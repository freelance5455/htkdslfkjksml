// ===== game: HUD, waves, input, ambience, main loop =====
const H = { money: $('money'), vt: document.querySelector('#vitals .t'), hp: $('hpNum'), fill: $('hpFill'), ammo: $('ammoNum'), wn: $('wName'), gren: $('gren'), wave: $('wave'), left: $('left'), score: $('score'), combo: $('combo'), msg: $('msg'), feed: $('feed'), hitm: $('hitm'), hurt: $('fxHurt'), hint: $('hint'), slots: [...document.querySelectorAll('#slots b')], radar: $('radar').getContext('2d') };
function setT(el, t) { if (el._t !== t) { el.textContent = t; el._t = t; } }
function hudHealth() { setT(H.hp, String(Math.ceil(P.hp))); setT(H.vt, P.armor > 0 ? 'SAĞLIK · ZIRH ' + Math.ceil(P.armor) : 'SAĞLIK'); H.fill.style.width = (P.hp / P.maxHp * 100) + '%'; H.fill.classList.toggle('low', P.hp <= 30); }
function hudAmmo() {
  const s = P.ws[P.cur], w = WEAPONS[P.cur];
  setT(H.wn, wname(P.cur)); H.ammo.innerHTML = s.ammo + ' <span>/ ' + s.reserve + '</span>'; setT(H.gren, 'BOMBA ' + P.gren + ' · MOLOTOF ' + P.molo + (P.air ? ' · HAVA ' + P.air : '')); setT(H.money, '$' + P.money);
  $('keys').innerHTML = [['R', 'ŞARJÖR', ''], ['G', 'BOMBA', P.gren], ['T', 'MOLOTOF', P.molo], ['X', 'HAVA SALDIRISI', P.air], ['E', 'AÇ / BİN', ''], ['TAB', 'ENVANTER', '']].map(k => `<span class="${k[2] === 0 ? 'z' : ''}"><kbd>${k[0]}</kbd> ${k[1]}${k[2] === '' ? '' : ' <b>' + k[2] + '</b>'}</span>`).join('');
  H.slots.forEach((b, i) => { b.classList.toggle('on', i === P.cur); b.style.display = P.owned[i] ? '' : 'none'; });
}
let hitT = 0;
function hitMarker(head, kill) { H.hitm.className = 'on' + (head || kill ? ' head' : ''); hitT = .13; }
function flashHurt(k) { H.hurt.style.opacity = k; }
const dirEls = []; let dirI = 0;
for (let i = 0; i < 6; i++) { const d = document.createElement('div'); d.className = 'dir'; d.innerHTML = '<i></i>'; $('dirs').appendChild(d); dirEls.push(d); }
function dmgDir(b) {
  const rel = angDiff(P.yaw + Math.PI, b), d = dirEls[dirI]; dirI = (dirI + 1) % dirEls.length;
  d.style.transition = 'none'; d.style.transform = 'rotate(' + (-rel * 180 / Math.PI) + 'deg)'; d.style.opacity = 1;
  requestAnimationFrame(() => requestAnimationFrame(() => { d.style.transition = 'opacity 1.2s'; d.style.opacity = 0; }));
}
function feedLine(t, cls) { const d = document.createElement('div'); d.textContent = t; if (cls) d.className = cls; H.feed.appendChild(d); while (H.feed.children.length > 5) H.feed.removeChild(H.feed.firstChild); setTimeout(() => d.remove(), 4000); }
function message(big, small) { H.msg.innerHTML = big + (small ? '<small>' + small + '</small>' : ''); H.msg.classList.remove('on'); void H.msg.offsetWidth; H.msg.classList.add('on'); }
function hint(t) { H.hint.style.display = t ? 'block' : 'none'; if (t) H.hint.textContent = t; }

function drawRadar() {
  const c = H.radar, s = 168, R = 84; c.clearRect(0, 0, s, s); c.save(); c.translate(R, R);
  c.strokeStyle = 'rgba(241,231,203,.18)'; c.lineWidth = 1; for (const r of [28, 56, 82]) { c.beginPath(); c.arc(0, 0, r, 0, 6.283); c.stroke(); }
  c.beginPath(); c.moveTo(0, -R); c.lineTo(0, R); c.moveTo(-R, 0); c.lineTo(R, 0); c.stroke();
  const range = 70, sc = (R - 4) / range, cy = Math.cos(P.yaw), sy = Math.sin(P.yaw);
  const pt = (x, z) => { const dx = x - P.pos.x, dz = z - P.pos.z; let rx = dx * cy - dz * sy, ry = dx * sy + dz * cy; const d = Math.hypot(rx, ry); if (d > range) { rx *= range / d; ry *= range / d; } return [rx * sc, ry * sc, d > range]; };
  if (PT) { const [x, y] = pt(PT.x, PT.z); c.fillStyle = '#8fd46a'; c.fillRect(x - 5, y - 5, 10, 10); }
  if (airdrop) { const [x, y] = pt(airdrop.x, airdrop.z); c.fillStyle = '#c68bff'; c.fillRect(x - 5, y - 5, 10, 10); }
  for (const a of allies) { if (a.dead) continue; const [x, y] = pt(a.x, a.z); c.fillStyle = '#4aa8ff'; c.fillRect(x - 3, y - 3, 6, 6); }
  if (merchant) { const [x, y] = pt(merchant.x, merchant.z); c.fillStyle = '#ffc040'; c.fillRect(x - 4, y - 4, 8, 8); }
  for (const k of pickups) { const [x, y] = pt(k.x, k.z); c.fillStyle = k.type === 'med' ? '#f2f2e6' : '#9fd05a'; c.fillRect(x - 2.5, y - 2.5, 5, 5); }
  for (const e of enemies) { if (e.dead) continue; const [x, y, edge] = pt(e.x, e.z); c.fillStyle = e.type === 'tank' ? '#ff8a1a' : e.type === 'sniper' ? '#ff4ad8' : '#e2412c'; c.globalAlpha = edge ? .5 : 1; const r = e.type === 'tank' ? 5 : 3.2; c.beginPath(); c.arc(x, y, r, 0, 6.283); c.fill(); }
  c.globalAlpha = 1; c.fillStyle = '#f1e7cb'; c.beginPath(); c.moveTo(0, -7); c.lineTo(5, 5); c.lineTo(-5, 5); c.closePath(); c.fill(); c.restore();
}

// ---- waves ----
function enterMap(i) {
  removeMerchant(); clearLoot(); clearEnemies(); clearTanks(); fires.length = 0; P.inTank = false; loadMap(i);
  P.pos.set(14, 0, 0); P.yaw = Math.PI / 2; P.pitch = 0; P.vx = P.vz = 0; P.hp = P.maxHp; spawnSquad(LOBBY.squad);
  setTimeout(() => message(MAP.name, MAP.sub), 300);
}
function startWave() {
  const nn = G.wave + 1;
  G.wave++; const n = G.wave, q = []; removeMerchant(); clearLoot(); spawnLoot(8 + Math.min(n, 6));
  const cm = DIFF.cnt, W = Math.min(n, 60);
  for (let i = 0; i < Math.round(Math.min(3 + 2 * W, 24 + Math.max(0, n - 30) * .5) * cm); i++) q.push('soldier');
  for (let i = 0; i < Math.round(Math.min(9 + Math.max(0, n - 30) / 4, Math.max(0, Math.floor((n - 1) / 2))) * cm); i++) q.push('heavy');
  if (n >= 3) for (let i = 0; i < Math.round(Math.min(5, 1 + Math.floor(n / 6)) * cm); i++) q.push('sniper');
  if (n % 3 === 0 && G.mode !== 'gungame') for (let i = 0; i < Math.round(Math.min(4, 1 + Math.floor(n / 10)) * Math.min(cm, 1.5)); i++) q.push('tank');
  for (let i = q.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [q[i], q[j]] = [q[j], q[i]]; }
  G.queue = q; G.waveActive = true; G.spawnT = 1.5;
  message('DALGA ' + n, n === 1 ? 'DÜŞMAN YAKLAŞIYOR' : (n % 3 === 0 ? 'ZIRHLI BİRLİK GELİYOR' : 'TAKVİYE GELİYOR'));
  setT(H.wave, G.mode === 'gungame' ? ggLabel() : 'DALGA ' + String(n).padStart(2, '0') + (G.mode === 'endless' ? ' / ∞' : ' / 30'));
  if (n % 2 === 0 && G.mode !== 'gungame') setTimeout(() => { if (G.state === 'playing' && G.waveActive && G.wave === n) spawnAirdrop(); }, 3500);
}
function updateWaves(dt) {
  G.chainT = Math.max(0, G.chainT - dt); if (G.chainT <= 0) G.chain = 0;
  if (G.arena) { updateArena(dt); return; }
  const alive = enemies.filter(e => !e.dead), soft = alive.filter(e => e.type !== 'tank').length;
  if (G.waveActive) {
    G.spawnT -= dt;
    if (G.queue.length && G.spawnT <= 0 && (soft < Math.min(8 + G.wave, 22) * Math.max(.8, DIFF.cnt) || G.queue[0] === 'tank')) { spawnEnemy(G.queue.shift()); G.spawnT = rand(.6, 1.4); }
    if (!G.queue.length && !alive.length) {
      if (G.wave >= 30 && G.mode === 'camp') { G.waveActive = false; if (SET.cine) { startPickup(altVehicle(MAPS[5].vehicle), 'win'); } else winGame(); return; }
      G.waveActive = false; G.breakT = G.mode === 'gungame' ? 6 : 50; const bonus = G.wave * 250; G.score += bonus; P.money += G.wave * 150; if (G.mode !== 'gungame') spawnMerchant();
      P.hp = Math.min(P.maxHp, P.hp + 30); P.ws[0].reserve += 60; P.ws[1].reserve += 8; P.ws[2].reserve += 1; P.gren = Math.min(6, P.gren + 1); hudHealth(); hudAmmo();
      feedLine('DALGA TEMİZLENDİ +' + bonus + ' · $' + G.wave * 150, '');
      if (G.wave % 5 === 0 && G.mode !== 'gungame') { G.extract = 0; G.breakT = 90; showLZ(); message('TAHLİYE ÇAĞRILDI', 'MAVİ IŞIĞA GİT · SIRADAKİ: ' + MAPS[(G.wave / 5) % MAPS.length].name); }
    }
  } else if (G.state === 'playing' && !P.dead) {
    G.breakT -= dt;
    if (G.wave % 5 === 0 && G.wave > 0 && lz && G.mode !== 'gungame') {
      const d = Math.hypot(P.pos.x - lz.x, P.pos.z - lz.z); hint('TAHLİYE NOKTASI: ' + Math.round(d) + ' m' + (d < 7 ? ' · BEKLE' : ''));
      G.extract = d < 7 ? (G.extract || 0) + dt : 0;
      if (G.extract > 1.6 || G.breakT <= 0) { hint(''); G.extract = 0; const nm = (G.wave / 5) % MAPS.length; if (SET.cine) startPickup(altVehicle(MAPS[nm].vehicle), 'map'); else { hideLZ(); enterMap(nm); } }
    } else if (G.breakT <= 0) startWave();
  }
  setT(H.left, G.waveActive ? 'DÜŞMAN ' + (alive.length + G.queue.length) : (G.wave ? 'SONRAKİ DALGA ' + Math.max(0, Math.ceil(G.breakT)) + ' · N' : 'HAZIRLAN'));
  setT(H.score, String(G.score));
  const mult = G.chainT > 0 ? Math.min(5, 1 + Math.floor((G.chain - 1) / 2)) : 1; setT(H.combo, G.chainT > 0 && mult > 1 ? 'x' + mult + ' SERİ' : '');
}
function winGame() {
  G.state = 'over'; saveBest(); try { payout(true); } catch (e) { reportErr(e); } $('oWave').textContent = G.wave; $('oScore').textContent = G.score; $('oKills').textContent = G.kills; $('oHeads').textContent = G.heads; $('oBest').textContent = bestScore();
  document.querySelector('#over h1').textContent = 'ZAFER'; document.querySelector('#over .eyebrow').textContent = G.mode === 'gungame' ? '20 silah tamamlandı' : G.mode === 'tdm' ? 'Takım ölüm kazanıldı' : '30 dalga tamamlandı'; $('over').hidden = false; if (document.pointerLockElement) document.exitPointerLock();
}
function bestScore() { try { return +localStorage.getItem('celikCephe') || 0; } catch (e) { return 0; } }
function saveBest() { try { if (G.score > bestScore()) localStorage.setItem('celikCephe', G.score); } catch (e) { } }
function showBest() { const b = bestScore(); $('best').textContent = b ? 'En iyi skor: ' + b : ''; }

// ---- state ----
let noLock = false, lockFails = 0, lastLockExit = 0;
function startGame() {
  if (isTouch) { try { const r = document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); if (r && r.catch) r.catch(() => { }); } catch (e) { } }
  initAudio(); camera.fov = 75; camera.updateProjectionMatrix(); canvas.style.filter = ''; $('fade').style.transition = 'none'; $('fade').style.opacity = 0;
  const arenaM = LOBBY.mode === 'tdm' || LOBBY.mode === 'gungame', wantMap = arenaM ? 'arena' : (LOBBY.map | 0); if ((MAP === MAP_ARENA ? 'arena' : MAPI) !== wantMap) loadMap(wantMap);
  if (G.mode && !G.paid && (G.wave > 0 || G.arena)) payout(false);
  musicStop(); clearEnemies(); clearLoot(); resetPlayer(); applyPerks(); $('oEarn').textContent = ''; G.mode = LOBBY.mode; G.paid = false; Object.assign(G, { score: 0, kills: 0, heads: 0, chain: 0, chainT: 0, wave: (!arenaM && wantMap > 0) ? wantMap * 5 : 0, queue: [], waveActive: false, breakT: 2.5, state: 'playing', arena: false, arenaEnd: false });
  if (!arenaM && wantMap > 0) P.money += wantMap * 1200;
  if (ggOn()) ggStart(); else if (G.mode === 'tdm') tdmLoadout();
  removeMerchant(); clearTanks(); fires.length = 0; $('menu').hidden = $('over').hidden = $('pause').hidden = $('shop').hidden = $('inv').hidden = true; $('hud').hidden = false; H.feed.innerHTML = '';
  hudHealth(); hudAmmo(); if (ggOn()) { setT(H.wave, ggLabel()); message('SİLAH OYUNU', GG[0].n + ' · HER 2 ÖLDÜRME = YENİ SİLAH'); } else { setT(H.wave, 'DALGA ' + String(G.wave + 1).padStart(2, '0')); message('HAZIR OL', 'M4 KARABİNA · 3 EL BOMBASI'); }
  hint(isTouch ? 'Sol: hareket · Sağ: bakış' : 'WASD hareket · Sol tık ateş · E sandık aç');
  setTimeout(() => hint(''), 7000); lockMouse();
  hideLZ(); clearStrikes(); clearAllies();
  if (arenaM) { arenaStart(); spawnSquad(LOBBY.squad); if (G.mode === 'tdm') message('TAKIM ÖLÜM', 'İLK 30 ÖLDÜRMEYİ YAPAN KAZANIR'); }
  else if (!SET.cine) spawnSquad(LOBBY.squad);
  if (SET.cine && !arenaM) { try { startDrop(pickV(['plane', 'plane', 'heli', 'gunship'])); } catch (e) { reportErr(e); G.state = 'playing'; } }
}
function lockMouse() {
  if (isTouch || noLock) return;
  try { const r = canvas.requestPointerLock(); if (r && r.catch) r.catch(() => lockFailed()); } catch (e) { lockFailed(); }
}
function lockFailed() { const since = performance.now() - lastLockExit; if (since < 1800 && G.state === 'playing') { setTimeout(lockMouse, 1850 - since); return; } if (++lockFails >= 3 && !noLock) { noLock = true; mouse.free = true; hint('Fare kilitlenemedi: imleci ekranın kenarına götürerek dön'); setTimeout(() => hint(''), 6000); }}
function pauseGame() { if (G.state !== 'playing' || P.dead) return; G.state = 'paused'; P.trigger = false; hint(''); $('pause').hidden = false; if (document.pointerLockElement) document.exitPointerLock(); }
function resumeGame() { if (G.state !== 'paused') return; G.state = 'playing'; $('pause').hidden = true; lockMouse(); }
function gameOver(title, eyebrow) {
  document.querySelector('#over h1').textContent = title || 'ÖLDÜN'; document.querySelector('#over .eyebrow').textContent = eyebrow || 'Hat çöktü'; canvas.style.filter = ''; $('fade').style.transition = 'none'; $('fade').style.opacity = 0;
  G.state = 'over'; saveBest(); try { payout(false); } catch (e) { reportErr(e); } $('oWave').textContent = G.wave; $('oScore').textContent = G.score; $('oKills').textContent = G.kills; $('oHeads').textContent = G.heads; $('oBest').textContent = bestScore();
  $('over').hidden = false; if (document.pointerLockElement) document.exitPointerLock(); flashHurt(0);
}
function toMenu() {
  hideLZ(); clearStrikes(); clearAllies(); G.arena = false; $('settings').hidden = true; if (G.mode && !G.paid && (G.state === 'paused' || G.state === 'playing')) payout(false);
  G.state = 'menu'; clearEnemies(); clearLoot(); removeMerchant(); clearTanks(); fires.length = 0; P.inTank = false; P.trigger = false; P.adsHeld = false; document.body.classList.remove('intank');
  $('hud').hidden = $('pause').hidden = $('over').hidden = $('shop').hidden = $('inv').hidden = true; $('menu').hidden = false; reloadBar(-1); $('tankfp').style.opacity = 0; setFov(75); showBest(); profUI(); if (PROFILE) musicStart();
  if (document.pointerLockElement) document.exitPointerLock();
}
$('skip').onclick = skipCine; $('btnRestart').onclick = startGame; $('btnMenu').onclick = toMenu; $('btnQuality').onclick = () => setGfx((gfx + 1) % 4);
$('btnPlay').onclick = startGame; $('btnRetry').onclick = startGame; $('btnOverMenu').onclick = toMenu; $('btnResume').onclick = resumeGame;
document.addEventListener('pointerlockchange', () => { mouse.lock = document.pointerLockElement === canvas; if (!mouse.lock) lastLockExit = performance.now(); if (mouse.lock) { lockFails = 0; mouse.free = false; } else if (G.state === 'playing' && !noLock && !P.dead) pauseGame(); });
document.addEventListener('pointerlockerror', lockFailed);
document.addEventListener('mousemove', e => {
  if (G.state !== 'playing') return;
  if (mouse.lock) { { const mm = .0022 * SET.mouse / 100 * lerp(1, SET.ads / 100, P.ads); lookDX += e.movementX * mm; lookDY += e.movementY * mm; } }
  else { mouse.nx = (e.clientX / innerWidth - .5) * 2; mouse.ny = (e.clientY / innerHeight - .5) * 2; }
});
document.addEventListener('mousedown', e => {
  if (G.state !== 'playing' || isTouch) return;
  if (!mouse.lock && !noLock) return;
  if (e.button === 0) { P.trigger = true; } else if (e.button === 2) P.adsHeld = true;
});
document.addEventListener('mouseup', e => { if (e.button === 0) P.trigger = false; else if (e.button === 2) P.adsHeld = false; });
document.addEventListener('contextmenu', e => e.preventDefault());
function nextWeapon(dir) { for (let k = 1; k <= NW; k++) { const i = (P.cur + dir * k + 70) % NW; if (P.owned[i]) return switchWeapon(i); } }
document.addEventListener('wheel', e => { if (G.state === 'playing') nextWeapon(e.deltaY > 0 ? 1 : -1); }, { passive: true });
document.addEventListener('keydown', e => {
  K[e.code] = true;
  if (G.state === 'playing' && !e.repeat) {
    if (e.code === 'KeyE') interact(); else if (e.code === 'KeyR') { if (P.inTank) tankRepairKit(); else startReload(); }
    else if (e.code === 'KeyQ') tankToggleAmmo(); else if (e.code === 'KeyF') karaSpin('ins');
    else if (e.code === 'KeyC') doCrouch();
    else if (G.mode === 'tdm' && P.slots && /^Digit[1-4]$/.test(e.code)) switchWeapon(P.slots[+e.code[5] - 1]);
    else if ((e.code === 'ShiftLeft' || e.code === 'ShiftRight') && P.inTank && PT) PT.fp = !PT.fp;
    else if (e.code === 'KeyZ' && !P.inTank && P.onGround) { P.stance = P.stance === 2 ? 0 : 2; }
    else if (e.code === 'KeyT') aimBegin('molo'); else if (e.code === 'KeyX') aimBegin('air'); else if (e.code === 'KeyN' && !G.waveActive) G.breakT = Math.min(G.breakT, .1);
    else if (e.code === 'Tab' || e.code === 'KeyI') openInv();
    else if (e.code === 'Digit4') switchWeapon(3); else if (e.code === 'Digit5') switchWeapon(4); else if (e.code === 'Digit6') switchWeapon(5); else if (e.code === 'Digit7') switchWeapon(6); else if (e.code === 'KeyG') aimBegin('gren');
    else if (e.code === 'Digit1') switchWeapon(0); else if (e.code === 'Digit2') switchWeapon(1); else if (e.code === 'Digit3') switchWeapon(2);
    else if (e.code === 'KeyP' || (e.code === 'Escape' && noLock)) pauseGame();
  } else if (G.state === 'shop' && (e.code === 'Escape' || e.code === 'KeyE')) backToGame();
  else if (G.state === 'inv' && (e.code === 'Escape' || e.code === 'Tab' || e.code === 'KeyI')) closeInv();
  else if (G.state === 'paused' && (e.code === 'KeyP' || e.code === 'Escape' || e.code === 'Enter')) resumeGame();
  if (e.code === 'KeyM') muted = !muted;
  if (['Space', 'ArrowUp', 'ArrowDown', 'Tab'].includes(e.code)) e.preventDefault();
});
document.addEventListener('keyup', e => { K[e.code] = false; if (AIM.kind && ((e.code === 'KeyG' && AIM.kind === 'gren') || (e.code === 'KeyT' && AIM.kind === 'molo') || (e.code === 'KeyX' && AIM.kind === 'air'))) aimEnd(); });
addEventListener('blur', () => { for (const k in K) K[k] = false; P.trigger = false; if (noLock) pauseGame(); });

// interaction shared by E key and touch button
function interact() {
  if (P.inTank) exitTank(); else if (P.merchNear) openShop(); else if (P.dropNear) openAirdrop(); else if (P.lootNear) openLoot(P.lootNear); else if (tankNear()) enterTank();
}
// touch (pointer events: works with fingers and with a mouse in phone mode)
const TB = {
  fire: [() => { P.trigger = true; }, () => { P.trigger = false; }], ads: [() => { P.adsHeld = !P.adsHeld; }], jump: [() => { K.Space = true; }, () => { K.Space = false; }],
  reload: [() => { if (P.inTank) tankRepairKit(); else startReload(); }], gren: [() => aimBegin('gren'), () => aimEnd()], molo: [() => aimBegin('molo'), () => aimEnd()], air: [() => aimBegin('air'), () => aimEnd()],
  inspect: [() => karaSpin('ins')], crouch: [() => doCrouch()], prone: [() => { if (!P.inTank && P.onGround) P.stance = P.stance === 2 ? 0 : 2; }],
  use: [interact], weap: [() => nextWeapon(1)], inv: [() => openInv()], pause: [() => pauseGame()],
  nitro: [() => { K.Space = true; }, () => { K.Space = false; }], fix: [() => tankRepairKit()], tcan: [() => { P.trigger = true; }, () => { P.trigger = false; }], tmg: [() => { P.adsHeld = true; }, () => { P.adsHeld = false; }], fp: [() => { if (PT) PT.fp = !PT.fp; }]
};
const layer = $('touch'), allBtns = [...layer.querySelectorAll('[data-btn]')], origPos = allBtns.map(b => ({ b, parent: b.parentNode }));
{
  const T = { mid: null, lid: null, sx: 0, sy: 0, lx: 0, ly: 0 }, joy = $('joy');
  layer.addEventListener('pointerdown', e => {
    if (G.state !== 'playing' || e.target.closest('[data-btn]')) return;
    e.preventDefault(); try { layer.setPointerCapture(e.pointerId); } catch (x) { }
    if (e.clientX < innerWidth * .45 && T.mid === null) { T.mid = e.pointerId; T.sx = e.clientX; T.sy = e.clientY; joy.style.display = 'block'; joy.style.left = (e.clientX - 55) + 'px'; joy.style.top = (e.clientY - 55) + 'px'; joy.firstElementChild.style.transform = ''; }
    else if (T.lid === null) { T.lid = e.pointerId; T.lx = e.clientX; T.ly = e.clientY; }
  });
  layer.addEventListener('pointermove', e => {
    if (e.pointerId === T.mid) { touchIn.mx = clamp((e.clientX - T.sx) / 50, -1, 1); touchIn.my = clamp((e.clientY - T.sy) / 50, -1, 1); joy.firstElementChild.style.transform = `translate(${touchIn.mx * 30}px,${touchIn.my * 30}px)`; }
    else if (e.pointerId === T.lid) { { const am = lerp(1, SET.ads / 100, P.ads || 0); lookDX += (e.clientX - T.lx) * .0055 * SET.tx / 100 * am; lookDY += (e.clientY - T.ly) * .0045 * SET.ty / 100 * am; } T.lx = e.clientX; T.ly = e.clientY; }
  });
  const end = e => { if (e.pointerId === T.mid) { T.mid = null; touchIn.mx = touchIn.my = 0; joy.style.display = 'none'; } if (e.pointerId === T.lid) T.lid = null; };
  layer.addEventListener('pointerup', end); layer.addEventListener('pointercancel', end);
  layer.addEventListener('contextmenu', e => e.preventDefault());
  allBtns.forEach(b => {
    const h = TB[b.dataset.btn]; if (!h) return;
    b.addEventListener('pointerdown', e => {
      if (G.state !== 'playing') return; e.preventDefault(); e.stopPropagation(); try { b.setPointerCapture(e.pointerId); } catch (x) { } b.classList.add('on'); h[0]();
    });
    const up = e => { if (G.state === 'edit') return; b.classList.remove('on'); if (h[1]) h[1](); };
    b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
  });
}
// ---- button layout editor ----
const LKEY = 'celikCephe.layout'; let layout = { s: 1, p: null, z: {} }, editFrom = null, drag = null, selBtn = null;
try { const j = localStorage.getItem(LKEY); if (j) layout = JSON.parse(j); } catch (e) { }
function absPlace(b, x, y) { if (b.parentNode !== layer) layer.appendChild(b); const st = b.style; st.position = 'absolute'; st.left = x + '%'; st.top = y + '%'; st.right = 'auto'; st.bottom = 'auto'; st.margin = '0'; st.transform = 'translate(-50%,-50%) scale(' + (+b.dataset.z || 1) + ')'; }
function setZ(b, z) { b.dataset.z = z; if (b.style.left) b.style.transform = 'translate(-50%,-50%) scale(' + z + ')'; }
function applyLayout() { layer.style.setProperty('--us', layout.s || 1); $('editAll').value = Math.round((layout.s || 1) * 100); if (layout.z) for (const b of allBtns) if (layout.z[b.dataset.btn]) b.dataset.z = layout.z[b.dataset.btn]; if (layout.p) for (const b of allBtns) { const q = layout.p[b.dataset.btn]; if (q) absPlace(b, q[0], q[1]); } }
function resetLayout() { layout = { s: 1, p: null, z: {} }; for (const o of origPos) { o.parent.appendChild(o.b); o.b.removeAttribute('style'); delete o.b.dataset.z; } applyLayout(); try { localStorage.removeItem(LKEY); } catch (e) { } }
function openLayoutEditor(from) {
  if (!isTouch) setDevice('phone');
  editFrom = from; G.state = 'edit'; $('pause').hidden = $('menu').hidden = true; document.body.classList.add('editing'); $('editDim').hidden = $('editUI').hidden = false;
  const lr = layer.getBoundingClientRect(), pos = allBtns.map(b => { const r = b.getBoundingClientRect(); return [b, (r.left + r.width / 2 - lr.left) / lr.width * 100, (r.top + r.height / 2 - lr.top) / lr.height * 100]; });
  for (const [b, x, y] of pos) absPlace(b, x, y);
  selBtn = null; allBtns.forEach(b => b.classList.remove('sel')); $('editSize').disabled = true; const ep = $('editUI'); ep.style.left = '50%'; ep.style.top = ''; ep.style.transform = 'translateX(-50%)'; $('editBody').style.display = '';
}
function closeLayoutEditor() {
  const p = {}; for (const b of allBtns) if (b.style.left) p[b.dataset.btn] = [parseFloat(b.style.left), parseFloat(b.style.top)];
  layout.p = p; layout.s = (+$('editAll').value || 100) / 100; layout.z = {}; for (const b of allBtns) if (+b.dataset.z && +b.dataset.z !== 1) layout.z[b.dataset.btn] = +b.dataset.z; try { localStorage.setItem(LKEY, JSON.stringify(layout)); } catch (e) { }
  allBtns.forEach(b => b.classList.remove('sel')); document.body.classList.remove('editing'); $('editDim').hidden = $('editUI').hidden = true;
  if (editFrom === 'menu') { G.state = 'menu'; $('menu').hidden = false; } else { G.state = 'paused'; $('pause').hidden = false; }
}
layer.addEventListener('pointerdown', e => { if (G.state !== 'edit') return; const b = e.target.closest('[data-btn]'); if (!b) return; e.preventDefault(); try { b.setPointerCapture(e.pointerId); } catch (x) { } drag = { b, id: e.pointerId }; selBtn = b; allBtns.forEach(x => x.classList.toggle('sel', x === b)); $('editSize').disabled = false; $('editSize').value = Math.round((+b.dataset.z || 1) * 100); });
layer.addEventListener('pointermove', e => { if (!drag || e.pointerId !== drag.id) return; const lr = layer.getBoundingClientRect(); absPlace(drag.b, clamp((e.clientX - lr.left) / lr.width * 100, 1, 99), clamp((e.clientY - lr.top) / lr.height * 100, 1, 99)); });
const endDrag = e => { if (drag && e.pointerId === drag.id) drag = null; };
layer.addEventListener('pointerup', endDrag); layer.addEventListener('pointercancel', endDrag);
$('editSize').oninput = () => { if (selBtn) setZ(selBtn, (+$('editSize').value) / 100); };
$('editAll').oninput = () => layer.style.setProperty('--us', (+$('editAll').value) / 100);
{ // the panel itself can be dragged out of the way, and folded
  const ep = $('editUI'); let pd = null;
  $('editHandle').addEventListener('pointerdown', e => { if (e.target.id === 'editMin') return; const r = ep.getBoundingClientRect(); pd = { id: e.pointerId, dx: e.clientX - r.left, dy: e.clientY - r.top }; ep.style.transform = 'none'; ep.style.left = r.left + 'px'; ep.style.top = r.top + 'px'; try { $('editHandle').setPointerCapture(e.pointerId); } catch (x) { } e.preventDefault(); });
  $('editHandle').addEventListener('pointermove', e => { if (!pd || e.pointerId !== pd.id) return; ep.style.left = clamp(e.clientX - pd.dx, 0, innerWidth - 60) + 'px'; ep.style.top = clamp(e.clientY - pd.dy, 0, innerHeight - 30) + 'px'; });
  $('editHandle').addEventListener('pointerup', () => { pd = null; });
  $('editMin').onclick = () => { const b = $('editBody'); b.style.display = b.style.display === 'none' ? '' : 'none'; };
}
$('editReset').onclick = () => { resetLayout(); openLayoutEditor(editFrom); };
$('editOk').onclick = closeLayoutEditor;
$('btnLayout').onclick = () => openLayoutEditor('pause'); $('btnLayoutMenu').onclick = () => openLayoutEditor('menu');
// quality + errors
let lowQ = false, gfx = 2;
const GFX_N = ['PATATES', 'DÜŞÜK', 'YÜKSEK', 'NASA'];
function gfxRatio() { const d = window.devicePixelRatio || 1; return gfx === 0 ? .55 : gfx === 1 ? 1 : gfx === 2 ? Math.min(d, isTouch ? 1.5 : 1.75) : Math.min(d * 1.25, isTouch ? 2 : 2.5); }
function setGfx(l, save = true) {
  gfx = clamp(l | 0, 0, 3); lowQ = gfx <= 1; PQ = [.22, .55, 1, 1][gfx];
  renderer.shadowMap.enabled = gfx >= 2; sun.castShadow = gfx >= 2;
  const ss = gfx === 3 ? 4096 : (isTouch ? 1024 : 2048); if (sun.shadow.mapSize.x !== ss) { sun.shadow.mapSize.set(ss, ss); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } }
  renderer.toneMapping = gfx === 3 ? THREE.ACESFilmicToneMapping : THREE.NoToneMapping; renderer.toneMappingExposure = 1.15;
  camera.far = gfx === 0 ? 200 : 700; camera.updateProjectionMatrix();
  scene.traverse(o => { if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { m.needsUpdate = true; }); });
  renderer.setPixelRatio(gfxRatio()); resize(); document.body.classList.toggle('nasa', gfx === 3); document.body.classList.toggle('potato', gfx === 0);
  const t = 'GRAFİK: ' + GFX_N[gfx]; $('btnQuality').textContent = t; if ($('btnQualityLobby')) $('btnQualityLobby').textContent = t;
  if (save) try { localStorage.setItem('celikCephe.gfx', String(gfx)); } catch (e) { }
}
let lastErr = '';
function reportErr(err) { const m = String(err && err.message || err) + ((err && err.stack) ? '\n' + String(err.stack).split('\n')[1] : ''); if (m === lastErr) return; lastErr = m; const el = $('err'); el.textContent = 'HATA: ' + m; el.style.display = 'block'; }
addEventListener('error', e => reportErr(e.error || e.message));
// device picker
function setDevice(dev) {
  isTouch = dev === 'phone'; document.body.classList.toggle('touch', isTouch);
  document.querySelectorAll('.device button').forEach(b => b.classList.toggle('on', b.dataset.dev === dev));
  renderer.setPixelRatio(gfxRatio()); resize();
  try { localStorage.setItem('celikCephe.dev', dev); } catch (e) { }
}
document.querySelectorAll('.device button').forEach(b => b.onclick = () => setDevice(b.dataset.dev));
let savedDev = null; try { savedDev = localStorage.getItem('celikCephe.dev'); } catch (e) { }

// ---- ambience: emitters, distant booms, jets ----
let ambT = 3, jetT = 25; const jets = [];
function updateAmbience(dt, active) {
  for (const em of emitters) {
    if (Math.hypot(em.x - camera.position.x, em.z - camera.position.z) > 110) continue;
    if (em.kind === 'smoke') { if (Math.random() < dt * 5) smoke.emit(em.x + rand(-.5, .5), em.y, em.z + rand(-.5, .5), rand(-.2, .4), rand(1.5, 2.6), rand(-.2, .2), rand(4, 6), .8, 5, C_SMOKE0, C_SMOKE1, .55, 0, -.1, .2); }
    else { if (Math.random() < dt * 22) glow.emit(em.x + rand(-.15, .15), em.y, em.z + rand(-.15, .15), rand(-.2, .2), rand(.8, 1.8), rand(-.2, .2), rand(.4, .7), .5, .1, C_FIRE0, C_FIRE1, .9, 0, -1, .5); if (Math.random() < dt * 3) smoke.emit(em.x, em.y + .5, em.z, rand(-.2, .2), rand(1.5, 2.5), rand(-.2, .2), rand(2, 3.5), .5, 2.5, C_SMOKE0, C_SMOKE1, .4, 0, -.2, .3); }
  }
  ambT -= dt; if (ambT <= 0) {
    ambT = rand(3, 8); const a = rand(0, 6.283), r = 170, x = Math.cos(a) * r, z = Math.sin(a) * r;
    SND.boom(x, z, false); glow.emit(x, 6, z, 0, 0, 0, .5, 60, 20, C_FIRE0, C_FIRE1, .9, 0, 0, 0); smoke.emit(x, 8, z, 0, 5, 0, 5, 30, 70, C_SMOKE0, C_SMOKE1, .5, 0, 0, 0);
  }
  if (active || G.state === 'menu') { jetT -= dt; if (jetT <= 0) { jetT = rand(45, 75); spawnJets(); } }
  for (let i = jets.length - 1; i >= 0; i--) { const j = jets[i]; j.g.position.addScaledVector(j.v, dt); j.life -= dt; if (j.life <= 0) { scene.remove(j.g); jets.splice(i, 1); } }
}
function spawnJets() {
  const a = rand(0, 6.283), dir = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
  for (let k = 0; k < 2; k++) {
    const g = new THREE.Group(), mat = sm(0x3a3d3f, .6);
    const body = new THREE.Mesh(BX(1.4, .8, 10), mat); g.add(body); const wing = new THREE.Mesh(BX(9, .12, 3), mat); wing.position.z = 1; g.add(wing);
    const tail = new THREE.Mesh(BX(.15, 1.8, 1.8), mat); tail.position.set(0, 1, 4); g.add(tail);
    const ab = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: 0xff8a30, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, fog: false })); ab.scale.set(4, 4, 1); ab.position.z = 5.5; g.add(ab);
    g.position.copy(dir).multiplyScalar(-320).add(new THREE.Vector3(-dir.z * 25 * (k ? 1 : -1) + rand(-30, 30), 95 + k * 10, dir.x * 25 * (k ? 1 : -1)));
    g.lookAt(g.position.clone().add(dir)); g.rotation.z = 0; scene.add(g); jets.push({ g, v: dir.clone().multiplyScalar(125), life: 5.4 });
  }
  SND.jet();
}

// ---- main loop ----
let last = performance.now(), tAcc = 0, shadowSnap = new THREE.Vector3();
function frame(now) {
  requestAnimationFrame(frame);
  let dt = Math.min(.05, (now - last) / 1000); last = now; if (P.dead && G.state === 'playing') dt *= lerp(.4, 1, clamp((P.deadT - .8) / 1.4, 0, 1)); tAcc += dt;
  const playing = G.state === 'playing';
  { const kn = playing && !P.inTank; if (document.body.classList.contains('knife') !== kn) document.body.classList.toggle('knife', kn); }
  if (document.body.classList.contains('intank') !== !!P.inTank) document.body.classList.toggle('intank', !!P.inTank);
  if (playing) { try { updateWeather(dt); updateLoot(dt); updatePlayer(dt); aimUpdate(dt); updateStrikes(dt); updateAllies(dt); updateEnemies(dt); updateProjectiles(dt); updatePickups(dt); updateFires(dt); updateWrecks(dt); updateMarks(); updateWaves(dt); drawRadar(); } catch (err) { reportErr(err); } }
  if (G.state === 'cine' && C) { try { C.update(dt); } catch (err) { reportErr(err); try { cineVisualsOff(); if (C) disposeCine(C); C = null; $('fade').style.opacity = 0; $('loading').hidden = true; G.state = 'playing'; $('hud').hidden = false; } catch (e2) { } } }
  if (G.state === 'over') { updateEnemies(dt); updateProjectiles(dt); try { updateStrikes(dt); } catch (e) { } }
  if (G.state === 'menu') { try { menuStage(tAcc, dt); } catch (err) { reportErr(err); } vmFlashSpr.visible = false; } else if (MF) MF.g.visible = false;
  if (!['paused', 'shop', 'inv', 'edit'].includes(G.state)) {
    updateAmbience(dt, playing); smoke.update(dt); glow.update(dt); updateTracers(dt); updateLights(dt);
    P.hurtT > 0 || H.hurt.style.opacity > 0 ? H.hurt.style.opacity = Math.max(0, +H.hurt.style.opacity - dt * 1.6) : 0;
    if (P.hp <= 30 && playing && !P.dead) H.hurt.style.opacity = Math.max(+H.hurt.style.opacity, .25 + Math.sin(tAcc * 6) * .1);
    if (hitT > 0) { hitT -= dt; if (hitT <= 0) H.hitm.className = ''; }
  }
  skyMesh.position.copy(camera.position); skyU.uTime.value = tAcc;
  const px = Math.round(camera.position.x / 2) * 2, pz = Math.round(camera.position.z / 2) * 2;
  sun.target.position.set(px, 0, pz); sun.position.set(px + SUN_DIR.x * 150, SUN_DIR.y * 150, pz + SUN_DIR.z * 150);
  renderer.clear(); renderer.render(scene, camera);
  if ((G.state === 'playing' || G.state === 'cine' || G.state === 'shop' || G.state === 'inv') && (!P.dead || P.deadT < 1.3) && !P.inTank) { renderer.clearDepth(); renderer.render(vmScene, vmCam); }
}
function boot() {
  setDevice(savedDev || (isTouch ? 'phone' : 'pc'));
  resize(); applyLayout(); loadMap(0); showBest(); hudAmmo();
  camera.position.set(34, 9, 0); camera.lookAt(0, 3, 0);
  requestAnimationFrame(t => { last = t; frame(t); });
  let sq = null; try { sq = localStorage.getItem('celikCephe.gfx'); } catch (e) { }
  setTimeout(() => setGfx(sq !== null ? +sq : (isTouch ? 1 : 2), false), 50);
}
window.__game = { G, P, enemies, startGame, spawnEnemy };
boot();
