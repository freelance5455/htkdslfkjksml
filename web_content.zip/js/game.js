(()=>{
const $=id=>document.getElementById(id),mob=matchMedia('(pointer:coarse)').matches;if(mob)document.body.classList.add('m');
const R=new THREE.WebGLRenderer({canvas:$('c')});R.setPixelRatio(Math.min(devicePixelRatio,1.5));
const S=new THREE.Scene();S.background=new THREE.Color(0x020403);S.fog=new THREE.FogExp2(0x040806,.075);
const cam=new THREE.PerspectiveCamera(70,1,.1,90);cam.rotation.order='YXZ';S.add(cam);
const rs=()=>{R.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()};addEventListener('resize',rs);rs();
S.add(new THREE.AmbientLight(0x1a2a22,.5));
const tex=(w,h,fn,rx,ry)=>{const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rx,ry);return t};
const dirt=tex(256,256,(g,w,h)=>{g.fillStyle='#14180f';g.fillRect(0,0,w,h);for(let i=0;i<2500;i++){g.fillStyle=`rgba(${20+Math.random()*50|0},${20+Math.random()*30|0},12,${Math.random()*.6})`;g.fillRect(Math.random()*w,Math.random()*h,2+Math.random()*5,1+Math.random()*3)}},60,60);
const bark=tex(64,128,(g,w,h)=>{g.fillStyle='#3a2c20';g.fillRect(0,0,w,h);for(let i=0;i<60;i++){g.fillStyle=`rgba(0,0,0,${Math.random()*.6})`;g.fillRect(Math.random()*w,0,1+Math.random()*3,h)}},1,3);
const gnd=new THREE.Mesh(new THREE.PlaneGeometry(240,240),new THREE.MeshStandardMaterial({map:dirt,roughness:1}));gnd.rotation.x=-Math.PI/2;S.add(gnd);
const N=800,T=new THREE.InstancedMesh(new THREE.CylinderGeometry(.18,.4,14,6),new THREE.MeshStandardMaterial({map:bark,color:0x9a8a7a,roughness:1}),N),D=new THREE.Object3D(),trees=[];
for(let i=0;i<N;i++){let x,z;do{x=(Math.random()-.5)*170;z=(Math.random()-.5)*170}while(Math.hypot(x,z)<5);D.position.set(x,7,z);D.scale.setScalar(.7+Math.random()*.9);D.updateMatrix();T.setMatrixAt(i,D.matrix);trees.push([x,z])}
S.add(T);
const moon=new THREE.DirectionalLight(0x4a5a9a,.5);moon.position.set(30,40,-20);S.add(moon,new THREE.HemisphereLight(0x223344,0x050805,.35));
const BR=new THREE.InstancedMesh(new THREE.CylinderGeometry(.03,.09,3.2,4),T.material,N*3);
for(let i=0;i<N*3;i++){const [x,z]=trees[i%N];D.position.set(x+(Math.random()-.5)*.3,2+Math.random()*7,z);D.rotation.set((Math.random()-.5)*1.6,Math.random()*6.28,Math.random()*2-1);D.scale.setScalar(.8+Math.random()*1.4);D.updateMatrix();BR.setMatrixAt(i,D.matrix)}
D.rotation.set(0,0,0);S.add(BR);
const bld=tex(128,128,g=>{for(let i=0;i<40;i++){g.fillStyle=`rgba(${90+Math.random()*50|0},0,0,${.3+Math.random()*.6})`;g.beginPath();g.arc(64+(Math.random()-.5)*80,64+(Math.random()-.5)*80,1+Math.random()*(i<6?18:5),0,7);g.fill()}},1,1);
for(let i=0;i<18;i++){const a=i*2.1,r=7+i*3.7,m=new THREE.Mesh(new THREE.PlaneGeometry(3,3),new THREE.MeshStandardMaterial({map:bld,transparent:true,depthWrite:false}));m.rotation.x=-Math.PI/2;m.rotation.z=i;m.position.set(Math.cos(a)*r,.02,Math.sin(a)*r);S.add(m)}
const ring=new THREE.Mesh(new THREE.PlaneGeometry(7,7),new THREE.MeshStandardMaterial({map:tex(256,256,g=>{g.strokeStyle='#8B0000';g.lineWidth=6;g.beginPath();g.arc(128,128,115,0,7);g.moveTo(95,128);g.arc(128,128,95,Math.PI,3*Math.PI);g.stroke()},1,1),transparent:true,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.y=.03;S.add(ring);
const candles=[];for(let i=0;i<4;i++){const a=i*1.57+.8,p=new THREE.PointLight(0xff6a2a,1.2,9,2),x=Math.cos(a)*3.3,z=Math.sin(a)*3.3;p.position.set(x,.5,z);const m=new THREE.Mesh(new THREE.CylinderGeometry(.05,.06,.3,6),new THREE.MeshBasicMaterial({color:0xddccaa}));m.position.set(x,.15,z);S.add(p,m);candles.push(p)}
const mt=tex(128,128,g=>{const r=g.createRadialGradient(64,64,0,64,64,64);r.addColorStop(0,'rgba(180,200,190,.5)');r.addColorStop(1,'rgba(180,200,190,0)');g.fillStyle=r;g.fillRect(0,0,128,128)},1,1);
const mist=[];for(let i=0;i<36;i++){const s=new THREE.Sprite(new THREE.SpriteMaterial({map:mt,transparent:true,opacity:.14,depthWrite:false}));s.scale.set(14,5,1);s.position.set((Math.random()-.5)*70,1.2+Math.random()*1.5,(Math.random()-.5)*70);S.add(s);mist.push(s)}
const lamp=new THREE.SpotLight(0xfff0b0,3,45,.5,.6,1.4);lamp.position.set(.2,-.1,0);lamp.target.position.set(0,0,-6);cam.add(lamp,lamp.target);
const stex=(()=>{const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');g.strokeStyle='#8B0000';g.lineWidth=7;g.beginPath();g.arc(64,64,52,0,7);g.moveTo(64,12);for(let i=1;i<=5;i++){const a=i*4*Math.PI/5-Math.PI/2;g.lineTo(64+52*Math.cos(a),64+52*Math.sin(a))}g.stroke();return new THREE.CanvasTexture(c)})();
const items=[];
for(let i=0;i<10;i++){const a=i*2.4,r=9+i*5.5,m=new THREE.Mesh(new THREE.BoxGeometry(.18,.35,.18),new THREE.MeshBasicMaterial({color:0xffdd44}));m.position.set(Math.cos(a)*r,.2,Math.sin(a)*r);S.add(m);items.push({m,k:'b',i})}
for(let i=0;i<5;i++){const a=i*1.3+.5,r=16+i*11,m=new THREE.Mesh(new THREE.PlaneGeometry(1.3,1.3),new THREE.MeshBasicMaterial({map:stex,transparent:true,side:2}));m.position.set(Math.cos(a)*r,1.6,Math.sin(a)*r);m.lookAt(0,1.6,0);S.add(m);items.push({m,k:'s',i})}
const G=new Ghost(S);G.onSpawn=()=>Aud.violin();
let sta=100,tired=false,hbT=0,ps=0,mode='menu',yaw=0,pitch=0,bat=100,nb=0,sym=0,t=0,bt=0,rec=0,on=true,muted=false,started=false;
const P=new THREE.Vector3(0,1.7,0),got={b:[],s:[]};
// ---- input
const K={};addEventListener('keydown',e=>{K[e.code]=1;if(e.code=='KeyF'&&mode=='play')on=!on});addEventListener('keyup',e=>K[e.code]=0);
const look=(dx,dy,s)=>{yaw-=dx*s;pitch=Math.max(-1.3,Math.min(1.3,pitch-dy*s))};
document.addEventListener('mousemove',e=>{if(document.pointerLockElement&&mode=='play')look(e.movementX,e.movementY,.0022)});
$('c').addEventListener('click',()=>{if(!mob&&mode=='play')$('c').requestPointerLock()});
let jv=[0,0],jid=null,lid=null,lp;const jy=$('joy');
const jm=t=>{const r=jy.getBoundingClientRect(),x=(t.clientX-r.left-r.width/2)/(r.width/2),y=(t.clientY-r.top-r.height/2)/(r.height/2),l=Math.hypot(x,y)||1,k=Math.min(1,l)/l;jv=[x*k,y*k];$('knob').style.transform=`translate(${jv[0]*36}px,${jv[1]*36}px)`};
jy.addEventListener('touchstart',e=>{jid=e.changedTouches[0].identifier;jm(e.changedTouches[0])});
$('look').addEventListener('touchstart',e=>{lid=e.changedTouches[0].identifier;lp=[e.changedTouches[0].clientX,e.changedTouches[0].clientY]});
document.addEventListener('touchmove',e=>{for(const t of e.changedTouches){if(t.identifier==jid)jm(t);else if(t.identifier==lid){look(t.clientX-lp[0],t.clientY-lp[1],.005);lp=[t.clientX,t.clientY]}}});
document.addEventListener('touchend',e=>{for(const t of e.changedTouches){if(t.identifier==jid){jid=null;jv=[0,0];$('knob').style.transform=''}if(t.identifier==lid)lid=null}});
$('fl').onclick=()=>{on=!on};
const ic=n=>`<svg class="i"><use href="#i-${n}"/></svg>`;
$('st').onclick=()=>{muted=!muted;Aud.mute(muted);$('st').innerHTML=ic(muted?'mute':'snd')};
function pz(on){if(on&&mode=='play'){mode='pause';document.exitPointerLock();$('pause').classList.remove('hide')}else if(!on&&mode=='pause'){mode='play';$('pause').classList.add('hide');if(!mob)$('c').requestPointerLock()}}
$('pz').onclick=()=>pz(true);$('bp').onclick=()=>pz(false);
$('bm').onclick=()=>{save();G.reset();mode='menu';['pause','hud'].forEach(i=>$(i).classList.add('hide'));$('menu').classList.remove('hide');$('bc').disabled=false;Aud.music(true)};
document.addEventListener('pointerlockchange',()=>{if(!document.pointerLockElement&&mode=='play'&&!mob)pz(true)});
addEventListener('keydown',e=>{if(e.code=='KeyP')pz(mode=='play')});
// ---- flow
const save=()=>Save.save({x:P.x,z:P.z,yaw,bat,nb,sym,got,scene:'forest'});
function end(msg){mode='over';document.documentElement.style.setProperty('--t',0);document.exitPointerLock();$('ot').textContent=msg;$('over').classList.remove('hide')}
G.onCatch=()=>end('คุณไม่ได้กลับออกมาอีกเลย...');
function start(s){
 s=s||{};P.set(s.x||0,1.7,s.z||0);yaw=s.yaw||0;pitch=0;bat=s.bat==null?100:s.bat;nb=s.nb||0;sym=s.sym||0;got.b=(s.got&&s.got.b)||[];got.s=(s.got&&s.got.s)||[];
 items.forEach(it=>{it.d=got[it.k].includes(it.i);it.m.visible=!it.d});
 G.reset();rec=0;on=true;mode='play';
 ['menu','over'].forEach(i=>$(i).classList.add('hide'));$('hud').classList.remove('hide');Aud.music(false);save();
 if(mob){const e=document.documentElement;e.requestFullscreen&&e.requestFullscreen().catch(()=>{})}else $('c').requestPointerLock();
}
$('load').addEventListener('pointerdown',()=>{if(started)return;started=true;Aud.init();$('lp').textContent='กำลังโหลด...';
 Aud.heart(p=>{$('lf').style.width=p*100+'%'},()=>{$('load').classList.add('hide');$('menu').classList.remove('hide');$('bc').disabled=!Save.has();Aud.music(true)})});
$('bn').onclick=()=>{Save.clear();start(null)};
$('bc').onclick=()=>start(Save.load());
$('br').onclick=()=>start(Save.load());
$('be').onclick=()=>{Aud.scream(.9);document.body.classList.add('sk');setTimeout(()=>{document.body.classList.remove('sk');try{window.close()}catch(e){}},900)};
setInterval(()=>{if(mode=='play'&&G.st!='scare')save()},4000);
// ---- loop
function menu(dt){yaw+=dt*.12;pitch=Math.sin(t*.4)*.08;cam.position.set(0,1.7,0);lamp.intensity=Math.random()<.08?0:2.5+Math.sin(t*2)*.5}
function play(dt){
 const sc=G.st=='scare',run=(K.ShiftLeft||K.ShiftRight||jv[1]<-.95)&&!tired;
 let f=sc?0:(K.KeyW||K.ArrowUp?1:0)-(K.KeyS||K.ArrowDown?1:0)-jv[1],s=sc?0:(K.KeyD||K.ArrowRight?1:0)-(K.KeyA||K.ArrowLeft?1:0)+jv[0];
 const l=Math.hypot(f,s);if(l>1){f/=l;s/=l}
 const rn=run&&l>0;sta=Math.max(0,Math.min(100,sta+(rn?-22:14)*dt));if(sta<=0)tired=true;else if(sta>25)tired=false;const v=(rn?5.5:3)*dt;P.x+=(-Math.sin(yaw)*f+Math.cos(yaw)*s)*v;P.z+=(-Math.cos(yaw)*f-Math.sin(yaw)*s)*v;
 for(const [x,z] of trees){const dx=P.x-x,dz=P.z-z,d=Math.hypot(dx,dz)||.01;if(d<.7){P.x=x+dx/d*.7;P.z=z+dz/d*.7}}
 const r=Math.hypot(P.x,P.z);if(r>80){P.x*=80/r;P.z*=80/r}
 bt+=dt*l*(run?9:6);const sn=Math.sin(bt);if(l>0&&sn*ps<0)Aud.step();ps=sn;cam.position.set(P.x,1.7+sn*.04,P.z);cam.fov+=((rn?78:70)-cam.fov)*Math.min(1,dt*6);cam.updateProjectionMatrix();rec+=dt;
 if(on&&bat>0)bat=Math.max(0,bat-dt*.8);
 const th=G.update(dt,P,cam,sym);document.documentElement.style.setProperty('--t',th);hbT-=dt;if(th>.3&&hbT<=0){Aud.beat();hbT=1.3-th*.8}
 if(sc){cam.position.x+=(Math.random()-.5)*.08;cam.position.y+=(Math.random()-.5)*.08}
 lamp.intensity=on&&bat>0?3*Math.min(1,.2+bat/35)*(Math.random()<th*.6?Math.random()*.4:1):0;
 Aud.threat(th);Aud.ghost(G.pos,G.on);Aud.listen(P,yaw);
 for(const it of items)if(!it.d&&Math.hypot(it.m.position.x-P.x,it.m.position.z-P.z)<1.8){
  it.d=1;it.m.visible=false;got[it.k].push(it.i);Aud.pick();
  if(it.k=='b'){nb++;bat=Math.min(100,bat+35)}else{sym++;if(sym>=5)end('สัญลักษณ์ครบ... แต่เสียงกรีดร้องยังตามมาในความมืด')}}
 const mm=rec/60|0,ss=rec%60|0;
 $('bf').style.width=bat+'%';$('tm').textContent=(mm<10?'0':'')+mm+':'+(ss<10?'0':'')+ss;$('nb').textContent=nb;$('sy').textContent=sym;$('sf').style.width=sta+'%';
}
const gx=$('grain').getContext('2d');let gf=0;
const grain=()=>{if(gf++%3)return;const im=gx.createImageData(160,90),d=im.data;for(let i=0;i<d.length;i+=4){const v=Math.random()*255;d[i]=d[i+1]=d[i+2]=v;d[i+3]=255}gx.putImageData(im,0,0)};
const clk=new THREE.Clock();
(function loop(){requestAnimationFrame(loop);const dt=Math.min(clk.getDelta(),.1);t+=dt;
 candles.forEach(p=>p.intensity=.9+Math.random()*.6);
 mist.forEach((s,i)=>{s.position.x+=Math.sin(t*.1+i)*dt*.6;s.position.z+=Math.cos(t*.08+i)*dt*.6;if(Math.hypot(s.position.x-cam.position.x,s.position.z-cam.position.z)>40){s.position.x=cam.position.x+(Math.random()-.5)*60;s.position.z=cam.position.z+(Math.random()-.5)*60}});
 if(mode=='play')play(dt);else if(mode=='menu')menu(dt);
 cam.rotation.set(pitch,yaw,0);R.render(S,cam);grain()})();
})();
