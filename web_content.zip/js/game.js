/**
 * Snake Escape — Main Game Controller & State Machine
 * Coordinates gameplay loop, timed traps, level timer, move scoring,
 * BFS hints, full undo/reset, and win/loss conditions.
 */
(function() {
  'use strict';

  class Game {
    constructor() {
      this.state = {
        currentLevelId: 1,
        currentLevelData: null,
        gameStatus: 'loading',
        snakes: [],
        moves: 0,
        timerSeconds: 0,
        timerInterval: null,
        trapInterval: null,
        hintsRemaining: 3,
        isPaused: false
      };

      this.storage = window.SnakeEscape.storage;
      this.audio = window.SnakeEscape.audio;
      this.animation = window.SnakeEscape.animation;
      this.collision = window.SnakeEscape.collision;
      this.levelManager = window.SnakeEscape.levelManager;
      this.progress = window.SnakeEscape.progress;
      this.ui = window.SnakeEscape.ui;
      this.settings = window.SnakeEscape.settings;

      this.player = new window.SnakeEscape.PlayerController();
      this.mazeRenderer = null;
      this.input = new window.SnakeEscape.InputHandler();
    }

    init() {
      const svgBoard = document.getElementById('maze-svg');
      const boardContainer = document.querySelector('.stone-maze-frame');

      this.mazeRenderer = new window.SnakeEscape.MazeRenderer(svgBoard);

      // Initialize inputs with callbacks
      this.input.init(boardContainer, this.mazeRenderer, {
        move: (dir) => this.handleMove(dir),
        tapCell: (coord) => this.handleTapCell(coord),
        reset: () => this.resetLevel(),
        hint: () => this.showHint(),
        pause: () => this.togglePause(),
        undo: () => this.undoMove()
      });

      // Window resize handler for responsive SVG scaling
      window.addEventListener('resize', () => {
        if (this.state.gameStatus === 'playing') {
          this.mazeRenderer.updateDimensions();
          this.mazeRenderer.render(this.state.snakes);
        }
      });
    }

    /**
     * Loads and initializes a level
     */
    loadLevel(levelId) {
      this.stopTimers();

      const rawLevelData = this.levelManager.getLevel(levelId);
      if (!rawLevelData) {
        console.error(`Cannot load level ${levelId}`);
        return;
      }

      // Deep clone so runtime mutations don't alter base level templates
      const levelData = JSON.parse(JSON.stringify(rawLevelData));

      this.state.currentLevelId = levelId;
      this.state.currentLevelData = levelData;
      this.state.gameStatus = 'playing';
      this.state.moves = 0;
      this.state.timerSeconds = 0;
      this.state.hintsRemaining = 3;
      this.state.isPaused = false;

      // Instantiate Snake entities
      this.state.snakes = levelData.snakes.map(sData => new window.SnakeEscape.Snake(sData));

      // Init player controller & maze
      this.player.init(this.state.snakes);
      this.mazeRenderer.initLevel(levelData);
      this.mazeRenderer.render(this.state.snakes);

      // Start gameplay timers
      this.startTimer();
      this.initTimedTraps();

      // Update HUD
      this.updateGameHUD();
      this.ui.updateHintBadge(this.state.hintsRemaining);
      this.ui.hideAllModals();
      this.input.setEnabled(true);
    }

    startTimer() {
      if (this.state.timerInterval) clearInterval(this.state.timerInterval);
      this.state.timerInterval = setInterval(() => {
        if (this.state.gameStatus === 'playing' && !this.state.isPaused) {
          this.state.timerSeconds++;
          this.updateGameHUD();
        }
      }, 1000);
    }

    stopTimers() {
      if (this.state.timerInterval) {
        clearInterval(this.state.timerInterval);
        this.state.timerInterval = null;
      }
      if (this.state.trapInterval) {
        clearInterval(this.state.trapInterval);
        this.state.trapInterval = null;
      }
    }

    initTimedTraps() {
      const traps = this.state.currentLevelData?.traps || [];
      const timedTraps = traps.filter(t => t.isTimed);
      if (!timedTraps.length) return;

      this.state.trapInterval = setInterval(() => {
        if (this.state.gameStatus !== 'playing' || this.state.isPaused) return;

        timedTraps.forEach(trap => {
          if (trap.state === 'active') {
            trap.state = 'inactive';
          } else {
            trap.state = 'active';
            this.audio.playTrapWarning();
          }
        });
        this.mazeRenderer.render(this.state.snakes);
      }, 3000);
    }

    updateGameHUD() {
      const lvl = this.state.currentLevelData;
      const parMoves = lvl ? lvl.parMoves : 15;
      const worldNum = lvl ? (lvl.world || 1) : 1;
      const remaining = this.getSnakesRemaining();

      this.ui.updateHUD(
        this.state.currentLevelId,
        remaining,
        this.state.moves,
        parMoves,
        this.state.timerSeconds,
        worldNum,
        lvl ? lvl.keys : []
      );
    }

    handleMove(direction) {
      if (this.state.gameStatus !== 'playing' || this.state.isPaused) return;

      const success = this.player.tryMove(
        direction,
        this.state.snakes,
        this.state.currentLevelData,
        this.collision,
        this.audio,
        this.animation,
        {
          onMoveCountChange: (count) => {
            this.state.moves = count;
            this.updateGameHUD();
          },
          onSnakeEscaped: (snake) => {
            this.handleSnakeEscaped(snake);
          },
          onLevelFailed: (reason) => {
            this.onLevelFailed(reason);
          },
          onMoveComplete: () => {
            this.mazeRenderer.render(this.state.snakes);
            this.checkGameConditions();
          }
        }
      );

      if (success) {
        this.mazeRenderer.clearHintPath();
        this.mazeRenderer.render(this.state.snakes);
      }
    }

    handleTapCell(coord) {
      if (this.state.gameStatus !== 'playing' || this.state.isPaused) return;

      // 1. Check if user tapped another non-escaped snake: select it
      for (const snake of this.state.snakes) {
        if (snake.escaped) continue;
        const tappedSnake = snake.segments.some(seg => seg.x === coord.x && seg.y === coord.y);
        if (tappedSnake) {
          this.player.selectSnake(snake.id, this.state.snakes);
          this.audio.playClick();
          this.mazeRenderer.render(this.state.snakes);
          return;
        }
      }

      // 2. Check if tapped cell is adjacent to active snake's head
      const activeSnake = this.player.getActiveSnake(this.state.snakes);
      if (!activeSnake) return;

      const head = activeSnake.getHead();
      const dx = coord.x - head.x;
      const dy = coord.y - head.y;

      if (Math.abs(dx) + Math.abs(dy) === 1) {
        let dir = null;
        if (dx === 1) dir = 'RIGHT';
        else if (dx === -1) dir = 'LEFT';
        else if (dy === 1) dir = 'DOWN';
        else if (dy === -1) dir = 'UP';

        if (dir) {
          this.handleMove(dir);
        }
      }
    }

    getSnakesRemaining() {
      return this.state.snakes.filter(s => !s.escaped && !s.isDead).length;
    }

    handleSnakeEscaped(snake) {
      this.ui.showToast(`✨ ${snake.color.toUpperCase()} Snake Escaped!`);
      this.updateGameHUD();

      if (this.getSnakesRemaining() === 0) {
        this.onAllSnakesCleared();
      }
    }

    checkGameConditions() {
      if (this.getSnakesRemaining() === 0) {
        this.onAllSnakesCleared();
        return;
      }

      // Check if any snake died from a trap
      const deadSnake = this.state.snakes.find(s => s.isDead);
      if (deadSnake) {
        this.onLevelFailed('Snake hit a deadly trap!');
        return;
      }

      // Check if active snake has any valid moves
      const activeSnake = this.player.getActiveSnake(this.state.snakes);
      if (activeSnake && !activeSnake.escaped) {
        const head = activeSnake.getHead();
        const neighbors = [
          { dir: 'RIGHT', x: head.x + 1, y: head.y },
          { dir: 'LEFT', x: head.x - 1, y: head.y },
          { dir: 'DOWN', x: head.x, y: head.y + 1 },
          { dir: 'UP', x: head.x, y: head.y - 1 }
        ];

        const hasAnyValidMove = neighbors.some(n => {
          const check = this.collision.isValidMove(
            activeSnake, n.x, n.y,
            this.state.currentLevelData,
            this.state.snakes,
            n.dir
          );
          return check.valid;
        });

        // Check if any other snake can move
        const otherSnakesCanMove = this.state.snakes.some(s => {
          if (s.id === activeSnake.id || s.escaped || s.isDead) return false;
          const h = s.getHead();
          return [
            { dir: 'RIGHT', x: h.x + 1, y: h.y },
            { dir: 'LEFT', x: h.x - 1, y: h.y },
            { dir: 'DOWN', x: h.x, y: h.y + 1 },
            { dir: 'UP', x: h.x, y: h.y - 1 }
          ].some(n => this.collision.isValidMove(s, n.x, n.y, this.state.currentLevelData, this.state.snakes, n.dir).valid);
        });

        if (!hasAnyValidMove && !otherSnakesCanMove && this.state.moves > 2) {
          this.onLevelFailed('All snakes are blocked! Use Undo to rethink your path.');
        }
      }
    }

    onAllSnakesCleared() {
      this.state.gameStatus = 'complete';
      this.stopTimers();
      this.input.setEnabled(false);

      const lvl = this.state.currentLevelData;
      const parMoves = lvl ? lvl.parMoves : 15;
      const parTime = lvl ? lvl.parTime : 45;

      // Calculate Stars (1-3 stars)
      let stars = 1;
      if (this.state.moves <= parMoves && this.state.timerSeconds <= parTime) {
        stars = 3;
      } else if (this.state.moves <= Math.ceil(parMoves * 1.4) && this.state.timerSeconds <= Math.ceil(parTime * 1.4)) {
        stars = 2;
      }

      // Calculate Score (Rule 35)
      const baseScore = 1000;
      const starBonus = stars * 350;
      const collectibleBonus = this.player.score;
      const movePenalty = Math.max(0, (this.state.moves - parMoves) * 15);
      const timePenalty = Math.max(0, (this.state.timerSeconds - parTime) * 3);
      const finalScore = Math.max(200, baseScore + starBonus + collectibleBonus - movePenalty - timePenalty);

      // Save progress to LocalStorage
      const result = this.progress.saveLevelSuccess(
        this.state.currentLevelId,
        this.state.moves,
        parMoves,
        stars,
        finalScore,
        this.state.timerSeconds
      );

      this.audio.playLevelComplete();
      this.animation.triggerConfetti(document.body, 60);

      // Multi-snake or world milestone check
      const isWorldComplete = (this.state.currentLevelId % 10 === 0);
      const modalId = isWorldComplete ? 'modal-cleared' : 'modal-complete';

      setTimeout(() => {
        const starContainer = document.getElementById(isWorldComplete ? 'cleared-stars-row' : 'complete-stars-row');
        this.ui.renderStars(starContainer, stars);

        const lvlLabel = document.getElementById('complete-level-label');
        if (lvlLabel) {
          lvlLabel.textContent = `Level ${this.state.currentLevelId} Cleared!`;
        }

        // Show score breakdown in completion modal
        const scoreEl = document.getElementById('complete-score-value');
        if (scoreEl) {
          scoreEl.textContent = `${finalScore}`;
        }
        const movesEl = document.getElementById('complete-moves-value');
        if (movesEl) {
          movesEl.textContent = `${this.state.moves} (Par: ${parMoves})`;
        }
        const timeEl = document.getElementById('complete-time-value');
        if (timeEl) {
          timeEl.textContent = `${this.state.timerSeconds}s (Par: ${parTime}s)`;
        }

        this.ui.showModal(modalId);
      }, 500);
    }

    onLevelFailed(reason = 'Snake got blocked!') {
      this.state.gameStatus = 'failed';
      this.stopTimers();
      this.input.setEnabled(false);

      const failMsg = document.getElementById('failed-reason-text');
      if (failMsg) {
        failMsg.textContent = reason;
      }

      this.audio.playLevelFailed();
      this.animation.screenShake(document.querySelector('.stone-maze-frame'));

      setTimeout(() => {
        this.ui.showModal('modal-failed');
      }, 600);
    }

    undoMove() {
      if (this.state.gameStatus !== 'playing' && this.state.gameStatus !== 'failed') return;

      const success = this.player.undo(
        this.state.snakes,
        this.state.currentLevelData,
        this.audio,
        this.animation,
        {
          onMoveCountChange: (count) => {
            this.state.moves = count;
            this.updateGameHUD();
          },
          onUndo: () => {
            if (this.state.gameStatus === 'failed') {
              this.state.gameStatus = 'playing';
              this.ui.hideModal('modal-failed');
              this.input.setEnabled(true);
              this.startTimer();
            }
            this.mazeRenderer.clearHintPath();
            this.mazeRenderer.render(this.state.snakes);
          }
        }
      );

      if (!success) {
        this.ui.showToast('No moves to undo');
      }
    }

    resetLevel() {
      this.audio.playReset();
      this.loadLevel(this.state.currentLevelId);
      this.ui.showToast('Level Reset');
    }

    showHint() {
      if (this.state.gameStatus !== 'playing' || this.state.isPaused) return;

      if (this.state.hintsRemaining <= 0) {
        this.ui.showToast('No hints remaining!');
        return;
      }

      const activeSnake = this.player.getActiveSnake(this.state.snakes);
      const hint = this.levelManager.getHint({
        snakes: this.state.snakes,
        activeSnakeId: activeSnake ? activeSnake.id : null,
        walls: this.state.currentLevelData.walls,
        keys: this.state.currentLevelData.keys,
        gates: this.state.currentLevelData.gates,
        switches: this.state.currentLevelData.switches,
        portals: this.state.currentLevelData.portals,
        bridges: this.state.currentLevelData.bridges,
        blocks: this.state.currentLevelData.blocks,
        traps: this.state.currentLevelData.traps,
        grid: this.state.currentLevelData.grid
      });

      if (hint) {
        this.state.hintsRemaining--;
        this.ui.updateHintBadge(this.state.hintsRemaining);
        this.audio.playHint();

        if (hint.type === 'select_snake' && hint.targetSnakeId) {
          this.player.selectSnake(hint.targetSnakeId, this.state.snakes);
        }

        this.mazeRenderer.setHintPath(hint);
        this.mazeRenderer.render(this.state.snakes);

        const hintDesc = document.getElementById('hint-desc-text');
        if (hintDesc) {
          hintDesc.textContent = hint.message || 'Follow the illuminated path!';
        }
        this.ui.showModal('modal-hint');
      } else {
        this.ui.showToast('No clear path found. Try undoing!');
      }
    }

    nextLevel() {
      if (this.state.currentLevelId === 999) {
        this.ui.showScreen('levels');
        return;
      }
      const nextId = Math.min(120, this.state.currentLevelId + 1);
      this.loadLevel(nextId);
    }

    togglePause() {
      if (this.state.gameStatus !== 'playing' && !this.state.isPaused) return;

      this.state.isPaused = !this.state.isPaused;
      this.audio.playClick();

      if (this.state.isPaused) {
        this.ui.showModal('modal-pause');
      } else {
        this.ui.hideModal('modal-pause');
      }
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.Game = Game;
})();
