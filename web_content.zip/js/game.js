// ===== Maré Baixa — núcleo do jogo =====
const G = { mode: 'title', ui: { tab: 'inv', selKey: null, dirty: true, open: false, map: false, markerType: 'agua' } };
const keys = {};
let canvas, ctx, lightC, lctx, mapC, mapX, fogC, fogX, DPR = 1, ZOOM = 1;
const cam = { x: 0, y: 0 };
const CAUSE = { sede: 'sede', fome: 'fome', caranguejo: 'ataque de caranguejo', cobra: 'picada de cobra', veneno: 'veneno', gas: 'gás vulcânico', sangue: 'sanguessugas', ninho: 'ataque de ave', frio: 'frio' };
const WATER_NAME = { rio: 'do rio', nascente: 'da nascente', mar: 'do mar', mangue: 'do mangue' };

// ---------- Criação do mundo ----------
function addNode(type, tx, ty, extra, jit) {
  const i = ty * MW + tx;
  if (tx < 0 || ty < 0 || tx >= MW || ty >= MH || G.nodeAt[i] >= 0) return null;
  const h = hash2(tx, ty, 41);
  const j = jit === false ? 0 : 1;
  const n = Object.assign({ type, tx, ty, x: tx * TS + TS / 2 + (hash2(tx, ty, 5) - 0.5) * 10 * j, y: ty * TS + TS / 2 + (hash2(tx, ty, 9) - 0.5) * 10 * j, h, dep: false }, extra || {});
  n.id = G.nodes.length; G.nodes.push(n); G.nodeAt[i] = n.id;
  return n;
}
function removeNode(n) { if (G.nodeAt[n.ty * MW + n.tx] === n.id) G.nodeAt[n.ty * MW + n.tx] = -1; n.gone = true; }
function nodeAtTile(tx, ty) { if (tx < 0 || ty < 0 || tx >= MW || ty >= MH) return null; const k = G.nodeAt[ty * MW + tx]; if (k < 0) return null; const n = G.nodes[k]; return n && !n.gone ? n : null; }

function populate(seed) {
  const W = G.W, rng = mulberry32(seed + 99);
  const [sx, sy] = W.nearest(0.5, 0.86, (i, x, y) => W.biome[i] === 1 && W.type[i] === T.SAND && W.cd[i] >= 2);
  G.start = [sx, sy];
  const TABLE = {
    '1_2': [['coqueiro', 0.025], ['graveto', 0.016], ['pedra_solta', 0.013], ['conchas', 0.015], ['arbusto', 0.007], ['toca', 0.004]],
    '1_3': [['poca', 0.06], ['conchas', 0.02], ['toca', 0.01]],
    '2_4': [['arvore', 0.075], ['samambaia', 0.03], ['graveto', 0.016], ['frutas', 0.012], ['cipoal', 0.014], ['pedra_solta', 0.01], ['rocha', 0.006], ['arbusto', 0.004]],
    '3_5': [['raizes', 0.04], ['argila', 0.035], ['arvore_mangue', 0.045], ['cipoal', 0.012], ['toca', 0.006]],
    '3_6': [['arvore_mangue', 0.03], ['raizes', 0.02]],
    '4_7': [['rocha', 0.035], ['arbusto', 0.015], ['erva', 0.015], ['ninho', 0.006], ['pedra_solta', 0.016], ['graveto', 0.006], ['samambaia', 0.006]],
    '4_8': [['silex', 0.14], ['pedra_solta', 0.03]],
    '5_9': [['rocha_vulc', 0.04], ['enxofre', 0.014], ['obsidiana', 0.008]],
  };
  for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) {
    const i = y * MW + x; if (!W.land[i]) continue;
    if (Math.abs(x - sx) < 3 && Math.abs(y - sy) < 3) continue;
    const tb = TABLE[W.biome[i] + '_' + W.type[i]]; if (!tb) continue;
    let r = rng();
    for (const [tp, p] of tb) { if (r < p) { const e = tp === 'coqueiro' ? { coco: 2, cocoT: 0 } : null; addNode(tp, x, y, e); break; } r -= p; }
  }
  const ensure = (tp, pred, min) => {
    let c = G.nodes.filter((n) => n.type === tp).length, tries = 0;
    while (c < min && tries++ < 5000) {
      const x = Math.floor(rng() * MW), y = Math.floor(rng() * MH), i = y * MW + x;
      if (W.land[i] && pred(i, x, y) && addNode(tp, x, y)) c++;
    }
  };
  ensure('silex', (i) => W.type[i] === T.CAVE, 9);
  ensure('obsidiana', (i) => W.type[i] === T.VOLC, 7);
  ensure('enxofre', (i) => W.type[i] === T.VOLC, 9);
  ensure('argila', (i) => W.type[i] === T.MUD, 12);
  ensure('cipoal', (i) => W.biome[i] === 2, 16);
  ensure('ninho', (i) => W.biome[i] === 4, 5);
  const placeNear = (tp, fx, fy, pred, extra) => {
    const [x, y] = W.nearest(fx, fy, (i, xx, yy) => W.land[i] && pred(i) && !nodeAtTile(xx, yy) && !isWaterType(W.type[i]));
    return addNode(tp, x, y, extra);
  };
  // naufrágio e início
  const [wx, wy] = W.nearest((sx + 3) / MW, (sy + 4) / MH, (i) => W.type[i] === T.SHALLOW);
  addNode('naufragio', wx, wy, null, false);
  addNode('bau_navio', sx + 2, sy, null, false) || placeNear('bau_navio', (sx + 2) / MW, sy / MH, () => true);
  addNode('pagina', sx - 2, sy + 1, { page: 0 }, false) || placeNear('pagina', (sx - 2) / MW, sy / MH, () => true, { page: 0 });
  addNode('coqueiro', sx + 4, sy - 2, { coco: 2, cocoT: 0 });
  addNode('graveto', sx - 1, sy - 2); addNode('pedra_solta', sx + 1, sy + 2); addNode('arbusto', sx - 3, sy - 1);
  // páginas
  const sp = W.spring;
  placeNear('pagina', 0.47, 0.7, (i) => W.biome[i] === 2, { page: 1 });
  placeNear('pagina', (sp[0] + 2) / MW, (sp[1] + 1) / MH, (i) => W.biome[i] === 2, { page: 2 });
  placeNear('pagina', 0.84, 0.5, (i) => W.biome[i] === 3, { page: 3 });
  placeNear('pagina', W.cave[0] / MW, W.cave[1] / MH, (i) => W.type[i] === T.CAVE, { page: 4 });
  const m1 = placeNear('mirante', 0.38, 0.22, (i) => W.biome[i] === 4);
  placeNear('mirante', 0.19, 0.44, (i) => W.biome[i] === 4);
  placeNear('mirante', 0.62, 0.52, (i) => W.biome[i] === 2);
  if (m1) placeNear('pagina', (m1.tx + 1) / MW, (m1.ty + 1) / MH, (i) => W.biome[i] === 4, { page: 5 });
  placeNear('pagina', 0.55, 0.33, (i) => W.biome[i] === 5, { page: 6 });
  placeNear('pagina', VX, VY + 0.07, (i) => W.biome[i] === 5 && W.type[i] === T.VOLC, { page: 7 });
  for (const [hx, hy] of W.hot) addNode('fonte_termal', hx, hy, null, false);
  // destroços iniciais
  for (let k = 0; k < 6; k++) spawnOnBeach('caixa', 40);
  // cobras
  G.enemies = [];
  let s = 0, tries = 0;
  while (s < 16 && tries++ < 4000) {
    const x = Math.floor(rng() * MW), y = Math.floor(rng() * MH), i = y * MW + x;
    if (W.biome[i] === 2 && W.type[i] === T.GRASS && W.cd[i] > 6 && Math.hypot(x - sx, y - sy) > 16 && !nodeAtTile(x, y)) {
      G.enemies.push({ kind: 'snake', x: x * TS + 16, y: y * TS + 16, hp: 3, cd: 0, hurt: 0 }); s++;
    }
  }
}
function spawnOnBeach(tp, maxDist) {
  const W = G.W, p = G.player, [sx, sy] = G.start;
  for (let k = 0; k < 200; k++) {
    const x = sx + rint(-maxDist, maxDist), y = sy + rint(-12, 10), i = y * MW + x;
    if (x < 0 || y < 0 || x >= MW || y >= MH) continue;
    const okType = tp === 'madeira_flut' ? W.type[i] === T.TIDE : W.type[i] === T.SAND;
    if (W.biome[i] !== 1 || !okType || nodeAtTile(x, y)) continue;
    if (p && Math.hypot(x * TS - p.x, y * TS - p.y) < 260) continue;
    return addNode(tp, x, y);
  }
  return null;
}

function newGame() {
  const seed = 20261121;
  G.W = genWorld(seed);
  G.t = 150; G.nodes = []; G.nodeAt = new Int32Array(MW * MH).fill(-1);
  G.particles = []; G.toasts = []; G.markers = []; G.pages = new Set(); G.seen = new Set(); G.known = new Set();
  G.revealed = new Uint8Array(MW * MH);
  G.inv = { hot: Array(6).fill(null), pocket: Array(24).fill(null), hotN: 4, pocketN: 8, ups: {}, bonus: 0 };
  G.sel = 0; G.craft = null; G.gather = null; G.weather = 'limpo'; G.day = 1; G.spawn = null; G.chest = null;
  G.lastLow = null; G.lastPhase = null; G.timers = { reveal: 0, respawn: 0, leech: 0, gasMsg: 0, rain: 0 };
  G.cutCount = {};
  G.tel = { session: 0, ev: {}, deaths: [], crafted: [], biomes: {}, invOpen: 0, dropped: 0, nights: [] };
  G.player = { x: 0, y: 0, face: { x: 0, y: 1 }, hp: 100, fome: 85, sede: 70, energia: 90, eff: {}, torch: 0, swing: 0, atkCd: 0, moving: false, hurtFlash: 0, lastCause: null, warm: false, cold: false };
  populate(seed);
  G.player.x = G.start[0] * TS + 16; G.player.y = G.start[1] * TS + 16;
  cam.x = G.player.x; cam.y = G.player.y;
  buildMapCanvas();
  G.ui.selKey = null; G.ui.dirty = true;
  G.lastLow = isLowTide();
}

// ---------- Tempo ----------
function dayInfo(t) {
  const L = CONFIG.duracao_dia, d = t % L, day = Math.floor(t / L) + 1;
  let phase, dark, hour;
  if (d < 120) { phase = 'amanhecer'; dark = 0.72 * (1 - d / 120); hour = 5 + (d / 120) * 1.5; }
  else if (d < 720) { phase = 'dia'; dark = 0; hour = 6.5 + ((d - 120) / 600) * 11; }
  else if (d < 840) { phase = 'entardecer'; dark = 0.72 * ((d - 720) / 120); hour = 17.5 + ((d - 720) / 120) * 1.5; }
  else { phase = 'noite'; dark = 0.74; hour = 19 + ((d - 840) / 360) * 10; }
  hour %= 24;
  return { day, phase, dark, hour, midday: d >= 330 && d <= 510, d };
}
function isLowTide() { return G.t % CONFIG.periodo_mare < CONFIG.mare_baixa; }
function elapsed() { return G.tel.session; }

// ---------- Inventário ----------
function slotRef(key) {
  const [k, i] = key.split('-'); const idx = +i;
  const arr = k === 'h' ? G.inv.hot : k === 'p' ? G.inv.pocket : G.chest ? G.chest.items : null;
  return arr ? { arr, i: idx, s: arr[idx], key } : null;
}
function invSlots() {
  const out = [];
  for (let i = 0; i < G.inv.hotN; i++) out.push({ arr: G.inv.hot, i });
  for (let i = 0; i < G.inv.pocketN; i++) out.push({ arr: G.inv.pocket, i });
  return out;
}
function weight() { let w = 0; for (const r of invSlots()) { const s = r.arr[r.i]; if (s) w += ITEMS[s.id].w * s.n; } return w; }
function cargaMax() { return CONFIG.carga_maxima + G.inv.bonus; }
function cargaLim() { return CONFIG.carga_limite + G.inv.bonus; }
function countItem(id) { let c = 0; for (const r of invSlots()) { const s = r.arr[r.i]; if (s && s.id === id) c += s.n; } return c; }
function hasItem(id) { return countItem(id) > 0; }
function newSlot(id, n) {
  const it = ITEMS[id], s = { id, n };
  if (it.tool) s.dur = it.tool.dur;
  if (it.cont) { s.doses = 0; s.clean = true; }
  if (it.spoil) s.spoil = G.t + it.spoil;
  return s;
}
function addItem(id, n, slotData) {
  const it = ITEMS[id]; if (!it) return n;
  const room = Math.floor((cargaLim() - weight()) / it.w + 1e-6);
  let left = Math.min(n, Math.max(0, room)); const refused = n - left;
  const slots = invSlots();
  if (it.st > 1 && !slotData) for (const r of slots) {
    const s = r.arr[r.i]; if (left <= 0) break;
    if (s && s.id === id && s.n < it.st && !s.dried) { const a = Math.min(left, it.st - s.n); s.n += a; left -= a; if (it.spoil) s.spoil = Math.min(s.spoil, G.t + it.spoil); }
  }
  const preferHot = !!(it.tool || it.food || it.cont || it.light || it.heal || id === 'sinalizador');
  const ordered = preferHot ? slots : slots.slice(G.inv.hotN).concat(slots.slice(0, G.inv.hotN));
  for (const r of ordered) {
    if (left <= 0) break;
    if (!r.arr[r.i]) { const c = Math.min(left, it.st); r.arr[r.i] = slotData ? Object.assign({}, slotData, { n: c }) : newSlot(id, c); left -= c; }
  }
  G.seen.add(id); G.ui.dirty = true;
  return left + refused;
}
function removeItem(id, n) {
  const slots = invSlots().slice(G.inv.hotN).concat(invSlots().slice(0, G.inv.hotN));
  for (const r of slots) {
    const s = r.arr[r.i]; if (!s || s.id !== id || n <= 0) continue;
    const a = Math.min(n, s.n); s.n -= a; n -= a; if (s.n <= 0) r.arr[r.i] = null;
  }
  G.ui.dirty = true;
}
function giveItems(list, quiet) {
  const got = [];
  for (const [id, n] of list) {
    const left = addItem(id, n);
    if (n - left > 0) got.push('+' + (n - left) + ' ' + ITEMS[id].n);
    if (left > 0) { dropPile([{ id, n: left }]); G.tel.dropped += left; toast('Sem espaço ou peso demais: ' + left + ' ' + ITEMS[id].n + ' ficou no chão', 'warn'); }
  }
  if (got.length && !quiet) toast(got.join('  '), 'good');
  checkRecipes();
}
function dropPile(slots) {
  const p = G.player, tx = Math.floor(p.x / TS), ty = Math.floor(p.y / TS);
  for (let r = 0; r < 4; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    const n = nodeAtTile(tx + dx, ty + dy);
    if (n && n.type === 'pilha') { for (const s of slots) n.items.push(Object.assign({}, s)); return; }
    if (!n && G.W.land[(ty + dy) * MW + tx + dx]) { addNode('pilha', tx + dx, ty + dy, { items: slots.map((s) => Object.assign({}, s)) }); return; }
  }
}
function selectedSlot() { return G.sel < G.inv.hotN ? G.inv.hot[G.sel] : null; }
function bestTool(cls) {
  let best = null;
  for (let i = 0; i < G.inv.hotN; i++) {
    const s = G.inv.hot[i]; if (!s) continue; const tl = ITEMS[s.id].tool;
    if (tl && tl.c === cls && (!best || tl.t > best.tier)) best = { s, i, tier: tl.t, name: ITEMS[s.id].n };
  }
  return best;
}
function wearTool(tool) {
  if (!tool) return;
  tool.s.dur -= 1;
  if (tool.s.dur <= 0) { G.inv.hot[tool.i] = null; toast(tool.name + ' quebrou', 'warn'); AudioSys.sfx('error'); }
  G.ui.dirty = true;
}
function hasOpener() { return hasItem('pedrinha') || invSlots().some((r) => r.arr[r.i] && ITEMS[r.arr[r.i].id].tool); }

// ---------- Receitas ----------
function checkRecipes(initial) {
  for (const r of RECIPES) {
    if (G.known.has(r.id)) continue;
    let ok;
    if (r.special === 'ferver') ok = G.seen.has('pote') || G.seen.has('cantil');
    else ok = Object.keys(r.ing).every((id) => G.seen.has(id));
    if (ok) { G.known.add(r.id); if (!initial) toast('Receita descoberta: ' + recipeName(r), 'info'); G.ui.dirty = true; }
  }
}
function recipeName(r) { return r.name || (r.out ? ITEMS[r.out].n : NODES[r.place].name); }
function nearStation(st) {
  if (!st) return true;
  const p = G.player, tx = Math.floor(p.x / TS), ty = Math.floor(p.y / TS);
  for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) { const n = nodeAtTile(tx + dx, ty + dy); if (n && n.type === st && dist(n.x, n.y, p.x, p.y) < 110) return true; }
  return false;
}
function dirtyBoilables() { return invSlots().map((r) => r.arr[r.i]).filter((s) => s && ITEMS[s.id].boil && s.doses > 0 && !s.clean); }
function craftState(r) {
  if (!G.known.has(r.id)) return { ok: false, why: 'unknown' };
  if (r.up && G.inv.ups[r.up]) return { ok: false, why: 'Já equipado' };
  if (!nearStation(r.st)) return { ok: false, why: 'Requer ' + STATION_NAME[r.st] + ' por perto' };
  for (const [id, n] of Object.entries(r.ing)) if (countItem(id) < n) return { ok: false, why: 'Faltam ingredientes' };
  if (r.special === 'ferver' && !dirtyBoilables().length) return { ok: false, why: 'Encha um pote ou cantil com água não tratada' };
  if (G.craft) return { ok: false, why: 'Já fabricando' };
  return { ok: true };
}
function startCraft(id) {
  const r = RECIPES.find((x) => x.id === id); if (!r) return;
  const st = craftState(r); if (!st.ok) { toast(st.why === 'unknown' ? 'Receita desconhecida' : st.why, 'warn'); AudioSys.sfx('error'); return; }
  for (const [iid, n] of Object.entries(r.ing)) removeItem(iid, n);
  G.craft = { r, t: 0 };
  toast('Fabricando: ' + recipeName(r) + ' (' + r.t + ' s)', 'info');
  G.ui.dirty = true;
}
function finishCraft() {
  const r = G.craft.r; G.craft = null;
  AudioSys.sfx('craft');
  if (r.out) giveItems([[r.out, r.n]], true);
  if (r.place) placeStructure(r.place);
  if (r.up) applyUpgrade(r.up);
  if (r.special === 'ferver') { for (const s of dirtyBoilables()) s.clean = true; toast('Água fervida: agora está potável', 'good'); }
  else toast('Pronto: ' + recipeName(r), 'good');
  const tl = r.out && ITEMS[r.out].tool;
  if (tl) markEv('primeira_ferramenta', 'Primeira ferramenta');
  if (r.place === 'fogueira') markEv('primeira_fogueira', 'Primeira fogueira');
  if (r.place === 'bancada') markEv('tier2', 'Bancada (tier 2)');
  if (r.place === 'forno') markEv('tier3', 'Forno (tier 3)');
  if (r.id.startsWith('cozinhar')) markEv('primeira_comida_cozida', 'Primeira comida cozida');
  G.tel.crafted.push({ id: r.id, n: recipeName(r), t: elapsed() });
  G.ui.dirty = true; checkRecipes();
}
function markEv(k, label) { if (G.tel.ev[k] == null) G.tel.ev[k] = { t: elapsed(), label }; }
function applyUpgrade(u) {
  G.inv.ups[u] = true;
  if (u === 'cinto') G.inv.hotN = 6;
  if (u === 'bolsa') G.inv.pocketN = Math.max(G.inv.pocketN, 16);
  if (u === 'mochila') { G.inv.pocketN = 24; G.inv.bonus = 5; }
  toast(UPGRADES[u].n + ' equipado: ' + UPGRADES[u].d, 'good');
}
function placeStructure(type) {
  const p = G.player, W = G.W;
  const fx = p.x + p.face.x * 40, fy = p.y + p.face.y * 40;
  const cx = Math.floor(fx / TS), cy = Math.floor(fy / TS);
  for (let r = 0; r < 5; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    const tx = cx + dx, ty = cy + dy, i = ty * MW + tx;
    if (tx < 0 || ty < 0 || tx >= MW || ty >= MH) continue;
    if (!W.land[i] || isWaterType(W.type[i]) || W.type[i] === T.TIDE || nodeAtTile(tx, ty)) continue;
    if (dist(tx * TS + 16, ty * TS + 16, p.x, p.y) < 26) continue;
    const extra = { struct: true };
    if (type === 'coletor') extra.water = 0;
    if (type === 'bau') extra.items = Array(24).fill(null);
    const n = addNode(type, tx, ty, extra, false);
    if (type === 'cama') { G.spawn = { x: n.x, y: n.y + 20 }; toast('Ponto de retorno definido na cama', 'info'); }
    return n;
  }
  toast('Sem espaço para construir aqui', 'warn');
}

// ---------- Uso de itens ----------
function useSlot(ref) {
  const s = ref.arr[ref.i]; if (!s) return;
  const it = ITEMS[s.id], p = G.player;
  const consume = () => { s.n -= 1; if (s.n <= 0) ref.arr[ref.i] = null; G.ui.dirty = true; };
  if (s.id === 'estragado') { toast('Não dá para comer isso', 'warn'); return; }
  if (it.food) {
    const f = it.food;
    if (f.open && !hasOpener()) { toast('Precisa de uma pedra pequena para abrir o coco', 'warn'); AudioSys.sfx('error'); return; }
    p.fome = Math.min(100, p.fome + f.f); p.sede = Math.min(100, p.sede + (f.s || 0)); p.energia = Math.min(100, p.energia + (f.e || 0));
    consume(); AudioSys.sfx('eat');
    let msg = 'Comeu ' + it.n + ' (+' + f.f + ' fome' + (f.s ? ', +' + f.s + ' sede' : '') + ')';
    if ((f.raw && chance(f.raw)) || (f.tox && chance(f.tox))) { sick(); msg += '. Algo não caiu bem...'; }
    toast(msg, 'good');
    if (s.id === 'coco') giveItems([['casca_coco', 1]], true);
    markEv('primeira_comida', 'Primeira refeição');
    return;
  }
  if (it.heal) { p.hp = Math.min(100, p.hp + it.heal); consume(); toast('+' + it.heal + ' vida', 'good'); AudioSys.sfx('soft'); return; }
  if (it.light) { p.torch = it.light; consume(); toast('Tocha acesa (' + Math.round(it.light / 60) + ' min)', 'info'); AudioSys.sfx('soft'); markEv('primeira_tocha', 'Primeira tocha'); return; }
  if (it.cont) {
    if (!s.doses) { toast(it.n + ' está vazio. Encha num rio, nascente ou coletor', 'warn'); return; }
    s.doses -= 1;
    if (s.clean) { p.sede = Math.min(100, p.sede + 25); toast('Bebeu água limpa (+25 sede)', 'good'); }
    else { p.sede = Math.min(100, p.sede + 15); toast('Bebeu água não tratada (+15 sede)', 'warn'); if (chance(CONFIG.chance_indisposicao)) sick(); }
    if (s.doses <= 0) s.clean = true;
    AudioSys.sfx('drink'); G.ui.dirty = true; return;
  }
  if (s.id === 'sinalizador') {
    if (G.W.biome[tileIdx(p.x, p.y)] === B.PRAIA) { consume(); win(); }
    else toast('Use o sinalizador na praia, onde o resgate pode ver', 'warn');
    return;
  }
  if (it.tool) { toast(it.n + ': fica na barra rápida e é usado automaticamente', 'info'); return; }
  toast(it.n + ': material de fabricação', 'info');
}
function sick() {
  const p = G.player; p.fome = Math.max(0, p.fome - 20); p.eff.indisp = 180;
  toast('Indisposição: −20 fome e sem regenerar vida por 3 min', 'bad'); AudioSys.sfx('hurt');
}
function tileIdx(x, y) { return clamp(Math.floor(y / TS), 0, MH - 1) * MW + clamp(Math.floor(x / TS), 0, MW - 1); }
function tileTypeAt(x, y) { return G.W.type[tileIdx(x, y)]; }

// ---------- Interação ----------
function findTarget() {
  const p = G.player, ptx = Math.floor(p.x / TS), pty = Math.floor(p.y / TS), low = isLowTide();
  let best = null, bs = 1e9;
  for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
    const n = nodeAtTile(ptx + dx, pty + dy); if (!n) continue;
    const d = NODES[n.type];
    if (d.deco) continue;
    if (n.dep && n.type !== 'coqueiro') continue;
    if (d.lowTide && !low) continue;
    const dd = dist(n.x, n.y, p.x, p.y - 4);
    const reach = 24 + (d.r || 10);
    if (dd > reach) continue;
    const dot = ((n.x - p.x) * p.face.x + (n.y - p.y) * p.face.y) / (dd || 1);
    const sc = dd - dot * 12;
    if (sc < bs) { bs = sc; best = { kind: 'node', n }; }
  }
  if (best) return best;
  // água
  const pts = [[p.face.x * 22, p.face.y * 22], [0, 0], [16, 0], [-16, 0], [0, 16], [0, -16]];
  for (const [ox, oy] of pts) {
    const tt = tileTypeAt(p.x + ox, p.y + oy);
    let wt = null;
    if (tt === T.RIVER) wt = 'rio'; else if (tt === T.SPRING) wt = 'nascente'; else if (tt === T.MWATER) wt = 'mangue';
    else if (tt === T.SHALLOW || tt === T.DEEP || (tt === T.TIDE && !low)) wt = 'mar';
    if (wt) return { kind: 'water', wt };
  }
  return null;
}
function selContainer() { const s = selectedSlot(); return s && ITEMS[s.id].cont ? s : null; }
function getAction(tg) {
  const p = G.player;
  if (!tg) return null;
  if (tg.kind === 'water') {
    const c = selContainer();
    if (c) {
      if (tg.wt === 'mar') return { label: 'Água salgada não serve para encher ' + ITEMS[c.id].n.toLowerCase(), can: false };
      return { label: 'Encher ' + ITEMS[c.id].n.toLowerCase() + ' com água ' + WATER_NAME[tg.wt], time: 1.5, can: true, sound: 'drink', exec: () => {
        const clean = tg.wt === 'nascente';
        c.clean = c.doses > 0 ? c.clean && clean : clean; c.doses = ITEMS[c.id].cont; G.ui.dirty = true;
        toast(ITEMS[c.id].n + ' cheio (' + c.doses + ' doses, ' + (c.clean ? 'água limpa' : 'precisa ferver') + ')', c.clean ? 'good' : 'warn');
      } };
    }
    if (tg.wt === 'mar') return { label: 'Beber água do mar', time: 1, can: true, exec: () => { p.sede = Math.max(0, p.sede - 10); toast('A água salgada piorou a sede (−10)', 'bad'); AudioSys.sfx('hurt'); } };
    return { label: 'Beber água ' + WATER_NAME[tg.wt], time: 2, can: true, exec: () => {
      AudioSys.sfx('drink');
      if (tg.wt === 'nascente') { p.sede = Math.min(100, p.sede + 25); toast('Água limpa da nascente (+25 sede)', 'good'); }
      else { p.sede = Math.min(100, p.sede + 15); toast('Bebeu água ' + WATER_NAME[tg.wt] + ' (+15 sede)', 'warn'); if (chance(CONFIG.chance_indisposicao)) sick(); }
      markEv('primeira_agua', 'Primeira água');
    } };
  }
  const n = tg.n, d = NODES[n.type];
  if (d.struct) {
    switch (n.type) {
      case 'fogueira': case 'bancada': case 'forno': return { label: 'Usar ' + d.name.toLowerCase() + ' (abre a fabricação)', time: 0, can: true, exec: () => openPanel('craft') };
      case 'cama': {
        const ph = dayInfo(G.t).phase;
        if (ph === 'noite' || ph === 'entardecer') return { label: 'Dormir até o amanhecer', time: 0, can: true, exec: sleep };
        return { label: 'Definir ponto de retorno (só dá para dormir ao entardecer)', time: 0, can: true, exec: () => { G.spawn = { x: n.x, y: n.y + 20 }; toast('Ponto de retorno definido', 'info'); } };
      }
      case 'abrigo': return { label: 'Abrigo: protege do frio e da chuva por perto', can: false };
      case 'coletor': {
        const c = selContainer();
        if (!n.water) return { label: 'Coletor de chuva vazio: espere chover', can: false };
        if (!c) return { label: 'Coletor com ' + n.water + ' doses: selecione um recipiente', can: false };
        return { label: 'Pegar água limpa do coletor (' + n.water + ' doses)', time: 1, can: true, exec: () => {
          const cap = ITEMS[c.id].cont, take = Math.min(cap - (c.clean ? c.doses : 0), n.water);
          if (!c.clean) c.doses = 0; c.doses += take; c.clean = true; n.water -= take; G.ui.dirty = true; toast('+' + take + ' doses de água limpa', 'good'); AudioSys.sfx('drink');
        } };
      }
      case 'secador': return { label: 'Secar comida cozida (dura 5 dias)', time: 3, can: true, exec: dryFood };
      case 'bau': return { label: 'Abrir baú', time: 0, can: true, exec: () => { G.chest = n; openPanel('inv'); } };
    }
  }
  if (n.type === 'pilha') return { label: 'Recolher itens do chão', time: 0.6, can: true, exec: () => pickPile(n) };
  if (n.type === 'pagina') return { label: 'Ler página de diário', time: 0.5, can: true, exec: () => readPage(n) };
  if (n.type === 'mirante') return { label: 'Escalar o mirante', time: 2, can: true, exec: () => { reveal(n.tx, n.ty, 24); toast('Do alto, você enxerga boa parte da ilha (mapa atualizado)', 'info'); AudioSys.sfx('page'); markEv('mirante', 'Primeiro mirante'); } };
  if (n.type === 'fonte_termal') return { label: 'Banhar-se na fonte termal', time: 4, can: true, exec: () => { p.hp = Math.min(100, p.hp + 15); p.energia = Math.min(100, p.energia + 25); toast('A água quente renova suas forças (+15 vida, +25 energia)', 'good'); } };
  if (n.type === 'coqueiro') {
    if (n.dep) return null;
    if (n.coco > 0) return { label: 'Sacudir coqueiro (' + n.coco + ' cocos)', time: 3, can: true, sound: 'soft', exec: () => { n.coco--; n.cocoT = G.t + 300; giveItems([['coco', 1]]); } };
    const tool = bestTool('machado');
    if (!tool) return { label: 'Coqueiro sem cocos. Um machado na barra rápida o derruba', can: false };
    return { label: 'Derrubar coqueiro (' + tool.name + ')', time: [0, 8, 5, 3][tool.tier], can: true, sound: 'chop', exec: () => { giveItems([['tora', 3]]); wearTool(tool); p.energia -= 1.5; n.dep = true; n.respawnAt = G.t + 1200; } };
  }
  // genérico
  let tool = null, time = d.time;
  if (d.tool) {
    tool = bestTool(d.tool);
    const nm = { machado: 'um machado', picareta: 'uma picareta', faca: 'uma faca', lanca: 'uma lança' }[d.tool];
    if (!tool) return { label: d.name + ': precisa de ' + nm + ' na barra rápida', can: false };
    if (tool.tier < (d.minTier || 1)) return { label: d.name + ': dura demais, precisa de ' + nm + ' de sílex ou melhor', can: false };
    time = d.times[tool.tier] || d.times[Math.max(...Object.keys(d.times).map(Number))];
  }
  let spear = null;
  if (n.type === 'toca') { spear = bestTool('lanca'); if (spear) time = d.spearTime; }
  const sound = d.tool === 'machado' ? 'chop' : d.tool === 'picareta' ? 'stone' : 'soft';
  return { label: d.verb + ' · ' + d.name + (tool ? ' (' + tool.name + ')' : ''), time, can: true, sound, exec: () => {
    giveItems(d.give(tool ? tool.tier : 1));
    if (tool) wearTool(tool); if (spear) wearTool(spear);
    p.energia = Math.max(0, p.energia - (tool ? 1.5 : 1));
    burst(n.x, n.y - 8, d.tool === 'picareta' ? '#9a988f' : d.tool === 'machado' ? '#c9925a' : '#7fb069', 8);
    if (d.bird) { damage(6, 'ninho'); toast('Uma ave mergulha para defender o ninho', 'bad'); }
    if (d.once) removeNode(n);
    else {
      let mult = 1;
      if (d.deplete === 'toco') {
        const ck = G.day + ':' + (n.tx >> 4) + ':' + (n.ty >> 4); G.cutCount[ck] = (G.cutCount[ck] || 0) + 1;
        if (G.cutCount[ck] > 8) { mult = 1.5; if (G.cutCount[ck] === 9) toast('Muitas árvores cortadas aqui: a mata vai demorar mais para voltar', 'warn'); }
      }
      n.dep = true; n.respawnAt = G.t + d.respawn * mult;
    }
  } };
}
function pickPile(n) {
  const rest = [];
  for (const s of n.items) {
    const left = addItem(s.id, s.n, ITEMS[s.id].st === 1 || s.spoil || s.doses != null ? s : null);
    if (left > 0) rest.push(Object.assign({}, s, { n: left }));
  }
  n.items = rest; AudioSys.sfx('pickup');
  if (!rest.length) removeNode(n); else toast('Não coube tudo', 'warn');
  checkRecipes();
}
function readPage(n) {
  G.pages.add(n.page); removeNode(n); AudioSys.sfx('page');
  markEv('pagina_' + n.page, 'Página ' + (n.page + 1));
  showPage(n.page);
}
function dryFood() {
  let c = 0;
  for (const r of invSlots()) { const s = r.arr[r.i]; if (s && ITEMS[s.id].food && /cozido|assad/.test(s.id) && !s.dried) { s.dried = true; s.spoil = G.t + 6000; c += s.n; } }
  toast(c ? c + ' porções secas: agora duram 5 dias' : 'Nenhuma comida cozida para secar', c ? 'good' : 'warn'); G.ui.dirty = true;
}
function sleep() {
  const p = G.player, L = CONFIG.duracao_dia;
  G.t = Math.ceil(G.t / L) * L + 5;
  p.fome = Math.max(0, p.fome - 15); p.sede = Math.max(0, p.sede - 20); p.energia = 100;
  const bed = G.nodes.find((n) => n && !n.gone && n.type === 'cama' && dist(n.x, n.y, p.x, p.y) < 80);
  if (bed) G.spawn = { x: bed.x, y: bed.y + 20 };
  G.enemies = G.enemies.filter((e) => e.kind !== 'crab');
  fadeFlash(); toast('Você dormiu até o amanhecer. Energia restaurada, mas acordou com fome e sede', 'info');
  markEv('primeira_noite_dormida', 'Primeira noite dormida');
}
function damage(a, cause) {
  const p = G.player; p.hp -= a; p.hurtFlash = 0.35; p.lastCause = cause; AudioSys.sfx('hurt');
}
function die(cause) {
  const p = G.player;
  G.tel.deaths.push({ cause, t: elapsed() });
  if (G.spawn) {
    for (let i = 0; i < G.inv.pocket.length; i++) G.inv.pocket[i] = null;
    p.x = G.spawn.x; p.y = G.spawn.y; p.hp = 60; p.fome = Math.max(p.fome, 50); p.sede = Math.max(p.sede, 50); p.energia = 60; p.eff = {};
    G.gather = null; G.ui.dirty = true; fadeFlash();
    toast('Você desmaiou (' + CAUSE[cause] + ') e acordou na cama. Perdeu o conteúdo dos bolsos', 'bad');
  } else {
    G.mode = 'dead'; showEnd(false, cause);
  }
}
function win() { G.mode = 'won'; AudioSys.sfx('win'); markEv('resgate', 'Resgate'); showEnd(true); }

// ---------- Combate ----------
function attack() {
  const p = G.player; if (p.atkCd > 0 || G.mode !== 'play') return;
  p.atkCd = 0.5; p.swing = 0.35; AudioSys.sfx('swing');
  const sel = selectedSlot(); let dmg = 1, tool = null;
  if (sel && ITEMS[sel.id].tool) { dmg = ITEMS[sel.id].tool.dmg; tool = { s: sel, i: G.sel, name: ITEMS[sel.id].n }; }
  else { const l = bestTool('lanca'); if (l) { dmg = ITEMS[l.s.id].tool.dmg; tool = l; } }
  for (const e of G.enemies) {
    const dx = e.x - p.x, dy = e.y - (p.y - 6), d = Math.hypot(dx, dy);
    if (d > 40) continue;
    if ((dx * p.face.x + dy * p.face.y) / (d || 1) < 0.1 && d > 14) continue;
    e.hp -= dmg; e.hurt = 0.15; e.x += (dx / (d || 1)) * 10; e.y += (dy / (d || 1)) * 10;
    if (tool) wearTool(tool);
    if (e.hp <= 0) {
      e.dead = true;
      if (e.kind === 'crab') { giveItems([['carne_crab', 1]]); }
      else toast('A cobra foi afastada', 'info');
      burst(e.x, e.y, '#d0482a', 10);
    }
    break;
  }
  G.enemies = G.enemies.filter((e) => !e.dead);
}

// ---------- Mapa e névoa ----------
function buildMapCanvas() {
  mapC = document.createElement('canvas'); mapC.width = MW; mapC.height = MH; mapX = mapC.getContext('2d');
  const img = mapX.createImageData(MW, MH);
  for (let i = 0; i < MW * MH; i++) {
    let col = TILE_COLOR[G.W.type[i]];
    const nnum = parseInt(col.slice(1), 16);
    img.data[i * 4] = (nnum >> 16) & 255; img.data[i * 4 + 1] = (nnum >> 8) & 255; img.data[i * 4 + 2] = nnum & 255; img.data[i * 4 + 3] = 255;
  }
  mapX.putImageData(img, 0, 0);
  fogC = document.createElement('canvas'); fogC.width = MW; fogC.height = MH; fogX = fogC.getContext('2d');
  fogX.fillStyle = '#1b2430'; fogX.fillRect(0, 0, MW, MH);
  // tile colors cache
  G.tileCol = new Array(MW * MH); G.tideLow = new Array(MW * MH); G.tideHigh = new Array(MW * MH); G.shore = new Uint8Array(MW * MH);
  for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) {
    const i = y * MW + x, tt = G.W.type[i], v = (G.W.vari[i] - 0.5) * 0.07;
    G.tileCol[i] = shade(TILE_COLOR[tt], v);
    if (tt === T.TIDE) { G.tideLow[i] = shade('#c9b07a', v); G.tideHigh[i] = shade('#3a9ab0', v); }
    if ((tt === T.SHALLOW) && [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([a, b]) => G.W.land[(y + b) * MW + x + a])) G.shore[i] = 1;
  }
}
function reveal(cx, cy, r) {
  for (let y = cy - r; y <= cy + r; y++) for (let x = cx - r; x <= cx + r; x++) {
    if (x < 0 || y < 0 || x >= MW || y >= MH) continue;
    const i = y * MW + x; if (G.revealed[i]) continue;
    if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) { G.revealed[i] = 1; fogX.clearRect(x, y, 1, 1); }
  }
}
function revealedPct() { let c = 0, l = 0; for (let i = 0; i < MW * MH; i++) if (G.W.land[i]) { l++; if (G.revealed[i]) c++; } return Math.round((c / l) * 100); }

// ---------- Partículas e avisos ----------
function burst(x, y, col, n) { for (let k = 0; k < n; k++) G.particles.push({ x, y, vx: (Math.random() - 0.5) * 120, vy: -Math.random() * 120, life: 0.5 + Math.random() * 0.3, max: 0.8, col, s: 2 + Math.random() * 2.5 }); }
let toastId = 0;
function toast(msg, kind) {
  const box = document.getElementById('toasts'); if (!box) return;
  const el = document.createElement('div'); el.className = 'toast ' + (kind || ''); el.textContent = msg;
  box.appendChild(el); while (box.children.length > 5) box.removeChild(box.firstChild);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 400); }, 4200);
}
function fadeFlash() { const f = document.getElementById('fade'); f.classList.remove('on'); void f.offsetWidth; f.classList.add('on'); }

// ---------- Atualização ----------
function update(dt) {
  if (G.mode !== 'play') return;
  const p = G.player, W = G.W;
  G.t += dt; G.tel.session += dt;
  if (G.ui.open) G.tel.invOpen += dt;
  const di = dayInfo(G.t);
  // fases
  if (di.phase !== G.lastPhase) {
    if (di.phase === 'entardecer') toast('O sol está se pondo. Hora de voltar para a base', 'warn');
    if (di.phase === 'noite') {
      toast('A noite caiu. Fique perto do fogo ou acenda uma tocha', 'warn');
      G.tel.nights.push({ dia: di.day, fome: Math.round(p.fome), sede: Math.round(p.sede), vida: Math.round(p.hp), fogueira: G.nodes.some((n) => n && !n.gone && n.type === 'fogueira') });
    }
    if (di.phase === 'amanhecer' && G.lastPhase) toast('Amanhece o dia ' + di.day, 'info');
    G.lastPhase = di.phase;
  }
  if (di.day !== G.day) {
    G.day = di.day; const r = Math.random();
    G.weather = r < 0.3 ? 'sol' : r < 0.55 ? 'chuva' : 'limpo';
    toast(G.weather === 'chuva' ? 'O céu fechou: dia de chuva (bom para coletores)' : G.weather === 'sol' ? 'Sol forte hoje: a sede aperta na praia' : 'Céu limpo hoje', 'info');
  }
  // maré
  const low = isLowTide();
  if (low !== G.lastLow) {
    G.lastLow = low;
    if (low) {
      let c = G.nodes.filter((n) => n && !n.gone && n.type === 'caixa').length, made = 0;
      for (let k = 0; k < 3 && c < 7; k++) if (spawnOnBeach('caixa', 40)) { c++; made++; }
      for (let k = 0; k < 4; k++) spawnOnBeach('madeira_flut', 40);
      toast('Maré baixa: poças com peixes e novos destroços na praia', 'info');
    } else toast('A maré subiu', 'info');
  }
  // movimento
  let mx = 0, my = 0;
  if (keys.KeyW || keys.ArrowUp) my -= 1; if (keys.KeyS || keys.ArrowDown) my += 1;
  if (keys.KeyA || keys.ArrowLeft) mx -= 1; if (keys.KeyD || keys.ArrowRight) mx += 1;
  if (G.joy && (Math.abs(G.joy.x) > 0.15 || Math.abs(G.joy.y) > 0.15)) { mx = G.joy.x; my = G.joy.y; }
  const ml = Math.hypot(mx, my); p.moving = ml > 0.01;
  const w = weight(), over = w > cargaMax(), tooHeavy = w > cargaLim();
  const potFull = invSlots().some((r) => r.arr[r.i] && ITEMS[r.arr[r.i].id].noRun && r.arr[r.i].doses > 0);
  const run = (keys.ShiftLeft || keys.ShiftRight || G.joyRun) && p.energia > 0 && !over && !potFull && p.moving;
  p.running = run;
  if (p.moving) {
    mx /= Math.max(1, ml); my /= Math.max(1, ml);
    p.face = { x: mx / (Math.hypot(mx, my) || 1), y: my / (Math.hypot(mx, my) || 1) };
    let sp = run ? CONFIG.velocidade_corrida : CONFIG.velocidade;
    const tt = tileTypeAt(p.x, p.y);
    if (tt === T.SHALLOW || tt === T.RIVER || tt === T.MWATER || tt === T.MUD || tt === T.HOT || (tt === T.TIDE && !low)) sp *= 0.6;
    if (over) sp *= 0.7;
    if (tooHeavy) { sp = 0; if (!G.timers.heavy || G.t > G.timers.heavy) { toast('Peso demais para se mover. Largue algo (inventário)', 'bad'); G.timers.heavy = G.t + 4; } }
    if (G.gather && sp > 0) G.gather = null;
    const nx = p.x + mx * sp * dt, ny = p.y + my * sp * dt;
    if (!collides(nx, p.y)) p.x = nx;
    if (!collides(p.x, ny)) p.y = ny;
  }
  // status
  const b = W.biome[tileIdx(p.x, p.y)];
  if (b && !G.tel.biomes[b]) { G.tel.biomes[b] = elapsed(); if (elapsed() > 1) toast('Novo bioma: ' + BIOME_NAME[b], 'info'); }
  p.warm = warmth();
  const sheltered = nearType('abrigo', 50);
  const mult = run ? 1.5 : 1;
  let heat = 1;
  if (b === B.VULCAO) heat = 2;
  else if (b === B.PRAIA && di.phase === 'dia' && (di.midday || G.weather === 'sol') && !sheltered) heat = 1.5;
  p.heat = heat;
  p.fome -= CONFIG.taxa_fome * dt * mult;
  p.sede -= CONFIG.taxa_sede * dt * mult * heat;
  p.energia -= CONFIG.energia_passiva * dt * (over ? 1.5 : 1);
  const night = di.phase === 'noite';
  p.cold = !p.warm && !sheltered && ((night && (b === B.PRAIA || b === B.PLANALTO)) || (night && G.weather === 'chuva'));
  if (p.cold) p.energia -= dt / 15;
  if (p.fome <= 0) { p.fome = 0; p.hp -= dt / 5; p.lastCause = 'fome'; }
  if (p.sede <= 0) { p.sede = 0; p.hp -= (2 * dt) / 5; p.lastCause = 'sede'; }
  const e = p.eff;
  if (e.indisp > 0) e.indisp -= dt;
  if (e.veneno > 0) { e.veneno -= dt; p.hp -= dt / 4; p.lastCause = 'veneno'; }
  if (e.sangue) { p.hp -= dt / 10; p.lastCause = 'sangue'; if (nearType('fogueira', 110)) { e.sangue = false; toast('O calor do fogo fez as sanguessugas se soltarem', 'good'); } }
  if (p.fome > 50 && p.sede > 50 && !(e.indisp > 0) && !(e.veneno > 0) && !e.sangue) p.hp += (dt / 10) * (p.warm ? 2 : 1);
  if (!p.moving && (p.warm || sheltered)) p.energia += dt / 3;
  const tt = tileTypeAt(p.x, p.y);
  if (tt === T.MUD || tt === T.MWATER) {
    G.timers.leech += dt;
    if (G.timers.leech > 15) { G.timers.leech = 0; if (!e.sangue && chance(0.15)) { e.sangue = true; toast('Sanguessugas grudaram em você (−vida aos poucos). O fogo as espanta', 'bad'); } }
  }
  if (tt === T.HOT) { p.hp += dt / 2; p.energia += dt / 2; }
  // gás
  if (inGas(p.x, p.y)) {
    if (!hasItem('mascara')) { p.hp -= dt; p.lastCause = 'gas'; if (G.t > G.timers.gasMsg) { toast('Gás vulcânico: você precisa de uma máscara', 'bad'); G.timers.gasMsg = G.t + 5; } }
  }
  p.hp = Math.min(100, p.hp); p.energia = clamp(p.energia, 0, 100); p.fome = clamp(p.fome, 0, 100); p.sede = clamp(p.sede, 0, 100);
  if (p.torch > 0) { p.torch -= dt; if (p.torch <= 0) toast('A tocha apagou', 'warn'); }
  p.atkCd -= dt; p.swing = Math.max(0, p.swing - dt); p.hurtFlash = Math.max(0, p.hurtFlash - dt);
  // coleta contínua
  if (G.gather) {
    const tg = findTarget();
    const same = tg && G.gather.tg && ((tg.kind === 'node' && G.gather.tg.kind === 'node' && tg.n === G.gather.tg.n) || (tg.kind === 'water' && G.gather.tg.kind === 'water'));
    if (!(keys.KeyE || G.touchE) || !same) G.gather = null;
    else {
      G.gather.t += dt * (p.energia <= 0 ? 0.5 : 1);
      G.gather.snd = (G.gather.snd || 0) + dt;
      if (G.gather.snd > 0.45 && G.gather.a.sound) { G.gather.snd = 0; AudioSys.sfx(G.gather.a.sound); }
      if (G.gather.t >= G.gather.a.time) { const a = G.gather.a; G.gather = null; a.exec(); G.repeatCd = 0.2; }
    }
  } else if ((keys.KeyE || G.touchE) && !G.ui.open) {
    G.repeatCd = (G.repeatCd || 0) - dt;
    if (G.repeatCd <= 0) tryInteract(true);
  }
  // fabricação
  if (G.craft) { G.craft.t += dt; if (G.craft.t >= G.craft.r.t) finishCraft(); }
  // inimigos
  updateEnemies(dt, di);
  // respawn / cocos / chuva / estragar
  G.timers.respawn += dt;
  if (G.timers.respawn > 2) {
    G.timers.respawn = 0;
    for (const n of G.nodes) {
      if (!n || n.gone) continue;
      if (n.dep && G.t >= n.respawnAt && dist(n.x, n.y, p.x, p.y) > 700) { n.dep = false; if (n.type === 'coqueiro') n.coco = 2; }
      if (n.type === 'coqueiro' && !n.dep && n.coco < 2 && G.t >= n.cocoT) { n.coco++; n.cocoT = G.t + 300; }
    }
    for (const r of invSlots()) { const s = r.arr[r.i]; if (s && s.spoil && G.t > s.spoil) { r.arr[r.i] = { id: 'estragado', n: s.n }; toast(ITEMS[s.id].n + ' estragou', 'warn'); G.ui.dirty = true; } }
  }
  if (G.weather === 'chuva' && (di.phase === 'dia' || di.phase === 'entardecer')) {
    G.timers.rain += dt;
    if (G.timers.rain > 40) { G.timers.rain = 0; for (const n of G.nodes) if (n && !n.gone && n.type === 'coletor' && n.water < 5) n.water++; }
  }
  // névoa
  G.timers.reveal -= dt;
  if (G.timers.reveal <= 0) { G.timers.reveal = 0.25; reveal(Math.floor(p.x / TS), Math.floor(p.y / TS), b === B.PLANALTO ? 9 : 7); }
  // partículas
  for (const q of G.particles) { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 300 * dt; q.life -= dt; }
  G.particles = G.particles.filter((q) => q.life > 0);
  if (Math.random() < dt * 3) for (const n of visibleStructs('fogueira')) G.particles.push({ x: n.x + (Math.random() - 0.5) * 6, y: n.y - 18, vx: (Math.random() - 0.5) * 10, vy: -30, life: 1.6, max: 1.6, col: 'rgba(120,120,120,.5)', s: 4, smoke: true });
  // áudio ambiente
  AudioSys.setAmbient(clamp(1 - W.cd[tileIdx(p.x, p.y)] / 10, 0, 1), night);
  if (p.hp <= 0) die(p.lastCause || 'fome');
}
function visibleStructs(tp) { return G.nodes.filter((n) => n && !n.gone && n.type === tp && Math.abs(n.x - cam.x) < 900 && Math.abs(n.y - cam.y) < 600); }
function nearType(tp, r) {
  const p = G.player, tx = Math.floor(p.x / TS), ty = Math.floor(p.y / TS), R = Math.ceil(r / TS) + 1;
  for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) { const n = nodeAtTile(tx + dx, ty + dy); if (n && n.type === tp && dist(n.x, n.y, p.x, p.y) < r) return n; }
  return null;
}
function warmth() { return !!(nearType('fogueira', 128) || nearType('forno', 80) || nearType('fonte_termal', 60) || G.player.torch > 0 && false); }
function inGas(x, y) { const tx = x / TS, ty = y / TS; return G.W.gas.some(([gx, gy, r]) => Math.hypot(tx - gx, ty - gy) < r); }
function collides(x, y) {
  const W = G.W;
  for (const [ox, oy] of [[-7, 0], [7, 0], [0, -3], [0, 5]]) { const t = tileTypeAt(x + ox, y + oy); if (t === T.DEEP) return true; }
  const tx = Math.floor(x / TS), ty = Math.floor(y / TS);
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
    const n = nodeAtTile(tx + dx, ty + dy); if (!n || n.dep) continue;
    const d = NODES[n.type]; if (!d.solid) continue;
    if (d.lowTide && !isLowTide()) continue;
    const rr = n.type === 'naufragio' ? 30 : d.r * 0.6 + 7;
    if (dist(x, y, n.x, n.y) < rr) return true;
  }
  return false;
}
function updateEnemies(dt, di) {
  const p = G.player, W = G.W, night = di.phase === 'noite';
  const pb = W.biome[tileIdx(p.x, p.y)];
  const crabs = G.enemies.filter((e) => e.kind === 'crab');
  if (night && pb === B.PRAIA && crabs.length < 4 && Math.random() < dt * 0.25) {
    for (let k = 0; k < 12; k++) {
      const a = Math.random() * 7, r = 220 + Math.random() * 120, x = p.x + Math.cos(a) * r, y = p.y + Math.sin(a) * r;
      if (W.biome[tileIdx(x, y)] === B.PRAIA && !isWaterType(tileTypeAt(x, y))) { G.enemies.push({ kind: 'crab', x, y, hp: 3, cd: 0, hurt: 0, wa: Math.random() * 7 }); break; }
    }
  }
  for (const e of G.enemies) {
    e.cd -= dt; e.hurt = Math.max(0, e.hurt - dt);
    const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
    if (e.kind === 'crab') {
      if (!night && d > 500) { e.dead = true; continue; }
      let vx = 0, vy = 0;
      const torchNear = p.torch > 0 && d < 120;
      if (!night || torchNear) { vx = (-dx / d) * 80; vy = (-dy / d) * 80; }
      else if (d < 180) { vx = (dx / d) * 72; vy = (dy / d) * 72; }
      else { e.wa += (Math.random() - 0.5) * dt * 3; vx = Math.cos(e.wa) * 30; vy = Math.sin(e.wa) * 30; }
      const nx = e.x + vx * dt, ny = e.y + vy * dt;
      if (tileTypeAt(nx, ny) !== T.DEEP) { e.x = nx; e.y = ny; }
      if (night && !torchNear && d < 18 && e.cd <= 0) { damage(3, 'caranguejo'); e.cd = 1.5; }
    } else if (e.kind === 'snake') {
      e.alert = d < 70;
      if (d < 22 && e.cd <= 0) { damage(4, 'cobra'); p.eff.veneno = 30; e.cd = 4; toast('Uma cobra picou você: veneno por 30 s', 'bad'); }
    }
  }
  G.enemies = G.enemies.filter((e) => !e.dead);
}

function tryInteract(fromHold) {
  if (G.mode !== 'play') return;
  const tg = findTarget(); const a = getAction(tg);
  if (!a) { G.repeatCd = 0.3; return; }
  if (!a.can) { if (!fromHold) { toast(a.label, 'warn'); AudioSys.sfx('error'); } G.repeatCd = 0.4; return; }
  if (!a.time) { if (!fromHold) a.exec(); G.repeatCd = 0.5; return; }
  G.gather = { tg, a, t: 0 };
}

// ---------- Render ----------
function resize() {
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.floor(innerWidth * DPR); canvas.height = Math.floor(innerHeight * DPR);
  lightC.width = canvas.width; lightC.height = canvas.height;
  ZOOM = clamp(Math.min(innerWidth / 1150, innerHeight / 720), 0.6, 1.2);
}
function render() {
  const cw = canvas.width, ch = canvas.height, S = ZOOM * DPR;
  const p = G.player, t = G.t || 0, low = isLowTide();
  if (G.mode === 'title') { cam.x = G.player.x + Math.sin(performance.now() / 9000) * 260; cam.y = G.player.y - 120 + Math.cos(performance.now() / 11000) * 140; }
  else { cam.x += (p.x - cam.x) * 0.15; cam.y += (p.y - 10 - cam.y) * 0.15; }
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#0f4866'; ctx.fillRect(0, 0, cw, ch);
  ctx.setTransform(S, 0, 0, S, cw / 2 - cam.x * S, ch / 2 - cam.y * S);
  const vw = cw / S, vh = ch / S;
  const x0 = Math.max(0, Math.floor((cam.x - vw / 2) / TS) - 1), x1 = Math.min(MW - 1, Math.ceil((cam.x + vw / 2) / TS) + 1);
  const y0 = Math.max(0, Math.floor((cam.y - vh / 2) / TS) - 1), y1 = Math.min(MH - 1, Math.ceil((cam.y + vh / 2) / TS) + 3);
  const W = G.W, now = performance.now() / 1000;
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
    const i = ty * MW + tx, tt = W.type[i];
    ctx.fillStyle = tt === T.TIDE ? (low ? G.tideLow[i] : G.tideHigh[i]) : G.tileCol[i];
    ctx.fillRect(tx * TS, ty * TS, TS + 0.6, TS + 0.6);
    const v = W.vari[i];
    if (tt === T.DEEP || tt === T.SHALLOW || tt === T.RIVER || tt === T.MWATER || tt === T.SPRING || (tt === T.TIDE && !low)) {
      if (v > 0.78) { ctx.fillStyle = 'rgba(255,255,255,' + (0.1 + 0.1 * Math.sin(now * 2 + v * 40)) + ')'; ctx.fillRect(tx * TS + 6 + Math.sin(now + v * 9) * 4, ty * TS + 12 + v * 8, 12, 2); }
      if (G.shore[i]) { ctx.fillStyle = 'rgba(255,255,255,' + (0.1 + 0.08 * Math.sin(now * 1.6 + tx * 0.6 + ty * 0.3)) + ')'; ctx.fillRect(tx * TS, ty * TS, TS, TS); }
      if (tt === T.RIVER && v > 0.4) { ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(tx * TS + 4, ty * TS + ((now * 30 + v * 32) % 32), 10, 2); }
    } else if (tt === T.GRASS && v < 0.3) { ctx.fillStyle = 'rgba(20,50,20,.35)'; ctx.fillRect(tx * TS + v * 60, ty * TS + 10 + v * 30, 3, 6); ctx.fillRect(tx * TS + v * 60 + 4, ty * TS + 12 + v * 30, 2, 5); }
    else if (tt === T.SAND && v < 0.12) { ctx.fillStyle = 'rgba(160,130,80,.3)'; ctx.fillRect(tx * TS + v * 200, ty * TS + 16, 3, 2); }
    else if ((tt === T.PLATEAU || tt === T.VOLC) && v < 0.2) { ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.fillRect(tx * TS + 6 + v * 50, ty * TS + 8 + v * 40, 6, 4); }
    else if (tt === T.MUD && v > 0.85) { ctx.fillStyle = 'rgba(40,30,20,.3)'; ctx.beginPath(); ctx.ellipse(tx * TS + 16, ty * TS + 16, 6, 3, 0, 0, 7); ctx.fill(); }
  }
  // gás
  for (const [gx, gy, r] of W.gas) {
    const gxx = gx * TS, gyy = gy * TS;
    if (Math.abs(gxx - cam.x) > vw || Math.abs(gyy - cam.y) > vh) continue;
    const g = ctx.createRadialGradient(gxx, gyy, 0, gxx, gyy, r * TS);
    g.addColorStop(0, 'rgba(200,210,90,' + (0.3 + Math.sin(now) * 0.05) + ')'); g.addColorStop(1, 'rgba(200,210,90,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(gxx, gyy, r * TS, 0, 7); ctx.fill();
  }
  // entidades
  const dr = [];
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) { const n = nodeAtTile(tx, ty); if (n) dr.push({ y: n.y, n }); }
  for (const e of G.enemies) {
    if (Math.abs(e.x - cam.x) > vw / 2 + 40 || Math.abs(e.y - cam.y) > vh / 2 + 40) continue;
    if (e.kind === 'snake' && dist(e.x, e.y, p.x, p.y) > 150) continue;
    dr.push({ y: e.y, e });
  }
  if (G.mode !== 'title') dr.push({ y: p.y, pl: true });
  dr.sort((a, b) => a.y - b.y);
  const sel = selectedSlot();
  for (const d of dr) {
    if (d.n) drawNode(ctx, d.n, now, low);
    else if (d.e) drawEnemy(ctx, d.e, now);
    else drawPlayer(ctx, p, now, sel && ITEMS[sel.id].tool ? sel.id : null);
  }
  for (const q of G.particles) { ctx.globalAlpha = clamp(q.life / q.max, 0, 1); ctx.fillStyle = q.col; if (q.smoke) { ctx.beginPath(); ctx.arc(q.x, q.y, q.s + (1 - q.life / q.max) * 6, 0, 7); ctx.fill(); } else ctx.fillRect(q.x, q.y, q.s, q.s); }
  ctx.globalAlpha = 1;
  // alvo e progresso
  if (G.mode === 'play') {
    const tg = G.curTarget;
    if (tg && tg.kind === 'node') { ctx.strokeStyle = 'rgba(255,240,200,.75)'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.ellipse(tg.n.x, tg.n.y + 2, (NODES[tg.n.type].r || 10) + 6, ((NODES[tg.n.type].r || 10) + 6) * 0.55, 0, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
    if (G.gather) {
      const k = clamp(G.gather.t / G.gather.a.time, 0, 1);
      ctx.fillStyle = 'rgba(10,20,30,.7)'; ctx.fillRect(p.x - 22, p.y - 44, 44, 7);
      ctx.fillStyle = '#f2c14e'; ctx.fillRect(p.x - 21, p.y - 43, 42 * k, 5);
    }
  }
  // iluminação
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  const di = dayInfo(t);
  let dark = di.dark + (G.weather === 'chuva' && di.phase !== 'noite' ? 0.18 : 0);
  if (G.mode === 'title') dark = 0.1;
  if (di.phase === 'entardecer' || di.phase === 'amanhecer') { ctx.fillStyle = 'rgba(255,120,60,' + (0.12 * (1 - Math.abs(dark - 0.36) / 0.36)) + ')'; ctx.fillRect(0, 0, cw, ch); }
  if (dark > 0.02) {
    lctx.globalCompositeOperation = 'source-over'; lctx.clearRect(0, 0, cw, ch);
    lctx.fillStyle = 'rgba(6,10,32,' + dark + ')'; lctx.fillRect(0, 0, cw, ch);
    lctx.globalCompositeOperation = 'destination-out';
    const light = (wx, wy, r, a) => {
      const sx = (wx - cam.x) * S + cw / 2, sy = (wy - cam.y) * S + ch / 2, rr = r * S;
      if (sx < -rr || sy < -rr || sx > cw + rr || sy > ch + rr) return;
      const g = lctx.createRadialGradient(sx, sy, 0, sx, sy, rr); g.addColorStop(0, 'rgba(0,0,0,' + a + ')'); g.addColorStop(0.6, 'rgba(0,0,0,' + a * 0.6 + ')'); g.addColorStop(1, 'rgba(0,0,0,0)');
      lctx.fillStyle = g; lctx.beginPath(); lctx.arc(sx, sy, rr, 0, 7); lctx.fill();
    };
    if (G.mode !== 'title') light(p.x, p.y - 10, p.torch > 0 ? 300 + Math.sin(now * 10) * 6 : 95, p.torch > 0 ? 1 : 0.75);
    for (const n of visibleStructs('fogueira')) light(n.x, n.y - 6, 240 + Math.sin(now * 8 + n.x) * 8, 1);
    for (const n of visibleStructs('forno')) light(n.x, n.y, 130, 0.9);
    for (const n of visibleStructs('fonte_termal')) light(n.x, n.y, 80, 0.6);
    for (const n of visibleStructs('pagina')) light(n.x, n.y, 40, 0.7);
    ctx.drawImage(lightC, 0, 0);
    ctx.globalCompositeOperation = 'lighter';
    for (const n of visibleStructs('fogueira')) { const sx = (n.x - cam.x) * S + cw / 2, sy = (n.y - cam.y) * S + ch / 2, g = ctx.createRadialGradient(sx, sy, 0, sx, sy, 160 * S); g.addColorStop(0, 'rgba(255,140,50,' + 0.22 * dark + ')'); g.addColorStop(1, 'rgba(255,140,50,0)'); ctx.fillStyle = g; ctx.fillRect(sx - 160 * S, sy - 160 * S, 320 * S, 320 * S); }
    ctx.globalCompositeOperation = 'source-over';
  }
  // chuva
  if (G.weather === 'chuva' && G.mode === 'play' && di.phase !== 'noite') {
    ctx.strokeStyle = 'rgba(200,220,255,.35)'; ctx.lineWidth = 1 * DPR; ctx.beginPath();
    for (let k = 0; k < 120; k++) { const rx = (hash2(k, 1, 3) * cw + now * 200 * DPR) % cw, ry = (hash2(k, 2, 3) * ch + now * 900 * DPR) % ch; ctx.moveTo(rx, ry); ctx.lineTo(rx - 4 * DPR, ry + 14 * DPR); }
    ctx.stroke();
  }
  // vinheta de dano / pouca vida / gás
  if (G.mode === 'play') {
    const lowHp = p.hp < 30 ? (30 - p.hp) / 30 : 0, a = Math.max(lowHp * 0.5, p.hurtFlash * 1.2);
    if (a > 0.01) { const g = ctx.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.3, cw / 2, ch / 2, Math.max(cw, ch) * 0.7); g.addColorStop(0, 'rgba(180,20,20,0)'); g.addColorStop(1, 'rgba(180,20,20,' + clamp(a, 0, 0.6) + ')'); ctx.fillStyle = g; ctx.fillRect(0, 0, cw, ch); }
    if (inGas(p.x, p.y)) { ctx.fillStyle = 'rgba(190,200,80,.12)'; ctx.fillRect(0, 0, cw, ch); }
  }
}

// ---------- Loop ----------
let lastTS = 0, fpsAcc = 0, fpsN = 0, fps = 60, hudT = 0, manualTime = false;
function frame(ts) {
  const dt = Math.min(0.05, (ts - (lastTS || ts)) / 1000); lastTS = ts;
  if (!manualTime) step(dt);
  fpsAcc += dt; fpsN++; if (fpsAcc > 0.5) { fps = Math.round(fpsN / fpsAcc); fpsAcc = 0; fpsN = 0; }
  requestAnimationFrame(frame);
}
function step(dt) {
  update(dt);
  if (G.mode === 'play') G.curTarget = findTarget();
  render();
  hudT -= dt; if (hudT <= 0) { hudT = 0.1; updateHUD(); }
}
window.advanceTime = (ms) => { manualTime = true; const n = Math.max(1, Math.round(ms / (1000 / 60))); for (let i = 0; i < n; i++) update(1 / 60); G.curTarget = G.mode === 'play' ? findTarget() : null; render(); updateHUD(); };
window.render_game_to_text = () => {
  const p = G.player, di = dayInfo(G.t), tg = G.curTarget, a = getAction(tg);
  return JSON.stringify({
    nota: 'coordenadas em tiles; origem no canto superior esquerdo, x para a direita, y para baixo',
    mode: G.mode, dia: di.day, fase: di.phase, hora: di.hour.toFixed(1), mare: isLowTide() ? 'baixa' : 'alta', clima: G.weather,
    jogador: { tx: +(p.x / TS).toFixed(1), ty: +(p.y / TS).toFixed(1), bioma: BIOME_NAME[G.W.biome[tileIdx(p.x, p.y)]], vida: Math.round(p.hp), fome: Math.round(p.fome), sede: Math.round(p.sede), energia: Math.round(p.energia), efeitos: Object.keys(p.eff).filter((k) => p.eff[k] > 0 || p.eff[k] === true), tocha: Math.round(p.torch) },
    alvo: a ? { acao: a.label, pode: a.can, tempo: a.time } : null,
    coletando: G.gather ? +(G.gather.t / G.gather.a.time).toFixed(2) : null,
    fabricando: G.craft ? G.craft.r.id : null,
    barra: G.inv.hot.slice(0, G.inv.hotN).map((s) => (s ? s.id + 'x' + s.n : null)), selecionado: G.sel,
    bolsos: G.inv.pocket.slice(0, G.inv.pocketN).filter(Boolean).map((s) => s.id + 'x' + s.n),
    peso: +weight().toFixed(1), receitas_conhecidas: G.known.size, paginas: [...G.pages],
    inimigos_proximos: G.enemies.filter((e) => dist(e.x, e.y, p.x, p.y) < 300).map((e) => ({ tipo: e.kind, tx: +(e.x / TS).toFixed(1), ty: +(e.y / TS).toFixed(1) })),
  });
};
