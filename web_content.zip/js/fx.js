// ===== fx: particles, tracers, decals, audio =====
let PQ = 1;
class PS {
  constructor(n, additive) {
    this.n = n; this.i = 0;
    this.pos = new Float32Array(n * 3); this.vel = new Float32Array(n * 3);
    this.col = new Float32Array(n * 4); this.size = new Float32Array(n);
    this.life = new Float32Array(n).fill(1); this.age = new Float32Array(n).fill(99);
    this.d8 = new Float32Array(n * 8); this.d4 = new Float32Array(n * 4);
    const g = new THREE.BufferGeometry();
    this.aPos = new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage);
    this.aCol = new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage);
    this.aSize = new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('position', this.aPos); g.setAttribute('aColor', this.aCol); g.setAttribute('aSize', this.aSize);
    const mat = new THREE.ShaderMaterial({
      uniforms: { uScale: PSU.uScale, uFogD: { value: FOG_D }, uFogC: { value: new THREE.Color(FOG) }, uAdd: { value: additive ? 1 : 0 } },
      transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      vertexShader: `attribute float aSize; attribute vec4 aColor; uniform float uScale,uFogD; varying vec4 vC; varying float vF;
void main(){ vec4 mv=modelViewMatrix*vec4(position,1.0); float z=max(-mv.z,0.1); gl_PointSize=min(aSize*uScale/z,500.0); gl_Position=projectionMatrix*mv; vF=1.0-exp(-pow(uFogD*z,2.0)); vC=aColor; }`,
      fragmentShader: `uniform vec3 uFogC; uniform float uAdd; varying vec4 vC; varying float vF;
void main(){ vec2 p=gl_PointCoord*2.0-1.0; float d=dot(p,p); if(d>1.0) discard; float a=1.0-d; a*=a; vec3 c=vC.rgb; float al=vC.a*a;
if(uAdd>0.5){ al*=(1.0-vF);} else { c=mix(c,uFogC,vF);} gl_FragColor=vec4(c,al); }`
    });
    this.mesh = new THREE.Points(g, mat); this.mesh.frustumCulled = false; scene.add(this.mesh);
  }
  emit(x, y, z, vx, vy, vz, life, s0, s1, c0, c1, a0, a1, grav, drag) {
    if (PQ < 1 && Math.random() > PQ) return;
    const i = this.i; this.i = (i + 1) % this.n;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.life[i] = life; this.age[i] = 0;
    const p = i * 8; this.d8[p] = s0; this.d8[p + 1] = s1; this.d8[p + 2] = c0[0]; this.d8[p + 3] = c0[1]; this.d8[p + 4] = c0[2]; this.d8[p + 5] = c1[0]; this.d8[p + 6] = c1[1]; this.d8[p + 7] = c1[2];
    const q = i * 4; this.d4[q] = a0; this.d4[q + 1] = a1; this.d4[q + 2] = grav; this.d4[q + 3] = drag;
  }
  update(dt) {
    for (let i = 0; i < this.n; i++) {
      if (this.age[i] >= this.life[i]) continue;
      const a = this.age[i] += dt, L = this.life[i];
      if (a >= L) { this.size[i] = 0; this.col[i * 4 + 3] = 0; continue; }
      const t = a / L, k = i * 3, p = i * 8, q = i * 4, dr = Math.max(0, 1 - this.d4[q + 3] * dt);
      this.vel[k + 1] -= this.d4[q + 2] * dt;
      this.vel[k] *= dr; this.vel[k + 1] *= dr; this.vel[k + 2] *= dr;
      this.pos[k] += this.vel[k] * dt; this.pos[k + 1] += this.vel[k + 1] * dt; this.pos[k + 2] += this.vel[k + 2] * dt;
      if (this.pos[k + 1] < 0.03 && this.d4[q + 2] > 2) { this.pos[k + 1] = 0.03; this.vel[k + 1] *= -0.3; this.vel[k] *= 0.6; this.vel[k + 2] *= 0.6; }
      this.size[i] = this.d8[p] + (this.d8[p + 1] - this.d8[p]) * t;
      this.col[i * 4] = this.d8[p + 2] + (this.d8[p + 5] - this.d8[p + 2]) * t;
      this.col[i * 4 + 1] = this.d8[p + 3] + (this.d8[p + 6] - this.d8[p + 3]) * t;
      this.col[i * 4 + 2] = this.d8[p + 4] + (this.d8[p + 7] - this.d8[p + 4]) * t;
      this.col[i * 4 + 3] = this.d4[q] + (this.d4[q + 1] - this.d4[q]) * t;
    }
    this.aPos.needsUpdate = this.aCol.needsUpdate = this.aSize.needsUpdate = true;
  }
}
const smoke = new PS(3200, false), glow = new PS(1600, true);
const C_FIRE0 = [1, .75, .3], C_FIRE1 = [.8, .2, .05], C_SMOKE0 = [.22, .2, .19], C_SMOKE1 = [.4, .37, .34];
const C_DUST = [.55, .45, .33], C_BLOOD = [.4, .02, .02], C_SPARK = [1, .85, .45];

function dustPuff(x, y, z, n, col, size, spd) {
  for (let i = 0; i < n; i++) smoke.emit(x, y, z, rand(-1, 1) * spd, rand(0.2, 1) * spd, rand(-1, 1) * spd, rand(.5, 1.1), size * .4, size, col, col, .5, 0, -0.5, 2.5);
}
function sparks(x, y, z, n, spd) {
  for (let i = 0; i < n; i++) glow.emit(x, y, z, rand(-1, 1) * spd, rand(0, 1) * spd, rand(-1, 1) * spd, rand(.2, .5), .12, .03, C_SPARK, [1, .4, .1], 1, 0, 14, .5);
}
function bloodPuff(x, y, z) {
  for (let i = 0; i < 7; i++) smoke.emit(x, y, z, rand(-1, 1) * 2, rand(0, 2), rand(-1, 1) * 2, rand(.3, .6), .15, .4, C_BLOOD, C_BLOOD, .8, 0, 6, 1);
}
function muzzleFx(x, y, z, size) { glow.emit(x, y, z, 0, 0, 0, 0.07, size, size * .4, [1, .85, .5], [1, .5, .1], 1, 0, 0, 0); }

// tracers
const trGeo = new THREE.BoxGeometry(0.035, 0.035, 1).translate(0, 0, 0.5);
const tracers = [];
for (let i = 0; i < 60; i++) {
  const m = new THREE.Mesh(trGeo, new THREE.MeshBasicMaterial({ color: 0xffd080, transparent: true, opacity: .9, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
  m.visible = false; scene.add(m); tracers.push({ m, on: false, s: new THREE.Vector3(), e: new THREE.Vector3(), t: 0, dur: 0, len: 6 });
}
let trI = 0;
function tracer(sx, sy, sz, ex, ey, ez, color, speed) {
  const t = tracers[trI]; trI = (trI + 1) % tracers.length;
  t.s.set(sx, sy, sz); t.e.set(ex, ey, ez);
  const dist = t.s.distanceTo(t.e); if (dist < 0.5) return;
  t.dur = dist / (speed || 260); t.t = 0; t.on = true; t.len = Math.min(7, dist);
  t.m.material.color.setHex(color || 0xffd080); t.m.visible = true;
}
const _tp = new THREE.Vector3(), _td = new THREE.Vector3();
function updateTracers(dt) {
  for (const t of tracers) {
    if (!t.on) continue; t.t += dt;
    const k = t.t / t.dur; if (k >= 1) { t.on = false; t.m.visible = false; continue; }
    _td.subVectors(t.e, t.s); const dist = _td.length(); _td.normalize();
    const head = k * dist;
    _tp.copy(t.s).addScaledVector(_td, head);
    t.m.position.copy(_tp); t.m.lookAt(_tp.x - _td.x, _tp.y - _td.y, _tp.z - _td.z);
    t.m.scale.z = Math.min(t.len, head + 0.1);
  }
}

// scorch decals
const scorchTex = craterTex(), scorches = []; let scI = 0;
for (let i = 0; i < 24; i++) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: scorchTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }));
  m.visible = false; scene.add(m); scorches.push(m);
}
function scorch(x, z, s) { const m = scorches[scI]; scI = (scI + 1) % scorches.length; m.position.set(x, 0.04, z); m.scale.set(s, 1, s); m.visible = true; }

// light flashes
let boomT = 0, flashT = 0;
function updateLights(dt) {
  boomT = Math.max(0, boomT - dt); boomLight.intensity = boomT > 0 ? 60 * (boomT / .5) : 0;
  flashT = Math.max(0, flashT - dt); flashLight.intensity = flashT > 0 ? 6 : 0;
}

// ===== audio =====
const AC = window.AudioContext || window.webkitAudioContext;
let ac = null, master = null, noiseBuf = null, activeSnd = 0, muted = false;
function initAudio() {
  if (ac || !AC) return;
  try {
    ac = new AC(); master = ac.createGain(); master.gain.value = 0.7; master.connect(ac.destination);
    noiseBuf = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    startAmbience();
  } catch (e) { ac = null; }
}
function spat(x, z) {
  if (x === undefined) return { g: 1, p: 0 };
  const dx = x - P.pos.x, dz = z - P.pos.z, d = Math.hypot(dx, dz) + 0.01;
  return { g: 1 / (1 + d * 0.045), p: clamp((dx * Math.cos(P.yaw) - dz * Math.sin(P.yaw)) / d, -1, 1) * 0.8 };
}
function sout(x, z, vol) {
  const s = spat(x, z), g = ac.createGain(); g.gain.value = vol * s.g;
  if (ac.createStereoPanner) { const p = ac.createStereoPanner(); p.pan.value = s.p; g.connect(p); p.connect(master); } else g.connect(master);
  return g;
}
function snoise(dest, dur, type, f0, f1, q, vol, delay = 0) {
  const t = ac.currentTime + delay, src = ac.createBufferSource(); src.buffer = noiseBuf;
  const f = ac.createBiquadFilter(); f.type = type; f.Q.value = q;
  f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  const e = ac.createGain(); e.gain.setValueAtTime(vol, t); e.gain.exponentialRampToValueAtTime(0.001, t + dur);
  src.connect(f); f.connect(e); e.connect(dest); src.start(t, Math.random()); src.stop(t + dur + 0.05);
  activeSnd++; src.onended = () => activeSnd--;
}
function stone(dest, f0, f1, dur, vol, type = 'sine', delay = 0) {
  const t = ac.currentTime + delay, o = ac.createOscillator(); o.type = type;
  o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(10, f1), t + dur);
  const e = ac.createGain(); e.gain.setValueAtTime(vol, t); e.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(e); e.connect(dest); o.start(t); o.stop(t + dur + 0.05);
}
const SND = {
  ok() { return ac && !muted && activeSnd < 36; },
  shot(kind, x, z) {
    if (!this.ok()) return; const o = sout(x, z, kind === 'rifle' ? .55 : .7);
    if (kind === 'rifle') { snoise(o, .16, 'lowpass', 5000, 600, .7, 1); stone(o, 160, 45, .12, .8); }
    else if (kind === 'shotgun') { snoise(o, .35, 'lowpass', 4000, 300, .7, 1.2); stone(o, 110, 35, .25, 1.1); }
    else if (kind === 'mg') { snoise(o, .1, 'bandpass', 2500, 800, 1, .7); stone(o, 140, 50, .08, .5); }
    else if (kind === 'sniper') { snoise(o, .5, 'lowpass', 3500, 200, .8, 1.1); stone(o, 120, 30, .3, 1); }
    else if (kind === 'rpg') { snoise(o, .6, 'bandpass', 300, 2500, .6, .9); stone(o, 90, 30, .35, 1); }
    else if (kind === 'plasma') { stone(o, 1500, 190, .17, .7, 'sawtooth'); snoise(o, .12, 'highpass', 4500, 2000, 1, .35); }
    else if (kind === 'minigun') { snoise(o, .07, 'bandpass', 2200, 700, 1, .6); stone(o, 120, 55, .05, .5); }
    else if (kind === 'sup') { snoise(o, .1, 'lowpass', 1800, 400, .7, .5); stone(o, 120, 70, .06, .35); }
    else if (kind === 'tank') { snoise(o, .9, 'lowpass', 2500, 100, .6, 1.4); stone(o, 70, 22, .7, 1.6); }
  },
  boom(x, z, big) {
    if (!ac || muted) return; const o = sout(x, z, big ? 1.8 : 1.2);
    snoise(o, big ? 2.2 : 1.4, 'lowpass', 1400, 60, .5, 1.6); stone(o, 80, 20, big ? 1.4 : .9, 1.6); snoise(o, .2, 'highpass', 3000, 1000, .5, .6);
  },
  hit(head) { if (!this.ok()) return; const o = sout(undefined, undefined, .35); stone(o, head ? 1700 : 1100, head ? 1000 : 700, .07, .6, 'square'); },
  kill() { if (!this.ok()) return; const o = sout(undefined, undefined, .3); stone(o, 500, 250, .15, .6, 'triangle'); },
  hurt() { if (!ac || muted) return; const o = sout(undefined, undefined, .8); stone(o, 120, 50, .25, .9, 'sawtooth'); snoise(o, .2, 'lowpass', 900, 200, 1, .6); },
  whiz(x, z) { if (!this.ok()) return; const o = sout(x, z, .5); snoise(o, .18, 'bandpass', 4500, 1500, 3, .5); },
  reload() { if (!this.ok()) return; const o = sout(undefined, undefined, .4); snoise(o, .05, 'highpass', 2500, 2000, 1, .8); snoise(o, .06, 'bandpass', 1200, 900, 2, .8, .45); snoise(o, .07, 'highpass', 3000, 2000, 1, .9, .95); },
  click() { if (!this.ok()) return; const o = sout(undefined, undefined, .4); snoise(o, .03, 'highpass', 3000, 2500, 1, .8); },
  pickup() { if (!ac || muted) return; const o = sout(undefined, undefined, .4); stone(o, 600, 900, .1, .6, 'triangle'); stone(o, 900, 1300, .12, .6, 'triangle', .09); },
  step() { if (!this.ok()) return; const o = sout(undefined, undefined, .12); snoise(o, .08, 'lowpass', 500, 200, .8, 1); },
  land() { if (!this.ok()) return; const o = sout(undefined, undefined, .3); snoise(o, .15, 'lowpass', 400, 100, .8, 1); },
  gren() { if (!this.ok()) return; const o = sout(undefined, undefined, .35); snoise(o, .06, 'bandpass', 2000, 1500, 2, .8); },
  alert() { if (!ac || muted) return; const o = sout(undefined, undefined, .35); stone(o, 440, 440, .2, .6, 'square'); stone(o, 330, 330, .3, .6, 'square', .22); },
  thump() { if (!ac || muted) return; const o = sout(undefined, undefined, .9); stone(o, 90, 28, .5, 1.3); snoise(o, .6, 'lowpass', 900, 80, .6, 1.2); },
  metal() { if (!ac || muted) return; const o = sout(undefined, undefined, .5); snoise(o, .5, 'bandpass', 500, 260, 2, 1); stone(o, 140, 70, .35, .8, 'square'); snoise(o, .06, 'highpass', 3000, 2000, 1, .9, .55); },
  whoosh() { if (!ac || muted) return; const o = sout(undefined, undefined, .5); snoise(o, 1.4, 'bandpass', 200, 2200, .8, 1); },
  firework(x, z) { if (!ac || muted) return; const o = sout(x, z, 1.1); snoise(o, .12, 'highpass', 4000, 1500, 1, .6); snoise(o, 1.2, 'lowpass', 1800, 90, .5, 1.1, .12); },
  jet() { if (!ac || muted) return; const o = sout(undefined, undefined, .7); const t = ac.currentTime; snoise(o, 7, 'bandpass', 300, 900, 1.2, 1.2); stone(o, 60, 140, 7, .5, 'sawtooth'); }
};
// continuous engine / rotor / diesel bed used by the cinematics
function makeEngine(kind) {
  if (!ac) return { vol() { }, pitch() { }, stop() { } };
  const out = ac.createGain(); out.gain.value = 0; out.connect(master);
  const fb = kind === 'jet' ? 700 : kind === 'rotor' ? 260 : 170, ob = kind === 'jet' ? 70 : kind === 'rotor' ? 46 : 38;
  const src = ac.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
  const f = ac.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = fb; f.Q.value = .8;
  const ng = ac.createGain(); ng.gain.value = kind === 'diesel' ? .45 : 1; src.connect(f); f.connect(ng); ng.connect(out); src.start();
  const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = ob;
  const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 240; const og = ac.createGain(); og.gain.value = .5; o.connect(lp); lp.connect(og); og.connect(out); o.start();
  let lfo = null; if (kind === 'rotor') { lfo = ac.createOscillator(); lfo.frequency.value = 14; const lg = ac.createGain(); lg.gain.value = .45; lfo.connect(lg); lg.connect(ng.gain); lfo.start(); }
  const tc = () => ac.currentTime;
  return {
    vol(v) { if (!isFinite(v)) v = .3; out.gain.setTargetAtTime(muted ? 0 : v, tc(), .2); },
    pitch(p) { if (!isFinite(p) || p <= 0) p = 1; f.frequency.setTargetAtTime(fb * p, tc(), .2); o.frequency.setTargetAtTime(ob * p, tc(), .2); if (lfo) lfo.frequency.setTargetAtTime(14 * p, tc(), .2); },
    stop() { out.gain.setTargetAtTime(0, tc(), .25); setTimeout(() => { try { src.stop(); o.stop(); if (lfo) lfo.stop(); } catch (e) { } }, 1200); }
  };
}
function startAmbience() {
  const src = ac.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
  const f = ac.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 420; f.Q.value = .5;
  const g = ac.createGain(); g.gain.value = .06; src.connect(f); f.connect(g); g.connect(master); src.start();
  for (const [fr, v] of [[55, .05], [82.4, .035]]) {
    const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = fr;
    const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 160;
    const gg = ac.createGain(); gg.gain.value = v; o.connect(lp); lp.connect(gg); gg.connect(master); o.start();
  }
}
