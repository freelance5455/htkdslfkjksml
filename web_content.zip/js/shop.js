// ===== merchant, shop and inventory =====
function spawnMerchant() {
  removeMerchant();
  let x = 0, z = 0;
  for (let i = 0; i < 60; i++) {
    const a = rand(0, 6.283), r = rand(9, 16); x = P.pos.x + Math.cos(a) * r; z = P.pos.z + Math.sin(a) * r;
    if (Math.hypot(x, z) < ARENA - 8 && !colliders.some(c => x > c.x0 - 2.5 && x < c.x1 + 2.5 && z > c.z0 - 2.5 && z < c.z1 + 2.5)) break;
  }
  const g = new THREE.Group(), coat = sm(0x6a4a2a), wood = sm(0x5a3d22), cloth = sm(0xb88a3a);
  eMesh(g, BX(.7, 1.1, .45), coat, 0, 1.0, 0); eMesh(g, BX(.3, .3, .3), EM.skin, 0, 1.75, 0);
  eMesh(g, new THREE.CylinderGeometry(.5, .5, .06, 14), coat, 0, 1.95, 0); eMesh(g, new THREE.CylinderGeometry(.22, .26, .26, 12), coat, 0, 2.05, 0);
  eMesh(g, BX(.75, .9, .45), sm(0x4a3a24), 0, 1.25, -.45);
  eMesh(g, BX(.22, .6, .22), coat, -.2, .3, 0); eMesh(g, BX(.22, .6, .22), coat, .2, .3, 0);
  eMesh(g, BX(2.6, .12, 1.1), wood, 0, .95, 1.5); eMesh(g, BX(.1, .95, .1), wood, -1.2, .48, 1.2); eMesh(g, BX(.1, .95, .1), wood, 1.2, .48, 1.2);
  eMesh(g, BX(2.9, .08, 1.5), cloth, 0, 2.4, 1.5); eMesh(g, BX(.08, 1.5, .08), wood, -1.35, 1.65, 1.0); eMesh(g, BX(.08, 1.5, .08), wood, 1.35, 1.65, 1.0);
  for (let i = 0; i < 4; i++) eMesh(g, BX(.35, .3, .35), i % 2 ? vmM.green : sm(0x8a2a22), -.9 + i * .6, 1.16, 1.5);
  const lamp = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: 0xffb040, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); lamp.scale.setScalar(2.4); lamp.position.set(1.2, 2.1, 1.0); g.add(lamp);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(.5, .5, 14, 10, 1, true), new THREE.MeshBasicMaterial({ color: 0xffd060, transparent: true, opacity: .22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); beam.position.y = 7; g.add(beam);
  g.position.set(x, 0, z); g.rotation.y = Math.atan2(P.pos.x - x, P.pos.z - z); scene.add(g);
  merchant = { x, z, g };
  message('TÜCCAR GELDİ', 'ALTIN IŞIĞA GİT · E');
}
function removeMerchant() { if (merchant) { scene.remove(merchant.g); merchant = null; } }

// ---- shared overlay handling ----
function openOverlay(kind) {
  if (G.state !== 'playing' && !(G.state === 'shop' || G.state === 'inv')) return false;
  G.state = kind; P.trigger = false; P.adsHeld = false; for (const k in K) K[k] = false; touchIn.mx = touchIn.my = 0;
  hint(''); if (document.pointerLockElement) document.exitPointerLock();
  $('shop').hidden = kind !== 'shop'; $('inv').hidden = kind !== 'inv'; return true;
}
function backToGame() {
  G.state = 'playing'; $('shop').hidden = $('inv').hidden = true; hudAmmo(); hudHealth(); lockMouse();
  setTimeout(() => { if (G.state === 'playing' && !isTouch && !noLock && !mouse.lock) pauseGame(); }, 600);
}
let shopTab = 'gear', invSel = 0, invFrom = null;
function openShop() { if (!merchant || P.dead) return; if (openOverlay('shop')) renderShop(); }
function openInv() { if (G.state !== 'playing' && G.state !== 'shop') return; invFrom = G.state === 'shop' ? 'shop' : null; if (!P.owned[invSel]) invSel = 0; if (openOverlay('inv')) renderInv(); }
function closeInv() { if (invFrom === 'shop') { openOverlay('shop'); renderShop(); } else backToGame(); }

// ---- shop ----
function ownedWeaponsRefill() { P.owned.forEach((o, i) => { if (o) P.ws[i].reserve += Math.ceil(WEAPONS[i].reserve * .6); }); }
function lvItem(name, desc, lv, max, costs, apply, extra) {
  return Object.assign({ n: name + ' ' + lv + '/' + max, d: desc, c: costs[Math.min(lv, max - 1)], done: lv >= max ? 'MAKSİMUM' : '', buy: () => { apply(); recomputeStats(); } }, extra || {});
}
function shopItems(tab) {
  const u = P.up;
  if (tab === 'gear') return [
    { n: 'Cephane Paketi', d: 'Sahip olduğun tüm silahlara +%60 yedek cephane', c: 150, buy: ownedWeaponsRefill },
    { n: 'Sağlık Paketi', d: '+60 sağlık', c: 120, ok: () => P.hp < P.maxHp, buy: () => { P.hp = Math.min(P.maxHp, P.hp + 60); } },
    { n: 'Zırh Plakası', d: '+50 zırh', c: 200, ok: () => P.armor < P.maxArmor, buy: () => { P.armor = Math.min(P.maxArmor, P.armor + 50); } },
    { n: 'El Bombası x2', d: 'Maksimum 8', c: 200, ok: () => P.gren < 8, buy: () => { P.gren = Math.min(8, P.gren + 2); } },
    { n: 'Molotof x2', d: 'Yere düşünce yanan ateş alanı. T tuşu', c: 250, ok: () => P.molo < 8, buy: () => { P.molo = Math.min(8, P.molo + 2); } },
    lvItem('Mıknatıs', 'Yerdeki eşyaları otomatik çeker (sandıklar hariç). Menzil: ' + [0, 7, 11, 16][u.mag] + 'm → ' + [7, 11, 16, 16][u.mag] + 'm', u.mag, 3, [1200, 2200, 3500], () => { u.mag++; })
  ];
  if (tab === 'up') {
    const out = [];
    P.owned.forEach((o, i) => { if (!o) return; const w = WEAPONS[i], lv = u.wlv[i]; out.push(lvItem(wname(i) + ' Geliştirme', 'Hasar +%10, şarjör +%8, yükleme -%5, saçılma -%4 (her seviye)', lv, 5, [0, 1, 2, 3, 4].map(k => Math.round((400 + 300 * k) * (w.id === 'rpg' ? 1.4 : w.id === 'sniper' ? 1.3 : 1))), () => { u.wlv[i]++; })); });
    out.push(lvItem('Zırh Yükseltme', 'Maksimum zırh +25', u.arm, 4, [400, 700, 1000, 1400], () => { u.arm++; P.armor = Math.min(P.maxArmor + 25, P.armor + 25); }));
    out.push(lvItem('Can Yükseltme', 'Maksimum sağlık +25', u.hp, 4, [400, 700, 1000, 1400], () => { u.hp++; P.hp += 25; }));
    out.push(lvItem('El Bombası Gücü', 'Bomba hasarı +%25', u.gren, 3, [500, 900, 1400], () => { u.gren++; }));
    out.push(lvItem('Molotof Gücü', 'Ateş +2.5 sn daha uzun, hasar +%25', u.molo, 3, [500, 900, 1400], () => { u.molo++; }));
    return out;
  }
  if (tab === 'guns') return [
    { n: 'MP7 SMG', d: 'Çok hızlı, 40 mermi şarjör. Yakın ve orta mesafe', c: 1200, done: P.owned[3] ? 'SAHİPSİN' : '', buy: () => { P.owned[3] = true; P.ws[3] = { ammo: WS(3).mag, reserve: WEAPONS[3].reserve }; invalidateWS(); } },
    { n: 'Keskin Nişancı Tüfeği', d: 'Tek atış, dürbünlü. Kafadan vuruş piyadeyi tek vuruşta indirir', c: 2000, done: P.owned[4] ? 'SAHİPSİN' : '', buy: () => { P.owned[4] = true; P.ws[4] = { ammo: WS(4).mag, reserve: WEAPONS[4].reserve }; invalidateWS(); } }
  ];
  if (tab === 'var') {
    const out = [];
    P.owned.forEach((o, i) => {
      if (!o) return; const id = WEAPONS[i].id, t = P.variant[i], nt = t + 1;
      if (nt > 5) { out.push({ n: VAR_NAMES[id][t], d: 'En üst varyant', c: 0, done: 'MAKSİMUM' }); return; }
      const cost = Math.round([1800, 3200, 5200, 8000, 12000][t] * ({ rpg: 1.3, sniper: 1.2, minigun: 1.5, plasma: 1.5 }[id] || 1)), locked = MAPI < nt;
      out.push({ n: VAR_NAMES[id][nt], d: VAR_NAMES[id][t] + ' → hasar +%16, şarjör +%8, yükleme -%4, saçılma -%5, atış hızı +%3 ' + (locked ? '· Harita ' + (nt + 1) + ' (' + MAPS[nt].name + ') açılınca kilidi açılır' : '· Renk: yeni parlak şerit'), c: cost, done: locked ? 'HARİTA ' + (nt + 1) + ' GEREKİR' : '', buy: () => { P.variant[i] = nt; invalidateWS(); fixAmmo(i); P.ws[i].ammo = WS(i).mag; } });
    });
    return out;
  }
  if (tab === 'sp') return [
    { n: 'Hasar Güçlendirici', d: '90 saniye boyunca tüm hasar x1.6', c: 900, ok: () => P.boostT <= 0, buy: () => { P.boostT = 90; recomputeStats(); } },
    { n: 'Tam Şifa', d: 'Sağlık ve zırh tamamen dolar', c: 450, ok: () => P.hp < P.maxHp || P.armor < P.maxArmor, buy: () => { P.hp = P.maxHp; P.armor = P.maxArmor; } },
    { n: 'Tam Cephane', d: 'Tüm silahlara +%150 yedek cephane, bomba ve molotof 8\'e tamamlanır', c: 700, buy: () => { P.owned.forEach((o, i) => { if (o) P.ws[i].reserve += Math.ceil(WEAPONS[i].reserve * 1.5); }); P.gren = 8; P.molo = 8; } },
    lvItem('Hızlı Ayak', 'Koşma ve yürüme hızı +%8', u.spd, 3, [1200, 2000, 3000], () => { u.spd++; }),
    lvItem('Hızlı Eller', 'Tüm silahlarda yükleme süresi -%10', u.rl, 3, [1500, 2400, 3500], () => { u.rl++; }),
    lvItem('Vampir Mermiler', 'Her öldürmede can kazan: +8 / +16 / +25', u.vamp, 3, [2000, 3200, 4800], () => { u.vamp++; }),
    { n: 'Hava Saldırısı Paketi', d: '+3 hava saldırısı (en fazla 5)', c: 4500, ok: () => P.air < 5, buy: () => { P.air = Math.min(5, P.air + 3); } },
    { n: 'İkram Çağır', d: 'Hemen bir ikram kutusu (içinden güçlü eşyalar çıkar) bırakılır. Dalga sırasında', c: 3500, ok: () => !airdrop && G.waveActive, buy: () => { spawnAirdrop(); } }
  ];
  if (tab === 'veh') return [
    { n: 'Tank Tamiri', d: 'Yıkık tanklardan en yakınını onarır, sen kullanırsın. Yıkık tank: ' + wrecks.length + (PT ? ' · Zaten tankın var' : ''), c: 3000, ok: () => wrecks.length > 0 && !PT, buy: () => { repairTank(); } },
    { n: 'Tank Bakımı', d: 'Tankının zırhını sıfırdan doldurur', c: 600, ok: () => !!PT && PT.hp < PT.maxHp, buy: () => { PT.hp = PT.maxHp; } },
    lvItem('Tank Zırhı', 'Tank dayanıklılığı +150', u.tank.arm, 4, [1500, 2200, 3000, 4000], () => { u.tank.arm++; if (PT) { PT.maxHp = tankMaxHp(); PT.hp += 150; } }),
    lvItem('Tank Topu', 'Top hasarı +%15', u.tank.gun, 4, [1500, 2200, 3000, 4000], () => { u.tank.gun++; }),
    lvItem('Hızlı Yükleme', 'Top yükleme süresi -%10', u.tank.rld, 3, [1800, 2600, 3500], () => { u.tank.rld++; })
  ];
  if (tab === 'att') return Object.keys(ATT).filter(id => !ATT[id].craft).map(id => ({ n: ATT[id].name, d: SLOT_NAMES[ATT[id].slot] + ': ' + ATT[id].desc + ((P.attInv[id] || 0) ? ' · Envanterde: ' + P.attInv[id] : ''), c: ATT[id].cost, buy: () => { P.attInv[id] = (P.attInv[id] || 0) + 1; } }));
  const r = u.rare;
  return [
    lvItem('Vurucu Mermiler', 'Tüm silah, bomba ve roket hasarı: x1.35 → x1.7 → x2.1', r.dmg, 3, [4500, 7000, 10000], () => { r.dmg++; }, { rare: 1 }),
    lvItem('Nano Sağlık', 'Her seviye +100 maksimum can, tam iyileşme, hasar almazsan yenilenir', r.hp, 3, [4000, 6500, 9000], () => { r.hp++; P.hp = 1e9; }),
    lvItem('Titanyum Zırh', 'Maksimum zırh +100 / +150 / +200 ve tam dolu', r.arm, 3, [5500, 8000, 11000], () => { r.arm++; P.armor = 1e9; }),
    { n: 'Roket Deposu', d: '+10 RPG roketi', c: 2200, buy: () => { P.ws[2].reserve += 10; } },
    { n: 'Hava Saldırısı', d: 'Nişan aldığın bölgeye 10 bomba. X tuşu. Maksimum 3', c: 1800, ok: () => P.air < 3, buy: () => { P.air++; } }
  ];
}
function renderShop() {
  $('shCash').textContent = '$' + P.money;
  const tabs = [['gear', 'EKİPMAN'], ['up', 'GELİŞTİR'], ['guns', 'SİLAHLAR'], ['att', 'EKLER'], ['var', 'VARYANT'], ['sp', 'ÖZEL'], ['veh', 'ARAÇ'], ['rare', 'NADİR']];
  $('shTabs').innerHTML = tabs.map(t => `<button class="tab${t[0] === shopTab ? ' on' : ''}${t[0] === 'rare' || t[0] === 'sp' || t[0] === 'var' ? ' gold' : ''}" data-t="${t[0]}">${t[1]}</button>`).join('');
  const items = shopItems(shopTab), grid = $('shGrid'); grid.innerHTML = '';
  items.forEach((it, idx) => {
    const done = it.done, can = !done && P.money >= it.c && (!it.ok || it.ok());
    const d = document.createElement('div'); d.className = 'card' + (shopTab === 'rare' && idx < 3 ? ' rare' : '');
    d.innerHTML = `<h3>${it.n}</h3><p>${it.d}</p><button class="buy" ${can ? '' : 'disabled'}>${done || '$' + it.c}</button>`;
    d.querySelector('button').onclick = () => { if (!can) return; P.money -= it.c; it.buy(); P.hp = Math.min(P.hp, P.maxHp); P.armor = Math.min(P.armor, P.maxArmor); SND.pickup(); hudAmmo(); hudHealth(); renderShop(); };
    grid.appendChild(d);
  });
  $('shTimer').textContent = 'Sonraki dalga: ' + Math.max(0, Math.ceil(G.breakT)) + ' sn';
}
$('shTabs').onclick = e => { const t = e.target.dataset && e.target.dataset.t; if (t) { shopTab = t; renderShop(); } };
$('shClose').onclick = backToGame;
$('shInv').onclick = openInv;
$('shGo').onclick = () => { G.breakT = 0; backToGame(); };

// ---- inventory ----
function renderInv() {
  const w = WEAPONS[invSel], a = P.att[invSel], rpg = w.id === 'rpg';
  $('invWeapons').innerHTML = WEAPONS.map((x, i) => P.owned[i] ? `<button class="tab${i === invSel ? ' on' : ''}" data-w="${i}">${wname(i)}</button>` : '').join('');
  const slots = Object.keys(SLOT_NAMES);
  $('invSlots').innerHTML = slots.map(s => {
    const id = a[s];
    return `<div class="slot${id ? ' full' : ''}"><span>${SLOT_NAMES[s]}</span><b>${rpg ? 'EK TAKILAMAZ' : id ? ATT[id].name : 'BOŞ'}</b>${id && !rpg ? `<button data-un="${s}">ÇIKAR</button>` : ''}</div>`;
  }).join('');
  const st = WS(invSel), base = WEAPONS[invSel], fmt = (v, b, inv) => { const c = v > b * 1.001 ? (inv ? 'bad' : 'good') : v < b * .999 ? (inv ? 'good' : 'bad') : ''; return `<b class="${c}">${v >= 100 ? Math.round(v) : v.toFixed(v < 1 ? 3 : 1)}</b>`; };
  $('invStats').innerHTML = `<div>Hasar ${fmt(st.dmg, base.dmg)}</div><div>Şarjör ${fmt(st.mag, base.mag)}</div><div>Şarjör süresi ${fmt(st.reload, base.reload, true)} sn</div><div>Saçılma ${fmt(st.spread, base.spread, true)}</div><div>Geri tepme ${fmt(st.kick, base.kick, true)}</div><div>Nişan yakınlaştırma ${fmt(75 / st.zoom, 75 / base.zoom)}x</div>`;
  const ids = Object.keys(ATT).filter(id => (P.attInv[id] || 0) > 0);
  $('invStore').innerHTML = rpg ? '<p class="empty">RPG-7\'ye ek parça takılamaz.</p>' : ids.length ? ids.map(id => `<div class="card sm"><h3>${ATT[id].name} <em>x${P.attInv[id]}</em></h3><p>${SLOT_NAMES[ATT[id].slot]}: ${ATT[id].desc}</p><button class="buy" data-eq="${id}">TAK</button></div>`).join('') : '<p class="empty">Depoda ek parça yok. Tüccardan satın al.</p>';
  const RC = RECIPES;
  $('invCraft').innerHTML = RC.map((r, i) => { const can = (P.attInv[r[0]] || 0) > 0 && (P.attInv[r[1]] || 0) > 0 && P.money >= r[3]; return `<div class="card sm"><div class="eq">${ATT[r[0]].name} + ${ATT[r[1]].name}</div><h3>→ ${ATT[r[2]].name}</h3><p>${ATT[r[2]].desc}</p><button class="buy" data-cr="${i}" ${can ? '' : 'disabled'}>BİRLEŞTİR $${r[3]}</button></div>`; }).join('');
  $('invItems').textContent = `El bombası ${P.gren} · Molotof ${P.molo} · Hava saldırısı ${P.air} · Zırh ${Math.ceil(P.armor)}/${P.maxArmor} · $${P.money}`;
}
function fixAmmo(i) { const m = WS(i).mag, s = P.ws[i]; if (s.ammo > m) { s.reserve += s.ammo - m; s.ammo = m; } }
$('invWeapons').onclick = e => { const w = e.target.dataset && e.target.dataset.w; if (w !== undefined) { invSel = +w; renderInv(); } };
$('invSlots').onclick = e => { const s = e.target.dataset && e.target.dataset.un; if (!s) return; const a = P.att[invSel]; P.attInv[a[s]] = (P.attInv[a[s]] || 0) + 1; a[s] = null; invalidateWS(); fixAmmo(invSel); renderInv(); };
$('invStore').onclick = e => {
  const id = e.target.dataset && e.target.dataset.eq; if (!id || WEAPONS[invSel].id === 'rpg') return;
  const a = P.att[invSel], slot = ATT[id].slot; if (a[slot]) P.attInv[a[slot]] = (P.attInv[a[slot]] || 0) + 1;
  P.attInv[id]--; a[slot] = id; invalidateWS(); fixAmmo(invSel); SND.reload(); renderInv();
};
$('invClose').onclick = closeInv;

$('invCraft').onclick = e => {
  const i = e.target.dataset && e.target.dataset.cr; if (i === undefined) return; const r = RECIPES[+i];
  if ((P.attInv[r[0]] || 0) < 1 || (P.attInv[r[1]] || 0) < 1 || P.money < r[3]) return;
  P.attInv[r[0]]--; P.attInv[r[1]]--; P.attInv[r[2]] = (P.attInv[r[2]] || 0) + 1; P.money -= r[3]; SND.pickup(); renderInv();
};

// ---- supply drop (every 2nd wave): very strong free rewards ----
let airdrop = null;
function spawnAirdrop() {
  clearAirdrop(); let x = 0, z = 0;
  for (let i = 0; i < 60; i++) { const a = rand(0, 6.283), r = rand(14, 30); x = P.pos.x + Math.cos(a) * r; z = P.pos.z + Math.sin(a) * r; if (Math.hypot(x, z) < ARENA - 8 && !colliders.some(c => x > c.x0 - 2 && x < c.x1 + 2 && z > c.z0 - 2 && z < c.z1 + 2)) break; }
  const g = new THREE.Group(), box = eMesh(g, BX(1.4, 1.1, 1.4), sm(0x8a2a26), 0, .55, 0); eMesh(g, BX(1.46, .2, 1.46), sm(0xe0b040), 0, 1.0, 0); eMesh(g, BX(.25, 1.12, 1.46), sm(0xe0b040), 0, .55, 0);
  const chute = new THREE.Group(), cm = new THREE.MeshStandardMaterial({ color: 0xe8e0c0, roughness: 1, side: THREE.DoubleSide });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(2.6, 14, 8, 0, 6.283, 0, 1.35), cm); dome.position.y = 4.6; chute.add(dome);
  for (let i = 0; i < 4; i++) { const a = i * 1.571 + .785, l = new THREE.Mesh(BX(.03, 3.6, .03), EM.gun); l.position.set(Math.cos(a) * 1.0, 2.6, Math.sin(a) * 1.0); l.rotation.set(Math.sin(a) * .3, 0, -Math.cos(a) * .3); chute.add(l); }
  g.add(chute);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(.45, .45, 40, 10, 1, true), new THREE.MeshBasicMaterial({ color: 0xc68bff, transparent: true, opacity: .3, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); beam.position.y = 20; g.add(beam);
  const lamp = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: 0xc68bff, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); lamp.scale.setScalar(4); lamp.position.y = 1.5; g.add(lamp);
  g.position.set(x, 80, z); scene.add(g); airdrop = { g, x, z, y: 80, landed: false, chute, beam };
  message('İKRAM DÜŞÜYOR!', 'MOR IŞIĞA GİT · AŞIRI GÜÇLÜ EŞYALAR'); SND.alert();
}
function clearAirdrop() { if (airdrop) { scene.remove(airdrop.g); airdrop = null; } P.dropNear = false; }
function updateAirdrop(dt) {
  P.dropNear = false; const a = airdrop; if (!a) return;
  if (!a.landed) {
    a.y -= (a.y > 10 ? 18 : 6 + a.y * .8) * dt; a.g.position.y = Math.max(0, a.y); a.g.rotation.y += dt * .3; a.chute.rotation.z = Math.sin(a.y * .3) * .06;
    if (a.y <= 0) { a.landed = true; a.g.position.y = 0; a.chute.visible = false; dustPuff(a.x, .2, a.z, 18, C_DUST, 2.4, 4); SND.land(); a.g.rotation.y = rand(0, 6); }
  } else if (!P.dead && Math.hypot(P.pos.x - a.x, P.pos.z - a.z) < (isTouch ? 2.6 : 3)) P.dropNear = true;
}
const DROP_POOL = [
  ['TAM İYİLEŞME', () => { P.hp = P.maxHp; P.armor = P.maxArmor; hudHealth(); }],
  ['CEPHANE DEPOSU', () => { P.owned.forEach((o, i) => { if (o) P.ws[i].reserve += Math.ceil(WEAPONS[i].reserve * 1.5); }); P.gren = 8; P.molo = 8; hudAmmo(); }],
  ['HASAR x1.6 · 120 SN', () => { P.boostT = 120; recomputeStats(); }],
  ['NADİR YÜKSELTME', () => { const u = P.up.rare, k = ['dmg', 'hp', 'arm'].filter(x => u[x] < 3); if (!k.length) { P.money += 6000; return '+$6000'; } const x = k[randi(0, k.length - 1)]; u[x]++; if (x === 'hp') P.hp = 1e9; if (x === 'arm') P.armor = 1e9; recomputeStats(); return ({ dmg: 'Vurucu Mermiler', hp: 'Nano Sağlık', arm: 'Titanyum Zırh' })[x] + ' +1'; }],
  ['SİLAH USTALIĞI', () => { P.owned.forEach((o, i) => { if (o && P.up.wlv[i] < 5) P.up.wlv[i]++; }); recomputeStats(); P.owned.forEach((o, i) => { if (o) { fixAmmo(i); P.ws[i].ammo = WS(i).mag; } }); hudAmmo(); return 'TÜM SİLAHLAR +1 SEVİYE'; }],
  ['SERVET', () => { const c = randi(4000, 7000); P.money += c; return '+$' + c; }],
  ['ELİT EK PARÇA', () => { const ids = ['holo', 'ml', 'drum', 'pro', 'brake', 'smart', 'ex', 'quantum', 'rapid', 'grip2', 'dragon'], top = ['omega', 'nova', 'overdrive', 'titan', 'apex']; for (let i = 0; i < 2; i++) { const id = Math.random() < .3 ? top[randi(0, 4)] : ids[randi(0, ids.length - 1)]; P.attInv[id] = (P.attInv[id] || 0) + 1; } return 'ENVANTERE 2 ELİT PARÇA'; }],
  ['HAVA SALDIRISI x2', () => { P.air = Math.min(5, P.air + 2); }],
  ['VAMPİR MERMİ', () => { if (P.up.vamp < 3) P.up.vamp++; else { P.money += 3000; return '+$3000'; } return 'ÖLDÜRÜNCE CAN KAZAN +1'; }]
];
function giveDropWeapon(i) {
  if (!P.owned[i]) { P.owned[i] = true; P.ws[i] = { ammo: WS(i).mag, reserve: WEAPONS[i].reserve }; hudAmmo(); setTimeout(() => switchWeapon(i), 400); return wname(i) + ' · TUŞ ' + (i + 1); }
  P.ws[i].reserve += WEAPONS[i].reserve; if (P.variant[i] < Math.min(5, MAPI + 1)) { P.variant[i]++; invalidateWS(); return 'VARYANT YÜKSELDİ'; } return '+CEPHANE';
}
function openAirdrop() {
  const a = airdrop; if (!a || !a.landed) return; clearAirdrop(); SND.pickup();
  const pool = DROP_POOL.slice().sort(() => Math.random() - .5).slice(0, 3), un = [5, 6].filter(i => !P.owned[i]);
  if (un.length && Math.random() < .8) { const i = un[randi(0, un.length - 1)]; pool[0] = ['ÖZEL SİLAH: ' + WEAPONS[i].name, () => giveDropWeapon(i)]; }
  else if (!un.length && Math.random() < .35) { const i = randi(5, 6); pool[0] = ['SİLAH GÜCÜ: ' + WEAPONS[i].name, () => giveDropWeapon(i)]; }
  message('İKRAM AÇILDI!', pool.map(p => p[0]).join(' · '));
  for (const [n, f] of pool) { const extra = f(); feedLine('İKRAM: ' + n + (extra ? ' · ' + extra : ''), 'head'); }
  P.hp = Math.min(P.hp, P.maxHp); P.armor = Math.min(P.armor, P.maxArmor); hudAmmo(); hudHealth(); explodeSpark(a.x, a.z);
}
function explodeSpark(x, z) { sparks(x, 1, z, 14, 6); dustPuff(x, .5, z, 8, C_DUST, 1.4, 2.4); }
