'use strict';
/* =====================================================================
   AutoAimController
   ---------------------------------------------------------------------
   - Nearest *visible* enemy ko lock karta hai (radius + on-screen + line-of-sight).
   - Gun ko lock ki taraf smooth (exp-lerp, shortest-angle) ghumata hai, instant snap nahi.
   - Manual input (fire-button drag / swipe / mouse) ho to assist band (manual priority);
     manual khatam hone ke `resumeDelay` sec baad wapas chalu.
   - Sab tuning `AutoAimController.cfg` se. Top-down aur side-scroll dono ke liye
     sirf `screenOffset()` aur `angleTo()` badalne hain (neeche dekho).
   ===================================================================== */
const AutoAimController={
  /* ---------- tuning (public) ---------- */
  cfg:{
    enabled:true,
    radius:400,              // lock radius (world px)
    clampToWeaponRange:true, // radius ko hathiyaar ki range se upar na jaane do
    onScreenOnly:true,       // sirf camera ke andar dikhne wale enemy
    screenMargin:0,          // screen ke bahar itna extra (world px) bhi "visible" maano
    requireLOS:true,         // deewar / glue wall / smoke beech mein ho to lock nahi
    ignoreCamo:true,         // camo wale enemy sirf paas aane par (110px) lock hote hain
    lerpSpeed:14,            // jitna zyada, utna tez rotate (1/sec). 6=dheema, 20=snappy
    maxTurnDegPerSec:900,    // rotation ki hard limit
    stickyBias:.75,          // naya target tabhi lo jab current se itna (x) nazdeek ho -> flicker nahi
    scanInterval:.1,         // kitni der mein dobara nearest dhoondhna (sec)
    resumeDelay:.5,          // manual chhodne ke baad itni der baad assist wapas (sec)
    fireConeDeg:10,          // assisted fire tabhi jab gun lock ke itne degree ke andar (paas ke enemy par max ye)
    minConeDeg:1.5,          // door ke enemy par cone isse chhota nahi hoga
    autoFire:false           // true = enemy radius mein aate hi bina touch ke fire
  },

  /* ---------- runtime state ---------- */
  target:null,
  manualT:0,
  scanT:0,

  /* ---------- engine adapters (2D side-scroller mein yahi 2 functions badlo) ---------- */
  // enemy ka screen-offset (world units) camera centre se
  screenOffset(p,t){return[t.x-cam.x,(t.y-(p.fl|0)*FH)-cam.y]},
  // p se t ki taraf angle (radians)
  angleTo(p,t){return Math.atan2(t.y-p.y,t.x-p.x)},

  /* ---------- API ---------- */
  get assistReady(){return this.cfg.enabled&&this.manualT<=0},

  reset(){this.target=null;this.manualT=0;this.scanT=0},

  range(p){
    const c=this.cfg;
    return c.clampToWeaponRange?Math.min(c.radius,curW(p).range*.95):c.radius;
  },

  // enemy `t` p ke liye abhi lock-yogya hai?
  valid(p,t,slack){
    const c=this.cfg;
    if(!t||!t.alive||t.team===p.team||(t.fl|0)!==(p.fl|0))return false;
    const d=Math.hypot(t.x-p.x,t.y-p.y);
    if(d>this.range(p)*(slack||1))return false;
    if(c.ignoreCamo&&t.camo>0&&d>110)return false;
    if(c.onScreenOnly){
      // purane target ko screen-edge par thoda extra (40px) -> camera kick/shake se lock na toote
      const o=this.screenOffset(p,t),m=c.screenMargin+(slack>1?40:0);
      if(Math.abs(o[0])>VW/(2*S)+m||Math.abs(o[1])>VH/(2*S)+m)return false;
    }
    if(c.requireLOS&&!los(p.x,p.y,t.x,t.y,p.fl))return false;
    return true;
  },

  // sabse nazdeek valid enemy (current target ko thoda sticky rakhta hai)
  scan(p){
    const c=this.cfg;let best=null,bd=Infinity;
    for(const t of players){
      if(t===p)continue;
      if(!this.valid(p,t,t===this.target?1.1:1))continue;   // current target ko hysteresis milti hai
      const d=Math.hypot(t.x-p.x,t.y-p.y);
      if(d<bd){bd=d;best=t}
    }
    const cur=this.target;
    if(cur&&best&&best!==cur){
      const cd=Math.hypot(cur.x-p.x,cur.y-p.y);
      if(bd>cd*c.stickyBias)best=cur;      // naya enemy kaafi nazdeek nahi -> purana hi rakho
    }
    this.target=best;
  },

  // gun lock par kitna aligned hai (radians, 0 = bilkul seedha)
  aimError(p){return this.target?Math.abs(angDiff(p.ang,this.angleTo(p,this.target))):0},
  // fire cone door ke enemy par apne-aap tang: enemy ke size ke andar (max fireConeDeg, min minConeDeg)
  aimed(p){
    const t=this.target;if(!t)return false;
    const c=this.cfg,d=Math.max(1,Math.hypot(t.x-p.x,t.y-p.y));
    const cone=Math.min(c.fireConeDeg*Math.PI/180,Math.max(c.minConeDeg*Math.PI/180,Math.atan2((t.r||13)*.9,d)));
    return this.aimError(p)<=cone;
  },

  /* Har frame bulao.
     manualNow : player abhi khud aim kar raha hai (drag / swipe / mouse)
     rotate    : target ki taraf gun ghumana hai (tap-fire ya auto-fire chal raha hai) */
  update(dt,p,manualNow,rotate){
    const c=this.cfg;
    if(manualNow)this.manualT=c.resumeDelay;
    else if(this.manualT>0)this.manualT=Math.max(0,this.manualT-dt);
    if(!c.enabled||manualNow||this.manualT>0||!p.alive){this.target=null;return}
    if(!this.valid(p,this.target,1.1))this.target=null;   // radius edge par flicker na ho (hysteresis)
    this.scanT-=dt;
    if(this.scanT<=0||!this.target){this.scanT=c.scanInterval;this.scan(p)}
    if(rotate&&this.target)this.rotateToward(dt,p);
  },

  // smooth rotation: angle ka shortest-path exp-lerp (2D mein ye Slerp ke barabar hai)
  rotateToward(dt,p){
    const c=this.cfg,df=angDiff(p.ang,this.angleTo(p,this.target));
    const k=1-Math.exp(-c.lerpSpeed*dt),cap=c.maxTurnDegPerSec*Math.PI/180*dt;
    p.ang+=clamp(df*k,-cap,cap);
  },

  /* World-space overlay: lock ring (render.js ke world transform ke andar bulao) */
  drawWorld(c){
    const t=this.target;
    if(!t||!t.alive)return;
    const ph=time*3.2;
    c.save();
    c.strokeStyle='rgba(255,93,108,.95)';c.lineWidth=2.5;c.setLineDash([9,7]);c.lineDashOffset=-ph*8;
    c.beginPath();c.ellipse(t.x,t.y+1,21,9.5,0,0,TAU);c.stroke();
    c.setLineDash([]);c.lineWidth=2;
    for(let i=0;i<4;i++){                                  // 4 corner ticks
      const a=i*Math.PI/2+Math.PI/4,x=t.x+Math.cos(a)*27,y=t.y+1+Math.sin(a)*12;
      c.beginPath();c.moveTo(t.x+Math.cos(a)*21,t.y+1+Math.sin(a)*9.5);c.lineTo(x,y);c.stroke();
    }
    c.restore();
  }
};
