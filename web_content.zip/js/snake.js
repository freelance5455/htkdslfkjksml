/**
 * Snake Escape — Snake Entity & Procedural SVG Renderer
 * Handles smooth animated slithering, head rotation, blinking eyes, flicking tongue,
 * portal teleportation, and celebration/failure states.
 */
(function() {
  'use strict';

  const COLOR_PALETTES = {
    green: {
      skinGrad: ['#7df73e', '#36b813', '#1b6e08'],
      belly: '#fff7a8',
      cheek: 'rgba(255, 105, 180, 0.5)',
      pupil: '#0d2e06',
      eyeShine: '#ffffff',
      tongue: '#ff3366',
      outline: '#144d06'
    },
    blue: {
      skinGrad: ['#52d9fc', '#2196f3', '#125aa0'],
      belly: '#d4f6ff',
      cheek: 'rgba(255, 105, 180, 0.45)',
      pupil: '#062647',
      eyeShine: '#ffffff',
      tongue: '#ff3366',
      outline: '#093a6b'
    },
    orange: {
      skinGrad: ['#ffbb45', '#f39c12', '#b35607'],
      belly: '#fff0cf',
      cheek: 'rgba(255, 80, 100, 0.5)',
      pupil: '#451c04',
      eyeShine: '#ffffff',
      tongue: '#ff2255',
      outline: '#6e3003'
    },
    purple: {
      skinGrad: ['#c973fc', '#9c27b0', '#601170'],
      belly: '#f4dcff',
      cheek: 'rgba(255, 105, 180, 0.45)',
      pupil: '#2c0733',
      eyeShine: '#ffffff',
      tongue: '#ff3366',
      outline: '#3e0a4a'
    }
  };

  class Snake {
    constructor(data) {
      this.id = data.id || 'snake-1';
      this.color = data.color || 'green';
      this.palette = COLOR_PALETTES[this.color] || COLOR_PALETTES.green;
      this.segments = JSON.parse(JSON.stringify(data.segments || [{ x: 1, y: 1 }]));
      this.exit = { ...data.exit };
      this.escaped = false;
      this.isDead = false;
      this.isSelected = false;

      // Animation state
      this.isMoving = false;
      this.prevSegments = JSON.parse(JSON.stringify(this.segments));
      this.targetSegments = null;
      this.animProgress = 1.0;
      this.direction = this._inferInitialDirection();
      this.headRotation = this._getAngleFromDirection(this.direction);

      // Blinking timer
      this.isBlinking = false;
      this._startBlinkCycle();
    }

    _startBlinkCycle() {
      const scheduleNextBlink = () => {
        const delay = 2500 + Math.random() * 3000;
        setTimeout(() => {
          this.isBlinking = true;
          setTimeout(() => {
            this.isBlinking = false;
            scheduleNextBlink();
          }, 160);
        }, delay);
      };
      scheduleNextBlink();
    }

    _inferInitialDirection() {
      if (this.segments.length > 1) {
        const head = this.segments[0];
        const neck = this.segments[1];
        if (head.x > neck.x) return 'RIGHT';
        if (head.x < neck.x) return 'LEFT';
        if (head.y > neck.y) return 'DOWN';
        if (head.y < neck.y) return 'UP';
      }
      return 'RIGHT';
    }

    _getAngleFromDirection(dir) {
      switch (dir) {
        case 'UP': return 270;
        case 'DOWN': return 90;
        case 'LEFT': return 180;
        case 'RIGHT': default: return 0;
      }
    }

    getHead() {
      return this.segments[0];
    }

    /**
     * Executes move to target cell with easing interpolation
     */
    moveTo(targetX, targetY, duration = 140, onComplete = null) {
      if (this.isMoving || this.escaped) return;

      this.isMoving = true;
      this.prevSegments = JSON.parse(JSON.stringify(this.segments));

      // Calculate direction
      const head = this.segments[0];
      if (targetX > head.x) this.direction = 'RIGHT';
      else if (targetX < head.x) this.direction = 'LEFT';
      else if (targetY > head.y) this.direction = 'DOWN';
      else if (targetY < head.y) this.direction = 'UP';

      this.headRotation = this._getAngleFromDirection(this.direction);

      // Create new segments (head at target, subsequent segments follow previous)
      const newSegments = [{ x: targetX, y: targetY }];
      for (let i = 0; i < this.segments.length - 1; i++) {
        newSegments.push({ ...this.segments[i] });
      }

      this.targetSegments = newSegments;
      this.animProgress = 0;

      const startTime = performance.now();

      const step = (currentTime) => {
        const elapsed = currentTime - startTime;
        let p = elapsed / duration;

        if (p >= 1.0) {
          p = 1.0;
          this.animProgress = 1.0;
          this.segments = this.targetSegments;
          this.prevSegments = JSON.parse(JSON.stringify(this.segments));
          this.isMoving = false;
          if (onComplete) onComplete();
          return;
        }

        // Ease Out Quad
        this.animProgress = p * (2 - p);
        requestAnimationFrame(step);
      };

      requestAnimationFrame(step);
    }

    /**
     * Teleports snake head to a new position (used by portals)
     */
    teleportHead(destX, destY) {
      this.segments[0] = { x: destX, y: destY };
      this.prevSegments = JSON.parse(JSON.stringify(this.segments));
      this.animProgress = 1.0;
      this.isMoving = false;
    }

    /**
     * Renders this snake onto the SVG board
     */
    render(svg, cellSize) {
      if (this.escaped) return;

      const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      group.setAttribute('class', `snake-entity ${this.id} ${this.isDead ? 'snake-dead' : ''}`);
      group.setAttribute('data-id', this.id);
      group.style.cursor = 'pointer';

      // Calculate current interpolated positions for all segments
      const currentPos = [];
      for (let i = 0; i < this.segments.length; i++) {
        const from = this.prevSegments[i] || this.segments[i];
        const to = this.targetSegments ? this.targetSegments[i] : this.segments[i];
        const x = from.x + (to.x - from.x) * this.animProgress;
        const y = from.y + (to.y - from.y) * this.animProgress;
        currentPos.push({
          cx: x * cellSize + cellSize / 2,
          cy: y * cellSize + cellSize / 2
        });
      }

      // 1. Draw Snake Body Path
      if (currentPos.length > 1) {
        let pathD = `M ${currentPos[0].cx} ${currentPos[0].cy}`;
        for (let i = 1; i < currentPos.length; i++) {
          pathD += ` L ${currentPos[i].cx} ${currentPos[i].cy}`;
        }

        // Outer body stroke (main skin)
        const bodyPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        bodyPath.setAttribute('d', pathD);
        bodyPath.setAttribute('fill', 'none');
        bodyPath.setAttribute('stroke', this.palette.skinGrad[1]);
        bodyPath.setAttribute('stroke-width', (cellSize * 0.58).toFixed(1));
        bodyPath.setAttribute('stroke-linecap', 'round');
        bodyPath.setAttribute('stroke-linejoin', 'round');
        group.appendChild(bodyPath);

        // Belly highlight line
        const bellyPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        bellyPath.setAttribute('d', pathD);
        bellyPath.setAttribute('fill', 'none');
        bellyPath.setAttribute('stroke', this.palette.belly);
        bellyPath.setAttribute('stroke-width', (cellSize * 0.22).toFixed(1));
        bellyPath.setAttribute('stroke-linecap', 'round');
        bellyPath.setAttribute('stroke-linejoin', 'round');
        bellyPath.setAttribute('opacity', '0.85');
        group.appendChild(bellyPath);
      }

      // 2. Selected Snake Glow / Pulsing Ring Indicator
      if (this.isSelected) {
        const selRing = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        selRing.setAttribute('cx', currentPos[0].cx);
        selRing.setAttribute('cy', currentPos[0].cy);
        selRing.setAttribute('r', cellSize * 0.48);
        selRing.setAttribute('fill', 'none');
        selRing.setAttribute('stroke', '#00f3ff');
        selRing.setAttribute('stroke-width', '3.5');
        selRing.setAttribute('stroke-dasharray', '5 3');
        selRing.setAttribute('class', 'hint-path-line');
        group.appendChild(selRing);
      }

      // 3. Snake Head (Expressive cartoon face)
      const headPos = currentPos[0];
      const headGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      headGroup.setAttribute('transform', `translate(${headPos.cx}, ${headPos.cy}) rotate(${this.headRotation})`);

      // Forked Tongue (flicks when moving)
      const tongue = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      tongue.setAttribute('class', 'tongue-anim');
      tongue.setAttribute('d', `M ${cellSize * 0.3} 0 Q ${cellSize * 0.55} 0 ${cellSize * 0.65} -2 M ${cellSize * 0.65} -2 L ${cellSize * 0.75} -5 M ${cellSize * 0.65} -2 L ${cellSize * 0.75} 2`);
      tongue.setAttribute('fill', 'none');
      tongue.setAttribute('stroke', this.palette.tongue);
      tongue.setAttribute('stroke-width', '2.5');
      tongue.setAttribute('stroke-linecap', 'round');
      headGroup.appendChild(tongue);

      // Main Head Circle
      const headCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      headCircle.setAttribute('cx', '0');
      headCircle.setAttribute('cy', '0');
      headCircle.setAttribute('r', cellSize * 0.36);
      headCircle.setAttribute('fill', this.palette.skinGrad[0]);
      headCircle.setAttribute('stroke', this.palette.outline);
      headCircle.setAttribute('stroke-width', '2');
      headGroup.appendChild(headCircle);

      // Cute Cheek Blushes
      [-1, 1].forEach((side) => {
        const blush = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        blush.setAttribute('cx', `${cellSize * 0.05}`);
        blush.setAttribute('cy', `${side * cellSize * 0.22}`);
        blush.setAttribute('r', `${cellSize * 0.07}`);
        blush.setAttribute('fill', this.palette.cheek);
        headGroup.appendChild(blush);
      });

      // Big Expressive Eyes with blinking
      if (!this.isBlinking && !this.isDead) {
        [-1, 1].forEach((side) => {
          const eyeY = side * (cellSize * 0.16);
          const eyeX = cellSize * 0.08;

          const eyeWhite = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          eyeWhite.setAttribute('cx', eyeX);
          eyeWhite.setAttribute('cy', eyeY);
          eyeWhite.setAttribute('r', cellSize * 0.12);
          eyeWhite.setAttribute('fill', '#ffffff');
          eyeWhite.setAttribute('stroke', this.palette.outline);
          eyeWhite.setAttribute('stroke-width', '1.2');
          headGroup.appendChild(eyeWhite);

          const pupil = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          pupil.setAttribute('cx', eyeX + 1.5);
          pupil.setAttribute('cy', eyeY);
          pupil.setAttribute('r', cellSize * 0.065);
          pupil.setAttribute('fill', this.palette.pupil);
          headGroup.appendChild(pupil);

          const shine = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          shine.setAttribute('cx', eyeX);
          shine.setAttribute('cy', eyeY - 2);
          shine.setAttribute('r', cellSize * 0.035);
          shine.setAttribute('fill', this.palette.eyeShine);
          headGroup.appendChild(shine);
        });
      } else if (this.isDead) {
        // X eyes on trap death
        [-1, 1].forEach((side) => {
          const eyeY = side * (cellSize * 0.16);
          const eyeX = cellSize * 0.08;
          const xPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          xPath.setAttribute('d', `M ${eyeX - 3} ${eyeY - 3} L ${eyeX + 3} ${eyeY + 3} M ${eyeX + 3} ${eyeY - 3} L ${eyeX - 3} ${eyeY + 3}`);
          xPath.setAttribute('stroke', '#000000');
          xPath.setAttribute('stroke-width', '2');
          xPath.setAttribute('stroke-linecap', 'round');
          headGroup.appendChild(xPath);
        });
      } else {
        // Blink slits
        [-1, 1].forEach((side) => {
          const eyeY = side * (cellSize * 0.16);
          const eyeX = cellSize * 0.08;
          const slit = document.createElementNS('http://www.w3.org/2000/svg', 'line');
          slit.setAttribute('x1', eyeX - 3);
          slit.setAttribute('y1', eyeY);
          slit.setAttribute('x2', eyeX + 3);
          slit.setAttribute('y2', eyeY);
          slit.setAttribute('stroke', this.palette.outline);
          slit.setAttribute('stroke-width', '2');
          slit.setAttribute('stroke-linecap', 'round');
          headGroup.appendChild(slit);
        });
      }

      group.appendChild(headGroup);
      svg.appendChild(group);
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.Snake = Snake;
})();
