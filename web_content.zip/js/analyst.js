/* يمكن هدف؟ — "شرح المحلل الذكي": a human analyst explains the match on an electronic video wall */
(function () {
  const { ai, viz, api } = YH; const esc = viz.esc; const AR = ai.AR;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // design size of the video wall (scaled to fit any screen); narrower on phones so text stays readable
  const dims = () => innerWidth < 900 ? [480, 420] : [640, 400];
  let cur = null;

  const ROW_AR = (li, n) => li === 0 ? 'الحارس' : li === n - 1 ? 'الهجوم' : li === 1 ? 'الدفاع' : n === 5 && li === 3 ? 'وسط متقدم' : 'الوسط';
  const joinAr = arr => arr.length <= 1 ? (arr[0] || '') : arr.slice(0, -1).join('، ') + ' و' + arr[arr.length - 1];
  const shortN = n => { const p = (n || '').split(' ').filter(Boolean); return p.length > 1 ? p.slice(-1)[0] : (n || ''); };

  /* ---------- extra wall scenes: lineups with photos + team stats ---------- */
  function extraScenes(ctx) {
    const { ev, sum, c, ppH, ppA, lmH, lmA, mode } = ctx;
    const T = s => AR(ev[s].name);
    const rs = sum.rosters || [];
    const liveXI = s => { const r = rs.find(x => x.homeAway === s); return r && (r.roster || []).some(p => p.starter) ? r : null; };
    const entry = s => liveXI(s) || ((s === 'home' ? lmH : lmA) || {}).roster || null;
    const out = { lineups: [], stats: null };
    ['home', 'away'].forEach(s => {
      const toks = YH.studio.xi(entry(s), s, s === 'home' ? ppH : ppA, c[s]);
      if (!toks.length) return;
      const n = Math.max(...toks.map(t => t.row)) + 1;
      const rows = Array.from({ length: n }, (_, i) => toks.filter(t => t.row === i).sort((a, b) => a.y0 - b.y0));
      const fm = (entry(s) || {}).formation || '';
      const card = t => `<div class="lu-p" id="lu_${t.key}"><span class="lu-ph">${t.img ? `<img src="${esc(t.img)}" alt="" loading="lazy" onerror="this.remove()">` : ''}<i>${esc(t.num || '')}</i></span><b>${esc(shortN(t.ar))}</b></div>`;
      const html = `<div class="lu" style="--tc:${c[s]}"><div class="lu-h">${ev[s].logo ? `<img class="crest" src="${esc(ev[s].logo)}" alt="">` : ''}<b>${esc(T(s))}</b>${fm ? `<span class="lu-fm" dir="ltr">${esc(fm)}</span>` : ''}<small>${liveXI(s) ? 'التشكيلة الرسمية' : 'التشكيلة المتوقعة'}</small></div>
        <div class="lu-rows">${rows.slice().reverse().map((row, ri) => { const li = n - 1 - ri; return `<div class="lu-row" id="lur_${s}_${li}"><span class="lu-lab">${ROW_AR(li, n)}</span><div class="lu-line">${row.map(card).join('')}</div></div>`; }).join('')}</div></div>`;
      const q = id => () => document.getElementById(id);
      const lines = [{ t: `خلّونا نشوف تشكيلة ${T(s)}${fm ? `، بخطة ${fm.split('-').join(' ')}` : ''}${liveXI(s) ? '.' : '، وهي التشكيلة المتوقعة حسب آخر مباراة.'}`, at: q(`lur_${s}_${n - 1}`) }];
      rows.forEach((row, li) => {
        const names = joinAr(row.map(t => t.ar));
        const lab = ROW_AR(li, n);
        lines.push({ t: li === 0 ? `بالحراسة ${names}.` : li === n - 1 ? `وبالهجوم ${names}.` : `${lab === 'الدفاع' ? 'خط الدفاع' : 'بخط ' + lab}: ${names}.`, at: q(`lur_${s}_${li}`) });
      });
      out.lineups.push({ t: `تشكيلة ${T(s)}`, html, lines });
    });
    if (mode !== 'pre') {
      const ts = ai.teamStats(sum);
      const keys = ['possessionPct', 'totalShots', 'shotsOnTarget', 'wonCorners', 'passPct', 'foulsCommitted'].filter(k => ts.home[k] != null || ts.away[k] != null);
      if (keys.length >= 3) {
        const row = k => { const h = ts.home[k] || 0, a = ts.away[k] || 0, tot = h + a || 1, pc = k.endsWith('Pct') ? '%' : '';
          return `<div class="ws-row" id="ws_${k}"><b>${h}${pc}</b><span>${YH.STAT_AR[k] || k}</span><b>${a}${pc}</b><div class="ws-bar"><i style="width:${(h / tot * 100).toFixed(1)}%;background:${c.home}"></i><i style="width:${(a / tot * 100).toFixed(1)}%;background:${c.away}"></i></div></div>`; };
        const pos = ts.home.possessionPct, sh = [ts.home.totalShots || 0, ts.away.totalShots || 0], on = [ts.home.shotsOnTarget || 0, ts.away.shotsOnTarget || 0];
        const lines = [];
        if (pos != null) lines.push({ t: `الاستحواذ: ${T('home')} ${pos} بالمية و${T('away')} ${ts.away.possessionPct} بالمية.`, at: () => document.getElementById('ws_possessionPct') });
        lines.push({ t: `بالتسديد، ${T('home')} سدد ${sh[0]} مرات، منها ${on[0]} على المرمى، و${T('away')} سدد ${sh[1]}، منها ${on[1]} على المرمى.`, at: () => document.getElementById('ws_totalShots') });
        if (ts.home.wonCorners != null) lines.push({ t: `والركنيات ${ts.home.wonCorners} مقابل ${ts.away.wonCorners || 0}.`, at: () => document.getElementById('ws_wonCorners') });
        out.stats = { t: 'أرقام المباراة', html: `<div class="ws"><div class="ws-teams"><span style="--tc:${c.home}">${esc(T('home'))}</span><span style="--tc:${c.away}">${esc(T('away'))}</span></div>${keys.map(row).join('')}</div>`, lines };
      }
    }
    return out;
  }

  /* real goal clips from the match feed (ESPN mp4, foreign commentary) */
  function goalClips(sum) {
    return (sum.videos || []).map(v => { const L = v.links || {}; const src = (L.source && ((L.source.HD && L.source.HD.href) || L.source.href)) || (L.mobile && L.mobile.source && L.mobile.source.href);
      return src && /\.mp4/.test(src) ? { title: v.headline || v.title || 'فيديو', src, thumb: v.thumbnail, dur: v.duration || 0, goal: /goal|scores|score/i.test(v.headline || ''), hl: /highlight/i.test(v.headline || '') } : null; }).filter(Boolean);
  }
  function goalClip(ctx, g) {
    const all = goalClips(ctx.sum); if (!all.length) return null;
    const last = (g.who || '').split(' ').filter(Boolean).slice(-1)[0] || '#';
    const norm = x => (x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    return all.find(x => x.goal && norm(x.title).includes(norm(last))) || all.find(x => x.hl) || null;
  }
  const TRANS = ['هسه ننتقل لـ', 'خلّونا نروح لـ', 'النقطة الجاية: ', 'وهسه نحچي عن ', 'ننتقل لـ'];
  const safe = f => { try { return f() || []; } catch (e) { console.warn(e); return []; } };
  function sceneList(ctx, A) {
    const { scenes } = YH.studio.buildScenes(ctx);
    const ex = extraScenes(ctx); const TX = YH.tactics; const pre = ctx.mode === 'pre';
    const by = re => scenes.filter(s => re.test(s.t));
    const deep = safe(() => TX.deepScenes(ctx)), rep = safe(() => TX.replayScenes(ctx)), pe = safe(() => TX.predScenes(ctx));
    const peX = pe.filter(s => /xG/.test(s.t)), peP = pe.filter(s => !/xG/.test(s.t));
    const intro = scenes[0];
    const list = (pre
      ? [intro, ...ex.lineups, ...by(/^شلون يلعب/), ...by(/المواجهة التكتيكية/), ...deep, ...by(/توقعي/), ...peP]
      : [intro, ...by(/هسه بالملعب/), ...(ex.stats ? [ex.stats] : []), ...rep, ...ex.lineups, ...by(/المواجهة التكتيكية/), ...deep, ...by(/الأهداف المتوقعة/), ...peX.slice(0, 1), ...by(/من سيطر/), ...by(/نقاط التحوّل/), ...by(/نجم/), ...by(/توقعي/), ...peP]).filter(Boolean);
    const PR = YH.presenter; const seen = new Set();
    const ART = [[/البناء/, 'build'], [/الضغط/, 'press'], [/الأطراف/, 'wing'], [/الكرات الطويلة|التحولات/, 'counter'], [/الثابتة/, 'set'], [/مناطق التسديد|xG|الأهداف المتوقعة/, 'shot'], [/^إعادة الهدف/, 'goal']];
    const artOf = t => { for (const [re, k] of ART) if (re.test(t)) return k; return null; };
    // keep it short: at most 2 sentences per scene (goal replays keep their animated steps)
    const MAXL = t => /^إعادة الهدف/.test(t) ? 4 : /^تشكيلة/.test(t) ? 1 : 2;
    let k = 0;
    const out = list.map((s, i) => {
      const who = PR.forScene(s.t); const Aw = PR.byId(who);
      let lines = s.lines.slice(0, MAXL(s.t));
      if (/^تشكيلة/.test(s.t) && s.lines.length > 1) { const atk = s.lines[s.lines.length - 1]; lines = [{ ...s.lines[0], t: s.lines[0].t + ' ' + atk.t.replace(/^وبالهجوم/, 'والهجوم بقيادة') }]; }
      const sc = { ...s, who, art: s.art || artOf(s.t), lines };
      if (!lines.length) return sc;
      const hi = !seen.has(who) && i > 0 ? `وياكم ${Aw.name}، ${Aw.role}. ` : ''; seen.add(who);
      if (i === 0) return { ...sc, lines: [{ t: `أهلاً بيكم بستوديو يمكن هدف، معكم ${Aw.name}. اليوم عدنا فريق كامل من المحللين، كل واحد يشرح جزء.`, at: () => document.querySelector('.sc-intro') }, ...lines.slice(0, 1)] };
      const l0 = lines[0];
      const pfx = hi || (/^تشكيلة|^إعادة/.test(s.t) ? '' : TRANS[k++ % TRANS.length] + s.t.replace(/[؟?]$/, '') + '. ');
      return { ...sc, lines: [{ ...l0, t: pfx + l0.t }, ...lines.slice(1)] };
    });
    return { scenes: out };
  }

  /* split speech into sentences so the voice starts fast and the subtitle stays in sync */
  function sentences(text) {
    const raw = text.split(/(?<=[.؟!])\s+/).filter(Boolean); const out = [];
    raw.forEach(p => { if (out.length && (out[out.length - 1].length < 28 || p.length < 14)) out[out.length - 1] += ' ' + p; else out.push(p); });
    return out.length ? out : [text];
  }
  function wordsHTML(t) {
    const re = /\S+/g; let m; const parts = [];
    while ((m = re.exec(t))) parts.push({ w: m[0], o: m.index });
    const html = []; for (let i = 0; i < parts.length; i++) {
      if (/^\d$/.test(parts[i].w) && parts[i + 2] && /^\d$/.test(parts[i + 1].w) && /^\d[.،]?$/.test(parts[i + 2].w)) {
        let j = i; const g = []; while (j < parts.length && /^\d[.،]?$/.test(parts[j].w)) { g.push(parts[j].w.replace(/[.،]/, '')); const end = /[.،]$/.test(parts[j].w); j++; if (end) break; }
        html.push(`<span class="w" data-o="${parts[i].o}"><bdi dir="ltr">${g.join('-')}</bdi></span>`); i = j - 1; continue;
      }
      html.push(`<span class="w" data-o="${parts[i].o}">${esc(parts[i].w)}</span>`);
    }
    return html.join(' ');
  }
  const VOICE_RE = [/Hamed|Shakir|Naayf|Fahed|Hamdan|Omar|Tarik|Bassel|Taim|Rami|Moaz|Jamal|Maged/i, /natural|neural|online/i, /google/i];
  function pickVoice(V) {
    if (!('speechSynthesis' in window)) return; const vs = (speechSynthesis.getVoices() || []).filter(x => /^ar/i.test(x.lang));
    if (!vs.length) return;
    const score = v => (VOICE_RE[0].test(v.name) ? 4 : 0) + (VOICE_RE[1].test(v.name) ? 3 : 0) + (VOICE_RE[2].test(v.name) ? 2 : 0) + (/SA|AE|EG|IQ|JO|KW/i.test(v.lang) ? 1 : 0) - (v.localService === false && !VOICE_RE[1].test(v.name) && !VOICE_RE[2].test(v.name) ? 1 : 0);
    V.v = vs.slice().sort((a, b) => score(b) - score(a))[0]; V.ready = true;
  }

  /* ---------- the studio overlay ---------- */
  function open(ctx) {
    close();
    ctx = { ...ctx };
    const { ev } = ctx;
    const el = document.createElement('div');
    el.className = 'as'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'شرح المحلل الذكي');
    const crest = s => ev[s].logo ? `<img class="crest" src="${esc(ev[s].logo)}" alt="">` : '';
    const score = ev.state === 'pre' ? '<i class="as-vs">ضد</i>' : `<b class="as-sc" dir="ltr">${ev.home.score} - ${ev.away.score}</b>`;
    const MK = YH.tactics.marks(ctx);
    const mkHTML = MK ? MK.list.map(x => `<button class="mk mk-${x.k}" data-m="${Math.floor(x.m)}" style="right:${(x.m / MK.max * 100).toFixed(2)}%;--tc:${ctx.c[x.side]}" aria-label="الدقيقة ${Math.floor(x.m)}"></button>`).join('') : '';
    el.innerHTML = `
      <div class="as-bg" aria-hidden="true"><i class="as-floor"></i></div>
      <header class="as-top">
        <span class="as-live"><span class="pulse"></span>المحلل الذكي</span>
        <div class="as-match">${crest('home')}<span>${esc(AR(ev.home.name))}</span>${score}<span>${esc(AR(ev.away.name))}</span>${crest('away')}</div>
        <button class="as-ask" data-c="ask" aria-label="اسأل المحلل"><svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/><path d="M10 9.2a2 2 0 113 1.7c-.6.4-1 .8-1 1.5"/><circle cx="12" cy="14.4" r=".4"/></svg><span>اسأل المحلل</span></button>
        <button class="as-x" data-c="close" aria-label="إغلاق الشرح"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
      </header>
      <div class="as-set">
        <div class="as-wallbox"><div class="as-wall"><div class="as-canvas">
          <div class="as-wh"><span class="as-wt"></span><span class="as-step"></span></div>
          <div class="as-stage"></div>
          <div class="as-dots"></div>
        </div></div></div>
        <div class="as-host"><div class="as-person"></div><div class="as-tag"><b class="as-name"></b><small class="as-role"></small></div></div>
      </div>
      <div class="as-sub" aria-live="polite"><p class="as-subt"></p></div>
      ${MK ? `<div class="as-tl"><span class="as-tl-l">خط المباراة</span><div class="as-tl-tr"><div class="as-tl-mk">${mkHTML}</div><input type="range" dir="rtl" min="0" max="${MK.max}" step="1" value="0" aria-label="اختر دقيقة من المباراة"></div><output class="as-tl-o" dir="ltr">—</output></div>` : ''}
      <footer class="as-ctrl">
        <div class="as-pick" aria-label="فريق المحللين">${YH.presenter.ANALYSTS.map(a => `<button data-a="${a.id}" style="--tone:${a.tone}" aria-label="${esc(a.name + ' — ' + a.role)}" title="${esc(a.name)}"><img src="${a.head}" alt=""></button>`).join('')}</div>
        <div class="as-play">
          <button class="as-btn" data-c="prev" aria-label="المشهد السابق"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></button>
          <button class="as-btn as-main" data-c="play" aria-label="إيقاف مؤقت"><svg viewBox="0 0 24 24" class="i-pause"><path d="M9 6v12M15 6v12"/></svg><svg viewBox="0 0 24 24" class="i-play"><path d="M16 6v12L7 12z"/></svg></button>
          <button class="as-btn" data-c="next" aria-label="المشهد التالي"><svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg></button>
        </div>
        <div class="as-tog">
          <button class="as-btn" data-c="music" aria-label="الموسيقى" aria-pressed="true"><svg viewBox="0 0 24 24"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg></button>
          <button class="as-btn" data-c="voice" aria-label="صوت المحلل" aria-pressed="true"><svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 8.5a4.5 4.5 0 010 7"/></svg></button>
        </div>
      </footer>
      <div class="as-qa" hidden>
        <div class="as-qa-h"><b>اسأل المحلل</b><small>يجاوب من بيانات المباراة نفسها</small><button class="as-x sm" data-c="askx" aria-label="إغلاق"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
        <form class="as-qf"><input type="text" enterkeyhint="send" autocomplete="off" placeholder="مثلاً: ليش خسر الفريق السيطرة؟" aria-label="سؤالك للمحلل">${(window.SpeechRecognition || window.webkitSpeechRecognition) ? '<button type="button" class="as-btn" data-c="mic" aria-label="اسأل بصوتك"><svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/></svg></button>' : ''}<button type="submit" class="as-send">اسأل</button></form>
        <div class="as-chips">${YH.qa.suggestions(ctx).map(s => `<button type="button" data-q="${esc(s)}">${esc(s)}</button>`).join('')}</div>
      </div>
      <div class="as-focus" aria-hidden="true"></div>`;
    document.body.appendChild(el); document.body.classList.add('as-open');
    requestAnimationFrame(() => el.classList.add('in'));

    const V = YH.robot.voice; const prevVoice = V.enabled; V.enabled = true; pickVoice(V);
    if ('speechSynthesis' in window) speechSynthesis.addEventListener('voiceschanged', () => pickVoice(V));
    const P = YH.presenter.create(el.querySelector('.as-person'));
    let A = P.set(1);
    let { scenes } = sceneList(ctx, A);
    const stage = el.querySelector('.as-stage'), subt = el.querySelector('.as-subt'), focus = el.querySelector('.as-focus');
    const st = { si: 0, li: 0, tok: 0, paused: false, done: false, temp: false };

    function drawPick() {
      el.querySelector('.as-name').textContent = A.name; el.querySelector('.as-role').textContent = A.role;
      el.querySelector('.as-tag').style.setProperty('--tone', A.tone);
      el.querySelectorAll('[data-a]').forEach(b => b.classList.toggle('on', +b.dataset.a === A.id));
    }
    drawPick();
    const drawDots = () => { el.querySelector('.as-dots').innerHTML = scenes.map((s, i) => `<button data-i="${i}" aria-label="${esc(s.t)}"><i></i></button>`).join(''); };
    drawDots();

    /* fit the wall canvas to its box */
    const canvas = el.querySelector('.as-canvas'), wall = el.querySelector('.as-wall');
    function fit() {
      const [W, H] = dims(); canvas.style.width = W + 'px'; canvas.style.height = H + 'px'; el.classList.toggle('narrow', W < 600);
      el.style.setProperty('--wall-ar', W / H);
      const r = el.querySelector('.as-wallbox').getBoundingClientRect();
      const k = Math.min(r.width / W, r.height / H);
      wall.style.width = W * k + 'px'; wall.style.height = H * k + 'px';
      canvas.style.transform = `scale(${k})`;
      if (ftgt) point(ftgt);
    }

    /* gold focus ring: only animates for a short time after each move (keeps the page light) */
    let ftgt = null, fraf = 0, fUntil = 0;
    function tick() {
      fraf = 0;
      if (!ftgt || !ftgt.isConnected) { focus.classList.remove('on'); return; }
      const r = ftgt.getBoundingClientRect(); const pad = 6;
      focus.style.transform = `translate(${r.left - pad}px, ${r.top - pad}px)`; focus.style.width = r.width + pad * 2 + 'px'; focus.style.height = r.height + pad * 2 + 'px';
      focus.classList.add('on');
      if (performance.now() < fUntil) fraf = requestAnimationFrame(tick);
    }
    const point = (t, ms = 3200) => { ftgt = t && t !== stage ? t : null; fUntil = performance.now() + ms; if (!fraf) fraf = requestAnimationFrame(tick); };
    const ro = new ResizeObserver(fit); ro.observe(el.querySelector('.as-wallbox')); fit();

    function render(s, label) {
      point(null);
      el.querySelector('.as-wt').textContent = s.t;
      el.querySelector('.as-step').textContent = label;
      clearTimeout(artT);
      const who = s.who || 1; if (who !== A.id) { A = P.set(who); drawPick(); YH.sfx.pop(); } else YH.sfx.whoosh();
      const clip = s.goal ? goalClip(ctx, s.goal) : null;
      const vbtn = s.goal ? `<button class="sc-vid" data-c="gvid"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>${clip ? 'شوف فيديو الهدف' : 'ابحث عن فيديو الهدف'}</button>` : '';
      const art = s.art ? `<figure class="sc-art"><img src="assets/art-${s.art}.webp" alt=""><figcaption><small>${s.goal ? 'شلون جا الهدف؟' : 'الفكرة التكتيكية'}</small><b>${esc(s.t)}</b></figcaption><i class="sc-art-ai">صورة توضيحية بالذكاء الاصطناعي</i></figure>` : '';
      stage.classList.remove('in'); stage.innerHTML = s.html + art + vbtn; void stage.offsetWidth; stage.classList.add('in');
      stage._clip = clip; stage._goal = s.goal;
      try { s.mount && s.mount(stage); } catch (e) { console.warn(e); }
      if (s.art && s.lines.length < 2) artT = setTimeout(hideArt, 2600);
    }
    let artT = 0;
    function hideArt() { const a = stage.querySelector('.sc-art:not(.out)'); if (a) { a.classList.add('out'); YH.sfx.reveal(); } }
    function show(i) {
      st.temp = false; st.si = (i + scenes.length) % scenes.length; st.li = 0;
      render(scenes[st.si], `${st.si + 1} / ${scenes.length}`);
      el.querySelectorAll('.as-dots [data-i]').forEach((d, k) => { d.classList.toggle('done', k < st.si); d.classList.toggle('cur', k === st.si); });
    }

    /* speech, sentence by sentence, with word highlighting */
    let sayTok = 0;
    function say(text) {
      const tok = ++sayTok; V.cancel();
      const parts = sentences(text);
      P.talk(true); P.gesture(); YH.music.duck(true);
      return new Promise(async res => {
        for (let i = 0; i < parts.length; i++) {
          if (tok !== sayTok) return res(false);
          await speakOne(parts[i], tok, i);
        }
        if (tok !== sayTok) return res(false);
        P.talk(false); YH.music.duck(false); setTimeout(() => res(tok === sayTok), 140);
      });
    }
    function speakOne(t, tok, i) {
      subt.innerHTML = wordsHTML(t); subt.classList.remove('in'); void subt.offsetWidth; subt.classList.add('in');
      if (i) P.gesture();
      const ws = [...subt.querySelectorAll('.w')];
      const hl = pos => ws.forEach(w => w.classList.toggle('said', +w.dataset.o <= pos));
      return new Promise(r => {
        let done = false, tm = 0, iv = 0, gotB = false;
        const end = () => { if (done) return; done = true; clearTimeout(tm); clearInterval(iv); ws.forEach(w => w.classList.add('said')); r(); };
        const spoke = V.enabled && V.has() && V.speak(t, { rate: 1.14, pitch: 0.98, onend: end, onboundary: e => { gotB = true; hl(e.charIndex); } });
        const dur = spoke ? 0 : 450 + t.length * 46;
        // progressive highlight (timer based when the voice gives no word boundaries)
        const est = spoke ? t.length * 72 : dur; const t0 = performance.now();
        iv = setInterval(() => { if (tok !== sayTok) { clearInterval(iv); return; } if (!gotB) hl((performance.now() - t0) / est * t.length); }, 120);
        tm = setTimeout(end, spoke ? 2400 + t.length * 95 : dur);
      });
    }
    function stopTalk() { sayTok++; V.cancel(); P.talk(false); YH.music.duck(false); }

    async function runLines(s, my, from) {
      for (let li = from; li < s.lines.length; li++) {
        if (my !== st.tok) return false;
        if (!st.temp) st.li = li;
        if (li >= 1) hideArt();
        const L = s.lines[li];
        if (L.act) { try { const r = L.act(); if (r && r.then) r.catch(() => {}); } catch (e) {} }
        let tgt = null; try { tgt = L.at && L.at(); } catch (e) {}
        point(tgt);
        const ok = await say(L.t); if (!ok || my !== st.tok) return false;
      }
      return true;
    }
    async function play() {
      const my = ++st.tok; st.paused = false; st.done = false; el.classList.remove('paused');
      if (st.temp) show(st.si);
      while (st.si < scenes.length) {
        const ok = await runLines(scenes[st.si], my, st.li); if (!ok) return;
        if (st.si >= scenes.length - 1) break;
        await sleep(220); if (my !== st.tok) return;
        show(st.si + 1);
      }
      point(null);
      await say('وهذا كل الشرح. تگدر تسألني أي سؤال من زر اسأل المحلل، أو تختار أي دقيقة من خط المباراة.');
      st.paused = true; st.done = true; el.classList.add('paused');
    }
    function pause() { st.tok++; stopTalk(); st.paused = true; el.classList.add('paused'); }
    function jump(i) { st.tok++; stopTalk(); show(i); play(); }
    /* a one-off scene (a minute on the timeline, or an answer); play resumes the main explanation */
    async function temp(s, label) {
      const my = ++st.tok; stopTalk(); st.temp = true; st.paused = false; el.classList.remove('paused');
      render(s, label);
      el.querySelectorAll('.as-dots [data-i]').forEach(d => d.classList.remove('cur'));
      const ok = await runLines(s, my, 0);
      if (ok && my === st.tok) { st.paused = true; el.classList.add('paused'); subt.innerHTML = '<span class="w said">اضغط تشغيل حتى نكمل الشرح من مكانه.</span>'; }
    }

    /* timeline */
    const tl = el.querySelector('.as-tl'); const rng = tl && tl.querySelector('input'), out = tl && tl.querySelector('output');
    const goMinute = m => { if (out) out.textContent = m + "'"; if (rng) rng.value = m; temp(YH.tactics.minuteScene(ctx, m), 'خط المباراة'); };
    if (rng) {
      rng.addEventListener('input', () => { out.textContent = rng.value + "'"; });
      rng.addEventListener('change', () => goMinute(+rng.value));
    }

    /* ask the analyst */
    const qa = el.querySelector('.as-qa'), qin = qa.querySelector('input');
    const openQA = on => { qa.hidden = !on; if (on) setTimeout(() => qin.focus({ preventScroll: true }), 40); };
    const askQ = text => { text = (text || '').trim(); if (!text) return; openQA(false); qin.value = ''; let sc; try { sc = YH.qa.ask(ctx, text); } catch (e) { console.warn(e); sc = { t: 'سؤالك للمحلل', html: `<div class="qa-a"><p class="qa-q">${esc(text)}</p></div>`, lines: [{ t: 'ما گدرت أحلل هذا السؤال، جرّب صيغة ثانية.' }] }; }
      if (!/qa-q/.test(sc.html)) sc = { ...sc, html: `<div class="qa-wrap"><p class="qa-q">${esc(text)}</p>${sc.html}</div>` };
      temp(sc, 'سؤالك'); };
    qa.querySelector('form').addEventListener('submit', e => { e.preventDefault(); askQ(qin.value); });
    let rec = null;
    function mic(b) {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return;
      if (rec) { rec.stop(); return; }
      pause(); rec = new SR(); rec.lang = 'ar-IQ'; rec.interimResults = true; b.classList.add('rec');
      rec.onresult = e => { const t = [...e.results].map(r => r[0].transcript).join(' '); qin.value = t; if (e.results[e.results.length - 1].isFinal) askQ(t); };
      rec.onend = rec.onerror = () => { b.classList.remove('rec'); rec = null; };
      try { rec.start(); } catch (e) { rec = null; b.classList.remove('rec'); }
    }

    function playGoalVideo() {
      const clip = stage._clip, g = stage._goal; pause();
      if (!clip) { const q = `${g ? g.ar + ' ' : ''}${AR(ev.home.name)} ${AR(ev.away.name)} هدف`; window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`, '_blank', 'noopener'); return; }
      const m = document.createElement('div'); m.className = 'as-vid';
      m.innerHTML = `<div class="as-vid-box"><div class="as-vid-h"><b>${esc(clip.title)}</b><button class="as-x sm" data-c="vx" aria-label="إغلاق الفيديو"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div><video src="${esc(clip.src)}" poster="${esc(clip.thumb || '')}" controls autoplay playsinline preload="metadata"></video><small>التعليق أجنبي · المصدر ESPN</small></div>`;
      el.appendChild(m); m.addEventListener('click', e => { if (e.target === m) { m.querySelector('video').pause(); m.remove(); } });
    }
    const music = YH.music; music.start();
    el.addEventListener('click', e => {
      const a = e.target.closest('[data-a]');
      if (a) { const id = +a.dataset.a; const i = scenes.findIndex(x => x.who === id); if (i >= 0) jump(i); else YH.viz && 0; return; }
      const d = e.target.closest('.as-dots [data-i]'); if (d) { jump(+d.dataset.i); return; }
      const mk = e.target.closest('.mk[data-m]'); if (mk) { goMinute(+mk.dataset.m); return; }
      const ch = e.target.closest('[data-q]'); if (ch) { askQ(ch.dataset.q); return; }
      const b = e.target.closest('[data-c]'); if (!b) return; const k = b.dataset.c;
      if (k === 'close') return close();
      if (k === 'gvid') return playGoalVideo();
      if (k === 'vx') { const m = el.querySelector('.as-vid'); if (m) { m.querySelector('video') && m.querySelector('video').pause(); m.remove(); } return; }
      if (k === 'ask') return openQA(qa.hidden);
      if (k === 'askx') return openQA(false);
      if (k === 'mic') return mic(b);
      if (k === 'prev') return jump(st.temp ? st.si : st.si - 1);
      if (k === 'next') return jump(st.temp ? st.si : st.si + 1);
      if (k === 'play') { if (st.done) jump(0); else if (st.paused) play(); else pause(); return; }
      if (k === 'music') { if (music.on) music.stop(); else music.start(); YH.sfx.on = music.on; b.setAttribute('aria-pressed', music.on); return; }
      if (k === 'voice') { V.enabled = !V.enabled; if (!V.enabled) V.cancel(); b.setAttribute('aria-pressed', V.enabled); return; }
    });
    const onKey = e => { if (e.key === 'Escape') { if (!qa.hidden) openQA(false); else close(); } };
    document.addEventListener('keydown', onKey);

    show(0);
    setTimeout(play, 250);
    cur = {
      el,
      refresh(extra) {
        if (!extra) return; Object.assign(ctx, extra);
        scenes = sceneList(ctx, A).scenes; drawDots();
        el.querySelector('.as-chips').innerHTML = YH.qa.suggestions(ctx).map(s => `<button type="button" data-q="${esc(s)}">${esc(s)}</button>`).join('');
        if (!st.temp) { el.querySelector('.as-step').textContent = `${st.si + 1} / ${scenes.length}`; el.querySelectorAll('.as-dots [data-i]').forEach((d, k) => { d.classList.toggle('done', k < st.si); d.classList.toggle('cur', k === st.si); }); }
      },
      destroy() { st.tok++; stopTalk(); if (rec) try { rec.stop(); } catch (e) {} cancelAnimationFrame(fraf); ro.disconnect(); P.destroy(); music.stop(); V.enabled = prevVoice; document.removeEventListener('keydown', onKey); },
    };
    el.querySelector('.as-x').focus({ preventScroll: true });
    return cur;
  }
  function close() {
    if (!cur) return; const c = cur; cur = null; c.destroy();
    c.el.classList.remove('in'); document.body.classList.remove('as-open');
    setTimeout(() => c.el.remove(), 320);
  }
  YH.analyst = { goalClips, open, close, refresh: x => cur && cur.refresh(x), isOpen: () => !!cur };
})();
