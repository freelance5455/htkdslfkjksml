window.WorkspaceQuestEvidence=(()=>{
  let detailToken=0;
  const n=value=>Number.isFinite(Number(value))?Number(value):0;
  const safe=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  function rows(value){
    let v=value;
    for(let i=0;i<4;i++){
      if(typeof v==='string'){try{v=JSON.parse(v);continue}catch{return[]}}
      if(Array.isArray(v)&&v.length===1&&(Array.isArray(v[0])||typeof v[0]==='string')){v=v[0];continue}
      break;
    }
    if(!Array.isArray(v))v=v&&typeof v==='object'?[v]:[];
    return v.flat(4).filter(x=>x&&typeof x==='object'&&!Array.isArray(x));
  }
  function groups(items){
    const map=new Map();
    for(const row of rows(items)){
      const key=String(row.record_key||row.stable_id||'');
      if(!key)continue;
      if(!map.has(key))map.set(key,{
        key,
        stableId:String(row.stable_id||''),
        name:String(row.quest_name||'Unknown quest'),
        content:String(row.content||'Unknown content'),
        type:String(row.quest_type||''),
        formId:String(row.form_id||''),
        providers:[]
      });
      map.get(key).providers.push(row);
    }
    return [...map.values()].sort((a,b)=>a.content.localeCompare(b.content)||a.name.localeCompare(b.name));
  }
  function winner(group){
    return [...group.providers].sort((a,b)=>n(b.plugin_load_order)-n(a.plugin_load_order))[0]||null;
  }
  function renderProfile(evidence){
    const host=document.getElementById('mo2QuestEvidence');if(!host)return;
    const run=evidence?.run||null;
    if(!run||String(run.status||'')!=='ok'){
      const fold=document.getElementById('mo2QuestFoldCount');if(fold)fold.textContent='No quest evidence yet';
      host.innerHTML='<p>Quest relationship evidence becomes available after Plugin Record Evidence reaches EVIDENCE READY.</p>';
      return;
    }
    const all=groups(evidence?.items),matched=n(evidence?.matched_quests),providerRows=n(evidence?.provider_rows);
    if(!all.length){
      const fold=document.getElementById('mo2QuestFoldCount');if(fold)fold.textContent='0 known quests';
      host.innerHTML='<div class="mo2-quest-heading"><b>QUEST RELATIONSHIP EVIDENCE</b><small>Direct QUST matches only</small></div><p>No shared QUST records match the current 252-quest database.</p>';
      return;
    }
    const shown=all.slice(0,12);
    const fold=document.getElementById('mo2QuestFoldCount');if(fold)fold.textContent=`${matched.toLocaleString()} known quests · ${providerRows.toLocaleString()} provider rows`;
    host.innerHTML=`<div class="mo2-quest-heading"><div><b>QUEST RELATIONSHIP EVIDENCE</b><small>Direct QUST record matches · evidence only</small></div><span>${matched.toLocaleString()} known quest${matched===1?'':'s'} · ${providerRows.toLocaleString()} provider rows</span></div><p class="mo2-quest-rule">This pass links exact quest records only. Dialogue, scripts, NPCs, cells, and other indirect quest effects are deliberately not inferred yet.</p><div class="mo2-quest-list">${shown.map(g=>{const win=winner(g);return`<article><div><b>${safe(g.name)}</b><small>${safe(g.content)} · ${safe(g.formId||'Form ID unavailable')} · ${g.providers.length} provider${g.providers.length===1?'':'s'}</small></div><span>${win?`${safe(win.plugin_name||'Unknown plugin')} · Load #${n(win.plugin_load_order)+1} · OBSERVED WINNER`:'No provider'}</span></article>`}).join('')}</div>${all.length>shown.length?`<small class="mo2-quest-more">Showing ${shown.length.toLocaleString()} of ${all.length.toLocaleString()} matched quests.</small>`:''}`;
  }
  async function loadProfile(api){
    try{const p=await api('/api/mo2/quest-evidence');renderProfile(p?.evidence||null);return p?.evidence||null}
    catch{renderProfile(null);return null}
  }
  function clearProfile(){renderProfile(null)}
  async function loadMod(api,mod,escape){
    const host=document.getElementById('detailQuestEvidence');if(!host||!mod?.id)return;
    const token=++detailToken;
    host.innerHTML='<p class="detail-quest-empty">Loading direct quest-record evidence…</p>';
    try{
      const p=await api(`/api/mo2/quest-evidence/mod/${Number(mod.id)}`);
      if(token!==detailToken)return;
      const e=p?.evidence||{},run=e.run||null;
      if(!run||String(run.status||'')!=='ok'){
        host.innerHTML='<p class="detail-quest-empty">Quest evidence requires EVIDENCE READY plugin-record data for the current MO2 snapshot.</p>';
        return;
      }
      const all=groups(e.items),total=n(e.matched_quests);
      if(!all.length){
        host.innerHTML='<p class="detail-quest-empty">No exact quest records in the current shared-record evidence are provided by this matched Workspace mod.</p>';
        return;
      }
      host.innerHTML=`<div class="detail-quest-summary"><b>${total.toLocaleString()} direct quest record${total===1?'':'s'}</b><span>Observed QUST evidence · not a compatibility verdict</span></div>${all.map(g=>{const providers=[...g.providers].sort((a,b)=>n(b.plugin_load_order)-n(a.plugin_load_order));return`<article class="detail-quest-row"><div><b>${escape(g.name)}</b><small>${escape(g.content)} · ${escape(g.type||'Quest')} · ${escape(g.formId||'Form ID unavailable')}</small></div><div class="detail-quest-providers">${providers.slice(0,5).map((provider,index)=>`<span class="detail-quest-provider${index===0?' winner':''}"><b>${escape(provider.plugin_name||'Unknown')}</b><small>Load #${n(provider.plugin_load_order)+1}${index===0?' · OBSERVED WINNER':''}</small></span>`).join('')}${providers.length>5?`<span class="detail-quest-provider"><small>+${providers.length-5} more</small></span>`:''}</div></article>`}).join('')}<p class="detail-quest-note">Direct QUST matches only. Indirect quest effects through dialogue, scripts, actors, or world records are intentionally not inferred in Step 13E.</p>`;
    }catch(error){
      if(token===detailToken)host.innerHTML=`<p class="detail-quest-empty">${escape(error?.message||'Quest evidence is unavailable.')}</p>`;
    }
  }
  return{loadProfile,clearProfile,loadMod}
})();
