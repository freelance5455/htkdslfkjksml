window.WorkspaceFileOverlaps=(()=>{
  let lastStatus=null,detailToken=0;

  function normalizeRows(value){
    let rows=value;
    for(let i=0;i<4;i++){
      if(typeof rows==='string'){
        try{rows=JSON.parse(rows);continue}catch{return[]}
      }
      if(Array.isArray(rows)&&rows.length===1&&(Array.isArray(rows[0])||typeof rows[0]==='string')){rows=rows[0];continue}
      break
    }
    if(!Array.isArray(rows))rows=rows&&typeof rows==='object'?[rows]:[];
    return rows.flat(4).filter(row=>row&&typeof row==='object'&&!Array.isArray(row))
  }
  const n=value=>Number.isFinite(Number(value))?Number(value):0;

  function renderProfile(overlap){
    lastStatus=overlap||null;
    const state=document.getElementById('mo2OverlapState'),mods=document.getElementById('mo2OverlapMods'),tracked=document.getElementById('mo2OverlapFiles'),paths=document.getElementById('mo2OverlapPaths'),providers=document.getElementById('mo2OverlapProviders'),note=document.getElementById('mo2OverlapPreview');
    if(!state)return;
    const status=String(overlap?.status||'not_scanned');
    state.className=`mo2-overlap-state ${status==='ok'?'good':status==='error'?'warn':''}`;
    state.textContent=status==='ok'?'EVIDENCE READY':status==='running'?'SCANNING':status==='error'?'SCAN ERROR':'NOT SCANNED';
    if(mods)mods.textContent=status==='not_scanned'?'—':n(overlap?.scanned_mods).toLocaleString();
    if(tracked)tracked.textContent=status==='not_scanned'?'—':n(overlap?.tracked_paths).toLocaleString();
    if(paths)paths.textContent=status==='not_scanned'?'—':n(overlap?.overlap_paths).toLocaleString();
    if(providers)providers.textContent=status==='not_scanned'?'—':n(overlap?.provider_rows).toLocaleString();
    if(note){
      if(status==='ok')note.innerHTML='<p>Overlap evidence is stored locally for the current MO2 snapshot. Open a matched mod to inspect its shared paths and providers.</p>';
      else if(status==='error')note.innerHTML=`<p>${String(overlap?.notes||'The overlap scan failed.')}</p>`;
      else note.innerHTML='<p>No file-overlap scan for the current MO2 snapshot yet.</p>'
    }
  }

  async function loadStatus(api){
    try{const payload=await api('/api/mo2/file-overlaps/status');renderProfile(payload?.overlap||null);return payload?.overlap||null}catch{renderProfile(null);return null}
  }
  async function scan(api){
    const payload=await api('/api/mo2/file-overlaps/scan',{method:'POST',body:'{}'});renderProfile(payload?.overlap||null);return payload?.overlap||null
  }
  function clearProfile(){renderProfile(null)}

  function groupEvidence(items){
    const groups=new Map();
    for(const row of normalizeRows(items)){
      const key=String(row.relative_path||'').toLowerCase();if(!key)continue;
      if(!groups.has(key))groups.set(key,{relative_path:row.relative_path,category:row.category||'Other',extension:row.file_extension||'',providers:[]});
      groups.get(key).providers.push(row)
    }
    return [...groups.values()].sort((a,b)=>b.providers.length-a.providers.length||String(a.relative_path).localeCompare(String(b.relative_path)))
  }

  async function loadMod(api,mod,escape){
    const host=document.getElementById('detailMo2Overlaps');if(!host||!mod?.id)return;
    const token=++detailToken;host.innerHTML='<p class="detail-overlap-empty">Loading local overlap evidence…</p>';
    try{
      const payload=await api(`/api/mo2/file-overlaps/mod/${Number(mod.id)}`);if(token!==detailToken)return;
      const evidence=payload?.evidence||{},run=evidence.run||null,groups=groupEvidence(evidence.items),total=Number(evidence.total_paths)||groups.length;
      if(!run||String(run.status||'')==='not_scanned'){host.innerHTML='<p class="detail-overlap-empty">No file-overlap scan exists for the current MO2 snapshot.</p>';return}
      if(!groups.length){host.innerHTML='<p class="detail-overlap-empty">No shared enabled-mod file paths are recorded for this matched mod.</p>';return}
      const shown=groups.slice(0,120);
      host.innerHTML=`<div class="detail-overlap-summary"><b>${total.toLocaleString()} shared path${total===1?'':'s'}</b><span>Highest observed MO2 priority is the virtual overwrite winner · evidence only</span></div>${shown.map(group=>{
        const providers=[...group.providers].sort((a,b)=>n(b.provider_priority)-n(a.provider_priority)||String(a.provider_mod_name||'').localeCompare(String(b.provider_mod_name||'')));
        const winnerPriority=providers.length?n(providers[0].provider_priority):null;
        const providerMarkup=providers.slice(0,4).map((p,index)=>{const winner=index===0&&n(p.provider_priority)===winnerPriority;return`<span class="detail-overlap-provider${winner?' winner':''}"><b>${escape(p.provider_mod_name||'Unknown')}</b><small>MO2 #${n(p.provider_priority)+1}${winner?' · VIRTUAL WINNER':''}</small></span>`}).join('');
        return`<article class="detail-overlap-row"><div class="detail-overlap-path"><b>${escape(group.relative_path)}</b><small>${escape(group.category)}${group.extension?` · ${escape(group.extension)}`:''} · ${group.providers.length} providers</small></div><div class="detail-overlap-providers">${providerMarkup}${providers.length>4?`<span class="detail-overlap-provider more"><small>+${providers.length-4} more provider${providers.length-4===1?'':'s'}</small></span>`:''}</div></article>`
      }).join('')}${total>shown.length?`<p class="detail-overlap-more">Showing ${shown.length.toLocaleString()} of ${total.toLocaleString()} shared paths.</p>`:''}`
    }catch(error){if(token===detailToken)host.innerHTML=`<p class="detail-overlap-empty">${escape(error?.message||'File-overlap evidence is unavailable.')}</p>`}
  }

  return{renderProfile,loadStatus,scan,clearProfile,loadMod,current:()=>lastStatus}
})();
