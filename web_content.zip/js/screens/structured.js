import { el, card } from "../ui/widgets.js";
import { formatQuestionHTML } from "../ui/widgets.js";
import { answersMatch } from "../engines/answerCheck.js";
import { drawDiagram } from "../ui/render.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";

function renderStimulus(stim) {
  if (!stim) return el("div", {});
  if (stim.type === "table" && stim.rows) {
    const table = el("table", { class: "datatable" }, [
      el("tr", {}, (stim.headers || []).map((h) => el("th", {}, String(h)))),
      ...stim.rows.map((row) => el("tr", {}, row.map((c) => el("td", {}, String(c)))))
    ]);
    return el("div", { class: "card" }, [
      el("div", { class: "role-heading wrap" }, stim.title || ""),
      table
    ]);
  }
  if (stim.type === "diagram" && stim.diagram) {
    const wrap = el("div", { class: "card" }, [el("div", { class: "role-heading wrap" }, stim.title || "")]);
    const c = el("canvas", { style: "display:block;margin:0.4rem auto;" });
    wrap.appendChild(c);
    requestAnimationFrame(() => { try { drawDiagram(c, stim.diagram, 300, 200); } catch {} });
    return wrap;
  }
  return el("div", { class: "card wrap" }, stim.title || "");
}

export async function StructuredPractice(app, params = {}) {
  const topicId = params.topicId || "data_5";
  const qe = app.questionEngine();
  let item;
  try {
    item = qe.generateStructured(topicId, params.difficulty || 2);
  } catch (err) {
    console.error(err);
    item = null;
  }
  if (!item || !item.parts || !item.parts.length) {
    return {
      title: "Challenge",
      body: [
        card("No question yet", "Try Data Handling."),
        el("button", { class: "btn", onClick: () => app.navigate("structuredPractice", { topicId: "data_5" }) }, "Data question")
      ]
    };
  }

  const inputs = {};
  const resultEls = {};
  const partsWrap = el("div", {});

  item.parts.forEach((p) => {
    const prompt = p.prompt || p.question || "";
    const inp = el("input", { type: "text", placeholder: p.id || "Answer" });
    const res = el("div", { class: "role-muted wrap" });
    inputs[p.id] = inp;
    resultEls[p.id] = res;
    const block = el("div", { class: "struct-part" });
    block.appendChild(el("div", {
      style: "font-weight:700;",
      html: formatQuestionHTML(`${p.id} (${p.marks ?? 1}) ${prompt}`)
    }));
    if (p.diagram) {
      const c = el("canvas", { style: "display:block;margin:0.3rem auto;" });
      block.appendChild(c);
      requestAnimationFrame(() => { try { drawDiagram(c, p.diagram, 260, 160); } catch {} });
    }
    block.appendChild(inp);
    block.appendChild(res);
    partsWrap.appendChild(block);
  });

  const scoreEl = el("div", { class: "role-heading" });

  function markAll() {
    let got = 0;
    const total = item.totalMarks || item.parts.reduce((s, p) => s + (p.marks || 1), 0);
    item.parts.forEach((p) => {
      const raw = inputs[p.id].value.trim();
      let ok = false;
      if (p.soft || p.kind === "sentence") ok = raw.length >= 6;
      else ok = answersMatch(raw, p.answer);
      if (ok) {
        got += p.marks || 1;
        resultEls[p.id].textContent = "Yes!";
      } else {
        resultEls[p.id].textContent = `Answer: ${p.answer}`;
      }
    });
    scoreEl.textContent = `${got} / ${total}`;
    const s = app.student;
    s.xp = (s.xp || 0) + Math.max(2, Math.round((got / Math.max(1, total)) * 12));
    s.today_done = (s.today_done || 0) + 1;
    (s.history = s.history || []).push({
      question_id: item.id, topic: item.topic, correct: got >= total * 0.6,
      difficulty: item.difficulty, timestamp: new Date().toISOString()
    });
    s.credits = (s.credits || 0) + (got === total ? 10 : 4);
    new GamificationEngine(s).checkNewUnlocks();
    app.saveStudent();
  }

  return {
    title: "Challenge",
    body: [
      el("div", { class: "role-subtitle wrap" },
        `Question ${item.number || 3} · ${item.topic_name || item.topic} · ${item.totalMarks || ""} marks`),
      renderStimulus(item.stimulus),
      partsWrap,
      scoreEl,
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn", onClick: markAll }, "Check"),
        el("button", { class: "btn-secondary", onClick: () => app.navigate("structuredPractice", { topicId }) }, "New"),
        el("button", { class: "btn-secondary", onClick: () => app.showPractice() }, "Practice")
      ])
    ]
  };
}

export async function StructuredHub(app) {
  return {
    title: "Challenges",
    bottomNavKey: "practice",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Long questions with parts 3.1 to 3.6."),
      card("📊 Data", "Table + six parts", [{ label: "GO", onClick: () => app.navigate("structuredPractice", { topicId: "data_5" }) }]),
      card("🔢 Numbers", "Six number parts", [{ label: "GO", onClick: () => app.navigate("structuredPractice", { topicId: "whole_numbers_5" }) }]),
      card("🍕 Fractions", "Six fraction parts", [{ label: "GO", onClick: () => app.navigate("structuredPractice", { topicId: "common_fractions_5" }) }]),
      card("🔺 Shapes", "Six shape parts", [{ label: "GO", onClick: () => app.navigate("structuredPractice", { topicId: "geometry_5" }) }])
    ]
  };
}
