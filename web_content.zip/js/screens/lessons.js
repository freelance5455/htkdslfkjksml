import { el, card } from "../ui/widgets.js";
import { formatQuestionHTML } from "../ui/widgets.js";
import { drawLessonVisual } from "../ui/imageBuilder.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { answersMatch } from "../engines/answerCheck.js";

async function loadJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error("Missing " + path);
  return res.json();
}

export async function MathsLessonsHub(app) {
  let index;
  try {
    index = await loadJSON("./content/grade5/maths/lessons/index.json");
  } catch {
    return { title: "Lessons", body: [card("Coming soon", "Maths lessons are loading.")] };
  }
  const byTerm = {};
  (index.lessons || []).forEach((l) => {
    (byTerm[l.term] = byTerm[l.term] || []).push(l);
  });
  const body = [
    el("div", { class: "role-subtitle wrap" }, "Step-by-step Grade 5 lessons. Big visuals. No senior tricks.")
  ];
  [1, 2, 3, 4].forEach((t) => {
    body.push(el("div", { class: "section-eyebrow" }, `TERM ${t}`));
    (byTerm[t] || []).forEach((l) => {
      body.push(card(l.title, l.topic.replaceAll("_", " "), [
        { label: "OPEN", onClick: () => app.navigate("mathsLesson", { id: l.id }) }
      ]));
    });
  });
  return { title: "Maths Lessons", bottomNavKey: "learn", body };
}

export async function MathsLesson(app, { id } = {}) {
  let lesson;
  try {
    lesson = await loadJSON(`./content/grade5/maths/lessons/${id}.json`);
  } catch (e) {
    return { title: "Lesson", body: [card("Not found", String(e.message))] };
  }
  const teachSteps = lesson.steps || [];
  const exitQs = lesson.exit_ticket || [];
  const practiceQs = lesson.practice || exitQs.map((x) => ({ q: x.q, a: x.a }));
  const PHASE_TEACH = 0, PHASE_EXIT = 1, PHASE_PRACTICE = 2;
  let phase = PHASE_TEACH;
  let step = 0;
  let practiceIndex = 0;
  let practiceScore = 0;
  const panel = el("div", {});

  function visualForStep(stepIndex) {
    const base = lesson.visual || { type: "banner", title: lesson.title };
    if (base.type === "banner" || !base.type) {
      return {
        type: "banner",
        title: lesson.title,
        bigText: base.bigText || "",
        steps: teachSteps,
        stepIndex
      };
    }
    return base;
  }

  function render() {
    panel.innerHTML = "";

    if (phase === PHASE_TEACH) {
      const visCanvas = el("canvas", { style: "display:block;margin:0.5rem auto;max-width:100%;border-radius:12px;" });
      panel.appendChild(visCanvas);
      requestAnimationFrame(() => {
        try {
          drawLessonVisual(visCanvas, visualForStep(step), 340, 180);
        } catch (err) { console.warn(err); }
      });
      panel.appendChild(el("div", { class: "role-heading" }, `Step ${step + 1} of ${teachSteps.length}`));
      panel.appendChild(el("div", {
        class: "card",
        style: "font-size:1.15rem;line-height:1.5;font-weight:600;",
        html: formatQuestionHTML(teachSteps[step] || "")
      }));
      const nav = el("div", { class: "btn-row" });
      if (step > 0) nav.appendChild(el("button", { class: "btn-secondary", onClick: () => { step -= 1; render(); } }, "Back"));
      if (step < teachSteps.length - 1) {
        nav.appendChild(el("button", { class: "btn", onClick: () => { step += 1; render(); } }, "Next"));
      } else {
        nav.appendChild(el("button", { class: "btn", onClick: () => { phase = PHASE_EXIT; render(); } }, "Check understanding"));
      }
      panel.appendChild(nav);
      return;
    }

    if (phase === PHASE_EXIT) {
      panel.appendChild(el("div", { class: "role-heading" }, "Check"));
      if (!exitQs.length) {
        panel.appendChild(el("div", { class: "role-muted" }, "No exit questions — go to practice."));
      }
      exitQs.forEach((item) => {
        const inp = el("input", { type: "text", placeholder: "Answer" });
        const res = el("div", { class: "role-muted" });
        const block = el("div", { class: "struct-part" });
        block.appendChild(el("div", { style: "font-weight:700;font-size:1.05rem;", html: formatQuestionHTML(item.q) }));
        block.appendChild(inp);
        block.appendChild(el("button", { class: "btn-secondary btn-sm", onClick: () => {
          const ok = answersMatch(inp.value.trim(), item.a) ||
            inp.value.trim().replace(/\s/g, "") === String(item.a).replace(/\s/g, "");
          res.textContent = ok ? "Yes!" : `Answer: ${item.a}`;
          if (ok) {
            app.student.xp = (app.student.xp || 0) + 2;
            new EconomyEngine(app.student).earn("teach_exit", "Lesson check");
            app.saveStudent();
          }
        } }, "Check"));
        block.appendChild(res);
        panel.appendChild(block);
      });
      const nav = el("div", { class: "btn-row" });
      nav.appendChild(el("button", { class: "btn-secondary", onClick: () => { phase = PHASE_TEACH; step = Math.max(0, teachSteps.length - 1); render(); } }, "Back"));
      nav.appendChild(el("button", { class: "btn", onClick: () => {
        phase = PHASE_PRACTICE;
        practiceIndex = 0;
        practiceScore = 0;
        render();
      } }, "Lesson practice"));
      panel.appendChild(nav);
      return;
    }

    // Built-in lesson practice (stays in the lesson)
    const pq = practiceQs[practiceIndex];
    if (!pq) {
      panel.appendChild(el("div", { class: "role-heading" }, "Practice complete"));
      panel.appendChild(el("div", { class: "card" }, `Score: ${practiceScore} / ${practiceQs.length}`));
      panel.appendChild(el("button", { class: "btn", onClick: () => app.showMathsLessons() }, "Back to lessons"));
      return;
    }
    panel.appendChild(el("div", { class: "role-heading" }, `Practice ${practiceIndex + 1} / ${practiceQs.length}`));
    if (pq.visual) {
      const c = el("canvas", { style: "display:block;margin:0.4rem auto;border-radius:12px;" });
      panel.appendChild(c);
      requestAnimationFrame(() => {
        try { drawLessonVisual(c, pq.visual, 280, 140); } catch { /* ignore */ }
      });
    }
    const inp = el("input", { type: "text", placeholder: "Your answer" });
    const res = el("div", { class: "wrap" });
    panel.appendChild(el("div", { class: "card", style: "font-weight:700;", html: formatQuestionHTML(pq.q) }));
    panel.appendChild(inp);
    panel.appendChild(el("div", { class: "btn-row" }, [
      el("button", { class: "btn", onClick: () => {
        const ok = answersMatch(inp.value.trim(), pq.a) ||
          inp.value.trim().replace(/\s/g, "") === String(pq.a).replace(/\s/g, "");
        res.textContent = ok ? "Yes!" : `Answer: ${pq.a}`;
        if (ok) {
          practiceScore += 1;
          app.student.xp = (app.student.xp || 0) + 3;
          new EconomyEngine(app.student).earn("lesson_practice", "Lesson practice");
          app.saveStudent();
        }
        setTimeout(() => {
          practiceIndex += 1;
          render();
        }, ok ? 500 : 1000);
      } }, "Check"),
      el("button", { class: "btn-secondary", onClick: () => { practiceIndex += 1; render(); } }, "Skip")
    ]));
    panel.appendChild(res);
  }
  render();

  return {
    title: lesson.title,
    body: [
      el("div", { class: "role-muted" }, `Term ${lesson.term} · ${lesson.topic}`),
      panel
    ]
  };
}
