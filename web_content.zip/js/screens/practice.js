import { el, progressBar, showAlert, formatQuestionHTML, mathKeyboard } from "../ui/widgets.js";
import { drawDiagram } from "../ui/render.js";
import { drawLessonVisual } from "../ui/imageBuilder.js";
import { AdaptiveEngine } from "../engines/adaptive.js";
import { MasteryEngine } from "../engines/mastery.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { answersMatch } from "../engines/answerCheck.js";
import { CountdownTimer } from "../engines/timerEngine.js";

/**
 * Build a compact visual that shows only a number, fraction, or shape —
 * never the full question sentence.
 */
function buildNumberOrShapeVisual(q) {
  if (!q) return null;
  const text = String(q.question || "").replace(/⟦FRAC:(\d+)\/(\d+)⟧/g, "$1/$2");
  const frac = text.match(/(\d+)\s*\/\s*(\d+)/);
  if (frac) {
    const num = parseInt(frac[1], 10), den = parseInt(frac[2], 10);
    if (den > 0 && den <= 12 && num >= 0 && num <= den * 2) {
      return { type: "fraction", num, den };
    }
  }
  const solidMatch = text.match(/\b(cube|cuboid|cylinder|cone|sphere|pyramid|prism)\b/i);
  if (solidMatch) return { type: "solid3d", kind: solidMatch[1].toLowerCase() };
  const shortExpr = text.match(/^[\s]*(?:Calculate|Find|What is|Work out)?[:\s]*([\d\s+\-×÷*/=().,]+)\s*$/i);
  if (shortExpr) {
    const expr = shortExpr[1].trim();
    if (expr.length <= 18) return { type: "banner", bigText: expr, title: "", steps: [] };
  }
  const nums = text.match(/\b\d[\d\s]*\d\b|\b\d+\b/g) || [];
  const big = nums.map((n) => n.replace(/\s/g, "")).filter((n) => n.length >= 2 && n.length <= 6);
  if (big.length === 1 && /^\d+$/.test(big[0])) {
    return { type: "place_value", number: parseInt(big[0], 10) };
  }
  if (big.length >= 1 && big[0].length <= 8) {
    return { type: "banner", bigText: big[0], title: "", steps: [] };
  }
  if (/dice|die|probability|chance/i.test(text)) {
    return { type: "dice", faces: 6, value: (parseInt((nums[0] || "3"), 10) % 6) + 1 };
  }
  return null;
}

const MODES = ["Pick a topic", "Today", "For you", "Needs work", "Strong topics", "Mix it up", "Speed run", "Mental Maths"];
const DIFFICULTIES = ["Foundation", "Standard", "Advanced", "Elite"];
const DIFF_MAP = { Foundation: 1, Standard: 2, Advanced: 3, Elite: 4 };
const MODE_LABELS = { recommended: "For you", weakness: "Needs work", strength: "Strong topics", mixed: "Mix it up", choose: "Pick a topic", daily: "Today" };
const MODE_KEYS = { "Today": "daily", "For you": "recommended", "Needs work": "weakness", "Strong topics": "strength", "Mix it up": "mixed", "Speed run": "speed", "Pick a topic": "choose" };

// ==================== SETUP ====================
export async function PracticeSetup(app, { mode = null, topics = null } = {}) {
  const gm = app.gradeManager();
  let selectedDiff = "Foundation", selectedCount = 10;
  const selectedTopics = new Set(topics || []);

  const modeSelect = el("select", {}, MODES.map((m) => el("option", { value: m }, m)));
  modeSelect.value = mode ? (MODE_LABELS[mode] || mode) : "Pick a topic";

  let topicList = gm.topics().slice();
  const isPS = app.student?.subject === "physical_sciences";
  if (gm.grade === 11 || gm.grade === 10) {
    try {
      const { allPhysSciTopics } = await import("../engines/contentLoader.js");
      const ps = await allPhysSciTopics();
      if (isPS) {
        topicList = ps.map((t) => ({ ...t, name: t.name }));
      } else {
        // Maths practice only — do not mix PS topics
        topicList = gm.topics().slice();
      }
    } catch { /* optional */ }
  }
  const topicWrap = el("div", { class: "topic-list" }, topicList.map((t) => {
    const cb = el("input", { type: "checkbox" });
    cb.checked = selectedTopics.has(t.id);
    cb.addEventListener("change", () => { cb.checked ? selectedTopics.add(t.id) : selectedTopics.delete(t.id); });
    return el("label", { class: "topic-check" }, [cb, `${t.icon || "📘"} ${t.name}`]);
  }));
  const topicSection = el("div", {}, [el("label", { class: "field-label" }, "Topics (select one or more)"), topicWrap]);
  function syncTopicVisibility() { topicSection.style.display = modeSelect.value === "Pick a topic" ? "" : "none"; }
  modeSelect.addEventListener("change", syncTopicVisibility);

  const diffRow = el("div", { class: "chip-row" });
  DIFFICULTIES.forEach((d) => {
    const chip = el("button", { class: "chip" + (d === selectedDiff ? " active" : ""), onClick: () => { selectedDiff = d; [...diffRow.children].forEach((c) => c.classList.toggle("active", c.textContent === d)); } }, d);
    diffRow.appendChild(chip);
  });

  const countRow = el("div", { class: "chip-row" });
  [5, 10, 15, 20].forEach((c) => {
    const chip = el("button", { class: "chip" + (c === selectedCount ? " active" : ""), onClick: () => { selectedCount = c; [...countRow.children].forEach((el2) => el2.classList.toggle("active", el2.textContent === String(c))); } }, String(c));
    countRow.appendChild(chip);
  });

  const timedBox = el("input", { type: "checkbox" });
  const hintsBox = el("input", { type: "checkbox" }); hintsBox.checked = true;
  const solutionBox = el("input", { type: "checkbox" }); solutionBox.checked = true;

  async function start() {
    const modeText = modeSelect.value;
    if (modeText === "Mental Maths") return app.showMental();
    const modeKey = MODE_KEYS[modeText] || "recommended";
    let chosenTopics = [];
    if (modeKey === "choose") {
      chosenTopics = [...selectedTopics];
      if (!chosenTopics.length) return showAlert("Choose a topic", "Please select at least one topic to practise.");
    }
    app.launchPracticeSession({
      mode: modeKey, topics: chosenTopics, difficulty: DIFF_MAP[selectedDiff], count: selectedCount,
      timed: timedBox.checked, hints: hintsBox.checked, showSolution: solutionBox.checked
    });
  }

  syncTopicVisibility();
  return {
    title: `✏️ Practice — ${gm.label()}`,
    body: [
      el("div", { class: "role-subtitle wrap" }, `Choose what you want to practise. Topics and numbers are matched to ${gm.label()} only.`),
      el("label", { class: "field-label" }, "Mode"), modeSelect,
      topicSection,
      el("label", { class: "field-label" }, "Difficulty"), diffRow,
      el("label", { class: "field-label" }, "Number of questions"), countRow,
      el("label", { class: "checkline" }, [timedBox, "⏱ Timed"]),
      el("label", { class: "checkline" }, [hintsBox, "💡 Hints"]),
      el("label", { class: "checkline" }, [solutionBox, "✅ Show solution after each answer"]),
      el("button", { class: "btn", onClick: start }, "🚀 START PRACTICE")
    ]
  };
}

// ==================== SESSION ====================
export async function PracticeSession(app, { mode = "recommended", topics = [], difficulty = 1, count = 10, timed = false, hints = true, showSolution = true }) {
  const state = { answered: 0, correct: 0, q: null };
  const qe = app.questionEngine();
  const ad = new AdaptiveEngine(app.student);
  const me = new MasteryEngine(app.student);
  const econ = new EconomyEngine(app.student);
  const gam = new GamificationEngine(app.student);
  const timer = new CountdownTimer();

  const progressEl = progressBar(0, count, `0 / ${count}`);
  const progressBarInner = progressEl.querySelector("i");
  const progressLabelInner = progressEl.querySelector(".progress-label");
  function setProgress(value) {
    progressBarInner.style.width = `${count > 0 ? Math.max(0, Math.min(100, (value / count) * 100)) : 0}%`;
    progressLabelInner.textContent = `${value} / ${count}`;
  }
  const statusEl = el("div", { class: "role-subtitle" });
  const topicLbl = el("div", { class: "role-heading" });
  const questionEl = el("div", { class: "wrap", style: "font-size:1.15rem;font-weight:700;" });
  const diagramCanvas = el("canvas", { style: "display:none;margin:0.5rem auto;width:100%;max-width:320px;height:auto;" });
  const answerInput = el("input", { type: "text", placeholder: "Type your answer" });
  const checkBtn = el("button", { class: "btn", onClick: () => check(false) }, "CHECK ANSWER");
  const nextBtn = el("button", { class: "btn-secondary", onClick: () => nextQuestion() }, "NEXT →");
  nextBtn.disabled = true;
  const hintEl = el("div", { class: "wrap role-subtitle" });
  const resultEl = el("div", { class: "wrap" });
  const timerLbl = el("div", { class: "role-muted" });
  const container = el("div", {}, [
    progressEl, statusEl, topicLbl, questionEl, diagramCanvas, answerInput,
    ((app.student.settings || {}).maths_keyboard ? mathKeyboard(answerInput) : null),
    el("div", { class: "btn-row" }, [checkBtn, nextBtn]), hintEl, resultEl, timerLbl
  ]);
  answerInput.addEventListener("keydown", (e) => { if (e.key === "Enter") check(false); });

  timer.onTick = (sec) => { timerLbl.textContent = `⏱ ${sec}s remaining`; };
  timer.onFinished = () => { if (!answerInput.disabled) check(true); };

  function pickTopic() {
    if (mode === "choose" && topics.length) return topics[Math.floor(Math.random() * topics.length)];
    if (mode === "speed") return ad.chooseTopic("mixed");
    return ad.chooseTopic(mode);
  }

  function nextQuestion() {
    if (state.answered >= count) return finishSession();
    const topic = pickTopic();
    const diff = mode === "recommended" ? ad.recommendDifficulty(topic) : difficulty;
    state.q = qe.generate(topic, diff);

    topicLbl.textContent = `${state.q.topic_name}  •  Difficulty ${state.q.difficulty}/4`;
    questionEl.innerHTML = formatQuestionHTML(state.q.question);

    // Visual-first: only numbers or shapes in the image — never the full question text
    diagramCanvas.style.display = "block";
    if (state.q.diagram) {
      const dw = Math.min(320, (diagramCanvas.parentElement?.clientWidth || 300));
      drawDiagram(diagramCanvas, state.q.diagram, dw, Math.round(dw * 0.65));
    } else {
      const visual = buildNumberOrShapeVisual(state.q);
      if (visual) {
        drawLessonVisual(diagramCanvas, visual, 320, 160);
      } else {
        diagramCanvas.style.display = "none";
      }
    }

    hintEl.textContent = hints ? "💡 " + state.q.hint : "";
    resultEl.textContent = "";
    answerInput.value = "";
    answerInput.disabled = false;
    nextBtn.disabled = true;
    statusEl.textContent = `Question ${state.answered + 1} of ${count}`;
    setProgress(state.answered);
    if (timed) timer.start(60); else timerLbl.textContent = "";
  }

  function check(timeout) {
    if (!state.q || answerInput.disabled) return;
    timer.stop();
    const userText = answerInput.value.trim();
    const correct = !timeout && answersMatch(userText, state.q.answer);
    const mastery = me.score(state.q.topic, correct, state.q.difficulty);
    state.answered += 1;
    if (correct) state.correct += 1;

    const s = app.student;
    (s.history = s.history || []).push({ question_id: state.q.id, topic: state.q.topic, correct, difficulty: state.q.difficulty });
    s.today_done = (s.today_done || 0) + 1;
    if (correct) {
      s.xp = (s.xp || 0) + (10 + state.q.difficulty * 2);
      econ.reward("correct_answer", `Correct answer — ${state.q.topic_name}`);
    }
    const today = new Date().toISOString().slice(0, 10);
    if (s.today_done >= (s.daily_goal || 20) && s.daily_goal_rewarded_date !== today) {
      econ.reward("daily_goal_met", "Daily goal reached");
      s.daily_goal_rewarded_date = today;
    }

    if (showSolution) {
      resultEl.textContent = correct
        ? `✓ CORRECT!  +XP\n\n${state.q.explanation}\n\nMastery: ${Math.round(mastery * 100)}%`
        : `✗ Not quite${timeout ? " (time's up)" : ""}\nCorrect answer: ${state.q.answer}\n\n${state.q.explanation}\n\nMastery: ${Math.round(mastery * 100)}%`;
    } else {
      resultEl.textContent = correct ? "✓ Recorded." : "✗ Recorded.";
    }
    answerInput.disabled = true;
    nextBtn.disabled = false;
    app.saveStudent();
  }

  function finishSession() {
    const s = app.student;
    s.streak = (s.streak || 0) + (state.correct >= count * 0.6 ? 1 : 0);
    econ.reward("session_complete", `Completed a ${count}-question session`);
    const newlyUnlocked = gam.checkNewUnlocks();
    newlyUnlocked.forEach((ach) => econ.reward("achievement_unlocked", `Unlocked: ${ach.name}`));
    app.saveStudent();

    const accuracy = count ? state.correct / count : 0;
    const rec = ad.nextAction(state.q ? state.q.topic : "", accuracy, null);
    questionEl.textContent = "🏁 Done!"; // plain
    topicLbl.textContent = `Score: ${state.correct}/${count} (${Math.round(accuracy * 100)}%)`;
    diagramCanvas.style.display = "none";
    answerInput.style.display = "none";
    checkBtn.style.display = "none";
    hintEl.textContent = rec;
    resultEl.textContent = "";
    nextBtn.disabled = true;
    statusEl.textContent = "Well done — return to Home or start another session.";

    if (newlyUnlocked.length) {
      container.appendChild(el("div", { class: "card", style: "font-weight:700;" },
        `🏆 NEW ACHIEVEMENT${newlyUnlocked.length > 1 ? "S" : ""}!\n` + newlyUnlocked.map((a) => `${a.icon} ${a.name} — ${a.desc}`).join("\n")));
    }
    container.appendChild(el("button", { class: "btn", onClick: () => app.showHome() }, "🏠 BACK TO HOME"));
    container.appendChild(el("button", { class: "btn-secondary", onClick: () => app.showPractice() }, "🔁 PRACTICE AGAIN"));
  }

  nextQuestion();
  return { title: "Practice Session", body: [container], onUnmount: () => timer.stop() };
}
