import { el, card } from "../ui/widgets.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";

function titleCase(s) { return String(s).replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()); }
function starsForMastery(v) {
  if (v >= 0.8) return "★★★";
  if (v >= 0.5) return "★★☆";
  if (v >= 0.25) return "★☆☆";
  return "☆☆☆";
}

export async function Parent(app) {
  const s = app.student;
  if (!s) {
    return { title: "Parent", body: [card("No learner yet", "Ask your child to open Learnly first.")] };
  }

  const mastery = s.mastery || {};
  const vals = Object.values(mastery);
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  const history = s.history || [];
  const correct = history.filter((h) => h.correct).length;
  const accuracy = history.length ? Math.round((correct / history.length) * 100) : 0;
  const econ = new EconomyEngine(s);
  const gam = new GamificationEngine(s);
  const [unlocked, total] = gam.progressSummary();

  const weekAgo = Date.now() - 7 * 24 * 3600 * 1000;
  const weekHistory = history.filter((h) => {
    const t = Date.parse(h.timestamp || h.at || "");
    return !Number.isNaN(t) && t >= weekAgo;
  });
  const weekCorrect = weekHistory.filter((h) => h.correct).length;

  const weak = (s.weaknesses || []).slice(0, 5).map(titleCase);
  const strong = (s.strengths || []).slice(0, 5).map(titleCase);

  const topicRows = Object.entries(mastery)
    .sort((a, b) => a[1] - b[1])
    .slice(0, 12)
    .map(([t, v]) =>
      el("div", { class: "card" }, [
        el("div", { class: "role-heading wrap" }, `${titleCase(t)}  ${starsForMastery(v)}`),
        el("div", { class: "role-subtitle" }, `${Math.round(v * 100)}%`)
      ])
    );

  const grade = s.grade ?? 5;

  return {
    title: "Parent",
    body: [
      card(s.name || "Learner",
        `Grade ${grade}\n⭐ ${s.xp || 0} XP · Level ${s.level || 1}\n🔥 ${s.streak || 0} day streak · ${econ.balance()} stars`),

      el("div", { class: "section-eyebrow" }, "THIS WEEK"),
      card("Maths activity", `${weekHistory.length} tries · ${weekCorrect} correct\nToday: ${s.today_done || 0} / ${s.daily_goal || 20}`),

      el("div", { class: "section-eyebrow" }, "MATHS OVERALL"),
      card("Snapshot",
        `Average mastery: ${Math.round(avg * 100)}%\nAll-time: ${history.length} · ${accuracy}% correct\nBadges: ${unlocked} / ${total}`),

      card("Needs practice", weak.length ? weak.join(", ") : "None yet"),
      card("Going well", strong.length ? strong.join(", ") : "More practice will fill this in."),

      el("div", { class: "section-eyebrow" }, "TOPICS"),
      ...(topicRows.length ? topicRows : [card("No data yet", "After practice, topics appear here.")]),

      el("div", { class: "role-muted wrap" }, "One short practice session each day supports steady progress."),
      el("button", { class: "btn", onClick: () => app.showHome() }, "← Back")
    ]
  };
}
