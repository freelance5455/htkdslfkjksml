// ---------- PAGE 8: Defaulter Children — group by address or by defaulted vaccine ----------
// Addresses are typed by hand across many visits/vaccinators, so the same
// physical place often shows up with different capitalization or a small
// spelling slip ("Banho Khushk" / "banhu khushak" / "Banho Khushak"). These
// helpers make address grouping ignore case and treat close spelling
// variants as the same place, instead of splitting them into separate rows.
function normalizeAddressText(s){
  return (s || '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s,]/gu, '')
    .replace(/\s*,\s*/g, ', ')
    .replace(/\s+/g, ' ')
    .trim();
}

function splitAddressLocality(addr){
  const idx = addr.indexOf(',');
  if (idx === -1) return { locality: addr, rest: '' };
  return { locality: addr.slice(0, idx).trim(), rest: addr.slice(idx + 1).trim() };
}

function levenshteinDistance(a, b){
  if (a === b) return 0;
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = new Array(n + 1), curr = new Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a[i-1] === b[j-1] ? 0 : 1;
      curr[j] = Math.min(curr[j-1] + 1, prev[j] + 1, prev[j-1] + cost);
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}

// Two locality names count as the same place once the difference between
// them is small relative to their length — enough to catch a typo or a
// missing/extra letter, not enough to merge two genuinely different names.
function localitiesMatch(a, b){
  if (a === b) return true;
  if (!a || !b) return false;
  const maxLen = Math.max(a.length, b.length);
  const allowed = Math.max(1, Math.round(maxLen * 0.28));
  return levenshteinDistance(a, b) <= allowed;
}

// Splits the saved Defaulters List against the Daily Registry records: anyone
// whose overdue vaccine now appears in our own records counts as covered.
// Nothing is stored — this is recomputed every time a view opens, so the moment
// a Daily Registry PDF covering a child is processed, that child drops out of
// the defaulter lists on its own.
function splitDefaultersByCoverage(){
  const store = loadStore();
  const still = [], covered = [];
  Object.values(loadDefaultersStore()).forEach(def => {
    const cov = computeDefaulterCoverage(def, store);
    (defaulterStatusOf(cov) === 'covered' ? covered : still).push(def);
  });
  return { still, covered };
}

function groupDefaultersByAddress(defaulters){
  // Bucket first by the (case-insensitive, exact) town/tehsil portion of the
  // address, then fuzzy-cluster the specific locality within each bucket —
  // so "Banho Khushk , Jarwar, Mirpur Mathelo" and "banhu khushak, Jarwar,
  // Mirpur Mathelo" land in the same result, while two different localities
  // that both happen to sit in "Jarwar, Mirpur Mathelo" stay separate.
  const buckets = {};
  const NO_ADDR_KEY = '__no_address__';
  (defaulters || []).forEach(def => {
    const raw = (def.address || '').trim();
    if (!raw) {
      if (!buckets[NO_ADDR_KEY]) buckets[NO_ADDR_KEY] = [{ items: [], countsByRaw: {} }];
      const cluster = buckets[NO_ADDR_KEY][0];
      cluster.items.push(def);
      cluster.countsByRaw['No address recorded'] = (cluster.countsByRaw['No address recorded'] || 0) + 1;
      return;
    }
    const { locality, rest } = splitAddressLocality(raw);
    const normLocality = normalizeAddressText(locality);
    const restKey = normalizeAddressText(rest);
    if (!buckets[restKey]) buckets[restKey] = [];
    // Match against every spelling variant already folded into a cluster
    // (not just the first one seen) so a middle-ground spelling can bridge
    // two variants that wouldn't be close enough to match each other directly.
    const cluster = buckets[restKey].find(c => c.localities.some(loc => localitiesMatch(loc, normLocality)));
    if (cluster) {
      cluster.items.push(def);
      cluster.countsByRaw[raw] = (cluster.countsByRaw[raw] || 0) + 1;
      if (!cluster.localities.includes(normLocality)) cluster.localities.push(normLocality);
    } else {
      buckets[restKey].push({ localities: [normLocality], items: [def], countsByRaw: { [raw]: 1 } });
    }
  });

  const groups = {};
  Object.values(buckets).forEach(clusters => {
    clusters.forEach(cluster => {
      const bestRaw = Object.entries(cluster.countsByRaw).sort((a, b) => b[1] - a[1])[0][0];
      let key = bestRaw, n = 2;
      while (Object.prototype.hasOwnProperty.call(groups, key)) key = `${bestRaw} (${n++})`;
      groups[key] = cluster.items;
    });
  });
  return groups;
}

function groupDefaultersByVaccine(defaulters){
  const groups = {};
  (defaulters || []).forEach(def => {
    (def.defaultedVaccines || []).forEach(tag => {
      if (!groups[tag]) groups[tag] = [];
      groups[tag].push(def);
    });
  });
  return groups;
}

function defVaccineLabel(tag){ return EPI_SHORT[tag] || TT_LABELS[tag] || tag; }

// Turns a plain list of defaulters into the { def, cov, status } rows that
// both renderDefaulterDetailCards and buildDefaultersPdf work with.
// Records saved by an older build carry no EPI No and would just show a dash
// forever with no explanation. Wherever that happens, say what to do about it.
function epiMissingNoticeHtml(list){
  const missing = (list || []).filter(d => !d.epiNo).length;
  if (!missing) return '';
  const total = (list || []).length;
  return `<div class="card" style="margin-top:0;border-color:#e2b8a3;background:#fdf4ef;">
    <div class="note" style="margin:0;color:#9d174d;">
      <b>EPI No missing on ${missing} of ${total} records.</b> They were saved before the EPI No could be read.
      Go to the main menu → <b>Back to Add New PDF Files</b> → <b>📋 Defaulters List</b>, pick the
      <b>Children Defaulters Report</b> again and press <b>Process and Save Data</b>. The EPI No will then fill in everywhere.
    </div></div>`;
}

function setEpiNotice(elId, list){
  const el = document.getElementById(elId);
  if (el) el.innerHTML = epiMissingNoticeHtml(list);
}

function defaulterResultsFor(list){
  const store = loadStore();
  return (list || []).map(def => {
    const cov = computeDefaulterCoverage(def, store);
    return { def, cov, status: defaulterStatusOf(cov) };
  });
}

function renderDefaulterDetailCards(list){
  const store = loadStore();
  return list.map((def, idx) => {
    const cov = computeDefaulterCoverage(def, store);
    const status = defaulterStatusOf(cov);
    const badgeColor = status === 'covered' ? 'var(--accent)' : 'var(--danger)';
    const badgeLabel = status === 'covered' ? '✅ Covered' : '⚠ Still Defaulting';
    const dobText = def.dob ? `${String(def.dob.day).padStart(2,'0')}/${String(def.dob.month).padStart(2,'0')}/${def.dob.year}` : '—';
    const vaccineText = (def.defaultedVaccines.map(defVaccineLabel).join(', ')) || '—';
    const enrollText = [def.enrollmentCenter, def.enrollmentVaccinator].filter(Boolean).join(' / ') || '—';
    return `<article class="child-card result-card">
      <div class="qr-code"><span class="qr-label">EPI No</span><span class="qr-number">${def.epiNo ? escapeHtml(def.epiNo) : '—'}</span></div>
      <div class="qr-code"><span class="qr-label">QR Code</span><span class="qr-right"><span class="qr-number">${escapeHtml(def.id)}</span>${def.id ? `<button type="button" class="qr-copy-btn" data-qr-copy="${escapeHtml(def.id)}">📋 Copy</button>` : ''}</span></div>
      <div class="result-line"><span class="result-label">Status</span><span class="result-value" style="color:${badgeColor};font-weight:700;">${badgeLabel}</span></div>
      <div class="result-line"><span class="result-label">Name</span><span class="result-value person-name">${def.name ? escapeHtml(def.name) : 'Name not recorded'}</span></div>
      <div class="result-line"><span class="result-label">Father/Husband</span><span class="result-value">${def.fatherName ? escapeHtml(def.fatherName) : '—'}</span></div>
      <div class="result-line"><span class="result-label">Date of Birth</span><span class="result-value">${dobText}</span></div>
      <div class="result-line"><span class="result-label">Defaulted Vaccine</span><span class="result-value">${escapeHtml(vaccineText)}</span></div>
      <div class="result-line"><span class="result-label">Due / Defaulted Date</span><span class="result-value">${dmy(def.dueDate) || '—'} / ${dmy(def.defaultedDate) || '—'}</span></div>
      <div class="result-address"><span class="result-label">Address</span><span class="result-value">${def.address ? escapeHtml(def.address) : '—'}</span></div>
      <div class="result-line"><span class="result-label">Enrollment</span><span class="result-value">${escapeHtml(enrollText)}</span></div>
      <div class="result-line"><span class="result-label">Last Visited Center</span><span class="result-value">${def.lastVisitedCenter ? escapeHtml(def.lastVisitedCenter) : '—'}</span></div>
      <div class="result-meta"><span>No. ${idx + 1}</span><span>${escapeHtml(def.status || '')}</span></div>
    </article>`;
  }).join('');
}

let defDetailReturnTo = 'defaulterChildrenView';

function showDefDetailView(list, title, returnTo){
  hideAllViews();
  document.getElementById('defDetailView').style.display = 'block';
  window.scrollTo(0, 0);
  document.getElementById('defDetailTitle').textContent = title;
  setEpiNotice('defDetailEpiNotice', list);
  document.getElementById('defDetailTable').innerHTML = list && list.length
    ? `<div class="child-list">${renderDefaulterDetailCards(list)}</div>`
    : '<div style="color:var(--muted);">No records found.</div>';
  lastRendered['defDetailTable'] = list || [];
  defDetailReturnTo = returnTo;
}

function showDefaulterChildrenView(){
  hideAllViews();
  document.getElementById('defaulterChildrenView').style.display = 'block';
  window.scrollTo(0, 0);
  // Recomputed on every visit, so the split always reflects the newest Daily
  // Registry data without the user having to do anything.
  const { still, covered } = splitDefaultersByCoverage();
  // Records saved by an older version have no EPI No and would silently show a
  // dash forever. Say so plainly instead, with the fix.
  const all = still.concat(covered);
  const noEpi = all.filter(d => !d.epiNo).length;
  const epiNote = noEpi
    ? `<div class="card" style="margin-top:0;border-color:#e2b8a3;background:#fdf4ef;"><div class="note" style="margin:0;color:#9d174d;">${noEpi} of ${all.length} saved defaulters have no <b>EPI No</b> — they were saved before it could be read. Upload the <b>Children Defaulters Report</b> again and press Process to fill them in.</div></div>`
    : '';
  document.getElementById('defChildrenCounts').innerHTML = ((still.length + covered.length)
    ? `<div class="card" style="margin-top:0;"><div class="age-grid">
         <div class="age-box"><span>⚠ Still to chase</span><span class="n" style="color:var(--danger);">${still.length}</span></div>
         <div class="age-box"><span>✅ Covered</span><span class="n" style="color:var(--accent);">${covered.length}</span></div>
       </div></div>`
    : '') + epiNote;
}

function showDefCoveredView(){
  const { covered } = splitDefaultersByCoverage();
  showDefDetailView(covered, `✅ Covered — ${covered.length}`, 'defaulterChildrenView');
}

function showDefByAddressView(){
  hideAllViews();
  document.getElementById('defByAddressView').style.display = 'block';
  window.scrollTo(0, 0);
  // Covered children are left out: once our Daily Registry shows the overdue
  // vaccine was given, they belong under "Covered", not in the chase list.
  const stillList = splitDefaultersByCoverage().still;
  setEpiNotice('defByAddressEpiNotice', stillList);
  const groups = groupDefaultersByAddress(stillList);
  const entries = Object.entries(groups).sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0]));
  const listEl = document.getElementById('defByAddressList');
  if (!entries.length) {
    listEl.innerHTML = '<div class="card"><div style="color:var(--muted);">Nothing left to chase — either no Defaulters List has been processed, or everyone on it has been covered.</div></div>';
    return;
  }
  listEl.innerHTML = `<div class="card">${entries.map(([addr, list], i) => `
    <div class="date-row addr-row">
      <button type="button" class="addr-row-main" data-i="${i}">
        <span class="dname">📍 ${escapeHtml(addr)}</span>
        <span class="dcount">${list.length} ${list.length === 1 ? 'record' : 'records'}</span>
      </button>
      <button type="button" class="age-pdf-btn" data-i="${i}" title="Share / Download PDF for ${escapeHtml(addr)}">📤</button>
    </div>`).join('')}</div>`;
  listEl.querySelectorAll('.addr-row-main').forEach((btn, i) => {
    const [addr, list] = entries[i];
    btn.addEventListener('click', () => showDefDetailView(list, `📍 ${addr}`, 'defByAddressView'));
  });
  listEl.querySelectorAll('.date-row.addr-row .age-pdf-btn').forEach((btn, i) => {
    const [addr, list] = entries[i];
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      // buildDefaultersPdf reads each row as { def, cov, status }. This button
      // was handing it the RAW defaulter objects, so `def` came out undefined
      // and the builder threw on the very first row — the download simply did
      // nothing. Wrap them the same way the "Defaulters Covered" page does.
      runDefaultersExportFlow(`Defaulters — ${addr}`, defaulterResultsFor(list), 'address-' + (i + 1));
    });
  });
}

function showDefByVaccineView(){
  hideAllViews();
  document.getElementById('defByVaccineView').style.display = 'block';
  window.scrollTo(0, 0);
  const stillList = splitDefaultersByCoverage().still;
  setEpiNotice('defByVaccineEpiNotice', stillList);
  const groups = groupDefaultersByVaccine(stillList);
  const order = ['BCG','HepB','OPV0','Penta1','Penta2','Penta3','Measles1','Measles2','TT1','TT2','TT3','TT4','TT5'];
  const present = order.filter(t => groups[t] && groups[t].length);
  const gridEl = document.getElementById('defByVaccineGrid');
  if (!present.length) {
    gridEl.innerHTML = '<div style="color:var(--muted);">Nothing left to chase — either no Defaulters List has been processed, or everyone on it has been covered.</div>';
    return;
  }
  gridEl.innerHTML = present.map(t => `
    <div class="epi-box clickable" data-tag="${t}">
      <div class="epi-box-top">
        <div class="n">${groups[t].length}</div>
        <button type="button" class="age-pdf-btn" data-tag="${t}" title="Share / Download PDF for ${escapeHtml(defVaccineLabel(t))}" aria-label="Share or download PDF for ${escapeHtml(defVaccineLabel(t))} defaulters">📤</button>
      </div>
      <div class="l">${defVaccineLabel(t)}</div>
    </div>`).join('');
  gridEl.querySelectorAll('.epi-box').forEach(box => {
    const tag = box.dataset.tag;
    box.addEventListener('click', () => showDefDetailView(groups[tag], `💉 ${defVaccineLabel(tag)} — Defaulters`, 'defByVaccineView'));
  });
  // The download button sits inside the tile, so its click must not also open
  // the tile's detail list.
  gridEl.querySelectorAll('.age-pdf-btn').forEach(btn => {
    const tag = btn.dataset.tag;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      runDefaultersExportFlow(`${defVaccineLabel(tag)} — Defaulters`, defaulterResultsFor(groups[tag]), 'vaccine-' + tag);
    });
  });
}

document.getElementById('btnGoDefaulterChildren').addEventListener('click', showDefaulterChildrenView);
document.getElementById('btnGoDefByAddress').addEventListener('click', showDefByAddressView);
document.getElementById('btnGoDefByVaccine').addEventListener('click', showDefByVaccineView);
document.getElementById('btnGoDefCovered').addEventListener('click', showDefCoveredView);

// Checks one defaulter entry against the saved children/women records: which
// of the defaulted vaccine(s) have already been given (per our own records),
// and — when covered — exactly when and by whom, reusing the same per-visit
// breakdown used everywhere else in the app.
function computeDefaulterCoverage(def, store){
  const rec = store[def.id];
  if (!rec) return { found: false, coveredTags: [], allCovered: false, coverageDetail: null };
  const coveredTags = def.defaultedVaccines.filter(tag => {
    const isTt = tag.startsWith('TT');
    const tags = isTt ? classifyTT(rec.doses) : classifyEpi(rec.doses);
    return tags.includes(tag);
  });
  // A defaulter entry can list two vaccines together (e.g. "Penta2, Measles2")
  // when the child is behind on more than one dose at the same time. Giving
  // EITHER one of the two per the EPI schedule — or both — is enough to
  // consider the child covered; it is not required that every listed vaccine
  // be given before counting it as covered.
  // There are only ever TWO outcomes here. A 'partial' state was wired through
  // the whole UI (amber badge, "Partially Covered" label, its own counter) but
  // partiallyCovered was hard-coded to false, so it could never be reached —
  // all of that dead branching has been removed.
  const allCovered = coveredTags.length > 0;
  const coverageDetail = coveredTags.length ? dateAndVaccinatorText(rec) : null;
  return { found: true, coveredTags, allCovered, coverageDetail, rec };
}

function defaulterStatusOf(cov){ return cov.allCovered ? 'covered' : 'still'; }
