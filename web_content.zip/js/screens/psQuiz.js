import { el, card, showAlert } from "../ui/widgets.js";
import { PhysSciEngine } from "../engines/physSciEngine.js";
import { answersMatch } from "../engines/answerCheck.js";
import { drawDiagram } from "../ui/render.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";

/**
 * Short quiz mode for Physical Sciences — pick topic (or mix), answer with feedback.
 */
export async function PsQuizSession(app, { topicId = null } = {}) {
  const engine = new PhysSciEngine();
  const econ = new EconomyEngine(app.student);
  const gam = new GamificationEngine(app.student);
  const state = { asked: 0, correct: 0, q: null, topicId };

  const topicPool = topicId
    ? [topicId]
    : [
        "ps_vectors", "ps_newtons_laws", "ps_gravitation", "ps_electrostatics",
        "ps_electromagnetism", "ps_circuits", "ps_waves", "ps_bonding",
        "ps_imf", "ps_stoich", "ps_energy_chem", "ps_acids_bases", "ps_redox"
      ];

  const scoreEl = el("div", { class: "role-subtitle" });
  const topicEl = el("div", { class: "role-heading wrap" });
  const questionEl = el("div", { class: "wrap", style: "font-size:1.08rem;font-weight:700;white-space:pre-wrap;" });
  const diagramHost = el("div", { style: "width:100%;max-width:320px;margin:0.4rem auto;" });
  const answerInput = el("input", { type: "text", placeholder: "Type your answer", style: "width:100%;" });
  const feedback = el("div", { class: "wrap", style: "margin-top:0.5rem;" });
  const solutionBox = el("div", { class: "card", style: "display:none;margin-top:0.5rem;" });

  function updateScore() {
    scoreEl.textContent = `Score ${state.correct} / ${state.asked}` + (topicId ? "" : " · mixed topics");
  }

  function nextQ() {
    feedback.textContent = "";
    solutionBox.style.display = "none";
    solutionBox.innerHTML = "";
    diagramHost.innerHTML = "";
    answerInput.value = "";
    answerInput.disabled = false;

    const tid = topicPool[Math.floor(Math.random() * topicPool.length)];
    const q = engine.generate(tid, 2);
    state.q = q;
    topicEl.textContent = (q.topic_name || tid).replaceAll("_", " ");
    questionEl.textContent = q.question || "";
    if (q.diagram) {
      const c = el("canvas", { style: "display:block;width:100%;height:auto;" });
      diagramHost.appendChild(c);
      requestAnimationFrame(() => drawDiagram(c, q.diagram, 300, 210));
    }
    updateScore();
  }

  function check() {
    if (!state.q || answerInput.disabled) return;
    const user = answerInput.value.trim();
    if (!user) return showAlert("Answer", "Type an answer first.");
    state.asked += 1;
    const ok = answersMatch(user, state.q.answer);
    if (ok) {
      state.correct += 1;
      feedback.textContent = "✓ Correct";
      feedback.style.color = "var(--accent)";
      try { if (typeof econ.earn === "function") econ.earn("practice", "PS quiz"); else if (typeof econ.reward === "function") econ.reward("practice", "PS quiz"); } catch { /* ignore */ }
      app.student.xp = (app.student.xp || 0) + 8;
      app.student.history = app.student.history || [];
      app.student.history.push({ topic: state.q.topic, correct: true, question_id: state.q.id });
    } else {
      feedback.textContent = "✗ Not quite";
      feedback.style.color = "#c0392b";
      app.student.history = app.student.history || [];
      app.student.history.push({ topic: state.q.topic, correct: false, question_id: state.q.id });
    }
    solutionBox.style.display = "";
    solutionBox.appendChild(el("div", { class: "role-heading" }, "Solution"));
    solutionBox.appendChild(el("div", { class: "wrap" }, `Answer: ${state.q.answer}`));
    if (state.q.explanation) {
      solutionBox.appendChild(el("div", { class: "wrap role-muted", style: "margin-top:0.35rem;white-space:pre-wrap;" }, state.q.explanation));
    }
    answerInput.disabled = true;
    gam.checkNewUnlocks();
    app.saveStudent();
    updateScore();
  }

  nextQ();

  return {
    title: topicId ? "🧠 PS Quiz" : "🧠 PS Quiz · Mix",
    bottomNavKey: "papers",
    body: [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "ps_quiz" }) }, "← Topics"),
      scoreEl,
      topicEl,
      questionEl,
      diagramHost,
      answerInput,
      el("div", { class: "btn-row", style: "margin-top:0.5rem;" }, [
        el("button", { class: "btn", onClick: check }, "CHECK"),
        el("button", { class: "btn-secondary", onClick: nextQ }, "NEXT →")
      ]),
      feedback,
      solutionBox
    ]
  };
}
