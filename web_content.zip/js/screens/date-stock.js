// ---------- PAGE 6: Results by Date — read every processed record and show who was vaccinated on the chosen date ----------
let dateFilteredRecordsGlobal = [];
let currentSelectedDateStr = null;

function showDateView(){
  hideAllViews();
  document.getElementById('dateView').style.display = 'block';
  populateDateList();
  window.scrollTo(0, 0);
}

// Reads every processed record and builds the list of distinct vaccination
// dates found in the PDFs — one date if only one file/date is present,
// more dates as soon as more files/dates have been processed.
function populateDateList(){
  const counts = {}; // 'YYYY-MM-DD' -> count
  for (const r of allRecordsGlobal) {
    if (!r.vaccDate) continue;
    const y = r.vaccDate.year, m = r.vaccDate.month, d = r.vaccDate.day;
    if (!y || !m || !d) continue;
    const key = `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    counts[key] = (counts[key] || 0) + 1;
  }
  const keys = Object.keys(counts).sort((a, b) => b.localeCompare(a)); // most recent first
  const listEl = document.getElementById('dateList');
  if (!keys.length) {
    listEl.innerHTML = '<div style="color:var(--muted);">No vaccination dates found yet.</div>';
    return;
  }
  listEl.innerHTML = keys.map(key => {
    const [y, m, d] = key.split('-');
    return `<button type="button" class="date-row" data-date="${key}">
      <span class="dname">📅 ${d}/${m}/${y}</span>
      <span class="dcount">${counts[key]} record${counts[key] === 1 ? '' : 's'}</span>
    </button>`;
  }).join('');
  listEl.querySelectorAll('.date-row').forEach(btn => {
    btn.addEventListener('click', () => runDateFilter(btn.dataset.date));
  });
}

function runDateFilter(dateQ){
  const section = document.getElementById('dateResultsSection');
  if (!dateQ) { section.style.display = 'none'; return; }
  const parts = dateQ.split('-').map(Number);
  const dateParts = { y: parts[0], m: parts[1], d: parts[2] };
  currentSelectedDateStr = dateQ;

  const results = allRecordsGlobal.filter(r =>
    r.vaccDate && r.vaccDate.year === dateParts.y && r.vaccDate.month === dateParts.m && r.vaccDate.day === dateParts.d
  );
  dateFilteredRecordsGlobal = results;
  currentGroupType = 'date';

  const dd = String(dateParts.d).padStart(2,'0'), mm = String(dateParts.m).padStart(2,'0');
  document.getElementById('dateResultsDateLabel').textContent = `${dd}/${mm}/${dateParts.y}`;
  document.getElementById('dateResultsCount').textContent = `(${results.length} found)`;
  fillDashboard(document.getElementById('dateDash'), results, false,
    (tag, kind) => showDrillView(tag, kind, false));  // no "Download/Share All Category Work" button on Results by Date
  renderDetailTable(results, 'dateDetailTable');
  section.style.display = 'block';
  document.getElementById('dateResultsSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ---------- PAGE 6b: Stock — vaccine doses given & syringes used, one row per
// vaccination date. Unlike the dashboards above (which classify doses into
// specific named tags like "Penta2" for the EPI schedule and de-duplicate a
// child to their single merged record), Stock is a raw count straight off
// each date's PDF rows: it counts every visit for that date and, for every
// vaccine column with ANY value recorded (Y, or a 0-5 dose number), adds one
// dose to that column's total — because every such row used one real syringe
// (or, for OPV, one real oral dose) on that day, no matter which dose number
// it was.
const STOCK_COLS = [
  { key:'BCG',     label:'BCG Doses' },
  { key:'OPV',     label:'OPV Doses (0+1+2+3)' },
  { key:'Penta',   label:'Penta Doses (1+2+3)' },
  { key:'PCV',     label:'PCV Doses (1+2+3)' },
  { key:'ROTA',    label:'Rota Doses (1+2)' },
  { key:'IPV',     label:'IPV Doses (1+2)' },
  { key:'Measles', label:'Measles Doses (1+2)' },
  { key:'TCV',     label:'TCV Doses' },
  { key:'TT',      label:'TT Doses (1+2+3+4+5)' }
];

// Reads every processed record's per-visit doses (not the merged/deduplicated
// top-level record) and tallies them per calendar date, so a child who was
// vaccinated on more than one date is correctly counted on EACH of those
// dates rather than only once under their most recent visit.
function computeStockByDate(){
  const map = {}; // 'YYYY-MM-DD' -> { BCG:0, OPV:0, ... }
  for (const r of allRecordsGlobal) {
    const visits = (r.visits && r.visits.length) ? r.visits : [{ vaccDate: r.vaccDate, doses: r.doses }];
    for (const v of visits) {
      if (!v.vaccDate) continue;
      const y = v.vaccDate.year, m = v.vaccDate.month, d = v.vaccDate.day;
      if (!y || !m || !d) continue;
      const key = `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
      if (!map[key]) {
        const row = {};
        STOCK_COLS.forEach(c => { row[c.key] = 0; });
        map[key] = row;
      }
      const doses = v.doses || {};
      STOCK_COLS.forEach(c => {
        const val = doses[c.key];
        if (val !== undefined && val !== null && val !== '') map[key][c.key]++;
      });
    }
  }
  return map;
}

function showStockView(){
  hideAllViews();
  document.getElementById('stockView').style.display = 'block';
  renderStockList();
  window.scrollTo(0, 0);
}

function showQrResultView(){
  hideAllViews();
  document.getElementById('qrResultView').style.display = 'block';
  renderQrList();
  window.scrollTo(0, 0);
}

// ---------- Stock view: Date by Date / Running Total ----------
// stockMode 'daily'   = each date's own numbers (default)
// stockMode 'running' = each date's card shows the total of ALL dates up to and
//                       including that date, so the numbers keep adding up
let stockMode = 'daily';

function emptyStockRow(){
  const row = {};
  STOCK_COLS.forEach(c => { row[c.key] = 0; });
  return row;
}
function addStockRows(a, b){
  const out = emptyStockRow();
  STOCK_COLS.forEach(c => { out[c.key] = (a[c.key] || 0) + (b[c.key] || 0); });
  return out;
}
function stockDateLabel(key){ const [y, m, d] = key.split('-'); return `${d}/${m}/${y}`; }

// One block: dose boxes + syringe counts.
function stockCardHtml(title, c, subtitle){
  // 24G Syringes: every injectable dose EXCEPT BCG (which uses a 26G
  // syringe) and OPV (which is oral, not injected).
  const g24 = c.Penta + c.PCV + c.IPV + c.Measles + c.TCV + c.TT;
  const g26 = c.BCG;
  const boxes = STOCK_COLS.map(col => `
      <div class="epi-box"><div class="n">${c[col.key]}</div><div class="l">${col.label}</div></div>
    `).join('');
  const inner = `<h2 style="margin-top:0;text-align:center;">${title}</h2>
      ${subtitle ? `<div class="note" style="text-align:center;margin:-4px 0 10px;">${subtitle}</div>` : ''}
      <div class="epi-grid">${boxes}</div>
      <div class="age-grid" style="margin-top:10px;">
        <div class="age-box"><span>24G Syringes</span><span class="n">${g24}</span></div>
        <div class="age-box"><span>26G Syringes</span><span class="n">${g26}</span></div>
      </div>`;
  return `<div class="card" style="margin-bottom:12px;">${inner}</div>`;
}

function renderStockList(){
  const map = computeStockByDate();
  const asc = Object.keys(map).sort();                 // oldest -> newest (for adding up)
  const listEl = document.getElementById('stockList');
  if (!asc.length) {
    listEl.innerHTML = '<div class="card"><div style="color:var(--muted);">No vaccination dates found yet.</div></div>';
    return;
  }

  // ---- view switch ----
  const modeBar = `<div style="display:flex;gap:8px;margin-bottom:12px;">
      <button type="button" class="go${stockMode === 'daily' ? '' : ' secondary'}" data-stock-mode="daily" style="flex:1;margin:0;">📅 Date by Date</button>
      <button type="button" class="go${stockMode === 'running' ? '' : ' secondary'}" data-stock-mode="running" style="flex:1;margin:0;">📈 Running Total</button>
    </div>`;

  // ---- one card per date, most recent first ----
  let running = emptyStockRow();
  const cards = {};
  asc.forEach(k => {
    running = addStockRows(running, map[k]);
    cards[k] = stockMode === 'running'
      ? stockCardHtml(`📅 ${stockDateLabel(k)}`, running, `Total of all dates up to ${stockDateLabel(k)}`)
      : stockCardHtml(`📅 ${stockDateLabel(k)}`, map[k]);
  });
  listEl.innerHTML = modeBar + asc.slice().reverse().map(k => cards[k]).join('');

  listEl.querySelectorAll('[data-stock-mode]').forEach(btn => btn.addEventListener('click', () => {
    stockMode = btn.dataset.stockMode; renderStockList();
  }));
}
