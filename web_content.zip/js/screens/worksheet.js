/**
 * Fillable worksheet session — journals, tables, label-the-diagram.
 */
import { el, card } from "../ui/widgets.js";
import { WorksheetEngine } from "../engines/worksheetEngine.js";
import { drawDiagram } from "../ui/render.js";

function norm(s) {
  return String(s || "")
    .toLowerCase()
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9\s=+\-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function answersMatch(user, key) {
  const u = norm(user), k = norm(key);
  if (!u) return false;
  if (u === k) return true;
  if (k.includes(u) || u.includes(k)) return true;
  // numeric: strip spaces
  const un = u.replace(/\s/g, ""), kn = k.replace(/\s/g, "");
  if (un && un === kn) return true;
  return false;
}

function renderJournal(ws, state) {
  const table = el("table", { class: "worksheet-table" });
  const thead = el("thead");
  thead.appendChild(el("tr", {}, ws.cols.map((c) => el("th", {}, c))));
  table.appendChild(thead);
  const tbody = el("tbody");
  const inputs = [];
  ws.rows.forEach((row, ri) => {
    const tr = el("tr");
    const cells = [row.date, row.details, row.fol, row.debit, row.credit];
    cells.forEach((val, ci) => {
      const td = el("td");
      const isAmount = ci >= 3;
      if (row.blank && isAmount && ((row.keyField === "debit" && ci === 3) || (row.keyField === "credit" && ci === 4) || (!row.keyField && !val))) {
        const inp = el("input", { type: "text", placeholder: "?", "data-key": row.key || "" });
        inputs.push({ input: inp, key: row.key });
        td.appendChild(inp);
      } else {
        td.textContent = val || "";
      }
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  state.inputs = inputs;
  return table;
}

function renderSimpleTable(ws, state) {
  const table = el("table", { class: "worksheet-table" });
  const thead = el("thead");
  thead.appendChild(el("tr", {}, ws.cols.map((c) => el("th", {}, c))));
  table.appendChild(thead);
  const tbody = el("tbody");
  const inputs = [];
  ws.rows.forEach((row) => {
    const tr = el("tr");
    const vals = ws.type === "trial_balance"
      ? [row.account, row.debit, row.credit]
      : [row.details, row.amount];
    vals.forEach((val, ci) => {
      const td = el("td");
      const amountCol = ws.type === "trial_balance" ? ci >= 1 : ci === 1;
      if (row.blank && amountCol && (ws.type !== "trial_balance" || (row.keyField === "debit" && ci === 1) || (row.keyField === "credit" && ci === 2) || !row.keyField)) {
        const inp = el("input", { type: "text", placeholder: "?" });
        inputs.push({ input: inp, key: row.key });
        td.appendChild(inp);
      } else td.textContent = val || "";
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  state.inputs = inputs;
  return table;
}

function renderTAccount(ws, state) {
  const wrap = el("div");
  wrap.appendChild(el("div", { class: "role-heading center" }, ws.account || "Account"));
  const table = el("table", { class: "worksheet-table" });
  table.appendChild(el("thead", {}, [el("tr", {}, [el("th", {}, "Debit"), el("th", {}, "Credit")])]));
  const tbody = el("tbody");
  const inputs = [];
  const n = Math.max(ws.debit.length, ws.credit.length);
  for (let i = 0; i < n; i++) {
    const tr = el("tr");
    const d = ws.debit[i];
    const c = ws.credit[i];
    const tdD = el("td");
    if (d) {
      if (d.blank) {
        const inp = el("input", { type: "text", placeholder: d.label + " ?" });
        inputs.push({ input: inp, key: d.key });
        tdD.appendChild(el("div", { class: "role-muted" }, d.label));
        tdD.appendChild(inp);
      } else tdD.textContent = `${d.label}  ${d.amount}`;
    }
    const tdC = el("td");
    if (c) {
      if (c.blank) {
        const inp = el("input", { type: "text", placeholder: c.label + " ?" });
        inputs.push({ input: inp, key: c.key });
        tdC.appendChild(el("div", { class: "role-muted" }, c.label));
        tdC.appendChild(inp);
      } else tdC.textContent = `${c.label}  ${c.amount}`;
    }
    tr.appendChild(tdD); tr.appendChild(tdC);
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  state.inputs = inputs;
  return wrap;
}

function renderLabelDiagram(ws, state) {
  const wrap = el("div");
  const host = el("div", { class: "label-diagram-wrap" });
  const canvas = el("canvas");
  host.appendChild(canvas);
  wrap.appendChild(host);
  requestAnimationFrame(() => drawDiagram(canvas, ws.diagram, 320, 220));
  const inputs = [];
  ws.labels.forEach((lab) => {
    const row = el("div", { class: "label-slot" });
    row.appendChild(el("div", { class: "role-muted", style: "min-width:42%;" }, lab.prompt));
    const inp = el("input", { type: "text", placeholder: "Your label" });
    inputs.push({ input: inp, key: lab.key });
    row.appendChild(inp);
    wrap.appendChild(row);
  });
  state.inputs = inputs;
  return wrap;
}


function renderMatch(ws, state) {
  const wrap = el("div");
  wrap.appendChild(el("div", { class: "role-heading" }, "Definitions"));
  ws.definitions.forEach((d) => {
    wrap.appendChild(el("div", { class: "role-subtitle wrap", style: "margin:0.25rem 0;" }, `${d.letter}. ${d.text}`));
  });
  wrap.appendChild(el("div", { class: "role-heading", style: "margin-top:0.75rem;" }, "Terms — write the letter"));
  const inputs = [];
  ws.terms.forEach((term) => {
    const row = el("div", { class: "label-slot" });
    row.appendChild(el("div", { style: "font-weight:700;min-width:40%;" }, term.term));
    const inp = el("input", { type: "text", placeholder: "A, B, C…", style: "max-width:4rem;text-transform:uppercase;" });
    inputs.push({ input: inp, key: term.key });
    row.appendChild(inp);
    wrap.appendChild(row);
  });
  state.inputs = inputs;
  return wrap;
}

function renderPaper(ws, state) {
  const wrap = el("div");
  wrap.appendChild(el("div", { class: "card", style: "white-space:pre-wrap;font-size:0.9rem;" }, ws.narrative));
  const inputs = [];
  ws.parts.forEach((part) => {
    const block = el("div", { class: "card", style: "margin-top:0.5rem;" });
    block.appendChild(el("div", { class: "wrap", style: "font-weight:700;margin-bottom:0.4rem;" }, part.prompt));
    const inp = el("input", { type: "text", placeholder: "Your answer" });
    inputs.push({ input: inp, key: part.key, hint: part.hint });
    block.appendChild(inp);
    wrap.appendChild(block);
  });
  state.inputs = inputs;
  return wrap;
}

export async function WorksheetSession(app, { subjectId = null, topicId = null, mode = null } = {}) {
  const sid = subjectId || app.student?.subject || "accounting";
  const grade = app.student?.grade ?? 11;
  const engine = new WorksheetEngine(sid, grade);
  const state = { ws: null, inputs: [] };

  const titleEl = el("div", { class: "role-heading wrap" });
  const narrEl = el("div", { class: "role-subtitle wrap" });
  const workHost = el("div");
  const feedback = el("div", { class: "wrap" });
  const solution = el("div", { class: "card", style: "display:none;" });

  function load() {
    feedback.textContent = "";
    solution.style.display = "none";
    solution.innerHTML = "";
    workHost.innerHTML = "";
    state.ws = engine.generate(topicId, mode);
    const ws = state.ws;
    titleEl.textContent = ws.title;
    narrEl.textContent = ws.narrative || "";
    let node;
    if (ws.type === "journal") node = renderJournal(ws, state);
    else if (ws.type === "t_account") node = renderTAccount(ws, state);
    else if (ws.type === "trial_balance" || ws.type === "bank_recon") node = renderSimpleTable(ws, state);
    else if (ws.type === "match_definitions") node = renderMatch(ws, state);
    else if (ws.type === "paper_style") node = renderPaper(ws, state);
    else node = renderLabelDiagram(ws, state);
    workHost.appendChild(node);
  }

  function check() {
    if (!state.ws || !state.inputs.length) return;
    let correct = 0;
    state.inputs.forEach(({ input, key }) => {
      const ok = answersMatch(input.value, key);
      input.classList.remove("ok", "bad");
      input.classList.add(ok ? "ok" : "bad");
      if (ok) correct += 1;
    });
    const total = state.inputs.length;
    feedback.textContent = `Score ${correct} / ${total}`;
    solution.style.display = "";
    solution.innerHTML = "";
    solution.appendChild(el("div", { class: "role-heading" }, "Model answers"));
    state.inputs.forEach(({ key, hint }, i) => {
      solution.appendChild(el("div", { class: "wrap" }, `${i + 1}. ${key}`));
      if (hint) solution.appendChild(el("div", { class: "role-muted wrap" }, hint));
    });
    if (correct === total) {
      app.student.xp = (app.student.xp || 0) + (state.ws.marks || 4);
      app.student.today_done = (app.student.today_done || 0) + 1;
      app.saveStudent();
    }
  }

  load();

  return {
    title: "✏️ Worksheet",
    bottomNavKey: "practice",
    body: [
      el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"),
      titleEl,
      narrEl,
      workHost,
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn", onClick: check }, "CHECK"),
        el("button", { class: "btn-secondary", onClick: load }, "NEW →")
      ]),
      feedback,
      solution
    ]
  };
}
