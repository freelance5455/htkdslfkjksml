import { el, card, masteryBar } from "../ui/widgets.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { EconomyEngine } from "../engines/economyEngine.js";

function titleCase(s) { return s.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()); }
function starsFor(v) {
  if (v >= 0.8) return "★★★";
  if (v >= 0.5) return "★★☆";
  if (v >= 0.25) return "★☆☆";
  return "☆☆☆";
}

export async function Profile(app) {
  const s = app.student;
  const gm = app.gradeManager();
  const mastery = s.mastery || {};
  const vals = Object.values(mastery);
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  const gam = new GamificationEngine(s);
  const econ = new EconomyEngine(s);
  const [unlocked, total] = gam.progressSummary();

  const body = [
    card(s.name || "Learner",
      `Grade 5 Mathematics · Term ${s.term ?? 1}\n⭐ ${s.xp ?? 0} XP · Level ${s.level ?? 1}\n🪙 ${econ.balance()} stars · 🏅 ${unlocked}/${total} badges`),
    card("🎯 Today's goal", `${s.today_done ?? 0} / ${s.daily_goal ?? 20} · 🔥 ${s.streak ?? 0} day streak`),
    card("📊 Overall", `${Math.round(avg * 100)}% average mastery`),

    el("div", { class: "section-eyebrow" }, "TOPICS"),
    ...Object.entries(mastery).sort((a, b) => b[1] - a[1]).map(([topic, val]) =>
      el("div", { class: "card" }, [
        el("div", { class: "role-heading wrap" }, `${titleCase(topic)} ${starsFor(val)}`),
        masteryBar("Mastery", val)
      ])
    ),

    card("Practice more", (s.weaknesses || []).map(titleCase).join(", ") || "Looking good"),
    card("Strengths", (s.strengths || []).map(titleCase).join(", ") || "More practice unlocks this"),

    card("🏆 Badges", "See what you have unlocked.", [{ label: "OPEN BADGES", onClick: () => app.showAchievements() }]),
    card("🎁 Rewards", "Spend stars on fun unlocks.", [{ label: "OPEN REWARDS", onClick: () => app.showRewards() }]),
    card("⚙ Settings", "Name, theme and daily goal.", [{ label: "OPEN", onClick: () => app.showSettings() }]),
    card("👪 Parent", "For grown-ups", [{ label: "OPEN PARENT VIEW", onClick: () => app.showParent() }])
  ];

  return { title: "👤 Profile", bottomNavKey: "profile", body };
}
