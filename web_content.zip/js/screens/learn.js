import { el, card, topicTile } from "../ui/widgets.js";
import { drawDiagram } from "../ui/render.js";
import { allTopics, loadTopicNotes, loadTips } from "../engines/contentLoader.js";

function section(title, body) {
  const kids = [el("div", { class: "role-heading wrap" }, title)];
  if (Array.isArray(body)) body.forEach((item) => kids.push(el("div", { class: "wrap" }, "•  " + item)));
  else if (body) kids.push(el("div", { class: "wrap" }, String(body)));
  return el("div", { class: "card" }, kids);
}

// ---------------- Learn (topic list) ----------------
export async function Learn(app) {
  const gm = app.gradeManager();
  const body = [el("div", { class: "role-subtitle wrap" },
    `${gm.phase()} • Deep notes, guides and worked examples, matched to ${gm.label()} only.`)];

  if (gm.grade === 8) {
    const topics = await allTopics();
    const byTerm = { 1: [], 2: [], 3: [], 4: [] };
    topics.forEach((t) => (byTerm[t.term || 1] = byTerm[t.term || 1] || []).push(t));
    [1, 2, 3, 4].forEach((term) => {
      if (!byTerm[term] || !byTerm[term].length) return;
      body.push(el("div", { class: "section-eyebrow" }, `TERM ${term}`));
      byTerm[term].forEach((t) => body.push(topicTile(t.icon || "📘", t.name, "Tap to open the full learning module.",
        () => app.showTopicDetail(t.id), () => app.showPractice("choose", [t.id]))));
    });
  } else if (gm.grade === 11 || gm.grade === 10) {
    const P1_IDS = new Set(["equations_inequalities","exponents_surds","number_patterns","functions_graphs","finance_11","probability_11"]);
    const p1 = gm.topics().filter((t) => (t.paper || (P1_IDS.has(t.id) ? 1 : 2)) === 1);
    const p2 = gm.topics().filter((t) => (t.paper || (P1_IDS.has(t.id) ? 1 : 2)) === 2);
    body.push(el("div", { class: "section-eyebrow" }, "PAPER 1"));
    body.push(el("div", { class: "wrap role-muted", style: "margin-bottom:0.35rem;" },
      "Algebra · patterns · functions · finance · probability"));
    p1.forEach((t) => body.push(topicTile(t.icon || "📘", t.name, "Notes and practice.",
      () => app.showTopicDetail(t.id), () => app.showPractice("choose", [t.id]))));
    body.push(el("div", { class: "section-eyebrow", style: "margin-top:0.75rem;" }, "PAPER 2"));
    body.push(el("div", { class: "wrap role-muted", style: "margin-bottom:0.35rem;" },
      "Statistics · analytical geometry · trigonometry · Euclidean geometry · measurement"));
    p2.forEach((t) => body.push(topicTile(t.icon || "📘", t.name, "Notes and practice.",
      () => app.showTopicDetail(t.id), () => app.showPractice("choose", [t.id]))));
  } else {
    gm.topics().forEach((t) => body.push(topicTile(t.icon || "📘", t.name, "Notes and practice.",
      () => app.showTopicDetail(t.id), () => app.showPractice("choose", [t.id]))));
  }

  return { title: `📚 Learn — ${gm.label()}`, bottomNavKey: "learn", body };
}

// ---------------- Topic Detail: Grade 8 full 19-part notes ----------------
export async function TopicDetail(app, { topicId }) {
  const topics = await allTopics();
  const meta = topics.find((t) => t.id === topicId) || { name: topicId, icon: "📘" };
  const notes = await loadTopicNotes(topicId);

  if (!notes) {
    return { title: `${meta.icon} ${meta.name}`, body: [card("Content not found",
      "This topic's notes file could not be loaded. Check that the content/grade8/topics/ folder is present alongside the app.")] };
  }

  const mastery = app.student.mastery?.[topicId] ?? 0.5;
  const body = [
    card("Your Mastery", `${Math.round(mastery * 100)}% on ${meta.name}`, [
      { label: "PRACTICE THIS TOPIC", onClick: () => app.showPractice("choose", [topicId]) },
      { label: "QUIZ DEFINITIONS", onClick: () => app.showQuiz("math", topicId), secondary: true }
    ]),
    section("1️⃣ What is it?", notes.what_is_it),
    section("2️⃣ Why it matters", notes.why_it_matters),
    section("3️⃣ Key vocabulary", notes.key_vocabulary),
    section("4️⃣ Core concept", notes.core_concept),
    section("5️⃣ Rules", notes.rules),
    section("6️⃣ Formulae", notes.formulae),
    section("7️⃣ Step-by-step method", notes.step_by_step_method)
  ];
  if (notes.caps_alignment) body.push(section("📋 CAPS / ATP alignment", notes.caps_alignment));
  if (notes.worked_example_1) body.push(section("8️⃣ Worked example 1", `Q: ${notes.worked_example_1.question || ""}\n\n${notes.worked_example_1.solution || ""}`));
  if (notes.worked_example_2) body.push(section("9️⃣ Worked example 2", `Q: ${notes.worked_example_2.question || ""}\n\n${notes.worked_example_2.solution || ""}`));
  if (notes.worked_example_3) body.push(section("🔟 Worked example 3", `Q: ${notes.worked_example_3.question || ""}\n\n${notes.worked_example_3.solution || ""}`));
  body.push(
    section("⚡ Fast method", notes.fast_method),
    section("🧠 Why the fast method works", notes.why_fast_method_works),
    section("⚠️ Common mistakes", notes.common_mistakes),
    section("💡 Memory trick", notes.memory_trick),
    section("👁 Visual explanation", notes.visual_explanation),
    section("🧭 Guided example", notes.guided_example)
  );
  // Textbook practice guide (foundation / standard / advanced)
  const tpg = notes.textbook_practice_guide;
  if (tpg && typeof tpg === "object") {
    body.push(el("div", { class: "section-eyebrow" }, "📖 TEXTBOOK PRACTICE GUIDE"));
    if (tpg.foundation && tpg.foundation.length) body.push(section("Foundation", tpg.foundation));
    if (tpg.standard && tpg.standard.length) body.push(section("Standard", tpg.standard));
    if (tpg.advanced && tpg.advanced.length) body.push(section("Advanced", tpg.advanced));
  }
  body.push(
    section("✏️ Practice questions", notes.practice_questions),
    section("🏆 Challenge question", notes.challenge_question),
    section("✅ Quick test", notes.quick_test),
    section("🎓 Mastery check", notes.mastery_check)
  );
  if (notes.atp_notes) body.push(section("📅 ATP notes", notes.atp_notes));
  body.push(el("button", { class: "btn", onClick: () => app.showPractice("choose", [topicId]) }, "✏️ PRACTICE THIS TOPIC NOW"));

  return { title: `${meta.icon} ${meta.name}`, body };
}

// ---------------- Topic Detail Lite: Grade R-7 and Grade 9 ----------------
const TOPIC_TO_TIPS_CATEGORY = {
  add_sub_20: "addition", add_sub_99: "addition", add_sub_999: "addition",
  numbers_20: "addition", numbers_99: "subtraction", numbers_999: "addition",
  whole_numbers_4: "addition", whole_numbers_5: "addition", whole_numbers_6: "addition",
  repeated_add: "multiplication", mult_tables: "multiplication", mult_div_4: "multiplication",
  division_intro: "division",
  fractions_intro: "fractions", common_fractions_4: "fractions",
  common_fractions_5: "fractions", decimal_fractions_5: "fractions", fractions_6: "fractions",
  percentages_6: "percentages", ratio_6: "fractions",
  shapes_r: "geometry", shapes_1: "geometry", shapes_2: "geometry",
  geometry_4: "geometry", geometry_5: "geometry", geometry_6: "geometry",
  data_5: "addition", data_6: "addition"
};

export async function TopicDetailLite(app, { topicId }) {
  const gm = app.gradeManager();
  gm.verifyTopic(topicId);
  const meta = gm.topics().find((t) => t.id === topicId) || { id: topicId, name: topicId.replaceAll("_", " "), icon: "📘" };
  const mastery = app.student.mastery?.[topicId] ?? 0.5;
  const [lo, hi] = gm.numberRange();

  // Try grade-specific notes under content/gradeN/topics/ then shared lite notes
  let notes = null;
  try {
    const { loadTopicNotesForGrade } = await import("../engines/contentLoader.js");
    if (typeof loadTopicNotesForGrade === "function") notes = await loadTopicNotesForGrade(gm.grade, topicId);
  } catch { /* optional */ }
  if (!notes) {
    try { notes = await loadTopicNotes(topicId); } catch { /* ignore */ }
  }

  const body = [
    card(`${gm.label()} • Your Mastery`, `${Math.round(mastery * 100)}% on ${meta.name}`,
      [{ label: "PRACTICE THIS TOPIC", onClick: () => app.showPractice("choose", [topicId]) }]),
  ];

  if (notes) {
    if (notes.about) body.push(card("About this topic", notes.about));
    if (notes.overview && notes.overview !== notes.about) body.push(card("Overview", notes.overview));
    if (notes.illustrations && notes.illustrations.length) {
      body.push(el("div", { class: "section-eyebrow" }, "ILLUSTRATIONS"));
      notes.illustrations.forEach((ill) => {
        const wrap = el("div", { class: "card" });
        wrap.appendChild(el("div", { class: "role-heading wrap" }, ill.title || "Diagram"));
        if (ill.caption) wrap.appendChild(el("div", { class: "role-muted wrap", style: "margin-bottom:0.4rem;" }, ill.caption));
        if (ill.diagram) {
          const holder = el("div", { style: "width:100%;max-width:340px;margin:0.35rem auto;overflow:hidden;" });
          const c = el("canvas", { style: "display:block;width:100%;max-width:100%;height:auto;" });
          holder.appendChild(c);
          wrap.appendChild(holder);
          requestAnimationFrame(() => {
            const w = Math.min(320, holder.clientWidth || 280);
            drawDiagram(c, ill.diagram, w, Math.round(w * 0.72));
          });
        }
        body.push(wrap);
      });
    }
    if (notes.what_is_it) body.push(card("What is it?", notes.what_is_it));
    if (notes.why_it_matters) body.push(card("Why it matters", notes.why_it_matters));
    if (notes.key_facts && notes.key_facts.length) {
      body.push(card("Key facts", notes.key_facts.map((f) => "• " + f).join("\n")));
    }
    if (notes.theorem_riders && notes.theorem_riders.length) {
      body.push(el("div", { class: "section-eyebrow" }, "THEOREM RIDERS"));
      notes.theorem_riders.forEach((r) => {
        body.push(card(
          r.name || "Theorem",
          `Statement: ${r.statement || ""}\n\nHow to use: ${r.how_to_use || ""}\n\nExam tip: ${r.exam_tip || ""}`
        ));
      });
    }
    if (notes.key_vocabulary) body.push(card("Key vocabulary", Array.isArray(notes.key_vocabulary) ? notes.key_vocabulary.map(v => "• " + v).join("\n") : String(notes.key_vocabulary)));
    if (notes.core_concept) body.push(card("Core concept", notes.core_concept));
    if (notes.formulae && notes.formulae.length) body.push(card("Formulae", notes.formulae.map(f => "• " + f).join("\n")));
    if (notes.step_by_step_method && notes.step_by_step_method.length) {
      body.push(card("Method", notes.step_by_step_method.map((s, i) => `${i + 1}. ${s}`).join("\n")));
    }
    if (notes.worked_examples && notes.worked_examples.length) {
      body.push(el("div", { class: "section-eyebrow" }, "WORKED EXAMPLES"));
      notes.worked_examples.forEach((ex, i) => {
        body.push(card(`Example ${i + 1}`, `Q: ${ex.question || ""}\n\n${ex.solution || ""}`));
      });
    }
    if (notes.worked_example_1) body.push(card("Worked example", `Q: ${notes.worked_example_1.question || ""}\n\n${notes.worked_example_1.solution || ""}`));
    const tpg = notes.textbook_practice_guide;
    if (tpg) {
      body.push(el("div", { class: "section-eyebrow" }, "📖 TEXTBOOK PRACTICE GUIDE"));
      if (tpg.foundation) body.push(card("Foundation", tpg.foundation.map(x => "• " + x).join("\n")));
      if (tpg.standard) body.push(card("Standard", tpg.standard.map(x => "• " + x).join("\n")));
      if (tpg.advanced) body.push(card("Advanced", tpg.advanced.map(x => "• " + x).join("\n")));
    }
    if (notes.common_mistakes) body.push(card("Common mistakes", Array.isArray(notes.common_mistakes) ? notes.common_mistakes.map(m => "• " + m).join("\n") : String(notes.common_mistakes)));
    if (notes.caps_alignment) body.push(card("CAPS alignment", notes.caps_alignment));
    if (notes.practice_note) body.push(el("div", { class: "role-muted wrap" }, notes.practice_note));
  }
  const categoryId = TOPIC_TO_TIPS_CATEGORY[topicId];
  if (categoryId) {
    const tipsData = await loadTips();
    const category = (tipsData.categories || []).find((c) => c.id === categoryId);
    if (category) {
      body.push(el("div", { class: "role-heading wrap" }, `${category.icon || "💡"} RELEVANT TIPS & TRICKS`));
      (category.tricks || []).slice(0, 3).forEach((trick) => {
        body.push(card(`⚡ ${trick.title}`, `Example: ${trick.example}\nMethod: ${trick.method}`));
      });
    }
  }

  body.push(el("button", { class: "btn", onClick: () => app.showPractice("choose", [topicId]) }, "✏️ PRACTICE THIS TOPIC NOW"));
  body.push(el("button", { class: "btn-secondary", onClick: () => app.showTipsTricks() }, "💡 OPEN FULL TIPS & TRICKS LIBRARY"));

  return { title: `${meta.icon || "📘"} ${meta.name}`, body };
}
