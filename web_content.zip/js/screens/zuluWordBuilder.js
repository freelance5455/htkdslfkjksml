import { el, card, showAlert, showPrompt } from "../ui/widgets.js";
import { ZULU_WORD_BUILDER_LIBRARY } from "../../content/grade5/isizulu/wordBuilderLibrary.js";

const clean = (x) => String(x ?? "").trim().toLowerCase();
const upper = (x) => clean(x).toUpperCase();

export async function ZuluWordBuilder(app, params = {}) {
  const student = app.student;
  const saved = student.zuluWordBuilder || {};
  let customFamilies = Array.isArray(saved.customFamilies) ? saved.customFamilies : [];
  let spellingList = Array.isArray(saved.spellingList) ? saved.spellingList : [];
  let session = saved.session || null;
  let tab = params.tab || "practice";
  let practiceIndex = 0;
  let built = [];
  let checked = false;

  const groups = () => [...ZULU_WORD_BUILDER_LIBRARY.cards, ...customFamilies];
  const cardSet = () => new Set(groups().flatMap(g => g.cards || []).map(clean));
  const save = () => {
    student.zuluWordBuilder = { ...saved, customFamilies, spellingList, session };
    app.saveStudent();
  };

  // Automatically split a word using the longest available syllable card first.
  const autoMap = (word) => {
    const w = clean(word);
    if (!w) return null;
    const candidates = [...cardSet()].sort((a, b) => b.length - a.length);
    const parts = [];
    let pos = 0;
    while (pos < w.length) {
      const hit = candidates.find(c => w.startsWith(c, pos));
      if (!hit) return null;
      parts.push(hit);
      pos += hit.length;
    }
    return parts;
  };

  const mapWord = (word) => {
    const known = ZULU_WORD_BUILDER_LIBRARY.words.find(x => clean(x.word) === clean(word));
    return known?.parts || autoMap(word);
  };

  const shuffle = (arr) => [...arr].sort(() => Math.random() - 0.5);
  const reset = () => { built = []; checked = false; };

  const panel = el("div", {});

  function cardPool(required) {
    const all = [...cardSet()];
    const out = [...required];
    const used = new Set(out.map(clean));
    for (const c of shuffle(all)) {
      if (out.length >= Math.max(8, required.length + 5)) break;
      if (!used.has(c)) { out.push(c); used.add(c); }
    }
    return shuffle(out);
  }

  function renderBuilder(parts, onCheck) {
    panel.appendChild(el("div", { class: "zulu-tray-label" }, "YOUR WORD"));
    panel.appendChild(el("div", { class: "zulu-build-tray" }, built.length
      ? built.map((p, i) => el("button", {
          class: "zulu-card zulu-card-built",
          onClick: () => { if (!checked) { built.splice(i, 1); render(); } }
        }, upper(p)))
      : [el("div", { class: "zulu-empty-tray" }, "Tap cards to build the word")]
    ));

    panel.appendChild(el("div", { class: "zulu-tray-label" }, "SYLLABLE CARDS"));
    const grid = el("div", { class: "zulu-card-grid" });
    cardPool(parts).forEach(p => grid.appendChild(el("button", {
      class: "zulu-card",
      disabled: checked,
      onClick: () => { built.push(p); render(); }
    }, upper(p))));
    panel.appendChild(grid);

    panel.appendChild(el("div", { class: "btn-row" }, [
      el("button", { class: "btn-secondary", disabled: !built.length || checked, onClick: () => { built.pop(); render(); } }, "UNDO"),
      el("button", { class: "btn-secondary", disabled: !built.length || checked, onClick: () => { built = []; render(); } }, "CLEAR"),
      el("button", { class: "btn", disabled: !built.length || checked, onClick: onCheck }, "CHECK")
    ]));
  }

  function practice() {
    const target = ZULU_WORD_BUILDER_LIBRARY.words[practiceIndex % ZULU_WORD_BUILDER_LIBRARY.words.length];
    panel.appendChild(card("Practice", `Build: ${upper(target.word)}`, [{
      label: "",
      onClick: () => {}
    }]));
    // Remove the intentionally empty action generated above. Card requires an array, not a string.
    panel.querySelector(".card-actions")?.remove();
    renderBuilder(target.parts, () => {
      checked = true;
      const ok = built.map(clean).join("|") === target.parts.map(clean).join("|");
      panel.appendChild(card(ok ? "✓ Correct" : "Not quite", ok ? "" : `Correct: ${target.parts.map(upper).join(" + ")}`, [{
        label: ok ? "NEXT WORD" : "TRY AGAIN",
        onClick: () => { if (ok) practiceIndex++; reset(); render(); }
      }]));
    });
  }

  function library() {
    panel.appendChild(card("All syllable cards", "Every available family is stored locally in Learnly. No sound library or internet is required.", []));
    groups().forEach(g => panel.appendChild(el("div", { class: "zulu-family-block" }, [
      el("div", { class: "zulu-family-name" }, g.family),
      el("div", { class: "zulu-card-grid zulu-library-grid" }, (g.cards || []).map(c => el("div", { class: "zulu-card zulu-card-static" }, upper(c))))
    ])));
    panel.appendChild(el("button", { class: "btn", onClick: addFamily }, "+ ADD FAMILY"));
  }

  async function addFamily() {
    const raw = await showPrompt("Add syllable family", "Example: na ne ni no nu");
    if (raw === null) return;
    const cards = raw.split(/\s+/).map(clean).filter(Boolean);
    if (!cards.length) return;
    customFamilies.push({ family: cards.map(upper).join(" · "), cards: cards.map(upper) });
    save();
    render();
  }

  async function parentSetup() {
    const raw = await showPrompt("Preset spelling list", "Enter 10–15 words separated by spaces or commas.");
    if (raw === null) return;
    const words = [...new Set(raw.split(/[\s,]+/).map(clean).filter(Boolean))];
    if (words.length < 10 || words.length > 15) {
      await showAlert("Spelling list", "Enter 10–15 different words.");
      return;
    }
    const mapped = words.map(word => ({ word, parts: mapWord(word) }));
    const missing = mapped.filter(x => !x.parts);
    if (missing.length) {
      await showAlert("Could not auto-map", `These words need syllable cards that are not in the library:\n\n${missing.map(x => x.word).join(", ")}\n\nAdd the missing family under ALL CARDS, then save the list again.`);
      return;
    }
    spellingList = mapped;
    session = null;
    save();
    await showAlert("List ready", `${words.length} words were automatically mapped into syllable cards.`);
    render();
  }

  function startSpelling() {
    session = { active: true, index: 0, order: shuffle(spellingList), results: [] };
    save();
    tab = "spelling";
    reset();
    render();
  }

  function spelling() {
    if (!session?.active) {
      panel.appendChild(card("No active spelling test", "The parent or tutor must preset a 10–15 word list first.", [{ label: "PARENT SETUP", onClick: () => { tab = "parent"; render(); } }]));
      return;
    }
    const item = session.order[session.index];
    panel.appendChild(card("SPELLING MODE", `Word ${session.index + 1} of ${session.order.length}. Parent/tutor reads the handwritten copy.`, []));
    panel.appendChild(el("div", { class: "zulu-child-safe" }, "TARGET WORD HIDDEN"));
    renderBuilder(item.parts, () => {
      checked = true;
      const correct = built.map(clean).join("|") === item.parts.map(clean).join("|");
      session.results.push({ word: item.word, parts: item.parts, correct });
      save();
      panel.appendChild(card(correct ? "✓ Correct" : "Answer recorded", correct ? "" : `Correct construction: ${item.parts.map(upper).join(" + ")}`, [{
        label: session.index + 1 >= session.order.length ? "FINISH" : "NEXT WORD",
        onClick: () => {
          session.index++;
          reset();
          if (session.index >= session.order.length) {
            session.active = false;
            session.finished = true;
            save();
            tab = "results";
          }
          render();
        }
      }]));
    });
  }

  function results() {
    const results = session?.results || [];
    const score = results.filter(x => x.correct).length;
    panel.appendChild(card("Spelling complete", `${score} / ${results.length} correct. The full list is now visible for parent/tutor review.`, []));
    results.forEach(x => panel.appendChild(card(upper(x.word), x.correct ? "✓ Correct" : `✗ Incorrect · ${x.parts.map(upper).join(" + ")}`, [])));
    panel.appendChild(el("button", { class: "btn", onClick: () => { session = null; save(); tab = "parent"; render(); } }, "NEW SPELLING LIST"));
  }

  function render() {
    panel.innerHTML = "";
    if (tab === "practice") practice();
    else if (tab === "library") library();
    else if (tab === "parent") parentSetup();
    else if (tab === "spelling") spelling();
    else results();
  }

  render();
  return {
    title: "IsiZulu Word Builder",
    showBack: true,
    bottomNavKey: "learn",
    body: [
      el("div", { class: "zulu-hero" }, [
        el("div", { class: "zulu-lion-mark" }, "🦁"),
        el("div", {}, [
          el("div", { class: "zulu-hero-title" }, "IsiZulu Word Builder"),
          el("div", { class: "zulu-hero-sub" }, "Grade 5 · build · spelling · cards")
        ])
      ]),
      el("div", { class: "btn-row" }, [
        el("button", { class: `chip${tab === "practice" ? " active" : ""}`, onClick: () => { tab = "practice"; reset(); render(); } }, "PRACTICE"),
        el("button", { class: `chip${tab === "spelling" ? " active" : ""}`, onClick: () => { tab = "spelling"; reset(); render(); } }, "SPELLING"),
        el("button", { class: `chip${tab === "library" ? " active" : ""}`, onClick: () => { tab = "library"; render(); } }, "ALL CARDS"),
        el("button", { class: `chip${tab === "parent" ? " active" : ""}`, onClick: () => { tab = "parent"; render(); } }, "PARENT")
      ]),
      panel
    ]
  };
}
