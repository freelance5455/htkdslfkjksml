import { el, card, mathKeyboard } from "../ui/widgets.js";
import { answersMatch } from "../engines/answerCheck.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { Stopwatch } from "../engines/timerEngine.js";

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }

function makeItem(op, level) {
  // level: 1 soft, 2 mid, 3 hard
  if (op === "mix") op = ["+", "-", "×", "÷"][ri(0, 3)];
  let a, b, ans, text;
  if (op === "+") {
    if (level === 1) { a = ri(10, 40); b = ri(10, 40); }
    else if (level === 2) { a = ri(40, 200); b = ri(20, 99); }
    else { a = ri(100, 500); b = ri(50, 400); }
    ans = a + b; text = `${a} + ${b}`;
  } else if (op === "-") {
    if (level === 1) { a = ri(15, 50); b = ri(1, a); }
    else if (level === 2) { a = ri(50, 200); b = ri(10, Math.min(90, a)); }
    else { a = ri(200, 800); b = ri(50, Math.min(400, a)); }
    ans = a - b; text = `${a} − ${b}`;
  } else if (op === "×") {
    if (level === 1) { a = ri(2, 10); b = ri(2, 10); }
    else if (level === 2) { a = ri(3, 12); b = ri(2, 12); }
    else { a = ri(11, 25); b = ri(3, 9); }
    ans = a * b; text = `${a} × ${b}`;
  } else {
    if (level === 1) { b = ri(2, 10); ans = ri(2, 10); }
    else if (level === 2) { b = ri(2, 12); ans = ri(2, 12); }
    else { b = ri(3, 12); ans = ri(8, 20); }
    a = b * ans; text = `${a} ÷ ${b}`;
  }
  return { text, answer: String(ans), op };
}

const COMMENT_OK = ["Nice!", "Yes!", "Got it!", "On fire!", "Smooth!"];
const COMMENT_NO = ["Not quite.", "Try the next one.", "Almost — keep going."];

export async function ChallengesHub(app) {
  return {
    title: "Challenges",
    bottomNavKey: "practice",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Pick an operation. Choose how many. Optional timer."),
      card("➕ Addition", "5 · 10 · 15 · 20 questions", [{ label: "GO", onClick: () => app.navigate("challengeSetup", { op: "+" }) }]),
      card("➖ Subtraction", "5 · 10 · 15 · 20 questions", [{ label: "GO", onClick: () => app.navigate("challengeSetup", { op: "-" }) }]),
      card("✖️ Multiplication", "5 · 10 · 15 · 20 questions", [{ label: "GO", onClick: () => app.navigate("challengeSetup", { op: "×" }) }]),
      card("➗ Division", "5 · 10 · 15 · 20 questions", [{ label: "GO", onClick: () => app.navigate("challengeSetup", { op: "÷" }) }]),
      card("🎲 Mixed", "All four operations", [{ label: "GO", onClick: () => app.navigate("challengeSetup", { op: "mix" }) }])
    ]
  };
}

export async function ChallengeSetup(app, { op = "+" } = {}) {
  let count = 10, level = 1, timerMin = 0;
  const countSel = el("select", {}, [5, 10, 15, 20].map((n) => el("option", { value: n }, String(n))));
  countSel.value = "10";
  const levelSel = el("select", {}, [
    el("option", { value: "1" }, "Soft"),
    el("option", { value: "2" }, "On track"),
    el("option", { value: "3" }, "Challenge")
  ]);
  const timerSel = el("select", {}, [
    el("option", { value: "0" }, "No timer"),
    el("option", { value: "3" }, "3 minutes"),
    el("option", { value: "5" }, "5 minutes")
  ]);
  const labels = { "+": "Addition", "-": "Subtraction", "×": "Multiplication", "÷": "Division", mix: "Mixed" };

  return {
    title: labels[op] || "Challenge",
    body: [
      el("label", { class: "field-label" }, "How many"), countSel,
      el("label", { class: "field-label" }, "Level"), levelSel,
      el("label", { class: "field-label" }, "Timer"), timerSel,
      el("button", { class: "btn", onClick: () => {
        app.navigate("challengeRun", {
          op,
          count: parseInt(countSel.value, 10),
          level: parseInt(levelSel.value, 10),
          timerMin: parseInt(timerSel.value, 10)
        });
      } }, "Start")
    ]
  };
}

export async function ChallengeRun(app, { op = "+", count = 10, level = 1, timerMin = 0 } = {}) {
  let i = 0, correct = 0, current = makeItem(op, level);
  const sw = new Stopwatch();
  const qEl = el("div", { style: "font-size:1.8rem;font-weight:800;text-align:center;padding:0.8rem 0;" });
  const inp = el("input", { type: "text", inputmode: "numeric", placeholder: "Answer", style: "font-size:1.2rem;text-align:center;" });
  const res = el("div", { class: "wrap", style: "text-align:center;min-height:1.4rem;" });
  const prog = el("div", { class: "role-heading" });
  const timeEl = el("div", { class: "role-muted" });
  let timedOut = false;
  let timerId = null;

  function show() {
    current = makeItem(op, level);
    qEl.textContent = current.text;
    inp.value = "";
    res.textContent = "";
    prog.textContent = `${i} / ${count} · ✅ ${correct}`;
    try { inp.focus(); } catch {}
  }

  function finish() {
    if (timerId) clearInterval(timerId);
    sw.stop();
    const econ = new EconomyEngine(app.student);
    if (correct === count) econ.earn("challenge_perfect", "Perfect challenge");
    else econ.earn("challenge_complete", "Challenge done");
    app.student.xp = (app.student.xp || 0) + correct * 2;
    app.student.today_done = (app.student.today_done || 0) + count;
    new GamificationEngine(app.student).checkNewUnlocks();
    app.saveStudent();
    const pct = Math.round((correct / count) * 100);
    let line = pct === 100 ? "Perfect run!" : pct >= 70 ? "Solid work!" : "Good try — practice makes it easier.";
    qEl.textContent = "Done!";
    res.textContent = `${correct}/${count} · ${pct}%\n${line}\nTime ${sw.display()}`;
    inp.style.display = "none";
  }

  function check() {
    if (timedOut || i >= count) return;
    const ok = answersMatch(inp.value.trim(), current.answer);
    i += 1;
    if (ok) {
      correct += 1;
      res.textContent = COMMENT_OK[ri(0, COMMENT_OK.length - 1)];
      const econ = new EconomyEngine(app.student);
      econ.earnCorrect(level, "Challenge correct");
    } else {
      res.textContent = `${COMMENT_NO[ri(0, COMMENT_NO.length - 1)]} Answer: ${current.answer}`;
    }
    (app.student.history = app.student.history || []).push({
      question_id: `ch_${Date.now()}`, topic: "challenge_" + op, correct: ok,
      difficulty: level, timestamp: new Date().toISOString()
    });
    app.saveStudent();
    if (i >= count) setTimeout(finish, 600);
    else setTimeout(show, ok ? 400 : 900);
  }

  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") check(); });
  show();
  sw.start();
  if (timerMin > 0) {
    const end = Date.now() + timerMin * 60 * 1000;
    timerId = setInterval(() => {
      const left = Math.max(0, end - Date.now());
      const s = Math.ceil(left / 1000);
      timeEl.textContent = `⏱ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
      if (left <= 0) { timedOut = true; finish(); }
    }, 250);
  }

  return {
    title: "Challenge",
    body: [
      prog, timeEl, qEl, inp,
      ((app.student.settings || {}).maths_keyboard ? mathKeyboard(inp) : null),
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn", onClick: check }, "Check"),
        el("button", { class: "btn-secondary", onClick: () => { if (i < count) { i += 1; if (i >= count) finish(); else show(); } } }, "Skip")
      ]),
      res
    ],
    onUnmount: () => { if (timerId) clearInterval(timerId); sw.stop(); }
  };
}
