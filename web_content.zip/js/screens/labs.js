import { el, card } from "../ui/widgets.js";
import { GeometryLabCanvas, MODES } from "../ui/geometryLabCanvas.js";
import { DataEngine } from "../engines/dataEngine.js";
import { ProbabilityEngine } from "../engines/probabilityEngine.js";
import { drawChart } from "../ui/render.js";
import { Stopwatch } from "../engines/timerEngine.js";
import { answersMatch } from "../engines/answerCheck.js";
import { drawSolid3D } from "../ui/imageBuilder.js";

// ==================== HUB ====================
export async function Labs(app) {
  const grade = app.student?.grade ?? 5;
  const body = [];

  if (grade >= 10) {
    // FET workshops — fully independent sessions (do not open Practice screen)
    const openWs = (topicId, title) => () =>
      app.navigate("workshopSession", { topicId, title, count: 8, difficulty: 2 });
    body.push(
      card("📐 Theorem Workshop", "Formulae mastery: drag, match or type (quadratic, distance, sequences, trig, finance).",
        [{ label: "OPEN", onClick: () => app.navigate("theoremLab") }]),
      card("✏️ Equation Builder", "Live multi-skill equations & inequalities drills inside this workshop.",
        [{ label: "START", onClick: openWs("equations_inequalities", "Equation Builder") }]),
      card("📈 Functions Lab", "Evaluate functions and turning points — workshop session.",
        [{ label: "START", onClick: openWs("functions_graphs", "Functions Lab") }]),
      card("📏 Analytical Geometry", "Distance, midpoint and gradient drills in-lab.",
        [{ label: "START", onClick: openWs("analytical_geometry", "Analytical Geometry Lab") }]),
      card("📐 Trigonometry Lab", "Special angles and ratios — workshop session.",
        [{ label: "START", onClick: openWs("trigonometry", "Trigonometry Lab") }]),
      card("🔢 Patterns Lab", "Arithmetic and geometric sequences.",
        [{ label: "START", onClick: openWs("number_patterns", "Number Patterns Lab") }]),
      card("√ Exponents & Surds", "Laws of exponents and surd simplification.",
        [{ label: "START", onClick: openWs("exponents_surds", "Exponents & Surds Lab") }]),
      card("💰 Finance Workshop", "Compound growth and decay calculations.",
        [{ label: "START", onClick: openWs("finance_11", "Finance Workshop") }]),
      card("🎲 Probability Lab", "Spinner and event probability drills.",
        [{ label: "START", onClick: openWs("probability_11", "Probability Lab") }]),
      card("📊 Statistics Lab", "Mean and basic statistics drills.",
        [{ label: "START", onClick: openWs("statistics_11", "Statistics Lab") }]),
      card("📝 Past Papers", "March / June / September / November style papers.",
        [{ label: "OPEN", onClick: () => app.showPapers() }])
    );
  } else {
    // Foundation / Intermediate workshops
    body.push(
      card("🔺 Shape Workshop", "Triangles, polygons, circle, angles, coordinates.", [{ label: "PLAY", onClick: () => app.showGeometryLab() }]),
      card("📦 3D Shapes", "Cube, prism, cylinder, cone, pyramid, sphere — perspective view.", [{ label: "PLAY", onClick: () => app.showSolidsLab() }]),
      card("📊 Survey Station", "Tables, mean, median, mode, range and charts.", [{ label: "PLAY", onClick: () => app.showDataLab() }]),
      card("⚔️ Challenges", "+ − × ÷ with timer and levels.", [{ label: "GO", onClick: () => app.showChallenges() }]),
      card("⚡ Number Sprint", "Quick fire + − × ÷.", [{ label: "SPRINT", onClick: () => app.showMental() }]),
      card("🎲 Chance Lab", "Dice, coins and spinners.", [{ label: "PLAY", onClick: () => app.showProbabilityLab() }])
    );
  }

  return {
    title: "Workshops",
    bottomNavKey: "learn",
    body
  };
}

// ==================== GEOMETRY DRAWER ====================
export async function GeometryLab(app) {
  const canvasEl = el("canvas");
  const wrap = el("div", { style: "width:100%;display:flex;justify-content:center;min-height:340px;" }, canvasEl);
  const lab = new GeometryLabCanvas(canvasEl);

  const selector = el("select", {}, MODES.map((m) => el("option", { value: m }, m)));
  selector.value = "Triangle";
  selector.addEventListener("change", () => { lab.mode = selector.value; lab.clear(); });

  const measureBox = el("input", { type: "checkbox" }); measureBox.checked = true;
  measureBox.addEventListener("change", () => { lab.showMeasurements = measureBox.checked; lab.redraw(); });

  // After the framework inserts the body into the DOM, size and draw the canvas.
  requestAnimationFrame(() => {
    requestAnimationFrame(() => lab.mount());
  });

  return {
    title: "Shape Workshop",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Tap points on the grid to build a shape. No manual images needed — every diagram is drawn live."),
      selector, wrap,
      el("label", { class: "checkline" }, [measureBox, "📏 Show measurements"]),
      el("button", { class: "btn-secondary", onClick: () => lab.clear() }, "🗑 CLEAR"),
      el("div", { class: "role-muted wrap" }, "TIP: Triangle needs 3 taps, Rectangle & Circle need 2 taps (opposite corners / centre + edge), Angle needs 3 taps (vertex first), Coordinate Plane plots every tap.")
    ],
    onUnmount: () => lab.unmount()
  };
}

// ==================== DATA HANDLING LAB ====================
export async function DataLab(app) {
  const de = new DataEngine();
  let rowCount = 10;
  const rowsInput = el("input", { type: "number", min: "3", max: "30", value: "10" });
  const rowsWrap = el("div", { class: "grid-2" });
  const statsLabel = el("div", { class: "wrap" });
  const outlierLabel = el("div", { class: "wrap" });
  const freqTable = el("div", {});
  const chartTypeSelect = el("select", {}, ["bar", "pie", "line", "box", "histogram"].map((t) => el("option", { value: t }, t)));
  const chartCanvas = el("canvas", { style: "display:block;margin:0 auto;" });

  function buildRows(n, preserve = []) {
    rowsWrap.innerHTML = "";
    for (let i = 0; i < n; i++) {
      const inp = el("input", { type: "number", placeholder: `#${i + 1}` });
      if (preserve[i] !== undefined) inp.value = preserve[i];
      rowsWrap.appendChild(inp);
    }
  }
  buildRows(rowCount);
  rowsInput.addEventListener("change", () => {
    const n = Math.max(3, Math.min(30, parseInt(rowsInput.value, 10) || 10));
    const preserve = [...rowsWrap.children].map((i) => i.value);
    rowCount = n;
    buildRows(n, preserve);
  });

  function getValues() { return [...rowsWrap.children].map((i) => parseFloat(i.value)).filter((v) => !Number.isNaN(v)); }

  function calculate() {
    const values = getValues();
    if (!values.length) {
      statsLabel.textContent = "Enter numbers in the table (or tap RANDOM DATA).";
      outlierLabel.textContent = "";
      freqTable.innerHTML = "";
      return;
    }
    const s = de.summary(values);
    const g = (n) => (Number.isInteger(n) ? n : Math.round(n * 100) / 100);
    statsLabel.textContent =
      `Count: ${s.count}   Sum: ${g(s.sum)}\nMean: ${g(s.mean)}   Median: ${g(s.median)}\n` +
      `Mode: ${s.mode.map(g).join(", ")}\nRange: ${g(s.range)}   Min: ${g(s.minimum)}   Max: ${g(s.maximum)}\n` +
      `Q1: ${g(s.q1)}   Q3: ${g(s.q3)}   IQR: ${g(s.iqr)}\n` +
      `Five-number summary: (${s.five_number_summary.map(g).join(", ")})`;
    outlierLabel.textContent = s.outliers.length ? `⚠️ Possible outliers (beyond 1.5×IQR): ${s.outliers.join(", ")}` : "No outliers detected (within 1.5×IQR of the quartiles).";

    const grouped = de.groupedFrequency(values, 5);
    freqTable.innerHTML = "";
    const t = el("table", { class: "datatable" }, [
      el("tr", {}, [el("th", {}, "Class Interval"), el("th", {}, "Frequency"), el("th", {}, "Cumulative Freq.")]),
      ...grouped.map((row) => el("tr", {}, [el("td", {}, row.class), el("td", {}, String(row.frequency)), el("td", {}, String(row.cumulative_frequency))]))
    ]);
    freqTable.appendChild(t);

    const labels = values.map((v) => (Number.isInteger(v) ? String(v) : String(v)));
    drawChart(chartCanvas, values, labels, chartTypeSelect.value, 320, 260);
  }
  chartTypeSelect.addEventListener("change", calculate);

  function randomFill() {
    const vals = de.randomDataset(rowCount, 1, 60);
    [...rowsWrap.children].forEach((inp, i) => (inp.value = vals[i]));
    calculate();
  }

  return {
    title: "📊 Data Handling Lab",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Enter values, calculate real statistics (mean/median/mode/range/quartiles/outliers), build a grouped frequency table, and generate graphs."),
      el("div", { class: "btn-row" }, [
        el("div", { style: "flex:1;" }, [el("label", { class: "field-label" }, "Rows"), rowsInput]),
        el("div", { style: "flex:1;display:flex;align-items:flex-end;" }, [el("button", { class: "btn-secondary", onClick: randomFill }, "🎲 RANDOM DATA")])
      ]),
      rowsWrap,
      el("button", { class: "btn", onClick: calculate }, "🧮 CALCULATE STATISTICS"),
      statsLabel, outlierLabel,
      el("div", { class: "section-eyebrow" }, "GROUPED FREQUENCY TABLE (class intervals)"),
      freqTable,
      el("label", { class: "field-label" }, "Graph type"), chartTypeSelect,
      chartCanvas
    ]
  };
}

// ==================== PROBABILITY LAB ====================
export async function ProbabilityLab(app) {
  const pe = new ProbabilityEngine();
  const simSelect = el("select", {}, ["Dice (1 die)", "Coin toss", "Spinner (8 sectors)", "Cards"].map((s) => el("option", { value: s }, s)));
  const trialsInput = el("input", { type: "number", min: "1", max: "500", value: "20" });
  const resultLabel = el("div", { class: "wrap" });
  const compareLabel = el("div", { class: "role-heading wrap" });
  const chartCanvas = el("canvas", { style: "display:block;margin:0 auto;" });

  function run() {
    const n = Math.max(1, Math.min(500, parseInt(trialsInput.value, 10) || 20));
    const sim = simSelect.value;
    let outcomes, labels, values, theoretical, favLabel, experimental;

    if (sim.startsWith("Dice")) {
      outcomes = pe.rollDie(6, n);
      const freq = {}; for (let i = 1; i <= 6; i++) freq[i] = outcomes.filter((x) => x === i).length;
      labels = ["1", "2", "3", "4", "5", "6"]; values = [1, 2, 3, 4, 5, 6].map((i) => freq[i]);
      theoretical = 1 / 6; favLabel = "rolling a 6"; experimental = freq[6] / n;
    } else if (sim.startsWith("Coin")) {
      outcomes = pe.flipCoin(n);
      const heads = outcomes.filter((x) => x === "Heads").length;
      labels = ["Heads", "Tails"]; values = [heads, n - heads];
      theoretical = 0.5; favLabel = "Heads"; experimental = heads / n;
    } else if (sim.startsWith("Spinner")) {
      outcomes = pe.spinSpinner(8, n);
      const freq = {}; for (let i = 1; i <= 8; i++) freq[i] = outcomes.filter((x) => x === i).length;
      labels = Array.from({ length: 8 }, (_, i) => String(i + 1)); values = labels.map((l) => freq[+l]);
      theoretical = 1 / 8; favLabel = "landing on 8"; experimental = freq[8] / n;
    } else {
      outcomes = []; let reds = 0;
      for (let i = 0; i < n; i++) { const c = pe.drawCard(1)[0]; outcomes.push(c); if (c.includes("♥") || c.includes("♦")) reds++; }
      labels = ["Red", "Black"]; values = [reds, n - reds];
      theoretical = 0.5; favLabel = "a red card"; experimental = reds / n;
    }

    resultLabel.textContent = `Outcomes (${n} trials): ${outcomes.slice(0, 30).join(", ")}${n > 30 ? " ..." : ""}`;
    compareLabel.textContent =
      `THEORETICAL P(${favLabel}) = ${theoretical.toFixed(3)}\nEXPERIMENTAL P(${favLabel}) = ${experimental.toFixed(3)}  (${n} trials)\nDifference: ${Math.abs(theoretical - experimental).toFixed(3)}`;
    drawChart(chartCanvas, values, labels, "bar", 320, 260);
  }

  return {
    title: "🎲 Probability Lab",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Run simulations and watch experimental probability approach theoretical probability."),
      el("label", { class: "field-label" }, "Simulation"), simSelect,
      el("label", { class: "field-label" }, "Trials"), trialsInput,
      el("button", { class: "btn", onClick: run }, "▶ RUN SIMULATION"),
      resultLabel, compareLabel, chartCanvas
    ]
  };
}


// ==================== NUMBER SPRINT (+ − × ÷ only, Grade 5) ====================
function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }

const SPRINT_OPS = {
  add: {
    label: "Addition",
    levels: {
      easy: () => { const a = ri(10, 40), b = ri(10, 40); return [a + b, `${a} + ${b}`]; },
      mid: () => { const a = ri(40, 200), b = ri(20, 90); return [a + b, `${a} + ${b}`]; },
      hard: () => { const a = ri(100, 500), b = ri(100, 400); return [a + b, `${a} + ${b}`]; }
    }
  },
  sub: {
    label: "Subtraction",
    levels: {
      easy: () => { const a = ri(15, 50), b = ri(1, a); return [a - b, `${a} − ${b}`]; },
      mid: () => { const a = ri(50, 200), b = ri(10, Math.min(90, a)); return [a - b, `${a} − ${b}`]; },
      hard: () => { const a = ri(200, 800), b = ri(50, Math.min(400, a)); return [a - b, `${a} − ${b}`]; }
    }
  },
  mul: {
    label: "Multiplication",
    levels: {
      easy: () => { const a = ri(2, 10), b = ri(2, 10); return [a * b, `${a} × ${b}`]; },
      mid: () => { const a = ri(3, 12), b = ri(2, 12); return [a * b, `${a} × ${b}`]; },
      hard: () => { const a = ri(11, 25), b = ri(3, 9); return [a * b, `${a} × ${b}`]; }
    }
  },
  div: {
    label: "Division",
    levels: {
      easy: () => { const b = ri(2, 10), q = ri(2, 10); return [q, `${b * q} ÷ ${b}`]; },
      mid: () => { const b = ri(2, 12), q = ri(2, 12); return [q, `${b * q} ÷ ${b}`]; },
      hard: () => { const b = ri(3, 12), q = ri(8, 20); return [q, `${b * q} ÷ ${b}`]; }
    }
  }
};

function sprintTip(op) {
  return ({
    add: "Add tens first, then ones — or count on from the bigger number.",
    sub: "Count up from the smaller number, or subtract tens then ones.",
    mul: "Use a times-table fact you know, or break the number apart.",
    div: "Think of the matching multiplication fact."
  })[op] || "Take your time and check your answer.";
}

export async function Mental(app) {
  let streak = 0, best = app.student.mental_best_streak || 0, current = null, answered = 0, correctCount = 0;
  const sw = new Stopwatch();
  let opKey = "mul";
  let level = "easy";

  const streakLabel = el("div", { class: "role-heading" });
  const metaLabel = el("div", { class: "role-muted wrap" });
  const questionEl = el("div", { style: "font-size:1.8rem;font-weight:800;text-align:center;padding:0.6rem 0;" });
  const answerInput = el("input", { type: "text", inputmode: "numeric", placeholder: "Your answer", style: "font-size:1.2rem;text-align:center;" });
  const resultEl = el("div", { class: "wrap" });
  const timeLabel = el("div", { class: "role-muted" });

  const opSelect = el("select", {}, Object.entries(SPRINT_OPS).map(([k, v]) => el("option", { value: k }, v.label)));
  opSelect.value = opKey;
  const levelSelect = el("select", {}, [
    el("option", { value: "easy" }, "Getting started"),
    el("option", { value: "mid" }, "On track"),
    el("option", { value: "hard" }, "Challenge")
  ]);
  levelSelect.value = level;

  function updateStreakLabel() {
    streakLabel.textContent = `🔥 Streak ${streak} · Best ${best} · ✅ ${correctCount}/${answered}`;
  }
  function nextQ() {
    opKey = opSelect.value;
    level = levelSelect.value;
    const gen = SPRINT_OPS[opKey].levels[level];
    const [ans, text] = gen();
    current = { expected: String(ans), text, tip: sprintTip(opKey) };
    questionEl.textContent = text;
    metaLabel.textContent = `${SPRINT_OPS[opKey].label} · ${levelSelect.options[levelSelect.selectedIndex].text}`;
    answerInput.value = "";
    resultEl.textContent = "";
    try { answerInput.focus(); } catch { /* ignore */ }
    updateStreakLabel();
  }
  function tick() { timeLabel.textContent = `Time ${sw.display()}`; }
  const timerId = setInterval(tick, 500);

  function grantSprintBonus() {
    app.student.credits = (app.student.credits || 0) + 5;
    app.student.transactions = app.student.transactions || [];
    app.student.transactions.push({
      amount: 5, reason: "Number Sprint streak bonus",
      timestamp: new Date().toISOString(), balance_after: app.student.credits
    });
  }

  function check() {
    if (!current) return;
    const ok = answersMatch(answerInput.value.trim(), current.expected);
    answered += 1;
    if (ok) {
      streak += 1; correctCount += 1;
      best = Math.max(best, streak);
      app.student.mental_best_streak = best;
      app.student.xp = (app.student.xp || 0) + 3;
      if (streak > 0 && streak % 5 === 0) grantSprintBonus();
      resultEl.textContent = `✓ Yes! ${current.tip}`;
    } else {
      streak = 0;
      resultEl.textContent = `Not quite. Answer: ${current.expected}\n${current.tip}`;
    }
    app.saveStudent();
    updateStreakLabel();
    setTimeout(nextQ, ok ? 550 : 1100);
  }

  answerInput.addEventListener("keydown", (e) => { if (e.key === "Enter") check(); });
  opSelect.addEventListener("change", () => { streak = 0; nextQ(); });
  levelSelect.addEventListener("change", () => { streak = 0; nextQ(); });

  nextQ();
  sw.start();

  return {
    title: "⚡ Number Sprint",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Only + − × ÷ — build speed and confidence."),
      el("label", { class: "field-label" }, "Focus"), opSelect,
      el("label", { class: "field-label" }, "Level"), levelSelect,
      streakLabel, metaLabel, questionEl, answerInput,
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn", onClick: check }, "CHECK"),
        el("button", { class: "btn-secondary", onClick: () => nextQ() }, "SKIP")
      ]),
      resultEl, timeLabel
    ],
    onUnmount: () => { clearInterval(timerId); sw.stop(); }
  };
}


export async function SolidsLab(app) {
  const kinds = ["cube", "rectangular prism", "cylinder", "cone", "pyramid", "sphere", "triangular prism"];
  let kind = "cube";
  const canvas = el("canvas", { style: "display:block;margin:0.5rem auto;border-radius:12px;background:#f8fafc;" });
  const sel = el("select", {}, kinds.map((k) => el("option", { value: k }, k)));
  function redraw() {
    requestAnimationFrame(() => { try { drawSolid3D(canvas, kind, 300, 240); } catch (e) { console.warn(e); } });
  }
  sel.addEventListener("change", () => { kind = sel.value; redraw(); });
  redraw();
  return {
    title: "3D Shapes",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Grade 5 solids — drawn with perspective (not flat only)."),
      sel, canvas,
      el("div", { class: "role-muted wrap" }, "Count faces, edges and vertices. A cube has 6 faces, 12 edges, 8 corners.")
    ]
  };
}
