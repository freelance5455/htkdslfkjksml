// Main box = 0–11 month schedule (birth doses through Measles1) — Measles2 is a
// 12–23 month booster and does not belong here, so it's left out entirely.
const orderMain = ['BCG','HepB','OPV0','Penta1','Penta2','Penta3','Measles1'];
const order1223 = ['BCG','OPV0','Penta1','Penta2','Penta3','Measles1','Measles2'];

// One result card (same look as the child result cards): label + how many + tap to open the list.
function statCardHtml(tag, kind, count, label, extraClass){
  return `
    <div class="stat-card clickable ${extraClass || ''}" data-tag="${tag}" data-kind="${kind}">
      <div class="stat-info">
        <div class="stat-label">${label}</div>
        <div class="stat-hint">Tap to view list ›</div>
      </div>
      <div class="stat-n">${count}</div>
    </div>`;
}

function dashboardHTML(){
  return `
    <div class="card">
      <h2 style="margin-top:0;text-align:center;">By Age</h2>
      <div class="stat-list">
        <div class="stat-card age"><div class="stat-info"><div class="stat-label">0–11 Months</div></div><div class="stat-n" data-slot="ageB0">0</div><button type="button" class="age-pdf-btn" data-age="b0" title="Share / Download 0–11 Months">📤</button></div>
        <div class="stat-card age"><div class="stat-info"><div class="stat-label">12–23 Months</div></div><div class="stat-n" data-slot="ageB1">0</div><button type="button" class="age-pdf-btn" data-age="b1" title="Share / Download 12–23 Months">📤</button></div>
        <div class="stat-card age"><div class="stat-info"><div class="stat-label">24+ Months</div></div><div class="stat-n" data-slot="ageB2">0</div><button type="button" class="age-pdf-btn" data-age="b2" title="Share / Download 24+ Months">📤</button></div>
        <div class="stat-card age"><div class="stat-info"><div class="stat-label">All TT</div></div><div class="stat-n" data-slot="ageTt">0</div><button type="button" class="age-pdf-btn" data-age="tt" title="Share / Download All TT">📤</button></div>
      </div>
      <button type="button" class="go" data-slot="exportAllBtn" style="margin-top:12px;"></button>
    </div>
    <div class="card">
      <h2 style="margin-top:0;text-align:center;">EPI Schedule Counts</h2>
      <div class="stat-list" data-slot="epi"></div>
    </div>
    <div class="card">
      <h2 style="margin-top:0;text-align:center;">EPI Details for Children Aged 12–23 Months</h2>
      <div class="stat-list" data-slot="epi1223"></div>
    </div>
    <div class="card">
      <h2 style="margin-top:0;text-align:center;">EPI Details for Children Aged 24+ Months</h2>
      <div class="stat-list" data-slot="age24"></div>
    </div>
    <div class="card">
      <h2 style="margin-top:0;text-align:center;">TT (Tetanus) Counts — Women</h2>
      <div class="stat-list" data-slot="tt"></div>
    </div>`;
}

// onBoxClick(tag, kind) fires when a vaccine/TT box is tapped, so the caller can drill down.
// onExportAll(list) fires from the "Download/Share All Category Work" button (omit both exportAllLabel and onExportAll to hide it); `list` holds
// EVERY category together: 0–11 months, 12–23 months, 24+ months and All TT (women).
function fillDashboard(containerEl, recs, excludeMeasles2FromB, onBoxClick, exportAllLabel, onExportAll){
  containerEl.innerHTML = dashboardHTML();
  const epiCounts = {};
  const ttCounts = {};
  const age = { b0:0, b1:0, b2:0 };
  const ageRecords = { b0:[], b1:[], b2:[] };
  const ttRecords = [];   // "All TT" = every woman's TT record
  for (const r of recs) {
    const isTt = isTtRecord(r.doses);
    classifyEpi(r.doses).forEach(t => {
      if (t === 'Measles2') return; // Measles2 never counted in the main (0-11 month) box — see 12-23 month box instead
      epiCounts[t] = (epiCounts[t]||0) + 1;
    });
    classifyTT(r.doses).forEach(t => { ttCounts[t] = (ttCounts[t]||0) + 1; });
    // TT rows are women and are never counted in ANY child age bracket. The
    // old check only excluded them from b2, so a stray TT row with an odd DOB
    // could land in the 0–11 or 12–23 count.
    if (isTt) { ttRecords.push(r); continue; }
    const am = ageMonths(r.dob, r.vaccDate);
    const bracket = am <= 11 ? 'b0' : (am <= 23 ? 'b1' : 'b2');
    age[bracket]++;
    ageRecords[bracket].push(r);
  }
  containerEl.querySelector('[data-slot="epi"]').innerHTML = orderMain.map(k => statCardHtml(k, 'main', epiCounts[k]||0, EPI_LABELS[k])).join('');
  containerEl.querySelector('[data-slot="tt"]').innerHTML = TT_ORDER.map(k => statCardHtml(k, 'tt', ttCounts[k]||0, TT_LABELS[k], 'tt')).join('');

  const epi1223 = {};
  for (const r of recs) {
    const am = ageMonths(r.dob, r.vaccDate);
    if (am >= 12 && am <= 23) {
      const isTt = isTtRecord(r.doses);
      classifyEpi(r.doses).forEach(t => {
        if (t === 'Measles2' && (excludeMeasles2FromB || isTt)) return;
        epi1223[t] = (epi1223[t]||0) + 1;
      });
    }
  }
  containerEl.querySelector('[data-slot="epi1223"]').innerHTML = order1223.map(k => statCardHtml(k, '1223', epi1223[k]||0, EPI_LABELS[k])).join('');

  const epi24 = {};
  for (const r of recs) {
    const am = ageMonths(r.dob, r.vaccDate);
    if (am >= 24) {
      const isTt = isTtRecord(r.doses);
      classifyEpi(r.doses).forEach(t => {
        if (t === 'Measles2' && (excludeMeasles2FromB || isTt)) return;
        epi24[t] = (epi24[t]||0) + 1;
      });
    }
  }

  containerEl.querySelector('[data-slot="age24"]').innerHTML = order1223.map(k => statCardHtml(k, '24plus', epi24[k]||0, EPI_LABELS[k])).join('');

  containerEl.querySelector('[data-slot="ageB0"]').textContent = age.b0;
  containerEl.querySelector('[data-slot="ageB1"]').textContent = age.b1;
  containerEl.querySelector('[data-slot="ageB2"]').textContent = age.b2;
  containerEl.querySelector('[data-slot="ageTt"]').textContent = ttRecords.length;
  // "Total Unique Children" used to show recs.length, which INCLUDED the TT
  // women that the 24+ bracket deliberately skips — so the three age boxes
  // never added up to the total. Children and women are now reported apart.

  containerEl.querySelectorAll('.stat-card.clickable').forEach(el => {
    el.addEventListener('click', () => onBoxClick(el.dataset.tag, el.dataset.kind));
  });

  // By Age boxes: each one shares/downloads its own group. The normal
  // Share/Download → Card Style / Print Style choice follows.
  const ageGroups = {
    b0: { label: '0–11 Months', list: ageRecords.b0 },
    b1: { label: '12–23 Months', list: ageRecords.b1 },
    b2: { label: '24+ Months', list: ageRecords.b2 },
    tt: { label: 'All TT', list: ttRecords }
  };
  containerEl.querySelectorAll('.age-pdf-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const key = btn.dataset.age;
      runRecordsExportFlow(ageGroups[key].label + ' Results', ageGroups[key].list, 'age-' + key);
    });
  });

  // "Download/Share All Category Work" = 0–11 + 12–23 + 24+ + All TT together.
  // Screens that pass no label/handler (Results by Date) don't get this button at all.
  const allCategoryList = ageRecords.b0.concat(ageRecords.b1, ageRecords.b2, ttRecords);
  const exportAllBtn = containerEl.querySelector('[data-slot="exportAllBtn"]');
  if (exportAllBtn) {
    if (exportAllLabel && onExportAll) {
      exportAllBtn.textContent = exportAllLabel;
      exportAllBtn.onclick = () => onExportAll(allCategoryList);
    } else {
      exportAllBtn.remove();
    }
  }
}

// records matching one specific box's tag, mirroring the exact rule that box was counted with
function recordsForTag(recs, tag, kind, excludeMeasles2FromB){
  if (kind === 'tt') return recs.filter(r => classifyTT(r.doses).includes(tag));
  if (kind === '1223') {
    return recs.filter(r => {
      const am = ageMonths(r.dob, r.vaccDate);
      if (am < 12 || am > 23) return false;
      const isTt = isTtRecord(r.doses);
      if (tag === 'Measles2' && (excludeMeasles2FromB || isTt)) return false;
      return classifyEpi(r.doses).includes(tag);
    });
  }
  if (kind === '24plus') {
    return recs.filter(r => {
      const am = ageMonths(r.dob, r.vaccDate);
      if (am < 24) return false;
      const isTt = isTtRecord(r.doses);
      if (tag === 'Measles2' && (excludeMeasles2FromB || isTt)) return false;
      return classifyEpi(r.doses).includes(tag);
    });
  }
  return recs.filter(r => classifyEpi(r.doses).includes(tag)); // 'main'
}
