window.WorkspacePluginOwnership=(()=>{
  let latest=null;
  const ownersByPlugin=new Map();
  const ownersByModId=new Map();
  const matchedMo2ByModId=new Map();

  function normalizeRows(value){
    let rows=value;
    for(let i=0;i<4;i++){
      if(typeof rows==='string'){
        try{rows=JSON.parse(rows);continue}catch{return[]}
      }
      if(Array.isArray(rows)&&rows.length===1&&(Array.isArray(rows[0])||typeof rows[0]==='string')){rows=rows[0];continue}
      break
    }
    if(!Array.isArray(rows))rows=rows&&typeof rows==='object'?[rows]:[];
    return rows.flat(4).filter(row=>row&&typeof row==='object'&&!Array.isArray(row))
  }

  function pluginKey(value){return String(value||'').trim().toLowerCase()}

  function ingest(payload){
    latest=payload?.latest||null;
    ownersByPlugin.clear();ownersByModId.clear();matchedMo2ByModId.clear();
    if(!latest)return payload;

    for(const row of normalizeRows(latest.mods)){
      if(Number(row.is_separator))continue;
      const id=Number(row.matched_mod_id);
      if(!Number.isInteger(id)||id<=0)continue;
      if(!matchedMo2ByModId.has(id))matchedMo2ByModId.set(id,[]);
      matchedMo2ByModId.get(id).push(row)
    }

    for(const row of normalizeRows(latest.owners)){
      const key=pluginKey(row.plugin_name);if(!key)continue;
      if(!ownersByPlugin.has(key))ownersByPlugin.set(key,[]);
      ownersByPlugin.get(key).push(row);
      const id=Number(row.matched_mod_id);
      if(Number.isInteger(id)&&id>0){
        if(!ownersByModId.has(id))ownersByModId.set(id,[]);
        ownersByModId.get(id).push(row)
      }
    }
    return payload
  }

  function priority(row){const n=Number(row?.provider_priority);return Number.isFinite(n)?n+1:null}
  function loadOrder(row){const n=Number(row?.load_order);return row?.load_order!==null&&row?.load_order!==undefined&&Number.isFinite(n)?n+1:null}
  function providersForPlugin(name){return ownersByPlugin.get(pluginKey(name))||[]}

  function groupedForMod(mod){
    const matchedRows=ownersByModId.get(Number(mod?.id))||[],groups=new Map();
    for(const matchedRow of matchedRows){
      const key=pluginKey(matchedRow.plugin_name);if(groups.has(key))continue;
      const providers=providersForPlugin(matchedRow.plugin_name);
      const evidence=providers[0]||matchedRow;
      groups.set(key,{plugin_name:matchedRow.plugin_name,providers,load_order:loadOrder(evidence),plugin_enabled:evidence.plugin_enabled})
    }
    return [...groups.values()].sort((a,b)=>{
      if(a.load_order!==null&&b.load_order!==null)return a.load_order-b.load_order;
      if(a.load_order!==null)return-1;if(b.load_order!==null)return 1;
      return String(a.plugin_name).localeCompare(String(b.plugin_name))
    })
  }

  function providerText(providers){
    if(!providers.length)return'No MO2 mod-folder provider';
    if(providers.length===1){const p=providers[0],prio=priority(p);return`${p.provider_mod_name||'Unknown provider'}${prio?` · Mod #${prio}`:''}${Number(p.provider_enabled)?'':' · disabled'}`}
    const names=[...new Set(providers.map(p=>String(p.provider_mod_name||'Unknown provider')))];
    return`${providers.length} providers recorded · ${names.slice(0,2).join(' / ')}${names.length>2?' / …':''}`
  }

  function profileMarkup(plugin,escape){
    const providers=providersForPlugin(plugin?.plugin_name),enabled=Number(plugin?.enabled)===1;
    return`<div class="mo2-plugin-row ${enabled?'enabled':'disabled'}"><i>${Number(plugin?.load_order)+1}</i><b>${escape(plugin?.plugin_name||'')}</b><span class="mo2-plugin-provider${providers.length>1?' duplicate':''}">${escape(providerText(providers))}</span></div>`
  }

  function applyDetail(mod,escape){
    const host=document.getElementById('detailMo2Plugins');if(!host)return;
    if(!latest){host.innerHTML='<p class="detail-plugin-empty">MO2 plugin ownership is not loaded.</p>';return}
    const matched=matchedMo2ByModId.get(Number(mod?.id))||[];
    if(!matched.length){host.innerHTML='<p class="detail-plugin-empty">This library record is not matched to the current MO2 snapshot.</p>';return}
    const groups=groupedForMod(mod);
    if(!groups.length){host.innerHTML='<p class="detail-plugin-empty">No root-level ESM, ESP, or ESL files were observed in the matched MO2 mod folder(s). This may be an ESPless mod.</p>';return}
    host.innerHTML=groups.map(group=>{
      const enabled=Number(group.plugin_enabled)===1,load=group.load_order?`Load #${group.load_order}`:'Not in load order';
      return`<article class="detail-plugin-row ${enabled?'enabled':'disabled'}"><div><b>${escape(group.plugin_name)}</b><small>${escape(load)} · ${enabled?'Enabled':'Disabled / unconfirmed'}</small></div><span>${escape(providerText(group.providers))}</span>${group.providers.length>1?'<em>Multiple providers recorded</em>':''}</article>`
    }).join('')
  }

  function counts(){
    const rows=[...ownersByPlugin.values()].flat();
    return{ownership_rows:rows.length,unique_plugins:ownersByPlugin.size,matched_mods:ownersByModId.size}
  }

  return{ingest,providersForPlugin,groupedForMod,profileMarkup,applyDetail,counts,latest:()=>latest}
})();
