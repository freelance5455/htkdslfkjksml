import { el, showAlert } from "../ui/widgets.js";

const SINGLE_CODE = "ME"; // one learner profile on this device

export async function Login(app) {
  const nameInput = el("input", {
    type: "text",
    placeholder: "Your name",
    autocomplete: "name",
    value: ""
  });

  // If a profile already exists, offer continue
  const existing = app.loadStudentByCode(SINGLE_CODE);

  async function startFresh() {
    const name = nameInput.value.trim();
    if (!name || name.length < 2) {
      return showAlert("Name needed", "Please type your name so Learnly can cheer you on.");
    }
    await app.login(SINGLE_CODE, 5, name);
  }

  async function continueExisting() {
    await app.login(SINGLE_CODE, 5, null);
  }

  nameInput.addEventListener("keydown", (e) => { if (e.key === "Enter") startFresh(); });

  const kids = [
    el("div", { class: "center", style: "font-size:2.4rem;font-weight:800;" }, "Learnly"),
    el("div", { class: "center role-subtitle" }, "Grade 5 Maths · Stars, quests & practice"),
    el("div", { style: "height:0.5rem" })
  ];

  if (existing && existing.name) {
    kids.push(
      el("div", { class: "card" }, [
        el("div", { class: "role-heading" }, `Welcome back, ${existing.name}!`),
        el("div", { class: "role-subtitle wrap" },
          `⭐ ${existing.xp || 0} XP · 🔥 ${existing.streak || 0} day streak · Level ${existing.level || 1}`)
      ]),
      el("button", { class: "btn", onClick: continueExisting }, "▶ CONTINUE"),
      el("div", { class: "section-eyebrow" }, "OR START A NEW NAME"),
      el("label", { class: "field-label" }, "Learner name"),
      nameInput,
      el("button", { class: "btn-secondary", onClick: startFresh }, "✨ SAVE NAME & PLAY")
    );
  } else {
    kids.push(
      el("label", { class: "field-label" }, "What is your name?"),
      nameInput,
      el("button", { class: "btn", onClick: startFresh }, "🚀 START LEARNING"),
      el("div", { class: "role-muted wrap" },
        "One learner on this device. Parents can open Parent View from the profile to see progress.")
    );
  }

  return {
    title: "",
    showBack: false,
    body: [
      el("div", {
        style: "flex:1;display:flex;flex-direction:column;justify-content:center;gap:0.85rem;padding:1.5rem 0;"
      }, kids)
    ]
  };
}
