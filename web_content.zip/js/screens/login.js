import { el, showAlert } from "../ui/widgets.js";
import { THEMES } from "../theme.js";

const SINGLE_CODE = "ME";

const GRADES = [
  { value: 0, label: "Grade R" },
  ...Array.from({ length: 12 }, (_, i) => ({ value: i + 1, label: `Grade ${i + 1}` }))
];

const GENDERS = [
  { value: "girl", label: "Girl" },
  { value: "boy", label: "Boy" },
  { value: "prefer_not", label: "Prefer not to say" }
];

export async function Login(app) {
  const nameInput = el("input", {
    type: "text",
    placeholder: "Your name",
    autocomplete: "name",
    value: ""
  });

  const gradeSelect = el("select", {}, GRADES.map((g) =>
    el("option", { value: String(g.value) }, g.label)
  ));
  gradeSelect.value = "5";

  const genderSelect = el("select", {}, GENDERS.map((g) =>
    el("option", { value: g.value }, g.label)
  ));

  const themeSelect = el("select", {}, THEMES.map((t) =>
    el("option", { value: t }, t)
  ));
  themeSelect.value = "Candy";

  const existing = app.loadStudentByCode(SINGLE_CODE);

  async function startFresh() {
    const name = nameInput.value.trim();
    if (!name || name.length < 2) {
      return showAlert("Name needed", "Please type your name so Learnly can cheer you on.");
    }
    const grade = parseInt(gradeSelect.value, 10);
    const gender = genderSelect.value;
    const theme = themeSelect.value;
    await app.login(SINGLE_CODE, grade, name, { gender, theme });
  }

  async function continueExisting() {
    await app.login(SINGLE_CODE, existing.grade ?? 5, null);
  }

  nameInput.addEventListener("keydown", (e) => { if (e.key === "Enter") startFresh(); });

  const kids = [
    el("div", { class: "center", style: "font-size:2.2rem;font-weight:800;" }, "Learnly"),
    el("div", { class: "center role-subtitle" }, "learnyZ · CAPS Grades R–12"),
    el("div", { style: "height:0.35rem" })
  ];

  if (existing && existing.name) {
    kids.push(
      el("div", { class: "card" }, [
        el("div", { class: "role-heading" }, `Welcome back, ${existing.name}!`),
        el("div", { class: "role-subtitle wrap" },
          `Grade ${existing.grade === 0 ? "R" : (existing.grade || 5)} · ⭐ ${existing.xp || 0} XP · Level ${existing.level || 1}`)
      ]),
      el("button", { class: "btn", onClick: continueExisting }, "▶ CONTINUE"),
      el("div", { class: "section-eyebrow" }, "OR NEW PROFILE")
    );
  }

  kids.push(
    el("label", { class: "field-label" }, "Learner name"),
    nameInput,
    el("label", { class: "field-label" }, "Grade"),
    gradeSelect,
    el("label", { class: "field-label" }, "Gender"),
    genderSelect,
    el("label", { class: "field-label" }, "Preferred theme"),
    themeSelect,
    el("button", { class: "btn", onClick: startFresh }, existing?.name ? "✨ SAVE & PLAY" : "🚀 START LEARNING"),
    el("div", { class: "role-muted wrap" },
      "Subjects unlock by grade (CAPS): Maths for all · NS & Tech from Grade 4 · Life Sciences & Geography from Grade 10.")
  );

  return {
    title: "",
    showBack: false,
    body: [
      el("div", {
        style: "flex:1;display:flex;flex-direction:column;justify-content:center;gap:0.75rem;padding:1.25rem 0;"
      }, kids)
    ]
  };
}
