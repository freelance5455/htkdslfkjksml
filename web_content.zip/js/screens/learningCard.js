import { el, card, showAlert } from "../ui/widgets.js";
import { getLesson, listLessonsForSubject } from "../engines/learningCards.js";
import { subjectLabel, loadSubjectRegistry } from "../engines/subjectRegistry.js";
import { MultiSubjectEngine } from "../engines/multiSubjectEngine.js";
import { EconomyEngine } from "../engines/economyEngine.js";

/**
 * Learning card flow: plain intro → step-by-step teaching → retention check.
 */
export async function LearningCardHub(app) {
  await loadSubjectRegistry();
  const sid = app.student?.subject || "mathematical_literacy";
  const lessons = listLessonsForSubject(sid);
  const body = [
    el("div", { class: "role-subtitle wrap" },
      "Short lessons in everyday language. Each card teaches one idea, then checks what you remember."),
    el("div", { class: "section-eyebrow" }, subjectLabel(sid) || sid)
  ];
  if (!lessons.length) {
    body.push(card("Coming soon", "Learning cards for this subject are being added."));
  } else {
    lessons.forEach((L) => {
      body.push(card("📖 " + L.title, L.plain.slice(0, 120) + (L.plain.length > 120 ? "…" : ""), [
        { label: "LEARN", onClick: () => app.navigate("learningCard", { topicId: L.id }) }
      ]));
    });
  }
  body.push(el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"));
  return { title: "Learning cards", bottomNavKey: "learn", body };
}

export async function LearningCard(app, { topicId } = {}) {
  const lesson = getLesson(topicId);
  if (!lesson) {
    return {
      title: "Learning card",
      body: [
        el("div", { class: "wrap" }, "Lesson not found."),
        el("button", { class: "btn-secondary", onClick: () => app.navigate("learningCardHub") }, "← Back")
      ]
    };
  }

  let phase = "teach"; // teach | check | done
  let step = 0;
  let checkIdx = 0;
  let score = 0;
  let answered = 0;

  const host = el("div", {});

  function render() {
    host.innerHTML = "";
    if (phase === "teach") {
      host.appendChild(el("div", {
        style: "font-size:0.75rem;font-weight:800;letter-spacing:0.06em;text-transform:uppercase;opacity:0.7;margin-bottom:0.35rem;"
      }, `Step ${step + 1} of ${lesson.steps.length}`));
      host.appendChild(el("div", {
        class: "card",
        style: "border-left:4px solid var(--accent);"
      }, [
        el("div", { class: "role-heading" }, lesson.title),
        step === 0
          ? el("div", { class: "wrap", style: "margin:0.4rem 0 0.6rem;opacity:0.9;" }, lesson.plain)
          : null,
        el("div", {
          class: "wrap",
          style: "white-space:pre-wrap;line-height:1.55;font-size:1.02rem;"
        }, lesson.steps[step])
      ].filter(Boolean)));

      if (step === 0 && lesson.terms?.length) {
        host.appendChild(card("Words to know",
          lesson.terms.map(([w, d]) => `• ${w} — ${d}`).join("\n")));
      }

      const nav = el("div", { class: "btn-row", style: "margin-top:0.75rem;gap:0.4rem;flex-wrap:wrap;" });
      if (step > 0) {
        nav.appendChild(el("button", {
          class: "btn-secondary",
          onClick: () => { step -= 1; render(); }
        }, "← Back"));
      }
      if (step < lesson.steps.length - 1) {
        nav.appendChild(el("button", {
          class: "btn",
          onClick: () => { step += 1; render(); }
        }, "Next →"));
      } else {
        nav.appendChild(el("button", {
          class: "btn",
          style: "background:linear-gradient(135deg,#0d9488,#059669);border:none;",
          onClick: () => { phase = "check"; checkIdx = 0; score = 0; answered = 0; render(); }
        }, "Check what I remember"));
      }
      host.appendChild(nav);
      return;
    }

    if (phase === "check") {
      const items = lesson.check || [];
      if (!items.length || checkIdx >= items.length) {
        phase = "done";
        render();
        return;
      }
      const item = items[checkIdx];
      host.appendChild(el("div", {
        style: "font-size:0.75rem;font-weight:800;letter-spacing:0.06em;text-transform:uppercase;opacity:0.7;"
      }, `Check ${checkIdx + 1} of ${items.length}`));
      host.appendChild(el("div", { class: "card" }, [
        el("div", { class: "wrap", style: "font-weight:650;line-height:1.45;" }, item.q)
      ]));
      const input = el("input", {
        type: "text",
        placeholder: "Your answer",
        style: "width:100%;margin-top:0.5rem;padding:0.75rem;border-radius:0.65rem;"
      });
      const feedback = el("div", { class: "wrap", style: "margin-top:0.45rem;min-height:1.2rem;font-weight:600;" }, "");
      const submit = () => {
        if (input.disabled) return;
        const raw = (input.value || "").trim();
        if (!raw) return;
        input.disabled = true;
        answered += 1;
        const ok = softMatch(raw, item.a);
        if (ok) {
          score += 1;
          feedback.textContent = "Correct — well remembered.";
          feedback.style.color = "#059669";
        } else {
          feedback.textContent = `Not quite. Expected: ${item.a}` + (item.hint ? ` (hint was: ${item.hint})` : "");
          feedback.style.color = "#dc2626";
        }
        setTimeout(() => {
          checkIdx += 1;
          render();
        }, 900);
      };
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
      host.appendChild(input);
      host.appendChild(el("button", { class: "btn", style: "margin-top:0.55rem;", onClick: submit }, "Check"));
      host.appendChild(feedback);
      if (item.hint) {
        host.appendChild(el("div", { class: "role-muted wrap", style: "margin-top:0.35rem;font-size:0.85rem;" },
          "Hint available after you answer."));
      }
      return;
    }

    // done
    const total = (lesson.check || []).length || 1;
    const pct = Math.round((score / total) * 100);
    try {
      if (score > 0) new EconomyEngine(app.student).earn("learning_card", "Learning card");
      app.student.mastery = app.student.mastery || {};
      const prev = app.student.mastery[topicId] ?? 0.35;
      app.student.mastery[topicId] = Math.min(1, prev + 0.05 + (pct / 100) * 0.1);
      app.saveStudent();
    } catch { /* ignore */ }

    host.appendChild(el("div", { class: "card", style: "text-align:center;padding:1.2rem;" }, [
      el("div", { style: "font-size:2rem;" }, pct >= 70 ? "🌟" : "📝"),
      el("div", { class: "role-heading", style: "margin-top:0.4rem;" }, "Lesson complete"),
      el("div", { class: "wrap", style: "margin-top:0.35rem;" },
        `You got ${score} of ${total} on the retention check (${pct}%).`),
      el("div", { class: "role-muted wrap", style: "margin-top:0.35rem;" },
        pct >= 70
          ? "Strong recall — try a practice session next."
          : "Re-read the steps, then try the check again.")
    ]));
    host.appendChild(el("div", { class: "btn-row", style: "margin-top:0.75rem;gap:0.4rem;flex-wrap:wrap;" }, [
      el("button", {
        class: "btn",
        onClick: () => app.navigate("practiceSetup", { mode: "choose", topics: [topicId] })
      }, "Practise this topic"),
      el("button", {
        class: "btn-secondary",
        onClick: () => { phase = "teach"; step = 0; render(); }
      }, "Revise lesson"),
      el("button", {
        class: "btn-secondary",
        onClick: () => app.navigate("learningCardHub")
      }, "More cards")
    ]));
  }

  function softMatch(user, expected) {
    const u = String(user).toLowerCase().replace(/,/g, ".").replace(/\s+/g, " ").trim();
    const options = String(expected).toLowerCase().split("/").map((s) => s.trim());
    return options.some((e) => {
      if (!e) return false;
      if (u === e) return true;
      if (e.includes(u) && u.length >= 2) return true;
      if (u.includes(e) && e.length >= 3) return true;
      // numeric soft
      const nu = parseFloat(u.replace(/[^\d.-]/g, ""));
      const ne = parseFloat(e.replace(/[^\d.-]/g, ""));
      if (Number.isFinite(nu) && Number.isFinite(ne) && Math.abs(nu - ne) < 0.05) return true;
      return false;
    });
  }

  render();
  return {
    title: "📖 " + lesson.title,
    bottomNavKey: "learn",
    body: [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("learningCardHub") }, "← Learning cards"),
      host
    ]
  };
}
