import { el, card } from "../ui/widgets.js";
import { AdaptiveEngine } from "../engines/adaptive.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { applyTheme } from "../theme.js";
import { loadSubjectRegistry, subjectsForGrade, subjectChipLabel, defaultSubject } from "../engines/subjectRegistry.js";

const GREETS = ["Hi", "Hey", "Sawubona", "Yebo"];

export async function Home(app) {
  const s = app.student;
  await loadSubjectRegistry();
  const available = subjectsForGrade(s.grade ?? 5);
  if (!s.subject || !available.includes(s.subject)) s.subject = defaultSubject(s.grade ?? 5);
  s.subject = s.subject || "maths";
  const goal = s.daily_goal ?? 20, done = s.today_done ?? 0;
  const econ = new EconomyEngine(s);
  const gam = new GamificationEngine(s);
  gam.checkNewUnlocks();
  app.saveStudent();
  const [unlocked, visible] = gam.progressSummary();
  const name = s.name || "friend";
  const greet = GREETS[Math.floor(Math.random() * GREETS.length)];
  const rec = new AdaptiveEngine(s).recommendationText();

  const themeMap = {
    theme_sunset: "Sunset", theme_forest: "Forest", theme_ocean: "Ocean",
    theme_candy: "Candy", theme_midnight: "Midnight", theme_neon: "Neon"
  };
  if (s.active_reward && themeMap[s.active_reward]) {
    applyTheme(themeMap[s.active_reward], s.settings?.font_scale || "Normal");
    s.settings = s.settings || {};
    s.settings.theme = themeMap[s.active_reward];
  }


  const pct = Math.min(100, Math.round((done / Math.max(1, goal)) * 100));
  const grade = s.grade ?? 5;
  const isFet = grade >= 10;
  const isPS = s.subject === "physical_sciences";
  const isLife = s.subject === "life_sciences";
  const isGeo = s.subject === "geography";
  const isAcc = s.subject === "accounting";
  const isNS = s.subject === "natural_sciences" || s.subject === "natural_sciences_technology";
  const isTech = s.subject === "technology";
  const isAlt = isPS || isLife || isGeo || isAcc || isNS || isTech;

  const playCards = isAlt
    ? [
        card("🎯 Practise", "Topic questions for this subject", [{ label: "GO", onClick: () => app.showSubjectHub() }]),
        card("📝 Papers & quiz", "Topic practice and short quiz", [{ label: "GO", onClick: () => isPS ? app.showPapers() : app.showSubjectHub() }]),
        card("📘 Notes", "Key facts and diagrams", [{ label: "GO", onClick: () => app.showSubjectHub() }])
      ]
    : isFet
    ? [
        card("🎯 Practise", "CAPS topics for your grade", [{ label: "GO", onClick: () => app.showPractice("choose") }]),
        card("📐 Theorems", "Formulae — drag, match, type", [{ label: "GO", onClick: () => app.navigate("theoremLab") }]),
        card("📄 Papers", "Past papers & generate", [{ label: "GO", onClick: () => app.showPapers() }])
      ]
    : [
        ...(grade === 5 ? [card("🔤 IsiZulu Word Builder", "Build words + spelling mode", [{ label: "OPEN", onClick: () => app.navigate("zuluWordBuilder") }])] : []),
        card("🎯 Start", "Jump into a short set", [{ label: "GO", onClick: () => app.showPractice("recommended") }]),
        card("⚔️ Challenges", "+ − × ÷ · timer optional", [{ label: "GO", onClick: () => app.showChallenges() }]),
        card("⚡ Sprint", "Speed round", [{ label: "GO", onClick: () => app.showMental() }])
      ];

  const learnCards = isAlt
    ? [
        card("📘 Topics", "CAPS topics for this subject", [{ label: "GO", onClick: () => app.showSubjectHub() }]),
        card("🧠 Quiz", "Short questions with feedback", [{ label: "GO", onClick: () => app.showSubjectHub() }]),
        ...(isPS ? [card("📐 Formula workshop", "Drag · match · type", [{ label: "GO", onClick: () => app.navigate("theoremLab") }])] : [])
      ]
    : isFet
    ? [
        card("📘 Maths topics", "Notes for every CAPS maths topic", [{ label: "GO", onClick: () => app.showLearn() }]),
        card("🎮 Workshops", "Theorems · equations · finance", [{ label: "GO", onClick: () => app.showLabs() }]),
        card("📄 Past papers", "March · June · Sept · November", [{ label: "GO", onClick: () => app.showPapers() }])
      ]
    : [
        ...(grade === 5 ? [card("🔤 IsiZulu Word Builder", "Build words + spelling mode", [{ label: "OPEN", onClick: () => app.navigate("zuluWordBuilder") }])] : []),
        card("📘 Lessons", "Step-by-step with big visuals", [{ label: "GO", onClick: () => app.showMathsLessons() }]),
        card("🃏 Teach cards", "Quick methods", [{ label: "GO", onClick: () => app.showTeach() }]),
        card("📝 Challenges 3.1–3.6", "Long questions", [{ label: "GO", onClick: () => app.showStructured() }]),
        card("🎮 Workshops", "Shapes · data", [{ label: "GO", onClick: () => app.showLabs() }])
      ];

  const body = [
    el("div", {
      class: "card hero-card",
      style: "background:linear-gradient(145deg,var(--accent),color-mix(in srgb,var(--accent) 55%,#8fb0ff));color:var(--on-accent);border:none;padding:1.15rem 1.1rem;"
    }, [
      el("div", { style: "font-size:0.75rem;font-weight:800;letter-spacing:0.06em;opacity:0.85;text-transform:uppercase;" }, "learnyZ"),
      el("div", { style: "font-size:1.55rem;font-weight:800;letter-spacing:-0.02em;margin-top:0.2rem;" }, `${greet}, ${name}`),
      el("div", { style: "margin-top:0.45rem;opacity:0.95;font-size:0.92rem;" },
        `Grade ${grade === 0 ? "R" : grade} · Lv ${s.level ?? 1} · ${s.xp ?? 0} XP · 🔥 ${s.streak ?? 0} · ⭐ ${econ.balance()}`),
      el("div", { style: "margin-top:0.75rem;background:rgba(255,255,255,0.22);border-radius:999px;height:8px;overflow:hidden;" }, [
        el("div", { style: `height:100%;width:${pct}%;background:#fff;border-radius:999px;transition:width 0.3s ease;` })
      ]),
      el("div", { style: "margin-top:0.4rem;font-size:0.82rem;opacity:0.9;" }, `Today ${done}/${goal} · ${rec}`)
    ]),
    // Subject switch — CAPS subjects available for this grade
    ...(available.length > 1 ? [el("div", {
      class: "btn-row",
      style: "margin:0.5rem 0 0.75rem;gap:0.35rem;flex-wrap:wrap;"
    }, available.map((sid) => el("button", {
      class: "chip" + (s.subject === sid ? " active" : ""),
      style: "flex:1;min-width:40%;padding:0.6rem;font-weight:700;",
      onClick: () => {
        s.subject = sid;
        app.saveStudent();
        app.showHome();
      }
    }, subjectChipLabel(sid))))] : []),
    el("div", { class: "section-eyebrow" }, "PLAY"),
    ...playCards,
    el("div", { class: "section-eyebrow" }, "LEARN"),
    ...learnCards,
    el("div", { class: "section-eyebrow" }, "YOU"),
    card("🏆 Badges", `${unlocked}/${visible}`, [{ label: "OPEN", onClick: () => app.showAchievements() }]),
    card("🎁 Shop", "Themes & packs", [{ label: "OPEN", onClick: () => app.showRewards() }])
  ];
  if (!isFet) {
    body.push(card("📄 Papers", "Save as picture", [{ label: "OPEN", onClick: () => app.showPapers() }]));
  }

  return { title: "Learnly", showBack: false, bottomNavKey: "home", body };
}
