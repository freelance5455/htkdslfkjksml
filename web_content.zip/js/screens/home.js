import { el, card } from "../ui/widgets.js";
import { licenceDaysLeft } from "../db.js";
import { AdaptiveEngine } from "../engines/adaptive.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { applyTheme } from "../theme.js";
import { loadSubjectRegistry, subjectsForGrade, subjectChipLabel, defaultSubject, topicsForSubject } from "../engines/subjectRegistry.js";
import { GradeManager } from "../engines/gradeManager.js";

const GREETS = [
  "Good to see you",
  "Welcome back",
  "Ready when you are",
  "Let's make progress",
  "Sharp focus today",
  "You've got this",
  "Steady steps",
  "Time to shine",
  "Onwards",
  "Hi",
  "Hello",
  "Sawubona",
  "Yebo",
  "Afternoon focus",
  "Evening study mode"
];

function titleCase(s) {
  return String(s || "").replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function subjectTopicIds(subject, grade) {
  const list = topicsForSubject(subject) || [];
  return list.map((t) => t.id || t).filter(Boolean);
}

function subjectInsights(student, subject) {
  const mastery = student.mastery || {};
  const ids = subjectTopicIds(subject, student.grade ?? 10);
  const scored = ids
    .map((id) => [id, mastery[id]])
    .filter(([, v]) => v != null && !Number.isNaN(v));
  if (!scored.length) {
    return {
      strengths: "Practise a few questions to build your profile.",
      weaknesses: "No subject data yet — start with notes or a short quiz.",
      tip: "Your strengths and focus areas will appear here for the selected subject."
    };
  }
  scored.sort((a, b) => b[1] - a[1]);
  const strong = scored.filter(([, v]) => v >= 0.65).slice(0, 3);
  const weak = scored.filter(([, v]) => v < 0.55).sort((a, b) => a[1] - b[1]).slice(0, 3);
  const strengths = strong.length
    ? strong.map(([id, v]) => `${titleCase(id)} (${Math.round(v * 100)}%)`).join(" · ")
    : "Still building — keep practising strong topics.";
  const weaknesses = weak.length
    ? weak.map(([id, v]) => `${titleCase(id)} (${Math.round(v * 100)}%)`).join(" · ")
    : "No critical gaps detected in this subject.";
  const tip = weak.length
    ? `Focus next: ${titleCase(weak[0][0])}.`
    : "Solid coverage — try exam-style papers for this subject.";
  return { strengths, weaknesses, tip };
}

export async function Home(app) {
  const s = app.student;
  await loadSubjectRegistry();
  const available = subjectsForGrade(10);
  if (!s.subject || !available.includes(s.subject)) s.subject = defaultSubject(10);
  s.subject = s.subject || "mathematical_literacy";
  const goal = s.daily_goal ?? 20, done = s.today_done ?? 0;
  const econ = new EconomyEngine(s);
  const gam = new GamificationEngine(s);
  gam.checkNewUnlocks();
  app.saveStudent();
  const [unlocked, visible] = gam.progressSummary();
  const name = s.name || "learner";
  const greet = GREETS[Math.floor(Math.random() * GREETS.length)];
  const insights = subjectInsights(s, s.subject);

  const themeMap = {
    theme_sunset: "Sunset", theme_forest: "Forest", theme_ocean: "Ocean",
    theme_candy: "Candy", theme_midnight: "Midnight", theme_neon: "Neon"
  };
  if (s.active_reward && themeMap[s.active_reward]) {
    applyTheme(themeMap[s.active_reward], s.settings?.font_scale || "Normal");
    s.settings = s.settings || {};
    s.settings.theme = themeMap[s.active_reward];
  }

  const pct = Math.min(100, Math.round((done / Math.max(1, goal)) * 100));
  const playCards = [
        card("Practise", "Topic questions for this subject", [{ label: "GO", onClick: () => app.showPractice("choose") }]),
        card("Papers", "Exam-style papers and topic practice", [{ label: "GO", onClick: () => app.showPapers() }]),
        card("Notes", "Key facts, method and worked examples", [{ label: "GO", onClick: () => app.showSubjectHub() }])
      ];

  const learnCards = [
        card("Topics", "CAPS topics for this subject", [{ label: "GO", onClick: () => app.showSubjectHub() }]),
        card("Quiz", "Short questions with feedback", [{ label: "GO", onClick: () => app.navigate("subjectQuiz", { subjectId: s.subject, topicId: null }) }]),
        card("Reference", "Formulae and key tables", [{ label: "GO", onClick: () => app.showReferenceSheets() }])
      ];

  const body = [
    el("div", {
      class: "card hero-card",
      style: "background:linear-gradient(145deg,var(--accent),color-mix(in srgb,var(--accent) 55%,#8fb0ff));color:var(--on-accent);border:none;padding:1.15rem 1.1rem;"
    }, [
      el("div", { style: "font-size:0.72rem;font-weight:800;letter-spacing:0.06em;opacity:0.9;text-transform:uppercase;" }, "Learnly Grade 10"),
      el("div", { style: "font-size:1.5rem;font-weight:800;letter-spacing:-0.02em;margin-top:0.25rem;" }, `${greet}, ${name}`),
      el("div", { style: "margin-top:0.4rem;opacity:0.95;font-size:0.9rem;" },
        `Grade 10 · Lv ${s.level ?? 1} · ${s.xp ?? 0} XP · 🔥 ${s.streak ?? 0} · ⭐ ${econ.balance()}`),
      el("div", { style: "margin-top:0.35rem;opacity:0.88;font-size:0.8rem;" }, "Math Lit · Business · Tourism · The Elites Academy"),
      el("div", { style: "margin-top:0.25rem;opacity:0.85;font-size:0.75rem;font-weight:700;" },
        (() => { const d = licenceDaysLeft(); return d > 0 ? `Licence · ${d} day${d === 1 ? "" : "s"} left` : "Licence expired — renew in Settings"; })()),
      el("div", { style: "margin-top:0.75rem;background:rgba(255,255,255,0.22);border-radius:999px;height:8px;overflow:hidden;" }, [
        el("div", { style: `height:100%;width:${pct}%;background:#fff;border-radius:999px;transition:width 0.3s ease;` })
      ]),
      el("div", { style: "margin-top:0.4rem;font-size:0.82rem;opacity:0.9;" }, `Today ${done}/${goal} · ${insights.tip}`)
    ]),
    el("div", {
      class: "btn-row",
      style: "margin:0.5rem 0 0.75rem;gap:0.35rem;flex-wrap:wrap;"
    }, available.map((sid) => el("button", {
      class: "chip" + (s.subject === sid ? " active" : ""),
      style: "flex:1;min-width:40%;padding:0.6rem;font-weight:700;",
      onClick: () => {
        s.subject = sid;
        app.saveStudent();
        app.showHome();
      }
    }, subjectChipLabel(sid)))),
    el("div", { class: "section-eyebrow" }, `THIS SUBJECT · ${subjectChipLabel(s.subject).replace(/^[^\w]+/, "")}`),
    card("Strengths", insights.strengths),
    card("Focus areas", insights.weaknesses),
    el("div", { class: "section-eyebrow" }, "PLAY"),
    ...playCards,
    el("div", { class: "section-eyebrow" }, "LEARN"),
    ...learnCards,
    el("div", { class: "section-eyebrow" }, "YOU"),
    card("Badges", `${unlocked}/${visible}`, [{ label: "OPEN", onClick: () => app.showAchievements() }]),
    card("Shop", "Themes & packs", [{ label: "OPEN", onClick: () => app.showRewards() }])
  ];

  return { title: "Home", showBack: false, bottomNavKey: "home", body };
}
