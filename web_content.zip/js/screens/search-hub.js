function runSearch(){
  const nameQ = document.getElementById('searchName').value.trim().toLowerCase();
  const fatherQ = document.getElementById('searchFather').value.trim().toLowerCase();
  const dateQ = document.getElementById('searchDate').value; // 'YYYY-MM-DD' or ''
  const addressQ = document.getElementById('searchAddress').value.trim().toLowerCase();
  const mobileQ = document.getElementById('searchMobile').value.trim().toLowerCase();

  let dateParts = null;
  if (dateQ) {
    const parts = dateQ.split('-').map(Number);
    dateParts = { y: parts[0], m: parts[1], d: parts[2] };
  }

  const heading = document.getElementById('searchResultsHeading');
  const countEl = document.getElementById('searchResultsCount');
  const resultsCard = document.getElementById('searchResultsCard');

  if (!nameQ && !fatherQ && !dateParts && !addressQ && !mobileQ) {
    // Nothing to search on: automatically clear away any previous search
    // result instead of leaving old matches on screen.
    heading.style.display = 'none';
    resultsCard.style.display = 'none';
    document.getElementById('searchDetailTable').innerHTML = '';
    return;
  }

  // Mobile number is recorded as part of the Address text extracted from the
  // PDF (the Contact / Address column), so a mobile search matches within it.
  const results = allRecordsGlobal.filter(r => {
    if (nameQ && !(r.name || '').toLowerCase().includes(nameQ)) return false;
    if (fatherQ && !(r.fatherName || '').toLowerCase().includes(fatherQ)) return false;
    if (addressQ && !(r.address || '').toLowerCase().includes(addressQ)) return false;
    if (mobileQ && !(r.address || '').toLowerCase().includes(mobileQ)) return false;
    if (dateParts && !(r.vaccDate && r.vaccDate.year === dateParts.y && r.vaccDate.month === dateParts.m && r.vaccDate.day === dateParts.d)) return false;
    return true;
  });

  // Every search fully replaces whatever was shown before — renderDrillTable
  // always overwrites searchDetailTable's content, so a second search never
  // mixes with the first search's results.
  heading.style.display = 'block';
  countEl.textContent = `(${results.length} found)`;
  resultsCard.style.display = 'block';
  renderDrillTable(results, 'searchDetailTable', { shareButton: true });   // each child card gets its own Share/Download button
  // The date field is deliberately NOT cleared any more. It used to be wiped
  // after every search, so pressing SEARCH a second time to refine the name
  // silently dropped the date filter and returned far more rows than expected,
  // with nothing on screen to explain why. Use "Clear" to reset the fields.
  document.getElementById('searchResultsCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// The hub's "⬅ Back" button does exactly what the phone's back button does:
// one step back inside the app (see js/platform/navigation.js). The app always
// keeps its own history trap armed, so this never drifts out of sync.
document.getElementById('btnBackHub').addEventListener('click', () => goBackOneStep());
document.getElementById('btnGoAll').addEventListener('click', () => showGroupView('all'));
document.getElementById('btnGoIn').addEventListener('click', () => showGroupView('in'));
document.getElementById('btnGoOut').addEventListener('click', () => showGroupView('out'));
document.getElementById('btnGoSearch').addEventListener('click', () => showSearchView());
document.getElementById('btnGoDate').addEventListener('click', () => showDateView());
document.getElementById('btnGoStock').addEventListener('click', () => showStockView());
document.getElementById('btnGoQrResults').addEventListener('click', () => showQrResultView());
document.getElementById('btnRunSearch').addEventListener('click', () => runSearch());
// Search Records: every result card has its own "Share / Download this card"
// button. It always exports THAT child's details in Card Style (no style choice).
document.getElementById('searchDetailTable').addEventListener('click', ev => {
  const btn = ev.target.closest('.card-share-btn');
  if (!btn) return;
  const rec = (lastRendered['searchDetailTable'] || [])[Number(btn.dataset.idx)];
  runSingleCardExportFlow(rec);
});
document.getElementById('btnClearSearch').addEventListener('click', () => {
  ['searchName','searchFather','searchAddress','searchMobile','searchDate']
    .forEach(id => { document.getElementById(id).value = ''; });
  document.getElementById('searchResultsHeading').style.display = 'none';
  document.getElementById('searchResultsCard').style.display = 'none';
  document.getElementById('searchDetailTable').innerHTML = '';
});

// Picking a UC re-filters the global record lists (inUcRecordsGlobal /
// outUcRecordsGlobal) against the newly selected facility before anything
// downstream (IN UC / OUT OF UC / All buttons, or the auto-jump below) reads them —
// see renderResults() in results.js.
document.getElementById('ucFilter').addEventListener('change', () => {
  const ucFilterEl = document.getElementById('ucFilter');
  renderResults(loadStore(), true);
  if (ucFilterEl.value !== '__all__') showGroupView('all', ucFilterEl.value); // a specific UC was picked → jump straight to its full combined result, titled with that UC
});

// Populates the UC filter dropdown and the global record lists from whatever
// is already saved — keepView=true so this never overrides which screen is
// showing (main.js decides that once, at the very end of startup); without
// it, this call alone would jump straight to the Results Menu on every open
// whenever data already existed, before the person even saw the main page.
renderResults(loadStore(), true);
