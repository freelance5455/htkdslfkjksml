let inUcRecordsGlobal = [];
let outUcRecordsGlobal = [];
let outTalukaRecordsGlobal = [];
let outDistrictRecordsGlobal = [];
let allRecordsGlobal = [];
let currentGroupType = 'in';

// Re-applies the status / UC rules to every stored record.
// This MUST be the single source of truth: the screen, the CSV export and the
// PDF exports all go through it, so a report can never disagree with what the
// app is showing (older records saved before these rules existed used to be
// labelled "In UC" in the CSV while the screen said "Out From Taluka").
function normalizeStoredRecords(store){
  const epiMap = buildEpiMap();   // QR code -> 8-digit EPI No (from saved Defaulters Reports)
  return Object.values(store).map(r => {
    // Status is always re-derived fresh from the Address vs. the currently
    // logged-in District/Tehsil/UC — this is the single source of truth
    // (see js/core/location-context.js), so results stay correct even for
    // records saved under an older version of the app / a different login.
    const facilityUc = addressFilterName(r.address);
    const status = addressLocationStatus(r.address); // 'in_uc' | 'out_uc' | 'out_taluka' | 'out_district'
    const outOfUc = status === 'out_uc';
    const outOfTaluka = status === 'out_taluka';
    const outOfDistrict = status === 'out_district';
    const facility = facilityUc || (outOfDistrict ? 'Out From District' : 'Out From Taluka');
    return { ...r, status, outOfUc, outOfTaluka, outOfDistrict, facility, epiNo: r.epiNo || epiMap[r.id] || null };
  });
}

function renderResults(store, keepView){
  const allRecords = normalizeStoredRecords(store);
  // Search pulls from every processed vaccinated record, independent of the
  // UC/facility dropdown filter below.
  allRecordsGlobal = allRecords;

  renderProcessedFileLists();
  updateProcessButtonState();

  if (allRecords.length === 0) {
    if (!keepView) {
      document.getElementById('uploadView').style.display = 'block';
      resultsWrap.style.display = 'none';
    }
    return;
  }

  // populate / preserve UC filter dropdown from Address endings.
  // The filter lists the logged-in Tehsil's own UCs (from the login
  // selection) plus Out From Taluka / Out From District. Falls back to the
  // original Mirpur Mathelo list if no login context is available.
  const ucFilterEl = document.getElementById('ucFilter');
  const facilities = [...new Set(allRecords.map(r => r.facility || 'Out From Taluka'))];
  const loginCtx = window.EPI_LOCATION_CONTEXT;
  const ucOrder = (loginCtx ? loginCtx.ucsInTehsil.slice() : [
    'Dhangro','Wahi Ghoto','Garhi Chakar','Jarwar',
    'Mirpur Mathelo- Mirpur Mathelo 1','Mirpur Mathelo 2',
    'Sono Pitafi','Yaro Lund'
  ]).concat(['Out From Taluka','Out From District']);
  facilities.sort((a,b) => {
    const ia = ucOrder.indexOf(a), ib = ucOrder.indexOf(b);
    return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib);
  });
  const prevSelection = ucFilterEl.value;
  ucFilterEl.innerHTML = `<option value="__all__">All (All UCs Combined)</option>` +
    facilities.map(f => `<option value="${escapeHtml(f)}">${escapeHtml(f)}</option>`).join('');
  if (prevSelection && (prevSelection === '__all__' || facilities.includes(prevSelection))) {
    ucFilterEl.value = prevSelection;
  } else {
    ucFilterEl.value = '__all__';
  }

  const selected = ucFilterEl.value;
  const records = selected === '__all__' ? allRecords : allRecords.filter(r => (r.facility || 'Out From Taluka') === selected);

  // IN UC = Identifier does not contain 'Out of UC', and the address is not
  // Out From Taluka/District either — an address outside the tehsil (or
  // outside the district) is never "in UC".
  inUcRecordsGlobal = records.filter(r => !r.outOfUc && !r.outOfTaluka && !r.outOfDistrict);
  // OUT OF UC page = Out of UC + Out From Taluka + Out From District records.
  outUcRecordsGlobal = records.filter(r => r.outOfUc || r.outOfTaluka || r.outOfDistrict);
  // Out From Taluka / Out From District records stay as separate categories
  // so they can be identified in the detailed list, but they are ALSO
  // included in the OUT OF UC result/dashboard. Never cut or discarded.
  outTalukaRecordsGlobal = records.filter(r => r.outOfTaluka);
  outDistrictRecordsGlobal = records.filter(r => r.outOfDistrict);

  if (!keepView) {
    document.getElementById('uploadView').style.display = 'none'; // step 3: upload menu only lives on page 1
    resultsWrap.style.display = 'block';
    showHubView(); // step 2: after data is (re)loaded, land on the 3-option menu page
  }
}

const AGE_LABELS = { b0: '0–11 Months', b1: '12–23 Months', b2: '24+ Months' };
const EPI_SHORT = {
  BCG:'BCG', HepB:'Hepatitis B', OPV0:'OPV-0', Penta1:'Penta1', Penta2:'Penta2',
  Penta3:'Penta3', Measles1:'Measles 1', Measles2:'Measles 2'
};

function ageBracketKey(am){ return am <= 11 ? 'b0' : (am <= 23 ? 'b1' : 'b2'); }

// TT (Tetanus) rows belong to women and are grouped/counted by dose, never by age.
function recordGroupKey(r){ return isTtRecord(r.doses) ? 'tt' : ageBracketKey(ageMonths(r.dob, r.vaccDate)); }

// full detail list for a group (Inside UC or Outside UC): name, father's name, address, vaccine, date
const lastRendered = {}; // elId -> the exact record list currently shown there (used by the PDF export)

// ONE on-screen result card, used by every list that shows vaccinated
// children/women (vaccine drill-down, search, hidden detail lists).
// The card shows EPI No and QR Code exactly like the Defaulter Children cards.
// opts.shareButton adds a per-child "Share / Download" button (Search Records).
function recordCardHtml(r, idx, opts){
  opts = opts || {};
  const isTt = isTtRecord(r.doses);
  const dv = dateAndVaccinatorText(r);
  const dobText = r.dob ? `${String(r.dob.day).padStart(2,'0')}/${String(r.dob.month).padStart(2,'0')}/${r.dob.year}` : '—';
  const tags = isTt ? classifyTT(r.doses) : classifyEpi(r.doses);
  const vaccineText = tags.length
    ? tags.map(t => isTt ? (TT_LABELS[t] || t) : (EPI_SHORT[t] || t)).join(', ')
    : (isTt ? 'No TT dose recorded' : 'No vaccine recorded');
  const personLabel = isTt ? 'Husband Name' : 'Father Name';
  const shareBtn = opts.shareButton
    ? `<button type="button" class="card-share-btn" data-idx="${idx}">📤 Share / Download this card</button>`
    : '';
  return `<article class="child-card result-card">
      <div class="qr-code"><span class="qr-label">EPI No</span><span class="qr-number">${r.epiNo ? escapeHtml(r.epiNo) : '—'}</span></div>
      <div class="qr-code"><span class="qr-label">QR Code</span><span class="qr-right"><span class="qr-number">${r.id ? escapeHtml(r.id) : '—'}</span>${r.id ? `<button type="button" class="qr-copy-btn" data-qr-copy="${escapeHtml(r.id)}">📋 Copy</button>` : ''}</span></div>
      <div class="result-line"><span class="result-label">Name</span><span class="result-value person-name">${r.name ? escapeHtml(r.name) : 'Name not recorded'}</span></div>
      <div class="result-line"><span class="result-label">${personLabel}</span><span class="result-value">${r.fatherName ? escapeHtml(r.fatherName) : '—'}</span></div>
      <div class="result-line"><span class="result-label">Date of Birth</span><span class="result-value">${dobText}</span></div>
      <div class="result-line"><span class="result-label">Vaccination Date</span><span class="result-value">${escapeHtmlMultiline(dv.dateText)}</span></div>
      <div class="result-address"><span class="result-label">Address</span><span class="result-value">${r.address ? escapeHtml(r.address) : '—'}</span></div>
      <div class="result-vaccine"><span class="result-label">Vaccine</span><span class="result-value">${escapeHtml(vaccineText)}</span></div>
      <div class="result-line"><span class="result-label">Vaccinator</span><span class="result-value">${escapeHtmlMultiline(dv.vaccinatorText)}</span></div>
      <div class="result-meta"><span>No. ${idx + 1}</span><span>${r.outOfDistrict ? 'Out From District' : (r.outOfTaluka ? 'Out From Taluka' : (r.outOfUc ? 'Out of UC' : (isTt ? 'Woman' : AGE_LABELS[ageBracketKey(ageMonths(r.dob, r.vaccDate))])))}</span></div>
      ${shareBtn}
    </article>`;
}

function renderDetailTable(records, elId){
  const list = records.slice();
  const order = { b1: 0, b0: 1, b2: 2, tt: 3 };
  list.sort((a, b) => order[recordGroupKey(a)] - order[recordGroupKey(b)]);
  lastRendered[elId] = list;

  const box = document.getElementById(elId);
  if (!list.length) { box.innerHTML = '<div style="color:var(--muted);">No records in this list.</div>'; return; }
  box.innerHTML = `<div class="child-list">${list.map((r, idx) => recordCardHtml(r, idx)).join('')}</div>`;
}

// one-vaccine drill-down list (and the Search Records results)
function renderDrillTable(records, elId, opts){
  lastRendered[elId] = records.slice();
  const box = document.getElementById(elId);
  if (!records.length) { box.innerHTML = '<div style="color:var(--muted);">No records for this box.</div>'; return; }
  box.innerHTML = `<div class="child-list">${records.map((r, idx) => recordCardHtml(r, idx, opts)).join('')}</div>`;
}

// ---------- page navigation: hub (page2) → group (page3) → drill (page4) ----------
const ALL_VIEW_IDS = ['hubView','groupView','drillView','searchView','dateView','stockView','qrResultView','defaulterChildrenView','defByAddressView','defByVaccineView','defDetailView'];
function hideAllViews(){
  ALL_VIEW_IDS.forEach(id => { const el = document.getElementById(id); if (el) el.style.display = 'none'; });
}

function showHubView(){
  hideAllViews();
  document.getElementById('hubView').style.display = 'block';
  window.scrollTo(0, 0);
}

let currentGroupFacilityLabel = null;

function showGroupView(type, facilityLabel){
  currentGroupType = type;
  currentGroupFacilityLabel = facilityLabel || null;
  // Keep Out From Taluka records included in the OUT OF UC result,
  // and also in this page's Complete Details. Do not remove them anywhere.
  // outUcRecordsGlobal already contains both Out of UC + Out From Taluka records.
  const outRecords = outUcRecordsGlobal;
  const detailRecs = type === 'in' ? inUcRecordsGlobal
    : (type === 'out' ? outRecords
    : inUcRecordsGlobal.concat(outRecords));
  const recs = type === 'in' ? inUcRecordsGlobal
    : (type === 'out' ? outRecords : inUcRecordsGlobal.concat(outRecords));
  // Measles2 must always be counted correctly in the 12-23 and 24+ month
  // boxes — it used to be hidden there (always showing 0) for "IN UC"
  // results specifically, which was wrong: that exclusion only ever made
  // sense for the 0-11 month box (Measles2 isn't part of that schedule —
  // see the unconditional skip in fillDashboard above), not for 12-23/24+.
  const excludeMeasles2FromB = false;
  if (currentGroupFacilityLabel) {
    document.getElementById('groupTitle').textContent = `📋 ${currentGroupFacilityLabel} — Children and Women Results`;
    document.getElementById('groupDetailHeading').innerHTML = `${escapeHtml(currentGroupFacilityLabel)} Complete Details for <span style="font-size:11px;color:var(--muted);">(Name, Father/Husband Name, Address, Vaccine, Date)</span>`;
  } else {
    document.getElementById('groupTitle').textContent = type === 'in'
      ? '📋 IN UC Children and Women Results'
      : (type === 'out' ? '📋 OUT OF UC Children and Women Results' : '📋 All Children and Women Results (IN UC + OUT OF UC Combined)');
    document.getElementById('groupDetailHeading').innerHTML = `Complete Details <span style="font-size:11px;color:var(--muted);">(Name, Father/Husband Name, Address, Vaccine, Date)</span>`;
  }
  fillDashboard(document.getElementById('groupDash'), recs, excludeMeasles2FromB,
    (tag, kind) => showDrillView(tag, kind, excludeMeasles2FromB),
    'Download/Share All Category Work',
    (allCategoryList) => runRecordsExportFlow(visibleTitle('groupTitle', 'Results'), allCategoryList, 'list'));
  renderDetailTable(detailRecs, 'groupDetailTable');
  hideAllViews();
  document.getElementById('groupView').style.display = 'block';
  window.scrollTo(0, 0);
}

function showDrillView(tag, kind, excludeMeasles2FromB){
  const recs = currentGroupType === 'in' ? inUcRecordsGlobal : (currentGroupType === 'out' ? outUcRecordsGlobal : (currentGroupType === 'date' ? dateFilteredRecordsGlobal : Array.from(new Map(inUcRecordsGlobal.concat(outUcRecordsGlobal).map(r => [r.id + '|' + (r.vaccDate?.year||'') + '|' + (r.vaccDate?.month||'') + '|' + (r.vaccDate?.day||''), r])).values())));
  const list = recordsForTag(recs, tag, kind, excludeMeasles2FromB);
  const label = kind === 'tt' ? (TT_LABELS[tag] || tag) : (EPI_LABELS[tag] || tag);
  document.getElementById('drillTitle').textContent = `${label} — Complete List (${list.length})`;
  renderDrillTable(list, 'drillDetailTable');
  hideAllViews();
  document.getElementById('drillView').style.display = 'block';
  window.scrollTo(0, 0);
}

// ---------- PAGE 5: Search — filter across every processed vaccinated record ----------
function showSearchView(){
  hideAllViews();
  document.getElementById('searchView').style.display = 'block';
  window.scrollTo(0, 0);
}
