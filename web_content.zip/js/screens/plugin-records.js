window.WorkspacePluginRecords=(()=>{
  let detailToken=0;
  const n=value=>Number.isFinite(Number(value))?Number(value):0;
  const safe=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const SYSTEMS={
    'Combat & Weapons':['WEAP','AMMO','PROJ','EXPL'],
    'Armor & Equipment':['ARMO','ARMA'],
    'Actors & AI':['NPC_','CREA','ACHR','ACRE','PACK','CSTY','COMB','IDLE','RACE','EYES','HAIR'],
    'Quests & Progression':['QUST','CHAL'],
    'Dialogue & Narrative':['DIAL','INFO'],
    'World & Navigation':['CELL','WRLD','REFR','NAVM','NAVI','DOOR','CONT','ACTI','FURN','STAT','MSTT','TREE','GRAS','LTEX','LAND','WATR','REGN'],
    'Visuals & Weather':['CLMT','WTHR','IMGS','IMAD','EFSH','LGTM','LIGH'],
    'Audio':['SOUN','SNDR'],
    'Items & Economy':['MISC','BOOK','NOTE','KEYM','ALCH','INGR'],
    'Gameplay Effects':['MGEF','SPEL','ENCH'],
    'Character Progression':['PERK','AVIF','CLAS'],
    'Factions & Reputation':['FACT','REPU'],
    'Crafting':['RCPE','RCCT'],
    'Scripts & Global Logic':['SCPT','GLOB','GMST','FLST'],
    'Leveled Lists & Encounters':['LVLI','LVLC','LVLN'],
    'UI & Messages':['MESG'],
    'Caravan & Minigames':['CCRD','CMNY','CDCK']
  };
  const signatureSystem=new Map(Object.entries(SYSTEMS).flatMap(([system,sigs])=>sigs.map(sig=>[sig,system])));
  const classify=signature=>signatureSystem.get(String(signature||'').toUpperCase())||'Other / Unclassified';
  function rows(value){let v=value;for(let i=0;i<4;i++){if(typeof v==='string'){try{v=JSON.parse(v);continue}catch{return[]}}if(Array.isArray(v)&&v.length===1&&(Array.isArray(v[0])||typeof v[0]==='string')){v=v[0];continue}break}if(!Array.isArray(v))v=v&&typeof v==='object'?[v]:[];return v.flat(4).filter(x=>x&&typeof x==='object'&&!Array.isArray(x))}
  function renderProfile(data){
    const state=document.getElementById('mo2RecordState'),plugins=document.getElementById('mo2RecordPlugins'),parsed=document.getElementById('mo2RecordParsed'),shared=document.getElementById('mo2RecordShared'),providers=document.getElementById('mo2RecordProviders'),note=document.getElementById('mo2RecordPreview');if(!state)return;
    const status=String(data?.status||'not_scanned');state.className=`mo2-overlap-state ${status==='ok'?'good':status==='error'?'warn':''}`;state.textContent=status==='ok'?'EVIDENCE READY':status==='running'?'SCANNING':status==='error'?'SCAN ERROR':'NOT SCANNED';
    if(plugins)plugins.textContent=status==='not_scanned'?'—':n(data?.scanned_plugins).toLocaleString();if(parsed)parsed.textContent=status==='not_scanned'?'—':n(data?.parsed_records).toLocaleString();if(shared)shared.textContent=status==='not_scanned'?'—':n(data?.overlap_records).toLocaleString();if(providers)providers.textContent=status==='not_scanned'?'—':n(data?.provider_rows).toLocaleString();
    if(note){if(status==='ok')note.innerHTML='<p>Normalized shared FormID evidence is stored for this MO2 snapshot. System labels below are derived conservatively from record signatures; they are not compatibility verdicts.</p>';else if(status==='error')note.innerHTML=`<p>${String(data?.notes||'Plugin-record scan failed.')}</p>`;else note.innerHTML='<p>No plugin-record scan for the current MO2 snapshot yet.</p>'}
    if(status!=='ok')renderSystems([]);
  }
  function systemSummary(items){
    const map=new Map();
    for(const row of rows(items)){const system=classify(row.record_signature),count=n(row.shared_records);if(!map.has(system))map.set(system,{system,records:0,providers:0,signatures:new Set()});const item=map.get(system);item.records+=count;item.providers+=n(row.provider_rows);item.signatures.add(String(row.record_signature||'????').toUpperCase())}
    return [...map.values()].sort((a,b)=>b.records-a.records||a.system.localeCompare(b.system));
  }
  function renderSystems(items){
    const host=document.getElementById('mo2RecordSystems');if(!host)return;const systems=systemSummary(items);
    if(!systems.length){const fold=document.getElementById('mo2SystemFoldCount');if(fold)fold.textContent='No classification yet';host.innerHTML='<p>No affected-system classification is available until plugin-record evidence exists.</p>';return}
    const fold=document.getElementById('mo2SystemFoldCount');if(fold)fold.textContent=`${systems.length} systems · ${systems.reduce((sum,x)=>sum+x.records,0).toLocaleString()} shared records`;host.innerHTML=`<div class="mo2-system-heading"><b>AFFECTED SYSTEM EVIDENCE</b><small>Signature-derived · evidence only</small></div><div class="mo2-system-grid">${systems.map(x=>`<article><b>${safe(x.system)}</b><span>${x.records.toLocaleString()} shared record${x.records===1?'':'s'}</span><small>${safe([...x.signatures].sort().join(', '))}</small></article>`).join('')}</div>`;
  }
  async function loadSystems(api){try{const p=await api('/api/mo2/plugin-records/signatures');renderSystems(p?.summary?.items||[]);return p?.summary||null}catch{renderSystems([]);return null}}
  async function loadStatus(api){try{const p=await api('/api/mo2/plugin-records/status');renderProfile(p?.records||null);if(String(p?.records?.status||'')==='ok')await loadSystems(api);return p?.records||null}catch{renderProfile(null);return null}}
  async function scan(api){const p=await api('/api/mo2/plugin-records/scan',{method:'POST',body:'{}'});renderProfile(p?.records||null);if(String(p?.records?.status||'')==='ok')await loadSystems(api);return p?.records||null}
  function clearProfile(){renderProfile(null);renderSystems([])}
  function groups(items){const map=new Map();for(const row of rows(items)){const key=String(row.record_key||'');if(!key)continue;if(!map.has(key))map.set(key,{key,signature:row.record_signature||'????',origin:row.origin_plugin||'Unknown',object:row.object_id||'',providers:[]});map.get(key).providers.push(row)}return[...map.values()].sort((a,b)=>b.providers.length-a.providers.length||String(a.origin).localeCompare(String(b.origin))||String(a.object).localeCompare(String(b.object)))}
  function modSystems(groups){const map=new Map();for(const g of groups){const system=classify(g.signature);if(!map.has(system))map.set(system,{system,records:0,signatures:new Set()});const item=map.get(system);item.records++;item.signatures.add(String(g.signature||'????').toUpperCase())}return [...map.values()].sort((a,b)=>b.records-a.records||a.system.localeCompare(b.system))}
  async function loadMod(api,mod,escape){const host=document.getElementById('detailPluginRecords');if(!host||!mod?.id)return;const token=++detailToken;host.innerHTML='<p class="detail-record-empty">Loading plugin-record evidence…</p>';try{const p=await api(`/api/mo2/plugin-records/mod/${Number(mod.id)}`);if(token!==detailToken)return;const e=p?.evidence||{},run=e.run||null;if(!run||String(run.status||'')==='not_scanned'){host.innerHTML='<p class="detail-record-empty">No plugin-record scan exists for the current MO2 snapshot.</p>';return}if(String(run.status)!=='ok'){host.innerHTML=`<p class="detail-record-empty">${escape(run.notes||'Plugin-record evidence is unavailable.')}</p>`;return}const all=groups(e.items),total=n(e.total_records);if(!all.length){host.innerHTML='<p class="detail-record-empty">No shared plugin records were recorded for this matched mod.</p>';return}const shown=all.slice(0,120),systems=modSystems(all);host.innerHTML=`<div class="detail-record-summary"><b>${total.toLocaleString()} shared record${total===1?'':'s'}</b><span>Later plugin load order wins the record · evidence only</span></div><div class="detail-system-summary">${systems.map(x=>`<span><b>${escape(x.system)}</b><small>${x.records.toLocaleString()} record${x.records===1?'':'s'} · ${escape([...x.signatures].sort().join(', '))}</small></span>`).join('')}</div>${shown.map(g=>{const providers=[...g.providers].sort((a,b)=>n(b.plugin_load_order)-n(a.plugin_load_order)),system=classify(g.signature);const markup=providers.slice(0,4).map((p,i)=>`<span class="detail-record-provider${i===0?' winner':''}"><b>${escape(p.plugin_name||'Unknown')}</b><small>Load #${n(p.plugin_load_order)+1}${i===0?' · OBSERVED WINNER':''}</small></span>`).join('');return`<article class="detail-record-row"><div><b>${escape(g.signature)} · ${escape(g.origin)}:${escape(g.object)}</b><small><span class="detail-system-badge">${escape(system)}</span> Signature-derived system · normalized FormID · ${g.providers.length} plugin providers</small></div><div class="detail-record-providers">${markup}${providers.length>4?`<span class="detail-record-provider"><small>+${providers.length-4} more</small></span>`:''}</div></article>`}).join('')}${total>shown.length?`<p class="detail-record-more">Showing ${shown.length.toLocaleString()} of ${total.toLocaleString()} shared records.</p>`:''}`
    }catch(error){if(token===detailToken)host.innerHTML=`<p class="detail-record-empty">${escape(error?.message||'Plugin-record evidence is unavailable.')}</p>`}}
  return{loadStatus,scan,clearProfile,loadMod,classify}
})();
