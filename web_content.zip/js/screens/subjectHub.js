import { el, card, topicTile } from "../ui/widgets.js";
import { loadSubjectRegistry, topicsForSubject, subjectLabel, subjectChipLabel } from "../engines/subjectRegistry.js";
import { MultiSubjectEngine } from "../engines/multiSubjectEngine.js";
import { drawDiagram } from "../ui/render.js";

/**
 * Hub for CAPS subjects other than pure maths (and PS which has its own screens).
 * Lists topics, opens notes + short practice.
 */
export async function SubjectHub(app) {
  await loadSubjectRegistry();
  const sid = app.student?.subject || "maths";
  if (sid === "maths") return app.showLearn();
  if (sid === "physical_sciences") return app.showScience();

  const topics = topicsForSubject(sid) || [];
  const title = subjectChipLabel(sid);
  const body = [
    el("div", { class: "role-subtitle wrap" },
      `${subjectLabel(sid)} · Grade ${app.student?.grade === 0 ? "R" : app.student?.grade} · CAPS-aligned topics.`),
    el("div", { class: "section-eyebrow" }, "TOPICS")
  ];

  if (!topics.length) {
    body.push(card("Coming soon", "Topic list for this subject is being expanded."));
  } else {
    topics.forEach((t) => {
      body.push(topicTile(
        t.icon || "📘",
        t.name,
        "Notes · quiz",
        () => app.navigate("subjectTopic", { subjectId: sid, topicId: t.id }),
        () => app.navigate("subjectQuiz", { subjectId: sid, topicId: t.id })
      ));
    });
  }

  body.push(card("🧠 Mixed quiz", "Random questions from this subject", [
    { label: "START", onClick: () => app.navigate("subjectQuiz", { subjectId: sid, topicId: null }) }
  ]));
  body.push(card("📖 Concepts & definitions", "Key terms and theory for this subject", [
    { label: "START", onClick: () => app.navigate("subjectQuiz", { subjectId: sid, topicId: null, concept: true }) }
  ]));
  body.push(card("✏️ Fillable worksheets", "Journals · tables · label the diagram", [
    { label: "START", onClick: () => app.navigate("worksheet", { subjectId: sid, topicId: null }) }
  ]));
  body.push(card("🔗 Match definitions", "Align terms with their meanings", [
    { label: "START", onClick: () => app.navigate("worksheet", { subjectId: sid, topicId: "definitions" }) }
  ]));
  if (sid === "accounting") {
    body.push(card("📄 Paper-style questions", "CAPS exam-style multi-part problems", [
      { label: "START", onClick: () => app.navigate("worksheet", { subjectId: sid, topicId: null, mode: "paper" }) }
    ]));
  }

  return { title, bottomNavKey: "learn", body };
}

export async function SubjectTopic(app, { subjectId, topicId }) {
  await loadSubjectRegistry();
  const topics = topicsForSubject(subjectId) || [];
  const meta = topics.find((t) => t.id === topicId) || { name: topicId, icon: "📘" };
  const engine = new MultiSubjectEngine(subjectId, app.student?.grade ?? 8);
  const note = engine.notesFor(topicId);

  const body = [
    el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"),
    card("About", note.about),
    card("Key facts", note.key_facts.map((f) => "• " + f).join("\n"))
  ];
  if (note.definitions?.length) {
    const lines = note.definitions.map(([w, d]) => `• ${w} — ${d}`);
    body.push(card("Definitions", lines.join("\n")));
  }
  if (note.formulae?.length) {
    body.push(card("Remember", note.formulae.map((f) => "• " + f).join("\n")));
  }
  if (note.diagram) {
    const holder = el("div", { style: "width:100%;max-width:320px;margin:0.5rem auto;" });
    const c = el("canvas", { style: "display:block;width:100%;height:auto;" });
    holder.appendChild(c);
    body.push(el("div", { class: "card" }, [
      el("div", { class: "role-heading" }, "Diagram"),
      holder
    ]));
    requestAnimationFrame(() => drawDiagram(c, note.diagram, 300, 210));
  }
  if (note.table && note.table.rows) {
    const lines = [];
    if (note.table.cols) lines.push(note.table.cols.join(" | "));
    note.table.rows.forEach((r) => lines.push((Array.isArray(r) ? r : [r]).join(" | ")));
    body.push(card(note.table.title || "Table", lines.join("\n")));
  }
  body.push(card("Practice", "Quiz, concepts, or fillable worksheet for this topic.", [
    { label: "QUIZ", onClick: () => app.navigate("subjectQuiz", { subjectId, topicId }) },
    { label: "CONCEPTS", onClick: () => app.navigate("subjectQuiz", { subjectId, topicId, concept: true }) },
    { label: "WORKSHEET", onClick: () => app.navigate("worksheet", { subjectId, topicId }) }
  ]));

  return { title: `${meta.icon || ""} ${meta.name}`, bottomNavKey: "learn", body };
}

export async function SubjectQuiz(app, { subjectId, topicId = null, concept = false } = {}) {
  const engine = new MultiSubjectEngine(subjectId, app.student?.grade ?? 8);
  const state = { asked: 0, correct: 0, q: null };

  const scoreEl = el("div", { class: "role-subtitle" });
  const topicEl = el("div", { class: "role-heading wrap" });
  const qEl = el("div", { class: "wrap", style: "font-weight:700;white-space:pre-wrap;" });
  const diagramHost = el("div", { style: "max-width:300px;margin:0.4rem auto;" });
  const input = el("input", { type: "text", placeholder: "Your answer", style: "width:100%;" });
  const feedback = el("div", { class: "wrap" });
  const solution = el("div", { class: "card", style: "display:none;" });

  function next() {
    feedback.textContent = "";
    solution.style.display = "none";
    solution.innerHTML = "";
    diagramHost.innerHTML = "";
    input.value = "";
    input.disabled = false;
    const q = concept ? engine.generateConcept(topicId, 2) : engine.generate(topicId, 2);
    state.q = q;
    topicEl.textContent = q.topic_name || q.topic;
    qEl.textContent = q.question;
    if (q.diagram) {
      const c = el("canvas", { style: "display:block;width:100%;height:auto;" });
      diagramHost.appendChild(c);
      requestAnimationFrame(() => drawDiagram(c, q.diagram, 280, 200));
    }
    scoreEl.textContent = `Score ${state.correct} / ${state.asked}`;
  }

  function check() {
    if (!state.q || input.disabled) return;
    const user = input.value.trim();
    if (!user) return;
    state.asked += 1;
    const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
    const u = norm(user), a = norm(state.q.answer);
    const ok = u === a || a.includes(u) || u.includes(a) || String(user).trim() === String(state.q.answer).trim();
    if (ok) {
      state.correct += 1;
      feedback.textContent = "✓ Correct";
      app.student.xp = (app.student.xp || 0) + 6;
    } else {
      feedback.textContent = "✗ Not quite";
    }
    solution.style.display = "";
    solution.appendChild(el("div", { class: "wrap" }, `Answer: ${state.q.answer}`));
    if (state.q.explanation) solution.appendChild(el("div", { class: "role-muted wrap" }, state.q.explanation));
    input.disabled = true;
    app.student.history = app.student.history || [];
    app.student.history.push({ topic: state.q.topic, correct: ok });
    app.saveStudent();
    scoreEl.textContent = `Score ${state.correct} / ${state.asked}`;
  }

  next();
  return {
    title: concept ? "📖 Concepts" : "🧠 Quiz",
    bottomNavKey: "practice",
    body: [
      el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"),
      scoreEl, topicEl, qEl, diagramHost, input,
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn", onClick: check }, "CHECK"),
        el("button", { class: "btn-secondary", onClick: next }, "NEXT →")
      ]),
      feedback, solution
    ]
  };
}
