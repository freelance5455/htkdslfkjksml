import { el, card, topicTile } from "../ui/widgets.js";
import { loadSubjectRegistry, topicsForSubject, subjectLabel, subjectChipLabel } from "../engines/subjectRegistry.js";
import { MultiSubjectEngine } from "../engines/multiSubjectEngine.js";
import { drawDiagram } from "../ui/render.js";
import { listSubjectPapers, generateSubjectPaper } from "../engines/subjectPapersEngine.js";

/**
 * Hub for CAPS subjects other than pure maths (and PS which has its own screens).
 * Lists topics, opens notes + short practice.
 */
export async function SubjectHub(app) {
  await loadSubjectRegistry();
  const sid = app.student?.subject || "maths";
  if (sid === "maths") return app.showLearn();
  if (sid === "physical_sciences") return app.showScience();

  const topics = topicsForSubject(sid) || [];
  const title = subjectChipLabel(sid);
  const body = [
    el("div", { class: "role-subtitle wrap" },
      `${subjectLabel(sid)} · Grade ${app.student?.grade === 0 ? "R" : app.student?.grade} · CAPS-aligned topics.`),
    el("div", { class: "section-eyebrow" }, "TOPICS")
  ];

  if (!topics.length) {
    body.push(card("Coming soon", "Topic list for this subject is being expanded."));
  } else {
    topics.forEach((t) => {
      body.push(topicTile(
        t.icon || "📘",
        t.name,
        "Notes · quiz",
        () => app.navigate("subjectTopic", { subjectId: sid, topicId: t.id }),
        () => app.navigate("subjectQuiz", { subjectId: sid, topicId: t.id })
      ));
    });
  }

  body.push(card("🧠 Mixed quiz", "Random questions from this subject", [
    { label: "START", onClick: () => app.navigate("subjectQuiz", { subjectId: sid, topicId: null }) }
  ]));
  body.push(card("📖 Concepts & definitions", "Key terms and theory for this subject", [
    { label: "START", onClick: () => app.navigate("subjectQuiz", { subjectId: sid, topicId: null, concept: true }) }
  ]));
  body.push(card("✏️ Fillable worksheets", "Journals · tables · label the diagram", [
    { label: "START", onClick: () => app.navigate("worksheet", { subjectId: sid, topicId: null }) }
  ]));
  body.push(card("🔗 Match definitions", "Align terms with their meanings", [
    { label: "START", onClick: () => app.navigate("worksheet", { subjectId: sid, topicId: "definitions" }) }
  ]));
  body.push(card("📄 Paper-style practice", `${subjectLabel(sid)} · multi-part CAPS questions`, [
    { label: "START", onClick: () => app.navigate("worksheet", { subjectId: sid, topicId: null, mode: "paper" }) }
  ]));
  const papers = listSubjectPapers(sid);
  if (papers.length) {
    body.push(el("div", { class: "section-eyebrow" }, "EXAM PAPERS (GENERATIVE CAPS-STYLE)"));
    body.push(el("div", { class: "role-muted wrap", style: "margin-bottom:0.4rem;" },
      "Structures follow CAPS weightings. Questions are generated on device from the learnyZ engines (not scanned copyrighted PDFs)."));
    // Group by template name
    const byName = {};
    papers.forEach((p) => {
      const k = p.name;
      byName[k] = byName[k] || [];
      byName[k].push(p);
    });
    Object.keys(byName).forEach((name) => {
      const years = byName[name];
      body.push(card(name, years.map((y) => String(y.year)).join(" · "),
        years.slice(0, 4).map((y) => ({
          label: String(y.year),
          onClick: () => {
            const paper = generateSubjectPaper(sid, y.templateId, app.student?.grade ?? 12, y.year);
            if (!paper) return;
            try { sessionStorage.setItem("learnyz_subject_paper", JSON.stringify(paper)); } catch (_) {}
            app.navigate("subjectPaperViewer", { subjectId: sid, paperId: paper.id });
          }
        }))
      ));
    });
  }
  body.push(card("📐 Formula sheet", "Subject formulae and periodic table (where relevant)", [
    { label: "OPEN", onClick: () => app.navigate("referenceSheets", { subjectId: sid }) }
  ]));

  return { title, bottomNavKey: "learn", body };
}

export async function SubjectTopic(app, { subjectId, topicId }) {
  await loadSubjectRegistry();
  const topics = topicsForSubject(subjectId) || [];
  const meta = topics.find((t) => t.id === topicId) || { name: topicId, icon: "📘" };
  const engine = new MultiSubjectEngine(subjectId, app.student?.grade ?? 8);
  const note = engine.notesFor(topicId);

  const body = [
    el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"),
    card("About", note.about),
    card("Key facts", (note.key_facts || []).map((f) => "• " + f).join("\n"))
  ];
  if (note.method) {
    body.push(card("How to approach", note.method));
  }
  if (note.common_mistakes?.length) {
    body.push(card("Common mistakes", note.common_mistakes.map((m) => "• " + m).join("\n")));
  }
  if (note.worked_examples?.length) {
    body.push(card("Worked examples", note.worked_examples.map((m) => "• " + m).join("\n")));
  }
  if (note.definitions?.length) {
    const lines = note.definitions.map(([w, d]) => `• ${w} — ${d}`);
    body.push(card("Definitions", lines.join("\n")));
  }
  if (note.formulae?.length) {
    body.push(card("Remember", note.formulae.map((f) => "• " + f).join("\n")));
  }
  if (note.diagram) {
    const holder = el("div", { style: "width:100%;max-width:320px;margin:0.5rem auto;" });
    const c = el("canvas", { style: "display:block;width:100%;height:auto;" });
    holder.appendChild(c);
    body.push(el("div", { class: "card" }, [
      el("div", { class: "role-heading" }, "Diagram"),
      holder
    ]));
    requestAnimationFrame(() => drawDiagram(c, note.diagram, 300, 210));
  }
  function fmtTable(table) {
    const cols = table.cols || [];
    const lines = [];
    if (cols.length) {
      lines.push(cols.join(" · "));
      lines.push("─".repeat(Math.min(48, cols.join(" · ").length + 4)));
    }
    (table.rows || []).forEach((r) => {
      const cells = Array.isArray(r) ? r : [r];
      lines.push(cells.join(" · "));
    });
    return lines.join("\n");
  }
  if (note.table && note.table.rows) {
    body.push(card(note.table.title || "Table", fmtTable(note.table)));
  }
  if (note.tables && Array.isArray(note.tables)) {
    note.tables.forEach((t) => {
      if (t && t.rows) body.push(card(t.title || "Table", fmtTable(t)));
    });
  }
  body.push(card("Practice", "Quiz, concepts, or fillable worksheet for this topic.", [
    { label: "QUIZ", onClick: () => app.navigate("subjectQuiz", { subjectId, topicId }) },
    { label: "CONCEPTS", onClick: () => app.navigate("subjectQuiz", { subjectId, topicId, concept: true }) },
    { label: "WORKSHEET", onClick: () => app.navigate("worksheet", { subjectId, topicId }) }
  ]));

  return { title: `${meta.icon || ""} ${meta.name}`, bottomNavKey: "learn", body };
}

export async function SubjectQuiz(app, { subjectId, topicId = null, concept = false } = {}) {
  const engine = new MultiSubjectEngine(subjectId, app.student?.grade ?? 12);
  const state = { asked: 0, correct: 0, q: null, streak: 0, target: 12, seen: new Set() };

  const scoreEl = el("div", { class: "quiz-score" });
  const progressFill = el("div", { class: "quiz-progress-fill", style: "width:0%" });
  const progress = el("div", { class: "quiz-progress" }, [progressFill]);
  const topicEl = el("div", { class: "quiz-topic" });
  const qCard = el("div", { class: "quiz-question-card" });
  const qEl = el("div", { class: "quiz-question-text" });
  const diagramHost = el("div", { class: "quiz-diagram" });
  qCard.appendChild(topicEl);
  qCard.appendChild(qEl);
  qCard.appendChild(diagramHost);
  const input = el("input", {
    type: "text",
    class: "quiz-input",
    placeholder: "Type your answer…",
    autocomplete: "off"
  });
  const feedback = el("div", { class: "quiz-feedback" });
  const solution = el("div", { class: "quiz-solution", style: "display:none;" });

  function updateScore() {
    const pct = state.asked ? Math.round((state.correct / state.asked) * 100) : 0;
    scoreEl.innerHTML = `<span class="quiz-score-main">${state.correct} / ${state.asked}</span>` +
      `<span class="quiz-score-meta">${pct}% · streak ${state.streak}</span>`;
    progressFill.style.width = `${Math.min(100, Math.round((state.asked / state.target) * 100))}%`;
  }

  function next() {
    feedback.textContent = "";
    feedback.className = "quiz-feedback";
    solution.style.display = "none";
    solution.innerHTML = "";
    diagramHost.innerHTML = "";
    input.value = "";
    input.disabled = false;
    input.classList.remove("quiz-input-correct", "quiz-input-wrong");
    // Scale difficulty with progress; prefer unseen questions
    const diff = state.asked < 3 ? 1 : state.asked < 7 ? 2 : state.asked < 10 ? 3 : 4;
    let q = null;
    for (let attempt = 0; attempt < 8; attempt++) {
      q = concept ? engine.generateConcept(topicId, diff) : engine.generate(topicId, diff);
      const key = (q && q.question) || "";
      if (key && !state.seen.has(key)) {
        state.seen.add(key);
        break;
      }
    }
    state.q = q;
    topicEl.textContent = ((q.topic_name || q.topic || "") + (concept ? " · concept" : " · practice")).replaceAll("_", " ");
    qEl.textContent = q.question;
    if (q.diagram) {
      const c = el("canvas", { style: "display:block;width:100%;height:auto;max-width:300px;margin:0 auto;" });
      diagramHost.appendChild(c);
      requestAnimationFrame(() => drawDiagram(c, q.diagram, 280, 200));
    }
    updateScore();
    setTimeout(() => input.focus(), 50);
  }

  function check() {
    if (!state.q || input.disabled) return;
    const user = input.value.trim();
    if (!user) return;
    state.asked += 1;
    const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\s./°×÷+\-]/g, " ").replace(/\s+/g, " ").trim();
    const u = norm(user), a = norm(state.q.answer);
    const ok = u === a || a.includes(u) || u.includes(a) || String(user).trim() === String(state.q.answer).trim();
    if (ok) {
      state.correct += 1;
      state.streak += 1;
      feedback.textContent = state.streak >= 3 ? `✓ Correct · streak ${state.streak}!` : "✓ Correct";
      feedback.className = "quiz-feedback quiz-feedback-ok";
      input.classList.add("quiz-input-correct");
      app.student.xp = (app.student.xp || 0) + 6 + Math.min(4, state.streak);
    } else {
      state.streak = 0;
      feedback.textContent = "✗ Not quite — see solution";
      feedback.className = "quiz-feedback quiz-feedback-bad";
      input.classList.add("quiz-input-wrong");
    }
    solution.style.display = "";
    solution.appendChild(el("div", { class: "quiz-solution-answer" }, `Answer: ${state.q.answer}`));
    if (state.q.explanation) {
      solution.appendChild(el("div", { class: "quiz-solution-explain" }, state.q.explanation));
    }
    input.disabled = true;
    app.student.history = app.student.history || [];
    app.student.history.push({ topic: state.q.topic, correct: ok });
    app.saveStudent();
    updateScore();
  }

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      if (input.disabled) next();
      else check();
    }
  });

  next();
  return {
    title: concept ? "📖 Concepts" : "🧠 Quiz",
    bottomNavKey: "practice",
    body: [
      el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"),
      scoreEl,
      progress,
      qCard,
      input,
      el("div", { class: "btn-row quiz-actions" }, [
        el("button", { class: "btn", onClick: check }, "CHECK"),
        el("button", { class: "btn-secondary", onClick: next }, "NEXT →")
      ]),
      feedback,
      solution
    ]
  };
}


/** View a generated subject paper — same exam layout as mathematics papers. */
export async function SubjectPaperViewer(app, params = {}) {
  let paper = null;
  try {
    paper = JSON.parse(sessionStorage.getItem("learnyz_subject_paper") || "null");
  } catch { paper = null; }
  if (!paper || !paper.questions?.length) {
    return {
      title: "Paper",
      body: [
        el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Back"),
        card("No paper loaded", "Generate a paper from the subject hub.")
      ]
    };
  }

  let showingMemo = false;
  const sheet = el("div", {
    class: "paper-sheet",
    style: "background:#fff;border-radius:12px;padding:0.75rem 0.9rem;border:1px solid #e8ecf2;"
  });
  const memoBtn = el("button", { class: "btn", onClick: toggleMemo }, "VIEW SOLUTIONS");
  const statusEl = el("div", { class: "role-muted wrap", style: "margin:0.25rem 0 0.5rem;" });

  function renderSheet() {
    sheet.innerHTML = "";
    const cover = el("div", {
      style: "border-bottom:2px solid #1e293b;padding-bottom:0.55rem;margin-bottom:0.75rem;"
    });
    cover.appendChild(el("div", {
      style: "font-weight:800;font-size:1.05rem;"
    }, paper.name || paper.title || "Subject paper"));
    cover.appendChild(el("div", {
      class: "role-muted",
      style: "margin-top:0.2rem;font-size:0.85rem;"
    }, `${paper.year || ""} · ${paper.period || ""} · ${paper.marks || "?"} marks · ${paper.time_minutes || 150} min`));
    if (paper.source) {
      cover.appendChild(el("div", {
        class: "role-muted",
        style: "font-size:0.78rem;margin-top:0.25rem;"
      }, paper.source));
    }
    sheet.appendChild(cover);

    let lastSection = "";
    paper.questions.forEach((q, qi) => {
      const section = q.section || q.sectionLabel || "";
      if (section && section !== lastSection) {
        sheet.appendChild(el("div", {
          class: "section-eyebrow",
          style: "margin:0.85rem 0 0.4rem;font-weight:800;font-size:0.95rem;color:#0f172a;border-top:1px solid #e2e8f0;padding-top:0.55rem;"
        }, section));
        lastSection = section;
      }
      const marks = q.marks != null ? q.marks : 1;
      const row = el("div", {
        class: "caps-q-row",
        style: "display:flex;gap:0.5rem;align-items:flex-start;margin:0.55rem 0;padding-bottom:0.4rem;border-bottom:1px solid #f0f0f0;"
      });
      const left = el("div", { style: "flex:1;min-width:0;" });
      const qNum = q.number != null ? `QUESTION ${q.number}` : (q.partLabel || `Q${qi + 1}`);
      left.appendChild(el("div", { style: "font-weight:700;margin-bottom:0.15rem;" }, qNum));
      if (q.topic_name || q.topic) {
        left.appendChild(el("div", {
          class: "role-muted",
          style: "font-size:0.8rem;margin-bottom:0.25rem;"
        }, String(q.topic_name || q.topic).replaceAll("_", " ")));
      }
      left.appendChild(el("div", {
        class: "wrap",
        style: "white-space:pre-wrap;line-height:1.45;font-weight:550;"
      }, q.question || ""));
      if (q.parts && Array.isArray(q.parts)) {
        q.parts.forEach((p) => {
          left.appendChild(el("div", {
            class: "wrap",
            style: "margin:0.25rem 0 0.25rem 0.5rem;white-space:pre-wrap;"
          }, String(p)));
        });
      }
      if (q.diagram) {
        const host = el("div", { style: "max-width:300px;margin:0.4rem 0;" });
        const c = el("canvas", { style: "display:block;width:100%;height:auto;" });
        host.appendChild(c);
        left.appendChild(host);
        requestAnimationFrame(() => {
          try { drawDiagram(c, q.diagram, 280, 200); } catch (_) {}
        });
      }
      if (showingMemo) {
        left.appendChild(el("div", {
          class: "solution-block",
          style: "margin-top:0.45rem;padding:0.5rem 0.6rem;background:#f3faf6;border-left:3px solid #0a7;border-radius:6px;"
        }, [
          el("div", { style: "font-weight:700;color:#0a7;margin-bottom:0.2rem;" }, "Solution"),
          el("div", { class: "wrap", style: "white-space:pre-wrap;" },
            (q.explanation || ("Answer: " + (q.answer != null ? q.answer : "—"))))
        ]));
      }
      const right = el("div", {
        style: "flex-shrink:0;font-weight:600;color:#64748b;min-width:2.2rem;text-align:right;"
      }, `(${marks})`);
      row.append(left, right);
      sheet.appendChild(row);
    });
  }

  function toggleMemo() {
    showingMemo = !showingMemo;
    memoBtn.textContent = showingMemo ? "HIDE SOLUTIONS" : "VIEW SOLUTIONS";
    statusEl.textContent = showingMemo
      ? `Full paper · solutions visible for all ${paper.questions.length} question(s).`
      : `Full paper · ${paper.questions.length} question(s) · ${paper.marks || "?"} marks · VIEW SOLUTIONS for formal working.`;
    renderSheet();
  }

  statusEl.textContent = `Full paper · ${paper.questions.length} question(s) · ${paper.marks || "?"} marks · VIEW SOLUTIONS for formal working.`;
  renderSheet();

  return {
    title: "📄 Exam paper",
    bottomNavKey: "papers",
    body: [
      el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"),
      el("div", { class: "btn-row", style: "flex-wrap:wrap;margin:0.35rem 0;" }, [memoBtn]),
      statusEl,
      sheet
    ]
  };
}
