import { el, card, showAlert } from "../ui/widgets.js";
import { PaperEngine, PAPER_TYPES, DIFFICULTY_MAP, PAST_PAPER_PERIODS } from "../engines/paperEngine.js";
import { GradeManager } from "../engines/gradeManager.js";
import { drawDiagram, exportPaperImage } from "../ui/render.js";

const pe = new PaperEngine();

function labelForQuestion(q) {
  if (q.partLabel) return q.partLabel;
  if (q.displayNumber) return q.displayNumber;
  if (q.qMain != null && q.qPart != null) return `${q.qMain}.${q.qPart}`;
  return String(q.number ?? "");
}

/** Format question body in PDF style. */
function bodyForQuestion(q) {
  if (q.questionDisplay) return q.questionDisplay;
  if (q.parts && Array.isArray(q.parts) && q.parts.length) {
    return q.parts.map((p) => {
      if (typeof p === "string") return p;
      const lab = p.label ? p.label + " " : "";
      return lab + (p.prompt || p.question || "");
    }).join("\n\n");
  }
  return String(q.question || q.prompt || "");
}

export async function Papers(app, { view = "hub" } = {}) {
  const grade = app.student.grade ?? 10;
  let gm;
  try {
    gm = new GradeManager(grade);
  } catch {
    gm = null;
  }
  const gradeTopics = gm ? gm.topics() : [];

  // ── HUB ────────────────────────────────────────────────────────────────
  if (view === "hub" || !view) {
    const sub = app.student?.subject || "mathematical_literacy";
    const isPS = false;
    const isMaths = false;
    // All G10 subjects use subject paper paths
    const multiPaperSubjects = new Set(["mathematical_literacy", "business_studies", "tourism"]);
    if (multiPaperSubjects.has(sub)) {
      const labels = {
        mathematical_literacy: "Mathematical Literacy",
        business_studies: "Business Studies",
        tourism: "Tourism"
      };
      const label = labels[sub] || sub.replaceAll("_", " ");
      const body = [
        el("div", { class: "wrap role-muted", style: "margin-bottom:0.75rem;" },
          label + " papers — exam-style multi-part questions generated from CAPS topic banks, with per-question solutions."),
        card("📚 Past papers",
          "Full " + label + " papers by year (CAPS-style).",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "subject_past" }) }]),
        card("🎯 Topic practice",
          "Multi-part question for one " + label + " topic.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "subject_topics" }) }]),
        card("✏️ Generate paper",
          "Build a full " + label + " paper now.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "subject_generate" }) }]),
        ...(sub === "accounting" ? [
          card("📒 Journals & worksheets",
            "CRJ · CPJ · DJ · bank reconciliation · VAT · trial balance — fill the blanks.",
            [{ label: "OPEN", onClick: () => app.navigate("worksheet", { subjectId: sub }) }])
        ] : []),
        card("📂 Your papers",
          "Papers saved on this device.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "yours" }) }])
      ];
      return { title: "📝 " + label + " Papers", bottomNavKey: "papers", body };
    }
    if (isPS) {
      const body = [
        el("div", { class: "wrap role-muted", style: "margin-bottom:0.75rem;" },
          "Physical Sciences papers — Paper 1 Physics and Paper 2 Chemistry. Generated from CAPS engines with diagrams and formal solutions."),
        card("📘 Paper 1 — Physics",
          "Mechanics · waves · electricity & magnetism · multi-part exam blocks.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "ps_paper1" }) }]),
        card("🧪 Paper 2 — Chemistry",
          "Bonding · quantitative · energy · acids & bases · redox.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "ps_paper2" }) }]),
        card("🎯 Topic practice",
          "Full multi-part question for one Physical Sciences topic.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "ps_topics" }) }]),
        card("🧠 Quiz mode",
          "Pick a topic and answer short questions with instant feedback.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "ps_quiz" }) }]),
        card("📂 Your papers",
          "Generated PS papers saved on this device.",
          [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "yours" }) }])
      ];
      return { title: "📝 PS Papers", bottomNavKey: "papers", body };
    }
    const body = [
      el("div", { class: "wrap role-muted", style: "margin-bottom:0.75rem;" },
        "Choose how you want to work with papers. Past papers and topic practice use the CAPS engines; each question can include a redrawn diagram."),
      card("📚 Past papers",
        "Pick a season, swipe a year, open Paper 1 or 2. Full exam-style questions with solutions.",
        [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "past" }) }]),
      card("📂 Your papers",
        "Papers you have generated or saved in this browser.",
        [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "yours" }) }]),
      card("✏️ Generate papers",
        "Build a custom paper by type, term, difficulty and topics.",
        [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "generate" }) }]),
      card("🎯 Topic practice",
        "Pick one CAPS topic and attempt a full set of questions for that topic only.",
        [{ label: "OPEN", onClick: () => app.navigate("papers", { view: "topics" }) }])
    ];
    return { title: "📝 Papers", bottomNavKey: "papers", body };
  }

  // ── PAST PAPERS ────────────────────────────────────────────────────────
  if (view === "past") {
    const pastBody = [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← Papers menu"),
      el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
        "Choose a period, then a paper. Same layout as Learn and Workshops.")
    ];

    if (!(grade === 12 || grade === 11 || grade === 10)) {
      pastBody.push(card("FET only", "Past papers are available for Grades 10–12. Use Generate papers for other grades."));
      return { title: "📚 Past papers", bottomNavKey: "papers", body: pastBody };
    }

    let groups = {};
    try { groups = await pe.listCuratedByPeriod(); } catch { groups = {}; }

    const periodMeta = {
      March: { icon: "🌱", blurb: "Term 1 tests" },
      June: { icon: "☀️", blurb: "Mid-year exams" },
      September: { icon: "🍂", blurb: "Trials & spring tests" },
      November: { icon: "📘", blurb: "Final exams" },
      Exemplar: { icon: "⭐", blurb: "Exemplar-style" },
      Activities: { icon: "✏️", blurb: "Short topic drills" }
    };

    const detailHost = el("div", {});

    async function openSample(s) {
      const paper = await pe.buildCuratedPaper(s.id, app.student);
      if (!paper) return showAlert("Error", "Could not load this paper.");
      sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper));
      app.showPaperViewer(paper.paper_id, { curated: true });
    }

    function showPeriod(period) {
      detailHost.innerHTML = "";
      const samples = (groups[period] || []).slice().sort((a, b) => (b.year || 0) - (a.year || 0));
      const meta = periodMeta[period] || { icon: "📄", blurb: "" };
      detailHost.appendChild(el("div", { class: "section-eyebrow" }, `${meta.icon} ${period}`));
      detailHost.appendChild(el("div", { class: "wrap role-muted", style: "margin-bottom:0.5rem;" }, meta.blurb));

      if (!samples.length) {
        detailHost.appendChild(card("No papers yet", "Try another period."));
        return;
      }

      // Group by year using normal section cards
      const byYear = {};
      samples.forEach((s) => {
        const y = s.year || "General";
        (byYear[y] = byYear[y] || []).push(s);
      });
      const yearKeys = Object.keys(byYear).sort((a, b) => {
        if (a === "General") return 1;
        if (b === "General") return -1;
        return Number(b) - Number(a);
      });

      yearKeys.forEach((y) => {
        detailHost.appendChild(el("div", {
          class: "section-eyebrow",
          style: "margin-top:0.65rem;"
        }, y === "General" ? "Papers" : String(y)));
        byYear[y].forEach((s) => {
          const label = s.title || s.id;
          const sub = `${s.time_minutes || 60} min · full multi-part`;
          detailHost.appendChild(card(label, sub, [
            { label: "START", onClick: () => openSample(s) }
          ]));
        });
      });
    }

    // Period list — same card language as Learn / Workshops
    for (const period of PAST_PAPER_PERIODS) {
      const samples = groups[period] || [];
      if (!samples.length) continue;
      const meta = periodMeta[period] || { icon: "📄", blurb: "" };
      const years = [...new Set(samples.map((s) => s.year).filter(Boolean))].sort((a, b) => b - a);
      const sub = years.length
        ? `${meta.blurb} · ${years[0]}${years.length > 1 ? "–" + years[years.length - 1] : ""}`
        : `${meta.blurb} · ${samples.length} sets`;
      pastBody.push(card(`${meta.icon} ${period}`, sub, [
        { label: "OPEN", onClick: () => showPeriod(period) }
      ]));
    }
    pastBody.push(detailHost);
    return { title: "📚 Past papers", bottomNavKey: "papers", body: pastBody };
  }

  // ── YOUR PAPERS ────────────────────────────────────────────────────────
  if (view === "yours") {
    const library = pe.listPapers(app.student.code);
    const yourBody = [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← Papers menu")
    ];
    if (library.length) {
      library.slice(0, 30).forEach((p) => {
        yourBody.push(
          card(
            `${p.type || "Paper"} — Term ${p.term ?? "—"}`,
            `${p.marks || 0} marks · ${p.questions?.length || 0} questions · ${(p.created_at || "").slice(0, 16).replace("T", " ")}`,
            [{ label: "VIEW PAPER", onClick: () => app.showPaperViewer(p.paper_id) }]
          )
        );
      });
    } else {
      yourBody.push(card("No papers yet", "Generate a paper or open a curated past paper."));
    }
    return { title: "📂 Your papers", bottomNavKey: "papers", body: yourBody };
  }

  // ── GENERATE ───────────────────────────────────────────────────────────
  if (view === "generate") {
    const typeSelect = el("select", {}, PAPER_TYPES.map((t) => el("option", { value: t }, t)));
    typeSelect.value = "Past Paper Style";
    const termSelect = el("select", {}, [1, 2, 3, 4].map((t) => el("option", { value: t }, `Term ${t}`)));
    termSelect.value = String(app.student.term || 1);
    const diffSelect = el("select", {}, Object.keys(DIFFICULTY_MAP).map((d) => el("option", { value: d }, d)));
    diffSelect.value = "Standard";
    const countInput = el("input", { type: "number", min: "5", max: "40", value: grade >= 10 ? "12" : "15" });
    const timeInput = el("input", { type: "number", min: "10", max: "180", value: grade >= 10 ? "60" : "45" });

    const selectedTopics = new Set();
    const topicWrap = el(
      "div",
      { class: "topic-list" },
      gradeTopics.map((t) => {
        const cb = el("input", { type: "checkbox" });
        cb.addEventListener("change", () => {
          if (cb.checked) selectedTopics.add(t.id);
          else selectedTopics.delete(t.id);
        });
        return el("label", { class: "topic-check" }, [cb, `${t.icon || "📘"} ${t.name}`]);
      })
    );

    async function generate() {
      let paper;
      const chosen = [...selectedTopics];
      try {
        paper = pe.generate(app.student, {
          paperType: typeSelect.value,
          term: parseInt(termSelect.value, 10),
          difficulty: diffSelect.value,
          count: parseInt(countInput.value, 10) || 15,
          timeMinutes: parseInt(timeInput.value, 10) || 45,
          topics: chosen.length ? chosen : null
        });
      } catch (e) {
        return showAlert("Generation Error", String(e.message || e));
      }
      app.saveStudent();
      await showAlert(
        "Paper Generated",
        `✓ ${paper.type} — Term ${paper.term}\n\nID: ${paper.paper_id}\nMarks: ${paper.marks}\nQuestions: ${paper.questions.length}\n\nSaved under Your papers.`
      );
      app.showPaperViewer(paper.paper_id);
    }

    return {
      title: "✏️ Generate papers",
      bottomNavKey: "papers",
      body: [
        el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← Papers menu"),
        el("label", { class: "field-label" }, "Paper type"),
        typeSelect,
        el("label", { class: "field-label" }, "Term"),
        termSelect,
        el("label", { class: "field-label" }, "Difficulty"),
        diffSelect,
        el("label", { class: "field-label" }, "Number of questions"),
        countInput,
        el("label", { class: "field-label" }, "Time limit (minutes)"),
        timeInput,
        el("label", { class: "field-label" }, "Topics (optional for Past Paper Style)"),
        topicWrap,
        el("button", { class: "btn", onClick: generate }, "📝 GENERATE PAPER")
      ]
    };
  }

  // ── TOPIC PRACTICE ─────────────────────────────────────────────────────
  if (view === "topics") {
    const body = [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← Papers menu"),
      el("div", { class: "wrap role-muted", style: "margin:0.5rem 0 0.75rem;" },
        "Choose Paper 1 or Paper 2, then a topic. You will see a full multi-part question in CAPS exam format.")
    ];
    const p1 = gradeTopics.filter((t) => (t.paper || 1) === 1);
    const p2 = gradeTopics.filter((t) => t.paper === 2);
    // If no paper tags, split by known sets
    const P1_IDS = new Set(["equations_inequalities","exponents_surds","number_patterns","functions_graphs","finance_11","probability_11"]);
    const list1 = p1.length ? p1 : gradeTopics.filter((t) => P1_IDS.has(t.id));
    const list2 = p2.length ? p2 : gradeTopics.filter((t) => !P1_IDS.has(t.id));

    async function startTopic(topicId) {
      const eng = app.questionEngine();
      let questions = [];
      if (typeof eng.generatePaperParts === "function") {
        questions = eng.generatePaperParts(topicId, 2) || [];
      }
      if (!questions.length) {
        for (let i = 0; i < 5; i++) {
          const q = eng.generate(topicId, 2);
          q.partLabel = `1.${i + 1}`;
          q.capsFormat = true;
          questions.push(q);
        }
      }
      questions.forEach((q, i) => {
        q.sectionLabel = q.sectionLabel || q.section || `QUESTION 1`;
        q.displayNumber = q.partLabel || String(i + 1);
      });
      const totalMarks = questions.reduce((s, q) => s + (q.marks || 2), 0);
      const paper = {
        paper_id: "topic_" + topicId + "_" + Date.now().toString(36),
        curated: true,
        generated: true,
        grade: grade,
        grade_label: "Grade " + grade,
        subject: "Mathematics",
        type: "Topic Practice",
        title: (gradeTopics.find((x) => x.id === topicId) || {}).name || topicId,
        period: "Topic practice",
        marks: totalMarks,
        time_minutes: 40,
        questions,
        topics: [topicId]
      };
      sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper));
      app.showPaperViewer(paper.paper_id, { curated: true });
    }

    body.push(el("div", { class: "section-eyebrow" }, "PAPER 1"));
    body.push(el("div", { class: "wrap role-muted", style: "margin-bottom:0.4rem;" },
      "Algebra · patterns · functions · finance · probability"));
    list1.forEach((t) => {
      body.push(card(`${t.icon || "📘"} ${t.name}`, "Full multi-part CAPS question", [
        { label: "START", onClick: () => startTopic(t.id) }
      ]));
    });
    body.push(el("div", { class: "section-eyebrow", style: "margin-top:1rem;" }, "PAPER 2"));
    body.push(el("div", { class: "wrap role-muted", style: "margin-bottom:0.4rem;" },
      "Statistics · analytical geometry · trigonometry · Euclidean geometry · measurement"));
    list2.forEach((t) => {
      body.push(card(`${t.icon || "📘"} ${t.name}`, "Full multi-part CAPS question", [
        { label: "START", onClick: () => startTopic(t.id) }
      ]));
    });
    if (!list1.length && !list2.length) {
      body.push(card("No topics", "Topics load for your grade after login."));
    }
    return { title: "🎯 Topic practice", bottomNavKey: "papers", body };
  }


  // ── PS PAPER 1 / PAPER 2 (generated full paper) ─────────────────────────
  if (view === "ps_paper1" || view === "ps_paper2") {
    const paperNo = view === "ps_paper1" ? 1 : 2;
    const { PhysSciEngine } = await import("../engines/physSciEngine.js");
    const { allPhysSciTopics } = await import("../engines/contentLoader.js");
    const engine = new PhysSciEngine();
    const topics = (await allPhysSciTopics()).filter((t) => t.paper === paperNo);
    const body = [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← PS Papers"),
      el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
        paperNo === 1
          ? "Paper 1 — Physics (150 marks style). Each START builds a unique multi-part paper from the engines."
          : "Paper 2 — Chemistry (150 marks style). Generated questions with solutions.")
    ];

    async function buildPsPaper(selectedIds) {
      const questions = [];
      let qMain = 1;
      for (const id of selectedIds) {
        const parts = engine.generatePaperParts(id, 2);
        parts.forEach((p) => {
          p.qMain = qMain;
          if (!p.sectionLabel) p.sectionLabel = `QUESTION ${qMain}`;
          questions.push(p);
        });
        qMain += 1;
      }
      const paper = {
        paper_id: `ps_p${paperNo}_${Date.now()}`,
        type: `Physical Sciences Paper ${paperNo}`,
        period: paperNo === 1 ? "Physics" : "Chemistry",
        subject: "physical_sciences",
        grade: 11,
        marks: questions.reduce((s, q) => s + (q.marks || 3), 0),
        time_minutes: 180,
        questions,
        created_at: new Date().toISOString()
      };
      try {
        const list = JSON.parse(localStorage.getItem("learnly:papers") || "[]");
        list.unshift({ paper_id: paper.paper_id, type: paper.type, marks: paper.marks, created_at: paper.created_at });
        localStorage.setItem("learnly:papers", JSON.stringify(list.slice(0, 40)));
        sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper));
      } catch { /* ignore */ }
      app.showPaperViewer(paper.paper_id, { curated: true });
    }

    body.push(card(
      `Full Paper ${paperNo}`,
      `Build a complete paper using all ${topics.length} topics in this paper.`,
      [{ label: "GENERATE FULL", onClick: () => buildPsPaper(topics.map((t) => t.id)) }]
    ));
    body.push(el("div", { class: "section-eyebrow", style: "margin-top:0.75rem;" }, "OR START BY TOPIC"));
    topics.forEach((t) => {
      body.push(card(`${t.icon || "🔬"} ${t.name}`, t.area || "", [
        { label: "START", onClick: () => buildPsPaper([t.id]) }
      ]));
    });
    return { title: paperNo === 1 ? "📘 PS Paper 1" : "🧪 PS Paper 2", bottomNavKey: "papers", body };
  }

  // ── PS TOPIC PRACTICE ───────────────────────────────────────────────────
  if (view === "ps_topics") {
    const { PhysSciEngine } = await import("../engines/physSciEngine.js");
    const { allPhysSciTopics } = await import("../engines/contentLoader.js");
    const engine = new PhysSciEngine();
    const topics = await allPhysSciTopics();
    const p1 = topics.filter((t) => t.paper === 1);
    const p2 = topics.filter((t) => t.paper === 2);
    const body = [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← PS Papers"),
      el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
        "One full multi-part question block per topic — same formal layout as maths topic practice.")
    ];

    async function startTopic(id) {
      const parts = engine.generatePaperParts(id, 2);
      const paper = {
        paper_id: `ps_topic_${id}_${Date.now()}`,
        type: "Topic Practice",
        period: "Topic practice",
        subject: "physical_sciences",
        grade: 11,
        marks: parts.reduce((s, q) => s + (q.marks || 3), 0),
        questions: parts,
        created_at: new Date().toISOString()
      };
      sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper));
      app.showPaperViewer(paper.paper_id, { curated: true });
    }

    body.push(el("div", { class: "section-eyebrow" }, "PAPER 1 — PHYSICS"));
    p1.forEach((t) => body.push(card(`${t.icon || "🔬"} ${t.name}`, "Multi-part exam block", [
      { label: "START", onClick: () => startTopic(t.id) }
    ])));
    body.push(el("div", { class: "section-eyebrow", style: "margin-top:0.85rem;" }, "PAPER 2 — CHEMISTRY"));
    p2.forEach((t) => body.push(card(`${t.icon || "🧪"} ${t.name}`, "Multi-part exam block", [
      { label: "START", onClick: () => startTopic(t.id) }
    ])));
    return { title: "🎯 PS Topic practice", bottomNavKey: "papers", body };
  }

  // ── PS QUIZ MODE (topic select) ─────────────────────────────────────────
  if (view === "ps_quiz") {
    const { allPhysSciTopics } = await import("../engines/contentLoader.js");
    const topics = await allPhysSciTopics();
    const body = [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← PS Papers"),
      el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
        "Select a topic for short quiz-style questions with instant feedback."),
      el("div", { class: "section-eyebrow" }, "CHOOSE A TOPIC")
    ];
    topics.forEach((t) => {
      body.push(card(`${t.icon || "🔬"} ${t.name}`, `Paper ${t.paper} · ${t.area || ""}`, [
        { label: "QUIZ", onClick: () => app.navigate("psQuizSession", { topicId: t.id }) }
      ]));
    });
    body.push(card("🎲 Mix all topics", "Random questions from every PS topic", [
      { label: "QUIZ", onClick: () => app.navigate("psQuizSession", { topicId: null }) }
    ]));
    return { title: "🧠 PS Quiz", bottomNavKey: "papers", body };
  }


  // ── SUBJECT PAST / TOPICS / GENERATE (Life Sciences · Accounting) ──
  if (view === "subject_past" || view === "subject_topics" || view === "subject_generate") {
    const sub = app.student?.subject || "mathematical_literacy";
    const { listSubjectPapers, generateSubjectPaper } = await import("../engines/subjectPapersEngine.js");
    const { topicsForSubject, loadSubjectRegistry, subjectLabel } = await import("../engines/subjectRegistry.js");
    await loadSubjectRegistry();
    const label = subjectLabel(sub) || sub;

    if (view === "subject_past") {
      const papers = listSubjectPapers(sub) || [];
      const body = [
        el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← Papers"),
        el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.85rem;" },
          label + " · CAPS-style full papers. Questions are generated on device.")
      ];
      // Group: period → name → years
      const byPeriod = {};
      papers.forEach((p) => {
        const per = p.period || "Exam";
        byPeriod[per] = byPeriod[per] || {};
        const k = p.name || p.templateId;
        byPeriod[per][k] = byPeriod[per][k] || [];
        byPeriod[per][k].push(p);
      });
      const periodOrder = ["March", "June", "September", "November", "Exam"];
      const periods = Object.keys(byPeriod).sort((a, b) => {
        const ia = periodOrder.indexOf(a), ib = periodOrder.indexOf(b);
        return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
      });
      if (!periods.length) {
        body.push(card("No papers", "Use Generate paper.", [
          { label: "GENERATE", onClick: () => app.navigate("papers", { view: "subject_generate" }) }
        ]));
      } else {
        periods.forEach((per) => {
          body.push(el("div", { class: "section-eyebrow" }, per.toUpperCase()));
          Object.keys(byPeriod[per]).forEach((name) => {
            const years = byPeriod[per][name].slice().sort((a, b) => (b.year || 0) - (a.year || 0));
            body.push(card(name, years.length + " year(s)",
              years.slice(0, 6).map((y) => ({
                label: String(y.year),
                onClick: () => {
                  const paper = generateSubjectPaper(sub, y.templateId || y.id, 10, y.year);
                  if (!paper) return showAlert("Error", "Could not build paper.");
                  paper.paper_id = paper.paper_id || paper.id;
                  try { sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper)); } catch (_) {}
                  app.showPaperViewer(paper.paper_id, { curated: true });
                }
              }))
            ));
          });
        });
      }
      return { title: "📚 " + label, bottomNavKey: "papers", body };
    }

    if (view === "subject_topics") {
      const { generateTopicPaper } = await import("../engines/subjectPapersEngine.js");
      const topics = topicsForSubject(sub) || [];
      const body = [
        el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← Papers"),
        el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
          "Full topic practice paper — 8–12 generative exam-style questions for one topic.")
      ];
      topics.forEach((t) => {
        const id = t.id || t;
        const name = t.name || String(id).replaceAll("_", " ");
        body.push(card((t.icon || "📘") + " " + name, "Textbook / paper-style question list", [
          {
            label: "START",
            onClick: () => {
              const paper = generateTopicPaper(sub, id, app.student?.grade ?? 10, 10);
              if (!paper || !paper.questions?.length) {
                return showAlert("Error", "Could not build topic paper.");
              }
              try { sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper)); } catch (_) {}
              app.showPaperViewer(paper.paper_id, { curated: true });
            }
          }
        ]));
      });
      if (!topics.length) body.push(card("No topics", "Subject topic list is empty."));
      return { title: "🎯 Topic practice", bottomNavKey: "papers", body };
    }

        // subject_generate
    const papers = listSubjectPapers(sub) || [];
    const body = [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("papers", { view: "hub" }) }, "← Papers menu"),
      el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
        "Generate a full " + label + " paper from CAPS blueprints."),
      card("Quick generate", "Build a random full paper for " + label, [
        {
          label: "GENERATE",
          onClick: () => {
            const tmplId = papers[0] && (papers[0].templateId || papers[0].id);
            const paper = generateSubjectPaper(sub, tmplId, 10);
            if (!paper) return showAlert("Error", "Could not generate paper.");
            paper.paper_id = paper.paper_id || ("gen_" + sub + "_" + Date.now().toString(36));
            paper.generated = true;
            sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper));
            app.showPaperViewer(paper.paper_id, { curated: true });
          }
        }
      ])
    ];
    papers.forEach((tmpl) => {
      body.push(card(tmpl.name || tmpl.id, "Blueprint · " + (tmpl.period || "exam"), [
        {
          label: "GENERATE",
          onClick: () => {
            const paper = generateSubjectPaper(sub, tmpl.templateId || tmpl.id, 10, tmpl.year);
            if (!paper) return showAlert("Error", "Could not generate paper.");
            paper.paper_id = paper.paper_id || ("gen_" + sub + "_" + Date.now().toString(36));
            paper.generated = true;
            sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper));
            app.showPaperViewer(paper.paper_id, { curated: true });
          }
        }
      ]));
    });
    return { title: "✏️ Generate · " + label, bottomNavKey: "papers", body };
  }


  // fallback
  return Papers(app, { view: "hub" });
}

async function previewPaperImage(paper, showMemo, box) {
  box.innerHTML = "";
  box.appendChild(el("div", { class: "role-muted" }, "Building image…"));
  const canvas = el("canvas", {
    style: "width:100%;border-radius:12px;background:#fff;margin-top:0.5rem;"
  });
  const W = 360;
  const lineH = 22;
  let lines = 10;
  (paper.questions || []).forEach((q) => {
    lines += 5 + Math.ceil(String(q.question || "").length / 40);
    if (showMemo) lines += 3;
  });
  const H = Math.min(3600, 90 + lines * lineH);
  const dpr = window.devicePixelRatio || 1;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.width = "100%";
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, W, H);

  let y = 24;
  ctx.fillStyle = "#111";
  ctx.font = "bold 14px system-ui";
  const title = paper.title || `${paper.grade_label || "Grade"} · ${paper.type || "Paper"}`;
  ctx.fillText(title.slice(0, 42), 12, y);
  y += 18;
  ctx.font = "12px system-ui";
  ctx.fillStyle = "#555";
  ctx.fillText(
    `${paper.period || "Term " + (paper.term || "")} · ${paper.marks || ""} marks · ${paper.time_minutes || ""} min`,
    12,
    y
  );
  y += 16;
  ctx.strokeStyle = "#ddd";
  ctx.beginPath();
  ctx.moveTo(12, y);
  ctx.lineTo(W - 12, y);
  ctx.stroke();
  y += 18;

  let lastMain = null;
  for (const q of paper.questions || []) {
    if (y > H - 40) break;
    const main = q.qMain;
    if (main != null && main !== lastMain) {
      ctx.fillStyle = "#111";
      ctx.font = "bold 13px system-ui";
      const heading = (q.sectionLabel || `QUESTION ${main}`).slice(0, 48);
      ctx.fillText(heading, 12, y);
      y += lineH;
      lastMain = main;
    }
    if (q.group && q.groupStem && q.partLabel && String(q.partLabel).endsWith(".1")) {
      ctx.fillStyle = "#111";
      ctx.font = "bold 12px system-ui";
      ctx.fillText(`${q.group}  ${q.groupStem}`.slice(0, 48), 12, y);
      y += lineH - 2;
    }
    ctx.fillStyle = "#111";
    ctx.font = "bold 12px system-ui";
    const num = labelForQuestion(q);
    ctx.fillText(`${num}  (${q.marks || 1})`, 12, y);
    y += lineH - 2;
    ctx.font = "12px system-ui";
    const text = bodyForQuestion(q).replace(/\n/g, " ");
    const words = text.split(/\s+/);
    let line = "";
    for (const w of words) {
      const test = line ? line + " " + w : w;
      if (ctx.measureText(test).width > W - 24) {
        ctx.fillText(line, 16, y);
        y += lineH - 4;
        line = w;
        if (y > H - 40) break;
      } else line = test;
    }
    if (line) {
      ctx.fillText(line, 16, y);
      y += lineH;
    }
    if (showMemo) {
      ctx.fillStyle = "#0a7";
      ctx.font = "11px system-ui";
      ctx.fillText(("Answer: " + String(q.answer || "")).slice(0, 58), 16, y);
      y += lineH - 4;
      ctx.fillStyle = "#555";
    }
    y += 6;
  }

  box.innerHTML = "";
  box.appendChild(canvas);
  box.appendChild(
    el("div", { class: "role-muted wrap" }, "Scroll to see the full paper. Use Save image to keep it.")
  );
}




export async function PaperViewer(app, { paperId, curated = false } = {}) {
  let paper = null;
  if (curated) {
    try {
      paper = JSON.parse(sessionStorage.getItem("learnly:curated:" + paperId) || "null");
    } catch {
      paper = null;
    }
    if (!paper) paper = await pe.buildCuratedPaper(paperId, app.student);
  } else {
    paper = pe.load(paperId);
  }

  if (!paper) {
    return { title: "📝 Paper Viewer", body: [el("div", { class: "wrap" }, "Paper not found.")] };
  }

  const isTopicPractice = paper.type === "Topic Practice" || (paper.period === "Topic practice");
  const topicId = (paper.topics && paper.topics[0]) || null;

  // Group questions into main QUESTION blocks (by qMain or sectionLabel)
  function groupQuestions(qs) {
    const groups = [];
    let cur = null;
    qs.forEach((q, i) => {
      const key = q.qMain != null
        ? String(q.qMain)
        : (q.sectionLabel || q.section || `item-${i}`);
      if (!cur || cur.key !== key) {
        cur = {
          key,
          sectionLabel: q.sectionLabel || q.section || (q.qMain != null ? `QUESTION ${q.qMain}` : null),
          items: []
        };
        groups.push(cur);
      }
      cur.items.push(q);
    });
    if (groups.length === 1 && groups[0].items.length > 6 && groups[0].items.every((q) => q.qMain == null)) {
      return qs.map((q, i) => ({
        key: String(i + 1),
        sectionLabel: q.sectionLabel || `QUESTION ${i + 1}`,
        items: [q]
      }));
    }
    return groups;
  }

  let groups = groupQuestions(paper.questions || []);
  let showingMemo = false;
  // Default: entire paper on one continuous sheet (exam style). Focus mode still available.
  let focusMode = false;
  let groupIdx = 0;

  const questionsWrap = el("div", {
    class: "paper-sheet",
    style: "background:#fff;border-radius:12px;padding:0.75rem 0.9rem;border:1px solid #e8ecf2;"
  });
  const navRow = el("div", { class: "btn-row", style: "flex-wrap:wrap;gap:0.4rem;margin:0.5rem 0;" });
  const memoBtn = el("button", {
    class: "btn",
    style: "font-weight:800;letter-spacing:0.04em;padding:0.65rem 1rem;border-radius:0.75rem;" +
      "background:linear-gradient(135deg,#0d9488,#059669);border:none;color:#fff;",
    onClick: toggleMemo
  }, "SHOW ALL SOLUTIONS");
  const statusEl = el("div", { class: "role-muted wrap", style: "margin:0.25rem 0 0.5rem;" });

  function scrollToTop() {
    try {
      window.scrollTo({ top: 0, behavior: "smooth" });
      const main = document.querySelector("main") || document.querySelector(".app-main") || document.body;
      if (main && main.scrollTo) main.scrollTo({ top: 0, behavior: "smooth" });
    } catch { /* ignore */ }
  }

  function labelForQuestion(q) {
    if (q.partLabel) return String(q.partLabel);
    if (q.displayNumber) return String(q.displayNumber);
    if (q.number != null) return String(q.number);
    return "";
  }

  function bodyForQuestion(q) {
    if (q.questionDisplay) return q.questionDisplay;
    if (q.parts && Array.isArray(q.parts) && q.parts.length) {
      return q.parts.map((p) => {
        if (typeof p === "string") return p;
        const lab = p.label ? p.label + " " : "";
        return lab + (p.prompt || p.question || "");
      }).join("\n\n");
    }
    return q.question || q.prompt || q.text || "";
  }

  function appendQuestionBlock(host, q) {
    if (q.group && q.groupStem && q.partLabel && /\.1$/.test(String(q.partLabel))) {
      host.appendChild(
        el("div", { class: "wrap", style: "font-weight:600;margin:0.55rem 0 0.25rem;" },
          `${q.group}  ${q.groupStem}`)
      );
    }
    const label = labelForQuestion(q);
    const marks = q.marks != null ? q.marks : 1;
    const row = el("div", {
      class: "caps-q-row",
      style: "display:flex;gap:0.5rem;align-items:flex-start;margin:0.55rem 0;padding-bottom:0.4rem;border-bottom:1px solid #f0f0f0;"
    });
    const left = el("div", { style: "flex:1;min-width:0;" });
    if (label) {
      left.appendChild(el("div", { style: "font-weight:600;margin-bottom:0.2rem;" }, label));
    }
    left.appendChild(
      el("div", { class: "wrap", style: "white-space:pre-wrap;line-height:1.45;" }, bodyForQuestion(q))
    );
    if (q.diagram) {
      const wrap = el("div", {
        style: "width:100%;max-width:340px;margin:0.45rem 0;overflow:hidden;"
      });
      const c = el("canvas", {
        style: "display:block;width:100%;max-width:100%;height:auto;"
      });
      wrap.appendChild(c);
      left.appendChild(wrap);
      requestAnimationFrame(() => {
        const w = Math.min(320, wrap.clientWidth || 280);
        try { drawDiagram(c, q.diagram, w, Math.round(w * 0.7)); } catch (_) {}
      });
    }
    // Per-question solution toggle (also respects global showingMemo)
    const solId = "sol_" + (q.id || label || Math.random().toString(36).slice(2));
    const solBody = el("div", {
      class: "solution-block",
      style: "display:none;margin-top:0.45rem;padding:0.5rem 0.6rem;background:#f3faf6;border-left:3px solid #0a7;border-radius:6px;"
    }, [
      el("div", { style: "font-weight:700;color:#0a7;margin-bottom:0.2rem;" }, "Solution"),
      el("div", { class: "wrap", style: "white-space:pre-wrap;line-height:1.4;" },
        (q.explanation || q.solution || ("Answer: " + (q.answer != null ? q.answer : "—"))))
    ]);
    if (showingMemo) solBody.style.display = "";
    const solBtn = el("button", {
      class: "btn-secondary btn-sm",
      style: "margin-top:0.4rem;padding:0.3rem 0.65rem;font-size:0.78rem;",
      onClick: () => {
        const open = solBody.style.display === "none";
        solBody.style.display = open ? "" : "none";
        solBtn.textContent = open ? "Hide solution" : "View solution";
      }
    }, showingMemo ? "Hide solution" : "Show solution");
    left.appendChild(solBtn);
    left.appendChild(solBody);
    const right = el("div", {
      style: "flex-shrink:0;font-weight:600;color:#64748b;min-width:2.2rem;text-align:right;"
    }, `(${marks})`);
    row.append(left, right);
    host.appendChild(row);
  }

  function renderNav() {
    navRow.innerHTML = "";
    if (isTopicPractice) {
      navRow.appendChild(
        el("button", {
          class: "btn",
          onClick: () => generateNextTopicQuestion()
        }, "New question block ▶")
      );
      navRow.appendChild(
        el("button", { class: "btn-secondary", onClick: scrollToTop }, "↑ Top")
      );
      return;
    }

    // Entire paper is default; Focus mode optional for one QUESTION at a time
    const modeBtn = el("button", {
      class: "btn-secondary",
      onClick: () => {
        focusMode = !focusMode;
        if (!focusMode) groupIdx = 0;
        showingMemo = showingMemo; // keep
        renderAll();
        scrollToTop();
      }
    }, focusMode ? "📄 Show entire paper" : "🔎 Focus one question");

    if (focusMode) {
      const prevBtn = el("button", {
        class: "btn-secondary",
        disabled: groupIdx <= 0,
        onClick: () => {
          groupIdx = Math.max(0, groupIdx - 1);
          renderAll();
          scrollToTop();
        }
      }, "◀ Previous");
      const nextBtn = el("button", {
        class: "btn",
        disabled: groupIdx >= groups.length - 1,
        onClick: () => {
          groupIdx = Math.min(groups.length - 1, groupIdx + 1);
          renderAll();
          scrollToTop();
        }
      }, "Next ▶");
      const jump = el("select", {
        onChange: (e) => {
          groupIdx = Number(e.target.value);
          renderAll();
          scrollToTop();
        }
      });
      groups.forEach((g, i) => {
        const label = g.sectionLabel || `QUESTION ${i + 1}`;
        const opt = el("option", { value: i }, label.length > 40 ? label.slice(0, 40) + "…" : label);
        if (i === groupIdx) opt.selected = true;
        jump.appendChild(opt);
      });
      navRow.append(modeBtn, prevBtn, jump, nextBtn,
        el("button", { class: "btn-secondary", onClick: scrollToTop }, "↑ Top"));
    } else {
      navRow.append(
        modeBtn,
        el("button", { class: "btn-secondary", onClick: scrollToTop }, "↑ Top")
      );
    }
  }

  function renderGroup() {
    questionsWrap.innerHTML = "";
    if (!groups.length) {
      questionsWrap.appendChild(el("div", { class: "wrap" }, "No questions."));
      return;
    }

    // Cover / header strip (exam style)
    const cover = el("div", {
      style: "border-bottom:2px solid #1e293b;padding-bottom:0.55rem;margin-bottom:0.75rem;"
    });
    cover.appendChild(el("div", {
      style: "font-weight:800;font-size:1.05rem;letter-spacing:0.02em;"
    }, paper.title || `${paper.grade_label || "Grade " + (paper.grade || "")} Mathematics — ${paper.type || "Paper"}`));
    cover.appendChild(el("div", {
      class: "role-muted",
      style: "margin-top:0.2rem;font-size:0.85rem;"
    }, `${paper.period || ("Term " + (paper.term || ""))} · ${paper.difficulty || "Standard"} · ${paper.marks || "—"} marks · ${paper.time_minutes || 45} minutes`));
    if (paper.instructions) {
      cover.appendChild(el("div", {
        class: "wrap",
        style: "margin-top:0.4rem;font-size:0.82rem;white-space:pre-wrap;"
      }, paper.instructions));
    }
    questionsWrap.appendChild(cover);

    const toRender = focusMode
      ? [groups[Math.max(0, Math.min(groupIdx, groups.length - 1))]]
      : groups;

    toRender.forEach((g, gi) => {
      if (g.sectionLabel) {
        questionsWrap.appendChild(
          el("div", {
            class: "section-eyebrow",
            style: "margin:0.85rem 0 0.4rem;font-weight:800;font-size:0.95rem;color:#0f172a;border-top:1px solid #e2e8f0;padding-top:0.55rem;"
          }, g.sectionLabel)
        );
      }
      g.items.forEach((q) => appendQuestionBlock(questionsWrap, q));
    });
  }

  function renderStatus() {
    if (isTopicPractice) {
      statusEl.textContent = showingMemo
        ? "Solutions shown for this block. Use New question block for another unique multi-part question."
        : "Full question block shown. Toggle VIEW SOLUTIONS for formal working.";
      return;
    }
    if (focusMode) {
      statusEl.textContent = showingMemo
        ? `Solutions for question ${groupIdx + 1} of ${groups.length}.`
        : `Focus mode — question ${groupIdx + 1} of ${groups.length}. Prefer “Show entire paper” for the full exam layout.`;
    } else {
      statusEl.textContent = showingMemo
        ? `Full paper · solutions visible for all ${groups.length} main question(s).`
        : `Full paper · ${groups.length} main question(s) · ${paper.questions?.length || 0} parts · use VIEW SOLUTIONS to reveal formal working.`;
    }
  }

  function renderAll() {
    renderNav();
    renderGroup();
    renderStatus();
  }

  function toggleMemo() {
    showingMemo = !showingMemo;
    memoBtn.textContent = showingMemo ? "HIDE ALL SOLUTIONS" : "SHOW ALL SOLUTIONS";
    renderGroup();
    renderStatus();
  }

  function generateNextTopicQuestion() {
    if (!topicId) return;
    const eng = app.questionEngine();
    let questions = [];
    if (typeof eng.generatePaperParts === "function") {
      questions = eng.generatePaperParts(topicId, 2) || [];
    }
    if (!questions.length) {
      for (let i = 0; i < 5; i++) {
        const q = eng.generate(topicId, 2);
        q.partLabel = `1.${i + 1}`;
        q.capsFormat = true;
        questions.push(q);
      }
    }
    questions.forEach((q, i) => {
      q.sectionLabel = q.sectionLabel || q.section || "QUESTION 1";
      q.displayNumber = q.partLabel || String(i + 1);
    });
    paper.questions = questions;
    paper.marks = questions.reduce((s, q) => s + (q.marks || 2), 0);
    paper.paper_id = "topic_" + topicId + "_" + Date.now().toString(36);
    sessionStorage.setItem("learnly:curated:" + paper.paper_id, JSON.stringify(paper));
    groups = groupQuestions(questions);
    groupIdx = 0;
    showingMemo = false;
    memoBtn.textContent = "SHOW ALL SOLUTIONS";
    renderAll();
    scrollToTop();
  }

  renderAll();

  const heading =
    paper.title || `${paper.grade_label || "Grade"} Mathematics — ${paper.type}`;
  const sub =
    `${paper.period || "Term " + (paper.term || "")} · ${paper.difficulty || "Standard"} · ${paper.marks || ""} marks · ${paper.time_minutes || 45} min` +
    (paper.generated ? "\nGenerated for this session" : "");

  return {
    title: "📝 Paper Viewer",
    bottomNavKey: "papers",
    body: [
      card(heading, sub),
      el("div", { class: "btn-row", style: "flex-wrap:wrap;" }, [
        memoBtn,
        el("button", {
          class: "btn-secondary",
          onClick: () => {
            try { exportPaperImage(paper, showingMemo); } catch (_) {
              showAlert("Export", "Image export is not available in this session.");
            }
          }
        }, "Save image")
      ]),
      statusEl,
      navRow,
      questionsWrap
    ]
  };
}
