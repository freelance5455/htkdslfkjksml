// v0.18.0 compatibility shim: installed-state ownership moved to components/mod-library/installed-state.js.
window.WorkspaceMo2LibraryOverlay=window.WorkspaceModLibraryInstalledState;
