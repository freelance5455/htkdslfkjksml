import { el, card, showAlert } from "../ui/widgets.js";
import { TheoremEngine } from "../engines/theoremEngine.js";

/**
 * Theorem Workshop — drag-fill, match, and type modes for CAPS formulae.
 */
export async function TheoremLab(app) {
  const grade = app.student?.grade ?? 11;
  const engine = new TheoremEngine(grade);
  const isPS = app.student?.subject === "physical_sciences";
  let theorems = engine.list();
  if (isPS) theorems = theorems.filter((th) => String(th.topic || "").startsWith("ps_"));
  else theorems = theorems.filter((th) => !String(th.topic || "").startsWith("ps_"));

  const list = theorems.map((t) =>
    card(
      t.name,
      `${t.formula}\nTopic: ${t.topic.replaceAll("_", " ")}`,
      [
        { label: "DRAG FILL", onClick: () => app.navigate("theoremRound", { theoremId: t.id, mode: "drag" }) },
        { label: "MATCH", onClick: () => app.navigate("theoremRound", { theoremId: t.id, mode: "match" }), secondary: true },
        { label: "TYPE", onClick: () => app.navigate("theoremRound", { theoremId: t.id, mode: "type" }), secondary: true }
      ]
    )
  );

  return {
    title: "📐 Theorem Workshop",
    bottomNavKey: "learn",
    body: [
      el(
        "div",
        { class: "wrap role-muted" },
        "Master CAPS Grade 11 formulae: quadratic formula, distance, gradient, sequences, trig ratios, compound interest and more. Choose a theorem, then Drag, Match or Type."
      ),
      el("button", {
        class: "btn",
        onClick: () => app.navigate("theoremRound", { theoremId: null, mode: "drag" })
      }, "🎲 RANDOM DRAG ROUND"),
      el("div", { class: "section-eyebrow" }, "THEOREMS & FORMULAE"),
      ...list
    ]
  };
}

export async function TheoremRound(app, { theoremId = null, mode = "drag" } = {}) {
  const engine = new TheoremEngine(app.student?.grade ?? 11);
  let round;
  if (mode === "match") round = engine.buildMatchRound(theoremId);
  else if (mode === "type") round = engine.buildTypeRound(theoremId);
  else round = engine.buildDragRound(theoremId);

  if (!round) {
    return { title: "Theorem Round", body: [card("Unavailable", "No theorem data for this selection.")] };
  }

  let score = 0;
  let done = 0;
  const status = el("div", { class: "wrap" }, "Fill each slot correctly. Tap an option, then tap a slot — or drag if your browser supports it.");
  const bodyParts = [
    card(round.name, round.formula),
    el("div", { class: "wrap role-muted" }, round.hint || ""),
    status
  ];

  if (round.mode === "drag") {
    const slotEls = [];
    const filled = new Set();
    let selectedOpt = null;

    const slotsWrap = el("div", { class: "topic-list" });
    for (const slot of round.slots) {
      const box = el("div", {
        class: "card",
        style: "cursor:pointer;min-height:3rem;",
        dataset: { answer: slot.answer, id: slot.id }
      }, [
        el("div", { class: "role-muted" }, slot.prompt),
        el("div", { class: "role-heading", style: "margin-top:0.35rem;" }, "— drop / tap answer —")
      ]);
      box.addEventListener("click", () => {
        if (filled.has(slot.id) || !selectedOpt) return;
        const val = selectedOpt.dataset.value;
        const ok = val === slot.answer;
        box.querySelector(".role-heading").textContent = val;
        if (ok) {
          box.style.borderColor = "#27ae60";
          filled.add(slot.id);
          score += 10;
          done++;
          selectedOpt.remove();
          selectedOpt = null;
          status.textContent = `Correct · ${done}/${round.slots.length} · score ${score}`;
          if (done >= round.slots.length) {
            status.textContent = `Complete · score ${score}. Review the explanation below.`;
          }
        } else {
          box.style.borderColor = "#e74c3c";
          status.textContent = "Not quite — try another option.";
          setTimeout(() => { box.style.borderColor = ""; }, 600);
        }
      });
      slotEls.push(box);
      slotsWrap.appendChild(box);
    }

    const optsWrap = el("div", { class: "chip-row", style: "flex-wrap:wrap;gap:0.5rem;" });
    for (const opt of round.options) {
      const chip = el("button", {
        class: "chip",
        dataset: { value: opt },
        onClick: (e) => {
          optsWrap.querySelectorAll(".chip").forEach((c) => c.classList.remove("active"));
          e.currentTarget.classList.add("active");
          selectedOpt = e.currentTarget;
        }
      }, opt);
      optsWrap.appendChild(chip);
    }

    bodyParts.push(el("div", { class: "section-eyebrow" }, "SLOTS"), slotsWrap);
    bodyParts.push(el("div", { class: "section-eyebrow" }, "OPTIONS"), optsWrap);
  } else if (round.mode === "match") {
    let selected = null;
    const matched = new Set();
    const leftCol = el("div", {});
    const rightCol = el("div", {});
    const pairById = Object.fromEntries(round.pairs.map((p) => [p.id, p]));

    function tryMatch(a, b) {
      if (a.side === b.side) return;
      const idA = parseInt(a.dataset.id, 10);
      const idB = parseInt(b.dataset.id, 10);
      if (idA === idB) {
        a.classList.add("active");
        b.classList.add("active");
        a.style.opacity = "0.55";
        b.style.opacity = "0.55";
        matched.add(idA);
        score += 15;
        status.textContent = `Matched · ${matched.size}/${round.pairs.length} · score ${score}`;
        selected = null;
      } else {
        status.textContent = "Those do not match.";
        selected.classList.remove("active");
        selected = null;
      }
    }

    for (const id of round.leftOrder) {
      const p = pairById[id];
      const btn = el("button", {
        class: "btn-secondary",
        style: "display:block;width:100%;margin:0.25rem 0;text-align:left;",
        dataset: { id: String(id), side: "left" },
        onClick: (e) => {
          const t = e.currentTarget;
          if (matched.has(id)) return;
          if (!selected) {
            selected = t;
            t.classList.add("active");
          } else {
            tryMatch(selected, t);
          }
        }
      }, p.left);
      leftCol.appendChild(btn);
    }
    for (const id of round.rightOrder) {
      const p = pairById[id];
      const btn = el("button", {
        class: "btn-secondary",
        style: "display:block;width:100%;margin:0.25rem 0;text-align:left;",
        dataset: { id: String(id), side: "right" },
        onClick: (e) => {
          const t = e.currentTarget;
          if (matched.has(id)) return;
          if (!selected) {
            selected = t;
            t.classList.add("active");
          } else {
            tryMatch(selected, t);
          }
        }
      }, p.right);
      rightCol.appendChild(btn);
    }
    bodyParts.push(el("div", { class: "section-eyebrow" }, "MATCH PAIRS"));
    bodyParts.push(el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;" }, [leftCol, rightCol]));
  } else {
    // type mode
    const input = el("input", {
      type: "text",
      class: "math-input",
      placeholder: "Type the formula…",
      style: "width:100%;padding:0.75rem;font-size:1rem;border-radius:8px;border:2px solid var(--accent,#3498db);"
    });
    const check = el("button", {
      class: "btn",
      onClick: () => {
        const v = (input.value || "").replace(/\s+/g, "").toLowerCase();
        const target = (round.answer || "").replace(/\s+/g, "").toLowerCase();
        // soft match: allow common variants
        const soft = target.replace(/[()]/g, "");
        const softV = v.replace(/[()]/g, "");
        if (v === target || softV === soft || softV.includes(soft.slice(0, Math.min(12, soft.length)))) {
          score += 20;
          status.textContent = `Accepted · score ${score}`;
          showAlert("Correct", round.formula);
        } else {
          status.textContent = "Not matching yet — check symbols and order.";
        }
      }
    }, "CHECK");
    bodyParts.push(el("div", { class: "wrap" }, round.prompt));
    bodyParts.push(input, check);
  }

  // Explanation
  if (round.explanation) {
    bodyParts.push(
      el("div", { class: "section-eyebrow" }, "EXPLANATION"),
      card("Formula", round.explanation.formula || round.formula),
      card("Steps", (round.explanation.steps || []).map((s, i) => `${i + 1}. ${s}`).join("\n"))
    );
  }

  bodyParts.push(
    el("div", { class: "btn-row" }, [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("theoremLab") }, "ALL THEOREMS"),
      el("button", {
        class: "btn",
        onClick: () => app.navigate("theoremRound", { theoremId: round.id, mode: round.mode })
      }, "TRY AGAIN")
    ])
  );

  return {
    title: `📐 ${round.name}`,
    bottomNavKey: "learn",
    body: bodyParts
  };
}
