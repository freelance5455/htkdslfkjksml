import { el, card, showAlert } from "../ui/widgets.js";
import { UnifiedQuestionEngine } from "../engines/unifiedEngine.js";
import { answersMatch } from "../engines/answerCheck.js";
import { playSfx } from "../engines/audioEngine.js";
import { drawDiagram } from "../ui/render.js";

/**
 * Self-contained workshop drill — never navigates to the Practice screen.
 * Generates questions for one topic and runs a local session with check / next / explain.
 */
export async function WorkshopSession(app, {
  topicId = "equations_inequalities",
  title = "Workshop",
  count = 8,
  difficulty = 2
} = {}) {
  const grade = app.student?.grade ?? 11;
  const qe = new UnifiedQuestionEngine(grade);
  const questions = [];
  for (let i = 0; i < count; i++) {
    try {
      questions.push(qe.generate(topicId, difficulty + (i % 2)));
    } catch {
      questions.push(qe.generate(topicId, 1));
    }
  }
  if (!questions.length) {
    return {
      title,
      body: [card("Unavailable", "No questions could be generated for this workshop.")]
    };
  }

  let index = 0;
  let score = 0;
  let checked = false;
  const progress = el("div", { class: "wrap role-muted" });
  const promptBox = el("div", { class: "card" });
  const input = el("input", {
    type: "text",
    placeholder: "Your answer…",
    style: "width:100%;padding:0.75rem;font-size:1.05rem;border-radius:10px;border:2px solid #ccc;margin:0.5rem 0;"
  });
  const feedback = el("div", { class: "wrap" });
  const diagramHost = el("div", {});

  function renderQ() {
    checked = false;
    const q = questions[index];
    progress.textContent = `Question ${index + 1} of ${questions.length} · Score ${score}`;
    promptBox.innerHTML = "";
    promptBox.appendChild(el("div", { class: "role-heading wrap" }, q.topic_name || topicId.replaceAll("_", " ")));
    promptBox.appendChild(el("div", { class: "wrap", style: "white-space:pre-wrap;margin-top:0.5rem;" }, q.question));
    if (q.marks) {
      promptBox.appendChild(el("div", { class: "role-muted wrap" }, `(${q.marks} marks)`));
    }
    diagramHost.innerHTML = "";
    if (q.diagram) {
      const c = el("canvas", { style: "display:block;margin:0.5rem auto;" });
      diagramHost.appendChild(c);
      requestAnimationFrame(() => drawDiagram(c, q.diagram, 260, 180));
    }
    input.value = "";
    feedback.textContent = "";
    input.focus();
  }

  function check() {
    if (checked) return;
    const q = questions[index];
    const raw = (input.value || "").trim();
    if (!raw) {
      feedback.textContent = "Enter an answer first.";
      return;
    }
    const ok = answersMatch(raw, q.answer);
    checked = true;
    if (ok) {
      score += q.marks || 1;
      feedback.textContent = `Correct. ${q.explanation ? "Working: " + q.explanation : ""}`;
      feedback.style.color = "#0a7";
      playSfx("correct");
    } else {
      feedback.textContent = `Not quite. Expected: ${q.answer}${q.explanation ? "\n" + q.explanation : ""}`;
      feedback.style.color = "#c0392b";
      playSfx("wrong");
    }
    progress.textContent = `Question ${index + 1} of ${questions.length} · Score ${score}`;
  }

  function next() {
    if (!checked) {
      // allow skip but nudge
      feedback.textContent = "Check your answer, or tap Next again to skip.";
      checked = true;
      return;
    }
    if (index >= questions.length - 1) {
      showAlert(
        "Workshop complete",
        `Score: ${score}\nQuestions: ${questions.length}\n\nReturning to Workshops.`
      ).then(() => app.showLabs());
      return;
    }
    index++;
    renderQ();
  }

  function showHint() {
    const q = questions[index];
    feedback.textContent = q.hint || "Work step by step; check domain if roots or fractions appear.";
    feedback.style.color = "#856404";
    playSfx("hint");
  }

  renderQ();

  return {
    title: `🛠️ ${title}`,
    bottomNavKey: "learn",
    body: [
      progress,
      promptBox,
      diagramHost,
      input,
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn", onClick: check }, "CHECK"),
        el("button", { class: "btn-secondary", onClick: showHint }, "HINT"),
        el("button", { class: "btn", onClick: next }, "NEXT")
      ]),
      feedback,
      el("button", {
        class: "btn-secondary",
        style: "margin-top:1rem;",
        onClick: () => app.showLabs()
      }, "← BACK TO WORKSHOPS")
    ]
  };
}

/** Factory helpers used by Labs hub */
export function openWorkshop(app, topicId, title) {
  return app.navigate("workshopSession", { topicId, title, count: 8, difficulty: 2 });
}
