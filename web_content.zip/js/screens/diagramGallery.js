/**
 * Diagram gallery — preview every CAPS / parametric recipe without grade gating.
 */
import { el, card } from "../ui/widgets.js";
import { DIAGRAM_CATALOG, drawCatalogDiagram } from "../engines/parametricEngine.js";
import { drawDiagram } from "../ui/render.js";
import { recipe } from "../engines/diagramEngine.js";

const FALLBACK_SPECS = {
  accounting_equation: { type: "accounting_equation", assets: 12000, liabilities: 4000, equity: 8000 },
  journal_table: { type: "journal_table" },
  t_account: { type: "t_account", account: "Bank", debit: [["Capital", "5 000"]], credit: [["Purchases", "1 200"]] },
  bank_recon: { type: "bank_recon" },
  food_web: { type: "food_web" },
  income_statement: { type: "income_statement" },
  trial_balance: { type: "trial_balance" }
};

function paint(canvas, id) {
  const w = 320, h = 230;
  const ctx = canvas.getContext("2d");
  // clear via setup-like fill
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + "px";
  canvas.style.height = h + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);

  const handled = drawCatalogDiagram(ctx, w, h, id);
  if (handled === null) {
    const spec = FALLBACK_SPECS[id] || recipe(id, 11) || { type: id };
    // drawDiagram expects to own setupCanvas — use temporary canvas path
    drawDiagram(canvas, spec, w, h);
  }
}

export async function DiagramGallery(app) {
  const groups = {};
  DIAGRAM_CATALOG.forEach((d) => {
    groups[d.group] = groups[d.group] || [];
    groups[d.group].push(d);
  });

  const body = [
    el("button", { class: "btn-secondary", onClick: () => app.showSettings() }, "← Settings"),
    el("div", { class: "role-subtitle wrap" },
      "All instructional and parametric diagrams. Not limited by grade — for review and quality checks.")
  ];

  Object.keys(groups).forEach((g) => {
    body.push(el("div", { class: "section-eyebrow" }, g.toUpperCase()));
    groups[g].forEach((d) => {
      const host = el("div", {
        style: "width:100%;max-width:320px;margin:0.35rem auto;border:1px solid var(--hairline);border-radius:0.75rem;overflow:hidden;background:#fff;"
      });
      const c = el("canvas");
      host.appendChild(c);
      body.push(card(d.name, null, []));
      // replace empty card body pattern — push custom block
      body.pop();
      body.push(el("div", { class: "card" }, [
        el("div", { class: "role-heading" }, d.name),
        el("div", { class: "role-muted" }, d.id),
        host
      ]));
      requestAnimationFrame(() => {
        try { paint(c, d.id); } catch (err) { console.warn("diagram", d.id, err); }
      });
    });
  });

  return { title: "🖼 Diagram library", bottomNavKey: "home", body };
}
