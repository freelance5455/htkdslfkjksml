import { el, card } from "../ui/widgets.js";
import { formatQuestionHTML } from "../ui/widgets.js";
import { drawDiagram } from "../ui/render.js";
import { drawLessonVisual } from "../ui/imageBuilder.js";

/** Grade 5 teach decks — short cards, methods & tricks, no fluff. */
const DECKS = {
  whole_numbers_5: {
    title: "Numbers",
    cards: [
      { type: "idea", title: "Place value", body: "Each digit has a place: units, tens, hundreds, thousands…" },
      { type: "try", title: "Try", body: "What is the value of 7 in 27 105?", answer: "7000", tip: "Thousands place → 7 000." },
      { type: "idea", title: "Rounding", body: "Look one place to the right. 0–4 stay. 5–9 go up." },
      { type: "try", title: "Try", body: "Round 682 to the nearest 10.", answer: "680", tip: "Ones digit is 2 → stay at 680." },
      { type: "try", title: "Try", body: "Round 73 to the nearest 10.", answer: "70", tip: "3 is less than 5." },
      { type: "watch", title: "Watch out", body: "Start with smaller numbers. Grow when you are steady." },
      { type: "exit", title: "Check", qs: [
        { q: "Round 73 to the nearest 10", a: "70" },
        { q: "Value of 5 in 5 280?", a: "5000" },
        { q: "Greater: 408 or 480?", a: "480" }
      ]}
    ]
  },
  common_fractions_5: {
    title: "Fractions",
    cards: [
      { type: "idea", title: "Parts of a whole", body: "Bottom number = equal parts. Top number = how many you have." },
      { type: "see", title: "See", body: "3 out of 4 equal parts", visual: { type: "fraction", num: 3, den: 4 } },
      { type: "idea", title: "Same bottom number", body: "Same denominator → add or compare the tops only." },
      { type: "try", title: "Try", body: "⟦FRAC:1/4⟧ + ⟦FRAC:2/4⟧ = ?", answer: "3/4", tip: "1+2=3. Bottom stays 4." },
      { type: "try", title: "Try", body: "⟦FRAC:2/5⟧ of 20?", answer: "8", tip: "20÷5=4. 4×2=8." },
      { type: "watch", title: "Watch out", body: "Do not add the bottoms: ⟦FRAC:1/4⟧+⟦FRAC:1/4⟧=⟦FRAC:2/4⟧ not ⟦FRAC:2/8⟧." },
      { type: "exit", title: "Check", qs: [
        { q: "⟦FRAC:1/3⟧ of 12?", a: "4" },
        { q: "⟦FRAC:2/6⟧ + ⟦FRAC:3/6⟧ ?", a: "5/6" },
        { q: "Greater: ⟦FRAC:3/8⟧ or ⟦FRAC:5/8⟧?", a: "5/8" }
      ]}
    ]
  },
  addition_5: {
    title: "Addition",
    cards: [
      { type: "idea", title: "Make 10", body: "Push a number to 10, then add what is left.", visual: { type: "banner", title: "8 + 5", bigText: "13", steps: ["8 + 2 = 10", "10 + 3 = 13"] } },
      { type: "idea", title: "Break apart", body: "Split the second number. 47+36 → 47+30=77, +6=83." },
      { type: "idea", title: "Column method", body: "Line up ones under ones. Add ones, then tens, then hundreds. Carry when needed." },
      { type: "try", title: "Try · make 10", body: "9 + 6 = ?", answer: "15", tip: "9+1=10, then +5=15." },
      { type: "try", title: "Try · break apart", body: "58 + 24 = ?", answer: "82", tip: "58+20=78, +4=82." },
      { type: "try", title: "Try · columns", body: "276 + 148 = ?", answer: "424", tip: "Ones 14 write 4 carry 1. Tens 12 write 2 carry 1. Hundreds 4." },
      { type: "watch", title: "Watch out", body: "Always line up the same place values." },
      { type: "exit", title: "Check", qs: [
        { q: "8 + 7", a: "15" },
        { q: "46 + 29", a: "75" },
        { q: "305 + 127", a: "432" }
      ]}
    ]
  },
  subtraction_5: {
    title: "Subtraction",
    cards: [
      { type: "idea", title: "Count up", body: "From the small number up to the big one. 83−79: 79→83 is 4." },
      { type: "idea", title: "Break apart", body: "83−27 → 83−20=63, then 63−7=56." },
      { type: "idea", title: "Borrow", body: "If ones are too small, borrow 10 from the tens." },
      { type: "try", title: "Try · count up", body: "100 − 96 = ?", answer: "4", tip: "96 to 100 is 4." },
      { type: "try", title: "Try · break apart", body: "75 − 28 = ?", answer: "47", tip: "75−20=55, 55−8=47." },
      { type: "try", title: "Try · borrow", body: "52 − 18 = ?", answer: "34", tip: "Borrow: 12−8=4, tens 4−1=3." },
      { type: "watch", title: "Watch out", body: "After borrowing, the tens digit is one less." },
      { type: "exit", title: "Check", qs: [
        { q: "60 − 23", a: "37" },
        { q: "91 − 47", a: "44" },
        { q: "400 − 126", a: "274" }
      ]}
    ]
  },
  multiplication_5: {
    title: "Multiplication",
    cards: [
      { type: "idea", title: "Times tables", body: "Know 1–12 well. Most Grade 5 work builds on these facts." },
      { type: "idea", title: "×10 and ×100", body: "×10 → add one zero. ×100 → add two zeros. 37×10=370." },
      { type: "idea", title: "Break apart (grid)", body: "24×6 = (20×6)+(4×6) = 120+24 = 144." },
      { type: "idea", title: "Double & half", body: "16×5 → half of 16 is 8, ×10 = 80. Same answer, often faster." },
      { type: "try", title: "Try · tables", body: "7 × 8 = ?", answer: "56", tip: "7×8=56." },
      { type: "try", title: "Try · break apart", body: "23 × 4 = ?", answer: "92", tip: "20×4=80, 3×4=12, total 92." },
      { type: "try", title: "Try · ×10", body: "56 × 10 = ?", answer: "560", tip: "Add a zero." },
      { type: "watch", title: "Watch out", body: "×5 is half the number ×10. 18×5 = 9×10 = 90." },
      { type: "exit", title: "Check", qs: [
        { q: "6 × 9", a: "54" },
        { q: "14 × 5", a: "70" },
        { q: "32 × 3", a: "96" }
      ]}
    ]
  },
  division_5: {
    title: "Division",
    cards: [
      { type: "idea", title: "Opposite of ×", body: "20÷5=4 because 5×4=20. Use a tables fact you know." },
      { type: "idea", title: "Sharing", body: "24÷6 means 24 shared into 6 equal groups → 4 in each group." },
      { type: "idea", title: "Chunking", body: "Take away easy chunks. 72÷6: six 10s=60, left 12, two more 6s → 12." },
      { type: "idea", title: "÷10", body: "÷10 moves the digit one place right. 370÷10=37." },
      { type: "try", title: "Try · fact", body: "36 ÷ 6 = ?", answer: "6", tip: "6×6=36." },
      { type: "try", title: "Try · share", body: "Share 28 equally between 4. Each gets?", answer: "7", tip: "4×7=28." },
      { type: "try", title: "Try · chunk", body: "84 ÷ 7 = ?", answer: "12", tip: "7×10=70, left 14 → 2 more. 12." },
      { type: "watch", title: "Watch out", body: "Division is not always even. Remainders come later — for now aim for exact facts." },
      { type: "exit", title: "Check", qs: [
        { q: "45 ÷ 5", a: "9" },
        { q: "63 ÷ 9", a: "7" },
        { q: "96 ÷ 8", a: "12" }
      ]}
    ]
  }
};

function mountDiagram(parent, diagram) {
  if (!diagram) return;
  const c = el("canvas", { style: "display:block;margin:0.4rem auto;" });
  parent.appendChild(c);
  requestAnimationFrame(() => {
    try { drawDiagram(c, diagram, 280, 180); } catch { /* ignore */ }
  });
}

/** Draw a card visual (fraction, place value, banner) — never the full question text. */
function mountVisual(parent, card) {
  const visual = card.visual;
  if (!visual) return;
  const c = el("canvas", { style: "display:block;margin:0.4rem auto;max-width:100%;border-radius:12px;" });
  parent.appendChild(c);
  requestAnimationFrame(() => {
    try { drawLessonVisual(c, visual, 300, 160); } catch (err) { console.warn("mountVisual", err); }
  });
}

export async function TeachHub(app) {
  return {
    title: "Teach",
    bottomNavKey: "learn",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Short cards. Learn a bit, try a bit."),
      card("🔢 Numbers", "Place value and rounding", [{ label: "GO", onClick: () => app.navigate("teachDeck", { topicId: "whole_numbers_5" }) }]),
      card("🍕 Fractions", "Parts of a whole", [{ label: "GO", onClick: () => app.navigate("teachDeck", { topicId: "common_fractions_5" }) }]),
      card("➕ Addition", "Make 10 · break apart · columns", [{ label: "GO", onClick: () => app.navigate("teachDeck", { topicId: "addition_5" }) }]),
      card("➖ Subtraction", "Count up · break apart · borrow", [{ label: "GO", onClick: () => app.navigate("teachDeck", { topicId: "subtraction_5" }) }]),
      card("✖️ Multiplication", "Tables · break apart · ×10", [{ label: "GO", onClick: () => app.navigate("teachDeck", { topicId: "multiplication_5" }) }]),
      card("➗ Division", "Facts · sharing · chunking", [{ label: "GO", onClick: () => app.navigate("teachDeck", { topicId: "division_5" }) }]),
      card("✏️ Practice", "Use what you learned", [{ label: "PRACTICE", onClick: () => app.showPractice() }])
    ]
  };
}

export async function TeachDeck(app, { topicId } = {}) {
  const deck = DECKS[topicId] || DECKS.whole_numbers_5;
  let i = 0;
  const panel = el("div", {});

  function render() {
    panel.innerHTML = "";
    const c = deck.cards[i];
    panel.appendChild(el("div", { class: "role-heading teach-card" }, `${c.title} · ${i + 1}/${deck.cards.length}`));

    mountVisual(panel, c);

    if (c.type === "exit") {
      c.qs.forEach((item, idx) => {
        const inp = el("input", { type: "text", placeholder: "Answer", inputmode: "numeric" });
        const res = el("div", { class: "role-muted" });
        const block = el("div", { class: "struct-part" });
        block.appendChild(el("div", { html: formatQuestionHTML(item.q) }));
        block.appendChild(inp);
        block.appendChild(el("button", { class: "btn-secondary btn-sm", onClick: () => {
          const ok = String(inp.value).trim().replace(/\s/g, "") === String(item.a).replace(/\s/g, "");
          res.textContent = ok ? "Yes!" : `Answer: ${item.a}`;
          if (ok) { app.student.xp = (app.student.xp || 0) + 2; app.saveStudent(); }
        } }, "CHECK"));
        block.appendChild(res);
        panel.appendChild(block);
      });
    } else if (c.type === "try") {
      const inp = el("input", { type: "text", placeholder: "Your answer" });
      const res = el("div", { class: "wrap" });
      const block = el("div", { class: "struct-part" });
      block.appendChild(el("div", { style: "font-weight:700;", html: formatQuestionHTML(c.body) }));
      block.appendChild(inp);
      block.appendChild(el("button", { class: "btn", onClick: () => {
        const ok = String(inp.value).trim().replace(/\s/g, "") === String(c.answer).replace(/\s/g, "");
        res.textContent = ok ? `Yes! ${c.tip || ""}` : `Answer: ${c.answer}. ${c.tip || ""}`;
        if (ok) { app.student.xp = (app.student.xp || 0) + 3; app.saveStudent(); }
      } }, "CHECK"));
      block.appendChild(res);
      panel.appendChild(block);
    } else {
      panel.appendChild(el("div", { class: "card", html: formatQuestionHTML(c.body) }));
    }

    const nav = el("div", { class: "btn-row" });
    if (i > 0) nav.appendChild(el("button", { class: "btn-secondary", onClick: () => { i -= 1; render(); } }, "Back"));
    if (i < deck.cards.length - 1) nav.appendChild(el("button", { class: "btn", onClick: () => { i += 1; render(); } }, "Next"));
    else nav.appendChild(el("button", { class: "btn", onClick: () => {
      app.student.xp = (app.student.xp || 0) + 5;
      app.student.credits = (app.student.credits || 0) + 5;
      app.saveStudent();
      app.showPractice();
    } }, "Done · Practice"));
    panel.appendChild(nav);
  }
  render();

  return {
    title: deck.title,
    body: [el("div", { class: "role-subtitle" }, "One card at a time."), panel]
  };
}
