window.WorkspaceEvidenceFolds=(()=>{
  const KEY='mwEvidenceFoldsV1';
  const folds=()=>[...document.querySelectorAll('#gameProfilesPage details[data-evidence-fold]')];
  function load(){if(window.WorkspaceSettings){const v=WorkspaceSettings.migrateLegacy('evidence-folds',KEY,{});return v&&typeof v==='object'&&!Array.isArray(v)?v:{}}try{const v=JSON.parse(localStorage.getItem(KEY)||'{}');return v&&typeof v==='object'&&!Array.isArray(v)?v:{}}catch{return{}}}
  function save(state){if(window.WorkspaceSettings){WorkspaceSettings.set('evidence-folds',state);return}try{localStorage.setItem(KEY,JSON.stringify(state))}catch{}}
  function remember(fold){const key=fold?.dataset?.evidenceFold;if(!key)return;const state=load();state[key]=Boolean(fold.open);save(state)}
  function setAll(open){const state=load();for(const fold of folds()){fold.open=open;state[fold.dataset.evidenceFold]=open}save(state)}
  function init(){
    const state=load();
    for(const fold of folds()){
      const key=fold.dataset.evidenceFold;
      if(Object.prototype.hasOwnProperty.call(state,key))fold.open=Boolean(state[key]);
      fold.addEventListener('toggle',()=>remember(fold));
    }
    document.getElementById('mo2ExpandEvidence')?.addEventListener('click',()=>setAll(true));
    document.getElementById('mo2CollapseEvidence')?.addEventListener('click',()=>setAll(false));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
  return{setAll};
})();
