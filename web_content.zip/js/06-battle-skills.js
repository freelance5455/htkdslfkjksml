/* =========================
   战斗状态与行动阶段
========================= */

function endCheck(){
  if(!s||s.done)return true;

  if(alive(s.enemies).length===0){
    finish(true);
    return true;
  }

  if(alive(s.allies).length===0){
    finish(false);
    return true;
  }

  return false;
}

function useAction(unit){
  if(!unit||unit.hp<=0||unit.acted||s.phase!=='player'||s.done){
    return false;
  }

  unit.acted=true;

  if(unit.stun>0){
    unit.stun--;

    playSound('stun');
    stunFX(unit.id);

    log(`${unit.name}受到眩晕影响，跳过本次行动。`,'bad');

    render();
    checkPlayerPhase();

    return false;
  }

  return true;
}

function checkPlayerPhase(){
  if(!s||s.done||s.phase!=='player')return;

  if(endCheck())return;

  const livingAllies=alive(s.allies);

  if(!livingAllies.length){
    finish(false);
    return;
  }

  if(!livingAllies.every(ally=>ally.acted))return;

  s.phase='enemy';

  log('我方行动结束，敌方开始行动！','system');
  render();

  cancelTimers();

  const battle=s;
  const token=battle.token;

  enemyTimer=setTimeout(()=>{
    enemyTimer=null;

    if(!validBattle(battle,token)||battle.phase!=='enemy')return;

    enemyPhase(battle,token);
  },500);
}

function validBattle(battle,token){
  return s===battle&&!battle.done&&battle.token===token;
}

/* =========================
   杰瑞技能
========================= */

function jerryAttack(id){
  const unit=getUnit('jerry');
  const target=getUnit(id);

  if(!unit||!target||target.hp<=0||!useAction(unit))return;

  playSound('hammer');
  skillLabel('jerry','🔨 大铁锤！');
  projectile('jerry',id,'🔨');

  target.hp=Math.max(0,target.hp-25);
  damageFX(id,25);

  log(`杰瑞使用「大铁锤」，对${target.name}造成25点伤害。`,'good');

  render();

  if(!endCheck())checkPlayerPhase();
}

function defend(){
  const unit=getUnit('jerry');

  if(!useAction(unit))return;

  playSound('shield');
  skillLabel('jerry','🛡️ 团队防护！');

  alive(s.allies).forEach(a=>{
    a.reduction=2;
    shieldFX(a.id);
  });

  log('杰瑞使用「团队防护」！我方全体获得2次敌方攻击的30%减伤。','good');

  render();
  checkPlayerPhase();
}
/* =========================
   泰菲技能
========================= */

function rocket(){
  const unit=getUnit('tuffy');

  if(!unit||!useAction(unit))return;

  playSound('rocket');
  skillLabel('tuffy','🚀 火箭筒发射！');
  rocketReadyFX('tuffy');

  alive(s.enemies).slice().forEach(enemy=>{
    projectile('tuffy',enemy.id,'🚀');

    enemy.hp=Math.max(0,enemy.hp-20);
    damageFX(enemy.id,20,'💥');

    log(`泰菲发射火箭筒，对${enemy.name}造成20点伤害。`,'good');
  });

  render();

  if(!endCheck())checkPlayerPhase();
}

async function heal(){
  const unit=getUnit('tuffy');

  if(!unit||unit.hp<=0||!useAction(unit))return;

  unit.max+=30;
  unit.tempMaxHp=(unit.tempMaxHp||0)+30;

  playSound('cake');
  skillLabel('tuffy','🍰 奶酪蛋糕！');

  log('泰菲使用「奶酪蛋糕」，最大HP立即增加30点；然后恢复35点当前HP。','good');

  render();

  const battle=s;
  const token=battle.token;

  await sleep(0);

  if(!validBattle(battle,token)||unit.hp<=0)return;

  const before=unit.hp;

  unit.hp=Math.min(unit.max,unit.hp+35);

  const restored=unit.hp-before;

  healFX('tuffy','tuffy',restored);

  log(`奶酪蛋糕生效，泰菲恢复${restored}点当前HP（当前HP不会超过最大HP）。`,'good');

  render();

  if(!endCheck())checkPlayerPhase();
}
/* =========================
   雪梨技能
========================= */

function shirleyPunch(){
  const unit=getUnit('shirley');

  if(!unit||!useAction(unit))return;

  const targets=alive(s.enemies);

  if(!targets.length){
    endCheck();
    return;
  }

  const target=targets[Math.floor(Math.random()*targets.length)];

  playSound('punch');
  skillLabel('shirley','👊 雪梨拳击！');
  projectile('shirley',target.id,'👊');

  target.hp=Math.max(0,target.hp-20);

  damageFX(target.id,20);

  log(`雪梨使用「拳击」，对${target.name}造成20点伤害。`,'good');

  render();

  if(!endCheck())checkPlayerPhase();
}

function loveBouquet(){
  const unit=getUnit('shirley');

  if(!unit||!useAction(unit))return;

  playSound('flowers');
  skillLabel('shirley','💐 爱心花束！');

  let total=0;

  alive(s.allies).forEach(ally=>{
    const amount=Math.floor(ally.max*.2);
    const before=ally.hp;

    ally.hp=Math.min(ally.max,ally.hp+amount);

    const restored=ally.hp-before;
    total+=restored;

    bouquetFX(ally.id,restored);
  });

  log(`雪梨使用「爱心花束」，为存活队友恢复各自最大HP的20%，实际共恢复${total}点HP。`,'good');

  render();
  checkPlayerPhase();
}
/* =========================
   剑客杰瑞技能
========================= */

function swordDance(id){
  const unit=getUnit('swordsman');
  const target=getUnit(id);

  if(!unit||!target||target.hp<=0||!useAction(unit))return;

  playSound('sword');
  skillLabel('swordsman','🗡️ 剑舞！');
  projectile('swordsman',id,'🗡️');

  target.hp=Math.max(0,target.hp-30);

  damageFX(id,30);

  log(`剑客杰瑞使用「剑舞」，对${target.name}造成30点伤害。`,'good');

  render();

  if(!endCheck())checkPlayerPhase();
}

function swordGuard(){
  const unit=getUnit('swordsman');

  if(!unit||unit.guardCd>0||unit.guard||!useAction(unit))return;

  unit.guard=true;
  unit.guardCd=1;
  unit.guardUsedThisRound=true;

  playSound('shield');
  skillLabel('swordsman','🛡️ 格挡！');
  shieldFX('swordsman');

  log('剑客杰瑞使用「格挡」！持续至敌方全员完成本轮行动，期间免疫控制；受击且存活时反击40点伤害。格挡进入冷却。','good');

  render();
  checkPlayerPhase();
}
/* =========================
   恶魔杰瑞技能与仇恨系统
========================= */

/*
 * 设置某名敌人的仇恨目标。
 * 每名敌人只能有一个仇恨目标。
 * 新仇恨立即替换原有仇恨。
 */
function setHate(enemy,targetId){
  enemy.hateTarget=targetId;
  enemy.hateTurns=1;
}

/*
 * 清除本轮敌方行动结束后应该消失的仇恨。
 * 仇恨在下一次敌方行动阶段中生效。
 */
function clearEnemyHate(){
  if(!s)return;

  s.enemies.forEach(enemy=>{
    if(enemy.hateTurns>0){
      enemy.hateTurns--;
    }

    if(enemy.hateTurns<=0){
      enemy.hateTurns=0;
      enemy.hateTarget=null;
    }
  });
}

/*
 * 三叉戟：
 * 选择一名敌人造成25点伤害，
 * 并使该敌人下一轮单体攻击仇恨恶魔杰瑞。
 */
function demonTrident(id){
  const unit=getUnit('demon');
  const target=getUnit(id);

  if(!unit||!target||target.hp<=0||!useAction(unit))return;

  playSound('sword');
  skillLabel('demon','🔱 三叉戟！');
  projectile('demon',target.id,'🔱');

  target.hp=Math.max(0,target.hp-25);

  setHate(target,'demon');

  damageFX(target.id,25,'💥');

  log(
    `恶魔杰瑞使用「三叉戟」，对${target.name}造成25点伤害，并使其仇恨恶魔杰瑞一轮。`,
    'good'
  );

  render();

  if(!endCheck())checkPlayerPhase();
}

/*
 * 诅咒符纸：
 * 选择一名我方角色。
 * 该角色持续到敌方全员完成本轮行动前都处于诅咒状态。
 * 所有敌人立刻仇恨该角色。
 */
function demonCurse(allyId){
  const unit=getUnit('demon');
  const target=getUnit(allyId);

  if(!unit||!target||target.hp<=0)return;

  // 符咒冷却：使用后跳过下一整轮，之后恢复可用。
  if(unit.curseCooldownUntilRound && s.round < unit.curseCooldownUntilRound){
    log(`诅咒符纸还在冷却中，下一轮结束后才能再次使用。`,'system');
    render();
    return;
  }

  if(!useAction(unit))return;

  playSound('curse');
  skillLabel('demon','📜 诅咒符纸！');
  shieldFX(target.id,'💀 诅咒！');

  // 恢复诅咒状态：敌人攻击该角色后，其下一次攻击降低30%攻击力
  target.cursed=true;
  unit.curseCooldownUntilRound=s.round+2;

  s.enemies.forEach(enemy=>{
    setHate(enemy,target.id);
  });

  log(
    `恶魔杰瑞使用「诅咒符纸」，${target.name}进入诅咒状态，所有敌人改为仇恨1回合${target.name}。`,
    'good'
  );

  log(
    `诅咒规则：敌人攻击${target.name}后，该敌人的下一次攻击攻击力降低30%。`,
    'system'
  );

  render();
  checkPlayerPhase();
}

function pass(id){
  const unit=getUnit(id);

  if(!useAction(unit))return;

  log(`${unit.name}选择空过本次行动。`,'system');

  render();
  checkPlayerPhase();
}
