/* tech-ui.js — Phase 7 interface: Research screen (Research / Doctrine / Researched). */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const me = () => G.state.player;
  const f1 = n => (Math.round(n * 10) / 10).toFixed(1);
  let tab = 'research';

  const bar = f => '<div class="bar"><i style="width:' + Math.max(0, Math.min(100, f * 100)).toFixed(0) + '%"></i></div>';

  G.showTech = function (which) {
    if (which) tab = which;
    const st = G.state, id = me(), r = st.tech[id];
    const names = { research: 'Research', doctrine: 'Doctrine', done: 'Researched (' + Object.keys(r.done).length + ')' };
    let h = '<h3>🔬 Research — ' + G.COUNTRIES[id].name + '</h3><div class="tabs">' +
      Object.keys(names).map(t => '<button data-t="' + t + '" class="' + (tab === t ? 'on' : '') + '">' + names[t] + '</button>').join('') + '</div>';
    h += ({ research: researchTab, doctrine: doctrineTab, done: doneTab })[tab](id, r);
    h += '<div class="row"><button id="tc-close">Close</button></div>';
    $('modal-box').innerHTML = h; $('modal').classList.remove('hidden');
    const box = $('modal-box');
    $('tc-close').onclick = G.closeModal;
    box.querySelectorAll('.tabs button[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; G.showTech(); });
    const act = (sel, fn) => box.querySelectorAll(sel).forEach(b => b.onclick = () => { const x = fn(b); if (x && x.msg) G.toast(x.msg); G.updateTopBar(); G.showTech(); });
    act('[data-start]', b => G.startResearch(id, b.dataset.start));
    act('[data-stop]', b => { G.cancelResearch(id, b.dataset.stop); return { msg: 'Research stopped (progress kept)' }; });
    act('[data-doc]', b => G.setDoctrine(id, b.dataset.doc));
  };

  function researchTab(id, r) {
    const st = G.state, slots = G.researchSlots(id);
    let h = '<div class="eqline">Research ' + f1(G.researchRate(id)) + ' pts/day · slots ' + r.active.length + ' / ' + slots + (r.doctrine ? '' : ' · ⚠ no doctrine chosen') + '</div>';
    h += '<p class="dim" style="font-size:12px">Civilian factories and provinces produce research. Points are split between active projects. Allies researching the same tech speed you up by 25%.</p>';
    if (r.active.length) {
      h += '<h3>In progress</h3>' + r.active.map(t => {
        const T = G.TECH[t], p = r.prog[t] || 0;
        return '<div class="slot"><div class="info"><b>' + G.BRANCHES[T.branch].icon + ' ' + T.name + '</b> <small>' + Math.floor(p) + ' / ' + T.cost + ' · ~' + G.techEta(id, t) + ' days</small><br><small>' + T.desc + '</small>' + bar(p / T.cost) + '</div><button data-stop="' + t + '">Stop</button></div>';
      }).join('');
    }
    for (const b in G.BRANCHES) {
      const list = G.TECHS.filter(t => t.branch === b);
      h += '<h3>' + G.BRANCHES[b].icon + ' ' + G.BRANCHES[b].name + '</h3>';
      h += list.map(T => {
        if (r.done[T.id]) return '<div class="slot" style="opacity:.6"><div class="info"><b>✓ ' + T.name + '</b><br><small>' + T.desc + '</small></div></div>';
        if (r.active.includes(T.id)) return '';
        const av = G.techAvailable(id, T.id), p = r.prog[T.id] || 0;
        return '<div class="slot"><div class="info"><b>' + T.name + '</b> <small>cost ' + T.cost + (p ? ' · ' + Math.floor(p) + ' done' : '') + (av.ok || /slots/.test(av.msg) ? ' · ~' + G.techEta(id, T.id) + ' days' : '') + '</small><br><small>' + T.desc + '</small>' +
          (av.ok ? '' : '<br><small style="color:#e0a090">' + av.msg + '</small>') + '</div><button data-start="' + T.id + '"' + (av.ok ? '' : ' disabled') + '>Research</button></div>';
      }).join('');
    }
    return h;
  }

  function doctrineTab(id, r) {
    const st = G.state, L = G.doctrineLevel(id);
    let h = '<div class="eqline">Doctrine level ' + L + ' (raised by Doctrinal Studies)</div>';
    if (!r.doctrine) h += '<div class="alert">Choose your army doctrine — the first choice is free.</div>';
    else h += '<p class="dim" style="font-size:12px">Changing doctrine costs 💰 ' + G.DOCTRINE_SWITCH_COST + ' and can only be done every 60 days.</p>';
    for (const d in G.DOCTRINES) {
      const D = G.DOCTRINES[d], on = r.doctrine === d;
      const eff = Object.keys(D.base).map(k => k.replace(/_/g, ' ') + ' +' + Math.round((D.base[k] + D.per[k] * L) * 100) + '%').join(', ');
      h += '<div class="slot"><div class="info"><b>' + D.icon + ' ' + D.name + (on ? ' — active' : '') + '</b><br><small>' + D.desc + '</small><br><small>Now: ' + eff + '</small></div>' +
        (on ? '' : '<button data-doc="' + d + '">' + (r.doctrine ? 'Switch' : 'Adopt') + '</button>') + '</div>';
    }
    return h;
  }

  function doneTab(id, r) {
    const tot = {};
    ['atk_all', 'def_all', 'atk_inf', 'def_inf', 'atk_arm', 'def_arm', 'atk_art', 'siege', 'speed', 'supply', 'reinforce', 'industry', 'resources', 'mining', 'food', 'construction', 'tax', 'manpower', 'research', 'trade', 'spy', 'netgrowth', 'naval_atk', 'naval_def', 'asw', 'naval_speed', 'convoy'].forEach(k => { const v = G.techEff(id, k); if (v) tot[k] = v; });
    let h = '<div class="eqline">Total bonuses: ' + (Object.keys(tot).length ? Object.keys(tot).map(k => k.replace(/_/g, ' ') + ' +' + Math.round(tot[k] * 100) + '%').join(', ') : 'none') + '</div>';
    h += '<div class="eqline">Fortification level allowed: ' + G.fortLevelAllowed(id) + '</div>';
    const done = G.TECHS.filter(t => r.done[t.id]);
    return h + (done.length ? done.map(T => '<div class="slot"><div class="info"><b>' + G.BRANCHES[T.branch].icon + ' ' + T.name + '</b><br><small>' + T.desc + '</small></div></div>').join('') : '<p class="dim">Nothing researched yet.</p>');
  }

  G.onTechDone = function () { /* toast already shown */ };
  G.bindTechUI = function () { $('btn-tech').onclick = () => { tab = 'research'; G.showTech(); }; };
})(window.EMP = window.EMP || {});
