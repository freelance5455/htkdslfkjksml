document.addEventListener("DOMContentLoaded", () => {
  const grid = document.getElementById("subjectGrid");
  const render = () => {
    const saved = JSON.parse(localStorage.getItem("msl_subjects") || "null");
    const subjects = saved || MSL.subjects;
    grid.innerHTML = subjects.map(s => `
      <button class="subject-card" data-subject="${s.id}" data-name="${escapeHtml(s.name)}">
        <div class="subject-icon">${s.icon}</div>
        <b>${escapeHtml(s.name)}</b>
        <small>${escapeHtml(s.description || "Espace de cours")}</small>
      </button>`).join("");
  };
  const escapeHtml = s => String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  render();

  grid.addEventListener("click", e => {
    const card = e.target.closest("[data-subject]");
    if(!card) return;
    if(window.openSubjectFolder) window.openSubjectFolder(card.dataset.subject, card.dataset.name);
  });

  document.getElementById("addSubjectBtn").onclick = () => {
    const name = prompt("Nom de la nouvelle matière :");
    if(!name || !name.trim()) return;
    const current = JSON.parse(localStorage.getItem("msl_subjects") || "null") || MSL.subjects.slice();
    current.push({id:"custom_"+Date.now(), name:name.trim(), icon:"✎", className:"purple", description:"Matière personnalisée"});
    localStorage.setItem("msl_subjects", JSON.stringify(current));
    render();
    if(window.refreshDocumentFilters) window.refreshDocumentFilters();
    showToast("Matière ajoutée");
  };
});