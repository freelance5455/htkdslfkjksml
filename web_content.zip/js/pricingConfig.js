/**
 * pricingConfig.js
 * Regras de precificação CONFIGURÁVEIS (nada de machine learning nesta etapa).
 * Tudo aqui é um número/lista que pode ser editado sem tocar na lógica do
 * pricingService.js — isso é a "estrutura para futuramente usar modelos de
 * previsão" pedida: quando houver dados reais, este objeto pode ser gerado/
 * ajustado por estatística em vez de escrito à mão.
 */
const PRICING_CONFIG = {
  moeda: 'BRL',

  precoBase: {
    Limpeza: {
      'padrão': 90,
      'pesada': 180,
      'pós-obra': 230,
      'outro': 100, // fallback de segurança para valores antigos/legados
    },
    'Pequenos Reparos': null, // normalmente exige avaliação — ver `necessitaAvaliacao`
    'Roupa de cama / Enxoval': {
      porKit: 18, // valor por kit de enxoval solicitado
    },
  },

  // Acréscimo por característica extra do imóvel (limpeza)
  acrescimoPorQuarto: 12,
  acrescimoPorBanheiro: 10,
  acrescimoPorCama: 6,
  acrescimoAmbienteExtra: 8, // cozinha, sala ou varanda marcados

  // Multiplicadores (aplicados sobre o subtotal)
  multiplicadorFimDeSemana: 1.15,   // sábado/domingo
  multiplicadorForaHorarioComercial: 1.10, // antes das 7h ou depois das 19h
  multiplicadorTemporadaAlta: 1.20,  // dezembro a março (verão litoral)
  multiplicadorFeriado: 1.25,

  multiplicadorUrgencia: {
    'Programado': 1.0,
    'Hoje': 1.15,
    'Urgente (poucas horas)': 1.30,
  },

  // Comissão da plataforma sobre o valor do serviço, por categoria
  comissaoPlataforma: {
    Limpeza: 0.15,
    'Pequenos Reparos': 0.12,
    'Roupa de cama / Enxoval': 0.10,
  },

  // Taxa de conveniência cobrada do anfitrião (adicional, não sai do profissional)
  taxaConveniencia: 0.05,

  // Dedução informativa por deslocamento do profissional (não altera o valor
  // cobrado do anfitrião — só o quanto sobra pro profissional naquela oportunidade)
  deducaoPorKmDeslocamento: 1.5,
  kmIsentosDeslocamento: 3,

  // Feriados fixos nacionais (formato MM-DD) — lista simples, sem cálculo de
  // feriados móveis (Carnaval/Páscoa) nesta etapa.
  feriadosFixos: ['01-01','04-21','05-01','09-07','10-12','11-02','11-15','12-25'],

  mesesTemporadaAlta: [12, 1, 2, 3], // litoral: verão
};
