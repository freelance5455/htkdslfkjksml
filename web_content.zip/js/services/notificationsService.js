/**
 * notificationsService.js — notificações internas simples (sem push real).
 */
const NotificationsService = {
  criar(userId, tipo, titulo, mensagem){
    return DB.insert('notifications', Models.novaNotificacao({ user_id: userId, tipo, titulo, mensagem }));
  },
  listarDoUsuario(userId){
    return DB.list('notifications', n => n.user_id === userId).sort((a,b)=> new Date(b.created_at)-new Date(a.created_at));
  },
  naoLidas(userId){
    return this.listarDoUsuario(userId).filter(n => !n.lida).length;
  },
  marcarLida(notifId){
    return DB.update('notifications', notifId, { lida: true });
  },
};
