/**
 * disputesService.js
 * Fluxo: profissional abre divergência (com evidências) → anfitrião é
 * notificado → anfitrião responde (com evidências) → decisão é registrada
 * (quem decide hoje: administrador — não há "IA decisora"). A plataforma
 * NUNCA decide sozinha nem acredita automaticamente em nenhum dos lados: a
 * decisão é sempre um ato humano registrado, à vista do snapshot original,
 * alterações formais, chat e evidências.
 */
const DisputesService = {

  /** Status em que faz sentido abrir uma divergência (serviço já em pré-vistoria ou execução). */
  ORIGENS_VALIDAS: [STATUS_SOLICITACAO.CHECKING, STATUS_SOLICITACAO.IN_PROGRESS, STATUS_SOLICITACAO.UNDER_REVIEW],

  abrirDivergencia(providerId, requestId, { motivo, severidade, descricao, fotos, videos, gps }){
    const solicitacao = DB.find('service_requests', requestId);
    if(!solicitacao || solicitacao.accepted_provider_id !== providerId) throw new Error('Você não está atribuído a esta solicitação.');
    if(!MOTIVOS_DIVERGENCIA.includes(motivo)) throw new Error('Motivo de divergência inválido.');
    if(!SEVERIDADES_DIVERGENCIA.includes(severidade)) throw new Error('Severidade de divergência inválida.');
    if(BLOQUEIOS_CONFIG.severidadesExigemFoto.includes(severidade) && (!fotos || fotos.length === 0)){
      throw new Error('Esta severidade exige ao menos uma foto como evidência.');
    }
    if(!this.ORIGENS_VALIDAS.includes(solicitacao.status)){
      throw new Error('Não é possível abrir divergência no status atual desta solicitação.');
    }

    const userId = DB.find('providers', providerId).user_id;
    const evidencia = EvidencesService.registrar({ service_request_id: requestId, user_id: userId, tipo:'divergencia_aberta', texto: descricao, fotos, videos, gps });

    const divergencia = DB.insert('disputes', Models.novaDivergencia({ service_request_id: requestId, aberta_por_user_id: userId, motivo, severidade, descricao, evidencia_id: evidencia.id, status_antes_disputa: solicitacao.status }));

    DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.DISPUTED });
    OccurrencesService.registrar(providerId, 'divergencia', motivo, { serviceRequestId: requestId, registradoPor: userId });
    PaymentsService.colocarEmDisputa(requestId);

    ChatService.mensagemSistema(requestId, `⚠️ Divergência aberta pelo profissional: "${motivo}". O pagamento permanece retido até a decisão.`);
    NotificationsService.criar(solicitacao.owner_id, 'divergencia', 'Divergência aberta pelo profissional', `O profissional relatou: ${motivo}. Responda com sua versão o quanto antes.`);
    AuditLogService.registrar({ user_id: userId, acao:'abrir_divergencia', entidade:'service_requests', entidade_id:requestId, dados_novos:{ motivo, divergencia_id: divergencia.id } });
    return divergencia;
  },

  responderAnfitriao(ownerId, disputeId, { texto, fotos, videos }){
    const divergencia = DB.find('disputes', disputeId);
    if(!divergencia) throw new Error('Divergência não encontrada.');
    const solicitacao = DB.find('service_requests', divergencia.service_request_id);
    if(!solicitacao || solicitacao.owner_id !== ownerId) throw new Error('Você não tem permissão para responder esta divergência.');
    if(divergencia.status !== 'aberta') throw new Error('Esta divergência já foi respondida ou decidida.');

    const evidencia = EvidencesService.registrar({ service_request_id: solicitacao.id, user_id: ownerId, tipo:'divergencia_resposta', texto, fotos, videos });
    const atualizada = DB.update('disputes', disputeId, { status: 'respondida', resposta_anfitriao: { texto, evidencia_id: evidencia.id, em: new Date().toISOString() } });

    ChatService.mensagemSistema(solicitacao.id, '💬 Anfitrião respondeu à divergência. Aguardando análise.');
    AuditLogService.registrar({ user_id: ownerId, acao:'responder_divergencia', entidade:'service_requests', entidade_id:solicitacao.id, dados_novos:{ divergencia_id: disputeId } });
    return atualizada;
  },

  /**
   * Decisão — hoje tomada por um administrador (não há "IA" nem decisão
   * automática). `decisaoDe`: 'anfitriao' | 'profissional' | 'parcial'.
   * Se `aplicarTaxa` e a responsabilidade for do anfitrião, desconta a taxa
   * de deslocamento/disponibilidade dos fundos e destina ao profissional.
   */
  decidir(adminUserId, disputeId, { decisaoDe, texto, aplicarTaxa, valorTaxa, retomarServico }){
    const divergencia = DB.find('disputes', disputeId);
    if(!divergencia) throw new Error('Divergência não encontrada.');
    const solicitacao = DB.find('service_requests', divergencia.service_request_id);

    const decisao = { decisao_de: decisaoDe, responsavel: adminUserId, aplicar_taxa: !!aplicarTaxa, valor_taxa: aplicarTaxa ? valorTaxa : 0, texto, em: new Date().toISOString() };
    const atualizada = DB.update('disputes', disputeId, { status: 'decidida', decisao });

    if(aplicarTaxa && valorTaxa > 0){
      PaymentsService.aplicarTaxaDeslocamento(solicitacao.id, valorTaxa, adminUserId, `Divergência #${disputeId}: ${texto}`);
    }

    // Bloqueio configurável (BLOQUEIOS_CONFIG): severidades altas/críticas nunca
    // retomam o serviço automaticamente, mesmo que o admin tenha marcado a opção —
    // exige revisão adicional antes de reabrir o fluxo operacional.
    if(retomarServico && BLOQUEIOS_CONFIG.severidadesBloqueiamRetomadaAutomatica.includes(divergencia.severidade)){
      ChatService.mensagemSistema(solicitacao.id, `⚠️ Divergência de severidade "${divergencia.severidade}" decidida. Retomada automática bloqueada por política — requer nova ação manual do administrador.`);
      NotificationsService.criar(solicitacao.owner_id, 'contestacao', 'Decisão registrada — retomada bloqueada', 'A divergência foi decidida, mas a severidade exige revisão manual antes de retomar o serviço.');
      AuditLogService.registrar({ user_id: adminUserId, acao:'decidir_divergencia', entidade:'service_requests', entidade_id:solicitacao.id, dados_novos:decisao });
      return atualizada;
    }

    if(retomarServico){
      // Retoma para o status em que a solicitação estava quando a divergência foi
      // aberta (CHECKING, IN_PROGRESS ou UNDER_REVIEW) — nunca força IN_PROGRESS
      // se o serviço ainda não tinha realmente começado.
      const alvo = (divergencia.status_antes_disputa && transicaoPermitida(STATUS_SOLICITACAO.DISPUTED, divergencia.status_antes_disputa))
        ? divergencia.status_antes_disputa
        : STATUS_SOLICITACAO.IN_PROGRESS;
      DB.update('service_requests', solicitacao.id, { status: alvo });
      PaymentsService.retomarAposDisputa(solicitacao.id);
      ChatService.mensagemSistema(solicitacao.id, `✅ Divergência decidida: ${texto}. Serviço retomado.`);
    } else {
      ChatService.mensagemSistema(solicitacao.id, `✅ Divergência decidida: ${texto}.`);
    }

    const provider = DB.find('providers', solicitacao.accepted_provider_id);
    if(provider) NotificationsService.criar(provider.user_id, 'contestacao', 'Decisão registrada', 'A divergência que você abriu foi analisada. Confira a decisão.');
    NotificationsService.criar(solicitacao.owner_id, 'contestacao', 'Decisão registrada', 'A divergência do seu serviço foi analisada. Confira a decisão.');

    AuditLogService.registrar({ user_id: adminUserId, acao:'decidir_divergencia', entidade:'service_requests', entidade_id:solicitacao.id, dados_novos:decisao });
    return atualizada;
  },

  listarPorSolicitacao(requestId){
    return DB.list('disputes', d => d.service_request_id === requestId).sort((a,b)=> new Date(b.created_at)-new Date(a.created_at));
  },
  listarAbertas(){
    return DB.list('disputes', d => d.status !== 'decidida');
  },
  obter(disputeId){ return DB.find('disputes', disputeId); },
};
