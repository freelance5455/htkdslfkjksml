/**
 * roomsService.js
 * Ambientes/cômodos cadastrados individualmente para um imóvel, cada um com
 * suas próprias fotos e (opcionalmente) um vídeo. Usado para dar contexto
 * detalhado ao profissional e para compor o checklist de pré-vistoria.
 */
const RoomsService = {
  criar(ownerId, propertyId, { nome, observacoes, fotos, video }){
    const imovel = PropertiesService.obterSeDono(ownerId, propertyId);
    if(!imovel) throw new Error('Você não tem permissão para editar este imóvel.');
    const ambiente = DB.insert('property_rooms', Models.novoAmbiente({ property_id: propertyId, nome, observacoes, fotos, video }));
    AuditLogService.registrar({ user_id: ownerId, acao:'criar_ambiente', entidade:'property_rooms', entidade_id:ambiente.id, dados_novos:{ nome, property_id: propertyId } });
    return ambiente;
  },

  atualizar(ownerId, roomId, patch){
    const ambiente = DB.find('property_rooms', roomId);
    if(!ambiente) throw new Error('Ambiente não encontrado.');
    const imovel = PropertiesService.obterSeDono(ownerId, ambiente.property_id);
    if(!imovel) throw new Error('Você não tem permissão para editar este ambiente.');
    const atualizado = DB.update('property_rooms', roomId, patch);
    AuditLogService.registrar({ user_id: ownerId, acao:'editar_ambiente', entidade:'property_rooms', entidade_id:roomId, dados_novos:Object.keys(patch) });
    return atualizado;
  },

  remover(ownerId, roomId){
    const ambiente = DB.find('property_rooms', roomId);
    if(!ambiente) return false;
    const imovel = PropertiesService.obterSeDono(ownerId, ambiente.property_id);
    if(!imovel) throw new Error('Você não tem permissão para remover este ambiente.');
    DB._deleteHard('property_rooms', roomId);
    AuditLogService.registrar({ user_id: ownerId, acao:'remover_ambiente', entidade:'property_rooms', entidade_id:roomId });
    return true;
  },

  listarPorImovel(propertyId){
    return DB.list('property_rooms', r => r.property_id === propertyId);
  },
};
