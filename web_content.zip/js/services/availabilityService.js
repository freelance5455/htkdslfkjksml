/**
 * availabilityService.js — agenda de disponibilidade dos profissionais.
 * (Sem lógica de reserva/matching ainda — isso fica para a próxima etapa.)
 */
const AvailabilityService = {
  adicionar(providerId, { data, horario_inicio, horario_fim }){
    return DB.insert('availability', Models.novaDisponibilidade({ provider_id: providerId, data, horario_inicio, horario_fim }));
  },
  listarDoProvider(providerId){
    return DB.list('availability', a => a.provider_id === providerId);
  },
  remover(providerId, availabilityId){
    const item = DB.find('availability', availabilityId);
    if(!item || item.provider_id !== providerId) return false;
    DB._deleteHard('availability', availabilityId);
    return true;
  },
};
