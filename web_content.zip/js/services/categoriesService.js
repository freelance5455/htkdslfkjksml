/**
 * categoriesService.js — categorias de serviço (Faxina, Manutenção, Roupa de cama...).
 */
const CategoriesService = {
  listarAtivas(){ return DB.list('service_categories', c => c.status === 'ativo'); },
  listarTodas(){ return DB.list('service_categories'); },
  criar(nome){ return DB.insert('service_categories', Models.novaCategoria({ nome })); },
  seedPadrao(){
    // Os nomes precisam bater exatamente com CATEGORIAS_SERVICO (statusMachine.js),
    // pois o matching e a precificação comparam essas strings diretamente.
    DB._seed('service_categories', [
      Object.assign({ id: 1 }, Models.novaCategoria({ nome: CATEGORIAS_SERVICO.LIMPEZA })),
      Object.assign({ id: 2 }, Models.novaCategoria({ nome: CATEGORIAS_SERVICO.REPAROS })),
      Object.assign({ id: 3 }, Models.novaCategoria({ nome: CATEGORIAS_SERVICO.ENXOVAL })),
    ]);
  },
};
