/**
 * evidencesService.js
 * Toda ocorrência relevante (deslocamento, chegada, divergência, finalização)
 * gera um registro aqui: quem, quando, onde (GPS quando houver), em qual
 * solicitação, tipo, texto e mídia. É o material usado depois numa decisão
 * de disputa (nunca se decide só com a palavra de uma das partes).
 */
const EvidencesService = {
  registrar({ service_request_id, user_id, tipo, texto, fotos, videos, gps }){
    return DB.insert('evidences', Models.novaEvidencia({ service_request_id, user_id, tipo, texto, fotos, videos, gps }));
  },
  listarPorSolicitacao(requestId){
    return DB.list('evidences', e => e.service_request_id === requestId)
      .sort((a,b)=> new Date(a.created_at) - new Date(b.created_at));
  },
};
