/**
 * termsService.js
 * Controla o aceite versionado de termos. `service_request_id` é opcional:
 * quando presente, o aceite fica vinculado a um serviço específico (ex.:
 * vistoria de entrada/saída do profissional) em vez de valer para o usuário
 * de forma geral (como o TERMO_INTERMEDIACAO, aceito uma vez por anfitrião).
 */
const TermsService = {
  jaAceitou(userId, tipo, versao, serviceRequestId){
    return !!DB.findOne('term_acceptances', a =>
      a.user_id === userId && a.tipo === tipo && a.versao === versao &&
      (serviceRequestId === undefined || a.service_request_id === serviceRequestId)
    );
  },

  registrarAceite(userId, tipo, { nome, cpf, versao, service_request_id }){
    if(!nome || !nome.trim()) throw new Error('Informe seu nome completo para aceitar o termo.');
    if(!cpf || !cpf.trim()) throw new Error('Informe seu CPF para aceitar o termo.');
    const aceite = DB.insert('term_acceptances', Models.novoAceiteTermo({ user_id: userId, tipo, nome, cpf, versao, service_request_id }));
    AuditLogService.registrar({ user_id: userId, acao:'aceitar_termo', entidade:'term_acceptances', entidade_id:aceite.id, dados_novos:{ tipo, versao, service_request_id: service_request_id || null } });
    return aceite;
  },

  listarAceites(userId){
    return DB.list('term_acceptances', a => a.user_id === userId);
  },
};
