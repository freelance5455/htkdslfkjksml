/**
 * inventoryService.js
 * Inventário de itens vinculado ao imóvel (e opcionalmente a um ambiente
 * específico), com estado de conservação e evidências. Serve de referência
 * objetiva para comparar o que foi declarado com o que o profissional
 * encontra na pré-vistoria (checklistService.js usa isso como base).
 */
const InventoryService = {
  ESTADOS: Models.ESTADOS_INVENTARIO,

  criarItem(ownerId, propertyId, { room_id, item, quantidade, estado, observacao, evidencias }){
    const imovel = PropertiesService.obterSeDono(ownerId, propertyId);
    if(!imovel) throw new Error('Você não tem permissão para editar este imóvel.');
    if(!this.ESTADOS.includes(estado)) throw new Error('Estado de conservação inválido.');
    const registro = DB.insert('property_inventory', Models.novoItemInventario({ property_id: propertyId, room_id, item, quantidade, estado, observacao, evidencias }));
    AuditLogService.registrar({ user_id: ownerId, acao:'criar_item_inventario', entidade:'property_inventory', entidade_id:registro.id, dados_novos:{ item, estado, property_id: propertyId } });
    return registro;
  },

  atualizarItem(ownerId, itemId, patch){
    const registro = DB.find('property_inventory', itemId);
    if(!registro) throw new Error('Item de inventário não encontrado.');
    const imovel = PropertiesService.obterSeDono(ownerId, registro.property_id);
    if(!imovel) throw new Error('Você não tem permissão para editar este item.');
    if(patch.estado && !this.ESTADOS.includes(patch.estado)) throw new Error('Estado de conservação inválido.');
    const atualizado = DB.update('property_inventory', itemId, patch);
    AuditLogService.registrar({ user_id: ownerId, acao:'editar_item_inventario', entidade:'property_inventory', entidade_id:itemId, dados_novos:Object.keys(patch) });
    return atualizado;
  },

  remover(ownerId, itemId){
    const registro = DB.find('property_inventory', itemId);
    if(!registro) return false;
    const imovel = PropertiesService.obterSeDono(ownerId, registro.property_id);
    if(!imovel) throw new Error('Você não tem permissão para remover este item.');
    DB._deleteHard('property_inventory', itemId);
    AuditLogService.registrar({ user_id: ownerId, acao:'remover_item_inventario', entidade:'property_inventory', entidade_id:itemId });
    return true;
  },

  listarPorImovel(propertyId){
    return DB.list('property_inventory', i => i.property_id === propertyId);
  },
};
