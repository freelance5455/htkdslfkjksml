/**
 * auditLogService.js — trilha de auditoria (quem fez o quê, quando).
 * Usado por auth.js e pelos demais services para registrar ações sensíveis.
 */
const AuditLogService = {
  registrar({ user_id, acao, entidade, entidade_id, dados_anteriores, dados_novos }){
    return DB.insert('audit_logs', Models.novoAuditLog({ user_id, acao, entidade, entidade_id, dados_anteriores, dados_novos }));
  },
  listarRecentes(limite = 50){
    return DB.list('audit_logs')
      .sort((a,b)=> new Date(b.created_at)-new Date(a.created_at))
      .slice(0, limite);
  },
};
