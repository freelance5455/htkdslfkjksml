/**
 * paymentsService.js
 *
 * ⚠️ Ver paymentGatewayAdapter.js: nenhum dinheiro real é movimentado aqui.
 * Esta é a ARQUITETURA (estados, separação de valores, service layer) pronta
 * para plugar um gateway real de marketplace. Uma linha em `payments` por
 * solicitação, sempre com valor do anfitrião, do profissional, comissão da
 * plataforma e taxa de conveniência separados — nunca um valor único.
 */
const PaymentsService = {

  /** Cria o registro financeiro e já simula autorização + retenção (HELD). */
  async criarEAutorizar(requestId){
    const solicitacao = DB.find('service_requests', requestId);
    if(!solicitacao || !solicitacao.precificacao) throw new Error('Solicitação sem precificação — não é possível criar o pagamento.');
    if(solicitacao.precificacao.necessitaAvaliacao) return null; // sem valor definido ainda — pagamento é criado depois do orçamento

    const existente = this.obterPorSolicitacao(requestId);
    if(existente) return existente;

    const p = solicitacao.precificacao;
    let pagamento = DB.insert('payments', Models.novoPagamento({
      service_request_id: requestId,
      valor_anfitriao: p.valorAnfitriao, valor_profissional: p.valorProfissional,
      comissao_plataforma: p.comissaoPlataforma, taxa_conveniencia: p.taxaConveniencia,
    }));

    const auth = await PaymentGatewayAdapter.autorizar({ valor: p.valorAnfitriao, referenciaExterna: requestId });
    pagamento = this._transicionar(pagamento.id, FINANCIAL_STATUS.AUTHORIZED, { gateway_referencia: auth.gateway_referencia });

    const ret = await PaymentGatewayAdapter.reter({ gatewayReferencia: pagamento.gateway_referencia });
    pagamento = this._transicionar(pagamento.id, FINANCIAL_STATUS.HELD);

    AuditLogService.registrar({ user_id: solicitacao.owner_id, acao:'pagamento_autorizado_retido', entidade:'payments', entidade_id:pagamento.id, dados_novos:{ status: pagamento.status } });
    return pagamento;
  },

  obterPorSolicitacao(requestId){
    return DB.findOne('payments', p => p.service_request_id === requestId);
  },

  /** Chamado quando o anfitrião confirma a conclusão do serviço. */
  iniciarLiberacao(requestId){
    const pagamento = this.obterPorSolicitacao(requestId);
    if(!pagamento) return null;
    if(!transicaoFinanceiraPermitida(pagamento.status, FINANCIAL_STATUS.RELEASE_PENDING)){
      throw new Error(`Pagamento em status ${pagamento.status} não pode iniciar liberação.`);
    }
    return this._transicionar(pagamento.id, FINANCIAL_STATUS.RELEASE_PENDING);
  },

  /** Libera de fato o repasse ao profissional (ação separada — nunca automática na mesma hora). */
  async liberar(requestId, responsavelUserId){
    const pagamento = this.obterPorSolicitacao(requestId);
    if(!pagamento) throw new Error('Pagamento não encontrado.');
    if(!transicaoFinanceiraPermitida(pagamento.status, FINANCIAL_STATUS.RELEASED)){
      throw new Error(`Pagamento em status ${pagamento.status} não pode ser liberado.`);
    }
    const valorProfissionalFinal = pagamento.valor_profissional - (pagamento.taxa_deslocamento_disponibilidade || 0);
    await PaymentGatewayAdapter.liberar({ gatewayReferencia: pagamento.gateway_referencia, valorProfissional: valorProfissionalFinal, comissaoPlataforma: pagamento.comissao_plataforma });
    const atualizado = this._transicionar(pagamento.id, FINANCIAL_STATUS.RELEASED);
    AuditLogService.registrar({ user_id: responsavelUserId, acao:'pagamento_liberado', entidade:'payments', entidade_id:pagamento.id, dados_novos:{ valorProfissionalFinal } });
    return atualizado;
  },

  /** Coloca o pagamento em disputa — bloqueia liberação até decisão. */
  colocarEmDisputa(requestId){
    const pagamento = this.obterPorSolicitacao(requestId);
    if(!pagamento) return null;
    if(!transicaoFinanceiraPermitida(pagamento.status, FINANCIAL_STATUS.DISPUTED)) return pagamento;
    return this._transicionar(pagamento.id, FINANCIAL_STATUS.DISPUTED);
  },

  /** Retoma o fluxo normal após decisão que não exige reembolso. */
  retomarAposDisputa(requestId){
    const pagamento = this.obterPorSolicitacao(requestId);
    if(!pagamento) return null;
    return this._transicionar(pagamento.id, FINANCIAL_STATUS.HELD);
  },

  /**
   * Aplica a taxa de deslocamento/disponibilidade (configurável) quando uma
   * disputa é decidida a favor do profissional por responsabilidade do
   * anfitrião. O valor é descontado dos fundos retidos da solicitação e
   * destinado ao profissional na liberação.
   */
  aplicarTaxaDeslocamento(requestId, valorTaxa, responsavelUserId, motivo){
    const pagamento = this.obterPorSolicitacao(requestId);
    if(!pagamento) throw new Error('Pagamento não encontrado.');
    const ajustes = (pagamento.ajustes || []).concat([{ descricao: motivo || 'Taxa de deslocamento e disponibilidade', valor: valorTaxa, em: new Date().toISOString() }]);
    const atualizado = DB.update('payments', pagamento.id, {
      taxa_deslocamento_disponibilidade: (pagamento.taxa_deslocamento_disponibilidade || 0) + valorTaxa,
      ajustes,
    });
    AuditLogService.registrar({ user_id: responsavelUserId, acao:'aplicar_taxa_deslocamento', entidade:'payments', entidade_id:pagamento.id, dados_novos:{ valorTaxa, motivo } });
    return atualizado;
  },

  async reembolsar(requestId, valor, parcial, responsavelUserId){
    const pagamento = this.obterPorSolicitacao(requestId);
    if(!pagamento) throw new Error('Pagamento não encontrado.');
    const alvoStatus = parcial ? FINANCIAL_STATUS.PARTIALLY_REFUNDED : FINANCIAL_STATUS.REFUNDED;
    if(!transicaoFinanceiraPermitida(pagamento.status, alvoStatus)) throw new Error(`Pagamento em status ${pagamento.status} não pode ser reembolsado.`);
    await PaymentGatewayAdapter.reembolsar({ gatewayReferencia: pagamento.gateway_referencia, valor, parcial });
    const atualizado = this._transicionar(pagamento.id, alvoStatus);
    AuditLogService.registrar({ user_id: responsavelUserId, acao:'pagamento_reembolsado', entidade:'payments', entidade_id:pagamento.id, dados_novos:{ valor, parcial } });
    return atualizado;
  },

  _transicionar(pagamentoId, novoStatus, patchExtra){
    const atual = DB.find('payments', pagamentoId);
    if(atual.status !== novoStatus && !transicaoFinanceiraPermitida(atual.status, novoStatus)){
      throw new Error(`Transição financeira inválida: ${atual.status} → ${novoStatus}`);
    }
    const historico = (atual.historico_status || []).concat([{ status: novoStatus, em: new Date().toISOString() }]);
    return DB.update('payments', pagamentoId, Object.assign({}, patchExtra, { status: novoStatus, historico_status: historico }));
  },
};
