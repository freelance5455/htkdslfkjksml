/**
 * providersService.js — regras de negócio sobre a tabela PROVIDERS (perfil profissional).
 */
const ProvidersService = {
  obterPorUsuario(userId){
    return DB.findOne('providers', p => p.user_id === userId);
  },
  obter(providerId){
    return DB.find('providers', providerId);
  },

  atualizarPerfil(userId, dados){
    const atual = this.obterPorUsuario(userId);
    if(!atual) return null;
    const patch = Object.assign({}, dados);
    // Editar o cadastro depois de uma rejeição reabre a análise (permite reenvio).
    if(atual.status_aprovacao === 'REJEITADO'){
      patch.status_aprovacao = 'PENDENTE';
      patch.motivo_rejeicao = null;
    }
    const atualizado = DB.update('providers', atual.id, patch);
    AuditLogService.registrar({ user_id: userId, acao:'alteracao_cadastral_profissional', entidade:'providers', entidade_id:atual.id, dados_novos:Object.keys(dados) });
    return atualizado;
  },

  listarAprovados(categoria){
    return DB.list('providers', p => !p.excluido && p.status === 'aprovado' && (!categoria || p.categorias.includes(categoria)));
  },
  listarPendentes(){
    // Pendentes de ação do admin: nunca analisados, em análise, aguardando revisão de
    // documento, OU REJEITADOS aguardando correção/reenvio do profissional.
    // BUG CORRIGIDO: REJEITADO não entrava aqui nem em listarAprovados, então um
    // cadastro rejeitado sumia da administração até o profissional reenviar.
    // Exclui quem já foi excluído logicamente (ver excluir()).
    return DB.list('providers', p => !p.excluido && ['PENDENTE','ENVIADO','EM_ANALISE','REJEITADO'].includes(p.status_aprovacao || 'PENDENTE'));
  },

  /** Ação exclusiva do administrador. */
  aprovar(providerId, adminId){
    const p = DB.update('providers', providerId, {
      status: 'aprovado', verificado: true,
      status_aprovacao: 'APROVADO', data_aprovacao: new Date().toISOString(),
      admin_responsavel_aprovacao_id: adminId, motivo_rejeicao: null,
    });
    AuditLogService.registrar({ user_id: adminId, acao:'aprovar_provider', entidade:'providers', entidade_id:providerId, dados_novos:{status_aprovacao:'APROVADO'} });
    const usuario = DB.find('users', p.user_id);
    if(usuario) NotificationsService.criar(usuario.id, 'alteracao', 'Cadastro aprovado!', 'Seu cadastro de profissional foi aprovado. Você já pode ver oportunidades no mapa.');
    return p;
  },

  /** Exclusivo do administrador — motivo é obrigatório. */
  rejeitar(providerId, adminId, motivo){
    if(!motivo || !motivo.trim()) throw new Error('Informe o motivo da rejeição.');
    const p = DB.update('providers', providerId, {
      status: 'pendente', status_aprovacao: 'REJEITADO',
      motivo_rejeicao: motivo, admin_responsavel_aprovacao_id: adminId,
    });
    AuditLogService.registrar({ user_id: adminId, acao:'rejeitar_provider', entidade:'providers', entidade_id:providerId, dados_novos:{motivo} });
    const usuario = DB.find('users', p.user_id);
    if(usuario) NotificationsService.criar(usuario.id, 'alteracao', 'Cadastro não aprovado', `Motivo: ${motivo}. Você pode corrigir seu perfil e reenviar.`);
    return p;
  },

  /** Desativar (suspensão) — reversível, mantém login e todo o cadastro/histórico intactos. */
  suspender(providerId, adminId){
    const p = DB.update('providers', providerId, { status: 'suspenso' });
    AuditLogService.registrar({ user_id: adminId, acao:'suspender_provider', entidade:'providers', entidade_id:providerId, dados_novos:{status:'suspenso'} });
    return p;
  },

  /**
   * Exclusão LÓGICA do profissional — nunca remove o cadastro, histórico,
   * avaliações ou auditoria (registro permanece integralmente na tabela
   * `providers`, `reviews`, `service_requests` e `audit_log`). Bloqueia o
   * acesso (login) reaproveitando o mecanismo já existente de suspensão de
   * conta em UsersService, e permite retorno futuro via reativarExcluido().
   */
  excluir(providerId, adminId){
    const provider = this.obter(providerId);
    if(!provider) throw new Error('Profissional não encontrado.');
    const p = DB.update('providers', providerId, {
      excluido: true, excluido_em: new Date().toISOString(), admin_responsavel_exclusao_id: adminId,
    });
    UsersService.definirStatus(provider.user_id, 'suspenso', adminId); // impede login sem apagar nada
    AuditLogService.registrar({ user_id: adminId, acao:'excluir_provider', entidade:'providers', entidade_id:providerId, dados_novos:{excluido:true} });
    const usuario = DB.find('users', provider.user_id);
    if(usuario) NotificationsService.criar(usuario.id, 'alteracao', 'Cadastro excluído', 'Seu cadastro de profissional foi excluído pela administração. Fale com o suporte para mais informações.');
    return p;
  },

  /** Reverte a exclusão lógica — restaura o acesso e preserva tudo que já existia. */
  reativarExcluido(providerId, adminId){
    const provider = this.obter(providerId);
    if(!provider) throw new Error('Profissional não encontrado.');
    const p = DB.update('providers', providerId, { excluido: false, excluido_em: null });
    UsersService.definirStatus(provider.user_id, 'ativo', adminId);
    AuditLogService.registrar({ user_id: adminId, acao:'reativar_provider_excluido', entidade:'providers', entidade_id:providerId, dados_novos:{excluido:false} });
    const usuario = DB.find('users', provider.user_id);
    if(usuario) NotificationsService.criar(usuario.id, 'alteracao', 'Cadastro reativado', 'Seu cadastro de profissional foi reativado. Bem-vindo de volta!');
    return p;
  },

  /** ---------- Documentação (opcional em DEV — ver README) ---------- */
  TIPOS_DOCUMENTO: ['rg_cpf', 'comprovante_residencia', 'certidao_antecedentes'],

  enviarDocumento(userId, tipo, arquivoBase64){
    if(!this.TIPOS_DOCUMENTO.includes(tipo)) throw new Error('Tipo de documento inválido.');
    const provider = this.obterPorUsuario(userId);
    if(!provider) throw new Error('Perfil de profissional não encontrado.');
    const documentos = Object.assign({}, provider.documentos, {
      [tipo]: { status: 'enviado', arquivo: arquivoBase64, enviado_em: new Date().toISOString(), analisado_em: null, admin_id: null, motivo_rejeicao: null },
    });
    const patch = { documentos };
    if(provider.status_aprovacao === 'PENDENTE') patch.status_aprovacao = 'ENVIADO';
    const atualizado = DB.update('providers', provider.id, patch);
    AuditLogService.registrar({ user_id: userId, acao:'enviar_documento', entidade:'providers', entidade_id:provider.id, dados_novos:{ tipo } });
    return atualizado;
  },

  /** Admin analisa um documento específico. */
  analisarDocumento(adminId, providerId, tipo, aprovar, motivo){
    const provider = this.obter(providerId);
    if(!provider) throw new Error('Profissional não encontrado.');
    if(!aprovar && (!motivo || !motivo.trim())) throw new Error('Informe o motivo da rejeição do documento.');
    const documentos = Object.assign({}, provider.documentos, {
      [tipo]: Object.assign({}, provider.documentos[tipo], {
        status: aprovar ? 'aprovado' : 'rejeitado', analisado_em: new Date().toISOString(),
        admin_id: adminId, motivo_rejeicao: aprovar ? null : motivo,
      }),
    });
    const atualizado = DB.update('providers', providerId, { documentos, status_aprovacao: provider.status_aprovacao === 'ENVIADO' ? 'EM_ANALISE' : provider.status_aprovacao });
    AuditLogService.registrar({ user_id: adminId, acao:'analisar_documento', entidade:'providers', entidade_id:providerId, dados_novos:{ tipo, aprovar, motivo: motivo||null } });
    return atualizado;
  },

  /**
   * Exibição CONTROLADA de documento sensível (ex.: RG para portaria/condomínio).
   * Só o próprio profissional, o anfitrião com uma solicitação ACEITA com ele,
   * ou o administrador podem ver — e toda visualização fica auditada.
   *
   * IMPORTANTE: o anfitrião NUNCA pode ver a certidão de antecedentes (nem
   * qualquer documento além de RG/CPF), mesmo tendo um serviço aceito com o
   * profissional. Isso é reforçado aqui, não só escondendo o botão na tela.
   */
  visualizarDocumentoSensivel(viewerUserId, providerId, tipo){
    const provider = this.obter(providerId);
    if(!provider) throw new Error('Profissional não encontrado.');
    const viewer = DB.find('users', viewerUserId);
    const ehProprioProfissional = provider.user_id === viewerUserId;
    const ehAdmin = viewer && viewer.tipo_usuario === 'administrador';
    const temServicoComEle = DB.findOne('service_requests', s => s.accepted_provider_id === providerId && s.owner_id === viewerUserId);

    if(!ehProprioProfissional && !ehAdmin && !temServicoComEle){
      throw new Error('Você não tem permissão para visualizar este documento.');
    }
    // Anfitrião (não-admin, não-dono) só pode ver RG/CPF — nunca comprovante de
    // residência nem, principalmente, a certidão de antecedentes.
    if(!ehProprioProfissional && !ehAdmin && tipo !== 'rg_cpf'){
      throw new Error('Este documento não pode ser exibido ao anfitrião.');
    }

    AuditLogService.registrar({ user_id: viewerUserId, acao:'visualizar_documento_sensivel', entidade:'providers', entidade_id:providerId, dados_novos:{ tipo } });
    const doc = provider.documentos[tipo];
    return { rg: provider.rg, cpf: provider.cpf, documento: doc };
  },

  /** ---------- Cartão digital / apresentação pública (sem dados sensíveis) ---------- */
  tempoNaPlataforma(provider){
    const inicio = new Date(provider.created_at);
    const agora = new Date();
    let meses = (agora.getFullYear()-inicio.getFullYear())*12 + (agora.getMonth()-inicio.getMonth());
    if(meses < 1) return 'Novo profissional';
    const anos = Math.floor(meses/12);
    const restoMeses = meses % 12;
    if(anos === 0) return `${restoMeses} mês${restoMeses===1?'':'es'} na plataforma`;
    if(restoMeses === 0) return `${anos} ano${anos===1?'':'s'} na plataforma`;
    return `${anos} ano${anos===1?'':'s'} e ${restoMeses} mês${restoMeses===1?'':'es'} na plataforma`;
  },

  contarServicosConcluidos(providerId){
    return DB.list('service_requests', s => s.accepted_provider_id === providerId && s.status === 'COMPLETED').length;
  },

  /** Resumo seguro para o cartão digital — nunca inclui RG/CPF/documentos/ocorrências detalhadas. */
  resumoPublico(providerId){
    const provider = this.obter(providerId);
    if(!provider) return null;
    const usuario = DB.find('users', provider.user_id);
    const reviews = ReviewsService.listarRecebidas(provider.user_id);
    const servicosConcluidos = this.contarServicosConcluidos(providerId);
    return {
      id: provider.id,
      nome: usuario ? usuario.nome : 'Profissional',
      selfie: provider.selfie || '',
      categorias: provider.categorias,
      aprovado: provider.status === 'aprovado',
      reputacao: provider.reputacao || 0,
      qtdAvaliacoes: reviews.length,
      servicosConcluidos,
      temHistorico: reviews.length > 0 || servicosConcluidos > 0,
      tempoNaPlataforma: this.tempoNaPlataforma(provider),
      ocorrenciasCount: OccurrencesService.contarPorProvider(providerId),
    };
  },

  /** Recalcula a reputação (média simples das reviews recebidas). */
  recalcularReputacao(userId){
    const reviews = ReviewsService.listarRecebidas(userId);
    const media = reviews.length ? reviews.reduce((s,r)=>s+r.nota,0) / reviews.length : 0;
    const provider = this.obterPorUsuario(userId);
    if(provider) DB.update('providers', provider.id, { reputacao: Math.round(media*10)/10 });
    return media;
  },
};
