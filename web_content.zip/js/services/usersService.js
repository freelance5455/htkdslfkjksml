/**
 * usersService.js — regras de negócio sobre a tabela USERS.
 */
const UsersService = {
  obter(id){ return DB.find('users', id); },
  listar(){ return DB.list('users'); },
  listarAnfitrioes(){ return DB.list('users', u => u.tipo_usuario === 'anfitriao'); },
  listarProfissionaisUsuarios(){ return DB.list('users', u => u.tipo_usuario === 'profissional'); },
  atualizarPerfil(id, { nome, telefone }){
    return DB.update('users', id, { nome, telefone });
  },
  /** Suspende/reativa um usuário. Nunca exclui fisicamente. */
  definirStatus(id, status, adminId){
    const antes = DB.find('users', id);
    const atualizado = DB.setStatus('users', id, status);
    AuditLogService.registrar({ user_id: adminId, acao: 'alterar_status_usuario', entidade:'users', entidade_id:id, dados_anteriores:{status:antes.status}, dados_novos:{status} });
    return atualizado;
  },
  desativar(id, adminId){ return this.definirStatus(id, 'suspenso', adminId); },
  reativar(id, adminId){ return this.definirStatus(id, 'ativo', adminId); },

  /**
   * Exclusão LÓGICA do usuário (ex.: anfitrião) — nunca remove o cadastro,
   * imóveis, histórico de solicitações, avaliações ou auditoria. Bloqueia o
   * acesso (login) e permite retorno futuro via reativarExcluido().
   */
  excluir(id, adminId){
    const atual = this.obter(id);
    if(!atual) throw new Error('Usuário não encontrado.');
    const atualizado = DB.update('users', id, {
      excluido: true, excluido_em: new Date().toISOString(), admin_responsavel_exclusao_id: adminId, status: 'suspenso',
    });
    AuditLogService.registrar({ user_id: adminId, acao:'excluir_usuario', entidade:'users', entidade_id:id, dados_novos:{excluido:true} });
    NotificationsService.criar(id, 'alteracao', 'Cadastro excluído', 'Sua conta foi excluída pela administração. Fale com o suporte para mais informações.');
    return atualizado;
  },

  /** Reverte a exclusão lógica — restaura o acesso e preserva tudo que já existia. */
  reativarExcluido(id, adminId){
    const atualizado = DB.update('users', id, { excluido: false, excluido_em: null, status: 'ativo' });
    AuditLogService.registrar({ user_id: adminId, acao:'reativar_usuario_excluido', entidade:'users', entidade_id:id, dados_novos:{excluido:false} });
    NotificationsService.criar(id, 'alteracao', 'Cadastro reativado', 'Sua conta foi reativada. Bem-vindo de volta!');
    return atualizado;
  },
};
