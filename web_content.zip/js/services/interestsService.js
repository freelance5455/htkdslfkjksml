/**
 * interestsService.js
 * Fluxo: profissional demonstra interesse → anfitrião vê e aceita/rejeita →
 * ao aceitar, a oportunidade é bloqueada para os demais interessados.
 */
const InterestsService = {

  demonstrarInteresse(providerId, requestId){
    const solicitacao = DB.find('service_requests', requestId);
    if(!solicitacao || solicitacao.status !== STATUS_SOLICITACAO.PUBLISHED){
      throw new Error('Esta oportunidade não está mais disponível.');
    }
    const provider = DB.find('providers', providerId);
    if(!provider || !provider.categorias.includes(solicitacao.categoria)){
      throw new Error('Esta oportunidade não é compatível com sua categoria de atuação.');
    }
    const jaExiste = DB.findOne('interests', i => i.provider_id === providerId && i.service_request_id === requestId);
    if(jaExiste) throw new Error('Você já demonstrou interesse nesta oportunidade.');

    const interesse = DB.insert('interests', Models.novoInteresse({ service_request_id: requestId, provider_id: providerId }));

    const profUser = DB.find('users', provider.user_id);
    NotificationsService.criar(
      solicitacao.owner_id,
      'interesse_recebido',
      'Um profissional demonstrou interesse',
      `${profUser ? profUser.nome : 'Um profissional'} tem interesse no serviço de ${solicitacao.categoria} que você publicou.`
    );
    AuditLogService.registrar({ user_id: provider.user_id, acao:'demonstrar_interesse', entidade:'service_requests', entidade_id:requestId });
    return interesse;
  },

  listarPorSolicitacao(requestId){
    return DB.list('interests', i => i.service_request_id === requestId)
      .map(i => Object.assign({}, i, { _provider: DB.find('providers', i.provider_id) }))
      .map(i => Object.assign({}, i, { _usuario: i._provider ? DB.find('users', i._provider.user_id) : null }));
  },

  /**
   * Anfitrião aceita um profissional específico: bloqueia a oportunidade para
   * os demais (interesses concorrentes viram 'recusado' automaticamente) e
   * já autoriza/retém o pagamento (sandbox — ver paymentsService.js).
   */
  async aceitar(ownerId, requestId, interesseId){
    const solicitacao = DB.find('service_requests', requestId);
    if(!solicitacao || solicitacao.owner_id !== ownerId) throw new Error('Solicitação não encontrada.');
    if(solicitacao.status !== STATUS_SOLICITACAO.PUBLISHED) throw new Error('Esta solicitação não está mais disponível para aceite.');

    const interesse = DB.find('interests', interesseId);
    if(!interesse || interesse.service_request_id !== requestId) throw new Error('Interesse inválido.');

    DB.update('interests', interesseId, { status: 'aceito' });

    // bloqueia a oportunidade para os demais — recusa automática dos outros interesses
    const outros = DB.list('interests', i => i.service_request_id === requestId && i.id !== interesseId);
    outros.forEach(o => {
      DB.update('interests', o.id, { status: 'recusado' });
      const provider = DB.find('providers', o.provider_id);
      if(provider) NotificationsService.criar(provider.user_id, 'interesse_recusado', 'Oportunidade já foi preenchida', 'O anfitrião escolheu outro profissional para este serviço.');
    });

    const atualizado = DB.update('service_requests', requestId, {
      status: STATUS_SOLICITACAO.ACCEPTED,
      accepted_provider_id: interesse.provider_id,
      accepted_at: new Date().toISOString(),
    });

    ChatService.mensagemSistema(requestId, '🤝 Profissional aceito. Este chat agora é o canal oficial da negociação.');

    try{ await PaymentsService.criarEAutorizar(requestId); }
    catch(e){ /* categorias "necessita avaliação" ainda não têm valor — pagamento criado após o orçamento */ }

    const providerAceito = DB.find('providers', interesse.provider_id);
    if(providerAceito) NotificationsService.criar(providerAceito.user_id, 'interesse_aceito', 'Seu interesse foi aceito!', `Você foi escolhido para o serviço de ${solicitacao.categoria}. Confira os detalhes.`);

    AuditLogService.registrar({ user_id: ownerId, acao:'aceitar_interesse', entidade:'service_requests', entidade_id:requestId, dados_novos:{ accepted_provider_id: interesse.provider_id } });
    return atualizado;
  },

  rejeitar(ownerId, requestId, interesseId){
    const solicitacao = DB.find('service_requests', requestId);
    if(!solicitacao || solicitacao.owner_id !== ownerId) throw new Error('Solicitação não encontrada.');
    const interesse = DB.find('interests', interesseId);
    if(!interesse || interesse.service_request_id !== requestId) throw new Error('Interesse inválido.');

    DB.update('interests', interesseId, { status: 'recusado' });
    const provider = DB.find('providers', interesse.provider_id);
    if(provider) NotificationsService.criar(provider.user_id, 'interesse_recusado', 'Interesse recusado', `O anfitrião não seguiu com seu interesse no serviço de ${solicitacao.categoria}.`);
    AuditLogService.registrar({ user_id: ownerId, acao:'recusar_interesse', entidade:'service_requests', entidade_id:requestId, dados_novos:{ interesseId } });
    return true;
  },
};
