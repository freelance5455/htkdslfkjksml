/**
 * checklistService.js
 * O "template" do checklist é gerado dinamicamente a partir dos ambientes e
 * do inventário já cadastrados no imóvel (não é uma lista fixa hardcoded) —
 * isso é o que o torna "reutilizável": qualquer profissional, em qualquer
 * serviço aceito para aquele imóvel, roda o mesmo checklist na pré-vistoria.
 * Cada execução (`property_checklist_runs`) fica vinculada à solicitação,
 * então dá pra comparar respostas entre visitas diferentes no futuro.
 */
const ChecklistService = {

  /** Gera os itens do checklist a partir de ambientes + inventário do imóvel. */
  gerarTemplate(propertyId){
    const ambientes = RoomsService.listarPorImovel(propertyId);
    const itensInventario = InventoryService.listarPorImovel(propertyId);

    const itens = [];
    ambientes.forEach(a => {
      itens.push({ tipo:'ambiente', referencia_id: a.id, descricao: `Conferir ambiente: ${a.nome}`, ok:null, observacao:'', fotos:[] });
    });
    itensInventario.forEach(i => {
      itens.push({ tipo:'inventario', referencia_id: i.id, descricao: `Conferir item: ${i.item} (qtd. ${i.quantidade}, estado declarado: ${i.estado})`, ok:null, observacao:'', fotos:[] });
    });
    return itens;
  },

  /** Inicia (ou retoma, se já existir) a execução do checklist de PRÉ-vistoria para um serviço. */
  iniciarExecucao(providerId, serviceRequestId, propertyId){
    const existente = DB.findOne('property_checklist_runs', r => r.service_request_id === serviceRequestId && r.tipo === 'pre');
    if(existente) return existente;
    const itens = this.gerarTemplate(propertyId);
    const run = DB.insert('property_checklist_runs', Models.novoChecklistRun({ property_id: propertyId, service_request_id: serviceRequestId, provider_id: providerId, itens, tipo:'pre' }));
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider_checklist(providerId), acao:'iniciar_checklist', entidade:'property_checklist_runs', entidade_id:run.id, dados_novos:{ service_request_id: serviceRequestId } });
    return run;
  },

  /**
   * ETAPA 4 — Pós-vistoria: comparativo "antes/depois" feito ao final da
   * execução. Reaproveita os mesmos itens da pré-vistoria (mesmo template),
   * zerando as respostas, para que o profissional confira novamente cada
   * ambiente/item já sabendo o que foi registrado na chegada.
   */
  iniciarPosVistoria(providerId, serviceRequestId){
    const existente = DB.findOne('property_checklist_runs', r => r.service_request_id === serviceRequestId && r.tipo === 'pos');
    if(existente) return existente;
    const preRun = this.obterPorSolicitacao(serviceRequestId, 'pre');
    if(!preRun) throw new Error('Pré-vistoria não encontrada — não é possível iniciar a pós-vistoria.');
    const itens = preRun.itens.map(it => Object.assign({}, it, { ok:null, observacao:'', fotos:[], fotos_antes: it.fotos || [] }));
    const run = DB.insert('property_checklist_runs', Models.novoChecklistRun({
      property_id: preRun.property_id, service_request_id: serviceRequestId, provider_id: providerId,
      itens, tipo:'pos', pre_run_id: preRun.id,
    }));
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider_checklist(providerId), acao:'iniciar_pos_vistoria', entidade:'property_checklist_runs', entidade_id:run.id, dados_novos:{ service_request_id: serviceRequestId, pre_run_id: preRun.id } });
    return run;
  },

  obterPorSolicitacao(serviceRequestId, tipo){
    return DB.findOne('property_checklist_runs', r => r.service_request_id === serviceRequestId && r.tipo === (tipo || 'pre'));
  },

  responderItem(providerId, runId, indice, { ok, observacao, fotos }){
    const run = DB.find('property_checklist_runs', runId);
    if(!run || run.provider_id !== providerId) throw new Error('Checklist não encontrado ou não pertence a você.');
    const itens = run.itens.slice();
    if(!itens[indice]) throw new Error('Item de checklist inválido.');
    itens[indice] = Object.assign({}, itens[indice], { ok, observacao: observacao || '', fotos: fotos || [] });
    return DB.update('property_checklist_runs', runId, { itens });
  },

  /** Vídeo obrigatório da vistoria (pré ou pós) — registro visual contínuo do estado do imóvel. */
  registrarVideo(providerId, runId, videoBase64){
    const run = DB.find('property_checklist_runs', runId);
    if(!run || run.provider_id !== providerId) throw new Error('Checklist não encontrado ou não pertence a você.');
    if(!videoBase64) throw new Error('Nenhum vídeo selecionado.');
    const atualizado = DB.update('property_checklist_runs', runId, { video: videoBase64, video_registrado_em: new Date().toISOString() });
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider_checklist(providerId), acao: run.tipo==='pos' ? 'anexar_video_pos_vistoria' : 'anexar_video_checklist', entidade:'property_checklist_runs', entidade_id:runId });
    return atualizado;
  },

  /** Observações gerais da vistoria — obrigatórias na pré-vistoria (item 1 do fluxo obrigatório). */
  registrarObservacaoGeral(providerId, runId, texto){
    const run = DB.find('property_checklist_runs', runId);
    if(!run || run.provider_id !== providerId) throw new Error('Checklist não encontrado ou não pertence a você.');
    return DB.update('property_checklist_runs', runId, { observacao_geral: (texto || '').trim() });
  },

  /**
   * Conclui o checklist. Exige: todos os itens respondidos (quando houver itens
   * cadastrados) e vídeo contínuo da vistoria (obrigatório na pré e na pós).
   * Na pré-vistoria também exige observações gerais preenchidas. Na
   * pós-vistoria, além do vídeo, exige ao menos uma foto "depois" por item
   * marcado como divergente, para comparação com a pré.
   */
  concluir(providerId, runId){
    const run = DB.find('property_checklist_runs', runId);
    if(!run || run.provider_id !== providerId) throw new Error('Checklist não encontrado ou não pertence a você.');
    const pendentes = run.itens.filter(i => i.ok === null).length;
    if(run.itens.length > 0 && pendentes > 0){
      throw new Error(`Responda todos os itens do checklist antes de concluir (${pendentes} pendente(s)).`);
    }
    if(!run.video){
      throw new Error(run.tipo === 'pos'
        ? 'O vídeo contínuo da vistoria de saída é obrigatório para concluir.'
        : 'O vídeo contínuo da vistoria de entrada é obrigatório para concluir.');
    }
    if(run.tipo === 'pos'){
      const divergentesSemFoto = run.itens.filter(i => i.ok === false && (!i.fotos || i.fotos.length === 0));
      if(divergentesSemFoto.length > 0){
        throw new Error(`Anexe ao menos uma foto "depois" para cada item divergente (${divergentesSemFoto.length} pendente(s)).`);
      }
    } else if(!run.observacao_geral || !run.observacao_geral.trim()){
      throw new Error('Preencha o campo de observações da vistoria de entrada antes de concluir.');
    }
    const atualizado = DB.update('property_checklist_runs', runId, { concluido: true, concluido_em: new Date().toISOString() });
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider_checklist(providerId), acao: run.tipo==='pos' ? 'concluir_pos_vistoria' : 'concluir_checklist', entidade:'property_checklist_runs', entidade_id:runId });
    return atualizado;
  },
};

function UsersService_userIdDoProvider_checklist(providerId){
  const p = DB.find('providers', providerId);
  return p ? p.user_id : null;
}
