/**
 * devToolsService.js
 * Ferramentas exclusivas do Ambiente DEV para manutenção do ambiente de
 * testes. NUNCA deve ser exposto/chamado quando APP_CONFIG.ENV === 'prod'.
 */
const DevToolsService = {
  /**
   * Tabelas consideradas "dados de teste" (tudo que é gerado pelo uso do
   * app: usuários, imóveis, solicitações/oportunidades, execuções,
   * mensagens, avaliações, pagamentos simulados, documentos/evidências,
   * disputas, notificações e auditoria).
   *
   * 'service_categories' fica de fora de propósito: não é dado de teste,
   * é catálogo fixo (Faxina/Manutenção/Roupa de cama) e se auto-restaura
   * via CategoriesService.seedPadrao() no próximo carregamento de página.
   */
  TABELAS_DADOS_TESTE: [
    'users', 'properties', 'property_rooms', 'property_inventory',
    'property_checklist_runs', 'providers', 'service_requests',
    'interests', 'availability', 'chat_messages', 'contact_violations',
    'reviews', 'payments', 'evidences', 'occurrences', 'disputes',
    'notifications', 'term_acceptances', 'audit_logs',
  ],

  /** Só é permitido operar em ambiente DEV. */
  disponivelNesteAmbiente(){
    return window.APP_CONFIG.ENV !== 'prod';
  },

  /**
   * Apaga definitivamente todos os dados de teste do localStorage, mantendo
   * intacta a conta administrativa (linha de 'users' com tipo_usuario
   * 'administrador') e sem deixar chaves órfãs (sequências/tabelas
   * relacionadas são limpas juntas).
   * Retorna um resumo do que foi removido, para auditoria/feedback.
   */
  limparDadosDeTeste({ admin_id } = {}){
    if(!this.disponivelNesteAmbiente()){
      throw new Error('Limpeza de dados de teste indisponível fora do Ambiente DEV.');
    }

    const resumo = {};

    this.TABELAS_DADOS_TESTE.forEach(tabela => {
      if(tabela === 'users'){
        const admins = DB.list('users', u => u.tipo_usuario === 'administrador');
        resumo.users = DB.list('users').length - admins.length;
        DB._clear('users');
        admins.forEach(a => DB.insert('users', Object.assign({}, a, { id: a.id })));
      } else {
        resumo[tabela] = DB.list(tabela).length;
        DB._clear(tabela);
      }
      // Remove o contador de sequência da tabela também, evitando IDs "órfãos"
      // (saltos sem sentido) na próxima rodada de testes.
      if(tabela !== 'users'){
        localStorage.removeItem(storageKey('_seq_' + tabela));
      }
    });

    // Encerra sessões ativas (usuários de teste deixam de existir) — força
    // um novo login, inclusive do administrador.
    localStorage.removeItem(storageKey('session'));

    // Registra a própria limpeza na auditoria (tabela recém-recriada vazia).
    AuditLogService.registrar({
      user_id: admin_id || null,
      acao: 'limpeza_dados_teste',
      entidade: 'sistema',
      entidade_id: null,
      dados_anteriores: resumo,
      dados_novos: null,
    });

    return resumo;
  },
};
