/**
 * serviceRequestsService.js
 * Regras de negócio da solicitação de serviço: criação, publicação (snapshot),
 * transições de status válidas, e alteração formal pós-aceite (nunca silenciosa).
 */
const ServiceRequestsService = {

  criarRascunho(ownerId, { property_id, categoria }){
    const imovel = DB.find('properties', property_id);
    if(!imovel || imovel.owner_id !== ownerId) throw new Error('Imóvel inválido.');
    return DB.insert('service_requests', Models.novaSolicitacao({ owner_id: ownerId, property_id, categoria }));
  },

  /**
   * Publica a solicitação: calcula o preço, congela o SNAPSHOT e muda o status.
   * `dadosForm` já vem validado por Models.validarSolicitacao na página.
   */
  publicar(ownerId, requestId, dadosForm){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.owner_id !== ownerId) throw new Error('Solicitação não encontrada.');
    if(!transicaoPermitida(atual.status, STATUS_SOLICITACAO.PUBLISHED) && atual.status !== STATUS_SOLICITACAO.DRAFT){
      throw new Error('Esta solicitação não pode mais ser publicada.');
    }

    const imovel = DB.find('properties', atual.property_id);
    const precificacao = PricingService.calcular({
      categoria: atual.categoria,
      data: dadosForm.data,
      horario: dadosForm.horario,
      urgencia: dadosForm.urgencia,
      limpeza: dadosForm.detalhes && atual.categoria === CATEGORIAS_SERVICO.LIMPEZA ? dadosForm.detalhes : undefined,
      reparo: dadosForm.detalhes && atual.categoria === CATEGORIAS_SERVICO.REPAROS ? dadosForm.detalhes : undefined,
      enxoval: dadosForm.detalhes && atual.categoria === CATEGORIAS_SERVICO.ENXOVAL ? dadosForm.detalhes : undefined,
    });

    const snapshot = {
      imovel: imovel ? {
        nome: imovel.nome, endereco: imovel.endereco, cep: imovel.cep, cidade: imovel.cidade, estado: imovel.estado,
        bairro: imovel.bairro, tipo: imovel.tipo, latitude: imovel.latitude, longitude: imovel.longitude,
        quartos: imovel.quartos, banheiros: imovel.banheiros, camas: imovel.camas, capacidade: imovel.capacidade,
        metragem_m2: imovel.metragem_m2, acesso: imovel.acesso, condominio: imovel.condominio,
        caracteristicas: imovel.caracteristicas,
        ambientes: RoomsService.listarPorImovel(imovel.id).map(a => ({ id:a.id, nome:a.nome, qtdFotos:(a.fotos||[]).length, temVideo: !!a.video })),
        inventario: InventoryService.listarPorImovel(imovel.id).map(i => ({ id:i.id, item:i.item, quantidade:i.quantidade, estado:i.estado })),
      } : null,
      categoria: atual.categoria,
      detalhes: dadosForm.detalhes,
      observacoes: dadosForm.observacoes || '',
      fotos: dadosForm.fotos || [],
      data: dadosForm.data,
      horario: dadosForm.horario,
      urgencia: dadosForm.urgencia,
      precificacao,
      congelado_em: new Date().toISOString(),
    };

    const atualizado = DB.update('service_requests', requestId, {
      data: dadosForm.data, horario: dadosForm.horario, urgencia: dadosForm.urgencia,
      detalhes: dadosForm.detalhes, observacoes: dadosForm.observacoes || '', fotos: dadosForm.fotos || [],
      precificacao, snapshot, status: STATUS_SOLICITACAO.PUBLISHED,
    });

    AuditLogService.registrar({ user_id: ownerId, acao:'publicar_solicitacao', entidade:'service_requests', entidade_id:requestId, dados_novos:{ status: STATUS_SOLICITACAO.PUBLISHED } });
    return atualizado;
  },

  /**
   * Alteração pós-publicação. NUNCA é silenciosa: sempre grava no
   * historico_alteracoes, e se já houver profissional aceito, a alteração é
   * registrada como formal (o profissional precisa ser avisado — notificação).
   */
  alterarFormalmente(ownerId, requestId, patch, motivo){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.owner_id !== ownerId) throw new Error('Solicitação não encontrada.');
    if([STATUS_SOLICITACAO.COMPLETED, STATUS_SOLICITACAO.CANCELLED].includes(atual.status)){
      throw new Error('Não é possível alterar uma solicitação finalizada.');
    }

    const evento = {
      em: new Date().toISOString(),
      motivo: motivo || 'Alteração solicitada pelo anfitrião',
      campos_antes: {},
      campos_depois: {},
    };
    Object.keys(patch).forEach(k => { evento.campos_antes[k] = atual[k]; evento.campos_depois[k] = patch[k]; });

    const historico = (atual.historico_alteracoes || []).concat([evento]);
    const atualizado = DB.update('service_requests', requestId, Object.assign({}, patch, { historico_alteracoes: historico }));

    AuditLogService.registrar({ user_id: ownerId, acao:'alterar_solicitacao', entidade:'service_requests', entidade_id:requestId, dados_anteriores:evento.campos_antes, dados_novos:evento.campos_depois });

    if(atual.accepted_provider_id){
      NotificationsService.criar(
        UsersService_userIdDoProvider(atual.accepted_provider_id),
        'alteracao',
        'A solicitação foi alterada',
        `O anfitrião alterou detalhes do serviço "${atual.categoria}" que você aceitou. Confira antes de prosseguir.`
      );
    }
    return atualizado;
  },

  cancelar(ownerId, requestId, motivo){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.owner_id !== ownerId) throw new Error('Solicitação não encontrada.');
    if(!transicaoPermitida(atual.status, STATUS_SOLICITACAO.CANCELLED)) throw new Error('Esta solicitação não pode mais ser cancelada.');

    const atualizado = DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.CANCELLED });
    AuditLogService.registrar({ user_id: ownerId, acao:'cancelar_solicitacao', entidade:'service_requests', entidade_id:requestId });

    if(atual.accepted_provider_id){
      NotificationsService.criar(UsersService_userIdDoProvider(atual.accepted_provider_id), 'alteracao', 'Solicitação cancelada', 'O anfitrião cancelou o serviço que você havia aceitado.');
      OccurrencesService.registrar(atual.accepted_provider_id, 'cancelamento', motivo || 'Cancelado pelo anfitrião após aceite', { serviceRequestId: requestId, registradoPor: ownerId });
    }
    return atualizado;
  },

  /** ---------- ETAPA 3: operação (deslocamento → chegada → conferência → execução → finalização) ---------- */

  iniciarDeslocamento(providerId, requestId, posicao){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.accepted_provider_id !== providerId) throw new Error('Você não está atribuído a esta solicitação.');
    if(!transicaoPermitida(atual.status, STATUS_SOLICITACAO.TRAVELING)) throw new Error('Status atual não permite iniciar deslocamento.');

    const evidencia = EvidencesService.registrar({
      service_request_id: requestId, user_id: UsersService_userIdDoProvider(providerId),
      tipo: 'deslocamento_iniciado', texto: 'Profissional iniciou o deslocamento até o imóvel.',
      gps: posicao ? { lat: posicao.lat, lng: posicao.lng, precisao: posicao.precisao } : null,
    });
    ChatService.mensagemSistema(requestId, `🚗 Profissional a caminho do imóvel. (${new Date().toLocaleString('pt-BR')})`);
    NotificationsService.criar(atual.owner_id, 'deslocamento', 'Profissional a caminho', 'O profissional iniciou o deslocamento até o seu imóvel.');
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider(providerId), acao:'iniciar_deslocamento', entidade:'service_requests', entidade_id:requestId, dados_novos:{ evidencia_id: evidencia.id } });
    return DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.TRAVELING });
  },

  /**
   * Registra a chegada com o GPS real do profissional. Valida proximidade
   * com o imóvel (tolerância configurável em APP_CONFIG.TOLERANCIA_CHEGADA_KM).
   * Se estiver fora do raio, NÃO bloqueia (GPS de celular tem erro), mas
   * registra o alerta na evidência para uso posterior numa eventual disputa.
   */
  registrarChegada(providerId, requestId, posicao, { simulado = false } = {}){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.accepted_provider_id !== providerId) throw new Error('Você não está atribuído a esta solicitação.');
    if(!transicaoPermitida(atual.status, STATUS_SOLICITACAO.ARRIVED)) throw new Error('Status atual não permite registrar chegada.');

    const imovel = DB.find('properties', atual.property_id);
    let distanciaKmCalc = null, dentroDoRaio = null;
    if(posicao && imovel && imovel.latitude != null && imovel.longitude != null){
      distanciaKmCalc = distanciaKm(posicao.lat, posicao.lng, imovel.latitude, imovel.longitude);
      dentroDoRaio = distanciaKmCalc <= window.APP_CONFIG.TOLERANCIA_CHEGADA_KM;
    }

    // Regra de negócio: fora do raio de 350 m do imóvel, a chegada NÃO é registrada.
    // (Se não houver coordenadas do imóvel para comparar, não é possível validar —
    // nesse caso, a chegada segue sendo registrada e fica marcada como "não verificável".)
    if(dentroDoRaio === false){
      const err = new Error(`Você está a ${distanciaKmCalc} km do imóvel — fora do raio de ${Math.round(window.APP_CONFIG.TOLERANCIA_CHEGADA_KM*1000)} m permitido para registrar chegada. Aproxime-se do endereço cadastrado.`);
      err.tipo = 'fora_do_raio';
      err.distanciaKm = distanciaKmCalc;
      throw err;
    }

    const evidencia = EvidencesService.registrar({
      service_request_id: requestId, user_id: UsersService_userIdDoProvider(providerId),
      tipo: 'chegada_registrada',
      texto: simulado
        ? `Chegada SIMULADA (ambiente de testes/DEV) — ${distanciaKmCalc != null ? distanciaKmCalc+' km do imóvel, dentro do raio.' : 'sem GPS real do profissional.'}`
        : (dentroDoRaio === null ? 'Chegada registrada — não foi possível verificar a distância até o imóvel (sem coordenadas cadastradas).' : `Chegada registrada dentro do raio permitido (${distanciaKmCalc} km do imóvel).`),
      gps: posicao ? { lat: posicao.lat, lng: posicao.lng, precisao: posicao.precisao } : null,
    });

    ChatService.mensagemSistema(requestId, `📍 Profissional registrou chegada ao imóvel${simulado ? ' (simulada — DEV)' : ''}. (${new Date().toLocaleString('pt-BR')})`);
    NotificationsService.criar(atual.owner_id, 'chegada', 'Profissional chegou', 'O profissional registrou a chegada ao imóvel.');
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider(providerId), acao:'registrar_chegada', entidade:'service_requests', entidade_id:requestId, dados_novos:{ distanciaKm: distanciaKmCalc, dentroDoRaio, evidencia_id: evidencia.id, simulado } });

    return { solicitacao: DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.ARRIVED }), distanciaKm: distanciaKmCalc, dentroDoRaio, simulado };
  },

  /**
   * Conferência obrigatória: "A solicitação corresponde ao que você encontrou?"
   * SIM → CHECKING → IN_PROGRESS. NÃO → abre divergência (ver disputesService).
   *
   * Exige checklist de pré-vistoria concluído (com vídeo obrigatório) antes de
   * permitir a resposta. Também é seguro chamar de novo enquanto já em CHECKING
   * (ex.: profissional respondeu "Não" e fechou o modal de divergência sem
   * enviar — sem isso a solicitação ficaria travada, pois CHECKING→CHECKING
   * não é uma transição válida em TRANSICOES_ATIVAS).
   */
  responderConferencia(providerId, requestId, corresponde){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.accepted_provider_id !== providerId) throw new Error('Você não está atribuído a esta solicitação.');

    const jaEmConferencia = atual.status === STATUS_SOLICITACAO.CHECKING;
    if(!jaEmConferencia && !transicaoPermitida(atual.status, STATUS_SOLICITACAO.CHECKING)){
      throw new Error('Status atual não permite conferência.');
    }

    const checklistRun = ChecklistService.obterPorSolicitacao(requestId);
    if(!checklistRun || !checklistRun.concluido){
      throw new Error('Conclua o checklist de pré-vistoria (incluindo o vídeo obrigatório) antes de responder à conferência.');
    }

    if(!jaEmConferencia){
      DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.CHECKING });
    }

    if(corresponde){
      ChatService.mensagemSistema(requestId, '✅ Profissional confirmou: a solicitação corresponde ao encontrado no imóvel. Serviço iniciado.');
      AuditLogService.registrar({ user_id: UsersService_userIdDoProvider(providerId), acao:'conferencia_confirmada', entidade:'service_requests', entidade_id:requestId });
      return { solicitacao: DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.IN_PROGRESS }), divergencia: null };
    }
    // Se NÃO corresponde, quem chama a tela deve em seguida abrir a divergência
    // via DisputesService.abrirDivergencia (que já move o status para DISPUTED).
    return { solicitacao: DB.find('service_requests', requestId), divergencia: 'pendente_abertura' };
  },

  /** Profissional finaliza: envia fotos, checklist, observações e horário de término. */
  finalizarExecucao(providerId, requestId, { fotos, checklist, observacoes, horario_termino }){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.accepted_provider_id !== providerId) throw new Error('Você não está atribuído a esta solicitação.');
    if(!transicaoPermitida(atual.status, STATUS_SOLICITACAO.UNDER_REVIEW)) throw new Error('Status atual não permite finalizar.');
    if(BLOQUEIOS_CONFIG.posVistoriaObrigatoria){
      const posRun = ChecklistService.obterPorSolicitacao(requestId, 'pos');
      if(!posRun || !posRun.concluido) throw new Error('Conclua a pós-vistoria (antes/depois) antes de finalizar o serviço.');
    }

    const finalizacao = { fotos: fotos||[], checklist: checklist||[], observacoes: observacoes||'', horario_termino, enviado_em: new Date().toISOString() };
    EvidencesService.registrar({ service_request_id: requestId, user_id: UsersService_userIdDoProvider(providerId), tipo:'finalizacao_execucao', texto: observacoes||'Serviço finalizado pelo profissional.', fotos: fotos||[] });
    ChatService.mensagemSistema(requestId, `🏁 Profissional finalizou o serviço às ${horario_termino}. Aguardando confirmação do anfitrião.`);
    NotificationsService.criar(atual.owner_id, 'conclusao', 'Serviço finalizado — confirme', 'O profissional finalizou o serviço e enviou fotos/checklist. Confira e confirme a conclusão.');
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider(providerId), acao:'finalizar_execucao', entidade:'service_requests', entidade_id:requestId });

    return DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.UNDER_REVIEW, finalizacao });
  },

  /** Anfitrião confirma a conclusão (revisão humana — a plataforma não decide sozinha). */
  confirmarConclusao(ownerId, requestId){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.owner_id !== ownerId) throw new Error('Solicitação não encontrada.');
    if(!transicaoPermitida(atual.status, STATUS_SOLICITACAO.COMPLETED)) throw new Error('Status atual não permite confirmar conclusão.');

    const atualizado = DB.update('service_requests', requestId, { status: STATUS_SOLICITACAO.COMPLETED });
    ChatService.mensagemSistema(requestId, '🎉 Anfitrião confirmou a conclusão do serviço.');
    AuditLogService.registrar({ user_id: ownerId, acao:'confirmar_conclusao', entidade:'service_requests', entidade_id:requestId });

    // Dispara o início da liberação financeira (não libera de imediato — ver PaymentsService).
    try{ PaymentsService.iniciarLiberacao(requestId); }catch(e){ /* pagamento pode não existir em dados de teste antigos */ }

    if(atual.accepted_provider_id){
      const p = DB.find('providers', atual.accepted_provider_id);
      if(p) NotificationsService.criar(p.user_id, 'pagamento_liberado', 'Conclusão confirmada', 'O anfitrião confirmou a conclusão. O pagamento entrou em processo de liberação.');
    }
    return atualizado;
  },

  marcarConcluido(providerId, requestId){
    // Mantido por compatibilidade — agora só finaliza (UNDER_REVIEW); a
    // conclusão definitiva depende da confirmação do anfitrião (ver acima).
    return this.finalizarExecucao(providerId, requestId, { horario_termino: new Date().toTimeString().slice(0,5) });
  },

  /**
   * ---------- Reparos ("nova avaliação/orçamento") e Enxoval (recontagem) ----------
   * O profissional NUNCA é obrigado a executar um escopo diferente sem
   * alteração formal aprovada pelo anfitrião. Isso cria uma proposta
   * pendente; nada muda de fato até `responderPropostaAlteracao`.
   */
  proporAlteracao(providerId, requestId, { novosDetalhes, motivo }){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.accepted_provider_id !== providerId) throw new Error('Você não está atribuído a esta solicitação.');
    if([STATUS_SOLICITACAO.COMPLETED, STATUS_SOLICITACAO.CANCELLED].includes(atual.status)) throw new Error('Não é possível propor alteração numa solicitação finalizada.');

    const detalhesMesclados = Object.assign({}, atual.detalhes, novosDetalhes);
    const novaPrecificacao = PricingService.calcular({
      categoria: atual.categoria, data: atual.data, horario: atual.horario, urgencia: atual.urgencia,
      limpeza: atual.categoria === CATEGORIAS_SERVICO.LIMPEZA ? detalhesMesclados : undefined,
      reparo: atual.categoria === CATEGORIAS_SERVICO.REPAROS ? detalhesMesclados : undefined,
      enxoval: atual.categoria === CATEGORIAS_SERVICO.ENXOVAL ? detalhesMesclados : undefined,
    });

    const proposta = {
      proposto_em: new Date().toISOString(), motivo,
      detalhes_originais: atual.detalhes, detalhes_propostos: detalhesMesclados,
      precificacao_original: atual.precificacao, precificacao_proposta: novaPrecificacao,
    };
    const atualizado = DB.update('service_requests', requestId, { alteracao_pendente: proposta });

    ChatService.mensagemSistema(requestId, `📋 Profissional propôs uma alteração formal: ${motivo}. Aguardando sua aprovação.`);
    NotificationsService.criar(atual.owner_id, 'alteracao', 'Nova proposta de alteração', `O profissional propôs uma alteração: ${motivo}. Novo valor: R$ ${novaPrecificacao.valorAnfitriao.toFixed(2)}.`);
    AuditLogService.registrar({ user_id: UsersService_userIdDoProvider(providerId), acao:'propor_alteracao', entidade:'service_requests', entidade_id:requestId, dados_novos:{ motivo } });
    return atualizado;
  },

  responderPropostaAlteracao(ownerId, requestId, aprovar){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.owner_id !== ownerId) throw new Error('Solicitação não encontrada.');
    if(!atual.alteracao_pendente) throw new Error('Não há proposta de alteração pendente.');

    const proposta = atual.alteracao_pendente;
    if(!aprovar){
      DB.update('service_requests', requestId, { alteracao_pendente: null });
      ChatService.mensagemSistema(requestId, '❌ Anfitrião rejeitou a proposta de alteração.');
      if(atual.accepted_provider_id) NotificationsService.criar(UsersService_userIdDoProvider(atual.accepted_provider_id), 'alteracao', 'Proposta rejeitada', 'O anfitrião não aprovou a alteração proposta.');
      return DB.find('service_requests', requestId);
    }

    // Aprovado: aplica formalmente (fica no historico_alteracoes) + ajusta o pagamento
    const atualizado = this.alterarFormalmente(ownerId, requestId, {
      detalhes: proposta.detalhes_propostos, precificacao: proposta.precificacao_proposta, alteracao_pendente: null,
    }, 'Proposta do profissional aprovada: ' + proposta.motivo);

    const pagamentoExistente = PaymentsService.obterPorSolicitacao(requestId);
    if(!pagamentoExistente){
      PaymentsService.criarEAutorizar(requestId); // ex.: reparo que era "necessita avaliação" e agora tem valor
    } else {
      const diff = proposta.precificacao_proposta.valorProfissional - proposta.precificacao_original.valorProfissional;
      DB.update('payments', pagamentoExistente.id, {
        valor_anfitriao: proposta.precificacao_proposta.valorAnfitriao,
        valor_profissional: proposta.precificacao_proposta.valorProfissional,
        comissao_plataforma: proposta.precificacao_proposta.comissaoPlataforma,
        ajustes: (pagamentoExistente.ajustes||[]).concat([{ descricao:'Alteração formal aprovada: '+proposta.motivo, valor: diff, em: new Date().toISOString() }]),
      });
    }

    ChatService.mensagemSistema(requestId, '✅ Anfitrião aprovou a alteração. Novo valor aplicado.');
    if(atual.accepted_provider_id) NotificationsService.criar(UsersService_userIdDoProvider(atual.accepted_provider_id), 'alteracao', 'Proposta aprovada', 'O anfitrião aprovou sua proposta de alteração.');
    return atualizado;
  },

  /**
   * ---------- Reclassificação de modalidade de Limpeza (Padrão → Pesada/Pós-obra) ----------
   * Diferente de `proporAlteracao` (aprovada pelo anfitrião), esta proposta só
   * pode ser decidida pelo ADMINISTRADOR, e exige evidência (foto/vídeo) do
   * profissional — é um apontamento de que o escopo real diverge do
   * publicado, não uma negociação comercial entre as partes.
   */
  proporReclassificacaoLimpeza(providerId, requestId, { modalidadeProposta, motivo, fotos, videos, gps }){
    const atual = DB.find('service_requests', requestId);
    if(!atual || atual.accepted_provider_id !== providerId) throw new Error('Você não está atribuído a esta solicitação.');
    if(atual.categoria !== CATEGORIAS_SERVICO.LIMPEZA) throw new Error('Reclassificação de modalidade só se aplica a serviços de Limpeza.');
    if([STATUS_SOLICITACAO.COMPLETED, STATUS_SOLICITACAO.CANCELLED].includes(atual.status)) throw new Error('Não é possível reclassificar uma solicitação finalizada.');
    if(!MODALIDADES_LIMPEZA.includes(modalidadeProposta)) throw new Error('Modalidade de limpeza inválida.');
    const modalidadeAtual = (atual.detalhes && atual.detalhes.tipo) || 'padrão';
    if(modalidadeProposta === modalidadeAtual) throw new Error('A modalidade proposta é igual à já publicada.');
    if((!fotos || fotos.length === 0) && (!videos || videos.length === 0)){
      throw new Error('Anexe ao menos uma foto ou vídeo como evidência da reclassificação.');
    }
    if(atual.reclassificacao_pendente) throw new Error('Já existe uma reclassificação pendente de decisão para esta solicitação.');

    const userId = UsersService_userIdDoProvider(providerId);
    const evidencia = EvidencesService.registrar({ service_request_id: requestId, user_id: userId, tipo:'reclassificacao_limpeza', texto: motivo, fotos, videos, gps });

    const pendente = {
      proposto_por_provider_id: providerId, motivo, modalidade_atual: modalidadeAtual, modalidade_proposta: modalidadeProposta,
      evidencia_id: evidencia.id, proposto_em: new Date().toISOString(),
    };
    const atualizado = DB.update('service_requests', requestId, { reclassificacao_pendente: pendente });

    ChatService.mensagemSistema(requestId, `📋 Profissional apontou que a faxina "${modalidadeAtual}" pode ser na verdade "${modalidadeProposta}", com evidências anexadas. Aguardando análise do administrador.`);
    NotificationsService.criar(atual.owner_id, 'alteracao', 'Reclassificação em análise', `O profissional enviou evidências de que a faxina pode ser "${modalidadeProposta}". Um administrador vai analisar antes de qualquer cobrança.`);
    AuditLogService.registrar({ user_id: userId, acao:'propor_reclassificacao_limpeza', entidade:'service_requests', entidade_id:requestId, dados_novos:pendente });
    return atualizado;
  },

  listarReclassificacoesPendentes(){
    return DB.list('service_requests', s => !!s.reclassificacao_pendente);
  },

  /** Decisão do ADMINISTRADOR: aprova (recalcula + cobra a diferença automaticamente) ou rejeita. */
  decidirReclassificacaoLimpeza(adminUserId, requestId, aprovar){
    const atual = DB.find('service_requests', requestId);
    if(!atual || !atual.reclassificacao_pendente) throw new Error('Não há reclassificação pendente para esta solicitação.');
    const pendente = atual.reclassificacao_pendente;
    const providerUserId = atual.accepted_provider_id ? UsersService_userIdDoProvider(atual.accepted_provider_id) : null;

    if(!aprovar){
      DB.update('service_requests', requestId, { reclassificacao_pendente: null });
      ChatService.mensagemSistema(requestId, '❌ Administrador não confirmou a reclassificação — modalidade e valor originais mantidos.');
      if(providerUserId) NotificationsService.criar(providerUserId, 'alteracao', 'Reclassificação não confirmada', 'O administrador analisou as evidências e manteve a modalidade original.');
      AuditLogService.registrar({ user_id: adminUserId, acao:'rejeitar_reclassificacao_limpeza', entidade:'service_requests', entidade_id:requestId });
      return DB.find('service_requests', requestId);
    }

    const novosDetalhes = Object.assign({}, atual.detalhes, { tipo: pendente.modalidade_proposta });
    const novaPrecificacao = PricingService.calcular({
      categoria: atual.categoria, data: atual.data, horario: atual.horario, urgencia: atual.urgencia, limpeza: novosDetalhes,
    });
    const precificacaoOriginal = atual.precificacao;

    const evento = {
      em: new Date().toISOString(),
      motivo: `Reclassificação aprovada pelo ADM (${pendente.modalidade_atual} → ${pendente.modalidade_proposta}): ${pendente.motivo}`,
      campos_antes: { detalhes: atual.detalhes, precificacao: precificacaoOriginal },
      campos_depois: { detalhes: novosDetalhes, precificacao: novaPrecificacao },
    };
    const historico = (atual.historico_alteracoes || []).concat([evento]);
    const atualizado = DB.update('service_requests', requestId, {
      detalhes: novosDetalhes, precificacao: novaPrecificacao, reclassificacao_pendente: null, historico_alteracoes: historico,
    });
    AuditLogService.registrar({ user_id: adminUserId, acao:'aprovar_reclassificacao_limpeza', entidade:'service_requests', entidade_id:requestId, dados_anteriores: evento.campos_antes, dados_novos: evento.campos_depois });

    // Recalcula e cobra automaticamente a diferença (arquitetura de pagamento simulada — ver paymentGatewayAdapter.js).
    const pagamentoExistente = PaymentsService.obterPorSolicitacao(requestId);
    const diffAnfitriao = novaPrecificacao.valorAnfitriao - precificacaoOriginal.valorAnfitriao;
    if(!pagamentoExistente){
      PaymentsService.criarEAutorizar(requestId);
    } else {
      DB.update('payments', pagamentoExistente.id, {
        valor_anfitriao: novaPrecificacao.valorAnfitriao,
        valor_profissional: novaPrecificacao.valorProfissional,
        comissao_plataforma: novaPrecificacao.comissaoPlataforma,
        ajustes: (pagamentoExistente.ajustes || []).concat([{
          descricao: `Reclassificação aprovada (${pendente.modalidade_atual} → ${pendente.modalidade_proposta}) — diferença cobrada automaticamente`,
          valor: novaPrecificacao.valorProfissional - precificacaoOriginal.valorProfissional,
          em: new Date().toISOString(),
        }]),
      });
    }

    ChatService.mensagemSistema(requestId, `✅ Administrador confirmou a reclassificação para "${pendente.modalidade_proposta}". Novo valor: R$ ${novaPrecificacao.valorAnfitriao.toFixed(2)} (diferença de R$ ${diffAnfitriao.toFixed(2)} cobrada automaticamente).`);
    NotificationsService.criar(atual.owner_id, 'alteracao', 'Faxina reclassificada', `O administrador confirmou que a faxina é "${pendente.modalidade_proposta}". A diferença de R$ ${diffAnfitriao.toFixed(2)} foi cobrada automaticamente.`);
    if(providerUserId) NotificationsService.criar(providerUserId, 'alteracao', 'Reclassificação aprovada', `O administrador confirmou "${pendente.modalidade_proposta}". Valor atualizado.`);
    return atualizado;
  },

  obterSeDono(ownerId, requestId){
    const r = DB.find('service_requests', requestId);
    return (r && r.owner_id === ownerId) ? r : null;
  },
  obter(requestId){ return DB.find('service_requests', requestId); },
  listarDoAnfitriao(ownerId){
    return DB.list('service_requests', r => r.owner_id === ownerId).sort((a,b)=> new Date(b.created_at)-new Date(a.created_at));
  },
  listarPublicadas(){
    return DB.list('service_requests', r => r.status === STATUS_SOLICITACAO.PUBLISHED);
  },
};

/** Pequeno helper local — evita importar UsersService só por essa consulta. */
function UsersService_userIdDoProvider(providerId){
  const p = DB.find('providers', providerId);
  return p ? p.user_id : null;
}
