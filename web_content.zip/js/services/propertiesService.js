/**
 * propertiesService.js — regras de negócio sobre a tabela PROPERTIES (imóveis).
 * Autorização (owner_id === usuário logado) é checada aqui, na camada de
 * serviço — não apenas escondendo botões na interface — para que, no dia em
 * que existir um backend real, a mesma regra baste ser copiada para lá.
 */
const PropertiesService = {
  criar(ownerId, dadosForm){
    const base = Models.novoImovel({ owner_id: ownerId });
    const imovel = Object.assign({}, base, dadosForm, { owner_id: ownerId });
    const criado = DB.insert('properties', imovel);
    AuditLogService.registrar({ user_id: ownerId, acao:'criar_imovel', entidade:'properties', entidade_id:criado.id, dados_novos:dadosForm });
    return criado;
  },

  atualizar(ownerId, imovelId, dadosForm){
    const atual = DB.find('properties', imovelId);
    if(!atual) throw new Error('Imóvel não encontrado.');
    if(atual.owner_id !== ownerId) throw new Error('Você não tem permissão para editar este imóvel.');
    const atualizado = DB.update('properties', imovelId, dadosForm);
    AuditLogService.registrar({ user_id: ownerId, acao:'editar_imovel', entidade:'properties', entidade_id:imovelId, dados_anteriores:atual, dados_novos:dadosForm });
    return atualizado;
  },

  /** Ativa ou desativa (nunca exclui fisicamente). */
  definirStatus(ownerId, imovelId, status){
    const atual = DB.find('properties', imovelId);
    if(!atual) throw new Error('Imóvel não encontrado.');
    if(atual.owner_id !== ownerId) throw new Error('Você não tem permissão para alterar este imóvel.');
    const atualizado = DB.setStatus('properties', imovelId, status);
    AuditLogService.registrar({ user_id: ownerId, acao:'status_imovel', entidade:'properties', entidade_id:imovelId, dados_anteriores:{status:atual.status}, dados_novos:{status} });
    return atualizado;
  },

  obterSeDono(ownerId, imovelId){
    const imovel = DB.find('properties', imovelId);
    if(!imovel || imovel.owner_id !== ownerId) return null;
    return imovel;
  },

  listarDoAnfitriao(ownerId){
    return DB.list('properties', p => p.owner_id === ownerId);
  },

  /** Todos os imóveis — uso exclusivo do painel administrativo. */
  listarTodos(){
    return DB.list('properties');
  },

  /** Ativa/inativa um imóvel — ação do administrador (independe do dono). */
  adminDefinirStatus(adminId, imovelId, status){
    const atual = DB.find('properties', imovelId);
    if(!atual) throw new Error('Imóvel não encontrado.');
    const atualizado = DB.update('properties', imovelId, { status });
    AuditLogService.registrar({ user_id: adminId, acao:'admin_status_imovel', entidade:'properties', entidade_id:imovelId, dados_anteriores:{status:atual.status}, dados_novos:{status} });
    return atualizado;
  },

  /**
   * Exclusão LÓGICA (arquivamento) do imóvel pelo administrador — nunca remove
   * o cadastro, ambientes, inventário, checklist ou histórico de serviços já
   * realizados nele. Fica fora das buscas ativas, mas pode retornar no futuro.
   */
  excluir(adminId, imovelId){
    const atual = DB.find('properties', imovelId);
    if(!atual) throw new Error('Imóvel não encontrado.');
    const atualizado = DB.update('properties', imovelId, {
      excluido: true, excluido_em: new Date().toISOString(), admin_responsavel_exclusao_id: adminId, status: 'inativo',
    });
    AuditLogService.registrar({ user_id: adminId, acao:'excluir_imovel', entidade:'properties', entidade_id:imovelId, dados_novos:{excluido:true} });
    return atualizado;
  },

  /** Reverte o arquivamento — o imóvel volta a existir normalmente (inativo, para o dono reativar). */
  reativarExcluido(adminId, imovelId){
    const atualizado = DB.update('properties', imovelId, { excluido: false, excluido_em: null });
    AuditLogService.registrar({ user_id: adminId, acao:'reativar_imovel_excluido', entidade:'properties', entidade_id:imovelId, dados_novos:{excluido:false} });
    return atualizado;
  },

  /** Busca pública — só imóveis ativos e não excluídos, filtrando por geolocalização. */
  buscarAtivos({ estado, cidade, bairro } = {}){
    return DB.list('properties', p =>
      p.status === 'ativo' && !p.excluido &&
      (!estado || p.estado === estado) &&
      (!cidade || p.cidade === cidade) &&
      (!bairro || p.bairro === bairro)
    );
  },
};
