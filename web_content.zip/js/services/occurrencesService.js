/**
 * occurrencesService.js
 * Registro de ocorrências OPERACIONAIS do profissional (atraso, cancelamento,
 * divergência, problema na execução etc.) — nunca "antecedentes criminais".
 * Casos graves continuam no fluxo de disputa/admin; isto aqui é só o
 * resumo objetivo que pode aparecer de forma agregada (contagem) no cartão
 * do profissional, sem detalhar o conteúdo para terceiros.
 */
const OccurrencesService = {
  registrar(providerId, tipo, descricao, { serviceRequestId, registradoPor } = {}){
    return DB.insert('occurrences', Models.novaOcorrencia({
      provider_id: providerId, tipo, descricao,
      service_request_id: serviceRequestId, registrado_por: registradoPor,
    }));
  },
  listarPorProvider(providerId){
    return DB.list('occurrences', o => o.provider_id === providerId).sort((a,b)=> new Date(b.created_at)-new Date(a.created_at));
  },
  contarPorProvider(providerId){
    return this.listarPorProvider(providerId).length;
  },
};
