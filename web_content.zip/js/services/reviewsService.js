/**
 * reviewsService.js — avaliações mútuas entre as partes.
 */
const ReviewsService = {
  criar({ service_request_id, avaliador_id, avaliado_id, nota, comentario }){
    const review = DB.insert('reviews', Models.novaReview({ service_request_id, avaliador_id, avaliado_id, nota, comentario }));
    ProvidersService.recalcularReputacao(avaliado_id);
    return review;
  },
  listarRecebidas(userId){
    return DB.list('reviews', r => r.avaliado_id === userId);
  },
};
