/**
 * chatService.js
 * Chat OFICIAL de cada solicitação (não é um chat genérico — toda mensagem
 * tem service_request_id). Aplica o filtro de contato externo ANTES de
 * gravar qualquer mensagem: uma mensagem bloqueada nunca chega ao banco,
 * apenas a tentativa fica registrada em `contact_violations` + auditoria.
 */
const ChatService = {

  /**
   * @param {number} solicitanteUserId — quem está enviando
   * @param {number} requestId
   * @param {{tipo:string, texto?:string, anexos?:Array}} dados
   * @throws {Error} com `.bloqueado = true` quando a mensagem contém contato externo
   */
  enviarMensagem(remetenteUserId, requestId, { tipo = 'texto', texto = '', anexos = [] }){
    const solicitacao = DB.find('service_requests', requestId);
    if(!solicitacao) throw new Error('Solicitação não encontrada.');
    this._garantirParticipante(remetenteUserId, solicitacao);

    if(tipo === 'texto' || tipo === 'documento'){
      const analise = ContactFilter.analisar(texto);
      if(analise.bloqueado){
        this._registrarTentativaBloqueada(remetenteUserId, requestId, texto, analise.motivos);
        const erro = new Error(ContactFilter.MENSAGEM_BLOQUEIO);
        erro.bloqueado = true;
        erro.motivos = analise.motivos;
        throw erro;
      }
    }

    const msg = DB.insert('chat_messages', Models.novaMensagem({ service_request_id: requestId, remetente_id: remetenteUserId, tipo, texto, anexos }));
    AuditLogService.registrar({ user_id: remetenteUserId, acao:'enviar_mensagem_chat', entidade:'service_requests', entidade_id:requestId, dados_novos:{ tipo, mensagem_id: msg.id } });
    return msg;
  },

  /** Mensagens automáticas do sistema (sem remetente humano, não passam pelo filtro). */
  mensagemSistema(requestId, texto){
    return DB.insert('chat_messages', Models.novaMensagem({ service_request_id: requestId, remetente_id: null, tipo: 'sistema', texto }));
  },

  listarPorSolicitacao(requestId){
    return DB.list('chat_messages', m => m.service_request_id === requestId)
      .sort((a,b)=> new Date(a.created_at) - new Date(b.created_at));
  },

  _garantirParticipante(userId, solicitacao){
    const ehAnfitriao = solicitacao.owner_id === userId;
    const provider = DB.findOne('providers', p => p.user_id === userId);
    const ehProfissionalAceito = provider && solicitacao.accepted_provider_id === provider.id;
    const ehProfissionalInteressado = provider && DB.findOne('interests', i => i.service_request_id === solicitacao.id && i.provider_id === provider.id);
    if(!ehAnfitriao && !ehProfissionalAceito && !ehProfissionalInteressado){
      throw new Error('Você não tem acesso a este chat.');
    }
  },

  /**
   * Registra a tentativa bloqueada e aplica escalonamento por reincidência:
   * 3 tentativas → alerta (notificação); 5 → restrição (audit apenas, sem
   * suspender automaticamente); 8+ → suspensão da conta (ação real).
   */
  _registrarTentativaBloqueada(userId, requestId, texto, motivos){
    DB.insert('contact_violations', { user_id: userId, service_request_id: requestId, texto_original: texto, motivos });
    AuditLogService.registrar({ user_id: userId, acao:'tentativa_contato_externo_bloqueada', entidade:'service_requests', entidade_id:requestId, dados_novos:{ motivos } });

    const total = DB.list('contact_violations', v => v.user_id === userId).length;
    if(total === 3){
      NotificationsService.criar(userId, 'alteracao', 'Aviso de segurança', 'Detectamos tentativas de compartilhar contato externo. Reincidência pode levar à suspensão da conta.');
    } else if(total >= 8){
      const usuario = DB.find('users', userId);
      if(usuario && usuario.status === 'ativo'){
        DB.setStatus('users', userId, 'suspenso');
        AuditLogService.registrar({ user_id: userId, acao:'suspensao_automatica_contato_externo', entidade:'users', entidade_id:userId, dados_novos:{ total_tentativas: total } });
      }
    }
    return total;
  },
};
