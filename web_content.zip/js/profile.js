// =======================================
// NetEarn Pro - SECURE PROFILE SYSTEM
// Firebase Auth + Firestore + Live Wallet
// =======================================

import { auth, db } from "./firebase.js";

import {
onAuthStateChanged,
signOut,
updateEmail,
updatePassword,
reauthenticateWithCredential,
EmailAuthProvider
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
doc,
getDoc,
setDoc,
onSnapshot,
collection,
query,
where,
getDocs
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

// =======================================
// ELEMENTS
// =======================================

const profilePreview =
document.getElementById("profilePreview");

const photoUpload =
document.getElementById("photoUpload");

const saveBtn =
document.getElementById("saveBtn");

const userName =
document.getElementById("userName");

const userNameText =
document.getElementById("userNameText");


const nameText =
document.getElementById("nameText");

const netEarnId =
document.getElementById("netEarnId");

const referralCode =
document.getElementById("referralCode");

const verifyStatus =
document.getElementById("verifyStatus");

const logoutBtn =
document.getElementById("logoutBtn");

const changePasswordBtn =
document.getElementById("changePasswordBtn");

// =======================================
// FORM ELEMENTS
// =======================================

const fullName =
document.getElementById("fullName");

const username =
document.getElementById("username");

const phone =
document.getElementById("phone");

const email =
document.getElementById("email");

const address =
document.getElementById("address");

// =======================================
// OPTIONAL PREMIUM CARD
// =======================================

const premiumCard =
document.getElementById("premiumCard");

// =======================================
// STATE
// =======================================

let currentUserId = "";
let currentAuthUser = null;
let currentUserData = {};
let unsubscribeUser = null;

// =======================================
// FAST PROFILE CACHE
// =======================================

function loadCachedProfile() {

    try {

        const cached =
            sessionStorage.getItem(
                "netearnProfileCache"
            );


        if (!cached) {

            return false;

        }


        const parsed =
            JSON.parse(cached);


        // ---------------------------------
        // Cache validity check
        // ---------------------------------

        if (
            !parsed ||
            !parsed.data ||
            !parsed.uid
        ) {

            return false;

        }


        // ---------------------------------
        // Current Firebase user check
        // ---------------------------------

        if (
            auth.currentUser &&
            parsed.uid !==
            auth.currentUser.uid
        ) {

            return false;

        }


        // ---------------------------------
        // Use cached data immediately
        // ---------------------------------

        currentUserData =
            parsed.data;


        currentUserId =
            getNetEarnId(
                parsed.data
            );


        // ---------------------------------
        // Show UI immediately
        // ---------------------------------

        updateVerificationUI(
            parsed.data
        );


        updateBasicProfileUI(
            parsed.data
        );


        loadFormData(
            parsed.data
        );


        // ---------------------------------
        // Profile photo
        // ---------------------------------

        // ---------------------------------
        // Profile photo
        // Always use the same user-specific
        // photo source as the live profile.
        // ---------------------------------

        loadProfilePhoto();


        // ---------------------------------
        // Wallet immediately
        // ---------------------------------

        updateProfileWalletUI(
            parsed.data,
            0
        );


        console.log(
            "⚡ Profile loaded from cache"
        );


        return true;

    }

    catch (error) {

        console.warn(
            "⚠️ Profile cache read failed:",
            error
        );


        return false;

    }

}

// =======================================
// MONEY FORMAT
// =======================================

function money(value) {

const number =  
    Number(value || 0);  

if (!Number.isFinite(number)) {  
    return "৳0";  
}  

return (  
    "৳" +  
    number.toLocaleString("en-BD")  
);

}

// =======================================
// SAFE STRING
// =======================================

function safeText(
value,
fallback = ""
) {

if (  
    value === null ||  
    value === undefined  
) {  
    return fallback;  
}  

return String(value);

}

// =======================================
// WALLET SUMMARY
// =======================================

function updateProfileWalletUI(
data,
withdrawnAmount = 0
) {

const mainBalance =  
    Number(data.balance || 0);  

const totalEarnings =  
    Number(data.totalEarnings || 0);  

const referralCommission =  
    Number(data.referralCommission || 0);  


const mainElement =  
    document.getElementById(  
        "profileMainBalance"  
    );  

const profitElement =  
    document.getElementById(  
        "profileProfitBalance"  
    );  

const referralElement =  
    document.getElementById(  
        "profileReferralIncome"  
    );  

const withdrawElement =  
    document.getElementById(  
        "profileWithdraw"  
    );  


if (mainElement) {  

    mainElement.innerText =  
        money(mainBalance);  

}  


if (profitElement) {  

    profitElement.innerText =  
        money(totalEarnings);  

}  


if (referralElement) {  

    referralElement.innerText =  
        money(referralCommission);  

}  


if (withdrawElement) {  

    withdrawElement.innerText =  
        money(withdrawnAmount);  

}  


// ---------------------------------  
// Fallback wallet cards  
// ---------------------------------  

const walletCards =  
    document.querySelectorAll(  
        ".wallet-grid > div"  
    );  


if (  
    walletCards &&  
    walletCards.length >= 4  
) {  

    const values = [  
        mainBalance,  
        totalEarnings,  
        referralCommission,  
        withdrawnAmount  
    ];  


    walletCards.forEach(  
        (card, index) => {  

            const amount =  
                card.querySelector("h3");  


            if (  
                amount &&  
                values[index] !== undefined  
            ) {  

                amount.innerText =  
                    money(values[index]);  

            }  

        }  
    );  

}

}

// =======================================
// GET TOTAL WITHDRAW
// =======================================

async function getWithdrawTotal(
uid,
userId = ""
) {

const collectionRef =  
    collection(  
        db,  
        "withdrawRequests"  
    );  


const documents =  
    new Map();  


try {  

    // ---------------------------------  
    // Search by Firebase UID  
    // ---------------------------------  

    if (uid) {  

        const q1 =  
            query(  
                collectionRef,  
                where(  
                    "uid",  
                    "==",  
                    uid  
                )  
            );  


        const snap1 =  
            await getDocs(q1);  


        snap1.forEach(  
            item => {  

                documents.set(  
                    item.id,  
                    item.data()  
                );  

            }  
        );  

    }  


    // ---------------------------------  
    // SECURITY/COMPATIBILITY NOTE  
    // ---------------------------------  
    // Current withdraw.js stores both uid and userId, but  
    // both values are the authenticated Firebase UID.  
    // Query only by uid so Firestore Rules can prove that  
    // every returned document belongs to the current user.  
    // This avoids a permission-denied error from the second  
    // userId query without changing withdrawal calculations.  


    let total = 0;  


    documents.forEach(  
        data => {  

            const status =  
                String(  
                    data.status || ""  
                ).toLowerCase();  


            const validStatus = [  
                "approved",  
                "completed",  
                "complete",  
                "paid",  
                "success",  
                "successful"  
            ].includes(status);  


            if (!validStatus) {  
                return;  
            }  


            const amount =  
                Number(  
                    data.amount ??  
                    data.withdrawAmount ??  
                    data.requestedAmount ??  
                    0  
                );  


            if (  
                Number.isFinite(amount)  
            ) {  

                total += amount;  

            }  

        }  
    );  


    return total;  

}  

catch (error) {  

    console.error(  
        "❌ Withdraw total error:",  
        error  
    );  

    return 0;  

}

}

// =======================================
// NETEARN ID
// IMPORTANT:
// Firebase UID NEVER shown as NetEarn ID
// =======================================

function getNetEarnId(data) {

return (  

    safeText(data.userId) ||  

    safeText(data.netEarnId) ||  

    safeText(data.netEarnID) ||  

    safeText(data.netEarnCode) ||  

    safeText(data.userCode) ||  

    safeText(data.memberId) ||  

    safeText(data.memberID) ||  

    ""  

);

}

// =======================================
// LOAD PROFILE PHOTO
// USER-SPECIFIC ONLY
// =======================================

// Prevent the default avatar from flashing before the
// user-specific photo is ready. The image is swapped only
// after the target source has loaded successfully.
function setProfilePhotoNoFlash(src) {

if (!profilePreview) {
    return;
}

const target =
    src ||
    "images/default-user.png";

// Keep the HTML default avatar visible at all times.
// A user photo is loaded in the background and replaces
// the default only after it has loaded successfully.
if (target === "images/default-user.png") {
    profilePreview.src = target;
    return;
}

const preload = new Image();

preload.onload = () => {
    profilePreview.src = target;
};

preload.onerror = () => {
    // Keep the already-visible default avatar.
    profilePreview.src = "images/default-user.png";
};

preload.src = target;
}

function loadProfilePhoto() {

if (!profilePreview) {  
    return;  
}  


// ---------------------------------  
// Firebase UID  
// ---------------------------------  

const uid =  
    auth.currentUser?.uid;  


if (!uid) {  

    setProfilePhotoNoFlash(
        "images/default-user.png"
    );

    return;  

}  


// ---------------------------------  
// User-specific storage key  
// ---------------------------------  

const storageKey =  
    `profilePhoto_${uid}`;  


const savedPhoto =  
    localStorage.getItem(  
        storageKey  
    );  


// ---------------------------------  
// Show saved photo  
// ---------------------------------  

if (savedPhoto) {  

    setProfilePhotoNoFlash(
        savedPhoto
    );

    return;  

}  


// ---------------------------------  
// Default photo  
// ---------------------------------  

setProfilePhotoNoFlash(
    "images/default-user.png"
);

}

// =======================================
// LOAD USER PROFILE
// =======================================

async function loadUserProfile(
user
) {

if (!user) {  
    return;  
}  


const userRef =  
    doc(  
        db,  
        "users",  
        user.uid  
    );  


const [snapshot, withdrawnAmount] =
    await Promise.all([
        getDoc(userRef),
        getWithdrawTotal(user.uid)
    ]);


if (!snapshot.exists()) {  

    console.warn(  
        "⚠️ User document not found:",  
        user.uid  
    );  

    return;  

}  


const data =  
    snapshot.data();  


currentUserData =  
    data;  
    
    
    // =======================================
// UPDATE PROFILE CACHE
// =======================================

try {

    const cache = {

        uid:
            user.uid,

        data:
            data,

        photo:
            localStorage.getItem(
                `profilePhoto_${user.uid}`
            ),

        cachedAt:
            Date.now()

    };


    sessionStorage.setItem(
        "netearnProfileCache",
        JSON.stringify(cache)
    );

}

catch (error) {

    console.warn(
        "⚠️ Profile cache update failed:",
        error
    );

}


// ---------------------------------  
// IMPORTANT  
// Always prefer Firestore userId.  
// Never display Firebase UID.  
// ---------------------------------  

currentUserId =  
    getNetEarnId(data);  


updateVerificationUI(  
    data  
);  


updateBasicProfileUI(  
    data  
);  


loadFormData(  
    data  
);  


loadProfilePhoto();  


updateProfileWalletUI(  
    data,  
    withdrawnAmount  
);

return withdrawnAmount;

}


// =======================================
// VERIFICATION UI
// 3 STATES
// Not Verified → Pending → Verified
// =======================================

function updateVerificationUI(data) {

    if (!verifyStatus) {
        return;
    }


    // VERIFIED
    if (data.verified === true) {

        verifyStatus.innerHTML =
            "✅ Verified";

        verifyStatus.style.background =
            "#16a34a";

        verifyStatus.style.color =
            "#ffffff";

        if (premiumCard) {
            premiumCard.style.display =
                "none";
        }

        return;
    }

    const status = String(
        data.verificationStatus || ""
    ).toLowerCase().trim();

    const requested =
        data.verificationRequested === true ||
        data.verificationRequested === "true";

    // PENDING
    if (status === "pending" || requested) {

        verifyStatus.innerHTML =
            "⏳ Pending";

        verifyStatus.style.background =
            "#ff9800";

        verifyStatus.style.color =
            "#ffffff";

        return;
    }

    // NOT VERIFIED
    verifyStatus.innerHTML =
        "❌ Not Verified";

    verifyStatus.style.background =
        "#dc2626";

    verifyStatus.style.color =
        "#ffffff";
}


// =======================================
// BASIC PROFILE UI
// =======================================

function updateBasicProfileUI(
data
) {

const displayUsername =  
    data.username ||  
    data.name ||  
    "User";  


const displayName =  
    data.name ||  
    data.username ||  
    "User";  


if (userNameText) {  

    userNameText.innerText =  
        displayUsername;  

}  


if (nameText) {  

    nameText.innerText =  
        displayName;  

}  


// ---------------------------------  
// NETEARN ID  
// ---------------------------------  

const customNetEarnId =  
    getNetEarnId(data);  


if (netEarnId) {  

    netEarnId.innerText =  
        customNetEarnId ||  
        "N/A";  

}  


// ---------------------------------  
// REFERRAL CODE  
// ---------------------------------  

if (referralCode) {  

    referralCode.innerText =  
        data.referralCode ||  
        "N/A";  

}

}

// =======================================
// LOAD FORM DATA
// =======================================

function loadFormData(
data
) {

if (fullName) {  

    fullName.value =  
        data.name || "";  

}  


if (username) {  

    username.value =  
        data.username || "";  

}  


if (phone) {  

    phone.value =  
        data.phone || "";  

}  


if (email) {  

    email.value =  
        data.email ||  
        currentAuthUser?.email ||  
        "";  

}  


if (address) {  

    address.value =  
        data.address || "";  

}

}

// =======================================
// LIVE USER LISTENER
// =======================================

function startLiveUserListener(
user,
initialWithdrawnAmount = null
) {

if (unsubscribeUser) {  

    unsubscribeUser();  

}  


const userRef =  
    doc(  
        db,  
        "users",  
        user.uid  
    );  


let useInitialWithdrawnAmount =
    initialWithdrawnAmount !== null &&
    initialWithdrawnAmount !== undefined;

unsubscribeUser =  
    onSnapshot(  

        userRef,  

        async snapshot => {  

            if (!snapshot.exists()) {  
                return;  
            }  


            const data =  
                snapshot.data();  


            currentUserData =  
                data;  


            currentUserId =  
                getNetEarnId(data);  


            updateVerificationUI(  
                data  
            );  


            updateBasicProfileUI(  
                data  
            );  


            const withdrawnAmount =
                useInitialWithdrawnAmount
                    ? initialWithdrawnAmount
                    : await getWithdrawTotal(
                        user.uid,
                        data.userId || ""
                    );

            useInitialWithdrawnAmount = false;  


            updateProfileWalletUI(  
                data,  
                withdrawnAmount  
            );  

        },  

        error => {  

            console.error(  
                "❌ Profile snapshot error:",  
                error  
            );  

        }  

    );

}

// =======================================
// PHOTO UPLOAD
// USER-SPECIFIC ONLY
// =======================================

if (photoUpload) {

photoUpload.addEventListener(  
    "change",  
    event => {  

        const file =  
            event.target.files?.[0];  


        if (!file) {  
            return;  
        }  


        // ---------------------------------  
        // IMAGE CHECK  
        // ---------------------------------  

        if (  
            !file.type.startsWith("image/")  
        ) {  

            alert(  
                "Please select an image."  
            );  

            photoUpload.value = "";  

            return;  

        }  


        // ---------------------------------  
        // SIZE CHECK  
        // ---------------------------------  

        if (  
            file.size >  
            5 * 1024 * 1024  
        ) {  

            alert(  
                "Photo must be smaller than 5MB."  
            );  

            photoUpload.value = "";  

            return;  

        }  


        // ---------------------------------  
        // FIREBASE AUTH USER  
        // IMPORTANT:  
        // Use Firebase UID for photo key  
        // ---------------------------------  

        const uid =  
            auth.currentUser?.uid;  


        if (!uid) {  

            alert(  
                "Login Required. Please login again."  
            );  

            photoUpload.value = "";  

            return;  

        }  


        // ---------------------------------  
        // READ IMAGE  
        // ---------------------------------  

        const reader =  
            new FileReader();  


        reader.onload =  
            event => {  

                const image =  
                    event.target.result;  


                // ---------------------------------  
                // SHOW NEW PHOTO IMMEDIATELY  
                // ---------------------------------  

                if (profilePreview) {  

                    profilePreview.src =  
                        image;

                }  


                // ---------------------------------  
                // SAVE USER-SPECIFIC PHOTO  
                // ---------------------------------  

                localStorage.setItem(  
                    `profilePhoto_${uid}`,  
                    image  
                );  


                // ---------------------------------  
                // SUCCESS  
                // ---------------------------------  

                showToast(  
                    "📸 Profile photo updated successfully"  
                );  

            };  


        reader.onerror =  
            () => {  

                alert(  
                    "Unable to read the selected photo."  
                );  

            };  


        reader.readAsDataURL(file);  

    }  
);

}

// =======================================
// SAVE PROFILE
// Username + Phone + Email
// =======================================

if (saveBtn) {

saveBtn.addEventListener(  
    "click",  
    async () => {  

        const user =  
            auth.currentUser;  


        if (!user) {  

            alert(  
                "Login Required"  
            );  

            return;  

        }  


        const nameValue =  
            fullName?.value  
                ?.trim() || "";  


        const usernameValue =  
            username?.value  
                ?.trim() || "";  


        const phoneValue =  
            phone?.value  
                ?.trim() || "";  


        const emailValue =  
            email?.value  
                ?.trim()  
                ?.toLowerCase() || "";  


        // =================================  
        // VALIDATION  
        // =================================  

        if (!usernameValue) {  

            alert(  
                "Please enter your username."  
            );  

            return;  

        }  


        if (emailValue) {  

            const emailPattern =  
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;  


            if (  
                !emailPattern.test(  
                    emailValue  
                )  
            ) {  

                alert(  
                    "Please enter a valid email address."  
                );  

                return;  

            }  

        }  


        const currentAuthEmail =  
            String(  
                user.email || ""  
            ).trim().toLowerCase();  


        const emailChanged =  
            emailValue &&  
            emailValue !==  
            currentAuthEmail;  


        try {  

            saveBtn.disabled =  
                true;  

            saveBtn.innerText =  
                "Saving...";  


            // =================================  
            // EMAIL CHANGE  
            //  
            // Current password  
            // → New email  
            // → Confirm email  
            // → Re-authenticate  
            // → Firebase Auth update  
            // → Firestore sync  
            // =================================  

            if (emailChanged) {  

                if (!user.email) {  

                    throw new Error(  
                        "EMAIL_PASSWORD_AUTH_REQUIRED"  
                    );  

                }  


                const currentPassword =  
                    await NetEarnDialog.prompt(  
                        "Current Password"  
                    );  


                if (!currentPassword) {  

                    return;  

                }  


                const confirmEmail =  
                    await NetEarnDialog.prompt(  
                        "Confirm your new email address:"  
                    );  


                if (!confirmEmail) {  

                    return;  

                }  


                const normalizedConfirmEmail =  
                    confirmEmail  
                        .trim()  
                        .toLowerCase();  


                if (  
                    normalizedConfirmEmail !==  
                    emailValue  
                ) {  

                    alert(  
                        "❌ New email and confirmation email do not match."  
                    );  

                    return;  

                }

// ---------------------------------
// Re-authenticate
// ---------------------------------

const credential =  
                    EmailAuthProvider.credential(  
                        user.email,  
                        currentPassword  
                    );  


                await reauthenticateWithCredential(  
                    user,  
                    credential  
                );  


                // ---------------------------------  
                // Update Firebase Authentication  
                // ---------------------------------  

                await updateEmail(  
                    user,  
                    emailValue  
                );  


                // ---------------------------------  
                // Sync Firestore email  
                // ---------------------------------  

                await setDoc(  

                    doc(  
                        db,  
                        "users",  
                        user.uid  
                    ),  

                    {  
                        username:  
                            usernameValue,  

                        email:  
                            emailValue,  

                        phone:  
                            phoneValue  
                    },  

                    {  
                        merge: true  
                    }  

                );  


                // Refresh local Auth reference  

                currentAuthUser =  
                    auth.currentUser;  


                if (email) {  

                    email.value =  
                        emailValue;  

                }  


                showToast(  
                    "📧 Email changed successfully"  
                );  


                alert(  
                    "✅ Email changed successfully.\n\n" +  
                    "You can now log in with your new email on another device."  
                );  

            }  

            else {  

                // =================================  
                // NORMAL PROFILE UPDATE  
                //  
                // Current Rules allow:  
                // username, email, phone  
                // =================================  

                await setDoc(  

                    doc(  
                        db,  
                        "users",  
                        user.uid  
                    ),  

                    {  

                        username:  
                            usernameValue,  

                        email:  
                            emailValue,  

                        phone:  
                            phoneValue  

                    },  

                    {  
                        merge: true  
                    }  

                );  


                if (userName) {  

                    userName.innerText =  
                        usernameValue;  

                }  


                if (nameText) {  

                    nameText.innerText =  
                        nameValue ||  
                        usernameValue;  

                }  


                showToast(  
                    "✅ Profile Saved Successfully"  
                );  

            }  

        }  

        catch (error) {  

            console.error(  
                "❌ Profile Save Error:",  
                error  
            );  


            // ---------------------------------  
            // Email/password authentication  
            // ---------------------------------  

            if (  
                error?.message ===  
                "EMAIL_PASSWORD_AUTH_REQUIRED"  
            ) {  

                alert(  
                    "❌ This account does not use Email/Password authentication."  
                );  

                return;  

            }  


            // ---------------------------------  
            // Wrong password  
            // ---------------------------------  

            if (  
                error?.code ===  
                "auth/wrong-password" ||  

                error?.code ===  
                "auth/invalid-credential"  
            ) {  

                alert(  
                    "❌ Current password is incorrect."  
                );  

                return;  

            }  


            // ---------------------------------  
            // Recent login  
            // ---------------------------------  

            if (  
                error?.code ===  
                "auth/requires-recent-login"  
            ) {  

                alert(  
                    "🔐 Please log in again and then try changing your email."  
                );  

                return;  

            }  


            // ---------------------------------  
            // Too many requests  
            // ---------------------------------  

            if (  
                error?.code ===  
                "auth/too-many-requests"  
            ) {  

                alert(  
                    "⚠️ Too many attempts. Please try again later."  
                );  

                return;  

            }  


            // ---------------------------------  
            // Invalid email  
            // ---------------------------------  

            if (  
                error?.code ===  
                "auth/invalid-email"  
            ) {  

                alert(  
                    "❌ Please enter a valid email address."  
                );  

                return;  

            }  


            // ---------------------------------  
            // Email already in use  
            // ---------------------------------  

            if (  
                error?.code ===  
                "auth/email-already-in-use"  
            ) {  

                alert(  
                    "❌ This email is already being used by another account."  
                );  

                return;  

            }  


            // ---------------------------------  
            // Operation not allowed  
            // ---------------------------------  

            if (  
                error?.code ===  
                "auth/operation-not-allowed"  
            ) {  

                alert(  
                    "❌ Email/password authentication is not enabled in Firebase."  
                );  

                return;  

            }  


            // ---------------------------------  
            // Generic error  
            // ---------------------------------  

            alert(  
                "❌ Profile update failed.\n\n" +  
                (  
                    error?.message ||  
                    "Unknown error"  
                )  
            );  

        }  

        finally {  

            saveBtn.disabled =  
                false;  

            saveBtn.innerText =  
                "💾 Save Profile";  

        }  

    }  
);

}

// =======================================
// SECURE CHANGE PASSWORD
// =======================================

if (changePasswordBtn) {

changePasswordBtn.addEventListener(  
    "click",  
    async () => {  

        const user =  
            auth.currentUser;  


        if (!user) {  

            alert(  
                "Login Required"  
            );  

            return;  

        }  


        if (!user.email) {  

            alert(  
                "Password change is unavailable for this account."  
            );  

            return;  

        }  


        const currentPassword =  
            await NetEarnDialog.prompt(  
                "Current Password"  
            );  


        if (!currentPassword) {  
            return;  
        }  


        const newPassword =  
            await NetEarnDialog.prompt(  
                "Enter your new password:"  
            );  


        if (!newPassword) {  
            return;  
        }  


        const confirmPassword =  
            await NetEarnDialog.prompt(  
                "Confirm your new password:"  
            );  


        if (!confirmPassword) {  
            return;  
        }  


        if (  
            newPassword.length < 6  
        ) {  

            alert(  
                "❌ New password must be at least 6 characters."  
            );  

            return;  

        }  


        if (  
            newPassword !==  
            confirmPassword  
        ) {  

            alert(  
                "❌ New password and confirm password do not match."  
            );  

            return;  

        }  


        if (  
            currentPassword ===  
            newPassword  
        ) {  

            alert(  
                "❌ New password must be different from your current password."  
            );  

            return;  

        }  


        try {  

            changePasswordBtn.disabled =  
                true;  

            changePasswordBtn.innerText =  
                "Changing Password...";  


            const credential =  
                EmailAuthProvider.credential(  
                    user.email,  
                    currentPassword  
                );  


            await reauthenticateWithCredential(  
                user,  
                credential  
            );  


            await updatePassword(  
                user,  
                newPassword  
            );  


            showToast(  
                "🔐 Password changed successfully"  
            );  


            alert(  
                "✅ Your password has been changed successfully."  
            );  

        }  

        catch (error) {  

            console.error(  
                "❌ Change Password Error:",  
                error  
            );  


            if (  
                error?.code ===  
                "auth/wrong-password" ||  

                error?.code ===  
                "auth/invalid-credential"  
            ) {  

                alert(  
                    "❌ Current password is incorrect."  
                );  

                return;  

            }  


            if (  
                error?.code ===  
                "auth/too-many-requests"  
            ) {  

                alert(  
                    "⚠️ Too many attempts. Please try again later."  
                );  

                return;  

            }  


            if (  
                error?.code ===  
                "auth/weak-password"  
            ) {  

                alert(  
                    "❌ Password is too weak. Please use a stronger password."  
                );  

                return;  

            }  


            if (  
                error?.code ===  
                "auth/requires-recent-login"  
            ) {  

                alert(  
                    "🔐 Please log in again and then try changing your password."  
                );  

                return;  

            }  


            alert(  
                "❌ Password change failed.\n\n" +  
                (  
                    error?.message ||  
                    "Unknown error"  
                )  
            );  

        }  

        finally {  

            changePasswordBtn.disabled =  
                false;  

            changePasswordBtn.innerText =  
                "🔑 Change Password";  

        }  

    }  
);

}

// =====================================
// LOGOUT
// =====================================

if (logoutBtn) {

logoutBtn.addEventListener(  
    "click",  
    async () => {  

        // ---------------------------------  
        // LOGOUT CONFIRMATION  
        // ---------------------------------  

        const ok = await NetEarnDialog.confirm(  
            "আপনি কি সত্যিই Logout করতে চান?"  
        );  


        // Cancel করলে কিছুই হবে না  
        if (!ok) {  
            return;  
        }  


        try {  

            // Live Firestore listener বন্ধ  
            if (unsubscribeUser) {  

                unsubscribeUser();  

                unsubscribeUser = null;  

            }  


            // Firebase logout  
            await signOut(auth);  


            // Login page-এ পাঠানো  
            window.location.href =  
                "login.html";  

        }  

        catch (error) {  

            console.error(  
                "❌ Logout Error:",  
                error  
            );  


            alert(  
                "Logout failed. Please try again."  
            );  

        }  

    }  
);

}

// =======================================
// TOAST
// =======================================

function showToast(
message
) {

const oldToast =  
    document.getElementById(  
        "netearnProfileToast"  
    );  


if (oldToast) {  

    oldToast.remove();  

}  


const box =  
    document.createElement(  
        "div"  
    );  


box.id =  
    "netearnProfileToast";  


box.innerText =  
    message;  


box.style.position =  
    "fixed";  

box.style.bottom =  
    "100px";  

box.style.left =  
    "50%";  

box.style.transform =  
    "translateX(-50%)";  

box.style.background =  
    "#1565ff";  

box.style.color =  
    "#fff";  

box.style.padding =  
    "13px 22px";  

box.style.borderRadius =  
    "30px";  

box.style.zIndex =  
    "99999";  

box.style.fontWeight =  
    "600";  

box.style.boxShadow =  
    "0 8px 25px rgba(0,0,0,.2)";  

box.style.maxWidth =  
    "90%";  

box.style.textAlign =  
    "center";  


document.body.appendChild(  
    box  
);  


setTimeout(  
    () => {  

        if (box) {  
            box.remove();  
        }  

    },  
    2500  
);

}

// =======================================
// AUTH STATE
// =======================================

onAuthStateChanged(
auth,
async user => {

// ---------------------------------  
    // NOT LOGGED IN  
    // ---------------------------------  

    if (!user) {  

        // শুধু profile.html থেকে বের করবে  
        // অন্য page-এ অপ্রয়োজনীয় redirect করবে না  

        if (  
            window.location.pathname  
                .toLowerCase()  
                .endsWith("profile.html")  
        ) {  

            window.location.replace(  
                "index.html"  
            );  

        }  

        return;  
    }  


    // ---------------------------------  
    // CURRENT AUTH USER  
    // ---------------------------------  

    currentAuthUser =
    user;


// =======================================
// ⚡ SHOW CACHED PROFILE IMMEDIATELY
// =======================================

loadCachedProfile();


// =======================================
// 🔄 FIREBASE BACKGROUND SYNC
// =======================================

try {

    const withdrawnAmount =
        await loadUserProfile(
            user
        );

        // ---------------------------------  
        // START REAL-TIME LISTENER  
        // ---------------------------------  

        startLiveUserListener(  
            user,
            withdrawnAmount
        );  

    }  

    catch (error) {  

        console.error(  
            "❌ Profile Load Error:",  
            error  
        );  

    }  

}

);

// =======================================
// START
// =======================================

console.log(
"🚀 NetEarn Pro Secure Profile System Loaded"
);