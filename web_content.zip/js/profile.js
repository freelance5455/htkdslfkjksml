/* =========================================================
   MESH — PROFILE MODULE
   FILE: MESH/js/profile.js

   PURPOSE:
   - Manage student profile UI
   - Display user information
   - Display university / faculty / department / level
   - Handle interests
   - Profile menu actions
   - Logout trigger
   - Prepare profile for Firebase
   ========================================================= */

(function () {

  "use strict";


  /* =========================================================
     1. PROFILE STATE
     ========================================================= */

  var state = {

    profile: {

      name: "MESH Student",

      email: "",

      photoURL: "",

      university: "",

      faculty: "",

      department: "",

      level: "",

      interests: []

    },

    isEditing: false

  };


  /* =========================================================
     2. DEMO PROFILE
     
     Temporary fallback until Firebase provides
     the authenticated user's real profile.
     ========================================================= */

  var demoProfile = {

    name: "MESH Student",

    email: "",

    photoURL: "",

    university: "University",

    faculty: "Faculty",

    department: "Department",

    level: "100 Level",

    interests: [

      "Technology",

      "Entrepreneurship"

    ]

  };


  /* =========================================================
     3. HELPERS
     ========================================================= */

  function escapeHTML(value) {

    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  }


  function getInitials(name) {

    var words =
      String(name || "MESH")
        .trim()
        .split(/\s+/)
        .filter(Boolean);


    if (!words.length) {
      return "M";
    }


    if (words.length === 1) {

      return words[0]
        .substring(0, 2)
        .toUpperCase();

    }


    return (
      words[0].charAt(0) +
      words[words.length - 1].charAt(0)
    ).toUpperCase();

  }


  /* =========================================================
     4. LOAD DEMO PROFILE
     ========================================================= */

  function loadDemoProfile() {

    state.profile =
      Object.assign(
        {},
        demoProfile,
        {
          interests:
            demoProfile.interests.slice()
        }
      );

  }


  /* =========================================================
     5. GET FIREBASE PROFILE
     
     Firebase module will provide the real data when
     authentication is connected.
     ========================================================= */

  function promptForUsername(profile) {
    if (!profile || profile.username && String(profile.username).trim() && String(profile.username).toLowerCase() !== "mesh students") return;
    if (document.querySelector("[data-mesh-username-prompt]")) return;
    var overlay = document.createElement("div");
    overlay.setAttribute("data-mesh-username-prompt", "");
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.style.cssText = "position:fixed;inset:0;z-index:10000;background:rgba(5,15,40,.7);display:flex;align-items:center;justify-content:center;padding:18px";
    var card = document.createElement("form");
    card.style.cssText = "width:min(100%,420px);background:var(--card-bg,#fff);color:var(--text-color,#14213d);border-radius:16px;padding:22px";
    var title = document.createElement("h2"); title.textContent = "Choose your MESH username";
    var copy = document.createElement("p"); copy.textContent = "Your username helps other students recognise you. Use 3–24 letters, numbers or underscores.";
    var input = document.createElement("input"); input.type = "text"; input.autocomplete = "username"; input.required = true; input.minLength = 3; input.maxLength = 24; input.pattern = "[A-Za-z0-9_]{3,24}"; input.placeholder = "e.g. kammy_07"; input.setAttribute("aria-label","Username"); input.style.cssText = "width:100%;box-sizing:border-box;padding:12px;margin:10px 0";
    var error = document.createElement("p"); error.setAttribute("aria-live","polite"); error.style.color = "#b42318";
    var submit = document.createElement("button"); submit.type = "submit"; submit.textContent = "Save username"; submit.style.cssText = "padding:12px 16px";
    card.append(title,copy,input,error,submit); overlay.appendChild(card); document.body.appendChild(overlay);
    card.addEventListener("submit", async function(ev) {
      ev.preventDefault(); error.textContent = ""; submit.disabled = true;
      try {
        var api = window.MESH_FIREBASE;
        if (!api || typeof api.updateUserProfile !== "function") throw new Error("Please refresh and try again.");
        await api.updateUserProfile({username:input.value.trim().toLowerCase().replace(/^@/,"")});
        overlay.remove();
        if (typeof api.getUserProfile === "function") state.profile = Object.assign({},state.profile,await api.getUserProfile(api.getCurrentUser() && api.getCurrentUser().uid));
        renderProfile(); showToast("Username saved");
      } catch (e) { error.textContent = e && e.message ? e.message : "Could not save username."; submit.disabled = false; }
    });
  }

  function loadFirebaseProfile() {

    if (
      !window.MESH_FIREBASE
    ) {

      return;

    }


    if (
      typeof window.MESH_FIREBASE.getUserProfile !==
      "function"
    ) {

      return;

    }


    window.MESH_FIREBASE
      .getUserProfile(
        window.MESH_FIREBASE.getCurrentUser() &&
        window.MESH_FIREBASE.getCurrentUser().uid
      )
      .then(function (profile) {

        if (!profile) {
          return;
        }


        state.profile =
          Object.assign(
            {},
            state.profile,
            profile
          );

        renderProfile();
        promptForUsername(profile);

      })
      .catch(function () {

        /*
          Keep demo profile as fallback.
        */

      });

  }


  /* =========================================================
     6. RENDER PROFILE
     ========================================================= */

  function renderProfile() {

    var profile =
      state.profile;


    /* -------------------------------------------------------
       Name
       ------------------------------------------------------- */

    setText(
      "[data-profile-name]",
      profile.fullName || profile.name ||
      "MESH Student"
    );


    /* -------------------------------------------------------
       Email
       ------------------------------------------------------- */

    setText(
      "[data-profile-email]",
      profile.email || ""
    );


    /* -------------------------------------------------------
       University
       ------------------------------------------------------- */

    setText(
      "[data-profile-university]",
      profile.university ||
      "University"
    );


    /* -------------------------------------------------------
       Faculty
       ------------------------------------------------------- */

    setText(
      "[data-profile-faculty]",
      profile.faculty ||
      "Faculty"
    );


    /* -------------------------------------------------------
       Department
       ------------------------------------------------------- */

    setText(
      "[data-profile-department]",
      profile.department ||
      "Department"
    );


    /* -------------------------------------------------------
       Level
       ------------------------------------------------------- */

    setText(
      "[data-profile-level]",
      profile.level ||
      "Level"
    );

    setText(
      "[data-profile-summary]",
      [profile.department, profile.level].filter(Boolean).join(" · ") || "Complete your academic profile"
    );


    /* -------------------------------------------------------
       Interests
       ------------------------------------------------------- */

    renderInterests();


    /* -------------------------------------------------------
       Avatar
       ------------------------------------------------------- */

    renderAvatar();

  }


  /* =========================================================
     7. SET TEXT HELPER
     ========================================================= */

  function setText(
    selector,
    value
  ) {

    var elements =
      document.querySelectorAll(
        selector
      );


    elements.forEach(function (element) {

      element.textContent =
        value || "";

    });

  }


  /* =========================================================
     8. RENDER AVATAR
     ========================================================= */

  function renderAvatar() {
    var avatars = document.querySelectorAll("[data-profile-avatar]");
    var profile = state.profile || {};
    var identity = String(profile.uid || profile.email || profile.name || "mesh-student");
    var hash = 0;
    for (var i = 0; i < identity.length; i++) hash = ((hash << 5) - hash + identity.charCodeAt(i)) | 0;
    var palette = ["#DDF7EA", "#E1ECFF", "#FCE7D7", "#F0E4FF", "#FFF0C2", "#D9F3F4", "#FFE0EA", "#E8EBCB"];
    var ink = ["#08784F", "#2859A8", "#9A4C13", "#7042A2", "#89600A", "#16717A", "#A13D65", "#56611A"];
    var idx = Math.abs(hash) % palette.length;
    var initials = getInitials(profile.fullName || profile.name || "MESH Student");
    var avatarChoice = profile.avatarStyle || "initials";
    var avatarGlyphs = {star:"⭐",bolt:"⚡",leaf:"🌿",moon:"🌙",sun:"☀️",wave:"🌊"};
    avatars.forEach(function (avatar) {
      avatar.textContent = avatarGlyphs[avatarChoice] || initials;
      avatar.classList.toggle("mesh-avatar-emoji", !!avatarGlyphs[avatarChoice]);
      avatar.style.backgroundColor = palette[idx];
      avatar.style.color = ink[idx];
      avatar.classList.remove("has-image");
      avatar.setAttribute("aria-label", (avatarGlyphs[avatarChoice] ? "Selected avatar style: " + avatarChoice : "Initials avatar") + " for " + (profile.fullName || profile.name || "MESH Student"));
    });
    var choice = document.getElementById("mesh-avatar-choice");
    if (choice && choice.value !== avatarChoice) choice.value = avatarChoice;
  }

  document.addEventListener("DOMContentLoaded", function () {
    var choice = document.getElementById("mesh-avatar-choice");
    if (!choice) return;
    choice.addEventListener("change", function () {
      var value = choice.value || "initials";
      saveProfile({avatarStyle:value});
    });
  });


  /* =========================================================
     9. RENDER INTERESTS
     ========================================================= */

  function renderInterests() {

    var containers =
      document.querySelectorAll(
        "[data-profile-interests]"
      );


    containers.forEach(function (container) {

      container.innerHTML = "";


      var interests =
        state.profile.interests || [];


      if (!interests.length) {

        container.innerHTML = `

          <span class="profile-interest-empty">
            No interests selected
          </span>

        `;

        return;

      }


      interests.forEach(
        function (interest) {

          var chip =
            document.createElement(
              "span"
            );


          chip.className =
            "profile-interest-chip";


          chip.textContent =
            interest;


          container.appendChild(
            chip
          );

        }
      );

    });

  }


  /* =========================================================
     10. UPDATE PROFILE DATA
     ========================================================= */

  function updateProfile(
    updates
  ) {

    if (!updates) {
      return;
    }


    state.profile =
      Object.assign(
        {},
        state.profile,
        updates
      );


    renderProfile();


    document.dispatchEvent(
      new CustomEvent(
        "mesh:profile-updated",
        {
          detail: {
            profile:
              state.profile
          }
        }
      )
    );

  }


  /* =========================================================
     11. SAVE PROFILE
     
     Firebase saving is handled by firebase.js.
     ========================================================= */

  function saveProfile(updates) {
    updates = Object.assign({}, updates || {});
    // University is set during onboarding and must not be editable here.
    delete updates.universityId;
    delete updates.university;
    var firebaseApi = window.MESH_FIREBASE;
    if (firebaseApi && typeof firebaseApi.updateUserProfile === "function") {
      return firebaseApi.updateUserProfile(updates).then(function(saved) {
        state.profile = Object.assign({}, state.profile, saved || {}, updates);
        renderProfile();
        document.dispatchEvent(new CustomEvent("mesh:profile-updated", {detail:{profile:state.profile}}));
        showToast("Profile updated");
        return state.profile;
      }).catch(function(error) {
        showToast("Profile could not be saved");
        throw error;
      });
    }
    updateProfile(updates);
    showToast("Profile updated");
    return Promise.resolve(state.profile);
  }

  /* =========================================================
     12. PROFILE EDIT FORM
     ========================================================= */

  function setupEditForm() {

    var form =
      document.querySelector(
        "[data-profile-form]"
      );


    if (!form) {
      return;
    }


    form.addEventListener(
      "submit",
      function (event) {

        event.preventDefault();


        var formData =
          new FormData(
            form
          );


        var updates = {};


        formData.forEach(
          function (
            value,
            key
          ) {

            updates[key] =
              value;

          }
        );


        delete updates.universityId;
        delete updates.university;
        saveProfile(updates).catch(function(error) {
          console.error("MESH profile save failed", error);
        });

      }
    );

  }


  /* =========================================================
     13. EDIT MODE
     ========================================================= */

  function setupEditButton() {

    var buttons =
      document.querySelectorAll(
        "[data-action='edit-profile']"
      );


    buttons.forEach(function (button) {

      button.addEventListener(
        "click",
        function () {

          state.isEditing =
            !state.isEditing;


          document.dispatchEvent(
            new CustomEvent(
              "mesh:profile-edit",
              {
                detail: {
                  editing:
                    state.isEditing
                }
              }
            )
          );


          document.body.classList.toggle(
            "profile-editing",
            state.isEditing
          );

        }
      );

    });

  }


  /* =========================================================
     14. LOGOUT
     ========================================================= */

  function setupLogout() {

    var buttons =
      document.querySelectorAll(
        "[data-action='logout']"
      );


    buttons.forEach(function (button) {

      button.addEventListener(
        "click",
        function () {

          if (
            window.MESH_AUTH &&
            typeof window.MESH_AUTH.logout ===
            "function"
          ) {

            window.MESH_AUTH.logout();

            return;

          }


          document.dispatchEvent(
            new CustomEvent(
              "mesh:logout"
            )
          );

        }
      );

    });

  }


  /* =========================================================
     15. PROFILE MENU ACTIONS
     ========================================================= */

  function setupProfileMenu() {

    var items =
      document.querySelectorAll(
        "[data-profile-action]"
      );


    items.forEach(function (item) {

      item.addEventListener(
        "click",
        function () {

          var action =
            item.getAttribute(
              "data-profile-action"
            );


          if (!action) {
            return;
          }


          document.dispatchEvent(
            new CustomEvent(
              "mesh:profile-action",
              {
                detail: {
                  action:
                    action
                }
              }
            )
          );

        }
      );

    });

  }


  /* =========================================================
     16. USER PROFILE EVENT
     
     Allows Firebase/auth modules to inject the
     authenticated user's profile.
     ========================================================= */

  function setupProfileEvents() {

    document.addEventListener(
      "mesh:user-profile",
      function (event) {

        if (
          !event.detail ||
          !event.detail.profile
        ) {

          return;

        }


        state.profile =
          Object.assign(
            {},
            state.profile,
            event.detail.profile
          );


        renderProfile();

      }
    );


    document.addEventListener(
      "mesh:auth-success",
      function () {
        loadFirebaseProfile();
      }
    );

    document.addEventListener(
      "mesh:auth-state",
      function (event) {
        if (event.detail && event.detail.user) {
          loadFirebaseProfile();
        }
      }
    );

  }


  /* =========================================================
     17. TOAST
     ========================================================= */

  function showToast(
    message
  ) {

    if (
      window.MESH_APP &&
      typeof window.MESH_APP.toast ===
      "function"
    ) {

      window.MESH_APP.toast(
        message
      );

      return;

    }


    var existing =
      document.querySelector(
        ".mesh-toast"
      );


    if (existing) {

      existing.remove();

    }


    var toast =
      document.createElement(
        "div"
      );


    toast.className =
      "mesh-toast";


    toast.textContent =
      message;


    document.body.appendChild(
      toast
    );


    setTimeout(
      function () {

        toast.classList.add(
          "show"
        );

      },
      10
    );


    setTimeout(
      function () {

        toast.classList.remove(
          "show"
        );


        setTimeout(
          function () {

            toast.remove();

          },
          250
        );

      },
      2500
    );

  }


  /* =========================================================
     18. GET PROFILE
     ========================================================= */

  function getProfile() {

    return Object.assign(
      {},
      state.profile
    );

  }


  /* =========================================================
     19. GET STATE
     ========================================================= */

  function getState() {

    return {

      profile:
        getProfile(),

      isEditing:
        state.isEditing

    };

  }


  /* =========================================================
     20. RESET PROFILE
     ========================================================= */

  function reset() {

    loadDemoProfile();

    state.isEditing =
      false;

    renderProfile();

  }


  /* =========================================================
     21. INITIALIZATION
     ========================================================= */

  function initProfile() {

    loadDemoProfile();

    setupEditForm();

    setupEditButton();

    setupLogout();

    setupProfileMenu();

    setupProfileEvents();

    renderProfile();

    loadFirebaseProfile();

  }


  /* =========================================================
     22. PUBLIC API
     ========================================================= */

  window.MESH_PROFILE = {

    getProfile:
      getProfile,

    getState:
      getState,

    update:
      updateProfile,

    save:
      saveProfile,

    reset:
      reset,

    refresh:
      renderProfile

  };


  /* =========================================================
     23. START
     ========================================================= */

  if (
    document.readyState ===
    "loading"
  ) {

    document.addEventListener(
      "DOMContentLoaded",
      initProfile
    );

  } else {

    initProfile();

  }


})();