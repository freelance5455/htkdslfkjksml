/**
 * BD BLOOD DONATION - Profile Management & Safety Reporting
 * Profile displays, photo upload, availability switch, edit profile view and safety tools.
 */

import { 
  db, 
  doc, 
  updateDoc, 
  setDoc,
  collection, 
  addDoc, 
  deleteDoc,
  storage, 
  storageRef, 
  uploadBytes, 
  getDownloadURL,
  serverTimestamp 
} from './firebase-config.js';
import { 
  getCurrentUser, 
  getCurrentUserProfile, 
  fetchUserProfile, 
  logoutUser, 
  toggleDonorAvailability 
} from './auth.js';
import { 
  getDistrictName, 
  getUpazilaName, 
  setupLocationDropdowns 
} from './location.js';
import { 
  toBengaliDigits, 
  escapeHtml, 
  isValidBdPhone, 
  showToast, 
  showModal, 
  getLanguage,
  setLanguage 
} from './utils.js';

export async function updateUserProfile({
  fullName,
  phone,
  bloodGroup,
  division,
  district,
  upazila,
  isAvailable
}) {
  const user = getCurrentUser();
  if (!user) throw new Error('লগইন করুন।');

  if (!fullName || fullName.trim().length < 2) {
    throw new Error('সঠিক নাম প্রদান করুন।');
  }
  if (!isValidBdPhone(phone)) {
    throw new Error('সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন।');
  }

  const userRef = doc(db, 'users', user.uid);
  const updates = {
    fullName: fullName.trim(),
    phone: phone.trim(),
    bloodGroup,
    division,
    district,
    upazila: upazila || '',
    isAvailable: Boolean(isAvailable),
    lastActive: serverTimestamp()
  };

  await updateDoc(userRef, updates);
  await fetchUserProfile(user.uid);
  showToast('প্রোফাইল সফলভাবে আপডেট করা হয়েছে।', 'success');
}

export async function uploadProfilePhoto(file) {
  const user = getCurrentUser();
  if (!user) throw new Error('লগইন করুন।');
  if (!file) throw new Error('ছবি নির্বাচন করুন।');

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const photoUrl = reader.result;
        const userRef = doc(db, 'users', user.uid);
        await updateDoc(userRef, { photoURL: photoUrl });
        await fetchUserProfile(user.uid);
        showToast('প্রোফাইল ছবি হালনাগাদ করা হয়েছে।', 'success');
        resolve(photoUrl);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export async function reportUserOrRequest({
  reportedUserId,
  reportedRequestId = null,
  reasonCategory,
  description
}) {
  const user = getCurrentUser();
  if (!user) throw new Error('লগইন করুন।');

  if (!reasonCategory) throw new Error('রিপোর্টের ধরন নির্বাচন করুন।');
  if (!description || description.trim().length < 5) {
    throw new Error('রিপোর্টের বিস্তারিত কারণ লিখুন (কমপক্ষে ৫ অক্ষর)।');
  }

  await addDoc(collection(db, 'reports'), {
    reporterId: user.uid,
    reportedUserId,
    reportedRequestId,
    reasonCategory,
    description: description.trim(),
    status: 'Pending Review',
    createdAt: serverTimestamp()
  });

  showToast('আপনার রিপোর্টটি নিরাপত্তা পর্যালোচনার জন্য জমা দেওয়া হয়েছে। ধন্যবাদ।', 'success');
}

export async function blockUser(targetUserId, targetUserName = '') {
  const user = getCurrentUser();
  if (!user) throw new Error('লগইন করুন।');

  const blockDocId = `${user.uid}_${targetUserId}`;
  await setDoc(doc(db, 'blocked_users', blockDocId), {
    blockerId: user.uid,
    blockedId: targetUserId,
    blockedName: targetUserName,
    createdAt: serverTimestamp()
  });

  showToast('ইউজারকে সফলভাবে ব্লক করা হয়েছে।', 'info');
}

/**
 * Render Profile Page View
 */
export async function renderProfilePage(container) {
  const user = getCurrentUser();
  const profile = getCurrentUserProfile();
  const isBn = getLanguage() === 'bn';

  if (!user) {
    container.innerHTML = `
      <div class="page-container animate-slide-in">
        <div class="empty-state card">
          <div class="empty-state-icon">👤</div>
          <div class="empty-state-title">${isBn ? 'লগইন প্রয়োজন' : 'Login Required'}</div>
          <div class="empty-state-desc">${isBn ? 'আপনার প্রোফাইল দেখতে ও পরিচালনা করতে লগইন করুন।' : 'Please login to manage your profile.'}</div>
          <a href="#/login" class="btn btn-primary btn-sm" style="margin-top: 10px;">${isBn ? 'লগইন করুন' : 'Login'}</a>
        </div>
      </div>
    `;
    return;
  }

  const distName = getDistrictName(profile?.division, profile?.district, isBn ? 'bn' : 'en');
  const upName = getUpazilaName(profile?.district, profile?.upazila, isBn ? 'bn' : 'en');
  const photoUrl = profile?.photoURL || user.photoURL || '';
  const fullName = profile?.fullName || user.displayName || 'সম্মানিত সদস্য';
  const bloodGroup = profile?.bloodGroup || 'A+';
  const isAvail = profile?.isAvailable !== false;

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>👤 ${isBn ? 'আমার প্রোফাইল' : 'My Profile'}</span>
        <a href="#/edit-profile" class="btn btn-secondary btn-sm">✏️ ${isBn ? 'এডিট' : 'Edit'}</a>
      </div>

      <!-- Main Profile Card -->
      <div class="card" style="text-align: center; padding: 24px 16px;">
        <div style="position: relative; width: 84px; height: 84px; margin: 0 auto 12px;">
          <div class="donor-avatar" style="width: 84px; height: 84px; font-size: 32px; ${photoUrl ? `background-image: url('${photoUrl}'); background-size: cover;` : ''}">
            ${!photoUrl ? (fullName.charAt(0) || 'U') : ''}
          </div>
          <label for="profile-photo-input" style="position: absolute; bottom: 0; right: 0; width: 28px; height: 28px; background: var(--primary-color); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; cursor: pointer; border: 2px solid #fff;" title="${isBn ? 'ছবি পরিবর্তন করুন' : 'Change photo'}">
            📷
          </label>
          <input type="file" id="profile-photo-input" accept="image/*" style="display: none;" />
        </div>

        <h2 style="font-size: 18px; font-weight: 800; color: var(--text-main); margin-bottom: 4px;">
          ${escapeHtml(fullName)}
        </h2>
        <div style="display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 12px;">
          <span class="badge badge-blood" style="font-size: 14px; padding: 4px 12px;">${bloodGroup}</span>
          <span class="badge ${isAvail ? 'badge-success' : 'badge-secondary'}">
            ${isAvail ? (isBn ? 'রক্তদানে প্রস্তুত' : 'Available') : (isBn ? 'অনুপলব্ধ' : 'Unavailable')}
          </span>
        </div>

        <p style="font-size: 12px; color: var(--text-muted);">
          📍 ${upName ? `${upName}, ` : ''}${distName || (isBn ? 'বাংলাদেশ' : 'Bangladesh')}
        </p>

        <!-- Stats Row -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 18px; padding-top: 14px; border-top: 1px solid var(--border-light);">
          <div>
            <div style="font-size: 20px; font-weight: 800; color: var(--primary-color);">
              ${toBengaliDigits(profile?.donationCount || 0)}
            </div>
            <div style="font-size: 11px; color: var(--text-muted);">${isBn ? 'বার রক্তদান' : 'Donations'}</div>
          </div>
          <div>
            <div style="font-size: 20px; font-weight: 800; color: #F59E0B;">
              ⭐ ${toBengaliDigits(profile?.averageRating || '5.0')}
            </div>
            <div style="font-size: 11px; color: var(--text-muted);">${isBn ? 'গড় রেটিং' : 'Rating'}</div>
          </div>
        </div>
      </div>

      <!-- Donor Availability Toggle Card -->
      <div class="card" style="display: flex; align-items: center; justify-content: space-between; padding: 14px 16px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span style="font-size: 22px;">🩸</span>
          <div>
            <div style="font-size: 14px; font-weight: 700; color: var(--text-main);">
              ${isBn ? 'রক্তদানের প্রস্তুতি স্ট্যাটাস' : 'Donor Availability'}
            </div>
            <div style="font-size: 11px; color: var(--text-muted);">
              ${isBn ? 'অন রাখলে জরুরি নোটিফিকেশন পাবেন' : 'Toggle to receive donation requests'}
            </div>
          </div>
        </div>
        <input type="checkbox" id="profile-availability-toggle" ${isAvail ? 'checked' : ''} style="width: 22px; height: 22px; cursor: pointer; accent-color: var(--primary-color);" />
      </div>

      <!-- Profile Details Card -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">📋 ${isBn ? 'ব্যক্তিগত তথ্য' : 'Personal Details'}</span>
        </div>

        <div style="display: flex; flex-direction: column; gap: 12px; font-size: 13px;">
          <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
            <span style="color: var(--text-muted);">${isBn ? 'মোবাইল নম্বর' : 'Phone'}:</span>
            <span style="font-weight: 600;">${escapeHtml(profile?.phone || (isBn ? 'যুক্ত করা হয়নি' : 'Not set'))}</span>
          </div>
          <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
            <span style="color: var(--text-muted);">${isBn ? 'ইমেইল' : 'Email'}:</span>
            <span style="font-weight: 600;">${escapeHtml(user.email || '')}</span>
          </div>
          <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
            <span style="color: var(--text-muted);">${isBn ? 'রক্তের গ্রুপ' : 'Blood Group'}:</span>
            <span style="font-weight: 700; color: var(--primary-color);">${bloodGroup}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span style="color: var(--text-muted);">${isBn ? 'জেলা / থানা' : 'Location'}:</span>
            <span style="font-weight: 600;">${distName || 'ঢাকা'}</span>
          </div>
        </div>
      </div>

      <!-- Quick Action Menu -->
      <div class="card" style="padding: 6px;">
        <a href="#/donation-history" class="btn btn-secondary btn-block" style="justify-content: flex-start; margin-bottom: 4px; border: none; background: transparent;">
          <span>🎖️</span> <span>${isBn ? 'রক্তদানের ইতিহাস ও সনদ' : 'Donation History & Badge'}</span>
        </a>
        <a href="#/my-requests" class="btn btn-secondary btn-block" style="justify-content: flex-start; margin-bottom: 4px; border: none; background: transparent;">
          <span>📋</span> <span>${isBn ? 'আমার রক্তের আবেদনসমূহ' : 'My Blood Requests'}</span>
        </a>
        <a href="#/about" class="btn btn-secondary btn-block" style="justify-content: flex-start; margin-bottom: 4px; border: none; background: transparent;">
          <span>ℹ️</span> <span>${isBn ? 'অ্যাপ সম্পর্কে ও ডেভেলপার তথ্য' : 'About & Developer'}</span>
        </a>
        <button id="profile-logout-btn" class="btn btn-secondary btn-block" style="justify-content: flex-start; color: var(--emergency-color); border: none; background: transparent;">
          <span>🚪</span> <span>${isBn ? 'লগআউট' : 'Logout'}</span>
        </button>
      </div>
    </div>
  `;

  // Photo upload listener
  const photoInput = document.getElementById('profile-photo-input');
  photoInput.addEventListener('change', async (e) => {
    if (e.target.files && e.target.files[0]) {
      await uploadProfilePhoto(e.target.files[0]);
      renderProfilePage(container);
    }
  });

  // Availability toggle
  const availToggle = document.getElementById('profile-availability-toggle');
  availToggle.addEventListener('change', async (e) => {
    await toggleDonorAvailability(e.target.checked);
  });

  // Logout button
  document.getElementById('profile-logout-btn').addEventListener('click', () => {
    showModal({
      title: isBn ? 'লগআউট নিশ্চিতকরণ' : 'Confirm Logout',
      body: isBn ? 'আপনি কি নিশ্চিতভাবে আপনার একাউন্ট থেকে লগআউট করতে চান?' : 'Are you sure you want to log out?',
      confirmText: isBn ? 'লগআউট' : 'Logout',
      cancelText: isBn ? 'বাতিল' : 'Cancel',
      isDanger: true,
      onConfirm: async () => {
        await logoutUser();
        window.location.hash = '#/home';
      }
    });
  });
}

/**
 * Render Edit Profile Page View
 */
export async function renderEditProfilePage(container) {
  const user = getCurrentUser();
  const profile = getCurrentUserProfile();
  const isBn = getLanguage() === 'bn';

  if (!user) {
    window.location.hash = '#/login';
    return;
  }

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>✏️ ${isBn ? 'প্রোফাইল সম্পাদন' : 'Edit Profile'}</span>
        <a href="#/profile" class="section-link">&larr; ${isBn ? 'ফিরে যান' : 'Back'}</a>
      </div>

      <div class="card">
        <form id="edit-profile-form">
          <div class="form-group">
            <label class="form-label">${isBn ? 'সম্পূর্ণ নাম' : 'Full Name'} <span class="required-star">*</span></label>
            <input type="text" id="edit-name" class="form-control" value="${escapeHtml(profile?.fullName || user.displayName || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label">${isBn ? 'মোবাইল নম্বর' : 'Phone Number'} <span class="required-star">*</span></label>
            <input type="tel" id="edit-phone" class="form-control" value="${escapeHtml(profile?.phone || '')}" placeholder="01XXXXXXXXX" required />
          </div>

          <!-- Blood Group -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'রক্তের গ্রুপ' : 'Blood Group'} <span class="required-star">*</span></label>
            <div class="blood-grid" id="edit-blood-grid">
              ${['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => `
                <div class="blood-radio-btn ${(profile?.bloodGroup || 'A+') === bg ? 'selected' : ''}" data-group="${bg}">${bg}</div>
              `).join('')}
            </div>
            <input type="hidden" id="edit-blood-group" value="${profile?.bloodGroup || 'A+'}" required />
          </div>

          <!-- Location Dropdowns -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
            <div class="form-group">
              <label class="form-label">${isBn ? 'বিভাগ' : 'Division'} <span class="required-star">*</span></label>
              <select id="edit-division" class="form-select" required></select>
            </div>
            <div class="form-group">
              <label class="form-label">${isBn ? 'জেলা' : 'District'} <span class="required-star">*</span></label>
              <select id="edit-district" class="form-select" required></select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">${isBn ? 'উপজেলা / এলাকা' : 'Upazila'}</label>
            <select id="edit-upazila" class="form-select"></select>
          </div>

          <button type="submit" id="edit-save-btn" class="btn btn-primary btn-block" style="margin-top: 10px;">
            💾 ${isBn ? 'তথ্য সংরক্ষণ করুন' : 'Save Changes'}
          </button>
        </form>
      </div>
    </div>
  `;

  // Setup location dropdowns
  setupLocationDropdowns({
    divisionSelectEl: document.getElementById('edit-division'),
    districtSelectEl: document.getElementById('edit-district'),
    upazilaSelectEl: document.getElementById('edit-upazila'),
    selectedDivision: profile?.division || 'dhaka',
    selectedDistrict: profile?.district || 'dhaka',
    selectedUpazila: profile?.upazila || '',
    lang: isBn ? 'bn' : 'en'
  });

  // Handle blood chips
  const bloodButtons = container.querySelectorAll('#edit-blood-grid .blood-radio-btn');
  const bloodHiddenInput = document.getElementById('edit-blood-group');
  bloodButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      bloodButtons.forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      bloodHiddenInput.value = btn.dataset.group;
    });
  });

  // Form submit
  document.getElementById('edit-profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const saveBtn = document.getElementById('edit-save-btn');
    saveBtn.disabled = true;

    try {
      await updateUserProfile({
        fullName: document.getElementById('edit-name').value,
        phone: document.getElementById('edit-phone').value,
        bloodGroup: bloodHiddenInput.value,
        division: document.getElementById('edit-division').value,
        district: document.getElementById('edit-district').value,
        upazila: document.getElementById('edit-upazila').value,
        isAvailable: profile?.isAvailable !== false
      });

      window.location.hash = '#/profile';
    } catch (err) {
      showToast(err.message, 'error');
      saveBtn.disabled = false;
    }
  });
}
