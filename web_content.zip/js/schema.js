/* OPERATION: DISCIPLINE — esquema, validação estrita e migração (v1/v2 → v3). Sem DOM. */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U,G=OD.G,R=OD.Rules,E=U.E,isO=U.isO,isInt=U.isInt,isTs=U.isTs,str=U.str;
var VERSION=3;
function validate(n){
if(!isO(n))E('Estrutura inválida');
if(!Array.isArray(n.m)||!Array.isArray(n.l)||!Array.isArray(n.c))E('Estrutura inválida: listas ausentes');
if(!isO(n.d)||!isO(n.r))E('Estrutura inválida: mapas de dias ausentes');
if(n.m.length>20000||n.l.length>60000||n.c.length>200||Object.keys(n.d).length>40000||Object.keys(n.r).length>40000)E('O backup excede os limites permitidos');
var S={v:VERSION,rev:0,m:[],l:[],d:Object.create(null),r:Object.create(null),c:[],ua:Object.create(null),n:1,cn:1,cfg:{name:'',sort:'time'}},cid=new Set(),cname=new Set(),i;
if(n.rev!=null){if(!Number.isInteger(n.rev)||n.rev<0||n.rev>1e12)E('Revisão inválida');S.rev=n.rev}
if(n.cfg!=null){if(!isO(n.cfg)||!str(n.cfg.name==null?'':n.cfg.name,R.LIMITS.name)||(n.cfg.sort!=null&&R.SORTS.indexOf(n.cfg.sort)<0))E('Configurações inválidas');S.cfg={name:(n.cfg.name||'').trim(),sort:n.cfg.sort||'time'}}
n.c.forEach(function(c){if(!isO(c)||!isInt(c.id)||c.id<1||!str(c.name,R.LIMITS.cat)||!c.name.trim())E('Categoria inválida');var k=c.name.trim().toLowerCase();if(cid.has(c.id))E('IDs de categoria duplicados');if(cname.has(k))E('Nomes de categoria duplicados');cid.add(c.id);cname.add(k);S.c.push({id:c.id,name:c.name.trim()})});
var mid=new Map();
n.m.forEach(function(m){var bad=function(w){E('Missão inválida ('+w+')')};if(!isO(m))bad('formato');
 if(!isInt(m.id)||m.id<1)bad('id');if(mid.has(m.id))E('IDs de missão duplicados');
 if(!str(m.title,R.LIMITS.title)||!m.title.trim())bad('título');if(!U.has(G.B,m.df))bad('dificuldade');if(R.ST.indexOf(m.s)<0)bad('estado');if(!U.validDate(m.date))bad('data');
 var time=m.time==null?'':m.time;if(time!==''&&!U.validTime(time))bad('horário');
 var desc=m.desc==null?'':m.desc;if(!str(desc,R.LIMITS.desc))bad('descrição');
 var pr=m.pr==null?'M':m.pr;if(R.PR.indexOf(pr)<0)bad('prioridade');
 var created=m.created==null?0:m.created;if(!isTs(created))bad('criação');
 if(m.cat!=null&&m.cat!==''&&!cid.has(m.cat))E('Missão referencia categoria inexistente');
 if(typeof m.main!=='boolean')bad('principal');
 var reason=m.reason==null?'':m.reason;if(!str(reason,R.LIMITS.reason))bad('justificativa');
 if(m.xp!==G.xpOf(m.df,m.main))E('Valor de XP inválido na missão '+m.id);
 var due=m.due==null?'':m.due;if(due!==''&&(!U.validDate(due)||due<m.date))bad('prazo');
 ['from','to'].forEach(function(k){if(m[k]!=null&&(!isInt(m[k])||m[k]<1))bad(k)});
 if(m.auto!=null&&(m.auto!==1||m.s!=='F'))bad('auto');
 var log=[];if(m.log!=null){if(!Array.isArray(m.log)||m.log.length>100)bad('histórico');m.log.forEach(function(x){if(!isO(x)||!isTs(x.t)||!str(x.e,24)||!x.e||!str(x.d,200))bad('histórico');log.push({t:x.t,e:x.e,d:x.d})})}
 var o={id:m.id,date:m.date,time:time,title:m.title,desc:desc,df:m.df,pr:pr,cat:m.cat||null,main:m.main,s:m.s,reason:reason,xp:m.xp,due:due,created:created,log:log};
 if(m.from!=null)o.from=m.from;if(m.to!=null)o.to=m.to;if(m.auto)o.auto=1;mid.set(m.id,o);S.m.push(o)});
S.m.forEach(function(m){if(m.from!=null){var p=mid.get(m.from);if(!p||p.s!=='R'||p.to!==m.id)E('Referência de reagendamento inconsistente (missão '+m.id+')')}
 if(m.s==='R'){var t=mid.get(m.to);if(!t||t.from!==m.id)E('Reagendamento sem missão destino (missão '+m.id+')')}else if(m.to!=null)E('Campo "to" em missão não reagendada')});
Object.keys(n.d).forEach(function(d){var v=n.d[d];if(!U.validDate(d))E('Data inválida em dias encerrados');if(R.DAYR.indexOf(v)<0)E('Estado de dia inválido');S.d[d]=v});
Object.keys(n.r).forEach(function(d){if(!U.validDate(d))E('Data inválida em dias de descanso');if(n.r[d]!==1)E('Valor inválido em descanso');S.r[d]=1});
var per=new Set();S.m.forEach(function(m){if(m.main&&R.active(m)){if(per.has(m.date))E('Duas principais ativas no mesmo dia');per.add(m.date)}});
var refs=new Set(),bsum={},wsum={};
n.l.forEach(function(x){if(!isO(x)||!str(x.r,64)||!isInt(x.a)||Math.abs(x.a)>1000||!str(x.d,200)||!isTs(x.t))E('Lançamento de XP inválido');if(refs.has(x.r))E('Lançamentos de XP duplicados');refs.add(x.r);var q;
 if(q=/^MC:(\d+)$/.exec(x.r)){var m=mid.get(+q[1]);if(!m||m.s!=='C'||m.xp!==x.a)E('XP de missão incoerente: '+x.r)}
 else if(q=/^B:(\d{4}-\d\d-\d\d):\d+$/.exec(x.r)){if(!U.validDate(q[1])||Math.abs(x.a)!==G.PERF_XP)E('Bônus inválido: '+x.r);bsum[q[1]]=(bsum[q[1]]||0)+x.a}
 else if(q=/^(W|WE):(\d{4}-\d\d-\d\d)$/.exec(x.r)){if(!U.validDate(q[2])||U.wkStart(q[2])!==q[2]||x.a!==G.CH_XP)E('Desafio semanal inválido: '+x.r)}
 else if(q=/^WD:(\d{4}-\d\d-\d\d):\d+$/.exec(x.r)){if(!U.validDate(q[1])||U.wkStart(q[1])!==q[1]||Math.abs(x.a)!==G.CH_XP)E('Desafio semanal inválido: '+x.r);wsum[q[1]]=(wsum[q[1]]||0)+x.a}
 else E('Tipo de lançamento desconhecido');S.l.push({r:x.r,a:x.a,d:x.d,t:x.t})});
S.m.forEach(function(m){if(m.s==='C'&&!refs.has('MC:'+m.id))E('Missão concluída sem lançamento de XP ('+m.id+')')});
Object.keys(wsum).forEach(function(w){if(wsum[w]!==0&&wsum[w]!==G.CH_XP)E('Desafio de disciplina incoerente em '+w)});
var bd={};Object.keys(bsum).forEach(function(d){bd[d]=1});Object.keys(S.d).forEach(function(d){if(S.d[d]==='PERFECT')bd[d]=1});
Object.keys(bd).forEach(function(d){if((bsum[d]||0)!==(S.d[d]==='PERFECT'?G.PERF_XP:0))E('Bônus de dia perfeito incoerente em '+d)});
if(isO(n.ua))Object.keys(n.ua).forEach(function(k){if(!G.ACH.some(function(a){return a[0]===k})||!isTs(n.ua[k]))E('Conquista inválida');S.ua[k]=n.ua[k]});else if(n.ua!=null)E('Conquistas inválidas');
var maxId=0;S.m.forEach(function(m){maxId=Math.max(maxId,m.id)});var maxC=0;S.c.forEach(function(c){maxC=Math.max(maxC,c.id)});
S.n=Math.max(isInt(n.n)?n.n:1,maxId+1,1);S.cn=Math.max(isInt(n.cn)?n.cn:1,maxC+1,1);
var C=R.mk(S);
Object.keys(S.d).forEach(function(d){if(C.on(d).some(R.open))E('Dia encerrado com missões pendentes: '+d);if(C.evalDay(d)!==S.d[d])E('Estado do dia '+d+' incoerente com suas missões')});
S.m.forEach(function(m){if(m.s==='F'&&!S.d[m.date])E('Missão não concluída em dia não encerrado ('+m.id+')')});
Object.keys(S.r).forEach(function(d){if(S.m.some(function(m){return m.date===d&&(m.s==='P'||m.s==='A'||m.s==='C'||m.s==='F')}))E('Dia de descanso '+d+' contém missões ativas')});
/* objetos sem protótipo → objetos comuns (serialização e igualdade previsíveis) */
S.d=Object.assign({},S.d);S.r=Object.assign({},S.r);S.ua=Object.assign({},S.ua);
return S}

/* Migração de dados legados (v1) para as regras atuais; devolve avisos para o usuário. v2→v3 apenas recebe valores padrão em validate(). */
function migrate(o){var notes=[];if(!isO(o)||!Array.isArray(o.m)||!Array.isArray(o.l)||!isO(o.d)||!isO(o.r))return notes;
o.c=o.c||[];o.ua=o.ua||{};Object.keys(o.d).forEach(function(d){if(o.d[d]==='UNPLANNED')delete o.d[d]});
Object.keys(o.r).forEach(function(d){if(o.m.some(function(m){return m&&m.date===d&&['P','C','F'].indexOf(m.s)>=0})){delete o.r[d];notes.push('Descanso removido em '+d+': o dia tinha missões ativas.')}});
try{var C=R.mk(o);Object.keys(o.d).forEach(function(d){if(!U.validDate(d))return;var ev=C.evalDay(d);if(R.DAYR.indexOf(ev)>=0&&ev!==o.d[d]){notes.push('Dia '+d+' reclassificado: '+o.d[d]+' → '+ev+'.');o.d[d]=ev}});
 var ds={};o.l.forEach(function(x){var q=/^B:(\d{4}-\d\d-\d\d):/.exec(x&&x.r||'');if(q)ds[q[1]]=1});Object.keys(o.d).forEach(function(d){if(o.d[d]==='PERFECT')ds[d]=1});Object.keys(ds).forEach(function(d){if(U.validDate(d))C.bonusSync(d)})}catch(e){}
o.v=Math.max(2,o.v|0);return notes}
OD.Schema={validate:validate,migrate:migrate,VERSION:VERSION};
})();
