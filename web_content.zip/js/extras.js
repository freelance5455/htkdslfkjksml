/* Canvas visibility, copy/context-menu blocking */
(()=>{const gv=document.getElementById('gv'),cv=document.querySelector('body>canvas');
if(gv&&cv){const f=()=>{cv.style.visibility=gv.hidden?'':'hidden'};f();new MutationObserver(f).observe(gv,{attributes:true,attributeFilter:['hidden']})}
['copy','cut','dragstart'].forEach(n=>document.addEventListener(n,e=>{const x=e.target;if(x&&x.closest&&x.closest('input,textarea'))return;e.preventDefault()},true));
document.addEventListener('contextmenu',e=>{const x=e.target;if(!(x&&x.closest&&x.closest('input,textarea')))e.preventDefault()});
})();
