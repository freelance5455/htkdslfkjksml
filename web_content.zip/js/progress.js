/**
 * Snake Escape — Progress & Star Calculation Manager
 */
(function() {
  'use strict';

  class ProgressManager {
    constructor(storage) {
      this.storage = storage;
    }

    calculateStars(moves, parMoves, time = 0, parTime = 60) {
      const par = parMoves || 15;
      const tPar = parTime || 60;
      if (moves <= par && time <= tPar) return 3;
      if (moves <= Math.ceil(par * 1.4) && time <= Math.ceil(tPar * 1.4)) return 2;
      return 1;
    }

    saveLevelSuccess(levelId, moves, parMoves, stars, score = 0, time = 0) {
      const earnedStars = stars || this.calculateStars(moves, parMoves, time);
      const existing = this.storage.data.completedLevels[levelId];
      const isNewCompletion = !existing;
      const isBestStars = existing ? earnedStars > existing.stars : true;

      this.storage.saveLevelComplete(levelId, earnedStars, moves, score, time);

      return {
        stars: earnedStars,
        score,
        time,
        isNewCompletion,
        isBestStars,
        totalStars: this.storage.data.totalStars,
        nextLevelUnlocked: Math.min(120, levelId + 1)
      };
    }

    getLevelStars(levelId) {
      const info = this.storage.data.completedLevels[levelId];
      return info ? info.stars : 0;
    }

    getLevelStats(levelId) {
      return this.storage.data.completedLevels[levelId] || null;
    }

    isUnlocked(levelId) {
      return this.storage.isLevelUnlocked(levelId);
    }

    getTotalStars() {
      return this.storage.data.totalStars || 0;
    }

    getCompletedCount() {
      return Object.keys(this.storage.data.completedLevels || {}).length;
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.progress = new ProgressManager(window.SnakeEscape.storage);
})();
