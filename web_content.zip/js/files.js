(function () {
  "use strict";

  const listEl = document.getElementById("file-list");
  const countEl = document.getElementById("files-count");
  const searchEl = document.getElementById("file-search");
  const sortEl = document.getElementById("file-sort");

  let files = [];
  let activeId = null;
  let onOpen = null;
  let searchQuery = "";
  let sortMode = "name";

  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  function langFromName(name) {
    const ext = (name.split(".").pop() || "").toLowerCase();
    if (ext === "html" || ext === "htm") return "html";
    if (ext === "css") return "css";
    if (ext === "js" || ext === "mjs") return "js";
    if (ext === "json") return "json";
    if (ext === "xml" || ext === "svg") return "xml";
    if (ext === "md") return "md";
    return "txt";
  }

  const ICON_COLORS = {
    html: "#f472b6", css: "#38bdf8", js: "#fbbf24",
    json: "#a78bfa", xml: "#34d399", md: "#94a3b8", txt: "#64748b",
  };

  function iconFor(lang) {
    const color = ICON_COLORS[lang] || ICON_COLORS.txt;
    return '<svg class="fi-icon" viewBox="0 0 24 24" fill="none" stroke="' + color +
      '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>';
  }

  function formatSize(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / 1024 / 1024).toFixed(1) + " MB";
  }

  function formatDate(ts) {
    const d = new Date(ts);
    const now = new Date();
    const diff = (now - d) / 1000;
    if (diff < 60) return "الآن";
    if (diff < 3600) return Math.floor(diff / 60) + " د";
    if (diff < 86400) return Math.floor(diff / 3600) + " س";
    return d.toLocaleDateString("ar");
  }

  function getFiltered() {
    let list = files.slice();
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter((f) => f.name.toLowerCase().includes(q));
    }
    if (sortMode === "name") list.sort((a, b) => a.name.localeCompare(b.name));
    else if (sortMode === "type") list.sort((a, b) => a.lang.localeCompare(b.lang) || a.name.localeCompare(b.name));
    else if (sortMode === "date") list.sort((a, b) => (b.updated || 0) - (a.updated || 0));
    return list;
  }

  function render() {
    countEl.textContent = files.length + " ملف";
    const list = getFiltered();
    if (!list.length) {
      listEl.innerHTML = '<div class="empty-state">' +
        '<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>' +
        '<div>' + (searchQuery ? "لا نتائج مطابقة" : "لا توجد ملفات بعد") + '</div></div>';
      return;
    }
    listEl.innerHTML = list.map((f) => {
      const active = f.id === activeId ? " active" : "";
      const size = formatSize(new Blob([f.content || ""]).size);
      return '<div class="file-item' + active + '" data-id="' + f.id + '">' +
        iconFor(f.lang) +
        '<div class="fi-info"><div class="fi-name">' + window.Highlighter.esc(f.name) + '</div>' +
        '<div class="fi-meta">' + f.lang.toUpperCase() + ' • ' + size + ' • ' + formatDate(f.updated || Date.now()) + '</div></div>' +
        '<button class="fi-del" data-del="' + f.id + '" aria-label="حذف">×</button>' +
        '</div>';
    }).join("");
  }

  function open(id) {
    const f = files.find((x) => x.id === id);
    if (!f) return;
    activeId = id;
    render();
    if (onOpen) onOpen(f);
  }

  function create(name, content) {
    const lang = langFromName(name);
    const f = { id: uid(), name, lang, content: content || "", updated: Date.now() };
    files.push(f);
    render();
    return f;
  }

  function remove(id) {
    files = files.filter((f) => f.id !== id);
    if (activeId === id) activeId = files.length ? files[0].id : null;
    render();
  }

  function rename(id, newName) {
    const f = files.find((x) => x.id === id);
    if (!f) return;
    f.name = newName;
    f.lang = langFromName(newName);
    render();
  }

  function updateContent(id, content) {
    const f = files.find((x) => x.id === id);
    if (!f) return;
    f.content = content;
    f.updated = Date.now();
  }

  function get(id) { return files.find((f) => f.id === id); }
  function getActive() { return get(activeId); }
  function all() { return files; }
  function setActive(id) { activeId = id; render(); }
  function getActiveId() { return activeId; }

  function loadFrom(data) {
    if (Array.isArray(data) && data.length) {
      files = data.map((f) => ({
        id: f.id || uid(),
        name: f.name || "untitled.txt",
        lang: f.lang || langFromName(f.name || "untitled.txt"),
        content: f.content || "",
        updated: f.updated || Date.now(),
      }));
      activeId = files[0].id;
    }
    render();
  }

  function toJSON() { return files; }
  function totalChars() { return files.reduce((s, f) => s + (f.content || "").length, 0); }

  searchEl.addEventListener("input", () => { searchQuery = searchEl.value; render(); });
  sortEl.addEventListener("change", () => { sortMode = sortEl.value; render(); });

  window.Files = {
    render, open, create, remove, rename, updateContent,
    get, getActive, all, setActive, getActiveId, loadFrom, toJSON, totalChars,
    onOpen: (cb) => { onOpen = cb; },
    langFromName,
  };
})();