/* ابزارهای مشاور: تعریف ابزارها با اعتبارسنجی ورودی، اجرا، پشته‌ی برگشت (حداکثر ۲۰)، و پیشنهاد گروهی که پیش از اعمال تأیید کاربر می‌خواهد. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var ex = App.exam;
  var ai = (App.ai = App.ai || {});
  var S = function () { return App.S; };
  var TOOLS = {};
  var MAX_UNDO = 20;
  var MUTATING = ['add_study_session', 'add_exam_result', 'update_goal', 'set_konkur_date', 'add_todo', 'toggle_todo', 'rename_chapter', 'set_chapter_count', 'add_weak_point', 'add_backlog', 'save_profile_note', 'create_quiz', 'delete_todo', 'delete_log', 'delete_exam', 'delete_memory'];
  var seq = 0;
  ai.undoStack = [];
  ai.proposals = {};

  // ---- پشته‌ی برگشت ----
  function pushUndo(label, fn) {
    seq++;
    var id = 'u' + seq + '-' + (Date.now() % 1000000);
    ai.undoStack.push({ id: id, label: label, fn: fn });
    while (ai.undoStack.length > MAX_UNDO) ai.undoStack.shift();
    return id;
  }
  ai.undoAvailable = function (uid) {
    return !!uid && ai.undoStack.some(function (e) { return e.id === uid; });
  };
  ai.undo = function (uid) {
    var i = ai.undoStack.findIndex(function (e) { return e.id === uid; });
    if (i < 0) return { ok: false, error: 'این کار دیگر قابل برگشت نیست.' };
    var e = ai.undoStack.splice(i, 1)[0];
    try { e.fn(); }
    catch (err) { App.logError(err); return { ok: false, error: 'برگرداندن انجام نشد.' }; }
    App.save();
    return { ok: true, label: e.label };
  };

  // ---- ابزارهای اعتبارسنجی ----
  function fail(msg) { var e = new Error(msg); e.userFacing = true; return e; }
  function need(cond, msg) { if (!cond) throw fail(msg); }
  function intIn(x, min, max, def, name) {
    if (x === undefined || x === null || x === '') return def;
    var n = Math.round(Number(x));
    if (!isFinite(n) || n < min || n > max) throw fail('مقدار ' + name + ' باید بین ' + u.fa(min) + ' و ' + u.fa(max) + ' باشد.');
    return n;
  }
  function strIn(x, max, name, required) {
    var v = String(x == null ? '' : x).trim();
    if (!v && required) throw fail(name + ' خالی است.');
    return v.slice(0, max);
  }
  function dateIn(x, name) {
    if (x === undefined || x === null || x === '') return u.todayISO();
    var v = String(x).trim();
    if (v === 'today' || v === 'امروز') return u.todayISO();
    if (v === 'tomorrow' || v === 'فردا') return u.addDays(u.todayISO(), 1);
    need(u.isISO(v), name + ' باید به شکل YYYY-MM-DD میلادی باشد.');
    return v;
  }
  function gradeIn(x) {
    var g = x === undefined || x === null || x === '' ? S().mg : Math.round(Number(x));
    need(D.GRADES.indexOf(g) >= 0, 'پایه باید ۸، ۱۰، ۱۱ یا ۱۲ باشد.');
    return g;
  }
  function subjIn(name, g) {
    var list = D.subjects(g).map(function (x) { return x.name; });
    var v = String(name || '').trim();
    if (list.indexOf(v) >= 0) return v;
    var alt = D.subjectFromText(v);
    if (alt && list.indexOf(alt) >= 0) return alt;
    throw fail('درس «' + v + '» در این پایه نیست. درس‌های پایه‌ی ' + u.fa(g) + ': ' + list.join('، '));
  }
  function chapterIn(x, g, s, def) {
    var c = intIn(x, 0, D.MAX_CH, def || 0, 'فصل');
    var n = st.chCount(g, s);
    if (c > 0 && n > 0) need(c <= n, 'این درس فقط ' + u.fa(n) + ' فصل دارد.');
    return c;
  }
  function dayLabel(iso) { return u.jd(iso); }

  function def(name, description, props, required, run) {
    TOOLS[name] = {
      run: run,
      def: { name: name, description: description, input_schema: { type: 'object', properties: props, required: required || [] } }
    };
  }
  var DATE_P = { type: 'string', description: 'تاریخ میلادی YYYY-MM-DD؛ یا today / tomorrow. پیش‌فرض امروز.' };
  var SUBJ_P = { type: 'string', description: 'نام دقیق درس (مثلاً ریاضی، فیزیک، شیمی، حسابان)' };
  var GRADE_P = { type: 'integer', enum: [8, 10, 11, 12], description: 'پایه؛ پیش‌فرض پایه‌ی انتخابی کاربر' };
  var CONFIRM_P = { type: 'boolean', description: 'باید true باشد؛ کاربر در پنجره‌ی تأیید نهایی می‌زند.' };

  // ---- تعریف ابزارها ----
  def('get_snapshot', 'وضعیت به‌روز کاربر را بگیر (بعد از تغییرها دوباره صدا بزن).', {}, [], function () {
    return { result: ai.snapshot() };
  });

  def('add_study_session', 'یک بار مطالعه یا کلاس ثبت کن. حداقل یکی از minutes یا tests لازم است.', {
    subject: SUBJ_P, grade: GRADE_P,
    chapter: { type: 'integer', minimum: 0, maximum: 30, description: 'شماره‌ی فصل؛ ۰ یعنی بدون فصل' },
    minutes: { type: 'integer', minimum: 0, maximum: 1440 },
    tests: { type: 'integer', minimum: 0, maximum: 5000, description: 'تعداد تستی که زده شد' },
    correct: { type: 'integer', minimum: 0, maximum: 5000, description: 'تعداد درست از همان تست‌ها' },
    date: DATE_P,
    is_class: { type: 'boolean', description: 'true برای کلاس (جدا از مطالعه)' }
  }, ['subject'], function (x) {
    var g = gradeIn(x.grade), s = subjIn(x.subject, g);
    var m = intIn(x.minutes, 0, 1440, 0, 'دقیقه'), t = intIn(x.tests, 0, 5000, 0, 'تعداد تست');
    need(m || t, 'زمان (minutes) یا تعداد تست (tests) را بده.');
    var ok = x.correct === undefined || x.correct === null || x.correct === '' ? undefined : intIn(x.correct, 0, t, 0, 'تعداد درست');
    var c = chapterIn(x.chapter, g, s, 0), d = dateIn(x.date, 'تاریخ');
    var rec = st.addLog({ g: g, s: s, c: c, m: m, t: t, ok: ok, k: x.is_class ? 'c' : undefined, d: d });
    need(rec, 'ثبت انجام نشد.');
    var label = (x.is_class ? '🏫 کلاس' : '📖 مطالعه') + ' ' + (m ? u.hm(m) : '') + ' · ' + s + (c ? ' · ' + st.chName(g, s, c) : '') + (t ? ' · ' + u.fa(t) + ' تست' + (ok != null ? ' (' + u.fa(ok) + ' درست)' : '') : '') + ' · ' + dayLabel(d);
    return { result: { ok: true, id: rec.id }, label: '✅ ثبت شد: ' + label, undo: function () { st.delLog(rec.id); } };
  });

  def('add_exam_result', 'نتیجه‌ی یک آزمون را ثبت کن. اگر درس نداری خالی بگذار (ترکیبی).', {
    name: { type: 'string', description: 'نام آزمون' },
    subject: { type: 'string', description: 'درس (اختیاری)' },
    date: DATE_P,
    total: { type: 'integer', minimum: 1, maximum: 1000, description: 'کل سؤال‌ها' },
    correct: { type: 'integer', minimum: 0, maximum: 1000 },
    wrong: { type: 'integer', minimum: 0, maximum: 1000 },
    taraz: { type: 'integer', minimum: 0, maximum: 10000, description: 'تراز (اختیاری)' },
    negative_marking: { type: 'boolean', description: 'اگر نمره‌ی منفی حساب شده، true' }
  }, ['total', 'correct', 'wrong'], function (x) {
    var t = intIn(x.total, 1, 1000, 0, 'کل سؤال‌ها');
    var c = intIn(x.correct, 0, t, 0, 'درست'), w = intIn(x.wrong, 0, t, 0, 'غلط');
    need(c + w <= t, 'درست + غلط نباید از کل سؤال‌ها بیشتر باشد.');
    var s = String(x.subject || '').trim();
    if (s) s = subjIn(s, S().mg);
    var rec = ex.addResult({ n: strIn(x.name, 60, 'نام آزمون'), s: s, date: dateIn(x.date, 'تاریخ'), t: t, c: c, w: w, z: intIn(x.taraz, 0, 10000, 0, 'تراز') || 0, neg: x.negative_marking ? 1 : 0 });
    need(rec, 'ثبت آزمون انجام نشد.');
    return { result: { ok: true, id: rec.id, percent: rec.p }, label: '🧪 آزمون ثبت شد: ' + u.fa(c) + ' از ' + u.fa(t) + ' (' + u.pct(rec.p) + ')' + (s ? ' · ' + s : ''), undo: function () { ex.delResult(rec.id); } };
  });

  def('update_goal', 'هدف روزانه‌ی مطالعه را به دقیقه تغییر بده.', {
    minutes: { type: 'integer', minimum: 10, maximum: 1440 }
  }, ['minutes'], function (x) {
    var m = intIn(x.minutes, 10, 1440, 0, 'هدف روزانه');
    var prev = S().goal;
    S().goal = m;
    return { result: { ok: true, goal_min: m }, label: '🎯 هدف روزانه: ' + u.hm(m), undo: function () { S().goal = prev; } };
  });

  def('set_konkur_date', 'تاریخ کنکور را ثبت یا عوض کن.', { date: DATE_P }, ['date'], function (x) {
    var d = dateIn(x.date, 'تاریخ کنکور');
    var prev = S().cd;
    S().cd = d;
    return { result: { ok: true, date: d }, label: '📅 تاریخ کنکور: ' + dayLabel(d), undo: function () { S().cd = prev; } };
  });

  def('list_todos', 'کارهای یک روز را با شناسه بگیر.', { date: DATE_P }, [], function (x) {
    var d = dateIn(x.date, 'تاریخ');
    return { result: { ok: true, date: d, todos: st.todosOn(d).map(function (t) { return { id: t.id, text: t.t, done: !!t.o, due: t.due }; }) }, save: false };
  });

  def('add_todo', 'یک کار به فهرست کارهای یک روز اضافه کن. اگر due بدهی، کار پیگیری با یادآوری در آن روز ثبت می‌شود.', {
    text: { type: 'string', description: 'متن کار (حداکثر ۲۰۰ نویسه)' }, date: DATE_P,
    due: { type: 'string', description: 'اختیاری: تاریخ پیگیری YYYY-MM-DD یا today/tomorrow' }
  }, ['text'], function (x) {
    var txt = strIn(x.text, 200, 'متن کار', true);
    var due = x.due ? dateIn(x.due, 'تاریخ پیگیری') : '';
    var o = st.addTodo(txt, dateIn(x.date, 'تاریخ'), due);
    need(o, 'کار اضافه نشد.');
    return { result: { ok: true, id: o.id, due: due || undefined }, label: '✅ کار اضافه شد: ' + u.clip(txt, 60) + (due ? ' (پیگیری ' + dayLabel(due) + ')' : ''), undo: function () { st.delById(S().todos, o.id); } };
  });

  def('toggle_todo', 'وضعیت انجام‌شدن یک کار را عوض کن (با شناسه‌ی list_todos).', {
    id: { type: 'string', description: 'شناسه‌ی کار' }
  }, ['id'], function (x) {
    var o = S().todos.find(function (t) { return String(t.id) === String(x.id); });
    need(o, 'کاری با این شناسه پیدا نشد.');
    o.o = o.o ? 0 : 1;
    return { result: { ok: true, done: !!o.o }, label: (o.o ? '☑️ انجام شد: ' : '↩️ دوباره باز شد: ') + u.clip(o.t, 60), undo: function () { o.o = o.o ? 0 : 1; } };
  });

  def('rename_chapter', 'نام یک فصل را عوض کن (حداکثر ۳۰ نویسه).', {
    grade: GRADE_P, subject: SUBJ_P,
    chapter: { type: 'integer', minimum: 1, maximum: 30 },
    name: { type: 'string' }
  }, ['subject', 'chapter', 'name'], function (x) {
    var g = gradeIn(x.grade), s = subjIn(x.subject, g);
    var c = intIn(x.chapter, 1, D.MAX_CH, 0, 'شماره‌ی فصل');
    var name = strIn(x.name, 30, 'نام فصل', true);
    var key = st.chKey(g, s) + '|' + c;
    var prev = (S().cn || {})[key];
    st.renameCh(g, s, c, name);
    return { result: { ok: true }, label: '✏️ فصل ' + u.fa(c) + ' ' + s + ': ' + name, undo: function () { st.renameCh(g, s, c, prev || ''); } };
  });

  def('set_chapter_count', 'تعداد فصل‌های یک درس را تعیین کن (۰ تا ۳۰).', {
    grade: GRADE_P, subject: SUBJ_P, count: { type: 'integer', minimum: 0, maximum: 30 }
  }, ['subject', 'count'], function (x) {
    var g = gradeIn(x.grade), s = subjIn(x.subject, g);
    var n = intIn(x.count, 0, D.MAX_CH, 0, 'تعداد فصل');
    var prev = st.chCount(g, s);
    st.setChCount(g, s, n);
    return { result: { ok: true, count: n }, label: '🔢 تعداد فصل‌های ' + s + ': ' + u.fa(n), undo: function () { st.setChCount(g, s, prev); } };
  });

  def('add_weak_point', 'یک نقطه‌ی ضعف باز ثبت کن.', {
    grade: GRADE_P, subject: SUBJ_P, text: { type: 'string' },
    level: { type: 'integer', minimum: 1, maximum: 3, description: '۱ کم، ۲ متوسط، ۳ زیاد' }
  }, ['subject', 'text'], function (x) {
    var g = gradeIn(x.grade), s = subjIn(x.subject, g);
    var t = strIn(x.text, 200, 'متن نقطه‌ی ضعف', true);
    var w = st.addWeak({ s: s, t: t, v: intIn(x.level, 1, 3, 2, 'سطح'), m: 10 });
    need(w, 'ثبت نشد.');
    return { result: { ok: true, id: w.id }, label: '🎯 نقطه‌ی ضعف: ' + s + ' — ' + u.clip(t, 60), undo: function () { st.delById(S().wk, w.id); } };
  });

  def('add_backlog', 'یک عقب‌افتادگی برای جبران ثبت کن.', {
    grade: GRADE_P, subject: SUBJ_P, text: { type: 'string' }
  }, ['subject', 'text'], function (x) {
    var g = gradeIn(x.grade), s = subjIn(x.subject, g);
    var t = strIn(x.text, 200, 'متن عقب‌افتادگی', true);
    var b = st.addBacklog({ s: s, t: t, u: 0 });
    need(b, 'ثبت نشد.');
    return { result: { ok: true, id: b.id }, label: '📌 عقب‌افتادگی: ' + s + ' — ' + u.clip(t, 60), undo: function () { st.delById(S().bl, b.id); } };
  });

  def('save_profile_note', 'یک نکته‌ی ماندگار دربارهٔ کاربر در حافظه‌ی مشاور ذخیره کن (فقط وقتی کاربر خواسته یا موافق است).', {
    text: { type: 'string', description: 'حداکثر ۲۰۰ نویسه' }
  }, ['text'], function (x) {
    var t = strIn(x.text, 200, 'یادداشت', true);
    var m = st.addMemory(t);
    need(m, 'یادداشت ذخیره نشد.');
    return { result: { ok: true, id: m.id }, label: '🧠 به حافظه افزوده شد: ' + u.clip(t, 60), undo: function () { st.delById(S().mem, m.id); } };
  });

  def('navigate', 'پیشنهاد باز کردن یک بخش برنامه را به کاربر نشان بده (کاربر خودش دکمه را می‌زند).', {
    tab: { type: 'string', enum: ['today', 'plan', 'subj', 'exam', 'stat', 'timer', 'settings'] }
  }, ['tab'], function (x) {
    var tabs = { today: 'امروز', plan: 'برنامه', subj: 'دروس', exam: 'آزمون', stat: 'آمار', timer: 'تایمر', settings: 'تنظیمات' };
    need(tabs[x.tab], 'بخش ناشناخته است.');
    return { result: { ok: true, note: 'کاربر با دکمه به این بخش می‌رود' }, label: '➡️ ' + tabs[x.tab], save: false, nav: x.tab };
  });

  def('create_quiz', 'یک آزمون تستی (کلید پاسخ A تا D) بساز.', {
    title: { type: 'string' }, grade: GRADE_P, subject: SUBJ_P,
    chapter: { type: 'integer', minimum: 0, maximum: 30 },
    answers: { type: 'string', description: 'کلید پاسخ مثل ABCDAB… (۴ تا ۶۰ حرف از A تا D)' }
  }, ['answers'], function (x) {
    var key = String(x.answers || '').toUpperCase().replace(/\s+/g, '');
    need(/^[ABCD]{4,60}$/.test(key), 'کلید پاسخ باید بین ۴ تا ۶۰ حرف از A تا D باشد.');
    var g = gradeIn(x.grade), s = x.subject ? subjIn(x.subject, g) : '';
    var q = ex.quizAdd({ title: strIn(x.title, 80, 'عنوان') || 'آزمون تستی', g: g, s: s, ch: intIn(x.chapter, 0, 30, 0, 'فصل'), src: 'ai', tl: 0, questions: key.split('').map(function (a) { return { a: a }; }) });
    need(q, 'آزمون ساخته نشد.');
    return { result: { ok: true, id: q.id, questions: key.length }, label: '📝 آزمون تستی: ' + q.title + ' (' + u.fa(key.length) + ' سؤال)', undo: function () { ex.quizDel(q.id); } };
  });

  // پیشنهاد گروهی: هیچ‌کدام از تغییرها تا تأیید کاربر اعمال نمی‌شود
  def('propose_changes', 'چند تغییر را به‌صورت یک پیشنهاد نشان بده. کاربر با دکمه‌ی «اعمال» همه را تأیید می‌کند.', {
    summary: { type: 'string', description: 'خلاصه‌ی پیشنهاد در یک جمله' },
    changes: {
      type: 'array', maxItems: 15,
      items: {
        type: 'object',
        properties: { tool: { type: 'string', enum: MUTATING }, input: { type: 'object' } },
        required: ['tool', 'input']
      }
    }
  }, ['summary', 'changes'], function (x) {
    var list = Array.isArray(x.changes) ? x.changes : [];
    need(list.length >= 1 && list.length <= 15, 'پیشنهاد باید بین ۱ تا ۱۵ تغییر داشته باشد.');
    list.forEach(function (c) { need(c && MUTATING.indexOf(c.tool) >= 0 && c.input && typeof c.input === 'object', 'یکی از تغییرهای پیشنهادی معتبر نیست.'); });
    seq++;
    var pid = 'p' + seq + '-' + (Date.now() % 1000000);
    var summary = strIn(x.summary, 160, 'خلاصه', true);
    ai.proposals[pid] = { id: pid, summary: summary, changes: list.map(function (c) { return { tool: c.tool, input: c.input }; }), status: 'pending' };
    return { result: { ok: true, status: 'waiting_for_user', note: 'هنوز اعمال نشده؛ منتظر تأیید کاربر است.' }, label: '📋 پیشنهاد: ' + summary, save: false, proposal: pid };
  });

  // ---- حذف: فقط با confirm=true و پنجره‌ی تأیید بومی ----
  function needDelete(x, what, ctx) {
    need(x.confirm === true, 'برای حذف، confirm=true لازم است و فقط وقتی کاربر خواسته.');
    if (!ctx.skipNative) need(App.confirm('حذف ' + what + ' انجام شود؟'), 'کاربر حذف را لغو کرد.');
  }
  def('delete_todo', 'یک کار را حذف کن (فقط با درخواست صریح کاربر).', { id: { type: 'string' }, confirm: CONFIRM_P }, ['id', 'confirm'], function (x, ctx) {
    needDelete(x, 'این کار', ctx);
    var list = S().todos, i = list.findIndex(function (t) { return String(t.id) === String(x.id); });
    need(i >= 0, 'کاری با این شناسه پیدا نشد.');
    var rec = list.splice(i, 1)[0];
    return { result: { ok: true }, label: '🗑 کار حذف شد: ' + u.clip(rec.t, 50), undo: function () { S().todos.push(rec); } };
  });
  def('delete_log', 'یک ثبت مطالعه را حذف کن (فقط با درخواست صریح کاربر).', { id: { type: 'string' }, confirm: CONFIRM_P }, ['id', 'confirm'], function (x, ctx) {
    needDelete(x, 'این ثبت', ctx);
    var rec = st.delLog(x.id);
    need(rec, 'ثبتی با این شناسه پیدا نشد.');
    return { result: { ok: true }, label: '🗑 ثبت حذف شد: ' + u.fa(rec.m) + ' دقیقه · ' + dayLabel(rec.d), undo: function () { S().logs.push(rec); S().logs.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; }); } };
  });
  def('delete_exam', 'یک آزمون را حذف کن (فقط با درخواست صریح کاربر).', { id: { type: 'string' }, confirm: CONFIRM_P }, ['id', 'confirm'], function (x, ctx) {
    needDelete(x, 'این آزمون', ctx);
    var rec = S().exams.find(function (e) { return String(e.id) === String(x.id); });
    need(rec, 'آزمونی با این شناسه پیدا نشد.');
    ex.delResult(rec.id);
    return { result: { ok: true }, label: '🗑 آزمون حذف شد: ' + dayLabel(rec.d), undo: function () { S().exams.push(rec); S().exams.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; }); } };
  });
  def('delete_memory', 'یک یادداشت حافظه‌ی مشاور را حذف کن (فقط با درخواست صریح کاربر).', { id: { type: 'string' }, confirm: CONFIRM_P }, ['id', 'confirm'], function (x, ctx) {
    needDelete(x, 'این یادداشت', ctx);
    var list = S().mem || [], i = list.findIndex(function (m) { return String(m.id) === String(x.id); });
    need(i >= 0, 'یادداشتی با این شناسه پیدا نشد.');
    var rec = list.splice(i, 1)[0];
    return { result: { ok: true }, label: '🗑 یادداشت حذف شد', undo: function () { S().mem.push(rec); } };
  });

  // ---- اجرا ----
  ai.toolDefs = function () {
    return Object.keys(TOOLS).map(function (k) { return TOOLS[k].def; });
  };
  // نتیجه: result (برای مدل)، label (برای کارت)، ok، uid (برای دکمه‌ی برگشت)، nav و proposal (اگر باشد)
  ai.runTool = function (name, input, ctx) {
    ctx = ctx || {};
    var t = TOOLS[name];
    input = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
    if (!t) return { ok: false, result: { ok: false, error: 'ابزار ناشناخته: ' + String(name).slice(0, 40) }, label: '⚠️ ابزار ناشناخته' };
    try {
      var out = t.run(input, ctx) || {};
      var uid = '';
      if (out.undo) uid = pushUndo(out.label || name, out.undo);
      if (out.proposal) uid = out.proposal;
      if (out.save !== false) App.save();
      return { ok: true, result: out.result || { ok: true }, label: out.label || name, uid: uid, nav: out.nav || '', proposal: out.proposal || '' };
    } catch (e) {
      var userMsg = e && e.userFacing ? e.message : 'این کار انجام نشد.';
      if (!(e && e.userFacing)) App.logError(e);
      return { ok: false, result: { ok: false, error: userMsg }, label: '⚠️ ' + userMsg };
    }
  };

  // اعمال یک پیشنهاد: همه‌ی تغییرها با هم یک برگشت دارند
  ai.applyProposal = function (pid) {
    var p = ai.proposals[pid];
    if (!p || p.status !== 'pending') return { ok: false, error: 'این پیشنهاد دیگر قابل اعمال نیست.' };
    var hasDel = p.changes.some(function (c) { return /^delete_/.test(c.tool); });
    if (hasDel && !App.confirm('این پیشنهاد شامل حذف است. همه‌ی موارد اعمال شود؟')) return { ok: false, error: 'لغو شد.' };
    var uids = [], failed = [], done = 0;
    p.changes.forEach(function (c) {
      var r = ai.runTool(c.tool, c.input, { skipNative: hasDel });
      if (r.ok) { done++; if (r.uid && r.uid !== pid) uids.push(r.uid); }
      else failed.push(r.result.error);
    });
    var parts = ai.undoStack.filter(function (e) { return uids.indexOf(e.id) >= 0; });
    ai.undoStack = ai.undoStack.filter(function (e) { return uids.indexOf(e.id) < 0; });
    var gid = parts.length ? pushUndo('پیشنهاد: ' + p.summary, function () {
      for (var i = parts.length - 1; i >= 0; i--) parts[i].fn();
    }) : '';
    p.status = 'applied';
    p.done = done;
    p.failed = failed.length;
    p.uid = gid;
    App.save();
    return { ok: true, done: done, failed: failed, uid: gid };
  };
  ai.cancelProposal = function (pid) {
    var p = ai.proposals[pid];
    if (p && p.status === 'pending') p.status = 'cancelled';
    return !!p;
  };
})();
