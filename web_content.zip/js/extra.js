/* ============================================================
   extra.js — Fase 3/4: porrinha, revisão da mão, mesa maluca,
   Noite de Truco, seu boteco, foto da mão, sala com amigos.
   Carregar DEPOIS de bairro.js e ANTES de world.js.
   ============================================================ */

/* ---------- Mesa maluca da semana (regra diferente) ---------- */
const CRAZY_RULES = [
  { id: 'virada', name: { pt: 'Vira dupla', en: 'Double flip', es: 'Vira doble' },
    desc: { pt: 'Duas viras na mesa. Manilhas das duas contam.', en: 'Two flip cards. Both trump ranks count.', es: 'Dos viras. Ambos rangos de manilla cuentan.' } },
  { id: 'cego', name: { pt: 'Mão cega', en: 'Blind hand', es: 'Mano ciega' },
    desc: { pt: 'Você só vê 2 das 3 cartas até jogar a primeira.', en: 'You only see 2 of 3 cards until you play the first.', es: 'Solo ves 2 de 3 cartas hasta jugar la primera.' } },
  { id: 'relampago', name: { pt: 'Relâmpago', en: 'Lightning', es: 'Relámpago' },
    desc: { pt: 'Timer de 8 segundos por jogada.', en: '8 second timer per play.', es: 'Timer de 8 segundos por jugada.' } },
  { id: 'vale3', name: { pt: 'Tudo vale 3', en: 'Everything is 3', es: 'Todo vale 3' },
    desc: { pt: 'Cada mão já começa valendo 3.', en: 'Every hand starts worth 3.', es: 'Cada mano empieza valiendo 3.' } },
  { id: 'sem_fugir', name: { pt: 'Sem correr', en: 'No running', es: 'Sin correr' },
    desc: { pt: 'Não dá pra correr do truco. Só aceita ou aumenta.', en: 'Cannot run from truco. Only accept or raise.', es: 'No se puede correr del truco. Solo aceptar o subir.' } },
  { id: 'manilha_fixa', name: { pt: 'Manilha invertida', en: 'Inverted trump', es: 'Manilla invertida' },
    desc: { pt: 'A manilha é a carta ANTERIOR à vira, não a seguinte.', en: 'Trump is the card BEFORE the flip, not after.', es: 'La manilla es la carta ANTERIOR a la vira.' } },
  { id: 'aposta_dobro', name: { pt: 'Aposta em dobro', en: 'Double stakes', es: 'Apuesta doble' },
    desc: { pt: 'Toda aposta da semana vale o dobro.', en: 'All bets this week are doubled.', es: 'Todas las apuestas de la semana valen doble.' } },
];

/* ---------- Noite de Truco: caminhos do mapa ---------- */
const NIGHT_PATHS = [
  { id: 'norte', name: { pt: 'Rota do Norte', en: 'North Route', es: 'Ruta del Norte' },
    stops: ['zeca', 'dudu', 'padre', 'nogueira'], reward: 80 },
  { id: 'sul', name: { pt: 'Rota do Morro', en: 'Hill Route', es: 'Ruta del Cerro' },
    stops: ['bereba', 'kombi', 'taxi', 'lenda'], reward: 120 },
  { id: 'centro', name: { pt: 'Rota do Centro', en: 'Downtown Route', es: 'Ruta del Centro' },
    stops: ['dona', 'dete', 'sindico', 'cotinha'], reward: 100 },
];

const Extra = {
  /* estado */
  handLog: [],          // últimas jogadas da mão [{who, card, note}]
  handReviewOn: true,   // toggle (também em Opts)
  lastHand: null,       // snapshot pra revisão
  crazyWeek: null,      // id da regra da semana
  crazyWeekNum: -1,
  nightActive: false,
  nightPath: null,      // id do caminho
  nightIndex: 0,        // parada atual
  nightWins: 0,
  ownBar: false,        // comprou o barracão
  ownBarLevel: 0,       // 0-3 upgrades
  ownBarCash: 0,        // lucro acumulado pra coletar
  photoHands: [],       // [{cards, score, vs, day}]
  roomCode: null,       // sala local (simulado)
  roomHost: false,
  manias: {},           // id npc -> mania ativa (opcional)

  lang() { return (typeof T !== 'undefined' && T.lang) || 'pt'; },

  /* ---------- Revisão da mão ---------- */
  logPlay(who, card, note) {
    if (!this.handReviewOn) return;
    this.handLog.push({ who, card, note: note || '', t: Date.now() });
    if (this.handLog.length > 40) this.handLog.shift();
  },

  snapshotHand(meta) {
    if (!this.handReviewOn) return;
    this.lastHand = {
      log: this.handLog.slice(),
      meta: meta || {},
      day: (typeof World !== 'undefined') ? World.day : 0,
    };
    this.handLog = [];
  },

  /* ---------- Mesa maluca ---------- */
  weekNumber(d) {
    d = d || new Date();
    const onejan = new Date(d.getFullYear(), 0, 1);
    return Math.ceil((((d - onejan) / 86400000) + onejan.getDay() + 1) / 7);
  },

  crazyOfWeek() {
    const w = this.weekNumber();
    if (this.crazyWeekNum !== w) {
      this.crazyWeekNum = w;
      this.crazyWeek = CRAZY_RULES[w % CRAZY_RULES.length].id;
    }
    return CRAZY_RULES.find((r) => r.id === this.crazyWeek) || CRAZY_RULES[0];
  },

  crazyName() {
    const r = this.crazyOfWeek();
    return (r.name[this.lang()] || r.name.pt);
  },

  crazyDesc() {
    const r = this.crazyOfWeek();
    return (r.desc[this.lang()] || r.desc.pt);
  },

  crazyMods() {
    const id = this.crazyOfWeek().id;
    if (id === 'relampago') return { turn: -12 };
    if (id === 'vale3') return { handStart: 3 };
    if (id === 'aposta_dobro') return { payMult: 2 };
    return {};
  },

  /* ---------- Noite de Truco ---------- */
  startNight(pathId) {
    const p = NIGHT_PATHS.find((x) => x.id === pathId);
    if (!p) return false;
    this.nightActive = true;
    this.nightPath = pathId;
    this.nightIndex = 0;
    this.nightWins = 0;
    return true;
  },

  nightStop() {
    if (!this.nightActive) return null;
    const p = NIGHT_PATHS.find((x) => x.id === this.nightPath);
    if (!p) return null;
    return p.stops[this.nightIndex] || null;
  },

  nightAdvance(won) {
    if (!this.nightActive) return { done: true, reward: 0, wins: this.nightWins };
    if (won) this.nightWins++;
    this.nightIndex++;
    const p = NIGHT_PATHS.find((x) => x.id === this.nightPath);
    if (!p || this.nightIndex >= p.stops.length) {
      // recompensa proporcional às vitórias na rota
      const base = p ? p.reward : 50;
      const ratio = p && p.stops.length ? this.nightWins / p.stops.length : 0;
      const reward = Math.max(0, Math.round(base * Math.max(0.25, ratio)));
      this.nightActive = false;
      const result = { done: true, reward, wins: this.nightWins, path: p };
      this.nightPath = null;
      this.nightIndex = 0;
      return result;
    }
    return { done: false, next: p.stops[this.nightIndex], wins: this.nightWins };
  },

  nightAbort() {
    this.nightActive = false;
    this.nightPath = null;
    this.nightIndex = 0;
  },

  /* ---------- Seu próprio boteco ---------- */
  BAR_PRICE: 500,
  BAR_UPGRADES: [
    { id: 'mesas', cost: 150, income: 8, name: { pt: 'Mais mesas', en: 'More tables', es: 'Más mesas' } },
    { id: 'som', cost: 200, income: 12, name: { pt: 'Som ambiente', en: 'Ambient sound', es: 'Sonido ambiente' } },
    { id: 'carta', cost: 300, income: 18, name: { pt: 'Mesa VIP de truco', en: 'VIP truco table', es: 'Mesa VIP de truco' } },
  ],

  canBuyBar(money, storyDone) {
    return !this.ownBar && storyDone && money >= this.BAR_PRICE;
  },

  buyBar(world) {
    if (this.ownBar) return false;
    if (world.money < this.BAR_PRICE) return false;
    world.money -= this.BAR_PRICE;
    this.ownBar = true;
    this.ownBarLevel = 0;
    this.ownBarCash = 0;
    return true;
  },

  barIncomePerDay() {
    if (!this.ownBar) return 0;
    let n = 15;
    for (let i = 0; i < this.ownBarLevel; i++) n += this.BAR_UPGRADES[i].income;
    return n;
  },

  tickBarDay() {
    if (!this.ownBar) return;
    this.ownBarCash += this.barIncomePerDay();
  },

  collectBar(world) {
    if (!this.ownBar || this.ownBarCash <= 0) return 0;
    const n = this.ownBarCash;
    world.money += n;
    this.ownBarCash = 0;
    return n;
  },

  upgradeBar(world) {
    if (!this.ownBar || this.ownBarLevel >= this.BAR_UPGRADES.length) return false;
    const u = this.BAR_UPGRADES[this.ownBarLevel];
    if (world.money < u.cost) return false;
    world.money -= u.cost;
    this.ownBarLevel++;
    return u;
  },

  /* ---------- Foto da mão histórica ---------- */
  savePhoto(cards, meta) {
    this.photoHands.unshift({
      cards: cards || [],
      vs: meta && meta.vs || '?',
      score: meta && meta.score || '',
      day: (typeof World !== 'undefined') ? World.day : 0,
      t: Date.now(),
    });
    if (this.photoHands.length > 12) this.photoHands.pop();
  },

  /* ---------- Truco com amigos (código de sala local) ---------- */
  makeRoomCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let s = '';
    for (let i = 0; i < 5; i++) s += chars[Math.floor(Math.random() * chars.length)];
    this.roomCode = s;
    this.roomHost = true;
    return s;
  },

  joinRoom(code) {
    if (!code || code.length < 4) return false;
    this.roomCode = code.toUpperCase();
    this.roomHost = false;
    return true;
  },

  leaveRoom() {
    this.roomCode = null;
    this.roomHost = false;
  },

  /* ---------- Porrinha (mini-jogo) ---------- */
  porrinhaPlay(playerChoice, playerQty) {
    // playerChoice: quantos dedos mostra (0-3)
    // playerQty: quantos acha que soma no total
    // bot joga 0-3, bot chute aleatório enviesado
    const botShow = Math.floor(Math.random() * 4);
    const total = playerChoice + botShow;
    let botGuess = total + (Math.random() < 0.45 ? 0 : (Math.random() < 0.5 ? -1 : 1));
    botGuess = Math.max(0, Math.min(6, botGuess));
    const playerHit = playerQty === total;
    const botHit = botGuess === total;
    let winner = 'draw';
    if (playerHit && !botHit) winner = 'player';
    else if (botHit && !playerHit) winner = 'bot';
    else if (playerHit && botHit) winner = 'draw';
    else winner = 'draw';
    return { botShow, total, botGuess, playerHit, botHit, winner };
  },

  /* ---------- serialização ---------- */
  data() {
    return {
      handReviewOn: this.handReviewOn,
      crazyWeek: this.crazyWeek,
      crazyWeekNum: this.crazyWeekNum,
      nightActive: this.nightActive,
      nightPath: this.nightPath,
      nightIndex: this.nightIndex,
      nightWins: this.nightWins,
      ownBar: this.ownBar,
      ownBarLevel: this.ownBarLevel,
      ownBarCash: this.ownBarCash,
      photoHands: this.photoHands.slice(0, 12),
      roomCode: this.roomCode,
      roomHost: this.roomHost,
    };
  },

  load(d) {
    if (!d) return;
    if (typeof d.handReviewOn === 'boolean') this.handReviewOn = d.handReviewOn;
    this.crazyWeek = d.crazyWeek || null;
    this.crazyWeekNum = d.crazyWeekNum != null ? d.crazyWeekNum : -1;
    this.nightActive = !!d.nightActive;
    this.nightPath = d.nightPath || null;
    this.nightIndex = d.nightIndex || 0;
    this.nightWins = d.nightWins || 0;
    this.ownBar = !!d.ownBar;
    this.ownBarLevel = d.ownBarLevel || 0;
    this.ownBarCash = d.ownBarCash || 0;
    this.photoHands = d.photoHands || [];
    this.roomCode = d.roomCode || null;
    this.roomHost = !!d.roomHost;
  },

  reset() {
    this.handLog = [];
    this.lastHand = null;
    this.handReviewOn = true;
    this.crazyWeek = null;
    this.crazyWeekNum = -1;
    this.nightActive = false;
    this.nightPath = null;
    this.nightIndex = 0;
    this.nightWins = 0;
    this.ownBar = false;
    this.ownBarLevel = 0;
    this.ownBarCash = 0;
    this.photoHands = [];
    this.roomCode = null;
    this.roomHost = false;
  },
};

window.Extra = Extra;
window.CRAZY_RULES = CRAZY_RULES;
window.NIGHT_PATHS = NIGHT_PATHS;
