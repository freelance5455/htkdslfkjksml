/* قالب‌بندی امن پاسخ مشاور: اول همه‌ی متن escape می‌شود، بعد فقط چند ساختار ساده (پررنگ، کد، فهرست، جدول، تیتر، نقل‌قول) ساخته می‌شود. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var ai = (App.ai = App.ai || {});

  function inline(s) {
    var parts = u.esc(s).split(/(`[^`\n]{1,200}`)/g);
    return parts.map(function (p, i) {
      if (i % 2 === 1) return '<code>' + p.slice(1, -1) + '</code>';
      return p.replace(/\*\*([^*\n]{1,300}?)\*\*/g, '<strong>$1</strong>').replace(/__([^_\n]{1,300}?)__/g, '<strong>$1</strong>');
    }).join('');
  }
  function cells(line) {
    var t = line.trim().replace(/^\|/, '').replace(/\|$/, '');
    return t.split('|').map(function (x) { return x.trim(); });
  }
  function isSep(line) { return /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(line); }

  // متن پاسخ را به HTML امن تبدیل می‌کند
  ai.md = function (text) {
    var src = String(text == null ? '' : text).slice(0, 12000).replace(/\r/g, '');
    var lines = src.split('\n');
    var out = [], para = [], list = null, i = 0;
    function flushPara() { if (para.length) { out.push('<p>' + para.map(inline).join('<br>') + '</p>'); para = []; } }
    function flushList() { if (list) { out.push('<' + list.tag + '>' + list.items.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</' + list.tag + '>'); list = null; } }
    while (i < lines.length) {
      var line = lines[i];
      var m;
      if (/^\s*```/.test(line)) {
        flushPara(); flushList();
        var code = [];
        i++;
        while (i < lines.length && !/^\s*```/.test(lines[i])) { code.push(lines[i]); i++; }
        i++;
        out.push('<pre class="md-code"><code>' + u.esc(code.join('\n')) + '</code></pre>');
        continue;
      }
      if (/^\s*\|/.test(line) && i + 1 < lines.length && isSep(lines[i + 1])) {
        flushPara(); flushList();
        var head = cells(line), rows = [];
        i += 2;
        while (i < lines.length && /^\s*\|/.test(lines[i])) { rows.push(cells(lines[i])); i++; }
        var th = '<tr>' + head.map(function (h) { return '<th scope="col">' + inline(h) + '</th>'; }).join('') + '</tr>';
        var tb = rows.map(function (r) { return '<tr>' + head.map(function (_, k) { return '<td>' + inline(r[k] || '') + '</td>'; }).join('') + '</tr>'; }).join('');
        out.push('<div class="table-wrap"><table class="tbl md-tbl"><thead>' + th + '</thead><tbody>' + tb + '</tbody></table></div>');
        continue;
      }
      if (!line.trim()) { flushPara(); flushList(); i++; continue; }
      if ((m = line.match(/^\s*#{1,3}\s+(.+)$/))) { flushPara(); flushList(); out.push('<h4 class="md-h">' + inline(m[1]) + '</h4>'); i++; continue; }
      if (/^\s*(---|\*\*\*)\s*$/.test(line)) { flushPara(); flushList(); out.push('<hr>'); i++; continue; }
      if ((m = line.match(/^\s*>\s?(.*)$/))) { flushPara(); flushList(); out.push('<blockquote>' + inline(m[1]) + '</blockquote>'); i++; continue; }
      if ((m = line.match(/^\s*[-*•]\s+(.+)$/))) {
        flushPara();
        if (!list || list.tag !== 'ul') { flushList(); list = { tag: 'ul', items: [] }; }
        list.items.push(m[1]); i++; continue;
      }
      if ((m = line.match(/^\s*\d{1,3}[.)]\s+(.+)$/))) {
        flushPara();
        if (!list || list.tag !== 'ol') { flushList(); list = { tag: 'ol', items: [] }; }
        list.items.push(m[1]); i++; continue;
      }
      flushList();
      para.push(line);
      i++;
    }
    flushPara(); flushList();
    return out.join('');
  };
})();
