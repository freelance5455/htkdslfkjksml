/**
 * statusMachine.js
 * Enums de status do ciclo de vida — SEPARADOS em dois porque representam
 * coisas diferentes (pedido pelo próprio briefing): o status OPERACIONAL da
 * solicitação (STATUS_SOLICITACAO) e o status FINANCEIRO do pagamento
 * (FINANCIAL_STATUS), que evoluem de forma relacionada mas não idêntica.
 *
 * Todos os status abaixo já têm transição FUNCIONAL implementada nesta etapa,
 * exceto onde comentado como "reservado".
 */
const STATUS_SOLICITACAO = {
  DRAFT: 'DRAFT',
  PUBLISHED: 'PUBLISHED',
  ACCEPTED: 'ACCEPTED',
  TRAVELING: 'TRAVELING',       // profissional iniciou deslocamento
  ARRIVED: 'ARRIVED',           // profissional registrou chegada (GPS)
  CHECKING: 'CHECKING',         // conferência obrigatória em andamento
  IN_PROGRESS: 'IN_PROGRESS',   // conferência respondida "SIM" — serviço em execução
  UNDER_REVIEW: 'UNDER_REVIEW', // profissional finalizou, aguardando confirmação do anfitrião
  DISPUTED: 'DISPUTED',         // divergência aberta — serviço pausado
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED',

  INTERESTED: 'INTERESTED', // reservado — hoje o interesse vive na tabela `interests`, não no status da solicitação
};

const TRANSICOES_ATIVAS = {
  DRAFT: ['PUBLISHED', 'CANCELLED'],
  PUBLISHED: ['ACCEPTED', 'CANCELLED'],
  ACCEPTED: ['TRAVELING', 'CANCELLED'],
  TRAVELING: ['ARRIVED', 'CANCELLED'],
  ARRIVED: ['CHECKING', 'CANCELLED'],
  CHECKING: ['IN_PROGRESS', 'DISPUTED', 'CANCELLED'],
  IN_PROGRESS: ['UNDER_REVIEW', 'DISPUTED', 'CANCELLED'],
  DISPUTED: ['CHECKING', 'IN_PROGRESS', 'UNDER_REVIEW', 'CANCELLED'], // decisão da disputa pode retomar de onde a divergência foi aberta, ou cancelar
  UNDER_REVIEW: ['COMPLETED', 'DISPUTED'],
  COMPLETED: [],
  CANCELLED: [],
};

function transicaoPermitida(de, para){
  return Array.isArray(TRANSICOES_ATIVAS[de]) && TRANSICOES_ATIVAS[de].includes(para);
}

/** Estados financeiros do pagamento — tabela `payments`, uma linha por solicitação. */
const FINANCIAL_STATUS = {
  PENDING: 'PENDING',
  AUTHORIZED: 'AUTHORIZED',
  HELD: 'HELD',
  RELEASE_PENDING: 'RELEASE_PENDING',
  RELEASED: 'RELEASED',
  REFUNDED: 'REFUNDED',
  PARTIALLY_REFUNDED: 'PARTIALLY_REFUNDED',
  DISPUTED: 'DISPUTED',
  CANCELLED: 'CANCELLED',
};

const TRANSICOES_FINANCEIRAS = {
  PENDING: ['AUTHORIZED', 'CANCELLED'],
  AUTHORIZED: ['HELD', 'CANCELLED'],
  HELD: ['RELEASE_PENDING', 'DISPUTED', 'REFUNDED', 'PARTIALLY_REFUNDED'],
  DISPUTED: ['HELD', 'RELEASE_PENDING', 'REFUNDED', 'PARTIALLY_REFUNDED'],
  RELEASE_PENDING: ['RELEASED', 'DISPUTED'],
  RELEASED: [],
  REFUNDED: [],
  PARTIALLY_REFUNDED: ['RELEASE_PENDING'],
  CANCELLED: [],
};

function transicaoFinanceiraPermitida(de, para){
  return Array.isArray(TRANSICOES_FINANCEIRAS[de]) && TRANSICOES_FINANCEIRAS[de].includes(para);
}

const CATEGORIAS_SERVICO = {
  LIMPEZA: 'Limpeza',
  REPAROS: 'Pequenos Reparos',
  ENXOVAL: 'Roupa de cama / Enxoval',
};

const URGENCIAS = ['Programado', 'Hoje', 'Urgente (poucas horas)'];

/**
 * ETAPA — Reclassificação de modalidade de Limpeza.
 * O profissional pode identificar, com evidências (fotos/vídeos), que uma
 * faxina publicada como "Padrão" é na prática "Pesada" (ou "Pós-obra"). A
 * mudança só é aplicada — e só recalcula/cobra a diferença — após decisão do
 * ADMINISTRADOR (nunca automaticamente).
 */
const MODALIDADES_LIMPEZA = ['padrão', 'pesada', 'pós-obra'];

const MOTIVOS_DIVERGENCIA = [
  'Quantidade de quartos diferente',
  'Quantidade de banheiros diferente',
  'Quantidade de camas diferente',
  'Imóvel diferente',
  'Descrição diferente',
  'Tipo de limpeza diferente',
  'Condição do imóvel diferente (mais suja/danificada do que informado)',
  'Limpeza pesada não informada',
  'Serviço adicional não informado',
  'Quantidade de enxoval diferente',
  'Problema de reparo diferente do descrito',
  'Outro',
];

/** ---------- ETAPA 4: severidade da divergência + bloqueios configuráveis ---------- */
const SEVERIDADES_DIVERGENCIA = ['baixa', 'media', 'alta', 'critica'];

/**
 * Configuração de bloqueios — centralizada aqui para não espalhar "regras
 * mágicas" pelo código. Qualquer ajuste de política de negócio (o que passa
 * a bloquear, o que passa a exigir decisão manual) muda só neste objeto.
 */
const BLOQUEIOS_CONFIG = {
  // Severidades que impedem a retomada automática do serviço após decisão —
  // exigem que o administrador desmarque manualmente a retomada sugerida.
  severidadesBloqueiamRetomadaAutomatica: ['alta', 'critica'],
  // Severidades que exigem obrigatoriamente evidência fotográfica ao abrir a divergência.
  severidadesExigemFoto: ['alta', 'critica'],
  // Pós-vistoria (Etapa 4) obrigatória antes de liberar o botão "Finalizar serviço".
  posVistoriaObrigatoria: true,
};
