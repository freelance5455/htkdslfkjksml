import { formatMoney } from "./shared-utils.js";
// =====================================================
// NetEarn Pro
// SUBMIT TASK
// FINAL CLEAN VERSION
// =====================================================
//
// Features:
// 1. Load Task
// 2. Direct Task Image from taskImage
// 3. Screenshot Preview
// 4. Screenshot Upload to Cloudinary
// 5. Firebase Storage NOT USED
// 6. Save proofImageUrl to Firestore
// 7. One User = One Task
// 8. Pending Submission
// 9. Social + Micro Job Support
// 10. Typing + Photo Editing + Form Fill Support
// =====================================================


// =====================================================
// FIREBASE
// =====================================================

import {
    auth,
    db
} from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";


import {
    onAuthStateChanged
} from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    collection,
    query,
    where,
    getDocs,
    getDoc,
    doc,
    addDoc,
    serverTimestamp
} from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// CLOUDINARY CONFIG
// =====================================================

const CLOUDINARY_CLOUD_NAME =
    "jqwnows8";


const CLOUDINARY_UPLOAD_PRESET =
    "neteearn_upload";


const CLOUDINARY_UPLOAD_URL =
    `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;


const MAX_SCREENSHOT_SIZE =
    5 * 1024 * 1024;


// =====================================================
// URL PARAMETER
// =====================================================

const urlParams =
    new URLSearchParams(
        window.location.search
    );


const taskId =
    urlParams.get(
        "taskId"
    );


// =====================================================
// ELEMENTS
// =====================================================

const messageBox =
    document.getElementById(
        "message"
    );


const loadingBox =
    document.getElementById(
        "loading"
    );


const taskCard =
    document.getElementById(
        "taskCard"
    );


const submissionCard =
    document.getElementById(
        "submissionCard"
    );


const taskImageBox =
    document.getElementById(
        "taskImageBox"
    );


const taskName =
    document.getElementById(
        "taskName"
    );


const taskDescription =
    document.getElementById(
        "taskDescription"
    );


const taskReward =
    document.getElementById(
        "taskReward"
    );


const taskCategory =
    document.getElementById(
        "taskCategory"
    );


const taskLink =
    document.getElementById(
        "taskLink"
    );


const screenshotInput =
    document.getElementById(
        "screenshotInput"
    );


const previewBox =
    document.getElementById(
        "previewBox"
    );


const previewImage =
    document.getElementById(
        "previewImage"
    );


const removeImageBtn =
    document.getElementById(
        "removeImageBtn"
    );


const proofText =
    document.getElementById(
        "proofText"
    );


const submitBtn =
    document.getElementById(
        "submitBtn"
    );


const uploadStatus =
    document.getElementById(
        "uploadStatus"
    );


// =====================================================
// STATE
// =====================================================

let currentUser =
    null;


let currentTask =
    null;


let selectedScreenshot =
    null;


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "error"
) {

    if (!messageBox) {

        return;

    }


    messageBox.textContent =
        text;


    messageBox.className =
        "message " +
        type;


    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });

}


// =====================================================
// HIDE MESSAGE
// =====================================================

function hideMessage() {

    if (!messageBox) {

        return;

    }


    messageBox.textContent =
        "";


    messageBox.className =
        "message";

}


// =====================================================
// LOADING
// =====================================================

function showLoading(
    show
) {

    if (!loadingBox) {

        return;

    }


    loadingBox.style.display =
        show
            ? "block"
            : "none";

}


// =====================================================
// TEXT ESCAPE
// =====================================================

function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// MONEY
// =====================================================
// =====================================================
// CATEGORY
// =====================================================

function normalizeCategory(
    category
) {

    const value =
        String(
            category ||
            ""
        )
        .trim()
        .toLowerCase();


    if (

        value === "social" ||
        value === "social task" ||
        value === "socialtask"

    ) {

        return "Social";

    }


    if (

        value === "micro job" ||
        value === "microjob" ||
        value === "micro_job"

    ) {

        return "Micro Job";

    }


    if (
        value === "typing"
    ) {

        return "Typing";

    }


    if (

        value === "photo editing" ||
        value === "photo_editing"

    ) {

        return "Photo Editing";

    }


    if (

        value === "form fill" ||
        value === "form filling" ||
        value === "form_fill" ||
        value === "form-fill"

    ) {

        return "Form Fill";

    }


    return category ||
        "Task";

}


// =====================================================
// LOAD TASK
// =====================================================

async function loadTask() {

    if (!taskId) {

        showMessage(
            "❌ Task ID পাওয়া যায়নি।"
        );

        return;

    }


    showLoading(
        true
    );


    try {

        // =============================================
        // TASK DOCUMENT
        // =============================================

        const taskRef =
            doc(
                db,
                "tasks",
                taskId
            );


        // ⚡ Task document and business settings are independent.
        // Start both reads together so the page does not wait on them sequentially.
        const settingsPromise =
            getBusinessSettings({ force: true });

        const [taskSnap, businessSettings] =
            await Promise.all([
                getDoc(taskRef),
                settingsPromise
            ]);


        if (
            !taskSnap.exists()
        ) {

            throw new Error(
                "TASK_NOT_FOUND"
            );

        }


        currentTask = {

            id:
                taskSnap.id,

            ...taskSnap.data()

        };

        const configuredReward = getConfiguredTaskReward(currentTask, businessSettings);
        if (configuredReward >= 0 && ["typing", "photo editing", "editing", "form fill", "form_fill"].some(type => String(currentTask.category || currentTask.taskType || "").toLowerCase().includes(type))) {
            currentTask.reward = configuredReward;
        }


        // =============================================
        // ACTIVE CHECK
        // =============================================

        if (
            currentTask.active !==
            true
        ) {

            showMessage(
                "⚠️ এই Task বর্তমানে Active নেই।"
            );

            return;

        }


        // =============================================
        // CATEGORY
        // =============================================

        const category =
            normalizeCategory(

                currentTask.category ||
                currentTask.taskCategory ||
                currentTask.taskType ||
                ""

            );


        // =============================================
        // TASK NAME
        // =============================================

        const name =
            currentTask.name ||
            currentTask.title ||
            currentTask.taskName ||
            currentTask.taskTitle ||
            "Task";


        // =============================================
        // DESCRIPTION
        // =============================================

        const description =
            currentTask.description ||
            "Complete this task and submit your proof.";


        // =============================================
        // REWARD
        // =============================================

        const reward =
            Number(

                currentTask.reward ??
                currentTask.taskReward ??
                0

            );


        // =============================================
        // DISPLAY
        // =============================================

        if (taskName) {

            taskName.textContent =
                name;

        }


        if (taskDescription) {

            taskDescription.textContent =
                description;

        }


        if (taskReward) {

            taskReward.textContent =
                "৳" +
                formatMoney(
                    reward
                );

        }


        if (taskCategory) {

            taskCategory.textContent =
                category;

        }


        // =============================================
        // TASK IMAGE
        // =============================================

        loadTaskImage(
            currentTask
        );


        // =============================================
        // TASK LINK
        // =============================================

        const link =
            currentTask.link ||
            currentTask.taskLink ||
            "";


        if (
            taskLink &&
            link
        ) {

            taskLink.href =
                link;

            taskLink.style.display =
                "flex";

        }

        else if (taskLink) {

            taskLink.style.display =
                "none";

        }


        // =============================================
        // SHOW TASK CARD
        // =============================================

        if (taskCard) {

            taskCard.style.display =
                "block";

        }


        // =============================================
        // CHECK EXISTING SUBMISSION
        // =============================================

        const existingSubmission =
            await findExistingSubmission(

                currentUser.uid,

                taskId

            );


        if (
            existingSubmission
        ) {

            showExistingSubmission(
                existingSubmission
            );

            return;

        }


        // =============================================
        // SHOW SUBMISSION CARD
        // =============================================

        if (submissionCard) {

            submissionCard.style.display =
                "block";

        }

    }


    catch (error) {

        console.error(
            "❌ Load Task Error:",
            error
        );


        if (
            error.message ===
            "TASK_NOT_FOUND"
        ) {

            showMessage(
                "❌ এই Task পাওয়া যায়নি।"
            );

        }

        else {

            showMessage(
                "❌ Task load করা যায়নি। আবার চেষ্টা করুন।"
            );

        }

    }


    finally {

        showLoading(
            false
        );

    }

}


// =====================================================
// TASK IMAGE
// =====================================================

function loadTaskImage(
    task
) {

    if (!taskImageBox) {

        return;

    }


    // IMPORTANT:
    // Admin Create/Edit Task-এর
    // taskImage Direct URL এখান থেকেই আসবে.

    const imageUrl =
        task.taskImage ||
        task.imageUrl ||
        task.image ||
        task.sourceImage ||
        "";


    if (!imageUrl) {

        taskImageBox.innerHTML = `

            <div
                class="task-image-placeholder"
            >

                📱

                <span>
                    Task Image
                </span>

            </div>

        `;

        return;

    }


    taskImageBox.innerHTML = `

        <img
            src="${escapeHTML(imageUrl)}"
            alt="Task Image"
        >

    `;


    const image =
        taskImageBox.querySelector(
            "img"
        );


    if (image) {

        image.onerror =
            () => {

                taskImageBox.innerHTML = `

                    <div
                        class="task-image-placeholder"
                    >

                        🖼️

                        <span>
                            Task Image Load করা যায়নি
                        </span>

                    </div>

                `;

            };

    }

}


// =====================================================
// FIND EXISTING SUBMISSION
// =====================================================

async function findExistingSubmission(
    uid,
    taskId
) {

    const submissionQuery =
        query(

            collection(
                db,
                "taskSubmissions"
            ),

            where(
                "userUid",
                "==",
                uid
            ),

            where(
                "taskId",
                "==",
                taskId
            )

        );


    const submissionSnap =
        await getDocs(
            submissionQuery
        );


    if (
        submissionSnap.empty
    ) {

        return null;

    }


    const submissionDoc =
        submissionSnap.docs[0];


    return {

        id:
            submissionDoc.id,

        ...submissionDoc.data()

    };

}


// =====================================================
// EXISTING SUBMISSION
// =====================================================

function showExistingSubmission(
    submission
) {

    if (submissionCard) {

        submissionCard.style.display =
            "none";

    }


    const status =
        String(

            submission.status ||
            "pending"

        )
        .trim()
        .toLowerCase();


    if (

        status === "approved" ||
        status === "completed"

    ) {

        showMessage(

            "✅ আপনি এই Task ইতিমধ্যে Completed করেছেন।",

            "success"

        );

        return;

    }


    if (
        status === "rejected"
    ) {

        showMessage(
            "❌ এই Task-এর আপনার আগের submission Rejected হয়েছে। এই Task আবার submit করা যাবে না।"
        );

        return;

    }


    showMessage(
        "⏳ আপনার এই Task-এর Proof ইতিমধ্যে জমা দেওয়া হয়েছে। Admin Review করার অপেক্ষায় আছে।"
    );

}


// =====================================================
// SCREENSHOT CHANGE
// =====================================================

screenshotInput?.addEventListener(
    "change",
    handleScreenshotSelect
);


// =====================================================
// HANDLE SCREENSHOT
// =====================================================

function handleScreenshotSelect(
    event
) {

    hideMessage();


    const file =
        event.target.files?.[0];


    if (!file) {

        return;

    }


    // =============================================
    // TYPE CHECK
    // =============================================

    const allowedTypes = [

        "image/jpeg",
        "image/png",
        "image/webp"

    ];


    if (
        !allowedTypes.includes(
            file.type
        )
    ) {

        showMessage(
            "❌ শুধু JPG, PNG অথবা WEBP Screenshot ব্যবহার করুন।"
        );


        clearSelectedScreenshot();

        return;

    }


    // =============================================
    // SIZE CHECK
    // =============================================

    if (
        file.size >
        MAX_SCREENSHOT_SIZE
    ) {

        showMessage(
            "❌ Screenshot 5MB-এর বেশি হতে পারবে না।"
        );


        clearSelectedScreenshot();

        return;

    }


    // =============================================
    // SAVE FILE
    // =============================================

    selectedScreenshot =
        file;


    // =============================================
    // PREVIEW
    // =============================================

    const objectUrl =
        URL.createObjectURL(
            file
        );


    if (previewImage) {

        previewImage.src =
            objectUrl;

    }


    if (previewBox) {

        previewBox.style.display =
            "block";

    }


    setUploadStatus(
        "",
        false
    );

}


// =====================================================
// REMOVE SCREENSHOT
// =====================================================

removeImageBtn?.addEventListener(

    "click",

    () => {

        clearSelectedScreenshot();

        hideMessage();

    }

);


// =====================================================
// CLEAR SCREENSHOT
// =====================================================

function clearSelectedScreenshot() {

    selectedScreenshot =
        null;


    if (screenshotInput) {

        screenshotInput.value =
            "";

    }


    if (previewImage) {

        previewImage.src =
            "";

    }


    if (previewBox) {

        previewBox.style.display =
            "none";

    }

}


// =====================================================
// UPLOAD STATUS
// =====================================================

function setUploadStatus(
    text,
    show = true
) {

    if (!uploadStatus) {

        return;

    }


    uploadStatus.textContent =
        text;


    uploadStatus.style.display =
        show
            ? "block"
            : "none";

}


// =====================================================
// CLOUDINARY UPLOAD
// =====================================================

async function uploadScreenshot(
    file
) {

    if (!file) {

        throw new Error(
            "NO_SCREENSHOT"
        );

    }


    setUploadStatus(
        "⏳ Screenshot upload হচ্ছে..."
    );


    const formData =
        new FormData();


    // =============================================
    // FILE
    // =============================================

    formData.append(
        "file",
        file
    );


    // =============================================
    // UNSIGNED PRESET
    // =============================================

    formData.append(
        "upload_preset",
        CLOUDINARY_UPLOAD_PRESET
    );


    // =============================================
    // UPLOAD
    // =============================================

    const response =
        await fetch(

            CLOUDINARY_UPLOAD_URL,

            {

                method:
                    "POST",

                body:
                    formData

            }

        );


    if (
        !response.ok
    ) {

        let errorText =
            "";


        try {

            errorText =
                await response.text();

        }

        catch {

            errorText =
                "";

        }


        console.error(

            "❌ Cloudinary Upload Error:",

            errorText

        );


        throw new Error(
            "CLOUDINARY_UPLOAD_FAILED"
        );

    }


    const result =
        await response.json();


    console.log(
        "✅ Cloudinary Response:",
        result
    );

// =============================================
    // URL CHECK
    // =============================================

    if (
        !result.secure_url
    ) {

        throw new Error(
            "CLOUDINARY_URL_MISSING"
        );

    }


    setUploadStatus(
        "✅ Screenshot upload সম্পন্ন হয়েছে।"
    );


    // =============================================
    // NORMALIZED RESULT
    // =============================================

    return {

        image_url:
            result.secure_url,

        image_id:
            result.public_id ||
            "",

        page_url:
            result.secure_url

    };

}


// =====================================================
// SUBMIT BUTTON
// =====================================================

submitBtn?.addEventListener(
    "click",
    submitProof
);


// =====================================================
// SUBMIT PROOF
// =====================================================

async function submitProof() {

    hideMessage();


    // =================================================
    // AUTH
    // =================================================

    if (!currentUser) {

        showMessage(
            "🔒 Login পাওয়া যায়নি। আবার Login করুন।"
        );

        return;

    }


    // =================================================
    // TASK
    // =================================================

    if (!currentTask) {

        showMessage(
            "❌ Task data পাওয়া যায়নি।"
        );

        return;

    }


    // =================================================
    // SCREENSHOT
    // =================================================

    if (!selectedScreenshot) {

        showMessage(
            "📸 প্রথমে Screenshot নির্বাচন করুন।"
        );

        return;

    }


    // =================================================
    // NOTE
    // =================================================

    const note =
        proofText?.value.trim() ||
        "";


    // =================================================
    // DISABLE BUTTON
    // =================================================

    if (submitBtn) {

        submitBtn.disabled =
            true;

        submitBtn.textContent =
            "⏳ Uploading...";

    }


    try {

        // =================================================
        // CHECK EXISTING SUBMISSION AGAIN
        // =================================================

        const existingSubmission =
            await findExistingSubmission(

                currentUser.uid,

                taskId

            );


        if (
            existingSubmission
        ) {

            showExistingSubmission(
                existingSubmission
            );

            return;

        }


        // =================================================
        // VERIFY TASK AGAIN
        // =================================================

        const taskRef =
            doc(
                db,
                "tasks",
                taskId
            );


        const taskSnap =
            await getDoc(
                taskRef
            );


        if (
            !taskSnap.exists()
        ) {

            throw new Error(
                "TASK_NOT_FOUND"
            );

        }


        const latestTask =
            taskSnap.data();


        if (
            latestTask.active !==
            true
        ) {

            throw new Error(
                "TASK_INACTIVE"
            );

        }


        // =================================================
        // UPLOAD + SETTINGS + USER DATA
        // =================================================

        // These operations no longer need to block one another.
        // Keep the user read non-fatal, matching the previous behavior.
        const userRef =
            doc(
                db,
                "users",
                currentUser.uid
            );

        const userDataPromise =
            getDoc(userRef).catch(userError => {
                console.warn(
                    "⚠️ User data load failed:",
                    userError
                );
                return null;
            });

        const [uploadResult, businessSettings, userSnap] =
            await Promise.all([
                uploadScreenshot(selectedScreenshot),
                getBusinessSettings({ force: true }),
                userDataPromise
            ]);

        const proofImageUrl =
            uploadResult.image_url;


        // =================================================
        // REWARD
        // =================================================

        // Central Admin-controlled reward.
        // For Typing / Photo Editing / Form Fill, the current
        // settings/main value is authoritative at submission time.
        const reward = getConfiguredTaskReward(latestTask, businessSettings);


        // =================================================
        // CATEGORY
        // =================================================

        const category =
            normalizeCategory(

                latestTask.category ||
                latestTask.taskCategory ||
                latestTask.taskType ||
                ""

            );


        // =================================================
        // TASK NAME
        // =================================================

        const taskNameValue =
            latestTask.name ||
            latestTask.title ||
            latestTask.taskName ||
            latestTask.taskTitle ||
            "Task";


        // =================================================
        // USER DATA
        // =================================================

        let userData =
            {};

        if (
            userSnap?.exists()
        ) {

            userData =
                userSnap.data();

        }

        }


        // =================================================
        // CUSTOM NETEARN USER ID
        // =================================================

        const userId =
            userData.userId ||
            "";


        // =================================================
        // SUBMISSION DATA
        // =================================================

        const submissionData = {

            userUid:
                currentUser.uid,

            userId:
                userId,

            userEmail:
                currentUser.email ||
                userData.email ||
                "",

            userName:
                userData.name ||
                userData.username ||
                currentUser.displayName ||
                "",

            taskId:
                taskId,

            taskName:
                taskNameValue,

            category:
                category,

            reward:
                reward,

            // =========================================
            // CLOUDINARY PROOF
            // =========================================

            proofImageUrl:
                proofImageUrl,

            proofImageId:
                uploadResult.image_id ||
                "",

            proofPageUrl:
                uploadResult.page_url ||
                "",

            proofNote:
                note,

            // =========================================
            // STATUS
            // =========================================

            status:
                "pending",

            submittedAt:
                serverTimestamp()

        };


        console.log(
            "📦 Submission:",
            submissionData
        );


        // =================================================
        // SAVE FIRESTORE
        // =================================================

        const submissionRef =
            await addDoc(

                collection(
                    db,
                    "taskSubmissions"
                ),

                submissionData

            );


        console.log(

            "✅ Submission Created:",

            submissionRef.id

        );

        // =================================================
        // SUCCESS
        // =================================================

        if (submitBtn) {

            submitBtn.disabled =
                true;

            submitBtn.textContent =
                "✅ Proof Submitted";

        }


        clearSelectedScreenshot();


        if (proofText) {

            proofText.value =
                "";

        }


        setUploadStatus(
            "",
            false
        );


        if (submissionCard) {

            submissionCard.style.display =
                "none";

        }


        showMessage(

            "✅ আপনার Task Proof সফলভাবে জমা হয়েছে.\n\n" +

            "Status: Pending Review\n\n" +

            "Admin আপনার Screenshot যাচাই করার পর Reward approve করবেন।",

            "success"

        );

    }


    catch (error) {

        console.error(

            "❌ Submit Proof Error:",

            error

        );


        setUploadStatus(
            "",
            false
        );


        // =============================================
        // TASK NOT FOUND
        // =============================================

        if (
            error.message ===
            "TASK_NOT_FOUND"
        ) {

            showMessage(
                "❌ এই Task আর পাওয়া যাচ্ছে না।"
            );

        }


        // =============================================
        // TASK INACTIVE
        // =============================================

        else if (
            error.message ===
            "TASK_INACTIVE"
        ) {

            showMessage(
                "⚠️ এই Task বর্তমানে Active নেই।"
            );

        }


        // =============================================
        // NO SCREENSHOT
        // =============================================

        else if (
            error.message ===
            "NO_SCREENSHOT"
        ) {

            showMessage(
                "📸 প্রথমে Screenshot নির্বাচন করুন।"
            );

        }


        // =============================================
        // CLOUDINARY UPLOAD FAILED
        // =============================================

        else if (
            error.message ===
            "CLOUDINARY_UPLOAD_FAILED"
        ) {

            showMessage(

                "❌ Screenshot upload করা যায়নি।\n\n" +

                "Cloudinary Cloud Name এবং Upload Preset ঠিক আছে কিনা পরীক্ষা করুন।"

            );

        }


        // =============================================
        // CLOUDINARY URL MISSING
        // =============================================

        else if (
            error.message ===
            "CLOUDINARY_URL_MISSING"
        ) {

            showMessage(

                "❌ Screenshot upload হয়েছে, কিন্তু Image URL পাওয়া যায়নি। আবার চেষ্টা করুন।"

            );

        }


        // =============================================
        // FIRESTORE / OTHER ERROR
        // =============================================

        else {

            showMessage(

                "❌ Proof Submit করা যায়নি।\n\n" +

                (
                    error.message ||
                    "Unknown error"
                )

            );

        }

    }


    finally {

        if (

            submitBtn &&

            submitBtn.textContent !==
            "✅ Proof Submitted"

        ) {

            submitBtn.disabled =
                false;

            submitBtn.textContent =
                "📤 Submit Proof";

        }

    }

}


// =====================================================
// AUTH STATE
// =====================================================

onAuthStateChanged(

    auth,

    async user => {

        console.log(

            "🔥 Submit Task Auth:",

            user?.uid ||
            "SIGNED OUT"

        );


        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        currentUser =
            user;


        await loadTask();

    }

);


// =====================================================
// PAGE READY
// =====================================================

console.log(
    "======================================"
);


console.log(
    "📋 NetEarn Pro Submit Task"
);


console.log(
    "📸 Screenshot Proof System Ready"
);


console.log(
    "☁️ Cloudinary Upload Enabled"
);


console.log(
    "🔥 Firebase Storage NOT Used"
);


console.log(
    "📝 Firestore Proof URL System Ready"
);


console.log(
    "🔒 One User = One Task"
);


console.log(
    "⏳ Pending Submission Ready"
);


console.log(
    "======================================"
);