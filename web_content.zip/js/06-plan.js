/* برنامه: هفتگی، کارهای ثابت، کلاس‌ها، برنامه‌ی خودکار، پایبندی، و تجزیه‌گر متن فارسی (نسخه‌ی پاک‌سازی‌شده‌ی قدیمی). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var store = App.store;
  var st = App.study;
  var pl = (App.plan = {});
  var S = function () { return App.S; };
  var WDM = u.WD;
  var NW = { 'یک': 1, 'یه': 1, 'دو': 2, 'سه': 3, 'چهار': 4, 'پنج': 5, 'شش': 6, 'هفت': 7, 'هشت': 8, 'نه': 9, 'ده': 10 };
  var DAYX = { 'شنبه': 6, 'یکشنبه': 0, 'یک‌شنبه': 0, 'دوشنبه': 1, 'دو‌شنبه': 1, 'سه‌شنبه': 2, 'سهشنبه': 2, 'چهارشنبه': 3, 'پنجشنبه': 4, 'پنج‌شنبه': 4, 'جمعه': 5 };
  var DNR = /(یکشنبه|دوشنبه|سهشنبه|چهارشنبه|پنجشنبه|جمعه|شنبه)/g;
  var DN = { 'یکشنبه': 0, 'دوشنبه': 1, 'سهشنبه': 2, 'چهارشنبه': 3, 'پنجشنبه': 4, 'جمعه': 5, 'شنبه': 6 };
  var VL = { log: '⏱ ثبت مطالعه/کلاس', todo: '✅ کار امروز', bl: '📌 عقب‌افتادگی', wk: '🎯 نقطه ضعف', jr: '📓 دفترچه', busy: '🗓 کار ثابت', exam: '📝 آزمون', goal: '🎯 هدف روزانه', wake: '⏰ ساعت بیدار شدن', sleep: '😴 ساعت خواب', tstart: '⏱ شروع تایمر', tstop: '⏹ پایان تایمر', ex2: '📆 آزمون پیش‌رو', wp: '🗓 بلوک برنامه هفتگی' };
  pl.VL = VL;
  var p2 = u.p2;
  function fd(t) { return u.ascii(t).replace(/,/g, '،'); }
  function allS() { return D.allSubjects(); }
  function isCls(t) { return /کلاس|مدرسه|آموزشگاه/.test(t || ''); }
  pl.isCls = isCls;

  // ---- کارهای ثابت ----
  pl.busyOn = function (b, iso) {
    if (b.r === 'all') return true;
    if (b.r === 'today') return b.d === iso;
    if (/^[0-6]$/.test(b.r)) return +b.r === new Date(iso + 'T12:00:00').getDay();
    return false;
  };
  pl.busyToday = function () {
    var today = u.todayISO();
    return S().busy.filter(function (b) { return pl.busyOn(b, today); })
      .map(function (b) { return { id: b.id, t: b.t, s: u.tmin(b.s), e: u.tmin(b.e), s0: b.s, e0: b.e, r: b.r, raw: b }; })
      .sort(function (a, b) { return a.s - b.s; });
  };
  pl.RL = function (b) { return b.r === 'all' ? 'هر روز' : b.r === 'today' ? 'فقط امروز' : 'هر ' + WDM[+b.r]; };

  // ---- برنامه‌ی هفتگی ----
  pl.todayWP = function () {
    var d = new Date().getDay();
    return S().wp.filter(function (x) { return x.day === d; }).sort(function (a, b) { return u.tmin(a.s0) - u.tmin(b.s0); });
  };
  pl.bkey = function (x) { return x.day + '|' + x.s0 + '|' + x.t; };
  pl.wdTick = function (x) {
    var d = u.todayISO();
    S().wd = S().wd || {};
    var D1 = S().wd[d] = S().wd[d] || {}, k = pl.bkey(x);
    if (D1[k] === 1) delete D1[k]; else D1[k] = 1;
  };
  pl.adh = function (iso) {
    var day = new Date(iso + 'T12:00:00').getDay();
    var P = S().wp.filter(function (x) { return x.day === day && x.k === 'study'; });
    if (!P.length) return null;
    var Dd = (S().wd || {})[iso] || {};
    var n = P.filter(function (x) { return Dd[pl.bkey(x)] === 1; }).length;
    return { n: n, t: P.length, p: Math.round(n / P.length * 100) };
  };
  pl.adh7 = function () {
    var n = 0, t = 0;
    for (var i = 0; i < 7; i++) {
      var a = pl.adh(u.addDays(u.todayISO(), -i));
      if (a) { n += a.n; t += a.t; }
    }
    return t ? Math.round(n / t * 100) : null;
  };
  pl.missedToday = function () {
    var Dd = (S().wd || {})[u.todayISO()] || {}, n = u.minutesNow();
    return pl.todayWP().filter(function (x) { return x.k === 'study' && u.tmin(x.e0) < n && !Dd[pl.bkey(x)]; });
  };
  pl.moveMissed = function () {
    var M = pl.missedToday(), today = u.todayISO();
    S().wd = S().wd || {};
    var Dd = S().wd[today] = S().wd[today] || {};
    M.forEach(function (x) {
      Dd[pl.bkey(x)] = 2;
      var sj = D.subjectFromText(x.t);
      sj = allS().indexOf(sj) >= 0 ? sj : (D.subjects(S().mg)[0] || { name: '' }).name;
      S().bl.push({ id: u.uid(), s: sj, t: u.clip(x.t, 100) + ' (از برنامه‌ی امروز)', u: 0, ok: 0, d: today });
    });
    return M.length;
  };

  // ---- کلاس‌ها ----
  pl.clsKey = function (b) { return b.t + '|' + b.s0; };
  pl.classesToday = function () { return pl.busyToday().filter(function (b) { return isCls(b.t); }); };
  pl.clsDefer = function (b) {
    var d = u.todayISO();
    S().cl = S().cl || {};
    var Dd = S().cl[d] = S().cl[d] || {}, k = pl.clsKey(b);
    if (Dd[k] === 1 || Dd[k] === 2) return false;
    Dd[k] = 2;
    var sj = D.subjectFromText(b.t);
    sj = allS().indexOf(sj) >= 0 ? sj : (D.subjects(S().mg)[0] || { name: '' }).name;
    S().bl.push({ id: u.uid(), s: sj, t: 'دیدن ' + b.t + ' (' + b.s0 + ')', u: 1, ok: 0, d: d, ck: k });
    return true;
  };
  pl.classTick = function (i) {
    var b = pl.classesToday()[i];
    if (!b) return null;
    var d = u.todayISO();
    S().cl = S().cl || {};
    var Dd = S().cl[d] = S().cl[d] || {}, k = pl.clsKey(b), was = Dd[k];
    if (was === 1) {
      delete Dd[k];
      S().logs = S().logs.filter(function (l) { return !(l.clsk === k && l.d === d); });
      return 'off';
    }
    if (was === 2) S().bl = S().bl.filter(function (x) { return x.ck !== k; });
    Dd[k] = 1;
    var sj = D.subjectFromText(b.t);
    sj = allS().indexOf(sj) >= 0 ? sj : (D.subjects(S().mg)[0] || { name: '' }).name;
    S().logs.push({ id: u.uid(), d: d, g: S().mg, s: sj, c: 0, m: Math.max(0, u.tmin(b.e0) - u.tmin(b.s0)), t: 0, k: 'c', clsk: k });
    return 'on';
  };
  pl.classMiss = function (i) {
    var b = pl.classesToday()[i];
    if (!b) return false;
    return pl.clsDefer(b);
  };

  // ---- برنامه‌ی خودکار (دور کارهای ثابت، با اولویت آزمون/عقب‌افتادگی/ضعف) ----
  pl.lastAuto = [];
  pl.planAuto = function () {
    pl.lastAuto = [];
    var W = pl.todayWP();
    if (W.some(function (x) { return x.k === 'study'; })) return W.map(function (x) { return u.hm(u.tmin(x.s0)) + ' تا ' + u.hm(u.tmin(x.e0)) + '   ' + (x.k === 'study' ? '📖 ' : '🗓 ') + x.t; }).join('\n');
    var nm = u.minutesNow(), wake = u.tmin(S().wake || '06:30'), sl = u.tmin(S().sleep || '23:00');
    var from = Math.max(wake, Math.ceil((nm + 5) / 5) * 5);
    if (from >= sl - 30) return 'امروز زمان آزاد باقی نمانده. فردا زودتر شروع کن 🌙';
    var B = pl.busyToday(), done = st.dayStat(u.todayISO()).s;
    var rem = Math.max(S().goal - done, 0);
    if (!rem) return '🎉 هدف امروز کامل شده.';
    var A = [], Bx = B.map(function (b) { return allS().find(function (x) { return b.t.indexOf(x) >= 0; }); }).filter(Boolean);
    Bx.forEach(function (x) { if (A.indexOf(x) < 0) A.push(x); });
    var weakNames = st.weakRank().map(function (x) { return x.s; });
    var L = []; A.concat(weakNames).forEach(function (x) { if (L.indexOf(x) < 0) L.push(x); });
    var free = [], cur = from;
    B.forEach(function (b) {
      if (b.e <= cur) return;
      if (b.s > cur) free.push([cur, Math.min(b.s, sl)]);
      cur = Math.max(cur, b.e);
    });
    if (cur < sl) free.push([cur, sl]);
    var it = B.filter(function (b) { return b.e > from; }).map(function (b) { return { s: b.s, e: b.e, x: '🗓 ' + b.t }; });
    var WP = S().wk.filter(function (x) { return !x.ok; }).sort(function (a, b) { return b.v - a.v || a.m - b.m; });
    var auto = st.autoWeak().slice(0, 3).map(function (a) { return { s: a.s, t: st.chName(a.g, a.s, a.c) + ' (دقت ' + a.p + '٪)', v: 2, m: 30 }; });
    WP = WP.concat(auto);
    var BL = S().bl.filter(function (x) { return !x.ok; }).sort(function (a, b) { return b.u - a.u; });
    var EXI = [];
    if (App.exam) {
      App.exam.upcoming().slice(0, 2).forEach(function (e) {
        if (App.exam.days(e) <= 45) (e.r || []).forEach(function (r) {
          st.covOf(r).miss.forEach(function (c) { EXI.push({ s: r.s, c: c, g: r.g, n: e.n, d: App.exam.days(e) }); });
        });
      });
    }
    var PL = [];
    if (EXI.length) PL.push('e');
    if (BL.length) PL.push('b');
    if (WP.length) PL.push('w');
    PL.push('n');
    var i = 0, j = 0, k = 0, q = 0, ee = 0;
    free.forEach(function (fr) {
      var t = fr[0], z = fr[1];
      while (rem > 0 && z - t >= 30) {
        var len = Math.min(45, rem, z - t), tx;
        var ty = PL[i % PL.length];
        if (ty === 'e') { var ex = EXI[ee++ % EXI.length]; tx = ex.s + ' — آمادگی «' + ex.n + '» (' + u.fa(ex.d) + ' روز مانده): ' + st.chName(ex.g, ex.s, ex.c); }
        else if (ty === 'b') { var b = BL[q++ % BL.length]; tx = b.s + ' — جبران عقب‌افتادگی: ' + b.t; }
        else if (ty === 'w') { var w = WP[j++ % WP.length]; tx = w.s + ' — ضعف: ' + w.t + ' (تمرین هدفمند + ۱۰ تست)'; }
        else { var y = L[k++ % L.length] || 'درس دلخواه'; tx = y + ' — ' + (A.indexOf(y) >= 0 ? 'مرور کلاس امروز + تست' : 'تست و رفع اشکال'); }
        it.push({ s: t, e: t + len, x: '📖 ' + tx });
        rem -= len; i++; t += len;
        if (rem > 0 && z - t >= 40) { it.push({ s: t, e: t + 10, x: '☕ استراحت' }); t += 10; }
      }
    });
    it.sort(function (a, b) { return a.s - b.s; });
    pl.lastAuto = it;
    return it.map(function (x) { return u.hm(x.s) + ' تا ' + u.hm(x.e) + '   ' + x.x; }).join('\n') + (rem > 0 ? '\n⚠️ ' + u.fa(rem) + ' دقیقه از هدف جا نشد؛ هدف را کمتر کن یا زمان آزاد بیشتری بگذار.' : '');
  };
  // بلوک فعلی طبق برنامه (هفتگی یا خودکار)
  pl.curBlock = function () {
    var m0 = u.minutesNow();
    var w0 = pl.todayWP().find(function (x) { return u.tmin(x.s0) <= m0 && m0 < u.tmin(x.e0); });
    if (w0) return w0.t;
    pl.planAuto();
    var b = pl.lastAuto.find(function (x) { return x.s <= m0 && m0 < x.e; });
    return b ? b.x : null;
  };
  pl.wpText = function () { return pl.todayWP().map(function (x) { return x.s0 + ' تا ' + x.e0 + ' ' + x.t; }).join('. '); };

  // ---- تجزیه‌ی متن فارسی ----
  function pmin(x) {
    var m = 0, f;
    if (f = x.match(/(\d+(?:\.\d+)?)\s*ساعت/)) m += +f[1] * 60;
    else if (f = x.match(/(یک|یه|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده)\s*ساعت/)) m += NW[f[1]] * 60;
    if (/نیم\s*ساعت|ساعت\s*و\s*نیم/.test(x)) m += 30;
    if (f = x.match(/(\d+)\s*دقیقه/)) m += +f[1];
    return Math.round(m);
  }
  pl.pmin = pmin;
  function hh(h, x) {
    h = +h;
    if (/صبح/.test(x)) return h % 12;
    if (/ظهر/.test(x)) return h < 6 ? h + 12 : h;
    if (/عصر|بعدازظهر|شب/.test(x)) return h < 12 ? h + 12 : h;
    return h;
  }
  pl.jparse = function (x) {
    var n = new Date(), cj = u.g2j(n.getFullYear(), n.getMonth() + 1, n.getDate());
    var jy, jm, jd, m = x.match(/(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
    if (m) { jy = +m[1]; jm = +m[2]; jd = +m[3]; }
    else {
      m = x.match(/(\d{1,2})\s*(فروردین|اردیبهشت|خرداد|تیر|مرداد|شهریور|مهر|آبان|آذر|دی|بهمن|اسفند)(?![؀-ۿ])(?:\s*(\d{4}))?/);
      if (!m) return null;
      jd = +m[1]; jm = u.JM.indexOf(m[2]) + 1; jy = m[3] ? +m[3] : cj[0];
    }
    var iso = u.jToIso(jy, jm, jd);
    if (!iso) return null;
    if (!m[3] && !/\d{4}/.test(x) && iso < u.todayISO()) iso = u.jToIso(jy + 1, jm, jd) || iso;
    return iso;
  };
  // جملات آزاد (مثلاً «امروز ۴۵ دقیقه فیزیک خوندم و ۱۰ تست زدم») → کارها
  pl.parseLocal = function (txt) {
    var out = [];
    var T = fd(txt).replace(/\s(?=(ضعف|فردا|هدف|آزمون|تایمر)\s)/g, '. ')
      .replace(/(خوندم|خواندم|زدم|داشتم|مونده|مانده|کردم|بخونم|بزنم|بودم|نخوندم|نرسیدم|ندیدم|می‌خوابم|میخوابم|می‌شم|میشم)(\s|$)/g, '$1.$2')
      .replace(/(دادم|بدم)(?!\s*\d)(\s|$)/g, '$1.$2');
    T.split(/[.\n؛،]/).map(function (x) { return x.trim(); }).filter(function (x) { return x.length > 3; }).forEach(function (x) {
      var f;
      var sj0 = D.subjectFromText(x);
      var sj = sj0 && allS().indexOf(sj0) >= 0 ? sj0 : '';
      var m = pmin(x);
      var tt = +((x.match(/(\d+)\s*(?:تا\s*)?تست/) || x.match(/تست[^\d]{0,12}(\d+)/) || [])[1] || 0);
      var g = function (r) { return +((x.match(r) || [])[1] || 0); };
      if (/تایمر/.test(x)) {
        if (/شروع|استارت|روشن/.test(x)) return out.push({ k: 'tstart', s: sj, c: /کلاس/.test(x), t: x });
        if (/تموم|پایان|ثبت|بسته|خاموش|توقف/.test(x)) return out.push({ k: 'tstop', t: x });
      }
      if (/آزمون/.test(x) && (f = x.match(/(\d+)\s*(?:تا\s*)?(?:سوال|سؤال)/))) return out.push({ k: 'exam', s: sj, t: +f[1], c: g(/(\d+)\s*(?:تا\s*)?(?:درست|صحیح)/), w: g(/(\d+)\s*(?:تا\s*)?(?:غلط|نادرست)/), z: g(/تراز\s*(\d+)/), x: x });
      if (/هدف/.test(x) && (m || (f = x.match(/(\d+(?:\.\d+)?)\s*ساعت/)))) return out.push({ k: 'goal', m: m || Math.round(+f[1] * 60), t: x });
      if (/بیدار|پا می‌شم|پا میشم/.test(x) && (f = x.match(/(\d{1,2})(?::(\d{2}))?/))) return out.push({ k: 'wake', v: p2(hh(f[1], x)) + ':' + p2(f[2] || 0), t: x });
      if (/می‌خوابم|میخوابم|ساعت خواب/.test(x) && (f = x.match(/(\d{1,2})(?::(\d{2}))?/))) {
        var h = hh(f[1], x);
        if (!/صبح|شب|عصر/.test(x) && h >= 6 && h < 12) h += 12;
        return out.push({ k: 'sleep', v: p2(h % 24) + ':' + p2(f[2] || 0), t: x });
      }
      if (!/خوندم|خواندم|زدم/.test(x) && (f = x.match(/از\s*(?:ساعت\s*)?(\d{1,2})(?::(\d{2}))?\s*تا\s*(?:ساعت\s*)?(\d{1,2})(?::(\d{2}))?/))) {
        var a = hh(f[1], x), b = hh(f[3], x);
        if (!/صبح|ظهر|عصر|شب/.test(x)) { if (a >= 1 && a <= 6) a += 12; if (b >= 1 && b <= 7) b += 12; }
        if (b <= a) b = a + 1;
        var d = (x.match(/هر\s*(شنبه|یکشنبه|دوشنبه|سه‌شنبه|چهارشنبه|پنجشنبه|جمعه)/) || [])[1];
        var r = d ? String(DAYX[d]) : /هر روز/.test(x) ? 'all' : 'today';
        var tl = x.replace(f[0], '').replace(/هر\s*\S+|دارم|امروز|فردا|ساعت/g, '').replace(/\s+/g, ' ').trim() || 'کار ثابت';
        return out.push({ k: 'busy', t: tl.slice(0, 40), s0: p2(a) + ':' + p2(f[2] || 0), e0: p2(b) + ':' + p2(f[4] || 0), r: r, x: x });
      }
      var fut = /باید|فردا|میخوام|می‌خوام|قراره|یادم باشه|فراموش نکنم|برنامه دارم/.test(x);
      var back = /عقب|مونده|مانده|نرسیدم|ندیدم|نخوندم|انجام ندادم/.test(x);
      var wk = /ضعف|نمیفهمم|نمی‌فهمم|بلد نیستم|گیج|مشکل دارم/.test(x);
      if (back) out.push({ k: 'bl', s: sj || D.subjectByHint(x), t: x, u: /فوری|مهم/.test(x) ? 1 : 0 });
      else if (wk) {
        var tp = (x.match(/(?:ضعف(?:ی)?\s*دارم|ضعفم|ضعف|مشکل دارم|نمیفهمم|نمی‌فهمم|بلد نیستم|گیج)\s*(?:اینه|در|توی|تو|به)?\s*:?\s*(.+)/) || [])[1] || x;
        tp.split(/\sو\s/).map(function (z) { return z.trim(); }).filter(function (z) { return z.length > 1; }).forEach(function (z) {
          var b2 = D.subjectFromText(z);
          out.push({ k: 'wk', s: b2 && allS().indexOf(b2) >= 0 ? b2 : (sj || D.subjectByHint(z)), t: z.replace(/^(در|توی|تو)\s*/, '') });
        });
      }
      else if (fut) out.push({ k: 'todo', t: x });
      else if (m || tt) out.push({ k: 'log', s: sj, m: m, t: tt, c: /کلاس/.test(x), x: x, ok: (x.match(/(\d+)\s*(?:تا\s*)?(?:درست|صحیح)/) || [])[1] });
      else out.push({ k: 'jr', t: x, jk: /مشکل|سخته|نتونستم|خسته|بد/.test(x) ? 'p' : /عالی|موفق|تونستم|خوب/.test(x) ? 'w' : 'n' });
    });
    return out;
  };
  // برنامه‌ی متنی (هفتگی + آزمون)
  pl.parseProg = function (txt) {
    var out = [], cur = { ds: [], cs: {} }, T = fd(txt).replace(/‌/g, '');
    T.split(/[\n؛;]/).map(function (x) { return x.trim(); }).filter(function (x) { return x.length > 3; }).forEach(function (line) {
      var ex = /آزمون|امتحان/.test(line) ? pl.jparse(line) : null;
      if (ex) {
        var R = [];
        var SUBR = '(ریاضی|حسابان|هندسه|فیزیک|شیمی|زیست|ادبیات|عربی|دینی|دین و زندگی|زبان|آمار|گسسته)';
        line.replace(new RegExp(SUBR + '\\D{0,8}?فصل\\s*(\\d+)(?:\\s*(تا|و|-)\\s*(\\d+))?', 'g'), function (m0, s, a, sp, b) {
          var sj = D.SUBA[s];
          if (!sj || allS().indexOf(sj) < 0) return m0;
          var g = S().mg || 12;
          if (sp === 'و') { R.push({ g: g, s: sj, a: +a, b: +a }); R.push({ g: g, s: sj, a: +b, b: +b }); }
          else R.push({ g: g, s: sj, a: +a, b: Math.max(+a, +(b || a)) });
          return m0;
        });
        out.push({ k: 'ex2', n: ((line.match(/(آزمون|امتحان)[^:،\d]{0,25}/) || ['آزمون'])[0]).trim(), d: ex, r: R, t: line });
        return;
      }
      var ds = []; var mm;
      var re = new RegExp(DNR.source, 'g');
      while ((mm = re.exec(line))) ds.push(DN[mm[1]]);
      if (/هر روز/.test(line)) ds = [0, 1, 2, 3, 4, 5, 6];
      if (ds.length) cur.ds = ds;
      var rest = line.replace(DNR, ' ').replace(/هر روز/g, ' ').replace(/[:：]/g, ' ').replace(/\s+(و|،)\s+(?=\s|$)/g, ' ').trim();
      if (!rest || !cur.ds.length) return;
      rest.split(/[،,]/).forEach(function (p) {
        p = p.trim();
        if (p.length < 2) return;
        var a, b, f = p.match(/(?:از\s*)?(?:ساعت\s*)?(\d{1,2})(?::(\d{2}))?\s*(?:تا|-|–)\s*(?:ساعت\s*)?(\d{1,2})(?::(\d{2}))?/), dur = 0;
        if (f) {
          a = hh(f[1], p); b = hh(f[3], p);
          if (!/صبح|ظهر|عصر|شب/.test(p)) { if (a >= 1 && a <= 6) a += 12; if (b >= 1 && b <= 7) b += 12; }
          a = a * 60 + (+f[2] || 0); b = b * 60 + (+f[4] || 0);
          if (b <= a) b = a + 60;
        } else if (dur = pmin(p)) { /* مدت بدون ساعت شروع */ } else return;
        var tt = p.replace(f ? f[0] : '', '').replace(/ساعت|دقیقه|\d+(\.\d+)?|نیم|و\s*$/g, ' ').replace(/\s+/g, ' ').trim() || 'مطالعه';
        var tk = /کلاس|مدرسه/.test(p) ? 'class' : /ناهار|غذا|استراحت|خواب|ورزش|فوتبال|شام/.test(p) ? 'other' : 'study';
        cur.ds.forEach(function (d) {
          var s0 = a, e0 = b;
          if (!f) { s0 = cur.cs[d] || 16 * 60; e0 = s0 + dur; if (e0 > 23 * 60 + 30) return; }
          cur.cs[d] = e0 + 10;
          out.push({ k: 'wp', day: d, s0: p2(Math.floor(s0 / 60)) + ':' + p2(s0 % 60), e0: p2(Math.floor(e0 / 60)) + ':' + p2(e0 % 60), t: tt.slice(0, 60), tk: tk });
        });
      });
    });
    return out;
  };
  // JSON داخل متن پاسخ مشاور
  pl.jsonOf = function (t) {
    t = String(t);
    var m = t.match(/```json\s*([\s\S]*?)```/i);
    var x = m ? m[1] : null;
    if (!x) {
      var a = t.indexOf('{"weekly"'), b = t.indexOf('[{"k"'), i = a >= 0 ? a : b;
      if (i >= 0) x = t.slice(i, (a >= 0 ? t.lastIndexOf('}') : t.lastIndexOf(']')) + 1);
    }
    if (!x) return null;
    try { return JSON.parse(x); } catch (e) { return null; }
  };
  pl.normActs = function (a) {
    return a.filter(function (x) { return x && VL[x.k]; }).map(function (x) {
      var o = Object.assign({ jk: 'n', u: 0, c: false, m: 0, w: 0, z: 0, r: 'today' }, x);
      o.s = allS().indexOf(x.s) >= 0 ? x.s : '';
      o.m = Math.round(+x.m || 0);
      o.t = ['log', 'exam'].indexOf(x.k) >= 0 ? Math.round(+x.t || 0) : String(x.t || x.n || '');
      o.x = x.s || '';
      return o;
    });
  };
  // برنامه‌ی هفتگی از JSON
  pl.wpApply = function (o) {
    var L = (o.weekly || []).filter(function (x) { return x && u.validHM(x.s0) && u.validHM(x.e0) && x.day >= 0 && x.day <= 6; }).map(function (x) {
      return { day: +x.day, s0: u.normHM(x.s0), e0: u.normHM(x.e0), t: String(x.t || '').slice(0, 80), k: ['study', 'class', 'other'].indexOf(x.k) >= 0 ? x.k : 'study' };
    });
    if (!L.length) return 0;
    S().wp = L;
    return L.length;
  };
  // اعمال فهرست آیتم‌ها (نتیجه‌ی تجزیه) در داده‌ها. تعداد ثبت‌شده برمی‌گرداند.
  pl.applyActs = function (list) {
    var n = 0, timers = [];
    list.forEach(function (a) {
      var ok = true;
      if (a.k === 'log') {
        var g = S().mg, rec = st.addLog({ g: g, s: a.s || (D.subjects(g)[0] || { name: '' }).name, c: 0, m: a.m, t: a.t, k: a.c ? 'c' : undefined, ok: a.ok != null && a.ok !== '' && +a.ok <= a.t ? +a.ok : undefined });
        ok = !!rec;
      } else if (a.k === 'todo') ok = !!st.addTodo(String(a.t || '').slice(0, 120));
      else if (a.k === 'bl') ok = !!st.addBacklog({ s: a.s || '', t: String(a.t || ''), u: a.u });
      else if (a.k === 'wk') ok = !!st.addWeak({ s: a.s || '', t: String(a.t || '').slice(0, 120), v: 2, m: 10 });
      else if (a.k === 'busy') {
        S().busy.push({ id: u.uid(), t: String(a.t || 'کار ثابت').slice(0, 80), s: a.s0, e: a.e0, r: String(a.r), d: u.todayISO() });
        ok = true;
      } else if (a.k === 'exam') {
        var ex = a.t > 0 && a.c + a.w <= a.t ? App.exam.addResult({ n: '', s: a.s || '', date: u.todayISO(), t: a.t, c: a.c, w: a.w, z: a.z || 0, neg: 0 }) : null;
        ok = !!ex;
      } else if (a.k === 'goal') { if (a.m) S().goal = u.clamp(a.m, 10, 1440); }
      else if (a.k === 'wake') S().wake = u.validHM(a.v) ? u.normHM(a.v) : S().wake;
      else if (a.k === 'sleep') S().sleep = u.validHM(a.v) ? u.normHM(a.v) : S().sleep;
      else if (a.k === 'wp') {
        var it = { day: +a.day, s0: u.normHM(a.s0), e0: u.normHM(a.e0), t: String(a.t || '').slice(0, 80), k: ['study', 'class', 'other'].indexOf(a.tk) >= 0 ? a.tk : 'study' };
        ok = u.validHM(a.s0) && u.validHM(a.e0) && a.day >= 0 && a.day <= 6 && !S().wp.some(function (z) { return z.day === it.day && z.s0 === it.s0 && z.e0 === it.e0 && z.t === it.t; });
        if (ok) S().wp.push(it);
      } else if (a.k === 'ex2') {
        if (u.isISO(a.d || '')) {
          var planned = store.cleanPlanned({ n: String(a.n || a.t || 'آزمون').slice(0, 60), d: a.d, r: (a.r || []).map(function (z) { return { g: +z.g || S().mg || 12, s: z.s, a: +z.a || 1, b: +z.b || +z.a || 1 }; }) });
          S().ex2.push(planned);
        } else ok = false;
      } else if (a.k === 'jr') ok = !!st.addJournal(a.jk, a.t);
      else if (a.k === 'tstart' || a.k === 'tstop') { timers.push(a); ok = false; }
      else ok = false;
      if (ok) n++;
    });
    return { n: n, timers: timers };
  };
})();
