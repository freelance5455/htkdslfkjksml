window.AUSTRAL_CITIES = [
{country:"Moçambique",flag:"🇲🇿",city:"Maputo",lat:-25.9692,lon:32.5732,timezone:"Africa/Maputo"},
{country:"Moçambique",flag:"🇲🇿",city:"Beira",lat:-19.8436,lon:34.8389,timezone:"Africa/Maputo"},
{country:"Moçambique",flag:"🇲🇿",city:"Nampula",lat:-15.1165,lon:39.2666,timezone:"Africa/Maputo"},
{country:"África do Sul",flag:"🇿🇦",city:"Joanesburgo",lat:-26.2041,lon:28.0473,timezone:"Africa/Johannesburg"},
{country:"África do Sul",flag:"🇿🇦",city:"Cidade do Cabo",lat:-33.9249,lon:18.4241,timezone:"Africa/Johannesburg"},
{country:"África do Sul",flag:"🇿🇦",city:"Durban",lat:-29.8587,lon:31.0218,timezone:"Africa/Johannesburg"},
{country:"Zimbabwe",flag:"🇿🇼",city:"Harare",lat:-17.8252,lon:31.0335,timezone:"Africa/Harare"},
{country:"Zâmbia",flag:"🇿🇲",city:"Lusaka",lat:-15.3875,lon:28.3228,timezone:"Africa/Lusaka"},
{country:"Malawi",flag:"🇲🇼",city:"Lilongwe",lat:-13.9626,lon:33.7741,timezone:"Africa/Blantyre"},
{country:"Angola",flag:"🇦🇴",city:"Luanda",lat:-8.8390,lon:13.2894,timezone:"Africa/Luanda"},
{country:"Botswana",flag:"🇧🇼",city:"Gaborone",lat:-24.6282,lon:25.9231,timezone:"Africa/Gaborone"},
{country:"Namíbia",flag:"🇳🇦",city:"Windhoek",lat:-22.5609,lon:17.0658,timezone:"Africa/Windhoek"},
{country:"Lesoto",flag:"🇱🇸",city:"Maseru",lat:-29.3151,lon:27.4869,timezone:"Africa/Maseru"},
{country:"Eswatini",flag:"🇸🇿",city:"Mbabane",lat:-26.3054,lon:31.1367,timezone:"Africa/Mbabane"}
];