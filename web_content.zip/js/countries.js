/* Extra country reference data (currency, languages, emergency numbers). Reference only: verify before travel. */
(function (EP) {
  const C = (cur, langs, em) => ({ cur, langs, em });
  const only112 = { general: '112' };
  Object.assign(EP.countries, {
    AL: C('ALL', ['sq'], { general: '112', police: '129', ambulance: '127', fire: '128' }),
    AD: C('EUR', ['ca'], only112),
    BA: C('BAM', ['bs', 'hr', 'sr'], null),
    BG: C('EUR', ['bg'], { general: '112', police: '166', ambulance: '150', fire: '160' }),
    HR: C('EUR', ['hr'], { general: '112', police: '192', ambulance: '194', fire: '193' }),
    CY: C('EUR', ['el', 'tr'], only112),
    EE: C('EUR', ['et'], only112),
    FI: C('EUR', ['fi', 'sv'], only112),
    IS: C('ISK', ['is'], only112),
    LV: C('EUR', ['lv'], only112),
    LI: C('CHF', ['de'], only112),
    LT: C('EUR', ['lt'], only112),
    LU: C('EUR', ['lb', 'fr', 'de'], { general: '112', police: '113' }),
    MT: C('EUR', ['mt', 'en'], only112),
    MD: C('MDL', ['ro'], only112),
    MC: C('EUR', ['fr'], only112),
    ME: C('EUR', ['sr'], only112),
    MK: C('MKD', ['mk'], { general: '112', police: '192', ambulance: '194', fire: '193' }),
    RO: C('RON', ['ro'], only112),
    RS: C('RSD', ['sr'], { general: '112', police: '192', ambulance: '194', fire: '193' }),
    SK: C('EUR', ['sk'], { general: '112', police: '158', ambulance: '155', fire: '150' }),
    SI: C('EUR', ['sl'], { general: '112', police: '113' }),
    TR: C('TRY', ['tr'], only112),
    UA: C('UAH', ['uk'], { general: '112', police: '102', ambulance: '103', fire: '101' }),
    US: C('USD', ['en'], { general: '911' }),
    CA: C('CAD', ['en', 'fr'], { general: '911' }),
    AU: C('AUD', ['en'], { general: '000' }),
    JP: C('JPY', ['ja'], { police: '110', ambulance: '119', fire: '119' }),
    AE: C('AED', ['ar'], { police: '999', ambulance: '998', fire: '997' }),
    EG: C('EGP', ['ar'], { police: '122', ambulance: '123', fire: '180' })
  });
  EP.currencies = ['EUR', 'USD', 'GBP', 'CHF', 'CZK', 'HUF', 'PLN', 'DKK', 'SEK', 'NOK', 'ISK', 'RON', 'BGN', 'TRY', 'CAD', 'AUD', 'JPY', 'CNY', 'INR', 'ALL', 'BAM', 'MDL', 'MKD', 'RSD', 'UAH', 'AED', 'EGP', 'SAR', 'IRR'];
})(window.EP = window.EP || {});
