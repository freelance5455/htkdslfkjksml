/* countries.js — scenario data: countries, layout, province names.
   All names/flags are original (fictional nations on a Europe-like continent). */
(function (G) {
  'use strict';

  G.SCENARIOS = G.SCENARIOS || {};
  const EMP = {};
  // Each character = one map cell. '.' = sea. Letters = country id.
  EMP.LAYOUT = [
    '..AAAABB.CC.',
    '.AAAAABBCCC.',
    '.DDAAEBBCCCC',
    '.DDDEEEFFCC.',
    '..DDEEEFFFG.',
    '...DDEEFFGG.',
    '....DD..GGG.',
    '............'
  ];
  EMP.CELL = 100;            // world units per cell
  EMP.WORLD_W = 1200;
  EMP.WORLD_H = 800;

  EMP.COUNTRIES = {
    A: { id: 'A', name: 'Valdoria',   adj: 'Valdorian',  color: '#3d7ea6', flag: ['#3d7ea6', '#f2f2f2', 'h'],  gov: 'Constitutional Monarchy', treasury: 900, manpower: 52000, res: { steel: 60, coal: 80, oil: 10, food: 120 } },
    B: { id: 'B', name: 'Karvenia',   adj: 'Karvenian',  color: '#b84a3e', flag: ['#b84a3e', '#e8c547', 'v'],  gov: 'Military Junta',          treasury: 700, manpower: 61000, res: { steel: 90, coal: 70, oil: 25, food: 90 } },
    C: { id: 'C', name: 'Ostrava',    adj: 'Ostravan',   color: '#7a9a3c', flag: ['#7a9a3c', '#222222', 'h'],  gov: 'Republic',                treasury: 650, manpower: 48000, res: { steel: 40, coal: 55, oil: 60, food: 150 } },
    D: { id: 'D', name: 'Westmarch',  adj: 'Westmarcher',color: '#8a5fa8', flag: ['#8a5fa8', '#f0d9a0', 'x'],  gov: 'Parliamentary Democracy', treasury: 1100, manpower: 43000, res: { steel: 70, coal: 95, oil: 5, food: 85 } },
    E: { id: 'E', name: 'Theria',     adj: 'Therian',    color: '#d09a3a', flag: ['#d09a3a', '#7a1f1f', 'v'],  gov: 'Empire',                  treasury: 1300, manpower: 78000, res: { steel: 110, coal: 100, oil: 15, food: 140 } },
    F: { id: 'F', name: 'Solmar',     adj: 'Solmari',    color: '#3e9a8a', flag: ['#3e9a8a', '#f4f4f4', 'x'],  gov: 'Federation',              treasury: 800, manpower: 55000, res: { steel: 50, coal: 45, oil: 40, food: 160 } },
    G: { id: 'G', name: 'Drakkenhold',adj: 'Drakkish',   color: '#6b6f78', flag: ['#6b6f78', '#c23b3b', 'h'],  gov: 'Fascist State',           treasury: 600, manpower: 39000, res: { steel: 65, coal: 50, oil: 70, food: 60 } }
  };

  EMP.PROVINCE_NAMES = {
    A: ['Aldenmoor', 'Brightwater', 'Corvale', 'Dunmere', 'Eastwick', 'Faircliff', 'Greyhaven', 'Highfell', 'Ironford', 'Kingsmead', 'Larkspur', 'Northgate', 'Oakhurst'],
    B: ['Karstad', 'Rovnik', 'Varsk', 'Dolgrad', 'Mirovka', 'Tarnov', 'Zlatograd', 'Belmora'],
    C: ['Ostrava', 'Brenik', 'Lubor', 'Havelka', 'Dravin', 'Sorvik', 'Milevsk', 'Podrada', 'Kolin', 'Vranov', 'Tesar', 'Nemec'],
    D: ['Westmarch', 'Caldwell', 'Dornhelm', 'Elmsford', 'Fenwick', 'Gallowmere', 'Harrowgate', 'Isenbridge', 'Jarrow', 'Kestrel', 'Lowmoor'],
    E: ['Thera', 'Aurelia', 'Basilea', 'Cyrene', 'Delphor', 'Elysar', 'Fortuna', 'Galenia', 'Hesperos', 'Ionia', 'Kallis'],
    F: ['Solmar', 'Altura', 'Brisa', 'Calmora', 'Deluvia', 'Esperia', 'Faro', 'Gaviota', 'Havra'],
    G: ['Drakken', 'Eisenburg', 'Falkenau', 'Grimwald', 'Hohenfels', 'Kronstadt', 'Lindorf', 'Marnbach']
  };

  G.TERRAIN = {
    plains:   { name: 'Plains',    color: '#cdd8a0', def: 1.0, move: 1.0, supply: 1.0 },
    forest:   { name: 'Forest',    color: '#9bbf8a', def: 1.2, move: 1.5, supply: 0.8 },
    hills:    { name: 'Hills',     color: '#c9b98a', def: 1.3, move: 1.6, supply: 0.8 },
    mountain: { name: 'Mountains', color: '#b4aaa0', def: 1.6, move: 2.2, supply: 0.5 },
    marsh:    { name: 'Marsh',     color: '#a4bfa9', def: 0.9, move: 2.0, supply: 0.6 },
    urban:    { name: 'Urban',     color: '#d7c5c5', def: 1.4, move: 1.0, supply: 1.4 },
    desert:   { name: 'Desert',    color: '#e3cf98', def: 0.9, move: 1.5, supply: 0.4 }
  };

  G.RESOURCES = ['steel', 'coal', 'oil', 'rubber', 'food'];

  // Sea anchors for the fictional continent (world units): each sea cell joins the nearest anchor by flood-fill.
  EMP.SEAS = [
    { name: 'Boreal Sea', x: 100, y: 50 }, { name: 'Kora Inlet', x: 850, y: 50 }, { name: 'Eastern Ocean', x: 1150, y: 250 },
    { name: 'Drakken Sea', x: 1150, y: 550 }, { name: 'Western Ocean', x: 50, y: 300 }, { name: 'Southern Ocean', x: 200, y: 700 },
    { name: 'Solmar Gulf', x: 1000, y: 750 }, { name: 'Southern Bay', x: 650, y: 650 }
  ];
  EMP.STRAITS = [];
  G.SCENARIOS.empires = {
    id: 'empires', name: 'Empires — fictional continent', blurb: '7 original nations · 61 land provinces · 1 Jan 1936', type: 'grid', startYear: 1936,
    layout: EMP.LAYOUT, cell: EMP.CELL, w: EMP.WORLD_W, h: EMP.WORLD_H, avgCell: 100,
    countries: EMP.COUNTRIES, names: EMP.PROVINCE_NAMES, seas: EMP.SEAS, straits: EMP.STRAITS
  };

  // Activate a scenario: fills the globals every other module reads.
  G.useScenario = function (id) {
    const S = G.SCENARIOS[id] || G.SCENARIOS.empires;
    G.scenario = S; G.scenarioId = S.id;
    G.LAYOUT = S.layout; G.CELL = S.cell; G.WORLD_W = S.w; G.WORLD_H = S.h; G.AVGCELL = S.avgCell;
    // deep copy so capital/ownership edits never leak back into the registry
    G.COUNTRIES = JSON.parse(JSON.stringify(S.countries));
    G.PROVINCE_NAMES = S.names;
    G.SEAS = S.seas; G.STRAITS = S.straits || [];
    return S;
  };
  G.useScenario('empires');
})(window.EMP = window.EMP || {});
