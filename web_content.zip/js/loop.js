'use strict';
/* ---------- match setup ---------- */
function startMatch(){
  $('loading').hidden=false;
  setTimeout(()=>{try{startMatchNow()}catch(e){showErr(e);state='lobby';$('lobby').hidden=false}$('loading').hidden=true},80);
}
function showErr(e){const d=$('err');d.hidden=false;d.textContent='गड़बड़ी: '+(e&&e.message||e)+' — सेटिंग्स में ग्राफ़िक्स "लो" करके फिर कोशिश करो'}
function startMatchNow(){
  mode=MODES.find(m=>m.id===prof.mode)||MODES[0];
  genWorld(prof.map);
  players=[];bullets=[];parts=[];hurt=0;time=0;specT=null;shake=0;wxInit();
  const nm=NAMES.slice().sort(()=>Math.random()-.5);
  const myOut=ITEMS[prof.eq.o]||OUT[0];
  for(let i=0;i<mode.cnt;i++){
    const team=Math.floor(i/mode.team);
    const p=mkP(i===0?(prof.name||'Player'):nm[i%nm.length],i!==0,team,i===0?myOut:pick(OUT));
    players.push(p);
  }
  player=players[0];
  const sk=ITEMS[prof.eq.w];player.skin=sk&&sk.col||null;
  const gs=ITEMS[prof.eq.g];player.gskin=gs&&gs.col||'#8fd8ff';
  const pet=ITEMS[prof.eq.p];if(pet){player.pet=pet.kind;player.perk=pet.perk}
  if(player.perk==='arm')player.armor=40;
  if(player.perk==='ammo')player.res+=60;
  const leader={};
  for(const p of players){
    let x,y;
    if(leader[p.team]){const l=leader[p.team],a=rnd(0,TAU);x=l.x+Math.cos(a)*rnd(40,90);y=l.y+Math.sin(a)*rnd(40,90)}
    else{[x,y]=spawnPos();leader[p.team]=p}
    p.x=x;p.y=y;p.lx=x;p.ly=y;fix(p);
  }
  aliveN=players.length;
  z={cx:MAP/2+rnd(-.08,.08)*MAP,cy:MAP/2+rnd(-.08,.08)*MAP,r:MAP*.74,i:0,k:Math.pow(MAP/3000,.6)*mode.k};
  startWait();
  cam.x=player.x;cam.y=player.y-18;
  $('feed').innerHTML='';
  state='play';
  closePanel();$('lobby').hidden=true;$('end').hidden=true;$('pause').hidden=true;$('hud').hidden=false;
  applyTouchUI();
  toast(mp.n+' · '+mp.loc);
}
function spawnPos(){
  for(let t=0;t<80;t++){
    const x=rnd(160,MAP-160),y=rnd(160,MAP-160);
    if(blocked(x,y)||lakes.some(l=>Math.hypot(x-l.x,y-l.y)<l.r+40))continue;
    if(players.some(p=>p.x&&Math.hypot(p.x-x,p.y-y)<190))continue;
    return[x,y];
  }
  return[MAP/2,MAP/2];
}
function startWait(){
  const ph=PHT[z.i],R=ph.f*MAP;z.stage='wait';z.t=ph.w*z.k;
  const a=rnd(0,TAU),d=rnd(0,Math.max(0,z.r-R));
  z.tx=clamp(z.cx+Math.cos(a)*d,R,MAP-R);z.ty=clamp(z.cy+Math.sin(a)*d,R,MAP-R);z.tr=R;
}
function updZone(dt){
  if(z.stage==='done')return;
  z.t-=dt;
  if(z.stage==='wait'){
    if(z.t<=0){z.stage='shrink';z.t=PHT[z.i].s*z.k;z.s0={cx:z.cx,cy:z.cy,r:z.r}}
  }else{
    const f=1-Math.max(0,z.t/(PHT[z.i].s*z.k));
    z.cx=lerp(z.s0.cx,z.tx,f);z.cy=lerp(z.s0.cy,z.ty,f);z.r=lerp(z.s0.r,z.tr,f);
    if(z.t<=0){z.i++;if(z.i<PHT.length)startWait();else z.stage='done'}
  }
}
function endMatch(place){
  if(state!=='play')return;
  state='done';
  const win=place===1,k=player.kills;
  const gold=20+k*15+(win?150:place<=5?60:place<=10?30:0);
  const gems=win?5:0,xp=30+k*10+(win?60:0)+(place<=5?20:0);
  prof.gold+=gold;prof.gems+=gems;prof.xp+=xp;prof.st.m++;prof.st.k+=k;if(win)prof.st.w++;
  save();
  if(win)snd('win');
  setTimeout(()=>showEnd(place,{gold,gems,xp,k}),1300);
}

/* ---------- input ---------- */
const mouse={x:0,y:0,down:false,active:false};
const stk={mv:{id:null,ox:0,oy:0,x:0,y:0,px:0,py:0},aim:{id:null,lx:0,ly:0}};
let fireTouch=false,fireId=null,fireLast=null,VW=0,VH=0,DPR=1,S=1;
const SR=56;
addEventListener('keydown',e=>{
  const k=e.key.toLowerCase();keys[k]=true;
  if(state==='play'&&player.alive){
    if(k==='r')startReload(player);else if(k==='q'||k==='tab')swapW(player);else if(k==='g')throwN(player,'grenade');
    else if(k==='t')throwN(player,'smoke');else if(k==='c'||k==='f')placeGloo(player);else if(k==='h')startHeal(player,'bandage');else if(k==='j')startHeal(player,'medkit');
    if(k==='tab'||k===' ')e.preventDefault();
  }
  if(k==='escape'||k==='p'){if(state==='play')pauseGame();else if(state==='pause')resumeGame()}
});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false});
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;mouse.down=false});
function rel(e){const r=$('c').getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]}
function turnBy(dx,dy,sens){const a=player.ang;player.ang+=(dx*-Math.sin(a)+dy*Math.cos(a))*.011*sens}
function bindInput(){
  const cv=$('c');
  cv.addEventListener('pointerdown',e=>{
    if(state!=='play')return;
    const[x,y]=rel(e);
    if(e.pointerType==='mouse'){if(e.button===0){mouse.down=true}mouse.active=true;mouse.x=x;mouse.y=y;return}
    if(x<VW*.45){
      if(stk.mv.id!==null)return;
      const fx=set.float?x:VW*.17,fy=set.float?y:VH-110;
      Object.assign(stk.mv,{id:e.pointerId,ox:fx,oy:fy,px:x,py:y,x:0,y:0});
      if(!set.float){const dx=x-fx,dy=y-fy,d=Math.hypot(dx,dy)||1,c=Math.min(d,SR*set.joy);stk.mv.x=dx/d*c/(SR*set.joy);stk.mv.y=dy/d*c/(SR*set.joy);stk.mv.px=fx+dx/d*c;stk.mv.py=fy+dy/d*c}
    }else{
      if(stk.aim.id!==null)return;
      stk.aim.id=e.pointerId;stk.aim.lx=x;stk.aim.ly=y;
    }
    try{cv.setPointerCapture(e.pointerId)}catch(_){}
  });
  cv.addEventListener('pointermove',e=>{
    const[x,y]=rel(e);
    if(e.pointerType==='mouse'){mouse.x=x;mouse.y=y;mouse.active=true;return}
    const s=stk.mv;
    if(s.id===e.pointerId){
      const R=SR*set.joy;let dx=x-s.ox,dy=y-s.oy;const d=Math.hypot(dx,dy);
      if(d>R){dx*=R/d;dy*=R/d}
      s.x=dx/R;s.y=dy/R;s.px=s.ox+dx;s.py=s.oy+dy;
    }
    if(stk.aim.id===e.pointerId&&state==='play'&&player.alive){turnBy(x-stk.aim.lx,y-stk.aim.ly,set.aim);stk.aim.lx=x;stk.aim.ly=y}
  });
  const up=e=>{
    if(e.pointerType==='mouse'){mouse.down=false;return}
    if(stk.mv.id===e.pointerId){stk.mv.id=null;stk.mv.x=0;stk.mv.y=0}
    if(stk.aim.id===e.pointerId)stk.aim.id=null;
  };
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  cv.addEventListener('contextmenu',e=>e.preventDefault());
  // touch buttons
  const fb=$('bFire');
  fb.addEventListener('pointerdown',e=>{e.preventDefault();fireTouch=true;fireId=e.pointerId;fireLast=rel(e);try{fb.setPointerCapture(e.pointerId)}catch(_){}ac()});
  fb.addEventListener('pointermove',e=>{if(fireId===e.pointerId&&state==='play'&&player.alive){const p=rel(e);turnBy(p[0]-fireLast[0],p[1]-fireLast[1],set.fsens*1.3);fireLast=p}});
  const fu=e=>{if(fireId===e.pointerId){fireTouch=false;fireId=null}};
  fb.addEventListener('pointerup',fu);fb.addEventListener('pointercancel',fu);
  const act=(id,fn)=>{$(id).addEventListener('pointerdown',e=>{e.preventDefault();ac();if(state==='play'&&player.alive)fn(player)})};
  act('bRel',startReload);act('bSwap',swapW);act('bGren',p=>throwN(p,'grenade'));act('bGloo',placeGloo);
  act('bBand',p=>startHeal(p,'bandage'));act('bMed',p=>startHeal(p,'medkit'));act('bSmk',p=>throwN(p,'smoke'));
  $('bPause').addEventListener('click',()=>{if(state==='play')pauseGame()});
  // desktop chips
  for(const [id,fn] of [['cBand',p=>startHeal(p,'bandage')],['cMed',p=>startHeal(p,'medkit')],['cGren',p=>throwN(p,'grenade')],['cSmk',p=>throwN(p,'smoke')],['cGloo',placeGloo]])
    $(id).addEventListener('click',()=>{if(state==='play'&&player.alive)fn(player)});
}
function pauseGame(){state='pause';$('pause').hidden=false}
function resumeGame(){state='play';$('pause').hidden=true;closePanel()}
function touchUIOn(){return set.show==='on'||(set.show==='auto'&&isTouch)}
function applyTouchUI(){
  const on=touchUIOn();
  $('tb').hidden=!on;$('chips').hidden=on;
  document.documentElement.style.setProperty('--bs',set.btn);
}

/* ---------- update ---------- */
function update(dt){
  if(state!=='play'&&state!=='done')return;
  if(state==='play')time+=dt;
  updZone(dt);
  const dmgZ=PHT[Math.min(z.i,PHT.length-1)].dmg;
  if(player.alive&&state==='play'){
    let mx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),my=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);
    mx+=stk.mv.x;my+=stk.mv.y;
    const m=Math.hypot(mx,my);if(m>1){mx/=m;my/=m}
    let fire=false;
    if(mouse.active&&!isTouch){
      const wx=cam.x+(mouse.x-VW/2)/S,wy=cam.y+(mouse.y-VH/2)/S;
      player.ang=Math.atan2(wy-(player.y-26),wx-player.x);fire=mouse.down||keys[' '];
    }
    if(fireTouch||(touchUIOn()&&false))fire=true;
    if(fire&&set.assist&&(fireTouch||stk.aim.id!==null)){
      const w=curW(player);let bd=.38,ba=null;
      for(const p of players){
        if(!p.alive||p.team===player.team)continue;
        const d=Math.hypot(p.x-player.x,p.y-player.y);if(d>w.range*.9)continue;
        const df=angDiff(player.ang,Math.atan2(p.y-player.y,p.x-player.x));
        if(Math.abs(df)<bd&&los(player.x,player.y,p.x,p.y)){bd=Math.abs(df);ba=df}
      }
      if(ba!==null)player.ang+=clamp(ba,-5*dt,5*dt);
    }
    if(m>.2&&!mouse.active&&stk.aim.id===null&&!fireTouch&&!isTouch)player.ang=Math.atan2(my,mx);
    const sp=175*(player.perk==='spd'?1.08:1)*(inWater(player)?.55:1)*(player.heal?.55:1);
    moveE(player,mx*sp,my*sp,dt);player.mv=clamp(Math.hypot(player.vx,player.vy)/150,0,1);
    if(fire)shoot(player);
  }
  for(const p of players){
    if(!p.alive)continue;
    p.cd-=dt;p.flash-=dt;p.hitT-=dt;p.throwCd-=dt;p.glCd-=dt;p.wt+=dt*(.3+p.mv);
    if(p.rl>0){p.rl-=dt;if(p.rl<=0){p.rl=0;finishReload(p)}}
    updHeal(p,dt);
    if(p.perk==='regen'&&time-p.lastHit>5&&p.hp<100)p.hp=Math.min(100,p.hp+1.2*dt);
    if(p.bot&&state==='play')botAI(p,dt);
    p.pk-=dt;if(p===player||p.pk<=0){p.pk=.12;pickups(p)}
    if(Math.hypot(p.x-z.cx,p.y-z.cy)>z.r){p.hp-=dmgZ*dt;if(p===player)hurt=Math.max(hurt,.25);if(p.hp<=0)kill(p,null)}
  }
  for(let i=bullets.length-1;i>=0;i--){
    const b=bullets[i],step=b.sp*dt,n=Math.max(1,Math.ceil(step/7)),sx=b.vx*dt/n,sy=b.vy*dt/n,sl=step/n;
    let dead=false;
    for(let s=0;s<n&&!dead;s++){
      b.x+=sx;b.y+=sy;b.l-=sl;
      if(b.l<=0){dead=true;break}
      const gw=hitDyn(b.x,b.y);
      if(gw){damageGloo(glooW.indexOf(gw),b.d);spark(b.x,b.y,gw.col,3);dead=true;break}
      if(blocked(b.x,b.y)){spark(b.x,b.y,'#d6d0b8',4);dead=true;break}
      for(const p of players){
        if(!p.alive||p.team===b.o.team)continue;
        const dx=p.x-b.x,dy=p.y-b.y,rr2=p.r+2;
        if(dx*dx+dy*dy<rr2*rr2){spark(b.x,b.y,'#ff5d6c',5);hurtP(p,b.d,b.o);dead=true;break}
      }
    }
    if(dead){bullets[i]=bullets[bullets.length-1];bullets.pop()}
  }
  updNades(dt);updGloo(dt);
  for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.l<=0){parts[i]=parts[parts.length-1];parts.pop()}}
  hurt=Math.max(0,hurt-dt);shake=Math.max(0,shake-dt*2.5);
  let f=player;
  if(!player.alive){
    if(!specT||!specT.alive)specT=players.find(p=>p.alive&&p.team===player.team)||players.find(p=>p.alive)||player;
    f=specT;
  }
  cam.x+=(f.x-cam.x)*Math.min(1,dt*9);cam.y+=(f.y-18-cam.y)*Math.min(1,dt*9);
}
