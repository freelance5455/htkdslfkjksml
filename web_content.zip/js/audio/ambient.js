// Sonido de ambiente procedural (viento, pasos, pájaros y chapoteo) con Web Audio, sin archivos. Portado de EDEN-Visor-3D.
// Se llama a frame() una vez por fotograma desde la capa del mundo; no hace nada si el audio aún no ha arrancado.
import { audio } from './engine.js';
import { pro } from '../core/pro.js';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export function createAmbient() {
  let noise = null;
  let wind = null; // { src, gain }
  let nextStep = 0;
  let nextBird = 3;
  let wasWet = false;

  const ensure = () => {
    if (!audio.running) return false;
    if (!noise) {
      const c = audio.ctx;
      const n = c.sampleRate * 2;
      noise = c.createBuffer(1, n, c.sampleRate);
      const d = noise.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    }
    return true;
  };
  // Un soplido de ruido filtrado: base de pasos, chapoteo y burbujas.
  const burst = (freq, q, dur, vol, type = 'bandpass') => {
    const c = audio.ctx;
    const s = c.createBufferSource();
    s.buffer = noise;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = c.createGain();
    const t = c.currentTime;
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f);
    f.connect(g);
    g.connect(audio.sfx);
    s.start(t, Math.random() * 1.5, dur + 0.05);
  };
  const chirp = () => {
    const c = audio.ctx;
    let t = c.currentTime;
    const n = 2 + Math.floor(Math.random() * 3);
    const base = 2200 + Math.random() * 1500;
    for (let i = 0; i < n; i++) {
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(base, t);
      o.frequency.exponentialRampToValueAtTime(base * (1.2 + Math.random() * 0.4), t + 0.08);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.05, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
      o.connect(g);
      g.connect(audio.sfx);
      o.start(t);
      o.stop(t + 0.12);
      t += 0.13;
    }
  };
  const startWind = () => {
    const c = audio.ctx;
    const src = c.createBufferSource();
    src.buffer = noise;
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 420;
    const gain = c.createGain();
    gain.gain.value = 0;
    src.connect(f);
    f.connect(gain);
    gain.connect(audio.sfx);
    src.start();
    wind = { src, gain };
  };
  const stopWind = () => {
    try {
      wind?.src.stop();
    } catch {
      /* ya parado */
    }
    wind = null;
  };

  // s: { active, y, grounded, wet, speed, biome, hours }  (biome: función que da mar · costa · roca · bosque · colinas, o null; solo se llama si hace falta)
  return {
    frame(s) {
      if (!ensure()) return;
      const now = audio.ctx.currentTime;
      const on = s.active && pro.get('ambient');
      if (!on) {
        wind?.gain.gain.setTargetAtTime(0, now, 0.3);
        return;
      }
      if (pro.get('windOn')) {
        if (!wind) startWind();
        const alt = clamp((s.y - 5) / 25, 0, 1);
        wind.gain.gain.setTargetAtTime(0.02 + 0.05 * alt + 0.015 * Math.sin(now * 0.4), now, 0.5);
      } else wind?.gain.gain.setTargetAtTime(0, now, 0.3);

      let b;
      let known = false;
      const biome = () => (known ? b : ((known = true), (b = s.biome ? s.biome() : null)));
      if (pro.get('stepsOn') && s.grounded && !s.wet && s.speed > 0.5 && now >= nextStep) {
        b = biome();
        nextStep = now + clamp(0.62 - s.speed * 0.06, 0.28, 0.6);
        if (b === 'costa') burst(800, 0.7, 0.14, 0.09, 'lowpass');
        else if (b === 'bosque') burst(2200, 1.2, 0.1, 0.07);
        else if (b === 'roca') burst(1500, 6, 0.07, 0.08);
        else burst(1100, 0.9, 0.09, 0.07);
      }
      if (s.wet && !wasWet && pro.get('splashOn')) burst(1500, 0.5, 0.5, 0.22, 'highpass');
      wasWet = s.wet;
      const day = s.hours > 6 && s.hours < 18;
      if (pro.get('birdsOn') && now >= nextBird && day && (biome() == null || b === 'bosque' || b === 'colinas')) {
        chirp();
        nextBird = now + 3 + Math.random() * 6;
      }
    },
    dispose: stopWind,
  };
}
