// Música: la generativa «china» (guzheng, pipa y arpa con síntesis de cuerda pulsada, escala pentatónica, sin archivos) y la
// música propia del usuario (archivos de audio guardados en el dispositivo). Portado de EDEN-Visor-3D.
// Mientras suena la música propia, la china se calla.
import { audio } from './engine.js';
import { pro } from '../core/pro.js';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const mulberry32 = (a) => () => {
  a |= 0;
  a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

// ── Música propia ────────────────────────────────────────────────────────────────────────────────────────────
const INDEX_KEY = 'music-index';
const fileKey = (id) => `music:${id}`;
export const MY_MAX_BYTES = 40 * 1024 * 1024;
export const MY_MAX_TRACKS = 12;

export const myMusic = {
  store: null,
  tracks: [], // [{ id, name, size }]
  el: null,
  src: null,
  url: '',
  current: -1,
  listeners: new Set(),
  get playing() {
    return !!this.el && !this.el.paused && !this.el.ended;
  },
  onChange(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  },
  emit() {
    for (const fn of this.listeners) fn();
  },
  async init(store) {
    this.store = store;
    const idx = await store.getSetting(INDEX_KEY, []).catch(() => []);
    this.tracks = Array.isArray(idx) ? idx.filter((t) => t && typeof t.id === 'string') : [];
    this.emit();
  },
  async add(file) {
    if (!file || !/^audio\//.test(file.type || '') && !/\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|webm)$/i.test(file.name || '')) throw new Error('Ese archivo no parece de audio.');
    if (file.size > MY_MAX_BYTES) throw new Error('Pesa más de 40 MB.');
    if (this.tracks.length >= MY_MAX_TRACKS) throw new Error(`Máximo ${MY_MAX_TRACKS} canciones.`);
    const id = Math.random().toString(36).slice(2, 10);
    await this.store.setSetting(fileKey(id), file);
    this.tracks = [...this.tracks, { id, name: (file.name || 'Canción').replace(/\.[^.]+$/, '').slice(0, 60), size: file.size }];
    await this.store.setSetting(INDEX_KEY, this.tracks);
    this.emit();
    return id;
  },
  async remove(id) {
    const i = this.tracks.findIndex((t) => t.id === id);
    if (i < 0) return;
    if (i === this.current) this.stop();
    this.tracks = this.tracks.filter((t) => t.id !== id);
    if (this.current > i) this.current--;
    await this.store.setSetting(INDEX_KEY, this.tracks);
    await this.store.setSetting(fileKey(id), null);
    this.emit();
  },
  async play(i = 0) {
    if (!this.tracks.length || !audio.start()) return false;
    i = ((i % this.tracks.length) + this.tracks.length) % this.tracks.length;
    const blob = await this.store.getSetting(fileKey(this.tracks[i].id), null);
    if (!(blob instanceof Blob)) return false;
    this.stop(false);
    this.url = URL.createObjectURL(blob);
    if (!this.el) {
      this.el = new Audio();
      this.el.crossOrigin = 'anonymous';
      this.el.addEventListener('ended', () => this.play(this.current + 1));
      this.el.addEventListener('error', () => {
        console.warn('[música] no se pudo reproducir esa canción');
        this.stop();
      });
    }
    this.el.src = this.url;
    if (!this.src) {
      this.src = audio.ctx.createMediaElementSource(this.el);
      this.src.connect(audio.music);
    }
    this.current = i;
    try {
      await this.el.play();
    } catch (err) {
      console.warn('[música] el navegador no dejó reproducir', err);
      this.stop();
      return false;
    }
    this.emit();
    return true;
  },
  stop(notify = true) {
    if (this.el) {
      this.el.pause();
      this.el.removeAttribute('src');
      this.el.load?.();
    }
    if (this.url) URL.revokeObjectURL(this.url);
    this.url = '';
    this.current = -1;
    if (notify) this.emit();
  },
  next() {
    return this.play(this.current + 1);
  },
};

// ── Música china generativa ──────────────────────────────────────────────────────────────────────────────────
const PENT = [0, 2, 4, 7, 9];
const INST = {
  guzheng: { len: 3.2, decay: 0.9983, bright: 0.55, pan: -0.15 },
  pipa: { len: 1.9, decay: 0.9945, bright: 1.0, pan: 0.25 },
  harp: { len: 3.8, decay: 0.9988, bright: 0.35, pan: -0.3 },
};

export const chineseMusic = {
  ctx: null,
  bus: null,
  timer: 0,
  nextBar: 0,
  bar: 0,
  rand: null,
  cache: new Map(),
  root: 0,
  voices: 0,
  playing: false,
  bpm: 64,
  kPrev: 8,
  setup() {
    if (!audio.ctx || !audio.music) return false;
    if (this.ctx === audio.ctx && this.bus) return true;
    const c = audio.ctx;
    this.ctx = c;
    this.cache.clear();
    this.bus = c.createGain();
    this.bus.gain.value = 0;
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -20;
    comp.ratio.value = 3;
    const dry = c.createGain();
    dry.gain.value = 0.8;
    const wet = c.createGain();
    wet.gain.value = 0.35;
    const conv = c.createConvolver();
    const n = Math.floor(c.sampleRate * 2.8);
    const ir = c.createBuffer(2, n, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = ir.getChannelData(ch);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2.6);
    }
    conv.buffer = ir;
    this.bus.connect(dry);
    this.bus.connect(conv);
    conv.connect(wet);
    dry.connect(comp);
    wet.connect(comp);
    comp.connect(audio.music);
    this.rand = mulberry32(Date.now() & 0xffffffff);
    return true;
  },
  // Una nota de cuerda pulsada (Karplus-Strong), guardada para no recalcularla.
  note(inst, midi) {
    const key = inst + midi;
    let b = this.cache.get(key);
    if (b) return b;
    const c = this.ctx;
    const sr = c.sampleRate;
    const f = 440 * Math.pow(2, (midi - 69) / 12);
    const N = Math.max(2, Math.round(sr / f));
    const P = INST[inst];
    const len = Math.floor(sr * P.len);
    b = c.createBuffer(1, len, sr);
    const d = b.getChannelData(0);
    const line = new Float32Array(N);
    const r = mulberry32(midi * 977 + inst.length);
    let prev = 0;
    for (let i = 0; i < N; i++) {
      prev += (r() * 2 - 1 - prev) * P.bright;
      line[i] = prev;
    }
    let idx = 0;
    for (let i = 0; i < len; i++) {
      const cur = line[idx];
      const nx = line[(idx + 1) % N];
      line[idx] = (cur + nx) * 0.5 * P.decay;
      d[i] = cur;
      idx = (idx + 1) % N;
    }
    let mx = 0;
    for (let i = 0; i < len; i++) mx = Math.max(mx, Math.abs(d[i]));
    const g = mx > 0 ? 0.9 / mx : 1;
    const fade = Math.floor(sr * 0.05);
    for (let i = 0; i < len; i++) {
      let k = g;
      if (i > len - fade) k *= (len - i) / fade;
      d[i] *= k;
    }
    b._f = sr / N;
    this.cache.set(key, b);
    return b;
  },
  play(inst, midi, t, vel, o = {}) {
    if (this.voices > 60) return;
    const c = this.ctx;
    const buf = this.note(inst, midi);
    const s = c.createBufferSource();
    s.buffer = buf;
    const f = 440 * Math.pow(2, (midi - 69) / 12);
    const rate = f / buf._f;
    if (o.bend) {
      s.playbackRate.setValueAtTime(rate * Math.pow(2, o.bend / 12), t);
      s.playbackRate.exponentialRampToValueAtTime(rate, t + (o.bendT || 0.16));
    } else s.playbackRate.value = rate;
    const g = c.createGain();
    g.gain.setValueAtTime(vel, t);
    if (o.dur) g.gain.setTargetAtTime(0.0001, t + o.dur * 0.7, 0.08);
    const pan = c.createStereoPanner ? c.createStereoPanner() : null;
    if (pan) pan.pan.value = clamp(INST[inst].pan + (this.rand() - 0.5) * 0.2, -1, 1);
    s.connect(g);
    if (pan) {
      g.connect(pan);
      pan.connect(this.bus);
    } else g.connect(this.bus);
    this.voices++;
    s.onended = () => {
      this.voices--;
      try {
        g.disconnect();
      } catch {
        /* ya desconectado */
      }
    };
    s.start(t);
    s.stop(t + (o.dur ? o.dur + 0.8 : buf.duration / rate));
  },
  midi(k) {
    const oct = Math.floor(k / 5);
    const i = ((k % 5) + 5) % 5;
    return 50 + this.root + 12 * oct + PENT[i];
  },
  tremolo(inst, k, t, dur, rate, vel) {
    const n = Math.floor(dur * rate);
    for (let i = 0; i < n; i++) this.play(inst, this.midi(k), t + i / rate, vel * (0.55 + 0.45 * Math.sin((Math.PI * i) / n)), { dur: 0.35 });
  },
  // Un compás de 4 tiempos: arpa de fondo, melodía de guzheng y toques de pipa; cada 8 compases cambia la tónica.
  scheduleBar(t0) {
    const B = 60 / this.bpm;
    const bar = this.bar++;
    const ph = bar % 8;
    const sec = Math.floor(bar / 8);
    const r = this.rand;
    if (ph === 0) {
      this.root = [0, 0, 5, 7][Math.floor(r() * 4)];
      this.kPrev = 8;
    }
    if (pro.get('harp')) {
      const up = bar % 2 === 0;
      const step = B * 0.5;
      for (let i = 0; i < 8; i++) this.play('harp', this.midi(2 + (up ? i : 7 - i)), t0 + i * step, 0.34 - i * 0.012, {});
      if (ph % 2 === 0) this.play('harp', this.midi(-3), t0, 0.5, {});
    }
    if (pro.get('guzheng') && ph >= 1) {
      const rhythms = [[0, 1, 1.5, 2, 3, 3.5], [0, 0.5, 1, 2, 2.5, 3], [0, 1, 2, 2.5, 3, 3.5], [0, 1.5, 2, 3]];
      const rh = rhythms[Math.floor(r() * rhythms.length)];
      rh.forEach((b, i) => {
        if (r() < 0.15 && i > 0) return;
        this.kPrev = clamp(this.kPrev + Math.floor(r() * 5) - 2, 4, 13);
        let k = this.kPrev;
        const last = ph === 7 && i === rh.length - 1;
        if (last) k = this.kPrev = 5 + (r() < 0.5 ? 0 : 5);
        const o = {};
        if (r() < 0.35 || last) {
          o.bend = (r() < 0.6 ? -1 : 1) * (1 + Math.floor(r() * 2));
          o.bendT = 0.14 + r() * 0.08;
        }
        this.play('guzheng', this.midi(k), t0 + b * B, 0.55 + r() * 0.2, o);
      });
      if (ph === 3) for (let i = 0; i < 8; i++) this.play('guzheng', this.midi(14 - i), t0 + i * 0.05, 0.3, {});
      if (ph === 5) this.tremolo('guzheng', 9, t0 + 2 * B, 1.6, 14, 0.4);
    }
    if (pro.get('pipa') && sec >= 1) {
      if (ph % 2 === 0) {
        this.tremolo('pipa', 7, t0, 2 * B, 16, 0.38);
        this.play('pipa', this.midi(9), t0 + 2.5 * B, 0.5, {});
        this.play('pipa', this.midi(8), t0 + 3 * B, 0.45, {});
      }
      if (ph === 6) for (let i = 0; i < 7; i++) this.play('pipa', this.midi(5 + i), t0 + 2 * B + i * 0.06, 0.35, {});
    }
  },
  wanted() {
    return pro.get('chinese') && pro.get('musicOn') && audio.running && !myMusic.playing && !(document.hidden && pro.get('visibilityPause'));
  },
  tick() {
    try {
      if (!this.setup()) return;
      const want = this.wanted();
      const c = this.ctx;
      const vol = pro.get('chineseVol') * (audio.inWorld ? 0.8 : 1);
      this.bus.gain.setTargetAtTime(want ? vol : 0, c.currentTime, want ? 0.4 : 0.3);
      if (!want) {
        this.playing = false;
        return;
      }
      if (!this.playing) {
        this.playing = true;
        this.nextBar = Math.max(this.nextBar, c.currentTime + 0.3);
      }
      const barLen = (4 * 60) / this.bpm;
      while (this.nextBar < c.currentTime + 1.2) {
        this.scheduleBar(this.nextBar);
        this.nextBar += barLen;
      }
    } catch (err) {
      console.warn('[música] se detuvo la música china', err);
      this.stop();
    }
  },
  // Se llama una vez al arrancar: revisa cada 250 ms si toca sonar (no hace nada mientras el ajuste está apagado).
  start() {
    if (!this.timer) this.timer = setInterval(() => this.tick(), 250);
  },
  stop() {
    clearInterval(this.timer);
    this.timer = 0;
    this.playing = false;
    try {
      this.bus?.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2);
    } catch {
      /* sin contexto */
    }
  },
};
