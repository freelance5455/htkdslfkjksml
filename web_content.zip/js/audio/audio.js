/* Audio: satu AudioContext dipakai ulang, dibuat hanya setelah gesture pengguna. SFX stop terjadwal (tanpa setTimeout). */
(function (g) {
  'use strict';
  const SU = g.SU;
  const CFG = {
    classic: { wave: 'square', eat: 700, hit: 100, pu: 1500, go: 50, mt: 'square', mm: 0.05, vc: 0.5, mf: 160 },
    dark: { wave: 'sawtooth', eat: 500, hit: 70, pu: 1200, go: 30, mt: 'sawtooth', mm: 0.08, vc: 0.8, mf: 100 },
    forest: { wave: 'triangle', eat: 600, hit: 90, pu: 1000, go: 40, mt: 'triangle', mm: 0.02, vc: 1.0, mf: 130 },
    neon: { wave: 'sine', eat: 900, hit: 200, pu: 1800, go: 80, mt: 'sine', mm: 0.06, vc: 1.0, mf: 220 },
    light: { wave: 'triangle', eat: 800, hit: 120, pu: 1600, go: 60, mt: 'square', mm: 0.10, vc: 0.5, mf: 180 },
    special: { wave: 'sawtooth', eat: 1200, hit: 20, pu: 2000, go: 10, mt: 'square', mm: 0.15, vc: 0.5, mf: 280 }
  };
  const A = (SU.audio = {
    ctx: null, music: null, opts: { fx: true, fxVol: 80, bg: true, bgVol: 20, theme: 'classic' },
    ensure: function () {
      if (!A.ctx) { try { A.ctx = new (g.AudioContext || g.webkitAudioContext)(); } catch (e) { return false; } }
      if (A.ctx.state === 'suspended') A.ctx.resume();
      return true;
    },
    set: function (o) { Object.assign(A.opts, o); A.musicVolume(); },
    sfx: function (type) {
      if (!A.opts.fx || !A.ctx) return;
      const c = CFG[A.opts.theme] || CFG.classic, t = A.ctx.currentTime;
      const f = type === 'eat' ? c.eat : type === 'hit' ? c.hit : type === 'powerup' ? c.pu : c.go;
      const d = type === 'eat' ? 0.08 : type === 'powerup' ? 0.15 : type === 'hit' ? 0.4 : 0.8;
      const o = A.ctx.createOscillator(), gn = A.ctx.createGain();
      o.type = c.wave; o.frequency.setValueAtTime(f, t);
      if (type === 'eat') o.frequency.linearRampToValueAtTime(f * 1.3, t + 0.05);
      gn.gain.setValueAtTime((A.opts.fxVol / 100) * 0.5, t); gn.gain.exponentialRampToValueAtTime(0.001, t + d);
      o.connect(gn); gn.connect(A.ctx.destination); o.start(t); o.stop(t + d + 0.02);
    },
    musicStart: function () {
      if (!A.opts.bg || !A.ctx || A.music) return;
      const c = CFG[A.opts.theme] || CFG.classic, t = A.ctx.currentTime;
      const o = A.ctx.createOscillator(), gn = A.ctx.createGain(), l = A.ctx.createOscillator(), lg = A.ctx.createGain();
      o.type = c.mt; o.frequency.value = c.mf; l.frequency.value = 5; lg.gain.value = c.mf * c.mm;
      l.connect(lg); lg.connect(o.frequency); o.connect(gn); gn.connect(A.ctx.destination);
      gn.gain.setValueAtTime(0.0001, t); gn.gain.linearRampToValueAtTime((A.opts.bgVol / 100) * 0.4 * c.vc, t + 1.5);
      o.start(t); l.start(t); A.music = { o: o, l: l, g: gn, c: c };
    },
    musicVolume: function () {
      if (A.music && A.ctx) A.music.g.gain.setTargetAtTime((A.opts.bgVol / 100) * 0.4 * A.music.c.vc, A.ctx.currentTime, 0.05);
    },
    musicStop: function () {
      const m = A.music; if (!m || !A.ctx) return; A.music = null;
      const t = A.ctx.currentTime;
      m.g.gain.cancelScheduledValues(t); m.g.gain.setTargetAtTime(0.0001, t, 0.05);
      m.o.stop(t + 0.3); m.l.stop(t + 0.3);
      m.o.onended = function () { try { m.o.disconnect(); m.l.disconnect(); m.g.disconnect(); } catch (e) { /* sudah lepas */ } };
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
