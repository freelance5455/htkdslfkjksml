// Motor de audio compartido: un solo AudioContext con tres volúmenes (general, música y efectos).
// Los navegadores solo dejan sonar tras un toque, así que el contexto se crea en el primer gesto (main.js y la capa del mundo llaman a start()).
import { pro } from '../core/pro.js';
import { bus } from '../core/bus.js';

export const audio = {
  ctx: null,
  master: null,
  music: null, // la música (china o la importada) pasa por aquí
  sfx: null, // efectos: ambiente, pasos y voces de criaturas
  inWorld: false, // la capa del mundo lo pone a true mientras se juega
  get running() {
    return !!this.ctx && this.ctx.state === 'running';
  },
  start() {
    try {
      if (!this.ctx) {
        const C = globalThis.AudioContext || globalThis.webkitAudioContext;
        if (!C) return false;
        this.ctx = new C();
        this.master = this.ctx.createGain();
        this.music = this.ctx.createGain();
        this.sfx = this.ctx.createGain();
        this.music.connect(this.master);
        this.sfx.connect(this.master);
        this.master.connect(this.ctx.destination);
        this.apply();
      }
      if (this.ctx.state === 'suspended' && !(document.hidden && pro.get('visibilityPause'))) this.ctx.resume().catch(() => {});
      return true;
    } catch (err) {
      console.warn('[audio] no se pudo iniciar', err);
      return false;
    }
  },
  // En Chrome un toque solo «activa» la página al soltar el dedo (pointerup/touchend/click), no al pulsar; por eso el contexto se
  // reintenta en cada uno de esos eventos hasta que queda sonando, y luego se dejan de escuchar.
  unlockOnGesture() {
    if (this._unlock || typeof document === 'undefined') return;
    const evs = ['pointerup', 'touchend', 'click', 'keydown'];
    const fn = () => {
      this.start();
      if (this.running) {
        for (const e of evs) document.removeEventListener(e, fn, true);
        this._unlock = null;
      }
    };
    for (const e of evs) document.addEventListener(e, fn, true);
    this._unlock = fn;
  },
  // Lleva los ajustes (volúmenes y interruptores) a los nodos de ganancia, con un pequeño fundido para evitar chasquidos.
  apply(p = pro.all()) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(p.master, t, 0.05);
    this.music.gain.setTargetAtTime(p.musicOn ? p.music : 0, t, 0.05);
    this.sfx.gain.setTargetAtTime(p.sfxOn ? p.sfx : 0, t, 0.05);
  },
};

bus.on('pro:changed', (p) => audio.apply(p));
if (typeof document !== 'undefined') {
  // Con la app oculta se suspende el audio (ahorra batería); al volver se reanuda.
  document.addEventListener('visibilitychange', () => {
    if (!audio.ctx) return;
    if (document.hidden) {
      if (pro.get('visibilityPause')) audio.ctx.suspend().catch(() => {});
    } else if (audio.ctx.state === 'suspended') audio.ctx.resume().catch(() => {});
  });
}
