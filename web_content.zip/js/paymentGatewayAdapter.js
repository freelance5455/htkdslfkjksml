/**
 * paymentGatewayAdapter.js
 *
 * ⚠️ NÃO É UM PAGAMENTO REAL. Nenhum dinheiro é movimentado por este código.
 *
 * Esta é a INTERFACE que uma integração real de marketplace (ex.: Stripe
 * Connect, Mercado Pago Marketplace, PagSeguro Split) precisaria implementar
 * para plugar aqui: autorizar, reter (escrow), liberar para o profissional,
 * reembolsar, e receber webhooks de confirmação.
 *
 * A implementação abaixo é um SANDBOX local: apenas simula os retornos que
 * um gateway real daria, de forma síncrona e sem nenhuma conexão de rede,
 * para que o restante do sistema (paymentsService.js) possa ser construído e
 * testado já com a forma final da integração. Trocar por uma integração real
 * significa reescrever SÓ este arquivo.
 */
const PaymentGatewayAdapter = {
  SANDBOX: true,

  /** Autoriza a cobrança do valor total do anfitrião (mas ainda não captura). */
  async autorizar({ valor, referenciaExterna }){
    return {
      sucesso: true,
      gateway_referencia: 'SANDBOX-AUTH-' + referenciaExterna + '-' + Date.now(),
      mensagem: '[SANDBOX] Autorização simulada — nenhuma cobrança real foi feita.',
    };
  },

  /** Move o valor autorizado para retenção (escrow) até a liberação. */
  async reter({ gatewayReferencia }){
    return { sucesso: true, mensagem: '[SANDBOX] Retenção simulada.', gateway_referencia: gatewayReferencia };
  },

  /** Repassa o valor ao profissional (split) e a comissão à plataforma. */
  async liberar({ gatewayReferencia, valorProfissional, comissaoPlataforma }){
    return {
      sucesso: true,
      mensagem: `[SANDBOX] Repasse simulado — profissional R$ ${valorProfissional.toFixed(2)}, plataforma R$ ${comissaoPlataforma.toFixed(2)}.`,
      gateway_referencia: gatewayReferencia,
    };
  },

  async reembolsar({ gatewayReferencia, valor, parcial }){
    return { sucesso: true, mensagem: `[SANDBOX] Reembolso ${parcial ? 'parcial' : 'total'} simulado de R$ ${valor.toFixed(2)}.`, gateway_referencia: gatewayReferencia };
  },

  /**
   * Formato esperado de um webhook real (ex.: `payment.authorized`,
   * `payment.released`). Aqui só documentamos o contrato — nenhum endpoint
   * de rede existe neste projeto (é 100% estático, sem servidor).
   */
  FORMATO_WEBHOOK_ESPERADO: {
    evento: 'payment.authorized | payment.released | payment.refunded | payment.disputed',
    gateway_referencia: 'string',
    valor: 'number',
    ocorrido_em: 'ISO 8601',
  },
};
