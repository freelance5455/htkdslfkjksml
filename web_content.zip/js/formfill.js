// =======================================
// NetEarn Pro
// Form Fill Task System V4
// Firebase Auth + Referral/Chance Validation
// Same Logic as Typing Task
// =======================================

import { auth, db } from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";

import {
    onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    getDoc,
    collection,
    query,
    where,
    getDocs,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// ELEMENTS
// =======================================

const statusBox =
    document.getElementById("taskStatus");

const startBtn =
    document.getElementById("startFormBtn");


// =======================================
// TASK PAGE
// =======================================

const TASK_PAGE =
    "formfill-work.html";
    
    let activeFormFillTask = null;

// =======================================
// LOAD ADMIN CREATED FORM FILL TASK
// =======================================

async function loadFormFillTask(){

    const tasksRef =
        collection(
            db,
            "tasks"
        );

    const taskQuery =
        query(
            tasksRef,
            where(
                "category",
                "==",
                "Form Fill"
            ),
            where(
                "status",
                "==",
                "Active"
            ),
            
        );
        

    // ⚡ Start business settings while the task query is in flight.
    const settingsPromise =
        getBusinessSettings({ force: true });

    const [taskSnap, businessSettings] =
        await Promise.all([
            getDocs(taskQuery),
            settingsPromise
        ]);

    if(taskSnap.empty){

        return null;

    }

    const taskDoc =
        taskSnap.docs[0];

    const task = {
        id: taskDoc.id,
        ...taskDoc.data()
    };

    task.reward = getConfiguredTaskReward(task, businessSettings);

    return task;

}

// =======================================
// SHOW STATUS
// =======================================

function showStatus(
    message,
    className = "status locked"
){

    if(!statusBox)
        return;

    statusBox.innerHTML =
        message;

    statusBox.className =
        className;

}


// =======================================
// DISABLE START BUTTON
// =======================================

function disableTask(){

    if(startBtn){

        startBtn.style.display =
            "none";

        startBtn.disabled =
            true;

    }

}


// =======================================
// ENABLE START BUTTON
// =======================================

function enableTask(){

    if(startBtn){

        startBtn.style.display =
            "block";

        startBtn.disabled =
            false;

    }

}


// =======================================
// AUTH CHECK
// =======================================

onAuthStateChanged(
    auth,
    async(user)=>{

        // ===================================
        // NOT LOGGED IN
        // ===================================

        if(!user){

            window.location.href =
                "index.html";

            return;

        }


        // ===================================
        // INITIAL STATE
        // ===================================

        disableTask();

        showStatus(
            "⏳ Checking Task Status..."
        );


        try{

            // ===================================
            // LOAD USER DATA
            // ===================================

            const userRef =
                doc(
                    db,
                    "users",
                    user.uid
                );


            // ⚡ User and active task can be fetched independently.
            const [snap, taskResult] =
                await Promise.all([
                    getDoc(userRef),
                    loadFormFillTask()
                ]);


            // ===================================
            // USER DATA NOT FOUND
            // ===================================

            if(!snap.exists()){

                showStatus(
                    "⚠️ User Data Not Found"
                );

                disableTask();

                return;

            }


            const userData =
                snap.data();

// ===================================
// LOAD ADMIN FORM FILL TASK
// ===================================

activeFormFillTask =
    taskResult;

const formRewardElement =
    document.getElementById("taskReward");

if (formRewardElement && activeFormFillTask) {
    formRewardElement.textContent =
        `৳${Number(activeFormFillTask.reward || 0).toLocaleString("en-BD")}`;
}

if(!activeFormFillTask){

    showStatus(
        "⚠️ বর্তমানে কোনো Form Fill Task Active নেই।"
    );

    disableTask();

    return;

}

            // ===================================
            // ACCOUNT VERIFICATION
            // ===================================

            const verified =
                userData.verified === true ||
                userData.verified === "true";


            if(!verified){

                showStatus(
                    "🔒 Please Verify Your Account First"
                );

                disableTask();

                return;

            }


            // ===================================
            // TASK CHANCE CHECK
            // ===================================

            const chance =
                Number(
                    userData.taskChance || 0
                );


            if(chance < 1){

                showStatus(
                    "👥 Need 1 Referral = 1 Task Chance"
                );

                disableTask();

                return;

            }


            // ===================================
            // SELECTED TASK CHECK
            // ===================================

            const selectedTask =
                userData.selectedTask ||
                null;


            // ===================================
            // ANOTHER TASK SELECTED
            // ===================================

            if(
                selectedTask &&
                selectedTask !== "formfill"
            ){

                const taskNames = {

                    typing:
                        "Typing",

                    editing:
                        "Photo Editing",

                    microjob:
                        "Micro Job",

                    dataentry:
                        "Data Entry",

                    social:
                        "Social Task"

                };


                const selectedName =
                    taskNames[selectedTask] ||
                    selectedTask;


                showStatus(
                    `🔒 ${selectedName} Task Already Selected`
                );

                disableTask();

                return;

            }


            // ===================================
            // IMPORTANT
            // ===================================
            // Form Fill does NOT block the user
            // based on formfillTaskStatus.
            //
            // pending / approved / rejected
            // will NOT hide the Start button.
            //
            // Referral + taskChance is the
            // requirement to start the task.
            // ===================================


            // ===================================
            // READY
            // ===================================

            showStatus(
                "✅ Form Fill Task Ready",
                "status available"
            );


            enableTask();


            // ===================================
            // START FORM FILL
            // ===================================

            if(startBtn){

                startBtn.onclick =
    ()=>{

        window.location.href =
            `${TASK_PAGE}?taskId=${activeFormFillTask.id}`;

    };

            }

        }

        catch(error){

            console.error(
                "❌ Form Fill Task Error:",
                error
            );


            showStatus(
                "⚠️ Task Load করা যায়নি। আবার চেষ্টা করুন।"
            );

            disableTask();

        }

    }
);


console.log(
    "✅ NetEarn Pro Form Fill Task V4 Loaded"
);