// Niveles de calidad del mundo. El gobernador de fotogramas (layers/world.js) baja el factor de resolución y, si no basta,
// el nivel; el usuario puede fijar uno a mano. Todo son números: sin dependencias.
//  radius        trozos de 64 m a cada lado del jugador que se mantienen cargados
//  propsFull     hasta qué distancia (en trozos) los árboles y rocas son completos; propsLow: versión de pocos polígonos
//  grassNear/Far separación (m) de los mechones junto al jugador y algo más lejos; grassRange: radio de la hierba (m)
//  density       multiplicador de la cantidad de árboles
//  shadow        resolución del mapa de sombras (0 = sin sombras)
//  cloudShadow   sombras de las nubes sobre el suelo (0/1) · detail  detalle fino del suelo: granos, grietas, guijarros (0/1)
//  creatures     tope de criaturas vivas a la vez
//  footIK        pies adaptados a las cuestas e inclinación del cuerpo (0/1)
export const QUALITY = Object.freeze({
  low: { id: 'low', creatures: 2, label: 'Baja', radius: 4, propsFull: 0, propsLow: 2, grassNear: 1.0, grassFar: 1.4, grassRange: 46, density: 0.6, shadow: 1024, pixelRatio: 1, antialias: false, shadowSpan: 34, cloudShadow: 0, detail: 0, footIK: 1 },
  mid: { id: 'mid', creatures: 3, label: 'Media', radius: 5, propsFull: 1, propsLow: 3, grassNear: 0.7, grassFar: 1.05, grassRange: 56, density: 0.85, shadow: 1024, pixelRatio: 1.25, antialias: true, shadowSpan: 42, cloudShadow: 1, detail: 1, footIK: 1 },
  high: { id: 'high', creatures: 5, label: 'Alta', radius: 7, propsFull: 1, propsLow: 5, grassNear: 0.55, grassFar: 0.85, grassRange: 64, density: 1, shadow: 2048, pixelRatio: 1.75, antialias: true, shadowSpan: 50, cloudShadow: 1, detail: 1, footIK: 1 },
});
export const QUALITY_ORDER = ['low', 'mid', 'high'];

// Calidad inicial según el perfil del dispositivo (device.js): tier 'low' | 'mid' | 'high'.
export const qualityForTier = (tier) => QUALITY[tier] || QUALITY.mid;

// Distancia de visión (m): hasta donde llega el terreno cargado, con un margen para que el borde quede entre la niebla.
export const viewDistance = (q) => q.radius * 64 + 24;
