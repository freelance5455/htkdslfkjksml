// Atmósfera y luz del mundo. Todo son funciones puras del instante del día y del clima:
//  · posición del Sol y de la Luna;
//  · dispersión atmosférica (Rayleigh + Mie, una sola dispersión con sombra de la Tierra, así el crepúsculo es real);
//  · una tabla del cielo (LUT) que se calcula aquí y se sube a la GPU: el sombreador del cielo solo la consulta,
//    de modo que cielo, niebla, luz ambiente y color del Sol salen del MISMO cálculo y siempre concuerdan;
//  · luz directa, ambiente, niebla, exposición y visibilidad de las estrellas.
// Unidades relativas: la irradiancia solar fuera de la atmósfera es SUN_E; las luces de Three usan estos mismos valores.
export const DEG = Math.PI / 180;
export const SUN_E = 20;
// La dispersión simple da un cielo ≈ 2× más oscuro que el real frente al Sol (falta la dispersión múltiple y el rebote del suelo).
const SKY_BOOST = 2.3;

const RE = 6371e3; // radio de la Tierra (m)
const RA = RE + 80e3; // tope de la atmósfera
const H_R = 8000, H_M = 1200; // alturas de escala (Rayleigh, Mie)
const BETA_R = [5.8e-6, 13.5e-6, 33.1e-6];
const BETA_M = 14e-6;
const BETA_M_EXT = 1.1 * BETA_M;
const BETA_O = [0.65e-6, 1.881e-6, 0.085e-6]; // absorción del ozono (capa a 25 km): da el azul del crepúsculo
const G = 0.76; // anisotropía de Mie
const OBS = RE + 2; // el observador está casi a nivel del suelo
const N_VIEW = 8, N_LIGHT = 4;

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
const lum = (c) => 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];

// ── Sol y Luna ─────────────────────────────────────────────────────────────────────────────────
// Ejes del mundo: +X este, +Y arriba, +Z sur (así el sistema es de mano derecha, como el de Three.js, y el Sol sale por
// la derecha de quien mira al sur y se mueve en el sentido correcto). Latitud 40° N y declinación +14° (primavera/finales
// de verano): día de ≈ 13,6 h y Sol a 64° al mediodía.
const LAT = 40 * DEG, DECL = 14 * DEG;

function bodyDirection(hourAngle, lat, decl) {
  const sinE = Math.sin(lat) * Math.sin(decl) + Math.cos(lat) * Math.cos(decl) * Math.cos(hourAngle);
  const east = -Math.cos(decl) * Math.sin(hourAngle);
  const north = Math.sin(decl) * Math.cos(lat) - Math.cos(decl) * Math.sin(lat) * Math.cos(hourAngle);
  return [east, sinE, -north];
}
export function sunDirection(hours) {
  return bodyDirection((hours - 12) * 15 * DEG, LAT, DECL);
}
// La Luna va unos 13,7° por detrás cada día; aquí una fase fija (creciente casi llena) que cruza la noche entera.
export function moonDirection(hours) {
  return bodyDirection(((hours - 12) * 15 + 205) * DEG, LAT, 10 * DEG);
}

// ── Dispersión ─────────────────────────────────────────────────────────────────────────────────
// Densidad relativa del ozono a la altura h (triángulo centrado en 25 km, 15 km de semiancho).
const ozone = (h) => Math.max(0, 1 - Math.abs(h - 25000) / 15000);

// Profundidad óptica (Rayleigh, Mie, ozono) desde el punto P en la dirección D hasta el tope de la atmósfera.
// Devuelve null si la Tierra tapa esa dirección.
function lightDepth(px, py, pz, dx, dy, dz, out) {
  const r2 = px * px + py * py + pz * pz;
  const b = px * dx + py * dy + pz * dz;
  const discE = b * b - (r2 - RE * RE);
  if (discE > 0 && -b - Math.sqrt(discE) > 0) return false;
  const tFar = -b + Math.sqrt(b * b - (r2 - RA * RA));
  let dR = 0, dM = 0, dO = 0;
  for (let j = 0; j < N_LIGHT; j++) {
    const f0 = j / N_LIGHT, f1 = (j + 1) / N_LIGHT, fm = (j + 0.5) / N_LIGHT;
    const t = tFar * fm * fm, dt = tFar * (f1 * f1 - f0 * f0);
    const x = px + dx * t, y = py + dy * t, z = pz + dz * t;
    const h = Math.sqrt(x * x + y * y + z * z) - RE;
    dR += Math.exp(-h / H_R) * dt;
    dM += Math.exp(-h / H_M) * dt;
    dO += ozone(h) * dt;
  }
  out[0] = dR;
  out[1] = dM;
  out[2] = dO;
  return true;
}

const phaseR = (mu) => (3 / (16 * Math.PI)) * (1 + mu * mu);
const phaseM = (mu) => (3 / (8 * Math.PI)) * ((1 - G * G) * (1 + mu * mu)) / ((2 + G * G) * Math.pow(1 + G * G - 2 * G * mu, 1.5));

const tmpL = [0, 0, 0];
// Radiancia del cielo (RGB lineal) en la dirección `d` (d.y ≥ 0) con el Sol en `s`. Ambos unitarios.
export function skyRadiance(d, s, out = [0, 0, 0]) {
  const dy = Math.max(d[1], 0.0005);
  const inv = 1 / Math.hypot(d[0], dy, d[2]);
  const dx = d[0] * inv, dyn = dy * inv, dz = d[2] * inv;
  const b = OBS * dyn;
  const tMax = -b + Math.sqrt(b * b - (OBS * OBS - RA * RA));
  const mu = dx * s[0] + dyn * s[1] + dz * s[2];
  let odR = 0, odM = 0, odO = 0, sumR0 = 0, sumR1 = 0, sumR2 = 0, sumM0 = 0, sumM1 = 0, sumM2 = 0;
  for (let i = 0; i < N_VIEW; i++) {
    const f0 = i / N_VIEW, f1 = (i + 1) / N_VIEW, fm = (i + 0.5) / N_VIEW;
    const t = tMax * fm * fm, dt = tMax * (f1 * f1 - f0 * f0);
    const px = dx * t, py = OBS + dyn * t, pz = dz * t;
    const h = Math.sqrt(px * px + py * py + pz * pz) - RE;
    const dR = Math.exp(-h / H_R) * dt, dM = Math.exp(-h / H_M) * dt;
    odR += dR;
    odM += dM;
    odO += ozone(h) * dt;
    if (!lightDepth(px, py, pz, s[0], s[1], s[2], tmpL)) continue; // en la sombra de la Tierra
    const lR = tmpL[0], lM = tmpL[1], lO = tmpL[2];
    const mie = BETA_M_EXT * (odM + lM), oz = odO + lO;
    const a0 = Math.exp(-(BETA_R[0] * (odR + lR) + mie + BETA_O[0] * oz));
    const a1 = Math.exp(-(BETA_R[1] * (odR + lR) + mie + BETA_O[1] * oz));
    const a2 = Math.exp(-(BETA_R[2] * (odR + lR) + mie + BETA_O[2] * oz));
    sumR0 += dR * a0; sumR1 += dR * a1; sumR2 += dR * a2;
    sumM0 += dM * a0; sumM1 += dM * a1; sumM2 += dM * a2;
  }
  const pR = phaseR(mu), pM = phaseM(mu);
  out[0] = SKY_BOOST * SUN_E * (sumR0 * BETA_R[0] * pR + sumM0 * BETA_M * pM);
  out[1] = SKY_BOOST * SUN_E * (sumR1 * BETA_R[1] * pR + sumM1 * BETA_M * pM);
  out[2] = SKY_BOOST * SUN_E * (sumR2 * BETA_R[2] * pR + sumM2 * BETA_M * pM);
  return out;
}

// Transmitancia (RGB) de la luz directa del Sol hasta el suelo. 0 con el Sol bajo el horizonte.
const tmpT = [0, 0, 0];
export function sunTransmittance(s, out = [1, 1, 1]) {
  // Se suaviza el horizonte unos grados (el disco sigue visible un poco bajo la línea geométrica).
  const sy = Math.max(s[1], -0.02);
  const sx = s[0], sz = s[2];
  const l = Math.hypot(sx, sy, sz);
  const ok = lightDepth(0, OBS, 0, sx / l, sy / l, sz / l, tmpT);
  if (!ok) {
    out[0] = out[1] = out[2] = 0;
    return out;
  }
  const fade = smooth(-0.035, 0.012, s[1]);
  out[0] = Math.exp(-(BETA_R[0] * tmpT[0] + BETA_M_EXT * tmpT[1] + BETA_O[0] * tmpT[2])) * fade;
  out[1] = Math.exp(-(BETA_R[1] * tmpT[0] + BETA_M_EXT * tmpT[1] + BETA_O[1] * tmpT[2])) * fade;
  out[2] = Math.exp(-(BETA_R[2] * tmpT[0] + BETA_M_EXT * tmpT[1] + BETA_O[2] * tmpT[2])) * fade;
  return out;
}

// ── Tabla del cielo (LUT) ─────────────────────────────────────────────────────────────────────
// Eje u: ángulo de azimut respecto al Sol, u = √(φ/π) (más resolución junto al Sol).
// Eje v: elevación de la vista, v = √(e/(π/2)) (más resolución junto al horizonte).
export const LUT_W = 96, LUT_H = 48;

// Dirección de vista (referencial del Sol: azimut 0 = hacia el Sol) → coordenadas de la tabla.
export function lutCoords(d, s) {
  const hl = Math.hypot(d[0], d[2]), sl = Math.hypot(s[0], s[2]);
  let phi = 0;
  if (hl > 1e-6 && sl > 1e-6) phi = Math.acos(clamp((d[0] * s[0] + d[2] * s[2]) / (hl * sl), -1, 1));
  const e = Math.asin(clamp(d[1], 0, 1));
  return [Math.sqrt(phi / Math.PI), Math.sqrt(e / (Math.PI / 2))];
}

// Conversión de float32 a float16 (la tabla se sube como textura de media precisión: se filtra bien en WebGL 2).
const f32 = new Float32Array(1), u32 = new Uint32Array(f32.buffer);
export function toHalf(v) {
  f32[0] = v;
  const x = u32[0];
  const sign = (x >>> 16) & 0x8000;
  let exp = ((x >>> 23) & 0xff) - 127 + 15;
  const mant = x & 0x7fffff;
  if (exp >= 31) return sign | 0x7bff; // satura en el mayor valor finito
  if (exp <= 0) {
    if (exp < -10) return sign;
    return sign | ((mant | 0x800000) >> (1 - exp + 13));
  }
  return sign | (exp << 10) | (mant >> 13);
}
export function fromHalf(h) {
  const s = (h & 0x8000) ? -1 : 1, e = (h >> 10) & 31, m = h & 1023;
  if (e === 0) return s * Math.pow(2, -14) * (m / 1024);
  if (e === 31) return m ? NaN : s * Infinity;
  return s * Math.pow(2, e - 15) * (1 + m / 1024);
}

// La tabla se rellena por filas repartidas en varios fotogramas para no dar tirones.
export class SkyLut {
  constructor() {
    this.w = LUT_W;
    this.h = LUT_H;
    this.half = new Uint16Array(LUT_W * LUT_H * 4);
    this.sun = [0, 1, 0];
    this.row = LUT_H; // terminada
    this.version = 0;
  }
  // Empieza un nuevo cálculo para este Sol.
  begin(sunDir) {
    this.sun = sunDir.slice();
    this.row = 0;
  }
  get done() {
    return this.row >= this.h;
  }
  // Calcula `rows` filas. Devuelve true si la tabla cambió.
  step(rows) {
    if (this.done) return false;
    const se = Math.asin(clamp(this.sun[1], -1, 1));
    const sunLocal = [0, Math.sin(se), Math.cos(se)];
    const rgb = [0, 0, 0];
    const end = Math.min(this.h, this.row + rows);
    for (let j = this.row; j < end; j++) {
      const v = (j + 0.5) / this.h;
      const e = (Math.PI / 2) * v * v;
      for (let i = 0; i < this.w; i++) {
        const u = (i + 0.5) / this.w;
        const phi = Math.PI * u * u;
        const d = [Math.sin(phi) * Math.cos(e), Math.sin(e), Math.cos(phi) * Math.cos(e)];
        skyRadiance(d, sunLocal, rgb);
        const o = (j * this.w + i) * 4;
        this.half[o] = toHalf(rgb[0]);
        this.half[o + 1] = toHalf(rgb[1]);
        this.half[o + 2] = toHalf(rgb[2]);
        this.half[o + 3] = 0x3c00; // 1.0
      }
    }
    this.row = end;
    this.version++;
    return true;
  }
  // Rellena la tabla entera de golpe (pruebas y primer fotograma).
  fill(sunDir) {
    this.begin(sunDir);
    this.step(this.h);
  }
  // Lectura bilineal en CPU: la misma que hace el sombreador. Devuelve RGB lineal.
  sample(d, out = [0, 0, 0]) {
    const [u, v] = lutCoords(d, this.sun);
    const fx = clamp(u * this.w - 0.5, 0, this.w - 1), fy = clamp(v * this.h - 0.5, 0, this.h - 1);
    const i = Math.min(this.w - 2, Math.floor(fx)), j = Math.min(this.h - 2, Math.floor(fy));
    const tx = fx - i, ty = fy - j;
    for (let k = 0; k < 3; k++) {
      const a = fromHalf(this.half[(j * this.w + i) * 4 + k]), b = fromHalf(this.half[(j * this.w + i + 1) * 4 + k]);
      const c = fromHalf(this.half[((j + 1) * this.w + i) * 4 + k]), e = fromHalf(this.half[((j + 1) * this.w + i + 1) * 4 + k]);
      out[k] = (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + e * tx) * ty;
    }
    return out;
  }
}

// ── Estado de la escena ─────────────────────────────────────────────────────────────────────────
export const WEATHER = Object.freeze({
  clear: { cloud: 0.32, fog: 1, label: 'Despejado' },
  cloudy: { cloud: 0.78, fog: 1.35, label: 'Nublado' },
  foggy: { cloud: 0.6, fog: 5, label: 'Niebla' },
});

// Referencia de brillo: radiancia de una superficie gris (albedo 0,18) iluminada por el Sol, el cielo y la Luna.
function sceneLuma(sunLum, sinE, ambLum, moonLum) {
  return 0.18 * ((sunLum * Math.max(sinE, 0)) / Math.PI + ambLum + moonLum / Math.PI);
}

const AMB_DIRS = (() => {
  // Direcciones (referencial del Sol) con peso para promediar la radiancia del hemisferio.
  const dirs = [[0, 1, 0, 0.26]];
  for (const [elev, w] of [[50, 0.5], [18, 0.24]]) {
    for (let k = 0; k < 4; k++) {
      const az = (k * 90 * Math.PI) / 180, e = (elev * Math.PI) / 180;
      dirs.push([Math.sin(az) * Math.cos(e), Math.sin(e), Math.cos(az) * Math.cos(e), w / 4]);
    }
  }
  return dirs;
})();

// Calcula todo lo que el renderizador necesita para un instante. `lut` debe estar rellena para el Sol de `hours`
// (si no, se usa la que tenga: el cielo converge en unos fotogramas). `camAz` = acimut (rad) hacia donde mira la cámara.
export function atmosphereState(hours, weather = WEATHER.clear, lut = null, camAz = 0) {
  const sun = sunDirection(hours);
  const moon = moonDirection(hours);
  const sunElev = Math.asin(clamp(sun[1], -1, 1));
  const t = sunTransmittance(sun);
  const cloud = clamp(weather.cloud, 0, 1);
  // Las nubes tapan el Sol: menos luz directa (y más difusa).
  const directK = 1 - 0.82 * Math.pow(cloud, 1.4);
  const sunColor = [SUN_E * t[0] * directK, SUN_E * t[1] * directK, SUN_E * t[2] * directK];

  // Luz ambiente: promedio de la radiancia del cielo (referencial del Sol) → irradiancia π·L.
  const sl = [0, Math.sin(sunElev), Math.cos(sunElev)];
  const avg = [0, 0, 0];
  const tmp = [0, 0, 0];
  // Las direcciones de AMB_DIRS están en el referencial del Sol (acimut 0 = hacia el Sol): para la tabla, que se consulta
  // con direcciones del mundo, se giran al acimut real del Sol.
  const sAz = Math.atan2(sun[0], sun[2]);
  const cA = Math.cos(sAz), sA = Math.sin(sAz);
  for (const [x, y, z, w] of AMB_DIRS) {
    if (lut) lut.sample([x * cA + z * sA, y, -x * sA + z * cA], tmp);
    else skyRadiance([x, y, z], sl, tmp);
    avg[0] += tmp[0] * w;
    avg[1] += tmp[1] * w;
    avg[2] += tmp[2] * w;
  }
  // Con la tabla el promedio se lee en el referencial del Sol; si el Sol está bajo el horizonte la tabla da el brillo del crepúsculo.
  const dark = smooth(0.05, -0.2, sun[1]);
  // Resplandor nocturno mínimo del cielo (cielo estrellado + luna): evita negros absolutos.
  const moonUp = smooth(-0.02, 0.18, moon[1]);
  const moonAmt = moonUp * smooth(0.1, -0.12, sun[1]); // la Luna solo ilumina de noche
  const nightSky = [0.0022, 0.0034, 0.0075];
  const skyLo = [avg[0] + nightSky[0] * (2.4 + 4 * moonAmt), avg[1] + nightSky[1] * (2.4 + 4 * moonAmt), avg[2] + nightSky[2] * (2.4 + 4 * moonAmt)]; // luz de las estrellas y del aire (más de lo real: que se vea el suelo)
  const flat = 1 + 0.35 * cloud; // el cielo cubierto ilumina más parejo
  const skyAmb = [Math.PI * skyLo[0] * flat, Math.PI * skyLo[1] * flat, Math.PI * skyLo[2] * flat];
  const groundAlbedo = [0.2, 0.19, 0.13];
  const sunHorizontal = SUN_E * Math.max(sun[1], 0);
  const groundAmb = [0, 1, 2].map((k) => groundAlbedo[k] * (sunHorizontal * t[k] * directK + skyAmb[k]) + 0.0008);

  // Luna: luz direccional azulada y tenue.
  const moonLight = 0.17 * moonAmt;
  const moonColor = [0.62 * moonLight, 0.74 * moonLight, 1 * moonLight];

  // Niebla: color del horizonte hacia donde mira la cámara (más clara hacia el Sol).
  const fogDir = [Math.sin(camAz) * Math.cos(0.05), Math.sin(0.05), Math.cos(camAz) * Math.cos(0.05)];
  // El color del horizonte se lee del mismo cielo que se dibuja: lejos del Sol (fogRgb) y hacia el Sol (fogSunRgb).
  const sunHz = Math.hypot(sun[0], sun[2]) || 1;
  const sunFogDir = [(sun[0] / sunHz) * Math.cos(0.05), Math.sin(0.05), (sun[2] / sunHz) * Math.cos(0.05)];
  const fogRgb = lut ? lut.sample(fogDir, [0, 0, 0]) : skyRadiance(fogDir, sun, [0, 0, 0]);
  const fogSunRgb = lut ? lut.sample(sunFogDir, [0, 0, 0]) : skyRadiance(sunFogDir, sun, [0, 0, 0]);
  const gray = lum(fogRgb);
  const fogy = smooth(1.5, 3.5, weather.fog); // 0 con tiempo claro … 1 con niebla (continuo: el clima cambia poco a poco)
  const fogMix = clamp(0.25 * cloud + 0.4 * fogy, 0, 0.7);
  const fogColor = [0, 1, 2].map((k) => (fogRgb[k] * (1 - fogMix) + gray * fogMix + nightSky[k] * 0.8) * flat);
  const grayS = lum(fogSunRgb);
  const fogSunColor = [0, 1, 2].map((k) => (fogSunRgb[k] * (1 - fogMix) + grayS * fogMix + nightSky[k] * 0.8) * flat);
  const fogDensity = (1 / 270) * weather.fog * (1 - 0.45 * fogy);

  const ambLum = lum(skyAmb) / Math.PI;
  const luma = sceneLuma(lum(sunColor), sun[1], ambLum, lum(moonColor) * 3.1416);
  // Exposición: el ojo se adapta (sube al caer la luz) sin igualar el día con la noche. Brillo objetivo de la
  // superficie gris de referencia: ≈ 0,29 a pleno día, ≈ 0,09 al anochecer y ≈ 0,06 de noche (con luna).
  const target = 0.235 * Math.pow(Math.max(luma, 1e-5) / 0.8, 0.45);
  const exposure = clamp(target / Math.max(luma, 1e-5), 0.28, 8);

  return {
    hours, sun, moon, sunElev,
    sunColor, sunTransmittance: t, directK,
    moonColor, moonAmt,
    skyAmbient: skyAmb, groundAmbient: groundAmb,
    fogColor, fogSunColor, fogDensity,
    exposure, luma,
    stars: smooth(-0.05, -0.2, sun[1]) * (1 - 0.85 * cloud),
    cloud,
    // Color de las nubes iluminadas (blanco cálido al amanecer, gris azulado de noche).
    cloudLight: [sunColor[0] * 0.05 + skyAmb[0] * 0.2 + 0.004, sunColor[1] * 0.05 + skyAmb[1] * 0.2 + 0.004, sunColor[2] * 0.05 + skyAmb[2] * 0.2 + 0.006],
    dayAmount: 1 - dark,
  };
}

// Hora formateada hh:mm.
export function formatHours(h) {
  const t = ((h % 24) + 24) % 24;
  const hh = Math.floor(t), mm = Math.floor((t - hh) * 60);
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

// Tono ACES de Three.js (para comprobar el brillo en pruebas): entrada lineal ya multiplicada por la exposición.
export function acesTone(c, exposure = 1) {
  const e = exposure / 0.6;
  let r = c[0] * e, g = c[1] * e, b = c[2] * e;
  const m1 = [[0.59719, 0.35458, 0.04823], [0.076, 0.90834, 0.01566], [0.0284, 0.13383, 0.83777]];
  const m2 = [[1.60475, -0.53108, -0.07367], [-0.10208, 1.10813, -0.00605], [-0.00327, -0.07276, 1.07602]];
  const mulM = (m, v) => [m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2], m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2], m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2]];
  const rrt = (v) => (v * (v + 0.0245786) - 0.000090537) / (v * (0.983729 * v + 0.432951) + 0.238081);
  let v = mulM(m1, [r, g, b]).map(rrt);
  v = mulM(m2, v).map((x) => clamp(x, 0, 1));
  return v;
}
export const linearToSrgb = (v) => (v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055);
