// Colocación determinista de árboles, rocas y arbustos. Cada celda de la rejilla del mundo decide, solo con
// su posición, si hay algo y qué es: el mismo trozo siempre sale igual y los vecinos encajan sin solaparse.
import { heightAt, normalAt, surfaceAt, CHUNK, SPAWN } from './terrain.js';
import { hash01, fbm2, smoothstep, mix } from './noise.js';
import { TREE_TRUNK, TREE_CANOPY } from './geometry.js';

const SEED = 4242;
const TREE_CELL = 8; // 8×8 celdas por trozo (CHUNK = 64), dos candidatos por celda
const ROCK_CELL = 16;
const BUSH_CELL = 8;
const SPAWN_CLEAR = 15; // sin árboles ni rocas cerca del punto de aparición

// 0 = pradera abierta, 1 = bosque denso.
export function forestAt(x, z) {
  return smoothstep(-0.1, 0.3, fbm2(x * 0.0042, z * 0.0042, 3, SEED));
}

// Interpolación bilineal de la rejilla de alturas de un trozo (la que se dibuja), en coordenadas locales.
export function sampleGrid(grid, side, cell, lx, lz) {
  const fx = Math.min(side - 1.001, Math.max(0, lx / cell)), fz = Math.min(side - 1.001, Math.max(0, lz / cell));
  const i = Math.floor(fx), j = Math.floor(fz);
  const tx = fx - i, tz = fz - j;
  const a = grid[j * side + i], b = grid[j * side + i + 1], c = grid[(j + 1) * side + i], d = grid[(j + 1) * side + i + 1];
  return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz;
}

const nrm = [0, 1, 0];

// Objetos del trozo (cx, cz). `terrain` aporta la rejilla de alturas para que las bases queden sobre la malla dibujada.
// density: multiplicador de la cantidad de árboles (calidad).
export function scatterChunk(cx, cz, terrain, density = 1) {
  const { heights, side, cell } = terrain;
  const x0 = cx * CHUNK, z0 = cz * CHUNK;
  const trees = [], rocks = [], bushes = [];
  const yAt = (x, z) => sampleGrid(heights, side, cell, x - x0, z - z0);
  const clearSpawn = (x, z) => Math.hypot(x - SPAWN[0], z - SPAWN[1]) < SPAWN_CLEAR;

  const perChunk = CHUNK / TREE_CELL;
  for (let gj = 0; gj < perChunk; gj++) {
    for (let gi = 0; gi < perChunk; gi++) {
      const gx = cx * perChunk + gi, gz = cz * perChunk + gj;
      for (let slot = 0; slot < 2; slot++) {
        const k = SEED + 100 + slot * 977;
        const x = (gx + 0.12 + 0.76 * hash01(gx, gz, k + 1)) * TREE_CELL;
        const z = (gz + 0.12 + 0.76 * hash01(gx, gz, k + 2)) * TREE_CELL;
        const forest = forestAt(x, z);
        if (hash01(gx, gz, k + 3) > (0.02 + 0.5 * forest) * density) continue;
        const h = heightAt(x, z);
        if (h < 0.9 || h > 90 || clearSpawn(x, z)) continue;
        normalAt(x, z, 0.8, nrm);
        if (nrm[1] < 0.84) continue;
        const cold = smoothstep(36, 72, h + fbm2(x * 0.01, z * 0.01, 2, SEED + 7) * 14);
        const r = hash01(gx, gz, k + 4);
        const kind = r < cold * 0.9 + 0.1 ? 'conifer' : hash01(gx, gz, k + 5) < 0.22 ? 'birch' : 'broadleaf';
        const s = (kind === 'conifer' ? 0.8 : 0.78) + 0.65 * hash01(gx, gz, k + 6);
        trees.push({
          kind, x, z, y: yAt(x, z) - 0.15, s,
          rot: hash01(gx, gz, k + 7) * Math.PI * 2,
          variant: hash01(gx, gz, k + 8),
          tilt: [(hash01(gx, gz, k + 9) - 0.5) * 0.08, (hash01(gx, gz, k + 10) - 0.5) * 0.08],
          r: TREE_TRUNK[kind] * s * 1.15,
          canopy: TREE_CANOPY[kind] * s,
        });
      }
    }
  }

  const rockCells = CHUNK / ROCK_CELL;
  for (let gj = 0; gj < rockCells; gj++) {
    for (let gi = 0; gi < rockCells; gi++) {
      const gx = cx * rockCells + gi, gz = cz * rockCells + gj;
      const x = (gx + 0.15 + 0.7 * hash01(gx, gz, SEED + 301)) * ROCK_CELL;
      const z = (gz + 0.15 + 0.7 * hash01(gx, gz, SEED + 302)) * ROCK_CELL;
      const h = heightAt(x, z);
      if (h < -0.6 || clearSpawn(x, z)) continue;
      normalAt(x, z, 0.8, nrm);
      const p = 0.2 + 0.5 * smoothstep(0.1, 0.4, 1 - nrm[1]) + 0.3 * smoothstep(50, 95, h);
      if (hash01(gx, gz, SEED + 303) > p) continue;
      const q = hash01(gx, gz, SEED + 304);
      const s = 0.5 + 2.2 * q * q;
      rocks.push({ kind: 'rock', x, z, y: yAt(x, z) - 0.12 * s, s, rot: hash01(gx, gz, SEED + 305) * Math.PI * 2, variant: hash01(gx, gz, SEED + 306), tilt: [(hash01(gx, gz, SEED + 307) - 0.5) * 0.3, (hash01(gx, gz, SEED + 308) - 0.5) * 0.3], r: 1.15 * s, canopy: 0 });
    }
  }

  const bushCells = CHUNK / BUSH_CELL;
  for (let gj = 0; gj < bushCells; gj++) {
    for (let gi = 0; gi < bushCells; gi++) {
      const gx = cx * bushCells + gi, gz = cz * bushCells + gj;
      const x = (gx + 0.1 + 0.8 * hash01(gx, gz, SEED + 401)) * BUSH_CELL;
      const z = (gz + 0.1 + 0.8 * hash01(gx, gz, SEED + 402)) * BUSH_CELL;
      const forest = forestAt(x, z);
      if (hash01(gx, gz, SEED + 403) > (0.03 + 0.3 * mix(0.4, 1, forest)) * density) continue;
      const h = heightAt(x, z);
      if (h < 1 || h > 70 || clearSpawn(x, z)) continue;
      normalAt(x, z, 0.8, nrm);
      if (nrm[1] < 0.8) continue;
      const s = 0.7 + 0.8 * hash01(gx, gz, SEED + 404);
      bushes.push({ kind: 'bush', x, z, y: yAt(x, z) - 0.05, s, rot: hash01(gx, gz, SEED + 405) * Math.PI * 2, variant: hash01(gx, gz, SEED + 406), tilt: [0, 0], r: 0.45 * s, canopy: 0 });
    }
  }
  return { trees, rocks, bushes };
}

// Mechones de hierba: cuadrícula con desplazamiento aleatorio sobre la malla del trozo. Cada mechón guarda 8 números:
// x, y, z (relativos a la esquina del trozo), escala, giro, exuberancia, flor (−1 = sin flor, o el tono 0..4) y sombra de copa.
export const GRASS_STRIDE = 8;
export function grassChunk(cx, cz, terrain, trees, spacing) {
  if (!(spacing > 0)) return { data: new Float32Array(0), count: 0 };
  const { heights, side, cell, minY } = terrain;
  if (minY > 110) return { data: new Float32Array(0), count: 0 };
  const x0 = cx * CHUNK, z0 = cz * CHUNK;
  const n = Math.floor(CHUNK / spacing);
  const out = new Float32Array(n * n * GRASS_STRIDE);
  // Árboles por cubos de 8 m para la sombra de copa.
  const bucket = new Map();
  for (const t of trees) {
    const key = Math.floor((t.x - x0) / 8) * 1000 + Math.floor((t.z - z0) / 8);
    (bucket.get(key) || bucket.set(key, []).get(key)).push(t);
  }
  let c = 0;
  const surf = { grass: 1, rock: 0, sand: 0, snow: 0, lush: 0.5, wet: 0 };
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const gx = cx * n + i, gz = cz * n + j;
      const lx = (i + hash01(gx, gz, SEED + 501)) * spacing, lz = (j + hash01(gx, gz, SEED + 502)) * spacing;
      const x = x0 + lx, z = z0 + lz;
      const y = sampleGrid(heights, side, cell, lx, lz);
      if (y < 0.55 || y > 80) continue;
      // Pendiente y composición con la misma función del terreno, a partir de la rejilla.
      const dx = sampleGrid(heights, side, cell, lx - 0.7, lz) - sampleGrid(heights, side, cell, lx + 0.7, lz);
      const dz = sampleGrid(heights, side, cell, lx, lz - 0.7) - sampleGrid(heights, side, cell, lx, lz + 0.7);
      const ny = 1.4 / Math.hypot(dx, 1.4, dz);
      if (ny < 0.72) continue;
      // El terreno decide cuánta hierba hay (más rala hacia la roca, la arena y la nieve).
      surfaceAt(x, z, y, ny, surf);
      const keep = surf.grass * (0.35 + 0.65 * surf.lush);
      if (hash01(gx, gz, SEED + 503) > keep) continue;
      let shade = 1;
      const bx = Math.floor(lx / 8), bz = Math.floor(lz / 8);
      for (let a = -1; a <= 1; a++) {
        for (let b = -1; b <= 1; b++) {
          const list = bucket.get((bx + a) * 1000 + (bz + b));
          if (!list) continue;
          for (const t of list) {
            const d = Math.hypot(t.x - x, t.z - z);
            if (d < t.canopy * 1.1) shade = Math.min(shade, 0.45 + 0.55 * smoothstep(t.canopy * 0.35, t.canopy * 1.1, d));
          }
        }
      }
      const o = c * GRASS_STRIDE;
      const flower = hash01(gx, gz, SEED + 504) < 0.05 * surf.lush && shade > 0.9 ? Math.floor(hash01(gx, gz, SEED + 505) * 5) : -1;
      out[o] = lx;
      out[o + 1] = y;
      out[o + 2] = lz;
      out[o + 3] = (0.75 + 0.6 * hash01(gx, gz, SEED + 506)) * (0.7 + 0.5 * surf.lush);
      out[o + 4] = hash01(gx, gz, SEED + 507) * Math.PI * 2;
      out[o + 5] = surf.lush;
      out[o + 6] = flower;
      out[o + 7] = shade;
      c++;
    }
  }
  return { data: out.slice(0, c * GRASS_STRIDE), count: c };
}
