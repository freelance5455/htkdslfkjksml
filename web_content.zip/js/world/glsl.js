// Código GLSL del mundo (cadenas de texto). Sin dependencias: se puede compilar y probar fuera de Three.js.
//
// Convenciones:
//  · Todo el color se calcula en RGB lineal «HDR» (radiancia relativa, ver atmosphere.js) y Three.js hace después el
//    mapeo de tonos (ACES) y la codificación sRGB. Por eso la niebla, el cielo, el agua y las luces concuerdan.
//  · Las funciones propias llevan el prefijo rw para no chocar con las de Three.js.
//  · Los sombreadores de cielo y agua son ShaderMaterial (Three.js añade su prefijo: precision, texture2D→texture, etc.);
//    el suelo, los árboles, la hierba y el personaje son MeshStandardMaterial con pequeños fragmentos inyectados.

// ── Uniformes compartidos y funciones comunes ────────────────────────────────────────────────────────────────
export const GLSL_SHARED = /* glsl */ `
uniform sampler2D uNoise;      // ruido repetible RGBA (ver noiseTexture.js)
uniform sampler2D uSkyLut;     // radiancia del cielo despejado (referencial del Sol: acimut 0 = hacia el Sol)
uniform vec3 uSunDir;          // dirección HACIA el Sol (mundo)
uniform vec3 uFogColor;        // color de la bruma en el horizonte (radiancia lineal)
uniform vec3 uFogSunColor;     // idem, hacia el Sol
uniform float uFogDensity;     // 1/m
uniform vec2 uFogFar;          // distancia donde el mundo se funde del todo con el cielo (inicio, fin)
uniform float uTime;
uniform float uWind;
uniform vec2 uFx;              // efectos por calidad: x = sombras de nubes (0..1), y = detalle fino del suelo (0..1)

float rwHash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
float rwHash13(vec3 p3) {
  p3 = fract(p3 * 0.1031);
  p3 += dot(p3, p3.zyx + 31.32);
  return fract((p3.x + p3.y) * p3.z);
}
vec2 rwRot(vec2 p, float a) {
  float c = cos(a), s = sin(a);
  return vec2(c * p.x - s * p.y, s * p.x + c * p.y);
}

// Radiancia del cielo despejado en la dirección d (unitaria, mundo). Misma tabla que usa la CPU para luz y niebla.
vec3 rwSkyLut(vec3 d) {
  float e = asin(clamp(d.y, 0.0, 1.0));
  vec2 sh = normalize(uSunDir.xz + vec2(1e-5, 0.0));
  float hl = length(d.xz);
  float phi = 0.0;
  if (hl > 1e-5) phi = acos(clamp(dot(d.xz / hl, sh), -1.0, 1.0));
  return texture2D(uSkyLut, vec2(sqrt(phi * 0.3183098862), sqrt(e * 0.6366197724))).rgb;
}

// Perspectiva aérea: mezcla el color con la bruma según la distancia. rel = punto − cámara (mundo).
vec3 rwFog(vec3 col, vec3 rel) {
  float d = length(rel);
  vec3 rd = rel / max(d, 1e-4);
  float f = 1.0 - exp(-d * uFogDensity);
  f = max(f, smoothstep(uFogFar.x, uFogFar.y, d));
  vec3 fc = mix(uFogColor, uFogSunColor, pow(max(dot(rd, uSunDir), 0.0), 8.0));
  return mix(col, fc, clamp(f, 0.0, 1.0));
}
`;

// ── Nubes: densidad en la capa (la usan el cielo y las sombras sobre el suelo, para que coincidan) ───────────
export const GLSL_CLOUD_FN = /* glsl */ `
float rwClouds(vec2 uv, float cover) {
  float a = texture2D(uNoise, uv).r;
  float b = texture2D(uNoise, uv * 2.9 + vec2(0.37, 0.11)).g;
  float c = texture2D(uNoise, uv * 0.37 + vec2(0.71, 0.53)).b;
  float n = a * 0.6 + b * 0.24 + c * 0.16;
  float thr = 0.78 - 1.02 * pow(cover, 1.35);
  return smoothstep(thr, thr + 0.26, n);
}
`;

// Sombra de las nubes sobre un punto del mundo: se sigue el rayo hacia el Sol hasta la capa (a 2200 m) y se mira si hay nube.
// Solo para materiales estándar (suelo, árboles, hierba, personaje); se aplica a la luz saliente antes de la niebla.
export const GLSL_CLOUD_SHADOW = /* glsl */ `
uniform float uCloud;
uniform vec2 uCloudDrift;
${GLSL_CLOUD_FN}
float rwCloudShadow(vec3 wp) {
  if (uFx.x < 0.01 || uSunDir.y < 0.05) return 1.0;
  vec2 uv = (wp.xz + uSunDir.xz * ((2200.0 - wp.y) / uSunDir.y)) / 12000.0 + uCloudDrift;
  float dens = rwClouds(uv, uCloud);
  float sunK = smoothstep(0.05, 0.32, uSunDir.y);
  return 1.0 - 0.46 * dens * sunK * uFx.x * (1.0 - 0.55 * uCloud);
}
`;

// ── Cielo ────────────────────────────────────────────────────────────────────────────────────────────────────
export const SKY_VERT = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = position;
  vec4 p = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
  gl_Position = vec4(p.xy, p.w * 0.99999, p.w); // siempre al fondo, sin depender del radio de la esfera
}
`;

export const SKY_FRAG = /* glsl */ `
varying vec3 vDir;
${GLSL_SHARED}
uniform vec3 uSunDisc;     // transmitancia directa del Sol (RGB 0..1; ya incluye las nubes que lo tapan)
uniform vec3 uMoonDir;
uniform vec3 uCloudLight;  // color de las nubes iluminadas (HDR)
uniform vec3 uNightGlow;   // resplandor mínimo del cielo nocturno
uniform float uStars;
uniform float uCloud;      // 0..1 cobertura
uniform float uHaze;       // 0..1 bruma baja (niebla)
uniform float uMoonVis;
uniform float uExposure;
uniform vec2 uCloudDrift;  // desplazamiento de las nubes (en repeticiones de la textura)

const float SUN_R = 0.0085;   // radio angular del Sol (rad), algo mayor que el real para que se vea bien en pantalla
const float MOON_R = 0.012;

${GLSL_CLOUD_FN}

vec3 rwStars(vec3 d) {
  vec3 q = d * 80.0;
  vec3 ci = floor(q);
  vec3 cf = fract(q);
  float h = rwHash13(ci);
  if (h < 0.92) return vec3(0.0);
  vec3 sp = 0.2 + 0.6 * vec3(rwHash13(ci + 7.1), rwHash13(ci + 13.7), rwHash13(ci + 3.9));
  float dd = length(cf - sp);
  float mag = 0.25 + 0.75 * rwHash13(ci + 1.3);
  float tw = 0.85 + 0.15 * sin(uTime * 2.7 + h * 60.0);
  vec3 tint = mix(vec3(0.75, 0.88, 1.15), vec3(1.2, 1.02, 0.82), rwHash13(ci + 9.2));
  return tint * smoothstep(0.085, 0.0, dd) * mag * mag * tw;
}

void main() {
  vec3 d = normalize(vDir);
  float up = max(d.y, 0.0);

  // Cielo despejado + resplandor nocturno + cielo cubierto (gris y algo más oscuro).
  vec3 sky = rwSkyLut(d);
  sky += uNightGlow * (1.0 + 1.5 * (1.0 - up));
  float lum = dot(sky, vec3(0.2126, 0.7152, 0.0722));
  sky = mix(sky, vec3(lum) * vec3(0.94, 0.97, 1.0), uCloud * 0.85);
  sky *= mix(1.0, 0.78, uCloud);

  vec3 col = sky;

  // Estrellas.
  if (uStars > 0.001 && d.y > 0.0) col += rwStars(d) * (2.2 / max(uExposure, 0.1)) * uStars;

  // Luna: disco con fase (iluminado por el Sol) y manchas oscuras.
  float mcs = dot(d, uMoonDir);
  if (mcs > 0.0 && uMoonVis > 0.001) {
    float ang = atan(length(cross(d, uMoonDir)), mcs);
    vec3 tx = normalize(cross(vec3(0.0, 1.0, 0.0), uMoonDir));
    vec3 ty = cross(uMoonDir, tx);
    vec2 q = vec2(dot(d, tx), dot(d, ty)) / MOON_R;
    float r2 = dot(q, q);
    if (r2 < 1.0) {
      vec3 n = vec3(q.x, q.y, sqrt(1.0 - r2));
      vec3 L = normalize(vec3(dot(uSunDir, tx), dot(uSunDir, ty), -dot(uSunDir, uMoonDir)));
      float lit = smoothstep(-0.04, 0.12, dot(n, L));
      float maria = 0.55 + 0.45 * smoothstep(0.35, 0.65, texture2D(uNoise, q * 0.32 + 0.5).a);
      float edge = smoothstep(1.0, 0.94, sqrt(r2));
      col += vec3(1.0, 0.97, 0.9) * (2.0 / max(uExposure, 0.1)) * 0.7 * lit * maria * edge * uMoonVis;
    }
    col += vec3(0.7, 0.8, 1.0) * exp(-ang * 38.0) * 0.12 * uMoonVis / max(uExposure, 0.1);
  }

  // Sol: disco con oscurecimiento del borde + corona. El color conserva el tono de la transmitancia (rojizo al atardecer).
  float scs = dot(d, uSunDir);
  float m = max(max(uSunDisc.r, uSunDisc.g), uSunDisc.b);
  if (scs > 0.0 && m > 0.0005) {
    float ang = atan(length(cross(d, uSunDir)), scs);
    vec3 hue = uSunDisc / m;
    float vis = smoothstep(0.0, 0.05, m) * (1.0 - 0.9 * uHaze);
    float r = ang / SUN_R;
    float disc = smoothstep(1.0, 0.9, r) * (1.0 - 0.35 * r * r);
    col += hue * disc * vis * (3.0 / max(uExposure, 0.1));
    float halo = 2.0 * exp(-ang * 48.0) + 0.3 * exp(-ang * 9.0);
    col += hue * halo * vis * (1.1 / max(uExposure, 0.1));
  }

  // Nubes en una capa a 2200 m, con sombra propia hacia el Sol y borde plateado.
  if (d.y > 0.0) {
    float t = 2200.0 / max(d.y, 0.03);
    vec2 uv = d.xz * t / 12000.0 + uCloudDrift;
    float dens = rwClouds(uv, uCloud);
    if (dens > 0.001) {
      vec2 sOff = uSunDir.xz / max(uSunDir.y, 0.22) * 0.018;
      float shade = rwClouds(uv + sOff, uCloud);
      float light = clamp(1.0 - shade * 0.85 + 0.15 * (1.0 - dens), 0.0, 1.0);
      vec3 cl = uCloudLight * (0.32 + 0.95 * light);
      cl *= mix(1.0, 0.6, dens * uCloud);
      float cs = max(dot(d, uSunDir), 0.0);
      cl += uCloudLight * 1.6 * pow(cs, 8.0) * (1.0 - dens) * light;
      float fadeH = smoothstep(0.015, 0.17, d.y);
      float alpha = dens * fadeH * 0.97;
      col = mix(col, cl, alpha);
    }
  }

  // Bruma baja: se funde con el mismo color con que el terreno lejano se pierde en el horizonte; bajo el horizonte, igual.
  vec3 fc = mix(uFogColor, uFogSunColor, pow(max(dot(normalize(vec3(d.x, 0.02, d.z)), uSunDir), 0.0), 8.0));
  float width = 0.1 + 0.45 * uHaze;
  float hz = 1.0 - smoothstep(0.0, width, up);
  col = mix(col, fc, hz);

  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
  gl_FragColor.rgb += (rwHash12(gl_FragCoord.xy + fract(uTime) * 61.0) - 0.5) / 255.0; // evita bandas en el degradado
}
`;

// ── Agua ─────────────────────────────────────────────────────────────────────────────────────────────────────
export const WATER_VERT = /* glsl */ `
attribute float aDepth;   // profundidad del fondo bajo la superficie (m); negativa en tierra
varying vec3 vWorld;
varying float vDepth;
void main() {
  vec4 w = modelMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  vDepth = aDepth;
  gl_Position = projectionMatrix * viewMatrix * w;
}
`;

export const WATER_FRAG = /* glsl */ `
varying vec3 vWorld;
varying float vDepth;
${GLSL_SHARED}
uniform vec3 uSunDisc;
uniform vec3 uLightE;     // (luz del Sol + del cielo) / π sobre una superficie horizontal: ilumina el fondo y la espuma
uniform float uExposure;
uniform float uCloud;

float rwWaveH(vec2 p) {
  float t = uTime;
  float h = texture2D(uNoise, p * 0.021 + vec2(t * 0.011, t * 0.007)).a * 0.9;
  h += texture2D(uNoise, p * 0.063 - vec2(t * 0.019, -t * 0.013)).a * 0.45;
  h += texture2D(uNoise, p * 0.19 + vec2(-t * 0.031, t * 0.027)).a * 0.2;
  return h;
}

void main() {
  vec3 rel = vWorld - cameraPosition;
  float dist = length(rel);
  vec3 V = -rel / max(dist, 1e-4);

  // Normal de las olas: pendiente del campo de alturas (se suaviza con la distancia para que no centellee).
  float e = 0.35;
  float h0 = rwWaveH(vWorld.xz);
  float hx = rwWaveH(vWorld.xz + vec2(e, 0.0));
  float hz = rwWaveH(vWorld.xz + vec2(0.0, e));
  float k = 0.55 * (1.0 - smoothstep(50.0, 230.0, dist));
  vec3 n = normalize(vec3(-(hx - h0) / e * k, 1.0, -(hz - h0) / e * k));

  float ndv = max(dot(n, V), 0.0);
  float F = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);

  vec3 R = reflect(-V, n);
  R.y = max(R.y, 0.015);
  R = normalize(R);
  vec3 refl = rwSkyLut(R);
  float lumR = dot(refl, vec3(0.2126, 0.7152, 0.0722));
  refl = mix(refl, vec3(lumR) * vec3(0.94, 0.97, 1.0), uCloud * 0.85) * mix(1.0, 0.78, uCloud);

  // Destello del Sol sobre el agua (el color conserva el tono del Sol; el brillo se mide después de la exposición).
  float m = max(max(uSunDisc.r, uSunDisc.g), uSunDisc.b);
  vec3 hue = uSunDisc / max(m, 1e-4);
  float rs = max(dot(R, uSunDir), 0.0);
  float glint = pow(rs, 900.0) * 9.0 + pow(rs, 120.0) * 0.8 + pow(rs, 18.0) * 0.07;
  float spark = 0.55 + 0.9 * texture2D(uNoise, vWorld.xz * 0.33 + uTime * 0.05).g;
  refl += hue * glint * spark * smoothstep(0.0, 0.05, m) * (1.0 - uCloud * 0.8) * (2.6 / max(uExposure, 0.1));

  // Cuerpo del agua: absorción con la profundidad (el rojo se pierde primero) y luz que se dispersa dentro.
  float depth = max(vDepth, 0.0);
  float body = 1.0 - exp(-depth * 0.85);
  vec3 deep = vec3(0.055, 0.135, 0.15) * uLightE * 0.9;
  vec3 shallow = vec3(0.12, 0.2, 0.17) * uLightE * 0.9;
  vec3 bodyCol = mix(shallow, deep, smoothstep(0.1, 2.4, depth));

  // Espuma en la orilla.
  float foamN = texture2D(uNoise, vWorld.xz * 0.45 + vec2(uTime * 0.04, -uTime * 0.03)).b;
  float foam = (1.0 - smoothstep(0.0, 0.42, vDepth)) * smoothstep(0.38, 0.8, foamN + 0.25 * sin(uTime * 1.3 + vDepth * 9.0)) * step(0.0, vDepth);

  float alpha = body + F - body * F;
  vec3 col = (bodyCol * body * (1.0 - F) + refl * F) / max(alpha, 1e-3);
  col = mix(col, uLightE * 0.85, foam * 0.85);
  alpha = max(alpha, foam * 0.85);
  alpha *= smoothstep(0.0, 0.1, vDepth);

  col = rwFog(col, rel);
  gl_FragColor = vec4(col, alpha);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

// ── Suelo ────────────────────────────────────────────────────────────────────────────────────────────────────
// Funciones comunes de colores de la hierba: las usan el suelo y los mechones para que se fundan sin costuras.
export const GLSL_GRASS_COLORS = /* glsl */ `
const vec3 RW_GRASS_DRY = vec3(0.22, 0.2, 0.07);
const vec3 RW_GRASS_LUSH = vec3(0.046, 0.135, 0.022);
`;

// Albedo procedural y altura de relieve (m) del suelo en un punto del mundo.
//   sp = pesos (hierba, roca, arena, nieve) · tint = (exuberancia, oclusión, humedad)
export const GLSL_TERRAIN_FUNCS = /* glsl */ `
${GLSL_GRASS_COLORS}
vec3 rwTerrainAlbedo(vec3 wp, vec4 sp, vec3 tint, float dist, out float height, out float rockW, out float snowW) {
  vec2 p = wp.xz;
  float nearK = 1.0 - smoothstep(14.0, 70.0, dist);
  float midK = 1.0 - smoothstep(90.0, 420.0, dist);
  vec4 n0 = texture2D(uNoise, p * 0.0071);
  vec4 n1 = texture2D(uNoise, rwRot(p, 0.7) * 0.047 + 0.31);
  vec4 n2 = texture2D(uNoise, rwRot(p, -0.4) * 0.39 + 0.57);
  // Detalle fino (granos de ≈1 mm por texel): solo cerca de la cámara y si el nivel de calidad lo permite.
  float fineK = uFx.y * (1.0 - smoothstep(4.0, 26.0, dist));
  vec4 n3 = vec4(0.5);
  if (uFx.y > 0.01) n3 = texture2D(uNoise, rwRot(p, 1.3) * 2.9 + 0.13);

  // Pesos de las capas con bordes irregulares (el ruido desplaza los límites en vez de un degradado liso).
  vec4 w = max(sp + (vec4(n1.g, n1.r, n1.b, n2.g) - 0.5) * vec4(0.32, 0.46, 0.26, 0.2), 0.0);
  w = pow(w + 1e-4, vec4(2.2));
  w /= (w.x + w.y + w.z + w.w);

  // Hierba: del seco al exuberante, con manchas grandes y grano fino.
  float lush = clamp(tint.x * 1.15 + (n0.r - 0.5) * 0.55, 0.0, 1.0);
  vec3 grass = mix(RW_GRASS_DRY, RW_GRASS_LUSH, lush);
  grass *= 0.74 + 0.5 * (n1.g * 0.55 + n0.g * 0.35 + (n2.b - 0.5) * 0.35 * nearK + 0.1);
  grass *= 1.0 + fineK * (n3.g - 0.5) * 0.5;
  grass = mix(grass, RW_GRASS_DRY * 0.6, fineK * smoothstep(0.8, 0.95, n3.r) * 0.55);   // briznas secas y tierra entre la hierba

  // Roca: estratos horizontales (el ruido se muestrea con la altura, no se estira en las paredes) y óxido.
  vec2 rp = vec2(wp.x * 0.7 + wp.z * 0.7, wp.y * 2.2);
  float strata = texture2D(uNoise, rp * 0.034).r;
  float rockV = n1.b * 0.35 + strata * 0.45 + (n2.r - 0.5) * 0.25 * nearK;
  vec3 rock = mix(vec3(0.15, 0.135, 0.125), vec3(0.4, 0.36, 0.31), clamp(rockV, 0.0, 1.0));
  rock = mix(rock, rock * vec3(1.25, 0.95, 0.7), smoothstep(0.55, 0.85, n0.b) * 0.5);
  // Grietas: líneas donde un ruido suave cruza su valor medio (más finas donde el ruido cambia rápido) y grano fino cerca.
  float crackV = texture2D(uNoise, rp * 0.11 + 0.37).g;
  float crack = (1.0 - smoothstep(0.0, 0.05, abs(crackV - 0.5))) * uFx.y * (1.0 - smoothstep(30.0, 220.0, dist));
  float grain = texture2D(uNoise, rp * 1.7).b;
  rock *= (1.0 - 0.5 * crack) * (1.0 + fineK * (grain - 0.5) * 0.32);

  vec3 sand = mix(vec3(0.5, 0.42, 0.27), vec3(0.72, 0.64, 0.45), n2.g * nearK + n1.g * (1.0 - nearK));
  sand *= 1.0 + fineK * (n3.g - 0.5) * 0.24;
  sand = mix(sand, sand * vec3(0.6, 0.56, 0.52), fineK * smoothstep(0.86, 0.94, n3.a) * 0.8);   // guijarros
  vec3 snow = vec3(0.84, 0.88, 0.93) * (0.93 + 0.07 * n1.g);
  snow += vec3(0.55) * fineK * step(0.975, n3.b);                                                 // destellos de cristales

  vec3 a = grass * w.x + rock * w.y + sand * w.z + snow * w.w;
  a *= 1.0 - 0.45 * tint.z * (1.0 - w.w);       // suelo húmedo más oscuro junto al agua
  a *= tint.y;                                    // oclusión ambiental horneada

  // Relieve (m): hierba suave, roca rugosa, arena con ondulaciones.
  float hg = 0.07 * (n1.g - 0.5) + 0.03 * (n2.g - 0.5) * nearK;
  float hr = 0.34 * (strata - 0.5) + 0.12 * (n1.b - 0.5) + 0.05 * (n2.r - 0.5) * nearK - 0.06 * crack + 0.008 * fineK * (grain - 0.5);
  float hs = 0.012 * sin((wp.x * 0.8 + wp.z * 0.5 + n1.r * 6.0) * 3.0) * midK;
  height = (hg * w.x + hr * w.y + hs * w.z + 0.02 * (n1.g - 0.5) * w.w) * (0.4 + 0.6 * midK);
  height += fineK * ((n3.g - 0.5) * 0.012 * w.x + (n3.a - 0.5) * 0.014 * w.z);
  rockW = w.y;
  snowW = w.w;
  return a;
}

// Perturba la normal (espacio de la vista) con el gradiente de una altura en metros (Mikkelsen).
vec3 rwBumpNormal(vec3 nrm, vec3 viewPos, float h) {
  vec3 sX = dFdx(viewPos);
  vec3 sY = dFdy(viewPos);
  float dBx = dFdx(h);
  float dBy = dFdy(h);
  vec3 R1 = cross(sY, nrm);
  vec3 R2 = cross(nrm, sX);
  float det = dot(sX, R1);
  vec3 grad = sign(det) * (dBx * R1 + dBy * R2);
  return normalize(abs(det) * nrm - grad);
}
`;

// ── Hierba (mechones instanciados) ───────────────────────────────────────────────────────────────────────────
export const GLSL_GRASS_VERT_PARS = /* glsl */ `
attribute vec4 iA;   // x, y, z (relativos al trozo), escala
attribute vec4 iB;   // giro, exuberancia, flor (−1 = sin flor), sombra de copa
varying vec3 vGrassCol;
uniform float uGrassFar;
uniform vec3 uPlayer;   // pies del personaje (mundo): la hierba cercana se aparta y se agacha
${GLSL_GRASS_COLORS}
vec3 rwFlower(float k) {
  if (k < 0.5) return vec3(0.9, 0.85, 0.2);
  if (k < 1.5) return vec3(0.9, 0.9, 0.85);
  if (k < 2.5) return vec3(0.75, 0.18, 0.2);
  if (k < 3.5) return vec3(0.45, 0.3, 0.75);
  return vec3(0.95, 0.5, 0.15);
}
`;

export const GLSL_GRASS_BEGIN_VERTEX = /* glsl */ `
float gScale = iA.w;
float gc = cos(iB.x), gs = sin(iB.x);
vec3 gBase = iA.xyz;
vec3 gWorld = (modelMatrix * vec4(gBase, 1.0)).xyz;
float gDist = distance(gWorld, cameraPosition);
float gFade = 1.0 - smoothstep(uGrassFar * 0.62, uGrassFar, gDist);
vec3 gp = position;
float gHt = clamp(position.y / 0.4, 0.0, 1.0);
gp.xz = vec2(gc * gp.x - gs * gp.z, gs * gp.x + gc * gp.z);
gp *= gScale * gFade;
float gT = uTime * 1.7 + gWorld.x * 0.35 + gWorld.z * 0.29;
float gBend = gHt * gHt * uWind;
gp.x += (sin(gT) + 0.4 * sin(gT * 2.1 + 1.3)) * 0.075 * gBend * gScale;
gp.z += cos(gT * 0.8) * 0.045 * gBend * gScale;
{
  vec2 pd = gWorld.xz - uPlayer.xz;
  float pr = length(pd);
  float push = (1.0 - smoothstep(0.3, 1.25, pr)) * (1.0 - smoothstep(0.7, 1.6, abs(gWorld.y - uPlayer.y))) * gHt * gHt;
  gp.xz += pd / max(pr, 0.08) * push * 0.34 * gScale;
  gp.y *= 1.0 - 0.38 * push;
}
vec3 transformed = gBase + gp;
vec3 gCol = mix(RW_GRASS_DRY, RW_GRASS_LUSH, iB.y);
gCol *= mix(0.4, 1.2, gHt) * iB.w;
if (iB.z > -0.5 && gHt > 0.72) gCol = rwFlower(iB.z) * (0.7 + 0.5 * gHt);
vGrassCol = gCol;
`;

// ── Árboles y rocas: viento ──────────────────────────────────────────────────────────────────────────────────
export const GLSL_PROPS_VERT_PARS = /* glsl */ `
attribute vec2 wind;   // cuánto se mueve (0 en el tronco, ≈1 en la punta), fase del árbol
varying vec3 vPropW;   // posición en el mundo (para variar el color de las hojas)
varying float vLeaf;   // 1 en el follaje (viento fuerte), 0 en troncos y rocas
varying vec2 vCard;    // uv de las tarjetas de hojas; (-1,-1) en todo lo demás
`;
export const GLSL_PROPS_BEGIN_VERTEX = /* glsl */ `
vec3 transformed = vec3(position);
{
  vec3 pw = (modelMatrix * vec4(position, 1.0)).xyz;
  float t = uTime * 1.25 + wind.y + pw.x * 0.09 + pw.z * 0.07;
  float a = wind.x * uWind;
  transformed.x += (sin(t) + 0.5 * sin(t * 2.3 + 1.7)) * 0.11 * a;
  transformed.z += (cos(t * 0.87) + 0.4 * sin(t * 1.9)) * 0.08 * a;
  vPropW = pw + vec3(transformed.x - position.x, transformed.y - position.y, transformed.z - position.z);
  vLeaf = step(0.3, wind.x);
  vCard = uv;
}
`;
// Fragmento de color de los árboles y rocas: rompe la uniformidad de los lóbulos con ruido y aclara las puntas.
export const GLSL_PROPS_COLOR = /* glsl */ `
{
  float rwLn = texture2D(uNoise, vPropW.xz * 0.9 + vPropW.y * 0.37).g;
  float rwLn2 = texture2D(uNoise, vPropW.xz * 3.1 - vPropW.y * 1.3).a;
  diffuseColor.rgb *= 0.74 + 0.34 * rwLn + 0.2 * rwLn2;
  // Follaje con hojas recortadas (solo si el ajuste está activo): hacia el borde de la copa (donde la superficie se ve de canto)
  // se descartan manchas de ruido del tamaño de una hoja, así el contorno queda desflecado y entre las hojas se ve el cielo.
  if (vCard.x >= 0.0) {
    // Tarjeta de hojas: racimo de cinco lóbulos con el borde irregular; lo de fuera se descarta.
    vec2 rwP = vCard * 2.0 - 1.0;
    float rwR = length(rwP);
    float rwNz = texture2D(uNoise, vPropW.xz * 6.0 + vPropW.y * 4.0 + vCard * 2.5).r;
    float rwLobe = 0.6 + 0.4 * cos(atan(rwP.y, rwP.x) * 5.0 + rwNz * 4.0);
    if (rwR > rwLobe * (0.82 + 0.3 * rwNz)) discard;
    diffuseColor.rgb *= 0.8 + 0.4 * (1.0 - rwR) + 0.2 * rwNz;
  } else if (uLeafy > 0.5 && vLeaf > 0.5) {
    float rwFace = abs(dot(normalize(vNormal), normalize(vViewPosition)));
    float rwHole = texture2D(uNoise, vPropW.xz * 3.6 + vPropW.y * 2.9).r * 0.6 + texture2D(uNoise, vPropW.zx * 9.0 - vPropW.y * 7.0).g * 0.4;
    if (rwHole > 0.32 + 0.6 * rwFace) discard;
    diffuseColor.rgb *= 0.8 + 0.5 * rwHole; // las hojas más claras al borde, un poco más oscuro en el fondo de la copa
  }
}
`;
