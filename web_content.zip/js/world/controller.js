// Control del personaje y de la cámara en el mundo. Sin Three.js ni DOM: recibe la entrada ya leída (stick, botones, giro de
// cámara) y devuelve dónde está el personaje y desde dónde se ve. Así se puede probar entero en Node.
//
// La velocidad sale del propio ciclo de la animación (`groundSpeed` × escala del personaje): el stick solo decide qué
// velocidad se pide al animador y hacia dónde se gira. Los pies no resbalan porque el avance es el del ciclo.
import { Player, stickToWorld, targetSpeed, orbitCamera, wrapAngle, EYE_HEIGHT } from './physics.js';
import { heightAt } from './terrain.js';
import { createTerrainFit } from '../rig/terrainFit.js';

// Cámara en tercera persona. `pitch` > 0 = cámara más alta que el personaje (mira hacia abajo); `pitch` < 0 = mira hacia arriba.
// La órbita solo baja hasta `orbitMinPitch` (por debajo estaría bajo el suelo); de ahí hasta `minPitch` la cámara se queda
// a esa altura y lo que sube es la mirada, así se puede ver el cielo y el Sol sin que la cámara se acerque ni atraviese nada.
export const CAMERA = Object.freeze({
  minDist: 1.7,
  maxDist: 9,
  defaultDist: 3.9,
  orbitMinPitch: -0.22,
  minPitch: -0.95,
  maxPitch: 1.32,
  defaultPitch: 0.24,
  lookK: 0.0052, // rad por píxel de arrastre
  focusHeight: 1.32, // punto del cuerpo al que mira la cámara (m sobre los pies)
});

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export class WorldController {
  // avatar: { animator, speeds() → { walk, run, sprint } (m/s), applyPose(pose) }.  spawn: [x, z].
  constructor({ avatar, spawn = [0, 0], heading = 0.79 } = {}) {
    this.avatar = avatar;
    // Pies y cuerpo adaptados al terreno (necesita el esqueleto del personaje; si falta o es raro, simplemente no se usa).
    this.footIK = true;
    this.fit = null;
    try {
      if (avatar?.rig?.joints) this.fit = createTerrainFit(avatar.rig);
    } catch (err) {
      console.warn('[mundo] sin adaptación al terreno', err);
    }
    this.player = new Player(spawn[0], spawn[1], heading);
    this.camYaw = heading;
    this.camPitch = CAMERA.defaultPitch;
    this.camDist = CAMERA.defaultDist;
    this.focusY = this.player.y + CAMERA.focusHeight;
    this.blockedFor = 0;
    this.speedNow = 0; // m/s reales del último fotograma
    this.cam = { x: 0, y: 0, z: 0, dist: 0 };
    this.focus = [0, 0, 0]; // punto del personaje alrededor del que orbita la cámara
    this.look = [0, 0, 0]; // punto al que mira la cámara (el mismo, o más arriba si se mira al cielo)
    this.last = null;
    this.#placeCamera(0);
  }

  // Altura del suelo relativa a la de los pies del personaje, en unidades del esqueleto (x a su izquierda, z hacia delante).
  #ground = { x: 0, z: 0, k: 1, c: 1, s: 0, base: 0 };
  #sample = (lx, lz) => {
    const g = this.#ground;
    return (heightAt(g.x + g.k * (lx * g.c + lz * g.s), g.z + g.k * (-lx * g.s + lz * g.c)) - g.base) / g.k;
  };

  // Un fotograma. inp = { stick: { x, y, mag }, sprint, jump, wave, lookX, lookY, zoom }. colliders(cx, cz) → Float32Array | null.
  step(dt, inp, colliders = null) {
    dt = clamp(dt, 0, 0.05);
    const p = this.player;
    const an = this.avatar.animator;
    const sp = this.avatar.speeds();

    // Cámara, como en la mayoría de juegos: el dedo a la derecha → la vista gira a la derecha; el dedo hacia arriba → se mira
    // hacia arriba (el cielo). lookX/lookY son los píxeles que se movió el dedo (x a la derecha, y hacia abajo).
    // Con yaw creciente la cámara gira hacia su izquierda (su derecha es (−cos yaw, sin yaw)), de ahí el signo menos.
    this.camYaw = wrapAngle(this.camYaw - inp.lookX * CAMERA.lookK);
    this.camPitch = clamp(this.camPitch + inp.lookY * CAMERA.lookK, CAMERA.minPitch, CAMERA.maxPitch);
    this.camDist = clamp(this.camDist * (inp.zoom || 1), CAMERA.minDist, CAMERA.maxDist);

    // Dirección pedida y velocidad.
    const [dx, dz, mag] = stickToWorld(inp.stick.x, inp.stick.y, this.camYaw);
    let want = targetSpeed(mag, sp, inp.sprint);
    if (mag > 0.1) {
      const desired = Math.atan2(dx, dz);
      const diff = Math.abs(wrapAngle(desired - p.heading));
      const frac = clamp(this.speedNow / Math.max(sp.run, 0.1), 0, 1);
      p.turnTowards(desired, dt, 11 - 5 * frac);
      want *= 1 - 0.85 * smooth(0.7, 2.0, diff); // casi parado al dar la vuelta: así no «derrapa»
    }
    want *= 1 - 0.45 * smooth(0.08, 0.34, p.steepness); // cuesta empinada
    want *= 1 - 0.4 * p.wade; // agua
    // Contra un obstáculo no se sigue corriendo en el sitio.
    if (p.blocked) this.blockedFor += dt;
    else this.blockedFor = Math.max(0, this.blockedFor - dt * 2);
    if (this.blockedFor > 0.3) want = Math.min(want, sp.walk * 0.35);

    // Animación: el animador suaviza la aceleración y devuelve cuánto avanzan los pies.
    an.setSpeed(sp.walk > 0 ? want / (this.avatar.scale || 1) : 0);
    if (inp.jump) an.jump();
    if (inp.wave) an.wave();
    const r = an.update(dt);
    let pose = r.pose;
    if (this.fit && this.footIK) {
      const g = this.#ground, k = this.avatar.scale || 1;
      g.x = p.x; g.z = p.z; g.k = k; g.c = Math.cos(p.heading); g.s = Math.sin(p.heading); g.base = heightAt(p.x, p.z);
      pose = this.fit.apply(pose, this.#sample, { dt, strength: r.state === 'jump' ? 0.3 : 1 });
    }
    this.avatar.applyPose(pose);

    const dist = r.groundSpeed * (this.avatar.scale || 1) * dt;
    const moved = p.move(dist, colliders);
    this.speedNow = dt > 0 ? moved / dt : 0;
    this.moving = r.moving;
    this.#placeCamera(dt);
    return this.state;
  }

  #placeCamera(dt) {
    const p = this.player;
    const k = dt > 0 ? 1 - Math.exp(-9 * dt) : 1;
    this.focusY += (p.y + CAMERA.focusHeight - this.focusY) * k;
    this.focus = [p.x, this.focusY, p.z];
    orbitCamera(this.focus, this.camYaw, Math.max(this.camPitch, CAMERA.orbitMinPitch), this.camDist, this.cam);
    // Mirar al cielo: si se pide mirar más arriba de lo que da la órbita (o el terreno la obligó a quedarse baja), la cámara
    // sigue en su sitio y el punto de mira sube hasta la elevación pedida. Es continuo con la órbita normal.
    this.look = this.focus;
    const up = -this.camPitch;
    if (up > 0) {
      const c = this.cam;
      const hd = Math.max(1e-3, Math.hypot(this.focus[0] - c.x, this.focus[2] - c.z));
      if (up > Math.atan2(this.focus[1] - c.y, hd)) this.look = [this.focus[0], c.y + hd * Math.tan(up), this.focus[2]];
    }
  }

  // Coloca al personaje en otro punto (p. ej. al volver a aparecer).
  teleport(x, z, heading = this.player.heading) {
    this.player = new Player(x, z, heading);
    this.camYaw = heading;
    this.focusY = this.player.y + CAMERA.focusHeight;
    this.speedNow = 0;
    this.blockedFor = 0;
    this.avatar.animator.reset?.();
    this.fit?.reset();
    this.#placeCamera(0);
  }

  get state() {
    const p = this.player;
    return {
      x: p.x, y: p.y, z: p.z, heading: p.heading,
      wade: p.wade, steepness: p.steepness, blocked: p.blocked,
      speed: this.speedNow,
      camera: this.cam, look: this.look, focus: this.focus, yaw: this.camYaw, pitch: this.camPitch, dist: this.camDist,
      eye: [p.x, p.y + EYE_HEIGHT, p.z],
    };
  }
}
