// Textura de ruido repetible (256×256, RGBA de 8 bits) que usan los sombreadores del cielo, el agua, el suelo y los árboles:
//   R: nubes grandes y suaves · G: detalle fino · B: ruido celular «hinchado» (nubes, espuma) · A: ruido independiente (estrellas, relieve).
// Se genera en la CPU una sola vez (≈ 0,1 s) a partir de ruido de gradiente periódico: sin archivos ni red.
import { hashInt } from './noise.js';

export const NOISE_SIZE = 256;

const S = Math.SQRT1_2;
const GX = [1, -1, 0, 0, S, -S, S, -S];
const GY = [0, 0, 1, -1, S, S, -S, -S];

// Ruido de gradiente con periodo `p` (las coordenadas enteras se reducen módulo p → la textura se repite sin costuras).
function periodicNoise(x, y, p, seed) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * xf * (xf * (xf * 6 - 15) + 10), v = yf * yf * yf * (yf * (yf * 6 - 15) + 10);
  const wrap = (i) => ((i % p) + p) % p;
  const x0 = wrap(xi), x1 = wrap(xi + 1), y0 = wrap(yi), y1 = wrap(yi + 1);
  const h00 = hashInt(x0, y0, seed) & 7, h10 = hashInt(x1, y0, seed) & 7, h01 = hashInt(x0, y1, seed) & 7, h11 = hashInt(x1, y1, seed) & 7;
  const n00 = GX[h00] * xf + GY[h00] * yf, n10 = GX[h10] * (xf - 1) + GY[h10] * yf;
  const n01 = GX[h01] * xf + GY[h01] * (yf - 1), n11 = GX[h11] * (xf - 1) + GY[h11] * (yf - 1);
  const a = n00 + u * (n10 - n00), b = n01 + u * (n11 - n01);
  return (a + v * (b - a)) * 1.4142;
}

function fbmPeriodic(x, y, basePeriod, octaves, seed, gain = 0.5) {
  let amp = 1, sum = 0, norm = 0, p = basePeriod;
  for (let o = 0; o < octaves; o++) {
    sum += amp * periodicNoise(x * p, y * p, p, seed + o * 13);
    norm += amp;
    amp *= gain;
    p *= 2;
  }
  return sum / norm;
}

// Ruido celular periódico (distancia al punto más cercano, invertida): protuberancias suaves.
function cellular(x, y, p, seed) {
  const fx = x * p, fy = y * p;
  const ix = Math.floor(fx), iy = Math.floor(fy);
  let best = 9;
  for (let j = -1; j <= 1; j++) {
    for (let i = -1; i <= 1; i++) {
      const cx = (((ix + i) % p) + p) % p, cy = (((iy + j) % p) + p) % p;
      const px = ix + i + hashInt(cx, cy, seed) / 4294967296, py = iy + j + hashInt(cx, cy, seed + 7) / 4294967296;
      const d = Math.hypot(fx - px, fy - py);
      if (d < best) best = d;
    }
  }
  return 1 - Math.min(1, best);
}

// Devuelve los datos RGBA (Uint8Array, NOISE_SIZE²·4). Los canales se estiran a todo el rango [0, 255].
export function generateNoiseData(size = NOISE_SIZE) {
  const raw = [new Float32Array(size * size), new Float32Array(size * size), new Float32Array(size * size), new Float32Array(size * size)];
  for (let j = 0; j < size; j++) {
    for (let i = 0; i < size; i++) {
      const x = i / size, y = j / size, k = j * size + i;
      raw[0][k] = fbmPeriodic(x, y, 4, 5, 101, 0.52);
      raw[1][k] = fbmPeriodic(x, y, 16, 3, 202, 0.55);
      raw[2][k] = 0.6 * cellular(x, y, 8, 303) + 0.4 * cellular(x, y, 16, 304);
      raw[3][k] = fbmPeriodic(x, y, 8, 4, 404, 0.5);
    }
  }
  const out = new Uint8Array(size * size * 4);
  for (let c = 0; c < 4; c++) {
    let lo = Infinity, hi = -Infinity;
    // Percentiles 1 % / 99 %: no dejan que unos pocos valores extremos aplasten el contraste.
    const sorted = Float32Array.from(raw[c]).sort();
    lo = sorted[Math.floor(sorted.length * 0.01)];
    hi = sorted[Math.floor(sorted.length * 0.99)];
    const inv = 1 / Math.max(1e-6, hi - lo);
    for (let k = 0; k < size * size; k++) out[k * 4 + c] = Math.max(0, Math.min(255, Math.round(((raw[c][k] - lo) * inv) * 255)));
  }
  return out;
}
