// Del estado de la atmósfera (atmosphere.js) a los valores que consumen los sombreadores y las luces.
// Funciones puras con números y arrays: las usan el renderizador y las pruebas.
import { WEATHER } from './atmosphere.js';

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

// state = atmosphereState(...) · viewDistance = distancia de visión (m) · weather = { cloud, fog } (ver WEATHER)
export function sceneValues(state, { time = 0, viewDistance = 400, weather = WEATHER.clear, grassFar = 44, fx = [1, 1] } = {}) {
  const sunUp = Math.max(state.sun[1], 0);
  const sunDisc = state.sunTransmittance.map((t) => t * state.directK);
  const haze = smooth(1.3, 4.2, weather.fog);
  const eSun = state.sunColor;
  const lightE = [0, 1, 2].map((k) => (eSun[k] * sunUp + state.skyAmbient[k]) / Math.PI);
  // Nubes: albedo ≈ 0,9 → radiancia = 0,9/π · (Sol + cielo). Las caras laterales y bajas reciben el Sol rasante, así que no se
  // apaga con el coseno (mínimo 0,3). La sombra propia y el borde plateado los pone el sombreador.
  const cloudLight = [0, 1, 2].map((k) => (0.9 * (eSun[k] * Math.max(state.sun[1], 0.3) * 0.85 + state.skyAmbient[k])) / Math.PI);
  const nightGlow = [0.0022, 0.0034, 0.0075].map((v) => v * (0.7 + 2 * state.moonAmt));
  return {
    uSunDir: state.sun,
    uMoonDir: state.moon,
    uSunDisc: sunDisc,
    uCloudLight: cloudLight,
    uNightGlow: nightGlow,
    uLightE: lightE,
    uFogColor: state.fogColor,
    uFogSunColor: state.fogSunColor.map((v, k) => state.fogColor[k] + (v - state.fogColor[k]) * 0.55), // el brillo hacia el Sol se modera
    uFogDensity: state.fogDensity,
    uFogFar: [viewDistance * 0.7, viewDistance * 0.96],
    uCloudDrift: [time * 0.0006, time * 0.00025],
    uTime: time,
    uWind: 0.55 + 0.45 * state.cloud + 0.3 * Math.sin(time * 0.05),
    uStars: state.stars,
    uCloud: state.cloud,
    uHaze: haze,
    uMoonVis: (1 - 0.9 * state.dayAmount) * smooth(-0.02, 0.1, state.moon[1]),
    uExposure: state.exposure,
    uGrassFar: grassFar,
    uFx: fx,
  };
}

// Luces de Three.js: irradiancia directa del Sol (con su color), de la Luna y hemisférica (cielo/suelo).
export function lightValues(state) {
  const sunUp = smooth(0.0, 0.06, state.sun[1]);
  return {
    sunColor: state.sunColor,
    sunDir: state.sun,
    sunShadow: smooth(0.02, 0.14, state.sun[1]), // con el Sol muy bajo las sombras serían kilométricas: se desvanecen
    sunOn: sunUp > 0.001,
    moonColor: state.moonColor,
    moonDir: state.moon,
    skyColor: state.skyAmbient,
    groundColor: state.groundAmbient,
    exposure: state.exposure,
    fogColor: state.fogColor,
  };
}

// Copia los valores en los uniformes de Three.js (objetos { value } con Vector3/Color/Vector2 o números).
export function writeUniforms(U, values) {
  for (const [key, v] of Object.entries(values)) {
    const u = U[key];
    if (!u) continue;
    if (typeof v === 'number') u.value = v;
    else if (u.value?.fromArray) u.value.fromArray(v);
    else if (u.value?.set) u.value.set(...v);
  }
}
