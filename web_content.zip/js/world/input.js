// Entrada del mundo: joystick flotante (mitad izquierda de la pantalla), arrastre para girar la cámara (mitad derecha),
// pellizco para acercar y teclado/ratón para probar en un ordenador. Con Pointer Events: sirve igual con dedos y ratón.
// El estado se lee una vez por fotograma con consume().

export const JOY_RADIUS = 56; // px: recorrido máximo del pulgar
export const JOY_DEAD = 0.12;

// Desplazamiento del dedo (px, y hacia abajo) → vector del stick (x derecha, y arriba) con zona muerta.
export function joystickVector(dx, dy, radius = JOY_RADIUS, dead = JOY_DEAD) {
  const len = Math.hypot(dx, dy);
  if (len < 1e-6) return { x: 0, y: 0, mag: 0 };
  const raw = Math.min(1, len / radius);
  const mag = raw < dead ? 0 : (raw - dead) / (1 - dead);
  return { x: (dx / len) * mag, y: (-dy / len) * mag, mag };
}

export class WorldInput {
  // el: superficie táctil (recibe los eventos). callbacks: { onStick({ active, ox, oy, x, y, rx, ry }) } para dibujar el joystick.
  constructor(el, { onStick = () => {}, joyZone = 0.5 } = {}) {
    this.el = el;
    this.onStick = onStick;
    this.joyZone = joyZone;
    this.joy = null; // { id, ox, oy, x, y }
    this.looks = new Map(); // id → { x, y }
    this.pinch = null;
    this.keys = new Set();
    this.acc = { lookX: 0, lookY: 0, zoom: 1, jump: false, wave: false };
    this.sprintHeld = false;
    this.sprintToggle = false;
    this.disposed = false;
    this.#bind();
  }

  #bind() {
    const el = this.el;
    const down = (e) => {
      if (this.disposed) return;
      if (e.target?.closest?.('[data-no-touch]')) return; // los botones tienen su propia gestión
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* algunos entornos no lo permiten */
      }
      const rect = el.getBoundingClientRect();
      const lx = e.clientX - rect.left, ly = e.clientY - rect.top;
      const onLeft = lx < rect.width * this.joyZone;
      if (onLeft && !this.joy && (e.pointerType !== 'mouse' || e.button === 0)) {
        this.joy = { id: e.pointerId, ox: lx, oy: ly, x: lx, y: ly };
        this.#emitStick();
      } else {
        this.looks.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (this.looks.size === 2) this.pinch = this.#pinchDist();
      }
      e.preventDefault?.();
    };
    const move = (e) => {
      if (this.disposed) return;
      if (this.joy && e.pointerId === this.joy.id) {
        const rect = el.getBoundingClientRect();
        this.joy.x = e.clientX - rect.left;
        this.joy.y = e.clientY - rect.top;
        // Si el pulgar se pasa del recorrido, la base lo sigue (no hay que volver al centro).
        const dx = this.joy.x - this.joy.ox, dy = this.joy.y - this.joy.oy;
        const len = Math.hypot(dx, dy);
        if (len > JOY_RADIUS * 1.15) {
          const k = (len - JOY_RADIUS * 1.15) / len;
          this.joy.ox += dx * k;
          this.joy.oy += dy * k;
        }
        this.#emitStick();
        return;
      }
      const p = this.looks.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX;
      p.y = e.clientY;
      if (this.looks.size === 1) {
        this.acc.lookX += dx;
        this.acc.lookY += dy;
      } else if (this.looks.size === 2) {
        const d = this.#pinchDist();
        if (this.pinch && d > 1) this.acc.zoom *= this.pinch / d;
        this.pinch = d;
      }
    };
    const up = (e) => {
      if (this.joy && e.pointerId === this.joy.id) {
        this.joy = null;
        this.#emitStick();
      }
      if (this.looks.delete(e.pointerId)) this.pinch = this.looks.size === 2 ? this.#pinchDist() : null;
    };
    const wheel = (e) => {
      e.preventDefault();
      this.acc.zoom *= Math.exp(e.deltaY * 0.0012);
    };
    const keydown = (e) => {
      if (e.repeat || /input|textarea|select/i.test(e.target?.tagName || '')) return;
      const k = e.key.toLowerCase();
      if (k === ' ') {
        this.acc.jump = true;
        e.preventDefault();
      } else if (k === 'f') this.acc.wave = true;
      else this.keys.add(k);
    };
    const keyup = (e) => this.keys.delete(e.key.toLowerCase());
    const blur = () => this.keys.clear();
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('wheel', wheel, { passive: false });
    const noMenu = (e) => e.preventDefault();
    el.addEventListener('contextmenu', noMenu);
    window.addEventListener('keydown', keydown);
    window.addEventListener('keyup', keyup);
    window.addEventListener('blur', blur);
    this.unbind = () => {
      el.removeEventListener('pointerdown', down);
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
      el.removeEventListener('pointercancel', up);
      el.removeEventListener('wheel', wheel);
      el.removeEventListener('contextmenu', noMenu);
      window.removeEventListener('keydown', keydown);
      window.removeEventListener('keyup', keyup);
      window.removeEventListener('blur', blur);
    };
  }

  #pinchDist() {
    const [a, b] = [...this.looks.values()];
    return Math.hypot(a.x - b.x, a.y - b.y) || 1;
  }

  #emitStick() {
    const j = this.joy;
    if (!j) return this.onStick({ active: false });
    const v = joystickVector(j.x - j.ox, j.y - j.oy);
    const len = Math.hypot(j.x - j.ox, j.y - j.oy);
    const k = len > JOY_RADIUS ? JOY_RADIUS / len : 1;
    this.onStick({ active: true, ox: j.ox, oy: j.oy, kx: j.ox + (j.x - j.ox) * k, ky: j.oy + (j.y - j.oy) * k, ...v });
  }

  pressJump() {
    this.acc.jump = true;
  }
  pressWave() {
    this.acc.wave = true;
  }
  setSprint(on) {
    this.sprintToggle = !!on;
  }
  get sprint() {
    return this.sprintToggle || this.keys.has('shift');
  }

  // Estado de este fotograma. El stick del teclado se combina con el táctil (gana el de mayor módulo).
  consume() {
    let s = { x: 0, y: 0, mag: 0 };
    if (this.joy) s = joystickVector(this.joy.x - this.joy.ox, this.joy.y - this.joy.oy);
    const kx = (this.keys.has('d') || this.keys.has('arrowright') ? 1 : 0) - (this.keys.has('a') || this.keys.has('arrowleft') ? 1 : 0);
    const ky = (this.keys.has('w') || this.keys.has('arrowup') ? 1 : 0) - (this.keys.has('s') || this.keys.has('arrowdown') ? 1 : 0);
    if (kx || ky) {
      const l = Math.hypot(kx, ky);
      const key = { x: kx / l, y: ky / l, mag: 1 };
      if (key.mag > s.mag) s = key;
    }
    const out = { stick: s, sprint: this.sprint, jump: this.acc.jump, wave: this.acc.wave, lookX: this.acc.lookX, lookY: this.acc.lookY, zoom: this.acc.zoom };
    this.acc = { lookX: 0, lookY: 0, zoom: 1, jump: false, wave: false };
    return out;
  }

  dispose() {
    this.disposed = true;
    this.unbind?.();
    this.joy = null;
    this.looks.clear();
  }
}
