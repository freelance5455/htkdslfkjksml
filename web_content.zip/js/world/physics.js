// Movimiento del jugador y de la cámara por el terreno. Funciones puras (sin Three.js) para poder probarlas en Node.
//  · El personaje siempre pisa el terreno; el salto lo da la propia animación (así los pies aterrizan con ella).
//  · La velocidad real sale del ciclo de la animación (`groundSpeed`), de modo que los pies nunca resbalan.
//  · Pendientes empinadas, agua profunda, árboles y rocas lo detienen.
import { heightAt, normalAt, SEA, CHUNK } from './terrain.js';

export const PLAYER_RADIUS = 0.38;
export const MAX_CLIMB = 1.25; // pendiente máxima que se sube (≈ 51°)
export const MAX_WADE = 1.15; // profundidad máxima del agua por la que se camina (m)
export const EYE_HEIGHT = 1.55; // punto al que mira la cámara sobre los pies (m)
export const HEIGHT_M = 1.75; // altura del personaje en el mundo (m)

const TAU = Math.PI * 2;
export const wrapAngle = (a) => {
  a = (a + Math.PI) % TAU;
  if (a < 0) a += TAU;
  return a - Math.PI;
};

// Stick de pantalla (x derecha, y arriba, módulo ≤ 1) → dirección en el mundo según hacia dónde mira la cámara.
// Con yaw = 0 la cámara mira a +Z (y su derecha es −X: el sistema de Three.js es de mano derecha). Devuelve [dx, dz, módulo].
export function stickToWorld(sx, sy, camYaw) {
  const m = Math.min(1, Math.hypot(sx, sy));
  if (m < 1e-6) return [0, 0, 0];
  const fx = Math.sin(camYaw), fz = Math.cos(camYaw); // adelante de la cámara
  const rx = -Math.cos(camYaw), rz = Math.sin(camYaw); // derecha de la cámara = adelante × arriba
  const dx = fx * sy + rx * sx, dz = fz * sy + rz * sx;
  const l = Math.hypot(dx, dz) || 1;
  return [dx / l, dz / l, m];
}

// Velocidad pedida (m/s) según cuánto se inclina el stick. `speeds` en m/s: { walk, run, sprint }.
// 0 → quieto; hasta 55 % → de lento a paso ligero; luego hasta correr; el botón de sprint pide la máxima.
export function targetSpeed(mag, speeds, sprint = false) {
  if (mag < 0.1) return 0;
  const slow = 0.35 * speeds.walk;
  let v;
  if (mag < 0.55) v = slow + (speeds.walk * 1.15 - slow) * ((mag - 0.1) / 0.45);
  else if (mag < 0.9) v = speeds.walk * 1.15 + (speeds.run - speeds.walk * 1.15) * ((mag - 0.55) / 0.35);
  else v = speeds.run;
  if (sprint && mag >= 0.55) v = speeds.sprint;
  return v;
}

export class Player {
  constructor(x = 0, z = 0, heading = 0) {
    this.x = x;
    this.z = z;
    this.y = heightAt(x, z);
    this.heading = heading; // dirección en que mira (forward = (sin h, cos h))
    this.wade = 0; // 0 seco … 1 con el agua en la cintura
    this.blocked = false;
    this.steepness = 0;
  }

  // Hacia dónde mira el personaje: gira hacia `desired` (rad) a `rate` rad/s como máximo.
  turnTowards(desired, dt, rate) {
    const d = wrapAngle(desired - this.heading);
    const step = Math.max(-rate * dt, Math.min(rate * dt, d));
    this.heading = wrapAngle(this.heading + step);
    return d;
  }

  // Avanza `dist` metros en la dirección actual respetando el terreno. getColliders(cx, cz) → Float32Array [x, z, r]*.
  move(dist, getColliders = null, dirOverride = null) {
    this.blocked = false;
    if (!(dist > 0)) {
      this.#settle();
      return 0;
    }
    const dx = dirOverride ? dirOverride[0] : Math.sin(this.heading);
    const dz = dirOverride ? dirOverride[1] : Math.cos(this.heading);
    // Se avanza en pasos de ≤ 0,25 m para no atravesar árboles finos ni saltarse un barranco con un fotograma largo.
    const steps = Math.max(1, Math.ceil(dist / 0.25));
    const sd = dist / steps;
    let moved = 0;
    for (let i = 0; i < steps; i++) {
      let nx = this.x + dx * sd, nz = this.z + dz * sd;
      if (!this.#accept(nx, nz)) {
        // Desliza a lo largo del obstáculo: prueba cada eje por separado.
        if (this.#accept(this.x + dx * sd, this.z)) {
          nx = this.x + dx * sd;
          nz = this.z;
        } else if (this.#accept(this.x, this.z + dz * sd)) {
          nx = this.x;
          nz = this.z + dz * sd;
        } else {
          this.blocked = true;
          break;
        }
      }
      if (getColliders) [nx, nz] = this.#pushOut(nx, nz, getColliders);
      moved += Math.hypot(nx - this.x, nz - this.z);
      this.x = nx;
      this.z = nz;
    }
    this.#settle();
    return moved;
  }

  // ¿Se puede pisar (nx, nz)? Pendiente subible y agua poco profunda.
  #accept(nx, nz) {
    const h0 = heightAt(this.x, this.z), h1 = heightAt(nx, nz);
    const run = Math.hypot(nx - this.x, nz - this.z) || 1e-6;
    if ((h1 - h0) / run > MAX_CLIMB) return false;
    if (SEA - h1 > MAX_WADE && SEA - h1 > SEA - h0 - 0.02) return false; // no se mete más hondo del límite
    return true;
  }

  // Saca al jugador de los círculos de árboles y rocas cercanos.
  #pushOut(nx, nz, getColliders) {
    const cx0 = Math.floor(nx / CHUNK), cz0 = Math.floor(nz / CHUNK);
    for (let pass = 0; pass < 2; pass++) {
      for (let a = -1; a <= 1; a++) {
        for (let b = -1; b <= 1; b++) {
          const list = getColliders(cx0 + a, cz0 + b);
          if (!list) continue;
          for (let k = 0; k < list.length; k += 3) {
            const ox = nx - list[k], oz = nz - list[k + 1];
            const min = list[k + 2] + PLAYER_RADIUS;
            const d2 = ox * ox + oz * oz;
            if (d2 < min * min) {
              const d = Math.sqrt(d2) || 1e-4;
              nx = list[k] + (ox / d) * min;
              nz = list[k + 1] + (oz / d) * min;
              this.blocked = true;
            }
          }
        }
      }
    }
    return [nx, nz];
  }

  #settle() {
    this.y = heightAt(this.x, this.z);
    const depth = SEA - this.y;
    this.wade = Math.max(0, Math.min(1, depth / 0.95));
    const n = normalAt(this.x, this.z, 0.5, [0, 1, 0]);
    this.steepness = 1 - n[1];
  }
}

// Cámara en tercera persona: órbita alrededor de `target` y se acerca si el terreno se interpone.
// yaw: hacia dónde mira la cámara (rad, 0 = +Z); pitch > 0 = cámara más alta que el objetivo.
export function orbitCamera(target, yaw, pitch, dist, out = { x: 0, y: 0, z: 0, dist: 0 }) {
  const cp = Math.cos(pitch), sp = Math.sin(pitch);
  const dirX = -Math.sin(yaw) * cp, dirY = sp, dirZ = -Math.cos(yaw) * cp; // del objetivo hacia la cámara
  let d = dist;
  // Se recorre el rayo objetivo → cámara y se acorta donde el terreno queda por encima (con margen).
  const N = 10;
  for (let i = 1; i <= N; i++) {
    const t = (dist * i) / N;
    const x = target[0] + dirX * t, y = target[1] + dirY * t, z = target[2] + dirZ * t;
    const ground = Math.max(heightAt(x, z), SEA + 0.05) + 0.45;
    if (y < ground) {
      d = Math.max(0.6, t - dist / N);
      break;
    }
  }
  out.x = target[0] + dirX * d;
  out.y = target[1] + dirY * d;
  out.z = target[2] + dirZ * d;
  // Nunca por debajo del suelo (cuando el objetivo mismo está pegado a una ladera).
  const g = Math.max(heightAt(out.x, out.z), SEA + 0.05) + 0.4;
  if (out.y < g) out.y = g;
  out.dist = d;
  return out;
}
