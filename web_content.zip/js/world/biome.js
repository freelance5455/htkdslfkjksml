// Bioma «de hábitat» de un punto del terreno, con los nombres que usa el zoológico para decidir dónde vive cada criatura.
// mar (agua profunda) · costa (arena) · roca (roca o nieve) · bosque · colinas (pradera abierta).
import { heightAt, normalAt, surfaceAt, SEA } from './terrain.js';
import { forestAt } from './scatter.js';

const N = [0, 1, 0];
const S = { grass: 1, rock: 0, sand: 0, snow: 0, lush: 0.5, wet: 0 };

export function biomeAt(x, z) {
  const h = heightAt(x, z);
  if (h < SEA - 0.5) return 'mar';
  normalAt(x, z, 0.6, N);
  surfaceAt(x, z, h, N[1], S);
  if (S.sand > 0.5) return 'costa';
  if (S.rock + S.snow > 0.5) return 'roca';
  if (forestAt(x, z) > 0.55) return 'bosque';
  return 'colinas';
}
