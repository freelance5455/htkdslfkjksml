// Origen de los trozos del mundo: un Worker y, si el navegador no puede crearlo (o falla), el hilo principal.
// El resultado es idéntico; el respaldo solo es más lento y puede dar pequeños tirones al cargar.
import { generateChunk } from './chunkGen.js';

const READY_TIMEOUT_MS = 8000;

export function createChunkSource({ preferWorker = true, workerUrl = null } = {}) {
  let worker = null;
  let readyPromise = null;
  let broken = !preferWorker || typeof Worker === 'undefined';
  let nextId = 1;
  const jobs = new Map();

  function ensureWorker() {
    if (broken) return Promise.reject(new Error('Worker no disponible'));
    if (readyPromise) return readyPromise;
    readyPromise = new Promise((resolve, reject) => {
      let w;
      try {
        w = new Worker(workerUrl || new URL('../workers/world.worker.js', import.meta.url), { type: 'module' });
      } catch (err) {
        reject(err);
        return;
      }
      const timer = setTimeout(() => reject(new Error('El Worker del mundo no arrancó a tiempo')), READY_TIMEOUT_MS);
      w.onmessage = (e) => {
        const m = e.data;
        if (m.type === 'ready') {
          clearTimeout(timer);
          worker = w;
          resolve(w);
          return;
        }
        const job = jobs.get(m.id);
        if (!job) return;
        jobs.delete(m.id);
        if (m.type === 'chunk') job.resolve(m.result);
        else job.reject(new Error(m.message || 'Error del Worker del mundo'));
      };
      w.onerror = (e) => {
        clearTimeout(timer);
        const err = new Error(e.message || 'Error del Worker del mundo');
        reject(err);
        for (const [id, job] of jobs) {
          jobs.delete(id);
          job.reject(err);
        }
      };
    }).catch((err) => {
      console.warn('[mundo] Worker no disponible, se genera en el hilo principal:', err?.message || err);
      broken = true;
      readyPromise = null;
      try {
        worker?.terminate();
      } catch {
        /* ya terminado */
      }
      worker = null;
      throw err;
    });
    return readyPromise;
  }

  // Hilo principal: se cede el control un instante entre trozos para que la interfaz respire.
  const onMain = (job) => new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        resolve(generateChunk(job.cx, job.cz, job.lod, job.opts));
      } catch (err) {
        reject(err);
      }
    }, 0);
  });

  return {
    get mode() {
      return broken ? 'main' : 'worker';
    },
    // → Promise<resultado de generateChunk>
    async request(cx, cz, lod, opts) {
      const job = { cx, cz, lod, opts };
      let w = null;
      if (!broken) {
        try {
          w = await ensureWorker();
        } catch {
          w = null;
        }
      }
      if (!w) return onMain(job);
      const id = nextId++;
      return new Promise((resolve, reject) => {
        jobs.set(id, { resolve, reject });
        w.postMessage({ type: 'chunk', id, ...job });
      }).catch((err) => {
        // Si el Worker se cae a mitad, ese trozo se hace aquí y el resto seguirá en el hilo principal.
        console.warn('[mundo] fallo del Worker, respaldo en el hilo principal:', err?.message || err);
        broken = true;
        return onMain(job);
      });
    },
    dispose() {
      try {
        worker?.terminate();
      } catch {
        /* ya terminado */
      }
      worker = null;
      readyPromise = null;
      for (const [id, job] of jobs) {
        jobs.delete(id);
        job.reject(new Error('cancelado'));
      }
    },
  };
}
