// Geometría procedural de la vegetación y las rocas, sin archivos externos. Cada plantilla es un conjunto de
// arrays (posición, normal, color lineal, viento, índices) en metros con la base en y = 0.
//   · El color va en los vértices (variación, luz de la copa y oclusión ambiental ya horneadas).
//   · El viento es (cuánto se mueve, fase): lo usa el sombreador de los árboles.
// Las plantillas se instancian «fusionadas» en una sola malla por trozo (ver chunkGen.js).
import { rng, noise2, smoothstep, clamp01 } from './noise.js';

// Color sRGB (#rrggbb) → lineal.
export function lin(hex) {
  const c = (shift) => {
    const v = ((hex >> shift) & 255) / 255;
    return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  };
  return [c(16), c(8), c(0)];
}
const mulC = (c, k) => [c[0] * k, c[1] * k, c[2] * k];
const mixC = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

class Builder {
  constructor() {
    this.pos = [];
    this.nor = [];
    this.col = [];
    this.wind = [];
    this.uv = []; // (-1, -1) en todo lo que no es una tarjeta de hojas; (0..1) en las tarjetas (el sombreador recorta su forma)
    this.idx = [];
  }
  vertex(p, n, c, w, u = null) {
    const l = Math.hypot(n[0], n[1], n[2]) || 1;
    this.pos.push(p[0], p[1], p[2]);
    this.nor.push(n[0] / l, n[1] / l, n[2] / l);
    this.col.push(c[0], c[1], c[2]);
    this.wind.push(w, 0);
    this.uv.push(u ? u[0] : -1, u ? u[1] : -1);
    return this.pos.length / 3 - 1;
  }
  tri(a, b, c) {
    this.idx.push(a, b, c);
  }
  finish() {
    return {
      positions: new Float32Array(this.pos),
      normals: new Float32Array(this.nor),
      colors: new Float32Array(this.col),
      wind: new Float32Array(this.wind),
      uvs: new Float32Array(this.uv),
      indices: new Uint16Array(this.idx),
    };
  }
}

// Base ortonormal para un eje dado.
function basis(axis) {
  const a = axis;
  const t = Math.abs(a[1]) < 0.95 ? [0, 1, 0] : [1, 0, 0];
  let u = [a[1] * t[2] - a[2] * t[1], a[2] * t[0] - a[0] * t[2], a[0] * t[1] - a[1] * t[0]];
  const ul = Math.hypot(...u);
  u = [u[0] / ul, u[1] / ul, u[2] / ul];
  const v = [a[1] * u[2] - a[2] * u[1], a[2] * u[0] - a[0] * u[2], a[0] * u[1] - a[1] * u[0]];
  return [u, v];
}

// Tronco o rama: cilindro cónico de `p0` a `p1`.
function addTube(b, p0, p1, r0, r1, seg, c0, c1, w0, w1, rand) {
  const axis = [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]];
  const len = Math.hypot(...axis);
  const a = [axis[0] / len, axis[1] / len, axis[2] / len];
  const [u, v] = basis(a);
  const rings = [];
  for (const [p, r, c, w] of [[p0, r0, c0, w0], [p1, r1, c1, w1]]) {
    const ring = [];
    for (let i = 0; i < seg; i++) {
      const phi = (i / seg) * Math.PI * 2;
      const cs = Math.cos(phi), sn = Math.sin(phi);
      const n = [u[0] * cs + v[0] * sn, u[1] * cs + v[1] * sn, u[2] * cs + v[2] * sn];
      const k = 0.9 + 0.2 * rand();
      ring.push(b.vertex([p[0] + n[0] * r * k, p[1] + n[1] * r * k, p[2] + n[2] * r * k], n, mulC(c, 0.85 + 0.3 * rand()), w));
    }
    rings.push(ring);
  }
  for (let i = 0; i < seg; i++) {
    const j = (i + 1) % seg;
    b.tri(rings[0][i], rings[1][i], rings[0][j]);
    b.tri(rings[0][j], rings[1][i], rings[1][j]);
  }
}

// Piso de copa de conífera: cono con borde caído, dos anillos para que se curve.
function addTier(b, cx, cy, cz, R, H, seg, droop, cTip, cRim, rand, windBase, windH) {
  const apex = b.vertex([cx, cy + H, cz], [0, 1, 0], cTip, windBase + windH);
  const mid = [], rim = [];
  for (let i = 0; i < seg; i++) {
    const phi = (i / seg) * Math.PI * 2 + rand() * 0.25;
    const cs = Math.cos(phi), sn = Math.sin(phi);
    const k = 0.84 + 0.3 * rand();
    const nrm = [cs * H, R * 0.9, sn * H];
    const rm = R * 0.55 * k, rr = R * k;
    const shade = 0.85 + 0.3 * rand();
    mid.push(b.vertex([cx + cs * rm, cy + H * 0.42 + droop * 0.25, cz + sn * rm], nrm, mulC(mixC(cTip, cRim, 0.5), shade), windBase + windH * 0.5));
    rim.push(b.vertex([cx + cs * rr, cy - droop * (0.6 + 0.8 * rand()), cz + sn * rr], [cs * H, R * 0.6, sn * H], mulC(cRim, shade * 0.9), windBase));
  }
  for (let i = 0; i < seg; i++) {
    const j = (i + 1) % seg;
    b.tri(apex, mid[j], mid[i]);
    b.tri(mid[i], mid[j], rim[i]);
    b.tri(mid[j], rim[j], rim[i]);
  }
}

// Icosfera unitaria subdividida (cacheada por nivel).
const icoCache = new Map();
function icosphere(level) {
  if (icoCache.has(level)) return icoCache.get(level);
  const t = (1 + Math.sqrt(5)) / 2;
  let verts = [[-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0], [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t], [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]].map((v) => {
    const l = Math.hypot(...v);
    return [v[0] / l, v[1] / l, v[2] / l];
  });
  let faces = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]];
  for (let l = 0; l < level; l++) {
    const cache = new Map();
    const mid = (a, c) => {
      const key = a < c ? `${a}_${c}` : `${c}_${a}`;
      if (cache.has(key)) return cache.get(key);
      const m = [(verts[a][0] + verts[c][0]) / 2, (verts[a][1] + verts[c][1]) / 2, (verts[a][2] + verts[c][2]) / 2];
      const ln = Math.hypot(...m);
      verts.push([m[0] / ln, m[1] / ln, m[2] / ln]);
      cache.set(key, verts.length - 1);
      return verts.length - 1;
    };
    const nf = [];
    for (const [a, c, d] of faces) {
      const ab = mid(a, c), cd = mid(c, d), da = mid(d, a);
      nf.push([a, ab, da], [c, cd, ab], [d, da, cd], [ab, cd, da]);
    }
    faces = nf;
  }
  const out = { verts, faces };
  icoCache.set(level, out);
  return out;
}

// Mata de hojas: icosfera deformada con ruido. La normal mezcla la radial de la mata con la de toda la copa
// (sombreado suave de «masa de hojas», sin caras visibles).
function addBlob(b, c, radii, level, colBase, colTop, rand, canopyC, soft, windBase, windH, baseY, topY, seed, cards = 0, cardSize = 1) {
  const { verts, faces } = icosphere(level);
  const ox = rand() * 50, oy = rand() * 50;
  const ids = verts.map((u) => {
    const n = 1 + 0.22 * noise2(u[0] * 2.3 + ox, u[2] * 2.3 + u[1] * 1.7 + oy, seed) + 0.1 * noise2(u[1] * 4.1 + oy, u[0] * 3.7 - ox, seed + 3);
    const p = [c[0] + u[0] * radii[0] * n, c[1] + u[1] * radii[1] * n, c[2] + u[2] * radii[2] * n];
    const toC = [p[0] - canopyC[0], p[1] - canopyC[1], p[2] - canopyC[2]];
    const tl = Math.hypot(...toC) || 1;
    const nrm = [u[0] * (1 - soft) + (toC[0] / tl) * soft, u[1] * (1 - soft) + (toC[1] / tl) * soft + 0.15, u[2] * (1 - soft) + (toC[2] / tl) * soft];
    const hgt = clamp01((p[1] - baseY) / Math.max(0.01, topY - baseY));
    const ao = 0.5 + 0.5 * smoothstep(0, 0.65, hgt);
    const col = mulC(mixC(colBase, colTop, smoothstep(0.1, 0.95, hgt) * 0.8 + 0.2 * rand()), ao * (0.88 + 0.24 * rand()));
    return b.vertex(p, nrm, col, windBase + windH * (0.45 + 0.55 * hgt));
  });
  for (const [a, d, e] of faces) b.tri(ids[a], ids[d], ids[e]);
  if (cards > 0) addLeafCards(b, { c, radii, ox, oy, seed, cards, size: cardSize, colBase, colTop, rand, canopyC, soft, windBase, windH, baseY, topY });
}

// Tarjetas de hojas: cuadrados con la forma de un racimo de hojas (el sombreador recorta el borde con ayuda de uv) pegados a la
// superficie de la mata, con la misma normal suave que ella. Dan al contorno de la copa su aspecto desflecado y con hojas.
function addLeafCards(b, o) {
  const { c, radii, ox, oy, seed, cards, size, colBase, colTop, rand, canopyC, soft, windBase, windH, baseY, topY } = o;
  const h = size / 2;
  for (let i = 0; i < cards; i++) {
    // Dirección al azar sobre la esfera, algo más densa hacia arriba (donde da el sol).
    let u;
    do {
      const z = rand() * 2 - 1, a = rand() * Math.PI * 2, r = Math.sqrt(1 - z * z);
      u = [r * Math.cos(a), z, r * Math.sin(a)];
    } while (u[1] < -0.45 && rand() < 0.8);
    const n = 1 + 0.22 * noise2(u[0] * 2.3 + ox, u[2] * 2.3 + u[1] * 1.7 + oy, seed) + 0.1 * noise2(u[1] * 4.1 + oy, u[0] * 3.7 - ox, seed + 3);
    const sp = [c[0] + u[0] * radii[0] * n, c[1] + u[1] * radii[1] * n, c[2] + u[2] * radii[2] * n];
    const toC = [sp[0] - canopyC[0], sp[1] - canopyC[1], sp[2] - canopyC[2]];
    const tl = Math.hypot(...toC) || 1;
    const nrm = [u[0] * (1 - soft) + (toC[0] / tl) * soft, u[1] * (1 - soft) + (toC[1] / tl) * soft + 0.15, u[2] * (1 - soft) + (toC[2] / tl) * soft];
    const nl = Math.hypot(...nrm) || 1;
    const nn = [nrm[0] / nl, nrm[1] / nl, nrm[2] / nl];
    const [tu, tv] = basis(nn);
    const roll = rand() * Math.PI * 2, cr = Math.cos(roll), sr = Math.sin(roll);
    const ax = [tu[0] * cr + tv[0] * sr, tu[1] * cr + tv[1] * sr, tu[2] * cr + tv[2] * sr];
    const ay = [-tu[0] * sr + tv[0] * cr, -tu[1] * sr + tv[1] * cr, -tu[2] * sr + tv[2] * cr];
    // Un poco por fuera de la superficie y ladeada, para que no quede pegada como una pegatina.
    const lift = 0.12 + 0.1 * rand();
    const cen = [sp[0] + nn[0] * lift, sp[1] + nn[1] * lift, sp[2] + nn[2] * lift];
    const hgt = clamp01((cen[1] - baseY) / Math.max(0.01, topY - baseY));
    const ao = 0.55 + 0.45 * smoothstep(0, 0.65, hgt);
    const col = mulC(mixC(colBase, colTop, smoothstep(0.1, 0.95, hgt) * 0.75 + 0.25 * rand()), ao * (0.9 + 0.28 * rand()));
    const w = windBase + windH * (0.5 + 0.5 * hgt);
    const sz = h * (0.8 + 0.4 * rand());
    const ids = [[-1, -1, 0, 0], [1, -1, 1, 0], [1, 1, 1, 1], [-1, 1, 0, 1]].map(([sx, sy, uu, vv]) =>
      b.vertex([cen[0] + (ax[0] * sx + ay[0] * sy) * sz, cen[1] + (ax[1] * sx + ay[1] * sy) * sz, cen[2] + (ax[2] * sx + ay[2] * sy) * sz], nn, col, w, [uu, vv]));
    b.tri(ids[0], ids[1], ids[2]);
    b.tri(ids[0], ids[2], ids[3]);
  }
}

// Roca: icosfera deformada con caras planas (normales por cara) y musgo arriba.
function addRock(b, level, rand, colA, colB, moss, sx, sy, sz, seed) {
  const { verts, faces } = icosphere(level);
  const ox = rand() * 40, oy = rand() * 40;
  const P = verts.map((u) => {
    const n = 1 + 0.32 * noise2(u[0] * 1.6 + ox, u[2] * 1.6 + oy, seed) + 0.14 * noise2(u[1] * 3.4 + oy, u[0] * 3.1 + ox, seed + 1);
    return [u[0] * sx * n, Math.max(-0.35 * sy, u[1] * sy * n), u[2] * sz * n];
  });
  for (const [a, c, d] of faces) {
    const A = P[a], B = P[c], C = P[d];
    const e1 = [B[0] - A[0], B[1] - A[1], B[2] - A[2]], e2 = [C[0] - A[0], C[1] - A[1], C[2] - A[2]];
    const n = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
    const nl = Math.hypot(...n) || 1;
    n[0] /= nl; n[1] /= nl; n[2] /= nl;
    const base = mixC(colA, colB, rand());
    const top = smoothstep(0.55, 0.9, n[1]);
    const col = mulC(mixC(base, moss, top * 0.75), 0.85 + 0.3 * rand());
    const ids = [A, B, C].map((p) => b.vertex(p, n, col, 0));
    b.tri(ids[0], ids[1], ids[2]);
  }
}

// ── Plantillas ────────────────────────────────────────────────────────────────────────────────────
const BARK = lin(0x4b3626), BARK_LIGHT = lin(0x6b4f38), BIRCH = lin(0xd8d4c8);

function conifer(seed, low) {
  const rand = rng(seed), b = new Builder();
  const H = 10 + rand() * 3;
  addTube(b, [0, 0, 0], [0, H * 0.85, 0], 0.3, 0.07, low ? 5 : 7, BARK, BARK_LIGHT, 0.02, 0.15, rand);
  const tiers = low ? 3 : 6;
  const dark = lin(0x1d4a2b), light = lin(0x3f7a3d), rimC = lin(0x173d24);
  for (let k = 0; k < tiers; k++) {
    const f = k / (tiers - 1);
    const cy = H * (0.17 + 0.62 * f) * (low ? 0.9 : 1);
    const R = (2.5 - 1.6 * f) * (low ? 1.12 : 1) * (0.94 + 0.12 * rand());
    const th = (low ? 4.4 : 2.7) - 0.9 * f;
    addTier(b, 0, cy, 0, R, th, low ? 6 : 10, 0.35 + 0.2 * (1 - f), mixC(light, dark, 0.25 + 0.3 * f), mixC(dark, rimC, 0.5), rand, 0.12 + 0.3 * f, 0.45 * (0.4 + f));
  }
  return b.finish();
}

function broadleaf(seed, low, cards = false) {
  const rand = rng(seed), b = new Builder();
  const trunkH = 3.8 + rand() * 1.2;
  addTube(b, [0, 0, 0], [0.1, trunkH, 0], 0.38, 0.17, low ? 5 : 7, BARK, BARK_LIGHT, 0.02, 0.12, rand);
  const baseY = trunkH - 0.4, topY = trunkH + 5;
  const cc = [0.1, trunkH + 2.1, 0];
  const g1 = lin(0x2f6b27), g2 = lin(0x4f8f2f), g3 = lin(0x3f7c2c);
  const blobs = low
    ? [[[0, trunkH + 2.3, 0], [3.1, 2.6, 3.1], 1, g1]]
    : [
        [[0, trunkH + 2.4, 0], [2.7, 2.3, 2.7], 2, g1],
        [[1.9, trunkH + 1.3, 0.8], [1.8, 1.5, 1.8], 1, g3],
        [[-1.7, trunkH + 1.6, -0.9], [1.9, 1.6, 1.9], 1, g1],
        [[0.4, trunkH + 1.3, -2], [1.7, 1.4, 1.7], 1, g3],
        [[-0.6, trunkH + 3.6, 1.2], [1.6, 1.4, 1.6], 1, g2],
      ];
  if (!low) {
    for (const [dx, dz] of [[1.2, 0.4], [-1.1, -0.5], [0.2, -1.3]]) addTube(b, [0.05, trunkH * 0.78, 0], [dx, trunkH + 1.2, dz], 0.12, 0.05, 5, BARK, BARK_LIGHT, 0.08, 0.2, rand);
  }
  blobs.forEach(([c, r, lvl, col], i) => addBlob(b, c, r, lvl, mulC(col, 0.8), mulC(col, 1.45), rand, cc, low ? 0.2 : 0.55, 0.15, 0.55, baseY, topY, seed + i, cards && !low ? (i === 0 ? 46 : 18) : 0, 1.35));
  return b.finish();
}

function birch(seed, low, cards = false) {
  const rand = rng(seed), b = new Builder();
  const H = 6 + rand() * 1.5;
  addTube(b, [0, 0, 0], [0.12, H, 0], 0.17, 0.06, low ? 4 : 6, BIRCH, mulC(BIRCH, 0.9), 0.03, 0.25, rand);
  const gl = lin(0x7aa63a), gd = lin(0x5b8d2e);
  const cc = [0.1, H - 0.8, 0];
  const blobs = low ? [[[0.1, H - 0.8, 0], [1.9, 2.4, 1.9], 1]] : [[[0.1, H - 0.6, 0], [1.5, 2.2, 1.5], 2], [[0.7, H - 2, 0.4], [1.2, 1.5, 1.2], 1], [[-0.6, H - 1.4, -0.5], [1.2, 1.7, 1.2], 1]];
  blobs.forEach(([c, r, lvl], i) => addBlob(b, c, r, lvl, mulC(gd, 0.85), mulC(gl, 1.35), rand, cc, 0.5, 0.2, 0.7, H - 3.4, H + 1.5, seed + 9 + i, cards && !low ? (i === 0 ? 34 : 14) : 0, 1.05));
  return b.finish();
}

function rock(seed, low) {
  const rand = rng(seed), b = new Builder();
  addRock(b, low ? 1 : 2, rand, lin(0x6c6a64), lin(0x8b857a), lin(0x4d6a36), 1.2 + rand() * 0.4, 0.8 + rand() * 0.4, 1 + rand() * 0.4, seed);
  return b.finish();
}

function bush(seed, low, cards = false) {
  const rand = rng(seed), b = new Builder();
  const g = lin(0x3e7330), gl = lin(0x5d9a34);
  const cc = [0, 0.5, 0];
  const blobs = low ? [[[0, 0.55, 0], [0.9, 0.7, 0.9], 1]] : [[[0, 0.55, 0], [0.8, 0.65, 0.8], 2], [[0.55, 0.4, 0.2], [0.55, 0.45, 0.55], 1], [[-0.45, 0.4, -0.3], [0.6, 0.45, 0.6], 1]];
  blobs.forEach(([c, r, lvl], i) => addBlob(b, c, r, lvl, mulC(g, 0.75), mulC(gl, 1.3), rand, cc, 0.4, 0.1, 0.5, 0, 1.2, seed + 3 + i, cards && !low ? (i === 0 ? 16 : 7) : 0, 0.55));
  return b.finish();
}

// Conjunto de plantillas por tipo: { full, low } con varias variantes.
// { full, low, cards? }: «cards» = la versión completa con tarjetas de hojas (solo árboles de hoja ancha, abedules y arbustos).
export function buildTemplates() {
  const make = (fn, seeds, withCards = false) => seeds.map((s) => ({ full: fn(s, false), low: fn(s, true), ...(withCards ? { cards: fn(s, false, true) } : {}) }));
  return {
    conifer: make(conifer, [11, 12, 13]),
    broadleaf: make(broadleaf, [21, 22, 23], true),
    birch: make(birch, [31, 32], true),
    rock: make(rock, [41, 42, 43]),
    bush: make(bush, [51, 52], true),
  };
}

// Radio aproximado del tronco (colisión) y de la copa (sombra falsa para la hierba) por tipo, a escala 1.
export const TREE_TRUNK = { conifer: 0.3, broadleaf: 0.38, birch: 0.2 };
export const TREE_CANOPY = { conifer: 2.4, broadleaf: 3.6, birch: 2.2 };
