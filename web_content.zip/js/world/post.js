// Tubería de imagen opcional del mundo: dibuja la escena en un buffer de media precisión y la compone con
//   oclusión ambiental (SSAO) · bloom · rayos de luz (god rays) · mapeo de tonos · gradación de color · aberración cromática ·
//   suavizado (MSAA del buffer, FXAA o TAA-lite) · nitidez · grano de película.
// Solo se usa si algún ajuste lo pide (core/pro.js → post.active); si no, el mundo se dibuja directamente como siempre, sin coste.
// THREE llega por parámetro. Las pasadas son triángulos a pantalla completa con ShaderMaterial.

const VERT = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';

const AO_FS = `
#include <packing>
uniform sampler2D tDepth; uniform mat4 uProjInv; uniform float uNear, uFar, uRadius, uProjY; uniform vec2 uRes;
varying vec2 vUv;
vec3 viewPos(vec2 uv){ float d = texture2D(tDepth, uv).x; vec4 p = uProjInv * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0); return p.xyz / p.w; }
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
void main(){
  float d0 = texture2D(tDepth, vUv).x;
  if (d0 >= 0.99999) { gl_FragColor = vec4(1.0); return; }
  vec3 P = viewPos(vUv);
  vec3 N = normalize(cross(dFdx(P), dFdy(P)));
  float rs = uRadius * uProjY * 0.5 / max(-P.z, 0.1);
  float rot = hash(gl_FragCoord.xy) * 6.2831853;
  float occ = 0.0;
  for (int i = 0; i < 12; i++) {
    float a = rot + float(i) * 2.399963;
    float r = sqrt((float(i) + 0.5) / 12.0);
    vec2 suv = vUv + vec2(cos(a), sin(a)) * r * rs * vec2(uRes.y / uRes.x, 1.0);
    vec3 S = viewPos(suv);
    vec3 V = S - P;
    float dist = length(V);
    occ += max(dot(N, V / max(dist, 1e-4)) - 0.12, 0.0) * smoothstep(uRadius * 1.6, 0.0, dist);
  }
  float ao = clamp(1.0 - occ / 12.0 * 1.7, 0.0, 1.0);
  ao = mix(ao, 1.0, smoothstep(50.0, 140.0, -P.z)); // lejos no se nota y la profundidad pierde precisión
  gl_FragColor = vec4(vec3(ao), 1.0);
}`;

const BRIGHT_FS = `
uniform sampler2D tSrc; uniform float uThr; varying vec2 vUv;
void main(){
  vec3 c = texture2D(tSrc, vUv).rgb;
  float l = max(c.r, max(c.g, c.b));
  float k = clamp((l - uThr) / max(uThr, 0.001), 0.0, 1.0);
  gl_FragColor = vec4(c * k * k, 1.0);
}`;

const DOWN_FS = `
uniform sampler2D tSrc; uniform vec2 uPx; varying vec2 vUv;
void main(){
  vec3 c = texture2D(tSrc, vUv).rgb * 4.0;
  c += texture2D(tSrc, vUv + uPx * vec2( 1.0,  1.0)).rgb;
  c += texture2D(tSrc, vUv + uPx * vec2(-1.0,  1.0)).rgb;
  c += texture2D(tSrc, vUv + uPx * vec2( 1.0, -1.0)).rgb;
  c += texture2D(tSrc, vUv + uPx * vec2(-1.0, -1.0)).rgb;
  gl_FragColor = vec4(c / 8.0, 1.0);
}`;

const UP_FS = `
uniform sampler2D tSrc, tAdd; uniform vec2 uPx; varying vec2 vUv;
void main(){
  vec3 c = texture2D(tSrc, vUv + uPx * vec2(-1.0, 0.0)).rgb + texture2D(tSrc, vUv + uPx * vec2(1.0, 0.0)).rgb
         + texture2D(tSrc, vUv + uPx * vec2(0.0, -1.0)).rgb + texture2D(tSrc, vUv + uPx * vec2(0.0, 1.0)).rgb
         + texture2D(tSrc, vUv).rgb * 2.0;
  gl_FragColor = vec4(c / 6.0 + texture2D(tAdd, vUv).rgb, 1.0);
}`;

// HDR → imagen visible (codificada en sRGB, 8 bits).
const COMP_FS = `
#include <tonemapping_pars_fragment>
uniform sampler2D tScene, tBloom, tAO;
uniform float uBloom, uUseAO, uRays, uCA, uGrade, uLift, uGamma, uGain, uTemp, uContrast, uSat, uVignette;
uniform vec2 uSun; uniform float uSunVis; uniform int uTone; varying vec2 vUv;
vec3 tone(vec3 c){
  if (uTone == 1) return AgXToneMapping(c);
  if (uTone == 2) return NeutralToneMapping(c);
  if (uTone == 3) return ReinhardToneMapping(c);
  if (uTone == 4) return LinearToneMapping(c);
  return ACESFilmicToneMapping(c);
}
vec3 toSRGB(vec3 c){ c = clamp(c, 0.0, 1.0); return mix(pow(c, vec3(1.0 / 2.4)) * 1.055 - 0.055, c * 12.92, step(c, vec3(0.0031308))); }
void main(){
  vec2 c0 = vUv - 0.5;
  vec3 col;
  if (uCA > 0.0) {
    vec2 o = c0 * uCA * 0.012;
    col = vec3(texture2D(tScene, vUv + o).r, texture2D(tScene, vUv).g, texture2D(tScene, vUv - o).b);
  } else col = texture2D(tScene, vUv).rgb;
  if (uUseAO > 0.5) col *= texture2D(tAO, vUv).r;
  if (uRays > 0.0 && uSunVis > 0.0) {
    vec2 d = (uSun - vUv) / 6.0; vec2 p = vUv; vec3 acc = vec3(0.0);
    for (int i = 0; i < 6; i++) { p += d; vec3 s = texture2D(tScene, p).rgb; acc += s * smoothstep(1.2, 4.0, max(s.r, max(s.g, s.b))) * (1.0 - float(i) / 7.0); }
    col += acc / 6.0 * uRays * uSunVis;
  }
  if (uBloom > 0.0) col += texture2D(tBloom, vUv).rgb * uBloom;
  col = tone(col);
  col = toSRGB(col);
  if (uGrade > 0.5) {
    col = pow(max(col * uGain + vec3(uLift), vec3(0.0)), vec3(1.0 / max(uGamma, 0.01)));
    col.r *= 1.0 + uTemp * 0.1; col.b *= 1.0 - uTemp * 0.1;
    col = (col - 0.5) * uContrast + 0.5;
    float l = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(l), col, uSat);
    col *= 1.0 - uVignette * smoothstep(0.35, 0.85, length(c0) * 1.4142);
  }
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}`;

const TAA_FS = `
uniform sampler2D tCur, tHist; uniform vec2 uRes; uniform float uBlend; uniform float uHas; varying vec2 vUv;
void main(){
  vec3 cur = texture2D(tCur, vUv).rgb;
  if (uHas < 0.5) { gl_FragColor = vec4(cur, 1.0); return; }
  vec3 mn = cur, mx = cur; vec2 px = 1.0 / uRes;
  for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec3 s = texture2D(tCur, vUv + vec2(float(x), float(y)) * px).rgb; mn = min(mn, s); mx = max(mx, s); }
  vec3 hist = clamp(texture2D(tHist, vUv).rgb, mn, mx);
  gl_FragColor = vec4(mix(cur, hist, uBlend), 1.0);
}`;

// Suavizado FXAA (Timothy Lottes, versión corta) + nitidez + grano. Lee la imagen ya visible y escribe tal cual en pantalla.
const FINAL_FS = `
uniform sampler2D tSrc; uniform vec2 uRes; uniform float uFxaa, uSharp, uGrain, uTime; varying vec2 vUv;
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233)) + uTime) * 43758.5453); }
void main(){
  vec2 px = 1.0 / uRes; vec3 luma = vec3(0.299, 0.587, 0.114);
  vec3 m = texture2D(tSrc, vUv).rgb;
  vec3 col = m;
  if (uFxaa > 0.5) {
    vec3 nw = texture2D(tSrc, vUv + vec2(-1.0, -1.0) * px).rgb, ne = texture2D(tSrc, vUv + vec2(1.0, -1.0) * px).rgb;
    vec3 sw = texture2D(tSrc, vUv + vec2(-1.0, 1.0) * px).rgb, se = texture2D(tSrc, vUv + vec2(1.0, 1.0) * px).rgb;
    float lnw = dot(nw, luma), lne = dot(ne, luma), lsw = dot(sw, luma), lse = dot(se, luma), lm = dot(m, luma);
    float lmin = min(lm, min(min(lnw, lne), min(lsw, lse))), lmax = max(lm, max(max(lnw, lne), max(lsw, lse)));
    vec2 dir = vec2(-((lnw + lne) - (lsw + lse)), (lnw + lsw) - (lne + lse));
    float red = max((lnw + lne + lsw + lse) * 0.03125, 0.0078125);
    float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + red);
    dir = clamp(dir * rcp, -8.0, 8.0) * px;
    vec3 a = 0.5 * (texture2D(tSrc, vUv + dir * (1.0 / 3.0 - 0.5)).rgb + texture2D(tSrc, vUv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b = a * 0.5 + 0.25 * (texture2D(tSrc, vUv + dir * -0.5).rgb + texture2D(tSrc, vUv + dir * 0.5).rgb);
    float lb = dot(b, luma);
    col = (lb < lmin || lb > lmax) ? a : b;
  }
  if (uSharp > 0.0) {
    vec3 n = texture2D(tSrc, vUv + vec2(px.x, 0.0)).rgb + texture2D(tSrc, vUv - vec2(px.x, 0.0)).rgb + texture2D(tSrc, vUv + vec2(0.0, px.y)).rgb + texture2D(tSrc, vUv - vec2(0.0, px.y)).rgb;
    col += (col - n * 0.25) * uSharp;
  }
  if (uGrain > 0.0) col += (hash(vUv * uRes) - 0.5) * uGrain * 0.2;
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}`;

const TONE_ID = { ACESFilmic: 0, AgX: 1, Neutral: 2, Reinhard: 3, Linear: 4 };
const halton = (i, b) => { let f = 1, r = 0; while (i > 0) { f /= b; r += (f * (i % b)); i = Math.floor(i / b); } return r; };

export class PostFX {
  constructor(THREE, renderer) {
    this.THREE = THREE;
    this.r = renderer;
    this.cfg = null;
    this.size = { w: 0, h: 0 };
    this.rts = {};
    this.bloomMips = [];
    this.frame = 0;
    this.hasHist = 0;
    this.histIdx = 0;
    this.lastView = new THREE.Matrix4();
    this.disposed = false;
    const hf = renderer.extensions.has('EXT_color_buffer_float') || renderer.extensions.has('EXT_color_buffer_half_float');
    this.ok = !!hf; // sin buffers de media precisión no hay tubería: el mundo se dibuja directo
    const tri = new THREE.BufferGeometry();
    tri.setAttribute('position', new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
    tri.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 2, 0, 0, 2], 2));
    this.mesh = new THREE.Mesh(tri, null);
    this.mesh.frustumCulled = false;
    this.fsScene = new THREE.Scene();
    this.fsScene.add(this.mesh);
    this.fsCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const mk = (fragmentShader, uniforms) => new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader, uniforms, depthTest: false, depthWrite: false, toneMapped: false });
    const U = (v) => ({ value: v });
    const V2 = () => new THREE.Vector2();
    this.m = {
      ao: mk(AO_FS, { tDepth: U(null), uProjInv: U(new THREE.Matrix4()), uNear: U(0.1), uFar: U(100), uRadius: U(4), uProjY: U(1), uRes: U(V2()) }),
      bright: mk(BRIGHT_FS, { tSrc: U(null), uThr: U(0.9) }),
      down: mk(DOWN_FS, { tSrc: U(null), uPx: U(V2()) }),
      up: mk(UP_FS, { tSrc: U(null), tAdd: U(null), uPx: U(V2()) }),
      comp: mk(COMP_FS, {
        tScene: U(null), tBloom: U(null), tAO: U(null), uBloom: U(0), uUseAO: U(0), uRays: U(0), uCA: U(0), uGrade: U(0), uLift: U(0), uGamma: U(1), uGain: U(1), uTemp: U(0),
        uContrast: U(1), uSat: U(1), uVignette: U(0), uSun: U(V2()), uSunVis: U(0), uTone: U(0), toneMappingExposure: U(1),
      }),
      taa: mk(TAA_FS, { tCur: U(null), tHist: U(null), uRes: U(V2()), uBlend: U(0.9), uHas: U(0) }),
      final: mk(FINAL_FS, { tSrc: U(null), uRes: U(V2()), uFxaa: U(0), uSharp: U(0), uGrain: U(0), uTime: U(0) }),
    };
  }

  // post: el objeto que devuelve resolveQuality(...).post
  setConfig(post, toneName = 'ACESFilmic') {
    this.cfg = post;
    this.toneName = toneName;
    this.#disposeTargets();
  }

  get active() {
    return !!(this.ok && this.cfg?.active && !this.disposed);
  }

  #rt(name, w, h, opts = {}) {
    const T = this.THREE;
    const rt = new T.WebGLRenderTarget(w, h, { type: opts.type ?? T.HalfFloatType, format: T.RGBAFormat, minFilter: T.LinearFilter, magFilter: T.LinearFilter, depthBuffer: !!opts.depth, samples: opts.samples || 0, colorSpace: T.NoColorSpace });
    if (opts.depthTexture) {
      rt.depthTexture = new T.DepthTexture(w, h);
      rt.depthTexture.type = T.UnsignedIntType;
    }
    this.rts[name]?.dispose();
    this.rts[name] = rt;
    return rt;
  }

  #ensure(w, h) {
    const c = this.cfg, T = this.THREE;
    const key = `${w}x${h}|${c.aa}|${c.ssao > 0}|${c.bloom > 0}`;
    if (key === this.key) return;
    this.key = key;
    this.#disposeTargets();
    const samples = c.aa === 'msaa' || c.aa === 'canvas' ? 4 : 0; // «canvas»: el suavizado de siempre pasa al buffer
    this.#rt('scene', w, h, { depth: true, samples, depthTexture: c.ssao > 0 });
    this.#rt('ldr', w, h, { type: T.UnsignedByteType });
    if (c.aa === 'taa') {
      this.#rt('histA', w, h, { type: T.UnsignedByteType });
      this.#rt('histB', w, h, { type: T.UnsignedByteType });
      this.hasHist = 0;
    }
    if (c.ssao > 0) this.#rt('ao', Math.max(1, w >> 1), Math.max(1, h >> 1), { type: T.UnsignedByteType });
    this.bloomMips = [];
    if (c.bloom > 0) {
      let bw = w >> 1, bh = h >> 1;
      for (let i = 0; i < 5; i++) {
        this.bloomMips.push({ down: this.#rt(`bd${i}`, Math.max(1, bw), Math.max(1, bh)), up: this.#rt(`bu${i}`, Math.max(1, bw), Math.max(1, bh)) });
        bw >>= 1; bh >>= 1;
      }
    }
    this.size = { w, h };
  }

  #disposeTargets() {
    for (const k of Object.keys(this.rts)) {
      this.rts[k].dispose();
      delete this.rts[k];
    }
    this.key = null;
    this.bloomMips = [];
  }

  #pass(mat, target) {
    this.mesh.material = mat;
    this.r.setRenderTarget(target);
    this.r.render(this.fsScene, this.fsCam);
  }

  // Dibuja la escena con todos los efectos activos y deja el resultado en pantalla. sun: { x, y, visible, alpha } (de computeGlare).
  render(scene, camera, { sun = null, time = 0 } = {}) {
    const T = this.THREE, r = this.r, c = this.cfg;
    const dbs = r.getDrawingBufferSize(new T.Vector2());
    const w = Math.max(2, Math.floor(dbs.x)), h = Math.max(2, Math.floor(dbs.y));
    this.#ensure(w, h);
    const R = this.rts;

    // Jitter de subpíxel para TAA-lite (se quita justo después para no alterar otros cálculos de la cámara).
    let jittered = false;
    if (c.aa === 'taa') {
      const i = (this.frame % 8) + 1;
      camera.setViewOffset(w, h, halton(i, 2) - 0.5, halton(i, 3) - 0.5, w, h);
      jittered = true;
    }
    this.frame++;

    // Con varias pasadas, el contador de llamadas debe sumar todo el fotograma (no quedarse con la última pasada).
    const autoReset = r.info.autoReset;
    r.info.autoReset = false;
    r.info.reset();
    r.setRenderTarget(R.scene);
    r.render(scene, camera);
    if (jittered) camera.clearViewOffset();

    // SSAO (media resolución)
    if (c.ssao > 0 && R.ao) {
      const u = this.m.ao.uniforms;
      u.tDepth.value = R.scene.depthTexture;
      u.uProjInv.value.copy(camera.projectionMatrixInverse);
      u.uNear.value = camera.near; u.uFar.value = camera.far; u.uRadius.value = c.ssao;
      u.uProjY.value = camera.projectionMatrix.elements[5];
      u.uRes.value.set(R.ao.width, R.ao.height);
      this.#pass(this.m.ao, R.ao);
    }

    // Bloom: umbral → bajar 5 niveles → subir sumando
    if (c.bloom > 0 && this.bloomMips.length) {
      const mips = this.bloomMips;
      this.m.bright.uniforms.tSrc.value = R.scene.texture;
      this.m.bright.uniforms.uThr.value = 0.9;
      this.#pass(this.m.bright, mips[0].down);
      for (let i = 1; i < mips.length; i++) {
        this.m.down.uniforms.tSrc.value = mips[i - 1].down.texture;
        this.m.down.uniforms.uPx.value.set(1 / mips[i - 1].down.width, 1 / mips[i - 1].down.height);
        this.#pass(this.m.down, mips[i].down);
      }
      let prev = mips[mips.length - 1].down;
      for (let i = mips.length - 2; i >= 0; i--) {
        this.m.up.uniforms.tSrc.value = prev.texture;
        this.m.up.uniforms.tAdd.value = mips[i].down.texture;
        this.m.up.uniforms.uPx.value.set(1 / prev.width, 1 / prev.height);
        this.#pass(this.m.up, mips[i].up);
        prev = mips[i].up;
      }
      this.bloomTex = prev.texture;
    } else this.bloomTex = null;

    // Composición HDR → visible
    const k = this.m.comp.uniforms;
    k.tScene.value = R.scene.texture;
    k.tBloom.value = this.bloomTex;
    k.tAO.value = R.ao?.texture || null;
    k.uBloom.value = c.bloom > 0 ? c.bloom : 0;
    k.uUseAO.value = c.ssao > 0 ? 1 : 0;
    k.uRays.value = c.rays; k.uCA.value = c.ca;
    k.uSun.value.set(sun?.x ?? 0.5, sun?.y ?? 0.5);
    k.uSunVis.value = sun?.visible ? Math.max(0, sun.alpha ?? 1) : 0;
    k.uGrade.value = c.grade ? 1 : 0;
    k.uLift.value = c.lift; k.uGamma.value = c.gamma; k.uGain.value = c.gain; k.uTemp.value = c.temp;
    k.uContrast.value = c.contrast; k.uSat.value = c.sat; k.uVignette.value = c.vignette;
    k.uTone.value = TONE_ID[this.toneName] ?? 0;
    k.toneMappingExposure.value = r.toneMappingExposure;
    this.#pass(this.m.comp, R.ldr);

    // Suavizado temporal (TAA-lite): mezcla con el fotograma anterior limitando a los vecinos para que no deje estelas.
    let src = R.ldr;
    if (c.aa === 'taa' && R.histA && R.histB) {
      const view = camera.matrixWorldInverse;
      let moved = 0;
      for (let i = 0; i < 16; i++) moved += Math.abs(view.elements[i] - this.lastView.elements[i]);
      this.lastView.copy(view);
      const out = this.histIdx ? R.histA : R.histB, hist = this.histIdx ? R.histB : R.histA;
      const t = this.m.taa.uniforms;
      t.tCur.value = R.ldr.texture; t.tHist.value = hist.texture; t.uRes.value.set(w, h);
      t.uHas.value = this.hasHist; t.uBlend.value = moved > 0.02 ? 0.45 : 0.9;
      this.#pass(this.m.taa, out);
      this.histIdx ^= 1;
      this.hasHist = 1;
      src = out;
    }

    const f = this.m.final.uniforms;
    f.tSrc.value = src.texture; f.uRes.value.set(w, h);
    f.uFxaa.value = c.aa === 'fxaa' ? 1 : 0;
    f.uSharp.value = c.sharpen; f.uGrain.value = c.grain; f.uTime.value = (time % 100) * 0.37;
    this.#pass(this.m.final, null);
    r.info.autoReset = autoReset;
  }

  dispose() {
    this.disposed = true;
    this.#disposeTargets();
    for (const m of Object.values(this.m)) m.dispose();
    this.mesh.geometry.dispose();
  }
}
