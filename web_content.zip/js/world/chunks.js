// Gestor de trozos: decide qué trozos del mundo hay que tener cargados alrededor del jugador, con qué detalle,
// los pide al origen (Worker o hilo principal), los construye de uno en uno por fotograma y descarta los lejanos.
// No depende de Three.js: construir y liberar los objetos gráficos lo hacen las funciones `build` y `entry.dispose()`.
import { CHUNK } from './terrain.js';

const keyOf = (cx, cz) => `${cx},${cz}`;

// Configuración de un trozo según su distancia (en trozos, Chebyshev) y la distancia real del jugador a su borde (m).
// prevGrass: estado anterior de la hierba, para dar histéresis y no regenerar un trozo cada vez que se cruza un límite.
export function chunkConfig(d, rectDist, q, prevGrass = 0) {
  const lod = d === 0 ? 0 : d === 1 ? 1 : d <= 3 ? 2 : 3;
  const props = d <= q.propsFull ? (q.leafCards ? 3 : 2) : d <= q.propsLow ? 1 : 0; // 3 = completa con tarjetas de hojas (ajuste «Follaje realista»)
  let grass = 0;
  if (q.grassRange > 0) {
    if (rectDist <= q.grassRange + (prevGrass ? 14 : 0)) grass = rectDist <= 22 + (prevGrass === 2 ? 12 : 0) ? 2 : 1;
  }
  return { lod, props, grass };
}
export const configKey = (c) => `${c.lod}|${c.props}|${c.grass}`;
export const optionsFor = (c, q) => ({ props: c.props, grassSpacing: c.grass === 2 ? q.grassNear : c.grass === 1 ? q.grassFar : 0, density: q.density });

// Distancia (m) del punto (px, pz) al rectángulo del trozo (cx, cz).
export function rectDistance(px, pz, cx, cz) {
  const rx = Math.max(0, Math.abs(px - (cx * CHUNK + CHUNK / 2)) - CHUNK / 2);
  const rz = Math.max(0, Math.abs(pz - (cz * CHUNK + CHUNK / 2)) - CHUNK / 2);
  return Math.hypot(rx, rz);
}

export class ChunkManager {
  // source.request(cx, cz, lod, opts) → Promise<resultado> · build(resultado, cfg) → entry { dispose() } · q: ver quality.js
  constructor({ source, quality, build, maxInflight = 2, replanEvery = 0.25, replanDistance = 6 }) {
    this.source = source;
    this.q = quality;
    this.build = build;
    this.maxInflight = maxInflight;
    this.replanEvery = replanEvery;
    this.replanDistance = replanDistance;
    this.chunks = new Map(); // clave → { cx, cz, cfg, cfgKey, entry, colliders }
    this.pending = new Map(); // clave → cfgKey en vuelo
    this.todo = [];
    this.ready = []; // resultados esperando a construirse
    this.wanted = new Map(); // clave → cfgKey deseado en el último plan
    this.inflight = 0;
    this.last = null; // { x, z, t }
    this.time = 0;
    this.dirty = true;
    this.disposed = false;
    this.failures = new Map(); // clave → instante del último fallo
    this.stats = { built: 0, discarded: 0, failed: 0 };
  }

  setQuality(q) {
    this.q = q;
    this.dirty = true;
  }

  // Llamar cada fotograma con la posición del jugador (m) y el tiempo transcurrido (s). Devuelve cuántos trozos se construyeron.
  update(px, pz, dt = 0.016) {
    if (this.disposed) return 0;
    this.time += dt;
    const moved = !this.last || Math.hypot(px - this.last.x, pz - this.last.z) > this.replanDistance;
    if (this.dirty || moved || this.time - this.last.t > this.replanEvery * 4 || (this.todo.length === 0 && this.time - this.last.t > this.replanEvery && this.#needsWork())) this.#plan(px, pz);
    this.#dispatch();
    return this.#apply(this.#budget(px, pz));
  }

  #needsWork() {
    for (const [k, want] of this.wanted) {
      const rec = this.chunks.get(k);
      if ((!rec || rec.cfgKey !== want) && this.pending.get(k) !== want) return true;
    }
    return false;
  }

  #budget(px, pz) {
    // Si falta el trozo bajo los pies se construyen más por fotograma.
    const rec = this.chunks.get(keyOf(Math.floor(px / CHUNK), Math.floor(pz / CHUNK)));
    return rec?.entry ? 1 : 3;
  }

  #plan(px, pz) {
    this.dirty = false;
    this.last = { x: px, z: pz, t: this.time };
    const R = this.q.radius;
    const pcx = Math.floor(px / CHUNK), pcz = Math.floor(pz / CHUNK);
    this.wanted.clear();
    const todo = [];
    for (let dz = -R; dz <= R; dz++) {
      for (let dx = -R; dx <= R; dx++) {
        const cx = pcx + dx, cz = pcz + dz;
        const d = Math.max(Math.abs(dx), Math.abs(dz));
        const rd = rectDistance(px, pz, cx, cz);
        if (d === R && rd > R * CHUNK - 4 && dx * dx + dz * dz > R * R * 1.25) continue; // esquinas lejanas: quedan dentro de la niebla
        const k = keyOf(cx, cz);
        const rec = this.chunks.get(k);
        const cfg = chunkConfig(d, rd, this.q, rec?.cfg.grass || 0);
        const ck = configKey(cfg);
        this.wanted.set(k, ck);
        if (rec && rec.cfgKey === ck) continue;
        if (this.pending.get(k) === ck || this.ready.some((r) => r.k === k && r.ck === ck)) continue;
        const failedAt = this.failures.get(k);
        if (failedAt !== undefined && this.time - failedAt < 3) continue;
        todo.push({ k, cx, cz, cfg, ck, prio: (rec ? 2000 : 0) + d * 100 + rd * 0.01 });
      }
    }
    todo.sort((a, b) => a.prio - b.prio);
    this.todo = todo;
    // Descarta lo que quedó fuera.
    for (const [k, rec] of this.chunks) {
      if (this.wanted.has(k)) continue;
      const d = Math.max(Math.abs(rec.cx - pcx), Math.abs(rec.cz - pcz));
      if (d > R + 1 || !this.wanted.has(k)) this.#drop(k, rec);
    }
  }

  #drop(k, rec) {
    try {
      rec.entry?.dispose?.();
    } catch (err) {
      console.warn('[mundo] error al liberar un trozo', err);
    }
    this.chunks.delete(k);
  }

  #dispatch() {
    while (this.inflight < this.maxInflight && this.todo.length) {
      const job = this.todo.shift();
      if (this.pending.has(job.k)) continue;
      this.pending.set(job.k, job.ck);
      this.inflight++;
      this.source
        .request(job.cx, job.cz, job.cfg.lod, optionsFor(job.cfg, this.q))
        .then((result) => {
          if (!this.disposed) this.ready.push({ k: job.k, ck: job.ck, cfg: job.cfg, cx: job.cx, cz: job.cz, result });
        })
        .catch((err) => {
          this.stats.failed++;
          this.failures.set(job.k, this.time);
          console.warn('[mundo] no se pudo generar un trozo', job.k, err?.message || err);
        })
        .finally(() => {
          this.inflight--;
          if (this.pending.get(job.k) === job.ck) this.pending.delete(job.k);
        });
    }
  }

  #apply(budget) {
    let n = 0;
    while (this.ready.length && n < budget) {
      const item = this.ready.shift();
      const want = this.wanted.get(item.k);
      const rec = this.chunks.get(item.k);
      // Fuera de alcance, o llegó tarde y el trozo ya tiene algo mejor: se descarta (el plan volverá a pedirlo si hace falta).
      if (want === undefined || (want !== item.ck && rec?.entry) || rec?.cfgKey === item.ck) {
        this.stats.discarded++;
        continue;
      }
      let entry;
      try {
        entry = this.build(item.result, item.cfg);
      } catch (err) {
        console.warn('[mundo] error al construir un trozo', item.k, err);
        this.stats.failed++;
        this.failures.set(item.k, this.time);
        continue;
      }
      if (rec) {
        try {
          rec.entry?.dispose?.();
        } catch (err) {
          console.warn('[mundo] error al liberar un trozo', err);
        }
      }
      this.chunks.set(item.k, { cx: item.cx, cz: item.cz, cfg: item.cfg, cfgKey: item.ck, entry, colliders: item.result.colliders });
      this.stats.built++;
      n++;
    }
    return n;
  }

  // Círculos de colisión [x, z, r]* del trozo (cx, cz), o null si no está cargado.
  colliders(cx, cz) {
    return this.chunks.get(keyOf(cx, cz))?.colliders || null;
  }

  // ¿Están construidos todos los trozos hasta `ring` trozos alrededor de (px, pz)?
  isReady(px, pz, ring = 1) {
    const pcx = Math.floor(px / CHUNK), pcz = Math.floor(pz / CHUNK);
    for (let dz = -ring; dz <= ring; dz++) for (let dx = -ring; dx <= ring; dx++) if (!this.chunks.get(keyOf(pcx + dx, pcz + dz))?.entry) return false;
    return true;
  }

  // Resumen para la interfaz.
  get summary() {
    return { loaded: this.chunks.size, queued: this.todo.length + this.ready.length, inflight: this.inflight, ...this.stats };
  }

  dispose() {
    this.disposed = true;
    for (const [k, rec] of [...this.chunks]) this.#drop(k, rec);
    this.todo = [];
    this.ready = [];
    this.pending.clear();
  }
}
