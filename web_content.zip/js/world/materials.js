// Materiales del mundo. Reciben THREE por parámetro (Three.js se carga bajo demanda).
//  · Cielo y agua: ShaderMaterial con GLSL propio (glsl.js).
//  · Suelo, árboles, hierba y personaje: MeshStandardMaterial al que se le inyectan pequeños fragmentos con onBeforeCompile
//    (albedo y relieve procedurales, viento, perspectiva aérea). Así conservan las luces y las sombras de Three.js.
// Si un fragmento no encuentra su punto de inyección (otra versión de Three.js) se avisa con onFail y el mundo pasa
// al modo sencillo: materiales estándar sin inyecciones.
import {
  GLSL_SHARED, SKY_VERT, SKY_FRAG, WATER_VERT, WATER_FRAG, GLSL_TERRAIN_FUNCS,
  GLSL_GRASS_VERT_PARS, GLSL_GRASS_BEGIN_VERTEX, GLSL_PROPS_VERT_PARS, GLSL_PROPS_BEGIN_VERTEX, GLSL_PROPS_COLOR, GLSL_CLOUD_SHADOW,
} from './glsl.js';

// Uniformes compartidos por todos los materiales: se actualizan una vez por fotograma y todos los ven.
export function createUniforms(THREE) {
  const v3 = (x = 0, y = 0, z = 0) => ({ value: new THREE.Vector3(x, y, z) });
  const col = (r = 0, g = 0, b = 0) => ({ value: new THREE.Color(r, g, b) });
  return {
    uNoise: { value: null },
    uSkyLut: { value: null },
    uSunDir: v3(0, 1, 0),
    uMoonDir: v3(0, -1, 0),
    uSunDisc: v3(1, 1, 1),
    uCloudLight: v3(1, 1, 1),
    uNightGlow: v3(0, 0, 0),
    uLightE: v3(0.3, 0.3, 0.3),
    uFogColor: col(0.5, 0.6, 0.8),
    uFogSunColor: col(0.7, 0.7, 0.8),
    uFogDensity: { value: 1 / 270 },
    uFogFar: { value: new THREE.Vector2(300, 420) },
    uCloudDrift: { value: new THREE.Vector2(0, 0) },
    uTime: { value: 0 },
    uWind: { value: 1 },
    uLeafy: { value: 0 }, // 1 = follaje con hojas recortadas (ajuste «Follaje realista»)
    uStars: { value: 0 },
    uCloud: { value: 0.3 },
    uHaze: { value: 0 },
    uMoonVis: { value: 0 },
    uExposure: { value: 0.3 },
    uGrassFar: { value: 40 },
    uPlayer: v3(0, 0, 0),
    uFx: { value: new THREE.Vector2(1, 1) },
  };
}

class PatchError extends Error {}

// Reemplaza `marker` por `text`; si el marcador no existe, es un error (la versión de Three.js no coincide).
function must(src, marker, text, what) {
  if (!src.includes(marker)) throw new PatchError(`No se encontró «${marker}» para ${what}`);
  return src.replace(marker, text);
}

// Perspectiva aérea para materiales estándar: se aplica sobre la luz saliente, antes del mapeo de tonos.
// Antes de la niebla se aplica la sombra de las nubes (posición en el mundo = cámara + vector hasta el punto).
const FOG_FRAG = 'outgoingLight *= rwCloudShadow(cameraPosition + (-vViewPosition) * mat3(viewMatrix));\noutgoingLight = rwFog(outgoingLight, (-vViewPosition) * mat3(viewMatrix));\n#include <opaque_fragment>';
const withFog = (src, what) => must(src, '#include <opaque_fragment>', FOG_FRAG, `la niebla de ${what}`);
const withShared = (src, extra = '') => must(src, '#include <common>', `#include <common>\n${GLSL_SHARED}\n${GLSL_CLOUD_SHADOW}\n${extra}`, 'las funciones comunes');

export function patchTerrain(shader, U) {
  Object.assign(shader.uniforms, U);
  let v = shader.vertexShader;
  v = must(v, '#include <common>', '#include <common>\nattribute vec4 splat;\nattribute vec3 tint;\nvarying vec4 vSplat;\nvarying vec3 vTint;\nvarying vec3 vWPos;', 'el suelo (vértice)');
  v = must(v, '#include <project_vertex>', '#include <project_vertex>\nvSplat = splat;\nvTint = tint;\nvWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;', 'el suelo (vértice)');
  let f = shader.fragmentShader;
  f = withShared(f, `varying vec4 vSplat;\nvarying vec3 vTint;\nvarying vec3 vWPos;\n${GLSL_TERRAIN_FUNCS}`);
  f = must(f, '#include <color_fragment>', `#include <color_fragment>
float rwH = 0.0, rwRock = 0.0, rwSnow = 0.0;
{
  float rwDist = length(vViewPosition);
  diffuseColor.rgb = rwTerrainAlbedo(vWPos, vSplat, vTint, rwDist, rwH, rwRock, rwSnow);
}`, 'el color del suelo');
  f = must(f, '#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
roughnessFactor = mix(mix(0.94, 0.8, rwRock), 0.6, rwSnow);
roughnessFactor = mix(roughnessFactor, 0.4, vTint.z * 0.7 * (1.0 - rwSnow));`, 'la rugosidad del suelo');
  f = must(f, '#include <normal_fragment_maps>', '#include <normal_fragment_maps>\nnormal = rwBumpNormal(normal, -vViewPosition, rwH);', 'el relieve del suelo');
  f = withFog(f, 'el suelo');
  shader.vertexShader = v;
  shader.fragmentShader = f;
}

export function patchProps(shader, U) {
  Object.assign(shader.uniforms, U);
  let v = shader.vertexShader;
  v = must(v, '#include <common>', `#include <common>\nuniform float uTime;\nuniform float uWind;\n${GLSL_PROPS_VERT_PARS}`, 'los árboles (vértice)');
  v = must(v, '#include <begin_vertex>', GLSL_PROPS_BEGIN_VERTEX, 'el viento de los árboles');
  let f = withShared(shader.fragmentShader, 'varying vec3 vPropW;\nvarying float vLeaf;\nvarying vec2 vCard;\nuniform float uLeafy;');
  f = must(f, '#include <color_fragment>', `#include <color_fragment>\n${GLSL_PROPS_COLOR}`, 'el color de los árboles');
  f = withFog(f, 'los árboles');
  shader.vertexShader = v;
  shader.fragmentShader = f;
}

export function patchGrass(shader, U) {
  Object.assign(shader.uniforms, U);
  let v = shader.vertexShader;
  v = must(v, '#include <common>', `#include <common>\nuniform float uTime;\nuniform float uWind;\n${GLSL_GRASS_VERT_PARS}`, 'la hierba (vértice)');
  v = must(v, '#include <beginnormal_vertex>', 'vec3 objectNormal = vec3(0.0, 1.0, 0.0);', 'la normal de la hierba');
  v = must(v, '#include <begin_vertex>', GLSL_GRASS_BEGIN_VERTEX, 'los mechones de hierba');
  let f = withShared(shader.fragmentShader, 'varying vec3 vGrassCol;');
  f = must(f, '#include <color_fragment>', '#include <color_fragment>\ndiffuseColor.rgb = vGrassCol;', 'el color de la hierba');
  // Material de doble cara: Three.js da la vuelta a la normal de las caras traseras (quedarían a oscuras, sin Sol). Los mechones se
  // iluminan como el suelo sobre el que están: normal hacia arriba por las dos caras.
  f = must(f, '#include <normal_fragment_maps>', '#include <normal_fragment_maps>\nnormal = normalize(mat3(viewMatrix) * vec3(0.0, 1.0, 0.0));', 'la normal de la hierba');
  f = withFog(f, 'la hierba');
  shader.vertexShader = v;
  shader.fragmentShader = f;
}

export function patchAvatar(shader, U) {
  Object.assign(shader.uniforms, U);
  shader.fragmentShader = withFog(withShared(shader.fragmentShader), 'el personaje');
}

// Fábrica de materiales. onFail(err) se llama (una sola vez por material) si falla una inyección.
export function createMaterials(THREE, U, { onFail = () => {}, simple = false } = {}) {
  const patched = (mat, key, patch) => {
    if (simple) return mat;
    mat.fog = false; // la niebla es la propia (rwFog), no la de Three.js
    mat.customProgramCacheKey = () => key;
    mat.onBeforeCompile = (shader) => {
      try {
        patch(shader, U);
      } catch (err) {
        onFail(err);
      }
    };
    return mat;
  };

  const terrain = patched(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.94, metalness: 0, vertexColors: simple }), 'rw-terrain-2', patchTerrain);
  const props = patched(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.88, metalness: 0, vertexColors: true }), 'rw-props-4', patchProps);
  const grass = patched(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, metalness: 0, side: THREE.DoubleSide }), 'rw-grass-3', patchGrass);

  // Modo sencillo: sin cielo propio (el fondo es un color) y con agua de material estándar.
  const sky = simple ? null : new THREE.ShaderMaterial({ uniforms: U, vertexShader: SKY_VERT, fragmentShader: SKY_FRAG, side: THREE.BackSide, depthWrite: false, fog: false });
  const water = simple
    ? new THREE.MeshStandardMaterial({ color: 0x2c6f86, roughness: 0.15, metalness: 0, transparent: true, opacity: 0.82, depthWrite: false })
    : new THREE.ShaderMaterial({ uniforms: U, vertexShader: WATER_VERT, fragmentShader: WATER_FRAG, transparent: true, depthWrite: false, fog: false });
  return { terrain, props, grass, sky, water, simple };
}

// El personaje conserva sus materiales (texturas del modelo); solo se les añade la niebla.
export function adaptAvatarMaterials(group, U, { simple = false, onFail = () => {} } = {}) {
  const seen = new Set();
  group.traverse((o) => {
    const mats = Array.isArray(o.material) ? o.material : o.material ? [o.material] : [];
    for (const m of mats) {
      if (seen.has(m)) continue;
      seen.add(m);
      if (simple) continue;
      m.fog = false;
      m.customProgramCacheKey = () => 'rw-avatar-2';
      m.onBeforeCompile = (shader) => {
        try {
          patchAvatar(shader, U);
        } catch (err) {
          onFail(err);
        }
      };
      m.needsUpdate = true;
    }
  });
}

// Las criaturas del zoológico traen sus propios materiales (escamas, plumas…). Aquí solo se les añade la niebla propia y las sombras de las
// nubes, encadenando con el onBeforeCompile que ya tengan. Los materiales que no son estándar (fuego, chispas) quedan como están.
export function adaptCreatureMaterials(group, U, { simple = false, onFail = () => {} } = {}) {
  if (simple) return;
  group.traverse((o) => {
    const mats = Array.isArray(o.material) ? o.material : o.material ? [o.material] : [];
    for (const m of mats) {
      if (!m.isMeshStandardMaterial || m.userData.rwFog) continue; // una plantilla se comparte entre instancias: no se parchea dos veces
      m.userData.rwFog = true;
      const prevKey = m.customProgramCacheKey ? m.customProgramCacheKey() : '';
      const prev = m.onBeforeCompile;
      m.fog = false;
      m.customProgramCacheKey = () => `${prevKey}|rw-creature-1`;
      m.onBeforeCompile = (shader, renderer) => {
        try {
          prev?.call(m, shader, renderer);
          for (const k in U) if (!(k in shader.uniforms)) shader.uniforms[k] = U[k]; // no pisa uniformes propios del material
          // Si el material ya declara su propio uTime (el fénix), no se repite la declaración del bloque compartido.
          const ownTime = /uniform\s+float\s+uTime\s*;/.test(shader.fragmentShader);
          const shared = ownTime ? GLSL_SHARED.replace(/uniform\s+float\s+uTime\s*;/, '') : GLSL_SHARED;
          const f = must(shader.fragmentShader, '#include <common>', `#include <common>\n${shared}\n${GLSL_CLOUD_SHADOW}`, 'las funciones comunes de la criatura');
          shader.fragmentShader = withFog(f, 'la criatura');
        } catch (err) {
          onFail(err);
        }
      };
      m.needsUpdate = true;
    }
  });
}
