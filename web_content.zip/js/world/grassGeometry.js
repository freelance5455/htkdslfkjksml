// Geometría de un mechón de hierba (plantilla): 3 hojas cónicas cruzadas, 15 vértices y 9 triángulos.
// Altura 0,4 m en la plantilla (el sombreador la escala por mechón, ver glsl.js). Sin dependencias.
import { rng } from './noise.js';

export const GRASS_HEIGHT = 0.4;

export function buildGrassTuft(blades = 3, seed = 77) {
  const r = rng(seed);
  const pos = [], idx = [];
  for (let b = 0; b < blades; b++) {
    const yaw = (b / blades) * Math.PI * 2 + (r() - 0.5) * 0.5;
    const ox = (r() - 0.5) * 0.12, oz = (r() - 0.5) * 0.12;
    const h = GRASS_HEIGHT * (0.8 + 0.2 * r());
    const w = 0.052 * (0.85 + 0.3 * r());
    const lean = 0.07 + 0.1 * r();
    const c = Math.cos(yaw), s = Math.sin(yaw);
    // Eje de la hoja (ancho) = (c, 0, −s)... ; inclinación hacia (s, 0, c).
    const at = (u, y, k) => [ox + c * u + s * lean * k, y, oz - s * u + c * lean * k];
    const base = pos.length / 3;
    pos.push(...at(-w, 0, 0), ...at(w, 0, 0), ...at(-w * 0.66, h * 0.5, 0.45), ...at(w * 0.66, h * 0.5, 0.45), ...at(0, h, 1));
    idx.push(base, base + 1, base + 2, base + 1, base + 3, base + 2, base + 2, base + 3, base + 4);
  }
  return { positions: new Float32Array(pos), indices: new Uint16Array(idx), height: GRASS_HEIGHT };
}
