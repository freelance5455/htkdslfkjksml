// Renderizador del mundo: escena de Three.js con cielo, luces, sombras, niebla, trozos de terreno/agua/árboles/hierba y
// el personaje. Recibe THREE por parámetro (se carga bajo demanda). La lógica de qué trozos existen está en chunks.js;
// los números de luz y atmósfera salen de atmosphere.js / sceneState.js.
import { createRenderer, releaseRenderer } from '../core/gl.js';
import { generateNoiseData, NOISE_SIZE } from './noiseTexture.js';
import { SkyLut, atmosphereState, WEATHER, sunDirection, acesTone } from './atmosphere.js';
import { createUniforms, createMaterials, adaptAvatarMaterials, adaptCreatureMaterials } from './materials.js';
import { sceneValues, lightValues, writeUniforms } from './sceneState.js';
import { buildGrassTuft, GRASS_HEIGHT } from './grassGeometry.js';
import { CHUNK, heightAt } from './terrain.js';
import { viewDistance } from './quality.js';
import { PostFX } from './post.js';

const SKY_RADIUS = 100;
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

// Colores del suelo para el modo sencillo (sin sombreador propio): mezcla de las capas con la misma paleta.
export function terrainVertexColors(splat, tint, count) {
  const out = new Float32Array(count * 3);
  for (let v = 0; v < count; v++) {
    const g = splat[v * 4], r = splat[v * 4 + 1], s = splat[v * 4 + 2], n = splat[v * 4 + 3];
    const lush = tint[v * 3], ao = tint[v * 3 + 1], wet = tint[v * 3 + 2];
    const gr = [0.22 + (0.046 - 0.22) * lush, 0.2 + (0.135 - 0.2) * lush, 0.07 + (0.022 - 0.07) * lush];
    const k = ao * (1 - 0.4 * wet);
    out[v * 3] = (gr[0] * g + 0.27 * r + 0.6 * s + 0.84 * n) * k;
    out[v * 3 + 1] = (gr[1] * g + 0.24 * r + 0.52 * s + 0.88 * n) * k;
    out[v * 3 + 2] = (gr[2] * g + 0.2 * r + 0.36 * s + 0.93 * n) * k;
  }
  return out;
}

export class WorldRenderer {
  // opts: { quality, simple, onShaderError(err), onContextLost() }
  constructor(THREE, canvas, opts = {}) {
    this.THREE = THREE;
    this.canvas = canvas;
    this.q = opts.quality;
    this.simple = !!opts.simple;
    this.onShaderError = opts.onShaderError || (() => {});
    this.onContextLost = opts.onContextLost || (() => {});
    this.scale = 1;
    this.disposed = false;
    this.hours = 9.5;
    this.weatherKey = 'clear';
    this.weather = { cloud: WEATHER.clear.cloud, fog: WEATHER.clear.fog };
    this.exposure = 0.3;
    this.time = 0;
    this.state = null;
    this.glare = { x: 0.5, y: 0.5, alpha: 0, visible: false };
    this.sunKey = null;
    this.failedPatches = 0;
    this.post = null; // tubería de imagen opcional (world/post.js); solo se crea si un ajuste la pide

    this.renderer = createRenderer(THREE, canvas, { antialias: this.q.antialias, alpha: false, pixelRatio: 1 });
    if (!this.renderer) throw new Error('No se pudo crear el contexto WebGL en este dispositivo.');
    const r = this.renderer;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = this.exposure;
    r.shadowMap.enabled = this.q.shadow > 0;
    r.shadowMap.type = THREE.PCFShadowMap; // desde r182 es la suave (PCFSoftShadowMap quedó obsoleta)
    r.debug.onShaderError = (gl, program, vs, fs) => {
      const log = gl.getProgramInfoLog?.(program) || '';
      this.onShaderError(new Error(`Error de sombreador: ${log.slice(0, 400)}`));
    };
    canvas.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      this.onContextLost();
    });

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(62, 1, 0.1, viewDistance(this.q) * 1.2);
    this.scene.add(this.camera);

    // Texturas: ruido repetible y tabla del cielo (media precisión: se filtra bien en WebGL 2).
    const noise = new THREE.DataTexture(generateNoiseData(), NOISE_SIZE, NOISE_SIZE, THREE.RGBAFormat);
    noise.wrapS = noise.wrapT = THREE.RepeatWrapping;
    noise.magFilter = THREE.LinearFilter;
    noise.minFilter = THREE.LinearMipmapLinearFilter;
    noise.generateMipmaps = true;
    noise.anisotropy = 4;
    noise.needsUpdate = true;
    this.lut = new SkyLut();
    const lutTex = new THREE.DataTexture(this.lut.half, this.lut.w, this.lut.h, THREE.RGBAFormat, THREE.HalfFloatType);
    lutTex.magFilter = lutTex.minFilter = THREE.LinearFilter;
    lutTex.wrapS = lutTex.wrapT = THREE.ClampToEdgeWrapping;
    lutTex.generateMipmaps = false;
    lutTex.needsUpdate = true;
    this.textures = [noise, lutTex];
    this.lutTex = lutTex;

    this.U = createUniforms(THREE);
    this.U.uNoise.value = noise;
    this.U.uSkyLut.value = lutTex;
    this.#makeMaterials();

    // Luces: Sol (con sombras), Luna, hemisferio (cielo/suelo). Las intensidades son 1 y el color lleva la irradiancia.
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x888888, 1);
    this.sun = new THREE.DirectionalLight(0xffffff, 1);
    this.moon = new THREE.DirectionalLight(0x8899ff, 1);
    this.scene.add(this.hemi, this.sun, this.sun.target, this.moon, this.moon.target);
    this.#configureShadow();

    // Cielo: esfera centrada en la cámara.
    if (this.mats.sky) {
      this.sky = new THREE.Mesh(new THREE.SphereGeometry(1, 40, 20), this.mats.sky);
      this.sky.scale.setScalar(SKY_RADIUS);
      this.sky.frustumCulled = false;
      this.sky.renderOrder = -10;
      this.scene.add(this.sky);
    }

    this.world = new THREE.Group();
    this.scene.add(this.world);
    this.avatarRoot = new THREE.Group();
    this.scene.add(this.avatarRoot);

    // Mechón de hierba compartido por todos los trozos.
    const tuft = buildGrassTuft();
    this.tuft = new THREE.BufferGeometry();
    this.tuft.setAttribute('position', new THREE.BufferAttribute(tuft.positions, 3));
    this.tuft.setIndex(new THREE.BufferAttribute(tuft.indices, 1));
    this.chunkEntries = new Set();

    this.lut.fill(sunDirection(this.hours));
    this.lutTex.needsUpdate = true;
    this.update(0, { hours: this.hours, weatherKey: this.weatherKey, playerPos: [0, 0, 0], camera: null });
  }

  #makeMaterials() {
    this.mats = createMaterials(this.THREE, this.U, {
      simple: this.simple,
      onFail: (err) => {
        this.failedPatches++;
        this.onShaderError(err);
      },
    });
    for (const m of [this.mats.terrain, this.mats.props, this.mats.grass]) m.shadowSide = this.THREE.DoubleSide;
    this.mats.terrain.shadowSide = this.THREE.FrontSide; // un terreno abierto: la cara que mira a la luz es la frontal
    if (this.simple) {
      this.scene.fog = new this.THREE.FogExp2(0x9ab0c8, 1 / 270);
      this.scene.background = new this.THREE.Color(0x9ab0c8);
    }
  }

  #configureShadow() {
    const s = this.sun.shadow;
    const size = this.q.shadow || 512;
    s.mapSize.set(size, size);
    s.bias = -0.0004;
    s.normalBias = 0.07;
    const S = this.q.shadowSpan;
    Object.assign(s.camera, { left: -S, right: S, top: S, bottom: -S, near: 1, far: 340 });
    s.camera.updateProjectionMatrix();
    this.sun.castShadow = this.q.shadow > 0 && !this.shadowOff;
  }

  // ── Calidad y tamaño ─────────────────────────────────────────────────────────────────────────
  setQuality(q) {
    this.q = q;
    const r = this.renderer;
    r.shadowMap.enabled = q.shadow > 0 && !this.shadowOff;
    const s = this.sun.shadow;
    if (s.map && s.mapSize.x !== (q.shadow || 512)) {
      s.map.dispose();
      s.map = null;
    }
    this.#configureShadow();
    this.camera.far = this.farOverride || viewDistance(q) * 1.2;
    this.camera.updateProjectionMatrix();
    this.resize();
  }

  // Mundos gigantes (SHENLONG): plano lejano propio y sin sombras del Sol (el terreno de ese mundo no las recibe).
  setWorldProfile({ far = 0, shadows = true } = {}) {
    this.farOverride = far;
    this.shadowOff = !shadows;
    this.renderer.shadowMap.enabled = this.q.shadow > 0 && shadows;
    this.sun.castShadow = this.q.shadow > 0 && shadows;
    this.camera.far = far || viewDistance(this.q) * 1.2;
    this.camera.updateProjectionMatrix();
  }

  // Ajustes avanzados (core/pro.js → resolveQuality): mapeo de tonos, efectos de imagen y filtrado anisotrópico.
  applyPro(res) {
    const T = this.THREE;
    const TM = { ACESFilmic: T.ACESFilmicToneMapping, AgX: T.AgXToneMapping, Neutral: T.NeutralToneMapping, Reinhard: T.ReinhardToneMapping, Linear: T.LinearToneMapping };
    this.renderer.toneMapping = TM[res.toneMapping] ?? T.ACESFilmicToneMapping;
    this.toneName = res.toneMapping;
    this.U.uLeafy.value = res.leaves && !this.simple ? 1 : 0;
    if (res.post?.active && !this.simple) {
      this.post ||= new PostFX(T, this.renderer);
      this.post.setConfig(res.post, res.toneMapping);
    } else this.post?.setConfig({ active: false }, res.toneMapping);
    const max = this.renderer.capabilities?.getMaxAnisotropy?.() || 1;
    this.aniso = res.aniso ? Math.min(res.aniso, max) : 0;
    for (const t of this.textures) if (this.aniso && t.anisotropy !== this.aniso) { t.anisotropy = this.aniso; t.needsUpdate = true; }
  }

  // k: factor de resolución del gobernador de fotogramas (0,4 … 1).
  setScale(k) {
    this.scale = clamp(k, 0.4, 1);
    this.resize();
  }

  resize() {
    if (this.disposed) return;
    const parent = this.canvas.parentElement;
    const w = Math.max(1, parent?.clientWidth || this.canvas.clientWidth || 1);
    const h = Math.max(1, parent?.clientHeight || this.canvas.clientHeight || 1);
    const dpr = Math.min(window.devicePixelRatio || 1, this.q.pixelRatio) * this.scale;
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.size = { w, h, dpr };
  }

  // ── Trozos ───────────────────────────────────────────────────────────────────────────────────
  // Construye los objetos de un trozo a partir del resultado de generateChunk. Devuelve { dispose }.
  buildChunk(result, cfg) {
    const T = this.THREE;
    const group = new T.Group();
    group.position.set(result.cx * CHUNK, 0, result.cz * CHUNK);
    group.updateMatrix();
    group.matrixAutoUpdate = false;
    const geos = [];
    const add = (mesh, geo, kind) => {
      mesh.userData.kind = kind;
      group.add(mesh);
      geos.push(geo);
    };
    const mid = (a, b) => (a + b) / 2;

    // Terreno
    const t = result.terrain;
    const tg = new T.BufferGeometry();
    tg.setAttribute('position', new T.BufferAttribute(t.positions, 3));
    tg.setAttribute('normal', new T.BufferAttribute(t.normals, 3));
    tg.setAttribute('splat', new T.BufferAttribute(t.splat, 4));
    tg.setAttribute('tint', new T.BufferAttribute(t.tint, 3));
    tg.setIndex(new T.BufferAttribute(t.indices, 1));
    tg.boundingSphere = new T.Sphere(new T.Vector3(CHUNK / 2, mid(t.minY, t.maxY), CHUNK / 2), Math.hypot(CHUNK / 2, CHUNK / 2, (t.maxY - t.minY) / 2 + 4));
    const tm = new T.Mesh(tg, this.mats.terrain);
    tm.castShadow = cfg.lod <= 1 && this.q.shadow > 0;
    tm.receiveShadow = true;
    if (this.simple) tg.setAttribute('color', new T.BufferAttribute(terrainVertexColors(t.splat, t.tint, t.positions.length / 3), 3));
    add(tm, tg, 'terrain');

    // Agua
    if (result.water) {
      const w = result.water;
      const wg = new T.BufferGeometry();
      wg.setAttribute('position', new T.BufferAttribute(w.positions, 3));
      wg.setAttribute('aDepth', new T.BufferAttribute(w.depth, 1));
      if (this.simple) {
        const n = new Float32Array(w.positions.length);
        for (let i = 1; i < n.length; i += 3) n[i] = 1;
        wg.setAttribute('normal', new T.BufferAttribute(n, 3));
      }
      wg.setIndex(new T.BufferAttribute(w.indices, 1));
      wg.boundingSphere = new T.Sphere(new T.Vector3(CHUNK / 2, 0, CHUNK / 2), CHUNK * 0.75);
      const wm = new T.Mesh(wg, this.mats.water);
      wm.renderOrder = 5;
      add(wm, wg, 'water');
    }

    // Árboles, rocas y arbustos fusionados
    if (result.props) {
      const p = result.props;
      const pg = new T.BufferGeometry();
      pg.setAttribute('position', new T.BufferAttribute(p.positions, 3));
      pg.setAttribute('normal', new T.BufferAttribute(p.normals, 3));
      pg.setAttribute('color', new T.BufferAttribute(p.colors, 3));
      pg.setAttribute('wind', new T.BufferAttribute(p.wind, 2));
      pg.setAttribute('uv', new T.BufferAttribute(p.uvs, 2)); // (-1,-1) salvo en las tarjetas de hojas
      pg.setIndex(new T.BufferAttribute(p.indices, 1));
      pg.computeBoundingSphere();
      pg.boundingSphere.radius += 1.5; // el viento mueve las copas
      const pm = new T.Mesh(pg, this.mats.props);
      pm.castShadow = this.q.shadow > 0;
      pm.receiveShadow = true;
      add(pm, pg, 'props');
    }

    // Hierba (mechones instanciados)
    if (result.grass && result.grass.count && !this.simple) {
      const g = result.grass;
      const gg = new T.InstancedBufferGeometry();
      gg.setIndex(this.tuft.index);
      gg.setAttribute('position', this.tuft.attributes.position);
      const buf = new T.InstancedInterleavedBuffer(g.data, 8, 1);
      gg.setAttribute('iA', new T.InterleavedBufferAttribute(buf, 4, 0));
      gg.setAttribute('iB', new T.InterleavedBufferAttribute(buf, 4, 4));
      gg.instanceCount = g.count;
      gg.boundingSphere = new T.Sphere(new T.Vector3(CHUNK / 2, mid(t.minY, t.maxY), CHUNK / 2), Math.hypot(CHUNK / 2, CHUNK / 2, (t.maxY - t.minY) / 2 + GRASS_HEIGHT * 2));
      const gm = new T.Mesh(gg, this.mats.grass);
      gm.receiveShadow = true;
      add(gm, gg, 'grass');
    }

    this.world.add(group);
    const entry = {
      group,
      dispose: () => {
        this.world.remove(group);
        for (const g of geos) g.dispose();
        this.chunkEntries.delete(entry);
      },
    };
    this.chunkEntries.add(entry);
    return entry;
  }

  // Pasa al modo sencillo (si fallaron los sombreadores propios): materiales estándar, cielo de un color y niebla de Three.js.
  enterSimpleMode() {
    if (this.simple) return;
    this.simple = true;
    if (this.sky) {
      this.scene.remove(this.sky);
      this.sky.geometry.dispose();
      this.sky = null;
    }
    const old = this.mats;
    this.#makeMaterials();
    const T = this.THREE;
    for (const entry of this.chunkEntries) {
      entry.group.traverse((o) => {
        const kind = o.userData?.kind;
        if (!kind) return;
        if (kind === 'terrain') {
          const a = o.geometry.attributes;
          if (!a.color) o.geometry.setAttribute('color', new T.BufferAttribute(terrainVertexColors(a.splat.array, a.tint.array, a.position.count), 3));
          o.material = this.mats.terrain;
        } else if (kind === 'props') o.material = this.mats.props;
        else if (kind === 'water') {
          if (!o.geometry.attributes.normal) {
            const n = new Float32Array(o.geometry.attributes.position.array.length);
            for (let i = 1; i < n.length; i += 3) n[i] = 1;
            o.geometry.setAttribute('normal', new T.BufferAttribute(n, 3));
          }
          o.material = this.mats.water;
        } else if (kind === 'grass') o.visible = false;
      });
    }
    if (this.avatar) adaptAvatarMaterials(this.avatar, this.U, { simple: true });
    for (const m of Object.values(old)) m?.dispose?.();
  }

  // ── Personaje ────────────────────────────────────────────────────────────────────────────────
  setAvatar(group) {
    if (this.avatar) this.avatarRoot.remove(this.avatar);
    this.avatar = group;
    if (!group) return;
    adaptAvatarMaterials(group, this.U, { simple: this.simple, onFail: (err) => this.onShaderError(err) });
    group.traverse((o) => {
      if (o.isMesh) {
        o.castShadow = this.q.shadow > 0;
        o.receiveShadow = true;
      }
    });
    this.avatarRoot.add(group);
  }

  // Criaturas del zoológico: niebla y sombras de nubes de EDEN, y que reciban las sombras del Sol. Un fallo aquí no afecta al mundo.
  adaptCreature(group) {
    adaptCreatureMaterials(group, this.U, { simple: this.simple, onFail: (err) => console.warn('[mundo] criatura sin niebla', err) });
    group.traverse((o) => { if (o.isMesh) o.receiveShadow = true; });
  }

  // ── Atmósfera y luces ────────────────────────────────────────────────────────────────────────
  setTime(hours) {
    this.hours = ((hours % 24) + 24) % 24;
  }
  setWeather(key) {
    if (WEATHER[key]) this.weatherKey = key;
  }

  // Actualiza cielo, luces, niebla y sombras. cam: { x, y, z, yaw, pitch } (opcional). Devuelve el estado atmosférico.
  update(dt, { hours = this.hours, weatherKey = this.weatherKey, playerPos = [0, 0, 0], camera = null } = {}) {
    this.hours = hours;
    this.time += dt;
    // El clima cambia poco a poco.
    const target = WEATHER[weatherKey] || WEATHER.clear;
    const k = clamp(dt * 0.35, 0, 1);
    this.weather.cloud += (target.cloud - this.weather.cloud) * k;
    this.weather.fog += (target.fog - this.weather.fog) * k;
    if (dt === 0) {
      this.weather.cloud = target.cloud;
      this.weather.fog = target.fog;
    }

    // Tabla del cielo: se recalcula (por filas, repartida en fotogramas) cuando el Sol se ha movido un poco.
    const sun = sunDirection(hours);
    const key = `${Math.round(Math.atan2(sun[0], sun[2]) * 57.3)}|${Math.round(Math.asin(sun[1]) * 57.3 * 2)}`;
    if (this.lut.done && key !== this.sunKey) {
      this.sunKey = key;
      this.lut.begin(sun);
    }
    if (this.lut.step(6)) this.lutTex.needsUpdate = true;

    const sunAz = Math.atan2(sun[0], sun[2]);
    const state = atmosphereState(hours, this.weather, this.lut, sunAz + Math.PI / 2);
    this.state = state;

    // Exposición: se adapta con suavidad (el ojo tarda en acostumbrarse).
    const ke = dt === 0 ? 1 : clamp(dt * 1.6, 0, 1);
    this.exposure *= Math.pow(state.exposure / this.exposure, ke);
    state.exposure = this.exposure;
    this.renderer.toneMappingExposure = this.exposure;

    const vals = sceneValues(state, { time: this.time, viewDistance: viewDistance(this.q), weather: this.weather, grassFar: this.q.grassRange * 0.78, fx: [this.q.cloudShadow ? 1 : 0, this.q.detail ? 1 : 0] });
    writeUniforms(this.U, vals);
    this.U.uPlayer.value.set(playerPos[0], playerPos[1], playerPos[2]);

    const L = lightValues(state);
    this.sun.color.setRGB(L.sunColor[0], L.sunColor[1], L.sunColor[2]);
    this.moon.color.setRGB(L.moonColor[0], L.moonColor[1], L.moonColor[2]);
    this.hemi.color.setRGB(L.skyColor[0], L.skyColor[1], L.skyColor[2]);
    this.hemi.groundColor.setRGB(L.groundColor[0], L.groundColor[1], L.groundColor[2]);

    const cx = playerPos[0], cy = playerPos[1], cz = playerPos[2];
    // Sombras: la caja de sombra sigue al jugador y se ajusta a la cuadrícula del mapa para que no «tiemble».
    const sd = L.sunDir;
    const S = this.q.shadowSpan;
    const size = this.q.shadow || 512;
    const texel = (2 * S) / size;
    const f = [-sd[0], -sd[1], -sd[2]];
    let rx = f[1] * 0 - f[2] * 1, ry = f[2] * 0 - f[0] * 0, rz = f[0] * 1 - f[1] * 0; // f × (0,1,0)
    let rl = Math.hypot(rx, ry, rz) || 1;
    rx /= rl; ry /= rl; rz /= rl;
    const ux = ry * f[2] - rz * f[1], uy = rz * f[0] - rx * f[2], uz = rx * f[1] - ry * f[0];
    const pr = cx * rx + cy * ry + cz * rz, pu = cx * ux + cy * uy + cz * uz;
    const sr = pr - Math.floor(pr / texel) * texel, su = pu - Math.floor(pu / texel) * texel;
    const tx = cx - rx * sr - ux * su, ty = cy - ry * sr - uy * su, tz = cz - rz * sr - uz * su;
    this.sun.target.position.set(tx, ty, tz);
    this.sun.position.set(tx + sd[0] * 150, ty + sd[1] * 150, tz + sd[2] * 150);
    this.sun.target.updateMatrixWorld();
    if ('intensity' in this.sun.shadow) this.sun.shadow.intensity = L.sunShadow;
    this.renderer.shadowMap.autoUpdate = L.sunShadow > 0.01;
    this.moon.position.set(cx + L.moonDir[0] * 100, cy + L.moonDir[1] * 100, cz + L.moonDir[2] * 100);
    this.moon.target.position.set(cx, cy, cz);
    this.moon.target.updateMatrixWorld();

    if (this.sky && camera) this.sky.position.set(camera.x, camera.y, camera.z);
    if (this.simple) {
      const toned = acesTone(state.fogColor, this.exposure);
      this.scene.background.setRGB(toned[0], toned[1], toned[2]);
      this.scene.fog.color.setRGB(toned[0], toned[1], toned[2]);
      this.scene.fog.density = state.fogDensity;
    }
    return state;
  }

  // Posición del Sol en pantalla y cuánto resplandor hay que mostrar (la tapa el terreno, o el Sol queda fuera de vista).
  computeGlare() {
    const st = this.state;
    const g = this.glare;
    g.alpha = 0;
    g.visible = false;
    if (!st || st.sun[1] < -0.02) return g;
    const cam = this.camera;
    cam.updateMatrixWorld();
    const T = this.THREE;
    const v = new T.Vector3(cam.position.x + st.sun[0] * 1000, cam.position.y + st.sun[1] * 1000, cam.position.z + st.sun[2] * 1000);
    v.project(cam);
    if (!(v.z < 1)) return g; // detrás de la cámara
    g.x = (v.x * 0.5 + 0.5);
    g.y = (-v.y * 0.5 + 0.5);
    const inView = smooth(1.35, 0.9, Math.max(Math.abs(v.x), Math.abs(v.y)));
    if (inView <= 0) return g;
    // Oclusión por el terreno: se camina un rayo hacia el Sol.
    let blocked = 0;
    const px = cam.position.x, py = cam.position.y, pz = cam.position.z;
    for (const d of [5, 12, 26, 55, 110, 220, 420, 800]) {
      const gy = heightAt(px + st.sun[0] * d, pz + st.sun[2] * d);
      const ray = py + st.sun[1] * d;
      if (gy > ray) blocked = Math.max(blocked, smooth(0, 6 + d * 0.04, gy - ray));
    }
    const m = Math.max(...st.sunTransmittance) * st.directK;
    const hazeK = 1 - 0.7 * smooth(1.5, 4, this.weather.fog);
    g.alpha = (1 - blocked) * inView * smooth(0.0, 0.05, m) * hazeK * (1 - 0.65 * this.weather.cloud) * smooth(-0.02, 0.03, st.sun[1]);
    g.visible = g.alpha > 0.01;
    g.warm = st.sunTransmittance;
    return g;
  }

  render() {
    if (this.disposed) return;
    if (this.post?.active) {
      const g = this.glare;
      this.post.render(this.scene, this.camera, { sun: { x: g.x, y: 1 - g.y, visible: g.visible, alpha: g.alpha }, time: this.time });
      return;
    }
    this.renderer.render(this.scene, this.camera);
  }

  get info() {
    const i = this.renderer.info;
    return { calls: i.render?.calls || 0, triangles: i.render?.triangles || 0, geometries: i.memory?.geometries || 0, textures: i.memory?.textures || 0, programs: i.programs?.length || 0 };
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    for (const entry of [...this.chunkEntries]) entry.dispose();
    this.tuft.dispose();
    this.sky?.geometry.dispose();
    for (const m of Object.values(this.mats)) m?.dispose?.();
    for (const t of this.textures) t.dispose();
    this.sun.shadow.map?.dispose();
    this.post?.dispose();
    releaseRenderer(this.renderer);
  }
}
