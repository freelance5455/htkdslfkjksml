// Prepara el personaje del usuario para el mundo: vista previa del modelo → esqueleto (el guardado o uno nuevo) → pesos de
// skinning → malla con huesos → animador. Es el mismo camino que el estudio de personaje (layers/rigStudio.js), pero sin
// visor: el resultado se coloca directamente en la escena del mundo, escalado a 1,75 m de altura.
import { loadThree } from '../core/threeLoader.js';
import { loadPreviewFor } from '../import/importer.js';
import { fitRigInBackground, skinInBackground } from '../rig/client.js';
import { isRigCompatible, orientMeshes } from '../rig/service.js';
import { buildRiggedPreview } from '../rig/skinned.js';
import { createAnimator } from '../rig/animator.js';
import { HEIGHT_M } from './physics.js';
import { applySavedLook } from '../ui/look.js';

// Reparto del progreso total entre las etapas (suman 1).
const STAGES = { engine: 0.04, analyze: 0.3, fit: 0.1, skin: 0.4, build: 0.16 };
const ORDER = Object.keys(STAGES);
const startOf = (name) => ORDER.slice(0, ORDER.indexOf(name)).reduce((s, k) => s + STAGES[k], 0);

// store, model: del hub. onStatus(texto, progreso 0..1). Devuelve { group, scale, rig, record, quality, animator, applyPose, dispose, fresh }.
//  · group: grupo de Three.js ya escalado, con los pies en y = 0 y mirando a +Z.
//  · scale: metros del mundo por unidad del esqueleto (la velocidad real del ciclo se multiplica por esto).
export async function prepareAvatar({ store, model, profile, signal, onStatus = () => {}, onModel = null, texLimit = 0 }) {
  const report = (stage, text, p = 0) => onStatus(text, startOf(stage) + STAGES[stage] * Math.min(1, Math.max(0, p)));
  const check = () => {
    if (signal?.aborted) throw Object.assign(new Error('Cancelado'), { name: 'AbortError' });
  };

  report('engine', 'Cargando el motor 3D…');
  const THREE = await loadThree();
  check();

  report('analyze', 'Analizando el modelo…');
  const { preview } = await loadPreviewFor(store, model, { signal, onProgress: (p) => report('analyze', 'Analizando el modelo…', p) });
  check();

  // Esqueleto: el guardado si sirve; si no, uno nuevo (que se guarda al terminar, como en el estudio).
  const saved = await store.getRig(model.id).catch(() => null);
  let record;
  let fresh = false;
  if (isRigCompatible(saved)) record = saved;
  else {
    report('fit', 'Detectando el esqueleto…');
    record = await fitRigInBackground(preview.meshes, { yawOffset: 0 }, { signal, onProgress: (p) => report('fit', 'Detectando el esqueleto…', p) });
    fresh = true;
    check();
  }

  const meshes = orientMeshes(preview.meshes, record.rig);
  report('skin', 'Calculando los pesos de la malla…');
  const { weights, quality } = await skinInBackground(meshes, record.rig, { signal, onProgress: (p) => report('skin', 'Calculando los pesos de la malla…', p) });
  check();

  report('build', 'Preparando el personaje…');
  const built = await buildRiggedPreview(THREE, { ...preview, meshes }, record.rig, weights, { texMax: texLimit || (profile?.tier === 'low' ? 1024 : 2048) });
  if (signal?.aborted) {
    built.dispose();
    check();
  }
  // Apariencia elegida en el visor B (textura, rugosidad, opacidad): si falla, el personaje queda como es.
  const lookHandle = await applySavedLook(THREE, store, model.id, built.group, { maxSize: texLimit || (profile?.tier === 'low' ? 1024 : 2048) }).catch((err) => {
    console.warn('[mundo] no se pudo aplicar la apariencia guardada', err);
    return null;
  });
  const scale = HEIGHT_M / Math.max(record.rig.height, 1e-6);
  built.group.scale.setScalar(scale);
  const animator = createAnimator(record.rig);
  built.applyPose(animator.update(0).pose);

  if (fresh) {
    // Guardar el esqueleto nuevo no es imprescindible para jugar: si falla, solo se avisa en consola.
    store
      .saveRig(model.id, { ...record, clips: [], quality: { level: quality.level, severePct: quality.severePct } })
      .then(() => store.updateModel(model.id, { rig: { poseType: record.poseType, confidence: record.confidence, level: quality.level, createdAt: record.createdAt } }, { touch: false }))
      .then((m) => onModel?.(m))
      .catch((err) => console.warn('[mundo] no se pudo guardar el esqueleto', err));
  }

  return {
    group: built.group,
    scale,
    rig: record.rig,
    record,
    quality,
    animator,
    fresh,
    // Velocidades del ciclo en metros del mundo por segundo.
    speeds() {
      const s = animator.speeds;
      return { min: s.min * scale, walk: s.walk * scale, trot: s.trot * scale, run: s.run * scale, sprint: s.sprint * scale };
    },
    applyPose: (pose) => built.applyPose(pose),
    dispose: () => {
      built.dispose();
      lookHandle?.dispose();
    },
  };
}
