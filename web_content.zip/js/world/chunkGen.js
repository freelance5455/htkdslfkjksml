// Generación completa de un trozo del mundo: terreno, agua, objetos fusionados, hierba y colisiones.
// Es una función pura (solo arrays tipados): se ejecuta en un Worker o, si no hay, en el hilo principal.
import { buildTerrainChunk, SEA, CHUNK } from './terrain.js';
import { scatterChunk, grassChunk } from './scatter.js';
import { buildTemplates } from './geometry.js';
import { hash01 } from './noise.js';

let templates = null;
const getTemplates = () => (templates ||= buildTemplates());

// Agua: solo las celdas que tocan zonas bajo el nivel del mar. aDepth = profundidad del fondo bajo la superficie.
function buildWater(t) {
  const { n, cell, side, heights } = t;
  if (t.minY >= SEA + 0.02) return null;
  const depth = new Float32Array(side * side);
  let wet = false;
  for (let v = 0; v < side * side; v++) {
    depth[v] = SEA - heights[v];
    if (depth[v] > -0.02) wet = true;
  }
  if (!wet) return null;
  const idx = [];
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const a = j * side + i, b = a + 1, c = a + side, d = c + 1;
      // Solo celdas con algo de agua (con un margen para que la orilla degrade suave).
      if (Math.max(depth[a], depth[b], depth[c], depth[d]) < -0.5) continue;
      idx.push(a, c, b, b, c, d);
    }
  }
  if (!idx.length) return null;
  const positions = new Float32Array(side * side * 3);
  for (let j = 0; j < side; j++) {
    for (let i = 0; i < side; i++) {
      const v = j * side + i;
      positions[v * 3] = i * cell;
      positions[v * 3 + 1] = SEA;
      positions[v * 3 + 2] = j * cell;
    }
  }
  return { positions, depth, indices: side * side > 65535 ? new Uint32Array(idx) : new Uint16Array(idx) };
}

// Fusiona los objetos en una sola malla (un solo dibujo por trozo y recorte por trozo en la pasada de sombras).
function mergeProps(objects, lodKey, cx, cz) {
  const T = getTemplates();
  const x0 = cx * CHUNK, z0 = cz * CHUNK;
  let vTotal = 0, iTotal = 0;
  const picks = objects.map((o) => {
    const list = T[o.kind];
    const entry = list[Math.min(list.length - 1, Math.floor(o.variant * list.length))];
    const tpl = entry[lodKey] || entry.full; // «cards» no existe para coníferas ni rocas: usan la completa
    vTotal += tpl.positions.length / 3;
    iTotal += tpl.indices.length;
    return tpl;
  });
  if (!vTotal) return null;
  const positions = new Float32Array(vTotal * 3), normals = new Float32Array(vTotal * 3), colors = new Float32Array(vTotal * 3), wind = new Float32Array(vTotal * 2), uvs = new Float32Array(vTotal * 2);
  const indices = vTotal > 65535 ? new Uint32Array(iTotal) : new Uint16Array(iTotal);
  let vo = 0, io = 0;
  objects.forEach((o, k) => {
    const tpl = picks[k];
    const nv = tpl.positions.length / 3;
    const cy = Math.cos(o.rot), sy = Math.sin(o.rot);
    const [tx, tz] = o.tilt;
    const ctx = Math.cos(tx), stx = Math.sin(tx), ctz = Math.cos(tz), stz = Math.sin(tz);
    // R = Ry · Rx · Rz aplicado a (p · s)
    const rot = (x, y, z) => {
      // Rz
      let ax = x * ctz - y * stz, ay = x * stz + y * ctz, az = z;
      // Rx
      const by = ay * ctx - az * stx, bz = ay * stx + az * ctx;
      ay = by;
      az = bz;
      // Ry
      return [ax * cy + az * sy, ay, -ax * sy + az * cy];
    };
    const tint = [0.92 + 0.16 * hash01(k, cx, 11), 0.92 + 0.16 * hash01(k, cz, 12), 0.92 + 0.16 * hash01(k, cx + cz, 13)];
    const phase = hash01(k, cx * 31 + cz, 14) * Math.PI * 2;
    for (let v = 0; v < nv; v++) {
      const p = rot(tpl.positions[v * 3] * o.s, tpl.positions[v * 3 + 1] * o.s, tpl.positions[v * 3 + 2] * o.s);
      const n = rot(tpl.normals[v * 3], tpl.normals[v * 3 + 1], tpl.normals[v * 3 + 2]);
      const w = (vo + v) * 3;
      positions[w] = p[0] + (o.x - x0);
      positions[w + 1] = p[1] + o.y;
      positions[w + 2] = p[2] + (o.z - z0);
      normals[w] = n[0];
      normals[w + 1] = n[1];
      normals[w + 2] = n[2];
      colors[w] = tpl.colors[v * 3] * tint[0];
      colors[w + 1] = tpl.colors[v * 3 + 1] * tint[1];
      colors[w + 2] = tpl.colors[v * 3 + 2] * tint[2];
      wind[(vo + v) * 2] = tpl.wind[v * 2];
      wind[(vo + v) * 2 + 1] = phase;
      uvs[(vo + v) * 2] = tpl.uvs[v * 2];
      uvs[(vo + v) * 2 + 1] = tpl.uvs[v * 2 + 1];
    }
    for (let i = 0; i < tpl.indices.length; i++) indices[io + i] = tpl.indices[i] + vo;
    vo += nv;
    io += tpl.indices.length;
  });
  return { positions, normals, colors, wind, uvs, indices };
}

// opts: { props: 0 (ninguno) | 1 (baja resolución) | 2 (completa) | 3 (completa con tarjetas de hojas), grassSpacing: 0 = sin hierba, density: 0..1 }
export function generateChunk(cx, cz, lod, opts = {}) {
  const { props = 0, grassSpacing = 0, density = 1 } = opts;
  const terrain = buildTerrainChunk(cx, cz, lod);
  const water = buildWater(terrain);
  let objects = null, propsGeo = null, colliders = new Float32Array(0), grass = null;
  if (props > 0 || grassSpacing > 0) {
    objects = scatterChunk(cx, cz, terrain, density);
    const all = [...objects.trees, ...objects.rocks, ...objects.bushes];
    if (props > 0 && all.length) propsGeo = mergeProps(all, props >= 3 ? 'cards' : props >= 2 ? 'full' : 'low', cx, cz);
    // Colisiones solo con árboles y rocas (el arbusto se atraviesa).
    const col = [...objects.trees, ...objects.rocks];
    colliders = new Float32Array(col.length * 3);
    col.forEach((o, i) => {
      colliders[i * 3] = o.x;
      colliders[i * 3 + 1] = o.z;
      colliders[i * 3 + 2] = o.r;
    });
    if (grassSpacing > 0) grass = grassChunk(cx, cz, terrain, objects.trees, grassSpacing);
  }
  const result = {
    cx, cz, lod,
    terrain: { positions: terrain.positions, normals: terrain.normals, splat: terrain.splat, tint: terrain.tint, indices: terrain.indices, minY: terrain.minY, maxY: terrain.maxY },
    water, props: propsGeo, grass: grass && grass.count ? grass : null, colliders,
  };
  return result;
}

// Buffers que se pueden ceder (transferir) al hilo principal sin copiarlos.
export function transferList(r) {
  const list = [];
  const add = (o) => o && Object.values(o).forEach((v) => ArrayBuffer.isView(v) && list.push(v.buffer));
  add(r.terrain);
  add(r.water);
  add(r.props);
  if (r.grass) list.push(r.grass.data.buffer);
  list.push(r.colliders.buffer);
  return [...new Set(list)];
}
