// Ruido determinista sin dependencias (el mismo resultado en el hilo principal y en el Worker, en cualquier
// dispositivo). Todo es función pura de las coordenadas y la semilla: así un trozo de mundo se puede volver a
// generar idéntico cuando el jugador regresa, sin guardar nada.

// Hash entero de dos coordenadas y una semilla → uint32.
export function hashInt(x, y, seed = 0) {
  let h = Math.imul(x | 0, 0x27d4eb2d) ^ Math.imul(y | 0, 0x165667b1) ^ Math.imul(seed | 0, 0x9e3779b1);
  h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  return (h ^ (h >>> 16)) >>> 0;
}
// Hash → [0, 1).
export const hash01 = (x, y, seed = 0) => hashInt(x, y, seed) / 4294967296;

// Generador pseudoaleatorio con semilla (mulberry32).
export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const S = Math.SQRT1_2;
const GX = [1, -1, 0, 0, S, -S, S, -S];
const GY = [0, 0, 1, -1, S, S, -S, -S];

// Ruido de gradiente 2D (tipo Perlin) en [-1, 1], continuo y suave (interpolación quíntica).
export function noise2(x, y, seed = 0) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * xf * (xf * (xf * 6 - 15) + 10);
  const v = yf * yf * yf * (yf * (yf * 6 - 15) + 10);
  const h00 = hashInt(xi, yi, seed) & 7, h10 = hashInt(xi + 1, yi, seed) & 7;
  const h01 = hashInt(xi, yi + 1, seed) & 7, h11 = hashInt(xi + 1, yi + 1, seed) & 7;
  const n00 = GX[h00] * xf + GY[h00] * yf;
  const n10 = GX[h10] * (xf - 1) + GY[h10] * yf;
  const n01 = GX[h01] * xf + GY[h01] * (yf - 1);
  const n11 = GX[h11] * (xf - 1) + GY[h11] * (yf - 1);
  const a = n00 + u * (n10 - n00);
  const b = n01 + u * (n11 - n01);
  return (a + v * (b - a)) * 1.4142;
}

// Movimiento browniano fraccional: suma de octavas, cada una girada para que no se noten los ejes de la rejilla.
export function fbm2(x, y, octaves = 4, seed = 0, lacunarity = 2.02, gain = 0.5) {
  let amp = 1, sum = 0, norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * noise2(x, y, seed + i * 31);
    norm += amp;
    amp *= gain;
    const nx = (x * 0.8 - y * 0.6) * lacunarity;
    y = (x * 0.6 + y * 0.8) * lacunarity + 11.7;
    x = nx + 5.3;
  }
  return sum / norm;
}

// Ruido «de crestas» en [0, 1]: aristas afiladas para montañas.
export function ridged2(x, y, octaves = 4, seed = 0) {
  let amp = 0.5, sum = 0, norm = 0, weight = 1;
  for (let i = 0; i < octaves; i++) {
    let n = 1 - Math.abs(noise2(x, y, seed + i * 17));
    n *= n * weight;
    weight = Math.min(1, Math.max(0, n * 1.6));
    sum += n * amp;
    norm += amp;
    amp *= 0.5;
    const nx = (x * 0.8 - y * 0.6) * 2.03;
    y = (x * 0.6 + y * 0.8) * 2.03 - 3.1;
    x = nx + 7.9;
  }
  return sum / norm;
}

export const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
export const smoothstep = (a, b, x) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
export const mix = (a, b, t) => a + (b - a) * t;
