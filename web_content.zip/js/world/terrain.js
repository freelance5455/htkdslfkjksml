// Terreno procedural infinito. La altura es una función pura h(x, z) en metros (nivel del mar = 0), así que:
//  · el jugador, los árboles y el agua consultan el mismo terreno que se dibuja;
//  · un trozo de mundo se genera en un Worker y se puede regenerar idéntico cuando se vuelve a él.
// El mundo se divide en trozos cuadrados de CHUNK metros; cada uno se malla con 4 niveles de detalle (LOD).
import { fbm2, ridged2, smoothstep, mix, clamp01, hash01 } from './noise.js';

export const SEA = 0; // nivel del agua (m)
export const CHUNK = 64; // lado de un trozo (m)
export const LOD_CELLS = [64, 32, 16, 8]; // celdas por lado en cada LOD (1 m, 2 m, 4 m, 8 m)
export const SPAWN = [0, 0]; // punto de aparición: prado llano
const SEED = 1337;

// Altura del terreno (m). Praderas onduladas + montañas en cresta + lagos en las depresiones; llano junto al origen.
export function heightAt(x, z) {
  const continent = fbm2(x * 0.0012, z * 0.0012, 3, SEED + 1);
  const hills = fbm2(x * 0.0052, z * 0.0052, 5, SEED + 2);
  const rolling = fbm2(x * 0.0021, z * 0.0021, 3, SEED + 6);
  const bumps = fbm2(x * 0.034, z * 0.034, 3, SEED + 3);
  const mountains = ridged2(x * 0.0019, z * 0.0019, 5, SEED + 4);
  const mountMask = smoothstep(-0.02, 0.32, continent);
  let h = 8 + hills * 11 + rolling * 14 + continent * 8 + bumps * 0.8;
  h += mountMask * mountMask * mountains * 150;

  // Lagos: depresiones amplias y suaves, solo donde no hay montaña.
  const lakeNoise = fbm2(x * 0.0015 + 17.3, z * 0.0015 - 9.1, 3, SEED + 5);
  let lake = smoothstep(0.2, 0.5, lakeNoise) * (1 - mountMask);
  lake = lake * lake * (3 - 2 * lake);
  h = mix(h, -5.5 + hills * 1.5, lake);

  // Prado llano alrededor del punto de aparición.
  const r = Math.hypot(x - SPAWN[0], z - SPAWN[1]);
  const open = smoothstep(26, 130, r);
  return mix(3.4 + bumps * 0.25, h, open);
}

// Normal (unitaria) por diferencias centrales de la función de altura.
export function normalAt(x, z, eps = 0.6, out = [0, 1, 0]) {
  const dx = heightAt(x - eps, z) - heightAt(x + eps, z);
  const dz = heightAt(x, z - eps) - heightAt(x, z + eps);
  const inv = 1 / Math.hypot(dx, 2 * eps, dz);
  out[0] = dx * inv;
  out[1] = 2 * eps * inv;
  out[2] = dz * inv;
  return out;
}

// Composición del suelo en un punto: pesos de hierba, roca, arena y nieve (suman 1) + exuberancia, humedad.
// h: altura; ny: componente vertical de la normal (1 = llano).
export function surfaceAt(x, z, h, ny, out = { grass: 1, rock: 0, sand: 0, snow: 0, lush: 0.5, wet: 0 }) {
  const slope = 1 - ny;
  const n1 = fbm2(x * 0.045, z * 0.045, 2, SEED + 21);
  const n2 = fbm2(x * 0.0035, z * 0.0035, 2, SEED + 22);
  const rock = smoothstep(0.2, 0.42, slope + n1 * 0.05) * 1 + smoothstep(70, 110, h + n1 * 14) * 0.45;
  let rockW = clamp01(rock);
  const sandW = (1 - smoothstep(0.5, 2.1, h + n1 * 0.7)) * (1 - rockW * 0.8);
  const snowW = smoothstep(84, 104, h + n1 * 9) * (1 - 0.75 * smoothstep(0.3, 0.55, slope));
  let grassW = Math.max(0, 1 - rockW - sandW - snowW);
  const sum = grassW + rockW + sandW + snowW || 1;
  out.grass = grassW / sum;
  out.rock = rockW / sum;
  out.sand = sandW / sum;
  out.snow = snowW / sum;
  out.lush = clamp01(0.55 + n2 * 0.7 - smoothstep(40, 90, h) * 0.5);
  out.wet = clamp01(1 - smoothstep(0, 1.6, h - SEA));
  return out;
}

// Malla de un trozo: rejilla de (n+1)² vértices + una «falda» vertical en los cuatro bordes que tapa las
// grietas entre niveles de detalle distintos. Posiciones relativas a la esquina del trozo (mejor precisión en float32).
// Devuelve arrays tipados listos para BufferGeometry y la rejilla de alturas (la reutilizan el agua y los objetos).
export function buildTerrainChunk(cx, cz, lod = 0) {
  const n = LOD_CELLS[lod];
  const cell = CHUNK / n;
  const x0 = cx * CHUNK, z0 = cz * CHUNK;
  const side = n + 1;
  // Alturas con un margen de una celda a cada lado para sacar normales continuas entre trozos vecinos.
  const m = n + 3;
  const H = new Float32Array(m * m);
  for (let j = 0; j < m; j++) for (let i = 0; i < m; i++) H[j * m + i] = heightAt(x0 + (i - 1) * cell, z0 + (j - 1) * cell);
  const hAt = (i, j) => H[(j + 1) * m + (i + 1)];

  const skirtN = 4 * side;
  const vCount = side * side + skirtN;
  const positions = new Float32Array(vCount * 3);
  const normals = new Float32Array(vCount * 3);
  const splat = new Float32Array(vCount * 4);
  const tint = new Float32Array(vCount * 3);
  const heights = new Float32Array(side * side);
  const surf = { grass: 1, rock: 0, sand: 0, snow: 0, lush: 0.5, wet: 0 };
  let minY = Infinity, maxY = -Infinity;
  const skirt = 1.2 + cell * 0.7;

  for (let j = 0; j < side; j++) {
    for (let i = 0; i < side; i++) {
      const v = j * side + i;
      const y = hAt(i, j);
      heights[v] = y;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
      positions[v * 3] = i * cell;
      positions[v * 3 + 1] = y;
      positions[v * 3 + 2] = j * cell;
      // Pendiente por diferencias centrales de la rejilla (2 celdas de separación).
      const dx = hAt(i - 1, j) - hAt(i + 1, j);
      const dz = hAt(i, j - 1) - hAt(i, j + 1);
      const inv = 1 / Math.hypot(dx, 2 * cell, dz);
      const nx = dx * inv, ny = 2 * cell * inv, nz = dz * inv;
      normals[v * 3] = nx;
      normals[v * 3 + 1] = ny;
      normals[v * 3 + 2] = nz;
      const wx = x0 + i * cell, wz = z0 + j * cell;
      surfaceAt(wx, wz, y, ny, surf);
      splat[v * 4] = surf.grass;
      splat[v * 4 + 1] = surf.rock;
      splat[v * 4 + 2] = surf.sand;
      splat[v * 4 + 3] = surf.snow;
      // Oclusión ambiental barata: una celda más baja que sus vecinas (cuenca, orilla) se oscurece un poco.
      const avg = (hAt(i - 1, j) + hAt(i + 1, j) + hAt(i, j - 1) + hAt(i, j + 1)) * 0.25;
      const ao = clamp01(1 - Math.max(0, avg - y) * (0.9 / Math.max(cell, 1)) - 0.08 * (1 - ny) * 4);
      tint[v * 3] = surf.lush;
      tint[v * 3 + 1] = Math.max(0.55, ao);
      tint[v * 3 + 2] = surf.wet;
    }
  }

  // Falda: copia de los vértices del borde bajada `skirt` metros.
  const edges = [
    (k) => k, // z = 0 (sur)
    (k) => (side - 1) * side + k, // z = máx
    (k) => k * side, // x = 0
    (k) => k * side + (side - 1), // x = máx
  ];
  const skirtBase = side * side;
  edges.forEach((pick, e) => {
    for (let k = 0; k < side; k++) {
      const src = pick(k), dst = skirtBase + e * side + k;
      positions[dst * 3] = positions[src * 3];
      positions[dst * 3 + 1] = positions[src * 3 + 1] - skirt;
      positions[dst * 3 + 2] = positions[src * 3 + 2];
      normals.copyWithin(dst * 3, src * 3, src * 3 + 3);
      splat.copyWithin(dst * 4, src * 4, src * 4 + 4);
      tint.copyWithin(dst * 3, src * 3, src * 3 + 3);
    }
  });

  const quads = n * n;
  const triCount = quads * 2 + 4 * n * 2;
  const U32 = vCount > 65535;
  const indices = U32 ? new Uint32Array(triCount * 3) : new Uint16Array(triCount * 3);
  let t = 0;
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const a = j * side + i, b = a + 1, c = a + side, d = c + 1;
      // Dos triángulos por celda, con la diagonal alternada para que no se note una dirección privilegiada.
      if ((i + j) & 1) {
        indices[t++] = a; indices[t++] = c; indices[t++] = d;
        indices[t++] = a; indices[t++] = d; indices[t++] = b;
      } else {
        indices[t++] = a; indices[t++] = c; indices[t++] = b;
        indices[t++] = b; indices[t++] = c; indices[t++] = d;
      }
    }
  }
  // Faldas: la cara mira hacia fuera del trozo.
  const outward = [[0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]];
  edges.forEach((pick, e) => {
    for (let k = 0; k < n; k++) {
      const a = pick(k), b = pick(k + 1), a2 = skirtBase + e * side + k, b2 = skirtBase + e * side + k + 1;
      for (const tri of [[a, b, a2], [b, b2, a2]]) {
        const p = (v) => [positions[v * 3], positions[v * 3 + 1], positions[v * 3 + 2]];
        const P0 = p(tri[0]), P1 = p(tri[1]), P2 = p(tri[2]);
        const e1 = [P1[0] - P0[0], P1[1] - P0[1], P1[2] - P0[2]], e2 = [P2[0] - P0[0], P2[1] - P0[1], P2[2] - P0[2]];
        const nx = e1[1] * e2[2] - e1[2] * e2[1], ny = e1[2] * e2[0] - e1[0] * e2[2], nz = e1[0] * e2[1] - e1[1] * e2[0];
        const o = outward[e];
        const flip = nx * o[0] + ny * o[1] + nz * o[2] < 0;
        indices[t++] = tri[0];
        indices[t++] = flip ? tri[2] : tri[1];
        indices[t++] = flip ? tri[1] : tri[2];
      }
    }
  });

  return { cx, cz, lod, n, cell, origin: [x0, 0, z0], positions, normals, splat, tint, indices, heights, side, minY, maxY: Math.max(maxY, minY + 0.01) };
}

// Altura y pendiente del terreno bajo (x, z): atajo para el jugador y la cámara.
export function groundAt(x, z, out = { h: 0, nx: 0, ny: 1, nz: 0 }) {
  out.h = heightAt(x, z);
  const n = normalAt(x, z, 0.5, [0, 1, 0]);
  out.nx = n[0];
  out.ny = n[1];
  out.nz = n[2];
  return out;
}

export const chunkOf = (v) => Math.floor(v / CHUNK);
// Ruido por celda para decisiones sueltas (p. ej. variante de un objeto).
export const cellNoise = (x, z, seed) => hash01(Math.floor(x), Math.floor(z), seed);
