/* ===================================================================
 * VFL.State — نسخه ۲
 * علاوه بر ساختار نسخه ۱ (فصل/هفته/تیم‌ها/لیگ‌ها)، این نسخه شامل:
 *   - دیتابیس قابل‌ویرایش بازیکنان + نقل‌وانتقال آزاد
 *   - شبیه‌سازی مسابقه با موتور VFL.Engine.Match
 *   - جام حذفی (برای لیگ برتر انگلیس) و سوپر جام
 *   - فرم اخیر تیم‌ها و آمار فصلی بازیکنان
 * =================================================================== */
(function (VFL) {
  "use strict";

  var state = null;

  function createFreshState() {
    var s = {
      meta: {
        version: VFL.Config.version,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      season: {
        current: new Date().getFullYear(),
        week: 1
      },
      selectedTeamId: null,
      selectedLeagueId: null,
      uiActiveLeagueId: null, // لیگی که کاربر همین الان در حال مرور/شبیه‌سازی آن است (برای مسابقات و آمار)
      teams: VFL.Utils.clone(VFL.Data.Teams),
      players: VFL.Utils.clone(VFL.Data.Players),
      teamLeagueOverride: {}, // teamId -> leagueId، فقط برای تیم‌هایی که با صعود/سقوط لیگ عوض کرده‌اند
      seasonHistory: [],      // آرشیو جدول نهایی هر فصل، برای مراجعه بعدی
      pendingTransition: null, // صعود/سقوط در حال انجام بین دو فصل (پلی‌آف و غیره)
      form: {},        // teamId -> ["W","D","L", ...] (حداکثر ۵ آخرین نتیجه)
      competitions: {
        league: { enabled: VFL.Config.competitions.league.enabled },
        cup: { enabled: true, label: "جام حذفی" },
        superCup: { enabled: true, label: "سوپر جام" },
        championsLeague: VFL.Competitions.buildPlaceholderCompetition(
          "championsLeague",
          "لیگ قهرمانان اروپا — منتظر دیتابیس بازیکنان سایر لیگ‌ها"
        )
      },
      standings: {},
      fixtures: {},
      leagueWeekOffset: {}, // leagueId -> عددی که از هفته مطلق فیکسچر کم می‌شود تا «هفته نمایشی» همیشه از ۱ شروع شود
      leagueArchivedPending: {}, // leagueId -> true یعنی جدول این فصل آرشیو شده اما هنوز منتظر ریست (مثلاً منتظر لیگ جفتش) است
      matchReports: {},   // fixtureId / matchId -> گزارش کامل موتور شبیه‌سازی
      cup: null,
      superCup: { homeTeamId: null, awayTeamId: null, played: false, matchId: null },
      championsLeague: null,
      transferHistory: [],
      seasonAwardsHistory: [],
      customLineups: {}   // teamId -> { starters: [playerId...], bench: [playerId...] } — چیده‌شده توسط کاربر
    };

    VFL.Data.Leagues.filter(function (l) { return l.full; }).forEach(function (league) {
      setupLeagueSeason(s, league.id);
    });

    // جام حذفی فعلاً فقط برای لیگی که دیتابیس بازیکن کامل دارد (لیگ برتر انگلیس) ساخته می‌شود
    var cupLeague = VFL.Data.Leagues.filter(function (l) { return l.full; }).find(function (l) {
      return VFL.Data.getTeamsByLeague(l.id).some(function (tm) { return VFL.Data.teamHasSquad(tm.id); });
    });
    if (cupLeague) {
      var cupTeamIds = VFL.Data.getTeamsByLeague(cupLeague.id).map(function (tm) { return tm.id; });
      s.cup = { leagueId: cupLeague.id, bracket: VFL.Competitions.createBracket(cupTeamIds) };
    }

    // لیگ قهرمانان اروپا — با قدرت تیم‌ها (Overall)، حتی بدون دیتابیس بازیکن کامل
    var clTeams = VFL.Competitions.selectChampionsLeagueTeams();
    s.championsLeague = {
      teams: clTeams,
      phase: "league",
      leagueMatches: VFL.Competitions.buildLeaguePhase(clTeams),
      leagueStandings: clTeams.map(VFL.Utils.emptyStandingRow),
      leagueRanking: null,
      playoffTies: null,
      r16Ties: null,
      qfTies: null,
      sfTies: null,
      finalMatch: null,
      championTeamId: null
    };

    return s;
  }

  // ---------------------------------------------------------------
  // کمکی‌های داخلی
  // ---------------------------------------------------------------
  // بازی‌های ذخیره‌شده قدیمی‌تر ممکن است فیلدهای جدید را نداشته باشند — این تابع بدون
  // پاک کردن هیچ داده‌ای، فقط فیلدهای غایب را با مقدار خالی مناسب پر می‌کند
  function migrateState(s) {
    if (!s.customLineups) s.customLineups = {};
    if (!s.leagueWeekOffset) s.leagueWeekOffset = {};
    if (!s.seasonAwardsHistory) s.seasonAwardsHistory = [];
    if (!s.seasonHistory) s.seasonHistory = [];
    if (!s.transferHistory) s.transferHistory = [];
    if (!s.teamLeagueOverride) s.teamLeagueOverride = {};
    if (s.uiActiveLeagueId === undefined) s.uiActiveLeagueId = null;
    if (!s.pendingTransition) s.pendingTransition = null;
  }

  function findFixture(fixtureId) {
    var found = null, leagueId = null;
    Object.keys(state.fixtures).some(function (lid) {
      var fx = state.fixtures[lid].find(function (f) { return f.id === fixtureId; });
      if (fx) { found = fx; leagueId = lid; return true; }
      return false;
    });
    return { fixture: found, leagueId: leagueId };
  }

  // لیگ فعلی یک تیم — با احتساب صعود/سقوطی که ممکن است رخ داده باشد
  function getTeamLeague(teamId) {
    var override = state.teamLeagueOverride && state.teamLeagueOverride[teamId];
    return override || VFL.Data.getTeamById(teamId).league;
  }

  // همه تیم‌هایی که الان (با احتساب صعود/سقوط) عضو یک لیگ هستند
  function getTeamsForLeagueFromState(s, leagueId) {
    var staticTeams = VFL.Data.getTeamsByLeague(leagueId).map(function (t) { return t.id; });
    var overrides = s.teamLeagueOverride || {};
    var overrideOut = staticTeams.filter(function (id) { return overrides[id] && overrides[id] !== leagueId; });
    var overrideIn = Object.keys(overrides).filter(function (id) { return overrides[id] === leagueId && staticTeams.indexOf(id) === -1; });
    return staticTeams.filter(function (id) { return overrideOut.indexOf(id) === -1; }).concat(overrideIn);
  }

  // جدول و برنامه مسابقات یک لیگ را (بر اساس عضویت فعلی تیم‌ها) می‌سازد — هم برای بازی جدید، هم برای شروع فصل بعد
  function setupLeagueSeason(s, leagueId) {
    var teamIds = getTeamsForLeagueFromState(s, leagueId);
    s.standings[leagueId] = teamIds.map(VFL.Utils.emptyStandingRow);
    var fixtures = VFL.Competitions.buildLeagueFixtures(leagueId, teamIds);
    // هفته‌های فیکسچر جدید باید از هفته تقویمی فعلی شروع شوند، نه همیشه از ۱ —
    // وگرنه وقتی یک لیگ فصلش را زودتر از بقیه تمام و از نو شروع می‌کند، ساعت
    // تقویمی سراسری دیگر هرگز به بازی‌های این لیگ نمی‌رسد (چون هفته‌های ۱..N
    // قبلاً رد شده‌اند) و آن لیگ برای همیشه معلق می‌ماند.
    var weekOffset = s.season.week - 1;
    if (weekOffset > 0) {
      fixtures.forEach(function (fx) { fx.week += weekOffset; });
    }
    s.leagueWeekOffset[leagueId] = weekOffset;
    s.fixtures[leagueId] = fixtures;
    teamIds.forEach(function (id) { s.form[id] = []; });
  }

  // جوایز و آمار پایانی یک فصل را از داده‌های واقعیِ همان فصل استخراج می‌کند —
  // هیچ‌کدام تصادفی نیست: بر اساس گل، پاس‌گل، میانگین امتیاز و برترین بازیکن مسابقه واقعی.
  function computeCompositeScore(p) {
    var st = p.seasonStats;
    return (st.avgRating || 6) * 10 + st.goals * 3 + st.assists * 2 + st.motmCount * 4;
  }

  function computeLeagueSeasonAwards(leagueId) {
    var teamIds = getTeamsForLeagueFromState(state, leagueId);
    var players = state.players.filter(function (p) { return teamIds.indexOf(p.teamId) !== -1 && p.seasonStats.matches > 0; });

    function topBy(list, fn) {
      var sorted = list.slice().sort(function (a, b) { return fn(b) - fn(a); });
      return sorted.length ? sorted[0] : null;
    }

    var topScorer = topBy(players, function (p) { return p.seasonStats.goals; });
    var topAssist = topBy(players, function (p) { return p.seasonStats.assists; });
    var bestGK = topBy(players.filter(function (p) { return p.position === "GK"; }), function (p) { return p.seasonStats.avgRating || 0; });
    var bestPlayer = topBy(players, computeCompositeScore);
    var bestYoung = topBy(players.filter(function (p) { return p.age !== null && p.age !== undefined && p.age <= 21; }), computeCompositeScore);

    var standings = VFL.Utils.sortStandings(state.standings[leagueId] || []);
    var bestAttack = standings.length ? standings.slice().sort(function (a, b) { return b.goalsFor - a.goalsFor; })[0] : null;
    var bestDefense = standings.length ? standings.slice().sort(function (a, b) { return a.goalsAgainst - b.goalsAgainst; })[0] : null;
    var mostWins = standings.length ? standings.slice().sort(function (a, b) { return b.win - a.win; })[0] : null;
    var totalMatches = (state.fixtures[leagueId] || []).filter(function (fx) { return fx.played; }).length;
    var totalGoals = standings.reduce(function (s, r) { return s + r.goalsFor; }, 0);

    return {
      leagueId: leagueId,
      year: state.season.current,
      championTeamId: standings.length ? standings[0].teamId : null,
      topScorer: topScorer ? { playerId: topScorer.id, value: topScorer.seasonStats.goals } : null,
      topAssist: topAssist ? { playerId: topAssist.id, value: topAssist.seasonStats.assists } : null,
      bestGoalkeeper: bestGK ? { playerId: bestGK.id, value: bestGK.seasonStats.avgRating } : null,
      bestPlayer: bestPlayer ? { playerId: bestPlayer.id, value: Math.round(computeCompositeScore(bestPlayer) * 100) / 100 } : null,
      bestYoungPlayer: bestYoung ? { playerId: bestYoung.id } : null,
      bestAttackTeamId: bestAttack ? bestAttack.teamId : null,
      bestDefenseTeamId: bestDefense ? bestDefense.teamId : null,
      mostWinsTeamId: mostWins ? mostWins.teamId : null,
      totalMatches: totalMatches,
      totalGoals: totalGoals,
      avgGoalsPerMatch: totalMatches ? Math.round((totalGoals / totalMatches) * 100) / 100 : 0
    };
  }

  function resetSeasonStatsForLeague(leagueId) {
    var teamIds = getTeamsForLeagueFromState(state, leagueId);
    state.players.filter(function (p) { return teamIds.indexOf(p.teamId) !== -1; }).forEach(function (p) {
      p.seasonStats = {
        matches: 0, goals: 0, assists: 0, shots: 0, shotsOnTarget: 0, passAccuracy: null,
        chancesCreated: 0, dribbles: 0, tackles: 0, interceptions: 0, fouls: 0, yellowCards: 0,
        redCards: 0, minutesPlayed: 0, motmCount: 0, avgRating: null
      };
    });
  }

  // جدول و برنامه یک لیگ را می‌بندد: جوایز فصل را ثبت می‌کند، آمار فصلی بازیکنانش را صفر می‌کند، سپس فصل تازه می‌سازد
  function closeAndRestartLeague(leagueId) {
    state.seasonAwardsHistory.push(computeLeagueSeasonAwards(leagueId));
    resetSeasonStatsForLeague(leagueId);
    setupLeagueSeason(state, leagueId);
    state.leagueArchivedPending[leagueId] = false;
  }

  function pushForm(teamId, result) {
    if (!state.form[teamId]) state.form[teamId] = [];
    state.form[teamId].push(result);
    if (state.form[teamId].length > 5) state.form[teamId].shift();
  }

  function buildEngineTeamInput(teamId, isHome) {
    var team = VFL.Data.getTeamById(teamId);
    var squad = VFL.State.getSquad(teamId);
    var leagueId = getTeamLeague(teamId);
    var row = null;
    if (leagueId && state.standings[leagueId]) {
      row = state.standings[leagueId].find(function (r) { return r.teamId === teamId; });
    }
    var played = row ? row.played : 0;
    return {
      teamId: teamId,
      teamName: team.name,
      overall: team.overall,
      squad: squad.length ? squad : null,
      customLineup: state.customLineups ? state.customLineups[teamId] : null,
      form: state.form[teamId] || [],
      fatiguePre: Math.min(25, played * 0.7),
      isHome: isHome
    };
  }

  function applyReportToPlayers(report) {
    Object.keys(report.playerRatings).forEach(function (pid) {
      var player = VFL.State.getPlayer(pid);
      if (!player) return;
      player.seasonStats.matches += 1;
      player.seasonStats.minutesPlayed += 90;
      var rating = report.playerRatings[pid];
      var prevAvg = player.seasonStats.avgRating;
      var n = player.seasonStats.matches;
      player.seasonStats.avgRating = prevAvg === null ? rating : Math.round(((prevAvg * (n - 1) + rating) / n) * 100) / 100;
    });
    report.goalEvents.forEach(function (g) {
      if (g.info.ownGoal) return;
      if (g.info.scorerId) {
        var scorer = VFL.State.getPlayer(g.info.scorerId);
        if (scorer) scorer.seasonStats.goals += 1;
      }
      if (g.info.assistId) {
        var assister = VFL.State.getPlayer(g.info.assistId);
        if (assister) assister.seasonStats.assists += 1;
      }
    });
    report.yellowCards.forEach(function (yc) {
      if (!yc.playerId) return;
      var p = VFL.State.getPlayer(yc.playerId);
      if (p) p.seasonStats.yellowCards += 1;
    });
    report.injuries.forEach(function (inj) {
      var p = VFL.State.getPlayer(inj.playerId);
      if (p) {
        p.status.injured = true;
        p.status.injuryReturnWeek = state.season.week + 1 + Math.floor(Math.random() * 3);
      }
    });
    if (report.motm) {
      var motmPlayer = VFL.State.getPlayer(report.motm);
      if (motmPlayer) motmPlayer.seasonStats.motmCount += 1;
    }
  }

  function applyReportToStandings(leagueId, homeId, awayId, report) {
    if (!leagueId || !state.standings[leagueId]) return;
    var homeRow = state.standings[leagueId].find(function (r) { return r.teamId === homeId; });
    var awayRow = state.standings[leagueId].find(function (r) { return r.teamId === awayId; });
    if (!homeRow || !awayRow) return;

    [homeRow, awayRow].forEach(function (row) { row.played += 1; });
    homeRow.goalsFor += report.homeGoals; homeRow.goalsAgainst += report.awayGoals;
    awayRow.goalsFor += report.awayGoals; awayRow.goalsAgainst += report.homeGoals;

    if (report.homeGoals > report.awayGoals) {
      homeRow.win += 1; awayRow.loss += 1; pushForm(homeId, "W"); pushForm(awayId, "L");
    } else if (report.homeGoals < report.awayGoals) {
      awayRow.win += 1; homeRow.loss += 1; pushForm(awayId, "W"); pushForm(homeId, "L");
    } else {
      homeRow.draw += 1; awayRow.draw += 1; pushForm(homeId, "D"); pushForm(awayId, "D");
    }
  }

  function applyReportToRows(rows, homeId, awayId, report) {
    var homeRow = rows.find(function (r) { return r.teamId === homeId; });
    var awayRow = rows.find(function (r) { return r.teamId === awayId; });
    if (!homeRow || !awayRow) return;
    [homeRow, awayRow].forEach(function (row) { row.played += 1; });
    homeRow.goalsFor += report.homeGoals; homeRow.goalsAgainst += report.awayGoals;
    awayRow.goalsFor += report.awayGoals; awayRow.goalsAgainst += report.homeGoals;
    if (report.homeGoals > report.awayGoals) { homeRow.win += 1; awayRow.loss += 1; }
    else if (report.homeGoals < report.awayGoals) { awayRow.win += 1; homeRow.loss += 1; }
    else { homeRow.draw += 1; awayRow.draw += 1; }
  }

  function simulateGenericMatch(homeId, awayId) {
    var homeInput = buildEngineTeamInput(homeId, true);
    var awayInput = buildEngineTeamInput(awayId, false);
    return VFL.Engine.simulateMatch({ home: homeInput, away: awayInput });
  }

  // ---------------------------------------------------------------
  // API عمومی
  // ---------------------------------------------------------------
  VFL.State = {
    init: function () {
      var saved = VFL.Storage.load();
      state = saved || createFreshState();
      migrateState(state);
      return state;
    },

    newGame: function () {
      state = createFreshState();
      VFL.Storage.save(state);
      return state;
    },

    get: function () { return state; },

    hasSavedGame: function () { return VFL.Storage.hasSave(); },

    save: function () { return VFL.Storage.save(state); },

    selectTeam: function (teamId) {
      var team = VFL.Data.getTeamById(teamId);
      if (!team) return false;
      state.selectedTeamId = teamId;
      state.selectedLeagueId = team.league;
      if (team.league) state.uiActiveLeagueId = team.league;
      VFL.Storage.save(state);
      return true;
    },

    // لیگی که کاربر همین الان دارد مسابقاتش را دنبال/شبیه‌سازی می‌کند (مستقل از تیم تحت کنترل)
    getActiveLeague: function () {
      return state.uiActiveLeagueId || (state.selectedTeamId && VFL.Data.getTeamById(state.selectedTeamId).league) || "epl";
    },

    setActiveLeague: function (leagueId) {
      state.uiActiveLeagueId = leagueId;
      VFL.Storage.save(state);
    },

    toggleCompetition: function (key) {
      if (key === "league") return;
      if (state.competitions[key] && state.competitions[key].status !== undefined) {
        state.competitions[key].status = state.competitions[key].status === "disabled" ? "not_implemented" : "disabled";
      } else if (state.competitions[key]) {
        state.competitions[key].enabled = !state.competitions[key].enabled;
      }
      VFL.Storage.save(state);
    },

    // هفته نمایشی یک فیکسچر داخل لیگ خودش (همیشه از ۱ شروع می‌شود، حتی اگر لیگ قبلاً یک‌بار فصلش تمام و از نو شروع شده باشد)
    getDisplayWeek: function (leagueId, absoluteWeek) {
      return absoluteWeek - (state.leagueWeekOffset[leagueId] || 0);
    },

    getRemainingFixturesForTeam: function (teamId) {
      var league = VFL.Data.getTeamById(teamId).league;
      if (!league || !state.fixtures[league]) return [];
      return state.fixtures[league].filter(function (fx) {
        return !fx.played && (fx.home === teamId || fx.away === teamId);
      });
    },

    getResultsForTeam: function (teamId) {
      var league = VFL.Data.getTeamById(teamId).league;
      if (!league || !state.fixtures[league]) return [];
      return state.fixtures[league].filter(function (fx) {
        return fx.played && (fx.home === teamId || fx.away === teamId);
      });
    },

    // ---------------- بازیکنان ----------------
    getPlayer: function (playerId) {
      return state.players.find(function (p) { return p.id === playerId; }) || null;
    },

    getSquad: function (teamId) {
      return state.players.filter(function (p) { return p.teamId === teamId; });
    },

    // ---------------- ترکیب اصلی و نیمکت (اختیاری — اگر تنظیم نشود، موتور خودش ۱۱ برتر را انتخاب می‌کند) ----------------
    getLineup: function (teamId) {
      return (state.customLineups && state.customLineups[teamId]) || null;
    },

    setLineup: function (teamId, starterIds, benchIds) {
      var squadIds = VFL.State.getSquad(teamId).map(function (p) { return p.id; });
      var starters = starterIds.filter(function (id) { return squadIds.indexOf(id) !== -1; }).slice(0, 11);
      var bench = (benchIds || squadIds.filter(function (id) { return starters.indexOf(id) === -1; }))
        .filter(function (id) { return squadIds.indexOf(id) !== -1 && starters.indexOf(id) === -1; })
        .slice(0, 7);
      state.customLineups[teamId] = { starters: starters, bench: bench };
      VFL.Storage.save(state);
      return state.customLineups[teamId];
    },

    clearLineup: function (teamId) {
      delete state.customLineups[teamId];
      VFL.Storage.save(state);
    },

    createPlayer: function (data) {
      var id = VFL.Utils.uid("cp");
      var player = {
        id: id,
        name: data.name,
        age: data.age,
        position: data.position,
        country: data.country,
        overall: data.overall,
        teamId: data.teamId,
        seasonStats: { matches: 0, goals: 0, assists: 0, shots: 0, shotsOnTarget: 0, passAccuracy: null, chancesCreated: 0, dribbles: 0, tackles: 0, interceptions: 0, fouls: 0, yellowCards: 0, redCards: 0, minutesPlayed: 0, motmCount: 0, avgRating: null },
        status: { fitness: 100, form: 0, injured: false, injuryReturnWeek: null, suspendedMatches: 0 }
      };
      state.players.push(player);
      VFL.Storage.save(state);
      return player;
    },

    editPlayer: function (playerId, patch) {
      var player = VFL.State.getPlayer(playerId);
      if (!player) return false;
      ["name", "age", "position", "country", "overall"].forEach(function (field) {
        var val = patch[field];
        if (val === undefined) return;
        if (typeof val === "number" && isNaN(val)) return; // ورودی خالی برای سن/Overall نادیده گرفته می‌شود
        player[field] = val;
      });
      VFL.Storage.save(state);
      return true;
    },

    deletePlayer: function (playerId) {
      var idx = state.players.findIndex(function (p) { return p.id === playerId; });
      if (idx === -1) return false;
      state.players.splice(idx, 1);
      VFL.Storage.save(state);
      return true;
    },

    // انتقال کاملاً آزاد — از هر تیمی به هر تیم دیگری، بدون هیچ محدودیتی
    transferPlayer: function (playerId, toTeamId) {
      var player = VFL.State.getPlayer(playerId);
      var toTeam = VFL.Data.getTeamById(toTeamId);
      if (!player || !toTeam) return false;
      var fromTeamId = player.teamId;
      player.teamId = toTeamId;
      state.transferHistory.unshift({
        id: VFL.Utils.uid("tr"),
        playerId: playerId,
        playerName: player.name,
        fromTeamId: fromTeamId,
        toTeamId: toTeamId,
        season: state.season.current,
        week: state.season.week
      });
      VFL.Storage.save(state);
      return true;
    },

    getTransferHistory: function (teamId) {
      if (!teamId) return state.transferHistory;
      return state.transferHistory.filter(function (t) { return t.fromTeamId === teamId || t.toTeamId === teamId; });
    },

    // ---------------- شبیه‌سازی مسابقه لیگ ----------------
    simulateFixture: function (fixtureId) {
      var found = findFixture(fixtureId);
      if (!found.fixture || found.fixture.played) return null;
      var fx = found.fixture;

      var homeInput = buildEngineTeamInput(fx.home, true);
      var awayInput = buildEngineTeamInput(fx.away, false);
      var report = VFL.Engine.simulateMatch({ home: homeInput, away: awayInput });

      fx.played = true;
      fx.result = { homeGoals: report.homeGoals, awayGoals: report.awayGoals };

      applyReportToStandings(found.leagueId, fx.home, fx.away, report);
      applyReportToPlayers(report);
      report.homeTeamId = fx.home;
      report.awayTeamId = fx.away;
      report.competition = "league";
      state.matchReports[fixtureId] = report;

      // توجه: عمداً اینجا ذخیره‌سازی نمی‌شود — شبیه‌سازی چند مسابقه پشت‌سرهم (هفته/همه‌لیگ‌ها)
      // در پایان یک‌بار ذخیره می‌کند تا با رشد دیتابیس بازیکنان کند نشود.
      // اگر این تابع مستقیم از UI برای یک مسابقه تنها صدا زده شود، خودِ UI باید ذخیره را انجام دهد.
      return report;
    },

    // شبیه‌سازی همه بازی‌های هفته جاری یک لیگ به‌تنهایی (برای دکمه‌های اختصاصی هر لیگ)
    simulateWeek: function (leagueId) {
      var fixtures = state.fixtures[leagueId] || [];
      var weekFixtures = fixtures.filter(function (fx) { return fx.week === state.season.week && !fx.played; });
      var reports = weekFixtures.map(function (fx) { return VFL.State.simulateFixture(fx.id); });
      VFL.Storage.save(state);
      return reports;
    },

    // شبیه‌سازی هفته جاری برای «همه» لیگ‌های کامل هم‌زمان — این تابع اصلی پیشبرد تقویم است.
    // هیچ لیگ خاصی (مثل EPL) قفل نیست؛ هر لیگی که برای هفته جاری بازی نشده داشته باشد پردازش می‌شود.
    // لیگ‌هایی که فصلشان زودتر تمام شده (مثلاً ۱۸ تیمی در برابر ۲۰ تیمی) به‌سادگی دیگر بازی‌ای برای
    // هفته‌های بعد ندارند و نادیده گرفته می‌شوند تا با «پایان فصل» به‌طور جداگانه جمع‌بندی شوند.
    simulateGlobalWeek: function () {
      var currentWeek = state.season.week;
      var summary = {};
      VFL.Data.Leagues.filter(function (l) { return l.full; }).forEach(function (league) {
        var fixtures = state.fixtures[league.id] || [];
        var weekFixtures = fixtures.filter(function (fx) { return fx.week === currentWeek && !fx.played; });
        weekFixtures.forEach(function (fx) { VFL.State.simulateFixture(fx.id); });
        summary[league.id] = {
          simulated: weekFixtures.length,
          finished: fixtures.length > 0 && fixtures.every(function (fx) { return fx.played; })
        };
      });
      state.season.week += 1;
      VFL.Storage.save(state);
      return summary;
    },

    // ---------------- فصل، صعود و سقوط ----------------
    getTeamLeague: function (teamId) { return getTeamLeague(teamId); },
    getSeasonHistory: function () { return state.seasonHistory; },
    getSeasonAwardsHistory: function () { return state.seasonAwardsHistory; },
    getPendingTransition: function () { return state.pendingTransition; },

    // وضعیت فعلی هر لیگ کامل: آیا برنامه فصلش تمام شده یا نه
    getLeagueSeasonStatus: function () {
      return VFL.Data.Leagues.filter(function (l) { return l.full; }).map(function (league) {
        var fixtures = state.fixtures[league.id] || [];
        var played = fixtures.filter(function (fx) { return fx.played; }).length;
        return {
          leagueId: league.id,
          displayName: league.displayName,
          totalMatches: fixtures.length,
          playedMatches: played,
          finished: fixtures.length > 0 && played === fixtures.length
        };
      });
    },

    // فصل یک لیگ مشخص را می‌بندد (فقط وقتی برنامه‌اش کامل تمام شده باشد).
    // اگر آن لیگ بخشی از یک پیوند صعود/سقوط باشد، منتظر تمام‌شدن لیگ طرف مقابل هم می‌ماند؛
    // وگرنه بلافاصله فصل جدید همان لیگ (با همان ترکیب تیم‌ها) از نو ساخته می‌شود.
    // لیگ‌های دیگر دست‌نخورده باقی می‌مانند و طبق برنامه خودشان ادامه می‌دهند.
    endLeagueSeason: function (leagueId) {
      var fixtures = state.fixtures[leagueId] || [];
      if (fixtures.length === 0 || !fixtures.every(function (fx) { return fx.played; })) {
        return { type: "not_finished" };
      }

      function archiveIfNeeded(lid) {
        if (state.leagueArchivedPending[lid]) return; // قبلاً برای همین فصل آرشیو شده، دوباره اضافه نکن
        state.seasonHistory.push({
          year: state.season.current,
          leagueId: lid,
          standings: VFL.Utils.clone(VFL.Utils.sortStandings(state.standings[lid]))
        });
        state.leagueArchivedPending[lid] = true;
      }

      archiveIfNeeded(leagueId);

      var link = (VFL.Config.promotionRelegation || []).find(function (l) {
        return l.upperLeagueId === leagueId || l.lowerLeagueId === leagueId;
      });

      if (!link) {
        closeAndRestartLeague(leagueId);
        VFL.Storage.save(state);
        return { type: "league_restarted", leagueId: leagueId };
      }

      var partnerId = link.upperLeagueId === leagueId ? link.lowerLeagueId : link.upperLeagueId;
      var partnerFixtures = state.fixtures[partnerId] || [];
      var partnerFinished = partnerFixtures.length > 0 && partnerFixtures.every(function (fx) { return fx.played; });

      if (!partnerFinished) {
        VFL.Storage.save(state);
        return { type: "waiting_for_partner", leagueId: leagueId, partnerLeagueId: partnerId };
      }

      archiveIfNeeded(partnerId);

      var upperRows = VFL.Utils.sortStandings(state.standings[link.upperLeagueId] || []);
      var lowerRows = VFL.Utils.sortStandings(state.standings[link.lowerLeagueId] || []);
      var result = VFL.Competitions.computePromotionRelegation(link, upperRows, lowerRows);
      var playoff = (link.playoffFrom && link.playoffTo) ? VFL.Competitions.buildPromotionPlayoff(result.playoffTeams) : null;
      var transition = {
        linkId: link.upperLeagueId + "-" + link.lowerLeagueId,
        link: link,
        relegatedFromUpper: result.relegatedFromUpper,
        autoPromotedFromLower: result.autoPromotedFromLower,
        playoffTeams: result.playoffTeams,
        playoff: playoff,
        playoffWinner: null
      };
      state.pendingTransition = {
        transitions: [transition],
        phase: playoff ? "playoff" : "ready",
        scopedLeagues: [link.upperLeagueId, link.lowerLeagueId]
      };
      VFL.Storage.save(state);
      return { type: "transition_ready", hasPlayoff: !!playoff };
    },

    // برچسب سال تقویم بازی را یکی جلو می‌برد — کاملاً مستقل از وضعیت لیگ‌ها،
    // هر وقت کاربر صلاح بداند (مثلاً وقتی همه یا اکثر لیگ‌ها فصلشان تمام شده)
    advanceCalendarYear: function () {
      state.season.current += 1;
      VFL.Storage.save(state);
      return state.season.current;
    },

    // فصل جاری را برای «همه» لیگ‌های کامل هم‌زمان می‌بندد (روش قدیمی/سریع — همه باید تمام شده باشند)
    endSeason: function () {
      VFL.Data.Leagues.filter(function (l) { return l.full; }).forEach(function (league) {
        if (!state.standings[league.id]) return;
        state.seasonHistory.push({
          year: state.season.current,
          leagueId: league.id,
          standings: VFL.Utils.clone(VFL.Utils.sortStandings(state.standings[league.id]))
        });
      });

      var links = VFL.Config.promotionRelegation || [];
      if (links.length === 0) {
        finalizeNewSeason();
        VFL.Storage.save(state);
        return { type: "season_ended", hasTransition: false };
      }

      var transitions = links.map(function (link) {
        var upperRows = VFL.Utils.sortStandings(state.standings[link.upperLeagueId] || []);
        var lowerRows = VFL.Utils.sortStandings(state.standings[link.lowerLeagueId] || []);
        var result = VFL.Competitions.computePromotionRelegation(link, upperRows, lowerRows);
        var playoff = (link.playoffFrom && link.playoffTo) ? VFL.Competitions.buildPromotionPlayoff(result.playoffTeams) : null;
        return {
          linkId: link.upperLeagueId + "-" + link.lowerLeagueId,
          link: link,
          relegatedFromUpper: result.relegatedFromUpper,
          autoPromotedFromLower: result.autoPromotedFromLower,
          playoffTeams: result.playoffTeams,
          playoff: playoff,
          playoffWinner: null
        };
      });

      state.pendingTransition = {
        transitions: transitions,
        phase: transitions.some(function (t) { return t.playoff; }) ? "playoff" : "ready"
      };
      VFL.Storage.save(state);
      return { type: "season_ended", hasTransition: true };
    },

    // یک قدم از پلی‌آف صعود را پیش می‌برد (لگ اول همه تای‌ها، سپس لگ دوم، سپس فینال‌ها)
    simulatePromotionPlayoffStep: function () {
      var pt = state.pendingTransition;
      if (!pt || pt.phase !== "playoff") return null;

      var activeTies = [];
      pt.transitions.forEach(function (t) { if (t.playoff) activeTies.push(t.playoff); });

      var leg1Unplayed = [];
      activeTies.forEach(function (po) {
        if (!po.semiA.leg1.played) leg1Unplayed.push(po.semiA.leg1);
        if (!po.semiB.leg1.played) leg1Unplayed.push(po.semiB.leg1);
      });
      if (leg1Unplayed.length > 0) {
        leg1Unplayed.forEach(function (leg) { playLeg(leg, "promotionPlayoff"); });
        VFL.Storage.save(state);
        return { type: "leg1_simulated" };
      }

      var leg2Unplayed = [];
      activeTies.forEach(function (po) {
        if (!po.semiA.leg2.played) leg2Unplayed.push(po.semiA.leg2);
        if (!po.semiB.leg2.played) leg2Unplayed.push(po.semiB.leg2);
      });
      if (leg2Unplayed.length > 0) {
        leg2Unplayed.forEach(function (leg) { playLeg(leg, "promotionPlayoff"); });
        activeTies.forEach(function (po) { VFL.Competitions.resolveTie(po.semiA); VFL.Competitions.resolveTie(po.semiB); });
        VFL.Storage.save(state);
        return { type: "leg2_simulated" };
      }

      var needsFinal = activeTies.some(function (po) { return !po.final; });
      if (needsFinal) {
        activeTies.forEach(function (po) {
          if (!po.final) po.final = { home: po.semiA.aggregateWinner, away: po.semiB.aggregateWinner, played: false, result: null };
        });
        VFL.Storage.save(state);
        return { type: "final_built" };
      }

      var finalsUnplayed = activeTies.filter(function (po) { return !po.final.played; });
      if (finalsUnplayed.length > 0) {
        finalsUnplayed.forEach(function (po) {
          var report = simulateGenericMatch(po.final.home, po.final.away);
          po.final.played = true;
          po.final.result = { homeGoals: report.homeGoals, awayGoals: report.awayGoals };
          applyReportToPlayers(report);
          report.homeTeamId = po.final.home; report.awayTeamId = po.final.away; report.competition = "promotionPlayoff";
          state.matchReports["promo-final-" + VFL.Utils.uid("m")] = report;
          if (report.homeGoals === report.awayGoals) {
            po.final.penalties = true;
            po.final.winner = Math.random() < 0.5 ? po.final.home : po.final.away;
          } else {
            po.final.winner = report.homeGoals > report.awayGoals ? po.final.home : po.final.away;
          }
        });
        pt.transitions.forEach(function (t) { if (t.playoff && t.playoff.final && t.playoff.final.played) t.playoffWinner = t.playoff.final.winner; });
        pt.phase = "ready";
        VFL.Storage.save(state);
        return { type: "playoff_done" };
      }

      return null;
    },

    // پس از مشخص شدن نتیجه پلی‌آف (یا اگر از اول پلی‌آفی لازم نبود)، فصل جدید را شروع می‌کند
    finalizeNewSeasonTransition: function () {
      var pt = state.pendingTransition;
      if (pt) {
        pt.transitions.forEach(function (t) {
          t.relegatedFromUpper.forEach(function (id) { state.teamLeagueOverride[id] = t.link.lowerLeagueId; });
          t.autoPromotedFromLower.forEach(function (id) { state.teamLeagueOverride[id] = t.link.upperLeagueId; });
          if (t.playoffWinner) state.teamLeagueOverride[t.playoffWinner] = t.link.upperLeagueId;
        });
      }

      if (pt && pt.scopedLeagues) {
        // فقط همان دو لیگ درگیر صعود/سقوط از نو ساخته می‌شوند؛ بقیه لیگ‌ها و سال تقویم دست‌نخورده می‌مانند
        pt.scopedLeagues.forEach(function (lid) { closeAndRestartLeague(lid); });
        state.pendingTransition = null;
        VFL.Storage.save(state);
        return { type: "leagues_restarted", leagues: pt.scopedLeagues };
      }

      state.pendingTransition = null;
      finalizeNewSeason();
      VFL.Storage.save(state);
      return { type: "new_season", year: state.season.current };
    },
    getCup: function () { return state.cup; },

    simulateCupRound: function () {
      if (!state.cup) return null;
      var round = state.cup.bracket.rounds[state.cup.bracket.rounds.length - 1];
      round.matches.forEach(function (m) {
        if (m.played) return;
        var homeInput = buildEngineTeamInput(m.home, true);
        var awayInput = buildEngineTeamInput(m.away, false);
        var report = VFL.Engine.simulateMatch({ home: homeInput, away: awayInput });
        var matchId = "cup-" + m.id;
        m.played = true;
        m.result = { homeGoals: report.homeGoals, awayGoals: report.awayGoals };
        // جام حذفی — تساوی با پنالتی تصادفی مشخص می‌شود (بدون شبیه‌سازی دقیقه‌به‌دقیقه پنالتی در این نسخه)
        if (report.homeGoals === report.awayGoals) {
          m.winner = Math.random() < 0.5 ? m.home : m.away;
          m.penalties = true;
        } else {
          m.winner = report.homeGoals > report.awayGoals ? m.home : m.away;
        }
        applyReportToPlayers(report);
        report.homeTeamId = m.home;
        report.awayTeamId = m.away;
        report.competition = "cup";
        state.matchReports[matchId] = report;
      });
      VFL.Competitions.advanceBracket(state.cup.bracket);
      VFL.Storage.save(state);
      return state.cup.bracket;
    },

    // ---------------- سوپر جام ----------------
    setSuperCupTeams: function (homeTeamId, awayTeamId) {
      state.superCup = { homeTeamId: homeTeamId, awayTeamId: awayTeamId, played: false, matchId: null };
      VFL.Storage.save(state);
    },

    simulateSuperCup: function () {
      var sc = state.superCup;
      if (!sc.homeTeamId || !sc.awayTeamId || sc.played) return null;
      var homeInput = buildEngineTeamInput(sc.homeTeamId, true);
      var awayInput = buildEngineTeamInput(sc.awayTeamId, false);
      var report = VFL.Engine.simulateMatch({ home: homeInput, away: awayInput });
      var matchId = VFL.Utils.uid("sc");
      sc.played = true;
      sc.matchId = matchId;
      sc.result = { homeGoals: report.homeGoals, awayGoals: report.awayGoals };
      applyReportToPlayers(report);
      report.homeTeamId = sc.homeTeamId;
      report.awayTeamId = sc.awayTeamId;
      report.competition = "superCup";
      state.matchReports[matchId] = report;
      VFL.Storage.save(state);
      return report;
    },

    getMatchReport: function (matchId) {
      return state.matchReports[matchId] || null;
    },

    // ---------------- لیگ قهرمانان اروپا ----------------
    getChampionsLeague: function () { return state.championsLeague; },

    // یک قدم پیش می‌رود: بازی‌های نشده مرحله فعلی را شبیه‌سازی می‌کند،
    // یا اگر مرحله تمام شده باشد به مرحله بعد می‌رود.
    simulateCLStep: function () {
      var cl = state.championsLeague;
      if (!cl || cl.phase === "done") return null;

      if (cl.phase === "league") {
        var unplayed = cl.leagueMatches.filter(function (m) { return !m.played; });
        if (unplayed.length > 0) {
          unplayed.forEach(function (m) {
            var report = simulateGenericMatch(m.home, m.away);
            m.played = true;
            m.result = { homeGoals: report.homeGoals, awayGoals: report.awayGoals };
            applyReportToRows(cl.leagueStandings, m.home, m.away, report);
            applyReportToPlayers(report);
            report.homeTeamId = m.home; report.awayTeamId = m.away; report.competition = "championsLeague";
            state.matchReports["cl-" + m.id] = report;
          });
          VFL.Storage.save(state);
          return { type: "league_simulated", count: unplayed.length };
        }
        var ranked = VFL.Utils.sortStandings(cl.leagueStandings).map(function (r) { return r.teamId; });
        cl.leagueRanking = ranked;
        cl.playoffTies = VFL.Competitions.pairBySeeding(ranked.slice(8, 24));
        cl.phase = "playoff";
        VFL.Storage.save(state);
        return { type: "phase_change", phase: "playoff" };
      }

      var roundMap = { playoff: "playoffTies", r16: "r16Ties", qf: "qfTies", sf: "sfTies" };
      if (roundMap[cl.phase]) {
        var ties = cl[roundMap[cl.phase]];
        var leg1Unplayed = ties.filter(function (t) { return !t.leg1.played; });
        if (leg1Unplayed.length > 0) {
          leg1Unplayed.forEach(function (t) { playLeg(t.leg1); });
          VFL.Storage.save(state);
          return { type: "leg1_simulated", phase: cl.phase };
        }
        var leg2Unplayed = ties.filter(function (t) { return !t.leg2.played; });
        if (leg2Unplayed.length > 0) {
          leg2Unplayed.forEach(function (t) { playLeg(t.leg2); });
          ties.forEach(function (t) { VFL.Competitions.resolveTie(t); });
          VFL.Storage.save(state);
          return { type: "leg2_simulated", phase: cl.phase };
        }
        // این دور کامل شد — دور بعد را بساز
        var winners = ties.map(function (t) { return t.aggregateWinner; });
        var nextRanked = sortByLeagueRank(winners, cl.leagueRanking);
        if (cl.phase === "playoff") {
          var top8 = cl.leagueRanking.slice(0, 8);
          var combined = sortByLeagueRank(top8.concat(winners), cl.leagueRanking);
          cl.r16Ties = VFL.Competitions.pairBySeeding(combined);
          cl.phase = "r16";
        } else if (cl.phase === "r16") {
          cl.qfTies = VFL.Competitions.pairBySeeding(nextRanked);
          cl.phase = "qf";
        } else if (cl.phase === "qf") {
          cl.sfTies = VFL.Competitions.pairBySeeding(nextRanked);
          cl.phase = "sf";
        } else if (cl.phase === "sf") {
          var finalist1 = nextRanked[0], finalist2 = nextRanked[1];
          cl.finalMatch = { home: finalist1, away: finalist2, played: false, result: null };
          cl.phase = "final";
        }
        VFL.Storage.save(state);
        return { type: "phase_change", phase: cl.phase };
      }

      if (cl.phase === "final") {
        if (!cl.finalMatch.played) {
          var report = simulateGenericMatch(cl.finalMatch.home, cl.finalMatch.away);
          cl.finalMatch.played = true;
          cl.finalMatch.result = { homeGoals: report.homeGoals, awayGoals: report.awayGoals };
          applyReportToPlayers(report);
          report.homeTeamId = cl.finalMatch.home; report.awayTeamId = cl.finalMatch.away; report.competition = "championsLeague";
          state.matchReports["cl-final"] = report;
          if (report.homeGoals === report.awayGoals) {
            cl.finalMatch.penalties = true;
            cl.finalMatch.winner = Math.random() < 0.5 ? cl.finalMatch.home : cl.finalMatch.away;
          } else {
            cl.finalMatch.winner = report.homeGoals > report.awayGoals ? cl.finalMatch.home : cl.finalMatch.away;
          }
          cl.championTeamId = cl.finalMatch.winner;
          cl.phase = "done";
          VFL.Storage.save(state);
          return { type: "champion", teamId: cl.championTeamId };
        }
      }

      return null;
    }
  };

  function playLeg(leg, tag) {
    tag = tag || "championsLeague";
    var report = simulateGenericMatch(leg.home, leg.away);
    leg.played = true;
    leg.result = { homeGoals: report.homeGoals, awayGoals: report.awayGoals };
    applyReportToPlayers(report);
    report.homeTeamId = leg.home; report.awayTeamId = leg.away; report.competition = tag;
    state.matchReports[tag + "-leg-" + VFL.Utils.uid("m")] = report;
  }

  function sortByLeagueRank(teamIds, ranking) {
    return teamIds.slice().sort(function (a, b) { return ranking.indexOf(a) - ranking.indexOf(b); });
  }

  // فصل جدید را می‌سازد: سال را یکی جلو می‌برد، جدول/برنامه هر لیگ را با عضویت
  // فعلی تیم‌ها (با احتساب صعود/سقوط) دوباره می‌سازد، جام حذفی/سوپرجام/لیگ قهرمانان را ریست می‌کند.
  function finalizeNewSeason() {
    state.season.current += 1;
    state.season.week = 1;

    VFL.Data.Leagues.filter(function (l) { return l.full; }).forEach(function (league) {
      setupLeagueSeason(state, league.id);
    });

    if (state.cup) {
      var cupTeamIds = getTeamsForLeagueFromState(state, state.cup.leagueId);
      state.cup = { leagueId: state.cup.leagueId, bracket: VFL.Competitions.createBracket(cupTeamIds) };
    }
    state.superCup = { homeTeamId: null, awayTeamId: null, played: false, matchId: null };

    if (state.championsLeague) {
      var clTeams = VFL.Competitions.selectChampionsLeagueTeams();
      state.championsLeague = {
        teams: clTeams,
        phase: "league",
        leagueMatches: VFL.Competitions.buildLeaguePhase(clTeams),
        leagueStandings: clTeams.map(VFL.Utils.emptyStandingRow),
        leagueRanking: null, playoffTies: null, r16Ties: null, qfTies: null, sfTies: null,
        finalMatch: null, championTeamId: null
      };
    }
  }
})(window.VFL || (window.VFL = {}));
