import { formatMoney } from "./shared-utils.js";
// =====================================================
// NetEarn Pro
// TASKS PAGE
// ULTRA FAST FINAL CLEAN VERSION
// =====================================================
//
// Current:
// 📱 Social Task
//
// Future:
// 💼 Micro Job
//
// Rules:
// 1️⃣ One User = One Task
// 2️⃣ Pending stays Pending
// 3️⃣ Approved = Completed
// 4️⃣ Rejected stays Rejected
// 5️⃣ Total Task Income = Approved rewards only
// 6️⃣ Dashboard verification gate is separate
// 7️⃣ Tasks Page has NO verification lock card
//
// Performance:
// ⚡ Cache First
// ⚡ Background Firebase Sync
// ⚡ Parallel Firestore Queries
// ⚡ No unnecessary loading on return
// ⚡ Duplicate-safe
// =====================================================


import {
    auth,
    db
} from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";


import {
    collection,
    query,
    where,
    getDocs,
    doc,
    getDoc,
    limit,
    startAfter,
    orderBy,
    documentId
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


import {
    onAuthStateChanged
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


// =====================================================
// ELEMENTS
// =====================================================

let businessSettings = null;

const availableBox =
    document.getElementById(
        "availableTasks"
    );

const pendingBox =
    document.getElementById(
        "pendingTasks"
    );

const completedBox =
    document.getElementById(
        "completedTasks"
    );

const rejectedBox =
    document.getElementById(
        "rejectedTasks"
    );


// =====================================================
// CACHE CONFIG
// =====================================================

const TASK_CACHE_PREFIX =
    "netearnpro_tasks_cache_";


const TASK_CACHE_TIME =
    2 * 60 * 1000;


// =====================================================
// STATE
// =====================================================

let currentUser = null;

let isRefreshing = false;

let hasRenderedCache = false;

// Firestore task pagination
const TASK_PAGE_SIZE = 10;
let lastTaskCursor = null;
let hasMoreTasks = true;
let taskPageLoading = false;
let loadedTaskDocs = [];


// =====================================================
// CACHE KEY
// =====================================================

function getCacheKey(uid) {

    return (
        TASK_CACHE_PREFIX +
        String(uid || "")
    );

}


// =====================================================
// SAVE CACHE
// =====================================================

function saveTaskCache(
    uid,
    data
) {

    if (!uid || !data) {
        return;
    }

    try {

        sessionStorage.setItem(

            getCacheKey(uid),

            JSON.stringify({

                savedAt:
                    Date.now(),

                data:
                    data

            })

        );

    }

    catch (error) {

        console.warn(
            "⚠️ Task cache save failed:",
            error
        );

    }

}


// =====================================================
// GET CACHE
// =====================================================

function getTaskCache(uid) {

    if (!uid) {
        return null;
    }

    try {

        const raw =
            sessionStorage.getItem(
                getCacheKey(uid)
            );

        if (!raw) {
            return null;
        }

        const parsed =
            JSON.parse(raw);

        if (
            !parsed ||
            !parsed.data
        ) {

            return null;

        }

        return parsed;

    }

    catch (error) {

        console.warn(
            "⚠️ Task cache read failed:",
            error
        );

        return null;

    }

}


// =====================================================
// CACHE FRESH CHECK
// =====================================================

function isCacheFresh(
    cache
) {

    if (!cache?.savedAt) {
        return false;
    }

    return (
        Date.now() -
        Number(cache.savedAt)
        <
        TASK_CACHE_TIME
    );

}


// =====================================================
// LOAD TASKS
// =====================================================

async function loadTasks(
    user,
    options = {}
) {

    if (!user) {
        return;
    }


    const uid =
        user.uid;


    const background =
        options.background === true;

    // ⚡ Allow Business Settings to load while task queries are in flight.
    // The settings promise is awaited before fresh task data is rendered,
    // so configured rewards remain exactly the same.
    const settingsPromise =
        options.settingsPromise ||
        Promise.resolve(businessSettings);


    // =================================================
    // CACHE FIRST
    // =================================================

    const cache =
        getTaskCache(uid);


    if (
        cache?.data &&
        !hasRenderedCache
    ) {

        renderTaskData(
            cache.data
        );

        hasRenderedCache =
            true;

        console.log(
            "⚡ Tasks loaded instantly from cache"
        );

    }


    // =================================================
    // FRESH CACHE
    //
    // If cache is fresh, don't immediately
    // perform another heavy query.
    // =================================================

    if (
        cache?.data &&
        isCacheFresh(cache) &&
        !background
    ) {

        refreshTasksInBackground(
            user
        );

        return;

    }


    // =================================================
    // FIRST LOAD WITHOUT CACHE
    // =================================================

    if (
        !cache?.data &&
        !hasRenderedCache
    ) {

        showInitialLoading();

    }


    // =================================================
    // PREVENT DUPLICATE REFRESH
    // =================================================

    if (isRefreshing) {
        return;
    }


    isRefreshing = true;


    try {

        if (options.loadMore !== true) {
            lastTaskCursor = null;
            hasMoreTasks = true;
            loadedTaskDocs = [];
        }

        // =================================================
        // FIRESTORE QUERIES
        //
        // USER DOCUMENT IS NOT REQUIRED HERE.
        // The old version fetched users/{uid}, but
        // userData was not actually used for rendering.
        //
        // Therefore removing that unnecessary read
        // makes the page faster.
        // =================================================

        const submissionQuery =
            query(

                collection(
                    db,
                    "taskSubmissions"
                ),

                where(
                    "userUid",
                    "==",
                    uid
                ),
                limit(100)

            );


        let taskQuery;

        const taskConstraints = [
            where("active", "==", true),
            orderBy(documentId()),
            limit(TASK_PAGE_SIZE)
        ];

        if (options.loadMore === true && lastTaskCursor) {
            taskQuery = query(
                collection(db, "tasks"),
                where("active", "==", true),
                orderBy(documentId()),
                startAfter(lastTaskCursor),
                limit(TASK_PAGE_SIZE)
            );
        } else {
            taskQuery = query(
                collection(db, "tasks"),
                ...taskConstraints
            );
        }


        // =================================================
        // PARALLEL FIREBASE LOAD
        // =================================================

        const [
            submissionSnap,
            taskSnap
        ] =
            await Promise.all([

                getDocs(
                    submissionQuery
                ),

                getDocs(
                    taskQuery
                )

            ]);


        // Ensure admin-configured rewards are ready before rendering.
        businessSettings =
            await settingsPromise;


        // =================================================
        // SUBMISSION MAP
        // =================================================

        const submittedTasks =
            new Map();


        submissionSnap.forEach(
            submissionDoc => {

                const data =
                    submissionDoc.data();


                const taskId =
                    data.taskId;


                if (!taskId) {
                    return;
                }


                const status =
                    String(
                        data.status ||
                        "pending"
                    )
                    .trim()
                    .toLowerCase();


                const existing =
                    submittedTasks.get(
                        taskId
                    );


                // -----------------------------------------
                // FIRST SUBMISSION
                // -----------------------------------------

                if (!existing) {

                    submittedTasks.set(
                        taskId,
                        {
                            ...data,
                            id:
                                submissionDoc.id
                        }
                    );

                    return;

                }


                // -----------------------------------------
                // STATUS PRIORITY
                // -----------------------------------------

                const existingStatus =
                    String(
                        existing.status ||
                        ""
                    )
                    .trim()
                    .toLowerCase();


                const currentProcessed =
                    status === "approved" ||
                    status === "completed" ||
                    status === "rejected";


                const existingProcessed =
                    existingStatus === "approved" ||
                    existingStatus === "completed" ||
                    existingStatus === "rejected";


                if (
                    currentProcessed &&
                    !existingProcessed
                ) {

                    submittedTasks.set(
                        taskId,
                        {
                            ...data,
                            id:
                                submissionDoc.id
                        }
                    );

                }

            }
        );


        // =================================================
        // PROCESS TASKS
        // =================================================

        // Keep previously loaded pages in memory.
        if (options.loadMore === true) {
            taskSnap.docs.forEach(d => {
                if (!loadedTaskDocs.some(existing => existing.id === d.id)) {
                    loadedTaskDocs.push(d);
                }
            });
        } else {
            loadedTaskDocs = [...taskSnap.docs];
        }

        lastTaskCursor = taskSnap.docs.length
            ? taskSnap.docs[taskSnap.docs.length - 1]
            : lastTaskCursor;

        hasMoreTasks = taskSnap.docs.length === TASK_PAGE_SIZE;

        const result =
            buildTaskData(
                { docs: loadedTaskDocs, forEach(fn) { this.docs.forEach(fn); } },
                submittedTasks
            );


        // =================================================
        // SAVE CACHE
        // =================================================

        saveTaskCache(
            uid,
            result
        );


        // =================================================
        // RENDER
        // =================================================

        renderTaskData(
            result
        );


        hasRenderedCache =
            true;


        console.log(
            "✅ Tasks Firebase Sync Complete",
            {
                user:
                    uid,

                total:
                    result.totalTasks,

                pending:
                    result.pending,

                completed:
                    result.completed,

                rejected:
                    result.rejected,

                totalEarn:
                    result.totalEarn
            }
        );

    }

    catch (error) {

        console.error(
            "❌ Tasks Load Error:",
            error
        );


        // =================================================
        // IF CACHE EXISTS
        // DON'T DESTROY GOOD UI
        // =================================================

        const fallbackCache =
            getTaskCache(uid);


        if (
            fallbackCache?.data
        ) {

            renderTaskData(
                fallbackCache.data
            );

            hasRenderedCache =
                true;

            console.warn(
                "⚠️ Firebase failed. Showing cached tasks."
            );

        }

        else {

            showTaskError();

        }

    }

    finally {

        isRefreshing =
            false;

    }

}


// =====================================================
// BACKGROUND REFRESH
// =====================================================

function refreshTasksInBackground(
    user
) {

    if (!user) {
        return;
    }


    // Do not show loading.
    // Existing task cards remain visible.

    setTimeout(
        () => {

            loadTasks(
                user,
                {
                    background:
                        true
                }
            );

        },
        0
    );

}


// =====================================================
// BUILD TASK DATA
// =====================================================

function buildTaskData(
    taskSnap,
    submittedTasks
) {

    let totalTasks =
        0;

    let pending =
        0;

    let completed =
        0;

    let rejected =
        0;

    let totalEarn =
        0;


    let availableHTML =
        "";

    let pendingHTML =
        "";

    let completedHTML =
        "";

    let rejectedHTML =
        "";


    // =================================================
    // ACTIVE TASKS
    // =================================================

    taskSnap.forEach(
        taskDoc => {

            const task =
                taskDoc.data();


            const taskId =
                taskDoc.id;


            // =========================================
            // CATEGORY
            // =========================================

            const category =
                String(
                    task.category ||
                    task.taskCategory ||
                    ""
                )
                .trim()
                .toLowerCase();


            // =========================================
            // SOCIAL ONLY
            // =========================================

            const isSocial =
                category === "social" ||
                category === "social task" ||
                category === "socialtask";


            if (!isSocial) {
                return;
            }


            totalTasks++;


            // =========================================
            // USER SUBMISSION
            // =========================================

            const submission =
                submittedTasks.get(
                    taskId
                );


            // =========================================
            // NEVER SUBMITTED
            // =========================================

            if (!submission) {

                availableHTML +=
                    createTaskCard(

                        {
                            ...task,

                            id:
                                taskId

                        },

                        "available"

                    );

                return;

            }


            // =========================================
            // STATUS
            // =========================================

            const status =
                String(
                    submission.status ||
                    "pending"
                )
                .trim()
                .toLowerCase();


            // =========================================
            // PENDING
            // =========================================

            if (
                status === "pending"
            ) {

                pending++;


                pendingHTML +=
                    createTaskCard(

                        {
                            ...task,

                            id:
                                taskId

                        },

                        "pending"

                    );

            }


            // =========================================
            // APPROVED / COMPLETED
            // =========================================

            else if (
                status === "approved" ||
                status === "completed"
            ) {

                completed++;


                const reward =
                    Number(
                        submission.reward ??
                        submission.rewardPaid ??
                        task.reward ??
                        task.taskReward ??
                        0
                    );


                if (
                    Number.isFinite(
                        reward
                    ) &&
                    reward > 0
                ) {

                    totalEarn +=
                        reward;

                }


                completedHTML +=
                    createTaskCard(

                        {
                            ...task,

                            id:
                                taskId

                        },

                        "completed"

                    );

            }


            // =========================================
            // REJECTED
            // =========================================

            else if (
                status === "rejected"
            ) {

                rejected++;


                rejectedHTML +=
                    createTaskCard(

                        {
                            ...task,

                            id:
                                taskId

                        },

                        "rejected"

                    );

            }


            // =========================================
            // UNKNOWN = PENDING
            // =========================================

            else {

                pending++;


                pendingHTML +=
                    createTaskCard(

                        {
                            ...task,

                            id:
                                taskId

                        },

                        "pending"

                    );

            }

        }
    );


    return {

        totalTasks:
            totalTasks,

        pending:
            pending,

        completed:
            completed,

        rejected:
            rejected,

        totalEarn:
            totalEarn,

        availableHTML:
            availableHTML,

        pendingHTML:
            pendingHTML,

        completedHTML:
            completedHTML,

        rejectedHTML:
            rejectedHTML

    };

}


// =====================================================
// RENDER TASK DATA
// =====================================================

function renderTaskData(
    data
) {

    if (!data) {
        return;
    }


    // =================================================
    // COUNTERS
    // =================================================

    setText(
        "totalCount",
        data.totalTasks || 0
    );


    setText(
        "pendingCount",
        data.pending || 0
    );


    setText(
        "completedCount",
        data.completed || 0
    );


    setText(
        "rejectedCount",
        data.rejected || 0
    );


    setText(
        "totalEarn",
        "৳" +
        formatMoney(
            data.totalEarn || 0
        )
    );


    // =================================================
    // SECTION COUNTERS
    // =================================================

    setText(
        "availableCount",
        countCards(
            data.availableHTML
        )
    );


    setText(
        "pendingSectionCount",
        data.pending || 0
    );


    setText(
        "completedSectionCount",
        data.completed || 0
    );


    setText(
        "rejectedSectionCount",
        data.rejected || 0
    );


    // =================================================
    // AVAILABLE
    // =================================================

    if (availableBox) {

        availableBox.innerHTML =
            data.availableHTML ||
            emptyBox(
                "🔥 No Available Task"
            );

    }


    // =================================================
    // PENDING
    // =================================================

    if (pendingBox) {

        pendingBox.innerHTML =
            data.pendingHTML ||
            emptyBox(
                "⏳ No Pending Task"
            );

    }

// =================================================
    // COMPLETED
    // =================================================

    if (completedBox) {

        completedBox.innerHTML =
            data.completedHTML ||
            emptyBox(
                "✓ No Completed Task"
            );

    }


    // =================================================
    // REJECTED
    // =================================================

    if (rejectedBox) {

        rejectedBox.innerHTML =
            data.rejectedHTML ||
            emptyBox(
                "× No Rejected Task"
            );

    }

    updateLoadMoreUI();

}


// =====================================================
// LOAD MORE UI
// =====================================================

function updateLoadMoreUI() {
    const wrap = document.getElementById("loadMoreTasksWrap");
    const button = document.getElementById("loadMoreTasksBtn");
    if (!wrap || !button) return;

    wrap.style.display = hasMoreTasks ? "block" : "none";
    button.disabled = taskPageLoading;
    button.textContent = taskPageLoading ? "Loading..." : "Load More";
}


// =====================================================
// INITIAL LOADING
// =====================================================

function showInitialLoading() {

    // Only show loading if there is
    // no usable task UI yet.

    if (
        availableBox &&
        !hasVisibleTaskContent(
            availableBox
        )
    ) {

        availableBox.innerHTML = `

            <div class="loading-card">

                <div class="loader"></div>

                <p>
                    Loading Social Tasks...
                </p>

            </div>

        `;

    }

}


// =====================================================
// CHECK VISIBLE TASK CONTENT
// =====================================================

function hasVisibleTaskContent(
    box
) {

    if (!box) {
        return false;
    }


    return Boolean(
        box.querySelector(
            ".social-task-card"
        )
    );

}


// =====================================================
// TASK ERROR
// =====================================================

function showTaskError() {

    if (availableBox) {

        availableBox.innerHTML =
            emptyBox(
                "❌ Task load করা যায়নি।"
            );

    }

}


// =====================================================
// TASK CARD
// =====================================================

function createTaskCard(
    task,
    status
) {

    const taskName =
        escapeHTML(

            task.name ||
            task.taskName ||
            task.taskTitle ||
            "Social Task"

        );


    const description =
        escapeHTML(

            task.description ||
            "Complete this task."

        );


    const reward =
        getConfiguredTaskReward(task, businessSettings || undefined);


    const image =
        task.taskImage ||
        task.image ||
        task.imageUrl ||
        "";


    // =================================================
    // BUTTON
    // =================================================

    let buttonHTML =
        "";


    if (
        status ===
        "available"
    ) {

        buttonHTML = `

            <button
                class="start-btn"
                onclick="startTask('${escapeAttribute(task.id)}')"
            >
                ▶ Start Task
            </button>

        `;

    }


    else if (
        status ===
        "pending"
    ) {

        buttonHTML = `

            <button
                class="pending-btn"
                disabled
            >
                ⏳ Pending Review
            </button>

        `;

    }


    else if (
        status ===
        "completed"
    ) {

        buttonHTML = `

            <button
                class="done-btn"
                disabled
            >
                ✓ Completed
            </button>

        `;

    }


    else {

        buttonHTML = `

            <button
                class="reject-btn"
                disabled
            >
                × Rejected
            </button>

        `;

    }


    // =================================================
    // STATUS TEXT
    // =================================================

    let statusText =
        "Available";


    if (
        status ===
        "pending"
    ) {

        statusText =
            "Pending Review";

    }

    else if (
        status ===
        "completed"
    ) {

        statusText =
            "Completed";

    }

    else if (
        status ===
        "rejected"
    ) {

        statusText =
            "Rejected";

    }


    // =================================================
    // CARD
    // =================================================

    return `

        <article
            class="social-task-card"
        >

            ${
                image
                ?

                `

                <div
                    class="task-image-wrap"
                >

                    <img
                        src="${escapeAttribute(image)}"
                        alt="${taskName}"
                        loading="lazy"
                        onerror="this.parentElement.classList.add('image-error')"
                    >

                    <span
                        class="task-category-badge"
                    >
                        📱 Social
                    </span>

                </div>

                `

                :

                `

                <div
                    class="task-image-placeholder"
                >

                    📱

                    <span>
                        Social Task
                    </span>

                </div>

                `
            }


            <div
                class="social-task-content"
            >

                <div
                    class="task-title-row"
                >

                    <h3>
                        ${taskName}
                    </h3>

                </div>


                <p
                    class="task-description"
                >
                    ${description}
                </p>


                <div
                    class="task-meta"
                >

                    <span
                        class="reward-pill"
                    >
                        ৳${formatMoney(reward)}
                    </span>


                    <span
                        class="status-pill ${status}"
                    >
                        ${statusText}
                    </span>

                </div>


                ${buttonHTML}


            </div>

        </article>

    `;

}


// =====================================================
// START TASK
// =====================================================

window.startTask =
async function(id) {

    if (!id) {

        await alert(
            "❌ Task ID পাওয়া যায়নি।"
        );

        return;

    }


    const user =
        auth.currentUser;


    if (!user) {

        location.href =
            "index.html";

        return;

    }


    try {

        // =================================================
        // ONE USER = ONE TASK
        // =================================================

        const submissionQuery =
            query(

                collection(
                    db,
                    "taskSubmissions"
                ),

                where(
                    "userUid",
                    "==",
                    user.uid
                ),

                where(
                    "taskId",
                    "==",
                    id
                )

            );


        const submissionSnap =
            await getDocs(
                submissionQuery
            );


        if (
            !submissionSnap.empty
        ) {

            alert(

                "⚠️ আপনি এই Task ইতিমধ্যে করেছেন।\n\n" +
                "একজন User একটি Task শুধুমাত্র একবার করতে পারবে।"

            );


            // Refresh in background.
            refreshTasksInBackground(
                user
            );


            return;

        }


        // =================================================
        // VERIFY TASK STILL ACTIVE
        // =================================================

        const taskRef =
            doc(
                db,
                "tasks",
                id
            );


        const taskSnap =
            await getDoc(
                taskRef
            );


        if (
            !taskSnap.exists()
        ) {

            alert(
                "❌ এই Task আর পাওয়া যাচ্ছে না।"
            );

            refreshTasksInBackground(
                user
            );

            return;

        }


        const task =
            taskSnap.data();


        if (
            task.active !==
            true
        ) {

            alert(
                "⚠️ এই Task বর্তমানে Active নেই।"
            );


            refreshTasksInBackground(
                user
            );


            return;

        }


        // =================================================
        // CATEGORY CHECK
        // =================================================

        const category =
            String(

                task.category ||
                task.taskCategory ||
                ""

            )
            .trim()
            .toLowerCase();


        const isSocial =
            category === "social" ||
            category === "social task" ||
            category === "socialtask";


        if (!isSocial) {

            await alert(
                "⚠️ এই Task বর্তমানে Social Task নয়।"
            );

            return;

        }


        // =================================================
        // OPEN SUBMISSION PAGE
        // =================================================

        location.href =
            `submit-task.html?taskId=${encodeURIComponent(id)}`;

    }


    catch (error) {

        console.error(
            "❌ Start Task Error:",
            error
        );


        alert(
            "❌ Task open করা যায়নি।\n\n" +
            "দয়া করে আবার চেষ্টা করুন।"
        );

    }

};


// =====================================================
// HELPERS
// =====================================================

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


// =====================================================
// MONEY
// =====================================================
// =====================================================
// COUNT CARDS
// =====================================================

function countCards(
    html
) {

    if (!html) {
        return 0;
    }


    const matches =
        html.match(
            /class="social-task-card"/g
        );


    return matches
        ? matches.length
        : 0;

}


// =====================================================
// EMPTY BOX
// =====================================================

function emptyBox(
    text
) {

    return `

        <div
            class="empty-card"
        >

            <span>
                ${escapeHTML(text)}
            </span>

        </div>

    `;

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// ESCAPE ATTRIBUTE
// =====================================================

function escapeAttribute(
    value
) {

    return escapeHTML(
        value
    );

}


const loadMoreTasksBtn = document.getElementById("loadMoreTasksBtn");

loadMoreTasksBtn?.addEventListener("click", async () => {
    if (!currentUser || taskPageLoading || !hasMoreTasks) return;

    taskPageLoading = true;
    updateLoadMoreUI();

    try {
        await loadTasks(currentUser, {
            loadMore: true,
            background: true,
            settingsPromise: Promise.resolve(businessSettings)
        });
    } finally {
        taskPageLoading = false;
        updateLoadMoreUI();
    }
});


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(

    auth,

    async user => {

        console.log(
            "🔥 Tasks Auth:",
            user?.uid ||
            "SIGNED OUT"
        );


        if (!user) {

            location.href =
                "index.html";

            return;

        }


        currentUser =
            user;

        // ⚡ Start Business Settings and task/submission reads together.
        const settingsPromise =
            getBusinessSettings({ force: true });

        await loadTasks(
            user,
            {
                settingsPromise
            }
        );

    }

);


// =====================================================
// FINAL READY
// =====================================================

console.log(
    "======================================"
);

console.log(
    "📋 NetEarn Pro Tasks"
);

console.log(
    "⚡ Ultra Fast Task System Ready"
);

console.log(
    "📱 Social Task System Ready"
);

console.log(
    "💼 Micro Job Architecture Ready"
);

console.log(
    "1️⃣ One User = One Task"
);

console.log(
    "⏳ Pending Ready"
);

console.log(
    "✅ Completed Ready"
);

console.log(
    "❌ Rejected Ready"
);

console.log(
    "💰 Total Task Income Ready"
);

console.log(
    "🔥 Available Tasks Ready"
);

console.log(
    "⚡ Cache First Enabled"
);

console.log(
    "⚡ Background Firebase Sync Enabled"
);

console.log(
    "🔒 Dashboard Verification Gate Separate"
);

console.log(
    "======================================"
);