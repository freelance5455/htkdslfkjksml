import { money, getDateValue } from "./shared-utils.js";
// =====================================================
// NetEarn Pro
// Premium Wallet Transaction History
//
// IMPORTANT:
// Existing "transactions" collection is used.
// No old transaction data is changed.
// =====================================================


import {
    auth,
    db
} from "./firebase.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    collection,
    query,
    where,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";



// =====================================================
// HELPERS
// =====================================================
// =====================================================
// WALLET HISTORY CACHE
// =====================================================
// Cache only the last successfully rendered result so the
// page can show useful history immediately while Firebase
// refreshes in the background. Cache failures must never
// block the real Firebase load.

function getWalletHistoryCacheKey(uid) {

    return `netearn_wallet_history_${String(uid || "")}`;

}


function restoreWalletHistoryCache(
    uid,
    historyList,
    historyCount
) {

    try {

        if (!uid || !historyList) {

            return false;

        }

        const raw = sessionStorage.getItem(
            getWalletHistoryCacheKey(uid)
        );

        if (!raw) {

            return false;

        }

        const cached = JSON.parse(raw);

        if (
            !cached ||
            typeof cached.html !== "string" ||
            cached.html.length > 500000
        ) {

            return false;

        }

        historyList.innerHTML = cached.html;

        if (historyCount && typeof cached.count === "string") {

            historyCount.innerText = cached.count;

        }

        return true;

    }

    catch (error) {

        console.warn(
            "⚠️ Wallet history cache restore skipped:",
            error
        );

        return false;

    }

}


function saveWalletHistoryCache(
    uid,
    historyList,
    historyCount
) {

    try {

        if (!uid || !historyList) {

            return;

        }

        sessionStorage.setItem(
            getWalletHistoryCacheKey(uid),
            JSON.stringify({
                html: historyList.innerHTML,
                count: historyCount?.innerText || "",
                savedAt: Date.now()
            })
        );

    }

    catch (error) {

        // Cache is only an enhancement; never fail the page because
        // sessionStorage is unavailable or full.
        console.warn(
            "⚠️ Wallet history cache save skipped:",
            error
        );

    }

}


function escapeHTML(value) {

    return String(
        value ?? ""
    )

    .replace(
        /&/g,
        "&amp;"
    )

    .replace(
        /</g,
        "&lt;"
    )

    .replace(
        />/g,
        "&gt;"
    )

    .replace(
        /"/g,
        "&quot;"
    )

    .replace(
        /'/g,
        "&#039;"
    );

}



// =====================================================
// DATE FORMAT
// =====================================================


function formatDate(date) {

    if (!date) {

        return "Date unavailable";

    }


    return date.toLocaleString(
        "en-BD",
        {

            day:
                "2-digit",

            month:
                "short",

            year:
                "numeric",

            hour:
                "2-digit",

            minute:
                "2-digit"

        }
    );

}



// =====================================================
// TRANSACTION ICON
// =====================================================


function getTransactionIcon(type) {

    const transactionType =
        String(
            type || "credit"
        )
        .toLowerCase();


    if (
        transactionType ===
        "debit"
    ) {

        return `
            <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
            >

                <path
                    d="M12 5v14"
                />

                <path
                    d="M7 14l5 5 5-5"
                />

            </svg>
        `;

    }


    return `
        <svg
            viewBox="0 0 24 24"
            aria-hidden="true"
        >

            <path
                d="M12 19V5"
            />

            <path
                d="M7 10l5-5 5 5"
            />

        </svg>
    `;

}



// =====================================================
// STATUS CLASS
// =====================================================


function getStatusClass(status) {

    const value =
        String(
            status ||
            "Completed"
        )
        .trim()
        .toLowerCase();


    if (
        value ===
        "pending"
    ) {

        return "history-status pending";

    }


    if (
        value ===
        "rejected"
    ) {

        return "history-status rejected";

    }


    if (
        value ===
        "approved"
    ) {

        return "history-status approved";

    }


    return "history-status completed";

}



// =====================================================
// LOAD TRANSACTIONS
// =====================================================


async function loadTransactions(uid) {

    const historyList =
        document.getElementById(
            "historyList"
        );


    const historyCount =
        document.getElementById(
            "historyCount"
        );


    if (!historyList) {

        return;

    }


    try {

        // Show the last successful result immediately; refresh from Firebase below.
        const hasCachedHistory = restoreWalletHistoryCache(
            uid,
            historyList,
            historyCount
        );

        // ---------------------------------------------
        // LOADING
        // ---------------------------------------------

        if (!hasCachedHistory) historyList.innerHTML = `

            <div class="history-loading">

                <div class="loading-spinner"></div>

                <p>
                    Loading Transactions...
                </p>

            </div>

        `;



        // ---------------------------------------------
        // QUERY
        // ---------------------------------------------

        const transactionQuery =
            query(

                collection(
                    db,
                    "transactions"
                ),

                where(
                    "uid",
                    "==",
                    uid
                )

            );



        const snapshot =
            await getDocs(
                transactionQuery
            );



        // ---------------------------------------------
        // EMPTY
        // ---------------------------------------------

        if (
            snapshot.empty
        ) {

            if (historyCount) {

                historyCount.innerText =
                    "0 Transactions";

            }


            historyList.innerHTML = `

                <div class="empty-history">

                    <div class="empty-icon">

                        <svg
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                        >

                            <rect
                                x="4"
                                y="4"
                                width="16"
                                height="16"
                                rx="3"
                            />

                            <path
                                d="M8 9h8"
                            />

                            <path
                                d="M8 13h6"
                            />

                            <path
                                d="M8 17h4"
                            />

                        </svg>

                    </div>


                    <h3>
                        No Transactions Yet
                    </h3>


                    <p>
                        Your wallet activity will
                        appear here.
                    </p>

                </div>

            `;

            return;

        }



        // ---------------------------------------------
        // CREATE ARRAY
        // ---------------------------------------------

        const transactions = [];


        snapshot.forEach(
            transactionDoc => {

                const data =
                    transactionDoc.data();


                transactions.push({

                    id:
                        transactionDoc.id,

                    amount:
                        Number(
                            data.amount || 0
                        ),

                    type:
                        String(
                            data.type ||
                            "credit"
                        )
                        .trim()
                        .toLowerCase(),

                    reason:
                        data.reason ||
                        "Wallet Transaction",

                    status:
                        data.status ||
                        "Completed",

                    taskId:
                        data.taskId ||
                        null,

                    submissionId:
                        data.submissionId ||
                        null,

                    createdAt:
                        getDateValue(
                            data.createdAt
                        )

                });

            }
        );



        // ---------------------------------------------
        // NEWEST FIRST
        // ---------------------------------------------

        transactions.sort(
            (
                first,
                second
            ) => {

                const firstTime =
                    first.createdAt
                        ?.getTime() || 0;


                const secondTime =
                    second.createdAt
                        ?.getTime() || 0;


                return (
                    secondTime -
                    firstTime
                );

            }
        );



        // ---------------------------------------------
        // COUNT
        // ---------------------------------------------

        if (historyCount) {

            historyCount.innerText =
                `${transactions.length} ${
                    transactions.length === 1
                        ? "Transaction"
                        : "Transactions"
                }`;

        }



        // ---------------------------------------------
        // RENDER
        // ---------------------------------------------

        historyList.innerHTML = "";


        transactions.forEach(
            transaction => {

                const isCredit =
                    transaction.type ===
                    "credit";


                const sign =
                    isCredit
                        ? "+"
                        : "-";


                const amountClass =
                    isCredit
                        ? "history-credit"
                        : "history-debit";


                const iconClass =
                    isCredit
                        ? "history-credit-icon"
                        : "history-debit-icon";


                const icon =
                    getTransactionIcon(
                        transaction.type
                    );


                const statusClass =
                    getStatusClass(
                        transaction.status
                    );


                const date =
                    formatDate(
                        transaction.createdAt
                    );



                const card =
                    document.createElement(
                        "article"
                    );


                card.className =
                    "premium-transaction-card";



                card.innerHTML = `

                    <div class="transaction-main">


                        <!-- ICON -->

                        <div
                            class="transaction-icon ${iconClass}"
                        >

                            ${icon}

                        </div>



                        <!-- DETAILS -->

                        <div class="transaction-details">

                            <h3>

                                ${escapeHTML(
                                    transaction.reason
                                )}

                            </h3>


                            <div class="transaction-meta">

                                <span>

                                    ${escapeHTML(
                                        date
                                    )}

                                </span>

                            </div>


                            <div class="transaction-status-row">

                                <span
                                    class="${statusClass}"
                                >

                                    ${escapeHTML(
                                        transaction.status
                                    )}

                                </span>

                            </div>

                        </div>



                        <!-- AMOUNT -->

                        <div
                            class="transaction-amount ${amountClass}"
                        >

                            <strong>

                                ${sign}${money(
                                    transaction.amount
                                )}

                            </strong>


                            <span>

                                ${
                                    isCredit
                                        ? "Credit"
                                        : "Debit"
                                }

                            </span>

                        </div>


                    </div>

                `;


                historyList.appendChild(
                    card
                );

            }
        );



        saveWalletHistoryCache(
            uid,
            historyList,
            historyCount
        );

        console.log(
            "✅ Wallet transaction history loaded:",
            transactions.length
        );

    }

    catch (error) {

        console.error(
            "❌ Wallet History Error:",
            error
        );


        if (historyCount) {

            historyCount.innerText =
                "History unavailable";

        }


        historyList.innerHTML = `

            <div class="empty-history error-history">

                <div class="empty-icon">

                    <svg
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path
                            d="M12 8v5"
                        />

                        <circle
                            cx="12"
                            cy="16.5"
                            r=".8"
                        />

                    </svg>

                </div>


                <h3>
                    History Load Failed
                </h3>


                <p>
                    Transaction history could not
                    be loaded right now.
                </p>

            </div>

        `;

    }

}



// =====================================================
// AUTH
// =====================================================


onAuthStateChanged(

    auth,

    async user => {

        console.log(
            "🔥 Wallet History Auth:",
            user?.uid ||
            "SIGNED OUT"
        );


        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        await loadTransactions(
            user.uid
        );

    }

);



// =====================================================
// FINAL READY
// =====================================================


console.log(
    "======================================="
);


console.log(
    "✅ NetEarn Pro Premium Wallet History"
);


console.log(
    "📜 Transaction History Ready"
);


console.log(
    "💰 Existing Transaction Data Preserved"
);


console.log(
    "======================================="
);

// =====================================================
// REFRESH TRANSACTION HISTORY
// =====================================================

const refreshHistoryBtn =
    document.getElementById(
        "refreshHistoryBtn"
    );

if (refreshHistoryBtn) {

    refreshHistoryBtn.addEventListener(
        "click",
        () => {

            refreshHistoryBtn.classList.add(
                "refreshing"
            );

            // Reload wallet history
            window.location.reload();

        }
    );

}