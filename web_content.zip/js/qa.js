/* يمكن هدف؟ — "اسأل المحلل": rule-based Arabic Q&A over the match data (local, no external models) */
(function () {
  const { ai, viz } = YH; const esc = viz.esc; const AR = ai.AR; const X = () => YH.tactics;
  const R = Math.round, pc = v => R(v * 100); const f2 = v => (v || 0).toFixed(2);
  const OPP = s => s === 'home' ? 'away' : 'home';
  const norm = t => (t || '').toLowerCase().replace(/[\u064B-\u065F\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/[؟?!.,،]/g, ' ');
  const has = (t, words) => words.some(w => t.includes(norm(w)));

  function teamIn(ctx, qn) {
    const sc = s => {
      const ar = norm(AR(ctx.ev[s].name)), en = norm(ctx.ev[s].name);
      const parts = [...ar.split(' '), ...en.split(' ')].map(w => w.replace(/^ال/, '')).filter(w => w.length >= 3 && !/^(fc|cf|afc|club|united|city|real|nacional)$/.test(w));
      let k = 0; if (qn.includes(ar)) k += 5; if (qn.includes(en)) k += 5; parts.forEach(w => { if (qn.includes(w)) k += 2; }); return k;
    };
    const h = sc('home'), a = sc('away');
    if (h === a) return /المضيف|صاحب الارض|الارض/.test(qn) ? 'home' : /الضيف/.test(qn) ? 'away' : null;
    return h > a ? 'home' : 'away';
  }

  const card = (ctx, title, rows, extra) => {
    const c = ctx.c;
    return `<div class="qa-a"><p class="qa-q">${esc(title)}</p>${rows ? `<div class="tx-teams"><span style="--tc:${c.home}">${esc(AR(ctx.ev.home.name))}</span><span style="--tc:${c.away}">${esc(AR(ctx.ev.away.name))}</span></div><div class="tx-m">${rows.map(r => { const h = r.h || 0, a = r.a || 0, t = (h + a) || 1; return `<div class="tx-r"><b>${r.h}${r.u || ''}</b><span>${esc(r.l)}</span><b>${r.a}${r.u || ''}</b><div class="tx-bar"><i style="width:${(h / t * 100).toFixed(1)}%;background:${c.home}"></i><i style="width:${(a / t * 100).toFixed(1)}%;background:${c.away}"></i></div></div>`; }).join('')}</div>` : ''}${extra || ''}</div>`;
  };
  const scene = (ctx, q, texts, rows, extra) => ({ t: 'سؤالك للمحلل', html: card(ctx, q, rows, extra), lines: texts.filter(Boolean).map(t => ({ t, at: () => document.querySelector('.qa-a .tx-m') || document.querySelector('.qa-q') })) });

  /* why did a team lose control of the game? */
  function controlAnswer(ctx, s, q) {
    const { sum, ev } = ctx; const T = k => AR(ev[k].name); const evs = X().events(sum); const mx = X().maxMinute(sum);
    const win = []; for (let a = 0; a + 15 <= mx + 5; a += 5) { const r = X().share(evs, a, a + 15); win.push({ a, v: r.tot ? r[s] : 0.5, tot: r.tot }); }
    const ts = ai.teamStats(sum); const me = ts[s] || {}, op = ts[OPP(s)] || {};
    const pS = X().profile(sum, s), pO = X().profile(sum, OPP(s));
    const peak = win.filter(w => w.tot).sort((x, y) => y.v - x.v)[0];
    let drop = null; let had = false;
    for (const w of win) { if (w.tot && w.v >= 0.55) had = true; if (had && w.tot && w.v <= 0.4) { drop = w; break; } }
    const texts = []; const all = X().share(evs, 0, 200);
    if (!had) {
      texts.push(`${T(s)} أصلاً ما سيطر على المباراة: من البداية ${T(OPP(s))} كان عنده ${pc(all[OPP(s)])} بالمية من الضغط الهجومي${me.possessionPct != null ? `، و${T(s)} استحوذ بس ${R(me.possessionPct)} بالمية` : ''}.`);
    } else if (drop) {
      const a = drop.a, b = drop.a + 15;
      const near = evs.filter(e => e.side && e.m >= a - 6 && e.m <= b);
      const causes = [];
      near.filter(e => /^goal|scored/.test(e.tt)).forEach(e => causes.push(e.side === s ? `بعد ما سجّل بالدقيقة ${Math.floor(e.m)} رجع لورا يحافظ على النتيجة` : `هدف ${T(e.side)} بالدقيقة ${Math.floor(e.m)} هزّ ثقة الفريق`));
      near.filter(e => /red-card/.test(e.tt)).forEach(e => causes.push(e.side === s ? `الطرد بالدقيقة ${Math.floor(e.m)} خلاه يلعب ناقص` : `الخصم لعب ناقص، و${T(s)} ما عرف يستغل`));
      const subO = near.filter(e => /substitution/.test(e.tt) && e.side === OPP(s)); if (subO.length) causes.push(`تبديلات ${T(OPP(s))} بالدقيقة ${Math.floor(subO[0].m)} بدّلت شكل الوسط، ودخل ${subO.map(e => X().nmAr(ctx, e.who[0], e.side)).join(' و')}`);
      const subS = near.filter(e => /substitution/.test(e.tt) && e.side === s); if (subS.length) causes.push(`تبديلات ${T(s)} نفسه بالدقيقة ${Math.floor(subS[0].m)} كسرت الإيقاع`);
      if (!causes.length) causes.push(`${T(OPP(s))} رفع الضغط وتقدم بخطوطه`);
      texts.push(`${T(s)} كان مسيطر${peak ? ` بين الدقيقة ${peak.a} و${peak.a + 15} بنسبة ${pc(peak.v)} بالمية` : ''}، بس من الدقيقة ${a} نزلت سيطرته لـ${pc(drop.v)} بالمية.`);
      texts.push(`السبب حسب بيانات المباراة: ${causes.slice(0, 3).join('، و')}.`);
    } else {
      texts.push(`${T(s)} ما خسر السيطرة بشكل واضح: حافظ على ${pc(all[s])} بالمية من الضغط الهجومي طول المباراة${peak ? `، وأقوى فترة إله من الدقيقة ${peak.a} لـ${peak.a + 15}` : ''}.`);
    }
    if (pO.foulX != null && pS.foulX != null && pO.foulX > pS.foulX + 6) texts.push(`وتكتيكياً: ${T(OPP(s))} ضغط أعلى منه، ودقة تمرير ${T(s)} كانت ${pS.passPct || 0} بالمية${pS.longShare >= 20 ? `، فاضطر يلعب كرات طويلة ${pS.long} مرة` : ''}.`);
    else texts.push(`وبالأرقام: استحواذ ${T(s)} ${me.possessionPct != null ? R(me.possessionPct) : '—'} بالمية مقابل ${op.possessionPct != null ? R(op.possessionPct) : '—'}، ودقة تمريره ${pS.passPct || 0} بالمية مقابل ${pO.passPct || 0}.`);
    const rows = [{ l: 'الاستحواذ', h: R(ts.home.possessionPct || 0), a: R(ts.away.possessionPct || 0), u: '%' }, { l: 'الضغط الهجومي', h: pc(all.home), a: pc(all.away), u: '%' }, { l: 'دقة التمرير', h: X().profile(sum, 'home').passPct || 0, a: X().profile(sum, 'away').passPct || 0, u: '%' }];
    return scene(ctx, q, texts, rows, `<div class="qa-mom">${viz.momentumChart(ai.momentum(sum), ctx.c, ai.analyze(sum).goals, { W: 640, Hh: 110 })}</div>`);
  }

  function ask(ctx, question) {
    const qn = norm(question); const { ev, sum, P, mode } = ctx; const T = s => AR(ev[s].name);
    const s0 = teamIn(ctx, qn);
    const pre = mode === 'pre';
    const res = pre ? null : ev.home.score > ev.away.score ? 'home' : ev.away.score > ev.home.score ? 'away' : 'draw';
    const notYet = () => scene(ctx, question, [`المباراة بعدها ما بدت، فما عندي أحداث أحللها. بس أگدر أشرحلك التوقع والتكتيك المتوقع: ${P ? `${T(P.pick === 'draw' ? 'home' : P.pick)} ${P.pick === 'draw' ? 'والتعادل الأرجح' : `الأقرب للفوز بنسبة ${pc(P.fin[P.pick])} بالمية`}.` : ''}`]);

    // minute
    const mm = qn.match(/(?:الدقيقه|دقيقه|د)\s*(\d{1,3})/) || qn.match(/^\s*(\d{1,3})\s*$/) || qn.match(/(\d{1,3})\s*(?:'|دقيقه)/);
    if (mm) { if (pre) return notYet(); const m = Math.min(+mm[1], X().maxMinute(sum)); const sc = X().minuteScene(ctx, m); sc.lines.unshift({ t: `سؤالك عن الدقيقة ${m}.`, at: () => null }); return sc; }

    // prediction / how did you compute
    if (has(qn, ['توقع', 'نسبه', 'احتمال', 'شلون حسبت', 'كيف حسبت', 'كيف وصلت', 'منو يفوز', 'من سيفوز', 'مين يفوز', 'الرقم'])) {
      const ps = X().predScenes(ctx); if (ps.length) { const sc = ps[0]; return { ...sc, t: 'سؤالك للمحلل' }; }
    }
    if (has(qn, ['xg', 'اكس جي', 'الاهداف المتوقعه'])) { const ps = X().predScenes(ctx); const x = ps.find(s => /xG/.test(s.t)); if (x) return { ...x, t: 'سؤالك للمحلل' }; }

    if (pre && !has(qn, ['تكتيك', 'خطه', 'تشكيل', 'اسلوب', 'يلعب', 'ضغط', 'دفاع', 'هجوم'])) return notYet();

    // control
    if (has(qn, ['سيطر', 'السيطره', 'الاستحواذ', 'الايقاع', 'تراجع', 'فقد'])) {
      let s = s0; if (!s) { const sh = X().share(X().events(sum), 0, 200); s = has(qn, ['خسر', 'فقد', 'تراجع']) ? (sh.home < sh.away ? 'home' : 'away') : (sh.home >= sh.away ? 'home' : 'away'); }
      return controlAnswer(ctx, s, question);
    }
    // replay a goal
    if (has(qn, ['هدف', 'اهداف', 'سجل', 'انسجل', 'الگول', 'گول', 'جول'])) {
      const goals = X().shotsOf(sum).filter(s => s.goal && !s.own).sort((a, b) => a.min - b.min);
      if (!goals.length) return scene(ctx, question, ['ما انسجل أي هدف لحد هسه.']);
      let i = /ثاني/.test(qn) ? 1 : /ثالث/.test(qn) ? 2 : /اخير/.test(qn) ? goals.length - 1 : 0;
      if (s0 && !/ثاني|ثالث|اخير/.test(qn)) i = Math.max(0, goals.findIndex(g => g.side === s0));
      const rp = X().replayScenes(ctx, Math.min(i, goals.length - 1));
      if (rp.length) return { ...rp[0], t: 'سؤالك للمحلل' };
      return scene(ctx, question, [goals.map(g => `${X().nmAr(ctx, g.who, g.side)} سجّل لـ${T(g.side)} بالدقيقة ${Math.floor(g.min)}`).join('، و') + '.']);
    }
    // why did X win/lose
    if (has(qn, ['ليش', 'لماذا', 'سبب', 'شنو السبب']) && has(qn, ['خسر', 'فاز', 'هزيمه', 'فوز', 'تعادل', 'ربح', 'انغلب', 'غلب'])) {
      const pH = X().profile(sum, 'home'), pA = X().profile(sum, 'away'); const p = s => s === 'home' ? pH : pA;
      const s = s0 || (res === 'draw' ? 'home' : has(qn, ['خسر', 'هزيمه', 'انغلب']) ? OPP(res) : res);
      const o = OPP(s); const evs = X().events(sum); const red = evs.find(e => /red-card/.test(e.tt) && e.side);
      const won = res === s, lost = res === o;
      const texts = [`${T(s)} ${won ? 'فاز' : lost ? 'خسر' : 'تعادل'} ${ev[s].score} ل ${ev[o].score}. خلّي أشرح الأسباب من البيانات.`];
      if (red) texts.push(red.side === (won ? o : s) ? `أول سبب: طرد ${X().nmAr(ctx, red.who[0], red.side)} بالدقيقة ${Math.floor(red.m)}، ${T(red.side)} لعب ناقص أغلب الوقت.` : `رغم إن ${T(red.side)} لعب ناقص من الدقيقة ${Math.floor(red.m)}.`);
      texts.push(`جودة الفرص: ${T(s)} ${f2(p(s).xg)} إكس جي مقابل ${f2(p(o).xg)} لـ${T(o)}، و${p(s).inBox} تسديدات من داخل الصندوق مقابل ${p(o).inBox}.`);
      texts.push(`وتكتيكياً: ${T(s)} لعب ${X().buildStyle(p(s)).t} و${X().pressStyle(p(s)).t}، بينما ${T(o)} لعب ${X().buildStyle(p(o)).t}.`);
      const eff = (ev[s].score || 0) - p(s).xg; if (Math.abs(eff) > 0.6) texts.push(eff > 0 ? `وكان فعّال أمام المرمى، سجّل أكثر من المتوقع.` : `بس أهدر فرص كان المفروض تدخل.`);
      return scene(ctx, question, texts, [{ l: 'xG', h: f2(pH.xg), a: f2(pA.xg) }, { l: 'التسديدات', h: pH.n, a: pA.n }, { l: 'الاستحواذ', h: pH.poss || 0, a: pA.poss || 0, u: '%' }]);
    }
    // best player
    if (has(qn, ['افضل', 'احسن', 'نجم', 'منو لعب زين'])) {
      const rt = ai.ratings(sum).filter(r => !s0 || r.side === s0).slice(0, 3);
      if (rt.length) return scene(ctx, question, [`${s0 ? `أفضل لاعب عند ${T(s0)}` : 'نجم المباراة'}: ${X().nmAr(ctx, rt[0].name, rt[0].side)} من ${T(rt[0].side)} بتقييم ${rt[0].rating.toFixed(1)}${rt[0].st.totalGoals ? `، وسجّل ${rt[0].st.totalGoals}` : ''}.`, rt[1] ? `وبعده ${X().nmAr(ctx, rt[1].name, rt[1].side)} بتقييم ${rt[1].rating.toFixed(1)}.` : ''], null, `<ol class="tx-keys">${rt.map(r => `<li style="--tc:${ctx.c[r.side]}">${esc(X().nmAr(ctx, r.name, r.side))} · ${r.rating.toFixed(1)}</li>`).join('')}</ol>`);
    }
    // cards
    if (has(qn, ['بطاقه', 'طرد', 'حمراء', 'صفراء', 'انذار'])) {
      const cs = X().events(sum).filter(e => /card/.test(e.tt) && e.side);
      if (!cs.length) return scene(ctx, question, ['ما كو بطاقات لحد هسه.']);
      const red = cs.filter(e => /red/.test(e.tt));
      return scene(ctx, question, [`انطت ${cs.length} ${cs.length === 1 ? 'بطاقة' : 'بطاقات'}: ${cs.filter(e => e.side === 'home').length} لـ${T('home')} و${cs.filter(e => e.side === 'away').length} لـ${T('away')}.`, red.length ? `والأهم الطرد: ${red.map(e => `${X().nmAr(ctx, e.who[0], e.side)} من ${T(e.side)} بالدقيقة ${Math.floor(e.m)}`).join('، و')}.` : 'وما كو طرد.'], [{ l: 'صفراء', h: cs.filter(e => e.side === 'home' && /yellow/.test(e.tt)).length, a: cs.filter(e => e.side === 'away' && /yellow/.test(e.tt)).length }, { l: 'حمراء', h: red.filter(e => e.side === 'home').length, a: red.filter(e => e.side === 'away').length }]);
    }
    // subs
    if (has(qn, ['تبديل', 'بديل', 'تغيير', 'دخل'])) { const d = X().deepScenes(ctx).find(s => /التبديلات/.test(s.t)); if (d) return { ...d, t: 'سؤالك للمحلل' }; }
    // set pieces
    if (has(qn, ['ركنيه', 'ركلات', 'ثابت', 'ضربه حره', 'جزاء'])) { const d = X().deepScenes(ctx).find(s => /الثابتة/.test(s.t)); if (d) return { ...d, t: 'سؤالك للمحلل' }; }
    // shots / chances
    if (has(qn, ['فرص', 'فرصه', 'تسديد', 'سدد', 'خطوره'])) { const d = X().deepScenes(ctx).find(s => /التسديد/.test(s.t)); if (d) return { ...d, t: 'سؤالك للمحلل' }; }
    // pressing / defence
    if (has(qn, ['ضغط', 'دفاع', 'دافع'])) { const d = X().deepScenes(ctx).find(s => /الضغط/.test(s.t)); if (d) return { ...d, t: 'سؤالك للمحلل' }; }
    if (has(qn, ['اطراف', 'عرضي', 'جناح', 'عمق'])) { const d = X().deepScenes(ctx).find(s => /الأطراف/.test(s.t)); if (d) return { ...d, t: 'سؤالك للمحلل' }; }
    // tactics in general
    if (has(qn, ['تكتيك', 'خطه', 'تشكيل', 'اسلوب', 'يلعب', 'لعبو', 'لعبوا', 'هجوم', 'بناء'])) {
      const d = X().deepScenes(ctx); const k = d.find(s => /الخلاصة|مفتاح/.test(s.t)) || d[0];
      if (k) return { ...k, t: 'سؤالك للمحلل' };
    }
    // fallback: summary
    const A = pre ? null : ai.analyze(sum);
    return scene(ctx, question, [`ما فهمت السؤال بالضبط، بس هذا الملخص:`, A ? A.story[0].text : (P ? `أتوقع ${P.pick === 'draw' ? 'التعادل' : 'فوز ' + T(P.pick)} بنسبة ${pc(P.fin[P.pick])} بالمية.` : ''), 'جرّب تسأل: ليش خسر الفريق السيطرة؟ شنو صار بالدقيقة 35؟ شلون انسجل الهدف؟ شلون حسبت التوقع؟']);
  }

  function suggestions(ctx) {
    const { ev, mode } = ctx; const T = s => AR(ev[s].name);
    if (mode === 'pre') return ['شلون حسبت التوقع؟', `شلون يلعب ${T('home')}؟`, `شلون يلعب ${T('away')}؟`, 'شنو مفتاح المواجهة؟'];
    const sh = X().share(X().events(ctx.sum), 0, 200); const weak = sh.home < sh.away ? 'home' : 'away';
    const res = ev.home.score > ev.away.score ? 'home' : ev.away.score > ev.home.score ? 'away' : null;
    const out = [`ليش ${T(weak)} خسر السيطرة؟`, 'شنو صار بالدقيقة 35؟'];
    if ((ev.home.score || 0) + (ev.away.score || 0) > 0) out.push('شلون انسجل الهدف الأول؟');
    if (res && mode === 'post') out.push(`ليش فاز ${T(res)}؟`);
    out.push('منو أفضل لاعب؟', 'شلون حسبت التوقع؟', 'شنو تأثير التبديلات؟');
    return out;
  }
  YH.qa = { ask, suggestions, norm };
})();
