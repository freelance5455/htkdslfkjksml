'use strict';
/* =====================================================================
   WeaponController
   ---------------------------------------------------------------------
   Player ki firing ka single entry point: WeaponController.fire(player)
   Hathiyaar ka base data (WP[...] in data.js) rehta hai; yahan uske upar
   multipliers / recoil / feedback lagta hai. Sab kuch `cfg` se tune hota hai.

   Har shot par:  bullet(s)  +  muzzle flash  +  sound  +  recoil (spread heat, gun kick, camera kick)
   ===================================================================== */
const WeaponController={
  /* ---------- tuning (public) ---------- */
  cfg:{
    fireRateMul:1,            // 1 = hathiyaar ka normal rate | 1.5 = 50% tez | .5 = aadha
    spreadMul:1,              // base bullet spread ka multiplier (0 = laser-accurate)
    spreadAddDeg:0,           // har shot ke spread mein flat extra degrees
    // --- recoil ---
    recoilPerShotDeg:.5,      // har shot par "heat": itne degree spread badhta hai
    recoilMaxDeg:5,           // heat ki upar limit
    recoilRecoverDegPerSec:8, // fire rukne par heat itni tezi se utarta hai
    aimKickDeg:.35,           // har shot par gun ka random side-jhatka (degrees)
    camKick:3,                // camera fire ki ulti disha mein itne px dhakelta hai
    classMul:{pistol:.8,smg:.7,ar:1,lmg:1.1,sg:1.8,sn:2.6,xb:1.2},   // hathiyaar-type ke hisaab se recoil
    // --- feedback ---
    muzzleFlash:true,
    flashTime:.07,            // muzzle flash kitni der (sec)
    muzzleSparks:true,        // nali par chhoti chingari
    shotSound:true
  },

  /* ---------- runtime state ---------- */
  heat:0,                      // abhi ka recoil spread (degrees)
  shots:0,
  onShot:[],                   // hooks: WeaponController.onShot.push((p,w)=>{...})

  update(dt){
    if(this.heat>0)this.heat=Math.max(0,this.heat-this.cfg.recoilRecoverDegPerSec*dt);
  },

  reset(){this.heat=0;this.shots=0},

  // current spread (degrees, +- ) — HUD / crosshair ke liye bhi use ho sakta hai
  spreadDeg(p){
    const w=curW(p),c=this.cfg;
    return w.spr*(180/Math.PI)*c.spreadMul+c.spreadAddDeg+this.heat;
  },

  /* Shot chalao. true = goli chali. (cooldown / reload / heal / khaali mag par false) */
  fire(p){
    const s=curS(p);if(!s)return false;
    const c=this.cfg,w=curW(p),RAD=Math.PI/180;
    const ok=shoot(p,{sprMul:c.spreadMul,sprAdd:(c.spreadAddDeg+this.heat)*RAD,noSound:!c.shotSound});
    if(!ok)return false;
    this.shots++;
    p.cd=w.rate/Math.max(.1,c.fireRateMul);              // configurable fire rate
    p.flash=c.muzzleFlash?c.flashTime:0;                 // muzzle flash (draw.js is p.flash ko padhta hai)
    const cm=c.classMul[w.cls]||1,ca=Math.cos(p.ang),sa=Math.sin(p.ang);
    if(c.muzzleSparks)spark(p.x+ca*(w.len||20),p.y+sa*(w.len||20),'#ffd36b',3);
    // --- recoil ---
    this.heat=Math.min(c.recoilMaxDeg,this.heat+c.recoilPerShotDeg*cm);
    p.ang+=(Math.random()*2-1)*c.aimKickDeg*cm*RAD;
    cam.x-=ca*c.camKick*cm;cam.y-=sa*c.camKick*cm;
    for(const f of this.onShot)f(p,w);
    return true;
  }
};
