// ===== CREATURES: an original dragon enemy, a village, and its villagers =====
// No licensed characters anywhere here -- this is all original design.

const VILLAGE_CENTER = { x: 45, z: 45 };
let villagers = [];

function buildDragon(color) {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color, flatShading: true });
  const wingMat = new THREE.MeshStandardMaterial({ color: 0x3a1f4a, flatShading: true, side: THREE.DoubleSide });
  const hornMat = new THREE.MeshStandardMaterial({ color: 0xe8d9a0, flatShading: true });

  const body = new THREE.Mesh(new THREE.SphereGeometry(1.1, 8, 6), bodyMat);
  body.scale.set(1, 0.85, 1.8);
  body.castShadow = true;
  group.add(body);

  const neck = new THREE.Mesh(new THREE.SphereGeometry(0.5, 6, 6), bodyMat);
  neck.scale.set(1, 1, 1.6);
  neck.position.set(0, 0.3, 1.7);
  neck.castShadow = true;
  group.add(neck);

  const head = new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.1, 6), bodyMat);
  head.rotation.x = Math.PI / 2;
  head.position.set(0, 0.45, 2.6);
  head.castShadow = true;
  group.add(head);

  const hornGeo = new THREE.ConeGeometry(0.08, 0.35, 4);
  const hornL = new THREE.Mesh(hornGeo, hornMat);
  hornL.position.set(-0.18, 0.85, 2.3);
  hornL.rotation.x = -0.5;
  const hornR = hornL.clone();
  hornR.position.x = 0.18;
  group.add(hornL, hornR);

  for (let i = 0; i < 4; i++) {
    const scale = 1 - i * 0.2;
    const seg = new THREE.Mesh(new THREE.SphereGeometry(0.35 * scale, 6, 6), bodyMat);
    seg.position.set(0, 0.1, -1.6 - i * 0.55);
    seg.castShadow = true;
    group.add(seg);
  }

  const wingVerts = new Float32Array([0, 0, 0, 2.2, 0.6, -0.3, 1.6, -0.3, 0.8]);
  const wingGeo = new THREE.BufferGeometry();
  wingGeo.setAttribute('position', new THREE.BufferAttribute(wingVerts, 3));
  wingGeo.computeVertexNormals();

  const wingL = new THREE.Mesh(wingGeo, wingMat);
  wingL.position.set(-0.5, 0.5, 0.2);
  wingL.castShadow = true;
  const wingR = new THREE.Mesh(wingGeo.clone(), wingMat);
  wingR.position.set(0.5, 0.5, 0.2);
  wingR.scale.x = -1;
  group.add(wingL, wingR);

  group.userData = { wingL, wingR, flapPhase: Math.random() * Math.PI * 2 };
  return group;
}

const dragon = buildDragon(0x7a2f8a);
dragon.position.set(VILLAGE_CENTER.x, 12, VILLAGE_CENTER.z);
scene.add(dragon);

const dragonState = {
  angle: 0, radius: 22, height: 12, breathTimer: 5,
  hp: 5, maxHp: 5, alive: true, respawnTimer: 0, hitFlash: 0,
};

function updateDragonWings(dt) {
  dragon.userData.flapPhase += dt * 6;
  const flap = Math.sin(dragon.userData.flapPhase) * 0.5;
  dragon.userData.wingL.rotation.z = flap;
  dragon.userData.wingR.rotation.z = -flap;
}

function breatheFireNearVillage() {
  playHit();
  villagers.forEach(v => {
    const d = Math.hypot(v.mesh.position.x - dragon.position.x, v.mesh.position.z - dragon.position.z);
    if (d < 14) v.fleeTimer = 3 + Math.random() * 2;
  });
  const dPlayer = Math.hypot(player.position.x - dragon.position.x, player.position.z - dragon.position.z);
  if (dPlayer < 14 && !inVehicle) playerHp = Math.max(0, playerHp - 5);
}

function updateDragon(dt) {
  if (!dragonState.alive) {
    dragonState.respawnTimer -= dt;
    dragon.visible = false;
    if (dragonState.respawnTimer <= 0) {
      dragonState.alive = true;
      dragonState.hp = dragonState.maxHp;
      dragon.visible = true;
    }
    return;
  }

  dragonState.angle += dt * 0.3;
  dragon.position.x = VILLAGE_CENTER.x + Math.cos(dragonState.angle) * dragonState.radius;
  dragon.position.z = VILLAGE_CENTER.z + Math.sin(dragonState.angle) * dragonState.radius;
  dragon.position.y = dragonState.height + Math.sin(dragonState.angle * 3) * 1.5;
  dragon.rotation.y = dragonState.angle + Math.PI / 2;
  updateDragonWings(dt);

  if (dragonState.hitFlash > 0) {
    dragonState.hitFlash -= dt;
    const s = 1 + Math.sin(dragonState.hitFlash * 20) * 0.1;
    dragon.scale.setScalar(s);
  } else {
    dragon.scale.setScalar(1);
  }

  dragonState.breathTimer -= dt;
  if (dragonState.breathTimer <= 0) {
    dragonState.breathTimer = 6 + Math.random() * 4;
    breatheFireNearVillage();
  }
}

function registerDragonHit() {
  if (!dragonState.alive) return;
  dragonState.hp -= 1;
  dragonState.hitFlash = 0.3;
  playHit();
  if (dragonState.hp <= 0) {
    dragonState.alive = false;
    dragonState.respawnTimer = 45;
  }
}

// ---- Village: a few huts and wandering villagers ----
function buildVillager(seed) {
  const tones = [0xc9a06b, 0x8a6f4a, 0xb08a5a, 0x6f8a5a];
  return buildCharacter(tones[seed % tones.length]);
}

function spawnVillage() {
  const hutRoofMat = new THREE.MeshStandardMaterial({ color: 0x8a4a2f, flatShading: true });
  const hutWallMat = new THREE.MeshStandardMaterial({ color: 0xd8c9a0, flatShading: true });

  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const x = VILLAGE_CENTER.x + Math.cos(angle) * 10;
    const z = VILLAGE_CENTER.z + Math.sin(angle) * 10;
    const y = heightAt(x, z);

    const wall = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.8, 2, 8), hutWallMat);
    wall.position.set(x, y + 1, z);
    wall.castShadow = true;
    wall.receiveShadow = true;
    const roof = new THREE.Mesh(new THREE.ConeGeometry(2.2, 1.6, 8), hutRoofMat);
    roof.position.set(x, y + 2.8, z);
    roof.castShadow = true;
    scene.add(wall, roof);

    const hutBody = new CANNON.Body({ mass: 0, shape: new CANNON.Cylinder(1.8, 1.8, 3, 8) });
    hutBody.position.set(x, y + 1.5, z);
    world.addBody(hutBody);
  }

  for (let i = 0; i < 10; i++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = Math.random() * 8;
    const x = VILLAGE_CENTER.x + Math.cos(angle) * dist;
    const z = VILLAGE_CENTER.z + Math.sin(angle) * dist;
    const v = buildVillager(i);
    v.position.set(x, heightAt(x, z), z);
    v.rotation.y = Math.random() * Math.PI * 2;
    scene.add(v);
    villagers.push({
      mesh: v, wanderAngle: Math.random() * Math.PI * 2, wanderTimer: 0,
      fleeTimer: 0, homeX: x, homeZ: z,
    });
  }
}
spawnVillage();

function updateVillagers(dt) {
  villagers.forEach(v => {
    if (v.fleeTimer > 0) {
      v.fleeTimer -= dt;
      const dx = v.mesh.position.x - dragon.position.x;
      const dz = v.mesh.position.z - dragon.position.z;
      const d = Math.hypot(dx, dz) || 1;
      const nx = v.mesh.position.x + (dx / d) * 4 * dt;
      const nz = v.mesh.position.z + (dz / d) * 4 * dt;
      v.mesh.position.x = nx;
      v.mesh.position.z = nz;
      v.mesh.position.y = heightAt(nx, nz);
      v.mesh.rotation.y = Math.atan2(dx, dz);
    } else {
      v.wanderTimer -= dt;
      if (v.wanderTimer <= 0) {
        v.wanderAngle = Math.random() * Math.PI * 2;
        v.wanderTimer = 2 + Math.random() * 3;
      }
      const nx = v.mesh.position.x + Math.sin(v.wanderAngle) * 0.5 * dt;
      const nz = v.mesh.position.z + Math.cos(v.wanderAngle) * 0.5 * dt;
      if (Math.hypot(nx - v.homeX, nz - v.homeZ) < 9) {
        v.mesh.position.x = nx;
        v.mesh.position.z = nz;
        v.mesh.position.y = heightAt(nx, nz);
        v.mesh.rotation.y = v.wanderAngle;
      }
    }
    v.mesh.userData.moveAmt = v.fleeTimer > 0 ? 1 : 0.3;
    v.mesh.userData.walkPhase = (v.mesh.userData.walkPhase || 0) + dt * (v.fleeTimer > 0 ? 10 : 4);
    const swing = Math.sin(v.mesh.userData.walkPhase) * 0.5;
    v.mesh.userData.legL.rotation.x = swing;
    v.mesh.userData.legR.rotation.x = -swing;
  });
}
