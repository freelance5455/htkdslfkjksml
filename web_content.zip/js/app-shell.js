"use strict";
/* Contractor Pro — app shell (V22)
   Loaded LAST. Wraps a few global functions (route, apply, renderDashboard, renderList, exportData, alert)
   without changing their behaviour, and adds: tab bar, app bar actions, preferences/launcher/quick-add sheets,
   dark mode, Android back-button support (History API), toasts, offline banner, install prompt, update notice,
   first-run welcome, backup reminder, and no-pull-to-refresh guards. */
(function () {
  var root = document.documentElement, doc = document;
  var ua = navigator.userAgent || '';
  var IS_ANDROID = /Android/i.test(ua), IS_IOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  function $(id) { return doc.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { } return null; }
  function lang() { try { return (typeof d !== 'undefined' && d && d.lang) || root.lang || 'en'; } catch (e) { return 'en'; } }

  /* ------------------------------------------------------------------ strings (fallback: English) */
  var S = {
    more: { en: 'More', fa: 'بیشتر', ar: 'المزيد', tr: 'Daha fazla', ru: 'Ещё', fr: 'Plus', de: 'Mehr', es: 'Más', pt: 'Mais', hi: 'और', ur: 'مزید', id: 'Lainnya' },
    quickAdd: { en: 'Quick add', fa: 'افزودن سریع', ar: 'إضافة سريعة', tr: 'Hızlı ekle', ru: 'Быстро добавить', fr: 'Ajout rapide', de: 'Schnell hinzufügen', es: 'Añadir rápido', pt: 'Adicionar rápido', hi: 'त्वरित जोड़ें', ur: 'فوری اضافہ', id: 'Tambah cepat' },
    install: { en: 'Install app', fa: 'نصب برنامه', ar: 'تثبيت التطبيق', tr: 'Uygulamayı yükle', ru: 'Установить приложение', fr: 'Installer l’app', de: 'App installieren', es: 'Instalar la app', pt: 'Instalar o app', hi: 'ऐप इंस्टॉल करें', ur: 'ایپ انسٹال کریں', id: 'Pasang aplikasi' },
    installHint: { en: 'To install: tap Share, then “Add to Home Screen”', fa: 'برای نصب: دکمهٔ اشتراک‌گذاری را بزنید و «افزودن به صفحهٔ اصلی» را انتخاب کنید', ar: 'للتثبيت: اضغط مشاركة ثم «إضافة إلى الشاشة الرئيسية»', tr: 'Yüklemek için Paylaş’a dokunun, ardından “Ana Ekrana Ekle”yi seçin', ru: 'Чтобы установить: нажмите «Поделиться», затем «На экран “Домой”»', fr: 'Pour installer : touchez Partager puis « Sur l’écran d’accueil »', de: 'Zum Installieren: Teilen tippen, dann „Zum Home-Bildschirm“', es: 'Para instalar: toca Compartir y luego «Añadir a pantalla de inicio»', pt: 'Para instalar: toque em Compartilhar e depois em “Adicionar à Tela de Início”', hi: 'इंस्टॉल करने के लिए: शेयर दबाएँ, फिर “होम स्क्रीन पर जोड़ें” चुनें', ur: 'انسٹال کرنے کے لیے: شیئر دبائیں پھر «ہوم اسکرین پر شامل کریں» منتخب کریں', id: 'Untuk memasang: ketuk Bagikan lalu “Tambahkan ke Layar Utama”' },
    appearance: { en: 'Appearance', fa: 'ظاهر', ar: 'المظهر', tr: 'Görünüm', ru: 'Оформление', fr: 'Apparence', de: 'Darstellung', es: 'Apariencia', pt: 'Aparência', hi: 'दिखावट', ur: 'ظاہری شکل', id: 'Tampilan' },
    themeAuto: { en: 'System', fa: 'سیستم', ar: 'النظام', tr: 'Sistem', ru: 'Система', fr: 'Système', de: 'System', es: 'Sistema', pt: 'Sistema', hi: 'सिस्टम', ur: 'سسٹم', id: 'Sistem' },
    light: { en: 'Light', fa: 'روشن', ar: 'فاتح', tr: 'Açık', ru: 'Светлая', fr: 'Clair', de: 'Hell', es: 'Claro', pt: 'Claro', hi: 'लाइट', ur: 'روشن', id: 'Terang' },
    dark: { en: 'Dark', fa: 'تاریک', ar: 'داكن', tr: 'Koyu', ru: 'Тёмная', fr: 'Sombre', de: 'Dunkel', es: 'Oscuro', pt: 'Escuro', hi: 'डार्क', ur: 'گہرا', id: 'Gelap' },
    offline: { en: 'You’re offline. Your work is saved on this device.', fa: 'اتصال اینترنت قطع است. کارهای شما روی همین دستگاه ذخیره می‌شود.', ar: 'لا يوجد اتصال بالإنترنت. يتم حفظ عملك على هذا الجهاز.', tr: 'Çevrimdışısınız. Çalışmanız bu cihazda kaydedilir.', ru: 'Нет подключения. Ваши данные сохраняются на этом устройстве.', fr: 'Vous êtes hors ligne. Votre travail est enregistré sur cet appareil.', de: 'Du bist offline. Deine Arbeit wird auf diesem Gerät gespeichert.', es: 'Sin conexión. Tu trabajo se guarda en este dispositivo.', pt: 'Você está offline. Seu trabalho é salvo neste dispositivo.', hi: 'आप ऑफ़लाइन हैं। आपका काम इसी डिवाइस पर सहेजा जाता है।', ur: 'آپ آف لائن ہیں۔ آپ کا کام اسی ڈیوائس پر محفوظ ہوتا ہے۔', id: 'Anda offline. Pekerjaan disimpan di perangkat ini.' },
    online: { en: 'Back online', fa: 'دوباره آنلاین شدید', ar: 'عاد الاتصال', tr: 'Yeniden çevrimiçi', ru: 'Подключение восстановлено', fr: 'De nouveau en ligne', de: 'Wieder online', es: 'De nuevo en línea', pt: 'De volta online', hi: 'फिर से ऑनलाइन', ur: 'دوبارہ آن لائن', id: 'Kembali online' },
    updated: { en: 'A new version is ready', fa: 'نسخهٔ جدید آماده است', ar: 'إصدار جديد جاهز', tr: 'Yeni sürüm hazır', ru: 'Доступна новая версия', fr: 'Une nouvelle version est prête', de: 'Neue Version bereit', es: 'Hay una nueva versión', pt: 'Nova versão disponível', hi: 'नया संस्करण तैयार है', ur: 'نیا ورژن تیار ہے', id: 'Versi baru siap' },
    reload: { en: 'Reload', fa: 'بارگذاری مجدد', ar: 'إعادة التحميل', tr: 'Yenile', ru: 'Обновить', fr: 'Recharger', de: 'Neu laden', es: 'Recargar', pt: 'Recarregar', hi: 'रीलोड करें', ur: 'دوبارہ لوڈ کریں', id: 'Muat ulang' },
    welcome: { en: 'Welcome to Contractor Pro', fa: 'به Contractor Pro خوش آمدید', ar: 'مرحبًا بك في Contractor Pro', tr: 'Contractor Pro’ya hoş geldiniz', ru: 'Добро пожаловать в Contractor Pro', fr: 'Bienvenue dans Contractor Pro', de: 'Willkommen bei Contractor Pro', es: 'Bienvenido a Contractor Pro', pt: 'Bem-vindo ao Contractor Pro', hi: 'Contractor Pro में आपका स्वागत है', ur: 'Contractor Pro میں خوش آمدید', id: 'Selamat datang di Contractor Pro' },
    welcomeSub: { en: 'Set up in a few seconds', fa: 'در چند ثانیه آماده می‌شوید', ar: 'جاهز خلال ثوانٍ', tr: 'Birkaç saniyede hazır olun', ru: 'Настройка за несколько секунд', fr: 'Configuration en quelques secondes', de: 'In wenigen Sekunden startklar', es: 'Listo en unos segundos', pt: 'Pronto em segundos', hi: 'कुछ ही सेकंड में तैयार', ur: 'چند سیکنڈ میں تیار', id: 'Siap dalam hitungan detik' },
    firstProject: { en: 'Add your first project', fa: 'افزودن اولین پروژه', ar: 'أضف مشروعك الأول', tr: 'İlk projenizi ekleyin', ru: 'Добавьте первый проект', fr: 'Ajoutez votre premier projet', de: 'Erstes Projekt hinzufügen', es: 'Añade tu primer proyecto', pt: 'Adicione sua primeira obra', hi: 'अपना पहला प्रोजेक्ट जोड़ें', ur: 'اپنا پہلا پراجیکٹ شامل کریں', id: 'Tambahkan proyek pertama' },
    skip: { en: 'Skip for now', fa: 'فعلاً رد شو', ar: 'تخطَّ الآن', tr: 'Şimdilik geç', ru: 'Пропустить', fr: 'Passer', de: 'Überspringen', es: 'Omitir', pt: 'Pular', hi: 'अभी छोड़ें', ur: 'ابھی چھوڑ دیں', id: 'Lewati' },
    prefs: { en: 'Language & region', fa: 'زبان و منطقه', ar: 'اللغة والمنطقة', tr: 'Dil ve bölge', ru: 'Язык и регион', fr: 'Langue et région', de: 'Sprache & Region', es: 'Idioma y región', pt: 'Idioma e região', hi: 'भाषा और क्षेत्र', ur: 'زبان اور علاقہ', id: 'Bahasa & wilayah' },
    close: { en: 'Close', fa: 'بستن', ar: 'إغلاق', tr: 'Kapat', ru: 'Закрыть', fr: 'Fermer', de: 'Schließen', es: 'Cerrar', pt: 'Fechar', hi: 'बंद करें', ur: 'بند کریں', id: 'Tutup' },
    backupTitle: { en: 'Back up your data', fa: 'از اطلاعاتتان پشتیبان بگیرید', ar: 'انسخ بياناتك احتياطيًا', tr: 'Verilerinizi yedekleyin', ru: 'Сделайте резервную копию', fr: 'Sauvegardez vos données', de: 'Daten sichern', es: 'Haz una copia de seguridad', pt: 'Faça backup dos seus dados', hi: 'अपने डेटा का बैकअप लें', ur: 'اپنے ڈیٹا کا بیک اپ لیں', id: 'Cadangkan data Anda' },
    backupBody: { en: 'Your data lives on this device. Export a backup so you never lose it.', fa: 'اطلاعات شما روی همین دستگاه ذخیره است. یک فایل پشتیبان بگیرید تا هرگز از دست نرود.', ar: 'بياناتك محفوظة على هذا الجهاز. صدّر نسخة احتياطية حتى لا تفقدها.', tr: 'Verileriniz bu cihazda saklanır. Kaybetmemek için yedek dışa aktarın.', ru: 'Данные хранятся на этом устройстве. Экспортируйте копию, чтобы не потерять их.', fr: 'Vos données sont sur cet appareil. Exportez une sauvegarde pour ne jamais les perdre.', de: 'Deine Daten liegen auf diesem Gerät. Exportiere eine Sicherung, damit nichts verloren geht.', es: 'Tus datos están en este dispositivo. Exporta una copia para no perderlos.', pt: 'Seus dados ficam neste dispositivo. Exporte um backup para não perdê-los.', hi: 'आपका डेटा इसी डिवाइस पर है। खोने से बचने के लिए बैकअप निर्यात करें।', ur: 'آپ کا ڈیٹا اسی ڈیوائس پر ہے۔ ضائع ہونے سے بچنے کے لیے بیک اپ ایکسپورٹ کریں۔', id: 'Data Anda ada di perangkat ini. Ekspor cadangan agar tidak hilang.' },
    backupBtn: { en: 'Export backup', fa: 'دریافت پشتیبان', ar: 'تصدير نسخة احتياطية', tr: 'Yedeği dışa aktar', ru: 'Экспорт копии', fr: 'Exporter', de: 'Sicherung exportieren', es: 'Exportar copia', pt: 'Exportar backup', hi: 'बैकअप निर्यात करें', ur: 'بیک اپ ایکسپورٹ کریں', id: 'Ekspor cadangan' }
  };
  function L(k) { var e = S[k] || {}; return e[lang()] || e.en || k; }
  function T(k, fb) { try { var r = t(k); return r === k && fb ? fb : r; } catch (e) { return fb || k; } }
  function title(id) { try { return titleOf(id); } catch (e) { return id; } }

  // the dashboard references a translation key that was never defined (it showed up raw as "projectProgress")
  try {
    if (typeof I !== 'undefined' && !I.projectProgress) I.projectProgress = { fa: 'پیشرفت پروژه‌ها', en: 'Project progress', ar: 'تقدم المشاريع', tr: 'Proje ilerlemesi', ru: 'Ход проектов', fr: 'Avancement des projets', de: 'Projektfortschritt', es: 'Progreso de proyectos', pt: 'Progresso das obras', hi: 'प्रोजेक्ट प्रगति', ur: 'پراجیکٹ کی پیش رفت', id: 'Kemajuan proyek' };
  } catch (e) { }

  /* ------------------------------------------------------------------ icons (24px, stroke) */
  var P = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
    projects: '<path d="M4 21V5l8-3v19"/><path d="M12 21V9l8 3v9"/><path d="M8 7h.01M8 11h.01M8 15h.01M16 14h.01M16 18h.01"/>',
    clients: '<path d="M16 20v-1.5a3.5 3.5 0 0 0-3.5-3.5h-5A3.5 3.5 0 0 0 4 18.5V20"/><circle cx="10" cy="7.5" r="3.5"/><path d="M20 20v-1.5a3.5 3.5 0 0 0-2.5-3.3"/><path d="M15.5 4.2a3.5 3.5 0 0 1 0 6.6"/>',
    leads: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    estimates: '<rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M8.5 7h7M8.5 11h.01M12 11h.01M15.5 11h.01M8.5 15h.01M12 15h.01M15.5 15h.01"/>',
    contracts: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
    changeOrders: '<path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/>',
    invoices: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h4"/>',
    team: '<path d="M3 18h18"/><path d="M5 18v-3a7 7 0 0 1 14 0v3"/><path d="M10 8V5h4v3"/>',
    timeEntries: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    finance: '<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18"/><path d="M16 15h2"/><path d="M6 6V5a2 2 0 0 1 2-2h8"/>',
    materials: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/><path d="M3 17.5l9 5 9-5" opacity=".5"/>',
    inventory: '<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
    equipment: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
    schedule: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 10h18"/>',
    dailyLogs: '<path d="M9 4h6v3H9z"/><path d="M7 5H6a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1"/><path d="M8 12h8M8 16h5"/>',
    rfis: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.2a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7"/><path d="M12 17h.01"/>',
    submittals: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 14l2 2 4-4"/>',
    punchList: '<rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="M8 12l3 3 5-6"/>',
    safetyForms: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    tenders: '<rect x="3" y="7" width="18" height="13" rx="3"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M3 13h18"/>',
    drawings: '<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z"/><path d="M9 4v14M15 6v14"/>',
    documents: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    accounts: '<path d="M3 10l9-6 9 6"/><path d="M5 10v8M9 10v8M15 10v8M19 10v8M3 21h18"/>',
    suppliers: '<path d="M2 6h11v10H2z"/><path d="M13 9h5l3 3v4h-8"/><circle cx="6.5" cy="18.5" r="1.8"/><circle cx="17.5" cy="18.5" r="1.8"/>',
    notifications: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
    reports: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    smartEstimate: '<path d="M3 17L17 3l4 4L7 21z"/><path d="M7 13l2 2M10 10l2 2M13 7l2 2"/>',
    settings: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
    grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.8"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    download: '<path d="M12 4v11"/><path d="M7.5 11L12 15.5 16.5 11"/><path d="M5 20h14"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    wifiOff: '<path d="M2 8.8a15 15 0 0 1 4-2.4M22 8.8a15 15 0 0 0-8-3.7"/><path d="M5 12.6a10 10 0 0 1 3.5-2M19 12.6a10 10 0 0 0-3.3-1.9"/><path d="M8.5 16.4a5 5 0 0 1 7 0"/><path d="M12 20h.01M3 3l18 18"/>',
    building: '<path d="M4 21V5l8-3v19"/><path d="M12 21V9l8 3v9"/>'
  };
  function ic(name) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + (P[name] || P.grid) + '</svg>'; }

  /* ------------------------------------------------------------------ theme */
  var mq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
  function themePref() { var v = ls('cp_theme'); return v === 'light' || v === 'dark' ? v : 'auto'; }
  function applyTheme() {
    var p = themePref(), dark = p === 'dark' || (p === 'auto' && mq && mq.matches);
    root.setAttribute('data-theme', dark ? 'dark' : 'light');
    var m = doc.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute('content', dark ? '#0a1020' : '#0f172a');
  }
  if (mq && mq.addEventListener) mq.addEventListener('change', applyTheme);
  applyTheme();

  /* ------------------------------------------------------------------ toasts */
  var toastBox;
  function toast(msg, o) {
    o = o || {};
    if (!toastBox) { toastBox = doc.createElement('div'); toastBox.className = 'cp-toasts'; toastBox.setAttribute('role', 'status'); toastBox.setAttribute('aria-live', 'polite'); doc.body.appendChild(toastBox); }
    var el = doc.createElement('div'); el.className = 'cp-toast' + (o.kind ? ' ' + o.kind : '');
    var sp = doc.createElement('span'); sp.textContent = String(msg == null ? '' : msg).slice(0, 400); el.appendChild(sp);
    if (o.action) { var b = doc.createElement('button'); b.type = 'button'; b.textContent = o.action.label; b.onclick = function () { try { o.action.fn(); } finally { el.remove(); } }; el.appendChild(b); }
    toastBox.appendChild(el);
    while (toastBox.children.length > 3) toastBox.firstChild.remove();
    if (o.ms !== 0) setTimeout(function () { if (el.parentNode) el.remove(); }, o.ms || 3600);
    return el;
  }
  window.cpToast = toast;
  // The app used blocking alert() dialogs for plain notices; show them as toasts instead (confirm() stays native).
  window.__nativeAlert = window.alert;
  window.alert = function (m) { toast(m, { ms: 4200 }); };

  /* ------------------------------------------------------------------ sheets */
  function sheetOpen() { return doc.getElementById('cpSheet'); }
  function openSheet(titleText, bodyNode, opts) {
    closeSheet();
    var m = doc.createElement('div'); m.className = 'modal'; m.id = 'cpSheet'; m.style.zIndex = 90;
    var s = doc.createElement('div'); s.className = 'sheet'; s.setAttribute('role', 'dialog'); s.setAttribute('aria-modal', 'true');
    if (titleText) {
      var h = doc.createElement('div'); h.className = 'cp-sheet-title';
      var h3 = doc.createElement('h3'); h3.textContent = titleText; h.appendChild(h3);
      var x = doc.createElement('button'); x.type = 'button'; x.className = 'cp-sheet-close'; x.setAttribute('aria-label', L('close')); x.innerHTML = ic('close'); x.onclick = closeSheet; h.appendChild(x);
      s.appendChild(h);
    }
    s.appendChild(bodyNode); m.appendChild(s);
    m.addEventListener('click', function (e) { if (e.target === m) closeSheet(); });
    doc.body.appendChild(m);
    return m;
  }
  function closeSheet() { var m = sheetOpen(); if (m) { var keep = m.querySelector('.cp-prefs-body'); if (keep) { var tb = keep.querySelector('.toolbar'); if (tb) stash.appendChild(tb); } m.remove(); } }

  // keep the language/country/calendar/currency <select>s (ids used all over the app) in a hidden holder when the sheet is closed
  var stash = doc.createElement('div'); stash.hidden = true; stash.id = 'cpStash';
  (function () { var tb = doc.querySelector('header .toolbar'); doc.body.appendChild(stash); if (tb) stash.appendChild(tb); })();

  function row(icon, label, fn, sub) {
    var b = doc.createElement('button'); b.type = 'button'; b.className = 'cp-sheet-row';
    b.innerHTML = '<span class="ic">' + ic(icon) + '</span><span style="flex:1;min-width:0"></span>';
    var s = b.lastChild; s.textContent = label; if (sub) { var sm = doc.createElement('small'); sm.className = 'muted'; sm.style.display = 'block'; sm.style.fontWeight = '500'; sm.textContent = sub; s.appendChild(sm); }
    b.onclick = fn; return b;
  }

  var deferredInstall = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferredInstall = e; });
  window.addEventListener('appinstalled', function () { deferredInstall = null; closeSheet(); });
  var standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  if (standalone) root.classList.add('cp-standalone');

  function openPrefs() {
    var body = doc.createElement('div'); body.className = 'cp-prefs-body';
    var l1 = doc.createElement('span'); l1.className = 'cp-label'; l1.textContent = L('prefs'); body.appendChild(l1);
    var tb = stash.querySelector('.toolbar'); if (tb) body.appendChild(tb);
    var l2 = doc.createElement('span'); l2.className = 'cp-label'; l2.textContent = L('appearance'); body.appendChild(l2);
    var seg = doc.createElement('div'); seg.className = 'cp-seg';
    [['auto', 'themeAuto'], ['light', 'light'], ['dark', 'dark']].forEach(function (o) {
      var b = doc.createElement('button'); b.type = 'button'; b.textContent = L(o[1]); b.setAttribute('aria-pressed', String(themePref() === o[0]));
      b.onclick = function () { ls('cp_theme', o[0] === 'auto' ? null : o[0]); applyTheme(); [].forEach.call(seg.children, function (c, i) { c.setAttribute('aria-pressed', String(['auto', 'light', 'dark'][i] === o[0])); }); };
      seg.appendChild(b);
    });
    body.appendChild(seg);
    if (!standalone && (deferredInstall || IS_IOS)) {
      var l3 = doc.createElement('span'); l3.className = 'cp-label'; l3.textContent = L('install'); body.appendChild(l3);
      if (deferredInstall) body.appendChild(row('download', L('install'), function () { var e = deferredInstall; deferredInstall = null; e.prompt(); }));
      else { var n = doc.createElement('p'); n.className = 'muted'; n.style.margin = '0'; n.textContent = L('installHint'); body.appendChild(n); }
    }
    var v = doc.createElement('div'); v.className = 'cp-ver'; v.textContent = 'Contractor Pro · v' + (typeof APP_VERSION !== 'undefined' ? APP_VERSION : ''); body.appendChild(v);
    openSheet(L('prefs'), body);
  }

  function openLauncher() {
    var body = doc.createElement('div'); body.className = 'cp-module-columns'; body.style.gridTemplateColumns = '1fr';
    var groups = typeof CP_MODULE_GROUPS !== 'undefined' ? CP_MODULE_GROUPS : [];
    groups.forEach(function (g) {
      var panel = doc.createElement('section'); panel.className = 'cp-module-group'; panel.dataset.g = g.key; panel.style.boxShadow = 'none';
      var h = doc.createElement('h4'); h.textContent = (typeof cpDashText === 'function') ? cpDashText(g.key) : g.key; panel.appendChild(h);
      g.ids.forEach(function (id) {
        var b = doc.createElement('button'); b.type = 'button'; b.className = 'cp-module-key'; b.dataset.mod = id; b.setAttribute('aria-label', title(id));
        b.innerHTML = '<span class="cp-module-icon" aria-hidden="true">' + ic(id) + '</span><span class="cp-module-copy"><strong></strong></span>'; b.querySelector('strong').textContent = title(id);
        b.onclick = function () { closeSheet(); goTab(id); };
        panel.appendChild(b);
      });
      body.appendChild(panel);
    });
    var col = doc.createElement('div'); col.className = 'cp-module-column'; while (body.firstChild) col.appendChild(body.firstChild);
    var wrap = doc.createElement('div'); wrap.appendChild(col);
    openSheet(L('more'), wrap);
  }

  var QUICK = ['projects', 'clients', 'finance', 'invoices', 'estimates', 'dailyLogs', 'timeEntries', 'materials', 'schedule', 'team'];
  function openQuickAdd() {
    var body = doc.createElement('div'); body.className = 'cp-sheet-list';
    var curId = (typeof nav !== 'undefined' && nav.length) ? nav[nav.length - 1] : '';
    var ids = QUICK.slice();
    if (curId && ids.indexOf(curId) > 0) { ids.splice(ids.indexOf(curId), 1); ids.unshift(curId); }
    ids.forEach(function (id) {
      if (typeof F === 'undefined' || !F[id]) return;
      body.appendChild(row(id, T('add', '+') + ' · ' + title(id), function () { closeSheet(); quickAdd(id); }));
    });
    openSheet(L('quickAdd'), body);
  }

  /* ------------------------------------------------------------------ navigation + tab bar */
  var tabbar;
  var TABS = [['home', 'home', 'dashboard'], ['projects', 'projects', 'projects'], ['add', 'plus', null], ['finance', 'finance', 'finance'], ['more', 'grid', null]];
  function tabLabel(k) { return k === 'home' ? T('dashboard', 'Home') : k === 'projects' ? title('projects') : k === 'finance' ? title('finance') : k === 'more' ? L('more') : L('quickAdd'); }
  function buildTabs() {
    if (!tabbar) {
      tabbar = doc.createElement('nav'); tabbar.className = 'cp-tabbar'; tabbar.setAttribute('role', 'navigation');
      TABS.forEach(function (t0) {
        var b = doc.createElement('button'); b.type = 'button'; b.className = 'cp-tab' + (t0[0] === 'add' ? ' add' : ''); b.dataset.tab = t0[0];
        b.innerHTML = (t0[0] === 'add' ? '<i>' + ic(t0[1]) + '</i>' : ic(t0[1])) + '<span></span>';
        b.addEventListener('click', function () { try { if (navigator.vibrate) navigator.vibrate(6); } catch (e) { } onTab(t0[0], t0[2]); });
        tabbar.appendChild(b);
      });
      doc.body.appendChild(tabbar);
    }
    [].forEach.call(tabbar.children, function (b) { var l = tabLabel(b.dataset.tab); b.querySelector('span').textContent = l; b.setAttribute('aria-label', l); });
    markTab();
  }
  function onTab(key, id) {
    if (key === 'add') return openQuickAdd();
    if (key === 'more') return openLauncher();
    closeSheet(); goTab(id);
  }
  function goTab(id) {
    if (typeof nav === 'undefined') return;
    if (id === 'dashboard') nav.splice(0, nav.length, 'dashboard');
    else nav.splice(0, nav.length, 'dashboard', id);
    closeFormSafe();
    route(nav[nav.length - 1]);
  }
  function closeFormSafe() { try { if (typeof closeForm === 'function') closeForm(); } catch (e) { } }
  function markTab() {
    if (!tabbar || typeof nav === 'undefined') return;
    var c = nav[nav.length - 1] || 'dashboard', key = 'more';
    if (c === 'dashboard') key = 'home'; else if (c === 'projects' || String(c).indexOf('project:') === 0) key = 'projects'; else if (c === 'finance') key = 'finance';
    [].forEach.call(tabbar.children, function (b) { if (b.dataset.tab === key) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
    if (tabbar.querySelector('.add')) tabbar.querySelector('.add').setAttribute('aria-expanded', String(!!sheetOpen()));
  }

  /* ------------------------------------------------------------------ Android back button / browser history */
  var depth = 1, skip = 0, popping = false, historyReady = false;
  function openModalEl() { return sheetOpen() || doc.getElementById('modal') || doc.querySelector('.modal:not(#cp20Gate)'); }
  function syncHistory() {
    if (!historyReady || typeof nav === 'undefined') return;
    var n = nav.length;
    if (popping) { depth = n; return; }
    try {
      if (n > depth) { for (var i = depth + 1; i <= n; i++) history.pushState({ d: i }, ''); }
      else if (n < depth) { skip++; history.go(n - depth); }
      else history.replaceState({ d: n }, '');
    } catch (e) { }
    depth = n;
  }
  function initHistory() {
    try {
      history.replaceState({ base: 1 }, '');
      history.pushState({ d: 1 }, '');
      historyReady = true; depth = 1;
    } catch (e) { historyReady = false; }
    window.addEventListener('popstate', function (e) {
      if (skip > 0) { skip--; return; }
      var st = e.state || {};
      if (doc.getElementById('cp20Gate')) { try { history.pushState({ d: depth }, ''); } catch (x) { } return; }
      var m = openModalEl();
      if (m) {
        if (m.id === 'modal') closeFormSafe(); else if (m.id === 'cpSheet') closeSheet(); else m.remove();
        try { history.pushState({ d: depth }, ''); } catch (x) { }
        return;
      }
      if (st.base) { // at the very first screen: let the app (or WebView) close
        skip++; try { history.back(); } catch (x) { } return;
      }
      var s = st.d || 1;
      if (s < nav.length) {
        popping = true;
        try { while (nav.length > s) nav.pop(); window.route(nav[nav.length - 1]); } finally { popping = false; }
        depth = nav.length;
      } else if (s > nav.length) { try { history.replaceState({ d: nav.length }, ''); } catch (x) { } depth = nav.length; }
    });
  }
  (function wrapRoute() {
    var _route = window.route; if (typeof _route !== 'function') return;
    window.route = function () { var r = _route.apply(this, arguments); try { syncHistory(); markTab(); } catch (e) { } return r; };
  })();

  /* ------------------------------------------------------------------ dashboard + list enhancements */
  function ensureHello() {
    var dash = $('dashboard'); if (!dash) return;
    var hello = $('cpHello');
    if (!hello) { hello = doc.createElement('div'); hello.id = 'cpHello'; hello.className = 'cp-hello'; dash.insertBefore(hello, dash.firstChild); }
    var name = (typeof d !== 'undefined' && d.companyName) || '';
    var dt = ''; try { dt = fmtDate(new Date().toISOString()); } catch (e) { }
    hello.innerHTML = '<div><h1></h1><p></p></div>';
    hello.querySelector('h1').textContent = name || T('dashboard', 'Dashboard');
    hello.querySelector('p').textContent = dt;
  }
  function ensureQuick() {
    var dash = $('dashboard'); if (!dash) return;
    var q = $('cpQuick');
    if (!q) { q = doc.createElement('div'); q.id = 'cpQuick'; q.className = 'cp-quick'; var grid = dash.querySelector(':scope > .grid'); if (grid) grid.after(q); else dash.appendChild(q); }
    q.textContent = '';
    ['projects', 'clients', 'finance', 'invoices', 'dailyLogs', 'timeEntries'].forEach(function (id) {
      if (typeof F === 'undefined' || !F[id]) return;
      var b = doc.createElement('button'); b.type = 'button'; b.innerHTML = ic('plus') + '<span></span>'; b.lastChild.textContent = title(id);
      b.onclick = function () { quickAdd(id); }; q.appendChild(b);
    });
  }
  function recordCount() { try { return ['projects', 'clients', 'finance', 'invoices', 'estimates', 'contracts', 'schedule'].reduce(function (n, k) { return n + ((d[k] || []).length); }, 0); } catch (e) { return 0; } }
  function ensureBackupBanner() {
    var old = $('cpBackup'); if (old) old.remove();
    var last = Number(ls('cp_last_backup') || 0), snooze = Number(ls('cp_backup_snooze') || 0), now = Date.now();
    if (recordCount() < 3 || now < snooze || (last && now - last < 14 * 86400000)) return;
    var q = $('cpQuick'); if (!q) return;
    var b = doc.createElement('div'); b.id = 'cpBackup'; b.className = 'cp-backup';
    b.innerHTML = '<div><strong></strong><div class="muted" style="font-size:12px;margin-top:2px"></div></div><div style="display:flex;gap:6px;align-items:center"><button class="btn" type="button"></button><button class="x" type="button" aria-label="x">✕</button></div>';
    b.querySelector('strong').textContent = L('backupTitle'); b.querySelector('.muted').textContent = L('backupBody'); b.querySelector('.btn').textContent = L('backupBtn');
    b.querySelector('.btn').onclick = function () { try { exportData(); } catch (e) { } b.remove(); };
    b.querySelector('.x').onclick = function () { ls('cp_backup_snooze', String(Date.now() + 7 * 86400000)); b.remove(); };
    q.after(b);
  }
  function decorateTiles() {
    [].forEach.call(doc.querySelectorAll('.cp-module-key[data-mod]'), function (k) { var i = k.querySelector('.cp-module-icon'); if (i && !i.dataset.svg) { i.innerHTML = ic(k.dataset.mod); i.dataset.svg = '1'; } });
  }
  function enhanceDashboard() { try { ensureHello(); ensureQuick(); ensureBackupBanner(); decorateTiles(); } catch (e) { if (window.console) console.warn('shell dashboard', e); } }
  (function wrapDashboard() {
    var _rd = window.renderDashboard; if (typeof _rd !== 'function') return;
    window.renderDashboard = function () { var r = _rd.apply(this, arguments); enhanceDashboard(); return r; };
  })();
  (function wrapList() {
    var _rl = window.renderList; if (typeof _rl !== 'function') return;
    window.renderList = function (id) {
      var r = _rl.apply(this, arguments);
      try {
        var box = $('records'), e = box && box.querySelector(':scope > .empty');
        if (e && !e.dataset.cta) {
          e.dataset.cta = '1';
          var txt = e.textContent; e.textContent = '';
          var i = doc.createElement('div'); i.className = 'cp-empty-ic'; i.innerHTML = ic(id); e.appendChild(i);
          var p = doc.createElement('div'); p.textContent = txt; e.appendChild(p);
          if (typeof F !== 'undefined' && F[id] && typeof openForm === 'function' && (id !== 'smartEstimate')) {
            var b = doc.createElement('button'); b.type = 'button'; b.className = 'btn'; b.textContent = '+ ' + T('add', 'Add'); b.onclick = function () { openForm(id); }; e.appendChild(b);
          }
        }
      } catch (x) { }
      return r;
    };
  })();
  (function wrapExport() {
    var _ex = window.exportData; if (typeof _ex !== 'function') return;
    window.exportData = function () { var r = _ex.apply(this, arguments); ls('cp_last_backup', String(Date.now())); return r; };
  })();
  (function wrapApply() {
    var _ap = window.apply; if (typeof _ap !== 'function') return;
    window.apply = function () { var r = _ap.apply(this, arguments); try { buildTabs(); buildAppbar(); if ($('dashboard') && $('dashboard').classList.contains('active')) enhanceDashboard(); } catch (e) { } return r; };
  })();

  /* ------------------------------------------------------------------ app bar */
  function buildAppbar() {
    var top = doc.querySelector('header .top'); if (!top) return;
    var box = top.querySelector('.cp-appbar-actions');
    if (!box) {
      box = doc.createElement('div'); box.className = 'cp-appbar-actions';
      var s = doc.createElement('button'); s.type = 'button'; s.className = 'cp-iconbtn'; s.dataset.act = 'search'; s.innerHTML = ic('search');
      s.onclick = function () { goTab('dashboard'); setTimeout(function () { var g = $('globalSearch'); if (g) { g.scrollIntoView({ block: 'center' }); g.focus(); } }, 60); };
      var m = doc.createElement('button'); m.type = 'button'; m.className = 'cp-iconbtn'; m.dataset.act = 'prefs'; m.innerHTML = ic('sliders'); m.onclick = openPrefs;
      box.appendChild(s); box.appendChild(m); top.appendChild(box);
      var clock = $('clock'); if (clock) clock.style.marginInlineStart = 'auto';
    }
    var sb = box.querySelector('[data-act=search]'), pb = box.querySelector('[data-act=prefs]');
    if (sb) { sb.setAttribute('aria-label', T('search', 'Search')); } if (pb) { pb.setAttribute('aria-label', L('prefs')); }
  }

  /* ------------------------------------------------------------------ connectivity + updates */
  var offBar;
  function setOffline(off, silent) {
    if (!offBar) { offBar = doc.createElement('div'); offBar.className = 'cp-offline'; offBar.setAttribute('role', 'status'); doc.body.appendChild(offBar); }
    offBar.textContent = L('offline'); offBar.classList.toggle('show', !!off);
    if (!off && !silent) toast(L('online'), { kind: 'ok', ms: 2200 });
  }
  window.addEventListener('offline', function () { setOffline(true); });
  window.addEventListener('online', function () { setOffline(false); });
  if (navigator.onLine === false) setOffline(true, true);

  if ('serviceWorker' in navigator) {
    var hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!hadController) { hadController = true; return; }
      toast(L('updated'), { ms: 0, action: { label: L('reload'), fn: function () { location.reload(); } } });
    });
  }

  /* ------------------------------------------------------------------ no pull-to-refresh / no scroll-0 on Android WebView wrappers */
  (function noPullToRefresh() {
    if (!IS_ANDROID) return;
    // Some "HTML to APK" wrappers put the WebView inside a SwipeRefreshLayout that refreshes when the WebView is
    // scrolled to y=0. Keeping the page 1px below the top means it never reports "at top". The 2px of extra body
    // height (app-shell.css) guarantees there is room to do so. Invisible to the user.
    function nudge() { if ((window.pageYOffset || 0) < 1 && root.scrollHeight > window.innerHeight + 1) window.scrollTo(0, 1); }
    window.addEventListener('scroll', function () { if ((window.pageYOffset || 0) < 1) nudge(); }, { passive: true });
    window.addEventListener('load', function () { setTimeout(nudge, 50); });
    window.addEventListener('resize', nudge);
  })();

  // body scroll lock while any sheet/modal is open
  new MutationObserver(function () { doc.body.classList.toggle('cp-lock', !!doc.querySelector('.modal')); markTab(); }).observe(doc.body, { childList: true });
  doc.addEventListener('keydown', function (e) { if (e.key === 'Escape' && sheetOpen()) closeSheet(); });

  /* ------------------------------------------------------------------ first-run welcome */
  function needsWelcome() {
    try { return !ls('cp_onboarded') && !d.companyName && !(d.projects || []).length && !(d.clients || []).length; } catch (e) { return false; }
  }
  function showWelcome() {
    var body = doc.createElement('div'); body.className = 'cp-welcome';
    var languages = [].map.call($('lang').options, function (o) { return [o.value, o.textContent]; });
    body.innerHTML = '<div class="logo">' + ic('building') + '</div><h2></h2><p></p>' +
      '<div class="field"><label for="cpWLang"></label><select id="cpWLang"></select></div>' +
      '<div class="field"><label for="cpWName"></label><input id="cpWName" autocomplete="organization" maxlength="120"></div>' +
      '<button type="button" class="btn" id="cpWGo"></button><button type="button" class="btn skip" id="cpWSkip"></button>';
    body.querySelector('h2').textContent = L('welcome'); body.querySelector('p').textContent = L('welcomeSub');
    body.querySelector('label[for=cpWLang]').textContent = T('lang', 'Language'); body.querySelector('label[for=cpWName]').textContent = T('companyName', 'Company');
    var sel = body.querySelector('#cpWLang'); languages.forEach(function (l) { var o = doc.createElement('option'); o.value = l[0]; o.textContent = l[1]; sel.appendChild(o); }); sel.value = lang();
    body.querySelector('#cpWGo').textContent = L('firstProject'); body.querySelector('#cpWSkip').textContent = L('skip');
    function finish(addProject) {
      var nm = body.querySelector('#cpWName').value.trim().slice(0, 120);
      if (nm) { d.companyName = nm; try { persist(); } catch (e) { } }
      ls('cp_onboarded', '1'); closeSheet(); enhanceDashboard();
      if (addProject) quickAdd('projects');
    }
    sel.onchange = function () { var nm = body.querySelector('#cpWName').value; try { onLanguageChange(sel.value); } catch (e) { } closeSheet(); showWelcome(); var n2 = $('cpWName'); if (n2) n2.value = nm; };
    body.querySelector('#cpWGo').onclick = function () { finish(true); }; body.querySelector('#cpWSkip').onclick = function () { finish(false); };
    var m = openSheet('', body);
    m.addEventListener('click', function (e) { if (e.target === m) ls('cp_onboarded', '1'); });
  }
  function maybeWelcome() {
    if (!needsWelcome()) return;
    var tries = 0;
    (function wait() {
      if (doc.getElementById('cp20Gate') || doc.getElementById('contractorSplash')) { if (++tries < 120) return setTimeout(wait, 500); return; }
      if (needsWelcome()) showWelcome();
    })();
  }

  /* ------------------------------------------------------------------ deep links (manifest shortcuts: ?go=projects) */
  function deepLink() {
    try {
      var go = new URLSearchParams(location.search).get('go');
      if (go && typeof F !== 'undefined' && (F[go] || go === 'settings' || go === 'reports')) { goTab(go); history.replaceState({ d: nav.length }, '', location.pathname); }
    } catch (e) { }
  }

  /* ------------------------------------------------------------------ init */
  try { apply(); } catch (e) { }
  buildAppbar(); buildTabs(); initHistory(); enhanceDashboard();
  deepLink(); maybeWelcome();
  window.cpShell = { toast: toast, openPrefs: openPrefs, openLauncher: openLauncher, openQuickAdd: openQuickAdd, goTab: goTab, icon: ic };
})();
