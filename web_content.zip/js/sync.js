window.WS_SYNC={busy:false,lastSuccess:0,lastError:null};
async function sb(){return window.WS_SUPABASE_READY?await window.WS_SUPABASE_READY:null}
const SYNC_MAP={profiles:'profiles',operations:'operations',operationChangeRequests:'operation_change_requests',stock:'stock_items',stockMovements:'stock_movements',services:'services',tasks:'tasks',cashSessions:'cash_sessions',cashMovements:'cash_movements',cashHandovers:'cash_handovers',notifications:'notifications',audit:'audit_logs'};
function iso(v){return new Date(v||Date.now()).toISOString()}
function mapEntity(store,o){
 if(store==='profiles') return {...o};
 if(store==='operations') return {...o,id:o.id,agent_id:o.agentId||null,agent:o.agent||'',unit_price:Number(o.unitPrice||0),created_at:iso(o.createdAt),updated_at:iso(o.updatedAt||o.createdAt),deleted:!!o.deleted};
 if(store==='operationChangeRequests') return {...o,id:o.id,operation_id:o.operationId,requested_by:o.requestedBy,reviewed_by:o.reviewedBy||null,reviewed_at:o.reviewedAt?iso(o.reviewedAt):null,created_at:iso(o.createdAt),updated_at:iso(o.updatedAt||o.createdAt)};
 if(store==='stock') return {...o,id:o.id,created_at:iso(o.createdAt),updated_at:iso(o.updatedAt||o.createdAt)};
 if(store==='stockMovements') return {...o,id:o.id,stock_id:o.stockId,agent_id:o.agentId||null,created_at:iso(o.createdAt)};
 if(store==='cashSessions') return {...o,id:o.id,agent_id:o.agentId||null,opened_at:iso(o.openedAt),closed_at:o.closedAt?iso(o.closedAt):null,closed_by:o.closedBy||null,status:o.status||'open',created_at:iso(o.createdAt||o.openedAt),updated_at:iso(o.updatedAt||o.createdAt||o.openedAt)};
 if(store==='cashMovements') return {...o,id:o.id,session_id:o.sessionId,operation_id:o.operationId||null,agent_id:o.agentId||null,created_at:iso(o.createdAt)};
 if(store==='cashHandovers') return {...o,id:o.id,week_start:o.weekStart,week_end:o.weekEnd,amount_expected:Number(o.amountExpected||0),amount_handed:o.amountHanded==null?null:Number(o.amountHanded),difference:o.difference==null?null:Number(o.difference),handed_over_by:o.handedOverBy||null,handed_over_by_name:o.handedOverByName||'',handed_over_at:o.handedOverAt?iso(o.handedOverAt):null,validated_by:o.validatedBy||null,validated_at:o.validatedAt?iso(o.validatedAt):null,status:o.status||'pending',note:o.note||'',created_at:iso(o.createdAt),updated_at:iso(o.updatedAt||o.createdAt)};
 if(store==='audit') return {...o,id:o.id,user_id:o.userId||null,action:o.action,metadata:o.metadata||{},device_id:o.deviceId||null,created_at:iso(o.createdAt)};
 if(store==='notifications') return {...o,id:o.id,created_at:iso(o.createdAt)};
 return {...o,id:o.id,created_at:iso(o.createdAt),updated_at:iso(o.updatedAt||o.createdAt)};
}
function mapRemote(store,r){
 if(store==='profiles') return {...r,synced:true};
 if(store==='operations') return {...r,agentId:r.agent_id,unitPrice:Number(r.unit_price||0),createdAt:new Date(r.created_at||r.date).getTime(),updatedAt:new Date(r.updated_at||r.created_at||r.date).getTime(),synced:true};
 if(store==='operationChangeRequests') return {...r,operationId:r.operation_id,requestedBy:r.requested_by,reviewedBy:r.reviewed_by,reviewedAt:r.reviewed_at?new Date(r.reviewed_at).getTime():null,createdAt:new Date(r.created_at).getTime(),updatedAt:new Date(r.updated_at||r.created_at).getTime(),synced:true};
 if(store==='stock') return {...r,createdAt:new Date(r.created_at).getTime(),updatedAt:new Date(r.updated_at||r.created_at).getTime(),synced:true};
 if(store==='stockMovements') return {...r,stockId:r.stock_id,agentId:r.agent_id,createdAt:new Date(r.created_at).getTime(),synced:true};
 if(store==='cashSessions') return {...r,agentId:r.agent_id,openedAt:new Date(r.opened_at).getTime(),closedAt:r.closed_at?new Date(r.closed_at).getTime():null,closedBy:r.closed_by,status:r.status||'open',createdAt:new Date(r.created_at).getTime(),updatedAt:new Date(r.updated_at||r.created_at).getTime(),synced:true};
 if(store==='cashMovements') return {...r,sessionId:r.session_id,operationId:r.operation_id,agentId:r.agent_id,createdAt:new Date(r.created_at).getTime(),synced:true};
 if(store==='cashHandovers') return {...r,weekStart:r.week_start,weekEnd:r.week_end,amountExpected:Number(r.amount_expected||0),amountHanded:r.amount_handed==null?null:Number(r.amount_handed),difference:r.difference==null?null:Number(r.difference),handedOverBy:r.handed_over_by,handedOverByName:r.handed_over_by_name,handedOverAt:r.handed_over_at?new Date(r.handed_over_at).getTime():null,validatedBy:r.validated_by,validatedAt:r.validated_at?new Date(r.validated_at).getTime():null,status:r.status,note:r.note,createdAt:new Date(r.created_at).getTime(),updatedAt:new Date(r.updated_at||r.created_at).getTime(),synced:true};
 if(store==='audit') return {...r,userId:r.user_id,deviceId:r.device_id,createdAt:new Date(r.created_at).getTime(),synced:true};
 if(store==='notifications') return {...r,createdAt:new Date(r.created_at).getTime(),synced:true};
 return {...r,createdAt:new Date(r.created_at).getTime(),updatedAt:new Date(r.updated_at||r.created_at).getTime(),synced:true};
}
async function markState(patch){try{await dbPut('syncState','global',{id:'global',...patch})}catch(_) {}}
async function recordConflict(entity,entityId,local,remote,reason='remote-newer'){
 const x={id:WS.uid('CF'),entity,entityId,reason,userId:null,localUpdatedAt:local?.updatedAt||local?.createdAt||null,remoteUpdatedAt:remote?.updatedAt||remote?.createdAt||null,createdAt:Date.now(),resolved:'remote-won'};
 try{await dbPut('syncConflicts',x)}catch(_){}
}
async function pushQueue(c){
 const queue=(await dbAll('syncQueue')).sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));let failures=0;
 for(const item of queue){
  const table=SYNC_MAP[item.entity];if(!table)continue;
  if(item.action==='delete'){
   const {error}=await c.from(table).delete().eq('id',item.entityId);
   if(error){failures++;console.warn('sync delete',item.entity,error.message);continue}
   await dbDelete('syncQueue',item.id);continue
  }
  const local=await dbGet(item.entity,item.entityId);if(!local){await dbDelete('syncQueue',item.id);continue}
  const payload=mapEntity(item.entity,local);
  let remote=null;
  const lookup=await c.from(table).select('*').eq('id',item.entityId).maybeSingle();
  if(lookup.error){failures++;console.warn('sync lookup',table,lookup.error.message);continue}
  if(lookup.data)remote=mapRemote(item.entity,lookup.data);
  const lt=Number(local.updatedAt||local.createdAt||0),rt=Number(remote?.updatedAt||remote?.createdAt||0);
  if(remote&&rt>lt){await recordConflict(item.entity,item.entityId,local,remote);await dbPut(item.entity,remote);await dbDelete('syncQueue',item.id);continue}
  const {error}=await c.from(table).upsert(payload,{onConflict:'id'});
  if(error){failures++;console.warn('sync push',item.entity,error.message);continue}
  local.synced=true;local.syncError=null;await dbPut(item.entity,local);await dbDelete('syncQueue',item.id)
 }
 return failures
}
async function pullTable(c,store,table){
 let q=c.from(table).select('*');if(['operations','stock','cashSessions','cashHandovers'].includes(store))q=q.order('updated_at',{ascending:true}).limit(5000);else q=q.order('created_at',{ascending:true}).limit(5000);
 const {data,error}=await q;if(error){console.warn('sync pull',table,error.message);return false}
 for(const r of data||[]){const remote=mapRemote(store,r),local=await dbGet(store,r.id);const dirty=!!local&&!local.synced;const rt=Number(remote.updatedAt||remote.createdAt||0),lt=Number(local?.updatedAt||local?.createdAt||0);
  if(!local||(!dirty&&rt>=lt)){await dbPut(store,remote);if(store==='profiles')await cacheProfile(remote)}
  else if(dirty&&rt>lt){await recordConflict(store,r.id,local,remote);await dbPut(store,remote)}
 }
 return true
}
async function heartbeat(c,user){
 const id=localStorage.getItem('ws_device_id')||WS.uid('DEV');localStorage.setItem('ws_device_id',id);
 const row={id,user_id:user.id,device_name:navigator.userAgent.slice(0,80),last_seen_at:new Date().toISOString(),app_version:'V12'};
 try{await c.from('sync_devices').upsert(row,{onConflict:'id'})}catch(_){}
}
async function syncNow(silent=false){
 if(WS_SYNC.busy||!navigator.onLine||!window.WS_SUPABASE_READY)return false;const c=await sb();if(!c)return false;WS_SYNC.busy=true;
 try{const {data:{user}}=await c.auth.getUser();if(!user)return false;await heartbeat(c,user);const failures=await pushQueue(c);if(failures){WS_SYNC.lastError='Certaines données restent en attente.';await markState({status:'partial',lastAttempt:Date.now(),pending:true});if(!silent)WS.toast('Synchronisation partielle : nouvelle tentative automatique.');return false}
  let ok=true;for(const [store,table] of Object.entries(SYNC_MAP)){if(store==='audit' && (await getProfileById(user.id))?.role!=='Développeur')continue;if(!(await pullTable(c,store,table)))ok=false}
  WS_SYNC.lastSuccess=Date.now();WS_SYNC.lastError=ok?null:'Certaines données cloud n’ont pas pu être récupérées.';await markState({status:ok?'online':'partial',lastSuccess:Date.now(),pending:false});window.dispatchEvent(new CustomEvent('ws:synced',{detail:{ok}}));if(!silent)WS.toast(ok?'Synchronisation terminée.':'Synchronisation partielle.');return ok;
 }catch(e){WS_SYNC.lastError=e?.message||'Erreur de synchronisation';await markState({status:'error',lastAttempt:Date.now(),pending:true});console.error(e);if(!silent)WS.toast('Synchronisation impossible, nouvelle tentative automatique.');return false}
 finally{WS_SYNC.busy=false}
}
async function queueSync(entity,entityId,action='upsert'){
 const existing=(await dbAll('syncQueue')).find(x=>x.entity===entity&&x.entityId===entityId);
 if(existing){existing.action=action;existing.createdAt=Math.min(existing.createdAt||Date.now(),Date.now());return dbPut('syncQueue',existing)}
 return dbPut('syncQueue',{id:WS.uid('SQ'),entity,entityId,action,createdAt:Date.now()})
}
window.addEventListener('online',()=>{document.documentElement.dataset.connection='online';syncNow(true)});window.addEventListener('offline',()=>{document.documentElement.dataset.connection='offline';window.dispatchEvent(new Event('ws:offline'))});setInterval(()=>syncNow(true),30000);window.syncNow=syncNow;window.queueSync=queueSync;
