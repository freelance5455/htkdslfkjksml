/* WONDER SHIFT — synchronisation local-first <-> Supabase
   Couche additive : ne remplace jamais les calculs métier locaux. */
const SYNC_STATUS_KEY='ws_sync_status';
const SYNC_CURSOR_KEY='ws_sync_cursor';
const SYNC_ENDPOINT=(window.WS_CONFIG&&WS_CONFIG.syncEndpoint)||'https://uqkjevqvntihbmsswqvh.supabase.co/functions/v1/wonder-shift-sync';
const SYNC_APP_ID='wonder-shift-sync-v1';
const SYNC_APP_VERSION='LOCAL-11-SYNC';
const SYNC_ENTITIES={
 services:'services',tasks:'tasks',stock:'stock',stockMovements:'stockMovements',stockRules:'stockRules',
 operations:'operations',cashSessions:'cashSessions',cashMovements:'cashMovements',
 notifications:'notifications',changeRequests:'changeRequests',audit:'audit',settings:'settings'
};
function setSyncStatus(status,extra={}){localStorage.setItem(SYNC_STATUS_KEY,JSON.stringify({status,at:Date.now(),...extra}));window.dispatchEvent(new CustomEvent('ws-sync-status',{detail:{status,...extra}}))}
function getSyncStatus(){try{return JSON.parse(localStorage.getItem(SYNC_STATUS_KEY)||'null')}catch{return null}}
function pendingCount(){return dbAll('syncQueue').then(rows=>rows.filter(x=>x.status!=='done').length).catch(()=>0)}
async function syncRequest(body){const r=await fetch(SYNC_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','x-app-id':SYNC_APP_ID},body:JSON.stringify(body)});const data=await r.json().catch(()=>({}));if(!r.ok||data.ok===false)throw new Error(data.error||`HTTP ${r.status}`);return data}
function checksum(obj){try{return btoa(unescape(encodeURIComponent(JSON.stringify(obj))))}catch{return JSON.stringify(obj)}}
function localId(x){return String(x.id)}
function updatedAt(x){return Number(x.updatedAt||x.createdAt||Date.now())}
function sanitize(entity,obj){if(entity==='users')return null;return {...obj}}
async function queueRecord(entity,row,action='upsert'){if(!row?.id)return;const all=await dbAll('syncQueue');const existing=all.find(q=>q.entity===entity&&q.entityId===String(row.id)&&q.status!=='done');if(existing)return;await dbPut('syncQueue',{id:WS.uid('SQ'),entity,entityId:String(row.id),action,createdAt:Date.now(),status:'pending',attempts:0})}
async function collectLocalRecords(){
 const records=[],deviceId=getDeviceId();
 for(const [entity,store] of Object.entries(SYNC_ENTITIES)){
  const rows=await dbAll(store);
  for(const row of rows){
   const payload=sanitize(entity,row);if(!payload)continue;
   const rec={entity_type:entity,local_id:localId(row),device_id:deviceId,payload,version:Number(row.syncVersion||row.version||1),deleted:Boolean(row.deleted||row.status==='deleted'),checksum:checksum(payload),local_updated_at:new Date(updatedAt(row)).toISOString()};
   records.push(rec);
   if(row.synced!==true || updatedAt(row)>Number(row.lastSyncedAt||0))await queueRecord(entity,row,row.deleted?'delete':'upsert');
  }
 }
 return records;
}
async function markQueueDone(entity,localIdValue){const q=await dbAll('syncQueue');for(const x of q.filter(x=>x.entity===entity&&x.entityId===String(localIdValue)&&x.status!=='done')){x.status='done';x.syncedAt=Date.now();await dbPut('syncQueue',x)}}
async function applyRemoteRecords(records){
 let applied=0,conflicts=0;
 for(const r of records||[]){
  const store=SYNC_ENTITIES[r.entity_type];if(!store)continue;
  const payload={...(r.payload||{})};if(!payload.id)payload.id=r.local_id;
  const local=await dbGet(store,payload.id);
  const remoteTime=Date.parse(r.local_updated_at||r.cloud_updated_at||'')||0;
  const localTime=local?updatedAt(local):0;
  if(local && localTime>remoteTime){conflicts++;continue}
  if(local && localTime===remoteTime && r.checksum && checksum(local)!==r.checksum){conflicts++;continue}
  payload.synced=true;payload.lastSyncedAt=Date.now();await dbPut(store,payload);await markQueueDone(r.entity_type,payload.id);applied++;
 }
 await recalcDerived();return {applied,conflicts};
}
async function syncNow(silent=false){
 if(!navigator.onLine){setSyncStatus('offline-local');if(!silent)WS.toast('Hors connexion : les données restent locales.');return false}
 try{
  setSyncStatus('syncing');const deviceId=getDeviceId();
  await syncRequest({action:'register_device',device_id:deviceId,app_version:SYNC_APP_VERSION,platform:navigator.platform||'web',metadata:{userAgent:navigator.userAgent.slice(0,160),language:navigator.language||'fr'}});
  const localRecords=await collectLocalRecords();let pushed=0,conflicts=0;
  for(let i=0;i<localRecords.length;i+=500){const batch=localRecords.slice(i,i+500);const result=await syncRequest({action:'push',records:batch});pushed+=Number(result.accepted||0);conflicts+=Number(result.conflicts||0);for(const r of batch){const store=SYNC_ENTITIES[r.entity_type];const row=await dbGet(store,r.local_id);if(row){row.synced=true;row.lastSyncedAt=Date.now();await dbPut(store,row);await markQueueDone(r.entity_type,r.local_id)}}}
  const since=localStorage.getItem(SYNC_CURSOR_KEY)||null;const pulled=await syncRequest({action:'pull',since,limit:1000});const applied=await applyRemoteRecords(pulled.records||[]);conflicts+=applied.conflicts;
  if(pulled.cursor)localStorage.setItem(SYNC_CURSOR_KEY,pulled.cursor);
  const pending=await pendingCount();setSyncStatus(conflicts?'synced-with-conflicts':'synced',{pushed,pulled:(pulled.records||[]).length,applied:applied.applied,conflicts,pending});
  if(!silent)WS.toast(conflicts?`Synchronisation terminée avec ${conflicts} conflit(s) à examiner.`:`Synchronisation terminée : ${pushed} envoyés, ${(pulled.records||[]).length} reçus.`);
  return true;
 }catch(e){const pending=await pendingCount();setSyncStatus('error',{message:e.message,pending});if(!silent)WS.toast(`Synchronisation échouée : ${e.message}`);return false}
}
async function syncRegisterAll(){try{const records=await collectLocalRecords();return records.length}catch{return 0}}
window.addEventListener('online',()=>{setSyncStatus('online-pending');setTimeout(()=>syncNow(true),500)});
window.addEventListener('offline',()=>setSyncStatus('offline-local'));
window.addEventListener('load',()=>{setTimeout(()=>{if(navigator.onLine)syncNow(true);else setSyncStatus('offline-local')},1200)});
window.syncNow=syncNow;window.getSyncStatus=getSyncStatus;window.pendingSyncCount=pendingCount;window.syncRegisterAll=syncRegisterAll;
async function syncHealth(){return syncRequest({action:'health'})}
async function syncConflicts(limit=50){return syncRequest({action:'conflicts',limit})}
async function resolveSyncConflict(id,resolution){return syncRequest({action:'resolve_conflict',id,resolution})}
window.syncHealth=syncHealth;window.syncConflicts=syncConflicts;window.resolveSyncConflict=resolveSyncConflict;
