/* WONDER SHIFT — synchronisation local-first <-> Supabase */
const SYNC_STATUS_KEY='ws_sync_status';
const SYNC_CURSOR_KEY='ws_sync_cursor';
const SYNC_ENDPOINT='https://uqkjevqvntihbmsswqvh.supabase.co/functions/v1/wonder-shift-sync';
const SYNC_APP_ID='wonder-shift-sync-v1';
const SYNC_ENTITIES={
 services:'services',tasks:'tasks',stock:'stock',stockMovements:'stockMovements',
 operations:'operations',cashSessions:'cashSessions',cashMovements:'cashMovements',
 notifications:'notifications',changeRequests:'changeRequests',audit:'audit',settings:'settings'
};
function setSyncStatus(status,extra={}){localStorage.setItem(SYNC_STATUS_KEY,JSON.stringify({status,at:Date.now(),...extra}))}
function getSyncStatus(){try{return JSON.parse(localStorage.getItem(SYNC_STATUS_KEY)||'null')}catch{return null}}
async function syncRequest(body){const r=await fetch(SYNC_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','x-app-id':SYNC_APP_ID},body:JSON.stringify(body)});const data=await r.json().catch(()=>({}));if(!r.ok||data.ok===false)throw new Error(data.error||`HTTP ${r.status}`);return data}
function checksum(obj){return JSON.stringify(obj)}
function localId(x){return String(x.id)}
function updatedAt(x){return Number(x.updatedAt||x.createdAt||Date.now())}
function sanitize(entity,obj){if(entity==='users')return null;return {...obj}}
async function collectLocalRecords(){const records=[],deviceId=getDeviceId(),now=new Date().toISOString();for(const [entity,store] of Object.entries(SYNC_ENTITIES)){const rows=await dbAll(store);for(const row of rows){const payload=sanitize(entity,row);if(!payload)continue;records.push({entity_type:entity,local_id:localId(row),device_id:deviceId,payload,version:Number(row.clientVersionNumber||row.version||1),deleted:Boolean(row.deleted||row.status==='deleted'),checksum:checksum(payload),local_updated_at:new Date(updatedAt(row)).toISOString()})}}return records}
async function applyRemoteRecords(records){let applied=0;for(const r of records||[]){const store=SYNC_ENTITIES[r.entity_type];if(!store)continue;const payload=r.payload||{};if(!payload.id)payload.id=r.local_id;const local=await dbGet(store,payload.id);const remoteTime=Date.parse(r.local_updated_at||r.cloud_updated_at||'')||0;const localTime=local?updatedAt(local):0;if(local && localTime>remoteTime)continue;await dbPut(store,payload);applied++}await recalcDerived();return applied}
async function syncNow(silent=false){
 try{
  setSyncStatus('syncing');
  const deviceId=getDeviceId();
  await syncRequest({action:'register_device',device_id:deviceId,app_version:'LOCAL-3',platform:navigator.platform||'web',metadata:{userAgent:navigator.userAgent.slice(0,160)}});
  const localRecords=await collectLocalRecords();
  for(let i=0;i<localRecords.length;i+=500)await syncRequest({action:'push',records:localRecords.slice(i,i+500)});
  const since=localStorage.getItem(SYNC_CURSOR_KEY)||null;
  const pulled=await syncRequest({action:'pull',since,limit:1000});
  await applyRemoteRecords(pulled.records||[]);
  if(pulled.cursor)localStorage.setItem(SYNC_CURSOR_KEY,pulled.cursor);
  setSyncStatus('synced',{pushed:localRecords.length,pulled:(pulled.records||[]).length});
  if(!silent)WS.toast(`Synchronisation terminée : ${localRecords.length} envoyés, ${(pulled.records||[]).length} reçus.`);
  return true;
 }catch(e){setSyncStatus('error',{message:e.message});if(!silent)WS.toast(`Synchronisation échouée : ${e.message}`);return false}
}
window.addEventListener('online',()=>{setSyncStatus('online-pending');syncNow(true)});
window.addEventListener('offline',()=>setSyncStatus('offline-local'));
window.syncNow=syncNow;window.getSyncStatus=getSyncStatus;
