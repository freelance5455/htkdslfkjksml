/* آزمون: برنامه‌ی آزمون (ex2)، نتیجه‌ها (exams، سازگار با قدیمی)، تحلیل‌ها، و تصحیح آزمون‌های تستی (quizzes). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var store = App.store;
  var st = App.study;
  var ex = (App.exam = {});
  var S = function () { return App.S; };

  ex.TAGS = { concept: 'مفهوم', calc: 'محاسبه', care: 'بی‌دقتی', time: 'فشار زمان', dk: 'نمی‌دانستم' };
  ex.TYPES = { full: 'کنکور کامل', subject: 'آزمون مبحثی', quick: 'تمرین سریع' };

  ex.days = function (e) { return Math.ceil((new Date(e.d + 'T23:59:00') - new Date()) / 864e5); };
  ex.upcoming = function () {
    return S().ex2.filter(function (e) { return ex.days(e) >= 0; }).sort(function (a, b) { return a.d < b.d ? -1 : 1; });
  };
  // شمارش پیش‌فرض سؤال‌ها: کنکور کامل از جدول کنکور؛ آزمون مبحثی و تمرین سریع جداگانه
  ex.defaults = function (type, subject) {
    if (type === 'full') {
      var k = D.KONKUR.riazi;
      return { sub: k.parts.map(function (p) { return { s: p.s, t: p.n }; }), tl: k.minutes };
    }
    return { sub: [{ s: subject || '', t: type === 'quick' ? 10 : 20 }], tl: 0 };
  };
  ex.addPlan = function (o) {
    var p = store.cleanPlanned({ n: o.n, d: o.d, typ: o.typ, neg: o.neg, tl: o.tl, sub: o.sub, r: o.r || [] });
    if (!p.sub.length) return null;
    S().ex2.push(p);
    return p;
  };
  ex.delPlan = function (id) { return st.delById(S().ex2, id); };
  ex.addRange = function (planId, r) {
    var p = S().ex2.find(function (x) { return String(x.id) === String(planId); });
    if (!p) return false;
    var a = u.clamp(Math.round(+r.a || 1), 1, D.MAX_CH), b = u.clamp(Math.round(+r.b || a), a, D.MAX_CH);
    if (!r.s) return false;
    p.r = p.r || [];
    p.r.push({ g: +r.g || S().mg || 12, s: r.s, a: a, b: b });
    return true;
  };
  ex.delRange = function (planId, i) {
    var p = S().ex2.find(function (x) { return String(x.id) === String(planId); });
    if (!p || !p.r || !p.r[i]) return false;
    p.r.splice(i, 1);
    return true;
  };

  // نتیجه‌ی آزمون. o: {n, s, date, t, c, w, z, neg, typ, tl, tu, sub:[{s,g,t,c,w}], qg, planId}
  ex.addResult = function (o) {
    var sub = null, t = +o.t || 0, c = +o.c || 0, w = +o.w || 0;
    if (o.sub && o.sub.length) {
      sub = o.sub.map(function (x) { return { s: x.s, g: x.g || 0, t: +x.t || 0, c: +x.c || 0, w: +x.w || 0 }; });
      if (sub.some(function (x) { return x.c + x.w > x.t || x.t <= 0; })) return null;
      t = u.sum(sub, function (x) { return x.t; });
      c = u.sum(sub, function (x) { return x.c; });
      w = u.sum(sub, function (x) { return x.w; });
    }
    if (!(t > 0) || c + w > t) return null;
    var rec = {
      id: u.uid(), n: u.clip(o.n || '', 60), s: sub ? '' : u.clip(o.s || '', 40), d: u.isISO(o.date) ? o.date : u.todayISO(),
      t: t, c: c, w: w, p: store.pctOf(c, w, t, !!o.neg), z: o.z ? Math.round(+o.z) : undefined,
      typ: ex.TYPES[o.typ] ? o.typ : (sub ? 'full' : 'subject'), neg: o.neg ? 1 : undefined,
      tl: o.tl ? Math.round(+o.tl) : undefined, tu: o.tu ? Math.round(+o.tu) : undefined,
      sub: sub ? sub.map(function (x) { return Object.assign(x, { b: x.t - x.c - x.w, p: store.pctOf(x.c, x.w, x.t, !!o.neg) }); }) : undefined,
      qg: Array.isArray(o.qg) && o.qg.length ? o.qg : undefined,
      ex2: o.planId || undefined
    };
    if (!sub && !rec.s && !o.s) rec.s = '';
    var clean = store.cleanExam(rec);
    if (!clean) return null;
    S().exams.push(clean);
    S().exams.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; });
    if (o.planId) {
      var p = S().ex2.find(function (x) { return String(x.id) === String(o.planId); });
      if (p) p.done = clean.id;
    }
    return clean;
  };
  ex.delResult = function (id) { return st.delById(S().exams, id); };

  // درصد هر درس در یک آزمون
  ex.subPercent = function (e) {
    if (e.sub && e.sub.length) return e.sub.map(function (x) { return { s: x.s, p: x.p != null ? x.p : store.pctOf(x.c, x.w, x.t, !!e.neg), t: x.t, c: x.c, w: x.w }; });
    return [{ s: e.s || 'ترکیبی', p: e.p, t: e.t, c: e.c, w: e.w }];
  };

  ex.trend = function () { return S().exams.map(function (e) { return { id: e.id, d: e.d, p: e.p, n: e.n || 'آزمون' }; }); };
  ex.heatmap = function (limit) {
    var list = S().exams.slice(-(limit || 10));
    var cols = [];
    list.forEach(function (e) { ex.subPercent(e).forEach(function (x) { if (cols.indexOf(x.s) < 0) cols.push(x.s); }); });
    var rows = list.map(function (e) {
      var m = {};
      ex.subPercent(e).forEach(function (x) { m[x.s] = x.p; });
      return { id: e.id, d: e.d, n: e.n || 'آزمون', cells: cols.map(function (c) { return m[c] != null ? m[c] : null; }) };
    });
    return { cols: cols, rows: rows };
  };
  ex.errors = function () {
    var tags = { concept: 0, calc: 0, care: 0, time: 0, dk: 0, untagged: 0, blank: 0 };
    var total = 0;
    S().exams.forEach(function (e) {
      (e.qg || []).forEach(function (q) {
        if (q.r === 'w') { total++; if (q.tag && tags[q.tag] != null) tags[q.tag]++; else tags.untagged++; }
        if (q.r === 'b') tags.blank++;
      });
    });
    return { tags: tags, wrongTotal: total };
  };
  // بیشترین خطا و کم‌دقت‌ترین فصل‌ها از پاسخ‌های سؤال‌به‌سؤال آزمون‌ها
  ex.weakChapters = function () {
    var M = {};
    S().exams.forEach(function (e) {
      (e.qg || []).forEach(function (q) {
        if (!q.ch || !q.s) return;
        var k = q.s + '|' + q.ch;
        var o = M[k] = M[k] || { s: q.s, c: q.ch, t: 0, wrong: 0 };
        if (q.r === 'c' || q.r === 'w') o.t++;
        if (q.r === 'w') o.wrong++;
      });
    });
    return Object.keys(M).map(function (k) { return M[k]; }).filter(function (o) { return o.wrong > 0; })
      .sort(function (a, b) { return b.wrong - a.wrong; }).slice(0, 5)
      .map(function (o) { return Object.assign({}, o, { name: st.chName(0, o.s, o.c) }); });
  };
  ex.subjectAverages = function () {
    var M = {};
    S().exams.forEach(function (e) {
      ex.subPercent(e).forEach(function (x) {
        if (!x.s || x.s === 'ترکیبی') return;
        var o = M[x.s] = M[x.s] || { s: x.s, sum: 0, n: 0 };
        o.sum += x.p; o.n++;
      });
    });
    return Object.keys(M).map(function (k) { return { s: k, p: Math.round(M[k].sum / M[k].n * 10) / 10, n: M[k].n }; })
      .sort(function (a, b) { return b.p - a.p; });
  };
  ex.timeStats = function () {
    var a = S().exams.filter(function (e) { return e.tu && e.t; });
    var perQ = a.map(function (e) { return e.tu / e.t; });
    var lim = S().exams.filter(function (e) { return e.tl; });
    return {
      count: a.length,
      perQuestion: perQ.length ? Math.round(u.avg(perQ) * 10) / 10 : null,
      overLimit: lim.filter(function (e) { return e.tu && e.tu > e.tl; }).length,
      totalMinutes: u.sum(a, function (e) { return e.tu; })
    };
  };
  // برآورد تقریبی درصد کنکور: میانگینِ وزن‌دار (جدیدترها وزن بیشتر) از آزمون‌های اخیر
  ex.predict = function () {
    var full = S().exams.filter(function (e) { return e.typ === 'full' && e.t >= 40; });
    var pool = full.length >= 1 ? full : S().exams.filter(function (e) { return e.t >= 20; });
    var recent = pool.slice(-5);
    if (!recent.length) return { value: null, n: 0, note: 'برای برآورد، حداقل یک آزمون کامل یا آزمون ۲۰ سؤالی لازم است.' };
    var wsum = 0, psum = 0;
    recent.forEach(function (e, i) { var wgt = i + 1; wsum += wgt; psum += wgt * e.p; });
    var v = Math.round(psum / wsum * 10) / 10;
    return {
      value: v, n: recent.length,
      note: recent.length < 3 ? 'داده کم است (' + u.fa(recent.length) + ' آزمون)؛ این عدد فقط نشانه‌ی تقریبی است.' : 'برآورد تقریبی بر پایه‌ی ' + u.fa(recent.length) + ' آزمون اخیر؛ قطعی نیست.'
    };
  };
  // مقایسه با آزمون قبلی
  ex.compareWithPrevious = function (e) {
    var list = S().exams.slice().sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; });
    var i = list.findIndex(function (x) { return x.id === e.id; });
    if (i <= 0) return null;
    var prev = list[i - 1];
    var subs = [];
    var prevSub = {};
    ex.subPercent(prev).forEach(function (x) { prevSub[x.s] = x.p; });
    ex.subPercent(e).forEach(function (x) {
      if (prevSub[x.s] != null) subs.push({ s: x.s, diff: Math.round((x.p - prevSub[x.s]) * 10) / 10 });
    });
    return { prev: prev, diff: Math.round((e.p - prev.p) * 10) / 10, subs: subs };
  };
  // ---- آزمون‌های تستی (کلید پاسخ یا تولیدشده با هوش مصنوعی) ----
  ex.quizAdd = function (o) {
    var q = store.cleanQuiz({
      title: o.title, g: o.g, s: o.s, ch: o.ch, src: o.src, tl: o.tl, created: u.todayISO(),
      questions: o.questions, attempts: []
    });
    if (!q) return null;
    S().quizzes.push(q);
    return q;
  };
  ex.quizGrade = function (quiz, answers) {
    var c = 0, w = 0, b = 0, detail = [];
    quiz.questions.forEach(function (q, i) {
      var a = answers[i] || '';
      if (!a) { b++; detail.push('b'); }
      else if (a === q.a) { c++; detail.push('c'); }
      else { w++; detail.push('w'); }
    });
    var n = quiz.questions.length;
    return { c: c, w: w, b: b, p: n ? Math.round(c / n * 1000) / 10 : 0, detail: detail };
  };
  ex.quizAttempt = function (quizId, answers, sec) {
    var q = S().quizzes.find(function (x) { return String(x.id) === String(quizId); });
    if (!q) return null;
    var g = ex.quizGrade(q, answers);
    var rec = { id: u.uid(), d: u.todayISO(), ans: answers.map(function (x) { return x || '-'; }).join(''), c: g.c, w: g.w, b: g.b, p: g.p, sec: sec || 0 };
    q.attempts = (q.attempts || []).concat([rec]).slice(-50);
    return { attempt: rec, grade: g, quiz: q };
  };
  ex.quizDel = function (id) { return st.delById(S().quizzes, id); };
})();
