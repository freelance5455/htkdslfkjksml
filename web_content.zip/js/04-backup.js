/* پشتیبان: خروجی بدون کلید، ورودی با پیش‌نمایش، ادغام یا جایگزینی، و پشتیبان چرخشی محلی (۵ نسخه). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var store = App.store;
  var bk = (App.backup = {});
  var SNAP_KEY = 'study_snaps';
  var SNAP_MAX = 5;
  var SNAP_EVERY_MS = 12 * 3600 * 1000;
  var ARRAYS = ['logs', 'exams', 'todos', 'jr', 'mem', 'wk', 'bl', 'ex2', 'quizzes', 'busy', 'wp'];
  var EXPORT_SKIP = ['col', 'rf', 'tm', 'notices', 'md', 'lg'];
  var SECRET_RE = /key|secret|token|password|passw/i;

  function stripSecrets(x) {
    if (Array.isArray(x)) return x.map(stripSecrets);
    if (x && typeof x === 'object') {
      var o = {};
      Object.keys(x).forEach(function (k) { if (!SECRET_RE.test(k)) o[k] = stripSecrets(x[k]); });
      return o;
    }
    return x;
  }

  // شیء خروجی (نسخه ۲). هیچ کلیدی وارد نمی‌شود.
  bk.exportObj = function () {
    var copy = store.clone(App.S);
    EXPORT_SKIP.forEach(function (k) { delete copy[k]; });
    var out = stripSecrets(copy);
    out.version = 2;
    out.app = 'study-advisor';
    out.exported_at = new Date().toISOString();
    return out;
  };
  bk.exportText = function () { return JSON.stringify(bk.exportObj(), null, 1); };

  // متن ورودی را می‌خواند و پاک‌سازی می‌کند
  bk.parse = function (text) {
    var raw = String(text == null ? '' : text).trim();
    if (!raw) return { ok: false, error: 'متنی برای ورود پیدا نشد.' };
    if (raw.length > 20 * 1024 * 1024) return { ok: false, error: 'فایل خیلی بزرگ است (بیشتر از ۲۰ مگابایت).' };
    var obj;
    try { obj = JSON.parse(raw); }
    catch (e) { return { ok: false, error: 'فایل پشتیبان معتبر نیست (JSON خراب است).' }; }
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return { ok: false, error: 'ساختار فایل پشتیبان درست نیست.' };
    var known = ['logs', 'exams', 'goal', 'todos', 'jr', 'mem', 'wk', 'bl', 'ex2', 'wp', 'busy', 'chn', 'cn', 'extra', 'quizzes', 'prof', 'cd'];
    var hits = known.filter(function (k) { return obj[k] !== undefined; }).length;
    if (hits < 2) return { ok: false, error: 'این فایل، پشتیبان مشاور تحصیلی نیست.' };
    var warn = '';
    if (obj.version && +obj.version > 2) warn = 'این پشتیبان از نسخه‌ی جدیدتری ساخته شده؛ بعضی بخش‌ها ممکن است نادیده گرفته شوند.';
    var data = store.cleanState(obj, {});
    // تنظیمات محلی (تم، پروکسی) را از پشتیبان نمی‌گیریم مگر در جایگزینی
    return { ok: true, data: data, warn: warn, legacy: !obj.version, exportedAt: obj.exported_at || '' };
  };

  // شمارش برای پیش‌نمایش: چند مورد جدید است و چند مورد تکراری
  bk.preview = function (data) {
    var S = App.S;
    var info = { counts: {}, newCounts: {}, range: null };
    var pairs = [['logs', 'ثبت مطالعه'], ['exams', 'آزمون'], ['todos', 'کار'], ['wk', 'نقطه ضعف'], ['bl', 'عقب‌افتادگی'], ['ex2', 'آزمون پیش‌رو'], ['quizzes', 'تست'], ['jr', 'دفترچه'], ['mem', 'حافظه'], ['busy', 'کار ثابت'], ['wp', 'بلوک هفتگی']];
    pairs.forEach(function (p) {
      var have = {};
      (S[p[0]] || []).forEach(function (x) { have[String(x.id)] = 1; });
      var list = data[p[0]] || [];
      info.counts[p[0]] = { label: p[1], total: list.length, fresh: list.filter(function (x) { return x.id == null || !have[String(x.id)]; }).length };
      if (p[0] === 'wp') { info.counts.wp.fresh = list.length; }
    });
    var days = (data.logs || []).map(function (l) { return l.d; }).sort();
    if (days.length) info.range = { from: days[0], to: days[days.length - 1] };
    info.hasGoal = !!data.goal;
    info.hasProfile = !!data.prof;
    return info;
  };

  // ادغام: اجتماع بر اساس شناسه، تنظیمات فقط اگر خالی بودند
  function mergeInto(S, data) {
    ARRAYS.forEach(function (k) {
      var have = {};
      (S[k] || []).forEach(function (x) { have[String(x.id)] = 1; });
      (data[k] || []).forEach(function (x) {
        if (x.id == null || !have[String(x.id)]) { (S[k] = S[k] || []).push(x); have[String(x.id)] = 1; }
      });
    });
    S.logs.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; });
    S.exams.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; });
    S.extra = Object.assign({}, S.extra, data.extra || {});
    S.chn = Object.assign({}, S.chn, data.chn || {});
    S.cn = Object.assign({}, S.cn, data.cn || {});
    ['wd', 'cl', 'rvd', 'ci'].forEach(function (k) { S[k] = Object.assign({}, S[k] || {}, data[k] || {}); });
    S.daily = S.daily || {};
    Object.keys(data.daily || {}).forEach(function (k) {
      var L = S.daily[k] = S.daily[k] || [], have = {};
      L.forEach(function (x) { have[String(x.id)] = 1; });
      (data.daily[k] || []).forEach(function (x) { if (!have[String(x.id)]) { L.push(x); have[String(x.id)] = 1; } });
    });
    var ai = pickAi(aiPart(S), data);
    S.prs = ai.prs; S.prsActive = ai.prsActive; store.fixActive(S);
    if (!S.prof && data.prof) S.prof = data.prof;
    if (!S.cd && data.cd) S.cd = data.cd;
    if (!S.fd && data.fd) S.fd = data.fd;
    if (!S.rules && data.rules) S.rules = data.rules;
    if (!S.prog && data.prog) S.prog = data.prog;
    if (data.plan && (!S.plan || data.plan.d > S.plan.d)) S.plan = data.plan;
    if (S.chat.length === 0 && data.chat && data.chat.length) S.chat = data.chat.slice(-40);
    return S;
  }

  // پروفایل‌های سرویس (نام، نشانی، مدل و پروفایل فعال) در پشتیبان هستند؛ کلید هرگز نیست.
  // اگر این دستگاه کلید دارد، پروفایل‌های خودش می‌ماند؛ دستگاه بی‌کلید، پروفایل‌های پشتیبان را می‌گیرد (اگر داشته باشد).
  function aiPart(S) { return { prs: S.prs || [], prsActive: S.prsActive, fb: S.fb }; }
  function pickAi(local, incoming) {
    var keep = (App.keys && App.keys.any()) || !(incoming.prs && incoming.prs.length);
    var src = keep ? local : incoming;
    return { prs: src.prs || [], prsActive: src.prsActive, fb: local.fb };
  }
  function keepAi(S, prev) {
    var r = pickAi(prev, S);
    S.prs = r.prs; S.prsActive = r.prsActive; S.fb = r.fb;
    store.fixActive(S);
  }
  bk.aiPart = aiPart;
  bk.keepAi = keepAi;

  // mode: 'merge' | 'replace'. قبل از هر تغییر، یک پشتیبان محلی گرفته می‌شود.
  bk.apply = function (data, mode) {
    bk.snapshot('پیش از ' + (mode === 'replace' ? 'جایگزینی' : 'ادغام') + ' پشتیبان');
    if (mode === 'replace') {
      var keep = { ai: aiPart(App.S), theme: App.S.theme, fs: App.S.fs, notices: App.S.notices, mg: App.S.mg, remind: App.S.remind };
      App.S = store.cleanState(store.clone(data), {});
      keepAi(App.S, keep.ai);
      App.S.theme = keep.theme; App.S.fs = keep.fs; App.S.notices = keep.notices; App.S.remind = keep.remind || App.S.remind;
      App.S.rs = 1;
    } else {
      App.S = mergeInto(App.S, store.clone(data));
      App.S.rs = 1;
    }
    App.S.lb = u.todayISO();
    store.save();
    return true;
  };

  // ---- پشتیبان چرخشی محلی ----
  function readSnaps() {
    try {
      var list = JSON.parse(localStorage.getItem(SNAP_KEY) || '[]');
      return Array.isArray(list) ? list : [];
    } catch (e) { return []; }
  }
  function writeSnaps(list) {
    while (list.length) {
      try { localStorage.setItem(SNAP_KEY, JSON.stringify(list)); return true; }
      catch (e) { list.shift(); } // حافظه پر است: قدیمی‌ترین را حذف کن
    }
    try { localStorage.removeItem(SNAP_KEY); } catch (e) { /* ignore */ }
    return false;
  }
  bk.snapshots = function () {
    return readSnaps().map(function (s, i) {
      return { i: i, at: s.at, note: s.note || '', logs: s.logs || 0, exams: s.exams || 0 };
    }).reverse();
  };
  bk.snapshot = function (note) {
    var S = App.S;
    var hasData = (S.logs.length + S.exams.length + S.todos.length + S.jr.length + S.wk.length) > 0;
    if (!hasData && !note) return false;
    var list = readSnaps();
    var body = JSON.stringify(bk.exportObj());
    list.push({ at: new Date().toISOString(), note: note || 'خودکار', logs: S.logs.length, exams: S.exams.length, data: body });
    while (list.length > SNAP_MAX) list.shift();
    return writeSnaps(list);
  };
  // هر چند ساعت یک‌بار (اگر داده باشد) پشتیبان خودکار
  bk.maybeSnapshot = function () {
    var list = readSnaps();
    var last = list.length ? Date.parse(list[list.length - 1].at) : 0;
    if (Date.now() - last < SNAP_EVERY_MS) return false;
    return bk.snapshot('خودکار');
  };
  bk.restoreSnapshot = function (idxFromNewest) {
    var list = readSnaps();
    var n = list.length - 1 - idxFromNewest;
    if (n < 0 || !list[n]) return false;
    var parsed = bk.parse(list[n].data);
    if (!parsed.ok) return false;
    bk.snapshot('پیش از بازیابی پشتیبان');
    var prevAi = aiPart(App.S);
    App.S = store.cleanState(parsed.data, {});
    keepAi(App.S, prevAi);
    App.S.theme = App.S.theme || 'system';
    store.save();
    return true;
  };
  bk.clearSnapshots = function () { try { localStorage.removeItem(SNAP_KEY); } catch (e) { /* ignore */ } };
})();
