/* intel-ui.js — Phase 6 interface: Intelligence screen (Agency / Operations / Intel / Log). */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const me = () => G.state.player;
  const nm = id => G.COUNTRIES[id].name;
  const fmt = n => Math.round(n).toLocaleString('en-US');
  let tab = 'agency', target = null, targetProv = null;

  const stars = n => '★'.repeat(n) + '☆'.repeat(5 - n);
  const bar = (f, col) => '<div class="bar"><i style="width:' + Math.max(0, Math.min(100, f * 100)).toFixed(0) + '%;' + (col ? 'background:' + col : '') + '"></i></div>';
  const flag = id => '<img class="mini" src="' + G.flagURL(id) + '">';

  G.showIntel = function (which, tgt, prov) {
    if (which) tab = which;
    if (tgt !== undefined) { if (tgt !== target) targetProv = null; target = tgt; }
    if (prov !== undefined) targetProv = prov;
    const st = G.state, id = me();
    const targets = Object.keys(G.COUNTRIES).filter(o => o !== id && !G.isDead(o));
    if (target == null || !targets.includes(target)) target = targets[0];
    const names = { agency: 'Agency', ops: 'Operations (' + st.ops.filter(o => o.owner === id).length + ')', intel: 'Intel', log: 'Reports' };
    let h = '<h3>🕵 Intelligence — ' + nm(id) + '</h3><div class="tabs">' +
      Object.keys(names).map(t => '<button data-t="' + t + '" class="' + (tab === t ? 'on' : '') + '">' + names[t] + '</button>').join('') + '</div>';
    h += ({ agency: agencyTab, ops: opsTab, intel: intelTab, log: logTab })[tab](id);
    h += '<div class="row"><button id="in-close">Close</button></div>';
    $('modal-box').innerHTML = h; $('modal').classList.remove('hidden');
    const box = $('modal-box');
    $('in-close').onclick = G.closeModal;
    box.querySelectorAll('.tabs button[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; G.showIntel(); });
    box.querySelectorAll('[data-tg]').forEach(b => b.onclick = () => { if (b.dataset.tg !== target) targetProv = null; target = b.dataset.tg; if (b.dataset.go) tab = b.dataset.go; G.showIntel(); });
    const act = (sel, fn) => box.querySelectorAll(sel).forEach(b => b.onclick = () => { const r = fn(b); if (r && r.msg) G.toast(r.msg); G.updateTopBar(); G.showIntel(); });
    act('#ag-rec', () => G.recruitAgent(id));
    act('#ag-up', () => G.upgradeAgency(id));
    act('#ag-cnt', () => G.upgradeCounter(id));
    act('[data-op]', b => {
      const r = G.launchOp(id, b.dataset.op, target);
      if (r.ok) return { msg: G.OPS[b.dataset.op].name + ' launched with ' + r.agent.name };
      return r;
    });
    box.querySelectorAll('[data-pv]').forEach(b => b.onclick = () => { targetProv = +b.dataset.pv; G.showIntel(); });
    act('[data-pop]', b => {
      const r = G.launchOp(id, b.dataset.pop, target, targetProv);
      if (r.ok) return { msg: G.OPS[b.dataset.pop].name + ' launched with ' + r.agent.name };
      return r;
    });
    act('[data-abort]', b => { G.abortOp(+b.dataset.abort); return { msg: 'Operation aborted' }; });
  };

  function agencyTab(id) {
    const st = G.state, it = st.intel[id], c = st.countries[id];
    let h = '<div class="grid"><div class="cell"><span>Agency level</span>' + it.level + ' / ' + G.AGENCY_MAX + '</div>' +
      '<div class="cell"><span>Agents</span>' + it.agents.length + (it.training.length ? ' (+' + it.training.length + ' training)' : '') + ' / ' + G.agentCap(id) + '</div>' +
      '<div class="cell"><span>Counter-intel</span>' + it.counter + ' / ' + G.COUNTER_MAX + '</div></div>';
    h += '<div class="chips"><button id="ag-rec">＋ Train agent (💰 ' + G.AGENT_COST.gold + ', 👥 ' + G.AGENT_COST.manpower + ', ' + G.AGENT_COST.days + 'd)</button>' +
      '<button id="ag-up"' + (it.level >= G.AGENCY_MAX ? ' disabled' : '') + '>⬆ Agency (💰 ' + (it.level >= G.AGENCY_MAX ? 'max' : G.agencyUpgradeCost(id)) + ')</button>' +
      '<button id="ag-cnt"' + (it.counter >= G.COUNTER_MAX ? ' disabled' : '') + '>🛡 Counter-intel (💰 ' + (it.counter >= G.COUNTER_MAX ? 'max' : G.counterUpgradeCost(id)) + ')</button></div>';
    h += '<p class="dim" style="font-size:12px">Agency level raises the number of agents you can keep. Counter-intelligence lowers enemy success, slows their networks and exposes more of their agents.</p>';
    h += '<h3>Agents</h3>';
    h += it.agents.map(a => {
      const op = a.op ? st.ops.find(o => o.id === a.op) : null;
      return '<div class="slot"><div class="info"><b>' + a.name + '</b> <small>' + stars(a.skill) + '</small><br><small>' +
        (op ? G.OPS[op.type].icon + ' ' + G.OPS[op.type].name + ' → ' + nm(op.target) + (op.type === 'infiltrate' ? ' (ongoing)' : ' — ' + op.left + 'd left') : 'Idle') + '</small></div></div>';
    }).join('') + it.training.map(t => '<div class="slot"><div class="info"><b>Trainee</b><br><small>Ready in ' + Math.max(0, t.ready - st.day) + ' days</small></div></div>').join('');
    if (c.treasury < 0) h += '';
    return h;
  }

  function opsTab(id) {
    const st = G.state, others = Object.keys(G.COUNTRIES).filter(o => o !== id && !G.isDead(o));
    let h = '<div class="chips">' + others.map(o => '<button data-tg="' + o + '" class="' + (o === target ? 'primary' : '') + '">' + nm(o) + '</button>').join('') + '</div>';
    const net = G.netLevel(id, target), tc = st.intel[target].counter;
    h += '<div class="eqline">' + flag(target) + ' ' + nm(target) + ' — your network ' + Math.floor(net) + '% · their counter-intel ' + tc + '</div>' + bar(net / 100);
    const best = G.idleAgents(id).sort((a, b) => b.skill - a.skill)[0];
    h += '<p class="dim" style="font-size:12px">' + (best ? 'Best idle agent: ' + best.name + ' ' + stars(best.skill) : 'No idle agents — train more or wait for operations to finish.') + '</p>';
    h += G.OP_TYPES.map(t => {
      const O = G.OPS[t], chk = G.canLaunch(id, t, target), ch = Math.round(G.opChance(id, t, target, best) * 100);
      return '<div class="slot"><div class="info"><b>' + O.icon + ' ' + O.name + '</b> <small>💰 ' + O.cost + ' · ' + (O.days ? O.days + ' days' : 'ongoing') + ' · net ≥ ' + O.min + ' · ' + (t === 'infiltrate' ? 'no roll — agent may be caught' : 'success ' + ch + '%') + '</small><br><small>' + O.desc + '</small>' +
        (chk.ok ? '' : '<br><small style="color:#e0a090">' + chk.msg + '</small>') + '</div><button data-op="' + t + '"' + (chk.ok ? '' : ' disabled') + '>Launch</button></div>';
    }).join('');
    h += '<h3>Province operations — ' + nm(target) + '</h3>';
    const provs = G.provinces.filter(p => !p.sea && st.owners[p.id] === target);
    if (targetProv != null && st.owners[targetProv] !== target) targetProv = null;
    h += '<p class="dim" style="font-size:12px">Pick a province. 🔗 = borders your land (required for revolution). Number = discontent' + (net >= 20 ? '' : ' (needs network 20%+ to see)') + '.</p><div class="chips">' +
      provs.map(p => {
        const border = p.adj.some(n => st.owners[n] === id), d = G.discontent(p.id);
        return '<button data-pv="' + p.id + '" class="' + (p.id === targetProv ? 'primary' : '') + '">' + (p.capital ? '★ ' : '') + p.name + (border ? ' 🔗' : '') + ' · ' + (net >= 20 ? Math.round(d) : '?') + '</button>';
      }).join('') + '</div>';
    if (targetProv != null) {
      const P = G.provinces[targetProv];
      h += '<div class="eqline">' + P.name + ' — discontent ' + (net >= 20 ? Math.round(G.discontent(targetProv)) : '?') + ' / 100</div>' + bar(net >= 20 ? G.discontent(targetProv) / 100 : 0, '#e07060');
      h += G.PROV_OP_TYPES.map(t => {
        const O = G.OPS[t], chk = G.canLaunch(id, t, target, targetProv), ch = Math.round(G.opChance(id, t, target, best, targetProv) * 100);
        return '<div class="slot"><div class="info"><b>' + O.icon + ' ' + O.name + '</b> <small>💰 ' + O.cost + ' · ' + O.days + ' days · net ≥ ' + O.min + ' · success ' + ch + '%</small><br><small>' + O.desc + '</small>' +
          (chk.ok ? '' : '<br><small style="color:#e0a090">' + chk.msg + '</small>') + '</div><button data-pop="' + t + '"' + (chk.ok ? '' : ' disabled') + '>Launch</button></div>';
      }).join('');
    }
    const mine = st.ops.filter(o => o.owner === id);
    if (mine.length) h += '<h3>Active operations</h3>' + mine.map(o => '<div class="slot"><div class="info"><b>' + G.OPS[o.type].icon + ' ' + G.OPS[o.type].name + '</b> → ' + flag(o.target) + nm(o.target) + (o.prov != null ? ' / ' + G.provinces[o.prov].name : '') +
      '<br><small>' + (o.type === 'infiltrate' ? 'ongoing — network ' + Math.floor(G.netLevel(id, o.target)) + '%' : o.left + ' days left') + '</small></div><button data-abort="' + o.id + '">Abort</button></div>').join('');
    return h;
  }

  function intelTab(id) {
    const st = G.state;
    return Object.keys(G.COUNTRIES).filter(o => o !== id && !G.isDead(o)).map(o => {
      const lv = G.intelLevel(id, o), c = st.countries[o], rev = G.revealLeft(id, o);
      const iv = (v, f) => G.intelVal(o, v, f);
      const men = st.armies.filter(a => a.owner === o).reduce((s, a) => s + G.armySummary(a).men, 0);
      const nArm = st.armies.filter(a => a.owner === o).length;
      const unrest = G.hasEffect(o, 'unrest') ? ' · 🔥 unrest' : '';
      return '<div class="card"><b>' + flag(o) + ' ' + nm(o) + '</b> <small class="dim">intel ' + Math.round(lv) + '%' + (rev ? ' · plans stolen (' + rev + 'd)' : '') + unrest + '</small>' + bar(lv / 100) +
        '<div class="grid" style="margin-top:6px"><div class="cell"><span>Treasury</span>' + iv(c.treasury) + '</div><div class="cell"><span>Manpower</span>' + iv(c.manpower) + '</div>' +
        '<div class="cell"><span>Armies</span>' + (lv >= 50 ? nArm + ' (' + fmt(men) + ' men)' : lv >= 20 ? '~' + Math.round(nArm / 2) * 2 : '?') + '</div>' +
        '<div class="cell"><span>Steel / Oil</span>' + iv(c.res.steel) + ' / ' + iv(c.res.oil) + '</div>' +
        '<div class="cell"><span>Provinces</span>' + c.provCount + '</div><div class="cell"><span>Counter-intel</span>' + (lv >= 50 ? st.intel[o].counter : '?') + '</div></div>' +
        '<div class="chips"><button data-tg="' + o + '" data-go="ops">Operations ›</button></div></div>';
    }).join('');
  }

  function logTab() {
    const L = G.state.intelLog;
    return L.length ? '<div class="logbox">' + L.map(x => '<div>' + x + '</div>').join('') + '</div>' : '<p class="dim">No reports yet.</p>';
  }

  // Province panel hook: shortcut to province operations on foreign provinces
  G.provinceIntelHtml = function (prov) {
    const st = G.state, o = st.owners[prov];
    if (!o || o === st.player || G.isDead(o) || G.provinces[prov].sea) return '';
    const lv = G.netLevel(st.player, o), d = G.discontent(prov);
    return '<div class="chips"><button id="pv-intel">🕵 Operations here' + (lv >= 20 ? ' (discontent ' + Math.round(d) + ')' : '') + '</button></div>';
  };
  G.bindProvinceIntel = function (prov) {
    const b = $('pv-intel'); if (b) b.onclick = () => { tab = 'ops'; G.showIntel('ops', G.state.owners[prov], prov); };
  };
  G.onIntelNote = function () { /* hook for badges */ };
  G.bindIntelUI = function () { $('btn-intel').onclick = () => { tab = 'agency'; G.showIntel(); }; };

})(window.EMP = window.EMP || {});
