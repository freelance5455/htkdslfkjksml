'use strict';
/* ============ الطباعة: الترويسة المخصصة + المستندات ============ */
function letterhead(p) {
  p = p || S.settings.print;
  const logo = p.showLogo ? '<img src="' + esc(p.logo || 'img/logo.png') + '" alt="">' : '<span></span>';
  const ph = v => v ? '<span class="ltr num">' + esc(v) + '</span>' : '';
  const parts = [p.address ? '<span>' + esc(p.address) + '</span>' : '', ph(p.phone1) && '<span>هاتف: ' + ph(p.phone1) + '</span>', ph(p.phone2) && '<span>' + ph(p.phone2) + '</span>', p.email ? '<span class="ltr">' + esc(p.email) + '</span>' : '', p.licence ? '<span>' + esc(p.licence) + '</span>' : ''].filter(Boolean);
  return '<div class="lh"><div class="ar"><div class="nm">' + esc(p.nameAr) + '</div>' + (p.subAr ? '<div class="sb">' + esc(p.subAr) + '</div>' : '') + '</div>' + logo +
    '<div class="en"><div class="nm">' + esc(p.nameEn) + '</div>' + (p.subEn ? '<div class="sb">' + esc(p.subEn) + '</div>' : '') + '</div></div>' +
    (parts.length ? '<div class="lc">' + parts.join('') + '</div>' : '');
}
async function printDoc(title, html, o) {
  o = o || {}; const p = S.settings.print;
  const page = o.page === '80mm' ? '@page{size:80mm auto;margin:4mm}' : '@page{size:A4;margin:12mm 12mm 20mm}';
  let st = document.getElementById('pgstyle'); if (!st) { st = document.createElement('style'); st.id = 'pgstyle'; document.head.appendChild(st); } st.textContent = page;
  $('printArea').innerHTML = (o.bare ? '' : letterhead(p) + (title ? '<div class="pt">' + esc(title) + '</div>' : '')) + html + (o.bare || !p.footer ? '' : '<div class="pf">' + esc(p.footer) + '</div>');
  const imgs = [...$('printArea').querySelectorAll('img')];
  await Promise.race([Promise.all(imgs.map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; }))), new Promise(r => setTimeout(r, 1800))]);
  setTimeout(() => window.print(), 60);
}
/* باركود Code 39 */
const C39 = { '0': 'nnnwwnwnn', '1': 'wnnwnnnnw', '2': 'nnwwnnnnw', '3': 'wnwwnnnnn', '4': 'nnnwwnnnw', '5': 'wnnwwnnnn', '6': 'nnwwwnnnn', '7': 'nnnwnnwnw', '8': 'wnnwnnwnn', '9': 'nnwwnnwnn', '-': 'nwnnnnwnw', '*': 'nwnnwnwnn' };
function barcodeSVG(text, h) {
  h = h || 46; let x = 0, bars = '';
  for (const ch of '*' + text + '*') {
    const p = C39[ch]; if (!p) continue;
    for (let i = 0; i < 9; i++) { const w = p[i] === 'w' ? 3 : 1; if (i % 2 === 0) bars += '<rect x="' + x + '" y="0" width="' + w + '" height="' + h + '"/>'; x += w; } x += 1;
  }
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + x + ' ' + h + '" width="' + Math.round(x * 1.3) + '" height="' + h + '" fill="#000" shape-rendering="crispEdges">' + bars + '</svg><div style="font-size:12px;text-align:center;letter-spacing:2px">' + esc(text) + '</div>';
}
function infoTable(r, extra) {
  return '<table><tr><th>رقم المريض</th><td class="num">' + r.patientNo + '</td><th>الاسم</th><td>' + esc(r.patientName) + '</td></tr><tr><th>العمر / الجنس</th><td>' + esc(r.age ?? '') + ' سنة · ' + GEN[r.gender || ''] + '</td><th>التاريخ</th><td class="num">' + (extra || r.date || '') + '</td></tr></table>';
}
function printRx(id) {
  const r = get('prescriptions', id), p = get('patients', r.patientNo) || {}, v = r.visitId ? get('visits', r.visitId) : null;
  printDoc('وصفة طبية', infoTable({ ...r, age: p.age, gender: p.gender }) +
    (v && v.diagnosis ? '<p style="margin:6px 0"><b>التشخيص:</b> ' + esc(v.diagnosis) + '</p>' : '') +
    (p.allergies ? '<p style="margin:6px 0;color:#c00"><b>الحساسية:</b> ' + esc(p.allergies) + '</p>' : '') +
    '<h2 style="margin:10px 0;font-size:22px">℞</h2><table><tr><th>#</th><th>الدواء</th><th>الجرعة</th><th>الكمية</th></tr>' +
    r.items.map((i, n) => '<tr><td>' + (n + 1) + '</td><td>' + esc(i.name) + '</td><td>' + esc(i.dosage) + '</td><td class="num">' + i.qty + '</td></tr>').join('') + '</table>' +
    '<div class="sig"><div>' + (r.doctorName ? 'د. ' + esc(r.doctorName) : 'توقيع الطبيب') + '</div><div>ختم المجمع</div></div>');
}
function printLab(id) {
  const r = get('labRequests', id);
  printDoc('تقرير المختبر', infoTable(r, new Date(r.doneTs || r.ts).toLocaleString('en-GB')) +
    '<table><tr><th>الفحص</th><th>النتيجة</th><th>الوحدة</th><th>المعدل الطبيعي</th></tr>' +
    r.tests.map(t => { const x = r.results[t.testId] || {}; return '<tr><td>' + esc(t.name) + '</td><td class="' + (x.flag === 'H' || x.flag === 'L' ? 'fl' : '') + '"><b class="num">' + esc(x.value ?? '') + '</b> ' + (x.flag === 'H' ? '▲' : x.flag === 'L' ? '▼' : '') + '</td><td>' + esc(t.unit) + '</td><td class="num">' + esc(x.range || '') + '</td></tr>'; }).join('') + '</table>' +
    (r.notes ? '<p style="margin-top:8px"><b>ملاحظات:</b> ' + esc(r.notes) + '</p>' : '') +
    '<div style="margin-top:12px">' + barcodeSVG(r.barcode, 40) + '</div><div class="sig"><div>' + (r.doneBy ? 'الفني: ' + esc(r.doneBy) : 'توقيع الفني') + '</div><div>ختم المجمع</div></div>');
}
function printCard(no) {
  const p = get('patients', no), pr = S.settings.print;
  printDoc('بطاقة مريض', '<div class="cardid"><div style="font-size:13px;font-weight:700;color:#0D1325">' + esc(pr.nameAr) + '</div><div style="font-size:12px;color:#555;direction:ltr">' + esc(pr.nameEn) + '</div><div style="font-size:30px;font-weight:700;margin:6px 0" class="num">رقم: ' + p.no + '</div><div style="font-size:18px;font-weight:700">' + esc(p.name) + '</div><div style="font-size:13px;margin:2px 0 8px">' + esc(p.age) + ' سنة · ' + GEN[p.gender || ''] + (p.phone ? ' · <span class="ltr">' + esc(p.phone) + '</span>' : '') + '</div>' + barcodeSVG(String(p.no), 44) + '</div>');
}
function printTicket(qid) {
  const q = get('queue', qid), p = S.settings.print;
  printDoc('', '<div class="tk"><img src="' + esc(p.logo || 'img/logo.png') + '" style="height:54px;display:block;margin:0 auto 4px" alt=""><div style="font-weight:700;font-size:15px">' + esc(p.nameAr) + '</div><div style="font-size:12px;color:#444;margin:8px 0 2px">رقم الدور</div><div class="big num">' + q.no + '</div><div style="font-size:16px;font-weight:700;margin:6px 0">' + esc(q.patientName) + '</div><div style="font-size:12px;color:#444" class="num">مريض رقم ' + q.patientNo + ' · ' + q.date + ' ' + hm(q.ts) + '</div></div>', { page: '80mm', bare: true });
}
function printSales(rows, label) {
  const tot = rows.reduce((s, d) => s + d.total, 0), items = rows.reduce((s, d) => s + d.qty, 0);
  printDoc('تقرير مبيعات الصيدلية — ' + label,
    '<table><tr><th>الوقت</th><th>المريض</th><th>الدواء</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>' +
    rows.map(d => '<tr><td class="num">' + d.date + ' ' + hm(d.ts) + '</td><td>' + d.patientNo + ' — ' + esc(d.patientName) + '</td><td>' + esc(d.name) + '</td><td class="num">' + d.qty + '</td><td class="num">' + num(d.price) + '</td><td class="num">' + num(d.total) + '</td></tr>').join('') +
    '</table><p style="margin-top:10px;font-size:15px"><b>عدد الأصناف المباعة:</b> <span class="num">' + items + '</span> &nbsp;·&nbsp; <b>الإجمالي:</b> <span class="num">' + money(tot) + '</span></p>');
}
