"use strict";

const DayUI = (() => {
  const LOCK_MS = 1500;
  let lockTimer = null;
  let selectedNominees = new Set();
  let selectedVote = null;
  let currentKind = null;
  let acted = false;
  let resultMode = "final";

  const $ = (id) => document.getElementById(id);

  /* ---------- مؤقت عدّ تنازلي مع إيقاف مؤقت ---------- */
  const Countdown = {
    id: null,
    remaining: 0,
    paused: false,
    onTick: null,
    onEnd: null,
    start(seconds, onTick, onEnd) {
      this.stop();
      this.remaining = seconds;
      this.paused = false;
      this.onTick = onTick;
      this.onEnd = onEnd;
      onTick(seconds);
      this.id = setInterval(() => {
        if (this.paused) return;
        this.remaining -= 1;
        this.onTick(this.remaining);
        if (this.remaining <= 0) {
          const callback = this.onEnd;
          this.stop();
          if (callback) callback();
        }
      }, 1000);
    },
    pause() { this.paused = true; },
    resume() { this.paused = false; },
    stop() {
      clearInterval(this.id);
      this.id = null;
    },
  };

  function formatTime(seconds) {
    const s = Math.max(0, seconds);
    const m = Math.floor(s / 60);
    const rest = String(s % 60).padStart(2, "0");
    return `${m}:${rest}`;
  }

  function timerEnabled() {
    const settings = Game.getSettings();
    return Boolean(settings && settings.timerEnabled);
  }

  /* ---------- النقاش ---------- */
  function start() {
    const res = Game.startDay();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    $("day-title").textContent = `☀️ النهار ${res.number}`;

    const aliveBox = $("day-alive");
    aliveBox.innerHTML = "";
    res.alive.forEach((p) => {
      const chip = document.createElement("span");
      chip.className = "alive-chip";
      chip.textContent = p.name;
      aliveBox.appendChild(chip);
    });

    const timerBox = $("day-timer");
    const pauseBtn = $("btn-day-pause");
    if (timerEnabled()) {
      const settings = Game.getSettings();
      timerBox.hidden = false;
      pauseBtn.hidden = false;
      pauseBtn.textContent = "⏸️ إيقاف مؤقت";
      Countdown.start(
        settings.discussionSeconds,
        (left) => { timerBox.textContent = `⏱️ ${formatTime(left)}`; },
        () => {
          UI.toast("⏰ انتهى وقت النقاش");
          onEndDiscussion();
        }
      );
    } else {
      Countdown.stop();
      timerBox.hidden = true;
      pauseBtn.hidden = true;
    }
    UI.showScreen("day-discussion");
  }

  function onPause() {
    const btn = $("btn-day-pause");
    if (Countdown.paused) {
      Countdown.resume();
      btn.textContent = "⏸️ إيقاف مؤقت";
    } else {
      Countdown.pause();
      btn.textContent = "▶️ استكمال";
    }
  }

  function onEndDiscussion() {
    Countdown.stop();
    const res = Game.endDiscussion();
    if (res.ok) showNomination();
  }

  /* ---------- الترشيح ---------- */
  function updateNominationButtons() {
    $("btn-start-voting").disabled = selectedNominees.size < 2;
    document.querySelectorAll("#nominee-list .target-btn").forEach((btn) => {
      btn.classList.toggle("on", selectedNominees.has(Number(btn.dataset.nominee)));
    });
  }

  function showNomination() {
    selectedNominees = new Set();
    const info = Game.getDayInfo();
    const list = $("nominee-list");
    list.innerHTML = "";
    info.alive.forEach((p) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "target-btn";
      btn.dataset.nominee = String(p.id);
      btn.textContent = p.name;
      list.appendChild(btn);
    });
    updateNominationButtons();
    UI.showScreen("day-nomination");
  }

  function onNomineeClick(event) {
    const btn = event.target.closest("[data-nominee]");
    if (!btn) return;
    const id = Number(btn.dataset.nominee);
    if (selectedNominees.has(id)) selectedNominees.delete(id);
    else selectedNominees.add(id);
    updateNominationButtons();
  }

  function onNominateAll() {
    const info = Game.getDayInfo();
    selectedNominees = new Set(info.alive.map((p) => p.id));
    updateNominationButtons();
  }

  function onStartVoting() {
    const res = Game.setNominees([...selectedNominees]);
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    showVoteHandover();
  }

  /* ---------- تسليم الهاتف للتصويت ---------- */
  function showVoteHandover() {
    const turn = Game.getVoteTurn();
    if (!turn) return;
    if (turn.done) {
      showTally();
      return;
    }
    const roundLabel = turn.round === 2 ? " — إعادة التصويت" : "";
    $("vote-progress").textContent = `التصويت ${turn.index + 1} من ${turn.total}${roundLabel}`;
    $("vote-handover-name").textContent = turn.player.name;
    $("btn-vote-ready").textContent = `👁️ أنا ${turn.player.name} — جاهز`;
    UI.showScreen("day-vote-handover");
  }

  /* ---------- شاشة التصويت ---------- */
  function clearVoteDom() {
    $("vote-targets").innerHTML = "";
    $("vote-title").textContent = "";
    $("vote-prompt").textContent = "";
    $("vote-timer").textContent = "";
  }

  function renderVote(res) {
    currentKind = res.turn.kind;
    acted = false;
    selectedVote = null;

    $("vote-title").textContent = res.turn.title;
    $("vote-prompt").textContent = res.turn.prompt;

    const list = $("vote-targets");
    list.innerHTML = "";
    res.turn.targets.forEach((target) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "target-btn";
      btn.dataset.vote = String(target.id);
      btn.textContent = target.name;
      list.appendChild(btn);
    });

    const confirm = $("btn-vote-confirm");
    if (currentKind === "silenced") {
      confirm.disabled = false;
      confirm.textContent = "➡️ متابعة";
    } else {
      confirm.disabled = true;
      confirm.textContent = "✅ تأكيد الصوت";
    }
    $("btn-vote-abstain").hidden = !res.turn.allowAbstain;

    const timerBox = $("vote-timer");
    if (timerEnabled() && currentKind === "vote") {
      const settings = Game.getSettings();
      timerBox.hidden = false;
      Countdown.start(
        settings.votingSeconds,
        (left) => { timerBox.textContent = `⏱️ ${formatTime(left)}`; },
        () => {
          UI.toast("⏰ انتهى الوقت: امتناع");
          submitVote(null);
        }
      );
    } else {
      Countdown.stop();
      timerBox.hidden = true;
    }
  }

  function onVoteReady() {
    const res = Game.beginVoteTurn();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    renderVote(res);
    UI.showScreen("day-vote-action");
  }

  function onVoteClick(event) {
    const btn = event.target.closest("[data-vote]");
    if (!btn || acted) return;
    selectedVote = Number(btn.dataset.vote);
    document.querySelectorAll("#vote-targets .target-btn").forEach((b) => {
      b.classList.toggle("on", b === btn);
    });
    $("btn-vote-confirm").disabled = false;
  }

  function submitVote(target) {
    if (acted) return;
    Countdown.stop();
    const res = Game.submitVote(target);
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    acted = true;
    clearVoteDom();
    showVoteTransition();
  }

  function onVoteConfirm() {
    submitVote(currentKind === "silenced" ? null : selectedVote);
  }

  function onVoteAbstain() {
    submitVote(null);
  }

  /* ---------- شاشة القفل ---------- */
  function showVoteTransition() {
    const res = Game.advanceVoteTurn();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    const btn = $("btn-vote-next");
    clearTimeout(lockTimer);
    btn.disabled = true;
    btn.textContent = "⏳ انتظر…";
    UI.showScreen("day-vote-transition");
    lockTimer = setTimeout(() => {
      btn.disabled = false;
      btn.textContent = res.finished ? "📊 عرض النتيجة" : "👤 المصوّت التالي";
    }, LOCK_MS);
  }

  function onVoteNext() {
    const btn = $("btn-vote-next");
    if (btn.disabled) return;
    btn.disabled = true;
    showVoteHandover();
  }

  /* ---------- النتيجة ---------- */
  function addLine(parent, text) {
    const line = document.createElement("p");
    line.className = "dawn-line";
    line.textContent = text;
    parent.appendChild(line);
  }

  function showTally() {
    const res = Game.tallyVotes();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }

    const countsBox = $("day-counts");
    countsBox.innerHTML = "";
    res.counts.forEach((row) => {
      const line = document.createElement("div");
      line.className = "count-row";
      const name = document.createElement("span");
      name.textContent = row.name;
      const votes = document.createElement("b");
      votes.textContent = String(row.votes);
      line.append(name, votes);
      countsBox.appendChild(line);
    });

    const text = $("day-result-text");
    const nextBtn = $("btn-day-result-next");

    if (res.status === "revote") {
      resultMode = "revote";
      $("day-result-icon").textContent = "⚖️";
      $("day-result-title").textContent = "تعادل في الأصوات!";
      text.textContent = `تعادل بين: ${res.tied.join("، ")} — يُعاد التصويت بينهم.`;
      nextBtn.textContent = "🔁 إعادة التصويت";
    } else {
      resultMode = "final";
      $("day-result-title").textContent = "📊 نتيجة التصويت";
      if (res.status === "eliminated") {
        const settings = Game.getSettings();
        const reveal = settings && settings.revealRoleOnElimination === "reveal";
        const role = Roles.get(res.eliminated.roleId);
        $("day-result-icon").textContent = "⚰️";
        text.textContent = reveal
          ? `استُبعد ${res.eliminated.name} — كان ${role.icon} ${role.name}`
          : `استُبعد ${res.eliminated.name}`;
      } else if (res.reason === "protected") {
        $("day-result-icon").textContent = "🛡️";
        text.textContent = "لم يُستبعد أحد… قوة غامضة حمت المتهم!";
      } else if (res.reason === "tie") {
        $("day-result-icon").textContent = "🤝";
        text.textContent = "تعادل مستمر، لا أحد يُستبعد اليوم.";
      } else {
        $("day-result-icon").textContent = "🤐";
        text.textContent = "لم يصوّت أحد، لا أحد يُستبعد اليوم.";
      }
      nextBtn.textContent = Game.getResult() ? "🏆 عرض النتيجة" : "🌙 الليلة التالية";
    }
    UI.showScreen("day-result");
  }

  function onResultNext() {
    if (resultMode === "revote") {
      showVoteHandover();
      return;
    }
    if (Game.getResult()) {
      WinUI.show();
      return;
    }
    const res = Game.finishDay();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    NightUI.start();
  }

  /* ---------- التهيئة ---------- */
  function init() {
    $("btn-day-pause").addEventListener("click", onPause);
    $("btn-day-end-discussion").addEventListener("click", onEndDiscussion);
    $("nominee-list").addEventListener("click", onNomineeClick);
    $("btn-nominate-all").addEventListener("click", onNominateAll);
    $("btn-start-voting").addEventListener("click", onStartVoting);
    $("btn-vote-ready").addEventListener("click", onVoteReady);
    $("vote-targets").addEventListener("click", onVoteClick);
    $("btn-vote-confirm").addEventListener("click", onVoteConfirm);
    $("btn-vote-abstain").addEventListener("click", onVoteAbstain);
    $("btn-vote-next").addEventListener("click", onVoteNext);
    $("btn-day-result-next").addEventListener("click", onResultNext);
  }

  function pauseTimer() {
    if (Countdown.id !== null) Countdown.pause();
  }

  function resumeTimer() {
    if (Countdown.id !== null) Countdown.resume();
  }

  function stopTimer() {
    Countdown.stop();
  }

  return { init, start, pauseTimer, resumeTimer, stopTimer };
  })();