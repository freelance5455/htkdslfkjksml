import { formatMoney } from "./shared-utils.js";
// =====================================================
// NetEarn Pro
// TASK HISTORY SYSTEM
// FINAL CLEAN VERSION
// =====================================================


import {
    auth,
    db
}
from "./firebase.js";


import {
    collection,
    query,
    where,
    getDocs
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


import {
    onAuthStateChanged
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";



// =====================================================
// ELEMENTS
// =====================================================

const historyList =
    document.getElementById(
        "historyList"
    );


const totalReward =
    document.getElementById(
        "totalReward"
    );


const approvedCount =
    document.getElementById(
        "approvedCount"
    );


const pendingCount =
    document.getElementById(
        "pendingCount"
    );


const rejectedCount =
    document.getElementById(
        "rejectedCount"
    );


const historyCount =
    document.getElementById(
        "historyCount"
    );



// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    async user => {

        if (!user) {

            location.href =
                "index.html";

            return;

        }


        await loadHistory(
            user.uid
        );

    }
);



// =====================================================
// ⚡ TASK HISTORY CACHE
// =====================================================
function restoreTaskHistoryCache(uid) {
    try {
        const raw = localStorage.getItem(`netearnTaskHistoryCache_${uid}`);
        if (!raw) return false;
        const cached = JSON.parse(raw);
        if (!cached || !cached.html) return false;
        historyList.innerHTML = cached.html;
        totalReward.textContent = cached.totalReward || "৳0";
        approvedCount.textContent = cached.approved ?? "0";
        pendingCount.textContent = cached.pending ?? "0";
        rejectedCount.textContent = cached.rejected ?? "0";
        historyCount.textContent = cached.historyCount ?? "0";
        return true;
    } catch (_) {
        return false;
    }
}

function saveTaskHistoryCache(uid, values) {
    try {
        localStorage.setItem(`netearnTaskHistoryCache_${uid}`, JSON.stringify({
            ...values, cachedAt: Date.now()
        }));
    } catch (_) {}
}

// =====================================================
// LOAD HISTORY
// =====================================================

async function loadHistory(uid) {


    try {

        // ⚡ Restore the last successful history instantly.
        restoreTaskHistoryCache(uid);


        // =============================================
        // USER SUBMISSIONS
        // =============================================

        const historyQuery =
            query(

                collection(
                    db,
                    "taskSubmissions"
                ),

                where(
                    "userUid",
                    "==",
                    uid
                )

            );


        const historySnap =
            await getDocs(
                historyQuery
            );



        historyList.innerHTML =
            "";



        let reward =
            0;


        let approved =
            0;


        let pending =
            0;


        let rejected =
            0;



        // =============================================
        // NO HISTORY
        // =============================================

        if (
            historySnap.empty
        ) {

            totalReward.textContent =
                "৳0";


            approvedCount.textContent =
                "0";


            pendingCount.textContent =
                "0";


            rejectedCount.textContent =
                "0";


            historyCount.textContent =
                "0";


            historyList.innerHTML = `

                <div class="history-empty">

                    <div class="empty-icon">
                        📭
                    </div>

                    <h3>
                        No Task History
                    </h3>

                    <p>
                        আপনার কোনো Task activity এখনো নেই।
                    </p>

                    <a
                        href="tasks.html"
                        class="empty-button"
                    >
                        💼 Browse Tasks
                    </a>

                </div>

            `;

            return;

        }



        // =============================================
        // CONVERT + SORT
        // =============================================

        const historyData =
            [];


        historySnap.forEach(
            historyDoc => {

                const data =
                    historyDoc.data();


                historyData.push({

                    id:
                        historyDoc.id,

                    ...data

                });

            }
        );



        historyData.sort(
            (
                a,
                b
            ) => {

                const dateA =
                    getTimestamp(
                        a
                    );


                const dateB =
                    getTimestamp(
                        b
                    );


                return (
                    dateB -
                    dateA
                );

            }
        );



        // =============================================
        // PROCESS
        // =============================================

        historyData.forEach(
            data => {


                const status =
                    String(
                        data.status ||
                        "pending"
                    )
                    .trim()
                    .toLowerCase();



                const taskName =
                    escapeHTML(

                        data.taskName ||
                        data.name ||
                        "Task"

                    );



                const taskId =
                    escapeHTML(

                        data.taskId ||
                        ""

                    );



                const taskReward =
                    Number(
                        data.reward ||
                        data.rewardPaid ||
                        0
                    );



                // =====================================
                // STATUS
                // =====================================

                let statusClass =
                    "pending";


                let statusText =
                    "⏳ Pending";


                if (
                    status ===
                    "approved" ||
                    status ===
                    "completed"
                ) {

                    approved++;


                    reward +=
                        taskReward;


                    statusClass =
                        "approved";


                    statusText =
                        "✓ Approved";

                }


                else if (
                    status ===
                    "rejected"
                ) {

                    rejected++;


                    statusClass =
                        "rejected";


                    statusText =
                        "× Rejected";

                }


                else {

                    pending++;


                    statusClass =
                        "pending";


                    statusText =
                        "⏳ Pending";

                }



                // =====================================
                // DATE
                // =====================================

                const dateText =
                    formatDate(
                        data
                    );



                // =====================================
                // REJECTION REASON
                // =====================================

                let rejectionHTML =
                    "";


                if (
                    status ===
                    "rejected" &&
                    data.rejectionReason
                ) {

                    rejectionHTML = `

                        <div class="rejection-reason">

                            <span>
                                Reason
                            </span>

                            <p>
                                ${escapeHTML(
                                    data.rejectionReason
                                )}
                            </p>

                        </div>

                    `;

                }



                // =====================================
                // CARD
                // =====================================

                historyList.innerHTML += `

                    <article
                        class="history-card ${statusClass}"
                    >


                        <div
                            class="history-card-top"
                        >


                            <div
                                class="history-task-icon"
                            >
                                📱
                            </div>



                            <div
                                class="history-task-info"
                            >

                                <h3>
                                    ${taskName}
                                </h3>

                                <span>
                                    ${
                                        taskId
                                        ?
                                        "Task ID: " +
                                        taskId
                                        :
                                        "NetEarn Pro Task"
                                    }
                                </span>

                            </div>



                            <span
                                class="history-status ${statusClass}"
                            >
                                ${statusText}
                            </span>


                        </div>



                        <div
                            class="history-card-bottom"
                        >


                            <div
                                class="history-reward"
                            >

                                <small>
                                    Reward
                                </small>

                                <strong>
                                    ৳${formatMoney(
                                        taskReward
                                    )}
                                </strong>

                            </div>



                            <div
                                class="history-date"
                            >

                                <small>
                                    Date
                                </small>

                                <span>
                                    ${dateText}
                                </span>

                            </div>


                        </div>



                        ${rejectionHTML}


                    </article>

                `;

            }
        );



        // =============================================
        // UPDATE SUMMARY
        // =============================================

        totalReward.textContent =
            "৳" +
            formatMoney(
                reward
            );


        approvedCount.textContent =
            approved;


        pendingCount.textContent =
            pending;


        rejectedCount.textContent =
            rejected;


        historyCount.textContent =
            historyData.length;

        // Save the complete rendered result for the next visit.
        saveTaskHistoryCache(uid, {
            html: historyList.innerHTML,
            totalReward: totalReward.textContent,
            approved,
            pending,
            rejected,
            historyCount: historyData.length
        });



    }

    catch (error) {


        console.error(
            "❌ Task History Error:",
            error
        );


        historyList.innerHTML = `

            <div class="history-empty error">

                <div class="empty-icon">
                    ⚠️
                </div>

                <h3>
                    History Load Failed
                </h3>

                <p>
                    ${escapeHTML(
                        error.message
                    )}
                </p>

                <button
                    class="empty-button"
                    onclick="location.reload()"
                >
                    🔄 Try Again
                </button>

            </div>

        `;

    }

}



// =====================================================
// TIMESTAMP
// =====================================================

function getTimestamp(
    data
) {


    const timestamp =
        data.approvedAt ||
        data.createdAt ||
        data.submittedAt ||
        data.rejectedAt;


    if (
        timestamp &&
        typeof timestamp.toDate ===
        "function"
    ) {

        return timestamp
            .toDate()
            .getTime();

    }


    return 0;

}



// =====================================================
// DATE FORMAT
// =====================================================

function formatDate(
    data
) {


    const timestamp =
        data.approvedAt ||
        data.createdAt ||
        data.submittedAt ||
        data.rejectedAt;


    if (
        timestamp &&
        typeof timestamp.toDate ===
        "function"
    ) {

        return timestamp
            .toDate()
            .toLocaleString(
                "en-US",
                {
                    day:
                        "2-digit",

                    month:
                        "short",

                    year:
                        "numeric",

                    hour:
                        "2-digit",

                    minute:
                        "2-digit"

                }
            );

    }


    return "Date unavailable";

}



// =====================================================
// MONEY
// =====================================================
// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(
    value
) {


    return String(
        value
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}



// =====================================================
// FINAL
// =====================================================

console.log(
    "===================================="
);

console.log(
    "📋 NetEarn Pro Task History"
);

console.log(
    "✅ taskSubmissions Connected"
);

console.log(
    "💰 Reward History Ready"
);

console.log(
    "📊 Approved / Pending / Rejected Ready"
);

console.log(
    "===================================="
);