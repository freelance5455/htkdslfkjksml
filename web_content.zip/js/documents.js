
/* My Study Life V3 - Document Library
   Stores Blob/File data in IndexedDB, recreates object URLs on demand,
   supports search, favorites, rename, sorting, subject filtering and image rotation.
*/
const MSL_DB = "MyStudyLifeDB";
const MSL_STORE = "documents";
let dbPromise;
let currentSubject = "all";
let currentSearch = "";
let currentSort = "recent";
let currentEditorId = null;
let editorRotation = 0;
let editorFavorite = false;
let editorImage = null;
let activeObjectUrls = [];

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(MSL_DB, 2);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      let store;
      if (!db.objectStoreNames.contains(MSL_STORE)) {
        store = db.createObjectStore(MSL_STORE, { keyPath: "id", autoIncrement: true });
      } else {
        store = e.target.transaction.objectStore(MSL_STORE);
      }
      if (!store.indexNames.contains("subject")) store.createIndex("subject", "subject", {unique:false});
      if (!store.indexNames.contains("created")) store.createIndex("created", "created", {unique:false});
      if (!store.indexNames.contains("favorite")) store.createIndex("favorite", "favorite", {unique:false});
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function getAllDocs() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(MSL_STORE, "readonly");
    const req = tx.objectStore(MSL_STORE).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function getDoc(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(MSL_STORE, "readonly").objectStore(MSL_STORE).get(Number(id));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function putDoc(doc) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(MSL_STORE, "readwrite").objectStore(MSL_STORE).put(doc);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function addDoc(doc) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(MSL_STORE, "readwrite").objectStore(MSL_STORE).add(doc);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function deleteDoc(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(MSL_STORE, "readwrite").objectStore(MSL_STORE).delete(Number(id));
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

function fmtBytes(bytes) {
  if (!bytes) return "0 Ko";
  const units = ["octets","Ko","Mo","Go"];
  let i = 0, n = bytes;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
}

function cleanupUrls() {
  activeObjectUrls.forEach(u => URL.revokeObjectURL(u));
  activeObjectUrls = [];
}

function createUrl(blob) {
  const url = URL.createObjectURL(blob);
  activeObjectUrls.push(url);
  return url;
}

async function refreshDocuments() {
  const list = document.getElementById("documentsList");
  if (!list) return;
  cleanupUrls();
  let docs = await getAllDocs();

  if (currentSubject !== "all") {
    docs = docs.filter(d => (d.subject || "Autres") === currentSubject);
  }
  const q = currentSearch.trim().toLowerCase();
  if (q) docs = docs.filter(d =>
    (d.name || "").toLowerCase().includes(q) ||
    (d.subject || "").toLowerCase().includes(q)
  );

  docs.sort((a,b) => {
    if (currentSort === "name") return (a.name || "").localeCompare(b.name || "", "fr");
    if (currentSort === "size") return (b.size || 0) - (a.size || 0);
    if (currentSort === "favorite") return Number(b.favorite) - Number(a.favorite);
    return (b.created || 0) - (a.created || 0);
  });

  list.innerHTML = "";
  if (!docs.length) {
    list.innerHTML = `<div class="empty-state">
      <div class="empty-icon">📚</div>
      <h3>Aucun document</h3>
      <p>Importe une photo ou un PDF pour commencer ta bibliothèque.</p>
    </div>`;
  } else {
    docs.forEach(doc => {
      const card = document.createElement("article");
      card.className = "document-card";
      const icon = doc.type?.includes("pdf") ? "📕" : "🖼️";
      const thumb = doc.type?.startsWith("image/") && doc.blob
        ? `<img src="${createUrl(doc.blob)}" alt="">`
        : `<span class="doc-icon">${icon}</span>`;
      card.innerHTML = `
        <div class="doc-thumb">${thumb}</div>
        <div class="doc-main">
          <div class="doc-title-row">
            <h3 title="${escapeHtml(doc.name || "")}">${escapeHtml(doc.name || "Document")}</h3>
            <button class="favorite-btn ${doc.favorite ? "active":""}" data-action="favorite" data-id="${doc.id}" aria-label="Favori">${doc.favorite ? "★" : "☆"}</button>
          </div>
          <p>${escapeHtml(doc.subject || "Autres")} · ${fmtBytes(doc.size || 0)}</p>
          <div class="doc-actions">
            <button class="mini-btn" data-action="open" data-id="${doc.id}">Ouvrir</button>
            <button class="mini-btn" data-action="edit" data-id="${doc.id}">${doc.type?.includes("pdf") ? "Détails" : "Modifier"}</button>
            <button class="mini-btn" data-action="rename" data-id="${doc.id}">Renommer</button>
            <button class="mini-btn danger" data-action="delete" data-id="${doc.id}">Supprimer</button>
          </div>
        </div>`;
      list.appendChild(card);
    });
  }
  updateStorageStats(await getAllDocs());
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

async function updateStorageStats(docs) {
  const total = docs.reduce((s,d) => s + (d.size || 0), 0);
  const count = docs.length;
  const sizeEl = document.getElementById("storageSize");
  const countEl = document.getElementById("storageCount");
  const bar = document.getElementById("storageBar");
  if (sizeEl) sizeEl.textContent = fmtBytes(total);
  if (countEl) countEl.textContent = `${count} document${count > 1 ? "s":""}`;
  if (bar) bar.style.width = `${Math.min(100, Math.max(5, count * 6))}%`;
}

async function importFiles(files, subject = currentSubject === "all" ? "Autres" : currentSubject) {
  const arr = Array.from(files || []);
  if (!arr.length) return;
  for (const file of arr) {
    if (!file.type.startsWith("image/") && file.type !== "application/pdf") {
      toast("Format non pris en charge. Utilise une image ou un PDF.");
      continue;
    }
    await addDoc({
      name: file.name || `Document ${Date.now()}`,
      type: file.type,
      size: file.size || 0,
      subject,
      blob: file,
      favorite: false,
      created: Date.now()
    });
  }
  toast(`${arr.length} fichier(s) ajouté(s).`);
  await refreshDocuments();
}

async function openDocument(id) {
  const doc = await getDoc(id);
  if (!doc?.blob) {
    toast("Document introuvable.");
    return;
  }
  const url = createUrl(doc.blob);
  const win = window.open(url, "_blank");
  if (!win) {
    const a = document.createElement("a");
    a.href = url; a.target = "_blank"; a.rel = "noopener";
    a.click();
  }
}

async function toggleFavorite(id) {
  const doc = await getDoc(id);
  if (!doc) return;
  doc.favorite = !doc.favorite;
  await putDoc(doc);
  await refreshDocuments();
}

async function removeDocument(id) {
  const doc = await getDoc(id);
  if (!doc) return;
  if (!confirm(`Supprimer « ${doc.name} » ?`)) return;
  await deleteDoc(id);
  toast("Document supprimé.");
  await refreshDocuments();
}

function showRename(id) {
  currentEditorId = id;
  getDoc(id).then(doc => {
    if (!doc) return;
    document.getElementById("renameInput").value = doc.name || "";
    document.getElementById("renameModal")?.classList.remove("hidden");
    document.getElementById("renameInput")?.focus();
  });
}

async function saveRename() {
  if (!currentEditorId) return;
  const doc = await getDoc(currentEditorId);
  if (!doc) return;
  const value = document.getElementById("renameInput").value.trim();
  if (!value) return;
  doc.name = value;
  await putDoc(doc);
  document.getElementById("renameModal")?.classList.add("hidden");
  toast("Nom modifié.");
  await refreshDocuments();
}

async function showEditor(id) {
  const doc = await getDoc(id);
  if (!doc) return;
  currentEditorId = id;
  editorRotation = doc.rotation || 0;
  editorFavorite = !!doc.favorite;
  document.getElementById("editorTitle").textContent = doc.name || "Modifier le document";
  document.getElementById("documentEditorModal")?.classList.remove("hidden");

  const canvas = document.getElementById("editCanvas");
  const pdfPreview = document.getElementById("pdfEditPreview");
  if (doc.type?.startsWith("image/")) {
    canvas.classList.remove("hidden");
    pdfPreview.classList.add("hidden");
    editorImage = new Image();
    editorImage.onload = () => drawEditorCanvas();
    editorImage.src = createUrl(doc.blob);
  } else {
    canvas.classList.add("hidden");
    pdfPreview.classList.remove("hidden");
  }
  updateFavoriteButton();
}

function drawEditorCanvas() {
  const canvas = document.getElementById("editCanvas");
  if (!canvas || !editorImage) return;
  const ctx = canvas.getContext("2d");
  const angle = ((editorRotation % 360) + 360) % 360;
  const quarter = angle === 90 || angle === 270;
  const max = 900;
  const scale = Math.min(1, max / Math.max(editorImage.width, editorImage.height));
  const w = Math.round(editorImage.width * scale);
  const h = Math.round(editorImage.height * scale);
  canvas.width = quarter ? h : w;
  canvas.height = quarter ? w : h;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.save();
  ctx.translate(canvas.width/2, canvas.height/2);
  ctx.rotate(angle * Math.PI/180);
  ctx.drawImage(editorImage, -w/2, -h/2, w, h);
  ctx.restore();
}

function updateFavoriteButton() {
  const b = document.getElementById("favoriteEditBtn");
  if (b) b.textContent = editorFavorite ? "★ Favori" : "☆ Favori";
}

async function saveEditor() {
  if (!currentEditorId) return;
  const doc = await getDoc(currentEditorId);
  if (!doc) return;
  doc.favorite = editorFavorite;
  if (doc.type?.startsWith("image/") && editorImage) {
    const canvas = document.getElementById("editCanvas");
    const blob = await new Promise(resolve => canvas.toBlob(resolve, doc.type || "image/jpeg", 0.92));
    if (blob) {
      doc.blob = blob;
      doc.size = blob.size;
      doc.rotation = editorRotation;
    }
  }
  await putDoc(doc);
  document.getElementById("documentEditorModal")?.classList.add("hidden");
  toast("Modifications enregistrées.");
  await refreshDocuments();
}

function setupDocumentUI() {
  document.getElementById("documentsList")?.addEventListener("click", async e => {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const id = Number(btn.dataset.id);
    const action = btn.dataset.action;
    if (action === "open") await openDocument(id);
    if (action === "favorite") await toggleFavorite(id);
    if (action === "delete") await removeDocument(id);
    if (action === "rename") showRename(id);
    if (action === "edit") showEditor(id);
  });

  document.getElementById("documentSearch")?.addEventListener("input", e => {
    currentSearch = e.target.value;
    refreshDocuments();
  });
  document.getElementById("documentSort")?.addEventListener("change", e => {
    currentSort = e.target.value;
    refreshDocuments();
  });
  document.querySelectorAll("[data-subject-filter]").forEach(btn => {
    btn.addEventListener("click", () => {
      currentSubject = btn.dataset.subjectFilter || "all";
      document.querySelectorAll("[data-subject-filter]").forEach(b => b.classList.toggle("active", b === btn));
      refreshDocuments();
    });
  });

  const picker = document.getElementById("filePicker");
  const camera = document.getElementById("cameraPicker");
  // Single event handler per input to avoid V2 double-import behavior.
  if (picker) picker.onchange = async e => {
    await importFiles(e.target.files, picker.dataset.subject || currentSubject);
    picker.value = "";
  };
  if (camera) camera.onchange = async e => {
    await importFiles(e.target.files, camera.dataset.subject || currentSubject);
    camera.value = "";
  };

  document.getElementById("closeEditorBtn")?.addEventListener("click", () => document.getElementById("documentEditorModal").classList.add("hidden"));
  document.getElementById("cancelEditBtn")?.addEventListener("click", () => document.getElementById("documentEditorModal").classList.add("hidden"));
  document.getElementById("rotateLeftBtn")?.addEventListener("click", () => { editorRotation -= 90; drawEditorCanvas(); });
  document.getElementById("rotateRightBtn")?.addEventListener("click", () => { editorRotation += 90; drawEditorCanvas(); });
  document.getElementById("resetEditBtn")?.addEventListener("click", () => { editorRotation = 0; drawEditorCanvas(); });
  document.getElementById("favoriteEditBtn")?.addEventListener("click", () => { editorFavorite = !editorFavorite; updateFavoriteButton(); });
  document.getElementById("saveEditBtn")?.addEventListener("click", saveEditor);

  document.getElementById("closeRenameBtn")?.addEventListener("click", () => document.getElementById("renameModal").classList.add("hidden"));
  document.getElementById("cancelRenameBtn")?.addEventListener("click", () => document.getElementById("renameModal").classList.add("hidden"));
  document.getElementById("saveRenameBtn")?.addEventListener("click", saveRename);
  document.getElementById("renameInput")?.addEventListener("keydown", e => { if (e.key === "Enter") saveRename(); });

  refreshDocuments().catch(err => console.error("V3 documents:", err));
}

document.addEventListener("DOMContentLoaded", setupDocumentUI);
window.MSLDocumentsV3 = { refreshDocuments, importFiles, openDocument };
