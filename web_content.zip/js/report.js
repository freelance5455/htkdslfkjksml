/* UrbaAlerte — signalement (assistant 3 étapes), détail, SMS hors ligne */
(function(w){
'use strict';
const UA=w.UA,S=UA.S,C=w.URBA_CONFIG,ACT=UA.ACT,R=UA.R;
let W=null;
const PIN='<svg viewBox="0 0 40 50"><defs><linearGradient id="pg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff9a55"/><stop offset="1" stop-color="#d84315"/></linearGradient></defs><path d="M20 49C20 49 3 31 3 19a17 17 0 0134 0c0 12-17 30-17 30z" fill="url(#pg)" stroke="#fff" stroke-width="2"/><circle cx="20" cy="19" r="6.5" fill="#fff"/></svg>';
const reset=()=>{W={step:1,type:null,desc:'',media:[],lat:null,lng:null,acc:null,adjusted:false,map:null}};
ACT.report=()=>{closeSheet();const today=UA.mine().filter(r=>Date.now()-r.created<864e5).length;
 if(today>=C.MAX_PER_DAY){toast(`Limite de ${C.MAX_PER_DAY} signalements par jour atteinte.`,'bad',4000,'alert');return}reset();UA.go('report')};
R.report=()=>{if(!W)reset();const sc=$('#s-report');sc.className='screen on';
 const st=W.step;sc.innerHTML=`<div class="scroll" style="padding-bottom:30px"><div class="top"><button class="iconbtn" data-act="rback" aria-label="Retour">${I(st>1?'chevl':'x')}</button><div style="text-align:center"><div class="eyebrow">Étape ${st} / 3</div><h2>${['Type d’incident','Preuves & description','Localisation'][st-1]}</h2></div><span style="width:44px"></span></div>
 <div class="steps"><i class="on"></i><i class="${st>1?'on':''}"></i><i class="${st>2?'on':''}"></i></div><div id="wb"></div></div>`;
 [step1,step2,step3][st-1]()};
UA.leave.report=()=>{if(W&&W.map){W.map.destroy();W.map=null}};
ACT.rback=()=>{if(W.step>1){UA.leave.report();W.step--;R.report()}else{UA.go('home')}};
function step1(){$('#wb').innerHTML=`<p class="mut" style="margin:0 0 14px">Que voulez-vous signaler ?</p><div class="types">${TYPES.map(t=>`<button class="type ${W.type===t.id?'on':''}" data-act="ptype" data-t="${t.id}"><div class="ic" style="color:${t.color};border-color:${t.color}66;background:${t.color}1c">${I(t.icon)}</div><div><b>${esc(t.label)}</b><br><small>${esc(t.desc)}</small></div></button>`).join('')}</div><button class="btn pri blk" style="margin-top:18px" data-act="pnext" ${W.type?'':'disabled'}>Continuer ${I('chev')}</button>`}
ACT.ptype=b=>{W.type=b.dataset.t;step1()};
function mediaGrid(){const g=$('#mgrid');if(!g)return;g.innerHTML=W.media.map((m,i)=>`<div class="mi">${m.kind==='image'?`<img src="${m.url}" alt="">`:`<video src="${m.url}" muted playsinline preload="metadata"></video><span class="vb">VIDÉO</span>`}<button class="x" data-act="mdel" data-i="${i}" aria-label="Retirer">${I('x')}</button></div>`).join('')+
 (W.media.length<4?`<button class="mi addm" data-act="madd" data-k="photo">${I('camera')}Photo</button><button class="mi addm" data-act="madd" data-k="video">${I('video')}Vidéo</button><button class="mi addm" data-act="madd" data-k="gal">${I('image')}Galerie</button>`:'')}
function step2(){const t=TYPE(W.type);$('#wb').innerHTML=`<div class="card" style="padding:10px 14px;display:flex;gap:10px;align-items:center;margin-bottom:14px"><span style="color:${t.color}">${I(t.icon)}</span><b>${esc(t.label)}</b></div>
 <div class="eyebrow">Photo / vidéo (jusqu’à 4)</div><div class="media" id="mgrid"></div>
 <input type="file" id="f-photo" accept="image/*" capture="environment" hidden><input type="file" id="f-video" accept="video/*" capture="environment" hidden><input type="file" id="f-gal" accept="image/*,video/*" multiple hidden>
 <label class="field" style="margin-top:16px"><span>Description</span><div class="in"><textarea id="pd" maxlength="500" placeholder="Décrivez le problème : où exactement, depuis quand, quel danger ?">${esc(W.desc)}</textarea></div><div class="hint" id="pc"></div></label>
 <button class="btn pri blk" data-act="pnext2">Continuer ${I('chev')}</button>`;
 mediaGrid();const upd=()=>{const n=W.desc.trim().length,ok=n>=C.MIN_DESC;$('#pc').className='hint'+(ok?'':' bad');$('#pc').textContent=ok?n+' / 500':`${n} / ${C.MIN_DESC} caractères minimum`};
 $('#pd').oninput=e=>{W.desc=e.target.value;upd()};upd();
 ['photo','video','gal'].forEach(k=>$('#f-'+k).onchange=async e=>{for(const f of Array.from(e.target.files)){if(W.media.length>=4)break;await addFile(f)}e.target.value='';mediaGrid()})}
async function addFile(f){try{if(f.type.startsWith('image/')){const b=await fileToImageBlob(f,1280);W.media.push({kind:'image',blob:b,url:URL.createObjectURL(b)})}
 else if(f.type.startsWith('video/')){if(f.size>40*1024*1024){toast('Vidéo trop lourde (40 Mo max).','bad',3500,'alert');return}W.media.push({kind:'video',blob:f,url:URL.createObjectURL(f)})}}catch(e){toast('Fichier illisible','bad',3000,'alert')}}
ACT.madd=b=>$('#f-'+b.dataset.k).click();
ACT.mdel=b=>{W.media.splice(+b.dataset.i,1);mediaGrid()};
ACT.pnext=()=>{if(!W.type)return;W.step=2;R.report()};
ACT.pnext2=()=>{if(W.desc.trim().length<C.MIN_DESC){toast(`Décrivez l’incident (${C.MIN_DESC} caractères minimum).`,'bad',3200,'alert');return}W.step=3;R.report()};
function gpsText(){const g=GEO.last;if(W.adjusted)return['warn','Position ajustée manuellement'];if(GEO.status==='loading'&&!g)return['warn','Recherche du signal GPS…'];if(g&&g.src==='gps')return['','Position GPS détectée'+(g.acc?' · précision ±'+Math.round(g.acc)+' m':'')];if(g)return['warn','Dernière position connue — ajustez si besoin'];return['off',(GEO.err||'GPS indisponible')+' — placez le repère sur la carte']}
function step3(){const p=GEO.last||GEO.DEFAULT;if(W.lat==null){W.lat=p.lat;W.lng=p.lng}const t=TYPE(W.type);
 $('#wb').innerHTML=`<div class="pm hud" id="pm"><div class="pin-fixed">${PIN}</div></div><div class="gpsbar" id="gb"></div><p class="hint" style="margin:8px 2px 14px">Déplacez la carte pour placer le repère exactement sur l’incident.</p>
 <div class="card" style="padding:14px;margin-bottom:16px"><div style="display:flex;gap:10px;align-items:center"><span style="color:${t.color}">${I(t.icon)}</span><b>${esc(t.label)}</b>${W.media.length?`<span class="mut" style="margin-left:auto;font-size:12px">${W.media.length} média${W.media.length>1?'s':''}</span>`:''}</div><p class="mut" style="margin:8px 0 0;font-size:13px">${esc(W.desc.trim())}</p></div>
 ${UA.online()?'':`<div class="card" style="padding:10px 14px;margin-bottom:12px;font-size:12.5px;border-color:var(--warn)">${I('wifioff')} Hors ligne : le signalement sera envoyé dès la reconnexion. Vous pourrez aussi l’envoyer par SMS.</div>`}
 <button class="btn hot blk" id="psend" data-act="psend">${I('send')} Envoyer le signalement</button>`;
 const gb=()=>{const g=gpsText();$('#gb').innerHTML=`<span class="chip ${g[0]}" style="border:0;background:none;padding:0"><i class="d"></i></span><span style="flex:1">${g[1]}</span><span class="mono mut" style="font-size:11px">${W.lat.toFixed(5)}, ${W.lng.toFixed(5)}</span><button class="btn gh sm" data-act="pgps" aria-label="Recentrer">${I('locate')}</button>`};
 W.gb=gb;gb();
 W.map=new UMap($('#pm'),{lat:W.lat,lng:W.lng,zoom:17,maxZ:19,tileUrl:C.TILE_URL,hud:false,onMove:(la,ln)=>{W.lat=la;W.lng=ln;const g=GEO.last;if(g&&haversine(g.lat,g.lng,la,ln)>.02)W.adjusted=true;gb()}});
 W.map.user=GEO.last;W.map.start();
 if(!(GEO.last&&GEO.last.src==='gps'&&Date.now()-GEO.last.t<30000)){GEO.once().then(g=>{if(!W||!W.map)return;W.acc=g.acc;W.map.user=g;if(!W.adjusted){W.map.setCenter(g.lat,g.lng,17);W.adjusted=false;W.gb()}}).catch(()=>{if(W&&W.gb)W.gb()});gb()}
 else{W.acc=GEO.last.acc;if(!W.adjusted)W.map.setCenter(GEO.last.lat,GEO.last.lng,17),W.adjusted=false}}
ACT.pgps=async()=>{try{const g=await GEO.once();W.adjusted=false;W.map.user=g;W.map.setCenter(g.lat,g.lng,17);W.adjusted=false;W.gb()}catch(e){toast(esc(e.message),'bad',3500,'alert')}};
ACT.psend=async b=>{if(b.disabled)return;if(W.desc.trim().length<C.MIN_DESC)return;b.disabled=true;
 const now=Date.now(),id=uid(),ref=refCode(),mids=[];
 try{for(const m of W.media){const mid=uid();await DB.put('media',{id:mid,rid:id,kind:m.kind,blob:m.blob});mids.push(mid)}
  const r={id,ref,userId:S.user.id,type:W.type,desc:W.desc.trim(),lat:W.lat,lng:W.lng,acc:W.acc,status:'EN_ATTENTE',created:now,mediaIds:mids,sync:'pending',demo:false,fresh:now,history:[{s:'EN_ATTENTE',t:now}]};
  if(UA.online()){try{if(API.enabled){const x=await API.createIncident(r);if(x&&x.id){r.remoteId=x.id;for(const m of W.media)await API.uploadMedia(x.id,m.blob).catch(()=>{})}}r.sync='synced';r.syncedAt=Date.now()}catch(e){r.sync='pending'}}
  await UA.addReport(r,true);vibrate(40);const pend=r.sync==='pending';UA.leave.report();W=null;UA.go('home');
  setTimeout(()=>sheet(`<div style="text-align:center"><div class="ic" style="width:72px;height:72px;margin:6px auto 12px;border-radius:22px;color:${pend?'var(--warn)':'var(--ok)'};border-color:currentColor;background:rgba(255,255,255,.05)">${I(pend?'wifioff':'check').replace('class="i ','class="i " style="width:34px;height:34px" data-x="')}</div><h2>${pend?'Enregistré hors ligne':'Signalement envoyé'}</h2><p class="mut">${pend?'Il sera transmis automatiquement dès le retour de la connexion. Vous pouvez aussi l’envoyer maintenant par SMS.':'Les services de la commune vont le traiter. Vous serez notifié à chaque changement de statut.'}</p><div class="sms" style="margin:12px 0">Référence : ${ref}</div>${pend?`<button class="btn hot blk" data-act="smsrep" data-id="${id}">${I('sms')} Envoyer par SMS</button>`:''}<button class="btn ${pend?'gh':'pri'} blk" style="margin-top:10px" data-act="open" data-id="${id}">Suivre mon signalement</button></div>`),350)
 }catch(e){console.error(e);b.disabled=false;toast('Échec de l’enregistrement : '+esc(e.message),'bad',4500,'alert')}};

/* ---------- détail ---------- */
UA.openReport=async id=>{const r=S.reports.find(x=>x.id===id);if(!r){toast('Signalement introuvable','bad',2500,'alert');return}const t=TYPE(r.type);
 const hist=r.history&&r.history.length?r.history:[{s:'EN_ATTENTE',t:r.created}];const seq=r.status==='REJETE'?['EN_ATTENTE','REJETE']:STATUTS;const cur=seq.indexOf(r.status);
 const times={};hist.forEach(h=>times[h.s]=h.t);
 const tl=seq.map((s,i)=>`<div class="s ${i<cur?'done':i===cur?'done cur':''}"><b>${STATUT_LABEL[s]}</b><small>${times[s]?fdate(times[s]):(i>cur?'à venir':'')}</small></div>`).join('');
 const d=UA.dist(r);
 sheet(`<div id="dm"></div><div style="display:flex;gap:12px;align-items:center;margin:4px 0 12px"><div class="ic" style="color:${t.color};border-color:${t.color}66;background:${t.color}1c">${I(t.icon)}</div><div style="flex:1"><h2>${esc(t.label)}</h2><div class="mut mono" style="font-size:12px">${esc(r.ref)}${r.demo?' · <span class="demo">DÉMO</span>':''}</div></div><span class="st ${r.status}">${STATUT_LABEL[r.status]}</span></div>
 <p style="margin:0 0 12px">${esc(r.desc)}</p>
 <div class="card" style="padding:12px 14px;margin-bottom:14px;font-size:13px"><div style="display:flex;gap:10px;align-items:center">${I('pin')}<span class="mono">${r.lat.toFixed(5)}, ${r.lng.toFixed(5)}</span><span class="mut" style="margin-left:auto">${fmtKm(d)}</span></div><div class="mut" style="margin-top:6px">Signalé ${ago(r.created)} · ${fdate(r.created)}${r.sync==='pending'?' · <span style="color:var(--warn)">en attente d’envoi</span>':''}</div></div>
 <div class="eyebrow" style="margin-bottom:8px">Suivi</div><div class="tl">${tl}</div>
 <div style="display:grid;gap:10px;margin-top:10px"><button class="btn gh blk" data-act="showmap" data-id="${r.id}">${I('map')} Voir sur la carte</button>${r.sync==='pending'?`<button class="btn hot blk" data-act="smsrep" data-id="${r.id}">${I('sms')} Envoyer par SMS</button>`:''}</div>`,{title:'Détail'});
 if(r.mediaIds&&r.mediaIds.length){const box=$('#dm');box.className='media';box.style.marginTop='0';box.style.marginBottom='12px';
  for(const mid of r.mediaIds){const m=await DB.get('media',mid);if(!m)continue;const u=await UA.mediaURL(mid);box.insertAdjacentHTML('beforeend',`<div class="mi">${m.kind==='image'?`<img src="${u}" alt="">`:`<video src="${u}" controls playsinline preload="metadata"></video>`}</div>`)}}};
ACT.open=b=>UA.openReport(b.dataset.id);
ACT.showmap=b=>{const r=S.reports.find(x=>x.id===b.dataset.id);closeSheet();UA.go('map');if(r)setTimeout(()=>{S.filter=null;UA.mapSync();UA.map.flyTo(r.lat,r.lng,16);UA.selectMarker(r.id)},200)};

/* ---------- SMS (mode hors ligne) ---------- */
UA.smsText=r=>{const head=`URBAALERTE|${r.ref}|${TYPE(r.type).code}|${r.lat.toFixed(5)},${r.lng.toFixed(5)}|`;return head+r.desc.replace(/\s+/g,' ').slice(0,Math.max(0,158-head.length))};
UA.smsHref=msg=>{const ios=/iPhone|iPad|iPod/i.test(navigator.userAgent);return 'sms:'+(S.cfg.gateway||'')+(ios?'&':'?')+'body='+encodeURIComponent(msg)};
function smsSheet(msg,title){sheet(`<p class="mut" style="margin:0 0 12px;font-size:13px">Sans internet, votre message est envoyé par SMS ordinaire (frais de votre opérateur). Votre application SMS s’ouvrira avec le texte prêt à envoyer.</p><div class="sms">${esc(msg)}</div><div class="hint">${msg.length} caractères${S.cfg.gateway?' · destinataire '+esc(S.cfg.gateway):' · aucun numéro de passerelle configuré (Profil)'}</div>
 <a class="btn hot blk" style="margin-top:14px;text-decoration:none" href="${esc(UA.smsHref(msg))}">${I('sms')} Ouvrir l’application SMS</a><button class="btn gh blk" style="margin-top:10px" data-act="smscopy" data-m="${esc(msg)}">Copier le message</button>`,{title:title||'Alerte par SMS'})}
ACT.smsrep=b=>{const r=S.reports.find(x=>x.id===b.dataset.id);if(r){r.smsAt=Date.now();DB.put('reports',r);smsSheet(UA.smsText(r))}};
ACT.smscopy=async b=>{try{await navigator.clipboard.writeText(b.dataset.m);toast('Message copié','ok',1800,'check')}catch(e){toast('Copie impossible','bad',2000,'alert')}};
ACT.sms=()=>{const p=UA.pos();sheet(`<p class="mut" style="margin:0 0 12px;font-size:13px">Envoyez une alerte courte par SMS, même sans internet.</p>
 <label class="field"><span>Type</span><div class="in"><select id="st">${TYPES.map(t=>`<option value="${t.id}">${esc(t.label)}</option>`).join('')}</select></div></label>
 <label class="field"><span>Description courte</span><div class="in"><textarea id="sd" maxlength="100" style="min-height:70px" placeholder="Ex. Ravin qui s’agrandit près de l’école"></textarea></div></label>
 <div class="gpsbar" style="margin-bottom:14px">${I('pin')}<span style="flex:1">${GEO.last?'Position actuelle':'Dernière position connue / approximative'}</span><span class="mono mut" style="font-size:11px">${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}</span></div>
 <button class="btn hot blk" data-act="smsgo">${I('sms')} Préparer le SMS</button>`,{title:'Alerte par SMS'})};
ACT.smsgo=()=>{const d=$('#sd').value.trim();if(d.length<8){toast('Ajoutez une courte description.','bad',2500,'alert');return}const p=UA.pos();
 smsSheet(UA.smsText({ref:refCode(),type:$('#st').value,lat:p.lat,lng:p.lng,desc:d}))};
})(window);
