/* Desktop keyboard shortcuts (game page only)
   1-9 / 0 : play the Nth card from the left   S H D C / 1-4 : choose trump
   Enter / N : start game                      Esc : back to menu */
(function(){
 'use strict';
 const page=()=>document.body.dataset.page;
 const typing=t=>t&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName);
 document.addEventListener('keydown',function(e){
  if(e.ctrlKey||e.metaKey||e.altKey||typing(e.target)||page()!=='game')return;
  const k=e.key.toLowerCase();
  const pick=document.getElementById('pick');
  if(pick&&pick.classList.contains('on')){
   const btns=[...document.querySelectorAll('#pickRow button')];
   const map={s:'S',h:'H',d:'D',c:'C'};
   let b=null;
   if(map[k])b=btns.find(x=>x.dataset.s===map[k]);
   else if(/^[1-4]$/.test(k))b=btns[+k-1];
   if(b){e.preventDefault();b.click()}
   return;
  }
  if(k==='escape'){if(typeof leaveGame==='function'){e.preventDefault();leaveGame()}return}
  if(k==='n'||(k==='enter'&&e.target===document.body)){
   const nb=document.getElementById('newBtn');if(nb&&!nb.disabled){e.preventDefault();nb.click()}return}
  if(/^[0-9]$/.test(k)){
   const cards=[...document.querySelectorAll('#hand .card')].sort((a,b)=>a.getBoundingClientRect().left-b.getBoundingClientRect().left);
   const c=cards[k==='0'?9:+k-1];
   if(c&&c.classList.contains('ok')){e.preventDefault();c.click()}
  }
 });
 // small hint under the table
 const note=document.querySelector('#v-game .note');
 if(note&&!document.querySelector('.kbd-hint')){
  const p=document.createElement('p');p.className='kbd-hint';
  p.innerHTML='\u0645\u06cc\u0627\u0646\u0628\u0631 \u06a9\u0644\u06cc\u062f: <kbd>1</kbd>\u2013<kbd>9</kbd> \u067e\u062e\u0634 \u06a9\u0627\u0631\u062a \u00b7 <kbd>S</kbd><kbd>H</kbd><kbd>D</kbd><kbd>C</kbd> \u062e\u0627\u0644 \u062d\u06a9\u0645 \u00b7 <kbd>N</kbd> \u0634\u0631\u0648\u0639 \u00b7 <kbd>Esc</kbd> \u0645\u0646\u0648';
  note.after(p);
 }
})();
