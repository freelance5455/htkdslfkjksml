/* کنترل‌های مشترک فرم: انتخاب پایه/درس/فصل، تاریخ شمسی، ساعت، و ابزار فصل‌ها. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var S = function () { return App.S; };

  // پایه‌ها برای انتخاب
  App.gradeOpts = function () { return D.GRADES.map(function (g) { return [String(g), D.GN[g]]; }); };
  // درس‌های یک پایه؛ اگر درس فرم معتبر نباشد، اولین درس انتخاب می‌شود
  App.normSubject = function (form, gKey, sKey) {
    var f = App.form(form, {});
    var g = +f[gKey] || S().mg || 12;
    f[gKey] = g;
    var list = D.subjects(g).map(function (x) { return x.name; });
    if (list.indexOf(f[sKey]) < 0) f[sKey] = list[0] || '';
    return { g: g, s: f[sKey], list: list };
  };
  App.subjSelect = function (form, gKey, sKey, o) {
    var n = App.normSubject(form, gKey, sKey);
    var list = n.list.length ? n.list : [];
    var opts = list.length ? list.map(function (x) { return [x, x]; }) : [['', 'درسی برای این پایه ثبت نشده']];
    return App.select(form, sKey, opts, Object.assign({ rr: true }, o || {}));
  };
  // فهرست فصل‌ها: 0 = بدون فصل
  App.chapOpts = function (g, s, cur) {
    var n = st.chCount(g, s);
    var list = [['0', 'بدون فصل / نامشخص']];
    for (var i = 1; i <= n; i++) list.push([String(i), u.pd(i) + '. ' + st.chName(g, s, i)]);
    return list.map(function (x) { return '<option value="' + x[0] + '"' + (String(cur) === x[0] ? ' selected' : '') + '>' + u.esc(x[1]) + '</option>'; }).join('');
  };
  App.chapSelect = function (form, gKey, sKey, cKey, o) {
    var f = App.form(form, {});
    var g = +f[gKey] || S().mg || 12;
    var s = f[sKey] || '';
    var n = st.chCount(g, s);
    var c = +f[cKey] || 0;
    if (c > n) { c = 0; f[cKey] = 0; }
    var id = (o && o.id) || ('f-' + form + '-' + cKey);
    return '<select id="' + id + '" data-f="' + form + '.' + cKey + '" data-t="int">' + App.chapOpts(g, s, c) + '</select>';
  };

  // ---- تاریخ شمسی: سه انتخاب روز/ماه/سال که مقدار ISO را در فرم نگه می‌دارند ----
  App.dateField = function (form, key, o) {
    o = o || {};
    var f = App.form(form, {});
    var iso = u.isISO(f[key]) ? f[key] : (o.def || u.todayISO());
    if (!u.isISO(f[key])) f[key] = iso;
    var p = u.jparts(iso);
    var cy = u.jparts(u.todayISO())[0];
    var years = [];
    for (var y = cy - (o.back == null ? 1 : o.back); y <= cy + (o.fwd == null ? 2 : o.fwd); y++) years.push(y);
    var days = [];
    for (var d = 1; d <= 31; d++) days.push(d);
    var id = (o.id || ('dp-' + form + '-' + key));
    return '<div class="comp" role="group" aria-label="' + u.esc(o.label || 'تاریخ') + '" data-cbox="' + form + '.' + key + '" data-ctype="date">' +
      '<select aria-label="روز" data-cpart="d" id="' + id + '-d">' + days.map(function (x) { return '<option value="' + x + '"' + (x === p[2] ? ' selected' : '') + '>' + u.pd(x) + '</option>'; }).join('') + '</select>' +
      '<select aria-label="ماه" data-cpart="m" id="' + id + '-m">' + u.JM.map(function (n, i) { return '<option value="' + (i + 1) + '"' + (i + 1 === p[1] ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select>' +
      '<select aria-label="سال" data-cpart="y" id="' + id + '-y">' + years.map(function (x) { return '<option value="' + x + '"' + (x === p[0] ? ' selected' : '') + '>' + u.pd(x) + '</option>'; }).join('') + '</select></div>';
  };
  // از سه انتخاب، ISO می‌سازد (روز نامعتبر به آخرین روز ماه)
  function isoFromBox(box) {
    var g = function (k) { var e = box.querySelector('[data-cpart="' + k + '"]'); return e ? +e.value : 0; };
    var y = g('y'), m = g('m'), d = g('d');
    for (var dd = d; dd >= 1; dd--) {
      var iso = u.jToIso(y, m, dd);
      if (iso) return iso;
    }
    return u.todayISO();
  }
  // ساعت: دو انتخاب (ساعت و دقیقه با گام ۵ دقیقه)
  App.timeField = function (form, key, o) {
    o = o || {};
    var f = App.form(form, {});
    var v = u.validHM(f[key]) ? u.normHM(f[key]) : (o.def || '08:00');
    f[key] = v;
    var p = v.split(':').map(Number);
    var id = (o.id || ('tp-' + form + '-' + key));
    var hours = []; for (var h = 0; h < 24; h++) hours.push(h);
    var mins = []; for (var m = 0; m < 60; m += 5) mins.push(m);
    return '<div class="comp" role="group" aria-label="' + u.esc(o.label || 'ساعت') + '" data-cbox="' + form + '.' + key + '" data-ctype="time">' +
      '<select aria-label="ساعت" data-cpart="h" id="' + id + '-h">' + hours.map(function (x) { return '<option value="' + x + '"' + (x === p[0] ? ' selected' : '') + '>' + u.pd(u.p2(x)) + '</option>'; }).join('') + '</select>' +
      '<span aria-hidden="true">:</span><select aria-label="دقیقه" data-cpart="mi" id="' + id + '-m">' + mins.map(function (x) { return '<option value="' + x + '"' + (x === p[1] - p[1] % 5 ? ' selected' : '') + '>' + u.pd(u.p2(x)) + '</option>'; }).join('') + '</select></div>';
  };
  function hmFromBox(box) {
    var h = box.querySelector('[data-cpart="h"]'), m = box.querySelector('[data-cpart="mi"]');
    return u.p2(+h.value) + ':' + u.p2(+m.value);
  }
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (!el || !el.getAttribute || !el.hasAttribute('data-cpart')) return;
    var box = el.closest('[data-cbox]');
    if (!box) return;
    var parts = box.getAttribute('data-cbox').split('.');
    var f = App.form(parts[0], {});
    f[parts[1]] = box.getAttribute('data-ctype') === 'date' ? isoFromBox(box) : hmFromBox(box);
    App.render();
  }, false);

  // کارت‌های فرم کوچک: دکمه‌های عدد (مثلاً +۱۵)
  App.chips = function (list, act, key, cls) {
    return '<div class="chips-row">' + list.map(function (x) {
      return App.sm(x.l, act, Object.assign({ v: x.v }, key ? { key: key } : {}), cls || '');
    }).join('') + '</div>';
  };
})();
