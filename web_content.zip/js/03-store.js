/* وضعیت برنامه: پیش‌فرض‌ها، پاک‌سازی و مهاجرت از نسخه‌ی قدیمی (کلید localStorage: study_v1). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var KEY = 'study_v1';
  var CORRUPT_KEY = 'study_v1_corrupt';
  var MODELS = ['claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-opus-5-5'];
  App.MODELS = MODELS;
  // شناسه‌ی مدل: هر شناسه‌ی معتبر پذیرفته می‌شود؛ وگرنه مدل پیش‌فرض
  var MODEL_RE = /^[A-Za-z0-9][A-Za-z0-9._:\/-]{1,120}$/;
  var store = (App.store = {});
  store.KEY = KEY;

  store.defaults = function () {
    return {
      v: 2,
      logs: [], exams: [], goal: D.DEFAULT_GOAL, extra: {}, cd: '', fd: '', field: 'riazi', prof: '', plan: null,
      chat: [], mg: 12, theme: 'system', fs: 'n',
      chn: {}, cn: {}, todos: [], daily: {}, remind: { on: 1, at: '20:00' }, tm: { acc: 0, st: 0, k: 's', g: 12, s: '', c: 0 },
      jr: [], mem: [], wk: [], bl: [], ex2: [], quizzes: [],
      wp: [], busy: [], wd: {}, cl: {}, rvd: {}, ci: {},
      rm: null, rf: null, md: null, lg: null, col: {},
      wake: '06:30', sleep: '23:00', rs: 0, rules: '', prog: '', lb: '',
      prs: [], prsActive: null, fb: 0,
      notices: {}
    };
  };

  // ---- ابزارهای پاک‌سازی ----
  function arr(x, fn, max) {
    if (!Array.isArray(x)) return [];
    var out = [];
    for (var i = 0; i < x.length && out.length < (max || 5000); i++) {
      var y = null;
      try { y = fn(x[i], i); } catch (e) { y = null; }
      if (y) out.push(y);
    }
    return out;
  }
  function str(x, max, def) {
    if (x == null) return def || '';
    return String(x).replace(/\u0000/g, '').slice(0, max || 500);
  }
  function intv(x, min, max, def) {
    var n = typeof x === 'number' ? x : u.num(x);
    if (!isFinite(n)) return def;
    return Math.min(max, Math.max(min, Math.round(n)));
  }
  function idOf(x) {
    var n = typeof x === 'number' ? x : parseFloat(x);
    return isFinite(n) && n > 0 ? n : u.uid();
  }
  function isoOr(x, def) { return u.isISO(x) ? x : def; }
  function hmOr(x, def) { return typeof x === 'string' && u.validHM(x) ? u.normHM(x) : def; }
  function plainObj(x) { return x && typeof x === 'object' && !Array.isArray(x) ? x : {}; }
  function goodGrade(g) { return D.GRADES.indexOf(+g) >= 0 ? +g : 0; }
  function unique(list) {
    var seen = {};
    return list.filter(function (x) {
      var k = String(x.id);
      if (seen[k]) return false;
      seen[k] = 1;
      return true;
    });
  }

  function cleanLog(x, mg) {
    var g = goodGrade(x.g) || mg;
    var m = intv(x.m, 0, 1440, 0);
    var t = intv(x.t, 0, 5000, 0);
    if (!m && !t) return null;
    var o = { id: idOf(x.id), d: isoOr(x.d, u.todayISO()), g: g, s: str(x.s, 40), c: intv(x.c, 0, D.MAX_CH, 0), m: m, t: t };
    if (x.k === 'c') o.k = 'c';
    if (x.ok != null && x.ok !== '' && isFinite(+x.ok)) o.ok = Math.min(t, Math.max(0, Math.round(+x.ok)));
    if (x.q != null) { var q = intv(x.q, 1, 4, 0); if (q) o.q = q; }
    if (x.clsk) o.clsk = str(x.clsk, 80);
    return o;
  }

  function cleanSub(x) {
    var t = intv(x.t, 0, 1000, 0);
    var c = intv(x.c, 0, t, 0);
    var w = intv(x.w, 0, Math.max(0, t - c), 0);
    var b = Math.max(0, t - c - w);
    return { s: str(x.s, 40), g: goodGrade(x.g) || 0, t: t, c: c, w: w, b: b, p: pctOf(c, w, t, !!x.neg) };
  }
  function pctOf(c, w, t, neg) {
    if (!t) return 0;
    var v = neg ? (c * 3 - w) / (t * 3) : c / t;
    return Math.round(v * 1000) / 10;
  }
  store.pctOf = pctOf;

  function cleanExam(x) {
    var t = intv(x.t, 0, 1000, 0);
    if (!t) return null;
    var c = intv(x.c, 0, t, 0);
    var w = intv(x.w, 0, Math.max(0, t - c), 0);
    var neg = x.neg ? 1 : 0;
    var p = typeof x.p === 'number' && isFinite(x.p) ? Math.round(Math.max(-100, Math.min(100, x.p)) * 10) / 10 : pctOf(c, w, t, neg);
    var o = { id: idOf(x.id), n: str(x.n, 60), s: str(x.s, 40), d: isoOr(x.d, u.todayISO()), t: t, c: c, w: w, p: p };
    if (x.z != null && x.z !== '') { var z = intv(x.z, 0, 30000, 0); if (z) o.z = z; }
    if (neg) o.neg = 1;
    if (x.typ === 'full' || x.typ === 'subject' || x.typ === 'quick') o.typ = x.typ;
    var tl = intv(x.tl, 0, 1440, 0); if (tl) o.tl = tl;
    var tu = intv(x.tu, 0, 1440, 0); if (tu) o.tu = tu;
    if (Array.isArray(x.sub)) { var sub = arr(x.sub, cleanSub, 20); if (sub.length) o.sub = sub; }
    if (Array.isArray(x.qg)) {
      var qg = arr(x.qg, function (y) {
        var r = y.r === 'c' || y.r === 'w' || y.r === 'b' ? y.r : null;
        if (!r) return null;
        var tag = ['concept', 'calc', 'care', 'time', 'dk'].indexOf(y.tag) >= 0 ? y.tag : '';
        return { s: str(y.s, 40), i: intv(y.i, 1, 1000, 1), r: r, tag: tag, ch: intv(y.ch, 0, D.MAX_CH, 0), g: goodGrade(y.g) || 0 };
      }, 1000);
      if (qg.length) o.qg = qg;
    }
    if (x.ex2) o.ex2 = idOf(x.ex2);
    return o;
  }

  function cleanPlanned(x) {
    var o = { id: idOf(x.id), n: str(x.n, 60, 'آزمون'), d: isoOr(x.d, u.todayISO()) };
    o.r = arr(x.r, function (y) {
      var g = goodGrade(y.g) || 12;
      var s = str(y.s, 40);
      if (!s) return null;
      var a = intv(y.a, 1, D.MAX_CH, 1);
      return { g: g, s: s, a: a, b: Math.max(a, intv(y.b, 1, D.MAX_CH, a)) };
    }, 60);
    o.typ = x.typ === 'full' || x.typ === 'subject' || x.typ === 'quick' ? x.typ : 'subject';
    o.neg = x.neg ? 1 : 0;
    var tl = intv(x.tl, 0, 1440, 0); if (tl) o.tl = tl;
    o.sub = arr(x.sub, function (y) {
      var s = str(y.s, 40); if (!s) return null;
      return { s: s, t: intv(y.t, 1, 200, 20) };
    }, 20);
    if (x.done) o.done = idOf(x.done);
    return o;
  }

  function cleanQuiz(x) {
    var qs = arr(x.questions, function (q) {
      var a = String(q.a || '').toUpperCase();
      if (['A', 'B', 'C', 'D'].indexOf(a) < 0) return null;
      var o = { a: a };
      if (q.q) o.q = str(q.q, 800);
      if (Array.isArray(q.o) && q.o.length === 4) o.o = q.o.map(function (z) { return str(z, 300); });
      if (q.exp) o.exp = str(q.exp, 2000);
      return o;
    }, 60);
    if (!qs.length) return null;
    var attempts = arr(x.attempts, function (a) {
      var ans = str(a.ans, 60);
      return { id: idOf(a.id), d: isoOr(a.d, u.todayISO()), ans: ans, c: intv(a.c, 0, 60, 0), w: intv(a.w, 0, 60, 0), b: intv(a.b, 0, 60, 0), p: +a.p || 0, sec: intv(a.sec, 0, 86400, 0) };
    }, 50);
    return {
      id: idOf(x.id), title: str(x.title, 80, 'آزمون تستی'), g: goodGrade(x.g) || 12, s: str(x.s, 40), ch: intv(x.ch, 0, D.MAX_CH, 0),
      src: x.src === 'ai' ? 'ai' : 'manual', created: isoOr(x.created, u.todayISO()), tl: intv(x.tl, 0, 1440, 0), questions: qs, attempts: attempts
    };
  }

  // پروفایل سرویس: شناسه، نام، نوع، نشانی (اختیاری برای Claude/Gemini، الزامی برای OpenAI-سازگار) و نام مدل. کلید هرگز اینجا نیست.
  var TYPES = ['claude', 'gemini', 'openai'];
  var TYPE_NAME = { claude: 'Claude', gemini: 'Gemini', openai: 'سرویس سازگار' };
  function cleanProfile(x) {
    var type = TYPES.indexOf(x.type) >= 0 ? x.type : '';
    if (!type) return null;
    return { id: idOf(x.id), name: str(x.name, 30).trim() || TYPE_NAME[type], type: type, base: cleanUrl(x.base || x.url), model: cleanModel(x.model) };
  }
  // نام مدل: هر شناسه‌ی معتبر (حروف، عدد، . _ : / -) یا رشته‌ی خالی؛ مدل پیش‌فرض هر سرویس در ai.config می‌آید
  function cleanModel(v) {
    var s = str(v, 130).trim();
    return MODEL_RE.test(s) ? s : '';
  }
  store.cleanModel = cleanModel;
  store.cleanProfile = cleanProfile;
  store.TYPES = TYPES;
  store.TYPE_NAME = TYPE_NAME;
  // پروفایل فعال باید یکی از پروفایل‌های موجود باشد؛ وگرنه اولی
  store.fixActive = function (S) {
    var list = S.prs || [];
    var hit = list.filter(function (p) { return String(p.id) === String(S.prsActive); })[0];
    S.prsActive = hit ? hit.id : (list[0] ? list[0].id : null);
    return S;
  };

  store.cleanLog = cleanLog;
  store.cleanExam = cleanExam;
  store.cleanPlanned = cleanPlanned;
  store.cleanQuiz = cleanQuiz;

  store.cleanState = function (raw, opts) {
    opts = opts || {};
    var d = store.defaults();
    var x = plainObj(raw);
    var S = {};
    S.v = 2;
    S.mg = goodGrade(x.mg) || 12;
    S.logs = unique(arr(x.logs, function (y) { return cleanLog(plainObj(y), S.mg); }, 20000));
    S.exams = unique(arr(x.exams, function (y) { return cleanExam(plainObj(y)); }, 5000));
    S.goal = intv(x.goal, 10, 1440, d.goal);
    S.extra = {};
    Object.keys(plainObj(x.extra)).slice(0, 200).forEach(function (k) { S.extra[str(k, 60)] = intv(x.extra[k], 0, D.MAX_CH, 0); });
    S.cd = isoOr(x.cd, ''); S.fd = isoOr(x.fd, '');
    S.field = 'riazi';
    S.prof = str(x.prof, 4000);
    S.plan = x.plan && u.isISO(x.plan.d) ? { d: x.plan.d, t: str(x.plan.t, 4000) } : null;
    S.chat = arr(x.chat, function (m, i) {
      m = plainObj(m);
      var r = m.r === 'user' || m.r === 'assistant' ? m.r : (m.role === 'user' || m.role === 'assistant' ? m.role : '');
      var c = m.c != null ? m.c : m.content;
      if (!r || typeof c !== 'string') return null;
      var o = { id: idOf(m.id) + i, r: r, c: str(c, 8000) };
      if (Array.isArray(m.acts)) {
        o.acts = arr(m.acts, function (a) {
          return { name: str(a.name, 40), label: str(a.label, 160), ok: !!a.ok, undo: 0, uid: str(a.uid, 24) };
        }, 20);
      }
      if (m.imgs) o.imgs = intv(m.imgs, 0, 10, 0) || undefined;
      return o;
    }, 1000).slice(-40);
    S.theme = m0(x.theme, ['system', 'light', 'dark'], 'system');
    S.fs = m0(x.fs, ['n', 'l', 'xl'], 'n');
    S.chn = {};
    Object.keys(plainObj(x.chn)).slice(0, 400).forEach(function (k) { S.chn[str(k, 60)] = intv(x.chn[k], 0, D.MAX_CH, 0); });
    S.cn = {};
    Object.keys(plainObj(x.cn)).slice(0, 2000).forEach(function (k) {
      var v = str(x.cn[k], 30).trim();
      if (v) S.cn[str(k, 80)] = v;
    });
    S.todos = unique(arr(x.todos, function (t) {
      if (!t.t) return null;
      var o = { id: idOf(t.id), d: isoOr(t.d, u.todayISO()), t: str(t.t, 200), o: t.o ? 1 : 0 };
      if (u.isISO(t.due)) { o.due = t.due; if (u.validHM(t.at)) o.at = u.normHM(t.at); }
      return o;
    }, 2000));
    // S.daily: {روز: [{id,text,done}]}، ۴۰۰ روز آخر
    S.daily = {};
    Object.keys(plainObj(x.daily)).slice(-400).forEach(function (k) {
      if (!u.isISO(k)) return;
      var L = arr(x.daily[k], function (y) { var t = str(y && y.text, 200).trim(); return t ? { id: idOf(y.id), text: t, done: y.done ? 1 : 0 } : null; }, 200);
      if (L.length) S.daily[k] = L;
    });
    // S.remind: نمایش داخل برنامه (پیش‌فرض روشن)، ساعت خلاصه
    var rm0 = plainObj(x.remind);
    S.remind = { on: rm0.on === 0 || rm0.on === false ? 0 : 1, at: hmOr(rm0.at, '20:00') };
    var tm = plainObj(x.tm);
    S.tm = { acc: Math.max(0, +tm.acc || 0), st: Math.max(0, +tm.st || 0), k: tm.k === 'c' ? 'c' : 's', g: goodGrade(tm.g) || S.mg, s: str(tm.s, 40), c: intv(tm.c, 0, D.MAX_CH, 0) };
    S.jr = arr(x.jr, function (j) { return j.t ? { id: idOf(j.id), d: isoOr(j.d, u.todayISO()), k: ['p', 'w', 'n'].indexOf(j.k) >= 0 ? j.k : 'n', t: str(j.t, 1000) } : null; }, 2000);
    S.mem = arr(x.mem, function (j) { return j.t ? { id: idOf(j.id), d: isoOr(j.d, u.todayISO()), t: str(j.t, 1200) } : null; }, 500);
    S.wk = unique(arr(x.wk, function (w) {
      if (!w.t) return null;
      return {
        id: idOf(w.id), s: str(w.s, 40), t: str(w.t, 200), v: intv(w.v, 1, 3, 2), m: intv(w.m, 0, 100, 10),
        ok: w.ok ? 1 : 0, d: isoOr(w.d, u.todayISO()), od: u.isISO(w.od) ? w.od : undefined,
        h: arr(w.h, function (z) { return { d: isoOr(z.d, u.todayISO()), m: intv(z.m, 0, 100, 0) }; }, 60)
      };
    }, 500));
    S.bl = unique(arr(x.bl, function (b) {
      if (!b.t) return null;
      var o = { id: idOf(b.id), s: str(b.s, 40), t: str(b.t, 200), u: b.u ? 1 : 0, ok: b.ok ? 1 : 0, d: isoOr(b.d, u.todayISO()) };
      if (b.ck) o.ck = str(b.ck, 120);
      return o;
    }, 1000));
    S.ex2 = unique(arr(x.ex2, function (e) { return cleanPlanned(plainObj(e)); }, 200));
    S.quizzes = unique(arr(x.quizzes, function (q) { return cleanQuiz(plainObj(q)); }, 100));
    S.wp = arr(x.wp, function (w) {
      if (!u.validHM(w.s0) || !u.validHM(w.e0)) return null;
      var day = intv(w.day, 0, 6, -1);
      if (day < 0) return null;
      return { day: day, s0: u.normHM(w.s0), e0: u.normHM(w.e0), t: str(w.t, 80), k: ['study', 'class', 'other'].indexOf(w.k) >= 0 ? w.k : 'study' };
    }, 500);
    S.busy = arr(x.busy, function (b) {
      if (!u.validHM(b.s) || !u.validHM(b.e)) return null;
      var r = String(b.r);
      if (r !== 'all' && r !== 'today' && !/^[0-6]$/.test(r)) r = 'all';
      return { id: idOf(b.id), t: str(b.t, 80, 'کار ثابت'), s: u.normHM(b.s), e: u.normHM(b.e), r: r, d: u.isISO(b.d) ? b.d : undefined };
    }, 200);
    S.wd = dayMap(x.wd, function (v) { return v === 1 || v === 2 ? v : 0; });
    S.cl = dayMap(x.cl, function (v) { return v === 1 || v === 2 ? v : 0; });
    S.rvd = dayMap(x.rvd, function (v) { return v ? 1 : 0; });
    S.ci = {};
    Object.keys(plainObj(x.ci)).slice(0, 1000).forEach(function (k) {
      if (!u.isISO(k)) return;
      var c = plainObj(x.ci[k]);
      S.ci[k] = { p: intv(c.p, 1, 3, 2), f: intv(c.f, 1, 4, 3), n: str(c.n, 200) };
    });
    S.rm = x.rm && typeof x.rm === 'object' ? { on: x.rm.on ? 1 : 0, t: [0, 1, 2].map(function (i) { return hmOr(x.rm.t && x.rm.t[i], ['09:00', '15:00', '21:00'][i]); }), nag: x.rm.nag ? 1 : 0 } : null;
    S.rf = x.rf && typeof x.rf === 'object' ? { d: isoOr(x.rf.d, ''), k: arr(x.rf.k, function (z) { return str(z, 10); }, 20), n: arr(x.rf.n, function (z) { return intv(z, 0, 100, 0); }, 40) } : null;
    S.md = x.md && typeof x.md === 'object' ? x.md : null;
    S.lg = x.lg == null ? null : intv(x.lg, 0, 10, 0);
    S.col = {};
    Object.keys(plainObj(x.col)).slice(0, 300).forEach(function (k) { S.col[str(k, 120)] = !!x.col[k]; });
    S.wake = hmOr(x.wake, d.wake);
    S.sleep = hmOr(x.sleep, d.sleep);
    S.rs = x.rs ? 1 : 0;
    S.rules = str(x.rules, 6000);
    S.prog = str(x.prog, 6000);
    S.lb = isoOr(x.lb, '');
    // پروفایل‌های سرویس (بدون کلید) و پروفایل فعال؛ pa نام قدیمی prsActive است
    S.prs = unique(arr(x.prs, function (y) { return cleanProfile(plainObj(y)); }, 12));
    S.prsActive = x.prsActive != null ? x.prsActive : (x.pa != null ? x.pa : null);
    store.fixActive(S);
    S.fb = x.fb ? 1 : 0;
    S.notices = {};
    var nt = plainObj(x.notices);
    Object.keys(nt).slice(0, 20).forEach(function (k) { S.notices[str(k, 40)] = nt[k] ? 1 : 0; });
    if (opts.migrated) S.notices.upgraded = S.notices.upgraded === 1 ? 1 : 0;
    return S;
  };
  function m0(v, list, def) { return list.indexOf(v) >= 0 ? v : def; }
  function dayMap(x, valFn) {
    var out = {};
    Object.keys(plainObj(x)).slice(0, 1000).forEach(function (d) {
      if (!u.isISO(d)) return;
      var inner = {};
      Object.keys(plainObj(x[d])).slice(0, 400).forEach(function (k) {
        var v = valFn(x[d][k]);
        if (v) inner[str(k, 120)] = v;
      });
      if (Object.keys(inner).length) out[d] = inner;
    });
    return out;
  }
  // آدرس سرویس فقط https؛ فاصله‌های اضافه حذف می‌شوند
  function cleanUrl(v) {
    var s = str(v, 300).trim().replace(/\s+/g, '');
    return /^https:\/\/[^\s]+$/i.test(s) ? s : '';
  }
  store.cleanUrl = cleanUrl;

  // ---- خواندن، ذخیره و مهاجرت ----
  store.load = function () {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { raw = null; }
    var obj = null;
    if (raw) {
      try { obj = JSON.parse(raw); }
      catch (e) {
        obj = null;
        try { localStorage.setItem(CORRUPT_KEY, raw); } catch (e2) { /* ignore */ }
      }
    }
    var legacy = !!(obj && typeof obj === 'object' && !obj.v);
    var hadKey = !!(obj && (obj.key || obj.gkey || (obj.prs && obj.prs.length)));
    var oldModel = obj && obj.ai && typeof obj.ai.model === 'string' ? obj.ai.model : '';
    App.S = store.cleanState(obj, { migrated: legacy });
    // کلید در study_ai_key می‌ماند؛ پروفایل Claude در صورت نیاز ساخته می‌شود
    if (App.ai && App.ai.migrate) App.ai.migrate(App.S, oldModel);
    if (legacy) {
      // نسخه‌ی قدیمی: اعلان یک‌باره‌ی تغییر پروکسی
      App.S.notices.upgraded = 0;
      App.S.notices.keyHad = hadKey ? 1 : 0;
      App.S.notices.upgradedFrom = 1;
    }
    store.save();
    return App.S;
  };

  store.save = function () {
    try {
      localStorage.setItem(KEY, JSON.stringify(App.S));
      App.storageFull = false;
      return true;
    } catch (e) {
      App.storageFull = true;
      return false;
    }
  };
  // قبل از ذخیره، کپی سبک از S برای ثبت در تاریخچه‌ی مرجع
  store.clone = function (x) { return JSON.parse(JSON.stringify(x)); };
  store.reset = function () { App.S = store.defaults(); store.save(); };
  store.MODELS = MODELS;
  App.save = function () { return store.save(); };
})();
