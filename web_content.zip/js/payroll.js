/**
 * Panchal Business Manager - Staff & Payroll Module
 * Staff Profiles, Check-in/out Attendance, Overtime, Advances, Wage Calculation & Printable Salary Slips.
 */
(function (global) {
  "use strict";

  const I18N = {
    en: {
      tabStaff: "Staff Directory",
      tabAttendance: "Attendance & OT",
      tabPayroll: "Payroll & Slips",
      addStaffBtn: "+ Add Staff",
      emptyStaff: "No staff added yet. Add employees or daily-wage workers.",
      wageMONTHLY: "Monthly Salary",
      wageDAILY: "Daily Wage",
      fieldName: "Staff Name *",
      fieldRole: "Designation / Role",
      fieldPhone: "Phone",
      fieldWageType: "Wage Type",
      fieldBaseRate: "Salary / Daily Rate (₹) *",
      fieldOtRate: "Overtime Rate / Hr (₹)",
      modalAddStaff: "Add Staff Member",
      modalEditStaff: "Edit Staff Member",
      toastSaved: "Staff saved.",
      toastDeleted: "Staff removed.",
      attDateLabel: "Attendance Date",
      attPresent: "Present",
      attHalf: "Half Day",
      attAbsent: "Absent",
      otHoursLabel: "OT Hrs",
      advBtn: "+ Advance",
      modalAdvTitle: "Record Staff Advance",
      advAmountLabel: "Advance Amount (₹)",
      toastAdvSaved: "Advance recorded.",
      monthLabel: "Payroll Month",
      calcSalaryBtn: "Generate / Refresh Payroll",
      markPaidBtn: "Mark Paid",
      printSlipBtn: "Salary Slip",
      statusPAID: "Paid",
      statusUNPAID: "Pending",
      saveBtn: "Save",
      cancelBtn: "Cancel",
      btnEdit: "Edit",
      btnDelete: "Delete"
    },
    hi: {
      tabStaff: "स्टाफ़ सूची",
      tabAttendance: "हाज़िरी व ओवरटाइम",
      tabPayroll: "सैलरी व स्लिप",
      addStaffBtn: "+ स्टाफ़ जोड़ें",
      emptyStaff: "अभी कोई स्टाफ़ नहीं जोड़ा गया है। कारीगर या कर्मचारी जोड़ें।",
      wageMONTHLY: "मासिक सैलरी",
      wageDAILY: "दिहाड़ी (Daily Wage)",
      fieldName: "स्टाफ़ का नाम *",
      fieldRole: "पद / काम",
      fieldPhone: "फ़ोन नंबर",
      fieldWageType: "सैलरी प्रकार",
      fieldBaseRate: "मासिक / प्रति दिन दर (₹) *",
      fieldOtRate: "ओवरटाइम प्रति घंटा (₹)",
      modalAddStaff: "नया स्टाफ़ जोड़ें",
      modalEditStaff: "स्टाफ़ बदलें",
      toastSaved: "स्टाफ़ सेव हो गया।",
      toastDeleted: "स्टाफ़ हटा दिया गया।",
      attDateLabel: "हाज़िरी तारीख़",
      attPresent: "हाज़िर (P)",
      attHalf: "आधा दिन (H)",
      attAbsent: "गैर-हाज़िर (A)",
      otHoursLabel: "OT घंटे",
      advBtn: "+ एडवांस",
      modalAdvTitle: "स्टाफ़ एडवांस दर्ज करें",
      advAmountLabel: "एडवांस राशि (₹)",
      toastAdvSaved: "एडवांस दर्ज हो गया।",
      monthLabel: "सैलरी का महीना",
      calcSalaryBtn: "सैलरी कैलकुलेट करें",
      markPaidBtn: "भुगतान करें",
      printSlipBtn: "सैलरी स्लिप",
      statusPAID: "भुगतान हो गया",
      statusUNPAID: "बकाया",
      saveBtn: "सेव करें",
      cancelBtn: "रद्द करें",
      btnEdit: "बदलें",
      btnDelete: "हटाएँ"
    }
  };

  const viewState = {
    tab: "staff",
    attDate: new Date().toISOString().slice(0, 10),
    month: new Date().toISOString().slice(0, 7),
    staff: [],
    attendance: [],
    payroll: []
  };

  function tr(key) {
    const lang = global.PBM_APP.getLang();
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function openStaffModal(existing) {
    const app = global.PBM_APP;
    const isEdit = Boolean(existing);
    const s = existing || { name: "", role: "", phone: "", wageType: "DAILY", baseRate: 0, otRate: 0, advanceBalance: 0 };

    const html = `
      <form id="staffForm" class="form-grid" novalidate>
        <div class="form-group">
          <label class="form-label" for="stName">${tr("fieldName")}</label>
          <input id="stName" class="form-input" type="text" required value="${app.escapeHtml(s.name)}" />
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="stRole">${tr("fieldRole")}</label>
            <input id="stRole" class="form-input" type="text" value="${app.escapeHtml(s.role || "")}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="stPhone">${tr("fieldPhone")}</label>
            <input id="stPhone" class="form-input" type="tel" maxlength="10" value="${app.escapeHtml(s.phone || "")}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="stWageType">${tr("fieldWageType")}</label>
            <select id="stWageType" class="form-select">
              <option value="DAILY" ${s.wageType === "DAILY" ? "selected" : ""}>${tr("wageDAILY")}</option>
              <option value="MONTHLY" ${s.wageType === "MONTHLY" ? "selected" : ""}>${tr("wageMONTHLY")}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" for="stBaseRate">${tr("fieldBaseRate")}</label>
            <input id="stBaseRate" class="form-input" type="number" min="0" step="1" value="${Number(s.baseRate) || 0}" required />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="stOtRate">${tr("fieldOtRate")}</label>
          <input id="stOtRate" class="form-input" type="number" min="0" step="1" value="${Number(s.otRate) || 0}" />
        </div>
        <div class="modal-actions">
          <button id="stCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(isEdit ? tr("modalEditStaff") : tr("modalAddStaff"), html);
    document.getElementById("stCancelBtn").addEventListener("click", app.closeModal);
    document.getElementById("staffForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("stName").value.trim();
      if (name.length < 2) return;
      const now = new Date().toISOString();
      global.PBM_DB.put("staff", {
        id: isEdit ? s.id : global.PBM_DB.generateId("stf"),
        businessId: app.getActiveBusinessId(),
        name: name,
        role: document.getElementById("stRole").value.trim(),
        phone: document.getElementById("stPhone").value.trim(),
        wageType: document.getElementById("stWageType").value,
        baseRate: Math.max(0, parseFloat(document.getElementById("stBaseRate").value) || 0),
        otRate: Math.max(0, parseFloat(document.getElementById("stOtRate").value) || 0),
        advanceBalance: Number(s.advanceBalance) || 0,
        createdAt: isEdit ? s.createdAt : now,
        updatedAt: now
      }).then(function () {
        app.closeModal();
        app.showToast(tr("toastSaved"), false);
        app.renderCurrentRoute();
      });
    });
  }

  function openAdvanceModal(staffMember) {
    const app = global.PBM_APP;
    const html = `
      <form id="advForm" class="form-grid">
        <div class="list-item-meta"><strong>${app.escapeHtml(staffMember.name)}</strong></div>
        <div class="form-group">
          <label class="form-label" for="advAmtInput">${tr("advAmountLabel")}</label>
          <input id="advAmtInput" class="form-input" type="number" min="1" step="1" required />
        </div>
        <div class="modal-actions">
          <button id="advCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;
    app.openModal(tr("modalAdvTitle"), html);
    document.getElementById("advCancelBtn").addEventListener("click", app.closeModal);
    document.getElementById("advForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const amt = parseFloat(document.getElementById("advAmtInput").value) || 0;
      if (amt <= 0) return;
      staffMember.advanceBalance = (Number(staffMember.advanceBalance) || 0) + amt;
      staffMember.updatedAt = new Date().toISOString();
      global.PBM_DB.put("staff", staffMember).then(function () {
        app.closeModal();
        app.showToast(tr("toastAdvSaved"), false);
        app.renderCurrentRoute();
      });
    });
  }

  function markAttendance(staffId, status, otHours) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const recId = "att_" + businessId + "_" + viewState.attDate + "_" + staffId;
    const now = new Date().toISOString();

    return global.PBM_DB.put("attendance", {
      id: recId,
      businessId: businessId,
      staffId: staffId,
      date: viewState.attDate,
      status: status,
      otHours: Math.max(0, Number(otHours) || 0),
      updatedAt: now
    });
  }

  function generateMonthlyPayroll() {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const monthPrefix = viewState.month;
    const now = new Date().toISOString();

    const tasks = viewState.staff.map(function (st) {
      const monthAtt = viewState.attendance.filter(function (a) {
        return a.staffId === st.id && (a.date || "").indexOf(monthPrefix) === 0;
      });
      let days = 0;
      let otHrs = 0;
      monthAtt.forEach(function (a) {
        if (a.status === "PRESENT") days += 1;
        if (a.status === "HALF") days += 0.5;
        otHrs += Number(a.otHours) || 0;
      });

      const baseEarned =
        st.wageType === "MONTHLY"
          ? (Number(st.baseRate) / 30) * days
          : Number(st.baseRate) * days;
      const otPay = otHrs * (Number(st.otRate) || 0);
      const gross = Math.round((baseEarned + otPay) * 100) / 100;
      const adv = Math.min(gross, Number(st.advanceBalance) || 0);
      const net = Math.max(0, Math.round((gross - adv) * 100) / 100);

      const slipId = "pay_" + businessId + "_" + monthPrefix + "_" + st.id;
      const existing = viewState.payroll.find(function (p) { return p.id === slipId; });

      return global.PBM_DB.put("payroll", {
        id: slipId,
        businessId: businessId,
        staffId: st.id,
        staffName: st.name,
        month: monthPrefix,
        daysWorked: days,
        otHours: otHrs,
        grossPay: gross,
        advanceDeducted: adv,
        netPayable: net,
        status: existing && existing.status === "PAID" ? "PAID" : "UNPAID",
        paidDate: existing ? existing.paidDate : "",
        updatedAt: now
      });
    });

    Promise.all(tasks).then(function () {
      app.renderCurrentRoute();
    });
  }

  function render(viewContainer, contextStripHtml) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    return Promise.all([
      global.PBM_DB.getByBusiness("staff", businessId),
      global.PBM_DB.getByBusiness("attendance", businessId),
      global.PBM_DB.getByBusiness("payroll", businessId)
    ]).then(function (results) {
      viewState.staff = results[0].sort(function (a, b) { return (a.name || "").localeCompare(b.name || ""); });
      viewState.attendance = results[1];
      viewState.payroll = results[2];

      let bodyHtml = "";
      if (viewState.tab === "staff") {
        const listHtml =
          viewState.staff.length === 0
            ? `<div class="card"><p class="card-subtitle">${tr("emptyStaff")}</p></div>`
            : viewState.staff
                .map(function (st) {
                  return `
                    <div class="list-item-card">
                      <div class="list-item-top">
                        <div>
                          <h3 class="list-item-title">${app.escapeHtml(st.name)}</h3>
                          <div class="list-item-meta">${app.escapeHtml(st.role || "-")} · ${tr("wage" + st.wageType)} · ${app.formatCurrency(st.baseRate)}</div>
                          <div class="list-item-meta">Advance: ${app.formatCurrency(st.advanceBalance || 0)}</div>
                        </div>
                      </div>
                      <div class="btn-row">
                        <button class="secondary-btn" type="button" data-st-adv="${app.escapeHtml(st.id)}">${tr("advBtn")}</button>
                        <button class="secondary-btn" type="button" data-st-edit="${app.escapeHtml(st.id)}">${tr("btnEdit")}</button>
                        <button class="danger-btn" type="button" data-st-del="${app.escapeHtml(st.id)}">${tr("btnDelete")}</button>
                      </div>
                    </div>
                  `;
                })
                .join("");

        bodyHtml = `
          <div class="card">
            <div class="card-header-row" style="margin-bottom:0;">
              <h2 class="card-title">${tr("tabStaff")} (${viewState.staff.length})</h2>
              <button id="addStaffBtn" class="primary-btn" type="button">${tr("addStaffBtn")}</button>
            </div>
          </div>
          <div class="list-stack">${listHtml}</div>
        `;
      } else if (viewState.tab === "attendance") {
        const attRows = viewState.staff
          .map(function (st) {
            const rec = viewState.attendance.find(function (a) {
              return a.staffId === st.id && a.date === viewState.attDate;
            });
            const status = rec ? rec.status : "NONE";
            const ot = rec ? rec.otHours : 0;
            return `
              <div class="list-item-card">
                <div class="list-item-top">
                  <div>
                    <div class="list-item-title">${app.escapeHtml(st.name)}</div>
                    <div class="list-item-meta">${app.escapeHtml(st.role || "-")}</div>
                  </div>
                  <div style="width:90px;">
                    <input class="form-input" type="number" min="0" step="0.5" placeholder="${tr("otHoursLabel")}" value="${ot}" data-att-ot="${app.escapeHtml(st.id)}" />
                  </div>
                </div>
                <div class="btn-row">
                  <button class="${status === "PRESENT" ? "primary-btn" : "secondary-btn"}" type="button" data-att-mark="${app.escapeHtml(st.id)}" data-att-val="PRESENT">${tr("attPresent")}</button>
                  <button class="${status === "HALF" ? "primary-btn" : "secondary-btn"}" type="button" data-att-mark="${app.escapeHtml(st.id)}" data-att-val="HALF">${tr("attHalf")}</button>
                  <button class="${status === "ABSENT" ? "danger-btn" : "secondary-btn"}" type="button" data-att-mark="${app.escapeHtml(st.id)}" data-att-val="ABSENT">${tr("attAbsent")}</button>
                </div>
              </div>
            `;
          })
          .join("");

        bodyHtml = `
          <div class="card">
            <div class="form-group">
              <label class="form-label" for="attDateInput">${tr("attDateLabel")}</label>
              <input id="attDateInput" class="form-input" type="date" value="${viewState.attDate}" />
            </div>
          </div>
          <div class="list-stack">${attRows || `<div class="card"><p class="card-subtitle">${tr("emptyStaff")}</p></div>`}</div>
        `;
      } else {
        const monthSlips = viewState.payroll.filter(function (p) { return p.month === viewState.month; });
        const slipsHtml = monthSlips
          .map(function (sl) {
            return `
              <div class="list-item-card">
                <div class="list-item-top">
                  <div>
                    <h3 class="list-item-title">${app.escapeHtml(sl.staffName)}</h3>
                    <div class="list-item-meta">Days: ${sl.daysWorked} · OT: ${sl.otHours}h · Adv: ${app.formatCurrency(sl.advanceDeducted)}</div>
                  </div>
                  <div style="text-align:right;">
                    <div class="kpi-value tabular-nums">${app.formatCurrency(sl.netPayable)}</div>
                    <div class="list-item-meta ${sl.status === "PAID" ? "text-receivable" : "text-payable"}">${tr("status" + sl.status)}</div>
                  </div>
                </div>
                <div class="btn-row">
                  ${sl.status !== "PAID" ? `<button class="primary-btn" type="button" data-pay-mark="${app.escapeHtml(sl.id)}">${tr("markPaidBtn")}</button>` : ""}
                  <button class="secondary-btn" type="button" data-pay-slip="${app.escapeHtml(sl.id)}">${tr("printSlipBtn")}</button>
                </div>
              </div>
            `;
          })
          .join("");

        bodyHtml = `
          <div class="card">
            <div class="form-row-2" style="align-items:end;">
              <div class="form-group">
                <label class="form-label" for="payMonthInput">${tr("monthLabel")}</label>
                <input id="payMonthInput" class="form-input" type="month" value="${viewState.month}" />
              </div>
              <button id="calcSalaryBtn" class="primary-btn" type="button">${tr("calcSalaryBtn")}</button>
            </div>
          </div>
          <div class="list-stack">${slipsHtml}</div>
        `;
      }

      viewContainer.innerHTML = `
        ${contextStripHtml}
        <div class="card">
          <div class="segmented-bar" style="margin-top:0;">
            <button class="seg-btn ${viewState.tab === "staff" ? "active" : ""}" data-st-tab="staff" type="button">${tr("tabStaff")}</button>
            <button class="seg-btn ${viewState.tab === "attendance" ? "active" : ""}" data-st-tab="attendance" type="button">${tr("tabAttendance")}</button>
            <button class="seg-btn ${viewState.tab === "payroll" ? "active" : ""}" data-st-tab="payroll" type="button">${tr("tabPayroll")}</button>
          </div>
        </div>
        ${bodyHtml}
      `;

      viewContainer.querySelectorAll("[data-st-tab]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          viewState.tab = btn.getAttribute("data-st-tab");
          render(viewContainer, contextStripHtml);
        });
      });

      const addBtn = document.getElementById("addStaffBtn");
      if (addBtn) addBtn.addEventListener("click", function () { openStaffModal(null); });

      viewContainer.querySelectorAll("[data-st-adv]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const st = viewState.staff.find(function (s) { return s.id === btn.getAttribute("data-st-adv"); });
          if (st) openAdvanceModal(st);
        });
      });

      viewContainer.querySelectorAll("[data-st-edit]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const st = viewState.staff.find(function (s) { return s.id === btn.getAttribute("data-st-edit"); });
          if (st) openStaffModal(st);
        });
      });

      viewContainer.querySelectorAll("[data-st-del]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          global.PBM_DB.remove("staff", btn.getAttribute("data-st-del")).then(function () {
            app.showToast(tr("toastDeleted"), false);
            app.renderCurrentRoute();
          });
        });
      });

      const attDateEl = document.getElementById("attDateInput");
      if (attDateEl) {
        attDateEl.addEventListener("change", function (e) {
          viewState.attDate = e.target.value;
          render(viewContainer, contextStripHtml);
        });
      }

      viewContainer.querySelectorAll("[data-att-mark]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const stId = btn.getAttribute("data-att-mark");
          const val = btn.getAttribute("data-att-val");
          const otEl = viewContainer.querySelector('[data-att-ot="' + stId + '"]');
          const ot = otEl ? parseFloat(otEl.value) || 0 : 0;
          markAttendance(stId, val, ot).then(function () {
            render(viewContainer, contextStripHtml);
          });
        });
      });

      const payMonthEl = document.getElementById("payMonthInput");
      if (payMonthEl) {
        payMonthEl.addEventListener("change", function (e) {
          viewState.month = e.target.value;
          render(viewContainer, contextStripHtml);
        });
      }

      const calcBtn = document.getElementById("calcSalaryBtn");
      if (calcBtn) calcBtn.addEventListener("click", generateMonthlyPayroll);

      viewContainer.querySelectorAll("[data-pay-mark]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const slip = viewState.payroll.find(function (p) { return p.id === btn.getAttribute("data-pay-mark"); });
          if (!slip) return;
          slip.status = "PAID";
          slip.paidDate = new Date().toISOString().slice(0, 10);
          global.PBM_DB.put("payroll", slip).then(function () {
            const st = viewState.staff.find(function (s) { return s.id === slip.staffId; });
            if (st && slip.advanceDeducted > 0) {
              st.advanceBalance = Math.max(0, (Number(st.advanceBalance) || 0) - slip.advanceDeducted);
              return global.PBM_DB.put("staff", st);
            }
            return null;
          }).then(function () {
            render(viewContainer, contextStripHtml);
          });
        });
      });

      viewContainer.querySelectorAll("[data-pay-slip]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const sl = viewState.payroll.find(function (p) { return p.id === btn.getAttribute("data-pay-slip"); });
          if (!sl) return;
          const biz = app.getActiveBusiness();
          const slipHtml = `
            <div class="print-sheet">
              <h2>${app.escapeHtml(biz ? biz.name : "Company")} — SALARY SLIP</h2>
              <p>Month: <strong>${app.escapeHtml(sl.month)}</strong> · Employee: <strong>${app.escapeHtml(sl.staffName)}</strong></p>
              <table class="print-table">
                <tr><td>Days Worked</td><td style="text-align:right;">${sl.daysWorked}</td></tr>
                <tr><td>Overtime Hours</td><td style="text-align:right;">${sl.otHours} hrs</td></tr>
                <tr><td>Gross Pay Earned</td><td style="text-align:right;">${app.formatCurrency(sl.grossPay)}</td></tr>
                <tr><td>Advance Deducted</td><td style="text-align:right;">- ${app.formatCurrency(sl.advanceDeducted)}</td></tr>
                <tr><td><strong>Net Salary Payable</strong></td><td style="text-align:right;"><strong>${app.formatCurrency(sl.netPayable)}</strong></td></tr>
                <tr><td>Payment Status</td><td style="text-align:right;">${sl.status}</td></tr>
              </table>
            </div>
          `;
          global.PBM_PRINT.printHtmlDocument(slipHtml);
        });
      });
    });
  }

  global.PBM_PAYROLL = {
    render: render
  };
})(window);
