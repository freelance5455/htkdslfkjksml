/* ===== FFM 26: in-game dialogs replace native alert/confirm ===== */
(function () {
'use strict';
var lang = function () { try { return (typeof state !== 'undefined' && state.lang) || 'ar'; } catch (e) { return 'ar'; } };
var LIDX = { ar: 0, en: 1, fr: 2, es: 3, pt: 4, de: 5, tr: 6 };
var L = function () { var v = arguments[LIDX[lang()] == null ? 0 : LIDX[lang()]]; return v == null ? arguments[1] : v; };
var esc = function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>'); };
var css = document.createElement('style');
css.textContent = '.ffm-dlg{display:none;position:fixed;inset:0;background:rgba(2,4,40,.78);z-index:20000;align-items:center;justify-content:center;padding:20px}' +
  '.ffm-dbox{background:var(--panel-color,#0a1f8a);border:4px solid #35d0ff;box-shadow:6px 6px 0 #02044a;padding:18px 16px;max-width:340px;width:100%;text-align:center;line-height:1.7;max-height:88vh;overflow:auto}' +
  '.ffm-dbox h3{margin:0 0 8px;font-size:18px;color:#7fe9ff}.ffm-dbody{font-size:14px;margin-bottom:12px}.ffm-dbtns{display:flex;flex-direction:column;gap:8px}.ffm-dbtns .godot-btn{width:100%}';
document.head.appendChild(css);
var box = document.createElement('div'); box.className = 'ffm-dlg'; box.id = 'ffm-dlg';
box.innerHTML = '<div class="ffm-dbox"><h3 id="ffm-dt"></h3><div class="ffm-dbody" id="ffm-db"></div><div class="ffm-dbtns" id="ffm-dbt"></div></div>';
document.body.appendChild(box);
var queue = [], open = false;
function show(o) {
  open = true; box.style.display = 'flex';
  document.getElementById('ffm-dt').innerHTML = o.title; document.getElementById('ffm-db').innerHTML = o.body;
  var bt = document.getElementById('ffm-dbt'); bt.innerHTML = '';
  o.buttons.forEach(function (b) { var x = document.createElement('button'); x.className = 'godot-btn'; x.innerHTML = b.label;
    x.onclick = function () { close(); if (b.fn) try { b.fn(); } catch (e) { console.error(e); } }; bt.appendChild(x); });
}
function close() { open = false; box.style.display = 'none'; if (queue.length) { var n = queue.shift(); setTimeout(function () { show(n); }, 60); } }
window.ffmDialog = function (o) {
  o = { title: o.title || L('تنبيه', 'Notice', 'Info', 'Aviso', 'Aviso', 'Hinweis', 'Uyarı'), body: o.body || '', buttons: o.buttons || [{ label: L('حسنًا', 'OK', 'OK', 'OK', 'OK', 'OK', 'Tamam') }] };
  if (open) queue.push(o); else show(o);
};
window.alert = function (m) { window.ffmDialog({ body: esc(m) }); };
window.ffmConfirm = function (m, yes, no) {
  window.ffmDialog({ title: L('تأكيد', 'Confirm', 'Confirmer', 'Confirmar', 'Confirmar', 'Bestätigen', 'Onayla'), body: esc(m), buttons: [{ label: L('نعم', 'Yes', 'Oui', 'Sí', 'Sim', 'Ja', 'Evet'), fn: yes }, { label: L('إلغاء', 'Cancel', 'Annuler', 'Cancelar', 'Cancelar', 'Abbrechen', 'İptal'), fn: no }] });
};
var go = {
  vch: function () { return { label: L('مبادلة التوكن بقسائم', 'Swap tokens for vouchers', 'Échanger jetons contre bons', 'Cambiar fichas por vales', 'Trocar fichas por vales', 'Tokens gegen Gutscheine tauschen', 'Jetonları kuponla değiştir'), fn: function () { openStore(); stOpenSection(5); } }; },
  tokRew: function () { return { label: L('🎁 المكافآت والمهام', '🎁 Rewards & tasks', '🎁 Récompenses et missions', '🎁 Premios y tareas', '🎁 Prémios e tarefas', '🎁 Belohnungen & Aufgaben', '🎁 Ödüller ve görevler'), fn: function () { if (window.FFMEng) FFMEng.go('g_rew'); } }; },
  tokSell: function () { return { label: L('💰 بيع اللاعبين', '💰 Sell players', '💰 Vendre des joueurs', '💰 Vender jugadores', '💰 Vender jogadores', '💰 Spieler verkaufen', '💰 Oyuncu sat'), fn: function () { openPlayerSales(); } }; },
  shard: function () { return { label: L('♻️ دمج المكررين (قطع)', '♻️ Merge duplicates (shards)', '♻️ Fusionner les doublons (pièces)', '♻️ Fusionar duplicados (fragmentos)', '♻️ Fundir duplicados (fragmentos)', '♻️ Duplikate verschmelzen (Splitter)', '♻️ Kopyaları birleştir (parça)'), fn: function () { openStore(); stOpenInventory(); } }; }
};
// kind: 'vch' | 'tok' | 'shard' | 'res' (tokens and/or shards)
window.ffmShort = function (kind, title, body) {
  var b = [];
  if (kind === 'vch') b.push(go.vch());
  if (kind === 'tok' || kind === 'res') { b.push(go.tokRew()); b.push(go.tokSell()); }
  if (kind === 'shard' || kind === 'res') b.push(go.shard());
  b.push({ label: L('إغلاق', 'Close', 'Fermer', 'Cerrar', 'Fechar', 'Schließen', 'Kapat') });
  window.ffmDialog({ title: title, body: body, buttons: b });
};
})();
