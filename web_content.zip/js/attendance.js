document.addEventListener("DOMContentLoaded", function () {
  const PREFIX = "civil3_attendance_";

  const dateInput = document.getElementById("attendanceDate");
  const loadButton = document.getElementById("loadAttendanceBtn");
  const allPresentButton = document.getElementById("allPresentBtn");
  const allAbsentButton = document.getElementById("allAbsentBtn");
  const saveButton = document.getElementById("saveAttendanceBtn");

  const totalElement = document.getElementById("totalStudents");
  const presentElement = document.getElementById("presentCount");
  const absentElement = document.getElementById("absentCount");
  const listElement = document.getElementById("attendanceList");
  const messageElement = document.getElementById("attendanceMessage");

  let statuses = {};
  let locked = false;

  function todayString() {
    const now = new Date();

    return [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, "0"),
      String(now.getDate()).padStart(2, "0")
    ].join("-");
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, function (character) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[character];
    });
  }

  function getStudents() {
    return Array.isArray(window.STUDENTS) ? window.STUDENTS : [];
  }

  function setMessage(text) {
    messageElement.textContent = text;
  }

  function readRecord(date) {
    const raw = localStorage.getItem(PREFIX + date);

    if (!raw) {
      return { statuses: {}, locked: false };
    }

    try {
      const saved = JSON.parse(raw);

      if (!saved || typeof saved !== "object") {
        return { statuses: {}, locked: false };
      }

      if (saved.statuses && typeof saved.statuses === "object") {
        return {
          statuses: saved.statuses,
          locked: saved.locked === true
        };
      }

      const oldStatuses = {};

      Object.entries(saved).forEach(function ([key, value]) {
        if (value === "P" || value === "A") {
          oldStatuses[key] = value;
        }
      });

      return {
        statuses: oldStatuses,
        locked: false
      };
    } catch (error) {
      console.error("Attendance read error:", error);
      return { statuses: {}, locked: false };
    }
  }

  function countStatuses() {
    const values = Object.values(statuses);

    totalElement.textContent = getStudents().length;
    presentElement.textContent =
      values.filter(value => value === "P").length;
    absentElement.textContent =
      values.filter(value => value === "A").length;
  }

  function render() {
    const students = getStudents();

    if (students.length === 0) {
      listElement.innerHTML =
        '<p style="padding:18px">No students found. Check students.js.</p>';
      countStatuses();
      return;
    }

    listElement.innerHTML = students.map(function (student, index) {
      const status = statuses[String(student.id)];

      return `
        <article class="attendance-student">
          <div>
            <span class="student-number">${index + 1}.</span>
            <span class="student-name">${escapeHTML(student.name)}</span>
          </div>

          <div class="attendance-actions">
            <button
              type="button"
              class="status-button ${status === "P" ? "selected" : ""}"
              data-id="${student.id}"
              data-status="P"
              ${locked ? "disabled" : ""}
            >P</button>

            <button
              type="button"
              class="status-button ${status === "A" ? "selected" : ""}"
              data-id="${student.id}"
              data-status="A"
              ${locked ? "disabled" : ""}
            >A</button>
          </div>
        </article>
      `;
    }).join("");

    countStatuses();

    saveButton.disabled = locked;
    allPresentButton.disabled = locked;
    allAbsentButton.disabled = locked;
  }

  function loadDate(date) {
    const today = todayString();

    if (!date) {
      setMessage("Please select a date.");
      return;
    }

    if (date > today) {
      dateInput.value = today;
      setMessage("Future dates are not allowed. You can select today or an earlier date.");
      return;
    }

    const record = readRecord(date);

    statuses = { ...record.statuses };
    locked = record.locked;

    render();

    if (locked) {
      setMessage("This attendance record is locked and read-only.");
    } else if (Object.keys(statuses).length > 0) {
      setMessage("Existing attendance loaded. Check the records before saving.");
    } else {
      setMessage("Mark every student Present (P) or Absent (A), then save.");
    }
  }

  listElement.addEventListener("click", function (event) {
    const button = event.target.closest("[data-status]");

    if (!button || locked) return;

    statuses[button.dataset.id] = button.dataset.status;

    render();
    setMessage("Attendance updated. Press Save Attendance to save.");
  });

  allPresentButton.addEventListener("click", function () {
    if (locked) return;

    getStudents().forEach(function (student) {
      statuses[String(student.id)] = "P";
    });

    render();
    setMessage("All students marked Present. Press Save Attendance.");
  });

  allAbsentButton.addEventListener("click", function () {
    if (locked) return;

    getStudents().forEach(function (student) {
      statuses[String(student.id)] = "A";
    });

    render();
    setMessage("All students marked Absent. Press Save Attendance.");
  });

  loadButton.addEventListener("click", function () {
    loadDate(dateInput.value);
  });

  dateInput.addEventListener("change", function () {
    loadDate(dateInput.value);
  });

  saveButton.addEventListener("click", function () {
    if (window.CIVIL3_AUTH && !window.CIVIL3_AUTH.requireAdmin()) return;
    const date = dateInput.value;
    const today = todayString();
    const students = getStudents();

    if (!date) {
      setMessage("Please select a date.");
      return;
    }

    if (date > today) {
      dateInput.value = today;
      loadDate(today);
      setMessage("Future dates are not allowed.");
      return;
    }

    if (locked) {
      setMessage("This attendance record is locked and cannot be changed.");
      return;
    }

    const unmarked = students.filter(function (student) {
      return !["P", "A"].includes(statuses[String(student.id)]);
    });

    if (unmarked.length > 0) {
      setMessage(
        `${unmarked.length} student(s) still need an attendance mark.`
      );
      return;
    }

    const existing = readRecord(date);

    if (existing.locked) {
      loadDate(date);
      setMessage("This record is locked. It was not overwritten.");
      return;
    }

    const record = {
      date: date,
      locked: false,
      savedAt: new Date().toISOString(),
      statuses: { ...statuses }
    };

    try {
      localStorage.setItem(PREFIX + date, JSON.stringify(record));
      setMessage("Attendance saved successfully for " + date + ".");
    } catch (error) {
      console.error("Attendance save error:", error);
      setMessage("Could not save attendance. Please try again.");
    }
  });

  // Prevent selecting a future date in the date picker.
  dateInput.max = todayString();
  dateInput.value = todayString();

  loadDate(dateInput.value);

  console.log("CIVIL 3 Attendance loaded successfully.");
});