// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 6392-6590 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_DRAGON_EAST(Z, SP, A) {
const { THREE, clamp, lerp, smooth, mix3, fbm, Rig, sweepP: sweep } = Z;
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], sc = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const nrm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const mixp = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const rib = (r, path, w0, w1, c0, c1, o) => r.decor.push(Object.assign({ type: 'ribbon', kind: 'sheet', path, w0, w1, up: [1, 0, 0], c0, c1 }, o || {}));
const hair = (r, path, w0, w1, c0, c1, o) => rib(r, path, w0, w1, c0, c1, Object.assign({ kind: (o && o.fire) ? 'fire' : 'hair' }, o || {}));
const eye = (r, bone, at, rad, slit) => r.rigid.push({ bone, eye: { r: rad, slit: !!slit }, at });
const bchain = (r, prefix, parent, pts) => { const names = []; let par = parent; pts.forEach((p, i) => { const n = prefix + (i + 1); r.bone(n, par, p); names.push(n); par = n; }); return names; };
const rseed = s => () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296;
const noiseCol = (c, f, a) => 1 + (fbm(c.x * f, c.y * f, c.z * f, 3) - 0.5) * a;

// ---------- curva de la columna ----------
function makePath(P) {
  const L = P.L, R = P.R, N = P.N, M = 1800, wl = P.wl;
  const yAt = s => { let y = (P.base || 3.2) * R; const env = 0.45 + 0.55 * smooth(0, 0.35, s); if (s <= 0.72) y += P.waveY * R * env * (0.5 - 0.5 * Math.cos(2 * Math.PI * (s - 0.42) / wl)); if (s > 0.72) y += P.neckH * R * smooth(0.72, 0.88, s); if (s > 0.9) y -= P.headDrop * R * smooth(0.9, 1, s); y += (P.curl || 0) * R * Math.pow(Math.max(0, 1 - s / 0.14), 1.6); return y; };
  const xAt = s => P.lat * R * Math.sin(2 * Math.PI * (s - 0.2) / wl + (P.ph || 0)) * (0.35 + 0.65 * smooth(0, 0.3, s)) * (1 - 0.85 * smooth(0.68, 0.8, s));
  const nk = Math.min(1, P.neckH / 5); const zr = s => 1 - 0.85 * nk * smooth(0.70, 0.78, s) * (1 - smooth(0.86, 0.95, s));
  const build = kz => { const out = []; let z = 0; for (let i = 0; i <= M; i++) { const s = i / M; if (i > 0) z += zr(s) * kz / M; out.push([xAt(s), yAt(s), z]); } return out; };
  const arc = pl => { let a = 0; for (let i = 1; i < pl.length; i++) a += Math.hypot(pl[i][0] - pl[i - 1][0], pl[i][1] - pl[i - 1][1], pl[i][2] - pl[i - 1][2]); return a; };
  let lo = L * 0.05, hi = L * 3; for (let k = 0; k < 34; k++) { const mid = (lo + hi) / 2; if (arc(build(mid)) < L) lo = mid; else hi = mid; }
  const raw = build(hi); const cum = [0]; for (let i = 1; i < raw.length; i++) cum.push(cum[i - 1] + Math.hypot(raw[i][0] - raw[i - 1][0], raw[i][1] - raw[i - 1][1], raw[i][2] - raw[i - 1][2]));
  const tot = cum[cum.length - 1]; const pts = []; let j = 0;
  for (let i = 0; i < N; i++) { const a = i / (N - 1) * tot * 0.985; while (j < cum.length - 2 && cum[j + 1] < a) j++; const t = (a - cum[j]) / ((cum[j + 1] - cum[j]) || 1); pts.push(mixp(raw[j], raw[j + 1], t)); }
  const rootI = Math.round(N * 0.58); const zc = pts[rootI][2]; pts.forEach(p => p[2] -= zc);
  const T = pts.map((p, i) => nrm(sub(pts[Math.min(N - 1, i + 1)], pts[Math.max(0, i - 1)]))); const D = []; let d = [0, 1, 0];
  for (let i = 0; i < N; i++) { d = nrm(sub(d, sc(T[i], dot(d, T[i])))); D.push(d.slice()); }
  const S = D.map((dd, i) => nrm(cross(dd, T[i])));
  const rad = u => { let k; if (u < 0.62) k = 0.13 + 0.87 * Math.pow(smooth(0, 0.62, u), 0.8); else if (u < 0.78) k = 1 + 0.08 * Math.sin((u - 0.6) / 0.18 * Math.PI); else k = lerp(1, 0.5, smooth(0.78, 1, u)); return k * R; };
  const rds = pts.map((_, i) => rad(i / (N - 1)));
  return { pts, T, D, S, rds, rootI, N };
}

// ---------- cuernos / astas ----------
const HORNS = { antler: { hl: 2.6, r0: 0.15, tn: 3, tl: 0.55, fork: 0 }, coral: { hl: 1.5, r0: 0.15, tn: 3, tl: 0.7, fork: 1 }, two: { hl: 2.0, r0: 0.15, tn: 1, tl: 0.35, fork: 0 }, prongs: { hl: 2.1, r0: 0.14, tn: 3, tl: 0.6, fork: 0 } };

function eastBuild(P) {
  const R = P.R, L = P.L, N = P.N, Q = (P.hq || 2.4) * R, pal = P.pal; const rnd = rseed(P.seed || 7);
  const path = makePath(P); const { pts, T, D, S, rds, rootI } = path; const r = new Rig('dragonE'); r.ks = 1;
  const name = i => i === rootI ? 'Body_Root' : i > rootI ? 'Body_' + (i - rootI) : 'Tail_' + (rootI - i);
  r.bone('Body_Root', null, pts[rootI]); const fwd = []; for (let i = rootI + 1; i < N; i++) { r.bone(name(i), name(i - 1), pts[i]); fwd.push(name(i)); } const back = []; for (let i = rootI - 1; i >= 0; i--) { r.bone(name(i), name(i + 1), pts[i]); back.push(name(i)); }
  const kb = 0.22 * R;
  for (let i = rootI; i < N - 1; i++) r.cone(name(i), pts[i], pts[i + 1], rds[i], rds[i + 1], kb);
  for (let i = rootI; i > 0; i--) r.cone(name(i), pts[i], pts[i - 1], rds[i], rds[i - 1], kb);
  r.roles.neck = fwd.slice(-Math.max(6, Math.round(N * 0.12))); r.roles.spine = ['Body_Root'].concat(fwd.slice(0, fwd.length - r.roles.neck.length)); r.roles.tails = back; r.roles.root = 'Body_Root';
  // ---- cabeza (marco local: f adelante, up, side +x = izquierda)
  const hp0 = pts[N - 1]; const f = T[N - 1]; const side = nrm(cross([0, 1, 0], f)); const upv = cross(f, side);
  const H = (a, b, c) => add(add(add(hp0, sc(f, (0.25 + a) * Q)), sc(upv, b * Q)), sc(side, c * Q));
  r.bone('Head', name(N - 1), H(0, 0, 0)); r.bone('Jaw', 'Head', H(0.45, -0.2, 0)); r.roles.head = 'Head'; r.roles.jaw = 'Jaw';
  r.cone(name(N - 1), pts[N - 1], H(0.1, 0, 0), rds[N - 1], 0.36 * Q, 0.15 * Q);
  r.ell('Head', H(0.45, 0.06, 0), [0.36 * Q, 0.31 * Q, 0.5 * Q], 0.1 * Q);
  r.cone('Head', H(0.8, 0.0, 0), H(1.6, -0.05, 0), 0.28 * Q, 0.17 * Q, 0.1 * Q, { sc: [1.15, 0.8, 1] });
  r.cone('Jaw', H(0.45, -0.22, 0), H(1.55, -0.24, 0), 0.2 * Q, 0.11 * Q, 0.06 * Q, { sc: [1, 0.55, 1] });
  r.ell('Jaw', H(1.5, -0.28, 0), [0.12 * Q, 0.07 * Q, 0.12 * Q], 0.05 * Q);
  r.ell('Head', H(1.62, 0.0, 0), [0.2 * Q, 0.13 * Q, 0.14 * Q], 0.06 * Q);
  for (const sx of [1, -1]) { const n = sx > 0 ? 'L' : 'R';
    r.ell('Head', H(1.62, 0.02, sx * 0.1), [0.08 * Q, 0.06 * Q, 0.08 * Q], 0.03 * Q); r.ell('Head', H(0.78, 0.3, sx * 0.2), [0.16 * Q, 0.09 * Q, 0.24 * Q], 0.07 * Q); r.ell('Head', H(0.3, -0.1, sx * 0.3), [0.22 * Q, 0.16 * Q, 0.2 * Q], 0.07 * Q);
    r.sub('Head', 'el', [H(1.7, 0.05, sx * 0.1), [0.045 * Q, 0.03 * Q, 0.045 * Q]], 0.02 * Q);
    eye(r, 'Head', H(0.82, 0.24, sx * 0.34), 0.1 * Q, true);
    for (let i = 0; i < 8; i++) { const t = i / 7; const p = H(lerp(0.95, 1.6, t), -0.06, sx * lerp(0.2, 0.08, t)); const k = i === 4 ? 1.7 : 1; r.rigid.push({ bone: 'Head', mat: 'claw', geo: sweep([p, add(p, [0, -0.1 * Q * k, 0]), add(p, [0, -0.18 * Q * k, 0])], [0.03 * Q, 0.015 * Q, 0.002 * Q], 5) }); }
    for (let i = 0; i < 6; i++) { const t = i / 5; const p = H(lerp(0.9, 1.45, t), -0.2, sx * lerp(0.16, 0.08, t)); r.rigid.push({ bone: 'Jaw', mat: 'claw', geo: sweep([p, add(p, [0, 0.09 * Q, 0]), add(p, [0, 0.15 * Q, 0])], [0.025 * Q, 0.012 * Q, 0.002 * Q], 5) }); }
    // aleta de la mejilla
    { const b = H(0.15, 0.0, sx * 0.36); const fin = [b, add(b, add(sc(f, -0.5 * Q), sc(side, sx * 0.55 * Q))), add(b, add(sc(f, -1.1 * Q), add(sc(side, sx * 0.75 * Q), sc(upv, -0.2 * Q))))]; hair(r, fin, 0.5 * Q, 0.04 * Q, pal.mane0, pal.mane1, { up: upv }); }
    // cuernos
    const hs = HORNS[P.horn] || HORNS.antler; const hl = hs.hl * (P.hornScale || 1); const beam = t => H(0.3 - 0.9 * hl * Math.pow(t, 1.3) * (P.horn === 'two' ? 0.55 : 1), 0.32 + 1.0 * hl * t - 0.12 * hl * t * t, sx * (0.16 + 0.5 * hl * Math.pow(t, 1.1)));
    const nbm = 6; const bp = []; for (let k = 0; k < nbm; k++) bp.push(beam(k / (nbm - 1))); const hc = bchain(r, 'Horn_' + n + '_', 'Head', bp); (r.roles.horns = r.roles.horns || []).push(hc);
    r.rigid.push({ bone: hc[0], mat: 'horn', geo: sweep(bp, bp.map((_, k) => Math.max(hs.r0 * Q * (1 - k / nbm * 0.85), 0.012 * Q)), 7) });
    for (let j = 0; j < hs.tn; j++) { const tt = 0.3 + 0.2 * j; const kb2 = 0; const s0 = beam(tt); const dir = nrm(add(add(sc(upv, 0.95), sc(side, sx * 0.3)), sc(f, 0.25 - 0.1 * j))); const tl = hs.tl * hl * Q * (1 - j * 0.18);
      const tip = add(s0, sc(dir, tl)); r.rigid.push({ bone: hc[kb2], mat: 'horn', geo: sweep([s0, add(s0, sc(dir, tl * 0.5)), tip], [0.075 * Q, 0.05 * Q, 0.01 * Q], 6) });
      if (hs.fork) for (const o of [-1, 1]) { const d2 = nrm(add(dir, sc(side, o * 0.7 * sx))); const m0 = add(s0, sc(dir, tl * 0.55)); r.rigid.push({ bone: hc[kb2], mat: 'horn', geo: sweep([m0, add(m0, sc(d2, tl * 0.3)), add(m0, sc(d2, tl * 0.6))], [0.04 * Q, 0.025 * Q, 0.006 * Q], 5) }); } }
    // bigotes largos y finos
    for (let k = 0; k < (P.whisk || 1); k++) { const base = H(1.5, -0.04 - k * 0.07, sx * 0.12); const Lw = (P.wLen || 5) * Q; const wp = []; for (let j = 0; j < 13; j++) { const t = j / 12; wp.push(add(add(add(base, sc(f, (-t * 0.9 + Math.sin(t * 5.5 + k) * 0.18) * Lw * 0.6)), sc(side, sx * (0.12 + Math.pow(t, 0.8) * 0.55 + Math.sin(t * 4 + k) * 0.08) * Lw)), sc(upv, (0.05 * t - 0.07 * t * t + 0.06 * Math.sin(t * 7)) * Lw))); }
      const wn = bchain(r, 'Whisker_' + n + (k + 1) + '_', 'Head', wp); (r.roles.whiskers = r.roles.whiskers || []).push(wn); rib(r, wp, 0.05 * Q, 0.008 * Q, pal.whisk, pal.whisk, { up: upv }); }
  }
  if (P.pearl) r.rigid.push({ bone: 'Jaw', at: H(1.1, -0.3, 0), obj: () => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.34 * Q, 20, 14), new THREE.MeshStandardMaterial({ color: 0xd8321e, emissive: 0xb01808, emissiveIntensity: 0.55, roughness: 0.25, metalness: 0.1 })); m.position.set(...H(1.1, -0.3, 0)); return m; } });
  // ---- melena: hebras con huesos propios que fluyen hacia atrás
  r.roles.manes = []; r.roles.tufts = []; const nm = P.maneN || 10; const mLen = (P.maneLen || 5) * Q;
  for (let k = 0; k < nm; k++) { const a = (k + 0.5) / nm; const lat = (a - 0.5) * 2; const base = H(0.2 - Math.abs(lat) * 0.15, 0.2 - Math.abs(lat) * 0.15 + (k % 2) * 0.05, lat * 0.34); const mp = [];
    const len = mLen * (0.7 + 0.6 * rnd()); for (let j = 0; j <= 7; j++) { const t = j / 7; mp.push(add(add(add(base, sc(f, -t * len)), sc(side, lat * (0.1 + t * 0.9) * Q * 1.1)), sc(upv, 0.05 * Math.sin(t * 2.4) * len * 0.3 - 0.45 * t * t * len * 0.6 + (k % 2) * 0.03 * len * t))); }
    const mn = bchain(r, 'Mane_' + (k + 1) + '_', 'Head', mp); r.roles.manes.push(mn); const w0 = (P.maneW || 0.5) * Q * 0.3 * (0.8 + 0.4 * rnd());
    for (let q = 0; q < 2; q++) hair(r, mp.map((p, j) => add(p, sc(side, (q - 0.5) * 0.12 * Q * (1 - j / 8)))), w0 * (1 - q * 0.35), 0.02 * Q, pal.mane0, pal.mane1, { up: nrm(add(upv, sc(side, lat * (0.6 + q * 0.5)))), pw: 0.8, fire: P.maneStyle === 'flame', af: P.maneStyle === 'flame' ? (t => 1 - t * 0.85) : undefined });
    if (P.maneStyle === 'fur') hair(r, mp.map((p, j) => add(p, sc(upv, 0.1 * Q * Math.sin(j * 1.3 + k)))), w0 * 0.6, 0.015 * Q, pal.mane1, pal.mane0, { up: side }); }
  // pelaje alrededor de la cabeza (mechones cortos pegados a hueso Head/cuello)
  if (P.fur) for (let k = 0; k < P.fur; k++) { const ang = rnd() * Math.PI * 2, rr = (0.25 + rnd() * 0.15) * Q; const base = add(H(0.15 + rnd() * 0.6, Math.sin(ang) * rr / Q, Math.cos(ang) * rr / Q), [0, 0, 0]); const dirv = nrm(add(add(sc(f, -1), sc(upv, Math.sin(ang) * 0.6)), sc(side, Math.cos(ang) * 0.8))); hair(r, [base, add(base, sc(dirv, 0.6 * Q)), add(base, add(sc(dirv, 1.2 * Q), sc(upv, -0.25 * Q)))], 0.3 * Q, 0.02 * Q, pal.mane0, pal.mane1, { up: nrm(cross(dirv, f)) }); }
  // barba
  if (P.beard) for (const sx of [1, -1]) { const n = sx > 0 ? 'L' : 'R'; const b0 = H(1.1, -0.34, sx * 0.07); const bp = []; for (let j = 0; j <= 5; j++) { const t = j / 5; bp.push(add(add(add(b0, sc(f, -t * 1.5 * Q)), sc(upv, -t * 0.9 * Q + 0.2 * Math.sin(t * 3) * Q)), sc(side, sx * t * 0.25 * Q))); } const bn = bchain(r, 'Beard_' + n + '_', 'Jaw', bp); r.roles.manes.push(bn); for (let q = -1; q <= 1; q++) hair(r, bp.map(p => add(p, sc(side, q * 0.1 * Q))), 0.28 * Q, 0.02 * Q, pal.mane0, pal.mane1, { up: side }); }
  // ---- cresta dorsal siguiendo el marco transportado
  const dstep = P.dstep || 1; for (let i = 0; i < N; i += dstep) { const rr = rds[i]; if (rr < 0.06 * R) continue; const base = add(pts[i], sc(D[i], rr * 0.9)); const back1 = sc(T[i], -1); const kind = P.dorsal;
    if (kind === 'spikes') { const h = (P.dorLen || 0.9) * rr; const tip = add(base, add(sc(D[i], h), sc(back1, h * 0.55))); r.rigid.push({ bone: name(i), mat: 'horn', geo: sweep([base, add(base, add(sc(D[i], h * 0.55), sc(back1, h * 0.18))), tip], [rr * 0.1, rr * 0.06, 0.004 * R], 5) }); }
    else { const n2 = kind === 'fur' ? 3 : kind === 'flame' ? 2 : 1; for (let q = 0; q < n2; q++) { const h = (P.dorLen || 1.1) * rr * (0.8 + 0.5 * rnd()) * (kind === 'flame' ? 1.6 : 1); const tilt = 0.5 + 0.5 * rnd(); const d0 = nrm(add(sc(D[i], 1), sc(back1, tilt))); const pth = []; for (let j = 0; j <= 4; j++) { const t = j / 4; pth.push(add(add(base, sc(d0, h * t)), add(sc(back1, h * 0.4 * t * t), sc(S[i], (q - (n2 - 1) / 2) * rr * 0.25 + (kind === 'flame' ? Math.sin(t * 6 + i) * 0.12 * h * t : 0))))); } (kind === 'frill' ? rib : hair)(r, pth, (kind === 'frill' ? 0.28 : 0.3) * rr, 0.01 * rr, pal.dors0, pal.dors1, { up: T[i], fire: kind === 'flame', af: kind === 'flame' ? (t => 1 - t * 0.8) : undefined }); } } }
  // ---- remate de la cola
  const te = rootI; const tipB = name(0), tipP = pts[0], tipT = sc(T[0], -1);
  if (P.tail === 'tuft') for (let k = 0; k < (P.tuftN || 9); k++) { const a = (k / ((P.tuftN || 9) - 1) - 0.5) * 2; const len = (P.tuftLen || 6) * R * (0.7 + 0.5 * rnd()); const tp = []; for (let j = 0; j <= 6; j++) { const t = j / 6; tp.push(add(add(add(tipP, sc(tipT, t * len * 0.8)), sc(S[0], a * (0.3 + t * 1.0) * R * 1.4)), sc(D[0], (0.35 * Math.sin(t * 2.6) * len * 0.4 - 0.2 * t * t * len + a * a * 0.1 * len * t)))); } const tn = bchain(r, 'Tuft_' + (k + 1) + '_', tipB, tp); r.roles.tufts.push(tn); hair(r, tp, (P.tuftW || 0.9) * R * (0.7 + 0.5 * rnd()), 0.03 * R, pal.mane0, pal.mane1, { up: nrm(add(D[0], sc(S[0], a))), pw: 0.9 }); }
  if (P.tail === 'flame') for (let k = 0; k < 7; k++) { const a = (k / 6 - 0.5) * 2; const len = (P.tuftLen || 4) * R * (0.7 + 0.6 * rnd()); const tp = []; for (let j = 0; j <= 6; j++) { const t = j / 6; tp.push(add(add(add(tipP, sc(tipT, t * len * 0.7)), sc(S[0], a * t * R * 0.9 + Math.sin(t * 7 + k) * 0.14 * R)), sc(D[0], Math.sin(t * 5 + k * 2) * 0.2 * R + 0.35 * t * R))); } const tn = bchain(r, 'Tuft_' + (k + 1) + '_', tipB, tp); r.roles.tufts.push(tn); hair(r, tp, 0.7 * R, 0.02 * R, pal.dors0, pal.dors1, { up: nrm(add(D[0], sc(S[0], a))), fire: true, af: t => 1 - t * 0.8 }); }
  if (P.tail === 'fin') { const rays = 7, Lr = (P.finLen || 4.2) * R; const pos = [], col = [], idx = []; const c0 = pal.mane0, c1 = pal.mane1; const origin = add(tipP, sc(tipT, -0.2 * R)); pos.push(...origin); col.push(...c0, 1);
    const tips = []; for (let q = 0; q < rays; q++) { const a = (q / (rays - 1) - 0.5) * 2.1; const ln = Lr * (0.65 + 0.35 * Math.cos(a * 1.5)); tips.push(add(origin, add(sc(tipT, Math.cos(a) * ln), sc(D[0], Math.sin(a) * ln * 0.75)))); }
    const ring = []; for (let q = 0; q < rays; q++) { ring.push(tips[q]); if (q < rays - 1) ring.push(add(mixp(tips[q], tips[q + 1], 0.5), sc(sub(origin, mixp(tips[q], tips[q + 1], 0.5)), 0.28))); }
    for (const f2 of [0.4, 0.75, 1]) ring.forEach(p => { const q = mixp(origin, p, f2); pos.push(...q); const cc = mix3(c0, c1, f2); col.push(cc[0], cc[1], cc[2], 1); });
    const nr = ring.length; for (let ri = 0; ri < 3; ri++) for (let q = 0; q < nr - 1; q++) { const a0 = 1 + ri * nr + q, b0 = a0 + 1; if (ri === 0) { idx.push(0, a0, b0); idx.push(0, b0, a0); } else { const c = a0 - nr, d2 = b0 - nr; idx.push(c, a0, d2, d2, a0, b0, c, d2, a0, d2, b0, a0); } }
    r.decor.push({ type: 'mesh', kind: 'sheet', pos, col, idx }); }
  // ---- patas: raíz en el vientre, pie en el suelo, dedos con garras
  r.roles.legs = {}; r.roles.toes = {}; const gy = 0.1 * R; const legT = P.legT || 1;
  [['F', P.legF || 0.82, 0.35], ['H', P.legH || 0.34, 0.3]].forEach(([fh, u, kk]) => { const i = Math.round(u * (N - 1)); const bn = name(i); const Fv = [0, 0, 1], Sv = [1, 0, 0];
    for (const sx of [1, -1]) { const key = fh + (sx > 0 ? 'L' : 'R'); const nmp = (fh === 'F' ? 'Front_Leg_' : 'Hind_Leg_') + (sx > 0 ? 'L' : 'R') + '_'; const A0 = add(add(pts[i], sc(Sv, sx * 0.62 * R)), sc(D[i], -0.3 * R)); const drop = (P.legDrop || 2.0) * R; const o = (l, d, fw) => [A0[0] + Sv[0] * sx * l * R + Fv[0] * fw * R, A0[1] - d * drop, A0[2] + Sv[2] * sx * l * R + Fv[2] * fw * R];
      const pp = fh === 'F' ? [o(0, 0, 0), o(0.7, 0.34, -0.5), o(0.8, 0.74, 0.35), o(0.85, 1, 0.85)] : [o(0, 0, 0), o(0.7, 0.3, 0.8), o(0.8, 0.72, -0.4), o(0.85, 1, 0.3)];
      const rr = [0.4, 0.3, 0.21, 0.19].map(v => v * R * legT); const names = bchain(r, nmp, bn, pp); r.roles.legs[key] = names; for (let q = 0; q < 3; q++) r.cone(names[q], pp[q], pp[q + 1], rr[q], rr[q + 1], 0.07 * R);
      r.ell(names[0], pp[0], [0.45 * R * legT, 0.55 * R * legT, 0.45 * R * legT], 0.1 * R); r.ell(names[3], add(pp[3], sc(Fv, 0.25 * R)), [0.27 * R, 0.12 * R, 0.34 * R], 0.05 * R);
      const nc = P.claws || 4; const toes = []; for (let t = 0; t < nc; t++) { const ang = (t - (nc - 1) / 2) * 0.36; const dir = nrm(add(sc(Fv, Math.cos(ang)), sc(Sv, sx * Math.sin(ang)))); const b0 = add(pp[3], sc(dir, 0.15 * R)), b1 = add(add(b0, sc(dir, 0.55 * R)), [0, -0.03 * R, 0]), b2 = add(add(b1, sc(dir, 0.5 * R)), [0, -0.06 * R, 0]);
        const tn = bchain(r, nmp.replace('Leg', 'Toe') + (t + 1) + '_', names[3], [b0, b1, b2]); toes.push(tn); for (let q = 0; q < 2; q++) r.cone(tn[q], [b0, b1, b2][q], [b0, b1, b2][q + 1], [0.12, 0.09, 0.06][q] * R, [0.12, 0.09, 0.06][q + 1] * R, 0.03 * R);
        const cp = b2; r.rigid.push({ bone: tn[2], mat: 'claw', geo: sweep([cp, add(add(cp, sc(dir, 0.22 * R)), [0, -0.05 * R, 0]), add(add(cp, sc(dir, 0.4 * R)), [0, -0.28 * R, 0])], [0.06 * R, 0.04 * R, 0.004 * R], 6) }); }
      r.roles.toes[key] = toes;
      if (P.legHair && fh === 'F') for (let q = 0; q < 2; q++) { const base = pp[1]; const bk = sc(Fv, -1); hair(r, [base, add(base, add(sc(bk, 0.4 * R), [0, -0.08 * R * q, 0])), add(base, add(sc(bk, 0.85 * R), [0, -0.25 * R, 0]))], 0.2 * R, 0.015 * R, pal.mane0, pal.mane1, { up: nrm(cross(bk, [0, 1, 0])) }); } } });
  r.pathInfo = { pts, D, S, T, rds, rootI, N, R, bl: L / N }; const m = r.meta; m.L = L; m.H = pts[N - 1][1]; m.hipY = pts[rootI][1]; m.stride = L * 0.3; m.nt = hp0; m.hR = 0.4 * Q; m.hL = 1.6 * Q; m.R = R; m.kb = 2 * Math.PI * (L / N) / (P.waveLen || 0.38 * L); m.nw = P.nw || 1.7; m.amp = P.amp || 1; m.coilPitch = P.coilPitch || 2.3; m.hf = f.slice(); m.bl = L / N; m.coilRho = P.coilRho || 3.3; m.coilTh = P.coilTh || 2.2; m.spd = P.spd || 1; return r;
}

function dragonEPaint(P) {
  const pal = P.pal;
  return function(c) {
    const R = P.R; const rig = c.rig, info = rig && rig.pathInfo; let idx = -1, u = 0; const b = c.bone; let m;
    if (info) { if ((m = /^Body_(\d+)$/.exec(b))) idx = info.rootI + (+m[1]); else if (b === 'Body_Root') idx = info.rootI; else if ((m = /^Tail_(\d+)$/.exec(b))) idx = info.rootI - (+m[1]); }
    const dn = fbm(c.x / R * 1.2, c.y / R * 1.2, c.z / R * 1.2, 3); const n = noiseCol(c, 9 / R * 0.5, 0.18);
    let col = pal.back.slice(); let nd = 0.5;
    if (idx >= 0) { const Dv = info.D[idx]; nd = c.nx * Dv[0] + c.ny * Dv[1] + c.nz * Dv[2]; const dw = smooth(-0.3, 0.9, nd); col = mix3(mix3(pal.back, pal.back2, 0.45), pal.back, dw);
      // franja de gran escala: variación de tono por escamas grandes
      col = mix3(col, pal.back2, smooth(0.55, 0.85, dn) * 0.35);
      if (pal.vein) { const v = Math.abs(fbm(c.x / R * 1.4 + 4, c.y / R * 1.4, c.z / R * 1.4 + 9, 3) - 0.5); const vm = 1 - smooth(0.0, 0.028, v); col = mix3(col, pal.vein, vm * 0.95 * smooth(-0.2, 0.6, nd)); }
      const bw = smooth(-0.1, -0.55, nd); if (bw > 0.01) { const f0 = idx - info.rootI; const uu = (info.N - 1 - idx) * (P.plateK || 1.1) + (c.y * 0.0); const rid = Math.abs(Math.sin(Math.PI * uu)); const plate = mix3(pal.belly, pal.belly2, smooth(0.05, 0.55, 1 - rid) * 0.7); col = mix3(col, plate, bw); } }
    else { col = mix3(pal.back, pal.back2, 0.3 + 0.3 * dn); }
    if (b === 'Head' || b === 'Jaw') { col = mix3(col, pal.head, 0.55); if (b === 'Jaw' || c.ny < -0.35) col = mix3(col, pal.belly, 0.45); const lip = smooth(0.0, 0.5, fbm(c.x / R * 4, c.y / R * 4, c.z / R * 4, 2)); col = mix3(col, pal.back2, lip * 0.25); }
    if (/Leg_[LR]_[1-2]$/.test(b)) col = mix3(col, pal.back2, 0.3); if (/Leg_[LR]_[3-4]$/.test(b)) col = mix3(col, pal.limb || pal.back2, 0.55); if (/Toe/.test(b)) col = mix3(col, pal.claw || [0.1, 0.1, 0.1], 0.5);
    return [col[0] * n, col[1] * n, col[2] * n];
  };
}

function dragonESUV(P) {
  return function(c) {
    const info = c.rig && c.rig.pathInfo; if (!info) return [0, 0, 0];
    const b = c.bone; let idx = -1, m;
    if ((m = /^Body_(\d+)$/.exec(b))) idx = info.rootI + (+m[1]); else if (b === 'Body_Root') idx = info.rootI; else if ((m = /^Tail_(\d+)$/.exec(b))) idx = info.rootI - (+m[1]);
    if (idx < 0) return [0, 0, 0];
    const pts = info.pts, n = info.N;
    if (!info.rc) { const rc = new Float32Array(n); let acc = 0; for (let i = n - 1; i >= 0; i--) { rc[i] = acc; if (i > 0) { const r = Math.max(info.rds[i], 0.22 * info.R); acc += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1], pts[i][2] - pts[i - 1][2]) / (0.47 * r); } } info.rc = rc; }
    let best = 1e30, bi = Math.min(Math.max(idx, 0), n - 2), bt = 0;
    for (let i = Math.max(0, idx - 3); i <= Math.min(n - 2, idx + 3); i++) { const a = pts[i], e = pts[i + 1]; const ux = e[0] - a[0], uy = e[1] - a[1], uz = e[2] - a[2]; const l2 = ux * ux + uy * uy + uz * uz || 1e-9; let t = ((c.x - a[0]) * ux + (c.y - a[1]) * uy + (c.z - a[2]) * uz) / l2; t = t < 0 ? 0 : t > 1 ? 1 : t; const dx = c.x - (a[0] + ux * t), dy = c.y - (a[1] + uy * t), dz = c.z - (a[2] + uz * t); const dd = dx * dx + dy * dy + dz * dz; if (dd < best) { best = dd; bi = i; bt = t; } }
    const a = pts[bi], e = pts[bi + 1], Dv = info.D, Sv = info.S; const cx = a[0] + (e[0] - a[0]) * bt, cy = a[1] + (e[1] - a[1]) * bt, cz = a[2] + (e[2] - a[2]) * bt; const ox = c.x - cx, oy = c.y - cy, oz = c.z - cz;
    const dd0 = Dv[bi], dd1 = Dv[bi + 1], ss0 = Sv[bi], ss1 = Sv[bi + 1];
    const dx = dd0[0] + (dd1[0] - dd0[0]) * bt, dy = dd0[1] + (dd1[1] - dd0[1]) * bt, dz = dd0[2] + (dd1[2] - dd0[2]) * bt, sx = ss0[0] + (ss1[0] - ss0[0]) * bt, sy = ss0[1] + (ss1[1] - ss0[1]) * bt, sz = ss0[2] + (ss1[2] - ss0[2]) * bt;
    const ang = Math.atan2(ox * sx + oy * sy + oz * sz, ox * dx + oy * dy + oz * dz); const rows = info.rc[bi] + (info.rc[bi + 1] - info.rc[bi]) * bt;
    return [rows, ang, 1];
  };
}

function reg(id, o) {
  const P = Object.assign({ L: 30, thick: 0.016, hq: 2.4, wl: 0.46, waveY: 0.5, neckH: 1.2, headDrop: 0, lat: 0.8, ph: 0, curl: 0.8, base: 3.2, legDrop: 2.0, legF: 0.82, legH: 0.34, horn: 'antler', whisk: 1, maneN: 10, maneLen: 5, maneStyle: 'hair', dorsal: 'fur', tail: 'tuft', claws: 4, seed: 7, legHair: true, dorLen: 1.1 }, o.P); P.R = P.thick * P.L; if (!P.N) P.N = Math.max(50, Math.min(170, Math.round(P.L / (0.55 * P.R)))); if (!P.waveLen) P.waveLen = 0.5 * P.L;
  const pal = P.pal;
  SP[id] = { id, kind: 'dragonE', proto: true, noSpawn: true, fastSDF: true, name: o.name, cat: 'leyendas', rank: 'mitico', int: 10, pow: o.pow || 10, spd: o.spd || 9, hab: 'Mundo de dragones', diet: o.diet || 'Perlas de luz', move: 'air', fly: true, cell: Math.min(P.R * 0.115, (P.hq || 2.4) * P.R * 0.09), size: P.L / 2,
    desc: o.desc, habits: { fly: 6, sing: 2, idle: 1, rest: 1 }, social: 'curious', sound: 'chime', eyeColor: o.eye || 0xffb020, hornColor: o.horn || 0xd8c690, clawColor: o.claw || 0xe8ddc0, anim: { k: 0.4 },
    style: Object.assign({ detail: 'scales', scaleUV: true, dscale: 0.42 / P.R, dstr: 0.9, sstr: 1.35, na: 12, rough: 0.38, metal: 0.25 }, o.style || {}), cfg: P,
    suv: dragonESUV(P),
    build() { return eastBuild(P); }, paint: dragonEPaint(P) };
  return SP[id];
}

const C = (h) => [((h >> 16) & 255) / 255, ((h >> 8) & 255) / 255, (h & 255) / 255];

// 1) Jade y púrpura (cuerpo esbelto, melena larga violeta, penacho enorme)
reg('dragonE', { name: 'Dragón Jade · oriental', eye: 0xffc030, horn: 0xcfc9bd, claw: 0xdfe6e0, desc: 'Dragón esbelto de escamas turquesa y larga melena violeta. Descansa con todo su largo cuerpo extendido y la cola ondulando suave; en el aire vuela por magia, zigzagueando como una serpiente. Solo se enrosca para mostrar orgullo y majestad.',
  P: { L: 28, thick: 0.0185, hq: 2.6, legF: 0.8, legH: 0.38, maneN: 20, maneLen: 4.6, maneStyle: 'hair', maneW: 0.6, dorsal: 'fur', dorLen: 1.6, tail: 'tuft', tuftN: 11, tuftLen: 9, tuftW: 1.1, horn: 'antler', hornScale: 0.75, whisk: 1, wLen: 5, claws: 4, seed: 11, plateK: 1.2,
    pal: { back: C(0x15b3a3), back2: C(0x0a7f86), belly: C(0xa6dcc0), belly2: C(0x6fb59c), head: C(0x1ebcae), mane0: C(0x4f3ea8), mane1: C(0x8a73e8), dors0: C(0x5642b5), dors1: C(0x8f7bef), whisk: C(0x2aa79c), limb: C(0x118f8a), claw: C(0xdfe6e0) } } });
// 2) Ébano y oro (melena de pelo oscuro, venas de oro, astas de hueso, muy imponente)
reg('dragonEn', { name: 'Dragón de Ébano y Oro', eye: 0xffbf1a, horn: 0xdadde0, claw: 0x2a2623, desc: 'Gran dragón negro con venas de oro, melena y barba de pelo oscuro y astas de hueso plateado. Cuerpo larguísimo de escamas finas, más serpiente que lagarto; la distancia entre sus patas delanteras y traseras es enorme. Se enrosca en espiral solo para clavar la mirada con majestad.',
  P: { L: 44, thick: 0.0155, hq: 2.4, legF: 0.8, legH: 0.36, maneN: 26, maneLen: 3.9, maneStyle: 'fur', maneW: 0.7, fur: 34, beard: true, dorsal: 'fur', dorLen: 1.5, tail: 'tuft', tuftN: 9, tuftLen: 5, tuftW: 0.8, horn: 'antler', hornScale: 0.9, whisk: 1, wLen: 5, claws: 4, seed: 23, plateK: 1.0,
    pal: { back: C(0x131315), back2: C(0x0a0a0c), belly: C(0x2d2a27), belly2: C(0x1c1a18), head: C(0x1a1a1d), vein: C(0xe8b030), mane0: C(0x0e0d0d), mane1: C(0x4a443b), dors0: C(0x141313), dors1: C(0x5a5448), whisk: C(0x101010), limb: C(0x151517), claw: C(0x1a1a1a) }, },
  style: { rough: 0.5, metal: 0.18 } });
// 3) Dorado celestial (larguísimo, melena blanca, vientre plateado)
reg('dragonEo', { name: 'Dragón Dorado Celestial', eye: 0xfff3c0, horn: 0xd9a83f, claw: 0xe3b24a, desc: 'Dragón colosal de escamas doradas, vientre de placas plateadas y melena blanca que ondea. El más largo de la colección: su cuerpo, extendido por completo, serpentea en el aire y necesita muchos huesos para fluir. Se enrosca en varias vueltas como pose de orgullo.',
  P: { L: 84, thick: 0.0125, hq: 2.7, legF: 0.78, legH: 0.3, maneN: 22, maneLen: 4.4, maneStyle: 'hair', maneW: 0.6, dorsal: 'fur', dorLen: 2.2, tail: 'tuft', tuftN: 13, tuftLen: 14, tuftW: 1.3, horn: 'two', hornScale: 0.95, whisk: 2, wLen: 5.5, claws: 4, seed: 31, plateK: 1.1,
    pal: { back: C(0xf0b844), back2: C(0xc88a24), belly: C(0xe6e6e2), belly2: C(0xb4b6b8), head: C(0xe0b04a), mane0: C(0xf2f3f6), mane1: C(0xbcc4d4), dors0: C(0xf5f6fa), dors1: C(0xc3cbdc), whisk: C(0xc99a2e), limb: C(0xc8932c), claw: C(0xe3b24a) } },
  style: { rough: 0.38, metal: 0.12 } });
// 4) Dragón de agua (azul, aleta de pez, golilla rosada, cuernos de coral, perla roja)
reg('dragonEa', { name: 'Dragón de Agua (水龍)', eye: 0xffa030, horn: 0xc99a5e, claw: 0x1f2740, desc: 'Dragón azul de vientre crema acostillado, golilla rosa y púrpura, astas de coral y una perla roja entre los colmillos. Termina en una aleta como la de un pez. Cuerpo muy largo y extendido que ondula suave al flotar; solo se enrosca para lucirse.',
  P: { L: 56, thick: 0.0148, hq: 2.6, legF: 0.8, legH: 0.34, maneN: 16, maneLen: 2.6, maneStyle: 'hair', maneW: 0.55, dorsal: 'frill', dorLen: 1.7, tail: 'fin', finLen: 5, horn: 'coral', hornScale: 1.0, whisk: 2, wLen: 5, pearl: true, claws: 4, seed: 41, plateK: 1.5, legHair: true,
    pal: { back: C(0x1c3fb0), back2: C(0x112a82), belly: C(0xe8d9ae), belly2: C(0xc2ab78), head: C(0x2a4cc0), mane0: C(0xc067b5), mane1: C(0x6a3f9f), dors0: C(0xd070b8), dors1: C(0x6e4aa8), whisk: C(0xcfd8e8), limb: C(0x1a3699), claw: C(0x1f2740) } },
  style: { rough: 0.4, metal: 0.15 } });
// 5) Bronce y llama azul
reg('dragonEb', { name: 'Dragón de Bronce y Llama Azul', eye: 0x55ccff, horn: 0xb8924a, claw: 0xc9a45a, desc: 'Dragón de escamas de bronce labrado con melena, cresta y cola de llama azul. Dos cuernos largos y ojos que brillan. Sus llamas se mueven con retardo, como un látigo. Vuela con el cuerpo extendido y se enrosca solo en su pose de orgullo.',
  P: { L: 36, thick: 0.0168, hq: 2.4, legF: 0.8, legH: 0.36, maneN: 24, maneLen: 3.7, maneStyle: 'flame', maneW: 0.7, dorsal: 'flame', dorLen: 1.7, tail: 'flame', tuftLen: 5, horn: 'two', hornScale: 0.85, whisk: 1, wLen: 5, claws: 4, seed: 53, plateK: 1.3,
    pal: { back: C(0xa87a30), back2: C(0x6a4a1a), belly: C(0xc49a48), belly2: C(0x8a6a2a), head: C(0xb68636), mane0: C(0x1f6cff), mane1: C(0xa5f0ff), dors0: C(0x1f78ff), dors1: C(0xb0f4ff), whisk: C(0xc9a45a), limb: C(0x6a4c1c), claw: C(0xc9a45a) } },
  style: { rough: 0.4, metal: 0.12, emissive: 0x1a60ff, emissiveI: 0.05 } });
// 6) Gris azulado (melena y barba grises, espinas dorsales, el más pequeño)
reg('dragonEg', { name: 'Dragón Gris Azulado', eye: 0xffc22a, horn: 0x2b2824, claw: 0x15171c, desc: 'Dragón de escamas gris azuladas, vientre crema, melena y barba grises revueltas y astas oscuras. Espinas azules recorren su espalda. Más corto y ágil, pero igual de serpentino: base extendida, vuelo ondulante y enrosque solo como pose de majestad.',
  P: { L: 24, thick: 0.0205, hq: 2.3, legF: 0.8, legH: 0.4, maneN: 20, maneLen: 3.2, maneStyle: 'hair', maneW: 0.7, beard: true, dorsal: 'spikes', dorLen: 1.0, tail: 'tuft', tuftN: 7, tuftLen: 4.2, tuftW: 0.8, horn: 'prongs', hornScale: 1.0, whisk: 1, wLen: 5, claws: 4, seed: 67, plateK: 1.2,
    pal: { back: C(0x3a557c), back2: C(0x24344f), belly: C(0xd5bf8e), belly2: C(0xa08a5c), head: C(0x425f88), mane0: C(0x8a8780), mane1: C(0xcfccc2), dors0: C(0x6a7a8a), dors1: C(0xa0aab4), whisk: C(0xd0d4dc), limb: C(0x2f4468), claw: C(0x15171c) } },
  style: { rough: 0.42, metal: 0.12 } });

return { eastBuild, makePath };
}

