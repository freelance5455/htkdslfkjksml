// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 5191-5586 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_ANIM(Z) {
const { THREE, clamp, lerp } = Z;
const Q = THREE.Quaternion, E = THREE.Euler, V3 = THREE.Vector3;
const TAU = Math.PI * 2;
const S = {
  idle: { move: 0 }, walk: { move: 0.5 }, run: { move: 1 }, rest: { rest: 1 }, sing: { sing: 1 }, graze: { graze: 1 }, fly: { fly: 1, move: 0.7 }, hover: { fly: 1, move: 0.1 }, glide: { fly: 1, glide: 1, move: 0.5 },
  roar: { roar: 1 }, alert: { alert: 1 }, coil: { coil: 1, move: 0.25 }, swim: { swim: 1, move: 0.6 }, flyrest: { fly: 1, move: 0 }
};
const AMT = ['coil', 'move', 'rest', 'sing', 'graze', 'fly', 'glide', 'roar', 'alert', 'swim'];

// prepara datos de retarget por hueso (rotación del padre en reposo)
function prepare(inst) {
  if (inst._prep) return; inst._prep = true;
  inst.group.updateMatrixWorld(true); const pw = {}, pwi = {}; let ident = true; const wq = new Q();
  inst.bones.forEach(b => { const p = b.parent; if (p && p.isBone) { p.getWorldQuaternion(wq); } else if (p) { p.getWorldQuaternion(wq); } else wq.identity(); const q = wq.clone(); pw[b.name] = q; pwi[b.name] = q.clone().invert(); if (Math.abs(q.w) < 0.9999) ident = false; });
  inst.pw = pw; inst.pwi = pwi; inst.identPw = ident;
  { const gi = inst.group.matrixWorld.clone().invert(), vv = new V3(); inst.restPos = {}; inst.bones.forEach(b => { vv.setFromMatrixPosition(b.matrixWorld).applyMatrix4(gi); inst.restPos[b.name] = [vv.x, vv.y, vv.z]; }); }
}
function make(inst, opts) {
  prepare(inst);
  const c = { inst, sp: inst.sp, kind: (opts && opts.kind) || inst.sp.kind || 'quad', amt: {}, tgt: {}, phase: Math.random(), t: Math.random() * 10, speed: 0, flap: Math.random(), state: 'idle', d: {}, tr: {}, seed: Math.random() * 100, blink: 0, extra: {} };
  AMT.forEach(k => { c.amt[k] = 0; c.tgt[k] = 0; });
  c.set = (name, p, y, r) => { const d = c.d[name] || (c.d[name] = [0, 0, 0]); d[0] += p || 0; d[1] += y || 0; d[2] += r || 0; };
  c.trans = (name, x, y, z) => { const d = c.tr[name] || (c.tr[name] = [0, 0, 0]); d[0] += x || 0; d[1] += y || 0; d[2] += z || 0; };
  return c;
}
function setState(c, st) { c.state = st; const s = S[st] || S.idle; AMT.forEach(k => c.tgt[k] = s[k] || 0); }

const _q = new Q(), _e = new E(0, 0, 0, 'YXZ'), _v = new V3();
function apply(c) {
  const inst = c.inst;
  for (const b of inst.bones) {
    const rest = inst.rest[b.name]; const d = c.d[b.name]; const t = c.tr[b.name];
    if (d) { _e.set(d[0], d[1], d[2], 'YXZ'); _q.setFromEuler(_e); if (!inst.identPw) { _q.premultiply(inst.pwi[b.name]).multiply(inst.pw[b.name]); } b.quaternion.copy(_q).multiply(rest.q); } else b.quaternion.copy(rest.q);
    if (t) { _v.set(t[0], t[1], t[2]); if (!inst.identPw) _v.applyQuaternion(inst.pwi[b.name]); b.position.copy(rest.p).add(_v); } else b.position.copy(rest.p);
  }
  c.d = {}; c.tr = {};
}

// utilidades
function chainWave(c, names, amp, ph, k, axis, fall) { if (!names) return; names.forEach((n, i) => { const f = fall === undefined ? 1 : Math.pow(1 + i * fall, 1); const a = amp * f * Math.sin(ph - i * k); if (axis === 'p') c.set(n, a, 0, 0); else if (axis === 'r') c.set(n, 0, 0, a); else c.set(n, 0, a, 0); }); }
const sm = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

// ---------- cuadrúpedo ----------
function quadLegs(c, o) {
  const R = c.inst.rig.roles, m = c.inst.rig.meta, a = c.amt; const P = c.phase * TAU; const A = (o && o.amp) || 0.55; const move = a.move;
  const fold = a.rest;
  const off = { FL: 0, HR: 0.0, FR: 0.5, HL: 0.5 };
  for (const key in R.legs) {
    const L = R.legs[key]; if (!L) continue; const front = key[0] === 'F'; const ph = P + off[key] * TAU; const s = Math.sin(ph), cs = Math.cos(ph);
    const lift = Math.max(0, -cs) ;// 0..1 mientras el pie va hacia adelante (aire)
    const sw = -A * s * move * (front ? 1 : 0.9);
    if (front) {
      c.set(L[0], sw - 0.0 * fold, 0, 0); c.set(L[1], lift * 1.0 * move, 0, 0); c.set(L[2], lift * 0.9 * move, 0, 0); c.set(L[3], -lift * 0.35 * move, 0, 0);
      // descanso: patas dobladas bajo el pecho
      c.set(L[0], -1.0 * fold, 0, 0); c.set(L[1], 2.0 * fold, 0, 0); c.set(L[2], 0.2 * fold, 0, 0); c.set(L[3], 0.2 * fold, 0, 0);
    } else {
      c.set(L[0], sw, 0, 0); c.set(L[1], lift * 0.9 * move, 0, 0); c.set(L[2], -lift * 0.8 * move, 0, 0); c.set(L[3], lift * 0.5 * move, 0, 0);
      c.set(L[0], -1.1 * fold, 0, 0); c.set(L[1], 2.1 * fold, 0, 0); c.set(L[2], -1.3 * fold, 0, 0); c.set(L[3], 0.5 * fold, 0, 0);
    }
  }
}
function quadBody(c) {
  const R = c.inst.rig.roles, m = c.inst.rig.meta, a = c.amt, t = c.t; const P = c.phase * TAU; const sp = c.sp;
  const rootN = R.root || R.spine[0];
  const bob = Math.sin(P * 2) * 0.018 * (m.H || 1) * a.move;
  c.trans(rootN, 0, bob - (m.hipY ? (m.hipY - (m.rv || 0.2) * 0.8) * a.rest : 0) * 1, 0);
  const breath = Math.sin(t * 1.7) * 0.012 * (1 + a.rest);
  R.spine.forEach((n, i) => { c.set(n, breath * (i + 1) * 0.5 + Math.sin(P * 2 + i) * 0.025 * a.move, Math.sin(P) * 0.07 * a.move, 0); });
  // cuello y cabeza
  const look = Math.sin(t * 0.37 + c.seed) * 0.25 * (1 - a.move * 0.7), lookP = Math.sin(t * 0.23 + c.seed * 2) * 0.1;
  const up = a.sing, gz = a.graze, al = a.alert;
  if (R.neck.length) {
    R.neck.forEach((n, i) => { c.set(n, -0.55 * up * (i ? 0.6 : 1) + 0.85 * gz * (i ? 0.7 : 1) - 0.12 * al + 0.35 * a.rest * 0.8 - Math.sin(P * 2 + 1) * 0.04 * a.move, look * 0.4 * (1 - gz) + Math.sin(P) * -0.05 * a.move, 0); });
    c.set(R.head, -0.2 * up + 0.35 * gz + lookP * 0.3 - 0.1 * al + 0.1 * a.rest, look * 0.5, 0);
  }
  if (R.jaw) { const chew = gz * (0.1 + 0.1 * Math.sin(t * 7)); const howl = up * (0.45 + 0.12 * Math.sin(t * 3.2)); const roar = a.roar * 0.7; c.set(R.jaw, chew + howl + roar + Math.max(0, Math.sin(t * 0.9 + c.seed)) * 0.0, 0, 0); }
  // cola
  if (R.tails && R.tails.length) R.tails.forEach((n, i) => { c.set(n, -0.15 * (i ? 0 : 1) * a.move + Math.sin(t * 2 + i * 0.5) * 0.04, Math.sin(t * (1.1 + 1.6 * a.move) - i * 0.7 + c.seed) * (0.13 + 0.12 * a.move) * (1 + i * 0.25), 0); });
  // orejas
  if (R.ears) R.ears.forEach((n, i) => { const tw = Math.max(0, Math.sin(t * 0.6 + i * 2.1 + c.seed * 3) - 0.9) * 8; c.set(n, -0.1 * al + tw * 0.2, 0, (i ? 1 : -1) * (tw * 0.15 + 0.1 * a.rest)); });
}

// ---------- alas (aves, grifos, dragones, fénix) ----------
function wings(c, o) {
  const R = c.inst.rig.roles; if (!R.wings || !R.wings.L) return; const a = c.amt, t = c.t; o = o || {};
  const fly = a.fly, glide = a.glide; const fp = c.flap * TAU; const sprd = (1 - fly) * clamp(Math.max(o.spread || 0, a.roar * 0.85) * (1 - a.rest) * (1 - a.move * 0.6), 0, 1); const fold = (1 - fly) - sprd;
  for (const side of ['L', 'R']) {
    const W = R.wings[side]; if (!W) continue; const sx = side === 'L' ? 1 : -1; const n = W.length;
    const rest = a.rest, flapAmp = (o.amp || 0.7) * (1 - glide * 0.85);
    W.forEach((b, i) => {
      const lag = i * (o.lag || 0.55); const roll = sx * (flapAmp * (0.55 + 0.2 * i) * Math.sin(fp - lag) * fly + (glide * 0.12 + (o.dihedral || 0.15)) * fly * (i === 0 ? 1 : 0.4));
      const foldYaw = sx * fold * (i === 0 ? (o.fold0 === undefined ? 0.5 : o.fold0) : i === 1 ? (o.fold1 === undefined ? -2.0 : o.fold1) : (o.fold2 === undefined ? 2.2 : o.fold2)) * -1;
      const droop = sx * fold * (i === 0 ? -0.35 : 0) + sx * sprd * (i === 0 ? 0.5 : 0.12) + sx * sprd * Math.sin(t * 1.3 + i) * 0.03;
      c.set(b, 0, foldYaw, roll + droop);
      if (i === 0) c.set(b, -0.1 * fly + 0.25 * Math.cos(fp) * fly * 0.4, 0, 0);
    });
    if (R.fingers && R.fingers[side]) R.fingers[side].forEach((chain, fi) => chain.forEach((b, i) => { const spread = (fi - (R.fingers[side].length - 1) / 2) * 0.12 * fly; c.set(b, 0, sx * (spread + fold * 0.9 * (1 + fi * 0.1)), sx * Math.sin(fp - (i + 3) * 0.55) * 0.3 * fly); }));
  }
  if (R.tailFeathers) R.tailFeathers.forEach((b, i) => c.set(b, -0.2 * a.fly + Math.sin(c.t * 2 + i) * 0.04, (i - (R.tailFeathers.length - 1) / 2) * 0.1 * a.fly, 0));
}

// ---------- aves ----------
function bird(c) {
  if (c.sp.phx && c.inst.rig && c.inst.rig.meta && c.inst.rig.meta.grp) return phoenixAnim(c);
  const R = c.inst.rig.roles, m = c.inst.rig.meta, a = c.amt, t = c.t, P = c.phase * TAU; const fly = a.fly;
  wings(c, { amp: m.flapAmp || 0.9, lag: 0.5, fold0: 0.25, fold1: -1.9, fold2: 1.9 });
  const rootN = R.root; const bobW = Math.abs(Math.sin(P)) * 0.02 * a.move * (1 - fly);
  c.trans(rootN, 0, bobW * (m.H || 0.3) * 6 + Math.sin(c.flap * TAU) * 0.05 * (m.H || 0.3) * fly - (m.hipY * 0.55) * a.rest * (1 - fly), 0);
  c.set(rootN, -0.7 * fly + 0.0 * a.rest + 0.25 * a.glide, 0, 0);
  R.spine.forEach((n, i) => c.set(n, Math.sin(t * 1.4 + i) * 0.015 + 0.1 * a.rest * (i ? 0.4 : 1) * 0, Math.sin(P) * 0.05 * a.move * (1 - fly), 0));
  const look = Math.sin(t * 0.8 + c.seed) * 0.5 * (1 - a.move) * (1 - fly), peck = Math.max(0, Math.sin(t * 2.3 + c.seed)) * 0.5 * a.graze;
  R.neck.forEach((n, i) => { c.set(n, (Math.sin(P * 2) * 0.12 * a.move * (1 - fly)) + peck * 0.9 + 0.35 * fly * (i ? 0.6 : 1) - 0.4 * a.sing * (i ? 0.7 : 1), look * 0.45, 0); });
  c.set(R.head, -0.15 * a.sing + peck * 0.3, look * 0.4, Math.sin(t * 0.5 + c.seed) * 0.12 * (1 - a.move));
  if (R.jaw) c.set(R.jaw, a.sing * (0.35 + 0.35 * Math.max(0, Math.sin(t * 14))) , 0, 0);
  if (R.tails) R.tails.forEach((n, i) => c.set(n, -0.15 * fly + Math.sin(t * 1.5 + i) * 0.04, Math.sin(t * 1.2 + i * 0.6) * 0.05 * (1 + 3 * fly), 0));
  const legs = R.legs; const fold = fly + a.rest * 0.0;
  for (const key in legs) { const Lg = legs[key]; if (!Lg) continue; const side = key === 'L' ? 0 : 0.5; const s = Math.sin(P + side * TAU), cs = Math.cos(P + side * TAU); const lift = Math.max(0, -cs) * a.move * (1 - fly);
    c.set(Lg[0], -0.5 * s * a.move * (1 - fly) + 1.1 * fold - 0.9 * a.rest, 0, 0); c.set(Lg[1], lift * 1.0 + 0.9 * fold + 1.5 * a.rest, 0, 0); c.set(Lg[2], -lift * 0.6 - 0.7 * fold - 1.5 * a.rest, 0, 0); if (Lg[3]) c.set(Lg[3], lift * 0.5 + 0.5 * fold, 0, 0); }
}

// ---------- fénix: alas plegadas en Z con abanico de plumas, cola serpenteante, cresta ----------
const PHX_HF = [1.4, -1.45, 1.5]; // rumbo del ala plegada (rad; 0 = hacia afuera, + = hacia atrás): brazo, antebrazo, mano
function phxData(inst) {
  if (inst._phx) return inst._phx; const g = inst.rig.meta.grp || {}, o = { L: [], R: [] };
  for (const k in g) if (o[g[k].side]) o[g[k].side].push(Object.assign({ name: k }, g[k])); return inst._phx = o;
}
function phoenixAnim(c) {
  const inst = c.inst, R = inst.rig.roles, m = inst.rig.meta, a = c.amt, t = c.t, P = c.phase * TAU, fly = a.fly, glide = a.glide, mv = a.move, sp = c.sp;
  const fp = c.flap * TAU, hovK = fly * (1 - clamp(mv / 0.7, 0, 1)), amp = ((sp.anim && sp.anim.flapAmp) || 0.85) * (1 - glide * 0.8) * (1 + 0.4 * hovK), rest = a.rest * (1 - fly);
  const open = clamp(Math.max(a.sing, a.roar, a.alert * 0.3), 0, 1) * (1 - fly), f = clamp((1 - fly) * (1 - open), 0, 1), D = phxData(inst), H0 = m.armH || [0.1, 0.1, 0.1];
  for (const side of ['L', 'R']) {
    const W = R.wings[side]; if (!W) continue; const sx = side === 'L' ? 1 : -1;
    const th = [0, 1, 2].map(k => f * (PHX_HF[k] - H0[k])), rollF = [-0.85, 0, 0], dsp = [0.28 + 0.1 * Math.sin(t * 1.5 + c.seed), -0.08, -0.12];
    const fl = [0.62 * Math.sin(fp), 0.4 * Math.sin(fp - 0.6), 0.5 * Math.sin(fp - 1.2)], dih = [0.16 + 0.12 * glide, 0.04, 0];
    const WR = R.wroot && R.wroot[side];
    for (let k = 0; k < 3; k++) {
      const rl = amp * fl[k] * fly + dih[k] * fly + dsp[k] * open + Math.sin(t * 1.1 + k) * 0.012 * (1 - fly) + (k === 0 ? 0 : rollF[k] * f);
      if (k === 0 && WR) c.set(WR, 0, 0, sx * (rl + rollF[0] * f)); else c.set(W[k], k === 0 ? -0.08 * fly : 0, 0, sx * (rl + (k === 0 ? rollF[0] * f : 0)));
      c.set(W[k], k === 0 && WR ? -0.08 * fly : 0, sx * (th[k] - (k ? th[k - 1] : 0)), 0);
    }
    D[side].forEach(g => {
      const T = 1.5 - 0.03 * (g.rank || 0) * (g.kind === 'chain' ? 1 : 0), yaw = f * ((T - g.h) - (PHX_HF[g.seg] - H0[g.seg]));
      const spread = g.kind === 'chain' && g.seg === 2 ? ((g.rank || 0) - 1.5) * 0.07 * (fly + open * 0.7) : 0;
      c.set(g.name, 0, sx * (yaw + spread), 0);
      if (g.kind === 'chain') { const kk = g.seg === 2 ? 0.5 + 0.1 * (g.rank || 0) : g.seg === 1 ? 0.3 : 0.18; c.set(g.name + 't', 0, sx * spread * 0.5, sx * (-kk * Math.cos(fp - 0.5 - 0.35 * g.seg) * fly * amp + Math.sin(t * 2.3 + g.seg + (g.rank || 0)) * 0.03 * (0.4 + fly))); }
    });
  }
  const rootN = R.root;
  c.trans(rootN, 0, Math.abs(Math.sin(P)) * 0.03 * mv * (1 - fly) + Math.sin(fp) * 0.06 * fly + Math.sin(t * 1.5) * 0.004 - (m.hipY * 0.5) * rest, 0);
  c.set(rootN, -0.1 * fly - 0.5 * hovK + 0.1 * glide - 0.05 * a.sing, Math.sin(P) * 0.04 * mv * (1 - fly), Math.sin(t * 0.6 + c.seed) * 0.05 * fly);
  R.spine.forEach((n, i) => c.set(n, Math.sin(t * 1.5 + i) * 0.012 - 0.05 * a.sing * i, 0, 0));
  const look = Math.sin(t * 0.55 + c.seed) * 0.3 * (1 - mv) * (1 - fly), peck = Math.max(0, Math.sin(t * 2.2 + c.seed)) * a.graze;
  R.neck.forEach((n, i) => c.set(n, 0.2 * fly * (i < 3 ? 1 : 0.5) - 0.1 * a.sing - 0.04 * a.alert + 0.16 * a.graze + 0.15 * peck + 0.1 * rest + Math.sin(P * 2) * 0.03 * mv * (1 - fly), look * 0.35, 0));
  c.set(R.head, -0.25 * fly - 0.15 * a.sing + 0.3 * peck + 0.2 * a.graze, look * 0.4, Math.sin(t * 0.5 + c.seed) * 0.1 * (1 - mv));
  if (R.jaw) c.set(R.jaw, a.sing * (0.3 + 0.3 * Math.max(0, Math.sin(t * 9))) + a.roar * 0.5, 0, 0);
  if (R.tails) { const nT = R.tails.length, tw = t * (1.3 + 1.6 * fly + 0.7 * mv), ay = 0.016 + 0.02 * fly + 0.012 * mv; R.tails.forEach((n, i) => c.set(n, -0.05 * fly - 0.012 * a.sing + Math.sin(tw * 0.7 - i * 0.45) * 0.02 * (1 + fly) + 0.03 * rest, Math.sin(tw - i * 0.5 + c.seed) * ay * (0.6 + i / nT) + 0.07 * rest * (i < 6 ? 1 : 0.4), 0)); }
  if (R.pf && R.pf.crest) R.pf.crest.forEach(ch => ch.forEach((n, i) => c.set(n, -0.09 * fly + 0.03 * a.sing + Math.sin(t * 2 + i * 0.7) * 0.03, Math.sin(t * 1.4 + i * 0.9 + c.seed) * 0.05, 0)));
  for (const key in R.legs) { const Lg = R.legs[key]; if (!Lg) continue; const sd = key === 'L' ? 0 : 0.5, s = Math.sin(P + sd * TAU), cs = Math.cos(P + sd * TAU), lift = Math.max(0, -cs) * mv * (1 - fly);
    c.set(Lg[0], -0.5 * s * mv * (1 - fly) + 1.1 * fly - 0.9 * rest, 0, 0); c.set(Lg[1], lift + 0.9 * fly + 1.5 * rest, 0, 0); c.set(Lg[2], -lift * 0.6 - 0.7 * fly - 1.5 * rest, 0, 0); if (Lg[3]) c.set(Lg[3], lift * 0.5 + 0.5 * fly, 0, 0); }
}

// ---------- cuadrúpedo alado (grifo, dragón, pegaso) ----------
function winged(c) {
  const a = c.amt; const sp = c.sp;
  // en vuelo, las patas se pliegan
  const flyFold = a.fly; const save = a.move; if (flyFold > 0.01) { a.move = save * (1 - flyFold); a.rest = a.rest * (1 - flyFold); }
  quadBody(c); quadLegs(c, { amp: 0.5 });
  if (flyFold > 0.01) { const R = c.inst.rig.roles; for (const key in R.legs) { const L = R.legs[key]; if (!L) continue; const front = key[0] === 'F'; c.set(L[0], (front ? -0.9 : 0.5) * flyFold, 0, 0); c.set(L[1], (front ? 1.7 : 1.4) * flyFold, 0, 0); c.set(L[2], (front ? 0.5 : -1.0) * flyFold, 0, 0); } a.move = save; }
  wings(c, { amp: (sp.anim && sp.anim.flapAmp) || 0.75, lag: 0.45, fold0: 0.35, fold1: -1.7, fold2: 1.8, dihedral: 0.2, spread: (sp.anim && sp.anim.idleSpread) || 0 });
  const R = c.inst.rig.roles; if (flyFold > 0) { c.set(R.root, -0.28 * flyFold + 0.15 * a.glide, 0, 0); c.trans(R.root, 0, Math.sin(c.flap * TAU) * 0.08 * (c.inst.rig.meta.H || 1) * a.fly, 0); }
  // rugido: cabeza atrás y mandíbula
  if (a.roar > 0.01) { R.neck.forEach(n => c.set(n, -0.4 * a.roar * Math.sin(Math.min(1, c.t * 0 + 1)) , 0, 0)); c.set(R.jaw, 0.5 * a.roar + Math.sin(c.t * 18) * 0.05 * a.roar, 0, 0); }
}

// ---------- serpentino (dragón oriental, serpientes) ----------
function serpent(c) {
  const R = c.inst.rig.roles, a = c.amt, t = c.t; const P = c.phase * TAU; const body = R.spine; const mv = Math.max(a.move, 0.15 + a.fly * 0.25);
  const ampH = (0.2 + 0.25 * mv) * (1 - a.rest * 0.4), k = (c.sp.anim && c.sp.anim.k) || 0.55;
  const ph = P * 1 + 0; // fase viajera
  body.forEach((n, i) => { const f = Math.sin(ph - i * k); c.set(n, a.fly * Math.sin(ph * 0.9 - i * k * 0.8) * 0.12 * (0.5 + i * 0.02), f * ampH * (0.55 + 0.45 * Math.min(1, i / 6)), 0); });
  if (a.rest > 0.01) body.forEach((n, i) => { c.set(n, 0, a.rest * Math.sin(i * 0.5) * 0.3 + a.rest * (0.5 + Math.sin(i * 0.3) * 0.3), 0); });
  if (R.neck.length) R.neck.forEach((n, i) => c.set(n, -0.2 * a.sing - 0.1 * a.alert + 0.3 * a.rest + Math.sin(t * 0.6 + i) * 0.04, Math.sin(ph - (body.length + i) * k) * 0.2, 0));
  c.set(R.head, -0.15 * a.roar + Math.sin(t * 0.9) * 0.05, Math.sin(t * 0.5) * 0.15, 0);
  if (R.jaw) c.set(R.jaw, a.roar * 0.6 + a.sing * 0.3 + Math.max(0, Math.sin(t * 0.7 + c.seed) - 0.8) * 1.0, 0, 0);
  if (R.tails) R.tails.forEach((n, i) => c.set(n, a.fly * Math.sin(ph - (body.length + 4 + i) * k) * 0.1, Math.sin(ph - (body.length + 4 + i) * k) * ampH * (0.9 + i * 0.05), 0));
  // patitas
  for (const key in R.legs) { const L = R.legs[key]; if (!L) continue; const s = Math.sin(P + (key[1] === 'L' ? 0 : Math.PI) + (key[0] === 'F' ? 0 : 1.6)); L.forEach((n, i) => c.set(n, s * 0.5 * (i === 0 ? 1 : 0.3) * Math.max(a.move, 0.2), 0, 0)); c.set(L[1], Math.max(0, Math.cos(P + (key[1] === 'L' ? 0 : Math.PI))) * 0.5, 0, 0); }
  // bigotes y melena
  if (R.whiskers) R.whiskers.forEach((chain, wi) => chain.forEach((n, i) => c.set(n, Math.sin(t * 2.2 + wi + i * 0.6) * 0.18, Math.sin(t * 1.7 + wi * 2 + i * 0.5) * 0.25, 0)));
  if (R.manes) R.manes.forEach((chain, wi) => chain.forEach((n, i) => c.set(n, Math.sin(t * 1.6 + wi * 0.7 - i * 0.7) * 0.2, Math.sin(ph - (i + wi) * k) * 0.15, 0)));
  wings(c, {});
}

// ---------- tentáculos (kraken) ----------
function kraken(c) {
  const R = c.inst.rig.roles, a = c.amt, t = c.t, P = c.phase * TAU; const mv = Math.max(a.move, 0.25);
  R.tentacles.forEach((chain, ti) => chain.forEach((n, i) => { const ph = t * (1.2 + mv * 1.4) - i * 0.6 + ti * 0.9; c.set(n, Math.sin(ph) * (0.35 + 0.25 * mv) * (0.7 + i * 0.12) + 0.2 * a.rest, Math.sin(ph * 0.8 + 1) * 0.28, 0); }));
  if (R.spine) R.spine.forEach((n, i) => c.set(n, Math.sin(t * 1.4 + i) * 0.04 - 0.1 * a.move, Math.sin(P) * 0.05, 0));
  c.trans(R.root, 0, Math.sin(t * 1.0) * 0.12 + Math.sin(P * 0.5) * 0.15 * a.move, 0);
  if (R.arms && R.arms.L) ['L', 'R'].forEach(s => R.arms[s].forEach((n, i) => c.set(n, Math.sin(t * 1.5 + i) * 0.3 * (s === 'L' ? 1 : -1), 0, 0)));
}

// ---------- bípedo/cuadrúpedo pesado (golem, ent) ----------
function biped(c) {
  const R = c.inst.rig.roles, m = c.inst.rig.meta, a = c.amt, t = c.t, P = c.phase * TAU;
  const mv = a.move; c.trans(R.root, 0, Math.abs(Math.sin(P)) * 0.05 * (m.H || 1) * mv - (m.hipY || 0) * 0.35 * a.rest, Math.sin(P) * 0.0);
  R.spine.forEach((n, i) => c.set(n, 0.04 * Math.sin(t * 1.0) + 0.5 * a.rest * (i ? 0.3 : 0.5) + (a.roar * -0.25), Math.sin(P) * 0.12 * mv * (i ? 1 : -1), Math.sin(P) * 0.04 * mv));
  for (const side of ['L', 'R']) {
    const sx = side === 'L' ? 1 : -1; const ph = P + (side === 'L' ? 0 : Math.PI); const s = Math.sin(ph), cs = Math.cos(ph); const lift = Math.max(0, -cs);
    const Lg = R.legs[side]; if (Lg) { c.set(Lg[0], -0.7 * s * mv - 1.3 * a.rest, 0, 0); c.set(Lg[1], lift * 1.0 * mv + 2.2 * a.rest, 0, 0); if (Lg[2]) c.set(Lg[2], -lift * 0.4 * mv, 0, 0); }
    const Ar = R.arms[side]; if (Ar) { c.set(Ar[0], 0.6 * s * mv + a.roar * -1.6 + a.sing * -1.2 - 0.2 * a.alert, 0, sx * (0.1 + 0.9 * a.roar)); if (Ar[1]) c.set(Ar[1], -0.2 - 0.3 * lift * mv - 0.5 * a.roar, 0, 0); }
  }
  if (R.neck) R.neck.forEach(n => c.set(n, 0.1 * a.rest + Math.sin(t * 0.7) * 0.03, Math.sin(t * 0.4 + c.seed) * 0.3 * (1 - mv), 0));
  c.set(R.head, -0.2 * a.roar, Math.sin(t * 0.4 + c.seed) * 0.15, 0); if (R.jaw) c.set(R.jaw, a.roar * 0.7, 0, 0);
  if (R.extras) R.extras.forEach((chain, i) => chain.forEach((n, j) => c.set(n, Math.sin(t * 0.9 + i + j * 0.5) * 0.06, Math.sin(t * 0.7 + i * 2 + j * 0.4) * 0.08, 0)));
}

// ---------- tortuga ----------
function turtle(c) {
  const R = c.inst.rig.roles, a = c.amt, t = c.t, P = c.phase * TAU; const mv = Math.max(a.move, 0.2 * a.fly);
  for (const key in R.legs) { const L = R.legs[key]; if (!L) continue; const front = key[0] === 'F'; const ph = P + (front === (key[1] === 'L') ? 0 : Math.PI); const s = Math.sin(ph);
    if (a.fly > 0.5) { c.set(L[0], s * 0.25, 0, (key[1] === 'L' ? 1 : -1) * Math.sin(t * 1.4 + (front ? 0 : 1)) * 0.5); L.slice(1).forEach(n => c.set(n, 0.15, 0, 0)); }
    else { c.set(L[0], -0.5 * s * mv + -1.0 * a.rest, 0, 0); c.set(L[1], Math.max(0, Math.cos(ph)) * 0.5 * mv + 1.0 * a.rest, 0, 0); } }
  R.neck.forEach((n, i) => c.set(n, -0.15 * a.sing + Math.sin(t * 0.6 + i) * 0.05 + 0.5 * a.rest * (i ? 1 : 1.2) * 0, Math.sin(t * 0.3 + c.seed) * 0.3 * (1 - mv), 0)); c.set(R.head, Math.sin(t * 0.5) * 0.04, 0, 0);
  if (R.tails) R.tails.forEach((n, i) => c.set(n, 0, Math.sin(t * 1.2 - i) * 0.2 * (0.3 + mv), 0));
  c.trans(R.root, 0, Math.sin(t * 0.8) * 0.05 * a.fly - 0.1 * a.rest, 0);
}


// ---------- dragones gigantes (esqueletos prototipo) ----------
const flapU = p => p + 0.38 * Math.sin(p); // fase sesgada: bajada firme, subida más lenta y suave
function dragonWings(c, o) {
  const R = c.inst.rig.roles; if (!R.wings || !R.wings.L) return; const a = c.amt, t = c.t; o = o || {};
  const fp = c.flap * TAU; const sprd = clamp(Math.max(o.spread || 0, a.roar * 0.9, a.sing * 0.35) * (1 - a.rest) * (1 - a.move * 0.6), 0, 1);
  const open = clamp(a.fly + (1 - a.fly) * sprd, 0, 1), fold = (R.wingRest === 'folded') ? -open : 1 - open, glide = a.glide, fly = a.fly; const amp = (o.amp || 0.6) * (1 - glide * 0.9);
  const u0 = flapU(fp), u1 = flapU(fp - 0.55), u2 = flapU(fp - 1.0); const flex1 = Math.max(0, -Math.sin(u1)) * fly, flex2 = Math.max(0, -Math.sin(u2)) * fly;
  for (const side of ['L', 'R']) {
    const W = R.wings[side]; if (!W) continue; const sx = side === 'L' ? 1 : -1; const br = Math.sin(t * 1.1 + (sx > 0 ? 0 : 1.3)) * 0.02;
    // hombro: sube/baja + ligero barrido hacia delante/atrás; plegado: húmero hacia atrás y arriba
    c.set(W[0], -0.1 * fly + 0.1 * Math.sin(u0) * fly, sx * fold * 1.15, sx * (amp * Math.cos(u0) * fly + (0.16 + glide * 0.08) * open - fold * 0.2 + br));
    // codo y muñeca con retardo; en la subida se flexionan (membrana recogida)
    if (W[1]) c.set(W[1], 0, sx * fold * -2.5, sx * (amp * 0.5 * Math.cos(u1) * fly - flex1 * 0.32 + br * 0.5));
    if (W[2]) c.set(W[2], 0, sx * fold * 2.35, sx * (amp * 0.5 * Math.cos(u2) * fly - flex2 * 0.38 + br * 0.5));
    const F = R.fingers && R.fingers[side];
    if (F) F.forEach((chain, fi) => chain.forEach((b, i) => { const lag = 1.15 + fi * 0.18 + i * 0.28; const ue = flapU(fp - lag); const fl = Math.max(0, -Math.sin(ue)) * fly; c.set(b, 0, sx * fold * (i === 0 ? 0.45 - fi * 0.38 : 0) + sx * (open * (fi - 1.5) * -0.02), sx * (amp * 0.3 * Math.cos(ue) * fly - fl * 0.16 + Math.sin(t * 0.9 + fi + i) * 0.012)); }));
    const T = R.thumbs && R.thumbs[side]; if (T) c.set(T[0], 0.2 * fold, 0, 0);
  }
}
function dragonBody(c, o) {
  const R = c.inst.rig.roles, m = c.inst.rig.meta, a = c.amt, t = c.t; const P = c.phase * TAU; const sp = c.sp; const rootN = R.root || R.spine[0];
  const mv = a.move * (1 - a.fly); const breath = Math.sin(t * 1.3) * 0.014 * (1 + a.rest);
  c.trans(rootN, 0, Math.sin(P * 2) * 0.012 * (m.H || 1) * mv - (m.hipY ? (m.hipY - 0.5) * 0.4 * a.rest : 0), 0);
  R.spine.forEach((n, i) => c.set(n, breath * (i + 1) * 0.35 + Math.sin(P * 2 + i) * 0.02 * mv, Math.sin(P) * 0.06 * mv * (i ? 0.7 : 1), 0));
  const look = Math.sin(t * 0.31 + c.seed) * 0.22 * (1 - mv * 0.6), lookP = Math.sin(t * 0.21 + c.seed * 2) * 0.1; const up = a.sing, al = a.alert, ro = a.roar;
  R.neck.forEach((n, i) => c.set(n, -0.09 * up - 0.11 * ro + 0.05 * a.rest - 0.02 * al + Math.sin(t * 0.8 - i * 0.55 + c.seed) * 0.018 + Math.sin(P * 2 - i * 0.5) * 0.02 * mv, look * 0.14 + Math.sin(t * 0.55 - i * 0.5 + c.seed) * 0.02 + Math.sin(P - i * 0.4) * 0.03 * mv, 0));
  c.set(R.head, 0.04 * ro - 0.05 * up + lookP * 0.3, look * 0.35, Math.sin(t * 0.4 + c.seed) * 0.03);
  if (R.jaw) c.set(R.jaw, ro * (0.75 + 0.06 * Math.sin(t * 16)) + up * (0.35 + 0.1 * Math.sin(t * 3)) + 0.02 * Math.sin(t * 1.3) + Math.max(0, Math.sin(t * 0.37 + c.seed) - 0.93) * 4, 0, 0);
  if (R.horns) R.horns.forEach((ch, hi) => ch.forEach((n, i) => c.set(n, Math.sin(t * 0.9 + hi + i * 0.6) * 0.012, 0, 0)));
}
function dragonTail(c, o) {
  const R = c.inst.rig.roles, a = c.amt, t = c.t; if (!R.tails || !R.tails.length) return; const fly = a.fly, mv = a.move * (1 - fly); const w = 1.25 + 1.0 * mv + 0.55 * fly; const n = R.tails.length; c.tw = (c.tw || 0) + 0; const ph = c.tailPh || 0;
  R.tails.forEach((b, i) => { const g = 1 + i * 0.035; const yawA = (0.042 + 0.03 * mv + 0.026 * fly) * g, pitA = (0.016 + 0.014 * fly) * (1 + i * 0.05);
    c.set(b, Math.sin(ph * 0.8 - i * 0.36 + 1.2) * pitA - 0.012 * fly - (i === 0 ? 0.04 * a.rest : 0) + (a.rest > 0 ? 0 : 0), Math.sin(ph - i * 0.4) * yawA + (a.rest * 0.07), 0); });
}
function dragonW(c) {
  const a = c.amt; const sp = c.sp; c.tailPh = (c.tailPh || 0); const R = c.inst.rig.roles;
  const w = 1.25 + 1.0 * a.move * (1 - a.fly) + 0.55 * a.fly; c.tailPh += (c._dt || 0.016) * w;
  const flyFold = a.fly; const save = a.move; if (flyFold > 0.01) { a.move = save * (1 - flyFold); a.rest = a.rest * (1 - flyFold); }
  dragonBody(c); quadLegs(c, { amp: 0.5 });
  if (flyFold > 0.01) { for (const key in R.legs) { const L = R.legs[key]; if (!L) continue; const front = key[0] === 'F'; c.set(L[0], (front ? -0.9 : 0.55) * flyFold, 0, 0); c.set(L[1], (front ? 1.7 : 1.4) * flyFold, 0, 0); c.set(L[2], (front ? 0.5 : -1.0) * flyFold, 0, 0); } a.move = save; }
  // dedos de las patas: se enroscan al caminar, al volar y al descansar
  if (R.toes) for (const key in R.toes) { const P = c.phase * TAU + (key === 'FR' || key === 'HL' ? Math.PI : 0); const lift = Math.max(0, -Math.cos(P)) * a.move; R.toes[key].forEach((ch, ti) => ch.forEach((n, i) => c.set(n, (0.18 + 0.35 * lift + 0.7 * flyFold + 0.35 * a.rest) * (i ? 1 : 0.6) + Math.sin(c.t * 1.1 + ti + i) * 0.02, 0, 0))); }
  dragonWings(c, { amp: (sp.anim && sp.anim.flapAmp) || 0.6, spread: (sp.anim && sp.anim.idleSpread) || 0 });
  dragonTail(c);
  if (flyFold > 0) { c.set(R.root, -0.22 * flyFold + 0.12 * a.glide, 0, 0); c.trans(R.root, 0, Math.sin(c.flap * TAU - 0.4) * 0.07 * (c.inst.rig.meta.H || 1) * a.fly, 0); }
}

// ---------- dragón oriental: cuerpo guiado por curva (ondas viajeras suaves, vuelo mágico, enrosque de orgullo) ----------
// El cuerpo no se dobla hueso a hueso con senos: cada segmento recibe una dirección objetivo (rumbo y elevación) que sale de una forma
// (onda extendida o espiral vertical) y de ahí se calculan las rotaciones de los huesos. La cabeza queda anclada y el cuerpo ondula detrás.
const _qi = new Q(), _qa = new Q(), _qb = new Q(), _qc = new Q(), _va = new V3(), _vb = new V3(), _ee = new E(0, 0, 0, 'YXZ');
function ypQ(q, v) { _ee.set(-Math.asin(clamp(v.y, -1, 1)), Math.atan2(v.x, v.z), 0, 'YXZ'); return q.setFromEuler(_ee); }
function eInit(c) {
  if (c._e) return c._e;
  const inst = c.inst, R = inst.rig.roles, m = inst.rig.meta, rp = inst.restPos || {}, pi = inst.rig.pathInfo;
  const names = (R.tails || []).slice().reverse().concat(R.spine || [], R.neck || []).filter(n => rp[n]); const M = names.length;
  const nodes = names.map(n => rp[n]); const nl = nodes[Math.max(0, M - 1)] || [0, 0, 0];
  nodes.push(R.head && rp[R.head] ? rp[R.head] : [nl[0], nl[1], nl[2] + (m.bl || 0.3)]);
  const len = new Float32Array(M), U = new Float32Array(M), rest = [], tg = [], Qw = [], pos = []; let acc = 0;
  for (let i = 0; i < M; i++) { const v = new V3(nodes[i + 1][0] - nodes[i][0], nodes[i + 1][1] - nodes[i][1], nodes[i + 1][2] - nodes[i][2]); len[i] = Math.max(v.length(), 1e-4); rest.push(v.multiplyScalar(1 / len[i])); U[i] = acc + len[i] / 2; acc += len[i]; tg.push(new V3()); Qw.push(new Q()); }
  for (let i = 0; i <= M; i++) pos.push(new V3()); for (let i = 0; i < M; i++) U[i] /= acc;
  const f0 = new V3(nodes[M][0] - nodes[0][0], 0, nodes[M][2] - nodes[0][2]); const yaw0 = f0.lengthSq() > 1e-8 ? Math.atan2(f0.x, f0.z) : 0; const qf = new Q().setFromAxisAngle(new V3(0, 1, 0), yaw0);
  const idxOf = new Map(); names.forEach((n, i) => idxOf.set(n, i)); const par = new Int16Array(M).fill(-1);
  for (let i = 0; i < M; i++) { let p = inst.byName[names[i]] && inst.byName[names[i]].parent; while (p && p.isBone && !idxOf.has(p.name)) p = p.parent; par[i] = p && p.isBone ? idxOf.get(p.name) : -1; }
  let rt0 = names.indexOf(R.root); if (rt0 < 0) rt0 = Math.min(Math.max(0, M - 1), (R.tails || []).length);
  const rad = new Float32Array(M + 1); for (let i = 0; i <= M; i++) rad[i] = (pi && pi.rds && pi.rds[Math.min(i, pi.rds.length - 1)]) || m.R || 0.4;
  return (c._e = { par, qf, yaw0, names, M, nodes, len, rest, tg, Qw, pos, U, Ltot: acc, rt: rt0, rad, R0: m.R || 0.4, psi: new Float32Array(M), eps: new Float32Array(M), psiC: new Float32Array(M), epsC: new Float32Array(M), kap: new Float32Array(M) });
}
// forma de enrosque vertical (orgullo/majestad): espiral de varias vueltas apiladas, tramo que sube y cuello en arco con la cabeza mirando al frente y hacia abajo
function eCoil(E, m, psiF, ph) {
  const { M, len, U, Ltot, R0, psiC, epsC, kap } = E; const rho = (m.coilRho || 3.3) * R0;
  const Lw = 0.64 * Ltot, rem = Ltot - Lw;
  const Lb = Math.min(5 * R0, 0.14 * rem), Ld = Math.min(3.2 * R0, 0.16 * rem), La = Math.min(6 * R0, 0.3 * rem), Lr = Math.max(0.05 * rem, rem - Lb - La - Ld);
  let tot = 0; for (let i = 0; i < M; i++) { const s = U[i] * Ltot; if (s < Lw) { const f = s / Lw; kap[i] = 1 + 0.8 * Math.pow(1 - f, 2.2); tot += kap[i] * len[i]; } else kap[i] = 0; }
  const ks = (Lw / rho) / (tot || 1); const gam = Math.asin(clamp((m.coilPitch || 2.3) * R0 / (TAU * rho), 0, 0.3)); const top = Math.PI / 2 + 0.2, end = -0.45; let acc = 0;
  const s1 = Lw + Lb, s2 = s1 + Lr, s3 = s2 + La;
  for (let i = M - 1; i >= 0; i--) { acc += kap[i] * ks * len[i]; psiC[i] = psiF - acc; const s = U[i] * Ltot; let e;
    if (s < Lw) e = gam; else if (s < s1) e = lerp(gam, top, sm(0, 1, (s - Lw) / Lb)); else if (s < s2) e = top + 0.26 * Math.sin(TAU * (s - s1) / Math.max(12 * R0, 0.9 * Lr) + ph) * sm(0, 0.15 * Lr + 1e-3, s - s1) * (1 - sm(0.8 * Lr, Lr + 1e-3, s - s1)); else if (s < s3) e = lerp(top, end, sm(0, 1, (s - s2) / La)); else e = end; epsC[i] = e; }
  return Lw;
}
// forma de reposo tendido: cuerpo sinuoso apoyado en el suelo (S), cuello en arco de cisne y cabeza mirando al frente (mundo de dragones)
function eLie(E, m, psiF, ph, P) {
  const { M, U, Ltot, psiC, epsC } = E; P = P || {};
  const nb = P.nb || 1.4, amp = P.amp || 1.0, phs = P.phase || 0, uL = P.uL || 0.82, rise = P.rise === undefined ? 1.3 : P.rise, endE = P.endE === undefined ? -0.3 : P.endE;
  const g0 = Math.sin(TAU * nb + phs);
  for (let i = 0; i < M; i++) {
    const u = U[i], uu = Math.min(u, uL) / uL;
    psiC[i] = psiF + amp * (Math.sin(TAU * nb * uu + phs) - g0) + 0.045 * Math.sin(TAU * 1.3 * u - ph * 1.6) * sm(0, 0.25, u) * (1 - sm(0.8, 0.95, u));
    let e = 0; if (u > uL) { const t = (u - uL) / (1 - uL); e = t < 0.45 ? lerp(0, rise, sm(0, 0.45, t)) : lerp(rise, endE, sm(0.45, 1, t)); }
    epsC[i] = e + (u < uL ? 0.012 * Math.sin(ph * 0.9 + u * 4) : 0);
  }
  return uL * Ltot;
}
function eDrive(c, E, wt, rest, name2) {
  const { M, rt, tg, Qw, pos, len, names, psi, eps } = E; const inst = c.inst;
  for (let i = 0; i < M; i++) { const ce = Math.cos(eps[i]); tg[i].set(Math.sin(psi[i]) * ce, Math.sin(eps[i]), Math.cos(psi[i]) * ce).applyQuaternion(E.qf); }
  pos[rt].set(0, 0, 0); for (let i = rt; i < M; i++) pos[i + 1].copy(pos[i]).addScaledVector(tg[i], len[i]); for (let i = rt; i > 0; i--) pos[i - 1].copy(pos[i]).addScaledVector(tg[i - 1], -len[i - 1]);
  // rotaciones: raíz sin balanceo; el resto por transporte paralelo (sin torsión) hacia la cabeza y hacia la cola
  const par = E.par, QI = _qi; const pq = i => (par[i] >= 0 && par[i] !== i ? Qw[par[i]] : QI);
  _va.copy(tg[rt]); if (rt > 0) _va.add(tg[rt - 1]).normalize(); ypQ(_qa, _va); ypQ(_qb, E.rest[rt]).invert(); Qw[rt].copy(_qa).multiply(_qb); _qb.copy(pq(rt)).invert().multiply(Qw[rt]); _ee.setFromQuaternion(_qb, 'YXZ'); c.set(names[rt], _ee.x, _ee.y, _ee.z);
  for (let i = rt + 1; i < M; i++) { const pr = par[i] >= 0 && par[i] < i ? Qw[par[i]] : Qw[i - 1]; _va.copy(E.rest[i]).applyQuaternion(pr); _qa.setFromUnitVectors(_va, tg[i]); Qw[i].copy(_qa).multiply(pr); _qb.copy(pr).invert().multiply(Qw[i]); _ee.setFromQuaternion(_qb, 'YXZ'); c.set(names[i], _ee.x, _ee.y, _ee.z); }
  for (let j = rt - 1; j >= 1; j--) { const pr = par[j] >= 0 && par[j] > j ? Qw[par[j]] : Qw[j + 1]; _va.copy(E.rest[j - 1]).negate().applyQuaternion(pr); _vb.copy(tg[j - 1]).negate(); _qa.setFromUnitVectors(_va, _vb); Qw[j].copy(_qa).multiply(pr); _qb.copy(pr).invert().multiply(Qw[j]); _ee.setFromQuaternion(_qb, 'YXZ'); c.set(names[j], _ee.x, _ee.y, _ee.z); }
}
function dragonE(c) {
  const inst = c.inst, R = inst.rig.roles, a = c.amt, t = c.t, m = inst.rig.meta; const dt = c._dt || 0; const E = eInit(c); const M = E.M, rt = E.rt, U = E.U;
  const body = M >= 4 && !!R.root;
  if (c.cw === undefined) c.cw = a.coil; c.cw += (a.coil - c.cw) * Math.min(1, dt * 0.9); const w = c.cw, wt = sm(0, 1, w);
  const mv = Math.max(a.move, a.fly * 0.4), spd = m.spd || 1;
  const hz = (0.13 + 0.2 * a.move + 0.14 * a.fly) * spd * (1 - 0.7 * wt); c.eph = (c.eph || 0) + dt * hz * TAU; const ph = c.eph, ph2 = ph * 0.43 + 1.3;
  // ---- onda extendida: rumbo (zigzag) y elevación en cuadratura; la cabeza apenas se mueve y la cola se agita más
  const calm = 1 - 0.5 * a.rest; const breathe = 1 + 0.12 * Math.sin(t * 0.37);
  const A = (0.17 + 0.1 * a.move + 0.42 * a.fly) * calm * breathe * (m.amp || 1), Ap = A * (0.22 + 0.1 * a.fly), A2 = A * 0.3, nw = (m.nw || 1.7) * (1 - 0.32 * a.fly);
  const imp = (c.look ? 0.6 : 0) + a.alert * 0.8 + wt * 0.9; const lift = 0.2 * imp + 0.35 * a.sing + 0.12 * a.roar;
  // mirada: el rumbo de la cabeza persigue al observador
  if (c.look && m.hf && R.head) { const hb = inst.byName[R.head]; if (hb) { const e = hb.matrixWorld.elements; const q = new Q(); hb.getWorldQuaternion(q); const fv = new V3(m.hf[0], m.hf[1], m.hf[2]).applyQuaternion(q); const tx = c.look.x - e[12], tz = c.look.z - e[14]; const cr = fv.z * tx - fv.x * tz, d2 = fv.x * tx + fv.z * tz; const lim = 1.3 + 1.8 * wt; c.lookYaw = clamp((c.lookYaw || 0) + clamp(Math.atan2(cr, d2), -0.8, 0.8) * dt * 1.8, -lim, lim); } } else c.lookYaw = (c.lookYaw || 0) * (1 - Math.min(1, dt * 0.8));
  const lookYaw = c.lookYaw || 0; const psi = E.psi, eps = E.eps;
  if (body) for (let i = 0; i < M; i++) { const u = U[i]; const env = (1 + 0.55 * Math.pow(1 - u, 1.5)) * (1 - 0.85 * sm(0.72, 0.96, u)); const phi = TAU * nw * u + ph; const nk = sm(0.74, 0.97, u);
    psi[i] = A * env * Math.cos(phi) + A2 * env * Math.cos(TAU * 0.7 * u - ph2) + lookYaw * 0.5 * (1 - wt) * nk;
    eps[i] = Ap * env * Math.cos(phi + 1.3) + 0.5 * Ap * env * Math.cos(TAU * 0.6 * u - ph2 * 1.3) + lift * sm(0.62, 0.9, u) + 0.03 * Math.sin(t * 0.5 + u * 5) * (1 - 0.6 * wt); }
  let Lw = 0;
  if (body && wt > 0.001) { Lw = c.shape === 'lie' ? eLie(E, m, lookYaw, ph * 0.7, c.lieP) : eCoil(E, m, lookYaw, ph * 0.7); for (let i = 0; i < M; i++) { psi[i] = lerp(psi[i], E.psiC[i], wt); eps[i] = lerp(eps[i], E.epsC[i], wt); } }
  if (body) eDrive(c, E);
  // anclaje: cabeza fija en modo onda; espiral centrada y apoyada en el suelo en modo enrosque
  if (body) {
    const P0 = E.nodes[rt], HP = E.nodes[M], pos = E.pos; let tx = HP[0] - P0[0] - pos[M].x, ty = HP[1] - P0[1] - pos[M].y, tz = HP[2] - P0[2] - pos[M].z;
    ty -= Math.max(0, P0[1] - 1.3 * E.R0) * a.rest * (1 - wt);
    if (wt > 0.001) { let sx = 0, sz = 0, n = 0, mn = 1e9; for (let i = 0; i <= M; i++) { if (i < M && U[i] * E.Ltot < Lw) { sx += pos[i].x; sz += pos[i].z; n++; } mn = Math.min(mn, pos[i].y - E.rad[Math.min(i, M)] * 0.9); } n = n || 1; const cx = -sx / n, cz = -sz / n, cy = 0.06 * E.R0 - P0[1] - mn; tx = lerp(tx, cx, wt); ty = lerp(ty, cy, wt); tz = lerp(tz, cz, wt); }
    c.trans(R.root, tx, ty, tz);
  }
  // ---- cabeza, mandíbula, cuernos
  const hY = lookYaw * 0.5 * (1 - wt);
  c.set(R.head, -0.3 * lift + Math.sin(t * 0.9) * 0.025, hY + Math.sin(t * 0.45) * 0.05 * (1 - imp * 0.5) - Math.sin(ph + 0.7) * 0.05 * (1 - imp * 0.5), 0);
  if (R.jaw) c.set(R.jaw, a.roar * 0.7 + a.sing * 0.3 + imp * 0.1 + 0.03 * Math.sin(t * 1.4) + Math.max(0, Math.sin(t * 0.37 + c.seed) - 0.92) * 5, 0, 0);
  if (R.horns) R.horns.forEach((ch, hi) => ch.forEach((n, i) => c.set(n, Math.sin(t * 0.9 + hi + i * 0.6) * 0.012, 0, 0)));
  // ---- patas cortas: colgando al estar quieto, recogidas hacia atrás en vuelo/enrosque, pasos al caminar
  const tuck = clamp(a.fly + a.rest * 0.6 + wt, 0, 1); const gph = c.phase * TAU;
  for (const key in R.legs) { const L = R.legs[key]; if (!L) continue; const front = key[0] === 'F'; const off = (front ? 0 : Math.PI) + (key[1] === 'L' ? 0 : Math.PI * 0.5); const s = Math.sin(gph + off), q = Math.max(0, Math.cos(gph + off)); const stp = a.move * (1 - a.fly) * (1 - wt);
    const bob = 0.07 * Math.sin(ph * 1.1 + off);
    if (front) { c.set(L[0], s * 0.35 * stp + 0.85 * tuck + bob, 0, 0); c.set(L[1], q * 0.5 * stp + 1.0 * tuck, 0, 0); c.set(L[2], q * 0.3 * stp + 0.5 * tuck, 0, 0); c.set(L[3], 0.12 * Math.sin(ph * 1.1 + off - 0.8) + 0.3 * tuck, 0, 0); }
    else { c.set(L[0], s * 0.35 * stp + 1.0 * tuck + bob, 0, 0); c.set(L[1], q * 0.5 * stp - 0.5 * tuck, 0, 0); c.set(L[2], -q * 0.4 * stp + 0.9 * tuck, 0, 0); c.set(L[3], 0.12 * Math.sin(ph * 1.1 + off - 0.8) + 0.4 * tuck, 0, 0); } }
  if (R.toes) for (const key in R.toes) R.toes[key].forEach((ch, ti) => ch.forEach((n, i) => c.set(n, 0.2 + 0.18 * Math.sin(t * 1.3 + ti * 0.7 + i * 0.5 + (key[0] === 'F' ? 0 : 1)) + 0.45 * tuck, 0, 0)));
  if (R.whiskers) R.whiskers.forEach((ch, wi) => ch.forEach((n, i) => c.set(n, Math.sin(ph * 1.3 + wi * 1.7 - i * 0.55) * 0.045, Math.sin(ph * 1.1 + wi * 2.3 - i * 0.45) * 0.07, 0)));
  if (R.manes) R.manes.forEach((ch, wi) => ch.forEach((n, i) => c.set(n, Math.sin(ph * 0.9 + wi * 0.8 - i * 0.6) * 0.06, Math.sin(ph + wi * 0.5 - i * 0.7 + 1) * 0.07, 0)));
  if (R.tufts) R.tufts.forEach((ch, wi) => ch.forEach((n, i) => c.set(n, Math.sin(ph * 0.9 + wi * 0.7 - i * 0.6) * 0.06, Math.sin(ph * 1.1 + wi * 0.4 - i * 0.5 + 2) * 0.09, 0)));
  if (R.wings && R.wings.L) wings(c, {});
}

const KINDS = { dragonW, dragonE, quad: c => { quadBody(c); quadLegs(c); }, bird, winged, serpent, kraken, biped, turtle };

function update(c, dt, speed) {
  c.t += dt; c._dt = Math.min(dt, 0.1); for (const k of AMT) c.amt[k] += (c.tgt[k] - c.amt[k]) * Math.min(1, dt * 3.5);
  const a = c.amt; c.speed = speed === undefined ? c.speed : speed; const stride = (c.inst.rig.meta.stride || 1) * (a.fly ? 1.0 : 1);
  const m = Math.max(a.move, 0.0001);
  const freq = (c.sp.kind === 'serpent' || c.sp.kind === 'dragonE') ? 0.35 + 0.8 * a.move : clamp((c.speed || m * 2.2) / stride * 0.55, 0.15, 3.2);
  if (c.kind === 'bird' || c.kind === 'winged' || c.kind === 'dragonW') c.flap += dt * (c.sp.anim && c.sp.anim.flapHz || 2.4) * (1 - a.glide * 0.9) * (a.fly > 0.2 ? (0.5 + a.move * 0.8) : 0);
  c.phase += dt * freq * (a.fly > 0.5 && (c.kind === 'winged' || c.kind === 'dragonW') ? 0.5 : 1);
  (KINDS[c.kind] || KINDS.quad)(c);
  apply(c);
}
function pose(inst, o) { // pose estática para pruebas/miniaturas
  const c = make(inst, o); setState(c, o.state || 'idle'); AMT.forEach(k => c.amt[k] = c.tgt[k]); c.t = o.t || 0; c.tailPh = c.eph = (o.t || 0) * 1.2; c.phase = o.phase || 0; c.flap = o.flap || 0; update(c, 0, o.speed); inst._ctrl = c; return c;
}
return { make, setState, update, pose, STATES: Object.keys(S), prepare };
}

