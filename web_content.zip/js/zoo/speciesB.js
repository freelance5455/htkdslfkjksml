// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 5724-5855 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_SPECIES_B(Z, SP) {
const { THREE, clamp, lerp, smooth, mix3, fbm, Rig, sweep, bez, taper } = Z;
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const noiseCol = (c, f, a) => 1 + (fbm(c.x * f, c.y * f, c.z * f, 3) - 0.5) * a;
const hex = h => [((h >> 16) & 255) / 255, ((h >> 8) & 255) / 255, (h & 255) / 255];

function birdBuild(P) {
  const r = new Rig(P.id); r.ks = clamp(P.L / 0.8, 0.12, 3); const L = P.L, bh = P.bh, bw = P.bw, hy = P.hy; r.meta.H = hy + bh; r.meta.hipY = hy; r.meta.stride = P.stride || 0.5; r.meta.flapAmp = P.flapAmp;
  r.bone('body', null, [0, hy, 0]); r.bone('chest', 'body', [0, hy + bh * 0.2, L * 0.28]);
  // cuello
  const nb = [0, hy + bh * 0.55, L * 0.38]; let pts = [nb]; (P.neck).forEach(o => pts.push(add(nb, [0, o[0], o[1]])));
  const nn = pts.length - 1, names = []; for (let i = 1; i < pts.length - 1; i++) { r.bone('neck' + i, i === 1 ? 'chest' : 'neck' + (i - 1), pts[i]); names.push('neck' + i); }
  const hp = pts[pts.length - 1]; r.bone('head', names.length ? names[names.length - 1] : 'chest', hp); r.bone('jaw', 'head', add(hp, [0, -P.hr * 0.35, P.hr * 0.3]));
  const nr = taper(pts.length, P.nr0, P.nr1, 1);
  const first = [add(nb, [0, -P.nr0 * 0.4, -0.02])].concat(pts.slice(1));
  r.cone('chest', nb, pts[1] || hp, nr[0], nr[1] || nr[0], 0.06);
  for (let i = 1; i < pts.length - 1; i++) r.cone('neck' + i, pts[i], pts[i + 1], nr[i], nr[i + 1], 0.05);
  // torso
  r.ell('body', [0, hy, -L * 0.05], [bw, bh, L * 0.42], 0.1); r.ell('chest', [0, hy + bh * 0.12, L * 0.27], [bw * 0.95, bh * 0.98, L * 0.3], 0.1);
  r.cone('body', [0, hy, -L * 0.25], [0, hy - bh * 0.05, -L * 0.45], bw * 0.7, bw * 0.28, 0.08, { sc: [1, 0.55, 1] });
  if (P.keel) r.ell('chest', [0, hy - bh * 0.5, L * 0.28], [bw * 0.3, bh * 0.5, L * 0.28], 0.1);
  // cabeza + pico
  const hr = P.hr; r.ell('head', add(hp, [0, hr * 0.05, hr * 0.25]), [hr * 0.95, hr, hr * 1.2], 0.04);
  if (P.crest) { r.cone('head', add(hp, [0, hr * 0.7, -hr * 0.1]), add(hp, [0, hr * 1.9, -hr * 1.1]), hr * 0.18, hr * 0.03, 0.03, { sc: [0.5, 1, 1] }); }
  const bk = P.beak, b0 = add(hp, [0, -hr * 0.12, hr * 0.85]);
  const tip = add(b0, [0, -bk.drop, bk.len]);
  r.cone('head', b0, tip, bk.r, bk.r * (bk.taper === undefined ? 0.25 : bk.taper), 0.02, { sc: [bk.w || 0.8, 1, 1] });
  if (bk.hook) r.cone('head', tip, add(tip, [0, -bk.hook, -bk.len * 0.08]), bk.r * 0.25, bk.r * 0.04, 0.015);
  r.cone('jaw', add(b0, [0, -bk.r * 0.7, -bk.len * 0.1]), add(tip, [0, bk.r * 0.1 + bk.r * 0.9, -bk.len * 0.08]), bk.r * 0.55, bk.r * 0.12, 0.012, { sc: [bk.w || 0.8, 1, 1] });
  r.sub('head', 'rc', [add(b0, [0, -bk.r * 0.42, -bk.len * 0.1]), add(tip, [0, bk.r * 0.1 + bk.r * 0.15, -bk.len * 0.1]), bk.r * 0.06, bk.r * 0.04], 0.01);
  for (const sx of [-1, 1]) r.rigid.push({ bone: 'head', eye: { r: hr * (P.eyeR || 0.25), slit: false }, at: add(hp, [sx * hr * 0.82, hr * 0.2, hr * 0.5]) });
  // alas
  const span = P.span / 2, sh0 = [bw * 0.85, hy + bh * 0.35, L * 0.12];
  const wp = [sh0, [span * 0.2, sh0[1] + 0.01, sh0[2] - span * 0.04], [span * 0.45, sh0[1], sh0[2] - span * 0.07], [span * 0.62, sh0[1], sh0[2] - span * 0.04]];
  const wr = [P.wr * 1.3, P.wr, P.wr * 0.7, P.wr * 0.4]; r.roles.wings = {};
  for (const sx of [-1, 1]) {
    const side = sx > 0 ? 'L' : 'R'; const pp = wp.map(p => [p[0] * sx, p[1], p[2]]);
    const wn = r.chain('wing' + side + '_', 'chest', pp, wr, 0.04); r.roles.wings[side] = wn;
    // plumas
    const fc = P.featherCols; const nPrim = P.nPrim || 8, nSec = P.nSec || 9;
    for (let i = 0; i < nPrim; i++) { const t = i / (nPrim - 1); const base = [lerp(pp[2][0], pp[3][0], t) , lerp(pp[2][1], pp[3][1], t) - 0.003 * i, lerp(pp[2][2], pp[3][2], t)]; const len = span * (0.3 + 0.16 * (1 - Math.abs(t - 0.25)) ) * (P.primLen || 1); const ang = lerp(-0.25, 0.65, t); const dir = [sx * Math.cos(ang) * 0.55, -0.02, -Math.sin(Math.abs(ang) + 0.35) * 0.8]; const dl = Math.hypot(...dir); r.decor.push({ type: 'feather', kind: 'feather', base, dir: dir.map(x => x / dl), len, w: span * 0.065, bend: -0.05, cf: tt => mix3(fc[0], fc[1], Math.min(1, tt * 1.1 + i * 0.01)) }); }
    for (let i = 0; i < nSec; i++) { const t = i / (nSec - 1); const base = [lerp(pp[1][0], pp[2][0], t), pp[1][1] - 0.004, lerp(pp[1][2], pp[2][2], t) - 0.01]; const len = span * (0.34 + 0.06 * t) * (P.secLen || 1); const dir = [sx * 0.08, -0.04, -1]; const dl = Math.hypot(...dir); r.decor.push({ type: 'feather', kind: 'feather', base, dir: dir.map(x => x / dl), len, w: span * 0.07, bend: -0.04, cf: tt => mix3(fc[2], fc[3], tt) }); }
    for (let i = 0; i < 6; i++) { const t = i / 5; const base = [lerp(pp[0][0], pp[2][0], t), pp[0][1] + 0.012, lerp(pp[0][2], pp[2][2], t)]; r.decor.push({ type: 'feather', kind: 'feather', base, dir: [sx * 0.1, 0.0, -1], len: span * 0.2, w: span * 0.06, bend: 0.0, cf: tt => mix3(fc[4], fc[5], tt) }); }
  }
  // patas
  r.roles.legs = {}; const legH = hy - bh * 0.6;
  for (const sx of [-1, 1]) {
    const key = sx > 0 ? 'L' : 'R'; const kz = P.legFwd === undefined ? 0.09 : P.legFwd;
    const pts = [[sx * bw * 0.5, hy - bh * 0.55, -L * 0.04], [sx * bw * 0.55, hy - bh * 0.55 - legH * 0.4, L * kz], [sx * bw * 0.5, legH * 0.1 + 0.01, -L * 0.03], [sx * bw * 0.5, 0.012, L * 0.0]];
    const nm = r.chain('leg' + key + '_', 'body', pts, [P.lt * 1.8, P.lt * 1.0, P.lt * 0.7, P.lt * 0.8], 0.03); r.roles.legs[key] = nm;
    r.ell(nm[0], [pts[0][0], pts[0][1] - bh * 0.1, pts[0][2]], [bw * 0.38, bh * 0.55, L * 0.12], 0.08);
    const f = pts[3]; const toes = [[0, 0], [0.5, 0], [-0.5, 0], [0, -1]]; toes.forEach((tt, ti) => { const back = ti === 3; const len = P.toe * (back ? 0.5 : 1); const tp = [[f[0], f[1] + 0.004, f[2]], [f[0] + tt[0] * len * 0.5, 0.008, f[2] + (back ? -len * 0.6 : len * 0.7)], [f[0] + tt[0] * len * 0.8, 0.004, f[2] + (back ? -len * 0.9 : len * 1.0)]]; r.rigid.push({ bone: nm[3], mat: P.talon ? 'claw' : 'dark', geo: sweep(tp, [P.lt * 0.75, P.lt * 0.6, P.lt * (P.talon ? 0.25 : 0.4)], 5) }); });
  }
  // cola
  const tl = P.tail; const tp = [[0, hy, -L * 0.42], [0, hy - 0.01, -L * 0.42 - tl * 0.5], [0, hy - 0.02, -L * 0.42 - tl]]; r.roles.tails = r.chain('tail', 'body', tp, [bw * 0.5, bw * 0.4, bw * 0.15], 0.05, { sc: [1, 0.4, 1] });
  const nT = P.nTail || 7; for (let i = 0; i < nT; i++) { const t = (i / (nT - 1) - 0.5) * 2; const dir = [t * 0.38, -0.02 - Math.abs(t) * 0.02, -1]; const dl = Math.hypot(...dir); r.decor.push({ type: 'feather', kind: 'feather', base: [t * bw * 0.4, hy - 0.01, -L * 0.42 - tl * 0.35], dir: dir.map(x => x / dl), len: tl * (1.05 - Math.abs(t) * 0.25), w: tl * 0.17, bend: -0.03, cf: tt => mix3(P.tailCols[0], P.tailCols[1], tt) }); }
  r.roles.spine = ['body', 'chest']; r.roles.neck = names; r.roles.head = 'head'; r.roles.jaw = 'jaw'; r.roles.root = 'body';
  r.meta.hp = hp; r.meta.hr = hr; r.meta.P = P; return r;
}
function birdPaint(P) {
  return c => {
    const n = noiseCol(c, 60, 0.28), st = fbm(c.x * 160, c.y * 160, c.z * 60, 2); let col = mix3(P.belly, P.back, smooth(-0.5, 0.35, c.ny));
    if (c.bone === 'head' || c.bone === 'jaw' || c.bone.startsWith('neck')) col = P.headFn ? P.headFn(c, col) : mix3(col, P.head, P.headMix === undefined ? 0.6 : P.headMix);
    if (/^leg/.test(c.bone) && c.y < (P.legCut || 0.2)) col = P.legCol;
    if (/^wing/.test(c.bone)) col = mix3(col, P.wingCol || P.back, 0.7);
    if (/^tail/.test(c.bone)) col = P.tailCols[0];
    if ((c.bone === 'head') && c.z > c.rig.meta.hp[2] + c.rig.meta.hr * 0.85) col = P.beakCol; if (c.bone === 'jaw' && c.z > c.rig.meta.hp[2] + c.rig.meta.hr * 0.5) col = P.beakCol;
    const bars = P.bars ? 1 - P.bars * smooth(0.55, 0.9, Math.sin(c.y * 220 + c.z * 90) * 0.5 + 0.5) * smooth(0.0, 0.5, -c.ny + 0.5) : 1;
    const k = n * (0.9 + 0.22 * st) * bars; return [col[0] * k, col[1] * k, col[2] * k];
  };
}

// ---------- Ruiseñor ----------
(function() {
  const P = { id: 'ruisenor', L: 0.15, bh: 0.036, bw: 0.034, hy: 0.075, neck: [[0.022, 0.012], [0.04, 0.03]], nr0: 0.024, nr1: 0.016, hr: 0.025, beak: { len: 0.02, drop: 0.002, r: 0.007, w: 0.8 }, span: 0.24, wr: 0.007, lt: 0.0042, toe: 0.025, tail: 0.075, legFwd: 0.1, stride: 0.12, flapAmp: 1.0, nPrim: 6, nSec: 6, eyeR: 0.28,
    featherCols: [[0.36, 0.26, 0.18], [0.28, 0.2, 0.14], [0.4, 0.29, 0.2], [0.3, 0.22, 0.15], [0.4, 0.3, 0.22], [0.45, 0.33, 0.24]], tailCols: [[0.55, 0.33, 0.17], [0.5, 0.28, 0.14]], nTail: 6 };
  SP.ruisenor = { id: 'ruisenor', kind: 'bird', name: 'Ruiseñor Canoro', cat: 'animales', rank: 'comun', int: 5, pow: 1, spd: 6, hab: 'Bosque y colinas', diet: 'Insectívoro', move: 'ground', fly: true, cell: 0.0024, size: 0.16,
    desc: 'Pequeña ave cuyo canto nocturno llena el bosque de melodías. Trina desde las ramas y salta entre el pasto.',
    habits: { wander: 3, idle: 2, sing: 5, fly: 2 }, social: 'flee', sound: 'song', eyeColor: 0x120c08,
    style: { detail: 'feather', dscale: 38, dstr: 0.7, rough: 0.9 }, build: () => birdBuild(P),
    paint: birdPaint({ back: [0.38, 0.28, 0.2], belly: [0.78, 0.7, 0.58], head: [0.36, 0.27, 0.19], headMix: 0.5, legCol: [0.62, 0.5, 0.44], beakCol: [0.22, 0.18, 0.15], tailCols: [[0.55, 0.33, 0.17], [0.5, 0.28, 0.14]], legCut: 0.05 }) };
})();
// ---------- Águila real ----------
(function() {
  const P = { id: 'aguila', L: 0.8, bh: 0.15, bw: 0.13, hy: 0.55, neck: [[0.06, 0.1], [0.12, 0.2]], nr0: 0.085, nr1: 0.07, hr: 0.07, beak: { len: 0.075, drop: 0.015, r: 0.032, w: 0.7, hook: 0.05, taper: 0.3 }, span: 2.2, wr: 0.035, lt: 0.016, toe: 0.12, tail: 0.38, legFwd: 0.07, stride: 0.5, flapAmp: 0.75, nPrim: 9, nSec: 10, talon: true, keel: true, eyeR: 0.27, primLen: 1.05,
    featherCols: [[0.25, 0.17, 0.1], [0.12, 0.09, 0.06], [0.36, 0.25, 0.14], [0.2, 0.14, 0.09], [0.42, 0.3, 0.17], [0.5, 0.36, 0.2]], tailCols: [[0.45, 0.33, 0.2], [0.14, 0.1, 0.07]], nTail: 9 };
  SP.aguila = { id: 'aguila', kind: 'bird', name: 'Águila Real', cat: 'animales', rank: 'raro', int: 6, pow: 5, spd: 9, hab: 'Montañas y colinas', diet: 'Carnívoro', move: 'ground', fly: true, cell: 0.016, size: 0.9,
    desc: 'Reina de los cielos. Planea durante horas sobre las corrientes de aire y caza con una vista prodigiosa.',
    habits: { fly: 6, idle: 2, rest: 2, sing: 1 }, social: 'wary', sound: 'screech', eyeColor: 0xd89a10,
    style: { detail: 'feather', dscale: 8, dstr: 0.8, rough: 0.85 }, build: () => birdBuild(P),
    paint: birdPaint({ back: [0.30, 0.2, 0.12], belly: [0.42, 0.3, 0.19], head: [0.62, 0.45, 0.22], headMix: 0.55, legCol: [0.9, 0.72, 0.18], beakCol: [0.9, 0.75, 0.2], tailCols: [[0.45, 0.33, 0.2], [0.14, 0.1, 0.07]], legCut: 0.3, bars: 0.35 }) };
})();
// ---------- Grulla de corona roja ----------
(function() {
  const P = { id: 'grulla', L: 0.7, bh: 0.15, bw: 0.1, hy: 0.78, neck: [[0.14, 0.04], [0.3, 0.0], [0.46, 0.06], [0.58, 0.16]], nr0: 0.06, nr1: 0.026, hr: 0.04, beak: { len: 0.17, drop: 0.012, r: 0.016, w: 0.7, taper: 0.25 }, span: 2.1, wr: 0.028, lt: 0.011, toe: 0.12, tail: 0.15, legFwd: 0.0, stride: 0.6, flapAmp: 0.6, nPrim: 8, nSec: 9, eyeR: 0.22,
    featherCols: [[0.05, 0.05, 0.06], [0.1, 0.1, 0.1], [0.96, 0.96, 0.95], [0.9, 0.9, 0.9], [0.96, 0.96, 0.95], [0.92, 0.92, 0.9]], tailCols: [[0.95, 0.95, 0.94], [0.88, 0.88, 0.86]], nTail: 5, primLen: 0.9 };
  SP.grulla = { id: 'grulla', kind: 'bird', name: 'Grulla de Corona Roja', cat: 'animales', rank: 'raro', int: 7, pow: 2, spd: 6, hab: 'Costas y humedales', diet: 'Omnívoro', move: 'ground', fly: true, cell: 0.013, size: 1.4,
    desc: 'Símbolo de longevidad en la tradición china. Baila con las alas abiertas y su grito resuena en la niebla.',
    habits: { wander: 4, idle: 3, sing: 2, fly: 2, rest: 1 }, social: 'wary', sound: 'crane', eyeColor: 0x3a1208,
    style: { detail: 'feather', dscale: 9, dstr: 0.6, rough: 0.85 }, build: () => birdBuild(P),
    paint: birdPaint({ back: [0.96, 0.96, 0.95], belly: [0.94, 0.94, 0.93], head: [0.06, 0.06, 0.07], legCol: [0.08, 0.08, 0.08], beakCol: [0.8, 0.78, 0.6], tailCols: [[0.95, 0.95, 0.94], [0.88, 0.88, 0.86]], legCut: 0.7,
      headFn: (c, col) => { const m = c.rig.meta; if (c.bone === 'head' || c.bone === 'jaw') { const top = smooth(m.hp[1] + m.hr * 0.35, m.hp[1] + m.hr * 0.75, c.y); return c.z > m.hp[2] + m.hr * 0.9 ? col : mix3([0.95, 0.95, 0.94], [0.8, 0.07, 0.07], top); } const t = c.bone.startsWith('neck') ? 1 : 0; return mix3(col, [0.05, 0.05, 0.06], t * (0.4 + 0.6 * smooth(m.hp[1] - 0.3, m.hp[1] - 0.1, c.y))); } }) };
})();
// ---------- Fénix ----------
(function() {
  const P = { id: 'fenix', L: 1.3, bh: 0.22, bw: 0.18, hy: 1.1, neck: [[0.1, 0.14], [0.22, 0.28], [0.28, 0.4]], nr0: 0.12, nr1: 0.07, hr: 0.09, beak: { len: 0.14, drop: 0.02, r: 0.04, w: 0.65, hook: 0.045, taper: 0.22 }, span: 4.6, wr: 0.05, lt: 0.02, toe: 0.17, tail: 1.3, legFwd: 0.08, stride: 0.8, flapAmp: 0.8, nPrim: 10, nSec: 11, talon: true, crest: true, eyeR: 0.26, primLen: 1.1, nTail: 5,
    featherCols: [[1.0, 0.7, 0.12], [0.75, 0.08, 0.14], [1.0, 0.5, 0.08], [0.62, 0.06, 0.12], [0.98, 0.6, 0.1], [0.9, 0.3, 0.08]], tailCols: [[0.8, 0.1, 0.16], [0.95, 0.65, 0.2]] };
  SP.fenix = { id: 'fenix', kind: 'bird', name: 'Fénix (凤凰)', cat: 'leyendas', rank: 'mitico', int: 10, pow: 9, spd: 9, hab: 'Cielos y montañas', diet: 'Llamas y rocío', move: 'ground', fly: true, cell: 0.026, size: 1.9, glow: true,
    desc: 'Ave de fuego que renace de sus cenizas. Su canto cura a los fieles y su plumaje ilumina la noche.',
    habits: { fly: 6, hover: 2, sing: 3, idle: 2 }, social: 'curious', sound: 'phoenix', eyeColor: 0xffe070,
    style: { detail: 'feather', dscale: 4, dstr: 0.5, rough: 0.6, emissive: 0xff5a10, emissiveI: 0.55 },
    build() {
      const r = birdBuild(P); // largas plumas de fuego en la cola y cresta
      const hy = P.hy, L = P.L; for (let i = 0; i < 5; i++) { const t = (i - 2) / 2; const path = bez([t * 0.06, hy, -L * 0.4], [t * 0.35, hy + 0.1, -L * 0.4 - 0.6], [t * 1.0, hy - 0.5, -L * 0.4 - 1.4], [t * 1.3, hy - 0.7, -L * 0.4 - 2.6], 14); r.decor.push({ type: 'ribbon', kind: 'fire', path, w0: 0.09, w1: 0.28, c0: [1, 0.8, 0.2], c1: [1, 0.15, 0.02], up: [0, 1, 0], pw: 1.2, af: t2 => 0.95 * (1 - Math.pow(t2, 2.2)) }); }
      const hp = r.meta.hp; for (let i = 0; i < 3; i++) { const t = (i - 1); const path = bez(add(hp, [t * 0.02, 0.07, -0.02]), add(hp, [t * 0.04, 0.2, -0.12]), add(hp, [t * 0.07, 0.28, -0.3]), add(hp, [t * 0.09, 0.2, -0.5]), 10); r.decor.push({ type: 'ribbon', kind: 'fire', path, w0: 0.03, w1: 0.07, c0: [1, 0.9, 0.4], c1: [1, 0.2, 0.05], up: [1, 0, 0], af: t2 => 0.9 * (1 - t2 * 0.8) }); }
      return r;
    },
    paint: birdPaint({ back: [0.6, 0.06, 0.14], belly: [0.95, 0.72, 0.5], head: [0.66, 0.08, 0.16], headMix: 0.8, legCol: [0.55, 0.4, 0.2], beakCol: [0.85, 0.7, 0.4], tailCols: [[0.8, 0.1, 0.16], [0.95, 0.65, 0.2]], legCut: 0.4, wingCol: [0.95, 0.4, 0.06] }) };
})();
// ---------- Ave del Trueno ----------
(function() {
  const P = { id: 'trueno', L: 1.5, bh: 0.28, bw: 0.22, hy: 1.4, neck: [[0.1, 0.15], [0.2, 0.3], [0.24, 0.42]], nr0: 0.15, nr1: 0.09, hr: 0.11, beak: { len: 0.17, drop: 0.02, r: 0.05, w: 0.65, hook: 0.06, taper: 0.22 }, span: 6.2, wr: 0.065, lt: 0.026, toe: 0.2, tail: 0.9, legFwd: 0.08, stride: 0.9, flapAmp: 0.75, nPrim: 10, nSec: 11, talon: true, crest: true, eyeR: 0.24, primLen: 1.1, nTail: 7,
    featherCols: [[0.08, 0.12, 0.3], [0.7, 0.85, 1.0], [0.12, 0.2, 0.45], [0.55, 0.7, 0.95], [0.9, 0.95, 1.0], [0.3, 0.5, 0.9]], tailCols: [[0.2, 0.3, 0.7], [0.9, 0.95, 1.0]] };
  SP.trueno = { id: 'trueno', kind: 'bird', name: 'Ave del Trueno', cat: 'leyendas', rank: 'legendario', int: 8, pow: 9, spd: 9, hab: 'Cumbres y tormentas', diet: 'Relámpagos', move: 'ground', fly: true, cell: 0.034, size: 2.2,
    desc: 'Gigante cuyas alas provocan tormentas. Cuando bate el vuelo, el cielo se oscurece y retumban los truenos.',
    habits: { fly: 7, hover: 1, sing: 2, idle: 1 }, social: 'wary', sound: 'thunder', eyeColor: 0xbfe8ff,
    style: { detail: 'feather', dscale: 3, dstr: 0.6, rough: 0.55, emissive: 0x3a70ff, emissiveI: 0.2 }, build: () => birdBuild(P),
    paint: birdPaint({ back: [0.1, 0.16, 0.38], belly: [0.78, 0.88, 1.0], head: [0.88, 0.94, 1.0], headMix: 0.7, legCol: [0.9, 0.82, 0.3], beakCol: [0.95, 0.85, 0.3], tailCols: [[0.2, 0.3, 0.7], [0.9, 0.95, 1.0]], legCut: 0.5, bars: 0.4 }) };
})();
return { birdBuild };
}

