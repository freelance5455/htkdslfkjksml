// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 5027-5189 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_BUILD(Z) {
const { THREE, V3, clamp, lerp, smooth, mix3, fbm, makeSDF, surfaceNets, sweep, boneTable, skinVerts, segDist, bodyMaterial, featherTexture, yield0, primDist, BUDGET } = Z;
const MAT_CACHE = {};

const IRIS_CACHE = {};
function irisTex(color, slit) {
  const key = color + ':' + (slit ? 1 : 0); if (IRIS_CACHE[key]) return IRIS_CACHE[key];
  const c = document.createElement('canvas'); c.width = c.height = 128; const g = c.getContext('2d'); const col = new THREE.Color(color); const rgb = (m) => 'rgb(' + Math.round(clamp(col.r * 255 * m, 0, 255)) + ',' + Math.round(clamp(col.g * 255 * m, 0, 255)) + ',' + Math.round(clamp(col.b * 255 * m, 0, 255)) + ')';
  const gr = g.createRadialGradient(64, 64, 6, 64, 64, 62); gr.addColorStop(0, rgb(0.55)); gr.addColorStop(0.35, rgb(1.25)); gr.addColorStop(0.8, rgb(0.8)); gr.addColorStop(0.93, rgb(0.35)); gr.addColorStop(1, 'rgba(10,6,4,1)'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  let s = 7; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647; for (let i = 0; i < 90; i++) { const a = rnd() * 6.283, r0 = 12 + rnd() * 10, r1 = 38 + rnd() * 20; g.strokeStyle = rnd() < 0.5 ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.16)'; g.lineWidth = 1 + rnd(); g.beginPath(); g.moveTo(64 + Math.cos(a) * r0, 64 + Math.sin(a) * r0); g.lineTo(64 + Math.cos(a) * r1, 64 + Math.sin(a) * r1); g.stroke(); }
  g.fillStyle = '#050403'; g.beginPath(); if (slit) g.ellipse(64, 64, 9, 34, 0, 0, 6.283); else g.ellipse(64, 64, 22, 22, 0, 0, 6.283); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return (IRIS_CACHE[key] = t);
}
function eyeMesh(r, color, slit, hl) {
  const g = new THREE.Group();
  const ball = new THREE.Mesh(new THREE.SphereGeometry(r, 18, 14), new THREE.MeshStandardMaterial({ color: 0x1b1410, roughness: 0.25 })); g.add(ball);
  const iris = new THREE.Mesh(new THREE.CircleGeometry(r * 0.86, 24), new THREE.MeshStandardMaterial({ map: irisTex(color, slit), roughness: 0.12, metalness: 0.0 })); iris.position.z = r * 0.93; g.add(iris);
  const lid = new THREE.Mesh(new THREE.TorusGeometry(r * 0.98, r * 0.2, 8, 24), new THREE.MeshStandardMaterial({ color: 0x15100d, roughness: 0.7 })); lid.position.z = r * 0.12; g.add(lid);
  const sp = new THREE.Mesh(new THREE.SphereGeometry(r * 0.17, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff })); sp.position.set(r * 0.32, r * 0.34, r * 0.97); g.add(sp);
  return g;
}
function rigidMat(kind, sp) {
  const key = sp.id + kind; if (MAT_CACHE[key]) return MAT_CACHE[key];
  let m;
  if (kind === 'horn') m = new THREE.MeshStandardMaterial({ color: sp.hornColor || 0xd8c9a8, roughness: 0.55, metalness: 0.05 });
  else if (kind === 'dark') m = new THREE.MeshStandardMaterial({ color: sp.darkColor || 0x161212, roughness: 0.35 });
  else if (kind === 'claw') m = new THREE.MeshStandardMaterial({ color: sp.clawColor || 0xe8e0d0, roughness: 0.45 });
  else if (kind === 'gold') m = new THREE.MeshStandardMaterial({ color: 0xe8b84a, roughness: 0.25, metalness: 0.85 });
  else if (kind === 'glow') m = new THREE.MeshBasicMaterial({ color: sp.glowColor || 0xffb040 });
  else m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 });
  MAT_CACHE[key] = m; return m;
}

// construye pesos para geometría suelta (decor): usa todos los huesos
function skinLoose(rig, bt, pos, count) {
  const si = new Uint16Array(count * 4), sw = new Float32Array(count * 4); const nb = rig.bones.length; const ws = new Float32Array(nb);
  for (let v = 0; v < count; v++) {
    const x = pos[v * 3], y = pos[v * 3 + 1], z = pos[v * 3 + 2]; let b0 = -1, b1 = -1, b2 = -1, b3 = -1, w0 = 0, w1 = 0, w2 = 0, w3 = 0;
    for (let j = 0; j < nb; j++) {
      const s = bt.seg[j]; const d = segDist(x, y, z, s[0], s[1]); const w = 1 / Math.pow(d + 0.03, 4);
      if (w > w0) { b3 = b2; w3 = w2; b2 = b1; w2 = w1; b1 = b0; w1 = w0; b0 = j; w0 = w; } else if (w > w1) { b3 = b2; w3 = w2; b2 = b1; w2 = w1; b1 = j; w1 = w; } else if (w > w2) { b3 = b2; w3 = w2; b2 = j; w2 = w; } else if (w > w3) { b3 = j; w3 = w; }
    }
    const t = w0 + w1 + w2 + w3; const ids = [b0, b1, b2, b3], wv = [w0, w1, w2, w3];
    for (let k = 0; k < 4; k++) { si[v * 4 + k] = Math.max(0, ids[k]); sw[v * 4 + k] = ids[k] < 0 ? 0 : wv[k] / t; }
  }
  return { si, sw };
}

function buildDecorGeo(rig, bt, list, kind) {
  const pos = [], idx = [], col = [], uv = [];
  for (const d of list) {
    const base = pos.length / 3;
    if (d.type === 'ribbon') { // d.path puntos, d.w0 d.w1 ancho, d.c0 d.c1 colores, d.up eje ancho
      const n = d.path.length; const up = d.up || [1, 0, 0];
      for (let i = 0; i < n; i++) {
        const t = i / (n - 1), w = lerp(d.w0, d.w1, Math.pow(t, d.pw || 1)) * 0.5; const c = d.cf ? d.cf(t) : mix3(d.c0, d.c1, t); const p = d.path[i];
        pos.push(p[0] - up[0] * w, p[1] - up[1] * w, p[2] - up[2] * w, p[0] + up[0] * w, p[1] + up[1] * w, p[2] + up[2] * w);
        const a = d.af ? d.af(t) : 1; col.push(c[0], c[1], c[2], a, c[0], c[1], c[2], a); uv.push(0, t, 1, t);
      }
      for (let i = 0; i < n - 1; i++) { const a = base + i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    } else if (d.type === 'feather') { // pluma: base, dirección, longitud, ancho, curvatura
      const seg = 4; const b = d.base, dr = d.dir, up = d.up || [0, 1, 0];
      // lateral = dir x up
      let lx = dr[1] * up[2] - dr[2] * up[1], ly = dr[2] * up[0] - dr[0] * up[2], lz = dr[0] * up[1] - dr[1] * up[0]; const ll = Math.hypot(lx, ly, lz) || 1; lx /= ll; ly /= ll; lz /= ll;
      for (let i = 0; i <= seg; i++) {
        const t = i / seg; const bend = (d.bend || 0) * t * t;
        const cx = b[0] + dr[0] * d.len * t + up[0] * bend * d.len, cy = b[1] + dr[1] * d.len * t + up[1] * bend * d.len, cz = b[2] + dr[2] * d.len * t + up[2] * bend * d.len; const w = d.w * 0.5;
        pos.push(cx - lx * w, cy - ly * w, cz - lz * w, cx + lx * w, cy + ly * w, cz + lz * w); const c = d.cf ? d.cf(t) : mix3(d.c0, d.c1, t); col.push(c[0], c[1], c[2], 1, c[0], c[1], c[2], 1); uv.push(0, t, 1, t);
      }
      for (let i = 0; i < seg; i++) { const a = base + i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    } else if (d.type === 'mesh') { // pos,idx,col directos
      for (let i = 0; i < d.pos.length; i += 3) pos.push(d.pos[i], d.pos[i + 1], d.pos[i + 2]);
      for (let i = 0; i < d.col.length; i += 4) col.push(d.col[i], d.col[i + 1], d.col[i + 2], d.col[i + 3]);
      for (let i = 0; i < d.pos.length / 3; i++) uv.push(0, 0);
      for (const k of d.idx) idx.push(base + k);
    }
  }
  if (!pos.length) return null;
  const g = new THREE.BufferGeometry(); const P = new Float32Array(pos); g.setAttribute('position', new THREE.BufferAttribute(P, 3)); g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(col), 4)); g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uv), 2));
  g.setIndex(idx); g.computeVertexNormals();
  const s = skinLoose(rig, bt, P, P.length / 3); g.setAttribute('skinIndex', new THREE.BufferAttribute(s.si, 4)); g.setAttribute('skinWeight', new THREE.BufferAttribute(s.sw, 4));
  return g;
}
let _hairTex = null;
function hairTexture() {
  if (_hairTex) return _hairTex; const cv = document.createElement('canvas'); cv.width = 128; cv.height = 256; const g = cv.getContext('2d'); let s = 91; const rn = () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296;
  g.lineCap = 'round'; for (let i = 0; i < 64; i++) { const x0 = 4 + rn() * 120, len = 150 + rn() * 100, dr = (rn() - 0.5) * 26; g.strokeStyle = 'rgba(255,255,255,' + (0.75 + rn() * 0.25).toFixed(2) + ')'; g.lineWidth = 1.3 + rn() * 2.2; g.beginPath(); g.moveTo(x0, 256); g.quadraticCurveTo(x0 + dr * 0.3, 256 - len * 0.5, x0 + dr, 256 - len); g.stroke(); }
  g.fillStyle = 'rgba(255,255,255,0.95)'; g.fillRect(0, 226, 128, 30);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; _hairTex = t; return t;
}
function decorMaterial(kind, sp) {
  if (kind === 'hair') return new THREE.MeshStandardMaterial({ vertexColors: true, map: hairTexture(), alphaTest: 0.4, side: THREE.DoubleSide, roughness: 0.85, transparent: false });
  if (kind === 'feather') return new THREE.MeshStandardMaterial({ vertexColors: true, map: featherTexture(), alphaTest: 0.45, side: THREE.DoubleSide, roughness: 0.7, transparent: false });
  if (kind === 'fire') return new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  return new THREE.MeshStandardMaterial({ vertexColors: true, side: THREE.DoubleSide, roughness: 0.6, transparent: false });
}

// ----- plantilla (geometría + material + esqueleto) -----
async function buildTemplate(sp, opts) {
  opts = opts || {}; const lod = opts.lod || 0;
  const rig = sp.build(opts); rig.sp = sp; const prims = rig.prims;
  let lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9]; prims.forEach(p => { if (p.op === 'sub') return; for (let i = 0; i < 3; i++) { lo[i] = Math.min(lo[i], p.lo[i] - p.k); hi[i] = Math.max(hi[i], p.hi[i] + p.k); } });
  const pad = (sp.cell || 0.04) * 2.5; lo = lo.map(v => v - pad); hi = hi.map(v => v + pad);
  const cell = (sp.cell || 0.04) * (lod ? 1.9 : 1); const sizeAO = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]); const accM = sizeAO * 0.035 * 1.1 + cell * 3; const sdf = makeSDF(prims, sp.fastSDF ? { bucket: accM, margin: accM } : null);
  const mesh = await surfaceNets(sdf, lo, hi, cell);
  const nV = mesh.pos.length / 3; const addPrims = prims.filter(p => p.op !== 'sub');
  const nearest = (x, y, z) => { let bi = 0, bd = 1e9; for (let i = 0; i < addPrims.length; i++) { const d = primDist(addPrims[i], x, y, z); if (d < bd) { bd = d; bi = i; } } return prims.indexOf(addPrims[bi]); };
  const bt = boneTable(rig);
  const sk = skinVerts(rig, bt, (v, a) => mesh.pos[v * 3 + a], nV, nearest);
  // colores + AO
  const col = new Float32Array(nV * 3); const size = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]); const h1 = size * 0.012, h2 = size * 0.035; let t0 = performance.now();
  const ctx = { rig, sp, size, lo, hi }; const suv = sp.suv ? new Float32Array(nV * 3) : null;
  for (let v = 0; v < nV; v++) {
    const x = mesh.pos[v * 3], y = mesh.pos[v * 3 + 1], z = mesh.pos[v * 3 + 2], nx = mesh.nor[v * 3], ny = mesh.nor[v * 3 + 1], nz = mesh.nor[v * 3 + 2];
    const a1 = clamp(sdf(x + nx * h1, y + ny * h1, z + nz * h1) / h1, 0, 1), a2 = clamp(sdf(x + nx * h2, y + ny * h2, z + nz * h2) / h2, 0, 1);
    const ao = 0.5 + 0.5 * (a1 * 0.4 + a2 * 0.6);
    const bone = rig.bones[sk.si[v * 4]].name;
    ctx.x = x; ctx.y = y; ctx.z = z; ctx.nx = nx; ctx.ny = ny; ctx.nz = nz; ctx.bone = bone; ctx.ao = ao;
    const c = sp.paint(ctx); if (suv) { const s = sp.suv(ctx); suv[v * 3] = s[0]; suv[v * 3 + 1] = s[1]; suv[v * 3 + 2] = s[2]; }
    col[v * 3] = Math.pow(clamp(c[0], 0, 1) * ao, 2.2); col[v * 3 + 1] = Math.pow(clamp(c[1], 0, 1) * ao, 2.2); col[v * 3 + 2] = Math.pow(clamp(c[2], 0, 1) * ao, 2.2);
    if ((v & 1023) === 0 && performance.now() - t0 > BUDGET.ms + 2) { await yield0(); t0 = performance.now(); }
  }
  // gancho opcional: plumas/cartas generadas sobre la superficie ya mallada (usa los pesos de piel de cada vértice)
  if (sp.postMesh) { try { const more = sp.postMesh({ rig, bt, mesh, sk, nV, size, lo, hi, lod, cell }); if (more && more.length) { rig.decor = rig.decor || []; for (const d of more) rig.decor.push(d); } } catch (e) { try { console.warn('postMesh', e); } catch (_) {} } }
  let gPos = mesh.pos, gNor = mesh.nor, gCol = col, gSi = sk.si, gSw = sk.sw;
  { const fx = sp.frameExtra && sp.frameExtra(rig); // puntos de encuadre sin triángulos (para que la cámara abarque alas/cola)
    if (fx && fx.length && !suv) { const n1 = nV + fx.length; gPos = new Float32Array(n1 * 3); gPos.set(mesh.pos); gNor = new Float32Array(n1 * 3); gNor.set(mesh.nor); gCol = new Float32Array(n1 * 3); gCol.set(col); gSi = new Uint16Array(n1 * 4); gSi.set(sk.si); gSw = new Float32Array(n1 * 4); gSw.set(sk.sw); fx.forEach((p, i) => { gPos.set(p, (nV + i) * 3); gNor[(nV + i) * 3 + 1] = 1; gSw[(nV + i) * 4] = 1; }); } }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(gPos, 3)); geo.setAttribute('normal', new THREE.BufferAttribute(gNor, 3)); geo.setAttribute('color', new THREE.BufferAttribute(gCol, 3));
  if (suv) geo.setAttribute('aSU', new THREE.BufferAttribute(suv, 3));
  geo.setAttribute('skinIndex', new THREE.BufferAttribute(gSi, 4)); geo.setAttribute('skinWeight', new THREE.BufferAttribute(gSw, 4)); geo.setIndex(new THREE.BufferAttribute(mesh.idx, 1)); geo.computeBoundingSphere();
  // decor
  const decor = {}; (rig.decor || []).forEach(d => { (decor[d.kind || 'sheet'] = decor[d.kind || 'sheet'] || []).push(d); });
  const decorGeos = {}; for (const k in decor) { const cb = sp.decorBuild && sp.decorBuild[k]; const g = cb ? cb(rig, bt, decor[k], Z) : buildDecorGeo(rig, bt, decor[k], k); if (g) decorGeos[k] = g; }
  // rigid
  const rigid = (rig.rigid || []).map(r => ({ bone: r.bone, geo: r.geo, mat: r.mat, obj: r.obj, at: r.at, rot: r.rot, eye: r.eye }));
  return { sp, rig, geo, decorGeos, rigid, bt, tris: mesh.idx.length / 3 };
}

// ----- instancia -----
function instantiate(tpl) {
  const sp = tpl.sp, rig = tpl.rig; const group = new THREE.Group(); group.name = 'zoo-' + sp.id;
  const bones = rig.bones.map(b => { const o = new THREE.Bone(); o.name = b.name; return o; }); const byName = {};
  rig.bones.forEach((b, i) => { byName[b.name] = bones[i]; const par = b.parent ? byName[b.parent] : null; const pp = b.parent ? rig.byName[b.parent].pos : [0, 0, 0]; bones[i].position.set(b.pos[0] - pp[0], b.pos[1] - pp[1], b.pos[2] - pp[2]); (par || group).add(bones[i]); });
  group.updateMatrixWorld(true); const skeleton = new THREE.Skeleton(bones);
  const mat = tpl.sharedMat || (tpl.sharedMat = (sp.makeMaterial ? sp.makeMaterial(sp, tpl) : bodyMaterial(sp.style || {})));
  const body = new THREE.SkinnedMesh(tpl.geo, mat); body.name = 'body'; body.frustumCulled = false; body.castShadow = true; body.receiveShadow = true; group.add(body); body.bind(skeleton);
  const meshes = [body];
  for (const k in tpl.decorGeos) { const dm = tpl.sharedDecor && tpl.sharedDecor[k] || ((tpl.sharedDecor = tpl.sharedDecor || {})[k] = (sp.decorMat && sp.decorMat[k]) ? sp.decorMat[k](sp, tpl) : decorMaterial(k, sp)); const m = new THREE.SkinnedMesh(tpl.decorGeos[k], dm); m.frustumCulled = false; m.name = 'decor-' + k; group.add(m); m.bind(skeleton); meshes.push(m); if (k === 'fire' || (sp.decorOrder && sp.decorOrder[k])) m.renderOrder = (sp.decorOrder && sp.decorOrder[k]) || 2; }
  for (const r of tpl.rigid) {
    const bp = rig.byName[r.bone].pos; let o;
    if (r.eye) { o = eyeMesh(r.eye.r, sp.eyeColor || 0xd8a020, r.eye.slit, true); o.position.set(r.at[0] - bp[0], r.at[1] - bp[1], r.at[2] - bp[2]); o.lookAt(o.position.clone().add(new V3(r.at[0] > 0 ? 0.6 : -0.6, 0.1, 0.8))); }
    else if (r.obj) { o = r.obj(); o.position.add(new V3(-bp[0], -bp[1], -bp[2])); }
    else { const g = r.geo.clone(); g.translate(-bp[0], -bp[1], -bp[2]); o = new THREE.Mesh(g, rigidMat(r.mat || 'horn', sp)); o.castShadow = true; }
    byName[r.bone].add(o);
  }
  const rest = {}; bones.forEach(b => { rest[b.name] = { q: b.quaternion.clone(), p: b.position.clone() }; });
  return { group, bones, byName, skeleton, meshes, rest, sp, rig };
}

return { buildTemplate, instantiate, eyeMesh };
}

