// Criaturas vivas en el mundo: aparecen cerca del jugador según el bioma, caminan, vuelan o nadan, se asustan o se acercan según
// su carácter, y suenan. Portado de EDEN-Visor-3D (objeto «Zoo») sin depender de su juego: todo lo del mundo llega por parámetros.
//
//   terrain: { heightAt(x, z), biomeAt(x, z), sea }      adapt(group): adapta los materiales al mundo (niebla, sombras de nubes)
//   Los dragones NO aparecen solos en EDEN: viven en SHENLONG y solo se ven aquí si el jugador los invoca desde los ajustes.
import { ZOO_HAB, ZOO_RANKS } from './meta.js';
import { ZooSound } from './sound.js';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const isDragon = (sp) => /^dragon/.test(sp.id);
const TAU = Math.PI * 2;

export function createCreatureManager({ THREE, zoo, scene, terrain, adapt = () => {}, onSeen = () => {}, onNotice = () => {} }) {
  const { heightAt, biomeAt, sea } = terrain;
  const AN = zoo.AN;
  const group = new THREE.Group();
  group.name = 'creatures';
  scene.add(group);
  const ents = [];
  const seen = new Set();
  const st = { cap: 3, enabled: true, sound: true, lowDetail: false, nextSpawn: 4, spawning: false, frameN: 0, disposed: false };
  const dir = new THREE.Vector3();

  // ── Elección y colocación ──────────────────────────────────────────────────────────────────
  function pickSpecies(P) {
    for (let tries = 0; tries < 8; tries++) {
      const a = Math.random() * TAU, d = 45 + Math.random() * 60;
      const x = P.x + Math.cos(a) * d, z = P.z + Math.sin(a) * d;
      const h = heightAt(x, z), bio = biomeAt(x, z), water = h < sea - 3;
      const cand = [];
      for (const sp of zoo.list()) {
        if (sp.noSpawn || isDragon(sp)) continue; // los dragones solo por invocación
        const hab = ZOO_HAB[sp.id] || '*';
        const count = ents.filter((e) => e.sp.id === sp.id).length;
        if (count >= (ZOO_RANKS[sp.rank].w >= 5 ? 3 : 1)) continue;
        if (sp.move === 'water') { if (!water) continue; } else if (h < sea + 1) continue; else if (hab !== '*' && !hab.includes(bio)) continue;
        cand.push([sp, ZOO_RANKS[sp.rank].w * (zoo.tpl[`${sp.id}:0`] || zoo.tpl[`${sp.id}:1`] ? 1.6 : 1)]); // se prefieren las ya construidas
      }
      if (!cand.length) continue;
      let r = Math.random() * cand.reduce((s, c) => s + c[1], 0);
      for (const c of cand) { r -= c[1]; if (r <= 0) return { sp: c[0], x, z }; }
      return { sp: cand[0][0], x, z };
    }
    return null;
  }

  async function spawn(sp, x, z, { pinned = false } = {}) {
    if (st.spawning) return null;
    st.spawning = true;
    try {
      const inst = await zoo.makeInst(sp.id, st.lowDetail && !pinned ? 1 : 0);
      if (st.disposed) return null;
      adapt(inst.group);
      const c = AN.make(inst, { kind: sp.kind });
      const h = heightAt(x, z);
      const e = { sp, inst, c, x, z, y: h, yaw: Math.random() * TAU, mode: 'idle', t: 1 + Math.random() * 3, tx: x, tz: z, air: sp.move === 'air', alt: 0, speed: 0, born: performance.now(), pinned, nextVoice: 4 + Math.random() * 8, accDt: 0, said: false };
      if (sp.move === 'water') e.y = sea - 2.4;
      if (e.air) { e.alt = 25 + Math.random() * 30; e.y = h + e.alt; }
      AN.setState(c, e.mode);
      place(e);
      group.add(inst.group);
      ents.push(e);
      return e;
    } catch (err) {
      console.warn('[criaturas] no se pudo crear', sp.id, err);
      return null;
    } finally { st.spawning = false; }
  }

  const place = (e) => { const g = e.inst.group; g.position.set(e.x, e.y, e.z); g.rotation.y = e.yaw; };
  function despawn(e) { try { e.inst.group.parent?.remove(e.inst.group); } catch {} }
  function clear() { ents.splice(0).forEach(despawn); }

  // ── Comportamiento ─────────────────────────────────────────────────────────────────────────
  const turn = (a, b, k) => { let d = b - a; while (d > Math.PI) d -= TAU; while (d < -Math.PI) d += TAU; return a + d * Math.min(1, k); };
  function vel(e, m) {
    const s = Math.sqrt(e.sp.size || 1);
    return m === 'run' ? 3.2 + 2.2 * s : m === 'walk' ? 0.9 + 0.55 * s : m === 'swim' ? 2 + 0.7 * s : m === 'fly' ? 7 + 2.2 * s : m === 'glide' ? 6 + 1.8 * s : 1;
  }
  function pickMode(e, night) {
    const sp = e.sp, H = sp.habits || { wander: 3, idle: 2 }, list = [];
    const add = (m, w) => { if (w > 0) list.push([m, w]); };
    const loud = /roar|growl|rumble|groan|thunder/.test(sp.sound || '');
    for (const k in H) {
      let w = H[k];
      if (night && k === 'rest') w *= 3;
      if (night && k === 'wander') w *= 0.6;
      if (k === 'wander') add(sp.move === 'water' ? 'swim' : sp.move === 'air' ? 'fly' : 'walk', w);
      else if (k === 'sing') add(loud ? 'roar' : 'sing', w);
      else if (k === 'rest') add(sp.move === 'air' ? 'hover' : 'rest', w);
      else if (k === 'fly') add(sp.move === 'air' ? 'glide' : 'fly', w);
      else add(k, w); // idle, graze, hover…
    }
    if (!list.length) return 'idle';
    let r = Math.random() * list.reduce((s, c) => s + c[1], 0);
    for (const c of list) { r -= c[1]; if (r <= 0) return c[0]; }
    return list[0][0];
  }
  function voice(e, P, force) {
    const sp = e.sp;
    if (!st.sound || !sp.sound) return;
    const dx = e.x - P.x, dz = e.z - P.z, d = Math.hypot(dx, dz);
    const v = Math.pow(clamp(1 - d / 110, 0, 1), 1.6) * (force ? 0.6 : 0.5);
    if (v < 0.02) return;
    ZooSound.play(sp.sound, v, clamp(dx / 60, -1, 1) * 0.6, clamp(1.25 - Math.log10((sp.size || 1) + 1) * 0.5, 0.55, 1.6));
  }
  const idleNow = (e, t) => { e.mode = 'idle'; e.t = t; AN.setState(e.c, 'idle'); };

  function stepEnt(e, dt, P, night) {
    const sp = e.sp, dx = P.x - e.x, dz = P.z - e.z, dist = Math.hypot(dx, dz), size = sp.size || 1, R = 9 + size * 3;
    const toward = Math.atan2(dx, dz), flying = e.air, sf = sp.social;
    let forced = null;
    e.t -= dt;
    if (dist < 22 && !e.said && !seen.has(sp.id)) { e.said = true; seen.add(sp.id); onSeen(sp); }
    if (sf === 'flee' && dist < R && !flying) { forced = 'run'; const a = toward + Math.PI + (Math.random() - 0.5) * 0.6; e.tx = e.x + Math.sin(a) * 40; e.tz = e.z + Math.cos(a) * 40; }
    else if (sf === 'wary' && dist < R * 0.75 && !flying && e.mode !== 'walk' && e.mode !== 'run') { forced = 'alert'; e.yaw = turn(e.yaw, toward, dt * 3); if (e.t < 0.5) e.t = 0.5; }
    else if (sf === 'curious' && dist < R * 1.6 && dist > R * 0.28 && !flying && sp.move !== 'water') {
      if (e.mode !== 'walk' || e.t < 0.5) { e.mode = 'walk'; e.t = 2; AN.setState(e.c, 'walk'); }
      e.tx = P.x - Math.sin(toward) * R * 0.25; e.tz = P.z - Math.cos(toward) * R * 0.25;
    } else if (sf === 'curious' && dist <= R * 0.28 && e.mode === 'walk') idleNow(e, 3);
    if (sf === 'curious' && (e.mode === 'idle' || e.mode === 'sing') && dist < R * 1.6) e.yaw = turn(e.yaw, toward, dt * 2);

    if (forced && e.mode !== forced) {
      e.mode = forced; e.t = 2.5 + Math.random() * 2; AN.setState(e.c, forced);
      if (forced === 'alert' && Math.random() < 0.4) voice(e, P);
    } else if (e.t <= 0) {
      const m = pickMode(e, night);
      e.mode = m; e.t = 3 + Math.random() * 7;
      if (m === 'walk' || m === 'run' || m === 'swim' || m === 'fly' || m === 'glide') {
        const a = Math.random() * TAU, d = 12 + Math.random() * 30 * (m === 'fly' || m === 'glide' ? 2.5 : 1);
        e.tx = e.x + Math.sin(a) * d; e.tz = e.z + Math.cos(a) * d; e.t = d / vel(e, m) + 1;
      }
      if (m === 'fly' || m === 'glide') {
        if (!e.air) { e.air = true; e.alt = 14 + Math.random() * 28 + size * 2; e.landing = false; e.t = 14 + Math.random() * 14; e.tx = e.x + Math.sin(e.yaw) * 120; e.tz = e.z + Math.cos(e.yaw) * 120; e.arc = (Math.random() - 0.5) * 0.35; }
      } else if (e.air && sp.move !== 'air' && (m === 'walk' || m === 'rest' || m === 'idle' || m === 'graze' || m === 'sing' || m === 'roar')) { e.landing = true; e.mode = 'glide'; e.t = 6; }
      AN.setState(e.c, e.mode);
      if (m === 'sing' || m === 'roar') { voice(e, P); e.nextVoice = 3 + Math.random() * 3; }
    }
    if (e.landing) {
      const g = heightAt(e.x, e.z);
      e.alt = Math.max(0, e.alt - dt * 5);
      if (e.alt <= 0.2 && Math.abs(e.y - g) < 0.8) { e.air = false; e.landing = false; idleNow(e, 2); }
    }
    if (e.mode === 'sing' || e.mode === 'roar') { e.nextVoice -= dt; if (e.nextVoice <= 0) { voice(e, P); e.nextVoice = 4 + Math.random() * 5; } }

    const m = e.mode, moving = m === 'walk' || m === 'run' || m === 'swim' || m === 'fly' || m === 'glide';
    let v = 0;
    if (moving) {
      v = vel(e, m);
      const tx = e.tx - e.x, tz = e.tz - e.z, td = Math.hypot(tx, tz);
      if (td < 1.5 && !(e.air && sp.move !== 'air' && !e.landing)) { idleNow(e, 1.5 + Math.random() * 3); v = 0; }
      else {
        let want = Math.atan2(tx, tz);
        if (e.air && e.arc) want += Math.sin(performance.now() / 4000 + e.born) * e.arc * 2;
        e.yaw = turn(e.yaw, want, dt * (e.air ? 0.8 : 2.2));
        const nx = e.x + Math.sin(e.yaw) * v * dt, nz = e.z + Math.cos(e.yaw) * v * dt, h2 = heightAt(nx, nz);
        if (!e.air && sp.move !== 'water' && (h2 < sea + 0.35 || Math.abs(h2 - e.y) > v * dt * 1.6 + 0.4)) { idleNow(e, 1.5); v = 0; e.tx = e.x; e.tz = e.z; } // agua o pared: se detiene
        else if (sp.move === 'water' && h2 > sea - 3) { idleNow(e, 2); v = 0; }
        else { e.x = nx; e.z = nz; }
      }
    } else if (m === 'alert' || ((m === 'sing' || m === 'roar') && sf === 'wary')) e.yaw = turn(e.yaw, toward, dt * 2);
    e.speed += (v - e.speed) * Math.min(1, dt * 3);

    const now = performance.now();
    if (sp.move === 'water') e.y = sea - 2.4 + Math.sin(now / 1500 + e.born) * 0.15;
    else {
      const g = heightAt(e.x, e.z);
      if (e.air) { const want = g + (e.landing ? 0 : e.alt) + (e.landing ? 0 : Math.sin(now / 1800 + e.born) * 1.5); e.y += (want - e.y) * Math.min(1, dt * (e.landing ? 1.4 : 0.8)); }
      else e.y += (g - e.y) * Math.min(1, dt * 8);
    }
  }

  // ── Bucle ──────────────────────────────────────────────────────────────────────────────────
  // P = { x, z }; night: bool. Las lejanas se actualizan menos veces y las muy lejanas no se dibujan.
  function update(dt, P, { night = false } = {}) {
    if (st.disposed) return;
    if (!st.enabled) { if (ents.length) clear(); return; }
    st.frameN++;
    st.nextSpawn -= dt;
    if (st.nextSpawn <= 0 && !st.spawning) {
      st.nextSpawn = 2.5 + Math.random() * 2;
      if (ents.filter((e) => !e.pinned).length < st.cap) {
        const pk = pickSpecies(P);
        if (pk) {
          const k = pk.sp.id;
          if (zoo.tpl[`${k}:0`] || zoo.tpl[`${k}:1`]) spawn(pk.sp, pk.x, pk.z);
          else { zoo.tplOf(k, st.lowDetail ? 1 : 0).catch(() => {}); st.nextSpawn = 1.5; } // se construye en segundo plano y aparece cuando está lista
        }
      }
    }
    for (let i = ents.length - 1; i >= 0; i--) {
      const e = ents[i], d = Math.hypot(e.x - P.x, e.z - P.z);
      if (d > 420 || (d > 260 && !e.pinned)) { despawn(e); ents.splice(i, 1); continue; }
      const near = d < 75, far = d > 160;
      e.accDt += dt;
      if (far) {
        e.inst.group.visible = false;
        if ((st.frameN + i) % 12 === 0) { stepEnt(e, e.accDt, P, night); e.accDt = 0; place(e); }
        continue;
      }
      e.inst.group.visible = true;
      const every = near ? 1 : d < 120 ? 2 : 4;
      if ((st.frameN + i) % every !== 0) continue;
      const sdt = e.accDt;
      e.accDt = 0;
      stepEnt(e, sdt, P, night);
      place(e);
      AN.update(e.c, sdt, e.speed);
      if (e._sh !== near) { e._sh = near; e.inst.group.traverse((o) => { if (o.isMesh) o.castShadow = near; }); }
    }
  }

  // Invoca una criatura delante de la cámara (también los dragones). Devuelve el mensaje de lo ocurrido.
  async function summon(id, P, camera) {
    const sp = zoo.SP[id];
    if (!sp) return { ok: false, msg: 'Esa criatura no existe.' };
    st.enabled = true;
    const dd = 12 + (sp.size || 1) * 3.5;
    camera.getWorldDirection(dir);
    dir.y = 0;
    dir.normalize();
    let x = P.x + dir.x * dd, z = P.z + dir.z * dd;
    if (sp.move === 'water') {
      let found = false;
      for (let k = 0; k < 40 && !found; k++) { const a = Math.random() * TAU, r = 30 + k * 4; x = P.x + Math.cos(a) * r; z = P.z + Math.sin(a) * r; found = heightAt(x, z) < sea - 4; }
      if (!found) return { ok: false, msg: 'No hay agua profunda cerca para esta criatura.' };
    } else if (heightAt(x, z) < sea + 1) {
      for (let k = 0; k < 24; k++) { const a = Math.random() * TAU; x = P.x + Math.cos(a) * dd; z = P.z + Math.sin(a) * dd; if (heightAt(x, z) > sea + 1) break; }
    }
    while (st.spawning) await new Promise((r) => setTimeout(r, 50));
    const e = await spawn(sp, x, z, { pinned: true });
    if (!e) return { ok: false, msg: 'No se pudo invocar la criatura.' };
    e.yaw = Math.atan2(P.x - x, P.z - z);
    seen.add(id);
    voice(e, P, true);
    return { ok: true, msg: `Invocado: ${sp.name}` };
  }

  function dispose() {
    st.disposed = true;
    clear();
    scene.remove(group);
  }
  return {
    group, ents, update, summon, clear, dispose,
    set cap(n) { st.cap = Math.max(0, n | 0); },
    set enabled(v) { st.enabled = !!v; },
    get enabled() { return st.enabled; },
    set sound(v) { st.sound = !!v; },
    set lowDetail(v) { st.lowDetail = !!v; },
    get count() { return ents.length; },
    onNotice,
  };
}
