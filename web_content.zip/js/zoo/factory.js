// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 4700-5025 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_FACTORY(THREE, deps) {
'use strict';
deps = deps || {};
const V3 = THREE.Vector3;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const yield0 = () => new Promise(r => setTimeout(r, 0));
// Presupuesto de tiempo (ms) por trozo de trabajo al construir una criatura; dentro del mundo se baja para no cortar los fotogramas.
const BUDGET = { ms: 10 };

// ---------- ruido ----------
function H3(x, y, z) { let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(z, 1274126177)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967295; }
function vnoise(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z), fx = x - xi, fy = y - yi, fz = z - zi;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy), w = fz * fz * (3 - 2 * fz);
  const a = lerp(lerp(H3(xi, yi, zi), H3(xi + 1, yi, zi), u), lerp(H3(xi, yi + 1, zi), H3(xi + 1, yi + 1, zi), u), v);
  const b = lerp(lerp(H3(xi, yi, zi + 1), H3(xi + 1, yi, zi + 1), u), lerp(H3(xi, yi + 1, zi + 1), H3(xi + 1, yi + 1, zi + 1), u), v);
  return lerp(a, b, w);
}
function fbm(x, y, z, o = 4) { let t = 0, a = 0.5, f = 1; for (let i = 0; i < o; i++) { t += vnoise(x * f, y * f, z * f) * a; a *= 0.5; f *= 2.03; } return t; }

// ---------- primitivas SDF ----------
function mkPrim(o) {
  const p = Object.assign({ k: 0.05, op: 'add', sc: null }, o);
  if (p.t === 'rc') {
    const a = p.a, b = p.b; p.ba = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
    p.l2 = p.ba[0] ** 2 + p.ba[1] ** 2 + p.ba[2] ** 2 || 1e-8; p.rr = p.r1 - p.r2; p.a2 = p.l2 - p.rr * p.rr; p.il2 = 1 / p.l2;
    const R = Math.max(p.r1, p.r2); p.lo = [Math.min(a[0], b[0]) - R, Math.min(a[1], b[1]) - R, Math.min(a[2], b[2]) - R]; p.hi = [Math.max(a[0], b[0]) + R, Math.max(a[1], b[1]) + R, Math.max(a[2], b[2]) + R];
    p.cen = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2];
  } else { // elipsoide
    const c = p.c, r = p.r; p.lo = [c[0] - r[0], c[1] - r[1], c[2] - r[2]]; p.hi = [c[0] + r[0], c[1] + r[1], c[2] + r[2]]; p.cen = c;
  }
  if (p.sc) { // escala no uniforme alrededor del centro
    const s = p.sc, c = p.cen; p.ms = Math.min(s[0], s[1], s[2]);
    p.lo = [c[0] + (p.lo[0] - c[0]) * s[0], c[1] + (p.lo[1] - c[1]) * s[1], c[2] + (p.lo[2] - c[2]) * s[2]];
    p.hi = [c[0] + (p.hi[0] - c[0]) * s[0], c[1] + (p.hi[1] - c[1]) * s[1], c[2] + (p.hi[2] - c[2]) * s[2]];
    for (let i = 0; i < 3; i++) if (p.lo[i] > p.hi[i]) { const t = p.lo[i]; p.lo[i] = p.hi[i]; p.hi[i] = t; }
  }
  return p;
}
function primDist(p, x, y, z) {
  if (p.sc) { const c = p.cen, s = p.sc; x = c[0] + (x - c[0]) / s[0]; y = c[1] + (y - c[1]) / s[1]; z = c[2] + (z - c[2]) / s[2]; }
  let d;
  if (p.t === 'rc') {
    const a = p.a, ba = p.ba; const pax = x - a[0], pay = y - a[1], paz = z - a[2];
    const yy = pax * ba[0] + pay * ba[1] + paz * ba[2]; const zz = yy - p.l2;
    const vx = pax * p.l2 - ba[0] * yy, vy = pay * p.l2 - ba[1] * yy, vz = paz * p.l2 - ba[2] * yy;
    const x2 = vx * vx + vy * vy + vz * vz, y2 = yy * yy * p.l2, z2 = zz * zz * p.l2; const k = (p.rr < 0 ? -1 : 1) * p.rr * p.rr * x2;
    if ((zz < 0 ? -1 : 1) * p.a2 * z2 > k) d = Math.sqrt(x2 + z2) * p.il2 - p.r2;
    else if ((yy < 0 ? -1 : 1) * p.a2 * y2 < k) d = Math.sqrt(x2 + y2) * p.il2 - p.r1;
    else d = (Math.sqrt(x2 * p.a2 * p.il2) + yy * p.rr) * p.il2 - p.r1;
  } else {
    const c = p.c, r = p.r; const qx = (x - c[0]) / r[0], qy = (y - c[1]) / r[1], qz = (z - c[2]) / r[2];
    const k0 = Math.sqrt(qx * qx + qy * qy + qz * qz); const k1 = Math.sqrt((qx / r[0]) ** 2 + (qy / r[1]) ** 2 + (qz / r[2]) ** 2);
    d = k1 < 1e-9 ? -Math.min(r[0], r[1], r[2]) : k0 * (k0 - 1) / k1;
  }
  return p.sc ? d * p.ms : d;
}
function smin(a, b, k) { if (k <= 0) return Math.min(a, b); const h = Math.max(k - Math.abs(a - b), 0) / k; return Math.min(a, b) - h * h * k * 0.25; }
function smax(a, b, k) { if (k <= 0) return Math.max(a, b); const h = Math.max(k - Math.abs(a - b), 0) / k; return Math.max(a, b) + h * h * k * 0.25; }

function makeSDF(prims, acc) {
  const add = prims.filter(p => p.op !== 'sub'), sub = prims.filter(p => p.op === 'sub');
  const evalList = function(lst, x, y, z) {
    let d = 1e9;
    for (let i = 0; i < lst.length; i++) {
      const p = lst[i], lo = p.lo, hi = p.hi;
      const dx = Math.max(lo[0] - x, 0, x - hi[0]), dy = Math.max(lo[1] - y, 0, y - hi[1]), dz = Math.max(lo[2] - z, 0, z - hi[2]);
      if (d < 1e8 && Math.sqrt(dx * dx + dy * dy + dz * dz) >= d + p.k) continue;
      d = smin(d, primDist(p, x, y, z), p.k);
    }
    return d;
  };
  if (!acc) return function(x, y, z) {
    let d = evalList(add, x, y, z);
    for (let i = 0; i < sub.length; i++) { const p = sub[i]; d = smax(d, -primDist(p, x, y, z), p.k); }
    return d;
  };
  // aceleración: cubetas espaciales con la lista de primitivas cercanas (para cuerpos largos y delgados, la mayor parte del volumen está vacío)
  const C = acc.bucket, M = acc.margin, cache = new Map(), inv = 1 / C;
  const listFor = (bx, by, bz) => {
    const key = ((bx + 2048) * 4096 + (by + 2048)) * 4096 + (bz + 2048); let l = cache.get(key); if (l) return l;
    const x0 = bx * C, y0 = by * C, z0 = bz * C, x1 = x0 + C, y1 = y0 + C, z1 = z0 + C; l = { add: [], sub: [] };
    for (let i = 0; i < add.length; i++) { const p = add[i], e = p.k + M; if (p.lo[0] - e <= x1 && p.hi[0] + e >= x0 && p.lo[1] - e <= y1 && p.hi[1] + e >= y0 && p.lo[2] - e <= z1 && p.hi[2] + e >= z0) l.add.push(p); }
    if (l.add.length) for (let i = 0; i < sub.length; i++) { const p = sub[i], e = p.k + M; if (p.lo[0] - e <= x1 && p.hi[0] + e >= x0 && p.lo[1] - e <= y1 && p.hi[1] + e >= y0 && p.lo[2] - e <= z1 && p.hi[2] + e >= z0) l.sub.push(p); }
    cache.set(key, l); return l;
  };
  return function(x, y, z) {
    const l = listFor(Math.floor(x * inv), Math.floor(y * inv), Math.floor(z * inv));
    if (!l.add.length) return 1e3;
    let d = evalList(l.add, x, y, z);
    for (let i = 0; i < l.sub.length; i++) { const p = l.sub[i]; d = smax(d, -primDist(p, x, y, z), p.k); }
    return d;
  };
}

// ---------- surface nets ----------
const EDG = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]];
async function surfaceNets(sdf, lo, hi, cell, timeBudget = BUDGET.ms) {
  const nx = Math.ceil((hi[0] - lo[0]) / cell) + 1, ny = Math.ceil((hi[1] - lo[1]) / cell) + 1, nz = Math.ceil((hi[2] - lo[2]) / cell) + 1;
  const F = new Float32Array(nx * ny * nz); let t0 = performance.now();
  for (let z = 0; z < nz; z++) {
    const wz = lo[2] + z * cell;
    for (let y = 0; y < ny; y++) { const wy = lo[1] + y * cell; let i = (z * ny + y) * nx; for (let x = 0; x < nx; x++, i++) F[i] = sdf(lo[0] + x * cell, wy, wz); }
    if (performance.now() - t0 > timeBudget) { await yield0(); t0 = performance.now(); }
  }
  const cx = nx - 1, cy = ny - 1, cz = nz - 1; const map = new Int32Array(cx * cy * cz).fill(-1);
  const pos = [], nor = []; const cv = new Float32Array(8); const IDX = (x, y, z) => (z * ny + y) * nx + x;
  for (let z = 0; z < cz; z++) {
    for (let y = 0; y < cy; y++) for (let x = 0; x < cx; x++) {
      let mask = 0;
      for (let c = 0; c < 8; c++) { const v = F[IDX(x + (c & 1), y + ((c >> 1) & 1), z + (c >> 2))]; cv[c] = v; if (v < 0) mask |= 1 << c; }
      if (mask === 0 || mask === 255) continue;
      let sx = 0, sy = 0, sz = 0, n = 0;
      for (let e = 0; e < 12; e++) {
        const a = EDG[e][0], b = EDG[e][1], va = cv[a], vb = cv[b]; if ((va < 0) === (vb < 0)) continue;
        const t = va / (va - vb); sx += (a & 1) + ((b & 1) - (a & 1)) * t; sy += ((a >> 1) & 1) + (((b >> 1) & 1) - ((a >> 1) & 1)) * t; sz += (a >> 2) + ((b >> 2) - (a >> 2)) * t; n++;
      }
      map[(z * cy + y) * cx + x] = pos.length / 3;
      pos.push(lo[0] + (x + sx / n) * cell, lo[1] + (y + sy / n) * cell, lo[2] + (z + sz / n) * cell);
      const gx = (cv[1] + cv[3] + cv[5] + cv[7]) - (cv[0] + cv[2] + cv[4] + cv[6]), gy = (cv[2] + cv[3] + cv[6] + cv[7]) - (cv[0] + cv[1] + cv[4] + cv[5]), gz = (cv[4] + cv[5] + cv[6] + cv[7]) - (cv[0] + cv[1] + cv[2] + cv[3]);
      const l = Math.hypot(gx, gy, gz) || 1; nor.push(gx / l, gy / l, gz / l);
    }
    if (performance.now() - t0 > timeBudget) { await yield0(); t0 = performance.now(); }
  }
  const idx = []; const M = (x, y, z) => map[(z * cy + y) * cx + x];
  for (let z = 1; z < cz; z++) for (let y = 1; y < cy; y++) for (let x = 0; x < cx; x++) { // eje X
    const a = F[IDX(x, y, z)], b = F[IDX(x + 1, y, z)]; if ((a < 0) === (b < 0)) continue;
    const v0 = M(x, y - 1, z - 1), v1 = M(x, y, z - 1), v2 = M(x, y, z), v3 = M(x, y - 1, z); if (v0 < 0 || v1 < 0 || v2 < 0 || v3 < 0) continue;
    if (a < 0) idx.push(v0, v1, v2, v0, v2, v3); else idx.push(v0, v2, v1, v0, v3, v2);
  }
  for (let z = 1; z < cz; z++) for (let y = 0; y < cy; y++) for (let x = 1; x < cx; x++) { // eje Y
    const a = F[IDX(x, y, z)], b = F[IDX(x, y + 1, z)]; if ((a < 0) === (b < 0)) continue;
    const v0 = M(x - 1, y, z - 1), v1 = M(x, y, z - 1), v2 = M(x, y, z), v3 = M(x - 1, y, z); if (v0 < 0 || v1 < 0 || v2 < 0 || v3 < 0) continue;
    if (a < 0) idx.push(v0, v2, v1, v0, v3, v2); else idx.push(v0, v1, v2, v0, v2, v3);
  }
  for (let z = 0; z < cz; z++) for (let y = 1; y < cy; y++) for (let x = 1; x < cx; x++) { // eje Z
    const a = F[IDX(x, y, z)], b = F[IDX(x, y, z + 1)]; if ((a < 0) === (b < 0)) continue;
    const v0 = M(x - 1, y - 1, z), v1 = M(x, y - 1, z), v2 = M(x, y, z), v3 = M(x - 1, y, z); if (v0 < 0 || v1 < 0 || v2 < 0 || v3 < 0) continue;
    if (a < 0) idx.push(v0, v1, v2, v0, v2, v3); else idx.push(v0, v2, v1, v0, v3, v2);
  }
  return { pos: new Float32Array(pos), nor: new Float32Array(nor), idx: pos.length / 3 > 65000 ? new Uint32Array(idx) : new Uint16Array(idx) };
}

// ---------- DSL de rig ----------
class Rig {
  constructor(id) { this.id = id; this.bones = []; this.prims = []; this.rigid = []; this.decor = []; this.roles = { legs: {}, wings: {}, tentacles: [], tails: [], ears: [], neck: [], spine: [], fingers: {}, arms: {} }; this.byName = {}; this.meta = {}; this.ks = 1; }
  bone(name, parent, pos) { const b = { name, parent, pos: pos.slice() }; this.bones.push(b); this.byName[name] = b; return b; }
  cone(bone, a, b, r1, r2, k, o) { this.prims.push(mkPrim(Object.assign({ t: 'rc', bone, a, b, r1, r2, k: (k === undefined ? 0.05 : k) * this.ks }, o))); return this; }
  ell(bone, c, r, k, o) { this.prims.push(mkPrim(Object.assign({ t: 'el', bone, c, r, k: (k === undefined ? 0.05 : k) * this.ks }, o))); return this; }
  sub(bone, kind, args, k) { const o = kind === 'rc' ? { t: 'rc', a: args[0], b: args[1], r1: args[2], r2: args[3] } : { t: 'el', c: args[0], r: args[1] }; this.prims.push(mkPrim(Object.assign({ bone, op: 'sub', k: (k === undefined ? 0.03 : k) * this.ks }, o))); return this; }
  // chain de huesos/segmentos con radios: pts=[[x,y,z],...], radii=[...], nombres
  chain(prefix, parent, pts, radii, k, o) {
    const names = []; let par = parent;
    for (let i = 0; i < pts.length; i++) { const n = prefix + (i + 1); this.bone(n, par, pts[i]); names.push(n); par = n; }
    for (let i = 0; i < pts.length - 1; i++) this.cone(names[i], pts[i], pts[i + 1], radii[i], radii[i + 1], k, o);
    return names;
  }
}
const mir = p => [-p[0], p[1], p[2]];
const addv = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const scl = (a, s) => [a[0] * s, a[1] * s, a[2] * s];

// ---------- geometría suelta (cuernos, colmillos, ojos...) ----------
function sweep(points, radii, sides, closedTip) {
  sides = sides || 8; const n = points.length; const pos = [], idx = [];
  const pts = points.map(p => new V3(p[0], p[1], p[2])); let prevN = new V3(0, 1, 0);
  for (let i = 0; i < n; i++) {
    const t = (i === 0) ? pts[1].clone().sub(pts[0]) : (i === n - 1) ? pts[i].clone().sub(pts[i - 1]) : pts[i + 1].clone().sub(pts[i - 1]);
    t.normalize(); let u = new V3().crossVectors(t, prevN); if (u.lengthSq() < 1e-6) u = new V3().crossVectors(t, new V3(1, 0, 0)); u.normalize(); const w = new V3().crossVectors(t, u).normalize(); prevN = w.clone();
    const r = radii[i];
    for (let s = 0; s < sides; s++) { const a = s / sides * Math.PI * 2, c = Math.cos(a), si = Math.sin(a); pos.push(pts[i].x + (u.x * c + w.x * si) * r, pts[i].y + (u.y * c + w.y * si) * r, pts[i].z + (u.z * c + w.z * si) * r); }
  }
  for (let i = 0; i < n - 1; i++) for (let s = 0; s < sides; s++) { const a = i * sides + s, b = i * sides + (s + 1) % sides, c = (i + 1) * sides + s, d = (i + 1) * sides + (s + 1) % sides; idx.push(a, c, b, b, c, d); }
  const tip = pos.length / 3; const l = pts[n - 1]; pos.push(l.x, l.y, l.z); for (let s = 0; s < sides; s++) idx.push((n - 1) * sides + s, tip, (n - 1) * sides + (s + 1) % sides);
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
function sweepP(points, radii, sides) { // como sweep, pero con marco de transporte paralelo (sin el giro alternante)
  sides = sides || 8; const n = points.length; const pos = [], idx = [];
  const pts = points.map(p => new V3(p[0], p[1], p[2])); let nPrev = null;
  for (let i = 0; i < n; i++) {
    const t = (i === 0) ? pts[1].clone().sub(pts[0]) : (i === n - 1) ? pts[i].clone().sub(pts[i - 1]) : pts[i + 1].clone().sub(pts[i - 1]); t.normalize();
    let u; if (!nPrev) u = new V3().crossVectors(t, Math.abs(t.y) < 0.9 ? new V3(0, 1, 0) : new V3(1, 0, 0)); else { u = nPrev.clone().sub(t.clone().multiplyScalar(nPrev.dot(t))); if (u.lengthSq() < 1e-8) u = new V3().crossVectors(t, new V3(1, 0, 0)); }
    u.normalize(); const w = new V3().crossVectors(t, u).normalize(); nPrev = u.clone(); const r = radii[i];
    for (let s = 0; s < sides; s++) { const a = s / sides * Math.PI * 2, cc = Math.cos(a), si = Math.sin(a); pos.push(pts[i].x + (u.x * cc + w.x * si) * r, pts[i].y + (u.y * cc + w.y * si) * r, pts[i].z + (u.z * cc + w.z * si) * r); }
  }
  for (let i = 0; i < n - 1; i++) for (let s = 0; s < sides; s++) { const a = i * sides + s, b = i * sides + (s + 1) % sides, cc = (i + 1) * sides + s, d = (i + 1) * sides + (s + 1) % sides; idx.push(a, cc, b, b, cc, d); }
  const tip = pos.length / 3; const l = pts[n - 1]; pos.push(l.x, l.y, l.z); for (let s = 0; s < sides; s++) idx.push((n - 1) * sides + s, tip, (n - 1) * sides + (s + 1) % sides);
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
function bez(p0, p1, p2, p3, n) { const out = []; for (let i = 0; i <= n; i++) { const t = i / n, u = 1 - t; out.push([0, 1, 2].map(k => u * u * u * p0[k] + 3 * u * u * t * p1[k] + 3 * u * t * t * p2[k] + t * t * t * p3[k])); } return out; }
function taper(n, r0, r1, pw) { const o = []; for (let i = 0; i < n; i++) { const t = i / (n - 1); o.push(lerp(r0, r1, Math.pow(t, pw || 1))); } return o; }

// ---------- texturas de detalle ----------
const detailCache = {};
function detailTexture(kind) {
  if (detailCache[kind]) return detailCache[kind];
  const S = 256, hm = new Float32Array(S * S);
  const wrapN = (x, y, f, o) => { // ruido tileable
    let t = 0, a = 0.5, ff = f; for (let i = 0; i < o; i++) { const px = x * ff, py = y * ff; const xi = Math.floor(px), yi = Math.floor(py), fx = px - xi, fy = py - yi; const m = Math.round(ff); const g = (a_, b_) => H3(((a_ % m) + m) % m, ((b_ % m) + m) % m, i * 17 + 3); const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy); t += lerp(lerp(g(xi, yi), g(xi + 1, yi), u), lerp(g(xi, yi + 1), g(xi + 1, yi + 1), u), v) * a; a *= 0.5; ff *= 2; } return t;
  };
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const u = x / S, v = y / S; let h = 0;
    if (kind === 'fur') { h = wrapN(u, v * 0.12 + 0.0, 64, 3) * 0.7 + wrapN(u, v, 24, 2) * 0.3; h = h * (0.6 + 0.4 * wrapN(u, v, 6, 2)); }
    else if (kind === 'scales') { // celdas hex
      const sx = 14, sy = 14 * 1.1547; let px = u * sx, py = v * sy; const row = Math.floor(py); px += (row & 1) * 0.5; const fx = px - Math.floor(px) - 0.5, fy = py - row - 0.5; const dd = Math.hypot(fx, fy * 0.9); h = 1 - smooth(0.25, 0.62, dd); h = h * 0.85 + wrapN(u, v, 32, 2) * 0.15;
    } else if (kind === 'rock') { h = wrapN(u, v, 6, 5); const c = wrapN(u, v, 10, 3); h = h * 0.7 + Math.abs(c - 0.5) * 0.9; }
    else if (kind === 'bark') { h = wrapN(u * 0.2 + 0, v, 40, 3) * 0.6 + wrapN(u, v, 8, 3) * 0.4; h = h * (0.5 + 0.5 * Math.abs(Math.sin(u * 40 + wrapN(u, v, 10, 2) * 8))); }
    else if (kind === 'feather') { h = wrapN(u, v, 48, 3) * 0.5 + wrapN(u, v, 16, 2) * 0.5; }
    else h = wrapN(u, v, 40, 3);
    hm[y * S + x] = h;
  }
  const cvs = document.createElement('canvas'); cvs.width = cvs.height = S; const cx = cvs.getContext('2d'); const img = cx.createImageData(S, S); const k = kind === 'scales' || kind === 'rock' ? 5 : 3.2;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const l = hm[y * S + (x - 1 + S) % S], r = hm[y * S + (x + 1) % S], u2 = hm[((y - 1 + S) % S) * S + x], d = hm[((y + 1) % S) * S + x];
    const dx = (r - l) * k, dy = (d - u2) * k, ln = Math.sqrt(dx * dx + dy * dy + 1), i = (y * S + x) * 4;
    img.data[i] = (-dx / ln * 0.5 + 0.5) * 255; img.data[i + 1] = (-dy / ln * 0.5 + 0.5) * 255; img.data[i + 2] = (1 / ln * 0.5 + 0.5) * 255; img.data[i + 3] = 255;
  }
  cx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(cvs); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4; detailCache[kind] = t; return t;
}
const featherTexCache = {};
function featherTexture() {
  if (featherTexCache.t) return featherTexCache.t;
  const W = 64, Hh = 256, c = document.createElement('canvas'); c.width = W; c.height = Hh; const g = c.getContext('2d');
  g.clearRect(0, 0, W, Hh);
  for (let y = 0; y < Hh; y++) { const t = y / Hh; const half = (W / 2) * Math.sin(Math.PI * Math.pow(t, 0.7)) * (1 - t * 0.2); for (let x = -half; x <= half; x += 1) { const barb = 0.7 + 0.3 * Math.sin((Math.abs(x) * 0.9 + y * 0.35)); const edge = 1 - Math.pow(Math.abs(x) / Math.max(half, 1), 3); g.fillStyle = 'rgba(255,255,255,' + clamp(barb * 0.5 + edge * 0.5, 0, 1).toFixed(2) + ')'; g.fillRect(W / 2 + x, Hh - y - 1, 1, 1); } }
  g.fillStyle = 'rgba(255,255,255,1)'; g.fillRect(W / 2 - 1, 0, 2, Hh);
  const t = new THREE.CanvasTexture(c); t.anisotropy = 4; featherTexCache.t = t; return t;
}

// ---------- materiales ----------
function patchDetail(mat, kind, scale, strength) {
  const tex = detailTexture(kind);
  mat.onBeforeCompile = shader => {
    shader.uniforms.uDetail = { value: tex }; shader.uniforms.uDS = { value: strength }; shader.uniforms.uDScale = { value: scale };
    shader.vertexShader = 'varying vec3 vOP; varying vec3 vON; varying mat3 vNM;\n' + shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n vOP = position; vON = normal; vNM = normalMatrix;');
    shader.fragmentShader = 'uniform sampler2D uDetail; uniform float uDS; uniform float uDScale; varying vec3 vOP; varying vec3 vON; varying mat3 vNM;\n' + shader.fragmentShader.replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
      { vec3 bw = pow(abs(normalize(vON)), vec3(4.0)); bw /= (bw.x + bw.y + bw.z + 1e-5);
        vec3 tx = texture2D(uDetail, vOP.zy * uDScale).xyz * 2.0 - 1.0; vec3 ty = texture2D(uDetail, vOP.xz * uDScale).xyz * 2.0 - 1.0; vec3 tz = texture2D(uDetail, vOP.xy * uDScale).xyz * 2.0 - 1.0;
        vec3 dO = bw.x * vec3(0.0, tx.y, tx.x) + bw.y * vec3(ty.x, 0.0, ty.y) + bw.z * vec3(tz.x, tz.y, 0.0);
        normal = normalize(normal + (vNM * dO) * uDS); }`);
  };
  mat.customProgramCacheKey = () => 'zoo-detail-' + kind;
  return mat;
}
// ---- escamas imbricadas en coordenadas cilíndricas del cuerpo (filas a lo largo, columnas alrededor) ----
let sclTex = null;
function scaleTexture() {
  if (sclTex) return sclTex;
  const S = 256, NX = 4, NY = 4, hm = new Float32Array(S * S);
  const sm = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const wr = (x, y, f) => { const px = x * f, py = y * f, xi = Math.floor(px), yi = Math.floor(py), fx = px - xi, fy = py - yi, m = Math.round(f); const g = (a, b) => H3(((a % m) + m) % m, ((b % m) + m) % m, 5); const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy); return lerp(lerp(g(xi, yi), g(xi + 1, yi), u), lerp(g(xi, yi + 1), g(xi + 1, yi + 1), u), v); };
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const gy = y / S * NY, row = Math.floor(gy), fy = gy - row; const gx = x / S * NX + (row & 1) * 0.5, col = Math.floor(gx), fx = (gx - col) * 2 - 1;
    const lim = 1 - 0.36 * fx * fx; let h = 0;
    if (fy < lim) { const q = fy / lim; h = Math.pow(q, 1.15); h *= 1 - 0.6 * sm(0.55, 1.0, Math.abs(fx)); h *= 1 + 0.16 * (1 - sm(0.0, 0.3, Math.abs(fx))); h *= 1 - 0.9 * sm(0.9, 1.0, q) * 0.0; const cl = sm(lim - 0.07, lim, fy); h *= 1 - cl * 0.85; }
    h = h * 0.92 + wr(x / S, y / S, 32) * 0.08; hm[y * S + x] = h;
  }
  const data = new Uint8Array(S * S * 4); const K = 4.6;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const l = hm[y * S + (x - 1 + S) % S], r = hm[y * S + (x + 1) % S], dn = hm[((y - 1 + S) % S) * S + x], up = hm[((y + 1) % S) * S + x];
    const nx = -(r - l) * K, ny = -(up - dn) * K, ln = Math.sqrt(nx * nx + ny * ny + 1), i = (y * S + x) * 4;
    data[i] = (nx / ln * 0.5 + 0.5) * 255; data[i + 1] = (ny / ln * 0.5 + 0.5) * 255; data[i + 2] = (1 / ln * 0.5 + 0.5) * 255; data[i + 3] = clamp(hm[y * S + x], 0, 1) * 255;
  }
  const t = new THREE.DataTexture(data, S, S, THREE.RGBAFormat); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.magFilter = THREE.LinearFilter; t.minFilter = THREE.LinearMipmapLinearFilter; t.generateMipmaps = true; t.anisotropy = 4; t.needsUpdate = true; sclTex = t; return t;
}
function patchScaleUV(mat, kind, scale, strength, ss, na) {
  const tex = detailTexture(kind), stex = scaleTexture();
  mat.onBeforeCompile = shader => {
    shader.uniforms.uDetail = { value: tex }; shader.uniforms.uScl = { value: stex }; shader.uniforms.uDS = { value: strength }; shader.uniforms.uDScale = { value: scale }; shader.uniforms.uSS = { value: ss }; shader.uniforms.uNA = { value: na };
    shader.vertexShader = 'attribute vec3 aSU; varying vec3 vOP; varying vec3 vON; varying mat3 vNM; varying vec3 vSU; varying vec2 vCS;\n' + shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n vOP = position; vON = normal; vNM = normalMatrix; vSU = aSU; vCS = vec2(cos(aSU.y), sin(aSU.y));');
    shader.fragmentShader = 'uniform sampler2D uDetail; uniform sampler2D uScl; uniform float uDS; uniform float uDScale; uniform float uSS; uniform float uNA; varying vec3 vOP; varying vec3 vON; varying mat3 vNM; varying vec3 vSU; varying vec2 vCS;\n' + shader.fragmentShader.replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
      { vec3 bw = pow(abs(normalize(vON)), vec3(4.0)); bw /= (bw.x + bw.y + bw.z + 1e-5);
        vec3 tx = texture2D(uDetail, vOP.zy * uDScale).xyz * 2.0 - 1.0; vec3 ty = texture2D(uDetail, vOP.xz * uDScale).xyz * 2.0 - 1.0; vec3 tz = texture2D(uDetail, vOP.xy * uDScale).xyz * 2.0 - 1.0;
        vec3 dO = bw.x * vec3(0.0, tx.y, tx.x) + bw.y * vec3(ty.x, 0.0, ty.y) + bw.z * vec3(tz.x, tz.y, 0.0);
        vec3 nTri = normalize(normal + (vNM * dO) * uDS);
        float fl = clamp(vSU.z, 0.0, 1.0);
        float ang = atan(vCS.y, vCS.x); float ua = ang * 0.15915494 * uNA; float ub = fract(ang * 0.15915494 + 0.5) * uNA; float al = vSU.x;
        float dxa = dFdx(ua), dxb = dFdx(ub), dya = dFdy(ua), dyb = dFdy(ub);
        float ax = abs(dxa) < abs(dxb) ? dxa : dxb; float ay = abs(dya) < abs(dyb) ? dya : dyb; float lx = dFdx(al), ly = dFdy(al);
        vec4 sT = textureGrad(uScl, vec2(ua, al) * 0.25, vec2(ax, lx) * 0.25, vec2(ay, ly) * 0.25);
        vec3 mN = sT.xyz * 2.0 - 1.0;
        vec3 q0 = dFdx(-vViewPosition), q1 = dFdy(-vViewPosition); vec3 N0 = normalize(normal); vec3 q1p = cross(q1, N0), q0p = cross(N0, q0);
        vec3 Tt = q1p * ax + q0p * ay; vec3 Bt = q1p * lx + q0p * ly; float det = max(dot(Tt, Tt), dot(Bt, Bt)); float scl = det == 0.0 ? 0.0 : inversesqrt(det);
        vec3 nS = normalize(mat3(Tt * scl, Bt * scl, N0) * vec3(mN.xy * uSS, mN.z));
        float row = floor(al); float colI = mod(floor(ua + 0.5 * mod(row, 2.0)), uNA); float rn = fract(sin(dot(vec2(colI, row), vec2(12.9898, 78.233))) * 43758.5453);
        float shade = mix(0.5, 1.12, smoothstep(0.0, 0.85, sT.a)); float tint = 0.84 + 0.32 * rn;
        diffuseColor.rgb *= mix(1.0, shade * tint, fl);
        normal = normalize(mix(nTri, nS, fl)); }`);
  };
  mat.customProgramCacheKey = () => 'zoo-scale-uv';
  return mat;
}
function bodyMaterial(style) {
  const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: style.rough === undefined ? 0.88 : style.rough, metalness: style.metal || 0, side: THREE.FrontSide });
  if (style.emissive) { m.emissive = new THREE.Color(style.emissive); m.emissiveIntensity = style.emissiveI || 0.3; }
  if (style.scaleUV) return patchScaleUV(m, style.detail || 'scales', style.dscale || 3.0, style.dstr === undefined ? 0.9 : style.dstr, style.sstr || 1.3, style.na || 12);
  return patchDetail(m, style.detail || 'fur', style.dscale || 3.0, style.dstr === undefined ? 0.9 : style.dstr);
}

// ---------- skinning ----------
function segDist(px, py, pz, a, b) { const bx = b[0] - a[0], by = b[1] - a[1], bz = b[2] - a[2]; const l2 = bx * bx + by * by + bz * bz; let t = l2 > 1e-9 ? ((px - a[0]) * bx + (py - a[1]) * by + (pz - a[2]) * bz) / l2 : 0; t = clamp(t, 0, 1); const dx = px - (a[0] + bx * t), dy = py - (a[1] + by * t), dz = pz - (a[2] + bz * t); return Math.sqrt(dx * dx + dy * dy + dz * dz); }
function boneTable(rig) {
  const kids = {}; rig.bones.forEach(b => { (kids[b.parent || ''] = kids[b.parent || ''] || []).push(b); });
  const idx = {}; rig.bones.forEach((b, i) => idx[b.name] = i);
  const seg = rig.bones.map(b => { const ch = (kids[b.name] || []).find(c => !c.noSeg); let tail; if (ch) tail = ch.pos; else { const p = b.parent && rig.byName[b.parent]; tail = p ? [b.pos[0] + (b.pos[0] - p.pos[0]) * 0.4, b.pos[1] + (b.pos[1] - p.pos[1]) * 0.4, b.pos[2] + (b.pos[2] - p.pos[2]) * 0.4] : [b.pos[0], b.pos[1] + 0.05, b.pos[2]]; } return [b.pos, tail]; });
  const cand = rig.bones.map(b => { const s = [b.name]; if (b.parent) s.push(b.parent); (kids[b.name] || []).forEach(c => { if (!c.noSkin) s.push(c.name); }); return s.map(n => idx[n]); });
  return { idx, seg, cand };
}
function skinVerts(rig, bt, getPos, count, nearestPrim) {
  const si = new Uint16Array(count * 4), sw = new Float32Array(count * 4); const ws = [], ids = [];
  for (let v = 0; v < count; v++) {
    const x = getPos(v, 0), y = getPos(v, 1), z = getPos(v, 2); const pi = nearestPrim ? nearestPrim(x, y, z) : 0; const prim = rig.prims[pi]; const bi = bt.idx[prim.bone];
    const cs = bt.cand[bi]; ws.length = 0; ids.length = 0; let tot = 0;
    for (let c = 0; c < cs.length; c++) { const j = cs[c]; const s = bt.seg[j]; const d = segDist(x, y, z, s[0], s[1]); let w = 1 / Math.pow(d + 0.035, 4); if (j !== bi) w *= 0.55; ws.push(w); ids.push(j); }
    const ord = ws.map((w, i) => i).sort((a, b) => ws[b] - ws[a]).slice(0, 4);
    for (const o of ord) tot += ws[o];
    for (let k = 0; k < ord.length; k++) { si[v * 4 + k] = ids[ord[k]]; sw[v * 4 + k] = ws[ord[k]] / tot; }
  }
  return { si, sw };
}

return { THREE, V3, clamp, lerp, smooth, mix3, fbm, vnoise, H3, mkPrim, primDist, makeSDF, surfaceNets, Rig, mir, addv, scl, sweep, sweepP, bez, taper, detailTexture, featherTexture, bodyMaterial, patchDetail, boneTable, skinVerts, segDist, BUDGET, yield0, deps };
}

