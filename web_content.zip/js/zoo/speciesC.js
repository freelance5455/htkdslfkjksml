// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 5857-6088 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_SPECIES_C(Z, SP, A) {
const { THREE, clamp, lerp, smooth, mix3, fbm, Rig, sweep, bez, taper } = Z;
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const noiseCol = (c, f, a) => 1 + (fbm(c.x * f, c.y * f, c.z * f, 3) - 0.5) * a;
const quadruped = A.quadruped;
const rnd = (() => { let s = 12345; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; })();

// mechón/cabellera: ribbons que siguen una línea base
function strand(p0, d, len, droop, n, side) {
  const out = []; let p = p0.slice(); const dl = Math.hypot(d[0], d[1], d[2]) || 1; let dx = d[0] / dl, dy = d[1] / dl, dz = d[2] / dl;
  for (let i = 0; i <= n; i++) { out.push(p.slice()); p = [p[0] + dx * len / n, p[1] + dy * len / n, p[2] + dz * len / n]; dy -= droop / n; const l = Math.hypot(dx, dy, dz); dx /= l; dy /= l; dz /= l; }
  return out;
}
function mane(r, basePts, o) {
  basePts.forEach((b, i) => {
    const t = i / Math.max(1, basePts.length - 1); const n = o.strands || 2;
    for (let k = 0; k < n; k++) { const j = (rnd() - 0.5) * (o.spread || 0.04); const path = strand(add(b, [j, (o.lift || 0.02), 0]), [(rnd() - 0.5) * 0.4 + (o.side || 0), o.up === undefined ? 0.5 : o.up, -(o.back || 0.7) + (rnd() - 0.5) * 0.3], (o.len || 0.4) * (0.75 + rnd() * 0.5), o.droop || 0.9, 7);
      r.decor.push({ type: 'ribbon', kind: o.kind || 'sheet', path, w0: o.w0 || 0.03, w1: o.w1 || 0.012, up: [1, 0, 0], cf: o.cf ? (tt => o.cf(tt, t)) : null, c0: o.c0 || [0.9, 0.9, 0.9], c1: o.c1 || [0.6, 0.6, 0.7], af: o.kind === 'fire' ? (tt => 0.9 * (1 - Math.pow(tt, 1.6))) : null, pw: 1.0 }); }
  });
}
function hornSweep(r, bone, pts, r0, r1, sides) { r.rigid.push({ bone, mat: 'horn', geo: sweep(pts, taper(pts.length, r0, r1, 1.1), sides || 8) }); }
// alas de plumas para cuadrúpedos
function featherWings(r, o) {
  const m = r.meta, rw = m.rw, yc = m.yc, L = m.L, sp = o.span / 2; r.roles.wings = {};
  const sh0 = [rw * 0.55, yc + m.rv * 0.8, L * 0.18]; const wp = [sh0, [sp * 0.22, sh0[1] + 0.12 * o.s, sh0[2] - sp * 0.04], [sp * 0.5, sh0[1] + 0.14 * o.s, sh0[2] - sp * 0.08], [sp * 0.68, sh0[1] + 0.1 * o.s, sh0[2] - sp * 0.05]];
  for (const sx of [-1, 1]) {
    const side = sx > 0 ? 'L' : 'R'; const pp = wp.map(p => [p[0] * sx, p[1], p[2]]); const wn = r.chain('wing' + side + '_', 'spine2', pp, [o.wr * 1.3, o.wr, o.wr * 0.7, o.wr * 0.4], 0.04); r.roles.wings[side] = wn;
    const np = o.nPrim || 9, ns = o.nSec || 10, fc = o.cols;
    for (let i = 0; i < np; i++) { const t = i / (np - 1); const base = [lerp(pp[2][0], pp[3][0], t), lerp(pp[2][1], pp[3][1], t) - 0.003 * i, lerp(pp[2][2], pp[3][2], t)]; const ang = lerp(-0.25, 0.65, t); const dir = [sx * Math.cos(ang) * 0.55, -0.02, -Math.sin(Math.abs(ang) + 0.35) * 0.8]; const dl = Math.hypot(...dir); r.decor.push({ type: 'feather', kind: 'feather', base, dir: dir.map(x => x / dl), len: sp * (0.3 + 0.16 * (1 - Math.abs(t - 0.25))), w: sp * 0.07, bend: -0.05, cf: tt => mix3(fc[0], fc[1], Math.min(1, tt * 1.1)) }); }
    for (let i = 0; i < ns; i++) { const t = i / (ns - 1); const base = [lerp(pp[1][0], pp[2][0], t), pp[1][1] - 0.004, lerp(pp[1][2], pp[2][2], t) - 0.01]; r.decor.push({ type: 'feather', kind: 'feather', base, dir: [sx * 0.08, -0.04, -1], len: sp * (0.34 + 0.06 * t), w: sp * 0.075, bend: -0.04, cf: tt => mix3(fc[2], fc[3], tt) }); }
    for (let i = 0; i < 6; i++) { const t = i / 5; r.decor.push({ type: 'feather', kind: 'feather', base: [lerp(pp[0][0], pp[2][0], t), pp[0][1] + 0.012, lerp(pp[0][2], pp[2][2], t)], dir: [sx * 0.1, 0, -1], len: sp * 0.2, w: sp * 0.065, bend: 0, cf: tt => mix3(fc[4], fc[5], tt) }); }
  }
}
// alas de membrana (dragón)
function batWings(r, o) {
  const m = r.meta, rw = m.rw, yc = m.yc, L = m.L, sp = o.span / 2; r.roles.wings = {}; r.roles.fingers = {};
  const sh0 = [rw * 0.5, yc + m.rv * 0.85, L * 0.2]; const E = [sp * 0.2, sh0[1] + sp * 0.12, sh0[2] - sp * 0.02], W = [sp * 0.4, sh0[1] + sp * 0.2, sh0[2] - sp * 0.08];
  const fingers = [[0.95, 0.3, -0.25], [0.8, 0.22, -0.62], [0.55, 0.12, -0.95], [0.25, 0.04, -1.1]];
  for (const sx of [-1, 1]) {
    const side = sx > 0 ? 'L' : 'R'; const S = sh0, X = (p) => [p[0] * sx, p[1], p[2]];
    const wn = r.chain('wing' + side + '_', 'spine2', [X(S), X(E), X(W)], [o.wr * 1.4, o.wr, o.wr * 0.7], 0.04); r.roles.wings[side] = wn; const wbone = wn[2]; r.roles.fingers[side] = [];
    const tips = [], mids = [];
    fingers.forEach((f, i) => { const len = sp * (0.75 - i * 0.07); const dir = [f[0] * sx, f[1], f[2]]; const dl = Math.hypot(...dir); const tip = [W[0] * sx + dir[0] / dl * len, W[1] + dir[1] / dl * len, W[2] + dir[2] / dl * len]; const mid = [(W[0] * sx + tip[0]) / 2, (W[1] + tip[1]) / 2, (W[2] + tip[2]) / 2]; const f1 = 'fing' + side + i + '_1', f2 = 'fing' + side + i + '_2'; r.bone(f1, wbone, mid); r.bone(f2, f1, tip); r.cone(f1, mid, tip, o.wr * 0.38, o.wr * 0.12, 0.01); r.cone(f1, [W[0] * sx, W[1], W[2]], mid, o.wr * 0.5, o.wr * 0.38, 0.01); r.roles.fingers[side].push([f1, f2]); tips.push(tip); });
    const body0 = [rw * 0.35 * sx, yc + m.rv * 0.55, L * 0.1], body1 = [rw * 0.4 * sx, yc + m.rv * 0.1, -L * 0.42];
    // membrana: abanico desde la muñeca
    const pts = [X(W)].concat(tips); const wr3 = X(W); const poly = [tips[0]]; for (let i = 1; i < tips.length; i++) { const a = tips[i - 1], b = tips[i]; const mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]; poly.push([lerp(mid[0], wr3[0], 0.16), lerp(mid[1], wr3[1], 0.16), lerp(mid[2], wr3[2], 0.16)], b); }
    poly.push(body1); poly.push(body0); const pos = [], col = [], idx = []; const c0 = o.mem0, c1 = o.mem1;
    const Cc = [(wr3[0] + body0[0]) / 2, wr3[1], wr3[2]]; pos.push(...wr3); col.push(...c0, 1);
    poly.forEach(p => { pos.push(...p); const d = Math.hypot(p[0] - wr3[0], p[1] - wr3[1], p[2] - wr3[2]) / (sp * 0.8); const c = mix3(c0, c1, clamp(d, 0, 1)); col.push(c[0], c[1], c[2], 1); });
    for (let i = 0; i < poly.length - 1; i++) { if (sx > 0) idx.push(0, 1 + i, 2 + i); else idx.push(0, 2 + i, 1 + i); }
    // subdividir: añadir puntos intermedios (lerp wrist-> borde) para que la piel siga mejor
    const sub = []; for (let i = 0; i < poly.length; i++) { for (const f of [0.33, 0.66]) { const p = poly[i]; sub.push([lerp(wr3[0], p[0], f), lerp(wr3[1], p[1], f) - 0.02 * o.s * f * (1 - f) * 4, lerp(wr3[2], p[2], f)]); } }
    // reconstruir con anillos
    const rings = [[wr3]]; rings.push(...[0.33, 0.66, 1].map(f => poly.map(p => [lerp(wr3[0], p[0], f), lerp(wr3[1], p[1], f) - (f < 1 ? 0.03 * o.s * Math.sin(f * 3.14) : 0), lerp(wr3[2], p[2], f)])));
    const P2 = [], C2 = [], I2 = []; P2.push(...wr3); C2.push(...c0, 1); const ringStart = [0];
    for (let ri = 1; ri < rings.length; ri++) { ringStart.push(P2.length / 3); rings[ri].forEach(p => { P2.push(...p); const d = Math.hypot(p[0] - wr3[0], p[1] - wr3[1], p[2] - wr3[2]) / (sp * 0.85); const c = mix3(c0, c1, clamp(d, 0, 1)); const vein = 0.85 + 0.15 * Math.sin(d * 40 + p[2] * 30); C2.push(c[0] * vein, c[1] * vein, c[2] * vein, 1); }); }
    const n = poly.length;
    for (let i = 0; i < n - 1; i++) { const a = ringStart[1] + i, b = a + 1; if (sx > 0) I2.push(0, a, b); else I2.push(0, b, a); }
    for (let ri = 1; ri < 3; ri++) for (let i = 0; i < n - 1; i++) { const a = ringStart[ri] + i, b = a + 1, c = ringStart[ri + 1] + i, d = c + 1; if (sx > 0) I2.push(a, c, b, b, c, d); else I2.push(a, b, c, b, d, c); }
    r.decor.push({ type: 'mesh', kind: 'sheet', pos: P2, col: C2, idx: I2 });
  }
}
function wingBase(rw, yc, rv, L) { return null; }

// ---------- Tigre blanco (anatomía felina propia) ----------
function feline(P) {
  const r = new Rig(P.id); r.ks = 1.0; const S = P.S || 1; const sx2 = [-1, 1];
  const Y = 0.8; r.bone('pelvis', null, [0, Y, -0.55]); r.bone('spine1', 'pelvis', [0, Y + 0.02, -0.05]); r.bone('spine2', 'spine1', [0, Y + 0.03, 0.42]);
  r.bone('neck1', 'spine2', [0, Y + 0.06, 0.72]); r.bone('neck2', 'neck1', [0, Y + 0.02, 0.9]); r.bone('head', 'neck2', [0, Y - 0.04, 1.06]); r.bone('jaw', 'head', [0, Y - 0.1, 1.14]);
  // torso
  r.ell('pelvis', [0, Y, -0.52], [0.2, 0.26, 0.3], 0.08); r.cone('spine1', [0, Y - 0.01, -0.36], [0, Y - 0.01, 0.16], 0.19, 0.215, 0.1, { sc: [0.88, 1.1, 1] }); r.ell('spine1', [0, Y - 0.2, 0.0], [0.15, 0.13, 0.3], 0.1);
  r.ell('spine2', [0, Y, 0.45], [0.23, 0.3, 0.34], 0.08); r.ell('spine2', [0, Y + 0.17, 0.5], [0.12, 0.07, 0.2], 0.08);
  for (const sx of sx2) { r.ell('pelvis', [sx * 0.16, Y - 0.1, -0.5], [0.12, 0.24, 0.24], 0.08); r.ell('spine2', [sx * 0.17, Y - 0.02, 0.52], [0.1, 0.24, 0.2], 0.08); }
  // cuello y cabeza
  r.cone('neck1', [0, Y + 0.05, 0.6], [0, Y + 0.05, 0.9], 0.235, 0.205, 0.08, { sc: [1.05, 1, 1] }); r.cone('neck2', [0, Y + 0.05, 0.85], [0, Y + 0.02, 1.08], 0.205, 0.18, 0.06);
  const hz = 1.14; r.ell('head', [0, Y + 0.035, hz], [0.17, 0.15, 0.18], 0.05);
  for (const sx of sx2) { r.ell('head', [sx * 0.16, Y - 0.04, hz - 0.04], [0.06, 0.1, 0.1], 0.05); r.ell('head', [sx * 0.085, Y + 0.12, hz + 0.09], [0.07, 0.035, 0.06], 0.03); r.ell('head', [sx * 0.052, Y - 0.07, hz + 0.22], [0.06, 0.04, 0.08], 0.03); }
  r.cone('head', [0, Y + 0.07, hz + 0.06], [0, Y - 0.01, hz + 0.24], 0.07, 0.07, 0.04); r.ell('head', [0, Y - 0.05, hz + 0.2], [0.105, 0.078, 0.11], 0.05); r.ell('head', [0, Y - 0.018, hz + 0.305], [0.05, 0.034, 0.03], 0.02);
  r.cone('jaw', [0, Y - 0.115, hz + 0.0], [0, Y - 0.1, hz + 0.26], 0.085, 0.065, 0.03, { sc: [1, 0.78, 1] });
  r.sub('head', 'rc', [[0, Y - 0.082, hz + 0.1], [0, Y - 0.084, hz + 0.33], 0.007, 0.007], 0.004); for (const sx of sx2) r.sub('head', 'el', [[sx * 0.022, Y - 0.012, hz + 0.325], [0.011, 0.01, 0.014]], 0.005);
  for (const sx of sx2) { r.rigid.push({ bone: 'head', eye: { r: 0.021, slit: false }, at: [sx * 0.128, Y + 0.085, hz + 0.12] });
    const en = sx < 0 ? 'earL' : 'earR'; r.bone(en, 'head', [sx * 0.1, Y + 0.14, hz - 0.06]); r.cone(en, [sx * 0.1, Y + 0.14, hz - 0.06], [sx * 0.125, Y + 0.2, hz - 0.075], 0.05, 0.043, 0.02, { sc: [1, 1, 0.45] }); r.roles.ears.push(en);
    for (let k = 0; k < 4; k++) r.decor.push({ type: 'ribbon', kind: 'sheet', path: strand([sx * 0.045, Y - 0.062 + k * 0.011, hz + 0.21], [sx * 1, 0.12 - 0.12 * k, 0.55], 0.17, 0.12, 4), w0: 0.0028, w1: 0.001, up: [0, 1, 0], c0: [0.97, 0.97, 0.95], c1: [0.9, 0.9, 0.88] }); }
  // patas
  const legs = {};
  for (const sx of sx2) for (const front of [true, false]) {
    const key = (front ? 'F' : 'H') + (sx < 0 ? 'L' : 'R'); let pts, rad, par;
    if (front) { par = 'spine2'; pts = [[sx * 0.17, Y - 0.08, 0.5], [sx * 0.155, 0.45, 0.49], [sx * 0.15, 0.15, 0.52], [sx * 0.15, 0.05, 0.58]]; rad = [0.115, 0.093, 0.074, 0.07]; }
    else { par = 'pelvis'; pts = [[sx * 0.17, Y - 0.08, -0.5], [sx * 0.17, 0.47, -0.36], [sx * 0.16, 0.25, -0.62], [sx * 0.16, 0.05, -0.56]]; rad = [0.14, 0.1, 0.066, 0.07]; }
    const names = r.chain(key + '_', par, pts, rad, 0.06); legs[key] = names; const pz = pts[3][2];
    r.ell(names[3], [pts[3][0], 0.038, pz + 0.045], [0.088, 0.04, 0.115], 0.04);
    for (let k = -1; k <= 1; k++) r.ell(names[3], [pts[3][0] + k * 0.04, 0.03, pz + 0.14 - Math.abs(k) * 0.01], [0.026, 0.026, 0.03], 0.015);
    if (!front) r.ell(names[0], [pts[0][0], pts[0][1] - 0.1, pts[0][2] + 0.0], [0.115, 0.2, 0.2], 0.1);
  }
  r.roles.legs = legs;
  // cola larga y gruesa
  const tp = [[0, Y + 0.02, -0.8]], tr = [0.065]; let ty = Y + 0.02, tz = -0.8; for (let i = 1; i <= 9; i++) { const t = i / 9; ty += (t < 0.45 ? -0.07 : 0.025); tz -= 0.115; tp.push([0, ty, tz]); tr.push(0.058 - 0.014 * t); }
  r.roles.tails = r.chain('tail', 'pelvis', tp, tr, 0.05);
  r.roles.spine = ['pelvis', 'spine1', 'spine2']; r.roles.neck = ['neck1', 'neck2']; r.roles.head = 'head'; r.roles.jaw = 'jaw'; r.roles.root = 'pelvis';
  const m = r.meta; m.L = 1.35; m.H = 0.98; m.hipY = Y; m.stride = 1.1; m.nt = [0, Y - 0.04, 1.06]; m.hR = 0.15; m.hL = 0.33; m.nb = [0, Y + 0.06, 0.72]; m.rw = 0.2; m.rv = 0.28; m.yc = Y; m.lt = 0.07; m.snout = [0, Y - 0.02, hz + 0.25];
  return r;
}
SP.tigre = { id: 'tigre', name: 'Tigre Blanco', cat: 'animales', rank: 'epico', int: 7, pow: 8, spd: 8, hab: 'Colinas y montañas', diet: 'Carnívoro', move: 'ground', cell: 0.016, size: 1.4,
  desc: 'Guardián del oeste en las leyendas. Silencioso y letal, sus rayas se funden con la nieve y la sombra.',
  habits: { wander: 4, rest: 4, idle: 2, sing: 1 }, social: 'wary', sound: 'roar', eyeColor: 0x8fb8c8,
  style: { detail: 'fur', dscale: 5, dstr: 0.8, rough: 0.9 },
  build() { return feline({ id: 'tigre' }); },
  paint(c) {
    const { x, y, z, ny, nz, bone } = c; const ax = Math.abs(x); const noise = noiseCol(c, 30, 0.08); const warp = fbm(x * 3.2, y * 3.2, z * 3.2, 3) - 0.5;
    const isHead = bone === 'head' || bone === 'jaw'; const isEar = bone.startsWith('ear'); const isTail = bone.startsWith('tail'); const isLeg = /^[FH][LR]_/.test(bone);
    let col = mix3([0.97, 0.96, 0.94], [0.84, 0.84, 0.83], smooth(-0.2, 0.9, ny) * 0.8); col = mix3(col, [0.9, 0.86, 0.8], smooth(0.4, 0.5, fbm(x * 4, y * 4, z * 4, 2)) * 0.25);
    let dark = 0; const Y = 0.8;
    if (isHead && bone === 'head') {
      const fore = smooth(Y + 0.06, Y + 0.1, y) * smooth(1.32, 1.2, z); const uf = ax * 38 + warp * 2.2 + (z - 1.0) * 6; const df = Math.abs(uf - Math.floor(uf) - 0.5) * 2; dark = Math.max(dark, smooth(0.7, 0.55, df) * fore * smooth(0.0, 0.03, ax + 0.01));
      const ch = smooth(0.1, 0.14, ax) * smooth(Y + 0.04, Y - 0.0, y) * smooth(Y - 0.13, Y - 0.08, y) * smooth(1.28, 1.2, z); const uc = y * 48 + warp * 2.0 - z * 14; const dc = Math.abs(uc - Math.floor(uc) - 0.5) * 2; dark = Math.max(dark, smooth(0.55, 0.42, dc) * ch * 0.9);
      const ed = Math.hypot(ax - 0.128, y - (Y + 0.085), z - 1.26); dark = Math.max(dark, smooth(0.052, 0.03, ed) * 0.95);
      const muz = smooth(1.26, 1.31, z); const dots = smooth(0.7, 0.8, fbm(x * 170, y * 170, z * 170, 1)) * smooth(0.02, 0.04, ax) * smooth(0.09, 0.06, ax) * muz * smooth(Y - 0.03, Y - 0.06, y) * smooth(Y - 0.1, Y - 0.07, y) * -1 + 0; dark = Math.max(dark, Math.abs(dots) * 0.0);
      dark *= (1 - muz * 0.9);
      col = mix3(col, [0.1, 0.085, 0.085], dark * 0.95);
      if (z > 1.41 && ax < 0.042 && y > Y - 0.045 && y < Y + 0.0) col = mix3(col, [0.62, 0.38, 0.38], smooth(1.41, 1.425, z) * smooth(0.042, 0.03, ax));
      const lip = smooth(0.009, 0, Math.abs(y - (Y - 0.083))) * smooth(1.2, 1.26, z); col = mix3(col, [0.3, 0.17, 0.17], lip * 0.85);
      return [col[0] * noise, col[1] * noise, col[2] * noise];
    }
    if (isHead) return [0.96 * noise, 0.95 * noise, 0.93 * noise];
    if (isEar) { const back = smooth(0.1, -0.3, nz); col = mix3([0.98, 0.9, 0.88], [0.1, 0.1, 0.11], back); col = mix3(col, [0.9, 0.9, 0.9], smooth(0.1, 0.05, Math.hypot(ax - 0.11, y - (Y + 0.17))) * back * 0.9); return [col[0] * noise, col[1] * noise, col[2] * noise]; }
    if (isTail) { const i = parseInt(bone.slice(4)); const u = z * 8.5 + warp; const d = Math.abs(u - Math.floor(u) - 0.5) * 2; dark = smooth(0.7, 0.55, d); if (i >= 9) dark = 1; col = mix3(col, [0.09, 0.08, 0.08], dark * 0.95); return [col[0] * noise, col[1] * noise, col[2] * noise]; }
    if (isLeg && !/_1$/.test(bone)) { const u = y * 9 + warp * 2.4 + z * 3; const d = Math.abs(u - Math.floor(u) - 0.5) * 2; const inner = smooth(0.2, 0.34, y) * smooth(0.6, 0.45, y); dark = smooth(0.82, 0.66, d) * inner * 0.8 * smooth(0.3, 0.7, fbm(x * 12, y * 12, z * 12, 2) + 0.2); }
    else {
      const tp = smooth(0.38, 0.72, y) * smooth(-0.7, 0.05, ny); let u = z * 7.4 + warp * 1.7 + Math.sin(y * 6 + z * 1.4) * 0.2; let d = Math.abs(u - Math.floor(u) - 0.5) * 2; const w = (0.36 + 0.3 * (fbm(x * 9, y * 9, z * 4, 2) - 0.25)) * tp; dark = smooth(w, w - 0.14, d) * smooth(0.12, 0.38, fbm(x * 12, y * 12, z * 5, 2) + 0.08);
      const u2 = z * 14.5 + warp * 3.2; const d2 = Math.abs(u2 - Math.floor(u2) - 0.5) * 2; dark = Math.max(dark, smooth(0.34 * tp, 0.2 * tp, d2) * 0.8 * smooth(0.3, 0.6, fbm(x * 10, y * 10, z * 8, 2)));
      if (bone.startsWith('neck') || z > 0.85) dark = Math.max(dark, 0.0);
    }
    col = mix3(col, [0.1, 0.085, 0.085], dark * 0.94); return [col[0] * noise, col[1] * noise, col[2] * noise];
  } };
// ---------- Oso pardo ----------
SP.oso = { id: 'oso', name: 'Oso Pardo', cat: 'animales', rank: 'raro', int: 5, pow: 8, spd: 5, hab: 'Bosque y montañas', diet: 'Omnívoro', move: 'ground', cell: 0.026, size: 1.4,
  desc: 'Enorme y paciente. Dormita junto a los ríos y defiende su territorio con una fuerza descomunal.',
  habits: { wander: 3, rest: 5, graze: 2, idle: 2 }, social: 'ignore', sound: 'growl', eyeColor: 0x1a0c06,
  style: { detail: 'fur', dscale: 3.5, dstr: 1.0, rough: 0.95 },
  build() { return quadruped({ id: 'oso', L: 1.1, H: 1.05, rv: 0.34, rw: 0.25, neckL: 0.3, neckUp: 0.1, neckR: 0.9, headL: 0.36, headR: 0.17, snout: 0.15, snoutR: 0.095, snoutTaper: 0.8, lt: 0.11, digi: 0.2, earLen: 0.07, earW: 0.065, earTip: 0.6, earOut: 0.05, cheek: true, claws: true, belly: true, ksm: 1.1, tail: { n: 2, len: 0.12, r: 0.06, droop: 0.9 }, eyeZ: 0.36, eyeR: 0.1 }); },
  paint(c) { const n = noiseCol(c, 20, 0.35), st = fbm(c.x * 60, c.y * 30, c.z * 20, 2); let col = mix3([0.40, 0.25, 0.13], [0.58, 0.38, 0.19], smooth(-0.6, 0.6, c.ny)); col = mix3(col, [0.52, 0.38, 0.22], smooth(0.5, 0.9, fbm(c.x * 12, c.y * 12, c.z * 12, 2)) * 0.35);
    if (/^[FH][LR]_/.test(c.bone) && c.y < 0.3) col = mix3(col, [0.1, 0.07, 0.05], 0.6); if (c.bone === 'head' && c.z > c.rig.meta.nt[2] + 0.2) col = mix3(col, [0.5, 0.38, 0.26], 0.7); const k = n * (0.85 + 0.3 * st); return [col[0] * k, col[1] * k, col[2] * k]; } };
// ---------- Unicornio / Pegaso ----------
function horse(P) {
  const r = quadruped(Object.assign({ L: 1.55, H: 1.5, rv: 0.3, rw: 0.19, neckL: 0.62, neckUp: 0.55, neckR: 0.62, headL: 0.5, headR: 0.12, snout: 0.26, snoutR: 0.082, snoutTaper: 0.85, snoutW: 0.9, lt: 0.056, digi: 0.45, hoof: true, earLen: 0.17, earW: 0.05, earOut: 0.1, earTip: 0.2, tail: { n: 6, len: 0.7, r: 0.04, droop: 1.1, curl: 0.05, bush: 0.15 }, eyeZ: 0.33, eyeR: 0.15, belly: true }, P));
  return r;
}
SP.unicornio = { id: 'unicornio', name: 'Unicornio', cat: 'fantasticos', rank: 'epico', int: 8, pow: 6, spd: 9, hab: 'Claros y bosques', diet: 'Herbívoro', move: 'ground', cell: 0.022, size: 1.8,
  desc: 'Corcel de pureza inmaculada. Su cuerno cura heridas y deja una estela de destellos a su paso.',
  habits: { wander: 4, graze: 3, rest: 2, idle: 2, sing: 1 }, social: 'curious', sound: 'neigh', eyeColor: 0x6a3a9a, hornColor: 0xf6ecc8,
  style: { detail: 'fur', dscale: 3.5, dstr: 0.45, rough: 0.55, emissive: 0x6a80ff, emissiveI: 0.05 },
  build() { const r = horse({ id: 'unicornio' }); const m = r.meta, nt = m.nt, hR = m.hR;
    const base = add(nt, [0, hR * 0.8, m.hL * 0.3]); hornSweep(r, 'head', bez(base, add(base, [0, 0.14, 0.05]), add(base, [0, 0.3, 0.1]), add(base, [0, 0.48, 0.17]), 12), 0.028, 0.002, 10);
    const pts = []; for (let i = 0; i < 8; i++) pts.push(add(m.nb, [0, 0.04 + i * 0.075, 0.0 + i * 0.07])); mane(r, pts, { strands: 3, len: 0.5, up: 0.4, back: 0.8, droop: 1.1, spread: 0.05, w0: 0.045, w1: 0.012, cf: (t, k) => mix3([0.98, 0.78, 0.95], [0.6, 0.78, 1.0], clamp(t * 0.9 + k * 0.3, 0, 1)) });
    const tb = [0, m.yc + m.rv * 0.3, -m.L * 0.5 - 0.2]; for (let i = 0; i < 6; i++) { const path = strand(add(tb, [(rnd() - 0.5) * 0.06, 0, 0]), [(rnd() - 0.5) * 0.3, -0.6, -0.5], 0.9, 0.5, 8); r.decor.push({ type: 'ribbon', kind: 'sheet', path, w0: 0.05, w1: 0.012, up: [1, 0, 0], cf: tt => mix3([0.98, 0.78, 0.95], [0.55, 0.75, 1.0], tt) }); }
    return r; },
  paint(c) { const n = noiseCol(c, 22, 0.08); let col = mix3([0.93, 0.92, 0.95], [0.99, 0.98, 1.0], smooth(-0.5, 0.5, c.ny)); const irid = fbm(c.x * 3, c.y * 3, c.z * 3, 2); col = mix3(col, [0.88, 0.92, 1.0], irid * 0.5);
    if (/^[FH][LR]_/.test(c.bone) && c.y < 0.06) col = mix3(col, [0.85, 0.8, 0.8], 0.8); const k = n; return [col[0] * k, col[1] * k, col[2] * k]; } };
SP.pegaso = { id: 'pegaso', kind: 'winged', name: 'Pegaso', cat: 'fantasticos', rank: 'epico', int: 7, pow: 6, spd: 10, hab: 'Cielos y montañas', diet: 'Herbívoro', move: 'ground', fly: true, cell: 0.024, size: 2.2,
  desc: 'Caballo alado nacido de las nubes. Galopa sobre el aire y se posa en las cumbres para descansar.',
  habits: { wander: 3, fly: 5, rest: 2, idle: 2 }, social: 'wary', sound: 'neigh', eyeColor: 0x2a2a3a, anim: { flapAmp: 0.7, flapHz: 1.9 },
  style: { detail: 'fur', dscale: 3.5, dstr: 0.4, rough: 0.6 },
  build() { const r = horse({ id: 'pegaso', ksm: 1 }); const m = r.meta;
    featherWings(r, { span: 6, s: 1, wr: 0.045, cols: [[0.95, 0.96, 1.0], [0.8, 0.85, 0.98], [0.98, 0.98, 1.0], [0.85, 0.88, 0.98], [0.97, 0.97, 1.0], [0.9, 0.92, 1.0]] });
    const pts = []; for (let i = 0; i < 7; i++) pts.push(add(m.nb, [0, 0.04 + i * 0.075, i * 0.07])); mane(r, pts, { strands: 2, len: 0.45, up: 0.4, back: 0.8, droop: 1.1, w0: 0.04, w1: 0.012, c0: [0.85, 0.9, 1], c1: [0.6, 0.7, 0.95] }); return r; },
  paint(c) { const n = noiseCol(c, 22, 0.08); let col = mix3([0.9, 0.92, 0.98], [0.98, 0.99, 1], smooth(-0.5, 0.5, c.ny)); if (/^[FH][LR]_/.test(c.bone) && c.y < 0.06) col = [0.75, 0.75, 0.8]; return [col[0] * n, col[1] * n, col[2] * n]; } };
// ---------- Kirin ----------
SP.kirin = { id: 'kirin', name: 'Kirin (麒麟)', cat: 'fantasticos', rank: 'legendario', int: 9, pow: 8, spd: 8, hab: 'Colinas sagradas', diet: 'Rocío y flores', move: 'ground', cell: 0.022, size: 1.8,
  desc: 'Criatura benévola de escamas doradas y melena de fuego. Camina sin pisar la hierba y anuncia la llegada de un sabio.',
  habits: { wander: 4, rest: 2, idle: 3, sing: 2 }, social: 'curious', sound: 'chime', eyeColor: 0xff9020, hornColor: 0xe8d090, kind: 'quad',
  style: { detail: 'scales', dscale: 6, dstr: 1.1, rough: 0.4, metal: 0.25, emissive: 0xff7a10, emissiveI: 0.12 },
  build() { const r = quadruped({ id: 'kirin', L: 1.5, H: 1.35, rv: 0.29, rw: 0.19, neckL: 0.5, neckUp: 0.4, neckR: 0.7, headL: 0.42, headR: 0.125, snout: 0.2, snoutR: 0.095, snoutTaper: 0.8, snoutW: 1.1, lt: 0.052, digi: 0.45, hoof: true, earLen: 0.1, earW: 0.04, earOut: 0.5, earTip: 0.2, tail: { n: 6, len: 0.7, r: 0.045, droop: 0.9, bush: 0.2 }, eyeZ: 0.33, eyeR: 0.14, belly: true }); const m = r.meta, nt = m.nt, hR = m.hR;
    for (const sx of [-1, 1]) { const b = add(nt, [sx * hR * 0.4, hR * 0.8, hR * 0.0]); hornSweep(r, 'head', bez(b, add(b, [sx * 0.03, 0.14, -0.06]), add(b, [sx * 0.07, 0.26, -0.16]), add(b, [sx * 0.05, 0.38, -0.32]), 10), 0.022, 0.003, 8); const bd = add(nt, [sx * hR * 0.45, -hR * 0.3, hR * 1.2]); r.decor.push({ type: 'ribbon', kind: 'sheet', path: strand(add(nt, [sx * 0.04, -0.06, m.hL * 0.55]), [sx * 0.5, -0.2, 0.5], 0.4, 0.5, 6), w0: 0.012, w1: 0.004, up: [0, 1, 0], c0: [0.95, 0.8, 0.3], c1: [0.9, 0.7, 0.2] }); }
    r.decor.push({ type: 'ribbon', kind: 'sheet', path: strand(add(nt, [0, -0.1, m.hL * 0.15]), [0, -0.8, -0.2], 0.35, 0.3, 6), w0: 0.04, w1: 0.012, up: [1, 0, 0], c0: [0.95, 0.8, 0.3], c1: [0.95, 0.75, 0.25] });
    const pts = []; for (let i = 0; i < 9; i++) pts.push(add(m.nb, [0, 0.03 + i * 0.06, i * 0.055 - 0.05])); mane(r, pts, { kind: 'fire', strands: 3, len: 0.5, up: 0.7, back: 0.6, droop: 0.4, w0: 0.07, w1: 0.02, spread: 0.05, cf: (t) => mix3([1, 0.85, 0.3], [1, 0.25, 0.05], t) });
    ['FL', 'FR', 'HL', 'HR'].forEach(k => { const L = r.roles.legs[k]; const b = r.byName[L[2]].pos; r.decor.push({ type: 'ribbon', kind: 'fire', path: strand(b, [0, 0.5, -0.5], 0.28, 0.2, 5), w0: 0.05, w1: 0.012, up: [1, 0, 0], cf: tt => mix3([1, 0.85, 0.3], [1, 0.3, 0.05], tt), af: tt => 0.85 * (1 - tt) }); });
    return r; },
  paint(c) { const n = noiseCol(c, 20, 0.15); let col = mix3([0.96, 0.9, 0.7], [0.8, 0.58, 0.14], smooth(-0.5, 0.45, c.ny)); const sc = fbm(c.x * 14, c.y * 14, c.z * 14, 2); col = mix3(col, [0.2, 0.55, 0.38], smooth(0.3, 0.8, c.ny) * smooth(0.55, 0.7, sc) * 0.6);
    if (/^[FH][LR]_/.test(c.bone)) col = mix3(col, [0.2, 0.12, 0.05], smooth(0.12, 0.04, c.y)); const k = n; return [col[0] * k, col[1] * k, col[2] * k]; } };
// ---------- Zorro de nueve colas ----------
SP.zorro9 = { id: 'zorro9', name: 'Zorro de Nueve Colas (九尾狐)', cat: 'fantasticos', rank: 'legendario', int: 10, pow: 8, spd: 9, hab: 'Bosques antiguos', diet: 'Esencia espiritual', move: 'ground', cell: 0.02, size: 1.2,
  desc: 'Espíritu milenario de nueve colas llameantes. Cambia de forma, juega con los viajeros y brilla al anochecer.',
  habits: { wander: 4, rest: 2, idle: 3, sing: 1 }, social: 'curious', sound: 'yip', eyeColor: 0x60b8ff, kind: 'quad',
  style: { detail: 'fur', dscale: 5, dstr: 0.9, rough: 0.8, emissive: 0x70a8ff, emissiveI: 0.08 },
  build() { const r = quadruped({ id: 'zorro9', L: 0.85, H: 0.7, rv: 0.19, rw: 0.12, neckL: 0.2, neckUp: 0.1, neckR: 0.65, headL: 0.22, headR: 0.09, snout: 0.15, snoutR: 0.052, lt: 0.037, digi: 1, earLen: 0.17, earW: 0.06, earOut: 0.15, belly: true, cheek: true, tail: { n: 5, len: 0.7, r: 0.06, droop: 0.3, curl: 0.0, bush: 1.2, tipPow: 3 }, eyeZ: 0.3, slit: true, eyeR: 0.18 }); const m = r.meta;
    r.roles.tailChains = [r.roles.tails]; const base = [0, m.yc + m.rv * 0.25, -m.L * 0.5 - m.rv * 0.5];
    for (let k = 1; k < 9; k++) { const a = (k / 8 - 0.5) * 2.4; const len = 0.7, n = 5; const pts = [base]; let p = base; for (let i = 0; i < n; i++) { const up = 0.3 + 0.5 * (1 - Math.abs(a) / 1.2) * Math.min(1, i / 3), ang = a * Math.min(1, (i + 1) / 2); p = [p[0] + Math.sin(ang) * len / n * 1.0, p[1] + up * len / n - 0.02, p[2] - Math.cos(ang) * len / n]; pts.push(p); } const radii = pts.map((_, i) => 0.055 * (1 + 1.1 * Math.sin(Math.PI * Math.pow(i / n, 0.8))) * (1 - 0.8 * Math.pow(i / n, 3)));
      const names = r.chain('tailx' + k + '_', 'pelvis', pts, radii, 0.05); r.roles.tailChains.push(names); const tip = pts[n]; r.decor.push({ type: 'ribbon', kind: 'fire', path: strand(tip, [Math.sin(a), 0.7, -0.4], 0.35, -0.2, 6), w0: 0.1, w1: 0.02, up: [1, 0, 0], cf: tt => mix3([0.7, 0.9, 1], [0.3, 0.45, 1], tt), af: tt => 0.8 * (1 - tt) }); }
    return r; },
  paint(c) { const n = noiseCol(c, 28, 0.22), st = fbm(c.x * 120, c.y * 40, c.z * 20, 2); let col = mix3([0.98, 0.97, 0.94], [0.97, 0.9, 0.78], smooth(-0.5, 0.4, c.ny)); if (c.bone.startsWith('tail')) { const i = parseInt((c.bone.match(/(\d+)$/) || [0, 1])[1]); col = mix3(col, [1, 0.8, 0.45], 0.2 + 0.1 * i / 5); }
    if (c.bone.startsWith('ear')) col = mix3(col, [0.1, 0.07, 0.1], 0.7); if (/^[FH][LR]_/.test(c.bone)) col = mix3(col, [0.12, 0.1, 0.14], smooth(0.2, 0.05, c.y) * 0.9);
    if (c.bone === 'head' && c.z > c.rig.meta.nt[2] + 0.1) { const tx = c.x; col = mix3(col, [0.8, 0.1, 0.1], smooth(0.012, 0.0, Math.abs(Math.abs(tx) - 0.045)) * smooth(0.0, 0.03, c.y - (c.rig.meta.nt[1] + 0.06)) * 0.0); }
    const k = n * (0.9 + 0.2 * st); return [col[0] * k, col[1] * k, col[2] * k]; } };
// ---------- Grifo ----------
SP.grifo = { id: 'grifo', kind: 'winged', name: 'Grifo', cat: 'fantasticos', rank: 'epico', int: 7, pow: 8, spd: 9, hab: 'Riscos y montañas', diet: 'Carnívoro', move: 'ground', fly: true, cell: 0.022, size: 1.9,
  desc: 'Mitad águila, mitad león. Guardián de tesoros que patrulla las cumbres con vuelos majestuosos.',
  habits: { wander: 2, fly: 5, rest: 3, idle: 2, sing: 1 }, social: 'wary', sound: 'screech', eyeColor: 0xf0b010, anim: { flapAmp: 0.65, flapHz: 1.7 },
  style: { detail: 'fur', dscale: 4, dstr: 0.9, rough: 0.8 },
  build() { const r = quadruped({ id: 'grifo', L: 1.3, H: 1.15, rv: 0.3, rw: 0.2, neckL: 0.34, neckUp: 0.3, neckR: 0.85, headL: 0.26, headR: 0.1, snout: 0.05, snoutR: 0.055, lt: 0.06, digi: 0.8, earLen: 0.0, earW: 0.001, claws: true, belly: true, ksm: 1, tail: { n: 6, len: 0.9, r: 0.045, droop: 0.4, bush: 0.5, tipPow: 3 }, eyeZ: 0.38, eyeR: 0.2 }); const m = r.meta, nt = m.nt, hR = m.hR;
    const b0 = add(nt, [0, -hR * 0.05, m.hL * 0.55]), tip = add(b0, [0, -0.05, 0.16]); r.cone('head', b0, tip, 0.05, 0.016, 0.02, { sc: [0.7, 1, 1] }); r.cone('head', tip, add(tip, [0, -0.07, -0.02]), 0.016, 0.004, 0.012); r.cone('jaw', add(b0, [0, -0.05, -0.04]), add(tip, [0, 0.015, -0.02]), 0.03, 0.01, 0.01, { sc: [0.7, 1, 1] });
    featherWings(r, { span: 3.6, s: 1, wr: 0.05, cols: [[0.45, 0.28, 0.12], [0.2, 0.12, 0.06], [0.55, 0.36, 0.16], [0.3, 0.18, 0.08], [0.75, 0.6, 0.35], [0.5, 0.35, 0.18]] });
    for (let i = 0; i < 14; i++) { const a = i / 13 * Math.PI * 2; const p = add(m.nb, [Math.sin(a) * 0.1, 0.05 + Math.cos(a) * 0.1, 0.0 + 0.1]); r.decor.push({ type: 'feather', kind: 'feather', base: add(nt, [Math.sin(a) * 0.07, Math.cos(a) * 0.07 - 0.04, -0.05]), dir: [Math.sin(a) * 0.4, Math.cos(a) * 0.3, -0.85], len: 0.2, w: 0.06, bend: -0.2, cf: tt => mix3([0.95, 0.92, 0.85], [0.7, 0.6, 0.45], tt) }); }
    return r; },
  paint(c) { const n = noiseCol(c, 24, 0.22), st = fbm(c.x * 90, c.y * 30, c.z * 20, 2); const m = c.rig.meta; let col = mix3([0.78, 0.6, 0.34], [0.55, 0.37, 0.16], smooth(-0.5, 0.4, c.ny));
    if (c.bone === 'head' || c.bone === 'jaw' || c.bone.startsWith('neck')) { col = mix3(col, [0.96, 0.94, 0.88], 0.88); if (c.z > m.nt[2] + m.hL * 0.5) col = [0.95, 0.75, 0.2]; }
    if (/^[F][LR]_/.test(c.bone) && c.y < 0.45) col = mix3(col, [0.95, 0.75, 0.2], 0.9); if (c.bone.startsWith('tail')) col = mix3(col, [0.3, 0.2, 0.1], 0.5); const k = n * (0.9 + 0.2 * st); return [col[0] * k, col[1] * k, col[2] * k]; } };
// ---------- Dragón occidental ----------
SP.dragon = { id: 'dragon', kind: 'winged', name: 'Dragón Ancestral', cat: 'leyendas', rank: 'mitico', int: 10, pow: 10, spd: 8, hab: 'Montañas y volcanes', diet: 'Carnívoro', move: 'ground', fly: true, cell: 0.06, size: 5,
  desc: 'Coloso alado de escamas negras como la obsidiana. Duerme sobre montañas de oro y su rugido hace temblar el cielo.',
  habits: { wander: 2, fly: 4, rest: 4, idle: 2, sing: 1 }, social: 'ignore', sound: 'roar', eyeColor: 0xffc020, hornColor: 0xb9a77f, clawColor: 0xd9ccaa, anim: { flapAmp: 0.6, flapHz: 1.0, idleSpread: 0.8 }, slitEyes: true,
  style: { detail: 'scales', dscale: 1.6, dstr: 1.5, rough: 0.36, metal: 0.25 },
  build() { const r = quadruped({ id: 'dragon', L: 3.2, H: 2.0, rv: 0.7, rw: 0.52, neckL: 0.85, neckUp: 1.35, neckR: 0.85, headL: 0.9, headR: 0.3, snout: 0.6, snoutR: 0.19, snoutTaper: 0.75, snoutW: 1.0, lt: 0.21, digi: 0.8, earLen: 0.0, earW: 0.001, claws: false, belly: true, ksm: 0.85, tail: { n: 10, len: 5.2, r: 0.3, droop: 0.12, curl: 0.0, bush: 0.0, tipPow: 1.2 }, eyeZ: 0.4, eyeR: 0.2, slit: true }); const m = r.meta, nt = m.nt, hR = m.hR;
    batWings(r, { span: 11, s: 1, wr: 0.13, mem0: [0.13, 0.115, 0.115], mem1: [0.32, 0.28, 0.26] });
    { const sn1 = m.snout, sR = 0.19, hL = m.hL; const up0 = add(nt, [0, -hR * 0.3, hL * 0.5]);
      for (const sx of [-1, 1]) { r.ell('head', add(nt, [sx * hR * 0.6, hR * 0.62, hL * 0.3]), [hR * 0.4, hR * 0.2, hL * 0.22], 0.04); r.ell('head', add(nt, [sx * hR * 0.5, hR * 0.0, hL * 0.0]), [hR * 0.45, hR * 0.6, hL * 0.25], 0.06);
        for (let i = 0; i < 8; i++) { const t = i / 7, p = [lerp(up0[0], sn1[0], t) + sx * sR * (0.85 - 0.35 * t), lerp(up0[1], sn1[1], t) - sR * 0.28, lerp(up0[2], sn1[2], t)]; const k = (i === 3 ? 1.7 : 1) * (1 - t * 0.35); r.rigid.push({ bone: 'head', mat: 'claw', geo: sweep([p, add(p, [0, -0.09 * k, 0.004]), add(p, [0, -0.17 * k, 0.012])], [0.026 * k, 0.015 * k, 0.002], 5) }); }
        for (let i = 0; i < 7; i++) { const t = i / 6, p = [sx * sR * (0.7 - 0.3 * t), lerp(nt[1] - hR * 0.62, sn1[1] - sR * 0.55, t) + 0.05, lerp(nt[2] + hL * 0.3, sn1[2] - 0.04, t)]; r.rigid.push({ bone: 'jaw', mat: 'claw', geo: sweep([p, add(p, [0, 0.07, 0.003]), add(p, [0, 0.13, 0.008])], [0.02, 0.012, 0.002], 5) }); }
        for (let k = 0; k < 3; k++) { const b = add(nt, [sx * hR * 0.85, -hR * 0.25 - k * 0.06, -hR * 0.1 - k * 0.16]); hornSweep(r, 'head', bez(b, add(b, [sx * 0.12, -0.02, -0.12]), add(b, [sx * 0.2, 0.0, -0.3]), add(b, [sx * 0.24, 0.06, -0.5 + k * 0.08]), 6), 0.04 - k * 0.008, 0.004, 6); } } }
    for (const sx of [-1, 1]) { const b = add(nt, [sx * hR * 0.55, hR * 0.7, -hR * 0.2]); hornSweep(r, 'head', bez(b, add(b, [sx * 0.15, 0.2, -0.3]), add(b, [sx * 0.25, 0.35, -0.7]), add(b, [sx * 0.2, 0.3, -1.1]), 12), 0.07, 0.008, 9);
      const b2 = add(nt, [sx * hR * 0.8, -hR * 0.1, -hR * 0.1]); hornSweep(r, 'head', bez(b2, add(b2, [sx * 0.15, 0.0, -0.1]), add(b2, [sx * 0.3, 0.05, -0.2]), add(b2, [sx * 0.4, 0.2, -0.35]), 8), 0.035, 0.005, 7); }
    // crestas dorsales
    const sp = [r.roles.spine, r.roles.neck]; const rows = [[0, m.yc + m.rv * 1.0, -m.L * 0.45], [0, m.yc + m.rv * 1.05, -m.L * 0.25], [0, m.yc + m.rv * 1.05, -m.L * 0.05], [0, m.yc + m.rv * 1.1, m.L * 0.15], [0, m.yc + m.rv * 1.2, m.L * 0.35]];
    rows.forEach((p, i) => { const sz = 0.22 - i * 0.015; r.rigid.push({ bone: i < 2 ? 'pelvis' : i < 4 ? 'spine1' : 'spine2', mat: 'horn', geo: sweep([p, add(p, [0, sz * 0.7, -sz * 0.4]), add(p, [0, sz * 1.1, -sz * 0.9])], [0.07, 0.04, 0.005], 6) }); });
    const tl = r.roles.tails; tl.forEach((n, i) => { if (i % 2 === 1 || i > 8) return; const p = r.byName[n].pos; const sz = 0.2 * (1 - i / 11); r.rigid.push({ bone: n, mat: 'horn', geo: sweep([add(p, [0, 0.2 * (1 - i / 12), 0]), add(p, [0, 0.2 * (1 - i / 12) + sz * 0.6, -sz * 0.4]), add(p, [0, 0.2 * (1 - i / 12) + sz, -sz])], [0.045, 0.025, 0.004], 5) }); });
    const dp = r.byName[r.roles.tails[r.roles.tails.length - 1]].pos; r.rigid.push({ bone: r.roles.tails[r.roles.tails.length - 1], mat: 'horn', geo: sweep([add(dp, [0, 0, 0.0]), add(dp, [0, 0.1, -0.35]), add(dp, [0, 0.0, -0.7])], [0.14, 0.09, 0.003], 7) });
    for (const k of ['FL', 'FR', 'HL', 'HR']) { const L = r.roles.legs[k], p = r.byName[L[3]].pos, sx = k[1] === 'L' ? -1 : 1; for (let j = -1; j <= 1; j++) r.rigid.push({ bone: L[3], mat: 'claw', geo: sweep([[p[0] + j * 0.08, 0.1, p[2] + 0.28], [p[0] + j * 0.1, 0.1, p[2] + 0.42], [p[0] + j * 0.1, 0.0, p[2] + 0.5]], [0.04, 0.03, 0.004], 6) }); }
    return r; },
  paint(c) { const n = noiseCol(c, 6, 0.3), st = fbm(c.x * 14, c.y * 14, c.z * 14, 3); let col = mix3([0.8, 0.8, 0.78], [0.09, 0.09, 0.105], smooth(-0.6, 0.3, c.ny)); col = mix3(col, [0.24, 0.24, 0.28], smooth(0.3, 0.9, st) * 0.6); if (c.bone.startsWith('tail') || c.bone.startsWith('neck') || c.bone.startsWith('spine') || c.bone === 'pelvis') { const belly = smooth(-0.1, -0.6, c.ny); const pl = Math.abs(Math.sin(c.z * 9)); const plate = 0.72 + 0.28 * smooth(0.05, 0.35, pl); col = mix3(col, [0.88, 0.82, 0.68], belly * plate); }
    if (c.bone === 'jaw') col = mix3(col, [0.8, 0.65, 0.4], 0.5); const k = n * 0.7 + 0.3; return [col[0] * k, col[1] * k, col[2] * k]; } };
return { featherWings, batWings, mane, strand, hornSweep, horse };
}

