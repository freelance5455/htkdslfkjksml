// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 6090-6236 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_SPECIES_D(Z, SP, A) {
const { THREE, clamp, lerp, smooth, mix3, fbm, Rig, sweep, bez, taper } = Z;
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const noiseCol = (c, f, a) => 1 + (fbm(c.x * f, c.y * f, c.z * f, 3) - 0.5) * a;
const quadruped = A.quadruped;
const rnd = (() => { let s = 777; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; })();
const strand = (p0, d, len, droop, n) => { const out = []; let p = p0.slice(); const dl = Math.hypot(d[0], d[1], d[2]) || 1; let dx = d[0] / dl, dy = d[1] / dl, dz = d[2] / dl; for (let i = 0; i <= n; i++) { out.push(p.slice()); p = [p[0] + dx * len / n, p[1] + dy * len / n, p[2] + dz * len / n]; dy -= droop / n; const l = Math.hypot(dx, dy, dz); dx /= l; dy /= l; dz /= l; } return out; };
const ribbon = (r, path, w0, w1, c0, c1, o) => r.decor.push(Object.assign({ type: 'ribbon', kind: 'sheet', path, w0, w1, up: [1, 0, 0], c0, c1 }, o || {}));
const horn = (r, bone, pts, r0, r1) => r.rigid.push({ bone, mat: 'horn', geo: sweep(pts, taper(pts.length, r0, r1, 1.1), 8) });
const eye = (r, bone, at, rad, slit) => r.rigid.push({ bone, eye: { r: rad, slit: !!slit }, at });
const leg3 = (r, key, parent, pts, rad, k) => { const n = r.chain(key + '_', parent, pts, rad, k || 0.05); return n; };

// ---------- Dragón oriental (serpentino, vuela sin alas) ----------
SP.dragonor = { id: 'dragonor', kind: 'serpent', name: 'Dragón Celestial (龍)', cat: 'leyendas', rank: 'mitico', int: 10, pow: 10, spd: 9, hab: 'Nubes y ríos sagrados', diet: 'Perlas de luz', move: 'air', fly: true, cell: 0.07, size: 6,
  desc: 'Serpiente cósmica de escamas jade y melena dorada. Nada entre las nubes y trae la lluvia a las tierras que protege.',
  habits: { fly: 5, rest: 1, sing: 2, idle: 1 }, social: 'curious', sound: 'chime', eyeColor: 0xffb020, hornColor: 0xe8cf8a, anim: { k: 0.5 },
  style: { detail: 'scales', dscale: 8, dstr: 1.0, rough: 0.35, metal: 0.3, emissive: 0x20c080, emissiveI: 0.05 },
  build() {
    const r = new Rig('dragonor'); r.ks = 3.2; const Y = 1.7;
    r.bone('root', null, [0, Y, 0]); r.meta.H = Y; r.meta.stride = 3; r.meta.hipY = Y;
    // columna delantera (cuerpo → cuello)
    const fw = [], fr = []; const nF = 10; for (let i = 0; i < nF; i++) { const t = i / (nF - 1); fw.push([0, Y + Math.sin(t * 1.4) * 0.15 + t * t * 0.9, 0.35 + t * 2.7]); fr.push(lerp(0.26, 0.17, Math.pow(t, 1.2))); }
    const sn = r.chain('sp', 'root', fw, fr, 0.12); r.roles.spine = sn.slice(0, 7); r.roles.neck = sn.slice(7);
    r.cone('root', [0, Y, -0.4], [0, Y, 0.35], 0.29, 0.26, 0.15);
    // cola
    const bw = [], br = []; const nB = 12; for (let i = 0; i < nB; i++) { const t = i / (nB - 1); bw.push([0, Y - t * 0.2 + Math.sin(t * 3) * 0.1, -0.45 - t * 4.2]); br.push(lerp(0.27, 0.03, Math.pow(t, 0.9))); }
    const tl = r.chain('tl', 'root', bw, br, 0.12); r.roles.tails = tl;
    // cabeza (en la última vértebra del cuello)
    const hp = fw[nF - 1], hb = add(hp, [0, 0.05, 0.25]); r.bone('head', sn[nF - 1], hb); r.bone('jaw', 'head', add(hb, [0, -0.12, 0.2]));
    r.roles.head = 'head'; r.roles.jaw = 'jaw'; r.roles.root = 'root';
    r.ell('head', add(hb, [0, 0.03, 0.2]), [0.17, 0.15, 0.3], 0.08);
    r.cone('head', add(hb, [0, 0.0, 0.35]), add(hb, [0, -0.05, 0.78]), 0.13, 0.095, 0.05, { sc: [1.1, 0.85, 1] });
    r.cone('jaw', add(hb, [0, -0.1, 0.25]), add(hb, [0, -0.17, 0.72]), 0.08, 0.055, 0.03);
    for (const sx of [-1, 1]) { r.ell('head', add(hb, [sx * 0.11, 0.13, 0.3]), [0.06, 0.04, 0.1], 0.05); r.ell('head', add(hb, [sx * 0.07, -0.0, 0.78]), [0.04, 0.03, 0.04], 0.02);
      eye(r, 'head', add(hb, [sx * 0.15, 0.12, 0.36]), 0.07, true);
      const b0 = add(hb, [sx * 0.07, 0.17, 0.12]); horn(r, 'head', bez(b0, add(b0, [sx * 0.05, 0.25, -0.12]), add(b0, [sx * 0.12, 0.45, -0.38]), add(b0, [sx * 0.1, 0.55, -0.7]), 10), 0.04, 0.006);
      // bigotes largos
      for (let k = 0; k < 2; k++) { const s0 = add(hb, [sx * 0.07, -0.02 - k * 0.05, 0.74]); ribbon(r, strand(s0, [sx * 0.5, -0.15 + k * 0.1, -0.3], 1.8, 0.5 + k * 0.2, 12), 0.016, 0.004, [0.95, 0.85, 0.4], [0.9, 0.75, 0.3], { up: [0, 1, 0] }); }
      // colmillo
      r.rigid.push({ bone: 'head', mat: 'horn', geo: sweep([add(hb, [sx * 0.045, -0.06, 0.62]), add(hb, [sx * 0.05, -0.15, 0.66]), add(hb, [sx * 0.05, -0.23, 0.68])], [0.012, 0.008, 0.001], 5) });
    }
    // melena dorsal: cinta desde la nuca hasta la cola
    for (let i = 1; i < nF; i++) { const b = fw[i]; for (let k = 0; k < 2; k++) ribbon(r, strand(add(b, [0, fr[i] * 0.9, 0]), [(rnd() - 0.5) * 0.3, 0.6, -0.8], 0.7 + rnd() * 0.25, 0.6, 6), 0.1, 0.02, [1.0, 0.82, 0.3], [0.9, 0.5, 0.15], { kind: 'sheet', up: [1, 0, 0] }); }
    for (let i = 0; i < nB; i += 2) { const b = bw[i]; ribbon(r, strand(add(b, [0, br[i] * 0.85, 0]), [0, 0.6, -0.8], 0.45, 0.5, 5), 0.07, 0.015, [1.0, 0.82, 0.3], [0.9, 0.5, 0.15], { up: [1, 0, 0] }); }
    ribbon(r, strand(bw[nB - 1], [0, 0.2, -1], 1.0, 0.1, 8), 0.28, 0.02, [0.2, 0.7, 0.55], [1, 0.8, 0.3], { up: [1, 0, 0] });
    // 4 patas con garras (cortas)
    const legs = {}; [['FL', 1, 2], ['FR', -1, 2], ['HL', 1, -0.3], ['HR', -1, -0.3]].forEach(([key, sx, zz]) => { const parent = key[0] === 'F' ? sn[3] : 'root'; const z0 = key[0] === 'F' ? fw[3][2] : -0.2; const y0 = Y - 0.12; const x0 = sx * 0.22;
      const pts = [[x0, y0, z0], [x0 + sx * 0.12, y0 - 0.32, z0 + 0.04], [x0 + sx * 0.1, y0 - 0.5, z0 + 0.2], [x0 + sx * 0.1, y0 - 0.62, z0 + 0.3]]; const nm = leg3(r, key, parent, pts, [0.09, 0.065, 0.05, 0.04]); legs[key] = nm;
      for (let c = -1; c <= 1; c++) r.rigid.push({ bone: nm[3], mat: 'horn', geo: sweep([[pts[3][0] + c * 0.03, pts[3][1], pts[3][2] + 0.03], [pts[3][0] + c * 0.04, pts[3][1] - 0.04, pts[3][2] + 0.09], [pts[3][0] + c * 0.04, pts[3][1] - 0.1, pts[3][2] + 0.11]], [0.016, 0.009, 0.002], 5) }); });
    r.roles.legs = legs; r.meta.nt = hb; r.meta.hR = 0.15; r.meta.hL = 0.6; r.meta.L = 6; return r;
  },
  paint(c) { const n = noiseCol(c, 12, 0.2); const sc = fbm(c.x * 18, c.y * 18, c.z * 18, 2); let col = mix3([0.96, 0.84, 0.45], [0.1, 0.52, 0.4], smooth(-0.75, 0.15, c.ny)); col = mix3(col, [0.05, 0.28, 0.35], smooth(0.5, 0.9, sc) * 0.5 * smooth(-0.2, 0.5, c.ny)); if (c.bone.startsWith('tl')) { const i = parseInt(c.bone.slice(2)); col = mix3(col, [0.1, 0.35, 0.5], i / 14 * 0.6); }
    if (c.bone === 'head' || c.bone === 'jaw') col = mix3(col, [0.88, 0.7, 0.3], 0.35); if (/^[FH][LR]_/.test(c.bone)) col = mix3(col, [0.85, 0.65, 0.25], 0.5); return [col[0] * n, col[1] * n, col[2] * n]; } };

// ---------- Basilisco ----------
SP.basilisco = { id: 'basilisco', name: 'Basilisco', cat: 'monstruos', rank: 'epico', int: 6, pow: 8, spd: 5, hab: 'Cuevas y pantanos', diet: 'Carnívoro', move: 'ground', cell: 0.02, size: 1.3,
  desc: 'Rey de las serpientes con cresta de gallo y patas de lagarto. Su mirada paraliza; acecha entre ruinas húmedas.',
  habits: { wander: 3, rest: 4, idle: 3, sing: 1 }, social: 'wary', sound: 'hiss', eyeColor: 0xffe030, hornColor: 0xcdbf90,
  style: { detail: 'scales', dscale: 9, dstr: 1.1, rough: 0.5 },
  build() { const r = quadruped({ id: 'basilisco', L: 1.5, H: 0.5, rv: 0.19, rw: 0.17, neckL: 0.34, neckUp: 0.1, neckR: 0.8, headL: 0.36, headR: 0.12, snout: 0.16, snoutR: 0.08, snoutW: 1.15, snoutH: 0.8, lt: 0.055, digi: 0.15, earLen: 0.0001, earW: 0.0001, claws: true, belly: true, tail: { n: 9, len: 1.5, r: 0.1, droop: 0.12, curl: 0.04, bush: 0 }, eyeZ: 0.34, eyeR: 0.2, slit: true }); const m = r.meta, nt = m.nt;
    // cresta
    for (let i = 0; i < 9; i++) { const b = add(nt, [0, 0.1 - i * 0.012, 0.02 - i * 0.04]); ribbon(r, strand(add(b, [0, 0.05, 0]), [0, 1, -0.5 - i * 0.08], 0.2 - i * 0.012, 0.3, 4), 0.045, 0.01, [0.95, 0.2, 0.12], [0.6, 0.05, 0.05], { kind: 'sheet', up: [1, 0, 0] }); }
    for (let i = 0; i < 12; i++) { const z = lerp(m.L * 0.3, -m.L * 0.5, i / 11); ribbon(r, strand([0, m.yc + m.rv * 0.9, z], [0, 1, -0.3], 0.12, 0.2, 3), 0.03, 0.006, [0.35, 0.5, 0.2], [0.2, 0.3, 0.1], { up: [1, 0, 0] }); }
    return r; },
  paint(c) { const n = noiseCol(c, 25, 0.25); const sc = fbm(c.x * 30, c.y * 30, c.z * 30, 2); let col = mix3([0.78, 0.7, 0.4], [0.22, 0.32, 0.12], smooth(-0.5, 0.3, c.ny)); col = mix3(col, [0.1, 0.12, 0.06], smooth(0.5, 0.8, sc) * 0.5 * smooth(-0.1, 0.5, c.ny)); if (c.bone === 'jaw') col = [0.82, 0.74, 0.45]; return [col[0] * n, col[1] * n, col[2] * n]; } };

// ---------- Kraken ----------
SP.kraken = { id: 'kraken', kind: 'kraken', name: 'Kraken Abisal', cat: 'monstruos', rank: 'legendario', int: 7, pow: 10, spd: 6, hab: 'Océano profundo', diet: 'Carnívoro', move: 'water', cell: 0.06, size: 7,
  desc: 'Coloso de ocho tentáculos que duerme bajo las olas. Los marineros juran que hunde flotas enteras.',
  habits: { wander: 3, rest: 3, idle: 2 }, social: 'ignore', sound: 'rumble', eyeColor: 0xffc040,
  style: { detail: 'scales', dscale: 5, dstr: 0.5, rough: 0.3, metal: 0.1, emissive: 0x6020a0, emissiveI: 0.04 },
  build() { const r = new Rig('kraken'); r.ks = 3; const Y = 2.2; r.bone('root', null, [0, Y, 0]); r.bone('mantle', 'root', [0, Y + 0.7, -0.7]); r.roles.spine = ['mantle']; r.roles.root = 'root'; r.meta.H = Y; r.meta.hipY = Y; r.meta.stride = 3;
    r.ell('mantle', [0, Y + 1.2, -1.3], [0.9, 0.95, 1.7], 0.3, { sc: [1, 1, 1] }); r.ell('root', [0, Y, 0.2], [1.1, 0.9, 1.0], 0.4);
    r.bone('head', 'root', [0, Y, 0.9]); r.roles.head = 'head'; r.roles.neck = [];
    for (const sx of [-1, 1]) { r.ell('head', [sx * 0.75, Y + 0.25, 0.9], [0.32, 0.32, 0.32], 0.1); eye(r, 'head', [sx * 0.95, Y + 0.3, 1.0], 0.2, true); r.ell('head', [sx * 0.9, Y + 0.5, 0.95], [0.3, 0.12, 0.3], 0.1); }
    r.roles.tentacles = []; const N = 8;
    for (let i = 0; i < N; i++) { const a = i / N * Math.PI * 2 + 0.3; const ca = Math.cos(a), sa = Math.sin(a); const long = (i % 2 === 0) ? 1.25 : 0.9; const pts = [], rad = []; const n = 8; let p = [ca * 0.7, Y - 0.35, sa * 0.6 + 0.2];
      for (let j = 0; j < n; j++) { pts.push(p.slice()); const t = j / n; p = [p[0] + ca * 0.75 * long * (1 - t * 0.4), p[1] - 0.55 * (j < 2 ? 1 : 0.3 + 0.4 * Math.sin(t * 5)) , p[2] + sa * 0.75 * long * (1 - t * 0.4)]; p[1] = Math.max(p[1], 0.15); rad.push(0.36 * Math.pow(1 - j / (n + 1), 1.3) + 0.03); }
      r.roles.tentacles.push(r.chain('t' + i + '_', 'root', pts, rad, 0.2)); }
    r.meta.L = 5; return r; },
  paint(c) { const n = noiseCol(c, 10, 0.3); const sp = fbm(c.x * 14, c.y * 14, c.z * 14, 2); let col = mix3([0.55, 0.38, 0.45], [0.22, 0.08, 0.28], smooth(-0.6, 0.7, c.ny)); col = mix3(col, [0.88, 0.7, 0.72], smooth(0.62, 0.7, sp) * 0.4); if (c.bone[0] === 't') col = mix3(col, [0.9, 0.75, 0.8], smooth(0.4, -0.7, c.ny) * 0.7); return [col[0] * n, col[1] * n, col[2] * n]; } };

// ---------- Golem de piedra ----------
function humanoid(r, P) { // r: Rig; P: {H, sw (hombros), hw (cadera), th (torso grosor), arm, leg}
  const H = P.H, hipY = H * 0.5; r.bone('root', null, [0, hipY, 0]); r.bone('spine1', 'root', [0, hipY + H * 0.12, 0]); r.bone('spine2', 'spine1', [0, hipY + H * 0.28, 0]); r.bone('neck1', 'spine2', [0, H * 0.88, P.neckZ || 0.02]); r.bone('head', 'neck1', [0, H * 0.94, P.neckZ || 0.03]); r.bone('jaw', 'head', [0, H * 0.96, (P.headR || 0.2) * 0.6]);
  r.roles.root = 'root'; r.roles.spine = ['spine1', 'spine2']; r.roles.neck = ['neck1']; r.roles.head = 'head'; r.roles.jaw = 'jaw'; r.meta.H = H; r.meta.hipY = hipY; r.meta.stride = H * 0.7;
  r.roles.legs = {}; r.roles.arms = {};
  for (const [side, sx] of [['L', 1], ['R', -1]]) {
    const hx = sx * P.hw, lp = [[hx, hipY, 0], [hx, hipY * 0.5, 0.04], [hx, 0.12 * H, 0], [hx, 0.02, 0.16 * H]], lr = P.leg;
    const ln = r.chain('leg' + side + '_', 'root', lp, [lr * 1.2, lr, lr * 0.85, lr * 0.9], P.k || 0.08); r.roles.legs[side] = ln; r.ell(ln[3], [hx, 0.06 * H, 0.1 * H], [lr * 1.25, 0.07 * H, 0.18 * H], 0.05);
    const sxp = sx * P.sw, ap = [[sxp, H * 0.8, 0], [sxp * 1.15, H * 0.55, 0.04], [sxp * 1.2, H * 0.32, 0.1 * H], [sxp * 1.2, H * 0.2, 0.14 * H]]; const ar = P.arm;
    const an = r.chain('arm' + side + '_', 'spine2', ap, [ar * 1.15, ar, ar * 0.9, ar * 1.3], P.k || 0.08); r.roles.arms[side] = an; r.ell(an[3], ap[3], [ar * 1.4, ar * 1.5, ar * 1.2], 0.05);
    r.ell('spine2', [sxp * 0.95, H * 0.82, 0], [ar * 1.8, ar * 1.5, ar * 1.6], 0.1);
  }
  return r;
}
SP.golem = { id: 'golem', kind: 'biped', name: 'Golem de Piedra', cat: 'monstruos', rank: 'raro', int: 3, pow: 9, spd: 2, hab: 'Ruinas y montañas', diet: 'Ninguna (animado por runas)', move: 'ground', cell: 0.05, size: 4,
  desc: 'Guardián tallado en roca viva. Camina con pasos pesados, vigila las ruinas y se queda inmóvil durante siglos.',
  habits: { wander: 2, rest: 4, idle: 4 }, social: 'ignore', sound: 'rumble', eyeColor: 0x60ffd0,
  style: { detail: 'rock', dscale: 3, dstr: 1.6, rough: 0.95, emissive: 0x20ffc0, emissiveI: 0.02 },
  build() { const r = new Rig('golem'); r.ks = 0.8; const H = 3.6; humanoid(r, { H, sw: 1.5, hw: 0.5, leg: 0.38, arm: 0.3, neckZ: 0.1, headR: 0.3, k: 0.1 });
    r.ell('root', [0, H * 0.5, 0], [0.7, 0.4, 0.5], 0.3); r.ell('spine1', [0, H * 0.62, 0], [0.8, 0.45, 0.55], 0.25); r.ell('spine2', [0, H * 0.78, 0.0], [1.0, 0.55, 0.62], 0.3); r.ell('spine2', [0, H * 0.7, -0.15], [0.7, 0.6, 0.55], 0.3);
    r.ell('head', [0, H * 0.98, 0.1], [0.34, 0.3, 0.34], 0.15); r.ell('head', [0, H * 0.93, 0.35], [0.2, 0.15, 0.12], 0.1);
    for (const sx of [-1, 1]) { eye(r, 'head', [sx * 0.14, H * 1.0, 0.36], 0.09, false); r.ell('spine2', [sx * 1.05, H * 0.9, 0], [0.38, 0.28, 0.4], 0.2); r.ell('spine2', [sx * 0.5, H * 0.95, -0.2], [0.25, 0.3, 0.3], 0.15); }
    return r; },
  paint(c) { const n = noiseCol(c, 8, 0.45); const cr = fbm(c.x * 20, c.y * 20, c.z * 20, 3); let col = mix3([0.34, 0.33, 0.32], [0.55, 0.52, 0.48], cr); col = mix3(col, [0.25, 0.4, 0.15], smooth(0.35, 0.9, c.ny) * smooth(0.45, 0.7, fbm(c.x * 6, c.y * 6, c.z * 6, 3)) * 0.8); const rune = smooth(0.78, 0.8, fbm(c.x * 12, c.y * 12, c.z * 12, 2)) * smooth(0.1, 0.5, c.ny); col = mix3(col, [0.2, 0.9, 0.7], rune * 0.9); return [col[0] * n, col[1] * n, col[2] * n]; } };

// ---------- Ent / Espíritu del bosque ----------
SP.ent = { id: 'ent', kind: 'biped', name: 'Ent Ancestral', cat: 'monstruos', rank: 'legendario', int: 9, pow: 8, spd: 2, hab: 'Bosque antiguo', diet: 'Luz y lluvia', move: 'ground', cell: 0.05, size: 5,
  desc: 'Árbol que camina. Habla en siglos, protege el bosque y apenas se mueve; muchos viajeros lo confunden con un roble.',
  habits: { wander: 2, rest: 4, idle: 4, sing: 2 }, social: 'curious', sound: 'groan', eyeColor: 0xffc040,
  style: { detail: 'bark', dscale: 3, dstr: 1.5, rough: 0.95 },
  build() { const r = new Rig('ent'); r.ks = 0.8; const H = 4.6; humanoid(r, { H, sw: 0.95, hw: 0.42, leg: 0.3, arm: 0.2, neckZ: 0.12, headR: 0.3, k: 0.1 });
    r.cone('root', [0, H * 0.3, 0], [0, H * 0.62, 0], 0.5, 0.45, 0.3); r.cone('spine1', [0, H * 0.55, 0], [0, H * 0.82, 0.02], 0.45, 0.5, 0.3); r.ell('spine2', [0, H * 0.82, 0.02], [0.65, 0.4, 0.5], 0.25);
    r.ell('head', [0, H * 0.99, 0.12], [0.34, 0.4, 0.3], 0.12); r.cone('head', [0, H * 0.96, 0.35], [0, H * 0.92, 0.55], 0.1, 0.06, 0.05);
    for (const sx of [-1, 1]) { r.ell('head', [sx * 0.2, H * 1.04, 0.38], [0.12, 0.06, 0.1], 0.04); eye(r, 'head', [sx * 0.17, H * 1.0, 0.4], 0.085, false);
      for (let b = 0; b < 3; b++) { const a0 = [sx * 0.55, H * 0.88 + b * 0.1, -0.1]; const br = bez(a0, add(a0, [sx * 0.4, 0.5, -0.1]), add(a0, [sx * 0.7, 0.9 + b * 0.2, 0.0]), add(a0, [sx * 0.9, 1.5 + b * 0.3, 0.1]), 8); r.rigid.push({ bone: 'spine2', mat: 'horn', geo: sweep(br, taper(9, 0.1 - b * 0.02, 0.01, 1), 7) }); }
    }
    // hojas: copa
    const leaf = (base, dir, len, w, g) => r.decor.push({ type: 'feather', kind: 'feather', base, dir, len, w, bend: 0.2, cf: tt => mix3([0.18 + g * 0.2, 0.45 + g * 0.2, 0.1], [0.5 + g * 0.2, 0.7, 0.2], tt) });
    for (let i = 0; i < 90; i++) { const a = rnd() * Math.PI * 2, e = 0.3 + rnd() * 1.1; const rr = 0.2 + rnd() * 0.5; const b = [Math.cos(a) * rr, H * 1.05 + Math.sin(e) * 0.5 + rnd() * 0.3, Math.sin(a) * rr - 0.1]; leaf(b, [Math.cos(a) * Math.cos(e), Math.sin(e) + 0.2, Math.sin(a) * Math.cos(e)], 0.5 + rnd() * 0.4, 0.2, rnd()); }
    for (const sx of [-1, 1]) for (let i = 0; i < 18; i++) { const t = rnd(); const b = [sx * (0.6 + t * 0.8), H * 0.9 + t * 1.2, -0.05 + rnd() * 0.2]; leaf(b, [sx * 0.6, 0.5, (rnd() - 0.5)], 0.35 + rnd() * 0.3, 0.16, rnd()); }
    return r; },
  paint(c) { const n = noiseCol(c, 10, 0.35); const gr = fbm(c.x * 4, c.y * 30, c.z * 4, 3); let col = mix3([0.2, 0.13, 0.08], [0.4, 0.28, 0.16], gr); col = mix3(col, [0.22, 0.38, 0.12], smooth(0.2, 0.85, c.ny) * smooth(0.4, 0.62, fbm(c.x * 7, c.y * 7, c.z * 7, 3)) * 0.75); return [col[0] * n, col[1] * n, col[2] * n]; } };

// ---------- Tortuga celestial ----------
SP.tortuga = { id: 'tortuga', kind: 'turtle', name: 'Tortuga Celestial (玄武)', cat: 'leyendas', rank: 'mitico', int: 10, pow: 7, spd: 1, hab: 'Lagos sagrados y cielos', diet: 'Rocío', move: 'ground', cell: 0.045, size: 4,
  desc: 'Guardiana del norte con un caparazón que lleva el cielo estrellado. Camina siglo a siglo y flota cuando duerme.',
  habits: { wander: 2, rest: 5, idle: 3, sing: 2 }, social: 'curious', sound: 'chime', eyeColor: 0xffd060, hornColor: 0xd8c890,
  style: { detail: 'scales', dscale: 4, dstr: 0.9, rough: 0.5, emissive: 0x4090ff, emissiveI: 0.03 },
  build() { const r = new Rig('tortuga'); r.ks = 2.2; const Y = 1.0; r.bone('root', null, [0, Y, 0]); r.roles.root = 'root'; r.meta.H = Y; r.meta.hipY = Y; r.meta.stride = 2;
    r.ell('root', [0, Y + 0.7, 0], [1.6, 0.85, 2.0], 0.15); r.ell('root', [0, Y + 0.05, 0], [1.5, 0.28, 1.9], 0.1); r.ell('root', [0, Y + 1.35, -0.1], [0.9, 0.3, 1.1], 0.2);
    r.roles.legs = {}; [['FL', 1, 1.2], ['FR', -1, 1.2], ['HL', 1, -1.2], ['HR', -1, -1.2]].forEach(([k, sx, z]) => { const x = sx * 1.1; const pts = [[x, Y + 0.1, z], [x + sx * 0.35, Y - 0.25, z + 0.2], [x + sx * 0.4, 0.15, z + 0.35]]; const n = r.chain(k + '_', 'root', pts, [0.4, 0.3, 0.3], 0.1); r.roles.legs[k] = n; r.ell(n[2], [pts[2][0], 0.1, pts[2][2] + 0.1], [0.34, 0.12, 0.42], 0.06); for (let c = -1; c <= 1; c++) r.rigid.push({ bone: n[2], mat: 'horn', geo: sweep([[pts[2][0] + c * 0.14, 0.08, pts[2][2] + 0.4], [pts[2][0] + c * 0.15, 0.06, pts[2][2] + 0.55]], [0.05, 0.005], 5) }); });
    const np = [[0, Y + 0.45, 1.6], [0, Y + 0.65, 2.3], [0, Y + 0.85, 2.9]]; const nn = r.chain('neck', 'root', np, [0.34, 0.28, 0.24], 0.1); r.roles.neck = nn.slice(0, 2); r.bone('head', nn[2], add(np[2], [0, 0.0, 0.2])); r.bone('jaw', 'head', add(np[2], [0, -0.12, 0.4])); r.roles.head = 'head'; r.roles.jaw = 'jaw';
    const hb = add(np[2], [0, 0, 0.2]); r.ell('head', add(hb, [0, 0.05, 0.2]), [0.26, 0.22, 0.34], 0.08); r.cone('head', add(hb, [0, 0, 0.35]), add(hb, [0, -0.05, 0.62]), 0.17, 0.12, 0.05); r.cone('jaw', add(hb, [0, -0.1, 0.32]), add(hb, [0, -0.13, 0.6]), 0.1, 0.08, 0.03);
    for (const sx of [-1, 1]) { eye(r, 'head', add(hb, [sx * 0.22, 0.12, 0.38]), 0.09, false); r.ell('head', add(hb, [sx * 0.2, 0.2, 0.34]), [0.1, 0.05, 0.12], 0.04); const b0 = add(hb, [sx * 0.12, 0.2, 0.05]); horn(r, 'head', bez(b0, add(b0, [sx * 0.05, 0.25, -0.1]), add(b0, [sx * 0.1, 0.4, -0.3]), add(b0, [sx * 0.08, 0.5, -0.55]), 8), 0.05, 0.008); ribbon(r, strand(add(hb, [sx * 0.1, -0.05, 0.6]), [sx * 0.5, -0.1, -0.4], 1.2, 0.3, 8), 0.02, 0.005, [0.9, 0.85, 0.5], [0.8, 0.7, 0.3], { up: [0, 1, 0] }); }
    const tp = [[0, Y + 0.2, -1.9], [0, Y + 0.1, -2.5], [0, Y - 0.05, -3.1]]; r.roles.tails = r.chain('tl', 'root', tp, [0.18, 0.12, 0.05], 0.06);
    // serpiente de cola (Xuanwu): cinta
    ribbon(r, strand([0, Y + 0.05, -3.0], [0, 0.4, -1], 1.5, -0.2, 8), 0.12, 0.02, [0.3, 0.6, 0.55], [0.9, 0.8, 0.4], { up: [1, 0, 0] });
    r.meta.L = 4.4; r.meta.nt = hb; r.meta.hR = 0.25; r.meta.hL = 0.6; return r; },
  paint(c) { const n = noiseCol(c, 10, 0.25); let col = [0.25, 0.4, 0.3];
    if (c.ny > 0.25 && c.y > 1.35) { const gx = c.x * 2.4, gz = c.z * 2.4; const hx = Math.abs(Math.sin(gx * 2.1) * Math.sin(gz * 1.2 + gx * 1.1) * Math.sin(gz * 1.2 - gx * 1.1 + 0.8)); const line = smooth(0.2, 0.0, hx); col = mix3([0.2, 0.34, 0.28], [0.15, 0.22, 0.4], fbm(c.x * 3, c.y * 3, c.z * 3, 3)); col = mix3(col, [0.95, 0.8, 0.35], line * 0.9); }
    else if (c.y < 1.15) col = [0.75, 0.68, 0.45]; else col = mix3([0.3, 0.38, 0.28], [0.4, 0.34, 0.2], fbm(c.x * 4, c.y * 4, c.z * 4, 2)); if (c.bone === 'head' || c.bone === 'jaw' || c.bone.startsWith('neck')) col = mix3(col, [0.4, 0.45, 0.25], 0.5); return [col[0] * n, col[1] * n, col[2] * n]; } };

return {};
}

