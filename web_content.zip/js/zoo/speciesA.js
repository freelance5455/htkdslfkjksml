// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 5588-5722 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_SPECIES_A(Z, SP) {
const { THREE, V3, clamp, lerp, smooth, mix3, fbm, Rig, sweep, bez, taper } = Z;
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const M = (a) => [-a[0], a[1], a[2]];
const V = (x, y, z) => [x, y, z];

// ---- cuadrúpedo genérico ----
function quadruped(P) {
  const r = new Rig(P.id); const S = P.S || 1; const L = P.L * S, H = P.H * S, rv = P.rv * S, rw = P.rw * S, lt = P.lt * S;
  r.ks = clamp(P.L / 0.8, 0.3, 2.5) * (P.ksm || 1); const yc = H - rv * 0.55; r.meta.L = L; r.meta.H = H; r.meta.hipY = yc; r.meta.stride = P.stride || H * 1.1;
  const pel = [0, yc - rv * 0.05, -L * 0.5], sp1 = [0, yc + rv * 0.05, -L * 0.1], sp2 = [0, yc + rv * 0.08, L * 0.33];
  r.bone('pelvis', null, pel); r.bone('spine1', 'pelvis', sp1); r.bone('spine2', 'spine1', sp2);
  const nb = [0, yc + rv * 0.5, L * 0.5 + rv * 0.1], nt = add(nb, [0, P.neckUp * S, P.neckL * S]), nm = add(nb, [0, P.neckUp * S * 0.5 + rv * 0.05, P.neckL * S * 0.5]);
  r.bone('neck1', 'spine2', nb); r.bone('neck2', 'neck1', nm); r.bone('head', 'neck2', nt);
  const hR = P.headR * S, hL = P.headL * S, sn = P.snout * S, sR = P.snoutR * S;
  r.bone('jaw', 'head', add(nt, [0, -hR * 0.6, hL * 0.25]));
  // torso
  r.ell('pelvis', [0, yc, -L * 0.5 + L * 0.02], [rw * 0.95, rv * 0.95, L * 0.26], 0.1);
  r.cone('spine1', [0, yc + rv * 0.05, -L * 0.28], [0, yc + rv * 0.0, L * 0.12], rv * 0.78, rv * 0.9, 0.12, { sc: [rw / rv * 0.95, 1, 1] });
  r.ell('spine2', [0, yc - rv * 0.14, L * 0.5 - L * 0.1], [rw * 1.04, rv * 1.2, L * 0.27], 0.1);
  r.ell('spine2', [0, yc + rv * 0.35, L * 0.5 - L * 0.2], [rw * 0.8, rv * 0.55, L * 0.16], 0.12); // cruz/hombros
  if (P.belly) r.ell('spine1', [0, yc - rv * 0.55, -L * 0.08], [rw * 0.7, rv * 0.5, L * 0.22], 0.15);
  // cuello y cabeza
  const nr0 = rv * (P.neckR || 0.6), nr1 = hR * 0.95;
  r.cone('neck1', nb, nm, nr0, (nr0 + nr1) * 0.5, 0.1, { sc: [0.92, 1, 1] }); r.cone('neck2', nm, nt, (nr0 + nr1) * 0.5, nr1, 0.08);
  r.ell('head', add(nt, [0, hR * 0.05, hL * 0.22]), [hR, hR * 1.0, hL * 0.5], 0.05);
  const sn0 = add(nt, [0, -hR * 0.05, hL * 0.5]), sn1 = add(nt, [0, -hR * 0.28, hL * 0.5 + sn]);
  r.cone('head', sn0, sn1, sR, sR * (P.snoutTaper || 0.72), 0.04, { sc: [P.snoutW || 1, P.snoutH || 0.9, 1] });
  if (P.cheek) for (const sx of [-1, 1]) r.ell('head', add(nt, [sx * hR * 0.72, -hR * 0.35, hL * 0.18]), [hR * 0.42, hR * 0.5, hL * 0.3], 0.05);
  for (const sx of [-1, 1]) r.ell('head', add(nt, [sx * hR * 0.5, hR * 0.38, hL * 0.34]), [hR * 0.32, hR * 0.22, hL * 0.18], 0.05); // arco de las cejas
  r.cone('jaw', add(nt, [0, -hR * 0.62, hL * 0.3]), add(sn1, [0, -sR * 0.55, -sn * 0.08]), sR * 0.55, sR * 0.42, 0.012);
  r.sub('head', 'rc', [add(nt, [0, -hR * 0.46, hL * 0.18]), add(sn1, [0, -sR * 0.22, -sn * 0.05]), sR * 0.07, sR * 0.07], 0.01);
  r.ell('head', add(sn1, [0, sR * 0.2, sn * 0.02]), [sR * 0.55, sR * 0.38, sR * 0.5], 0.03); // nariz
  r.rigid.push({ bone: 'head', obj: () => { const m = new THREE.Mesh(new THREE.SphereGeometry(sR * 0.42, 12, 8), new THREE.MeshStandardMaterial({ color: 0x0b0909, roughness: 0.3 })); m.scale.set(1.15, 0.8, 0.8); m.position.set(sn1[0], sn1[1] + sR * 0.22, sn1[2] + sR * 0.28); return m; } });
  for (const sx of [-1, 1]) {
    r.rigid.push({ bone: 'head', eye: { r: hR * (P.eyeR || 0.2) * 1.35, slit: !!P.slit }, at: add(nt, [sx * hR * 0.78, hR * 0.28, hL * (P.eyeZ || 0.32)]) });
  }
  // orejas
  for (const sx of [-1, 1]) {
    const nm2 = sx < 0 ? 'earL' : 'earR'; const e0 = add(nt, [sx * hR * 0.5, hR * 0.72, hL * 0.05]); const e1 = add(e0, [sx * P.earLen * S * (P.earOut || 0.3), P.earLen * S * 0.95, -P.earLen * S * 0.12]);
    r.bone(nm2, 'head', e0); r.cone(nm2, e0, e1, P.earW * S, P.earW * S * (P.earTip || 0.14), 0.02, { sc: [0.38, 1, 1] }); r.roles.ears.push(nm2);
  }
  // patas
  const legs = { FL: null, FR: null, HL: null, HR: null };
  for (const sx of [-1, 1]) for (const front of [true, false]) {
    const key = (front ? 'F' : 'H') + (sx < 0 ? 'L' : 'R'); const x0 = sx * rw * 0.72; let pts, par;
    if (front) { const sz = L * 0.5 - L * 0.1; par = 'spine2'; pts = [[x0, yc - rv * 0.12, sz], [x0 * 0.96, H * 0.5, sz - 0.01 * S], [x0 * 0.94, H * 0.2, sz + 0.02 * S], [x0 * 0.94, 0.04 * S, sz + 0.05 * S]]; }
    else { const hz = -L * 0.5 + L * 0.06, d = P.digi === undefined ? 1 : P.digi; par = 'pelvis'; pts = [[x0, yc - rv * 0.05, hz], [x0 * 0.98, H * 0.5, hz + d * L * 0.12], [x0 * 0.95, H * 0.24, hz - d * L * 0.1], [x0 * 0.95, 0.04 * S, hz - d * L * 0.04 + 0.0]]; }
    const rad = front ? [lt * 1.6, lt * 1.05, lt * 0.68, lt * 0.62] : [lt * 2.0, lt * 1.15, lt * 0.66, lt * 0.6];
    const names = r.chain(key + '_', par, pts, rad, 0.11); // _1.._4
    legs[key] = names;
    r.ell(names[3], [pts[3][0], 0.022 * S, pts[3][2] + 0.035 * S], [lt * (P.hoof ? 0.62 : 0.8), 0.025 * S, lt * (P.hoof ? 1.0 : 1.5)], 0.03);
    if (!front) r.ell(names[0], [pts[0][0], pts[0][1] - rv * 0.15, pts[0][2] + 0.01 * S], [rw * 0.42, rv * 0.78, L * 0.16], 0.12);
    else r.ell(names[0], [pts[0][0] * 0.9, pts[0][1] + rv * 0.1, pts[0][2] - L * 0.02], [rw * 0.38, rv * 0.7, L * 0.12], 0.12);
    if (P.claws) { const cn = names[3]; for (let k = -1; k <= 1; k++) r.rigid.push({ bone: cn, mat: 'claw', geo: sweep([[pts[3][0] + k * lt * 0.5, 0.025 * S, pts[3][2] + 0.1 * S], [pts[3][0] + k * lt * 0.55, 0.012 * S, pts[3][2] + 0.14 * S], [pts[3][0] + k * lt * 0.55, 0.0, pts[3][2] + 0.155 * S]], [lt * 0.2, lt * 0.12, lt * 0.03], 5) }); }
  }
  r.roles.legs = legs;
  // cola
  const tn = P.tail ? P.tail.n : 4, tl = P.tail ? P.tail.len * S : 0.4 * S; let pt = [0, yc + rv * 0.25, -L * 0.5 - rv * 0.5]; const tpts = [pt], tr = []; const droop = P.tail ? P.tail.droop : 0.4; let ang = droop;
  for (let i = 0; i < tn; i++) { ang = ang + (P.tail ? P.tail.curl || 0 : 0); pt = [0, pt[1] - Math.sin(ang) * tl / tn, pt[2] - Math.cos(ang) * tl / tn]; tpts.push(pt); }
  const t0 = P.tail ? P.tail.r * S : 0.04 * S, bush = P.tail ? P.tail.bush || 0 : 0;
  for (let i = 0; i <= tn; i++) { const t = i / tn; tr.push(t0 * (1 + bush * Math.sin(Math.PI * Math.pow(t, 0.8))) * (1 - 0.8 * Math.pow(t, P.tail && P.tail.tipPow || 2))); }
  r.roles.tails = r.chain('tail', 'pelvis', tpts, tr, 0.06);
  r.roles.spine = ['pelvis', 'spine1', 'spine2']; r.roles.neck = ['neck1', 'neck2']; r.roles.head = 'head'; r.roles.jaw = 'jaw'; r.roles.root = 'pelvis';
  r.meta.nt = nt; r.meta.hR = hR; r.meta.hL = hL; r.meta.nb = nb; r.meta.rw = rw; r.meta.rv = rv; r.meta.yc = yc; r.meta.lt = lt; r.meta.snout = sn1;
  return r;
}
function antler(r, sx, nt, hR, S, big) {
  const base = add(nt, [sx * hR * 0.45, hR * 0.85, -hR * 0.1]); const k = big * S;
  const beam = bez(base, add(base, [sx * 0.04 * k, 0.16 * k, -0.04 * k]), add(base, [sx * 0.12 * k, 0.3 * k, -0.12 * k]), add(base, [sx * 0.14 * k, 0.46 * k, -0.04 * k]), 10);
  r.rigid.push({ bone: 'head', mat: 'horn', geo: sweep(beam, taper(11, 0.014 * k, 0.004 * k, 1.2), 7) });
  for (let i = 0; i < 3; i++) { const a = beam[3 + i * 2]; const tine = bez(a, add(a, [sx * 0.03 * k, 0.07 * k, 0.04 * k]), add(a, [sx * 0.02 * k, 0.13 * k, 0.1 * k]), add(a, [sx * 0.0, 0.2 * k, 0.12 * k]), 6); r.rigid.push({ bone: 'head', mat: 'horn', geo: sweep(tine, taper(7, 0.0085 * k, 0.0025 * k), 6) }); }
}
function hair(a) { return a; }
const eyeRing = (c, col, dark) => { const m = c.rig.meta; if (!m.nt) return col; const dx = Math.abs(c.x) - m.hR * 0.78, dy = c.y - (m.nt[1] + m.hR * 0.28), dz = c.z - (m.nt[2] + m.hL * 0.32); const d = Math.sqrt(dx * dx + dy * dy + dz * dz); return mix3(col, dark || [0.04, 0.03, 0.03], smooth(m.hR * 0.55, m.hR * 0.2, d) * 0.9); };
const noiseCol = (c, f, a) => 1 + (fbm(c.x * f, c.y * f, c.z * f, 3) - 0.5) * a;

// ---------- Lobo ----------
SP.lobo = {
  id: 'lobo', name: 'Lobo Gris', cat: 'animales', rank: 'comun', int: 6, pow: 4, spd: 7, hab: 'Bosque y colinas', diet: 'Carnívoro', move: 'ground', cell: 0.02, size: 1.0,
  desc: 'Cazador social de pelaje espeso. Aúlla a la luna y recorre su territorio en manada.',
  habits: { wander: 4, rest: 2, sing: 1, idle: 2 }, social: 'wary', sound: 'howl',
  style: { detail: 'fur', dscale: 5, dstr: 1.0, rough: 0.92 },
  build() { return quadruped({ id: 'lobo', L: 0.8, H: 0.86, rv: 0.2, rw: 0.13, neckL: 0.24, neckUp: 0.1, neckR: 0.78, headL: 0.26, headR: 0.1, snout: 0.17, snoutR: 0.058, lt: 0.048, digi: 1, earLen: 0.14, earW: 0.07, earOut: 0.12, belly: true, cheek: true, tail: { n: 5, len: 0.55, r: 0.05, droop: 0.55, curl: -0.04, bush: 0.7 }, eyeZ: 0.34, eyeR: 0.2, slit: false }); },
  eyeColor: 0xe0a030,
  paint(c) {
    const n = noiseCol(c, 22, 0.35), st = fbm(c.x * 90, c.y * 30, c.z * 12, 2); const back = [0.5, 0.47, 0.43], belly = [0.9, 0.86, 0.78]; const t = smooth(-0.55, 0.2, c.ny);
    let col = mix3(belly, back, t); const dark = [0.26, 0.24, 0.22];
    col = mix3(col, dark, smooth(0.55, 0.9, c.ny) * smooth(0.5, 0.9, fbm(c.x * 8, c.y * 8, c.z * 8, 2)) * 0.6);
    if (c.bone[0] === 'F' || c.bone[0] === 'H') { col = mix3(col, [0.52, 0.45, 0.36], 0.4 * (1 - smooth(0.05, 0.5, c.y))); }
    if (c.bone === 'head' || c.bone === 'jaw') { const m = smooth(c.z, c.z + 0.001, 0) ; col = mix3(col, [0.78, 0.73, 0.66], smooth(0.1, -0.5, c.ny) * 0.8 + 0.1); }
    if (c.bone.startsWith('tail')) col = mix3(col, [0.2, 0.19, 0.18], smooth(0.5, 1, st) * 0.5 + 0.2 * (parseInt(c.bone.slice(4)) / 5));
    col = eyeRing(c, col); const k = n * (0.85 + 0.3 * st); return [col[0] * k, col[1] * k, col[2] * k];
  }
};
// ---------- Zorro ----------
SP.zorro = {
  id: 'zorro', name: 'Zorro Rojo', cat: 'animales', rank: 'comun', int: 8, pow: 2, spd: 7, hab: 'Bosque y colinas', diet: 'Omnívoro', move: 'ground', cell: 0.014, size: 0.6,
  desc: 'Astuto y curioso. Se acerca a los viajeros a una distancia prudente y huye si lo asustas.',
  habits: { wander: 4, rest: 2, idle: 3 }, social: 'curious', sound: 'yip',
  style: { detail: 'fur', dscale: 7, dstr: 1.0, rough: 0.92 },
  build() { return quadruped({ id: 'zorro', L: 0.5, H: 0.42, rv: 0.115, rw: 0.08, neckL: 0.14, neckUp: 0.06, neckR: 0.6, headL: 0.14, headR: 0.058, snout: 0.1, snoutR: 0.034, lt: 0.024, digi: 1, earLen: 0.1, earW: 0.04, earOut: 0.15, belly: true, tail: { n: 5, len: 0.42, r: 0.04, droop: 0.2, curl: 0.0, bush: 1.4, tipPow: 3 }, eyeZ: 0.3, slit: true, eyeR: 0.18 }); },
  eyeColor: 0xd89a28,
  paint(c) {
    const n = noiseCol(c, 28, 0.3), st = fbm(c.x * 120, c.y * 40, c.z * 20, 2); const orange = [0.74, 0.30, 0.08], belly = [0.95, 0.92, 0.86], dark = [0.1, 0.08, 0.07];
    let col = mix3(belly, orange, smooth(-0.5, 0.25, c.ny));
    if (/^[FH][LR]_/.test(c.bone)) col = mix3(col, dark, smooth(0.34, 0.1, c.y) * 0.95);
    if (c.bone.startsWith('ear')) col = mix3(col, dark, 0.8);
    if (c.bone === 'jaw') col = belly; if (c.bone === 'head') col = mix3(col, belly, smooth(0.0, -0.6, c.ny) * 0.9);
    if (c.bone.startsWith('tail')) { const i = parseInt(c.bone.slice(4)); col = i >= 5 ? [0.97, 0.95, 0.9] : mix3(col, [0.9, 0.5, 0.2], 0.2); }
    const k = n * (0.88 + 0.25 * st); return [col[0] * k, col[1] * k, col[2] * k];
  }
};
// ---------- Ciervo ----------
SP.ciervo = {
  id: 'ciervo', name: 'Ciervo Rojo', cat: 'animales', rank: 'comun', int: 4, pow: 3, spd: 8, hab: 'Bosque', diet: 'Herbívoro', move: 'ground', cell: 0.016, size: 1.5,
  desc: 'Elegante y tímido. Pasta tranquilo y escapa a gran velocidad ante cualquier peligro.',
  habits: { wander: 4, graze: 4, rest: 2, idle: 2 }, social: 'flee', sound: 'bellow',
  style: { detail: 'fur', dscale: 5, dstr: 0.8, rough: 0.9 },
  build() { const r = quadruped({ id: 'ciervo', L: 0.95, H: 1.18, rv: 0.21, rw: 0.14, neckL: 0.36, neckUp: 0.38, neckR: 0.5, headL: 0.22, headR: 0.07, snout: 0.15, snoutR: 0.04, snoutTaper: 0.8, lt: 0.036, digi: 0.35, hoof: true, earLen: 0.14, earW: 0.055, earOut: 0.55, earTip: 0.3, tail: { n: 2, len: 0.14, r: 0.04, droop: 0.9, bush: 0.1 }, eyeZ: 0.3, eyeR: 0.2 });
    antler(r, 1, r.meta.nt, r.meta.hR, 1.15, 1.3); antler(r, -1, r.meta.nt, r.meta.hR, 1.15, 1.3); return r; },
  eyeColor: 0x2a1a0e,
  paint(c) {
    const n = noiseCol(c, 20, 0.25), st = fbm(c.x * 80, c.y * 30, c.z * 12, 2); const back = [0.50, 0.28, 0.14], belly = [0.82, 0.70, 0.55];
    let col = mix3(belly, back, smooth(-0.6, 0.15, c.ny));
    if (c.bone.startsWith('neck') || c.bone === 'head') col = mix3(col, [0.36, 0.2, 0.1], 0.35);
    if (/^[FH][LR]_/.test(c.bone)) { col = mix3(col, [0.3, 0.2, 0.13], smooth(0.5, 0.2, c.y)); col = mix3(col, [0.08, 0.06, 0.05], smooth(0.07, 0.03, c.y)); }
    if (c.bone === 'jaw' || (c.bone === 'head' && c.ny < -0.3)) col = mix3(col, [0.9, 0.85, 0.75], 0.7);
    if (c.bone.startsWith('tail') || (c.bone === 'pelvis' && c.z < -0.52 && c.ny < 0.6)) col = mix3(col, [0.9, 0.82, 0.68], 0.6);
    const k = n * (0.9 + 0.2 * st); return [col[0] * k, col[1] * k, col[2] * k];
  }
};
return { quadruped, antler };
}

