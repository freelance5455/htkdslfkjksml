// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 6593-7113 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_PHOENIX(Z, SP, A) {
'use strict';
const { THREE, clamp, lerp, smooth, mix3, H3, fbm, Rig, bez, bodyMaterial } = Z;
const V3 = THREE.Vector3;
const rngf = seed => { let s = (Math.imul((seed | 0) + 7, 2654435761) >>> 0) || 1; return () => (s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296; };
const sst = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const lin3 = c => [Math.pow(clamp(c[0], 0, 1), 2.2), Math.pow(clamp(c[1], 0, 1), 2.2), Math.pow(clamp(c[2], 0, 1), 2.2)];
const TIME = { value: 0 };
const tickTime = () => { TIME.value = performance.now() * 0.001; };
const vec3 = c => new V3(c[0], c[1], c[2]);
const vecL = c => { const l = lin3(c); return new V3(l[0], l[1], l[2]); };

// ---------------------------------------------------------------
// ATLAS DE PLUMAS: 4 teselas de 128x512 (u = ancho, v = de la base a la punta)
//  0 vana de pluma de vuelo/cola | 1 filamentos (cabellos luminosos) | 2 pluma con ocelo (ojo de pavo) | 3 cobertera redondeada
//  canales: R = luminancia, G = raquis/núcleo (en tesela 2: interior del ojo), B = borde metálico (en tesela 2: aro dorado), A = alfa
// ---------------------------------------------------------------
const TW = 128, TH = 512, NTILE = 4, PADX = 3;
function tileFil(u, v) {
  const NS = 30; let cov = 0, lum = 0.8, core = 0; const spread = 0.14 + 0.84 * Math.pow(v, 0.75);
  for (let i = 0; i < NS; i++) {
    const f = (i + 0.5) / NS - 0.5; const cx = 0.5 + f * spread + 0.03 * v * Math.sin(v * (4.5 + 4 * H3(i, 1, 21)) + i * 1.9);
    const w = (0.0075 + 0.0035 * H3(i, 2, 21)) * (1 - 0.6 * v); const d = Math.abs(u - cx); const q = 1 - sst(w * 0.5, w * 1.6, d);
    if (q > cov) { cov = q; lum = 0.62 + 0.38 * H3(i, 3, 21); core = q * q; }
  }
  const stem = (1 - sst(0.05, 0.2, v)) * (1 - sst(0.012, 0.03, Math.abs(u - 0.5))); const a = Math.max(cov, stem);
  return [a > 0 ? Math.max(lum, stem) : 0, core, 0, a];
}
function tilePx(tile, u, v) {
  if (tile === 1) return tileFil(u, v);
  const s = Math.abs(u * 2 - 1), cov = tile === 3, oce = tile === 2;
  const NB = cov ? 140 : oce ? 110 : 128, shift = cov ? 0.34 : oce ? 0.05 : 0.07;
  const b = v * NB - s * NB * shift, bi = Math.floor(b), fb = b - bi;
  let lum = 0.8 + 0.2 * Math.cos(fb * 6.2832) + (H3(bi, tile, 5) - 0.5) * 0.14; lum *= 0.92 + 0.12 * s;
  const lim = 1 - 0.03 - (cov ? 0.04 : 0.075) * H3(bi, tile, 9);
  let a = 1 - sst(lim - 0.02, lim + 0.015, s);
  if (!cov) a *= 1 - (oce ? 0.4 : 0.5) * sst(0.62, 0.95, s) * sst(0.45, 0.8, fb);
  if (!cov && !oce) for (let k = 0; k < 3; k++) { const bk = 14 + k * 38 + H3(k, tile, 13) * 14, ds = Math.abs(b - bk), wd = 0.3 + 0.9 * Math.max(0, s - 0.3); if (s > 0.34 && ds < wd) a = 0; }
  if (cov) a *= 1 - sst(0.8, 1.0, Math.sqrt(s * s * 0.85 + Math.pow(Math.max(0, (v - 0.4) / 0.6), 2.4)));
  const rw = 0.03 * (1 - 0.5 * v) + 0.01; let g = 0, bl = 0;
  if (s < rw) { a = 1; lum = 1; g = 1; } else if (s < rw * 2.4) g = 0.35 * (1 - (s - rw) / (rw * 1.4));
  if (cov) bl = Math.max(sst(0.8, 0.97, v), sst(0.78, 0.95, s) * 0.75) * (0.65 + 0.35 * Math.cos(fb * 6.2832));
  if (oce) { // ojo: v central 0.78, elíptico
    const rho = Math.sqrt((s / 0.88) ** 2 + ((v - 0.78) / 0.066) ** 2);
    if (rho < 1) { a = 1; g = 0; bl = 0; if (rho < 0.3) lum = 0.16; else if (rho < 0.62) { g = 1; lum = 0.95; } else if (rho < 0.86) { bl = 1; lum = 1; } else lum = 0.38; }
  }
  return [clamp(lum, 0, 1), g, bl, a];
}
let _atlas = null;
function featherAtlas() {
  if (_atlas) return _atlas;
  const W = TW * NTILE, H = TH, data = new Uint8Array(W * H * 4);
  for (let tile = 0; tile < NTILE; tile++) for (let y = 0; y < TH; y++) {
    const v = (y + 0.5) / TH;
    for (let x = PADX; x < TW - PADX; x++) { const u = (x + 0.5 - PADX) / (TW - 2 * PADX); const o = tilePx(tile, u, v); const i = (y * W + tile * TW + x) * 4; data[i] = o[0] * 255; data[i + 1] = o[1] * 255; data[i + 2] = o[2] * 255; data[i + 3] = o[3] * 255; }
  }
  const t = new THREE.DataTexture(data, W, H, THREE.RGBAFormat); t.magFilter = THREE.LinearFilter; t.minFilter = THREE.LinearMipmapLinearFilter; t.generateMipmaps = true; t.anisotropy = 4; t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; t.needsUpdate = true; _atlas = t; return t;
}

// ---------------------------------------------------------------
// MATERIALES
// ---------------------------------------------------------------
const FEATHER_FRAG_HEAD = 'uniform sampler2D uAtlas; uniform float uTime; uniform vec3 uGlow0; uniform vec3 uGlow1; uniform float uGlowK; uniform vec3 uRim; uniform float uIri; uniform float uIriF; uniform vec3 uEyeA; uniform vec3 uEyeB; uniform float uFil; varying vec4 vCol; varying vec2 vUvF; varying vec4 vFx;\n';
const FEATHER_MAP = `vec4 pxT = texture2D(uAtlas, vUvF);
  float pxFl = vFx.w;
  diffuseColor.rgb = vCol.rgb * mix(0.5, 1.22, pxT.r);
  diffuseColor.a = pxT.a;
  if (pxFl > 1.5) { diffuseColor.a = clamp(pxT.a * 2.4, 0.0, 1.0) * uFil * (1.0 - smoothstep(0.86, 1.0, vFx.z)); }`;
const FEATHER_EMIS = `#include <emissivemap_fragment>
  {
    vec3 pxV = normalize(vViewPosition);
    float pxNV = abs(dot(normal, pxV));
    float pxT0 = vFx.z; float pxG = vCol.a;
    float pxCover = (pxFl < 0.5) ? 1.0 : 0.0;
    vec3 pxI = 0.5 + 0.5 * cos(6.28318 * (vec3(0.0, 0.33, 0.67) + vFx.x + pxNV * uIriF + pxT0 * 0.25));
    float pxIa = clamp(uIri * vFx.y * (0.3 + 0.7 * (1.0 - pxNV)), 0.0, 1.0);
    diffuseColor.rgb = mix(diffuseColor.rgb, pxI * (0.3 + 0.95 * pxT.r), pxIa);
    float pxEdge = pxT.b * pxCover;
    diffuseColor.rgb = mix(diffuseColor.rgb, pxI * 1.1 + vec3(0.1), clamp(pxEdge * (0.08 + vFx.y * 1.3) * uIri, 0.0, 1.0));
    if (pxFl > 0.5 && pxFl < 1.5) {
      vec3 pxE = vCol.rgb * mix(0.5, 1.22, pxT.r);
      pxE = mix(pxE, uEyeB * (0.8 + 0.4 * pxT.r), pxT.g);
      pxE = mix(pxE, uEyeA * (0.9 + 0.3 * pxT.r), pxT.b);
      diffuseColor.rgb = pxE;
      totalEmissiveRadiance += (uEyeB * pxT.g * 0.5 + uEyeA * pxT.b * 0.7) * uGlowK;
    }
    vec3 pxGl = mix(uGlow0, uGlow1, smoothstep(0.0, 1.0, pxT0));
    float pxFk = 0.86 + 0.14 * sin(uTime * 2.6 + vFx.x * 31.0 + pxT0 * 6.0);
    float pxCore = (pxFl > 0.5 && pxFl < 1.5) ? 0.0 : pxT.g;
    totalEmissiveRadiance += pxGl * pxG * (0.5 + 1.0 * pxCore + 0.9 * pxEdge) * uGlowK * pxFk;
    totalEmissiveRadiance += uRim * pow(1.0 - pxNV, 3.0) * (0.25 + pxG);
    totalEmissiveRadiance += diffuseColor.rgb * (gl_FrontFacing ? 0.09 : 0.3);
  }`;
function featherMaterial(P) {
  const m = new THREE.MeshStandardMaterial({ roughness: P.rough === undefined ? 0.5 : P.rough, metalness: P.metal || 0, side: THREE.DoubleSide, alphaTest: 0.45, alphaToCoverage: true });
  const U = { uAtlas: { value: featherAtlas() }, uTime: TIME, uGlow0: { value: vecL(P.glow0) }, uGlow1: { value: vecL(P.glow1) }, uGlowK: { value: P.glowK }, uRim: { value: vecL(P.rim) }, uIri: { value: P.iri }, uIriF: { value: P.iriF || 1.4 }, uEyeA: { value: vecL(P.eyeA || [1, 0.8, 0.2]) }, uEyeB: { value: vecL(P.eyeB || [0.1, 0.6, 0.7]) }, uFil: { value: P.fil === undefined ? 1 : P.fil } };
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, U);
    sh.vertexShader = 'attribute vec4 aCol; attribute vec2 aUv; attribute vec4 aFx; varying vec4 vCol; varying vec2 vUvF; varying vec4 vFx;\n' + sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n vCol = aCol; vUvF = aUv; vFx = aFx;');
    sh.fragmentShader = FEATHER_FRAG_HEAD + sh.fragmentShader.replace('#include <map_fragment>', FEATHER_MAP).replace('#include <emissivemap_fragment>', FEATHER_EMIS);
  };
  m.customProgramCacheKey = () => 'phx-feather-3'; m.onBeforeRender = tickTime; return m;
}
const FLAME_VERT_HEAD = 'attribute vec4 aCol; attribute vec2 aUv; attribute vec4 aFx; attribute vec3 aDir; uniform float uTime; varying vec4 vCol; varying vec2 vUvF; varying vec4 vFx;\n';
const FLAME_VERT = `#include <skinning_vertex>
  vCol = aCol; vUvF = aUv; vFx = aFx;
  { float fv = aUv.y; float fa = sin(uTime * (2.2 + aFx.z) + aFx.x * 6.2832 + fv * 5.0) * 0.55 + sin(uTime * 3.7 + aFx.x * 11.0 - fv * 8.0) * 0.45; transformed += aDir * fa * aFx.y * fv * fv; }`;
const FLAME_FRAG_HEAD = 'uniform float uTime; uniform vec3 uF0; uniform vec3 uF1; varying vec4 vCol; varying vec2 vUvF; varying vec4 vFx;\n';
const FLAME_COLOR = `{ float fu = vUvF.x * 2.0 - 1.0; float fv = vUvF.y;
    float fn = 0.5 + 0.5 * sin(fv * 11.0 - uTime * (3.0 + vFx.z * 2.0) + vFx.x * 6.2832 + fu * 4.0);
    float fn2 = 0.5 + 0.5 * sin(fv * 23.0 - uTime * 5.3 + vFx.x * 17.0 - fu * 7.0);
    float core = 1.0 - abs(fu);
    float body = smoothstep(0.0, 0.55, core + 0.15 * (fn - 0.5));
    float tip = 1.0 - smoothstep(0.55, 1.0, fv + 0.22 * (fn2 - 0.5));
    float al = body * tip * (0.5 + 0.5 * fn) * smoothstep(0.0, 0.08, fv);
    vec3 fc = mix(uF1, uF0, pow(core, 1.6) * (1.0 - 0.55 * fv));
    diffuseColor.rgb = fc * vCol.rgb * (0.85 + 0.5 * fn2 * core);
    diffuseColor.a = al * vCol.a; }`;
function flameMaterial(P) {
  const m = new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false });
  const U = { uTime: TIME, uF0: { value: vecL(P.flame0) }, uF1: { value: vecL(P.flame1) } };
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, U);
    sh.vertexShader = FLAME_VERT_HEAD + sh.vertexShader.replace('#include <skinning_vertex>', FLAME_VERT);
    sh.fragmentShader = FLAME_FRAG_HEAD + sh.fragmentShader.replace('#include <color_fragment>', FLAME_COLOR);
  };
  m.customProgramCacheKey = () => 'phx-flame-1'; m.onBeforeRender = tickTime; return m;
}

// ---------------------------------------------------------------
// GEOMETRÍA DE PLUMAS Y LLAMAS (explícitamente enlazadas a huesos)
// ---------------------------------------------------------------
const PR_FLIGHT = { a: 0.55, b: 1.05 }, PR_COVERT = { a: 0.8, b: 0.55 }, PR_PLUME = { a: 0.62, b: 0.8 }, PR_BODY = { a: 1.0, b: 0.42 };
const prof = (t, p) => Math.pow(Math.max(0, Math.sin(Math.PI * Math.pow(t, p.a))), p.b);
function genPath(d, n) {
  const b = d.base, dr = d.dir, nr = d.nrm || [0, 1, 0];
  let sx = dr[1] * nr[2] - dr[2] * nr[1], sy = dr[2] * nr[0] - dr[0] * nr[2], sz = dr[0] * nr[1] - dr[1] * nr[0]; const sl = Math.hypot(sx, sy, sz) || 1; sx /= sl; sy /= sl; sz /= sl;
  const ux = sy * dr[2] - sz * dr[1], uy = sz * dr[0] - sx * dr[2], uz = sx * dr[1] - sy * dr[0];
  const bu = d.bu || 0, bu2 = d.bu2 || 0, bs = d.bs || 0, bs2 = d.bs2 || 0, L = d.len, out = [];
  for (let i = 0; i <= n; i++) { const t = i / n, ou = (bu * t * t + bu2 * t * t * t) * L, os = (bs * t * t + bs2 * t * t * t) * L; out.push([b[0] + dr[0] * L * t + ux * ou + sx * os, b[1] + dr[1] * L * t + uy * ou + sy * os, b[2] + dr[2] * L * t + uz * ou + sz * os]); }
  return out;
}
function resample(pl, n) {
  const m = pl.length, cum = [0]; for (let i = 1; i < m; i++) cum.push(cum[i - 1] + Math.hypot(pl[i][0] - pl[i - 1][0], pl[i][1] - pl[i - 1][1], pl[i][2] - pl[i - 1][2]));
  const tot = cum[m - 1] || 1, out = []; let j = 0;
  for (let i = 0; i <= n; i++) { const L = tot * i / n; while (j < m - 2 && cum[j + 1] < L) j++; const f = clamp((L - cum[j]) / ((cum[j + 1] - cum[j]) || 1), 0, 1); const a = pl[j], c = pl[j + 1]; out.push([lerp(a[0], c[0], f), lerp(a[1], c[1], f), lerp(a[2], c[2], f)]); }
  return out;
}
function skinOf(bt, d, t) { // → [i0, w0, i1, w1]
  if (d.sk) return d.sk;
  const c = d.bind.c, n = c.length; if (n === 1) return [bt.idx[c[0]] | 0, 1, 0, 0];
  let s = lerp(d.bind.s0 || 0, d.bind.s1 === undefined ? 1 : d.bind.s1, t) * (n - 1); s = clamp(s, 0, n - 1); const k = Math.min(n - 2, Math.floor(s)), f = s - k;
  return [bt.idx[c[k]] | 0, 1 - f, bt.idx[c[k + 1]] | 0, f];
}
function buildPF(rig, bt, list) {
  if (!list.length) return null;
  let nv = 0, ni = 0; list.forEach(d => { d.n = d.seg || 7; nv += (d.n + 1) * 3; ni += d.n * 12; });
  const pos = new Float32Array(nv * 3), uv = new Float32Array(nv * 2), col = new Float32Array(nv * 4), fx = new Float32Array(nv * 4), si = new Uint16Array(nv * 4), sw = new Float32Array(nv * 4);
  const idx = nv > 65000 ? new Uint32Array(ni) : new Uint16Array(ni); let vo = 0, io = 0;
  const T = new V3(), N = new V3(), S = new V3(), tmp = new V3();
  for (let fi = 0; fi < list.length; fi++) {
    const d = list[fi], n = d.n, pts = d.path ? resample(d.path, n) : genPath(d, n), tg = [];
    for (let i = 0; i <= n; i++) { const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n, i + 1)]; tmp.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]).normalize(); tg.push([tmp.x, tmp.y, tmp.z]); }
    const nr0 = d.nrm || [0, 1, 0]; N.set(nr0[0], nr0[1], nr0[2]); T.set(tg[0][0], tg[0][1], tg[0][2]); N.addScaledVector(T, -N.dot(T)); if (N.lengthSq() < 1e-6) { N.set(1, 0, 0); N.addScaledVector(T, -T.x); } N.normalize();
    const fl = d.tile === 2 ? 1 : d.tile === 1 ? 2 : 0, as = d.as || 0, cup = d.cup === undefined ? 0.14 : d.cup, rid = d.ridge === undefined ? 0.05 : d.ridge;
    const c0 = d.c0 || [1, 1, 1], c1 = d.c1 || c0, jr = 1 + (d.jit === undefined ? 0.07 : d.jit) * (H3(fi, 3, 99) * 2 - 1), pr = d.pr || PR_FLIGHT;
    const tx0 = (d.tile * TW + PADX) / (TW * NTILE), tx1 = (d.tile * TW + TW - PADX) / (TW * NTILE);
    for (let i = 0; i <= n; i++) {
      const t = i / n; T.set(tg[i][0], tg[i][1], tg[i][2]); N.addScaledVector(T, -N.dot(T)).normalize(); if (d.twist && i > 0) N.applyAxisAngle(T, d.twist / n); S.crossVectors(T, N).normalize();
      const wv = (d.profFn ? d.profFn(t) : prof(t, pr)) * d.w * 0.5, hl = wv * (1 - as), hr = wv * (1 + as), p = pts[i], o = vo + i * 3;
      let q = o * 3; pos[q] = p[0] + S.x * hl - N.x * cup * hl; pos[q + 1] = p[1] + S.y * hl - N.y * cup * hl; pos[q + 2] = p[2] + S.z * hl - N.z * cup * hl;
      q += 3; pos[q] = p[0] + N.x * rid * wv; pos[q + 1] = p[1] + N.y * rid * wv; pos[q + 2] = p[2] + N.z * rid * wv;
      q += 3; pos[q] = p[0] - S.x * hr - N.x * cup * hr; pos[q + 1] = p[1] - S.y * hr - N.y * cup * hr; pos[q + 2] = p[2] - S.z * hr - N.z * cup * hr;
      const vv = clamp(d.vmap ? d.vmap(t) : t, 0.003, 0.997);
      uv[o * 2] = tx0; uv[o * 2 + 1] = vv; uv[o * 2 + 2] = (tx0 + tx1) * 0.5; uv[o * 2 + 3] = vv; uv[o * 2 + 4] = tx1; uv[o * 2 + 5] = vv;
      const g = Math.pow(t, d.cg || 1), cc = lin3([lerp(c0[0], c1[0], g) * jr, lerp(c0[1], c1[1], g) * jr, lerp(c0[2], c1[2], g) * jr]), gl = lerp(d.g0 === undefined ? 0.4 : d.g0, d.g1 === undefined ? 0.4 : d.g1, t);
      const sk = skinOf(bt, d, t);
      for (let k = 0; k < 3; k++) { const v = o + k; col[v * 4] = cc[0]; col[v * 4 + 1] = cc[1]; col[v * 4 + 2] = cc[2]; col[v * 4 + 3] = gl; fx[v * 4] = d.ph || 0; fx[v * 4 + 1] = d.iri === undefined ? 1 : d.iri; fx[v * 4 + 2] = t; fx[v * 4 + 3] = fl; si[v * 4] = sk[0]; si[v * 4 + 1] = sk[2]; sw[v * 4] = sk[1]; sw[v * 4 + 1] = sk[3]; }
    }
    for (let i = 0; i < n; i++) { const a = vo + i * 3, b = a + 3; idx[io++] = a; idx[io++] = a + 1; idx[io++] = b + 1; idx[io++] = a; idx[io++] = b + 1; idx[io++] = b; idx[io++] = a + 1; idx[io++] = a + 2; idx[io++] = b + 2; idx[io++] = a + 1; idx[io++] = b + 2; idx[io++] = b + 1; }
    vo += (n + 1) * 3;
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aUv', new THREE.BufferAttribute(uv, 2)); g.setAttribute('aCol', new THREE.BufferAttribute(col, 4)); g.setAttribute('aFx', new THREE.BufferAttribute(fx, 4));
  g.setAttribute('skinIndex', new THREE.BufferAttribute(si, 4)); g.setAttribute('skinWeight', new THREE.BufferAttribute(sw, 4)); g.setIndex(new THREE.BufferAttribute(idx, 1)); g.computeVertexNormals(); return g;
}
function buildFL(rig, bt, list) {
  if (!list.length) return null;
  let nv = 0, ni = 0; list.forEach(d => { d.n = d.path.length - 1; d.cr = d.cross || 2; nv += (d.n + 1) * 2 * d.cr; ni += d.n * 6 * d.cr; });
  const pos = new Float32Array(nv * 3), uv = new Float32Array(nv * 2), col = new Float32Array(nv * 4), fx = new Float32Array(nv * 4), dir = new Float32Array(nv * 3), si = new Uint16Array(nv * 4), sw = new Float32Array(nv * 4);
  const idx = nv > 65000 ? new Uint32Array(ni) : new Uint16Array(ni); let vo = 0, io = 0; const T = new V3(), N = new V3(), S = new V3(), tmp = new V3(), W = new V3();
  for (let fi = 0; fi < list.length; fi++) {
    const d = list[fi], n = d.n, pts = d.path, tg = [];
    for (let i = 0; i <= n; i++) { const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n, i + 1)]; tmp.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]).normalize(); tg.push([tmp.x, tmp.y, tmp.z]); }
    const nr0 = d.nrm || [0, 1, 0]; N.set(nr0[0], nr0[1], nr0[2]); T.set(tg[0][0], tg[0][1], tg[0][2]); N.addScaledVector(T, -N.dot(T)); if (N.lengthSq() < 1e-6) { N.set(1, 0, 0); N.addScaledVector(T, -T.x); } N.normalize();
    const c = d.col || [1, 1, 1], al = d.a === undefined ? 1 : d.a;
    for (let i = 0; i <= n; i++) {
      const t = i / n; T.set(tg[i][0], tg[i][1], tg[i][2]); N.addScaledVector(T, -N.dot(T)).normalize(); S.crossVectors(T, N).normalize();
      const wv = lerp(d.w0, d.w1, Math.pow(t, d.pw || 1)) * 0.5, p = pts[i], sk = skinOf(bt, d, t);
      for (let k = 0; k < d.cr; k++) {
        const ang = k * Math.PI / d.cr, ca = Math.cos(ang), sa = Math.sin(ang); W.set(S.x * ca + N.x * sa, S.y * ca + N.y * sa, S.z * ca + N.z * sa);
        for (let sd = 0; sd < 2; sd++) {
          const v = vo + (i * d.cr + k) * 2 + sd, sg = sd ? 1 : -1;
          pos[v * 3] = p[0] + W.x * wv * sg; pos[v * 3 + 1] = p[1] + W.y * wv * sg; pos[v * 3 + 2] = p[2] + W.z * wv * sg; uv[v * 2] = sd; uv[v * 2 + 1] = t;
          col[v * 4] = c[0]; col[v * 4 + 1] = c[1]; col[v * 4 + 2] = c[2]; col[v * 4 + 3] = al; fx[v * 4] = d.ph || 0; fx[v * 4 + 1] = d.amp === undefined ? 0.05 : d.amp; fx[v * 4 + 2] = d.spd || 0; fx[v * 4 + 3] = 0;
          dir[v * 3] = N.x * ca - S.x * sa; dir[v * 3 + 1] = N.y * ca - S.y * sa; dir[v * 3 + 2] = N.z * ca - S.z * sa;
          si[v * 4] = sk[0]; si[v * 4 + 1] = sk[2]; sw[v * 4] = sk[1]; sw[v * 4 + 1] = sk[3];
        }
      }
    }
    for (let k = 0; k < d.cr; k++) for (let i = 0; i < n; i++) { const a = vo + (i * d.cr + k) * 2, b = vo + ((i + 1) * d.cr + k) * 2; idx[io++] = a; idx[io++] = a + 1; idx[io++] = b; idx[io++] = a + 1; idx[io++] = b + 1; idx[io++] = b; }
    vo += (n + 1) * 2 * d.cr;
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aUv', new THREE.BufferAttribute(uv, 2)); g.setAttribute('aCol', new THREE.BufferAttribute(col, 4)); g.setAttribute('aFx', new THREE.BufferAttribute(fx, 4)); g.setAttribute('aDir', new THREE.BufferAttribute(dir, 3));
  g.setAttribute('skinIndex', new THREE.BufferAttribute(si, 4)); g.setAttribute('skinWeight', new THREE.BufferAttribute(sw, 4)); g.setIndex(new THREE.BufferAttribute(idx, 1)); return g;
}


// ---------------------------------------------------------------
// CONSTRUCTOR DEL FÉNIX (hueso + SDF + plumas enlazadas)
// ---------------------------------------------------------------
const lerp3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const add3 = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const norm3 = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const isObj = o => o && typeof o === 'object' && !Array.isArray(o);
const mergeP = (a, b) => { const o = Object.assign({}, a); for (const k in b) o[k] = (isObj(a[k]) && isObj(b[k])) ? mergeP(a[k], b[k]) : b[k]; return o; };
const BASE = {
  seed: 1, hy: 0.8, bw: 0.145, bh: 0.175,
  neck: [[0.10, 0.05], [0.24, 0.07], [0.38, 0.03], [0.50, -0.02], [0.58, 0.04], [0.63, 0.13]], nr0: 0.082, nr1: 0.04,
  hr: 0.062, beak: { len: 0.165, drop: 0.03, r: 0.031, w: 0.7, hook: 0.055, taper: 0.17 }, lt: 0.013, toe: 0.15,
  wing: { sh: [0.13, 0.2, 0.14], el: [0.52, 0.26, 0.1], wr: [0.96, 0.31, 0.2], tip: [1.3, 0.33, 0.08], nPrim: 12, nSec: 10, nTert: 4, primLen: 1.05, secLen: 0.78, primW: 0.17, secW: 0.18 },
  tail: { type: 'plumes', len: 2.4, n: 12, count: 9, wid: 0.19, amp: 0.3, waves: 1.2, spread: 0.5, shortK: 0.6, fan: 8 },
  crest: { n: 12, len: 0.34, type: 'fil', spread: 0.06 },
  flames: { tail: 8, wing: 6, crest: 2 }, sparks: 60, sparkSize: 0.05,
  glowK: 1.0, iriF: 1.4, selfGlow: 0.15, chestK: 0.6, rough: 0.5
};
function phxBuild(P, opts) {
  const lod = (opts && opts.lod) || 0, rnd = rngf(P.seed), r = new Rig(P.id), hy = P.hy, bw = P.bw, bh = P.bh, hr = P.hr, C = P.pal, W = P.wing, T = P.tail, CR = P.crest;
  r.meta.grp = {}; r.meta.H = hy + 0.9; r.meta.hipY = hy; r.meta.stride = 0.7; r.meta.flapAmp = 0.7; r.meta.P = P;
  const mkF = d => { d.kind = 'pf'; if (d.ph === undefined) d.ph = rnd(); r.decor.push(d); return d; };
  const mkFl = d => { d.kind = 'pfl'; if (d.ph === undefined) d.ph = rnd(); r.decor.push(d); return d; };
  const sg = n => lod ? Math.max(3, Math.round(n * 0.6)) : n;
  const G = C.glow, I = C.iri;
  // --- tronco
  r.bone('body', null, [0, hy, 0]); r.bone('chest', 'body', [0, hy + 0.05, 0.26]);
  r.ell('body', [0, hy, -0.1], [bw, bh, 0.34], 0.1); r.ell('chest', [0, hy + 0.06, 0.2], [bw * 0.98, bh * 1.08, 0.26], 0.1); r.ell('chest', [0, hy - 0.11, 0.2], [0.04, 0.1, 0.24], 0.1);
  r.cone('body', [0, hy - 0.01, -0.28], [0, hy - 0.06, -0.46], bw * 0.72, bw * 0.24, 0.08, { sc: [1, 0.6, 1] });
  // --- cuello y cabeza
  const nb = [0, hy + 0.17, 0.34], pts = [nb]; P.neck.forEach(o => pts.push([0, nb[1] + o[0], nb[2] + o[1]]));
  const nn = pts.length - 1, nm = [];
  for (let i = 1; i < nn; i++) { r.bone('neck' + i, i === 1 ? 'chest' : 'neck' + (i - 1), pts[i]); nm.push('neck' + i); }
  const hp = pts[nn]; r.bone('head', nm[nm.length - 1], hp); r.bone('jaw', 'head', add3(hp, [0, -hr * 0.35, hr * 0.3]));
  const nr = Z.taper(pts.length, P.nr0, P.nr1, 0.9);
  r.cone('chest', nb, pts[1], nr[0], nr[1], 0.06); for (let i = 1; i < nn; i++) r.cone('neck' + i, pts[i], pts[i + 1], nr[i], nr[i + 1], 0.05);
  r.ell('head', add3(hp, [0, hr * 0.05, hr * 0.25]), [hr * 0.95, hr, hr * 1.25], 0.04);
  const bk = P.beak, b0 = add3(hp, [0, -hr * 0.12, hr * 0.85]), tip = add3(b0, [0, -bk.drop, bk.len]);
  r.cone('head', b0, tip, bk.r, bk.r * bk.taper, 0.02, { sc: [bk.w, 1, 1] });
  r.cone('head', tip, add3(tip, [0, -bk.hook, -bk.len * 0.08]), bk.r * 0.25, bk.r * 0.04, 0.015);
  r.cone('jaw', add3(b0, [0, -bk.r * 0.7, -bk.len * 0.1]), add3(tip, [0, bk.r * 0.1 + bk.r * 0.9, -bk.len * 0.08]), bk.r * 0.55, bk.r * 0.12, 0.012, { sc: [bk.w, 1, 1] });
  r.sub('head', 'rc', [add3(b0, [0, -bk.r * 0.42, -bk.len * 0.1]), add3(tip, [0, bk.r * 0.1 + bk.r * 0.15, -bk.len * 0.1]), bk.r * 0.06, bk.r * 0.04], 0.01);
  for (const sx of [-1, 1]) r.rigid.push({ bone: 'head', eye: { r: hr * 0.27, slit: false }, at: add3(hp, [sx * hr * 0.82, hr * 0.2, hr * 0.5]) });
  // --- alas
  r.roles.wings = {}; r.roles.pf = { L: {}, R: {}, crest: [], tail: [] };
  const wp = [W.sh, W.el, W.wr, W.tip], armPt = a => { const f = clamp(a, 0, 1) * 3, k = Math.min(2, Math.floor(f)); return lerp3(wp[k], wp[k + 1], f - k); };
  const wingSets = {}; r.meta.armH = [0, 1, 2].map(k => Math.atan2(-(wp[k + 1][2] - wp[k][2]), wp[k + 1][0] - wp[k][0]));
  for (const sx of [1, -1]) {
    const side = sx > 0 ? 'L' : 'R', pp = wp.map(p => [p[0] * sx, hy + p[1], p[2]]);
    const wrn = 'wr' + side, wrb = r.bone(wrn, 'chest', pp[0]); wrb.noSkin = true; (r.roles.wroot = r.roles.wroot || {})[side] = wrn;
    const wn = r.chain('wing' + side + '_', wrn, pp, [0.05, 0.04, 0.03, 0.018], 0.04); r.roles.wings[side] = wn;
    const toW = p => [p[0] * sx, hy + p[1], p[2]], dirW = (ang, el) => { const ce = Math.cos(el); return [Math.sin(ang) * sx * ce, Math.sin(el), -Math.cos(ang) * ce]; }, asy = 0.3 * sx;
    const nP = W.nPrim, nS = W.nSec, nT = W.nTert, prim = [], sec = [], tert = [], wt = P.wingTile || 0, wf = wt === 1 ? 1.5 : 1, ct = wt === 1 ? 1 : 3, NGP = 4, NGS = 3, NAG = 8;
    const hd = dv => Math.atan2(-dv[2], dv[0] * sx);
    for (let k = 0; k < nP; k++) { const u = k / (nP - 1); prim.push({ u, base: lerp3(W.wr, W.tip, u * 0.92), ang: lerp(0.18, 1.2, Math.pow(u, 1.15)), el: 0.02 + 0.06 * u, len: W.primLen * (0.82 + 0.36 * Math.sin(Math.PI * (0.1 + 0.8 * u))) * (k === nP - 1 ? 0.9 : 1), gi: Math.min(NGP - 1, Math.floor(u * NGP)) }); }
    for (let i = 0; i < nS; i++) { const u = i / (nS - 1); sec.push({ u, base: lerp3(W.wr, W.el, u * 0.95), ang: lerp(0.3, -0.1, u), el: 0.02, len: W.secLen * (1 - 0.18 * u), gi: Math.min(NGS - 1, Math.floor(u * NGS)) }); }
    for (let i = 0; i < nT; i++) { const u = i / Math.max(1, nT - 1); tert.push({ u, base: lerp3(W.el, W.sh, 0.12 + 0.8 * u), ang: -0.15 - 0.1 * u, el: 0.0, len: W.secLen * 0.78 * (1 - 0.2 * u) }); }
    const mkGroup = (name, parent, items, seg) => {
      const c = [0, 0, 0], md = [0, 0, 0]; let ml = 0;
      items.forEach(it => { const dv = dirW(it.ang, it.el), bw_ = toW(it.base); for (let q = 0; q < 3; q++) { c[q] += bw_[q]; md[q] += dv[q]; } ml += it.len; });
      const n = items.length; for (let q = 0; q < 3; q++) c[q] /= n; ml /= n; const mdn = norm3(md);
      const b1 = r.bone(name, parent, c); b1.noSkin = true; const b2 = r.bone(name + 't', name, [c[0] + mdn[0] * ml * 0.55, c[1] + mdn[1] * ml * 0.55, c[2] + mdn[2] * ml * 0.55]); b2.noSkin = true;
      r.meta.grp[name] = { seg, h: hd(mdn), side, kind: 'chain', rank: items.length ? items[0].gi || 0 : 0 }; return [name, name + 't'];
    };
    const pg = [...Array(NGP).keys()].map(g => mkGroup('pg' + side + g, wn[2], prim.filter(it => it.gi === g), 2)), sgp = [...Array(NGS).keys()].map(g => mkGroup('sg' + side + g, wn[1], sec.filter(it => it.gi === g), 1)), tgp = mkGroup('tg' + side, wn[0], tert, 0);
    r.roles.pf[side] = { prim: pg, sec: sgp, tert: [tgp] };
    const gl = (a, b) => ({ g0: a, g1: b });
    // plumas de vuelo
    prim.forEach(it => { mkF(Object.assign({ tile: wt, base: toW(it.base), dir: dirW(it.ang, it.el), len: it.len, w: W.primW * wf * (1 - 0.28 * it.u), as: asy, pr: PR_FLIGHT, bu: 0.03 + 0.07 * it.u, bu2: 0.06, seg: sg(12), c0: C.prim[0], c1: C.prim[1], iri: I.prim, bind: { c: pg[it.gi], s0: 0, s1: 0.92 }, cup: 0.12 }, gl(G.prim[0], G.prim[1]))); });
    sec.forEach(it => { mkF(Object.assign({ tile: wt, base: toW(it.base), dir: dirW(it.ang, it.el), len: it.len, w: W.secW * wf, as: asy * 0.7, pr: PR_FLIGHT, bu: -0.05, bu2: 0.02, seg: sg(12), c0: C.sec[0], c1: C.sec[1], iri: I.prim, bind: { c: sgp[it.gi], s0: 0, s1: 0.9 }, cup: 0.12 }, gl(G.sec[0], G.sec[1]))); });
    tert.forEach(it => { mkF(Object.assign({ tile: wt, base: toW(it.base), dir: dirW(it.ang, it.el), len: it.len, w: W.secW * wf * 0.95, as: asy * 0.5, pr: PR_FLIGHT, bu: -0.04, seg: sg(10), c0: C.sec[0], c1: C.sec[1], iri: I.prim, bind: { c: tgp, s0: 0, s1: 0.9 }, cup: 0.12 }, gl(G.sec[0], G.sec[1]))); });
    // coberteras (hileras superpuestas sobre las bases de las plumas de vuelo)
    prim.forEach(it => { const b = [it.base[0], it.base[1] + 0.008, it.base[2] + 0.05]; mkF(Object.assign({ tile: ct, base: toW(b), dir: dirW(it.ang, it.el), len: 0.38 * it.len / W.primLen, w: 0.15, as: asy * 0.4, pr: PR_COVERT, bu: -0.1, bu2: 0.22, seg: sg(6), c0: C.cov[0], c1: C.cov[1], iri: I.cov, bind: { c: pg[it.gi], s0: 0, s1: 0.5 }, cup: 0.1 }, gl(G.cov[0], G.cov[1]))); });
    sec.forEach(it => { const b = [it.base[0], it.base[1] + 0.008, it.base[2] + 0.05]; mkF(Object.assign({ tile: ct, base: toW(b), dir: dirW(it.ang, it.el), len: 0.32, w: 0.15, as: asy * 0.4, pr: PR_COVERT, bu: -0.1, bu2: 0.22, seg: sg(6), c0: C.cov[0], c1: C.cov[1], iri: I.cov, bind: { c: sgp[it.gi], s0: 0, s1: 0.5 }, cup: 0.1 }, gl(G.cov[0], G.cov[1]))); });
    const nM = 12; for (let i = 0; i < nM; i++) { const u = i / (nM - 1), a = lerp3(W.wr, W.el, u * 0.95), b = [a[0], a[1] + 0.016, a[2] + 0.11]; mkF(Object.assign({ tile: ct, base: toW(b), dir: dirW(lerp(0.25, -0.1, u), 0.02), len: 0.2, w: 0.115, pr: PR_COVERT, bu: -0.1, bu2: 0.25, seg: sg(5), c0: C.cov2[0], c1: C.cov2[1], iri: I.cov, bind: { c: sgp[Math.min(NGS - 1, Math.floor(u * NGS))], s0: 0, s1: 0.4 }, cup: 0.1 }, gl(G.cov[0], G.cov[1]))); }
    // línea del ala (borde de ataque): dos hileras, cada una ligada a un grupo fino sobre el brazo
    const armIt = [], nL = 16; for (let row = 0; row < 2; row++) for (let i = 0; i < nL; i++) { const a = 0.03 + 0.95 * (i + row * 0.5) / (nL - 0.5), p0 = armPt(Math.min(0.99, a)); armIt.push({ a, base: [p0[0], p0[1] + 0.022 + row * 0.012, p0[2] + 0.055 - row * 0.05], ang: lerp(0.05, 0.5, a) + row * 0.1, el: 0.02, len: 0.15 * (1 - 0.3 * a) * (row ? 1.25 : 1), w: row ? 0.1 : 0.088, gi: Math.min(NAG - 1, Math.floor(a * NAG)) }); }
    for (let g = 0; g < NAG; g++) {
      const its = armIt.filter(it => it.gi === g); if (!its.length) continue; const c = [0, 0, 0], md = [0, 0, 0];
      its.forEach(it => { const b_ = toW(it.base), dv = dirW(it.ang, it.el); for (let q = 0; q < 3; q++) { c[q] += b_[q]; md[q] += dv[q]; } }); for (let q = 0; q < 3; q++) c[q] /= its.length;
      const am = its.reduce((s_, it) => s_ + it.a, 0) / its.length, seg = Math.min(2, Math.floor(am * 3)), nm_ = 'ag' + side + g, b1 = r.bone(nm_, wn[seg], c); b1.noSkin = true;
      r.meta.grp[nm_] = { seg, h: hd(norm3(md)), side, kind: 'arm', rank: g }; its.forEach(it => { it.grp = nm_; });
    }
    armIt.forEach(it => { mkF(Object.assign({ tile: ct, base: toW(it.base), dir: dirW(it.ang, it.el), len: it.len, w: it.w, pr: PR_COVERT, bu: -0.1, bu2: 0.25, seg: sg(4), c0: C.cov2[0], c1: C.cov2[1], iri: I.cov, bind: { c: [it.grp], s0: 0, s1: 0 }, cup: 0.1 }, gl(G.cov[0], G.cov[1]))); });
    wingSets[side] = { prim, pg, wn, toW, dirW };
  }
  // --- piernas y garras
  r.roles.legs = {}; const legH = hy - bh * 0.6;
  for (const sx of [-1, 1]) {
    const key = sx > 0 ? 'L' : 'R', lp = [[sx * bw * 0.5, hy - bh * 0.55, -0.04], [sx * bw * 0.55, hy - bh * 0.55 - legH * 0.4, 0.08], [sx * bw * 0.5, legH * 0.1 + 0.01, -0.03], [sx * bw * 0.5, 0.012, 0]];
    const lnm = r.chain('leg' + key + '_', 'body', lp, [P.lt * 1.8, P.lt, P.lt * 0.7, P.lt * 0.8], 0.03); r.roles.legs[key] = lnm;
    r.ell(lnm[0], [lp[0][0], lp[0][1] - bh * 0.1, lp[0][2]], [bw * 0.38, bh * 0.55, 0.12], 0.08);
    const f = lp[3]; [[0, 0], [0.5, 0], [-0.5, 0], [0, -1]].forEach((tt, ti) => { const back = ti === 3, len = P.toe * (back ? 0.5 : 1), tp = [[f[0], f[1] + 0.004, f[2]], [f[0] + tt[0] * len * 0.5, 0.008, f[2] + (back ? -len * 0.6 : len * 0.7)], [f[0] + tt[0] * len * 0.8, 0.004, f[2] + (back ? -len * 0.9 : len * 1.0)]]; r.rigid.push({ bone: lnm[3], mat: 'gold', geo: Z.sweep(tp, [P.lt * 0.75, P.lt * 0.6, P.lt * 0.28], 5) }); });
  }
  // --- cola: cadena de huesos + estandartes largos enlazados por longitud de arco
  const tb = [0, hy - 0.03, -0.4], Lt = T.len, nTb = T.n, drop = Math.min(hy * 0.82, Lt * 0.28), cen = s => [0, tb[1] - drop * Math.pow(s, 1.7), tb[2] - Lt * s];
  const tn = []; for (let j = 0; j < nTb; j++) { const nm_ = 'tail' + (j + 1); r.bone(nm_, j ? 'tail' + j : 'body', cen(j / (nTb - 1))); tn.push(nm_); }
  r.cone(tn[0], cen(0), cen(1 / (nTb - 1)), 0.07, 0.025, 0.05);
  const streams = [], nSt = T.count, eyes = T.type === 'eyes', fil = T.type === 'fil';
  for (let i = 0; i < nSt; i++) {
    const m = nSt > 1 ? (i - (nSt - 1) / 2) / ((nSt - 1) / 2) : 0, am = Math.abs(m), fl = lerp(1, T.shortK, Math.pow(am, 1.1)), ph = rnd(), nw = T.waves * (0.85 + 0.3 * rnd()), path = [], NP = 16;
    for (let k = 0; k <= NP; k++) { const s = k / NP, c = cen(s * fl); path.push([m * T.spread * Math.pow(s, 1.25) + T.amp * Math.sin(6.283 * (nw * s + ph)) * Math.pow(s, 0.85) * (0.55 + 0.45 * am), c[1] + 0.012 * (i % 3), c[2]]); }
    const len = Lt * fl; streams.push({ path, fl, m });
    const rl = m * (eyes ? 0.5 : 0.85) + (rnd() - 0.5) * 0.25, dd = { nrm: [Math.sin(rl), Math.cos(rl), 0], twist: (rnd() - 0.5) * 1.5, tile: eyes ? 2 : fil ? 1 : 0, path, w: eyes ? len / 11 : fil ? T.wid * 1.6 : T.wid * (1 - 0.25 * am), as: 0, pr: PR_PLUME, seg: sg(eyes ? 22 : 18), c0: C.tail[0], c1: C.tail[1], cg: 1.2, iri: I.tail, cup: 0.1, bind: { c: tn, s0: 0.02, s1: fl }, g0: G.tail[0], g1: G.tail[1] };
    if (eyes) { dd.profFn = t => (0.22 + 0.78 * sst(0.55, 0.84, t)) * (t > 0.84 ? Math.sqrt(Math.max(0, 1 - ((t - 0.84) / 0.16) ** 2)) : 1); dd.vmap = t => (t < 0.75 ? t * 0.55 / 0.75 : 0.55 + (t - 0.75) / 0.25 * 0.45); }
    mkF(dd);
  }
  for (let i = 0; i < T.fan; i++) {
    const m = T.fan > 1 ? (i - (T.fan - 1) / 2) / ((T.fan - 1) / 2) : 0, ang = m * 0.65, len = 0.7 - 0.2 * Math.abs(m) + 0.15 * rnd();
    mkF(Object.assign({ nrm: [Math.sin(m * 0.7), Math.cos(m * 0.7), 0], tile: 0, base: [m * 0.06, hy - 0.04, -0.36], dir: norm3([Math.sin(ang), -0.12 + 0.06 * (1 - Math.abs(m)), -Math.cos(ang)]), len, w: 0.15, as: 0.2 * m, pr: PR_PLUME, bu: -0.04, bu2: -0.08, seg: sg(10), c0: C.tail2[0], c1: C.tail2[1], iri: I.tail, bind: { c: tn.slice(0, 5), s0: 0, s1: Math.min(1, len / Lt * 1.2) }, cup: 0.1 }, { g0: G.tail[0], g1: G.tail[1] }));
  }
  // --- cresta
  const h0 = [hp[0], hp[1] + hr * 0.75, hp[2] - hr * 0.3], cpts = bez(h0, add3(h0, [0, 0.12, -0.08]), add3(h0, [0, 0.2, -0.24]), add3(h0, [0, 0.14, -CR.len * 0.95]), 3), cb = [];
  cpts.forEach((p, i) => { const b = r.bone('crest' + (i + 1), i ? 'crest' + i : 'head', p); b.noSkin = true; cb.push('crest' + (i + 1)); });
  for (let i = 0; i < CR.n; i++) {
    const u = CR.n > 1 ? i / (CR.n - 1) : 0.5, sx_ = (u - 0.5) * 2 * CR.spread, ln = CR.len * (0.75 + 0.5 * rnd()), rz = rnd(), cr = CR.type === 'fil';
    const path = bez(add3(h0, [sx_ * 0.4, 0.01, 0]), add3(h0, [sx_ * 0.9, 0.12 + 0.03 * rz, -0.07]), add3(h0, [sx_ * 1.6, 0.2 + 0.05 * rz, -0.2]), add3(h0, [sx_ * 2.4, 0.15 + 0.05 * rz, -ln]), 10);
    mkF({ tile: cr ? 1 : 0, path, w: cr ? 0.085 : 0.05, as: 0, pr: PR_PLUME, seg: sg(10), c0: C.crest[0], c1: C.crest[1], cg: 1.1, iri: I.crest, cup: 0.1, bind: { c: cb, s0: 0.05, s1: 0.95 }, g0: G.crest[0], g1: G.crest[1] });
  }
  // --- llamas (cintas cruzadas con shader animado)
  const pointOn = (pl, f) => { const k = clamp(f, 0, 1) * (pl.length - 1), a = Math.min(pl.length - 2, Math.floor(k)); return lerp3(pl[a], pl[a + 1], k - a); };
  for (let i = 0; i < P.flames.tail && streams.length; i++) {
    const st = streams[Math.floor(rnd() * streams.length)], s0 = 0.15 + 0.6 * rnd(), ds = 0.12 + 0.1 * rnd(), ph = rnd() * 6.28, path = [];
    for (let k = 0; k <= 7; k++) { const u = k / 7, q = pointOn(st.path, s0 + u * ds); path.push([q[0] + Math.sin(u * 5 + ph) * 0.035 * u, q[1] + 0.05 * u + 0.2 * u * u, q[2]]); }
    mkFl({ path, w0: 0.1, w1: 0.012, pw: 0.9, col: C.flameCol, a: 0.85, amp: 0.06, spd: rnd(), bind: { c: tn, s0: st.fl * s0, s1: st.fl * Math.min(1, s0 + ds) } });
  }
  for (const side of ['L', 'R']) for (let i = 0; i < P.flames.wing; i++) {
    const ws = wingSets[side], it = ws.prim[Math.floor(rnd() * ws.prim.length)], t0 = 0.5 + 0.3 * rnd(), ph = rnd() * 6.28, path = [], dv = ws.dirW(it.ang, it.el), b = ws.toW(it.base);
    for (let k = 0; k <= 6; k++) { const u = k / 6, tt = t0 + u * (1.18 - t0); path.push([b[0] + dv[0] * it.len * tt + Math.sin(u * 5 + ph) * 0.03 * u, b[1] + dv[1] * it.len * tt + 0.03 * u + 0.18 * u * u, b[2] + dv[2] * it.len * tt]); }
    mkFl({ path, w0: 0.09, w1: 0.01, pw: 0.9, col: C.flameCol, a: 0.8, amp: 0.05, spd: rnd(), bind: { c: ws.pg[it.gi], s0: t0 * 0.9, s1: 0.95 } });
  }
  for (let i = 0; i < P.flames.crest; i++) { const path = bez(add3(h0, [(i - 0.5) * 0.03, 0.02, 0]), add3(h0, [(i - 0.5) * 0.05, 0.14, -0.05]), add3(h0, [(i - 0.5) * 0.08, 0.22, -0.17]), add3(h0, [(i - 0.5) * 0.1, 0.24, -0.34]), 7); mkFl({ path, w0: 0.07, w1: 0.01, pw: 0.9, col: C.flameCol, a: 0.85, amp: 0.04, spd: rnd(), bind: { c: cb, s0: 0.05, s1: 0.95 } }); }
  // --- chispas y orbe luminoso
  const sparkPts = []; for (let i = 0; i < P.sparks; i++) { if (rnd() < 0.6 && streams.length) { const st = streams[Math.floor(rnd() * streams.length)], q = pointOn(st.path, 0.1 + 0.8 * rnd()); sparkPts.push([q[0] + (rnd() - 0.5) * 0.25, q[1] + (rnd() - 0.5) * 0.2, q[2]]); } else sparkPts.push([(rnd() - 0.5) * 1.8, hy + (rnd() - 0.3) * 0.7, (rnd() - 0.5) * 1.1]); }
  r.rigid.push({ bone: 'body', obj: () => makeSparks(P, sparkPts) });
  if (P.orb) r.rigid.push({ bone: 'chest', obj: () => makeOrb(P, [0, hy + 0.1, 0.36]) });
  // --- roles
  r.roles.spine = ['body', 'chest']; r.roles.neck = nm; r.roles.head = 'head'; r.roles.jaw = 'jaw'; r.roles.root = 'body'; r.roles.tails = tn; r.roles.pf.tail = tn; r.roles.pf.crest = [cb];
  r.meta.hp = hp; r.meta.hr = hr; r.meta.spine = [b0, hp].concat(pts.slice(1, nn).reverse(), [nb, [0, hy + 0.1, 0.2], [0, hy, -0.1], [0, hy - 0.05, -0.4], [0, hy - 0.1, -0.8]]); r.meta.chestC = [0, hy + 0.1, 0.3]; r.meta.tailLen = Lt; r.meta.nT = nTb;
  return r;
}


// ---------------------------------------------------------------
// CHISPAS, ORBE, PIEL DE PLUMAS DEL CUERPO Y MATERIAL DEL CUERPO
// ---------------------------------------------------------------
function makeSparks(P, pts) {
  const n = pts.length, pos = new Float32Array(n * 3), ap = new Float32Array(n * 4), rr = rngf(P.seed + 55);
  for (let i = 0; i < n; i++) { pos[i * 3] = pts[i][0]; pos[i * 3 + 1] = pts[i][1]; pos[i * 3 + 2] = pts[i][2]; ap[i * 4] = rr(); ap[i * 4 + 1] = 0.6 + rr() * 0.9; ap[i * 4 + 2] = 0.5 + rr() * 1.2; ap[i * 4 + 3] = 0.5 + rr() * 1.1; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aP', new THREE.BufferAttribute(ap, 4));
  const m = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: { uTime: TIME, uCol: { value: vec3(P.sparkCol) }, uSize: { value: P.sparkSize }, uPx: { value: 1 } },
    vertexShader: `attribute vec4 aP; uniform float uTime; uniform float uSize; uniform float uPx; varying float vA;
      void main() { float life = fract(aP.x + uTime * 0.11 * aP.y);
        vec3 p = position + vec3(sin(aP.x * 40.0 + uTime * 0.9 * aP.y) * 0.1, life * aP.z, cos(aP.x * 37.0 + uTime * 0.7) * 0.1);
        vec4 mv = modelViewMatrix * vec4(p, 1.0); gl_Position = projectionMatrix * mv;
        float fade = smoothstep(0.0, 0.12, life) * (1.0 - smoothstep(0.55, 1.0, life)); vA = fade;
        gl_PointSize = uSize * aP.w * uPx * (1.0 + 0.3 * fade) * (400.0 / max(0.1, -mv.z)); }`,
    fragmentShader: `uniform vec3 uCol; varying float vA;
      void main() { vec2 q = gl_PointCoord * 2.0 - 1.0; float d = dot(q, q); if (d > 1.0) discard; float a = pow(1.0 - d, 1.6) * vA; gl_FragColor = vec4(uCol * (0.6 + 1.2 * (1.0 - d)), a); }`
  });
  m.onBeforeRender = rd => { tickTime(); try { m.uniforms.uPx.value = rd.getPixelRatio(); } catch (_) {} };
  const o = new THREE.Points(g, m); o.frustumCulled = false; o.renderOrder = 5; return o;
}
let _orbTex = null;
function orbTex() {
  if (_orbTex) return _orbTex; const c = document.createElement('canvas'); c.width = c.height = 128; const g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.18, 'rgba(255,255,255,0.85)'); gr.addColorStop(0.45, 'rgba(255,255,255,0.25)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  g.globalCompositeOperation = 'lighter'; for (let i = 0; i < 12; i++) { g.save(); g.translate(64, 64); g.rotate(i / 12 * Math.PI * 2); const rg = g.createLinearGradient(0, 0, 60, 0); rg.addColorStop(0, 'rgba(255,255,255,0.35)'); rg.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = rg; g.fillRect(0, -1.2, 60, 2.4); g.restore(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; _orbTex = t; return t;
}
function makeOrb(P, pos) {
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: orbTex(), color: new THREE.Color(P.orb[0], P.orb[1], P.orb[2]), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: P.orbA === undefined ? 0.85 : P.orbA, fog: false }));
  sp.position.set(pos[0], pos[1], pos[2]); sp.scale.setScalar(P.orbSize || 0.6); sp.renderOrder = 6; return sp;
}
const mul3 = (c, k) => [Math.min(1, c[0] * k), Math.min(1, c[1] * k), Math.min(1, c[2] * k)];
const RG = {
  head: { name: 'head', len: 0.034, w: 0.028, cell: 0.024, splay: 0.4, lift: 0.05, half: 0.05, gk: 0.6, ik: 0.9 },
  neck: { name: 'neck', len: 0.058, w: 0.048, cell: 0.031, splay: 0.5, lift: 0.07, half: 0.07, gk: 0.8, ik: 1.0 },
  chest: { name: 'chest', len: 0.088, w: 0.072, cell: 0.041, splay: 0.8, lift: 0.06, half: 0.15, gk: 1.0, ik: 0.9 },
  back: { name: 'back', len: 0.1, w: 0.082, cell: 0.045, splay: 0.6, lift: 0.08, half: 0.15, gk: 0.5, ik: 1.0 },
  belly: { name: 'belly', len: 0.09, w: 0.076, cell: 0.045, splay: 0.4, lift: 0.06, half: 0.15, gk: 0.8, ik: 0.7 },
  rump: { name: 'rump', len: 0.12, w: 0.09, cell: 0.05, splay: 0.8, lift: 0.06, half: 0.1, gk: 0.6, ik: 1.0 },
  thigh: { name: 'thigh', len: 0.09, w: 0.075, cell: 0.043, splay: 0.3, lift: 0.06, half: 0.1, gk: 0.5, ik: 0.8 },
  shoulder: { name: 'shoulder', len: 0.09, w: 0.075, cell: 0.043, splay: 0.3, lift: 0.06, half: 0.1, gk: 0.6, ik: 1.0 }
};
// plumas de contorno sobre la superficie ya mallada (hereda los pesos de piel del vértice)
function bodyCards(ctx) {
  const { rig, mesh, sk, nV, lod } = ctx, P = rig.meta.P, C = P.pal, hp = rig.meta.hp, hr = P.hr, hipY = rig.meta.hipY, spn = rig.meta.spine, rnd = rngf(P.seed + 101), out = [], seen = new Set();
  const G = C.glow, I = C.iri;
  for (let v = 0; v < nV; v++) {
    const x = mesh.pos[v * 3], y = mesh.pos[v * 3 + 1], z = mesh.pos[v * 3 + 2], bi = sk.si[v * 4], bn = rig.bones[bi].name; let rg = null, Rc = null;
    if (bn === 'head') { if (z > hp[2] + hr * 0.3) continue; rg = RG.head; Rc = C.head; } else if (bn === 'jaw') continue;
    else if (bn.startsWith('neck')) { rg = RG.neck; Rc = mix3(C.neck[1], C.neck[0], smooth(hipY + 0.2, hipY + 0.85, y)); }
    else if (bn === 'chest') { rg = RG.chest; Rc = C.chest; } else if (bn === 'body') { if (y < hipY - 0.07) { rg = RG.belly; } else { rg = RG.back; } Rc = mix3(C.belly, C.back, smooth(hipY - 0.16, hipY + 0.12, y)); }
    else if (bn === 'tail1') { rg = RG.rump; Rc = C.back; } else if (bn.startsWith('leg')) { if (y > hipY - 0.32) { rg = RG.thigh; Rc = mix3(C.belly, C.back, 0.45); } else continue; }
    else if (/^wing[LR]_1$/.test(bn)) { rg = RG.shoulder; Rc = C.cov2[0]; } else continue;
    const cs = rg.cell * (lod ? 1.45 : 1), key = ((Math.floor(x / cs) + 512) * 1024 + (Math.floor(y / cs) + 512)) * 1024 + (Math.floor(z / cs) + 512);
    if (seen.has(key)) continue; seen.add(key);
    let best = 1e9, dx = 0, dy = 0, dz = -1;
    for (let k = 0; k < spn.length - 1; k++) { const a = spn[k], b = spn[k + 1], bx = b[0] - a[0], by = b[1] - a[1], bz = b[2] - a[2], l2 = bx * bx + by * by + bz * bz || 1e-9; let t = ((x - a[0]) * bx + (y - a[1]) * by + (z - a[2]) * bz) / l2; t = t < 0 ? 0 : t > 1 ? 1 : t; const ex = x - (a[0] + bx * t), ey = y - (a[1] + by * t), ez = z - (a[2] + bz * t), d2 = ex * ex + ey * ey + ez * ez; if (d2 < best) { best = d2; const il = 1 / Math.sqrt(l2); dx = bx * il; dy = by * il; dz = bz * il; } }
    const nx = mesh.nor[v * 3], ny = mesh.nor[v * 3 + 1], nz = mesh.nor[v * 3 + 2];
    let d = dx * nx + dy * ny + dz * nz; dx -= nx * d; dy -= ny * d; dz -= nz * d; let dl = Math.hypot(dx, dy, dz);
    if (dl < 0.15) { dx = -nx * ny; dy = 1 - ny * ny; dz = -nz * ny; dl = Math.hypot(dx, dy, dz) || 1; }
    dx /= dl; dy /= dl; dz /= dl;
    const lat = clamp(x / rg.half, -1, 1) * rg.splay; dx += lat * (1 - nx * nx); dy += lat * (-nx * ny); dz += lat * (-nx * nz);
    d = dx * nx + dy * ny + dz * nz; dx -= nx * d; dy -= ny * d; dz -= nz * d; dl = Math.hypot(dx, dy, dz) || 1; dx /= dl; dy /= dl; dz /= dl;
    dx += nx * rg.lift; dy += ny * rg.lift; dz += nz * rg.lift; dl = Math.hypot(dx, dy, dz) || 1; dx /= dl; dy /= dl; dz /= dl;
    const w0 = sk.sw[v * 4], w1 = sk.sw[v * 4 + 1], ws = w0 + w1;
    const rj = 0.9 + 0.2 * rnd(), c0 = mul3(Rc, 0.7 * rj), c1 = mul3(Rc, 1.14 * rj);
    out.push({ kind: 'pf', tile: 3, base: [x - nx * 0.012, y - ny * 0.012, z - nz * 0.012], dir: [dx, dy, dz], len: rg.len * (0.85 + 0.3 * rnd()), w: rg.w * (0.9 + 0.2 * rnd()), nrm: [nx, ny, nz], pr: PR_BODY, profFn: () => 1, bu: -0.06, bu2: 0.2, seg: lod ? 2 : 3, c0, c1, g0: G.body * rg.gk, g1: G.body * rg.gk * 1.2, iri: I.body * rg.ik, ph: rnd(), cup: 0.1, jit: 0.1, sk: [bi, ws > 1e-6 ? w0 / ws : 1, sk.si[v * 4 + 1], ws > 1e-6 ? w1 / ws : 0] });
  }
  rig.meta.nCards = out.length; return out;
}
function phxPaint(c) {
  const P = c.rig.meta.P, C = P.pal, b = c.bone, hp = c.rig.meta.hp, hr = P.hr; let col;
  if (/^wing/.test(b)) col = C.arm;
  else if (b === 'head' || b === 'jaw') { col = C.head; if ((b === 'head' && c.z > hp[2] + hr * 0.85) || (b === 'jaw' && c.z > hp[2] + hr * 0.5)) col = C.beak; }
  else if (b.startsWith('neck')) col = mix3(C.neck[1], C.neck[0], smooth(P.hy + 0.2, P.hy + 0.85, c.y));
  else if (b.startsWith('leg')) col = c.y < P.hy * 0.55 ? C.leg : C.back;
  else if (b === 'chest') col = mix3(C.chest, C.back, smooth(0, 0.7, c.ny));
  else col = mix3(C.belly, C.back, smooth(-0.5, 0.35, c.ny));
  const n = 1 + (fbm(c.x * 30, c.y * 30, c.z * 30, 3) - 0.5) * 0.25; return [col[0] * n, col[1] * n, col[2] * n];
}
function bodyMat(P) {
  const m = bodyMaterial({ detail: 'feather', dscale: 5, dstr: 0.3, rough: 0.55 }), prev = m.onBeforeCompile, cc = P.hy + 0.1;
  const U = { uSelf: { value: P.selfGlow }, uRimB: { value: vecL(P.rim) }, uChestC: { value: new V3(0, cc, 0.3) }, uChestK: { value: P.chestK }, uChestCol: { value: vecL(P.glow0) } };
  m.onBeforeCompile = sh => {
    prev(sh); Object.assign(sh.uniforms, U);
    sh.fragmentShader = 'uniform float uSelf; uniform vec3 uRimB; uniform vec3 uChestC; uniform float uChestK; uniform vec3 uChestCol;\n' + sh.fragmentShader.replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
      { float bNV = abs(dot(normal, normalize(vViewPosition))); vec3 dc = vOP - uChestC; float cm = exp(-dot(dc, dc) * 9.0);
        totalEmissiveRadiance += diffuseColor.rgb * uSelf + uChestCol * cm * uChestK + uRimB * pow(1.0 - bNV, 3.0) * 0.6; }`);
  };
  m.customProgramCacheKey = () => 'phx-body-1'; return m;
}

// ---------------------------------------------------------------
// RAZAS
// ---------------------------------------------------------------
const pal = o => o;
const BREEDS = {
  fenix: { name: 'Fénix de Fuego', rank: 'mitico', int: 10, pow: 9, spd: 9, hab: 'Cielos y montañas', diet: 'Llamas y rocío', eye: 0xffe070, hz: '*',
    desc: 'Ave de fuego que renace de sus cenizas. Su plumaje de oro y brasa ilumina la noche y su canto cura a los fieles.',
    over: { seed: 11,orb: [1.0, 0.62, 0.22], orbSize: 0.55, orbA: 0.5,  tail: { type: 'plumes', count: 9, len: 2.5, wid: 0.2, amp: 0.3, waves: 1.2 }, crest: { type: 'plume', n: 7, len: 0.38 }, flames: { tail: 10, wing: 7, crest: 2 }, sparks: 70, sparkCol: [1.0, 0.62, 0.16],
      glow0: [1.0, 0.85, 0.35], glow1: [1.0, 0.22, 0.04], glowK: 0.95, rim: [0.35, 0.12, 0.03], eyeA: [1, 0.8, 0.2], eyeB: [1, 0.45, 0.1], flame0: [1, 0.95, 0.6], flame1: [1, 0.3, 0.05], selfGlow: 0.1, chestK: 0.7,
      pal: pal({ prim: [[1.0, 0.78, 0.25], [0.85, 0.12, 0.05]], sec: [[1.0, 0.66, 0.16], [0.76, 0.1, 0.06]], cov: [[1.0, 0.86, 0.38], [1.0, 0.5, 0.12]], cov2: [[1.0, 0.9, 0.5], [1.0, 0.62, 0.16]], tail: [[1.0, 0.72, 0.18], [0.8, 0.08, 0.05]], tail2: [[1.0, 0.56, 0.12], [0.62, 0.06, 0.05]], crest: [[1.0, 0.9, 0.5], [1.0, 0.34, 0.08]],
        neck: [[1.0, 0.46, 0.08], [1.0, 0.72, 0.24]], chest: [1.0, 0.64, 0.18], back: [0.82, 0.18, 0.05], belly: [1.0, 0.7, 0.26], head: [0.95, 0.3, 0.07], arm: [0.9, 0.56, 0.16], beak: [0.96, 0.78, 0.3], leg: [0.86, 0.58, 0.18],
        glow: { prim: [0.35, 0.95], sec: [0.3, 0.85], cov: [0.3, 0.6], tail: [0.4, 1.0], crest: [0.6, 1.0], body: 0.55 }, iri: { prim: 0.05, cov: 0.12, tail: 0.05, crest: 0, body: 0.1 }, flameCol: [1, 1, 1] }) } },
  fenixAzul: { name: 'Fénix de Llama Azul', rank: 'mitico', int: 10, pow: 9, spd: 9, hab: 'Colinas y rocas', diet: 'Luz de estrellas', eye: 0xbfe8ff, hz: 'colinas roca',
    desc: 'Su fuego arde frío, azul como la luz de una estrella. Deja tras de sí una estela de llamas pálidas.',
    over: { seed: 23,orb: [0.55, 0.8, 1.0], orbSize: 0.58, orbA: 0.6,  tail: { type: 'plumes', count: 9, len: 2.6, wid: 0.2, amp: 0.34, waves: 1.3 }, crest: { type: 'plume', n: 8, len: 0.4 }, flames: { tail: 16, wing: 11, crest: 3 }, sparks: 80, sparkCol: [0.55, 0.82, 1.0],
      glow0: [0.85, 0.97, 1.0], glow1: [0.15, 0.3, 1.0], glowK: 1.1, rim: [0.1, 0.2, 0.55], eyeA: [0.8, 0.95, 1], eyeB: [0.2, 0.5, 1], flame0: [0.9, 0.98, 1.0], flame1: [0.15, 0.3, 1.0], selfGlow: 0.2, chestK: 0.8,
      pal: pal({ prim: [[0.55, 0.9, 1.0], [0.1, 0.2, 0.85]], sec: [[0.4, 0.75, 1.0], [0.08, 0.12, 0.7]], cov: [[0.7, 0.95, 1.0], [0.2, 0.45, 0.95]], cov2: [[0.8, 0.97, 1.0], [0.3, 0.55, 1.0]], tail: [[0.5, 0.85, 1.0], [0.15, 0.12, 0.8]], tail2: [[0.3, 0.6, 1.0], [0.1, 0.08, 0.6]], crest: [[0.85, 0.98, 1.0], [0.3, 0.5, 1.0]],
        neck: [[0.2, 0.45, 0.95], [0.5, 0.85, 1.0]], chest: [0.65, 0.92, 1.0], back: [0.1, 0.18, 0.7], belly: [0.6, 0.88, 1.0], head: [0.12, 0.25, 0.8], arm: [0.5, 0.7, 0.95], beak: [0.9, 0.9, 0.7], leg: [0.5, 0.6, 0.8],
        glow: { prim: [0.4, 1.0], sec: [0.35, 0.9], cov: [0.35, 0.7], tail: [0.5, 1.0], crest: [0.7, 1.0], body: 0.65 }, iri: { prim: 0.1, cov: 0.2, tail: 0.1, crest: 0, body: 0.15 }, flameCol: [1, 1, 1] }) } },
  fenixIris: { name: 'Fénix Prisma', rank: 'legendario', int: 9, pow: 7, spd: 9, hab: 'Cielos abiertos', diet: 'Rocío y luz', eye: 0xffd0f0, hz: '*',
    desc: 'Sus plumas iridiscentes reflejan todos los colores del cielo: al batir las alas parece un arcoíris con vida propia.',
    over: { seed: 37,orb: [1.0, 0.85, 1.0], orbSize: 0.42, orbA: 0.45,  tail: { type: 'plumes', count: 8, len: 2.3, wid: 0.22, amp: 0.3, waves: 1.1 }, crest: { type: 'fil', n: 18, len: 0.5 }, flames: { tail: 0, wing: 0, crest: 0 }, sparks: 90, sparkCol: [1.0, 0.9, 0.98], iri: 1,
      glow0: [1, 0.9, 0.9], glow1: [0.55, 0.6, 1.0], glowK: 0.55, rim: [0.28, 0.24, 0.45], eyeA: [1, 0.85, 0.5], eyeB: [0.5, 0.6, 1], flame0: [1, 0.9, 1], flame1: [0.6, 0.6, 1], selfGlow: 0.1, chestK: 0.35, iriF: 2.0, rough: 0.38,
      pal: pal({ prim: [[0.86, 0.72, 0.96], [0.36, 0.5, 0.95]], sec: [[0.96, 0.72, 0.86], [0.56, 0.46, 0.95]], cov: [[1.0, 0.78, 0.72], [0.72, 0.62, 1.0]], cov2: [[1.0, 0.84, 0.8], [0.78, 0.7, 1.0]], tail: [[0.82, 0.62, 0.95], [0.46, 0.42, 0.92]], tail2: [[0.96, 0.7, 0.82], [0.5, 0.4, 0.9]], crest: [[1, 1, 1], [0.85, 0.9, 1.0]],
        neck: [[0.5, 0.65, 0.95], [0.95, 0.72, 0.86]], chest: [1.0, 0.8, 0.72], back: [0.7, 0.46, 0.9], belly: [1.0, 0.84, 0.74], head: [0.7, 0.8, 1.0], arm: [0.88, 0.88, 0.96], beak: [0.9, 0.9, 0.95], leg: [0.8, 0.8, 0.9],
        glow: { prim: [0.25, 0.5], sec: [0.25, 0.45], cov: [0.25, 0.4], tail: [0.3, 0.55], crest: [0.4, 0.7], body: 0.25 }, iri: { prim: 0.85, cov: 1.0, tail: 0.75, crest: 0.25, body: 1.0 }, flameCol: [1, 1, 1] }) } },
  fenixAurora: { name: 'Fénix Aurora', rank: 'legendario', int: 9, pow: 7, spd: 10, hab: 'Colinas heladas', diet: 'Luz boreal', eye: 0xfff0a0, hz: 'colinas',
    desc: 'Su plumaje de filamentos de luz ondula como una aurora boreal, acompañado de chispas doradas que flotan a su alrededor.',
    over: { seed: 41,orb: [0.7, 1.0, 1.0], orbSize: 0.52, orbA: 0.6,  wingTile: 1, tail: { type: 'fil', count: 14, len: 3.1, wid: 0.2, amp: 0.34, waves: 1.4, spread: 0.55, shortK: 0.55, fan: 6 }, crest: { type: 'fil', n: 16, len: 0.46 }, flames: { tail: 5, wing: 4, crest: 1 }, sparks: 120, sparkSize: 0.09, sparkCol: [1.0, 0.66, 0.22],
      glow0: [0.9, 1.0, 1.0], glow1: [0.3, 0.7, 1.0], glowK: 1.2, rim: [0.15, 0.35, 0.6], eyeA: [1, 0.9, 0.5], eyeB: [0.4, 0.8, 1], flame0: [0.9, 1, 1], flame1: [0.3, 0.7, 1.0], selfGlow: 0.2, chestK: 0.8, fil: 1.0,
      pal: pal({ prim: [[0.72, 0.96, 1.0], [0.2, 0.58, 1.0]], sec: [[0.6, 0.9, 1.0], [0.25, 0.55, 1.0]], cov: [[0.85, 0.98, 1.0], [0.45, 0.8, 1.0]], cov2: [[0.9, 1.0, 1.0], [0.6, 0.88, 1.0]], tail: [[0.8, 0.95, 1.0], [1.0, 0.82, 0.4]], tail2: [[0.6, 0.9, 1.0], [1.0, 0.85, 0.5]], crest: [[1.0, 0.85, 0.4], [1.0, 0.96, 0.75]],
        neck: [[0.5, 0.82, 1.0], [0.9, 0.97, 1.0]], chest: [1.0, 0.86, 0.5], back: [0.4, 0.75, 1.0], belly: [0.9, 0.97, 1.0], head: [0.6, 0.88, 1.0], arm: [0.9, 0.8, 0.5], beak: [1.0, 0.85, 0.45], leg: [0.9, 0.75, 0.4],
        glow: { prim: [0.5, 0.9], sec: [0.45, 0.8], cov: [0.4, 0.7], tail: [0.5, 1.0], crest: [0.7, 1.0], body: 0.7 }, iri: { prim: 0.15, cov: 0.2, tail: 0.15, crest: 0, body: 0.2 }, flameCol: [1, 1, 1] }) } },
  fenixCeleste: { name: 'Fénix Celeste (凤)', rank: 'mitico', int: 10, pow: 8, spd: 9, hab: 'Cumbres nocturnas', diet: 'Luz de luna', eye: 0xffd860, hz: 'roca colinas',
    desc: 'Guardiana de los cielos nocturnos. Un orbe de luz arde en su pecho y su larga cola está salpicada de ojos dorados.',
    over: { seed: 53, tail: { type: 'eyes', count: 6, len: 3.0, amp: 0.28, waves: 0.9, spread: 0.7, shortK: 0.68, fan: 7 }, crest: { type: 'plume', n: 7, len: 0.4 }, flames: { tail: 0, wing: 3, crest: 2 }, sparks: 70, sparkCol: [0.6, 0.85, 1.0],
      glow0: [0.8, 0.95, 1.0], glow1: [0.2, 0.5, 1.0], glowK: 1.05, rim: [0.12, 0.3, 0.7], eyeA: [1, 0.8, 0.25], eyeB: [0.1, 0.7, 0.8], flame0: [0.85, 0.97, 1], flame1: [0.2, 0.45, 1], selfGlow: 0.2, chestK: 1.0, orb: [0.8, 0.95, 1.0], orbSize: 0.75,
      pal: pal({ prim: [[0.3, 0.6, 1.0], [0.04, 0.12, 0.6]], sec: [[0.25, 0.5, 1.0], [0.04, 0.1, 0.55]], cov: [[0.5, 0.85, 1.0], [0.12, 0.3, 0.85]], cov2: [[0.6, 0.92, 1.0], [0.2, 0.4, 0.9]], tail: [[0.1, 0.35, 0.8], [0.04, 0.5, 0.7]], tail2: [[0.12, 0.3, 0.8], [0.05, 0.15, 0.6]], crest: [[0.7, 0.95, 1.0], [0.25, 0.5, 1.0]],
        neck: [[0.1, 0.25, 0.75], [0.3, 0.6, 1.0]], chest: [0.8, 0.95, 1.0], back: [0.05, 0.14, 0.55], belly: [0.4, 0.7, 1.0], head: [0.08, 0.2, 0.7], arm: [0.7, 0.8, 0.95], beak: [0.95, 0.85, 0.5], leg: [0.8, 0.75, 0.5],
        glow: { prim: [0.35, 0.85], sec: [0.3, 0.75], cov: [0.4, 0.8], tail: [0.3, 0.7], crest: [0.7, 1.0], body: 0.6 }, iri: { prim: 0.15, cov: 0.3, tail: 0.25, crest: 0, body: 0.25 }, flameCol: [1, 1, 1] }) } },
  fenixLuna: { name: 'Fénix de Luna', rank: 'legendario', int: 9, pow: 6, spd: 8, hab: 'Cielos y costas', diet: 'Rocío lunar', eye: 0xdde8ff, hz: '*',
    desc: 'Blanca y plateada como la luna llena. Vuela en silencio y su luz pálida calma a quien la mira.',
    over: { seed: 67,orb: [0.9, 0.95, 1.0], orbSize: 0.42, orbA: 0.45,  tail: { type: 'plumes', count: 7, len: 2.4, wid: 0.2, amp: 0.26, waves: 1.0 }, crest: { type: 'fil', n: 14, len: 0.44 }, flames: { tail: 2, wing: 2, crest: 0 }, sparks: 60, sparkCol: [0.9, 0.95, 1.0],
      glow0: [1, 1, 1], glow1: [0.6, 0.7, 1.0], glowK: 0.6, rim: [0.3, 0.35, 0.55], eyeA: [0.9, 0.95, 1], eyeB: [0.5, 0.65, 1], flame0: [1, 1, 1], flame1: [0.6, 0.7, 1], selfGlow: 0.14, chestK: 0.5, rough: 0.42,
      pal: pal({ prim: [[1, 1, 1], [0.76, 0.84, 1.0]], sec: [[0.98, 0.98, 1], [0.8, 0.86, 1]], cov: [[1, 1, 1], [0.82, 0.88, 1.0]], cov2: [[1, 1, 1], [0.88, 0.92, 1.0]], tail: [[1, 1, 1], [0.7, 0.78, 1.0]], tail2: [[0.95, 0.96, 1], [0.72, 0.8, 1.0]], crest: [[1, 1, 1], [0.8, 0.88, 1.0]],
        neck: [[0.85, 0.9, 1.0], [1, 1, 1]], chest: [1, 1, 1], back: [0.82, 0.87, 1.0], belly: [1, 1, 1], head: [0.9, 0.93, 1.0], arm: [0.85, 0.88, 0.95], beak: [0.9, 0.85, 0.65], leg: [0.85, 0.8, 0.7],
        glow: { prim: [0.3, 0.6], sec: [0.3, 0.55], cov: [0.3, 0.5], tail: [0.35, 0.7], crest: [0.5, 0.9], body: 0.35 }, iri: { prim: 0.4, cov: 0.6, tail: 0.35, crest: 0.2, body: 0.5 }, flameCol: [1, 1, 1] }) } },
  fenixCeniza: { name: 'Fénix de Ceniza', rank: 'epico', int: 8, pow: 8, spd: 8, hab: 'Desiertos y rocas', diet: 'Brasas', eye: 0xff5030, hz: 'desierto roca',
    desc: 'Recién renacida de las cenizas: plumas de carbón con venas de brasa incandescente que se avivan al volar.',
    over: { seed: 79,orb: [1.0, 0.4, 0.1], orbSize: 0.55, orbA: 0.55,  tail: { type: 'plumes', count: 8, len: 2.3, wid: 0.2, amp: 0.3, waves: 1.2 }, crest: { type: 'plume', n: 7, len: 0.38 }, flames: { tail: 14, wing: 10, crest: 3 }, sparks: 90, sparkCol: [1.0, 0.42, 0.1],
      glow0: [1.0, 0.5, 0.1], glow1: [0.9, 0.12, 0.02], glowK: 1.6, rim: [0.4, 0.08, 0.02], eyeA: [1, 0.35, 0.1], eyeB: [0.8, 0.1, 0.05], flame0: [1, 0.7, 0.2], flame1: [0.9, 0.12, 0.02], selfGlow: 0.12, chestK: 0.7, rough: 0.7,
      pal: pal({ prim: [[0.16, 0.12, 0.12], [0.4, 0.05, 0.02]], sec: [[0.14, 0.1, 0.1], [0.34, 0.04, 0.02]], cov: [[0.2, 0.14, 0.14], [0.5, 0.08, 0.03]], cov2: [[0.22, 0.16, 0.15], [0.55, 0.12, 0.04]], tail: [[0.18, 0.1, 0.1], [0.7, 0.1, 0.02]], tail2: [[0.15, 0.09, 0.09], [0.5, 0.06, 0.02]], crest: [[0.9, 0.4, 0.1], [1.0, 0.7, 0.2]],
        neck: [[0.14, 0.1, 0.1], [0.22, 0.14, 0.13]], chest: [0.3, 0.14, 0.1], back: [0.1, 0.08, 0.08], belly: [0.25, 0.14, 0.12], head: [0.12, 0.08, 0.08], arm: [0.45, 0.3, 0.2], beak: [0.5, 0.35, 0.2], leg: [0.3, 0.22, 0.18],
        glow: { prim: [0.15, 0.7], sec: [0.12, 0.6], cov: [0.2, 0.5], tail: [0.15, 0.9], crest: [0.7, 1.0], body: 0.35 }, iri: { prim: 0.03, cov: 0.05, tail: 0.03, crest: 0, body: 0.05 }, flameCol: [1, 1, 1] }) } }
};
function defPhoenix(id, B) {
  const P = mergeP(BASE, Object.assign({ id, iri: 1 }, B.over));
  SP[id] = { id, kind: 'bird', phx: true, name: B.name, cat: 'leyendas', rank: B.rank, int: B.int, pow: B.pow, spd: B.spd, hab: B.hab, diet: B.diet, move: 'ground', fly: true, cell: 0.026, size: 2.2, glow: true, fastSDF: true,
    desc: B.desc, habits: { fly: 6, hover: 2, sing: 3, idle: 2 }, social: 'curious', sound: 'phoenix', eyeColor: B.eye, anim: { flapHz: 1.7 }, style: { detail: 'feather', dscale: 5, dstr: 0.3, rough: 0.55 },
    build: o => phxBuild(P, o), postMesh: bodyCards, paint: phxPaint, makeMaterial: () => bodyMat(P),
    frameExtra: rig => { const W = P.wing, hy = P.hy, ex = W.tip[0] + W.primLen * 0.5; return [[ex, hy + 0.35, 0], [-ex, hy + 0.35, 0], [0, 0.05, -0.4 - P.tail.len * 0.55], [0, hy + 1.2, 0.2], [0, 0, 0.5]]; },
    decorBuild: { pf: buildPF, pfl: buildFL }, decorMat: { pf: () => featherMaterial(P), pfl: () => flameMaterial(P) }, decorOrder: { pfl: 4 } };
  SP[id].phxHab = B.hz; return SP[id];
}
const PHX_IDS = Object.keys(BREEDS);
PHX_IDS.forEach(id => defPhoenix(id, BREEDS[id]));
return { BREEDS, PHX_IDS, BASE, defPhoenix, phxBuild };
}
