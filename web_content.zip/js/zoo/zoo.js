// Zoológico místico: catálogo de criaturas, plantillas (cuerpo + esqueleto) por especie, instancias y animación procedural.
// Las criaturas se generan por código; no hay archivos externos. Este módulo solo necesita THREE (se pasa como parámetro).
import { EDEN_ZOO_FACTORY } from './factory.js';
import { EDEN_ZOO_BUILD } from './build.js';
import { EDEN_ZOO_ANIM } from './anim.js';
import { EDEN_ZOO_SPECIES_A } from './speciesA.js';
import { EDEN_ZOO_SPECIES_B } from './speciesB.js';
import { EDEN_ZOO_SPECIES_C } from './speciesC.js';
import { EDEN_ZOO_SPECIES_D } from './speciesD.js';
import { EDEN_ZOO_DRAGONS } from './dragons.js';
import { EDEN_ZOO_DRAGON_EAST } from './dragonEast.js';
import { EDEN_ZOO_PHOENIX } from './phoenix.js';
import { ZOO_ORDER } from './meta.js';

export function createZoo(THREE, { skeletonClone = null, log = () => {} } = {}) {
  const Z = EDEN_ZOO_FACTORY(THREE, { skeletonClone });
  const B = EDEN_ZOO_BUILD(Z);
  const AN = EDEN_ZOO_ANIM(Z);
  const SP = {};
  const A = EDEN_ZOO_SPECIES_A(Z, SP);
  EDEN_ZOO_SPECIES_B(Z, SP);
  EDEN_ZOO_SPECIES_C(Z, SP, A);
  EDEN_ZOO_SPECIES_D(Z, SP, A);
  // Los dragones y fénix son adicionales: si uno fallase, el resto del zoológico sigue.
  for (const add of [EDEN_ZOO_DRAGONS, EDEN_ZOO_DRAGON_EAST, EDEN_ZOO_PHOENIX]) {
    try { add(Z, SP, A); } catch (e) { log('warn', 'zoo', e); }
  }
  ZOO_ORDER.forEach((id) => { if (SP[id] && !SP[id].kind) SP[id].kind = 'quad'; });

  const zoo = {
    THREE, Z, B, AN, SP,
    tpl: {}, // plantillas ya construidas: «id:lod» → plantilla
    thumbs: {}, // id → dataURL
    custom: {}, // modelos propios importados (se rellena en la entrega siguiente)
    // Milisegundos de trabajo seguidos al construir una criatura antes de ceder el hilo (menos = más fluido, pero tarda más).
    setBuildBudget(ms) { Z.BUDGET.ms = Math.max(2, Math.min(30, ms)); },
    list() { return ZOO_ORDER.filter((id) => SP[id]).map((id) => SP[id]); },
    // Construye (una a la vez, cediendo el hilo entre criaturas) y recuerda la plantilla de una especie.
    tplOf(id, lod = 0) {
      const key = `${id}:${lod}`;
      if (zoo.tpl[key]) return Promise.resolve(zoo.tpl[key]);
      if (lod && zoo.tpl[`${id}:0`]) return Promise.resolve(zoo.tpl[`${id}:0`]);
      const p = (queue.p[key] ||= new Promise((res, rej) => { queue.jobs.push({ id, lod, res, rej, key }); pump(); }));
      return p;
    },
    async makeInst(id, lod = 0) {
      const tpl = await zoo.tplOf(id, lod);
      return B.instantiate(tpl);
    },
    // Libera la memoria de GPU de una plantilla (geometría y texturas) si ya no se usa.
    disposeAll() {
      for (const k in zoo.tpl) { try { zoo.tpl[k].geo?.dispose?.(); } catch {} }
      zoo.tpl = {}; queue.p = {};
    },
  };

  const queue = { jobs: [], busy: false, p: {} };
  async function pump() {
    if (queue.busy) return;
    queue.busy = true;
    try {
      while (queue.jobs.length) {
        const j = queue.jobs.shift();
        try {
          const t = await B.buildTemplate(SP[j.id], { lod: j.lod || 0 });
          zoo.tpl[j.key] = t;
          j.res(t);
        } catch (e) {
          delete queue.p[j.key];
          log('warn', 'zoo', e);
          j.rej(e);
        }
        await new Promise((r) => setTimeout(r, 16));
      }
    } finally { queue.busy = false; }
  }
  return zoo;
}
