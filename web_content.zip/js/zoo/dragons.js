// Portado de EDEN-Visor-3D (zoológico místico) sin cambiar su lógica: fábrica independiente que recibe THREE por parámetro.
// Original: líneas 6240-6388 del HTML adjunto. Las criaturas se generan por código (SDF + surface nets), sin archivos externos.
export function EDEN_ZOO_DRAGONS(Z, SP, A) {
const { THREE, clamp, lerp, smooth, mix3, fbm, Rig, sweep, bez, taper } = Z;
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sc = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const mixp = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const noiseCol = (c, f, a) => 1 + (fbm(c.x * f, c.y * f, c.z * f, 3) - 0.5) * a;
const strand = (p0, d, len, droop, n) => { const out = []; let p = p0.slice(); const dl = Math.hypot(d[0], d[1], d[2]) || 1; let dx = d[0] / dl, dy = d[1] / dl, dz = d[2] / dl; for (let i = 0; i <= n; i++) { out.push(p.slice()); p = [p[0] + dx * len / n, p[1] + dy * len / n, p[2] + dz * len / n]; dy -= droop / n; const l = Math.hypot(dx, dy, dz); dx /= l; dy /= l; dz /= l; } return out; };
const rib = (r, path, w0, w1, c0, c1, o) => r.decor.push(Object.assign({ type: 'ribbon', kind: 'sheet', path, w0, w1, up: [1, 0, 0], c0, c1 }, o || {}));
const spike = (r, bone, p, h, w, dir) => { const d = dir || [0, 1, -0.35]; const l = Math.hypot(...d); r.rigid.push({ bone, mat: 'horn', geo: sweep([p, add(p, sc(d, h * 0.55 / l)), add(p, sc(d, h / l))], [w, w * 0.55, w * 0.06], 6) }); };
const claw = (r, bone, p, len, w, dir) => { const d = dir || [0, -0.35, 1]; const l = Math.hypot(...d); r.rigid.push({ bone, mat: 'claw', geo: sweep([p, add(p, sc(d, len * 0.5 / l)), add(add(p, sc(d, len * 0.9 / l)), [0, -len * 0.18, 0])], [w, w * 0.6, w * 0.05], 6) }); };
const eye = (r, bone, at, rad, slit) => r.rigid.push({ bone, eye: { r: rad, slit: !!slit }, at });

// membrana alar: costillas (dedos) + cuerpo; mallas con borde festoneado
function wingMembrane(r, side, sx, wrist, ribsPts, bodyPts, c0, c1, scallop) {
  const pos = [], col = [], idx = []; const ribs = ribsPts.concat([bodyPts]); const rows = ribs[0].length; const cols = 4;
  const grid = []; // grid[ri][row] -> [pts across]
  for (let k = 0; k < ribs.length - 1; k++) { const A_ = ribs[k], B_ = ribs[k + 1]; const base = pos.length / 3;
    for (let row = 0; row < rows; row++) { const t = row / (rows - 1); for (let s = 0; s <= cols; s++) { const u = s / cols; let p = mixp(A_[row], B_[row], u); const dip = Math.sin(Math.PI * u) * t * t * (scallop || 0.12); p = mixp(p, wrist, dip); pos.push(p[0], p[1], p[2]); const cc = mix3(c0, c1, clamp(t * 0.9 + Math.sin(u * 3.14) * 0.15, 0, 1)); const vein = 0.86 + 0.14 * Math.cos(u * 6.283 * 1) ; col.push(cc[0] * vein, cc[1] * vein, cc[2] * vein, 1); } }
    for (let row = 0; row < rows - 1; row++) for (let s = 0; s < cols; s++) { const a = base + row * (cols + 1) + s, b = a + 1, c = a + (cols + 1), d = c + 1; if (sx > 0) idx.push(a, c, b, b, c, d); else idx.push(a, b, c, b, d, c); } }
  r.decor.push({ type: 'mesh', kind: 'sheet', pos, col, idx });
}

// ===================== DRAGÓN OCCIDENTAL =====================
function westSkeleton(P) {
  P = P || {}; const S = P.S || 1; const r = new Rig('dragonW'); r.ks = 1.5 * S; const A_ = (x, y, z) => [x * S, y * S, z * S]; const sxs = [1, -1]; const sideN = sx => sx > 0 ? 'L' : 'R';
  r.bone('Hips', null, A_(0, 2.6, -1.6)); const spP = [[0, 2.72, -0.6], [0, 2.88, 0.4], [0, 3.02, 1.3], [0, 3.18, 1.85]]; const spN = ['Spine_1', 'Spine_2', 'Spine_3', 'Spine_4']; let par = 'Hips'; spN.forEach((n, i) => { r.bone(n, par, A_(...spP[i])); par = n; });
  // torso (proxy)
  r.ell('Hips', A_(0, 2.5, -1.55), [0.85 * S, 0.9 * S, 1.0 * S], 0.25 * S); r.cone('Spine_1', A_(0, 2.55, -1.0), A_(0, 2.7, 0.1), 0.82 * S, 0.88 * S, 0.2 * S);
  r.cone('Spine_2', A_(0, 2.7, 0.1), A_(0, 2.9, 1.0), 0.88 * S, 0.98 * S, 0.2 * S); r.ell('Spine_3', A_(0, 2.75, 1.25), [1.0 * S, 1.2 * S, 1.3 * S], 0.25 * S); r.ell('Spine_2', A_(0, 1.95, 0.3), [0.62 * S, 0.62 * S, 1.5 * S], 0.25 * S);
  // cuello en S (6 huesos) y cabeza
  const nP = [[0, 3.4, 2.15], [0, 3.85, 2.42], [0, 4.35, 2.55], [0, 4.85, 2.55], [0, 5.28, 2.68], [0, 5.58, 2.9]].map(p => A_(...p)); const nR = [0.6, 0.5, 0.42, 0.37, 0.34, 0.32].map(v => v * S);
  const neck = r.chain('Neck_', 'Spine_4', nP, nR, 0.22 * S); r.roles.neck = neck;
  const hb = A_(0, 5.72, 3.15); r.bone('Head', 'Neck_6', hb); r.bone('Jaw', 'Head', A_(0, 5.5, 3.35)); r.roles.head = 'Head'; r.roles.jaw = 'Jaw';
  r.ell('Head', A_(0, 5.78, 3.38), [0.5 * S, 0.45 * S, 0.64 * S], 0.12 * S); r.cone('Head', A_(0, 5.7, 3.8), A_(0, 5.52, 4.6), 0.35 * S, 0.22 * S, 0.1 * S, { sc: [1.05, 0.8, 1] });
  r.cone('Jaw', A_(0, 5.46, 3.45), A_(0, 5.36, 4.45), 0.24 * S, 0.14 * S, 0.06 * S, { sc: [1, 0.7, 1] });
  r.sub('Head', 'rc', [A_(0, 5.48, 3.7), A_(0, 5.42, 4.5), 0.03 * S, 0.03 * S], 0.015 * S);
  for (const sx of sxs) { const n = sideN(sx); r.ell('Head', A_(sx * 0.3, 6.08, 3.55), [0.2 * S, 0.1 * S, 0.3 * S], 0.08 * S); r.ell('Head', A_(sx * 0.1, 5.63, 4.52), [0.07 * S, 0.05 * S, 0.06 * S], 0.03 * S);
    eye(r, 'Head', A_(sx * 0.36, 5.9, 3.78), 0.1 * S, true);
    // cuernos (3 huesos por lado, se mecen)
    const hp = [A_(sx * 0.28, 6.1, 3.1), A_(sx * 0.5, 6.55, 2.62), A_(sx * 0.72, 6.95, 2.05), A_(sx * 0.82, 7.15, 1.55)]; const hr = [0.15 * S, 0.11 * S, 0.075 * S, 0.03 * S]; const hn = r.chain('Horn_' + n + '_', 'Head', hp, hr, 0.05 * S); (r.roles.horns = r.roles.horns || []).push(hn);
    const cp = [A_(sx * 0.42, 5.75, 3.05), A_(sx * 0.62, 5.7, 2.7), A_(sx * 0.82, 5.62, 2.3)]; const cn = r.chain('Cheek_' + n + '_', 'Head', cp, [0.09 * S, 0.06 * S, 0.02 * S], 0.04 * S); r.roles.horns.push(cn);
    for (let i = 0; i < 6; i++) { const t = i / 5; spike(r, 'Head', A_(sx * lerp(0.2, 0.34, t), lerp(6.12, 5.95, t), lerp(3.0, 2.7, t)), 0.28 * S, 0.05 * S, [sx * 0.3, 0.8, -0.8]); }
    for (let i = 0; i < 9; i++) { const t = i / 8; const p = A_(sx * (0.17 - 0.05 * t), 5.62 + 0.06, lerp(3.88, 4.5, t)); r.rigid.push({ bone: 'Head', mat: 'claw', geo: sweep([p, add(p, [0, -0.12 * S * (i === 3 ? 1.6 : 1), 0.006]), add(p, [0, -0.2 * S * (i === 3 ? 1.6 : 1), 0.014])], [0.03 * S, 0.016 * S, 0.002], 5) }); }
    for (let i = 0; i < 8; i++) { const t = i / 7; const p = A_(sx * (0.15 - 0.05 * t), 5.42, lerp(3.55, 4.4, t)); r.rigid.push({ bone: 'Jaw', mat: 'claw', geo: sweep([p, add(p, [0, 0.09 * S, 0.004]), add(p, [0, 0.16 * S, 0.01])], [0.025 * S, 0.013 * S, 0.002], 5) }); }
  }
  // cresta dorsal
  neck.forEach((n, i) => spike(r, n, add(r.byName[n].pos, [0, nR[i] * 0.92, -0.05 * S]), (0.42 - i * 0.03) * S, 0.07 * S, [0, 1, -0.5]));
  spN.forEach((n, i) => spike(r, n, add(r.byName[n].pos, [0, 0.95 * S, 0]), (0.45 - i * 0.03) * S, 0.08 * S, [0, 1, -0.45]));
  // patas con 3 dedos + garras
  r.roles.legs = {}; r.roles.toes = {};
  const legDef = (front, sx) => front ? { par: 'Spine_3', pts: [[sx * 0.88, 2.6, 1.25], [sx * 1.0, 1.62, 0.95], [sx * 0.95, 0.66, 1.5], [sx * 0.95, 0.2, 1.85]], rad: [0.52, 0.37, 0.27, 0.26], toe: 1 } : { par: 'Hips', pts: [[sx * 0.92, 2.5, -1.7], [sx * 1.02, 1.55, -1.05], [sx * 0.96, 0.86, -2.05], [sx * 0.96, 0.22, -1.62]], rad: [0.66, 0.46, 0.28, 0.27], toe: 1 };
  for (const sx of sxs) for (const front of [true, false]) {
    const key = (front ? 'F' : 'H') + (sx > 0 ? 'L' : 'R'); const d = legDef(front, sx); const nm = (front ? 'Front_Leg_' : 'Hind_Leg_') + sideN(sx) + '_'; const pts = d.pts.map(p => A_(...p)); const names = r.chain(nm, d.par, pts, d.rad.map(v => v * S), 0.14 * S); r.roles.legs[key] = names;
    if (front) r.ell(names[0], A_(sx * 0.88, 2.35, 1.2), [0.5 * S, 0.75 * S, 0.6 * S], 0.12 * S); else r.ell(names[0], A_(sx * 0.92, 2.2, -1.65), [0.6 * S, 0.9 * S, 0.8 * S], 0.14 * S);
    const foot = pts[3]; const toes = []; r.ell(names[3], add(foot, [0, -0.02 * S, 0.1 * S]), [0.32 * S, 0.12 * S, 0.3 * S], 0.05 * S);
    for (let t = -1; t <= 1; t++) { const dir = front ? 1 : 1; const b0 = add(foot, [t * 0.2 * S, -0.06 * S, 0.12 * S]), b1 = add(b0, [t * 0.04 * S, -0.03 * S, 0.34 * S]), b2 = add(b1, [t * 0.03 * S, -0.03 * S, 0.3 * S]); const tn = r.chain(nm.replace('Leg', 'Toe') + (t + 2) + '_', names[3], [b0, b1, b2], [0.13 * S, 0.1 * S, 0.07 * S], 0.04 * S); toes.push(tn); claw(r, tn[2], b2, 0.36 * S, 0.055 * S, [0, -0.4, 1]); }
    r.roles.toes[key] = toes;
  }
  // cola larga de 16 huesos
  const tp = [], tr = []; for (let i = 0; i < 16; i++) { const t = i / 15; tp.push(A_(Math.sin(t * 2.2) * 0.25, 2.4 - 1.95 * Math.pow(t, 0.75) + 0.12 * Math.sin(t * 5), -2.35 - i * 0.5)); tr.push((0.6 * Math.pow(1 - t, 1.15) + 0.05) * S); }
  const tail = r.chain('Tail_', 'Hips', tp, tr, 0.18 * S); r.roles.tails = tail;
  tail.forEach((n, i) => { if (i % 2 === 0 && i < 13) spike(r, n, add(r.byName[n].pos, [0, tr[i] * 0.95, 0]), (0.34 - i * 0.017) * S, 0.06 * S, [0, 1, -0.6]); });
  { const e = r.byName[tail[15]].pos; r.rigid.push({ bone: tail[15], mat: 'horn', geo: sweep([e, add(e, [0, 0.05 * S, -0.35 * S]), add(e, [0, -0.02 * S, -0.8 * S])], [0.12 * S, 0.08 * S, 0.005], 6) }); }
  // alas: hombro-codo-muñeca, pulgar y 4 dedos de 3 falanges
  r.roles.wings = {}; r.roles.fingers = {}; r.roles.thumbs = {};
  for (const sx of sxs) { const n = sideN(sx); const W = [[0.62, 3.65, 1.05], [2.2, 4.75, 0.35], [4.5, 5.4, 0.85]].map(p => A_(sx * p[0], p[1], p[2])); const wn = r.chain('Wing_' + n + '_', 'Spine_3', W, [0.26 * S, 0.17 * S, 0.12 * S], 0.06 * S); r.roles.wings[n] = wn;
    r.bone('Wing_' + n + '_Thumb', wn[2], add(W[2], [0, 0.2 * S, 0.15 * S])); r.bone('Wing_' + n + '_ThumbTip', 'Wing_' + n + '_Thumb', add(W[2], [sx * 0.08 * S, 0.62 * S, 0.5 * S])); r.cone('Wing_' + n + '_Thumb', add(W[2], [0, 0.2 * S, 0.15 * S]), add(W[2], [sx * 0.08 * S, 0.62 * S, 0.5 * S]), 0.08 * S, 0.03 * S, 0.03 * S); claw(r, 'Wing_' + n + '_ThumbTip', add(W[2], [sx * 0.08 * S, 0.62 * S, 0.5 * S]), 0.4 * S, 0.06 * S, [0.1 * sx, 0.5, 0.9]); r.roles.thumbs[n] = ['Wing_' + n + '_Thumb', 'Wing_' + n + '_ThumbTip'];
    const dirs = [[0.95, 0.28, -0.12, 5.9], [0.82, 0.16, -0.55, 5.6], [0.58, 0.04, -0.9, 5.0], [0.34, -0.04, -1.0, 3.9]]; const fch = []; const tips = [];
    dirs.forEach((d, fi) => { const dl = Math.hypot(d[0], d[1], d[2]); const L = d[3] * S; const seg = []; for (let k = 0; k <= 3; k++) { const f = k / 3; seg.push(add(W[2], [sx * d[0] / dl * L * f, d[1] / dl * L * f - 0.35 * S * f * f, d[2] / dl * L * f])); } const names = []; let pp = wn[2];
      for (let k = 0; k < 3; k++) { const bn = 'Wing_' + n + '_Finger' + (fi + 1) + '_' + (k + 1); r.bone(bn, pp, seg[k]); names.push(bn); pp = bn; }
      for (let k = 0; k < 3; k++) { const a = seg[k], b = seg[k + 1]; const rr0 = (0.1 - fi * 0.012) * (1 - k * 0.3) * S, rr1 = (0.1 - fi * 0.012) * (1 - (k + 1) * 0.3) * S; r.rigid.push({ bone: names[k], mat: 'horn', geo: sweep([a, mixp(a, b, 0.5), b], [rr0, (rr0 + rr1) * 0.5, Math.max(rr1, 0.02 * S)], 6) }); }
      fch.push(names); tips.push(seg); });
    r.roles.fingers[n] = fch;
    // membrana (cuerpo → dedos)
    const bodyPts = [0, 1, 2, 3].map(k => mixp(W[2], A_(sx * 0.95, 2.85, -1.5), k / 3));
    wingMembrane(r, n, sx, W[2], tips, bodyPts, P.mem0 || [0.1, 0.09, 0.1], P.mem1 || [0.3, 0.27, 0.28], 0.16);
    // membrana del brazo (propatagio)
    wingMembrane(r, n, sx, W[0], [[W[0], mixp(W[0], W[1], 0.5), W[1], mixp(W[1], W[2], 0.5)]], [W[0], mixp(W[0], tips[0][0], 0.2), mixp(W[1], tips[0][1], 0.3), W[2]], P.mem0 || [0.1, 0.09, 0.1], P.mem1 || [0.3, 0.27, 0.28], 0.0);
  }
  r.roles.spine = ['Hips'].concat(spN); r.roles.root = 'Hips'; const m = r.meta; m.L = 3.6 * S; m.H = 3.2 * S; m.hipY = 2.6 * S; m.stride = 2.4 * S; m.nt = hb; m.hR = 0.4 * S; m.hL = 0.9 * S; m.span = 9 * S; return r;
}
SP.dragonW = { id: 'dragonW', kind: 'dragonW', proto: true, noSpawn: true, name: 'Dragón Occidental · esqueleto', cat: 'leyendas', rank: 'mitico', int: 10, pow: 10, spd: 8, hab: 'Mundo de dragones', diet: 'Carnívoro', move: 'ground', fly: true, cell: 0.075, size: 8,
  desc: 'Prototipo de esqueleto del dragón occidental: cuello en S, tórax profundo, cuatro patas con tres dedos y garras, cola de 16 huesos y alas con brazo, pulgar y cuatro dedos. Pulsa 🦴 para ver los huesos.',
  habits: { wander: 2, fly: 4, rest: 3, idle: 3, sing: 1 }, social: 'ignore', sound: 'roar', eyeColor: 0xffb020, hornColor: 0xb9a77f, clawColor: 0xd9ccaa, anim: { flapAmp: 0.62, flapHz: 0.62, idleSpread: 0.0 },
  style: { detail: 'scales', dscale: 1.4, dstr: 1.6, rough: 0.34, metal: 0.25 },
  build() { return westSkeleton({}); },
  paint(c) { const n = noiseCol(c, 5, 0.25); const st = fbm(c.x * 12, c.y * 12, c.z * 12, 3); let col = mix3([0.07, 0.07, 0.085], [0.2, 0.2, 0.24], smooth(0.3, 0.9, st) * 0.7); const b = c.bone;
    const front = c.ny < -0.35 && (b.startsWith('Neck') || b.startsWith('Spine') || b === 'Hips' || b.startsWith('Tail')); if (front) { const pl = Math.abs(Math.sin(c.z * 3.4 + (b.startsWith('Tail') ? 0 : 0))); col = mix3(col, [0.82, 0.74, 0.58], smooth(0.1, 0.45, pl) * 0.9); }
    if (c.ny > 0.25 && b.startsWith('Neck')) col = mix3(col, [0.1, 0.55, 0.5], smooth(0.55, 0.75, fbm(c.x * 7, c.y * 7, c.z * 7, 2)) * 0.35);
    if (b.startsWith('Horn') || b.startsWith('Cheek')) col = [0.7, 0.62, 0.45]; if (/Toe/.test(b)) col = mix3(col, [0.12, 0.11, 0.12], 0.2);
    if (b === 'Head') col = mix3(col, [0.12, 0.12, 0.15], 0.2); return [col[0] * n, col[1] * n, col[2] * n]; } };

// ===================== DRAGÓN ORIENTAL =====================
function eastSkeleton(P) {
  P = P || {}; const S = P.S || 1; const claws = P.claws || 4; const wings = !!P.wings; const r = new Rig('dragonE'); r.ks = 1.6 * S; const sxs = [1, -1]; const sideN = sx => sx > 0 ? 'L' : 'R';
  const N = 34, Y0 = 3.2 * S; const path = u => { const z = lerp(-7.5, 6, u) * S, x = 2.4 * Math.sin(u * 7.6 + 0.4) * S * (0.3 + 0.7 * Math.sin(u * 3.1415)), y = Y0 + (0.9 * Math.sin(u * 5.2 + 1.0) + (u > 0.84 ? (u - 0.84) * 9 : 0)) * S; return [x, y, z]; };
  const rad = u => (u < 0.62 ? lerp(0.05, 0.7, Math.pow(u / 0.62, 0.7)) : lerp(0.7, 0.44, (u - 0.62) / 0.38)) * S;
  const pts = [], rds = []; for (let i = 0; i < N; i++) { const u = i / (N - 1); pts.push(path(u)); rds.push(rad(u)); }
  const rootI = Math.floor(N * 0.6);
  r.bone('Body_Root', null, pts[rootI]);
  const fwd = r.chain('Body_', 'Body_Root', pts.slice(rootI + 1), rds.slice(rootI + 1), 0.16 * S); // adelante hasta el cuello
  r.cone('Body_Root', pts[rootI], pts[rootI + 1], rds[rootI], rds[rootI + 1], 0.14 * S);
  const back = []; { let par = 'Body_Root'; for (let i = rootI - 1; i >= 0; i--) { const n = 'Tail_' + (rootI - i); r.bone(n, par, pts[i]); back.push(n); par = n; } for (let k = 0; k < back.length; k++) { const i = rootI - 1 - k; const pPrev = k === 0 ? pts[rootI] : pts[i + 1]; r.cone(k === 0 ? 'Body_Root' : back[k - 1], pPrev, pts[i], rds[i + 1], rds[i], 0.14 * S); } }
  const nNeck = 6; r.roles.neck = fwd.slice(-nNeck); r.roles.spine = ['Body_Root'].concat(fwd.slice(0, fwd.length - nNeck)); r.roles.tails = back; r.roles.root = 'Body_Root';
  // cabeza (escala Q: cabeza mayor que el cuerpo base)
  const Q = S * 1.35;
  const hp = pts[N - 1]; const hd = [pts[N - 1][0] - pts[N - 2][0], pts[N - 1][1] - pts[N - 2][1], pts[N - 1][2] - pts[N - 2][2]]; const hl = Math.hypot(...hd); const f = sc(hd, 1 / hl); const side = [f[2], 0, -f[0]]; const sl = Math.hypot(...side) || 1; const sd = sc(side, 1 / sl);
  const H = (a, b, c2) => add(add(add(hp, sc(f, a * Q)), sc([0, 1, 0], b * Q)), sc(sd, c2 * Q));
  r.bone('Head', fwd[fwd.length - 1], H(0.1, 0.0, 0)); r.bone('Jaw', 'Head', H(0.4, -0.2, 0)); r.roles.head = 'Head'; r.roles.jaw = 'Jaw';
  r.ell('Head', H(0.5, 0.05, 0), [0.36 * Q, 0.3 * Q, 0.5 * Q], 0.1 * Q); r.cone('Head', H(0.85, 0.0, 0), H(1.55, -0.08, 0), 0.26 * Q, 0.17 * Q, 0.1 * Q, { sc: [1.1, 0.78, 1] }); r.cone('Jaw', H(0.5, -0.22, 0), H(1.5, -0.25, 0), 0.19 * Q, 0.11 * Q, 0.06 * Q, { sc: [1, 0.6, 1] });
  for (const sx of sxs) { const n = sideN(sx); r.ell('Head', H(1.5, 0.0, sx * 0.12), [0.1 * Q, 0.07 * Q, 0.1 * Q], 0.04 * Q); r.ell('Head', H(0.7, 0.28, sx * 0.22), [0.17 * Q, 0.1 * Q, 0.3 * Q], 0.06 * Q); eye(r, 'Head', H(0.78, 0.27, sx * 0.36), 0.085 * Q, true);
    // cuernos (ramas) 4 huesos
    const hb = [H(0.35, 0.3, sx * 0.14), H(0.1, 0.75, sx * 0.3), H(-0.25, 1.25, sx * 0.45), H(-0.7, 1.6, sx * 0.55)]; const hn = r.chain('Horn_' + n + '_', 'Head', hb, [0.1 * Q, 0.075 * Q, 0.05 * Q, 0.02 * Q], 0.04 * Q); (r.roles.horns = r.roles.horns || []).push(hn);
    for (let k = 0; k < 2; k++) spike(r, hn[1 + k], r.byName[hn[1 + k]].pos, 0.5 * Q, 0.035 * Q, add(add(sc(f, -0.3), [0, 1, 0]), sc(sd, sx * 0.5)));
    // bigotes: 2 por lado, 10 huesos
    (r.roles.whiskers = r.roles.whiskers || []);
    for (let k = 0; k < 2; k++) { const base = H(1.45, -0.06 - k * 0.04, sx * 0.1); const wp = []; for (let j = 0; j <= 9; j++) { const t = j / 9; wp.push(add(add(add(base, sc(f, -t * 1.2 * Q + Math.sin(t * 3) * 0.2 * Q)), sc(sd, sx * (0.3 + t * 1.6) * Q)), [0, (-0.25 * t - 0.4 * t * t + 0.1 * Math.sin(t * 5) - k * 0.1 * t) * Q, 0])); } const wn = r.chain('Whisker_' + n + (k + 1) + '_', 'Head', wp, wp.map((_, j) => 0.022 * Q * (1 - j / 10) + 0.004), 0.02 * Q); r.roles.whiskers.push(wn); rib(r, wp, 0.02 * Q, 0.004 * Q, [0.95, 0.85, 0.5], [0.9, 0.75, 0.4], { up: [0, 1, 0] }); }
    // dientes
    for (let i = 0; i < 6; i++) { const t = i / 5; const p = H(lerp(0.95, 1.5, t), -0.09, sx * lerp(0.15, 0.08, t)); r.rigid.push({ bone: 'Head', mat: 'claw', geo: sweep([p, add(p, [0, -0.1 * Q, 0]), add(p, [0, -0.17 * Q * (i === 2 ? 1.5 : 1), 0])], [0.024 * Q, 0.012 * Q, 0.002], 5) }); }
  }
  // melena: 6 mechones de huesos desde la nuca, orientados hacia atrás
  r.roles.manes = []; for (let k = 0; k < 6; k++) { const off = (k - 2.5) * 0.14; const base = H(-0.05, 0.3 + (k % 2) * 0.1, off); const mp = []; for (let j = 0; j <= 6; j++) { const t = j / 6; mp.push(add(add(add(base, sc(f, -t * 1.6 * Q)), sc(sd, off * (1 + t * 2) * Q)), [0, (0.25 * Math.sin(t * 2.2) - 0.3 * t * t + (k % 2) * 0.1) * Q, 0])); } const mn = r.chain('Mane_' + (k + 1) + '_', 'Head', mp, mp.map((_, j) => 0.03 * Q * (1 - j / 8)), 0.02 * Q); r.roles.manes.push(mn); rib(r, mp, 0.2 * Q, 0.02 * Q, P.mane0 || [0.95, 0.75, 0.25], P.mane1 || [0.85, 0.4, 0.15], { up: [0, 1, 0], kind: 'sheet' }); }
  // melena dorsal / aleta: cintas a lo largo del lomo y cola
  fwd.forEach((n, i) => { if (i % 2 === 0) rib(r, strand(add(r.byName[n].pos, [0, rds[rootI + 1 + i] * 0.9, 0]), [0, 1, -0.7], 0.55 * S, 0.5, 5), 0.12 * S, 0.02 * S, P.mane0 || [0.95, 0.75, 0.25], P.mane1 || [0.85, 0.4, 0.15], { up: [1, 0, 0] }); });
  back.forEach((n, i) => { if (i % 2 === 0) rib(r, strand(add(r.byName[n].pos, [0, rds[rootI - 1 - i] * 0.9, 0]), [0, 1, -0.4], (0.5 - i * 0.012) * S, 0.5, 5), 0.1 * S, 0.02 * S, P.mane0 || [0.95, 0.75, 0.25], P.mane1 || [0.85, 0.4, 0.15], { up: [1, 0, 0] }); });
  rib(r, strand(r.byName[back[back.length - 1]].pos, [0.1, 0.3, -1], 2.0 * S, -0.1, 10), 0.8 * S, 0.05 * S, P.mane0 || [0.95, 0.75, 0.25], P.mane1 || [0.7, 0.3, 0.2], { up: [1, 0, 0] });
  // 4 patas con garras
  r.roles.legs = {}; r.roles.toes = {}; const legAt = (u, frontKey) => { const i = Math.round(u * (N - 1)); return i; };
  [['F', 0.8], ['H', 0.42]].forEach(([fh, u]) => { const i = Math.round(u * (N - 1)); const bn = i > rootI ? fwd[i - rootI - 1] : (i === rootI ? 'Body_Root' : back[rootI - i - 1]); const bp = pts[i]; const bnext = pts[Math.min(N - 1, i + 1)], bprev = pts[Math.max(0, i - 1)]; const tg = [bnext[0] - bprev[0], 0, bnext[2] - bprev[2]]; const tl = Math.hypot(...tg) || 1; const lat = [tg[2] / tl, 0, -tg[0] / tl];
    for (const sx of sxs) { const key = fh + (sx > 0 ? 'L' : 'R'); const nm = (fh === 'F' ? 'Front_Leg_' : 'Hind_Leg_') + sideN(sx) + '_'; const o = (a, b, c2) => add(add(add(bp, sc(lat, sx * a * S)), [0, b * S, 0]), sc(sc(tg, 1 / tl), c2 * S));
      const lp = [o(0.4, -0.25, 0), o(0.85, -0.55, 0.15), o(1.15, -0.85, 0.3), o(1.3, -1.0, 0.45)]; const names = r.chain(nm, bn, lp, [0.3 * S, 0.21 * S, 0.15 * S, 0.14 * S], 0.08 * S); r.roles.legs[key] = names; r.ell(names[3], o(1.33, -1.05, 0.55), [0.17 * S, 0.09 * S, 0.17 * S], 0.05 * S);
      const toes = []; for (let t = 0; t < claws; t++) { const a = (t - (claws - 1) / 2); const b0 = o(1.3 + a * 0.05, -1.04, 0.5), b1 = o(1.38 + a * 0.15, -1.1, 0.78), b2 = o(1.4 + a * 0.22, -1.16, 1.02); const tn = r.chain(nm.replace('Leg', 'Toe') + (t + 1) + '_', names[3], [b0, b1, b2], [0.075 * S, 0.055 * S, 0.035 * S], 0.025 * S); toes.push(tn); claw(r, tn[2], b2, 0.36 * S, 0.045 * S, [sx * a * 0.2, -0.45, 1]); }
      r.roles.toes[key] = toes; } });
  if (wings) { r.roles.wings = {}; r.roles.fingers = {}; /* alas opcionales (variantes con alas) */ for (const sx of sxs) { const n = sideN(sx); const bn = fwd[Math.round(0.72 * (N - 1)) - rootI - 1]; const bp = pts[Math.round(0.72 * (N - 1))]; const W = [[0.5, 0.5, 0], [1.6, 1.3, -0.4], [3.0, 1.6, -0.2]].map(p => add(bp, [sx * p[0] * S, p[1] * S, p[2] * S])); const wn = r.chain('Wing_' + n + '_', bn, W, [0.1 * S, 0.07 * S, 0.05 * S], 0.04 * S); r.roles.wings[n] = wn; r.roles.fingers[n] = []; } }
  const m = r.meta; m.L = 13.5 * S; m.H = Y0; m.hipY = Y0; m.stride = 4 * S; m.nt = hp; m.hR = 0.3 * S; m.hL = 0.6 * S; return r;
}
SP.dragonE = { id: 'dragonE', kind: 'dragonE', proto: true, noSpawn: true, name: 'Dragón Oriental · esqueleto', cat: 'leyendas', rank: 'mitico', int: 10, pow: 10, spd: 9, hab: 'Mundo de dragones', diet: 'Perlas de luz', move: 'air', fly: true, cell: 0.07, size: 12,
  desc: 'Prototipo de esqueleto del dragón oriental: 34 huesos de cuerpo serpentino, cola, cabeza con mandíbula, 4 cuernos, 4 bigotes, 6 mechones de melena y 4 patas con 4 garras. Pulsa 🦴 para ver los huesos.',
  habits: { fly: 6, sing: 2, idle: 1, rest: 1 }, social: 'curious', sound: 'chime', eyeColor: 0xffb020, hornColor: 0xd8c690, clawColor: 0xe8ddc0, anim: { k: 0.42 },
  style: { detail: 'scales', dscale: 6, dstr: 1.0, rough: 0.35, metal: 0.3, emissive: 0x20c080, emissiveI: 0.04 },
  build() { return eastSkeleton({ claws: 4 }); },
  paint(c) { const n = noiseCol(c, 10, 0.2); const sc2 = fbm(c.x * 18, c.y * 18, c.z * 18, 2); const b = c.bone; let col = mix3([0.92, 0.82, 0.55], [0.08, 0.5, 0.4], smooth(-0.8, 0.1, c.ny)); col = mix3(col, [0.04, 0.3, 0.34], smooth(0.5, 0.9, sc2) * 0.5 * smooth(-0.2, 0.5, c.ny));
    if (c.ny < -0.45) { const pl = Math.abs(Math.sin(c.z * 4.2)); col = mix3([0.95, 0.88, 0.62], [0.78, 0.66, 0.4], smooth(0.1, 0.5, pl)); }
    if (b.startsWith('Horn')) col = [0.88, 0.8, 0.58]; if (b === 'Head' || b === 'Jaw') col = mix3(col, [0.15, 0.55, 0.45], 0.3); if (/Leg|Toe/.test(b)) col = mix3(col, [0.1, 0.45, 0.38], 0.5); if (b.startsWith('Whisker') || b.startsWith('Mane')) col = [0.95, 0.8, 0.4];
    return [col[0] * n, col[1] * n, col[2] * n]; } };

return { westSkeleton, eastSkeleton };
}

