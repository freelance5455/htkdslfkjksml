// Voces procedurales de las criaturas (Web Audio, sin archivos). Portado de EDEN-Visor-3D; el contexto de audio se crea en el primer toque.
import { audio } from '../audio/engine.js';
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
// El contexto y el volumen de efectos son los del motor de audio compartido (audio/engine.js).
const AudioSystem = { get ctx() { return audio.ctx; }, get sfxGain() { return audio.sfx; } };
const ZOO_SND = {
  howl: [{ t: 0, d: 2.6, f0: 330, f1: 520, f2: 360, w: 'sawtooth', v: 0.22, lp: 900, vib: 5 }], yip: [0, 0.22, 0.45].map(t => ({ t, d: 0.16, f0: 900, f1: 1500, w: 'sawtooth', v: 0.16, lp: 2600 })),
  bellow: [{ t: 0, d: 1.2, f0: 120, f1: 190, f2: 130, w: 'sawtooth', v: 0.3, lp: 600, vib: 7 }], neigh: [{ t: 0, d: 1.0, f0: 520, f1: 1100, f2: 420, w: 'sawtooth', v: 0.2, lp: 2200, vib: 14 }],
  roar: [{ t: 0, d: 1.6, f0: 110, f1: 70, f2: 55, w: 'sawtooth', v: 0.34, lp: 500, vib: 11 }, { n: 1, t: 0, d: 1.5, f: 420, q: 0.7, v: 0.3 }], growl: [{ t: 0, d: 1.3, f0: 80, f1: 62, w: 'sawtooth', v: 0.3, lp: 420, vib: 22 }, { n: 1, t: 0, d: 1.2, f: 250, q: 1, v: 0.18 }],
  chime: [0, 0.35, 0.8].map((t, i) => ({ t, d: 2.2, f0: [784, 988, 1175][i], w: 'sine', v: 0.14, lp: 6000 })).concat([0, 0.35, 0.8].map((t, i) => ({ t, d: 1.4, f0: [784, 988, 1175][i] * 2.76, w: 'sine', v: 0.04 }))),
  hiss: [{ n: 1, t: 0, d: 1.3, f: 6500, q: 0.8, v: 0.22, hp: 3500 }], rumble: [{ t: 0, d: 2.8, f0: 48, f1: 38, w: 'sine', v: 0.55 }, { n: 1, t: 0, d: 2.6, f: 120, q: 0.7, v: 0.25 }], groan: [{ t: 0, d: 2.2, f0: 90, f1: 55, w: 'sawtooth', v: 0.26, lp: 380, vib: 3 }],
  phoenix: [0, 0.3, 0.65, 1.1].map((t, i) => ({ t, d: 1.6, f0: [880, 1175, 1318, 1760][i], f1: [990, 1320, 1480, 1970][i], w: 'sine', v: 0.15, lp: 5000, vib: 6 })), thunder: [{ n: 1, t: 0, d: 3.4, f: 90, q: 0.6, v: 0.7 }, { t: 0.1, d: 2.6, f0: 45, f1: 30, w: 'sine', v: 0.5 }],
  crane: [0, 0.5].map(t => ({ t, d: 0.45, f0: 1400, f1: 1000, w: 'sawtooth', v: 0.12, lp: 2600, vib: 28 })), screech: [{ t: 0, d: 0.9, f0: 2200, f1: 1500, w: 'sawtooth', v: 0.13, lp: 3800, vib: 30 }],
  song: [0, 0.14, 0.28, 0.5, 0.64, 0.78, 1.0].map((t, i) => ({ t, d: 0.11, f0: 2400 + ((i * 7) % 5) * 260, f1: 2900 + ((i * 3) % 4) * 300, w: 'sine', v: 0.1 }))
};
export const ZooSound = {
  ok() { const A = AudioSystem; return A && A.ctx && A.sfxGain && A.ctx.state === 'running'; },
  noiseBuf() { if (this._nb) return this._nb; const c = AudioSystem.ctx, n = c.sampleRate * 2, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; return (this._nb = b); },
  play(kind, vol, pan, pitch) {
    if (!this.ok() || vol < 0.01) return; const segs = ZOO_SND[kind]; if (!segs) return; const c = AudioSystem.ctx, t0 = c.currentTime + 0.02; pitch = pitch || 1;
    const out = c.createGain(); out.gain.value = vol; let node = out; try { const p = c.createStereoPanner(); p.pan.value = clamp(pan || 0, -1, 1); out.connect(p); p.connect(AudioSystem.sfxGain); } catch (_) { out.connect(AudioSystem.sfxGain); }
    let end = 0;
    for (const s of segs) {
      const t = t0 + s.t, d = s.d, g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(s.v, t + Math.min(0.08, d * 0.25)); g.gain.exponentialRampToValueAtTime(0.0001, t + d); end = Math.max(end, s.t + d);
      let src;
      if (s.n) { src = c.createBufferSource(); src.buffer = this.noiseBuf(); src.loop = true; const f = c.createBiquadFilter(); f.type = s.hp ? 'highpass' : 'bandpass'; f.frequency.value = (s.hp || s.f) * pitch; f.Q.value = s.q || 1; src.connect(f); f.connect(g); src.start(t, Math.random()); src.stop(t + d + 0.05); }
      else {
        src = c.createOscillator(); src.type = s.w || 'sine'; src.frequency.setValueAtTime(s.f0 * pitch, t); if (s.f1) src.frequency.linearRampToValueAtTime(s.f1 * pitch, t + d * (s.f2 ? 0.5 : 1)); if (s.f2) src.frequency.linearRampToValueAtTime(s.f2 * pitch, t + d);
        let last = src; if (s.vib) { const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = s.vib; lg.gain.value = s.f0 * pitch * 0.025; l.connect(lg); lg.connect(src.frequency); l.start(t); l.stop(t + d + 0.05); }
        if (s.lp) { const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = s.lp * pitch; src.connect(f); last = f; }
        last.connect(g); src.start(t); src.stop(t + d + 0.05);
      }
      g.connect(out);
    }
    setTimeout(() => { try { out.disconnect(); } catch (_) {} }, (end + 0.5) * 1000);
  }
};

// ---------- retarget de modelos importados ----------

// Se llama desde un toque del usuario (los navegadores no dejan sonar antes). Crea el contexto una sola vez.
export function zooAudioStart() {
  return audio.start();
}
