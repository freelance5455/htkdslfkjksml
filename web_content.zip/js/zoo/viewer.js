// Visor 3D de una criatura (órbita con el dedo, pellizco para acercar, esqueleto) y miniaturas de la galería.
// Basado en el visor del zoológico de EDEN-Visor-3D; aquí recibe THREE y el zoológico como parámetros.
import { ZOO_CATS } from './meta.js';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

// Estados de animación que ofrece cada criatura en el visor.
export function statesFor(sp) {
  const st = ['idle', 'walk', 'run', 'rest', 'sing', 'graze', 'roar', 'alert'];
  if (sp.fly || sp.move === 'air') st.push('fly', 'hover', 'glide');
  if (sp.move === 'water' || sp.kind === 'kraken') st.push('swim');
  if (sp.kind === 'dragonE') st.push('coil');
  return st;
}

export function createCreatureViewer({ THREE, zoo, canvas, id, state = 'idle', pixelRatioCap = 2, onError = () => {} }) {
  const sp = zoo.SP[id];
  const bg = ZOO_CATS[sp.cat].bg;
  const vr = { alive: true, az: -0.7, el: 0.16, dist: 1, auto: true, last: performance.now(), state, skelMode: 0, r: 2, ctr: new THREE.Vector3(0, 1, 0) };
  const rd = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  rd.setPixelRatio(Math.min(globalThis.devicePixelRatio || 1, pixelRatioCap));
  rd.outputColorSpace = THREE.SRGBColorSpace;
  rd.toneMapping = THREE.ACESFilmicToneMapping;
  rd.shadowMap.enabled = true;
  const sc = new THREE.Scene();
  sc.background = new THREE.Color(bg);
  sc.fog = new THREE.Fog(bg, 30, 120);
  sc.add(new THREE.HemisphereLight(0xdfeaff, 0x3a3326, 1.1));
  const sun = new THREE.DirectionalLight(0xfff0d8, 2.4);
  sun.position.set(5, 9, 6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sc.add(sun);
  const ground = new THREE.Mesh(new THREE.CircleGeometry(60, 48), new THREE.MeshStandardMaterial({ color: 0x33432d, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  sc.add(ground);
  const cam = new THREE.PerspectiveCamera(36, 1, 0.02, 500);
  let inst = null;
  let c = null; // animador de la criatura
  let skel = null;

  function frame() {
    inst.group.updateMatrixWorld(true);
    const tpl = zoo.tpl[`${id}:0`];
    let r = (sp.size || 1) * 1.1;
    if (tpl?.geo) {
      tpl.geo.computeBoundingSphere();
      r = tpl.geo.boundingSphere.radius * 1.15;
      vr.ctr = tpl.geo.boundingSphere.center.clone();
    } else vr.ctr = new THREE.Vector3(0, r * 0.5, 0);
    if (sp.move === 'air' || sp.kind === 'winged') r *= 1.1;
    if (sp.kind === 'dragonW') r *= 1.35;
    vr.r = r;
    sc.fog.near = r * 3;
    sc.fog.far = r * 12;
    ground.scale.setScalar(Math.max(1, r / 14));
    const s2 = sun.shadow.camera;
    s2.left = s2.bottom = -r * 1.4;
    s2.right = s2.top = r * 1.4;
    s2.far = r * 6;
    s2.updateProjectionMatrix();
  }

  // ── Esqueleto: huesos como varillas y articulaciones, coloreados por función ─────────────────
  function buildSkel() {
    const bones = inst.bones.filter((b) => b.parent && b.parent.isBone);
    const roles = inst.rig?.roles || {};
    const col = {};
    const put = (arr, hex) => {
      if (!arr) return;
      (Array.isArray(arr) ? arr : [arr]).forEach((x) => { if (Array.isArray(x)) put(x, hex); else if (x && !col[x]) col[x] = hex; });
    };
    put(roles.head, 0xffe066); put(roles.jaw, 0xffc533); put(roles.neck, 0xffd84d); put(roles.spine, 0xffb020);
    put(roles.tails, 0xff7a3d); put(roles.horns, 0xffffff); put(roles.whiskers, 0x66ff99); put(roles.manes, 0x44dd88);
    for (const k in roles.legs || {}) put(roles.legs[k], 0x4aa8ff);
    for (const k in roles.toes || {}) put(roles.toes[k], 0x35e8e0);
    for (const k in roles.wings || {}) put(roles.wings[k], 0xff4d6a);
    for (const k in roles.fingers || {}) put(roles.fingers[k], 0xff8fb0);
    for (const k in roles.thumbs || {}) put(roles.thumbs[k], 0xffb0c8);
    const R = vr.r * 0.011;
    const mat = new THREE.MeshBasicMaterial({ depthTest: false, transparent: true, opacity: 0.95 });
    const sticks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.55, 1, 1, 6, 1), mat, bones.length);
    const joints = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 8, 6), mat, inst.bones.length);
    sticks.renderOrder = joints.renderOrder = 20;
    sticks.frustumCulled = joints.frustumCulled = false;
    const cc = new THREE.Color();
    bones.forEach((b, i) => sticks.setColorAt(i, cc.setHex(col[b.name] || 0xcccccc)));
    inst.bones.forEach((b, i) => joints.setColorAt(i, cc.setHex(col[b.name] || 0xcccccc).multiplyScalar(1.25)));
    const group = new THREE.Group();
    group.add(sticks, joints);
    sc.add(group);
    skel = { group, sticks, joints, bones, R };
  }
  const A = new THREE.Vector3(), Bv = new THREE.Vector3(), D = new THREE.Vector3(), UP = new THREE.Vector3(0, 1, 0);
  const Q = new THREE.Quaternion(), M = new THREE.Matrix4(), S = new THREE.Vector3();
  function updateSkel() {
    if (!skel) return;
    inst.group.updateMatrixWorld(true);
    skel.bones.forEach((bn, i) => {
      bn.parent.getWorldPosition(A);
      bn.getWorldPosition(Bv);
      D.subVectors(Bv, A);
      const len = D.length() || 1e-4;
      D.divideScalar(len);
      Q.setFromUnitVectors(UP, D);
      const wd = Math.min(skel.R, len * 0.18);
      S.set(wd, len, wd);
      M.compose(A.clone().add(Bv).multiplyScalar(0.5), Q, S);
      skel.sticks.setMatrixAt(i, M);
    });
    inst.bones.forEach((bn, i) => {
      bn.getWorldPosition(A);
      const r = skel.R * (/finger|toe|whisker|mane|horn/i.test(bn.name) ? 0.8 : 1.5);
      M.compose(A, Q.identity(), S.set(r, r, r));
      skel.joints.setMatrixAt(i, M);
    });
    skel.sticks.instanceMatrix.needsUpdate = true;
    skel.joints.instanceMatrix.needsUpdate = true;
    if (skel.sticks.instanceColor) skel.sticks.instanceColor.needsUpdate = true;
    if (skel.joints.instanceColor) skel.joints.instanceColor.needsUpdate = true;
  }

  function setSkel(mode) {
    if (!inst) return 0;
    vr.skelMode = mode;
    try { if (mode && !skel) buildSkel(); } catch (e) { onError(e); }
    inst.group.traverse((o) => { if (o.isMesh) o.visible = mode !== 2; });
    if (skel) skel.group.visible = mode > 0;
    return mode;
  }

  function setState(s) {
    vr.state = s;
    if (c) zoo.AN.setState(c, s);
  }

  function tick(dt) {
    const w = canvas.clientWidth, hh = canvas.clientHeight, pr = rd.getPixelRatio();
    if (w && (canvas.width !== Math.floor(w * pr) || canvas.height !== Math.floor(hh * pr))) {
      rd.setSize(w, hh, false);
      cam.aspect = w / hh;
      cam.updateProjectionMatrix();
    }
    if (vr.auto) vr.az += dt * 0.25;
    const st = vr.state;
    zoo.AN.update(c, dt, st === 'run' ? 5 : st === 'walk' ? 1.6 : 0.6);
    const east = c?.sp?.kind === 'dragonE';
    const kzc = (east && c.cw) || 0;
    const zf = 1 - 0.55 * kzc * kzc * (3 - 2 * kzc);
    const d = (vr.r / Math.tan((cam.fov * Math.PI) / 360)) * 0.9 * vr.dist * zf;
    const k = vr.ctr, cy = k.y + kzc * vr.r * 0.2;
    cam.position.set(k.x + Math.sin(vr.az) * Math.cos(vr.el) * d, cy + Math.sin(vr.el) * d, k.z + Math.cos(vr.az) * Math.cos(vr.el) * d);
    cam.lookAt(k.x, cy, k.z);
    if (east) c.look = cam.position;
    if (vr.skelMode) updateSkel();
    rd.render(sc, cam);
  }
  function loop() {
    if (!vr.alive) return;
    vr.raf = requestAnimationFrame(loop);
    const now = performance.now();
    const dt = Math.min(0.05, (now - vr.last) / 1000);
    vr.last = now;
    try { tick(dt); } catch (e) { onError(e); vr.alive = false; }
  }

  // ── Gestos: un dedo gira, dos dedos acercan ───────────────────────────────────────────────────
  const pts = new Map();
  let pinch = 0;
  const onDown = (e) => { pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); vr.auto = false; try { canvas.setPointerCapture(e.pointerId); } catch {} };
  const onMove = (e) => {
    const p = pts.get(e.pointerId);
    if (!p) return;
    if (pts.size === 1) {
      vr.az -= (e.clientX - p.x) * 0.008;
      vr.el = clamp(vr.el + (e.clientY - p.y) * 0.006, -0.1, 1.3);
    }
    p.x = e.clientX; p.y = e.clientY;
    if (pts.size === 2) {
      const [a, b] = [...pts.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (pinch) vr.dist = clamp((vr.dist * pinch) / d, 0.4, 3);
      pinch = d;
    }
  };
  const onUp = (e) => { pts.delete(e.pointerId); if (pts.size < 2) pinch = 0; };
  const onWheel = (e) => { e.preventDefault(); vr.dist = clamp(vr.dist * (1 + e.deltaY * 0.001), 0.4, 3); };
  canvas.addEventListener('pointerdown', onDown);
  canvas.addEventListener('pointermove', onMove);
  canvas.addEventListener('pointerup', onUp);
  canvas.addEventListener('pointercancel', onUp);
  canvas.addEventListener('wheel', onWheel, { passive: false });

  const ready = (async () => {
    inst = await zoo.makeInst(id, 0);
    if (!vr.alive) return false;
    sc.add(inst.group);
    c = zoo.AN.make(inst, { kind: sp.kind });
    zoo.AN.setState(c, vr.state);
    frame();
    loop();
    return true;
  })();

  function dispose() {
    vr.alive = false;
    cancelAnimationFrame(vr.raf);
    canvas.removeEventListener('pointerdown', onDown);
    canvas.removeEventListener('pointermove', onMove);
    canvas.removeEventListener('pointerup', onUp);
    canvas.removeEventListener('pointercancel', onUp);
    canvas.removeEventListener('wheel', onWheel);
    try { skel?.sticks.geometry.dispose(); skel?.joints.geometry.dispose(); skel?.sticks.material.dispose(); } catch {}
    ground.geometry.dispose();
    ground.material.dispose();
    try { rd.dispose(); rd.forceContextLoss(); } catch {}
  }
  return { ready, setState, setSkel, dispose, get skelMode() { return vr.skelMode; } };
}

// Miniaturas: un solo renderizador reutilizado; se genera de una en una y se devuelve un dataURL JPEG.
export function createThumbMaker({ THREE, zoo }) {
  let rd = null, sc = null, cam = null, cv = null;
  function ensure() {
    if (rd) return;
    cv = document.createElement('canvas');
    rd = new THREE.WebGLRenderer({ canvas: cv, antialias: true, preserveDrawingBuffer: true });
    rd.setSize(220, 220, false);
    rd.setPixelRatio(1);
    rd.outputColorSpace = THREE.SRGBColorSpace;
    rd.toneMapping = THREE.ACESFilmicToneMapping;
    rd.toneMappingExposure = 1.7;
    sc = new THREE.Scene();
    sc.add(new THREE.HemisphereLight(0xdfeaff, 0x3a3326, 1.15));
    const sun = new THREE.DirectionalLight(0xfff0d8, 2.4);
    sun.position.set(4, 7, 5);
    sc.add(sun);
    cam = new THREE.PerspectiveCamera(32, 1, 0.02, 400);
  }
  async function make(id) {
    if (zoo.thumbs[id]) return zoo.thumbs[id];
    ensure();
    const sp = zoo.SP[id];
    const inst = await zoo.makeInst(id, 1);
    sc.background = new THREE.Color(ZOO_CATS[sp.cat].bg);
    const grd = new THREE.Mesh(new THREE.CircleGeometry(40, 32), new THREE.MeshStandardMaterial({ color: 0x2f3b2a, roughness: 1 }));
    grd.rotation.x = -Math.PI / 2;
    sc.add(grd, inst.group);
    zoo.AN.pose(inst, { state: 'idle' });
    inst.group.updateMatrixWorld(true);
    const tp = zoo.tpl[`${id}:1`] || zoo.tpl[`${id}:0`];
    let ctr, r;
    if (tp?.geo) { tp.geo.computeBoundingSphere(); ctr = tp.geo.boundingSphere.center.clone(); r = tp.geo.boundingSphere.radius * 0.95; }
    else { ctr = new THREE.Vector3(0, (sp.size || 1) * 0.5, 0); r = sp.size || 1; }
    if (sp.kind === 'winged' || sp.move === 'air') r *= 1.2;
    const az = -0.65, el = 0.18, dist = r / Math.tan((cam.fov * Math.PI) / 360);
    cam.position.set(ctr.x + Math.sin(az) * Math.cos(el) * dist, ctr.y + Math.sin(el) * dist, ctr.z + Math.cos(az) * Math.cos(el) * dist);
    cam.lookAt(ctr);
    cam.updateProjectionMatrix();
    rd.render(sc, cam);
    zoo.thumbs[id] = cv.toDataURL('image/jpeg', 0.85);
    sc.remove(inst.group, grd);
    grd.geometry.dispose();
    grd.material.dispose();
    return zoo.thumbs[id];
  }
  function dispose() { try { rd?.dispose(); rd?.forceContextLoss(); } catch {} rd = null; }
  return { make, dispose };
}
