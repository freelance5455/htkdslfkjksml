/* تب برنامه: هفتگی، کارهای ثابت، عقب‌افتادگی، یادآور، کنکور، دفترچه، برنامه‌ی متنی. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var pl = App.plan;
  var S = function () { return App.S; };
  var WDO = [[6, 'شنبه'], [0, 'یکشنبه'], [1, 'دوشنبه'], [2, 'سه‌شنبه'], [3, 'چهارشنبه'], [4, 'پنجشنبه'], [5, 'جمعه']];

  App.views.plan = function () {
    return App.upgradeNotice() + wpCard() + busyCard() + blCard() + rmCard() + cdCard() + jrCard() + progCard();
  };

  // ---- برنامه‌ی هفتگی ----
  function wpCard() {
    var W = S().wp || [];
    var f = App.form('wpf', { day: 6, s: '16:00', e: '18:00', t: '', k: 'study' });
    var byDay = WDO.map(function (d) {
      var L = W.filter(function (x) { return x.day === d[0]; }).sort(function (a, b) { return u.tmin(a.s0) - u.tmin(b.s0); });
      if (!L.length) return '';
      return '<div class="day-block' + (d[0] === new Date().getDay() ? ' today' : '') + '"><b>' + d[1] + (d[0] === new Date().getDay() ? ' (امروز)' : '') + '</b>' +
        L.map(function (x) { return '<div class="li"><span>' + u.hm(u.tmin(x.s0)) + ' تا ' + u.hm(u.tmin(x.e0)) + ' — ' + u.esc(x.t) + (x.k === 'class' ? ' <span class="pill">کلاس</span>' : '') + '</span>' + App.sm('🗑', 'wp-del', { key: pl.bkey(x) }) + '</div>'; }).join('') + '</div>';
    }).join('');
    var body = (W.length ? byDay : '<p class="mu">هنوز برنامه‌ی هفتگی نداری. می‌توانی بلوک‌ها را یکی‌یکی اضافه کنی، برنامه‌ات را از متن بچسبانی، یا از مشاور بخواهی.</p>') +
      '<details class="inner"><summary>➕ افزودن بلوک</summary><div class="grid2">' + App.field('روز', App.select('wpf', 'day', WDO.map(function (d) { return [String(d[0]), d[1]]; }))) +
      App.field('عنوان', App.input('wpf', 't', { ph: 'مثلاً فیزیک — تست فصل ۲', maxlength: 80 })) + '</div>' +
      '<div class="grid2">' + App.field('از ساعت', App.timeField('wpf', 's', { def: '16:00', label: 'از ساعت' })) + App.field('تا ساعت', App.timeField('wpf', 'e', { def: '18:00', label: 'تا ساعت' })) + '</div>' +
      App.field('نوع', App.select('wpf', 'k', [['study', 'مطالعه'], ['class', 'کلاس'], ['other', 'سایر']])) +
      App.btn('افزودن بلوک', 'wp-add', {}, 'mt') + '</details>' +
      '<div class="q-row mt">' + App.sm('📋 کپی برنامه‌ی امروز', 'copy-today-wp') + App.sm('🗑 حذف همه', 'wp-clear') + App.sm('🤖 برنامه‌ی هفتگی با مشاور', 'ai-ask', { q: 'wplan', tab: 'plan' }) + '</div>';
    return App.card('🗓 برنامه‌ی هفتگی من', body, { open: true });
  }
  App.act['wp-add'] = function () {
    var f = App.form('wpf', {});
    var s0 = u.validHM(f.s) ? f.s : null, e0 = u.validHM(f.e) ? f.e : null;
    if (!s0 || !e0 || u.tmin(e0) <= u.tmin(s0)) { App.alert('ساعت پایان باید بعد از ساعت شروع باشد'); return; }
    var t = String(f.t || '').trim().slice(0, 80);
    if (!t) { App.alert('عنوان بلوک را بنویس'); return; }
    S().wp.push({ day: +f.day, s0: u.normHM(s0), e0: u.normHM(e0), t: t, k: f.k || 'study' });
    f.t = ''; App.save(); App.render(); App.toast('✅ بلوک افزوده شد');
  };
  App.act['wp-del'] = function (el) {
    var key = el.getAttribute('data-key');
    var i = S().wp.findIndex(function (x) { return pl.bkey(x) === key; });
    if (i >= 0) S().wp.splice(i, 1);
    App.save(); App.render();
  };
  App.act['wp-clear'] = function () {
    if (!App.confirm('برنامه‌ی هفتگی پاک شود؟')) return;
    S().wp = []; App.save(); App.render();
  };
  App.act['copy-today-wp'] = function () {
    u.copyText(pl.wpText() || 'امروز بلوکی نداری').then(function (ok) { App.toast(ok ? 'کپی شد ✅' : 'کپی انجام نشد'); });
  };

  // ---- کارهای ثابت + ساعت خواب و بیداری ----
  function busyCard() {
    var B = (S().busy || []).filter(function (b) { return b.r !== 'today' || b.d === u.todayISO(); }).sort(function (a, b) { return u.tmin(a.s) - u.tmin(b.s); });
    var f = App.form('busy', { t: '', s: '14:00', e: '16:00', r: 'all' });
    var w = App.form('wake', { w: S().wake || '06:30', z: S().sleep || '23:00' });
    return App.card('🗓 کارهای ثابت من', '<p class="mu">هر کاری که توی روز داری (مدرسه، کلاس، ورزش، غذا…) بنویس؛ برنامه‌ی مطالعه خودکار دور آن‌ها چیده می‌شود.</p>' +
      B.map(function (b) { return '<div class="li"><span>' + u.esc(b.t) + '<br><span class="mu">' + u.hm(u.tmin(b.s)) + ' تا ' + u.hm(u.tmin(b.e)) + ' · ' + pl.RL(b) + '</span></span>' + App.sm('🗑', 'busy-del', { key: b.id }) + '</div>'; }).join('') +
      '<div class="q-row mt">' + ['🏫 مدرسه', '⚽ فوتبال', '🍽 غذا', '😴 چرت', '🚌 رفت‌وآمد', '📱 استراحت'].map(function (x) { return App.sm(x, 'busy-preset', { v: x.slice(x.indexOf(' ') + 1) }); }).join('') + '</div>' +
      App.field('عنوان (مثلاً کلاس فیزیک، فوتبال)', App.input('busy', 't', { ph: 'عنوان', maxlength: 80 })) +
      '<div class="grid2">' + App.field('از ساعت', App.timeField('busy', 's', { def: '14:00', label: 'از ساعت' })) + App.field('تا ساعت', App.timeField('busy', 'e', { def: '16:00', label: 'تا ساعت' })) + '</div>' +
      App.field('تکرار', App.select('busy', 'r', [['all', 'هر روز'], ['today', 'فقط امروز']].concat([6, 0, 1, 2, 3, 4, 5].map(function (i) { return [String(i), 'هر ' + u.WD[i]]; })))) +
      App.btn('افزودن', 'busy-add', {}, 'mt') +
      '<div class="grid2 mt">' + App.field('ساعت بیدار شدن', App.timeField('wake', 'w', { def: '06:30', label: 'بیدار شدن' })) + App.field('ساعت خواب', App.timeField('wake', 'z', { def: '23:00', label: 'خواب' })) + '</div>' +
      App.sm('ذخیره ساعت خواب و بیداری', 'wake-save'), { open: true });
  }
  App.act['busy-preset'] = function (el) { App.form('busy', {}).t = el.getAttribute('data-v'); App.render(); };
  App.act['busy-add'] = function () {
    var f = App.form('busy', {});
    var t = String(f.t || '').trim().slice(0, 80);
    var a = u.validHM(f.s) ? u.normHM(f.s) : null, b = u.validHM(f.e) ? u.normHM(f.e) : null;
    if (!t) { App.alert('عنوان کار را بنویس'); return; }
    if (!a || !b || u.tmin(b) <= u.tmin(a)) { App.alert('ساعت پایان باید بعد از شروع باشد'); return; }
    S().busy.push({ id: u.uid(), t: t, s: a, e: b, r: String(f.r || 'all'), d: u.todayISO() });
    f.t = ''; App.save(); App.render(); App.toast('✅ افزوده شد');
  };
  App.act['busy-del'] = function (el) { st.delById(S().busy, el.getAttribute('data-key')); App.save(); App.render(); };
  App.act['wake-save'] = function () {
    var w = App.form('wake', {});
    if (u.validHM(w.w)) S().wake = u.normHM(w.w);
    if (u.validHM(w.z)) S().sleep = u.normHM(w.z);
    App.save(); App.render(); App.toast('ساعت‌ها ذخیره شد');
  };

  // ---- عقب‌افتادگی‌ها ----
  function blCard() {
    var B = S().bl.slice().sort(function (a, b) { return a.ok - b.ok || b.u - a.u; });
    var f = App.form('bl', { s: '', t: '', u: 0 });
    return App.card('📌 عقب‌افتادگی‌ها و کارهای مانده', '<p class="mu">هر چیزی که عقب افتاده‌ای (مثلاً یک فیلم هندسه مانده). برنامه‌ی خودکار و مشاور آن‌ها را جبران می‌کنند.</p>' +
      (B.length ? B.map(function (x) {
        return '<div class="li"><label class="check' + (x.ok ? ' done' : '') + '"><input type="checkbox" data-act="bl-toggle" data-key="' + x.id + '"' + (x.ok ? ' checked' : '') + '><span>' + (x.u && !x.ok ? '🔥 ' : '') + u.esc(x.s) + ' — ' + u.esc(x.t) + '</span></label>' + App.sm('🗑', 'bl-del', { key: x.id }) + '</div>';
      }).join('') : '<p class="mu">چیزی عقب نیفتاده. عالیه!</p>') +
      '<div class="grid2 mt">' + App.field('درس', App.select('bl', 's', [['', 'بدون درس']].concat(D.allSubjects().map(function (x) { return [x, x]; })))) +
      App.field('اولویت', App.select('bl', 'u', [['0', 'عادی'], ['1', '🔥 فوری']])) + '</div>' +
      App.field('چه چیزی مانده؟', App.input('bl', 't', { ph: 'مثلاً یک فیلم فصل ۲ مانده', maxlength: 200 })) +
      App.btn('افزودن', 'bl-add', {}, 'mt') + App.sm('🤖 مشاور برایش برنامه بچیند', 'ai-ask', { q: 'backlog', tab: 'plan' }, 'mt'), { open: true });
  }
  App.act['bl-add'] = function () {
    var f = App.form('bl', {});
    var o = st.addBacklog({ s: f.s || '', t: f.t, u: +f.u === 1 });
    if (!o) { App.alert('بنویس چی عقب افتاده'); return; }
    f.t = ''; App.save(); App.render();
  };
  App.act['bl-toggle'] = function (el) {
    var x = S().bl.find(function (y) { return String(y.id) === String(el.getAttribute('data-key')); });
    if (x) x.ok = x.ok ? 0 : 1;
    App.save(); App.render();
  };
  App.act['bl-del'] = function (el) { st.delById(S().bl, el.getAttribute('data-key')); App.save(); App.render(); };

  // ---- یادآور ----
  function rmCard() {
    var R = S().rm || { on: 0, t: ['09:00', '15:00', '21:00'], nag: 0 };
    var f = App.form('rmf', { t0: R.t[0], t1: R.t[1], t2: R.t[2], nag: R.nag ? 1 : 0 });
    var perm = typeof Notification !== 'undefined' ? ' · اجازه‌ی اعلان: ' + ({ granted: 'داده شده', denied: 'رد شده', default: 'هنوز پرسیده نشده' }[Notification.permission] || '—') : ' · این مرورگر اعلان ندارد';
    return App.card('🔔 یادآور و پیگیری', '<p class="mu">در ساعت‌های زیر، اگر برنامه باز یا پشت‌صحنه باشد اعلان می‌آید. اگر برنامه کاملاً بسته باشد، برای یادآوری از آلارم گوشی استفاده کن.</p>' +
      '<div class="grid3">' + [0, 1, 2].map(function (i) { return App.timeField('rmf', 't' + i, { def: R.t[i], label: 'یادآور ' + u.fa(i + 1) }); }).join('') + '</div>' +
      App.check('rmf', 'nag', 'پیگیری مکرر: هر ۹۰ دقیقه (۱۰ صبح تا ۱۰ شب) تا وقتی هدف امروز کامل نشده') +
      '<div class="grid2 mt">' + App.btn('🔔 فعال‌سازی', 'rm-save', { on: 1 }) + App.btn('خاموش', 'rm-save', { on: 0 }, 'muted') + '</div>' +
      '<div class="mu mt">وضعیت: ' + (R.on ? 'فعال ✅' : 'خاموش') + perm + '</div>', { open: false });
  }
  App.act['rm-save'] = function (el) {
    var on = el.getAttribute('data-on') === '1';
    var f = App.form('rmf', {});
    var t = [0, 1, 2].map(function (i) { return u.validHM(f['t' + i]) ? u.normHM(f['t' + i]) : ['09:00', '15:00', '21:00'][i]; });
    S().rm = { on: on ? 1 : 0, t: t, nag: f.nag ? 1 : 0 };
    S().rf = null;
    App.save();
    if (on && typeof Notification !== 'undefined' && Notification.permission === 'default') {
      try { Notification.requestPermission().then(function () { App.render(); }, function () { App.render(); }); } catch (e) { App.render(); }
    } else App.render();
  };

  // ---- کنکور و امتحان نهایی ----
  function cdCard() {
    var d = st.daysToKonkur();
    var f = App.form('cdf', { d: S().cd || u.todayISO() });
    if (!u.isISO(f.d)) f.d = S().cd || u.todayISO();
    var nf = App.form('fdf', { d: S().fd || u.todayISO() });
    if (!u.isISO(nf.d)) nf.d = S().fd || u.todayISO();
    return App.card('🎯 تاریخ کنکور', '<div class="grid2"><div>' + App.field('تاریخ آزمون/کنکور', App.dateField('cdf', 'd', { label: 'تاریخ کنکور' })) + App.sm('ثبت تاریخ کنکور', 'cd-save') + '</div>' +
      '<div class="center">' + (d !== null && d >= 0 ? '<div class="big accent">' + u.fa(d) + '</div><div class="mu">روز مانده</div>' : '<div class="mu">تاریخ را انتخاب کن</div>') + '</div></div>' +
      '<details class="inner"><summary>📅 تاریخ امتحانات نهایی (اختیاری)</summary>' + App.dateField('fdf', 'd', { label: 'تاریخ امتحان نهایی' }) + App.sm('ثبت', 'fd-save') + '</details>', { open: true });
  }
  App.act['cd-save'] = function () { S().cd = App.form('cdf', {}).d; App.save(); App.render(); App.toast('تاریخ کنکور ثبت شد'); };
  App.act['fd-save'] = function () { S().fd = App.form('fdf', {}).d; App.save(); App.render(); };

  // ---- دفترچه ----
  function jrCard() {
    var f = App.form('jr', { k: 'n', t: '' });
    var recent = S().jr.slice(-3).reverse();
    return App.card('📓 دفترچه‌ی من (حافظه)', '<p class="mu">هر چیزی که می‌خواهی یادت بماند بنویس: مشکل‌ها، موفقیت‌ها، چیزهایی که جواب داد. مشاور همه‌اش را به یاد دارد.</p>' +
      App.select('jr', 'k', [['p', '⚠️ مشکل'], ['w', '🏆 موفقیت'], ['n', '📝 یادداشت']]) +
      '<textarea id="jr-t" class="ta" data-f="jr.t" maxlength="1000" placeholder="امروز چی شد؟" aria-label="متن یادداشت">' + u.esc(f.t) + '</textarea>' +
      App.btn('ذخیره در دفترچه', 'jr-add', {}, 'mt') +
      recent.map(function (x) { return '<div class="li"><span class="mu">' + u.esc(u.jd(x.d, true)) + ' · ' + JK(x.k) + '</span>' + App.sm('🗑', 'jr-del', { key: x.id }) + '</div><div class="line">' + u.esc(x.t) + '</div>'; }).join('') +
      '<div class="mu mt">' + u.fa(S().jr.length) + ' یادداشت · همه در تب «آمار»</div>', { open: false });
  }
  function JK(k) { return { p: '⚠️ مشکل', w: '🏆 موفقیت', n: '📝 یادداشت' }[k] || ''; }
  App.JK = JK;
  App.act['jr-add'] = function () {
    var f = App.form('jr', {});
    var o = st.addJournal(f.k, f.t);
    if (!o) { App.alert('چیزی بنویس'); return; }
    f.t = ''; App.save(); App.render();
  };
  App.act['jr-del'] = function (el) { st.delById(S().jr, el.getAttribute('data-key')); App.save(); App.render(); };

  // ---- برنامه‌ی متنی (از مشاور یا مدرسه) ----
  function progCard() {
    var f = App.form('prg', { t: S().prog || '' });
    return App.card('📋 برنامه‌ی متنی که گرفتم', '<textarea id="prg-t" class="ta" data-f="prg.t" placeholder="مثال:\nشنبه: ۱۶ تا ۱۸ فیزیک فصل ۲، ۱۸:۱۵ تا ۱۹ شیمی\nیکشنبه و سه‌شنبه: ریاضی ۲ ساعت\nآزمون ۱۵ آبان: فیزیک فصل ۱ تا ۳، شیمی فصل ۲" aria-label="متن برنامه">' + u.esc(f.t) + '</textarea>' +
      '<div class="q-row"><button type="button" class="sm" data-act="prog-save">ذخیره</button><button type="button" class="sm accent" data-act="prog-go">🔍 تحلیل و جایگذاری</button><button type="button" class="sm" data-act="prog-ai">🤖 هوشمند</button><button type="button" class="sm" data-act="prog-prompt">📄 پرامپت تبدیل PDF/عکس</button></div>' +
      '<p class="mu">برنامه‌ی هفتگی و آزمون‌ها خودکار جایگذاری می‌شوند. مشاور هم همین را دنبال می‌کند. برای PDF یا عکس، پرامپت را کپی کن و در یک چت Claude بفرست.</p>', { open: false });
  }
  App.act['prog-save'] = function () { S().prog = String(App.form('prg', {}).t || '').slice(0, 6000); App.save(); App.toast('ذخیره شد ✅'); };
  App.act['prog-go'] = function () {
    var t = String(App.form('prg', {}).t || '').trim();
    if (!t) { App.alert('متن برنامه را بنویس یا بچسبان'); return; }
    S().prog = t.slice(0, 6000); App.save();
    var J = pl.jsonOf(t);
    if (J && J.weekly) { var n = pl.wpApply(J); App.save(); App.render(); App.toast(n ? '✅ برنامه‌ی هفتگی ثبت شد' : 'برنامه‌ی هفتگی معتبر پیدا نشد'); return; }
    App.ui.vp = Array.isArray(J) ? pl.normActs(J) : pl.parseProg(t);
    if (!App.ui.vp.length) { App.alert('چیزی پیدا نشد؛ برنامه را با روز و ساعت بنویس (مثلاً «شنبه: ۱۶ تا ۱۸ فیزیک فصل ۲»).'); App.render(); return; }
    App.go('today');
    App.toast('پیش‌نمایش در کارت 🎙 بالای صفحه آماده است؛ بررسی کن و «ثبت همه» را بزن', { ms: 6000 });
  };
  App.act['prog-ai'] = function () {
    var t = String(App.form('prg', {}).t || '').trim();
    if (!t) { App.alert('متن برنامه را بنویس یا بچسبان'); return; }
    S().prog = t.slice(0, 6000); App.save();
    if (App.ai && App.ai.parseProgram) App.ai.parseProgram(t);
    else App.act['prog-go']();
  };
  App.act['prog-prompt'] = function () {
    var t = 'فایل یا عکس پیوست، برنامه‌ی مطالعاتی یا جدول آزمون‌های من است. همه‌ی صفحه‌ها را با دقت بخوان و آن را به یک آرایه‌ی JSON تبدیل کن. اول در ۳ تا ۵ خط خلاصه‌ی آنچه فهمیدی را بگو و اگر چیزی خوانا نبود بپرس؛ بعد فقط یک بلوک ```json بده.\nآیتم‌ها:\n• بلوک هفتگی: {"k":"wp","day":6,"s0":"16:00","e0":"18:00","t":"فیزیک — فصل ۲","tk":"study"} — day: یکشنبه=0، دوشنبه=1، سه‌شنبه=2، چهارشنبه=3، پنجشنبه=4، جمعه=5، شنبه=6؛ tk یکی از study | class | other؛ ساعت ۲۴ ساعته.\n• آزمون: {"k":"ex2","n":"نام آزمون","d":"YYYY-MM-DD (میلادی)","r":[{"g":12,"s":"فیزیک","a":1,"b":3}]}\nامروز: ' + u.todayISO() + ' (' + u.jd(u.todayISO(), true) + '). دروس مجاز: ' + D.allSubjects().join('، ') + '.';
    u.copyText(t).then(function (ok) { App.toast(ok ? 'پرامپت کپی شد ✅ حالا در یک چت Claude پیست کن و PDF یا عکس را بفرست' : 'کپی انجام نشد', { ms: 6000 }); });
  };
})();
