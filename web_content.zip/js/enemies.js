// ===== enemies: soldiers, heavies, snipers, tanks =====
const sm = (c, r = .9) => new THREE.MeshStandardMaterial({ color: c, roughness: r });
const EM = { uni: sm(0x4a4f3f), uni2: sm(0x3d4136), vest: sm(0x2c2f2a), skin: sm(0xb58b6a), helmet: sm(0x30362b), band: new THREE.MeshBasicMaterial({ color: 0xc02c20 }), gun: sm(0x1a1a1a), boots: sm(0x1c1a17), heavy: sm(0x5a3f33), ghillie: sm(0x4d5a35), laser: new THREE.MeshBasicMaterial({ color: 0xff2a1a, transparent: true, opacity: .8, blending: THREE.AdditiveBlending, depthWrite: false }) };
const LASER_GEO = new THREE.BoxGeometry(.02, .02, 1).translate(0, 0, .5);
function eMesh(parent, geo, mat, x, y, z) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; }

function buildSoldier(kind) {
  const g = new THREE.Group(), uni = kind === 'sniper' ? EM.ghillie : kind === 'heavy' ? EM.heavy : EM.uni;
  eMesh(g, BX(.46, .58, .26), uni, 0, 1.12, 0); eMesh(g, BX(.5, .38, .3), EM.vest, 0, 1.2, 0);
  eMesh(g, BX(.2, .22, .22), EM.skin, 0, 1.58, 0);
  eMesh(g, new THREE.SphereGeometry(.17, 10, 8, 0, 6.283, 0, 1.7), kind === 'sniper' ? EM.ghillie : EM.helmet, 0, 1.62, 0);
  const legs = [], arms = [];
  for (const sx of [-1, 1]) { const l = new THREE.Group(); l.position.set(sx * .12, .82, 0); g.add(l); eMesh(l, BX(.17, .8, .19), EM.uni2, 0, -.4, 0); eMesh(l, BX(.18, .12, .28), EM.boots, 0, -.77, .04); legs.push(l); }
  for (const sx of [-1, 1]) { const a = new THREE.Group(); a.position.set(sx * .3, 1.38, 0); a.rotation.set(-1.2, 0, -sx * .25); g.add(a); arms.push(a); eMesh(a, BX(.12, .5, .12), uni, 0, -.25, 0); if (sx > 0) eMesh(a, BX(.13, .08, .13), EM.band, 0, -.12, 0); }
  eMesh(g, BX(.07, .09, kind === 'sniper' ? 1.1 : .75), EM.gun, .08, 1.2, .4);
  if (kind === 'heavy') g.scale.set(1.25, 1.15, 1.25);
  return { g, legs, arms };
}
function buildTank() {
  const g = new THREE.Group(), hull = sm(0x4d5340), dk = sm(0x23241f), tm = [hull, dk];
  eMesh(g, BX(3.2, .9, 6), hull, 0, .95, 0); eMesh(g, BX(3, .5, 1.6), hull, 0, .95, 3.2).rotation.x = -.35;
  for (const sx of [-1, 1]) { eMesh(g, BX(.9, 1.1, 6.6), dk, sx * 1.95, .7, 0); for (let i = 0; i < 6; i++) eMesh(g, new THREE.CylinderGeometry(.38, .38, .95, 10).rotateZ(Math.PI / 2), hull, sx * 1.95, .5, -2.5 + i); }
  const turret = new THREE.Group(); turret.position.y = 1.4; g.add(turret);
  eMesh(turret, BX(2.2, .75, 2.7), hull, 0, .4, -.2); eMesh(turret, BX(1.4, .6, .5), dk, 0, .4, 1.3);
  eMesh(turret, new THREE.CylinderGeometry(.13, .13, 4.3, 10).rotateX(Math.PI / 2), dk, 0, .45, 3.4); eMesh(turret, new THREE.CylinderGeometry(.35, .35, .2, 10), dk, .5, .85, -.5);
  g.userData = { turret, mats: tm };
  return g;
}
const SPEC = {
  soldier: { hp: 55, speed: 3.6, hitR: .36, bodyH: 1.45, headY: 1.6, headR: .22, dmg: 6, acc: 1, range: 30, pref: [14, 24] },
  heavy: { hp: 240, speed: 2.3, hitR: .45, bodyH: 1.7, headY: 1.85, headR: .26, dmg: 4, acc: .6, range: 26, pref: [10, 18] },
  sniper: { hp: 45, speed: 2.8, hitR: .36, bodyH: 1.45, headY: 1.6, headR: .22, dmg: 28, acc: 1, range: 60, pref: [38, 52] },
  tank: { hp: 900, speed: 3.2, hitR: 2.3, bodyH: 2.4, headY: 0, headR: 0, dmg: 4, acc: .8, range: 50, pref: [24, 32] }
};
function spawnPos(far) {
  for (let i = 0; i < 30; i++) {
    const a = rand(0, 6.283), r = far ? rand(52, 68) : rand(50, 80), x = P.pos.x + Math.cos(a) * r, z = P.pos.z + Math.sin(a) * r;
    if (Math.hypot(x, z) < ARENA - 4 && !colliders.some(c => c.h > .45 && x > c.x0 - 1 && x < c.x1 + 1 && z > c.z0 - 1 && z < c.z1 + 1)) return [x, z];
  }
  const a = rand(0, 6.283); return [Math.cos(a) * 80, Math.sin(a) * 80];
}
function spawnEnemy(type, at) {
  const s = SPEC[type], [x, z] = at || spawnPos(type === 'tank'), hm = (1 + .14 * MAPI) * DIFF.hp * (1 + Math.max(0, G.wave - 30) * .03);
  const e = { type, hp: s.hp * hm, maxHp: s.hp * hm, x, z, y: 0, yaw: 0, tyaw: 0, speed: s.speed, hitR: s.hitR, bodyH: s.bodyH, headY: s.headY, headR: s.headR, dmg: s.dmg, acc: s.acc, range: s.range,
    pref: rand(s.pref[0], s.pref[1]), dead: false, dt: 0, los: false, losT: rand(0, .3), fireT: rand(1.5, 3), burst: 0, strafeDir: Math.random() < .5 ? -1 : 1, strafeT: rand(1, 3), avoidT: 0, avoidDir: 1,
    lastX: x, lastZ: z, chkT: 0, stuckN: 0, walk: Math.random() * 6, aim: 0, vx: 0, vz: 0, vy: 0, spin: 0 };
  if (type === 'tank') { const g = buildTank(); e.g = g; e.turret = g.userData.turret; e.mats = g.userData.mats; e.fireT = rand(2, 4); }
  else { const b = buildSoldier(type); e.g = b.g; e.legs = b.legs; }
  if (type === 'sniper') { e.laser = new THREE.Mesh(LASER_GEO, EM.laser); e.laser.visible = false; scene.add(e.laser); }
  e.g.position.set(x, 0, z); scene.add(e.g); enemies.push(e);
  if (ggOn() && type !== 'tank') aiInit(e, G.botCarry.shift());
  if (type === 'tank') { message('TANK YAKLAŞIYOR!', ''); SND.alert(); }
  if (type === 'sniper') { feedLine('KESKİN NİŞANCI', 'head'); }
  return e;
}
function damagePlayer(d, fx, fz, src) {
  if (P.dead || P.protT > 0) return; P.sinceHurt = 0; if (P.inTank && PT) { tankHit(d); return; } if (P.armor > 0) { const ab = Math.min(P.armor, d * .6); P.armor -= ab; d -= ab; } P.hp -= d; P.hurtT = .4; P.shake += .2; SND.hurt(); hudHealth(); flashHurt(Math.min(1, d / 30 + .3));
  if (fx !== undefined) dmgDir(Math.atan2(fx - P.pos.x, fz - P.pos.z));
  if (P.hp <= 0) { P.hp = 0; P.dead = true; P.deadT = 0; P.trigger = false; hudHealth(); if (G.mode === 'tdm') tdmScore('B'); if (src) aiKill(src); }
}
function hurtEnemy(e, dmg, o) {
  if (e.dead) return; e.hp -= dmg; e.alert = true; SND.hit(o && o.head);
  if (e.hp <= 0) killEnemy(e, o || {});
}
function killEnemy(e, o) {
  e.dead = true; e.dt = 0; SND.kill(); if (e.tag) e.tag.sp.visible = false; if (ggOn() && e.ggLv !== undefined) G.botCarry.push({ lv: e.ggLv, k: e.ggK }); if (o.by) aiKill(o.by);
  const pts = { soldier: 100, heavy: 250, sniper: 200, tank: 1000 }[e.type], head = !!o.head;
  G.chain = G.chainT > 0 ? G.chain + 1 : 1; G.chainT = 4; const mult = Math.min(5, 1 + Math.floor((G.chain - 1) / 2)), gain = (pts + (head ? 50 : 0)) * mult;
  if (!o.ally && ggOn()) ggKill(e); if (G.mode === 'tdm') tdmScore('A'); G.score += gain; const cash = { soldier: 50, heavy: 150, sniper: 120, tank: 800 }[e.type]; P.money += cash; G.kills++; if (head) G.heads++; if (P.up.vamp) { P.hp = Math.min(P.maxHp, P.hp + [0, 8, 16, 25][P.up.vamp]); hudHealth(); }
  feedLine(({ soldier: 'PİYADE', heavy: 'AĞIR PİYADE', sniper: 'KESKİN NİŞANCI', tank: 'TANK İMHA' })[e.type] + (head ? ' · KAFADAN' : '') + ' +' + gain + ' · $' + cash, head ? 'head' : '');
  if (e.type === 'tank') {
    explode(e.x, 1.5, e.z, 9, 0, 'enemy'); e.mats.forEach(m => m.color.setHex(0x161412)); e.vx = e.vz = 0; e.wreck = true; wrecks.push({ x: e.x, z: e.z, g: e.g, turret: e.turret, mats: e.mats, yaw: e.yaw, tyaw: e.tyaw, t: 0 }); if (wrecks.length > 4) scene.remove(wrecks.shift().g);
    if (!G.arena) { dropPickup(e.x + 3, e.z, 'med'); dropPickup(e.x - 3, e.z, 'ammo'); dropPickup(e.x, e.z + 3, 'armor'); } P.ws[2].reserve += 1; feedLine('+1 RPG', '');
  } else {
    const dx = o.ix || 0, dz = o.iz || 0, kick = o.boom ? 1 : .25; { const fx = dx || (o.from ? e.x - o.from.x : 0), fz = dz || (o.from ? e.z - o.from.z : 0); e.fallA = (fx || fz) ? Math.atan2(fx, fz) : rand(0, 6.28); } e.vx = dx + (o.from ? (e.x - o.from.x) * .15 : 0); e.vz = dz + (o.from ? (e.z - o.from.z) * .15 : 0); e.vy = o.boom ? 6 : 1.2; e.spin = rand(-3, 3) * kick;
    const r = Math.random(); if (!G.arena && r < ({ soldier: .38, heavy: .8, sniper: .7 })[e.type]) dropPickup(e.x, e.z, ['med', 'ammo', 'armor', 'cash', 'cash'][randi(0, 4)]);
  }
  if (e.laser) e.laser.visible = false;
}
function pickTarget(e) { let best = null, bd = P.dead ? 1e9 : Math.hypot(P.pos.x - e.x, P.pos.z - e.z); for (const a of allies) { if (a.dead) continue; const d = Math.hypot(a.x - e.x, a.z - e.z); if (d < bd + (G.arena ? 14 : -3)) { bd = d; best = a; } } e.tgt = best; }
function enemyShoot(e, ox, oy, oz, dist, kind) {
  const ta = (e.type !== 'tank' && e.tgt && !e.tgt.dead) ? e.tgt : null;
  const tx = ta ? ta.x : P.pos.x, ty = ta ? 1.05 : P.pos.y + P.eyeH * .7, tz = ta ? ta.z : P.pos.z;
  let p = ta ? clamp(.45 - dist * .009, .1, .36) * e.acc : clamp(.34 - dist * .011, .03, .26) * e.acc * (P.sprint ? .6 : 1) * (P.ads > .5 ? .85 : 1) * [1, .75, .5][P.stance] * (Math.hypot(P.vx, P.vz) > 3 ? .7 : 1);
  if (kind === 'sniper') p = ta ? .5 : Math.hypot(P.vx, P.vz) > 2 ? .35 : .65;
  let hit = Math.random() < p; const off = hit ? 0 : rand(1.2, 3);
  let ex = tx + (hit ? 0 : rand(-1, 1) * off), ey = ty + (hit ? 0 : rand(-.5, .5)), ez = tz + (hit ? 0 : rand(-1, 1) * off);
  // real bullet path: from the shooter's body (not just the muzzle) to the impact point; walls and props stop it
  const sx = e.x, sz = e.z, bdx = ex - sx, bdy = ey - oy, bdz = ez - sz, blen = Math.hypot(bdx, bdy, bdz) || 1, bd = { x: bdx / blen, y: bdy / blen, z: bdz / blen };
  const wall = castRay({ x: sx, y: oy, z: sz }, bd, blen, false, false);
  if (wall && wall.kind === 'world') { ex = sx + bd.x * wall.t; ey = oy + bd.y * wall.t; ez = sz + bd.z * wall.t; hit = false; impactFx({ x: ex, y: ey, z: ez }, wall, bd); }
  tracer(ox, oy, oz, ex, ey, ez, kind === 'sniper' ? 0xff6050 : 0xff9a50, kind === 'sniper' ? 500 : 200);
  muzzleFx(ox, oy, oz, kind === 'sniper' ? 1 : .7); SND.shot(kind, e.x, e.z);
  if (hit) { if (ta) hurtAlly(ta, e.dmg * DIFF.dmg * 1.7, e); else damagePlayer(e.dmg * DIFF.dmg, e.x, e.z, e); } else if (ta) { } else if (dist < 40 && Math.random() < .5) SND.whiz(e.x, e.z);
}
const _ep = new THREE.Vector3(), _dq1 = new THREE.Quaternion(), _dq2 = new THREE.Quaternion(), _dax = new THREE.Vector3(), _dup = new THREE.Vector3(0, 1, 0);
function updateEnemy(e, dt) {
  if (e.dead) {
    e.dt += dt;
    if (e.type === 'tank') return true;
    e.x += e.vx * dt; e.z += e.vz * dt; e.vy -= 18 * dt; e.y = Math.max(0, e.y + e.vy * dt); if (e.y === 0) { e.vx *= .85; e.vz *= .85; e.vy = 0; }
    // topple away from where the hit came from: stagger, fall, small settle
    const k = Math.min(1, e.dt * 2.2), th = 1.53 * (1 - Math.pow(1 - k, 3)) + (k >= 1 ? 0 : Math.sin(k * Math.PI) * .05) - Math.sin(Math.min(1, e.dt / .16) * Math.PI) * .09;
    _dq1.setFromAxisAngle(_dax.set(Math.cos(e.fallA), 0, -Math.sin(e.fallA)), th); _dq2.setFromAxisAngle(_dup, e.yaw + e.spin * e.dt * (1 - k) * .6); e.g.quaternion.copy(_dq1).multiply(_dq2);
    if (e.legs) { e.legs[0].rotation.x = -k * .55 + Math.sin(e.dt * 14) * .15 * (1 - k); e.legs[1].rotation.x = k * .75 - Math.sin(e.dt * 12) * .15 * (1 - k); }
    e.g.position.set(e.x, e.y + Math.sin(th) * .13, e.z);
    if (e.dt > 5) e.g.position.y -= (e.dt - 5) * .5; return e.dt > 8;
  }
  if (e.tag) tagUpd(e, false);
  if (allies.length) { e.tgtT = (e.tgtT || 0) - dt; if (e.tgtT <= 0) { e.tgtT = .5; pickTarget(e); } } else e.tgt = null;
  const tg = (e.type !== 'tank' && e.tgt && !e.tgt.dead) ? e.tgt : null, tX = tg ? tg.x : P.pos.x, tZ = tg ? tg.z : P.pos.z, tdead = tg ? false : P.dead;
  const dx = tX - e.x, dz = tZ - e.z, dist = Math.hypot(dx, dz) + .001, fx = dx / dist, fz = dz / dist, ang = Math.atan2(dx, dz);
  e.losT -= dt; if (e.losT <= 0) { e.losT = .2 + Math.random() * .2; e.los = !tdead && !blocked(e.x, e.type === 'tank' ? 2.0 : 1.3, e.z, tX, tg ? 1.1 : P.pos.y + Math.min(1.3, P.eyeH * .8), tZ); }
  e.strafeT -= dt; if (e.strafeT <= 0) { e.strafeDir = Math.random() < .5 ? -1 : 1; e.strafeT = rand(1.2, 3); }
  e.avoidT = Math.max(0, e.avoidT - dt);
  let want = e.los ? (dist > e.pref + 4 ? 1 : dist < e.pref - 8 ? -.6 : 0) : 1;
  if (tdead) want = 0;
  const side = e.los && e.type !== 'tank' && e.type !== 'sniper' ? .6 : 0;
  let mx = fx * want - fz * e.strafeDir * side, mz = fz * want + fx * e.strafeDir * side;
  if (e.avoidT > 0) { mx = -fz * e.avoidDir + fx * .2; mz = fx * e.avoidDir + fz * .2; }
  const ml = Math.hypot(mx, mz); if (ml > 1) { mx /= ml; mz /= ml; }
  if (e.aim > 0) { mx = mz = 0; }
  let sp = e.speed;
  if (e.type === 'tank') {
    const want2 = Math.atan2(mx, mz); if (ml > .05) e.yaw += clamp(angDiff(e.yaw, want2), -.8 * dt, .8 * dt);
    const al = Math.max(0, Math.cos(angDiff(e.yaw, want2))); mx = Math.sin(e.yaw) * Math.min(1, ml) * al; mz = Math.cos(e.yaw) * Math.min(1, ml) * al;
  }
  const ox = e.x, oz = e.z; _ep.set(e.x, 0, e.z);
  moveEntity(_ep, mx * sp * dt, mz * sp * dt, e.type === 'tank' ? 2.4 : e.hitR + .1, 0, e.type === 'tank'); e.x = _ep.x; e.z = _ep.z;
  e.chkT += dt;
  if (e.chkT > .8) { const moved = Math.hypot(e.x - e.lastX, e.z - e.lastZ); if (want !== 0 && moved < sp * .8 * .3 && e.aim <= 0) { e.avoidT = 1.6; e.avoidDir = Math.random() < .5 ? -1 : 1; e.stuckN++; if (e.stuckN > 6 && e.type !== 'tank') { const [nx, nz] = spawnPos(); e.x = nx; e.z = nz; e.stuckN = 0; } } else if (moved > sp * .5) e.stuckN = 0; e.lastX = e.x; e.lastZ = e.z; e.chkT = 0; }
  // facing
  if (e.type === 'tank') {
    e.tyaw += clamp(angDiff(e.tyaw, ang), -.9 * dt, .9 * dt); e.g.rotation.y = e.yaw; e.turret.rotation.y = e.tyaw - e.yaw; e.g.position.set(e.x, 0, e.z);
    e.fireT -= dt;
    const mo = new THREE.Vector3(e.x + Math.sin(e.tyaw) * 5.2, 2.0, e.z + Math.cos(e.tyaw) * 5.2);
    if (e.aim > 0) {
      e.aim -= dt; if (!e.laser) { e.laser = new THREE.Mesh(LASER_GEO, EM.laser); scene.add(e.laser); }
      const t = new THREE.Vector3(P.pos.x, P.pos.y + 1, P.pos.z); e.laser.visible = true; e.laser.position.copy(mo); e.laser.lookAt(t); e.laser.scale.z = Math.min(mo.distanceTo(t), 60);
      if (e.aim > 0 && blocked(e.x, 2.0, e.z, mo.x, 2.0, mo.z)) { e.aim = 0; e.laser.visible = false; e.fireT = 1; }
      else if (e.aim <= 0) {
        e.laser.visible = false; e.fireT = rand(7, 10);
        const lead = dist / 55 * .4, tgt = new THREE.Vector3(P.pos.x + P.vx * lead, P.pos.y + 1, P.pos.z + P.vz * lead), d = tgt.sub(mo).normalize();
        spawnRocket(mo, d, 'enemy', 55, true); SND.shot('tank', e.x, e.z); muzzleFx(mo.x, mo.y, mo.z, 3); smoke.emit(mo.x, mo.y, mo.z, 0, .5, 0, 1.2, 1, 3, C_SMOKE1, C_SMOKE1, .5, 0, 0, 1);
      }
    } else if (e.los && dist < e.range && e.fireT <= 0 && Math.abs(angDiff(e.tyaw, ang)) < .07 && !blocked(e.x, 2.0, e.z, mo.x, 2.0, mo.z)) { e.aim = 1.6; SND.alert(); message('TANK NİŞAN ALIYOR!', 'SİPERE GİR'); }
    e.mgT = (e.mgT || 0) - dt;
    if (e.los && dist < 45 && e.mgT <= 0 && !blocked(e.x, 2.0, e.z, e.x + Math.sin(e.tyaw) * 2, 2.2, e.z + Math.cos(e.tyaw) * 2)) { e.mgT = rand(.12, .16); if (Math.random() < .18) enemyShoot(e, e.x + Math.sin(e.tyaw) * 2, 2.2, e.z + Math.cos(e.tyaw) * 2, dist, 'mg'); }
    if (Math.random() < dt * 10) smoke.emit(e.x - Math.sin(e.yaw) * 3, 1.5, e.z - Math.cos(e.yaw) * 3, 0, 1, 0, 1.5, .8, 2.5, C_SMOKE0, C_SMOKE1, .35, 0, -.3, .3);
    return false;
  }
  let dy = angDiff(e.yaw, ang); e.yaw += clamp(dy, -6 * dt, 6 * dt); e.g.rotation.y = e.yaw; e.g.position.set(e.x, 0, e.z);
  const mv = Math.hypot(e.x - ox, e.z - oz) / dt; e.walk += mv * dt * 2.2;
  const sw = Math.sin(e.walk) * .7 * Math.min(1, mv / 2); e.legs[0].rotation.x = sw; e.legs[1].rotation.x = -sw; e.g.position.y = Math.abs(Math.cos(e.walk)) * .03 * Math.min(1, mv / 2);
  // shooting
  const mz0 = e.yaw, mox = e.x + Math.sin(mz0) * .6 + Math.cos(mz0) * .15, moz = e.z + Math.cos(mz0) * .6 - Math.sin(mz0) * .15;
  if (e.type === 'sniper') {
    if (e.aim > 0) {
      e.aim -= dt; if (!e.los) { e.aim = 0; e.laser.visible = false; e.fireT = 1; } e.laser.visible = e.aim > 0; const o = new THREE.Vector3(mox, 1.3, moz), t = new THREE.Vector3(tX, tg ? 1.1 : P.pos.y + 1.3, tZ);
      e.laser.position.copy(o); e.laser.lookAt(t); e.laser.scale.z = o.distanceTo(t);
      if (e.aim <= 0 && e.los) { e.laser.visible = false; enemyShoot(e, mox, 1.3, moz, dist, 'sniper'); e.fireT = rand(3, 4.5); }
    } else { e.fireT -= dt; if (e.los && dist < e.range && e.fireT <= 0 && !tdead) { e.aim = 1.4; SND.alert(); } }
  } else if (e.los && dist < e.range && !tdead) {
    e.fireT -= dt;
    if (e.fireT <= 0) {
      if (e.burst <= 0) { e.burst = e.type === 'heavy' ? randi(8, 14) : randi(3, 6); }
      enemyShoot(e, mox, 1.35, moz, dist, e.type === 'heavy' ? 'mg' : 'rifle'); e.burst--;
      e.fireT = e.burst > 0 ? (e.gri || (e.type === 'heavy' ? .09 : .15)) : rand(1.6, 3.2);
    }
  }
  return false;
}
function updateEnemies(dt) {
  for (let i = enemies.length - 1; i >= 0; i--) { if (updateEnemy(enemies[i], dt)) { const e = enemies[i]; if (!e.wreck) scene.remove(e.g); if (e.laser) scene.remove(e.laser); enemies.splice(i, 1); } }
}
function clearEnemies() { for (const e of enemies) { scene.remove(e.g); if (e.laser) scene.remove(e.laser); } enemies.length = 0; for (const p of proj) scene.remove(p.mesh); proj.length = 0; for (const k of pickups) scene.remove(k.g); pickups.length = 0; }
