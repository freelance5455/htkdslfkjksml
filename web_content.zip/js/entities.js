// ===== ENTITIES: instanced scenery, character rig, vehicle, target dummies =====

// ---- Instanced trees and rocks (real GPU instancing, not one draw call per object) ----
const staticColliders = []; // {x, z, radius} used for simple push-out collision

function scatterScenery() {
  const TREE_COUNT = 360;
  const trunkGeo = new THREE.CylinderGeometry(0.28, 0.4, 2.2, 6);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x6b4a2f, flatShading: true });
  const leavesGeo = new THREE.ConeGeometry(1.7, 3.2, 6);
  const leavesMat = new THREE.MeshStandardMaterial({ color: 0x2f7d3a, flatShading: true });

  const trunkMesh = new THREE.InstancedMesh(trunkGeo, trunkMat, TREE_COUNT);
  const leavesMesh = new THREE.InstancedMesh(leavesGeo, leavesMat, TREE_COUNT);
  trunkMesh.castShadow = true;
  leavesMesh.castShadow = true;

  const dummy = new THREE.Object3D();
  for (let i = 0; i < TREE_COUNT; i++) {
    const x = (Math.random() - 0.5) * WORLD_SIZE * 0.85;
    const z = (Math.random() - 0.5) * WORLD_SIZE * 0.85;
    const y = heightAt(x, z);
    const scale = 0.8 + Math.random() * 0.6;
    const rotY = Math.random() * Math.PI * 2;

    dummy.position.set(x, y + 1.1 * scale, z);
    dummy.rotation.set(0, rotY, 0);
    dummy.scale.setScalar(scale);
    dummy.updateMatrix();
    trunkMesh.setMatrixAt(i, dummy.matrix);

    dummy.position.set(x, y + 2.7 * scale, z);
    dummy.updateMatrix();
    leavesMesh.setMatrixAt(i, dummy.matrix);

    staticColliders.push({ x, z, radius: 0.6 * scale });
  }
  trunkMesh.instanceMatrix.needsUpdate = true;
  leavesMesh.instanceMatrix.needsUpdate = true;
  scene.add(trunkMesh, leavesMesh);

  const ROCK_COUNT = 140;
  const rockGeo = new THREE.DodecahedronGeometry(1, 0);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x8a8578, flatShading: true });
  const rockMesh = new THREE.InstancedMesh(rockGeo, rockMat, ROCK_COUNT);
  rockMesh.castShadow = true;
  rockMesh.receiveShadow = true;
  for (let i = 0; i < ROCK_COUNT; i++) {
    const x = (Math.random() - 0.5) * WORLD_SIZE * 0.85;
    const z = (Math.random() - 0.5) * WORLD_SIZE * 0.85;
    const y = heightAt(x, z);
    const scale = 0.6 + Math.random() * 1.1;
    dummy.position.set(x, y + scale * 0.5, z);
    dummy.rotation.set(Math.random(), Math.random(), Math.random());
    dummy.scale.setScalar(scale);
    dummy.updateMatrix();
    rockMesh.setMatrixAt(i, dummy.matrix);
    staticColliders.push({ x, z, radius: 0.7 * scale });
  }
  rockMesh.instanceMatrix.needsUpdate = true;
  scene.add(rockMesh);
}
scatterScenery();

// ---- Low-poly humanoid rig, shared by the player and target dummies ----
function buildCharacter(bodyColor) {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: bodyColor, flatShading: true });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xdab08a, flatShading: true });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x232323, flatShading: true });

  // A tapered cylinder torso reads as a body, not a crate.
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.48, 1.05, 7), bodyMat);
  torso.position.y = 1.15;
  torso.castShadow = true;
  group.add(torso);

  const head = new THREE.Mesh(new THREE.IcosahedronGeometry(0.34, 0), skinMat);
  head.position.y = 1.9;
  head.castShadow = true;
  group.add(head);

  const cap = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.28, 7), bodyMat);
  cap.position.y = 2.12;
  cap.castShadow = true;
  group.add(cap);

  const legGeo = new THREE.CylinderGeometry(0.14, 0.11, 0.85, 6);
  legGeo.translate(0, -0.425, 0); // shift the pivot to the top of the leg (the hip)
  const legL = new THREE.Mesh(legGeo, darkMat);
  legL.position.set(-0.2, 0.85, 0);
  legL.castShadow = true;
  const legR = legL.clone();
  legR.position.x = 0.2;
  group.add(legL, legR);

  const armGeo = new THREE.CylinderGeometry(0.11, 0.09, 0.8, 6);
  armGeo.translate(0, -0.4, 0); // shift the pivot to the top of the arm (the shoulder)
  const armL = new THREE.Mesh(armGeo, bodyMat);
  armL.position.set(-0.58, 1.55, 0);
  armL.castShadow = true;
  const armR = armL.clone();
  armR.position.x = 0.58;
  group.add(armL, armR);

  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.85), darkMat);
  gun.position.set(0.32, 1.25, 0.5);
  gun.castShadow = true;
  group.add(gun);

  group.userData = { legL, legR, armL, armR, bodyMat, gun, walkPhase: 0 };
  return group;
}

// ---- Player ----
// Color is set by whichever character the person picks on the start menu
// (see characters.js); default here covers the case where that hasn't run yet.
const player = buildCharacter(0x4a90d8);
player.position.set(0, heightAt(0, 0), 0);
scene.add(player);

const auraGeo = new THREE.IcosahedronGeometry(1.1, 1);
const auraMat = new THREE.MeshBasicMaterial({ color: 0x4a90d8, transparent: true, opacity: 0.16, depthWrite: false });
const playerAura = new THREE.Mesh(auraGeo, auraMat);
playerAura.position.y = 1.1;
player.add(playerAura);

const playerBody = new CANNON.Body({
  mass: 5,
  shape: new CANNON.Sphere(0.55),
  position: new CANNON.Vec3(0, 3, 0),
  linearDamping: 0.9,
  fixedRotation: true,
});
world.addBody(playerBody);

let playerHp = 100;
let playerMaxHp = 100;

// ---- Low-poly car ----
function buildVehicle() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0xd8543a, flatShading: true });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x7fb8d8, flatShading: true, transparent: true, opacity: 0.75 });
  const wheelMat = new THREE.MeshStandardMaterial({ color: 0x1c1c1c, flatShading: true });

  const base = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.6, 4), bodyMat);
  base.position.y = 0.6;
  base.castShadow = true;
  group.add(base);

  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.65, 1.9), glassMat);
  cabin.position.set(0, 1.15, -0.2);
  cabin.castShadow = true;
  group.add(cabin);

  const wheelGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.4, 8);
  wheelGeo.rotateZ(Math.PI / 2);
  const wheelPositions = [[-1.05, 0.45, 1.3], [1.05, 0.45, 1.3], [-1.05, 0.45, -1.3], [1.05, 0.45, -1.3]];
  wheelPositions.forEach(p => {
    const w = new THREE.Mesh(wheelGeo, wheelMat);
    w.position.set(p[0], p[1], p[2]);
    w.castShadow = true;
    group.add(w);
  });

  return group;
}

const vehicle = buildVehicle();
vehicle.position.set(6, heightAt(6, 4), 4);
scene.add(vehicle);

const vehicleBody = new CANNON.Body({
  mass: 40,
  shape: new CANNON.Box(new CANNON.Vec3(1.1, 0.6, 2)),
  position: new CANNON.Vec3(6, 3, 4),
  linearDamping: 0.5,
  angularDamping: 0.9,
});
world.addBody(vehicleBody);

// Static collider bodies for trees/rocks, so the player and vehicle can't
// just walk/drive straight through the scenery.
staticColliders.forEach(c => {
  const body = new CANNON.Body({ mass: 0, shape: new CANNON.Cylinder(c.radius, c.radius, 4, 8) });
  body.position.set(c.x, heightAt(c.x, c.z) + 2, c.z);
  world.addBody(body);
});

// ---- Target dummies: stand-ins for the full faction AI, coming in a later pass ----
const targets = [];
function spawnTargets() {
  for (let i = 0; i < 8; i++) {
    const t = buildCharacter(0xb8483a);
    const x = (Math.random() - 0.5) * WORLD_SIZE * 0.6;
    const z = (Math.random() - 0.5) * WORLD_SIZE * 0.6;
    t.position.set(x, heightAt(x, z), z);
    t.rotation.y = Math.random() * Math.PI * 2;
    scene.add(t);
    targets.push({ mesh: t, hp: 3, alive: true, respawnTimer: 0, homeX: x, homeZ: z });
  }
}
spawnTargets();
