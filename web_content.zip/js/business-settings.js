// =====================================================
// NetEarn Pro - Central Business Settings
// Single source of truth for configurable business values.
// Reads settings/main and keeps a per-page memory cache.
// =====================================================

import { db } from "./firebase.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

export const DEFAULT_BUSINESS_SETTINGS = Object.freeze({
    referralBonus: 50,
    taskReward: 0,
    welcomeBonus: 5,
    typingReward: 30,
    editingReward: 40,
    formReward: 30,
    microJobReward: 0,
    dailyBonus: 5,
    monthlyBonus: 500,
    targetBonus: 100,
    minimumWithdraw: 100,
    withdrawFee: 0,
    premiumFee: 299
});

let cachedSettings = null;
let settingsPromise = null;

function normalizeSettings(data = {}) {
    const merged = { ...DEFAULT_BUSINESS_SETTINGS, ...data };

    for (const key of Object.keys(DEFAULT_BUSINESS_SETTINGS)) {
        const value = Number(merged[key]);
        if (!Number.isFinite(value) || value < 0) {
            merged[key] = DEFAULT_BUSINESS_SETTINGS[key];
        } else {
            merged[key] = value;
        }
    }

    return merged;
}

export async function getBusinessSettings({ force = false } = {}) {
    if (cachedSettings && !force) {
        return { ...cachedSettings };
    }

    if (settingsPromise && !force) {
        return settingsPromise;
    }

    settingsPromise = (async () => {
        try {
            const snap = await getDoc(doc(db, "settings", "main"));
            cachedSettings = normalizeSettings(
                snap.exists() ? snap.data() : {}
            );
        } catch (error) {
            console.warn("⚠️ Central business settings unavailable; defaults used.", error);
            cachedSettings = normalizeSettings();
        } finally {
            settingsPromise = null;
        }

        return { ...cachedSettings };
    })();

    return settingsPromise;
}

export function clearBusinessSettingsCache() {
    cachedSettings = null;
    settingsPromise = null;
}

export function getConfiguredTaskReward(task = {}, settings = null) {
    const type = String(
        typeof task === "string" ? task : (task.taskType || task.category || task.taskName || task.name || "")
    ).toLowerCase().trim();

    const values = settings || cachedSettings || DEFAULT_BUSINESS_SETTINGS;

    if (type.includes("typing")) return Number(values.typingReward ?? DEFAULT_BUSINESS_SETTINGS.typingReward);
    if (type.includes("photo") || type.includes("editing")) return Number(values.editingReward ?? DEFAULT_BUSINESS_SETTINGS.editingReward);
    if (type.includes("form")) return Number(values.formReward ?? DEFAULT_BUSINESS_SETTINGS.formReward);

    return Number(
        typeof task === "object"
            ? (task.reward ?? task.taskReward ?? values.taskReward ?? DEFAULT_BUSINESS_SETTINGS.taskReward)
            : (values.taskReward ?? DEFAULT_BUSINESS_SETTINGS.taskReward)
    );
}
