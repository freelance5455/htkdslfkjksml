"use strict";

"use strict";

const Setup = (() => {
  let draft = null;
  let mafiaTouched = false;

  const $ = (id) => document.getElementById(id);

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function resizeNames(count) {
    while (draft.names.length < count) draft.names.push(`لاعب ${draft.names.length + 1}`);
    draft.names.length = count;
  }

  function renderNames(invalidIndexes = []) {
    const list = $("names-list");
    list.innerHTML = "";
    draft.names.forEach((name, index) => {
      const input = document.createElement("input");
      input.type = "text";
      input.className = "text-input";
      input.maxLength = Game.MAX_NAME_LENGTH + 4;
      input.placeholder = `اللاعب ${index + 1}`;
      input.value = name;
      input.dataset.nameIndex = String(index);
      if (invalidIndexes.includes(index)) input.classList.add("invalid");
      list.appendChild(input);
    });
  }

  function renderRoles() {
    const list = $("roles-list");
    list.innerHTML = "";
    Roles.optionalRoles().forEach((role) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "chip";
      if (draft.enabledRoles.includes(role.id)) chip.classList.add("on");
      chip.dataset.role = role.id;
      chip.textContent = `${role.icon} ${role.name}`;
      chip.style.setProperty("--role-color", role.color);
      list.appendChild(chip);
    });
  }

  function renderCounters() {
    $("players-value").textContent = draft.playerCount;
    $("mafia-value").textContent = draft.mafiaCount;
    const max = Game.maxMafia(draft.playerCount);
    const rec = Game.recommendedMafia(draft.playerCount);
    const town = draft.playerCount - draft.mafiaCount;
    $("mafia-hint").textContent =
      `الموصى به: ${rec} — الحد الأقصى: ${max} — المواطنون: ${town}`;
  }

  function renderSettingsFields() {
    document.querySelectorAll("[data-setting]").forEach((el) => {
      const key = el.dataset.setting;
      if (el.type === "checkbox") el.checked = Boolean(draft[key]);
      else el.value = String(draft[key]);
    });
    const disabled = !draft.timerEnabled;
    $("discussion-time").disabled = disabled;
    $("voting-time").disabled = disabled;
  }

  function renderErrors(errors) {
    const box = $("setup-errors");
    box.innerHTML = "";
    if (!errors.length) {
      box.classList.remove("show");
      return;
    }
    errors.forEach((message) => {
      const line = document.createElement("div");
      line.textContent = "⚠️ " + message;
      box.appendChild(line);
    });
    box.classList.add("show");
  }

  function renderAll() {
    renderCounters();
    renderNames();
    renderRoles();
    renderSettingsFields();
    renderErrors([]);
  }

  function changePlayers(delta) {
    const count = clamp(draft.playerCount + delta, Game.MIN_PLAYERS, Game.MAX_PLAYERS);
    if (count === draft.playerCount) return;
    draft.playerCount = count;
    resizeNames(count);
    const max = Game.maxMafia(count);
    if (!mafiaTouched) draft.mafiaCount = Game.recommendedMafia(count);
    else draft.mafiaCount = clamp(draft.mafiaCount, 1, max);
    renderCounters();
    renderNames();
    renderErrors([]);
  }

  function changeMafia(delta) {
    const max = Game.maxMafia(draft.playerCount);
    const next = draft.mafiaCount + delta;
    if (next > max) {
      UI.toast(`فريق غير متوازن: الحد الأقصى ${max}`);
      return;
    }
    if (next < 1) return;
    draft.mafiaCount = next;
    mafiaTouched = true;
    renderCounters();
  }

  function toggleRole(roleId) {
    const index = draft.enabledRoles.indexOf(roleId);
    if (index >= 0) draft.enabledRoles.splice(index, 1);
    else draft.enabledRoles.push(roleId);
    renderRoles();
  }

  function onClick(event) {
    const chip = event.target.closest("[data-role]");
    if (chip) {
      toggleRole(chip.dataset.role);
      return;
    }
    const btn = event.target.closest("[data-step]");
    if (!btn) return;
    const delta = Number(btn.dataset.delta);
    if (btn.dataset.step === "players") changePlayers(delta);
    else if (btn.dataset.step === "mafia") changeMafia(delta);
  }

  function onInput(event) {
    const el = event.target;
    if (el.dataset.nameIndex !== undefined) {
      draft.names[Number(el.dataset.nameIndex)] = el.value;
      el.classList.remove("invalid");
      return;
    }
    const key = el.dataset.setting;
    if (!key) return;
    if (el.type === "checkbox") draft[key] = el.checked;
    else if (el.dataset.type === "number") draft[key] = Number(el.value);
    else draft[key] = el.value;

    if (key === "timerEnabled") renderSettingsFields();
    if (key === "complexity") {
      draft.enabledRoles = Roles.presetFor(draft.complexity);
      renderRoles();
    }
  }

  function onSubmit() {
    const result = Game.validateSettings(draft);
    renderErrors(result.errors);
    if (!result.valid) {
      renderNames(result.invalidNameIndexes);
      UI.toast("صحّح الأخطاء أولًا");
      return;
    }
    Game.setSettings(draft);
    const started = Game.startNewGame();
    if (!started.ok) {
      UI.toast("تعذر بدء اللعبة");
      return;
    }
    if (started.skipped.length > 0) {
      const names = started.skipped.map((item) => Roles.get(item.id).name).join("، ");
      UI.toast(`لم تُستخدم أدوار: ${names}`, 3600);
    }
    Reveal.start();
  }

  function init() {
    draft = Game.createDefaultSettings();
    mafiaTouched = false;
    renderAll();
    const screen = $("screen-setup");
    screen.addEventListener("click", onClick);
    screen.addEventListener("input", onInput);
    screen.addEventListener("change", onInput);
    $("btn-start-setup").addEventListener("click", onSubmit);
  }

  return { init };
})();