'use strict';
/* ===== Environment: day and night cycle, weather (clear, rain, snow, fog), street lamps ===== */
const ENV = {
  t: .32,              // time of day: 0 midnight, .25 sunrise, .5 noon, .75 sunset
  dayLen: 300,         // seconds of game time for a full day
  weather: 'clear', nextChange: 80,
  amt: { rain: 0, snow: 0, fog: 0 }, tgt: { rain: 0, snow: 0, fog: 0 }, dayK: 1
};
const WEATHER_NAMES = { clear: 'صافٍ', rain: 'مطر', snow: 'ثلج', fog: 'ضباب' };
const WEATHER_POOL = ['clear', 'clear', 'clear', 'rain', 'rain', 'snow', 'fog'];
const C_DAY = new THREE.Color(0xbfe3f7), C_NIGHT = new THREE.Color(0x0d1729);
const C_RAINFOG = new THREE.Color(0x7d8b99), C_SNOWFOG = new THREE.Color(0xdfe8f0), C_FOG = new THREE.Color(0xc3ccd4);
const C_SKY_DAY = new THREE.Color(0xffffff), C_SKY_DUSK = new THREE.Color(0xffa570), C_SKY_NIGHT = new THREE.Color(0x1c2a4a), C_OVERCAST = new THREE.Color(0x8e98a3);
const C_LAMP_DAY = new THREE.Color(0x4a4a48), C_LAMP_NIGHT = new THREE.Color(0xfff2b8);
const fogCol = new THREE.Color(), tmpC = new THREE.Color();
let rainObj = null, snowObj = null, envGroup = null;

function timeName() {
  const t = ENV.t;
  if (t < .2 || t >= .84) return 'ليل';
  if (t < .27) return 'فجر';
  if (t < .6) return 'نهار';
  if (t < .76) return 'عصر';
  return 'غروب';
}
function weatherName() { return WEATHER_NAMES[ENV.weather]; }
function smoothstep(a, b, x) { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }

function initEnv() {
  envGroup = new THREE.Group(); scene.add(envGroup);
  // rain: vertical streaks in a box that follows the camera
  const N = 1400, rp = new Float32Array(N * 6);
  for (let i = 0; i < N; i++) {
    const x = rnd(-30, 30), y = rnd(0, 30), z = rnd(-30, 30);
    rp.set([x, y, z, x, y - 1.2, z], i * 6);
  }
  const rg = new THREE.BufferGeometry(); rg.setAttribute('position', new THREE.BufferAttribute(rp, 3));
  rainObj = new THREE.LineSegments(rg, new THREE.LineBasicMaterial({ color: 0xaecde0, transparent: true, opacity: 0, depthWrite: false }));
  rainObj.frustumCulled = false; rainObj.visible = false; envGroup.add(rainObj);
  // snow: soft round flakes
  const M = 1000, sp = new Float32Array(M * 3);
  for (let i = 0; i < M; i++) { sp[i * 3] = rnd(-30, 30); sp[i * 3 + 1] = rnd(0, 30); sp[i * 3 + 2] = rnd(-30, 30); }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
  const flake = canvasTex(32, 32, (g, w, h) => {
    const gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
  });
  snowObj = new THREE.Points(sg, new THREE.PointsMaterial({ size: .34, map: flake, transparent: true, opacity: 0, depthWrite: false, color: 0xffffff }));
  snowObj.frustumCulled = false; snowObj.visible = false; envGroup.add(snowObj);
  ENV.weather = 'clear';
}

function updateRainSnow(dt) {
  const rain = ENV.amt.rain, snow = ENV.amt.snow;
  if (rainObj) {
    rainObj.visible = rain > .01;
    rainObj.material.opacity = rain * .5;
    if (rainObj.visible) {
      const a = rainObj.geometry.attributes.position.array, step = dt * 42;
      for (let i = 0; i < a.length; i += 6) {
        a[i + 1] -= step; a[i + 4] -= step;
        if (a[i + 4] < 0) { a[i + 1] += 30; a[i + 4] += 30; }
      }
      rainObj.geometry.attributes.position.needsUpdate = true;
    }
  }
  if (snowObj) {
    snowObj.visible = snow > .01;
    snowObj.material.opacity = snow * .9;
    if (snowObj.visible) {
      const a = snowObj.geometry.attributes.position.array, tt = performance.now() / 1000;
      for (let i = 0; i < a.length; i += 3) {
        a[i + 1] -= dt * 2.4;
        a[i] += Math.sin(tt * .9 + i) * dt * .8;
        if (a[i + 1] < 0) a[i + 1] += 30;
      }
      snowObj.geometry.attributes.position.needsUpdate = true;
    }
  }
}

/* call once per frame; px, pz is the player's position, which the sun follows */
function updateEnv(dt, px, pz) {
  ENV.t = (ENV.t + dt / ENV.dayLen) % 1;
  ENV.nextChange -= dt;
  if (ENV.nextChange <= 0) {
    let w; do { w = pick(WEATHER_POOL); } while (w === ENV.weather);
    ENV.weather = w; ENV.nextChange = rnd(70, 120);
    ENV.tgt = { rain: w === 'rain' ? 1 : 0, snow: w === 'snow' ? 1 : 0, fog: w === 'fog' ? 1 : 0 };
  }
  const k = Math.min(1, dt * .35);
  for (const key of ['rain', 'snow', 'fog']) ENV.amt[key] += (ENV.tgt[key] - ENV.amt[key]) * k;
  const { rain, snow, fog } = ENV.amt;

  // sun path: rises at .25, peaks at .5, sets at .75
  const a = (ENV.t - .25) * Math.PI * 2, e = Math.sin(a), cx = Math.cos(a);
  const dayK = smoothstep(-.12, .22, e); ENV.dayK = dayK;
  const dim = 1 - rain * .35 - snow * .2 - fog * .3;
  if (sun) {
    sun.position.set(px + cx * 110, e * 140 + 1, pz + 50);
    sun.target.position.set(px, 0, pz); sun.target.updateMatrixWorld();
    sun.intensity = dayK * 1.15 * dim;
  }
  if (hemi) hemi.intensity = (.22 + .65 * dayK) * (1 - rain * .2 - snow * .1 - fog * .1);

  // sky: night blue, orange at dusk, grey when overcast
  const dusk = Math.max(0, 1 - Math.abs(e) * 5) * .8;
  tmpC.copy(C_SKY_NIGHT).lerp(C_SKY_DAY, dayK).lerp(C_SKY_DUSK, dusk).lerp(C_OVERCAST, Math.min(1, rain * .7 + snow * .5 + fog * .6));
  if (skyMesh) skyMesh.material.color.copy(tmpC);

  // fog: colour and distance change with time and weather
  fogCol.copy(C_NIGHT).lerp(C_DAY, dayK);
  fogCol.lerp(C_RAINFOG, rain * .8).lerp(C_SNOWFOG, snow * .8).lerp(C_FOG, fog * .9);
  scene.fog.color.copy(fogCol);
  scene.fog.near = Math.max(20, 170 - rain * 60 - snow * 60 - fog * 150);
  scene.fog.far = 680 - rain * 260 - snow * 270 - fog * 560;

  // street lamps glow at night
  lampMat.color.copy(C_LAMP_DAY).lerp(C_LAMP_NIGHT, 1 - dayK);

  envGroup.position.set(px, 0, pz);
  updateRainSnow(dt);
}
