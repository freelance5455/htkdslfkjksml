/* UrbaAlerte — moteur de carte (Web Mercator, tuiles XYZ, canvas) sans dépendance */
(function(w){
'use strict';
const TS=256,PI=Math.PI;
const lx=(lng,z)=>(lng+180)/360*Math.pow(2,z)*TS;
const ly=(lat,z)=>{const s=Math.sin(lat*PI/180);return(.5-Math.log((1+s)/(1-s))/(4*PI))*Math.pow(2,z)*TS};
const xl=(x,z)=>x/(Math.pow(2,z)*TS)*360-180;
const yl=(y,z)=>{const n=PI-2*PI*y/(Math.pow(2,z)*TS);return 180/PI*Math.atan(.5*(Math.exp(n)-Math.exp(-n)))};
const cache=new Map();
function UMap(el,o){
 o=o||{};this.o=o;this.el=el;this.c={lat:o.lat,lng:o.lng};this.z=o.zoom||14;this.minZ=o.minZ||10;this.maxZ=o.maxZ||18;
 this.tileUrl=o.tileUrl||'';this.markers=[];this.layers=[];this.user=null;this.radius=null;this.selected=null;this.dirty=true;this.running=false;
 const wrap=this.wrap=document.createElement('div');wrap.className='mapwrap';
 this.tc=document.createElement('canvas');this.tc.className='tiles';this.oc=document.createElement('canvas');
 wrap.appendChild(this.tc);wrap.appendChild(this.oc);el.insertBefore(wrap,el.firstChild);
 this.tx=this.tc.getContext('2d');this.ox=this.oc.getContext('2d');
 this.ptrs=new Map();this.moved=0;this.tilesShown=0;
 this.bind();this.resize();
 if(w.ResizeObserver){this.ro=new ResizeObserver(()=>this.resize());this.ro.observe(el)}
}
const P=UMap.prototype;
P.resize=function(){const r=this.el.getBoundingClientRect();this.dpr=Math.min(w.devicePixelRatio||1,2);this.w=Math.max(1,r.width);this.h=Math.max(1,r.height);
 [this.tc,this.oc].forEach(c=>{c.width=Math.round(this.w*this.dpr);c.height=Math.round(this.h*this.dpr)});this.dirty=true};
P.px=function(lat,lng){return{x:lx(lng,this.z)-lx(this.c.lng,this.z)+this.w/2,y:ly(lat,this.z)-ly(this.c.lat,this.z)+this.h/2}};
P.unpx=function(x,y){const cx=lx(this.c.lng,this.z),cy=ly(this.c.lat,this.z);return{lat:yl(cy+y-this.h/2,this.z),lng:xl(cx+x-this.w/2,this.z)}};
P.mpp=function(){return 156543.03392*Math.cos(this.c.lat*PI/180)/Math.pow(2,this.z)};
P.setCenter=function(lat,lng,z){this.c={lat,lng};if(z!=null)this.z=Math.max(this.minZ,Math.min(this.maxZ,z));this.dirty=true;this.moveEnd()};
P.moveEnd=function(){if(this.o.onMove)this.o.onMove(this.c.lat,this.c.lng,this.z)};
P.zoomAt=function(nz,sx,sy){nz=Math.max(this.minZ,Math.min(this.maxZ,nz));const g=this.unpx(sx,sy);this.z=nz;
 const gx=lx(g.lng,nz),gy=ly(g.lat,nz);this.c={lat:yl(gy-(sy-this.h/2),nz),lng:xl(gx-(sx-this.w/2),nz)};this.dirty=true};
P.flyTo=function(lat,lng,z){const s={lat:this.c.lat,lng:this.c.lng,z:this.z},t0=performance.now(),D=650,tz=z==null?this.z:z;
 const e=t=>t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;const step=now=>{const k=Math.min(1,(now-t0)/D),q=e(k);this.c={lat:s.lat+(lat-s.lat)*q,lng:s.lng+(lng-s.lng)*q};this.z=s.z+(tz-s.z)*q;this.dirty=true;if(k<1)requestAnimationFrame(step);else this.moveEnd()};requestAnimationFrame(step)};
P.bind=function(){const c=this.oc,self=this;c.style.touchAction='none';
 c.addEventListener('pointerdown',e=>{c.setPointerCapture(e.pointerId);self.ptrs.set(e.pointerId,{x:e.offsetX,y:e.offsetY});self.moved=0;self.t0=Date.now();self.pd=self.pinchDist()});
 c.addEventListener('pointermove',e=>{const p=self.ptrs.get(e.pointerId);if(!p)return;const nx=e.offsetX,ny=e.offsetY;
  if(self.ptrs.size===1){const dx=nx-p.x,dy=ny-p.y;self.moved+=Math.abs(dx)+Math.abs(dy);const cx=lx(self.c.lng,self.z)-dx,cy=ly(self.c.lat,self.z)-dy;self.c={lat:yl(cy,self.z),lng:xl(cx,self.z)};self.dirty=true}
  p.x=nx;p.y=ny;
  if(self.ptrs.size===2){const d=self.pinchDist(),m=self.pinchMid();if(self.pd&&d){self.zoomAt(self.z+Math.log2(d/self.pd),m.x,m.y)}self.pd=d;self.moved+=10}});
 const up=e=>{if(!self.ptrs.has(e.pointerId))return;self.ptrs.delete(e.pointerId);self.pd=self.pinchDist();
  if(!self.ptrs.size){if(self.moved<7&&Date.now()-self.t0<500)self.tap(e.offsetX,e.offsetY);else self.moveEnd()}};
 c.addEventListener('pointerup',up);c.addEventListener('pointercancel',up);
 c.addEventListener('wheel',e=>{e.preventDefault();self.zoomAt(self.z-e.deltaY*.0025,e.offsetX,e.offsetY);self.moveEnd()},{passive:false});
 c.addEventListener('dblclick',e=>{self.zoomAt(self.z+1,e.offsetX,e.offsetY);self.moveEnd()})};
P.pinchDist=function(){if(this.ptrs.size<2)return 0;const a=[...this.ptrs.values()];return Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)};
P.pinchMid=function(){const a=[...this.ptrs.values()];return{x:(a[0].x+a[1].x)/2,y:(a[0].y+a[1].y)/2}};
P.tap=function(x,y){let best=null,bd=26;this.markers.forEach(m=>{const p=this.px(m.lat,m.lng),d=Math.hypot(p.x-x,p.y-y);if(d<bd){bd=d;best=m}});
 if(this.o.onTap)this.o.onTap(best,this.unpx(x,y))};
P.tile=function(url){let i=cache.get(url);if(!i){i=new Image();i.decoding='async';i.onload=()=>{i._ok=1;this.dirty=true};i.onerror=()=>{i._err=Date.now()};i.src=url;cache.set(url,i);if(cache.size>600){const k=cache.keys().next().value;cache.delete(k)}}
 else if(i._err&&Date.now()-i._err>20000&&navigator.onLine!==false){i._err=0;i.src=url+(url.indexOf('?')<0?'?':'&')+'r='+Date.now()}return i};
P.start=function(){if(this.running)return;this.running=true;this.resize();let last=0;const loop=t=>{if(!this.running)return;if(t-last>30){last=t;this.draw(t)}requestAnimationFrame(loop)};requestAnimationFrame(loop)};
P.stop=function(){this.running=false};
P.destroy=function(){this.stop();if(this.ro)this.ro.disconnect();this.wrap.remove()};
P.draw=function(t){const W=this.w,H=this.h,d=this.dpr,tx=this.tx,ox=this.ox;
 tx.setTransform(d,0,0,d,0,0);tx.clearRect(0,0,W,H);
 const zt=Math.max(0,Math.min(19,Math.round(this.z))),sc=Math.pow(2,this.z-zt),n=Math.pow(2,zt);
 const cx=lx(this.c.lng,zt),cy=ly(this.c.lat,zt),hw=W/2/sc,hh=H/2/sc;let shown=0;
 if(this.tileUrl&&navigator.onLine!==false){
  const x0=Math.floor((cx-hw)/TS),x1=Math.floor((cx+hw)/TS),y0=Math.floor((cy-hh)/TS),y1=Math.floor((cy+hh)/TS);
  for(let y=y0;y<=y1;y++){if(y<0||y>=n)continue;for(let x=x0;x<=x1;x++){const xx=((x%n)+n)%n;const im=this.tile(this.tileUrl.replace('{z}',zt).replace('{x}',xx).replace('{y}',y));
   if(im._ok){tx.drawImage(im,(x*TS-cx)*sc+W/2,(y*TS-cy)*sc+H/2,TS*sc+.6,TS*sc+.6);shown++}}}}
 this.tilesShown=shown;
 ox.setTransform(d,0,0,d,0,0);ox.clearRect(0,0,W,H);
 if(!shown)this.fallback(ox,t);
 this.layers.forEach(f=>{try{f(ox,this,t)}catch(e){}});
 this.drawRadius(ox);this.drawMarkers(ox,t);this.drawUser(ox,t);
 if(this.o.hud!==false)this.hudFrame(ox)};
P.fallback=function(g,t){const W=this.w,H=this.h;g.fillStyle='#061030';g.fillRect(0,0,W,H);
 const mpp=this.mpp(),stepM=mpp*60>400?2000:mpp*60>120?500:100,step=stepM/mpp,off=this.px(-4.45,15.28);
 g.strokeStyle='rgba(120,170,255,.13)';g.lineWidth=1;g.beginPath();
 for(let x=((off.x%step)+step)%step;x<W;x+=step){g.moveTo(x,0);g.lineTo(x,H)}for(let y=((off.y%step)+step)%step;y<H;y+=step){g.moveTo(0,y);g.lineTo(W,y)}g.stroke();
 g.strokeStyle='rgba(34,211,238,.18)';g.beginPath();for(let x=((off.x%(step*5))+step*5)%(step*5);x<W;x+=step*5){g.moveTo(x,0);g.lineTo(x,H)}for(let y=((off.y%(step*5))+step*5)%(step*5);y<H;y+=step*5){g.moveTo(0,y);g.lineTo(W,y)}g.stroke();
 g.fillStyle='rgba(143,163,200,.75)';g.font='11px "UA Mono",monospace';g.textAlign='center';g.fillText('FOND DE CARTE INDISPONIBLE · MODE HORS LIGNE',W/2,H-118);
 g.fillText('grille '+(stepM>=1000?stepM/1000+' km':stepM+' m'),W/2,H-102)};
P.hudFrame=function(g){const W=this.w,H=this.h,L=16;g.strokeStyle='rgba(34,211,238,.55)';g.lineWidth=2;[[6,6,1,1],[W-6,6,-1,1],[6,H-6,1,-1],[W-6,H-6,-1,-1]].forEach(a=>{g.beginPath();g.moveTo(a[0],a[1]+a[3]*L);g.lineTo(a[0],a[1]);g.lineTo(a[0]+a[2]*L,a[1]);g.stroke()})};
P.drawRadius=function(g){if(!this.radius||!this.user)return;const p=this.px(this.user.lat,this.user.lng),r=this.radius*1000/this.mpp();
 const gr=g.createRadialGradient(p.x,p.y,r*.2,p.x,p.y,r);gr.addColorStop(0,'rgba(34,211,238,0)');gr.addColorStop(1,'rgba(34,211,238,.13)');g.fillStyle=gr;g.beginPath();g.arc(p.x,p.y,r,0,PI*2);g.fill();
 g.setLineDash([7,6]);g.strokeStyle='rgba(103,232,249,.75)';g.lineWidth=1.5;g.stroke();g.setLineDash([]);
 g.fillStyle='rgba(103,232,249,.9)';g.font='600 10.5px "UA Mono",monospace';g.textAlign='center';g.fillText(this.radius+' KM',p.x,p.y-r-6)};
P.drawUser=function(g,t){if(!this.user)return;const p=this.px(this.user.lat,this.user.lng);const ph=(t%2000)/2000;
 if(this.user.acc){const ar=this.user.acc/this.mpp();if(ar>8&&ar<400){g.fillStyle='rgba(59,130,246,.12)';g.beginPath();g.arc(p.x,p.y,ar,0,PI*2);g.fill()}}
 g.strokeStyle='rgba(34,211,238,'+(.7*(1-ph))+')';g.lineWidth=2;g.beginPath();g.arc(p.x,p.y,10+ph*26,0,PI*2);g.stroke();
 g.fillStyle='#fff';g.beginPath();g.arc(p.x,p.y,10,0,PI*2);g.fill();g.fillStyle='#2d9cff';g.shadowColor='#22d3ee';g.shadowBlur=14;g.beginPath();g.arc(p.x,p.y,7,0,PI*2);g.fill();g.shadowBlur=0};
P.drawMarkers=function(g,t){const small=this.z<13,now=Date.now();
 this.markers.forEach(m=>{const p=this.px(m.lat,m.lng);if(p.x<-30||p.y<-30||p.x>this.w+30||p.y>this.h+30)return;const sel=this.selected===m.id;
  if(small&&!sel){g.fillStyle=m.color;g.shadowColor=m.color;g.shadowBlur=8;g.beginPath();g.arc(p.x,p.y,4.5,0,PI*2);g.fill();g.shadowBlur=0;return}
  if(m.fresh&&now-m.fresh<9000){const k=((now-m.fresh)%1800)/1800;g.strokeStyle=m.color;g.globalAlpha=1-k;g.lineWidth=2.5;g.beginPath();g.arc(p.x,p.y,14+k*34,0,PI*2);g.stroke();g.globalAlpha=1}
  const R=sel?17:13;g.shadowColor=m.color;g.shadowBlur=sel?22:12;g.fillStyle='#071030';g.beginPath();g.arc(p.x,p.y,R,0,PI*2);g.fill();g.shadowBlur=0;
  g.lineWidth=sel?3:2;g.strokeStyle=m.color;g.stroke();
  if(m.mine){g.strokeStyle='#fff';g.lineWidth=1;g.beginPath();g.arc(p.x,p.y,R+4,0,PI*2);g.stroke()}
  g.save();g.translate(p.x-R*.62,p.y-R*.62);g.scale(R*1.24/24,R*1.24/24);g.strokeStyle=m.color;g.lineWidth=2;g.lineCap='round';g.lineJoin='round';g.stroke(new Path2D(IP(m.icon)));g.restore()})};
w.UMap=UMap;
})(window);
