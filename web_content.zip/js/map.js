/* map.js — canvas political map: rendering, zoom/pan (mouse + touch + pinch), hit-testing, flags. */
(function (G) {
  'use strict';

  G.view = { x: 0, y: 0, z: 1 };       // x,y = world coords of canvas top-left; z = pixels per world unit
  G.selected = null;                    // selected province id
  G.hover = null;
  G.mapMode = 'political';              // 'political' | 'terrain' | 'diplomacy' | 'naval' | 'economy'
  G.MAP_MODES = ['political', 'terrain', 'diplomacy', 'naval', 'economy'];
  G.MAP_MODE_NAMES = { political: 'Political', terrain: 'Terrain', diplomacy: 'Diplomatic', naval: 'Naval', economy: 'Economy' };
  G.selZone = null;                     // selected sea zone id ('z3')
  G.selFleet = null;                    // selected fleet id
  G.fleetMoveMode = false;              // choosing a sea/port destination for the selected fleet
  G.onZoneSelect = null; G.onFleetSelect = null; G.onFleetTarget = null;
  G.onSelect = null;                    // callback(provinceId|null)
  G.selArmy = null;                     // selected army id
  G.moveMode = false;                   // true while choosing a destination
  G.onArmySelect = null; G.onMoveTarget = null;
  let armyHits = [], fleetHits = [];

  let canvas, ctx, W = 0, H = 0, dpr = 1, dirty = true;
  const cache = {};

  /* ---------- flags ---------- */
  G.drawFlag = function (c, x, y, w, h, id) {
    if (G.scenarioId === 'world' && G.drawRealFlag && G.drawRealFlag(c, x, y, w, h, id)) return;
    const f = G.COUNTRIES[id].flag;
    c.save();
    c.fillStyle = f[0]; c.fillRect(x, y, w, h);
    c.fillStyle = f[1];
    if (f[2] === 'h') c.fillRect(x, y + h * 0.4, w, h * 0.2);
    else if (f[2] === 'v') c.fillRect(x + w * 0.4, y, w * 0.2, h);
    else { c.fillRect(x, y + h * 0.4, w, h * 0.2); c.fillRect(x + w * 0.3, y, w * 0.2, h); }
    c.strokeStyle = 'rgba(0,0,0,.6)'; c.lineWidth = 1; c.strokeRect(x + .5, y + .5, w - 1, h - 1);
    c.restore();
  };
  G.flagURL = function (id) {
    if (cache['f' + id]) return cache['f' + id];
    const cv = document.createElement('canvas'); cv.width = 72; cv.height = 48;
    G.drawFlag(cv.getContext('2d'), 0, 0, 72, 48, id);
    return (cache['f' + id] = cv.toDataURL());
  };

  /* ---------- coordinate helpers ---------- */
  G.toWorld = function (sx, sy) { return { x: sx / G.view.z + G.view.x, y: sy / G.view.z + G.view.y }; };
  function minZoom() { return Math.max(W / G.WORLD_W, H / G.WORLD_H) * 0.9; }
  function clampView() {
    const v = G.view, z = v.z;
    const vw = W / z, vh = H / z;
    const mx = 80, my = 80;
    if (vw >= G.WORLD_W + 2 * mx) v.x = (G.WORLD_W - vw) / 2; else v.x = Math.max(-mx, Math.min(G.WORLD_W + mx - vw, v.x));
    if (vh >= G.WORLD_H + 2 * my) v.y = (G.WORLD_H - vh) / 2; else v.y = Math.max(-my, Math.min(G.WORLD_H + my - vh, v.y));
  }
  G.zoomAt = function (sx, sy, factor) {
    const v = G.view;
    const nz = Math.max(minZoom(), Math.min(6, v.z * factor));
    const wx = sx / v.z + v.x, wy = sy / v.z + v.y;
    v.z = nz; v.x = wx - sx / nz; v.y = wy - sy / nz;
    clampView(); dirty = true;
  };
  G.fitView = function () {
    G.view.z = minZoom() / 0.9; G.view.x = 0; G.view.y = 0; clampView(); dirty = true;
  };
  G.focusProvince = function (id) {
    const p = G.provinces[id]; if (!p) return;
    const v = G.view; v.z = Math.max(v.z, 1.6);
    v.x = p.cx - W / v.z / 2; v.y = p.cy - H / v.z / 2; clampView(); dirty = true;
  };
  // Keep a province clear of the info panel (bottom sheet in portrait, left sidebar in landscape).
  G.ensureVisible = function (id, insetBottom, insetLeft) {
    const p = G.provinces[id]; if (!p) return;
    const v = G.view, pad = 40;
    const sx = (p.cx - v.x) * v.z, sy = (p.cy - v.y) * v.z;
    const maxY = H - (insetBottom || 0) - pad, minX = (insetLeft || 0) + pad;
    if (sy > maxY) v.y += (sy - maxY) / v.z;
    if (sx < minX) v.x -= (minX - sx) / v.z;
    clampView(); dirty = true;
  };
  G.requestDraw = function () { dirty = true; };

  /* ---------- hit-test ---------- */
  function inPoly(poly, x, y) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i], b = poly[j];
      if ((a.y > y) !== (b.y > y) && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) inside = !inside;
    }
    return inside;
  }
  G.provinceAt = function (sx, sy) {
    const w = G.toWorld(sx, sy);
    if (G.landMask) {                         // real-coast scenario: land cells are clipped to the coastline
      const land = G.landMask.has(w.x, w.y);
      let near = null, nd = 1e18;
      for (const p of G.provinces) {
        if (land) { if (!p.sea && inPoly(p.poly, w.x, w.y)) return p.id; }
        else if (p.sea) { if (inPoly(p.poly, w.x, w.y)) return p.id; const d = (p.x - w.x) ** 2 + (p.y - w.y) ** 2; if (d < nd) { nd = d; near = p.id; } }
      }
      return land ? null : near;
    }
    for (const p of G.provinces) if (inPoly(p.poly, w.x, w.y)) return p.id;
    return null;
  };
  let landPath = null, landPathFor = null;
  function getLandPath() {
    if (!G.landRings) return null;
    if (landPathFor !== G.landRings) {
      landPathFor = G.landRings; landPath = new Path2D();
      for (const r of G.landRings) { r.forEach((q, i) => i ? landPath.lineTo(q[0], q[1]) : landPath.moveTo(q[0], q[1])); landPath.closePath(); }
    }
    return landPath;
  }
  // Map position of a naval node: a port province (number) or a sea zone ('z3').
  G.nodePos = function (n) {
    if (typeof n === 'string') { const z = G.zoneById[n]; return z ? { x: z.cx, y: z.cy } : { x: 0, y: 0 }; }
    const p = G.provinces[n]; return { x: p.cx, y: p.cy };
  };

  /* ---------- drawing ---------- */
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16);
    let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    r = Math.max(0, Math.min(255, Math.round(r * f))); g = Math.max(0, Math.min(255, Math.round(g * f))); b = Math.max(0, Math.min(255, Math.round(b * f)));
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }
  function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; }
  function tracePoly(p) {
    ctx.beginPath();
    p.poly.forEach((v, i) => i ? ctx.lineTo(v.x, v.y) : ctx.moveTo(v.x, v.y));
    ctx.closePath();
  }

  function draw(t) {
    const st = G.state; if (!st || !G.provinces) return;
    const v = G.view;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // ocean
    const og = ctx.createLinearGradient(0, 0, 0, H);
    og.addColorStop(0, '#16324a'); og.addColorStop(1, '#0d2236');
    ctx.fillStyle = og; ctx.fillRect(0, 0, W, H);

    ctx.save();
    ctx.scale(v.z, v.z); ctx.translate(-v.x, -v.y);
    const P = G.provinces;
    const selOwner = G.selected != null ? st.owners[G.selected] : null;

    // sea zones: faint zone borders (and a tint in naval mode)
    if (G.mapMode === 'naval' && G.zones) {
      for (const z of G.zones) {
        const dom = G.zoneDominant ? G.zoneDominant(z.id) : null;
        const sel = G.selZone === z.id;
        ctx.fillStyle = sel ? 'rgba(255,230,140,.20)' : dom ? rgba(G.COUNTRIES[dom].color, 0.30) : 'rgba(40,90,140,.10)';
        for (const c of z.cells) { tracePoly(P[c]); ctx.fill(); }
      }
    } else if (G.selZone && G.zoneById && G.zoneById[G.selZone]) {
      ctx.fillStyle = 'rgba(255,230,140,.16)';
      for (const c of G.zoneById[G.selZone].cells) { tracePoly(P[c]); ctx.fill(); }
    }
    ctx.beginPath();
    for (const p of P) {
      if (!p.sea) continue;
      const n = p.poly.length;
      for (let i = 0; i < n; i++) {
        const a = p.poly[i], b = p.poly[(i + 1) % n], nb = a.e;
        if (nb >= 0 && P[nb].sea && P[nb].zone !== p.zone && nb > p.id) { ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
      }
    }
    ctx.lineWidth = (G.mapMode === 'naval' ? 1.4 : 0.8) / v.z; ctx.strokeStyle = G.mapMode === 'naval' ? 'rgba(150,200,240,.55)' : 'rgba(120,170,210,.16)'; ctx.stroke();

    // land fill (clipped to the real coastline when the scenario has one)
    const LP = getLandPath();
    ctx.save();
    if (LP) { ctx.beginPath(); ctx.rect(0, 0, G.WORLD_W, G.WORLD_H); ctx.clip(); ctx.clip(LP, 'evenodd'); }
    for (const p of P) {
      if (p.sea) continue;
      const o = st.owners[p.id], c = G.COUNTRIES[o];
      let fill;
      if (G.mapMode === 'terrain') fill = G.TERRAIN[p.terrain].color;
      else if (G.mapMode === 'diplomacy') fill = G.relationColor(o);
      else if (G.mapMode === 'economy') fill = G.economyColor(p);
      else if (G.mapMode === 'naval') fill = shade(c.color, 0.62);
      else fill = shade(c.color, o === selOwner ? 1.12 : 0.92);
      tracePoly(p); ctx.fillStyle = fill; ctx.fill();
      if (G.mapMode === 'political' && p.terrain !== 'plains' && p.terrain !== 'urban') {
        // subtle terrain tint so provinces differ inside one country
        ctx.fillStyle = p.terrain === 'mountain' ? 'rgba(255,255,255,.18)' : p.terrain === 'forest' ? 'rgba(0,40,0,.14)' : p.terrain === 'hills' ? 'rgba(80,50,0,.10)' : p.terrain === 'desert' ? 'rgba(200,150,40,.16)' : 'rgba(0,50,60,.12)';
        ctx.fill();
      }
    }
    // province borders (thin) then country/coast borders (thick)
    ctx.lineJoin = 'round';
    for (let pass = 0; pass < 2; pass++) {
      ctx.beginPath();
      for (const p of P) {
        if (p.sea) continue;
        const n = p.poly.length;
        for (let i = 0; i < n; i++) {
          const a = p.poly[i], b = p.poly[(i + 1) % n], nb = a.e;
          let kind; // 0 internal, 1 country border, 2 coast
          if (nb < 0) kind = 2;
          else if (P[nb].sea) kind = 2;
          else kind = st.owners[nb] !== st.owners[p.id] ? 1 : 0;
          if (pass === 0 ? kind === 0 : kind > 0) {
            if (pass === 1 && kind === 1 && nb < p.id) continue; // draw shared edge once
            ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
          }
        }
      }
      if (pass === 0) { ctx.strokeStyle = 'rgba(0,0,0,.28)'; ctx.lineWidth = 0.8 / v.z; }
      else { ctx.strokeStyle = 'rgba(10,10,14,.9)'; ctx.lineWidth = 2.2 / v.z; }
      ctx.stroke();
    }
    // selected country outline glow
    if (selOwner && LP) {
      ctx.save(); ctx.beginPath();
      for (const p of P) { if (p.sea || st.owners[p.id] !== selOwner) continue; p.poly.forEach((q, i) => i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)); ctx.closePath(); }
      ctx.clip(); ctx.strokeStyle = 'rgba(255,230,140,.95)'; ctx.lineWidth = 6 / v.z; ctx.stroke(LP); ctx.restore();
    }
    if (selOwner) {
      ctx.beginPath();
      for (const p of P) {
        if (p.sea || st.owners[p.id] !== selOwner) continue;
        const n = p.poly.length;
        for (let i = 0; i < n; i++) {
          const a = p.poly[i], b = p.poly[(i + 1) % n], nb = a.e;
          if (nb < 0 || P[nb].sea || st.owners[nb] !== selOwner) { ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
        }
      }
      ctx.strokeStyle = 'rgba(255,230,140,.95)'; ctx.lineWidth = 3 / v.z; ctx.stroke();
    }
    // hover + selected province
    if (G.hover != null && !P[G.hover].sea) { tracePoly(P[G.hover]); ctx.fillStyle = 'rgba(255,255,255,.14)'; ctx.fill(); }
    if (G.selected != null) {
      const p = P[G.selected];
      tracePoly(p); ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.fill();
      ctx.setLineDash([6 / v.z, 4 / v.z]); ctx.lineDashOffset = -(t / 60) / v.z;
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.4 / v.z; ctx.stroke(); ctx.setLineDash([]);
    }
    // occupation progress overlay
    if (st.occ) for (const k in st.occ) {
      const o = st.occ[k], p = P[k]; if (!p) continue;
      const col = G.COUNTRIES[o.by].color, need = G.occupationNeed(+k);
      tracePoly(p); ctx.fillStyle = rgba(col, 0.18 + 0.5 * Math.min(1, o.days / need)); ctx.fill();
      ctx.setLineDash([5 / v.z, 4 / v.z]); ctx.strokeStyle = col; ctx.lineWidth = 3 / v.z; ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.restore();                                  // end of land clip
    if (LP) { ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(8,12,18,.92)'; ctx.lineWidth = 1.7 / v.z; ctx.stroke(LP); }
    ctx.restore();

    // ---- labels (screen space) ----
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round'; ctx.miterLimit = 2;
    const cz = v.z * (G.AVGCELL || 100) / 100;     // zoom normalised to the scenario's province size
    if (G.mapMode === 'naval' || cz >= 0.55) drawSeaLabels(cz);
    if (cz >= 1.15) {
      ctx.font = 'bold ' + Math.min(14, 8 + cz * 2.2) + 'px "Trebuchet MS", sans-serif';
      for (const p of P) {
        if (p.sea) continue;
        const sx = (p.cx - v.x) * v.z, sy = (p.cy - v.y) * v.z;
        if (sx < -60 || sy < -20 || sx > W + 60 || sy > H + 20) continue;
        if (p.capital) { star(sx, sy - 11, 7, '#ffd84a'); }
        if (p.fort > 0) { ctx.save(); ctx.fillStyle = '#222'; ctx.strokeStyle = '#ffd84a'; ctx.lineWidth = 1.5; ctx.fillRect(sx - 30, sy - 8, 14, 14); ctx.strokeRect(sx - 30, sy - 8, 14, 14); ctx.fillStyle = '#ffd84a'; ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(p.fort, sx - 23, sy); ctx.restore(); }
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.65)'; ctx.strokeText(p.name, sx, sy + (p.capital ? 4 : 0));
        ctx.fillStyle = '#fff'; ctx.fillText(p.name, sx, sy + (p.capital ? 4 : 0));
      }
    } else {
      // zoomed out: stars on capitals only
      for (const p of P) if (p.capital) star((p.cx - v.x) * v.z, (p.cy - v.y) * v.z, cz < 0.5 ? 3 : 5, '#ffd84a');
    }
    // country names (large, spaced) when zoomed out; skipped when the country is too small to hold its name
    if (cz < 1.9) {
      const a = Math.max(0, Math.min(1, (1.9 - cz) / 0.6));
      const byOwner = {};
      for (const p of P) { if (p.sea) continue; const o = st.owners[p.id]; if (o) (byOwner[o] = byOwner[o] || []).push(p); }
      for (const id in byOwner) {
        const own = byOwner[id];
        // label the biggest connected block: use the centroid of the province cluster nearest to the capital
        const cap = G.provinces[G.COUNTRIES[id].capitalId];
        let near = own.filter(p => Math.hypot(p.cx - cap.cx, p.cy - cap.cy) < (G.AVGCELL || 100) * 9);
        if (!near.length) near = own;
        let mx = 0, my = 0, x0 = 1e9, x1 = -1e9; near.forEach(p => { mx += p.cx; my += p.cy; x0 = Math.min(x0, p.cx); x1 = Math.max(x1, p.cx); }); mx /= near.length; my /= near.length;
        if (G.landMask) { let bp = near[0], bd = 1e18; near.forEach(p => { const d = (p.cx - mx) ** 2 + (p.cy - my) ** 2; if (d < bd) { bd = d; bp = p; } }); mx = bp.cx; my = bp.cy - 14 / v.z; }
        const sx = (mx - v.x) * v.z, sy = (my - v.y) * v.z;
        if (sx < -80 || sy < -20 || sx > W + 80 || sy > H + 20) continue;
        const nm = G.COUNTRIES[id].name.toUpperCase();
        const fs = Math.max(9, Math.min(22, 12 * cz + 4));
        const span = (x1 - x0 + (G.AVGCELL || 100)) * v.z;
        if (near.length < 3 && span < nm.length * fs * 0.55) { if (cz > 0.5) continue; }
        if (span < nm.length * fs * 0.3 && near.length < 6) continue;
        ctx.font = '900 ' + fs + 'px "Trebuchet MS", sans-serif';
        ctx.globalAlpha = a * 0.9;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.7)';
        ctx.strokeText(nm, sx, sy); ctx.fillStyle = '#f5ecd0'; ctx.fillText(nm, sx, sy);
        ctx.globalAlpha = 1;
      }
    }
    drawArmies(t);
    drawFleets(t);
    drawModeLegend();
  }
  /* ---------- army icons ---------- */
  function drawArmies(t) {
    const st = G.state, v = G.view; armyHits = [];
    if (!st.armies) return;
    // group stationary armies per province so stacks fan out
    const slots = {};
    st.armies.forEach(a => { const k = a.path.length ? 'm' + a.id : 'p' + a.prov; (slots[k] = slots[k] || []).push(a); });
    // selected army route
    const sel = G.selArmy != null ? G.armyById(G.selArmy) : null;
    if (sel && sel.path.length) {
      const pos = G.armyPos(sel);
      ctx.save(); ctx.beginPath(); ctx.moveTo((pos.x - v.x) * v.z, (pos.y - v.y) * v.z);
      sel.path.forEach(pid => { const q = G.provinces[pid]; ctx.lineTo((q.cx - v.x) * v.z, (q.cy - v.y) * v.z); });
      ctx.setLineDash([8, 6]); ctx.lineDashOffset = -t / 40; ctx.strokeStyle = '#ffe48a'; ctx.lineWidth = 3; ctx.stroke();
      const last = G.provinces[sel.path[sel.path.length - 1]];
      ctx.setLineDash([]); ctx.beginPath(); ctx.arc((last.cx - v.x) * v.z, (last.cy - v.y) * v.z, 7, 0, 7); ctx.fillStyle = '#ffe48a'; ctx.fill(); ctx.restore();
    }
    const cellPx = v.z * (G.AVGCELL || 100), bw = Math.max(15, Math.min(40, cellPx * 0.7)), bh = bw * 0.62;
    for (const k in slots) {
      const list = slots[k];
      const seen = list.filter(a => G.canSee(a));
      seen.forEach((a, i) => {
        const list = seen;
        const pos = G.armyPos(a);
        let sx = (pos.x - v.x) * v.z + (i - (list.length - 1) / 2) * (bw + 4), sy = (pos.y - v.y) * v.z + Math.min(26, cellPx * 0.3);
        if (sx < -50 || sy < -30 || sx > W + 50 || sy > H + 30) return;
        const isSel = a.id === G.selArmy, mine = a.owner === st.player;
        ctx.save(); ctx.translate(sx, sy);
        ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 5; ctx.shadowOffsetY = 2;
        ctx.fillStyle = '#141a22'; ctx.fillRect(-bw / 2 - 2, -bh / 2 - 2, bw + 4, bh + 4);
        ctx.shadowColor = 'transparent';
        G.drawFlag(ctx, -bw / 2, -bh / 2, bw, bh, a.owner);
        ctx.font = 'bold ' + Math.max(8, Math.round(bh * 0.62)) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 3; ctx.strokeStyle = '#000'; ctx.strokeText(a.units.length, 0, 1); ctx.fillStyle = '#fff'; ctx.fillText(a.units.length, 0, 1);
        if (isSel) { ctx.strokeStyle = '#ffe48a'; ctx.lineWidth = 2.5 + Math.sin(t / 150); ctx.strokeRect(-bw / 2 - 4, -bh / 2 - 4, bw + 8, bh + 8); }
        else if (mine) { ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1; ctx.strokeRect(-bw / 2 - 2, -bh / 2 - 2, bw + 4, bh + 4); }
        if (pos.moving) { // little arrow showing marching
          ctx.fillStyle = '#ffe48a'; ctx.beginPath(); ctx.moveTo(bw / 2 + 3, -4); ctx.lineTo(bw / 2 + 10, 0); ctx.lineTo(bw / 2 + 3, 4); ctx.fill();
        }
        ctx.restore();
        armyHits.push({ id: a.id, x: sx - bw / 2 - 4, y: sy - bh / 2 - 4, w: bw + 8, h: bh + 8 });
      });
    }
    for (const b of G.activeBattles()) {
      const p = G.provinces[b.prov], sx = (p.cx - v.x) * v.z, sy = (p.cy - v.y) * v.z - 6, pr = 14 + 3 * Math.sin(t / 120);
      ctx.save(); ctx.translate(sx, sy);
      ctx.beginPath(); ctx.arc(0, 0, pr, 0, 7); ctx.fillStyle = 'rgba(160,20,20,.75)'; ctx.fill(); ctx.strokeStyle = '#ffd0c0'; ctx.lineWidth = 2; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-8, -8); ctx.lineTo(8, 8); ctx.moveTo(8, -8); ctx.lineTo(-8, 8); ctx.lineWidth = 3; ctx.strokeStyle = '#fff'; ctx.stroke();
      ctx.restore();
    }
    if (G.moveMode) {
      ctx.font = 'bold 14px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(0,0,0,.7)';
      ctx.fillRect(W / 2 - 130, 8, 260, 28); ctx.fillStyle = '#ffe48a'; ctx.fillText('Tap a destination province', W / 2, 23);
    }
  }
  function hitArmy(sx, sy) {
    for (let i = armyHits.length - 1; i >= 0; i--) { const h = armyHits[i]; if (sx >= h.x && sx <= h.x + h.w && sy >= h.y && sy <= h.y + h.h) return h.id; }
    return null;
  }


  /* ---------- Phase 9: sea labels, fleets, map-mode helpers ---------- */
  function drawSeaLabels(cz) {
    if (!G.zones) return;
    const v = G.view, naval = G.mapMode === 'naval';
    ctx.save(); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = 'italic ' + Math.max(9, Math.min(15, 8 + cz * 3)) + 'px Georgia, serif';
    for (const z of G.zones) {
      const sx = (z.cx - v.x) * v.z, sy = (z.cy - v.y) * v.z;
      if (sx < -80 || sy < -20 || sx > W + 80 || sy > H + 20) continue;
      if (!naval && z.cells.length < 3 && cz < 1.4) continue;       // tiny zones only when zoomed in
      ctx.fillStyle = naval ? 'rgba(210,235,255,.9)' : 'rgba(170,205,235,.55)';
      ctx.fillText(z.name, sx, sy - (naval ? 10 : 0));
    }
    ctx.restore();
  }
  G.relationColor = function (o) {
    const st = G.state, me = st.player;
    if (!o) return '#555';
    if (o === me) return '#e8c66a';
    if (G.atWar(me, o)) return '#c0392b';
    if (G.allied(me, o)) return '#3fae5a';
    const r = G.relation(me, o);
    return r >= 40 ? '#78b878' : r >= 10 ? '#8fb0a0' : r > -10 ? '#7c8794' : r > -40 ? '#c08a4a' : '#b0553f';
  };
  let maxInc = 0, maxIncScen = null;
  G.economyColor = function (p) {
    if (maxIncScen !== G.scenarioId) { maxIncScen = G.scenarioId; maxInc = 0; G.provinces.forEach(q => { if (!q.sea) maxInc = Math.max(maxInc, q.income); }); }
    const f = Math.min(1, p.income / Math.max(1, maxInc * 0.8)), pb = G.state.pb && G.state.pb[p.id];
    const ind = pb ? Math.min(1, (pb.civ + pb.mil) / 6) : 0;
    const r = Math.round(40 + 60 * f + 40 * ind), g = Math.round(60 + 150 * f), b = Math.round(60 - 20 * f);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  };
  function drawModeLegend() {
    const rows = G.mapMode === 'diplomacy' ? [['#e8c66a', 'You'], ['#3fae5a', 'Allied'], ['#78b878', 'Friendly'], ['#7c8794', 'Neutral'], ['#c08a4a', 'Cool'], ['#b0553f', 'Hostile'], ['#c0392b', 'At war']]
      : G.mapMode === 'economy' ? [['rgb(70,90,60)', 'Low income'], ['rgb(100,200,55)', 'High income'], ['rgb(140,220,55)', '+ factories']]
      : G.mapMode === 'naval' ? [['rgba(150,200,240,.9)', 'Sea zone border'], ['rgba(230,120,60,.9)', 'Dominant fleet tint'], ['#e05a4a', 'Blockaded port']] : null;
    if (!rows) return;
    ctx.save(); ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    const x = 10, y = 10, hh = 18 * rows.length + 22;
    ctx.fillStyle = 'rgba(10,16,22,.78)'; ctx.fillRect(x, y, 142, hh);
    ctx.font = 'bold 11px sans-serif'; ctx.fillStyle = '#e8c66a'; ctx.fillText(G.MAP_MODE_NAMES[G.mapMode] + ' map', x + 8, y + 10);
    ctx.font = '11px sans-serif';
    rows.forEach((r, i) => { ctx.fillStyle = r[0]; ctx.fillRect(x + 8, y + 22 + i * 18, 14, 11); ctx.fillStyle = '#e8e4d6'; ctx.fillText(r[1], x + 28, y + 28 + i * 18); });
    ctx.restore();
  }
  function drawFleets(t) {
    const st = G.state, v = G.view; fleetHits = [];
    if (!st.fleets || !G.fleetPos) return;
    const cellPx = v.z * (G.AVGCELL || 100), bw = Math.max(16, Math.min(40, cellPx * 0.7)), bh = bw * 0.62;
    // blockade markers
    if (G.blockadeLevel) for (const p of G.provinces) {
      if (p.sea || !p.seaZones || !p.seaZones.length) continue;
      const b = G.blockadeLevel(p.id); if (b <= 0) continue;
      const sx = (p.cx - v.x) * v.z, sy = (p.cy - v.y) * v.z;
      if (sx < -30 || sy < -30 || sx > W + 30 || sy > H + 30) continue;
      ctx.save(); ctx.translate(sx, sy + 7); ctx.beginPath(); ctx.arc(0, 0, 7, 0, 7); ctx.fillStyle = 'rgba(190,40,30,.9)'; ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-4, 4); ctx.lineTo(4, -4); ctx.stroke(); ctx.restore();
    }
    const sel = G.selFleet != null ? G.fleetById(G.selFleet) : null;
    if (sel && sel.path && sel.path.length) {
      const pos = G.fleetPos(sel);
      ctx.save(); ctx.beginPath(); ctx.moveTo((pos.x - v.x) * v.z, (pos.y - v.y) * v.z);
      sel.path.forEach(n => { const q = G.nodePos(n); ctx.lineTo((q.x - v.x) * v.z, (q.y - v.y) * v.z); });
      ctx.setLineDash([8, 6]); ctx.lineDashOffset = -t / 40; ctx.strokeStyle = '#8fd0ff'; ctx.lineWidth = 3; ctx.stroke();
      const last = G.nodePos(sel.path[sel.path.length - 1]);
      ctx.setLineDash([]); ctx.beginPath(); ctx.arc((last.x - v.x) * v.z, (last.y - v.y) * v.z, 7, 0, 7); ctx.fillStyle = '#8fd0ff'; ctx.fill(); ctx.restore();
    }
    const slots = {};
    st.fleets.forEach(f => { if (!G.canSeeFleet(f)) return; const k = f.path && f.path.length ? 'm' + f.id : 'n' + f.loc; (slots[k] = slots[k] || []).push(f); });
    for (const k in slots) {
      const list = slots[k];
      list.forEach((f, i) => {
        const pos = G.fleetPos(f), docked = typeof f.loc === 'number' && !(f.path && f.path.length);
        const sx = (pos.x - v.x) * v.z + (i - (list.length - 1) / 2) * (bw + 5) + (docked ? bw * 0.6 : 0), sy = (pos.y - v.y) * v.z + (docked ? -Math.min(22, cellPx * 0.35) : 0);
        if (sx < -50 || sy < -30 || sx > W + 50 || sy > H + 30) return;
        const isSel = f.id === G.selFleet, mine = f.owner === st.player;
        ctx.save(); ctx.translate(sx, sy);
        ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 5; ctx.shadowOffsetY = 2;
        ctx.fillStyle = '#0d2a44'; ctx.beginPath(); ctx.moveTo(-bw / 2 - 3, -bh / 2 - 2); ctx.lineTo(bw / 2 + 3, -bh / 2 - 2); ctx.lineTo(bw / 2 - 1, bh / 2 + 3); ctx.lineTo(-bw / 2 + 1, bh / 2 + 3); ctx.closePath(); ctx.fill();
        ctx.shadowColor = 'transparent';
        G.drawFlag(ctx, -bw / 2 + 1, -bh / 2, bw - 2, bh - 1, f.owner);
        const n = f.ships.length;
        ctx.font = 'bold ' + Math.max(8, Math.round(bh * 0.62)) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 3; ctx.strokeStyle = '#000'; ctx.strokeText(n, 0, 1); ctx.fillStyle = '#bfe6ff'; ctx.fillText(n, 0, 1);
        ctx.strokeStyle = isSel ? '#8fd0ff' : mine ? 'rgba(255,255,255,.75)' : 'rgba(140,190,230,.6)'; ctx.lineWidth = isSel ? 2.5 + Math.sin(t / 150) : 1.2;
        ctx.beginPath(); ctx.moveTo(-bw / 2 - 3, -bh / 2 - 2); ctx.lineTo(bw / 2 + 3, -bh / 2 - 2); ctx.lineTo(bw / 2 - 1, bh / 2 + 3); ctx.lineTo(-bw / 2 + 1, bh / 2 + 3); ctx.closePath(); ctx.stroke();
        if (f.cargo && f.cargo.length) { ctx.fillStyle = '#ffe48a'; ctx.fillRect(-bw / 2, bh / 2 + 4, bw, 3); }
        if (pos.moving) { ctx.fillStyle = '#8fd0ff'; ctx.beginPath(); ctx.moveTo(bw / 2 + 5, -4); ctx.lineTo(bw / 2 + 12, 0); ctx.lineTo(bw / 2 + 5, 4); ctx.fill(); }
        ctx.restore();
        fleetHits.push({ id: f.id, x: sx - bw / 2 - 4, y: sy - bh / 2 - 4, w: bw + 8, h: bh + 8 });
      });
    }
    if (G.activeNavalBattles) for (const b of G.activeNavalBattles()) {
      const q = G.nodePos(b.zone), sx = (q.x - v.x) * v.z, sy = (q.y - v.y) * v.z - 8, pr = 12 + 3 * Math.sin(t / 120);
      ctx.save(); ctx.translate(sx, sy);
      ctx.beginPath(); ctx.arc(0, 0, pr, 0, 7); ctx.fillStyle = 'rgba(30,80,170,.8)'; ctx.fill(); ctx.strokeStyle = '#d0e8ff'; ctx.lineWidth = 2; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-7, -7); ctx.lineTo(7, 7); ctx.moveTo(7, -7); ctx.lineTo(-7, 7); ctx.lineWidth = 3; ctx.strokeStyle = '#fff'; ctx.stroke();
      ctx.restore();
    }
    if (G.fleetMoveMode) {
      ctx.save(); ctx.font = 'bold 14px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(0,0,0,.7)';
      ctx.fillRect(W / 2 - 150, 8, 300, 28); ctx.fillStyle = '#8fd0ff'; ctx.fillText('Tap a sea zone or a port province', W / 2, 23); ctx.restore();
    }
  }
  function hitFleet(sx, sy) {
    for (let i = fleetHits.length - 1; i >= 0; i--) { const h = fleetHits[i]; if (sx >= h.x && sx <= h.x + h.w && sy >= h.y && sy <= h.y + h.h) return h.id; }
    return null;
  }

  function star(x, y, r, col) {
    ctx.save(); ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const rr = i % 2 ? r * 0.45 : r, a = -Math.PI / 2 + i * Math.PI / 5;
      ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    ctx.closePath(); ctx.fillStyle = col; ctx.strokeStyle = '#000'; ctx.lineWidth = 1.2; ctx.fill(); ctx.stroke(); ctx.restore();
  }

  /* ---------- input ---------- */
  function setupInput() {
    const ptrs = new Map();
    let dragStart = null, moved = false, pinch0 = null;
    const rect = () => canvas.getBoundingClientRect();
    canvas.addEventListener('pointerdown', e => {
      try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
      ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (ptrs.size === 1) { dragStart = { x: e.clientX, y: e.clientY, vx: G.view.x, vy: G.view.y }; moved = false; }
      if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch0 = { d: Math.hypot(a.x - b.x, a.y - b.y), z: G.view.z }; moved = true; }
    });
    canvas.addEventListener('pointermove', e => {
      const r = rect();
      if (!ptrs.has(e.pointerId)) { // mouse hover
        const id = G.provinceAt(e.clientX - r.left, e.clientY - r.top);
        if (id !== G.hover) { G.hover = id; dirty = true; }
        return;
      }
      ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (ptrs.size === 2 && pinch0) {
        const [a, b] = [...ptrs.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        const cx = (a.x + b.x) / 2 - r.left, cy = (a.y + b.y) / 2 - r.top;
        G.zoomAt(cx, cy, (pinch0.d ? d / pinch0.d * pinch0.z : pinch0.z) / G.view.z);
      } else if (ptrs.size === 1 && dragStart) {
        const dx = e.clientX - dragStart.x, dy = e.clientY - dragStart.y;
        if (!moved && Math.hypot(dx, dy) > 8) moved = true;
        if (moved) { G.view.x = dragStart.vx - dx / G.view.z; G.view.y = dragStart.vy - dy / G.view.z; clampView(); dirty = true; }
      }
    });
    function up(e) {
      const wasSingle = ptrs.size === 1;
      ptrs.delete(e.pointerId);
      if (ptrs.size < 2) pinch0 = null;
      if (wasSingle && !moved && dragStart) {
        const r = rect(), sx = e.clientX - r.left, sy = e.clientY - r.top;
        const id = G.provinceAt(sx, sy);
        if (G.fleetMoveMode && G.selFleet != null) { G.onFleetTarget && G.onFleetTarget(id); dirty = true; }
        else if (G.moveMode && G.selArmy != null) { G.onMoveTarget && G.onMoveTarget(id); dirty = true; }
        else {
          const fh = hitFleet(sx, sy), ah = fh == null ? hitArmy(sx, sy) : null;
          if (fh != null) { G.selFleet = fh; G.selArmy = null; G.selected = null; G.selZone = null; dirty = true; G.onFleetSelect && G.onFleetSelect(fh); }
          else if (ah != null) { G.selArmy = ah; G.selFleet = null; G.selected = null; G.selZone = null; dirty = true; G.onArmySelect && G.onArmySelect(ah); }
          else {
            G.selArmy = null; G.selFleet = null;
            if (id != null && G.provinces[id].sea && G.provinces[id].zone) {
              G.selected = null; G.selZone = G.provinces[id].zone; dirty = true; G.onZoneSelect && G.onZoneSelect(G.selZone);
            } else {
              G.selZone = null;
              G.selected = (id != null && !G.provinces[id].sea) ? id : null;
              dirty = true; G.onSelect && G.onSelect(G.selected);
            }
          }
        }
      }
      if (ptrs.size === 0) dragStart = null;
      else if (ptrs.size === 1) { const [p] = [...ptrs.values()]; dragStart = { x: p.x, y: p.y, vx: G.view.x, vy: G.view.y }; moved = true; }
    }
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', e => { ptrs.delete(e.pointerId); pinch0 = null; dragStart = null; });
    canvas.addEventListener('pointerleave', () => { if (G.hover != null) { G.hover = null; dirty = true; } });
    canvas.addEventListener('wheel', e => {
      e.preventDefault(); const r = rect();
      G.zoomAt(e.clientX - r.left, e.clientY - r.top, e.deltaY < 0 ? 1.15 : 1 / 1.15);
    }, { passive: false });
    canvas.addEventListener('contextmenu', e => e.preventDefault());
  }

  G.initMap = function (cv) {
    canvas = cv; ctx = cv.getContext('2d');
    const resize = () => {
      const r = cv.parentElement.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      W = r.width; H = r.height;
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      cv.style.width = W + 'px'; cv.style.height = H + 'px';
      if (G.view.z < minZoom()) G.view.z = minZoom();
      clampView(); dirty = true;
    };
    window.addEventListener('resize', resize);
    window.addEventListener('orientationchange', () => setTimeout(resize, 200));
    resize(); G.fitView(); setupInput();
    G.resizeMap = resize;
  };
  G.renderFrame = function (t) { if (dirty || G.selected != null || G.selArmy != null || G.selFleet != null || G.selZone != null || (G.state && !G.state.paused)) { dirty = false; draw(t); } };
})(window.EMP = window.EMP || {});
