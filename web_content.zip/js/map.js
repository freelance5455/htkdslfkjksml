class GameMap {
  constructor(scene) {
    this.scene = scene;
    this.size = 200;
    this.buildings = [];
    this.trees = [];
    this.lootSpots = [];
    this.colliders = [];

    this.createGround();
    this.createSky();
    this.createLights();
    this.generateCity();
    this.generateForest();
    this.generateMountains();
    this.generateRoads();
    this.placeLoot();
  }

  createGround() {
    const geo = new THREE.PlaneGeometry(this.size, this.size, 32, 32);
    // Slight height variation
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      pos.setZ(i, Math.sin(x * 0.05) * Math.cos(y * 0.05) * 0.8);
    }
    geo.computeVertexNormals();

    const mat = new THREE.MeshStandardMaterial({
      color: 0x3a5f3a,
      roughness: 0.9,
      metalness: 0.05
    });
    const ground = new THREE.Mesh(geo, mat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);
  }

  createSky() {
    this.scene.background = new THREE.Color(0x87ceeb);
    this.scene.fog = new THREE.Fog(0x87ceeb, 60, 160);
  }

  createLights() {
    const ambient = new THREE.AmbientLight(0xb0c4de, 0.55);
    this.scene.add(ambient);

    const sun = new THREE.DirectionalLight(0xfff5e0, 0.95);
    sun.position.set(40, 80, 30);
    sun.castShadow = true;
    sun.shadow.mapSize.width = 512;
    sun.shadow.mapSize.height = 512;
    sun.shadow.camera.near = 10;
    sun.shadow.camera.far = 200;
    sun.shadow.camera.left = -80;
    sun.shadow.camera.right = 80;
    sun.shadow.camera.top = 80;
    sun.shadow.camera.bottom = -80;
    this.scene.add(sun);
    this.sun = sun;
  }

  createBuilding(x, z, w, d, h, color) {
    const group = new THREE.Group();

    const bodyGeo = new THREE.BoxGeometry(w, h, d);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: color || 0x6b6b6b,
      roughness: 0.85
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = h / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    // Roof
    const roofGeo = new THREE.BoxGeometry(w + 0.3, 0.25, d + 0.3);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x3d2b1f, roughness: 0.9 });
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.y = h + 0.1;
    roof.castShadow = true;
    group.add(roof);

    // Windows
    const winMat = new THREE.MeshStandardMaterial({
      color: 0x88ccff,
      emissive: 0x112233,
      roughness: 0.3
    });
    const floors = Math.max(1, Math.floor(h / 2.8));
    for (let f = 0; f < floors; f++) {
      for (let side = 0; side < 2; side++) {
        const win = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.9), winMat);
        win.position.set(
          side === 0 ? w / 2 + 0.01 : -w / 2 - 0.01,
          1.5 + f * 2.6,
          (Math.random() - 0.5) * (d - 1)
        );
        win.rotation.y = side === 0 ? Math.PI / 2 : -Math.PI / 2;
        group.add(win);
      }
    }

    group.position.set(x, 0, z);
    this.scene.add(group);
    this.buildings.push(group);
    this.colliders.push({ x, z, w: w / 2 + 0.5, d: d / 2 + 0.5 });
    return group;
  }

  generateCity() {
    // Central abandoned city
    const positions = [
      { x: 0, z: 0, w: 8, d: 10, h: 12 },
      { x: 15, z: 5, w: 6, d: 7, h: 8 },
      { x: -12, z: 8, w: 7, d: 6, h: 10 },
      { x: 8, z: -14, w: 9, d: 6, h: 7 },
      { x: -18, z: -10, w: 5, d: 8, h: 9 },
      { x: 22, z: -8, w: 6, d: 5, h: 6 },
      { x: -5, z: 20, w: 10, d: 7, h: 11 },
      { x: 25, z: 18, w: 7, d: 9, h: 8 },
      { x: -25, z: 15, w: 6, d: 6, h: 7 },
      { x: 10, z: 28, w: 8, d: 5, h: 6 },
      { x: -30, z: -20, w: 9, d: 7, h: 10 },
      { x: 35, z: 5, w: 5, d: 10, h: 9 },
      // warehouses
      { x: -40, z: 30, w: 14, d: 8, h: 5 },
      { x: 40, z: -35, w: 12, d: 9, h: 5 },
      { x: 0, z: -40, w: 10, d: 12, h: 6 }
    ];

    const colors = [0x7a7a7a, 0x5c5c5c, 0x8b7355, 0x6b5b4b, 0x4a4a4a, 0x8a8a8a];
    positions.forEach((p, i) => {
      this.createBuilding(p.x, p.z, p.w, p.d, p.h, colors[i % colors.length]);
    });

    // Towers
    this.createBuilding(-50, 0, 4, 4, 18, 0x555555);
    this.createBuilding(50, 40, 3.5, 3.5, 15, 0x666666);
  }

  createTree(x, z) {
    const group = new THREE.Group();
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.2, 0.3, 2.2, 6),
      new THREE.MeshStandardMaterial({ color: 0x5d4037, roughness: 0.9 })
    );
    trunk.position.y = 1.1;
    trunk.castShadow = true;
    group.add(trunk);

    const leaves = new THREE.Mesh(
      new THREE.ConeGeometry(1.6, 3.5, 7),
      new THREE.MeshStandardMaterial({ color: 0x2e7d32, roughness: 0.85 })
    );
    leaves.position.y = 3.5;
    leaves.castShadow = true;
    group.add(leaves);

    group.position.set(x, 0, z);
    this.scene.add(group);
    this.trees.push(group);
  }

  generateForest() {
    // Forests around edges
    for (let i = 0; i < 40; i++) {
      let x, z;
      do {
        x = Utils.randomRange(-90, 90);
        z = Utils.randomRange(-90, 90);
      } while (Math.abs(x) < 35 && Math.abs(z) < 35);
      this.createTree(x, z);
    }
  }

  generateMountains() {
    // Simple mountain meshes at borders
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const dist = 95 + Math.random() * 15;
      const x = Math.cos(angle) * dist;
      const z = Math.sin(angle) * dist;
      const h = 12 + Math.random() * 18;
      const r = 8 + Math.random() * 10;

      const geo = new THREE.ConeGeometry(r, h, 6);
      const mat = new THREE.MeshStandardMaterial({
        color: 0x5a6a5a,
        roughness: 0.95,
        flatShading: true
      });
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, h / 2 - 2, z);
      m.castShadow = true;
      this.scene.add(m);
    }
  }

  generateRoads() {
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x333333,
      roughness: 0.95
    });

    // Main cross roads
    const road1 = new THREE.Mesh(new THREE.PlaneGeometry(8, 160), roadMat);
    road1.rotation.x = -Math.PI / 2;
    road1.position.y = 0.05;
    this.scene.add(road1);

    const road2 = new THREE.Mesh(new THREE.PlaneGeometry(160, 8), roadMat);
    road2.rotation.x = -Math.PI / 2;
    road2.position.y = 0.05;
    this.scene.add(road2);
  }

  placeLoot() {
    // Loot positions near buildings and random
    const spots = [
      new THREE.Vector3(2, 0.5, 2),
      new THREE.Vector3(14, 0.5, 6),
      new THREE.Vector3(-10, 0.5, 9),
      new THREE.Vector3(9, 0.5, -12),
      new THREE.Vector3(-16, 0.5, -8),
      new THREE.Vector3(20, 0.5, -6),
      new THREE.Vector3(-3, 0.5, 18),
      new THREE.Vector3(24, 0.5, 16),
      new THREE.Vector3(-38, 0.5, 28),
      new THREE.Vector3(38, 0.5, -32),
      new THREE.Vector3(0, 0.5, -38),
      new THREE.Vector3(-48, 0.5, 2),
      new THREE.Vector3(48, 0.5, 38)
    ];

    // Extra random
    for (let i = 0; i < 20; i++) {
      spots.push(new THREE.Vector3(
        Utils.randomRange(-70, 70),
        0.5,
        Utils.randomRange(-70, 70)
      ));
    }

    this.lootSpots = spots;

    // Visual markers (crates)
    spots.forEach((p, i) => {
      if (i % 2 === 0) {
        const crate = new THREE.Mesh(
          new THREE.BoxGeometry(0.8, 0.7, 0.8),
          new THREE.MeshStandardMaterial({ color: 0xc9a227, roughness: 0.7 })
        );
        crate.position.copy(p);
        crate.position.y = 0.35;
        crate.castShadow = true;
        this.scene.add(crate);
      }
    });
  }

  getLootNear(pos, radius = 2.5) {
    for (let i = 0; i < this.lootSpots.length; i++) {
      if (Utils.dist(pos, this.lootSpots[i]) < radius) {
        return i;
      }
    }
    return -1;
  }

  removeLoot(index) {
    if (index >= 0 && index < this.lootSpots.length) {
      this.lootSpots.splice(index, 1);
    }
  }
}
