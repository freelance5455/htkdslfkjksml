/**
 * learnyZ — Parametric drawing engine inspired by Hamid Naderi Yeganeh.
 *
 * Method 1 (exploratory): evaluate families of trig formulae over k = 1..N
 * Method 2 (constructive): compose known school shapes from parametric pieces
 *
 * Primitives:
 *  - line-segment clouds: endpoints (x1(k),y1(k)), (x2(k),y2(k))
 *  - circle unions: centre (A(k),B(k)), radius R(k)
 *  - parametric polylines: (x(t), y(t)) for t in [0,1]
 *
 * Reference (public formulae):
 *  Bird in flight (500 segments), endpoints for i=1..500:
 *   P1 = (1.5 * sin(2πi/500 + π/3)^7,  0.25 * cos(6πi/500)^2)
 *   P2 = (0.2 * sin(6πi/500 + π/5),   -2/3 * sin(2πi/500 - π/3)^2)
 */

const TWO_PI = Math.PI * 2;

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

/** Map normalised math coords [-1.2,1.2]² into canvas box */
function mapToCanvas(x, y, w, h, pad = 28) {
  const s = Math.min(w, h) / 2.6;
  const cx = w / 2, cy = h / 2 + 4;
  return [cx + x * s, cy - y * s];
}

/**
 * Draw Naderi-style segment cloud.
 * endpoints(i, N) -> {x1,y1,x2,y2} in math space
 */
export function drawSegmentCloud(ctx, w, h, N, endpoints, style = {}) {
  ctx.save();
  ctx.strokeStyle = style.stroke || "#1e293b";
  ctx.lineWidth = style.width || 1.1;
  ctx.lineCap = "round";
  for (let i = 1; i <= N; i++) {
    const e = endpoints(i, N);
    const [a, b] = mapToCanvas(e.x1, e.y1, w, h);
    const [c, d] = mapToCanvas(e.x2, e.y2, w, h);
    ctx.beginPath();
    ctx.moveTo(a, b);
    ctx.lineTo(c, d);
    ctx.stroke();
  }
  ctx.restore();
}

/**
 * Draw union of circles (filled silhouette).
 * circle(k, N) -> {x, y, r} in math space
 */
export function drawCircleUnion(ctx, w, h, N, circle, style = {}) {
  ctx.save();
  ctx.fillStyle = style.fill || "rgba(30,41,59,0.9)";
  for (let k = -N; k <= N; k++) {
    const c = circle(k, N);
    if (!c || c.r <= 0) continue;
    const [cx, cy] = mapToCanvas(c.x, c.y, w, h);
    const s = Math.min(w, h) / 2.6;
    ctx.beginPath();
    ctx.arc(cx, cy, c.r * s, 0, TWO_PI);
    ctx.fill();
  }
  ctx.restore();
}

/** Polyline from parametric (x(t),y(t)), t in [0,1] */
export function drawParametricPolyline(ctx, w, h, steps, xt, yt, style = {}) {
  ctx.save();
  ctx.strokeStyle = style.stroke || "#1e293b";
  ctx.lineWidth = style.width || 2;
  ctx.lineJoin = "round";
  ctx.beginPath();
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const [x, y] = mapToCanvas(xt(t), yt(t), w, h);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  if (style.close) ctx.closePath();
  if (style.fill) {
    ctx.fillStyle = style.fill;
    ctx.fill();
  }
  ctx.stroke();
  ctx.restore();
}

/** Filled region from parametric closed curve */
export function fillParametric(ctx, w, h, steps, xt, yt, fill, stroke) {
  drawParametricPolyline(ctx, w, h, steps, xt, yt, { fill, stroke: stroke || fill, width: 1.5, close: true });
}

// ---------- Published Naderi recipes (for study / labs) ----------

/** Exact public "Bird in Flight" 500-segment recipe */
export function birdInFlightEndpoints(i, N = 500) {
  const t = (TWO_PI * i) / N;
  return {
    x1: 1.5 * Math.pow(Math.sin(t + Math.PI / 3), 7),
    y1: 0.25 * Math.pow(Math.cos(3 * t), 2),
    x2: 0.2 * Math.sin(3 * t + Math.PI / 5),
    y2: (-2 / 3) * Math.pow(Math.sin(t - Math.PI / 3), 2)
  };
}

export function drawBirdInFlight(ctx, w, h) {
  drawSegmentCloud(ctx, w, h, 500, birdInFlightEndpoints, { stroke: "#0f172a", width: 1 });
}

// ---------- Constructive CAPS-oriented parametric outlines ----------

/** Smooth plant-cell outer wall: rounded rectangle via trig blend */
export function plantCellWall(t) {
  // superellipse-ish rectangle in [-1,1]
  const a = 1.05, b = 0.78, n = 5;
  const ang = t * TWO_PI;
  const c = Math.cos(ang), s = Math.sin(ang);
  const f = Math.pow(Math.abs(c), n) + Math.pow(Math.abs(s), n);
  const r = f === 0 ? 1 : Math.pow(f, -1 / n);
  return { x: a * r * c, y: b * r * s };
}

/** Large central vacuole — offset soft blob */
export function vacuoleCurve(t) {
  const ang = t * TWO_PI;
  const rx = 0.42 + 0.06 * Math.sin(3 * ang);
  const ry = 0.38 + 0.05 * Math.cos(2 * ang);
  return {
    x: -0.12 + rx * Math.cos(ang),
    y: 0.05 + ry * Math.sin(ang)
  };
}

/** Nucleus circle */
export function nucleusCurve(t, cx = 0.45, cy = -0.15, r = 0.18) {
  const ang = t * TWO_PI;
  return { x: cx + r * Math.cos(ang), y: cy + r * Math.sin(ang) };
}

/** Chloroplast oval at (cx,cy) */
export function chloroplastCurve(t, cx, cy, rot = 0) {
  const ang = t * TWO_PI;
  const rx = 0.12, ry = 0.06;
  const x = rx * Math.cos(ang), y = ry * Math.sin(ang);
  const cr = Math.cos(rot), sr = Math.sin(rot);
  return { x: cx + x * cr - y * sr, y: cy + x * sr + y * cr };
}

/** Heart silhouette (school schematic) via parametric */
export function heartCurve(t) {
  // Classic parametric heart, scaled
  const ang = t * TWO_PI;
  const x = 16 * Math.pow(Math.sin(ang), 3);
  const y =
    13 * Math.cos(ang) -
    5 * Math.cos(2 * ang) -
    2 * Math.cos(3 * ang) -
    Math.cos(4 * ang);
  return { x: x / 18, y: y / 18 + 0.1 };
}

/** Leaf outline */
export function leafCurve(t) {
  const ang = t * TWO_PI;
  // pointed oval with midrib asymmetry
  const r = 0.55 * (1 + 0.15 * Math.sin(ang)) * Math.abs(Math.cos(ang / 2));
  return {
    x: r * Math.cos(ang) * 0.7,
    y: r * Math.sin(ang)
  };
}

/** Simple fish silhouette (Naderi-adjacent demo) */
export function fishEndpoints(i, N = 400) {
  const t = (TWO_PI * i) / N;
  return {
    x1: 0.9 * Math.cos(t) + 0.15 * Math.cos(3 * t),
    y1: 0.35 * Math.sin(t) + 0.05 * Math.sin(5 * t),
    x2: 0.75 * Math.cos(t + 0.08) + 0.2 * Math.pow(Math.sin(t), 3),
    y2: 0.28 * Math.sin(t + 0.08)
  };
}

/**
 * High-level: draw a named parametric recipe onto ctx.
 */
export function drawParametricRecipe(ctx, w, h, name, opts = {}) {
  switch (name) {
    case "bird_in_flight":
      drawBirdInFlight(ctx, w, h);
      break;
    case "fish":
      drawSegmentCloud(ctx, w, h, 400, fishEndpoints, { stroke: "#0f172a", width: 1 });
      break;
    case "heart_outline": {
      const xt = (t) => heartCurve(t).x;
      const yt = (t) => heartCurve(t).y;
      fillParametric(ctx, w, h, 180, xt, yt, opts.fill || "#fecaca", opts.stroke || "#b91c1c");
      break;
    }
    case "leaf_outline": {
      const xt = (t) => leafCurve(t).x;
      const yt = (t) => leafCurve(t).y;
      fillParametric(ctx, w, h, 120, xt, yt, opts.fill || "#86efac", opts.stroke || "#166534");
      break;
    }
    case "plant_cell_wall": {
      const xt = (t) => plantCellWall(t).x;
      const yt = (t) => plantCellWall(t).y;
      fillParametric(ctx, w, h, 160, xt, yt, opts.fill || "#dcfce7", opts.stroke || "#166534");
      break;
    }
    default:
      break;
  }
}

/**
 * Compose a full CAPS plant-cell diagram from parametric parts + leaders.
 * This is constructive method 2: known school structure, parametric edges.
 */
export function composePlantCell(ctx, w, h) {
  // wall
  const wallX = (t) => plantCellWall(t).x;
  const wallY = (t) => plantCellWall(t).y;
  fillParametric(ctx, w, h, 160, wallX, wallY, "#dcfce7", "#166534");

  // membrane (slightly inset superellipse)
  const memX = (t) => plantCellWall(t).x * 0.92;
  const memY = (t) => plantCellWall(t).y * 0.92;
  drawParametricPolyline(ctx, w, h, 160, memX, memY, { stroke: "#2563eb", width: 1.6, close: true });

  // vacuole
  const vx = (t) => vacuoleCurve(t).x;
  const vy = (t) => vacuoleCurve(t).y;
  fillParametric(ctx, w, h, 100, vx, vy, "rgba(147,197,253,0.5)", "#3b82f6");

  // nucleus
  const nx = (t) => nucleusCurve(t).x;
  const ny = (t) => nucleusCurve(t).y;
  fillParametric(ctx, w, h, 80, nx, ny, "#a5b4fc", "#4338ca");
  // nucleolus
  const [ncx, ncy] = mapToCanvas(0.45, -0.15, w, h);
  ctx.fillStyle = "#6366f1";
  ctx.beginPath();
  ctx.arc(ncx, ncy, 5, 0, TWO_PI);
  ctx.fill();

  // chloroplasts
  const chl = [
    [-0.55, 0.35, 0.4],
    [-0.5, -0.4, -0.3],
    [0.55, 0.4, 0.6],
    [0.5, -0.35, -0.5]
  ];
  chl.forEach(([cx, cy, rot]) => {
    const xt = (t) => chloroplastCurve(t, cx, cy, rot).x;
    const yt = (t) => chloroplastCurve(t, cx, cy, rot).y;
    fillParametric(ctx, w, h, 60, xt, yt, "#4ade80", "#15803d");
  });

  // leaders (canvas space)
  const s = Math.min(w, h) / 2.6;
  const cx = w / 2, cy = h / 2 + 4;
  function L(mx, my, lx, ly, label, align) {
    const x1 = cx + mx * s, y1 = cy - my * s;
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(lx, ly);
    ctx.stroke();
    ctx.fillStyle = "#0f172a";
    ctx.font = "11px sans-serif";
    ctx.textAlign = align || "left";
    ctx.textBaseline = "middle";
    ctx.fillText(label, align === "right" ? lx - 3 : lx + 3, ly);
  }
  L(-1.0, 0.5, 8, 32, "cell wall", "left");
  L(-0.9, 0.2, 8, 52, "membrane", "left");
  L(-0.12, 0.05, w - 10, h * 0.52, "vacuole", "right");
  L(0.55, -0.15, w - 10, 40, "nucleus", "right");
  L(-0.55, 0.35, w - 10, 62, "chloroplast", "right");

  ctx.font = "bold 12px sans-serif";
  ctx.fillStyle = "#334155";
  ctx.textAlign = "center";
  ctx.fillText("Plant cell (parametric construction)", w / 2, 14);
}

export function composeHeart(ctx, w, h) {
  const xt = (t) => heartCurve(t).x;
  const yt = (t) => heartCurve(t).y;
  fillParametric(ctx, w, h, 200, xt, yt, "#fecaca", "#b91c1c");
  // chamber guides
  const s = Math.min(w, h) / 2.6;
  const cx = w / 2, cy = h / 2 + 4;
  ctx.strokeStyle = "#991b1b";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(cx, cy - 0.35 * s);
  ctx.lineTo(cx, cy + 0.45 * s);
  ctx.moveTo(cx - 0.35 * s, cy + 0.05 * s);
  ctx.lineTo(cx + 0.35 * s, cy + 0.05 * s);
  ctx.stroke();
  ctx.font = "10px sans-serif";
  ctx.fillStyle = "#7f1d1d";
  ctx.textAlign = "center";
  ctx.fillText("RA", cx - 0.2 * s, cy - 0.08 * s);
  ctx.fillText("LA", cx + 0.2 * s, cy - 0.08 * s);
  ctx.fillText("RV", cx - 0.2 * s, cy + 0.22 * s);
  ctx.fillText("LV", cx + 0.2 * s, cy + 0.22 * s);
  ctx.font = "bold 12px sans-serif";
  ctx.fillStyle = "#334155";
  ctx.fillText("Heart (parametric outline)", w / 2, 14);
}


export function composeAnimalCell(ctx, w, h) {
  const cx = 0, cy = 0;
  // membrane — soft ellipse via parametric
  const memX = (t) => 0.95 * Math.cos(t * TWO_PI);
  const memY = (t) => 0.7 * Math.sin(t * TWO_PI);
  fillParametric(ctx, w, h, 120, memX, memY, "#fef3c7", "#2563eb");
  // nucleus
  const nx = (t) => nucleusCurve(t, -0.15, -0.05, 0.22).x;
  const ny = (t) => nucleusCurve(t, -0.15, -0.05, 0.22).y;
  fillParametric(ctx, w, h, 80, nx, ny, "#a5b4fc", "#4338ca");
  const [ncx, ncy] = mapToCanvas(-0.15, -0.05, w, h);
  ctx.fillStyle = "#6366f1";
  ctx.beginPath(); ctx.arc(ncx, ncy, 6, 0, TWO_PI); ctx.fill();
  // mitochondria
  [[0.4, 0.25, 0.5], [-0.45, 0.35, -0.3], [0.35, -0.35, 0.8]].forEach(([mx, my, rot]) => {
    const xt = (t) => {
      const a = t * TWO_PI;
      const x = 0.14 * Math.cos(a), y = 0.07 * Math.sin(a);
      return mx + x * Math.cos(rot) - y * Math.sin(rot);
    };
    const yt = (t) => {
      const a = t * TWO_PI;
      const x = 0.14 * Math.cos(a), y = 0.07 * Math.sin(a);
      return my + x * Math.sin(rot) + y * Math.cos(rot);
    };
    fillParametric(ctx, w, h, 50, xt, yt, "#fca5a5", "#b91c1c");
  });
  const s = Math.min(w, h) / 2.6;
  const ox = w / 2, oy = h / 2 + 4;
  function L(mx, my, lx, ly, label, align) {
    ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(ox + mx * s, oy - my * s); ctx.lineTo(lx, ly); ctx.stroke();
    ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
    ctx.textAlign = align || "left"; ctx.textBaseline = "middle";
    ctx.fillText(label, align === "right" ? lx - 3 : lx + 3, ly);
  }
  L(0.95, 0, w - 10, h * 0.5, "cell membrane", "right");
  L(0.05, -0.05, w - 10, 40, "nucleus", "right");
  L(0.5, 0.25, w - 10, h - 36, "mitochondrion", "right");
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Animal cell (parametric)", w / 2, 14);
}

export function composeDigestive(ctx, w, h) {
  // path as parametric tube centreline sampled to thick stroke
  const pts = [];
  for (let i = 0; i <= 40; i++) {
    const t = i / 40;
    const y = 0.85 - t * 1.7;
    const x = 0.08 * Math.sin(t * Math.PI * 3);
    pts.push(mapToCanvas(x, y, w, h));
  }
  ctx.strokeStyle = "#e11d48"; ctx.lineWidth = 14; ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.beginPath();
  pts.forEach((p, i) => { if (i === 0) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]); });
  ctx.stroke();
  // stomach
  const [sx, sy] = mapToCanvas(0.12, 0.15, w, h);
  ctx.fillStyle = "#fca5a5"; ctx.strokeStyle = "#b91c1c"; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.ellipse(sx, sy, 28, 18, 0.35, 0, TWO_PI); ctx.fill(); ctx.stroke();
  // liver
  const [lx, ly] = mapToCanvas(-0.35, 0.3, w, h);
  ctx.fillStyle = "#f87171";
  ctx.beginPath(); ctx.ellipse(lx, ly, 16, 12, -0.4, 0, TWO_PI); ctx.fill();
  ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
  function lead(x1, y1, x2, y2, lab, align) {
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
    ctx.textAlign = align; ctx.textBaseline = "middle";
    ctx.fillText(lab, align === "right" ? x2 - 3 : x2 + 3, y2);
  }
  const [m0x, m0y] = mapToCanvas(0, 0.8, w, h);
  lead(m0x, m0y, w - 10, 36, "mouth / oesophagus", "right");
  lead(sx + 20, sy, w - 10, sy, "stomach", "right");
  lead(lx - 10, ly, 10, ly, "liver", "left");
  const [ix, iy] = mapToCanvas(0.1, -0.45, w, h);
  lead(ix + 10, iy, w - 10, iy, "small intestine", "right");
  const [bx, by] = mapToCanvas(0, -0.85, w, h);
  lead(bx + 10, by, w - 10, by, "large intestine", "right");
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Digestive system (schematic)", w / 2, 14);
}

export function composePlantStructure(ctx, w, h) {
  const ox = w * 0.42, ground = h * 0.68;
  ctx.strokeStyle = "#a16207"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(20, ground); ctx.lineTo(w - 20, ground); ctx.stroke();
  ctx.fillStyle = "#fef3c7"; ctx.fillRect(20, ground, w - 40, h - ground - 8);
  // roots parametric branches
  ctx.strokeStyle = "#92400e"; ctx.lineWidth = 2.5;
  [[0, 0.2], [-0.15, 0.22], [0.14, 0.2]].forEach(([dx, dy], i) => {
    ctx.beginPath();
    ctx.moveTo(ox, ground);
    ctx.quadraticCurveTo(ox + dx * 80, ground + 30, ox + dx * 120, ground + dy * 140);
    ctx.stroke();
  });
  // stem
  ctx.strokeStyle = "#166534"; ctx.lineWidth = 7;
  ctx.beginPath(); ctx.moveTo(ox, ground); ctx.lineTo(ox, h * 0.28); ctx.stroke();
  // leaves parametric
  [[-1, 0.42], [1, 0.38], [-1, 0.52]].forEach(([side, fy]) => {
    const xt = (t) => leafCurve(t).x * 0.35 + side * 0.35;
    const yt = (t) => leafCurve(t).y * 0.25 + (0.5 - fy);
    // map manually with offset
    fillParametric(ctx, w, h, 80,
      (t) => { const L = leafCurve(t); return L.x * 0.4 + side * 0.28; },
      (t) => { const L = leafCurve(t); return L.y * 0.22 + (0.55 - fy) * 2; },
      "#22c55e", "#15803d");
  });
  // flower
  const fy = h * 0.2;
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * TWO_PI;
    ctx.fillStyle = "#f472b6";
    ctx.beginPath(); ctx.ellipse(ox + Math.cos(a) * 14, fy + Math.sin(a) * 14, 8, 5, a, 0, TWO_PI); ctx.fill();
  }
  ctx.fillStyle = "#fbbf24";
  ctx.beginPath(); ctx.arc(ox, fy, 7, 0, TWO_PI); ctx.fill();
  ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
  function lead(x1, y1, x2, y2, lab, align) {
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
    ctx.textAlign = align; ctx.textBaseline = "middle";
    ctx.fillText(lab, align === "right" ? x2 - 3 : x2 + 3, y2);
  }
  lead(ox - 20, ground + 40, 12, ground + 40, "roots", "left");
  lead(ox + 6, h * 0.48, w - 12, h * 0.48, "stem", "right");
  lead(ox + 40, h * 0.38, w - 12, h * 0.32, "leaf", "right");
  lead(ox + 18, fy, w - 12, fy, "flower", "right");
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Plant structure", w / 2, 14);
}

export function composeSolar(ctx, w, h) {
  const cx = w * 0.4, cy = h * 0.52;
  const maxR = Math.min(w, h) * 0.36;
  const bodies = [
    { name: "Sun", r: 0, color: "#f59e0b", rp: 16 },
    { name: "Mercury", r: 0.22, color: "#9ca3af", rp: 3 },
    { name: "Venus", r: 0.34, color: "#d4a574", rp: 5 },
    { name: "Earth", r: 0.48, color: "#2563eb", rp: 5 },
    { name: "Mars", r: 0.6, color: "#dc2626", rp: 4 },
    { name: "Jupiter", r: 0.8, color: "#c4a35a", rp: 9 }
  ];
  ctx.strokeStyle = "#cbd5e1"; ctx.lineWidth = 1;
  bodies.forEach((b) => {
    if (b.r > 0) {
      ctx.beginPath(); ctx.arc(cx, cy, b.r * maxR, 0, TWO_PI); ctx.stroke();
    }
  });
  bodies.forEach((b, i) => {
    if (b.r === 0) {
      const g = ctx.createRadialGradient(cx - 3, cy - 3, 2, cx, cy, b.rp);
      g.addColorStop(0, "#fde68a"); g.addColorStop(1, b.color);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(cx, cy, b.rp, 0, TWO_PI); ctx.fill();
    } else {
      const ang = -0.5 + i * 0.5;
      const px = cx + Math.cos(ang) * b.r * maxR;
      const py = cy + Math.sin(ang) * b.r * maxR;
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(px, py, b.rp, 0, TWO_PI); ctx.fill();
    }
  });
  ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(cx + 16, cy); ctx.lineTo(w - 12, 36); ctx.stroke();
  ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif"; ctx.textAlign = "right";
  ctx.fillText("Sun", w - 14, 36);
  ctx.beginPath(); ctx.moveTo(cx + 0.48 * maxR, cy); ctx.lineTo(w - 12, 58); ctx.stroke();
  ctx.fillText("Earth", w - 14, 58);
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Solar system (not to scale)", w / 2, 14);
}

export function composeLever(ctx, w, h) {
  const y = h * 0.55;
  const fx = w * 0.4;
  ctx.strokeStyle = "#334155"; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(w - 40, y); ctx.stroke();
  ctx.fillStyle = "#64748b";
  ctx.beginPath(); ctx.moveTo(fx, y); ctx.lineTo(fx - 16, y + 40); ctx.lineTo(fx + 16, y + 40); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#fca5a5"; ctx.fillRect(50, y - 34, 30, 28);
  ctx.fillStyle = "#93c5fd"; ctx.fillRect(w - 80, y - 34, 30, 28);
  ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
  ctx.fillText("Load", 52, y - 42);
  ctx.fillText("Effort", w - 78, y - 42);
  ctx.fillText("fulcrum", fx - 18, y + 56);
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Lever", w / 2, 16);
}


export const DIAGRAM_CATALOG = [
  { id: "cell_plant", name: "Plant cell", group: "Life Sciences", draw: "composePlantCell" },
  { id: "cell_animal", name: "Animal cell", group: "Life Sciences", draw: "composeAnimalCell" },
  { id: "organ_heart", name: "Heart", group: "Life Sciences", draw: "composeHeart" },
  { id: "organ_digestive", name: "Digestive system", group: "Life Sciences", draw: "composeDigestive" },
  { id: "plant_structure", name: "Plant structure", group: "Natural Sciences", draw: "composePlantStructure" },
  { id: "solar_system", name: "Solar system", group: "Natural Sciences", draw: "composeSolar" },
  { id: "lever", name: "Lever", group: "Technology", draw: "composeLever" },
  { id: "leaf_outline", name: "Leaf outline", group: "Parametric", draw: "leaf" },
  { id: "bird_in_flight", name: "Bird in flight (Naderi)", group: "Parametric art", draw: "bird" },
  { id: "fish", name: "Fish (segment cloud)", group: "Parametric art", draw: "fish" },
  { id: "accounting_equation", name: "Accounting equation", group: "Accounting", draw: "render" },
  { id: "journal_table", name: "Journal table", group: "Accounting", draw: "render" },
  { id: "t_account", name: "T-account", group: "Accounting", draw: "render" },
  { id: "bank_recon", name: "Bank reconciliation", group: "Accounting", draw: "render" },
  { id: "food_web", name: "Food web", group: "Natural Sciences", draw: "render" }
];

export const PARAMETRIC_KINDS = DIAGRAM_CATALOG.map((d) => d.id);

/** Draw any catalog id onto canvas */
export function drawCatalogDiagram(ctx, w, h, id) {
  switch (id) {
    case "cell_plant": case "plant_cell_parametric": return composePlantCell(ctx, w, h);
    case "cell_animal": return composeAnimalCell(ctx, w, h);
    case "organ_heart": case "heart_parametric": case "heart_outline": return composeHeart(ctx, w, h);
    case "organ_digestive": return composeDigestive(ctx, w, h);
    case "plant_structure": return composePlantStructure(ctx, w, h);
    case "solar_system": return composeSolar(ctx, w, h);
    case "lever": return composeLever(ctx, w, h);
    case "bird_in_flight": case "naderi_bird": return drawBirdInFlight(ctx, w, h);
    case "fish": return drawSegmentCloud(ctx, w, h, 400, fishEndpoints, { stroke: "#0f172a", width: 1 });
    case "leaf_outline": return drawParametricRecipe(ctx, w, h, "leaf_outline");
    default: return null; // fall through to render.js drawDiagram
  }
}

