// Port of engine/question_engine.py — Senior Phase (Grade 7-9) procedural question templates.
// Difficulty: 1=Foundation 2=Standard 3=Advanced 4=Elite
function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; } // randint inclusive
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a || 1; }
function fmtNum(n) { return Number.isInteger(n) ? n : Math.round(n * 100) / 100; }

const NAMES = {
  number_sense: "Number Sense", whole_numbers: "Whole Numbers", integers: "Integers",
  exponents: "Exponents", patterns: "Numeric Patterns",
  algebraic_expressions: "Algebraic Expressions", algebraic_equations: "Algebraic Equations",
  geometry_lines: "Geometry of Straight Lines", pythagoras: "Theorem of Pythagoras",
  area_perimeter: "Area & Perimeter", financial_maths: "Financial Mathematics",
  transformations: "Transformation Geometry", data_handling: "Data Handling", probability: "Probability",
  surface_area_volume: "Surface Area & Volume"
};
export const TOPICS = Object.keys(NAMES);

function base(topic, q, a, d, hint, exp, diagram = null) {
  return {
    id: `${topic}_${ri(100000, 999999)}`, topic, topic_name: NAMES[topic],
    question: q, answer: String(a), difficulty: d, hint, explanation: exp, marks: d, diagram
  };
}

export class QuestionEngine {
  generate(topic, difficulty = 1) {
    topic = TOPICS.includes(topic) ? topic : choice(TOPICS);
    difficulty = Math.max(1, Math.min(4, Math.round(difficulty)));
    return this["_" + topic](difficulty);
  }

  // ---------------- NUMBER SENSE ----------------
  _number_sense(d) {
    const mode = d > 1
      ? choice(["add10", "numberline", "compensation", "friendly_mult", "basic_div", "double_half"])
      : choice(["add10", "numberline", "basic_div"]);

    if (mode === "add10") {
      const a = ri(1, 9), b = ri(10 - a, 9);
      return base("number_sense", `Use 'making 10' to add: ${a} + ${b}`, a + b, d,
        `Take ${10 - a} from ${b} to make ${a} up to 10, then add what's left of ${b}.`,
        `${a} + ${10 - a} = 10. ${b} − ${10 - a} = ${b - (10 - a)}. So 10 + ${b - (10 - a)} = ${a + b}.`);
    }
    if (mode === "numberline") {
      const start = ri(-10, 10), jump = ri(-8, 8) || 3;
      return base("number_sense", `On a number line, start at ${start} and jump ${jump} spaces (${jump > 0 ? "right" : "left"}). Where do you land?`, start + jump, d,
        `Move ${Math.abs(jump)} spaces ${jump > 0 ? "right (add)" : "left (subtract)"} from ${start}.`,
        `${start} ${jump >= 0 ? "+" : "−"} ${Math.abs(jump)} = ${start + jump}.`);
    }
    if (mode === "compensation") {
      const a = ri(20, 90), b = choice([9, 19, 29, 39, 49, 98, 99]);
      const ans = a + b, roundB = b + 1;
      return base("number_sense", `Use compensation to calculate: ${a} + ${b}`, ans, d,
        `Round ${b} up to ${roundB} (add ${roundB - b}), add, then subtract ${roundB - b} back.`,
        `${a} + ${roundB} = ${a + roundB}, then ${a + roundB} − ${roundB - b} = ${ans}.`);
    }
    if (mode === "friendly_mult") {
      const a = ri(4, 40);
      const [label, method, mult] = choice([["x5", "x10 ÷ 2", 5], ["x25", "x100 ÷ 4", 25], ["x50", "x100 ÷ 2", 50], ["x9", "x10 − original", 9]]);
      const ans = a * mult;
      return base("number_sense", `Use the ${label} trick: ${a} × ${mult}`, ans, d, `${label} = ${method}.`, `${a} × ${mult} = ${ans} using ${method}.`);
    }
    if (mode === "basic_div") {
      const b = ri(2, 12), q = ri(2, 20), a = b * q;
      return base("number_sense", `Calculate: ${a} ÷ ${b}`, q, d, `Think: ${b} × ? = ${a}. Use known multiplication facts.`, `${b} × ${q} = ${a}, so ${a} ÷ ${b} = ${q}.`);
    }
    // double_half
    const a = ri(4, 60), b = choice([4, 8, 16, 6, 12]);
    return base("number_sense", `Use doubling and halving: ${a} × ${b}`, a * b, d,
      "Halve one number and double the other until it's easy to multiply.",
      `E.g. halve ${b} and double ${a} repeatedly until simple, then multiply: ${a} × ${b} = ${a * b}.`);
  }

  // ---------------- WHOLE NUMBERS ----------------
  _whole_numbers(d) {
    if (d <= 2) {
      const a = ri(10, 40), b = ri(2, 12), op = choice(["+", "-", "*"]);
      const ans = op === "+" ? a + b : op === "-" ? a - b : a * b;
      const disp = op === "*" ? "×" : op;
      return base("whole_numbers", `Calculate: ${a} ${disp} ${b}`, ans, d, `Work left to right: ${a} ${disp} ${b}.`, `${a} ${disp} ${b} = ${ans}.`);
    }
    const [n1, n2] = choice([[36, 60], [24, 84], [18, 48], [60, 72]]);
    const pf = (n) => { const f = {}; let x = 2; while (x * x <= n) { while (n % x === 0) { f[x] = (f[x] || 0) + 1; n = Math.floor(n / x); } x++; } if (n > 1) f[n] = (f[n] || 0) + 1; return f; };
    const f1 = pf(n1), f2 = pf(n2);
    let hcf = 1;
    for (const p of Object.keys(f1)) if (f2[p]) hcf *= Math.pow(+p, Math.min(f1[p], f2[p]));
    return base("whole_numbers", `Find the HCF of ${n1} and ${n2}.`, hcf, d,
      `Break ${n1} and ${n2} into prime factors, then multiply the lowest common powers.`,
      `${n1} and ${n2} share prime factors giving HCF = ${hcf}.`);
  }

  // ---------------- INTEGERS ----------------
  _integers(d) {
    let a = ri(-15, 15) || 3, b = ri(-15, 15) || 4;
    let op = d < 3 ? choice(["+", "-", "*"]) : choice(["*", "/"]);
    if (op === "/") { b = choice([2, 3, 4, 5, 6]) * choice([-1, 1]); a = b * ri(-8, 8); }
    const ans = op === "+" ? a + b : op === "-" ? a - b : op === "*" ? a * b : Math.trunc(a / b);
    const dispOp = op === "*" ? "×" : op === "/" ? "÷" : op;
    return base("integers", `Calculate: ${a} ${dispOp} ${b}`, ans, d,
      `${a} and ${b}: same signs give a positive result, different signs give a negative result.`, `${a} ${op} ${b} = ${ans}.`);
  }

  // ---------------- EXPONENTS ----------------
  _exponents(d) {
    const a = ri(2, 5), x = ri(1, 3 + d), y = ri(1, 3 + d);
    const mode = d > 1 ? choice(["mul", "div", "pow"]) : "mul";
    if (mode === "mul") return base("exponents", `Simplify: ${a}^${x} × ${a}^${y}`, Math.pow(a, x + y), d,
      `Same base (${a}): add the exponents ${x} + ${y}.`, `${a}^${x} × ${a}^${y} = ${a}^${x + y} = ${Math.pow(a, x + y)}.`);
    if (mode === "div") { const hi = Math.max(x, y) + 2; return base("exponents", `Simplify: ${a}^${hi} ÷ ${a}^${x}`, Math.pow(a, hi - x), d,
      `Same base (${a}): subtract the exponents ${hi} − ${x}.`, `${a}^${hi} ÷ ${a}^${x} = ${a}^${hi - x} = ${Math.pow(a, hi - x)}.`); }
    return base("exponents", `Simplify: (${a}^${x})^${y}`, Math.pow(a, x * y), d,
      `Power of a power: multiply the exponents ${x} × ${y}.`, `(${a}^${x})^${y} = ${a}^${x * y} = ${Math.pow(a, x * y)}.`);
  }

  // ---------------- PATTERNS ----------------
  _patterns(d) {
    const diff = ri(2, 6), start = ri(1, 10);
    const terms = [0, 1, 2, 3, 4].map((i) => start + diff * i);
    const c = start - diff;
    if (d <= 2) {
      const seq = terms.slice(0, 4).join(", ") + ", ...";
      return base("patterns", `Find the next term: ${seq}`, terms[4], d,
        `The common difference is ${diff}. Add ${diff} to the last term (${terms[3]}).`,
        `Common difference = ${diff}. Next term = ${terms[3]} + ${diff} = ${terms[4]}.`);
    }
    const n = ri(8, 20), ans = diff * n + c;
    const seq = terms.slice(0, 4).join(", ") + ", ...";
    return base("patterns", `Sequence: ${seq}\nFind term number ${n}.`, ans, d,
      `General term: Tn = ${diff}n + (${c}). Substitute n = ${n}.`, `Tn = ${diff}n + (${c}). T${n} = ${diff}(${n}) + (${c}) = ${ans}.`);
  }

  // ---------------- ALGEBRAIC EXPRESSIONS ----------------
  _algebraic_expressions(d) {
    if (d <= 2) {
      const a1 = ri(1, 9), a2 = ri(1, 9), b1 = ri(1, 9), b2 = ri(1, 9);
      const expr = `${a1}x + ${b1}y - ${a2}x + ${b2}y`;
      const rx = a1 - a2, ry = b1 + b2;
      const ans = `${rx}x + ${ry}y`;
      return base("algebraic_expressions", `Simplify: ${expr}`, ans, d,
        `Collect x-terms: ${a1}x − ${a2}x. Collect y-terms: ${b1}y + ${b2}y.`, `(${a1}x - ${a2}x) + (${b1}y + ${b2}y) = ${ans}.`);
    }
    const m = ri(2, 6), c = ri(-8, 8), x = ri(-5, 5);
    const ans = d === 4 ? m * x * x + c : m * x + c;
    const expr = d === 4 ? `${m}x^2 + (${c})` : `${m}x + (${c})`;
    return base("algebraic_expressions", `If x = ${x}, evaluate ${expr}`, ans, d,
      `Substitute x = ${x} using brackets: ${expr.replaceAll("x", `(${x})`)}.`, `Substituting x=${x}: ${expr.replaceAll("x", `(${x})`)} = ${ans}.`);
  }

  // ---------------- ALGEBRAIC EQUATIONS ----------------
  _algebraic_equations(d) {
    const x = ri(-10, 12) || 3, a = ri(2, 9), b = ri(1, 20), c = a * x + b;
    return base("algebraic_equations", `Solve for x: ${a}x + ${b} = ${c}`, x, d,
      `Subtract ${b} from both sides to get ${a}x = ${c - b}, then divide by ${a}.`,
      `${a}x = ${c} - ${b} = ${c - b}, so x = ${c - b}/${a} = ${x}.`);
  }

  // ---------------- GEOMETRY OF STRAIGHT LINES ----------------
  _geometry_lines(d) {
    const mode = choice(["line", "point", "vert"]);
    if (mode === "line") {
      const known = ri(30, 150), ans = 180 - known;
      return base("geometry_lines", `Two angles on a straight line are x and ${known}°. Find x.`, ans, d,
        `Angles on a straight line add up to 180°. Subtract ${known}° from 180°.`, `x = 180° - ${known}° = ${ans}°.`,
        { type: "straight_line_angles", known });
    }
    if (mode === "point") {
      const a1 = ri(60, 150), a2 = ri(60, 150), ans = 360 - a1 - a2;
      return base("geometry_lines", `Three angles around a point are ${a1}°, ${a2}° and y. Find y.`, ans, d,
        `Angles around a point add up to 360°. Subtract ${a1}° and ${a2}° from 360°.`, `y = 360° - ${a1}° - ${a2}° = ${ans}°.`,
        { type: "angles_at_point", a: a1, b: a2 });
    }
    const known = ri(20, 160);
    return base("geometry_lines", `Two lines cross. One angle is ${known}°. Find its vertically opposite angle.`, known, d,
      "Vertically opposite angles are always equal — no calculation needed.", `Vertically opposite angle = ${known}°.`,
      { type: "vertical_angles", known });
  }

  // ---------------- PYTHAGORAS ----------------
  _pythagoras(d) {
    const [a, b, c] = choice([[3, 4, 5], [6, 8, 10], [5, 12, 13], [9, 12, 15], [8, 15, 17], [7, 24, 25]]);
    if (Math.random() < 0.5) {
      return base("pythagoras", `A right triangle has legs ${a} cm and ${b} cm. Find the hypotenuse.`, c, d,
        "c² = a² + b², then take the square root.", `c² = ${a}²+${b}² = ${a * a + b * b}, c = √${a * a + b * b} = ${c} cm.`,
        { type: "right_triangle", a, b, c, find: "c" });
    }
    return base("pythagoras", `A right triangle has hypotenuse ${c} cm and one leg ${a} cm. Find the other leg.`, b, d,
      "b² = c² − a², then take the square root.", `b² = ${c}²-${a}² = ${c * c - a * a}, b = √${c * c - a * a} = ${b} cm.`,
      { type: "right_triangle", a, c, find: "b" });
  }

  // ---------------- AREA & PERIMETER ----------------
  // CAPS Grade 8: rectangles, squares, triangles, circles; composite at higher difficulty.
  // Textbook-style: clear units, π≈22/7 when r is multiple of 7, perpendicular height stressed.
  _area_perimeter(d) {
    const modes = d <= 1
      ? ["rect_area", "rect_perim", "square_area", "square_perim"]
      : d === 2
        ? ["rect_area", "rect_perim", "triangle", "circle_area", "circle_circ", "square_area"]
        : ["triangle", "circle_area", "circle_circ", "composite", "parallelogram", "rect_area"];
    const mode = choice(modes);

    if (mode === "rect_area") {
      const l = ri(4, 20), w = ri(3, 15);
      return base("area_perimeter", `Find the area of a rectangle ${l} cm by ${w} cm.`, l * w, d,
        `Area = length × width = ${l} × ${w}.`, `${l} × ${w} = ${l * w} cm².`, { type: "rectangle", l, w });
    }
    if (mode === "rect_perim") {
      const l = ri(4, 20), w = ri(3, 15);
      return base("area_perimeter", `Find the perimeter of a rectangle ${l} cm by ${w} cm.`, 2 * (l + w), d,
        `Perimeter = 2 × (length + width) = 2 × (${l} + ${w}).`, `2(${l}+${w}) = ${2 * (l + w)} cm.`, { type: "rectangle", l, w });
    }
    if (mode === "square_area") {
      const s = ri(4, 18);
      return base("area_perimeter", `Find the area of a square with side ${s} cm.`, s * s, d,
        `Area of square = side² = ${s}².`, `${s}² = ${s * s} cm².`, { type: "square", s });
    }
    if (mode === "square_perim") {
      const s = ri(4, 18);
      return base("area_perimeter", `Find the perimeter of a square with side ${s} cm.`, 4 * s, d,
        `Perimeter of square = 4 × side = 4 × ${s}.`, `4 × ${s} = ${4 * s} cm.`, { type: "square", s });
    }
    if (mode === "triangle") {
      const b = ri(6, 20), h = ri(4, 14), area = fmtNum(b * h / 2);
      return base("area_perimeter", `Find the area of a triangle with base ${b} cm and perpendicular height ${h} cm.`, area, d,
        `Area = ½ × base × height. Height must be perpendicular to the base.`, `½ × ${b} × ${h} = ${area} cm².`, { type: "triangle_bh", b, h });
    }
    if (mode === "parallelogram") {
      const b = ri(6, 18), h = ri(4, 12);
      return base("area_perimeter", `Find the area of a parallelogram with base ${b} cm and perpendicular height ${h} cm.`, b * h, d,
        `Area of parallelogram = base × perpendicular height.`, `${b} × ${h} = ${b * h} cm².`, { type: "parallelogram", b, h });
    }
    if (mode === "circle_circ") {
      const r = choice([7, 14, 21, 10, 5]);
      const circ = [7, 14, 21].includes(r) ? Math.round(2 * (22 / 7) * r) : Math.round(2 * 3.142 * r * 10) / 10;
      return base("area_perimeter", `Find the circumference of a circle with radius ${r} cm (use π≈22/7 or 3.142).`, circ, d,
        `Circumference = 2πr. Prefer π≈22/7 when radius is a multiple of 7.`, `2πr ≈ ${circ} cm.`, { type: "circle", r });
    }
    if (mode === "composite") {
      const L = ri(12, 24), W = ri(8, 16), r = choice([2, 3, 4]);
      const rectA = L * W;
      const circA = Math.round(3.14 * r * r);
      const ans = rectA - circA;
      return base("area_perimeter",
        `A rectangular garden measures ${L} m by ${W} m. A circular pond of radius ${r} m is cut out of it. Find the remaining area of the garden (use π≈3.14).`,
        ans, d,
        `Remaining area = area of rectangle − area of circle.`,
        `Rectangle: ${L}×${W}=${rectA} m². Circle: πr²≈${circA} m². Remaining = ${rectA}−${circA}=${ans} m².`,
        { type: "composite_rect_circle", L, W, r });
    }
    const r = choice([7, 14, 21, 10, 20]);
    const area = [7, 14, 21].includes(r) ? Math.round((22 / 7) * r * r) : Math.round(3.142 * r * r * 10) / 10;
    return base("area_perimeter", `Find the area of a circle with radius ${r} cm (use π≈22/7 or 3.142).`, area, d,
      "Area = πr². Convert diameter to radius first if diameter is given.", `π × ${r}² ≈ ${area} cm².`, { type: "circle", r });
  }

  // ---------------- FINANCIAL MATHS ----------------
  _financial_maths(d) {
    if (choice([true, false])) {
      const p = choice([1000, 2000, 5000, 3000, 4000]), r = choice([5, 6, 8, 10, 12]), t = ri(1, 5);
      const interest = Math.round(p * (r / 100) * t);
      return base("financial_maths", `R${p} is invested at ${r}% simple interest per year for ${t} years. Find the interest earned.`, interest, d,
        `I = P × r × t = ${p} × ${r / 100} × ${t}.`, `I = ${p} × ${r / 100} × ${t} = R${interest}.`);
    }
    const cost = ri(200, 900), pct = choice([10, 15, 20, 25, 30]);
    const selling = cost + Math.floor(cost * pct / 100);
    return base("financial_maths", `An item costs R${cost} and is sold for R${selling}. Find the profit percentage.`, pct, d,
      `Profit = R${selling}-R${cost}. Profit % = (profit ÷ cost) × 100.`, `Profit = R${selling - cost}. % = (${selling - cost}/${cost})×100 = ${pct}%.`);
  }

  // ---------------- TRANSFORMATIONS ----------------
  _transformations(d) {
    const x = ri(-8, 8), y = ri(-8, 8), mode = choice(["translate", "reflect_x", "reflect_y"]);
    if (mode === "translate") {
      const a = ri(-6, 6), b = ri(-6, 6);
      return base("transformations", `Translate point (${x}, ${y}) by vector (${a}, ${b}). Give the new point.`, `(${x + a}, ${y + b})`, d,
        `Add ${a} to x and ${b} to y.`, `(${x}+${a}, ${y}+${b}) = (${x + a}, ${y + b}).`, { type: "translation", x, y, a, b });
    }
    if (mode === "reflect_x") {
      return base("transformations", `Reflect point (${x}, ${y}) over the x-axis.`, `(${x}, ${-y})`, d,
        "Reflecting over the x-axis flips the sign of the y-coordinate only.", `(${x}, ${y}) → (${x}, ${-y}).`, { type: "reflect_x", x, y });
    }
    return base("transformations", `Reflect point (${x}, ${y}) over the y-axis.`, `(${-x}, ${y})`, d,
      "Reflecting over the y-axis flips the sign of the x-coordinate only.", `(${x}, ${y}) → (${-x}, ${y}).`, { type: "reflect_y", x, y });
  }

  // ---------------- DATA HANDLING ----------------
  _data_handling(d) {
    const n = d < 3 ? 6 : 8;
    const vals = Array.from({ length: n }, () => ri(2, 40));
    const mode = choice(["mean", "median", "range"]);
    if (mode === "mean") {
      const ans = fmtNum(vals.reduce((s, v) => s + v, 0) / vals.length);
      return base("data_handling", `Find the mean of: ${vals.join(", ")}`, ans, d,
        `Add all ${vals.length} values, then divide by ${vals.length}.`, `Sum=${vals.reduce((s, v) => s + v, 0)}, n=${vals.length}, mean=${ans}.`);
    }
    if (mode === "median") {
      const sv = [...vals].sort((a, b) => a - b), nn = sv.length;
      const med = nn % 2 ? sv[(nn - 1) / 2] : (sv[nn / 2 - 1] + sv[nn / 2]) / 2;
      const ans = fmtNum(med);
      return base("data_handling", `Find the median of: ${vals.join(", ")}`, ans, d,
        "Order the data first, then find the middle value.", `Ordered: [${sv.join(", ")}]. Median = ${ans}.`);
    }
    const ans = Math.max(...vals) - Math.min(...vals);
    return base("data_handling", `Find the range of: ${vals.join(", ")}`, ans, d,
      `Range = maximum (${Math.max(...vals)}) − minimum (${Math.min(...vals)}).`, `${Math.max(...vals)} − ${Math.min(...vals)} = ${ans}.`);
  }

  // ---------------- PROBABILITY ----------------
  _probability(d) {
    if (choice([true, false])) {
      const target = choice(["even", "odd", "greater than 4", "less than 3", "a 6"]);
      const favMap = { even: 3, odd: 3, "greater than 4": 2, "less than 3": 2, "a 6": 1 };
      const fav = favMap[target], g = gcd(fav, 6), ans = `${fav / g}/${6 / g}`;
      return base("probability", `A fair die is rolled. Find P(${target}).`, ans, d,
        `${fav} of the 6 faces satisfy this. P = ${fav}/6.`, `${fav}/6 simplifies to ${ans}.`);
    }
    const red = ri(2, 8), blue = ri(2, 8), total = red + blue, g = gcd(red, total), ans = `${red / g}/${total / g}`;
    return base("probability", `A bag has ${red} red and ${blue} blue balls. Find P(red).`, ans, d,
      `P(red) = ${red} red ÷ ${total} total balls.`, `${red}/${total} simplifies to ${ans}.`);
  }

  // ---------------- SURFACE AREA & VOLUME (CAPS Term 4) ----------------
  _surface_area_volume(d) {
    const mode = d <= 2
      ? choice(["prism_vol", "prism_sa", "cube_vol"])
      : choice(["prism_vol", "prism_sa", "cyl_vol", "cyl_sa"]);
    if (mode === "prism_vol") {
      const l = ri(3, 12), b = ri(2, 10), h = ri(2, 10);
      return base("surface_area_volume", `Find the volume of a rectangular prism ${l} cm by ${b} cm by ${h} cm.`, l * b * h, d,
        `Volume = length × breadth × height = ${l} × ${b} × ${h}.`, `${l} × ${b} × ${h} = ${l * b * h} cm³.`,
        { type: "rect_prism", l, b, h });
    }
    if (mode === "prism_sa") {
      const l = ri(3, 10), b = ri(2, 8), h = ri(2, 8);
      const sa = 2 * (l * b + l * h + b * h);
      return base("surface_area_volume", `Find the surface area of a rectangular prism ${l} cm × ${b} cm × ${h} cm.`, sa, d,
        `SA = 2(lb + lh + bh) = 2(${l}×${b} + ${l}×${h} + ${b}×${h}).`, `2(${l*b}+${l*h}+${b*h}) = ${sa} cm².`,
        { type: "rect_prism", l, b, h });
    }
    if (mode === "cube_vol") {
      const s = ri(2, 12);
      return base("surface_area_volume", `Find the volume of a cube with side ${s} cm.`, s * s * s, d,
        `Volume of cube = side³ = ${s}³.`, `${s}³ = ${s*s*s} cm³.`, { type: "cube", s });
    }
    if (mode === "cyl_vol") {
      const r = choice([7, 14, 3, 5]), h = ri(5, 15);
      const vol = [7, 14].includes(r) ? Math.round((22 / 7) * r * r * h) : Math.round(3.14 * r * r * h);
      return base("surface_area_volume", `Find the volume of a cylinder with radius ${r} cm and height ${h} cm (use π≈22/7 or 3.14).`, vol, d,
        `V = πr²h.`, `π × ${r}² × ${h} ≈ ${vol} cm³.`, { type: "cylinder", r, h });
    }
    // cyl_sa
    const r = choice([7, 14, 3]), h = ri(4, 12);
    const sa = [7, 14].includes(r) ? Math.round(2 * (22 / 7) * r * (r + h)) : Math.round(2 * 3.14 * r * (r + h));
    return base("surface_area_volume", `Find the total surface area of a closed cylinder with radius ${r} cm and height ${h} cm (use π≈22/7 or 3.14).`, sa, d,
      `SA = 2πr² + 2πrh = 2πr(r + h).`, `2πr(r+h) ≈ ${sa} cm².`, { type: "cylinder", r, h });
  }
}
