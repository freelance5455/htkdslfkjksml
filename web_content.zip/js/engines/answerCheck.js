// Port of engine/answer_check.py — lenient, forgiving answer comparison.
// Fixes 'correct answer marked wrong' on things like '-5' vs '-5 ', 'x=5' vs '5',
// '3/4' vs '0.75', '12.0' vs '12', spacing, degree signs, units, etc.

function clean(text) {
  let t = String(text).trim().toLowerCase().replaceAll(" ", "");
  t = t.replace(/[−–—]/g, "-"); // normalise unicode minuses
  t = t.replace(/≤/g, "<=").replace(/≥/g, ">=");
  t = t.replace(/^[a-z]+=/, "");
  t = t.replace(/(cm2|cm²|cm3|cm³|cm|m2|m²|m|°|percent|%)$/, "");
  return t;
}

function toNumber(text) {
  const t = text.replaceAll("°", "").replaceAll("%", "");
  const fracMatch = t.match(/^(-?\d+)\/(-?\d+)$/);
  if (fracMatch) {
    const den = +fracMatch[2];
    if (den !== 0) return (+fracMatch[1]) / den;
  }
  if (/^-?\d+\.?\d*$/.test(t) || /^-?\.\d+$/.test(t)) {
    const n = parseFloat(t);
    if (!Number.isNaN(n)) return n;
  }
  return null;
}

export function answersMatch(userInput, expected, tolerance = 0.01) {
  const u = clean(userInput);
  const e = clean(expected);
  if (!u) return false;
  if (u === e) return true;

  const un = toNumber(u), en = toNumber(e);
  if (un !== null && en !== null && !Number.isNaN(un) && !Number.isNaN(en)) {
    return Math.abs(un - en) <= tolerance;
  }

  // Coordinate-pair style answers e.g. "(3,4)" vs "( 3 , 4 )"
  const uCoords = u.match(/-?\d+\.?\d*/g) || [];
  const eCoords = e.match(/-?\d+\.?\d*/g) || [];
  if (uCoords.length && eCoords.length && uCoords.length === eCoords.length && (e.includes("(") || e.includes(","))) {
    if (uCoords.every((c, i) => Math.abs(parseFloat(c) - parseFloat(eCoords[i])) <= tolerance)) return true;
  }

  // Exponent style answers e.g. accept "729" as correct if expected is "3^6"
  const expMatch = e.match(/^(-?\d+)\^(\d+)$/);
  if (expMatch) {
    const b = +expMatch[1], p = +expMatch[2];
    if (un !== null && Math.abs(un - Math.pow(b, p)) <= tolerance) return true;
  }

  return false;
}
