/**
 * Learnly Grade 10 — multi-subject engine
 * Mathematical Literacy · Business Studies · Tourism (CAPS-aligned)
 */
import { generateMlQuestion, generateMlPaperParts, isMlTopic } from "./mlRecipes.js";
import { getLesson } from "./learningCards.js";
function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function shuffle(a) { const x = a.slice(); for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; }

const NOTES = {
  /* ——— Mathematical Literacy ——— */
  ml_numbers: {
    about: "Numbers and calculations form the foundation of Mathematical Literacy. Learners work with number formats, order of operations, rounding, ratios, rates, proportions and percentages in real-life contexts.",
    key_facts: [
      "BODMAS / PEMDAS governs the order of operations.",
      "Rounding: to nearest whole, tenth, hundredth, or significant figures as required by context.",
      "Ratio compares quantities of the same kind (e.g. 3:5).",
      "Rate compares different units (e.g. km/h, R/kg).",
      "Proportion: if a/b = c/d then ad = bc.",
      "Percentage = (part / whole) × 100.",
      "Increase/decrease by x%: multiply by (1 ± x/100).",
      "Always show working and state units in answers."
    ],
    formulae: ["% = (part/whole)×100", "new = original × (1 ± r/100)", "rate = quantity ÷ time"],
    method: "1. Identify the operation and units. 2. Convert units if needed. 3. Apply BODMAS. 4. Round sensibly for the context. 5. Check reasonableness.",
    common_mistakes: ["Ignoring order of operations", "Mixing ratio with rate", "Forgetting to convert units", "Rounding too early"],
    worked_examples: [
      "A recipe needs flour:sugar in the ratio 5:2. For 350 g flour, sugar = 350 × 2/5 = 140 g.",
      "A shirt costs R280. After a 15% discount: 280 × 0.85 = R238."
    ]
  },
  ml_patterns: {
    about: "Patterns, relationships and representations include tables, graphs and equations that describe everyday relationships (linear, constant difference, simple growth).",
    key_facts: [
      "A constant first difference often indicates a linear relationship.",
      "Independent variable usually on the horizontal axis; dependent on the vertical.",
      "Gradient = change in y / change in x.",
      "Read graphs carefully: scales, units and intercepts.",
      "Verbal, numerical, graphical and symbolic forms should be convertible."
    ],
    formulae: ["gradient m = Δy/Δx", "y = mx + c (linear)"],
    method: "1. Complete or extend the table. 2. Plot points accurately. 3. Describe the trend in words. 4. Find the rule if required.",
    common_mistakes: ["Misreading scale", "Swapping axes", "Assuming every pattern is linear"],
    worked_examples: ["Taxi fare: fixed R15 + R8 per km → cost = 15 + 8d."]
  },
  ml_finance: {
    about: "Finance covers documents (payslips, invoices, bank statements), tariff systems, income and expenditure, budgets, interest (simple), VAT and banking.",
    key_facts: [
      "Gross income − deductions = net income (take-home pay).",
      "VAT in South Africa is 15% (standard rate).",
      "Price including VAT = price excluding VAT × 1.15.",
      "Price excluding VAT = price including VAT ÷ 1.15.",
      "Simple interest: I = P × i × n (i as decimal, n in years).",
      "Budgets balance planned income against planned expenses.",
      "Tariff systems may be flat, stepwise or prepaid."
    ],
    formulae: ["I = Pin", "A = P(1 + in)", "VAT amount = excl × 0.15", "incl = excl × 1.15"],
    method: "1. Extract figures from the document. 2. Identify what is asked (net, VAT, interest). 3. Apply the correct formula. 4. Show working with units (R).",
    common_mistakes: ["Using compound instead of simple interest", "Adding VAT twice", "Confusing gross and net"],
    worked_examples: [
      "Item R230 incl. VAT: excl = 230 ÷ 1.15 ≈ R200; VAT = R30.",
      "P = R5000, i = 8% p.a., n = 2 years → I = 5000×0.08×2 = R800."
    ]
  },
  ml_measurement: {
    about: "Measurement includes conversions of units, perimeter, area and volume of everyday shapes, time, temperature, mass and capacity in practical contexts.",
    key_facts: [
      "1 km = 1000 m; 1 m = 100 cm; 1 cm = 10 mm.",
      "1 L = 1000 mL; 1 kg = 1000 g.",
      "Perimeter is the total distance around a 2-D shape.",
      "Area of rectangle = l × w; triangle = ½bh; circle ≈ πr² (π≈3.14).",
      "Volume of rectangular prism = l × w × h.",
      "Always state units (m, m², m³, L)."
    ],
    formulae: ["P = 2(l+w)", "A = lw", "A = ½bh", "V = lwh", "C = 2πr"],
    method: "1. Sketch and label. 2. Convert all lengths to the same unit. 3. Apply the formula. 4. Round appropriately.",
    common_mistakes: ["Mixing units (cm with m)", "Using diameter instead of radius", "Forgetting units on the answer"],
    worked_examples: ["Room 4.5 m by 3.2 m → area = 14.4 m²."]
  },
  ml_maps: {
    about: "Maps, plans and other representations of the physical world include scale, direction, distance on maps, floor plans and assembly diagrams.",
    key_facts: [
      "Scale 1:50 000 means 1 unit on the map = 50 000 units in reality.",
      "Map distance × scale factor = real distance.",
      "Compass directions: N, S, E, W and intermediate points.",
      "Floor plans show room layout; symbols indicate doors, windows, fixtures.",
      "Always convert map cm to real km or m carefully."
    ],
    formulae: ["real distance = map distance × scale number", "map distance = real ÷ scale number"],
    method: "1. Measure map distance carefully. 2. Apply scale. 3. Convert units (cm → km). 4. State direction if asked.",
    common_mistakes: ["Forgetting scale is a ratio", "Not converting cm to km", "Misreading compass bearings"],
    worked_examples: ["Scale 1:20 000; map distance 3.5 cm → real = 3.5 × 20 000 = 70 000 cm = 0.7 km."]
  },
  ml_data: {
    about: "Data handling covers collecting, organising, summarising and representing data, and interpreting graphs and tables for decision-making.",
    key_facts: [
      "Mean = sum of values ÷ number of values.",
      "Median = middle value when ordered; mode = most frequent value.",
      "Range = maximum − minimum.",
      "Bar graphs, pie charts, line graphs and histograms each suit different data types.",
      "Always comment on trends, outliers and context when interpreting."
    ],
    formulae: ["mean = Σx / n", "range = max − min"],
    method: "1. Order the data if needed. 2. Calculate the required measure. 3. Draw or read the representation carefully. 4. Write a contextual conclusion.",
    common_mistakes: ["Forgetting to order data for median", "Misreading pie-chart percentages", "Ignoring outliers when discussing mean"],
    worked_examples: ["Scores 12, 15, 15, 18, 20 → mean = 16; median = 15; mode = 15; range = 8."]
  },
  ml_probability: {
    about: "Probability expresses the chance of an event occurring, using relative frequency and simple theoretical probability in everyday contexts.",
    key_facts: [
      "Probability lies between 0 (impossible) and 1 (certain).",
      "P(event) = number of favourable outcomes ÷ total possible outcomes (equally likely).",
      "Relative frequency ≈ probability for a large number of trials.",
      "P(not A) = 1 − P(A)."
    ],
    formulae: ["P(A) = n(A) / n(S)", "P(not A) = 1 − P(A)"],
    method: "1. List the sample space. 2. Count favourable outcomes. 3. Write as a fraction, decimal or percentage. 4. Interpret in context.",
    common_mistakes: ["Writing probability greater than 1", "Confusing relative frequency with theoretical probability"],
    worked_examples: ["Fair die: P(even) = 3/6 = 1/2."]
  },

  /* ——— Business Studies ——— */
  bs_micro: {
    about: "The micro environment is the internal business environment that management can control: vision, mission, goals, resources and the eight business functions.",
    key_facts: [
      "Vision: long-term aspirational picture of the future.",
      "Mission: purpose of the business and how it will achieve the vision.",
      "Goals are broad; objectives are specific and measurable.",
      "Eight functions: general management, purchasing, production, marketing, public relations, human resources, administration, finance.",
      "Resources include human, physical, financial and information resources.",
      "Management can largely control the micro environment."
    ],
    formulae: [],
    method: "Define each component clearly. Link functions to examples. Distinguish vision from mission and goals from objectives.",
    common_mistakes: ["Confusing vision with mission", "Listing external factors as micro", "Omitting some of the eight functions"],
    worked_examples: ["A bakery’s mission may be ‘to provide fresh, affordable bread to the local community’."]
  },
  bs_market: {
    about: "The market environment consists of external stakeholders that the business can influence but not fully control: consumers, suppliers, competitors and intermediaries.",
    key_facts: [
      "Consumers demand products that satisfy needs and wants.",
      "Suppliers provide inputs; poor supplier relations affect quality and cost.",
      "Competitors offer similar products; businesses must monitor them.",
      "Intermediaries (wholesalers, retailers, agents) help distribute products.",
      "The market environment lies between the micro and macro environments."
    ],
    formulae: [],
    method: "Identify each component and explain how it affects the business. Give South African examples where possible.",
    common_mistakes: ["Treating government as market rather than macro", "Ignoring intermediaries"],
    worked_examples: ["A clothing retailer competes with online stores and mall outlets for the same customers."]
  },
  bs_macro: {
    about: "The macro environment includes political, economic, social, technological, environmental and legal (PESTEL) factors that the business cannot control but must adapt to.",
    key_facts: [
      "Political: government stability, policy, elections.",
      "Economic: inflation, interest rates, exchange rates, unemployment.",
      "Social: demographics, culture, lifestyle, education levels.",
      "Technological: innovation, automation, internet.",
      "Environmental / physical: climate, natural resources, pollution laws.",
      "Legal: labour law, consumer protection, company law.",
      "Businesses scan the macro environment and adapt strategies."
    ],
    formulae: [],
    method: "Use the PESTEL framework. For each factor give an example and state a possible impact on a business.",
    common_mistakes: ["Listing micro factors under macro", "Not linking the factor to a business impact"],
    worked_examples: ["Rising fuel prices (economic) increase delivery costs for a courier company."]
  },
  bs_sectors: {
    about: "The economy is divided into primary, secondary and tertiary sectors. Businesses operate within one or more sectors and form value chains.",
    key_facts: [
      "Primary: extraction of raw materials (mining, farming, fishing, forestry).",
      "Secondary: manufacturing and processing (factories, construction).",
      "Tertiary: services (retail, banking, tourism, transport, education).",
      "A value chain links the three sectors from raw material to final consumer.",
      "South Africa’s economy has significant primary (mining) and tertiary (services) activity."
    ],
    formulae: [],
    method: "Classify businesses correctly. Explain how sectors depend on one another with a simple chain example.",
    common_mistakes: ["Calling retail primary", "Forgetting that tourism is tertiary"],
    worked_examples: ["Maize farm (primary) → mill (secondary) → bakery and supermarket (tertiary)."]
  },
  bs_socio: {
    about: "Contemporary socioeconomic issues such as poverty, unemployment, HIV/AIDS, crime, inequality and strikes affect businesses and communities. Social responsibility is the response.",
    key_facts: [
      "Poverty and unemployment reduce consumer spending power.",
      "HIV/AIDS affects the workforce and productivity.",
      "Crime increases security costs and risk.",
      "Inequality and strikes can disrupt operations.",
      "Corporate Social Responsibility (CSR) is voluntary actions beyond legal requirements for the benefit of society.",
      "CSI (Corporate Social Investment) is the practical spending arm of CSR."
    ],
    formulae: [],
    method: "Name the issue, explain its impact on business, then suggest a responsible response.",
    common_mistakes: ["Confusing CSR with legal compliance only", "Listing issues without impact"],
    worked_examples: ["A company sponsors a local clinic (CSI) to support employees and the community affected by HIV/AIDS."]
  },
  bs_entrepreneurship: {
    about: "Entrepreneurship is the process of identifying opportunities, taking calculated risks and organising resources to start and grow a business.",
    key_facts: [
      "Key qualities: creativity, risk-taking, perseverance, initiative, passion, leadership.",
      "Entrepreneurs create jobs and contribute to economic growth.",
      "Opportunity identification comes from needs, trends, problems and gaps in the market.",
      "A good entrepreneur combines idea, skills, resources and timing."
    ],
    formulae: [],
    method: "List qualities with brief explanations. Link a quality to a practical example of business success or failure.",
    common_mistakes: ["Saying entrepreneurs take no risk", "Confusing employee qualities with entrepreneurial ones"],
    worked_examples: ["Perseverance: continuing after early product failures until product-market fit is found."]
  },
  bs_ownership: {
    about: "Forms of ownership determine legal structure, liability, continuity and ability to raise capital: sole trader, partnership, close corporation (historical), private and public company, and cooperatives.",
    key_facts: [
      "Sole proprietor: one owner, unlimited liability, simple to start.",
      "Partnership: 2–20 partners, shared liability, shared profits.",
      "Private company (Pty Ltd): limited liability, shares not freely transferable.",
      "Public company (Ltd): limited liability, shares traded on a stock exchange.",
      "Continuity: companies continue if ownership changes; sole traders and partnerships may not.",
      "Limited liability protects personal assets of shareholders."
    ],
    formulae: [],
    method: "Compare forms under headings: number of owners, liability, capital, continuity, legal personality.",
    common_mistakes: ["Saying sole traders have limited liability", "Confusing Pty Ltd with Ltd"],
    worked_examples: ["A small family café often starts as a sole trader; a growing manufacturer may register as a Pty Ltd."]
  },
  bs_opportunity: {
    about: "A business opportunity is a favourable set of circumstances that creates a need for a product or service. A business plan documents how the opportunity will be exploited.",
    key_facts: [
      "Sources of opportunity: problems, trends, gaps, hobbies, research.",
      "A feasibility study checks market, technical and financial viability.",
      "A business plan typically includes: cover page, executive summary, description, market analysis, marketing plan, operations, management, financial plan, appendices.",
      "Location factors: target market, cost, competition, infrastructure, legislation."
    ],
    formulae: [],
    method: "Describe the opportunity clearly. Outline the main sections of a simple business plan and justify a location choice.",
    common_mistakes: ["Writing a plan without market research", "Ignoring start-up costs"],
    worked_examples: ["Opportunity: rising demand for healthy school lunch boxes → business plan for a subscription lunch service."]
  },
  bs_creative: {
    about: "Creative thinking generates new ideas; problem-solving selects and implements solutions. Both are essential business roles skills.",
    key_facts: [
      "Techniques: brainstorming, mind-mapping, force-field analysis, the Delphi technique, nominal group technique.",
      "Steps in problem-solving: identify, analyse, generate options, evaluate, implement, review.",
      "Creative thinking should be encouraged without immediate criticism.",
      "Routine and non-routine problems require different approaches."
    ],
    formulae: [],
    method: "Name a technique, explain the steps, and apply it to a short case study.",
    common_mistakes: ["Skipping the evaluation step", "Confusing brainstorming with final decision-making"],
    worked_examples: ["Brainstorm 20 ideas for reducing packaging waste, then evaluate the top three."]
  },
  bs_self: {
    about: "Self-management includes time management, stress management, professionalism and ethics. Team performance depends on roles, communication and conflict handling.",
    key_facts: [
      "Professionalism: competence, integrity, respect, accountability.",
      "Ethics: moral principles that guide behaviour; codes of conduct formalise them.",
      "Teams need clear goals, complementary skills and open communication.",
      "Conflict can be constructive if managed; destructive if ignored.",
      "Personal goals should be SMART (Specific, Measurable, Achievable, Relevant, Time-bound)."
    ],
    formulae: [],
    method: "Define professionalism and ethics with workplace examples. Describe how a team can improve performance.",
    common_mistakes: ["Treating ethics as optional", "Ignoring the role of communication in teams"],
    worked_examples: ["A professional employee meets deadlines, treats colleagues with respect and reports errors honestly."]
  },

  /* ——— Tourism ——— */
  tour_intro: {
    about: "Tourism is the activities of persons travelling to and staying in places outside their usual environment for not more than one consecutive year for leisure, business and other purposes.",
    key_facts: [
      "Inbound tourism: visitors entering a country from abroad.",
      "Outbound tourism: residents travelling out of their own country.",
      "Domestic tourism: travel within one’s own country.",
      "Regional tourism: travel within a group of neighbouring countries (e.g. SADC).",
      "A tourist is a visitor who stays at least one night; a same-day visitor is an excursionist.",
      "People travel for leisure, business, VFR, health, education, religion, sport and special interest."
    ],
    formulae: [],
    method: "Define key terms precisely. Classify a travel scenario as domestic / regional / international and inbound / outbound.",
    common_mistakes: ["Calling every traveller a tourist", "Confusing inbound with outbound"],
    worked_examples: ["A Cape Town family visiting Kruger National Park is domestic tourism."]
  },
  tour_types: {
    about: "Tourists are classified by purpose of travel and profile. Understanding types helps the industry design products and services.",
    key_facts: [
      "Leisure, adventure, business, VFR, health, eco, cultural, religious, sport, education, special-interest, incentive, backpacker / youth, gap-year.",
      "Tourist profile includes age, income, origin, interests and length of stay.",
      "Needs, preferences and expectations differ by type (e.g. business travellers value speed and Wi-Fi; eco-tourists value low impact)."
    ],
    formulae: [],
    method: "Match a description to a tourist type. Explain how a destination can meet the needs of that type.",
    common_mistakes: ["Using only ‘holiday’ as a type", "Ignoring special-interest tourism"],
    worked_examples: ["A group on a bird-watching tour of iSimangaliso is special-interest / eco tourism."]
  },
  tour_sectors: {
    about: "The tourism industry comprises interrelated sectors: transport, accommodation, food and beverage, attractions, and travel organising and support services.",
    key_facts: [
      "Transport: air, road, rail, sea.",
      "Accommodation: hotels, guesthouses, B&Bs, lodges, camping, backpacker hostels.",
      "Food and beverage: restaurants, fast food, catering.",
      "Attractions: natural and man-made sites that draw visitors.",
      "Travel organisers: travel agencies, tour operators, online platforms.",
      "Support services: information centres, guides, insurance, currency exchange."
    ],
    formulae: [],
    method: "List the sectors and give a South African example for each. Explain how sectors depend on one another.",
    common_mistakes: ["Omitting support services", "Treating attractions as the whole industry"],
    worked_examples: ["A visitor flies (transport), stays in a lodge (accommodation), eats at a restaurant (F&B) and visits a game reserve (attraction)."]
  },
  tour_transport: {
    about: "Transport enables tourists to reach and move within destinations. South Africa has air, road, rail and limited sea options for tourism.",
    key_facts: [
      "Airports and airlines handle domestic and international arrivals.",
      "Road: private cars, coaches, car rental, taxis, ride-hailing.",
      "Rail: long-distance passenger services and luxury tourism trains.",
      "Sea: cruise liners and ferries in selected ports.",
      "Technology at airports (check-in kiosks, biometric gates) speeds processing."
    ],
    formulae: [],
    method: "Compare modes on speed, cost, comfort and environmental impact. Match a tourist type to a suitable mode.",
    common_mistakes: ["Assuming all tourists fly", "Ignoring safety and accessibility"],
    worked_examples: ["A backpacker may prefer long-distance coaches; a business traveller often prefers scheduled flights."]
  },
  tour_accommodation: {
    about: "Accommodation establishments provide overnight stays and related services. South Africa uses a star grading system. Food and beverage establishments complement the stay.",
    key_facts: [
      "Types: hotel, guesthouse, B&B, lodge, self-catering, backpacker, camping / caravan.",
      "Grading (1–5 stars) indicates facilities and service level.",
      "Room terms: single, double, twin, family, suite, en suite, per person sharing.",
      "Meal plans: room only, B&B, half board, full board, fully inclusive.",
      "F&B: à la carte, buffet, continental / English breakfast, room service."
    ],
    formulae: [],
    method: "Match establishment type and meal plan to a tourist profile. Explain what a star grading communicates to the guest.",
    common_mistakes: ["Confusing twin with double", "Assuming higher stars always mean better location"],
    worked_examples: ["A family of four may book a family room on a B&B basis at a 3-star guesthouse."]
  },
  tour_maps: {
    about: "Map work and tour planning use maps, distance, direction, time zones and itineraries to design practical tours.",
    key_facts: [
      "Map types: road maps, topographic, political, tourist maps.",
      "Scale, distance indicators and map symbols are essential.",
      "Itineraries list day-by-day activities, transport and accommodation.",
      "Time zones affect international arrival and departure planning.",
      "A good tour plan balances attractions, travel time and rest."
    ],
    formulae: ["travel time ≈ distance ÷ average speed"],
    method: "Read the map legend. Calculate approximate distances. Draft a simple one- or two-day itinerary with realistic times.",
    common_mistakes: ["Ignoring travel time between attractions", "Misreading scale"],
    worked_examples: ["From Cape Town CBD to Table Mountain cableway is a short transfer; allow time for queues."]
  },
  tour_attractions: {
    about: "Tourist attractions are natural or man-made features that draw visitors. South Africa has World Heritage Sites, national parks, cultural sites and built attractions.",
    key_facts: [
      "Natural: mountains, beaches, wildlife, waterfalls, forests.",
      "Man-made / cultural: museums, heritage sites, monuments, theme parks, festivals.",
      "World Heritage Sites in South Africa include iSimangaliso, Robben Island, Cradle of Humankind, Cape Floral Region, Vredefort Dome, Mapungubwe, Maloti-Drakensberg, ‡Khomani cultural landscape, Barberton Makhonjwa.",
      "Attractions should be accessible, safe and well interpreted for visitors."
    ],
    formulae: [],
    method: "Classify attractions as natural or cultural. Name key South African examples and state why they attract tourists.",
    common_mistakes: ["Listing only Cape Town attractions", "Confusing World Heritage with national parks only"],
    worked_examples: ["Kruger National Park is a major natural wildlife attraction supporting safari tourism."]
  },
  tour_sustainable: {
    about: "Sustainable and responsible tourism meets the needs of present tourists and host regions while protecting opportunities for the future — economically, socially and environmentally.",
    key_facts: [
      "Three pillars: environmental, social/cultural, economic sustainability.",
      "Responsible tourism: minimising negative impacts and maximising benefits for local communities.",
      "Practices: reduce waste, conserve water and energy, respect culture, buy local, stay on paths.",
      "Green tourism and eco-tourism emphasise low-impact nature experiences.",
      "Certification and codes of conduct guide operators and tourists."
    ],
    formulae: [],
    method: "Explain each pillar with an example. Suggest practical actions a tourist and a hotel can take.",
    common_mistakes: ["Thinking sustainability is only about the environment", "Ignoring community benefit"],
    worked_examples: ["A lodge that employs local guides and uses solar power supports all three pillars."]
  },
  tour_domestic: {
    about: "Domestic, regional and international tourism differ by origin and destination of the tourist. Statistics help governments and businesses plan.",
    key_facts: [
      "Domestic: within South Africa — important for local jobs and seasonality management.",
      "Regional: within SADC or neighbouring countries.",
      "International: from or to countries outside the region.",
      "Statistics include arrivals, length of stay, spend and purpose of visit.",
      "Foreign exchange earnings from inbound tourism support the economy."
    ],
    formulae: [],
    method: "Classify a travel scenario. Explain why domestic tourism is promoted (e.g. Sho’t Left campaigns).",
    common_mistakes: ["Calling all non-local travel international", "Ignoring the value of domestic spend"],
    worked_examples: ["A Johannesburg resident holidaying in Durban contributes to domestic tourism statistics."]
  },
  tour_service: {
    about: "Customer care and service excellence create memorable experiences, encourage repeat visits and positive word-of-mouth.",
    key_facts: [
      "Service excellence: consistently exceeding guest expectations.",
      "Communication: clear, polite, culturally sensitive; listening is essential.",
      "Complaints should be handled promptly, fairly and with empathy.",
      "Body language, appearance and product knowledge influence perception of service.",
      "Value of service excellence: loyalty, reviews, competitive advantage."
    ],
    formulae: [],
    method: "Describe a service failure and a recovery. List actions that demonstrate excellence in a hotel or attraction setting.",
    common_mistakes: ["Treating complaints as nuisances", "Ignoring non-verbal communication"],
    worked_examples: ["A front-desk agent who resolves a booking error quickly and offers a sincere apology demonstrates service recovery."]
  }
};

const BANK = {
  ml_numbers: [
    { q: "Calculate 15% of R2 400.", a: "R360", exp: "2 400 × 0.15 = 360." },
    { q: "Simplify the ratio 24:36.", a: "2:3", exp: "Divide both by 12." },
    { q: "A car travels 210 km in 3 hours. Calculate the average speed in km/h.", a: "70 km/h", exp: "210 ÷ 3 = 70." },
    { q: "Convert 2,5 km to metres.", a: "2 500 m", exp: "2,5 × 1 000 = 2 500." },
    { q: "Round 47,638 to two decimal places.", a: "47,64", exp: "Third decimal is 8 ≥ 5, so round up." },
    { q: "A recipe uses flour:sugar in the ratio 5:2. How much sugar for 450 g flour?", a: "180 g", exp: "450 × 2/5 = 180." },
    { q: "Increase R800 by 12,5%.", a: "R900", exp: "800 × 1,125 = 900." },
    { q: "What is 3/8 as a percentage?", a: "37,5%", exp: "3/8 = 0,375 = 37,5%." },
    { q: "A worker earns R95/hour and works 8 hours. Calculate the day's pay.", a: "R760", exp: "95 × 8 = 760." },
    { q: "Express 0,04 as a percentage.", a: "4%", exp: "0,04 × 100 = 4." }
  ],
  ml_patterns: [
    { q: "A taxi charges R25 fixed plus R7 per km. Write a formula for cost C in terms of distance d.", a: "C = 25 + 7d", exp: "Fixed fee + rate × distance." },
    { q: "The table shows: x: 1,2,3 and y: 5,9,13. What is the constant difference in y?", a: "4", exp: "9−5=4; 13−9=4." },
    { q: "If C = 50 + 12n, calculate C when n = 8.", a: "146", exp: "50 + 12×8 = 146." },
    { q: "A pattern of tiles: 3, 7, 11, 15. What is the next term?", a: "19", exp: "Add 4 each time." },
    { q: "The nth term of a sequence is 2n + 5. Find the 10th term.", a: "25", exp: "2(10)+5 = 25." },
    { q: "A phone plan costs R199 + R0,85 per minute. Cost for 40 minutes?", a: "R233", exp: "199 + 0,85×40 = 233." },
    { q: "Graphically, a constant rate of change appears as what kind of graph?", a: "Straight line / linear", exp: "Constant difference → linear relationship." },
    { q: "Complete: if income I = 15h and h = hours, income for 6,5 hours is?", a: "R97,50", exp: "15 × 6,5 = 97,5." }
  ],
  ml_finance: [
    { q: "An item costs R1 200 excluding VAT. Calculate the price including 15% VAT.", a: "R1 380", exp: "1 200 × 1,15 = 1 380." },
    { q: "A product costs R920 including 15% VAT. Calculate the price before VAT.", a: "R800", exp: "920 ÷ 1,15 = 800." },
    { q: "R5 000 invested at 8% simple interest per year for 3 years. Interest earned?", a: "R1 200", exp: "I = 5000×0,08×3 = 1 200." },
    { q: "Cost price R450, selling price R585. Calculate profit percentage on cost.", a: "30%", exp: "(135/450)×100 = 30%." },
    { q: "Monthly income R12 000. Rent is 30% of income. Calculate rent.", a: "R3 600", exp: "12 000 × 0,30 = 3 600." },
    { q: "Gross salary R18 500; deductions R3 200. Calculate net pay.", a: "R15 300", exp: "18 500 − 3 200 = 15 300." },
    { q: "A loan of R8 000 is repaid at R750 per month for 12 months. Total interest paid?", a: "R1 000", exp: "Total repaid 9 000 − 8 000 principal = 1 000." },
    { q: "Discount of 20% on R350. Calculate sale price.", a: "R280", exp: "350 × 0,80 = 280." },
    { q: "VAT amount on an item priced R690 including VAT (15%)?", a: "R90", exp: "690 − 690/1,15 = 690 − 600 = 90." },
    { q: "Budget: income R9 500; expenses R8 200. Calculate surplus.", a: "R1 300", exp: "9 500 − 8 200 = 1 300." }
  ],
  ml_measurement: [
    { q: "Convert 3,2 m to cm.", a: "320 cm", exp: "3,2 × 100 = 320." },
    { q: "Area of a rectangle 4,5 m by 2,8 m?", a: "12,6 m²", exp: "4,5 × 2,8 = 12,6." },
    { q: "Perimeter of a square with side 6,5 cm?", a: "26 cm", exp: "4 × 6,5 = 26." },
    { q: "A room needs 28 m² of tiles plus 10% waste. How many m² to buy?", a: "30,8 m²", exp: "28 × 1,10 = 30,8." },
    { q: "Volume of a rectangular box 2 m × 1,5 m × 0,8 m?", a: "2,4 m³", exp: "2×1,5×0,8 = 2,4." },
    { q: "Convert 2 500 ml to litres.", a: "2,5 L", exp: "2 500 ÷ 1 000 = 2,5." },
    { q: "A circular garden has diameter 7 m. Approximate circumference (use π ≈ 22/7).", a: "22 m", exp: "C = πd = 22/7 × 7 = 22." },
    { q: "1 hectare equals how many square metres?", a: "10 000 m²", exp: "Standard conversion." }
  ],
  ml_maps: [
    { q: "Map scale 1:50 000. Map distance 4 cm. Actual distance in km?", a: "2 km", exp: "4 × 50 000 = 200 000 cm = 2 km." },
    { q: "Actual distance 7,5 km. Scale 1:25 000. Map distance in cm?", a: "30 cm", exp: "7,5 km = 750 000 cm; 750 000/25 000 = 30." },
    { q: "A plan uses scale 1:100. A wall is 8 cm on the plan. Actual length in m?", a: "8 m", exp: "8 × 100 = 800 cm = 8 m." },
    { q: "On a map, North is up. A road runs from bottom-left to top-right. Approximate direction of travel from SW corner?", a: "North-east / NE", exp: "Up and right on a standard map." },
    { q: "Scale 1:10 000. 1 cm on the map represents how many metres on the ground?", a: "100 m", exp: "10 000 cm = 100 m." },
    { q: "Two towns are 12 cm apart on a 1:250 000 map. Distance in km?", a: "30 km", exp: "12 × 250 000 = 3 000 000 cm = 30 km." }
  ],
  ml_data: [
    { q: "Data: 4, 7, 7, 9, 12. Calculate the mean.", a: "7,8", exp: "(4+7+7+9+12)/5 = 39/5 = 7,8." },
    { q: "Data: 3, 5, 8, 10, 14. Calculate the median.", a: "8", exp: "Middle value when ordered." },
    { q: "Data: 2, 5, 5, 7, 9, 5. What is the mode?", a: "5", exp: "5 appears most often." },
    { q: "Data: 11, 18, 4, 22, 9. Calculate the range.", a: "18", exp: "22 − 4 = 18." },
    { q: "In a pie chart, a sector of 90° represents what percentage of the whole?", a: "25%", exp: "90/360 = 1/4 = 25%." },
    { q: "A bar graph shows Mon 12, Tue 18, Wed 9 visitors. Total for three days?", a: "39", exp: "12+18+9 = 39." },
    { q: "Mean of five test scores is 64. Total of the five scores?", a: "320", exp: "64 × 5 = 320." },
    { q: "Ordered data: 2, 4, 6, 8, 10, 12. Median?", a: "7", exp: "Average of 6 and 8 = 7." }
  ],
  ml_probability: [
    { q: "A fair coin is tossed. Probability of heads?", a: "1/2", exp: "One favourable of two equally likely outcomes." },
    { q: "A die is rolled. Probability of a 4?", a: "1/6", exp: "One face out of six." },
    { q: "Bag: 5 red, 3 blue. Probability of red?", a: "5/8", exp: "5 favourable of 8." },
    { q: "Probability of an impossible event?", a: "0", exp: "Cannot occur." },
    { q: "Probability of a certain event?", a: "1", exp: "Must occur." },
    { q: "A spinner has 4 equal sectors: A,B,C,D. P(not A)?", a: "3/4", exp: "1 − 1/4 = 3/4." },
    { q: "Two outcomes equally likely: rain or no rain. P(rain)?", a: "1/2", exp: "If equally likely." },
    { q: "A card is drawn from 10 cards numbered 1–10. P(even number)?", a: "1/2", exp: "2,4,6,8,10 → 5/10 = 1/2." }
  ],
  bs_micro: [
    { q: "Name the eight business functions.", a: "General management, purchasing, production, marketing, public relations, human resources, administration, finance", exp: "Standard CAPS micro-environment list." },
    { q: "What is the difference between a vision and a mission statement?", a: "Vision is the long-term aspirational future picture; mission states the purpose and how the vision will be pursued.", exp: "Vision = where; mission = why/how." },
    { q: "List three types of resources in the micro environment.", a: "Human, physical, financial (and information)", exp: "Internal resources management can control." },
    { q: "Which business function is responsible for recruiting staff?", a: "Human resources", exp: "HR manages people." },
    { q: "What is an objective in a business context?", a: "A specific, measurable target that supports a broader goal", exp: "Goals are broad; objectives are SMART." },
    { q: "Give one example of a physical resource.", a: "Buildings / machinery / vehicles / equipment (any valid)", exp: "Tangible assets used in operations." },
    { q: "Who largely controls the micro environment?", a: "Management / the business itself", exp: "Internal environment is controllable." },
    { q: "Name the function that promotes the business image to the public.", a: "Public relations", exp: "PR manages external image and communication." },
    { q: "Identify the business function: negotiating contracts with suppliers of raw materials.", a: "Purchasing", exp: "Purchasing obtains inputs." },
    { q: "Identify the business function: preparing cash-flow forecasts and budgets.", a: "Finance", exp: "Finance manages money." },
    { q: "A bakery decides its long-term dream is to be the preferred bread supplier in Gauteng. Is this a vision or a mission?", a: "Vision", exp: "Vision is the long-term aspirational picture." },
    { q: "List two examples of information resources in a business.", a: "Sales data / customer database / market research / reports (any two)", exp: "Information supports decisions." },
  ],
  bs_market: [
    { q: "List four components of the market environment.", a: "Consumers, suppliers, competitors, intermediaries", exp: "Stakeholders the business can influence but not fully control." },
    { q: "What role do intermediaries play?", a: "They help distribute products (wholesalers, retailers, agents)", exp: "Link between producer and consumer." },
    { q: "Why must a business monitor competitors?", a: "To respond to prices, quality, new products and stay competitive", exp: "Competitors affect market share." },
    { q: "Give one way a business can influence consumers.", a: "Marketing / quality / price / service (any valid)", exp: "Market environment can be influenced." },
    { q: "Is government part of the market environment?", a: "No — government is part of the macro environment", exp: "Market = consumers, suppliers, competitors, intermediaries." },
    { q: "Name one risk of poor supplier relations.", a: "Higher costs / late deliveries / poor quality inputs", exp: "Suppliers provide inputs." },
    { q: "Read: Shop A lowers prices after Shop B opens nearby. Which market component is Shop B?", a: "Competitor", exp: "Competitors offer similar products." },
    { q: "A clothing brand sells through independent boutiques. What market component are the boutiques?", a: "Intermediaries", exp: "Intermediaries help distribute products." },
    { q: "Explain one way a business can influence its suppliers.", a: "Long-term contracts / volume orders / prompt payment / quality standards (any valid)", exp: "Market environment can be influenced." },
  ],
  bs_macro: [
    { q: "What does PESTEL stand for?", a: "Political, Economic, Social, Technological, Environmental, Legal", exp: "Framework for macro factors." },
    { q: "Give one economic factor that can affect a business.", a: "Inflation / interest rates / exchange rates / unemployment (any valid)", exp: "Economic conditions influence costs and demand." },
    { q: "How can a technological change affect a retailer?", a: "Online shopping / automation / new payment systems (any valid)", exp: "Technology changes how customers buy and firms operate." },
    { q: "Give one legal factor affecting South African businesses.", a: "Labour law / BCEA / consumer protection / tax law (any valid)", exp: "Legal environment sets compliance rules." },
    { q: "Can management control the macro environment?", a: "No — it must adapt to it", exp: "Macro factors are external and uncontrollable." },
    { q: "Rising fuel prices mainly illustrate which PESTEL factor?", a: "Economic (or Environmental)", exp: "Fuel prices are an economic cost driver." },
    { q: "Name one social factor relevant to a school uniform shop.", a: "Demographics / youth culture / school enrolment trends", exp: "Social trends affect demand." },
    { q: "Classify: a new minimum-wage law. Which PESTEL factor?", a: "Legal (or Political)", exp: "Labour law is a legal/political macro factor." },
    { q: "Classify: rapid growth in mobile-phone use among teens. Which PESTEL factor?", a: "Technological / Social", exp: "Tech adoption and social lifestyle change." },
    { q: "A drought raises maize prices. Which PESTEL factors are involved?", a: "Environmental and Economic", exp: "Climate event affecting costs and prices." },
    { q: "Why must businesses scan the macro environment?", a: "To anticipate changes and adapt strategy", exp: "Macro factors cannot be controlled but can be monitored." },
  ],
  bs_sectors: [
    { q: "Name the three economic sectors.", a: "Primary, secondary, tertiary", exp: "Extraction, manufacturing, services." },
    { q: "In which sector does a gold mine operate?", a: "Primary", exp: "Extraction of raw materials." },
    { q: "In which sector does a bakery factory operate?", a: "Secondary", exp: "Processing/manufacturing." },
    { q: "In which sector does a hotel operate?", a: "Tertiary", exp: "Service industry." },
    { q: "Give a simple value-chain example for timber.", a: "Forestry (primary) → sawmill (secondary) → furniture shop (tertiary)", exp: "Raw → process → service/retail." },
    { q: "Why is tourism classified as tertiary?", a: "It provides services rather than extracting or manufacturing goods", exp: "Services sector." },
    { q: "Classify: a commercial bank.", a: "Tertiary", exp: "Service sector." },
    { q: "Classify: a furniture factory.", a: "Secondary", exp: "Manufacturing." },
    { q: "Classify: a citrus farm.", a: "Primary", exp: "Extraction/production of raw materials." },
  ],
  bs_socio: [
    { q: "What is Corporate Social Responsibility (CSR)?", a: "Voluntary actions by a business to benefit society beyond legal requirements.", exp: "CSR goes beyond compliance." },
    { q: "What is CSI?", a: "Corporate Social Investment — the practical spending/projects arm of CSR", exp: "CSI implements CSR through projects." },
    { q: "Name two contemporary socioeconomic issues in South Africa.", a: "Poverty, unemployment, HIV/AIDS, crime, inequality, strikes (any two)", exp: "CAPS list of issues affecting business and communities." },
    { q: "How can unemployment affect a business?", a: "Lower consumer spending / smaller skilled labour pool", exp: "Demand and workforce both affected." },
    { q: "Give one example of a CSI project.", a: "Sponsoring a clinic / bursaries / community sports / skills training (any valid)", exp: "Investment in community welfare." },
    { q: "Is paying tax an example of CSR?", a: "No — tax is a legal requirement, not voluntary CSR", exp: "CSR is beyond legal duties." },
    { q: "A mining firm funds a local maths tutoring programme. Is this CSR or a legal requirement?", a: "CSR / CSI", exp: "Voluntary benefit beyond legal duties." },
    { q: "Explain one way crime can increase business costs.", a: "Security guards / insurance / theft losses / shorter trading hours", exp: "Socioeconomic issue impact." },
  ],
  bs_entrepreneurship: [
    { q: "Define entrepreneurship.", a: "Identifying opportunities, taking calculated risks and organising resources to start and grow a business", exp: "CAPS definition of the process." },
    { q: "Name four entrepreneurial qualities.", a: "Creativity, risk-taking, perseverance, initiative, passion, leadership (any four)", exp: "Personal qualities that support venture success." },
    { q: "Why are entrepreneurs important to the economy?", a: "They create jobs and contribute to economic growth", exp: "New ventures employ people and add value." },
    { q: "What is a calculated risk?", a: "A risk taken after assessing possible gains and losses", exp: "Not reckless — informed decision." },
    { q: "Give one reason a small business might fail.", a: "Poor planning / lack of capital / weak marketing / competition (any valid)", exp: "Many start-ups fail without sound management." },
    { q: "Name the entrepreneurial quality shown when a founder keeps going after two failed product launches.", a: "Perseverance / determination", exp: "Continuing despite setbacks." },
    { q: "A learner notices no healthy lunch options near school and plans a subscription snack box. What did they identify?", a: "A business opportunity", exp: "Gap between need and current supply." },
    { q: "Why is calculated risk-taking different from gambling in business?", a: "Calculated risk is based on research and possible outcomes; gambling is chance without analysis", exp: "Informed vs reckless." },
  ],
  bs_ownership: [
    { q: "Which form of ownership has unlimited liability and a single owner?", a: "Sole proprietor / sole trader", exp: "Owner and business are the same legal person." },
    { q: "What does limited liability mean?", a: "Owners are not personally liable for business debts beyond their investment/shares", exp: "Separate legal personality protects personal assets." },
    { q: "Name three forms of ownership.", a: "Sole proprietor, partnership, Pty (Ltd) / company (any three)", exp: "CAPS forms of ownership." },
    { q: "How many partners may a partnership typically have?", a: "2 to 20", exp: "Standard partnership range in CAPS context." },
    { q: "Advantage of a sole proprietorship?", a: "Owner keeps all profits / full control / easy to start (any valid)", exp: "Simple structure." },
    { q: "Disadvantage of a sole proprietorship?", a: "Unlimited liability / limited capital / long hours (any valid)", exp: "Owner bears all risk." },
    { q: "What is a Pty Ltd?", a: "A private company with limited liability", exp: "Separate legal person; shares not freely transferable to the public." },
    { q: "Thabo runs a one-person mobile phone repair stall and is personally liable for debts. Form of ownership?", a: "Sole proprietor", exp: "Single owner, unlimited liability." },
    { q: "Three friends start a design studio; they share profits and each has unlimited liability. Form?", a: "Partnership", exp: "2–20 owners, unlimited joint liability." },
    { q: "A business wants limited liability and up to 50 shareholders without offering shares to the public. Form?", a: "Private company / Pty Ltd", exp: "Limited liability; private shareholding." },
    { q: "Differentiate profit company and non-profit company in one sentence.", a: "Profit companies distribute surplus to owners; NPCs apply surplus to their public-benefit purpose", exp: "CAPS distinction." },
  ],
  bs_opportunity: [
    { q: "What is a business opportunity?", a: "A favourable set of circumstances that creates a need for a product or service", exp: "Gap in the market the entrepreneur can fill." },
    { q: "Name three typical sections of a business plan.", a: "Executive summary, market analysis, financial plan (or marketing, operations, management)", exp: "Standard business-plan structure." },
    { q: "Why is a business plan important?", a: "It guides the venture and helps attract finance / shows feasibility", exp: "Planning and funding tool." },
    { q: "Give one factor when choosing a business location.", a: "Customer access / rent cost / competition / infrastructure (any valid)", exp: "Location affects sales and costs." },
    { q: "What should a market analysis in a plan describe?", a: "Customers, competitors and demand for the product/service", exp: "Understanding the market." },
    { q: "State one reason banks ask for a business plan before lending.", a: "To assess viability / repayment ability / management planning", exp: "Plan is a funding and feasibility tool." },
    { q: "Name the business-plan section that describes target customers and competitors.", a: "Market analysis / marketing plan", exp: "Understanding demand and competition." },
    { q: "Give one challenge of the macro environment a new café might face (PESTEL).", a: "Rising food inflation / load-shedding / new health regulations (any valid)", exp: "External factors beyond control." },
  ],
  bs_creative: [
    { q: "Name one creative-thinking technique used in business.", a: "Brainstorming / mind-mapping / force-field analysis / Delphi / nominal group", exp: "CAPS lists several techniques." },
    { q: "List the main steps in problem-solving.", a: "Identify, analyse, generate options, evaluate, implement, review", exp: "Systematic problem-solving cycle." },
    { q: "What is the purpose of brainstorming?", a: "To generate many ideas quickly without judging them at first", exp: "Quantity first; evaluation later." },
    { q: "Why is creative thinking important in business?", a: "It helps find new products, processes and solutions to problems", exp: "Innovation and adaptation." },
    { q: "Difference between creative thinking and problem-solving?", a: "Creative thinking generates ideas; problem-solving selects and implements solutions", exp: "Generate vs decide and act." },
    { q: "Team lists 30 ideas in 10 minutes without criticising any idea. Technique?", a: "Brainstorming", exp: "Generate first; evaluate later." },
    { q: "After generating options, a manager scores each against cost and impact. Which problem-solving step is this?", a: "Evaluate / select options", exp: "Systematic problem-solving cycle." },
  ],
  bs_self: [
    { q: "Name two self-management skills.", a: "Time management, stress management, goal-setting, prioritising (any two)", exp: "Managing oneself effectively at work." },
    { q: "Why are teams used in business?", a: "Shared skills, better decisions, higher productivity, support", exp: "Collaboration benefits." },
    { q: "What is a team role?", a: "A specific contribution or function a member performs in the team", exp: "Clear roles reduce conflict and duplication." },
    { q: "Give one benefit of good time management.", a: "Meeting deadlines / less stress / higher productivity (any valid)", exp: "Self-management outcome." },
    { q: "What does successful teamwork require?", a: "Communication, cooperation, clear goals, respect (any valid)", exp: "Team effectiveness factors." },
    { q: "A project team has a leader, researcher, writer and presenter. What does this illustrate?", a: "Team roles / division of roles", exp: "Clear roles improve teamwork." },
    { q: "Give one strategy for managing workplace stress.", a: "Prioritising tasks / breaks / exercise / asking for help / time management (any valid)", exp: "Self-management skill." },
  ],
  tour_intro: [
    { q: "Define tourism.", a: "Activities of persons travelling to and staying in places outside their usual environment for not more than one consecutive year for leisure, business and other purposes", exp: "UNWTO-style definition used in CAPS." },
    { q: "What is the difference between inbound and outbound tourism?", a: "Inbound: visitors entering a country; outbound: residents leaving their country to travel", exp: "Direction of travel relative to the country." },
    { q: "Name three reasons people travel.", a: "Leisure, business, VFR, health, education, religion, sport (any three)", exp: "Travel motivations." },
    { q: "What does VFR stand for?", a: "Visiting friends and relatives", exp: "Common tourism purpose." },
    { q: "Is a daily commute to work considered tourism?", a: "No — it is within the usual environment", exp: "Tourism is outside usual environment." },
    { q: "Name one economic benefit of tourism to a country.", a: "Foreign exchange / jobs / tax revenue / infrastructure development (any valid)", exp: "Tourism contributes to GDP and employment." },
    { q: "A family from Johannesburg spends a weekend in Durban for leisure. Type of tourism for South Africa?", a: "Domestic tourism", exp: "Residents travelling within their country." },
    { q: "German visitors arrive in Cape Town for a holiday. Inbound or outbound for South Africa?", a: "Inbound", exp: "Visitors entering the country." },
    { q: "South African students fly to France for a year of study. Outbound or inbound for SA?", a: "Outbound", exp: "Residents leaving the country." },
    { q: "State the maximum consecutive stay usually associated with the tourism definition.", a: "One year / not more than one consecutive year", exp: "UNWTO-style definition used in CAPS." },
  ],
  tour_types: [
    { q: "Name four types of tourists.", a: "Leisure, business, VFR, eco, cultural, adventure, religious, sport (any four)", exp: "Tourist typology." },
    { q: "What does a business tourist typically value?", a: "Speed, reliability, Wi-Fi, meeting facilities", exp: "Business travel priorities." },
    { q: "What is an eco-tourist?", a: "A tourist who focuses on nature and low environmental impact", exp: "Responsible nature-based travel." },
    { q: "Give one need of an adventure tourist.", a: "Activity options / safety briefing / suitable equipment (any valid)", exp: "Adventure tourism requirements." },
    { q: "How might a backpacker's budget differ from a luxury leisure tourist?", a: "Backpacker seeks lower-cost transport and accommodation", exp: "Profile drives spending pattern." },
    { q: "What is cultural tourism focused on?", a: "Heritage, traditions, arts, local communities", exp: "Culture as the attraction." },
    { q: "A tourist books a guided hike in the Drakensberg and wants minimal environmental impact. Likely tourist type?", a: "Eco-tourist / adventure tourist", exp: "Nature and low impact." },
    { q: "A consultant flies in for a two-day conference and needs fast Wi-Fi. Tourist type?", a: "Business tourist", exp: "Travel for work/meetings." },
    { q: "Name one special-interest tourism type.", a: "Birding / wine / medical / sport / religious / heritage (any valid)", exp: "Travel driven by a specific interest." },
  ],
  tour_sectors: [
    { q: "Name five tourism industry sectors.", a: "Transport, accommodation, food and beverage, attractions, travel trade (any five)", exp: "Main sectors of the tourism industry." },
    { q: "Which sector do airlines belong to?", a: "Transport", exp: "Moving tourists between places." },
    { q: "Which sector do hotels and B&Bs belong to?", a: "Accommodation", exp: "Where tourists stay." },
    { q: "What does the travel trade sector include?", a: "Travel agents and tour operators", exp: "Intermediaries packaging and selling travel." },
    { q: "A museum is primarily part of which sector?", a: "Attractions", exp: "Places tourists visit." },
    { q: "Why is food and beverage important in tourism?", a: "Tourists need meals; local cuisine can be an attraction", exp: "F&B is both necessity and experience." },
    { q: "Booking.com and a local travel agency mainly belong to which sector?", a: "Travel trade", exp: "Intermediaries packaging and selling travel." },
    { q: "A restaurant inside a game lodge primarily supports which two sectors?", a: "Food and beverage and accommodation", exp: "F&B services within a stay facility." },
  ],
  tour_transport: [
    { q: "Name four modes of transport used in tourism.", a: "Air, road, rail, sea (water)", exp: "Main transport modes." },
    { q: "Give one advantage of air transport for tourists.", a: "Speed / long distances / international connections (any valid)", exp: "Air is fast for long hauls." },
    { q: "Give one disadvantage of air transport.", a: "Cost / carbon emissions / airport delays (any valid)", exp: "Trade-offs of flying." },
    { q: "When might a tourist choose rail over road?", a: "Scenic routes / avoiding traffic / city-centre arrivals (any valid)", exp: "Context-dependent choice." },
    { q: "Name one South African long-distance passenger rail or bus service type relevant to tourists.", a: "Luxury train / intercity coach / tourist bus (any valid)", exp: "Domestic transport options." },
    { q: "What is a car-hire service part of?", a: "Road transport sector", exp: "Self-drive tourism." },
    { q: "Give one advantage of coach travel for domestic tourists.", a: "Lower cost / door-to-door routes / scenic (any valid)", exp: "Road transport benefits." },
    { q: "Why might a tourist prefer a scheduled flight over a self-drive for a long intercity trip?", a: "Speed / safety / avoid fatigue / fixed schedule (any valid)", exp: "Mode choice factors." },
  ],
  tour_accommodation: [
    { q: "Name four types of tourist accommodation.", a: "Hotel, B&B, lodge, guesthouse, backpacker, camping, self-catering (any four)", exp: "Accommodation categories." },
    { q: "What does B&B stand for?", a: "Bed and breakfast", exp: "Overnight stay with breakfast included." },
    { q: "What is a lodge typically associated with?", a: "Game / nature / rural tourism settings", exp: "Often in or near parks." },
    { q: "Give one factor that influences accommodation choice.", a: "Budget / location / facilities / safety / star grading (any valid)", exp: "Guest decision factors." },
    { q: "Why is star grading useful for tourists?", a: "It indicates standard of facilities and service", exp: "Quality signal." },
    { q: "What does F&B mean in hospitality?", a: "Food and beverage", exp: "Meals and drinks services." },
    { q: "What does a 4-star grading generally indicate compared with 2-star?", a: "Higher standard of facilities and service", exp: "Star grading quality signal." },
    { q: "Name one in-room technology guests may expect in a modern hotel.", a: "Wi-Fi / smart TV / electronic safe / USB charging / AC (any valid)", exp: "Accommodation technology." },
  ],
  tour_maps: [
    { q: "Why do tourists use maps?", a: "To plan routes, locate attractions, estimate distances and travel times", exp: "Navigation and planning." },
    { q: "What does a map scale tell you?", a: "The relationship between map distance and real-world distance", exp: "e.g. 1:50 000." },
    { q: "Name three features you might find on a tourist map.", a: "Roads, attractions, accommodation, north arrow, scale, legend (any three)", exp: "Map elements." },
    { q: "What is an itinerary?", a: "A planned schedule of places, times and activities for a trip", exp: "Tour planning document." },
    { q: "Why is a legend (key) important on a map?", a: "It explains symbols used on the map", exp: "Without a key, symbols are unclear." },
    { q: "Give one tip for reading distance on a tourist map.", a: "Use the scale bar / measure and convert using the scale ratio", exp: "Scale converts map cm to real km." },
    { q: "On a map, the scale bar shows 0 to 50 km across 5 cm. What is the scale ratio (1 cm represents)?", a: "10 km (1:1 000 000)", exp: "5 cm → 50 km ⇒ 1 cm → 10 km." },
    { q: "Why include a north arrow on a tourist map?", a: "To orient the user / show direction", exp: "Orientation aid." },
  ],
  tour_attractions: [
    { q: "Name three categories of tourist attractions.", a: "Natural, cultural, man-made (or events)", exp: "Attraction classification." },
    { q: "Give one example of a natural attraction in South Africa.", a: "Kruger National Park / Table Mountain / Drakensberg / beaches (any valid)", exp: "Nature-based attractions." },
    { q: "Give one example of a cultural/heritage attraction.", a: "Robben Island / Cradle of Humankind / museums / cultural villages (any valid)", exp: "Culture and history." },
    { q: "What makes an attraction successful?", a: "Accessibility, unique appeal, facilities, marketing, safety (any valid)", exp: "Pull factors and management." },
    { q: "Why should attractions manage visitor numbers?", a: "To protect the site and maintain visitor experience", exp: "Carrying capacity / sustainability." },
    { q: "Name one man-made attraction.", a: "Theme park / stadium / shopping centre / monument (any valid)", exp: "Built attractions." },
    { q: "Classify Table Mountain: natural, cultural or man-made?", a: "Natural", exp: "Natural landscape feature." },
    { q: "Classify Robben Island Museum: natural, cultural or man-made?", a: "Cultural / heritage (man-made site with cultural significance)", exp: "Heritage attraction." },
    { q: "What is a primary attraction?", a: "The main reason tourists visit a destination", exp: "Primary vs secondary attractions." },
    { q: "Give one example of a secondary attraction that might accompany a primary sports event.", a: "Local restaurants / shopping / nearby parks / museums (any valid)", exp: "Extra activities beyond the main draw." },
  ],
  tour_sustainable: [
    { q: "What is sustainable tourism?", a: "Tourism that minimises harm to the environment and local culture while supporting the local economy", exp: "People, planet, profit balance." },
    { q: "Name three principles of responsible tourism.", a: "Reduce waste, conserve water/energy, respect culture, buy local, stay on paths (any three)", exp: "Practical responsible practices." },
    { q: "How can tourists reduce their environmental impact?", a: "Use less plastic / save water / choose eco-certified stays / public transport (any valid)", exp: "Individual actions." },
    { q: "Why is buying local products helpful?", a: "Supports local economy and often reduces transport emissions", exp: "Local multiplier effect." },
    { q: "What is greenwashing in tourism?", a: "Claiming to be environmentally friendly without real practices", exp: "Misleading marketing." },
    { q: "Name one benefit of sustainable tourism for host communities.", a: "Jobs / cultural preservation / infrastructure / income (any valid)", exp: "Community benefits when tourism is responsible." },
    { q: "Name the three pillars of sustainable tourism.", a: "Planet (environment), People (social), Profit (economic)", exp: "Three Ps balance." },
    { q: "List two ways a lodge can reduce its environmental impact.", a: "Solar power / water-saving fittings / waste recycling / local sourcing (any two)", exp: "Sustainable business practices." },
    { q: "What is responsible tourist behaviour?", a: "Actions by tourists that respect environment, culture and host communities", exp: "Tourist-side responsibility." },
  ],
  tour_domestic: [
    { q: "What is domestic tourism?", a: "Residents travelling within their own country", exp: "Opposite of international tourism." },
    { q: "What is regional tourism in a Southern African context?", a: "Travel between neighbouring countries in the region (e.g. SADC)", exp: "Cross-border but regional." },
    { q: "Give one reason governments promote domestic tourism.", a: "Keep spending in the local economy / reduce seasonality / build national pride (any valid)", exp: "Policy benefits." },
    { q: "What is inbound tourism?", a: "Visitors from other countries entering the destination country", exp: "International arrivals." },
    { q: "Name one challenge for domestic tourism in South Africa.", a: "Cost of transport / safety perceptions / limited leave / marketing (any valid)", exp: "Barriers to local travel." },
    { q: "How can statistics help tourism planners?", a: "Show volumes, seasons, source markets and spending so capacity and marketing can be planned", exp: "Data-driven planning." },
    { q: "Name one South African organisation or brand associated with promoting domestic tourism.", a: "South African Tourism / Sho’t Left / provincial tourism authorities (any valid)", exp: "Domestic marketing initiatives." },
    { q: "Give one benefit of regional (SADC) tourism cooperation.", a: "Cross-border packages / shared marketing / easier travel formalities (any valid)", exp: "Regional tourism advantages." },
  ],
  tour_service: [
    { q: "What is service excellence in tourism?", a: "Meeting and exceeding guest expectations consistently", exp: "Quality of service delivery." },
    { q: "Name three elements of good customer care.", a: "Greeting, listening, helpfulness, product knowledge, follow-up, recovery (any three)", exp: "Customer care behaviours." },
    { q: "What should staff do when a guest complains?", a: "Listen, apologise, solve the problem, follow up (service recovery)", exp: "Complaint handling steps." },
    { q: "Why is product knowledge important for tourism staff?", a: "So they can advise guests accurately and upsell appropriately", exp: "Knowledge builds trust." },
    { q: "Give one example of going beyond basic service.", a: "Remembering a guest preference / surprise upgrade / local tip (any valid)", exp: "Exceeding expectations." },
    { q: "How does poor service affect a tourism business?", a: "Bad reviews / lost repeat business / weaker reputation", exp: "Service quality drives loyalty." },
    { q: "A guest’s room is not ready at check-in. Outline two steps of good service recovery.", a: "Apologise; offer alternative/compensation; update guest; follow up (any two)", exp: "Listen, apologise, solve, follow up." },
    { q: "Why do tourism businesses monitor online reviews?", a: "To improve service / protect reputation / respond to complaints", exp: "Feedback drives service quality." },
  ]
};

const TOPIC_DIAGRAM = {
  ml_numbers: { type: "banner", title: "Numbers & calculations", bigText: "% · ratio · rate" },
  ml_patterns: { type: "banner", title: "Patterns", bigText: "tables · graphs" },
  ml_finance: { type: "table_diagram", title: "VAT 15%", cols: ["From", "Do"], rows: [["Excl. price", "× 1.15"], ["Incl. price", "÷ 1.15"], ["VAT amount", "× 0.15"]] },
  ml_measurement: { type: "shape_rect", L: 8, W: 5, label: "Rectangle · P & A" },
  ml_maps: { type: "map_scale", title: "Scale & maps" },
  ml_data: { type: "line_graph", title: "Data over time", labels: ["Mon", "Tue", "Wed", "Thu", "Fri"], values: [12, 18, 9, 15, 20] },
  ml_probability: { type: "dice", faces: 6, value: 4 },
  bs_micro: { type: "eight_functions", title: "Micro environment" },
  bs_market: { type: "banner", title: "Market environment", bigText: "customers · competitors" },
  bs_macro: { type: "pestel", title: "Macro environment (PESTEL)" },
  bs_sectors: { type: "sectors", title: "Business sectors", items: [{ t: "Primary", s: "Extract" }, { t: "Secondary", s: "Make" }, { t: "Tertiary", s: "Serve" }] },
  bs_socio: { type: "banner", title: "Socioeconomic issues", bigText: "CSR · CSI" },
  bs_entrepreneurship: { type: "banner", title: "Entrepreneurship", bigText: "opportunity · risk" },
  bs_ownership: { type: "table_diagram", title: "Forms of ownership", cols: ["Form", "Liability"], rows: [["Sole trader", "Unlimited"], ["Partnership", "Unlimited"], ["Pty Ltd", "Limited"]] },
  bs_opportunity: { type: "banner", title: "Business plan", bigText: "idea → plan" },
  bs_creative: { type: "banner", title: "Creative thinking", bigText: "brainstorm · evaluate" },
  bs_self: { type: "banner", title: "Self-management", bigText: "teams · roles" },
  tour_intro: { type: "banner", title: "Tourism", bigText: "travel · stay · experience" },
  tour_types: { type: "table_diagram", title: "Tourist types", cols: ["Type", "Focus"], rows: [["Leisure", "Relax"], ["Business", "Meetings"], ["VFR", "Family"], ["Eco", "Nature"]] },
  tour_sectors: { type: "sectors", title: "Tourism sectors", items: [{ t: "Transport", s: "Move" }, { t: "Beds", s: "Stay" }, { t: "Attractions", s: "See" }] },
  tour_transport: { type: "banner", title: "Transport", bigText: "air · rail · road · sea" },
  tour_accommodation: { type: "banner", title: "Accommodation", bigText: "hotel · B&B · lodge" },
  tour_maps: { type: "map_scale", title: "Tour planning maps" },
  tour_attractions: { type: "banner", title: "Attractions", bigText: "natural · cultural · built" },
  tour_sustainable: { type: "pillars", title: "Sustainable tourism" },
  tour_domestic: { type: "banner", title: "Domestic & international", bigText: "inbound · outbound" },
  tour_service: { type: "banner", title: "Service excellence", bigText: "listen · solve · follow up" }
};

const TOPIC_TABLE = {
  ml_finance: {
    title: "VAT quick reference (15%)",
    cols: ["Situation", "Calculation"],
    rows: [
      ["Price excluding VAT", "Add 15% → × 1.15"],
      ["Price including VAT", "Remove VAT → ÷ 1.15"],
      ["VAT amount from excl.", "× 0.15"],
      ["VAT amount from incl.", "incl. − (incl. ÷ 1.15)"]
    ]
  },
  ml_data: {
    title: "Measures of central tendency",
    cols: ["Measure", "How to find"],
    rows: [
      ["Mean", "Sum of values ÷ number of values"],
      ["Median", "Middle value when ordered"],
      ["Mode", "Most frequent value"],
      ["Range", "Highest − lowest"]
    ]
  },
  bs_sectors: {
    title: "Economic sectors",
    cols: ["Sector", "Activity", "Example"],
    rows: [
      ["Primary", "Extract raw materials", "Mining, farming"],
      ["Secondary", "Manufacture / process", "Factories, construction"],
      ["Tertiary", "Services", "Retail, tourism, banking"]
    ]
  },
  bs_macro: {
    title: "PESTEL factors",
    cols: ["Factor", "Examples"],
    rows: [
      ["Political", "Policy, elections, stability"],
      ["Economic", "Inflation, interest rates, exchange rates"],
      ["Social", "Demographics, culture, lifestyle"],
      ["Technological", "Innovation, automation, internet"],
      ["Environmental", "Climate, pollution, resources"],
      ["Legal", "Labour law, consumer law, tax"]
    ]
  },
  bs_ownership: {
    title: "Forms of ownership (summary)",
    cols: ["Form", "Owners", "Liability"],
    rows: [
      ["Sole proprietor", "1", "Unlimited"],
      ["Partnership", "2–20", "Unlimited (joint)"],
      ["Pty (Ltd)", "1–50", "Limited"],
      ["Public company", "7+", "Limited"],
      ["Close corporation*", "1–10", "Limited (*legacy)"]
    ]
  },
  tour_sectors: {
    title: "Tourism industry sectors",
    cols: ["Sector", "Examples"],
    rows: [
      ["Transport", "Airlines, coaches, car hire, trains"],
      ["Accommodation", "Hotels, B&Bs, lodges, camping"],
      ["Food & beverage", "Restaurants, catering"],
      ["Attractions", "Parks, museums, heritage sites"],
      ["Travel trade", "Travel agents, tour operators"]
    ]
  },
  tour_types: {
    title: "Tourist profiles (examples)",
    cols: ["Type", "Typical need"],
    rows: [
      ["Leisure", "Relaxation, sightseeing"],
      ["Business", "Speed, Wi-Fi, meetings"],
      ["VFR", "Affordable stays near family"],
      ["Eco-tourist", "Low impact, nature focus"],
      ["Adventure", "Activity, safety briefing"]
    ]
  },
  ml_measurement: {
    title: "Common conversions",
    cols: ["From", "To"],
    rows: [
      ["1 km", "1 000 m"],
      ["1 m", "100 cm"],
      ["1 L", "1 000 ml"],
      ["1 kg", "1 000 g"],
      ["1 ha", "10 000 m²"]
    ]
  }
};

function notesFor(topicId) {
  const n = NOTES[topicId];
  if (!n) {
    return {
      about: "CAPS topic notes for Grade 10. Open practice and quizzes to build mastery.",
      key_facts: ["Review the topic title and related CAPS content.", "Practise short questions regularly."],
      formulae: [],
      method: "Read the key facts, attempt practice questions, then check solutions.",
      common_mistakes: [],
      worked_examples: [],
      table: TOPIC_TABLE[topicId] || null,
      tables: TOPIC_TABLE[topicId] ? [TOPIC_TABLE[topicId]] : [],
      diagram: TOPIC_DIAGRAM[topicId] || null
    };
  }
  const table = n.table || TOPIC_TABLE[topicId] || null;
  const tables = n.tables || (table ? [table] : []);
  const lesson = (typeof getLesson === "function") ? getLesson(topicId) : null;
  const about = (lesson && lesson.plain)
    ? (lesson.plain + (n.about ? "\n\n" + n.about : ""))
    : (n.about || "");
  const key_facts = (n.key_facts || []).slice();
  if (lesson && lesson.steps && lesson.steps.length) {
    // Keep notes self-contained: first steps double as readable teaching points
    lesson.steps.slice(0, 3).forEach((s) => {
      if (s && !key_facts.includes(s)) key_facts.push(s);
    });
  }
  const definitions = n.definitions || (lesson && lesson.terms) || [];
  return {
    about,
    key_facts,
    formulae: n.formulae || [],
    method: n.method || (lesson ? "Work through the Learning card for this topic, then try practice questions." : ""),
    common_mistakes: n.common_mistakes || [],
    worked_examples: n.worked_examples || [],
    definitions,
    table,
    tables,
    diagram: n.diagram || TOPIC_DIAGRAM[topicId] || null,
    lesson_title: lesson ? lesson.title : null
  };
}

const SUBJECT_TOPICS = {
  mathematical_literacy: ["ml_numbers", "ml_patterns", "ml_finance", "ml_measurement", "ml_maps", "ml_data", "ml_probability"],
  business_studies: ["bs_micro", "bs_market", "bs_macro", "bs_sectors", "bs_socio", "bs_entrepreneurship", "bs_ownership", "bs_opportunity", "bs_creative", "bs_self"],
  tourism: ["tour_intro", "tour_types", "tour_sectors", "tour_transport", "tour_accommodation", "tour_maps", "tour_attractions", "tour_sustainable", "tour_domestic", "tour_service"]
};

function topicName(id) {
  return String(id || "").replaceAll("_", " ").replace(/^ml /, "ML · ").replace(/^bs /, "Business · ").replace(/^tour /, "Tourism · ");
}

function normalizeQ(q, topicId, opts = {}) {
  if (!q) q = {};
  const tid = q.topic || topicId || "ml_numbers";
  const prompt = q.prompt || q.question || "Answer the question.";
  return {
    ...q,
    id: q.id || `g10_${tid}_${Date.now()}_${ri(100, 999)}`,
    prompt,
    question: q.question || prompt,
    answer: q.answer != null ? String(q.answer) : "",
    explanation: q.explanation || "",
    hint: q.hint || "Use the topic notes and show your working.",
    topic: tid,
    topic_name: q.topic_name || topicName(tid),
    difficulty: q.difficulty || opts.difficulty || opts.marks || 2,
    marks: q.marks || opts.marks || 2,
    type: q.type || "short",
    diagram: q.diagram || TOPIC_DIAGRAM[tid] || null
  };
}

function resolveTopic(topicId, subjectId) {
  if (topicId && (NOTES[topicId] || BANK[topicId] || isMlTopic(topicId))) return topicId;
  const pool = SUBJECT_TOPICS[subjectId] || SUBJECT_TOPICS.mathematical_literacy;
  return choice(pool);
}

function generateConcept(topicId, opts = {}) {
  const tid = resolveTopic(topicId, opts.subjectId);
  const bank = BANK[tid] || [];
  if (!bank.length) {
    return normalizeQ({
      prompt: `State one key fact about ${topicName(tid)}.`,
      answer: "See topic notes.",
      explanation: "Refer to the notes for this topic.",
      type: "concept",
      topic: tid
    }, tid, opts);
  }
  const item = choice(bank);
  return normalizeQ({
    prompt: item.q,
    answer: item.a,
    explanation: item.exp || "",
    type: "concept",
    topic: tid
  }, tid, opts);
}

function generate(topicId, opts = {}) {
  const tid = resolveTopic(topicId, opts.subjectId);
  // Mathematical Literacy: generative recipes (randomised CAPS contexts)
  if (isMlTopic(tid)) {
    try {
      const q = generateMlQuestion(tid, opts);
      if (q && (q.prompt || q.question)) return normalizeQ(q, tid, opts);
    } catch (_) { /* fall through */ }
  }
  // Prefer bank items; fall back to concept
  const bank = BANK[tid] || [];
  if (bank.length) {
    const item = choice(bank);
    return normalizeQ({
      prompt: item.q,
      answer: String(item.a),
      explanation: item.exp || "",
      topic: tid,
      marks: opts.marks || 2,
      type: "short"
    }, tid, opts);
  }
  return generateConcept(tid, opts);
}

function generatePaperParts(topicId, opts = {}) {
  if (isMlTopic(topicId)) {
    try {
      const block = generateMlPaperParts(topicId, opts);
      if (block && block.parts && block.parts.length) return block;
    } catch (_) { /* fall through */ }
  }
  const bank = BANK[topicId] || [];
  const count = Math.min(opts.parts || 3, Math.max(1, bank.length || 1));
  const items = shuffle(bank).slice(0, count);
  if (!items.length) {
    const one = generate(topicId);
    return {
      topic: topicId,
      title: String(topicId).replaceAll("_", " "),
      parts: [{ label: "1.1", prompt: one.prompt, answer: one.answer, explanation: one.explanation, marks: 2 }]
    };
  }
  return {
    topic: topicId,
    title: String(topicId).replaceAll("_", " "),
    parts: items.map((it, i) => ({
      label: `1.${i + 1}`,
      prompt: it.q,
      answer: String(it.a),
      explanation: it.exp || "",
      marks: 2
    }))
  };
}


const MULTI_PREFIXES = ["ml_", "bs_", "tour_"];
export function isMultiSubjectTopic(topicId) {
  if (!topicId) return false;
  const id = String(topicId);
  return MULTI_PREFIXES.some((p) => id.startsWith(p)) || Boolean(NOTES[id] || BANK[id]);
}

export class MultiSubjectEngine {
  constructor(gradeOrSubject = 10, gradeMaybe = null) {
    // Support both MultiSubjectEngine(grade) and MultiSubjectEngine(subjectId, grade)
    if (typeof gradeOrSubject === "string") {
      this.subjectId = gradeOrSubject;
      this.grade = gradeMaybe || 10;
    } else {
      this.subjectId = null;
      this.grade = gradeOrSubject || 10;
    }
  }
  notesFor(topicId) { return notesFor(topicId); }
  generate(topicId, opts = {}) {
    return generate(topicId, { ...opts, subjectId: opts.subjectId || this.subjectId });
  }
  generateConcept(topicId, opts = {}) {
    return generateConcept(topicId, { ...(typeof opts === "object" ? opts : {}), subjectId: (opts && opts.subjectId) || this.subjectId });
  }
  generatePaperParts(topicId, opts) { return generatePaperParts(topicId, opts); }
  hasTopic(topicId) { return Boolean(NOTES[topicId] || BANK[topicId]); }
  topicsForSubject(subjectId) {
    return (SUBJECT_TOPICS[subjectId || this.subjectId] || SUBJECT_TOPICS.mathematical_literacy).slice();
  }
}

export { NOTES, BANK, notesFor, generate, generateConcept, generatePaperParts };
