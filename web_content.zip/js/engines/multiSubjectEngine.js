/**
 * learnyZ — lightweight generative engine for Life Sciences, Geography,
 * Natural Sciences & Technology (scaffold content; expands over time).
 */
function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

const NOTES = {
  ls_cells: {
    about: "All living organisms are made of cells. Plant and animal cells share organelles but plants have a cell wall and chloroplasts.",
    key_facts: [
      "Cell theory: all living things are made of cells; cells come from pre-existing cells.",
      "Nucleus contains DNA; mitochondria release energy.",
      "Plant cells: cell wall, chloroplasts, large vacuole."
    ],
    formulae: [],
    diagram: { type: "cell_simple" }
  },
  ls_genetics: {
    about: "Genetics studies how characteristics are inherited through genes on chromosomes.",
    key_facts: [
      "Genes are sections of DNA that code for traits.",
      "Alleles are alternative forms of a gene.",
      "Dominant alleles mask recessive ones in heterozygotes."
    ],
    formulae: [],
    diagram: null
  },
  ls_human: {
    about: "Human body systems work together to maintain life: circulatory, respiratory, digestive, nervous and more.",
    key_facts: [
      "Heart pumps blood through arteries, capillaries and veins.",
      "Lungs exchange oxygen and carbon dioxide.",
      "Neurons transmit electrical impulses."
    ],
    formulae: [],
    diagram: null
  },
  geo_mapwork: {
    about: "Mapwork uses scale, direction, contour lines and GIS to interpret the landscape.",
    key_facts: [
      "Scale links map distance to ground distance.",
      "Contour lines join points of equal height.",
      "GIS stores and analyses spatial data in layers."
    ],
    formulae: ["Ground distance = map distance × scale factor"],
    diagram: { type: "map_scale" }
  },
  geo_climate: {
    about: "Climate is the long-term pattern of weather. Factors include latitude, altitude, ocean currents and prevailing winds.",
    key_facts: [
      "Weather is short-term; climate is long-term average.",
      "Temperature generally decreases with latitude and altitude.",
      "South Africa has a variety of climate regions."
    ],
    formulae: [],
    diagram: null
  },
  geo_population: {
    about: "Population geography studies distribution, density, growth and development indicators.",
    key_facts: [
      "Birth rate, death rate and migration change population size.",
      "Population pyramids show age–sex structure.",
      "Development indicators include GDP per capita, literacy and life expectancy."
    ],
    formulae: [],
    diagram: null
  },
  ns_life_living: {
    about: "Life and living covers plants, animals, habitats and ecosystems in the Natural Sciences CAPS strand.",
    key_facts: [
      "Living things need energy, water and a suitable habitat.",
      "Food chains show energy flow: producer → consumer.",
      "Habitats provide food, water and shelter."
    ],
    formulae: [],
    diagram: { type: "food_chain" }
  },
  ns_matter_materials: {
    about: "Matter is anything that has mass and occupies space. Materials have properties that make them useful.",
    key_facts: [
      "Solids, liquids and gases are states of matter.",
      "Physical properties include hardness, flexibility and conductivity.",
      "Mixtures can often be separated by physical methods."
    ],
    formulae: [],
    diagram: { type: "states_of_matter" }
  },
  ns_energy_change: {
    about: "Energy can be stored, transferred and transformed. CAPS explores heat, light, sound and electrical energy.",
    key_facts: [
      "Energy cannot be created or destroyed, only transferred.",
      "Heat flows from hot to cold.",
      "Circuits need a closed path for current to flow."
    ],
    formulae: [],
    diagram: { type: "simple_circuit" }
  },
  ns_planet_earth: {
    about: "Planet Earth and beyond includes the solar system, seasons, day and night, and Earth’s resources.",
    key_facts: [
      "Earth rotates once per day and orbits the Sun once per year.",
      "The Moon orbits Earth and causes phases.",
      "Rocks, soil and water are important Earth resources."
    ],
    formulae: [],
    diagram: null
  },
  tech_structures: {
    about: "Structures support loads. Frame and shell structures appear in nature and design.",
    key_facts: [
      "Strong shapes include triangles and arches.",
      "Materials and joints affect strength and stability.",
      "Structures must resist forces without collapsing."
    ],
    formulae: [],
    diagram: null
  },
  tech_electrical: {
    about: "Electrical systems use components in circuits to control energy flow.",
    key_facts: [
      "A simple circuit needs a source, path and load.",
      "Switches open or close the path.",
      "Series and parallel arrangements change current paths."
    ],
    formulae: [],
    diagram: { type: "simple_circuit" }
  },
  tech_mechanical: {
    about: "Mechanical systems use gears, levers and linkages to transfer motion and force.",
    key_facts: [
      "Levers multiply force or distance depending on fulcrum position.",
      "Gears can change speed and direction of rotation.",
      "Friction can help (grip) or waste energy (heat)."
    ],
    formulae: [],
    diagram: null
  },
  tech_processing: {
    about: "Processing changes materials into useful products through physical or chemical methods.",
    key_facts: [
      "Raw materials are processed into finished goods.",
      "Steps may include sorting, mixing, heating and shaping.",
      "Safety and waste management matter in every process."
    ],
    formulae: [],
    diagram: null
  },
  tech_systems: {
    about: "Systems and control study how inputs, processes and outputs work together, including simple electrical control.",
    key_facts: [
      "A system has input → process → output.",
      "Feedback can control a system.",
      "Sensors detect changes in the environment."
    ],
    formulae: [],
    diagram: null
  }
};

// Default note for unknown topics
function defaultNote(topicId) {
  const name = String(topicId || "topic").replaceAll("_", " ");
  return {
    about: `CAPS topic: ${name}. Key ideas for this grade band.`,
    key_facts: [
      `Focus on the core definitions for ${name}.`,
      "Use diagrams and real-life examples when you revise.",
      "Practise short questions, then longer explanations."
    ],
    formulae: [],
    diagram: null
  };
}

const BANK = {
  ls_cells: [
    ["What organelle contains the genetic material DNA?", "Nucleus", "The nucleus holds chromosomes made of DNA."],
    ["Name one organelle found in plant cells but not animal cells.", "Chloroplast", "Chloroplasts carry out photosynthesis. Cell wall is also valid."],
    ["What is the basic unit of life?", "Cell", "Cell theory states all living things are made of cells."]
  ],
  ls_genetics: [
    ["What is an alternative form of a gene called?", "Allele", "Alleles occupy the same locus on homologous chromosomes."],
    ["If an allele is always expressed when present, it is called…", "Dominant", "Recessive alleles are only expressed when homozygous."]
  ],
  ls_human: [
    ["Which organ pumps blood around the body?", "Heart", "The heart is a muscular pump in the circulatory system."],
    ["Which gas do we inhale for respiration?", "Oxygen", "Oxygen is used in cellular respiration; CO₂ is exhaled."]
  ],
  geo_mapwork: [
    ["What do contour lines join?", "Points of equal height", "Close contours mean steep slopes."],
    ["What does GIS stand for?", "Geographic Information System", "GIS layers spatial data for analysis."]
  ],
  geo_climate: [
    ["Is climate short-term or long-term weather patterns?", "Long-term", "Weather is day-to-day; climate is long-term average."],
    ["Name one factor that affects climate.", "Latitude", "Also altitude, ocean currents, distance from sea, winds."]
  ],
  geo_population: [
    ["What does a population pyramid show?", "Age and sex structure", "Wide base suggests high birth rates."],
    ["Birth rate minus death rate is called…", "Natural increase", "Migration also changes total population."]
  ],
  ns_life_living: [
    ["What is the first organism in a food chain called?", "Producer", "Producers make food by photosynthesis."],
    ["Name one thing a habitat must provide.", "Food", "Also water, shelter and space."]
  ],
  ns_matter_materials: [
    ["Name the three common states of matter.", "Solid, liquid, gas", "Plasma is a fourth state but less common in this grade."],
    ["Does a solid have a fixed shape?", "Yes", "Liquids take the shape of their container."]
  ],
  ns_energy_change: [
    ["Heat flows from … to … objects.", "Hot to cold", "Energy transfers from higher to lower temperature."],
    ["What must a circuit be for current to flow?", "Closed", "An open switch breaks the path."]
  ],
  ns_planet_earth: [
    ["How long does Earth take to rotate once?", "One day", "About 24 hours."],
    ["What causes the phases of the Moon?", "The Moon orbiting Earth", "We see different portions of the sunlit half."]
  ],
  tech_structures: [
    ["Which shape is especially strong in frames?", "Triangle", "Triangles resist changing shape under load."],
    ["What is a structure designed to do?", "Support loads", "It must be strong and stable."]
  ],
  tech_electrical: [
    ["Name three parts of a simple circuit.", "Source, path, load", "e.g. battery, wires, bulb."],
    ["What does a switch do?", "Opens or closes the circuit", "It controls whether current can flow."]
  ],
  tech_mechanical: [
    ["What is the pivot of a lever called?", "Fulcrum", "Load and effort positions determine mechanical advantage."],
    ["Gears can change speed and…", "Direction", "Meshed gears reverse rotation direction."]
  ]
};

export class MultiSubjectEngine {
  constructor(subjectId = "life_sciences", grade = 8) {
    this.subjectId = subjectId || "life_sciences";
    this.grade = grade;
  }

  notesFor(topicId) {
    return NOTES[topicId] || defaultNote(topicId);
  }

  generate(topicId = null, difficulty = 2) {
    const ids = topicId ? [topicId] : Object.keys(BANK);
    const tid = choice(ids.filter((id) => BANK[id]) || ids);
    const pool = BANK[tid] || BANK.ls_cells;
    const [question, answer, explanation] = choice(pool);
    const note = this.notesFor(tid);
    return {
      id: `ms_${tid}_${ri(1000, 9999)}`,
      topic: tid,
      topic_name: tid.replaceAll("_", " "),
      subject: this.subjectId,
      question,
      answer,
      explanation: explanation || "",
      diagram: note.diagram || null,
      difficulty,
      marks: 2
    };
  }
}

export function isMultiSubjectTopic(id) {
  const s = String(id || "");
  return /^(ls_|geo_|ns_|tech_)/.test(s);
}
