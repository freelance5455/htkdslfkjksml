import { diagramForTopic, recipe } from "./diagramEngine.js";
/**
 * learnyZ — lightweight generative engine for Life Sciences, Geography, Accounting,
 * Natural Sciences & Technology (scaffold content; expands over time).
 */
function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

const NOTES = {
  ls_cells: {
    about: "All living organisms are made of cells. Plant and animal cells share organelles but plants have a cell wall and chloroplasts.",
    key_facts: [
      "Cell theory: all living things are made of cells; cells come from pre-existing cells.",
      "Nucleus contains DNA; mitochondria release energy.",
      "Plant cells: cell wall, chloroplasts, large vacuole."
    ],
    formulae: [],
    diagram: { type: "cell_simple" }
  },
  ls_genetics: {
    about: "Genetics studies how characteristics are inherited through genes on chromosomes.",
    key_facts: [
      "Genes are sections of DNA that code for traits.",
      "Alleles are alternative forms of a gene.",
      "Dominant alleles mask recessive ones in heterozygotes."
    ],
    formulae: [],
    diagram: null
  },
  ls_human: {
    about: "Human body systems work together to maintain life: circulatory, respiratory, digestive, nervous and more.",
    key_facts: [
      "Heart pumps blood through arteries, capillaries and veins.",
      "Lungs exchange oxygen and carbon dioxide.",
      "Neurons transmit electrical impulses."
    ],
    formulae: [],
    diagram: null
  },
  geo_mapwork: {
    about: "Mapwork uses scale, direction, contour lines and GIS to interpret the landscape.",
    key_facts: [
      "Scale links map distance to ground distance.",
      "Contour lines join points of equal height.",
      "GIS stores and analyses spatial data in layers."
    ],
    formulae: ["Ground distance = map distance × scale factor"],
    diagram: { type: "map_scale" }
  },
  geo_climate: {
    about: "Climate is the long-term pattern of weather. Factors include latitude, altitude, ocean currents and prevailing winds.",
    key_facts: [
      "Weather is short-term; climate is long-term average.",
      "Temperature generally decreases with latitude and altitude.",
      "South Africa has a variety of climate regions."
    ],
    formulae: [],
    diagram: null
  },
  geo_population: {
    about: "Population geography studies distribution, density, growth and development indicators.",
    key_facts: [
      "Birth rate, death rate and migration change population size.",
      "Population pyramids show age–sex structure.",
      "Development indicators include GDP per capita, literacy and life expectancy."
    ],
    formulae: [],
    diagram: null
  },
  ns_life_living: {
    diagram: { type: "plant_structure" },
    about: "Life and living covers plants, animals, habitats and ecosystems in the Natural Sciences CAPS strand.",
    key_facts: [
      "Living things need energy, water and a suitable habitat.",
      "Food chains show energy flow: producer → consumer.",
      "Habitats provide food, water and shelter."
    ],
    formulae: [],
    diagram: { type: "food_chain" }
  },
  ns_matter_materials: {
    about: "Matter is anything that has mass and occupies space. Materials have properties that make them useful.",
    key_facts: [
      "Solids, liquids and gases are states of matter.",
      "Physical properties include hardness, flexibility and conductivity.",
      "Mixtures can often be separated by physical methods."
    ],
    formulae: [],
    diagram: { type: "states_of_matter" }
  },
  ns_energy_change: {
    about: "Energy can be stored, transferred and transformed. CAPS explores heat, light, sound and electrical energy.",
    key_facts: [
      "Energy cannot be created or destroyed, only transferred.",
      "Heat flows from hot to cold.",
      "Circuits need a closed path for current to flow."
    ],
    formulae: [],
    diagram: { type: "simple_circuit" }
  },
  ns_planet_earth: {
    diagram: { type: "solar_system" },
    about: "Planet Earth and beyond includes the solar system, seasons, day and night, and Earth’s resources.",
    key_facts: [
      "Earth rotates once per day and orbits the Sun once per year.",
      "The Moon orbits Earth and causes phases.",
      "Rocks, soil and water are important Earth resources."
    ],
    formulae: [],
    diagram: null
  },
  tech_structures: {
    about: "Structures support loads. Frame and shell structures appear in nature and design.",
    key_facts: [
      "Strong shapes include triangles and arches.",
      "Materials and joints affect strength and stability.",
      "Structures must resist forces without collapsing."
    ],
    formulae: [],
    diagram: null
  },
  tech_electrical: {
    about: "Electrical systems use components in circuits to control energy flow.",
    key_facts: [
      "A simple circuit needs a source, path and load.",
      "Switches open or close the path.",
      "Series and parallel arrangements change current paths."
    ],
    formulae: [],
    diagram: { type: "simple_circuit" }
  },
  tech_mechanical: {
    diagram: { type: "lever" },
    about: "Mechanical systems use gears, levers and linkages to transfer motion and force.",
    key_facts: [
      "Levers multiply force or distance depending on fulcrum position.",
      "Gears can change speed and direction of rotation.",
      "Friction can help (grip) or waste energy (heat)."
    ],
    formulae: [],
    diagram: null
  },
  tech_processing: {
    about: "Processing changes materials into useful products through physical or chemical methods.",
    key_facts: [
      "Raw materials are processed into finished goods.",
      "Steps may include sorting, mixing, heating and shaping.",
      "Safety and waste management matter in every process."
    ],
    formulae: [],
    diagram: null
  },
  tech_systems: {
    about: "Systems and control study how inputs, processes and outputs work together, including simple electrical control.",
    key_facts: [
      "A system has input → process → output.",
      "Feedback can control a system.",
      "Sensors detect changes in the environment."
    ],
    formulae: [],
    diagram: null
  },
  acc_concepts: {
    diagram: { type: "accounting_equation", assets: 12000, liabilities: 4000, equity: 8000 },
        definitions: [
      ["Asset", "Resource controlled by the business"],
      ["Liability", "Present obligation to outsiders"],
      ["Equity", "Owner's interest in the business"],
      ["Expense", "Cost incurred to earn income"],
      ["Income", "Earnings from operations or other sources"]
    ],
about: "Accounting records, classifies and reports financial information. The accounting equation Assets = Owner's equity + Liabilities must always balance.",
    key_facts: [
      "Assets are resources controlled by the business (cash, inventory, equipment).",
      "Liabilities are amounts owed to outsiders (creditors, loans).",
      "Owner's equity is the owner's interest: capital + profits − drawings.",
      "Every transaction has a dual effect that keeps the equation in balance."
    ],
    formulae: ["Assets = Owner's equity + Liabilities", "Owner's equity = Capital + Profit − Drawings"],
    diagram: null
  },
  acc_books: {
    diagram: { type: "journal_table" },
    table: {
      title: "Example — Cash Receipts Journal (extract)",
      cols: ["Date", "Details", "Analysis of receipts", "Bank"],
      rows: [
        ["01 Mar", "Capital", "Capital 20 000", "20 000"],
        ["05 Mar", "Cash sales", "Sales 3 500", "3 500"],
        ["12 Mar", "D. Dlamini", "Debtors 1 200", "1 200"]
      ]
    },
    about: "Books of first entry (journals) record transactions chronologically before posting to the general ledger. Common journals: Cash Receipts, Cash Payments, Sales, Purchases, Petty Cash, General Journal.",
    key_facts: [
      "Source documents (invoices, receipts, cheques) support each entry.",
      "Cash receipts journal records money received; cash payments journal records money paid.",
      "Sales journal records credit sales; purchases journal records credit purchases.",
      "The general journal is used for non-routine entries and corrections."
    ],
    formulae: [],
    diagram: null
  },
  acc_ledger: {
    diagram: { type: "t_account", account: "Bank" },
    table: {
      title: "Example — Trial balance (extract)",
      cols: ["Account", "Debit (R)", "Credit (R)"],
      rows: [
        ["Bank", "25 000", ""],
        ["Capital", "", "40 000"],
        ["Purchases", "15 000", ""],
        ["Sales", "", "12 000"],
        ["Rent expense", "3 000", ""],
        ["Drawings", "9 000", ""],
        ["Totals", "52 000", "52 000"]
      ]
    },
    about: "The general ledger holds individual accounts. Debits and credits post from journals. A trial balance lists account balances to check that total debits equal total credits.",
    key_facts: [
      "Assets and expenses normally have debit balances; equity, liabilities and income have credit balances.",
      "Posting transfers journal totals or individual amounts to ledger accounts.",
      "A trial balance that balances does not prove all entries are correct—only that debits equal credits.",
      "Closing entries transfer temporary accounts (income, expenses) to the capital account."
    ],
    formulae: ["Total debits = Total credits (trial balance)"],
    diagram: null
  },
  acc_debtors: {
    about: "Debtors (accounts receivable) owe the business for credit sales. Creditors (accounts payable) are suppliers the business owes for credit purchases. Control accounts summarise subsidiary ledgers.",
    key_facts: [
      "Debtors control account total should equal the sum of individual debtor balances.",
      "Bad debts arise when a debtor cannot pay; provision for bad debts is an estimate.",
      "Credit notes reduce debtors for returns or allowances.",
      "Age analysis helps manage collection of overdue accounts."
    ],
    formulae: [],
    diagram: null
  },
  acc_bank: {
    diagram: { type: "bank_recon" },
    table: {
      title: "Example — Bank reconciliation",
      cols: ["Details", "Amount (R)"],
      rows: [
        ["Balance per bank statement", "8 450"],
        ["Add: Outstanding deposit", "1 200"],
        ["Less: Outstanding cheques", "(950)"],
        ["Balance per cash book", "8 700"]
      ]
    },
    about: "A bank reconciliation explains differences between the cash book balance and the bank statement balance. Timing differences and errors must be identified and adjusted.",
    key_facts: [
      "Outstanding deposits: recorded in the cash book but not yet on the bank statement.",
      "Outstanding cheques: issued and recorded but not yet cleared by the bank.",
      "Bank charges, interest and direct deposits appear on the statement first.",
      "Errors in the cash book are corrected before preparing the reconciliation."
    ],
    formulae: [],
    diagram: null
  },
  acc_vat: {
    table: {
      title: "VAT calculation (15%)",
      cols: ["Item", "Exclusive", "VAT", "Inclusive"],
      rows: [
        ["Taxable supply", "200", "30", "230"],
        ["Another supply", "1 000", "150", "1 150"]
      ]
    },
    about: "Value-Added Tax (VAT) is a consumption tax collected by registered vendors. Output VAT is charged on taxable supplies; input VAT is paid on purchases and can usually be claimed back.",
    key_facts: [
      "Standard rate in South Africa is currently 15%.",
      "Output VAT − Input VAT = VAT payable (or refundable) to SARS.",
      "VAT-exclusive price × 15% = VAT amount; inclusive price × 15/115 = VAT.",
      "Zero-rated and exempt supplies are treated differently for input claims."
    ],
    formulae: ["VAT = exclusive amount × 0.15", "Exclusive = inclusive × 100/115", "VAT payable = Output VAT − Input VAT"],
    diagram: null
  },
  acc_inventory: {
    about: "Inventory systems track stock. Periodic systems update inventory at period end; perpetual systems update continuously. Cost of sales depends on the cost flow assumption (FIFO, weighted average).",
    key_facts: [
      "Cost of sales = Opening inventory + Purchases − Closing inventory (periodic).",
      "FIFO assumes oldest goods are sold first.",
      "Weighted average uses a moving average cost per unit.",
      "Stocktake verifies physical quantities against records."
    ],
    formulae: ["Cost of sales = Opening stock + Net purchases − Closing stock"],
    diagram: null
  },
  acc_financials: {
    diagram: { type: "income_statement" },
    table: {
      title: "Example — Income statement extract",
      cols: ["Details", "R"],
      rows: [
        ["Sales", "45 000"],
        ["Cost of sales", "(28 000)"],
        ["Gross profit", "17 000"],
        ["Operating expenses", "(9 500)"],
        ["Net profit", "7 500"]
      ]
    },
    about: "Financial statements communicate results and position. The Statement of Comprehensive Income (Income Statement) reports profit; the Statement of Financial Position (Balance Sheet) reports assets, equity and liabilities.",
    key_facts: [
      "Gross profit = Sales − Cost of sales.",
      "Net profit is after operating expenses and other income/expenses.",
      "Current assets are expected to be realised within 12 months.",
      "Non-current liabilities are due after more than one year."
    ],
    formulae: ["Gross profit = Sales − Cost of sales", "Assets = Equity + Liabilities"],
    diagram: null
  },
  acc_analysis: {
    about: "Analysis and interpretation uses ratios and trends to assess liquidity, solvency, profitability and efficiency. Comparisons over time and against industry norms improve insight.",
    key_facts: [
      "Current ratio = Current assets ÷ Current liabilities (liquidity).",
      "Acid-test ratio excludes inventory from current assets.",
      "Gross profit percentage = Gross profit ÷ Sales × 100.",
      "Return on equity measures profit relative to owner's investment."
    ],
    formulae: [
      "Current ratio = Current assets / Current liabilities",
      "Gross profit % = Gross profit / Sales × 100",
      "Net profit % = Net profit / Sales × 100"
    ],
    diagram: null
  },
  acc_ethics: {
    about: "Ethics and internal control protect stakeholders. Integrity, objectivity and confidentiality guide professional conduct. Internal controls reduce error and fraud risk.",
    key_facts: [
      "Segregation of duties separates authorisation, custody and recording.",
      "Source documents and authorisation trails support accountability.",
      "GAAP and IFRS provide frameworks for fair presentation.",
      "Whistle-blowing and audit processes help detect misconduct."
    ],
    formulae: [],
    diagram: null
  },
  acc_companies: {
    about: "Companies are separate legal entities. Share capital, retained income, dividends and limited liability distinguish company accounting from sole traders and partnerships.",
    key_facts: [
      "Ordinary shares represent ownership; dividends are distributions of profit.",
      "Retained income accumulates undistributed profits.",
      "Directors manage the company on behalf of shareholders.",
      "Financial statements of companies follow formal presentation requirements."
    ],
    formulae: [],
    diagram: null
  },
  acc_costing: {
    about: "Cost accounting analyses manufacturing costs: direct materials, direct labour and manufacturing overhead. Prime cost and conversion cost support inventory valuation and pricing decisions.",
    key_facts: [
      "Prime cost = Direct materials + Direct labour.",
      "Conversion cost = Direct labour + Manufacturing overhead.",
      "Overheads may be allocated using predetermined rates.",
      "Unit cost supports pricing and inventory valuation."
    ],
    formulae: ["Prime cost = Direct materials + Direct labour", "Total manufacturing cost = Prime cost + Overhead"],
    diagram: null
  }
};

function defaultNote(topicId) {
  const name = String(topicId || "topic").replaceAll("_", " ");
  return {
    about: `CAPS topic: ${name}. Key ideas for this grade band.`,
    key_facts: [
      `Focus on the core definitions for ${name}.`,
      "Use diagrams and real-life examples when you revise.",
      "Practise short questions, then longer explanations."
    ],
    formulae: [],
    diagram: null
  };
}

const BANK = {

  acc_concepts: [
    ["State the basic accounting equation.", "Assets = Owner's equity + Liabilities", "Every transaction keeps this equation in balance."],
    ["Name the three elements of the accounting equation.", "Assets, owner's equity, liabilities", "Also written A = OE + L."],
    ["Does buying equipment with cash increase total assets?", "No", "One asset (equipment) increases; another (cash) decreases by the same amount."]
  ],
  acc_books: [
    ["Which journal records cash received from customers?", "Cash receipts journal", "Often abbreviated CRJ."],
    ["What supports entries in the books of first entry?", "Source documents", "Invoices, receipts, cheques, credit notes."],
    ["Which journal is used for non-routine adjustments?", "General journal", "Also used for error corrections."]
  ],
  acc_ledger: [
    ["What does a trial balance test?", "That total debits equal total credits", "It does not prove every entry is correct."],
    ["Do asset accounts normally have debit or credit balances?", "Debit", "Expenses also normally debit; equity, liabilities and income credit."],
    ["What is posting?", "Transferring journal entries to ledger accounts", "From books of first entry to the general ledger."]
  ],
  acc_debtors: [
    ["Who are debtors?", "Customers who owe the business", "Also called accounts receivable."],
    ["What is a bad debt?", "An amount that a debtor cannot pay", "It is written off as an expense."],
    ["What should the debtors control account equal?", "The sum of individual debtor balances", "It is a control total for the subsidiary ledger."]
  ],
  acc_bank: [
    ["What is an outstanding cheque?", "A cheque recorded in the cash book but not yet cleared by the bank", "It appears in the reconciliation as a deduction from the bank statement balance."],
    ["Where do bank charges usually appear first?", "On the bank statement", "They must then be entered in the cash book."],
    ["Why prepare a bank reconciliation?", "To explain differences between cash book and bank statement balances", "Timing differences and errors are identified."]
  ],
  acc_vat: [
    ["What is the standard VAT rate in South Africa?", "15%", "Applied to most taxable supplies."],
    ["How is VAT calculated on a VAT-exclusive amount?", "Multiply by 0.15 (or 15%)", "Inclusive amount × 15/115 extracts the VAT."],
    ["What is VAT payable to SARS?", "Output VAT minus Input VAT", "A negative result may mean a refund."]
  ],
  acc_inventory: [
    ["Give the formula for cost of sales (periodic system).", "Opening inventory + Purchases − Closing inventory", "Net purchases adjust for returns and carriage where applicable."],
    ["What does FIFO assume?", "Oldest goods are sold first", "Closing inventory reflects more recent costs."],
    ["Name two inventory systems.", "Periodic and perpetual", "Perpetual updates continuously; periodic updates at period end."]
  ],
  acc_financials: [
    ["How is gross profit calculated?", "Sales minus cost of sales", "Shown near the top of the income statement."],
    ["Which statement reports assets, equity and liabilities?", "Statement of financial position (balance sheet)", "It reflects the accounting equation."],
    ["Are current assets expected to be realised within 12 months?", "Yes", "Non-current assets are longer-term."]
  ],
  acc_analysis: [
    ["State the current ratio formula.", "Current assets ÷ Current liabilities", "A common liquidity measure."],
    ["How is gross profit percentage calculated?", "Gross profit ÷ Sales × 100", "Shows markup relative to sales."],
    ["What does the acid-test ratio exclude from current assets?", "Inventory", "It is a stricter liquidity test."]
  ],
  acc_ethics: [
    ["Name one purpose of internal control.", "To reduce error and fraud", "Also improves reliability of records."],
    ["What is segregation of duties?", "Separating authorisation, custody and recording", "No one person should control all steps of a transaction."],
    ["Why is professional ethics important in accounting?", "To protect stakeholders and maintain trust", "Integrity and objectivity are core principles."]
  ],
  acc_companies: [
    ["What do ordinary shares represent?", "Ownership in the company", "Shareholders may receive dividends."],
    ["What is retained income?", "Accumulated profits not distributed as dividends", "Part of equity on the statement of financial position."],
    ["Are companies separate legal entities?", "Yes", "They have limited liability distinct from their owners."]
  ],
  acc_costing: [
    ["What is prime cost?", "Direct materials + Direct labour", "Excludes manufacturing overhead."],
    ["Name the three main elements of manufacturing cost.", "Direct materials, direct labour, manufacturing overhead", "Together they form total manufacturing cost."],
    ["What is conversion cost?", "Direct labour + Manufacturing overhead", "Cost to convert materials into finished goods."]
  ],

  ls_cells: [
    ["What organelle contains the genetic material DNA?", "Nucleus", "The nucleus holds chromosomes made of DNA."],
    ["Name one organelle found in plant cells but not animal cells.", "Chloroplast", "Chloroplasts carry out photosynthesis. Cell wall is also valid."],
    ["What is the basic unit of life?", "Cell", "Cell theory states all living things are made of cells."]
  ],
  ls_genetics: [
    ["What is an alternative form of a gene called?", "Allele", "Alleles occupy the same locus on homologous chromosomes."],
    ["If an allele is always expressed when present, it is called…", "Dominant", "Recessive alleles are only expressed when homozygous."]
  ],
  ls_human: [
    ["Which organ pumps blood around the body?", "Heart", "The heart is a muscular pump in the circulatory system."],
    ["Which gas do we inhale for respiration?", "Oxygen", "Oxygen is used in cellular respiration; CO₂ is exhaled."]
  ],
  geo_mapwork: [
    ["What do contour lines join?", "Points of equal height", "Close contours mean steep slopes."],
    ["What does GIS stand for?", "Geographic Information System", "GIS layers spatial data for analysis."]
  ],
  geo_climate: [
    ["Is climate short-term or long-term weather patterns?", "Long-term", "Weather is day-to-day; climate is long-term average."],
    ["Name one factor that affects climate.", "Latitude", "Also altitude, ocean currents, distance from sea, winds."]
  ],
  geo_population: [
    ["What does a population pyramid show?", "Age and sex structure", "Wide base suggests high birth rates."],
    ["Birth rate minus death rate is called…", "Natural increase", "Migration also changes total population."]
  ],
  ns_life_living: [
    ["What is the first organism in a food chain called?", "Producer", "Producers make food by photosynthesis."],
    ["Name one thing a habitat must provide.", "Food", "Also water, shelter and space."]
  ],
  ns_matter_materials: [
    ["Name the three common states of matter.", "Solid, liquid, gas", "Plasma is a fourth state but less common in this grade."],
    ["Does a solid have a fixed shape?", "Yes", "Liquids take the shape of their container."]
  ],
  ns_energy_change: [
    ["Heat flows from … to … objects.", "Hot to cold", "Energy transfers from higher to lower temperature."],
    ["What must a circuit be for current to flow?", "Closed", "An open switch breaks the path."]
  ],
  ns_planet_earth: [
    ["How long does Earth take to rotate once?", "One day", "About 24 hours."],
    ["What causes the phases of the Moon?", "The Moon orbiting Earth", "We see different portions of the sunlit half."]
  ],
  tech_structures: [
    ["Which shape is especially strong in frames?", "Triangle", "Triangles resist changing shape under load."],
    ["What is a structure designed to do?", "Support loads", "It must be strong and stable."]
  ],
  tech_electrical: [
    ["Name three parts of a simple circuit.", "Source, path, load", "e.g. battery, wires, bulb."],
    ["What does a switch do?", "Opens or closes the circuit", "It controls whether current can flow."]
  ],
  tech_mechanical: [
    ["What is the pivot of a lever called?", "Fulcrum", "Load and effort positions determine mechanical advantage."],
    ["Gears can change speed and…", "Direction", "Meshed gears reverse rotation direction."]
  ],
  acc_concepts_def: [
    ["Define an asset.", "A resource controlled by the business from which future economic benefits are expected", "Examples: cash, inventory, equipment."],
    ["Define a liability.", "A present obligation of the business arising from past events", "Examples: creditors, loans."],
    ["State the dual-aspect concept.", "Every transaction has two effects that keep the accounting equation in balance", "Also called double-entry."]
  ],
  acc_books_def: [
    ["What is a source document?", "Evidence that a transaction occurred", "Invoice, receipt, cheque counterfoil, credit note."],
    ["Name the journal used for credit sales.", "Sales journal", "Also called the debtors journal in some texts."],
    ["Owner deposited capital into the business bank account. Which two accounts are affected?", "Bank and Capital", "Bank debited; Capital credited."]
  ],
  acc_ledger_def: [
    ["What is a trial balance?", "A list of ledger account balances to check that total debits equal total credits", "It does not prove accuracy of every entry."],
    ["On which side of a T-account do assets increase?", "Debit", "Assets and expenses increase on the debit side."],
    ["What is posting?", "Transferring amounts from journals to ledger accounts", "Each journal entry is posted to at least two accounts."]
  ],
  acc_vat_def: [
    ["Define output VAT.", "VAT charged by a vendor on taxable supplies (sales)", "Collected from customers."],
    ["Define input VAT.", "VAT paid by a vendor on taxable purchases", "Usually claimable from SARS."],
    ["Calculate VAT on a VAT-exclusive price of R200 at 15%.", "R30", "200 × 0.15 = 30."]
  ],
  acc_bank_def: [
    ["What is an outstanding deposit?", "An amount recorded in the cash book but not yet on the bank statement", "Added to the bank statement balance in the reconciliation."],
    ["Why might the cash book and bank statement balances differ?", "Timing differences and errors", "Outstanding cheques, deposits, bank charges, interest."]
  ],
  acc_financials_def: [
    ["Define gross profit.", "Sales minus cost of sales", "Shown near the top of the income statement."],
    ["Which statement reports assets, equity and liabilities?", "Statement of financial position", "Also called the balance sheet."]
  ],
  ls_cells_def: [
    ["Define a cell.", "The basic structural and functional unit of living organisms", "All living things are made of cells."],
    ["Name the organelle that contains DNA.", "Nucleus", "Controls cell activities."],
    ["Which organelle performs photosynthesis?", "Chloroplast", "Found in plant cells."]
  ],
  ls_human_def: [
    ["Name the organ that pumps blood.", "Heart", "Part of the circulatory system."],
    ["Where does most nutrient absorption occur?", "Small intestine", "Large surface area from villi."]
  ],
  geo_mapwork_def: [
    ["Define map scale.", "The ratio of a distance on the map to the corresponding distance on the ground", "May be a representative fraction."],
    ["What do contour lines join?", "Points of equal height above sea level", "Closer contours mean steeper slopes."],
    ["What does GIS stand for?", "Geographic Information System", "Layers of spatial data for analysis."]
  ],
  ns_planet_earth_def: [
    ["Name the planet third from the Sun.", "Earth", "Mercury, Venus, Earth, Mars."],
    ["What force keeps planets in orbit around the Sun?", "Gravity", "Attractive force between masses."],
    ["How long does Earth take to orbit the Sun once?", "One year", "About 365.25 days."]
  ],
  ns_life_living_def: [
    ["Define a habitat.", "The place where an organism lives", "Provides food, water, shelter and space."],
    ["What is a producer in a food chain?", "An organism that makes its own food", "Usually a green plant using photosynthesis."]
  ]
};

export class MultiSubjectEngine {
  constructor(subjectId = "life_sciences", grade = 8) {
    this.subjectId = subjectId || "life_sciences";
    this.grade = grade;
  }

  notesFor(topicId) {
    const id = String(topicId || "").replace(/_def$/, "");
    return NOTES[id] || defaultNote(id);
  }

  generate(topicId = null, difficulty = 2, opts = {}) {
    const concept = !!(opts && opts.concept);
    let candidates = Object.keys(BANK);
    if (topicId) {
      const base = String(topicId).replace(/_def$/, "");
      candidates = candidates.filter((id) => id === base || id === base + "_def" || id.startsWith(base + "_"));
      if (concept) {
        const defs = candidates.filter((id) => id.endsWith("_def"));
        if (defs.length) candidates = defs;
      } else {
        const practice = candidates.filter((id) => !id.endsWith("_def"));
        if (practice.length) candidates = practice;
      }
      if (!candidates.length) candidates = Object.keys(BANK).filter((id) => id.startsWith(base.split("_")[0]));
    } else if (concept) {
      const defs = candidates.filter((id) => id.endsWith("_def"));
      if (defs.length) candidates = defs;
    }
    candidates = candidates.filter((id) => BANK[id] && BANK[id].length);
    if (!candidates.length) candidates = Object.keys(BANK).filter((id) => BANK[id] && BANK[id].length);
    const tid = choice(candidates);
    const pool = BANK[tid];
    const [question, answer, explanation] = choice(pool);
    const baseTopic = tid.replace(/_def$/, "");
    const note = this.notesFor(baseTopic);
    let diagram = note.diagram || null;
    try {
      const recipeDiag = diagramForTopic(baseTopic, this.grade);
      if (recipeDiag) diagram = recipeDiag;
    } catch (_) {}
    if (baseTopic === "acc_books") diagram = recipe("journal_table", this.grade);
    else if (baseTopic === "acc_ledger" || baseTopic === "acc_debtors") diagram = recipe("t_account", this.grade, { account: baseTopic === "acc_debtors" ? "Debtors control" : "Bank" });
    else if (baseTopic === "acc_bank") diagram = recipe("bank_recon", this.grade);
    else if (baseTopic === "acc_concepts") diagram = recipe("accounting_equation", this.grade);
    else if (baseTopic === "acc_financials" || baseTopic === "acc_analysis") diagram = recipe("income_statement", this.grade);
    else if (baseTopic === "ns_planet_earth") diagram = recipe("solar_system", this.grade);
    else if (baseTopic === "ns_life_living") diagram = recipe("plant_structure", this.grade);
    else if (baseTopic === "ls_cells") diagram = recipe("cell_plant", this.grade);
    else if (baseTopic === "ls_human") diagram = recipe("organ_digestive", this.grade);
    return {
      id: `ms_${tid}_${ri(1000, 9999)}`,
      topic: baseTopic,
      topic_name: baseTopic.replaceAll("_", " "),
      subject: this.subjectId,
      question,
      answer,
      explanation: explanation || "",
      diagram,
      difficulty,
      marks: 2,
      mode: concept ? "concept" : "practice"
    };
  }

  generateConcept(topicId = null, difficulty = 2) {
    return this.generate(topicId, difficulty, { concept: true });
  }
}

export function isMultiSubjectTopic(id) {
  const s = String(id || "");
  return /^(ls_|geo_|ns_|tech_|acc_)/.test(s);
}
