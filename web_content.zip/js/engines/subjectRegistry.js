/**
 * learnyZ — CAPS subject availability by grade.
 */
const _cache = new Map();
async function fetchJson(path) {
  if (_cache.has(path)) return _cache.get(path);
  try {
    const res = await fetch(path);
    if (!res.ok) { _cache.set(path, null); return null; }
    const data = await res.json();
    _cache.set(path, data);
    return data;
  } catch { _cache.set(path, null); return null; }
}

let _map = null;
let _topics = null;

export async function loadSubjectRegistry() {
  if (!_map) {
    _map = (await fetchJson("./content/subjects_by_grade.json")) || { subjects: {}, labels: {} };
  }
  if (!_topics) {
    _topics = (await fetchJson("./content/subject_topics.json")) || {};
  }
  return _map;
}

export function subjectsForGrade(grade) {
  const g = String(grade ?? 5);
  const list = (_map && _map.subjects && _map.subjects[g]) || ["maths"];
  return list;
}

export function subjectLabel(id) {
  return (_map && _map.labels && _map.labels[id]) || id;
}

export function topicsForSubject(subjectId) {
  if (subjectId === "maths" || subjectId === "physical_sciences") return null;
  const all = _topics || {};
  if (subjectId === "natural_sciences_technology") return all.natural_sciences_technology || [];
  if (subjectId === "natural_sciences") return all.natural_sciences || [];
  if (subjectId === "technology") return all.technology || [];
  if (subjectId === "life_sciences") return all.life_sciences || [];
  if (subjectId === "geography") return all.geography || [];
  return [];
}

export function defaultSubject(grade) {
  const list = subjectsForGrade(grade);
  return list[0] || "maths";
}

export function subjectChipLabel(id) {
  const map = {
    maths: "📘 Maths",
    physical_sciences: "🔬 Physical Sciences",
    life_sciences: "🧬 Life Sciences",
    geography: "🗺️ Geography",
    natural_sciences_technology: "🔭 NS & Tech",
    natural_sciences: "🔭 Natural Sciences",
    technology: "⚙️ Technology"
  };
  return map[id] || subjectLabel(id);
}
