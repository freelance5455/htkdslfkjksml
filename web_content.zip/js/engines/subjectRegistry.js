/**
 * Learnly Grade 10 — CAPS subject availability.
 */
const _cache = new Map();
async function fetchJson(path) {
  if (_cache.has(path)) return _cache.get(path);
  try {
    const res = await fetch(path);
    if (!res.ok) { _cache.set(path, null); return null; }
    const data = await res.json();
    _cache.set(path, data);
    return data;
  } catch { _cache.set(path, null); return null; }
}

let _map = null;
let _topics = null;

export async function loadSubjectRegistry() {
  if (!_map) {
    _map = (await fetchJson("./content/subjects_by_grade.json")) || { subjects: {}, labels: {} };
  }
  if (!_topics) {
    _topics = (await fetchJson("./content/subject_topics.json")) || {};
  }
  return _map;
}

export function subjectsForGrade(grade) {
  const g = String(grade ?? 10);
  const list = (_map && _map.subjects && _map.subjects[g]) || ["mathematical_literacy"];
  return list;
}

export function subjectLabel(id) {
  return (_map && _map.labels && _map.labels[id]) || id;
}

export function topicsForSubject(subjectId) {
  const all = _topics || {};
  if (subjectId === "mathematical_literacy") return all.mathematical_literacy || [];
  if (subjectId === "business_studies") return all.business_studies || [];
  if (subjectId === "tourism") return all.tourism || [];
  return [];
}

export function defaultSubject(grade) {
  const list = subjectsForGrade(grade);
  return list[0] || "mathematical_literacy";
}

export function subjectChipLabel(id) {
  const map = {
    mathematical_literacy: "📐 Math Literacy",
    business_studies: "💼 Business Studies",
    tourism: "✈️ Tourism"
  };
  return map[id] || subjectLabel(id);
}
