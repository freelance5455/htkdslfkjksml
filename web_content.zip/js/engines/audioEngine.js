/**
 * Lightweight audio: procedural ambient music + short SFX via Web Audio API.
 * No external files required. Respects settings.sound and settings.music.
 */
let ctx = null;
let musicNodes = null;
let musicOn = false;
let sfxEnabled = true;
let musicEnabled = false;

function ensureCtx() {
  if (ctx) return ctx;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  ctx = new AC();
  return ctx;
}

export function setSfxEnabled(on) {
  sfxEnabled = !!on;
}

export function setMusicEnabled(on) {
  musicEnabled = !!on;
  if (!musicEnabled) stopMusic();
  else if (!musicOn) startMusic();
}

export function isMusicPlaying() {
  return musicOn;
}

/** Soft pentatonic ambient pad — very small CPU footprint */
export function startMusic() {
  if (!musicEnabled) return;
  const c = ensureCtx();
  if (!c || musicOn) return;
  if (c.state === "suspended") c.resume().catch(() => {});

  const master = c.createGain();
  master.gain.value = 0.04; // quiet background
  master.connect(c.destination);

  const notes = [196.0, 220.0, 246.94, 293.66, 329.63]; // G A B D E
  const oscs = [];
  notes.forEach((freq, i) => {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = i % 2 === 0 ? "sine" : "triangle";
    o.frequency.value = freq;
    g.gain.value = 0.15 + (i % 3) * 0.05;
    // slow LFO on amplitude
    const lfo = c.createOscillator();
    const lfoG = c.createGain();
    lfo.frequency.value = 0.05 + i * 0.02;
    lfoG.gain.value = 0.08;
    lfo.connect(lfoG);
    lfoG.connect(g.gain);
    o.connect(g);
    g.connect(master);
    o.start();
    lfo.start();
    oscs.push(o, lfo);
  });

  // gentle filter
  const filter = c.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 800;
  master.disconnect();
  master.connect(filter);
  filter.connect(c.destination);

  musicNodes = { master, filter, oscs };
  musicOn = true;
}

export function stopMusic() {
  if (!musicNodes) {
    musicOn = false;
    return;
  }
  try {
    musicNodes.oscs.forEach((o) => {
      try { o.stop(); } catch { /* already stopped */ }
    });
    musicNodes.master.disconnect();
    musicNodes.filter.disconnect();
  } catch { /* ignore */ }
  musicNodes = null;
  musicOn = false;
}

export function toggleMusic() {
  if (musicOn) {
    stopMusic();
    musicEnabled = false;
  } else {
    musicEnabled = true;
    startMusic();
  }
  return musicOn;
}

/** Short UI sounds */
export function playSfx(type = "tap") {
  if (!sfxEnabled) return;
  const c = ensureCtx();
  if (!c) return;
  if (c.state === "suspended") c.resume().catch(() => {});

  const o = c.createOscillator();
  const g = c.createGain();
  o.connect(g);
  g.connect(c.destination);
  const now = c.currentTime;

  if (type === "correct") {
    o.frequency.setValueAtTime(523.25, now);
    o.frequency.setValueAtTime(659.25, now + 0.08);
    o.frequency.setValueAtTime(783.99, now + 0.16);
    g.gain.setValueAtTime(0.2, now);
    g.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
    o.start(now);
    o.stop(now + 0.35);
  } else if (type === "wrong") {
    o.type = "square";
    o.frequency.setValueAtTime(180, now);
    o.frequency.linearRampToValueAtTime(90, now + 0.2);
    g.gain.setValueAtTime(0.12, now);
    g.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
    o.start(now);
    o.stop(now + 0.25);
  } else if (type === "hint") {
    o.frequency.setValueAtTime(440, now);
    g.gain.setValueAtTime(0.1, now);
    g.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
    o.start(now);
    o.stop(now + 0.15);
  } else {
    o.frequency.setValueAtTime(600, now);
    g.gain.setValueAtTime(0.06, now);
    g.gain.exponentialRampToValueAtTime(0.01, now + 0.08);
    o.start(now);
    o.stop(now + 0.08);
  }
}

/** Apply from student settings object */
export function syncFromSettings(settings = {}) {
  setSfxEnabled(settings.sound !== false);
  setMusicEnabled(settings.music === true);
}
