// Port of engine/content_loader.py + engine/science_engine.py + engine/quiz_engine.py.
// Fetch-based with an in-memory cache in place of Python's @lru_cache over local files.
const _cache = new Map();
async function fetchJson(path) {
  if (_cache.has(path)) return _cache.get(path);
  try {
    const res = await fetch(path);
    if (!res.ok) { _cache.set(path, null); return null; }
    const data = await res.json();
    _cache.set(path, data);
    return data;
  } catch { _cache.set(path, null); return null; }
}

// ---------------- Grade 8 Mathematics deep notes ----------------
export async function loadCurriculum() { return (await fetchJson("./content/grade8/curriculum.json")) || {}; }
export async function loadTopicNotes(topicId) { return fetchJson(`./content/grade8/topics/${topicId}.json`); }
export async function loadTopicNotesForGrade(grade, topicId) {
  // Prefer grade-specific notes; fall back to grade8 shared senior notes for grades 7–9
  const primary = await fetchJson(`./content/grade${grade}/topics/${topicId}.json`);
  if (primary) return primary;
  if (grade === 7 || grade === 9) {
    return fetchJson(`./content/grade8/topics/${topicId}.json`);
  }
  return null;
}

export async function allTopics() { const c = await loadCurriculum(); return c.topics || []; }
export async function topicName(topicId) { const t = (await allTopics()).find((x) => x.id === topicId); return t ? t.name : topicId.replaceAll("_", " "); }
export async function topicIcon(topicId) { const t = (await allTopics()).find((x) => x.id === topicId); return t ? t.icon || "📘" : "📘"; }
export async function topicsForTerm(term) { return (await allTopics()).filter((t) => t.term === +term); }

// ---------------- Grade 8 Natural Sciences ----------------
export async function loadScienceCurriculum() { return (await fetchJson("./content/grade8/science/curriculum.json")) || { topics: [] }; }
export async function loadScienceTopic(topicId) { return fetchJson(`./content/grade8/science/${topicId}.json`); }
export async function allScienceTopics() { const c = await loadScienceCurriculum(); return c.topics || []; }

// ---------------- Tips & Tricks library ----------------
export async function loadTips() { return (await fetchJson("./content/tips_and_tricks.json")) || { categories: [] }; }

// ---------------- Definitions Quiz: builds MC questions from key_vocabulary ----------------
function parseVocabEntry(entry) {
  let sep = entry.includes("—") ? "—" : entry.includes("-") ? "-" : null;
  if (!sep) return null;
  const idx = entry.indexOf(sep);
  return [entry.slice(0, idx).trim(), entry.slice(idx + 1).trim()];
}

async function collectTerms(subject) {
  const terms = [];
  if (subject === "math") {
    for (const t of await allTopics()) {
      const data = await loadTopicNotes(t.id);
      if (!data) continue;
      for (const entry of data.key_vocabulary || []) {
        const parsed = parseVocabEntry(entry);
        if (parsed) terms.push({ term: parsed[0], definition: parsed[1], topic: data.name });
      }
    }
  } else {
    for (const t of await allScienceTopics()) {
      const data = await loadScienceTopic(t.id);
      if (!data) continue;
      for (const entry of data.key_vocabulary || []) {
        const parsed = parseVocabEntry(entry);
        if (parsed) terms.push({ term: parsed[0], definition: parsed[1], topic: data.name });
      }
    }
  }
  return terms;
}

export async function generateDefinitionsQuiz(subject = "math") {
  const terms = await collectTerms(subject);
  if (terms.length < 4) return null;
  const correct = terms[Math.floor(Math.random() * terms.length)];
  const others = terms.filter((t) => t.term !== correct.term).map((t) => t.term);
  const shuffled = [...others].sort(() => Math.random() - 0.5);
  const distractors = shuffled.slice(0, Math.min(3, others.length));
  const options = [...distractors, correct.term].sort(() => Math.random() - 0.5);
  return { question: `Which term matches this definition?\n\n"${correct.definition}"`, options, answer: correct.term, topic: correct.topic };
}

export async function loadPhysSciCurriculum() {
  return (await fetchJson("./content/grade11/physical_sciences/curriculum.json")) || { topics: [] };
}
export async function loadPhysSciTopic(topicId) {
  return fetchJson(`./content/grade11/physical_sciences/${topicId}.json`);
}
export async function allPhysSciTopics() {
  const c = await loadPhysSciCurriculum();
  return c.topics || [];
}
