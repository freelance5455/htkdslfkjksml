/**
 * learnyZ — fillable worksheets: journals, T-accounts, trial balances,
 * data tables, and label-the-diagram tasks (CAPS school style).
 */
import { recipe, diagramForTopic } from "./diagramEngine.js";

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function money(n) {
  return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

/** CAPS-style General Journal practice */
function genJournal(grade = 11) {
  const capital = ri(8, 25) * 1000;
  const purchases = ri(5, 18) * 100;
  const sales = ri(4, 15) * 100;
  const rent = ri(3, 12) * 100;
  const rows = [
    { date: "01 Mar", details: "Bank", fol: "B1", debit: money(capital), credit: "", blank: false },
    { date: "", details: "Capital", fol: "B2", debit: "", credit: money(capital), blank: false },
    { date: "03 Mar", details: "Purchases", fol: "B3", debit: money(purchases), credit: "", blank: true, key: money(purchases), keyField: "debit" },
    { date: "", details: "Bank", fol: "B1", debit: "", credit: money(purchases), blank: true, key: money(purchases), keyField: "credit" },
    { date: "05 Mar", details: "Bank", fol: "B1", debit: money(sales), credit: "", blank: false },
    { date: "", details: "Sales", fol: "B4", debit: "", credit: money(sales), blank: true, key: money(sales), keyField: "credit" },
    { date: "10 Mar", details: "Rent expense", fol: "B5", debit: money(rent), credit: "", blank: true, key: money(rent), keyField: "debit" },
    { date: "", details: "Bank", fol: "B1", debit: "", credit: money(rent), blank: false }
  ];
  return {
    type: "journal",
    title: "General Journal — complete the blank cells",
    narrative: "Owner started business with a capital deposit. Goods were purchased for cash, cash sales were made, and rent was paid. Fill in the missing debit/credit amounts.",
    cols: ["Date", "Details", "Fol", "Debit (R)", "Credit (R)"],
    rows,
    marks: 6,
    topic: "acc_books"
  };
}

function genTAccount(grade = 11) {
  const open = ri(20, 50) * 100;
  const sales = ri(8, 20) * 100;
  const purch = ri(5, 15) * 100;
  const rent = ri(3, 9) * 100;
  const debit = [
    { label: "Balance b/d", amount: money(open), blank: false },
    { label: "Sales", amount: money(sales), blank: true, key: money(sales) },
  ];
  const credit = [
    { label: "Purchases", amount: money(purch), blank: true, key: money(purch) },
    { label: "Rent", amount: money(rent), blank: false },
  ];
  const bal = open + sales - purch - rent;
  return {
    type: "t_account",
    title: "Bank account — complete missing amounts",
    narrative: "Complete the Bank T-account. Opening balance and rent are given.",
    account: "Bank",
    debit,
    credit,
    closing: money(bal),
    marks: 4,
    topic: "acc_ledger"
  };
}

function genTrialBalance(grade = 11) {
  const bank = ri(30, 80) * 100;
  const capital = ri(50, 120) * 100;
  const purch = ri(10, 40) * 100;
  const sales = ri(15, 50) * 100;
  const rent = capital + sales - bank - purch; // force balance if rent is the plug — better fixed set
  // balanced set
  const c = 50000, b = 32000, p = 12000, s = 18000, r = 4000, draw = 8000;
  // A: bank 32k + purch 12k + rent 4k + drawings 8k = 56k; capital 50k + sales 18k = 68k — adjust
  const rows = [
    { account: "Bank", debit: money(25000), credit: "", blank: false },
    { account: "Capital", debit: "", credit: money(40000), blank: false },
    { account: "Purchases", debit: money(15000), credit: "", blank: true, key: money(15000), keyField: "debit" },
    { account: "Sales", debit: "", credit: money(12000), blank: true, key: money(12000), keyField: "credit" },
    { account: "Rent expense", debit: money(3000), credit: "", blank: false },
    { account: "Drawings", debit: money(9000), credit: "", blank: true, key: money(9000), keyField: "debit" }
  ];
  // 25+15+3+9=52; 40+12=52
  return {
    type: "trial_balance",
    title: "Trial balance — fill missing balances",
    narrative: "Complete the trial balance so that total debits equal total credits.",
    cols: ["Account", "Debit (R)", "Credit (R)"],
    rows,
    marks: 4,
    topic: "acc_ledger"
  };
}

function genBankRecon(grade = 11) {
  const stmt = ri(70, 120) * 100;
  const dep = ri(8, 20) * 100;
  const chq = ri(5, 15) * 100;
  const book = stmt + dep - chq;
  return {
    type: "bank_recon",
    title: "Bank reconciliation — complete the blanks",
    narrative: "Balance per bank statement is given. Complete outstanding items and cash book balance.",
    cols: ["Details", "Amount (R)"],
    rows: [
      { details: "Balance per bank statement", amount: money(stmt), blank: false },
      { details: "Add: Outstanding deposit", amount: money(dep), blank: true, key: money(dep) },
      { details: "Less: Outstanding cheques", amount: "(" + money(chq) + ")", blank: true, key: "(" + money(chq) + ")" },
      { details: "Balance per cash book", amount: money(book), blank: true, key: money(book) }
    ],
    marks: 4,
    topic: "acc_bank"
  };
}

/** Label-the-diagram: blanks for CAPS school diagrams */
function genLabelDiagram(subjectId, topicId, grade = 8) {
  const packs = {
    ls_cells: {
      diagram: recipe("cell_plant", grade),
      labels: [
        { id: "wall", prompt: "Outer rigid layer", key: "cell wall" },
        { id: "nuc", prompt: "Controls the cell / contains DNA", key: "nucleus" },
        { id: "chl", prompt: "Site of photosynthesis", key: "chloroplast" },
        { id: "vac", prompt: "Large fluid-filled space", key: "vacuole" }
      ],
      narrative: "Label the plant cell structures."
    },
    ls_human: {
      diagram: recipe("organ_digestive", grade),
      labels: [
        { id: "mouth", prompt: "Where digestion begins", key: "mouth" },
        { id: "stom", prompt: "Muscular sac that churns food", key: "stomach" },
        { id: "si", prompt: "Main site of nutrient absorption", key: "small intestine" }
      ],
      narrative: "Label the digestive system organs shown."
    },
    ns_planet_earth: {
      diagram: recipe("solar_system", grade),
      labels: [
        { id: "star", prompt: "The star at the centre", key: "sun" },
        { id: "third", prompt: "Third planet from the Sun", key: "earth" },
        { id: "force", prompt: "Force that keeps planets in orbit", key: "gravity" }
      ],
      narrative: "Answer using the solar system diagram."
    },
    ns_life_living: {
      diagram: recipe("plant_structure", grade),
      labels: [
        { id: "r", prompt: "Anchors the plant and absorbs water", key: "roots" },
        { id: "s", prompt: "Supports leaves and transports materials", key: "stem" },
        { id: "l", prompt: "Main site of photosynthesis", key: "leaf" }
      ],
      narrative: "Label the parts of the plant."
    },
    acc_concepts: {
      diagram: recipe("accounting_equation", grade, { assets: 12000, liabilities: 4000, equity: 8000 }),
      labels: [
        { id: "eq", prompt: "State the accounting equation", key: "assets = owner's equity + liabilities" },
        { id: "a", prompt: "Name one example of an asset", key: "cash" }
      ],
      narrative: "Use the diagram of the accounting equation."
    },
    tech_mechanical: {
      diagram: recipe("lever", grade),
      labels: [
        { id: "f", prompt: "Name of the pivot point", key: "fulcrum" },
        { id: "e", prompt: "Force applied to move the load", key: "effort" }
      ],
      narrative: "Label the lever diagram."
    }
  };
  const key = topicId && packs[topicId] ? topicId : choice(Object.keys(packs));
  const pack = packs[key];
  return {
    type: "label_diagram",
    title: "Label the diagram",
    narrative: pack.narrative,
    diagram: pack.diagram,
    labels: pack.labels,
    marks: pack.labels.length * 2,
    topic: key
  };
}


const DEF_BANKS = {
  accounting: [
    ["Asset", "Resource controlled by the business expected to give future economic benefits"],
    ["Liability", "Present obligation arising from past events"],
    ["Owner's equity", "Owner's interest in the net assets of the business"],
    ["Source document", "Evidence that a transaction occurred"],
    ["Trial balance", "List of ledger balances to test debits equal credits"],
    ["Gross profit", "Sales minus cost of sales"],
    ["Output VAT", "VAT charged on taxable supplies (sales)"],
    ["Input VAT", "VAT paid on taxable purchases"],
    ["Depreciation", "Allocation of the cost of a fixed asset over its useful life"],
    ["Bank reconciliation", "Statement explaining differences between cash book and bank statement"]
  ],
  life_sciences: [
    ["Cell", "Basic structural and functional unit of living organisms"],
    ["Nucleus", "Organelle that contains DNA and controls the cell"],
    ["Chloroplast", "Organelle where photosynthesis takes place"],
    ["Mitochondrion", "Organelle where cellular respiration releases energy"],
    ["Photosynthesis", "Process by which plants make food using light energy"],
    ["Habitat", "Place where an organism lives"]
  ],
  natural_sciences: [
    ["Gravity", "Force of attraction between masses"],
    ["Habitat", "Place where an organism lives"],
    ["Producer", "Organism that makes its own food"],
    ["Circuit", "Closed path through which electric current can flow"],
    ["Evaporation", "Change of liquid to gas at the surface"]
  ],
  geography: [
    ["Scale", "Ratio of map distance to ground distance"],
    ["Contour line", "Line joining points of equal height"],
    ["GIS", "Geographic Information System"],
    ["Climate", "Long-term average of weather patterns"]
  ],
  technology: [
    ["Fulcrum", "Pivot point of a lever"],
    ["Effort", "Force applied to a machine"],
    ["Load", "Object or resistance being moved"],
    ["Structure", "Arrangement that supports loads"]
  ]
};

function genMatchDefinitions(subjectId) {
  const key = subjectId === "natural_sciences_technology" ? "natural_sciences"
    : (DEF_BANKS[subjectId] ? subjectId : "accounting");
  const pool = DEF_BANKS[key] || DEF_BANKS.accounting;
  const shuffled = pool.slice().sort(() => Math.random() - 0.5).slice(0, Math.min(5, pool.length));
  const defs = shuffled.map((x) => x[1]).sort(() => Math.random() - 0.5);
  return {
    type: "match_definitions",
    title: "Match terms with definitions",
    narrative: "Write the letter of the correct definition next to each term.",
    terms: shuffled.map((x, i) => ({ term: x[0], key: String.fromCharCode(65 + defs.indexOf(x[1])) })),
    definitions: defs.map((d, i) => ({ letter: String.fromCharCode(65 + i), text: d })),
    marks: shuffled.length * 2,
    topic: "definitions"
  };
}

/** CAPS paper-style multi-part accounting problem */
function genPaperStyle(grade = 11) {
  const capital = [15000, 20000, 25000, 30000][ri(0, 3)];
  const purch = [1200, 1500, 1800, 2000][ri(0, 3)];
  const sales = [800, 1000, 1200, 1500][ri(0, 3)];
  const rent = [500, 600, 750, 900][ri(0, 3)];
  const bankEnd = capital - purch + sales - rent;
  return {
    type: "paper_style",
    title: "QUESTION — Accounting equation & journals",
    narrative: `The following transactions relate to Mbeki Traders for March 2025:\n1. Owner deposited R${money(capital)} capital into the business bank account.\n2. Purchased goods for R${money(purch)} cash.\n3. Cash sales R${money(sales)}.\n4. Paid rent R${money(rent)} by EFT.\n\nREQUIRED:`,
    parts: [
      {
        id: "1.1",
        prompt: "1.1 Complete the effect on the accounting equation for transaction 1 (Capital deposit). Show Assets, Equity, Liabilities.",
        key: `+${money(capital)} | +${money(capital)} | 0`,
        hint: "Bank increases; Capital increases."
      },
      {
        id: "1.2",
        prompt: "1.2 Name the journal in which transaction 2 (cash purchases) is recorded.",
        key: "Cash payments journal",
        hint: "Also called CPJ."
      },
      {
        id: "1.3",
        prompt: `1.3 Calculate the bank balance after all four transactions.`,
        key: money(bankEnd),
        hint: `Start ${money(capital)} − purchases + sales − rent.`
      },
      {
        id: "1.4",
        prompt: "1.4 State whether rent is an asset, liability, income or expense.",
        key: "Expense",
        hint: "Operating cost that reduces profit."
      }
    ],
    marks: 10,
    topic: "acc_concepts"
  };
}

function genPaperVAT(grade = 11) {
  const excl = [200, 400, 500, 1000][ri(0, 3)];
  const vat = Math.round(excl * 0.15);
  const incl = excl + vat;
  return {
    type: "paper_style",
    title: "QUESTION — VAT calculations",
    narrative: `A registered VAT vendor sold goods with a VAT-exclusive price of R${money(excl)}. VAT rate is 15%.\n\nREQUIRED:`,
    parts: [
      { id: "2.1", prompt: "2.1 Calculate the VAT amount.", key: money(vat), hint: "Exclusive × 15%." },
      { id: "2.2", prompt: "2.2 Calculate the VAT-inclusive selling price.", key: money(incl), hint: "Exclusive + VAT." },
      { id: "2.3", prompt: "2.3 Is this output VAT or input VAT for the vendor?", key: "Output VAT", hint: "VAT on sales." }
    ],
    marks: 6,
    topic: "acc_vat"
  };
}

function genPaperRecon(grade = 11) {
  const stmt = [7000, 8500, 9200][ri(0, 2)];
  const dep = [800, 1200, 1500][ri(0, 2)];
  const chq = [450, 600, 900][ri(0, 2)];
  const book = stmt + dep - chq;
  return {
    type: "paper_style",
    title: "QUESTION — Bank reconciliation",
    narrative: `Balance per bank statement on 31 March 2025: R${money(stmt)}.\nOutstanding deposit: R${money(dep)}.\nOutstanding cheque: R${money(chq)}.\nNo errors in the cash book.\n\nREQUIRED:`,
    parts: [
      { id: "3.1", prompt: "3.1 Calculate the balance per cash book.", key: money(book), hint: "Statement + outstanding deposit − outstanding cheque." },
      { id: "3.2", prompt: "3.2 What is an outstanding cheque?", key: "A cheque recorded in the cash book but not yet presented at the bank", hint: "Timing difference." },
      { id: "3.3", prompt: "3.3 Give one reason why the cash book and bank statement balances may differ.", key: "Timing differences", hint: "Or bank charges, errors, direct deposits." }
    ],
    marks: 8,
    topic: "acc_bank"
  };
}

export class WorksheetEngine {
  constructor(subjectId = "accounting", grade = 11) {
    this.subjectId = subjectId;
    this.grade = grade;
  }

  generate(topicId = null, mode = null) {
    if (mode === "match" || topicId === "definitions") {
      return genMatchDefinitions(this.subjectId);
    }
    if (mode === "paper" || (this.subjectId === "accounting" && mode === "exam")) {
      return choice([genPaperStyle, genPaperVAT, genPaperRecon])(this.grade);
    }
    const tid = topicId ? String(topicId) : null;
    if (tid && /^(ls_|ns_|geo_|tech_)/.test(tid)) {
      return genLabelDiagram(this.subjectId, tid, this.grade);
    }
    if (this.subjectId === "accounting" || (tid && tid.startsWith("acc_"))) {
      const roll = Math.random();
      if (roll < 0.25) return choice([genPaperStyle, genPaperVAT, genPaperRecon])(this.grade);
      const t = tid || choice(["acc_books", "acc_ledger", "acc_bank", "acc_concepts"]);
      if (t === "acc_books" || t === "acc_inventory") return genJournal(this.grade);
      if (t === "acc_vat") return choice([genJournal, genPaperVAT])(this.grade);
      if (t === "acc_ledger" || t === "acc_debtors") return Math.random() < 0.5 ? genTAccount(this.grade) : genTrialBalance(this.grade);
      if (t === "acc_bank") return Math.random() < 0.5 ? genBankRecon(this.grade) : genPaperRecon(this.grade);
      if (t === "acc_concepts" || t === "acc_financials" || t === "acc_analysis") {
        return Math.random() < 0.5 ? genPaperStyle(this.grade) : genLabelDiagram("accounting", "acc_concepts", this.grade);
      }
      return genJournal(this.grade);
    }
    if (Math.random() < 0.35) return genMatchDefinitions(this.subjectId);
    return genLabelDiagram(this.subjectId, tid, this.grade);
  }

  generateMatch() { return this.generate(null, "match"); }
  generatePaper() { return this.generate(null, "paper"); }
}

export function isWorksheetTopic(id) {
  return /^(acc_|ls_|ns_|tech_|geo_)/.test(String(id || ""));
}
