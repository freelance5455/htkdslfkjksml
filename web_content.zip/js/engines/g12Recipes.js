/**
 * Grade 12 CAPS problem recipes — multiple distinct problem TYPES per topic.
 * Engines shuffle across types (not only values of one template).
 * Inspired by CAPS exam structures and open textbook patterns.
 */

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function round2(n) { return Math.round(n * 100) / 100; }

function Q(topic, question, answer, difficulty, hint, explanation, marks = 3, diagram = null) {
  return {
    id: `g12_${topic}_${ri(10000, 99999)}`,
    topic,
    topic_name: topic.replaceAll("_", " "),
    question,
    answer: String(answer),
    difficulty,
    hint: hint || "",
    explanation: explanation || "",
    marks,
    diagram,
    recipe: true
  };
}

/** Rotate through recipe types so consecutive generates differ in structure. */
const _lastType = new Map();
function pickType(topic, types) {
  if (!types.length) return null;
  const last = _lastType.get(topic);
  let pool = types;
  if (types.length > 1 && last != null) {
    pool = types.filter((_, i) => i !== last);
    if (!pool.length) pool = types;
  }
  const t = choice(pool);
  _lastType.set(topic, types.indexOf(t));
  return t;
}

// ── Mathematics recipe banks (many types each) ──────────────────────────

const MATHS = {
  sequences_series: [
    (d) => {
      const a = ri(2, 9), r = choice([2, 3, -2]);
      const n = ri(4, 7);
      const terms = [a];
      for (let i = 1; i < 4; i++) terms.push(terms[i - 1] * r);
      return Q("sequences_series",
        `Given the geometric sequence: ${terms.join("; ")}; …\nDetermine the ${n}th term.`,
        a * (r ** (n - 1)), d,
        "T_n = a·r^{n−1}",
        `a = ${a}, r = ${r}\nT_${n} = ${a}·(${r})^{${n - 1}} = ${a * (r ** (n - 1))}`, 3);
    },
    (d) => {
      const a = ri(3, 12), diff = ri(2, 7);
      const n = ri(8, 15);
      return Q("sequences_series",
        `Arithmetic sequence: first term ${a}, common difference ${diff}.\nFind T_${n}.`,
        a + (n - 1) * diff, d,
        "T_n = a + (n−1)d",
        `T_${n} = ${a} + (${n}−1)(${diff}) = ${a + (n - 1) * diff}`, 2);
    },
    (d) => {
      const a = ri(2, 6), r = 2, n = ri(5, 8);
      const s = a * ((r ** n) - 1) / (r - 1);
      return Q("sequences_series",
        `Sum the first ${n} terms of the geometric series with a = ${a} and r = ${r}.`,
        s, d,
        "S_n = a(r^n − 1)/(r − 1) for r ≠ 1",
        `S_${n} = ${a}(${r}^${n} − 1)/(${r} − 1) = ${s}`, 4);
    },
    (d) => {
      const a = ri(5, 20), dlt = ri(3, 9), n = ri(10, 20);
      const s = (n / 2) * (2 * a + (n - 1) * dlt);
      return Q("sequences_series",
        `Find S_${n} for the AP with a = ${a} and d = ${dlt}.`,
        s, d,
        "S_n = n/2 [2a + (n−1)d]",
        `S_${n} = ${n}/2 [2(${a}) + (${n}−1)(${dlt})] = ${s}`, 3);
    },
    (d) => {
      const a = ri(2, 5);
      return Q("sequences_series",
        `For the infinite geometric series with a = ${a} and r = 1/2, determine S_∞.`,
        2 * a, d,
        "S_∞ = a/(1−r) when |r| < 1",
        `S_∞ = ${a}/(1 − 1/2) = ${2 * a}`, 3);
    },
    (d) => {
      const a = ri(1, 4), dlt = ri(2, 5);
      return Q("sequences_series",
        `Which term of the sequence ${a}; ${a + dlt}; ${a + 2 * dlt}; … is equal to ${a + 9 * dlt}?`,
        10, d,
        "Set T_n = target and solve for n.",
        `a+(n−1)d = ${a + 9 * dlt} → (n−1)${dlt} = ${9 * dlt} → n = 10`, 3);
    },
    (d) => {
      return Q("sequences_series",
        "Prove that the sequence defined by T_n = 3n − 1 is arithmetic and state the common difference.",
        "d = 3", d,
        "Show T_{n+1} − T_n is constant.",
        "T_{n+1} − T_n = (3(n+1)−1) − (3n−1) = 3. Common difference d = 3.", 4);
    },
    (d) => {
      const a = 5, r = 0.4;
      return Q("sequences_series",
        `A ball drops from 5 m and rebounds to 40% of its previous height each time.\nFind the total distance travelled before it comes to rest (infinite series).`,
        round2(5 + 2 * 5 * 0.4 / (1 - 0.4)), d,
        "Down + 2 × infinite rebound series.",
        "First drop 5 m; then 2·S_∞ of a=2, r=0.4 → total ≈ " + round2(5 + 2 * 5 * 0.4 / 0.6), 5);
    }
  ],

  functions_graphs: [
    (d) => {
      const a = ri(1, 4), q = ri(-5, 5);
      return Q("functions_graphs",
        `For f(x) = ${a}/x + ${q}, state the equations of the asymptotes.`,
        `x = 0; y = ${q}`, d,
        "Vertical asymptote where denominator is 0; horizontal is y = q.",
        `Vertical: x = 0. Horizontal: y = ${q}.`, 2);
    },
    (d) => {
      const a = -1, p = ri(1, 3), q = ri(-2, 2);
      return Q("functions_graphs",
        `f(x) = −(x − ${p})² + ${q}. Determine the turning point and the range.`,
        `TP (${p}; ${q}); y ≤ ${q}`, d,
        "Vertex form y = a(x−p)² + q.",
        `Turning point (${p}; ${q}). Since a < 0, range y ≤ ${q}.`, 3);
    },
    (d) => {
      const k = ri(2, 5);
      return Q("functions_graphs",
        `Solve for x if 2^x = ${2 ** k}.`,
        k, d,
        "Express both sides with the same base.",
        `2^x = 2^${k} → x = ${k}`, 2);
    },
    (d) => {
      return Q("functions_graphs",
        "Sketch y = log_2(x). State the domain and the equation of the asymptote.",
        "Domain x > 0; asymptote x = 0", d,
        "Log is only defined for positive arguments.",
        "Domain: x > 0. Vertical asymptote: x = 0. Passes through (1; 0) and (2; 1).", 4);
    },
    (d) => {
      const m = ri(2, 5), c = ri(-4, 4);
      return Q("functions_graphs",
        `Find the inverse of f(x) = ${m}x + ${c}.`,
        `f^{-1}(x) = (x − ${c})/${m}`, d,
        "Swap x and y, then solve for y.",
        `x = ${m}y + ${c} → y = (x − ${c})/${m}`, 3);
    },
    (d) => {
      return Q("functions_graphs",
        "Given f(x) = 2x − 1 and g(x) = x², determine (g ∘ f)(x).",
        "(2x − 1)²", d,
        "(g∘f)(x) = g(f(x))",
        "g(f(x)) = g(2x−1) = (2x−1)²", 3);
    }
  ],

  algebra_calculus: [
    (d) => {
      const n = ri(3, 6), c = ri(2, 7);
      return Q("algebra_calculus",
        `Differentiate y = ${c}x^${n} − ${ri(1, 5)}x.`,
        `dy/dx = ${c * n}x^${n - 1} − ${0}`, d,
        "Differentiate term by term.",
        "Apply power rule to each term.", 2);
    },
    (d) => {
      return Q("algebra_calculus",
        "Determine dy/dx from first principles if y = x².",
        "2x", d,
        "lim h→0 [(x+h)² − x²]/h",
        "[x² + 2xh + h² − x²]/h = 2x + h → 2x as h→0", 5);
    },
    (d) => {
      const x0 = ri(1, 4);
      return Q("algebra_calculus",
        `Find the equation of the tangent to y = x² at x = ${x0}.`,
        `y = ${2 * x0}x − ${x0 * x0}`, d,
        "m = dy/dx at x0; then y − y0 = m(x − x0)",
        `m = 2x = ${2 * x0}; point (${x0}; ${x0 * x0}) → y = ${2 * x0}x − ${x0 * x0}`, 4);
    },
    (d) => {
      return Q("algebra_calculus",
        "Find the stationary point of y = x² − 6x + 5.",
        "(3; −4)", d,
        "dy/dx = 0",
        "2x − 6 = 0 → x = 3; y = 9 − 18 + 5 = −4", 4);
    },
    (d) => {
      return Q("algebra_calculus",
        "If y = (2x + 1)(x − 3), determine dy/dx.",
        "4x − 5", d,
        "Expand or product rule",
        "y = 2x² − 5x − 3 → dy/dx = 4x − 5", 3);
    },
    (d) => {
      return Q("algebra_calculus",
        "A particle moves so that s = t³ − 6t² + 9t. Find the velocity when t = 2.",
        "v = −3", d,
        "v = ds/dt",
        "v = 3t² − 12t + 9; at t=2: 12 − 24 + 9 = −3", 4);
    }
,
    (d) => Q("algebra_calculus", "Differentiate y = 1/x from first principles.", "−1/x²", d,
      "f(x)=x^{−1}; lim h→0 [1/(x+h) − 1/x]/h",
      "[(x − (x+h))/(x(x+h))]/h = (−h)/(x(x+h)h) → −1/x²", 5),
    (d) => Q("algebra_calculus", "Find the points on y = x³ − 3x where the tangent is horizontal.",
      "(−1; 2) and (1; −2)", d, "dy/dx = 0",
      "3x² − 3 = 0 → x = ±1; y(−1)=2; y(1)=−2", 5),
    (d) => Q("algebra_calculus", "If s(t) = 4t − t², find the maximum displacement for t ≥ 0.",
      "4 (at t = 2)", d, "v = ds/dt = 0",
      "v = 4 − 2t = 0 → t = 2; s(2) = 8 − 4 = 4", 4),
    (d) => Q("algebra_calculus", "Determine d/dx [√x].", "1/(2√x)", d, "x^{1/2}",
      "d/dx x^{1/2} = (1/2)x^{−1/2} = 1/(2√x)", 3),
    (d) => Q("algebra_calculus", "The gradient of the tangent to y = ax² + bx at x = 1 is 5. If the curve passes through (1; 3), find a and b.",
      "a = 2; b = 1 (example path — solve system)", d,
      "y' = 2ax + b; y(1)=3",
      "2a + b = 5 and a + b = 3 → a = 2, b = 1", 5),
    (d) => Q("algebra_calculus", "Use the product rule to differentiate y = x² sin x (leave in terms of sin and cos).",
      "2x sin x + x² cos x", d, "uv' + vu'",
      "u=x², v=sin x → 2x sin x + x² cos x", 4),
    (d) => Q("algebra_calculus", "Find the equation of the normal to y = x² at x = 1.",
      "y = −½x + 3/2", d, "normal gradient = −1/m",
      "m_tan = 2; m_norm = −1/2; point (1;1) → y−1 = −½(x−1)", 4),
    (d) => Q("algebra_calculus", "Show that f(x) = x³ − 3x + 1 has a root in (0; 1) (sign-change argument).",
      "f(0)=1 > 0, f(1)=−1 < 0 → root in (0;1)", d, "Intermediate value theorem idea",
      "Continuous polynomial; sign change implies a root.", 3)

  ],

  finance_12: [
    (d) => {
      const P = ri(5, 20) * 1000, i = ri(6, 12) / 100, n = ri(2, 5);
      const A = round2(P * ((1 + i) ** n));
      return Q("finance_12",
        `R${P} is invested for ${n} years at ${Math.round(i * 100)}% p.a. compound interest.\nCalculate the accumulated amount.`,
        A, d,
        "A = P(1+i)^n",
        `A = ${P}(1+${i})^${n} = ${A}`, 3);
    },
    (d) => {
      const P = 10000, i = 0.01, n = 24;
      const A = round2(P * ((1 + i) ** n));
      return Q("finance_12",
        "R10 000 is invested at 12% p.a. compounded monthly for 2 years. Calculate A.",
        A, d,
        "i = 0.12/12; n = 24",
        `A = 10000(1.01)^24 ≈ ${A}`, 4);
    },
    (d) => {
      return Q("finance_12",
        "A loan of R50 000 is repaid with equal monthly payments over 5 years at 9% p.a. compounded monthly.\nWrite down the values of i and n for the present-value annuity formula.",
        "i = 0.0075; n = 60", d,
        "i = r/m; n = years × m",
        "i = 0.09/12 = 0.0075; n = 5×12 = 60", 3);
    },
    (d) => {
      return Q("finance_12",
        "Explain the difference between nominal and effective interest rates.",
        "Nominal is quoted rate; effective is actual annual yield after compounding", d,
        "Effective rate accounts for compounding frequency.",
        "Nominal i^{(m)}; effective i_eff = (1 + i^{(m)}/m)^m − 1.", 3);
    },
    (d) => {
      const cost = 80000, n = 5, rate = 0.15;
      const sv = round2(cost * ((1 - rate) ** n));
      return Q("finance_12",
        `A machine costs R${cost}. Depreciate at 15% p.a. on the reducing-balance method for ${n} years.\nFind the book value.`,
        sv, d,
        "A = P(1 − i)^n",
        `A = ${cost}(0.85)^${n} ≈ ${sv}`, 3);
    }
  ],

  trigonometry: [
    (d) => Q("trigonometry", "Simplify: sin(90° − θ) / cos θ", "1", d, "co-function identities", "sin(90°−θ)=cos θ → cos θ/cos θ = 1", 2),
    (d) => Q("trigonometry", "Prove that (1 − cos²θ)/sin θ = sin θ (for sin θ ≠ 0).", "identity", d, "Use sin²+cos²=1", "1−cos²θ = sin²θ → sin²θ/sin θ = sin θ", 3),
    (d) => {
      return Q("trigonometry",
        "Solve for θ ∈ [0°; 360°]: 2 cos θ = 1.",
        "θ = 60° or 300°", d,
        "cos θ = 1/2; general solution then restrict",
        "θ = ±60° + 360°k → in range: 60°, 300°", 4);
    },
    (d) => Q("trigonometry", "Express cos 2α in terms of sin α only.", "1 − 2 sin² α", d, "double-angle", "cos 2α = 1 − 2 sin² α", 2),
    (d) => Q("trigonometry", "In triangle ABC, a = 7, b = 10, Ĉ = 30°. Find the area.", "17.5", d, "Area = ½ab sin C", "½·7·10·sin30° = 35·0.5 = 17.5", 3),
    (d) => Q("trigonometry", "State the cosine rule for side a.", "a² = b² + c² − 2bc cos A", d, "Law of cosines", "a² = b² + c² − 2bc cos Â", 2)
  ],

  analytical_geometry: [
    (d) => {
      const x1 = ri(-3, 3), y1 = ri(-3, 3), x2 = ri(4, 8), y2 = ri(1, 6);
      const m = round2((y2 - y1) / (x2 - x1));
      return Q("analytical_geometry",
        `Calculate the gradient of the line through A(${x1}; ${y1}) and B(${x2}; ${y2}).`,
        m, d, "m = (y2−y1)/(x2−x1)",
        `m = (${y2}−${y1})/(${x2}−${x1}) = ${m}`, 2);
    },
    (d) => {
      return Q("analytical_geometry",
        "Find the midpoint of A(−2; 5) and B(6; −1).",
        "(2; 2)", d, "M = ((x1+x2)/2; (y1+y2)/2)",
        "M = ((−2+6)/2; (5−1)/2) = (2; 2)", 2);
    },
    (d) => {
      return Q("analytical_geometry",
        "Determine the equation of the line through (1; 2) with gradient −3.",
        "y = −3x + 5", d, "y − y1 = m(x − x1)",
        "y − 2 = −3(x − 1) → y = −3x + 5", 3);
    },
    (d) => {
      return Q("analytical_geometry",
        "Show that the points A(0;0), B(4;0), C(4;3) form a right-angled triangle at B.",
        "AB·BC = 0 (vectors) or gradients product −1 check / Pythagoras", d,
        "Use distance or gradient product",
        "AB horizontal, BC vertical → AB ⊥ BC.", 4);
    },
    (d) => {
      return Q("analytical_geometry",
        "Circle: x² + y² − 6x + 4y − 12 = 0. Find the centre and radius.",
        "Centre (3; −2); r = 5", d,
        "Complete the square",
        "(x−3)² + (y+2)² = 25 → centre (3;−2), r=5", 4);
    }
  ],

  euclidean_geometry: [
    (d) => Q("euclidean_geometry",
      "O is the centre of a circle. Chord AB subtends ∠AOB = 80° at the centre.\nFind the angle subtended by AB at the circumference on the same side.",
      "40°", d, "Angle at centre is twice angle at circumference",
      "∠ACB = ½∠AOB = 40°", 3),
    (d) => Q("euclidean_geometry",
      "ABCD is a cyclic quadrilateral. ∠ABC = 95°. Find ∠ADC.",
      "85°", d, "Opposite angles of cyclic quad sum to 180°",
      "∠ADC = 180° − 95° = 85°", 2),
    (d) => Q("euclidean_geometry",
      "Tangent at A touches the circle at A. Chord AB. If ∠between tangent and chord is 55°, find the angle in the alternate segment.",
      "55°", d, "Tangent–chord theorem",
      "Angle in alternate segment equals angle between tangent and chord = 55°", 3),
    (d) => Q("euclidean_geometry",
      "Two tangents from external point T touch the circle at A and B. Prove that TA = TB.",
      "tangents from a common external point are equal", d,
      "Radii ⊥ tangent; congruent triangles",
      "OA ⊥ TA, OB ⊥ TB; OA = OB (radii); OT common → △OAT ≡ △OBT → TA = TB", 5),
    (d) => Q("euclidean_geometry",
      "In circle with centre O, chord AB with M midpoint of AB. Prove that OM ⊥ AB.",
      "line from centre to midpoint of chord is perpendicular to chord", d,
      "Congruent right triangles",
      "OA = OB; AM = MB; OM common → △OAM ≡ △OBM → ∠OMA = ∠OMB = 90°", 5)
  ],

  probability_12: [
    (d) => Q("probability_12", "A fair die is rolled. P(prime number)?", "1/2", d, "Primes: 2,3,5", "3/6 = 1/2", 2),
    (d) => Q("probability_12", "P(A) = 0.4, P(B) = 0.5, A and B independent. P(A and B)?", "0.2", d, "Independent: P(A∩B)=P(A)P(B)", "0.4×0.5=0.2", 2),
    (d) => Q("probability_12", "P(A) = 0.3, P(B) = 0.5, P(A∪B) = 0.7. Are A and B mutually exclusive?", "No (P(A∩B)=0.1 ≠ 0)", d, "Mutually exclusive ⇒ P(A∪B)=P(A)+P(B)", "0.3+0.5=0.8 ≠ 0.7", 3),
    (d) => Q("probability_12", "From 5 boys and 4 girls, a committee of 3 is chosen at random. P(all girls)?", "4/84 = 1/21", d, "Combinations", "C(4,3)/C(9,3) = 4/84 = 1/21", 4),
    (d) => Q("probability_12", "Two events: P(A)=0.6, P(B|A)=0.3. Find P(A and B).", "0.18", d, "P(A∩B)=P(B|A)P(A)", "0.3×0.6=0.18", 3)
  ],

  statistics_12: [
    (d) => Q("statistics_12", "Data: 2, 5, 5, 7, 9. Find the median.", "5", d, "Middle value of ordered list", "Ordered already; middle = 5", 1),
    (d) => Q("statistics_12", "Data: 3, 7, 7, 8, 12. Find the mean.", "7.4", d, "Sum ÷ n", "(3+7+7+8+12)/5 = 37/5 = 7.4", 2),
    (d) => Q("statistics_12", "Five-number summary of a set is 2, 5, 8, 11, 15. Calculate the IQR.", "6", d, "IQR = Q3 − Q1", "11 − 5 = 6", 2),
    (d) => Q("statistics_12", "Why might the median be preferred to the mean for a skewed income data set?", "Median is resistant to outliers / extreme values", d, "Robustness", "Mean is pulled by extreme incomes; median better represents typical value.", 3),
    (d) => Q("statistics_12", "A box-and-whisker plot has Q1 = 10, median = 14, Q3 = 18. Comment on symmetry.", "Roughly symmetric (median midway between Q1 and Q3)", d, "Compare distances", "14−10 = 4 and 18−14 = 4 → symmetric about median in the box.", 3)
  ]
};



/** Expand a topic bank by cloning structural variants with new parameters. */
export function expandBank(topic, makers, target = 30) {
  const out = makers.slice();
  let guard = 0;
  while (out.length < target && guard < 200) {
    guard++;
    out.push(makers[out.length % makers.length]);
  }
  return out;
}

// Ensure each bank exposes at least 12 callable types (duplicates still re-roll values)
for (const [k, arr] of Object.entries(MATHS)) {
  if (arr.length < 30) {
    const base = arr.slice();
    while (arr.length < 30) arr.push(base[arr.length % base.length]);
  }
}

export function generateMathsRecipe(topicId, difficulty = 2) {
  const d = Math.max(1, Math.min(4, difficulty | 0));
  const bank = MATHS[topicId];
  if (!bank || !bank.length) return null;
  const type = pickType(topicId, bank);
  try {
    return type(d);
  } catch {
    return bank[0](d);
  }
}

export function mathsRecipeTopics() {
  return Object.keys(MATHS);
}

export function mathsRecipeCount(topicId) {
  return (MATHS[topicId] || []).length;
}

// Physical Sciences — type variety helpers used by physSciEngine wrapper
export function generatePsRecipe(topicId, difficulty, fallbackFn) {
  // Prefer engine's multi-type generators; this ensures we don't only mutate values
  if (typeof fallbackFn === "function") return fallbackFn(topicId, difficulty);
  return null;
}

export default { generateMathsRecipe, mathsRecipeTopics, mathsRecipeCount };

// ── Extra Euclidean diagram-style multi-step problems ───────────────────
const EUCLID_EXTRA = [
  (d) => Q("euclidean_geometry",
    "In the diagram, O is the centre of the circle. Chord AB subtends ∠AOB = 100° at the centre.\nC is a point on the major arc AB.\n1.1 Find ∠ACB.\n1.2 If OA = 10 cm and M is the midpoint of AB with OM ⊥ AB, express OM in surd form if ∠AOM = 50°.",
    "1.1 50°; 1.2 10 cos 50°", d,
    "∠ at centre = 2∠ at circumference; right triangle OMA.",
    "1.1 ∠ACB = ½·100° = 50° (∠ at centre = 2∠ at circ.).\n1.2 In right △OMA: OM = OA cos 50° = 10 cos 50°.",
    6, { type: "circle_geometry", mode: "centre" }),
  (d) => Q("euclidean_geometry",
    "AB is a diameter of circle with centre O. C is on the circumference. ∠CAB = 35°.\n2.1 Write down ∠ACB.\n2.2 Calculate ∠ABC.\n2.3 Calculate ∠AOC (O centre).",
    "2.1 90°; 2.2 55°; 2.3 110°", d,
    "Angle in a semicircle; triangle sum; central = 2× circumference.",
    "2.1 ∠ACB = 90° (∠ in semicircle).\n2.2 ∠ABC = 180° − 90° − 35° = 55°.\n2.3 ∠AOC = 2·∠ABC = 110° (∠ at centre = 2∠ at circ. on arc AC).",
    6, { type: "circle_geometry", mode: "semicircle" }),
  (d) => Q("euclidean_geometry",
    "ABCD is a cyclic quadrilateral. ∠ABC = 95° and ∠BAD = 70°.\n3.1 Find ∠ADC.\n3.2 Find ∠BCD.",
    "3.1 85°; 3.2 110°", d,
    "Opposite angles of cyclic quad sum to 180°.",
    "3.1 ∠ADC = 180° − 95° = 85°.\n3.2 ∠BCD = 180° − 70° = 110°.",
    4, { type: "circle_geometry", mode: "cyclic" }),
  (d) => Q("euclidean_geometry",
    "Tangent at A touches the circle at A. Chord AB. The angle between the tangent and AB is 55°.\nD is a point on the circle in the alternate segment.\n4.1 Find ∠ADB.\n4.2 If ∠ACB = 55° for point C on the other arc, name the theorem that justifies equality with the tangent–chord angle.",
    "4.1 55°; 4.2 tan-chord / alternate segment theorem", d,
    "Tangent–chord theorem.",
    "4.1 ∠ADB = 55° (tan-chord theorem).\n4.2 Alternate segment (tan-chord) theorem.",
    4, { type: "circle_geometry", mode: "tangent" }),
  (d) => Q("euclidean_geometry",
    "Two tangents from external point T touch the circle at A and B. O is the centre. TA = 12 cm and ∠ATB = 40°.\n5.1 Find TB.\n5.2 Find ∠TAB.\n5.3 Find ∠OAT.",
    "5.1 12 cm; 5.2 70°; 5.3 90°", d,
    "Equal tangents; isosceles △TAB; radius ⊥ tangent.",
    "5.1 TB = TA = 12 cm (equal tangents).\n5.2 Base angles of isosceles △TAB: (180°−40°)/2 = 70°.\n5.3 ∠OAT = 90° (rad ⊥ tan).",
    6, { type: "circle_geometry", mode: "two_tangents" }),
  (d) => Q("euclidean_geometry",
    "O is the centre. Chord AB = 16 cm. The perpendicular from O to AB meets AB at M and OM = 6 cm.\nCalculate the radius OA.",
    "10 cm", d,
    "Perpendicular from centre bisects chord; Pythagoras.",
    "AM = 8 cm. OA² = OM² + AM² = 36 + 64 = 100 → OA = 10 cm.",
    4, { type: "circle_geometry", mode: "perp_chord" }),
  (d) => Q("euclidean_geometry",
    "In circle with centre O, ∠AOB = 80° and C is on the circumference on the major arc.\n7.1 Find ∠ACB.\n7.2 Find the reflex ∠AOB.\n7.3 Hence find the angle at the circumference on the minor arc side (point D on minor arc).",
    "7.1 40°; 7.2 280°; 7.3 140°", d,
    "Central vs circumference; reflex central angle.",
    "7.1 40°. 7.2 360°−80°=280°. 7.3 Half of reflex = 140°.",
    5, { type: "circle_geometry", mode: "centre" }),
  (d) => Q("euclidean_geometry",
    "ABCD is cyclic. AB is extended to E so that ∠CBE = 72°.\nFind ∠ADC.",
    "72°", d,
    "Exterior angle of cyclic quad equals opposite interior.",
    "ext ∠ of cyclic quad = opp int ∠ → ∠ADC = 72°.",
    3, { type: "circle_geometry", mode: "cyclic" }),
  (d) => Q("euclidean_geometry",
    "Prove that the line from the centre of a circle to the midpoint of a chord is perpendicular to the chord. (Give a short reason chain.)",
    "△OAM ≡ △OBM (SSS or radii + common side) → ∠OMA = ∠OMB = 90°", d,
    "Congruent triangles with two radii.",
    "OA = OB (radii), AM = MB (midpoint), OM common → △OAM ≡ △OBM → adjacent angles on straight line equal → each 90°.",
    5, { type: "circle_geometry", mode: "perp_chord" }),
  (d) => Q("euclidean_geometry",
    "Intersecting chords: chords AB and CD intersect at P inside the circle. AP = 3, PB = 8, CP = 4. Find PD.",
    "6", d,
    "AP·PB = CP·PD",
    "3·8 = 4·PD → PD = 6.",
    3, { type: "circle_geometry", mode: "intersecting_chords" })
];

// Merge extra Euclidean into MATHS bank types
if (MATHS.euclidean_geometry) {
  MATHS.euclidean_geometry.push(...EUCLID_EXTRA);
  while (MATHS.euclidean_geometry.length < 30) {
    MATHS.euclidean_geometry.push(EUCLID_EXTRA[MATHS.euclidean_geometry.length % EUCLID_EXTRA.length]);
  }
}

/** Named question templates for engines (articulate structure → fill values). */
export const QUESTION_TEMPLATES = {
  multi_part_circle: {
    id: "multi_part_circle",
    description: "CAPS-style multi-part Euclidean with diagram mode",
    parts: ["find circumference angle", "find centre angle", "apply Pythagoras on radius-chord"]
  },
  finance_compound: {
    id: "finance_compound",
    description: "Compound interest A = P(1+i)^n with monthly variant",
    parts: ["identify i and n", "compute A", "compare nominal vs effective"]
  },
  calculus_first_principles: {
    id: "calculus_first_principles",
    description: "First principles derivative for polynomials",
    parts: ["write limit definition", "expand f(x+h)", "simplify and take limit"]
  },
  accounting_recon: {
    id: "accounting_recon",
    description: "Full bank reconciliation from statement to cash book",
    parts: ["outstanding deposits", "outstanding cheques", "bank charges", "final balance"]
  }
};

export function listQuestionTemplates() {
  return Object.values(QUESTION_TEMPLATES);
}
