import { applyTheme } from "../theme.js";

// Core story badges + generated level ladder (shows by learner level).
const CORE = [
  { id: "first_spark", name: "First Spark", icon: "✨", desc: "First answer.", minLevel: 1, check: (s) => (s.history || []).length >= 1, reward: 10 },
  { id: "warm_up", name: "Warm-Up", icon: "🌤️", desc: "10 answers.", minLevel: 1, check: (s) => (s.history || []).length >= 10, reward: 15 },
  { id: "fifty_club", name: "Fifty", icon: "5️⃣", desc: "50 answers.", minLevel: 1, check: (s) => (s.history || []).length >= 50, reward: 25 },
  { id: "hundred_club", name: "Hundred", icon: "💯", desc: "100 answers.", minLevel: 2, check: (s) => (s.history || []).length >= 100, reward: 50 },
  { id: "sprint_5", name: "Sprint 5", icon: "⚡", desc: "Sprint streak 5.", minLevel: 1, check: (s) => (s.mental_best_streak || 0) >= 5, reward: 15 },
  { id: "sprint_15", name: "Sprint 15", icon: "🏃", desc: "Sprint streak 15.", minLevel: 2, check: (s) => (s.mental_best_streak || 0) >= 15, reward: 30 },
  { id: "streak_3", name: "3-day streak", icon: "🔥", desc: "Practice 3 days.", minLevel: 1, check: (s) => (s.streak || 0) >= 3, reward: 20 },
  { id: "streak_7", name: "7-day streak", icon: "📅", desc: "Practice 7 days.", minLevel: 2, check: (s) => (s.streak || 0) >= 7, reward: 40 },
  { id: "struct_1", name: "Challenge start", icon: "📋", desc: "One multi-part question.", minLevel: 1, check: (s) => (s.history || []).some((h) => String(h.question_id || "").includes("struct")), reward: 20 },
  { id: "fraction_15", name: "Fraction 15", icon: "🍕", desc: "15 fraction wins.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("fraction") && h.correct).length >= 15, reward: 25 },
  { id: "data_15", name: "Data 15", icon: "📊", desc: "15 data wins.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("data") && h.correct).length >= 15, reward: 25 },
  { id: "shape_15", name: "Shape 15", icon: "🔺", desc: "15 shape wins.", minLevel: 1, check: (s) => (s.history || []).filter((h) => /geometry|shape/.test(String(h.topic || "")) && h.correct).length >= 15, reward: 25 },
  { id: "goal_1", name: "Daily goal", icon: "🎯", desc: "Hit today's goal.", minLevel: 1, check: (s) => (s.today_done || 0) >= (s.daily_goal || 20), reward: 20 },
  { id: "shop_1", name: "First buy", icon: "🛒", desc: "Buy from the shop.", minLevel: 1, check: (s) => (s.unlocked_rewards || []).length >= 1, reward: 15 },
  // Grade 11 / FET
  { id: "g11_eq_10", name: "Equation ten", icon: "🧮", desc: "10 correct equations.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("equation") && h.correct).length >= 10, reward: 30 },
  { id: "g11_pattern_10", name: "Pattern finder", icon: "🔢", desc: "10 correct number patterns.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("pattern") && h.correct).length >= 10, reward: 30 },
  { id: "g11_fn_10", name: "Function form", icon: "📈", desc: "10 correct functions.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("function") && h.correct).length >= 10, reward: 30 },
  { id: "g11_euc_10", name: "Circle rider", icon: "⭕", desc: "10 correct Euclidean.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("euclidean") && h.correct).length >= 10, reward: 35 },
  { id: "g11_trig_10", name: "Trig ten", icon: "📐", desc: "10 correct trigonometry.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("trig") && h.correct).length >= 10, reward: 30 },
  { id: "g11_paper_1", name: "Paper starter", icon: "📄", desc: "Open a past paper.", minLevel: 1, check: (s) => !!(s.flags && s.flags.opened_paper), reward: 25 },
  { id: "g11_topic_practice", name: "Topic grind", icon: "🎯", desc: "Finish a topic practice set.", minLevel: 1, check: (s) => !!(s.flags && s.flags.topic_practice), reward: 25 },
  { id: "g11_theorem", name: "Theorem lab", icon: "📜", desc: "Visit Theorem Workshop.", minLevel: 1, check: (s) => !!(s.flags && s.flags.theorem_lab), reward: 20 },
  { id: "g11_five_topics", name: "Five topics", icon: "🌟", desc: "Correct answers in 5 different topics.", minLevel: 2, check: (s) => new Set((s.history || []).filter((h) => h.correct).map((h) => h.topic)).size >= 5, reward: 40 },
  { id: "star_spender", name: "Star spender", icon: "✨", desc: "Spend 100 stars in the shop.", minLevel: 1, check: (s) => (s.transactions || []).filter((t) => t.amount < 0).reduce((a, t) => a + Math.abs(t.amount), 0) >= 100, reward: 20 }
];

// Generate level ladder badges up to a large catalogue (level-gated display).
function buildLadder() {
  const out = [];
  const icons = ["⭐", "🌟", "💫", "🔥", "🎯", "🏆", "🎖️", "💎", "🚀", "🌈"];
  for (let lvl = 1; lvl <= 50; lvl++) {
    for (let i = 1; i <= 20; i++) {
      const id = `lvl_${lvl}_${i}`;
      const need = (lvl - 1) * 20 + i; // answers milestone
      out.push({
        id,
        name: `Level ${lvl} · ${i}`,
        icon: icons[(lvl + i) % icons.length],
        desc: `Reach ${need * 5} XP or level ${lvl}.`,
        minLevel: lvl,
        check: (s) => (s.level || 1) >= lvl && ((s.xp || 0) >= need * 5 || (s.history || []).length >= need * 3),
        reward: 5 + Math.floor(lvl / 2)
      });
    }
  }
  return out; // 1000 ladder badges
}

export const ACHIEVEMENTS = [...CORE, ...buildLadder()];

const THEME_REWARDS = [
  { id: "theme_sunset", name: "Sunset", icon: "🌅", cost: 40, desc: "Warm evening glow.", theme: "Sunset", minLevel: 1, kind: "theme" },
  { id: "theme_forest", name: "Forest", icon: "🌿", cost: 40, desc: "Calm greens.", theme: "Forest", minLevel: 1, kind: "theme" },
  { id: "theme_ocean", name: "Ocean", icon: "🌊", cost: 45, desc: "Deep blue focus.", theme: "Ocean", minLevel: 1, kind: "theme" },
  { id: "theme_candy", name: "Candy", icon: "🍭", cost: 45, desc: "Bright pink energy.", theme: "Candy", minLevel: 1, kind: "theme" },
  { id: "theme_midnight", name: "Midnight", icon: "🌙", cost: 35, desc: "True dark mode.", theme: "Midnight", minLevel: 1, kind: "theme" },
  { id: "theme_neon", name: "Neon", icon: "💜", cost: 50, desc: "Electric neon.", theme: "Neon", minLevel: 2, kind: "theme" },
  { id: "theme_academic", name: "Academic", icon: "🎓", cost: 55, desc: "Clean study look.", theme: "Academic", minLevel: 2, kind: "theme" },
  { id: "theme_glass", name: "Glass", icon: "🪟", cost: 60, desc: "Frosted glass UI.", theme: "Glass", minLevel: 3, kind: "theme" },
  { id: "theme_aurora", name: "Aurora", icon: "🌌", cost: 70, desc: "Northern-lights vibe.", theme: "Aurora", minLevel: 4, kind: "theme" },
  { id: "theme_gold", name: "Gold", icon: "👑", cost: 90, desc: "Premium gold accents.", theme: "Gold", minLevel: 5, kind: "theme" }
];

const UI_UPGRADES = [
  { id: "ui_compact", name: "Compact cards", icon: "📦", cost: 80, desc: "Tighter card spacing for more on screen.", minLevel: 2, kind: "ui" },
  { id: "ui_large_type", name: "Exam type size", icon: "🔤", cost: 60, desc: "Larger question text in papers.", minLevel: 1, kind: "ui" },
  { id: "ui_progress_ring", name: "Progress ring", icon: "⭕", cost: 70, desc: "Ring meter on Home for daily goal.", minLevel: 2, kind: "ui" },
  { id: "ui_confetti", name: "Confetti bursts", icon: "🎉", cost: 50, desc: "Celebrate correct multi-part answers.", minLevel: 1, kind: "ui" },
  { id: "ui_paper_serif", name: "Paper serif", icon: "✒️", cost: 65, desc: "Exam-style serif font in paper viewer.", minLevel: 3, kind: "ui" },
  { id: "ui_diagram_hd", name: "HD diagrams", icon: "🖼️", cost: 75, desc: "Sharper canvas diagrams on retina screens.", minLevel: 2, kind: "ui" },
  { id: "frame_gold", name: "Gold frame", icon: "🖼️", cost: 100, desc: "Gold border on profile avatar.", minLevel: 3, kind: "frame" },
  { id: "frame_neon", name: "Neon frame", icon: "💜", cost: 100, desc: "Neon border on profile avatar.", minLevel: 3, kind: "frame" },
  { id: "frame_maths", name: "π frame", icon: "π", cost: 85, desc: "Maths-symbol avatar frame.", minLevel: 2, kind: "frame" },
  { id: "title_scholar", name: "Title: Scholar", icon: "🏷️", cost: 120, desc: "Show Scholar under your name.", minLevel: 4, kind: "title" },
  { id: "title_rider", name: "Title: Rider pro", icon: "🏷️", cost: 120, desc: "For Euclidean grinders.", minLevel: 4, kind: "title" },
  { id: "boost_double_star", name: "Double-star hour", icon: "⭐", cost: 150, desc: "Next session earns 2× stars (cosmetic flag).", minLevel: 3, kind: "boost" }
];

function buildShopLadder() {
  const out = [...THEME_REWARDS, ...UI_UPGRADES];
  const frames = ["🥇", "🚀", "📚", "🦊", "🐸", "🐻", "🦁", "🐼", "⚡", "🎯"];
  for (let lvl = 1; lvl <= 30; lvl++) {
    for (let i = 0; i < 3; i++) {
      out.push({
        id: `shop_${lvl}_${i}`,
        name: `Boost pack L${lvl}-${i + 1}`,
        icon: frames[(lvl + i) % frames.length],
        cost: 25 + lvl * 4 + i * 8,
        desc: `Level ${lvl} cosmetic pack.`,
        minLevel: lvl,
        kind: "pack"
      });
    }
  }
  ["Explorer", "Sprinter", "Algebra ace", "Pattern pro", "Geometry star"].forEach((name, i) => {
    out.push({ id: `title_core_${i}`, name: `Title: ${name}`, icon: "🏷️", cost: 40 + i * 15, desc: name, minLevel: 1 + i, kind: "title" });
  });
  return out;
}

export const REWARD_SHOP = buildShopLadder();

export class GamificationEngine {
  constructor(student) {
    this.student = student;
    if (!student.achievements) student.achievements = [];
    if (!student.unlocked_rewards) student.unlocked_rewards = [];
    if (!student.active_reward) student.active_reward = null;
    if (!student.level) student.level = Math.max(1, Math.floor((student.xp || 0) / 100) + 1);
  }
  level() {
    const lvl = Math.max(1, Math.floor((this.student.xp || 0) / 100) + 1);
    this.student.level = lvl;
    return lvl;
  }
  checkNewUnlocks() {
    this.level();
    const unlocked = new Set(this.student.achievements);
    const newly = [];
    for (const ach of ACHIEVEMENTS) {
      if (unlocked.has(ach.id)) continue;
      // only evaluate badges at or below level+2 for performance
      if ((ach.minLevel || 1) > this.student.level + 2) continue;
      try {
        if (ach.check(this.student)) {
          this.student.achievements.push(ach.id);
          newly.push(ach);
          if (ach.reward) {
            this.student.credits = (this.student.credits || 0) + ach.reward;
            this.student.transactions = this.student.transactions || [];
            this.student.transactions.push({
              amount: ach.reward, reason: `Badge: ${ach.name}`,
              timestamp: new Date().toISOString(), balance_after: this.student.credits
            });
          }
        }
      } catch { /* ignore */ }
    }
    return newly;
  }
  allWithStatus() {
    const lvl = this.level();
    const unlocked = new Set(this.student.achievements || []);
    // Show core + badges up to level+1 (not all 1000 at once)
    return ACHIEVEMENTS
      .filter((a) => (a.minLevel || 1) <= lvl + 1)
      .map((a) => ({
        id: a.id, name: a.name, icon: a.icon, desc: a.desc,
        unlocked: unlocked.has(a.id), reward: a.reward || 0, minLevel: a.minLevel || 1
      }));
  }
  progressSummary() {
    const lvl = this.level();
    const visible = ACHIEVEMENTS.filter((a) => (a.minLevel || 1) <= lvl + 1);
    const unlocked = new Set(this.student.achievements || []);
    const have = visible.filter((a) => unlocked.has(a.id)).length;
    return [have, visible.length, ACHIEVEMENTS.length];
  }
  shopItems() {
    const lvl = this.level();
    const owned = new Set(this.student.unlocked_rewards || []);
    return REWARD_SHOP
      .filter((r) => (r.minLevel || 1) <= lvl)
      .map((r) => ({ ...r, owned: owned.has(r.id) }));
  }
  buy(rewardId) {
    const item = REWARD_SHOP.find((r) => r.id === rewardId);
    if (!item) return { ok: false, reason: "not_found" };
    if ((item.minLevel || 1) > this.level()) return { ok: false, reason: "level" };
    const owned = new Set(this.student.unlocked_rewards || []);
    if (owned.has(rewardId)) return { ok: false, reason: "owned" };
    const bal = this.student.credits || 0;
    if (bal < item.cost) return { ok: false, reason: "funds" };
    this.student.credits = bal - item.cost;
    this.student.unlocked_rewards.push(rewardId);
    this.student.transactions = this.student.transactions || [];
    this.student.transactions.push({
      amount: -item.cost, reason: `Shop: ${item.name}`,
      timestamp: new Date().toISOString(), balance_after: this.student.credits
    });
    return { ok: true, item };
  }
  equip(rewardId) {
    const owned = new Set(this.student.unlocked_rewards || []);
    if (!owned.has(rewardId)) return false;
    this.student.active_reward = rewardId;
    const item = REWARD_SHOP.find((r) => r.id === rewardId);
    if (item?.theme) {
      this.student.settings = this.student.settings || {};
      this.student.settings.theme = item.theme;
      applyTheme(item.theme, this.student.settings.font_scale || "Normal");
    }
    return true;
  }
}
