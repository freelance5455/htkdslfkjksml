/**
 * Learnly Grade 10 — Subject paper engine (CAPS-style generative papers).
 * Mathematical Literacy · Business Studies · Tourism
 * Questions are generated programmatically — not copied from copyrighted PDFs.
 */

import { MultiSubjectEngine } from "./multiSubjectEngine.js";

function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

/** CAPS-inspired paper blueprints for Grade 10 */
const BLUEPRINTS = {
  mathematical_literacy: {
    papers: [
      {
        id: "ml_p1",
        name: "Mathematical Literacy Paper 1",
        period: "November",
        sections: [
          { heading: "SECTION A — Basic skills (numbers, ratio, rate, percentage)", topics: ["ml_numbers", "ml_patterns"], marks: 25, count: 4 },
          { heading: "SECTION B — Finance (budget, interest, VAT, profit)", topics: ["ml_finance"], marks: 40, count: 4 },
          { heading: "SECTION C — Measurement, maps & probability", topics: ["ml_measurement", "ml_maps", "ml_probability"], marks: 35, count: 3 },
          { heading: "SECTION D — Data handling", topics: ["ml_data"], marks: 25, count: 2 }
        ]
      },
      {
        id: "ml_p2",
        name: "Mathematical Literacy Paper 2",
        period: "November",
        sections: [
          { heading: "SECTION A — Finance & integrated budgets", topics: ["ml_finance", "ml_numbers"], marks: 40, count: 4 },
          { heading: "SECTION B — Measurement, plans & scale", topics: ["ml_measurement", "ml_maps"], marks: 40, count: 3 },
          { heading: "SECTION C — Data, probability & patterns", topics: ["ml_data", "ml_probability", "ml_patterns"], marks: 35, count: 3 }
        ]
      },
      {
        id: "ml_june",
        name: "Mathematical Literacy June Paper",
        period: "June",
        sections: [
          { heading: "SECTION A — Short items", topics: ["ml_numbers", "ml_finance", "ml_measurement"], marks: 30, count: 5 },
          { heading: "SECTION B — Structured finance & maps", topics: ["ml_finance", "ml_maps"], marks: 40, count: 3 },
          { heading: "SECTION C — Data & integrated", topics: ["ml_data", "ml_probability", "ml_patterns"], marks: 30, count: 2 }
        ]
      },
      {
        id: "ml_march",
        name: "Mathematical Literacy March Controlled Test",
        period: "March",
        sections: [
          { heading: "SECTION A — Numbers, ratio & percentage", topics: ["ml_numbers", "ml_patterns"], marks: 30, count: 4 },
          { heading: "SECTION B — Finance introduction", topics: ["ml_finance"], marks: 40, count: 3 },
          { heading: "SECTION C — Measurement basics", topics: ["ml_measurement", "ml_maps"], marks: 30, count: 3 }
        ]
      },
      {
        id: "ml_sept",
        name: "Mathematical Literacy September Trial",
        period: "September",
        sections: [
          { heading: "SECTION A — Finance & numbers", topics: ["ml_finance", "ml_numbers"], marks: 40, count: 4 },
          { heading: "SECTION B — Maps, measurement & data", topics: ["ml_maps", "ml_measurement", "ml_data"], marks: 40, count: 3 },
          { heading: "SECTION C — Probability & patterns", topics: ["ml_probability", "ml_patterns"], marks: 20, count: 2 }
        ]
      }
    ]
  },
  business_studies: {
    papers: [
      {
        id: "bs_p1",
        name: "Business Studies Paper 1",
        period: "November",
        sections: [
          { heading: "SECTION A — Compulsory short items", topics: ["bs_micro", "bs_market", "bs_macro", "bs_sectors"], marks: 30, count: 5 },
          { heading: "SECTION B — Business environments", topics: ["bs_micro", "bs_market", "bs_macro", "bs_socio"], marks: 40, count: 3 },
          { heading: "SECTION C — Essay / extended", topics: ["bs_entrepreneurship", "bs_ownership", "bs_opportunity"], marks: 40, count: 2 }
        ]
      },
      {
        id: "bs_p2",
        name: "Business Studies Paper 2",
        period: "November",
        sections: [
          { heading: "SECTION A — Compulsory short items", topics: ["bs_entrepreneurship", "bs_ownership", "bs_creative", "bs_self"], marks: 30, count: 5 },
          { heading: "SECTION B — Business ventures", topics: ["bs_opportunity", "bs_ownership", "bs_sectors"], marks: 40, count: 3 },
          { heading: "SECTION C — Essay / extended", topics: ["bs_socio", "bs_creative", "bs_self"], marks: 40, count: 2 }
        ]
      },
      {
        id: "bs_march",
        name: "Business Studies March Controlled Test",
        period: "March",
        sections: [
          { heading: "SECTION A — Short items", topics: ["bs_micro", "bs_market", "bs_macro"], marks: 30, count: 5 },
          { heading: "SECTION B — Environments & sectors", topics: ["bs_sectors", "bs_socio"], marks: 40, count: 3 },
          { heading: "SECTION C — Extended", topics: ["bs_entrepreneurship", "bs_ownership"], marks: 30, count: 2 }
        ]
      },
      {
        id: "bs_sept",
        name: "Business Studies September Trial",
        period: "September",
        sections: [
          { heading: "SECTION A — Short items", topics: ["bs_ownership", "bs_opportunity", "bs_creative"], marks: 30, count: 5 },
          { heading: "SECTION B — Ventures & roles", topics: ["bs_self", "bs_socio", "bs_sectors"], marks: 40, count: 3 },
          { heading: "SECTION C — Extended", topics: ["bs_macro", "bs_entrepreneurship"], marks: 30, count: 2 }
        ]
      }
    ]
  },
  tourism: {
    papers: [
      {
        id: "tour_p1",
        name: "Tourism Paper 1",
        period: "November",
        sections: [
          { heading: "SECTION A — Compulsory short items", topics: ["tour_intro", "tour_types", "tour_sectors", "tour_transport"], marks: 40, count: 5 },
          { heading: "SECTION B — Sectors & planning", topics: ["tour_accommodation", "tour_maps", "tour_attractions"], marks: 40, count: 3 },
          { heading: "SECTION C — Extended response", topics: ["tour_sustainable", "tour_domestic", "tour_service"], marks: 40, count: 2 }
        ]
      },
      {
        id: "tour_p2",
        name: "Tourism Paper 2",
        period: "June",
        sections: [
          { heading: "SECTION A — Short items", topics: ["tour_intro", "tour_types", "tour_service"], marks: 30, count: 4 },
          { heading: "SECTION B — Map work & attractions", topics: ["tour_maps", "tour_attractions", "tour_transport"], marks: 40, count: 3 },
          { heading: "SECTION C — Sustainable & domestic", topics: ["tour_sustainable", "tour_domestic", "tour_sectors"], marks: 30, count: 2 }
        ]
      },
      {
        id: "tour_march",
        name: "Tourism March Controlled Test",
        period: "March",
        sections: [
          { heading: "SECTION A — Introduction & types", topics: ["tour_intro", "tour_types"], marks: 30, count: 4 },
          { heading: "SECTION B — Sectors & transport", topics: ["tour_sectors", "tour_transport", "tour_accommodation"], marks: 40, count: 3 },
          { heading: "SECTION C — Service", topics: ["tour_service"], marks: 30, count: 2 }
        ]
      },
      {
        id: "tour_sept",
        name: "Tourism September Trial",
        period: "September",
        sections: [
          { heading: "SECTION A — Short items", topics: ["tour_maps", "tour_attractions", "tour_types"], marks: 30, count: 4 },
          { heading: "SECTION B — Sustainable tourism", topics: ["tour_sustainable", "tour_domestic"], marks: 40, count: 3 },
          { heading: "SECTION C — Service excellence", topics: ["tour_service", "tour_sectors"], marks: 30, count: 2 }
        ]
      }
    ]
  }
};

const YEARS = [2022, 2023, 2024, 2025];

export function listSubjectPapers(subjectId) {
  const bp = BLUEPRINTS[subjectId];
  if (!bp) return [];
  const out = [];
  bp.papers.forEach((tpl) => {
    YEARS.forEach((year) => {
      out.push({
        templateId: tpl.id,
        name: tpl.name,
        period: tpl.period,
        year,
        subjectId
      });
    });
  });
  return out;
}

export function generateSubjectPaper(subjectId, templateId = null, grade = 10, year = null) {
  const bp = BLUEPRINTS[subjectId];
  if (!bp) return null;
  const template = templateId
    ? bp.papers.find((p) => p.id === templateId) || bp.papers[0]
    : bp.papers[0];
  year = year || choice(YEARS);
  const eng = new MultiSubjectEngine(grade);
  const questions = [];
  let qn = 1;
  template.sections.forEach((sec) => {
    const perQ = Math.max(2, Math.round(sec.marks / sec.count));
    for (let i = 0; i < sec.count; i++) {
      const topic = choice(sec.topics);
      const marks = i === sec.count - 1
        ? sec.marks - perQ * (sec.count - 1)
        : perQ;
      const item = buildQuestion(topic, eng, marks, qn);
      if (item) {
        item.section = sec.heading;
        questions.push(item);
        qn += 1;
      }
    }
  });
  const totalMarks = questions.reduce((s, q) => s + (q.marks || 0), 0);
  const pid = `sp_${subjectId}_${template.id}_${year}_${Date.now()}`;
  return {
    id: pid,
    paper_id: pid,
    title: `${template.name} · ${year}`,
    name: template.name,
    period: template.period,
    year,
    subjectId,
    subject: subjectId,
    grade,
    grade_label: `Grade ${grade}`,
    questions,
    total_marks: totalMarks,
    marks: totalMarks,
    time_minutes: 150,
    source: "Learnly Grade 10 · generative CAPS-style (not a past-paper scan)"
  };
}

function buildQuestion(topic, eng, marks, number) {
  function pack(parts, title, diagram) {
    const partMarks = Math.max(1, Math.floor(marks / Math.max(1, parts.length)));
    const normalised = parts.map((p, i) => ({
      label: p.label || `${number}.${i + 1}`,
      prompt: p.prompt || p.question || "",
      answer: p.answer != null ? String(p.answer) : "",
      explanation: p.explanation || "",
      marks: p.marks || partMarks
    }));
    const questionText = normalised.map((p) => `${p.label} ${p.prompt}`).join("\n\n");
    const answerText = normalised.map((p) => `${p.label} ${p.answer}`).join("\n");
    const explText = normalised.map((p) => {
      const bit = p.explanation ? ` — ${p.explanation}` : "";
      return `${p.label} ${p.answer}${bit}`;
    }).join("\n");
    return {
      number,
      topic,
      topic_name: String(topic).replaceAll("_", " "),
      title: title || String(topic).replaceAll("_", " "),
      marks,
      question: questionText,
      answer: answerText,
      explanation: explText,
      diagram: diagram || null,
      parts: normalised
    };
  }
  try {
    if (typeof eng.generatePaperParts === "function") {
      const block = eng.generatePaperParts(topic, { parts: Math.min(4, Math.max(2, Math.ceil(marks / 3))) });
      if (block && block.parts && block.parts.length) {
        return pack(block.parts, block.title, block.diagram);
      }
    }
    const one = eng.generate(topic, { marks });
    return pack([{
      label: `${number}.1`,
      prompt: one.prompt || one.question,
      answer: one.answer,
      explanation: one.explanation || "",
      marks
    }], String(topic).replaceAll("_", " "), one.diagram);
  } catch (e) {
    return pack([{
      label: `${number}.1`,
      prompt: `Discuss a key idea from ${String(topic).replaceAll("_", " ")}.`,
      answer: "See topic notes.",
      explanation: "",
      marks
    }], String(topic).replaceAll("_", " "), null);
  }
}

export function subjectsWithPapers() {
  return Object.keys(BLUEPRINTS);
}


/**
 * Full topic practice paper: textbook / exam-style list of generative questions
 * for a single topic (8–12 items with hierarchical numbering).
 */
export function generateTopicPaper(subjectId, topicId, grade = 10, count = 10) {
  const eng = new MultiSubjectEngine(subjectId, grade);
  const title = String(topicId || "").replaceAll("_", " ");
  const n = Math.max(6, Math.min(14, count || 10));
  const questions = [];
  const seen = new Set();
  for (let i = 0; i < n * 3 && questions.length < n; i++) {
    const useBlock = questions.length % 3 === 0 && typeof eng.generatePaperParts === "function";
    if (useBlock) {
      const block = eng.generatePaperParts(topicId, { parts: 3 });
      if (block && block.parts && block.parts.length) {
        const qn = questions.length + 1;
        const body = block.parts.map((p, pi) => {
          const lab = p.label || `${qn}.${pi + 1}`;
          return `${lab} ${p.prompt || ""}`;
        }).join("\n\n");
        const ans = block.parts.map((p, pi) => {
          const lab = p.label || `${qn}.${pi + 1}`;
          return `${lab} ${p.answer || ""}`;
        }).join("\n");
        const exp = block.parts.map((p, pi) => {
          const lab = p.label || `${qn}.${pi + 1}`;
          return `${lab} ${p.answer || ""}${p.explanation ? " — " + p.explanation : ""}`;
        }).join("\n");
        const key = body.slice(0, 80);
        if (seen.has(key)) continue;
        seen.add(key);
        questions.push({
          number: qn,
          partLabel: String(qn),
          displayNumber: `QUESTION ${qn}`,
          sectionLabel: `QUESTION ${qn}`,
          question: body,
          prompt: body,
          answer: ans,
          explanation: exp,
          marks: block.parts.reduce((s, p) => s + (p.marks || 2), 0),
          topic: topicId,
          topic_name: title,
          parts: block.parts
        });
        continue;
      }
    }
    const one = eng.generate(topicId, { difficulty: 1 + (questions.length % 4) });
    if (!one) continue;
    const prompt = one.question || one.prompt || "";
    if (!prompt || seen.has(prompt.slice(0, 60))) continue;
    seen.add(prompt.slice(0, 60));
    const qn = questions.length + 1;
    questions.push({
      number: qn,
      partLabel: String(qn),
      displayNumber: `QUESTION ${qn}`,
      sectionLabel: `QUESTION ${qn}`,
      question: prompt,
      prompt,
      answer: one.answer,
      explanation: one.explanation || String(one.answer || ""),
      marks: one.marks || 2,
      topic: topicId,
      topic_name: one.topic_name || title,
      diagram: one.diagram || null
    });
  }
  const total = questions.reduce((s, q) => s + (q.marks || 2), 0);
  const pid = `topic_${topicId}_${Date.now()}`;
  return {
    id: pid,
    paper_id: pid,
    title: `${title} — topic practice paper`,
    name: title,
    period: "Topic practice",
    type: "Topic practice",
    subjectId,
    subject: subjectId,
    grade,
    grade_label: `Grade ${grade}`,
    questions,
    total_marks: total,
    marks: total,
    time_minutes: Math.max(30, questions.length * 4),
    source: "Learnly Grade 10 · generative CAPS topic paper · The Elites Academy"
  };
}
