// Strict stars/credits — earned by real work, never free for opening screens.
export const REWARD_TABLE = {
  correct_soft: 1,
  correct_standard: 2,
  correct_hard: 3,
  session_complete: 5,
  session_perfect: 8,
  daily_goal_met: 10,
  streak_bonus_5: 5,
  structured_part: 1,
  structured_full: 12,
  teach_exit: 4,
  sprint_correct: 1,
  sprint_streak_5: 5,
  challenge_complete: 6,
  challenge_perfect: 10
};

// Daily caps so stars can't be farmed endlessly
const DAILY_CAPS = {
  practice: 40,
  sprint: 25,
  structured: 30,
  challenge: 30,
  teach: 15
};

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

export class EconomyEngine {
  constructor(student) {
    this.student = student;
    if (student.credits === undefined) student.credits = 0;
    if (!student.transactions) student.transactions = [];
    if (!student.star_day) student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0 };
    if (student.star_day.date !== todayKey()) {
      student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0 };
    }
  }
  balance() { return this.student.credits || 0; }

  _record(amount, kind, reason) {
    const entry = {
      amount, kind, reason,
      balance_after: this.student.credits,
      timestamp: new Date().toISOString()
    };
    this.student.transactions.push(entry);
    if (this.student.transactions.length > 300) {
      this.student.transactions = this.student.transactions.slice(-300);
    }
    return entry;
  }

  _bucketFor(eventKey) {
    if (eventKey.startsWith("sprint")) return "sprint";
    if (eventKey.startsWith("structured")) return "structured";
    if (eventKey.startsWith("challenge")) return "challenge";
    if (eventKey.startsWith("teach")) return "teach";
    return "practice";
  }

  /** Earn stars for a named event. Respects daily caps. */
  earn(eventKey, note = "") {
    let amount = REWARD_TABLE[eventKey];
    if (amount === undefined) amount = 0;
    if (amount <= 0) return null;

    const day = this.student.star_day;
    if (day.date !== todayKey()) {
      this.student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0 };
    }
    const bucket = this._bucketFor(eventKey);
    const cap = DAILY_CAPS[bucket] ?? 40;
    const used = this.student.star_day[bucket] || 0;
    if (used >= cap) return null; // capped for today

    const room = cap - used;
    const grant = Math.min(amount, room);
    if (grant <= 0) return null;

    this.student.credits = (this.student.credits || 0) + grant;
    this.student.star_day[bucket] = used + grant;
    return this._record(grant, "earn", note || eventKey);
  }

  /** Correct answer reward by difficulty 1–4 */
  earnCorrect(difficulty = 1, note = "Correct") {
    const key = difficulty >= 3 ? "correct_hard" : difficulty >= 2 ? "correct_standard" : "correct_soft";
    return this.earn(key, note);
  }

  // legacy name used around the app
  reward(eventKey, note = "") {
    // map old keys
    const map = {
      correct_answer: "correct_soft",
      session_complete: "session_complete",
      daily_goal_met: "daily_goal_met",
      streak_day: "streak_bonus_5",
      perfect_struct: "structured_full"
    };
    return this.earn(map[eventKey] || eventKey, note);
  }

  spend(amount, reason) {
    amount = Math.abs(Math.trunc(amount));
    if (amount > (this.student.credits || 0)) return false;
    this.student.credits -= amount;
    this._record(-amount, "spend", reason);
    return true;
  }

  history(limit = 20) {
    return [...(this.student.transactions || [])].reverse().slice(0, limit);
  }

  devAdd(amount, reason = "Dev: add") {
    amount = Math.abs(Math.trunc(amount));
    this.student.credits = (this.student.credits || 0) + amount;
    return this._record(amount, "dev", reason);
  }
  devRemove(amount, reason = "Dev: remove") {
    amount = Math.min(Math.abs(Math.trunc(amount)), this.student.credits || 0);
    this.student.credits -= amount;
    return this._record(-amount, "dev", reason);
  }
  devSetBalance(n, reason = "Dev: set") {
    n = Math.max(0, Math.trunc(n));
    const delta = n - (this.student.credits || 0);
    this.student.credits = n;
    return this._record(delta, "dev", reason);
  }
  devSimulatePurchase(name, cost) { return this.spend(cost, `Dev buy: ${name}`); }
  devReset() {
    this.student.credits = 0;
    this.student.transactions = [];
    this.student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0 };
    return this._record(0, "dev", "reset");
  }

  /** One-time starter boost (e.g. 2000 stars). Safe to call repeatedly. */
  grantStarterStars(amount = 2000) {
    if (this.student.flags && this.student.flags.starter_stars_granted) return false;
    this.student.flags = this.student.flags || {};
    this.student.flags.starter_stars_granted = true;
    this.student.credits = (this.student.credits || 0) + amount;
    this.student.transactions = this.student.transactions || [];
    this.student.transactions.push({
      amount,
      reason: "Starter stars",
      timestamp: new Date().toISOString(),
      balance_after: this.student.credits
    });
    return true;
  }

}
