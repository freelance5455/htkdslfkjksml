// Grade R–6 generators — Grade 5 focus: soft adaptive ranges, rich shapes/data/fractions.
import { GradeManager } from "./gradeManager.js";

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a || 1; }

const TOPIC_NAMES = {
  counting: "Counting", shapes_r: "Shapes", sorting: "Sorting", time_r: "Time",
  numbers_20: "Numbers to 20", add_sub_20: "Add & Subtract to 20", shapes_1: "Shapes", measurement_1: "Measurement",
  numbers_99: "Numbers to 99", add_sub_99: "Add & Subtract to 99", repeated_add: "Repeated Addition", shapes_2: "Shapes",
  numbers_999: "Numbers to 999", add_sub_999: "Add & Subtract to 999", mult_tables: "Times Tables",
  division_intro: "Sharing", fractions_intro: "Fractions",
  whole_numbers_4: "Whole Numbers", mult_div_4: "× and ÷", common_fractions_4: "Fractions",
  geometry_4: "Shapes", measurement_4: "Measurement",
  whole_numbers_5: "Whole Numbers", common_fractions_5: "Fractions", decimal_fractions_5: "Decimals",
  geometry_5: "Shapes", data_5: "Data Handling",
  whole_numbers_6: "Whole Numbers", fractions_6: "Fractions", percentages_6: "Percentages",
  ratio_6: "Ratio", geometry_6: "Geometry", data_6: "Data Handling"
};

// Richer shape set for Intermediate Phase
const SHAPES_2D = [
  { name: "triangle", sides: 3, corners: 3 },
  { name: "square", sides: 4, corners: 4 },
  { name: "rectangle", sides: 4, corners: 4 },
  { name: "circle", sides: 0, corners: 0 },
  { name: "pentagon", sides: 5, corners: 5 },
  { name: "hexagon", sides: 6, corners: 6 },
  { name: "octagon", sides: 8, corners: 8 },
  { name: "parallelogram", sides: 4, corners: 4 },
  { name: "rhombus", sides: 4, corners: 4 },
  { name: "trapezium", sides: 4, corners: 4 }
];
const SHAPES_3D = [
  { name: "cube", faces: 6, edges: 12, vertices: 8 },
  { name: "rectangular prism", faces: 6, edges: 12, vertices: 8 },
  { name: "triangular prism", faces: 5, edges: 9, vertices: 6 },
  { name: "square pyramid", faces: 5, edges: 8, vertices: 5 },
  { name: "cylinder", faces: 3, edges: 2, vertices: 0 },
  { name: "cone", faces: 2, edges: 1, vertices: 1 },
  { name: "sphere", faces: 1, edges: 0, vertices: 0 }
];

const DATA_CONTEXTS = [
  { title: "favourite break snacks", unit: "learners", cats: ["Apple", "Chips", "Yoghurt", "Popcorn", "Juice"] },
  { title: "how learners come to school", unit: "learners", cats: ["Walk", "Taxi", "Bus", "Car", "Bicycle"] },
  { title: "goals scored in netball matches", unit: "goals", cats: null },
  { title: "pages read each day", unit: "pages", cats: null },
  { title: "rainfall (mm) over five days", unit: "mm", cats: ["Mon", "Tue", "Wed", "Thu", "Fri"] },
  { title: "beans grown in the garden (cm)", unit: "cm", cats: null },
  { title: "cool-drinks sold at the tuck shop", unit: "drinks", cats: ["Cola", "Juice", "Water", "Fizz"] }
];

function fracHTML(n, d) {
  // Marker the UI can turn into a stacked fraction
  return `⟦FRAC:${n}/${d}⟧`;
}
function fracPlain(n, d) { return `${n}/${d}`; }

function base(topic, q, a, d, hint, exp, diagram = null, extra = {}) {
  return {
    id: `${topic}_${ri(100000, 999999)}`, topic,
    topic_name: TOPIC_NAMES[topic] || topic.replaceAll("_", " "),
    question: q, answer: String(a), difficulty: d, hint, explanation: exp, marks: d,
    diagram, ...extra
  };
}

export class FoundationQuestionEngine {
  constructor(grade) {
    this.gm = new GradeManager(grade);
    this.grade = this.gm.grade;
  }

  generate(topicId, difficulty = 1) {
    this.gm.verifyTopic(topicId);
    const method = this["_" + topicId];
    let q = method ? method.call(this, difficulty) : this._genericArithmetic(topicId, difficulty);
    // Soft numbers: skip strict upper-range fails for Grade 5 soft starts
    const { ok } = this.gm.verifyQuestion(q);
    if (!ok && this.grade >= 5) {
      // accept soft questions; only reject wrong topic
      if (q.topic && !this.gm.hasTopic(q.topic)) q = this._genericArithmetic(topicId, difficulty);
    } else if (!ok) {
      q = this._genericArithmetic(topicId, difficulty);
    }
    return q;
  }

  /** Soft adaptive band: difficulty 1 starts small, grows gradually. */
  _softBand(d, bands) {
    // bands: array of [lo, hi] from easy → hard
    const i = Math.max(0, Math.min(bands.length - 1, (d || 1) - 1));
    return bands[i];
  }

  _range(capLo = null, capHi = null) {
    let [lo, hi] = this.gm.numberRange();
    if (capLo !== null) lo = Math.max(lo, capLo);
    if (capHi !== null) hi = Math.min(hi, capHi);
    return [lo, Math.max(lo + 1, hi)];
  }

  _genericArithmetic(topicId, d) {
    const [lo, hi] = this._softBand(d, [[10, 99], [20, 200], [50, 500], [100, 2000]]);
    let a = ri(lo, hi), b = ri(lo, Math.min(hi, a));
    const op = choice(["+", "-"]);
    if (op === "-" && b > a) [a, b] = [b, a];
    const ans = op === "+" ? a + b : a - b;
    return base(topicId, `Calculate: ${a} ${op} ${b}`, ans, d, `Work step by step.`, `${a} ${op} ${b} = ${ans}.`);
  }

  // ---------- shapes ----------
  _diagramFor(shapeName) {
    if (shapeName === "triangle") return { type: "triangle_bh", b: 10, h: 8 };
    if (shapeName === "rectangle") return { type: "rectangle", l: 12, w: 7 };
    if (shapeName === "square") return { type: "rectangle", l: 8, w: 8 };
    if (shapeName === "circle") return { type: "circle", r: 6 };
    if (shapeName === "pentagon") return { type: "polygon", sides: 5 };
    if (shapeName === "hexagon") return { type: "polygon", sides: 6 };
    if (shapeName === "octagon") return { type: "polygon", sides: 8 };
    if (shapeName === "parallelogram" || shapeName === "rhombus" || shapeName === "trapezium")
      return { type: "rectangle", l: 11, w: 6 };
    return null;
  }

  _shapeQuestion(topicId, d) {
    const mode = choice(["name2d", "sides", "name3d", "faces", "edges", "realworld", "right_angle"]);
    if (mode === "name2d" || mode === "sides") {
      const s = choice(SHAPES_2D);
      const diagram = this._diagramFor(s.name);
      if (mode === "name2d") {
        return base(topicId, "What is the name of this 2D shape?", s.name, d,
          "Count the sides and look at their lengths.", `This shape is a ${s.name}.`, diagram);
      }
      return base(topicId, `How many sides does a ${s.name} have?`, s.sides, d,
        "Sides are the straight edges of the shape (a circle has 0).", `A ${s.name} has ${s.sides} side(s).`);
    }
    if (mode === "name3d" || mode === "faces" || mode === "edges") {
      const s = choice(SHAPES_3D);
      if (mode === "name3d") {
        return base(topicId,
          `A 3D object has ${s.faces} faces, ${s.edges} edges and ${s.vertices} vertices. What could it be?`,
          s.name, d, "Match faces, edges and vertices to a solid you know.", `It matches a ${s.name}.`);
      }
      if (mode === "faces") {
        return base(topicId, `How many faces does a ${s.name} have?`, s.faces, d,
          "Faces are the flat (or curved) surfaces.", `A ${s.name} has ${s.faces} face(s).`);
      }
      return base(topicId, `How many edges does a ${s.name} have?`, s.edges, d,
        "Edges are where two faces meet.", `A ${s.name} has ${s.edges} edge(s).`);
    }
    if (mode === "realworld") {
      const pairs = [
        ["cool-drink can", "cylinder"], ["football", "sphere"], ["dice", "cube"],
        ["cereal box", "rectangular prism"], ["party hat", "cone"], ["tent (simple)", "square pyramid"]
      ];
      const [obj, shape] = choice(pairs);
      return base(topicId, `Which 3D shape best matches a ${obj}?`, shape, d,
        "Think about the faces you can see.", `A ${obj} is best modelled as a ${shape}.`);
    }
    // right angle
    return base(topicId, "How many right angles does a rectangle have?", 4, d,
      "A right angle is 90° — like the corner of a book.", "A rectangle has 4 right angles.");
  }

  // ---------- data ----------
  _buildDataset(d) {
    const ctx = choice(DATA_CONTEXTS);
    if (ctx.cats) {
      const freqs = ctx.cats.map(() => ri(2, d >= 3 ? 18 : 12));
      return { ctx, kind: "categorical", cats: ctx.cats, freqs, values: freqs };
    }
    const n = d >= 3 ? 7 : 5;
    const values = Array.from({ length: n }, () => ri(1, d >= 3 ? 30 : 15));
    return { ctx, kind: "numeric", cats: null, freqs: null, values };
  }

  _stats(values) {
    const sorted = [...values].sort((a, b) => a - b);
    const n = sorted.length;
    const sum = sorted.reduce((a, b) => a + b, 0);
    const mean = Math.round((sum / n) * 10) / 10;
    const median = n % 2 ? sorted[(n - 1) / 2] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
    const counts = {};
    sorted.forEach((v) => { counts[v] = (counts[v] || 0) + 1; });
    const maxc = Math.max(...Object.values(counts));
    const modes = Object.keys(counts).filter((k) => counts[k] === maxc).map(Number);
    const mode = modes.length === n ? "none" : modes.join(" & ");
    const range = sorted[n - 1] - sorted[0];
    return { sum, mean, median, mode, range, min: sorted[0], max: sorted[n - 1], n };
  }

  _data_5(d) {
    // Mix single-skill and story questions; multi-part lives in structuredEngine
    const ds = this._buildDataset(d);
    const st = this._stats(ds.values);
    const mode = choice(["mean", "median", "mode", "range", "total", "most", "compare", "sentence"]);

    if (ds.kind === "categorical") {
      const rows = ds.cats.map((c, i) => `${c}: ${ds.freqs[i]}`).join(", ");
      if (mode === "total" || mode === "mean") {
        return base("data_5",
          `A class recorded ${ds.ctx.title}:\n${rows}\nHow many ${ds.ctx.unit} were surveyed in total?`,
          st.sum, d, "Add all the frequencies.", `Total = ${st.sum}.`);
      }
      if (mode === "most" || mode === "mode") {
        const i = ds.freqs.indexOf(Math.max(...ds.freqs));
        return base("data_5",
          `Favourite survey — ${ds.ctx.title}:\n${rows}\nWhich was most popular?`,
          ds.cats[i], d, "Look for the largest number.", `${ds.cats[i]} was most popular.`);
      }
      if (mode === "compare") {
        const i = 0, j = Math.min(1, ds.cats.length - 1);
        const diff = Math.abs(ds.freqs[i] - ds.freqs[j]);
        return base("data_5",
          `${ds.ctx.title}:\n${rows}\nHow many more chose ${ds.freqs[i] >= ds.freqs[j] ? ds.cats[i] : ds.cats[j]} than ${ds.freqs[i] >= ds.freqs[j] ? ds.cats[j] : ds.cats[i]}?`,
          diff, d, "Subtract the smaller frequency from the larger.", `Difference = ${diff}.`);
      }
    }

    const list = ds.values.join(", ");
    if (mode === "mean") {
      return base("data_5", `Find the mean of: ${list}`, st.mean, d,
        "Add all values, then divide by how many there are.", `Sum ${st.sum} ÷ ${st.n} = ${st.mean}.`);
    }
    if (mode === "median") {
      return base("data_5", `Find the median of: ${list}`, st.median, d,
        "Order the numbers, then pick the middle.", `Median = ${st.median}.`);
    }
    if (mode === "mode") {
      return base("data_5", `Find the mode of: ${list}`, st.mode, d,
        "Mode is the value that appears most often.", `Mode = ${st.mode}.`);
    }
    if (mode === "range") {
      return base("data_5", `Find the range of: ${list}`, st.range, d,
        "Range = largest − smallest.", `${st.max} − ${st.min} = ${st.range}.`);
    }
    if (mode === "sentence" || mode === "mean") {
      // attach a simple bar chart diagram for visual data
      const diagram = { type: "bar_chart", values: ds.values.slice(0, 5), labels: ds.values.slice(0, 5).map((_, i) => String(i + 1)) };
      return base("data_5", `The bar graph shows values: ${list}.\nWhat is the mean?`, st.mean, d,
        "Add all, divide by how many.", `Mean = ${st.mean}.`, diagram);
    }
    return base("data_5", `What is the largest value in: ${list}?`, st.max, d,
      "Scan for the biggest number.", `Maximum = ${st.max}.`);
  }

  /** Full structured multi-part data question (3.1–3.6 style). */
  generateStructuredData(difficulty = 2) {
    const d = difficulty;
    const ds = this._buildDataset(Math.max(2, d));
    const st = this._stats(ds.values);
    let stimulus, parts;

    if (ds.kind === "categorical") {
      const tableRows = ds.cats.map((c, i) => ({ cat: c, freq: ds.freqs[i] }));
      const topI = ds.freqs.indexOf(Math.max(...ds.freqs));
      const lowI = ds.freqs.indexOf(Math.min(...ds.freqs));
      stimulus = {
        type: "table",
        title: `The Grade 5 class surveyed ${ds.ctx.title}.`,
        headers: ["Category", "Number of " + ds.ctx.unit],
        rows: tableRows.map((r) => [r.cat, String(r.freq)])
      };
      parts = [
        { id: "3.1", prompt: `How many ${ds.ctx.unit} were surveyed in total?`, answer: String(st.sum), marks: 2, kind: "number" },
        { id: "3.2", prompt: "Which category was the most popular?", answer: ds.cats[topI], marks: 1, kind: "text" },
        { id: "3.3", prompt: "Which category was the least popular?", answer: ds.cats[lowI], marks: 1, kind: "text" },
        { id: "3.4", prompt: `How many more ${ds.ctx.unit} chose ${ds.cats[topI]} than ${ds.cats[lowI]}?`, answer: String(ds.freqs[topI] - ds.freqs[lowI]), marks: 2, kind: "number" },
        { id: "3.5", prompt: "What is the mode of this data?", answer: ds.cats[topI], marks: 1, kind: "text" },
        { id: "3.6", prompt: `Write one sentence about what the class prefers (${ds.ctx.title}).`, answer: `Most learners chose ${ds.cats[topI]}.`, marks: 2, kind: "sentence", soft: true }
      ];
    } else {
      stimulus = {
        type: "list",
        title: `Thando recorded ${ds.ctx.title}: ${ds.values.join(", ")}.`,
        headers: null, rows: null
      };
      parts = [
        { id: "3.1", prompt: "How many values were recorded?", answer: String(st.n), marks: 1, kind: "number" },
        { id: "3.2", prompt: "What is the mean?", answer: String(st.mean), marks: 2, kind: "number" },
        { id: "3.3", prompt: "What is the median?", answer: String(st.median), marks: 2, kind: "number" },
        { id: "3.4", prompt: "What is the mode? (or none)", answer: String(st.mode), marks: 1, kind: "text" },
        { id: "3.5", prompt: "What is the range?", answer: String(st.range), marks: 1, kind: "number" },
        { id: "3.6", prompt: "Write one sentence describing this set of data.", answer: `The values range from ${st.min} to ${st.max}.`, marks: 2, kind: "sentence", soft: true }
      ];
    }

    return {
      id: `struct_data_${ri(100000, 999999)}`,
      number: 3,
      topic: "data_5",
      topic_name: "Data Handling",
      title: stimulus.title,
      stimulus,
      parts,
      totalMarks: parts.reduce((s, p) => s + p.marks, 0),
      difficulty: d
    };
  }

  // ---------- Grade 5 whole numbers (SOFT START) ----------
  _whole_numbers_5(d) {
    const band = this._softBand(d, [[50, 900], [100, 4000], [500, 50000], [1000, 200000]]);
    const mode = choice(["round10", "round100", "round1000", "place", "compare", "expand", "add", "sub"]);
    const n = ri(band[0], band[1]);

    if (mode === "round10") {
      const r = Math.round(n / 10) * 10;
      return base("whole_numbers_5", `Round ${n} to the nearest 10.`, r, d, "Look at the ones digit.", `${n} → ${r}.`,
        { type: "number_line", value: n, roundTo: 10 });
    }
    if (mode === "round100") {
      const r = Math.round(n / 100) * 100;
      return base("whole_numbers_5", `Round ${n} to the nearest 100.`, r, d, "Look at the tens digit.", `${n} → ${r}.`,
        { type: "number_line", value: n, roundTo: 100 });
    }
    if (mode === "round1000" && n >= 500) {
      const r = Math.round(n / 1000) * 1000;
      return base("whole_numbers_5", `Round ${n} to the nearest 1 000.`, r, d, "Look at the hundreds digit.", `${n} → ${r}.`,
        { type: "number_line", value: n, roundTo: 1000 });
    }
    if (mode === "place") {
      const s = String(n);
      const pos = ri(0, s.length - 1);
      const digit = s[pos];
      const value = Number(digit) * Math.pow(10, s.length - 1 - pos);
      return base("whole_numbers_5", `What is the value of the digit ${digit} in ${n}?`, value, d,
        "Use place value: units, tens, hundreds…", `The value is ${value}.`);
    }
    if (mode === "compare") {
      let a = ri(band[0], band[1]), b = ri(band[0], band[1]);
      while (a === b) b = ri(band[0], band[1]);
      const bigger = Math.max(a, b);
      return base("whole_numbers_5", `Which is greater: ${a} or ${b}?`, bigger, d, "Compare place values from the left.", `${bigger} is greater.`);
    }
    if (mode === "expand") {
      const s = String(n);
      const parts = [];
      for (let i = 0; i < s.length; i++) {
        if (s[i] !== "0") parts.push(String(Number(s[i]) * Math.pow(10, s.length - 1 - i)));
      }
      return base("whole_numbers_5", `Expand ${n}.`, parts.join(" + "), d, "Write each digit’s place value.", `${n} = ${parts.join(" + ")}.`);
    }
    if (mode === "add") {
      const a = ri(band[0], band[1]), b = ri(Math.floor(band[0] / 2), Math.floor(band[1] / 2));
      return base("whole_numbers_5", `Calculate: ${a} + ${b}`, a + b, d, "Add ones, tens, hundreds…", `${a} + ${b} = ${a + b}.`);
    }
    let a = ri(band[0], band[1]), b = ri(Math.floor(band[0] / 2), a);
    return base("whole_numbers_5", `Calculate: ${a} − ${b}`, a - b, d, "Subtract carefully.", `${a} − ${b} = ${a - b}.`);
  }

  // ---------- fractions (stacked markers) ----------
  _common_fractions_5(d) {
    const dens = d <= 1 ? [2, 3, 4] : d === 2 ? [2, 3, 4, 5, 6, 8] : [2, 3, 4, 5, 6, 8, 10, 12];
    const den = choice(dens);
    const mode = choice(["of", "add_same", "compare", "equivalent", "shade_words"]);

    if (mode === "of") {
      const n = ri(1, den - 1);
      const whole = den * ri(d <= 1 ? 2 : 2, d <= 1 ? 5 : 8);
      const ans = Math.floor(whole * n / den);
      return base("common_fractions_5",
        `Calculate ${fracHTML(n, den)} of ${whole}.`, ans, d,
        `Divide ${whole} by ${den}, then multiply by ${n}.`,
        `(${whole} ÷ ${den}) × ${n} = ${ans}.`,
        null, { display_fraction: true });
    }
    if (mode === "add_same") {
      let n1 = ri(1, den - 1), n2 = ri(1, den - 1);
      if (n1 + n2 > den && d <= 2) { n1 = 1; n2 = 1; }
      const total = n1 + n2;
      const g = gcd(total, den);
      const ans = g > 1 && d >= 2 ? `${total / g}/${den / g}` : `${total}/${den}`;
      return base("common_fractions_5",
        `Calculate: ${fracHTML(n1, den)} + ${fracHTML(n2, den)}`,
        ans, d, "Same denominator — add the numerators.",
        `${n1}/${den} + ${n2}/${den} = ${total}/${den}.`,
        null, { display_fraction: true });
    }
    if (mode === "compare") {
      const n1 = ri(1, den - 1);
      let n2 = ri(1, den - 1);
      while (n2 === n1) n2 = ri(1, den - 1);
      const bigger = n1 > n2 ? `${n1}/${den}` : `${n2}/${den}`;
      return base("common_fractions_5",
        `Which is greater: ${fracHTML(n1, den)} or ${fracHTML(n2, den)}?`,
        bigger, d, "Same denominator — the larger numerator is greater.",
        `${bigger} is greater.`, null, { display_fraction: true });
    }
    if (mode === "equivalent") {
      const n = ri(1, Math.min(3, den - 1));
      const k = ri(2, 3);
      return base("common_fractions_5",
        `Complete: ${fracHTML(n, den)} = ${fracHTML("?", den * k)}\nWhat is the missing numerator?`,
        n * k, d, "Multiply numerator and denominator by the same number.",
        `${n}/${den} = ${n * k}/${den * k}.`, null, { display_fraction: true });
    }
    return base("common_fractions_5",
      `A pizza is cut into ${den} equal slices. You eat ${ri(1, den - 1)}. What fraction is left? (as a/b)`,
      `${den - 1}/${den}`, d, "Whole minus the part eaten.",
      `Left = ${den - 1}/${den}.`, null, { display_fraction: true });
  }

  _decimal_fractions_5(d) {
    const band = this._softBand(d, [[1, 20], [1, 50], [1, 100], [1, 200]]);
    const mode = choice(["add", "sub", "order", "money", "from_frac"]);
    if (mode === "add") {
      const a = ri(band[0], band[1]) / 10, b = ri(band[0], band[1]) / 10;
      const ans = Math.round((a + b) * 10) / 10;
      return base("decimal_fractions_5", `Calculate: ${a} + ${b}`, ans, d, "Line up the decimal points.", `${a} + ${b} = ${ans}.`);
    }
    if (mode === "sub") {
      let a = ri(band[0], band[1]) / 10, b = ri(band[0], band[1]) / 10;
      if (b > a) [a, b] = [b, a];
      const ans = Math.round((a - b) * 10) / 10;
      return base("decimal_fractions_5", `Calculate: ${a} − ${b}`, ans, d, "Line up the decimal points.", `${a} − ${b} = ${ans}.`);
    }
    if (mode === "money") {
      const r = ri(5, 40), c = ri(0, 95);
      const paid = r + 10;
      const change = Math.round((paid - (r + c / 100)) * 100) / 100;
      return base("decimal_fractions_5",
        `A book costs R${r}.${String(c).padStart(2, "0")}. You pay R${paid}. What change do you get (in rand)?`,
        change, d, "Subtract the price from what you paid.", `Change = R${change}.`);
    }
    if (mode === "from_frac") {
      const den = choice([2, 4, 5, 10]);
      const n = ri(1, den - 1);
      const dec = Math.round((n / den) * 100) / 100;
      return base("decimal_fractions_5",
        `Write ${fracHTML(n, den)} as a decimal.`, dec, d, `Divide ${n} by ${den}.`,
        `${n} ÷ ${den} = ${dec}.`, null, { display_fraction: true });
    }
    const a = ri(10, 90) / 10, b = ri(10, 90) / 10;
    const bigger = Math.max(a, b);
    return base("decimal_fractions_5", `Which is greater: ${a} or ${b}?`, bigger, d, "Compare tenths, then hundredths.", `${bigger} is greater.`);
  }

  _geometry_5(d) { return this._shapeQuestion("geometry_5", d); }

  // ---- lower grades kept simple ----
  _counting(d) { const n = ri(1, 10); return base("counting", `Count: ${"●".repeat(n)}\nHow many?`, n, d, "Count one by one.", `${n}.`); }
  _shapes_r(d) { return this._shapeQuestion("shapes_r", d); }
  _sorting(d) { const x = ri(1, 9), y = ri(1, 9); return base("sorting", `Which is bigger: ${x} or ${y}?`, Math.max(x, y), d, "Compare.", `${Math.max(x, y)}.`); }
  _time_r(d) { const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]; const i = ri(0, 5); return base("time_r", `Day after ${days[i]}?`, days[i + 1], d, "Days of the week.", days[i + 1]); }
  _numbers_20(d) { const n = ri(1, 19); return base("numbers_20", `Number after ${n}?`, n + 1, d, "+1", `${n + 1}`); }
  _add_sub_20(d) { let a = ri(1, 20), b = ri(1, 20); if (b > a) [a, b] = [b, a]; const op = choice(["+", "-"]); const ans = op === "+" ? a + b : a - b; return base("add_sub_20", `${a} ${op} ${b}`, ans, d, "Count.", `${ans}`); }
  _shapes_1(d) { return this._shapeQuestion("shapes_1", d); }
  _measurement_1(d) { return base("measurement_1", "Which is heavier: an elephant or a mouse?", "an elephant", d, "Think size.", "elephant"); }
  _numbers_99(d) { const n = ri(10, 98); return base("numbers_99", `Number before ${n}?`, n - 1, d, "-1", `${n - 1}`); }
  _add_sub_99(d) { return this._genericArithmetic("add_sub_99", d); }
  _repeated_add(d) { const n = ri(2, 5), t = ri(2, 5); return base("repeated_add", Array(t).fill(n).join(" + "), n * t, d, "×", `${n * t}`); }
  _shapes_2(d) { return this._shapeQuestion("shapes_2", d); }
  _numbers_999(d) { const n = ri(100, 999); return base("numbers_999", `Round ${n} to nearest 10.`, Math.round(n / 10) * 10, d, "Ones digit.", `${Math.round(n / 10) * 10}`); }
  _add_sub_999(d) { return this._genericArithmetic("add_sub_999", d); }
  _mult_tables(d) { const a = ri(1, 10), b = ri(1, 10); return base("mult_tables", `${a} × ${b}`, a * b, d, "Tables", `${a * b}`); }
  _division_intro(d) { const b = ri(2, 10), q = ri(2, 10); return base("division_intro", `Share ${b * q} between ${b}. Each gets?`, q, d, "÷", `${q}`); }
  _fractions_intro(d) { const whole = choice([4, 8, 12]); const den = choice([2, 4]); return base("fractions_intro", `One ${den === 2 ? "half" : "quarter"} of ${whole}?`, whole / den, d, "Divide", `${whole / den}`); }
  _whole_numbers_4(d) { const n = ri(100, 4000); return base("whole_numbers_4", `Round ${n} to nearest 100.`, Math.round(n / 100) * 100, d, "Tens", `${Math.round(n / 100) * 100}`); }
  _mult_div_4(d) { const a = ri(2, 12), b = ri(2, 12); return base("mult_div_4", `${a} × ${b}`, a * b, d, "×", `${a * b}`); }
  _common_fractions_4(d) { return this._common_fractions_5(d); }
  _geometry_4(d) { return this._shapeQuestion("geometry_4", d); }
  _measurement_4(d) { const cm = ri(100, 500); return base("measurement_4", `${cm} cm in metres?`, cm / 100, d, "÷100", `${cm / 100}`); }
  _whole_numbers_6(d) { return this._whole_numbers_5(Math.min(4, d + 1)); }
  _fractions_6(d) { return this._common_fractions_5(d); }
  _percentages_6(d) { const w = choice([50, 100, 200]), p = choice([10, 25, 50]); return base("percentages_6", `${p}% of ${w}`, w * p / 100, d, "%", `${w * p / 100}`); }
  _ratio_6(d) { const a = ri(2, 12), b = ri(2, 12), g = gcd(a, b); return base("ratio_6", `Simplify ${a}:${b}`, `${a / g}:${b / g}`, d, "HCF", `${a / g}:${b / g}`); }
  _geometry_6(d) { return this._shapeQuestion("geometry_6", d); }
  _data_6(d) { return this._data_5(d); }
}
