import { GradeManager } from "./gradeManager.js";
import { QuestionEngine } from "./questionEngine.js";
import { FoundationQuestionEngine } from "./foundationEngine.js";
import { FetQuestionEngine } from "./fetEngine.js";
import { PhysSciEngine, isPhysSciTopic } from "./physSciEngine.js";
import { MultiSubjectEngine, isMultiSubjectTopic } from "./multiSubjectEngine.js";

function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

export class UnifiedQuestionEngine {
  constructor(grade) {
    this.gm = new GradeManager(grade);
    this.grade = this.gm.grade;
    this._senior = this.gm.isSeniorPhase() ? new QuestionEngine() : null;
    this._fet = this.gm.isFetPhase() ? new FetQuestionEngine(this.grade) : null;
    this._foundation = (!this.gm.isSeniorPhase() && !this.gm.isFetPhase())
      ? new FoundationQuestionEngine(this.grade)
      : null;
    this._phys = (this.grade >= 10) ? new PhysSciEngine() : null;
    this._multi = new MultiSubjectEngine();
  }
  topics() { return this.gm.topics(); }
  topicIds() { return this.gm.topicIds(); }

  generate(topicId = null, difficulty = 1) {
    if (isPhysSciTopic(topicId) && this._phys) {
      return this._phys.generate(topicId, difficulty);
    }
    if (isMultiSubjectTopic(topicId) && this._multi) {
      return this._multi.generate(topicId, difficulty);
    }
    if (!topicId || !this.gm.hasTopic(topicId)) topicId = choice(this.gm.topicIds());
    this.gm.verifyTopic(topicId);

    let q;
    if (this._fet) {
      q = this._fet.generate(topicId, difficulty);
    } else if (this.gm.isSeniorPhase()) {
      const scaled = Math.max(1, Math.min(4, Math.round(difficulty * this.gm.difficultyScale())));
      q = this._senior.generate(topicId, scaled);
    } else {
      q = this._foundation.generate(topicId, difficulty);
    }

    const { ok } = this.gm.verifyQuestion(q);
    if (!ok) {
      if (this._fet) {
        q = this._fet.generate(topicId, 1);
      } else if (this._foundation) {
        try { q = this._foundation.generate(topicId, 1); } catch {
          q = this._foundation._genericArithmetic(topicId, difficulty);
        }
      } else if (this._senior) {
        q = this._senior.generate(topicId, 1);
      }
    }
    return q;
  }

  generateStructured(topicId = "data_5", difficulty = 2) {
    if (this._foundation && typeof this._foundation.generateStructuredData === "function") {
      if (!topicId || topicId.includes("data")) return this._foundation.generateStructuredData(difficulty);
    }
    const parts = [];
    let total = 0;
    for (let i = 1; i <= 6; i++) {
      const q = this.generate(topicId, difficulty);
      parts.push({
        id: `3.${i}`,
        prompt: q.question,
        answer: q.answer,
        marks: q.marks || 1,
        kind: "text",
        hint: q.hint,
        explanation: q.explanation
      });
      total += q.marks || 1;
    }
    return {
      id: `struct_${topicId}_${Date.now()}`,
      number: 3,
      topic: topicId,
      topic_name: topicId,
      title: "Structured practice question",
      stimulus: { type: "text", title: "Answer each part." },
      parts,
      totalMarks: total,
      difficulty
    };
  }

  /** CAPS multi-part paper blocks (e.g. full QUESTION 1 for equations). */
  generatePaperParts(topicId, difficulty = 2) {
    if (isPhysSciTopic(topicId) && this._phys) {
      return this._phys.generatePaperParts(topicId, difficulty);
    }
    if (isMultiSubjectTopic(topicId) && this._multi) {
      return this._multi.generatePaperParts(topicId, difficulty);
    }
    if (this._fet && typeof this._fet.generatePaperParts === "function") {
      return this._fet.generatePaperParts(topicId, difficulty);
    }
    return [this.generate(topicId, difficulty)];
  }

}
