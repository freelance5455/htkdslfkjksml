/**
 * Theorem / formula mastery engine — CAPS Grade 10–11 focused.
 * Interaction patterns inspired by Mathematical Theorem Master:
 * drag-fill, type-in, and match pairs.
 */

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Core CAPS theorem / formula bank for FET phase */
export const THEOREM_BANK = [
  {
    id: "quadratic_formula",
    name: "Quadratic Formula",
    topic: "equations_inequalities",
    formula: "x = (−b ± √(b² − 4ac)) / (2a)",
    hint: "For ax² + bx + c = 0, provided a ≠ 0.",
    explanation: {
      formula: "x = (−b ± √(b² − 4ac)) / (2a)",
      steps: [
        "Identify a, b and c from ax² + bx + c = 0.",
        "Compute the discriminant Δ = b² − 4ac.",
        "If Δ ≥ 0, substitute into the formula.",
        "Simplify each root carefully."
      ]
    },
    // Drag slots: fill the formula blanks
    slots: [
      { prompt: "Numerator starts with", answer: "−b", options: ["−b", "b", "−a", "2a"] },
      { prompt: "Under the square root", answer: "b² − 4ac", options: ["b² − 4ac", "b² + 4ac", "2a", "a² − 4bc"] },
      { prompt: "Denominator", answer: "2a", options: ["2a", "a", "2b", "b"] }
    ],
    match: [
      { left: "Discriminant Δ", right: "b² − 4ac" },
      { left: "Two equal real roots", right: "Δ = 0" },
      { left: "No real roots", right: "Δ < 0" },
      { left: "Two distinct real roots", right: "Δ > 0" }
    ]
  },
  {
    id: "discriminant",
    name: "Nature of Roots",
    topic: "equations_inequalities",
    formula: "Δ = b² − 4ac",
    hint: "Sign of Δ tells you about the roots.",
    explanation: {
      formula: "Δ = b² − 4ac",
      steps: [
        "Δ > 0 → two distinct real roots",
        "Δ = 0 → two equal real roots (repeated root)",
        "Δ < 0 → no real roots (complex conjugate pair)"
      ]
    },
    slots: [
      { prompt: "Δ > 0 means", answer: "two distinct real roots", options: ["two distinct real roots", "no real roots", "equal roots", "infinite roots"] },
      { prompt: "Δ = 0 means", answer: "equal real roots", options: ["equal real roots", "no real roots", "three roots", "undefined"] }
    ],
    match: [
      { left: "Δ > 0", right: "Two distinct real roots" },
      { left: "Δ = 0", right: "Equal real roots" },
      { left: "Δ < 0", right: "Non-real roots" }
    ]
  },
  {
    id: "distance_formula",
    name: "Distance Formula",
    topic: "analytical_geometry",
    formula: "d = √[(x₂−x₁)² + (y₂−y₁)²]",
    hint: "Derived from Pythagoras in the coordinate plane.",
    explanation: {
      formula: "d = √[(x₂−x₁)² + (y₂−y₁)²]",
      steps: [
        "Find horizontal change: x₂ − x₁",
        "Find vertical change: y₂ − y₁",
        "Apply Pythagoras: d² = (Δx)² + (Δy)²",
        "Take the positive square root."
      ]
    },
    slots: [
      { prompt: "Inside the square root (x-part)", answer: "(x₂−x₁)²", options: ["(x₂−x₁)²", "x₂−x₁", "(x₂+x₁)²", "2x"] },
      { prompt: "Inside the square root (y-part)", answer: "(y₂−y₁)²", options: ["(y₂−y₁)²", "y₂−y₁", "(y₂+y₁)²", "2y"] }
    ],
    match: [
      { left: "Distance AB", right: "√[(x_B−x_A)² + (y_B−y_A)²]" },
      { left: "Horizontal change", right: "x₂ − x₁" },
      { left: "Vertical change", right: "y₂ − y₁" }
    ]
  },
  {
    id: "midpoint",
    name: "Midpoint Formula",
    topic: "analytical_geometry",
    formula: "M = ((x₁+x₂)/2 ; (y₁+y₂)/2)",
    hint: "Average the coordinates.",
    explanation: {
      formula: "M = ((x₁+x₂)/2 ; (y₁+y₂)/2)",
      steps: [
        "Add the x-coordinates and divide by 2.",
        "Add the y-coordinates and divide by 2.",
        "Write the midpoint as an ordered pair."
      ]
    },
    slots: [
      { prompt: "x-coordinate of midpoint", answer: "(x₁+x₂)/2", options: ["(x₁+x₂)/2", "x₁−x₂", "(x₁−x₂)/2", "x₁/2"] },
      { prompt: "y-coordinate of midpoint", answer: "(y₁+y₂)/2", options: ["(y₁+y₂)/2", "y₁−y₂", "(y₁−y₂)/2", "y₂/2"] }
    ],
    match: [
      { left: "Midpoint x", right: "(x₁ + x₂) / 2" },
      { left: "Midpoint y", right: "(y₁ + y₂) / 2" }
    ]
  },
  {
    id: "gradient",
    name: "Gradient of a Line",
    topic: "analytical_geometry",
    formula: "m = (y₂ − y₁) / (x₂ − x₁)",
    hint: "Rise over run. Undefined when x₂ = x₁ (vertical line).",
    explanation: {
      formula: "m = (y₂ − y₁) / (x₂ − x₁)",
      steps: [
        "Compute change in y (rise).",
        "Compute change in x (run).",
        "Divide rise by run.",
        "If run = 0, the gradient is undefined."
      ]
    },
    slots: [
      { prompt: "Numerator (rise)", answer: "y₂ − y₁", options: ["y₂ − y₁", "x₂ − x₁", "y₂ + y₁", "x₂ + x₁"] },
      { prompt: "Denominator (run)", answer: "x₂ − x₁", options: ["x₂ − x₁", "y₂ − y₁", "x₂ + x₁", "2x"] }
    ],
    match: [
      { left: "Horizontal line", right: "m = 0" },
      { left: "Vertical line", right: "m undefined" },
      { left: "Parallel lines", right: "Equal gradients" },
      { left: "Perpendicular lines", right: "m₁ × m₂ = −1" }
    ]
  },
  {
    id: "exponent_laws",
    name: "Laws of Exponents",
    topic: "exponents_surds",
    formula: "aᵐ × aⁿ = aᵐ⁺ⁿ ;  (aᵐ)ⁿ = aᵐⁿ ;  a⁰ = 1",
    hint: "Same base required for the product and quotient laws.",
    explanation: {
      formula: "aᵐ × aⁿ = aᵐ⁺ⁿ",
      steps: [
        "Product: add exponents when bases match.",
        "Power of a power: multiply exponents.",
        "Quotient: subtract exponents.",
        "a⁰ = 1 (a ≠ 0); a⁻ⁿ = 1/aⁿ."
      ]
    },
    slots: [
      { prompt: "aᵐ × aⁿ =", answer: "aᵐ⁺ⁿ", options: ["aᵐ⁺ⁿ", "aᵐⁿ", "aᵐ⁻ⁿ", "2aᵐⁿ"] },
      { prompt: "(aᵐ)ⁿ =", answer: "aᵐⁿ", options: ["aᵐⁿ", "aᵐ⁺ⁿ", "aᵐ⁻ⁿ", "naᵐ"] },
      { prompt: "a⁰ =", answer: "1", options: ["1", "0", "a", "undefined"] }
    ],
    match: [
      { left: "aᵐ × aⁿ", right: "aᵐ⁺ⁿ" },
      { left: "(aᵐ)ⁿ", right: "aᵐⁿ" },
      { left: "aᵐ / aⁿ", right: "aᵐ⁻ⁿ" },
      { left: "a⁻ⁿ", right: "1/aⁿ" }
    ]
  },
  {
    id: "arithmetic_sequence",
    name: "Arithmetic Sequence",
    topic: "number_patterns",
    formula: "Tₙ = a + (n−1)d ;  Sₙ = n/2 [2a + (n−1)d]",
    hint: "Constant difference d between consecutive terms.",
    explanation: {
      formula: "Tₙ = a + (n − 1)d",
      steps: [
        "a is the first term.",
        "d is the common difference.",
        "The n-th term is a plus (n−1) steps of d.",
        "Sum of first n terms: Sₙ = n/2 × (first + last)."
      ]
    },
    slots: [
      { prompt: "General term Tₙ", answer: "a + (n−1)d", options: ["a + (n−1)d", "a + nd", "arⁿ⁻¹", "n/2(a+d)"] },
      { prompt: "Sum Sₙ (form with a and d)", answer: "n/2[2a+(n−1)d]", options: ["n/2[2a+(n−1)d]", "n(a+d)", "a+(n−1)d", "n/2 × d"] }
    ],
    match: [
      { left: "Common difference", right: "d = T₂ − T₁" },
      { left: "n-th term", right: "a + (n−1)d" },
      { left: "Sum of n terms", right: "n/2 [2a + (n−1)d]" }
    ]
  },
  {
    id: "geometric_sequence",
    name: "Geometric Sequence",
    topic: "number_patterns",
    formula: "Tₙ = arⁿ⁻¹ ;  Sₙ = a(rⁿ − 1)/(r − 1)  (r ≠ 1)",
    hint: "Constant ratio r between consecutive terms.",
    explanation: {
      formula: "Tₙ = a rⁿ⁻¹",
      steps: [
        "a is the first term.",
        "r is the common ratio.",
        "Each term multiplies the previous by r.",
        "Sum formula differs when |r| < 1 for infinite series (Grade 12)."
      ]
    },
    slots: [
      { prompt: "General term Tₙ", answer: "arⁿ⁻¹", options: ["arⁿ⁻¹", "a+(n−1)d", "arⁿ", "n ar"] },
      { prompt: "Common ratio", answer: "T₂/T₁", options: ["T₂/T₁", "T₂−T₁", "T₁/T₂", "a/r"] }
    ],
    match: [
      { left: "Common ratio", right: "r = T₂ / T₁" },
      { left: "n-th term", right: "a rⁿ⁻¹" },
      { left: "Sum (r ≠ 1)", right: "a(rⁿ − 1)/(r − 1)" }
    ]
  },
  {
    id: "sohcahtoa",
    name: "Trigonometric Ratios",
    topic: "trigonometry",
    formula: "sin θ = opposite/hypotenuse ; cos θ = adjacent/hypotenuse ; tan θ = opposite/adjacent",
    hint: "SOH CAH TOA — right-angled triangles only for these definitions.",
    explanation: {
      formula: "sin θ = O/H ; cos θ = A/H ; tan θ = O/A",
      steps: [
        "Identify the reference angle θ.",
        "Label opposite, adjacent and hypotenuse.",
        "Choose the ratio that uses the sides you know / need.",
        "Solve for the unknown side or angle."
      ]
    },
    slots: [
      { prompt: "sin θ =", answer: "opposite/hypotenuse", options: ["opposite/hypotenuse", "adjacent/hypotenuse", "opposite/adjacent", "hypotenuse/opposite"] },
      { prompt: "cos θ =", answer: "adjacent/hypotenuse", options: ["adjacent/hypotenuse", "opposite/hypotenuse", "opposite/adjacent", "adjacent/opposite"] },
      { prompt: "tan θ =", answer: "opposite/adjacent", options: ["opposite/adjacent", "adjacent/opposite", "opposite/hypotenuse", "adjacent/hypotenuse"] }
    ],
    match: [
      { left: "SOH", right: "sin = opposite / hypotenuse" },
      { left: "CAH", right: "cos = adjacent / hypotenuse" },
      { left: "TOA", right: "tan = opposite / adjacent" }
    ]
  },
  {
    id: "compound_interest",
    name: "Compound Interest",
    topic: "finance_11",
    formula: "A = P(1 + i)ⁿ",
    hint: "i is the decimal interest rate per compounding period; n is the number of periods.",
    explanation: {
      formula: "A = P(1 + i)ⁿ",
      steps: [
        "P = principal (starting amount).",
        "i = interest rate per period as a decimal.",
        "n = number of compounding periods.",
        "A = final amount."
      ]
    },
    slots: [
      { prompt: "Final amount A =", answer: "P(1+i)ⁿ", options: ["P(1+i)ⁿ", "P + in", "P(1−i)ⁿ", "Piⁿ"] },
      { prompt: "i represents", answer: "rate per period (decimal)", options: ["rate per period (decimal)", "number of years", "principal", "final amount"] }
    ],
    match: [
      { left: "P", right: "Principal" },
      { left: "i", right: "Interest rate (decimal)" },
      { left: "n", right: "Number of periods" },
      { left: "A", right: "Final amount" }
    ]
  },
  {
    id: "straight_line",
    name: "Equation of a Straight Line",
    topic: "functions_graphs",
    formula: "y = mx + c",
    hint: "m is gradient; c is y-intercept.",
    explanation: {
      formula: "y = mx + c",
      steps: [
        "m = gradient of the line.",
        "c = y-value where the line cuts the y-axis.",
        "Point-gradient form: y − y₁ = m(x − x₁).",
        "Two-point form uses the gradient between two known points."
      ]
    },
    slots: [
      { prompt: "Gradient-intercept form", answer: "y = mx + c", options: ["y = mx + c", "y = mx − c", "x = my + c", "y = m + xc"] },
      { prompt: "c represents", answer: "y-intercept", options: ["y-intercept", "x-intercept", "gradient", "midpoint"] }
    ],
    match: [
      { left: "m", right: "Gradient" },
      { left: "c", right: "y-intercept" },
      { left: "x-intercept", right: "Set y = 0 and solve" },
      { left: "Parallel to y = 2x + 1", right: "Same m = 2" }
    ]
  },
  {
    id: "centre_circumference",
    name: "Angle at the Centre",
    topic: "euclidean_geometry",
    formula: "∠ at centre = 2 × ∠ at circumference (same arc)",
    hint: "The angle subtended by an arc at the centre is twice the angle at the circumference.",
    explanation: {
      formula: "∠AOB = 2 × ∠ACB (arc AB)",
      steps: [
        "Identify the common arc (e.g. arc AB).",
        "∠AOB is at the centre O.",
        "∠ACB is at the circumference on the remaining part of the circle.",
        "Then ∠AOB = 2 × ∠ACB."
      ]
    },
    slots: [
      { prompt: "Centre angle vs circumference", answer: "twice", options: ["twice", "half", "equal", "three times"] },
      { prompt: "Must share the same", answer: "arc", options: ["arc", "chord length", "radius only", "tangent"] }
    ],
    match: [
      { left: "∠ at centre", right: "2 × ∠ at circumference" },
      { left: "Same arc required", right: "Yes" },
      { left: "Reason in exams", right: "∠ at centre = 2 × ∠ at circumference" }
    ]
  },
  {
    id: "same_segment",
    name: "Angles in the Same Segment",
    topic: "euclidean_geometry",
    formula: "Angles in the same segment are equal",
    hint: "Angles standing on the same chord/arc in the same segment are equal.",
    explanation: {
      formula: "∠ACB = ∠ADB (same segment on arc AB)",
      steps: [
        "Identify the chord (or arc) that both angles stand on.",
        "Confirm both angles are in the same segment of the circle.",
        "Conclude the angles are equal."
      ]
    },
    slots: [
      { prompt: "Angles in the same segment are", answer: "equal", options: ["equal", "supplementary", "complementary", "double"] },
      { prompt: "They stand on the same", answer: "chord / arc", options: ["chord / arc", "radius", "tangent", "diameter only"] }
    ],
    match: [
      { left: "Same segment", right: "Angles equal" },
      { left: "Common feature", right: "Same chord or arc" }
    ]
  },
  {
    id: "cyclic_quad",
    name: "Cyclic Quadrilateral",
    topic: "euclidean_geometry",
    formula: "Opposite angles of a cyclic quadrilateral sum to 180°",
    hint: "A cyclic quadrilateral can be inscribed in a circle.",
    explanation: {
      formula: "∠ABC + ∠ADC = 180°",
      steps: [
        "Confirm ABCD is cyclic (all four vertices on one circle).",
        "Opposite angles are supplementary.",
        "Exam reason: opp. ∠s of cyclic quad."
      ]
    },
    slots: [
      { prompt: "Opposite angles of cyclic quad", answer: "sum to 180°", options: ["sum to 180°", "are equal", "sum to 90°", "are complementary"] },
      { prompt: "Exam reason short form", answer: "opp. ∠s of cyclic quad", options: ["opp. ∠s of cyclic quad", "vertically opposite", "co-interior", "corresponding"] }
    ],
    match: [
      { left: "Opposite angles", right: "Supplementary (180°)" },
      { left: "Exterior angle of cyclic quad", right: "Equals opposite interior angle" }
    ]
  },
  {
    id: "tangent_chord",
    name: "Tangent–Chord Theorem",
    topic: "euclidean_geometry",
    formula: "∠ between tangent and chord = ∠ in alternate segment",
    hint: "Also called the alternate segment theorem.",
    explanation: {
      formula: "∠(tangent, chord AB) = ∠ACB in alternate segment",
      steps: [
        "Identify the tangent and the chord from the point of contact.",
        "Find the angle in the alternate segment.",
        "Those two angles are equal.",
        "Exam reason: tan-chord / alternate segment."
      ]
    },
    slots: [
      { prompt: "Tangent–chord angle equals", answer: "∠ in alternate segment", options: ["∠ in alternate segment", "∠ at centre", "half the arc", "vertically opposite angle"] },
      { prompt: "Also known as", answer: "alternate segment theorem", options: ["alternate segment theorem", "corresponding angles", "co-interior angles", "Pythagoras"] }
    ],
    match: [
      { left: "Tangent–chord angle", right: "Angle in alternate segment" },
      { left: "Radius to point of contact", right: "Perpendicular to tangent" }
    ]
  },
  {
    id: "exterior_cyclic",
    name: "Exterior Angle of Cyclic Quad",
    topic: "euclidean_geometry",
    formula: "Exterior ∠ of cyclic quad = opposite interior ∠",
    hint: "Produce one side of the cyclic quadrilateral.",
    explanation: {
      formula: "If AB produced to E, ∠CBE = ∠ADC",
      steps: [
        "Produce a side of the cyclic quadrilateral.",
        "The exterior angle equals the opposite interior angle.",
        "Exam reason: ext. ∠ of cyclic quad."
      ]
    },
    slots: [
      { prompt: "Exterior angle equals", answer: "opposite interior angle", options: ["opposite interior angle", "adjacent interior angle", "half centre angle", "vertically opposite"] }
    ],
    match: [
      { left: "Exterior ∠ of cyclic quad", right: "Opposite interior ∠" }
    ]
  },
  {
    id: "radius_tangent",
    name: "Radius ⊥ Tangent",
    topic: "euclidean_geometry",
    formula: "Radius to point of contact ⊥ tangent",
    hint: "OA ⊥ tangent at A when O is the centre.",
    explanation: {
      formula: "OA ⊥ tangent at A",
      steps: [
        "O is the centre; tangent touches at A.",
        "Then OA is perpendicular to the tangent.",
        "Often creates right-angled triangles for Pythagoras or trig."
      ]
    },
    slots: [
      { prompt: "Radius to contact point is", answer: "perpendicular to the tangent", options: ["perpendicular to the tangent", "parallel to the tangent", "equal to the chord", "half the tangent"] }
    ],
    match: [
      { left: "Radius to contact", right: "⊥ tangent" },
      { left: "Two tangents from external point", right: "Equal lengths" }
    ]
  },
  {
    id: "equal_radii",
    name: "Equal Radii (Isosceles)",
    topic: "euclidean_geometry",
    formula: "Radii equal ⇒ isosceles triangle (base angles equal)",
    hint: "Any two radii of the same circle are equal.",
    explanation: {
      formula: "OA = OB ⇒ ∠OAB = ∠OBA",
      steps: [
        "OA and OB are radii ⇒ OA = OB.",
        "△OAB is isosceles.",
        "Base angles are equal: ∠OAB = ∠OBA = (180° − ∠AOB)/2."
      ]
    },
    slots: [
      { prompt: "Two radii of same circle are", answer: "equal", options: ["equal", "perpendicular", "parallel", "tangents"] },
      { prompt: "Triangle formed by two radii is", answer: "isosceles", options: ["isosceles", "equilateral always", "right-angled always", "scalene"] }
    ],
    match: [
      { left: "OA = OB (radii)", right: "Isosceles △OAB" },
      { left: "Base angles", right: "Equal" }
    ]
  },
,

  {
    id: "coulombs_law",
    name: "Coulomb's Law",
    topic: "ps_electrostatics",
    formula: "F = k Q₁Q₂ / r²",
    hint: "k = 9,0 × 10⁹ N·m²·C⁻². Convert units to SI.",
    explanation: { formula: "F = k Q₁Q₂ / r²", steps: ["Convert nC/μC and cm to C and m.", "Substitute into Coulomb's law.", "Like charges: repulsion."] },
    slots: [
      { prompt: "Force is proportional to", answer: "Q₁Q₂", options: ["Q₁Q₂", "Q₁ + Q₂", "r²", "k only"] },
      { prompt: "Force is inversely proportional to", answer: "r²", options: ["r²", "r", "Q₁Q₂", "k"] }
    ],
    match: [
      { left: "k", right: "9,0 × 10⁹ N·m²·C⁻²" },
      { left: "Like charges", right: "Repel" }
    ]
  },
  {
    id: "newton_2",
    name: "Newton's Second Law",
    topic: "ps_newtons_laws",
    formula: "F_net = ma",
    hint: "Net force, not a single applied force.",
    explanation: { formula: "F_net = ma", steps: ["Draw a free-body diagram.", "Find F_net.", "a = F_net / m."] },
    slots: [
      { prompt: "F_net equals", answer: "ma", options: ["ma", "mv", "mg only", "μN"] }
    ],
    match: [
      { left: "F_net", right: "ma" },
      { left: "Weight", right: "mg" }
    ]
  },
  {
    id: "ohm_law",
    name: "Ohm's Law",
    topic: "ps_circuits",
    formula: "V = IR",
    hint: "At constant temperature for ohmic conductors.",
    explanation: { formula: "V = IR", steps: ["V is potential difference.", "I is current.", "R is resistance."] },
    slots: [
      { prompt: "V equals", answer: "IR", options: ["IR", "I/R", "I²R", "V/I"] }
    ],
    match: [
      { left: "P", right: "VI" },
      { left: "Series resistance", right: "R₁ + R₂" }
    ]
  },
  {
    id: "wave_equation",
    name: "Wave equation",
    topic: "ps_waves",
    formula: "v = f λ",
    hint: "Speed = frequency × wavelength.",
    explanation: { formula: "v = fλ", steps: ["f in Hz.", "λ in metres.", "v in m·s⁻¹."] },
    slots: [
      { prompt: "v equals", answer: "fλ", options: ["fλ", "f/λ", "λ/f", "f + λ"] }
    ],
    match: [
      { left: "T", right: "1/f" },
      { left: "λ", right: "Crest to crest" }
    ]
  },

];

export class TheoremEngine {
  constructor(grade = 11) {
    this.grade = grade;
  }

  list(topicFilter = null) {
    let bank = THEOREM_BANK;
    if (topicFilter) bank = bank.filter((t) => t.topic === topicFilter);
    // Grade 11 only — no foundation-only items in this bank
    return bank;
  }

  get(id) {
    return THEOREM_BANK.find((t) => t.id === id) || null;
  }

  /** Build a drag-fill round from a theorem */
  buildDragRound(theoremId = null) {
    const th = theoremId ? this.get(theoremId) : choice(this.list());
    if (!th) return null;
    const slots = (th.slots || []).map((s, i) => ({
      id: `slot_${i}`,
      prompt: s.prompt,
      answer: s.answer,
      options: shuffle([s.answer, ...s.options.filter((o) => o !== s.answer)].slice(0, 4))
    }));
    const allOptions = shuffle([...new Set(slots.flatMap((s) => s.options))]);
    return {
      id: th.id,
      name: th.name,
      formula: th.formula,
      hint: th.hint,
      explanation: th.explanation,
      topic: th.topic,
      mode: "drag",
      slots,
      options: allOptions
    };
  }

  /** Build a matching round */
  buildMatchRound(theoremId = null) {
    const th = theoremId ? this.get(theoremId) : choice(this.list());
    if (!th || !th.match) return this.buildDragRound(theoremId);
    const pairs = th.match.map((p, i) => ({ id: i, left: p.left, right: p.right }));
    return {
      id: th.id,
      name: th.name,
      formula: th.formula,
      hint: th.hint,
      explanation: th.explanation,
      topic: th.topic,
      mode: "match",
      pairs,
      leftOrder: shuffle(pairs.map((p) => p.id)),
      rightOrder: shuffle(pairs.map((p) => p.id))
    };
  }

  /** Type-in: ask for the formula itself */
  buildTypeRound(theoremId = null) {
    const th = theoremId ? this.get(theoremId) : choice(this.list());
    if (!th) return null;
    return {
      id: th.id,
      name: th.name,
      formula: th.formula,
      hint: th.hint,
      explanation: th.explanation,
      topic: th.topic,
      mode: "type",
      prompt: `Write the formula for: ${th.name}`,
      answer: th.formula
    };
  }

  randomRound(mode = null) {
    const m = mode || choice(["drag", "match", "type"]);
    if (m === "match") return this.buildMatchRound();
    if (m === "type") return this.buildTypeRound();
    return this.buildDragRound();
  }
}
