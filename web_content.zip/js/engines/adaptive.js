// Port of engine/adaptive.py — deterministic local "AI-like" recommendation logic.
// Always derives its topic pool from the student's own mastery dict (grade-correct
// because it's built by createDefaultStudent()/GradeManager) — never a hardcoded list.
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

export class AdaptiveEngine {
  constructor(student) {
    this.student = student;
    this.mastery = student.mastery = student.mastery || {};
  }
  _topics() { const k = Object.keys(this.mastery); return k.length ? k : ["number_sense"]; }

  chooseTopic(mode = "recommended") {
    const items = Object.entries(this.mastery);
    if (!items.length) return this._topics()[0];
    if (mode === "weakness") return items.reduce((m, x) => (x[1] < m[1] ? x : m))[0];
    if (mode === "strength") return items.reduce((m, x) => (x[1] > m[1] ? x : m))[0];
    if (mode === "mixed" || mode === "daily") return choice(this._topics());
    items.sort((a, b) => a[1] - b[1]);
    const pool = items.slice(0, Math.max(3, Math.floor(items.length / 2)));
    return choice(pool)[0];
  }
  chooseTopics(mode, n = 1) { return Array.from({ length: n }, () => this.chooseTopic(mode)); }

  recommendDifficulty(topic) {
    // Soft start: unknown topics begin at Foundation (1); climb only with proven mastery.
    const m = this.mastery[topic];
    if (m === undefined || m === null) return 1;
    if (m < 0.35) return 1;
    if (m < 0.55) return 2;
    if (m < 0.75) return 3;
    return 4;
  }

  recommendationText() {
    const items = Object.entries(this.mastery).sort((a, b) => a[1] - b[1]);
    if (!items.length) return "Start with a mixed practice session to build your profile.";
    const [weakest, m] = items[0];
    const name = weakest.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
    if (m < 0.4) return `Your ${name} mastery is low. Start with the topic notes before practising.`;
    if (m < 0.65) return `Focus on ${name} — a short weakness-recovery session will help.`;
    return "You're doing well across topics. Try a Mixed or Speed challenge.";
  }

  nextAction(topic, accuracy, avgTimeSec) {
    const m = this.mastery[topic] ?? 0.5;
    if (m < 0.4) return "Open Teach, then try again.";
    if (accuracy >= 0.8 && avgTimeSec && avgTimeSec > 40) return "Try a speed run.";
    if (accuracy < 0.5 && avgTimeSec && avgTimeSec < 15) return "Slow down a bit.";
    if (m > 0.85) return "Hard mode?";
    return "Keep practising.";
  }
}
