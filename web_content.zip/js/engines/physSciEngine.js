/**
 * Grade 11 Physical Sciences question engine — CAPS Paper 1 (Physics)
 * and Paper 2 (Chemistry). Generative, no static paper images.
 */

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function round2(x) { return Math.round(x * 100) / 100; }

function base(topic, question, answer, difficulty, hint, explanation, diagram = null, marks = 3) {
  return {
    id: `ps_${topic}_${ri(10000, 99999)}`,
    topic,
    topic_name: topic.replace(/^ps_/, "").replaceAll("_", " "),
    subject: "physical_sciences",
    question,
    answer,
    difficulty,
    hint: hint || "",
    explanation: explanation || "",
    diagram,
    marks,
    capsFormat: true
  };
}

export const PS_TOPICS = [
  "ps_vectors", "ps_newtons_laws", "ps_gravitation",
  "ps_electrostatics", "ps_electromagnetism", "ps_circuits", "ps_waves",
  "ps_bonding", "ps_imf", "ps_stoich", "ps_energy_chem", "ps_acids_bases", "ps_redox"
];

export class PhysSciEngine {
  generate(topicId, difficulty = 2) {
    const d = Math.max(1, Math.min(4, difficulty | 0));
    const map = {
      ps_vectors: () => this._vectors(d),
      ps_newtons_laws: () => this._newton(d),
      ps_gravitation: () => this._gravity(d),
      ps_electrostatics: () => this._electro(d),
      ps_electromagnetism: () => this._emag(d),
      ps_circuits: () => this._circuit(d),
      ps_waves: () => this._waves(d),
      ps_bonding: () => this._bonding(d),
      ps_imf: () => this._imf(d),
      ps_stoich: () => this._stoich(d),
      ps_energy_chem: () => this._energyChem(d),
      ps_acids_bases: () => this._acids(d),
      ps_redox: () => this._redox(d)
    };
    const fn = map[topicId] || map.ps_newton;
    return fn();
  }

  generatePaperParts(topicId, difficulty = 2) {
    if (topicId === "ps_newtons_laws") return this._structNewton();
    if (topicId === "ps_electrostatics") return this._structElectro();
    if (topicId === "ps_circuits") return this._structCircuits();
    if (topicId === "ps_vectors") return this._structVectors();
    const n = 4;
    const out = [];
    for (let i = 0; i < n; i++) {
      const q = this.generate(topicId, difficulty);
      q.partLabel = `1.${i + 1}`;
      q.qMain = 1;
      q.sectionLabel = `QUESTION 1 — ${q.topic_name}`;
      out.push(q);
    }
    return out;
  }

  _expand(parts, topic, sectionLabel, qMain) {
    return parts.map((p) => ({
      id: `ps_${topic}_${ri(10000, 99999)}_${p.partLabel}`,
      topic,
      topic_name: topic.replace(/^ps_/, "").replaceAll("_", " "),
      subject: "physical_sciences",
      sectionLabel,
      qMain,
      partLabel: p.partLabel,
      question: p.question,
      answer: p.answer,
      explanation: p.explanation || "",
      hint: p.hint || "",
      marks: p.marks || 3,
      diagram: p.diagram || null,
      capsFormat: true,
      difficulty: 2
    }));
  }

  _structNewton() {
    const m = ri(4, 12);
    const F = ri(20, 60);
    const mu = choice([0.2, 0.25, 0.3]);
    const N = round2(m * 9.8);
    const fk = round2(mu * N);
    const a = round2((F - fk) / m);
    return this._expand([
      {
        partLabel: "3.1", marks: 2,
        question: `A crate of mass ${m} kg rests on a rough horizontal surface.\nDraw a labelled free-body diagram while a horizontal force of ${F} N acts on it.`,
        answer: "Weight mg down, normal N up, applied F, friction opposite to F",
        explanation: "Four forces on the free-body diagram.",
        diagram: { type: "free_body", mass: m, forces: [{ label: "F", dir: "right" }, { label: "f", dir: "left" }, { label: "N", dir: "up" }, { label: "mg", dir: "down" }] }
      },
      {
        partLabel: "3.2", marks: 3,
        question: `The coefficient of kinetic friction is ${mu}. Take g = 9,8 m·s⁻².\nCalculate the magnitude of the kinetic frictional force.`,
        answer: String(fk),
        explanation: `N = ${m}×9,8 = ${N} N\nfₖ = ${mu}×${N} = ${fk} N.`,
        hint: "fₖ = μₖN"
      },
      {
        partLabel: "3.3", marks: 4,
        question: `Calculate the acceleration of the crate while the ${F} N force acts.`,
        answer: String(a),
        explanation: `F_net = ${F} − ${fk} = ${round2(F - fk)} N\na = ${a} m·s⁻².`,
        hint: "F_net = ma"
      },
      {
        partLabel: "3.4", marks: 3,
        question: `State Newton's Third Law in words.`,
        answer: "When body A exerts a force on B, B exerts an equal and opposite force on A.",
        explanation: "Equal magnitude, opposite direction, different objects."
      }
    ], "ps_newtons_laws", "QUESTION 3 — Newton's Laws", 3);
  }

  _structElectro() {
    const q1 = choice([2, 3, 4]);
    const q2 = choice([-5, -4, -3, 5, 6]);
    const r = choice([20, 25, 30]);
    const k = 9e9;
    const F = Math.abs((k * (q1 * 1e-9) * (q2 * 1e-9)) / ((r / 100) ** 2));
    const attractive = q2 < 0;
    return this._expand([
      {
        partLabel: "8.1", marks: 2,
        question: "State Coulomb's law in words.",
        answer: "The electrostatic force between two point charges is directly proportional to the product of the charges and inversely proportional to the square of the distance between them."
      },
      {
        partLabel: "8.2", marks: 4,
        question: `Two point charges of ${q1} nC and ${q2} nC are ${r} cm apart in air.\nCalculate the magnitude of the electrostatic force between them.\nUse k = 9,0 × 10⁹ N·m²·C⁻².`,
        answer: F.toExponential(2) + " N",
        explanation: `r = ${r / 100} m\nF = k|Q₁Q₂|/r² ≈ ${F.toExponential(2)} N.`,
        diagram: { type: "coulomb", q1, q2, r }
      },
      {
        partLabel: "8.3", marks: 2,
        question: "Is the force attractive or repulsive? Give a reason.",
        answer: attractive ? "Attractive — unlike signs" : "Repulsive — like signs",
        explanation: attractive ? "One positive, one negative ⇒ attract." : "Same sign ⇒ repel."
      },
      {
        partLabel: "8.4", marks: 4,
        question: "The spheres touch and are returned to the same separation. Explain how the force changes (qualitatively).",
        answer: "Charge is shared on contact; new charges are each (Q₁+Q₂)/2; force is then calculated with Coulomb's law.",
        explanation: "Conservation of charge; identical spheres share equally."
      }
    ], "ps_electrostatics", "QUESTION 8 — Electrostatics", 8);
  }

  _structCircuits() {
    const V = choice([12, 18, 24]);
    const R1 = choice([2, 3, 4, 6]);
    const R2 = choice([3, 4, 6, 8]);
    const Rs = R1 + R2;
    const I = round2(V / Rs);
    const V1 = round2(I * R1);
    return this._expand([
      {
        partLabel: "10.1", marks: 2,
        question: "State Ohm's law in words.",
        answer: "The potential difference across a conductor is directly proportional to the current through it, at constant temperature."
      },
      {
        partLabel: "10.2", marks: 3,
        question: `Resistors of ${R1} Ω and ${R2} Ω are connected in series across a ${V} V battery (internal resistance negligible).\nCalculate the equivalent resistance.`,
        answer: String(Rs),
        explanation: `R = ${R1}+${R2} = ${Rs} Ω.`,
        diagram: { type: "circuit_series", R1, R2, V }
      },
      {
        partLabel: "10.3", marks: 3,
        question: "Calculate the current in the circuit.",
        answer: String(I),
        explanation: `I = V/R = ${V}/${Rs} = ${I} A.`
      },
      {
        partLabel: "10.4", marks: 3,
        question: `Calculate the potential difference across the ${R1} Ω resistor.`,
        answer: String(V1),
        explanation: `V₁ = IR₁ = ${I}×${R1} = ${V1} V.`
      },
      {
        partLabel: "10.5", marks: 3,
        question: `Calculate the power dissipated in the ${R2} Ω resistor.`,
        answer: String(round2(I * I * R2)),
        explanation: `P = I²R = (${I})²×${R2} = ${round2(I * I * R2)} W.`
      }
    ], "ps_circuits", "QUESTION 10 — Electric circuits", 10);
  }

  _structVectors() {
    const ax = ri(5, 12), ay = ri(5, 12);
    const R = round2(Math.sqrt(ax * ax + ay * ay));
    const th = round2(Math.atan2(ay, ax) * 180 / Math.PI);
    return this._expand([
      {
        partLabel: "2.1", marks: 2,
        question: "Define a resultant vector.",
        answer: "A single vector that has the same effect as two or more vectors acting together."
      },
      {
        partLabel: "2.2", marks: 4,
        question: `Two perpendicular forces of ${ax} N east and ${ay} N north act on a point.\nCalculate the magnitude of the resultant.`,
        answer: String(R),
        explanation: `R = √(${ax}²+${ay}²) = ${R} N.`,
        diagram: { type: "vectors_2d", vx: ax, vy: ay }
      },
      {
        partLabel: "2.3", marks: 3,
        question: "Calculate the direction of the resultant relative to the east axis.",
        answer: `${th}° north of east`,
        explanation: `θ = tan⁻¹(${ay}/${ax}) ≈ ${th}°.`
      }
    ], "ps_vectors", "QUESTION 2 — Vectors", 2);
  }


  _vectors(d) {
    const ax = ri(3, 12), ay = ri(3, 12);
    const r = round2(Math.sqrt(ax * ax + ay * ay));
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_vectors",
        `Two perpendicular vectors have magnitudes ${ax} N (east) and ${ay} N (north).\nCalculate the magnitude of the resultant (2 d.p.).`,
        r, d, "R = √(Rx² + Ry²)",
        `R = √(${ax}² + ${ay}²) = ${r} N.`,
        { type: "vectors_2d", vx: ax, vy: ay }, 4);
    }
    if (roll === 1) {
      const theta = round2(Math.atan2(ay, ax) * 180 / Math.PI);
      return base("ps_vectors",
        `A force of ${ax} N acts east and ${ay} N acts north.\nCalculate the direction of the resultant relative to the east axis (degrees, 2 d.p.).`,
        theta, d, "θ = tan⁻¹(Ry/Rx)",
        `θ = tan⁻¹(${ay}/${ax}) ≈ ${theta}°.`,
        { type: "vectors_2d", vx: ax, vy: ay }, 3);
    }
    return base("ps_vectors",
      `Resolve a ${ax + ay} N force acting at 90° into perpendicular components if one component is ${ax} N along the x-axis.\nWhat is the y-component?`,
      ay, d, "Pythagoras: Ry = √(R² − Rx²) if they form a right triangle, or use given pair.",
      `From the pair used here the north component is ${ay} N.`,
      { type: "vectors_2d", vx: ax, vy: ay }, 3);
  }

  _newton(d) {
    const roll = ri(0, 3);
    if (roll === 0) {
      const m = ri(2, 10), a = ri(2, 6);
      const F = m * a;
      return base("ps_newtons_laws",
        `A ${m} kg object accelerates at ${a} m·s⁻² on a frictionless surface.\nCalculate the net force (N).`,
        F, d, "F_net = ma",
        `F_net = ${m} × ${a} = ${F} N.`,
        { type: "free_body", mass: m, forces: [{ label: "Fnet", dir: "right" }] }, 3);
    }
    if (roll === 1) {
      return base("ps_newtons_laws",
        `State Newton's Third Law in words.`,
        "When object A exerts a force on B, B exerts an equal and opposite force on A.",
        d, "Action–reaction pairs.",
        "The two forces are equal in magnitude, opposite in direction, and act on different objects.",
        null, 3);
    }
    if (roll === 2) {
      const m = ri(4, 12), g = 9.8, mu = choice([0.2, 0.3, 0.4]);
      const N = round2(m * g);
      const f = round2(mu * N);
      return base("ps_newtons_laws",
        `A ${m} kg crate rests on a horizontal surface. μₖ = ${mu}. Take g = 9,8 m·s⁻².\nCalculate the magnitude of the kinetic frictional force (N, 2 d.p.).`,
        f, d, "fₖ = μₖ N and N = mg on a horizontal surface",
        `N = ${m} × 9,8 = ${N} N\nfₖ = ${mu} × ${N} = ${f} N.`,
        { type: "free_body", mass: m, forces: [{ label: "N", dir: "up" }, { label: "mg", dir: "down" }, { label: "fk", dir: "left" }] }, 4);
    }
    const m = ri(2, 8), F = ri(20, 50), f = ri(5, 15);
    const a = round2((F - f) / m);
    return base("ps_newtons_laws",
      `A ${m} kg block is pulled with ${F} N. Friction is ${f} N.\nCalculate the acceleration (m·s⁻², 2 d.p.).`,
      a, d, "F_net = F − f = ma",
      `F_net = ${F} − ${f} = ${F - f} N\na = ${F - f}/${m} = ${a} m·s⁻².`,
      { type: "free_body", mass: m, forces: [{ label: "F", dir: "right" }, { label: "f", dir: "left" }] }, 4);
  }

  _gravity(d) {
    const G = 6.67e-11;
    const m1 = ri(2, 8);
    const m2 = ri(3, 9);
    const r = ri(2, 6);
    // Use simplified numbers: F = G m1 m2 / r^2 with G given
    const F = (G * m1 * m2) / (r * r);
    const sci = F.toExponential(2);
    return base("ps_gravitation",
      `Use G = 6,67 × 10⁻¹¹ N·m²·kg⁻².\nTwo masses ${m1} kg and ${m2} kg are ${r} m apart.\nCalculate the gravitational force between them (scientific notation, 2 s.f.).`,
      sci, d, "F = G m₁m₂ / r²",
      `F = (6,67×10⁻¹¹)(${m1})(${m2}) / (${r})² ≈ ${sci} N.`,
      null, 4);
  }

  _electro(d) {
    const roll = ri(0, 2);
    const k = 9e9;
    if (roll === 0) {
      const q1 = choice([2, 3, 4]); // nC
      const q2 = choice([2, 3, 5]);
      const r = choice([2, 3, 4]); // cm → convert
      const F = (k * (q1 * 1e-9) * (q2 * 1e-9)) / ((r / 100) ** 2);
      return base("ps_electrostatics",
        `Two point charges of ${q1} nC and ${q2} nC are ${r} cm apart in air.\nUse k = 9,0 × 10⁹ N·m²·C⁻². Calculate F (N, 2 s.f. scientific notation).`,
        F.toExponential(2), d, "Coulomb: F = k Q₁Q₂ / r² (r in metres)",
        `r = ${r / 100} m\nF = (9×10⁹)(${q1}×10⁻⁹)(${q2}×10⁻⁹)/(${r / 100})² ≈ ${F.toExponential(2)} N.`,
        { type: "coulomb", q1, q2, r }, 5);
    }
    if (roll === 1) {
      return base("ps_electrostatics",
        `State Coulomb's law in words.`,
        "The force between two point charges is directly proportional to the product of the charges and inversely proportional to the square of the distance between them.",
        d, "F ∝ Q₁Q₂ / r²",
        "Direction: like charges repel; unlike charges attract.",
        { type: "coulomb", q1: 2, q2: -3, r: 3 }, 3);
    }
    const Q = choice([2, 4, 5]); // μC
    const r = choice([2, 4, 5]);
    const E = (k * Q * 1e-6) / (r * r);
    return base("ps_electrostatics",
      `Calculate the electric field strength ${r} m from a point charge of ${Q} μC.\nk = 9,0 × 10⁹ N·m²·C⁻². Answer in N·C⁻¹ (scientific notation, 2 s.f.).`,
      E.toExponential(2), d, "E = kQ / r²",
      `E = (9×10⁹)(${Q}×10⁻⁶)/(${r})² ≈ ${E.toExponential(2)} N·C⁻¹.`,
      null, 4);
  }

  _emag(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_electromagnetism",
        `A current-carrying straight wire produces a magnetic field. Which rule gives the field direction?`,
        "Right-hand rule (thumb = current, fingers = field)",
        d, "Right-hand rule for a straight conductor.",
        "Point the thumb in the conventional current direction; curled fingers show B-field circles.",
        { type: "solenoid" }, 2);
    }
    if (roll === 1) {
      return base("ps_electromagnetism",
        `State Faraday's law in words.`,
        "The induced emf is equal to the negative rate of change of magnetic flux linkage.",
        d, "ε = −N ΔΦ/Δt",
        "Lenz's law gives the negative sign (opposes the change).",
        null, 3);
    }
    const N = ri(20, 80), dPhi = choice([0.02, 0.04, 0.05]), dt = choice([0.1, 0.2, 0.25]);
    const emf = round2(N * dPhi / dt);
    return base("ps_electromagnetism",
      `A coil of ${N} turns experiences a flux change of ${dPhi} Wb in ${dt} s.\nCalculate the magnitude of the induced emf (V).`,
      emf, d, "ε = N ΔΦ / Δt",
      `ε = ${N} × ${dPhi} / ${dt} = ${emf} V.`,
      { type: "solenoid" }, 4);
  }

  _circuit(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      const V = ri(6, 24), R = choice([2, 3, 4, 6, 8, 12]);
      const I = round2(V / R);
      return base("ps_circuits",
        `A resistor of ${R} Ω is connected across ${V} V.\nCalculate the current (A).`,
        I, d, "Ohm: I = V / R",
        `I = ${V}/${R} = ${I} A.`,
        { type: "circuit_simple", V, R }, 3);
    }
    if (roll === 1) {
      const R1 = choice([2, 3, 4, 6]), R2 = choice([2, 3, 4, 6]);
      const rs = R1 + R2;
      return base("ps_circuits",
        `${R1} Ω and ${R2} Ω are connected in series.\nCalculate the equivalent resistance (Ω).`,
        rs, d, "Series: R = R₁ + R₂",
        `R = ${R1} + ${R2} = ${rs} Ω.`,
        { type: "circuit_series", R1, R2 }, 2);
    }
    const V = ri(8, 24), I = choice([2, 3, 4]);
    const P = V * I;
    return base("ps_circuits",
      `A device operates at ${V} V and draws ${I} A.\nCalculate the power (W).`,
      P, d, "P = VI",
      `P = ${V} × ${I} = ${P} W.`,
      { type: "circuit_simple", V, R: round2(V / I) }, 3);
  }

  _waves(d) {
    const f = choice([2, 4, 5, 10]) * 10; // Hz
    const lam = choice([2, 4, 5, 8]); // m
    const v = f * lam;
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_waves",
        `A wave has frequency ${f} Hz and wavelength ${lam} m.\nCalculate the wave speed (m·s⁻¹).`,
        v, d, "v = f λ",
        `v = ${f} × ${lam} = ${v} m·s⁻¹.`,
        { type: "wave", lambda: lam }, 3);
    }
    if (roll === 1) {
      const T = round2(1 / f);
      return base("ps_waves",
        `A wave has frequency ${f} Hz.\nCalculate the period (s).`,
        T, d, "T = 1/f",
        `T = 1/${f} = ${T} s.`,
        { type: "wave", lambda: lam }, 2);
    }
    return base("ps_waves",
      `Define wavelength.`,
      "The distance between two successive points in phase on a wave (e.g. crest to crest).",
      d, "Symbol λ.",
      "Measured in metres.",
      { type: "wave", lambda: 4 }, 2);
  }

  _bonding(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_bonding",
        `Which type of bond forms between two non-metal atoms that share electrons?`,
        "Covalent bond", d, "Sharing of electron pairs.",
        "Metals + non-metals typically form ionic bonds; two non-metals form covalent bonds.",
        { type: "lewis_pair" }, 2);
    }
    if (roll === 1) {
      return base("ps_bonding",
        `A bond-energy vs bond-length graph has a minimum. What does the depth of the well represent?`,
        "Bond energy (energy released when the bond forms / needed to break it)",
        d, "Minimum = most stable bond length.",
        "The x-value at the minimum is the bond length; the well depth is the bond energy.",
        { type: "energy_profile", exo: true }, 3);
    }
    return base("ps_bonding",
      `How many valence electrons does a Group 16 element have?`,
      6, d, "Group number ≈ valence electrons for main-group elements.",
      "Group 16 elements have 6 valence electrons.",
      null, 2);
  }

  _imf(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_imf",
        `Name the strongest intermolecular force in liquid water.`,
        "Hydrogen bonding", d, "H bonded to N, O or F.",
        "Water has O–H bonds; hydrogen bonds form between molecules.",
        null, 2);
    }
    if (roll === 1) {
      return base("ps_imf",
        `Which generally has the higher boiling point: a substance with only London forces, or one with hydrogen bonds (similar size)?`,
        "The one with hydrogen bonds",
        d, "Stronger IMF → more energy to separate molecules.",
        "Hydrogen bonds are stronger than London forces for similar molecular size.",
        null, 2);
    }
    return base("ps_imf",
      `Define intermolecular forces.`,
      "Forces of attraction between molecules.",
      d, "Not the same as chemical bonds inside a molecule.",
      "Examples: London, dipole–dipole, hydrogen bonding.",
      null, 2);
  }

  _stoich(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      const n = choice([0.25, 0.5, 1, 2]);
      const V = round2(n * 22.4);
      return base("ps_stoich",
        `Calculate the volume (dm³) occupied by ${n} mol of an ideal gas at STP.\nMolar volume = 22,4 dm³·mol⁻¹.`,
        V, d, "V = n × 22,4 dm³ at STP",
        `V = ${n} × 22,4 = ${V} dm³.`,
        null, 3);
    }
    if (roll === 1) {
      const m = ri(8, 40);
      const M = choice([16, 18, 32, 44]);
      const n = round2(m / M);
      return base("ps_stoich",
        `Calculate the number of moles in ${m} g of a substance with M = ${M} g·mol⁻¹.`,
        n, d, "n = m / M",
        `n = ${m}/${M} = ${n} mol.`,
        null, 3);
    }
    const n = choice([0.1, 0.2, 0.5]);
    const V = choice([0.25, 0.5, 1]);
    const c = round2(n / V);
    return base("ps_stoich",
      `A solution contains ${n} mol of solute in ${V} dm³ of solution.\nCalculate the concentration (mol·dm⁻³).`,
      c, d, "c = n / V",
      `c = ${n}/${V} = ${c} mol·dm⁻³.`,
      null, 3);
  }

  _energyChem(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_energy_chem",
        `In an exothermic reaction, is ΔH positive or negative?`,
        "Negative", d, "Heat is released to the surroundings.",
        "Products have lower enthalpy than reactants; ΔH < 0.",
        { type: "energy_profile", exo: true }, 2);
    }
    if (roll === 1) {
      return base("ps_energy_chem",
        `Define activation energy.`,
        "The minimum energy that colliding particles must have for a reaction to occur.",
        d, "Symbol Eₐ.",
        "Shown as the hump height from reactants to the transition state.",
        { type: "energy_profile", exo: false }, 3);
    }
    return base("ps_energy_chem",
      `Bond breaking is … (endothermic or exothermic)?`,
      "Endothermic", d, "Energy is required to break bonds.",
      "Bond formation releases energy (exothermic).",
      { type: "energy_profile", exo: false }, 2);
  }

  _acids(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_acids_bases",
        `According to Brønsted–Lowry, an acid is a …`,
        "Proton (H⁺) donor", d, "Base is a proton acceptor.",
        "HA + B ⇌ A⁻ + HB⁺ ; A⁻ is the conjugate base of HA.",
        null, 2);
    }
    if (roll === 1) {
      return base("ps_acids_bases",
        `Identify the conjugate base of HCl.`,
        "Cl⁻", d, "Remove one H⁺ from the acid.",
        "HCl ⇌ H⁺ + Cl⁻.",
        null, 2);
    }
    return base("ps_acids_bases",
      `What is an ampholyte?`,
      "A substance that can act as both an acid and a base.",
      d, "Example: H₂O, HSO₄⁻.",
      "Water can donate or accept a proton.",
      null, 2);
  }

  _redox(d) {
    const roll = ri(0, 2);
    if (roll === 0) {
      return base("ps_redox",
        `Define oxidation in terms of electrons.`,
        "Loss of electrons", d, "OIL RIG: Oxidation Is Loss.",
        "Reduction is gain of electrons.",
        null, 2);
    }
    if (roll === 1) {
      return base("ps_redox",
        `What is the oxidation number of O in most compounds?`,
        "-2", d, "Except peroxides (−1) and OF₂ (+2).",
        "Oxygen is usually −2.",
        null, 2);
    }
    return base("ps_redox",
      `If Fe³⁺ becomes Fe²⁺, has iron been oxidised or reduced?`,
      "Reduced", d, "Oxidation number decreases; electrons are gained.",
      "Fe³⁺ + e⁻ → Fe²⁺ is reduction.",
      null, 2);
  }
}

export function isPhysSciTopic(id) {
  return String(id || "").startsWith("ps_");
}
