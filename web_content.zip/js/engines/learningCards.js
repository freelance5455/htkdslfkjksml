/**
 * Learnly Grade 10 — Learning cards
 * Step-by-step concept teaching in plain language, then a short retention check.
 * CAPS-aligned for Mathematical Literacy, Business Studies, Tourism.
 */
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

/** @typedef {{ title: string, plain: string, steps: string[], terms?: [string,string][], check: {q:string,a:string,hint?:string}[] }} Lesson */

/** @type {Record<string, Lesson>} */
const LESSONS = {
  ml_numbers: {
    title: "Numbers, ratio and percentage",
    plain: "This topic is about everyday number skills: comparing amounts, sharing fairly, and working with percentages such as discounts and VAT.",
    steps: [
      "Start with what you already know. A ratio like 2:3 means 'for every 2 of the first thing, there are 3 of the second'. The parts must be the same kind of unit (both rand, both litres, both people).",
      "A rate is different: it compares two different units, for example kilometres per hour (km/h) or rand per kilogram (R/kg).",
      "Percentage means 'out of 100'. So 15% of R200 means 15 out of every 100 rand. Calculate: 200 × 15 ÷ 100 = R30.",
      "To increase an amount by a percentage, multiply by (1 + percentage/100). Example: increase R80 by 10% → 80 × 1,10 = R88.",
      "To decrease, multiply by (1 − percentage/100). Example: 20% discount on R150 → 150 × 0,80 = R120.",
      "Always write the unit in your answer (R, km, %, people) so the marker knows you understand the context."
    ],
    terms: [
      ["Ratio", "A comparison of two quantities of the same kind, written a:b"],
      ["Rate", "A comparison of two different units, e.g. R/kg or km/h"],
      ["Percentage", "A number out of 100"],
      ["VAT", "Value-Added Tax — a tax added to many goods and services in South Africa (currently 15%)"]
    ],
    check: [
      { q: "What is 10% of R250?", a: "R25", hint: "250 × 0,10" },
      { q: "Simplify the ratio 12:18.", a: "2:3", hint: "Divide both by 6" },
      { q: "Is km/h a ratio or a rate?", a: "Rate", hint: "Different units: kilometres and hours" }
    ]
  },
  ml_patterns: {
    title: "Patterns and graphs",
    plain: "Patterns and graphs help you describe how one thing changes when another changes — for example cost as you travel more kilometres.",
    steps: [
      "A pattern is a rule that repeats. If a taxi charges R20 plus R5 per kilometre, the cost grows in a steady way.",
      "You can show the same relationship in four ways: words, a table of values, a formula (like C = 20 + 5d), and a graph.",
      "On a graph, the horizontal axis (x) is usually the independent variable (what you choose, e.g. distance). The vertical axis (y) is the dependent variable (what results, e.g. cost).",
      "If the graph is a straight line, the relationship is linear. The steepness is the gradient: how much y changes when x increases by 1.",
      "Read the scale carefully. One square might mean 2 km or R50 — always check before you answer."
    ],
    terms: [
      ["Linear relationship", "A relationship that makes a straight-line graph"],
      ["Gradient", "How steep a line is; change in y ÷ change in x"],
      ["Independent variable", "The input you control (often on the x-axis)"]
    ],
    check: [
      { q: "If C = 30 + 8d, what is C when d = 5?", a: "70", hint: "30 + 8×5" },
      { q: "A constant first difference in a table usually means which kind of graph?", a: "Straight line / linear", hint: "Equal steps → straight line" }
    ]
  },
  ml_finance: {
    title: "Personal and household finance",
    plain: "Finance in Grade 10 is about real money decisions: budgets, VAT, interest, profit and reading payslips or bank statements.",
    steps: [
      "A budget lists income (money in) and expenses (money out). If income is bigger, you have a surplus. If expenses are bigger, you have a deficit.",
      "VAT in South Africa is 15% on most goods. Price including VAT = price excluding VAT × 1,15. Price excluding VAT = price including VAT ÷ 1,15.",
      "Simple interest grows only on the original amount (the principal). Interest = principal × rate × time (rate as a decimal, time in years).",
      "Profit = selling price − cost price. Profit % is usually calculated on the cost price: (profit ÷ cost) × 100.",
      "On a payslip, gross pay is before deductions. Net pay is what you take home after tax, UIF and other deductions."
    ],
    terms: [
      ["Gross pay", "Total earnings before deductions"],
      ["Net pay", "Take-home pay after deductions"],
      ["Principal", "The original amount borrowed or invested"],
      ["Simple interest", "Interest calculated only on the principal"]
    ],
    check: [
      { q: "An item costs R400 excluding VAT. Price including 15% VAT?", a: "R460", hint: "400 × 1,15" },
      { q: "R2 000 at 6% simple interest for 2 years. Interest earned?", a: "R240", hint: "2000×0,06×2" }
    ]
  },
  ml_measurement: {
    title: "Perimeter, area and volume",
    plain: "Measurement is about length around a shape (perimeter), space inside a flat shape (area), and space inside a solid (volume). Grade 10 focuses mainly on 2D shapes, with some simple 3D.",
    steps: [
      "Perimeter is the total distance around the outside. For a rectangle: P = 2 × (length + width). For a square: P = 4 × side. For a circle, we say circumference: C = π × diameter (π ≈ 3,142).",
      "Area is the space inside a flat shape. Rectangle: length × width. Triangle: ½ × base × height. Circle: π × radius².",
      "Always use the same units. Convert mm → cm → m before you multiply. 1000 mm = 1 m, 100 cm = 1 m, 1 000 000 m² = 1 km².",
      "Volume is how much a container can hold. For a rectangular box (prism): length × width × height. Answer in cubic units (m³, cm³) or litres (1 litre = 1 000 cm³).",
      "In exams, formulae are often given — but you still must choose the right one and substitute carefully. Show each step."
    ],
    terms: [
      ["Perimeter", "Distance around the outside of a shape"],
      ["Area", "Space inside a flat (2D) shape"],
      ["Volume", "Space inside a solid (3D) object"],
      ["Circumference", "Perimeter of a circle"]
    ],
    check: [
      { q: "Perimeter of a rectangle 8 m by 3 m?", a: "22 m", hint: "2×(8+3)" },
      { q: "Area of a square with side 5 cm?", a: "25 cm²", hint: "5×5" }
    ]
  },
  ml_maps: {
    title: "Scale, maps and plans",
    plain: "Maps and plans are smaller pictures of real places. Scale tells you how to convert a distance on paper into a real distance on the ground.",
    steps: [
      "A scale of 1:50 000 means 1 unit on the map = 50 000 of the same unit in real life. So 1 cm on the map = 50 000 cm = 500 m = 0,5 km in reality.",
      "To find a real distance: measure the map distance, then multiply by the scale factor. Convert to a sensible unit (m or km).",
      "To find a map distance: take the real distance, convert to the same unit as the map measurement, then divide by the scale factor.",
      "Floor plans use large scales such as 1:100. A wall drawn as 4 cm is really 4 × 100 = 400 cm = 4 m.",
      "Always write the unit. Markers want to see whether you mean cm, m or km."
    ],
    terms: [
      ["Scale", "The ratio of map distance to real distance"],
      ["Floor plan", "A scaled drawing of a room or building from above"]
    ],
    check: [
      { q: "Scale 1:100. Map length 3 cm. Real length in metres?", a: "3 m", hint: "3×100 = 300 cm = 3 m" }
    ]
  },
  ml_data: {
    title: "Data handling and graphs",
    plain: "Data handling means collecting numbers, organising them, and reading graphs so you can make sensible conclusions.",
    steps: [
      "Mean is the average: add all values, divide by how many there are.",
      "Median is the middle value when the data is ordered from smallest to largest. If there are two middle values, average them.",
      "Mode is the value that appears most often. Range is largest minus smallest.",
      "Bar graphs compare categories. Line graphs show change over time. Pie charts show parts of a whole (the full circle is 360° or 100%).",
      "When you read a graph, first read the title, then the axis labels and scales, then the actual bars or points."
    ],
    terms: [
      ["Mean", "Average — sum of values ÷ number of values"],
      ["Median", "Middle value in an ordered list"],
      ["Mode", "Most frequent value"],
      ["Range", "Largest value − smallest value"]
    ],
    check: [
      { q: "Mean of 4, 6, 10?", a: "6,67 or 20/3", hint: "(4+6+10)/3" },
      { q: "Range of 3, 9, 5, 12?", a: "9", hint: "12 − 3" }
    ]
  },
  ml_probability: {
    title: "Chance and probability",
    plain: "Probability measures how likely something is. It is always a number from 0 (impossible) to 1 (certain).",
    steps: [
      "For equally likely outcomes: Probability = number of favourable outcomes ÷ total number of possible outcomes.",
      "A fair coin has 2 outcomes. P(heads) = 1/2. A fair die has 6 faces. P(rolling a 4) = 1/6.",
      "Probability can be written as a fraction, decimal or percentage. 1/4 = 0,25 = 25%.",
      "The probability that an event does not happen is 1 minus the probability that it does.",
      "Impossible events have probability 0. Certain events have probability 1. Most real-life events sit somewhere in between."
    ],
    terms: [
      ["Outcome", "A possible result of an experiment"],
      ["Event", "One or more outcomes we care about"],
      ["Favourable", "Outcomes that count as a 'success' for our event"]
    ],
    check: [
      { q: "P(rolling an even number on a fair die)?", a: "1/2", hint: "2,4,6 → 3/6" },
      { q: "Probability of an impossible event?", a: "0", hint: "Cannot happen" }
    ]
  },
  bs_micro: {
    title: "The micro environment",
    plain: "The micro environment is everything inside the business that managers can largely control — the people, money, machines and departments.",
    steps: [
      "Think of a business as a team with different jobs. Those jobs are called business functions.",
      "The eight functions are: general management, purchasing, production, marketing, public relations, human resources, administration and finance.",
      "General management sets the vision (long-term dream) and mission (why the business exists and how it will get there).",
      "Human resources looks after staff. Finance looks after money. Marketing connects the product to customers.",
      "Because these things are inside the business, management can change them — hire staff, change a budget, redesign a product."
    ],
    terms: [
      ["Micro environment", "Internal factors the business can control"],
      ["Vision", "The long-term picture of where the business wants to be"],
      ["Mission", "The purpose of the business and how it will pursue the vision"]
    ],
    check: [
      { q: "Which function recruits staff?", a: "Human resources", hint: "People" },
      { q: "Can management control the micro environment?", a: "Yes (mostly)", hint: "Internal = controllable" }
    ]
  },
  bs_market: {
    title: "The market environment",
    plain: "The market environment sits just outside the business. You can influence it, but you do not fully control it.",
    steps: [
      "The main role-players are: consumers (buyers), suppliers (who sell you inputs), competitors (rival businesses) and intermediaries (shops, agents, wholesalers who help sell).",
      "If a competitor cuts prices, you may need to respond — but you cannot force them to change.",
      "Good relationships with suppliers can mean better prices and reliable stock.",
      "Intermediaries help products reach customers. A bakery might sell through spaza shops or supermarkets.",
      "Market research (surveys, sales data) helps you understand what customers want."
    ],
    terms: [
      ["Consumer", "The person or organisation that buys the product"],
      ["Intermediary", "A go-between that helps distribute products"],
      ["Competitor", "Another business offering similar products"]
    ],
    check: [
      { q: "Name one market environment component.", a: "Consumers / suppliers / competitors / intermediaries", hint: "Outside but close" }
    ]
  },
  bs_macro: {
    title: "The macro environment (PESTEL)",
    plain: "The macro environment is the big outside world — politics, the economy, society, technology, the natural environment and the law. Businesses cannot control it; they must adapt.",
    steps: [
      "PESTEL is a memory tool: Political, Economic, Social, Technological, Environmental, Legal.",
      "Political: government decisions, stability, protests.",
      "Economic: inflation, interest rates, unemployment, exchange rates.",
      "Social: culture, demographics, lifestyle, education levels.",
      "Technological: new apps, machines, internet access.",
      "Environmental: climate, pollution laws, load shedding linked to energy.",
      "Legal: labour law, tax, consumer protection. Paying tax is legal duty — not CSR."
    ],
    terms: [
      ["PESTEL", "Framework for scanning macro factors"],
      ["Inflation", "General rise in prices over time"],
      ["Adapt", "Change your plans because the outside world changed"]
    ],
    check: [
      { q: "What does the P in PESTEL stand for?", a: "Political", hint: "Government" },
      { q: "Can a business control the macro environment?", a: "No", hint: "It must adapt" }
    ]
  },
  bs_sectors: {
    title: "Primary, secondary and tertiary sectors",
    plain: "The economy is divided into three broad sectors based on what businesses do with resources.",
    steps: [
      "Primary sector: takes raw materials from nature — farming, mining, fishing, forestry.",
      "Secondary sector: makes or processes things — factories, bakeries, car assembly, construction.",
      "Tertiary sector: provides services — shops, banks, schools, hotels, transport companies.",
      "A value chain can link all three: trees (primary) → furniture factory (secondary) → furniture shop (tertiary).",
      "Tourism businesses are mostly tertiary because they sell experiences and services, not raw materials."
    ],
    terms: [
      ["Primary", "Extracts raw materials"],
      ["Secondary", "Manufactures or processes"],
      ["Tertiary", "Provides services"]
    ],
    check: [
      { q: "A gold mine is in which sector?", a: "Primary", hint: "Extraction" },
      { q: "A hotel is in which sector?", a: "Tertiary", hint: "Service" }
    ]
  },
  bs_socio: {
    title: "Socioeconomic issues, CSR and CSI",
    plain: "Businesses operate in a society that faces challenges such as poverty, unemployment and inequality. CSR is how businesses choose to help beyond what the law demands.",
    steps: [
      "Socioeconomic issues affect both communities and businesses. Unemployment can mean fewer customers and a smaller skills pool.",
      "CSR means Corporate Social Responsibility — voluntary actions to benefit society.",
      "CSI means Corporate Social Investment — the actual projects and money spent (bursaries, clinics, sports fields).",
      "Paying tax or following labour law is a legal duty, not CSR.",
      "Good CSI can improve a brand's reputation and long-term relationships with communities."
    ],
    terms: [
      ["CSR", "Corporate Social Responsibility — voluntary social good"],
      ["CSI", "Corporate Social Investment — the projects/funding arm of CSR"]
    ],
    check: [
      { q: "Is paying company tax an example of CSR?", a: "No", hint: "Tax is a legal requirement" }
    ]
  },
  bs_entrepreneurship: {
    title: "Entrepreneurs and opportunity",
    plain: "An entrepreneur spots a need, takes a calculated risk, and organises resources to start and grow a business.",
    steps: [
      "Entrepreneurship is the process of creating and running a business.",
      "Useful qualities include creativity, perseverance, initiative and the courage to take calculated risks (risks you have thought through).",
      "A business opportunity is a gap — customers want something that is not available or not good enough yet.",
      "Entrepreneurs help the economy by creating jobs and supplying goods or services.",
      "Not every idea succeeds. Planning, research and learning from failure matter."
    ],
    terms: [
      ["Entrepreneur", "Person who starts and runs a business, taking on risk"],
      ["Calculated risk", "A risk taken after weighing possible gains and losses"]
    ],
    check: [
      { q: "Name one entrepreneurial quality.", a: "Creativity / perseverance / initiative / risk-taking", hint: "Personal strengths" }
    ]
  },
  bs_ownership: {
    title: "Forms of ownership",
    plain: "Choosing a form of ownership decides who owns the business, who is liable for debts, and how profits are shared.",
    steps: [
      "Sole proprietor: one owner. Easy to start. Owner keeps all profit but has unlimited liability (personal assets can be used to pay business debts).",
      "Partnership: two or more owners. Shared skills and capital, but usually unlimited liability and shared decision-making.",
      "Private company (Pty Ltd): separate legal person. Owners have limited liability — they only risk what they invested. More paperwork to set up.",
      "Limited liability means the business is separate from the owners in the eyes of the law.",
      "Choose a form based on risk, capital needed, control and tax — not only on what 'sounds professional'."
    ],
    terms: [
      ["Unlimited liability", "Owners can lose personal assets to pay business debts"],
      ["Limited liability", "Owners only risk the money they put into the business"],
      ["Sole proprietor", "Business owned by one person"]
    ],
    check: [
      { q: "Which form has one owner and unlimited liability?", a: "Sole proprietor", hint: "Single owner" }
    ]
  },
  bs_opportunity: {
    title: "Business opportunities and the business plan",
    plain: "A business plan is a written guide that explains the idea, the market, the operations and the money side. Banks and partners often ask for one.",
    steps: [
      "A business opportunity is a favourable chance to sell a product or service that people need.",
      "A simple plan usually includes: executive summary, description of the product, market analysis, marketing, operations, management team and financial plan.",
      "Market analysis asks: who are the customers, who are the competitors, and is there real demand?",
      "Location matters: customers must reach you, and rent must be affordable.",
      "The plan is a living document — update it when the market changes."
    ],
    terms: [
      ["Business plan", "Written document describing how the business will work and make money"],
      ["Market analysis", "Study of customers, competitors and demand"]
    ],
    check: [
      { q: "Name one section of a business plan.", a: "Executive summary / market analysis / financial plan", hint: "Standard sections" }
    ]
  },
  bs_creative: {
    title: "Creative thinking and problem-solving",
    plain: "Creative thinking produces many ideas. Problem-solving chooses and applies the best idea.",
    steps: [
      "Brainstorming: write down as many ideas as possible without judging them at first.",
      "Other tools include mind maps and force-field analysis (forces for and against a change).",
      "A simple problem-solving path: identify the problem → gather facts → list options → evaluate → implement → review.",
      "Creative thinking is not only for 'artists' — businesses use it for new products, better processes and customer service.",
      "Evaluate ideas against cost, time, risk and impact before you spend money."
    ],
    terms: [
      ["Brainstorming", "Generating many ideas quickly without early criticism"],
      ["Problem-solving", "Choosing and applying a solution"]
    ],
    check: [
      { q: "Should you criticise ideas during the first stage of brainstorming?", a: "No", hint: "Quantity first" }
    ]
  },
  bs_self: {
    title: "Self-management and teamwork",
    plain: "Self-management is how you run your own time, stress and goals. Teamwork is how people with different strengths work toward one goal.",
    steps: [
      "Time management: prioritise important tasks, break big tasks into steps, meet deadlines.",
      "Stress management: rest, ask for help, keep goals realistic.",
      "Teams work better when roles are clear — who researches, who writes, who presents.",
      "Good teams communicate, respect each other and share credit.",
      "In a business, teamwork across functions (marketing with finance, for example) prevents costly mistakes."
    ],
    terms: [
      ["Prioritise", "Decide which tasks matter most and do those first"],
      ["Team role", "The specific contribution a member makes"]
    ],
    check: [
      { q: "Name one self-management skill.", a: "Time management / stress management / goal-setting", hint: "Managing yourself" }
    ]
  },
  tour_intro: {
    title: "What is tourism?",
    plain: "Tourism is about people travelling to and staying in places outside their everyday environment — for holiday, work, family visits and more.",
    steps: [
      "A common definition: activities of people travelling to and staying in places outside their usual environment for not more than one consecutive year, for leisure, business and other purposes.",
      "Inbound tourism: visitors coming into a country. Outbound: residents leaving their country. Domestic: residents travelling inside their own country.",
      "Tourism brings jobs, foreign currency and infrastructure — but only if it is managed well.",
      "A daily commute to work is not tourism, because it is inside your usual environment.",
      "South Africa markets itself for wildlife, culture, beaches and adventure — different visitors want different experiences."
    ],
    terms: [
      ["Inbound", "Visitors entering a country"],
      ["Outbound", "Residents leaving their country to travel"],
      ["Domestic tourism", "Residents travelling inside their own country"]
    ],
    check: [
      { q: "German tourists arriving in Cape Town are inbound or outbound for South Africa?", a: "Inbound", hint: "Entering SA" }
    ]
  },
  tour_types: {
    title: "Types of tourists",
    plain: "Tourists are grouped by why they travel and what they need. Knowing the type helps businesses design the right package.",
    steps: [
      "Leisure tourists travel to relax or explore. Business tourists travel for meetings and conferences — they value speed and Wi-Fi.",
      "VFR means Visiting Friends and Relatives.",
      "Eco-tourists focus on nature and low environmental impact. Adventure tourists want activities such as hiking or diving.",
      "Cultural tourists seek heritage, museums and local traditions.",
      "Budget and luxury tourists may visit the same city but choose very different transport and accommodation."
    ],
    terms: [
      ["VFR", "Visiting friends and relatives"],
      ["Eco-tourist", "Traveller focused on nature and low impact"]
    ],
    check: [
      { q: "What does VFR stand for?", a: "Visiting friends and relatives", hint: "Family and friends" }
    ]
  },
  tour_sectors: {
    title: "Tourism industry sectors",
    plain: "The tourism industry is made of linked sectors: transport, accommodation, food and beverage, attractions and the travel trade.",
    steps: [
      "Transport moves people: airlines, coaches, car hire, rail, ferries.",
      "Accommodation is where tourists sleep: hotels, guesthouses, lodges, backpackers, self-catering.",
      "Food and beverage covers restaurants, cafés and catering.",
      "Attractions are the places people come to see — parks, museums, beaches, cultural villages.",
      "Travel trade means travel agents and tour operators who package and sell trips.",
      "A single holiday uses several sectors at once: flight + hotel + restaurant + game drive."
    ],
    terms: [
      ["Travel trade", "Agents and operators who sell travel"],
      ["Attraction", "A place or experience that draws visitors"]
    ],
    check: [
      { q: "Which sector do hotels belong to?", a: "Accommodation", hint: "Where tourists stay" }
    ]
  },
  tour_transport: {
    title: "Tourist transport",
    plain: "Choosing transport is a balance of cost, time, comfort and safety.",
    steps: [
      "Air: fast for long distances; higher cost and carbon impact.",
      "Road: flexible (car hire, coach); good for scenic routes and door-to-door travel.",
      "Rail: comfortable for some long routes; can be scenic.",
      "Sea: cruises and ferries — the journey is part of the experience.",
      "Match the mode to the tourist type: a business traveller may prefer a short flight; a backpacker may prefer a coach."
    ],
    terms: [
      ["Mode of transport", "The type of vehicle or system used to travel"]
    ],
    check: [
      { q: "Name one advantage of air transport.", a: "Speed / long distance / international links", hint: "Fast" }
    ]
  },
  tour_accommodation: {
    title: "Accommodation types and grading",
    plain: "Accommodation ranges from camping to five-star hotels. Grading systems help guests know what standard to expect.",
    steps: [
      "Common types: hotel, bed and breakfast (B&B), guest house, lodge, backpacker, self-catering, camping.",
      "Star grading (where used) signals facilities and service level — higher stars usually mean more amenities.",
      "Location, price, safety and facilities drive guest choice.",
      "In-room technology (Wi-Fi, charging points) is increasingly expected.",
      "F&B means food and beverage — meals linked to the stay."
    ],
    terms: [
      ["B&B", "Bed and breakfast"],
      ["Lodge", "Often nature- or game-oriented accommodation"]
    ],
    check: [
      { q: "What does B&B stand for?", a: "Bed and breakfast", hint: "Overnight + morning meal" }
    ]
  },
  tour_maps: {
    title: "Maps and tour planning",
    plain: "Maps help tourists and planners estimate distance, direction and travel time. An itinerary is a day-by-day plan.",
    steps: [
      "Read the scale, legend (key) and north arrow before you measure anything.",
      "Convert map distance to real distance using the scale.",
      "An itinerary lists places, times and activities — useful for tour operators and independent travellers.",
      "Good planning avoids backtracking and respects opening times and daylight.",
      "Always have a backup plan for weather or delays."
    ],
    terms: [
      ["Legend / key", "Explains symbols on a map"],
      ["Itinerary", "Scheduled plan of a trip"]
    ],
    check: [
      { q: "What does a map scale tell you?", a: "How map distance relates to real distance", hint: "Ratio" }
    ]
  },
  tour_attractions: {
    title: "Tourist attractions",
    plain: "Attractions are the reasons people visit. They can be natural, cultural or man-made.",
    steps: [
      "Natural: mountains, beaches, parks, waterfalls.",
      "Cultural / heritage: museums, historical sites, cultural villages, music and food traditions.",
      "Man-made: theme parks, stadiums, modern landmarks.",
      "A primary attraction is the main reason for the visit. Secondary attractions are extras enjoyed while there.",
      "Successful attractions need access, safety, facilities and careful management of visitor numbers."
    ],
    terms: [
      ["Primary attraction", "Main reason tourists visit"],
      ["Secondary attraction", "Additional places or activities enjoyed on the same trip"]
    ],
    check: [
      { q: "Is Table Mountain a natural or man-made attraction?", a: "Natural", hint: "Landscape" }
    ]
  },
  tour_sustainable: {
    title: "Sustainable and responsible tourism",
    plain: "Sustainable tourism aims to protect the environment and culture while still supporting local jobs and businesses — so future visitors can enjoy the place too.",
    steps: [
      "Three pillars (the three Ps): Planet (environment), People (communities and culture), Profit (economic benefit).",
      "Responsible tourist behaviour: save water and energy, avoid litter, respect local customs, buy local where possible.",
      "Businesses can use solar power, reduce plastic, hire locally and train staff.",
      "Greenwashing is pretending to be eco-friendly without real action — look for honest practices.",
      "When tourism is sustainable, communities gain income without losing their environment or dignity."
    ],
    terms: [
      ["Sustainable tourism", "Tourism that balances environment, people and economy long-term"],
      ["Greenwashing", "False or exaggerated environmental claims"]
    ],
    check: [
      { q: "Name the three pillars of sustainable tourism.", a: "Planet, People, Profit", hint: "Three Ps" }
    ]
  },
  tour_domestic: {
    title: "Domestic, regional and international tourism",
    plain: "Not all tourism crosses oceans. Domestic and regional travel are important for local economies.",
    steps: [
      "Domestic tourism: residents travelling inside their own country.",
      "Regional tourism: travel within a group of neighbouring countries (e.g. SADC).",
      "International tourism: travel between countries further afield — inbound and outbound.",
      "Governments promote domestic tourism to keep spending local and to smooth seasonal dips.",
      "Statistics (arrivals, bed-nights, spend) help planners decide where to invest."
    ],
    terms: [
      ["Domestic tourism", "Travel inside one's own country"],
      ["Regional tourism", "Travel within a neighbouring-country region"]
    ],
    check: [
      { q: "A family from Johannesburg holidaying in Durban is an example of which tourism type?", a: "Domestic", hint: "Inside SA" }
    ]
  },
  tour_service: {
    title: "Customer care and service excellence",
    plain: "Service excellence means meeting and exceeding guest expectations. In tourism, people remember how you made them feel.",
    steps: [
      "Core habits: greet, listen, know your product, help promptly, follow up.",
      "When something goes wrong, use service recovery: listen, apologise, fix the problem, confirm the guest is satisfied.",
      "Product knowledge lets you recommend honestly and safely.",
      "Reviews and feedback are free research — use them to improve.",
      "Poor service costs more than the refund: lost repeat visits and damaged reputation."
    ],
    terms: [
      ["Service recovery", "Steps taken to fix a service failure and restore trust"],
      ["Product knowledge", "Knowing what you sell well enough to advise guests"]
    ],
    check: [
      { q: "Name one step of service recovery.", a: "Listen / apologise / solve / follow up", hint: "After a complaint" }
    ]
  }
};

export function getLesson(topicId) {
  return LESSONS[topicId] || null;
}

export function listLessonsForSubject(subjectId) {
  const prefixes = {
    mathematical_literacy: "ml_",
    business_studies: "bs_",
    tourism: "tour_"
  };
  const p = prefixes[subjectId];
  if (!p) return [];
  return Object.keys(LESSONS).filter((k) => k.startsWith(p)).map((id) => ({
    id,
    title: LESSONS[id].title,
    plain: LESSONS[id].plain
  }));
}

export function allLessonIds() {
  return Object.keys(LESSONS);
}

export default { getLesson, listLessonsForSubject, allLessonIds };
