/* ============================================================
   AETHERVALE — Item, inventory, market & upgrade systems
   ============================================================ */
let UID = 1;

function newItem(tid, qty) {
  const tpl = ITEMS[tid];
  if (!tpl) throw new Error('unknown item ' + tid);
  if (tpl.stack) return { uid: UID++, tid, qty: qty || 1 };
  return { uid: UID++, tid, plus: 0, sockets: new Array(tpl.sockets || 0).fill(null), enchant: null };
}
function tpl(inst) { return ITEMS[inst.tid]; }
function isGear(inst) { return !!SLOTS[tpl(inst).type]; }

function itemStats(inst) {
  const t = tpl(inst); const out = {};
  const m = RARITY[t.rarity || 'common'].mult;
  const pm = plusMult(inst.plus || 0);
  for (const k in (t.stats || {})) {
    let v = t.stats[k] * (isGear(inst) ? pm : 1);
    if (k === 'atk' || k === 'def' || k === 'hp') v *= m * 0.85 + 0.15;
    out[k] = (out[k] || 0) + v;
  }
  (inst.sockets || []).forEach(g => {
    if (!g) return; const gem = GEMS[g];
    out[gem.stat] = (out[gem.stat] || 0) + gem.val;
  });
  if (inst.enchant) out[inst.enchant.stat] = (out[inst.enchant.stat] || 0) + inst.enchant.val;
  for (const k in out) out[k] = Math.round(out[k] * 10) / 10;
  return out;
}
function itemName(inst) {
  const t = tpl(inst);
  return t.name + ((inst.plus || 0) > 0 ? ' +' + inst.plus : '');
}
function itemColor(inst) { return RARITY[tpl(inst).rarity || 'common'].color; }
function itemPower(inst) {
  const s = itemStats(inst);
  return Math.round((s.atk || 0) * 3 + (s.def || 0) * 2.5 + (s.hp || 0) * 0.35 + (s.crit || 0) * 4 +
    (s.critdmg || 0) * 1.2 + (s.life || 0) * 5 + (s.haste || 0) * 3 + (s.spd || 0) * 0.8);
}
function itemValue(inst) {
  const t = tpl(inst);
  let v = t.price || 20;
  if (isGear(inst)) {
    v *= (1 + (inst.plus || 0) * 0.42 + Math.max(0, (inst.plus || 0) - 6) * 0.35);
    (inst.sockets || []).forEach(g => { if (g) v += (ITEMS[g].price || 0) * 0.8; });
    if (inst.enchant) v += 400 + inst.enchant.gradeIdx * 700;
  }
  return Math.round(v);
}
function statLine(k, v) {
  const suf = STAT_SUFFIX[k] || '';
  return `${STAT_LABEL[k]} +${Math.round(v * 10) / 10}${suf}`;
}

/* ================= Inventory ================= */
const Inv = {
  add(tid, qty) {
    qty = qty || 1;
    const t = ITEMS[tid];
    const P = Game.player;
    if (t.stack) {
      const ex = P.inv.find(i => i.tid === tid);
      if (ex) { ex.qty += qty; return ex; }
      const it = newItem(tid, qty); P.inv.push(it); return it;
    }
    let last = null;
    for (let i = 0; i < qty; i++) { last = newItem(tid); P.inv.push(last); }
    return last;
  },
  addInst(inst) { Game.player.inv.push(inst); return inst; },
  count(tid) {
    return Game.player.inv.reduce((a, i) => a + (i.tid === tid ? (i.qty || 1) : 0), 0);
  },
  remove(tid, qty) {
    qty = qty || 1;
    const P = Game.player;
    for (let i = P.inv.length - 1; i >= 0 && qty > 0; i--) {
      const it = P.inv[i];
      if (it.tid !== tid) continue;
      if (it.qty) {
        const take = Math.min(it.qty, qty); it.qty -= take; qty -= take;
        if (it.qty <= 0) P.inv.splice(i, 1);
      } else { P.inv.splice(i, 1); qty--; }
    }
    return qty === 0;
  },
  removeUid(uid) {
    const P = Game.player;
    const i = P.inv.findIndex(x => x.uid === uid);
    if (i >= 0) return P.inv.splice(i, 1)[0];
    return null;
  },
  byUid(uid) {
    const P = Game.player;
    let f = P.inv.find(x => x.uid === uid);
    if (f) return f;
    for (const s in P.equip) if (P.equip[s] && P.equip[s].uid === uid) return P.equip[s];
    return null;
  },
  equip(uid) {
    const P = Game.player;
    const inst = P.inv.find(x => x.uid === uid);
    if (!inst || !isGear(inst)) return false;
    const slot = tpl(inst).type;
    Inv.removeUid(uid);
    if (P.equip[slot]) P.inv.push(P.equip[slot]);
    P.equip[slot] = inst;
    Game.recalc();
    return true;
  },
  unequip(slot) {
    const P = Game.player;
    if (!P.equip[slot]) return;
    P.inv.push(P.equip[slot]); P.equip[slot] = null; Game.recalc();
  },
  gearList(slot) {
    const P = Game.player;
    return P.inv.filter(i => isGear(i) && (!slot || tpl(i).type === slot));
  },
};

/* ================= Market / Auction House ================= */
const Market = {
  tradeable: [],           // template ids tracked by the market
  price: {},               // tid -> current price multiplier (1.0 = base)
  hist: {},                // tid -> array of multipliers
  listings: [],
  consigned: [],           // player's items on sale
  lid: 1,
  news: [],
  t: 0,

  init() {
    this.tradeable = Object.keys(ITEMS).filter(id => {
      const t = ITEMS[id];
      return t.type !== 'gem' || true;
    }).filter(id => !['w_rift', 'a_aether', 'm_riftshard'].includes(id));
    this.tradeable.forEach(id => {
      this.price[id] = 0.85 + Math.random() * 0.3;
      this.hist[id] = Array.from({ length: 28 }, (_, i) => this.price[id] + (Math.random() - 0.5) * 0.08 - (27 - i) * 0.001);
    });
    this.listings = [];
    for (let i = 0; i < 30; i++) this.spawnListing();
    this.news = ['Pasar dibuka. Harga batu tempa stabil.'];
  },
  spawnListing(forceTid) {
    const lvl = Game.player ? Game.player.level : 1;
    const pool = this.tradeable.filter(id => {
      const t = ITEMS[id];
      if (t.type === 'mat' || t.type === 'potion' || t.type === 'gem') return true;
      return (t.tier || 1) <= Math.max(2, Math.ceil(lvl / 3) + 1);
    });
    const tid = forceTid || pool[Math.floor(Math.random() * pool.length)];
    const t = ITEMS[tid];
    const inst = newItem(tid, t.stack ? (1 + Math.floor(Math.random() * 5)) : 1);
    // NPC sellers sometimes offer pre-enhanced / socketed gear
    if (isGear(inst) && Math.random() < 0.45) {
      inst.plus = Math.min(7, Math.floor(Math.random() * Math.random() * 8));
      if (inst.sockets.length && Math.random() < 0.4) {
        const gids = Object.keys(GEMS).filter(g => !g.endsWith('_hi') && g !== 'g_star');
        inst.sockets[0] = gids[Math.floor(Math.random() * gids.length)];
      }
    }
    const sellers = ['Wira', 'Kalya', 'Dimas', 'Suri', 'Ganda', 'Ratu Hujan', 'Jaka', 'Nirmala', 'Gusti', 'Reza', 'Ayu', 'Bhre'];
    const price = Math.max(5, Math.round(itemValue(inst) * this.price[tid] * (0.9 + Math.random() * 0.35) * (inst.qty || 1)));
    const l = { id: this.lid++, inst, tid, qty: inst.qty || 1, price, seller: sellers[Math.floor(Math.random() * sellers.length)], age: 0 };
    this.listings.push(l);
    return l;
  },
  unit(l) { return Math.round(l.price / (l.qty || 1)); },
  tick(dt) {
    this.t += dt;
    if (this.t < 4) return;
    this.t = 0;
    // random walk with mean reversion
    for (const id of this.tradeable) {
      const drift = (1 - this.price[id]) * 0.06;
      this.price[id] = Math.max(0.55, Math.min(1.9, this.price[id] + drift + (Math.random() - 0.5) * 0.07));
      const h = this.hist[id]; h.push(this.price[id]); if (h.length > 40) h.shift();
    }
    // market events
    if (Math.random() < 0.3) {
      const id = this.tradeable[Math.floor(Math.random() * this.tradeable.length)];
      const up = Math.random() < 0.5;
      this.price[id] = Math.max(0.5, Math.min(2.1, this.price[id] * (up ? 1.22 : 0.82)));
      this.news.unshift(`${ITEMS[id].name}: harga ${up ? 'melonjak' : 'jatuh'} ${up ? '+' : '-'}${Math.round(Math.random() * 12 + 8)}% — ${up ? 'permintaan naik' : 'pasokan membanjir'}.`);
      if (this.news.length > 6) this.news.pop();
    }
    // listings churn
    for (let i = this.listings.length - 1; i >= 0; i--) {
      this.listings[i].age++;
      if (this.listings[i].age > 14 && Math.random() < 0.4) this.listings.splice(i, 1);
    }
    while (this.listings.length < 30) this.spawnListing();
    // consigned sales
    for (let i = this.consigned.length - 1; i >= 0; i--) {
      const c = this.consigned[i];
      c.age++;
      const chance = 0.12 + Math.max(0, (this.price[c.tid] - c.priceRatio)) * 0.9;
      if (Math.random() < chance) {
        const net = Math.round(c.price * 0.95);
        Game.player.gold += net;
        Game.toast(`Terjual: ${itemName(c.inst)} — ${fmt(net)} G (pajak 5%)`, '#6fe08a');
        Game.stats.sold++;
        this.consigned.splice(i, 1);
      }
    }
  },
  buy(id) {
    const i = this.listings.findIndex(l => l.id === id);
    if (i < 0) return { ok: false, msg: 'Barang sudah terjual.' };
    const l = this.listings[i];
    if (Game.player.gold < l.price) return { ok: false, msg: 'Gold tidak cukup.' };
    Game.player.gold -= l.price;
    if (ITEMS[l.tid].stack) Inv.add(l.tid, l.qty); else Inv.addInst(l.inst);
    this.listings.splice(i, 1);
    this.price[l.tid] = Math.min(2.1, this.price[l.tid] * 1.01);
    Game.stats.bought++;
    Game.quest.onBuy();
    return { ok: true, msg: `Dibeli: ${itemName(l.inst)}${l.qty > 1 ? ' x' + l.qty : ''}` };
  },
  quickSell(inst, qty) {
    qty = qty || 1;
    const val = Math.round(itemValue(inst) * this.price[inst.tid] * 0.85) * qty;
    Game.player.gold += val;
    if (inst.qty) Inv.remove(inst.tid, qty); else Inv.removeUid(inst.uid);
    this.price[inst.tid] = Math.max(0.5, this.price[inst.tid] * 0.995);
    Game.stats.sold++;
    return val;
  },
  consign(inst, price, qty) {
    qty = qty || 1;
    const sub = inst.qty ? newItem(inst.tid, qty) : inst;
    if (inst.qty) Inv.remove(inst.tid, qty); else Inv.removeUid(inst.uid);
    this.consigned.push({ id: this.lid++, inst: sub, tid: inst.tid, qty, price, priceRatio: price / Math.max(1, itemValue(sub) * qty), age: 0 });
  },
  cancelConsign(id) {
    const i = this.consigned.findIndex(c => c.id === id);
    if (i < 0) return;
    const c = this.consigned.splice(i, 1)[0];
    if (ITEMS[c.tid].stack) Inv.add(c.tid, c.qty); else Inv.addInst(c.inst);
  },
  suggested(inst, qty) {
    return Math.max(5, Math.round(itemValue(inst) * this.price[inst.tid] * (qty || 1)));
  },
  trend(tid) {
    const h = this.hist[tid]; if (!h || h.length < 6) return 0;
    return (h[h.length - 1] - h[h.length - 6]) / h[h.length - 6];
  },
};

/* ================= Enhancement ================= */
const Enhance = {
  info(inst) {
    const p = inst.plus || 0;
    if (p >= MAX_PLUS) return null;
    const e = ENHANCE[p];
    const tierScale = 1 + ((tpl(inst).tier || 1) - 1) * 0.55;
    return {
      ...e, gold: Math.round(e.gold * tierScale), next: p + 1,
      canProtect: e.down > 0 || e.brk > 0,
    };
  },
  attempt(uid, useProtect) {
    const inst = Inv.byUid(uid);
    if (!inst || !isGear(inst)) return { ok: false, msg: 'Pilih peralatan dulu.' };
    const e = this.info(inst);
    if (!e) return { ok: false, msg: 'Sudah mencapai +10 (maksimum).' };
    if (Game.player.gold < e.gold) return { ok: false, msg: 'Gold tidak cukup.' };
    if (Inv.count(e.stone) < e.qty) return { ok: false, msg: `Butuh ${e.qty}x ${ITEMS[e.stone].name}.` };
    if (useProtect && Inv.count('m_protect') < 1) return { ok: false, msg: 'Tidak punya Gulungan Perlindungan.' };
    Game.player.gold -= e.gold;
    Inv.remove(e.stone, e.qty);
    if (useProtect) Inv.remove('m_protect', 1);
    Game.stats.enhanceTry++;
    const roll = Math.random();
    if (roll < e.rate) {
      inst.plus++;
      Game.recalc(); Game.stats.enhanceOk++;
      Game.quest.onPlus(inst.plus);
      return { ok: true, result: 'up', msg: `BERHASIL! ${tpl(inst).name} kini +${inst.plus}`, inst };
    }
    // failure branch
    const r2 = Math.random();
    if (!useProtect && r2 < e.brk / (1 - e.rate + 0.0001)) {
      // destroyed
      const name = itemName(inst);
      if (Game.player.equip[tpl(inst).type] && Game.player.equip[tpl(inst).type].uid === inst.uid) Game.player.equip[tpl(inst).type] = null;
      else Inv.removeUid(inst.uid);
      Game.recalc();
      return { ok: true, result: 'break', msg: `HANCUR! ${name} lenyap jadi debu.`, inst: null };
    }
    if (!useProtect && e.down > 0 && Math.random() < 0.6) {
      inst.plus = Math.max(0, inst.plus - 1);
      Game.recalc();
      return { ok: true, result: 'down', msg: `GAGAL — tempaan turun ke +${inst.plus}.`, inst };
    }
    return { ok: true, result: 'keep', msg: useProtect ? 'GAGAL — tapi gulungan melindungi item.' : 'GAGAL — level tempaan bertahan.', inst };
  },
};

/* ================= Socketing ================= */
const Socket = {
  set(uid, slotIdx, gemId) {
    const inst = Inv.byUid(uid);
    if (!inst || !isGear(inst)) return { ok: false, msg: 'Pilih peralatan.' };
    if (slotIdx >= inst.sockets.length) return { ok: false, msg: 'Slot tidak tersedia.' };
    if (inst.sockets[slotIdx]) return { ok: false, msg: 'Slot sudah terisi — lepas dulu.' };
    if (Inv.count(gemId) < 1) return { ok: false, msg: 'Permata tidak ada di tas.' };
    const cost = 60 + (tpl(inst).tier || 1) * 40;
    if (Game.player.gold < cost) return { ok: false, msg: 'Gold tidak cukup.' };
    Game.player.gold -= cost;
    Inv.remove(gemId, 1);
    inst.sockets[slotIdx] = gemId;
    Game.recalc(); Game.stats.socketed++;
    Game.quest.onSocket();
    return { ok: true, msg: `${GEMS[gemId].name} terpasang. ${GEMS[gemId].desc}` };
  },
  pull(uid, slotIdx, keep) {
    const inst = Inv.byUid(uid);
    if (!inst || !inst.sockets[slotIdx]) return { ok: false, msg: 'Slot kosong.' };
    const gid = inst.sockets[slotIdx];
    const cost = keep ? 450 : 80;
    if (Game.player.gold < cost) return { ok: false, msg: 'Gold tidak cukup.' };
    Game.player.gold -= cost;
    inst.sockets[slotIdx] = null;
    Game.recalc();
    if (keep) { Inv.add(gid, 1); return { ok: true, msg: `${GEMS[gid].name} dilepas utuh.` }; }
    return { ok: true, msg: `${GEMS[gid].name} hancur saat dilepas paksa.` };
  },
  drill(uid) {
    const inst = Inv.byUid(uid);
    const t = tpl(inst);
    const max = (t.sockets || 0) + 1;
    if (!inst) return { ok: false, msg: 'Pilih peralatan.' };
    if (inst.sockets.length >= Math.min(4, max)) return { ok: false, msg: 'Slot sudah maksimum untuk item ini.' };
    const cost = 800 + inst.sockets.length * 900;
    if (Game.player.gold < cost) return { ok: false, msg: `Butuh ${fmt(cost)} G untuk melubangi.` };
    if (Inv.count('m_stone_hi') < 2) return { ok: false, msg: 'Butuh 2x Batu Tempa Agung.' };
    Game.player.gold -= cost; Inv.remove('m_stone_hi', 2);
    if (Math.random() < 0.7) { inst.sockets.push(null); Game.recalc(); return { ok: true, msg: 'Slot baru berhasil dilubangi!' }; }
    return { ok: true, msg: 'Gagal melubangi — bahan hilang, item aman.' };
  },
};

/* ================= Enchantment ================= */
const Enchantment = {
  roll() {
    const total = ENCHANTS.reduce((a, e) => a + e.w, 0);
    let r = Math.random() * total, pick = ENCHANTS[0];
    for (const e of ENCHANTS) { r -= e.w; if (r <= 0) { pick = e; break; } }
    const q = Math.pow(Math.random(), 1.6);
    const gi = ENCHANT_GRADE.findIndex(g => q >= g.t[0] && q < g.t[1]);
    const gradeIdx = Math.max(0, gi);
    const val = Math.round(pick.rolls[0] + (pick.rolls[1] - pick.rolls[0]) * q);
    return { id: pick.id, name: pick.name, stat: pick.stat, val, grade: ENCHANT_GRADE[gradeIdx].name, gradeIdx, color: ENCHANT_GRADE[gradeIdx].color };
  },
  apply(uid) {
    const inst = Inv.byUid(uid);
    if (!inst || !isGear(inst)) return { ok: false, msg: 'Pilih peralatan.' };
    if (Inv.count('m_enchant') < 1) return { ok: false, msg: 'Butuh Gulungan Sihir.' };
    const cost = 150 + (tpl(inst).tier || 1) * 90;
    if (Game.player.gold < cost) return { ok: false, msg: 'Gold tidak cukup.' };
    Game.player.gold -= cost; Inv.remove('m_enchant', 1);
    const prev = inst.enchant;
    const nw = this.roll();
    Game.stats.enchanted++;
    Game.quest.onEnchant();
    inst.enchant = nw; Game.recalc();
    return { ok: true, prev, nw, msg: `Sihir baru: ${nw.name} ${nw.grade} (+${nw.val}${STAT_SUFFIX[nw.stat] || ''})` };
  },
};

/* ================= Inheritance / Stat transfer ================= */
const Inherit = {
  preview(srcUid, dstUid) {
    const s = Inv.byUid(srcUid), d = Inv.byUid(dstUid);
    if (!s || !d) return { ok: false, msg: 'Pilih item sumber dan tujuan.' };
    if (s.uid === d.uid) return { ok: false, msg: 'Pilih dua item berbeda.' };
    if (tpl(s).type !== tpl(d).type) return { ok: false, msg: `Harus slot sama (${SLOTS[tpl(s).type]} → ${SLOTS[tpl(d).type]}).` };
    const gems = (s.sockets || []).filter(Boolean);
    const movable = Math.min(gems.length, (d.sockets || []).length);
    const cost = 400 + (tpl(d).tier || 1) * 350 + (s.plus || 0) * 220;
    const essence = 1 + (s.plus >= 8 ? 1 : 0);
    const loss = s.plus >= 8 ? 1 : 0; // very high tempering loses 1 level in transfer
    return {
      ok: true, src: s, dst: d, cost, essence,
      plus: Math.max(0, (s.plus || 0) - loss), loss,
      gems: gems.slice(0, movable), gemsLost: gems.length - movable,
      enchant: s.enchant,
    };
  },
  execute(srcUid, dstUid) {
    const p = this.preview(srcUid, dstUid);
    if (!p.ok) return p;
    if (Game.player.gold < p.cost) return { ok: false, msg: 'Gold tidak cukup.' };
    if (Inv.count('m_essence') < p.essence) return { ok: false, msg: `Butuh ${p.essence}x Esensi Warisan.` };
    Game.player.gold -= p.cost; Inv.remove('m_essence', p.essence);
    const d = p.dst, s = p.src;
    d.plus = p.plus;
    p.gems.forEach((g, i) => { if (i < d.sockets.length) d.sockets[i] = g; });
    if (p.enchant) d.enchant = { ...p.enchant };
    // consume source
    const slot = tpl(s).type;
    if (Game.player.equip[slot] && Game.player.equip[slot].uid === s.uid) Game.player.equip[slot] = null;
    else Inv.removeUid(s.uid);
    Game.recalc(); Game.stats.inherited++;
    Game.quest.onInherit();
    return { ok: true, msg: `Warisan selesai — ${tpl(d).name} kini +${d.plus}${p.enchant ? ', sihir ikut pindah' : ''}.`, dst: d };
  },
};

/* ================= General shop (fixed prices) ================= */
const Shop = {
  stock: ['p_potion', 'p_potion_hi', 'm_stone', 'm_stone_hi', 'm_protect', 'm_enchant', 'm_essence', 'g_ruby', 'g_sapphire', 'g_topaz', 'g_emerald', 'g_onyx', 'g_garnet'],
  buy(tid, qty) {
    qty = qty || 1;
    const price = Math.round(ITEMS[tid].price * 1.25) * qty;
    if (Game.player.gold < price) return { ok: false, msg: 'Gold tidak cukup.' };
    Game.player.gold -= price; Inv.add(tid, qty);
    Game.quest.onBuy();
    return { ok: true, msg: `Dibeli ${ITEMS[tid].name} x${qty} — ${fmt(price)} G` };
  },
};

function fmt(n) { return Math.round(n).toLocaleString('id-ID'); }
