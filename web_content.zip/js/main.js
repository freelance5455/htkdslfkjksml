'use strict';
/* ===== Game: input, player, camera, HUD, minimap, loop ===== */
const $ = id => document.getElementById(id);
const P = { x: 0, y: 0, z: 12, vy: 0, h: 0, hp: 100, money: 500, wanted: 0, mode: 'foot', veh: null, fireCd: 0, dead: 0, lastCrime: 0, anim: 0, punch: 0, mesh: null };
const cam = { yaw: 0, pitch: .3, x: 0, y: 4, z: 0, lastDrag: -9 };
const input = { jx: 0, jy: 0, fire: false, jumpQ: false, useQ: false, brake: false, gas: false, brakeBtn: false };
let started = false, time = 0, last = performance.now(), zoneT = 0, spawnT = 0, toastT = 0, curZone = '', miniT = 0;

/* ---------- input ---------- */
const stick = $('stick'), knob = $('knob'); let sid = null, sv = [0, 0];
// screen vector -> game vector (on portrait phones the #app box is rotated 90deg)
const toLocal = (dx, dy) => isRot() ? [dy, -dx] : [dx, dy];
function moveStick(e) {
  const carMode = P.mode === 'car';
  const r = stick.getBoundingClientRect(), R = stick.offsetWidth / 2 - (carMode ? 24 : 8);
  let [dx, dy] = toLocal(e.clientX - (r.left + r.width / 2), e.clientY - (r.top + r.height / 2));
  if (carMode) dy = 0;                          // steering is horizontal only
  const l = Math.hypot(dx, dy);
  if (l > R) { dx = dx / l * R; dy = dy / l * R; }
  knob.style.transform = `translate(${dx}px,${dy}px)`;
  sv = [clamp(dx / R, -1, 1), carMode ? 0 : clamp(-dy / R, -1, 1)];
}
stick.addEventListener('pointerdown', e => { sid = e.pointerId; stick.setPointerCapture(e.pointerId); moveStick(e); e.preventDefault(); });
stick.addEventListener('pointermove', e => { if (e.pointerId === sid) moveStick(e); });
const endStick = e => { if (e.pointerId === sid) { sid = null; sv = [0, 0]; knob.style.transform = ''; } };
stick.addEventListener('pointerup', endStick); stick.addEventListener('pointercancel', endStick);

function hold(el, down, up) {
  const u = () => { el.classList.remove('down'); if (up) up(); };
  el.addEventListener('pointerdown', e => { el.setPointerCapture(e.pointerId); el.classList.add('down'); down(); e.preventDefault(); });
  el.addEventListener('pointerup', u); el.addEventListener('pointercancel', u);
}
hold($('bFire'), () => input.fire = true, () => input.fire = false);
hold($('bJump'), () => { input.jumpQ = true; input.brake = true; }, () => input.brake = false);
hold($('bUse'), () => input.useQ = true);
hold($('bCarUse'), () => input.useQ = true);
hold($('bGas'), () => input.gas = true, () => input.gas = false);
hold($('bBrake'), () => input.brakeBtn = true, () => input.brakeBtn = false);

const look = $('look'); let lid = null, lx = 0, ly = 0;
look.addEventListener('pointerdown', e => { lid = e.pointerId; lx = e.clientX; ly = e.clientY; look.setPointerCapture(e.pointerId); });
look.addEventListener('pointermove', e => {
  if (e.pointerId !== lid) return;
  const [ux, uy] = toLocal(e.clientX - lx, e.clientY - ly);
  cam.yaw -= ux * .0055; cam.pitch = clamp(cam.pitch + uy * .004, -.05, 1.15);
  lx = e.clientX; ly = e.clientY; cam.lastDrag = time;
});
const endLook = e => { if (e.pointerId === lid) lid = null; };
look.addEventListener('pointerup', endLook); look.addEventListener('pointercancel', endLook);

const keys = {};
addEventListener('keydown', e => {
  if (e.repeat) return; keys[e.code] = true;
  if (e.code === 'Space') { input.jumpQ = true; e.preventDefault(); }
  if (e.code === 'KeyE') input.useQ = true;
});
addEventListener('keyup', e => { keys[e.code] = false; });
function readInput() {
  let jx = sv[0], jy = sv[1];
  if (keys.KeyD || keys.ArrowRight) jx += 1; if (keys.KeyA || keys.ArrowLeft) jx -= 1;
  if (keys.KeyW || keys.ArrowUp) jy += 1; if (keys.KeyS || keys.ArrowDown) jy -= 1;
  if (P.mode === 'car') {
    // car: steering on the left; gas and brake on the right
    jx = clamp(jx, -1, 1);
    jy = (input.gas || keys.KeyW || keys.ArrowUp) ? 1 : (input.brakeBtn || keys.KeyS || keys.ArrowDown) ? -1 : 0;
  } else {
    const l = Math.hypot(jx, jy); if (l > 1) { jx /= l; jy /= l; }
  }
  input.jx = started ? jx : 0; input.jy = started ? jy : 0;
  input.fireNow = started && (input.fire || keys.KeyF);
  input.brakeNow = keys.ShiftLeft;   // handbrake on keyboard only
}

/* ---------- HUD helpers ---------- */
function toast(t, bad, ms) {
  const el = $('toast'); el.textContent = t; el.className = 'show' + (bad ? ' bad' : ''); toastT = ms || 2.2;
}
let hitT = 0;
function hurtPlayer(d) {
  if (P.dead > 0) return;
  P.hp -= d; hitT = .18; $('hud').style.boxShadow = 'inset 0 0 90px 10px rgba(220,30,30,.55)';
  if (d > 3) audioHit();
}

/* ---------- crime ---------- */
function onCrime(level, x, z) {
  let near = false;
  for (const w of walkers) if (w.kind === 'cop' && w.state !== 'dead' && Math.hypot(w.x - x, w.z - z) < 90) { near = true; break; }
  const lv = near ? level : (level >= 2 ? 1 : 0);
  if (lv > P.wanted) { P.wanted = Math.min(5, lv); toast('أنت مطلوب للشرطة', true, 1.6); }
  if (lv > 0) P.lastCrime = time;
}
function onKill(w) {
  if (w.kind === 'cop') { P.money += 100; P.wanted = clamp(Math.max(P.wanted + 1, 3), 0, 5); P.lastCrime = time; }
  else { P.money += rint(15, 70); onCrime(2, w.x, w.z); }
}

/* ---------- vehicles ---------- */
function nearestVehicle() {
  let best = null, bd = 4.6;
  for (const c of cars) { if (c.mode === 'player' || c.mode === 'chase') continue; const d = Math.hypot(c.x - P.x, c.z - P.z); if (d < bd) { bd = d; best = { type: 'car', obj: c }; } }
  if (plane && !plane.pilot && Math.hypot(plane.x - P.x, plane.z - P.z) < 9) best = { type: 'plane', obj: plane };
  return best;
}
function enterVehicle(v) {
  if (v.type === 'car') {
    const c = v.obj;
    if (c.mode === 'ai') {
      const w = newWalker('civ'); w.x = c.x + Math.cos(c.h) * 2.4; w.z = c.z - Math.sin(c.h) * 2.4; w.state = 'flee'; w.timer = 6;
      onCrime(1, c.x, c.z);
    }
    if (c.kind === 'police') onCrime(3, c.x, c.z);
    c.mode = 'player'; c.stun = 0; P.mode = 'car'; P.veh = c;
  } else { P.mode = 'plane'; plane.pilot = true; }
  P.mesh.visible = false; $('bUse').querySelector('span').textContent = 'نزول';
}
function exitVehicle() {
  if (P.mode === 'car') {
    const c = P.veh; if (Math.abs(c.speed) > 12) { toast('أوقف السيارة أولاً'); return; }
    P.x = c.x + Math.cos(c.h) * 2.6; P.z = c.z - Math.sin(c.h) * 2.6; c.mode = 'parked'; P.veh = null;
  } else {
    if (plane.y > .5 || plane.speed > 12) { toast('لا يمكن النزول أثناء الطيران'); return; }
    P.x = plane.x + Math.cos(plane.h) * 4; P.z = plane.z - Math.sin(plane.h) * 4; plane.pilot = false;
  }
  P.mode = 'foot'; P.y = 0; P.mesh.visible = true; $('bUse').querySelector('span').textContent = 'ركوب';
}

function driveCar(dt) {
  const c = P.veh, th = input.jy, st = input.jx;
  if (th > .05) c.speed += (c.speed < 0 ? 36 : 19) * th * dt;
  else if (th < -.05) c.speed += (c.speed > .5 ? -38 : -12) * -th * dt;
  else c.speed *= 1 - .35 * dt;
  if (input.brakeNow) c.speed *= Math.max(0, 1 - 3.2 * dt);
  c.speed = clamp(c.speed, -9, 34);
  c.steer += (st - c.steer) * Math.min(1, dt * 8);
  c.h -= c.steer * clamp(c.speed / 9, -1, 1) * 1.55 * dt * (1 - Math.min(.55, Math.abs(c.speed) / 70));
  c.x += Math.sin(c.h) * c.speed * dt; c.z += Math.cos(c.h) * c.speed * dt;
  if (pushOut(c, 2.1)) {
    const s = Math.abs(c.speed);
    if (s > 10) { c.hp -= s * 1.6; hurtPlayer(s * .12); }
    c.speed *= -.2;
  }
  clampWorld(c);
  for (const o of cars) {
    if (o === c || o.mode === 'player') continue;
    const dx = o.x - c.x, dz = o.z - c.z, d = Math.hypot(dx, dz);
    if (d < 3.6 && d > .01) {
      const nx = dx / d, nz = dz / d, push = 3.6 - d;
      o.x += nx * push; o.z += nz * push;
      if (Math.abs(c.speed) > 4) { o.stun = 2; o.speed *= .3; if (o.mode === 'ai') onCrime(1, o.x, o.z); if (o.kind === 'police') onCrime(2, o.x, o.z); c.hp -= Math.abs(c.speed) * .8; c.speed *= .55; }
    }
  }
  if (Math.abs(c.speed) > 5) for (const w of walkers) {
    if (w.state === 'dead') continue;
    if (Math.hypot(w.x - c.x, w.z - c.z) < 1.9) { hurtWalker(w, 300, true); c.speed *= .93; }
  }
  if (c.hp <= 0) {
    explode(c.x, 1.5, c.z); removeCar(c); P.veh = null; P.mode = 'foot'; P.mesh.visible = true; P.y = 0;
    $('bUse').querySelector('span').textContent = 'ركوب'; hurtPlayer(45); onCrime(1, P.x, P.z);
    return;
  }
  updateCarVisual(c, dt);
  P.x = c.x; P.z = c.z;
}

/* ---------- shooting ---------- */
function playerFire(dt) {
  P.fireCd -= dt; P.punch = Math.max(0, P.punch - dt);
  if (!input.fireNow || P.fireCd > 0) return;
  P.fireCd = .24; audioShot();
  const ox = P.x, oz = P.z, fxv = Math.sin(cam.yaw), fzv = Math.cos(cam.yaw);
  if (P.mode === 'plane') { fireTracer(plane.x, plane.y + 1.4, plane.z, plane.x + Math.sin(plane.h) * 90, plane.y + 1.4 - plane.pitch * 40, plane.z + Math.cos(plane.h) * 90); return; }
  if (P.mode === 'foot') {
    let mel = null, md = 2.1;
    for (const w of walkers) if (w.state !== 'dead') { const d = Math.hypot(w.x - ox, w.z - oz); if (d < md) { md = d; mel = w; } }
    if (mel) { P.h = Math.atan2(mel.x - ox, mel.z - oz); P.punch = .25; hurtWalker(mel, 26, true); return; }
  }
  let best = null, bs = 1e9;
  const consider = (t, x, z, kind) => {
    const dx = x - ox, dz = z - oz, d = Math.hypot(dx, dz); if (d < 1.5 || d > 55) return;
    const dot = (dx * fxv + dz * fzv) / d; if (dot < .88) return;
    const sc = d * (1.6 - dot * 1.2); if (sc < bs && los(ox, oz, x, z)) { bs = sc; best = { t, x, z, kind }; }
  };
  for (const w of walkers) if (w.state !== 'dead') consider(w, w.x, w.z, 'w');
  for (const c of cars) if (c.mode !== 'player') consider(c, c.x, c.z, 'c');
  const y0 = P.mode === 'foot' ? 1.3 : 1.5;
  if (P.mode === 'foot') P.h = best ? Math.atan2(best.x - ox, best.z - oz) : cam.yaw;
  P.punch = 0;
  if (best) {
    fireTracer(ox, y0, oz, best.x, 1.1, best.z);
    if (best.kind === 'w') hurtWalker(best.t, 34, true);
    else { best.t.hp -= 30; onCrime(1, best.x, best.z); if (best.t.hp <= 0) { explode(best.x, 1.5, best.z); removeCar(best.t); } }
  } else fireTracer(ox, y0, oz, ox + fxv * 45, y0, oz + fzv * 45);
  for (const w of walkers) if (w.kind === 'civ' && w.state === 'walk' && Math.hypot(w.x - ox, w.z - oz) < 22) { w.state = 'flee'; w.timer = 5; }
}

/* ---------- on foot ---------- */
function updateFoot(dt) {
  const fx = Math.sin(cam.yaw), fz = Math.cos(cam.yaw), rx = -fz, rz = fx;
  let dx = fx * input.jy + rx * input.jx, dz = fz * input.jy + rz * input.jx;
  const mag = Math.min(1, Math.hypot(input.jx, input.jy)), l = Math.hypot(dx, dz);
  let spd = 0;
  if (l > .05) { dx /= l; dz /= l; spd = mag > .8 ? 7.6 : mag * 5.2; P.h = turnTo(P.h, Math.atan2(dx, dz), dt * 12); }
  P.x += dx * spd * dt; P.z += dz * spd * dt;
  if (input.jumpQ && P.y <= .01) P.vy = 9;
  P.vy -= 26 * dt; P.y += P.vy * dt; if (P.y < 0) { P.y = 0; P.vy = 0; }
  pushOut(P, .45); clampWorld(P);
  const m = P.mesh; m.visible = true;
  m.position.set(P.x, .2 + P.y, P.z); m.rotation.y = P.h;
  if (spd > .1 && P.y < .05) { P.anim += dt * (spd > 5.5 ? 13 : 8); swing(m, spd > 5.5 ? 1 : .6, P.anim); } else swing(m, 0, 0);
  const armed = input.fireNow || P.punch > 0;
  m.userData.limbs.gun.visible = armed;
  if (P.punch > 0) m.userData.limbs.armR.rotation.x = -1.5;
  else if (input.fireNow) m.userData.limbs.armR.rotation.x = -1.4;
}

function flyPlane(dt) {
  updatePlane(dt, input.jx, input.jy, true);
  P.x = plane.x; P.z = plane.z;
  if (plane.crashed) {
    explode(plane.x, plane.y + 1, plane.z); plane.crashed = false; P.hp = 0;
  }
}

/* ---------- camera ---------- */
function updateCamera(dt) {
  let tx = P.x, ty = P.y + 1.6, tz = P.z, dist = 7.2;
  if (P.mode === 'car') { tx = P.veh.x; tz = P.veh.z; ty = 1.6; dist = 10.5; }
  else if (P.mode === 'plane') { tx = plane.x; ty = plane.y + 2; tz = plane.z; dist = 22; }
  if (!started) { cam.yaw += dt * .12; cam.pitch = .38; dist = 15; }
  else if (P.mode !== 'foot' && time - cam.lastDrag > 1.4) {
    const h = P.mode === 'car' ? (P.veh.speed < -1.5 ? P.veh.h + Math.PI : P.veh.h) : plane.h;
    cam.yaw = turnTo(cam.yaw, h, dt * 1.8);
  }
  const cp = Math.cos(cam.pitch);
  const dx = tx - Math.sin(cam.yaw) * cp * dist, dy = ty + Math.sin(cam.pitch) * dist, dz = tz - Math.cos(cam.yaw) * cp * dist;
  const k = Math.min(1, dt * 12);
  cam.x += (dx - cam.x) * k; cam.y += (dy - cam.y) * k; cam.z += (dz - cam.z) * k;
  camera.position.set(cam.x, Math.max(.7, cam.y), cam.z); camera.lookAt(tx, ty + .3, tz);
  skyMesh.position.copy(camera.position);
}

/* ---------- police spawning, wanted decay ---------- */
function ringPoint(minD, maxD) {
  for (let i = 0; i < 10; i++) {
    const a = Math.random() * Math.PI * 2, d = rnd(minD, maxD);
    let x = P.x + Math.sin(a) * d, z = P.z + Math.cos(a) * d;
    if (Math.random() < .5) x = clamp(Math.round(x / PITCH), -NR, NR) * PITCH + 6; else z = clamp(Math.round(z / PITCH), -NR, NR) * PITCH + 6;
    const p = { x, z }; clampWorld(p);
    if (!insideBuilding(p.x, p.z, 2.5)) return p;
  }
  return null;
}
function spawnPolice() {
  if (P.wanted <= 0) return;
  let foot = 0, cc = 0;
  for (const w of walkers) if (w.kind === 'cop' && w.state === 'chase') foot++;
  for (const c of cars) if (c.mode === 'chase') cc++;
  if (foot < Math.min(2 + P.wanted, 7) && walkers.length < 180) {
    const p = ringPoint(55, 90); if (p) { const w = newWalker('cop', p.x, p.z); w.x = p.x; w.z = p.z; w.state = 'chase'; }
  }
  if (cc < (P.wanted >= 2 ? Math.min(P.wanted - 1, 3) : 0)) {
    const p = ringPoint(90, 130);
    if (p) { const c = newCar(p.x, p.z, Math.atan2(P.x - p.x, P.z - p.z), 0x0f1b3d, 'police', 'chase'); c.speed = 8; }
  }
}

/* ---------- death ---------- */
function respawn() {
  if (P.veh) { P.veh.mode = 'parked'; P.veh = null; }
  if (plane.pilot) { plane.pilot = false; plane.x = 232; plane.y = .02; plane.z = -110; plane.h = Math.PI / 2; plane.speed = 0; plane.pitch = 0; plane.roll = 0; syncPlane(); }
  P.mode = 'foot'; P.x = 0; P.z = 12; P.y = 0; P.hp = 100; P.wanted = 0; P.money = Math.max(0, P.money - 100);
  P.mesh.visible = true; P.mesh.rotation.x = 0; $('bUse').querySelector('span').textContent = 'ركوب';
  for (const w of walkers) if (w.kind === 'cop' && w.state === 'chase') { w.state = 'leave'; w.timer = 10; }
  toast('تم نقلك إلى المستشفى', false, 2.2);
}

/* ---------- HUD ---------- */
const starEls = [...document.querySelectorAll('#stars b')], hpFill = $('hpfill'), moneyEl = $('money'), zoneEl = $('zone'), speedEl = $('speed'), promptEl = $('prompt');
const mctx = $('mini').getContext('2d'), north = $('north');
function updateHud(dt) {
  starEls.forEach((s, i) => s.classList.toggle('on', i < P.wanted));
  const hp = clamp(P.hp, 0, 100); hpFill.style.width = hp + '%'; hpFill.style.background = hp > 55 ? 'var(--ok)' : hp > 25 ? '#facc15' : 'var(--hot)';
  moneyEl.textContent = '$' + P.money;
  zoneT -= dt; if (zoneT <= 0) { zoneT = .5; const z = zoneName(P.x, P.z) + ' · ' + timeName() + ' · ' + weatherName(); if (z !== curZone) { curZone = z; zoneEl.textContent = z; } }
  const inV = P.mode !== 'foot';
  $('app').classList.toggle('carmode', P.mode === 'car');
  speedEl.hidden = !inV;
  if (inV) speedEl.firstChild.nodeValue = Math.round(Math.abs(P.mode === 'car' ? P.veh.speed : plane.speed) * 3.6);
  if (started && P.dead <= 0) {
    if (P.mode === 'foot') { const v = nearestVehicle(); promptEl.hidden = !v; if (v) promptEl.textContent = v.type === 'plane' ? 'اضغط «ركوب» لقيادة الطائرة' : 'اضغط «ركوب» للدخول للسيارة'; }
    else { promptEl.hidden = P.mode !== 'plane' || plane.y > .5; if (!promptEl.hidden) promptEl.textContent = 'الجويستيك لأعلى للتسارع، وعند السرعة العالية اسحب للإقلاع'; }
  } else promptEl.hidden = true;
  toastT -= dt; if (toastT <= 0) $('toast').className = '';
  if (hitT > 0) { hitT -= dt; if (hitT <= 0) $('hud').style.boxShadow = ''; }
  if (time - miniT > .066) { miniT = time; drawMini(); }   // minimap at about 15 fps is enough
}
function drawMini() {
  const s = 1.15, W = 300, g = mctx;
  g.save(); g.clearRect(0, 0, W, W);
  g.beginPath(); g.arc(150, 150, 150, 0, Math.PI * 2); g.clip();
  g.fillStyle = '#10202e'; g.fillRect(0, 0, W, W);
  g.translate(150, 150); g.rotate(Math.PI + cam.yaw); g.scale(s, s); g.translate(-P.x, -P.z);
  g.drawImage(mapBase.canvas, -mapBase.ox, -mapBase.oz);
  const dot = (x, z, r, c) => { g.fillStyle = c; g.beginPath(); g.arc(x, z, r / s * 1.15, 0, 7); g.fill(); };
  const flash = Math.floor(time * 4) % 2;
  for (const w of walkers) if (w.kind === 'cop' && w.state !== 'dead') dot(w.x, w.z, 3, w.state === 'chase' ? (flash ? '#ff3b3b' : '#3b6bff') : '#4a7dff');
  for (const c of cars) if (c.kind === 'police' && c.mode !== 'player') dot(c.x, c.z, 4, flash ? '#ff3b3b' : '#3b6bff');
  if (plane) dot(plane.x, plane.z, 4, '#ffffff');
  g.translate(P.x, P.z); g.rotate(-(P.mode === 'car' ? P.veh.h : P.mode === 'plane' ? plane.h : P.h)); g.scale(1 / s, 1 / s);
  g.fillStyle = '#ffd34d'; g.strokeStyle = '#111'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, 11); g.lineTo(-7, -7); g.lineTo(0, -3); g.lineTo(7, -7); g.closePath(); g.fill(); g.stroke();
  g.restore();
  const phi = Math.PI + cam.yaw; north.style.left = (75 + 74 * Math.sin(phi)) + 'px'; north.style.top = (75 - 74 * Math.cos(phi)) + 'px';
}

/* ---------- main update ---------- */
function update(dt) {
  readInput();
  if (P.dead > 0) { P.dead -= dt; if (P.dead <= 0) respawn(); }
  else {
    if (input.useQ && started) { if (P.mode === 'foot') { const v = nearestVehicle(); if (v) enterVehicle(v); } else exitVehicle(); }
    if (P.mode === 'foot') updateFoot(dt); else if (P.mode === 'car') driveCar(dt); else flyPlane(dt);
    playerFire(dt);
    if (P.hp <= 0) { P.dead = 3.2; toast('انتهت حياتك', true, 3); if (P.mode === 'foot') P.mesh.rotation.x = -Math.PI / 2; }
  }
  input.jumpQ = false; input.useQ = false;
  if (P.mode !== 'plane') updatePlane(dt, 0, 0, false);
  for (let i = walkers.length - 1; i >= 0; i--) updateWalker(walkers[i], dt, P);
  for (let i = cars.length - 1; i >= 0; i--) { const c = cars[i]; if (c.mode !== 'player') updateCar(c, dt, P); }
  for (let i = cars.length - 1; i >= 0; i--) { const c = cars[i]; if (c.hp <= 0 && c.mode !== 'player') { explode(c.x, 1.5, c.z); removeCar(c); } else if (c.mode === 'parkedcop' && P.wanted <= 0 && Math.hypot(c.x - P.x, c.z - P.z) > 110) removeCar(c); }
  spawnT -= dt; if (spawnT <= 0) { spawnT = 2; spawnPolice(); }
  if (P.wanted > 0 && time - P.lastCrime > 22) { P.wanted--; P.lastCrime = time; if (P.wanted === 0) toast('اختفت المطلوبية'); }
  updateTracers(dt); updateBlasts(dt);
  waterTex.offset.set(time * .004, time * .007);
  updateCamera(dt); updateHud(dt);
}

/* engine, siren and rain follow the game state */
function updateAudioLoop(dt) {
  const alive = P.dead <= 0;
  if (alive && P.mode === 'car') audioEngine(true, Math.abs(P.veh.speed), Math.max(0, input.jy));
  else if (alive && P.mode === 'plane') audioEngine(true, plane.speed * .5, Math.abs(input.jy));
  else audioEngine(false, 0, 0);
  audioSiren(started && P.wanted > 0, dt);
  audioRain(ENV.amt.rain + ENV.amt.snow * .3);
}

/* lower the render resolution when the frame rate drops, and raise it again when there is headroom */
let prAcc = 0, prN = 0;
function adaptPR(dt) {
  prAcc += dt; prN++;
  if (prN < 90) return;
  const avg = prAcc / prN; prAcc = 0; prN = 0;
  const cap = maxPixelRatio();
  if (curPR == null) curPR = cap;
  if (avg > .022 && curPR > .6) { curPR = Math.max(.6, +(curPR - .1).toFixed(2)); renderer.setPixelRatio(curPR); }
  else if (avg < .0145 && curPR < cap) { curPR = Math.min(cap, +(curPR + .1).toFixed(2)); renderer.setPixelRatio(curPR); }
}

function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(.05, (now - last) / 1000); last = now; time += dt;
  update(dt);
  updateAudioLoop(dt);
  updateEnv(dt, P.x, P.z);
  adaptPR(dt);
  renderer.render(scene, camera);
}

/* ---------- boot ---------- */
try {
  initWorld($('gl'));
  initEnv();
  populate();
  P.mesh = makeHuman(0xb91c1c, 0x1e293b, 0xc68642, false, { hair: 0x1b1008, style: 'short', shoe: 0x0f0f0f }); P.mesh.traverse(o => { if (o.isMesh) o.castShadow = true; });
  P.mesh.position.set(P.x, .2, P.z); scene.add(P.mesh);
  cam.x = P.x; cam.z = P.z - 8;
  $('go').disabled = false; $('go').textContent = 'ابدأ اللعب';
  $('go').addEventListener('click', () => {
    started = true; $('start').hidden = true; cam.yaw = 0; cam.pitch = .3; P.lastCrime = time;
    audioInit();
    try { const r = document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); if (r && r.catch) r.catch(() => { }); } catch (e) { }
  });
  $('bMute').addEventListener('click', () => {
    audioSetMuted(!AUD.muted);
    $('bMute').querySelector('span').textContent = AUD.muted ? 'صامت' : 'صوت';
  });
  requestAnimationFrame(frame);
} catch (err) {
  $('loadmsg').textContent = 'تعذّر تشغيل الرسوم ثلاثية الأبعاد على هذا الجهاز: ' + err.message;
}
