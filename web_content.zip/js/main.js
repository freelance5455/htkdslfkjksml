window.KJ=window.KJ||{};
document.addEventListener("DOMContentLoaded",()=>{
 document.getElementById("add-button").addEventListener("click",KJ.openTransaction);
 window.addEventListener("hashchange",KJ.render);
 document.querySelectorAll("[data-route]").forEach(b=>b.addEventListener("click",()=>location.hash=b.dataset.route));
 if(!location.hash)location.hash="#/beranda";KJ.render();
});
