/* =========================================================
   عيادة الفتح البيطرية - Behaviour (v2)
   ========================================================= */
(function () {
  'use strict';

  const html = document.documentElement;
  const header = document.getElementById('siteHeader');
  const progress = document.getElementById('progress');
  const navInner = document.getElementById('navInner');
  const pill = document.getElementById('pill');
  const langBtn = document.getElementById('langBtn');
  const navLinks = Array.from(document.querySelectorAll('.nav a[href^="#"]'));
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Storage helpers (safe in private mode) ---------- */
  const store = {
    get(key) {
      try { return localStorage.getItem(key); } catch (e) { return null; }
    },
    set(key, value) {
      try { localStorage.setItem(key, value); } catch (e) { /* ignore */ }
    }
  };

  /* ---------- Reveal delays from data-delay ---------- */
  document.querySelectorAll('[data-delay]').forEach(function (el) {
    el.style.setProperty('--d', el.dataset.delay + 'ms');
  });

  /* ---------- Scroll reveal ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- Sliding pill for the active nav item ---------- */
  function movePill(link) {
    if (!link || !pill) return;
    const r = link.getBoundingClientRect();
    const base = navInner.getBoundingClientRect();
    pill.style.width = r.width + 'px';
    pill.style.height = r.height + 'px';
    pill.style.transform = 'translate(' + (r.left - base.left) + 'px, ' + (r.top - base.top) + 'px)';
  }

  function setActive(id) {
    let activeLink = null;
    navLinks.forEach(function (a) {
      const on = a.getAttribute('href') === id;
      a.classList.toggle('active', on);
      if (on) activeLink = a;
    });
    if (activeLink) movePill(activeLink);
  }

  /* ---------- Header state, progress bar, scroll-spy ---------- */
  const sections = navLinks
    .map(function (a) { return document.querySelector(a.getAttribute('href')); })
    .filter(Boolean);

  let currentId = '';
  let ticking = false;

  function onScroll() {
    const y = window.scrollY || window.pageYOffset;
    header.classList.toggle('scrolled', y > 16);

    const max = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.transform = 'scaleX(' + (max > 0 ? y / max : 0) + ')';

    const probe = y + window.innerHeight * 0.35;
    let nextId = '';
    sections.forEach(function (sec) {
      if (sec.offsetTop <= probe) nextId = '#' + sec.id;
    });
    if (nextId !== currentId) {
      currentId = nextId;
      setActive(currentId);
    }
  }

  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(function () {
        onScroll();
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });

  // Clicking a nav item glides the pill immediately; the scroll-spy keeps it in sync.
  navLinks.forEach(function (a) {
    a.addEventListener('click', function () { setActive(a.getAttribute('href')); });
  });

  window.addEventListener('resize', function () {
    const active = navLinks.find(function (a) { return a.classList.contains('active'); });
    movePill(active);
  });

  /* ---------- Language toggle (Arabic RTL / English LTR) ---------- */
  const textNodes = document.querySelectorAll('[data-ar][data-en]');

  function applyLang(lang) {
    const isEn = lang === 'en';
    html.lang = isEn ? 'en' : 'ar';
    html.dir = isEn ? 'ltr' : 'rtl';
    textNodes.forEach(function (el) {
      el.textContent = isEn ? el.dataset.en : el.dataset.ar;
    });
    langBtn.textContent = isEn ? 'عربي' : 'EN';
    document.title = isEn
      ? 'Al-Fath Veterinary Clinic | Dr. Mohamed Essam'
      : 'عيادة الفتح البيطرية | د. محمد عصام';
    store.set('fath-lang', lang);
    updateStatus();
    // Direction change moves items, so re-measure the pill after layout settles.
    requestAnimationFrame(function () {
      const active = navLinks.find(function (a) { return a.classList.contains('active'); });
      movePill(active);
    });
  }

  langBtn.addEventListener('click', function () {
    applyLang(html.lang === 'en' ? 'ar' : 'en');
  });

  /* ---------- Live open/closed status (Cairo time, Sun-Thu 14:00-20:00) ---------- */
  const openPill = document.getElementById('openPill');
  const openPillText = document.getElementById('openPillText');
  const statusCardText = document.getElementById('statusCardText');
  const statusCard = document.getElementById('statusCard');

  function cairoNow() {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Africa/Cairo',
      weekday: 'short',
      hour: 'numeric',
      hourCycle: 'h23'
    }).formatToParts(new Date());
    const get = function (type) {
      const p = parts.find(function (x) { return x.type === type; });
      return p ? p.value : '';
    };
    return { day: get('weekday'), hour: parseInt(get('hour'), 10) };
  }

  function isOpenNow() {
    try {
      const now = cairoNow();
      const workDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu'];
      return workDays.indexOf(now.day) !== -1 && now.hour >= 14 && now.hour < 20;
    } catch (e) {
      return false;
    }
  }

  function updateStatus() {
    const isEn = html.lang === 'en';
    const open = isOpenNow();

    openPillText.textContent = open
      ? (isEn ? 'Open now' : 'مفتوح الآن')
      : (isEn ? 'Currently closed' : 'مغلق حالياً');
    openPill.querySelector('.dot').className = 'dot ' + (open ? 'on' : 'off');

    statusCardText.textContent = open
      ? (isEn ? 'Open now' : 'مفتوح الآن')
      : (isEn ? 'Opens 2 PM' : 'نفتح 2 ظهراً');
    statusCard.querySelector('.dot').className = 'dot ' + (open ? 'on' : 'off');
  }

  /* ---------- Footer year ---------- */
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  /* ---------- Init ---------- */
  const saved = store.get('fath-lang');
  applyLang(saved === 'en' ? 'en' : 'ar');
  onScroll();
})();
