/* Vstupní bod – inicializace uložiště, registrace komponent a spuštění.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.store.init();
  BD.studio.enable(BD.dev.studio);                         // Studio zapnuté příkazem „dev“: přepíše herní data uloženými úpravami

  var app = Vue.createApp(BD.ui.App);
  var C = BD.ui.components;
  app.component('ic', C.Ic);
  app.component('bd-backdrop', C.Backdrop);
  app.component('bd-level-preview', C.LevelPreview);
  app.component('bd-intro', C.Intro);
  app.component('bd-main-menu', C.MainMenu);
  app.component('bd-settings', C.Settings);
  app.component('bd-story-map', C.StoryMap);
  app.component('bd-game-view', C.GameView);
  app.component('bd-editor-view', C.EditorView);
  app.component('bd-terminal', C.Terminal);
  app.component('bd-bestiary', C.Bestiary);
  app.component('bd-sil', C.Silhouette);
  app.component('bd-studio-view', C.StudioView);
  app.mount('#app');
})(window.BD);
