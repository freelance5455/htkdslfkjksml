import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { Component } from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App.js';
import { AuthProvider } from './lib/AuthContext.js';
class Boundary extends Component {
    constructor() {
        super(...arguments);
        this.state = { err: null };
    }
    static getDerivedStateFromError(err) { return { err }; }
    render() {
        if (this.state.err) {
            return (_jsxs("div", { className: "splash", children: [_jsx("h2", { children: "Kuch masla aa gaya" }), _jsx("p", { style: { maxWidth: 420, wordBreak: 'break-word' }, children: String(this.state.err.message || this.state.err) }), _jsx("button", { className: "btn", onClick: () => location.reload(), children: "Dobara try karein" })] }));
        }
        return this.props.children;
    }
}
ReactDOM.createRoot(document.getElementById('root')).render(_jsx(React.StrictMode, { children: _jsx(Boundary, { children: _jsx(HashRouter, { children: _jsx(AuthProvider, { children: _jsx(App, {}) }) }) }) }));
