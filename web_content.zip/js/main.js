'use strict';
let prevT=performance.now();
function frame(now){
  const dt=Math.min(.033,(now-prevT)/1000);prevT=now;rdt=dt;
  if(state==='lobby')lobbyDraw(dt);
  else{update(dt);draw();hudUpdate()}
  requestAnimationFrame(frame);
}
function initUI(){
  $('bFire').innerHTML=ICONS.fire;$('bRel').innerHTML=ICONS.reload+'<i class="bd"></i>';$('bSwap').innerHTML=ICONS.swap;
  $('bGren').innerHTML=ICONS.gren+'<i class="bd"></i>';$('bGloo').innerHTML=ICONS.gloo+'<i class="bd"></i>';
  $('bBand').innerHTML=ICONS.band+'<i class="bd"></i>';$('bMed').innerHTML=ICONS.med+'<i class="bd"></i>';$('bSmk').innerHTML=ICONS.smoke+'<i class="bd"></i>';
  $('bPause').innerHTML=ICONS.pause;$('bRel').querySelector('.bd').remove();
  document.querySelectorAll('[data-p]').forEach(b=>b.addEventListener('click',()=>{snd('click');openPanel(b.dataset.p)}));
  $('pclose').onclick=()=>{snd('click');closePanel()};
  $('start').onclick=()=>{ac();snd('click');startMatch()};
  $('lModeBtn').onclick=()=>{snd('click');openPanel('mode')};
  $('dailyBtn').onclick=claimDaily;
  $('again').onclick=()=>{startMatch()};
  $('toLobby').onclick=()=>{showLobby()};
  $('resume').onclick=resumeGame;
  $('pSet').onclick=()=>openPanel('set');
  $('leave').onclick=()=>{showLobby()};
}
initUI();bindInput();resize();addEventListener('resize',()=>{resize()});
showLobby();applyTouchUI();
requestAnimationFrame(frame);
window.__dbg={startMatch,startMatchNow,get state(){return state},get players(){return players},get player(){return player},prof,set,MAPS,genWorld,openPanel,closePanel,update,draw,endMatch,get aliveN(){return aliveN},setState:s=>{state=s}};
