/* main.js — boot, game loop, autosave. */
(function (G) {
  'use strict';
  let last = 0, lastMonthSaved = -1, uiAcc = 0;

  function frame(t) {
    const dt = Math.min(0.25, (t - last) / 1000); last = t;
    if (G.state && G.state.player) {
      const days = G.update(dt);
      if (days) {
        uiAcc = 0; G.updateTopBar(); G.refreshPanel();
        const key = G.state.date.y * 12 + G.state.date.m;
        if (key !== lastMonthSaved) { if (lastMonthSaved !== -1) G.saveGame('auto'); lastMonthSaved = key; }
      }
    }
    G.renderFrame(t);
    requestAnimationFrame(frame);
  }

  window.addEventListener('DOMContentLoaded', () => {
    // A placeholder world lets the map render behind the start menu.
    G.newGame(null);
    G.initMap(document.getElementById('map'));
    G.bindUI();
    G.showStart();
    G.fitView();
    requestAnimationFrame(t => { last = t; frame(t); });
  });
  window.addEventListener('beforeunload', () => { if (G.state && G.state.player) G.saveGame('auto'); });
})(window.EMP = window.EMP || {});
