/* ============================================================
   main.js — bootstrap, state machine, game loop, HUD, UI wiring
   BADAL 3D EXTREME RACING
   ============================================================ */
'use strict';

const ST = {
  LOADING: 0, MENU: 1, GARAGE: 2, MODES: 3, MISSIONS: 4,
  SETTINGS: 5, PLAYING: 6, PAUSED: 7, OVER: 8,
};

/* global singletons (car.js references `audio` too) */
const audio = new EngineAudio();
const input = new InputManager();

const DRIFT_GOAL = 12000;

class Game {
  constructor() {
    this.state = ST.LOADING;
    this.save = new SaveSystem();
    this.missions = new MissionSystem(this.save);

    this._el = {};
    this._last = performance.now() / 1000;
    this._hudAcc = 0;
    this._hudForce = true;
    this._fpsAcc = 0;
    this._fpsFrames = 0;
    this._mTimer = 0;
    this._flashTimer = 0;
    this._mtTimer = 0;
    this._resetArm = 0;
    this._garageIndex = 0;
    this._previewSpec = null;
    this._modeId = 'free';
    this._mode = MODE_BY_ID.free;
    this._run = null;
    this._heat = 0;
    this._mAcc = { distance: 0, nitro: 0, policeTime: 0, overtakes: 0, nearMiss: 0 };
    this._loopBound = (t) => this._loop(t);

    this.isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

    this._cb = {
      onCrash: (info) => this._onCrash(info),
      onOvertake: (n) => this._onOvertake(n),
      onNearMiss: (n) => this._onNearMiss(n),
      onPickup: (t) => this._onPickup(t),
      onPoliceContact: (info) => this._onPoliceContact(info),
    };
  }

  /* ================================================================
     BOOT
     ================================================================ */
  async boot() {
    this._cacheEls();
    this._bindUI();

    await this._sleep(50);
    this._setLoad(6, 'Starting engine…');
    this._initRenderer();
    this._buildEnvMap();

    await this._sleep(70);
    this._setLoad(20, 'Building the city…');
    this.env = new Environment(this.scene, this.renderer, this.envMap);

    await this._sleep(70);
    this._setLoad(48, 'Assembling supercars…');
    this.car = new PlayerCar(this.scene, this.envMap);
    this.car.group.visible = false;
    this.traffic = new Traffic(this.scene, this.envMap);
    this.camRig = new CameraRig(this.camera);

    await this._sleep(70);
    this._setLoad(74, 'Opening the showroom…');
    this.garage = new Garage(this.envMap);
    this.garage.resize(window.innerWidth, window.innerHeight);

    this._applyAllSettings();
    this._resize();

    await this._sleep(70);
    this._setLoad(92, 'Tuning engines…');
    const spec = this.selectedSpec;
    this.garage.showCar(spec, this.save.paintOf(spec.id));

    await this._sleep(230);
    this._setLoad(100, 'Ready to race');
    await this._sleep(280);

    this._el['loading-screen'].classList.add('done');
    setTimeout(() => this._el['loading-screen'].classList.add('hidden'), 560);

    this._showMenu();
    requestAnimationFrame(this._loopBound);

    /* unlock audio on first gesture */
    const unlock = () => {
      audio.init();
      audio.resume();
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
  }

  _sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

  _setLoad(pct, text) {
    const f = this._el['load-fill'], t = this._el['load-text'];
    if (f) f.style.width = pct + '%';
    if (t) t.textContent = text;
  }

  get selectedSpec() { return CAR_BY_ID[this.save.data.selected] || CARS[0]; }

  /* ================================================================
     RENDERER / ENV MAP
     ================================================================ */
  _initRenderer() {
    const canvas = document.getElementById('game-canvas');
    this.renderer = new THREE.WebGLRenderer({
      canvas, antialias: true, powerPreference: 'high-performance',
      alpha: false, stencil: false,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    if ('outputColorSpace' in this.renderer) this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.3, 4200);
    this.camera.position.set(0, 4, 10);
  }

  _buildEnvMap() {
    const tex = AD.canvasTexture(512, 256, (g, w, h) => {
      const sky = g.createLinearGradient(0, 0, 0, h);
      sky.addColorStop(0, '#122140');
      sky.addColorStop(0.34, '#3b4d78');
      sky.addColorStop(0.47, '#c07a68');
      sky.addColorStop(0.5, '#ffc489');
      sky.addColorStop(0.54, '#2a2f3a');
      sky.addColorStop(0.72, '#12161e');
      sky.addColorStop(1, '#05070b');
      g.fillStyle = sky; g.fillRect(0, 0, w, h);

      // soft sun bloom
      const sun = g.createRadialGradient(w * 0.62, h * 0.5, 2, w * 0.62, h * 0.5, h * 0.2);
      sun.addColorStop(0, 'rgba(255,240,210,0.95)');
      sun.addColorStop(0.5, 'rgba(255,190,120,0.35)');
      sun.addColorStop(1, 'rgba(255,170,90,0)');
      g.fillStyle = sun; g.fillRect(0, 0, w, h);

      // city light streaks (for paint reflections)
      const cols = ['rgba(46,230,255,0.85)', 'rgba(255,46,136,0.7)', 'rgba(255,196,0,0.7)', 'rgba(160,200,255,0.8)'];
      for (let i = 0; i < 46; i++) {
        g.fillStyle = cols[i % cols.length];
        const cw = 2 + Math.random() * 9;
        g.globalAlpha = 0.12 + Math.random() * 0.35;
        g.fillRect(Math.random() * w, h * 0.53 + Math.random() * h * 0.45, cw, 2 + Math.random() * 10);
      }
      g.globalAlpha = 1;
    });
    tex.mapping = THREE.EquirectangularReflectionMapping;
    tex.colorSpace = THREE.SRGBColorSpace;

    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      pmrem.compileEquirectangularShader();
      this.envMap = pmrem.fromEquirectangular(tex).texture;
      pmrem.dispose();
    } catch (e) {
      this.envMap = tex;
    }
    if (this.envMap !== tex) tex.dispose();
  }

  /* ================================================================
     MAIN LOOP
     ================================================================ */
  _loop(now) {
    requestAnimationFrame(this._loopBound);
    const t = (now || 0) / 1000;
    let dt = t - this._last;
    this._last = t;
    if (!isFinite(dt) || dt <= 0) dt = 1 / 60;
    dt = Math.min(dt, 0.05);

    input.update(dt);
    this._handleEdges();

    if (this.state === ST.PLAYING) this._updatePlay(dt);

    this._render(dt);
  }

  _handleEdges() {
    if (input.consumePause()) {
      if (this.state === ST.PLAYING) this._pause();
      else if (this.state === ST.PAUSED) this._resume();
      else if (this.state === ST.GARAGE || this.state === ST.MODES ||
               this.state === ST.MISSIONS || this.state === ST.SETTINGS) this._showMenu();
    }
    if (this.state === ST.PLAYING) {
      if (input.consumeRestart()) { this._restart(); return; }
      if (input.consumeCamera()) this._cycleCamera();
      if (input.consumeHorn()) audio.horn();
    } else {
      input.consumeRestart();
      input.consumeCamera();
      input.consumeHorn();
    }
  }

  _render(dt) {
    if (!this.renderer) return;
    const menuStates = [ST.MENU, ST.GARAGE, ST.MODES, ST.MISSIONS, ST.SETTINGS];
    if (menuStates.indexOf(this.state) >= 0) {
      this.garage.update(dt);
      if (this.state === ST.MENU) {
        this.garage.camera.position.set(0, 2.05, 8.3);
        this.garage.camera.lookAt(0, 0.84, 0);
      }
      this.renderer.render(this.garage.scene, this.garage.camera);
    } else if (this.state === ST.LOADING) {
      /* nothing yet */
    } else {
      this.renderer.render(this.scene, this.camera);
    }
  }

  _resize() {
    if (!this.renderer) return;
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    if (this.camera) {
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
    }
    if (this.garage) this.garage.resize(w, h);
  }

  /* ================================================================
     STATE / SCREENS
     ================================================================ */
  _setState(state) {
    this.state = state;
    const E = this._el;
    const map = {
      'menu-screen': ST.MENU,
      'garage-screen': ST.GARAGE,
      'modes-screen': ST.MODES,
      'missions-screen': ST.MISSIONS,
      'settings-screen': ST.SETTINGS,
    };
    for (const id in map) E[id].classList.toggle('hidden', state !== map[id]);

    const hudOn = state === ST.PLAYING || state === ST.PAUSED;
    E['hud'].classList.toggle('hidden', !hudOn);
    E['pause-screen'].classList.toggle('hidden', state !== ST.PAUSED);
    E['results-screen'].classList.toggle('hidden', state !== ST.OVER);

    const showControls = state === ST.PLAYING && (this.isTouch || document.body.classList.contains('force-controls'));
    E['controls'].classList.toggle('hidden', !showControls);

    document.body.classList.toggle('playing', state === ST.PLAYING || state === ST.PAUSED || state === ST.OVER);
  }

  _showMenu() {
    audio.stop();
    if (this.car) this.car.group.visible = false;
    if (this._run) this._run = null;
    const spec = this.selectedSpec;
    if (this.garage) this.garage.showCar(spec, this.save.paintOf(spec.id));
    this._refreshMenu();
    this._updateCoins();
    this._setState(ST.MENU);
  }

  /* ================================================================
     COINS / MENU REFRESH
     ================================================================ */
  _updateCoins() {
    const E = this._el;
    const coins = this.save.data.coins;
    ['menu-coins', 'garage-coins', 'modes-coins', 'missions-coins', 'settings-coins']
      .forEach((id) => { if (E[id]) E[id].textContent = AD.formatNum(coins); });
    if (E['menu-owned']) E['menu-owned'].textContent = this.save.data.owned.length + '/' + CARS.length;
  }

  _refreshMenu() {
    const E = this._el;
    if (!E['menu-screen']) return;
    const bestFree = Math.max(this.save.best('free'), this.save.best('extreme'));
    E['menu-best'].textContent = AD.formatNum(bestFree) + ' m';
    E['menu-topspeed'].textContent = Math.round(this.save.best('top')) + ' km/h';
    E['menu-earned'].textContent = AD.formatNum(this.save.data.stats.coinsEarned);
    E['menu-owned'].textContent = this.save.data.owned.length + '/' + CARS.length;
    const dot = E['mission-dot'];
    if (dot) dot.classList.toggle('hidden', this.missions.claimableCount() === 0);
  }

  /* ================================================================
     RUN LIFECYCLE
     ================================================================ */
  startRun(modeId) {
    this._modeId = MODE_BY_ID[modeId] ? modeId : 'free';
    const mode = MODE_BY_ID[this._modeId];
    this._mode = mode;

    const spec = this.selectedSpec;
    this.car.setSpec(spec);
    this.car.setPaint(this.save.paintOf(spec.id));
    this.car.autoTransmission = this.save.settings.transmission === 'auto';
    this.car.speedLimitMul = this._modeId === 'extreme' ? 1.07 : 1;
    this.car.group.visible = true;
    this.car.reset(0, ENV.lanes[1]);

    this.traffic.reset(0, this._modeId);
    this.traffic.setPoliceCount(this._modeId === 'police' ? 1 : 0);

    this.camRig.setMode(this.save.settings.camera);
    this.camRig.snap(this.car);

    this.env.timeOfDay = this.save.settings.time;
    this.env.autoTime = true;
    this.env.setWeather(this.save.settings.weather);

    input.reset();
    audio.setCar(spec);
    audio.start();

    this._run = {
      time: 0, timeLeft: mode.time, dist: 0, coins: 0,
      overtakes: 0, nearMiss: 0, drift: 0, topSpeed: 0,
      nitroTime: 0, bestCombo: 1, rank: 1, crashes: 0,
      policeHits: 0, finishTime: 0,
    };
    this._heat = 0;
    this._mAcc = { distance: 0, nitro: 0, policeTime: 0, overtakes: 0, nearMiss: 0 };
    this._mTimer = 0;

    this._configureHud(mode);
    this._updateHud();
    this._setState(ST.PLAYING);

    this._toast(mode.name + ' · ' + mode.goal, 'gold');
  }

  _restart() {
    this.startRun(this._modeId);
  }

  _pause() {
    if (this.state !== ST.PLAYING) return;
    this._setState(ST.PAUSED);
    audio.suspend();
    const run = this._run;
    this._el['pause-distance'].textContent = AD.formatNum(run.dist) + ' m';
    this._el['pause-speed'].textContent = Math.round(Math.abs(this.car.getSpeedKmh())) + ' km/h';
    this._el['pause-coins'].textContent = AD.formatNum(run.coins);
    this._syncSoundLabel();
  }

  _resume() {
    if (this.state !== ST.PAUSED) return;
    this._setState(ST.PLAYING);
    audio.resume();
    input.reset();
    this._last = performance.now() / 1000;
  }

  _syncSoundLabel() {
    const b = this._el['btn-sound-p'];
    if (b) b.textContent = this.save.settings.mute ? '🔇 SOUND: OFF' : '🔊 SOUND: ON';
  }

  _abandon() {
    if (this._run && (this.state === ST.PLAYING || this.state === ST.PAUSED)) {
      this._endRun(false, 'quit', true);
    }
    this._run = null;
    if (this.car) this.car.group.visible = false;
    audio.stop();
  }

  /* ================================================================
     PLAY UPDATE
     ================================================================ */
  _updatePlay(dt) {
    const run = this._run, mode = this._mode, car = this.car;
    if (!run) return;

    run.time += dt;
    if (mode.time > 0) run.timeLeft = Math.max(0, mode.time - run.time);

    const envCtx = {
      gripMul: this.env.gripMul, wet: this.env.wet,
      night: this.env.night, bounds: this.env.bounds,
    };
    car.update(dt, input, envCtx);

    if (!this.save.settings.headlights) {
      if (car.headMat) car.headMat.emissiveIntensity = 1.3;
      if (car.beamMat) car.beamMat.opacity = 0;
      if (car.headSpot) car.headSpot.intensity = 0;
    }

    const prev = run.dist;
    run.dist = Math.max(run.dist, Math.max(0, -car.pos.z));
    const delta = run.dist - prev;

    this.traffic.update(dt, car, this._cb);

    this.env.update(dt, car.pos, this.camRig.pos);
    this.camRig.update(dt, car, this.env);

    run.topSpeed = Math.max(run.topSpeed, Math.abs(car.getSpeedKmh()));
    if (car.nitroActive) run.nitroTime += dt;
    if (mode.id === 'drift') run.drift = car.driftScore;
    run.bestCombo = Math.max(run.bestCombo, car.driftCombo);

    /* mission accumulation */
    this._mAcc.distance += delta;
    if (car.nitroActive) this._mAcc.nitro += dt;
    if (mode.id === 'police') this._mAcc.policeTime += dt;
    this._mTimer += dt;
    if (this._mTimer >= 0.5) {
      this._mTimer = 0;
      this._flushMissions(false);
    }

    /* police heat */
    if (mode.id === 'police') {
      this._heat = AD.clamp(run.time / mode.time, 0, 1);
      const want = run.time > 70 ? 3 : run.time > 30 ? 2 : 1;
      let activeCount = 0;
      for (const p of this.traffic.police) if (p.active) activeCount++;
      if (activeCount < want) this.traffic.setPoliceCount(want);
    }

    /* audio */
    audio.update(dt, {
      rpm: car.rpm,
      throttle: input.throttle,
      speedKmh: Math.abs(car.getSpeedKmh()),
      gear: car.gear,
      drift: Math.min(1, Math.abs(car.slip) * 3.4),
      nitro: car.nitroActive,
      rain: this.env.rainAmount,
      siren: mode.id === 'police' && this.traffic.nearestPolice(car) < 90,
      gearCount: car.gearCount,
    });

    this._checkRunEnd();

    this._hudAcc += dt;
    if (this._hudAcc >= 0.055 || this._hudForce) {
      this._hudAcc = 0;
      this._hudForce = false;
      this._updateHud();
    }
    this._updateFps(dt);
  }

  _checkRunEnd() {
    const run = this._run, mode = this._mode;
    if (!run) return;

    if (this.car.damage >= 0.999) { this._endRun(false, 'wrecked'); return; }

    if (mode.id === 'race') {
      if (run.dist >= mode.distance) {
        run.rank = this.traffic.getRank(this.car.pos.z);
        run.finishTime = run.time;
        this._endRun(run.rank === 1, 'race');
      }
      return;
    }

    if (mode.id === 'time') {
      if (run.dist >= mode.distance) {
        run.finishTime = run.time;
        this._endRun(true, 'time');
      } else if (run.timeLeft <= 0) {
        this._endRun(false, 'timeout');
      }
      return;
    }

    if (mode.time > 0 && run.timeLeft <= 0) {
      if (mode.id === 'police') this._endRun(true, 'police');
      else if (mode.id === 'drift') this._endRun(run.drift >= DRIFT_GOAL, 'drift');
      else this._endRun(true, 'timeout');
    }
  }

  /* ================================================================
     TRAFFIC CALLBACKS
     ================================================================ */
  _onCrash(info) {
    const impact = info.impact || 0;
    this.car.applyCrash(impact, info.pushX, info.pushZ);
    this._run.crashes++;
    audio.crash(Math.min(1, impact / 42));
    this.camRig.addShake(Math.min(1.3, 0.25 + impact / 55));
    if (impact > 16) this._flashScreen();
  }

  _onPoliceContact(info) {
    this.car.applyCrash(info.impact || 12, info.pushX, info.pushZ);
    this.car.damage = Math.min(1, this.car.damage + 0.035);
    this._run.policeHits++;
    audio.crash(1);
    this.camRig.addShake(1.1);
    this._flashScreen();
  }

  _onOvertake(n) {
    if (!this._run) return;
    this._run.overtakes += n;
    this._mAcc.overtakes += n;
  }

  _onNearMiss(n) {
    if (!this._run) return;
    this._run.nearMiss += n;
    this._mAcc.nearMiss += n;
    this._run.coins += 6 * n;
    audio.ui();
  }

  _onPickup(type) {
    if (!this._run) return;
    if (type === 'coin') {
      this._run.coins += 25;
      audio.coin();
    } else if (type === 'fuel') {
      this.car.addFuel(0.35);
      audio.ui();
      this._toast('FUEL +35%', 'good');
    } else if (type === 'nitro') {
      this.car.addNitro(0.4);
      audio.ui();
      this._toast('NITRO +40%', 'good');
    }
  }

  _flashScreen() {
    const f = this._el['flash'];
    if (!f) return;
    f.classList.add('on');
    clearTimeout(this._flashTimer);
    this._flashTimer = setTimeout(() => f.classList.remove('on'), 70);
  }

  _cycleCamera() {
    const mode = this.camRig.cycle();
    this.save.setSetting('camera', mode);
    this._syncSegs();
    this._toast('CAMERA: ' + (CAMERA_LABELS[mode] || mode), 'gold');
  }

  /* ================================================================
     RUN END / RESULTS
     ================================================================ */
  _computeReward(success, reason) {
    const run = this._run, id = this._modeId;
    if (reason === 'quit') return run.coins;
    let bonus = 0;
    switch (id) {
      case 'free': bonus = Math.round(run.dist * 0.06); break;
      case 'race': bonus = success ? 1000 : run.rank === 2 ? 550 : run.rank === 3 ? 350 : 180; break;
      case 'traffic': bonus = Math.round(run.overtakes * 22); break;
      case 'drift': bonus = Math.round(run.drift * 0.06); break;
      case 'police': bonus = Math.round(run.time * 9); break;
      case 'time': bonus = success ? 900 : Math.round(run.dist * 0.14); break;
      case 'extreme': bonus = Math.round(run.dist * 0.1); break;
      default: bonus = 0;
    }
    return Math.max(0, Math.round(run.coins + bonus));
  }

  _endRun(success, reason, silent) {
    if (this.state !== ST.PLAYING && this.state !== ST.PAUSED) return;
    const run = this._run, mode = this._mode;
    if (!run) return;

    this._flushMissions(true);
    const reward = this._computeReward(success, reason);
    this.save.addCoins(reward);

    let newBest = false;

    if (reason !== 'quit') {
      this.save.addStat('distance', Math.round(run.dist));
      this.save.addStat('overtakes', run.overtakes);
      this.save.addStat('drift', Math.round(run.drift));
      this.save.addStat('nearMiss', run.nearMiss);
      this.save.addStat('nitro', Math.round(run.nitroTime));
      if (mode.id === 'police') this.save.addStat('policeTime', Math.round(run.time));
      this.save.addStat('runs', 1);
      this.save.setBest('top', Math.round(run.topSpeed));

      switch (mode.id) {
        case 'free': newBest = this.save.setBest('free', Math.round(run.dist)); break;
        case 'race':
          if (success) { this.save.data.raceWins++; this.save.save(); newBest = true; }
          break;
        case 'traffic': newBest = this.save.setBest('traffic', run.overtakes); break;
        case 'drift': newBest = this.save.setBest('drift', Math.round(run.drift)); break;
        case 'police': newBest = this.save.setBest('police', Math.round(run.time)); break;
        case 'time': if (success) newBest = this.save.setBestTime(run.time); break;
        case 'extreme': newBest = this.save.setBest('extreme', Math.round(run.dist)); break;
      }
      this._trackMission('races', 1);
      this._flushMissions(true);
    }

    this.save.save();
    audio.stop();
    this.car.group.visible = false;
    this._updateCoins();
    this._refreshMenu();

    if (silent) {
      this._run = null;
      this._setState(ST.MENU);
      return;
    }

    this._showResults(success, reason, reward, newBest);
    this._setState(ST.OVER);
  }

  _showResults(success, reason, reward, newBest) {
    const run = this._run, mode = this._mode, E = this._el;

    let kicker = 'RUN COMPLETE';
    let title = 'NICE DRIVING';
    let sub = 'Solid run. Push harder for a bigger reward.';

    if (reason === 'wrecked') {
      kicker = 'RUN ENDED'; title = 'WRECKED';
      sub = 'Your car took too much damage. Try a smoother line.';
    } else if (mode.id === 'race') {
      kicker = 'RACE COMPLETE';
      if (success) { title = 'VICTORY'; sub = 'You won the 3 km highway race. Champion!'; }
      else { title = 'P' + run.rank + ' FINISH'; sub = 'So close. Better lines and nitro will get you P1.'; }
    } else if (mode.id === 'time') {
      kicker = 'TIME TRIAL';
      if (success) { title = 'TARGET REACHED'; sub = 'Finished in ' + AD.formatTime(run.finishTime) + '.'; }
      else { title = 'TIME UP'; sub = 'You reached ' + AD.formatNum(run.dist) + ' of 2,500 m.'; }
    } else if (mode.id === 'police') {
      kicker = 'POLICE CHASE';
      title = 'YOU ESCAPED';
      sub = 'You survived the full 2 minutes of heat.';
    } else if (mode.id === 'drift') {
      kicker = 'DRIFT CHALLENGE';
      if (success) { title = 'DRIFT KING'; sub = 'Target smashed with ' + AD.formatNum(run.drift) + ' points.'; }
      else { title = 'TIME UP'; sub = 'You scored ' + AD.formatNum(run.drift) + ' of ' + AD.formatNum(DRIFT_GOAL) + ' points.'; }
    } else if (mode.id === 'traffic') {
      kicker = 'TRAFFIC CHALLENGE';
      title = 'RUN COMPLETE';
      sub = 'You carved through ' + run.overtakes + ' traffic cars.';
    } else if (mode.id === 'extreme') {
      kicker = 'EXTREME SPEED';
      title = 'RUN COMPLETE';
      sub = 'You covered ' + AD.formatNum(run.dist) + ' m at extreme pace.';
    }

    E['result-kicker'].textContent = kicker;
    E['result-title'].textContent = title;
    E['result-sub'].textContent = sub;

    const cells = [
      { label: 'DISTANCE', value: AD.formatNum(run.dist) + ' m' },
      { label: 'TOP SPEED', value: Math.round(run.topSpeed) + ' km/h' },
    ];
    switch (mode.id) {
      case 'race':
        cells.push({ label: 'POSITION', value: 'P' + run.rank, cls: success ? 'good' : '' });
        cells.push({ label: 'RACE TIME', value: AD.formatTime(run.time) });
        break;
      case 'traffic':
        cells.push({ label: 'OVERTAKES', value: String(run.overtakes), cls: 'gold' });
        cells.push({ label: 'NEAR MISSES', value: String(run.nearMiss) });
        break;
      case 'drift':
        cells.push({ label: 'DRIFT SCORE', value: AD.formatNum(run.drift), cls: 'good' });
        cells.push({ label: 'BEST COMBO', value: 'x' + run.bestCombo.toFixed(1) });
        break;
      case 'police':
        cells.push({ label: 'SURVIVED', value: AD.formatTime(run.time) });
        cells.push({ label: 'POLICE HITS', value: String(run.policeHits) });
        break;
      case 'time':
        cells.push({ label: 'FINISH TIME', value: run.finishTime ? AD.formatTime(run.finishTime) : '—' });
        cells.push({ label: 'BEST EVER', value: this.save.data.bestTime ? AD.formatTime(this.save.data.bestTime) : '—', cls: 'gold' });
        break;
      case 'extreme':
        cells.push({ label: 'NITRO USED', value: Math.round(run.nitroTime) + ' s' });
        cells.push({ label: 'NEAR MISSES', value: String(run.nearMiss) });
        break;
      default:
        cells.push({ label: 'COINS FOUND', value: String(run.coins), cls: 'gold' });
        cells.push({ label: 'RUN TIME', value: AD.formatTime(run.time) });
    }

    if (newBest) cells.push({ label: 'NEW RECORD', value: 'YES', cls: 'good' });

    E['result-grid'].innerHTML = cells.map((c) =>
      '<div><small>' + c.label + '</small><b class="' + (c.cls || '') + '">' + c.value + '</b></div>'
    ).join('');

    E['result-coins'].textContent = '+' + AD.formatNum(reward);
    audio.mission();
  }

  /* ================================================================
     HUD
     ================================================================ */
  _configureHud(mode) {
    const E = this._el, car = this.car;
    E['hud-mode-name'].textContent = mode.name;
    E['hud-objective'].textContent = mode.goal;
    E['hud-timer-label'].textContent = mode.time > 0 ? 'TIME LEFT' : 'TIME';
    E['hud-rank-wrap'].classList.toggle('hidden', mode.id !== 'race');
    E['hud-heat-wrap'].classList.toggle('hidden', mode.id !== 'police');
    E['hud-drift-wrap'].classList.toggle('hidden', mode.id !== 'drift');
    E['hud-accel'].textContent = car.spec.accel.toFixed(1) + 's';
    E['hud-top'].textContent = String(car.spec.top);
    E['hud-trans'].textContent = car.autoTransmission ? 'AUTO' : 'MANUAL';
  }

  _updateHud() {
    const E = this._el, car = this.car, run = this._run;
    if (!run) return;

    const kmh = Math.abs(car.getSpeedKmh());
    E['hud-speed'].textContent = String(Math.round(kmh));

    const gearTxt = car.gear === -1 ? 'R' : car.gear === 0 ? 'N' : String(car.gear);
    E['hud-gear'].textContent = gearTxt;
    if (E['gear-display']) E['gear-display'].textContent = gearTxt;

    E['hud-distance'].textContent = AD.formatNum(run.dist);
    E['hud-coins'].textContent = AD.formatNum(this.save.data.coins + run.coins);
    E['hud-zone'].textContent = this.env.zoneAt(car.pos.z);

    const rpmPct = AD.clamp(car.rpm / car.redline, 0, 1) * 100;
    E['rpm-fill'].style.width = rpmPct.toFixed(1) + '%';
    E['hud-rpm-v'].textContent = String(Math.round(car.rpm));

    const fuelPct = AD.clamp(car.fuel, 0, 1) * 100;
    E['hud-fuel'].style.width = fuelPct.toFixed(1) + '%';
    E['hud-fuel-v'].textContent = Math.round(fuelPct) + '%';

    const nitroPct = AD.clamp(car.nitro, 0, 1) * 100;
    E['hud-nitro'].style.width = nitroPct.toFixed(1) + '%';
    E['hud-nitro-v'].textContent = Math.round(nitroPct) + '%';

    const dmgPct = AD.clamp(car.damage, 0, 1) * 100;
    E['hud-damage'].style.width = dmgPct.toFixed(1) + '%';
    E['hud-damage-v'].textContent = Math.round(dmgPct) + '%';

    if (this._mode.time > 0) {
      E['hud-timer'].textContent = AD.formatTime(run.timeLeft);
      E['hud-timer-wrap'].classList.toggle('urgent', run.timeLeft <= 10);
    } else {
      E['hud-timer'].textContent = AD.formatTime(run.time);
      E['hud-timer-wrap'].classList.remove('urgent');
    }

    if (this._mode.id === 'race') {
      run.rank = this.traffic.getRank(car.pos.z);
      E['hud-rank'].textContent = 'P' + run.rank + '/6';
    }
    if (this._mode.id === 'police') {
      E['hud-heat'].style.width = (this._heat * 100).toFixed(1) + '%';
    }
    if (this._mode.id === 'drift') {
      E['hud-drift'].textContent = AD.formatNum(car.driftScore);
      E['hud-combo'].textContent = 'x' + car.driftCombo.toFixed(1);
    }
  }

  _updateFps(dt) {
    this._fpsAcc += dt;
    this._fpsFrames++;
    if (this._fpsAcc >= 0.5) {
      const fps = Math.round(this._fpsFrames / this._fpsAcc);
      const el = this._el['hud-fps'];
      if (el) el.textContent = fps + ' FPS';
      this._fpsAcc = 0;
      this._fpsFrames = 0;
    }
  }

  /* ================================================================
     MISSIONS
     ================================================================ */
  _flushMissions(force) {
    const a = this._mAcc;
    if (!a) return;
    if (a.distance > 0) { this._trackMission('distance', a.distance); a.distance = 0; }
    if (a.overtakes > 0) { this._trackMission('overtakes', a.overtakes); a.overtakes = 0; }
    if (a.nearMiss > 0) { this._trackMission('nearMiss', a.nearMiss); a.nearMiss = 0; }
    if (a.nitro > 0) { this._trackMission('nitro', a.nitro); a.nitro = 0; }
    if (a.policeTime > 0) { this._trackMission('policeTime', a.policeTime); a.policeTime = 0; }
    if (this._run) {
      const done = this.missions.trackMax('topSpeed', Math.round(this._run.topSpeed));
      if (done.length) done.forEach((m) => this._missionComplete(m));
    }
    if (force) this._refreshMenu();
  }

  _trackMission(type, amount) {
    if (!amount) return;
    const done = this.missions.track(type, amount);
    if (done.length) done.forEach((m) => this._missionComplete(m));
  }

  _missionComplete(m) {
    const el = this._el['mission-toast'];
    if (!el) return;
    this._el['mission-toast-text'].textContent = m.label + ' — claim ' + m.reward + ' coins';
    el.classList.remove('hidden');
    clearTimeout(this._mtTimer);
    this._mtTimer = setTimeout(() => el.classList.add('hidden'), 3800);
    audio.mission();
    const dot = this._el['mission-dot'];
    if (dot) dot.classList.remove('hidden');
  }

  /* ================================================================
     TOASTS
     ================================================================ */
  _toast(text, kind) {
    const layer = this._el['toast-layer'];
    if (!layer) return;
    const el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = text;
    layer.appendChild(el);
    while (layer.children.length > 3) layer.removeChild(layer.firstChild);
    setTimeout(() => {
      el.classList.add('out');
      setTimeout(() => el.remove(), 320);
    }, 2000);
  }

  /* ================================================================
     UI WIRING
     ================================================================ */
  _cacheEls() {
    const ids = [
      'loading-screen', 'load-fill', 'load-text', 'flash', 'toast-layer', 'rotate-hint',
      'menu-screen', 'menu-coins', 'menu-owned', 'menu-best', 'menu-topspeed', 'menu-earned',
      'btn-quick', 'btn-modes', 'btn-garage', 'btn-missions', 'btn-settings', 'mission-dot',
      'garage-screen', 'btn-garage-back', 'garage-coins', 'car-list',
      'garage-brand', 'garage-name', 'garage-class', 'garage-desc',
      'stat-speed', 'stat-speed-v', 'stat-accel', 'stat-accel-v',
      'stat-handle', 'stat-handle-v', 'stat-grip', 'stat-grip-v',
      'paint-swatches', 'garage-price-label', 'garage-price', 'btn-buy-car', 'btn-select-car',
      'btn-car-prev', 'btn-car-next', 'garage-index',
      'modes-screen', 'btn-modes-back', 'modes-coins', 'modes-grid',
      'missions-screen', 'btn-missions-back', 'missions-coins', 'mission-list',
      'settings-screen', 'btn-settings-back', 'settings-coins',
      'vol-master', 'vol-master-v', 'vol-engine', 'vol-engine-v', 'vol-sfx', 'vol-sfx-v',
      'time-of-day', 'time-of-day-v', 'btn-reset-progress',
      'pause-screen', 'pause-distance', 'pause-speed', 'pause-coins',
      'btn-resume', 'btn-restart-p', 'btn-pause-garage', 'btn-pause-menu', 'btn-sound-p',
      'results-screen', 'result-kicker', 'result-title', 'result-sub', 'result-grid',
      'result-coins', 'btn-retry', 'btn-results-garage', 'btn-results-menu',
      'hud', 'btn-pause', 'hud-mode-name', 'hud-objective', 'hud-timer-wrap',
      'hud-timer-label', 'hud-timer', 'hud-coins', 'hud-distance', 'hud-zone',
      'hud-rank-wrap', 'hud-rank', 'hud-heat-wrap', 'hud-heat',
      'hud-drift-wrap', 'hud-drift', 'hud-combo', 'hud-damage', 'hud-damage-v',
      'hud-fuel', 'hud-fuel-v', 'hud-nitro', 'hud-nitro-v', 'hud-rpm-v', 'rpm-fill',
      'hud-speed', 'hud-gear', 'hud-accel', 'hud-top', 'hud-trans',
      'mission-toast', 'mission-toast-text', 'hud-fps',
      'controls', 'gear-display', 'steering-wheel', 'wheel-wrap',
      'steer-left', 'steer-right', 'pedal-gas', 'pedal-brake',
      'btn-nitro', 'btn-handbrake', 'btn-gear-up', 'btn-gear-down',
      'btn-camera', 'btn-horn', 'btn-restart-hud',
    ];
    for (const id of ids) this._el[id] = document.getElementById(id);
  }

  _bindUI() {
    const E = this._el;
    const on = (id, fn) => {
      const el = E[id];
      if (el) el.addEventListener('click', fn);
    };

    /* menu */
    on('btn-quick', () => { audio.ui(); this.startRun('free'); });
    on('btn-modes', () => { audio.ui(); this._openModes(); });
    on('btn-garage', () => { audio.ui(); this._openGarage(); });
    on('btn-missions', () => { audio.ui(); this._openMissions(); });
    on('btn-settings', () => { audio.ui(); this._openSettings(); });

    /* back buttons */
    on('btn-garage-back', () => { audio.ui(); this._showMenu(); });
    on('btn-modes-back', () => { audio.ui(); this._showMenu(); });
    on('btn-missions-back', () => { audio.ui(); this._showMenu(); });
    on('btn-settings-back', () => { audio.ui(); this._showMenu(); });

    /* garage */
    on('btn-car-prev', () => this._stepCar(-1));
    on('btn-car-next', () => this._stepCar(1));
    on('btn-buy-car', () => this._buyCar());
    on('btn-select-car', () => this._selectCar());

    /* pause */
    on('btn-resume', () => this._resume());
    on('btn-restart-p', () => { this.startRun(this._modeId); });
    on('btn-pause-garage', () => { this._abandon(); this._openGarage(); });
    on('btn-pause-menu', () => { this._abandon(); this._showMenu(); });
    on('btn-sound-p', () => {
      const mute = !this.save.settings.mute;
      this.save.setSetting('mute', mute);
      audio.setVolumes({ mute });
      this._syncSoundLabel();
      this._syncSegs();
    });

    /* results */
    on('btn-retry', () => this.startRun(this._modeId));
    on('btn-results-garage', () => { this._run = null; this._openGarage(); });
    on('btn-results-menu', () => { this._run = null; this._showMenu(); });

    /* settings segmented controls */
    document.querySelectorAll('.seg[data-setting]').forEach((seg) => {
      const key = seg.dataset.setting;
      seg.querySelectorAll('button').forEach((btn) => {
        btn.addEventListener('click', () => {
          audio.ui();
          this._applySetting(key, btn.dataset.value);
        });
      });
    });

    /* sliders */
    const bindSlider = (id, labelId, key, fmt) => {
      const el = E[id];
      if (!el) return;
      el.addEventListener('input', () => {
        const v = parseFloat(el.value);
        this.save.settings[key] = fmt(v);
        if (labelId && E[labelId]) E[labelId].textContent = Math.round(v) + '%';
        this._applyAudioSettings();
        this.save.save();
      });
    };
    bindSlider('vol-master', 'vol-master-v', 'master', (v) => v / 100);
    bindSlider('vol-engine', 'vol-engine-v', 'engine', (v) => v / 100);
    bindSlider('vol-sfx', 'vol-sfx-v', 'sfx', (v) => v / 100);

    if (E['time-of-day']) {
      E['time-of-day'].addEventListener('input', () => {
        const v = parseFloat(E['time-of-day'].value);
        this.save.settings.time = v;
        if (this.env) this.env.setTime(v);
        if (E['time-of-day-v']) E['time-of-day-v'].textContent = this._timeLabel(v);
        this.save.save();
      });
    }

    /* reset progress (double confirm) */
    on('btn-reset-progress', () => {
      const btn = E['btn-reset-progress'];
      if (!this._resetArm) {
        this._resetArm = setTimeout(() => {
          this._resetArm = 0;
          btn.textContent = 'RESET ALL PROGRESS';
          btn.classList.remove('armed');
        }, 3200);
        btn.textContent = 'TAP AGAIN TO CONFIRM';
        btn.classList.add('armed');
        return;
      }
      clearTimeout(this._resetArm);
      this._resetArm = 0;
      this.save.reset();
      this.missions.ensure();
      this._applyAllSettings();
      this._syncSettingsUI();
      this._refreshMenu();
      this._updateCoins();
      btn.textContent = 'PROGRESS RESET ✓';
      setTimeout(() => { btn.textContent = 'RESET ALL PROGRESS'; btn.classList.remove('armed'); }, 1800);
      audio.mission();
    });

    /* auto-pause when tab hidden */
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === ST.PLAYING) this._pause();
    });

    window.addEventListener('resize', () => this._resize());
    window.addEventListener('orientationchange', () => setTimeout(() => this._resize(), 260));
  }

  /* ================================================================
     GARAGE SCREEN
     ================================================================ */
  _openGarage() {
    this._garageIndex = Math.max(0, CARS.findIndex((c) => c.id === this.save.data.selected));
    this._renderGarageList();
    this._previewCar(this._garageIndex);
    this._updateCoins();
    this._setState(ST.GARAGE);
  }

  _stepCar(dir) {
    this._garageIndex = (this._garageIndex + dir + CARS.length) % CARS.length;
    this._previewCar(this._garageIndex);
    audio.ui();
  }

  _renderGarageList() {
    const wrap = this._el['car-list'];
    if (!wrap) return;
    wrap.innerHTML = CARS.map((c, i) => {
      const owned = this.save.isOwned(c.id);
      const selected = this.save.data.selected === c.id;
      const paint = PAINTS[this.save.paintOf(c.id)] || PAINTS[0];
      const hex = '#' + paint.hex.toString(16).padStart(6, '0');
      const cls = ['car-item'];
      if (i === this._garageIndex) cls.push('active');
      if (!owned) cls.push('locked');
      if (selected) cls.push('selected-car');
      const right = owned
        ? '<span class="ci-owned">' + (selected ? 'SELECTED' : 'OWNED') + '</span>'
        : '<span class="ci-price">● ' + AD.formatNum(c.price) + '</span>';
      return '<button class="' + cls.join(' ') + '" data-idx="' + i + '">' +
        '<span class="swatch" style="background:' + hex + '"></span>' +
        '<span class="ci-copy"><b>' + c.name + '</b><small>' + c.cls + '</small></span>' +
        right + '</button>';
    }).join('');

    wrap.querySelectorAll('[data-idx]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = parseInt(btn.dataset.idx, 10);
        if (i === this._garageIndex) return;
        this._garageIndex = i;
        this._previewCar(i);
        audio.ui();
      });
    });
  }

  _previewCar(index) {
    const spec = CARS[AD.clamp(index, 0, CARS.length - 1)];
    this._previewSpec = spec;
    const paint = this.save.paintOf(spec.id);
    const owned = this.save.isOwned(spec.id);
    const selected = this.save.data.selected === spec.id;
    const E = this._el;

    this.garage.showCar(spec, paint);

    E['garage-brand'].textContent = spec.brand;
    E['garage-name'].textContent = spec.name;
    E['garage-class'].textContent = spec.cls;
    E['garage-desc'].textContent = spec.desc;
    E['garage-index'].textContent = (index + 1) + ' / ' + CARS.length;

    const pct = (v, min, max) => (AD.clamp((v - min) / (max - min), 0, 1) * 100).toFixed(1) + '%';
    E['stat-speed'].style.width = pct(spec.top, 150, 375);
    E['stat-accel'].style.width = pct(10 - spec.accel, 0, 7.4);
    E['stat-handle'].style.width = pct(spec.handling, 5.5, 9.6);
    E['stat-grip'].style.width = pct(spec.grip, 5.5, 9.6);

    E['stat-speed-v'].textContent = String(spec.top);
    E['stat-accel-v'].textContent = spec.accel.toFixed(1) + 's';
    E['stat-handle-v'].textContent = spec.handling.toFixed(1);
    E['stat-grip-v'].textContent = spec.grip.toFixed(1);

    /* paint swatches */
    const sw = E['paint-swatches'];
    sw.innerHTML = PAINTS.map((p, i) => {
      const hex = '#' + p.hex.toString(16).padStart(6, '0');
      return '<button class="swatch-btn' + (i === paint ? ' active' : '') + '" data-paint="' + i +
        '" title="' + p.name + '" style="background:' + hex + '"></button>';
    }).join('');
    sw.querySelectorAll('[data-paint]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const pi = parseInt(btn.dataset.paint, 10);
        this.save.setPaint(spec.id, pi);
        this.garage.setPaint(pi);
        sw.querySelectorAll('[data-paint]').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        this._renderGarageList();
        audio.ui();
      });
    });

    /* price + buttons */
    E['btn-buy-car'].classList.toggle('hidden', owned);
    E['btn-select-car'].classList.toggle('hidden', !owned);
    E['garage-price-label'].textContent = owned ? 'STATUS' : 'PRICE';
    E['garage-price'].textContent = owned ? (selected ? 'SELECTED' : 'OWNED') : '● ' + AD.formatNum(spec.price);

    if (owned) {
      E['btn-select-car'].textContent = selected ? 'DRIVE THIS CAR' : 'SELECT CAR';
      E['btn-select-car'].classList.remove('disabled');
    } else {
      const afford = this.save.data.coins >= spec.price;
      E['btn-buy-car'].textContent = afford ? 'BUY CAR · ● ' + AD.formatNum(spec.price) : 'NEED ● ' + AD.formatNum(spec.price - this.save.data.coins) + ' MORE';
      E['btn-buy-car'].classList.toggle('disabled', !afford);
    }
  }

  _buyCar() {
    const spec = this._previewSpec;
    if (!spec || this.save.isOwned(spec.id)) return;
    if (this.save.data.coins < spec.price) {
      this._toast('NOT ENOUGH COINS', 'bad');
      return;
    }
    this.save.spendCoins(spec.price);
    this.save.unlockCar(spec.id);
    this.save.selectCar(spec.id);
    this._renderGarageList();
    this._previewCar(this._garageIndex);
    this._updateCoins();
    this._refreshMenu();
    audio.mission();
    this._toast(spec.name + ' UNLOCKED', 'good');
  }

  _selectCar() {
    const spec = this._previewSpec;
    if (!spec) return;
    if (!this.save.isOwned(spec.id)) return;
    if (this.save.data.selected !== spec.id) {
      this.save.selectCar(spec.id);
      this._renderGarageList();
      this._previewCar(this._garageIndex);
      this._refreshMenu();
      audio.ui();
      this._toast(spec.name + ' SELECTED', 'good');
      return;
    }
    audio.ui();
    this.startRun('free');
  }

  /* ================================================================
     MODES SCREEN
     ================================================================ */
  _openModes() {
    const grid = this._el['modes-grid'];
    grid.innerHTML = MODES.map((m) => {
      const best = this._modeBest(m.id);
      return '<button class="mode-card" data-mode="' + m.id + '" style="--accent:' + m.accent + '">' +
        '<div class="mc-top">' +
          '<span class="mc-icon">' + m.icon + '</span>' +
          '<span class="mc-best">' + best.label + '<b>' + best.value + '</b></span>' +
        '</div>' +
        '<h3>' + m.name + '</h3>' +
        '<p>' + m.desc + '</p>' +
        '<div class="mc-goal"><span>GOAL</span>' + m.goal + '</div>' +
      '</button>';
    }).join('');

    grid.querySelectorAll('[data-mode]').forEach((btn) => {
      btn.addEventListener('click', () => {
        audio.ui();
        this.startRun(btn.dataset.mode);
      });
    });

    this._updateCoins();
    this._setState(ST.MODES);
  }

  _modeBest(id) {
    const s = this.save;
    switch (id) {
      case 'free': return { label: 'BEST DISTANCE', value: AD.formatNum(s.best('free')) + ' m' };
      case 'race': return { label: 'RACE WINS', value: String(s.data.raceWins) };
      case 'traffic': return { label: 'BEST OVERTAKES', value: String(s.best('traffic')) };
      case 'drift': return { label: 'BEST SCORE', value: AD.formatNum(s.best('drift')) };
      case 'police': return { label: 'BEST SURVIVAL', value: AD.formatTime(s.best('police')) };
      case 'time': return { label: 'BEST TIME', value: s.data.bestTime ? AD.formatTime(s.data.bestTime) : '—' };
      case 'extreme': return { label: 'BEST DISTANCE', value: AD.formatNum(s.best('extreme')) + ' m' };
      default: return { label: 'BEST', value: '—' };
    }
  }

  /* ================================================================
     MISSIONS SCREEN
     ================================================================ */
  _openMissions() {
    this._renderMissions();
    this._updateCoins();
    this._setState(ST.MISSIONS);
  }

  _renderMissions() {
    const wrap = this._el['mission-list'];
    if (!wrap) return;
    const list = this.missions.list();

    wrap.innerHTML = list.map((m) => {
      const pct = Math.min(100, (m.progress / m.target) * 100);
      const ready = !m.claimed && m.progress >= m.target;
      const cls = ['mission-card'];
      if (ready) cls.push('ready');
      if (m.claimed) cls.push('claimed');
      const btnLabel = m.claimed ? 'CLAIMED ✓' : ready ? 'CLAIM REWARD' : 'IN PROGRESS';
      const prog = Math.round(m.progress).toLocaleString('en-US') + ' / ' + m.target.toLocaleString('en-US');
      return '<div class="' + cls.join(' ') + '">' +
        '<div class="mc-head"><b>' + m.label + '</b><span class="mc-reward">● ' + m.reward + '</span></div>' +
        '<div class="mc-progress-row">' +
          '<div class="mc-track"><i style="width:' + pct.toFixed(1) + '%"></i></div>' +
          '<span>' + prog + '</span>' +
        '</div>' +
        '<button class="btn-claim" data-claim="' + m.id + '"' + (ready ? '' : ' disabled') + '>' + btnLabel + '</button>' +
      '</div>';
    }).join('');

    wrap.querySelectorAll('[data-claim]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const reward = this.missions.claim(btn.dataset.claim);
        if (!reward) return;
        audio.mission();
        this._toast('+' + AD.formatNum(reward) + ' COINS', 'gold');
        this._renderMissions();
        this._updateCoins();
        this._refreshMenu();
      });
    });
  }

  /* ================================================================
     SETTINGS SCREEN
     ================================================================ */
  _openSettings() {
    this._syncSettingsUI();
    this._updateCoins();
    this._setState(ST.SETTINGS);
  }

  _timeLabel(v) {
    const h = Math.floor(v) % 24;
    const m = Math.round((v - Math.floor(v)) * 60);
    return AD.pad(h) + ':' + AD.pad(Math.min(59, m));
  }

  _syncSettingsUI() {
    const s = this.save.settings, E = this._el;
    if (E['vol-master']) {
      E['vol-master'].value = Math.round(s.master * 100);
      E['vol-master-v'].textContent = Math.round(s.master * 100) + '%';
      E['vol-engine'].value = Math.round(s.engine * 100);
      E['vol-engine-v'].textContent = Math.round(s.engine * 100) + '%';
      E['vol-sfx'].value = Math.round(s.sfx * 100);
      E['vol-sfx-v'].textContent = Math.round(s.sfx * 100) + '%';
    }
    if (E['time-of-day']) {
      E['time-of-day'].value = s.time;
      E['time-of-day-v'].textContent = this._timeLabel(s.time);
    }
    this._syncSegs();
  }

  _syncSegs() {
    const s = this.save.settings;
    const values = {
      steering: s.steering,
      transmission: s.transmission,
      camera: s.camera,
      mute: s.mute ? 'on' : 'off',
      quality: s.quality,
      weather: s.weather,
      headlights: s.headlights ? 'on' : 'off',
      showFps: s.showFps ? 'on' : 'off',
    };
    document.querySelectorAll('.seg[data-setting]').forEach((seg) => {
      const key = seg.dataset.setting;
      const val = values[key];
      seg.querySelectorAll('button').forEach((btn) => {
        btn.classList.toggle('active', btn.dataset.value === val);
      });
    });
  }

  _applySetting(key, value) {
    const s = this.save.settings;
    switch (key) {
      case 'steering':
        s.steering = value;
        input.setSteeringMode(value);
        break;
      case 'transmission':
        s.transmission = value;
        if (this.car) this.car.autoTransmission = value === 'auto';
        if (this._el['hud-trans']) this._el['hud-trans'].textContent = value === 'auto' ? 'AUTO' : 'MANUAL';
        break;
      case 'camera':
        s.camera = value;
        if (this.camRig) this.camRig.setMode(value);
        break;
      case 'mute':
        s.mute = value === 'on';
        audio.setVolumes({ mute: s.mute });
        this._syncSoundLabel();
        break;
      case 'quality':
        s.quality = value;
        if (this.env) this.env.setQuality(value);
        this._applyQuality(value);
        break;
      case 'weather':
        s.weather = value;
        if (this.env) this.env.setWeather(value);
        break;
      case 'headlights':
        s.headlights = value === 'on';
        break;
      case 'showFps':
        s.showFps = value === 'on';
        if (this._el['hud-fps']) this._el['hud-fps'].classList.toggle('hidden', !s.showFps);
        break;
    }
    this.save.save();
    this._syncSegs();
  }

  _applyAudioSettings() {
    const s = this.save.settings;
    audio.setVolumes({ master: s.master, engine: s.engine, sfx: s.sfx, mute: s.mute });
  }

  _applyQuality(q) {
    if (!this.renderer) return;
    const dpr = window.devicePixelRatio || 1;
    const cap = q === 'high' ? Math.min(dpr, 2) : q === 'medium' ? Math.min(dpr, 1.4) : 1;
    this.renderer.setPixelRatio(cap);
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
  }

  _applyAllSettings() {
    const s = this.save.settings;
    input.setSteeringMode(s.steering);
    this._applyAudioSettings();
    if (this.env) {
      this.env.setQuality(s.quality);
      this.env.setWeather(s.weather);
      this.env.timeOfDay = s.time;
      this.env.autoTime = false;
      this.env._updateSky(true);
    }
    this._applyQuality(s.quality);
    if (this.car) this.car.autoTransmission = s.transmission === 'auto';
    if (this.camRig) this.camRig.setMode(s.camera);
    if (this._el['hud-fps']) this._el['hud-fps'].classList.toggle('hidden', !s.showFps);
    this._syncSoundLabel();
  }
}

/* ================================================================
   LAUNCH
   ================================================================ */
const game = new Game();
window.game = game;
game.boot().catch((err) => {
  console.error('BOOT FAILED', err);
  const t = document.getElementById('load-text');
  if (t) t.textContent = 'Failed to start: ' + err.message;
});
