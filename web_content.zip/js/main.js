/* ============================================================
   AETHERVALE — Engine, player, combat, quests
   ============================================================ */
const Input = {
  keys: {}, just: {}, mouse: { x: 0, y: 0, down: false, clicked: false },
  init(canvas) {
    addEventListener('keydown', e => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
      if (!this.keys[e.code]) this.just[e.code] = true;
      this.keys[e.code] = true;
      Game.onKey(e.code);
    });
    addEventListener('keyup', e => { this.keys[e.code] = false; });
    addEventListener('blur', () => { this.keys = {}; });
    canvas.addEventListener('mousedown', e => {
      this.mouse.down = true; this.mouse.clicked = true;
      const r = canvas.getBoundingClientRect();
      this.mouse.x = (e.clientX - r.left) / r.width * G.VW;
      this.mouse.y = (e.clientY - r.top) / r.height * G.VH;
    });
    canvas.addEventListener('mouseup', () => { this.mouse.down = false; });
    canvas.addEventListener('mousemove', e => {
      const r = canvas.getBoundingClientRect();
      this.mouse.x = (e.clientX - r.left) / r.width * G.VW;
      this.mouse.y = (e.clientY - r.top) / r.height * G.VH;
    });
  },
  touchVec: { x: 0, y: 0 },
  initTouch(root) {
    const stick = { id: null, ox: 0, oy: 0 };
    const clear = () => { stick.id = null; this.touchVec.x = 0; this.touchVec.y = 0; };
    const skip = e => !!(e.target.closest && e.target.closest('#modal, #home, .touchpad, button, select, input'));
    const set = (dx, dy) => {
      const d = Math.hypot(dx, dy);
      if (d < 8) { this.touchVec.x = 0; this.touchVec.y = 0; return; }
      const k = Math.min(1, d / 42) / d;
      this.touchVec.x = dx * k; this.touchVec.y = dy * k;
    };
    root.addEventListener('touchstart', e => {
      if (skip(e)) return;
      e.preventDefault();
      if (typeof Audio2 !== 'undefined') Audio2.init();
      const busy = Game.state !== 'play' || Game.dialog;
      if (busy) {
        this.mouse.down = true; this.mouse.clicked = true;
        setTimeout(() => { this.mouse.down = false; }, 60);
        return;
      }
      const t = e.changedTouches[0];
      if (t.clientX < window.innerWidth * 0.55) { stick.id = t.identifier; stick.ox = t.clientX; stick.oy = t.clientY; }
      else { this.keys['Space'] = true; setTimeout(() => { this.keys['Space'] = false; }, 220); }
    }, { passive: false });
    root.addEventListener('touchmove', e => {
      if (stick.id === null) return;
      for (const t of e.changedTouches) if (t.identifier === stick.id) set(t.clientX - stick.ox, t.clientY - stick.oy);
      e.preventDefault();
    }, { passive: false });
    const end = e => {
      for (const t of e.changedTouches) if (t.identifier === stick.id) clear();
    };
    root.addEventListener('touchend', end);
    root.addEventListener('touchcancel', end);
  },
  down(c) { return !!this.keys[c]; },
  pressed(c) { return !!this.just[c]; },
  endFrame() { this.just = {}; this.mouse.clicked = false; },
};

/* ---------------- Game ---------------- */
const Game = {
  state: 'home',
  canvas: null, ctx: null,
  player: null,
  enemies: [], drops: [], particles: [], floaters: [], projectiles: [],
  cam: { x: 0, y: 0, w: G.VW, h: G.VH },
  time: 0, elapsed: 0, spawnT: 0, shake: 0,
  toasts: [],
  stats: { kills: 0, bought: 0, sold: 0, enhanceTry: 0, enhanceOk: 0, socketed: 0, enchanted: 0, inherited: 0, deaths: 0, bosses: 0 },
  activePanel: null,
  dialog: null,
  cutscene: null,
  paused: false,

  /* ---------- crisp screen-space label queue (drawn on HUD layer) ---------- */
  labels: [],
  label(text, x, y, color, size, opts) {
    this.labels.push({ text: text, x: x, y: y, color: color || '#ece7f5', size: size || 6, o: opts || {} });
  },
  drawLabels(h) {
    for (const L of this.labels) {
      h.font = `${L.o.bold ? 700 : 600} ${L.size}px "Press Start 2P", monospace`;
      h.textAlign = 'center';
      if (L.o.bg) {
        const w = h.measureText(L.text).width + 6;
        h.fillStyle = L.o.bg;
        h.fillRect(L.x - w / 2, L.y - L.size - 2, w, L.size + 5);
      }
      if (L.o.alpha !== undefined) h.globalAlpha = L.o.alpha;
      h.fillStyle = L.o.shadow || '#0e0b14';
      h.fillText(L.text, L.x + 1, L.y + 1);
      h.fillStyle = L.color;
      h.fillText(L.text, L.x, L.y);
      h.globalAlpha = 1;
      h.textAlign = 'left';
    }
    this.labels.length = 0;
  },

  /* ---------- lifecycle ---------- */
  settings: SETTINGS,
  fps: 0, _fpsAcc: 0, _fpsFrames: 0,

  boot() {
    this.canvas = document.getElementById('game');
    this.ctx = this.canvas.getContext('2d');
    this.hudCanvas = document.getElementById('hud');
    this.hctx = this.hudCanvas.getContext('2d');
    this.applyResolution();
    addEventListener('resize', () => this.applyResolution());
    if (screen.orientation && screen.orientation.addEventListener) {
      screen.orientation.addEventListener('change', () => setTimeout(() => this.applyResolution(), 120));
    }
    Input.init(this.canvas);
    Input.initTouch(document.querySelector('.stage'));
    UI.initTouchPad();
    World.generate();
    UI.initHome();
    UI.initBoot();
    requestAnimationFrame(this.loop.bind(this));
  },

  /* resolusi internal mengikuti ukuran jendela + mode DLSS 4 */
  applyResolution() {
    const dm = DLSS_MODES[this.settings.dlss] || DLSS_MODES.off;
    const zoom = this.settings.pixelZoom || 3;
    const w = Math.max(320, window.innerWidth), h = Math.max(240, window.innerHeight);
    let base = zoom / dm.scale;                     // piksel layar per piksel internal
    // jaga resolusi minimum tanpa merusak rasio: kecilkan skala, bukan pangkas sisi
    base = Math.min(base, w / 320, h / 200);
    base = Math.max(1, base);
    G.VW = Math.round(w / base / 2) * 2;
    G.VH = Math.round(h / base / 2) * 2;
    this.canvas.width = G.VW; this.canvas.height = G.VH;
    this.ctx.imageSmoothingEnabled = false;
    this.HS = Math.max(2, Math.min(4, Math.round(base)));
    this.hudCanvas.width = Math.round(G.VW * this.HS);
    this.hudCanvas.height = Math.round(G.VH * this.HS);
    this.hctx.imageSmoothingEnabled = false;
    this.canvas.style.imageRendering = dm.sharp > 0 ? 'auto' : 'pixelated';
    this.canvas.style.filter = dm.sharp > 0 ? `contrast(${1 + dm.sharp * 0.12}) saturate(${1 + dm.sharp * 0.06})` : 'none';
    this.cam.w = G.VW; this.cam.h = G.VH;
    if (UI.onResize) UI.onResize();
  },

  // Mode imersif: kanvas selalu mengisi seluruh jendela; bila peramban mengizinkan
  // API layar penuh (di luar pratinjau), kita pakai juga lewat pencarian kunci dinamis.
  toggleBigScreen() {
    const d = document, el = d.documentElement;
    const onKey = 'full' + 'screenElement', reqKey = 'request' + 'Full' + 'screen', exitKey = 'exit' + 'Full' + 'screen';
    try {
      if (!d[onKey] && !d['webkit' + 'Full' + 'screenElement']) {
        const fn = el[reqKey] || el['webkitRequest' + 'Full' + 'screen'];
        if (fn) { const r = fn.call(el); if (r && r.catch) r.catch(() => {}); }
      } else {
        const fn = d[exitKey] || d['webkitExit' + 'Full' + 'screen'];
        if (fn) fn.call(d);
      }
    } catch (e) { /* diabaikan: permainan sudah mengisi jendela */ }
    d.body.classList.toggle('immersive');
    this.applyResolution();
    if (UI.toast) UI.toast(d.body.classList.contains('immersive') ? 'Mode imersif aktif — tekan lagi untuk kembali' : 'Mode imersif nonaktif');
  },

  start(classId) {
    const cls = CLASSES.find(c => c.id === classId) || CLASSES[0];
    this.cls = cls;
    this.player = {
      x: World.TOWN.cx * 16 + 8, y: (World.TOWN.cy + 4) * 16,
      dir: 1, frame: 0, animT: 0, moving: false,
      level: 1, xp: 0, xpNext: 90, gold: 500,
      hp: cls.hp, base: { hp: cls.hp, atk: cls.atk, def: cls.def, crit: cls.crit, critdmg: cls.critdmg, life: 0, haste: cls.haste, spd: cls.spd },
      stats: {}, inv: [], equip: { weapon: null, armor: null, helm: null, boots: null, ring: null },
      atkCd: 0, skillCd: 0, hurtCd: 0, flash: 0, potionCd: 0, dead: false,
    };
    // starter kit
    Inv.add('w_stick'); Inv.add('a_cloth'); Inv.add('p_potion', 3); Inv.add('m_stone', 2);
    Inv.equip(this.player.inv.find(i => i.tid === 'w_stick').uid);
    Inv.equip(this.player.inv.find(i => i.tid === 'a_cloth').uid);
    this.recalc(); this.player.hp = this.player.stats.hp;
    Market.init();
    this.enemies = []; this.drops = []; this.particles = []; this.floaters = []; this.projectiles = [];
    this.elapsed = 0; this.quest.reset();
    this.bossDefeated = {}; Skills.reset(cls.id); Lairs.reset(); Villages.reset(); Fx.clear();
    Clash.active = false; Clash.wave = 0;
    this.state = 'play';
    this.cutscene = null;
    UI.hideHome();
    this.toast(STORY.opening, '#ffe9b8');
    setTimeout(() => this.toast('Tujuan: ' + (this.quest.cur() || {}).text, '#9ef7ff'), 900);
    Audio2.init();
    UI.syncHUD();
  },

  recalc() {
    const P = this.player;
    const g = 1 + (P.level - 1) * 0.11;
    const s = {
      hp: Math.round(P.base.hp * g), atk: P.base.atk * g, def: P.base.def * g,
      crit: P.base.crit, critdmg: P.base.critdmg, life: P.base.life, haste: P.base.haste, spd: P.base.spd,
    };
    for (const slot in P.equip) {
      const it = P.equip[slot]; if (!it) continue;
      const st = itemStats(it);
      for (const k in st) s[k] = (s[k] || 0) + st[k];
    }
    s.atk = Math.round(s.atk * 10) / 10; s.def = Math.round(s.def * 10) / 10;
    s.hp = Math.round(s.hp);
    P.stats = s;
    if (P.hp > s.hp) P.hp = s.hp;
    P.power = Math.round(s.atk * 3 + s.def * 2.5 + s.hp * 0.3 + s.crit * 4 + s.critdmg * 0.8 + s.life * 5 + s.haste * 3);
    UI.syncHUD();
  },

  regionUnlocked() { return true; },   // dunia terbuka penuh: tidak ada kabut penghalang

  toast(msg, color) {
    this.toasts.unshift({ msg, color: color || '#ffe9b8', t: 0 });
    if (this.toasts.length > 5) this.toasts.pop();
  },
  floater(x, y, text, color, big) { this.floaters.push({ x, y, text, color, t: 0, big }); },
  burst(x, y, n, color, spread) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = (spread || 60) * (0.3 + Math.random());
      this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 20, life: 0.3 + Math.random() * 0.5, max: 0.8, color, size: 1 + Math.floor(Math.random() * 2) });
    }
  },

  onKey(code) {
    if (this.state === 'cutscene') {
      if (code === 'Space' || code === 'Enter' || code === 'KeyE' || code === 'Escape') this.advanceCutscene();
      return;
    }
    if (this.state === 'home' || this.state === 'ended') {
      if (code === 'Escape' && this.activePanel) UI.closePanel();
      return;
    }
    if (code === 'Escape') {
      if (this.activePanel) UI.closePanel();
      else if (this.dialog) this.dialog = null;
      else UI.togglePause();
      return;
    }
    if (this.activePanel) return;
    if (this.dialog) { if (code === 'Space' || code === 'KeyE' || code === 'Enter') this.advanceDialog(); return; }
    if (code === 'KeyE') this.interact();
    if (code === 'KeyI') UI.openPanel('inventory');
    if (code === 'KeyJ') UI.openPanel('quest');
    if (code === 'KeyM') UI.openPanel('map');
    if (code === 'KeyF') this.usePotion();
  },

  /* ---------- interaction ---------- */
  nearestNpc() {
    const P = this.player; let best = null, bd = 30;
    for (const n of World.NPCS) {
      if (n.hidden) continue;
      const d = Math.hypot(n.x - P.x, n.y - P.y);
      if (d < bd) { bd = d; best = n; }
    }
    return best;
  },
  interact() {
    const n = this.nearestNpc();
    if (!n) { this.toast('Tidak ada siapa pun di dekatmu.', '#8b93a5'); return; }
    const def = NPC_LINES[n.id];
    this.quest.onTalk(n.id);
    const lines = this.quest.npcLines(n.id) || def.idle;
    this.dialog = { npc: n.id, name: def.name, role: def.role, lines: lines.slice(), idx: 0, panel: n.panel };
    Audio2.sfx('ui');
  },
  advanceDialog() {
    if (!this.dialog) return;
    this.dialog.idx++;
    if (this.dialog.idx >= this.dialog.lines.length) {
      const panel = this.dialog.panel;
      this.dialog = null;
      if (panel) UI.openPanel(panel);
    }
  },
  advanceCutscene() {
    const c = this.cutscene; if (!c) return;
    c.idx++;
    if (c.idx >= c.lines.length) { this.cutscene = null; c.after(); }
  },

  usePotion() {
    const P = this.player;
    if (P.potionCd > 0) return;
    let tid = null;
    if (P.hp < P.stats.hp * 0.45 && Inv.count('p_potion_hi') > 0) tid = 'p_potion_hi';
    else if (Inv.count('p_potion') > 0) tid = 'p_potion';
    else if (Inv.count('p_potion_hi') > 0) tid = 'p_potion_hi';
    if (!tid) { this.toast('Tidak ada ramuan.', '#ff7a7a'); return; }
    Inv.remove(tid, 1);
    const heal = ITEMS[tid].heal;
    P.hp = Math.min(P.stats.hp, P.hp + heal);
    P.potionCd = 1.2;
    this.floater(P.x, P.y - 22, '+' + heal, '#6fe08a');
    this.burst(P.x, P.y - 8, 8, '#6fe08a', 40);
    Audio2.sfx('ok'); UI.syncHUD();
  },

  /* ---------- combat ---------- */
  attack() {
    const P = this.player;
    if (!P || P.dead || this.paused || this.state !== 'play') return;
    if (P.atkCd > 0) return;
    const hasteMul = 1 / (1 + (P.stats.haste || 0) / 100);
    const cls = this.cls.id;
    P.atkCd = (cls === 'ranger' ? 0.38 : cls === 'arcanist' ? 0.5 : 0.55) * hasteMul;
    P.atkCd /= Skills.hasteMul();
    P.swing = 0.18;
    Audio2.swing(WeaponFx.snd());
    const dirv = [[0, 1], [0, -1], [-1, 0], [1, 0]][P.dir];
    if (cls === 'arcanist') {
      this.projectiles.push({ x: P.x + dirv[0] * 8, y: P.y - 6 + dirv[1] * 8, vx: dirv[0] * 190, vy: dirv[1] * 190, life: 0.85, dmgMul: 1.15, friendly: true, pierce: 3, hitIds: [], color: '#c07bff', r: 6 });
    } else {
      this.meleeHit(dirv, cls === 'ranger' ? 22 : 27, cls === 'ranger' ? 0.72 : 1.18);
      if (cls === 'ranger') setTimeout(() => { if (this.state === 'play') this.meleeHit(dirv, 22, 0.72); }, 130);
    }
  },
  meleeHit(dirv, range, mul) {
    const P = this.player;
    const hx = P.x + dirv[0] * range * 0.6, hy = P.y - 6 + dirv[1] * range * 0.6;
    let hitAny = false;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = Math.hypot(e.x - hx, e.y - (e.y0 || e.y) + (e.y - e.y) - hy + 0);
      const dd = Math.hypot(e.x - hx, e.y - 8 - hy);
      if (Math.min(d, dd) < range * 0.85 + e.def_r) { this.damageEnemy(e, mul); hitAny = true; }
    }
    this.particles.push({ x: hx, y: hy, vx: 0, vy: 0, life: 0.14, max: 0.14, color: '#ffffff', size: 3, slash: true });
    if (!hitAny) this.burst(hx, hy, 3, 'rgba(255,255,255,0.7)', 30);
  },
  skill(slot) { Skills.use(slot || 0); },
  damageEnemy(e, mul) {
    const P = this.player;
    const crit = Math.random() * 100 < (P.stats.crit || 0);
    let dmg = P.stats.atk * mul * (0.9 + Math.random() * 0.2) - e.def * 0.45;
    dmg = Math.max(1, dmg);
    if (crit) dmg *= (P.stats.critdmg || 150) / 100;
    dmg = Math.round(dmg);
    e.hp -= dmg;
    e.flash = 0.12; e.aggro = true; e.knock = { x: (e.x - P.x), y: (e.y - P.y) };
    this.floater(e.x + (Math.random() * 8 - 4), e.y - 22, (crit ? '' : '') + dmg, crit ? '#ffd24d' : '#ffffff', crit);
    this.burst(e.x, e.y - 8, crit ? 8 : 4, crit ? '#ffd24d' : '#ff9a9a', 50);
    Audio2.impact(WeaponFx.snd(), crit, e.def_boss ? 1.25 : 1);
    WeaponFx.onHit(e, dmg, crit);
    if (P.stats.life > 0) {
      const h = Math.max(1, Math.round(dmg * P.stats.life / 100));
      P.hp = Math.min(P.stats.hp, P.hp + h);
    }
    if (e.hp <= 0) this.killEnemy(e);
    UI.syncHUD();
  },
  killEnemy(e) {
    e.dead = true; e.deadT = 0;
    this.stats.kills++;
    if (e.def_boss) { this.stats.bosses++; this.shake = 8; }
    const def = ENEMIES[e.type];
    const gold = Math.floor(def.gold[0] + Math.random() * (def.gold[1] - def.gold[0]));
    this.drops.push({ x: e.x, y: e.y, kind: 'gold', amount: gold, t: 0, vy: -40 });
    for (const [tid, chance, a, b] of def.drops) {
      if (Math.random() < chance) {
        const q = a + Math.floor(Math.random() * (b - a + 1));
        this.drops.push({ x: e.x + (Math.random() * 16 - 8), y: e.y + (Math.random() * 10 - 5), kind: 'item', tid, qty: q, t: 0, vy: -50 });
      }
    }
    this.gainXp(def.xp);
    this.burst(e.x, e.y - 8, e.def_boss ? 40 : 12, def.color, e.def_boss ? 140 : 70);
    this.quest.onKill(e.type);
    WeaponFx.onKill(e);
    if (e.def_boss && !e.clash) Lairs.onBossKill(e);
  },
  gainXp(n) {
    const P = this.player;
    P.xp += n;
    while (P.xp >= P.xpNext) {
      P.xp -= P.xpNext; P.level++;
      P.xpNext = Math.round(90 * Math.pow(P.level, 1.42));
      this.recalc(); P.hp = P.stats.hp;
      this.floater(P.x, P.y - 30, 'NAIK LEVEL ' + P.level, '#ffd24d', true);
      this.burst(P.x, P.y - 8, 26, '#ffd24d', 90);
      Audio2.sfx('level');
      this.toast(`Naik ke Level ${P.level}! Status meningkat.`, '#ffd24d');
    }
    UI.syncHUD();
  },
  hurtPlayer(dmg, src) {
    const P = this.player;
    if (P.hurtCd > 0 || P.dead) return;
    const real = Math.max(1, Math.round((dmg - P.stats.def * 0.5) * Skills.dmgTakenMul()));
    P.hp -= real; P.hurtCd = 0.45; P.flash = 0.2;
    this.shake = Math.min(6, 2 + real / 12);
    this.floater(P.x, P.y - 26, '-' + real, '#ff6b6b');
    Audio2.sfx('hurt');
    if (src) { P.knock = { x: P.x - src.x, y: P.y - src.y }; }
    if (P.hp <= 0) this.playerDie();
    UI.syncHUD();
  },
  playerDie() {
    const P = this.player;
    P.hp = 0; P.dead = true; this.stats.deaths++;
    if (Clash.active) Clash.exit(false);          // jangan terkurung di koordinat arena
    const lost = Math.floor(P.gold * 0.1);
    P.gold -= lost;
    Audio2.sfx('death');
    this.burst(P.x, P.y - 8, 30, '#ff6b6b', 90);
    this.state = 'cutscene';
    this.cutscene = {
      title: 'Kau Tumbang', lines: [
        'Kabut menelanmu... tapi Serambi belum melepaskanmu.',
        `Kau terbangun di kota. ${fmt(lost)} gold hilang dalam perjalanan.`,
      ], idx: 0, after: () => {
        P.dead = false; P.hp = Math.round(P.stats.hp * 0.6);
        P.x = World.TOWN.cx * 16 + 8; P.y = (World.TOWN.cy + 4) * 16;
        P.hurtCd = 1.5; P.potionCd = 0; P.atkCd = 0; P.knock = null; P.dash = null; P.flash = 0;
        // buang musuh yang jauh & padamkan amarah sisanya (dulu SEMUA musuh terhapus)
        this.enemies = this.enemies.filter(e => !e.dead && (e.def_boss || Math.hypot(e.x - P.x, e.y - P.y) < 520));
        for (const e of this.enemies) { e.aggro = false; e.calmT = 1.2; e.atkCd = 1.2; }
        this.projectiles.length = 0;
        Status.clear && Status.clear(P);
        Skills.timeslow = 0; Skills.buffs.shield = 0; Skills.buffs.haste = 0;
        Skills.cd = [0, 0, 0];
        if (Lairs.active && !this.enemies.includes(Lairs.active)) Lairs.active = null;
        this.cam.x = P.x - G.VW / 2; this.cam.y = P.y - G.VH / 2;
        this.state = 'play'; UI.syncHUD();
        Save.write && Save.write(true);
      },
    };
  },

  /* ---------- spawns ---------- */
  spawnEnemy(type, tx, ty) {
    const def = ENEMIES[type];
    const sc = def.boss ? 1 : 1 + Math.min(1.6, Math.hypot(tx, ty) / 420);
    const e = {
      type, x: tx * 16 + 8, y: ty * 16 + 8, hp: Math.round(def.hp * sc), maxhp: Math.round(def.hp * sc),
      def: def.def * sc, atk: def.atk * sc, scale: sc,
      spd: def.spd, frame: 0, animT: 0, dir: 0, aggro: false, calmT: 0, atkCd: 0, flash: 0, dead: false, deadT: 0,
      def_r: def.r, def_boss: !!def.boss, wander: { a: Math.random() * 6.28, t: 0 }, castT: 2,
    };
    if (def.boss) { e.hp = def.hp; e.maxhp = def.hp; }
    this.enemies.push(e);
    return e;
  },
  maintainSpawns(dt) {
    this.spawnT -= dt;
    if (this.spawnT > 0) return;
    this.spawnT = 0.8;
    const P = this.player;
    if (World.inTown(Math.floor(P.x / 16), Math.floor(P.y / 16), 8)) return;
    const alive = this.enemies.filter(e => !e.dead).length;
    if (alive >= 16) return;
    for (let tries = 0; tries < 24; tries++) {
      const a = Math.random() * Math.PI * 2, d = 170 + Math.random() * 180;
      const px = P.x + Math.cos(a) * d, py = P.y + Math.sin(a) * d;
      const tx = Math.floor(px / 16), ty = Math.floor(py / 16);
      if (World.inTown(tx, ty, 6)) continue;
      if (!World.walkable(px, py, 6)) continue;
      const b = World.biomeAt(tx, ty);
      const pool = (b.enemies || ['slime']).filter(k => ENEMIES[k]);
      if (!pool.length) continue;
      this.spawnEnemy(pool[Math.floor(Math.random() * pool.length)], tx, ty);
      break;
    }
  },
  ensureBoss(type) {
    if (this.enemies.some(e => e.type === type && !e.dead)) return;
    const [ax, ay] = World.ARENAS[type];
    const P = this.player;
    if (Math.hypot(P.x - ax * 16, P.y - ay * 16) > 340) return;
    const e = this.spawnEnemy(type, ax, ay);
    e.boss = true;
    this.toast(`${ENEMIES[type].name} muncul!`, '#ff7a45');
    Audio2.sfx('boss');
    this.shake = 6;
  },

  /* ---------- update ---------- */
  update(dt) {
    this.time += dt;
    // waktu kisah tidak lagi berjalan saat permainan dijeda
    if (this.state === 'play' && !this.paused) this.elapsed += dt;
    if (this.state === 'cutscene') {
      if (Input.mouse.clicked) this.advanceCutscene();
      return;
    }
    if (this.state !== 'play' || this.paused) return;
    const P = this.player;

    if (!(this.activePanel === 'auction' || this.activePanel === 'shop')) Market.tick(dt);

    // input → movement
    let mx = 0, my = 0;
    if (Input.down('KeyA') || Input.down('ArrowLeft')) mx -= 1;
    if (Input.down('KeyD') || Input.down('ArrowRight')) mx += 1;
    if (Input.down('KeyW') || Input.down('ArrowUp')) my -= 1;
    if (Input.down('KeyS') || Input.down('ArrowDown')) my += 1;
    if (Input.touchVec.x || Input.touchVec.y) { mx += Input.touchVec.x; my += Input.touchVec.y; }
    if (!this.dialog && !this.activePanel) {
      if (Input.down('Space') || Input.mouse.down) this.attack();
      if (Input.pressed('KeyQ') || Input.pressed('ShiftLeft')) this.skill(0);
      if (Input.pressed('KeyR')) this.skill(1);
      if (Input.pressed('KeyC')) this.skill(2);
    } else { mx = 0; my = 0; }

    const len = Math.hypot(mx, my) || 1;
    const spd = (P.stats.spd || 80) * (this.dialog ? 0 : 1) * Skills.spdMul();
    let vx = mx / len * spd, vy = my / len * spd;
    if (P.dash && P.dash.t > 0) { vx = P.dash.vx; vy = P.dash.vy; P.dash.t -= dt; }
    if (P.knock) { vx += P.knock.x * 2.2; vy += P.knock.y * 2.2; P.knock = null; }

    if (mx || my) {
      P.moving = true;
      if (Math.abs(mx) > Math.abs(my)) P.dir = mx < 0 ? 2 : 3; else P.dir = my < 0 ? 1 : 0;
    } else P.moving = false;

    const nx = P.x + vx * dt, ny = P.y + vy * dt;
    if (World.walkable(nx, P.y, 5)) P.x = nx;
    if (World.walkable(P.x, ny, 5)) P.y = ny;
    // dunia tak terbatas: petak baru dibentuk otomatis saat melewati batas lama
    const bnow = World.biomeAtPx(P.x, P.y);
    if (bnow !== this._lastBiome) {
      if (this._lastBiome) this.toast('Memasuki ' + bnow.name + ' — ' + REALM_LABEL[bnow.realm], bnow.accent);
      this._lastBiome = bnow;
    }

    P.animT += dt * (P.moving ? 8 : 3);
    P.frame = Math.floor(P.animT) % 4;
    P.atkCd = Math.max(0, P.atkCd - dt);
    P.skillCd = Math.max(0, P.skillCd - dt);
    P.hurtCd = Math.max(0, P.hurtCd - dt);
    P.potionCd = Math.max(0, P.potionCd - dt);
    if (P.swing) P.swing = Math.max(0, P.swing - dt);
    if (P.flash) P.flash = Math.max(0, P.flash - dt);

    // camera
    const tcx = P.x - G.VW / 2, tcy = P.y - G.VH / 2;
    this.cam.x += (tcx - this.cam.x) * Math.min(1, dt * 7);
    this.cam.y += (tcy - this.cam.y) * Math.min(1, dt * 7);
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 22);

    // quest needs
    this.quest.update(dt);

    // enemies
    let inCombat = false;
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.dead) { e.deadT += dt; if (e.deadT > 0.5) this.enemies.splice(i, 1); continue; }
      const dx = P.x - e.x, dy = P.y - e.y, dist = Math.hypot(dx, dy);
      if (dist > 700 && !e.def_boss) { this.enemies.splice(i, 1); continue; }
      if (e.flash) e.flash = Math.max(0, e.flash - dt);
      if (e.stun > 0) { e.stun -= dt; if (e.flash) e.flash = Math.max(0, e.flash - dt); continue; }
      // MUSUH PASIF: hanya mengejar/menyerang setelah kita serang lebih dulu
      if (e.aggro && dist > 620) { e.aggro = false; e.calmT = 1; }
      if (e.aggro) inCombat = true;
      let ex = 0, ey = 0;
      if (e.aggro) {
        const espd = e.spd * Status.spdMul(e);
        if (dist > e.def_r + 9) { ex = dx / dist * espd; ey = dy / dist * espd; }
        e.atkCd -= dt;
        if (dist < e.def_r + 14 && e.atkCd <= 0) {
          e.atkCd = e.def_boss ? 1.1 : 1.5;
          this.hurtPlayer(e.atk * (0.9 + Math.random() * 0.2), e);
        }
        if (e.def_boss) {
          e.castT -= dt;
          if (e.castT <= 0) {
            e.castT = 3.4;
            if (ENEMIES[e.type].pattern) BossAI.cast(e);
            else {
              const n = e.type === 'vaelor' ? 14 : 10;
              for (let k = 0; k < n; k++) {
                const a = k / n * Math.PI * 2 + Math.random() * 0.2;
                this.projectiles.push({ x: e.x, y: e.y - 10, vx: Math.cos(a) * 105, vy: Math.sin(a) * 105, life: 2.4, friendly: false, dmg: e.atk * 0.7, color: ENEMIES[e.type].color, r: 5 });
              }
              this.shake = 4;
              Audio2.sfx('boss');
            }
          }
        }
      } else {
        e.wander.t -= dt;
        if (e.wander.t <= 0) { e.wander.t = 1 + Math.random() * 2.2; e.wander.a = Math.random() * 6.28; e.idle = Math.random() < 0.4; }
        if (!e.idle) { const ws = e.spd * Status.spdMul(e) * 0.4; ex = Math.cos(e.wander.a) * ws; ey = Math.sin(e.wander.a) * ws; }
      }
      if (e.knock) { ex += e.knock.x * 1.6; ey += e.knock.y * 1.6; e.knock = null; }
      const enx = e.x + ex * dt, eny = e.y + ey * dt;
      if (World.walkable(enx, e.y, 5, true)) e.x = enx;
      if (World.walkable(e.x, eny, 5, true)) e.y = eny;
      e.animT += dt * (ex || ey ? 7 : 2.5); e.frame = Math.floor(e.animT) % 4;
      if (Math.abs(ex) > Math.abs(ey)) e.dir = ex < 0 ? 2 : 3; else e.dir = ey < 0 ? 1 : 0;
    }
    if (this.quest.bossNeeded) this.ensureBoss(this.quest.bossNeeded);
    if (!Clash.active) this.maintainSpawns(dt);
    Skills.update(dt); Status.update(dt); Fx.update(dt);
    Lairs.update(dt); Villages.update(dt); Clash.update(dt);

    // projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
      if (p.life <= 0 || World.solidAtPx(p.x, p.y)) { this.burst(p.x, p.y, 4, p.color, 40); this.projectiles.splice(i, 1); continue; }
      if (p.friendly) {
        for (const e of this.enemies) {
          if (e.dead || p.hitIds.includes(e)) continue;
          if (Math.hypot(e.x - p.x, e.y - 8 - p.y) < e.def_r + p.r) {
            p.hitIds.push(e); this.damageEnemy(e, p.dmgMul);
            if (--p.pierce <= 0) { this.projectiles.splice(i, 1); break; }
          }
        }
      } else if (Math.hypot(P.x - p.x, P.y - 8 - p.y) < 8 + p.r) {
        this.hurtPlayer(p.dmg); this.projectiles.splice(i, 1);
      }
      if (this.particles.length < 420 && Math.random() < 0.6) this.particles.push({ x: p.x, y: p.y, vx: 0, vy: 0, life: 0.2, max: 0.2, color: p.color, size: 2 });
    }

    // drops pickup
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.t += dt; d.vy = (d.vy || 0) + 200 * dt;
      d.y = Math.min(d.y + d.vy * dt, d.y0 !== undefined ? d.y0 : (d.y0 = d.y));
      if (d.t > 0.25) {
        const dist = Math.hypot(P.x - d.x, P.y - d.y);
        if (dist < 26) { d.x += (P.x - d.x) * dt * 7; d.y += (P.y - d.y) * dt * 7; }
        if (dist < 11) {
          if (d.kind === 'gold') { P.gold += d.amount; this.floater(P.x, P.y - 30, '+' + fmt(d.amount) + ' G', '#ffd24d'); }
          else { Inv.add(d.tid, d.qty); this.floater(P.x, P.y - 30, ITEMS[d.tid].name + (d.qty > 1 ? ' x' + d.qty : ''), RARITY[ITEMS[d.tid].rarity || 'common'].color); this.quest.onCollect(); }
          Audio2.sfx('coin'); this.drops.splice(i, 1); UI.syncHUD(); continue;
        }
      }
      if (d.t > 60) this.drops.splice(i, 1);
    }

    // particles & floaters
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += (p.vx || 0) * dt; p.y += (p.vy || 0) * dt;
      if (p.vy !== undefined) p.vy += 120 * dt;
      p.life -= dt; if (p.life <= 0) this.particles.splice(i, 1);
    }
    for (let i = this.floaters.length - 1; i >= 0; i--) {
      const f = this.floaters[i]; f.t += dt; f.y -= dt * 20;
      if (f.t > 1.1) this.floaters.splice(i, 1);
    }
    for (const t of this.toasts) t.t += dt;
    this.toasts = this.toasts.filter(t => t.t < 4.5);

    // NPC idle animation
    for (const n of World.NPCS) { n.t += dt; n.frame = Math.floor(n.t * 2) % 4; }

    Audio2.setIntensity(Clash.active || this.enemies.some(e => !e.dead && e.def_boss && e.aggro) ? 2 : inCombat ? 1 : 0);
    Audio2.updateMusic(World.biomeAtPx(P.x, P.y).music || 'meadow', inCombat);
    if (this.time % 0.5 < dt) UI.syncHUD();
  },

  /* ---------- render ---------- */
  render() {
    const ctx = this.ctx;
    if (this.hctx) {
      this.hctx.setTransform(1, 0, 0, 1, 0, 0);
      this.hctx.clearRect(0, 0, this.hudCanvas.width, this.hudCanvas.height);
    }
    if (this.state === 'home') { UI.renderHomeCanvas(ctx, this.time); return; }
    const cam = { x: Math.round(this.cam.x + (this.shake ? (Math.random() - 0.5) * this.shake : 0)), y: Math.round(this.cam.y + (this.shake ? (Math.random() - 0.5) * this.shake : 0)), w: G.VW, h: G.VH };
    ctx.fillStyle = '#10131a'; ctx.fillRect(0, 0, G.VW, G.VH);
    if (Clash.active) Clash.draw(ctx, cam); else World.drawGround(ctx, cam);
    Lairs.draw(ctx, cam);
    Fx.drawGround(ctx, cam);

    // drops (under entities)
    for (const d of this.drops) {
      const sx = Math.round(d.x - cam.x), sy = Math.round(d.y - cam.y);
      if (sx < -16 || sy < -16 || sx > G.VW + 16 || sy > G.VH + 16) continue;
      const bob = Math.sin(this.time * 4 + d.x) * 1.5;
      ctx.globalAlpha = 0.35; ctx.fillStyle = '#000'; ctx.fillRect(sx - 4, sy + 2, 8, 2); ctx.globalAlpha = 1;
      if (d.kind === 'gold') {
        ctx.fillStyle = '#f5c542'; ctx.fillRect(sx - 3, sy - 4 + bob, 6, 6);
        ctx.fillStyle = '#fff1b8'; ctx.fillRect(sx - 2, sy - 3 + bob, 2, 2);
      } else {
        const ic = Art.itemIcon(ITEMS[d.tid], 12);
        ctx.drawImage(ic, sx - 6, sy - 10 + bob);
        ctx.strokeStyle = RARITY[ITEMS[d.tid].rarity || 'common'].color;
        ctx.globalAlpha = 0.6; ctx.strokeRect(sx - 7.5, sy - 11.5 + bob, 15, 15); ctx.globalAlpha = 1;
      }
    }

    // build sortable list
    const list = [];
    for (const o of World.visibleObjects(cam)) list.push({ y: o.y, draw: () => {
      const img = o.kind === 'tree' ? Art.tree(o.biome, o.variant) : Art.rock(o.biome, o.variant);
      ctx.drawImage(img, Math.round(o.x - img.width / 2 - cam.x), Math.round(o.y - img.height + 6 - cam.y));
    } });
    for (const b of World.BUILDINGS) {
      const img = Art.building(b.kind);
      const bx = b.tx * 16 + (b.w * 16) / 2, by = (b.ty + b.h) * 16;
      if (Math.abs(bx - cam.x - G.VW / 2) > 340 || Math.abs(by - cam.y - G.VH / 2) > 300) continue;
      list.push({ y: by - 4, draw: () => {
        ctx.drawImage(img, Math.round(bx - img.width / 2 - cam.x), Math.round(by - img.height - cam.y));
        const lbl = { hall: 'BALAI KOTA', auction: 'BALAI LELANG', smith: 'PANDAI BESI', gem: 'TUKANG PERMATA', enchant: 'PERAPAL', inherit: 'BALAI WARISAN', shop: 'TOKO' }[b.kind];
        this.label(lbl, Math.round(bx - cam.x), Math.round(by - img.height - cam.y) + 34,
          '#ffe9b8', 6, { bold: true, bg: 'rgba(15,12,22,0.78)' });
      } });
    }
    if (!Clash.active) Villages.collect(list, ctx, cam);
    for (const n of World.NPCS) {
      if (n.hidden) continue;
      if (Math.abs(n.x - cam.x - G.VW / 2) > 300 || Math.abs(n.y - cam.y - G.VH / 2) > 220) continue;
      const def = NPC_LINES[n.id];
      list.push({ y: n.y, draw: () => {
        const img = Art.humanoid({ key: 'npc' + n.id, skin: '#e8b98a', hair: '#3a2c28', tunic: def.tint, pants: '#3b3550' }, 0, n.frame);
        ctx.drawImage(img, Math.round(n.x - 8 - cam.x), Math.round(n.y - 18 - cam.y));
        // name + marker
        this.label(def.name, Math.round(n.x - cam.x), Math.round(n.y - 22 - cam.y), def.tint, 6, {});
        if (this.quest.npcHasQuest(n.id)) {
          const by = Math.sin(this.time * 4) * 2;
          ctx.fillStyle = '#ffd24d';
          ctx.fillRect(Math.round(n.x - 1 - cam.x), Math.round(n.y - 34 - cam.y + by), 3, 7);
          ctx.fillRect(Math.round(n.x - 1 - cam.x), Math.round(n.y - 25 - cam.y + by), 3, 3);
        }
      } });
    }
    for (const e of this.enemies) {
      if (Math.abs(e.x - cam.x - G.VW / 2) > 300 || Math.abs(e.y - cam.y - G.VH / 2) > 220) continue;
      list.push({ y: e.y, draw: () => this.drawEnemy(ctx, e, cam) });
    }
    const P = this.player;
    list.push({ y: P.y, draw: () => this.drawPlayer(ctx, cam) });
    list.sort((a, b) => a.y - b.y);
    for (const it of list) it.draw();

    // projectiles
    for (const p of this.projectiles) {
      const sx = Math.round(p.x - cam.x), sy = Math.round(p.y - cam.y);
      ctx.fillStyle = p.color; ctx.fillRect(sx - p.r / 2, sy - p.r / 2, p.r, p.r);
      ctx.fillStyle = '#fff'; ctx.fillRect(sx - 1, sy - 1, 2, 2);
    }
    // particles
    for (const p of this.particles) {
      const a = Math.max(0, p.life / p.max);
      ctx.globalAlpha = a;
      ctx.fillStyle = p.color;
      if (p.slash) { ctx.fillRect(Math.round(p.x - cam.x) - 8, Math.round(p.y - cam.y) - 1, 16, 3); }
      else ctx.fillRect(Math.round(p.x - cam.x), Math.round(p.y - cam.y), p.size, p.size);
      ctx.globalAlpha = 1;
    }
    // floaters
    for (const f of this.floaters) {
      this.label(f.text, Math.round(f.x - cam.x), Math.round(f.y - cam.y), f.color,
        f.big ? 9 : 7, { bold: !!f.big, alpha: Math.max(0, 1 - f.t / 1.1) });
    }

    Fx.drawOver(ctx, cam);
    if (!Clash.active) World.drawAmbient(ctx, cam, this.time);
    this.drawNight(ctx);
    Shader.apply(ctx, G.VW, G.VH);
    const h = this.hctx;
    h.setTransform(1, 0, 0, 1, 0, 0);
    h.clearRect(0, 0, this.hudCanvas.width, this.hudCanvas.height);
    h.setTransform(this.HS, 0, 0, this.HS, 0, 0);
    h.imageSmoothingEnabled = false;
    this.drawLabels(h);
    HUD.draw(h, cam);
    if (this.dialog) HUD.drawDialog(h);
    if (this.cutscene) HUD.drawCutscene(h, this.cutscene);
  },

  drawNight(ctx) {
    // subtle vignette + region tint
    const b = World.biomeAtPx(this.player.x, this.player.y);
    const tint = { forest: 'rgba(20,60,40,0.14)', swamp: 'rgba(40,60,30,0.20)', ash: 'rgba(90,40,20,0.16)', snow: 'rgba(150,190,230,0.12)', rift: 'rgba(70,40,140,0.22)' }[b.music];
    if (tint) { ctx.fillStyle = tint; ctx.fillRect(0, 0, G.VW, G.VH); }
    const g = ctx.createRadialGradient(G.VW / 2, G.VH / 2, G.VH * 0.35, G.VW / 2, G.VH / 2, G.VH * 0.95);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(6,4,12,0.55)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, G.VW, G.VH);
  },

  drawPlayer(ctx, cam) {
    const P = this.player;
    const img = Art.humanoid({
      key: 'pc' + this.cls.id, skin: '#e8b98a', hair: '#2f2420', tunic: this.cls.tint,
      pants: '#38304a', belt: '#6b4f38', weapon: true, weaponColor: '#dfe6f2', crest: this.cls.id === 'arcanist' ? '#ffd24d' : null,
    }, P.dir, P.moving ? P.frame : 0);
    const sx = Math.round(P.x - 8 - cam.x), sy = Math.round(P.y - 18 - cam.y);
    if (P.flash > 0 && Math.floor(P.flash * 30) % 2 === 0) ctx.globalAlpha = 0.5;
    ctx.drawImage(img, sx, sy);
    ctx.globalAlpha = 1;
    if (P.swing > 0) {
      const dirv = [[0, 1], [0, -1], [-1, 0], [1, 0]][P.dir];
      ctx.globalAlpha = P.swing / 0.18 * 0.85;
      ctx.fillStyle = this.cls.id === 'arcanist' ? '#d9b3ff' : '#fdfdff';
      const cx = Math.round(P.x + dirv[0] * 15 - cam.x), cy = Math.round(P.y - 6 + dirv[1] * 15 - cam.y);
      if (dirv[0]) ctx.fillRect(cx - 2, cy - 9, 4, 18); else ctx.fillRect(cx - 9, cy - 2, 18, 4);
      ctx.globalAlpha = 1;
    }
  },

  drawEnemy(ctx, e, cam) {
    const def = ENEMIES[e.type];
    const big = e.type === 'magmaris' ? 36 : e.type === 'vaelor' ? 44 : def.boss ? 26 : 20;
    const img = Art.enemy(def.art, def.color, e.frame, big);
    const sx = Math.round(e.x - img.width / 2 - cam.x), sy = Math.round(e.y - img.height + 4 - cam.y);
    if (e.dead) { ctx.globalAlpha = Math.max(0, 1 - e.deadT / 0.5); }
    ctx.drawImage(img, sx, sy);
    if (e.flash > 0) {
      ctx.globalAlpha = 0.6; ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = '#fff'; ctx.fillRect(sx, sy, img.width, img.height);
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.globalAlpha = 1;
    if (e.dead) return;
    Status.draw(ctx, e, cam);
    // health bar
    const w = def.boss ? 40 : 20;
    const hpr = Math.max(0, e.hp / e.maxhp);
    const bx = Math.round(e.x - w / 2 - cam.x), by = sy - 6;
    ctx.fillStyle = 'rgba(10,8,16,0.8)'; ctx.fillRect(bx - 1, by - 1, w + 2, 4);
    ctx.fillStyle = def.boss ? '#ff6b3d' : '#e0524f'; ctx.fillRect(bx, by, Math.round(w * hpr), 2);
    if (def.boss) {
      Game.label(def.name, Math.round(e.x - cam.x), by - 5, '#ffd7a8', 6, {});
    }
  },

  /* ---------- main loop ---------- */
  loop(ts) {
    requestAnimationFrame(this.loop.bind(this));
    if (!this._last) this._last = ts;
    const cap = this.settings.fpsCap;
    if (cap && ts - this._last < 1000 / cap - 1.2) return;
    let dt = (ts - this._last) / 1000; this._last = ts;
    dt = Math.min(dt, 0.05);
    this._fpsAcc += dt; this._fpsFrames++;
    if (this._fpsAcc >= 0.25) {
      this.fps = Math.round(this._fpsFrames / this._fpsAcc);
      this._fpsAcc = 0; this._fpsFrames = 0;
      if (UI.updateFpsBadge) UI.updateFpsBadge();
    }
    this.update(dt);
    this.render();
    const playing = this.state === 'play' && !this.activePanel;
    if (playing !== this._bodyPlaying) { this._bodyPlaying = playing; document.body.classList.toggle('playing', playing); }
    Input.endFrame();
  },
};

/* ================= Mesin kisah (satu alur, tanpa bab) ================= */
Game.quest = {
  step: 0, counter: 0, finished: false, bossNeeded: null, log: [],
  reset() { this.step = 0; this.counter = 0; this.finished = false; this.bossNeeded = null; this.log = []; this.refresh(); },
  all() { return STORY.steps; },
  cur() { return this.finished ? null : STORY.steps[this.step]; },
  total() { return STORY.steps.length; },
  refresh() {
    const s = this.cur();
    this.bossNeeded = null;
    if (s && s.type === 'kill' && s.target.some(t => ENEMIES[t] && ENEMIES[t].boss)) {
      this.bossNeeded = s.target.find(t => ENEMIES[t].boss);
    }
    UI.syncQuest();
  },
  progressText() {
    const s = this.cur(); if (!s) return '';
    if (s.type === 'kill') return `${Math.min(this.counter, s.count)}/${s.count}`;
    if (s.type === 'collect') return `${Math.min(Inv.count(s.item), s.count)}/${s.count}`;
    if (['buy', 'socket', 'enchant', 'inherit'].includes(s.type)) return `${Math.min(this.counter, s.count)}/${s.count}`;
    if (s.type === 'plus') {
      const best = Object.values(Game.player.equip).concat(Game.player.inv.filter(isGear)).filter(Boolean)
        .reduce((a, i) => Math.max(a, i.plus || 0), 0);
      return `+${best}/+${s.min}`;
    }
    if (s.type === 'explore' || s.type === 'realm') {
      const t = this.objectiveTarget();
      if (t) return Math.round(Math.hypot(t[0] - Game.player.x, t[1] - Game.player.y) / 16) + 'm';
    }
    return '';
  },
  npcHasQuest(id) {
    const s = this.cur();
    return !!(s && ((s.type === 'talk' && s.npc === id) || (s.type === 'socket' && id === 'wen') ||
      (s.type === 'enchant' && id === 'ilya') || (s.type === 'inherit' && id === 'nadia') ||
      (s.type === 'plus' && id === 'borin') || (s.type === 'buy' && id === 'mira')));
  },
  npcLines(id) {
    const s = this.cur();
    if (!s || s.type !== 'talk' || s.npc !== id) return null;
    if (id === 'rangga') {
      return this.step === 0
        ? ['"Akhirnya kau datang. Lonceng Serambi pecah — dan kabut Aether menebal."',
           '"Bersihkan enam makhluk di sekitar kota agar petani berani keluar. Ingat: mereka tidak akan menyerang lebih dulu."',
           '"Dunia di luar pagar tak berujung. Berjalanlah, tanahnya akan terus terbentuk di depanmu."']
        : ['"Kau selamat. Bagus." Rangga menatap serpih perunggu di tangannya.',
           '"Retakan ini bukan besi yang lelah. Ini Aether yang bocor dari suatu tempat jauh di luar peta."',
           '"Temui Mira di Balai Lelang. Kau butuh besi yang lebih baik."'];
    }
    if (id === 'mira') {
      return ['"Selamat datang di Balai Lelang. Semua yang dijatuhkan monster berakhir di sini."',
              '"Perhatikan grafik harga: hijau berarti pasar sedang panas, merah berarti murah."',
              '"Beli satu barang dulu — apa saja. Rasakan iramanya."'];
    }
    return [`"Soal ${s.text.toLowerCase()} — teruskan, aku menunggu kabar baik."`];
  },
  advance() {
    const s = this.cur(); if (!s) return;
    this.counter = 0;
    Audio2.sfx('quest');
    if (s.reward) {
      Game.player.gold += s.reward.gold || 0;
      (s.reward.items || []).forEach(([tid, q]) => Inv.add(tid, q));
      Game.toast(`Tujuan selesai! +${fmt(s.reward.gold || 0)} G`, '#ffd24d');
    }
    this.log.push(s.text);
    this.step++;
    UI.syncHUD();
    if (this.step >= STORY.steps.length) {
      this.finished = true;
      this.refresh();
      UI.showEnding();
      return;
    }
    const nxt = this.cur();
    if (nxt.story) Game.toast(nxt.story, '#cbbcf0');
    setTimeout(() => Game.toast('Tujuan: ' + nxt.text, '#9ef7ff'), 700);
    this.refresh();
  },
  check() {
    const s = this.cur(); if (!s) return;
    if (s.type === 'kill' && this.counter >= s.count) this.advance();
    else if (s.type === 'collect' && Inv.count(s.item) >= s.count) { Inv.remove(s.item, s.count); this.advance(); }
    else if (['buy', 'socket', 'enchant', 'inherit'].includes(s.type) && this.counter >= s.count) this.advance();
    else if (s.type === 'plus') {
      const best = Object.values(Game.player.equip).concat(Game.player.inv.filter(isGear)).filter(Boolean)
        .reduce((a, i) => Math.max(a, i.plus || 0), 0);
      if (best >= s.min) this.advance();
    }
    UI.syncQuest();
  },
  onKill(type) {
    const s = this.cur();
    if (s && s.type === 'kill' && s.target.includes(type)) { this.counter++; this.check(); }
    UI.syncQuest();
  },
  onCollect() { const s = this.cur(); if (s && s.type === 'collect') this.check(); },
  onBuy() { const s = this.cur(); if (s && s.type === 'buy') { this.counter++; this.check(); } },
  onPlus() { const s = this.cur(); if (s && s.type === 'plus') this.check(); },
  onSocket() { const s = this.cur(); if (s && s.type === 'socket') { this.counter++; this.check(); } },
  onEnchant() { const s = this.cur(); if (s && s.type === 'enchant') { this.counter++; this.check(); } },
  onInherit() { const s = this.cur(); if (s && s.type === 'inherit') { this.counter++; this.check(); } },
  onTalk(id) {
    const s = this.cur();
    if (s && s.type === 'talk' && s.npc === id) setTimeout(() => this.advance(), 60);
  },
  update() {
    const s = this.cur(); if (!s) return;
    const P = Game.player; if (!P) return;
    if (s.type === 'explore') {
      const b = World.biomeAtPx(P.x, P.y);
      if (s.biomes.includes(b.id)) this.advance();
    } else if (s.type === 'realm') {
      if (World.realmAtPx(P.x, P.y) === s.realm) this.advance();
    } else if (s.type === 'collect') {
      if (Inv.count(s.item) >= s.count) this.check();
    }
  },
  objectiveTarget() {
    const s = this.cur(); if (!s) return null;
    const npc = id => { const n = World.NPCS.find(x => x.id === id); return n ? [n.x, n.y] : null; };
    const mark = k => { const m = World.LANDMARKS[k]; return m ? [m[0] * 16, m[1] * 16] : null; };
    if (s.type === 'talk') return npc(s.npc);
    if (s.type === 'buy') return npc('mira');
    if (s.type === 'plus') return npc('borin');
    if (s.type === 'socket') return npc('wen');
    if (s.type === 'enchant') return npc('ilya');
    if (s.type === 'inherit') return npc('nadia');
    if (s.type === 'explore') return mark('forest');
    if (s.type === 'realm') return mark(s.realm);
    if (s.type === 'collect') return mark('swamp');
    if (s.type === 'kill') {
      if (this.bossNeeded) { const a = World.ARENAS[this.bossNeeded]; return [a[0] * 16, a[1] * 16]; }
      return this.step > 3 ? mark('forest') : null;
    }
    return null;
  },
};

window.addEventListener('DOMContentLoaded', () => {
  document.fonts.ready.then(() => Game.boot());
});
