(()=>{'use strict';
const $=s=>document.querySelector(s),KEY='ams-v2',CATS=['ذكاء','سرعة','حظ','استراتيجية','جماعي'];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const shuf=a=>[...a].sort(()=>Math.random()-.5);
const ICON={"search": "<circle cx=\"11\" cy=\"11\" r=\"6.5\"/><path d=\"M16 16l4.5 4.5\"/>", "home": "<path d=\"M4 11l8-7 8 7v9h-5v-6H9v6H4z\"/>", "edit": "<path d=\"M4 20l1-4L16 5l3 3L8 19z\"/><path d=\"M14 7l3 3\"/>", "trophy": "<path d=\"M8 4h8v5a4 4 0 01-8 0z\"/><path d=\"M8 6H5a3 3 0 003 4M16 6h3a3 3 0 01-3 4M12 13v4M8 20h8M10 17h4\"/>", "star": "<path d=\"M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z\"/>", "sound": "<path d=\"M4 9v6h4l5 4V5L8 9z\"/><path d=\"M16.5 8.5a5 5 0 010 7M19 6a8 8 0 010 12\"/>", "mute": "<path d=\"M4 9v6h4l5 4V5L8 9z\"/><path d=\"M17 9l5 6M22 9l-5 6\"/>", "close": "<path d=\"M6 6l12 12M18 6L6 18\"/>", "expand": "<path d=\"M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7\"/>", "float": "<rect x=\"3\" y=\"5\" width=\"18\" height=\"14\" rx=\"2\"/><rect x=\"11\" y=\"11\" width=\"8\" height=\"6\" rx=\"1\"/>", "fs": "<path d=\"M4 8V4h4M20 8V4h-4M4 16v4h4M20 16v4h-4\"/>", "undo": "<path d=\"M9 7L4 12l5 5M4 12h10a6 6 0 010 6h-3\"/>", "reset": "<path d=\"M20 12a8 8 0 11-3-6.2M20 4v5h-5\"/>", "flag": "<path d=\"M6 21V4M6 5h11l-2 4 2 4H6\"/>", "plus": "<path d=\"M12 5v14M5 12h14\"/>", "up": "<path d=\"M6 15l6-6 6 6\"/>", "down": "<path d=\"M6 9l6 6 6-6\"/>", "trash": "<path d=\"M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13\"/>", "download": "<path d=\"M12 4v11M7 11l5 5 5-5M5 20h14\"/>", "upload": "<path d=\"M12 16V5M7 9l5-5 5 5M5 20h14\"/>", "check": "<path d=\"M5 12l5 5 9-10\"/>", "skip": "<path d=\"M5 5l8 7-8 7zM17 5v14\"/>", "play": "<path d=\"M7 4l13 8-13 8z\"/>", "lock": "<rect x=\"5\" y=\"11\" width=\"14\" height=\"9\" rx=\"2\"/><path d=\"M8 11V8a4 4 0 018 0v3\"/>", "clock": "<circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M12 7v5l3 2\"/>", "users": "<circle cx=\"9\" cy=\"8\" r=\"3\"/><path d=\"M3 20c0-3.5 2.7-6 6-6s6 2.5 6 6\"/><circle cx=\"17\" cy=\"9\" r=\"2.4\"/><path d=\"M16 14.2c3 .3 5 2.4 5 5.8\"/>", "memory": "<rect x=\"4\" y=\"4\" width=\"7\" height=\"7\" rx=\"1.5\"/><rect x=\"13\" y=\"4\" width=\"7\" height=\"7\" rx=\"1.5\"/><rect x=\"4\" y=\"13\" width=\"7\" height=\"7\" rx=\"1.5\"/><rect x=\"13\" y=\"13\" width=\"7\" height=\"7\" rx=\"1.5\" fill=\"currentColor\" opacity=\".35\"/>", "number": "<path d=\"M9 4L7 20M17 4l-2 16M4 9h16M3 15h16\"/>", "odd": "<circle cx=\"8\" cy=\"8\" r=\"3\"/><circle cx=\"16\" cy=\"8\" r=\"3\"/><circle cx=\"8\" cy=\"16\" r=\"3\"/><rect x=\"13\" y=\"13\" width=\"6\" height=\"6\" rx=\"1\"/>", "match": "<rect x=\"3\" y=\"6\" width=\"11\" height=\"14\" rx=\"2\"/><rect x=\"10\" y=\"4\" width=\"11\" height=\"14\" rx=\"2\" fill=\"currentColor\" opacity=\".25\"/>", "quiz": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M9.5 9.5a2.5 2.5 0 015 0c0 1.6-2.5 2-2.5 3.8M12 17v.2\"/>", "math": "<path d=\"M4 7h6M7 4v6M14 17h6M15 6l5 5M20 6l-5 5\"/>", "tap": "<circle cx=\"12\" cy=\"12\" r=\"2.5\"/><circle cx=\"12\" cy=\"12\" r=\"6\"/><circle cx=\"12\" cy=\"12\" r=\"9.5\" opacity=\".5\"/>", "react": "<path d=\"M13 3L5 14h6l-1 7 8-11h-6z\"/>", "whack": "<circle cx=\"12\" cy=\"12\" r=\"7\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M12 2v4M12 18v4M2 12h4M18 12h4\"/>", "typing": "<rect x=\"3\" y=\"6\" width=\"18\" height=\"12\" rx=\"2\"/><path d=\"M7 10h.1M11 10h.1M15 10h.1M7 14h10\"/>", "guess": "<path d=\"M8 4v16M4 8l4-4 4 4M16 20V4M12 16l4 4 4-4\"/>", "rps": "<path d=\"M6 12V8a1.5 1.5 0 013 0V6a1.5 1.5 0 013 0v1a1.5 1.5 0 013 0v5a6 6 0 01-6 6 6 6 0 01-6-6z\"/>", "dice": "<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"3\"/><path d=\"M8.5 8.5h.1M15.5 8.5h.1M12 12h.1M8.5 15.5h.1M15.5 15.5h.1\"/>", "xo": "<path d=\"M4 4l7 7M11 4l-7 7\"/><circle cx=\"16.5\" cy=\"16.5\" r=\"4\"/>", "c4": "<circle cx=\"7\" cy=\"7\" r=\"2.5\"/><circle cx=\"17\" cy=\"7\" r=\"2.5\"/><circle cx=\"7\" cy=\"17\" r=\"2.5\" fill=\"currentColor\"/><circle cx=\"17\" cy=\"17\" r=\"2.5\"/><circle cx=\"12\" cy=\"12\" r=\"2.5\" fill=\"currentColor\" opacity=\".4\"/>", "forbid": "<circle cx=\"12\" cy=\"12\" r=\"8.5\"/><path d=\"M6 6l12 12\"/>", "sab": "<path d=\"M4 8c3-2 13-2 16 0v4c0 4-3.5 7-8 7s-8-3-8-7z\"/><path d=\"M8 12h2M14 12h2\"/>", "score": "<rect x=\"3\" y=\"5\" width=\"18\" height=\"14\" rx=\"2\"/><path d=\"M12 5v14M6.5 10v4M17.5 10v4\"/>", "detect": "<circle cx=\"10\" cy=\"10\" r=\"6\"/><path d=\"M15 15l5 5M8 10h4\"/>", "trivia": "<path d=\"M4 5h16v11H9l-5 4z\"/><path d=\"M9 9h6M9 12h4\"/>", "moon":"<path d=\"M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z\"/>","spy":"<path d=\"M3 11h18M6 11l1.5-6h9L18 11\"/><circle cx=\"8.5\" cy=\"16\" r=\"2.5\"/><circle cx=\"15.5\" cy=\"16\" r=\"2.5\"/><path d=\"M11 16h2\"/>","eye":"<path d=\"M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>","person":"<circle cx=\"10\" cy=\"8\" r=\"3.5\"/><path d=\"M3 20c0-4 3-6 7-6s7 2 7 6\"/><path d=\"M17 3.5a1.8 1.8 0 013 .8c0 1.2-1.8 1.4-1.8 2.7M18.2 9.2v.1\"/>","mask":"<path d=\"M4 6c5-2 11-2 16 0v5c0 4-3.5 7-8 7s-8-3-8-7z\"/><path d=\"M8 10l2 1M16 10l-2 1M9 14c1.5 1.3 4.5 1.3 6 0\"/>","phone":"<path d=\"M6 3h4l2 5-2.5 1.5a11 11 0 005 5L16 12l5 2v4a2 2 0 01-2 2A16 16 0 013 5a2 2 0 013-2z\"/>","shuffle":"<path d=\"M3 7h4l10 10h4M3 17h4l3-3M14 10l3-3h4M18 4l3 3-3 3M18 14l3 3-3 3\"/>","list":"<path d=\"M9 6h11M9 12h11M9 18h11M4.5 6h.1M4.5 12h.1M4.5 18h.1\"/>","tag":"<path d=\"M3 12V4h8l10 10-8 8z\"/><circle cx=\"7.5\" cy=\"8.5\" r=\"1.2\"/>","crown":"<path d=\"M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z\"/>","theater":"<path d=\"M4 4h9v7a4.5 4.5 0 01-9 0z\"/><path d=\"M7 8h.1M10 8h.1M6.5 11.5c1 .9 3 .9 4 0\"/><path d=\"M13 11h7v5a3.5 3.5 0 01-7 0z\" opacity=\".7\"/>","diff":"<rect x=\"3\" y=\"4\" width=\"8\" height=\"16\" rx=\"1.5\"/><rect x=\"13\" y=\"4\" width=\"8\" height=\"16\" rx=\"1.5\"/><circle cx=\"17\" cy=\"12\" r=\"2.5\"/>","minus":"<path d=\"M5 12h14\"/>","carrom":"<rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"3\"/><circle cx=\"12\" cy=\"12\" r=\"4\"/><circle cx=\"6.5\" cy=\"6.5\" r=\"1.2\"/><circle cx=\"17.5\" cy=\"6.5\" r=\"1.2\"/><circle cx=\"6.5\" cy=\"17.5\" r=\"1.2\"/><circle cx=\"17.5\" cy=\"17.5\" r=\"1.2\"/>","majd":"<path d=\"M6 4v8M2 8h8M14 8h8M2 18h8M14 18h8\"/>","gear":"<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M12 2v3M12 19v3M4.9 4.9 7 7M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1 7 17M17 7l2.1-2.1\"/>"};
const ICOLOR={};const ic=(k,c)=>(window.CICON&&CICON[k])?CICON[k]():`<svg class="ic ${c||""}"${ICOLOR[k]?` style="color:${ICOLOR[k]}"`:""} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[k]||ICON.quiz}</svg>`;
Object.assign(ICON,{"grid":"<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"3\"/><path d=\"M4 12h16M12 4v16\"/>","puzzle":"<path d=\"M5 5h5a2 2 0 1 1 4 0h5v5a2 2 0 1 0 0 4v5H5z\"/>","bulb":"<path d=\"M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z\"/>","brain":"<path d=\"M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V4a3 3 0 0 0-3 0zM15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1\"/>","sun":"<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6L7 7M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4\"/>","vote":"<rect x=\"5\" y=\"10\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 10l1-6h6l1 6M9 15l2 2 4-4\"/>","doctor":"<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"4\"/><path d=\"M12 8v8M8 12h8\"/>","elder":"<circle cx=\"12\" cy=\"7\" r=\"3.5\"/><path d=\"M5 21c0-4 3-7 7-7s7 3 7 7M9 7c1 1 5 1 6 0\"/>","palette":"<path d=\"M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.2-2.5 1.6-2.5H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.5z\"/><circle cx=\"7.5\" cy=\"11\" r=\"1\"/><circle cx=\"10\" cy=\"7\" r=\"1\"/><circle cx=\"15\" cy=\"7.5\" r=\"1\"/>","globe":"<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18\"/>"});
const clone=v=>JSON.parse(JSON.stringify(v));

const BANK=[
{cat:'جغرافيا',level:'سهل',q:'ما عاصمة المملكة العربية السعودية?',a:['جدة','الرياض','مكة المكرمة','الدمام'],correct:1,why:'الرياض هي عاصمة المملكة العربية السعودية.'},
{cat:'جغرافيا',level:'سهل',q:'أي محيط هو الأكبر على الأرض?',a:['الأطلسي','الهندي','الهادئ','المتجمد الشمالي'],correct:2,why:'المحيط الهادئ هو أكبر محيط على الأرض.'},
{cat:'جغرافيا',level:'متوسط',q:'ما الدولة التي تضم مدينة إسطنبول?',a:['اليونان','تركيا','بلغاريا','إيطاليا'],correct:1,why:'تقع إسطنبول في تركيا.'},
{cat:'جغرافيا',level:'صعب',q:'ما المضيق الذي يصل البحر الأحمر بخليج عدن?',a:['هرمز','جبل طارق','باب المندب','البوسفور'],correct:2,why:'مضيق باب المندب يصل البحر الأحمر بخليج عدن.'},
{cat:'علوم',level:'سهل',q:'ما الكوكب المعروف بالكوكب الأحمر?',a:['الزهرة','المريخ','المشتري','عطارد'],correct:1,why:'يبدو المريخ أحمر بسبب أكاسيد الحديد على سطحه.'},
{cat:'علوم',level:'متوسط',q:'ما وحدة قياس القوة في النظام الدولي?',a:['الجول','الواط','النيوتن','الأمبير'],correct:2,why:'تقاس القوة بالنيوتن.'},
{cat:'علوم',level:'صعب',q:'ما الجسيم ذو الشحنة السالبة في الذرة?',a:['البروتون','النيوترون','الإلكترون','النواة'],correct:2,why:'الإلكترون يحمل شحنة سالبة.'},
{cat:'أحياء',level:'سهل',q:'ما العضو الذي يضخ الدم في جسم الإنسان?',a:['الرئة','القلب','الكبد','المعدة'],correct:1,why:'القلب يضخ الدم عبر الأوعية الدموية.'},
{cat:'أحياء',level:'متوسط',q:'ما الجزء الذي يحمل معظم المادة الوراثية في الخلية?',a:['النواة','الغشاء','السيتوبلازم','الفجوة'],correct:0,why:'توجد معظم المادة الوراثية في نواة الخلية.'},
{cat:'أحياء',level:'صعب',q:'ما اسم العملية التي تصنع بها النباتات غذاءها باستخدام الضوء?',a:['التنفس','التخمر','البناء الضوئي','النتح فقط'],correct:2,why:'البناء الضوئي يحول الطاقة الضوئية إلى طاقة كيميائية.'},
{cat:'تاريخ',level:'سهل',q:'في أي قارة قامت الحضارة المصرية القديمة?',a:['آسيا','أفريقيا','أوروبا','أمريكا الجنوبية'],correct:1,why:'نشأت الحضارة المصرية القديمة على ضفاف نهر النيل في أفريقيا.'},
{cat:'تاريخ',level:'متوسط',q:'في أي عام انتهت الحرب العالمية الثانية?',a:['1918','1939','1945','1955'],correct:2,why:'انتهت الحرب العالمية الثانية عام 1945.'},
{cat:'تاريخ',level:'صعب',q:'ما اسم الطريق التجاري القديم الذي ربط مناطق من شرق آسيا بالغرب?',a:['طريق البخور فقط','طريق الحرير','طريق الذهب الأطلسي','طريق القطب'],correct:1,why:'كان طريق الحرير شبكة طرق تجارية تربط شرق آسيا بمناطق غرباً.'},
{cat:'فضاء',level:'سهل',q:'ما النجم الأقرب إلى الأرض?',a:['الشعرى اليمانية','الشمس','النجم القطبي','منكب الجوزاء'],correct:1,why:'الشمس هي أقرب نجم إلى الأرض.'},
{cat:'فضاء',level:'متوسط',q:'ما اسم المجرة التي تقع فيها المجموعة الشمسية?',a:['أندروميدا','درب التبانة','المثلث','سحابة ماجلان الكبرى'],correct:1,why:'تقع مجموعتنا الشمسية في مجرة درب التبانة.'},
{cat:'فضاء',level:'صعب',q:'ما اسم أول قمر صناعي أطلقه الإنسان إلى الفضاء?',a:['أبولو 11','سبوتنيك 1','فوستوك 1','فوياجر 1'],correct:1,why:'أطلق الاتحاد السوفيتي سبوتنيك 1 عام 1957.'},
{cat:'رياضيات',level:'سهل',q:'كم يساوي 9 × 7?',a:['56','63','72','67'],correct:1,why:'9 × 7 = 63.'},
{cat:'رياضيات',level:'متوسط',q:'ما مجموع زوايا المثلث بالدرجات في الهندسة الإقليدية?',a:['90','180','270','360'],correct:1,why:'مجموع زوايا أي مثلث يساوي 180 درجة.'},
{cat:'رياضيات',level:'صعب',q:'إذا كان x + 7 = 19، فما قيمة x?',a:['10','11','12','13'],correct:2,why:'بطرح 7 من الطرفين نحصل على x = 12.'},
{cat:'معلومات عامة',level:'سهل',q:'كم يوماً في السنة العادية?',a:['360','364','365','366'],correct:2,why:'السنة العادية تتكون من 365 يوماً.'},
{cat:'معلومات عامة',level:'متوسط',q:'ما اللغة الأكثر انتشاراً من حيث عدد المتحدثين الأصليين تقريباً?',a:['الإسبانية','الإنجليزية','الصينية المندرينية','العربية'],correct:2,why:'الصينية المندرينية من أكبر اللغات من حيث عدد المتحدثين الأصليين.'},
{cat:'معلومات عامة',level:'صعب',q:'ما اسم المقياس المستخدم لقياس صلادة المعادن?',a:['مقياس موهس','مقياس ريختر','مقياس بوفورت','مقياس سيليسيوس'],correct:0,why:'مقياس موهس يقارن صلادة المعادن.'},
{cat:'لغة عربية',level:'سهل',q:'ما جمع كلمة «كتاب»?',a:['كتائب','كتابون فقط','كتب','مكتبات فقط'],correct:2,why:'جمع كتاب هو كتب.'},
{cat:'لغة عربية',level:'متوسط',q:'أي كلمة من الآتي تُعد فعلاً ماضياً?',a:['يكتب','اكتب','كتب','كاتب'],correct:2,why:'«كتب» فعل ماضٍ.'},
{cat:'لغة عربية',level:'صعب',q:'ما نوع «لن» في جملة «لن أهمل واجبي»?',a:['حرف نصب ونفي واستقبال','حرف جر','اسم موصول','حرف عطف'],correct:0,why:'لن تنصب الفعل المضارع وتفيد نفي المستقبل.'},
{cat:'علوم',level:'صعب',q:'أي قانون يربط الجهد والتيار والمقاومة?',a:['قانون نيوتن','قانون أوم','قانون باسكال','قانون بويل'],correct:1,why:'قانون أوم: الجهد يساوي التيار مضروبًا في المقاومة.'},
{cat:'علوم',level:'صعب',q:'ما العدد الذري للكربون?',a:['4','6','8','12'],correct:1,why:'العدد الذري للكربون هو 6.'},
{cat:'علوم',level:'متوسط',q:'أي طبقة من الغلاف الجوي تحدث فيها معظم الظواهر الجوية?',a:['الستراتوسفير','الميزوسفير','التروبوسفير','الإكسوسفير'],correct:2,why:'تحدث معظم الظواهر الجوية في طبقة التروبوسفير.'},
{cat:'علوم',level:'صعب',q:'ما اسم تحول المادة من الحالة الصلبة إلى الغازية مباشرة?',a:['التكاثف','التسامي','التجمد','الانصهار'],correct:1,why:'يسمى التحول المباشر من الصلب إلى الغاز بالتسامي.'},
{cat:'جغرافيا',level:'صعب',q:'ما أعلى قمة جبلية في أفريقيا?',a:['كليمنجارو','كينيا','إلبروس','أطلس'],correct:0,why:'قمة كليمنجارو هي الأعلى في أفريقيا.'},
{cat:'جغرافيا',level:'صعب',q:'ما عاصمة كازاخستان?',a:['ألماتي','طشقند','أستانا','بيشكيك'],correct:2,why:'عاصمة كازاخستان هي أستانا.'},
{cat:'جغرافيا',level:'متوسط',q:'أي نهر يمر بمدينة بغداد?',a:['النيل','دجلة','الأردن','الفرات فقط'],correct:1,why:'يمر نهر دجلة بمدينة بغداد.'},
{cat:'تاريخ',level:'صعب',q:'في أي عام سقطت القسطنطينية بيد العثمانيين?',a:['1299','1453','1492','1517'],correct:1,why:'سقطت القسطنطينية عام 1453.'},
{cat:'تاريخ',level:'صعب',q:'ما الحضارة التي طورت الكتابة المسمارية في بلاد الرافدين?',a:['السومرية','الرومانية','الفينيقية','الإغريقية'],correct:0,why:'ارتبطت الكتابة المسمارية المبكرة بالسومريين.'},
{cat:'تاريخ',level:'متوسط',q:'من قاد أول رحلة بحرية دارت حول العالم وأكملها طاقمه?',a:['كولومبوس','ماجلان','فاسكو دا غاما','جيمس كوك'],correct:1,why:'بدأ ماجلان الرحلة وأكملها طاقمه بعد وفاته.'},
{cat:'فضاء',level:'صعب',q:'ما الكوكب الذي يملك أقصر مدة دوران حول الشمس?',a:['المريخ','عطارد','الزهرة','الأرض'],correct:1,why:'عطارد أقرب الكواكب إلى الشمس وأقصرها سنة.'},
{cat:'فضاء',level:'صعب',q:'ما اسم الحد الذي لا يستطيع الضوء بعده الهروب من الثقب الأسود?',a:['الأفق الحدثي','الغلاف الضوئي','خط الاستواء','الحزام الكويكبي'],correct:0,why:'يسمى هذا الحد أفق الحدث.'},
{cat:'رياضيات',level:'صعب',q:'ما العدد الأولي الزوجي الوحيد?',a:['0','1','2','4'],correct:2,why:'العدد 2 هو العدد الأولي الزوجي الوحيد.'},
{cat:'رياضيات',level:'صعب',q:'إذا كان 3x - 5 = 16، فما قيمة x?',a:['5','6','7','8'],correct:2,why:'بإضافة 5 ثم القسمة على 3 نحصل على 7.'},
{cat:'رياضيات',level:'متوسط',q:'ما قيمة 15% من 200?',a:['15','20','30','35'],correct:2,why:'0.15 × 200 = 30.'},
{cat:'معلومات عامة',level:'صعب',q:'ما العنصر الكيميائي الذي رمزه W?',a:['التنغستن','القصدير','الفضة','الزنك'],correct:0,why:'يرمز W إلى التنغستن.'},
{cat:'معلومات عامة',level:'صعب',q:'كم عدد العظام تقريبًا في جسم الإنسان البالغ?',a:['106','206','306','406'],correct:1,why:'يبلغ عدد العظام لدى الإنسان البالغ عادة نحو 206 عظام.'},
{cat:'معلومات عامة',level:'متوسط',q:'ما العملة الرسمية في اليابان?',a:['الوون','اليوان','الين','الروبية'],correct:2,why:'الين هو العملة الرسمية في اليابان.'},
{cat:'لغة عربية',level:'صعب',q:'ما جمع كلمة «قاضٍ»?',a:['قاضيون','قضاة','قاضيات فقط','أقضية'],correct:1,why:'من جموع قاضٍ: قضاة.'},
{cat:'علوم',level:'صعب',q:'ما قيمة تسارع الجاذبية قرب سطح الأرض تقريبًا?',a:['1.8 م/ث²','5.2 م/ث²','9.8 م/ث²','18 م/ث²'],correct:2,why:'تسارع الجاذبية قرب سطح الأرض يقارب 9.8 م/ث².'},
{cat:'جغرافيا',level:'صعب',q:'أي دولة تحيط بها جنوب أفريقيا من جميع الجهات البرية?',a:['ليسوتو','ناميبيا','بوتسوانا','زيمبابوي'],correct:0,why:'تقع ليسوتو بالكامل داخل حدود جنوب أفريقيا.'},
{cat:'تاريخ',level:'صعب',q:'ما اسم المعاهدة التي أنهت الحرب العالمية الأولى رسميًا مع ألمانيا?',a:['فرساي','فيينا','لوزان','باريس 1763'],correct:0,why:'وُقعت معاهدة فرساي عام 1919.'},
{cat:'فضاء',level:'متوسط',q:'ما أكبر كوكب في المجموعة الشمسية?',a:['زحل','الأرض','المشتري','نبتون'],correct:2,why:'المشتري أكبر كواكب المجموعة الشمسية.'},
{cat:'معلومات عامة',level:'صعب',q:'ما اسم العلم الذي يدرس الزلازل?',a:['الأرصاد','علم الزلازل','علم المحيطات','علم الصخور فقط'],correct:1,why:'علم الزلازل يدرس الزلازل والموجات الزلزالية.'},
{cat:'رياضيات',level:'صعب',q:'ما الجذر التربيعي للعدد 196?',a:['12','13','14','16'],correct:2,why:'14 × 14 = 196.'},
{cat:'علوم',level:'متوسط',q:'أي فيتامين يساعد الجسم على امتصاص الكالسيوم?',a:['فيتامين A','فيتامين C','فيتامين D','فيتامين K فقط'],correct:2,why:'يساعد فيتامين D على امتصاص الكالسيوم.'},
{cat:'جغرافيا',level:'متوسط',q:'ما أكبر دولة في العالم من حيث المساحة?',a:['كندا','الصين','روسيا','الولايات المتحدة'],correct:2,why:'روسيا هي الأكبر مساحةً.'},
{cat:'معلومات عامة',level:'صعب',q:'ما وحدة قياس التردد?',a:['نيوتن','هرتز','جول','باسكال'],correct:1,why:'يقاس التردد بالهرتز.'}
].map((x,i)=>({id:'q'+i,cat:x.cat,level:x.level,q:x.q,a:x.a,c:x.correct,w:x.why}));
const DEF={fav:[],best:{},plays:{},recent:[],custom:[],rounds:[],qRecent:[],sb:null,theme:'royal',vol:.8,mute:false,motion:true,vib:true,pack:'arcade',font:'system',bg:'glow',cs:'glass',rd:'soft',fz:100,acc:'',music:false,xp:0,streak:null,daily:null};
let S=Object.assign({},DEF);try{Object.assign(S,JSON.parse(localStorage.getItem(KEY)||'{}'));if(!localStorage.getItem(KEY)){const t=localStorage.getItem('ahmed-game-theme');if(['royal','red','blue'].includes(t))S.theme=t}}catch(e){}
for(const k of ['fav','recent','custom','rounds','qRecent'])if(!Array.isArray(S[k]))S[k]=[];for(const k of ['best','plays'])if(!S[k]||typeof S[k]!=='object'||Array.isArray(S[k]))S[k]={};S.custom=S.custom.filter(g=>g&&typeof g.n==='string'&&Array.isArray(g.qs)&&Array.isArray(g.players));
const CLR=['عام','مجد','كيرم'];
const SBD={'عام':{b:[{n:'عادي',v:1},{n:'عادي',v:5},{n:'عادي',v:10},{n:'عادي',v:20}],limit:0,max:8,sel:0,used:null,teams:[{n:'الفريق الأول',s:0},{n:'الفريق الثاني',s:0}],hist:[]},
'مجد':{b:[{n:'زيادة 10',v:10},{n:'زيادة 10',v:10},{n:'زيادة 10',v:10},{n:'زيادة 10',v:10}],limit:500,max:8,sel:0,used:null,teams:[{n:'الفريق الأول',s:0},{n:'الفريق الثاني',s:0}],hist:[]},
'كيرم':{b:[{n:'الحمراء',v:50,once:true},{n:'البيضاء',v:10},{n:'السوداء',v:5},{n:'زيادة 10',v:10}],limit:0,max:8,sel:0,used:null,teams:[{n:'الفريق الأول',s:0},{n:'الفريق الثاني',s:0}],hist:[]}};
function sbGet(){let sb=S.sb;if(!sb||typeof sb!=='object'||!sb.m||typeof sb.m!=='object')sb=S.sb={mode:'عام',m:{}};for(const k of CLR){const m=sb.m[k];if(!m||!Array.isArray(m.teams)||!m.teams.length||!Array.isArray(m.b)||!m.b.length||!Array.isArray(m.hist)||!m.teams.every(t=>t&&typeof t.n==='string'&&Number.isFinite(t.s)))sb.m[k]=clone(SBD[k])}if(!SBD[sb.mode])sb.mode='عام';return sb}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast('تعذّر الحفظ على هذا المتصفح','err')}};
function toast(m,k){const t=document.createElement('div');t.className='toast '+(k||'');t.textContent=m;$('#toasts').appendChild(t);if(k==='err')SFX.bad();else SFX.pop();setTimeout(()=>t.classList.add('out'),2300);setTimeout(()=>t.remove(),2600)}
function cfm(m){return new Promise(r=>{const d=$('#dlg');d.querySelector('p').textContent=m;d.hidden=false;const f=v=>{d.hidden=true;r(v)};$('#dy').onclick=()=>f(true);$('#dn').onclick=()=>f(false)})}
let AC,MG;
const actx=()=>{if(!AC){const C=window.AudioContext||window.webkitAudioContext;if(!C)return null;AC=new C();MG=AC.createGain();const cp=AC.createDynamicsCompressor();MG.connect(cp);cp.connect(AC.destination)}if(AC.state==='suspended')AC.resume().catch(()=>{});MG.gain.value=Math.max(0,Math.min(1,+S.vol||0));return AC};
let RV;const rev=c=>{if(RV)return RV;const n=c.sampleRate*1.4|0,bf=c.createBuffer(2,n,c.sampleRate);for(let k=0;k<2;k++){const d=bf.getChannelData(k);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2.6)}const cv=c.createConvolver();cv.buffer=bf;const w=c.createGain();w.gain.value=.24;cv.connect(w);w.connect(MG);return RV=cv};
const tone=(f,d=.12,type='sine',o={})=>{if(S.mute||!(S.vol>0))return;try{const c=actx();if(!c)return;const t=c.currentTime+(o.at||0),ty=S.pack==='soft'?'sine':S.pack==='retro'?'square':S.pack==='crystal'?(type==='sawtooth'?'sawtooth':'triangle'):type,v=Math.min(.6,(o.v||.28)*1.1),g=c.createGain(),fl=c.createBiquadFilter(),lp=Math.min(16000,o.lp||Math.max(1800,f*7));fl.type='lowpass';fl.Q.value=o.q||1.1;fl.frequency.setValueAtTime(lp,t);fl.frequency.exponentialRampToValueAtTime(Math.max(300,lp*.35),t+d);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+Math.min(.012,d/4));g.gain.setTargetAtTime(.0001,t+d*.35,d*.26);(o.det===0?[0]:[-7,7]).forEach(dt=>{const os=c.createOscillator();os.type=ty;os.frequency.setValueAtTime(f,t);os.detune.value=dt;if(o.to)os.frequency.exponentialRampToValueAtTime(o.to,t+d);os.connect(fl);os.start(t);os.stop(t+d+.12)});if(o.sub){const os=c.createOscillator(),sg=c.createGain();os.frequency.setValueAtTime(f/2,t);if(o.to)os.frequency.exponentialRampToValueAtTime(o.to/2,t+d);sg.gain.value=.7;os.connect(sg);sg.connect(fl);os.start(t);os.stop(t+d+.12)}fl.connect(g);g.connect(MG);if(o.rv!==0){const r=c.createGain();r.gain.value=o.rv||.45;g.connect(r);r.connect(rev(c))}}catch(e){}};
const hiss=(d=.12,o={})=>{if(S.mute||!(S.vol>0))return;try{const c=actx();if(!c)return;const t=c.currentTime+(o.at||0),len=Math.max(1,c.sampleRate*d|0),buf=c.createBuffer(1,len,c.sampleRate),ch=buf.getChannelData(0);for(let i=0;i<len;i++)ch[i]=Math.random()*2-1;const sr=c.createBufferSource(),fl=c.createBiquadFilter(),g=c.createGain();sr.buffer=buf;fl.type='bandpass';fl.frequency.setValueAtTime(o.f||1800,t);if(o.to)fl.frequency.exponentialRampToValueAtTime(o.to,t+d);g.gain.setValueAtTime(o.v||.18,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);sr.connect(fl);fl.connect(g);g.connect(MG);sr.start(t)}catch(e){}};
const bell=(f,d=.5,o={})=>{if(S.mute||!(S.vol>0))return;try{const c=actx();if(!c)return;const t=c.currentTime+(o.at||0),ca=c.createOscillator(),md=c.createOscillator(),mg=c.createGain(),g=c.createGain(),v=o.v||.2;ca.frequency.value=f;md.frequency.value=f*3.5;mg.gain.setValueAtTime(f*1.6,t);mg.gain.exponentialRampToValueAtTime(1,t+d);md.connect(mg);mg.connect(ca.frequency);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+.006);g.gain.exponentialRampToValueAtTime(.0001,t+d);ca.connect(g);g.connect(MG);const r=c.createGain();r.gain.value=.6;g.connect(r);r.connect(rev(c));ca.start(t);md.start(t);ca.stop(t+d+.05);md.stop(t+d+.05)}catch(e){}};
const thud=(f=120,d=.2,v=.4)=>{tone(f,d,'sine',{to:f*.4,v,det:0,rv:.15});hiss(d*.7,{f:500,to:120,v:v*.5})};
const snd=(f,d=.12,t='sine')=>tone(f,d,t);
const vib=p=>{if(S.motion!==false&&S.vib!==false&&!S.mute&&navigator.vibrate)try{navigator.vibrate(p)}catch(e){}};
const arp=(n,st,type,o)=>n.forEach((f,i)=>tone(f,.2,type,Object.assign({at:i*st},o||{})));
const SFX={
tap:()=>{tone(880,.05,'triangle',{to:1250,v:.15,rv:.2});vib(8)},
pop:()=>tone(520,.1,'sine',{to:1040,v:.22}),
ok:()=>{arp([659,880,1175],.06,'triangle',{v:.18});bell(1568,.45,{at:.14,v:.12});vib(15)},
bad:()=>{tone(220,.3,'sawtooth',{to:90,lp:700,v:.2,sub:1});vib([40,30,40])},
win:()=>{arp([523,659,784,1047],.1,'square',{v:.12,lp:3200});bell(1568,.8,{at:.42,v:.18});bell(2093,.8,{at:.5,v:.12});vib([20,40,20,40,60])},
end:()=>{arp([392,349,311,262],.18,'triangle',{v:.18,sub:1})},
lose:()=>{arp([392,349,311,262],.2,'triangle',{v:.2,sub:1});thud(80,.5,.3)},
tick:()=>tone(1400,.03,'square',{v:.06,lp:3500,det:0,rv:0}),
flip:()=>{hiss(.09,{f:2500,to:900,v:.1});tone(700,.05,'triangle',{v:.1})},
coin:()=>{bell(1319,.3,{v:.16});bell(1760,.4,{at:.07,v:.14})},
swoosh:()=>hiss(.25,{f:500,to:4200,v:.13}),
open:()=>arp([392,523,659],.05,'triangle',{v:.15}),
close:()=>arp([659,523,392],.05,'triangle',{v:.13}),
jump:()=>{tone(300,.16,'square',{to:680,v:.12,lp:2800,det:0});vib(6)},
land:()=>thud(150,.1,.22),
eat:()=>{tone(520,.07,'square',{to:1040,v:.12,det:0,lp:3000});bell(1175,.3,{at:.05,v:.14})},
hit:()=>{thud(110,.18,.35);hiss(.15,{f:2000,to:500,v:.2});vib(25)},
die:()=>{tone(520,.7,'sawtooth',{to:55,lp:1400,v:.2,sub:1});hiss(.45,{f:1500,to:150,v:.18});vib([60,40,100])},
flap:()=>{hiss(.08,{f:900,to:2400,v:.09});tone(380,.07,'triangle',{to:600,v:.1,det:0,rv:.1})},
score:()=>{bell(1175,.35,{v:.18});bell(1568,.45,{at:.08,v:.16})},
milestone:()=>arp([784,988,1175,1568],.06,'triangle',{v:.16}),
best:()=>{arp([523,659,784,1047,1319,1568],.08,'square',{v:.1,lp:3500});bell(2093,.9,{at:.5,v:.16});vib([20,30,20,30,80])},
shoot:()=>tone(900,.12,'sawtooth',{to:200,v:.13,lp:3000,det:0}),
zap:()=>{hiss(.18,{f:3000,to:800,v:.16});tone(1500,.15,'sawtooth',{to:300,v:.1,lp:4000})},
boom:()=>{thud(70,.6,.5);hiss(.5,{f:900,to:100,v:.3});vib([80,40,120])},
buy:()=>{bell(1047,.25,{v:.15});bell(1319,.25,{at:.08,v:.15});bell(1568,.5,{at:.16,v:.15})},
upgrade:()=>{arp([523,659,784,1047,1319],.06,'triangle',{v:.16});bell(2093,.6,{at:.35,v:.14})},
powerup:()=>arp([440,554,659,880,1109],.05,'square',{v:.1,lp:3000})
};
(()=>{const T={};Object.keys(SFX).forEach(k=>{const f=SFX[k];SFX[k]=(...z)=>{const n=performance.now();if(n-(T[k]||0)<45)return;T[k]=n;return f(...z)}})})();
for(const k of ['bad', 'close', 'end', 'ok', 'open', 'swoosh', 'tap', 'win'])if(!SFX[k])SFX[k]=SFX.tap;
addEventListener('pointerdown',()=>actx(),{once:true,passive:true});
const burst=()=>{if(S.motion===false||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const v=$('#gv'),C=['#ffd36b','#ff5a6e','#4cd964','#4aa8ff','#a66cff'];for(let i=0;i<36;i++){const p=document.createElement('i');p.className='cf';p.style.background=C[i%5];p.style.setProperty('--x',(Math.random()*340-170)+'px');p.style.setProperty('--y',(Math.random()*320+40)+'px');p.style.setProperty('--r',(Math.random()*720-360)+'deg');p.style.animationDelay=(Math.random()*.15)+'s';v.appendChild(p);setTimeout(()=>p.remove(),1400)}};
Object.assign(SFX,{sub:()=>tone(330,.14,'triangle',{to:190,v:.22}),restart:()=>{hiss(.35,{f:300,to:3500,v:.15});arp([392,523,659,784],.07,'sine',{v:.2,at:.05})},red:()=>{arp([523,659,784,1047,1319,1568],.06,'triangle',{v:.24});tone(131,.5,'sine',{v:.3})},found:()=>{tone(784,.09,'triangle',{v:.24});tone(1175,.16,'sine',{at:.07,v:.22})}});
/* ===== v4 sounds: stronger + more effects ===== */
Object.assign(SFX,{
ok:()=>{arp([784,988,1319],.06,'triangle',{v:.3});vib(15)},
bad:()=>{tone(220,.3,'sawtooth',{to:100,lp:900,v:.28});tone(165,.3,'square',{at:.05,to:80,lp:700,v:.14});vib([40,30,40])},
win:()=>{arp([523,659,784,1047,1319,1568],.09,'triangle',{v:.3});arp([262,330,392,523],.09,'sine',{v:.26,at:.05});tone(2093,.5,'sine',{at:.65,v:.16});vib([20,40,20,40,60])},
click:()=>tone(900,.04,'square',{v:.12,lp:3000}),
select:()=>arp([523,784],.06,'triangle',{v:.22}),
levelup:()=>arp([392,523,659,784,1047],.08,'square',{v:.2,lp:2500}),
combo:()=>arp([659,784,988,1319],.05,'triangle',{v:.24}),
warn:()=>{tone(180,.18,'square',{v:.22,lp:900});tone(180,.18,'square',{at:.22,v:.22,lp:900})},
boom:()=>{hiss(.5,{f:900,to:80,v:.3});tone(70,.4,'sine',{to:40,v:.4})},
whoosh:()=>hiss(.3,{f:300,to:4000,v:.2}),
power:()=>arp([262,330,392,523,659,784],.05,'sawtooth',{v:.16,lp:2000}),
fanfare:()=>{arp([523,523,523,659,784,1047],.11,'square',{v:.2,lp:2600});arp([262,262,262,330,392,523],.11,'triangle',{v:.2})},
merge:()=>tone(300,.12,'triangle',{to:700,v:.26}),
slide:()=>hiss(.1,{f:1200,to:600,v:.12}),
type:()=>tone(1400,.025,'square',{v:.08,lp:4000})});

/* ---------- game runtime ---------- */
let cur=null,TM=[]; let LANG='ar';
const api={live:false,cu:[],
t(f,ms){const i=setTimeout(f,ms);TM.push(['t',i]);return i},
i(f,ms){const i=setInterval(f,ms);TM.push(['i',i]);return i},
clr(){(this.cu||[]).splice(0).forEach(f=>{try{f()}catch(e){}});TM.forEach(([k,i])=>k==='t'?clearTimeout(i):clearInterval(i));TM=[]},
end(sc,msg){this.clr();this.live=false;const g=cur,b=$('#gb');b.onclick=b.oninput=b.onkeydown=null;if(sc!=null&&Number.isFinite(sc)){const o=S.best[g.id];if(o==null||(g.low?sc<o:sc>o)){S.best[g.id]=sc;msg+=' - رقم جديد وأقوى'}}save();SFX.win();if(/قياسي/.test(msg))burst();$('#gr').innerHTML=`<div class="res">${esc(msg)}</div><div class="row"><button class="btn p" id="again">↻ عيد</button><button class="btn" id="exit">القائمة</button></div>`;$('#again').onclick=startGame;$('#exit').onclick=()=>closeGame(true)}};
function startGame(){api.clr();api.live=true;const b=$('#gb');b.onclick=b.oninput=b.onkeydown=null;b.onpointerdown=b.onpointerup=null;KEYH=null;b.innerHTML='';$('#gr').innerHTML='';try{cur.run(b,api)}catch(e){console.error(e);toast('صار خطأ في اللعبة','err');closeGame(true)}}
function setMode(m){const v=$('#gv');v.className=m;delete v.dataset.min;if(m!=='fl')v.removeAttribute('style');document.body.classList.toggle('lock',m!=='fl')}
function openGame(g){closeGame(true);cur=g;S.plays[g.id]=(S.plays[g.id]||0)+1;S.recent=[g.id,...S.recent.filter(x=>x!==g.id)].slice(0,6);save();$('#gt').innerHTML=ic(g.i)+' '+esc(g.n);$('#gv').hidden=false;setMode('');SFX.open();startGame()}
async function closeGame(force){if(!cur)return;if(!force&&api.live&&!(await cfm('اللعبة شغالة وبيروح تقدمك. تبي تسكّرها؟')))return;api.clr();api.live=false;if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});$('#gv').hidden=true;SFX.close();$('#gb').innerHTML='';$('#gb').onclick=$('#gb').oninput=$('#gb').onkeydown=null;cur=null;document.body.classList.remove('lock');renderLib();renderRec()}
$('#gx').onclick=()=>closeGame(false);
$('#gmin').onclick=()=>{const v=$('#gv'),m=v.dataset.min!=='1';v.dataset.min=m?'1':'0';$('#gmin').innerHTML=ic(m?'up':'minus');SFX.swoosh()};
$('#gbg').onclick=()=>setMode($('#gv').className==='big'?'':'big');
$('#gfl').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});setMode($('#gv').className==='fl'?'':'fl')};
if(!document.fullscreenEnabled)$('#gfs').hidden=true;
$('#gfs').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});else{setMode('big');$('#gv').requestFullscreen().catch(()=>toast('المتصفح منع ملء الشاشة','err'))}};
let drag=null;const H=$('#ghd');
H.onpointerdown=e=>{const v=$('#gv');if(v.className!=='fl'||e.target.closest('button'))return;const r=v.getBoundingClientRect();drag={x:e.clientX-r.left,y:e.clientY-r.top};H.setPointerCapture(e.pointerId)};
H.onpointermove=e=>{if(!drag)return;const v=$('#gv');v.style.left=Math.max(0,Math.min(innerWidth-80,e.clientX-drag.x))+'px';v.style.top=Math.max(0,Math.min(innerHeight-60,e.clientY-drag.y))+'px';v.style.right=v.style.bottom='auto'};
H.onpointerup=()=>drag=null;
/* ---------- games ---------- */
function gMemory(b,a){const C=['#ff5a6e','#4cd964','#4aa8ff','#ffd23f'];let seq=[],pos=0,ok=false;
b.innerHTML='<div class="info" id="mi">راقب التسلسل</div><div class="pads">'+C.map((c,i)=>`<button class="pad" data-a="${i}" style="background:${c}"></button>`).join('')+'</div>';
const pads=[...b.querySelectorAll('.pad')],info=b.querySelector('#mi');
const flash=i=>{pads[i].classList.add('on');snd(300+i*120,.2);a.t(()=>pads[i].classList.remove('on'),300)};
const play=()=>{ok=false;pos=0;seq.push(Math.random()*4|0);info.textContent='المستوى '+seq.length;seq.forEach((s,k)=>a.t(()=>flash(s),600+k*600));a.t(()=>{ok=true;info.textContent='دورك!'},600+seq.length*600)};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t||!ok)return;const i=+t.dataset.a;flash(i);if(i!==seq[pos]){SFX.bad();a.end(seq.length-1,'وصلت للمستوى '+(seq.length-1));return}if(++pos===seq.length){ok=false;SFX.ok();a.t(play,700)}};play()}
function gNumber(b,a){let lv=3;const show=()=>{const n=Array.from({length:lv},()=>Math.random()*10|0).join('');b.onclick=null;b.innerHTML=`<div class="big">${n}</div><div class="info">احفظه… المستوى ${lv-2}</div>`;a.t(()=>{b.innerHTML='<input id="ni" inputmode="numeric" placeholder="اكتب الرقم" autocomplete="off"><button class="btn p" data-a="1">تحقق</button>';const go=()=>{const v=b.querySelector('#ni').value.trim();if(v===n){SFX.ok();lv++;show()}else{SFX.bad();a.end(lv-3,`الرقم كان ${n} - اجتزت ${lv-3} مستويات`)}};b.onclick=e=>{if(e.target.closest('[data-a]'))go()};b.onkeydown=e=>{if(e.key==='Enter')go()};b.querySelector('#ni').focus()},900+lv*500)};show()}
function gMath(b,a){let sc=0,left=20,ans;b.innerHTML='<div class="info"><span id="mt">20</span> ث · النقاط <span id="ms">0</span></div><div class="big" id="mq"></div><input id="ma" inputmode="numeric" autocomplete="off"><button class="btn p" data-a="1">تأكيد</button>';
const q=()=>{const x=1+Math.random()*12|0,y=1+Math.random()*12|0,m=Math.random()<.5;ans=m?x*y:x+y;b.querySelector('#mq').textContent=`${x} ${m?'×':'+'} ${y} = ?`;const i=b.querySelector('#ma');i.value='';i.focus()};
const chk=()=>{const v=b.querySelector('#ma').value.trim();if(v==='')return;if(+v===ans){sc++;SFX.ok()}else SFX.bad();b.querySelector('#ms').textContent=sc;q()};
b.onclick=e=>{if(e.target.closest('[data-a]'))chk()};b.onkeydown=e=>{if(e.key==='Enter')chk()};
a.i(()=>{left--;b.querySelector('#mt').textContent=left;if(left<=0)a.end(sc,'أجبت '+sc+' إجابة صحيحة')},1000);q()}
function gOdd(b,a){let sc=0,left=30;const EP=[['🙂','🙃'],['😀','😃'],['🐶','🐕'],['🐱','🐈'],['🍎','🍏'],['🍊','🍋'],['🌕','🌝'],['⭐','🌟'],['❤️','🧡'],['💙','💜'],['🔺','🔻'],['🚗','🚙'],['🚕','🚖'],['🏠','🏡'],['🌞','☀️'],['🍇','🫐'],['🍓','🍒'],['🐭','🐹'],['🐻','🐨'],['🦊','🐺'],['🐸','🐢'],['🕐','🕑'],['🔔','🔕'],['📘','📗'],['🌷','🌹'],['🌲','🌳'],['🥕','🍠'],['🍩','🍪'],['⚽','🏀'],['🎾','🥎'],['😠','😡'],['😢','😭'],['😴','🥱'],['🙈','🙉'],['🐔','🐓'],['🦅','🦉'],['🐬','🐳'],['🍔','🌭'],['🔑','🗝️'],['🎈','🎃']],E=['star','memory','match','trophy','users','detect','quiz','number','react','clock','whack','score'];b.innerHTML='<div class="info"><span id="ot">30</span> ث · <span id="os">0</span></div><div class="grid5" id="og"></div>';
const rd=()=>{const pr=Math.random()<.65?EP[Math.random()*EP.length|0]:null,n=Math.min(6,3+(sc/4|0)),x=E[Math.random()*E.length|0],k=Math.random()*n*n|0,g=b.querySelector('#og'),styles=['transform:rotate(180deg)','transform:scaleX(-1)','filter:brightness(1.3)','opacity:.66','transform:scale(.88)','filter:contrast(1.6)','transform:rotate(90deg) scale(.94)'];g.style.setProperty('--n',n);g.innerHTML=Array.from({length:n*n},(_,i)=>`<button class="cell" data-a="${i===k?1:0}" style="${pr?'font-size:24px;':''}${!pr&&i===k?styles[Math.random()*styles.length|0]:''}">${pr?pr[i===k?1:0]:ic(x)}</button>`).join('')};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;if(t.dataset.a==='1'){sc++;SFX.ok();b.querySelector('#os').textContent=sc;rd()}else{SFX.bad();left=Math.max(1,left-2)}};
a.i(()=>{left--;b.querySelector('#ot').textContent=left;if(left<=0)a.end(sc,'وجدت '+sc+' اختلافًا')},1000);rd()}
function gTap(b,a){let n=0,left=10;b.innerHTML='<div class="info"><span id="tt">10</span> ث</div><div class="big" id="tn">0</div><button class="btn p bigbtn" data-a="1">اضغط!</button>';
b.onclick=e=>{if(!e.target.closest('[data-a]'))return;n++;b.querySelector('#tn').textContent=n;snd(400+n*3,.04)};
a.i(()=>{left--;b.querySelector('#tt').textContent=left;if(left<=0)a.end(n,'ضغطت '+n+' مرة ('+(n/10).toFixed(1)+' بالثانية)')},1000)}
function gGuess(b,a){const s=1+Math.random()*100|0;let k=0;b.innerHTML='<div class="info" id="gi">خمّن رقمًا من 1 إلى 100</div><input id="gn" inputmode="numeric" autocomplete="off"><button class="btn p" data-a="1">خمّن</button>';
const go=()=>{const i=b.querySelector('#gn'),v=+i.value;if(!Number.isInteger(v)||v<1||v>100){toast('أدخل رقمًا من 1 إلى 100','err');return}k++;i.value='';if(v===s)a.end(k,'أصبت الرقم '+s+' في '+k+' محاولة');else{SFX.tap();b.querySelector('#gi').textContent=(v<s?'أعلى':'أقل')+' - محاولات: '+k}};
b.onclick=e=>{if(e.target.closest('[data-a]'))go()};b.onkeydown=e=>{if(e.key==='Enter')go()}}
function gDice(b,a){let me=0,cp=0,r=0;b.innerHTML='<div class="info" id="di">5 جولات - ارمِ النرد</div><div class="big" id="dv">? × ?</div><button class="btn p" data-a="1">ارمِ النرد</button>';
b.onclick=e=>{if(!e.target.closest('[data-a]'))return;const x=1+Math.random()*6|0,y=1+Math.random()*6|0;r++;if(x>y)me++;else if(y>x)cp++;b.querySelector('#dv').textContent=x+' × '+y;b.querySelector('#di').textContent=`جولة ${r}/5 - أنت ${me} : ${cp}`;SFX.tap();if(r===5)a.end(me,me>cp?'فزت!':me<cp?'خسرت':'تعادلنا')}}
function gTyping(b,a){const ws=shuf(['مغامرة','تحدي','سرعة','أبطال','ذكاء','ماينكرافت','خادم','برمجة','قلعة','كنز','صاروخ','مستودع']).slice(0,5);let i=0,t0=0;
b.innerHTML='<div class="info" id="yi">كلمة 1/5</div><div class="big" id="yw"></div><input id="yt" autocomplete="off" placeholder="اكتب هنا">';const inp=b.querySelector('#yt');b.querySelector('#yw').textContent=ws[0];
b.oninput=()=>{if(!t0)t0=performance.now();if(inp.value.trim()===ws[i]){i++;inp.value='';SFX.ok();if(i===5){const s=(performance.now()-t0)/1000;a.end(+s.toFixed(1),'أنهيت الكلمات في '+s.toFixed(1)+' ث')}else{b.querySelector('#yw').textContent=ws[i];b.querySelector('#yi').textContent='كلمة '+(i+1)+'/5'}}}}
function gXO(b,a){let B=Array(9).fill(''),busy=false,over=false,last=-1;const L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const win=B=>{for(const [x,y,z] of L)if(B[x]&&B[x]===B[y]&&B[y]===B[z])return B[x];return B.includes('')?null:'d'};
const line=B=>L.find(([x,y,z])=>B[x]&&B[x]===B[y]&&B[y]===B[z]);
const mm=(B,p)=>{const w=win(B);if(w)return w==='O'?1:w==='X'?-1:0;let best=p==='O'?-2:2;for(let i=0;i<9;i++)if(!B[i]){B[i]=p;const v=mm(B,p==='O'?'X':'O');B[i]='';best=p==='O'?Math.max(best,v):Math.min(best,v)}return best};
const draw=()=>{const w=line(B)||[];b.innerHTML='<div class="info xin">'+(over?'خلصت الجولة':busy?'دور الكمبيوتر…':'دورك - أنت <b class="xmx">X</b> والكمبيوتر <b class="xmo">O</b>')+'</div><div class="xob">'+B.map((v,i)=>'<button class="xc'+(w.includes(i)?' xw':'')+'" data-a="'+i+'">'+(v?'<span class="xm '+(v==='X'?'xmx':'xmo')+(i===last?' pop':'')+'">'+v+'</span>':'')+'</button>').join('')+'</div>'};
const fin=()=>{const w=win(B);if(!w)return false;busy=true;over=true;draw();a.t(()=>a.end(w==='X'?1:0,w==='X'?'فزت!':w==='O'?'الكمبيوتر غلبك':'تعادلنا'),w==='d'?500:1000);return true};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t||busy)return;const i=+t.dataset.a;if(B[i])return;B[i]='X';last=i;SFX.tap();if(fin())return;busy=true;draw();
a.t(()=>{const free=B.map((v,k)=>v?-1:k).filter(k=>k>=0);let m=free[Math.random()*free.length|0];if(Math.random()<XOP){let bv=-2;for(const k of free){B[k]='O';const v=mm(B,'X');B[k]='';if(v>bv){bv=v;m=k}}}B[m]='O';last=m;busy=false;draw();fin()},450)};draw()}
function gC4(b,a){const R=6,C=7;let G=Array.from({length:R},()=>Array(C).fill(0)),p=1,over=false;
const chk=(r,c)=>{for(const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]){let n=1;for(const s of [1,-1]){let y=r+dr*s,x=c+dc*s;while(G[y]&&G[y][x]===p){n++;y+=dr*s;x+=dc*s}}if(n>=4)return true}return false};
const col=v=>v===1?'#ff5a6e':v===2?'#ffd23f':'transparent';
const draw=()=>{b.innerHTML=`<div class="info">دور اللاعب <b style="color:${col(p)}">${p===1?'الأحمر':'الأصفر'}</b> (لاعبان على جهاز واحد)</div><div class="c4">`+G.map(r=>r.map((v,c)=>`<button class="c4c" data-a="${c}" style="--c:${col(v)}"></button>`).join('')).join('')+'</div>'};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t||over)return;const c=+t.dataset.a;let r=R-1;while(r>=0&&G[r][c])r--;if(r<0){toast('العمود ممتلئ','err');return}G[r][c]=p;SFX.tap();
if(chk(r,c)){over=true;draw();a.end(null,'فاز اللاعب '+(p===1?'الأحمر':'الأصفر')+'');return}if(G.every(x=>x.every(v=>v))){over=true;draw();a.end(null,'تعادلنا');return}p=3-p;draw()};draw()}
function gReact(b,a){let st=0,state=0,tm;b.innerHTML='<div class="info">اضغط الدائرة عندما تتحول للأخضر</div><button class="orb" id="ob" data-a="1">ابدأ</button>';const o=b.querySelector('#ob');
b.onclick=e=>{if(!e.target.closest('[data-a]'))return;if(state===0){state=1;o.textContent='انتظر…';o.className='orb wait';tm=a.t(()=>{state=2;st=performance.now();o.className='orb go';o.textContent='اضغط!'},1000+Math.random()*3000)}
else if(state===1){clearTimeout(tm);state=0;SFX.bad();o.className='orb';o.textContent='مبكر! أعد المحاولة'}else{const ms=Math.round(performance.now()-st);a.end(ms,'زمن استجابتك '+ms+' م.ث')}}}
function gMatch(b,a){const E=['star','users','trophy','react','flag','memory'];const D=shuf([...E,...E]);let open=[],found=0,mv=0,lock=false;
b.innerHTML='<div class="info" id="mm">حركات: 0</div><div class="grid4">'+D.map((e,i)=>`<button class="cell" data-a="${i}" data-e="${e}">${ic('quiz')}</button>`).join('')+'</div>';
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t||lock||t.classList.contains('ok')||open.includes(t))return;t.innerHTML=ic(t.dataset.e);t.classList.add('fl');open.push(t);SFX.tap();
if(open.length===2){mv++;b.querySelector('#mm').textContent='حركات: '+mv;const [x,y]=open;if(x.dataset.e===y.dataset.e){x.classList.add('ok');y.classList.add('ok');open=[];SFX.ok();if(++found===6)a.end(mv,'أنهيتها في '+mv+' حركة')}else{lock=true;a.t(()=>{x.innerHTML=y.innerHTML=ic('quiz');x.classList.remove('fl');y.classList.remove('fl');open=[];lock=false},700)}}}}
function gWhack(b,a){let sc=0,left=20;b.innerHTML='<div class="info"><span id="wt">20</span> ث · <span id="ws">0</span></div><div class="arena" id="ar"></div>';const ar=b.querySelector('#ar');
const sp=()=>{ar.innerHTML='';const t=document.createElement('button');t.className='tgt';t.innerHTML=ic('whack');t.style.left=Math.random()*80+'%';t.style.top=Math.random()*80+'%';t.dataset.a=1;ar.appendChild(t)};
b.onclick=e=>{if(e.target.closest('[data-a]')){sc++;SFX.ok();b.querySelector('#ws').textContent=sc;sp()}};
a.i(sp,1300);a.i(()=>{left--;b.querySelector('#wt').textContent=left;if(left<=0)a.end(sc,'أصبت '+sc+' هدفًا')},1000);sp()}
/* quiz engine (bank quiz + user-made games) */
function quizRun(b,a,qs,o={}){const time=o.time||15,pts=o.pts||10,names=o.names||['أنت'];let i=0,sc=names.map(()=>0),tm,left;
const show=()=>{const q=qs[i],p=i%names.length;left=time;b.innerHTML=`<div class="info">سؤال ${i+1}/${qs.length} · دور ${esc(names[p])} · <b id="qt">${left}</b> ث</div><div class="qq">${esc(q.q)}</div><div class="opts">`+q.a.map((x,k)=>`<button class="btn opt" data-a="${k}">${esc(x)}</button>`).join('')+`</div><div class="info">${names.map((n,k)=>esc(n)+': '+sc[k]).join(' · ')}</div>`;clearInterval(tm);tm=a.i(()=>{left--;const e=b.querySelector('#qt');if(e)e.textContent=left;if(left<=0){clearInterval(tm);SFX.end();ans(-1)}},1000)};
const ans=k=>{clearInterval(tm);const q=qs[i],p=i%names.length;if(k===q.c){sc[p]+=pts;SFX.ok()}else if(k>=0)SFX.bad();b.querySelectorAll('.opt').forEach((x,j)=>{x.disabled=true;if(j===q.c)x.classList.add('good');else if(j===k)x.classList.add('badc')});if(q.w)b.insertAdjacentHTML('beforeend','<div class="info">'+esc(q.w)+'</div>');a.t(()=>{if(++i>=qs.length)fin();else show()},1600)};
const fin=()=>{const m=Math.max(...sc),w=names.filter((n,k)=>sc[k]===m);a.end(names.length===1?sc[0]:m,names.length===1?`نتيجتك ${sc[0]} من ${qs.length*pts}`:(w.length>1?'تعادل بين '+w.join(' و ')+' ('+m+')':'الفائز: '+w[0]+' ('+m+' نقطة)'))};
b.onclick=e=>{const t=e.target.closest('.opt');if(t&&!t.disabled)ans(+t.dataset.a)};show()}
function pickQuestions(level,count){let pool=[...new Map(BANK.concat(genQs(80)).map(q=>[q.id,q])).values()].filter(q=>level==='مختلط'||q.level===level);if(!pool.length)pool=BANK.slice();const recent=new Set(S.qRecent||[]);let fresh=shuf(pool.filter(q=>!recent.has(q.id)));if(fresh.length<count)fresh=fresh.concat(shuf(pool.filter(q=>recent.has(q.id))));const out=fresh.slice(0,Math.min(count,pool.length));S.qRecent=[...out.map(q=>q.id),...(S.qRecent||[])].filter((x,i,ar)=>ar.indexOf(x)===i).slice(0,120);save();return out}
function gQuiz(b,a){b.innerHTML='<div class="info">اختر مستوى التحدي. الأسئلة تتغير وتُستبعد الأسئلة التي ظهرت مؤخرًا قدر الإمكان.</div><div class="opts"><button class="btn" data-level="سهل">سهل</button><button class="btn" data-level="متوسط">متوسط</button><button class="btn" data-level="صعب">صعب</button><button class="btn p" data-level="مختلط">مختلط</button></div><div class="lbl">السهل للمراجعة، المتوسط للتحدي، والصعب لأسئلة أعمق.</div>';b.onclick=e=>{const t=e.target.closest('[data-level]');if(!t)return;const level=t.dataset.level;const qs=pickQuestions(level,Math.min(10,BANK.filter(q=>level==='مختلط'||q.level===level).length));quizRun(b,a,qs,{time:level==='صعب'?25:20})}}

/* team games (local, one device) */
const FW=['قهوة:فنجان,مشروب,بن','سيارة:سواقة,عجلات,طريق','مدرسة:طلاب,معلم,كتاب','طيارة:سماء,مطار,جناح','بحر:ماء,موج,سباحة','هاتف:اتصال,جوال,شاشة','كرة:لعب,هدف,ملعب','مطعم:أكل,طاولة,قائمة','ساعة:وقت,عقارب,يد','مكتبة:كتب,قراءة,رفوف','قمر:ليل,سماء,نور','ثلج:بارد,شتاء,أبيض'];
function gForbid(b,a){let teams,sc=[0,0],turn=0,left,cards=shuf(FW),ci=0,iv;const R=6;
b.innerHTML='<div class="info">فريقان يتناوبان - 6 أدوار، 60 ثانية لكل دور. اشرح الكلمة دون ذكر الكلمات الممنوعة.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:2,max:2,teams:true,startBtn:b.querySelector('[data-a="go"]')});
const intro=()=>{b.innerHTML=`<div class="info">${esc(teams[0])} ${sc[0]} - ${sc[1]} ${esc(teams[1])}</div><div class="big sm">دور ${esc(teams[turn%2])}</div><div class="info">الشارح فقط ينظر للشاشة (دور ${turn+1}/${R})</div><button class="btn p" data-a="st">ابدأ الدور</button>`};
const card=()=>{const [w,x]=cards[ci%cards.length].split(':');b.innerHTML=`<div class="info"><b id="ft">${left}</b> ث · ${esc(teams[turn%2])}: ${sc[turn%2]}</div><div class="big">${esc(w)}</div><div class="info">ممنوع: ${x.split(',').map(esc).join(' · ')}</div><div class="row"><button class="btn good" data-a="ok">${ic('check')} صح</button><button class="btn" data-a="no">${ic('skip')} تخطي</button><button class="btn danger" data-a="bad">${ic('forbid')} مخالفة</button></div>`};
const tick=()=>{left--;const e=b.querySelector('#ft');if(e)e.textContent=left;if(left<=0){clearInterval(iv);SFX.end();turn++;if(turn>=R){const w=sc[0]===sc[1]?'تعادلنا':'الفائز: '+teams[sc[0]>sc[1]?0:1];a.end(Math.max(...sc),w+` (${sc[0]} - ${sc[1]})`)}else intro()}};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a;
if(k==='go'){teams=pp.get();intro()}
else if(k==='st'){left=60;card();iv=a.i(tick,1000)}
else{if(k==='ok'){sc[turn%2]++;SFX.ok()}else if(k==='bad'){sc[turn%2]--;SFX.bad()}ci++;card()}}}
const SW=[['حيوانات','جمل'],['حيوانات','حصان'],['حيوانات','ذئب'],['حيوانات','ثعلب'],['حيوانات','أرنب'],['حيوانات','قرد'],['حيوانات','فيل'],['حيوانات','زرافة'],['حيوانات','تمساح'],['حيوانات','نسر'],['حيوانات','صقر'],['حيوانات','بومة'],['حيوانات','ببغاء'],['حيوانات','دب'],['حيوانات','بطريق'],['حيوانات','فراشة'],['حيوانات','نحلة'],['حيوانات','عنكبوت'],['حيوانات','سلحفاة'],['حيوانات','ضفدع'],['حيوانات','كنغر'],['حيوانات','باندا'],['حيوانات','غزال'],['أماكن','مستشفى'],['أماكن','مكتبة'],['أماكن','مسجد'],['أماكن','سوق'],['أماكن','ملعب'],['أماكن','فندق'],['أماكن','شاطئ'],['أماكن','صحراء'],['أماكن','جامعة'],['أماكن','سينما'],['أماكن','متحف'],['أماكن','مطعم'],['أماكن','بنك'],['أماكن','مزرعة'],['أماكن','جزيرة'],['أماكن','غابة'],['أماكن','كهف'],['أماكن','برج'],['طعام','شاورما'],['طعام','فلافل'],['طعام','كباب'],['طعام','مطبق'],['طعام','جريش'],['طعام','سمبوسة'],['طعام','حمص'],['طعام','كنافة'],['طعام','تمر'],['طعام','عصيدة'],['طعام','مكرونة'],['طعام','سوشي'],['طعام','برجر'],['طعام','شوربة'],['طعام','سلطة'],['طعام','بسبوسة'],['طعام','آيس كريم'],['مهن','معلم'],['مهن','مهندس'],['مهن','شرطي'],['مهن','طباخ'],['مهن','محامي'],['مهن','نجار'],['مهن','خياط'],['مهن','فلاح'],['مهن','رسام'],['مهن','صحفي'],['مهن','ممرض'],['مهن','سائق'],['مهن','حلاق'],['مهن','ميكانيكي'],['مهن','مبرمج'],['مهن','قاضي'],['مهن','رائد فضاء'],['مهن','إطفائي'],['رياضة','تنس'],['رياضة','كرة طائرة'],['رياضة','جري'],['رياضة','ملاكمة'],['رياضة','مصارعة'],['رياضة','غولف'],['رياضة','بلياردو'],['رياضة','فروسية'],['رياضة','رماية'],['رياضة','تزلج'],['رياضة','سباق خيل'],['رياضة','كرة يد'],['رياضة','جودو'],['أشياء','مفتاح'],['أشياء','ساعة'],['أشياء','مظلة'],['أشياء','نظارة'],['أشياء','مرآة'],['أشياء','شنطة'],['أشياء','كرسي'],['أشياء','سرير'],['أشياء','مروحة'],['أشياء','ثلاجة'],['أشياء','تلفاز'],['أشياء','مقص'],['أشياء','مطرقة'],['أشياء','شمعة'],['أشياء','وسادة'],['أشياء','سجادة'],['أشياء','فرشاة'],['ملابس','ثوب'],['ملابس','شماغ'],['ملابس','غترة'],['ملابس','عباءة'],['ملابس','حذاء'],['ملابس','جزمة'],['ملابس','قبعة'],['ملابس','جاكيت'],['ملابس','قميص'],['ملابس','بنطلون'],['دول','اليابان'],['دول','البرازيل'],['دول','المغرب'],['دول','تركيا'],['دول','فرنسا'],['دول','الهند'],['دول','كندا'],['دول','إيطاليا'],['دول','الأردن'],['مدن','جدة'],['مدن','الدمام'],['مدن','أبها'],['مدن','تبوك'],['مدن','الطائف'],['مدن','نيوم'],['مدن','العلا'],['مدن','بريدة'],['مدن','جازان'],['مدن','الخبر'],['مشروبات','عصير'],['مشروبات','حليب'],['مشروبات','قهوة عربية'],['مشروبات','كابتشينو'],['مشروبات','شاي أخضر'],['مشروبات','ليمون بنعناع'],['طبيعة','مطر'],['طبيعة','برق'],['طبيعة','رعد'],['طبيعة','ثلج'],['طبيعة','ضباب'],['طبيعة','بركان'],['طبيعة','زلزال'],['طبيعة','شلال'],['طبيعة','واحة'],['طبيعة','جبل'],['تقنية','واي فاي'],['تقنية','بلوتوث'],['تقنية','سماعة'],['تقنية','كاميرا'],['تقنية','لابتوب'],['تقنية','ماوس'],['تقنية','شاحن'],['تقنية','بطارية'],['حيوانات','أسد'],['حيوانات','دلفين'],['أماكن','مطار'],['أماكن','حديقة'],['طعام','بيتزا'],['طعام','كبسة'],['مهن','طبيب'],['مهن','طيار'],['رياضة','سباحة'],['رياضة','كرة قدم']];
function gSab(b,a){let ps,sab,w,i=0;b.innerHTML='<div class="info">3 إلى 8 لاعبين - جهاز واحد يُمرَّر بينكم. واحد منكم مخرب لا يعرف الكلمة!</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:3,max:8,startBtn:b.querySelector('[data-a="go"]')});
const ask=()=>{b.innerHTML=`<div class="info">مرّر الجهاز إلى</div><div class="big sm">${esc(ps[i])}</div><button class="btn p" data-a="show">اضغط لرؤية دورك</button>`};
const disc=()=>{b.innerHTML='<div class="info">كل لاعب يقول كلمة واحدة تلمّح للكلمة، ثم صوّتوا على المخرب - <b id="dt">120</b> ث</div><div class="opts">'+ps.map((p,k)=>`<button class="btn opt" data-a="vote" data-v="${k}">${esc(p)}</button>`).join('')+'</div>';let l=120;a.i(()=>{l--;const e=b.querySelector('#dt');if(e)e.textContent=Math.max(l,0);if(l===0)SFX.end()},1000)};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a;
if(k==='go'){ps=pp.get();if(ps.length<3){toast('أدخل 3 لاعبين على الأقل','err');return}w=amsPick(SW,'sab');sab=Math.random()*ps.length|0;i=0;ask()}
else if(k==='show'){b.innerHTML=`<div class="big sm">${i===sab?'أنت المخرب!':esc(w[1])}</div><div class="info">الفئة: ${esc(w[0])}${i===sab?' - لا تعرف الكلمة، حاول ألا تُكتشف':''}</div><button class="btn p" data-a="hide">أخفِ ومرّر</button>`}
else if(k==='hide'){i++;i<ps.length?ask():disc()}
else if(k==='vote'){const v=+t.dataset.v;a.end(v===sab?1:0,v===sab?`أمسكتم المخرب (${ps[sab]})! فاز الفريق`:`أخطأتم! المخرب كان ${ps[sab]} وفاز`)}}}
function gScore(b,a){const sb=sbGet();let ed=null,showSet=false;const CL=['#a66cff','#ff5a6e','#3dd6c6','#ffd23f','#4aa8ff','#ff9f43','#7bd957','#e87bd2'];
const M=()=>sb.m[sb.mode],fmt=t=>new Date(t).toLocaleTimeString('ar',{hour:'2-digit',minute:'2-digit'});
const draw=()=>{const m=M(),T=m.teams;if(m.sel>=T.length)m.sel=0;const rk=T.map((t,i)=>({s:t.s,i})).sort((x,y)=>y.s-x.s);
const card=(t,i)=>{const r=rk.findIndex(x=>x.i===i)+1;let top,ex='';
top=ed&&ed.i===i&&ed.k==='n'?`<div class="row"><input data-e="n" value="${esc(t.n)}" maxlength="20"><button class="btn p" data-a="ok">${ic('check')}</button></div>`:`<button class="th2" data-a="sel" data-v="${i}"><span class="rk">${r}</span><span>${esc(t.n)}</span></button>`;
if(ed&&ed.i===i&&ed.k==='s')ex=`<div class="row"><input data-e="s" type="number" inputmode="numeric" value="${t.s}"><button class="btn p" data-a="ok">${ic('check')}</button></div>`;
return `<div class="team ${i===m.sel?'sel':''}" style="--tc:${CL[i%CL.length]}">${top}<b>${t.s}</b><div class="mini"><button class="ib" data-a="en" data-v="${i}" aria-label="تغيير الاسم">${ic('edit')}</button><button class="ib" data-a="es" data-v="${i}" aria-label="تعديل النقاط">${ic('score')}</button>${T.length>2?`<button class="ib" data-a="dt" data-v="${i}" aria-label="حذف الفريق">${ic('trash')}</button>`:''}</div>${ex}</div>`};
const btns=sg=>m.b.map((x,i)=>`<button class="btn ${sg>0?'good':'danger'} sbb" data-a="${sg>0?'add':'sub'}" data-v="${i}">${sg>0?'+':'−'}${x.v}<small>${sg>0?'إضافة':'خصم'} · ${esc(x.n)}${x.once?' · مرة':''}</small></button>`).join('');
const rr=(S.rounds||[]).filter(x=>x.mode===sb.mode).slice(0,5);
b.innerHTML=`<div class="sbw"><div class="row">${Object.keys(SBD).map(k=>`<button class="btn ${k===sb.mode?'p':''}" data-a="mode" data-v="${k}">${k}</button>`).join('')}</div>
<div class="teams">${T.map(card).join('')}</div>
<div class="info">الفريق المحدد: <b>${esc(T[m.sel].n)}</b>${m.limit?` · حد الفوز ${m.limit}`:''}</div>
<div class="sbg">${btns(1)}</div><div class="sbg">${btns(-1)}</div>
<div class="row"><button class="btn" data-a="addt">${ic('plus')} فريق</button><button class="btn" data-a="undo">${ic('undo')} تراجع</button><button class="btn" data-a="set">${ic('gear')} إعدادات</button><button class="btn danger" data-a="rst">${ic('reset')} تصفير النقاط</button><button class="btn p" data-a="fin">${ic('flag')} إنهاء الجولة</button></div>
${showSet?`<div class="card"><b>إعدادات وضع ${sb.mode}</b>${m.b.map((x,i)=>`<div class="row"><input data-s="n" data-i="${i}" value="${esc(x.n)}" maxlength="14"><input data-s="v" data-i="${i}" type="number" inputmode="numeric" value="${x.v}"><button class="ib" data-a="db" data-v="${i}">${ic('trash')}</button></div>`).join('')}<button class="btn" data-a="ab" style="width:100%">${ic('plus')} زر نقاط</button><div class="row2"><div><div class="lbl">حد الفوز (0 = بدون)</div><input data-s="limit" type="number" inputmode="numeric" value="${m.limit}"></div><div><div class="lbl">أقصى عدد فرق</div><input data-s="max" type="number" inputmode="numeric" value="${m.max}"></div></div></div>`:''}
<div class="card"><b>سجل العمليات</b><div class="log">${m.hist.slice(-8).reverse().map(x=>`${fmt(x.t)} · ${esc(x.nm)}: ${x.d>0?'+':''}${x.d}${x.n?' ('+esc(x.n)+')':''}`).join('<br>')||'لا عمليات بعد'}</div></div>
${rr.length?`<div class="card"><b>الجولات السابقة</b><div class="log">${rr.map(x=>fmt(x.at)+' · '+esc(x.rank[0].n)+' '+x.rank[0].s+(x.rank[1]?' مقابل '+esc(x.rank[1].n)+' '+x.rank[1].s:'')).join('<br>')}</div></div>`:''}</div>`};
const apply=(bi,sg)=>{const m=M(),bt=m.b[bi],t=m.teams[m.sel];if(!bt||!t)return;const d=sg*bt.v,en={i:m.sel,d,n:bt.n,nm:t.n,t:Date.now()};
if(bt.once){if(sg>0){if(m.used!=null){toast('هذه القطعة سُجّلت مرة في هذه الجولة','err');return}m.used=m.sel;en.red=1}else{if(m.used!==m.sel){toast('هذه القطعة غير مسجّلة لهذا الفريق','err');return}m.used=null;en.redOff=1}}
t.s+=d;m.hist.push(en);if(m.hist.length>200)m.hist.shift();SFX.tap();if(m.limit>0&&d>0&&t.s>=m.limit)toast(t.n+' وصل إلى حد الفوز ('+m.limit+')')};
b.oninput=e=>{const x=e.target,m=M();if(x.dataset.s==null)return;const k=x.dataset.s,i=+x.dataset.i,v=Math.trunc(+x.value);
if(k==='n'&&m.b[i])m.b[i].n=x.value.slice(0,14);else if(k==='v'&&m.b[i]&&Number.isFinite(v)&&Math.abs(v)<=9999)m.b[i].v=v;else if(k==='limit'&&v>=0&&v<=99999)m.limit=v;else if(k==='max'&&v>=2&&v<=12)m.max=v;save()};
b.onclick=async e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a,v=t.dataset.v,m=M();
if(k==='mode'){sb.mode=v;ed=null}else if(k==='sel')m.sel=+v;
else if(k==='add')apply(+v,1);else if(k==='sub')apply(+v,-1);
else if(k==='en')ed={i:+v,k:'n'};else if(k==='es')ed={i:+v,k:'s'};
else if(k==='ok'&&ed){const inp=b.querySelector('[data-e]'),tm=m.teams[ed.i];if(inp&&tm){if(ed.k==='n'){const n=inp.value.trim().slice(0,20);if(!n){toast('الاسم فارغ','err');return}tm.n=n}else{const n=Math.trunc(+inp.value);if(!Number.isFinite(n)||Math.abs(n)>999999||inp.value.trim()===''){toast('أدخل رقمًا صحيحًا','err');return}if(n!==tm.s){m.hist.push({i:ed.i,d:n-tm.s,n:'تعديل يدوي',nm:tm.n,t:Date.now()});tm.s=n}}}ed=null}
else if(k==='dt'){if(!(await cfm('حذف هذا الفريق?')))return;const i=+v;m.teams.splice(i,1);m.hist=m.hist.filter(h=>h.i!==i).map(h=>Object.assign({},h,{i:h.i>i?h.i-1:h.i}));if(m.used===i)m.used=null;else if(m.used>i)m.used--;if(m.sel>=m.teams.length)m.sel=0;ed=null}
else if(k==='addt'){if(m.teams.length<m.max)m.teams.push({n:'الفريق '+(m.teams.length+1),s:0});else toast('بلغت الحد الأقصى للفرق ('+m.max+') - غيّره من الإعدادات','err')}
else if(k==='undo'){const x=m.hist.pop();if(!x){toast('لا توجد عمليات للتراجع','err');return}const tm=m.teams[x.i];if(tm)tm.s-=x.d;if(x.red)m.used=null;if(x.redOff)m.used=x.i;SFX.tap()}
else if(k==='set')showSet=!showSet;
else if(k==='ab'){if(m.b.length<8)m.b.push({n:'زر '+(m.b.length+1),v:1});else toast('الحد 8 أزرار','err')}
else if(k==='db'){if(m.b.length>1)m.b.splice(+v,1);else toast('يجب بقاء زر واحد','err')}
else if(k==='rst'){if(!(await cfm('إعادة ضبط نقاط هذا الوضع?')))return;m.teams.forEach(x=>x.s=0);m.hist=[];m.used=null;toast('تم تصفير النقاط بنجاح')}
else if(k==='fin'){const rk=[...m.teams].sort((x,y)=>y.s-x.s);if(!m.hist.length&&rk.every(x=>x.s===0)){toast('لا توجد نتائج لإنهائها','err');return}if(!(await cfm('إنهاء الجولة وإعلان النتيجة?')))return;const top=rk.filter(x=>x.s===rk[0].s);const snap=rk.map(x=>({n:x.n,s:x.s})),msg=(top.length>1?'تعادل بين '+top.map(x=>x.n).join(' و '):'الفائز: '+top[0].n)+' - '+snap.map((x,i)=>(i+1)+'. '+x.n+' '+x.s).join(' · ');S.rounds=[{mode:sb.mode,at:Date.now(),rank:snap},...(S.rounds||[])].slice(0,50);m.teams.forEach(x=>x.s=0);m.hist=[];m.used=null;save();a.end(null,msg);return}
save();draw()};draw()}
const DT=[['الأهرامات','بناء ضخم قديم','في بلد عربي','شكله هرمي','عمره آلاف السنين','في الجيزة'],['القمر','يظهر ليلًا','يدور حول الأرض','يتغير شكله خلال الشهر','نزل عليه الإنسان عام 1969','تابع طبيعي'],['الكعبة','مبنى مكعب','وجهة ملايين المسلمين','كسوتها سوداء','في مكة المكرمة','نصلي باتجاهها'],['الذهب','معدن','لونه أصفر','ثمين جدًا','يُصاغ حليًا','رمزه Au'],['الهاتف','جهاز','في جيب أغلب الناس','له شاشة','نتصل به بالآخرين','محمول'],['الصقر','طائر','حاد البصر','يُستخدم في الصيد','رمز مشهور في الخليج','جارح']];
function gDetect(b,a){let ps,sc,R=0,items,k,p,dis,opts,it;b.innerHTML='<div class="info">تتكشف الأدلة تدريجيًا. خمّن الشيء بأقل أدلة لتربح نقاطًا أكثر.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:2,max:8,startBtn:b.querySelector('[data-a="go"]')});
const scr=()=>{b.innerHTML=`<div class="info">جولة ${R+1}/${items.length} · الدور: <b>${esc(ps[p])}</b></div><div class="info">${ps.map((n,i)=>esc(n)+' '+sc[i]).join(' · ')}</div><div class="card sbw">${it.slice(1,k+1).map((c,i)=>`<div class="ln"><span>دليل ${i+1}</span><span>${esc(c)}</span></div>`).join('')}</div><div class="opts">${opts.map((o,i)=>`<button class="btn opt" data-a="g" data-v="${i}" ${dis.has(i)?'disabled':''}>${esc(o)}</button>`).join('')}</div><button class="btn" data-a="more" ${k>=5?'disabled':''}>${ic('plus')} دليل إضافي وتمرير الدور</button><div class="info">الإجابة الصحيحة الآن تساوي ${6-k} نقاط، والخاطئة تخصم نقطة</div>`};
const nr=()=>{it=items[R];k=1;p=R%ps.length;dis=new Set();opts=shuf([it[0],...shuf(DT.filter(x=>x!==it)).slice(0,3).map(x=>x[0])]);scr()};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t||t.disabled)return;const x=t.dataset.a;
if(x==='go'){ps=pp.get();if(ps.length<2){toast('لاعبان على الأقل','err');return}sc=ps.map(()=>0);items=shuf(DT).slice(0,5);R=0;nr()}
else if(x==='g'){const i=+t.dataset.v;if(opts[i]===it[0]){sc[p]+=6-k;SFX.ok();toast('إجابة صحيحة: '+it[0]);if(++R>=items.length){const m=Math.max(...sc),w=ps.filter((n,j)=>sc[j]===m);a.end(m,(w.length>1?'تعادل بين '+w.join(' و '):'الفائز: '+w[0])+' ('+m+' نقطة)')}else nr()}else{sc[p]--;dis.add(i);SFX.bad();p=(p+1)%ps.length;scr()}}
else if(x==='more'&&k<5){k++;p=(p+1)%ps.length;scr()}}}
function gTrivia(b,a){b.innerHTML='<div class="info">لاعبون يتناوبون على الأسئلة. 10 نقاط لكل إجابة صحيحة.</div><div data-pp></div><div class="lbl">مستوى الأسئلة</div><select id="tl"><option>مختلط</option><option>سهل</option><option>متوسط</option><option>صعب</option></select><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:2,max:8,startBtn:b.querySelector('[data-a="go"]')});
b.onclick=e=>{if(!e.target.closest('[data-a]'))return;const ps=pp.get(),level=b.querySelector('#tl').value;if(ps.length<2){toast('لاعبان على الأقل','err');return}quizRun(b,a,pickQuestions(level,Math.min(12,BANK.filter(q=>level==='مختلط'||q.level===level).length)),{time:20,names:ps})}}
function gMost(b,a){let ps,round=0,sc=[],used=[];const qs=[
'من الأكثر احتمالًا أن يضحك في وقت غير مناسب?','من الأكثر احتمالًا أن ينسى أين وضع هاتفه?','من الأكثر احتمالًا أن يصبح مشهورًا?','من الأكثر احتمالًا أن ينجو في جزيرة?','من الأكثر احتمالًا أن يتأخر عن الموعد?','من الأكثر احتمالًا أن يحل لغزًا صعبًا?','من الأكثر احتمالًا أن ينام أثناء فيلم?','من الأكثر احتمالًا أن يفوز في مسابقة معلومات?','من الأكثر احتمالًا أن يخطط لرحلة مفاجئة?','من الأكثر احتمالًا أن يتذكر التفاصيل الصغيرة?','من الأكثر احتمالًا أن يخترع لعبة جديدة?','من الأكثر احتمالًا أن يربح تحدي سرعة?'];
b.innerHTML='<div class="info">أضيفوا اللاعبين، ثم يظهر سؤال تصويت في كل جولة. اختاروا اسمًا واحدًا وتناقشوا بالنتائج.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:3,max:12,startBtn:b.querySelector('[data-a="go"]')});
const draw=()=>{const q=qs[used[round]];b.innerHTML=`<div class="info">جولة ${round+1}/${used.length}</div><div class="qq">${q}</div><div class="opts">${ps.map((n,i)=>`<button class="btn opt" data-a="vote" data-v="${i}">${esc(n)} <span class="mu">${sc[i]}</span></button>`).join('')}</div><button class="btn" data-a="next">السؤال التالي</button>`};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;if(t.dataset.a==='go'){ps=pp.get();if(ps.length<3){toast('أدخل 3 لاعبين على الأقل','err');return}sc=ps.map(()=>0);used=shuf(qs.map((_,i)=>i)).slice(0,Math.min(8,qs.length));round=0;draw()}else if(t.dataset.a==='vote'){sc[+t.dataset.v]++;t.disabled=true;t.classList.add('good')}else if(t.dataset.a==='next'){if(round+1>=used.length){const mx=Math.max(...sc),w=ps.filter((_,i)=>sc[i]===mx);a.end(mx,(w.length>1?'تعادل: ':'الأكثر تصويتًا: ')+w.join(' و ')+` (${mx} تصويت)`)}else{round++;draw()}}}}
function gCategories(b,a){let ps,turn=0,sc=[],cat='',letter='',rounds=10,done=new Set(),timer=null,locked=false;const cats=['حيوان','دولة','أكلة','مهنة','شيء في المدرسة','شيء في البيت','اسم ولد','اسم بنت','شيء في المطبخ','رياضة','مدينة','نبات','شيء في البحر','شيء نلبسه','وسيلة نقل','شيء بارد','شيء نستخدمه يوميًا'];
const norm=v=>String(v||'').toLowerCase().normalize('NFD').replace(/[\u064B-\u065F\u0670]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/ة/g,'ه').replace(/ـ/g,'').replace(/[^\u0600-\u06FFa-z0-9]/g,'').trim();
const starts=(v)=>{let z=norm(v),l=norm(letter);if(z.startsWith('ال')&&z.length>2)z=z.slice(2);return z.startsWith(l)};
const finish=(earned,msg)=>{if(timer)clearInterval(timer);timer=null;locked=true;if(earned)sc[turn%ps.length]++;toast(msg,earned?'':'err');turn++;a.t(()=>next(),500)};
b.innerHTML='<div class="info">أضيفوا اللاعبين. الإجابة تُفحص بمرونة مع تجاهل «الـ» والتشكيل واختلافات الهمزة. وإذا كانت إجابتك صحيحة لكن النظام ما تعرف عليها، تقدر تحتسبها يدويًا.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:2,max:8,startBtn:b.querySelector('[data-a="go"]')});
const next=()=>{if(turn>=rounds){const mx=Math.max(...sc),w=ps.filter((_,i)=>sc[i]===mx);a.end(mx,(w.length>1?'تعادل بين ':'الفائز: ')+w.join(' و ')+` (${mx} نقطة)`);return}locked=false;cat=cats[Math.random()*cats.length|0];letter=['ا','ب','ت','ج','ح','خ','د','ر','س','ش','ع','ف','ك','ل','م','ن','ه','و'][Math.random()*18|0];let left=20;b.innerHTML=`<div class="info">جولة ${turn+1}/${rounds} · <span id="ct">20</span> ث</div><div class="big sm">${cat}</div><div class="qq">الحرف: ${letter==='ا'?'أ / إ / ا':letter}</div><div class="info">الدور: ${esc(ps[turn%ps.length])} · النقاط ${sc[turn%ps.length]}</div><input id="ca" placeholder="اكتب إجابتك" maxlength="40" autocomplete="off"><div class="row"><button class="btn p" data-a="send">تحقق</button><button class="btn good" data-a="accept">إجابة صحيحة +1</button><button class="btn" data-a="skip">تخطي</button></div><div class="info">«احتساب الإجابة» متاح لأن بعض الإجابات الصحيحة تعتمد على معنى الكلمة وليس الحروف فقط.</div>`;timer=a.i(()=>{if(locked)return;left--;const el=b.querySelector('#ct');if(el)el.textContent=left;if(left<=0){clearInterval(timer);timer=null;locked=true;turn++;next()}},1000);b.querySelector('#ca').focus()};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t||locked)return;const k=t.dataset.a;if(k==='go'){ps=pp.get();if(ps.length<2){toast('أدخل لاعبين على الأقل','err');return}sc=ps.map(()=>0);turn=0;done=new Set();next()}else if(k==='send'){const inp=b.querySelector('#ca'),v=inp.value.trim();if(!v){toast('اكتب إجابة أولًا','err');return}if(!starts(v)){toast('الإجابة لا تبدأ بالحرف المطلوب. راجع الحرف أو استخدم الاحتساب اليدوي إذا كانت صحيحة.','err');return}const key=cat+'|'+norm(v);if(done.has(key)){toast('هذه الإجابة استُخدمت في هذه اللعبة','err');return}done.add(key);finish(true,'إجابة مقبولة +1')}else if(k==='accept'){const inp=b.querySelector('#ca'),v=inp.value.trim();if(!v){toast('اكتب الإجابة أولًا ثم احتسبها','err');return}const key=cat+'|'+norm(v);if(done.has(key)){toast('هذه الإجابة استُخدمت في هذه اللعبة','err');return}done.add(key);finish(true,'تم احتساب الإجابة +1')}else if(k==='skip')finish(false,'تم تخطي الدور')};}
function gSecretWord(b,a){let ps,spy,word,cat,idx=0,words=[['فواكه','تفاح','برتقال'],['خضار','خيار','جزر'],['حلويات','كنافة','بسبوسة'],['وجبات','غداء','عشاء'],['ألوان','أحمر','وردي'],['ملابس','ثوب','قميص'],['بيت','غرفة','صالة'],['مطبخ','ملعقة','سكين'],['سفر','مطار','فندق'],['طقس','مطر','غيم'],['بحر','سمكة','قرش'],['صحراء','جمل','كثيب'],['مدينة','شارع','حي'],['مستشفى','دواء','عملية'],['سوق','تاجر','زبون'],['تقنية','جوال','تابلت'],['برمجة','تطبيق','موقع'],['موسيقى','عود','بيانو'],['سينما','فيلم','مسلسل'],['كرة','هدف','ركلة'],['سيارات','بنزين','إطار'],['حدائق','شجرة','ورد'],['عائلة','أب','أم'],['مدرسة2','معلم','مدير'],['وقت','ساعة','دقيقة'],['بنك','راتب','قرض'],['شرطة','دورية','مخالفة'],['رحلات','خيمة','نار'],['قهوة','دلة','فنجان'],['عيد','عيدية','ملابس جديدة'],['طعام','مندي','كبسة'],['رياضة','كرة قدم','كرة سلة'],['أماكن','مكة','المدينة'],['أجهزة','حاسوب','هاتف'],['حيوانات','أسد','نمر'],['مواصلات','قطار','مترو'],['مشروبات','قهوة','شاي'],['ألعاب','شطرنج','دومينو'],['فضاء','كوكب','قمر'],['طبيعة','جبل','وادي'],['مدرسة','اختبار','واجب'],['مهن','طبيب','ممرض']];
b.innerHTML='<div class="info">لعبة جماعية شبيهة بالمخرب: الجميع يعرف الكلمة نفسها تقريبًا، ولاعب واحد تصله كلمة قريبة. أعطوا تلميحات وصوّتوا.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:3,max:12,startBtn:b.querySelector('[data-a="go"]')});
const ask=()=>{b.innerHTML=`<div class="info">مرّر الجهاز إلى</div><div class="big sm">${esc(ps[idx])}</div><button class="btn p" data-a="show">اعرض دوري</button>`};
const vote=()=>{b.innerHTML=`<div class="qq">قولوا تلميحًا لكل لاعب، ثم اختاروا من تعتقدون أنه صاحب الكلمة المختلفة.</div><div class="opts">${ps.map((n,i)=>`<button class="btn opt" data-a="vote" data-v="${i}">${esc(n)}</button>`).join('')}</div><button class="btn" data-a="reveal">كشف الكلمات</button>`};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a;if(k==='go'){ps=pp.get();if(ps.length<3){toast('أدخل 3 لاعبين على الأقل','err');return}const row=amsPick(words,'sw');window.__rw=row;cat=row[0];word=row[1];spy=Math.random()*ps.length|0;idx=0;ask()}else if(k==='show'){b.innerHTML=`<div class="big sm">${idx===spy?esc((window.__rw||words.find(x=>x[0]===cat))[2]):esc(word)}</div><div class="info">الفئة: ${esc(cat)} - احفظ كلمتك ولا تُظهرها للآخرين.</div><button class="btn p" data-a="hide">إخفاء وتمرير</button>`}else if(k==='hide'){idx++;idx<ps.length?ask():vote()}else if(k==='vote'){a.end(null,`تم التصويت على ${ps[+t.dataset.v]}. الكلمة الأساسية: ${word}، والكلمة المختلفة: ${(window.__rw||words.find(x=>x[0]===cat))[2]}. المخرب كان ${ps[spy]}.`)}else if(k==='reveal'){a.end(null,`الكلمة الأساسية: ${word}، الكلمة المختلفة: ${(window.__rw||words.find(x=>x[0]===cat))[2]}، صاحبها: ${ps[spy]}.`)}}}
function gWhoAmI(b,a){let ps,idx=0,person='',clues=[],used=[];const bank=[['مصر','دولة في أفريقيا','لها نهر مشهور','عاصمتها القاهرة'],['القمر','جرم سماوي','يدور حول الأرض','نراه ليلًا'],['الذهب','معدن ثمين','لونه أصفر غالبًا','رمزه الكيميائي Au'],['الحوت','حيوان بحري','يتنفس الهواء','من أكبر الحيوانات'],['الرياض','مدينة','عاصمة السعودية','تقع في نجد'],['الإنترنت','شبكة عالمية','تربط الأجهزة','تُستخدم للمعلومات والتواصل'],['الشطرنج','لعبة استراتيجية','تُستخدم فيها قطع','هدفها كش ملك'],['البوصلة','أداة','تساعد في تحديد الاتجاه','تشير إلى الشمال المغناطيسي']];
b.innerHTML='<div class="info">خمنوا الشيء من الأدلة، ويتناوب اللاعبون. كلما احتجتم أدلة أكثر قلت النقاط.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:2,max:8,startBtn:b.querySelector('[data-a="go"]')});
const draw=()=>{b.innerHTML=`<div class="info">الدور: ${esc(ps[idx%ps.length])} · الجولة ${used.length+1}/${bank.length}</div><div class="card">${clues.map((c,i)=>`<div class="ln"><span>دليل ${i+1}</span><span>${esc(c)}</span></div>`).join('')||'ابدأ بأول دليل'}</div><input id="wg" placeholder="ما الإجابة?"><div class="row"><button class="btn p" data-a="guess">تخمين</button><button class="btn" data-a="hint">دليل إضافي</button><button class="btn" data-a="pass">تمرير الدور</button></div>`};
const next=()=>{if(used.length>=bank.length){a.end(null,'انتهت جولات التخمين');return}const available=bank.map((_,i)=>i).filter(i=>!used.includes(i));if(!available.length){a.end(null,'انتهت جولات التخمين');return}person=bank[available[Math.random()*available.length|0]];clues=[];idx=used.length;draw()};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;if(t.dataset.a==='go'){ps=pp.get();if(ps.length<2){toast('أدخل لاعبين على الأقل','err');return}used=[];next()}else if(t.dataset.a==='hint'){if(clues.length<3)clues.push(person[clues.length+1]);draw()}else if(t.dataset.a==='guess'){const v=b.querySelector('#wg').value.trim();if(v.toLowerCase()===person[0].toLowerCase()){used.push(bank.indexOf(person));toast('إجابة صحيحة: '+person[0]);next()}else{toast('ليست الإجابة الصحيحة','err');idx++;draw()}}else if(t.dataset.a==='pass'){used.push(bank.indexOf(person));next()}}}
function gWordChain(b,a){let ps=[],turn=0,sc=[],used=new Set(),last='',timer=null,locked=false;const clean=v=>String(v||'').toLowerCase().normalize('NFD').replace(/[\u064B-\u065F\u0670]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[^\u0600-\u06FF]/g,'');const first=v=>{const x=clean(v);return x[0]||''};const lastChar=v=>{const x=clean(v);return x[x.length-1]||''};
b.innerHTML='<div class="info">لعبة جماعية: اكتب كلمة تبدأ بآخر حرف من الكلمة السابقة. ممنوع تكرار الكلمات، ولكل لاعب 12 ثانية.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:2,max:8,startBtn:b.querySelector('[data-a="go"]')});
const next=()=>{if(turn>=ps.length*5){const mx=Math.max(...sc),w=ps.filter((_,i)=>sc[i]===mx);a.end(mx,(w.length>1?'تعادل بين ':'الفائز: ')+w.join(' و ')+` (${mx} نقطة)`);return}locked=false;let left=12;b.innerHTML=`<div class="info">الدور ${turn+1} · ${esc(ps[turn%ps.length])} · النقاط ${sc[turn%ps.length]}</div><div class="big sm">${last?`الحرف المطلوب: ${esc(last)}`:'ابدأ بأي كلمة'}</div><div class="info" id="wct">${left} ثانية</div><input id="wc" maxlength="32" placeholder="اكتب كلمة" autocomplete="off"><div class="row"><button class="btn p" data-a="send">اعتماد الكلمة</button><button class="btn" data-a="pass">تمرير</button></div><div class="card">آخر الكلمات: ${[...used].slice(-8).map(esc).join(' · ')||'لا توجد بعد'}</div>`;timer=a.i(()=>{if(locked)return;left--;const el=b.querySelector('#wct');if(el)el.textContent=left+' ثانية';if(left<=0){clearInterval(timer);timer=null;locked=true;turn++;next()}},1000);b.querySelector('#wc').focus()};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t||locked)return;if(t.dataset.a==='go'){ps=pp.get();if(ps.length<2){toast('أدخل لاعبين على الأقل','err');return}turn=0;sc=ps.map(()=>0);used=new Set();last='';next()}else if(t.dataset.a==='send'){const v=b.querySelector('#wc').value.trim(),n=clean(v);if(n.length<2){toast('اكتب كلمة من حرفين أو أكثر','err');return}if(last&&first(v)!==last){toast('الكلمة لازم تبدأ بحرف '+last,'err');return}if(used.has(n)){toast('هذه الكلمة مستخدمة مسبقًا','err');return}used.add(n);last=lastChar(v);sc[turn%ps.length]++;if(timer)clearInterval(timer);timer=null;locked=true;SFX.ok();turn++;next()}else if(t.dataset.a==='pass'){if(timer)clearInterval(timer);timer=null;locked=true;turn++;next()}}}
function gTruth(b,a){const Q=[['الأخطبوط لديه ثلاثة قلوب',true],['الصوت ينتقل في الفراغ',false],['البرق أسخن من سطح الشمس لحظيًا',true],['الخفاش أعمى تمامًا',false],['كوكب الزهرة أسخن من عطارد غالبًا',true],['جميع الثدييات تلد صغارًا أحياء',false],['الماء النقي يغلي عند 100 درجة مئوية عند ضغط جوي واحد',true],['الإنسان يستخدم 10% فقط من دماغه',false],['الضوء أسرع من الصوت',true],['الذهب يصدأ مثل الحديد بسهولة',false],['العسل يمكن أن يبقى صالحًا مدة طويلة جدًا إذا خُزّن جيدًا',true],['القمر يصدر ضوءه من نفسه',false],['النعامة تستطيع الطيران',false],['المشتري أكبر كواكب المجموعة الشمسية',true],['كل الزلازل تحدث عند حدود الصفائح فقط',false]];let ps=[],turn=0,sc=[],items=[];
b.innerHTML='<div class="info">كل لاعب يقرر: حقيقة أم خدعة? الإجابة الصحيحة +10، والخاطئة −5.</div><div data-pp></div><button class="btn p" data-a="go">ابدأ</button>';const pp=playerPicker(b.querySelector('[data-pp]'),{min:2,max:8,startBtn:b.querySelector('[data-a="go"]')});
const draw=()=>{if(turn>=items.length){const mx=Math.max(...sc),w=ps.filter((_,i)=>sc[i]===mx);a.end(mx,(w.length>1?'تعادل بين ':'الفائز: ')+w.join(' و ')+` (${mx} نقطة)`);return}const q=items[turn],p=turn%ps.length;b.innerHTML=`<div class="info">سؤال ${turn+1}/${items.length} · دور ${esc(ps[p])} · النقاط ${sc[p]}</div><div class="qq">${q[0]}</div><div class="row"><button class="btn good" data-a="true">حقيقة</button><button class="btn danger" data-a="false">خدعة</button></div>`};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;if(t.dataset.a==='go'){ps=pp.get();if(ps.length<2){toast('أدخل لاعبين على الأقل','err');return}sc=ps.map(()=>0);items=shuf(Q).slice(0,Math.min(10,Q.length));turn=0;draw()}else if(t.dataset.a==='true'||t.dataset.a==='false'){const p=turn%ps.length,ok=(t.dataset.a==='true')===items[turn][1];sc[p]+=ok?10:-5;toast(ok?'صحيح +10':'غير صحيح −5',ok?'':'err');turn++;SFX[ok?'ok':'bad']();draw()}}}

/* New playable games: visual-difference scenes, word scramble, mafia, category sprint */
function gDifferences(b,a){
 let round=0,found=new Set();
 const draw=()=>{
  found=new Set();
  const scene=(right)=>`<svg viewBox="0 0 300 180" style="width:100%;display:block;border-radius:12px;background:#bde8ff">
   <rect width="300" height="180" fill="#bde8ff"/><rect y="118" width="300" height="62" fill="#8acb75"/>
   <path d="M20 130 L55 55 L90 130Z" fill="#397b47"/><path d="M30 130 L55 75 L80 130Z" fill="#4b9658"/>
   <rect x="145" y="82" width="65" height="55" rx="3" fill="#d78b55"/><path d="M135 84 L178 48 L220 84Z" fill="#b64c42"/>
   <rect x="150" y="91" width="18" height="18" fill="${right?'#7bd7ff':'#fff0a8'}" stroke="#8b583d" stroke-width="3"/>
   <rect x="170" y="105" width="17" height="32" fill="${right?'#3c2b26':'#69412d'}"/>
   ${right?'<path d="M225 24q-10-12-20 0q-13 2-5 12h28q9-10-3-12Z" fill="#fff"/>':'<circle cx="245" cy="30" r="18" fill="#ffd34d"/>'}
   ${right?'':'<circle cx="70" cy="55" r="12" fill="#ff8fa3"/><path d="M70 67v30" stroke="#397b47" stroke-width="4"/>'}
   ${right?'':'<rect x="20" y="140" width="35" height="8" rx="3" fill="#8a593d"/><path d="M24 148v15M51 148v15" stroke="#60412e" stroke-width="4"/>'}
   <circle cx="112" cy="143" r="5" fill="#ffdf4d"/><circle cx="126" cy="154" r="4" fill="#fff"/>
   </svg>`;
  const spots=[{x:245,y:30},{x:70,y:55},{x:159,y:100},{x:38,y:145},{x:178,y:118}];
  const marks=spots.map((p,i)=>`<button data-diff="${i}" aria-label="Difference ${i+1}" style="position:absolute;left:${p.x/3}%;top:${p.y/1.8}%;width:13%;height:22%;border:2px solid transparent;border-radius:50%;background:transparent"></button>`).join('');
  b.innerHTML=`<div class="info">جولة ${round+1} · اكتشف 5 فروقات في المشهد الأيمن</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;width:100%"><div><div class="lbl">المشهد A</div>${scene(false)}</div><div><div class="lbl">المشهد B - اضغط على الفروقات</div><div style="position:relative">${scene(true)}${marks}</div></div></div><div class="info" id="dfcount">اكتُشف 0 من 5 · المتبقي 5</div><div class="info" id="dfmsg">ابحث عن تفاصيل مختلفة بين المشهدين.</div><button class="btn" data-diffnext="1">جولة جديدة</button>`;
 };
 b.onclick=e=>{const t=e.target.closest('[data-diff],[data-diffnext]');if(!t)return;if(t.hasAttribute('data-diffnext')){round++;draw();return}const n=+t.dataset.diff;if(found.has(n)){b.querySelector('#dfmsg').textContent='هذا الفرق محسوب بالفعل.';return}found.add(n);t.style.borderColor='#45ef91';t.style.background='#45ef9144';t.style.pointerEvents='none';b.querySelector('#dfcount').textContent=`اكتُشف ${found.size} من 5 · المتبقي ${5-found.size}`;b.querySelector('#dfmsg').textContent='صحيح! اكتشفت فرقًا.';SFX.ok();if(found.size===5){SFX.win();b.querySelector('#dfmsg').textContent='ممتاز! اكتشفت الفروقات الخمسة.';$('#gr').innerHTML='<div class="row"><button class="btn p" id="dfagain">إعادة الجولة</button><button class="btn" id="dfnext">المشهد التالي</button></div>';$('#dfagain').onclick=()=>{draw();$('#gr').innerHTML=''};$('#dfnext').onclick=()=>{round++;draw();$('#gr').innerHTML=''}}};draw()
}
const WORDS=[
 ['قلم','م ق ل'],['مدرسة','ة ر د م س'],['حديقة','ة ق ي د ح'],['برمجة','ج م ر ب ة'],['مغامرة','ة ر م ا غ م'],['تفاحة','ة ح ا ف ت'],['مكتبة','ة ب ت ك م'],['حاسوب','ب و س ا ح'],
 ['PLANET','T A N E P L'],['GARDEN','D A R G E N'],['PUZZLE','Z U P L E Z'],['POCKET','K C O P E T'],['ORANGE','G R A N O E'],['BRIDGE','G D R I B E'],['CASTLE','T S A C L E']
];
function gScramble(b,a){let round=0,score=0,word,answer;const draw=()=>{const pair=WORDS[Math.random()*WORDS.length|0];word=pair[0];answer=word.toLocaleLowerCase();let chars=[...word];do{chars=shuf(chars)}while(chars.join('')===word);b.innerHTML=`<div class="info">رتّب الأحرف لتكوين كلمة · النقاط ${score}</div><div class="big sm" style="letter-spacing:5px">${esc(chars.join(' '))}</div><input id="scrans" autocomplete="off" placeholder="اكتب الكلمة الصحيحة"><div class="row"><button class="btn p" data-scr="check">تحقق</button><button class="btn" data-scr="skip">تخطّ</button></div><div class="info" id="scrmsg">الجولة ${round+1}</div>`;b.querySelector('#scrans').focus()};b.onclick=e=>{const t=e.target.closest('[data-scr]');if(!t)return;if(t.dataset.scr==='skip'){round++;draw();return}const v=b.querySelector('#scrans').value.trim().toLocaleLowerCase();if(v===answer){score+=10;round++;SFX.ok();if(round>=10)a.end(score,`أكملت 10 كلمات · النقاط ${score}`);else draw()}else{SFX.bad();b.querySelector('#scrmsg').textContent='ليست الكلمة المطلوبة، جرّب مرة أخرى.'}};b.onkeydown=e=>{if(e.key==='Enter')b.querySelector('[data-scr="check"]').click()};draw()}
function gMafia(b,a){
 let ppM=null,players=[],roles={},alive=[],phase='setup',nightOrder=[],nightAt=0,killTarget=null,savedTarget=null,checkTarget=null,votes={},voterAt=0,round=1,tv=0,voteLeft=180;
 const roleNames={mafia:'المافيا',doctor:'الطبيب',elder:'الشايب',villager:'أهل القرية'};
 const say=(ar,en)=>LANG==='ar'?ar:en;
 const fmtT=n=>Math.floor(n/60)+':'+String(n%60).padStart(2,'0');
 const discuss=()=>{b.innerHTML=`<div class="big sm" id="mvt">${fmtT(voteLeft)}</div><div class="qq">${say('نقاش القرية','Village discussion')}</div><div class="info">${say('عندكم 3 دقائق للنقاش والتصويت. إذا انتهى الوقت يُحسب التصويت الحالي مباشرة.','You have 3 minutes to discuss and vote. When time runs out the votes so far are counted.')}</div><button class="btn p" data-maf="beginVote">${say('ابدأ التصويت السري','Start secret vote')}</button>`};
 const countM=()=>alive.filter(p=>roles[p]==='mafia').length;
 const checkWin=()=>{const m=countM(),v=alive.length-m;if(m===0)return 'village';if(m>=v)return 'mafia';return ''};
 const showWin=who=>{clearInterval(tv);phase='end';const win=who==='village'?say('فاز أهل القرية!','The village wins!'):say('فازت المافيا!','The Mafia wins!');b.innerHTML=`<div class="big">${ic(who==='village'?'home':'mask')}</div><div class="qq">${win}</div><div class="info">${say('الأدوار كانت:','Roles were:')}<br>${players.map(p=>`${esc(p)} - ${roleNames[roles[p]]}`).join('<br>')}</div><button class="btn p" data-maf="restart">${say('لعبة جديدة','New game')}</button>`};
 const drawSetup=()=>{phase='setup';b.innerHTML=`<div class="qq">${say('المافيا: أهل القرية ضد المافيا','Mafia: Village vs Mafia')}</div><div class="info">${say('أضف من 5 إلى 16 لاعبًا. كل لاعب يظهر كشريحة ويمكن حذفه.','Add 5–16 players. Each one appears as a chip you can remove.')}</div><div data-pp></div><div class="card"><b>${say('الأدوار','Roles')}</b><div class="info">${ic('home')} ${say('أهل القرية: يناقشون ويصوتون','Villagers: discuss and vote')}<br>${ic('mask')} ${say('المافيا: تختار هدفًا ليلًا','Mafia: choose a target at night')}<br>${ic('doctor')} ${say('الطبيب: ينقذ لاعبًا كل ليلة','Doctor: saves one player each night')}<br>${ic('elder')} ${say('الشايب: يفحص لاعبًا لمعرفة إن كان مافيا','Elder: checks whether a player is Mafia')}</div></div><button class="btn p" data-maf="start">${say('توزيع الأدوار سرًا','Deal secret roles')}</button>`;ppM=playerPicker(b.querySelector('[data-pp]'),{min:5,max:16,startBtn:b.querySelector('[data-maf="start"]')})};
 const passRole=(title,body,btn,action)=>{b.innerHTML=`<div class="big">${ic('lock')}</div><div class="qq">${title}</div><div class="info">${body}</div><button class="btn p" data-maf="${action}">${btn}</button>`};
 const revealNext=()=>{if(nightAt>=players.length){startNightActions();return}const p=players[nightAt];passRole(say('مرّر الجهاز إلى','Pass the device to')+' '+esc(p),say('لا أحد ينظر إلى الشاشة غير اللاعب الحالي.','Only the current player should look at the screen.'),say('اكشف دوري','Reveal my role'),'revealrole')};
 const startNightActions=()=>{phase='night';killTarget=null;savedTarget=null;checkTarget=null;nightOrder=['mafia','doctor','elder'].filter(r=>alive.some(p=>roles[p]===r));nightAt=0;nextNightRole()};
 const nextNightRole=()=>{if(nightAt>=nightOrder.length){morning();return}const role=nightOrder[nightAt];const actor=alive.find(p=>roles[p]===role);if(!actor){nightAt++;nextNightRole();return}passRole(say('الليل - مرّر الجهاز إلى','Night - pass the device to')+' '+esc(actor),say('تأكد أن الآخرين لا ينظرون.','Make sure nobody else is looking.'),say('أنا جاهز','I am ready'),'nightreveal')};
 const targetChoices=(role)=>{const actor=alive.find(p=>roles[p]===role);let targets=alive.filter(p=>role==='mafia'?roles[p]!=='mafia':p!==actor);if(role==='doctor')targets=alive;const title=role==='mafia'?say('المافيا: اختاروا هدفًا','Mafia: choose a target'):role==='doctor'?say('الطبيب: من تريد إنقاذه؟','Doctor: who will you save?'):say('الشايب: من تريد فحصه؟','Elder: who will you investigate?');b.innerHTML=`<div class="qq">${title}</div><div class="info">${say('اختيار سري - لا تكشفوا الاختيار للآخرين.','Secret choice - do not reveal it to others.')}</div><div class="opts">${targets.map(p=>`<button class="btn opt" data-maf="target" data-p="${esc(p)}">${esc(p)}</button>`).join('')}</div>`};
 const morning=()=>{phase='day';const out=killTarget&&killTarget!==savedTarget?killTarget:null;if(out)alive=alive.filter(p=>p!==out);const w=checkWin();if(w){showWin(w);return}b.innerHTML=`<div class="big">${ic('sun')}</div><div class="qq">${say('صباح القرية - الجولة ','Village morning - round ')}${round}</div><div class="info">${out?`${esc(out)} ${say('خرج من اللعبة خلال الليل.','was eliminated during the night.')}`:say('لم يخرج أحد هذه الليلة.','Nobody was eliminated tonight.')}<br>${say('اللاعبون الباقون:','Players remaining:')} ${alive.map(esc).join('، ')}</div><button class="btn p" data-maf="voteStart">${say('ابدأ النقاش والتصويت','Start discussion and vote')}</button>`};
 const votePass=()=>{if(voterAt>=alive.length){finishVote();return}const voter=alive[voterAt];b.innerHTML=`<div class="big sm" id="mvt" style="color:${voteLeft<=30?'#ff5a6e':''}">${fmtT(voteLeft)}</div><div class="qq">${say('وقت التصويت','Voting time')}</div><div class="info">${say('مرّر الجهاز إلى','Pass the device to')} <b>${esc(voter)}</b> - ${say('اختر الشخص الذي تشك فيه.','choose who you suspect.')}</div><div class="opts">${alive.filter(p=>p!==voter).map(p=>`<button class="btn opt" data-maf="vote" data-voter="${esc(voter)}" data-p="${esc(p)}">${esc(p)}</button>`).join('')}<button class="btn" data-maf="abstain" data-voter="${esc(voter)}">${say('امتناع','Abstain')}</button></div>`};
 const finishVote=()=>{clearInterval(tv);const entries=Object.entries(votes).sort((x,y)=>y[1]-x[1]);const top=entries[0];let out=null;if(top){const tied=entries.filter(x=>x[1]===top[1]);if(tied.length===1)out=top[0]}if(out)alive=alive.filter(p=>p!==out);const win=checkWin();if(win){showWin(win);return}b.innerHTML=`<div class="big">${ic('vote')}</div><div class="qq">${out?`${esc(out)} ${say('تم إقصاؤه.','was voted out.')}`:say('تعادل التصويت - لا إقصاء.','Vote tied - nobody is eliminated.')}</div><div class="info">${say('نتائج التصويت:','Vote results:')}<br>${Object.entries(votes).map(([p,n])=>`${esc(p)}: ${n}`).join('<br>')||say('لا أصوات','No votes')}</div><button class="btn p" data-maf="nextnight">${say('ابدأ الليل التالي','Start next night')}</button>`;};
 b.onclick=e=>{const t=e.target.closest('[data-maf]');if(!t)return;const k=t.dataset.maf;
 if(k==='start'){players=ppM.get();if(players.length<5||players.length>16){toast(say('أدخل من 5 إلى 16 لاعبًا بأسماء مختلفة','Enter 5–16 unique player names'),'err');return}roles={};alive=[...players];const deck=[];const m=players.length>=10?Math.max(2,Math.floor(players.length/4)):1;for(let i=0;i<m;i++)deck.push('mafia');deck.push('doctor','elder');while(deck.length<players.length)deck.push('villager');shuf(deck).forEach((r,i)=>roles[players[i]]=r);nightAt=0;revealNext();}
 else if(k==='revealrole'){const p=players[nightAt];b.innerHTML=`<div class="info">${esc(p)} - ${say('دورك السري','your secret role')}</div><div class="big sm">${ic(roles[p]==='mafia'?'mask':roles[p]==='doctor'?'doctor':roles[p]==='elder'?'elder':'home')} ${roleNames[roles[p]]}</div><div class="info">${roles[p]==='mafia'?say('حاول البقاء مخفيًا.','Stay undercover.'):roles[p]==='doctor'?say('اختر لاعبًا لتنقذه كل ليلة.','Choose one player to save each night.'):roles[p]==='elder'?say('افحص لاعبًا كل ليلة.','Investigate one player each night.'):say('ساعد القرية بكشف المافيا.','Help the village find the Mafia.')}</div><button class="btn p" data-maf="hideRole">${say('إخفاء وتمرير','Hide and pass')}</button>`}
 else if(k==='hideRole'){nightAt++;revealNext()}
 else if(k==='nightreveal'){const role=nightOrder[nightAt],actor=alive.find(p=>roles[p]===role);if(!actor){nightAt++;nextNightRole();return}if(role==='mafia'){targetChoices(role)}else if(role==='doctor'){targetChoices(role)}else{targetChoices(role)}}
 else if(k==='target'){const role=nightOrder[nightAt],p=t.dataset.p;if(role==='mafia')killTarget=p;else if(role==='doctor')savedTarget=p;else{checkTarget=p;const isM=roles[p]==='mafia';b.innerHTML=`<div class="qq">${say('نتيجة فحص الشايب','Elder investigation')}</div><div class="big">${ic(isM?'mask':'home')}</div><div class="info">${esc(p)} ${isM?say('من المافيا!','is Mafia!'):say('ليس من المافيا.','is not Mafia.')}</div><button class="btn p" data-maf="checkDone">${say('إخفاء النتيجة','Hide result')}</button>`;return}nightAt++;nextNightRole()}
 else if(k==='checkDone'){nightAt++;nextNightRole()}
 else if(k==='voteStart'){phase='vote';votes={};voterAt=0;voteLeft=180;clearInterval(tv);discuss();tv=a.i(()=>{voteLeft--;const e=b.querySelector('#mvt');if(e){e.textContent=fmtT(voteLeft);e.style.color=voteLeft<=30?'#ff5a6e':''}if(voteLeft<=10&&voteLeft>0)SFX.tick();if(voteLeft<=0){clearInterval(tv);SFX.end();toast(say('انتهى الوقت!','Time is up!'),'err');finishVote()}},1000)}
  else if(k==='beginVote'){votePass()}
 else if(k==='vote'||k==='abstain'){const voter=t.dataset.voter,p=t.dataset.p;if(p)votes[p]=(votes[p]||0)+1;voterAt++;votePass()}
 else if(k==='nextnight'){round++;startNightActions()}
 else if(k==='restart')drawSetup();
 };drawSetup()
}

/* ===== Majd / Carrom / Spot (v3) ===== */
const TT=(a,e)=>LANG==='en'?e:a;
const EN_X={majd:['Majd - Team Counter','Fast two-team scoring: ±10, history, undo and a safe reset.',null],carrom:['Carrom Scoreboard','Carrom scoring: red piece 50 (once per round), white 10, black 5.',null],differences:['Spot the Difference','Three picture stages: tap differences in either image, with hints and an optional timer.',null]};
async function cfmGear(m){const bx=$('#dlg .box'),g=document.createElement('div');g.className='gearspin';g.innerHTML=ic('gear');bx.prepend(g);try{return await cfm(m)}finally{g.remove()}}
const disc=(c,red)=>`<svg viewBox="0 0 40 40" class="dsc" aria-hidden="true"><circle cx="20" cy="20" r="18" fill="${c}" stroke="#fff5" stroke-width="1.5"/><circle cx="20" cy="20" r="12" fill="none" stroke="#fff6" stroke-width="1.4"/>${red?'<path d="M9 25c4-9 13-11 22-6-4-.3-6.500.8-8.500 3.600 2 .2 4 1.200 5.500 3.200-5.500-2.200-11-1.400-19-.8z" fill="#fff"/><circle cx="27" cy="19.500" r="1.100" fill="#b3122b"/>':'<circle cx="20" cy="20" r="4.500" fill="#fff5"/>'}</svg>`;
function scoreBoard(b,a,cfg){
 let st=S[cfg.key];if(!st||!Array.isArray(st.s)||!Array.isArray(st.log)||!Array.isArray(st.n)){st=S[cfg.key]=Object.assign({n:['',''],s:[0,0],log:[],neg:false},cfg.init||{});save()}
 const nm=i=>st.n[i]||TT(i?'الفريق الثاني':'الفريق الأول','Team '+(i+1)),TC=['#a66cff','#ffd36b'];let bump=-1;
 const draw=()=>{const L=st.s[0]===st.s[1]?-1:st.s[0]>st.s[1]?0:1;
  b.innerHTML=`<div class="sbx ${cfg.cls||''}">`+[0,1].map(i=>`<div class="tm ${L===i?'lead':''}" style="--tc:${TC[i]}">${L===i?`<span class="crn">${ic('crown')}</span>`:''}<input class="tn" data-n="${i}" maxlength="18" value="${esc(st.n[i])}" placeholder="${esc(nm(i))}" aria-label="${TT('اسم الفريق','Team name')}"><div class="tsc" id="sc${i}">${st.s[i]}</div><div class="tbs">${cfg.btns.map((x,j)=>{const u=x.once&&st[x.once];return `<button class="btn pb ${x.cls||''}" data-a="${i}:${j}" ${u?'disabled':''}>${x.icon||''}<span>${u?TT('مستخدمة','Used'):x.l()}</span></button>`}).join('')}</div></div>`).join('')+`</div>`+(cfg.status?cfg.status(st):'')+
  `<div class="row"><button class="btn" data-x="undo" ${st.log.length?'':'disabled'}>${ic('undo')} ${TT('تراجع','Undo')}</button>${cfg.round?`<button class="btn" data-x="round">${ic('flag')} ${TT('راوند جديد','New round')}</button>`:''}<button class="btn danger" data-x="reset">${ic('reset')} ${TT('إعادة ضبط','Reset')}</button></div>`+
  (cfg.neg?`<label class="mu"><input type="checkbox" data-x="neg" ${st.neg?'checked':''} style="width:auto;min-height:0"> ${TT('السماح بنتيجة سالبة','Allow negative scores')}</label>`:'')+
  `<div class="sbl"><b>${TT('السجل','History')}</b>${st.log.length?st.log.slice(0,8).map(e=>`<div class="ln"><span>${esc(nm(e.t))} · ${cfg.btns[e.j]?cfg.btns[e.j].l():''}</span><span class="${e.v<0?'neg':'pos'}">${e.v>0?'+':''}${e.v}</span></div>`).join(''):`<div class="mu">${TT('لا توجد عمليات بعد','No actions yet')}</div>`}</div>`;
  if(bump>=0){const el=b.querySelector('#sc'+bump);if(el)el.classList.add('bump');bump=-1}};
 b.onclick=async e=>{const t=e.target.closest('[data-a],[data-x]');if(!t||t.disabled)return;
  if(t.dataset.a){const [i,j]=t.dataset.a.split(':').map(Number),x=cfg.btns[j];if(x.once&&st[x.once]){SFX.bad();return}let v=x.v;if(v<0&&!(cfg.neg&&st.neg))v=-Math.min(st.s[i],-v);if(!v){SFX.bad();toast(TT('لا يمكن الخصم: النتيجة صفر','Cannot subtract: score is zero'),'err');return}
   st.s[i]+=v;if(x.once)st[x.once]=true;st.log.unshift({t:i,v,j});if(st.log.length>80)st.log.length=80;save();bump=i;if(x.snd)x.snd();else v>0?SFX.coin():SFX.sub();vib(10);if(x.fx)x.fx();draw();return}
  const k=t.dataset.x;
  if(k==='undo'){const z=st.log.shift();if(!z)return;st.s[z.t]-=z.v;const x=cfg.btns[z.j];if(x&&x.once)st[x.once]=false;save();bump=z.t;SFX.tap();draw()}
  else if(k==='round'){st.red=false;st.round=(st.round||1)+1;save();SFX.swoosh();toast(TT('راوند جديد - القطعة الحمراء متاحة','New round - red piece available'));draw()}
  else if(k==='reset'){if(await cfmGear(TT('سيتم تصفير نقاط الفريقين والسجل وإعادة الراوند. هل أنت متأكد؟','This will zero both teams, clear the history and restart the round. Continue?'))){st.s=[0,0];st.log=[];st.red=false;st.round=1;save();SFX.restart();draw();const bx=b.querySelector('.sbx');bx.classList.add('rst');b.insertAdjacentHTML('beforeend','<div class="rsti">'+ic('reset')+'</div>');a.t(()=>{bx.classList.remove('rst');const r=b.querySelector('.rsti');if(r)r.remove()},900)}}};
 b.oninput=e=>{const t=e.target;if(t.dataset.n!=null){st.n[+t.dataset.n]=t.value;save()}else if(t.dataset.x==='neg'){st.neg=t.checked;save()}};
 draw()}
/* ===== Carrom & Majd: two fully separate games (own state, own storage key, own UI) ===== */
const ldSt=(k,def)=>{try{const o=JSON.parse(localStorage.getItem('ams-'+k)||'null');if(o&&Array.isArray(o.n)&&Array.isArray(o.c)&&Array.isArray(o.s)&&o.s.length===2&&o.s.every(Number.isFinite)&&Array.isArray(o.log))return Object.assign(clone(def),o,{cfg:Object.assign({},def.cfg,o.cfg||{})})}catch(e){}return clone(def)};
const svSt=(k,st)=>{try{localStorage.setItem('ams-'+k,JSON.stringify(st))}catch(e){toast(TT('تعذّر الحفظ (التخزين ممتلئ؟)','Could not save (storage full?)'),'err')}};
function counterGame(b,a,K){
 const CR=K==='carrom',DEF={n:['',''],c:['#ffd36b','#a66cff'],s:[0,0],sel:0,red:false,round:1,log:[],rounds:[],cfg:CR?{red:50,white:10,black:5,step:10,keep:true,snd:true}:{step:10,neg:false,snd:true}};
 const st=ldSt(K,DEF);if(st.sel!==1)st.sel=0;const C=st.cfg,sv=()=>svSt(K,st),sfx=n=>{if(C.snd)SFX[n]()},nm=i=>st.n[i]||TT(i?'الفريق الثاني':'الفريق الأول','Team '+(i+1));
 const raf=[0,0],shown=[...st.s],lab={red:TT('حمراء','Red'),white:TT('بيضاء','White'),black:TT('سوداء','Black')};
 const tween=i=>{const el=b.querySelector('#sc'+i);if(!el)return;cancelAnimationFrame(raf[i]);const f=shown[i],t=st.s[i];if(S.motion===false){el.textContent=t;shown[i]=t;return}const t0=performance.now();el.classList.remove('bump');void el.offsetWidth;el.classList.add('bump');
  const go=n=>{const p=Math.min(1,(n-t0)/380);shown[i]=Math.round(f+(t-f)*(1-Math.pow(1-p,3)));el.textContent=shown[i];if(p<1)raf[i]=requestAnimationFrame(go)};raf[i]=requestAnimationFrame(go)};
 const popup=(i,txt)=>{const c=b.querySelector('#tm'+i);if(!c||S.motion===false)return;c.insertAdjacentHTML('beforeend',`<span class="pop">${txt}</span>`);a.t(()=>{const p=c.querySelector('.pop');if(p)p.remove()},850)};
 const logH=()=>st.log.length?st.log.slice(0,8).map(e=>`<div class="ln"><span>${esc(nm(e.t))} · ${e.k==='step'?'±':lab[e.k]||''}</span><span class="${e.v<0?'neg':'pos'}">${e.v>0?'+':''}${e.v}</span></div>`).join(''):`<div class="mu">${TT('لا توجد عمليات بعد','No actions yet')}</div>`;
 const sync=()=>{const L=st.s[0]===st.s[1]?-1:st.s[0]>st.s[1]?0:1;[0,1].forEach(i=>{const c=b.querySelector('#tm'+i);if(!c)return;c.classList.toggle('sel',CR&&st.sel===i);c.classList.toggle('lead',L===i)});
  const lg=b.querySelector('#lg');if(lg)lg.innerHTML=logH();const u=b.querySelector('[data-x=undo]');if(u)u.disabled=!st.log.length;
  if(CR){const r=b.querySelector('.cp.red'),rs=b.querySelector('#rs');if(r){r.classList.toggle('used',st.red);r.disabled=st.red}if(rs){rs.className='rstat '+(st.red?'used':'avail');rs.textContent=(st.red?TT('القطعة الحمراء: مستخدمة في هذا الراوند','Red piece: used this round'):TT('القطعة الحمراء: متاحة (مرة واحدة)','Red piece: available (once)'))+' · '+TT('الراوند','Round')+' '+st.round}}
  else{const r=b.querySelector('#rn');if(r)r.textContent=TT('الجولة ','Round ')+st.round}};
 const paint=()=>{const team=i=>`<div class="tm ctm" id="tm${i}" data-t="${i}" style="--tc:${esc(st.c[i])}"><span class="crn">${ic('crown')}</span><div class="tnm">${esc(nm(i))}</div><div class="tsc" id="sc${i}">${st.s[i]}</div>${CR?'':`<div class="mbs"><button class="btn pb p" data-m="${i}:1">+${C.step}</button><button class="btn pb danger" data-m="${i}:-1">−${C.step}</button></div>`}</div>`;
  b.innerHTML=`<div class="cn k-${K}"><div class="cnbar"><button class="btn" data-x="menu">${ic('home')} ${TT('القائمة','Menu')}</button><button class="btn" data-x="edit">${ic('edit')} ${TT('تعديل','Edit')}</button><button class="btn danger" data-x="reset">${ic('reset')} ${TT('ريست','Reset')}</button></div><div class="cnteams">${team(0)}${team(1)}</div>`+
  (CR?`<div class="rstat" id="rs"></div><div class="cpieces">${['red','white','black'].map(p=>`<button class="cp ${p}" data-p="${p}" aria-label="${lab[p]}"><span>+${C[p]}</span></button>`).join('')}</div><div class="row"><button class="btn p pb" data-x="plus">+${C.step}</button><button class="btn danger pb" data-x="minus">−${C.step}</button></div>`:`<div class="info" id="rn"></div>`)+
  `<div class="row"><button class="btn" data-x="undo">${ic('undo')} ${TT('تراجع','Undo')}</button><button class="btn" data-x="round">${ic('flag')} ${CR?TT('بداية راوند','New round')+` <small>(${C.keep?TT('النقاط تستمر','scores kept'):TT('تصفير النقاط','scores reset')})</small>`:TT('جولة جديدة','New round')}</button></div><div class="sbl"><b>${TT('السجل','History')}</b><div id="lg"></div></div></div>`;sync()};
 const apply=(i,v,k)=>{if(v<0&&!C.neg)v=-Math.min(st.s[i],-v);if(!v){sfx('bad');return false}st.s[i]+=v;st.log.unshift({t:i,v,k});if(st.log.length>60)st.log.length=60;sv();tween(i);popup(i,(v>0?'+':'')+v);vib(10);return true};
 const edit=()=>{const d=$('#det');d.innerHTML=`<div class="box"><h3>${TT('تعديل','Edit')} - ${CR?TT('الكيرم','Carrom'):TT('مجد','Majd')}</h3>`+[0,1].map(i=>`<div class="row"><input id="en${i}" maxlength="18" value="${esc(st.n[i])}" placeholder="${esc(nm(i))}"><input id="ec${i}" type="color" value="${esc(st.c[i])}" style="max-width:64px;padding:2px"></div>`).join('')+
  `<label class="mu">${TT('قيمة +/−','Step value')}</label><input id="est" type="number" min="1" max="100" value="${C.step}">`+
  (CR?`<div class="row"><input id="er" type="number" min="1" max="500" value="${C.red}" title="red"><input id="ew" type="number" min="1" max="500" value="${C.white}" title="white"><input id="eb" type="number" min="1" max="500" value="${C.black}" title="black"></div><label class="mu"><input type="checkbox" id="ek" ${C.keep?'checked':''} style="width:auto;min-height:0"> ${TT('النقاط تستمر عند بداية راوند جديد','Keep scores on new round')}</label>`:`<label class="mu"><input type="checkbox" id="eg" ${C.neg?'checked':''} style="width:auto;min-height:0"> ${TT('السماح بنتيجة سالبة','Allow negative scores')}</label>`)+
  `<label class="mu"><input type="checkbox" id="es" ${C.snd?'checked':''} style="width:auto;min-height:0"> ${TT('الأصوات','Sounds')}</label><div class="row"><button class="btn p" data-e="save">${ic('check')} ${TT('حفظ','Save')}</button><button class="btn" data-e="close">${TT('سكّر','Close')}</button></div></div>`;d.hidden=false;
  d.onclick=e=>{const t=e.target.closest('[data-e]');if(!t)return;if(t.dataset.e==='close'){d.hidden=true;return}const g=id=>d.querySelector('#'+id),n=(id,lo,hi)=>Math.max(lo,Math.min(hi,Math.round(+g(id).value)||lo));
   st.n=[g('en0').value.trim(),g('en1').value.trim()];st.c=[g('ec0').value,g('ec1').value];C.step=n('est',1,100);C.snd=g('es').checked;if(CR){C.red=n('er',1,500);C.white=n('ew',1,500);C.black=n('eb',1,500);C.keep=g('ek').checked}else C.neg=g('eg').checked;sv();d.hidden=true;SFX.ok();paint()}};
 b.onclick=async e=>{const t=e.target.closest('[data-p],[data-x],[data-m],[data-t]');if(!t||t.disabled)return;const d=t.dataset;
  if(d.p){if(d.p==='red'&&st.red)return;if(apply(st.sel,C[d.p],d.p)){if(d.p==='red'){st.red=true;sv();sfx('red');burst();t.classList.add('fly')}else sfx('coin');sync()}return}
  if(d.m){const[i,sg]=d.m.split(':').map(Number);if(apply(i,sg*C.step,'step')){sfx(sg>0?'coin':'sub');sync()}return}
  if(d.t&&!d.x){if(CR){st.sel=+d.t;sv();sfx('tap');sync()}return}
  const k=d.x;
  if(k==='plus'||k==='minus'){if(apply(st.sel,(k==='plus'?1:-1)*C.step,'step')){sfx(k==='plus'?'coin':'sub');sync()}}
  else if(k==='undo'){const z=st.log.shift();if(!z)return;st.s[z.t]-=z.v;if(z.k==='red')st.red=false;sv();tween(z.t);sfx('tap');sync();paintRed()}
  else if(k==='round'){st.rounds.push({r:st.round,s:[...st.s]});if(st.rounds.length>50)st.rounds.shift();st.round++;st.red=false;st.log=[];if(!CR||!C.keep)st.s=[0,0];sv();sfx('swoosh');toast(TT('بدأ راوند جديد','New round started'));paint()}
  else if(k==='reset'){if(await cfmGear(TT('سيتم تصفير نقاط الفريقين والسجل وإعادة الراوند إلى 1. هل أنت متأكد؟','Both scores, the history and the round counter will be reset. Continue?'))){st.s=[0,0];st.log=[];st.red=false;st.round=1;st.rounds=[];sv();sfx('restart');paint();b.insertAdjacentHTML('beforeend','<div class="rsti">'+ic('reset')+'</div>');a.t(()=>{const r=b.querySelector('.rsti');if(r)r.remove()},900)}}
  else if(k==='edit')edit();
  else if(k==='menu'){sv();closeGame(true)}};
 const paintRed=()=>{};
 b.oninput=null;paint()}
const gMajd=(b,a)=>counterGame(b,a,'majd'),gCarrom=(b,a)=>counterGame(b,a,'carrom');
const SPOT=[
{n:['الحديقة','Garden'],lv:['سهل','Easy'],d:[[80,12,7],[33,11,9],[51.5,44,6],[22,45,5]],
draw:v=>`<rect width="100" height="70" fill="#8fd3ff"/><circle cx="80" cy="12" r="6" fill="${v[0]?'#ff7a33':'#ffd23f'}"/>${v[1]?'':'<g fill="#fff"><ellipse cx="30" cy="12" rx="8" ry="4"/><ellipse cx="36" cy="10" rx="5" ry="4"/></g>'}<rect y="48" width="100" height="22" fill="#4cb85a"/><rect x="38" y="28" width="27" height="22" fill="#ffe3b3"/><path d="M35 29l16.5-12L68 29z" fill="#c0392b"/><rect x="48" y="38" width="7" height="12" fill="${v[2]?'#3b82f6':'#7a4a21'}"/><rect x="40" y="33" width="6" height="6" fill="#8fd3ff"/><rect x="58" y="33" width="5" height="6" fill="#8fd3ff"/><rect x="85" y="34" width="4" height="16" fill="#7a4a21"/><circle cx="87" cy="30" r="9" fill="#2e8b3e"/><path d="M22 52v-6" stroke="#2e8b3e" stroke-width="1.5"/><circle cx="22" cy="44" r="3.4" fill="${v[3]?'#ff5a6e':'#ffd23f'}"/>`},
{n:['البحر','Sea'],lv:['متوسط','Medium'],d:[[58,36,7],[24,56,7],[75,13,7],[88,40.5,6],[15,34,5]],
draw:v=>`<rect width="100" height="70" fill="#9fe0ff"/><rect y="38" width="100" height="32" fill="#1f7ad1"/><path d="M38 46h24l-4 6H42z" fill="#7a4a21"/><rect x="49.5" y="22" width="1.2" height="24" fill="#444"/><path d="M52 24l12 18H52z" fill="${v[0]?'#ff5a6e':'#fff'}"/><path d="M48 28L38 42h10z" fill="#fff"/>${v[1]?'':'<ellipse cx="22" cy="56" rx="6" ry="3" fill="#ffd23f"/><path d="M28 56l4-3v6z" fill="#ffd23f"/>'}${v[2]?'':'<path d="M70 14q2.500-4 5 0q2.500-4 5 0" stroke="#fff" stroke-width="1.2" fill="none"/>'}<rect x="84" y="24" width="8" height="24" fill="#fff"/><rect x="84" y="38" width="8" height="5" fill="${v[3]?'#3b82f6':'#e74c3c'}"/><path d="M83 24l5-6 5 6z" fill="#444"/><ellipse cx="15" cy="40" rx="12" ry="4" fill="#e8c874"/><rect x="14" y="30" width="2" height="10" fill="#7a4a21"/><path d="M15 30q-8-2-9 3M15 30q8-2 9 3" stroke="#2e8b3e" stroke-width="2" fill="none"/><circle cx="15" cy="34" r="1.8" fill="${v[4]?'#ff9f43':'#7a4a21'}"/>`},
{n:['الفضاء','Space'],lv:['صعب','Hard'],d:[[30,25,11],[75,15,6],[55,42,5],[55,57,7],[83,56,6],[15,58,6]],
draw:v=>`<rect width="100" height="70" fill="#0b1030"/><g fill="#fff"><circle cx="8" cy="8" r=".8"/><circle cx="50" cy="6" r=".8"/><circle cx="92" cy="30" r=".8"/><circle cx="65" cy="25" r=".8"/><circle cx="40" cy="62" r=".8"/><circle cx="95" cy="64" r=".8"/></g><circle cx="30" cy="25" r="9" fill="#e08a3c"/><ellipse cx="30" cy="25" rx="14" ry="3.500" fill="none" stroke="${v[0]?'#4aa8ff':'#ffd23f'}" stroke-width="1.6"/>${v[1]?'':'<circle cx="75" cy="15" r="5" fill="#d9d9e6"/><circle cx="73.500" cy="14" r="1" fill="#aaa"/>'}<path d="M55 28q6 8 6 20H49q0-12 6-20z" fill="#e9ecf5"/><circle cx="55" cy="42" r="3.200" fill="${v[2]?'#ff5a6e':'#4aa8ff'}"/><path d="M49 48l-5 7 5-2zM61 48l5 7-5-2z" fill="#e74c3c"/><path d="M52 50h6l-3 ${v[3]?'14':'8'}z" fill="#ffb347"/><circle cx="82" cy="58" r="7" fill="#7bd957"/><circle cx="79.500" cy="56" r="1.600" fill="#111"/>${v[4]?'':'<circle cx="84.500" cy="56" r="1.600" fill="#111"/>'}${v[5]?'<circle cx="15" cy="58" r="3.500" fill="#ffd23f"/>':'<path d="M15 54l1.200 3 3.200.2-2.500 2 .9 3.200-2.800-1.800-2.800 1.800.9-3.200-2.500-2 3.200-.2z" fill="#ffd23f"/>'}`}
];
function gSpot(b,a){
 let lvl=0,total=0,timerOn=false,found=[],hints=3,tl=0,score=0,zi=0,over=false;const ZS=[1,1.6,2.3],N=()=>SPOT[lvl].d.length,off=n=>Array(n).fill(false),on=n=>Array(n).fill(true);
 const intro=()=>{b.innerHTML=`<div class="qq">${TT('أوجد الفرق','Spot the Difference')}</div><div class="info">${TT('قارن الصورتين واضغط على أي اختلاف في أي منهما. لكل مرحلة 3 تلميحات فقط.','Compare the two pictures and tap any difference in either one. Each stage has only 3 hints.')}</div><div class="opts">${SPOT.map((s,i)=>`<button class="btn" data-l="${i}">${i+1}. ${TT(s.n[0],s.n[1])} - ${TT(s.lv[0],s.lv[1])} (${s.d.length})</button>`).join('')}</div><label class="mu"><input type="checkbox" id="tmo" ${timerOn?'checked':''} style="width:auto;min-height:0"> ${TT('تفعيل المؤقت (مكافأة وقت)','Enable timer (time bonus)')}</label>`};
 const hud=()=>{const q=s=>b.querySelector(s);q('#fc').textContent=found.length;q('#rm').textContent=TT('المتبقي ','Left ')+(N()-found.length);q('#pt').textContent=score;q('#hc').textContent=hints;q('#hb').disabled=hints<1};
 const mark=h=>b.querySelectorAll('.pane').forEach(p=>p.insertAdjacentHTML('beforeend',h));
 const play=i=>{a.clr();lvl=i;found=[];hints=3;score=0;over=false;const s=SPOT[i],n=s.d.length;tl=45+n*15;
  b.innerHTML=`<div class="spbar"><span>${TT('المرحلة','Stage')} ${i+1}/${SPOT.length}</span><span>${ic('check')} <b id="fc">0</b>/${n}</span><span id="rm"></span>${timerOn?`<span>${ic('clock')} <b id="tm">${tl}</b></span>`:''}<span>★ <b id="pt">0</b></span></div><div class="spotw"><div class="spot" style="width:${ZS[zi]*100}%"><svg class="pane" viewBox="0 0 100 70">${s.draw(off(n))}</svg><svg class="pane" viewBox="0 0 100 70">${s.draw(on(n))}</svg></div></div><div class="row"><button class="btn" id="hb" data-h="1">${ic('eye')} ${TT('تلميح','Hint')} (<span id="hc">3</span>)</button><button class="btn" data-z="-1" aria-label="zoom out">${ic('minus')}</button><button class="btn" data-z="1" aria-label="zoom in">${ic('plus')} ${TT('تكبير','Zoom')}</button><button class="btn" data-l="${i}" aria-label="restart">${ic('reset')}</button></div>`;hud();
  if(timerOn)a.i(()=>{if(over)return;tl--;const e=b.querySelector('#tm');if(e)e.textContent=tl;if(tl>0&&tl<=5)SFX.tick();if(tl<=0)lose()},1000)};
 const box=h=>b.insertAdjacentHTML('beforeend',`<div class="spwin"><div class="box">${h}</div></div>`);
 const done=()=>{over=true;a.clr();const bonus=timerOn?tl*2:0;score+=bonus;total+=score;SFX.win();burst();const last=lvl===SPOT.length-1;box(`<h3>${TT('أحسنت!','Great!')}</h3><p>${TT('اكتشفت كل الاختلافات','You found every difference')} · ★ ${score}${bonus?` (${TT('مكافأة الوقت','time bonus')} +${bonus})`:''}</p><div class="row">${last?`<button class="btn p" data-fin="1">${TT('إنهاء','Finish')}</button>`:`<button class="btn p" data-nx="1">${TT('المرحلة التالية','Next stage')}</button>`}</div>`)};
 const lose=()=>{over=true;a.clr();SFX.lose();box(`<h3>${TT('انتهى الوقت','Time is up')}</h3><div class="row"><button class="btn p" data-l="${lvl}">${TT('إعادة المرحلة','Retry stage')}</button><button class="btn" data-fin="1">${TT('إنهاء','Finish')}</button></div>`)};
 const hit=(p,e)=>{const r=p.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*100,y=(e.clientY-r.top)/r.height*70;let k=-1;SPOT[lvl].d.forEach(([dx,dy,dr],j)=>{if(Math.hypot(x-dx,y-dy)<=dr+1.5)k=j});
  if(k>=0&&found.includes(k)){SFX.tap();return}
  if(k>=0){found.push(k);const[dx,dy,dr]=SPOT[lvl].d[k];mark(`<circle class="fm" cx="${dx}" cy="${dy}" r="${dr}"/>`);score+=100;SFX.found();vib(12);hud();if(found.length===N())done()}
  else{score=Math.max(0,score-5);SFX.bad();p.insertAdjacentHTML('beforeend',`<path class="wx" d="M${x-2} ${y-2}l4 4m0-4l-4 4"/>`);a.t(()=>p.querySelectorAll('.wx').forEach(n=>n.remove()),700);hud()}};
 b.onclick=e=>{const t=e.target.closest('[data-l],[data-h],[data-z],[data-nx],[data-fin]');
  if(t){const d=t.dataset;if(d.l!=null){const c=b.querySelector('#tmo');if(c)timerOn=c.checked;SFX.tap();play(+d.l)}
   else if(d.h&&!over&&hints>0){const k=SPOT[lvl].d.findIndex((_,j)=>!found.includes(j));if(k<0)return;const[dx,dy,dr]=SPOT[lvl].d[k];hints--;score=Math.max(0,score-30);mark(`<circle class="ht" cx="${dx}" cy="${dy}" r="${dr+2}"/>`);a.t(()=>b.querySelectorAll('.ht').forEach(n=>n.remove()),1700);SFX.pop();hud()}
   else if(d.z){zi=Math.max(0,Math.min(2,zi+ +d.z));b.querySelector('.spot').style.width=ZS[zi]*100+'%';SFX.tap()}
   else if(d.nx)play(lvl+1);
   else if(d.fin){a.end(total,TT('انتهت اللعبة - النقاط: ','Game over - points: ')+total)}return}
  const p=e.target.closest('.pane');if(p&&!over)hit(p,e)};
 intro()}

/* ===== missing party games (were referenced but never defined) ===== */
const UCP=[['مسجد','كنيسة','مسجد','كنيسة'],['ثلج','برد','ثلج','برد'],['قمر','شمس','قمر','شمس'],['كتاب','مجلة','كتاب','مجلة'],['قلم','قلم رصاص','قلم','قلم رصاص'],['سمك','روبيان','سمك','روبيان'],['حليب','لبن','حليب','لبن'],['خبز','كعك','خبز','كعك'],['عسل','سكر','عسل','سكر'],['باب','نافذة','باب','نافذة'],['طاولة','كرسي','طاولة','كرسي'],['حذاء','صندل','حذاء','صندل'],['ساعة','منبه','ساعة','منبه'],['جوال','تلفاز','جوال','تلفاز'],['نهر','بحيرة','نهر','بحيرة'],['جبل','تل','جبل','تل'],['وردة','نخلة','وردة','نخلة'],['صقر','نسر','صقر','نسر'],['حصان','حمار','حصان','حمار'],['بطيخ','شمام','بطيخ','شمام'],['تمر','زبيب','تمر','زبيب'],['شاورما','فلافل','شاورما','فلافل'],['ملعب','صالة','ملعب','صالة'],['طبيب','ممرض','طبيب','ممرض'],['معلم','مدرب','معلم','مدرب'],['طيارة','هليكوبتر','طيارة','هليكوبتر'],['سفينة','قارب','سفينة','قارب'],['دجاج','ديك','دجاج','ديك'],['حمام','عصفور','حمام','عصفور'],['مطر','رذاذ','مطر','رذاذ'],['شاي','قهوة','Tea','Coffee'],['قطة','أسد','Cat','Lion'],['بحر','نهر','Sea','River'],['سيارة','دراجة','Car','Bike'],['تفاح','برتقال','Apple','Orange'],['مدرسة','جامعة','School','University'],['ملعقة','شوكة','Spoon','Fork'],['مطار','محطة','Airport','Station'],['بيتزا','برجر','Pizza','Burger'],['ذهب','فضة','Gold','Silver']];
const CHW=[['موز','Banana'],['سباحة','Swimming'],['طبيب','Doctor'],['ركوب الدراجة','Riding a bike'],['حلاق','Barber'],['تصوير','Taking a photo'],['أسد','Lion'],['طبخ','Cooking'],['مطر','Rain'],['حارس مرمى','Goalkeeper'],['فيل','Elephant'],['نوم','Sleeping'],['رجل آلي','Robot'],['حفلة زفاف','Wedding'],['تسلق','Climbing'],['كاميرا','Camera'],['طيارة','Airplane'],['ملك','King']];
/* ===== playerPicker: reusable multi-player input (chips) ===== */
const PP_CL=['#a66cff','#ff5a6e','#3dd6c6','#ffd23f','#4aa8ff','#ff9f43','#7bd957','#e87bd2'],PP_LEN=18,ROSTER_MAX=16;
const ppNorm=s=>String(s).toLowerCase().normalize('NFC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/\s+/g,' ').trim();

const AMS_BL=['قحب','قحيب','متناك','شرموط','عاهر','ديوث','كسمك','كسام','كسخت','منيوك','زنوه','زانيه','شرمط','fuck','shit','bitch','cunt','pussy','whore','slut','asshole'];
const AMS_EX=['كس','كسه','كسك','كسها','كسم','نيك','نيكه','نيكني','ناك','انيك','ينيك','زاني','زنا','قواد','عرص','معرص','قوادين'];
function amsNz(t){return String(t).toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/(.)\1+/g,'$1')}
const AMS_BLN=AMS_BL.map(amsNz),AMS_EXN=new Set(AMS_EX.map(amsNz));
function amsBadTok(t){const n=amsNz(t).replace(/[^\p{L}]/gu,'');if(!n)return false;const m=n.replace(/^(?:ال|و|ف|ب|ل)+/,'');return AMS_EXN.has(n)||AMS_EXN.has(m)||AMS_BLN.some(w=>n.includes(w))}
function amsClean(t){t=String(t==null?'':t);let o=t.split(/(\s+)/).map(p=>!p||/^\s+$/.test(p)?p:(amsBadTok(p)?'★★★':p)).join('');if(/(?:\p{L}[\s._\-*]+){3,}\p{L}/u.test(o)){const c=amsNz(o).replace(/[^\p{L}]/gu,'');if(AMS_BLN.some(w=>c.includes(w)))o='★★★'}return o}
document.addEventListener('input',e=>{const t=e.target;if(e.isComposing||!t||!/^(INPUT|TEXTAREA)$/.test(t.tagName)||t.id==='bk'||(t.type&&!/^(text|search)$/.test(t.type)))return;const c=amsClean(t.value);if(c!==t.value){t.value=c;try{toast('الكلمات المسيئة غير مسموحة','err')}catch(x){}}},true);
function amsPick(arr,key){let u=[];try{u=JSON.parse(localStorage.getItem('ams_nr_'+key)||'[]')}catch(x){}let av=arr.map((_,i)=>i).filter(i=>!u.includes(i));if(!av.length){u=[];av=arr.map((_,i)=>i)}const i=av[Math.random()*av.length|0];u.push(i);try{localStorage.setItem('ams_nr_'+key,JSON.stringify(u))}catch(x){}return arr[i]}
const ppClean=s=>Array.from(amsClean(String(s==null?'':s)).replace(/\s+/g,' ').trim()).slice(0,PP_LEN).join('').trim();
const ppStore={mem:{},get(k){if(this.mem[k])return this.mem[k].slice();try{const a=JSON.parse(localStorage.getItem('ams-pp-'+k)||'[]');if(Array.isArray(a)){const seen=new Set(),out=[];for(const x of a){const n=ppClean(x),z=ppNorm(n);if(n&&!seen.has(z)){seen.add(z);out.push(n)}}return out}}catch(e){}return[]},set(k,a){this.mem[k]=a.slice();try{localStorage.setItem('ams-pp-'+k,JSON.stringify(a))}catch(e){}}};
const ppSame=(a,b)=>a.length===b.length&&a.every((x,i)=>ppNorm(x)===ppNorm(b[i]));
let ppUid=0;
function playerPicker(host,o){
 o=Object.assign({min:0,max:8,teams:false,roster:true,last:true,key:cur?cur.id:'x',startBtn:null,clearAll:false,onChange:null,initial:null,title:''},o||{});
 const uid=++ppUid,T=!!o.teams,list=[];let seq=0,qCache='';
 const title=o.title||(T?TT('الفرق','Teams'):TT('اللاعبون','Players'));
 const ph=()=>T?TT('اسم الفريق','Team name'):TT('اسم اللاعب','Player name');
 host.innerHTML=`<div class="pp" role="group" aria-label="${esc(title)}"><div class="pp-h"><label class="pp-t" for="pp${uid}">${esc(title)}</label><span class="pp-n" role="status" aria-live="polite"></span></div><div class="pp-row"><input id="pp${uid}" dir="auto" maxlength="${PP_LEN}" autocomplete="off" autocapitalize="words" enterkeyhint="done" placeholder="${esc(ph())}"><button type="button" class="pp-add" aria-label="${esc(T?TT('إضافة فريق','Add team'):TT('إضافة لاعب','Add player'))}">${ic('plus')}</button></div><div class="pp-chips" role="list"></div><div class="pp-empty">${esc(T?TT('لم تضف فرقًا بعد','No teams added yet'):TT('لم تضف لاعبين بعد','No players added yet'))}</div><div class="pp-msg" role="status" aria-live="polite" hidden></div><div class="pp-q"></div></div>`;
 const root=host.firstElementChild,inp=root.querySelector('input'),addB=root.querySelector('.pp-add'),row=root.querySelector('.pp-row'),chipsEl=root.querySelector('.pp-chips'),emptyEl=root.querySelector('.pp-empty'),msgEl=root.querySelector('.pp-msg'),qEl=root.querySelector('.pp-q'),cntEl=root.querySelector('.pp-n');
 const motion=()=>S.motion!==false&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
 const names=()=>list.map(x=>x.n);
 const rosterNow=()=>(!T&&o.roster)?ppStore.get('roster'):[];
 const lastNow=()=>(o.last&&o.key)?ppStore.get('last-'+o.key):[];
 const dup=n=>list.some(x=>ppNorm(x.n)===ppNorm(n));
 const bad=m=>{toast(m,'err');row.classList.remove('pp-shake');void row.offsetWidth;row.classList.add('pp-shake')};
 const pend=()=>addB.classList.toggle('pend',!!inp.value.trim()&&!addB.disabled);
 function sync(){
  const n=list.length,full=n>=o.max,low=n<o.min;
  cntEl.textContent=T?TT(`${n} / ${o.max} فرق`,`${n} / ${o.max} teams`):TT(`${n} / ${o.max} لاعبين`,`${n} / ${o.max} players`);
  cntEl.classList.toggle('ok',n>0&&!low);
  inp.disabled=addB.disabled=full;
  inp.placeholder=full?TT('اكتمل العدد','Full'):ph();
  emptyEl.hidden=n>0;
  let msg='';
  if(low)msg=T?(o.min===2?TT('أضف فريقين لبدء اللعبة','Add two teams to start'):TT(`أضف ${o.min} فرق على الأقل لتبدأ`,`Add at least ${o.min} teams to start`)):TT(`أضف ${o.min} لاعبين على الأقل لتبدأ (ينقصك ${o.min-n})`,`Add at least ${o.min} players to start (${o.min-n} more needed)`);
  msgEl.textContent=msg;msgEl.hidden=!msg;
  if(o.startBtn){o.startBtn.disabled=low;o.startBtn.setAttribute('aria-disabled',String(low))}
  const R=rosterNow(),Ls=lastNow(),cur_=names(),q=[];
  if(R.length&&!ppSame(R.slice(0,o.max),cur_))q.push(`<button type="button" class="btn pp-qb" data-q="r">${esc(TT(`استخدام لاعبيّ (${R.length})`,`Use my players (${R.length})`))}<small>${esc(R.slice(0,o.max).join(' · '))}</small></button>`);
  if(Ls.length&&!ppSame(Ls.slice(0,o.max),cur_)&&!(R.length&&ppSame(R.slice(0,o.max),Ls.slice(0,o.max))))q.push(`<button type="button" class="btn pp-qb" data-q="l">${esc(T?TT(`استخدام آخر الفرق (${Ls.length})`,`Use last teams (${Ls.length})`):TT(`استخدام آخر لاعبين (${Ls.length})`,`Use last players (${Ls.length})`))}<small>${esc(Ls.slice(0,o.max).join(' · '))}</small></button>`);
  if(o.clearAll&&n>0)q.push(`<button type="button" class="btn pp-qb" data-q="c">${ic('trash')} ${esc(TT('مسح الكل','Clear all'))}</button>`);
  if(R.length>o.max&&ppSame(R.slice(0,o.max),cur_))q.push(`<div class="pp-note" style="flex:1 1 100%">${esc(TT(`لديك ${R.length} لاعبين محفوظين، وهذه اللعبة تتسع لـ ${o.max} فقط`,`You saved ${R.length} players; this game fits only ${o.max}`))}</div>`);
  const h=q.join('');if(h!==qCache){qCache=h;qEl.innerHTML=h}
  pend();
  if(o.onChange)o.onChange(names());
 }
 function mk(n,delay){const el=document.createElement('span'),c=PP_CL[seq++%PP_CL.length];el.className='pp-chip';el.setAttribute('role','listitem');el.style.setProperty('--cc',c);if(delay)el.style.animationDelay=delay+'ms';el.innerHTML=`<span class="pp-nm">${esc(n)}</span><button type="button" class="pp-x" aria-label="${esc(TT('حذف','Remove')+' '+n)}">${ic('close')}</button>`;chipsEl.appendChild(el);list.push({n,el})}
 function setAll(arr){list.length=0;chipsEl.textContent='';seq=0;let i=0;for(const raw of arr||[]){if(list.length>=o.max)break;const n=ppClean(raw);if(!n||dup(n))continue;mk(n,i++*30)}sync()}
 function add(raw,quiet){
  const parts=String(raw==null?'':raw).split(/[,،\n]/).map(ppClean).filter(Boolean);
  if(!parts.length){if(!quiet)bad(TT('اكتب الاسم أولًا','Type a name first'));return 0}
  let added=0,err='';
  for(const n of parts){
   if(list.length>=o.max){err=TT(`وصلت للحد الأقصى (${o.max})`,`Maximum reached (${o.max})`);break}
   if(dup(n)){err=TT('هذا الاسم مضاف بالفعل','This name is already added');continue}
   mk(n);added++;
  }
  if(added){if(!quiet)SFX.tap();sync()}
  if(err&&!quiet)bad(err);
  return added;
 }
 function rm(el){const i=list.findIndex(x=>x.el===el);if(i<0)return;list.splice(i,1);el.classList.add('out');const x=el.querySelector('.pp-x');if(x)x.disabled=true;if(motion())setTimeout(()=>el.remove(),190);else el.remove();SFX.tap();sync()}
 function flush(){if(inp.value.trim()&&!inp.disabled){add(inp.value,true);inp.value='';pend()}}
 function submit(){const n=add(inp.value);if(n)inp.value='';pend();if(!inp.disabled)inp.focus()}
 addB.addEventListener('mousedown',e=>e.preventDefault());
 addB.addEventListener('click',submit);
 inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();submit()}});
 inp.addEventListener('input',pend);
 inp.addEventListener('paste',e=>{const t=((e.clipboardData||window.clipboardData)&&(e.clipboardData||window.clipboardData).getData('text'))||'';if(/[,،\n]/.test(t.trim())){e.preventDefault();if(add(t))inp.value='';pend()}});
 chipsEl.addEventListener('click',e=>{const x=e.target.closest('.pp-x');if(x)rm(x.closest('.pp-chip'))});
 qEl.addEventListener('click',e=>{const q=e.target.closest('[data-q]');if(!q)return;const k=q.dataset.q;if(k==='c'){setAll([]);SFX.tap();return}const src=k==='r'?rosterNow():lastNow();setAll(src.slice(0,o.max));SFX.tap()});
 if(o.startBtn)o.startBtn.addEventListener('click',()=>{flush();const a=names();if(o.last&&o.key&&a.length&&a.length>=o.min)ppStore.set('last-'+o.key,a)});
 setAll(Array.isArray(o.initial)?o.initial.slice(0,o.max):rosterNow().slice(0,o.max));
 return {get:names,set:setAll,add,flush,el:root,input:inp,count:()=>list.length};
}
/* ----- roster: a global list of players saved once, used by every party game ----- */
const rosEl=$('#ros');let rosPP=null;
function syncRoster(){const n=ppStore.get('roster').length,b=$('#rosterBtn');b.innerHTML=ic('users')+(n?`<span class="rbadge">${n}</span>`:'');b.setAttribute('aria-label',TT('اللاعبون','Players')+(n?' ('+n+')':''))}
function openRoster(){
 $('#rosT').textContent=TT('لاعبيّ','My players');
 $('#rosP').textContent=TT('أضف لاعبيك مرة واحدة وسيظهرون تلقائيًا في كل لعبة جماعية دون إعادة كتابتهم. يمكنك حذف أي لاعب في أي وقت.','Add your players once and they will appear automatically in every party game. You can remove anyone at any time.');
 $('#rosOk').textContent=TT('تأكيد','Confirm');$('#rosX').textContent=TT('إلغاء','Cancel');
 const init=ppStore.get('roster');
 rosPP=playerPicker($('#rosPP'),{key:'roster',roster:false,last:false,min:0,max:ROSTER_MAX,clearAll:true,initial:init,title:TT('اللاعبون','Players')});
 rosEl.hidden=false;document.body.classList.add('lock');SFX.open();
 if(!init.length)rosPP.input.focus();
}
function closeRoster(){rosEl.hidden=true;document.body.classList.toggle('lock',!$('#gv').hidden);rosPP=null;$('#rosPP').textContent='';$('#rosterBtn').focus()}
$('#rosterBtn').onclick=()=>{SFX.tap();openRoster()};
$('#rosX').onclick=()=>{SFX.tap();closeRoster()};
$('#rosOk').onclick=()=>{if(!rosPP)return;rosPP.flush();const a=rosPP.get();ppStore.set('roster',a);syncRoster();closeRoster();SFX.ok();toast(a.length?TT(`تم حفظ اللاعبين (${a.length})`,`Players saved (${a.length})`):TT('تم مسح قائمة اللاعبين','Players list cleared'))};
rosEl.addEventListener('keydown',e=>{if(e.key==='Escape')closeRoster()});
function askPlayers(b,o){b.innerHTML=`<div class="qq">${o.title}</div><div class="info">${o.info}</div><div data-pp></div><button class="btn p" id="go">${ic('play')} ${TT('ابدأ','Start')}</button>`;
 const pp=playerPicker(b.querySelector('[data-pp]'),{min:o.min,max:o.max,teams:!!o.teams,startBtn:b.querySelector('#go')});
 b.onclick=e=>{if(!e.target.closest('#go'))return;const ps=pp.get();if(ps.length<o.min){toast(TT(`أدخل ${o.min} لاعبين على الأقل`,`Enter at least ${o.min} players`),'err');return}SFX.tap();o.ok(ps)}}
const passScr=(b,name,btn,k)=>{b.innerHTML=`<div class="info">${TT('مرّر الجهاز إلى','Pass the device to')}</div><div class="big sm">${esc(name)}</div><button class="btn p" data-a="${k}">${btn}</button>`};
function gUndercover(b,a){askPlayers(b,{title:TT('الجاسوس المتخفي','Undercover Spy'),info:TT('3 إلى 12 لاعبًا. الجميع يأخذ كلمة سرية، وواحد فقط كلمته مختلفة قليلًا وهو لا يعلم! صفوا كلماتكم دون ذكرها ثم صوّتوا لإقصاء المشتبه به.','3–12 players. Everyone gets a secret word, but one player has a slightly different word and does not know it! Describe your word without saying it, then vote someone out.'),min:3,max:12,ok:ps=>{
 const pr=amsPick(UCP,'uc'),o=LANG==='en'?2:0,sw=Math.random()<.5,civ=pr[o+(sw?0:1)],spy=pr[o+(sw?1:0)],sp=Math.random()*ps.length|0,alive=ps.map(()=>true);let i=0,msg='';
 const ask=()=>passScr(b,ps[i],TT('اكشف كلمتي','Reveal my word'),'show');
 const vote=()=>{b.innerHTML=`<div class="info">${msg}</div><div class="qq">${TT('من الجاسوس؟ صوّتوا لإقصاء لاعب','Who is the spy? Vote one player out')}</div><div class="opts">`+ps.map((p,k)=>alive[k]?`<button class="btn opt" data-a="out" data-v="${k}">${esc(p)}</button>`:'').join('')+'</div>'};
 b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a;SFX.tap();
  if(k==='show')b.innerHTML=`<div class="big sm">${esc(i===sp?spy:civ)}</div><div class="info">${TT('احفظ الكلمة ولا تُظهرها لأحد','Memorize it and show nobody')}</div><button class="btn p" data-a="hide">${TT('إخفاء وتمرير','Hide and pass')}</button>`;
  else if(k==='hide'){i++;i<ps.length?ask():vote()}
  else if(k==='out'){const v=+t.dataset.v;alive[v]=false;
   if(v===sp)a.end(1,TT(`كشفتم الجاسوس! كان ${ps[sp]} - كلمة الأغلبية: ${civ}، كلمته: ${spy}`,`Spy found! It was ${ps[sp]} - majority word: ${civ}, spy word: ${spy}`));
   else if(alive.filter(Boolean).length<=2)a.end(0,TT(`نجا الجاسوس! كان ${ps[sp]} - كلمة الأغلبية: ${civ}، كلمته: ${spy}`,`The spy escaped! It was ${ps[sp]} - majority word: ${civ}, spy word: ${spy}`));
   else{SFX.bad();msg=esc(ps[v])+TT(' لم يكن الجاسوس! استمروا.',' was not the spy! Keep going.');vote()}}};
 ask()}})}
function gCharades(b,a){askPlayers(b,{title:TT('تمثيل بدون كلام','Silent Charades'),info:TT('فريقان يتناوبان 3 جولات. مثّل الكلمة بالإشارات فقط وفريقك يخمّن خلال 60 ثانية.','Two teams alternate for 3 rounds. Act out the word with gestures only while your team guesses within 60 seconds.'),teams:true,min:2,max:2,ok:ts=>{
 const sc=[0,0],deck=shuf(CHW);let turn=0,wi=0,tl=60;
 const card=()=>{const e=b.querySelector('#cw');if(e)e.textContent=deck[wi%deck.length][LANG==='en'?1:0]};
 const ready=()=>{a.clr();b.innerHTML=`<div class="info">${TT('الجولة','Round')} ${(turn>>1)+1}/3 · ${esc(ts[0])} ${sc[0]} - ${sc[1]} ${esc(ts[1])}</div><div class="info">${TT('دور الفريق','Team turn')}</div><div class="big sm">${esc(ts[turn%2])}</div><button class="btn p" data-a="go">${ic('play')} ${TT('ابدأ التمثيل','Start acting')}</button>`};
 const next=()=>{turn++;if(turn>=6){const w=sc[0]===sc[1]?TT('تعادل!','Draw!'):TT('فاز ','Winner: ')+ts[sc[0]>sc[1]?0:1];a.end(Math.max(...sc),`${w} (${sc[0]} - ${sc[1]})`)}else ready()};
 const play=()=>{tl=60;wi++;b.innerHTML=`<div class="info">${esc(ts[turn%2])} · ${ic('clock')} <b id="ct">60</b></div><div class="big sm" id="cw"></div><div class="row"><button class="btn good" data-a="ok">${ic('check')} ${TT('صحيح','Correct')}</button><button class="btn" data-a="skip">${ic('skip')} ${TT('تخطّ','Skip')}</button></div>`;card();
  a.i(()=>{tl--;const e=b.querySelector('#ct');if(e)e.textContent=tl;if(tl>0&&tl<=5)SFX.tick();if(tl<=0){a.clr();SFX.end();next()}},1000)};
 b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a;
  if(k==='go'){SFX.open();play()}else if(k==='ok'){sc[turn%2]++;SFX.ok();wi++;card()}else if(k==='skip'){SFX.tap();wi++;card()}};
 ready()}})}
function gFibbage(b,a){askPlayers(b,{title:TT('الحقيقة والخدعة','Truth or Bluff'),info:TT('3 إلى 8 لاعبين يتناوبون على الأسئلة. الإجابة الصحيحة بنقطة، وانتبهوا للخيارات المخادعة!','3–8 players take turns answering. A correct answer earns a point - beware of the tricky options!'),min:3,max:8,ok:ps=>{
 const R=Math.min(10,ps.length*2),qs=pickQuestions('مختلط',R),sc=ps.map(()=>0);let r=0,done=false;
 const show=()=>{const x=qs[r];done=false;b.innerHTML=`<div class="info">${TT('السؤال','Question')} ${r+1}/${R} · ${TT('الدور:','Turn:')} <b>${esc(ps[r%ps.length])}</b></div><div class="qq">${esc(x.q)}</div><div class="opts">${x.a.map((o,k)=>`<button class="btn opt" data-a="pick" data-v="${k}">${esc(o)}</button>`).join('')}</div>`};
 b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a;
  if(k==='pick'){if(done)return;done=true;const x=qs[r],v=+t.dataset.v,ok=v===x.c;if(ok)sc[r%ps.length]++;ok?SFX.ok():SFX.bad();b.querySelectorAll('.opt').forEach((o,j)=>{if(j===x.c)o.classList.add('good');else if(j===v)o.classList.add('badc')});b.insertAdjacentHTML('beforeend',`<div class="info">${esc(x.w||'')}</div><button class="btn p" data-a="next">${r+1<R?TT('التالي','Next'):TT('النتيجة','Results')}</button>`)}
  else if(k==='next'){SFX.tap();r++;if(r<R)show();else{const m=Math.max(...sc),w=ps.filter((_,j)=>sc[j]===m);a.end(m,TT(`الفائز: ${w.join('، ')} - ${m} نقطة`,`Winner: ${w.join(', ')} - ${m} pts`))}}};
 show()}})}
function gTelephone(b,a){askPlayers(b,{title:TT('الهاتف الخربان','Telephone Remix'),info:TT('كل لاعب يقرأ الجملة السابقة ثم يخفيها ويكتبها كما يتذكرها. في النهاية شاهدوا كيف تغيّرت!','Each player reads the previous sentence, hides it, then writes it as they remember it. At the end, see how it changed!'),min:3,max:10,ok:ps=>{let i=0;const ch=[];
 const pass=()=>passScr(b,ps[i],i?TT('اقرأ الجملة','Read the sentence'):TT('اكتب جملة','Write a sentence'),i?'read':'write');
 b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const k=t.dataset.a;SFX.tap();
  if(k==='read')b.innerHTML=`<div class="info">${TT('حاول حفظها ثم اضغط للكتابة','Memorize it, then tap to write')}</div><div class="qq">${esc(ch[i-1])}</div><button class="btn p" data-a="write">${TT('إخفاء والكتابة','Hide and write')}</button>`;
  else if(k==='write')b.innerHTML=`<div class="info">${i?TT('اكتب الجملة كما تذكرها (أو كما فهمتها!)','Write the sentence as you remember it (or as you understood it!)'):TT('اكتب جملة مضحكة','Write a funny sentence')}</div><textarea id="tx" maxlength="120"></textarea><button class="btn p" data-a="sub">${TT('تمرير للاعب التالي','Pass to next player')}</button>`;
  else if(k==='sub'){const v=b.querySelector('#tx').value.trim();if(!v){toast(TT('اكتب الجملة أولًا','Write the sentence first'),'err');return}ch[i]=v;i++;
   if(i<ps.length)pass();else{b.innerHTML=`<div class="qq">${TT('الجملة الأصلية والتحولات','Original and transformations')}</div><div class="sbw">`+ch.map((c,j)=>`<div class="card"><div class="mu">${j?j+'. ':'★ '}${esc(ps[j])}</div>${esc(c)}</div>`).join('')+'</div>';a.end(null,TT('انتهى التحدي','Challenge complete'))}}};
 pass()}})}

const G=[
{id:'zombie',n:'زومبي',i:'rps',c:'ملحمي',p:'1',l:'صعب',d:'موجات زومبي وأسلحة نادرة ومتجر وتطويرات.',run:gZombie},
{id:'dino',n:'الديناصور',i:'rps',c:'ملحمي',p:'1',l:'متوسط',d:'نط فوق الصبار والسرعة تزيد كل شوي.',run:gDino},
{id:'snake',n:'الثعبان',i:'rps',c:'ملحمي',p:'1',l:'متوسط',d:'كُل وكبّر ثعبانك وانتبه من الجدران وجسمك.',run:gSnake},
{id:'flappy',n:'الطيّار',i:'rps',c:'ملحمي',p:'1',l:'صعب',d:'طير بين الأنابيب وإياك تصطدم.',run:gFlap},
{id:'memory',n:'الألوان',i:'memory',c:'ذكاء',p:'1',l:'متوسط',d:'احفظ ترتيب الألوان وعيده صح.',run:gMemory},
{id:'number',n:'ذاكرة الأرقام',i:'number',c:'ذكاء',p:'1',l:'صعب',d:'احفظ الرقم قبل لا يختفي، وكل مرحلة يطول أكثر.',run:gNumber},
{id:'odd',n:'المختلف',i:'odd',c:'ذكاء',p:'1',l:'متوسط',d:'دوّر على الرمز المختلف وانقره خلال 30 ثانية.',run:gOdd},
{id:'match',n:'الكروت',i:'match',c:'استراتيجية',p:'1',l:'سهل',d:'اقلب الكروت وطابق الأزواج بأقل حركات.',run:gMatch,low:1},
{id:'quiz',n:'الأسئلة',i:'quiz',c:'ذكاء',p:'1',l:'متوسط',d:'10 أسئلة عشوائية مع شرح الجواب.',run:gQuiz},
{id:'math',n:'الحساب',i:'math',c:'سرعة',p:'1',l:'متوسط',d:'حل أكبر عدد من المسائل في 20 ثانية.',run:gMath},
{id:'tap',n:'الضغط',i:'tap',c:'سرعة',p:'1',l:'سهل',d:'كم ضغطة تقدر تسوي في 10 ثواني؟',run:gTap},
{id:'react',n:'ردة الفعل',i:'react',c:'سرعة',p:'1',l:'سهل',d:'اضغط أول ما تصير الدائرة خضراء. الأقل أحسن.',run:gReact,low:1},
{id:'whack',n:'الأهداف',i:'whack',c:'سرعة',p:'1',l:'متوسط',d:'اضرب الأهداف المتحركة قبل لا تختفي.',run:gWhack},
{id:'typing',n:'الكتابة',i:'typing',c:'سرعة',p:'1',l:'متوسط',d:'اكتب 5 كلمات بأسرع وقت. الأقل أحسن.',run:gTyping,low:1},
{id:'guess',n:'خمّن الرقم',i:'guess',c:'حظ',p:'1',l:'سهل',d:'خمّن رقم من 1 إلى 100 بأقل محاولات.',run:gGuess,low:1},
{id:'rps',n:'حجر ورقة مقص',i:'rps',c:'حظ',p:'1',l:'سهل',d:'تحدى الكمبيوتر، اللي يوصل 3 أول يفوز.',run:gRps},
{id:'dice',n:'النرد',i:'dice',c:'حظ',p:'1',l:'سهل',d:'5 جولات نرد ضد الكمبيوتر.',run:gDice},
{id:'xo',n:'اكس او',i:'xo',c:'استراتيجية',p:'1',l:'صعب',d:'غلب الكمبيوتر في اكس او.',run:gXO},
{id:'c4',n:'اربعة',i:'c4',c:'استراتيجية',p:'2',l:'متوسط',d:'اثنين على جوال واحد: اللي يجمع 4 في صف يفوز.',run:gC4},
{id:'forbid',n:'الممنوعة',i:'forbid',c:'جماعي',p:'2 فرق',l:'متوسط',d:'اشرح الكلمة لفريقك بدون الكلمات الممنوعة.',run:gForbid},
{id:'sab',n:'المخرب',i:'sab',c:'جماعي',p:'3-8',l:'متوسط',d:'واحد منكم ما يعرف الكلمة. طلّعوه بالتصويت.',run:gSab},
{id:'score',n:'النقاط',i:'score',c:'فرق ونقاط',p:'2-12',l:'سهل',d:'سجّل نقاط الفرق (مجد، كيرم، عام) مع سجل وتراجع.',run:gScore},
{id:'majd',n:'مجد',i:'majd',c:'فرق ونقاط',p:'2',l:'سهل',f:true,d:'عداد سريع لفريقين: +10 و−10 مع سجل وتراجع وإعادة ضبط آمنة.',r:'اضغط +10 أو −10 لكل فريق. النتيجة لا تنزل تحت الصفر إلا إذا فعّلت خيار السالب. يمكنك تغيير الأسماء والتراجع عن آخر عملية.',run:gMajd},
{id:'carrom',n:'كيرم',i:'carrom',c:'فرق ونقاط',p:'2',l:'سهل',f:true,d:'نقاط الكيرم: الحمراء 50 (مرة في الراوند)، البيضاء 10، السوداء 5.',r:'القطعة الحمراء تُحتسب مرة واحدة فقط في الراوند، وتعود متاحة عند «راوند جديد». يمكنك التراجع عن آخر عملية.',run:gCarrom},
{id:'detect',n:'المحقق',i:'detect',c:'جماعي',p:'2-8',l:'متوسط',d:'أدلة تنكشف واحد واحد، خمّن بأقل أدلة.',run:gDetect},
{id:'trivia',n:'معلومات',i:'trivia',c:'جماعي',p:'2-8',l:'متوسط',d:'كل واحد يجاوب بدوره على أسئلة عامة ونقاط.',run:gTrivia},
{id:'most',n:'من الأكثر؟',i:'crown',c:'جماعي',p:'3-12',l:'سهل',d:'أسئلة تصويت تطلّع آراء الشلة بشكل ممتع.',run:gMost},
{id:'categories',n:'الفئات',i:'list',c:'جماعي',p:'2-8',l:'متوسط',d:'اكتب جواب يبدأ بالحرف المطلوب قبل لا يخلص الوقت.',run:gCategories},
{id:'secretword',n:'الكلمة الغريبة',i:'eye',c:'جماعي',p:'3-12',l:'متوسط',d:'كلمات متقاربة وتلميحات وتصويت عشان تعرفون مين اللي كلمته غير.',run:gSecretWord},
{id:'whoami',n:'مين أنا',i:'person',c:'جماعي',p:'2-8',l:'متوسط',d:'خمّن شخص أو شي من أدلة تنكشف شوي شوي.',run:gWhoAmI},{id:'wordchain',n:'سلسلة الكلمات',i:'typing',c:'جماعي',p:'2-8',l:'متوسط',d:'ابدأ كل كلمة بآخر حرف من الكلمة اللي قبلها وبدون تكرار.',run:gWordChain},{id:'truth',n:'صدق ولا كذب',i:'quiz',c:'جماعي',p:'2-8',l:'متوسط',d:'جرّبوا معلوماتكم بأسئلة صح أو غلط.',run:gTruth},
{id:'differences',n:'الفروقات',i:'diff',c:'ذكاء',p:'1',l:'سهل',d:'ثلاث مراحل بصور حقيقية: اضغط الاختلافات في أي صورة مع تلميحات ومؤقت اختياري.',run:gSpot},
{id:'scramble',n:'رتّب الحروف',i:'shuffle',c:'ذكاء',p:'1-8',l:'متوسط',d:'سوّ كلمات عربي وإنجليزي من حروف مبعثرة.',run:gScramble},
{id:'mafia',n:'المافيا',i:'moon',c:'جماعي',p:'5-16',l:'صعب',d:'أهل القرية والمافيا والطبيب والشايب بأدوار سرية، ليل ونهار وتصويت.',run:gMafia},
{id:'categories2',n:'فئات سريعة',i:'tag',c:'جماعي',p:'2-8',l:'سهل',d:'جاوب بسرعة على فئات تبدأ بحرف معيّن.',run:gCategories},
{id:'undercover',n:'الجاسوس',i:'spy',c:'جماعي',p:'3-12',l:'متوسط',d:'كلمات سرية متقاربة، اكتشفوا مين ما يعرف الكلمة.',run:gUndercover},
{id:'charades',n:'تمثيل',i:'theater',c:'جماعي',p:'2-12',l:'سهل',d:'مثّل العبارة بالحركات بس قبل لا يخلص الوقت.',run:gCharades},
{id:'fibbage',n:'خدعني',i:'mask',c:'جماعي',p:'3-8',l:'متوسط',d:'أسئلة للكل ونقاط على الجواب الصح.',run:gFibbage},
{id:'telephone',n:'الهاتف الخربان',i:'phone',c:'جماعي',p:'3-12',l:'سهل',d:'مرّروا الجملة بينكم وشوفوا وش يصير فيها.',run:gTelephone}];
const RULES={score:'اختر الوضع (عام/مجد/كيرم). اضغط اسم الفريق لتحديده، ثم أزرار الإضافة (أخضر) أو الخصم (أحمر) تؤثر على الفريق المحدد فقط. قيم الأزرار قابلة للتعديل من الإعدادات. الحمراء في كيرم تُسجَّل مرة واحدة في الجولة.',forbid:'فريقان يتناوبان 6 أدوار. الشارح يصف الكلمة لفريقه دون استخدام الكلمات الممنوعة. صح +1، مخالفة −1، والوقت 60 ثانية.',sab:'3 إلى 8 لاعبين. يرى كل لاعب الكلمة سرًا إلا المخرب فيرى الفئة فقط. يلمّح كل واحد بكلمة ثم تصوّتون على المخرب.',detect:'تظهر أدلة عن شيء مخفي واحدًا تلو الآخر. في دورك خمّن أو اطلب دليلًا إضافيًا. كلما قلّت الأدلة زادت النقاط، والخطأ يخصم نقطة.',trivia:'اللاعبون يتناوبون على الأسئلة. 15 ثانية للسؤال و10 نقاط لكل إجابة صحيحة. الأعلى نقاطًا يفوز.',c4:'لاعبان على جهاز واحد يتناوبان بإسقاط قطعة في عمود. أول من يكوّن 4 قطع متتالية يفوز.',xo:'أنت X والكمبيوتر O. أول من يكمل ثلاثة في صف يفوز.'};
const FEAT=['score','sab','detect','quiz','xo','secretword','most','categories'];G.forEach(g=>{g.r=RULES[g.id]||'';g.f=FEAT.includes(g.id)});
/* ===== v4: hard brain games, endless question generator, XO levels, daily challenge ===== */
var XOP=.7,KEYH=null;
addEventListener('keydown',e=>{if(!api.live||!KEYH||KEYH.g!==cur)return;if(KEYH.f(e))e.preventDefault()});
const XQ=[
['علوم','صعب','ما الغاز الأكثر وفرة في الغلاف الجوي للأرض؟','النيتروجين','الأكسجين','ثاني أكسيد الكربون','الأرجون','النيتروجين يشكل نحو 78% من الهواء.'],
['فضاء','صعب','كم تقريبًا يستغرق ضوء الشمس للوصول إلى الأرض؟','8 دقائق','8 ثوانٍ','8 ساعات','80 دقيقة','حوالي 8 دقائق و20 ثانية.'],
['تاريخ','صعب','من مؤسس الدولة الأموية؟','معاوية بن أبي سفيان','عبد الملك بن مروان','أبو العباس السفاح','هارون الرشيد','أسسها معاوية عام 41هـ.'],
['تاريخ','صعب','في أي عام سقطت غرناطة آخر معاقل الأندلس؟','1492','1453','1517','1258','سقطت غرناطة عام 1492م.'],
['جغرافيا','صعب','ما أعمق بحيرة في العالم؟','بايكال','فيكتوريا','سوبيريور','تنجانيقا','بحيرة بايكال في روسيا.'],
['رياضيات','صعب','ما قيمة 2 أس 10؟','1024','512','2048','1000','2^10 = 1024.'],
['رياضيات','صعب','ما مجموع الأعداد من 1 إلى 100؟','5050','5000','5100','4950','n(n+1)/2 = 5050.'],
['أحياء','صعب','أي عضية تسمى محطة توليد الطاقة في الخلية؟','الميتوكوندريا','الريبوسوم','جهاز جولجي','الفجوة','تنتج الميتوكوندريا الطاقة ATP.'],
['علوم','متوسط','ما أصلب مادة طبيعية معروفة؟','الألماس','الحديد','الكوارتز','الجرانيت','الألماس 10 على مقياس موهس.'],
['معلومات عامة','صعب','من سجّل براءة اختراع الهاتف عام 1876؟','ألكسندر غراهام بيل','توماس إديسون','نيكولا تيسلا','ماركوني','سجّلها بيل.'],
['لغة عربية','صعب','ما إعراب «الطالبُ» في «نجح الطالبُ»؟','فاعل مرفوع','مفعول به','مبتدأ','خبر','نجح فعل والطالب فاعل.'],
['فضاء','صعب','ما أكبر أقمار المشتري؟','غانيميد','يوروبا','أيو','كاليستو','غانيميد أكبر قمر في المجموعة الشمسية.'],
['تاريخ','متوسط','لأي ملك يعود الهرم الأكبر في الجيزة؟','خوفو','رمسيس الثاني','توت عنخ آمون','أخناتون','الهرم الأكبر للملك خوفو.'],
['علوم','صعب','ما وحدة قياس شدة التيار الكهربائي؟','الأمبير','الفولت','الأوم','الواط','الأمبير هو وحدة التيار.'],
['جغرافيا','صعب','ما أكبر صحراء حارة في العالم؟','الصحراء الكبرى','الربع الخالي','غوبي','كالاهاري','الصحراء الكبرى في أفريقيا.'],
['علوم','صعب','ما العنصر الأخف في الجدول الدوري؟','الهيدروجين','الهيليوم','الليثيوم','الأكسجين','عدده الذري 1.']];
const XQ2=[["جغرافيا", "سهل", "ما عاصمة مصر?", "القاهرة", "الإسكندرية", "الجيزة", "أسوان", "القاهرة هي عاصمة مصر."], ["جغرافيا", "سهل", "ما أطول نهر في العالم؟", "النيل", "الأمازون", "دجلة", "الراين", "يعد النيل من أطول أنهار العالم."], ["جغرافيا", "متوسط", "ما عاصمة اليابان؟", "طوكيو", "أوساكا", "كيوتو", "سابورو", "طوكيو عاصمة اليابان."], ["جغرافيا", "متوسط", "في أي قارة تقع البرازيل؟", "أمريكا الجنوبية", "أفريقيا", "آسيا", "أوروبا", "البرازيل أكبر دول أمريكا الجنوبية."], ["جغرافيا", "صعب", "ما أعمق بحيرة في العالم؟", "بايكال", "فيكتوريا", "تيتيكاكا", "سوبيريور", "بحيرة بايكال في روسيا أعمق بحيرات العالم."], ["علوم", "سهل", "ما الغاز الذي نتنفسه ليبقينا أحياء؟", "الأكسجين", "الهيدروجين", "النيتروجين", "الهيليوم", "نحتاج الأكسجين للتنفس."], ["علوم", "سهل", "كم عدد أيام الأسبوع؟", "7", "5", "6", "8", "الأسبوع سبعة أيام."], ["علوم", "متوسط", "ما أقرب كوكب إلى الشمس؟", "عطارد", "الزهرة", "المريخ", "الأرض", "عطارد الأقرب للشمس."], ["علوم", "متوسط", "ما درجة غليان الماء بالسيليزية؟", "100", "90", "110", "120", "يغلي الماء عند 100 درجة عند مستوى البحر."], ["علوم", "صعب", "ما الرمز الكيميائي للذهب؟", "Au", "Ag", "Gd", "Go", "الرمز Au من اللاتينية Aurum."], ["أحياء", "سهل", "كم عدد أرجل العنكبوت؟", "8", "6", "4", "10", "للعنكبوت ثماني أرجل."], ["أحياء", "متوسط", "ما أسرع حيوان بري؟", "الفهد", "الأسد", "الحصان", "الغزال", "الفهد أسرع الحيوانات البرية."], ["أحياء", "صعب", "ما الفصيلة التي ينتمي إليها الدلفين؟", "الثدييات", "الأسماك", "الزواحف", "البرمائيات", "الدلفين من الثدييات البحرية."], ["تاريخ", "سهل", "من هو مؤسس المملكة العربية السعودية؟", "الملك عبدالعزيز", "الملك فيصل", "الملك سعود", "الملك فهد", "وحّد الملك عبدالعزيز المملكة عام 1932."], ["تاريخ", "متوسط", "في أي عام تأسست الدولة السعودية الأولى؟", "1744", "1824", "1902", "1932", "تأسست الدولة السعودية الأولى عام 1744م."], ["تاريخ", "متوسط", "ما الحضارة التي بنت الأهرامات؟", "المصرية القديمة", "الرومانية", "الفارسية", "اليونانية", "بنى المصريون القدماء الأهرامات."], ["تاريخ", "صعب", "من هو أول خليفة في الإسلام؟", "أبو بكر الصديق", "عمر بن الخطاب", "عثمان بن عفان", "علي بن أبي طالب", "أبو بكر هو أول الخلفاء الراشدين."], ["فضاء", "سهل", "ما اسم قمر الأرض؟", "القمر", "فوبوس", "تيتان", "أوروبا", "للأرض قمر واحد طبيعي."], ["فضاء", "متوسط", "ما الكوكب ذو الحلقات الأشهر؟", "زحل", "المشتري", "أورانوس", "المريخ", "زحل مشهور بحلقاته."], ["رياضيات", "سهل", "كم يساوي 12 × 12؟", "144", "122", "124", "148", "12 × 12 = 144."], ["رياضيات", "سهل", "ما ناتج 100 ÷ 4؟", "25", "20", "30", "40", "100 ÷ 4 = 25."], ["رياضيات", "متوسط", "كم عدد أضلاع السداسي؟", "6", "5", "7", "8", "السداسي له ستة أضلاع."], ["رياضيات", "صعب", "ما قيمة 2 أس 10؟", "1024", "512", "2048", "1000", "2^10 = 1024."], ["معلومات عامة", "سهل", "كم عدد لاعبي فريق كرة القدم داخل الملعب؟", "11", "9", "10", "12", "يلعب 11 لاعبًا من كل فريق."], ["معلومات عامة", "سهل", "ما لون الحمض النووي الذي يرمز للدم في العلم؟", "أحمر", "أزرق", "أخضر", "أصفر", "الدم الأحمر لونه بسبب الهيموغلوبين."], ["معلومات عامة", "متوسط", "ما أكبر قارة من حيث المساحة؟", "آسيا", "أفريقيا", "أوروبا", "أمريكا الشمالية", "آسيا أكبر القارات."], ["معلومات عامة", "متوسط", "ما عدد قارات العالم؟", "7", "5", "6", "8", "يقسم العالم عادة إلى سبع قارات."], ["معلومات عامة", "صعب", "ما العملة الرسمية للمملكة المتحدة؟", "الجنيه الإسترليني", "اليورو", "الدولار", "الفرنك", "عملة بريطانيا الجنيه الإسترليني."], ["لغة عربية", "سهل", "ما ضد كلمة «كبير»؟", "صغير", "طويل", "واسع", "قوي", "ضد كبير صغير."], ["لغة عربية", "متوسط", "ما مفرد كلمة «أقلام»؟", "قلم", "قلمة", "مقلم", "قلام", "مفرد أقلام هو قلم."], ["لغة عربية", "صعب", "ما جمع كلمة «وزير»؟", "وزراء", "وزيرون", "أوزار", "وزائر", "جمع وزير وزراء."]];XQ.push(...XQ2);BANK.push(...XQ.map((x,i)=>{const a=shuf([x[3],x[4],x[5],x[6]]);return{id:'x'+i,cat:x[0],level:x[1],q:x[2],a,c:a.indexOf(x[3]),w:x[7]}}));
const CAP='السعودية:الرياض,مصر:القاهرة,الأردن:عمّان,الإمارات:أبوظبي,الكويت:الكويت,قطر:الدوحة,عُمان:مسقط,المغرب:الرباط,تونس:تونس,الجزائر:الجزائر,العراق:بغداد,لبنان:بيروت,فرنسا:باريس,ألمانيا:برلين,إيطاليا:روما,إسبانيا:مدريد,اليابان:طوكيو,الصين:بكين,الهند:نيودلهي,روسيا:موسكو,كندا:أوتاوا,أستراليا:كانبرا,البرازيل:برازيليا,الأرجنتين:بوينس آيرس,تركيا:أنقرة,كوريا الجنوبية:سيول,تايلاند:بانكوك,النرويج:أوسلو,السويد:ستوكهولم,بولندا:وارسو,اليونان:أثينا,البرتغال:لشبونة,نيجيريا:أبوجا,كينيا:نيروبي,إثيوبيا:أديس أبابا,كولومبيا:بوغوتا,تشيلي:سانتياغو,بيرو:ليما,باكستان:إسلام آباد,ماليزيا:كوالالمبور,سويسرا:برن,النمسا:فيينا'.split(',').map(s=>s.split(':'));
const ELM='الذهب:Au,الفضة:Ag,الحديد:Fe,النحاس:Cu,الصوديوم:Na,البوتاسيوم:K,الرصاص:Pb,القصدير:Sn,الزئبق:Hg,الكالسيوم:Ca,الهيليوم:He,النيون:Ne,الكلور:Cl,الزنك:Zn,اليود:I,الكبريت:S'.split(',').map(s=>s.split(':'));
const hs=s=>[...s].reduce((h,c)=>(h*31+c.charCodeAt(0))|0,7);
const mkq=(cat,level,q,ans,pool,w)=>{ans=String(ans);const o=new Set([ans]);let g=0;while(o.size<4&&g++<80)o.add(String(pool()));const a=shuf([...o]);return{id:'g'+hs(q),cat,level,q,a,c:a.indexOf(ans),w}};
function genQs(n){const R=k=>Math.random()*k|0,P=r=>r[R(r.length)],out=[];for(let i=0;i<n;i++){const t=R(7),ix=R(CAP.length),lv=ix<14?'سهل':ix<30?'متوسط':'صعب',[c,k]=CAP[ix],[en,es]=P(ELM);
if(t===0)out.push(mkq('جغرافيا',lv,`ما عاصمة ${c}؟`,k,()=>P(CAP)[1],`عاصمة ${c} هي ${k}.`));
else if(t===1)out.push(mkq('جغرافيا',lv,`${k} هي عاصمة أي دولة؟`,c,()=>P(CAP)[0],`${k} عاصمة ${c}.`));
else if(t===2)out.push(mkq('علوم','متوسط',`ما الرمز الكيميائي لعنصر ${en}؟`,es,()=>P(ELM)[1],`رمز ${en} هو ${es}.`));
else if(t===3)out.push(mkq('علوم','صعب',`أي عنصر رمزه ${es}؟`,en,()=>P(ELM)[0],`${es} هو رمز ${en}.`));
else if(t<6){const x=R(12)+6,y=R(12)+6;out.push(mkq('رياضيات','صعب',`كم يساوي ${x} × ${y}؟`,x*y,()=>x*y+(R(25)-12||13),`${x} × ${y} = ${x*y}.`))}
else{const p=P([10,15,20,25,30,40,60,75]),v=P([40,80,120,200,360,480]);out.push(mkq('رياضيات','متوسط',`ما قيمة ${p}% من ${v}؟`,p*v/100,()=>p*v/100+(R(21)-10||11),`${p}% × ${v} = ${p*v/100}.`))}}return out}
function seqQ(l){const R=k=>Math.random()*k|0,t=R(7),a0=2+R(9),d=2+R(5+l*2);let s=[],w='';
if(t===0){s=Array.from({length:7},(_,i)=>a0+d*i);w=`الفرق ثابت = ${d}.`}
else if(t===1){const q=2+R(2);s=Array.from({length:7},(_,i)=>a0*q**i);w=`كل عدد = السابق × ${q}.`}
else if(t===2){s=Array.from({length:7},(_,i)=>(i+1+l)**2+a0);w=`مربعات متتالية + ${a0}.`}
else if(t===3){s=[a0,a0+R(4)+1];for(let i=2;i<7;i++)s.push(s[i-1]+s[i-2]);w='كل عدد = مجموع العددين قبله.'}
else if(t===4){const e=2+R(5);s=Array.from({length:7},(_,i)=>i%2?a0+e*(i>>1):a0+30+d*(i>>1));w='سلسلتان متداخلتان.'}
else if(t===5){const k=1+(l>>1);let v=a0;for(let i=0;i<7;i++){s.push(v);v+=(i+1)*k}w='الفروق بين الأعداد تزيد بانتظام.'}
else{s=Array.from({length:7},(_,i)=>(i+1)**3+(l>1?a0:0));w='مكعبات متتالية.'}
const ans=s[6],set=new Set([ans]);while(set.size<4)set.add(ans+(R(2*d+6)-d-3||d+4));const o=shuf([...set]);
return{id:'s'+Date.now()+R(999),q:'\u202A'+s.slice(0,6).join(' ، ')+' ، ؟\u202C',a:o.map(String),c:o.indexOf(ans),w:w+` الجواب ${ans}.`}}
function gSeq(b,a){quizRun(b,a,Array.from({length:12},(_,i)=>seqQ(i/3|0)),{time:30,pts:1,names:[TT('أنت','You')]})}
const RID=[['ما الشيء الذي كلما أخذت منه كبر؟','الحفرة','الظل','الدين','الجبل','كلما حفرت أكثر كبرت الحفرة.'],
['له أسنان ولا يعض، ما هو؟','المشط','الأسد','الكلب','الثعبان',''],
['يمشي بلا أرجل ويبكي بلا عيون؟','السحاب','النهر','الريح','الليل','السحاب يسير وينزل مطرًا.'],
['أب وابنه في حادث، مات الأب، وقال الجراح: لا أستطيع العملية فهو ابني. من الجراح؟','أمه','عمه','جده','أبوه','الجراح هي أم الولد.'],
['معك 3 تفاحات وأخذت منها 2، كم تفاحة معك؟','2','1','3','5','الذي أخذته صار معك: تفاحتان.'],
['قطار كهربائي يسير شمالًا، إلى أين يتجه دخانه؟','لا دخان له','شمالًا','جنوبًا','شرقًا','القطار الكهربائي لا يُصدر دخانًا.'],
['كم مرة يمكنك طرح 5 من 25؟','مرة واحدة','5 مرات','4 مرات','لا يمكن','بعد المرة الأولى يصبح العدد 20.'],
['ما الشيء الذي يرتفع ولا ينزل؟','العمر','الطائرة','البالون','الدخان',''],
['غرفة فيها 4 زوايا، في كل زاوية قطة، وأمام كل قطة 3 قطط. كم قطة في الغرفة؟','4','12','16','8','كل قطة ترى القطط الثلاث الأخرى.'],
['تجاوزت المتسابق الثاني، فما ترتيبك؟','الثاني','الأول','الثالث','الرابع','أخذت مكانه فقط.'],
['مزارع عنده 17 خروفًا، مات كلها إلا 9. كم بقي؟','9','8','17','0',''],
['عدد إذا ضربته بنفسه ثم أضفت إليه نفسه كان الناتج 56، ما هو؟','7','6','8','9','7×7+7 = 56.'],
['كم يومًا بين 1 يناير و1 مارس في سنة غير كبيسة؟','59','58','60','61','31 + 28 = 59.'],
['ساعة تتأخر دقيقتين كل ساعة. كم تتأخر بعد 5 ساعات؟','10 دقائق','7 دقائق','12 دقيقة','5 دقائق','2 × 5 = 10.'],
['ثلاثة أمثال عدد ناقص 4 يساوي 20. ما العدد؟','8','6','7','9','(20+4)÷3 = 8.'],
['لو كان نصف 6 هو 3 فكم نصف 12 وثلثه؟','6 و4','6 و3','4 و6','5 و4','12÷2=6 و12÷3=4.']];
function gRiddle(b,a){quizRun(b,a,shuf(RID).slice(0,10).map(x=>{const o=shuf([x[1],x[2],x[3],x[4]]);return{q:x[0],a:o,c:o.indexOf(x[1]),w:x[5]||x[1]}}),{time:40,pts:1,names:[TT('أنت','You')]})}
function g2048(b,a){let G=Array.from({length:4},()=>Array(4).fill(0)),sc=0,over=false,won=false,px=null,py=0;
const add=()=>{const e=[];G.forEach((r,y)=>r.forEach((v,x)=>{if(!v)e.push([y,x])}));if(e.length){const [y,x]=e[Math.random()*e.length|0];G[y][x]=Math.random()<.9?2:4}};
const sl=r=>{const t=r.filter(Boolean);for(let i=0;i<t.length-1;i++)if(t[i]===t[i+1]){t[i]*=2;sc+=t[i];if(t[i]===2048&&!won){won=true;toast(TT('وصلت إلى 2048!','You reached 2048!'));SFX.fanfare()}t.splice(i+1,1)}while(t.length<4)t.push(0);return t};
const tr=g=>g[0].map((_,x)=>g.map(r=>r[x]));
const can=()=>G.some((r,y)=>r.some((v,x)=>!v||r[x+1]===v||(G[y+1]&&G[y+1][x]===v)));
const col=v=>v?`hsl(${(Math.log2(v)*37+250)%360} 65% ${v>4?52:38}%)`:'#ffffff12';
const draw=()=>{b.innerHTML=`<div class="info">${TT('النقاط','Score')} <b>${sc}</b></div><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;width:min(340px,92%);direction:ltr;touch-action:none;user-select:none">${G.flat().map(v=>`<div style="aspect-ratio:1;border-radius:12px;display:grid;place-items:center;font-weight:900;color:#fff;font-size:${v>=1024?20:v>=128?26:32}px;background:${col(v)}">${v||''}</div>`).join('')}</div><div class="row" style="width:min(340px,92%);direction:ltr">${[0,1,3,2].map(d=>`<button class="btn" data-d="${d}"><span style="display:inline-block;transform:rotate(${[-90,0,90,180][d]}deg)">${ic('up')}</span></button>`).join('')}</div>`};
const mv=d=>{if(over)return;const before=JSON.stringify(G);let g=G;if(d%2)g=tr(g);if(d>1)g=g.map(r=>[...r].reverse());g=g.map(sl);if(d>1)g=g.map(r=>r.reverse());if(d%2)g=tr(g);G=g;if(JSON.stringify(G)===before)return;add();SFX.merge();draw();if(!can()){over=true;const m=Math.max(...G.flat());a.t(()=>a.end(sc,TT('انتهت اللعبة - أعلى مربع '+m,'Game over - best tile '+m)),500)}};
b.onclick=e=>{const t=e.target.closest('[data-d]');if(t)mv(+t.dataset.d)};
b.onpointerdown=e=>{px=e.clientX;py=e.clientY};
b.onpointerup=e=>{if(px==null)return;const dx=e.clientX-px,dy=e.clientY-py;px=null;if(Math.max(Math.abs(dx),Math.abs(dy))<28)return;mv(Math.abs(dx)>Math.abs(dy)?(dx<0?0:2):(dy<0?1:3))};
KEYH={g:cur,f:e=>{const m={ArrowLeft:0,ArrowUp:1,ArrowRight:2,ArrowDown:3}[e.key];if(m==null)return false;mv(m);return true}};
add();add();draw()}
function gLights(b,a){const N=5;let G=Array(N*N).fill(0),mv=0;
const tg=i=>{const x=i%N,y=i/N|0;for(const [dx,dy] of [[0,0],[1,0],[-1,0],[0,1],[0,-1]]){const X=x+dx,Y=y+dy;if(X>=0&&X<N&&Y>=0&&Y<N)G[Y*N+X]^=1}};
for(let k=0;k<10+(Math.random()*6|0);k++)tg(Math.random()*25|0);if(!G.some(Boolean))tg(12);
const draw=()=>{b.innerHTML=`<div class="info">${TT('أطفئ كل الأضواء - الحركات','Turn all lights off - moves')}: <b>${mv}</b></div><div class="grid5" style="--n:5">${G.map((v,i)=>`<button class="cell" data-a="${i}" style="background:${v?'var(--p)':'#ffffff10'};box-shadow:${v?'0 0 16px var(--glow)':'none'}"></button>`).join('')}</div>`};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;tg(+t.dataset.a);mv++;SFX.tap();draw();if(!G.some(Boolean)){SFX.fanfare();a.end(mv,TT('أطفأت كل الأضواء في '+mv+' حركة','Solved in '+mv+' moves'))}};draw()}
function gSlide(b,a){const pick=()=>{b.innerHTML=`<div class="info">${TT('اختر حجم اللغز','Choose puzzle size')}</div><div class="opts"><button class="btn" data-n="3">3×3</button><button class="btn" data-n="4">4×4</button><button class="btn p" data-n="5">5×5</button></div>`;b.onclick=e=>{const t=e.target.closest('[data-n]');if(t)run(+t.dataset.n)}};
const run=N=>{const M=N*N;let T=[...Array(M).keys()].map(i=>(i+1)%M),z=M-1,mv=0,prev=-1;const nb=i=>[i-N,i+N,i%N?i-1:-1,(i+1)%N?i+1:-1].filter(j=>j>=0&&j<M);
for(let k=0;k<M*12;k++){const o=nb(z).filter(j=>j!==prev),j=o[Math.random()*o.length|0];T[z]=T[j];T[j]=0;prev=z;z=j}
const draw=()=>{b.innerHTML=`<div class="info">${TT('الحركات','Moves')}: <b>${mv}</b></div><div style="display:grid;grid-template-columns:repeat(${N},1fr);gap:6px;width:min(340px,92%);direction:ltr">${T.map((v,i)=>`<button class="cell" data-a="${i}" style="${v?'':'visibility:hidden;'}font-weight:900;font-size:${N>4?18:26}px;background:${v===i+1?'var(--glow)':'#ffffff14'}">${v||''}</button>`).join('')}</div>`};
b.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const i=+t.dataset.a;if(!nb(z).includes(i))return;T[z]=T[i];T[i]=0;z=i;mv++;SFX.slide();draw();if(T.every((v,k)=>v===(k+1)%M)){SFX.fanfare();a.end(mv,TT('حللت اللغز في '+mv+' حركة','Solved in '+mv+' moves'))}};draw()};pick()}
function gCode(b,a){const s=shuf([...'0123456789']).slice(0,4).join('');let tr=[];
const draw=()=>{b.innerHTML=`<div class="info">${TT('خمّن الرمز السري: 4 أرقام مختلفة - 10 محاولات','Crack the code: 4 distinct digits - 10 tries')}</div><div class="log" style="direction:ltr">${tr.map(t=>`<div class="ln"><b>${t.g}</b><span>● ${t.p} · ○ ${t.m}</span></div>`).join('')}</div><div class="info">● ${TT('رقم صحيح بمكانه','right place')} · ○ ${TT('رقم صحيح بمكان خاطئ','wrong place')}</div><input id="cg" inputmode="numeric" maxlength="4" placeholder="----" autocomplete="off" style="text-align:center;letter-spacing:8px;direction:ltr"><button class="btn p" data-a="go">${TT('تحقق','Check')} (${10-tr.length})</button>`};
const go=()=>{const i=b.querySelector('#cg'),v=i.value.trim();if(!/^\d{4}$/.test(v)||new Set(v).size<4){toast(TT('أدخل 4 أرقام مختلفة','Enter 4 distinct digits'),'err');SFX.bad();return}let p=0,c=0;for(let k=0;k<4;k++){if(v[k]===s[k])p++;if(s.includes(v[k]))c++}tr.push({g:v,p,m:c-p});SFX.tap();if(p===4){SFX.fanfare();a.end(tr.length,TT('فككت الشفرة '+s+' في '+tr.length+' محاولة','Cracked '+s+' in '+tr.length+' tries'));return}if(tr.length>=10){a.end(null,TT('الرمز كان '+s,'The code was '+s));return}draw();b.querySelector('#cg').focus()};
b.onclick=e=>{if(e.target.closest('[data-a]'))go()};b.onkeydown=e=>{if(e.key==='Enter')go()};draw()}
{const x=G.find(g=>g.id==='xo'),orig=x.run;x.run=(b,a)=>{b.innerHTML=`<div class="info">${TT('اختر مستوى الصعوبة','Choose difficulty')}</div><div class="opts">${[['سهل','Easy'],['متوسط','Medium'],['صعب','Hard'],['مستحيل','Impossible']].map((n,i)=>`<button class="btn ${i===3?'p':''}" data-xl="${i}">${TT(n[0],n[1])}</button>`).join('')}</div>`;b.onclick=e=>{const t=e.target.closest('[data-xl]');if(!t)return;XOP=[.2,.55,.85,1][+t.dataset.xl];orig(b,a)}}}
const NG=[['g2048','2048','grid','1','صعب','ادمج الأرقام المتشابهة للوصول إلى 2048 - اسحب أو استخدم الأسهم.',g2048,'اسحب في أي اتجاه لتتحرك كل المربعات. المربعان المتطابقان يندمجان. لا تدع اللوح يمتلئ.',0],
['lights','الأضواء','sun','1','صعب','كل ضغطة تقلب الخلية وجيرانها - أطفئ الكل بأقل حركات.',gLights,'اضغط خلية لتقلب حالتها وحالة الخلايا المجاورة. الهدف إطفاء كل الأضواء بأقل حركات.',1],
['slide','الأرقام المنزلقة','puzzle','1','صعب','رتّب البلاطات تصاعديًا بتحريكها نحو الفراغ - حتى 5×5.',gSlide,'اضغط البلاطة المجاورة للفراغ لتتحرك. رتّب الأرقام من 1 للنهاية بأقل حركات.',1],
['seqiq','السلاسل','brain','1','صعب','سلاسل أرقام تُولَّد عشوائيًا فلا تتكرر أبدًا، وتزداد صعوبتها.',gSeq,'اكتشف النمط واختر العدد الناقص. 12 سؤالًا، 30 ثانية لكل سؤال.',0],
['riddles','الألغاز','bulb','1','صعب','ألغاز وفخاخ منطقية بوقت محدد.',gRiddle,'اقرأ اللغز جيدًا - أغلب الإجابات فيها خدعة. 10 ألغاز عشوائية.',0],
['code','الشفرة','lock','1','صعب','خمّن رمزًا سريًا من 4 أرقام مختلفة بأقل محاولات.',gCode,'بعد كل تخمين تعرف كم رقمًا صحيحًا بمكانه وكم رقمًا صحيحًا بمكان خاطئ.',1]];
NG.forEach(x=>G.push({id:x[0],n:x[1],i:x[2],c:'ذكاء',p:x[3],l:x[4],d:x[5],run:x[6],r:x[7],low:x[8]?1:0,f:true}));
Object.assign(EN_X,{g2048:['2048 Merge','Merge matching tiles to reach 2048 - swipe or use arrows.',null],lights:['Lights Out','Each tap flips a cell and its neighbours - turn all off.',null],slide:['Sliding Puzzle','Slide tiles into order - up to 5×5.',null],seqiq:['IQ: Number Sequences','Endless generated sequences that never repeat.',null],riddles:['Logic Riddles','Tricky riddles against the clock.',null],code:['Code Breaker','Crack a 4-digit secret code in the fewest tries.',null]});
/* daily challenge + XP */
const DLY=['g2048','lights','slide','seqiq','riddles','code','xo','memory','number','odd','differences','scramble','quiz'],today=()=>new Date().toLocaleDateString('en-CA');
const dGame=()=>all().find(g=>g.id===DLY[Math.floor(Date.now()/864e5)%DLY.length]);
function renderDaily(){const el=$('#daily');if(!el)return;const g=dGame();if(fq||fc!=='الكل'||!g){el.innerHTML='';return}const done=S.daily&&S.daily.d===today()&&S.daily.done,xp=S.xp||0,lv=Math.floor(Math.sqrt(xp/25))+1,st=S.streak||{n:0,last:''},y=new Date(Date.now()-864e5).toLocaleDateString('en-CA'),sn=(st.last===today()||st.last===y)?st.n:0;
el.innerHTML=`<div class="card" style="display:flex;align-items:center;gap:10px;border-color:var(--p)"><div class="gi">${ic(done?'check':g.i)}</div><div style="flex:1;min-width:0"><b>${TT('التحدي اليومي','Daily challenge')}: ${esc(g.n)}</b><div class="mu" style="margin:2px 0 0">${TT('المستوى','Level')} ${lv} · ${TT('سلسلة','Streak')} ${sn} · XP ${xp}</div></div><button class="btn p" data-dly="1" aria-label="play">${ic('play')}</button><button class="btn" data-rnd="1" aria-label="random">${ic('shuffle')}</button></div>`}
$('#daily').onclick=e=>{const t=e.target.closest('[data-dly],[data-rnd]');if(!t)return;SFX.open();const g=t.dataset.rnd?shuf(all().filter(x=>String(x.p)==='1'))[0]:dGame();if(g)showDet(g.id)};
{const _end=api.end;api.end=function(sc,msg){_end.call(this,sc,msg);try{S.xp=(S.xp||0)+10;const dg=dGame();if(cur&&dg&&cur.id===dg.id&&!(S.daily&&S.daily.d===today()&&S.daily.done)){const y=new Date(Date.now()-864e5).toLocaleDateString('en-CA');S.daily={d:today(),done:true};S.streak={last:today(),n:(S.streak&&S.streak.last===y)?S.streak.n+1:1};S.xp+=40;toast(TT('أنجزت التحدي اليومي! +40 XP','Daily challenge done! +40 XP'));SFX.levelup()}save();renderDaily()}catch(e){}}}

const custToGame=g=>({id:g.id,n:g.n,i:ICON[g.i]?g.i:'quiz',r:'',c:g.c,p:g.players.length>1?'2-8':'1',l:'مخصص',d:g.d||`لعبة أسئلة من ${g.qs.length} سؤال`,run:(b,a)=>quizRun(b,a,g.qs,{time:g.time,pts:g.pts,names:g.players.length?g.players:['أنت']})});
const EN_GAME={zombie:['Zombie Survival: Last Stand','Zombie waves, rare weapons, shop & upgrades.','Epic'],dino:['Dino Runner','Jump over cacti at increasing speed.','Epic'],snake:['Snake','Eat, grow, avoid walls and yourself.','Epic'],flappy:['Flappy Flyer','Fly between the pipes.','Epic'],forbid:['Forbidden Word','Describe the secret word without saying the forbidden words.','Party'],sab:['Secret Saboteur','Everyone sees the word except the saboteur. Find them by voting.','Party'],score:['Team Scoreboard','Track points for two teams.','Teams & Scores'],most:['Who Is Most Likely?','Vote for the player who best fits each prompt.','Party'],categories:['Categories & Letters','Name something in a category beginning with the shown letter.','Party'],memory:['Memory Sequence','Memorize and repeat the color sequence.','Brain'],odd:['Find the Odd One','Tap the different symbol before time runs out.','Brain'],number:['Number Memory','Remember the number before it disappears.','Brain'],odd:['Find the Odd One','Tap the symbol that is different.','Brain'],match:['Card Match','Find matching pairs in as few moves as possible.','Strategy'],quiz:['Quiz Challenge','Random questions with answer explanations.','Brain'],c4:['Connect Four','Drop pieces and connect four in a row.','Strategy'],math:['Math Sprint','Solve as many equations as possible.','Speed'],forbid:['Forbidden Word','Describe the secret word without saying the forbidden words.','Party'],tap:['Tap Sprint','Tap quickly to build your score.','Speed'],reaction:['Reaction Test','React as soon as the signal appears.','Speed'],whack:['Target Smash','Hit targets as they appear.','Speed'],typing:['Typing Race','Type the displayed text accurately.','Speed'],typing:['Typing Race','Type the text accurately and quickly.','Speed'],guess:['Guess the Number','Find the hidden number.','Luck'],xo:['Tic-Tac-Toe vs Computer','Play X against the computer.','Strategy'],rps:['Rock Paper Scissors','Challenge the computer.','Luck'],dice:['Dice Duel','Roll and compare results.','Luck'],xo:['Tic-Tac-Toe','Play X against the computer.','Strategy'],connect4:['Connect Four','Connect four pieces in a row.','Strategy'],forbid:['Forbidden Word','Describe without saying forbidden words.','Teams'],sab:['Secret Saboteur','Find the player who does not know the word.','Party'],score:['Team Scoreboard','Track points for two teams.','Teams & Scores'],detect:['Detective','Solve a mystery from clues.','Party'],trivia:['Trivia Night','Take turns answering general knowledge questions.','Party'],most:['Most Likely To','Vote for the player who fits the prompt.','Party'],categories:['Categories & Letters','Find words that fit the category and letter.','Party'],secretword:['Odd Word','Find the player with the different word.','Party'],whoami:['Guess From Clues','Guess a person or thing from clues.','Party'],wordchain:['Word Chain','Start each word with the previous word’s last letter.','Party'],truth:['True or False','Test your knowledge and score points.','Party'],detect:['Detective','Solve the mystery from clues.','Party'],trivia:['Trivia Challenge','Take turns answering general knowledge questions.','Party'],differences:['Spot the Difference','Find five differences between two scenes.','Brain'],scramble:['Word Scramble','Unscramble Arabic and English words.','Brain'],mafia:['Mafia: Village vs Mafia','Secret roles, night actions, discussion, and voting.','Party'],categories2:['Category Sprint','Answer category prompts starting with a letter.','Party'],undercover:['Undercover Spy','Find the player who does not know the secret word.','Party'],charades:['Silent Charades','Act out the prompt without speaking.','Party'],fibbage:['Truth or Bluff','Answer group trivia questions.','Party'],telephone:['Telephone Remix','Pass a sentence around and watch it change.','Party']};
const EN_CATS={'ملحمي':'Epic','الكل':'All','مميزة':'Featured','ذكاء':'Brain','سرعة':'Speed','حظ':'Luck','استراتيجية':'Strategy','جماعي':'Party','فرق ونقاط':'Teams & Scores','ألعابي':'My Games','المفضلة':'Favorites','مؤخرًا':'Recent','فرق':'Teams','استراتيجية':'Strategy'};
const all=()=>[...G.map(g=>{if(LANG!=='en')return g;const x=EN_X[g.id]||EN_GAME[g.id];return x?Object.assign({},g,{n:x[0],d:x[1],c:x[2]||EN_CATS[g.c]||g.c}):g}),...S.custom.map(custToGame)];
/* Click ripples: lightweight, no external libraries */
document.addEventListener('pointerdown',e=>{const el=e.target.closest('button');if(!el||el.disabled||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const r=el.getBoundingClientRect(),d=Math.max(r.width,r.height)*.8,sp=document.createElement('span');sp.className='ripple';sp.style.width=sp.style.height=d+'px';sp.style.left=(e.clientX-r.left-d/2)+'px';sp.style.top=(e.clientY-r.top-d/2)+'px';el.appendChild(sp);setTimeout(()=>sp.remove(),600)},{passive:true});
/* ---------- library UI ---------- */
let fq='',fc='الكل',fp='all',fl='all';
const card=g=>`<div class="gc" data-id="${esc(g.id)}"><button class="fav" data-f="${esc(g.id)}" aria-label="مفضلة">${ic('star',S.fav.includes(g.id)?'f':'')}</button><div class="gi">${ic(g.i)}</div><b>${esc(g.n)}</b><small>${esc(g.d)}</small><div class="tags"><span>${g.c}</span><span>${ic('users')} ${g.p}</span><span>${g.l}</span>${S.best[g.id]!=null?`<span>أفضل: ${S.best[g.id]}</span>`:''}</div></div>`;
function renderChips(){$('#chips').innerHTML=['الكل','مميزة','أكشن','ألغاز','ذكاء','سرعة','حظ','استراتيجية','جماعي','فرق ونقاط','ألعابي','المفضلة','مؤخرًا'].map(c=>`<button class="chip ${c===fc?'on':''}" data-c="${c}">${LANG==='en'?(EN_CATS[c]||c):c}</button>`).join('')}
const inChip=g=>fc==='الكل'||g.c===fc||g.c===EN_CATS[fc]||(fc==='مميزة'&&g.f)||(fc==='ألعابي'&&S.custom.some(x=>x.id===g.id))||(fc==='المفضلة'&&S.fav.includes(g.id))||(fc==='مؤخرًا'&&S.recent.includes(g.id));
function renderLib(){
  try {
    const source=all();
    const l=source.filter(g=>{
      const categoryOK=inChip(g);
      const playersOK=fp==='all'||(fp==='1'?(String(g.p)==='1'):String(g.p)!=='1');
      const levelOK=fl==='all'||g.l===fl;
      const textOK=(String(g.n||'')+' '+String(g.d||'')+' '+String(g.c||'')).toLocaleLowerCase().includes(fq.toLocaleLowerCase());
      return categoryOK&&playersOK&&levelOK&&textOK;
    });
    // Render cards directly in one grid to avoid nested-grid/layout issues on mobile browsers.
    $('#lib').className='grid';
    $('#lib').innerHTML=l.length?l.map(card).join(''):'<div class="empty">'+(LANG==='en'?'No matching games. Clear search or filters.':'لا توجد ألعاب مطابقة. امسح البحث أو غيّر الفلاتر.')+'</div>';
    renderRec();
  } catch(err) {
    console.error('Library render failed',err);
    $('#lib').className='grid';
    $('#lib').innerHTML='<div class="empty">تعذّر عرض الألعاب. اضغط تحديث الصفحة، أو امسح البحث والفلاتر.</div>';
  }
}
function renderRec(){try{renderDaily()}catch(e){}const A=all(),r=S.recent.map(id=>A.find(g=>g.id===id)).filter(Boolean),ft=fc==='الكل'&&!fq?A.filter(g=>g.f):[];$('#rec').innerHTML=(ft.length?'<div class="lbl">'+ic('star')+' مميزة</div><div class="hs">'+ft.map(card).join('')+'</div>':'')+(r.length&&!fq?'<div class="lbl">'+ic('clock')+' آخر ما لعبت</div><div class="chips">'+r.map(g=>`<button class="chip" data-id="${esc(g.id)}">${ic(g.i)} ${esc(g.n)}</button>`).join('')+'</div>':'')}
function showDet(id){const g=all().find(x=>x.id===id);if(!g)return;const d=$('#det');d.innerHTML=`<div class="box"><div class="gi big">${ic(g.i)}</div><h3>${esc(g.n)}</h3><p class="mu">${esc(g.d)}</p><div class="tags" style="justify-content:center"><span>${g.c}</span><span>${ic('users')} ${g.p}</span><span>${g.l}</span></div>${g.r?`<div class="card" style="text-align:right"><b>طريقة اللعب</b><p class="mu">${esc(g.r)}</p></div>`:''}<p>أفضل نتيجة: ${S.best[id]??'—'} · مرات اللعب: ${S.plays[id]||0}</p><div class="row"><button class="btn p" data-d="play">${ic('play')} العب</button><button class="btn" data-d="fav">${ic('star',S.fav.includes(id)?'f':'')} ${S.fav.includes(id)?'في المفضلة':'للمفضلة'}</button><button class="btn" data-d="x">إغلاق</button></div></div>`;d.hidden=false;d.onclick=e=>{const k=e.target instanceof Element?e.target.closest('[data-d]'):null;if(e.target===d||(k&&k.dataset.d==='x')){d.hidden=true;return}if(!k)return;e.preventDefault();if(k.dataset.d==='play'){d.hidden=true;SFX.tap();openGame(g)}else{toggleFav(id);showDet(id)}}}
function toggleFav(id){S.fav=S.fav.includes(id)?S.fav.filter(x=>x!==id):[...S.fav,id];save();renderLib()}
/* FIX: <html data-f=font> matched closest('[data-f]') for every click, so cards never opened. Scope to the fav button only. */
const cardClick=e=>{const f=e.target.closest('button.fav[data-f]');if(f){toggleFav(f.dataset.f);SFX.tap();return}const c=e.target.closest('[data-id]');if(c){SFX.tap();showDet(c.dataset.id)}};
$('#lib').onclick=cardClick;$('#rec').onclick=cardClick;
$('#chips').onclick=e=>{const c=e.target.closest('[data-c]');if(c){fc=c.dataset.c;renderChips();renderLib();SFX.tap()}};
$('#q').oninput=e=>{fq=e.target.value.trim();renderLib()};$('#fpl').onchange=e=>{fp=e.target.value;renderLib()};$('#flv').onchange=e=>{fl=e.target.value;renderLib()};
/* ---------- creator ---------- */
let E=null,ppMk=null;
const newE=()=>({id:'',n:'',i:'quiz',d:'',c:'ذكاء',time:15,pts:10,players:[],qs:[]});
function valid(g){if(!g||typeof g.n!=='string'||g.n.trim().length<2)return 'اسم اللعبة قصير جدًا';if(!Array.isArray(g.qs)||!g.qs.length)return 'أضف سؤالًا واحدًا على الأقل';for(const q of g.qs){if(!q||typeof q.q!=='string'||!q.q.trim()||!Array.isArray(q.a)||q.a.length<2||q.a.some(x=>typeof x!=='string'||!x.trim())||!Number.isInteger(q.c)||q.c<0||q.c>=q.a.length)return 'سؤال غير صالح: '+String(q&&q.q).slice(0,30)}if(!(+g.time>=5&&+g.time<=120))return 'الوقت بين 5 و120 ثانية';if(!(+g.pts>=1&&+g.pts<=100))return 'النقاط بين 1 و100';return ''}
const norm=g=>({id:g.id||'c'+Date.now()+Math.random().toString(36).slice(2,5),n:g.n.trim().slice(0,30),i:ICON[g.i]?g.i:'quiz',d:String(g.d||'').trim().slice(0,80),c:CATS.includes(g.c)?g.c:'ذكاء',time:+g.time,pts:+g.pts,players:(Array.isArray(g.players)?g.players:String(g.players||'').split(/[,،]/)).map(s=>String(s).trim()).filter(Boolean).slice(0,8),qs:g.qs.map(q=>({q:q.q.trim(),a:q.a.map(x=>x.trim()),c:q.c}))});
function renderMake(){E=E||newE();const m=$('#v-make');m.innerHTML=`<h2>${ic('edit')} صانع الألعاب</h2><div class="card"><div class="lbl">اسم اللعبة</div><input data-k="n" value="${esc(E.n)}" maxlength="30"><div class="lbl">الوصف</div><input data-k="d" value="${esc(E.d)}" maxlength="80"><div class="row2"><div><div class="lbl">الأيقونة</div><select data-k="i">${[['quiz','سؤال'],['memory','ذاكرة'],['star','نجمة'],['trophy','كأس'],['react','برق'],['whack','هدف'],['users','فريق'],['flag','راية']].map(x=>`<option value="${x[0]}" ${x[0]===E.i?'selected':''}>${x[1]}</option>`).join('')}</select></div><div><div class="lbl">التصنيف</div><select data-k="c">${CATS.map(x=>`<option ${x===E.c?'selected':''}>${x}</option>`).join('')}</select></div></div><div class="row2"><div><div class="lbl">وقت السؤال (ث)</div><input data-k="time" type="number" value="${E.time}"></div><div><div class="lbl">نقاط السؤال</div><input data-k="pts" type="number" value="${E.pts}"></div></div><div data-pp></div></div>
<div class="card"><b>الأسئلة (${E.qs.length})</b>${E.qs.map((q,i)=>`<div class="ln"><span>${i+1}. ${esc(q.q)}</span><span><button class="ib" data-m="up" data-i="${i}">${ic('up')}</button><button class="ib" data-m="dn" data-i="${i}">${ic('down')}</button><button class="ib" data-m="del" data-i="${i}">${ic('close')}</button></span></div>`).join('')||'<div class="empty">لا أسئلة بعد</div>'}
<div class="lbl">سؤال جديد</div><input id="nq" placeholder="نص السؤال" maxlength="200">${[0,1,2,3].map(i=>`<input id="no${i}" placeholder="الخيار ${i+1}${i>1?' (اختياري)':''}" maxlength="80">`).join('')}<div class="lbl">الإجابة الصحيحة</div><select id="nc"><option value="0">الخيار 1</option><option value="1">الخيار 2</option><option value="2">الخيار 3</option><option value="3">الخيار 4</option></select><button class="btn" data-m="addq" style="width:100%;margin-top:8px">${ic('plus')} أضف السؤال</button></div>
<div class="row"><button class="btn p" data-m="save">${ic('check')} حفظ اللعبة</button><button class="btn" data-m="new">لعبة جديدة</button></div>
<div class="card"><b>ألعابي (${S.custom.length})</b>${S.custom.map(g=>`<div class="ln"><span>${ic(g.i)} ${esc(g.n)}</span><span><button class="ib" data-m="edit" data-id="${g.id}">${ic('edit')}</button><button class="ib" data-m="exp" data-id="${g.id}">${ic('download')}</button><button class="ib" data-m="rm" data-id="${g.id}">${ic('trash')}</button></span></div>`).join('')||'<div class="empty">لم تنشئ ألعابًا بعد</div>'}<div class="lbl">استيراد JSON</div><textarea id="jin" placeholder="ألصق JSON للعبة أو مصفوفة ألعاب"></textarea><button class="btn" data-m="imp" style="width:100%">${ic('upload')} استيراد</button></div>`;ppMk=playerPicker(m.querySelector('[data-pp]'),{key:'maker',min:0,max:8,roster:false,last:false,initial:E.players,title:TT('اللاعبون (اختياري) - يتناوبون على الأسئلة','Players (optional) - they take turns answering'),onChange:l=>{if(E)E.players=l}})}
$('#v-make').oninput=e=>{const k=e.target.dataset.k;if(k&&E)E[k]=e.target.value};
$('#v-make').onclick=async e=>{const t=e.target.closest('[data-m]');if(!t)return;const k=t.dataset.m,i=+t.dataset.i;SFX.tap();
if(k==='addq'){const q=$('#nq').value.trim(),o=[0,1,2,3].map(n=>$('#no'+n).value.trim()),ix=+$('#nc').value;if(!q){toast('اكتب نص السؤال','err');return}if(o.filter(Boolean).length<2){toast('أدخل خيارين على الأقل','err');return}if(!o[ix]){toast('الإجابة الصحيحة يجب أن تكون خيارًا مكتوبًا','err');return}E.qs.push({q,a:o.filter(Boolean),c:o.slice(0,ix).filter(Boolean).length});renderMake()}
else if(k==='up'&&i>0){[E.qs[i-1],E.qs[i]]=[E.qs[i],E.qs[i-1]];renderMake()}
else if(k==='dn'&&i<E.qs.length-1){[E.qs[i+1],E.qs[i]]=[E.qs[i],E.qs[i+1]];renderMake()}
else if(k==='del'){E.qs.splice(i,1);renderMake()}
else if(k==='save'){if(ppMk)ppMk.flush();const v=valid(E);if(v){toast(v,'err');return}const g=norm(E),x=S.custom.findIndex(c=>c.id===g.id);if(x>=0)S.custom[x]=g;else S.custom.push(g);save();E=null;toast('تم حفظ اللعبة');renderMake();renderLib()}
else if(k==='new'){E=null;renderMake()}
else if(k==='edit'){const g=S.custom.find(c=>c.id===t.dataset.id);if(g){E=clone(g);E.players=[...g.players];renderMake();scrollTo(0,0)}}
else if(k==='rm'){if(await cfm('حذف هذه اللعبة نهائيًا?')){const id=t.dataset.id;S.custom=S.custom.filter(c=>c.id!==id);delete S.best[id];delete S.plays[id];S.fav=S.fav.filter(x=>x!==id);S.recent=S.recent.filter(x=>x!==id);save();renderMake();renderLib()}}
else if(k==='exp'){const g=S.custom.find(c=>c.id===t.dataset.id);if(g){$('#jin').value=JSON.stringify(g,null,1);dl('game-'+g.id+'.json',JSON.stringify(g,null,1));toast('تم التصدير')}}
else if(k==='imp'){let j;try{j=JSON.parse($('#jin').value)}catch(x){toast('JSON غير صالح','err');return}const arr=Array.isArray(j)?j:[j];let n=0;for(const g of arr){const v=valid(g);if(v){toast(v,'err');continue}const c=norm(Object.assign({},g,{id:''}));S.custom.push(c);n++}if(n){save();toast('تم استيراد '+n+' لعبة');renderMake();renderLib()}}};
function dl(name,txt){try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'application/json'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}catch(e){}}
/* ---------- stats ---------- */
function renderStats(){const A=all(),tot=Object.values(S.plays).reduce((x,y)=>x+y,0),dif=Object.keys(S.plays).length;const ACH=[['play','أول لعبة',tot>=1],['react','٢٠ جولة',tot>=20],['search','جرّبت ٨ ألعاب مختلفة',dif>=8],['edit','أنشأت لعبة',S.custom.length>0],['star','٣ مفضلات',S.fav.length>=3]];
$('#v-stats').innerHTML=`<h2>${ic('trophy')} التقدم والإحصائيات</h2><div class="card"><b>${tot}</b> جولة · <b>${dif}</b> لعبة مختلفة</div><div class="card"><b>الإنجازات</b>${ACH.map(x=>`<div class="ach ${x[2]?'on':''}">${ic(x[2]?x[0]:'lock')} ${x[1]}</div>`).join('')}</div><div class="card"><b>أعلى النتائج</b>${A.filter(g=>S.best[g.id]!=null).map(g=>`<div class="ln"><span>${ic(g.i)} ${esc(g.n)}</span><b>${S.best[g.id]}</b></div>`).join('')||'<div class="empty">لم تلعب بعد</div>'}</div><div class="card"><b>مستوى الصوت</b><input type="range" id="vol" min="0" max="1" step=".1" value="${S.vol}"></div><div class="card"><b>نسخة احتياطية</b><p class="mu">البيانات محفوظة في هذا المتصفح فقط ولا تنتقل لجهاز آخر تلقائيًا - صدّرها ثم استوردها يدويًا.</p><div class="row"><button class="btn p" data-s="exp">${ic('download')} تصدير</button><button class="btn" data-s="imp">${ic('upload')} استيراد</button><button class="btn danger" data-s="rst">مسح الكل</button></div><textarea id="bk" placeholder="ألصق النسخة الاحتياطية هنا للاستيراد"></textarea></div>`}
$('#v-stats').oninput=e=>{if(e.target.id==='vol'){S.vol=+e.target.value;save();snd(660,.08)}};
$('#v-stats').onclick=async e=>{const t=e.target.closest('[data-s]');if(!t)return;const k=t.dataset.s;
if(k==='exp'){const j=JSON.stringify(S);$('#bk').value=j;dl('ahmed-games-backup.json',j);toast('تم التصدير')}
else if(k==='imp'){let j;try{j=JSON.parse($('#bk').value)}catch(x){toast('نسخة غير صالحة','err');return}if(!j||typeof j!=='object'||Array.isArray(j)){toast('نسخة غير صالحة','err');return}if(!(await cfm('سيتم استبدال بياناتك الحالية. متابعة?')))return;const n=Object.assign({},DEF,j);n.custom=(Array.isArray(n.custom)?n.custom:[]).filter(g=>!valid(g)).map(norm);for(const a of ['fav','recent'])if(!Array.isArray(n[a]))n[a]=[];['best','plays'].forEach(a=>{if(!n[a]||typeof n[a]!=='object')n[a]={}});S=n;save();applyTheme(S.theme);syncSnd();renderStats();renderLib();renderRec();toast('تمت الاستعادة')}
else if(k==='rst'){if(await cfm('مسح كل النتائج والألعاب المنشأة?')){S=Object.assign({},DEF,{fav:[],best:{},plays:{},recent:[],custom:[]});save();applyTheme(S.theme);renderStats();renderLib();renderRec()}}};
/* ---------- shell ---------- */
const TH={black:['#f2f2f2','#000000'],royal:['#a66cff','#0a0713'],red:['#e0344a','#120708'],blue:['#1ea0ff','#050c16'],green:['#2ecc71','#04120a'],gold:['#f5c542','#0d0a03']};
function applyTheme(t){if(!TH[t])t='royal';S.theme=t;document.documentElement.dataset.t=t;$('#tc').content=TH[t][1];$('#ths').innerHTML=Object.keys(TH).map(k=>`<button class="th ${k===t?'on':''}" data-t="${k}" style="background:${TH[k][0]}" aria-label="${k}"></button>`).join('');save()}
$('#ths').onclick=e=>{const b=e.target.closest('[data-t]');if(b){applyTheme(b.dataset.t);SFX.tap()}};
$('#settingsBtn').innerHTML=ic('gear');$('#settingsBtn').onclick=()=>{const d=$('#det');d.innerHTML=`<div class="box"><h3>الإعدادات / Settings</h3><label>الثيم</label><div class="row">${Object.keys(TH).map(k=>`<button class="btn" data-theme="${k}">${k}</button>`).join('')}</div><label>الصوت</label><div class="row"><button class="btn" data-setting="mute">${S.mute?'تشغيل الصوت':'كتم الصوت'}</button><input id="settingVol" type="range" min="0" max="1" step=".1" value="${S.vol}"></div><label><input id="motionToggle" type="checkbox" ${S.motion===false?'':'checked'} style="width:auto;min-height:0"> الحركة والمؤثرات</label><button class="btn p" data-setting="xpanel" style="width:100%;margin:8px 0">🎛 المظهر والخلفية والأنيميشن والصوت</button><button class="btn danger" data-setting="reset">إعادة ضبط البيانات</button><button class="btn" data-setting="close">إغلاق</button></div>`;d.hidden=false;d.onclick=async e=>{const t=e.target.closest('[data-theme],[data-setting]');if(t?.dataset.theme){applyTheme(t.dataset.theme);return}if(!t)return;if(t.dataset.setting==='close'){d.hidden=true;return}if(t.dataset.setting==='xpanel'){d.hidden=true;xPanel();return}if(t.dataset.setting==='mute'){S.mute=!S.mute;save();syncSnd();t.textContent=S.mute?'تشغيل الصوت':'كتم الصوت';SFX.tap();return}if(t.dataset.setting==='reset'&&await cfm('سيتم مسح المفضلة والنتائج والألعاب المخصصة. هل أنت متأكد؟')){S=Object.assign({},DEF);save();applyTheme(S.theme);renderLib();renderRec();renderStats();d.hidden=true}};d.oninput=e=>{if(e.target.id==='settingVol'){S.vol=+e.target.value;save();SFX.pop()}if(e.target.id==='motionToggle'){S.motion=e.target.checked;document.documentElement.classList.toggle('no-motion',!S.motion);save()}}};
function applyLanguage(){const en=LANG==='en';document.documentElement.lang=LANG;document.documentElement.dir=en?'ltr':'rtl';$('#langBtn').textContent=en?'AR':'EN';document.querySelector('.hero h1').textContent=en?'Game Studio':'منصة الألعاب';document.querySelector('.hero p').textContent=en?'A collection of solo and party games - all on one device':'ألعاب حقيقية قابلة للّعب - فردية وجماعية على جهاز واحد';$('#q').placeholder=en?'Search games…':'ابحث عن لعبة…';const navLabels=en?['Games','Game Maker','Stats']:['الألعاب','صانع الألعاب','تقدّمي'];document.querySelectorAll('nav [data-v]').forEach((n,i)=>{const sp=n.querySelector('span');if(sp)sp.textContent=navLabels[i]||sp.textContent});$('#settingsBtn').setAttribute('aria-label',en?'Settings':'الإعدادات');syncRoster();const titles=document.querySelectorAll('#v-make h2,#v-stats h2');if($('#v-make').hidden===false)renderMake();if($('#v-stats').hidden===false)renderStats();renderChips();renderLib();renderRec();save()}
$('#langBtn').onclick=()=>{LANG=LANG==='ar'?'en':'ar';applyLanguage()};
const UI_EN={"تسلسل الذاكرة":"Memory Sequence","ذاكرة الأرقام":"Number Memory","اكتشف المختلف":"Find the Odd One","مطابقة البطاقات":"Card Match","تحدي الأسئلة":"Quiz Challenge","سرعة الحساب":"Math Sprint","سرعة الضغط":"Tap Sprint","سرعة الاستجابة":"Reaction Test","صيد الأهداف":"Target Smash","تحدي الكتابة":"Typing Race","خمّن الرقم":"Guess the Number","حجر ورقة مقص":"Rock Paper Scissors","حظ النرد":"Dice Roll","XO ضد الكمبيوتر":"Tic-Tac-Toe vs Computer","أربع قطع متتالية":"Connect Four","الكلمة المحظورة":"Forbidden Word","المخرب السري":"Secret Saboteur","لوحة النقاط والفرق":"Team Scoreboard","المحقق":"Detective","تحدي المعلومات":"Trivia Challenge","من الأكثر؟":"Who Is Most Likely?","تحدي الفئات والحروف":"Categories & Letters","الكلمة المختلفة":"Odd Word","خمنها من الأدلة":"Guess From Clues","سلسلة الكلمات":"Word Chain","حقيقة أم خدعة":"True or False","أوجد الفرق":"Spot the Difference","رتّب الأحرف":"Word Scramble","المافيا - من القاتل":"Mafia: Village vs Mafia","تحدي الفئات السريع":"Category Sprint","الجاسوس المتخفي":"Undercover Spy","تمثيل بدون كلام":"Silent Charades","الحقيقة والخدعة":"Truth or Bluff","الهاتف الخربان":"Telephone Remix","اكتب اسم اللعبة":"Enter a game name","اكتب إجابتك":"Type your answer","أدخل إجابة أولًا":"Enter an answer first","أدخل لاعبين على الأقل":"Enter at least two players","أدخل 3 لاعبين على الأقل":"Enter at least three players","إجابة صحيحة":"Correct answer","إجابة خاطئة":"Incorrect answer","صحيح!":"Correct!","غير صحيح":"Incorrect","جرب مرة أخرى":"Try again","جرّب مرة أخرى":"Try again","انتهت اللعبة":"Game over","انتهى التحدي":"Challenge complete","النقاط":"Points","أفضل نتيجة":"Best score","أعلى النتائج":"Top scores","التقدم والإحصائيات":"Progress & Stats","الإنجازات":"Achievements","نسخة احتياطية":"Backup","لا توجد ألعاب مطابقة":"No matching games","ابحث عن لعبة…":"Search games…","راقب التسلسل":"Watch the sequence","دورك!":"Your turn!","المستوى":"Level","احفظه…":"Memorize it…","اكتب الرقم":"Enter the number","اكتب الكلمة الصحيحة":"Enter the correct word","رتّب الأحرف لتكوين كلمة":"Unscramble the letters to form a word","اكتشف 5 فروقات في المشهد الأيمن":"Find 5 differences in the right scene","المشهد A":"Scene A","المشهد B - اضغط على الفروقات":"Scene B - tap the differences","اكتُشف":"Found","المتبقي":"Remaining","ابحث عن تفاصيل مختلفة بين المشهدين.":"Look for details that differ between the scenes.","ممتاز! اكتشفت الفروقات الخمسة.":"Great! You found all five differences.","هذا الفرق محسوب بالفعل.":"That difference has already been counted.","سوّ كلمات عربي وإنجليزي من حروف مبعثرة.":"Unscramble Arabic and English words.","الجولة":"Round","تحدي الفئات":"Category challenge","اذكر":"Name a","يبدأ بهذا الحرف":"starting with this letter","تأكيد":"Confirm","تخطّ":"Skip","أدخل 4 أسماء مختلفة على الأقل":"Enter at least four unique names","الأدوار":"Roles","أهل القرية":"Villagers","الطبيب":"Doctor","الشايب":"Elder","المافيا":"Mafia","ليل ونهار":"Night and day","توزيع الأدوار سرًا":"Deal secret roles","نقاش وتصويت":"Discussion and vote","ابدأ النقاش والتصويت":"Start discussion and vote","مرّر الجهاز إلى":"Pass the device to","اكشف دوري":"Reveal my role","إخفاء وتمرير":"Hide and pass","الليل - مرّر الجهاز إلى":"Night - pass the device to","تأكد أن الآخرين لا ينظرون.":"Make sure nobody else is looking.","أنا جاهز":"I'm ready","اختيار سري - لا تكشفوا الاختيار للآخرين.":"Secret choice - do not reveal the choice to others.","المافيا: اختاروا هدفًا":"Mafia: choose a target","الطبيب: من تريد إنقاذه؟":"Doctor: who will you save?","الشايب: من تريد فحصه؟":"Elder: who will you investigate?","نتيجة فحص الشايب":"Elder investigation result","من المافيا!":"is Mafia!","ليس من المافيا.":"is not Mafia.","صباح القرية - الجولة":"Village morning - round","صباح القرية":"Village morning","لم يخرج أحد هذه الليلة.":"Nobody was eliminated tonight.","خرج من اللعبة خلال الليل.":"was eliminated during the night.","اللاعبون الباقون:":"Players remaining:","ابدأ الليل التالي":"Start next night","تعادل التصويت - لا إقصاء.":"Vote tied - nobody is eliminated.","نتائج التصويت:":"Vote results:","الأصوات المسجلة:":"Votes recorded:","امتناع":"Abstain","الطبيب: من تريد إنقاذه؟":"Doctor: who will you save?","الجاسوس كان:":"The spy was:","الكلمة:":"Word:","كشفتم الجاسوس!":"Spy found!","نجا الجاسوس!":"The spy escaped!","الجملة الأصلية والتحولات":"Original and transformations","اكتب جملة مضحكة":"Write a funny sentence","تمرير للاعب التالي":"Pass to next player","اكتب الجملة أولًا":"Write the sentence first","الألعاب":"Games","صانع الألعاب":"Game Maker","تقدّمي":"Stats","الإعدادات / Settings":"Settings","الثيم":"Theme","الصوت":"Sound","تشغيل الصوت":"Enable sound","كتم الصوت":"Mute sound","الحركة والمؤثرات":"Motion and effects","إعادة ضبط البيانات":"Reset data","إغلاق":"Close","الكل":"All","مميزة":"Featured","ذكاء":"Brain","سرعة":"Speed","حظ":"Luck","استراتيجية":"Strategy","جماعي":"Party","فرق ونقاط":"Teams & Scores","ألعابي":"My Games","المفضلة":"Favorites","مؤخرًا":"Recent","لا توجد ألعاب مطابقة":"No matching games","طريقة اللعب":"How to play","أفضل نتيجة:":"Best score:","مرات اللعب:":"Times played:","في المفضلة":"In favorites","للمفضلة":"Add to favorites","العب":"Play","إغلاق اللعبة?":"Close game?","جولة جديدة":"New round","إعادة":"Restart","القائمة":"Menu","أضف السؤال":"Add question","حفظ اللعبة":"Save game","لعبة جديدة":"New game","اسم اللعبة":"Game name","الوصف":"Description","التصنيف":"Category","أيقونة":"Icon","سؤال جديد":"New question","الإجابة الصحيحة":"Correct answer","أضف السؤال":"Add question","لا أسئلة بعد":"No questions yet","استيراد JSON":"Import JSON","تصدير":"Export","استيراد":"Import","مسح الكل":"Clear all","أعلى النتائج":"Top scores","الإنجازات":"Achievements","نسخة احتياطية":"Backup","تم حفظ اللعبة":"Game saved","اكتب إجابتك":"Type your answer","تحقق":"Check","تخطّ":"Skip","صحيح":"Correct","غير صحيح":"Incorrect","ابدأ":"Start","التالي":"Next","نقاط":"Points","الوقت":"Time","الجولة":"Round","المتبقي":"Remaining","تمرير الجهاز إلى":"Pass the device to","اكشف دورك":"Reveal your role","إخفاء وتمرير":"Hide and pass","فاز أهل القرية!":"The village wins!","فازت المافيا!":"The Mafia wins!","الليل":"Night","النهار":"Day","صوّتوا":"Vote","التصويت":"Voting","تم إقصاؤه":"was eliminated","لم يخرج أحد هذه الليلة.":"Nobody was eliminated tonight.","الإجابة الصحيحة":"Correct answer","ليست الكلمة المطلوبة، جرّب مرة أخرى.":"Not the right word. Try again."};
function translateVisible(){if(LANG!=='en')return;const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);for(const n of nodes){let v=n.nodeValue;for(const [ar,en] of Object.entries(UI_EN).sort((a,b)=>b[0].length-a[0].length)){if(v.includes(ar))v=v.split(ar).join(en)}if(v!==n.nodeValue)n.nodeValue=v}document.querySelectorAll('[placeholder],[title],[aria-label]').forEach(el=>{for(const attr of ['placeholder','title','aria-label'])if(el.hasAttribute(attr)){let v=el.getAttribute(attr);if(UI_EN[v])el.setAttribute(attr,UI_EN[v])}})}
const langObserver=new MutationObserver(()=>{if(LANG==='en')translateVisible()});langObserver.observe(document.body,{childList:true,subtree:true,characterData:true});
const syncSnd=()=>{$('#snd').innerHTML=ic(S.mute?'mute':'sound')};
$('#snd').onclick=()=>{S.mute=!S.mute;save();syncSnd();SFX.tap()};
function showView(v){['home','make','stats'].forEach(x=>$('#v-'+x).hidden=x!==v);document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));if(v==='make')renderMake();if(v==='stats')renderStats();scrollTo(0,0)}
document.querySelector('nav').onclick=e=>{const b=e.target.closest('[data-v]');if(b){SFX.tap();showView(b.dataset.v)}};
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&$('#gv').className==='big'&&false)setMode('')});
window.addEventListener('error',e=>{console.error(e.message);toast('حدث خطأ غير متوقع','err')});window.addEventListener('unhandledrejection',e=>console.error(e.reason));
/* ===== v4: settings (appearance / sound / language / general) ===== */
const THN={royal:['ملكي','Royal'],black:['أسود','Black'],red:['أحمر','Red'],blue:['أزرق','Blue'],green:['أخضر','Green'],gold:['ذهبي','Gold'],ocean:['محيط','Ocean'],sunset:['غروب','Sunset'],mint:['نعناع','Mint'],rose:['وردي','Rose'],neon:['نيون','Neon'],cyber:['سايبر','Cyber'],forest:['غابة','Forest'],coffee:['قهوة','Coffee'],ice:['جليد','Ice'],lava:['حمم','Lava'],sakura:['ساكورا','Sakura'],midnight:['منتصف الليل','Midnight'],matrix:['ماتركس','Matrix'],amethyst:['جمشت','Amethyst'],light:['فاتح','Light']};
Object.assign(TH,{ocean:['#00b4d8','#03111c'],sunset:['#ff7b54','#160a12'],mint:['#3ef2c0','#04130f'],rose:['#ff5fa2','#170811'],neon:['#ff2bd6','#07020f'],cyber:['#fcee0a','#030a0a'],forest:['#6bbf59','#07100a'],coffee:['#c8864a','#120c08'],ice:['#8ecbff','#08121a'],lava:['#ff4500','#150603'],sakura:['#f7a8c8','#140b10'],midnight:['#6c7bff','#02030a'],matrix:['#00ff41','#000a02'],amethyst:['#c77dff','#0e0716'],light:['#6d3df5','#f3f1fb']});
const FONTS=[['system','النظام','System',"'Segoe UI',Tahoma,system-ui,Arial,sans-serif"],['tajawal','تجوّل','Tajawal',"'Tajawal'"],['cairo','القاهرة','Cairo',"'Cairo'"],['almarai','المرعي','Almarai',"'Almarai'"],['changa','تشانجا','Changa',"'Changa'"],['lalezar','لاليزار','Lalezar',"'Lalezar'"],['reem','ريم كوفي','Reem Kufi',"'Reem Kufi'"],['amiri','أميري','Amiri',"'Amiri'"],['rubik','روبيك','Rubik',"'Rubik'"],['kufi','نوتو كوفي','Noto Kufi',"'Noto Kufi Arabic'"],['mada','مدى','Mada',"'Mada'"],['messiri','المسيري','El Messiri',"'El Messiri'"],['marhey','مرحي','Marhey',"'Marhey'"],['baloo','بالو','Baloo',"'Baloo Bhaijaan 2'"]];
const BGS=[['glow','توهج','Glow'],['solid','سادة','Solid'],['grid','شبكة','Grid'],['dots','نقاط','Dots'],['stars','نجوم','Stars'],['aurora','شفق','Aurora']],CST=[['glass','زجاجي','Glass'],['flat','مسطح','Flat'],['outline','حدود','Outline'],['neon','نيون','Neon']],RDS=[['sharp','حادة','Sharp'],['soft','ناعمة','Soft'],['round','دائرية','Round']],PCK=[['arcade','أركيد','Arcade'],['soft','ناعم','Soft'],['retro','قديم','Retro'],['crystal','كريستال','Crystal']];
function applyLook(){const h=document.documentElement;h.dataset.f=S.font||'system';h.dataset.bg=S.bg||'glow';h.dataset.cs=S.cs||'glass';h.dataset.rd=S.rd||'soft';h.style.setProperty('--fz',(S.fz||100)/100);if(S.acc){h.style.setProperty('--p',S.acc);h.style.setProperty('--glow',S.acc+'44')}else{h.style.removeProperty('--p');h.style.removeProperty('--glow')}}
let musT=null;function musOn(){clearInterval(musT);musT=null;if(!S.music||S.mute)return;const sc=[262,294,330,392,440,523,588,659];musT=setInterval(()=>{if(document.hidden)return;tone(sc[Math.random()*sc.length|0]/(Math.random()<.3?2:1),.9,'sine',{v:.05})},650)}
let stab='look';
function openSettings(){const d=$('#det'),old=d.firstElementChild,sc=old?old.scrollTop:0;
const sw=(arr,key,cur)=>arr.map(x=>`<button class="btn ${cur===x[0]?'p':''}" data-set="${key}" data-v="${x[0]}">${TT(x[1],x[2])}</button>`).join('');
const tabs=[['look','palette','المظهر','Appearance'],['sound','sound','الصوت','Sound'],['lang','globe','اللغة','Language'],['more','gear','عام','General']];
let h=`<div class="box" style="text-align:start"><div class="row" style="margin:0 0 8px;align-items:center;flex-wrap:nowrap"><h3 style="margin:0;flex:1">${ic('gear')} ${TT('الإعدادات','Settings')}</h3><button class="ib" data-set="close" aria-label="close" style="flex:none;min-width:44px">${ic('close')}</button></div><div class="row set-tabs">${tabs.map(t=>`<button class="btn ${stab===t[0]?'p':''}" data-tab="${t[0]}">${ic(t[1])} ${TT(t[2],t[3])}</button>`).join('')}</div>`;
if(stab==='look')h+=`<div class="sl">${TT('الألوان','Colors')}</div><div class="swg">${Object.keys(TH).map(k=>`<button class="swt ${S.theme===k&&!S.acc?'on':''}" data-theme="${k}" style="--a:${TH[k][0]};--b:${TH[k][1]}"><i></i>${esc(TT(...(THN[k]||[k,k])))}</button>`).join('')}</div>
<div class="sl">${TT('لون مخصص','Custom accent')}</div><div class="row"><input id="sAcc" type="color" value="${S.acc||TH[S.theme][0]}" style="min-height:46px;padding:4px"><button class="btn" data-set="accx">${TT('إلغاء اللون المخصص','Reset accent')}</button></div>
<div class="sl">${TT('الخط','Font')}</div><div class="fgrid">${FONTS.map(f=>`<button class="btn ${(S.font||'system')===f[0]?'p':''}" data-set="font" data-v="${f[0]}" style="font-family:${f[3]}">${TT(f[1],f[2])}</button>`).join('')}</div>
<div class="sl">${TT('حجم الخط','Font size')}</div><input id="sFz" type="range" min="85" max="135" step="5" value="${S.fz||100}">
<div class="sl">${TT('الخلفية','Background')}</div><div class="fgrid">${sw(BGS,'bg',S.bg||'glow')}</div>
<div class="sl">${TT('شكل البطاقات','Card style')}</div><div class="fgrid">${sw(CST,'cs',S.cs||'glass')}</div>
<div class="sl">${TT('الزوايا','Corners')}</div><div class="fgrid">${sw(RDS,'rd',S.rd||'soft')}</div>`;
else if(stab==='sound')h+=`<div class="row"><button class="btn ${S.mute?'danger':'good'}" data-set="mute">${ic(S.mute?'mute':'sound')} ${S.mute?TT('الصوت مكتوم','Muted'):TT('الصوت يعمل','Sound on')}</button><button class="btn" data-set="test">${ic('play')} ${TT('تجربة','Test')}</button></div>
<div class="sl">${TT('مستوى الصوت','Volume')}</div><input id="sVol" type="range" min="0" max="1" step=".05" value="${S.vol}">
<div class="sl">${TT('نمط الأصوات','Sound pack')}</div><div class="fgrid">${sw(PCK,'pack',S.pack||'arcade')}</div>
<div class="sl">${TT('موسيقى خلفية هادئة','Ambient music')}</div><button class="btn ${S.music?'good':''}" data-set="music">${S.music?TT('تعمل','On'):TT('متوقفة','Off')}</button>
<div class="sl">${TT('الاهتزاز','Vibration')}</div><button class="btn ${S.vib===false?'':'good'}" data-set="vib">${S.vib===false?TT('متوقف','Off'):TT('يعمل','On')}</button>`;
else if(stab==='lang')h+=`<div class="sl">${TT('لغة الواجهة','Interface language')}</div><div class="fgrid"><button class="btn ${LANG==='ar'?'p':''}" data-set="lang" data-v="ar">العربية</button><button class="btn ${LANG==='en'?'p':''}" data-set="lang" data-v="en">English</button></div>`;
else h+=`<div class="sl">${TT('الحركة والمؤثرات','Motion & effects')}</div><button class="btn ${S.motion===false?'':'good'}" data-set="motion">${S.motion===false?TT('متوقفة','Off'):TT('تعمل','On')}</button>
<div class="sl">${TT('البيانات','Data')}</div><div class="row"><button class="btn" data-set="exp">${ic('download')} ${TT('نسخة احتياطية','Backup')}</button><button class="btn danger" data-set="reset">${ic('trash')} ${TT('إعادة ضبط','Reset')}</button></div>`;
d.innerHTML=h+'</div>';d.hidden=false;if(d.firstElementChild)d.firstElementChild.scrollTop=sc;
d.onclick=async e=>{if(e.target===d){d.hidden=true;return}const t=e.target.closest('[data-tab],[data-set],[data-theme]');if(!t)return;const D=t.dataset,k=D.set,v=D.v;
if(D.tab){stab=D.tab;SFX.tap();return openSettings()}
if(D.theme){S.acc='';applyTheme(D.theme);applyLook();SFX.select();return openSettings()}
if(k==='close'){d.hidden=true;SFX.close();return}
if(k==='lang'){if(LANG!==v){LANG=v;applyLanguage()}return openSettings()}
if(k==='reset'){if(await cfm(TT('سيتم مسح المفضلة والنتائج والألعاب المخصصة. هل أنت متأكد؟','This will erase favorites, scores and custom games. Sure?'))){S=clone(DEF);save();applyTheme(S.theme);applyLook();musOn();syncSnd();renderLib();renderStats();d.hidden=true}return}
if(k==='mute'){S.mute=!S.mute;syncSnd();musOn()}else if(k==='test')SFX.win();else if(k==='accx')S.acc='';else if(k==='motion'){S.motion=S.motion===false;document.documentElement.classList.toggle('no-motion',S.motion===false)}else if(k==='vib')S.vib=S.vib===false;else if(k==='music'){S.music=!S.music;musOn()}else if(k==='exp'){dl('ahmed-games-backup.json',JSON.stringify(S));toast(TT('تم التصدير','Exported'));return}else S[k]=v;
save();applyLook();if(k!=='test')SFX.select();openSettings()};
d.oninput=e=>{const i=e.target;if(i.id==='sVol'){S.vol=+i.value;save();SFX.pop()}else if(i.id==='sFz'){S.fz=+i.value;save();applyLook()}else if(i.id==='sAcc'){S.acc=i.value;save();applyLook()}}}
$('#settingsBtn').onclick=()=>{SFX.open();openSettings()};
applyLook();musOn();

try{document.querySelectorAll('[data-ic]').forEach(n=>n.innerHTML=ic(n.dataset.ic));applyTheme(S.theme);applyLook();document.documentElement.classList.toggle('no-motion',S.motion===false);syncSnd();$('#settingsBtn').innerHTML=ic('gear');syncRoster();renderChips();renderLib()}catch(err){console.error(err);document.body.insertAdjacentHTML('afterbegin','<div class="card">تعذّر تحميل البيانات. أعد فتح الصفحة أو امسح بيانات الموقع.</div>')}
/* ===== Epic helpers ===== */
function EL(a,t,e,f,o){t.addEventListener(e,f,o);a.cu.push(()=>t.removeEventListener(e,f,o))}
function LOOP(a,f){let id,l=performance.now(),on=1;const r=n=>{if(!on)return;f(Math.min(.05,(n-l)/1000));l=n;id=requestAnimationFrame(r)};id=requestAnimationFrame(r);const st=()=>{on=0;cancelAnimationFrame(id)};a.cu.push(st);return st}
function CV(b,w,h){b.innerHTML='<canvas width="'+w+'" height="'+h+'" style="width:100%;max-width:'+w+'px;touch-action:none;background:#0d0a1a;border-radius:14px;border:1px solid var(--line);display:block;margin:auto"></canvas><div class="info" style="text-align:center;margin-top:8px" id="ei"></div>';return b.firstChild}
function KEYS(a,map){EL(a,document,'keydown',e=>{const f=map[e.code]||map[e.key];if(f){e.preventDefault();f()}})}
/* ===== Rock Paper Scissors (SVG hands) ===== */
function gRps(b,a){
if(!document.getElementById('rpsCss')){const s=document.createElement('style');s.id='rpsCss';s.textContent='.rh{width:min(40vw,150px);transition:transform .25s}.rh svg{width:100%;display:block}.rh.sh{animation:rsh .35s ease-in-out infinite}.rh.w{animation:rw .6s ease 2}.rh.l{opacity:.55;transform:scale(.88)}@keyframes rsh{50%{transform:translateY(-22px) rotate(-6deg)}}@keyframes rw{50%{transform:scale(1.18)}}.rn{font-weight:900;text-align:center;margin-bottom:6px;letter-spacing:1px}.rc{font-size:44px;font-weight:900;text-align:center;min-height:56px;color:var(--p2)}';document.head.appendChild(s)}
const N=['حجر','ورقة','مقص'];let me=0,cp=0,mode='cpu',lvl=1,pk=[null,null],busy=0,hist=[1,1,1];
const H=(t,c)=>{const f='fill="'+c+'" stroke="#0009" stroke-width="3" stroke-linejoin="round"';return'<svg viewBox="0 0 120 130">'+[
'<rect x="26" y="46" width="68" height="62" rx="24" '+f+'/><circle cx="40" cy="46" r="11" '+f+'/><circle cx="56" cy="42" r="11" '+f+'/><circle cx="72" cy="42" r="11" '+f+'/><circle cx="87" cy="47" r="10" '+f+'/><rect x="30" y="68" width="40" height="17" rx="8" '+f+'/>',
'<rect x="30" y="64" width="60" height="52" rx="16" '+f+'/><rect x="30" y="18" width="14" height="54" rx="7" '+f+'/><rect x="46" y="8" width="14" height="62" rx="7" '+f+'/><rect x="62" y="6" width="14" height="64" rx="7" '+f+'/><rect x="78" y="16" width="14" height="56" rx="7" '+f+'/><rect x="2" y="64" width="38" height="14" rx="7" transform="rotate(35 20 70)" '+f+'/>',
'<g transform="rotate(-13 46 82)"><rect x="38" y="4" width="16" height="84" rx="8" '+f+'/><rect x="41" y="9" width="10" height="13" rx="5" fill="#fff6"/></g><g transform="rotate(13 74 82)"><rect x="66" y="4" width="16" height="84" rx="8" '+f+'/><rect x="69" y="9" width="10" height="13" rx="5" fill="#fff6"/></g><rect x="30" y="70" width="62" height="48" rx="20" '+f+'/><circle cx="80" cy="82" r="10" '+f+'/><circle cx="90" cy="96" r="9" '+f+'/><path d="M72 88q6 6 14 2M80 104q6 3 11-3" fill="none" stroke="#0007" stroke-width="2.5" stroke-linecap="round"/><rect x="14" y="88" width="46" height="16" rx="8" transform="rotate(-10 40 96)" '+f+'/>'][t]+'</svg>'};
function ui(m){b.innerHTML='<div class="row" style="justify-content:center"><button class="btn'+(mode=='cpu'?' p':'')+'" data-m="cpu">ضد الكمبيوتر</button><button class="btn'+(mode=='2p'?' p':'')+'" data-m="2p">لاعبان</button>'+(mode=='cpu'?['سهل','متوسط','صعب'].map((x,i)=>'<button class="btn'+(lvl==i?' p':'')+'" data-l="'+i+'">'+x+'</button>').join(''):'')+'</div><div class="info" id="ri">'+(mode=='cpu'?'أول من يصل إلى 3 - اختر (1/2/3 أو A/S/D)':'لاعب 1: A S D - لاعب 2: J K L')+'</div><div style="display:flex;justify-content:space-around;align-items:flex-end;margin:12px 0"><div><div class="rn">'+(mode=='cpu'?'أنت':'لاعب 1')+' • '+me+'</div><div class="rh" id="h0">'+H(0,'#a66cff')+'</div></div><div class="rc" id="rc">VS</div><div><div class="rn">'+(mode=='cpu'?'الكمبيوتر':'لاعب 2')+' • '+cp+'</div><div class="rh" id="h1">'+H(0,'#ffb347')+'</div></div></div><div class="row" style="justify-content:center">'+N.map((o,i)=>'<button class="btn bigbtn" data-a="'+i+'">'+o+'</button>').join('')+'</div>'}
const cpuPick=()=>{const r=Math.random();if(lvl==0||r<(lvl==1?.55:.25))return Math.random()*3|0;return (hist.indexOf(Math.max(...hist))+1)%3};
function go(m,c){busy=1;const rc=b.querySelector('#rc'),h=[b.querySelector('#h0'),b.querySelector('#h1')];h.forEach((x,i)=>{x.innerHTML=H(0,i?'#ffb347':'#a66cff');x.className='rh sh'});let n=3;rc.textContent=n;SFX.tap();const iv=a.i(()=>{n--;if(n>0){rc.textContent=n;SFX.tap();return}clearInterval(iv);h.forEach((x,i)=>{x.className='rh';x.innerHTML=H(i?c:m,i?'#ffb347':'#a66cff')});hist[m]++;const d=(m-c+3)%3;if(d==0){rc.textContent='تعادلنا'}else if(d==1){me++;rc.textContent='فزت!';h[0].classList.add('w');h[1].classList.add('l')}else{cp++;rc.textContent=mode=='cpu'?'خسرت':'فاز لاعب 2';h[1].classList.add('w');h[0].classList.add('l')}SFX.tap();a.t(()=>{if(me==3||cp==3)return a.end(mode=='cpu'?me:null,(me>cp?(mode=='cpu'?'فزت ':'فاز لاعب 1 '):(mode=='cpu'?'خسرت ':'فاز لاعب 2 '))+me+'-'+cp);pk=[null,null];ui();busy=0},1300)},600)}
function pick(p,i){if(busy)return;if(mode=='cpu'){go(i,cpuPick());return}pk[p]=i;b.querySelector('#ri').textContent=(pk[0]!=null?'✔ لاعب 1 جاهز ':'')+(pk[1]!=null?'✔ لاعب 2 جاهز':'');if(pk[0]!=null&&pk[1]!=null)go(pk[0],pk[1])}
b.onclick=e=>{const t=e.target.closest('button');if(!t||busy)return;if(t.dataset.m){mode=t.dataset.m;me=cp=0;pk=[null,null];ui()}else if(t.dataset.l){lvl=+t.dataset.l;ui()}else if(t.dataset.a)pick(0,+t.dataset.a)};
const K={Digit1:[0,0],Digit2:[0,1],Digit3:[0,2],KeyA:[0,0],KeyS:[0,1],KeyD:[0,2],KeyJ:[1,0],KeyK:[1,1],KeyL:[1,2]};
EL(a,document,'keydown',e=>{const k=K[e.code];if(k&&(mode=='2p'||k[0]==0)){e.preventDefault();pick(k[0],k[1])}});
ui()}
/* ===== Dino Runner: stable collision, jump buffering, restart handled by studio ===== */
function gDino(b,a){
 const c=CV(b,640,220),x=c.getContext('2d'),F=190,hi=S.best.dino||0;
 let y=0,vy=0,sp=300,sc=0,ob=[],nx=.8,fx=[],t=0,dead=false,buf=0,flash=0,shake=0,ms=0,cl=[[90,40],[340,28],[540,52]];
 const puff=(px,py,n)=>{for(let i=0;i<n;i++)fx.push({x:px,y:py,vx:-40-Math.random()*130,vy:-20-Math.random()*90,l:.4})};
 const jump=()=>{if(!dead)buf=.14};
 KEYS(a,{Space:jump,ArrowUp:jump,KeyW:jump});EL(a,c,'pointerdown',e=>{e.preventDefault();jump()});BTN(a,b,'⬆ اقفز',jump);
 b.querySelector('#ei').textContent='Space / ↑ / لمس الشاشة للقفز';
 LOOP(a,dt=>{
  t+=dt;flash=Math.max(0,flash-dt);shake=Math.max(0,shake-dt);
  if(!dead){buf=Math.max(0,buf-dt);sp=Math.min(650,sp+dt*7);sc+=dt*sp/40;
   if(buf>0&&y>=0){vy=-610;y=-1;buf=0;SFX.jump();puff(52,F,6)}
   const was=y<0;vy+=1700*dt;y=Math.min(0,y+vy*dt);if(y===0){vy=0;if(was){SFX.land();puff(52,F,4)}}
   nx-=dt;if(nx<=0){const k=1+(Math.random()*(sc>150?3:2)|0),w=14*k+4,h=28+Math.random()*26;ob.push({x:660,w,h,k,p:0});nx=Math.max(.5,.95+Math.random()*.7-sp/1300)}
   ob.forEach(o=>{o.x-=sp*dt;if(!o.p&&o.x+o.w<44){o.p=1;SFX.tick()}});ob=ob.filter(o=>o.x>-60);
   if((sc/100|0)>ms){ms=sc/100|0;SFX.milestone();flash=.3}
   const bx=48,by=F-38+y;
   if(ob.some(o=>bx+26>o.x+4&&bx+4<o.x+o.w-4&&by+34>F-o.h+4)){dead=true;SFX.die();shake=.4;puff(60,F-20,16);a.t(()=>a.end(sc|0,'اصطدمت! النتيجة '+(sc|0)),850)}}
  fx.forEach(d=>{d.x+=d.vx*dt;d.y+=d.vy*dt;d.l-=dt});fx=fx.filter(d=>d.l>0);
  x.save();if(shake>0)x.translate((Math.random()-.5)*8,(Math.random()-.5)*6);
  x.fillStyle=flash>0?'#2a1f4d':'#0d0a1a';x.fillRect(-10,-10,660,240);
  x.fillStyle='#ffffff12';cl.forEach(q=>{if(!dead)q[0]-=dt*20;if(q[0]<-70)q[0]=700;x.fillRect(q[0],q[1],56,10);x.fillRect(q[0]+10,q[1]-8,30,10)});
  x.fillStyle='#a66cff22';x.beginPath();x.moveTo(0,F);for(let i=0;i<=640;i+=40)x.lineTo(i,F-30-18*Math.sin(i/90+t*(dead?0:.1)));x.lineTo(640,F);x.fill();
  x.fillStyle='#a66cff';x.fillRect(0,F,640,2);x.fillStyle='#a66cff66';for(let i=0;i<16;i++)x.fillRect(((i*47-t*sp*.9)%700+700)%700-20,F+8+(i%3)*8,10,2);
  x.fillStyle='#4ade80';ob.forEach(o=>{for(let i=0;i<o.k;i++){const cx=o.x+i*14,h=o.h-(i%2)*8;x.fillRect(cx+4,F-h,7,h);x.fillRect(cx,F-h*.6,4,10);x.fillRect(cx,F-h*.6,4,4);x.fillRect(cx+11,F-h*.7,4,10)}});
  const px=48,py=F-38+y,run=!dead&&y===0,lg=run&&Math.sin(t*sp/22)>0;
  x.save();if(dead){x.translate(px+15,py+19);x.rotate(.35);x.translate(-px-15,-py-19)}
  x.fillStyle='#ffd36b';x.fillRect(px,py+8,22,22);x.fillRect(px+14,py,18,14);x.fillRect(px+30,py+7,5,5);x.fillRect(px-8,py+14,10,6);
  x.fillRect(px+4,py+30,6,lg?8:4);x.fillRect(px+14,py+30,6,lg?4:8);
  x.fillStyle='#0d0a1a';if(dead){x.fillRect(px+22,py+3,6,2);x.fillRect(px+24,py+1,2,6)}else x.fillRect(px+24,py+3,4,4);x.restore();
  fx.forEach(d=>{x.fillStyle='rgba(255,211,107,'+Math.max(0,d.l*2)+')';x.fillRect(d.x,d.y,4,4)});
  x.fillStyle='#fff';x.font='700 18px monospace';x.fillText(String(sc|0).padStart(5,'0'),560,26);x.fillStyle='#ffffff77';x.fillText('HI '+String(Math.max(hi,sc|0)).padStart(5,'0'),440,26);x.restore();
 });
}

function gSnake(b,a){
 const G=20,C=16,c=CV(b,320,320),x=c.getContext('2d');
 let s=[[10,10],[9,10],[8,10]],d=[1,0],nd=[1,0],f=[15,10],sc=0,acc=0,pause=false,dead=false,fx=[],t=0,shake=0;
 const skin=['#a66cff','#4ade80','#ffd36b','#1ea0ff'][Math.min(3,(S.best.snake||0)/10|0)];
 const turn=(dx,dy)=>{if(dead)return;if(dx!==-nd[0]||dy!==-nd[1])nd=[dx,dy]};
 const toggle=()=>{if(dead)return;pause=!pause;SFX.tap()};
 const spark=(px,py,col,n)=>{for(let i=0;i<n;i++){const r=Math.random()*6.28,v=40+Math.random()*90;fx.push({x:px,y:py,vx:Math.cos(r)*v,vy:Math.sin(r)*v,l:.5,c:col})}};
 const place=()=>{let k=0;do{f=[Math.random()*G|0,Math.random()*G|0];k++}while(s.some(p=>p[0]===f[0]&&p[1]===f[1])&&k<500)};
 KEYS(a,{ArrowUp:()=>turn(0,-1),ArrowDown:()=>turn(0,1),ArrowLeft:()=>turn(-1,0),ArrowRight:()=>turn(1,0),KeyW:()=>turn(0,-1),KeyS:()=>turn(0,1),KeyA:()=>turn(-1,0),KeyD:()=>turn(1,0),KeyP:toggle,Space:toggle});
 let sx=0,sy=0;EL(a,c,'pointerdown',e=>{sx=e.clientX;sy=e.clientY});
 EL(a,c,'pointerup',e=>{const dx=e.clientX-sx,dy=e.clientY-sy;if(Math.max(Math.abs(dx),Math.abs(dy))<15)return;Math.abs(dx)>Math.abs(dy)?turn(Math.sign(dx),0):turn(0,Math.sign(dy))});
 DPAD(a,b,turn);b.querySelector('#ei').textContent='الجدران تنقلك للجهة المقابلة - الأسهم / WASD / السحب';
 LOOP(a,dt=>{
  t+=dt;shake=Math.max(0,shake-dt);
  if(!dead&&!pause){acc+=dt;const step=Math.max(.065,.16-sc*.0025);if(acc>=step){acc=0;d=nd;
   const h=[(s[0][0]+d[0]+G)%G,(s[0][1]+d[1]+G)%G],eat=h[0]===f[0]&&h[1]===f[1],body=eat?s:s.slice(0,-1);
   if(body.some(p=>p[0]===h[0]&&p[1]===h[1])){dead=true;SFX.die();shake=.4;s.forEach(p=>spark(p[0]*C+8,p[1]*C+8,skin,2));a.t(()=>a.end(sc,'اصطدمت بنفسك - '+sc),800)}
   else{s.unshift(h);if(eat){sc++;SFX.eat();spark(f[0]*C+8,f[1]*C+8,'#ff5a6e',12);if(sc%10===0)SFX.milestone();if(s.length>=G*G){dead=true;a.t(()=>a.end(sc,'فزت! امتلأت الساحة - '+sc),300);return}place()}else s.pop()}}}
  fx.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.l-=dt});fx=fx.filter(q=>q.l>0);
  x.save();if(shake>0)x.translate((Math.random()-.5)*7,(Math.random()-.5)*7);
  x.fillStyle='#0d0a1a';x.fillRect(-8,-8,336,336);for(let i=0;i<G;i++)for(let j=0;j<G;j++)if((i+j)%2){x.fillStyle='#ffffff08';x.fillRect(i*C,j*C,C,C)}
  const pu=1+.15*Math.sin(t*8);x.fillStyle='#ff5a6e';x.shadowColor='#ff5a6e';x.shadowBlur=10;x.beginPath();x.arc(f[0]*C+8,f[1]*C+8,6*pu,0,7);x.fill();x.shadowBlur=0;x.fillStyle='#4ade80';x.fillRect(f[0]*C+8,f[1]*C+1,2,4);
  s.forEach((p,i)=>{const k=1-i/s.length*.45;x.globalAlpha=dead?.5:1;x.fillStyle=skin;x.beginPath();x.roundRect?x.roundRect(p[0]*C+1,p[1]*C+1,C-2,C-2,i?4:6):x.rect(p[0]*C+1,p[1]*C+1,C-2,C-2);x.globalAlpha=(dead?.5:1)*(.55+.45*k);x.fill()});x.globalAlpha=1;
  const hd=s[0],ex=d[0]*3,ey=d[1]*3;x.fillStyle='#fff';[[-3,-3],[3,3]].forEach(([u,v])=>{const px=d[0]?0:u,py=d[0]?v:0;x.fillRect(hd[0]*C+8+px+ex-1.5,hd[1]*C+8+(d[0]?py:-3+0)+ey-1.5,3,3)});
  fx.forEach(q=>{x.globalAlpha=Math.max(0,q.l*2);x.fillStyle=q.c;x.fillRect(q.x,q.y,3,3)});x.globalAlpha=1;
  x.fillStyle='#fff';x.font='700 14px sans-serif';x.fillText(sc,8,18);if(pause){x.fillStyle='#000a';x.fillRect(0,0,320,320);x.fillStyle='#fff';x.font='700 24px sans-serif';x.fillText('⏸ متوقف',110,165)}x.restore();
 });
}

function gFlap(b,a){
 const c=CV(b,320,480),x=c.getContext('2d'),W=320,H=480,GY=440,best=S.best.flappy||0;
 let st='ready',y=220,vy=0,p=[],nx=.8,sc=0,t=0,off=0,fx=[],shake=0,nb=0,cls=[[40,70],[200,120],[300,40]];
 const burst=(px,py,col,n,g)=>{for(let i=0;i<n;i++){const r=Math.random()*6.28,v=30+Math.random()*110;fx.push({x:px,y:py,vx:Math.cos(r)*v,vy:Math.sin(r)*v-20,l:.6,c:col,g:g||0})}};
 const flap=()=>{if(st==='dead')return;if(st==='ready')st='play';vy=-290;SFX.flap();burst(70,y+8,'#ffffffaa',3)};
 const die=()=>{if(st==='dead')return;st='dead';SFX.hit();shake=.35;burst(80,y,'#ffd36b',14,300);a.t(()=>SFX.die(),120);a.t(()=>a.end(sc,'سقطت! النتيجة '+sc),950)};
 KEYS(a,{Space:flap,ArrowUp:flap,KeyW:flap});EL(a,c,'pointerdown',e=>{e.preventDefault();flap()});BTN(a,b,'⬆ حلّق',flap);
 b.querySelector('#ei').textContent='Space / ↑ / لمس الشاشة للتحليق';
 LOOP(a,dt=>{
  t+=dt;shake=Math.max(0,shake-dt);
  if(st!=='dead')off+=dt*(st==='play'?120:50);
  if(st==='ready')y=220+Math.sin(t*4)*8;
  if(st!=='ready'){vy+=900*dt;y+=vy*dt;if(y>GY-12){y=GY-12;die()}if(y<12){y=12;vy=0;if(st==='play')die()}}
  if(st==='play'){nx-=dt;if(nx<=0){p.push({x:340,g:125+Math.random()*190,s:0});nx=1.5}
   p.forEach(q=>{q.x-=120*dt;if(!q.s&&q.x+52<80){q.s=1;sc++;SFX.score();burst(80,y,'#ffd36b',8);if(best>0&&sc>best&&!nb){nb=1;SFX.best();burst(160,120,'#a66cff',30);burst(160,120,'#4ade80',20)}}
    if(80>q.x-12&&80<q.x+64&&(y-12<q.g-65||y+12>q.g+65))die()});p=p.filter(q=>q.x>-70)}
  fx.forEach(f=>{f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=f.g*dt;f.l-=dt});fx=fx.filter(f=>f.l>0);
  x.save();if(shake>0)x.translate((Math.random()-.5)*8,(Math.random()-.5)*8);
  const sk=x.createLinearGradient(0,0,0,H);sk.addColorStop(0,'#1b1050');sk.addColorStop(.7,'#4b2a8f');sk.addColorStop(1,'#ff8fb1');x.fillStyle=sk;x.fillRect(-10,-10,340,500);
  x.fillStyle='#ffd36b';x.beginPath();x.arc(250,300,34,0,7);x.fill();
  x.fillStyle='#ffffff22';cls.forEach(q=>{const cx=((q[0]-off*.1)%420+420)%420-60;x.fillRect(cx,q[1],70,14);x.fillRect(cx+14,q[1]-10,40,14)});
  x.fillStyle='#2a1a63';x.beginPath();x.moveTo(0,GY);for(let i=0;i<=340;i+=20)x.lineTo(i,GY-70-30*Math.sin((i+off*.25)/60));x.lineTo(340,GY);x.fill();
  x.fillStyle='#1d5a46';x.beginPath();x.moveTo(0,GY);for(let i=0;i<=340;i+=20)x.lineTo(i,GY-28-14*Math.sin((i+off*.6)/28));x.lineTo(340,GY);x.fill();
  p.forEach(q=>{const gr=x.createLinearGradient(q.x,0,q.x+52,0);gr.addColorStop(0,'#2e9e5b');gr.addColorStop(.5,'#7be08f');gr.addColorStop(1,'#238147');x.fillStyle=gr;x.fillRect(q.x,0,52,q.g-65);x.fillRect(q.x,q.g+65,52,GY-q.g-65);x.fillRect(q.x-4,q.g-90,60,25);x.fillRect(q.x-4,q.g+65,60,25);x.fillStyle='#0004';x.fillRect(q.x-4,q.g-70,60,5);x.fillRect(q.x-4,q.g+65,60,4)});
  x.fillStyle='#8a5a2b';x.fillRect(0,GY,W,40);x.fillStyle='#5ed26b';x.fillRect(0,GY,W,8);x.fillStyle='#00000030';for(let i=0;i<14;i++)x.fillRect(((i*30-off)%360+360)%360-20,GY+8,14,6);
  x.save();x.translate(80,y);x.rotate(Math.max(-.5,Math.min(1.2,vy/450)));
  x.fillStyle='#ffd36b';x.beginPath();x.ellipse(0,0,17,13,0,0,7);x.fill();x.fillStyle='#f5a524';x.beginPath();x.ellipse(-3,6,10,5,0,0,7);x.fill();
  const w=Math.sin(t*(st==='dead'?0:22))*9;x.fillStyle='#fff';x.beginPath();x.ellipse(-6,2+w*.3,9,5+Math.abs(w)*.4,-.4,0,7);x.fill();
  x.fillStyle='#fff';x.beginPath();x.arc(8,-5,5,0,7);x.fill();x.fillStyle='#111';x.beginPath();x.arc(st==='dead'?9:10,-5,2,0,7);x.fill();
  x.fillStyle='#f97316';x.beginPath();x.moveTo(15,-1);x.lineTo(25,2);x.lineTo(15,6);x.fill();x.restore();
  fx.forEach(f=>{x.globalAlpha=Math.max(0,f.l*1.6);x.fillStyle=f.c;x.fillRect(f.x,f.y,4,4)});x.globalAlpha=1;
  x.textAlign='center';x.lineWidth=4;x.strokeStyle='#000a';x.fillStyle='#fff';x.font='800 38px sans-serif';x.strokeText(sc,160,60);x.fillText(sc,160,60);
  if(st==='ready'){x.font='700 20px sans-serif';x.fillText('اضغط للتحليق',160,150);x.font='600 14px sans-serif';x.fillText('الأفضل: '+best,160,176)}
  x.textAlign='left';x.restore();
 });
}

Object.assign(UI_EN,{'عدّاء الديناصور':'Dino Runner','الثعبان':'Snake','طائر التحليق':'Flappy Flyer','ملحمي':'Epic','ضد الكمبيوتر':'Vs CPU','لاعبان':'Two Players','سهل':'Easy','متوسط':'Medium','صعب':'Hard','حجر':'Rock','ورقة':'Paper','مقص':'Scissors','أنت':'YOU','الكمبيوتر':'CPU','تعادلنا':'Draw','فزت!':'You win!','خسرت':'You lose'});
/* ===== X: settings / fonts / sound / background / badges ===== */
const XS=(()=>{const d={font:'Cairo',bg:'particles',speed:1,int:1,pack:'arcade',vol:.7,mute:0,part:1,perf:0};try{Object.assign(d,JSON.parse(localStorage.getItem('ams-x')||'{}'))}catch(e){}return d})();
const XD=Object.assign({},XS);const xsave=()=>{try{localStorage.setItem('ams-x',JSON.stringify(XS))}catch(e){}};
const TT2=(ar,en)=>LANG==='en'?en:ar;
(function(){const l=document.createElement('link');l.rel='stylesheet';l.href='https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&family=Tajawal:wght@400;700;900&family=Changa:wght@500;800&family=Orbitron:wght@500;800&display=swap';document.head.appendChild(l);
const s=document.createElement('style');s.textContent='html{background:radial-gradient(ellipse at 50% -10%,var(--glow),transparent 55%),var(--bg)}body{background:none!important;font-family:var(--ff,"Cairo"),"Segoe UI",Tahoma,sans-serif}.app{position:relative;z-index:1}.gc{position:relative}.nb{position:absolute;top:8px;inset-inline-end:8px;background:linear-gradient(135deg,#ff3d81,#a66cff);color:#fff;font-size:10px;font-weight:900;padding:3px 8px;border-radius:99px;letter-spacing:1px;z-index:3;box-shadow:0 0 12px #ff3d8155}.sb{background:#ffffff18;color:var(--p2)}.gc.soon{opacity:.7;filter:saturate(.7)}.js{position:relative;width:120px;height:120px;border-radius:50%;border:2px solid var(--line);background:#ffffff08;touch-action:none;flex:none}.js i{position:absolute;left:34px;top:34px;width:48px;height:48px;border-radius:50%;background:var(--p);opacity:.8;pointer-events:none}.xs{position:fixed;z-index:60;inset-inline-start:10px;bottom:calc(86px + env(safe-area-inset-bottom))}#xp{position:fixed;inset:0;z-index:80;background:#000b;display:flex;align-items:center;justify-content:center;padding:12px}#xp .box{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:16px;width:min(440px,100%);max-height:88dvh;overflow:auto}#xp label{display:flex;justify-content:space-between;align-items:center;gap:8px;margin:10px 0;font-weight:700}#xp select,#xp input[type=range]{min-width:150px;background:#ffffff10;border:1px solid var(--line);border-radius:10px;padding:8px}.zs h4{margin:12px 0 6px;color:var(--p2)}.zi{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px;border:1px solid var(--line);border-radius:12px;margin:5px 0}@media (hover:hover) and (pointer:fine){#zc{display:none!important}}';document.head.appendChild(s);document.documentElement.style.setProperty('--ff',XS.font)})();
const SND=(()=>{let ctx;const P={arcade:{w:'square',m:1,v:.7},neon:{w:'sawtooth',m:1.25,v:.6},soft:{w:'sine',m:.85,v:1},mech:{w:'triangle',m:1.1,v:1}};
const C=()=>{if(!ctx){const A=window.AudioContext||window.webkitAudioContext;if(!A)return null;ctx=new A()}if(ctx.state==='suspended')ctx.resume();return ctx};
function tone(f,d,o){o=o||{};const c=C();if(!c||XS.mute)return;const p=P[XS.pack]||P.arcade,t=c.currentTime+(o.at||0),os=c.createOscillator(),g=c.createGain();os.type=o.type||p.w;os.frequency.setValueAtTime(f*p.m,t);if(o.to)os.frequency.exponentialRampToValueAtTime(Math.max(20,o.to*p.m),t+d);const v=(o.v||.18)*XS.vol*p.v;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);os.connect(g);g.connect(c.destination);os.start(t);os.stop(t+d+.03)}
function noise(d,v,fq){const c=C();if(!c||XS.mute)return;const n=c.sampleRate*d|0,bf=c.createBuffer(1,n,c.sampleRate),a=bf.getChannelData(0);for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*(1-i/n);const s=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain();f.type='lowpass';f.frequency.value=fq;g.gain.value=v*XS.vol;s.buffer=bf;s.connect(f);f.connect(g);g.connect(c.destination);s.start()}
const arp=(a,d,o)=>a.forEach((f,i)=>tone(f,d,Object.assign({at:i*d*.8},o||{})));
const M={click:()=>tone(700,.05,{to:480}),open:()=>arp([400,600],.07),empty:()=>tone(120,.05,{type:'square'}),
sh_pistol:()=>{noise(.09,.35,2600);tone(200,.08,{to:60})},sh_shotgun:()=>{noise(.22,.5,1000);tone(90,.2,{to:40})},sh_rifle:()=>{noise(.06,.28,3200);tone(240,.05,{to:90})},sh_sniper:()=>{noise(.3,.5,1800);tone(100,.3,{to:35})},sh_rocket:()=>{noise(.35,.5,600);tone(70,.35,{to:35})},
boom:()=>{noise(.45,.6,500);tone(60,.4,{to:30})},reload:()=>{tone(300,.05,{type:'square'});tone(520,.06,{at:.18,type:'square'})},hit:()=>tone(160,.06,{to:90,type:'sawtooth',v:.1}),zdie:()=>tone(130,.22,{to:45,type:'sawtooth',v:.12}),hurt:()=>{tone(180,.18,{to:70,type:'sawtooth',v:.25})},
coin:()=>{tone(988,.06);tone(1319,.12,{at:.06})},buy:()=>arp([523,659,784,1047],.08),bad:()=>tone(170,.22,{to:100,type:'sawtooth'}),wave:()=>{arp([196,247,294,392],.14,{type:'sawtooth',v:.15})},over:()=>arp([392,330,262,196],.2,{type:'square'}),win:()=>arp([523,659,784,1047,1319],.09)};
return{play:n=>{try{(M[n]||M.click)()}catch(e){}}}})();
const BG=(()=>{const c=document.createElement('canvas');c.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none';document.body.prepend(c);const x=c.getContext('2d');let W=0,H=0,t=0,pts=[],raf=0,col='#a66cff',lt=0,fc=0;const rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function init(){const r=Math.min(devicePixelRatio||1,XS.perf?1:1.5);W=c.width=innerWidth*r|0;H=c.height=innerHeight*r|0;const n=Math.round((XS.perf?24:70)*XS.int);pts=Array.from({length:n},()=>({x:Math.random()*W,y:Math.random()*H,r:Math.random()*2.2+.6,a:Math.random()*6.3,s:Math.random()*.6+.2}))}
function frame(n){raf=requestAnimationFrame(frame);if(document.hidden||(typeof cur!=='undefined'&&cur))return;if(XS.perf&&n-lt<33)return;lt=n;const dt=.016*XS.speed;t+=dt;if(!(fc++%60))col=(getComputedStyle(document.documentElement).getPropertyValue('--p')||'#a66cff').trim();x.clearRect(0,0,W,H);const st=XS.bg,I=XS.int;x.fillStyle=col;x.strokeStyle=col;
if(st==='particles'||st==='stars'||st==='minimal'){pts.forEach(p=>{p.y-=p.s*XS.speed*(st==='stars'?.2:1)*(W/700);p.x+=Math.sin(t+p.a)*.4;if(p.y<-5){p.y=H+5;p.x=Math.random()*W}x.globalAlpha=(st==='stars'?.3+.7*Math.abs(Math.sin(t*2+p.a)):.55)*Math.min(1,I);x.beginPath();x.arc(p.x,p.y,p.r*(st==='stars'?.8:1.4),0,7);x.fill()});if(st==='particles'&&!XS.perf){x.globalAlpha=.12*I;for(let i=0;i<pts.length;i+=2)for(let j=i+1;j<Math.min(i+8,pts.length);j++){const a=pts[i],b=pts[j];if(Math.hypot(a.x-b.x,a.y-b.y)<140){x.beginPath();x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke()}}}}
else if(st==='grid'){x.globalAlpha=.22*I;x.lineWidth=1;const g=60,o=(t*30)%g;for(let i=-g;i<W+g;i+=g){x.beginPath();x.moveTo(i+o,0);x.lineTo(i+o,H);x.stroke()}for(let j=-g;j<H+g;j+=g){x.beginPath();x.moveTo(0,j+o);x.lineTo(W,j+o);x.stroke()}}
else if(st==='orbs'||st==='gradient'){const k=st==='orbs'?6:3;for(let i=0;i<k;i++){const px=W*(.5+.4*Math.sin(t*.4+i*2)),py=H*(.5+.4*Math.cos(t*.3+i*1.7)),r=Math.max(W,H)*(st==='orbs'?.16:.5),g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,col);g.addColorStop(1,'transparent');x.globalAlpha=(st==='orbs'?.28:.2)*I;x.fillStyle=g;x.fillRect(0,0,W,H)}}
else if(st==='shapes'){x.globalAlpha=.3*Math.min(1,I);x.lineWidth=2;pts.slice(0,Math.round(18*I)).forEach((p,i)=>{p.y-=p.s*XS.speed*.6;if(p.y<-60)p.y=H+60;x.save();x.translate(p.x,p.y);x.rotate(t*p.s+p.a);const s=14+p.r*9,k=3+i%3;x.beginPath();for(let q=0;q<k;q++){const an=q/k*6.283;x.lineTo(Math.cos(an)*s,Math.sin(an)*s)}x.closePath();x.stroke();x.restore()})}x.globalAlpha=1}
function start(){cancelAnimationFrame(raf);if(XS.bg==='off'||rm){x.clearRect(0,0,W,H);return}raf=requestAnimationFrame(frame)}
addEventListener('resize',()=>{init();start()});init();start();return{start,init}})();
/* settings panel */
function xPanel(){const o=document.getElementById('xp');if(o){o.remove();return}const d=document.createElement('div');d.id='xp';
const sel=(k,arr)=>'<select data-k="'+k+'">'+arr.map(v=>'<option value="'+v[0]+'"'+(String(XS[k])===String(v[0])?' selected':'')+'>'+v[1]+'</option>').join('')+'</select>',rg=(k,mn,mx,st)=>'<input type="range" data-k="'+k+'" min="'+mn+'" max="'+mx+'" step="'+st+'" value="'+XS[k]+'">',tg=k=>'<input type="checkbox" data-k="'+k+'"'+(XS[k]?' checked':'')+' style="width:26px;height:26px">';
d.innerHTML='<div class="box"><h3 style="margin:0">⚙ '+TT2('الإعدادات','Settings')+'</h3><label>'+TT2('الخط','Font')+sel('font',[['Cairo','Cairo'],['Tajawal','Tajawal'],['Changa','Changa'],['Orbitron','Orbitron']])+'</label><label>'+TT2('خلفية متحركة','Animated background')+sel('bg',[['particles',TT2('جزيئات نيون','Neon particles')],['grid',TT2('شبكة رقمية','Digital grid')],['stars',TT2('نجوم','Stars')],['orbs',TT2('كرات ضوء','Light orbs')],['gradient',TT2('تدرج بنفسجي','Purple gradient')],['shapes',TT2('أشكال هندسية','Shapes')],['off',TT2('ثابتة','Static')]])+'</label><label>'+TT2('السرعة','Speed')+rg('speed',.3,3,.1)+'</label><label>'+TT2('الشدة','Intensity')+rg('int',.3,2,.1)+'</label><label>'+TT2('حزمة الأصوات','Sound pack')+sel('pack',[['arcade',TT2('أركيد','Arcade')],['neon',TT2('نيون','Neon')],['soft',TT2('ناعم','Soft')],['mech',TT2('ميكانيكي','Mechanical')]])+'</label><label>'+TT2('مستوى الصوت','Volume')+rg('vol',0,1,.05)+'</label><label>'+TT2('كتم','Mute')+tg('mute')+'</label><label>'+TT2('جزيئات الألعاب','Game particles')+tg('part')+'</label><label>'+TT2('وضع الأداء','Performance mode')+tg('perf')+'</label><div class="row"><button class="btn" data-x="test">🔊 '+TT2('تجربة','Test')+'</button><button class="btn" data-x="reset">'+TT2('إعادة ضبط','Reset')+'</button><button class="btn p" data-x="close">'+TT2('سكّر','Close')+'</button></div></div>';
const ap=()=>{document.documentElement.style.setProperty('--ff',XS.font);xsave();BG.init();BG.start()};
d.addEventListener('input',e=>{const k=e.target.dataset.k;if(!k)return;XS[k]=e.target.type==='checkbox'?+e.target.checked:e.target.type==='range'?+e.target.value:e.target.value;ap();if(k==='pack')SND.play('open')});
d.addEventListener('click',e=>{const a=e.target.closest('[data-x]'),x=a&&a.dataset.x;if(e.target===d||x==='close')d.remove();else if(x==='test'){SND.play('click');setTimeout(()=>SND.play('coin'),150);setTimeout(()=>SND.play('sh_rifle'),350)}else if(x==='reset'&&confirm(TT2('إعادة الإعدادات للافتراضي؟','Reset settings to defaults?'))){Object.assign(XS,XD);ap();d.remove()}});document.body.appendChild(d)}
const xb=document.createElement('button');xb.className='ib xs';xb.textContent='🎛';xb.setAttribute('aria-label','Settings');
/* NEW playable games - keep the existing studio design unchanged */
const NEWSET=['zombie','dino','rps','mafia','tbattle','typearena','rhythm','golf','tycoon','towerdef','dungeon','kart','bossrush','escape','survival','parkour'];
function xBadges(){document.querySelectorAll('#lib .gc[data-id]').forEach(c=>{if(NEWSET.includes(c.dataset.id)&&!c.querySelector('.nb')){const s=document.createElement('span');s.className='nb';s.textContent=TT2('جديد','NEW');c.appendChild(s)}});const s=document.getElementById('soonSec');if(s)s.remove()}
const _rl=renderLib;renderLib=function(){_rl.apply(this,arguments);try{xBadges()}catch(e){}};
const _al=applyLanguage;applyLanguage=function(){_al.apply(this,arguments);try{xBadges()}catch(e){}};
try{xBadges()}catch(e){}
/* ===== controls helpers ===== */
function BTN(a,b,label,fn){const e=document.createElement('button');e.className='btn p bigbtn';e.style.cssText='width:100%;margin-top:10px;min-height:64px;font-size:20px;touch-action:none';e.textContent=label;b.appendChild(e);EL(a,e,'pointerdown',ev=>{ev.preventDefault();fn()})}
function DPAD(a,b,fn){const d=document.createElement('div');d.style.cssText='display:grid;grid-template-columns:repeat(3,68px);gap:6px;justify-content:center;margin-top:10px;direction:ltr';[['',0,0],['▲',0,-1],['',0,0],['◀',-1,0],['▼',0,1],['▶',1,0]].forEach(q=>{const e=document.createElement('button');e.className='btn';e.style.cssText='min-height:60px;font-size:22px;touch-action:none;'+(q[0]?'':'visibility:hidden');e.textContent=q[0];if(q[0])EL(a,e,'pointerdown',ev=>{ev.preventDefault();fn(q[1],q[2])});d.appendChild(e)});b.appendChild(d)}
/* ===== ZOMBIE SURVIVAL: LAST STAND ===== */
function heroDraw(x,X,Y,ang,inv,wc,t){const p=.4+.18*Math.sin(t*5),g=x.createRadialGradient(X,Y,6,X,Y,56);g.addColorStop(0,'rgba(166,108,255,'+p+')');g.addColorStop(1,'rgba(166,108,255,0)');x.fillStyle=g;x.beginPath();x.arc(X,Y,56,0,7);x.fill();
x.save();x.translate(X,Y);x.rotate(ang);x.scale(1.4,1.4);x.lineCap='round';x.shadowColor='#a66cff';x.shadowBlur=12;
x.strokeStyle='#f1c59a';x.lineWidth=5;x.beginPath();x.moveTo(0,-10);x.lineTo(15,-4);x.moveTo(0,10);x.lineTo(15,4);x.stroke();
x.shadowBlur=0;x.fillStyle=wc;x.fillRect(12,-3,22,6);x.fillStyle='#222';x.fillRect(26,-4,8,8);
x.shadowBlur=12;x.fillStyle=inv>0?'#fff':'#7c3aed';x.beginPath();x.ellipse(0,0,8,16,0,0,7);x.fill();x.fillStyle=inv>0?'#ddd':'#5b21b6';x.fillRect(-9,-7,5,14);
x.shadowBlur=0;x.fillStyle='#f1c59a';x.beginPath();x.arc(2,0,8,0,7);x.fill();x.fillStyle='#2b1b0e';x.beginPath();x.arc(2,0,8.4,Math.PI/2+.25,Math.PI*1.5-.25);x.fill();
x.fillStyle='#111';x.fillRect(8,-4,2,2);x.fillRect(8,2,2,2);x.restore()}
function gZombie(b,a){const W=360,HH=440,AW=1000,AH=1000,en=LANG==='en',T=(x,y)=>en?y:x;b.style.position='relative';
const RC={common:'#9ca3af',rare:'#3b82f6',epic:'#a855f7',legendary:'#fbbf24'},RN={common:['عادي','Common'],rare:['نادر','Rare'],epic:['ملحمي','Epic'],legendary:['أسطوري','Legendary']};
const WP={pistol:{n:['مسدس','Pistol'],r:'common',dmg:22,rate:.32,mag:12,rl:1,sp:.04,pel:1,spd:540,price:0,res:72,ac:25,col:'#ffd36b'},
shotgun:{n:['شوتغن','Shotgun'],r:'rare',dmg:13,rate:.85,mag:6,rl:1.7,sp:.24,pel:7,spd:470,price:300,res:30,ac:40,col:'#fb923c'},
rifle:{n:['رشاش','Assault Rifle'],r:'epic',dmg:17,rate:.11,mag:30,rl:1.9,sp:.08,pel:1,spd:640,price:700,res:150,ac:60,col:'#38bdf8'},
sniper:{n:['قناصة','Sniper Rifle'],r:'epic',dmg:120,rate:1.1,mag:5,rl:2.4,sp:0,pel:1,spd:1100,price:900,res:25,ac:70,col:'#a3e635',pierce:3},
rocket:{n:['قاذف صواريخ','Rocket Launcher'],r:'legendary',dmg:90,rate:1.3,mag:3,rl:2.8,sp:.02,pel:1,spd:360,price:1500,res:12,ac:120,col:'#f43f5e',exp:75}};
let sv={coins:0,own:['pistol'],up:{hp:0,dmg:0,spd:0},aa:1};try{Object.assign(sv,JSON.parse(localStorage.getItem('ams-zs')||'{}'))}catch(e){}
const save=()=>{try{localStorage.setItem('ams-zs',JSON.stringify(sv))}catch(e){}};
const c=CV(b,W,HH),x=c.getContext('2d');c.style.cursor='crosshair';c.style.maxWidth='min(100%,560px)';
b.insertAdjacentHTML('beforeend','<div id="zc" style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-top:8px;direction:ltr"><div class="js" id="js1"><i></i></div><div style="display:grid;gap:8px;flex:1;max-width:110px"><button class="btn" id="zr" style="min-height:52px">⟳ '+T('تعبئة','Reload')+'</button><button class="btn" id="zw" style="min-height:52px">⇄ '+T('سلاح','Weapon')+'</button></div><div class="js" id="js2"><i></i></div></div><div class="zs" id="zov" style="position:absolute;inset:0;z-index:6;background:#0b0716f2;border-radius:14px;padding:12px;overflow:auto" hidden></div>');
const ov=b.querySelector('#zov');
const AM={};const refill=()=>sv.own.forEach(k=>{AM[k]={mag:WP[k].mag,res:WP[k].res}});refill();
const P={x:AW/2,y:AH/2,mhp:100+sv.up.hp*25,hp:0,w:'pistol',cd:0,rl:0,ang:0,fl:0,inv:0};P.hp=P.mhp;
let Z=[],B=[],PT=[],wave=0,st='shop',left=0,spT=0,kills=0,time=0,earn=0,msg='',msgT=0,shake=0,paused=0,mf=0,mx=W/2,my=HH/2,mv={x:0,y:0},aim={x:0,y:0,on:0},K={},over=0;
const dmgM=()=>1+sv.up.dmg*.15,spdM=()=>1+sv.up.spd*.08,pc=n=>XS.part?(XS.perf?Math.ceil(n/3):n*2):0;
const burst=(X,Y,n,col,sp,l)=>{n=pc(n);for(let i=0;i<n&&PT.length<260;i++){const an=Math.random()*6.283,s=Math.random()*sp;PT.push({x:X,y:Y,vx:Math.cos(an)*s,vy:Math.sin(an)*s,l:l*(.5+Math.random()*.5),m:l,c:col})}};
function stick(el,cb){const k=el.firstChild;let id=null;const mvf=e=>{const q=el.getBoundingClientRect(),m=q.width/2-12;let dx=e.clientX-q.left-q.width/2,dy=e.clientY-q.top-q.height/2;const l=Math.hypot(dx,dy);if(l>m){dx*=m/l;dy*=m/l}k.style.transform='translate('+dx+'px,'+dy+'px)';cb(dx/m,dy/m,1)};
EL(a,el,'pointerdown',e=>{e.preventDefault();id=e.pointerId;try{el.setPointerCapture(id)}catch(_){}mvf(e)});EL(a,el,'pointermove',e=>{if(e.pointerId===id)mvf(e)});const up=e=>{if(e.pointerId!==id)return;id=null;k.style.transform='';cb(0,0,0)};EL(a,el,'pointerup',up);EL(a,el,'pointercancel',up)}
stick(b.querySelector('#js1'),(dx,dy)=>{mv.x=dx;mv.y=dy});stick(b.querySelector('#js2'),(dx,dy,on)=>{aim.x=dx;aim.y=dy;aim.on=on&&Math.hypot(dx,dy)>.25})
const ownL=()=>Object.keys(WP).filter(k=>sv.own.includes(k));
function equip(k){if(!sv.own.includes(k)||P.w===k)return;P.w=k;P.rl=0;SND.play('click')}
function cyc(){const l=ownL();equip(l[(l.indexOf(P.w)+1)%l.length])}
function reload(){const m=AM[P.w],w=WP[P.w];if(P.rl>0||m.mag>=w.mag||m.res<=0)return;P.rl=w.rl;SND.play('reload')}
b.querySelector('#zr').onpointerdown=e=>{e.preventDefault();reload()};b.querySelector('#zw').onpointerdown=e=>{e.preventDefault();cyc()};
const rc=()=>c.getBoundingClientRect();
EL(a,c,'pointermove',e=>{if(e.pointerType!=='mouse')return;const r=rc();mx=(e.clientX-r.left)*W/r.width;my=(e.clientY-r.top)*HH/r.height});EL(a,c,'pointerdown',e=>{if(e.pointerType==='mouse'&&e.button===0){e.preventDefault();mf=1}});EL(a,window,'pointerup',()=>{mf=0});
const GK=['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','KeyR','KeyQ','KeyP','Digit1','Digit2','Digit3','Digit4','Digit5'];
EL(a,document,'keydown',e=>{if(!GK.includes(e.code))return;e.preventDefault();K[e.code]=1;if(e.code==='KeyR')reload();if(e.code==='KeyQ')cyc();if(e.code==='KeyP'&&st==='play')paused=!paused;if(e.code.startsWith('Digit'))equip(Object.keys(WP)[+e.code[5]-1])});EL(a,document,'keyup',e=>{K[e.code]=0});
const near=()=>{let b2=null,d2=1e9;Z.forEach(z=>{const d=(z.x-P.x)**2+(z.y-P.y)**2;if(d<d2){d2=d;b2=z}});return b2};
function fire(an){const w=WP[P.w],m=AM[P.w];if(P.cd>0||P.rl>0)return;if(m.mag<=0){if(m.res>0)reload();else{P.cd=.3;SND.play('empty')}return}m.mag--;P.cd=w.rate;P.fl=.06;SND.play('sh_'+P.w);shake=Math.max(shake,w.pel>1||w.exp?4:1.5);
for(let i=0;i<w.pel;i++){const a2=an+(Math.random()-.5)*2*w.sp;B.push({x:P.x+Math.cos(an)*20,y:P.y+Math.sin(an)*20,vx:Math.cos(a2)*w.spd,vy:Math.sin(a2)*w.spd,l:w.exp?1.6:.9,d:w.dmg*dmgM(),ex:w.exp,pi:w.pierce||0,col:w.col,hit:[]})}burst(P.x+Math.cos(an)*22,P.y+Math.sin(an)*22,4,w.col,120,.25);if(m.mag<=0&&m.res>0)reload()}
function startWave(){wave++;left=6+wave*4;spT=0;st='play';ov.hidden=true;msg=T('الموجة ','WAVE ')+wave;msgT=2;SND.play('wave');Z=[];B=[]}
function spawn(){let t='walker';const r=Math.random();if(wave%5===0&&!P.boss){t='boss';P.boss=1}else if(wave>=4&&r<.15)t='tank';else if(wave>=2&&r<.4)t='runner';const w=wave,D={walker:{hp:40+w*7,s:46+w*2,d:8,r:12,rw:10,c:'#5f8f4e'},runner:{hp:24+w*4,s:92+w,d:6,r:10,rw:14,c:'#b8a23a'},tank:{hp:170+w*22,s:34,d:18,r:18,rw:35,c:'#7a3b3b'},boss:{hp:650+w*70,s:52,d:26,r:27,rw:150,c:'#8b2fc9'}}[t];const an=Math.random()*6.283;Z.push({t,x:Math.min(AW-20,Math.max(20,P.x+Math.cos(an)*330)),y:Math.min(AH-20,Math.max(20,P.y+Math.sin(an)*330)),hp:D.hp,mh:D.hp,s:Math.min(D.s,130),d:D.d,r:D.r,rw:D.rw,c:D.c,cd:0,fl:0})}
function boom(X,Y,R,dm){SND.play('boom');shake=8;burst(X,Y,40,'#fb923c',260,.6);Z.forEach(z=>{if(Math.hypot(z.x-X,z.y-Y)<R+z.r)hurtZ(z,dm)})}
function hurtZ(z,dm){z.hp-=dm;z.fl=.08;burst(z.x,z.y,5,'#a11',140,.35);SND.play('hit')}
function die(z){sv.coins+=z.rw;earn+=z.rw;kills++;SND.play('zdie');burst(z.x,z.y,14,'#a11',200,.6)}
function shop(txt,ok){ov.hidden=false;const m=AM[P.w],cur=WP[P.w],lv=k=>sv.up[k],cost=k=>150*(lv(k)+1);
ov.innerHTML='<div style="display:flex;justify-content:space-between;font-weight:900"><span>🛒 '+T('المتجر','Shop')+(wave?' - '+T('أكملت الموجة ','Wave done ')+wave:'')+'</span><span style="color:#ffd36b">💰 '+sv.coins+'</span></div>'+(txt?'<div class="info" style="color:'+(ok?'#4ade80':'#f87171')+';font-weight:900">'+txt+'</div>':'')+'<h4>'+T('الأسلحة','Weapons')+'</h4>'+Object.keys(WP).map(k=>{const w=WP[k],o=sv.own.includes(k);return'<div class="zi"><span><b style="color:'+RC[w.r]+'">'+w.n[+en]+'</b> <small>['+RN[w.r][+en]+'] '+T('ضرر','DMG')+' '+w.dmg+(w.pel>1?'×'+w.pel:'')+' • '+w.mag+'/'+w.res+'</small></span><button class="btn'+(P.w===k?' p':'')+'" data-z="'+(o?'eq:':'buy:')+k+'">'+(o?(P.w===k?'✔ '+T('مجهّز','Equipped'):T('جهّز','Equip')):'💰 '+w.price)+'</button></div>'}).join('')+
'<h4>'+T('ذخيرة وعلاج','Ammo & health')+'</h4><div class="zi"><span>'+T('ذخيرة ','Ammo ')+cur.n[+en]+' ('+m.res+')</span><button class="btn" data-z="ammo">💰 '+cur.ac+'</button></div><div class="zi"><span>❤ '+T('علاج +50','Heal +50')+' ('+Math.ceil(P.hp)+'/'+P.mhp+')</span><button class="btn" data-z="heal">💰 50</button></div>'+
'<h4>'+T('ترقيات','Upgrades')+'</h4>'+[['hp',T('الصحة القصوى +25','Max HP +25')],['dmg',T('الضرر +15%','Damage +15%')],['spd',T('السرعة +8%','Speed +8%')]].map(u=>'<div class="zi"><span>'+u[1]+' <small>Lv '+lv(u[0])+'/5</small></span><button class="btn" data-z="up:'+u[0]+'">'+(lv(u[0])>=5?'MAX':'💰 '+cost(u[0]))+'</button></div>').join('')+
'<div class="row" style="margin-top:12px"><button class="btn p" data-z="go" style="flex:1;min-height:54px">▶ '+T('ابدأ الموجة ','Start wave ')+(wave+1)+'</button></div><div class="row"><button class="btn" data-z="aa">🎯 '+T('مساعد التصويب: ','Aim assist: ')+(sv.aa?'ON':'OFF')+'</button><button class="btn" data-z="pt">'+T('جزيئات: ','Particles: ')+(XS.part?'ON':'OFF')+'</button><button class="btn" data-z="mu">🔊 '+T('صوت: ','Sound: ')+(XS.mute?'OFF':'ON')+'</button><button class="btn" data-z="rs">⟲ '+T('مسح التقدم','Reset progress')+'</button></div>'}
EL(a,ov,'click',e=>{const t=e.target.closest('[data-z]');if(!t)return;const [k,v]=t.dataset.z.split(':');let tx='',ok=1;
const pay=n=>{if(sv.coins<n){SND.play('bad');tx=T('ما عندك عملات تكفي!','Not enough coins!');ok=0;return 0}sv.coins-=n;SND.play('buy');tx=T('تمّت العملية!','Purchase successful!');return 1};
if(k==='go'){startWave();return}
if(k==='buy'){if(pay(WP[v].price)){sv.own.push(v);AM[v]={mag:WP[v].mag,res:WP[v].res};P.w=v}}else if(k==='eq')equip(v);
else if(k==='ammo'){const w=WP[P.w];if(pay(w.ac))AM[P.w].res+=w.res}else if(k==='heal'){if(P.hp>=P.mhp){tx=T('صحتك كاملة','Health is full');ok=0}else if(pay(50))P.hp=Math.min(P.mhp,P.hp+50)}
else if(k==='up'){if(sv.up[v]>=5){tx=T('وصلت للحد الأقصى','Max level');ok=0}else if(pay(150*(sv.up[v]+1))){sv.up[v]++;if(v==='hp'){P.mhp+=25;P.hp+=25}}}
else if(k==='aa')sv.aa=sv.aa?0:1;else if(k==='pt'){XS.part=XS.part?0:1;xsave()}else if(k==='mu'){XS.mute=XS.mute?0:1;xsave()}
else if(k==='rs'&&confirm(T('مسح كل تقدم الزومبي؟','Erase all zombie progress?'))){sv={coins:0,own:['pistol'],up:{hp:0,dmg:0,spd:0},aa:1};P.w='pistol';P.mhp=100;P.hp=100;refill()}
save();shop(tx,ok)});
function finish(){if(over)return;over=1;save();SND.play('over');const mm=Math.floor(time/60),ss=Math.floor(time%60);a.end(wave,T('انتهت اللعبة - الموجة ','Game over - wave ')+wave+' • '+T('قتلى ','kills ')+kills+' • '+T('وقت ','time ')+mm+':'+String(ss).padStart(2,'0')+' • '+T('عملات ','coins ')+earn)}
LOOP(a,dt=>{if(over)return;if(!paused){
if(st==='play'){time+=dt;
let dx=(K.KeyD||K.ArrowRight?1:0)-(K.KeyA||K.ArrowLeft?1:0)+mv.x,dy=(K.KeyS||K.ArrowDown?1:0)-(K.KeyW||K.ArrowUp?1:0)+mv.y;const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l}const sp=125*spdM();P.x=Math.min(AW-14,Math.max(14,P.x+dx*sp*dt));P.y=Math.min(AH-14,Math.max(14,P.y+dy*sp*dt));
const cx=Math.min(AW-W,Math.max(0,P.x-W/2)),cy=Math.min(AH-HH,Math.max(0,P.y-HH/2));let fa=null;
if(aim.on){fa=Math.atan2(aim.y,aim.x);if(sv.aa){const n=near();if(n&&Math.hypot(n.x-P.x,n.y-P.y)<300){const ta=Math.atan2(n.y-P.y,n.x-P.x);let df=Math.atan2(Math.sin(ta-fa),Math.cos(ta-fa));if(Math.abs(df)<.45)fa=ta}}}
else if(mf){fa=Math.atan2(my+cy-P.y,mx+cx-P.x)}else if(K.Space){const n=near();if(n)fa=Math.atan2(n.y-P.y,n.x-P.x)}
if(fa!==null){P.ang=fa;fire(fa)}else if(!aim.on)P.ang=Math.atan2(my+cy-P.y,mx+cx-P.x)*(mf||!mv.x&&!mv.y&&false?1:1)*0+(P.ang);
P.cd-=dt;P.fl-=dt;P.inv-=dt;if(P.rl>0){P.rl-=dt;if(P.rl<=0){const m=AM[P.w],w=WP[P.w],tk=Math.min(w.mag-m.mag,m.res);m.mag+=tk;m.res-=tk;P.rl=0}}
if(left>0){spT-=dt;if(spT<=0){spawn();left--;spT=Math.max(.35,1.3-wave*.06)}}
Z.forEach(z=>{const an=Math.atan2(P.y-z.y,P.x-z.x),d=Math.hypot(P.x-z.x,P.y-z.y);z.x+=Math.cos(an)*z.s*dt;z.y+=Math.sin(an)*z.s*dt;z.cd-=dt;z.fl-=dt;if(d<z.r+14&&z.cd<=0){z.cd=.8;P.hp-=z.d;shake=6;SND.play('hurt');burst(P.x,P.y,8,'#d22',160,.4)}});
B.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.l-=dt;if(XS.part&&!XS.perf&&Math.random()<.5&&PT.length<260)PT.push({x:q.x,y:q.y,vx:(Math.random()-.5)*40,vy:(Math.random()-.5)*40,l:.25,m:.25,c:q.col});if(q.x<0||q.y<0||q.x>AW||q.y>AH)q.l=0;for(const z of Z){if(q.l<=0)break;if(q.hit.includes(z))continue;if(Math.hypot(z.x-q.x,z.y-q.y)<z.r+3){if(q.ex){boom(q.x,q.y,q.ex,q.d);q.l=0}else{hurtZ(z,q.d);q.hit.push(z);if(q.pi--<=0)q.l=0;else q.d*=.8}}}});
B=B.filter(q=>q.l>0);Z.filter(z=>z.hp<=0).forEach(die);Z=Z.filter(z=>z.hp>0);
if(P.hp<=0){finish();return}
if(left<=0&&!Z.length){P.boss=0;const bn=25+wave*10;sv.coins+=bn;earn+=bn;P.hp=Math.min(P.mhp,P.hp+15);save();SND.play('win');st='shop';aim.on=0;mf=0;shop(T('مكافأة النجاة: +','Survival bonus: +')+bn,1)}}
PT.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.92;p.vy*=.92;p.l-=dt});PT=PT.filter(p=>p.l>0);msgT-=dt;shake=Math.max(0,shake-dt*20)}
const cx=Math.min(AW-W,Math.max(0,P.x-W/2)),cy=Math.min(AH-HH,Math.max(0,P.y-HH/2)),sx=(Math.random()-.5)*shake,sy=(Math.random()-.5)*shake;
x.setTransform(1,0,0,1,0,0);x.fillStyle='#0e0a18';x.fillRect(0,0,W,HH);x.translate(sx,sy);x.strokeStyle='#ffffff0a';x.lineWidth=1;for(let i=-(cx%60);i<W;i+=60){x.beginPath();x.moveTo(i,0);x.lineTo(i,HH);x.stroke()}for(let j=-(cy%60);j<HH;j+=60){x.beginPath();x.moveTo(0,j);x.lineTo(W,j);x.stroke()}
x.strokeStyle='#a66cff55';x.strokeRect(-cx,-cy,AW,AH);
Z.forEach(z=>{const X=z.x-cx,Y=z.y-cy;x.fillStyle='#0006';x.beginPath();x.ellipse(X,Y+z.r*.7,z.r,z.r*.45,0,0,7);x.fill();x.fillStyle=z.fl>0?'#fff':z.c;x.beginPath();x.arc(X,Y,z.r,0,7);x.fill();x.fillStyle='#f33';const ea=Math.atan2(P.y-z.y,P.x-z.x);x.fillRect(X+Math.cos(ea)*z.r*.5-2,Y+Math.sin(ea)*z.r*.5-4,4,3);x.fillRect(X+Math.cos(ea)*z.r*.5-2,Y+Math.sin(ea)*z.r*.5+1,4,3);x.fillStyle='#000a';x.fillRect(X-z.r,Y-z.r-8,z.r*2,4);x.fillStyle='#4ade80';x.fillRect(X-z.r,Y-z.r-8,z.r*2*Math.max(0,z.hp/z.mh),4)});
x.save();if(!XS.perf)x.lineCap='round';B.forEach(q=>{const px=q.x-cx,py=q.y-cy;x.strokeStyle=q.col;x.globalAlpha=.35;x.lineWidth=q.ex?11:6;x.beginPath();x.moveTo(px,py);x.lineTo(px-q.vx*.05,py-q.vy*.05);x.stroke();x.globalAlpha=1;x.lineWidth=q.ex?4:2;x.stroke();x.fillStyle='#fff';x.beginPath();x.arc(px,py,q.ex?4:2,0,6.283);x.fill()});x.restore();
const PX=P.x-cx,PY=P.y-cy;x.fillStyle='#0006';x.beginPath();x.ellipse(PX,PY+10,13,6,0,0,7);x.fill();heroDraw(x,PX,PY,P.ang,P.inv,WP[P.w].col,time);if(P.fl>0){x.fillStyle='#fff9';x.beginPath();x.arc(PX+Math.cos(P.ang)*46,PY+Math.sin(P.ang)*46,11,0,7);x.fill()}
x.save();if(!XS.perf)x.globalCompositeOperation='lighter';PT.forEach(p=>{const k=Math.max(0,p.l/p.m);x.globalAlpha=k;x.fillStyle=p.c;x.beginPath();x.arc(p.x-cx,p.y-cy,1.5+k*2.5,0,6.283);x.fill()});x.restore();x.globalAlpha=1;
const g=x.createRadialGradient(PX,PY,60,PX,PY,260);g.addColorStop(0,'transparent');g.addColorStop(1,'#000c');x.fillStyle=g;x.fillRect(-10,-10,W+20,HH+20);
x.setTransform(1,0,0,1,0,0);x.fillStyle='#000a';x.fillRect(8,8,130,10);x.fillStyle=P.hp/P.mhp>.35?'#4ade80':'#ef4444';x.fillRect(8,8,130*Math.max(0,P.hp/P.mhp),10);x.fillStyle='#fff';x.font='700 12px sans-serif';x.fillText('❤ '+Math.ceil(Math.max(0,P.hp)),12,30);x.fillText('💰 '+sv.coins,12,46);x.textAlign='right';x.fillText(T('الموجة ','Wave ')+wave+'  •  '+T('متبقي ','Left ')+(left+Z.length),W-8,18);const m=AM[P.w];x.fillStyle=RC[WP[P.w].r];x.fillText(WP[P.w].n[+en]+'  '+(P.rl>0?T('تعبئة...','Reloading...'):m.mag+' / '+m.res),W-8,HH-10);x.textAlign='left';
if(msgT>0){x.globalAlpha=Math.min(1,msgT);x.fillStyle='#fff';x.font='900 38px sans-serif';x.textAlign='center';x.fillText(msg,W/2,HH/2-60);x.textAlign='left';x.globalAlpha=1}
if(paused){x.fillStyle='#000a';x.fillRect(0,0,W,HH);x.fillStyle='#fff';x.font='900 30px sans-serif';x.textAlign='center';x.fillText('PAUSE (P)',W/2,HH/2);x.textAlign='left'}});
b.querySelector('#ei').textContent=T('WASD + الماوس + R تعبئة + Q تبديل + P إيقاف • الجوال: عصا يسار للحركة وعصا يمين للتصويب والإطلاق','WASD + mouse • R reload • Q switch • P pause • Mobile: left stick moves, right stick aims & fires');
shop(T('اشترِ قبل البدء - أرباحك محفوظة','Shop before you start - progress is saved'),1)}

/* ===== V2: new playable games ===== */
function gTBattle(b,a){const qs=pickQuestions('مختلط',40);let i=0,lv=3,sc=0,st=0,tl=12;
const fin=()=>a.end(sc,'انتهت المعركة - '+sc+' نقطة');
const show=()=>{if(i>=qs.length)return fin();const q=qs[i];tl=12;b.innerHTML=`<div class="info">${'❤'.repeat(lv)} · النقاط <b>${sc}</b> · سلسلة ×${1+Math.min(st,5)} · <b id="tb">12</b>ث</div><div class="qq">${esc(q.q)}</div><div class="opts">${q.a.map((x,k)=>`<button class="btn opt" data-k="${k}">${esc(x)}</button>`).join('')}</div>`};
const ans=k=>{const q=qs[i];b.querySelectorAll('.opt').forEach((x,j)=>{x.disabled=true;if(j===q.c)x.classList.add('good');else if(j===k)x.classList.add('badc')});if(k===q.c){sc+=10*(1+Math.min(st,5))+tl;st++;SFX.ok()}else{lv--;st=0;SFX.bad()}i++;a.t(()=>lv<=0?fin():show(),900)};
b.onclick=e=>{const t=e.target.closest('.opt');if(t&&!t.disabled)ans(+t.dataset.k)};
a.i(()=>{const e=b.querySelector('#tb');if(!e||b.querySelector('.opt:disabled'))return;tl--;e.textContent=tl;if(tl<=0)ans(-1)},1000);show()}
function gTypeArena(b,a){const W=['مدرسة','برمجة','سيارة','قهوة','صاروخ','كتاب','ذكاء','سرعة','تحدي','نجمة','بحر','جبل','لعبة','فريق','قمر','شمس','طائرة','حاسوب','مكتبة','صحراء','حديقة','مطعم'];let t=30,sc=0,w=shuf(W),i=0,ch=0;
b.innerHTML='<div class="info">⏱ <b id="ta">30</b> ث · كلمات <b id="tc">0</b></div><div class="big" id="tw"></div><div class="info" id="tn"></div><input id="ti" autocomplete="off" placeholder="اكتب الكلمة…">';
const nx=()=>{if(i>=w.length-1){w=shuf(W);i=0}b.querySelector('#tw').textContent=w[i];b.querySelector('#tn').textContent='التالي: '+w[i+1]};const inp=b.querySelector('#ti');
b.oninput=()=>{if(inp.value.trim()===w[i]){sc++;ch+=w[i].length;t=Math.min(45,t+(w[i].length>4?2:1));i++;inp.value='';SFX.ok();b.querySelector('#tc').textContent=sc;nx()}};
a.i(()=>{t--;b.querySelector('#ta').textContent=t;if(t<=0)a.end(sc,sc+' كلمة ('+ch+' حرف)')},1000);nx();inp.focus()}
function gRhythm(b,a){const c=CV(b,320,480),x=c.getContext('2d'),CL=['#ff5a6e','#ffd23f','#4cd964','#4aa8ff'],F=[330,392,494,587];let N=[],t=0,nb=0,sc=0,cb=0,ms=0,fl=[0,0,0,0],jt='',jT=0,dn=0;
const hit=l=>{let bs=null;N.forEach(n=>{if(n.l===l&&!n.h&&(!bs||Math.abs(n.y-400)<Math.abs(bs.y-400)))bs=n});fl[l]=.15;if(bs&&Math.abs(bs.y-400)<50){const p=Math.abs(bs.y-400)<18;bs.h=1;sc+=Math.round((p?100:50)*(1+Math.min(cb,20)/10));cb++;jt=p?'مثالي!':'جيد';jT=.5;snd(F[l],.12,'triangle')}else{cb=0;ms++;SFX.bad()}};
KEYS(a,{KeyD:()=>hit(0),KeyF:()=>hit(1),KeyJ:()=>hit(2),KeyK:()=>hit(3)});
EL(a,c,'pointerdown',e=>{e.preventDefault();const r=c.getBoundingClientRect();hit(Math.max(0,Math.min(3,((e.clientX-r.left)/r.width*4)|0)))});
LOOP(a,dt=>{t+=dt;nb-=dt;if(nb<=0&&t<58){const l=Math.random()*4|0;N.push({l,y:-20});if(t>20&&Math.random()<.3)N.push({l:(l+1+(Math.random()*3|0))%4,y:-20});nb=Math.max(.28,.62-t/150)}
const sp=240+t*2;N.forEach(n=>{n.y+=sp*dt;if(!n.h&&n.y>452&&!n.m){n.m=1;cb=0;ms++}});N=N.filter(n=>n.y<500&&!n.h);fl=fl.map(v=>Math.max(0,v-dt));jT-=dt;
x.fillStyle='#0d0a1a';x.fillRect(0,0,320,480);for(let l=0;l<4;l++){x.fillStyle=CL[l]+(fl[l]>0?'55':'18');x.fillRect(l*80,0,80,480);x.fillStyle='#ffffff14';x.fillRect(l*80,0,1,480)}
x.fillStyle='#fff';x.fillRect(0,398,320,4);N.forEach(n=>{x.fillStyle=CL[n.l];x.shadowColor=CL[n.l];x.shadowBlur=10;x.fillRect(n.l*80+8,n.y-12,64,24);x.shadowBlur=0});
x.fillStyle='#fff';x.font='900 18px sans-serif';x.fillText('النقاط '+sc,10,24);x.fillText('كومبو '+cb,10,46);x.fillText('⏱ '+Math.max(0,Math.ceil(60-t)),270,24);if(jT>0){x.textAlign='center';x.font='900 30px sans-serif';x.fillText(jt,160,200);x.textAlign='left'}
if(t>=60&&!dn){dn=1;a.end(sc,'نتيجتك '+sc+' - أخطاء '+ms)}});
b.querySelector('#ei').textContent='D F J K أو المس الأعمدة - اضغط عند خط الإيقاع';}
function gGolf(b,a){const c=CV(b,360,420),x=c.getContext('2d'),H=[{b:[180,370],h:[180,60],w:[[110,200,140,16]]},{b:[60,370],h:[300,60],w:[[0,250,230,16],[130,130,230,16]]},{b:[180,385],h:[300,50],w:[[100,300,16,120],[250,150,16,150],[100,150,150,16]]}];let k=0,st=0,tot=0,B,V,dr=null,dn=0;
const ld=()=>{const h=H[k];B={x:h.b[0],y:h.b[1]};V={x:0,y:0};st=0;dn=0};ld();
const pos=e=>{const r=c.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*360,y:(e.clientY-r.top)/r.height*420}};
EL(a,c,'pointerdown',e=>{e.preventDefault();if(Math.hypot(V.x,V.y)<4&&!dn)dr=pos(e)});EL(a,c,'pointermove',e=>{if(dr)dr=pos(e)});
EL(a,document,'pointerup',()=>{if(!dr)return;const dx=B.x-dr.x,dy=B.y-dr.y,m=Math.hypot(dx,dy),d=Math.min(110,m);if(d>8){V.x=dx/m*d*5.5;V.y=dy/m*d*5.5;st++;SFX.tap()}dr=null});
LOOP(a,dt=>{if(!dn){for(let q=0;q<4;q++){B.x+=V.x*dt/4;B.y+=V.y*dt/4;if(B.x<7){B.x=7;V.x=Math.abs(V.x)}if(B.x>353){B.x=353;V.x=-Math.abs(V.x)}if(B.y<7){B.y=7;V.y=Math.abs(V.y)}if(B.y>413){B.y=413;V.y=-Math.abs(V.y)}
H[k].w.forEach(([wx,wy,ww,wh])=>{const cx=Math.max(wx,Math.min(B.x,wx+ww)),cy=Math.max(wy,Math.min(B.y,wy+wh)),dx=B.x-cx,dy=B.y-cy;if(dx*dx+dy*dy<49){const sx=dx<0?-1:1,sy=dy<0?-1:1;if(Math.abs(dx)>Math.abs(dy)){V.x=sx*Math.abs(V.x);B.x=cx+sx*7.1}else{V.y=sy*Math.abs(V.y);B.y=cy+sy*7.1}}})}
const f=Math.pow(.28,dt);V.x*=f;V.y*=f;if(Math.hypot(V.x,V.y)<12)V.x=V.y=0;const h=H[k].h;if(Math.hypot(B.x-h[0],B.y-h[1])<12&&Math.hypot(V.x,V.y)<420){dn=1;tot+=st;SFX.ok();a.t(()=>{k++;if(k>=H.length)a.end(tot,'أنهيت الملاعب بـ '+tot+' ضربة');else ld()},700)}}
x.fillStyle='#2f9e4f';x.fillRect(0,0,360,420);x.fillStyle='#ffffff10';for(let i=0;i<420;i+=40)x.fillRect(0,i,360,20);
x.fillStyle='#7a4a21';H[k].w.forEach(w=>x.fillRect(...w));const h=H[k].h;x.fillStyle='#000';x.beginPath();x.arc(h[0],h[1],12,0,7);x.fill();x.fillStyle='#ef4444';x.fillRect(h[0],h[1]-34,2,34);x.fillRect(h[0],h[1]-34,14,8);
if(dr&&!dn){x.strokeStyle='#fff';x.setLineDash([6,6]);x.lineWidth=3;x.beginPath();x.moveTo(B.x,B.y);x.lineTo(B.x+(B.x-dr.x),B.y+(B.y-dr.y));x.stroke();x.setLineDash([])}
x.fillStyle='#fff';x.beginPath();x.arc(B.x,B.y,7,0,7);x.fill();x.fillStyle='#fff';x.font='900 16px sans-serif';x.fillText('حفرة '+(k+1)+'/'+H.length+' · ضربات '+st,10,22)});
b.querySelector('#ei').textContent='اسحب للخلف من الكرة ثم أفلت - الأقل ضربات أفضل';}
function gTycoon(b,a){
 const W=640,H=360,KEY='ams-tycoon-v3',c=CV(b,W,H),x=c.getContext('2d'); const rr=(x0,a0,b0,w,h,r)=>{x0.beginPath();x0.moveTo(a0+r,b0);x0.arcTo(a0+w,b0,a0+w,b0+h,r);x0.arcTo(a0+w,b0+h,a0,b0+h,r);x0.arcTo(a0,b0+h,a0,b0,r);x0.arcTo(a0,b0,a0+w,b0,r);x0.closePath()};
 const LV=[[1,'محل صغير',0,6,1],[2,'محل متوسط',250,4.6,1.3],[3,'سوبرماركت',900,3.6,1.7],[4,'مول مصغر',3000,2.8,2.2],[5,'مول كبير',9000,2.3,2.9],[6,'مجمع تجاري',24000,1.9,3.8]];
 let D={m:60,tot:0,lvl:1,stock:20,cash:0,clean:0,tool:1,shelf:1,served:0,goal:0,rent:0,ad:0,cof:0,wh:0};
 try{const o=JSON.parse(localStorage.getItem(KEY)||'null');if(o&&typeof o.m==='number')D=Object.assign(D,o)}catch(e){}
 const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(D))}catch(e){}};
 const GL=[['اخدم 10 زبائن',()=>D.served>=10,40,1],['اجمع 300 عملة',()=>D.tot>=300,80,1],['وظّف كاشير',()=>D.cash,0,1],['ارفع المحل للمستوى 2',()=>D.lvl>=2,120,2],['اخدم 40 زبون',()=>D.served>=40,150,2],['وظّف عامل نظافة',()=>D.clean,0,2],['طوّر الإعلان للمستوى 1',()=>D.ad>=1,100,2],['ارفع المحل للمستوى 3',()=>D.lvl>=3,250,3],['اجمع 1500 عملة',()=>D.tot>=1500,400,3],['ركّب ماكينة قهوة',()=>D.cof>=1,200,3],['ارفع المحل للمستوى 4',()=>D.lvl>=4,500,4],['اجمع 5000 عملة',()=>D.tot>=5000,800,4],['أرفف مستوى 4',()=>D.shelf>=4,600,4],['ارفع المحل للمستوى 5',()=>D.lvl>=5,900,5],['اجمع 12000 عملة',()=>D.tot>=12000,1200,5],['مخزن مستوى 2',()=>D.wh>=2,700,5],['إعلان مستوى 3',()=>D.ad>=3,800,6],['ارفع المحل للمستوى 6',()=>D.lvl>=6,2500,6],['ماكينة قهوة مستوى 3',()=>D.cof>=3,1800,6],['اجمع 40000 عملة',()=>D.tot>=40000,4000,7],['أرفف مستوى 6',()=>D.shelf>=6,3000,7],['الملياردير: اجمع 100000 عملة',()=>D.tot>=100000,0,8]];
 const price=()=>Math.round(9*LV[D.lvl-1][4]*(1+.15*(D.shelf-1))*(1+.12*D.cof)),UNIT=4;
 let cu=[],dirt=[],fx=[],em=[{k:'cash',x:575,y:178,hx:575,hy:178},{k:'clean',x:300,y:320,hx:300,hy:320}],t=0,sp=2,dt2=0,sv=0,rent=0,mop={x:-99,y:-99,on:0},ban='',banT=0,done=0,cd=0,ui=0;
 const dirtiness=()=>Math.min(1,dirt.reduce((s,d)=>s+d.d,0)/(4+D.lvl*2));
 const spot=(px,py)=>{if(dirt.length<6+D.lvl*3)dirt.push({x:px+(Math.random()-.5)*24,y:Math.min(335,Math.max(110,py+(Math.random()-.5)*20)),d:.5+Math.random()*.5,r:9+Math.random()*7})};
 const nShelf=()=>Math.min(6,2+D.lvl),shx=i=>70+i*(400/nShelf());
 const queue=()=>cu.filter(q=>q.st==='queue'||q.st==='pay').sort((p,q)=>p.qi-q.qi);
 const mk=()=>{const cols=['#ff5a6e','#4aa8ff','#7bd957','#ffd23f','#e87bd2','#ff9f43'];cu.push({x:40,y:352,st:'in',tx:shx(Math.random()*nShelf()|0),ty:120,tm:0,want:1+(Math.random()*3|0),col:cols[Math.random()*6|0],mood:1,sp:70+Math.random()*30,ph:Math.random()*6,qi:0,wait:0})};
 const sell=q=>{const p=q.want*price(),tip=dirtiness()<.25?Math.round(p*.15):dirtiness()>.6?-Math.round(p*.2):0,g=p+tip;D.stock-=q.want;D.m+=g;D.tot+=g;D.served++;q.st='out';q.mood=dirtiness()>.6?0:2;q.tx=40;q.ty=352;SFX.coin();for(let i=0;i<8;i++)fx.push({x:q.x,y:q.y-20,vx:(Math.random()-.5)*100,vy:-60-Math.random()*60,l:.7,c:'#ffd36b',tx:'+'+g,show:i===0});if(Math.random()<.4)spot(q.x,q.y+16);uiRefresh()};
 const msg=m=>{ban=m;banT=2.2};
 const buy=(cost,fn)=>{if(D.m<cost){SFX.bad();return}D.m-=cost;fn();SFX.buy();save();uiRefresh()};
 const acts={
  stock:()=>{const n=[10,20,35,50][D.wh|0];buy(Math.round(UNIT*n*(1-.06*(D.wh|0))),()=>{D.stock+=n})},wh:()=>{if((D.wh|0)<3)buy([500,1500,4000][D.wh|0],()=>{D.wh=(D.wh|0)+1;msg('مخزن أكبر: تعبئة أكثر وأرخص')})},
  lvl:()=>{const n=LV[D.lvl];if(!n)return;buy(n[2],()=>{D.lvl++;SFX.upgrade();msg('تمت الترقية: '+n[1])})},
  cash:()=>{if(!D.cash)buy(150,()=>{D.cash=1})},
  clean:()=>{if(!D.clean)buy(220,()=>{D.clean=1})},
  tool:()=>{if(D.tool<4)buy([0,80,250,700][D.tool],()=>{D.tool++})},
  shelf:()=>{if(D.shelf<6)buy([0,120,350,900,2200,5000][D.shelf],()=>{D.shelf++})},ad:()=>{if(D.ad<3)buy([200,600,1500][D.ad],()=>{D.ad++;msg('إعلان أقوى: زبائن أكثر')})},cof:()=>{if(D.cof<3)buy([300,800,2000][D.cof],()=>{D.cof++;msg('ماكينة قهوة: أسعار أعلى')})}};
 const ctr=document.createElement('div');ctr.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px';b.appendChild(ctr);
 const btns={};[['stock'],['wh'],['lvl'],['cash'],['clean'],['tool'],['shelf'],['ad'],['cof']].forEach(([k])=>{const e=document.createElement('button');e.className='btn';e.style.cssText='min-height:50px;font-size:13px;line-height:1.3';ctr.appendChild(e);btns[k]=e;EL(a,e,'click',()=>acts[k]())});
 const fin=document.createElement('button');fin.className='btn danger';fin.style.cssText='grid-column:1/-1;min-height:44px';fin.innerHTML=ic('flag')+' إنهاء وحفظ النتيجة';ctr.appendChild(fin);EL(a,fin,'click',()=>{save();a.end(D.tot|0,'خلّصت الجلسة - إجمالي الأرباح '+(D.tot|0))});
 function uiRefresh(){const L=(k,txt,cost,dis)=>{btns[k].innerHTML=txt+(cost!=null?'<br><b>'+cost+'</b>':'');btns[k].disabled=dis||(cost!=null&&D.m<cost);btns[k].style.opacity=btns[k].disabled?.5:1};
  const sn=[10,20,35,50][D.wh|0];L('stock',ic('box')+' تعبئة المخزون +'+sn,Math.round(UNIT*sn*(1-.06*(D.wh|0))));L('wh',ic('box')+' مخزن مستوى '+(D.wh|0)+((D.wh|0)<3?' (تعبئة أكبر وأرخص)':' ✔'),(D.wh|0)<3?[500,1500,4000][D.wh|0]:null,(D.wh|0)>=3);const n=LV[D.lvl];L('lvl',n?ic('store')+' ترقية إلى '+n[1]:ic('store')+' أعلى مستوى',n?n[2]:null,!n);
  L('cash',D.cash?ic('person')+' الكاشير يعمل':ic('person')+' توظيف كاشير (راتب)',D.cash?null:150,!!D.cash);L('clean',D.clean?ic('broom')+' عامل النظافة يعمل':ic('broom')+' توظيف عامل نظافة',D.clean?null:220,!!D.clean);
  L('tool',ic('sparkle')+' أداة التنظيف مستوى '+D.tool+(D.tool<4?' ←':' ✔'),D.tool<4?[0,80,250,700][D.tool]:null,D.tool>=4);L('shelf',ic('shelf')+' أرفف مستوى '+D.shelf+(D.shelf<6?' (+15% سعر)':' ✔'),D.shelf<6?[0,120,350,900,2200,5000][D.shelf]:null,D.shelf>=6);L('ad',ic('flag')+' إعلان مستوى '+D.ad+(D.ad<3?' (+زبائن)':' ✔'),D.ad<3?[200,600,1500][D.ad]:null,D.ad>=3);L('cof',ic('sparkle')+' ماكينة قهوة '+D.cof+(D.cof<3?' (+12% سعر)':' ✔'),D.cof<3?[300,800,2000][D.cof]:null,D.cof>=3)}
 uiRefresh();a.i(()=>{save();uiRefresh()},3000);
 const pt=e=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)/r.width*W,(e.clientY-r.top)/r.height*H]};
 EL(a,c,'pointerdown',e=>{e.preventDefault();const[px,py]=pt(e);mop.on=1;mop.x=px;mop.y=py;if(px>480&&py>130&&py<300){const q=queue().find(z=>z.st==='pay');if(q)sell(q)}});
 EL(a,c,'pointermove',e=>{const[px,py]=pt(e);mop.x=px;mop.y=py});['pointerup','pointercancel','pointerleave'].forEach(n=>EL(a,c,n,()=>{mop.on=0}));
 b.querySelector('#ei').textContent='اسحب على الأوساخ لتنظيفها · اضغط على الكاشير/الكاونتر لخدمة الزبون · اشترِ المخزون والتطويرات بالأسفل';
 LOOP(a,dt=>{if(done)return;t+=dt;banT=Math.max(0,banT-dt);sv+=dt;
  dt2-=dt;const iv=LV[D.lvl-1][3]*(dirtiness()>.5?1.5:1)*(1-.15*D.ad);if(dt2<=0&&cu.length<6+D.lvl*2){mk();dt2=iv*(.7+Math.random()*.6)}
  rent+=dt;if(rent>=30){rent=0;const exp=5*D.lvl+(D.cash?3:0)+(D.clean?3:0);D.m=Math.max(0,D.m-exp);msg('مصاريف: −'+exp+' (إيجار/رواتب)');uiRefresh()}
  if((cd-=dt)<=0){cd=Math.max(4,9-(GL[D.goal]?GL[D.goal][3]:5));spot(100+Math.random()*350,150+Math.random()*180)}
  queue().forEach((q,i)=>{q.qi=i});
  cu.forEach(q=>{q.ph+=dt*8;const dx=q.tx-q.x,dy=q.ty-q.y,dd=Math.hypot(dx,dy);
   if(q.st==='in'||q.st==='out'||q.st==='queue'){const arrived=dd<4;if(!arrived){const v=q.sp*(q.st==='out'?1.2:1)*dt;q.x+=dx/dd*v;q.y+=dy/dd*v}
    if(q.st==='in'&&arrived){q.st='shelf';q.tm=1+Math.random()}
    if(q.st==='out'&&arrived)q.dead=1}
   if(q.st==='shelf'){q.tm-=dt;if(q.tm<=0){if(D.stock>=q.want){q.st='queue';q.qi=99}else{q.st='out';q.mood=0;q.tx=40;q.ty=352;msg('خلص المخزون!');SFX.bad()}}}
   if(q.st==='queue'||q.st==='pay'){const i=q.qi;q.tx=540-(i>0?18:0);q.ty=250+i*26;if(i===0&&Math.hypot(q.x-q.tx,q.y-q.ty)<6&&q.st!=='pay'){q.st='pay';q.wait=0}
    q.wait+=dt;if(q.st==='pay'&&D.cash){q.wait+=0;if(q.wait>1.2)sell(q)}
    if(q.wait>(q.st==='pay'?16:30)&&!D.cash){q.st='out';q.mood=0;q.tx=40;q.ty=352;SFX.bad()}
    if(q.st==='pay'&&q.wait>7&&q.mood===1)q.mood=3}});
  cu=cu.filter(q=>!q.dead);
  em.forEach(e=>{if(e.k==='clean'&&D.clean){const d=dirt.slice().sort((p,q)=>Math.hypot(p.x-e.x,p.y-e.y)-Math.hypot(q.x-e.x,q.y-e.y))[0];const tx=d?d.x:e.hx,ty=d?d.y:e.hy,dx=tx-e.x,dy=ty-e.y,dd=Math.hypot(dx,dy);if(dd>6){e.x+=dx/dd*75*dt;e.y+=dy/dd*75*dt}else if(d){d.d-=.45*dt;if(Math.random()<.2)fx.push({x:d.x,y:d.y,vx:(Math.random()-.5)*40,vy:-30,l:.4,c:'#9be7ff'})}}});
  if(mop.on){const R=16+10*D.tool;let hit=0;dirt.forEach(d=>{if(Math.hypot(d.x-mop.x,d.y-mop.y)<R+d.r*.5){d.d-=dt*.5*(1+D.tool*.6);hit=1;if(Math.random()<.5)fx.push({x:d.x,y:d.y,vx:(Math.random()-.5)*60,vy:-40,l:.4,c:'#9be7ff'})}});if(hit&&(sp-=dt)<=0){SFX.swoosh();sp=.25}}
  const before=dirt.length;dirt=dirt.filter(d=>d.d>0);if(dirt.length<before){D.m+=1;SFX.pop()}
  fx.forEach(f=>{f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=120*dt;f.l-=dt});fx=fx.filter(f=>f.l>0);
  const g=GL[D.goal];if(g&&g[1]()){D.m+=g[2];SFX.win();{const nx=GL[D.goal+1];const ns=nx&&nx[3]!==g[3];msg((ns?'اكتملت المرحلة '+g[3]+'! ':'هدف مكتمل: ')+g[0]+(g[2]?' +'+g[2]:''));if(ns)SFX.levelup()}D.goal++;save();uiRefresh();if(D.goal>=GL.length){done=1;save();a.t(()=>a.end(D.tot|0,'صرت ملياردير المحل! الأرباح '+(D.tot|0)),1200)}}
   x.textAlign='left';
   const fgr=x.createLinearGradient(0,100,0,H);fgr.addColorStop(0,'#d9b07a');fgr.addColorStop(1,'#b98a52');x.fillStyle=fgr;x.fillRect(0,100,W,H-100);
   x.strokeStyle='#00000018';x.lineWidth=1;for(let j=100,k=0;j<H;j+=30,k++){x.beginPath();x.moveTo(0,j);x.lineTo(W,j);x.stroke();for(let i=(k%2)*45;i<W;i+=90){x.beginPath();x.moveTo(i,j);x.lineTo(i,j+30);x.stroke()}}
   const wgr=x.createLinearGradient(0,0,0,100);wgr.addColorStop(0,'#5b3f8f');wgr.addColorStop(1,'#3a2766');x.fillStyle=wgr;x.fillRect(0,0,W,100);
   x.fillStyle='#ffffff10';for(let i=0;i<W;i+=32)x.fillRect(i,0,2,100);
   x.fillStyle='#2a1c4d';x.fillRect(0,92,W,9);x.fillStyle='#ffd36b';x.fillRect(0,98,W,3);
   for(let i=0;i<nShelf();i++){const sx0=shx(i);x.fillStyle='#0003';x.fillRect(sx0-30,94,64,8);x.fillStyle='#6b4a2e';rr(x,sx0-32,40,64,54,4);x.fill();x.fillStyle='#3d2a18';x.fillRect(sx0-28,44,56,46);x.fillStyle='#8a6038';x.fillRect(sx0-28,66,56,4);x.fillRect(sx0-28,88,56,3);
    const f=Math.min(1,D.stock/(10+10*D.lvl));['#ff5a6e','#ffd23f','#4aa8ff','#7bd957'].forEach((c2,k)=>{if(f>(k+1)/6)for(let m=0;m<4;m++){const bx=sx0-26+m*13,by=(k%2)?68:46;x.fillStyle=c2;rr(x,bx,by,11,16,3);x.fill();x.fillStyle='#ffffff55';x.fillRect(bx+2,by+2,3,12)}})}
   x.fillStyle='#0003';x.fillRect(496,205,122,10);const cgr=x.createLinearGradient(0,150,0,210);cgr.addColorStop(0,'#b07a3c');cgr.addColorStop(1,'#7a4d22');x.fillStyle=cgr;rr(x,500,150,110,60,8);x.fill();x.fillStyle='#d9a25e';rr(x,500,150,110,12,6);x.fill();
   x.fillStyle='#2a2f45';rr(x,512,155,40,26,4);x.fill();x.fillStyle='#4de1a0';x.fillRect(516,158,32,10);x.fillStyle='#ffffff88';x.fillRect(518,172,12,3);x.fillStyle='#ffd36b';x.beginPath();x.arc(584,160,6,0,7);x.fill();
   x.fillStyle='#2a1c4d';rr(x,8,334,64,26,5);x.fill();x.fillStyle='#8fd3ff55';rr(x,12,338,26,22,3);x.fill();rr(x,42,338,26,22,3);x.fill();x.fillStyle='#fff9';x.font='11px sans-serif';x.fillText('باب',28,354);
  dirt.forEach(d=>{x.globalAlpha=Math.min(1,.3+d.d*.7);x.fillStyle='#4a3a28';x.beginPath();x.ellipse(d.x,d.y,d.r,d.r*.7,0,0,7);x.fill();x.fillStyle='#37291b';x.beginPath();x.ellipse(d.x+3,d.y-2,d.r*.5,d.r*.35,0,0,7);x.fill();x.globalAlpha=1});
  const person=(px,py,col,ph,walk,hat)=>{const bob=walk?Math.abs(Math.sin(ph))*2:0,lg=walk?Math.sin(ph)*4:0;x.fillStyle='#0003';x.beginPath();x.ellipse(px,py+14,10,3.5,0,0,7);x.fill();x.fillStyle='#2b2146';rr(x,px-6+lg,py+3,5,11,2);x.fill();rr(x,px+1-lg,py+3,5,11,2);x.fill();x.fillStyle=col;rr(x,px-8,py-9-bob,16,15,6);x.fill();x.fillStyle='#ffffff30';rr(x,px-8,py-9-bob,16,6,5);x.fill();x.fillStyle=col;x.fillRect(px-11,py-7-bob+lg*.3,4,9);x.fillRect(px+7,py-7-bob-lg*.3,4,9);x.fillStyle='#f3c9a0';x.beginPath();x.arc(px,py-15-bob,6.5,0,7);x.fill();x.fillStyle='#2a1a12';x.beginPath();x.arc(px,py-17-bob,6.5,Math.PI,0);x.fill();x.fillStyle='#222';x.fillRect(px-3,py-15-bob,1.6,1.6);x.fillRect(px+1.5,py-15-bob,1.6,1.6);if(hat){x.fillStyle=hat;rr(x,px-7,py-23-bob,14,5,2);x.fill()}};
  em.forEach(e=>{if(e.k==='cash'&&D.cash)person(e.x,e.y,'#4ade80',t*6,0,'#fff');if(e.k==='clean'&&D.clean)person(e.x,e.y,'#4aa8ff',t*8,Math.hypot(e.x-e.hx,e.y-e.hy)>3||dirt.length>0,'#ffd36b')});
  cu.slice().sort((p,q)=>p.y-q.y).forEach(q=>{const walk=q.st==='in'||q.st==='out'||(q.st!=='shelf'&&q.st!=='pay'&&Math.hypot(q.tx-q.x,q.ty-q.y)>4);person(q.x,q.y,q.col,q.ph,walk,0);
   const bub=q.st==='shelf'?'…':q.st==='pay'?(q.mood===3?'!':'$'):q.mood===0&&q.st==='out'?'!':q.mood===2&&q.st==='out'?'✓':'';if(bub){const by=q.y-28+Math.sin(t*4)*2;x.fillStyle={'$':'#ffd36b','…':'#4aa8ff','!':'#e0344a','✓':'#4ade80'}[bub];x.beginPath();x.arc(q.x,by,8,0,7);x.fill();x.fillStyle='#111';x.font='700 11px sans-serif';x.textAlign='center';x.fillText(bub,q.x,by+4);x.textAlign='left'}});
  fx.forEach(f=>{x.globalAlpha=Math.max(0,f.l*2);if(f.show){x.fillStyle='#ffd36b';x.font='700 13px sans-serif';x.fillText(f.tx,f.x,f.y)}else{x.fillStyle=f.c;x.fillRect(f.x,f.y,3,3)}});x.globalAlpha=1;
  if(mop.on&&mop.x>0){x.strokeStyle='#9be7ff';x.lineWidth=2;x.beginPath();x.arc(mop.x,mop.y,16+10*D.tool,0,7);x.stroke()}
   x.textAlign='left';x.fillStyle='#000a';x.fillRect(0,0,W,30);x.font='700 13px Cairo,sans-serif';const cl=Math.round((1-dirtiness())*100);
   let hx=6;[['عملات '+(D.m|0),'#ffd36b'],['مخزون '+D.stock,'#4aa8ff'],['نظافة '+cl+'%',cl<50?'#ff5a6e':'#4ade80'],[LV[D.lvl-1][1],'#a66cff'],['السعر '+price(),'#ff9f43']].forEach(([tt,cc])=>{const w=x.measureText(tt).width+30;x.fillStyle='#ffffff18';rr(x,hx,5,w,20,10);x.fill();x.fillStyle=cc;x.beginPath();x.arc(hx+11,15,4,0,7);x.fill();x.fillStyle='#fff';x.fillText(tt,hx+20,19.5);hx+=w+6});
   const g2=GL[D.goal];if(g2){x.font='700 13px Cairo,sans-serif';const tt='المرحلة '+g2[3]+' - '+g2[0],w=x.measureText(tt).width+20;x.fillStyle='#000a';rr(x,6,74,w,20,10);x.fill();x.fillStyle='#ffd36b';x.fillText(tt,16,88.5)}
  if(banT>0){x.globalAlpha=Math.min(1,banT);x.fillStyle='#000c';x.fillRect(0,36,W,26);x.fillStyle='#fff';x.textAlign='center';x.fillText(ban,W/2,54);x.textAlign='left';x.globalAlpha=1}
 });
}

/* ===== Replacement for every formerly-coming-soon tile: real playable games ===== */
function gTowerDef(b,a){let hp=10,wave=1,gold=80,kills=0,started=false;const draw=()=>{b.innerHTML=`<div class="info">🏰 صحة القلعة: <b>${hp}</b> · موجة <b>${wave}</b> · 💰 ${gold} · هزائم ${kills}</div><div class="card" style="width:100%;text-align:center"><div style="font-size:54px">🏰</div><p>الأعداء يقتربون! اشترِ دفاعات أو ابدأ الموجة.</p><div class="row"><button class="btn p" data-t="arrow">🏹 برج سهام (30)</button><button class="btn" data-t="bomb">💥 قنبلة (45)</button></div><button class="btn p" data-t="wave">ابدأ الموجة ${wave}</button></div>`};b.onclick=e=>{let t=e.target.closest('[data-t]')?.dataset.t;if(!t)return;if(t==='arrow'&&gold>=30){gold-=30;kills+=2;SFX.play('hit')}else if(t==='bomb'&&gold>=45){gold-=45;kills+=4;SFX.play('boom')}else if(t==='wave'){started=true;hp-=Math.max(1,Math.ceil(wave/3));gold+=25+wave*5;wave++;SFX.play('wave');if(hp<=0){a.end(kills,'سقطت القلعة بعد '+(wave-1)+' موجة');return}}else SFX.play('bad');draw()};draw()}
function gDungeon(b,a){let room=1,hp=5,loot=0;const rooms=[['🕸️','ممر مظلم','تابع بحذر'],['🧟','حارس الزنزانة','قاتله أو حاول تجاوزه'],['💎','غرفة الكنز','اختر طريقك'],['🧙','الساحر الغامض','قرارك يحدد مصيرك'],['🚪','البوابة الأخيرة','وصلت للنهاية']];const draw=()=>{let q=rooms[Math.min(room-1,4)];b.innerHTML=`<div class="info">❤️ ${hp} · 💎 الغنائم ${loot} · غرفة ${room}/5</div><div class="card" style="width:100%;text-align:center"><div style="font-size:58px">${q[0]}</div><h3>${q[1]}</h3><p>${q[2]}</p><div class="opts"><button class="btn p" data-d="fight">⚔️ استكشف / قاتل</button><button class="btn" data-d="safe">🛡️ اختر الطريق الآمن</button><button class="btn" data-d="loot">💰 فتّش الغرفة</button></div></div>`};b.onclick=e=>{let k=e.target.closest('[data-d]')?.dataset.d;if(!k)return;if(k==='fight'){if(Math.random()<.65){loot+=15+room*5;SFX.play('hit')}else hp--}if(k==='safe'){loot+=4;SFX.play('click')}if(k==='loot'){if(Math.random()<.6)loot+=20+room*4;else hp--;SFX.play('coin')}room++;if(hp<=0){a.end(loot,'انتهت المغامرة - الغنائم '+loot);return}if(room>5){a.end(loot+hp*10,'نجوت من السرداب! الغنائم '+loot);return}draw()};draw()}
function gKart(b,a){let lane=1,score=0,left=30,dead=false;const draw=()=>{b.innerHTML=`<div class="info">🏁 النقاط ${score} · ⏱ ${left} ثانية</div><div class="grid3">${[0,1,2].map(i=>`<button class="btn ${i===lane?'p':''}" data-l="${i}" style="min-height:100px;font-size:30px">${i===lane?'🏎️':'🛣️'}</button>`).join('')}</div><p class="info">بدّل المسار لتفادي الحواجز القادمة.</p><button class="btn p" data-k="go">اندفع! ⚡</button>`};b.onclick=e=>{let l=e.target.closest('[data-l]');if(l){lane=+l.dataset.l;draw();return}if(e.target.closest('[data-k]')){if(Math.random()<.27){a.end(score,'اصطدمت! نقاط السباق '+score);return}score+=10;SFX.play('whoosh');draw()}};a.i(()=>{left--;if(left<=0)a.end(score,'أنهيت السباق بـ '+score+' نقطة');else draw()},1000);draw()}
function gBossRush(b,a){
 const W=640,H=360,GY=300,c=CV(b,W,H),x=c.getContext('2d');
 const BO=[{n:'الجولم الحجري',hp:140,w:70,h:80,t:0,col:'#9a8f7a'},{n:'التنين الناري',hp:200,w:90,h:56,t:1,col:'#e0344a'},{n:'الروبوت الحارس',hp:260,w:60,h:84,t:2,col:'#3df2ff'}];
 const K={l:0,r:0,j:0};let P={x:110,y:GY-34,w:22,h:34,vx:0,vy:0,on:1,face:1,hp:100,inv:0,atk:0,acd:0,roll:0,rcd:0,hit:0},lv=0,B,pr=[],fx=[],shake=0,sc=0,t=0,over=0,txt='',txtT=0,stop=0,gap=0;
 const burst=(px,py,col,n,sp)=>{for(let i=0;i<n;i++){const r=Math.random()*6.28,v=(sp||120)*(.3+Math.random());fx.push({x:px,y:py,vx:Math.cos(r)*v,vy:Math.sin(r)*v-30,l:.5,c:col})}};
 const spawnBoss=()=>{const d=BO[lv];B=Object.assign({},d,{max:d.hp,x:470,y:GY-d.h,vx:0,vy:0,st:'idle',tm:1.3,face:-1,fl:0,act:'',ly:0});pr=[];txt='الزعيم '+(lv+1)+' - '+d.n;txtT=2;SFX.powerup()};spawnBoss();
 const hurt=(d,fromX)=>{if(P.inv>0||P.roll>0||over)return;P.hp-=d;P.inv=1;P.vx=(P.x<fromX?-1:1)*220;P.vy=-260;P.on=0;shake=.25;SFX.hit();burst(P.x+11,P.y+17,'#ff5a6e',10);if(P.hp<=0){P.hp=0;over=1;SFX.die();burst(P.x+11,P.y+17,'#ff5a6e',30,200);a.t(()=>a.end(sc,'هزمك '+B.n+' - النقاط '+sc),1000)}};
 const atk=()=>{if(P.acd>0||over||P.roll>0)return;P.atk=.18;P.acd=.34;P.hit=0;SFX.shoot()};
 const roll=()=>{if(P.rcd>0||over)return;P.roll=.28;P.rcd=.8;P.inv=Math.max(P.inv,.32);P.vx=P.face*340;SFX.swoosh()};
 const jump=()=>{if(P.on&&!over){P.vy=-560;P.on=0;SFX.jump()}};
 const kd=v=>e=>{const k=e.code;if(k==='ArrowLeft'||k==='KeyA')K.l=v;else if(k==='ArrowRight'||k==='KeyD')K.r=v;else if(k==='Space'||k==='ArrowUp'||k==='KeyW'){if(v)jump()}else if(k==='KeyJ'||k==='KeyZ'||k==='KeyK'){if(v)atk()}else if(k==='ShiftLeft'||k==='KeyL'||k==='KeyX'){if(v)roll()}else return;e.preventDefault()};
 EL(a,document,'keydown',kd(1));EL(a,document,'keyup',kd(0));
 const pad=document.createElement('div');pad.style.cssText='display:flex;gap:8px;margin-top:10px;direction:ltr';
 [[ic('arrowL'),()=>K.l=1,()=>K.l=0,1],[ic('arrowR'),()=>K.r=1,()=>K.r=0,1],[ic('arrowU'),jump,0,1],[ic('sword'),atk,0,1.3],[ic('dash'),roll,0,1]].forEach(([lb,dn,up,f])=>{const e=document.createElement('button');e.className='btn p';e.style.cssText='flex:'+f+';min-height:64px;font-size:22px;touch-action:none;user-select:none';e.innerHTML=lb;pad.appendChild(e);EL(a,e,'pointerdown',v=>{v.preventDefault();dn()});if(up)['pointerup','pointercancel','pointerleave'].forEach(n=>EL(a,e,n,up))});
 b.appendChild(pad);b.querySelector('#ei').textContent='A D حركة · Space قفز · J/Z هجوم · Shift/L تدحرج (حصانة لحظية)';
 const ov=(r)=>P.x<r.x+r.w&&P.x+P.w>r.x&&P.y<r.y+r.h&&P.y+P.h>r.y;
 const choose=()=>{const r=Math.random();B.face=P.x<B.x?-1:1;B.tgx=P.x;
  B.act=B.t===0?(r<.5?'charge':'slam'):B.t===1?(r<.55?'fire':'swoop'):(r<.35?'laser':r<.6?'laserHi':'charge');B.st='tele';B.tm=B.act==='fire'?.45:.7;SFX.tick()};
 const go=()=>{B.st='act';const f=B.face;
  if(B.act==='charge'){B.vx=f*(380+lv*30);B.tm=.7}
  else if(B.act==='slam'){B.vy=-650;B.vx=Math.max(-260,Math.min(260,(P.x-B.x)*.9));B.tm=2}
  else if(B.act==='fire'){for(let i=-1;i<=1;i++){const an=Math.atan2(P.y-B.y,P.x-B.x)+i*.28;pr.push({x:B.x,y:B.y+10,vx:Math.cos(an)*230,vy:Math.sin(an)*230,r:9,k:'f'})}SFX.shoot();B.tm=.4}
  else if(B.act==='swoop'){B.vx=(B.tgx-B.x)/.55;B.vy=(GY-B.h-B.y)/.55;B.tm=.8}
  else{B.ly=B.act==='laser'?GY-14:GY-72;B.tm=.5;SFX.zap()}};
 LOOP(a,dt=>{dt*=stop>0?.12:1;stop=Math.max(0,stop-dt);t+=dt;txtT=Math.max(0,txtT-dt);shake=Math.max(0,shake-dt);P.inv=Math.max(0,P.inv-dt);P.acd=Math.max(0,P.acd-dt);P.rcd=Math.max(0,P.rcd-dt);P.atk=Math.max(0,P.atk-dt);P.roll=Math.max(0,P.roll-dt);
  if(!over){if(P.roll<=0)P.vx+=((K.r-K.l)*200-P.vx)*Math.min(1,(P.on?14:6)*dt);if(K.r-K.l&&P.roll<=0)P.face=K.r-K.l;
   P.vy+=1700*dt;P.x=Math.max(10,Math.min(W-10-P.w,P.x+P.vx*dt));P.y+=P.vy*dt;if(P.y>=GY-P.h){if(!P.on&&P.vy>300)SFX.land();P.y=GY-P.h;P.vy=0;P.on=1}}
  if(B&&!over){B.fl=Math.max(0,B.fl-dt);
   if(B.hp>0){
    if(B.st==='idle'){B.tm-=dt;if(B.t===1){B.y+=(100+Math.sin(t*2)*18-B.y)*3*dt;B.x+=((P.x<320?460:180)-B.x)*.8*dt}if(B.tm<=0)choose()}
    else if(B.st==='tele'){B.tm-=dt;if(B.tm<=0)go()}
    else{B.tm-=dt;B.x+=B.vx*dt;B.y+=B.vy*dt;
     if(B.act==='slam'){B.vy+=1700*dt;if(B.y>=GY-B.h){B.y=GY-B.h;B.vx=0;B.vy=0;B.st='idle';B.tm=1.1;shake=.35;SFX.boom();burst(B.x+B.w/2,GY,'#c9b99a',16);pr.push({x:B.x,y:GY-14,vx:-260,vy:0,r:10,k:'w'},{x:B.x+B.w,y:GY-14,vx:260,vy:0,r:10,k:'w'})}}
     else if(B.act==='swoop'){if(B.y>=GY-B.h-2||B.tm<=0){B.vx=0;B.vy=0;B.st='idle';B.tm=.9;shake=.15}}
     else if(B.tm<=0){B.vx=0;B.st='idle';B.tm=B.t===2?.9:1.1-lv*.1}
     if(B.act==='charge'&&(B.x<10||B.x+B.w>W-10)){B.x=Math.max(10,Math.min(W-10-B.w,B.x));B.vx=0;B.tm=Math.min(B.tm,.1);shake=.2;SFX.hit()}
     if((B.act==='laser'||B.act==='laserHi')&&Math.abs(P.y+P.h/2-B.ly)<P.h/2+7)hurt(18,B.x)}
    B.x=Math.max(5,Math.min(W-5-B.w,B.x));
    if(ov(B)&&(B.st!=='act'||B.act!=='fire'))hurt(B.st==='act'?18:8,B.x+B.w/2);
    if(P.atk>0&&!P.hit){const r={x:P.face>0?P.x+P.w:P.x-46,y:P.y-4,w:46,h:42};if(r.x<B.x+B.w&&r.x+r.w>B.x&&r.y<B.y+B.h&&r.y+r.h>B.y){P.hit=1;B.hp-=12+lv*2;B.fl=.12;stop=.06;sc+=10;SFX.hit();burst(B.x+B.w/2,B.y+B.h/2,'#fff',10);if(B.hp<=0){B.hp=0;sc+=200;SFX.boom();burst(B.x+B.w/2,B.y+B.h/2,B.col,50,260);shake=.5;pr=[];B.st='dead';gap=1.6}}}}
   else if(B.st==='dead'){gap-=dt;if(gap<=0){lv++;if(lv>=BO.length){over=1;a.end(sc+P.hp*3,'هزمت جميع الزعماء! الصحة المتبقية '+P.hp);return}P.hp=Math.min(100,P.hp+35);SFX.upgrade();spawnBoss()}}}
  pr.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;if(!over&&Math.hypot(P.x+11-q.x,P.y+17-q.y)<q.r+13)hurt(q.k==='w'?14:12,q.x)});pr=pr.filter(q=>q.x>-20&&q.x<W+20&&q.y<H);
  fx.forEach(f=>{f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=260*dt;f.l-=dt});fx=fx.filter(f=>f.l>0);
  x.save();if(shake>0)x.translate((Math.random()-.5)*10,(Math.random()-.5)*10);
  const sk=x.createLinearGradient(0,0,0,H);sk.addColorStop(0,'#120a25');sk.addColorStop(1,'#3a1f5c');x.fillStyle=sk;x.fillRect(-10,-10,W+20,H+20);
  [80,240,400,560].forEach(px=>{x.fillStyle='#ffffff0c';x.fillRect(px,40,24,GY-40);x.fillStyle='rgba(255,170,60,'+(.5+.2*Math.sin(t*6+px))+')';x.beginPath();x.arc(px+12,70,7,0,7);x.fill()});
  x.fillStyle='#2a1a3c';x.fillRect(0,GY,W,H-GY);x.fillStyle='#a66cff';x.fillRect(0,GY,W,3);
  if(B&&B.st!=='dead'){const bx=B.x,by=B.y,fl=B.fl>0;x.save();x.translate(bx+B.w/2,by+B.h/2);x.scale(-B.face,1);x.fillStyle=fl?'#fff':B.col;
   if(B.t===0){x.fillRect(-35,-40,70,80);x.fillStyle=fl?'#fff':'#7d735f';x.fillRect(-45,-20,12,50);x.fillRect(33,-20,12,50)}
   else if(B.t===1){x.beginPath();x.ellipse(0,0,36,22,0,0,7);x.fill();const w=Math.sin(t*10)*22;x.beginPath();x.moveTo(-10,-10);x.lineTo(-40,-34-w);x.lineTo(-48,-2);x.fill();x.beginPath();x.moveTo(8,-10);x.lineTo(34,-30+w);x.lineTo(46,-2);x.fill();x.fillRect(30,-14,22,16)}
   else{x.fillRect(-30,-42,60,84);x.fillStyle=fl?'#fff':'#16314a';x.fillRect(-22,-30,44,20)}
   x.fillStyle=B.st==='tele'?'#ff2d2d':'#ffe14a';x.shadowColor=x.fillStyle;x.shadowBlur=10;x.fillRect(8,-24,8,6);x.fillRect(-4,-24,8,6);x.shadowBlur=0;x.restore();
   if(B.st==='tele'){x.fillStyle='#ff2d2d';x.font='800 28px sans-serif';x.textAlign='center';x.fillText('!',bx+B.w/2,by-8);x.textAlign='left';if(B.act==='laser'||B.act==='laserHi'){x.fillStyle='#ff2d2d55';x.fillRect(0,(B.act==='laser'?GY-14:GY-72)-1,W,2)}}
   if(B.st==='act'&&(B.act==='laser'||B.act==='laserHi')){x.fillStyle='#ff4d4d';x.shadowColor='#ff4d4d';x.shadowBlur=18;x.fillRect(0,B.ly-5,W,10);x.shadowBlur=0}}
  pr.forEach(q=>{x.fillStyle=q.k==='w'?'#c9b99a':'#ff8a3c';x.shadowColor=x.fillStyle;x.shadowBlur=10;x.beginPath();x.arc(q.x,q.y,q.r,0,7);x.fill();x.shadowBlur=0});
  if(!over||P.hp>0){if(P.inv>0&&Math.floor(t*20)%2)x.globalAlpha=.4;x.save();x.translate(P.x+11,P.y+34);x.scale(P.face,1);if(P.roll>0)x.rotate(t*30);const lg=P.on&&Math.abs(P.vx)>20?Math.sin(t*16)*4:0;
   x.fillStyle='#4aa8ff';x.fillRect(-7,-24,14,14);x.fillStyle='#f1c59a';x.fillRect(-7,-34,14,11);x.fillStyle='#222';x.fillRect(2,-30,3,3);x.fillStyle='#3a2a6a';x.fillRect(-6+lg,-10,5,10);x.fillRect(1-lg,-10,5,10);x.fillStyle='#ffd36b';x.fillRect(-10,-18,4,10);
   if(P.atk>0){x.strokeStyle='#fff';x.shadowColor='#a66cff';x.shadowBlur=14;x.lineWidth=5;x.beginPath();x.arc(4,-16,34,-1.1,1.1);x.stroke();x.shadowBlur=0}x.restore();x.globalAlpha=1}
  fx.forEach(f=>{x.globalAlpha=Math.max(0,f.l*2);x.fillStyle=f.c;x.fillRect(f.x,f.y,4,4)});x.globalAlpha=1;x.restore();
  x.fillStyle='#000a';x.fillRect(10,10,200,12);x.fillStyle='#4ade80';x.fillRect(10,10,200*P.hp/100,12);x.fillStyle='#fff';x.font='700 12px sans-serif';x.fillText('الصحة '+P.hp,14,32);x.fillText('النقاط '+sc,150,32);
  if(B){x.fillStyle='#000a';x.fillRect(W-310,10,300,14);x.fillStyle='#e0344a';x.fillRect(W-310,10,300*Math.max(0,B.hp)/B.max,14);x.textAlign='right';x.fillText(B.n,W-12,38);x.textAlign='left'}
  if(txtT>0){x.globalAlpha=Math.min(1,txtT);x.fillStyle='#fff';x.font='800 24px sans-serif';x.textAlign='center';x.fillText(txt,W/2,110);x.textAlign='left';x.globalAlpha=1}
 });
}

function gEscape(b,a){const code=String(100+Math.random()*900|0),hints=['الرقم الأوسط أكبر من الأول.','مجموع الأرقام يساوي '+code.split('').reduce((s,n)=>s+ +n,0)+'.','الرمز السري من ثلاثة أرقام.'];let tries=0;b.innerHTML=`<div class="card" style="width:100%"><div class="big">🔐</div><h3>افتح باب الهروب</h3><p class="info">${hints[1]}</p><input id="ec" inputmode="numeric" maxlength="3" placeholder="اكتب الرمز من 3 أرقام"><button class="btn p" id="eg">جرّب الرمز</button><p id="eh" class="info">لديك محاولات غير محدودة، وكل محاولة تكشف تلميحًا.</p></div>`;b.querySelector('#eg').onclick=()=>{let v=b.querySelector('#ec').value.trim();tries++;if(v===code){a.end(Math.max(10,100-tries*5),'فتحت الباب وهربت في '+tries+' محاولة!')}else{b.querySelector('#eh').textContent='غير صحيح. '+(tries%3===0?'التلميح الأخير: الرمز هو '+code:(tries%2?hints[0]:hints[2]));SFX.play('bad')}}}
function gSurvival(b,a){let day=1,food=3,water=3,wood=0,hp=100;b.innerHTML='';const draw=()=>{b.innerHTML=`<div class="info">☀️ اليوم ${day}/7 · ❤️ ${hp} · 🍎 ${food} · 💧 ${water} · 🪵 ${wood}</div><div class="big">🏕️</div><p class="info">اجمع مواردك واصمد سبعة أيام.</p><div class="opts"><button class="btn" data-s="food">🍎 جمع طعام</button><button class="btn" data-s="water">💧 جمع ماء</button><button class="btn" data-s="wood">🪵 جمع خشب</button><button class="btn p" data-s="sleep">🌙 نهاية اليوم</button></div>`};b.onclick=e=>{let k=e.target.closest('[data-s]')?.dataset.s;if(!k)return;if(k==='food')food+=1+(Math.random()*2|0);if(k==='water')water+=1+(Math.random()*2|0);if(k==='wood')wood+=1+(Math.random()*3|0);if(k==='sleep'){day++;food--;water--;if(food<0){hp-=18;food=0}if(water<0){hp-=24;water=0}if(wood>=2){wood-=2;hp=Math.min(100,hp+10)}if(hp<=0){a.end(day-1,'لم تصمد أكثر - الأيام '+(day-1));return}if(day>7){a.end(hp+food*5+water*5+wood*2,'نجوت أسبوعًا كاملًا!');return}}SFX.play('click');draw()};draw()}
if(!SFX.power)SFX.power=SFX.powerup;if(!SFX.play)SFX.play=n=>(SFX[n]||SFX.tap)();
function gParkour(b,a){
 const W=640,H=360,T=32,c=CV(b,W,H),x=c.getContext('2d'),NL=5;
 const rnd=sd=>()=>(sd=(sd*1664525+1013904223)>>>0)/4294967296;
 const build=lv=>{const r=rnd(lv*7919+13),P=[],Sp=[],Co=[],Cp=[];let px=0,py=9;const n=9+lv*3;
  P.push({x:-T*4,y:py*T,w:10*T,h:500});Cp.push({x:3*T,y:py*T,on:1});px=6*T;
  for(let i=0;i<n;i++){const g=Math.min(3.4*T,(2+r()*(1.2+lv*.35))*T)|0,w=(3+(r()*4|0))*T,dy=(r()*3-1.2)|0;
   py=Math.max(5,Math.min(10,py+dy));px+=g;P.push({x:px,y:py*T,w,h:500});
   if(w>=5*T&&r()<.35+lv*.08)Sp.push({x:px+((w/T/2)|0)*T,y:py*T-14,w:T,h:14});
   if(r()<.7)for(let k=0;k<2;k++)Co.push({x:px+w/2-16+k*32,y:py*T-48,g:0});
   if(i%4===3)Cp.push({x:px+T,y:py*T,on:0});px+=w}
  return{P,Sp,Co,Cp,end:{x:px-2*T,y:py*T},len:px}};
 let lv=0,L=build(0),p,cam=0,cpI=0,coins=0,deaths=0,tm=0,tot=0,t=0,dead=0,ban=1.6,fx=[],sq=1,done=0;
 const K={l:0,r:0,j:0},spawn=()=>{const q=L.Cp[cpI];p={x:q.x,y:q.y-34,w:20,h:30,vx:0,vy:0,on:0,face:1,coy:0,jb:0,wasOn:0}};spawn();
 const dust=(px,py,n,col)=>{for(let i=0;i<n;i++)fx.push({x:px,y:py,vx:(Math.random()-.5)*120,vy:-Math.random()*80,l:.4,c:col||'#ffffffaa'})};
 const kd=v=>e=>{const k=e.code;if(k==='ArrowLeft'||k==='KeyA'){K.l=v;e.preventDefault()}else if(k==='ArrowRight'||k==='KeyD'){K.r=v;e.preventDefault()}else if(k==='Space'||k==='ArrowUp'||k==='KeyW'){if(v&&!K.j)p.jb=.12;K.j=v;e.preventDefault()}};
 EL(a,document,'keydown',kd(1));EL(a,document,'keyup',kd(0));
 const pad=document.createElement('div');pad.style.cssText='display:flex;justify-content:space-between;gap:10px;margin-top:10px;direction:ltr';
 [[ic('arrowL'),'l'],[ic('arrowR'),'r'],[ic('arrowU')+' قفز','j']].forEach(([lab,k])=>{const e=document.createElement('button');e.className='btn p bigbtn';e.style.cssText='flex:'+(k==='j'?2:1)+';min-height:66px;font-size:22px;touch-action:none;user-select:none';e.innerHTML=lab;pad.appendChild(e);
  EL(a,e,'pointerdown',v=>{v.preventDefault();K[k]=1;if(k==='j')p.jb=.12});['pointerup','pointercancel','pointerleave'].forEach(n=>EL(a,e,n,()=>{K[k]=0}))});
 b.appendChild(pad);b.querySelector('#ei').textContent='◀ ▶ / A D للحركة - Space / ↑ للقفز (اضغط أطول للقفز أعلى)';
 const hit=(r,q)=>p.x<q.x+q.w&&p.x+p.w>q.x&&p.y<q.y+q.h&&p.y+p.h>q.y;
 const die=()=>{if(dead)return;dead=.7;deaths++;SFX.die();dust(p.x+10,p.y+15,16,'#ff5a6e');if(deaths%1===0)tot+=0};
 const next=()=>{SFX.win();tot+=tm;lv++;if(lv>=NL){done=1;const sc=Math.max(0,coins*10+NL*150-deaths*8+Math.max(0,700-tot|0));a.end(sc,'أنهيت كل المراحل! عملات '+coins+' · سقطات '+deaths+' · الوقت '+(tot|0)+'ث');return}L=build(lv);cpI=0;tm=0;spawn();ban=1.6;cam=0};
 LOOP(a,dt=>{if(done)return;t+=dt;ban=Math.max(0,ban-dt);
  if(dead){dead-=dt;if(dead<=0){dead=0;spawn()}}
  else{tm+=dt;p.jb=Math.max(0,p.jb-dt);p.coy=p.on?.1:p.coy-dt;
   const tg=(K.r-K.l)*190;p.vx+=(tg-p.vx)*Math.min(1,(p.on?14:7)*dt);if(tg)p.face=Math.sign(tg);
   if(p.jb>0&&p.coy>0){p.vy=-520;p.coy=0;p.jb=0;p.on=0;SFX.jump();dust(p.x+10,p.y+30,5);sq=1.25}
   p.vy+=(K.j||p.vy>0?1500:3000)*dt;p.vy=Math.min(p.vy,900);
   p.x+=p.vx*dt;for(const q of L.P)if(hit(p,q)){if(p.vx>0)p.x=q.x-p.w;else if(p.vx<0)p.x=q.x+q.w;p.vx=0}
   const pv=p.vy;p.y+=p.vy*dt;p.wasOn=p.on;p.on=0;
   for(const q of L.P)if(hit(p,q)){if(p.vy>0){p.y=q.y-p.h;p.on=1}else p.y=q.y+q.h;p.vy=0}
   if(p.on&&!p.wasOn&&pv>260){SFX.land();dust(p.x+10,p.y+30,6);sq=.7}
   sq+=(1-sq)*Math.min(1,10*dt);
   for(const s of L.Sp)if(hit(p,{x:s.x+5,y:s.y+3,w:s.w-10,h:s.h}))die();
   if(p.y>H+120)die();
   L.Cp.forEach((q,i)=>{if(i>cpI&&p.x>q.x){cpI=i;q.on=1;SFX.powerup();dust(q.x,q.y-20,12,'#4ade80')}});
   L.Co.forEach(q=>{if(!q.g&&Math.hypot(p.x+10-q.x,p.y+15-q.y)<22){q.g=1;coins++;SFX.coin();dust(q.x,q.y,8,'#ffd36b')}});
   if(hit(p,{x:L.end.x-6,y:L.end.y-70,w:44,h:70}))next()}
  fx.forEach(f=>{f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=300*dt;f.l-=dt});fx=fx.filter(f=>f.l>0);
  cam+=(Math.max(0,Math.min(L.len-W+200,p.x-W*.35))-cam)*Math.min(1,6*dt);
  const sk=x.createLinearGradient(0,0,0,H);sk.addColorStop(0,'#1b1050');sk.addColorStop(1,'#5b3aa8');x.fillStyle=sk;x.fillRect(0,0,W,H);
  x.fillStyle='#ffffff40';for(let i=0;i<30;i++)x.fillRect((i*97-cam*.1+W*3)%W,(i*53)%200,2,2);
  x.fillStyle='#2a1a63';x.beginPath();x.moveTo(0,H);for(let i=0;i<=W;i+=20)x.lineTo(i,250-40*Math.sin((i+cam*.3)/70)-20*Math.sin((i+cam*.3)/23));x.lineTo(W,H);x.fill();
  x.save();x.translate(-cam|0,0);
  L.P.forEach(q=>{if(q.x+q.w<cam-10||q.x>cam+W+10)return;x.fillStyle='#5b3a24';x.fillRect(q.x,q.y,q.w,H-q.y+40);x.fillStyle='#4ade80';x.fillRect(q.x,q.y,q.w,8);x.fillStyle='#3cb866';for(let i=q.x;i<q.x+q.w;i+=16)x.fillRect(i,q.y+8,8,4)});
  x.fillStyle='#e8e8f0';L.Sp.forEach(s=>{for(let i=0;i<3;i++){x.beginPath();x.moveTo(s.x+i*T/3,s.y+s.h);x.lineTo(s.x+i*T/3+T/6,s.y);x.lineTo(s.x+(i+1)*T/3,s.y+s.h);x.fill()}});
  L.Cp.forEach(q=>{x.fillStyle='#ddd';x.fillRect(q.x,q.y-44,3,44);x.fillStyle=q.on?'#4ade80':'#888';x.beginPath();x.moveTo(q.x+3,q.y-44);x.lineTo(q.x+26,q.y-36+Math.sin(t*5)*2);x.lineTo(q.x+3,q.y-28);x.fill()});
  const e=L.end;x.fillStyle='#ffd36b';x.fillRect(e.x+12,e.y-64,4,64);x.shadowColor='#ffd36b';x.shadowBlur=14;x.beginPath();x.moveTo(e.x+16,e.y-64);x.lineTo(e.x+42,e.y-52+Math.sin(t*6)*2);x.lineTo(e.x+16,e.y-40);x.fill();x.shadowBlur=0;
  L.Co.forEach(q=>{if(q.g)return;x.fillStyle='#ffd36b';x.shadowColor='#ffd36b';x.shadowBlur=8;x.beginPath();x.ellipse(q.x,q.y,Math.abs(Math.cos(t*4+q.x))*7+1,7,0,0,7);x.fill();x.shadowBlur=0});
  if(!dead){const px=p.x+10,py=p.y+30,run=p.on&&Math.abs(p.vx)>20,lg=Math.sin(t*16)*5*(run?1:0);x.save();x.translate(px,py);x.scale(p.face*(1/Math.sqrt(sq)),sq);
   x.fillStyle='#ff5a6e';x.fillRect(-12,-22+(p.on?0:2),8,4);x.fillStyle='#4aa8ff';x.fillRect(-7,-20,14,14);x.fillStyle='#f1c59a';x.fillRect(-7,-30,14,11);x.fillStyle='#222';x.fillRect(2,-26,3,3);x.fillStyle='#3a2a6a';x.fillRect(-6+lg,-6,5,6);x.fillRect(1-lg,-6,5,6);x.restore()}
  fx.forEach(f=>{x.globalAlpha=Math.max(0,f.l*2.5);x.fillStyle=f.c;x.fillRect(f.x,f.y,4,4)});x.globalAlpha=1;x.restore();
  x.fillStyle='#fff';x.font='700 15px sans-serif';x.textAlign='left';x.fillText('المرحلة '+(lv+1)+'/'+NL+'  ·  عملات '+coins+'  ·  سقطات '+deaths+'  ·  '+(tm|0)+'ث',10,22);
  x.fillStyle='#ffffff30';x.fillRect(10,30,W-20,5);x.fillStyle='#a66cff';x.fillRect(10,30,(W-20)*Math.min(1,p.x/L.len),5);
  if(ban>0){x.globalAlpha=Math.min(1,ban);x.fillStyle='#000a';x.fillRect(0,140,W,70);x.fillStyle='#fff';x.font='800 28px sans-serif';x.textAlign='center';x.fillText('المرحلة '+(lv+1),W/2,185);x.textAlign='left';x.globalAlpha=1}
 });
}


/* ===== V2: icons, categories, grouping ===== */
G.push({id:'towerdef',n:'الأبراج',i:'memory',c:'استراتيجية',p:'1',l:'متوسط',d:'ابنِ دفاعك وصدّ موجات الأعداء.',run:gTowerDef},{id:'dungeon',n:'السرداب',i:'odd',c:'أكشن',p:'1',l:'متوسط',d:'اختار طريقك وجمّع الغنايم في سرداب يتغير كل مرة.',run:gDungeon},{id:'kart',n:'الكارت',i:'react',c:'أكشن',p:'1',l:'سهل',d:'بدّل المسارات وانطلق وسجّل نقاط.',run:gKart},{id:'bossrush',n:'الزعماء',i:'zombie',c:'أكشن',p:'1',l:'صعب',d:'قاتل 3 زعماء: اضرب وتدحرج وانط وتفادى ضرباتهم.',run:gBossRush},{id:'escape',n:'الهروب',i:'code',c:'ذكاء',p:'1',l:'متوسط',d:'حل لغز الرمز وافتح باب الهروب.',run:gEscape},{id:'survival',n:'البقاء',i:'memory',c:'استراتيجية',p:'1',l:'متوسط',d:'جمّع أكل وموية وخشب وعيش أسبوع كامل.',run:gSurvival},{id:'parkour',n:'الباركور',i:'tap',c:'سرعة',p:'1',l:'متوسط',d:'منصات وفجوات وأشواك ونقاط حفظ، تحرك وانط عبر 5 مراحل.',run:gParkour});
G.push({id:'tbattle',n:'معركة المعلومات',c:'ذكاء',p:'1',l:'صعب',d:'3 أرواح، وكل ما جاوبت صح ورا بعض نقاطك تتضاعف، وكل ما خلصت أسرع تاخذ أكثر.',run:gTBattle,r:'أجب قبل انتهاء 12 ثانية. كل خطأ يكلفك قلبًا. السلسلة ترفع المضاعف حتى ×6.'},
{id:'typearena',n:'حلبة الكتابة',c:'سرعة',p:'1',l:'متوسط',d:'اكتب الكلمات وخذ وقت زيادة قبل لا يخلص العد.',run:gTypeArena,r:'ابدأ بـ 30 ثانية. كل كلمة صحيحة تضيف ثانية أو ثانيتين (الأقصى 45).'},
{id:'rhythm',n:'الإيقاع',c:'سرعة',p:'1',l:'متوسط',d:'4 مسارات ونغمات تسرّع وكومبو يضاعف نقاطك.',run:gRhythm,r:'اضغط المسار عندما تصل النوتة لخط الإيقاع. المثالي أعلى نقاطًا. المفاتيح: D F J K.'},
{id:'golf',n:'غولف',c:'أكشن',p:'1',l:'متوسط',d:'3 ملاعب فيها جدران وارتداد، دخّل الكرة بأقل ضربات.',run:gGolf,low:1,r:'اسحب للخلف من الكرة لتحديد الاتجاه والقوة ثم أفلت. الأقل ضربات أفضل.'},
{id:'tycoon',n:'محاكي المتجر',c:'استراتيجية',p:'1',l:'متوسط',d:'دير محلك: زباين وموظفين ونظافة وتطويرات وأهداف.',run:gTycoon,r:'اخدم الزبائن عند الكاونتر، نظّف الأوساخ بالسحب، أعد تعبئة المخزون، ووظّف وطوّر لتحقيق الأهداف.'});

function gOasis(b,a){const T=28,W=12,H=14,ST=[
'الجفاف ضرب واحتك الأخيرة يا حارس الواحة. استعد بلورات الماء الخمس من الكثبان قبل أن تحرسها العقارب.',
'نجحت! لكن العقارب صارت أكثر. اجمع ست بلورات وافتح بوابة المعبد القديم.',
'الفصل الأخير: عقارب الليل تطارد بسرعة. اجمع سبع بلورات وأعد الماء إلى الواحة.'];
let ch=0,lives=3,sc=0,px,py,cr=[],en=[],dr=null,left=0,pause=0,tk=0,done=0,msg=ST[0];
b.innerHTML='<div class="big">🏜️</div><div class="qq">حارس الواحة</div><div class="info">'+ST[0]+'<br>حرّك اللاعب بالأسهم أو الأزرار.</div><button class="btn p" id="go">ابدأ الرحلة</button>';
b.querySelector('#go').onclick=()=>{const c=CV(b,W*T,H*T),x=c.getContext('2d'),ei=b.querySelector('#ei');
const fr=()=>{let q;do{q=[Math.random()*W|0,2+(Math.random()*(H-2)|0)]}while((q[0]==px&&q[1]==py)||[...cr,...en].some(o=>o[0]==q[0]&&o[1]==q[1]));return q};
const setup=()=>{px=W>>1;py=H-1;cr=[];en=[];dr=null;left=4+ch;for(let i=0;i<left;i++)cr.push(fr());for(let i=0;i<2+ch;i++){const q=fr();if(Math.abs(q[0]-px)+Math.abs(q[1]-py)<4)q[1]=2;en.push(q)}pause=2.2;ei.textContent=ST[ch]};
const hit=()=>{if(en.some(e=>e[0]==px&&e[1]==py)){lives--;SFX.bad&&SFX.bad();if(lives<=0){done=1;a.end(sc,'سقط حارس الواحة... جمعت '+sc+' نقطة')}else{px=W>>1;py=H-1;ei.textContent='لدغتك عقرب! بقي لك '+lives+' ❤️'}}};
const mv=(dx,dy)=>{if(pause>0||done)return;const nx=px+dx,ny=py+dy;if(nx<0||ny<0||nx>=W||ny>=H)return;px=nx;py=ny;const i=cr.findIndex(q=>q[0]==px&&q[1]==py);if(i>=0){cr.splice(i,1);left--;sc+=10;SFX.ok&&SFX.ok();if(!left){dr=fr();ei.textContent='البوابة 🚪 فُتحت! اذهب إليها'}}
if(dr&&px==dr[0]&&py==dr[1]){sc+=50*(ch+1);ch++;if(ch>=3){done=1;a.end(sc,'أنقذت الواحة! نقاطك '+sc);return}setup();return}hit()};
DPAD(a,b,mv);KEYS(a,{ArrowUp:()=>mv(0,-1),ArrowDown:()=>mv(0,1),ArrowLeft:()=>mv(-1,0),ArrowRight:()=>mv(1,0),KeyW:()=>mv(0,-1),KeyS:()=>mv(0,1),KeyA:()=>mv(-1,0),KeyD:()=>mv(1,0)});
setup();
LOOP(a,dt=>{if(done)return;if(pause>0)pause-=dt;else{tk+=dt;if(tk>Math.max(.28,.6-ch*.1)){tk=0;en.forEach(e=>{if(Math.random()<.6){const dx=Math.sign(px-e[0]),dy=Math.sign(py-e[1]);if(Math.random()<.5&&dx)e[0]+=dx;else if(dy)e[1]+=dy;else e[0]+=dx}else{const d=[[1,0],[-1,0],[0,1],[0,-1]][Math.random()*4|0];e[0]=Math.max(0,Math.min(W-1,e[0]+d[0]));e[1]=Math.max(0,Math.min(H-1,e[1]+d[1]))}});hit()}}
x.fillStyle='#c9a86a';x.fillRect(0,0,W*T,H*T);x.fillStyle='#b8955a';for(let i=0;i<W;i++)for(let j=0;j<H;j++)if((i+j)%2)x.fillRect(i*T,j*T,T,T);
x.font='22px serif';x.textAlign='center';x.textBaseline='middle';const D=(e,p)=>x.fillText(e,p[0]*T+T/2,p[1]*T+T/2+1);
cr.forEach(q=>D('💎',q));if(dr)D('🚪',dr);en.forEach(q=>D('🦂',q));D('🧑‍🌾',[px,py]);
x.fillStyle='#000a';x.fillRect(0,0,W*T,24);x.fillStyle='#fff';x.font='15px sans-serif';x.fillText('❤️'.repeat(Math.max(lives,0))+'   💎 '+left+'   ⭐ '+sc+'   فصل '+(ch+1)+'/3',W*T/2,12);
if(pause>0){x.fillStyle='#000b';x.fillRect(0,H*T/2-20,W*T,40);x.fillStyle='#ffd36b';x.fillText('الفصل '+(ch+1)+' - استعد!',W*T/2,H*T/2)}})}}
G.push({id:'oasis',n:'حارس الواحة',c:'أكشن',p:'1',l:'متوسط',d:'قصة من 3 فصول: حرّك الحارس وجمّع البلورات وانتبه من العقارب.',run:gOasis,r:'حرّك اللاعب بالأسهم أو الأزرار. اجمع كل البلورات 💎 ثم ادخل البوابة 🚪 وتجنب العقارب 🦂. لديك 3 قلوب.'});
const CM={zombie:'أكشن',dino:'أكشن',snake:'أكشن',flappy:'أكشن',golf:'أكشن',g2048:'ألغاز',lights:'ألغاز',slide:'ألغاز',seqiq:'ألغاز',riddles:'ألغاز',code:'ألغاز',differences:'ألغاز',scramble:'ألغاز',odd:'ألغاز',match:'ألغاز',memory:'ألغاز',number:'ألغاز',math:'سرعة',tap:'سرعة',react:'سرعة',whack:'سرعة',typing:'سرعة',guess:'حظ',rps:'حظ',dice:'حظ'};
const EM={oasis:'🧑‍🌾',zombie:'🧟',dino:'🦖',snake:'🐍',flappy:'🐦',golf:'⛳',g2048:'🧮',lights:'💡',slide:'🧱',seqiq:'📈',riddles:'🧐',code:'🔐',differences:'👀',scramble:'🔀',odd:'🔍',match:'🃏',memory:'🧠',number:'🔢',math:'➕',tap:'👆',react:'⚡',whack:'🔨',typing:'⌨️',typearena:'🚀',rhythm:'🎵',guess:'🎯',rps:'✊',dice:'🎲',xo:'❌',c4:'🔴',tycoon:'💰',quiz:'❓',tbattle:'⚔️',forbid:'🚫',sab:'🕵️',score:'📊',majd:'🏆',carrom:'🪙',detect:'🔎',trivia:'🎓',most:'🙋',categories:'🔤',secretword:'🤫',whoami:'🤔',wordchain:'🔗',truth:'⚖️',mafia:'🌙',categories2:'🏷️',undercover:'🥸',charades:'🎭',fibbage:'🤥',telephone:'📞'};
G.forEach(g=>{if(CM[g.id])g.c=CM[g.id];const e=EM[g.id];if(e){ICON['e_'+g.id]='<text x="12" y="18.5" font-size="19" text-anchor="middle" stroke="none" fill="currentColor">'+e+'</text>';g.i='e_'+g.id}});
EN_CATS['أكشن']='Action';EN_CATS['ألغاز']='Puzzles';
const ST=document.createElement('style');ST.textContent='.ch{grid-column:1/-1;font-weight:900;margin:16px 4px 2px;color:var(--p2);display:flex;gap:8px;align-items:center}.ch:after{content:"";flex:1;height:1px;background:var(--line)}.ch small{color:var(--mu);font-weight:400}';document.head.appendChild(ST);
const CORD=['أكشن','ألغاز','ذكاء','سرعة','حظ','استراتيجية','جماعي','فرق ونقاط'],CEM={'أكشن':'🔥','ألغاز':'🧩','ذكاء':'🧠','سرعة':'⚡','حظ':'🍀','استراتيجية':'♟️','جماعي':'👥','فرق ونقاط':'📋'};
function groupLib(){if(fc!=='الكل'||fq)return;const l=$('#lib'),cs=[...l.querySelectorAll('.gc[data-id]')];if(!cs.length)return;const cat=id=>{const g=G.concat(S.custom).find(x=>x.id===id);return g?g.c:'ألعابي'},ix=c=>{const i=CORD.indexOf(c);return i<0?99:i},mp=new Map(cs.map((e,i)=>[e,[ix(cat(e.dataset.id)),cat(e.dataset.id),i]]));cs.sort((p,q)=>mp.get(p)[0]-mp.get(q)[0]||mp.get(p)[2]-mp.get(q)[2]);let last=null;cs.forEach(e=>{const c=mp.get(e)[1];if(c!==last){last=c;const n=cs.filter(z=>mp.get(z)[1]===c).length,h=document.createElement('div');h.className='ch';h.innerHTML=ic(({'ملحمي':'crown','ذكاء':'brain','سرعة':'react','حظ':'dice','استراتيجية':'c4','جماعي':'users','فرق ونقاط':'score','أكشن':'sword'})[c]||'star')+' '+(LANG==='en'?(EN_CATS[c]||c):c)+' <small>'+n+'</small>';l.appendChild(h)}l.appendChild(e)})}
const _r2=renderLib;renderLib=function(){_r2.apply(this,arguments);try{groupLib()}catch(e){console.error(e)}};
function gFlame(b,a){
 const W=360,H=520,FY=H-92,c=CV(b,W,H),x=c.getContext('2d'),R=Math.random;
 let px=W/2,tx=W/2,size=1,sc=0,t=0,it=[],ps=[],em=[],nx=.6,inf=0,over=0,shake=0,spd=150,sk=0,flash=0,tip=0,tipT=0;
 for(let i=0;i<45;i++)em.push({x:R()*W,y:R()*H,v:12+R()*34,s:1+R()*2,p:R()*6});
 const K={l:0,r:0},kd=v=>e=>{const k=e.code;if(k==='ArrowLeft'||k==='KeyA')K.l=v;else if(k==='ArrowRight'||k==='KeyD')K.r=v;else return;e.preventDefault()};
 EL(a,document,'keydown',kd(1));EL(a,document,'keyup',kd(0));
 const mv=e=>{const r=c.getBoundingClientRect();tx=Math.max(18,Math.min(W-18,(e.clientX-r.left)/r.width*W))};
 EL(a,c,'pointerdown',e=>{e.preventDefault();mv(e)});EL(a,c,'pointermove',mv);
 b.querySelector('#ei').textContent='اسحب بإصبعك أو الأسهم - الحطب يكبّر الشعلة، الماء يطفئها، علبة الوقود تشعل الجحيم';
 const pop=(x0,y0,col,n,sp)=>{for(let i=0;i<n;i++){const r=R()*6.28,v=(sp||90)*(.3+R());ps.push({x:x0,y:y0,vx:Math.cos(r)*v,vy:Math.sin(r)*v-30,l:.6,m:.6,r:2+R()*3,c:col,k:'s'})}};
 const msg=m=>{tip=m;tipT=1.4};
 LOOP(a,dt=>{t+=dt;shake=Math.max(0,shake-dt);flash=Math.max(0,flash-dt);tipT=Math.max(0,tipT-dt);
  if(!over){tx+=(K.r-K.l)*380*dt;tx=Math.max(18,Math.min(W-18,tx));px+=(tx-px)*Math.min(1,11*dt);
   size=Math.max(0,size-dt*(.035+sc/9000));sc+=dt*2;spd=150+Math.min(230,t*3.2);inf=Math.max(0,inf-dt);
   nx-=dt;if(nx<=0){const r=R(),k=r<.42?'wood':r<.68?'water':r<.8?'coal':r<.86?'gas':'hail';it.push({k,x:20+R()*(W-40),y:-20,ph:R()*6,rot:R()*6,r:k==='hail'?15:12});nx=Math.max(.26,.78-t*.004)*(.7+R()*.6)}
   const rad=20+size*16;
   it.forEach(o=>{o.y+=spd*dt*(o.k==='hail'?1.25:1);o.rot+=dt*2;const d=Math.hypot(o.x-px,o.y-FY+10);
    if(d<rad+o.r||(inf>0&&(o.k==='water'||o.k==='hail')&&d<rad*2.2)){o.dead=1;
     if(o.k==='wood'){size=Math.min(2.4,size+.15);sc+=10;SFX.eat();pop(o.x,o.y,'#ffb347',10)}
     else if(o.k==='coal'){size=Math.min(2.4,size+.32);sc+=25;SFX.powerup();pop(o.x,o.y,'#ff6a1a',16,130);flash=.15}
     else if(o.k==='gas'){inf=6;sc+=50;SFX.boom();shake=.4;flash=.3;pop(o.x,o.y,'#6ee7ff',30,220);msg('وضع الجحيم!')}
     else if(inf>0){sc+=8;SFX.pop();pop(o.x,o.y,'#bfefff',8)}
     else{size-=o.k==='hail'?.5:.3;shake=.25;SFX.hit();for(let i=0;i<12;i++)ps.push({x:o.x,y:FY-10,vx:(R()-.5)*60,vy:-40-R()*80,l:.9,m:.9,r:5+R()*5,c:'#bcc7d6',k:'g'})}}});
   it=it.filter(o=>!o.dead&&o.y<H+30);
   if(Math.random()<dt*7)hiss(.05,{f:3500,v:.02});
   if(size<.22){over=1;SFX.die();for(let i=0;i<30;i++)ps.push({x:px+(R()-.5)*20,y:FY,vx:(R()-.5)*50,vy:-30-R()*90,l:1.6,m:1.6,r:6+R()*8,c:'#8a8f9a',k:'g'});a.t(()=>a.end(sc|0,'انطفأت الشعلة! النتيجة '+(sc|0)),1200)}
   const n=Math.round((3+size*7)*dt*60/1.2);for(let i=0;i<n;i++)ps.push({x:px+(R()-.5)*22*Math.min(1.6,size),y:FY+6,vx:(R()-.5)*34*size,vy:-(70+R()*90)*(.8+size*.4),l:.5+R()*.45*size,m:.8,r:(5+R()*8)*Math.min(1.5,size)*(inf>0?1.3:1),c:inf>0?'b':'f',k:'f'})}
  ps.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.l-=dt;if(q.k==='s')q.vy+=240*dt;if(q.k==='g')q.vy-=20*dt});ps=ps.filter(q=>q.l>0);if(ps.length>420)ps.splice(0,ps.length-420);
  x.save();if(shake>0)x.translate((R()-.5)*8,(R()-.5)*8);
  const bg=x.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#07050f');bg.addColorStop(1,'#1d0d12');x.fillStyle=bg;x.fillRect(-10,-10,W+20,H+20);
  x.fillStyle='#ffffff08';for(let i=0;i<5;i++){x.beginPath();x.moveTo(i*90-20,H);x.lineTo(i*90+20,200+(i%2)*60);x.lineTo(i*90+60,H);x.fill()}
  em.forEach(e=>{e.y-=e.v*dt;if(e.y<-5){e.y=H+5;e.x=R()*W}x.fillStyle='rgba(255,140,50,'+(.25+.25*Math.sin(t*3+e.p))+')';x.fillRect(e.x+Math.sin(t+e.p)*8,e.y,e.s,e.s)});
  x.globalCompositeOperation='lighter';const g=x.createRadialGradient(px,FY-20,5,px,FY-20,150*Math.min(1.7,size)+40);g.addColorStop(0,inf>0?'rgba(80,180,255,.45)':'rgba(255,120,30,.4)');g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.fillRect(0,0,W,H);
  ps.forEach(q=>{const u=1-q.l/q.m;if(q.k==='f'){const r=q.c==='b'?[80+u*80,190-u*120,255]:[255,230-u*190,120-u*110];x.fillStyle='rgba('+(r[0]|0)+','+(Math.max(0,r[1])|0)+','+(Math.max(0,r[2])|0)+','+Math.max(0,.75*(1-u))+')';x.beginPath();x.arc(q.x,q.y,q.r*(1-u*.6),0,7);x.fill()}});
  x.globalCompositeOperation='source-over';
  ps.forEach(q=>{if(q.k==='s'){x.fillStyle=q.c;x.globalAlpha=Math.max(0,q.l*1.6);x.fillRect(q.x,q.y,q.r,q.r)}else if(q.k==='g'){x.fillStyle='rgba(180,190,205,'+Math.max(0,q.l/q.m*.45)+')';x.beginPath();x.arc(q.x,q.y,q.r*(1+(1-q.l/q.m)),0,7);x.fill()}});x.globalAlpha=1;
  it.forEach(o=>{x.save();x.translate(o.x+Math.sin(t*3+o.ph)*3,o.y);
   if(o.k==='wood'){x.rotate(o.rot*.3);x.fillStyle='#7a4e2a';x.fillRect(-14,-6,28,12);x.fillStyle='#a8703c';x.beginPath();x.ellipse(14,0,4,6,0,0,7);x.fill();x.fillStyle='#4a2d16';x.fillRect(-8,-6,3,12)}
   else if(o.k==='coal'){x.rotate(o.rot);x.fillStyle='#22222a';x.beginPath();x.moveTo(-10,-4);x.lineTo(-3,-11);x.lineTo(9,-6);x.lineTo(11,5);x.lineTo(0,11);x.lineTo(-10,6);x.fill();x.strokeStyle='#ff6a1a';x.shadowColor='#ff6a1a';x.shadowBlur=10;x.lineWidth=1.5;x.beginPath();x.moveTo(-6,0);x.lineTo(0,-3);x.lineTo(6,2);x.stroke()}
   else if(o.k==='gas'){x.shadowColor='#ffd36b';x.shadowBlur=16;x.fillStyle='#e0344a';x.fillRect(-9,-12,18,24);x.fillStyle='#ffd36b';x.fillRect(-9,-4,18,5);x.fillStyle='#bbb';x.fillRect(-4,-17,8,5)}
   else if(o.k==='water'){x.fillStyle='#4aa8ff';x.shadowColor='#4aa8ff';x.shadowBlur=8;x.beginPath();x.moveTo(0,-14);x.bezierCurveTo(12,2,10,12,0,12);x.bezierCurveTo(-10,12,-12,2,0,-14);x.fill();x.fillStyle='#ffffff88';x.fillRect(-5,0,2,6)}
   else{x.rotate(o.rot);x.fillStyle='#bfefff';x.shadowColor='#bfefff';x.shadowBlur=10;x.beginPath();for(let i=0;i<6;i++){const an=i/6*6.28;x.lineTo(Math.cos(an)*(i%2?7:15),Math.sin(an)*(i%2?7:15))}x.fill()}
   x.restore()});
  if(flash>0){x.fillStyle='rgba(255,220,150,'+flash+')';x.fillRect(0,0,W,H)}x.restore();
  x.fillStyle='#fff';x.font='800 34px sans-serif';x.textAlign='center';x.strokeStyle='#000a';x.lineWidth=4;x.strokeText(sc|0,W/2,48);x.fillText(sc|0,W/2,48);
  x.fillStyle='#000a';x.fillRect(16,64,W-32,8);const fg=x.createLinearGradient(16,0,W-16,0);fg.addColorStop(0,'#e0344a');fg.addColorStop(.5,'#ff9f1a');fg.addColorStop(1,'#ffe14a');x.fillStyle=inf>0?'#6ee7ff':fg;x.fillRect(16,64,(W-32)*Math.min(1,size/2.4),8);
  if(inf>0){x.fillStyle='#6ee7ff';x.font='700 12px sans-serif';x.fillText('جحيم '+inf.toFixed(1)+'ث',W/2,92)}
  if(tipT>0){x.globalAlpha=Math.min(1,tipT);x.fillStyle='#6ee7ff';x.font='800 22px sans-serif';x.fillText(tip,W/2,150);x.globalAlpha=1}x.textAlign='left';
 });
}

function gRoof(b,a){
 const W=640,H=300,Y=232,PX=130,c=CV(b,W,H),x=c.getContext('2d'),R=Math.random;
 let py=Y,vy=0,jm=0,sl=0,sp=270,dist=0,coins=0,t=0,over=0,rf=[{x:-200,w:760}],ob=[],co=[],fx=[],cb=0,cbT=0,shake=0,end=560,wx=0,on=1,flip=0;
 const city=(n,s,h0)=>{const r=[];let q=0;for(let i=0;i<n;i++){const w=30+R()*50;r.push({x:q,w,h:h0+R()*s});q+=w+4}return r},C1=city(30,110,60),C2=city(24,90,40);
 const gen=()=>{while(end<wx+W+400){const gap=60+R()*Math.min(120,sp*.28),w=200+R()*280,x0=end+gap;rf.push({x:x0,w});const r=R();
   if(w>240){if(r<.34)ob.push({k:'crate',x:x0+w*.55,w:34,h:34});else if(r<.62)ob.push({k:'bar',x:x0+w*.5,w:64,h:0});else if(r<.78)ob.push({k:'drone',x:x0+w*.55,w:30,h:0,p:R()*6})}
   if(R()<.7)for(let i=0;i<5;i++){const u=i/4;co.push({x:x0+w*.25+i*34,y:Y-34-Math.sin(u*3.14)*52,g:0})}
   end=x0+w}rf=rf.filter(q=>q.x+q.w>wx-200);ob=ob.filter(q=>q.x>wx-200);co=co.filter(q=>q.x>wx-200)};
 const jump=()=>{if(over)return;if(on||jm<2){if(!on&&jm===0)jm=1;vy=on?-600:-540;on=0;jm++;sl=0;SFX.jump();if(jm===2){flip=.4;for(let i=0;i<8;i++)fx.push({x:PX+wx,y:py-20,vx:(R()-.5)*160,vy:R()*60,l:.4,c:'#3df2ff'})}}};
 const slide=()=>{if(over)return;if(on){sl=.65;SFX.swoosh()}else vy=Math.max(vy,500)};
 KEYS(a,{Space:jump,ArrowUp:jump,KeyW:jump,ArrowDown:slide,KeyS:slide});
 let sy=0;EL(a,c,'pointerdown',e=>{e.preventDefault();sy=e.clientY;jump()});EL(a,c,'pointerup',e=>{if(e.clientY-sy>30)slide()});
 const pad=document.createElement('div');pad.style.cssText='display:flex;gap:10px;margin-top:10px;direction:ltr';
 [[ic('arrowU')+' قفز',jump,2],[ic('arrowD')+' انزلاق',slide,1]].forEach(([lb,fn,f])=>{const e=document.createElement('button');e.className='btn p';e.style.cssText='flex:'+f+';min-height:66px;font-size:18px;touch-action:none;user-select:none';e.innerHTML=lb;pad.appendChild(e);EL(a,e,'pointerdown',v=>{v.preventDefault();fn()})});b.appendChild(pad);
 b.querySelector('#ei').textContent='Space/↑ قفز (مرتين في الهواء) - ↓ انزلاق تحت الحواجز العالية';
 const die=()=>{if(over)return;over=1;SFX.hit();a.t(()=>SFX.die(),120);shake=.35;for(let i=0;i<16;i++)fx.push({x:PX+wx,y:py-20,vx:(R()-.5)*260,vy:-R()*200,l:.7,c:'#ff5a6e'});a.t(()=>a.end((dist/10|0)+coins*5,'سقطت بعد '+(dist/10|0)+' م - العملات '+coins),900)};
 LOOP(a,dt=>{t+=dt;shake=Math.max(0,shake-dt);flip=Math.max(0,flip-dt);cbT=Math.max(0,cbT-dt);if(!cbT)cb=0;
  if(!over){sp=270+Math.min(300,dist/55);wx+=sp*dt;dist+=sp*dt;sl=Math.max(0,sl-dt);gen();
   const pw=wx+PX,roof=rf.some(q=>pw>q.x&&pw<q.x+q.w);vy+=1650*dt;py+=vy*dt;
   if(py>=Y&&vy>=0&&roof&&py<Y+30){if(!on){SFX.land();jm=0;for(let i=0;i<6;i++)fx.push({x:pw,y:Y,vx:-60-R()*100,vy:-R()*60,l:.35,c:'#ffffff88'})}py=Y;vy=0;on=1}else if(py>Y+2)on=0;
   if(py>H+40)die();
   const hh=sl>0?22:44,P={x:pw-9,y:py-hh,w:18,h:hh};
   ob.forEach(o=>{const r=o.k==='crate'?{x:o.x,y:Y-o.h,w:o.w,h:o.h}:o.k==='bar'?{x:o.x,y:Y-58,w:o.w,h:26}:{x:o.x,y:Y-64+Math.sin(t*3+o.p)*8,w:o.w,h:18};if(P.x<r.x+r.w-3&&P.x+P.w>r.x+3&&P.y<r.y+r.h-3&&P.y+P.h>r.y+3)die()});
   co.forEach(q=>{if(!q.g&&Math.hypot(pw-q.x,py-22-q.y)<24){q.g=1;coins++;cb++;cbT=2;SFX.coin();if(cb>0&&cb%5===0)SFX.milestone();for(let i=0;i<6;i++)fx.push({x:q.x,y:q.y,vx:(R()-.5)*120,vy:-R()*100,l:.4,c:'#ffd36b'})}})}
  fx.forEach(f=>{f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=300*dt;f.l-=dt});fx=fx.filter(f=>f.l>0);
  x.save();if(shake>0)x.translate((R()-.5)*8,(R()-.5)*8);
  const sk=x.createLinearGradient(0,0,0,H);sk.addColorStop(0,'#1a0f3c');sk.addColorStop(.6,'#a23c8f');sk.addColorStop(1,'#ff8a5c');x.fillStyle=sk;x.fillRect(-10,-10,W+20,H+20);
  x.fillStyle='#ffe9a8';x.beginPath();x.arc(500,150,28,0,7);x.fill();x.fillStyle='#ffffff55';for(let i=0;i<24;i++)x.fillRect((i*83)%W,(i*37)%110,1.5,1.5);
  const lay=(arr,par,col,y0)=>{const tw=arr[arr.length-1].x+arr[arr.length-1].w+4,off=(wx*par)%tw;x.fillStyle=col;for(let k=-1;k<2;k++)arr.forEach(q=>{const qx=q.x-off+k*tw;if(qx>-90&&qx<W+10)x.fillRect(qx,y0-q.h,q.w,q.h+80)})};
  lay(C1,.12,'#3a1d57',210);lay(C2,.3,'#2a1342',235);
  x.save();x.translate(-wx,0);
  rf.forEach(q=>{if(q.x>wx+W+20||q.x+q.w<wx-20)return;x.fillStyle='#1b1030';x.fillRect(q.x,Y,q.w,H);x.fillStyle='#3a2a63';x.fillRect(q.x,Y,q.w,6);x.fillStyle='#ffd36b44';for(let i=q.x+14;i<q.x+q.w-10;i+=34)for(let j=Y+18;j<H;j+=26)if(((i*7+j*3)|0)%5>1)x.fillRect(i,j,10,12)});
  ob.forEach(o=>{if(o.x>wx+W+20||o.x<wx-80)return;if(o.k==='crate'){x.fillStyle='#8a5a2b';x.fillRect(o.x,Y-o.h,o.w,o.h);x.strokeStyle='#5a3a1b';x.lineWidth=3;x.strokeRect(o.x+2,Y-o.h+2,o.w-4,o.h-4);x.beginPath();x.moveTo(o.x,Y-o.h);x.lineTo(o.x+o.w,Y);x.stroke()}
   else if(o.k==='bar'){x.fillStyle='#aab';x.fillRect(o.x,Y-60,4,60);x.fillRect(o.x+o.w-4,Y-60,4,60);x.fillStyle='#e0344a';x.fillRect(o.x,Y-58,o.w,26);x.fillStyle='#fff';for(let i=0;i<5;i++)x.fillRect(o.x+4+i*13,Y-58,6,26)}
   else{const dy=Y-64+Math.sin(t*3+o.p)*8;x.fillStyle='#2b2b3b';x.fillRect(o.x,dy,o.w,12);x.fillStyle='#ff4d4d';x.shadowColor='#ff4d4d';x.shadowBlur=10;x.fillRect(o.x+11,dy+3,8,6);x.shadowBlur=0;x.fillStyle='#8a8aa5';x.fillRect(o.x-6,dy-4+Math.sin(t*40)*1,42,3)}});
  co.forEach(q=>{if(q.g||q.x>wx+W+20||q.x<wx-30)return;x.fillStyle='#ffd36b';x.shadowColor='#ffd36b';x.shadowBlur=8;x.beginPath();x.ellipse(q.x,q.y,Math.abs(Math.cos(t*4+q.x))*6+1.5,6.5,0,0,7);x.fill();x.shadowBlur=0});
  fx.forEach(f=>{x.globalAlpha=Math.max(0,f.l*2.4);x.fillStyle=f.c;x.fillRect(f.x,f.y,4,4)});x.globalAlpha=1;
  if(!over||py<H){const cx=wx+PX,run=on&&sl<=0,ph=t*sp*.035;x.save();x.translate(cx,py);
   if(sl>0){x.rotate(-.5);x.translate(0,-6)}else if(!on&&jm===2&&flip>0){x.translate(0,-22);x.rotate(-flip/.4*6.28);x.translate(0,22)}
   const lg=run?Math.sin(ph)*9:(on?0:6),ar=run?Math.cos(ph)*8:-5;x.strokeStyle='#3df2ff';x.lineCap='round';x.lineWidth=5;
   x.beginPath();x.moveTo(0,-18);x.lineTo(lg,-2);x.moveTo(0,-18);x.lineTo(-lg,-2);x.stroke();
   x.strokeStyle='#ff4fa3';x.lineWidth=7;x.beginPath();x.moveTo(0,-34);x.lineTo(3,-18);x.stroke();
   x.strokeStyle='#ffd36b';x.lineWidth=4;x.beginPath();x.moveTo(0,-30);x.lineTo(ar+6,-22);x.moveTo(0,-30);x.lineTo(-ar+6,-22);x.stroke();
   x.fillStyle='#f1c59a';x.beginPath();x.arc(4,-42,6,0,7);x.fill();x.fillStyle='#ff4fa3';x.fillRect(-2,-49,12,4);x.fillRect(-12,-46,10,3);x.restore()}
  x.restore();
  if(sp>420){x.strokeStyle='#ffffff30';for(let i=0;i<6;i++){const yy=(i*53+t*400)%H;x.beginPath();x.moveTo(W,yy);x.lineTo(W-60-R()*40,yy);x.stroke()}}
  x.restore();x.fillStyle='#fff';x.font='700 16px sans-serif';x.textAlign='left';x.fillText((dist/10|0)+' م',12,24);x.fillStyle='#ffd36b';x.beginPath();x.arc(100,19,6,0,7);x.fill();x.fillStyle='#fff';x.fillText(coins,112,24);
  if(cb>=3){x.fillStyle='#3df2ff';x.font='800 16px sans-serif';x.fillText('كومبو ×'+cb,W-110,24)}
 });
}

function gStack(b,a){
 const W=360,H=560,BH=26,W0=200,c=CV(b,W,H),x=c.getContext('2d'),R=Math.random;
 let tw=[{x:(W-W0)/2,w:W0,h:200}],cur,n=1,cam=0,db=[],fx=[],cb=0,over=0,shake=0,t=0,pt=0,ptx='',st=0;
 const mkCur=()=>{const l=tw[tw.length-1];cur={x:R()<.5?-l.w:W,w:l.w,h:(l.h+9)%360,d:0,v:150+Math.min(280,n*7)};cur.d=cur.x<0?1:-1};mkCur();
 const sy=i=>H-70-(i+1)*BH+cam;
 const drop=()=>{if(over)return;const l=tw[tw.length-1],ov=Math.min(cur.x+cur.w,l.x+l.w)-Math.max(cur.x,l.x);
  if(ov<=0){over=1;SFX.die();db.push({x:cur.x,w:cur.w,y:sy(n),vy:0,r:0,vr:(R()-.5)*3,h:cur.h});shake=.3;a.t(()=>a.end(n-1,'سقط البرج عند الطابق '+(n-1)),1000);return}
  let nx0=Math.max(cur.x,l.x),nw=ov;
  if(Math.abs(cur.x-l.x)<5){nx0=l.x;nw=l.w;cb++;pt=1;ptx='مثالي'+(cb>1?' ×'+cb:'');fx.push({k:'ring',x:l.x,w:l.w,y:sy(n),l:.5});SFX.score();bell(520*Math.pow(1.0595,Math.min(cb*2,24)),.5,{v:.16});if(cb>=4){nw=Math.min(W0,nw+8);nx0=Math.max(0,nx0-4)}for(let i=0;i<10;i++)fx.push({k:'p',x:nx0+R()*nw,y:sy(n),vx:(R()-.5)*120,vy:-40-R()*90,l:.6,h:cur.h})}
  else{cb=0;SFX.land();const cutL=cur.x<l.x;db.push({x:cutL?cur.x:l.x+l.w,w:cur.w-ov,y:sy(n),vy:0,r:0,vr:(cutL?-1:1)*(.5+R()),h:cur.h})}
  tw.push({x:nx0,w:nw,h:cur.h});n++;if(n%10===0)SFX.milestone();mkCur();shake=.08};
 KEYS(a,{Space:drop,Enter:drop,ArrowDown:drop});EL(a,c,'pointerdown',e=>{e.preventDefault();drop()});BTN(a,b,'اسقط الطابق',drop);
 b.querySelector('#ei').textContent='اضغط في اللحظة المناسبة - المحاذاة المثالية تعيد توسيع البرج';
 LOOP(a,dt=>{t+=dt;shake=Math.max(0,shake-dt);pt=Math.max(0,pt-dt);
  if(!over){cur.x+=cur.d*cur.v*dt;if(cur.x+cur.w>W+30){cur.d=-1}if(cur.x<-30){cur.d=1}}
  const ct=Math.max(0,(n-5)*BH);cam+=(ct-cam)*Math.min(1,4*dt);
  db.forEach(d=>{d.vy+=1400*dt;d.y+=d.vy*dt;d.r+=d.vr*dt});db=db.filter(d=>d.y<H+120);
  fx.forEach(f=>{f.l-=dt;if(f.k==='p'){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=300*dt}});fx=fx.filter(f=>f.l>0);
  const u=Math.min(1,n/70),sky=[[110,198,255],[255,150,110],[24,18,64],[5,4,20]],q=u*3,i0=Math.min(2,q|0),f=q-i0,mix=(p,o)=>p.map((v,k)=>(v+(o[k]-v)*f)|0),top=mix(sky[i0],sky[i0+1]),bot=mix(sky[Math.max(0,i0)],sky[i0+1]).map(v=>Math.min(255,v+30));
  x.save();if(shake>0)x.translate((R()-.5)*7,(R()-.5)*7);
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgb('+top+')');g.addColorStop(1,'rgb('+bot+')');x.fillStyle=g;x.fillRect(-10,-10,W+20,H+20);
  if(u>.35){x.fillStyle='rgba(255,255,255,'+Math.min(.9,(u-.35)*2)+')';for(let k=0;k<40;k++)x.fillRect((k*97)%W,(k*61+cam*.2)%H,1.5,1.5)}
  x.fillStyle='#00000030';x.fillRect(0,H-70+BH*0+0,W,80);
  const blk=(bx,by,bw,h,al)=>{x.globalAlpha=al==null?1:al;const gr=x.createLinearGradient(0,by,0,by+BH);gr.addColorStop(0,'hsl('+h+',85%,62%)');gr.addColorStop(1,'hsl('+h+',80%,45%)');x.fillStyle=gr;x.fillRect(bx,by,bw,BH-1);x.fillStyle='rgba(255,255,255,.35)';x.fillRect(bx,by,bw,3);x.fillStyle='rgba(0,0,0,.18)';x.fillRect(bx,by+BH-4,bw,3);x.globalAlpha=1};
  tw.forEach((k,i)=>{const yy=sy(i);if(yy>-BH&&yy<H+BH)blk(k.x,yy,k.w,k.h)});
  if(cb>=2&&!over){const l=tw[tw.length-1];x.shadowColor='hsl('+l.h+',90%,60%)';x.shadowBlur=18+cb*2;blk(l.x,sy(n-1),l.w,l.h);x.shadowBlur=0}
  if(!over)blk(cur.x,sy(n),cur.w,cur.h);
  db.forEach(d=>{x.save();x.translate(d.x+d.w/2,d.y+BH/2);x.rotate(d.r);x.translate(-d.w/2,-BH/2);blk(0,0,d.w,d.h,.9);x.restore()});
  fx.forEach(f=>{if(f.k==='ring'){x.strokeStyle='rgba(255,255,255,'+f.l*2+')';x.lineWidth=3;const e=(.5-f.l)*30;x.strokeRect(f.x-e,f.y-e/2,f.w+e*2,BH+e)}else{x.fillStyle='hsla('+f.h+',90%,70%,'+f.l*1.6+')';x.fillRect(f.x,f.y,4,4)}});
  x.restore();
  x.fillStyle='#fff';x.font='800 54px sans-serif';x.textAlign='center';x.strokeStyle='#0008';x.lineWidth=5;x.strokeText(n-1,W/2,80);x.fillText(n-1,W/2,80);
  if(pt>0){x.globalAlpha=Math.min(1,pt*2);x.fillStyle='#ffe14a';x.font='800 24px sans-serif';x.strokeText(ptx,W/2,120-(1-pt)*14);x.fillText(ptx,W/2,120-(1-pt)*14);x.globalAlpha=1}x.textAlign='left';
 });
}

Object.assign(ICON,{
skull:'<path d="M12 3a7 7 0 00-7 7c0 2.5 1.2 4 3 5v3h8v-3c1.8-1 3-2.5 3-5a7 7 0 00-7-7z"/><circle cx="9" cy="11" r="1.4"/><circle cx="15" cy="11" r="1.4"/><path d="M10 18v2M14 18v2"/>',
dino:'<path d="M4 20h4l1-5h3l1 5h4v-6l3-1V9h-5V6h-6v5l-3 2z"/><circle cx="15" cy="8" r=".7"/>',
snake:'<path d="M18 5c-3-2-8-1-8 2s6 2 6 6-6 5-10 3"/><circle cx="18" cy="5.5" r="1"/>',
bird:'<path d="M3 13c3-5 9-6 14-3l4 1-4 1c-1 4-5 7-10 6z"/><circle cx="15" cy="10" r=".8"/><path d="M8 14c2 0 3 1 4 2"/>',
sword:'<path d="M14 4l6-1-1 6-9 9-3-3z"/><path d="M5 15l4 4M4 20l3-3"/>',
runner:'<circle cx="14" cy="5" r="2"/><path d="M8 21l3-6 3 2 2 4M11 15l-1-5 4-2 3 3M10 9l-3 2"/>',
store:'<path d="M4 9l1-5h14l1 5M4 9a2.5 2.5 0 005 0 2.5 2.5 0 005 0 2.5 2.5 0 005 0M5 12v8h14v-8M10 20v-5h4v5"/>',
tower:'<path d="M6 21V9l2-1V4h2v2h4V4h2v4l2 1v12zM10 21v-5h4v5"/>',
tree:'<path d="M12 3l5 7h-3l4 6H6l4-6H7z"/><path d="M12 16v5"/>',
door:'<path d="M5 21V10a7 7 0 0114 0v11zM12 21v-8"/><circle cx="12" cy="11" r="1"/>',
kart:'<path d="M3 15l2-5h9l3 3h3v3H3z"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>',
golf:'<path d="M8 20V4l9 4-9 4"/><circle cx="15" cy="19" r="1.5"/>',
palm:'<path d="M12 21V11M12 11c-2-4-6-4-8-3 3 0 5 1 8 3zM12 11c2-4 6-4 8-3-3 0-5 1-8 3zM12 11c-1-3-1-5 0-7 1 2 1 4 0 7z"/>',
key:'<circle cx="8" cy="12" r="4"/><path d="M12 12h9M18 12v3M21 12v2"/>',
shield:'<path d="M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6z"/><path d="M10 10a2 2 0 114 0c0 1.5-2 1.5-2 3M12 16v.5"/>',
keyboard:'<rect x="3" y="7" width="18" height="11" rx="2"/><path d="M7 11h.5M11 11h.5M15 11h.5M7 15h10"/>',
note:'<path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="16" r="2"/>',
link:'<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',
truth:'<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
flame:'<path d="M12 3c1 4 5 6 5 11a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-4-1-6 1-10z"/>',
roof:'<path d="M3 21V12h5V9h5v6h3v-4h5v10zM6 15h.5M11 12h.5M16 15h.5"/>',
stack:'<rect x="5" y="16" width="14" height="4" rx="1"/><rect x="7" y="11" width="11" height="4" rx="1"/><rect x="9" y="6" width="8" height="4" rx="1"/>',
arrowL:'<path d="M15 5l-7 7 7 7"/>',arrowR:'<path d="M9 5l7 7-7 7"/>',arrowU:'<path d="M5 15l7-7 7 7"/>',arrowD:'<path d="M5 9l7 7 7-7"/>',
dash:'<path d="M4 8h10M2 12h12M4 16h10M17 7l5 5-5 5"/>',
box:'<path d="M4 8l8-4 8 4v9l-8 4-8-4zM4 8l8 4 8-4M12 12v9"/>',
broom:'<path d="M14 3l-4 9M7 12h8l2 8H5z"/>',
sparkle:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',
shelf:'<path d="M4 6h16M4 13h16M4 20h16M7 6V3M17 13v-3M10 20v-3"/>'});
Object.assign(ICOLOR,{skull:'#9be564',dino:'#f4a259',snake:'#2ecc71',bird:'#ffd23f',sword:'#ff5a6e',runner:'#3df2ff',store:'#ffd36b',tower:'#a66cff',tree:'#3cb371',door:'#c08457',kart:'#ff7849',golf:'#7bd957',palm:'#2bd9a8',key:'#f5c542',shield:'#4aa8ff',keyboard:'#9aa7ff',note:'#ff79c6',link:'#6ee7ff',truth:'#7ee787',flame:'#ff6a1a',roof:'#ff4fa3',stack:'#b46bff',memory:'#e87bd2',number:'#5ee0ff',odd:'#ffd23f',match:'#ff9f43',quiz:'#4aa8ff',math:'#7bd957',tap:'#ff5a6e',react:'#3dd6c6',whack:'#c77dff',typing:'#8ab4ff',guess:'#ffb703',rps:'#ef476f',dice:'#ffd166',xo:'#06d6a0',c4:'#3ea6ff',forbid:'#ff4d6d',sab:'#ff9e00',score:'#a66cff',majd:'#f5c542',carrom:'#e07a5f',detect:'#8ecae6',trivia:'#ffb27a',crown:'#ffd700',list:'#9bf6ff',eye:'#bdb2ff',person:'#ffc6ff',diff:'#9ef0b0',shuffle:'#e9f08a',moon:'#a0c4ff',tag:'#ff9aa2',spy:'#b4bcc6',theater:'#f4a6d7',mask:'#cdb4db',phone:'#90dbf4',brain:'#ff8fab',users:'#7bdff2',box:'#d4a373',broom:'#9bf6ff',sparkle:'#fff3a0',shelf:'#c8a27a'});
G.push({id:'flame',n:'الشعلة',i:'flame',c:'ملحمي',p:'1',l:'متوسط',d:'شعلة حيّة: جمّع الحطب والفحم وابعد عن الموية والبَرَد، وولّع وضع الجحيم.',run:gFlame,r:'اسحب بإصبعك أو استخدم الأسهم. الحطب يكبّر الشعلة، الماء يطفئها، وعلبة الوقود تفعّل الجحيم الأزرق الذي يحرق كل ما يسقط.'},{id:'roofrun',n:'الأسطح',i:'roof',c:'ملحمي',p:'1',l:'صعب',d:'باركور بدون نهاية فوق أسطح المدينة: نطّة مزدوجة وانزلاق وكومبو عملات.',run:gRoof,r:'اضغط للقفز (مرتين في الهواء)، واسحب لأسفل أو زر الانزلاق لتمر تحت الحواجز العالية.'},{id:'stack',n:'البرج',i:'stack',c:'سرعة',p:'1',l:'متوسط',d:'اضغط في اللحظة المضبوطة عشان تبني برج أعلى، والمحاذاة الكاملة توسّع البرج.',run:gStack,r:'اضغط لإسقاط الطابق المتحرك. كل جزء زائد يُقص. أربع محاذاات مثالية متتالية تُرجع عرض الطابق.'});
(()=>{const GI={zombie:'skull',dino:'dino',snake:'snake',flappy:'bird',bossrush:'sword',parkour:'runner',tycoon:'store',towerdef:'tower',survival:'tree',dungeon:'door',kart:'kart',golf:'golf',oasis:'palm',escape:'key',tbattle:'shield',typearena:'keyboard',rhythm:'note',wordchain:'link',truth:'truth'};for(let i=G.length;i--;)if(G[i].id==='categories2')G.splice(i,1);G.forEach(g=>{if(GI[g.id])g.i=GI[g.id]})})();
/* ===== V5 upgrade layer ===== */
(()=>{
const st=document.createElement('style');st.textContent=`
.ci{width:100%;height:100%;overflow:visible}.ci *{transform-box:fill-box}
@keyframes cFlap{from{transform:rotate(-28deg)}to{transform:rotate(22deg)}}@keyframes cBob{50%{transform:translateY(-3px)}}
@keyframes cPulse{50%{opacity:.35}}@keyframes cSway{50%{transform:rotate(7deg)}}@keyframes cShake{25%{transform:translateX(-1.5px)}75%{transform:translateX(1.5px)}}
@keyframes cFlick{50%{transform:scale(1.25,.8)}}@keyframes cHop{50%{transform:translateY(-6px)}}@keyframes cWave{50%{transform:skewY(10deg)}}
.gi .ci{width:42px!important;height:42px!important}.gi.big .ci{width:84px!important;height:84px!important;display:block;margin:auto}.studio-tag{margin-top:14px;text-align:center;font-size:10px;letter-spacing:2px;color:var(--mu);opacity:.7}
.td-info{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-top:8px}.td-info b{color:var(--p2)}`;
document.head.appendChild(st);
const S_=(v,i)=>`<svg class="ci" viewBox="0 0 48 48" aria-hidden="true">${i}</svg>`;
window.CICON={
bird:()=>S_(0,`<circle cx="24" cy="26" r="19" fill="#3df2ff" opacity=".14" style="animation:cPulse 2s infinite"/><g style="animation:cBob 1s infinite"><ellipse cx="22" cy="26" rx="14" ry="11" fill="#ffd23f"/><path d="M34 25l10 3-10 4z" fill="#ff7a1a"/><circle cx="29" cy="22" r="4" fill="#fff"/><circle cx="30" cy="22" r="2" fill="#222"/><path d="M10 28q-5 2-6 8 8-1 10-6z" fill="#ff7a1a"/><path d="M14 27q8-12 14 0q-7 7-14 0z" fill="#ff9a3c" style="transform-origin:14px 27px;animation:cFlap .35s infinite alternate"/></g>`),
dino:()=>S_(0,`<g style="animation:cHop .7s infinite"><path d="M6 36q-2-12 8-14l4-12h14q6 0 6 6v4h-8l2 4q0 12-8 14z" fill="#3ddc84"/><path d="M14 17l-3-4 4 1zM20 14l-1-5 4 3z" fill="#1fa75a"/><circle cx="34" cy="16" r="2.4" fill="#fff"/><circle cx="35" cy="16" r="1.2" fill="#111"/><path d="M26 33v9h4v-3h4v-6zM12 36v6h4v-6z" fill="#1fa75a"/><path d="M36 23h-6" stroke="#0b5a30" stroke-width="2"/></g>`),
tower:()=>S_(0,`<rect x="10" y="20" width="28" height="22" rx="2" fill="#7aa2ff"/><path d="M8 20v-8h6v4h4v-4h4v4h4v-4h4v4h4v-4h6v8z" fill="#9db9ff"/><path d="M20 42v-9q4-6 8 0v9z" fill="#27325c"/><rect x="14" y="25" width="4" height="6" rx="2" fill="#ffd23f" style="animation:cPulse 1.4s infinite"/><rect x="30" y="25" width="4" height="6" rx="2" fill="#ffd23f" style="animation:cPulse 1.4s .4s infinite"/><path d="M24 12V2" stroke="#ddd" stroke-width="2"/><path d="M24 2h12l-4 4 4 4H24z" fill="#ff3b5c" style="transform-origin:24px 6px;animation:cWave 1s infinite"/>`),
kart:()=>S_(0,`<g style="animation:cShake .22s infinite"><rect x="9" y="10" width="30" height="30" rx="9" fill="#ff3b5c"/><rect x="14" y="16" width="20" height="9" rx="3" fill="#3df2ff"/><rect x="21" y="8" width="6" height="32" fill="#fff" opacity=".85"/><rect x="5" y="14" width="6" height="9" rx="2" fill="#222"/><rect x="37" y="14" width="6" height="9" rx="2" fill="#222"/><rect x="5" y="30" width="6" height="9" rx="2" fill="#222"/><rect x="37" y="30" width="6" height="9" rx="2" fill="#222"/><circle cx="14" cy="11" r="2" fill="#ffe08a"/><circle cx="34" cy="11" r="2" fill="#ffe08a"/></g><path d="M12 44h8M28 44h8" stroke="#fff" stroke-width="2" opacity=".4" stroke-linecap="round" style="animation:cPulse .5s infinite"/>`),
skull:()=>S_(0,`<g style="animation:cBob 1.2s infinite"><path d="M7 22q0-16 17-16t17 16v10q0 8-7 10H14q-7-2-7-10z" fill="#7bd36b"/><path d="M12 12q4-5 10-3-2 4-5 5zM36 14l-6-2 2-4z" fill="#4c9f46"/><circle cx="17" cy="23" r="5" fill="#1b1b1b"/><circle cx="31" cy="23" r="5" fill="#1b1b1b"/><circle cx="17" cy="23" r="2.4" fill="#ff3b3b" style="animation:cPulse 1s infinite"/><circle cx="31" cy="23" r="2.4" fill="#ff3b3b" style="animation:cPulse 1s .3s infinite"/><path d="M13 35h22" stroke="#244d20" stroke-width="2.5"/><path d="M17 33v5M22 33v5M27 33v5M32 33v5" stroke="#244d20" stroke-width="2"/></g>`),
golf:()=>S_(0,`<ellipse cx="24" cy="40" rx="20" ry="6" fill="#2ecc71"/><path d="M30 38V8" stroke="#eee" stroke-width="2"/><path d="M30 8l12 5-12 5z" fill="#ff3b5c" style="transform-origin:30px 13px;animation:cWave .8s infinite"/><circle cx="30" cy="38" r="2.6" fill="#111"/><g style="animation:cHop .9s infinite"><circle cx="13" cy="33" r="6" fill="#fff"/><circle cx="11" cy="31" r="1" fill="#bbb"/><circle cx="15" cy="34" r="1" fill="#bbb"/></g>`),
palm:()=>S_(0,`<circle cx="36" cy="11" r="6" fill="#ffd23f" style="animation:cPulse 2.4s infinite"/><path d="M0 40q12-6 24 0t24 0v8H0z" fill="#1ea0ff"/><ellipse cx="22" cy="40" rx="14" ry="4" fill="#f5d58a"/><path d="M22 38q-2-14 3-24" stroke="#8a5a2b" stroke-width="4" fill="none" stroke-linecap="round"/><g style="transform-origin:25px 14px;animation:cSway 2s infinite"><path d="M25 14q-14-8-20 2q10-2 20-2zM25 14q14-8 20 2q-10-2-20-2zM25 14q-6-12-14-12q8 4 14 12zM25 14q6-12 14-12q-8 4-14 12z" fill="#2ecc71"/></g>`),
door:()=>S_(0,`<path d="M6 44V20q0-14 18-14t18 14v24z" fill="#59536e"/><path d="M12 44V22q0-10 12-10t12 10v22z" fill="#1b1530"/><path d="M12 24h24M12 32h24" stroke="#2c2447" stroke-width="2"/><g style="transform-origin:24px 34px;animation:cFlick .3s infinite"><path d="M24 40q-7-6-2-14q1 5 4 4q1-4-1-8q9 8 5 16q-3 3-6 2z" fill="#ff9a3c"/><path d="M24 40q-3-3-1-7q2 2 3 0q2 4-2 7z" fill="#ffe08a"/></g>`),
tree:()=>S_(0,`<rect x="21" y="36" width="6" height="9" fill="#8a5a2b"/><g style="transform-origin:24px 40px;animation:cSway 2.6s infinite"><path d="M24 4l11 15h-6l9 12H11l9-12h-6z" fill="#2ecc71"/><path d="M24 4l-11 15h6l-9 12h13z" fill="#1fa75a"/></g><circle cx="35" cy="12" r="2.4" fill="#fff" style="animation:cPulse 1.5s infinite"/><circle cx="12" cy="24" r="1.8" fill="#fff" style="animation:cPulse 1.2s .5s infinite"/>`),
drift:()=>S_(0,`<g style="transform-origin:24px 26px;transform:rotate(-24deg);animation:cShake .2s infinite"><rect x="14" y="8" width="20" height="34" rx="8" fill="#ffb020"/><rect x="17" y="15" width="14" height="8" rx="3" fill="#222"/><rect x="22" y="8" width="4" height="34" fill="#111" opacity=".5"/></g><circle cx="8" cy="40" r="4" fill="#fff" opacity=".5" style="animation:cPulse .6s infinite"/><circle cx="3" cy="44" r="3" fill="#fff" opacity=".35" style="animation:cPulse .6s .2s infinite"/>`)};
const _ic=window.ic;
/* ---- shared helpers ---- */
const sf=n=>{try{(SFX[n]||SFX.tap)()}catch(e){}};
const pop=(fx,x,y,n,c,sp=160,l=.6)=>{for(let i=0;i<n;i++){const an=Math.random()*6.283,v=sp*(.3+Math.random());fx.push({x,y,vx:Math.cos(an)*v,vy:Math.sin(an)*v,l:l*(.5+Math.random()),m:l,c,s:2+Math.random()*3})}};
const stepFx=(fx,dt)=>{for(let i=fx.length;i--;){const p=fx[i];p.l-=dt;if(p.l<=0){fx.splice(i,1);continue}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=260*dt}};
const drawFx=(x,fx)=>{fx.forEach(p=>{x.globalAlpha=Math.max(0,p.l/p.m);x.fillStyle=p.c;x.beginPath();x.arc(p.x,p.y,p.s,0,6.283);x.fill()});x.globalAlpha=1};
const rr=(x,a,b,w,h,r)=>{x.beginPath();x.moveTo(a+r,b);x.arcTo(a+w,b,a+w,b+h,r);x.arcTo(a+w,b+h,a,b+h,r);x.arcTo(a,b+h,a,b,r);x.arcTo(a,b,a+w,b,r);x.closePath()};
/* ---- Flappy: tap anywhere ---- */
function gFlap2(b,a){
 const W=360,H=540,c=CV(b,W,H),x=c.getContext('2d');let by=H/2,vy=0,t=0,sc=0,pipes=[],nx=1,fx=[],dead=0,go=0,shake=0,cl=[[40,80,1],[220,140,.7],[300,50,1.2]];
 const flap=()=>{if(dead)return;go=1;vy=-430;sf('jump');pop(fx,80,by+10,5,'#fff6c8',90,.4)};
 EL(a,b,'pointerdown',e=>{if(e.target.closest('button'))return;e.preventDefault();flap()});KEYS(a,{Space:flap,ArrowUp:flap,KeyW:flap});
 b.querySelector('#ei').textContent='المس الشاشة في أي مكان للتحليق';
 LOOP(a,dt=>{t+=dt;shake=Math.max(0,shake-dt);
  if(go&&!dead){vy+=1500*dt;by+=vy*dt;nx-=dt;if(nx<=0){pipes.push({x:W+30,g:150+Math.random()*30,y:120+Math.random()*(H-340),p:0});nx=1.55}
   pipes.forEach(p=>{p.x-=150*dt;if(!p.p&&p.x+26<70){p.p=1;sc++;sf('tick');pop(fx,70,p.y+p.g/2,8,'#ffd23f',120,.5)}});pipes=pipes.filter(p=>p.x>-70);
   const hit=by>H-60||by<-10||pipes.some(p=>70+13>p.x&&70-13<p.x+52&&(by-11<p.y||by+11>p.y+p.g));
   if(hit){dead=1;shake=.4;sf('die');pop(fx,80,by,26,'#ffd23f',260,.9);pop(fx,80,by,10,'#ff7a1a',200,.7);a.t(()=>a.end(sc,'تحطّم الطائر! مررت '+sc+' أنبوب'),800)}}
  else if(!go)by=H/2+Math.sin(t*5)*8;
  stepFx(fx,dt);
  x.save();if(shake>0)x.translate((Math.random()-.5)*10,(Math.random()-.5)*10);
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#3a1c71');g.addColorStop(.55,'#d76d77');g.addColorStop(1,'#ffaf7b');x.fillStyle=g;x.fillRect(-10,-10,W+20,H+20);
  cl.forEach(q=>{q[0]=(q[0]-q[2]*20*dt+500)%460-60;x.fillStyle='#ffffff30';x.beginPath();x.ellipse(q[0],q[1],38*q[2],14*q[2],0,0,6.283);x.fill()});
  pipes.forEach(p=>{const pg=x.createLinearGradient(p.x,0,p.x+52,0);pg.addColorStop(0,'#1fa75a');pg.addColorStop(.5,'#7dff9a');pg.addColorStop(1,'#128a47');x.fillStyle=pg;x.fillRect(p.x+4,0,44,p.y-16);x.fillRect(p.x+4,p.y+p.g+16,44,H);rr(x,p.x,p.y-26,52,26,6);x.fill();rr(x,p.x,p.y+p.g,52,26,6);x.fill()});
  x.fillStyle='#5b3a1e';x.fillRect(0,H-50,W,50);x.fillStyle='#2ecc71';x.fillRect(0,H-50,W,10);x.fillStyle='#00000025';for(let i=0;i<9;i++)x.fillRect(((i*48-t*150)%(W+48)+W+48)%(W+48)-24,H-30,24,6);
  if(!dead||shake>0&&0||!dead){x.save();x.translate(80,by);x.rotate(Math.max(-.5,Math.min(1.1,vy/550)));x.fillStyle='#ffd23f';x.beginPath();x.ellipse(0,0,17,13,0,0,6.283);x.fill();x.fillStyle='#ff7a1a';x.beginPath();x.moveTo(14,0);x.lineTo(26,4);x.lineTo(14,8);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(8,-5,5,0,6.283);x.fill();x.fillStyle='#222';x.beginPath();x.arc(9.5,-5,2.4,0,6.283);x.fill();x.fillStyle='#ff9a3c';x.save();x.translate(-4,2);x.rotate(Math.sin(t*(go?30:12))*.7);x.beginPath();x.ellipse(-4,0,11,6,0,0,6.283);x.fill();x.restore();x.restore()}
  drawFx(x,fx);x.fillStyle='#fff';x.font='900 46px system-ui';x.textAlign='center';x.strokeStyle='#0006';x.lineWidth=5;x.strokeText(sc,W/2,70);x.fillText(sc,W/2,70);
  if(!go){x.font='700 16px system-ui';x.fillText('المس للبدء',W/2,H/2+60)}x.restore()})}
/* ---- Tower defense with upgrades ---- */
function gTD2(b,a){
 const W=360,H=520,c=CV(b,W,H),x=c.getContext('2d');
 const P=[[-20,90],[260,90],[260,210],[90,210],[90,330],[270,330],[270,450],[326,450]];const seg=[];let tot=0;for(let i=1;i<P.length;i++){const l=Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);seg.push(l);tot+=l}
 const at=d=>{let i=0;while(i<seg.length-1&&d>seg[i]){d-=seg[i];i++}const k=Math.min(1,d/seg[i]);return[P[i][0]+(P[i+1][0]-P[i][0])*k,P[i][1]+(P[i+1][1]-P[i][1])*k]};
 const sl=[[170,150],[322,150],[180,270],[34,270],[180,390],[330,390]].map(p=>({x:p[0],y:p[1],lv:0,cd:0,an:0}));
 const COL=['#556','#7aa2ff','#3df2ff','#7dff6b','#ffd23f','#ff7a1a','#ff3b5c'];
 let hp=10,gold=90,wave=0,kills=0,en=[],pr=[],fx=[],spawn=0,left=0,wt=0,sel=-1,shake=0,over=0;
 b.insertAdjacentHTML('beforeend','<button class="btn p" id="nw" style="width:100%;margin-top:8px;min-height:54px">ابدأ الموجة التالية</button>');
 const info=b.querySelector('#ei'),nw=b.querySelector('#nw');
 const cost=s=>s.lv?30+s.lv*30:40;const txt=()=>{const s=sel>=0?sl[sel]:null;info.innerHTML=`قلعة <b>${hp}</b> · موجة <b>${wave}</b> · ذهب <b>${gold|0}</b> · هزائم <b>${kills}</b>`+(s?`<br>${s.lv?(s.lv>=6?'برج مطوّر للأقصى':'طوّر البرج إلى مستوى '+(s.lv+1)+' بـ '+cost(s)+' ذهب'):'ابنِ برجًا بـ 40 ذهب'} - اضغط مرة ثانية للتأكيد`:'<br>اضغط على دائرة لبناء برج أو ترقيته')};txt();
 EL(a,nw,'click',()=>{if(left||en.length||over)return;wave++;left=5+wave*2;spawn=0;sf('milestone');txt()});
 EL(a,c,'pointerdown',e=>{e.preventDefault();const r=c.getBoundingClientRect(),px=(e.clientX-r.left)*W/r.width,py=(e.clientY-r.top)*H/r.height;const i=sl.findIndex(s=>Math.hypot(s.x-px,s.y-py)<30);if(i<0){sel=-1;txt();return}
  if(sel!==i){sel=i;sf('tap');txt();return}const s=sl[i];if(s.lv>=6||gold<cost(s)){sf('bad');return}gold-=cost(s);s.lv++;s.an=.4;sf('ok');pop(fx,s.x,s.y,18,COL[s.lv],170,.7);txt()});
 LOOP(a,dt=>{wt+=dt;shake=Math.max(0,shake-dt);
  if(!over){if(left>0){spawn-=dt;if(spawn<=0){const m=18+wave*16;en.push({d:0,hp:m,m,v:48+wave*3,w:0});left--;spawn=.85}}
   en.forEach(e=>{e.d+=e.v*dt;e.w+=dt*8;if(e.d>=tot){e.dead=1;hp--;shake=.35;sf('die');pop(fx,326,450,16,'#ff3b5c',200,.7);txt();if(hp<=0&&!over){over=1;a.t(()=>a.end(kills*3+wave*20,'سقطت القلعة بعد '+wave+' موجة'),900)}}});
   sl.forEach(s=>{s.an=Math.max(0,s.an-dt);if(!s.lv)return;s.cd-=dt;const R=70+s.lv*10;let tg=null,bd=-1;en.forEach(e=>{if(e.dead)return;const p=at(e.d);if(Math.hypot(p[0]-s.x,p[1]-s.y)<R&&e.d>bd){bd=e.d;tg=e}});if(tg){const p=at(tg.d);s.ang=Math.atan2(p[1]-s.y,p[0]-s.x);if(s.cd<=0){s.cd=Math.max(.25,.95-s.lv*.11);pr.push({x:s.x,y:s.y,t:tg,dm:10+s.lv*9,c:COL[s.lv]});pop(fx,s.x+Math.cos(s.ang)*16,s.y+Math.sin(s.ang)*16,3,COL[s.lv],80,.25)}}});
   pr.forEach(q=>{if(q.t.dead){q.x=-99;return}const p=at(q.t.d),dx=p[0]-q.x,dy=p[1]-q.y,l=Math.hypot(dx,dy);if(l<10){q.t.hp-=q.dm;q.x=-99;pop(fx,p[0],p[1],5,q.c,110,.3);if(q.t.hp<=0&&!q.t.dead){q.t.dead=1;kills++;gold+=7+wave;sf('pop');pop(fx,p[0],p[1],16,'#ff7b7b',190,.6);txt()}}else{q.x+=dx/l*430*dt;q.y+=dy/l*430*dt}});
   pr=pr.filter(q=>q.x>-50);en=en.filter(e=>!e.dead)}
  stepFx(fx,dt);
  x.save();if(shake>0)x.translate((Math.random()-.5)*8,(Math.random()-.5)*8);
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#0e2a1c');g.addColorStop(1,'#071a2e');x.fillStyle=g;x.fillRect(-10,-10,W+20,H+20);
  x.lineCap='round';x.lineJoin='round';x.strokeStyle='#6b4f2a';x.lineWidth=40;x.beginPath();P.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.stroke();x.strokeStyle='#a07a42';x.lineWidth=30;x.stroke();
  x.fillStyle='#8a8fa8';rr(x,296,424,50,56,6);x.fill();x.fillStyle='#ff3b5c';x.fillRect(318,408,4,20);x.fillRect(318,408,16,8);x.fillStyle='#fff';x.font='700 11px system-ui';x.textAlign='center';x.fillText(hp,321,458);
  sl.forEach((s,i)=>{x.save();x.translate(s.x,s.y);const k=1+s.an;x.scale(k,k);if(i===sel){x.strokeStyle='#fff';x.lineWidth=2;x.setLineDash([5,4]);x.beginPath();x.arc(0,0,70+s.lv*10,0,6.283);x.stroke();x.setLineDash([])}
   x.fillStyle=s.lv?'#2a2f4a':'#ffffff18';x.beginPath();x.arc(0,0,22,0,6.283);x.fill();x.strokeStyle=COL[s.lv];x.lineWidth=3;x.stroke();
   if(s.lv){x.shadowColor=COL[s.lv];x.shadowBlur=14;x.rotate(s.ang||0);x.fillStyle=COL[s.lv];x.fillRect(0,-5,24,10);x.beginPath();x.arc(0,0,11,0,6.283);x.fill();x.shadowBlur=0;x.rotate(-(s.ang||0));for(let k2=0;k2<s.lv;k2++){x.fillStyle='#fff';x.fillRect(-15+k2*5.5,26,4,4)}}else{x.fillStyle='#fff';x.font='700 22px system-ui';x.fillText('+',0,8)}x.restore()});
  en.forEach(e=>{const p=at(e.d);x.save();x.translate(p[0],p[1]+Math.sin(e.w)*2);x.fillStyle='#e0344a';x.beginPath();x.arc(0,0,11,0,6.283);x.fill();x.fillStyle='#fff';x.fillRect(-6,-4,4,5);x.fillRect(2,-4,4,5);x.fillStyle='#000';x.fillRect(-4,-3,2,3);x.fillRect(4,-3,2,3);x.fillStyle='#0008';x.fillRect(-12,-19,24,4);x.fillStyle='#7dff6b';x.fillRect(-12,-19,24*e.hp/e.m,4);x.restore()});
  pr.forEach(q=>{x.fillStyle=q.c;x.shadowColor=q.c;x.shadowBlur=8;x.beginPath();x.arc(q.x,q.y,4,0,6.283);x.fill();x.shadowBlur=0});drawFx(x,fx);x.restore();
  nw.disabled=!!(left||en.length||over);nw.style.opacity=nw.disabled?.45:1})}
/* ---- Drift racer ---- */
function gDrift(b,a){
 const W=360,H=560,L=44,R=316,c=CV(b,W,H),x=c.getContext('2d');let cx=180,vx=0,sp=260,t=0,sc=0,tr=[],nx=.6,fx=[],sk=[],dead=0,shake=0,inp=0,dr=0,off=0;
 const set=v=>{inp=v};EL(a,b,'pointerdown',e=>{if(e.target.closest('button'))return;e.preventDefault();const r=c.getBoundingClientRect();set((e.clientX-r.left)<r.width/2?-1:1)});EL(a,document,'pointerup',()=>set(0));EL(a,document,'pointercancel',()=>set(0));
 KEYS(a,{ArrowLeft:()=>set(-1),ArrowRight:()=>set(1),KeyA:()=>set(-1),KeyD:()=>set(1)});EL(a,document,'keyup',()=>set(0));
 b.querySelector('#ei').textContent='المس يمين أو يسار الشاشة للتفحيط وتجنّب السيارات';
 const car=(px,py,ang,col,hl)=>{x.save();x.translate(px,py);x.rotate(ang);x.fillStyle='#000';x.globalAlpha=.3;rr(x,-17,-22,38,56,10);x.fill();x.globalAlpha=1;x.fillStyle='#111';x.fillRect(-21,-18,6,14);x.fillRect(15,-18,6,14);x.fillRect(-21,12,6,14);x.fillRect(15,12,6,14);x.fillStyle=col;rr(x,-17,-28,34,56,10);x.fill();x.fillStyle='#bff6ff';rr(x,-12,-12,24,14,4);x.fill();x.fillStyle='#0003';x.fillRect(-12,8,24,10);if(hl){x.fillStyle='#fff8c8';x.fillRect(-14,-28,8,4);x.fillRect(6,-28,8,4)}x.restore()};
 LOOP(a,dt=>{t+=dt;shake=Math.max(0,shake-dt);
  if(!dead){sp=Math.min(560,sp+dt*8);vx+=inp*1500*dt;vx*=Math.pow(.05,dt);cx+=vx*dt;if(cx<L+20||cx>R-20){cx=Math.max(L+20,Math.min(R-20,cx));vx*=-.5;shake=.25;sf('land');pop(fx,cx,500,10,'#ffd23f',200,.4)}
   dr=Math.abs(vx)>150;sc+=dt*sp/12+(dr?dt*14:0);off=(off+sp*dt)%60;
   if(dr){sk.push({x:cx-14,y:512,l:2.2});sk.push({x:cx+14,y:512,l:2.2});if(Math.random()<.8)pop(fx,cx,520,1,'#ffffff90',50,.8);if(Math.random()<.03)sf('tick')}
   nx-=dt;if(nx<=0){tr.push({x:L+30+Math.random()*(R-L-60),y:-60,c:['#3df2ff','#7dff6b','#c28bff','#ff7a1a'][Math.random()*4|0],v:sp*.45});nx=Math.max(.45,1-sp/900)}
   tr.forEach(o=>o.y+=(sp-o.v)*dt);tr=tr.filter(o=>o.y<H+70);
   if(tr.some(o=>Math.abs(o.x-cx)<30&&Math.abs(o.y-500)<50)){dead=1;shake=.6;sf('die');pop(fx,cx,500,30,'#ff9a3c',300,.9);a.t(()=>a.end(sc|0,'اصطدمت! قطعت '+(sc|0)+' نقطة'),900)}}
  sk.forEach(s=>{s.y+=sp*dt;s.l-=dt});sk=sk.filter(s=>s.l>0&&s.y<H+10);stepFx(fx,dt);
  x.save();if(shake>0)x.translate((Math.random()-.5)*14*shake*2,(Math.random()-.5)*14*shake*2);
  x.fillStyle='#14102a';x.fillRect(-20,-20,W+40,H+40);x.fillStyle='#2b2b3a';x.fillRect(L,0,R-L,H);x.fillStyle='#ff3b5c';for(let y=-60+off;y<H;y+=60){x.fillRect(L-6,y,6,30);x.fillRect(R,y,6,30)}x.fillStyle='#ffffff80';for(let y=-60+off;y<H;y+=60){x.fillRect(W/2-3,y,6,32)}
  x.fillStyle='#000b';sk.forEach(s=>{x.globalAlpha=Math.min(1,s.l/1.2);x.fillRect(s.x-3,s.y,6,16)});x.globalAlpha=1;
  tr.forEach(o=>car(o.x,o.y,0,o.c,0));if(!dead)car(cx,500,Math.max(-.7,Math.min(.7,vx/260)),'#ffb020',1);drawFx(x,fx);
  x.fillStyle='#fff';x.font='900 30px system-ui';x.textAlign='center';x.fillText(sc|0,W/2,44);if(dr&&!dead){x.fillStyle='#ffd23f';x.font='900 20px system-ui';x.fillText('تفحيط!',W/2,74)}x.restore()})}
/* ---- Kart RPG-style top-down ---- */
function gKart2(b,a){
 const W=360,H=520,CX=400,CY=480,RX=270,RY=410,TW=64,c=CV(b,W,H),x=c.getContext('2d');
 const P={x:CX,y:CY+RY,a:Math.PI,vx:0,vy:0,prog:0,last:Math.PI/2,lap:0};let s=0,dr=0,fx=[],sk=[],shake=0,t=0,fin=0,go=3,sm=0;
 const ai=[0,1,2].map(i=>({th:Math.PI/2-.12*(i+1),w:2*Math.PI/(8.6+i*.5),off:(i-1)*24,prog:0,col:['#3df2ff','#7dff6b','#c28bff'][i]}));
 const er=th=>1/Math.hypot(Math.cos(th)/RX,Math.sin(th)/RY);
 b.insertAdjacentHTML('beforeend','<button class="btn p" id="dk" style="width:100%;margin-top:8px;min-height:60px;font-size:20px;touch-action:none">اضغط للتفحيط</button>');
 const dk=b.querySelector('#dk');EL(a,dk,'pointerdown',e=>{e.preventDefault();dr=1});['pointerup','pointercancel','pointerleave'].forEach(n=>EL(a,dk,n,()=>{dr=0}));
 EL(a,c,'pointerdown',e=>{e.preventDefault();const r=c.getBoundingClientRect();s=(e.clientX-r.left)<r.width/2?-1:1});['pointerup','pointercancel'].forEach(n=>EL(a,c,n,()=>{s=0}));
 KEYS(a,{ArrowLeft:()=>s=-1,ArrowRight:()=>s=1,KeyA:()=>s=-1,KeyD:()=>s=1,Space:()=>dr=1});EL(a,document,'keyup',e=>{if(e.code==='Space')dr=0;else s=0});
 b.querySelector('#ei').textContent='المس يمين/يسار للتوجيه، وامسك زر التفحيط في المنعطفات - 3 لفات';
 const car=(px,py,ang,col)=>{x.save();x.translate(px,py);x.rotate(ang+Math.PI/2);x.fillStyle='#0005';rr(x,-12,-15,28,42,8);x.fill();x.fillStyle='#111';x.fillRect(-15,-12,5,11);x.fillRect(10,-12,5,11);x.fillRect(-15,8,5,11);x.fillRect(10,8,5,11);x.fillStyle=col;rr(x,-11,-20,22,40,8);x.fill();x.fillStyle='#bff6ff';rr(x,-8,-8,16,10,3);x.fill();x.fillStyle='#fff';x.fillRect(-1.5,-20,3,40);x.restore()};
 LOOP(a,dt=>{t+=dt;shake=Math.max(0,shake-dt);
  if(go>0){go-=dt}else if(!fin){
   const f0={x:Math.cos(P.a),y:Math.sin(P.a)},sd={x:-f0.y,y:f0.x};let f=P.vx*f0.x+P.vy*f0.y,l=P.vx*sd.x+P.vy*sd.y;
   P.a+=s*(dr?3.2:2.4)*Math.max(.45,Math.min(1,Math.abs(f)/110))*dt;f+=(dr?230:330)*dt;f=Math.min(f,dr?290:310);l*=Math.pow(dr?.45:.004,dt);
   const g={x:Math.cos(P.a),y:Math.sin(P.a)},h={x:-g.y,y:g.x};P.vx=g.x*f+h.x*l;P.vy=g.y*f+h.y*l;P.x+=P.vx*dt;P.y+=P.vy*dt;
   const dx=P.x-CX,dy=P.y-CY,th=Math.atan2(dy,dx),re=er(th),dd=Math.hypot(dx,dy)-re;
   if(Math.abs(dd)>TW-10){const k=(re+Math.sign(dd)*(TW-10))/Math.hypot(dx,dy);P.x=CX+dx*k;P.y=CY+dy*k;{const nn=Math.hypot(dx,dy)||1,nx=dx/nn,ny=dy/nn,vn=P.vx*nx+P.vy*ny;if(vn*Math.sign(dd)>0){P.vx-=vn*nx*1.3;P.vy-=vn*ny*1.3}P.vx*=.94;P.vy*=.94}if(shake<.1){sf('land');shake=.25;pop(fx,P.x,P.y,12,'#ffd23f',210,.4)}}
   if(Math.abs(l)>45){const w=P.a+Math.PI/2;[-1,1].forEach(q=>sk.push({x:P.x-g.x*10+h.x*7*q,y:P.y-g.y*10+h.y*7*q,l:3}));if(Math.random()<.7)pop(fx,P.x-g.x*14,P.y-g.y*14,1,'#ffffff80',45,.7);if(Math.random()<.04)sf('tick')}
   let dl=th-P.last;while(dl>Math.PI)dl-=2*Math.PI;while(dl<-Math.PI)dl+=2*Math.PI;P.prog+=dl;P.last=th;
   ai.forEach(q=>{q.th+=q.w*dt;q.prog+=q.w*dt});
   if(P.prog>=6*Math.PI-.3){fin=1;const pl=1+ai.filter(q=>q.prog>=P.prog-.3).length;sf(pl===1?'win':'end');a.t(()=>a.end(Math.max(10,(5-pl)*120+Math.max(0,60-(t|0))*3),'انتهى السباق: المركز '+pl+' من 4'),700)}
   sm+=dt}
  sk.forEach(q=>q.l-=dt);sk=sk.filter(q=>q.l>0);stepFx(fx,dt);
  x.save();if(shake>0)x.translate((Math.random()-.5)*10,(Math.random()-.5)*10);
  x.translate(Math.round(W/2-P.x),Math.round(H/2-P.y));x.fillStyle='#1c5a34';x.fillRect(-400,-400,1600,1800);x.fillStyle='#ffffff10';for(let i=0;i<160;i++)x.fillRect((i*73)%800,(i*131)%960,18,4);
  x.lineWidth=TW*2;x.strokeStyle='#ff3b5c';x.beginPath();x.ellipse(CX,CY,RX,RY,0,0,6.283);x.setLineDash([16,16]);x.lineWidth=TW*2+10;x.stroke();x.setLineDash([]);x.strokeStyle='#34344a';x.lineWidth=TW*2;x.stroke();
  x.fillStyle='#1c5a34';x.beginPath();x.ellipse(CX,CY,RX-TW,RY-TW,0,0,6.283);x.fill();
  x.fillStyle='#fff';for(let i=0;i<6;i++){x.fillStyle=i%2?'#111':'#fff';x.fillRect(CX-3+0,CY+RY-TW+i*(TW*2/6),6,TW*2/6)}
  x.fillStyle='#000a';sk.forEach(q=>{x.globalAlpha=Math.min(1,q.l/1.5);x.beginPath();x.arc(q.x,q.y,2.5,0,6.283);x.fill()});x.globalAlpha=1;
  ai.forEach(q=>{const r=er(q.th)+q.off;car(CX+Math.cos(q.th)*r,CY+Math.sin(q.th)*r,q.th+Math.PI/2,q.col)});
  car(P.x,P.y,P.a,'#ffb020');drawFx(x,fx);
  const lap=Math.min(3,1+Math.max(0,P.prog/(2*Math.PI)|0));x.fillStyle='#fff';x.font='900 20px system-ui';x.textAlign='center';x.fillText('اللفة '+lap+'/3',P.x,P.y-190);
  if(go>0){x.font='900 70px system-ui';x.fillStyle='#ffd23f';x.fillText(Math.ceil(go),P.x,P.y-60)}x.restore()})}
/* ---- Dungeon 2D RPG ---- */
function gDun2(b,a){
 const W=360,H=520,c=CV(b,W,H),x=c.getContext('2d');
 const K={};let joy=null,P,wall,en,coin,fx=[],lv=0,score=0,t=0,shake=0,atk=0,cd=0,inv=0,open=0,over=0,sl=0;
 const R=(l,t2,w,h)=>({l,t:t2,w,h});
 const build=()=>{lv++;P={x:W/2,y:H-60,hp:P?P.hp:5,f:{x:0,y:-1}};wall=[R(0,0,W,16),R(0,H-16,W,16),R(0,0,16,H),R(W-16,0,16,H)];for(let i=0;i<4+lv;i++){const w=34+Math.random()*50,h=30+Math.random()*40,l=24+Math.random()*(W-w-48),t2=110+Math.random()*(H-300);wall.push(R(l,t2,w,h))}
  en=[];for(let i=0;i<3+lv*2;i++)en.push({x:30+Math.random()*(W-60),y:40+Math.random()*180,hp:2+(lv>2?1:0),v:36+lv*6+Math.random()*14,kb:0,kx:0,ky:0});coin=[];open=0;
  wall=wall.filter((q,i)=>i<4||(Math.hypot(q.l+q.w/2-W/2,q.t+q.h/2-(H-60))>90&&!en.some(e=>e.x>q.l-12&&e.x<q.l+q.w+12&&e.y>q.t-12&&e.y<q.t+q.h+12)))};
 const hit=(px,py,r)=>wall.some(q=>px+r>q.l&&px-r<q.l+q.w&&py+r>q.t&&py-r<q.t+q.h);
 const mv=(o,dx,dy,r)=>{if(!hit(o.x+dx,o.y,r))o.x+=dx;if(!hit(o.x,o.y+dy,r))o.y+=dy};
 build();
 b.insertAdjacentHTML('beforeend','<button class="btn p" id="sw" style="width:100%;margin-top:8px;min-height:60px;font-size:20px;touch-action:none">اضرب بالسيف</button>');
 const swing=()=>{if(cd>0||over)return;cd=.38;atk=.16;sf('tap');en.forEach(e=>{const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy);if(d<54){e.hp--;e.kb=.2;e.kx=dx/d*260;e.ky=dy/d*260;pop(fx,e.x,e.y,8,'#e8e8ff',150,.4);if(e.hp<=0){e.dead=1;sf('pop');pop(fx,e.x,e.y,16,'#ffd23f',200,.6);coin.push({x:e.x,y:e.y})}}});en=en.filter(e=>!e.dead);if(!en.length&&!open){open=1;sf('milestone')}};
 EL(a,b.querySelector('#sw'),'pointerdown',e=>{e.preventDefault();swing()});
 KEYS(a,{Space:swing,KeyJ:swing});EL(a,document,'keydown',e=>{K[e.code]=1});EL(a,document,'keyup',e=>{K[e.code]=0});
 EL(a,c,'pointerdown',e=>{e.preventDefault();const r=c.getBoundingClientRect();joy={ox:e.clientX,oy:e.clientY,dx:0,dy:0,sx:(e.clientX-r.left)*W/r.width,sy:(e.clientY-r.top)*H/r.height}});
 EL(a,c,'pointermove',e=>{if(!joy)return;let dx=e.clientX-joy.ox,dy=e.clientY-joy.oy;const d=Math.hypot(dx,dy),m=40;if(d>m){dx*=m/d;dy*=m/d}joy.dx=dx/m;joy.dy=dy/m});
 ['pointerup','pointercancel'].forEach(n=>EL(a,c,n,()=>{joy=null}));
 b.querySelector('#ei').textContent='اسحب بإصبعك للتحرك - اقضِ على الهياكل ثم ادخل الباب العلوي';
 LOOP(a,dt=>{t+=dt;cd-=dt;atk=Math.max(0,atk-dt);inv=Math.max(0,inv-dt);shake=Math.max(0,shake-dt);
  if(!over){let ax=(K.ArrowRight||K.KeyD?1:0)-(K.ArrowLeft||K.KeyA?1:0),ay=(K.ArrowDown||K.KeyS?1:0)-(K.ArrowUp||K.KeyW?1:0);if(joy){ax=joy.dx;ay=joy.dy}const m=Math.hypot(ax,ay);if(m>.12){const k=Math.min(1,m)/m;ax*=k;ay*=k;P.f={x:ax/Math.hypot(ax,ay),y:ay/Math.hypot(ax,ay)};mv(P,ax*130*dt,ay*130*dt,11);sl+=dt*12;if(Math.random()<.2)pop(fx,P.x,P.y+12,1,'#ffffff40',30,.4)}
   en.forEach(e=>{if(e.kb>0){e.kb-=dt;mv(e,e.kx*dt,e.ky*dt,10)}else{const dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy)||1;mv(e,dx/d*e.v*dt,dy/d*e.v*dt,10)}
    if(Math.hypot(P.x-e.x,P.y-e.y)<20&&inv<=0){P.hp--;inv=1;shake=.3;sf('bad');pop(fx,P.x,P.y,14,'#ff3b5c',200,.6);if(P.hp<=0){over=1;a.t(()=>a.end(score,'سقط البطل في المرحلة '+lv),900)}}});
   coin=coin.filter(q=>{if(Math.hypot(P.x-q.x,P.y-q.y)<20){score+=10;sf('pop');pop(fx,q.x,q.y,6,'#ffd23f',120,.4);return false}return true});
   if(open&&P.y<40&&Math.abs(P.x-W/2)<34){score+=50*lv;sf('win');P.hp=Math.min(5,P.hp+1);build()}}
  stepFx(fx,dt);
  x.save();if(shake>0)x.translate((Math.random()-.5)*8,(Math.random()-.5)*8);
  x.fillStyle='#1b1530';x.fillRect(-10,-10,W+20,H+20);for(let i=0;i<W;i+=40)for(let j=0;j<H;j+=40){x.fillStyle=(i+j)/40%2?'#241c3f':'#201838';x.fillRect(i,j,40,40)}
  wall.forEach(q=>{x.fillStyle='#4a4468';x.fillRect(q.l,q.t,q.w,q.h);x.fillStyle='#6b6590';x.fillRect(q.l,q.t,q.w,4);x.fillStyle='#0006';x.fillRect(q.l,q.t+q.h-5,q.w,5)});
  [[40,16],[W-40,16],[16,H/2],[W-16,H/2]].forEach((q,i)=>{const fl=.7+Math.sin(t*14+i*2)*.2,g=x.createRadialGradient(q[0],q[1],2,q[0],q[1],70*fl);g.addColorStop(0,'#ff9a3c88');g.addColorStop(1,'#ff9a3c00');x.fillStyle=g;x.fillRect(q[0]-80,q[1]-80,160,160);x.fillStyle='#ffd23f';x.beginPath();x.arc(q[0],q[1],4*fl,0,6.283);x.fill()});
  x.fillStyle=open?'#7dff9a':'#0b0816';x.fillRect(W/2-30,0,60,18);if(open){x.shadowColor='#7dff9a';x.shadowBlur=20;x.fillRect(W/2-30,0,60,6);x.shadowBlur=0}
  coin.forEach(q=>{x.fillStyle='#ffd23f';x.beginPath();x.ellipse(q.x,q.y+Math.sin(t*6)*2,6,6*Math.abs(Math.cos(t*4)),0,0,6.283);x.fill()});
  en.forEach(e=>{x.save();x.translate(e.x,e.y+Math.sin(t*8+e.x)*1.5);x.fillStyle='#0004';x.beginPath();x.ellipse(0,11,10,4,0,0,6.283);x.fill();x.fillStyle=e.kb>0?'#ff9a9a':'#e9e9f5';x.beginPath();x.arc(0,-2,10,0,6.283);x.fill();x.fillRect(-6,6,12,6);x.fillStyle='#111';x.beginPath();x.arc(-4,-3,2.6,0,6.283);x.arc(4,-3,2.6,0,6.283);x.fill();x.fillStyle='#ff3b3b';x.fillRect(-4,-4,1.5,1.5);x.fillRect(4,-4,1.5,1.5);x.restore()});
  if(!over&&(inv<=0||Math.floor(t*20)%2)){x.save();x.translate(P.x,P.y+Math.sin(sl)*1.5);x.fillStyle='#0004';x.beginPath();x.ellipse(0,12,11,4,0,0,6.283);x.fill();x.fillStyle='#3d7bff';x.beginPath();x.moveTo(-9,10);x.lineTo(9,10);x.lineTo(6,-6);x.lineTo(-6,-6);x.fill();x.fillStyle='#ffd7a8';x.beginPath();x.arc(0,-10,8,0,6.283);x.fill();x.fillStyle='#d94a4a';x.fillRect(-8,-18,16,5);x.fillStyle='#222';x.fillRect(-3+P.f.x*2,-11+P.f.y*2,2,3);x.fillRect(2+P.f.x*2,-11+P.f.y*2,2,3);
   const an=Math.atan2(P.f.y,P.f.x)+(atk>0?(atk/.16-.5)*2.2:0);x.rotate(an);x.fillStyle='#cfd8ff';x.fillRect(8,-2,22,4);x.fillStyle='#8a5a2b';x.fillRect(5,-3,5,6);if(atk>0){x.strokeStyle='#fff';x.lineWidth=4;x.globalAlpha=atk/.16;x.beginPath();x.arc(0,0,38,-1,1);x.stroke()}x.restore()}
  drawFx(x,fx);if(joy){x.strokeStyle='#ffffff50';x.lineWidth=2;x.beginPath();x.arc(joy.sx,joy.sy,34,0,6.283);x.stroke();x.fillStyle='#ffffff40';x.beginPath();x.arc(joy.sx+joy.dx*34,joy.sy+joy.dy*34,14,0,6.283);x.fill()}
  x.font='900 16px system-ui';x.textAlign='left';x.fillStyle='#ff5c7a';for(let i=0;i<P.hp;i++)x.fillText('♥',24+i*18,38);x.fillStyle='#fff';x.textAlign='right';x.fillText('مرحلة '+lv+' · '+score,W-24,38);x.restore()})}
/* ---- register ---- */
const defs={flappy:{run:gFlap2,d:'المس الشاشة في أي مكان وطِر بين الأنابيب. ريش وارتجاج لما تصطدم.'},kart:{run:gKart2,d:'سباق كارت من فوق: وجّه وفحّط في اللفّات مع دخان وآثار إطارات ضد 3 منافسين.'},dungeon:{run:gDun2,d:'مغامر 2D تحركه بالسحب وتضرب بالسيف، خلّص الهياكل وادخل الباب للمرحلة اللي بعدها.'},towerdef:{run:gTD2,d:'ابنِ أبراج على الدوائر وطوّرها لين المستوى 6 بالذهب وصدّ الموجات.'}};
G.forEach(g=>{const o=defs[g.id];if(o)Object.assign(g,o);if(window.CICON[g.i])g.i=g.i});
/* tap anywhere for dino */
const _d=G.find(g=>g.id==='dino'),_dr=_d&&_d.run;if(_dr)_d.run=(b,a)=>{_dr(b,a);EL(a,b,'pointerdown',e=>{if(e.target.closest('button')||e.target.tagName==='CANVAS')return;document.dispatchEvent(new KeyboardEvent('keydown',{code:'Space',key:' '}))})};
/* studio tag in settings */
new MutationObserver(()=>{const d=document.getElementById('det'),bx=d&&d.firstElementChild;if(bx&&/Settings/.test(bx.textContent)&&!bx.querySelector('.studio-tag'))bx.insertAdjacentHTML('beforeend','<div class="studio-tag">MINI GAME STUDIO</div>')}).observe(document.getElementById('det'),{childList:true,subtree:true});
})();

/* ===== V5.1: tidy icons + emoji replacer ===== */
(()=>{
const st=document.createElement('style');st.textContent=`.ci{overflow:hidden!important;display:inline-block;width:24px;height:24px;vertical-align:middle}#gb canvas{width:auto!important;height:auto!important;max-width:100%!important;max-height:calc(100dvh - 280px)!important}#gt{display:flex;align-items:center;gap:8px;min-width:0}#gt .ci{width:26px;height:26px;flex:none}.gi .ci{width:40px!important;height:40px!important}.gi.big .ci{width:60px!important;height:60px!important;margin:auto}.ei{display:inline-block;width:1.05em;height:1.05em;vertical-align:-.17em}`;document.head.appendChild(st);
Object.keys(CICON).forEach(k=>{const f=CICON[k];CICON[k]=()=>f().replace('aria-hidden="true">','aria-hidden="true"><rect width="48" height="48" rx="13" fill="#ffffff14"/><g transform="translate(6 6) scale(.75)">').replace(/<\/svg>$/,'</g></svg>')});
const TI={quiz:'<path d="M18 19q0-7 6-7t6 6q0 4-6 6v3"/><path d="M24 36h.1" stroke-width="4"/>',xo:'<path d="M11 11l12 12M23 11L11 23"/><circle cx="32" cy="32" r="7"/>',sab:'<circle cx="22" cy="28" r="10"/><path d="M29 21l6-6M33 11l3 3"/>',score:'<path d="M16 11h16v9q0 8-8 8t-8-8zM16 14h-5q0 7 6 9M32 14h5q0 7-6 9M24 28v6M17 37h14"/>',detect:'<circle cx="21" cy="21" r="10"/><path d="M29 29l9 9"/>',most:'<path d="M11 33L9 15l9 8 6-11 6 11 9-8-2 18zM12 38h24"/>',categories:'<rect x="11" y="11" width="11" height="11" rx="3"/><rect x="26" y="11" width="11" height="11" rx="3"/><rect x="11" y="26" width="11" height="11" rx="3"/><rect x="26" y="26" width="11" height="11" rx="3"/>',secretword:'<rect x="12" y="22" width="24" height="16" rx="4"/><path d="M17 22v-4a7 7 0 0114 0v4"/>',g2048:'<rect x="10" y="10" width="28" height="28" rx="6"/><path d="M17 20q0-5 5-5t4 5l-9 11h10"/>',lights:'<path d="M24 9a11 11 0 00-6 20v4h12v-4a11 11 0 00-6-20zM20 38h8"/>',slide:'<rect x="10" y="10" width="28" height="28" rx="5"/><path d="M10 24h18M24 10v18"/>',seqiq:'<circle cx="14" cy="33" r="3"/><circle cx="24" cy="24" r="3"/><circle cx="34" cy="14" r="3"/><path d="M16 31l6-5M26 22l6-5"/>',riddles:'<path d="M12 19h7a4 4 0 118 0h7v8a4 4 0 100 8H12z"/>',code:'<path d="M18 16l-8 8 8 8M30 16l8 8-8 8M26 11l-4 26"/>',memory:'<rect x="10" y="14" width="17" height="23" rx="3"/><rect x="21" y="11" width="17" height="23" rx="3" fill="#ffffff30"/>',number:'<path d="M20 10l-3 28M32 10l-3 28M11 20h27M10 30h27"/>',odd:'<circle cx="15" cy="16" r="5"/><circle cx="33" cy="16" r="5"/><circle cx="15" cy="32" r="5"/><rect x="28" y="27" width="10" height="10" rx="2" fill="#ffe08a" stroke="none"/>',match:'<circle cx="19" cy="24" r="9"/><circle cx="29" cy="24" r="9"/>',differences:'<path d="M7 24q17-17 34 0-17 17-34 0z"/><circle cx="24" cy="24" r="5"/>',scramble:'<path d="M9 16h6q6 0 10 8t10 8h3M9 32h6q4 0 6-3M26 19q3-3 7-3h5M34 12l4 4-4 4M34 28l4 4-4 4"/>',math:'<path d="M24 10v14M17 17h14M15 34h18"/>',tap:'<circle cx="24" cy="24" r="3" fill="#fff"/><circle cx="24" cy="24" r="10"/><circle cx="24" cy="24" r="16" opacity=".5"/>',react:'<path d="M27 7L13 27h9l-2 14 14-20h-9z" fill="#ffe08a" stroke="none"/>',whack:'<path d="M11 37l14-14M21 11l16 16-6 6-16-16z"/>',typing:'<rect x="8" y="15" width="32" height="20" rx="4"/><path d="M14 22h.1M21 22h.1M28 22h.1M34 22h.1M16 29h16"/>',guess:'<circle cx="24" cy="24" r="15"/><circle cx="24" cy="24" r="7"/><path d="M24 24h.1"/>',rps:'<circle cx="15" cy="33" r="4"/><circle cx="33" cy="33" r="4"/><path d="M18 30l17-19M30 30L13 11"/>',dice:'<rect x="10" y="10" width="28" height="28" rx="6"/><path d="M18 18h.1M24 24h.1M30 30h.1" stroke-width="4.5"/>',c4:'<circle cx="16" cy="16" r="5"/><circle cx="32" cy="16" r="5" fill="#ffe08a" stroke="none"/><circle cx="16" cy="32" r="5" fill="#ffe08a" stroke="none"/><circle cx="32" cy="32" r="5"/>',forbid:'<circle cx="24" cy="24" r="15"/><path d="M13 35L35 13"/>',trivia:'<path d="M9 12h12q3 0 3 3v22q0-3-3-3H9zM39 12H27q-3 0-3 3v22q0-3 3-3h12z"/>',whoami:'<circle cx="24" cy="17" r="7"/><path d="M10 38q0-12 14-12t14 12"/>',mafia:'<path d="M12 26l4-14h16l4 14zM8 26h32M15 34h18"/>',undercover:'<circle cx="15" cy="27" r="6"/><circle cx="33" cy="27" r="6"/><path d="M21 27h6M9 23l-2-5M39 23l2-5"/>',charades:'<rect x="10" y="21" width="28" height="17" rx="3"/><path d="M10 21l4-9 8 3-4 6M24 16l8 3 4-8"/>',fibbage:'<path d="M10 12h28v19H26l-7 6v-6h-9z"/><path d="M18 21h.1M24 21h.1M30 21h.1" stroke-width="4"/>',telephone:'<path d="M14 10h7l3 8-4 3q3 6 8 8l3-4 8 3v7q0 3-4 3Q11 38 10 14q0-4 4-4z"/>',majd:'<path d="M24 9l4.500 9 10 1.500-7.300 7 1.800 10L24 32l-9 4.500 1.800-10-7.300-7 10-1.500z"/>',carrom:'<rect x="9" y="9" width="30" height="30" rx="5"/><circle cx="24" cy="24" r="5"/><path d="M15 15h.1M33 15h.1M15 33h.1M33 33h.1" stroke-width="4"/>'};
Object.keys(TI).forEach((k,i)=>{const h=(i*41+12)%360;CICON['v_'+k]=()=>`<svg class="ci" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="tg${k}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h} 82% 60%)"/><stop offset="1" stop-color="hsl(${(h+38)%360} 78% 40%)"/></linearGradient></defs><rect width="48" height="48" rx="13" fill="url(#tg${k})"/><g fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">${TI[k]}</g></svg>`});
G.forEach(g=>{if(TI[g.id])g.i='v_'+g.id});
/* emoji -> small svg */
const mk=(p,c,f)=>`<svg class="ei" viewBox="0 0 24 24" fill="${f||'none'}" stroke="${c||'currentColor'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const star='<path d="M12 3l2.800 5.700 6.200.9-4.500 4.400 1 6.200L12 17.200 6.500 20.200l1-6.200L3 9.600l6.200-.9z"/>',heart='<path d="M12 20S4 15 4 9.500A4.500 4.500 0 0112 7a4.500 4.500 0 018 2.500C20 15 12 20 12 20z"/>',up='<path d="M12 20V5M6 11l6-6 6 6"/>',dn='<path d="M12 4v15M6 13l6 6 6-6"/>',gear='<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>';
const E={'★':mk(star,'#ffd23f','#ffd23f'),'⭐':mk(star,'#ffd23f','#ffd23f'),'✦':mk('<path d="M12 3l2 7 7 2-7 2-2 7-2-7-7-2 7-2z"/>','#ffd23f','#ffd23f'),'✨':mk('<path d="M12 3l2 7 7 2-7 2-2 7-2-7-7-2 7-2z"/>','#ffd23f','#ffd23f'),
'💰':mk('<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.500 9.500h4a2 2 0 010 3h-3a2 2 0 000 3h4"/>','#b8860b','#ffd23f'),'❤':mk(heart,'#ff3b5c','#ff3b5c'),'🧡':mk(heart,'#ff7a1a','#ff7a1a'),'💙':mk(heart,'#1ea0ff','#1ea0ff'),'💜':mk(heart,'#a66cff','#a66cff'),
'✔':mk('<path d="M5 13l4 4 10-10"/>','#3ddc84'),'✓':mk('<path d="M5 13l4 4 10-10"/>','#3ddc84'),'💎':mk('<path d="M6 4h12l4 6-10 11L2 10z"/>','#3df2ff','#3df2ff55'),'🚪':mk('<rect x="6" y="3" width="12" height="18" rx="2"/><path d="M15 12h.1"/>','#c28b55'),
'⏱':mk('<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/>'),'🕐':mk('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),'🕑':mk('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),'⚡':mk('<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>','#ffd23f','#ffd23f'),
'▶':mk('<path d="M7 4l13 8-13 8z"/>','currentColor','currentColor'),'◀':mk('<path d="M17 4L4 12l13 8z"/>','currentColor','currentColor'),'←':mk('<path d="M20 12H4M10 6l-6 6 6 6"/>'),'↑':mk(up),'⬆':mk(up),'↓':mk(dn),'⬇':mk(dn),'▲':mk('<path d="M12 5l8 14H4z"/>','#ff3b5c','#ff3b5c'),'▼':mk('<path d="M12 19L4 5h16z"/>','#1ea0ff','#1ea0ff'),'🔺':mk('<path d="M12 5l8 14H4z"/>','#ff3b5c','#ff3b5c'),'🔻':mk('<path d="M12 19L4 5h16z"/>','#1ea0ff','#1ea0ff'),
'↻':mk('<path d="M20 12a8 8 0 11-3-6.200M20 4v5h-5"/>'),'🏰':mk('<path d="M4 21V8h4v3h2V8h4v3h2V8h4v13zM10 21v-5h4v5"/>','#9db9ff'),'🧟':mk('<circle cx="12" cy="12" r="9"/><path d="M9 10h.1M15 10h.1M8 16h8"/>','#3f8f3a','#7bd36b'),
'⚔️':mk('<path d="M5 19L17 7M14 4h6v6M19 19L7 7M10 4H4v6"/>'),'⚔':mk('<path d="M5 19L17 7M14 4h6v6M19 19L7 7M10 4H4v6"/>'),'🔊':mk('<path d="M4 9v6h4l5 4V5L8 9zM16 9a4 4 0 010 6M18.500 6.500a8 8 0 010 11"/>'),'🔔':mk('<path d="M6 17v-6a6 6 0 0112 0v6l2 2H4zM10 21h4"/>'),'🔕':mk('<path d="M6 17v-6a6 6 0 0112 0v6l2 2H4zM10 21h4M4 4l16 16"/>'),
'🎯':mk('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>','#ff3b5c'),'🔐':mk('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>'),'🔑':mk('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>','#ffd23f'),'🗝️':mk('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>','#ffd23f'),'🗝':mk('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>','#ffd23f'),
'💧':mk('<path d="M12 3s7 7 7 12a7 7 0 01-14 0c0-5 7-12 7-12z"/>','#3df2ff','#3df2ff'),'🪵':mk('<rect x="3" y="8" width="18" height="8" rx="4"/>','#5b3a1e','#8a5a2b'),'🌙':mk('<path d="M20 14A8 8 0 1110 4a7 7 0 0010 10z"/>','#ffe08a','#ffe08a'),'🧑':mk('<circle cx="12" cy="8" r="4"/><path d="M4 21q0-8 8-8t8 8"/>'),
'🌾':mk('<path d="M12 21V8M12 8c-3 0-4-2-4-4 3 0 4 2 4 4zM12 8c3 0 4-2 4-4-3 0-4 2-4 4zM12 14c-3 0-4-2-4-4M12 14c3 0 4-2 4-4"/>','#f5c542'),'☀️':mk('<circle cx="12" cy="12" r="4"/>'+gear.split('/>')[1],'#ffd23f','#ffd23f'),'☀':mk('<circle cx="12" cy="12" r="4"/>','#ffd23f','#ffd23f'),'🌞':mk('<circle cx="12" cy="12" r="4"/>','#ffd23f','#ffd23f'),
'🏹':mk('<path d="M5 4q15 3 15 16M4 5l16 15M3 8l5-5"/>','#c28b55'),'⚙':mk(gear),'⏸':mk('<path d="M8 5v14M16 5v14"/>'),'●':mk('<circle cx="12" cy="12" r="6"/>','currentColor','currentColor'),'○':mk('<circle cx="12" cy="12" r="6"/>'),'⇄':mk('<path d="M4 8h14M14 4l4 4-4 4M20 16H6M10 12l-4 4 4 4"/>'),'🛒':mk('<path d="M3 4h3l2 12h10l2-8H7"/><circle cx="10" cy="20" r="1.500"/><circle cx="17" cy="20" r="1.500"/>'),'🏕':mk('<path d="M3 20L12 5l9 15zM12 20l-3-7h6z"/>','#ff9a3c','#ff9a3c33'),'⛺':mk('<path d="M3 20L12 5l9 15zM12 20l-3-7h6z"/>','#ff9a3c','#ff9a3c33'),'🏜':mk('<path d="M8 21V9a2 2 0 014 0v12M12 14h4a2 2 0 002-2V8M8 16H5"/>','#3ddc84'),'🌵':mk('<path d="M8 21V9a2 2 0 014 0v12M12 14h4a2 2 0 002-2V8M8 16H5"/>','#3ddc84'),'🏝':mk('<path d="M12 21V9M12 9c-4-4-8-1-8-1 4-1 6 0 8 1zM12 9c4-4 8-1 8-1-4-1-6 0-8 1z"/>','#2ecc71'),'🍎':mk('<path d="M12 8c-5-3-8 1-7 6s4 7 7 6 6 1 7-6-2-9-7-6zM12 8c0-3 1-4 3-5"/>','#ff3b5c','#ff3b5c'),'🔥':mk('<path d="M12 21c-5 0-7-4-5-8 1 2 3 2 3 0 0-3 1-6 3-9 1 4 5 6 5 11 0 4-2 6-6 6z"/>','#ff7a1a','#ff9a3c'),'🏆':mk('<path d="M7 4h10v6a5 5 0 01-10 0zM7 6H3q0 5 4 5M17 6h4q0 5-4 5M12 15v4M8 20h8"/>','#ffd23f'),'💀':mk('<path d="M5 12a7 7 0 0114 0v4l-3 1v3H8v-3l-3-1z"/><path d="M9 12h.1M15 12h.1"/>'),'🎉':mk('<path d="M4 20l5-12 7 7z"/><path d="M14 4v2M19 9h2M17 6l1-1"/>','#ffd23f'),'🎮':mk('<rect x="3" y="8" width="18" height="10" rx="5"/><path d="M8 11v4M6 13h4M16 12h.1M18 14h.1"/>'),
'🦂':mk('<path d="M5 19q0-10 8-10t6 7M17 15l3 2"/>','#ff7a1a')};
const rx=new RegExp('('+Object.keys(E).sort((a,b)=>b.length-a.length).map(k=>k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')\\ufe0f?','g'),t1=new RegExp(rx.source);
const run=()=>{const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT),L=[];while(w.nextNode()){const n=w.currentNode,p=n.parentElement;if(p&&t1.test(n.data)&&!/^(SCRIPT|STYLE|TEXTAREA|OPTION|TEXT|TSPAN|TITLE)$/i.test(p.tagName)&&!p.closest('.cell,svg'))L.push(n)}
 L.forEach(n=>{const f=document.createElement('span');f.innerHTML=n.data.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(rx,(m,k)=>E[k]);n.replaceWith(...f.childNodes)})};
let q=0;new MutationObserver(()=>{if(q)return;q=1;setTimeout(()=>{q=0;if(!(cur&&api.live&&document.querySelector('#gb canvas')))run()},300)}).observe(document.body,{childList:true,subtree:true,characterData:true});run();
})();

/* ===== V6: perf mode, intro, polish, new Dino/Flappy/Oasis ===== */
(()=>{
const R=Math.random,QL=()=>XS.perf?0:(XS.q==null?1:XS.q|0),PM=()=>[.35,.7,1][QL()];
const sf=n=>{try{(SFX[n]||SFX.tap)()}catch(e){}};
const rr=(x,a,b,w,h,r)=>{x.beginPath();x.moveTo(a+r,b);x.arcTo(a+w,b,a+w,b+h,r);x.arcTo(a+w,b+h,a,b+h,r);x.arcTo(a,b+h,a,b,r);x.arcTo(a,b,a+w,b,r);x.closePath()};
const fxp=(f,x,y,n,c,sp=160,l=.6,g=200)=>{n=Math.ceil(n*PM());if(!XS.part)n=Math.min(n,1);for(let i=0;i<n&&f.length<320;i++){const an=R()*6.283,v=sp*(.25+R());f.push({x,y,vx:Math.cos(an)*v,vy:Math.sin(an)*v,l:l*(.5+R()*.5),m:l,c,s:1.5+R()*2.5,g})}};
const fxs=(f,dt)=>{for(let i=f.length;i--;){const p=f[i];p.l-=dt;if(p.l<=0){f.splice(i,1);continue}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.g*dt;p.vx*=.99}};
const fxd=(x,f)=>{x.save();if(QL())x.globalCompositeOperation='lighter';f.forEach(p=>{const k=Math.max(0,p.l/p.m);x.globalAlpha=k;x.fillStyle=p.c;x.beginPath();x.arc(p.x,p.y,p.s*(.4+k*.8),0,6.283);x.fill()});x.restore()};
const glow=(x,px,py,r,c,a=1)=>{if(!QL())return;const g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,c);g.addColorStop(1,'transparent');x.save();x.globalCompositeOperation='lighter';x.globalAlpha=a;x.fillStyle=g;x.fillRect(px-r,py-r,r*2,r*2);x.restore()};
const mx=(a,b,k)=>'rgb('+a.map((v,i)=>Math.round(v+(b[i]-v)*k))+')';
const ridge=(x,W,H,base,amp,o,col)=>{x.fillStyle=col;x.beginPath();x.moveTo(0,H);for(let i=0;i<=W;i+=10)x.lineTo(i,base+Math.sin((i+o)/80)*amp+Math.sin((i+o)/33)*amp*.35);x.lineTo(W,H);x.fill()};
const puff=(x,cx,cy,s)=>{x.beginPath();x.arc(cx,cy,18*s,0,6.283);x.arc(cx+18*s,cy-8*s,22*s,0,6.283);x.arc(cx+40*s,cy,17*s,0,6.283);x.fill()};

/* ---- Dino ---- */
function gD3(b,a){
const W=640,H=220,GY=176,c=CV(b,W,H),x=c.getContext('2d'),hi=S.best.dino||0;
let y=0,vy=0,sp=330,sc=0,ob=[],nd=420,fx=[],t=0,dead=0,buf=0,duck=0,sh=0,ph=0,ms=0,ban=0,bt='',bs=0,off=0;
const cl=[[80,36,1],[300,22,.7],[520,44,1.2],[760,30,.9]],st=Array.from({length:40},()=>[R()*W,R()*110,R()*1.5+.4]);
const jump=()=>{buf=.12};
KEYS(a,{Space:jump,ArrowUp:jump,KeyW:jump});
EL(a,document,'keydown',e=>{if(e.code==='ArrowDown'||e.code==='KeyS'){duck=1;e.preventDefault()}});
EL(a,document,'keyup',e=>{if(e.code==='ArrowDown'||e.code==='KeyS')duck=0});
EL(a,b,'pointerdown',e=>{if(e.target.closest('button'))return;e.preventDefault();jump()});
b.insertAdjacentHTML('beforeend','<div class="row" style="margin-top:8px"><button class="btn p" id="dj" style="flex:1;min-height:60px;font-size:20px;touch-action:none">اقفز</button><button class="btn" id="dd" style="flex:1;min-height:60px;font-size:20px;touch-action:none">انحنِ</button></div>');
const dj=b.querySelector('#dj'),dd=b.querySelector('#dd');
EL(a,dj,'pointerdown',e=>{e.preventDefault();jump()});EL(a,dd,'pointerdown',e=>{e.preventDefault();duck=1});
['pointerup','pointercancel','pointerleave'].forEach(n=>EL(a,dd,n,()=>{duck=0}));
b.querySelector('#ei').textContent='Space/↑ قفز · ↓ انحناء · المس للقفز';
const cac=o=>{const w=o.w/o.n;x.fillStyle=mx([46,140,70],[60,220,180],(Math.sin(sc/140-1)+1)/2);for(let k=0;k<o.n;k++){const px=o.x+k*w,h=o.h*(1-(k%2)*.2);rr(x,px+w*.3,GY-h,w*.4,h,w*.2);x.fill();rr(x,px,GY-h*.62,w*.3,w*.22,3);x.fill();rr(x,px,GY-h*.62-w*.5,w*.2,w*.5,3);x.fill();rr(x,px+w*.7,GY-h*.5,w*.3,w*.22,3);x.fill();rr(x,px+w*.8,GY-h*.5-w*.45,w*.2,w*.45,3);x.fill()}};
const bird=o=>{const by=GY-o.hb-o.h/2,f=dead?0:Math.sin(t*18+o.x);x.fillStyle='#ff6b81';x.beginPath();x.ellipse(o.x+20,by,16,8,0,0,6.283);x.fill();x.beginPath();x.moveTo(o.x+4,by);x.lineTo(o.x-8,by-2);x.lineTo(o.x+4,by+5);x.fill();x.fillStyle='#ffd23f';x.beginPath();x.moveTo(o.x+34,by-2);x.lineTo(o.x+44,by+1);x.lineTo(o.x+34,by+4);x.fill();x.fillStyle='#ff9aa8';x.beginPath();x.moveTo(o.x+14,by-3);x.lineTo(o.x+26,by-3);x.lineTo(o.x+18,by-3-f*18);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(o.x+29,by-2,2.5,0,6.283);x.fill();x.fillStyle='#111';x.fillRect(o.x+29,by-3,2,2)};
const dino=()=>{const by=GY-y,dk=duck&&y<=0&&!dead,x0=70,col='#43e6a0',s=dead||y>0?0:Math.sin(ph);x.save();if(QL()>1){x.shadowColor=col;x.shadowBlur=14}x.fillStyle=col;
 if(dk){rr(x,x0+2,by-24,44,20,8);x.fill();rr(x,x0+36,by-30,20,14,6);x.fill();x.beginPath();x.moveTo(x0+2,by-20);x.lineTo(x0-12,by-14);x.lineTo(x0+4,by-10);x.fill()}
 else{rr(x,x0+8,by-36,26,30,9);x.fill();rr(x,x0+22,by-52,26,20,7);x.fill();x.beginPath();x.moveTo(x0+10,by-28);x.lineTo(x0-10,by-14);x.lineTo(x0+10,by-12);x.fill();rr(x,x0+30,by-26,10,5,2);x.fill()}
 x.fillRect(x0+13,by-9-Math.max(0,s)*5,7,9);x.fillRect(x0+25,by-9-Math.max(0,-s)*5,7,9);x.shadowBlur=0;
 const ex=x0+(dk?50:40),ey=by-(dk?24:45);if(dead){x.strokeStyle='#103';x.lineWidth=2;x.beginPath();x.moveTo(ex-3,ey-3);x.lineTo(ex+3,ey+3);x.moveTo(ex+3,ey-3);x.lineTo(ex-3,ey+3);x.stroke()}else{x.fillStyle='#fff';x.beginPath();x.arc(ex,ey,4,0,6.283);x.fill();x.fillStyle='#103';x.fillRect(ex+1,ey-1,3,3)}x.restore()};
LOOP(a,dt=>{
 if(!dead){t+=dt;sp=Math.min(800,330+sc*.5);const d=sp*dt;sc+=d/9;off+=d;nd-=d;ph+=dt*(8+sp/80);buf-=dt;
  cl.forEach(q=>{q[0]-=dt*9*q[2];if(q[0]<-90)q[0]=W+80});
  if(buf>0&&y<=0){vy=780;y=.01;buf=0;sf('jump');fxp(fx,80,GY,6,'#e8d8b0',90,.35,-60)}
  if(y>0||vy>0){vy-=(duck&&y>0?5200:2300)*dt;y+=vy*dt;if(y<=0){y=0;vy=0;fxp(fx,86,GY,5,'#e8d8b0',80,.3,-40)}}else if(R()<.25)fxp(fx,70,GY,1,'#e8d8b0',40,.3,-30);
  if(nd<=0){if(sc>250&&R()<.4)ob.push({t:'b',x:W+30,w:44,h:24,hb:[6,30,70][R()*3|0]});else{const n=1+(R()*(sc>150?3:2)|0);ob.push({t:'c',x:W+30,w:n*(15+R()*5),h:34+R()*22,n})}nd=360+R()*300+sp*.35}
  ob.forEach(o=>o.x-=d);ob=ob.filter(o=>o.x>-80);
  const dk=duck&&y<=0,L=dk?74:78,Rg=dk?118:106,T=y+(dk?24:44);
  if(ob.some(o=>{const lo=o.t==='b'?o.hb+3:0,hi2=o.t==='b'?o.hb+o.h-3:o.h-4;return Rg>o.x+3&&L<o.x+o.w-3&&T>lo&&y<hi2})){dead=1;sh=.5;sf('die');fxp(fx,90,GY-y-20,30,'#43e6a0',320,.9);fxp(fx,90,GY-y-20,12,'#fff',220,.6);a.t(()=>a.end(Math.floor(sc),'اصطدم الديناصور! النقاط '+Math.floor(sc)),900)}
  const m=Math.floor(sc/100);if(m>ms){ms=m;ban=1.3;bt=sc>=250&&!bs?(bs=1,'مرحلة الطيور!'):String(m*100);sf('milestone')}}
 sh=Math.max(0,sh-dt);ban=Math.max(0,ban-dt);fxs(fx,dt);
 const ni=(Math.sin(sc/140-1)+1)/2,g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,mx([86,182,255],[8,6,36],ni));g.addColorStop(1,mx([214,240,255],[70,36,110],ni));x.fillStyle=g;x.fillRect(0,0,W,H);
 x.save();if(sh>0)x.translate((R()-.5)*8,(R()-.5)*8);
 st.forEach(s=>{x.globalAlpha=ni*.9*(.6+.4*Math.sin(t*3+s[0]));x.fillStyle='#fff';x.fillRect(s[0],s[1],s[2],s[2])});x.globalAlpha=1;
 glow(x,560,50,80,ni>.5?'#bcd0ff':'#ffe27a',.8);x.fillStyle=ni>.5?'#e8eeff':'#fff2a8';x.beginPath();x.arc(560,50,18,0,6.283);x.fill();
 x.fillStyle='rgba(255,255,255,'+(.85-ni*.6)+')';cl.forEach(q=>puff(x,q[0],q[1],q[2]*.9));
 ridge(x,W,H,120,18,off*.1,mx([140,175,215],[34,26,76],ni));ridge(x,W,H,150,12,off*.3,mx([92,150,110],[18,44,52],ni));
 x.fillStyle=mx([222,196,140],[60,44,80],ni);x.fillRect(0,GY,W,H-GY);x.fillStyle=mx([160,130,80],[130,90,210],ni);x.fillRect(0,GY,W,3);
 for(let i=0;i<20;i++){const px=((i*97-off)%W+W)%W;x.fillRect(px,GY+10+(i*13%30),10+(i%3)*6,2)}
 ob.forEach(o=>o.t==='c'?cac(o):bird(o));dino();fxd(x,fx);
 x.font='900 18px system-ui';x.textAlign='right';x.fillStyle='#fff';x.shadowColor='#0008';x.shadowBlur=4;x.fillText('HI '+String(Math.max(hi,Math.floor(sc))).padStart(5,'0')+'   '+String(Math.floor(sc)).padStart(5,'0'),W-14,26);
 if(ban>0){x.globalAlpha=Math.min(1,ban*2);x.textAlign='center';x.font='900 30px system-ui';x.fillStyle='#ffe27a';x.fillText(bt,W/2,70)}x.restore()})}

/* ---- Flappy ---- */
function gF3(b,a){
const W=360,H=540,GY=H-56,c=CV(b,W,H),x=c.getContext('2d');
let by=H/2,vy=0,t=0,sc=0,pipes=[],nx=1.3,fx=[],dead=0,go=0,sh=0,off=0,wg=0;const cl=[[40,90,1],[210,140,.7],[310,70,1.2],[130,230,.8]];
const flap=()=>{if(dead)return;go=1;vy=-420;sf('jump');fxp(fx,80,by+8,6,'#fff3b0',90,.4,100)};
EL(a,b,'pointerdown',e=>{if(e.target.closest('button'))return;e.preventDefault();flap()});KEYS(a,{Space:flap,ArrowUp:flap,KeyW:flap});
b.querySelector('#ei').textContent='المس الشاشة في أي مكان للتحليق';
const pp=(px,y0,y1,top)=>{const g=x.createLinearGradient(px,0,px+54,0);g.addColorStop(0,'#3da83d');g.addColorStop(.35,'#9cf08a');g.addColorStop(1,'#2f8f3a');x.fillStyle=g;x.strokeStyle='#1f6b2a';x.lineWidth=2;const cy=top?y1-22:y0;x.fillRect(px,y0,54,y1-y0);x.strokeRect(px,y0,54,y1-y0);x.fillRect(px-4,cy,62,22);x.strokeRect(px-4,cy,62,22)};
LOOP(a,dt=>{t+=dt;sh=Math.max(0,sh-dt);fxs(fx,dt);
 if(!dead){wg+=dt*(go?16:7);const spd=150+Math.min(50,sc*2);off+=spd*dt;cl.forEach(q=>{q[0]-=dt*7*q[2];if(q[0]<-80)q[0]=W+70});
  if(go){vy+=1450*dt;by+=vy*dt;nx-=dt;if(nx<=0){pipes.push({x:W+30,g:158+R()*22,y:110+R()*(GY-330),p:0});nx=1.6}
   pipes.forEach(p=>{p.x-=spd*dt;if(!p.p&&p.x+27<80){p.p=1;sc++;sf('tick');fxp(fx,80,p.y+p.g/2,10,'#ffd23f',130,.5,100)}});pipes=pipes.filter(p=>p.x>-70);
   if(R()<.5)fxp(fx,70,by+4,1,'#ffffff99',30,.35,0);
   if(by>GY-12||by<-10||pipes.some(p=>80+12>p.x&&80-12<p.x+54&&(by-10<p.y||by+10>p.y+p.g))){dead=1;sh=.45;sf('die');fxp(fx,80,by,28,'#ffd23f',270,.9);fxp(fx,80,by,10,'#ff7a1a',200,.7);a.t(()=>a.end(sc,'تحطّم الطائر! مررت '+sc+' أنبوب'),900)}}
  else by=H/2+Math.sin(t*4)*8}
 else{vy+=1450*dt;by=Math.min(GY-10,by+vy*dt)}
 const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#4b7bec');g.addColorStop(.6,'#8ec5fc');g.addColorStop(1,'#ffe6c7');x.fillStyle=g;x.fillRect(0,0,W,H);
 x.save();if(sh>0)x.translate((R()-.5)*9,(R()-.5)*9);
 glow(x,280,150,130,'#fff2a8',.9);x.fillStyle='#fff6bf';x.beginPath();x.arc(280,150,26,0,6.283);x.fill();
 x.fillStyle='rgba(255,255,255,.85)';cl.forEach(q=>puff(x,q[0],q[1],q[2]));
 ridge(x,W,H,GY-90,22,off*.1,'#9ec5e8');ridge(x,W,H,GY-45,16,off*.3,'#6fbf8a');
 pipes.forEach(p=>{pp(p.x,-10,p.y,1);pp(p.x,p.y+p.g,GY,0)});
 x.fillStyle='#ded895';x.fillRect(0,GY,W,H-GY);x.fillStyle='#73bf2e';x.fillRect(0,GY,W,10);x.fillStyle='#8fd14f';for(let i=-1;i<W/24+1;i++)x.fillRect(i*24-(off%24),GY,12,10);
 x.save();x.translate(80,by);x.rotate(Math.max(-.5,Math.min(1.1,vy/600)));x.fillStyle='#ffd23f';x.strokeStyle='#e08a00';x.lineWidth=2;x.beginPath();x.ellipse(0,0,15,11,0,0,6.283);x.fill();x.stroke();
 x.fillStyle='#fff3b0';x.save();x.translate(-4,3);x.rotate(Math.sin(wg)*.8);x.beginPath();x.ellipse(0,0,9,5,0,0,6.283);x.fill();x.restore();
 x.fillStyle='#fff';x.beginPath();x.arc(7,-4,4.5,0,6.283);x.fill();x.fillStyle='#111';x.beginPath();x.arc(8.5,-4,2,0,6.283);x.fill();x.fillStyle='#ff7a1a';x.beginPath();x.moveTo(12,-1);x.lineTo(23,2);x.lineTo(12,6);x.fill();x.restore();
 fxd(x,fx);x.textAlign='center';x.font='900 56px system-ui';x.lineWidth=6;x.strokeStyle='#0006';x.strokeText(sc,W/2,90);x.fillStyle='#fff';x.fillText(sc,W/2,90);
 if(!go){x.globalAlpha=.6+.4*Math.sin(t*5);x.font='800 22px system-ui';x.fillText('المس للبدء',W/2,H/2+70)}x.restore()})}

/* ---- Oasis Guardian ---- */
function gO3(b,a){
const W=360,H=520,c=CV(b,W,H),x=c.getContext('2d');b.style.position='relative';
const WP={sword:{n:'سيف',cd:.4,r:56,d:2},bow:{n:'قوس',cd:.5,r:240,d:1.7},staff:{n:'عصا النار',cd:.95,r:200,d:2.6}};
const ET={sc:{hp:3,v:48,d:1,r:11,c:'#e0522e',g:3},wr:{hp:2,v:86,d:1,r:10,c:'#b06bff',g:4},go:{hp:10,v:32,d:2,r:17,c:'#d4a85a',g:10},kg:{hp:48,v:42,d:2,r:27,c:'#ff2d55',g:80}};
let P={x:W/2,y:H/2+90,hp:6,mh:6,f:{x:0,y:-1},cd:0,dsh:0,dcd:0,inv:0,w:'sword',dm:1,sp:1,gem:20},own={sword:1},U={hp:0,dm:0,sp:0},wave=0,en=[],pr=[],gm=[],fx=[],tx=[],t=0,sh=0,ph='shop',lf=0,sc=0,joy=null,K={},over=0,atk=0,wk=0,sp2=0,fl=0;
const cost=k=>({wbow:45,wstaff:100,hp:25+U.hp*15,dm:35+U.dm*20,sp:30+U.sp*15,heal:15})[k];
const near=()=>{let m=null,d=1e9;en.forEach(e=>{const q=Math.hypot(e.x-P.x,e.y-P.y);if(q<d){d=q;m=e}});return m?[m,d]:null};
const mv=(o,dx,dy)=>{o.x=Math.max(14,Math.min(W-14,o.x+dx));o.y=Math.max(40,Math.min(H-24,o.y+dy))};
const hurt=(e,d,kx,ky)=>{e.hp-=d;e.fl=.12;e.kx=kx||0;e.ky=ky||0;e.kb=.15;tx.push({x:e.x,y:e.y-14,t:.6,s:Math.round(d*10)/10,c:'#ffe27a'});fxp(fx,e.x,e.y,7,'#ffd36b',150,.4);sf('tap');if(e.hp<=0&&!e.dead){e.dead=1;sc+=ET[e.k].g*10;gm.push({x:e.x,y:e.y,v:ET[e.k].g});fxp(fx,e.x,e.y,18,ET[e.k].c,230,.7);sf('pop');sh=Math.max(sh,.15)}};
const fire=()=>{const n=near(),w=WP[P.w];if(!n||P.cd>0||n[1]>w.r)return;const e=n[0],dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy)||1,ux=dx/d,uy=dy/d,dm=w.d*P.dm;P.f={x:ux,y:uy};P.cd=w.cd;
 if(P.w==='sword'){atk=.2;sf('tap');en.forEach(q=>{const ex=q.x-P.x,ey=q.y-P.y,dd=Math.hypot(ex,ey);if(dd<w.r+ET[q.k].r&&(ex*ux+ey*uy)/(dd||1)>-.2)hurt(q,dm,ex/dd*220,ey/dd*220)});fxp(fx,P.x+ux*30,P.y+uy*30,6,'#e8f2ff',140,.3)}
 else{const v=P.w==='bow'?460:270;pr.push({x:P.x+ux*14,y:P.y+uy*14,vx:ux*v,vy:uy*v,l:1.2,d:dm,f:P.w==='staff'});sf(P.w==='staff'?'milestone':'jump')}};
const dash=()=>{if(P.dcd>0||ph!=='play'||over)return;P.dsh=.17;P.dcd=1.1;P.inv=Math.max(P.inv,.3);sf('jump');fxp(fx,P.x,P.y+8,10,'#ffe7a8',120,.4)};
const swv=()=>{wave++;lf=4+wave*3;ph='play';sp2=0;const o=b.querySelector('#shp');if(o)o.remove();tx.push({x:W/2,y:H/2,t:1.4,s:'الموجة '+wave,c:'#fff',big:1});sf('milestone')};
const spawnE=()=>{const s=R()*4|0,x0=s==0?-10:s==1?W+10:R()*W,y0=s==2?30:s==3?H+10:40+R()*(H-60);let k='sc';if(wave===8&&lf===1)k='kg';else{const r=R();if(wave>=5&&r<.2)k='go';else if(wave>=3&&r<.5)k='wr'}en.push({x:x0,y:y0,k,hp:ET[k].hp*(1+wave*.06),kb:0,fl:0,ph:R()*6});lf--};
const shop=()=>{ph='shop';const o0=b.querySelector('#shp');if(o0)o0.remove();
 const B=(k,n,dis)=>`<button class="btn" data-s="${k}" ${dis||P.gem<cost(k)?'disabled':''} style="flex:1 1 45%;margin:3px">${n} · ${cost(k)} 💎</button>`;
 const wb=['sword','bow','staff'].map(k=>own[k]?`<button class="btn ${P.w===k?'p':''}" data-e="${k}" style="flex:1;margin:3px">${WP[k].n}</button>`:B('w'+k,WP[k].n)).join('');
 b.insertAdjacentHTML('beforeend',`<div id="shp" style="position:absolute;inset:0;background:#0b0816ee;border-radius:14px;padding:12px;overflow:auto;text-align:center"><div class="big sm">متجر الواحة</div><div class="info">الجواهر: <b>${P.gem}</b> · الموجة القادمة ${wave+1}/8</div><div class="row" style="flex-wrap:wrap">${wb}</div><div class="row" style="flex-wrap:wrap">${B('hp','قلب إضافي')}${B('dm','قوة +20%')}${B('sp','سرعة +10%')}${B('heal','علاج كامل',P.hp>=P.mh)}</div><button class="btn p" data-s="go" style="width:100%;margin-top:8px;min-height:54px;font-size:20px">ابدأ الموجة</button></div>`)};
EL(a,b,'click',e=>{const t2=e.target.closest('[data-s],[data-e]');if(!t2)return;if(t2.dataset.e){P.w=t2.dataset.e;shop();return}const k=t2.dataset.s;if(k==='go'){swv();return}const cs=cost(k);if(P.gem<cs)return;P.gem-=cs;sf('ok');
 if(k[0]==='w'&&k.length>2){own[k.slice(1)]=1;P.w=k.slice(1)}else if(k==='hp'){U.hp++;P.mh++;P.hp++}else if(k==='dm'){U.dm++;P.dm+=.2}else if(k==='sp'){U.sp++;P.sp+=.1}else if(k==='heal')P.hp=P.mh;shop()});
b.insertAdjacentHTML('beforeend','<button class="btn p" id="od" style="width:100%;margin-top:8px;min-height:56px;font-size:20px;touch-action:none">اندفاع</button>');
EL(a,b.querySelector('#od'),'pointerdown',e=>{e.preventDefault();dash()});
KEYS(a,{Space:dash,ShiftLeft:dash});EL(a,document,'keydown',e=>{K[e.code]=1;if(e.code.startsWith('Arrow'))e.preventDefault()});EL(a,document,'keyup',e=>{K[e.code]=0});
EL(a,c,'pointerdown',e=>{e.preventDefault();const r=c.getBoundingClientRect();joy={ox:e.clientX,oy:e.clientY,dx:0,dy:0,sx:(e.clientX-r.left)*W/r.width,sy:(e.clientY-r.top)*H/r.height}});
EL(a,c,'pointermove',e=>{if(!joy)return;let dx=e.clientX-joy.ox,dy=e.clientY-joy.oy;const d=Math.hypot(dx,dy),m=40;if(d>m){dx*=m/d;dy*=m/d}joy.dx=dx/m;joy.dy=dy/m});
['pointerup','pointercancel'].forEach(n=>EL(a,c,n,()=>{joy=null}));
b.querySelector('#ei').textContent='اسحب للتحرك · الهجوم تلقائي · اندفاع للهروب';
const palm=(px,py,s)=>{x.strokeStyle='#7a4e22';x.lineWidth=6*s;x.beginPath();x.moveTo(px,py);x.quadraticCurveTo(px+10*s,py-30*s,px+4*s,py-60*s);x.stroke();x.strokeStyle='#2fa84f';x.lineWidth=4*s;for(let k=0;k<6;k++){const an=-Math.PI/2+(k-2.5)*.55+Math.sin(t*1.5+k)*.05;x.beginPath();x.moveTo(px+4*s,py-60*s);x.quadraticCurveTo(px+4*s+Math.cos(an)*28*s,py-60*s+Math.sin(an)*28*s-8*s,px+4*s+Math.cos(an)*46*s,py-60*s+Math.sin(an)*40*s+14*s);x.stroke()}};
const mon=e=>{const T=ET[e.k],r=T.r,ang=Math.atan2(P.y-e.y,P.x-e.x)+Math.PI/2,wl=Math.sin(t*14+e.ph);x.save();x.translate(e.x,e.y);x.fillStyle='#0004';x.beginPath();x.ellipse(0,r*.8,r,r*.4,0,0,6.283);x.fill();x.rotate(ang);if(e.k==='wr')x.globalAlpha=.8;
 const col=e.fl>0?'#fff':T.c;x.strokeStyle=col;x.lineWidth=2;
 if(e.k==='sc'||e.k==='kg'){for(let s=-1;s<=1;s+=2)for(let k=0;k<3;k++){x.beginPath();x.moveTo(0,-r*.3+k*r*.5);x.lineTo(s*r*1.3,-r*.1+k*r*.5+wl*s*2);x.stroke()}x.beginPath();x.moveTo(0,r*.6);x.bezierCurveTo(-r*1.2,r*1.6,-r*1.2,r*2.4+wl*2,0,r*2.2);x.lineWidth=r*.3;x.stroke();x.lineWidth=2;x.fillStyle=col;x.beginPath();x.arc(s0(r),r*2.2,r*.25,0,6.283);x.fill()}
 x.fillStyle=col;if(e.k==='go'||e.k==='kg'){rr(x,-r,-r,r*2,r*2,r*.4);x.fill()}else{x.beginPath();x.ellipse(0,0,r*.8,r,0,0,6.283);x.fill()}
 if(e.k==='sc'||e.k==='kg'){for(let s=-1;s<=1;s+=2){x.beginPath();x.arc(s*r*.9,-r*1.1,r*.45,0,6.283);x.fill()}}
 x.fillStyle='#ff2d2d';x.fillRect(-r*.4,-r*.6,3,3);x.fillRect(r*.4-3,-r*.6,3,3);x.restore();glow(x,e.x,e.y,r*2.2,T.c,.25)};
const s0=r=>0;
const guard=()=>{const bob=Math.sin(wk)*1.6,fa=Math.atan2(P.f.y,P.f.x);x.save();x.translate(P.x,P.y);x.fillStyle='#0004';x.beginPath();x.ellipse(0,13,12,4.5,0,0,6.283);x.fill();x.translate(0,bob);
 x.fillStyle='#c0392b';x.beginPath();x.moveTo(-8,-6);x.lineTo(8,-6);x.lineTo(10+Math.sin(wk)*3-P.f.x*6,15);x.lineTo(-10-Math.sin(wk)*3-P.f.x*6,15);x.fill();
 x.fillStyle='#2f6bff';rr(x,-8,-8,16,20,5);x.fill();x.fillStyle='#ffd23f';x.fillRect(-8,2,16,3);
 x.fillStyle='#f2c08f';x.beginPath();x.arc(0,-14,7,0,6.283);x.fill();x.fillStyle='#f7f1e3';x.beginPath();x.arc(0,-17,7.5,Math.PI,0);x.fill();x.fillStyle='#ffd23f';x.beginPath();x.arc(0,-20,2,0,6.283);x.fill();
 x.fillStyle='#222';x.fillRect(-3+P.f.x*2,-14+P.f.y*1.5,2,2.5);x.fillRect(2+P.f.x*2,-14+P.f.y*1.5,2,2.5);
 x.rotate(fa+(atk>0?(atk/.2-.5)*2.4:0));x.translate(10,0);
 if(P.w==='sword'){x.fillStyle='#e6f0ff';x.fillRect(0,-1.5,22,3);x.fillStyle='#8a5a2b';x.fillRect(-3,-3,5,6);glow(x,18,0,18,'#9fd0ff',.5)}
 else if(P.w==='bow'){x.strokeStyle='#c28b55';x.lineWidth=2.5;x.beginPath();x.arc(4,0,12,-1.2,1.2);x.stroke()}
 else{x.strokeStyle='#8a5a2b';x.lineWidth=3;x.beginPath();x.moveTo(-4,0);x.lineTo(20,0);x.stroke();x.fillStyle='#ff7a1a';x.beginPath();x.arc(22,0,4.5,0,6.283);x.fill();glow(x,22,0,26,'#ff8a2a',.8)}
 if(atk>0&&P.w==='sword'){x.strokeStyle='#fff';x.globalAlpha=atk/.2;x.lineWidth=4;x.beginPath();x.arc(-10,0,34,-.9,.9);x.stroke()}x.restore()};
LOOP(a,dt=>{t+=dt;sh=Math.max(0,sh-dt);fl=Math.max(0,fl-dt);atk=Math.max(0,atk-dt);P.cd-=dt;P.dcd-=dt;P.inv=Math.max(0,P.inv-dt);P.dsh=Math.max(0,P.dsh-dt);
 if(ph==='play'&&!over){
  let ax=(K.ArrowRight||K.KeyD?1:0)-(K.ArrowLeft||K.KeyA?1:0),ay=(K.ArrowDown||K.KeyS?1:0)-(K.ArrowUp||K.KeyW?1:0);if(joy){ax=joy.dx;ay=joy.dy}
  const m=Math.hypot(ax,ay);
  if(P.dsh>0){mv(P,P.f.x*330*dt,P.f.y*330*dt);if(R()<.7)fxp(fx,P.x,P.y+8,1,'#ffe7a8',40,.4)}
  else if(m>.12){const k=Math.min(1,m)/m;ax*=k;ay*=k;mv(P,ax*105*P.sp*dt,ay*105*P.sp*dt);if(!near())P.f={x:ax/Math.hypot(ax,ay),y:ay/Math.hypot(ax,ay)};wk+=dt*10;if(R()<.3)fxp(fx,P.x,P.y+12,1,'#e8d29a',30,.4,-20)}
  fire();sp2-=dt;if(lf>0&&sp2<=0){spawnE();sp2=Math.max(.35,1.1-wave*.08)}
  en.forEach(e=>{e.fl=Math.max(0,e.fl-dt);const T=ET[e.k];if(e.kb>0){e.kb-=dt;e.x+=e.kx*dt;e.y+=e.ky*dt}else{const dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy)||1,v=T.v*(1+wave*.03);e.x+=dx/d*v*dt;e.y+=dy/d*v*dt;if(d<T.r+10&&P.inv<=0){P.hp-=T.d;P.inv=1;sh=.35;fl=.3;sf('bad');fxp(fx,P.x,P.y,16,'#ff3b5c',200,.6);if(P.hp<=0){over=1;a.t(()=>a.end(sc,'سقط الحارس في الموجة '+wave),900)}}}});
  pr.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.l-=dt;if(q.f&&R()<.8)fxp(fx,q.x,q.y,1,'#ff8a2a',40,.35,-30);for(const e of en){if(q.l<=0)break;if(Math.hypot(e.x-q.x,e.y-q.y)<ET[e.k].r+5){q.l=0;if(q.f){fxp(fx,q.x,q.y,26,'#ff8a2a',260,.6);fxp(fx,q.x,q.y,10,'#ffe27a',200,.5);sh=Math.max(sh,.12);sf('pop');en.forEach(z=>{if(Math.hypot(z.x-q.x,z.y-q.y)<48)hurt(z,q.d,(z.x-q.x)*3,(z.y-q.y)*3)})}else hurt(e,q.d,q.vx*.2,q.vy*.2)}}});
  pr=pr.filter(q=>q.l>0&&q.x>-10&&q.x<W+10&&q.y>-10&&q.y<H+10);en=en.filter(e=>!e.dead);
  gm=gm.filter(g=>{const d=Math.hypot(P.x-g.x,P.y-g.y);if(d<70){g.x+=(P.x-g.x)/d*220*dt;g.y+=(P.y-g.y)/d*220*dt}if(d<16){P.gem+=g.v;sc+=g.v;sf('ok');fxp(fx,g.x,g.y,8,'#3df2ff',140,.4);return false}return true});
  if(lf<=0&&!en.length&&!over){if(wave>=8){over=1;sf('win');a.t(()=>a.end(sc+P.hp*50,'حرست الواحة! أنهيت 8 موجات'),900)}else{P.gem+=5+wave*2;sf('win');fxp(fx,P.x,P.y,30,'#ffd23f',260,.9);shop()}}}
 fxs(fx,dt);tx.forEach(q=>{q.t-=dt;q.y-=30*dt});tx=tx.filter(q=>q.t>0);
 x.save();if(sh>0)x.translate((R()-.5)*10,(R()-.5)*10);
 const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#f6d68f');g.addColorStop(1,'#d99a52');x.fillStyle=g;x.fillRect(-10,-10,W+20,H+20);
 x.fillStyle='rgba(160,90,40,.16)';for(let i=0;i<5;i++){x.beginPath();x.ellipse((i*97+40)%W,100+i*95,120,26,0,0,6.283);x.fill()}
 x.fillStyle='#4fa84a';x.beginPath();x.ellipse(W/2,170,96,50,0,0,6.283);x.fill();const wg=x.createLinearGradient(0,140,0,200);wg.addColorStop(0,'#5fe6ff');wg.addColorStop(1,'#1380b0');x.fillStyle=wg;x.beginPath();x.ellipse(W/2,172,70,34,0,0,6.283);x.fill();
 x.strokeStyle='#ffffff88';x.lineWidth=1.5;x.beginPath();x.ellipse(W/2,172,20+(t*18)%40,8+(t*8)%16,0,0,6.283);x.stroke();
 palm(W/2-60,160,1);palm(W/2+64,158,.85);
 x.fillStyle='rgba(255,255,255,.22)';for(let i=0;i<10;i++)x.fillRect((t*70*(1+i*.1)+i*83)%(W+60)-30,60+i*44,24,2);
 gm.forEach(q=>{glow(x,q.x,q.y,24,'#3df2ff',.8);x.fillStyle='#7ef3ff';x.beginPath();x.moveTo(q.x,q.y-7+Math.sin(t*5)*1.5);x.lineTo(q.x+5,q.y);x.lineTo(q.x,q.y+7);x.lineTo(q.x-5,q.y);x.fill()});
 const L=[...en.map(e=>[e.y,0,e]),[P.y,1]].sort((p,q)=>p[0]-q[0]);L.forEach(o=>{if(o[1]){if(P.inv<=0||Math.floor(t*20)%2)guard()}else mon(o[2])});
 pr.forEach(q=>{glow(x,q.x,q.y,q.f?22:12,q.f?'#ff8a2a':'#fff2a8',.9);x.fillStyle=q.f?'#ffd36b':'#fff';x.beginPath();x.arc(q.x,q.y,q.f?5:2.5,0,6.283);x.fill()});
 fxd(x,fx);tx.forEach(q=>{x.globalAlpha=Math.min(1,q.t*2);x.textAlign='center';x.font=(q.big?'900 34px':'800 13px')+' system-ui';x.fillStyle=q.c;x.fillText(q.s,q.x,q.y)});x.globalAlpha=1;
 if(joy){x.strokeStyle='#ffffff60';x.lineWidth=2;x.beginPath();x.arc(joy.sx,joy.sy,34,0,6.283);x.stroke();x.fillStyle='#ffffff50';x.beginPath();x.arc(joy.sx+joy.dx*34,joy.sy+joy.dy*34,14,0,6.283);x.fill()}
 if(fl>0){x.fillStyle='rgba(255,40,70,'+fl*.5+')';x.fillRect(0,0,W,H)}
 x.font='900 16px system-ui';x.textAlign='left';for(let i=0;i<P.mh;i++){x.fillStyle=i<P.hp?'#ff3b5c':'#ffffff40';x.fillText('♥',12+i*17,26)}
 x.textAlign='right';x.fillStyle='#2b1a08';x.fillText('الموجة '+wave+'/8 · '+WP[P.w].n,W-12,26);x.fillStyle='#075a73';x.fillText('◆ '+P.gem,W-12,46);x.restore()});
shop()}

/* ---- Visual polish (CSS only) ---- */
const cs=document.createElement('style');cs.textContent=`
:where(#gb) .btn{background:linear-gradient(180deg,#ffffff1c,#ffffff08);box-shadow:0 3px 0 #0006,inset 0 1px 0 #ffffff22;transition:transform .1s,box-shadow .1s,filter .15s}
:where(#gb) .btn:active{transform:translateY(2px) scale(.98);box-shadow:0 1px 0 #0006}
:where(#gb) .btn.p{box-shadow:0 4px 0 #0005,0 8px 22px color-mix(in srgb,var(--p) 40%,transparent),inset 0 1px 0 #fff6}
:where(#gb) .cell{background:linear-gradient(160deg,#ffffff1e,#ffffff08);border-radius:14px;box-shadow:inset 0 -3px 6px #0004,0 3px 8px #0003}
:where(#gb) .card{background:linear-gradient(160deg,#ffffff12,#ffffff05),var(--card);box-shadow:0 8px 24px #0004}
:where(#gb) .c4{background:linear-gradient(160deg,#2450c8,#112a78);box-shadow:inset 0 4px 10px #fff3,inset 0 -6px 12px #0006,0 10px 26px #0005}
:where(#gb) .c4c{box-shadow:inset 0 5px 8px #0007,inset 0 -3px 5px #fff2}
:where(#gb) .orb{background:radial-gradient(circle at 35% 30%,#ffffff30,var(--card) 60%);box-shadow:0 0 0 6px color-mix(in srgb,var(--p) 18%,transparent),0 0 38px color-mix(in srgb,var(--p) 45%,transparent)}
:where(#gb) .arena{background:radial-gradient(circle at 50% 40%,#ffffff12,#0007);box-shadow:inset 0 0 40px #0008}
:where(#gb) .tgt{background:radial-gradient(circle at 35% 30%,#fff9,var(--p) 55%,var(--p2));box-shadow:0 6px 14px #0006,0 0 20px color-mix(in srgb,var(--p) 50%,transparent)}
:where(#gb) .big{text-shadow:0 0 22px color-mix(in srgb,var(--p) 55%,transparent),0 3px 0 #0005}
:where(#gb) .res{font-size:22px;text-shadow:0 0 18px color-mix(in srgb,var(--p2) 50%,transparent)}
:where(#gb) input,:where(#gb) select{background:#0003;border:1px solid var(--line);border-radius:12px;padding:10px 12px;outline:none}
:where(#gb) input:focus,:where(#gb) select:focus{border-color:var(--p);box-shadow:0 0 0 3px color-mix(in srgb,var(--p) 30%,transparent)}
html.q2 #gb canvas{box-shadow:0 12px 44px color-mix(in srgb,var(--p) 28%,transparent),0 0 0 1px var(--line);filter:saturate(1.15) contrast(1.05)}
html.q2 #gv{background-image:radial-gradient(circle at 50% 0,color-mix(in srgb,var(--p) 14%,transparent),transparent 60%)}
html.q0 :where(#gb) .btn,html.q0 :where(#gb) .card{box-shadow:none}`;
document.head.appendChild(cs);
const qcls=()=>{const h=document.documentElement;h.classList.remove('q0','q1','q2');h.classList.add('q'+QL())};qcls();

/* ---- Intro (loading screen, no text, own sound) ---- */
function intro(){if(document.getElementById('ams-intro'))return;
 const q=QL(),W=innerWidth,H=innerHeight,r=q>1?1:.75,c=document.createElement('canvas');
 c.id='ams-intro';c.width=W*r|0;c.height=H*r|0;c.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:99999;background:#05030f;touch-action:none';
 document.body.appendChild(c);const x=c.getContext('2d'),cx=W/2,cy=H/2,IM=1.0,END=2.2,PUL=[.25,.6,.9];
 let T0=performance.now(),lt=T0,done=0,snd=0,tp=0,hit=0,fl=0,shk=0,pt=[],ac=null,mg=null;
 const stars=Array.from({length:q?50:30},()=>({a:R()*6.283,d:.1+R()*.9,z:R()}));
 try{const AC=window.AudioContext||window.webkitAudioContext;ac=new AC();mg=ac.createGain();mg.gain.value=.9;const cp=ac.createDynamicsCompressor();mg.connect(cp);cp.connect(ac.destination)}catch(e){ac=null}
 const T=(f,d,ty,at,v,to,lp)=>{const t=ac.currentTime+at,o=ac.createOscillator(),g=ac.createGain(),fi=ac.createBiquadFilter();o.type=ty;o.frequency.setValueAtTime(f,t);if(to)o.frequency.exponentialRampToValueAtTime(to,t+d);fi.type='lowpass';fi.frequency.value=lp||3000;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+Math.min(.02,d/4));g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(fi);fi.connect(g);g.connect(mg);o.start(t);o.stop(t+d+.05)};
 const N=(d,at,v,f0,f1)=>{const t=ac.currentTime+at,n=Math.max(1,ac.sampleRate*d|0),bf=ac.createBuffer(1,n,ac.sampleRate),ch=bf.getChannelData(0);for(let i=0;i<n;i++)ch[i]=R()*2-1;const s=ac.createBufferSource(),fi=ac.createBiquadFilter(),g=ac.createGain();s.buffer=bf;fi.type='bandpass';fi.frequency.setValueAtTime(f0,t);fi.frequency.exponentialRampToValueAtTime(f1,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(fi);fi.connect(g);g.connect(mg);s.start(t)};
 const sound=()=>{try{T(110,.4,'sawtooth',0,.12,0,2000);T(220,.5,'sawtooth',.4,.14,0,2500);N(.4,.45,.2,400,3000);T(45,.7,'sine',IM,.7,22);[523,659,784,1046].forEach((f,i)=>T(f,.6,'triangle',IM+i*.05,.12))}catch(e){}};const sound_old=()=>{try{
  for(let i=0;i<8;i++){T(110*Math.pow(1.22,i),.3,'sawtooth',i*.33,.12+i*.035,0,2600);N(.3,i*.33,.06+i*.035,500+i*700,900+i*900)}
  PUL.forEach(s=>T(58,.22,'sine',s,.6,30));
  for(let i=0;i<12;i++)T(600+i*95,.05,'square',.2+i*.17,.08,0,5000);
  T(45,1.1,'sine',IM,.8,22);N(.9,IM,.45,6000,200);
  [262,330,392,523,659,784].forEach((f,i)=>T(f,.9,'sawtooth',IM+.04+i*.06,.14,0,3000));
  T(131,2.6,'sawtooth',IM,.12,0,900);T(196,2.6,'sawtooth',IM,.09,0,900);
  [[1046,3.4],[1568,3.55],[2093,3.7]].forEach(([f,s],i)=>{T(f,1.3,'sine',s,.18-i*.03);T(f*2.01,.8,'sine',s,.05)})}catch(e){}};
 const go=()=>{if(snd||done||!ac||ac.state!=='running')return;snd=1;T0=performance.now();hit=0;pt=[];sound()};
 const un=()=>{if(!ac)return;try{ac.resume().then(()=>setTimeout(go,30)).catch(()=>{})}catch(e){}};
 const kd=()=>{if(snd||!ac)end();else un()};
 const end=()=>{if(done)return;done=1;c.remove();removeEventListener('keydown',kd);if(ac){try{mg.gain.setTargetAtTime(0,ac.currentTime,.06)}catch(e){}setTimeout(()=>{try{ac.close()}catch(e){}},400)}};
 addEventListener('keydown',kd);c.addEventListener('pointerdown',()=>{if(!snd&&ac&&!tp){tp=1;un()}else end()});
 un();
 const draw=()=>{if(done)return;const now=performance.now(),dt=Math.min(.05,(now-lt)/1000);lt=now;if(!snd)go();const t=(now-T0)/1000,post=t>=IM;
  x.setTransform(r,0,0,r,0,0);
  if(post&&!hit){hit=1;fl=1;shk=.6;for(let i=0;i<40*PM();i++){const an=R()*6.283,v=150+R()*520;pt.push({x:cx,y:cy,vx:Math.cos(an)*v,vy:Math.sin(an)*v,l:.8+R()*.8,m:1.4,h:R()*360})}}
  x.fillStyle='rgba(5,3,15,'+(post?.45:.3)+')';x.fillRect(0,0,W,H);
  const sp=post?.7:.25+Math.pow(Math.min(1,t/IM),2.4)*3.2,mn=Math.min(W,H)*.06;
  x.save();if(shk>0)x.translate((R()-.5)*shk*30,(R()-.5)*shk*30);x.globalCompositeOperation='lighter';
  stars.forEach(s=>{const z0=s.z;s.z-=dt*sp*.45;if(s.z<=.03){s.z=1;s.a=R()*6.283;s.d=.1+R()*.9}const a0=mn*s.d/(z0+.05),a1=mn*s.d/(s.z+.05),co=Math.cos(s.a),si=Math.sin(s.a);x.strokeStyle='hsla('+(220+s.d*120)+',90%,70%,'+Math.min(1,(1-s.z)*1.4)+')';x.lineWidth=.6+(1-s.z)*2.2;x.beginPath();x.moveTo(cx+co*a0,cy+si*a0);x.lineTo(cx+co*a1,cy+si*a1);x.stroke()});
  PUL.forEach(s=>{const d=t-s;if(d>0&&d<.55){x.globalAlpha=1-d/.55;x.strokeStyle='#7c5cff';x.lineWidth=3;x.beginPath();x.arc(cx,cy,30+d*260,0,6.283);x.stroke()}});
  const rd=Math.min(170,70+t*22),g2=x.createRadialGradient(cx,cy,0,cx,cy,rd);g2.addColorStop(0,'#fff');g2.addColorStop(.3,'#8a5cff');g2.addColorStop(1,'transparent');x.globalAlpha=.4+.4*Math.min(1,t/IM);x.fillStyle=g2;x.fillRect(cx-rd,cy-rd,rd*2,rd*2);
  pt.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.97;p.vy*=.97;p.l-=dt;x.globalAlpha=Math.max(0,p.l/p.m);x.fillStyle='hsl('+p.h+',90%,65%)';x.fillRect(p.x,p.y,3,3)});pt=pt.filter(p=>p.l>0);
  x.globalAlpha=1;
  if(post){const u=t-IM,e=Math.min(1,u*3),R0=Math.min(W,H)*.16*(.5+.5*e);x.save();x.translate(cx,cy);x.globalAlpha=e;for(let i=0;i<3;i++){x.rotate(u*(i%2?-1:1)*(.8+i*.4));x.strokeStyle=['#2de2ff','#a66cff','#ff5fa2'][i];x.lineWidth=4-i;x.beginPath();x.arc(0,0,R0*(1+i*.28),0,4.2);x.stroke()}x.fillStyle='#fff';x.beginPath();for(let k=0;k<10;k++){const a=k*Math.PI/5-Math.PI/2,rr2=k%2?R0*.28:R0*.62;x.lineTo(Math.cos(a)*rr2,Math.sin(a)*rr2)}x.closePath();x.fill();x.restore()}
  x.globalCompositeOperation='source-over';
  if(!post){const e=1-Math.pow(1-Math.min(1,t/(IM-.1)),2),bw=W*.7,bx=cx-bw/2,by=H*.78;x.fillStyle='#ffffff22';rr(x,bx,by,bw,10,5);x.fill();const gg=x.createLinearGradient(bx,0,bx+bw,0);gg.addColorStop(0,'#2de2ff');gg.addColorStop(1,'#a66cff');x.fillStyle=gg;rr(x,bx,by,Math.max(10,bw*e),10,5);x.fill()}
  x.restore();
  if(fl>0){x.fillStyle='rgba(255,255,255,'+fl+')';x.fillRect(0,0,W,H)}
  
  if(t>END-.7){x.fillStyle='rgba(5,3,15,'+Math.min(1,(t-END+.7)/.6)+')';x.fillRect(0,0,W,H)}
  shk=Math.max(0,shk-dt*1.2);fl=Math.max(0,fl-dt*2.2);
  if(t>END){end();return}requestAnimationFrame(draw)};
 requestAnimationFrame(draw)}

/* ---- settings: performance mode ---- */
new MutationObserver(()=>{const d=document.getElementById('det'),bx=d&&d.firstElementChild;if(!bx||!/Settings/.test(bx.textContent)||bx.querySelector('.pm'))return;const h=bx.querySelector('[data-setting="xpanel"]');if(!h)return;const cu=QL(),B=(k,n,v)=>`<button class="btn ${cu===v?'p':''}" data-pm="${k}" style="flex:1">${n}</button>`;
 h.insertAdjacentHTML('beforebegin',`<label>وضع الأداء (للألعاب والخلفية)</label><div class="row pm">${B('l','أداء ⚡',0)}${B('m','متوسط',1)}${B('h','جودة عالية',2)}</div><button class="btn" data-pm="in" style="width:100%;margin:6px 0">▶ تشغيل الانترو</button>`);
 bx.addEventListener('click',e=>{const t2=e.target.closest('[data-pm]');if(!t2)return;const k=t2.dataset.pm;if(k==='in'){d.hidden=true;intro();return}XS.perf=k==='l'?1:0;XS.q=k==='h'?2:k==='m'?1:0;XS.part=1;xsave();qcls();bx.querySelectorAll('.pm button').forEach(q=>q.classList.toggle('p',q===t2));sf('tap')})}).observe(document.getElementById('det'),{childList:true,subtree:true});
const set=(id,f,d)=>{const g=G.find(q=>q.id===id);if(g){g.run=f;if(d)g.d=d}};
set('dino',gD3,'ديناصور نيون: ليل ونهار، صبار، مرحلة طيور، انحناء وسرعة متزايدة.');
set('flappy',gF3,'طائر بحركة ناعمة، سحب بطيئة، تلال متحركة وأنابيب مصقولة.');
set('oasis',gO3,'حارس بشخصية متحركة: 8 موجات، سيف وقوس وعصا نار، متجر وترقيات وجسيمات.');
{const g=G.find(q=>q.id==='oasis');if(g)g.r='اسحب للتحرك، الهجوم تلقائي على أقرب عدو. اجمع الجواهر، اشترِ الأسلحة والترقيات بين الموجات، واستخدم الاندفاع للهروب.'}
setTimeout(()=>{try{if(sessionStorage.getItem('ams-i'))return;sessionStorage.setItem('ams-i','1');intro()}catch(e){}},250);
})();

/* ===== V6 patch: whack / tower defense / wild survival / card particles / no-select ===== */
(()=>{
const sx=n=>{try{(SFX[n]||SFX.tap||SFX.click)()}catch(e){}};
const FONT='Cairo,system-ui,sans-serif';
const LP=(a,f)=>{let id,l=performance.now(),on=1;const r=n=>{if(!on)return;f(Math.min(.05,(n-l)/1000));l=n;id=requestAnimationFrame(r)};id=requestAnimationFrame(r);const st=()=>{on=0;cancelAnimationFrame(id)};a.cu.push(st);return st};
const pw=(fx,x,y,n,c,sp=160,l=.6,g=260)=>{for(let i=0;i<n;i++){const an=Math.random()*6.283,v=sp*(.3+Math.random()),L=l*(.5+Math.random());fx.push({x,y,vx:Math.cos(an)*v,vy:Math.sin(an)*v,l:L,m:L,c,s:1.5+Math.random()*3,g})}};
const fs=(fx,dt)=>{for(let i=fx.length;i--;){const p=fx[i];p.l-=dt;if(p.l<=0){fx.splice(i,1);continue}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=(p.g==null?260:p.g)*dt}};
const fd=(x,fx)=>{fx.forEach(p=>{x.globalAlpha=Math.max(0,p.l/p.m);x.fillStyle=p.c;x.beginPath();x.arc(p.x,p.y,p.s,0,6.283);x.fill()});x.globalAlpha=1};
const rr=(x,a,b,w,h,r)=>{x.beginPath();x.moveTo(a+r,b);x.arcTo(a+w,b,a+w,b+h,r);x.arcTo(a+w,b+h,a,b+h,r);x.arcTo(a,b+h,a,b,r);x.arcTo(a,b,a+w,b,r);x.closePath()};
const ptr=(c,e,W,H)=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height]};
const cl=(v,a,b)=>Math.max(a,Math.min(b,v));

/* ---------- no text selection in the UI + lighter canvases ---------- */
const css=document.createElement('style');
css.textContent='body,.app,#gv,nav,header{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}input,textarea,select,[contenteditable="true"]{-webkit-user-select:text;user-select:text}html #gb canvas,html.q2 #gb canvas{filter:none!important;box-shadow:none!important}#gb .btn:disabled{opacity:.45}img,svg{-webkit-user-drag:none}';
document.head.appendChild(css);
addEventListener('selectstart',e=>{const n=e.target&&e.target.nodeType===1?e.target:e.target&&e.target.parentElement;if(n&&n.closest&&n.closest('input,textarea,[contenteditable="true"]'))return;e.preventDefault()},true);
addEventListener('contextmenu',e=>{const n=e.target;if(n&&n.closest&&n.closest('.gc,#gv,nav,header'))e.preventDefault()});

/* ---------- V7 global look (applies to every game + library) ---------- */
const c7=document.createElement('style');
c7.textContent=`
html #gv{background:radial-gradient(ellipse at 50% 0,color-mix(in srgb,var(--p) 20%,transparent),transparent 62%),var(--bg);border:1px solid color-mix(in srgb,var(--p) 70%,transparent);box-shadow:0 0 0 1px #000,0 18px 60px #000a,0 0 50px var(--glow)}
html #ghd{background:linear-gradient(180deg,#ffffff16,#ffffff05),var(--card);border-bottom:1px solid var(--line);box-shadow:0 4px 14px #0005}
html #gt{font-weight:900;text-shadow:0 0 14px var(--glow)}
html #gb{background:radial-gradient(circle at 50% 0,#ffffff0a,transparent 60%)}
html #gb .btn{border-radius:14px;border:1px solid color-mix(in srgb,var(--p) 30%,var(--line));background:linear-gradient(180deg,#ffffff26,#ffffff08);box-shadow:0 3px 0 #0007,0 6px 14px #0003,inset 0 1px 0 #ffffff30}
html #gb .btn.p{background:linear-gradient(135deg,var(--p),var(--p2));border:0;box-shadow:0 4px 0 color-mix(in srgb,var(--p) 40%,#000),0 8px 22px color-mix(in srgb,var(--p) 40%,transparent),inset 0 1px 0 #fff8}
html #gb .btn.good{background:linear-gradient(180deg,#2fbf75,#1c7a4a)}
html #gb .btn.danger{background:linear-gradient(180deg,#e0475c,#8f1f33)}
html #gb .btn:active{transform:translateY(3px);box-shadow:0 0 0 #0007}
html #gb .info{background:#ffffff0c;border:1px solid var(--line);border-radius:14px;padding:6px 14px}
html #gb canvas{border-radius:18px!important;border:2px solid color-mix(in srgb,var(--p) 55%,var(--line))!important;outline:3px solid #0006}
html #gb .card,html #gb .team,html #gb .box{background:linear-gradient(160deg,#ffffff14,#ffffff05),var(--card);border-radius:18px;box-shadow:0 8px 22px #0004,inset 0 1px 0 #ffffff14}
html #gb .cell{background:linear-gradient(160deg,#ffffff26,#ffffff08);border-radius:16px;box-shadow:inset 0 -3px 6px #0004,0 3px 8px #0003}
html #gb .res{font-size:22px;text-shadow:0 0 18px var(--glow)}
html #gb input,html #gb select{border-radius:14px;background:#0005;border:1px solid color-mix(in srgb,var(--p) 30%,var(--line))}
html .hero h1{font-size:32px;background:linear-gradient(90deg,var(--p),var(--p2));-webkit-background-clip:text;background-clip:text;color:transparent}
html .gc{background:linear-gradient(155deg,color-mix(in srgb,var(--p) 14%,var(--card)),var(--card) 62%);border:1px solid color-mix(in srgb,var(--p) 28%,var(--line));border-radius:20px;box-shadow:0 8px 22px #0005,inset 0 1px 0 #ffffff14;transition:transform .15s,box-shadow .2s}
html .gc .gi{background:linear-gradient(145deg,color-mix(in srgb,var(--p) 40%,transparent),color-mix(in srgb,var(--p) 10%,transparent));box-shadow:inset 0 1px 0 #ffffff33,0 6px 14px #0004}
html .gc b{font-size:15px}
html .tags span{border:1px solid #ffffff12}
html .chip.on{box-shadow:0 0 16px var(--glow)}
html nav{background:linear-gradient(180deg,#0004,#000d)}
html nav button.on{box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--p) 50%,transparent)}
::-webkit-scrollbar{width:6px;height:6px}::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--p) 40%,transparent);border-radius:9px}
`;
document.head.appendChild(c7);

/* =====================================================================
   1) Target hunting (whack) - target stays put until its ring runs out
   ===================================================================== */
function gWhack2(b,a){
 const W=340,H=430,c=CV(b,W,H),x=c.getContext('2d');
 b.querySelector('#ei').textContent='اضغط على الهدف قبل ما تخلص الحلقة - كل إصابة ورا الثانية ترفع الكومبو';
 let sc=0,hits=0,left=30,combo=0,tg=null,gap=0,fx=[],tx=[],rp=[],shake=0,over=0;
 const spawn=()=>{const r=Math.max(27,41-hits*.35),life=Math.max(1.2,2.6-hits*.04);tg={x:r+14+Math.random()*(W-2*r-28),y:62+r+Math.random()*(H-62-2*r-14),r,life,age:0,hue:[350,200,45,140,280][hits%5]}};
 spawn();
 const hit=()=>{hits++;combo++;const p=1+Math.min(4,combo/3|0);sc+=p;sx('ok');shake=.12;
  pw(fx,tg.x,tg.y,28,'hsl('+tg.hue+',90%,62%)',240,.7);pw(fx,tg.x,tg.y,10,'#fff',320,.45);
  rp.push({x:tg.x,y:tg.y,r:tg.r,l:.45,m:.45,h:tg.hue});tx.push({x:tg.x,y:tg.y-tg.r,t:'+'+p+(combo>2?'  ×'+combo:''),l:.8});tg=null;gap=.2};
 EL(a,c,'pointerdown',e=>{e.preventDefault();if(over)return;const[px,py]=ptr(c,e,W,H);
  if(tg&&Math.hypot(px-tg.x,py-tg.y)<=tg.r+18)hit();else{combo=0;sx('bad');rp.push({x:px,y:py,r:8,l:.3,m:.3,h:0,w:1})}});
 LP(a,dt=>{
  if(!over){left-=dt;
   if(left<=0){over=1;a.t(()=>a.end(sc,'أصبت '+hits+' هدفًا · النقاط '+sc),350)}
   if(tg){tg.age+=dt;if(tg.age>=tg.life){pw(fx,tg.x,tg.y,8,'#999',80,.4);tg=null;combo=0;gap=.25}}
   else if((gap-=dt)<=0)spawn()}
  shake=Math.max(0,shake-dt);fs(fx,dt);tx.forEach(q=>{q.y-=40*dt;q.l-=dt});tx=tx.filter(q=>q.l>0);rp.forEach(q=>q.l-=dt);rp=rp.filter(q=>q.l>0);
  x.save();if(shake>0)x.translate((Math.random()-.5)*6,(Math.random()-.5)*6);
  const g=x.createRadialGradient(W/2,H*.45,20,W/2,H*.45,H*.8);g.addColorStop(0,'#2a1f52');g.addColorStop(1,'#0c0820');x.fillStyle=g;x.fillRect(-8,-8,W+16,H+16);
  x.strokeStyle='#ffffff0d';x.lineWidth=1;for(let i=0;i<W;i+=34){x.beginPath();x.moveTo(i,0);x.lineTo(i,H);x.stroke()}for(let j=0;j<H;j+=34){x.beginPath();x.moveTo(0,j);x.lineTo(W,j);x.stroke()}
  rp.forEach(q=>{const k=1-q.l/q.m;x.globalAlpha=q.l/q.m;x.strokeStyle=q.w?'#ff5a6e':'hsl('+q.h+',90%,65%)';x.lineWidth=3;x.beginPath();x.arc(q.x,q.y,q.r+k*50,0,6.283);x.stroke()});x.globalAlpha=1;
  if(tg){const rem=1-tg.age/tg.life,pp=Math.min(1,tg.age/.15),s2=(.3+.7*(1-Math.pow(1-pp,3)))*(1+(pp<1?.15*Math.sin(pp*3.14):0));
   x.save();x.translate(tg.x,tg.y);x.scale(s2,s2);x.shadowColor='hsl('+tg.hue+',90%,60%)';x.shadowBlur=22;
   const cs=['#fff','hsl('+tg.hue+',85%,55%)'];for(let i=0;i<4;i++){x.fillStyle=cs[i%2];x.beginPath();x.arc(0,0,tg.r*(1-i*.24),0,6.283);x.fill()}
   x.shadowBlur=0;x.fillStyle='#fff';x.beginPath();x.arc(0,0,tg.r*.1,0,6.283);x.fill();x.restore();
   x.strokeStyle=rem<.35?'#ff5a6e':'#ffd36b';x.lineWidth=4;x.lineCap='round';x.beginPath();x.arc(tg.x,tg.y,tg.r+9,-1.5708,-1.5708+6.283*rem);x.stroke()}
  fd(x,fx);x.font='900 18px '+FONT;x.textAlign='center';tx.forEach(q=>{x.globalAlpha=Math.min(1,q.l*2);x.fillStyle='#ffd36b';x.fillText(q.t,q.x,q.y)});x.globalAlpha=1;x.restore();
  x.fillStyle='#0008';x.fillRect(0,0,W,40);x.font='700 15px '+FONT;x.textAlign='left';x.fillStyle='#fff';x.fillText('الوقت '+Math.ceil(Math.max(0,left)),12,26);
  x.textAlign='center';x.fillStyle='#ffd36b';x.fillText('النقاط '+sc,W/2,26);x.textAlign='right';x.fillStyle=combo>2?'#4cd964':'#ffffff88';x.fillText('كومبو ×'+combo,W-12,26);
  x.fillStyle='#ffffff22';x.fillRect(0,38,W,2);x.fillStyle='#a66cff';x.fillRect(0,38,W*Math.max(0,left)/30,2);
 })}

/* =====================================================================
   2) Tower defense - 5 stages, 3 tower types, upgrades, boss waves
   ===================================================================== */
const TDL=[
 {n:'المرج',p:[[-20,80],[250,80],[250,200],[100,200],[100,320],[260,320],[260,440],[330,440]],g:110,hp:10},
 {n:'الوادي',p:[[-20,450],[90,450],[90,70],[180,70],[180,450],[270,450],[270,70],[330,70]],g:125,hp:10},
 {n:'الحلزون',p:[[-20,60],[320,60],[320,460],[40,460],[40,160],[230,160],[230,360],[130,360]],g:135,hp:9},
 {n:'المتاهة',p:[[-20,260],[80,260],[80,80],[200,80],[200,440],[290,440],[290,200],[330,200]],g:145,hp:8},
 {n:'الزعيم',p:[[-20,60],[300,60],[300,150],[60,150],[60,240],[300,240],[300,330],[60,330],[60,420],[300,420],[300,480],[330,480]],g:165,hp:8}];
const TW={arrow:{n:'سهّام',c:40,r:84,d:11,cd:.62,col:'#7aa2ff'},cannon:{n:'مدفع',c:75,r:74,d:30,cd:1.5,col:'#ff9f43',sp:42},frost:{n:'ثلج',c:55,r:76,d:4,cd:.85,col:'#6ee7ff'}};
const EN={g:{c:'#e0344a',r:11,v:46,h:1},r:{c:'#ff9f1c',r:9,v:84,h:.55},t:{c:'#8b5cf6',r:14,v:32,h:2.8},B:{c:'#c2185b',r:19,v:26,h:14}};
const mkR=s=>()=>(s=(s*16807)%2147483647)/2147483647;
const pdist=(P,px,py)=>{let m=1e9;for(let i=1;i<P.length;i++){const A=P[i-1],B=P[i],dx=B[0]-A[0],dy=B[1]-A[1],L=dx*dx+dy*dy,t=cl(((px-A[0])*dx+(py-A[1])*dy)/L,0,1);m=Math.min(m,Math.hypot(px-(A[0]+dx*t),py-(A[1]+dy*t)))}return m};
const slotsFor=(P,n)=>{const cand=[],E=P[P.length-1];
 for(let i=1;i<P.length;i++){const A=P[i-1],B=P[i],L=Math.hypot(B[0]-A[0],B[1]-A[1]),nx=-(B[1]-A[1])/L,ny=(B[0]-A[0])/L;
  for(let d=25;d<L;d+=35)for(const s of[-1,1]){const px=A[0]+(B[0]-A[0])*d/L+nx*44*s,py=A[1]+(B[1]-A[1])*d/L+ny*44*s;if(px>26&&px<334&&py>26&&py<494&&pdist(P,px,py)>36&&Math.hypot(px-E[0],py-E[1])>56)cand.push([px,py])}}
 const out=[];cand.forEach(q=>{if(out.every(o=>Math.hypot(o[0]-q[0],o[1]-q[1])>58))out.push(q)});
 if(out.length<=n)return out;const r=[];for(let i=0;i<n;i++)r.push(out[Math.floor(i*out.length/n)]);return r};

function gTD3(b,a){
 const KEY='ams-td3';let sv={u:1,s:[0,0,0,0,0]};
 try{const o=JSON.parse(localStorage.getItem(KEY)||'null');if(o&&o.s)sv=Object.assign(sv,o)}catch(e){}
 const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(sv))}catch(e){}};
 let stop=null;
 const menu=()=>{if(stop){stop();stop=null}
  b.innerHTML='<div class="info" style="font-size:15px"><b>الدفاع عن البرج</b> - اختر المرحلة</div><div style="display:grid;gap:8px;width:min(340px,96%)">'+
  TDL.map((l,i)=>'<button class="btn '+(i<sv.u?'p':'')+'" data-l="'+i+'" '+(i<sv.u?'':'disabled')+' style="min-height:58px;display:flex;justify-content:space-between;align-items:center"><span>'+(i+1)+'. '+l.n+'</span><span>'+(i<sv.u?'★'.repeat(sv.s[i])+'☆'.repeat(3-sv.s[i]):'مقفلة')+'</span></button>').join('')+'</div>'};
 EL(a,b,'click',e=>{const k=e.target.closest&&e.target.closest('[data-l]');if(k&&!k.disabled){sx('click');play(+k.dataset.l)}});
 function play(L){
  const D=TDL[L],P=D.p,W=360,H=520,WV=5+L,seg=[];let tot=0;
  for(let i=1;i<P.length;i++){const l=Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);seg.push(l);tot+=l}
  const at=d=>{let i=0;while(i<seg.length-1&&d>seg[i]){d-=seg[i];i++}const k=cl(d/seg[i],0,1);return[P[i][0]+(P[i+1][0]-P[i][0])*k,P[i][1]+(P[i+1][1]-P[i][1])*k]};
  const sl=slotsFor(P,6+((L+1)>>1)).map(p=>({x:p[0],y:p[1],k:null,lv:0,cd:0,an:0,inv:0,ang:0}));
  const c=CV(b,W,H),x=c.getContext('2d'),ei=b.querySelector('#ei');
  b.insertAdjacentHTML('beforeend','<div id="pn" style="width:min(360px,100%);margin-top:8px"></div>');
  const pn=b.querySelector('#pn');
  /* pre-rendered background */
  const bg=document.createElement('canvas');bg.width=W;bg.height=H;const g=bg.getContext('2d'),RN=mkR(77+L*131);
  const gg=g.createLinearGradient(0,0,0,H);gg.addColorStop(0,'#2f6b3a');gg.addColorStop(1,'#1d4a2b');g.fillStyle=gg;g.fillRect(0,0,W,H);
  for(let i=0;i<90;i++){const px=RN()*W,py=RN()*H;if(pdist(P,px,py)<30)continue;g.fillStyle=RN()<.5?'#3d8247':'#255c33';g.beginPath();g.arc(px,py,2+RN()*5,0,6.283);g.fill()}
  for(let i=0;i<26;i++){const px=RN()*W,py=RN()*H;if(pdist(P,px,py)<26)continue;g.fillStyle=['#ffd36b','#ff8fa3','#fff'][i%3];g.beginPath();g.arc(px,py,1.8,0,6.283);g.fill()}
  g.lineCap='round';g.lineJoin='round';
  [[46,'#2b1d10'],[38,'#7a5a30'],[31,'#b08a52']].forEach(([w,cc])=>{g.strokeStyle=cc;g.lineWidth=w;g.beginPath();P.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke()});
  g.strokeStyle='#c9a468';g.lineWidth=2;g.setLineDash([8,10]);g.beginPath();P.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke();g.setLineDash([]);
  for(let i=0;i<16;i++){const px=14+RN()*(W-28),py=14+RN()*(H-28);if(pdist(P,px,py)<42||sl.some(s=>Math.hypot(s.x-px,s.y-py)<44))continue;
   g.fillStyle='#0003';g.beginPath();g.ellipse(px,py+12,12,5,0,0,6.283);g.fill();g.fillStyle='#5b3a1c';g.fillRect(px-2,py,4,12);g.fillStyle='#1f6b3a';g.beginPath();g.arc(px,py-4,12,0,6.283);g.fill();g.fillStyle='#2f9150';g.beginPath();g.arc(px-3,py-7,7,0,6.283);g.fill()}
  const E=P[P.length-1],cx=Math.min(E[0],322),cy=E[1];
  g.fillStyle='#0004';g.beginPath();g.ellipse(cx,cy+28,32,9,0,0,6.283);g.fill();g.fillStyle='#8b90ad';rr(g,cx-24,cy-26,48,52,4);g.fill();g.fillStyle='#a9aecb';g.fillRect(cx-24,cy-26,48,8);
  for(let i=0;i<4;i++)g.fillRect(cx-24+i*13,cy-33,9,9);g.fillStyle='#3a3f63';g.beginPath();g.moveTo(cx-8,cy+26);g.lineTo(cx-8,cy+8);g.arc(cx,cy+8,8,Math.PI,0);g.lineTo(cx+8,cy+26);g.fill();
  g.fillStyle='#ff3b5c';g.fillRect(cx-1,cy-48,2,16);g.beginPath();g.moveTo(cx+1,cy-48);g.lineTo(cx+15,cy-43);g.lineTo(cx+1,cy-38);g.fill();
  /* state */
  let hp=D.hp,gold=D.g,wave=0,state='idle',queue=[],spT=0,en=[],pr=[],fx=[],tx=[],rg=[],sel=-1,shake=0,spd=1,over=0,t=0,kills=0,sig='';
  const stat=s=>{const T=TW[s.k],m=s.lv-1;return{d:T.d*(1+.6*m),r:T.r*(1+.07*m),cd:T.cd*(1-.1*m)}};
  const upC=s=>Math.round(TW[s.k].c*.9*s.lv),sellV=s=>Math.round(s.inv*.6);
  const panel=()=>{const s=sel>=0?sl[sel]:null;let h='<div class="row" style="gap:6px;justify-content:center">';
   if(s&&!s.k)h+=Object.keys(TW).map(k=>'<button class="btn" data-a="b" data-k="'+k+'" '+(gold<TW[k].c?'disabled':'')+' style="flex:1;min-height:52px;font-size:13px;line-height:1.25;border-color:'+TW[k].col+'">'+TW[k].n+'<br><b>'+TW[k].c+'</b></button>').join('');
   else if(s)h+='<button class="btn" data-a="u" '+(s.lv>=3||gold<upC(s)?'disabled':'')+' style="flex:2;min-height:52px">'+(s.lv>=3?'أقصى مستوى':'ترقية ← '+(s.lv+1)+' ('+upC(s)+')')+'</button><button class="btn danger" data-a="s" style="flex:1;min-height:52px">بيع +'+sellV(s)+'</button>';
   else h+='<span class="info" style="padding:8px">اضغط على دائرة لبناء برج</span>';
   h+='</div><div class="row" style="gap:6px;margin-top:6px"><button class="btn p" data-a="w" style="flex:3;min-height:48px" '+(state==='idle'&&!over?'':'disabled')+'>'+(state==='idle'?'ابدأ الموجة '+(wave+1)+' / '+WV:'الموجة '+wave+' جارية…')+'</button><button class="btn" data-a="x" style="flex:1;min-height:48px">×'+spd+'</button><button class="btn" data-a="m" style="flex:1;min-height:48px">قائمة</button></div>';
   if(h!==sig){sig=h;pn.innerHTML=h}
   ei.innerHTML='القلعة <b>'+hp+'</b> · موجة <b>'+wave+'/'+WV+'</b> · ذهب <b>'+(gold|0)+'</b>'+(s&&s.k?' · '+TW[s.k].n+' م'+s.lv:'')};
  const spawn=ty=>{const hp0=14+L*8+(wave-1)*9,T=EN[ty];en.push({d:0,hp:hp0*T.h,m:hp0*T.h,ty,v0:T.v,sl:0,w:Math.random()*6,x:P[0][0],y:P[0][1]})};
  const startWave=()=>{if(state!=='idle'||over)return;wave++;const w=wave-1,n=5+w*2+L;queue=[];for(let i=0;i<n;i++)queue.push(w>=1&&i%4===3?'r':w>=2&&i%5===4?'t':'g');if(w===WV-1)queue.push('B');state='run';spT=0;sx('levelup')};
  const win=()=>{over=1;const st=hp>=D.hp?3:hp>=D.hp*.6?2:1;sv.s[L]=Math.max(sv.s[L],st);if(L+1<TDL.length)sv.u=Math.max(sv.u,L+2);save();
   a.t(()=>a.end(L*1000+st*300+hp*20+(gold|0),'المرحلة '+(L+1)+' اكتملت - '+'★'.repeat(st)+'☆'.repeat(3-st)+(L+1<TDL.length?' - انفتحت المرحلة التالية':' - خلصت كل المراحل!')),900)};
  const lose=()=>{over=1;a.t(()=>a.end(L*100+wave*10,'سقط البرج في الموجة '+wave+' - المرحلة '+(L+1)),900)};
  const hurtE=(e,dm)=>{e.hp-=dm;if(e.hp<=0&&!e.dead){e.dead=1;kills++;const rw=3+((L+wave)>>1)+(e.ty==='B'?30:0);gold+=rw;sx('pop');pw(fx,e.x,e.y,e.ty==='B'?40:14,EN[e.ty].c,190,.6);tx.push({x:e.x,y:e.y-12,t:'+'+rw,l:.7})}};
  const dmg=q=>{if(q.k==='cannon'){pw(fx,q.t.x,q.t.y,22,'#ffb347',220,.5);rg.push({x:q.t.x,y:q.t.y,l:.3});en.forEach(e=>{if(!e.dead&&Math.hypot(e.x-q.t.x,e.y-q.t.y)<TW.cannon.sp)hurtE(e,q.dm)});shake=Math.max(shake,.08)}
   else{if(q.k==='frost'){q.t.sl=1.6;pw(fx,q.t.x,q.t.y,6,'#bff4ff',90,.4)}else pw(fx,q.t.x,q.t.y,4,q.c,100,.3);hurtE(q.t,q.dm)}};
  EL(a,c,'pointerdown',e=>{e.preventDefault();const[px,py]=ptr(c,e,W,H),i=sl.findIndex(s=>Math.hypot(s.x-px,s.y-py)<30);sel=i;sx('click')});
  EL(a,pn,'click',e=>{const t2=e.target.closest('[data-a]');if(!t2||t2.disabled)return;const k=t2.dataset.a,s=sel>=0?sl[sel]:null;
   if(k==='b'&&s&&!s.k){const T=TW[t2.dataset.k];if(gold>=T.c){gold-=T.c;s.k=t2.dataset.k;s.lv=1;s.inv=T.c;s.an=.3;sx('ok');pw(fx,s.x,s.y,16,T.col,160,.6)}else sx('bad')}
   else if(k==='u'&&s&&s.k&&s.lv<3&&gold>=upC(s)){const cs=upC(s);gold-=cs;s.inv+=cs;s.lv++;s.an=.3;sx('levelup');pw(fx,s.x,s.y,20,'#ffd36b',180,.7)}
   else if(k==='s'&&s&&s.k){gold+=sellV(s);s.k=null;s.lv=0;s.inv=0;sx('coin')}
   else if(k==='w')startWave();
   else if(k==='x'){spd=spd===1?2:1;sx('click')}
   else if(k==='m'){menu();return}
   panel()});
  panel();
  stop=LP(a,r0=>{const dt=r0*spd;t+=r0;shake=Math.max(0,shake-dt);
   if(!over){
    if(state==='run'){spT-=dt;if(queue.length&&spT<=0){spawn(queue.shift());spT=queue.length&&queue[0]==='B'?1.6:.85}
     if(!queue.length&&!en.length){state='idle';const bn=25+wave*8;gold+=bn;tx.push({x:W/2,y:H/2,t:'اكتملت الموجة  +'+bn,l:1.6,big:1});sx('win');if(wave>=WV)win()}}
    en.forEach(e=>{e.sl=Math.max(0,e.sl-dt);e.d+=e.v0*(e.sl>0?.5:1)*dt;e.w+=dt*8;const p=at(Math.min(e.d,tot));e.x=p[0];e.y=p[1];
     if(e.d>=tot&&!e.dead){e.dead=1;hp--;shake=.35;sx('die');pw(fx,e.x,e.y,18,'#ff3b5c',200,.7);if(hp<=0&&!over)lose()}});
    sl.forEach(s=>{s.an=Math.max(0,s.an-dt);if(!s.k)return;s.cd-=dt;const S=stat(s);let tg=null,bd=-1;
     en.forEach(e=>{if(e.dead)return;if(Math.hypot(e.x-s.x,e.y-s.y)<S.r&&e.d>bd){bd=e.d;tg=e}});
     if(tg){s.ang=Math.atan2(tg.y-s.y,tg.x-s.x);if(s.cd<=0){s.cd=S.cd;pr.push({x:s.x+Math.cos(s.ang)*14,y:s.y+Math.sin(s.ang)*14,t:tg,dm:S.d,k:s.k,c:TW[s.k].col});s.an=.12;pw(fx,s.x+Math.cos(s.ang)*18,s.y+Math.sin(s.ang)*18,3,TW[s.k].col,70,.25);if(s.k==='cannon')sx('boom')}}});
    pr.forEach(q=>{if(q.t.dead){q.x=-99;return}const dx=q.t.x-q.x,dy=q.t.y-q.y,l=Math.hypot(dx,dy),sp=440*dt;if(l<=Math.max(10,sp)){q.x=-99;dmg(q)}else{q.x+=dx/l*sp;q.y+=dy/l*sp}});
    pr=pr.filter(q=>q.x>-50);en=en.filter(e=>!e.dead)}
   fs(fx,dt);tx.forEach(q=>{q.y-=30*dt;q.l-=dt});tx=tx.filter(q=>q.l>0);rg.forEach(q=>q.l-=dt);rg=rg.filter(q=>q.l>0);
   x.save();if(shake>0)x.translate((Math.random()-.5)*8,(Math.random()-.5)*8);x.drawImage(bg,0,0);
   sl.forEach((s,i)=>{
    if(i===sel){const R=s.k?stat(s).r:70;x.fillStyle='#ffffff14';x.beginPath();x.arc(s.x,s.y,R,0,6.283);x.fill();x.strokeStyle='#fff';x.lineWidth=2;x.setLineDash([5,4]);x.stroke();x.setLineDash([])}
    if(!s.k){x.fillStyle='#ffffff1c';x.beginPath();x.arc(s.x,s.y,21,0,6.283);x.fill();x.strokeStyle=i===sel?'#fff':'#ffffff66';x.lineWidth=2;x.stroke();x.fillStyle='#fff';x.font='700 22px '+FONT;x.textAlign='center';x.fillText('+',s.x,s.y+8);return}
    const col=TW[s.k].col;x.save();x.translate(s.x,s.y);const k2=1+s.an*1.2;x.scale(k2,k2);
    x.fillStyle='#0004';x.beginPath();x.ellipse(0,18,19,7,0,0,6.283);x.fill();x.fillStyle='#4a4f66';x.beginPath();x.arc(0,0,20,0,6.283);x.fill();x.fillStyle='#6a7090';x.beginPath();x.arc(0,-2,17,0,6.283);x.fill();x.strokeStyle=col;x.lineWidth=3;x.stroke();
    x.fillStyle='#ffd36b';for(let q=0;q<s.lv;q++){x.beginPath();x.arc(-7+q*7,24,2.4,0,6.283);x.fill()}
    x.rotate(s.ang);
    if(s.k==='arrow'){x.fillStyle='#e9eefc';x.fillRect(0,-3,22,6);x.fillStyle=col;x.beginPath();x.moveTo(22,-6);x.lineTo(32,0);x.lineTo(22,6);x.fill();x.fillStyle='#8899bb';x.fillRect(-8,-9,6,18)}
    else if(s.k==='cannon'){x.fillStyle='#2b2f45';rr(x,-4,-7,28,14,5);x.fill();x.fillStyle=col;x.fillRect(20,-8,6,16);x.beginPath();x.arc(0,0,10,0,6.283);x.fill()}
    else{x.rotate(-s.ang+t*1.5);x.fillStyle=col;x.beginPath();for(let q=0;q<12;q++){const an=q/12*6.283,rad=q%2?7:16;x.lineTo(Math.cos(an)*rad,Math.sin(an)*rad)}x.closePath();x.fill();x.fillStyle='#fff';x.beginPath();x.arc(0,0,4,0,6.283);x.fill()}
    x.restore()});
   en.forEach(e=>{const T=EN[e.ty];x.save();x.translate(e.x,e.y+Math.sin(e.w)*1.5);x.fillStyle='#0003';x.beginPath();x.ellipse(0,T.r*.8,T.r*.9,T.r*.35,0,0,6.283);x.fill();
    x.fillStyle=e.sl>0?'#7fd3ff':T.c;x.beginPath();x.arc(0,0,T.r,0,6.283);x.fill();x.fillStyle='#ffffff40';x.beginPath();x.arc(-T.r*.3,-T.r*.35,T.r*.4,0,6.283);x.fill();
    x.fillStyle='#fff';x.beginPath();x.arc(-T.r*.35,-T.r*.1,T.r*.25,0,6.283);x.arc(T.r*.35,-T.r*.1,T.r*.25,0,6.283);x.fill();x.fillStyle='#111';x.beginPath();x.arc(-T.r*.3,-T.r*.05,T.r*.11,0,6.283);x.arc(T.r*.4,-T.r*.05,T.r*.11,0,6.283);x.fill();
    if(e.ty==='t'){x.strokeStyle='#c4b5fd';x.lineWidth=3;x.beginPath();x.arc(0,0,T.r-1.5,3.5,5.9);x.stroke()}
    if(e.ty==='B'){x.fillStyle='#ffd36b';x.beginPath();x.moveTo(-9,-T.r+2);x.lineTo(-9,-T.r-9);x.lineTo(-4,-T.r-3);x.lineTo(0,-T.r-11);x.lineTo(4,-T.r-3);x.lineTo(9,-T.r-9);x.lineTo(9,-T.r+2);x.fill()}
    const bw=T.r*2+6,by=-T.r-9-(e.ty==='B'?10:0),f=Math.max(0,e.hp/e.m);x.fillStyle='#0009';x.fillRect(-bw/2,by,bw,4);x.fillStyle=f>.5?'#7dff6b':f>.25?'#ffd23f':'#ff5a6e';x.fillRect(-bw/2,by,bw*f,4);x.restore()});
   pr.forEach(q=>{x.fillStyle=q.c;x.shadowColor=q.c;x.shadowBlur=8;x.beginPath();x.arc(q.x,q.y,q.k==='cannon'?6:4,0,6.283);x.fill();x.shadowBlur=0});
   rg.forEach(q=>{x.globalAlpha=q.l/.3;x.strokeStyle='#ffb347';x.lineWidth=3;x.beginPath();x.arc(q.x,q.y,TW.cannon.sp*(1.1-q.l/.3*.6),0,6.283);x.stroke()});x.globalAlpha=1;
   fd(x,fx);x.textAlign='center';tx.forEach(q=>{x.globalAlpha=Math.min(1,q.l*2);x.font=(q.big?'900 20px ':'700 13px ')+FONT;x.fillStyle=q.big?'#fff':'#ffd36b';x.fillText(q.t,q.x,q.y)});x.globalAlpha=1;
   x.restore();panel()})}
 menu()}

/* =====================================================================
   3) Wild survival - 2D top-down, 7 days, day/night, wolves, campfire
   ===================================================================== */
function gWild(b,a){
 const W=360,H=470,WS=1000,DAY=42,DAYS=7,R=Math.random,c=CV(b,W,H),x=c.getContext('2d'),ei=b.querySelector('#ei');
 ei.textContent='اسحب بإصبعك للتحرك - الخشب والتوت والماء يتجمعون تلقائيًا. بالليل ولّع نار وانتبه من الذئاب';
 const ovc=document.createElement('canvas');ovc.width=W;ovc.height=H;const ov=ovc.getContext('2d');
 const P={x:WS/2,y:WS/2,hp:100,hu:100,th:100,wd:3,fd:1,sp:0,f:1,hit:0,gc:0,ac:0,ph:0};
 let tm=0,fx=[],tr=[],bu=[],po=[{x:230,y:260,rx:72,ry:48},{x:780,y:700,rx:84,ry:56}],rk=[],wv=[],fr=[],tx=[],K={},pt=null,over=0,sh=0,spW=3,cx=0,cy=0,sig='';
 const free=(px,py,rad)=>{if(Math.hypot(px-WS/2,py-WS/2)<80)return false;if(po.some(p=>((px-p.x)/(p.rx+rad))**2+((py-p.y)/(p.ry+rad))**2<1))return false;return![...tr,...bu].some(o=>Math.hypot(o.x-px,o.y-py)<o.r+rad+14)};
 const put=(arr,n,mk)=>{let k=0;while(arr.length<n&&k++<3000){const px=40+R()*(WS-80),py=40+R()*(WS-80),o=mk(px,py);if(free(px,py,o.r))arr.push(o)}};
 put(tr,46,(px,py)=>({x:px,y:py,r:18+R()*6,hp:3,rg:0,sh:0}));put(bu,16,(px,py)=>({x:px,y:py,r:14,b:1,rg:0}));
 for(let i=0;i<20;i++)rk.push({x:30+R()*(WS-60),y:30+R()*(WS-60),r:5+R()*7});
 const blocked=(px,py)=>px<12||py<12||px>WS-12||py>WS-12||tr.some(o=>o.hp>0&&Math.hypot(o.x-px,o.y-py)<o.r*.6+8)||po.some(p=>((px-p.x)/(p.rx*.9))**2+((py-p.y)/(p.ry*.9))**2<1);
 const note=(t,col)=>tx.push({x:P.x,y:P.y-34,t,l:1,c:col||'#fff'});
 const makeFire=()=>{if(over||P.wd<4)return;P.wd-=4;fr.push({x:P.x,y:P.y+16,t:50});sx('power');pw(fx,P.x,P.y+14,16,'#ffb347',140,.6,-40)};
 const makeSpear=()=>{if(over||P.sp||P.wd<6)return;P.wd-=6;P.sp=1;sx('levelup');note('رمح جاهز','#ffd36b')};
 EL(a,document,'keydown',e=>{K[e.code]=1;if(/Arrow/.test(e.code))e.preventDefault();if(e.code==='KeyF')makeFire();if(e.code==='KeyR')makeSpear()});
 EL(a,document,'keyup',e=>{K[e.code]=0});
 EL(a,c,'pointerdown',e=>{e.preventDefault();try{c.setPointerCapture(e.pointerId)}catch(_){}const[px,py]=ptr(c,e,W,H);pt={x:px,y:py}});
 EL(a,c,'pointermove',e=>{if(!pt)return;const[px,py]=ptr(c,e,W,H);pt.x=px;pt.y=py});
 ['pointerup','pointercancel'].forEach(n=>EL(a,c,n,()=>{pt=null}));
 b.insertAdjacentHTML('beforeend','<div id="pn" class="row" style="gap:8px;width:min(360px,100%);margin-top:8px"></div>');
 const pn=b.querySelector('#pn');
 const panel=()=>{const s=[P.wd>=4,P.wd>=6&&!P.sp,P.sp].join();if(s===sig)return;sig=s;
  pn.innerHTML='<button class="btn p" data-a="f" '+(P.wd>=4?'':'disabled')+' style="flex:1;min-height:54px">ولّع نار<br><small>4 خشب</small></button><button class="btn" data-a="s" '+(P.sp||P.wd<6?'disabled':'')+' style="flex:1;min-height:54px">'+(P.sp?'الرمح جاهز':'اصنع رمح')+'<br><small>6 خشب</small></button>'};
 EL(a,pn,'click',e=>{const t=e.target.closest('[data-a]');if(!t||t.disabled)return;if(t.dataset.a==='f')makeFire();else makeSpear();sig='';panel()});
 panel();
 const finish=(win)=>{if(over)return;over=1;const sc=Math.round(tm+P.hp*2);a.t(()=>a.end(sc,win?'نجوت 7 أيام في البرية!':'ما صمدت - وصلت اليوم '+(Math.floor(tm/DAY)+1)),900)};
 const hash=(i,j)=>((i*73856093)^(j*19349663))>>>0;
 LP(a,dt=>{
  const dayN=Math.floor(tm/DAY)+1,ph=(tm%DAY)/DAY,dark=ph<.5?0:ph<.6?(ph-.5)/.1:ph<.92?1:(1-ph)/.08,night=dark>.5;
  if(!over){tm+=dt;sh=Math.max(0,sh-dt);P.hit=Math.max(0,P.hit-dt);P.gc-=dt;P.ac-=dt;
   if(dayN>DAYS){finish(1)}
   /* needs */
   P.hu=Math.max(0,P.hu-dt*1.05);P.th=Math.max(0,P.th-dt*1.35);
   if(P.hu<55&&P.fd>0){P.fd--;P.hu=Math.min(100,P.hu+28);sx('ok');note('أكلت','#ff9f43')}
   if(P.hu<=0||P.th<=0)P.hp-=4*dt;else if(P.hu>40&&P.th>40)P.hp=Math.min(100,P.hp+1.2*dt);
   if(fr.some(f=>Math.hypot(f.x-P.x,f.y-P.y)<80))P.hp=Math.min(100,P.hp+2*dt);
   if(P.hp<=0)finish(0);
   /* move */
   let dx=(K.ArrowRight||K.KeyD?1:0)-(K.ArrowLeft||K.KeyA?1:0),dy=(K.ArrowDown||K.KeyS?1:0)-(K.ArrowUp||K.KeyW?1:0);
   if(dx&&dy){dx*=.707;dy*=.707}
   if(pt){const ex=pt.x-(P.x-cx),ey=pt.y-(P.y-cy),d=Math.hypot(ex,ey);if(d>14){dx=ex/d;dy=ey/d}}
   const mv=dx||dy;if(mv){const s=120*dt,nx=P.x+dx*s,ny=P.y+dy*s;if(!blocked(nx,P.y))P.x=nx;if(!blocked(P.x,ny))P.y=ny;P.ph+=dt*11;if(dx)P.f=dx>0?1:-1}
   /* gather */
   tr.forEach(o=>{o.sh=Math.max(0,o.sh-dt);if(o.hp<=0){if((o.rg-=dt)<=0)o.hp=3;return}
    if(P.gc<=0&&Math.hypot(o.x-P.x,o.y-P.y)<o.r+22){P.gc=.55;o.hp--;o.sh=.2;P.wd+=1+(R()<.4?1:0);sx('click');pw(fx,o.x,o.y-10,6,'#2fa84f',110,.4);
     if(o.hp<=0){o.rg=36;pw(fx,o.x,o.y,14,'#8a5a2b',160,.6)}}});
   bu.forEach(o=>{if(!o.b){if((o.rg-=dt)<=0)o.b=1;return}if(Math.hypot(o.x-P.x,o.y-P.y)<o.r+20){o.b=0;o.rg=20;P.fd+=2;sx('coin');pw(fx,o.x,o.y,10,'#ff4d6d',120,.5);note('+2 توت','#ff9fb0')}});
   if(po.some(p=>((P.x-p.x)/(p.rx+26))**2+((P.y-p.y)/(p.ry+26))**2<1)&&P.th<100){P.th=Math.min(100,P.th+45*dt);if(R()<.3)pw(fx,P.x,P.y+8,1,'#9be7ff',70,.4,100)}
   /* fires */
   fr.forEach(f=>{f.t-=dt;if(R()<.3)fx.push({x:f.x+(R()-.5)*10,y:f.y-6,vx:(R()-.5)*20,vy:-50-R()*40,l:.5,m:.5,c:'#ffb347',s:1.5+R()*1.5,g:-20})});fr=fr.filter(f=>f.t>0);
   /* wolves */
   if(night){spW-=dt;if(spW<=0&&wv.length<Math.min(2+dayN,8)){spW=Math.max(3,11-dayN);const an=R()*6.283;wv.push({x:cl(P.x+Math.cos(an)*290,20,WS-20),y:cl(P.y+Math.sin(an)*290,20,WS-20),hp:30,cd:0,ph:R()*6,f:1,kb:0})}}
   else if(dark<.05&&wv.length){wv.forEach(w=>pw(fx,w.x,w.y,8,'#aab',80,.5));wv=[]}
   wv.forEach(w=>{w.ph+=dt*9;w.cd-=dt;const fire=fr.find(f=>Math.hypot(f.x-w.x,f.y-w.y)<115),dd=Math.hypot(P.x-w.x,P.y-w.y);
    let tx2=P.x,ty2=P.y,v=82+dayN*3;if(fire){tx2=w.x+(w.x-fire.x);ty2=w.y+(w.y-fire.y);v=100}else if(dd>230)v=40;
    const ex=tx2-w.x,ey=ty2-w.y,d=Math.hypot(ex,ey)||1;if(w.kb>0){w.kb-=dt;w.x+=w.dx*dt;w.y+=w.dy*dt}else if(!(dd<20&&!fire)){w.x+=ex/d*v*dt;w.y+=ey/d*v*dt;w.f=ex>0?1:-1}
    w.x=cl(w.x,10,WS-10);w.y=cl(w.y,10,WS-10);
    if(dd<22&&w.cd<=0&&!fire){w.cd=1;P.hp-=11;P.hit=.25;sh=.25;sx('bad');pw(fx,P.x,P.y,8,'#ff5a6e',140,.4)}
    if(dd<42&&P.ac<=0){P.ac=.5;w.hp-=P.sp?20:9;w.kb=.15;w.dx=(w.x-P.x)/(dd||1)*260;w.dy=(w.y-P.y)/(dd||1)*260;sx('hit');pw(fx,w.x,w.y,6,'#d33',140,.35);
     if(w.hp<=0){w.dead=1;P.fd+=2;sx('coin');pw(fx,w.x,w.y,14,'#aab',170,.6);note('+2 لحم','#ff9f43')}}});
   wv=wv.filter(w=>!w.dead)}
  fs(fx,dt);tx.forEach(q=>{q.y-=26*dt;q.l-=dt});tx=tx.filter(q=>q.l>0);
  cx=cl(P.x-W/2,0,WS-W);cy=cl(P.y-H/2,0,WS-H);
  /* ---- draw ---- */
  x.save();if(sh>0)x.translate((R()-.5)*6,(R()-.5)*6);x.translate(-cx,-cy);
  const cols=['#3f8f4a','#43964e','#3b8845','#47a054','#3d8c48'];
  for(let i=Math.floor(cx/64);i<=Math.floor((cx+W)/64);i++)for(let j=Math.floor(cy/64);j<=Math.floor((cy+H)/64);j++){const h=hash(i,j);x.fillStyle=cols[h%5];x.fillRect(i*64,j*64,65,65);
   if(h%3===0){x.strokeStyle='#2c6e38';x.lineWidth=1.5;const gx=i*64+(h>>3)%56,gy=j*64+(h>>7)%56;x.beginPath();x.moveTo(gx,gy);x.lineTo(gx-2,gy-6);x.moveTo(gx+3,gy);x.lineTo(gx+4,gy-7);x.stroke()}}
  po.forEach(p=>{x.fillStyle='#d9c48a';x.beginPath();x.ellipse(p.x,p.y,p.rx+8,p.ry+8,0,0,6.283);x.fill();x.fillStyle='#2a7fd0';x.beginPath();x.ellipse(p.x,p.y,p.rx,p.ry,0,0,6.283);x.fill();x.strokeStyle='#7cc4ff';x.lineWidth=2;x.globalAlpha=.6;x.beginPath();x.ellipse(p.x,p.y,p.rx*.6+Math.sin(tm*2)*3,p.ry*.6+Math.sin(tm*2)*2,0,0,6.283);x.stroke();x.globalAlpha=1});
  rk.forEach(o=>{x.fillStyle='#0003';x.beginPath();x.ellipse(o.x,o.y+o.r*.6,o.r,o.r*.4,0,0,6.283);x.fill();x.fillStyle='#8a8f9c';x.beginPath();x.arc(o.x,o.y,o.r,0,6.283);x.fill();x.fillStyle='#a8adba';x.beginPath();x.arc(o.x-o.r*.25,o.y-o.r*.25,o.r*.5,0,6.283);x.fill()});
  const dr=[];
  tr.forEach(o=>{if(o.hp>0&&o.x>cx-40&&o.x<cx+W+40&&o.y>cy-60&&o.y<cy+H+40)dr.push({y:o.y,f:()=>{const k=o.hp/3*.25+.75,sx2=o.sh>0?Math.sin(o.sh*60)*2:0;x.fillStyle='#0003';x.beginPath();x.ellipse(o.x,o.y+o.r*.7,o.r*1.1,o.r*.4,0,0,6.283);x.fill();x.fillStyle='#7a4a24';x.fillRect(o.x-4,o.y-4,8,o.r*.9);
    x.fillStyle='#2e8b4f';x.beginPath();x.arc(o.x+sx2,o.y-o.r*.7,o.r*k,0,6.283);x.fill();x.fillStyle='#37a05a';x.beginPath();x.arc(o.x-o.r*.35+sx2,o.y-o.r*.4,o.r*.7*k,0,6.283);x.fill();x.fillStyle='#4cc070';x.beginPath();x.arc(o.x+o.r*.2+sx2,o.y-o.r*1,o.r*.6*k,0,6.283);x.fill()}})});
  bu.forEach(o=>{if(o.x>cx-30&&o.x<cx+W+30&&o.y>cy-30&&o.y<cy+H+30)dr.push({y:o.y,f:()=>{x.fillStyle='#0003';x.beginPath();x.ellipse(o.x,o.y+8,14,5,0,0,6.283);x.fill();x.fillStyle=o.b?'#2f9150':'#7a9a62';x.beginPath();x.arc(o.x,o.y,13,0,6.283);x.arc(o.x-8,o.y+3,9,0,6.283);x.arc(o.x+8,o.y+3,9,0,6.283);x.fill();
    if(o.b){x.fillStyle='#ff4d6d';[[-5,-3],[4,-5],[1,3],[-9,4],[9,4]].forEach(q=>{x.beginPath();x.arc(o.x+q[0],o.y+q[1],2.4,0,6.283);x.fill()})}}})});
  fr.forEach(f=>dr.push({y:f.y,f:()=>{const fl=1+Math.sin(tm*18+f.x)*.12;x.fillStyle='#0003';x.beginPath();x.ellipse(f.x,f.y+4,16,5,0,0,6.283);x.fill();x.strokeStyle='#5b3a1c';x.lineWidth=5;x.lineCap='round';x.beginPath();x.moveTo(f.x-12,f.y+2);x.lineTo(f.x+12,f.y-2);x.moveTo(f.x-12,f.y-2);x.lineTo(f.x+12,f.y+2);x.stroke();
    x.fillStyle='#ff7a1a';x.beginPath();x.moveTo(f.x-9,f.y);x.quadraticCurveTo(f.x-6,f.y-18*fl,f.x,f.y-28*fl);x.quadraticCurveTo(f.x+6,f.y-18*fl,f.x+9,f.y);x.fill();x.fillStyle='#ffd23f';x.beginPath();x.moveTo(f.x-5,f.y);x.quadraticCurveTo(f.x-3,f.y-10*fl,f.x,f.y-17*fl);x.quadraticCurveTo(f.x+3,f.y-10*fl,f.x+5,f.y);x.fill()}}));
  wv.forEach(w=>dr.push({y:w.y,f:()=>{const lg=Math.sin(w.ph)*3;x.save();x.translate(w.x,w.y);x.scale(w.f,1);x.fillStyle='#0003';x.beginPath();x.ellipse(0,9,13,4,0,0,6.283);x.fill();x.strokeStyle='#4a5160';x.lineWidth=3;x.lineCap='round';x.beginPath();x.moveTo(-7,4);x.lineTo(-7+lg,10);x.moveTo(6,4);x.lineTo(6-lg,10);x.stroke();
    x.fillStyle='#7b8494';x.beginPath();x.ellipse(0,0,13,8,0,0,6.283);x.fill();x.beginPath();x.moveTo(-12,-2);x.lineTo(-19,-8+lg*.4);x.lineTo(-11,3);x.fill();x.fillStyle='#8d96a8';x.beginPath();x.arc(11,-3,6.5,0,6.283);x.fill();x.fillStyle='#7b8494';x.beginPath();x.moveTo(8,-8);x.lineTo(10,-14);x.lineTo(13,-8);x.fill();x.fillStyle=night?'#ff3b3b':'#222';x.beginPath();x.arc(13,-4,1.6,0,6.283);x.fill();x.restore();
    if(w.hp<30){x.fillStyle='#0009';x.fillRect(w.x-12,w.y-18,24,3);x.fillStyle='#ff5a6e';x.fillRect(w.x-12,w.y-18,24*w.hp/30,3)}}}));
  dr.push({y:P.y,f:()=>{const lg=Math.sin(P.ph)*4;x.save();x.translate(P.x,P.y);x.scale(P.f,1);x.fillStyle='#0003';x.beginPath();x.ellipse(0,12,10,4,0,0,6.283);x.fill();x.strokeStyle='#3a2a6a';x.lineWidth=4;x.lineCap='round';x.beginPath();x.moveTo(-3,5);x.lineTo(-3+lg,13);x.moveTo(3,5);x.lineTo(3-lg,13);x.stroke();
    x.fillStyle=P.hit>0?'#fff':'#e8a23a';rr(x,-8,-9,16,15,6);x.fill();x.fillStyle='#f3c9a0';x.beginPath();x.arc(0,-15,6.5,0,6.283);x.fill();x.fillStyle=P.hit>0?'#fff':'#3a2412';x.beginPath();x.arc(0,-17,6.6,Math.PI,0);x.fill();x.fillStyle='#222';x.fillRect(2,-16,1.8,1.8);
    if(P.sp){x.strokeStyle='#8a5a2b';x.lineWidth=2.5;x.beginPath();x.moveTo(6,4);x.lineTo(20,-16);x.stroke();x.fillStyle='#dfe5f0';x.beginPath();x.moveTo(20,-16);x.lineTo(17,-12);x.lineTo(23,-12);x.fill()}x.restore()}});
  dr.sort((p,q)=>p.y-q.y).forEach(d=>d.f());
  fd(x,fx);x.font='700 13px '+FONT;x.textAlign='center';tx.forEach(q=>{x.globalAlpha=Math.min(1,q.l*2);x.fillStyle=q.c;x.fillText(q.t,q.x,q.y)});x.globalAlpha=1;
  x.restore();
  /* night */
  const al=dark*.78;
  if(al>.02){ov.globalCompositeOperation='source-over';ov.clearRect(0,0,W,H);ov.fillStyle='rgba(6,10,36,'+al+')';ov.fillRect(0,0,W,H);ov.globalCompositeOperation='destination-out';
   const light=(lx,ly,r,s)=>{const g=ov.createRadialGradient(lx,ly,r*.15,lx,ly,r);g.addColorStop(0,'rgba(0,0,0,'+s+')');g.addColorStop(1,'rgba(0,0,0,0)');ov.fillStyle=g;ov.fillRect(lx-r,ly-r,r*2,r*2)};
   light(P.x-cx,P.y-cy,110,.85);fr.forEach(f=>light(f.x-cx,f.y-cy,160,1));ov.globalCompositeOperation='source-over';x.drawImage(ovc,0,0)}
  /* HUD */
  x.fillStyle='#0008';x.fillRect(0,0,W,58);x.font='700 11px '+FONT;
  [['صحة',P.hp,'#ff5a6e'],['جوع',P.hu,'#ff9f43'],['عطش',P.th,'#4aa8ff']].forEach(([n,v,col],i)=>{const y=8+i*16;x.textAlign='left';x.fillStyle='#fff';x.fillText(n,8,y+9);x.fillStyle='#ffffff22';rr(x,40,y,92,10,5);x.fill();x.fillStyle=col;rr(x,40,y,Math.max(0,92*v/100),10,5);x.fill()});
  x.textAlign='right';x.font='900 14px '+FONT;x.fillStyle='#ffd36b';x.fillText('اليوم '+Math.min(DAYS,dayN)+' / '+DAYS,W-10,20);x.font='700 12px '+FONT;x.fillStyle='#fff';x.fillText('خشب '+P.wd+' · أكل '+P.fd,W-10,38);
  x.fillStyle='#ffffff22';rr(x,W-110,45,100,6,3);x.fill();x.fillStyle=night?'#8ea2ff':'#ffd36b';rr(x,W-110,45,Math.max(6,100*ph),6,3);x.fill();
  if(night&&dayN<=DAYS){x.textAlign='center';x.font='700 12px '+FONT;x.fillStyle='#ffd36b';x.fillText('الليل - الذئاب قريبة، ولّع نار',W/2,H-10)}
  panel()})}

/* ---------- register ---------- */
const setG=(id,f,d,r)=>{const g=G.find(q=>q.id===id);if(g){g.run=f;if(d)g.d=d;if(r)g.r=r}};
setG('whack',gWhack2,'اضرب الأهداف قبل ما تخلص حلقتها - الهدف ما يهرب، وتطلع جسيمات وكومبو.','اضغط الهدف بسرعة قبل ما تنتهي الحلقة حوله. الإصابات المتتالية ترفع الكومبو والنقاط، والضغط بالفراغ يكسر الكومبو.');
setG('towerdef',gTD3,'5 مراحل، 3 أنواع أبراج مع ترقيات، موجات وزعيم، وتقدمك ينحفظ.','اضغط دائرة فاضية لبناء برج (سهام/مدفع/ثلج) ثم اضغطها لترقيتها. ابدأ الموجات وصدّ الأعداء قبل ما يوصلون القلعة.');
setG('survival',gWild,'لعبة 2D: اجمع خشب وتوت وماء، ولّع نار، وواجه الذئاب بالليل لين تكمل 7 أيام.','اسحب بإصبعك للتحرك (أو WASD). الخشب والتوت والماء تنجمع تلقائيًا. ولّع نار بالليل، واصنع رمحًا، وصمد 7 أيام.');
})();

try{renderChips();renderLib()}catch(e){console.error(e)}
Object.assign(UI_EN,{'ناجٍ ضد الزومبي: الموقف الأخير':'Zombie Survival: Last Stand'});

})();
