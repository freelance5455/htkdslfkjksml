/* ===================================================================
 * main.js — نقطه ورود برنامه
 * =================================================================== */
(function (VFL) {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    VFL.State.init();
    VFL.UI.Router.start();
  });
})(window.VFL || (window.VFL = {}));
