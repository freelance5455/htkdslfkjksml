document.addEventListener('DOMContentLoaded', () => {
  UI.showScreen('screen-login');

  document.getElementById('btn-login').addEventListener('click', () => {
    const name = document.getElementById('input-username').value.trim()
      || 'Player' + Math.floor(Math.random() * 1000);
    NET.login(name);
  });

  NET.socket.on('loginSuccess', data => {
    document.getElementById('lobby-username').textContent = data.username;
    UI.showScreen('screen-lobby');
  });

  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      NET.joinMatchmaking(btn.dataset.mode);
      UI.showScreen('screen-matchmaking');
      UI.setCountdown(0);
    });
  });

  document.getElementById('btn-dev-force').addEventListener('click', () => {
    NET.devForceStart();
  });

  NET.socket.on('matchmakingUpdate', data => {
    UI.setMatchmakingCount(data.playersFound, data.minPlayers, data.maxPlayers);
  });

  NET.socket.on('countdownStart', data => UI.setCountdown(data.seconds));
  NET.socket.on('countdownTick', data => UI.setCountdown(data.seconds));

  Game.init();
});
