(function () {
  'use strict';
  const P = window.Pith;
  const U = P.util;

  async function boot() {
    const wire = (id, fn) => document.getElementById(id).addEventListener('change', (e) => { fn(e.target.files); });
    wire('in-camera', (f) => P.chat.addFiles(f));
    wire('in-gallery', (f) => P.chat.addFiles(f));
    wire('in-files', (f) => P.chat.addFiles(f));

    await P.state.load();
    await P.theme.applyCurrent();
    P.views.build();
    P.chat.startQueueIfNeeded();
    if (!P.state.profile) P.views.showOnboarding();
    if (P.store.usingFallback()) U.toast('Using limited storage: large attachments may not be kept.', 4200);
  }

  boot().catch((e) => {
    console.error(e);
    document.body.append(U.h('pre', { style: { padding: '24px', whiteSpace: 'pre-wrap', color: '#b3261e' } }, 'Pith could not start:\n' + (e && e.stack ? e.stack : e)));
  });
})();
