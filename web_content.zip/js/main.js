// ============================================================
// START-UP — this file is loaded LAST, so every function and constant from
// the other files already exists by the time these lines run.
// ============================================================

// ---------- Storage reliability check ----------
// Pages opened via a "content://" share-sheet link (instead of a normal
// file opened straight from Downloads/Files) are very often given a
// throwaway browser storage area by the phone — anything saved can vanish
// again the moment the tab is reloaded. This can't be fixed from inside the
// page, so it's surfaced as a clear warning instead of failing silently.
function checkStorageReliability(){
  const banner = document.getElementById('storageWarningBanner');
  if (!banner) return;
  let unreliable = false;
  try {
    const testKey = '__epi_storage_test__';
    localStorage.setItem(testKey, '1');
    const readBack = localStorage.getItem(testKey);
    localStorage.removeItem(testKey);
    if (readBack !== '1') unreliable = true;
  } catch (e) {
    unreliable = true;
  }
  if (location.protocol === 'content:' || location.protocol === 'blob:') unreliable = true;
  banner.style.display = unreliable ? 'block' : 'none';
}

// 1) show whatever data is already saved on this phone — keepView=true so the
// app always opens on the main Insert/Delete page (the default HTML state),
// never auto-jumping to the Results Menu just because data already exists.
// This only affects which screen is shown on startup; it never touches the
// saved data itself — that is only ever removed by the person's own "Clear"
// buttons. Existing saved data is still loaded normally and is one tap away
// via the main page's "Continue ⟶" button.
renderResults(loadStore(), true);
updateStorageNote();
checkStorageReliability();

// 2) phone-side features (notifications, back button)
NativeBridge.init();
initBackButton();

// 3) show who is logged in (Name, Center, District/Tehsil/UC) and wire Logout
(function initLoginInfoBar(){
  const ctx = window.EPI_LOCATION_CONTEXT;
  const bar = document.getElementById('loginInfoBar');
  if (!ctx || !bar) return;
  document.getElementById('loginInfoName').textContent = ctx.name;
  document.getElementById('loginInfoCenter').textContent = ctx.center;
  document.getElementById('loginInfoLocation').textContent =
    `${ctx.district} ➜ ${ctx.tehsil} ➜ ${ctx.uc}`;
  bar.style.display = 'flex';
  const logoutBtn = document.getElementById('btnLogout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function(){
      if (!confirm('Logout? You will need to select Name/Center/District/Tehsil/UC again next time.')) return;
      window.epiClearLogin();
      window.location.href = 'login.html';
    });
  }
})();
