// Entry point
window.gameSettings = {
  quality: 'medium',
  sensitivity: 1.2,
  volume: 0.7,
  difficulty: 'normal'
};

let game = null;

function setProgress(p, text) {
  const fill = document.getElementById('progress-fill');
  const txt = document.getElementById('loading-text');
  if (fill) fill.style.width = p + '%';
  if (txt && text) txt.textContent = text;
}

async function boot() {
  setProgress(10, 'Inicializando áudio...');
  AudioManager.init();

  setProgress(30, 'Carregando engine 3D...');
  await new Promise(r => setTimeout(r, 200));

  setProgress(50, 'Criando mundo...');
  game = new Game();
  game.init();

  setProgress(80, 'Preparando interface...');
  await new Promise(r => setTimeout(r, 150));

  setProgress(100, 'Pronto!');
  await new Promise(r => setTimeout(r, 300));

  document.getElementById('loading-screen').classList.add('hidden');
  document.getElementById('main-menu').classList.remove('hidden');
}

// Keyboard support for desktop testing
window.addEventListener('keydown', (e) => {
  if (!game || !game.player || !game.running) return;
  const p = game.player;
  switch (e.code) {
    case 'KeyW': p.moveInput.z = 1; break;
    case 'KeyS': p.moveInput.z = -1; break;
    case 'KeyA': p.moveInput.x = -1; break;
    case 'KeyD': p.moveInput.x = 1; break;
    case 'Space': p.wantJump = true; break;
    case 'ShiftLeft': p.isSprinting = true; break;
    case 'KeyC': p.isCrouching = !p.isCrouching; break;
    case 'KeyR': p.startReload(); break;
    case 'KeyF': game.tryPickup(); break;
    case 'KeyQ': p.switchWeapon(); break;
  }
});

window.addEventListener('keyup', (e) => {
  if (!game || !game.player) return;
  const p = game.player;
  switch (e.code) {
    case 'KeyW':
    case 'KeyS': p.moveInput.z = 0; break;
    case 'KeyA':
    case 'KeyD': p.moveInput.x = 0; break;
    case 'ShiftLeft': p.isSprinting = false; break;
  }
});

// Mouse look for desktop
let mouseDown = false;
window.addEventListener('mousedown', (e) => {
  if (e.button === 0 && game && game.running) {
    game.ui.buttons.shoot = true;
  }
  if (e.button === 2) mouseDown = true;
});
window.addEventListener('mouseup', (e) => {
  if (e.button === 0 && game) game.ui.buttons.shoot = false;
  if (e.button === 2) mouseDown = false;
});
window.addEventListener('mousemove', (e) => {
  if (mouseDown && game && game.player && game.running) {
    game.player.lookInput.x = e.movementX;
    game.player.lookInput.y = e.movementY;
  }
});
window.addEventListener('contextmenu', e => e.preventDefault());

boot();
