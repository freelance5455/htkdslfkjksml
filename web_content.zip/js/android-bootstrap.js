/* Modding Workspace Android / file:// Core bootstrap.
   Prototype transport only. No Game Pack maps, MO2 live authority, or cross-device sync. */
(()=>{
  const nativeFetch=window.fetch.bind(window);
  const REGISTRY={"schema":1,"assets":{"branding.fallout.logo":{"path":"assets/branding/fallout-logo.png","type":"image","owner":"fallout","role":"franchise-logo"},"branding.fallout-new-vegas.logo":{"path":"assets/branding/fallout-new-vegas-logo.png","type":"image","owner":"fallout-new-vegas","role":"game-logo"},"background.fallout.home":{"path":"assets/backgrounds/fallout-home.jpg","type":"image","owner":"fallout","role":"home-background"},"background.fallout.franchise":{"path":"assets/backgrounds/fallout-world.jpg","type":"image","owner":"fallout","role":"franchise-background"},"background.elder-scrolls.franchise":{"path":"https://cdn.wallpapersafari.com/6/74/shnlU9.jpg","type":"remote-image","owner":"elder-scrolls","role":"temporary-background"},"card.fallout-3":{"path":"assets/cards/fallout-3-card.jpg","type":"image","owner":"fallout-3","role":"game-card"},"card.fallout-new-vegas":{"path":"assets/cards/fallout-new-vegas-card.jpg","type":"image","owner":"fallout-new-vegas","role":"game-card"},"card.fallout-4":{"path":"assets/cards/fallout-4-card.jpg","type":"image","owner":"fallout-4","role":"game-card"},"card.fallout-76":{"path":"assets/cards/fallout-76-card.jpg","type":"image","owner":"fallout-76","role":"game-card"},"game-card.fallout-3.background":{"path":"assets/game-cards/fallout-3/background.jpg","type":"image","owner":"fallout-3","role":"game-card-background"},"game-card.fallout-3.icon":{"path":"assets/game-cards/fallout-3/icon.png","type":"image","owner":"fallout-3","role":"game-card-icon"},"game-card.fallout-3.overlay":{"path":"assets/game-cards/fallout-3/overlay.png","type":"image","owner":"fallout-3","role":"game-card-overlay"},"game-card.fallout-3.hover":{"path":"assets/game-cards/fallout-3/hover.png","type":"image","owner":"fallout-3","role":"game-card-hover"},"game-card.fallout-3.selected":{"path":"assets/game-cards/fallout-3/selected.png","type":"image","owner":"fallout-3","role":"game-card-selected"},"game-card.fallout-new-vegas.background":{"path":"assets/game-cards/fallout-new-vegas/background.jpg","type":"image","owner":"fallout-new-vegas","role":"game-card-background"},"game-card.fallout-new-vegas.icon":{"path":"assets/game-cards/fallout-new-vegas/icon.png","type":"image","owner":"fallout-new-vegas","role":"game-card-icon"},"game-card.fallout-new-vegas.overlay":{"path":"assets/game-cards/fallout-new-vegas/overlay.png","type":"image","owner":"fallout-new-vegas","role":"game-card-overlay"},"game-card.fallout-new-vegas.hover":{"path":"assets/game-cards/fallout-new-vegas/hover.png","type":"image","owner":"fallout-new-vegas","role":"game-card-hover"},"game-card.fallout-new-vegas.selected":{"path":"assets/game-cards/fallout-new-vegas/selected.png","type":"image","owner":"fallout-new-vegas","role":"game-card-selected"},"game-card.fallout-4.background":{"path":"assets/game-cards/fallout-4/background.jpg","type":"image","owner":"fallout-4","role":"game-card-background"},"game-card.fallout-4.icon":{"path":"assets/game-cards/fallout-4/icon.png","type":"image","owner":"fallout-4","role":"game-card-icon"},"game-card.fallout-4.overlay":{"path":"assets/game-cards/fallout-4/overlay.png","type":"image","owner":"fallout-4","role":"game-card-overlay"},"game-card.fallout-4.hover":{"path":"assets/game-cards/fallout-4/hover.png","type":"image","owner":"fallout-4","role":"game-card-hover"},"game-card.fallout-4.selected":{"path":"assets/game-cards/fallout-4/selected.png","type":"image","owner":"fallout-4","role":"game-card-selected"},"game-card.fallout-76.background":{"path":"assets/game-cards/fallout-76/background.jpg","type":"image","owner":"fallout-76","role":"game-card-background"},"game-card.fallout-76.icon":{"path":"assets/game-cards/fallout-76/icon.png","type":"image","owner":"fallout-76","role":"game-card-icon"},"game-card.fallout-76.overlay":{"path":"assets/game-cards/fallout-76/overlay.png","type":"image","owner":"fallout-76","role":"game-card-overlay"},"game-card.fallout-76.hover":{"path":"assets/game-cards/fallout-76/hover.png","type":"image","owner":"fallout-76","role":"game-card-hover"},"game-card.fallout-76.selected":{"path":"assets/game-cards/fallout-76/selected.png","type":"image","owner":"fallout-76","role":"game-card-selected"},"branding.workspace.home-logo":{"path":"assets/branding/modding-workspace-home-logo.png","type":"image","owner":"workspace","role":"home-brand-logo"}},"slots":{"home-selected-world":"background.fallout.home","fallout-home":"background.fallout.home","elder-scrolls-home":"background.elder-scrolls.franchise","fallout-franchise":"background.fallout.franchise","elder-scrolls-franchise":"background.elder-scrolls.franchise","fallout-3-card":"game-card.fallout-3.background","fallout-new-vegas-card":"game-card.fallout-new-vegas.background","fallout-4-card":"game-card.fallout-4.background","fallout-76-card":"game-card.fallout-76.background","oblivion-card":"","elder-scrolls-online-card":"","skyrim-card":"","fallout-3-hub":"","fallout-new-vegas-hub":"background.fallout.franchise","fallout-4-hub":"","fallout-76-hub":"","oblivion-hub":"","elder-scrolls-online-hub":"","skyrim-hub":""}};
  const ICONS={"schema":1,"icons":{"menu":"\u2630","search":"\u2315","add":"\uff0b","home":"\u2302","library":"\u25a6","archive":"\u25a3","profiles":"\u2659","load-order":"\u2637","notes":"\u25a1","favorite":"\u2606"}};
  const VERSION={"product":"Modding Workspace","version":"0.20.28-mobile-bootstrap-1","display_version":"v0.20.28 \u00b7 Android Core bootstrap","channel":"Android Phone Test","build":"02028-android-bootstrap-1","database_schema":8,"release_stage":"prototype"};
  const ACTIVE_KEY='mw.android.prototype.mods';
  const ARCHIVE_KEY='mw.android.prototype.archive';
  const json=(value,status=200)=>Promise.resolve(new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json'}}));
  const read=(key)=>{try{const v=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(v)?v:[]}catch{return[]}};
  const write=(key,value)=>{localStorage.setItem(key,JSON.stringify(value));return value};
  const body=async opt=>{try{return JSON.parse(String(opt?.body||'{}'))}catch{return{}}};
  const idNext=(rows)=>rows.reduce((m,x)=>Math.max(m,Number(x?.id)||0),0)+1;
  const pathname=input=>{
    if(typeof input==='string') return input;
    try{return input?.url||String(input)}catch{return String(input)}
  };
  function apiPath(raw){
    const s=pathname(raw);
    if(s.startsWith('/api/')) return s;
    try{const u=new URL(s,location.href);return u.pathname.startsWith('/api/')?u.pathname+u.search:s}catch{return s}
  }
  window.fetch=async(input,opt={})=>{
    const raw=pathname(input), path=apiPath(input), method=String(opt?.method||'GET').toUpperCase();
    if(raw==='app-version.json'||raw.endsWith('/app-version.json')) return json(VERSION);
    if(raw==='/ui-icons.json'||raw.endsWith('/ui-icons.json')) return json(ICONS);
    if(raw==='/assets/asset-registry.json'||raw.endsWith('/assets/asset-registry.json')) return json(REGISTRY);
    if(path==='/api/health') return json({ok:true,platform:'android',runtime:'mobile-core-bootstrap',capabilities:{core_ui:true,sqlite_local:false,mo2_live_scan:false,cross_device_sync:false},notes:'Phone test mode. Data is stored locally in browser/WebView storage.'});
    if(path==='/api/assets-version') return json({version:'02028-android-bootstrap-1'});
    if(path==='/api/game-packs') return json({packs:[]});
    if(path==='/api/game-pack/fallout-new-vegas/mod-knowledge') return json({mods:[]});
    if(path==='/api/mods'&&method==='GET') return json(read(ACTIVE_KEY));
    if(path==='/api/archive'&&method==='GET') return json(read(ARCHIVE_KEY));
    if(path==='/api/mods'&&method==='POST'){const rows=read(ACTIVE_KEY), item=await body(opt);item.id=idNext([...rows,...read(ARCHIVE_KEY)]);item.archived_at=null;rows.push(item);write(ACTIVE_KEY,rows);return json(item,201)}
    const m=path.match(/^\/api\/mods\/(\d+)(?:\/(archive|restore))?$/);
    if(m){
      const id=Number(m[1]), action=m[2]||'', active=read(ACTIVE_KEY), archived=read(ARCHIVE_KEY);
      if(method==='PUT'&&!action){const i=active.findIndex(x=>Number(x.id)===id);if(i<0)return json({error:'Mod not found'},404);active[i]={...active[i],...(await body(opt)),id};write(ACTIVE_KEY,active);return json(active[i])}
      if(method==='POST'&&action==='archive'){const i=active.findIndex(x=>Number(x.id)===id);if(i<0)return json({error:'Mod not found'},404);const [item]=active.splice(i,1), payload=await body(opt);item.archive_reason=payload.reason||item.archive_reason||'';item.archived_at=new Date().toISOString();archived.push(item);write(ACTIVE_KEY,active);write(ARCHIVE_KEY,archived);return json(item)}
      if(method==='POST'&&action==='restore'){const i=archived.findIndex(x=>Number(x.id)===id);if(i<0)return json({error:'Archived mod not found'},404);const [item]=archived.splice(i,1);item.archived_at=null;active.push(item);write(ACTIVE_KEY,active);write(ARCHIVE_KEY,archived);return json(item)}
      if(method==='DELETE'&&!action){let i=active.findIndex(x=>Number(x.id)===id);if(i>=0){active.splice(i,1);write(ACTIVE_KEY,active);return json({ok:true})}i=archived.findIndex(x=>Number(x.id)===id);if(i>=0){archived.splice(i,1);write(ARCHIVE_KEY,archived);return json({ok:true})}return json({error:'Mod not found'},404)}
    }
    if(path.startsWith('/api/mo2/')) return json({error:'MO2 live data is unavailable on Android phone test mode.'},404);
    if(path.startsWith('/api/private/')) return json({error:'Private desktop runtime endpoint is unavailable in Android phone test mode.'},404);
    if(path.startsWith('/api/game-pack/')) return json({error:'Game Pack content is not bundled in this Android Core prototype.'},404);
    if(path.startsWith('/api/')) return json({error:'Endpoint not available in Android Core prototype',path},404);
    if(location.protocol==='file:'){
      // Browser fetch() commonly blocks file:// JSON, and every required local JSON above is already embedded.
      return json({error:'Local file fetch is not exposed by the phone bootstrap',resource:raw},404);
    }
    return nativeFetch(input,opt);
  };
  document.addEventListener('DOMContentLoaded',()=>{
    document.documentElement.dataset.platform='android';
    document.body.dataset.platform='android';
    const local=document.querySelector('.local-note');
    if(local) local.innerHTML='<span class="local-dot"></span><div><b>Phone test mode</b><small>Stored locally on this phone</small></div>';
    document.title='Modding Workspace · Phone Test';
  },{once:true});
})();
