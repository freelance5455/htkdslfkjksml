(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const S = P.state;
  const G = P.gemini;
  const C = (P.chat = {});

  const MAX_ATTACH = 8;
  const MAX_INLINE = 18 * 1024 * 1024;
  const MAX_TEXT_CHARS = 300000;
  const IMG_EXT = new Set(['png', 'jpg', 'jpeg', 'webp', 'heic', 'heif', 'gif', 'bmp']);
  const AUDIO_MIME = { mp3: 'audio/mp3', wav: 'audio/wav', aac: 'audio/aac', ogg: 'audio/ogg', flac: 'audio/flac' };
  const TEXT_EXT = new Set(['txt', 'md', 'markdown', 'csv', 'tsv', 'json', 'xml', 'html', 'htm', 'css', 'js', 'ts', 'py', 'dart', 'java', 'kt', 'c', 'h', 'cpp', 'cs', 'go', 'rs', 'rb', 'php', 'sh', 'yaml', 'yml', 'toml', 'ini', 'sql', 'log', 'tex', 'swift']);

  const last = (chat) => chat.messages[chat.messages.length - 1];
  const touch = (chat) => { chat.updatedAt = Date.now(); };
  const removeMsg = (chat, m) => { const i = chat.messages.indexOf(m); if (i >= 0) chat.messages.splice(i, 1); };

  // ---------------------------------------------------------------- navigation
  function resetComposer() {
    S.pending = [];
    S.imageMode = false;
    S.editingId = null;
    if (P.composer) P.composer.setText('');
    S.emit('composer');
  }

  C.newChat = function () {
    S.activeId = null;
    resetComposer();
    S.emit('chat', { kind: 'full' });
    S.emit('list');
  };

  C.open = function (id, jumpTo) {
    if (!S.byId(id)) return;
    const same = S.activeId === id;
    S.activeId = id;
    if (!same) resetComposer();
    S.jump = jumpTo || null;
    if (jumpTo) {
      S.highlightId = jumpTo;
      setTimeout(() => { S.highlightId = null; S.emit('chat', { kind: 'highlight' }); }, 2200);
    }
    S.emit('chat', { kind: 'full', scroll: jumpTo ? 'jump' : 'bottom' });
    S.emit('list');
  };

  // ---------------------------------------------------------------- attachments
  async function toAttachment(file) {
    const ext = (file.name && file.name.includes('.') ? file.name.split('.').pop() : '').toLowerCase();
    const type = file.type || '';
    let kind = null, blob = file, mime = type;
    if (type.startsWith('image/') || IMG_EXT.has(ext)) {
      kind = 'image';
      blob = await U.prepareImage(file, 2048, 0.88);
      mime = blob.type || type;
      if (blob === file && !/^image\/(png|jpeg|webp|heic|heif)$/.test(mime)) throw new Error('That image format is not supported.');
    } else if (type === 'application/pdf' || ext === 'pdf') {
      kind = 'pdf'; mime = 'application/pdf';
    } else if (AUDIO_MIME[ext] || type.startsWith('audio/')) {
      kind = 'audio'; mime = AUDIO_MIME[ext] || type;
    } else if (TEXT_EXT.has(ext) || type.startsWith('text/') || type === 'application/json') {
      kind = 'text'; mime = 'text/plain';
    } else {
      throw new Error(`${file.name || 'That file'} is not a supported type. Use images, PDFs, audio, or text and code files.`);
    }
    if (blob.size > MAX_INLINE) throw new Error(`${file.name || 'That file'} is larger than 18 MB.`);
    const id = await P.media.put(blob, { name: file.name, mime });
    return { id, kind, name: file.name || (kind === 'image' ? 'photo.jpg' : 'file'), mime, size: blob.size };
  }

  C.addFiles = async function (fileList) {
    for (const file of Array.from(fileList || [])) {
      if (S.pending.length >= MAX_ATTACH) { U.toast(`You can attach up to ${MAX_ATTACH} files per message.`); break; }
      try { S.pending.push(await toAttachment(file)); } catch (e) { U.toast(e.message); }
    }
    S.emit('composer');
  };
  C.removePending = function (id) {
    S.pending = S.pending.filter((a) => a.id !== id);
    U.haptic(8);
    S.emit('composer');
  };
  C.toggleImageMode = function () {
    S.imageMode = !S.imageMode;
    U.haptic(8);
    S.emit('composer');
  };
  C.usePrompt = function (text, asImage) {
    P.composer.setText(text);
    S.imageMode = !!asImage;
    S.emit('composer');
    P.composer.focus();
  };
  C.editImage = function (att) {
    if (!S.pending.some((a) => a.id === att.id)) S.pending.push(att);
    S.imageMode = true;
    U.haptic(8);
    S.emit('composer');
    P.composer.focus();
  };
  C.beginEdit = function (m) {
    S.editingId = m.id;
    S.pending = (m.attachments || []).slice();
    S.imageMode = !!m.imageReq;
    P.composer.setText(m.text);
    S.emit('composer');
    P.composer.focus();
  };
  C.cancelEdit = function () {
    S.editingId = null;
    S.pending = [];
    S.imageMode = false;
    P.composer.setText('');
    S.emit('composer');
  };

  // ---------------------------------------------------------------- sending
  function provisionalTitle(text) {
    const t = text.replace(/\s+/g, ' ').trim();
    if (!t) return 'New chat';
    return t.length <= 40 ? t : t.slice(0, 40).trimEnd() + '…';
  }

  C.send = async function () {
    const text = P.composer.getText().trim();
    if ((!text && !S.pending.length) || S.isBusy(S.activeId)) return;
    let chat = S.active();
    if (!chat) { chat = S.newChatObj(provisionalTitle(text)); S.chats.push(chat); S.activeId = chat.id; }
    const attachments = S.pending.slice();
    const imageReq = S.imageMode;
    const editId = S.editingId;
    P.composer.setText('');
    S.pending = [];
    S.imageMode = false;
    S.editingId = null;
    S.emit('composer');
    U.haptic(12);
    if (editId) {
      const at = chat.messages.findIndex((m) => m.id === editId);
      if (at >= 0) chat.messages.splice(at);
    }
    chat.messages.push({ id: U.uid(), role: 'user', text, ts: Date.now(), attachments, status: 'done', imageReq });
    touch(chat);
    S.saveChat(chat);
    S.emit('list');
    S.emit('chat', { kind: 'full', scroll: 'bottom' });
    await respond(chat);
  };

  C.stop = function () {
    const gen = S.gens.get(S.activeId);
    if (!gen) return;
    U.haptic(20);
    gen.abort.abort();
  };

  C.regenerate = async function (chatId, msgId) {
    const chat = S.byId(chatId);
    if (!chat || S.isBusy(chatId)) return;
    const at = chat.messages.findIndex((m) => m.id === msgId);
    if (at < 0) return;
    U.haptic(12);
    chat.messages.splice(at);
    S.saveChat(chat);
    S.emit('chat', { kind: 'full', scroll: 'bottom' });
    await respond(chat);
  };

  async function probe() {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 4000);
      await fetch('https://www.gstatic.com/generate_204', { mode: 'no-cors', cache: 'no-store', signal: ctrl.signal });
      clearTimeout(t);
      return true;
    } catch (e) { return false; }
  }
  const knownOffline = () => navigator.onLine === false;

  let streamTimer = 0, streamPending = null;
  function paintStream(chatId, msgId) {
    streamPending = { chatId, msgId };
    if (streamTimer) return;
    streamTimer = setTimeout(() => {
      streamTimer = 0;
      const p = streamPending; streamPending = null;
      if (p) S.emit('chat', { kind: 'stream', chatId: p.chatId, msgId: p.msgId });
    }, 60);
  }

  async function respond(chat) {
    if (S.gens.has(chat.id)) return;
    const trigger = last(chat);
    if (!trigger || trigger.role !== 'user') return;
    const reply = { id: U.uid(), role: 'assistant', text: '', ts: Date.now(), attachments: [], status: 'streaming', error: null };
    const ctrl = new AbortController();
    S.gens.set(chat.id, { msgId: reply.id, abort: ctrl });
    chat.messages.push(reply);
    S.emit('chat', { kind: 'append', chatId: chat.id, msgId: reply.id });
    S.emit('composer');

    if (knownOffline()) {
      removeMsg(chat, reply);
      S.gens.delete(chat.id);
      hold(chat);
      return;
    }
    for (let i = chat.messages.length - 2; i >= 0 && chat.messages[i].role === 'user'; i--) {
      const sent = chat.messages[i];
      if (sent.status !== 'done') { sent.status = 'done'; S.emit('chat', { kind: 'update', chatId: chat.id, msgId: sent.id }); }
    }

    try {
      if (trigger.imageReq) await runImage(trigger, reply, ctrl); else await runText(chat, reply, ctrl);
      reply.status = 'done';
      reply.error = null;
      if (ctrl.signal.aborted && !reply.text && !reply.attachments.length) removeMsg(chat, reply);
    } catch (e) {
      if (ctrl.signal.aborted || (e && e.aborted)) {
        reply.status = 'done';
        if (!reply.text && !reply.attachments.length) removeMsg(chat, reply);
      } else if (e && e.offline && !reply.text && !(await probe())) {
        removeMsg(chat, reply);
        hold(chat);
      } else {
        reply.status = 'error';
        reply.error = (e && e.message) || 'Something went wrong.';
      }
    } finally {
      S.gens.delete(chat.id);
    }
    touch(chat);
    S.saveChat(chat);
    S.emit('list');
    S.emit('chat', { kind: 'update', chatId: chat.id, msgId: reply.id });
    S.emit('composer');
    if (reply.status === 'done' && chat.messages.includes(reply)) { U.haptic(10); improveTitle(chat); }
  }

  async function runText(chat, reply, ctrl) {
    const contents = await buildContents(chat, reply);
    await G.stream({
      model: S.prefs.textModel,
      system: systemPrompt(chat),
      contents,
      signal: ctrl.signal,
      onText: (t) => { reply.text = t; paintStream(chat.id, reply.id); },
    });
  }

  async function runImage(trigger, reply, ctrl) {
    const parts = [];
    let total = 0;
    for (const a of trigger.attachments || []) {
      if (a.kind !== 'image') continue;
      const blob = await P.media.blob(a.id);
      if (!blob) continue;
      total += blob.size;
      parts.push(G.part.inline(a.mime, await U.blobToBase64(blob)));
    }
    if (total > MAX_INLINE) throw new G.AiError('Those images are too large to send together. Use fewer or smaller ones.');
    parts.push(G.part.text(trigger.text || 'Create an image.'));
    const r = await G.image({ model: S.prefs.imageModel, contents: [{ role: 'user', parts }], signal: ctrl.signal });
    reply.text = r.text;
    let n = 0;
    for (const img of r.images) {
      n++;
      const blob = U.base64ToBlob(img.data, img.mime);
      const id = await P.media.put(blob, { name: `Generated image ${n}`, mime: img.mime });
      reply.attachments.push({ id, kind: 'image', name: `Generated image ${n}`, mime: img.mime, size: blob.size, generated: true });
    }
  }

  function systemPrompt(chat) {
    const name = (S.profile && S.profile.name) || 'the user';
    let s = `${G.BASE_INSTRUCTIONS}\nThe user is called ${name}.\nCurrent date and time: ${U.stamp(Date.now())}.`;
    if (S.prefs.instructions) s += `\n\nInstructions from the user for every chat:\n${S.prefs.instructions}`;
    if (chat.system) s += `\n\nInstructions for this conversation:\n${chat.system}`;
    return s;
  }

  async function attachmentParts(a) {
    const blob = await P.media.blob(a.id);
    if (!blob) return [G.part.text(`[Attachment ${a.name} is no longer on this device]`)];
    if (a.kind === 'text') {
      let t = await U.blobText(blob);
      if (t.length > MAX_TEXT_CHARS) t = t.slice(0, MAX_TEXT_CHARS) + '\n[truncated]';
      return [G.part.text(`Attached file "${a.name}":\n\`\`\`\n${t}\n\`\`\``)];
    }
    return [G.part.inline(a.mime, await U.blobToBase64(blob))];
  }

  async function buildContents(chat, upTo) {
    const history = chat.messages.slice(0, chat.messages.indexOf(upTo));
    const withFiles = new Set();
    for (let i = history.length - 1; i >= 0 && withFiles.size < 2; i--) {
      if (history[i].role === 'user' && (history[i].attachments || []).length) withFiles.add(history[i].id);
    }
    const contents = [];
    let inline = 0;
    for (const m of history) {
      const parts = [];
      if (m.role === 'user') {
        for (const a of m.attachments || []) {
          if (withFiles.has(m.id)) {
            const extra = await attachmentParts(a);
            extra.forEach((p) => { if (p.inlineData) inline += p.inlineData.data.length * 0.75; });
            parts.push(...extra);
          } else parts.push(G.part.text(`[Earlier attachment: ${a.name}]`));
        }
        if (m.text) parts.push(G.part.text(m.text));
      } else {
        if (m.status === 'error' && !m.text) continue;
        if (m.text) parts.push(G.part.text(m.text));
        else if ((m.attachments || []).length) parts.push(G.part.text('[Generated an image]'));
      }
      if (!parts.length) continue;
      const role = m.role === 'user' ? 'user' : 'model';
      const prev = contents[contents.length - 1];
      if (prev && prev.role === role) prev.parts.push(...parts); else contents.push({ role, parts });
    }
    if (inline > MAX_INLINE) throw new G.AiError('The attached files are too large to send together. Remove some and try again.');
    if (!contents.length) throw new G.AiError('There is nothing to send yet.');
    return contents;
  }

  // ---------------------------------------------------------------- offline queue
  let queueTimer = null;
  function hold(chat) {
    const already = chat.messages.length && last(chat).status === 'queued';
    for (let i = chat.messages.length - 1; i >= 0 && chat.messages[i].role === 'user'; i--) chat.messages[i].status = 'queued';
    S.saveChat(chat);
    startQueue();
    S.emit('chat', { kind: 'full' });
    S.emit('composer');
    if (!already) U.toast('You are offline. Pith will send this when the connection returns.', 3800);
  }
  const hasQueued = (chat) => chat.messages.length > 0 && last(chat).role === 'user' && last(chat).status === 'queued';
  function startQueue() { if (!queueTimer) queueTimer = setInterval(C.flushQueue, 7000); }
  C.flushQueue = function () {
    const waiting = S.chats.filter((c) => hasQueued(c) && !S.gens.has(c.id));
    if (!S.chats.some(hasQueued)) { clearInterval(queueTimer); queueTimer = null; return; }
    if (knownOffline()) return;
    waiting.forEach((c) => respond(c));
  };
  C.hasQueued = hasQueued;
  C.startQueueIfNeeded = () => { if (S.chats.some(hasQueued)) startQueue(); };
  window.addEventListener('online', () => C.flushQueue());
  document.addEventListener('visibilitychange', () => { if (!document.hidden) C.flushQueue(); });

  // ---------------------------------------------------------------- titles
  const titling = new Set();
  async function improveTitle(chat) {
    if (!chat.titleAuto || titling.has(chat.id)) return;
    const u = chat.messages.find((m) => m.role === 'user' && m.text);
    const a = chat.messages.find((m) => m.role === 'assistant' && m.text);
    if (!u || !a) return;
    titling.add(chat.id);
    try {
      const clip = (s) => (s.length > 400 ? s.slice(0, 400) : s);
      const raw = await G.quickText(`Write a title of at most five words for this conversation. Reply with the title only, with no quotes and no trailing punctuation.\n\nUser: ${clip(u.text)}\nAssistant: ${clip(a.text)}`);
      const title = raw.replace(/["*#\n]/g, '').trim();
      if (title && title.length <= 60 && chat.titleAuto) {
        chat.title = title;
        chat.titleAuto = false;
        S.saveChat(chat);
        S.emit('list');
        S.emit('chat', { kind: 'title' });
      }
    } catch (e) { /* the provisional title stays */ } finally { titling.delete(chat.id); }
  }

  // ---------------------------------------------------------------- chat and message actions
  C.rename = function (chat, title) {
    const t = (title || '').trim();
    if (!t) return;
    chat.title = t;
    chat.titleAuto = false;
    S.saveChat(chat);
    S.emit('list');
    S.emit('chat', { kind: 'title' });
  };
  C.togglePin = function (chat) {
    chat.pinned = !chat.pinned;
    U.haptic(8);
    S.saveChat(chat);
    S.emit('list');
  };
  C.setSystem = function (chat, text) {
    chat.system = text;
    S.saveChat(chat);
  };

  async function dropMedia(chat) {
    for (const m of chat.messages) for (const a of m.attachments || []) await P.media.remove(a.id);
  }

  C.deleteChat = async function (chat) {
    const gen = S.gens.get(chat.id);
    if (gen) gen.abort.abort();
    S.gens.delete(chat.id);
    S.chats = S.chats.filter((c) => c.id !== chat.id);
    if (S.activeId === chat.id) { S.activeId = null; resetComposer(); }
    U.haptic(20);
    S.emit('list');
    S.emit('chat', { kind: 'full' });
    await dropMedia(chat);
    try { await P.store.del('chats', chat.id); } catch (e) { /* ignore */ }
  };

  C.deleteAll = async function () {
    S.gens.forEach((g) => g.abort.abort());
    S.gens.clear();
    const old = S.chats;
    S.chats = [];
    S.activeId = null;
    resetComposer();
    U.haptic(30);
    S.emit('list');
    S.emit('chat', { kind: 'full' });
    for (const c of old) await dropMedia(c);
    try { await P.store.clear('chats'); } catch (e) { /* ignore */ }
  };

  C.deleteMessage = function (chat, m) {
    const gen = S.gens.get(chat.id);
    if (gen && gen.msgId === m.id) gen.abort.abort();
    removeMsg(chat, m);
    U.haptic(15);
    S.saveChat(chat);
    S.emit('chat', { kind: 'full' });
  };

  // ---------------------------------------------------------------- search
  C.search = function (query) {
    const needle = query.trim().toLowerCase();
    if (needle.length < 2) return [];
    const hits = [];
    S.sorted().forEach((chat) => {
      const at = chat.title.toLowerCase().indexOf(needle);
      if (at >= 0) hits.push({ chat, msgId: null, snippet: chat.title, start: at, end: at + needle.length });
      let found = 0;
      for (const m of chat.messages) {
        if (found >= 3) break;
        const i = (m.text || '').toLowerCase().indexOf(needle);
        if (i < 0) continue;
        found++;
        const s = Math.max(0, i - 40), e = Math.min(m.text.length, i + needle.length + 90);
        const pre = s > 0 ? '…' : '', suf = e < m.text.length ? '…' : '';
        const body = m.text.slice(s, e).replace(/\s+/g, ' ');
        const from = Math.min(pre.length + body.length, pre.length + (i - s));
        hits.push({ chat, msgId: m.id, snippet: pre + body + suf, start: from, end: Math.max(from, Math.min(pre.length + body.length, from + needle.length)) });
      }
    });
    return hits;
  };
})();
