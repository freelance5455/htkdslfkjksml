/**
 * BD BLOOD DONATION - Real-Time In-App Chat Service & View
 * Donor-to-requester real-time messaging using Cloud Firestore subcollections
 */

import { 
  db, 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  serverTimestamp, 
  increment 
} from './firebase-config.js';
import { getCurrentUser, getCurrentUserProfile } from './auth.js';
import { formatTimeAgo, escapeHtml, showToast, getLanguage } from './utils.js';

export function getConversationId(userId1, userId2) {
  return [userId1, userId2].sort().join('_');
}

export async function getOrCreateConversation(otherUserId, otherUserData = {}, relatedRequestId = null) {
  const currentUser = getCurrentUser();
  const currentProfile = getCurrentUserProfile();
  if (!currentUser) throw new Error('চ্যাট করতে প্রথমে লগইন করুন।');
  if (currentUser.uid === otherUserId) throw new Error('নিজের সাথে চ্যাট করা যাবে না।');

  const convId = getConversationId(currentUser.uid, otherUserId);
  const convRef = doc(db, 'conversations', convId);
  const convSnap = await getDoc(convRef);

  if (!convSnap.exists()) {
    // If other user data is sparse, fetch from users doc
    if (!otherUserData.fullName) {
      try {
        const uSnap = await getDoc(doc(db, 'users', otherUserId));
        if (uSnap.exists()) {
          otherUserData = uSnap.data();
        }
      } catch (e) {}
    }

    const participantsData = {
      [currentUser.uid]: {
        name: currentProfile?.fullName || currentUser.displayName || 'ইউজার',
        photoURL: currentProfile?.photoURL || currentUser.photoURL || '',
        bloodGroup: currentProfile?.bloodGroup || ''
      },
      [otherUserId]: {
        name: otherUserData.fullName || otherUserData.name || 'ইউজার',
        photoURL: otherUserData.photoURL || '',
        bloodGroup: otherUserData.bloodGroup || ''
      }
    };

    const initialData = {
      id: convId,
      participants: [currentUser.uid, otherUserId],
      participantDetails: participantsData,
      lastMessage: '',
      lastMessageSenderId: '',
      lastMessageTimestamp: serverTimestamp(),
      unreadCount: {
        [currentUser.uid]: 0,
        [otherUserId]: 0
      },
      relatedRequestId: relatedRequestId || null,
      createdAt: serverTimestamp()
    };

    await setDoc(convRef, initialData);
    return { id: convId, ...initialData };
  }

  return { id: convSnap.id, ...convSnap.data() };
}

export async function sendMessage(conversationId, text, receiverId) {
  const currentUser = getCurrentUser();
  const currentProfile = getCurrentUserProfile();
  if (!currentUser) throw new Error('লগইন করুন।');
  if (!text || !text.trim()) throw new Error('বার্তা লিখুন।');

  const cleanText = text.trim();
  const messagesRef = collection(db, 'conversations', conversationId, 'messages');
  
  await addDoc(messagesRef, {
    conversationId,
    senderId: currentUser.uid,
    senderName: currentProfile?.fullName || currentUser.displayName || 'ইউজার',
    text: cleanText,
    createdAt: serverTimestamp(),
    read: false
  });

  const convRef = doc(db, 'conversations', conversationId);
  await updateDoc(convRef, {
    lastMessage: cleanText,
    lastMessageSenderId: currentUser.uid,
    lastMessageTimestamp: serverTimestamp(),
    [`unreadCount.${receiverId}`]: increment(1)
  });

  try {
    await addDoc(collection(db, 'notifications'), {
      recipientId: receiverId,
      senderId: currentUser.uid,
      conversationId,
      type: 'new_chat_message',
      title: '💬 নতুন মেসেজ',
      message: `${currentProfile?.fullName || 'সদস্য'}: ${cleanText.substring(0, 50)}`,
      read: false,
      createdAt: serverTimestamp()
    });
  } catch (e) {
    console.warn('[Chat Notification Error]', e.message);
  }
}

export function subscribeUserConversations(userId, onUpdate, onError) {
  const q = query(
    collection(db, 'conversations'),
    where('participants', 'array-contains', userId),
    orderBy('lastMessageTimestamp', 'desc'),
    limit(30)
  );

  return onSnapshot(
    q, 
    (snapshot) => {
      const convs = [];
      snapshot.forEach((doc) => {
        convs.push({ id: doc.id, ...doc.data() });
      });
      onUpdate(convs);
    },
    (err) => {
      console.warn('[Conversations Listener Error]', err.message);
      if (onError) onError(err);
    }
  );
}

export function subscribeMessages(conversationId, onUpdate, onError) {
  const q = query(
    collection(db, 'conversations', conversationId, 'messages'),
    orderBy('createdAt', 'asc'),
    limit(100)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const messages = [];
      snapshot.forEach((doc) => {
        messages.push({ id: doc.id, ...doc.data() });
      });
      onUpdate(messages);
    },
    (err) => {
      console.warn('[Messages Listener Error]', err.message);
      if (onError) onError(err);
    }
  );
}

export async function markConversationRead(conversationId, userId) {
  if (!conversationId || !userId) return;
  try {
    const convRef = doc(db, 'conversations', conversationId);
    await updateDoc(convRef, {
      [`unreadCount.${userId}`]: 0
    });
  } catch (e) {
    console.warn('[Mark Read Error]', e.message);
  }
}

/**
 * Render Chat View (Either Conversations List or Active Message Window)
 */
export async function renderChatPage(container, params = {}) {
  const user = getCurrentUser();
  const isBn = getLanguage() === 'bn';

  if (!user) {
    container.innerHTML = `
      <div class="page-container animate-slide-in">
        <div class="empty-state card">
          <div class="empty-state-icon">💬</div>
          <div class="empty-state-title">${isBn ? 'লগইন প্রয়োজন' : 'Login Required'}</div>
          <div class="empty-state-desc">${isBn ? 'রক্তদাতা ও গ্রহীতাদের সাথে সরাসরি চ্যাট করতে লগইন করুন।' : 'Please login to chat with donors.'}</div>
          <a href="#/login" class="btn btn-primary btn-sm" style="margin-top: 10px;">${isBn ? 'লগইন করুন' : 'Login'}</a>
        </div>
      </div>
    `;
    return;
  }

  // 1. If a specific user or conversation is targeted
  if (params.userId || params.convId) {
    renderActiveChatWindow(container, user, params.userId, params.convId);
    return;
  }

  // 2. Otherwise render Conversations List
  renderConversationsListView(container, user);
}

async function renderActiveChatWindow(container, currentUser, targetUserId, directConvId) {
  const isBn = getLanguage() === 'bn';
  container.innerHTML = `<div class="page-container"><div class="spinner"></div></div>`;

  let convId = directConvId;
  let otherUserId = targetUserId;
  let otherUserData = {};

  if (!convId && targetUserId) {
    const conv = await getOrCreateConversation(targetUserId);
    convId = conv.id;
  }

  // Fetch conv details
  const convRef = doc(db, 'conversations', convId);
  const convSnap = await getDoc(convRef);
  if (convSnap.exists()) {
    const cData = convSnap.data();
    otherUserId = cData.participants.find(p => p !== currentUser.uid) || targetUserId;
    otherUserData = cData.participantDetails?.[otherUserId] || {};
  }

  // If other user data empty, fetch user doc
  if (!otherUserData.name && otherUserId) {
    const uSnap = await getDoc(doc(db, 'users', otherUserId));
    if (uSnap.exists()) {
      const uData = uSnap.data();
      otherUserData = {
        name: uData.fullName || 'রক্তদাতা',
        photoURL: uData.photoURL || '',
        bloodGroup: uData.bloodGroup || ''
      };
    }
  }

  container.innerHTML = `
    <div class="chat-window animate-slide-in">
      <!-- Chat Header -->
      <div class="chat-header-bar">
        <a href="#/chat" class="header-icon-btn" style="width: 32px; height: 32px;">&larr;</a>
        <div class="donor-avatar" style="width: 36px; height: 36px; font-size: 15px; ${otherUserData.photoURL ? `background-image: url('${otherUserData.photoURL}'); background-size: cover;` : ''}">
          ${!otherUserData.photoURL ? (otherUserData.name ? otherUserData.name.charAt(0) : 'U') : ''}
        </div>
        <div style="flex: 1;">
          <div style="font-size: 14px; font-weight: 700; color: var(--text-main); line-height: 1.2;">
            ${escapeHtml(otherUserData.name || (isBn ? 'সদস্য' : 'User'))}
          </div>
          <div style="font-size: 11px; color: var(--text-muted);">
            ${otherUserData.bloodGroup ? `<span class="badge badge-blood" style="font-size: 10px; padding: 1px 6px;">${otherUserData.bloodGroup}</span> • ` : ''}
            <span style="color: var(--success-color);">অনলাইন</span>
          </div>
        </div>
      </div>

      <!-- Messages Body -->
      <div class="chat-messages-container" id="chat-messages-box">
        <div class="spinner"></div>
      </div>

      <!-- Chat Input Footer -->
      <form class="chat-input-bar" id="chat-input-form">
        <input type="text" id="chat-msg-input" class="chat-input-field" placeholder="${isBn ? 'বার্তা লিখুন...' : 'Type message...'}" autocomplete="off" required />
        <button type="submit" class="btn btn-primary" style="border-radius: var(--radius-full); padding: 9px 14px;">
          ➤
        </button>
      </form>
    </div>
  `;

  markConversationRead(convId, currentUser.uid);

  const msgBox = document.getElementById('chat-messages-box');
  const unsubscribe = subscribeMessages(convId, (messages) => {
    if (!msgBox) return;

    if (messages.length === 0) {
      msgBox.innerHTML = `
        <div class="empty-state" style="padding: 20px;">
          <div style="font-size: 32px;">👋</div>
          <div style="font-size: 13px; font-weight: 600; color: var(--text-muted);">
            ${isBn ? 'কথোপকথন শুরু করতে বার্তা পাঠান।' : 'Say hello to start the conversation.'}
          </div>
        </div>
      `;
      return;
    }

    let html = '';
    messages.forEach(msg => {
      const isSent = msg.senderId === currentUser.uid;
      const timeStr = msg.createdAt ? formatTimeAgo(msg.createdAt) : '';

      html += `
        <div class="chat-bubble ${isSent ? 'sent' : 'received'}">
          <div>${escapeHtml(msg.text)}</div>
          <div class="chat-time">${timeStr}</div>
        </div>
      `;
    });

    msgBox.innerHTML = html;
    msgBox.scrollTop = msgBox.scrollHeight;
  });

  container._unsubscribe = unsubscribe;

  // Handle send message
  const form = document.getElementById('chat-input-form');
  const input = document.getElementById('chat-msg-input');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    input.value = '';

    try {
      await sendMessage(convId, text, otherUserId);
    } catch (err) {
      showToast(err.message, 'error');
    }
  });
}

function renderConversationsListView(container, currentUser) {
  const isBn = getLanguage() === 'bn';

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>💬 ${isBn ? 'বার্তা ও চ্যাট' : 'Messages'}</span>
      </div>

      <div id="conversations-list-box">
        <div class="spinner"></div>
      </div>
    </div>
  `;

  const listBox = document.getElementById('conversations-list-box');

  const unsubscribe = subscribeUserConversations(currentUser.uid, (convs) => {
    if (!listBox) return;

    if (convs.length === 0) {
      listBox.innerHTML = `
        <div class="empty-state card">
          <div class="empty-state-icon">💬</div>
          <div class="empty-state-title">${isBn ? 'কোনো বার্তা নেই' : 'No Messages Yet'}</div>
          <div class="empty-state-desc">
            ${isBn ? 'রক্তদাতা বা সেবাগ্রহীতার সাথে যোগাযোগ করতে রক্তদাতা তালিকা থেকে মেসেজ বাটনে ক্লিক করুন।' : 'Find a donor in the directory to start a conversation.'}
          </div>
          <a href="#/donor-search" class="btn btn-primary btn-sm" style="margin-top: 10px;">
            🔍 ${isBn ? 'রক্তদাতা খুঁজুন' : 'Find Donors'}
          </a>
        </div>
      `;
      return;
    }

    let html = '';
    convs.forEach(c => {
      const otherId = c.participants.find(p => p !== currentUser.uid);
      const otherInfo = c.participantDetails?.[otherId] || {};
      const unread = c.unreadCount?.[currentUser.uid] || 0;

      html += `
        <a href="#/chat?convId=${c.id}" class="card" style="display: flex; align-items: center; gap: 12px; text-decoration: none; color: inherit; padding: 12px; margin-bottom: 8px;">
          <div class="donor-avatar" style="width: 46px; height: 46px; font-size: 18px; ${otherInfo.photoURL ? `background-image: url('${otherInfo.photoURL}'); background-size: cover;` : ''}">
            ${!otherInfo.photoURL ? (otherInfo.name ? otherInfo.name.charAt(0) : 'U') : ''}
          </div>
          <div style="flex: 1; min-width: 0;">
            <div style="display: flex; align-items: center; justify-content: space-between;">
              <span style="font-size: 14px; font-weight: 700; color: var(--text-main);">${escapeHtml(otherInfo.name || 'সদস্য')}</span>
              <span style="font-size: 10px; color: var(--text-light);">${formatTimeAgo(c.lastMessageTimestamp)}</span>
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 3px;">
              <span style="font-size: 12px; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 200px;">
                ${escapeHtml(c.lastMessage || (isBn ? 'কথোপকথন শুরু হয়েছে' : 'Conversation started'))}
              </span>
              ${unread > 0 ? `<span class="badge-counter" style="position: static;">${unread}</span>` : ''}
            </div>
          </div>
        </a>
      `;
    });

    listBox.innerHTML = html;
  });

  container._unsubscribe = unsubscribe;
}
