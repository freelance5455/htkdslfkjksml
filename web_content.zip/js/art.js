/* ============================================================
   AETHERVALE — Procedural pixel art (no external assets)
   ============================================================ */
const Art = (() => {
  const cache = new Map();

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const x = c.getContext('2d');
    x.imageSmoothingEnabled = false;
    return { c, x };
  }
  function P(x, px, py, w, h, col) { x.fillStyle = col; x.fillRect(px, py, w, h); }

  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) + amt, g = ((n >> 8) & 255) + amt, b = (n & 255) + amt;
    r = Math.max(0, Math.min(255, r)); g = Math.max(0, Math.min(255, g)); b = Math.max(0, Math.min(255, b));
    return '#' + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
  }

  /* ---------------- Humanoid (player, NPCs) ---------------- */
  // dir: 0 down, 1 up, 2 left, 3 right ; frame 0..3
  function humanoid(opts, dir, frame) {
    const key = `h:${opts.key}:${dir}:${frame}`;
    if (cache.has(key)) return cache.get(key);
    const { c, x } = makeCanvas(16, 20);
    const skin = opts.skin || '#e8b98a', skinD = shade(skin, -40);
    const hair = opts.hair || '#40302a';
    const tunic = opts.tunic || '#5b7fbf', tunicD = shade(tunic, -35), tunicL = shade(tunic, 25);
    const pants = opts.pants || '#3b3550';
    const boot = opts.boot || '#2a2330';
    const bob = (frame === 1 || frame === 3) ? 0 : 0;
    const legA = frame === 1 ? 1 : frame === 3 ? -1 : 0;

    // shadow
    P(x, 4, 19, 8, 1, 'rgba(0,0,0,0.30)');
    // legs
    P(x, 5, 14 + Math.max(0, legA), 2, 4 - Math.max(0, legA), pants);
    P(x, 9, 14 + Math.max(0, -legA), 2, 4 - Math.max(0, -legA), pants);
    P(x, 5, 18, 2, 1, boot); P(x, 9, 18, 2, 1, boot);
    // torso
    P(x, 4, 8 + bob, 8, 6, tunic);
    P(x, 4, 8 + bob, 8, 1, tunicL);
    P(x, 4, 13 + bob, 8, 1, tunicD);
    if (opts.belt) P(x, 4, 12 + bob, 8, 1, opts.belt);
    // arms
    const ao = frame === 1 ? -1 : frame === 3 ? 1 : 0;
    P(x, 3, 9 + bob + ao, 1, 4, tunic); P(x, 12, 9 + bob - ao, 1, 4, tunic);
    P(x, 3, 13 + bob + ao, 1, 1, skin); P(x, 12, 13 + bob - ao, 1, 1, skin);
    // head
    P(x, 4, 2 + bob, 8, 6, skin);
    P(x, 4, 7 + bob, 8, 1, skinD);
    // hair
    P(x, 4, 1 + bob, 8, 2, hair);
    if (dir === 1) { P(x, 4, 1 + bob, 8, 6, hair); }
    else if (dir === 0) {
      P(x, 3, 2 + bob, 1, 4, hair); P(x, 12, 2 + bob, 1, 4, hair);
      P(x, 6, 5 + bob, 1, 1, '#22202c'); P(x, 9, 5 + bob, 1, 1, '#22202c');
      if (opts.mouth !== false) P(x, 7, 6 + bob, 2, 1, shade(skin, -60));
    } else {
      const flip = dir === 2 ? -1 : 1;
      const ex = dir === 2 ? 5 : 9;
      P(x, dir === 2 ? 3 : 12, 2 + bob, 1, 5, hair);
      P(x, ex, 5 + bob, 1, 1, '#22202c');
      void flip;
    }
    if (opts.hood) {
      P(x, 3, 1 + bob, 10, 6, opts.hood);
      if (dir === 0) { P(x, 5, 4 + bob, 6, 3, '#1a1622'); P(x, 6, 5 + bob, 1, 1, opts.eye || '#ffd24d'); P(x, 9, 5 + bob, 1, 1, opts.eye || '#ffd24d'); }
    }
    if (opts.crest) P(x, 7, 0 + bob, 2, 2, opts.crest);
    // weapon
    if (opts.weapon) {
      const wc = opts.weaponColor || '#cfd6e4';
      if (dir === 2) { P(x, 2, 6 + bob, 1, 8, wc); P(x, 1, 12 + bob, 3, 1, '#7a5a3a'); }
      else if (dir === 3) { P(x, 13, 6 + bob, 1, 8, wc); P(x, 12, 12 + bob, 3, 1, '#7a5a3a'); }
      else if (dir === 0) { P(x, 13, 7 + bob, 1, 7, wc); P(x, 12, 13 + bob, 3, 1, '#7a5a3a'); }
      else { P(x, 2, 7 + bob, 1, 7, wc); }
    }
    cache.set(key, c);
    return c;
  }

  /* ---------------- Enemies ---------------- */
  function enemy(art, color, frame, big) {
    const key = `e:${art}:${color}:${frame}:${big ? 1 : 0}`;
    if (cache.has(key)) return cache.get(key);
    const S = big || 20;
    const { c, x } = makeCanvas(S, S);
    const d = shade(color, -50), l = shade(color, 40);
    const f = frame % 4;
    const bob = (f === 1 || f === 3) ? 1 : 0;

    if (art === 'slime') {
      const sq = f === 1 ? 1 : f === 3 ? -1 : 0;
      P(x, 3, S - 1, S - 6, 1, 'rgba(0,0,0,0.3)');
      P(x, 3, S - 9 + sq, 14, 8 - sq, color);
      P(x, 5, S - 11 + sq, 10, 3, color);
      P(x, 5, S - 10 + sq, 4, 2, l);
      P(x, 7, S - 7, 2, 2, '#1a1622'); P(x, 12, S - 7, 2, 2, '#1a1622');
      P(x, 3, S - 2, 14, 1, d);
    } else if (art === 'boar' || art === 'wolf') {
      const legA = f === 1 ? 1 : f === 3 ? -1 : 0;
      P(x, 3, S - 1, 14, 1, 'rgba(0,0,0,0.3)');
      P(x, 3, 8 - bob, 12, 6, color);           // body
      P(x, 3, 8 - bob, 12, 1, l);
      P(x, 3, 13 - bob, 12, 1, d);
      P(x, 13, 5 - bob, 5, 5, color);           // head
      P(x, 16, 7 - bob, 1, 1, '#ffe08a');       // eye
      if (art === 'wolf') { P(x, 13, 3 - bob, 1, 2, d); P(x, 16, 3 - bob, 1, 2, d); P(x, 1, 6 - bob, 2, 4, color); }
      else { P(x, 17, 8 - bob, 1, 1, '#fff'); P(x, 1, 9 - bob, 2, 2, d); }
      P(x, 4, 14 + legA, 2, 4 - legA, d);
      P(x, 12, 14 - legA, 2, 4 + legA, d);
      P(x, 7, 14, 2, 4, shade(color, -25));
    } else if (art === 'wisp') {
      const r = 5 + (f % 2);
      P(x, 10 - r, 10 - r, r * 2, r * 2, color + '');
      x.globalAlpha = 0.5; P(x, 10 - r - 2, 10 - r - 2, r * 2 + 4, r * 2 + 4, color); x.globalAlpha = 1;
      P(x, 8, 8, 4, 4, '#ffffff');
      P(x, 6 + f, 3, 1, 1, l); P(x, 14 - f, 15, 1, 1, l);
    } else if (art === 'lurker') {
      P(x, 3, S - 1, 14, 1, 'rgba(0,0,0,0.3)');
      P(x, 4, 7 - bob, 12, 9, color);
      P(x, 4, 7 - bob, 12, 1, l);
      P(x, 2, 9 - bob, 2, 6, d); P(x, 16, 9 - bob, 2, 6, d);
      P(x, 6, 4 - bob, 8, 4, color);
      P(x, 7, 5 - bob, 2, 2, '#c6ff6a'); P(x, 11, 5 - bob, 2, 2, '#c6ff6a');
      P(x, 6, 16, 3, 3, d); P(x, 11, 16, 3, 3, d);
      P(x, 7, 12 - bob, 6, 1, d);
    } else if (art === 'bandit') {
      return (cache.set(key, humanoid({ key: 'bandit' + color, skin: '#d6a172', hair: '#2a2028', tunic: color, pants: '#39313c', hood: '#3a2f38', eye: '#ffd24d', weapon: true, weaponColor: '#b9c2d0' }, 0, frame)), cache.get(key));
    } else if (art === 'fiend') {
      P(x, 3, S - 1, 14, 1, 'rgba(0,0,0,0.35)');
      P(x, 5, 7 - bob, 10, 8, color);
      P(x, 5, 7 - bob, 10, 1, l);
      P(x, 6, 3 - bob, 8, 5, shade(color, -15));
      P(x, 4, 1 - bob, 2, 3, d); P(x, 14, 1 - bob, 2, 3, d);   // horns
      P(x, 7, 5 - bob, 2, 2, '#fff2b0'); P(x, 11, 5 - bob, 2, 2, '#fff2b0');
      P(x, 3, 8 - bob, 2, 5, d); P(x, 15, 8 - bob, 2, 5, d);
      P(x, 6, 15, 3, 4, d); P(x, 11, 15, 3, 4, d);
      P(x, 8 + (f % 2), 0, 1, 2, '#ffd27a');
    } else if (art === 'revenant') {
      x.globalAlpha = 0.9;
      P(x, 5, 6 - bob, 10, 9, color);
      P(x, 4, 2 - bob, 12, 6, shade(color, -30));
      P(x, 7, 4 - bob, 2, 2, '#ffffff'); P(x, 11, 4 - bob, 2, 2, '#ffffff');
      x.globalAlpha = 0.55;
      P(x, 6, 15 - bob, 8, 3, color); P(x, 7, 17 - bob, 6, 2, color);
      x.globalAlpha = 1;
      P(x, 2, 8 - bob, 3, 2, shade(color, -20)); P(x, 15, 8 - bob, 3, 2, shade(color, -20));
    } else if (art === 'golem') {
      const Z = big || 36; // big blocky
      P(x, 4, Z - 1, Z - 8, 1, 'rgba(0,0,0,0.4)');
      P(x, 8, 10 - bob, Z - 16, 16, color);
      P(x, 8, 10 - bob, Z - 16, 2, l);
      P(x, 10, 4 - bob, Z - 20, 7, shade(color, -15));
      P(x, 12, 6 - bob, 3, 3, '#fff3c4'); P(x, Z - 15, 6 - bob, 3, 3, '#fff3c4');
      P(x, 2, 12 - bob, 6, 12, d); P(x, Z - 8, 12 - bob, 6, 12, d);
      P(x, 9, 26, 6, Z - 27, d); P(x, Z - 15, 26, 6, Z - 27, d);
      for (let i = 0; i < 4; i++) P(x, 11 + i * 4, 16 - bob + (i % 2), 2, 4, '#ffb347');
    } else if (art === 'rift') {
      const Z = big || 44;
      P(x, 6, Z - 1, Z - 12, 1, 'rgba(0,0,0,0.45)');
      P(x, Z / 2 - 8, 12 - bob, 16, 20, shade(color, -40));
      P(x, Z / 2 - 8, 12 - bob, 16, 2, color);
      P(x, Z / 2 - 6, 4 - bob, 12, 9, shade(color, -25));
      P(x, Z / 2 - 4, 7 - bob, 3, 3, '#fdf1ff'); P(x, Z / 2 + 1, 7 - bob, 3, 3, '#fdf1ff');
      P(x, Z / 2 - 14, 14 - bob, 5, 14, shade(color, -30));
      P(x, Z / 2 + 9, 14 - bob, 5, 14, shade(color, -30));
      P(x, Z / 2 - 7, 32, 5, Z - 33, shade(color, -45));
      P(x, Z / 2 + 2, 32, 5, Z - 33, shade(color, -45));
      for (let i = 0; i < 5; i++) {
        const a = (f * 0.4 + i * 1.25);
        P(x, Z / 2 + Math.round(Math.cos(a) * 16) - 1, 18 + Math.round(Math.sin(a) * 12) - 1, 3, 3, '#dcb8ff');
      }
      P(x, Z / 2 - 2, 0, 4, 4, '#ffffff');
    }
    cache.set(key, c);
    return c;
  }

  /* ---------------- World objects ---------------- */
  function tree(biomeKey, variant) {
    const key = `t:${biomeKey}:${variant}`;
    if (cache.has(key)) return cache.get(key);
    const b = BIOMES[biomeKey];
    const { c, x } = makeCanvas(24, 32);
    const trunk = '#5a4232';
    P(x, 4, 31, 16, 1, 'rgba(0,0,0,0.28)');
    P(x, 10, 20, 4, 11, trunk);
    P(x, 10, 20, 1, 11, shade(trunk, 20));
    const leaf = b.tree, leafL = shade(leaf, 26), leafD = shade(leaf, -22);
    const style = b.treeStyle || 'broad';
    const off = variant % 2;
    if (style === 'pine' || style === 'snowpine') {
      for (let i = 0; i < 4; i++) {
        const w = 18 - i * 4;
        P(x, 12 - w / 2, 18 - i * 5, w, 5, i % 2 ? leaf : leafD);
        if (style === 'snowpine') P(x, 12 - w / 2, 18 - i * 5, w, 1, '#dfeaf5');
      }
    } else if (style === 'birch') {
      P(x, 10, 18, 4, 13, '#e6e2d4'); P(x, 10, 20, 1, 11, '#b8b2a2');
      P(x, 11, 22, 3, 1, '#4a463c'); P(x, 10, 26, 3, 1, '#4a463c');
      P(x, 4 + off, 6, 16, 12, leaf); P(x, 6 + off, 3, 12, 4, leafL); P(x, 4 + off, 15, 16, 3, leafD);
    } else if (style === 'cherry') {
      P(x, 3 + off, 7, 18, 12, leaf); P(x, 5 + off, 3, 14, 5, leafL);
      P(x, 3 + off, 17, 18, 3, leafD);
      P(x, 2, 12, 2, 2, '#ffffff'); P(x, 20, 9, 2, 2, '#ffffff');
    } else if (style === 'dark') {
      P(x, 9, 18, 6, 13, '#4a3a2c');
      P(x, 1 + off, 5, 22, 14, leaf); P(x, 3 + off, 2, 18, 4, leafD); P(x, 1 + off, 16, 22, 4, shade(leaf, -34));
    } else if (style === 'jungle') {
      P(x, 10, 12, 4, 19, '#4f5a2f');
      P(x, 2 + off, 2, 20, 8, leaf); P(x, 0, 6, 6, 3, leafD); P(x, 18, 8, 6, 3, leafD);
      P(x, 5 + off, 9, 14, 4, leafL);
    } else if (style === 'bamboo') {
      for (let i = 0; i < 3; i++) {
        const bx = 6 + i * 6, bh = 22 + (i % 2) * 6;
        P(x, bx, 31 - bh, 3, bh, leaf);
        for (let s2 = 0; s2 < bh; s2 += 6) P(x, bx, 31 - bh + s2, 3, 1, leafD);
      }
    } else if (style === 'mangrove') {
      P(x, 11, 16, 3, 12, '#5a4232');
      P(x, 7, 26, 3, 5, '#5a4232'); P(x, 15, 26, 3, 5, '#5a4232');
      P(x, 3 + off, 5, 18, 11, leaf); P(x, 5 + off, 2, 14, 4, leafL); P(x, 3 + off, 14, 18, 3, leafD);
    } else if (style === 'palm') {
      P(x, 11, 12, 3, 19, '#7a5c3a');
      P(x, 4, 10, 8, 2, leaf); P(x, 13, 10, 8, 2, leaf);
      P(x, 2, 12, 4, 2, leafD); P(x, 19, 12, 4, 2, leafD);
      P(x, 8, 7, 9, 3, leafL); P(x, 11, 13, 3, 2, '#c08a3a');
    } else if (style === 'dead') {
      P(x, 11, 8, 2, 23, '#3b2c2a');
      P(x, 5, 12, 6, 2, '#3b2c2a'); P(x, 13, 15, 6, 2, '#3b2c2a');
      P(x, 4, 9, 3, 3, shade(leaf, -10)); P(x, 17, 12, 3, 3, shade(leaf, -10));
    } else if (style === 'crystal') {
      P(x, 9, 10, 6, 21, shade(leaf, -20));
      P(x, 10, 2, 4, 9, leaf); P(x, 11, 4, 1, 6, '#ffffff');
      P(x, 5, 16, 3, 6, leaf); P(x, 17, 13, 3, 8, leaf);
    } else if (style === 'fungus_red' || style === 'fungus_blue') {
      const cap = leaf, stem = style === 'fungus_red' ? '#6d2a2a' : '#1f5f62';
      P(x, 10, 12, 4, 19, stem);
      P(x, 3, 6, 18, 7, cap); P(x, 5, 3, 14, 4, shade(cap, 22)); P(x, 3, 12, 18, 2, shade(cap, -26));
      P(x, 7, 16, 2, 2, cap); P(x, 16, 18, 2, 2, cap);
    } else if (style === 'mushroom') {
      P(x, 10, 14, 4, 17, '#e8e0d0');
      P(x, 3, 7, 18, 8, leaf); P(x, 6, 4, 12, 4, shade(leaf, 20));
      P(x, 6, 9, 3, 3, '#ffffff'); P(x, 13, 11, 3, 3, '#ffffff');
    } else if (style === 'coral') {
      P(x, 10, 20, 4, 11, shade(leaf, -18));
      P(x, 6, 14, 3, 8, leaf); P(x, 15, 12, 3, 10, leafL); P(x, 10, 10, 4, 10, leaf);
      P(x, 4, 12, 3, 3, leafL); P(x, 17, 9, 3, 3, leafL);
    } else {
      P(x, 3 + off, 8, 18, 12, leaf);
      P(x, 6 + off, 3, 12, 6, leaf);
      P(x, 5 + off, 5, 6, 4, leafL);
      P(x, 3 + off, 17, 18, 3, leafD);
      P(x, 1 + off, 11, 2, 6, leaf); P(x, 21 + off, 11, 2, 6, leaf);
    }
    cache.set(key, c);
    return c;
  }

  function rock(biomeKey, variant) {
    const key = `r:${biomeKey}:${variant}`;
    if (cache.has(key)) return cache.get(key);
    const b = BIOMES[biomeKey];
    const { c, x } = makeCanvas(20, 18);
    const col = b.rock, l = shade(col, 28), d = shade(col, -30);
    P(x, 2, 17, 16, 1, 'rgba(0,0,0,0.25)');
    const w = variant % 2 ? 16 : 12;
    P(x, (20 - w) / 2, 7, w, 10, col);
    P(x, (20 - w) / 2 + 2, 4, w - 4, 4, col);
    P(x, (20 - w) / 2 + 3, 5, 4, 3, l);
    P(x, (20 - w) / 2, 15, w, 2, d);
    cache.set(key, c);
    return c;
  }

  function building(kind) {
    const key = `b:${kind}`;
    if (cache.has(key)) return cache.get(key);
    const W = kind === 'hall' ? 80 : 64, H = kind === 'hall' ? 72 : 60;
    const { c, x } = makeCanvas(W, H);
    const roofCol = { auction: '#b5566e', smith: '#8a5a3a', gem: '#3f7fa8', enchant: '#6a4e9e', inherit: '#a88a3a', hall: '#7a6350', shop: '#4e8a5a' }[kind] || '#7a6350';
    const wall = '#d9c9a8', wallD = '#b8a486', wood = '#6a4f38';
    P(x, 2, H - 2, W - 4, 2, 'rgba(0,0,0,0.3)');
    // walls
    P(x, 6, 26, W - 12, H - 28, wall);
    P(x, 6, H - 8, W - 12, 6, wallD);
    // roof
    for (let i = 0; i < 14; i++) {
      const w = W - i * (W / 30);
      P(x, (W - w) / 2, 26 - i * 2, w, 2, i % 2 ? roofCol : shade(roofCol, -18));
    }
    P(x, W / 2 - 2, 0, 4, 4, shade(roofCol, 40));
    // door
    P(x, W / 2 - 7, H - 24, 14, 22, wood);
    P(x, W / 2 - 5, H - 22, 10, 18, shade(wood, -22));
    P(x, W / 2 + 2, H - 14, 2, 2, '#e6c86a');
    // windows
    P(x, 12, H - 26, 10, 9, '#2b3b52'); P(x, 13, H - 25, 4, 4, '#7fb0d6');
    P(x, W - 22, H - 26, 10, 9, '#2b3b52'); P(x, W - 21, H - 25, 4, 4, '#7fb0d6');
    // sign
    P(x, W / 2 - 10, 28, 20, 8, wood);
    P(x, W / 2 - 8, 30, 16, 4, shade(roofCol, 30));
    cache.set(key, c);
    return c;
  }

  /* ---------------- Item icons ---------------- */
  function itemIcon(item, size) {
    const S = size || 24;
    const key = `i:${item.id}:${S}`;
    if (cache.has(key)) return cache.get(key);
    const { c, x } = makeCanvas(S, S);
    const k = S / 24;
    x.save(); x.scale(k, k);
    const ic = item.icon;
    const rc = RARITY[item.rarity || 'common'].color;
    const steel = '#cfd6e4', steelD = '#8b93a5', gold = '#e8c25a', wood = '#7a5a3a';
    if (ic === 'sword' || ic === 'spear' || ic === 'axe') {
      P(x, 11, 2, 3, 13, steel); P(x, 11, 2, 1, 13, '#f2f6ff'); P(x, 13, 4, 1, 11, steelD);
      if (ic === 'axe') { P(x, 5, 3, 6, 6, steel); P(x, 5, 3, 6, 1, '#f2f6ff'); }
      if (ic === 'spear') { P(x, 10, 0, 5, 4, steel); }
      P(x, 8, 15, 9, 2, gold); P(x, 11, 17, 3, 6, wood);
      P(x, 10, 22, 5, 2, gold);
    } else if (ic === 'armor') {
      P(x, 5, 4, 14, 16, rc === '#cfd3e0' ? '#8b93a5' : rc);
      P(x, 5, 4, 14, 2, '#f2f6ff'); P(x, 5, 18, 14, 2, steelD);
      P(x, 9, 4, 6, 6, '#2d3444'); P(x, 3, 6, 3, 8, steelD); P(x, 18, 6, 3, 8, steelD);
      P(x, 11, 12, 2, 6, gold);
    } else if (ic === 'helm') {
      P(x, 5, 6, 14, 11, rc === '#cfd3e0' ? '#8b93a5' : rc);
      P(x, 5, 6, 14, 2, '#f2f6ff');
      P(x, 8, 11, 8, 4, '#2d3444'); P(x, 4, 14, 16, 3, steelD);
      P(x, 11, 2, 2, 5, gold);
    } else if (ic === 'boots') {
      P(x, 5, 7, 6, 10, '#6b4a33'); P(x, 13, 7, 6, 10, '#6b4a33');
      P(x, 5, 15, 8, 3, '#39281c'); P(x, 13, 15, 8, 3, '#39281c');
      P(x, 5, 7, 6, 2, '#8a6244'); P(x, 13, 7, 6, 2, '#8a6244');
    } else if (ic === 'ring') {
      for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; P(x, 12 + Math.round(Math.cos(a) * 7) - 1, 14 + Math.round(Math.sin(a) * 7) - 1, 3, 3, gold); }
      P(x, 10, 2, 5, 5, rc);
    } else if (ic === 'gem' || ic === 'gem2') {
      const col = item.gemColor || rc;
      P(x, 8, 4, 8, 4, shade(col, 30)); P(x, 6, 8, 12, 8, col); P(x, 9, 16, 6, 4, shade(col, -35));
      P(x, 9, 6, 3, 4, '#ffffff');
      if (ic === 'gem2') { P(x, 4, 2, 2, 2, '#fff'); P(x, 19, 12, 2, 2, '#fff'); }
    } else if (ic === 'stone' || ic === 'stone2') {
      const col = ic === 'stone2' ? '#9fd8ff' : '#a9b0bd';
      P(x, 6, 7, 12, 11, col); P(x, 6, 7, 12, 2, shade(col, 35)); P(x, 6, 16, 12, 2, shade(col, -40));
      P(x, 9, 4, 6, 3, col);
      P(x, 10, 10, 4, 5, ic === 'stone2' ? '#e8fbff' : '#cfd6e4');
    } else if (ic === 'scroll' || ic === 'scroll2') {
      P(x, 5, 4, 14, 16, '#e8ddbd'); P(x, 5, 4, 14, 2, '#c9b894'); P(x, 5, 18, 14, 2, '#c9b894');
      P(x, 3, 3, 3, 18, '#8a6d45'); P(x, 18, 3, 3, 18, '#8a6d45');
      const inkc = ic === 'scroll2' ? '#8e5bd0' : '#b5566e';
      P(x, 8, 8, 8, 2, inkc); P(x, 8, 12, 6, 2, inkc); P(x, 8, 15, 8, 2, inkc);
    } else if (ic === 'essence') {
      P(x, 8, 3, 8, 3, '#8a6d45'); P(x, 7, 6, 10, 14, 'rgba(180,230,255,0.35)');
      P(x, 8, 10, 8, 9, '#f5b53c'); P(x, 9, 12, 3, 4, '#ffe9a8');
      P(x, 7, 6, 10, 1, '#dff3ff');
    } else if (ic === 'potion' || ic === 'potion2') {
      P(x, 10, 2, 4, 4, '#b8c4d4'); P(x, 7, 6, 10, 15, 'rgba(210,235,255,0.3)');
      const col = ic === 'potion2' ? '#9ef7ff' : '#ff4d6a';
      P(x, 8, 10, 8, 10, col); P(x, 9, 12, 2, 4, '#ffffff'); P(x, 8, 19, 8, 1, shade(col, -40));
    } else if (ic === 'pelt') {
      P(x, 4, 6, 16, 12, '#9a8f7e'); P(x, 4, 6, 16, 2, '#c1b6a2');
      P(x, 2, 8, 3, 4, '#9a8f7e'); P(x, 19, 8, 3, 4, '#9a8f7e');
      P(x, 8, 10, 3, 3, '#6e6557'); P(x, 13, 13, 3, 3, '#6e6557');
    } else if (ic === 'relic') {
      P(x, 5, 6, 14, 14, '#7f8b72'); P(x, 5, 6, 14, 2, '#a3b094');
      P(x, 9, 10, 6, 6, '#d8e6a8'); P(x, 11, 12, 2, 2, '#3b4230');
      P(x, 5, 18, 14, 2, '#5c6653');
    } else if (ic === 'core') {
      P(x, 7, 5, 10, 14, '#4a3530'); P(x, 9, 8, 6, 8, '#ff8c3a'); P(x, 10, 10, 3, 4, '#ffe08a');
      P(x, 7, 5, 10, 1, '#6e4f43');
    } else if (ic === 'frost') {
      P(x, 11, 2, 3, 20, '#cdeeff'); P(x, 4, 10, 17, 3, '#cdeeff');
      P(x, 6, 5, 3, 3, '#eaf8ff'); P(x, 16, 15, 3, 3, '#eaf8ff');
    } else if (ic === 'rift') {
      P(x, 10, 2, 5, 20, '#c07bff'); P(x, 8, 6, 3, 12, '#8e6bff'); P(x, 14, 5, 3, 13, '#8e6bff');
      P(x, 11, 8, 2, 7, '#fdf1ff');
    } else { // dust / fallback
      P(x, 6, 12, 4, 4, '#9aa0ad'); P(x, 12, 9, 5, 5, '#b4bac7'); P(x, 9, 16, 6, 3, '#7e848f');
      P(x, 13, 15, 3, 3, '#cfd6e4');
    }
    x.restore();
    cache.set(key, c);
    return c;
  }

  return { humanoid, enemy, tree, rock, building, itemIcon, makeCanvas, shade };
})();
