    // Background music controls (settings)
    function setBackgroundMusicMuted(muted) {
        const music = document.getElementById('ffm26-background-music');
        if (!music) return;
        music.muted = !!muted;
        try { localStorage.setItem('ffm26_music_muted', music.muted ? '1' : '0'); } catch (_) {}
    }
    function setBackgroundMusicVolume(value) {
        const music = document.getElementById('ffm26-background-music');
        const volume = Math.max(0, Math.min(100, Number(value) || 0));
        if (music) music.volume = volume / 100;
        const label = document.getElementById('music-volume-value');
        if (label) label.textContent = volume + '%';
        try { localStorage.setItem('ffm26_music_volume', String(volume)); } catch (_) {}
    }

    // Global State
    let state = {
        tokens: 500,
        currentTier: 4,
        lang: 'ar',
        teams: {}
    };
    let pendingRestoreState = null;
/* ---- FFM 26 sealed saves: 4 layers (integrity digest -> ChaCha20 -> HMAC-CTR stream -> keyed byte shuffle) + encrypt-then-MAC ---- */
const FFMSec = (function () {
  const K = new Uint32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
  const W = new Uint32Array(64);
  function sha256(m) {
    const l = m.length, nb = ((l + 9 + 63) >> 6) << 6, p = new Uint8Array(nb); p.set(m); p[l] = 0x80;
    const dv = new DataView(p.buffer); dv.setUint32(nb - 4, (l << 3) >>> 0); dv.setUint32(nb - 8, Math.floor(l / 0x20000000));
    let h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a, h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;
    for (let o = 0; o < nb; o += 64) {
      for (let i = 0; i < 16; i++) W[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) { const a = W[i - 15], b = W[i - 2]; W[i] = (W[i - 16] + (((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3)) + W[i - 7] + (((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10))) >>> 0; }
      let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
      for (let i = 0; i < 64; i++) {
        const t1 = (h + (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + K[i] + W[i]) >>> 0;
        const t2 = ((((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c))) >>> 0;
        h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0; h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + h) >>> 0;
    }
    const out = new Uint8Array(32), ov = new DataView(out.buffer); [h0, h1, h2, h3, h4, h5, h6, h7].forEach((v, i) => ov.setUint32(i * 4, v)); return out;
  }
  const cat = (...a) => { let n = 0; a.forEach(x => n += x.length); const o = new Uint8Array(n); let p = 0; a.forEach(x => { o.set(x, p); p += x.length; }); return o; };
  function hmac(key, msg) {
    if (key.length > 64) key = sha256(key); const k = new Uint8Array(64); k.set(key);
    const ip = new Uint8Array(64), op = new Uint8Array(64); for (let i = 0; i < 64; i++) { ip[i] = k[i] ^ 0x36; op[i] = k[i] ^ 0x5c; }
    return sha256(cat(op, sha256(cat(ip, msg))));
  }
  const utf8 = (s) => new TextEncoder().encode(s), unutf8 = (b) => new TextDecoder().decode(b);
  function chacha20(key, nonce, data) {
    const out = new Uint8Array(data.length), st = new Uint32Array(16), x = new Uint32Array(16), kv = new DataView(key.buffer, key.byteOffset, 32), nv = new DataView(nonce.buffer, nonce.byteOffset, 12);
    st[0] = 0x61707865; st[1] = 0x3320646e; st[2] = 0x79622d32; st[3] = 0x6b206574;
    for (let i = 0; i < 8; i++) st[4 + i] = kv.getUint32(i * 4, true); st[13] = nv.getUint32(0, true); st[14] = nv.getUint32(4, true); st[15] = nv.getUint32(8, true);
    const qr = (a, b, c, d) => { x[a] += x[b]; x[d] ^= x[a]; x[d] = (x[d] << 16) | (x[d] >>> 16); x[c] += x[d]; x[b] ^= x[c]; x[b] = (x[b] << 12) | (x[b] >>> 20); x[a] += x[b]; x[d] ^= x[a]; x[d] = (x[d] << 8) | (x[d] >>> 24); x[c] += x[d]; x[b] ^= x[c]; x[b] = (x[b] << 7) | (x[b] >>> 25); };
    for (let pos = 0, ctr = 1; pos < data.length; pos += 64, ctr++) {
      st[12] = ctr; x.set(st);
      for (let r = 0; r < 10; r++) { qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15); qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14); }
      for (let i = 0; i < 16; i++) { const w = (x[i] + st[i]) >>> 0, j = pos + i * 4; if (j < data.length) out[j] = data[j] ^ (w & 255); if (j + 1 < data.length) out[j + 1] = data[j + 1] ^ ((w >>> 8) & 255); if (j + 2 < data.length) out[j + 2] = data[j + 2] ^ ((w >>> 16) & 255); if (j + 3 < data.length) out[j + 3] = data[j + 3] ^ (w >>> 24); }
    }
    return out;
  }
  function ctrStream(key, nonce, data) { // layer 2: keyed SHA-256 in counter mode
    const out = new Uint8Array(data.length), blk = new Uint8Array(nonce.length + 4);
    blk.set(nonce);
    for (let pos = 0, c = 0; pos < data.length; pos += 32, c++) {
      blk[nonce.length] = c >>> 24; blk[nonce.length + 1] = (c >>> 16) & 255; blk[nonce.length + 2] = (c >>> 8) & 255; blk[nonce.length + 3] = c & 255;
      const ks = sha256(cat(key, blk)); for (let i = 0; i < 32 && pos + i < data.length; i++) out[pos + i] = data[pos + i] ^ ks[i];
    }
    return out;
  }
  function permutation(key, n) { // layer 3: keyed shuffle (xorshift128 seeded by key)
    const s = new Uint32Array(4), dv = new DataView(key.buffer, key.byteOffset, 16); for (let i = 0; i < 4; i++) s[i] = dv.getUint32(i * 4) | 1;
    const nx = () => { let t = s[3]; const q = s[0]; s[3] = s[2]; s[2] = s[1]; s[1] = q; t ^= t << 11; t ^= t >>> 8; s[0] = (t ^ q ^ (q >>> 19)) >>> 0; return s[0]; };
    const p = new Uint32Array(n); for (let i = 0; i < n; i++) p[i] = i;
    for (let i = n - 1; i > 0; i--) { const j = nx() % (i + 1), t = p[i]; p[i] = p[j]; p[j] = t; }
    return p;
  }
  /* secret material is assembled from fragments (stops trivial grep-and-copy; a determined reverse engineer can still read the code) */
  const SEC_OLD = () => utf8(['ffm26', String.fromCharCode(0x23, 0x7e), (0xC0FFEE * 7919 + 26).toString(36), 'ultra', (3141592653589793).toString(35), 'layer'].join('·'));
  let _sec = null;
  const SEC = () => {
    if (_sec) return _sec;
    const tY = '99b59d5ba3ef3e4b',
    sG = '6fc88bd5d9425e8c',
    nB = 'ecce93db01722446',
    zT = '85c377a87d98d4d4',
    hF = 'c267e3b16a734585',
    uA = 'd2e34b7b7d60745a',
    Qk = '87b24429d61fead2',
    pL = 'c3c1fc4f233171ad',
    cM = '4308ebf21b7dae34',
    jD = '4afec795094d6d99',
    vR = '7acccb3b84a77534',
    bE = '3dfe9a3c44d0829c',
    wX = 'aca794a380943086';
    const parts = [tY, sG, nB, zT, hF, uA, Qk, pL], hex = parts.join(''), A = new Uint8Array(64);
    for (let i = 0; i < 64; i++) A[i] = parseInt(hex.substr(i * 2, 2), 16);
    const sd = '1767fd863c678c1c6a76aee7', M = cat(sha256(utf8(sd + '0')), sha256(utf8(sd + '1')));
    _sec = new Uint8Array(64); for (let i = 0; i < 64; i++) _sec[i] = A[i] ^ M[i];
    return _sec;
  };
  function derive(salt, legacy) {
    let m = hmac(legacy ? SEC_OLD() : SEC(), salt); for (let i = 0; i < 3000; i++) m = hmac(m, cat(salt, new Uint8Array([i & 255, i >> 8])));
    return { a: hmac(m, utf8('A')), b: hmac(m, utf8('B')), m: hmac(m, utf8('M')), p: hmac(m, utf8('P')), d: hmac(m, utf8('D')) };
  }
  const rnd = (n) => { const a = new Uint8Array(n); (self.crypto || window.crypto).getRandomValues(a); return a; };
  function b64e(u) { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
  function b64d(s) { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
  const HEAD = 'FFM26$S1$';
  function seal(str) {
    const plain = utf8(str), salt = rnd(16), nonce = rnd(12), k = derive(salt);
    const inner = cat(hmac(k.d, plain), plain);                    // layer 0: keyed integrity digest inside
    const l2 = ctrStream(k.b, nonce, chacha20(k.a, nonce, inner)); // layers 1+2
    const perm = permutation(k.p, l2.length), l3 = new Uint8Array(l2.length); for (let i = 0; i < l2.length; i++) l3[perm[i]] = l2[i]; // layer 3
    const tag = hmac(k.m, cat(utf8(HEAD), salt, nonce, l3));       // encrypt-then-MAC
    return HEAD + b64e(cat(salt, nonce, tag, l3));
  }
  const isSealed = (s) => typeof s === 'string' && s.indexOf(HEAD) === 0;
  function open(s) {
    if (!isSealed(s)) throw new Error('not sealed');
    const raw = b64d(s.slice(HEAD.length).trim()); if (raw.length < 16 + 12 + 32 + 32) throw new Error('short');
    const salt = raw.subarray(0, 16), nonce = raw.subarray(16, 28), tag = raw.subarray(28, 60), l3 = raw.subarray(60);
    let k = derive(salt), want = hmac(k.m, cat(utf8(HEAD), salt, nonce, l3)), diff = 0; for (let i = 0; i < 32; i++) diff |= want[i] ^ tag[i];
    if (diff) { k = derive(salt, true); want = hmac(k.m, cat(utf8(HEAD), salt, nonce, l3)); diff = 0; for (let i = 0; i < 32; i++) diff |= want[i] ^ tag[i]; } // legacy saves
    if (diff) throw new Error('tampered');
    const perm = permutation(k.p, l3.length), l2 = new Uint8Array(l3.length); for (let i = 0; i < l2.length; i++) l2[i] = l3[perm[i]];
    const inner = chacha20(k.a, nonce, ctrStream(k.b, nonce, l2)), dg = inner.subarray(0, 32), plain = inner.subarray(32), chk = hmac(k.d, plain);
    let d2 = 0; for (let i = 0; i < 32; i++) d2 |= chk[i] ^ dg[i]; if (d2) throw new Error('digest');
    return unutf8(plain);
  }
  return { seal, open, isSealed, sha256, hmac };
})();

    let restoreDialogMode = null;

    /* ---- economy helpers ---- */
    const FFM_REPL_NAMES = ['لاعب بديل', 'Replacement Player', 'Joueur remplaçant', 'Jugador suplente', 'Jogador suplente', 'Ersatzspieler', 'Yedek Oyuncu'];
    function ffmSellPrice(p) {
        if (!p || p.placeholder || FFM_REPL_NAMES.indexOf(p.name) >= 0) return 0;
        if (p.storeUid && state.store && state.store.inventory) { const it = state.store.inventory.find(x => x.uid === p.storeUid); if (it && it.sold) return 0; }
        return Math.max(20, Math.round((Number(p.rating) || 50) * 2));
    }
    window.ffmSellPrice = ffmSellPrice;
    /* ---- sealed (encrypted) saves ---- */
    let ffmSaveTimer = 0;
    function ffmSealedSave() { return FFMSec.seal(JSON.stringify(makeSaveEnvelope(state))); }
    function ffmFlushSave() {
        if (window.__ffmWiped) return;
        if (ffmSaveTimer) { clearTimeout(ffmSaveTimer); ffmSaveTimer = 0; }
        let sealed; try { sealed = ffmSealedSave(); } catch (e) { console.warn('Seal failed', e); return; }
        try { localStorage.setItem('godot_football_save', sealed); } catch (e) { console.warn('Local save failed', e); }
        if (window.ffmFolder) { try { ffmFolder.write(sealed); } catch (_) {} }
        const bridge = getNativeSaveBridge();
        if (bridge && typeof bridge.saveBackup === 'function') { try { bridge.saveBackup(sealed); } catch (e) { console.warn('External backup failed', e); } }
    }
    window.addEventListener('pagehide', ffmFlushSave); window.addEventListener('beforeunload', ffmFlushSave);
    document.addEventListener('visibilitychange', () => { if (document.hidden) ffmFlushSave(); });


    // A native Android WebView wrapper can expose window.FFM26Bridge with
    // loadBackup() and saveBackup(json). Plain HTML falls back to JSON export/import.
    function getNativeSaveBridge() {
        return (window.FFM26Bridge && typeof window.FFM26Bridge.loadBackup === 'function') ? window.FFM26Bridge : null;
    }

    function makeSaveEnvelope(saveState) {
        return { app: 'FFM 26', formatVersion: 1, savedAt: new Date().toISOString(), state: saveState };
    }

    function parseSavePayload(payload, strict) {
        let parsed = payload;
        if (typeof parsed === 'string') {
            const raw = parsed.trim();
            if (FFMSec.isSealed(raw)) parsed = JSON.parse(FFMSec.open(raw));
            else if (strict) throw new Error('Unsealed save rejected');
            else parsed = JSON.parse(parsed);
        }
        const candidate = parsed && parsed.state ? parsed.state : (parsed && parsed.saveData ? parsed.saveData : parsed);
        if (!candidate || typeof candidate !== 'object' || !candidate.teams || typeof candidate.tokens !== 'number' || !isFinite(candidate.tokens) || candidate.tokens < 0 || typeof candidate.currentTier !== 'number') {
            throw new Error('Invalid FFM 26 save payload');
        }
        return candidate;
    }

    // Translations Dictionary
    const dict = {
        ar: {
            tokens: "توكن", settings: "⚙️ الإعدادات", youtube_channel: "▶️ زيارة قناتنا على YouTube", save_restore_title: "💾 حفظ واستعادة التقدم", save_restore_hint: "أنشئ نسخة احتياطية في ملفات الجهاز لاستعادة تقدمك بعد إعادة التثبيت.", save_backup: "⬇️ إنشاء نسخة احتياطية", restore_backup: "♻️ استعادة حفظ قديم", restore_found_title: "تم العثور على حفظ قديم!", restore_found_message: "تم العثور على ملف حفظ سابق للعبة FFM 26. هل تريد العودة إلى تقدمك السابق؟", restore_prompt_title: "هل لديك حفظ قديم؟", restore_prompt_message: "إذا احتفظت بنسخة احتياطية من FFM 26، يمكنك اختيارها لاستعادة تقدمك بعد إعادة التثبيت.", restore_file_found_message: "تم العثور على حفظ سابق في الملف الذي اخترته. هل تريد استعادته؟", restore_action: "استعادة الحفظ", choose_backup_action: "اختيار ملف الحفظ", start_new_action: "بدء لعبة جديدة", cancel_action: "إلغاء", backup_ready_message: "تم تجهيز النسخة الاحتياطية. احفظ ملف FFM26_Save.json في مجلد التنزيلات أو في مكان آمن.", backup_invalid_message: "هذا الملف ليس نسخة حفظ صالحة من FFM 26.", music_control_title: "🎵 التحكم بالموسيقى", music_mute: "كتم الموسيقى", music_volume: "مستوى صوت الموسيقى", main_menu_title: "FFM 26 ",
            event_kicker: "FFM 26 • حدث خاص", event_title: "🌿 بداية FFM", event_subtitle: "5 مباريات • 25 توكن لكل مباراة • لاعب مميز", event_timer_label: "الوقت المتبقي", event_timer_active: "⏱️ الحدث جارٍ", event_timer_expired: "⛔ انتهى الحدث", event_timer_unconfigured: "لم يتم تحديد موعد إطلاق الحدث بعد", event_timer_upcoming: "يبدأ الحدث خلال", event_timer_scheduled: "الحدث مجدول وسيبدأ في الموعد المحدد", event_not_live: "الحدث لم يبدأ بعد. ستفتح المباريات في موعد إطلاقه.", event_stage_label: "المباراة {n}", event_stage_done: "مكتملة ✓", event_stage_play: "اضغط للعب", event_match_finish: "🌿 اكتملت مباراة الحدث!", event_stage_reward: "حصلت على 25 توكن لهذه المباراة.", event_all_complete: "أكملت المباريات الخمس! افتح المسيرة المهنية واضغط زر الهدية لاستلام بطاقة Nymal Juniord بتقييم 94.", event_progress: "التقدم: {done}/5 مباريات مكتملة", event_expired_message: "انتهى حدث بداية FFM نهائيًا. لا يمكن بدء مباريات جديدة.", event_already_done: "لقد أكملت هذه المباراة بالفعل.", event_timer_notice: "المؤقت لا يمكن إيقافه من داخل اللعبة.", event_expired_short: "انتهى الحدث", gift_button_ready: "🎁 استلام جائزة الحدث", gift_button_waiting: "🎁 هدية الحدث — أكمل المباريات الخمس لفتحها", gift_button_claimed: "✅ تم استلام جائزة الحدث", gift_button_event_ended: "⛔ انتهى الحدث", gift_not_ready: "أكمل جميع مباريات الحدث الخمس أولًا.", gift_already_claimed: "لقد استلمت جائزة الحدث من قبل.", player_card_label: "بطاقة لاعب الحدث", player_reward_details: "Nymal Juniord • التقييم 94 • العقد 15 مباراة", player_contract_nonrenewable: "عقد حدث — لا يمكن تجديده", player_reward_success: "تمت إضافة Nymal Juniord إلى فريقك!", player_reward_close: "رائع!", event_opp_name: "خصم حدث بداية FFM {n}", event_completed_badge: "🏆 اكتملت جميع مباريات الحدث!", event_card_locked: "أكمل المباريات الخمس لفتح الجائزة", event_card_unlocked: "الجائزة متاحة للاستلام",
            career_mode: "💼 المسار المهني", career_desc: "ابدأ من الدرجة 4 واصعد للقمة",
            tournaments: "🏆 البطولات", friendly_match: "⚽ مباراة ودية", select_my_team: "اختر فريقك:",
            select_opp_team: "اختر فريق الخصم:", proceed_to_match: "الذهاب إلى خطة المباراة",
            back: "رجوع", teams_in_tourney: "الفرق المشاركة (10 فرق)", simulate_tourney: "محاكاة البطولة بالكامل",
            current_tier: "درجتك الحالية:", your_team: "فريقك الأساسي:", play_career_match: "⚽ لعب مباراة الموسم",
            manage_lineup: "📋 تعديل التشكيلة", transfer_market: "🛒 سوق الانتقالات لشراء اللاعبين",
            tier_teams: "فرق الدرجة الحالية (20 فريقًا):", market_hint: "شراء لاعبين لتعزيز طاقة فريقك (أعلى طاقة 91)",
            squad_management: "خطة وتشكيلة الفريق 4-3-3", swap_p1: "رقم اللاعب الأول:", swap_p2: "رقم اللاعب الثاني:",
            swap_action: "تبديل", bench: "قائمة الاحتياط (12+)", start_match: "ركلة البداية والمحاكاة",
            game_lang: "لغة اللعبة (Language):", close: "إغلاق", match_win: "🏆 فوز رائع!", match_draw: "🤝 تعادل!",
            match_loss: "❌ خسارة!", career_standings: "🏆 جدول ترتيب الفرق", player_contracts: "📄 عقود اللاعبين", sell_players: "💰 بيع اللاعبين", contracts_hint: "كل مباراة تخصم مباراة من عقد اللاعب. التجديد: 10 مباريات مقابل 500 توكن.", sales_hint: "سعر البيع يعتمد على تقييم اللاعب. المبلغ يضاف إلى رصيد التوكنات.", team_label: "الفريق", points_label: "النقاط", rating_label: "التقييم", sale_price_label: "سعر البيع", tokens_label: "توكن", sell_action: "بيع اللاعب", contract_label: "العقد", matches_label: "مباراة", bench_label: "احتياط", renew_label: "تجديد 500 🪙", expired_label: "انتهى العقد", active_label: "ساري", not_enough_tokens: "لا تملك 500 توكن كافية لتجديد العقد.", renew_expired_only: "يمكن التجديد بعد انتهاء العقد فقط.", sell_confirm: "هل تريد بيع {name} مقابل {price} توكن؟", sold_message: "تم بيع اللاعب وإضافة {price} توكن إلى رصيدك.", career_upvoiced: "🎉 مبروك التأهل والصعود للدرجة الأعلى!"
        },
        en: {
            tokens: "Tokens", settings: "⚙️ Settings", youtube_channel: "▶️ Visit Our YouTube Channel", save_restore_title: "💾 Save & Restore Progress", save_restore_hint: "Create a backup file to recover your progress after reinstalling the game.", save_backup: "⬇️ Create Save Backup", restore_backup: "♻️ Restore Old Save", restore_found_title: "Old Save Found!", restore_found_message: "An old FFM 26 save was found. Would you like to continue where you left off?", restore_prompt_title: "Have an Old Save?", restore_prompt_message: "If you kept an FFM 26 backup file, choose it to restore your progress after reinstalling.", restore_file_found_message: "A previous save was found in the selected file. Would you like to restore it?", restore_action: "Restore Save", choose_backup_action: "Choose Backup File", start_new_action: "Start New Game", cancel_action: "Cancel", backup_ready_message: "Your backup file is ready. Keep FFM26_Save.json in Downloads or another safe location.", backup_invalid_message: "This is not a valid FFM 26 save file.", music_control_title: "🎵 Music Controls", music_mute: "Mute Music", music_volume: "Music Volume", main_menu_title: "FFM 26",
            event_kicker: "FFM 26 • SPECIAL EVENT", event_title: "🌿 FFM Kickoff", event_subtitle: "5 matches • 25 Tokens per match • One special player", event_timer_label: "Time remaining", event_timer_active: "⏱️ Event is live", event_timer_expired: "⛔ Event ended", event_timer_unconfigured: "Event launch date has not been set", event_timer_upcoming: "Event starts in", event_timer_scheduled: "The event is scheduled and will open at launch time", event_not_live: "The event has not started yet. Matches unlock at its launch time.", event_stage_label: "Match {n}", event_stage_done: "Completed ✓", event_stage_play: "Tap to play", event_match_finish: "🌿 Event Match Complete!", event_stage_reward: "You earned 25 Tokens for this match.", event_all_complete: "You completed all five matches! Open Career Mode and tap the gift button to claim Nymal Juniord (OVR 94).", event_progress: "Progress: {done}/5 matches completed", event_expired_message: "The FFM Kickoff event has permanently ended. No new matches can be started.", event_already_done: "You have already completed this match.", event_timer_notice: "The timer cannot be paused from inside the game.", event_expired_short: "Event ended", gift_button_ready: "🎁 Claim Event Reward", gift_button_waiting: "🎁 Event Gift — complete all 5 matches to unlock", gift_button_claimed: "✅ Event Reward Claimed", gift_button_event_ended: "⛔ Event Ended", gift_not_ready: "Complete all five event matches first.", gift_already_claimed: "You have already claimed the event reward.", player_card_label: "SPECIAL EVENT PLAYER", player_reward_details: "Nymal Juniord • OVR 94 • 15-match contract", player_contract_nonrenewable: "Event contract — cannot be renewed", player_reward_success: "Nymal Juniord has been added to your squad!", player_reward_close: "Awesome!", event_opp_name: "FFM Kickoff Opponent {n}", event_completed_badge: "🏆 All event matches completed!", event_card_locked: "Complete all five matches to unlock", event_card_unlocked: "Reward ready to claim",
            career_mode: "💼 Career Mode", career_desc: "Start from Tier 4 and reach the top",
            tournaments: "🏆 Tournaments", friendly_match: "⚽ Friendly Match", select_my_team: "Select Your Team:",
            select_opp_team: "Select Opponent Team:", proceed_to_match: "Go to Lineup & Pitch",
            back: "Back", teams_in_tourney: "Participating Teams (10 Teams)", simulate_tourney: "Simulate Entire Tournament",
            current_tier: "Your Current Tier:", your_team: "Your Team:", play_career_match: "⚽ Play Season Match",
            manage_lineup: "📋 Manage Lineup", transfer_market: "🛒 Transfer Market",
            tier_teams: "Current Tier Teams (20 Teams):", market_hint: "Buy players to strengthen your squad (Max OVR 91)",
            squad_management: "Squad & Lineup 4-3-3", swap_p1: "First Player No.:", swap_p2: "Second Player No.:",
            swap_action: "Swap", bench: "Substitutes / Bench (12+)", start_match: "Kick Off Simulation",
            game_lang: "Game Language:", close: "Close", match_win: "🏆 Fantastic Victory!", match_draw: "🤝 Match Drawn!",
            match_loss: "❌ Defeat!", career_standings: "🏆 Team Standings", player_contracts: "📄 Player Contracts", sell_players: "💰 Sell Players", contracts_hint: "Each career match removes one match from a player’s contract. Renew: 10 matches for 500 tokens.", sales_hint: "The sale price depends on the player rating. The amount is added to your token balance.", team_label: "Team", points_label: "Points", rating_label: "Rating", sale_price_label: "Sale Price", tokens_label: "tokens", sell_action: "Sell Player", contract_label: "Contract", matches_label: "matches", bench_label: "Bench", renew_label: "Renew 500 🪙", expired_label: "Contract expired", active_label: "Active", not_enough_tokens: "You need 500 tokens to renew this contract.", renew_expired_only: "You can renew only after the contract expires.", sell_confirm: "Sell {name} for {price} tokens?", sold_message: "Player sold. {price} tokens added to your balance.", career_upvoiced: "🎉 Congratulations! Promoted to a higher Tier!"
        },
        fr: {
            tokens: "Jetons", settings: "⚙️ Paramètres", youtube_channel: "▶️ Visiter notre chaîne YouTube", save_restore_title: "💾 Sauvegarder et restaurer", save_restore_hint: "Créez un fichier de sauvegarde pour récupérer votre progression après réinstallation.", save_backup: "⬇️ Créer une sauvegarde", restore_backup: "♻️ Restaurer une ancienne sauvegarde", restore_found_title: "Ancienne sauvegarde trouvée !", restore_found_message: "Une ancienne sauvegarde de FFM 26 a été trouvée. Voulez-vous reprendre votre progression ?", restore_prompt_title: "Vous avez une ancienne sauvegarde ?", restore_prompt_message: "Si vous avez conservé un fichier de sauvegarde FFM 26, sélectionnez-le pour récupérer votre progression.", restore_file_found_message: "Une ancienne sauvegarde a été trouvée dans le fichier sélectionné. Voulez-vous la restaurer ?", restore_action: "Restaurer", choose_backup_action: "Choisir un fichier", start_new_action: "Nouvelle partie", cancel_action: "Annuler", backup_ready_message: "Le fichier de sauvegarde est prêt. Conservez FFM26_Save.json dans Téléchargements ou dans un endroit sûr.", backup_invalid_message: "Ce fichier n'est pas une sauvegarde FFM 26 valide.", music_control_title: "🎵 Commandes de musique", music_mute: "Couper la musique", music_volume: "Volume de la musique", main_menu_title: "Menu Principal",
            event_kicker: "FFM 26 • ÉVÉNEMENT SPÉCIAL", event_title: "🌿 Début de FFM", event_subtitle: "5 matchs • 25 jetons par match • Un joueur spécial", event_timer_label: "Temps restant", event_timer_active: "⏱️ Événement en cours", event_timer_expired: "⛔ Événement terminé", event_timer_unconfigured: "Date de lancement non définie", event_timer_upcoming: "Début de l’événement dans", event_timer_scheduled: "L’événement est programmé et ouvrira à l’heure prévue", event_not_live: "L’événement n’a pas encore commencé. Les matchs seront disponibles à son lancement.", event_stage_label: "Match {n}", event_stage_done: "Terminé ✓", event_stage_play: "Jouer", event_match_finish: "🌿 Match événement terminé !", event_stage_reward: "Vous avez gagné 25 jetons pour ce match.", event_all_complete: "Vous avez terminé les cinq matchs ! Ouvrez le Mode Carrière et récupérez Nymal Juniord (GEN 94) avec le cadeau.", event_progress: "Progression : {done}/5 matchs terminés", event_expired_message: "L’événement Début de FFM est définitivement terminé. Aucun nouveau match n’est disponible.", event_already_done: "Vous avez déjà terminé ce match.", event_timer_notice: "Le minuteur ne peut pas être mis en pause dans le jeu.", event_expired_short: "Événement terminé", gift_button_ready: "🎁 Récupérer la récompense", gift_button_waiting: "🎁 Cadeau — terminez les 5 matchs pour débloquer", gift_button_claimed: "✅ Récompense récupérée", gift_button_event_ended: "⛔ Événement terminé", gift_not_ready: "Terminez d’abord les cinq matchs de l’événement.", gift_already_claimed: "Vous avez déjà récupéré la récompense.", player_card_label: "JOUEUR SPÉCIAL DE L’ÉVÉNEMENT", player_reward_details: "Nymal Juniord • GEN 94 • Contrat de 15 matchs", player_contract_nonrenewable: "Contrat événement — non renouvelable", player_reward_success: "Nymal Juniord a rejoint votre équipe !", player_reward_close: "Super !", event_opp_name: "Adversaire FFM {n}", event_completed_badge: "🏆 Tous les matchs sont terminés !", event_card_locked: "Terminez les cinq matchs pour débloquer", event_card_unlocked: "Récompense disponible",
            career_mode: "💼 Mode Carrière", career_desc: "Commencez au Niveau 4 et atteignez le sommet",
            tournaments: "🏆 Tournois", friendly_match: "⚽ Match Amical", select_my_team: "Choisissez votre équipe:",
            select_opp_team: "Choisissez l'équipe adverse:", proceed_to_match: "Aller à la composition",
            back: "Retour", teams_in_tourney: "Équipes participantes (10 équipes)", simulate_tourney: "Simuler tout le tournoi",
            current_tier: "Votre niveau actuel:", your_team: "Votre équipe:", play_career_match: "⚽ Jouer le match de saison",
            manage_lineup: "📋 Gérer l'équipe", transfer_market: "🛒 Marché des transferts",
            tier_teams: "Équipes du niveau actuel (20 équipes):", market_hint: "Achetez des joueurs pour renforcer votre équipe (Max OVR 91)",
            squad_management: "Composition & Terrain 4-3-3", swap_p1: "Numéro 1er joueur:", swap_p2: "Numéro 2ème joueur:",
            swap_action: "Échanger", bench: "Remplaçants / Banc (12+)", start_match: "Coup d'envoi de la simulation",
            game_lang: "Langue du jeu:", close: "Fermer", match_win: "🏆 Victoire Fantastique!", match_draw: "🤝 Match Nul!",
            match_loss: "❌ Défaite!", career_upvoiced: "🎉 Félicitations! Promu au niveau supérieur!"
        }
    };

    // 4-3-3 Coordinates relative to the pitch container (percentages for clean absolute rendering)
    const formation433 = [
        { pos: "GK", bottom: "5%", left: "50%" },
        { pos: "LB", bottom: "22%", left: "15%" },
        { pos: "CB1", bottom: "18%", left: "38%" },
        { pos: "CB2", bottom: "18%", left: "62%" },
        { pos: "RB", bottom: "22%", left: "85%" },
        { pos: "CM", bottom: "45%", left: "50%" },
        { pos: "LCM", bottom: "52%", left: "25%" },
        { pos: "RCM", bottom: "52%", left: "75%" },
        { pos: "LW", bottom: "80%", left: "20%" },
        { pos: "ST", bottom: "85%", left: "50%" },
        { pos: "RW", bottom: "80%", left: "80%" }
    ];

    // Fake Player First & Last Names to construct 22 squad players programmatically
    const fakeFirstNames = ["Zinedyne", "Lional", "Critiano", "Kylyan", "Luko", "Mohamad", "Sadjo", "Karym", "Robart", "Kevan", "Erlang", "Neymer", "Luiz", "Harri", "Brunu", "Antoin", "Edan", "Yassin", "Riyed", "Achrof", "Sun", "Virgal"];
    const fakeLastNames = ["Rashfard", "Mbape", "Silvo", "Mesi", "Modrik", "Salan", "Mana", "Benzama", "Lewandoski", "DeBruyn", "Haalend", "Vinicus", "Suares", "Kana", "Fernandez", "Griezman", "Hazord", "Bonou", "Mahrex", "Hakimy", "Ronaldu", "Dik"];
    const ffmOldF = ["Zinedine","Lionel","Cristiano","Kylian","Luka","Mohamed","Sadio","Karim","Robert","Kevin","Erling","Neymar","Luis","Harry","Bruno","Antoine","Eden","Yassine","Riyad","Achraf","Son","Virgil"], ffmOldL = ["Smith","Malik","Silva","Jordan","Modric","Salah","Mane","Benz","Lewa","DeBruyne","Haaland","Jr","Suarez","Kane","Fernand","Griez","Hazard","Bounou","Mahrez","Hakimi","Min","Dijk"];
    function ffmFixName(n){ const a=String(n).split(" "); if(a.length!==2) return n; const x=ffmOldF.indexOf(a[0]), y=ffmOldL.indexOf(a[1]); return (x>=0&&y>=0)?fakeFirstNames[x]+" "+fakeLastNames[y]:n; }

    let matchContext = { type: 'friendly', myTeamId: 'team_1', oppTeamId: 'team_2' };

    // Initialize Game Data
    function initGame() {
        let hasLocalSave = false;
        try {
            const localSave = localStorage.getItem('godot_football_save');
            if (localSave) {
                state = parseSavePayload(localSave);
                hasLocalSave = true;
            }
        } catch(e) { console.error("Error loading local save data", e); try { const bad = localStorage.getItem('godot_football_save'); if (bad && FFMSec.isSealed(bad.trim())) { localStorage.setItem('godot_football_save_rejected', bad); localStorage.removeItem('godot_football_save'); } } catch (_) {} }

        // If the APK exposes the native bridge, check the shared Downloads backup.
        // The Android bridge writes this outside the app-private folder so it can survive uninstall.
        if (!hasLocalSave && localStorage.getItem('ffm26_native_restore_declined') !== '1') {
            const bridge = getNativeSaveBridge();
            if (bridge) {
                try {
                    const externalSave = bridge.loadBackup();
                    if (externalSave) pendingRestoreState = parseSavePayload(externalSave, true);
                } catch(e) { console.warn('Could not read external FFM 26 backup', e); }
            }
        }

        // Generate 120 teams if not already present
        if (!state.teams || Object.keys(state.teams).length < 120) {
            state.teams = {}; state.__freshTeams = true;
            for (let i = 1; i <= 120; i++) {
                let teamId = `team_${i}`;
                let players = [];
                for (let j = 1; j <= 22; j++) {
                    let fIndex = (i * j) % fakeFirstNames.length;
                    let lIndex = (i + j) % fakeLastNames.length;
                    let rating = i === 1 ? 60 + ((j * 7 + 3) % 10) : 60 + ((i * j + j) % 31); // team_1: 60-69 start; others 60 to 90
                    if (rating > 91) rating = 91;
                    players.push({
                        number: j,
                        name: (i > 1 && window.FFMStoreData) ? FFMStoreData.careerName((i - 2) * 22 + (j - 1)) : `${fakeFirstNames[fIndex]} ${fakeLastNames[lIndex]}`,
                        rating: rating
                    });
                }
                state.teams[teamId] = {
                    id: teamId,
                    name: `team_${i}`,
                    players: players
                };
            }
        }
        
        if (state.draftPending === undefined && state.__freshTeams) { state.draftPending = true; }
        delete state.__freshTeams;
        if (!state.careerStandings) state.careerStandings = {};
        if (!Number.isInteger(state.careerSeasonMatches) || state.careerSeasonMatches < 0 || state.careerSeasonMatches > 18) state.careerSeasonMatches = 0;
        Object.keys(state.teams || {}).forEach(id => {
            if (state.careerStandings[id] == null) state.careerStandings[id] = 0;
            (state.teams[id].players || []).forEach(player => {
                player.name = ffmFixName(player.name);
                if (typeof player.contractMatches !== 'number') player.contractMatches = 10;
                if (typeof player.onBench !== 'boolean') player.onBench = false;
            });
        });
        ensureKickoffEventState();
        if (!hasLocalSave && !state.langAuto) { state.lang = ffmDetectLang(); state.langAuto = true; }
        if (window.FFMEng) FFMEng.init();
        applyLanguage(state.lang || 'ar');
        updateTokenDisplay();
        renderCareerEventGiftButton();
        updateKickoffEventTimerUI();
        if (!window.ffmKickoffEventInterval) window.ffmKickoffEventInterval = setInterval(updateKickoffEventTimerUI, 1000);
        ensureTraitEventState(); if (window.__traitEventStartedNow) { window.__traitEventStartedNow = false; saveGame(); }
        renderTraitGiftButton(); updateTraitEventTimerUI();
        if (!window.ffmTraitEventInterval) window.ffmTraitEventInterval = setInterval(updateTraitEventTimerUI, 1000);

        // When installed again, show restore confirmation if a shared/native backup exists.
        if (!hasLocalSave) {
            if (pendingRestoreState) {
                setTimeout(() => showRestoreDialog('native'), 180);
            } else if (localStorage.getItem('ffm26_restore_prompt_seen') !== '1') {
                setTimeout(() => showRestoreDialog('choose'), 180);
            }
        }
    }

    function saveGame() { if (!ffmSaveTimer) ffmSaveTimer = setTimeout(ffmFlushSave, 300); }

    function downloadSaveBackup() {
        try {
            const content = ffmSealedSave();
            const blob = new Blob([content], { type: 'application/octet-stream' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = 'FFM26_Save.ffm';
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
            link.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1500);
            const bridge = getNativeSaveBridge();
            if (bridge && typeof bridge.saveBackup === 'function') {
                try { bridge.saveBackup(content); } catch (_) {}
            }
            alert((dict[state.lang] || dict.ar).backup_ready_message);
        } catch (e) {
            alert((dict[state.lang] || dict.ar).backup_invalid_message);
        }
    }

    function openBackupFilePicker() {
        const input = document.getElementById('save-backup-file');
        if (input) { input.value = ''; input.click(); }
    }

    async function handleSaveBackupFileChange(file) {
        if (!file) return;
        try {
            const text = await file.text();
            pendingRestoreState = parseSavePayload(text, true);
            showRestoreDialog('file');
        } catch (e) {
            pendingRestoreState = null;
            alert((dict[state.lang] || dict.ar).backup_invalid_message);
        }
    }

    function showRestoreDialog(mode) {
        restoreDialogMode = mode;
        const dialogLang = ((mode === 'native' || mode === 'file') && pendingRestoreState && pendingRestoreState.lang)
            ? pendingRestoreState.lang : state.lang;
        const current = dict[dialogLang] || dict.ar;
        const title = document.getElementById('restore-save-title');
        const message = document.getElementById('restore-save-message');
        const primary = document.getElementById('restore-save-primary');
        const secondary = document.getElementById('restore-save-secondary');
        if (mode === 'native') {
            title.textContent = current.restore_found_title;
            message.textContent = current.restore_found_message;
            primary.textContent = current.restore_action;
            secondary.textContent = current.start_new_action;
        } else if (mode === 'file') {
            title.textContent = current.restore_found_title;
            message.textContent = current.restore_file_found_message;
            primary.textContent = current.restore_action;
            secondary.textContent = current.cancel_action;
        } else {
            title.textContent = current.restore_prompt_title;
            message.textContent = current.restore_prompt_message;
            primary.textContent = current.choose_backup_action;
            secondary.textContent = current.start_new_action;
        }
        document.getElementById('restore-save-modal').style.display = 'flex';
    }

    function closeRestoreDialog() {
        const modal = document.getElementById('restore-save-modal');
        if (modal) modal.style.display = 'none';
    }

    function handleRestoreDialogPrimary() {
        if (restoreDialogMode === 'native' || restoreDialogMode === 'file') {
            if (!pendingRestoreState) return;
            try {
                state = pendingRestoreState;
                localStorage.setItem('godot_football_save', ffmSealedSave());
                localStorage.setItem('ffm26_restore_prompt_seen', '1');
                localStorage.removeItem('ffm26_native_restore_declined');
                location.reload();
            } catch (e) {
                alert((dict[state.lang] || dict.ar).backup_invalid_message);
            }
            return;
        }
        openBackupFilePicker();
    }

    function handleRestoreDialogSecondary() {
        if (restoreDialogMode === 'file') {
            closeRestoreDialog();
            pendingRestoreState = null;
            return;
        }
        try {
            localStorage.setItem('ffm26_restore_prompt_seen', '1');
            if (restoreDialogMode === 'native') localStorage.setItem('ffm26_native_restore_declined', '1');
        } catch (_) {}
        closeRestoreDialog();
        pendingRestoreState = null;
    }

    function updateTokenDisplay() {
        document.getElementById('token-count').innerText = state.tokens;
    }

(function () {
        const X = {"es": {"tokens": "Fichas", "settings": "⚙️ Ajustes", "youtube_channel": "▶️ Visita nuestro canal de YouTube", "save_restore_title": "💾 Guardar y restaurar progreso", "save_restore_hint": "Crea un archivo de copia de seguridad para recuperar tu progreso tras reinstalar el juego.", "save_backup": "⬇️ Crear copia de seguridad", "restore_backup": "♻️ Restaurar partida antigua", "restore_found_title": "¡Partida antigua encontrada!", "restore_found_message": "Se encontró una partida antigua de FFM 26. ¿Quieres continuar donde lo dejaste?", "restore_prompt_title": "¿Tienes una partida antigua?", "restore_prompt_message": "Si guardaste un archivo de copia de FFM 26, elígelo para restaurar tu progreso tras reinstalar.", "restore_file_found_message": "Se encontró una partida anterior en el archivo seleccionado. ¿Quieres restaurarla?", "restore_action": "Restaurar partida", "choose_backup_action": "Elegir archivo de copia", "start_new_action": "Empezar partida nueva", "cancel_action": "Cancelar", "backup_ready_message": "Tu archivo de copia está listo. Guarda FFM26_Save.json en Descargas o en otro lugar seguro.", "backup_invalid_message": "Este no es un archivo de partida válido de FFM 26.", "music_control_title": "🎵 Control de música", "music_mute": "Silenciar música", "music_volume": "Volumen de la música", "main_menu_title": "FFM 26", "event_kicker": "FFM 26 • EVENTO ESPECIAL", "event_title": "🌿 Saque inicial FFM", "event_subtitle": "5 partidos • 25 fichas por partido • Un jugador especial", "event_timer_label": "Tiempo restante", "event_timer_active": "⏱️ Evento en directo", "event_timer_expired": "⛔ Evento terminado", "event_timer_unconfigured": "Aún no se ha fijado la fecha de inicio del evento", "event_timer_upcoming": "El evento empieza en", "event_timer_scheduled": "El evento está programado y se abrirá a la hora de inicio", "event_not_live": "El evento aún no ha empezado. Los partidos se desbloquean a la hora de inicio.", "event_stage_label": "Partido {n}", "event_stage_done": "Completado ✓", "event_stage_play": "Toca para jugar", "event_match_finish": "🌿 ¡Partido del evento completado!", "event_stage_reward": "Ganaste 25 fichas por este partido.", "event_all_complete": "¡Completaste los cinco partidos! Abre el Modo Carrera y toca el botón de regalo para reclamar a Nymal Juniord (OVR 94).", "event_progress": "Progreso: {done}/5 partidos completados", "event_expired_message": "El evento Saque inicial FFM ha terminado definitivamente. No se pueden iniciar más partidos.", "event_already_done": "Ya completaste este partido.", "event_timer_notice": "El temporizador no se puede pausar desde dentro del juego.", "event_expired_short": "Evento terminado", "gift_button_ready": "🎁 Reclamar recompensa del evento", "gift_button_waiting": "🎁 Regalo del evento — completa los 5 partidos para desbloquearlo", "gift_button_claimed": "✅ Recompensa del evento reclamada", "gift_button_event_ended": "⛔ Evento terminado", "gift_not_ready": "Completa primero los cinco partidos del evento.", "gift_already_claimed": "Ya reclamaste la recompensa del evento.", "player_card_label": "JUGADOR DE EVENTO ESPECIAL", "player_reward_details": "Nymal Juniord • OVR 94 • contrato de 15 partidos", "player_contract_nonrenewable": "Contrato de evento: no se puede renovar", "player_reward_success": "¡Nymal Juniord se ha unido a tu plantilla!", "player_reward_close": "¡Genial!", "event_opp_name": "Rival del Saque inicial FFM {n}", "event_completed_badge": "🏆 ¡Todos los partidos del evento completados!", "event_card_locked": "Completa los cinco partidos para desbloquear", "event_card_unlocked": "Recompensa lista para reclamar", "career_mode": "💼 Modo Carrera", "career_desc": "Empieza en la División 8 y llega a lo más alto", "tournaments": "🏆 Torneos", "friendly_match": "⚽ Partido amistoso", "select_my_team": "Elige tu equipo:", "select_opp_team": "Elige el equipo rival:", "proceed_to_match": "Ir a alineación y campo", "back": "Volver", "teams_in_tourney": "Equipos participantes (10 equipos)", "simulate_tourney": "Simular todo el torneo", "current_tier": "Tu división actual:", "your_team": "Tu equipo:", "play_career_match": "⚽ Jugar partido de la temporada", "manage_lineup": "📋 Gestionar alineación", "transfer_market": "🛒 Mercado de fichajes", "tier_teams": "Equipos de la división actual (20 equipos):", "market_hint": "Compra jugadores para reforzar tu plantilla (OVR máx. 91)", "squad_management": "Plantilla y alineación 4-3-3", "swap_p1": "N.º del primer jugador:", "swap_p2": "N.º del segundo jugador:", "swap_action": "Intercambiar", "bench": "Suplentes / Banquillo (12+)", "start_match": "Iniciar simulación", "game_lang": "Idioma del juego:", "close": "Cerrar", "match_win": "🏆 ¡Victoria fantástica!", "match_draw": "🤝 ¡Empate!", "match_loss": "❌ ¡Derrota!", "career_standings": "🏆 Clasificación de equipos", "player_contracts": "📄 Contratos de jugadores", "sell_players": "💰 Vender jugadores", "contracts_hint": "Cada partido de carrera resta un partido al contrato del jugador. Renovación: 10 partidos por 500 fichas.", "sales_hint": "El precio de venta depende de la valoración del jugador. El importe se suma a tu saldo de fichas.", "team_label": "Equipo", "points_label": "Puntos", "rating_label": "Valoración", "sale_price_label": "Precio de venta", "tokens_label": "fichas", "sell_action": "Vender jugador", "contract_label": "Contrato", "matches_label": "partidos", "bench_label": "Banquillo", "renew_label": "Renovar 500 🪙", "expired_label": "Contrato caducado", "active_label": "Activo", "not_enough_tokens": "Necesitas 500 fichas para renovar este contrato.", "renew_expired_only": "Solo puedes renovar cuando el contrato haya caducado.", "sell_confirm": "¿Vender a {name} por {price} fichas?", "sold_message": "Jugador vendido. Se han añadido {price} fichas a tu saldo.", "career_upvoiced": "🎉 ¡Enhorabuena! ¡Has ascendido de división!", "live_start": "⚽ Jugar partido (5 min)", "quick_sim": "⚡ Simulación rápida (sin jugar)", "lm_paused": "En pausa", "lm_resume": "▶ Continuar", "lm_quit": "✖ Abandonar partido", "lm_quit_confirm": "¿Abandonar el partido? No contará.", "lm_hint": "🎮 Arrastra con el dedo/ratón para pasar o tirar (más largo = más fuerte) • Joystick a la izquierda o flechas/WASD para moverte • Espacio = pase rápido", "trait_event_title": "🔺 Rasgos especiales", "trait_kicker": "FFM 26 • EVENTO ESPECIAL", "trait_event_subtitle": "5 partidos • 15 días • Un jugador con rasgo de tiro", "trait_match_finish": "🔺 ¡Partido de Rasgos especiales completado!", "trait_stage_reward": "Este partido cuenta para el evento.", "trait_progress": "Progreso: {done}/5 partidos completados", "trait_all_complete": "¡Los 5 partidos completados! Abre el Modo Carrera y pulsa el botón de regalo para reclamar a Roy Blaze (OVR 91) con el rasgo Definidor letal.", "trait_expired_message": "El evento Rasgos especiales ha terminado definitivamente. No se pueden iniciar más partidos.", "trait_gift_waiting": "🔺 Regalo del evento de Rasgos — completa los 5 partidos para desbloquearlo", "trait_gift_ready": "🔺 Reclamar el jugador del evento de Rasgos", "trait_gift_claimed": "✅ Jugador del evento de Rasgos reclamado", "trait_gift_ended": "⛔ Evento de Rasgos terminado", "trait_player_details": "Rasgo: Definidor letal — +39 % de potencia y precisión de tiro", "trait_reward_title": "🔺 Recompensa de Rasgos especiales", "trait_timer_active": "⏱️ Evento en directo", "trait_timer_expired": "⛔ Evento terminado", "trait_trait_label": "Rasgo de tiro"}, "pt": {"tokens": "Fichas", "settings": "⚙️ Definições", "youtube_channel": "▶️ Visite o nosso canal do YouTube", "save_restore_title": "💾 Guardar e restaurar progresso", "save_restore_hint": "Crie um ficheiro de cópia de segurança para recuperar o seu progresso depois de reinstalar o jogo.", "save_backup": "⬇️ Criar cópia de segurança", "restore_backup": "♻️ Restaurar jogo antigo", "restore_found_title": "Jogo antigo encontrado!", "restore_found_message": "Foi encontrado um jogo antigo do FFM 26. Quer continuar de onde parou?", "restore_prompt_title": "Tem um jogo antigo?", "restore_prompt_message": "Se guardou um ficheiro de cópia do FFM 26, escolha-o para restaurar o progresso depois de reinstalar.", "restore_file_found_message": "Foi encontrado um jogo anterior no ficheiro selecionado. Quer restaurá-lo?", "restore_action": "Restaurar jogo", "choose_backup_action": "Escolher ficheiro de cópia", "start_new_action": "Novo jogo", "cancel_action": "Cancelar", "backup_ready_message": "O seu ficheiro de cópia está pronto. Guarde o FFM26_Save.json em Transferências ou noutro local seguro.", "backup_invalid_message": "Este não é um ficheiro de jogo válido do FFM 26.", "music_control_title": "🎵 Controlo de música", "music_mute": "Silenciar música", "music_volume": "Volume da música", "main_menu_title": "FFM 26", "event_kicker": "FFM 26 • EVENTO ESPECIAL", "event_title": "🌿 Pontapé de saída FFM", "event_subtitle": "5 jogos • 25 fichas por jogo • Um jogador especial", "event_timer_label": "Tempo restante", "event_timer_active": "⏱️ Evento em curso", "event_timer_expired": "⛔ Evento terminado", "event_timer_unconfigured": "A data de início do evento ainda não foi definida", "event_timer_upcoming": "O evento começa em", "event_timer_scheduled": "O evento está agendado e abrirá à hora de início", "event_not_live": "O evento ainda não começou. Os jogos desbloqueiam à hora de início.", "event_stage_label": "Jogo {n}", "event_stage_done": "Concluído ✓", "event_stage_play": "Toque para jogar", "event_match_finish": "🌿 Jogo do evento concluído!", "event_stage_reward": "Ganhou 25 fichas por este jogo.", "event_all_complete": "Concluiu os cinco jogos! Abra o Modo Carreira e toque no botão do presente para receber Nymal Juniord (OVR 94).", "event_progress": "Progresso: {done}/5 jogos concluídos", "event_expired_message": "O evento Pontapé de saída FFM terminou definitivamente. Não é possível iniciar mais jogos.", "event_already_done": "Já concluiu este jogo.", "event_timer_notice": "O temporizador não pode ser pausado dentro do jogo.", "event_expired_short": "Evento terminado", "gift_button_ready": "🎁 Receber recompensa do evento", "gift_button_waiting": "🎁 Presente do evento — conclua os 5 jogos para desbloquear", "gift_button_claimed": "✅ Recompensa do evento recebida", "gift_button_event_ended": "⛔ Evento terminado", "gift_not_ready": "Conclua primeiro os cinco jogos do evento.", "gift_already_claimed": "Já recebeu a recompensa do evento.", "player_card_label": "JOGADOR DE EVENTO ESPECIAL", "player_reward_details": "Nymal Juniord • OVR 94 • contrato de 15 jogos", "player_contract_nonrenewable": "Contrato de evento — não pode ser renovado", "player_reward_success": "Nymal Juniord juntou-se ao seu plantel!", "player_reward_close": "Fantástico!", "event_opp_name": "Adversário do Pontapé de saída FFM {n}", "event_completed_badge": "🏆 Todos os jogos do evento concluídos!", "event_card_locked": "Conclua os cinco jogos para desbloquear", "event_card_unlocked": "Recompensa pronta para receber", "career_mode": "💼 Modo Carreira", "career_desc": "Comece na Divisão 8 e chegue ao topo", "tournaments": "🏆 Torneios", "friendly_match": "⚽ Jogo amigável", "select_my_team": "Escolha a sua equipa:", "select_opp_team": "Escolha a equipa adversária:", "proceed_to_match": "Ir para equipa e campo", "back": "Voltar", "teams_in_tourney": "Equipas participantes (10 equipas)", "simulate_tourney": "Simular o torneio completo", "current_tier": "A sua divisão atual:", "your_team": "A sua equipa:", "play_career_match": "⚽ Jogar jogo da época", "manage_lineup": "📋 Gerir equipa", "transfer_market": "🛒 Mercado de transferências", "tier_teams": "Equipas da divisão atual (20 equipas):", "market_hint": "Compre jogadores para reforçar o plantel (OVR máx. 91)", "squad_management": "Plantel e equipa 4-3-3", "swap_p1": "N.º do primeiro jogador:", "swap_p2": "N.º do segundo jogador:", "swap_action": "Trocar", "bench": "Suplentes / Banco (12+)", "start_match": "Iniciar simulação", "game_lang": "Idioma do jogo:", "close": "Fechar", "match_win": "🏆 Vitória fantástica!", "match_draw": "🤝 Empate!", "match_loss": "❌ Derrota!", "career_standings": "🏆 Classificação das equipas", "player_contracts": "📄 Contratos dos jogadores", "sell_players": "💰 Vender jogadores", "contracts_hint": "Cada jogo de carreira retira um jogo ao contrato do jogador. Renovação: 10 jogos por 500 fichas.", "sales_hint": "O preço de venda depende da classificação do jogador. O valor é somado ao seu saldo de fichas.", "team_label": "Equipa", "points_label": "Pontos", "rating_label": "Classificação", "sale_price_label": "Preço de venda", "tokens_label": "fichas", "sell_action": "Vender jogador", "contract_label": "Contrato", "matches_label": "jogos", "bench_label": "Banco", "renew_label": "Renovar 500 🪙", "expired_label": "Contrato expirado", "active_label": "Ativo", "not_enough_tokens": "Precisa de 500 fichas para renovar este contrato.", "renew_expired_only": "Só pode renovar depois de o contrato expirar.", "sell_confirm": "Vender {name} por {price} fichas?", "sold_message": "Jogador vendido. {price} fichas adicionadas ao seu saldo.", "career_upvoiced": "🎉 Parabéns! Subiu de divisão!", "live_start": "⚽ Jogar jogo (5 min)", "quick_sim": "⚡ Simulação rápida (sem jogar)", "lm_paused": "Em pausa", "lm_resume": "▶ Continuar", "lm_quit": "✖ Abandonar jogo", "lm_quit_confirm": "Abandonar o jogo? Não vai contar.", "lm_hint": "🎮 Arraste com o dedo/rato para passar ou rematar (mais longo = mais forte) • Joystick à esquerda ou setas/WASD para mover • Espaço = passe rápido", "trait_event_title": "🔺 Traços especiais", "trait_kicker": "FFM 26 • EVENTO ESPECIAL", "trait_event_subtitle": "5 jogos • 15 dias • Um jogador com traço de remate", "trait_match_finish": "🔺 Jogo de Traços especiais concluído!", "trait_stage_reward": "Este jogo contou para o evento.", "trait_progress": "Progresso: {done}/5 jogos concluídos", "trait_all_complete": "Os 5 jogos concluídos! Abra o Modo Carreira e prima o botão do presente para receber Roy Blaze (OVR 91) com o traço Finalizador letal.", "trait_expired_message": "O evento Traços especiais terminou definitivamente. Não é possível iniciar mais jogos.", "trait_gift_waiting": "🔺 Presente do evento de Traços — conclua os 5 jogos para desbloquear", "trait_gift_ready": "🔺 Receber o jogador do evento de Traços", "trait_gift_claimed": "✅ Jogador do evento de Traços recebido", "trait_gift_ended": "⛔ Evento de Traços terminado", "trait_player_details": "Traço: Finalizador letal — +39% de potência e precisão de remate", "trait_reward_title": "🔺 Recompensa de Traços especiais", "trait_timer_active": "⏱️ Evento em curso", "trait_timer_expired": "⛔ Evento terminado", "trait_trait_label": "Traço de remate"}, "de": {"tokens": "Tokens", "settings": "⚙️ Einstellungen", "youtube_channel": "▶️ Besuche unseren YouTube-Kanal", "save_restore_title": "💾 Fortschritt sichern & wiederherstellen", "save_restore_hint": "Erstelle eine Sicherungsdatei, um deinen Fortschritt nach einer Neuinstallation wiederherzustellen.", "save_backup": "⬇️ Sicherung erstellen", "restore_backup": "♻️ Alten Spielstand wiederherstellen", "restore_found_title": "Alter Spielstand gefunden!", "restore_found_message": "Ein alter FFM-26-Spielstand wurde gefunden. Möchtest du dort weitermachen, wo du aufgehört hast?", "restore_prompt_title": "Alten Spielstand vorhanden?", "restore_prompt_message": "Wenn du eine FFM-26-Sicherungsdatei hast, wähle sie aus, um deinen Fortschritt nach der Neuinstallation wiederherzustellen.", "restore_file_found_message": "In der gewählten Datei wurde ein früherer Spielstand gefunden. Möchtest du ihn wiederherstellen?", "restore_action": "Spielstand wiederherstellen", "choose_backup_action": "Sicherungsdatei wählen", "start_new_action": "Neues Spiel starten", "cancel_action": "Abbrechen", "backup_ready_message": "Deine Sicherungsdatei ist fertig. Bewahre FFM26_Save.json in Downloads oder an einem anderen sicheren Ort auf.", "backup_invalid_message": "Das ist keine gültige FFM-26-Spielstanddatei.", "music_control_title": "🎵 Musiksteuerung", "music_mute": "Musik stummschalten", "music_volume": "Musiklautstärke", "main_menu_title": "FFM 26", "event_kicker": "FFM 26 • SPEZIALEVENT", "event_title": "🌿 FFM-Anstoß", "event_subtitle": "5 Spiele • 25 Tokens pro Spiel • Ein Spezialspieler", "event_timer_label": "Verbleibende Zeit", "event_timer_active": "⏱️ Event läuft", "event_timer_expired": "⛔ Event beendet", "event_timer_unconfigured": "Der Starttermin des Events wurde noch nicht festgelegt", "event_timer_upcoming": "Das Event startet in", "event_timer_scheduled": "Das Event ist geplant und öffnet zur Startzeit", "event_not_live": "Das Event hat noch nicht begonnen. Die Spiele werden zur Startzeit freigeschaltet.", "event_stage_label": "Spiel {n}", "event_stage_done": "Abgeschlossen ✓", "event_stage_play": "Zum Spielen tippen", "event_match_finish": "🌿 Eventspiel abgeschlossen!", "event_stage_reward": "Du hast 25 Tokens für dieses Spiel erhalten.", "event_all_complete": "Du hast alle fünf Spiele abgeschlossen! Öffne den Karrieremodus und tippe auf den Geschenk-Button, um Nymal Juniord (OVR 94) zu erhalten.", "event_progress": "Fortschritt: {done}/5 Spiele abgeschlossen", "event_expired_message": "Das Event FFM-Anstoß ist endgültig beendet. Es können keine neuen Spiele gestartet werden.", "event_already_done": "Du hast dieses Spiel bereits abgeschlossen.", "event_timer_notice": "Der Timer kann im Spiel nicht angehalten werden.", "event_expired_short": "Event beendet", "gift_button_ready": "🎁 Event-Belohnung abholen", "gift_button_waiting": "🎁 Event-Geschenk — schließe alle 5 Spiele ab, um es freizuschalten", "gift_button_claimed": "✅ Event-Belohnung abgeholt", "gift_button_event_ended": "⛔ Event beendet", "gift_not_ready": "Schließe zuerst alle fünf Eventspiele ab.", "gift_already_claimed": "Du hast die Event-Belohnung bereits abgeholt.", "player_card_label": "SPEZIAL-EVENT-SPIELER", "player_reward_details": "Nymal Juniord • OVR 94 • 15-Spiele-Vertrag", "player_contract_nonrenewable": "Event-Vertrag — nicht verlängerbar", "player_reward_success": "Nymal Juniord wurde deinem Kader hinzugefügt!", "player_reward_close": "Großartig!", "event_opp_name": "FFM-Anstoß-Gegner {n}", "event_completed_badge": "🏆 Alle Eventspiele abgeschlossen!", "event_card_locked": "Schließe alle fünf Spiele ab, um freizuschalten", "event_card_unlocked": "Belohnung zum Abholen bereit", "career_mode": "💼 Karrieremodus", "career_desc": "Starte in Liga 8 und steige bis an die Spitze auf", "tournaments": "🏆 Turniere", "friendly_match": "⚽ Freundschaftsspiel", "select_my_team": "Wähle dein Team:", "select_opp_team": "Wähle das gegnerische Team:", "proceed_to_match": "Zu Aufstellung & Spielfeld", "back": "Zurück", "teams_in_tourney": "Teilnehmende Teams (10 Teams)", "simulate_tourney": "Gesamtes Turnier simulieren", "current_tier": "Deine aktuelle Liga:", "your_team": "Dein Team:", "play_career_match": "⚽ Saisonspiel spielen", "manage_lineup": "📋 Aufstellung verwalten", "transfer_market": "🛒 Transfermarkt", "tier_teams": "Teams der aktuellen Liga (20 Teams):", "market_hint": "Kaufe Spieler, um deinen Kader zu verstärken (max. OVR 91)", "squad_management": "Kader & Aufstellung 4-3-3", "swap_p1": "Nr. des ersten Spielers:", "swap_p2": "Nr. des zweiten Spielers:", "swap_action": "Tauschen", "bench": "Ersatzbank (12+)", "start_match": "Simulation starten", "game_lang": "Spielsprache:", "close": "Schließen", "match_win": "🏆 Fantastischer Sieg!", "match_draw": "🤝 Unentschieden!", "match_loss": "❌ Niederlage!", "career_standings": "🏆 Teamtabelle", "player_contracts": "📄 Spielerverträge", "sell_players": "💰 Spieler verkaufen", "contracts_hint": "Jedes Karrierespiel zieht ein Spiel vom Spielervertrag ab. Verlängerung: 10 Spiele für 500 Tokens.", "sales_hint": "Der Verkaufspreis hängt von der Spielerwertung ab. Der Betrag wird deinem Token-Guthaben gutgeschrieben.", "team_label": "Team", "points_label": "Punkte", "rating_label": "Wertung", "sale_price_label": "Verkaufspreis", "tokens_label": "Tokens", "sell_action": "Spieler verkaufen", "contract_label": "Vertrag", "matches_label": "Spiele", "bench_label": "Bank", "renew_label": "Verlängern 500 🪙", "expired_label": "Vertrag abgelaufen", "active_label": "Aktiv", "not_enough_tokens": "Du brauchst 500 Tokens, um diesen Vertrag zu verlängern.", "renew_expired_only": "Du kannst erst nach Vertragsablauf verlängern.", "sell_confirm": "{name} für {price} Tokens verkaufen?", "sold_message": "Spieler verkauft. {price} Tokens wurden deinem Guthaben gutgeschrieben.", "career_upvoiced": "🎉 Glückwunsch! Aufstieg in eine höhere Liga!", "live_start": "⚽ Spiel spielen (5 Min.)", "quick_sim": "⚡ Schnellsimulation (ohne Spielen)", "lm_paused": "Pausiert", "lm_resume": "▶ Fortsetzen", "lm_quit": "✖ Spiel beenden", "lm_quit_confirm": "Spiel beenden? Es zählt nicht.", "lm_hint": "🎮 Mit Finger/Maus ziehen zum Passen oder Schießen (länger = stärker) • Joystick links oder Pfeile/WASD zum Bewegen • Leertaste = Kurzpass", "trait_event_title": "🔺 Spezialeigenschaften", "trait_kicker": "FFM 26 • SPEZIALEVENT", "trait_event_subtitle": "5 Spiele • 15 Tage • Ein Spieler mit Schusseigenschaft", "trait_match_finish": "🔺 Spiel der Spezialeigenschaften abgeschlossen!", "trait_stage_reward": "Dieses Spiel zählte für das Event.", "trait_progress": "Fortschritt: {done}/5 Spiele abgeschlossen", "trait_all_complete": "Alle 5 Spiele abgeschlossen! Öffne den Karrieremodus und tippe auf den Geschenk-Button, um Roy Blaze (OVR 91) mit der Eigenschaft Eiskalter Vollstrecker zu erhalten.", "trait_expired_message": "Das Event Spezialeigenschaften ist endgültig beendet. Es können keine neuen Spiele gestartet werden.", "trait_gift_waiting": "🔺 Eigenschaften-Event-Geschenk — schließe alle 5 Spiele ab, um es freizuschalten", "trait_gift_ready": "🔺 Spieler des Eigenschaften-Events abholen", "trait_gift_claimed": "✅ Spieler des Eigenschaften-Events abgeholt", "trait_gift_ended": "⛔ Eigenschaften-Event beendet", "trait_player_details": "Eigenschaft: Eiskalter Vollstrecker — +39 % Schusskraft & Präzision", "trait_reward_title": "🔺 Belohnung Spezialeigenschaften", "trait_timer_active": "⏱️ Event läuft", "trait_timer_expired": "⛔ Event beendet", "trait_trait_label": "Schusseigenschaft"}, "tr": {"tokens": "Jeton", "settings": "⚙️ Ayarlar", "youtube_channel": "▶️ YouTube kanalımızı ziyaret et", "save_restore_title": "💾 İlerlemeyi Kaydet ve Geri Yükle", "save_restore_hint": "Oyunu yeniden yükledikten sonra ilerlemeni kurtarmak için bir yedek dosyası oluştur.", "save_backup": "⬇️ Yedek Oluştur", "restore_backup": "♻️ Eski Kaydı Geri Yükle", "restore_found_title": "Eski Kayıt Bulundu!", "restore_found_message": "Eski bir FFM 26 kaydı bulundu. Kaldığın yerden devam etmek ister misin?", "restore_prompt_title": "Eski Kaydın Var mı?", "restore_prompt_message": "Bir FFM 26 yedek dosyan varsa, yeniden yükledikten sonra ilerlemeni geri getirmek için seç.", "restore_file_found_message": "Seçilen dosyada önceki bir kayıt bulundu. Geri yüklemek ister misin?", "restore_action": "Kaydı Geri Yükle", "choose_backup_action": "Yedek Dosyası Seç", "start_new_action": "Yeni Oyun Başlat", "cancel_action": "İptal", "backup_ready_message": "Yedek dosyan hazır. FFM26_Save.json dosyasını İndirilenler'de veya başka güvenli bir yerde sakla.", "backup_invalid_message": "Bu geçerli bir FFM 26 kayıt dosyası değil.", "music_control_title": "🎵 Müzik Ayarları", "music_mute": "Müziği Kapat", "music_volume": "Müzik Sesi", "main_menu_title": "FFM 26", "event_kicker": "FFM 26 • ÖZEL ETKİNLİK", "event_title": "🌿 FFM Başlama Vuruşu", "event_subtitle": "5 maç • Maç başına 25 jeton • Bir özel oyuncu", "event_timer_label": "Kalan süre", "event_timer_active": "⏱️ Etkinlik canlı", "event_timer_expired": "⛔ Etkinlik sona erdi", "event_timer_unconfigured": "Etkinlik başlangıç tarihi henüz belirlenmedi", "event_timer_upcoming": "Etkinliğin başlamasına", "event_timer_scheduled": "Etkinlik planlandı ve başlangıç saatinde açılacak", "event_not_live": "Etkinlik henüz başlamadı. Maçlar başlangıç saatinde açılır.", "event_stage_label": "Maç {n}", "event_stage_done": "Tamamlandı ✓", "event_stage_play": "Oynamak için dokun", "event_match_finish": "🌿 Etkinlik Maçı Tamamlandı!", "event_stage_reward": "Bu maç için 25 jeton kazandın.", "event_all_complete": "Beş maçı da tamamladın! Kariyer Modu'nu aç ve Nymal Juniord'u (OVR 94) almak için hediye düğmesine dokun.", "event_progress": "İlerleme: {done}/5 maç tamamlandı", "event_expired_message": "FFM Başlama Vuruşu etkinliği kalıcı olarak sona erdi. Yeni maç başlatılamaz.", "event_already_done": "Bu maçı zaten tamamladın.", "event_timer_notice": "Sayaç oyunun içinden durdurulamaz.", "event_expired_short": "Etkinlik sona erdi", "gift_button_ready": "🎁 Etkinlik Ödülünü Al", "gift_button_waiting": "🎁 Etkinlik Hediyesi — kilidi açmak için 5 maçı da tamamla", "gift_button_claimed": "✅ Etkinlik Ödülü Alındı", "gift_button_event_ended": "⛔ Etkinlik Sona Erdi", "gift_not_ready": "Önce beş etkinlik maçını da tamamla.", "gift_already_claimed": "Etkinlik ödülünü zaten aldın.", "player_card_label": "ÖZEL ETKİNLİK OYUNCUSU", "player_reward_details": "Nymal Juniord • OVR 94 • 15 maçlık sözleşme", "player_contract_nonrenewable": "Etkinlik sözleşmesi — yenilenemez", "player_reward_success": "Nymal Juniord kadrona eklendi!", "player_reward_close": "Harika!", "event_opp_name": "FFM Başlama Vuruşu Rakibi {n}", "event_completed_badge": "🏆 Tüm etkinlik maçları tamamlandı!", "event_card_locked": "Kilidi açmak için beş maçı da tamamla", "event_card_unlocked": "Ödül alınmaya hazır", "career_mode": "💼 Kariyer Modu", "career_desc": "8. Ligde başla ve zirveye ulaş", "tournaments": "🏆 Turnuvalar", "friendly_match": "⚽ Hazırlık Maçı", "select_my_team": "Takımını Seç:", "select_opp_team": "Rakip Takımı Seç:", "proceed_to_match": "Kadro ve Sahaya Git", "back": "Geri", "teams_in_tourney": "Katılan Takımlar (10 Takım)", "simulate_tourney": "Tüm Turnuvayı Simüle Et", "current_tier": "Şu Anki Ligin:", "your_team": "Takımın:", "play_career_match": "⚽ Sezon Maçı Oyna", "manage_lineup": "📋 Kadroyu Yönet", "transfer_market": "🛒 Transfer Piyasası", "tier_teams": "Mevcut Ligin Takımları (20 Takım):", "market_hint": "Kadronu güçlendirmek için oyuncu satın al (en fazla OVR 91)", "squad_management": "Kadro ve Diziliş 4-3-3", "swap_p1": "Birinci Oyuncu No:", "swap_p2": "İkinci Oyuncu No:", "swap_action": "Değiştir", "bench": "Yedekler / Kulübe (12+)", "start_match": "Simülasyonu Başlat", "game_lang": "Oyun Dili:", "close": "Kapat", "match_win": "🏆 Muhteşem Zafer!", "match_draw": "🤝 Berabere!", "match_loss": "❌ Yenilgi!", "career_standings": "🏆 Takım Sıralaması", "player_contracts": "📄 Oyuncu Sözleşmeleri", "sell_players": "💰 Oyuncu Sat", "contracts_hint": "Her kariyer maçı oyuncunun sözleşmesinden bir maç düşer. Yenileme: 500 jetona 10 maç.", "sales_hint": "Satış fiyatı oyuncunun puanına bağlıdır. Tutar jeton bakiyene eklenir.", "team_label": "Takım", "points_label": "Puan", "rating_label": "Puan", "sale_price_label": "Satış Fiyatı", "tokens_label": "jeton", "sell_action": "Oyuncuyu Sat", "contract_label": "Sözleşme", "matches_label": "maç", "bench_label": "Yedek", "renew_label": "Yenile 500 🪙", "expired_label": "Sözleşme bitti", "active_label": "Aktif", "not_enough_tokens": "Bu sözleşmeyi yenilemek için 500 jeton gerekir.", "renew_expired_only": "Sözleşmeyi ancak süresi dolduktan sonra yenileyebilirsin.", "sell_confirm": "{name} oyuncusunu {price} jetona satmak istiyor musun?", "sold_message": "Oyuncu satıldı. {price} jeton bakiyene eklendi.", "career_upvoiced": "🎉 Tebrikler! Bir üst lige yükseldin!", "live_start": "⚽ Maçı Oyna (5 dk)", "quick_sim": "⚡ Hızlı Simülasyon (oynamadan)", "lm_paused": "Duraklatıldı", "lm_resume": "▶ Devam Et", "lm_quit": "✖ Maçtan Çık", "lm_quit_confirm": "Maçtan çıkılsın mı? Sayılmayacak.", "lm_hint": "🎮 Pas ya da şut için parmağını/fareyi sürükle (uzun = daha güçlü) • Hareket için soldaki joystick veya oklar/WASD • Boşluk = hızlı pas", "trait_event_title": "🔺 Özel Yetenekler", "trait_kicker": "FFM 26 • ÖZEL ETKİNLİK", "trait_event_subtitle": "5 maç • 15 gün • Şut yeteneği olan bir oyuncu", "trait_match_finish": "🔺 Özel Yetenekler maçı tamamlandı!", "trait_stage_reward": "Bu maç etkinliğe sayıldı.", "trait_progress": "İlerleme: {done}/5 maç tamamlandı", "trait_all_complete": "5 maçın hepsi tamamlandı! Kariyer Modu'nu aç ve Soğukkanlı Golcü yeteneğine sahip Roy Blaze'i (OVR 91) almak için hediye düğmesine bas.", "trait_expired_message": "Özel Yetenekler etkinliği kalıcı olarak sona erdi. Yeni maç başlatılamaz.", "trait_gift_waiting": "🔺 Yetenek Etkinliği Hediyesi — kilidi açmak için 5 maçı da tamamla", "trait_gift_ready": "🔺 Yetenek Etkinliği oyuncusunu al", "trait_gift_claimed": "✅ Yetenek Etkinliği oyuncusu alındı", "trait_gift_ended": "⛔ Yetenek Etkinliği sona erdi", "trait_player_details": "Yetenek: Soğukkanlı Golcü — %39 şut gücü ve isabeti", "trait_reward_title": "🔺 Özel Yetenekler Ödülü", "trait_timer_active": "⏱️ Etkinlik canlı", "trait_timer_expired": "⛔ Etkinlik sona erdi", "trait_trait_label": "Şut yeteneği"}, "frfix": {"career_standings": "🏆 Classement des équipes", "player_contracts": "📄 Contrats des joueurs", "sell_players": "💰 Vendre des joueurs", "contracts_hint": "Chaque match de carrière retire un match au contrat d'un joueur. Renouvellement : 10 matchs pour 500 jetons.", "sales_hint": "Le prix de vente dépend de la note du joueur. Le montant est ajouté à votre solde de jetons.", "team_label": "Équipe", "points_label": "Points", "rating_label": "Note", "sale_price_label": "Prix de vente", "tokens_label": "jetons", "sell_action": "Vendre le joueur", "contract_label": "Contrat", "matches_label": "matchs", "bench_label": "Banc", "renew_label": "Renouveler 500 🪙", "expired_label": "Contrat expiré", "active_label": "Actif", "not_enough_tokens": "Il faut 500 jetons pour renouveler ce contrat.", "renew_expired_only": "Vous ne pouvez renouveler qu'après l'expiration du contrat.", "sell_confirm": "Vendre {name} pour {price} jetons ?", "sold_message": "Joueur vendu. {price} jetons ajoutés à votre solde.", "career_desc": "Commencez au Niveau 8 et visez le sommet", "event_stage_label": "Match {n}"}};
        ['es', 'pt', 'de', 'tr'].forEach(function (l) { dict[l] = Object.assign({}, dict.en, X[l]); });
        Object.assign(dict.fr, X.frfix);
        dict.ar.career_desc = 'ابدأ من الدرجة 8 وتسلّق إلى القمة';
        dict.en.career_desc = 'Start in Tier 8 and climb to the top';
    })();
    window.ffmL = function () { const m = { ar: 0, en: 1, fr: 2, es: 3, pt: 4, de: 5, tr: 6 }; const i = m[state.lang]; const v = arguments[i == null ? 1 : i]; return v == null ? arguments[1] : v; };
    function ffmDetectLang() {
        try { const c = String((navigator.languages && navigator.languages[0]) || navigator.language || 'en').toLowerCase().slice(0, 2); return ({ ar: 'ar', en: 'en', fr: 'fr', es: 'es', pt: 'pt', de: 'de', tr: 'tr' })[c] || 'en'; } catch (e) { return 'en'; }
    }
    function changeLanguage(langCode) {
        state.lang = langCode;
        applyLanguage(langCode);
        if (typeof renderCareerEventGiftButton === 'function') renderCareerEventGiftButton();
        if (typeof renderKickoffLadder === 'function') renderKickoffLadder();
        if (typeof updateKickoffEventTimerUI === 'function') updateKickoffEventTimerUI();
        saveGame();
    }

    function applyLanguage(lang) {
        const currentDict = dict[lang] || dict['ar'];
        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        document.getElementById('language-select').value = lang;
        ['screen-standings','screen-contracts','screen-player-sales'].forEach(id=>{const el=document.getElementById(id); if(el){el.dir=lang==='ar'?'rtl':'ltr';el.lang=lang;}});

        // Apply string tokens
        document.querySelectorAll('[data-key]').forEach(el => {
            const key = el.getAttribute('data-key');
            if (currentDict[key]) {
                if (el.childNodes.length > 0 && el.childNodes[0].nodeType === Node.TEXT_NODE) {
                    el.childNodes[0].nodeValue = currentDict[key] + " ";
                } else {
                    el.innerText = currentDict[key];
                }
            }
        });
        if (document.getElementById('screen-standings')?.classList.contains('active') && typeof openCareerStandings==='function') openCareerStandings();
        if (document.getElementById('screen-contracts')?.classList.contains('active') && typeof openPlayerContracts==='function') openPlayerContracts();
        if (document.getElementById('screen-player-sales')?.classList.contains('active') && typeof openPlayerSales==='function') openPlayerSales();
    }

    function showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        document.getElementById(screenId).classList.add('active');
    }

    // Friendly Match Setups
    function openFriendlyMatch() {
        const mySelect = document.getElementById('friendly-my-team');
        const oppSelect = document.getElementById('friendly-opp-team');
        mySelect.innerHTML = '';
        oppSelect.innerHTML = '';

        Object.keys(state.teams).forEach(id => {
            let opt1 = new Option(state.teams[id].name, id);
            let opt2 = new Option(state.teams[id].name, id);
            mySelect.add(opt1);
            oppSelect.add(opt2);
        });
        oppSelect.selectedIndex = 1; // Default distinct opponent
        showScreen('screen-friendly');
    }

    // Tournaments Setups (10 Tournaments, 10 teams each)
    function openTournaments() {
        const container = document.getElementById('tournaments-list');
        container.innerHTML = '';
        for (let i = 1; i <= 10; i++) {
            let btn = document.createElement('button');
            btn.className = 'godot-btn';
            btn.style.fontSize = '15px';
            btn.innerText = ffmL(`🏆 بطولة كأس الخيال ${i}`, `🏆 Fantasy Cup ${i}`, `🏆 Coupe Fantaisie ${i}`, `🏆 Copa Fantasía ${i}`, `🏆 Taça Fantasia ${i}`, `🏆 Fantasie-Pokal ${i}`, `🏆 Fantezi Kupası ${i}`);
            btn.onclick = () => openTournamentDetails(i);
            container.appendChild(btn);
        }
        showScreen('screen-tournaments');
    }

    function openTournamentDetails(id) {
        const title = document.getElementById('tourney-title');
        title.innerText = ffmL(`بطولة كأس الخيال ${id}`, `Fantasy Cup ${id}`, `Coupe Fantaisie ${id}`, `Copa Fantasía ${id}`, `Taça Fantasia ${id}`, `Fantasie-Pokal ${id}`, `Fantezi Kupası ${id}`);
        
        const list = document.getElementById('tourney-teams-list');
        list.innerHTML = '';
        // Select 10 teams based on tournament id factor
        let startIndex = ((id - 1) * 10) % 110;
        matchContext.tournamentTeams = [];
        for (let t = 1; t <= 10; t++) {
            let teamKey = `team_${startIndex + t}`;
            matchContext.tournamentTeams.push(teamKey);
            let li = document.createElement('li');
            li.innerText = state.teams[teamKey].name;
            list.appendChild(li);
        }
        showScreen('screen-tournament-detail');
    }

    function simulateTournament() {
        // Pick one random team as winner from the 10 participating teams
        let winnerIndex = Math.floor(Math.random() * matchContext.tournamentTeams.length);
        let winnerTeamId = matchContext.tournamentTeams[winnerIndex];
        // Tournament rewards are disabled: tokens can only be earned in Career Mode.
        const prize = 0;

        const _wn = state.teams[winnerTeamId].name; let statusText = ffmL(`انتهت البطولة بفوز فريق: ${_wn}`, `Tournament ended! Winner: ${_wn}`, `Tournoi terminé ! Vainqueur : ${_wn}`, `¡Torneo terminado! Ganador: ${_wn}`, `Torneio terminado! Vencedor: ${_wn}`, `Turnier beendet! Sieger: ${_wn}`, `Turnuva bitti! Kazanan: ${_wn}`);
        document.getElementById('popup-status').innerText = statusText;
        document.getElementById('popup-score').innerText = "🏆 FINAL";
        document.getElementById('popup-teams-details').innerText = ffmL("انتهت البطولة دون الحصول على توكن.", "Tournament completed with no token reward.", "Tournoi terminé sans récompense en jetons.", "Torneo completado sin recompensa de fichas.", "Torneio concluído sem recompensa de fichas.", "Turnier ohne Token-Belohnung beendet.", "Turnuva jeton ödülü olmadan tamamlandı.");
        document.getElementById('popup-tokens-earned').innerText = prize;
        document.getElementById('result-popup').style.display = 'flex';
    }

    // Career Mode Setup (4 Tiers, 20 teams each)
    function enterCareerMode() {
        if (state.draftPending && window.ffmShowDraft) { ffmShowDraft(); return; }
        document.getElementById('career-tier-display').innerText = state.currentTier;
        const container = document.getElementById('career-tier-teams');
        container.innerHTML = '';

        // Tiers range mapping: Tier 4 (teams 81-100), Tier 3 (61-80), Tier 2 (41-60), Tier 1 (1-20)
        let tierOffset = (8 - state.currentTier) * 20;
        for (let i = 1; i <= 20; i++) {
            let teamId = `team_${tierOffset + i}`;
            let div = document.createElement('div');
            div.style.padding = '3px 0';
            div.innerText = `🔹 ${state.teams[teamId] ? state.teams[teamId].name : teamId}`;
            container.appendChild(div);
        }
        renderCareerEventGiftButton();
        showScreen('screen-career');
    }

    function getCurrentTierTeamIds() {
        const offset = (8 - state.currentTier) * 20;
        if (state.currentTier === 8) return Array.from({length:20}, (_, i) => `team_${i+1}`).filter(id => state.teams[id]);
        // The player's club remains team_1; pair it with 19 clubs from the current tier.
        return ['team_1', ...Array.from({length:19}, (_, i) => `team_${offset+i+2}`)].filter(id => state.teams[id]);
    }
    function tx(key, vars={}) { let value=(dict[state.lang]||dict.en)[key] || dict.en[key] || key; return value.replace(/\{(\w+)\}/g,(_,k)=>vars[k] ?? ''); }

    // FFM Kickoff launch time: 30 October 2026 at 19:31:52 (Algeria time). The event runs for 36 days.
    // There is deliberately no timer toggle in the player-facing interface.
    const KICKOFF_EVENT_START_AT = "2026-10-30T19:31:52+01:00";
    const KICKOFF_EVENT_DURATION_MS = 36 * 24 * 60 * 60 * 1000;
    function kickoffEventStartMs() {
        if (typeof KICKOFF_EVENT_START_AT !== 'string' || !KICKOFF_EVENT_START_AT.trim()) return null;
        const parsed = Date.parse(KICKOFF_EVENT_START_AT);
        return Number.isFinite(parsed) ? parsed : null;
    }
    function kickoffEventStatus() {
        if (state.ffmKickoffEvent && state.ffmKickoffEvent.permanentlyExpired === true) return 'expired';
        const start = kickoffEventStartMs();
        if (start === null) return 'unconfigured';
        const now = Date.now();
        if (now < start) return 'upcoming';
        if (now >= start + KICKOFF_EVENT_DURATION_MS) return 'expired';
        return 'active';
    }
    function ensureKickoffEventState() {
        if (!state.ffmKickoffEvent || typeof state.ffmKickoffEvent !== 'object') state.ffmKickoffEvent = {};
        const ev = state.ffmKickoffEvent;
        if (!Array.isArray(ev.completedStages)) ev.completedStages = [];
        ev.completedStages = [...new Set(ev.completedStages.map(Number).filter(n => n >= 1 && n <= 5))];
        if (typeof ev.rewardPending !== 'boolean') ev.rewardPending = false;
        if (typeof ev.rewardClaimed !== 'boolean') ev.rewardClaimed = false;
        if (typeof ev.playerRewardAdded !== 'boolean') ev.playerRewardAdded = false;
        if (typeof ev.permanentlyExpired !== 'boolean') ev.permanentlyExpired = false;
        if (typeof ev.currentStage !== 'number') ev.currentStage = 0;
        // Ignore old per-player pause state: the release timestamp is the single source of truth.
        ev.timerEnabled = false;
        ev.timerStartedAt = null;
        const status = kickoffEventStatus();
        ev.expired = status === 'expired';
        if (ev.completedStages.length === 5 && !ev.rewardClaimed && !ev.playerRewardAdded) ev.rewardPending = true;
        return ev;
    }
    function kickoffEventRemainingMs() {
        const start = kickoffEventStartMs();
        if (start === null) return null;
        const now = Date.now();
        const end = start + KICKOFF_EVENT_DURATION_MS;
        if (now < start) return start - now;
        return Math.max(0, end - now);
    }
    function formatKickoffCountdown(ms) {
        const total = Math.max(0, Math.floor(ms / 1000));
        const days = Math.floor(total / 86400);
        const hours = Math.floor((total % 86400) / 3600).toString().padStart(2, '0');
        const mins = Math.floor((total % 3600) / 60).toString().padStart(2, '0');
        const secs = (total % 60).toString().padStart(2, '0');
        const dayWord = ffmL('ي', 'd', 'j', 'd', 'd', 'T', 'g');
        return `${days}${dayWord} ${hours}:${mins}:${secs}`;
    }
    function updateKickoffEventTimerUI() {
        const ev = ensureKickoffEventState();
        const statusKey = kickoffEventStatus();
        if (statusKey === 'expired' && !ev.permanentlyExpired) {
            ev.permanentlyExpired = true;
            ev.expired = true;
            saveGame();
        }
        const left = kickoffEventRemainingMs();
        const clock = document.getElementById('event-countdown');
        const label = document.getElementById('event-countdown-label');
        const wrap = document.getElementById('event-countdown-wrap');
        const status = document.getElementById('event-timer-status');
        if (clock) clock.textContent = left === null ? '—' : formatKickoffCountdown(left);
        if (label) label.textContent = tx(statusKey === 'upcoming' ? 'event_timer_upcoming' : 'event_timer_label');
        if (wrap) {
            wrap.classList.toggle('expired', statusKey === 'expired');
            wrap.classList.toggle('upcoming', statusKey === 'upcoming');
            wrap.style.display = statusKey === 'unconfigured' ? 'none' : 'inline-block';
        }
        if (status) status.textContent = tx(statusKey === 'unconfigured' ? 'event_timer_unconfigured' : (statusKey === 'upcoming' ? 'event_timer_scheduled' : (statusKey === 'expired' ? 'event_timer_expired' : 'event_timer_active')));
        if (window.ffmKickoffPreviousStatus !== statusKey) {
            window.ffmKickoffPreviousStatus = statusKey;
            renderKickoffLadder();
            renderCareerEventGiftButton();
        }
        if (ev.expired && document.getElementById('screen-kickoff-event')?.classList.contains('active')) {
            const msg = document.getElementById('event-progress-message');
            if (msg) msg.textContent = tx('event_expired_message');
        }
    }
    function openKickoffEvent() {
        showScreen('screen-kickoff-event');
        renderKickoffLadder();
        updateKickoffEventTimerUI();
    }
    function renderKickoffLadder() {
        const ev = ensureKickoffEventState();
        const ladder = document.getElementById('event-ladder');
        if (!ladder) return;
        ladder.innerHTML = '';
        const status = kickoffEventStatus();
        const playable = status === 'active';
        for (let n = 1; n <= 5; n++) {
            const done = ev.completedStages.includes(n);
            const node = document.createElement('button');
            node.type = 'button';
            node.className = `event-node${done ? ' completed' : ''}`;
            node.setAttribute('aria-label', tx('event_stage_label', { n }));
            node.title = done ? tx('event_stage_done') : tx('event_stage_label', { n });
            node.disabled = !playable || done;
            node.innerHTML = `<span class="node-number">${done ? '✓' : n}</span><span class="node-mini">${done ? tx('event_stage_done') : tx('event_stage_label', { n })}</span>`;
            node.onclick = () => playKickoffEventStage(n);
            ladder.appendChild(node);
        }
        // Reward player card appears at the end of the horizontal track, even before it is unlocked.
        const unlocked = ev.rewardPending || ev.rewardClaimed || ev.playerRewardAdded;
        const rewardCard = document.createElement('div');
        rewardCard.className = 'event-track-player-card';
        rewardCard.innerHTML = `<div class="event-track-card-label">${tx('player_card_label')}</div><div class="event-track-card-rating"><span>🌿</span><strong>94</strong><span>OVR</span></div><div class="event-track-card-name">Nymal Juniord</div><div class="event-track-card-meta">${tx('player_reward_details')}</div><div class="event-track-card-status">${tx(unlocked ? 'event_card_unlocked' : 'event_card_locked')}</div>`;
        ladder.appendChild(rewardCard);

        const progress = document.getElementById('event-progress-message');
        if (progress) {
            const doneCount = ev.completedStages.length;
            if (status === 'expired') progress.textContent = tx('event_expired_message');
            else if (status === 'upcoming' || status === 'unconfigured') progress.textContent = tx(status === 'upcoming' ? 'event_timer_upcoming' : 'event_timer_unconfigured');
            else progress.textContent = doneCount === 5 ? tx('event_all_complete') : tx('event_progress', { done: doneCount });
        }
    }
    function playKickoffEventStage(stage) {
        const ev = ensureKickoffEventState();
        const status = kickoffEventStatus();
        if (status === 'unconfigured' || status === 'upcoming') { alert(tx('event_not_live')); return; }
        if (status === 'expired' || ev.expired) { alert(tx('event_expired_message')); return; }
        if (ev.completedStages.includes(stage)) { alert(tx('event_already_done')); return; }
        ev.currentStage = stage;
        matchContext.type = 'event';
        matchContext.eventStage = stage;
        matchContext.myTeamId = 'team_1';
        matchContext.oppTeamId = `team_${stage + 1}`;
        setupTacticsScreen();
    }
    function renderCareerEventGiftButton() {
        const ev = ensureKickoffEventState();
        const button = document.getElementById('career-event-gift-button');
        if (!button) return;
        const endedWithoutReward = kickoffEventStatus() === 'expired' && !ev.rewardPending && !ev.rewardClaimed && !ev.playerRewardAdded;
        button.classList.toggle('ready', ev.rewardPending && !ev.rewardClaimed);
        button.classList.toggle('claimed', ev.rewardClaimed);
        button.textContent = ev.rewardClaimed ? tx('gift_button_claimed') : (ev.rewardPending ? tx('gift_button_ready') : (endedWithoutReward ? tx('gift_button_event_ended') : tx('gift_button_waiting')));
        button.disabled = endedWithoutReward;
    }
    function claimKickoffEventReward() {
        const ev = ensureKickoffEventState();
        if (ev.rewardClaimed || ev.playerRewardAdded) { alert(tx('gift_already_claimed')); renderCareerEventGiftButton(); return; }
        if (!ev.rewardPending || ev.completedStages.length < 5) { alert(tx('gift_not_ready')); return; }
        const team = state.teams && state.teams.team_1;
        if (!team || !Array.isArray(team.players)) { alert(tx('gift_not_ready')); return; }
        const existing = team.players.find(p => p && (p.eventPlayerId === 'ffm-kickoff-nymal-juniord' || (p.name === 'Nymal Juniord' && p.eventPlayer)));
        if (!existing) {
            if (!ffmCanAdd()) return;
            ffmAddPlayer({ name: 'Nymal Juniord', rating: 94, contractMatches: 15, eventPlayer: true, eventPlayerId: 'ffm-kickoff-nymal-juniord', contractRenewable: false });
        }
        ev.rewardPending = false; ev.rewardClaimed = true; ev.playerRewardAdded = true;
        saveGame(); renderCareerEventGiftButton(); openKickoffRewardPopup();
    }
    function openKickoffRewardPopup() {
        const card = document.getElementById('event-player-card-popup');
        if (card) card.innerHTML = `<div class="event-player-card"><div style="font-size:12px;letter-spacing:1.5px;font-weight:900;color:#d8ffe5;">${tx('player_card_label')}</div><div style="display:flex;justify-content:space-between;align-items:flex-start;margin-top:12px;"><span style="font-size:38px;">🌿</span><span class="event-player-ovr">94<small style="display:block;font-size:10px;text-align:center;">OVR</small></span></div><div class="event-player-name">Nymal Juniord</div><div class="event-player-meta">${tx('player_reward_details')}</div><div style="font-size:12px;margin-top:8px;color:#c8ffda;">${tx('player_contract_nonrenewable')}</div></div><p style="line-height:1.5;">${tx('player_reward_success')}</p>`;
        document.getElementById('event-reward-popup').style.display = 'flex';
    }
    function closeKickoffRewardPopup() { document.getElementById('event-reward-popup').style.display = 'none'; enterCareerMode(); }

    function openCareerStandings() {
        const ids=getCurrentTierTeamIds(); ids.sort((a,b)=>(state.careerStandings[b]||0)-(state.careerStandings[a]||0)||a.localeCompare(b,undefined,{numeric:true}));
        const rows=ids.map((id,i)=>`<tr><td>${i+1}</td><td style="text-align:${state.lang==='ar'?'right':'left'};padding:7px">${state.teams[id].name}</td><td>${state.careerStandings[id]||0}</td></tr>`).join('');
        const progress = `${state.careerSeasonMatches || 0}/19`;
        const progressLabel = ffmL(`مباريات الموسم: ${progress}`, `Season matches: ${progress}`, `Matchs de saison : ${progress}`, `Partidos de la temporada: ${progress}`, `Jogos da época: ${progress}`, `Saisonspiele: ${progress}`, `Sezon maçları: ${progress}`);
        document.getElementById('career-standings-table').innerHTML=`<div style="margin-bottom:8px;color:#cfcfcf">${progressLabel}</div><table style="width:100%;border-collapse:collapse;text-align:center;color:#fff"><thead><tr style="background:#444"><th style="padding:8px">#</th><th>${tx('team_label')}</th><th>${tx('points_label')}</th></tr></thead><tbody>${rows}</tbody></table>`; showScreen('screen-standings');
    }
    function openPlayerContracts() {
        const list=document.getElementById('player-contracts-list');
        list.innerHTML=state.teams.team_1.players.map((p,i)=>`<div class="contract-row"><div>${p.trait?'<i class="trait-tri inline"></i>':''}<b>${p.number}. ${p.name}</b><div style="color:${p.contractMatches<=0?'#ff7777':'#f5c542'}">${tx('contract_label')}: ${p.contractMatches} ${tx('matches_label')} ${p.onBench?' • '+tx('bench_label'):''}</div>${p.eventPlayer?`<div style="font-size:11px;color:#9affb7;margin-top:3px;">${tx('player_contract_nonrenewable')}</div>`:''}</div><div style="display:flex;gap:5px;flex-wrap:wrap;justify-content:flex-end">${p.eventPlayer||p.contractRenewable===false?(p.contractMatches<=0?tx('expired_label'):tx('active_label')):(p.contractMatches<=0&&!p.onBench?`<button class="godot-btn" onclick="renewPlayerContract(${i})">${tx('renew_label')}</button><button class="godot-btn" onclick="benchExpiredPlayer(${i})">${tx('bench_label')}</button>`:(p.contractMatches<=0?tx('expired_label'):tx('active_label')))}</div></div>`).join(''); showScreen('screen-contracts');
    }
    function renewPlayerContract(index) { const p=state.teams.team_1.players[index]; if (!p) return; if (p.eventPlayer || p.contractRenewable === false) { alert(tx('player_contract_nonrenewable')); return; } if(state.tokens<500){ffmShort('tok', tx('not_enough_tokens'), tx('not_enough_tokens'));return;} if(p.contractMatches>0){alert(tx('renew_expired_only'));return;} state.tokens-=500;p.contractMatches+=10;p.onBench=false;updateTokenDisplay();saveGame();openPlayerContracts(); }
    const FFM_MAX_SQUAD = 200; window.FFM_MAX_SQUAD = FFM_MAX_SQUAD;
    function ffmFullMsg() { const n = FFM_MAX_SQUAD; return ffmL('وصل فريقك إلى ' + n + ' لاعب. بِع بعض اللاعبين أولًا.', 'Your squad has reached ' + n + ' players. Sell some players first.', 'Votre effectif atteint ' + n + ' joueurs. Vendez-en d\'abord.', 'Tu plantilla llegó a ' + n + ' jugadores. Primero vende algunos.', 'O seu plantel chegou a ' + n + ' jogadores. Venda alguns primeiro.', 'Dein Kader hat ' + n + ' Spieler erreicht. Verkaufe zuerst einige.', 'Kadron ' + n + ' oyuncuya ulaştı. Önce bazılarını sat.'); }
    function ffmCanAdd() { if (state.teams.team_1.players.length >= FFM_MAX_SQUAD) { alert(ffmFullMsg()); return false; } return true; }
    function ffmAddPlayer(o) { const pl = state.teams.team_1.players; let n = 0; pl.forEach(p => { if (p && p.number > n) n = p.number; }); o.number = n + 1; o.onBench = true; pl.push(o); return o; }
    window.ffmAddPlayer = ffmAddPlayer; window.ffmCanAdd = ffmCanAdd;
    function benchExpiredPlayer(index) { const team=state.teams.team_1,p=team.players[index];if(p.contractMatches>0)return;p.onBench=true;if(index<11){const sub=team.players.findIndex((x,i)=>i>=11&&!x.onBench&&x.contractMatches>0);if(sub>=0){const tmp=team.players[index];team.players[index]=team.players[sub];team.players[sub]=tmp;}}saveGame();openPlayerContracts(); }
    function processCareerContracts() { state.teams.team_1.players.slice(0,11).forEach(p=>{if(!p.onBench&&p.contractMatches>0)p.contractMatches--;});saveGame(); }
    function openPlayerSales() {
        const list = document.getElementById('player-sales-list'); const squad = state.teams.team_1.players;
        list.innerHTML = squad.map((p, i) => { const price = ffmSellPrice(p); return `<div class="contract-row"><div>${p.trait?'<i class="trait-tri inline"></i>':''}<b>${p.number}. ${p.name}</b><div style="color:#f5c542">${tx('rating_label')}: ${p.rating} | ${tx('sale_price_label')}: ${price} ${tx('tokens_label')}</div></div><button class="godot-btn" onclick="sellCareerPlayer(${i})">${tx('sell_action')}</button></div>`; }).join(''); showScreen('screen-player-sales');
    }
    function sellCareerPlayer(index) {
        const team = state.teams.team_1; const p = team.players[index]; if (!p) return;
        const price = ffmSellPrice(p);
        if (!(price > 0)) { alert(ffmL('لا يمكن بيع هذا اللاعب (بديل أو سبق بيعه).', 'This player cannot be sold (placeholder or already sold).', 'Ce joueur ne peut pas être vendu (remplaçant ou déjà vendu).', 'Este jugador no se puede vender (suplente o ya vendido).', 'Este jogador não pode ser vendido (suplente ou já vendido).', 'Dieser Spieler kann nicht verkauft werden (Ersatz oder bereits verkauft).', 'Bu oyuncu satılamaz (yedek veya daha önce satıldı).')); return; }
        if (!window.__sellOk) { ffmConfirm(tx('sell_confirm',{name:p.name,price}), () => { window.__sellOk = true; try { sellCareerPlayer(index); } finally { window.__sellOk = false; } }); return; }
        const number = p.number;
        if (p.storeUid && state.store && state.store.inventory) { const inv = state.store.inventory.find(x => x.uid === p.storeUid); if (inv) { inv.joined = false; inv.sold = true; } }
        if (team.players.length > 22) {
            if (index < 11) { const tmp = team.players[index]; team.players[index] = team.players[11]; team.players[11] = tmp; index = 11; }
            team.players.splice(index, 1);
            team.players.forEach((q, i) => { if (q) q.onBench = i >= 11; });
        } else {
            team.players[index] = { number, placeholder: true, name: ffmL('لاعب بديل', 'Replacement Player', 'Joueur remplaçant', 'Jugador suplente', 'Jogador suplente', 'Ersatzspieler', 'Yedek Oyuncu'), rating: 60, contractMatches: 10, onBench: true };
        }
        state.tokens += price; updateTokenDisplay(); saveGame(); openPlayerSales(); alert(tx('sold_message',{price}));
    }


    function openSquadManagement() {
        matchContext.type = 'manage';
        matchContext.myTeamId = 'team_1'; // Player always manages team_1 in Career Mode
        setupTacticsScreen();
    }

    function openTransferMarket() {
        const container = document.getElementById('market-players-container');
        container.innerHTML = '';
        
        // Generate 4 randomized transfer players with high rating cap of 91
        for (let i = 0; i < 4; i++) {
            let rRating = 75 + Math.floor(Math.random() * 17); // 75 to 91
            if (rRating > 91) rRating = 91;
            let tokenCost = rRating * 3; 

            let pFirstName = fakeFirstNames[Math.floor(Math.random() * fakeFirstNames.length)];
            let pLastName = fakeLastNames[Math.floor(Math.random() * fakeLastNames.length)];
            let pName = `${pFirstName} ${pLastName}`;

            let card = document.createElement('div');
            card.className = 'market-card';
            card.innerHTML = `
                <div style="font-weight:bold; color:var(--accent-color); font-size:16px;">⭐ ${rRating}</div>
                <div style="font-size:13px; margin:5px 0; min-height:34px;">${pName}</div>
                <button class="godot-btn" style="font-size:12px; padding:4px 8px; width:100%; background:#df7e26;" onclick="buyPlayer('${pName}', ${rRating}, ${tokenCost})">
                    🪙 ${tokenCost}
                </button>
            `;
            container.appendChild(card);
        }
        showScreen('screen-market');
    }

    function buyPlayer(name, rating, cost) {
        if (state.tokens < cost) {
            const _m = ffmL("ليس لديك توكنات كافية!", "Not enough tokens!", "Pas assez de jetons !", "¡No tienes suficientes fichas!", "Não tem fichas suficientes!", "Nicht genug Tokens!", "Yeterli jetonun yok!");
            ffmShort('tok', _m, _m);
            return;
        }
        if (!ffmCanAdd()) return;
        state.tokens -= cost;
        const np = ffmAddPlayer({ name: name, rating: rating, contractMatches: 10 });
        updateTokenDisplay();
        saveGame();
        alert(ffmL(`تم شراء اللاعب ${name} بنجاح وانضم إلى فريقك!`, `Successfully bought ${name}! He joined your squad.`, `${name} acheté avec succès ! Il rejoint votre équipe.`, `¡${name} fichado con éxito! Se une a tu plantilla.`, `${name} contratado com sucesso! Juntou-se ao seu plantel.`, `${name} erfolgreich gekauft! Er ist deinem Kader beigetreten.`, `${name} başarıyla satın alındı! Kadroya katıldı.`));
        openTransferMarket();
    }

    // Tactical Pre-match & Lineup Preparation Screen
    function goToTactics(mode) {
        matchContext.type = mode;
        if (mode === 'friendly') {
            matchContext.myTeamId = document.getElementById('friendly-my-team').value;
            matchContext.oppTeamId = document.getElementById('friendly-opp-team').value;
        } else if (mode === 'career') {
            const squad = state.teams.team_1?.players || [];
            const expiredStarter = squad.find(p => Number(p.contractMatches) <= 0);
            if (expiredStarter) {
                const _en = expiredStarter.name; const message = ffmL(`لا يمكن لعب المباراة القادمة! انتهى عقد اللاعب ${_en}. جدّد عقده أو أخرجه من التشكيلة الأساسية أولاً.`, `Next match blocked: ${_en}'s contract has expired. Renew it or remove the player from the starting XI.`, `Match bloqué : le contrat de ${_en} est expiré. Renouvelez-le ou retirez-le du onze titulaire.`, `Partido bloqueado: el contrato de ${_en} ha caducado. Renuévalo o sácalo del once inicial.`, `Jogo bloqueado: o contrato de ${_en} expirou. Renove-o ou retire-o do onze inicial.`, `Spiel gesperrt: Der Vertrag von ${_en} ist abgelaufen. Verlängere ihn oder nimm ihn aus der Startelf.`, `Maç engellendi: ${_en} oyuncusunun sözleşmesi bitti. Yenile veya ilk 11'den çıkar.`);
                alert(message);
                openPlayerContracts();
                return;
            }
            matchContext.myTeamId = 'team_1';
            // Opponents belong to the current tier; team_1 is always the user's club.
            const tierOffset = (8 - state.currentTier) * 20;
            const firstOpponent = state.currentTier === 8 ? 2 : tierOffset + 2;
            const randOpp = firstOpponent + Math.floor(Math.random() * 19);
            matchContext.oppTeamId = `team_${randOpp}`;
        }
        setupTacticsScreen();
    }

    function setupTacticsScreen() {
        const startBtn = document.getElementById('start-match-btn');
        const backBtn = document.getElementById('tactics-back-btn');
        
        if (matchContext.type === 'manage') {
            startBtn.style.display = 'none'; { const q = document.getElementById('quick-sim-btn'); if (q) q.style.display = 'none'; }
            backBtn.setAttribute('onclick', "showScreen('screen-career')");
        } else {
            startBtn.style.display = 'block'; { const q = document.getElementById('quick-sim-btn'); if (q) q.style.display = 'block'; }
            backBtn.setAttribute('onclick', matchContext.type === 'friendly' ? "showScreen('screen-friendly')" : (matchContext.type === 'event' ? "openKickoffEvent()" : (matchContext.type === 'trait' ? "openTraitEvent()" : "showScreen('screen-career')")));
        }

        { const bb = document.getElementById('best-xi-btn'); if (bb) { bb.textContent = '⭐ ' + ffmL('اختيار أفضل تشكيلة', 'Pick Best Lineup', 'Choisir la meilleure composition', 'Elegir mejor alineación', 'Escolher melhor escalação', 'Beste Aufstellung wählen', 'En İyi Kadroyu Seç'); bb.style.display = matchContext.myTeamId === 'team_1' ? '' : 'none'; } }
        renderTacticalPitch();
        showScreen('screen-tactics');
    }

    function renderTacticalPitch() {
        const pitch = document.getElementById('pitch-field');
        // Clear previous players but keep structural pitch lines
        document.querySelectorAll('.pitch-player').forEach(p => p.remove());

        const team = state.teams[matchContext.myTeamId];
        if (!team) return;

        // Render first 11 on the 4-3-3 formation points
        for (let i = 0; i < 11; i++) {
            let pNode = document.createElement('div');
            pNode.className = 'pitch-player';
            pNode.style.bottom = formation433[i].bottom;
            pNode.style.left = formation433[i].left;

            let player = team.players[i];
            pNode.innerHTML = `
                ${ffmPitchCard(player)}
                <span class="player-contract-badge">${player.contractMatches ?? 10} ${ffmL('م', 'M', 'm', 'P', 'J', 'S', 'M')}</span>
                
            `;
            pitch.appendChild(pNode);
        }

        // Render substitutes list (indices 11 to 21)
        const benchContainer = document.getElementById('bench-list-container');
        benchContainer.innerHTML = '';
        for (let i = 11; i < team.players.length; i++) {
            let player = team.players[i];
            let item = document.createElement('div');
            item.className = 'bench-item';
            item.innerHTML = `<span>${player.trait ? '<i class="trait-tri inline"></i>' : ''}${player.nat ? `<img class="bench-flag" src="${FFMStoreData.flagURL(player.nat)}" alt="">` : ''}<b>#${player.number}</b> ${player.name}</span> <span style="color:var(--accent-color)">OVR ${player.rating}</span>`;
            benchContainer.appendChild(item);
        }
    }

    // Auto-pick the best XI: highest ratings placed in their natural slots
    function ffmBestXI() {
        const team = state.teams[matchContext.myTeamId]; if (!team) return;
        const all = team.players.filter(p => p && !p.placeholder);
        const SLOTS = [['GK', 0], ['ST', 9], ['LW', 8], ['RW', 10], ['CB', 2], ['CB', 3], ['LB', 1], ['RB', 4], ['CM', 5], ['CM', 6], ['CM', 7]];
        const GRP = { GK: 'G', CB: 'D', LB: 'D', RB: 'D', CDM: 'M', CM: 'M', CAM: 'M', LW: 'F', RW: 'F', ST: 'F' };
        const slotGrp = { GK: 'G', CB: 'D', LB: 'D', RB: 'D', CM: 'M', LW: 'F', RW: 'F', ST: 'F' };
        const eff = (p, slot) => {
            let r = Number(p.rating) || 0; const pos = p.pos;
            if (!pos) return slot === 'GK' ? r - 100 : r - 4;
            if (pos === slot || (slot === 'CM' && (pos === 'CDM' || pos === 'CAM'))) return r - (pos === slot ? 0 : 1);
            if (slot === 'GK' || pos === 'GK') return r - 100;
            if (GRP[pos] === slotGrp[slot]) return r - 6;
            return r - 25;
        };
        const usable = all.filter(p => Number(p.contractMatches) > 0 || p.contractMatches === undefined);
        const used = new Set(), xi = new Array(11);
        for (const [slot, idx] of SLOTS) {
            let best = null, bs = -1e9;
            for (const p of usable) { if (used.has(p)) continue; const sc = eff(p, slot); if (sc > bs) { bs = sc; best = p; } }
            if (best) { used.add(best); xi[idx] = best; }
        }
        if (xi.some(x => !x)) { alert(ffmL('لا يوجد عدد كافٍ من اللاعبين الصالحين.', 'Not enough eligible players.', 'Pas assez de joueurs disponibles.', 'No hay suficientes jugadores disponibles.', 'Não há jogadores suficientes.', 'Nicht genug spielberechtigte Spieler.', 'Yeterli uygun oyuncu yok.')); return; }
        const rest = team.players.filter(p => p && !used.has(p)).sort((a, b) => (Number(b.rating) || 0) - (Number(a.rating) || 0));
        team.players = xi.concat(rest);
        team.players.forEach((p, i) => { if (p) p.onBench = i >= 11; });
        saveGame(); renderTacticalPitch();
        const avg = Math.round(xi.reduce((t, p) => t + (Number(p.rating) || 0), 0) / 11 * 10) / 10;
        alert(ffmL('تم اختيار أفضل تشكيلة! متوسط التقييم: ' + avg, 'Best lineup selected! Average rating: ' + avg, 'Meilleure composition choisie ! Note moyenne : ' + avg, '¡Mejor alineación elegida! Media: ' + avg, 'Melhor escalação escolhida! Média: ' + avg, 'Beste Aufstellung gewählt! Durchschnitt: ' + avg, 'En iyi kadro seçildi! Ortalama: ' + avg));
    }

    // Swap Execution Logic based on Player Numbers
    function executeSwap() {
        let p1Num = parseInt(document.getElementById('swap-p1').value);
        let p2Num = parseInt(document.getElementById('swap-p2').value);

        if (!p1Num || !p2Num || p1Num < 1 || p2Num < 1) {
            alert(ffmL("يرجى إدخال أرقام لاعبين صحيحة", "Please enter valid player numbers", "Veuillez saisir des numéros de joueurs valides", "Introduce números de jugador válidos", "Introduza números de jogador válidos", "Bitte gültige Spielernummern eingeben", "Geçerli oyuncu numaraları gir"));
            return;
        }

        let team = state.teams[matchContext.myTeamId];
        // Find indices of the selected numbers
        let idx1 = team.players.findIndex(p => p.number === p1Num);
        let idx2 = team.players.findIndex(p => p.number === p2Num);

        if (idx1 !== -1 && idx2 !== -1) {
            // Swap the full player objects inside the array positions
            let temp = team.players[idx1];
            team.players[idx1] = team.players[idx2];
            team.players[idx2] = temp;
            team.players.forEach((p, i) => { if (p) p.onBench = i >= 11; });

            saveGame();
            renderTacticalPitch();
            
            // Clear inputs
            document.getElementById('swap-p1').value = '';
            document.getElementById('swap-p2').value = '';
        }
    }

    // Match Simulation Engines
    function startMatchSimulation(forced) {
        const myTeam = state.teams[matchContext.myTeamId];
        const oppTeam = state.teams[matchContext.oppTeamId];
        if (!myTeam || !oppTeam) return;

        // Final contract validation: no career match may start with an expired starter.
        if (matchContext.type === 'career') {
            const expiredStarter = myTeam.players.find(p => Number(p.contractMatches) <= 0);
            if (expiredStarter) {
                { const _en = expiredStarter.name; alert(ffmL(`تم منع المباراة لأن عقد ${_en} منتهٍ. جدّد العقد أو أخرجه من التشكيلة الأساسية.`, `Match blocked: ${_en}'s contract has expired. Renew it or remove the player from the starting XI.`, `Match bloqué : le contrat de ${_en} est expiré. Renouvelez-le ou retirez-le du onze titulaire.`, `Partido bloqueado: el contrato de ${_en} ha caducado. Renuévalo o sácalo del once inicial.`, `Jogo bloqueado: o contrato de ${_en} expirou. Renove-o ou retire-o do onze inicial.`, `Spiel gesperrt: Der Vertrag von ${_en} ist abgelaufen. Verlängere ihn oder nimm ihn aus der Startelf.`, `Maç engellendi: ${_en} oyuncusunun sözleşmesi bitti. Yenile veya ilk 11'den çıkar.`)); }
                openPlayerContracts();
                return;
            }
        }

        const averageRating = players => players.slice(0, 11).reduce((sum, p) => sum + (Number(p.rating) || 50), 0) / 11;
        const myPower = averageRating(myTeam.players);
        let oppPower = averageRating(oppTeam.players);

        // Each higher division makes career opponents stronger, not the player's own team.
        if (matchContext.type === 'career') oppPower += (8 - state.currentTier) * 2.2;

        // Poisson-style goal simulation: team strength changes expected goals,
        // while randomness keeps upsets and draws possible.
        const sampleGoals = lambda => {
            const limit = Math.exp(-lambda);
            let product = 1, count = 0;
            do { count++; product *= Math.random(); } while (product > limit && count < 9);
            return count - 1;
        };
        const strengthGap = myPower - oppPower;
        const myExpectedGoals = Math.max(0.25, Math.min(3.1, 1.35 + strengthGap * 0.105));
        const oppExpectedGoals = Math.max(0.25, Math.min(3.1, 1.25 - strengthGap * 0.095));
        let myScore = forced ? forced.my : sampleGoals(myExpectedGoals);
        let oppScore = forced ? forced.opp : sampleGoals(oppExpectedGoals);

        let tokensEarned = matchContext.type === 'event' ? 25 : (matchContext.type === 'career' ? 20 : 0);
        let statusKey = 'match_draw';

        if (myScore > oppScore) {
            tokensEarned = matchContext.type === 'event' ? 25 : (matchContext.type === 'career' ? 50 : 0);
            statusKey = 'match_win';
        } else if (myScore < oppScore) {
            tokensEarned = matchContext.type === 'event' ? 25 : (matchContext.type === 'career' ? 5 : 0);
            statusKey = 'match_loss';
        }

        if (matchContext.type === 'trait') { if (!traitEventCompleteStage()) return; }

        if (matchContext.type === 'event') {
            const ev = ensureKickoffEventState();
            if (kickoffEventStatus() !== 'active') {
                alert(tx(kickoffEventStatus() === 'expired' ? 'event_expired_message' : 'event_not_live'));
                showScreen('screen-kickoff-event');
                updateKickoffEventTimerUI();
                return;
            }
            const stage = Number(matchContext.eventStage || ev.currentStage || 0);
            if (stage >= 1 && stage <= 5 && !ev.completedStages.includes(stage)) ev.completedStages.push(stage);
            if (ev.completedStages.length === 5 && !ev.rewardClaimed && !ev.playerRewardAdded) ev.rewardPending = true;
            ev.currentStage = 0;
            renderKickoffLadder();
            renderCareerEventGiftButton();
        }

        if (matchContext.type === 'career') {
            const points=state.careerStandings||(state.careerStandings={});
            points[matchContext.myTeamId]=points[matchContext.myTeamId]||0; points[matchContext.oppTeamId]=points[matchContext.oppTeamId]||0;
            if(myScore>oppScore)points[matchContext.myTeamId]+=3;else if(myScore<oppScore)points[matchContext.oppTeamId]+=3;else{points[matchContext.myTeamId]++;points[matchContext.oppTeamId]++;}
            processCareerContracts();
            state.careerSeasonMatches = (state.careerSeasonMatches || 0) + 1;
            if (state.careerSeasonMatches >= 19) {
                const leagueIds = getCurrentTierTeamIds();
                const ranked = [...leagueIds].sort((a, b) =>
                    (points[b] || 0) - (points[a] || 0) ||
                    (averageRating(state.teams[b].players) - averageRating(state.teams[a].players)) ||
                    a.localeCompare(b, undefined, {numeric:true})
                );
                const playerRank = ranked.indexOf('team_1') + 1;
                const promoted = playerRank >= 1 && playerRank <= 3 && state.currentTier > 1;
                if (promoted) state.currentTier -= 1;
                // A completed season always starts fresh; finishing 4th-20th never promotes.
                leagueIds.forEach(id => { points[id] = 0; });
                state.careerSeasonMatches = 0;
                state.lastCareerSeasonRank = playerRank;
                state.lastCareerSeasonPromoted = promoted;
                const seasonMessage = promoted
                    ? ffmL(`🎉 أنهيت الموسم في المركز ${playerRank}! صعدت إلى الدرجة ${state.currentTier}.`, `🎉 You finished ${playerRank}${playerRank===1?'st':playerRank===2?'nd':'rd'} and were promoted to Tier ${state.currentTier}.`, `🎉 Vous terminez ${playerRank}${playerRank===1?'er':'e'} et montez au niveau ${state.currentTier}.`, `🎉 ¡Terminaste en el puesto ${playerRank} y ascendiste a la división ${state.currentTier}!`, `🎉 Terminou em ${playerRank}.º lugar e subiu para a divisão ${state.currentTier}!`, `🎉 Du wurdest Platz ${playerRank} und bist in Liga ${state.currentTier} aufgestiegen!`, `🎉 ${playerRank}. sırada bitirdin ve ${state.currentTier}. lige yükseldin!`)
                    : ffmL(`انتهى الموسم! مركزك ${playerRank}. الصعود متاح فقط للمراكز الثلاثة الأولى.`, `Season finished! Your rank: ${playerRank}. Only the top 3 teams are promoted.`, `Saison terminée ! Votre rang : ${playerRank}. Seules les 3 premières équipes montent.`, `¡Temporada terminada! Tu puesto: ${playerRank}. Solo ascienden los 3 primeros.`, `Época terminada! A sua posição: ${playerRank}. Só os 3 primeiros sobem.`, `Saison beendet! Dein Rang: ${playerRank}. Nur die Top 3 steigen auf.`, `Sezon bitti! Sıran: ${playerRank}. Yalnızca ilk 3 takım yükselir.`);
                setTimeout(() => alert(seasonMessage), 250);
            }
        }
        state.tokens += tokensEarned;
        updateTokenDisplay();
        saveGame();

        // Populate popup
        document.getElementById('popup-status').innerText = matchContext.type === 'event' ? tx('event_match_finish') : (dict[state.lang][statusKey] || dict['ar'][statusKey]);
        document.getElementById('popup-score').innerText = `${myScore} - ${oppScore}`;
        const eventDetails = matchContext.type === 'event' ? `${tx('event_opp_name', { n: matchContext.eventStage || '' })} • ${tx('event_stage_reward')}` : `${myTeam.name} vs ${oppTeam.name}`;
        document.getElementById('popup-teams-details').innerText = eventDetails;
        document.getElementById('popup-tokens-earned').innerText = tokensEarned;
        if (matchContext.type === 'friendly') {
            document.getElementById('popup-teams-details').innerText +=
                ffmL(' — لا توجد مكافأة توكن للمباريات الودية.', ' — No token reward for friendly matches.', ' — Pas de récompense en jetons pour les matchs amicaux.', ' — Sin recompensa de fichas en amistosos.', ' — Sem recompensa de fichas em amistosos.', ' — Keine Token-Belohnung bei Freundschaftsspielen.', ' — Hazırlık maçlarında jeton ödülü yok.');
        }
        if (matchContext.type === 'event' && ensureKickoffEventState().completedStages.length === 5) {
            document.getElementById('popup-teams-details').innerText += ' • ' + tx('event_all_complete');
        }
        if (matchContext.type === 'event') { saveGame(); renderKickoffLadder(); renderCareerEventGiftButton(); }
        if (matchContext.type === 'trait') {
            document.getElementById('popup-status').innerText = tx('trait_match_finish');
            document.getElementById('popup-teams-details').innerText = tx('event_stage_label', { n: matchContext.eventStage || '' }) + ' • ' + tx('trait_stage_reward') + (ensureTraitEventState().completedStages.length === 5 ? ' • ' + tx('trait_all_complete') : '');
        }
        document.getElementById('result-popup').style.display = 'flex';
    }

    function closePopup() {
        document.getElementById('result-popup').style.display = 'none';
        if (matchContext.type === 'career') {
            enterCareerMode();
        } else if (matchContext.type === 'event') {
            openKickoffEvent();
        } else if (matchContext.type === 'trait') {
            openTraitEvent();
        } else {
            showScreen('screen-main-menu');
        }
    }

    // Auto Run on script execution
    window.onload = initGame;
