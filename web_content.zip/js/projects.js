/**
 * Panchal Business Manager - Contractor & Interior Project Management
 * Project Opening, Agreements, Client vs Contractor Materials, Labour/Site Expenses,
 * Daily Progress, Extra Work Approval & Project-wise Profit.
 */
(function (global) {
  "use strict";

  const I18N = {
    en: {
      newProjectBtn: "+ New Project",
      kpiActive: "Active Sites",
      kpiContract: "Contract Value",
      kpiCost: "Total Site Cost",
      kpiProfit: "Est. Net Profit",
      emptyTitle: "No contractor/interior projects yet",
      emptyDesc: "Open a project to track agreement value, client materials, labour expenses, daily progress & profit.",
      btnWorkspace: "Open Site Workspace",
      btnEdit: "Edit",
      btnDelete: "Delete",
      btnPrint: "Print Summary",
      modalAddProject: "Open New Project",
      modalEditProject: "Edit Project",
      fieldName: "Project / Site Name *",
      fieldClient: "Client Name *",
      fieldLocation: "Site Address / Location",
      fieldValue: "Agreement / Contract Value (₹) *",
      fieldStart: "Start Date",
      fieldStatus: "Status",
      statusACTIVE: "Active",
      statusON_HOLD: "On Hold",
      statusCOMPLETED: "Completed",
      toastSaved: "Project saved.",
      toastDeleted: "Project deleted.",
      confirmDelTitle: "Delete Project?",
      confirmDelMsg: "This removes the project and all its material/expense/progress logs.",
      wsTabOverview: "Profit & Overview",
      wsTabExpense: "Labour & Expenses",
      wsTabMaterial: "Client / Site Material",
      wsTabProgress: "Daily Progress",
      wsTabExtra: "Extra Work Approval",
      addEntryBtn: "+ Add Entry",
      entryTypeEXPENSE: "Labour / Site Expense",
      entryTypeCONTRACTOR_MATERIAL: "Contractor Material",
      entryTypeCLIENT_MATERIAL: "Client Supplied Material",
      entryTypePROGRESS: "Daily Progress Log",
      entryTypeEXTRA_WORK: "Extra Work Quote",
      approveBtn: "Approve",
      approvedLabel: "Approved",
      pendingLabel: "Pending Approval",
      contractPlusExtra: "Contract + Approved Extra",
      totalExpensesLabel: "Contractor Cost (Labour + Material)",
      netProjectProfit: "Project Net Profit",
      saveBtn: "Save",
      cancelBtn: "Cancel",
      deleteBtn: "Delete"
    },
    hi: {
      newProjectBtn: "+ नया प्रोजेक्ट",
      kpiActive: "चालू साइट्स",
      kpiContract: "कुल ठेका राशि",
      kpiCost: "कुल साइट खर्च",
      kpiProfit: "अनुमानित मुनाफ़ा",
      emptyTitle: "अभी कोई कॉन्ट्रैक्टर / इंटीरियर प्रोजेक्ट नहीं है",
      emptyDesc: "ठेका राशि, क्लाइंट का सामान, मज़दूरी/खर्च, रोज़ का काम और प्रोजेक्ट मुनाफ़ा देखने के लिए नया प्रोजेक्ट खोलें।",
      btnWorkspace: "साइट खोलें",
      btnEdit: "बदलें",
      btnDelete: "हटाएँ",
      btnPrint: "प्रिंट रिपोर्ट",
      modalAddProject: "नया प्रोजेक्ट शुरू करें",
      modalEditProject: "प्रोजेक्ट बदलें",
      fieldName: "प्रोजेक्ट / साइट का नाम *",
      fieldClient: "क्लाइंट का नाम *",
      fieldLocation: "साइट का पता",
      fieldValue: "एग्रीमेंट / ठेका राशि (₹) *",
      fieldStart: "शुरू होने की तारीख़",
      fieldStatus: "स्थिति",
      statusACTIVE: "चालू (Active)",
      statusON_HOLD: "रुका हुआ (On Hold)",
      statusCOMPLETED: "पूरा (Completed)",
      toastSaved: "प्रोजेक्ट सेव हो गया।",
      toastDeleted: "प्रोजेक्ट हटा दिया गया।",
      confirmDelTitle: "प्रोजेक्ट हटाएँ?",
      confirmDelMsg: "प्रोजेक्ट और इसके सभी खर्च, मटेरियल व प्रोग्रेस रिकॉर्ड हट जाएँगे।",
      wsTabOverview: "मुनाफ़ा सारांश",
      wsTabExpense: "लेबर व खर्च",
      wsTabMaterial: "क्लाइंट / साइट मटेरियल",
      wsTabProgress: "दैनिक काम (Progress)",
      wsTabExtra: "एक्स्ट्रा काम मंजूरी",
      addEntryBtn: "+ नई एंट्री",
      entryTypeEXPENSE: "लेबर / साइट खर्च",
      entryTypeCONTRACTOR_MATERIAL: "कॉन्ट्रैक्टर मटेरियल",
      entryTypeCLIENT_MATERIAL: "क्लाइंट द्वारा दिया मटेरियल",
      entryTypePROGRESS: "आज का काम (Progress)",
      entryTypeEXTRA_WORK: "अतिरिक्त काम (Extra Work)",
      approveBtn: "मंजूर करें",
      approvedLabel: "मंजूर (Approved)",
      pendingLabel: "मंजूरी बाकी",
      contractPlusExtra: "ठेका + मंजूर एक्स्ट्रा काम",
      totalExpensesLabel: "कॉन्ट्रैक्टर खर्च (लेबर + मटेरियल)",
      netProjectProfit: "प्रोजेक्ट शुद्ध मुनाफ़ा",
      saveBtn: "सेव करें",
      cancelBtn: "रद्द करें",
      deleteBtn: "हटाएँ"
    }
  };

  const viewState = {
    projects: [],
    entries: []
  };

  function tr(key) {
    const lang = global.PBM_APP.getLang();
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function calcProjectMetrics(project, projectEntries) {
    const baseContract = Number(project.contractValue) || 0;
    let approvedExtra = 0;
    let totalCost = 0;
    let clientMaterialVal = 0;
    let latestProgress = 0;

    projectEntries.forEach(function (e) {
      if (e.entryType === "EXPENSE" || e.entryType === "CONTRACTOR_MATERIAL") {
        totalCost += Number(e.amount) || 0;
      } else if (e.entryType === "CLIENT_MATERIAL") {
        clientMaterialVal += Number(e.amount) || 0;
      } else if (e.entryType === "EXTRA_WORK" && e.status === "APPROVED") {
        approvedExtra += Number(e.amount) || 0;
      } else if (e.entryType === "PROGRESS") {
        latestProgress = Math.max(latestProgress, Number(e.progressPct) || 0);
      }
    });

    const totalRevenue = baseContract + approvedExtra;
    const netProfit = totalRevenue - totalCost;
    return {
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      totalCost: Math.round(totalCost * 100) / 100,
      netProfit: Math.round(netProfit * 100) / 100,
      clientMaterialVal: Math.round(clientMaterialVal * 100) / 100,
      latestProgress: latestProgress
    };
  }

  function getSummary(businessId) {
    return Promise.all([
      global.PBM_DB.getByBusiness("projects", businessId),
      global.PBM_DB.getByBusiness("projectEntries", businessId)
    ]).then(function (results) {
      const projects = results[0];
      const entries = results[1];
      let activeCount = 0;
      let totalContract = 0;
      let totalCost = 0;
      let totalProfit = 0;

      projects.forEach(function (p) {
        if (p.status === "ACTIVE") activeCount += 1;
        const pEntries = entries.filter(function (e) { return e.projectId === p.id; });
        const m = calcProjectMetrics(p, pEntries);
        totalContract += m.totalRevenue;
        totalCost += m.totalCost;
        totalProfit += m.netProfit;
      });

      return {
        activeCount: activeCount,
        totalContract: Math.round(totalContract * 100) / 100,
        totalCost: Math.round(totalCost * 100) / 100,
        totalProfit: Math.round(totalProfit * 100) / 100
      };
    });
  }

  function openProjectFormModal(existing) {
    const app = global.PBM_APP;
    const isEdit = Boolean(existing);
    const today = new Date().toISOString().slice(0, 10);
    const p = existing || {
      name: "",
      clientName: "",
      location: "",
      contractValue: 0,
      startDate: today,
      status: "ACTIVE"
    };

    const html = `
      <form id="prjForm" class="form-grid" novalidate>
        <div class="form-group">
          <label class="form-label" for="prjName">${tr("fieldName")}</label>
          <input id="prjName" class="form-input" type="text" required value="${app.escapeHtml(p.name)}" />
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="prjClient">${tr("fieldClient")}</label>
            <input id="prjClient" class="form-input" type="text" required value="${app.escapeHtml(p.clientName)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="prjValue">${tr("fieldValue")}</label>
            <input id="prjValue" class="form-input" type="number" min="0" step="0.01" value="${Number(p.contractValue) || 0}" required />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="prjStart">${tr("fieldStart")}</label>
            <input id="prjStart" class="form-input" type="date" value="${app.escapeHtml(p.startDate || today)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="prjStatus">${tr("fieldStatus")}</label>
            <select id="prjStatus" class="form-select">
              <option value="ACTIVE" ${p.status === "ACTIVE" ? "selected" : ""}>${tr("statusACTIVE")}</option>
              <option value="ON_HOLD" ${p.status === "ON_HOLD" ? "selected" : ""}>${tr("statusON_HOLD")}</option>
              <option value="COMPLETED" ${p.status === "COMPLETED" ? "selected" : ""}>${tr("statusCOMPLETED")}</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="prjLoc">${tr("fieldLocation")}</label>
          <input id="prjLoc" class="form-input" type="text" value="${app.escapeHtml(p.location || "")}" />
        </div>
        <div class="modal-actions">
          <button id="prjCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(isEdit ? tr("modalEditProject") : tr("modalAddProject"), html);
    document.getElementById("prjCancelBtn").addEventListener("click", app.closeModal);

    document.getElementById("prjForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("prjName").value.trim();
      const clientName = document.getElementById("prjClient").value.trim();
      if (name.length < 2 || clientName.length < 1) return;
      const now = new Date().toISOString();
      const businessId = app.getActiveBusinessId();
      global.PBM_DB.put("projects", {
        id: isEdit ? p.id : global.PBM_DB.generateId("prj"),
        businessId: businessId,
        name: name,
        clientName: clientName,
        contractValue: Math.max(0, parseFloat(document.getElementById("prjValue").value) || 0),
        startDate: document.getElementById("prjStart").value || today,
        status: document.getElementById("prjStatus").value,
        location: document.getElementById("prjLoc").value.trim(),
        createdAt: isEdit ? p.createdAt : now,
        updatedAt: now
      }).then(function () {
        app.closeModal();
        app.showToast(tr("toastSaved"), false);
        app.renderCurrentRoute();
      });
    });
  }

  function openProjectWorkspace(projectId, activeTab) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const tab = activeTab || "overview";

    Promise.all([
      global.PBM_DB.getOne("projects", projectId),
      global.PBM_DB.getByBusiness("projectEntries", businessId)
    ]).then(function (results) {
      const project = results[0];
      if (!project) return;
      const entries = results[1]
        .filter(function (e) { return e.projectId === projectId; })
        .sort(function (a, b) { return (b.date || "").localeCompare(a.date || ""); });
      const metrics = calcProjectMetrics(project, entries);
      const today = new Date().toISOString().slice(0, 10);

      let tabBody = "";
      if (tab === "overview") {
        tabBody = `
          <div class="ledger-list">
            <div class="ledger-row"><span>${tr("contractPlusExtra")}</span><strong class="tabular-nums">${app.formatCurrency(metrics.totalRevenue)}</strong></div>
            <div class="ledger-row"><span>${tr("totalExpensesLabel")}</span><strong class="tabular-nums text-payable">${app.formatCurrency(metrics.totalCost)}</strong></div>
            <div class="ledger-row"><span>${tr("entryTypeCLIENT_MATERIAL")}</span><strong class="tabular-nums">${app.formatCurrency(metrics.clientMaterialVal)}</strong></div>
            <div class="ledger-row"><strong>${tr("netProjectProfit")}</strong><strong class="tabular-nums ${metrics.netProfit >= 0 ? "text-receivable" : "text-payable"}">${app.formatCurrency(metrics.netProfit)}</strong></div>
          </div>
          <div class="btn-row" style="margin-top:12px;">
            <button id="prjPrintBtn" class="primary-btn" type="button">${tr("btnPrint")}</button>
          </div>
        `;
      } else {
        let defaultType = "EXPENSE";
        let filterFn = function (e) { return e.entryType === "EXPENSE"; };
        if (tab === "material") {
          defaultType = "CLIENT_MATERIAL";
          filterFn = function (e) { return e.entryType === "CLIENT_MATERIAL" || e.entryType === "CONTRACTOR_MATERIAL"; };
        } else if (tab === "progress") {
          defaultType = "PROGRESS";
          filterFn = function (e) { return e.entryType === "PROGRESS"; };
        } else if (tab === "extra") {
          defaultType = "EXTRA_WORK";
          filterFn = function (e) { return e.entryType === "EXTRA_WORK"; };
        }

        const filtered = entries.filter(filterFn);
        const listHtml = filtered.map(function (e) {
          return `
            <div class="ledger-row">
              <div class="ledger-row-main">
                <div class="ledger-row-title">${app.escapeHtml(e.title)}</div>
                <div class="list-item-meta">
                  ${app.escapeHtml(e.date)} · ${tr("entryType" + e.entryType)}
                  ${e.qty ? " · " + e.qty + " " + app.escapeHtml(e.unit || "") : ""}
                  ${e.entryType === "PROGRESS" ? " · " + (e.progressPct || 0) + "%" : ""}
                  ${e.entryType === "EXTRA_WORK" ? " · " + (e.status === "APPROVED" ? tr("approvedLabel") : tr("pendingLabel")) : ""}
                </div>
              </div>
              <div class="ledger-row-right">
                ${e.amount ? `<span class="tabular-nums">${app.formatCurrency(e.amount)}</span>` : ""}
                <div class="btn-row">
                  ${e.entryType === "EXTRA_WORK" && e.status !== "APPROVED" ? `<button class="secondary-btn" style="min-height:34px;padding:4px 8px;font-size:0.76rem;" type="button" data-pe-approve="${app.escapeHtml(e.id)}">${tr("approveBtn")}</button>` : ""}
                  <button class="mini-danger-btn" type="button" data-pe-del="${app.escapeHtml(e.id)}">${tr("btnDelete")}</button>
                </div>
              </div>
            </div>
          `;
        }).join("");

        tabBody = `
          <form id="prjEntryForm" class="form-grid" style="margin-bottom:14px;">
            ${
              tab === "material"
                ? `<select id="peType" class="form-select">
                     <option value="CLIENT_MATERIAL">${tr("entryTypeCLIENT_MATERIAL")}</option>
                     <option value="CONTRACTOR_MATERIAL">${tr("entryTypeCONTRACTOR_MATERIAL")}</option>
                   </select>`
                : `<input type="hidden" id="peType" value="${defaultType}" />`
            }
            <div class="form-row-2">
              <input id="peTitle" class="form-input" type="text" placeholder="Description / Work *" required />
              <input id="peDate" class="form-input" type="date" value="${today}" required />
            </div>
            <div class="form-row-2">
              ${
                tab === "progress"
                  ? `<input id="pePct" class="form-input" type="number" min="0" max="100" placeholder="Progress %" />
                     <input id="peQty" class="form-input" type="number" min="0" placeholder="Workers Count" />`
                  : `<input id="peAmt" class="form-input" type="number" min="0" step="0.01" placeholder="Amount (₹)" />
                     <input id="peQty" class="form-input" type="text" placeholder="Qty / Mode (optional)" />`
              }
            </div>
            <button class="primary-btn" type="submit">${tr("addEntryBtn")}</button>
          </form>
          <div class="ledger-list">${listHtml}</div>
        `;
      }

      const html = `
        <div class="ledger-summary-box" style="margin-bottom:12px;">
          <div>
            <div class="list-item-title">${app.escapeHtml(project.name)}</div>
            <div class="list-item-meta">${app.escapeHtml(project.clientName)} · ${metrics.latestProgress}%</div>
          </div>
          <div style="text-align:right;">
            <div class="list-item-meta">${tr("netProjectProfit")}</div>
            <strong class="tabular-nums ${metrics.netProfit >= 0 ? "text-receivable" : "text-payable"}">${app.formatCurrency(metrics.netProfit)}</strong>
          </div>
        </div>
        <div class="segmented-bar" style="margin:0 0 12px;">
          <button class="seg-btn ${tab === "overview" ? "active" : ""}" data-ws-tab="overview" type="button">${tr("wsTabOverview")}</button>
          <button class="seg-btn ${tab === "expense" ? "active" : ""}" data-ws-tab="expense" type="button">${tr("wsTabExpense")}</button>
          <button class="seg-btn ${tab === "material" ? "active" : ""}" data-ws-tab="material" type="button">${tr("wsTabMaterial")}</button>
          <button class="seg-btn ${tab === "progress" ? "active" : ""}" data-ws-tab="progress" type="button">${tr("wsTabProgress")}</button>
          <button class="seg-btn ${tab === "extra" ? "active" : ""}" data-ws-tab="extra" type="button">${tr("wsTabExtra")}</button>
        </div>
        ${tabBody}
      `;

      app.openModal(project.name, html);

      document.querySelectorAll("[data-ws-tab]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          openProjectWorkspace(projectId, btn.getAttribute("data-ws-tab"));
        });
      });

      const prjPrintBtn = document.getElementById("prjPrintBtn");
      if (prjPrintBtn) {
        prjPrintBtn.addEventListener("click", function () {
          const printHtml = `
            <div class="print-sheet">
              <h2>Project Cost &amp; Profit Report: ${app.escapeHtml(project.name)}</h2>
              <p>Client: ${app.escapeHtml(project.clientName)} · Location: ${app.escapeHtml(project.location || "-")}</p>
              <table class="print-table">
                <tr><td>Agreement + Approved Extra Work</td><td style="text-align:right;">${app.formatCurrency(metrics.totalRevenue)}</td></tr>
                <tr><td>Contractor Material &amp; Labour Cost</td><td style="text-align:right;">${app.formatCurrency(metrics.totalCost)}</td></tr>
                <tr><td>Client Supplied Material Value</td><td style="text-align:right;">${app.formatCurrency(metrics.clientMaterialVal)}</td></tr>
                <tr><td><strong>Net Project Profit</strong></td><td style="text-align:right;"><strong>${app.formatCurrency(metrics.netProfit)}</strong></td></tr>
              </table>
            </div>
          `;
          global.PBM_PRINT.printHtmlDocument(printHtml);
        });
      }

      const peForm = document.getElementById("prjEntryForm");
      if (peForm) {
        peForm.addEventListener("submit", function (e) {
          e.preventDefault();
          const title = document.getElementById("peTitle").value.trim();
          if (!title) return;
          const entryType = document.getElementById("peType").value;
          const now = new Date().toISOString();
          global.PBM_DB.put("projectEntries", {
            id: global.PBM_DB.generateId("pe"),
            businessId: businessId,
            projectId: projectId,
            entryType: entryType,
            title: title,
            date: document.getElementById("peDate").value || today,
            amount: document.getElementById("peAmt") ? parseFloat(document.getElementById("peAmt").value) || 0 : 0,
            qty: document.getElementById("peQty") ? document.getElementById("peQty").value.trim() : "",
            progressPct: document.getElementById("pePct") ? parseFloat(document.getElementById("pePct").value) || 0 : 0,
            status: entryType === "EXTRA_WORK" ? "PENDING" : "RECORDED",
            createdAt: now,
            updatedAt: now
          }).then(function () {
            openProjectWorkspace(projectId, tab);
            app.renderCurrentRoute();
          });
        });
      }

      document.querySelectorAll("[data-pe-approve]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const peId = btn.getAttribute("data-pe-approve");
          global.PBM_DB.getOne("projectEntries", peId).then(function (rec) {
            if (!rec) return;
            rec.status = "APPROVED";
            rec.updatedAt = new Date().toISOString();
            global.PBM_DB.put("projectEntries", rec).then(function () {
              openProjectWorkspace(projectId, tab);
              app.renderCurrentRoute();
            });
          });
        });
      });

      document.querySelectorAll("[data-pe-del]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          global.PBM_DB.remove("projectEntries", btn.getAttribute("data-pe-del")).then(function () {
            openProjectWorkspace(projectId, tab);
            app.renderCurrentRoute();
          });
        });
      });
    });
  }

  function render(viewContainer, contextStripHtml) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    return Promise.all([
      global.PBM_DB.getByBusiness("projects", businessId),
      global.PBM_DB.getByBusiness("projectEntries", businessId),
      getSummary(businessId)
    ]).then(function (results) {
      viewState.projects = results[0].sort(function (a, b) {
        return (b.createdAt || "").localeCompare(a.createdAt || "");
      });
      viewState.entries = results[1];
      const summary = results[2];

      const listHtml =
        viewState.projects.length === 0
          ? `<div class="card"><h3 class="card-title">${tr("emptyTitle")}</h3><p class="card-subtitle">${tr("emptyDesc")}</p></div>`
          : viewState.projects
              .map(function (p) {
                const pEntries = viewState.entries.filter(function (e) { return e.projectId === p.id; });
                const m = calcProjectMetrics(p, pEntries);
                return `
                  <div class="list-item-card">
                    <div class="list-item-top">
                      <div>
                        <h3 class="list-item-title">${app.escapeHtml(p.name)}</h3>
                        <div class="list-item-meta">${app.escapeHtml(p.clientName)} · ${tr("status" + p.status)} · ${m.latestProgress}%</div>
                        <div class="list-item-meta">${tr("kpiContract")}: ${app.formatCurrency(m.totalRevenue)} · ${tr("kpiCost")}: ${app.formatCurrency(m.totalCost)}</div>
                      </div>
                      <div style="text-align:right;">
                        <div class="kpi-value tabular-nums ${m.netProfit >= 0 ? "text-receivable" : "text-payable"}" style="font-size:1.05rem;">${app.formatCurrency(m.netProfit)}</div>
                        <div class="list-item-meta">${tr("netProjectProfit")}</div>
                      </div>
                    </div>
                    <div class="btn-row">
                      <button class="primary-btn" type="button" data-prj-open="${app.escapeHtml(p.id)}">${tr("btnWorkspace")}</button>
                      <button class="secondary-btn" type="button" data-prj-edit="${app.escapeHtml(p.id)}">${tr("btnEdit")}</button>
                      <button class="danger-btn" type="button" data-prj-del="${app.escapeHtml(p.id)}">${tr("btnDelete")}</button>
                    </div>
                  </div>
                `;
              })
              .join("");

      viewContainer.innerHTML = `
        ${contextStripHtml}
        <div class="kpi-grid">
          <div class="kpi-card"><div class="kpi-label">${tr("kpiActive")}</div><div class="kpi-value tabular-nums">${summary.activeCount}</div></div>
          <div class="kpi-card"><div class="kpi-label">${tr("kpiContract")}</div><div class="kpi-value tabular-nums">${app.formatCurrency(summary.totalContract)}</div></div>
          <div class="kpi-card"><div class="kpi-label">${tr("kpiCost")}</div><div class="kpi-value tabular-nums text-payable">${app.formatCurrency(summary.totalCost)}</div></div>
          <div class="kpi-card"><div class="kpi-label">${tr("kpiProfit")}</div><div class="kpi-value tabular-nums ${summary.totalProfit >= 0 ? "text-receivable" : "text-payable"}">${app.formatCurrency(summary.totalProfit)}</div></div>
        </div>
        <div class="card">
          <div class="card-header-row" style="margin-bottom:0;">
            <h2 class="card-title">${app.t("navProjects")}</h2>
            <button id="addProjectBtn" class="primary-btn" type="button">${tr("newProjectBtn")}</button>
          </div>
        </div>
        <div class="list-stack">${listHtml}</div>
      `;

      document.getElementById("addProjectBtn").addEventListener("click", function () {
        openProjectFormModal(null);
      });
      viewContainer.querySelectorAll("[data-prj-open]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          openProjectWorkspace(btn.getAttribute("data-prj-open"), "overview");
        });
      });
      viewContainer.querySelectorAll("[data-prj-edit]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const found = viewState.projects.find(function (p) { return p.id === btn.getAttribute("data-prj-edit"); });
          if (found) openProjectFormModal(found);
        });
      });
      viewContainer.querySelectorAll("[data-prj-del]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const id = btn.getAttribute("data-prj-del");
          app.confirmDialog({
            title: tr("confirmDelTitle"),
            message: tr("confirmDelMsg"),
            confirmText: tr("deleteBtn"),
            isDanger: true
          }).then(function (ok) {
            if (!ok) return;
            const dels = viewState.entries
              .filter(function (e) { return e.projectId === id; })
              .map(function (e) { return global.PBM_DB.remove("projectEntries", e.id); });
            Promise.all(dels).then(function () {
              return global.PBM_DB.remove("projects", id);
            }).then(function () {
              app.showToast(tr("toastDeleted"), false);
              app.renderCurrentRoute();
            });
          });
        });
      });
    });
  }

  global.PBM_PROJECTS = {
    render: render,
    getSummary: getSummary
  };
})(window);
