// =======================================
// NetEarn Pro
// Register System V4 - FINAL SAFE
// Firebase Auth + Firestore + Referral
// =======================================

import { auth, db } from "./firebase.js";

import {
    createUserWithEmailAndPassword,
    deleteUser,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    getDoc,
    collection,
    serverTimestamp,
    writeBatch,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// PASSWORD SHOW / HIDE
// =======================================

const passwordInput =
    document.getElementById("password");

const togglePassword =
    document.getElementById("togglePassword");

const confirmPasswordInput =
    document.getElementById("confirmPassword");

const toggleConfirmPassword =
    document.getElementById("toggleConfirmPassword");


togglePassword?.addEventListener(
    "click",
    () => {

        if (
            passwordInput &&
            passwordInput.type === "password"
        ) {

            passwordInput.type = "text";

            togglePassword.textContent =
                "🙈";

        } else if (passwordInput) {

            passwordInput.type =
                "password";

            togglePassword.textContent =
                "👁️";

        }

    }
);


toggleConfirmPassword?.addEventListener(
    "click",
    () => {

        if (
            confirmPasswordInput &&
            confirmPasswordInput.type === "password"
        ) {

            confirmPasswordInput.type =
                "text";

            toggleConfirmPassword.textContent =
                "🙈";

        } else if (confirmPasswordInput) {

            confirmPasswordInput.type =
                "password";

            toggleConfirmPassword.textContent =
                "👁️";

        }

    }
);


// =======================================
// REGISTER BUTTON
// =======================================

const registerBtn =
    document.getElementById("registerBtn");


if (registerBtn) {

    registerBtn.addEventListener(
        "click",
        async () => {

            // =======================================
            // GET FORM VALUES
            // =======================================

            const name =
                document.getElementById("name")
                    ?.value
                    ?.trim() || "";


            const username =
                document.getElementById("username")
                    ?.value
                    ?.trim() || "";


            const email =
                document.getElementById("email")
                    ?.value
                    ?.trim()
                    ?.toLowerCase() || "";


            const phone =
                document.getElementById("phone")
                    ?.value
                    ?.trim() || "";


            const password =
                document.getElementById("password")
                    ?.value || "";


            const confirmPassword =
                document.getElementById("confirmPassword")
                    ?.value || "";


            const referral =
                document.getElementById("referral")
                    ?.value
                    ?.trim()
                    ?.toUpperCase() || "";


            const terms =
                document.getElementById("terms")
                    ?.checked || false;


            // =======================================
            // VALIDATION
            // =======================================

            if (
                !name ||
                !username ||
                !email ||
                !phone ||
                !password ||
                !confirmPassword
            ) {

                alert(
                    "সব তথ্য পূরণ করুন।"
                );

                return;
            }


            if (password !== confirmPassword) {

                alert(
                    "Password মিল নেই।"
                );

                return;
            }


            if (!terms) {

                alert(
                    "Terms & Conditions Accept করুন।"
                );

                return;
            }


            if (password.length < 6) {

                alert(
                    "Password কমপক্ষে ৬ অক্ষরের হতে হবে।"
                );

                return;
            }


            // =======================================
            // DISABLE BUTTON
            // =======================================

            registerBtn.disabled = true;


            const oldButtonText =
                registerBtn.innerText;


            registerBtn.innerText =
                "⏳ Creating Account...";


            let createdAuthUser = null;


            try {

                // =======================================
                // CREATE FIREBASE AUTH ACCOUNT
                //
                // Referral validation needs a signed-in
                // user because current Firestore Rules
                // allow referralCodes read only when
                // signedIn().
                // =======================================

                const result =
                    await createUserWithEmailAndPassword(
                        auth,
                        email,
                        password
                    );


                const user =
                    result.user;


                createdAuthUser =
                    user;


                const uid =
                    user.uid;


                // =======================================
                // CREATE NEP USER ID
                // =======================================

                const nepId =
                    "NEP" +
                    Math.floor(
                        100000 +
                        Math.random() * 900000
                    );


                // =======================================
                // FIND / VALIDATE REFERRER
                // =======================================

                let referrerUid =
                    "";

                let referrerUserId =
                    "";


                if (referral) {

                    const referralRef =
                        doc(
                            db,
                            "referralCodes",
                            referral
                        );


                    const referralSnap =
                        await getDoc(
                            referralRef
                        );


                    // -----------------------------------
                    // INVALID REFERRAL CODE
                    // -----------------------------------

                    if (!referralSnap.exists()) {

                        throw new Error(
                            "INVALID_REFERRAL_CODE"
                        );

                    }


                    const referralData =
                        referralSnap.data();


                    const possibleUid =
                        referralData?.uid || "";


                    const possibleUserId =
                        referralData?.userId || "";


                    // -----------------------------------
                    // SAFETY CHECK
                    // -----------------------------------

                    if (!possibleUid) {

                        throw new Error(
                            "INVALID_REFERRAL_OWNER"
                        );

                    }


                    // -----------------------------------
                    // PREVENT SELF REFERRAL
                    // -----------------------------------

                    if (
                        possibleUid === uid
                    ) {

                        throw new Error(
                            "SELF_REFERRAL"
                        );

                    }


                    // -----------------------------------
                    // VALID REFERRER
                    // -----------------------------------

                    referrerUid =
                        possibleUid;


                    referrerUserId =
                        possibleUserId;

                }


                // =======================================
                // CREATE UNIQUE REFERRAL CODE
                //
                // IMPORTANT:
                // referralCodes rules allow CREATE only.
                //
                // We therefore never UPDATE an existing
                // referral code.
                //
                // Firestore batch commit is atomic.
                // If candidate already exists, the whole
                // batch fails and another candidate is tried.
                // =======================================

                let registrationCompleted =
                    false;


                let lastCodeError =
                    null;


                for (
                    let attempt = 0;
                    attempt < 10;
                    attempt++
                ) {

                    const candidate =
                        "NET" +
                        Math.floor(
                            100000 +
                            Math.random() * 900000
                        );


                    const codeRef =
                        doc(
                            db,
                            "referralCodes",
                            candidate
                        );


                    // -----------------------------------
                    // Check existing code
                    // -----------------------------------

                    const codeSnap =
                        await getDoc(
                            codeRef
                        );


                    if (codeSnap.exists()) {

                        continue;

                    }


                    // ===================================
                    // USER DOCUMENT
                    // ===================================

                    const userRef =
                        doc(
                            db,
                            "users",
                            uid
                        );


                    // ===================================
                    // REFERRAL CODE DOCUMENT
                    // ===================================

                    const myCodeRef =
                        doc(
                            db,
                            "referralCodes",
                            candidate
                        );


                    // ===================================
                    // NEW REFERRAL RECORD ID
                    // ===================================

                    let referralRecordRef =
                        null;


                    if (referrerUid) {

                        referralRecordRef =
                            doc(
                                collection(
                                    db,
                                    "referrals"
                                )
                            );

                    }


                    // ===================================
                    // NEW NOTIFICATION ID
                    // ===================================

                    const notificationRef =
                        doc(
                            collection(
                                db,
                                "notifications"
                            )
                        );


                    // ===================================
                    // CREATE BATCH
                    // ===================================

                    const batch =
                        writeBatch(db);


                    // ===================================
                    // USER DOCUMENT
                    // ===================================

                    batch.set(
                        userRef,
                        {

                            // -----------------------------
                            // BASIC USER DATA
                            // -----------------------------

                            uid:
                                uid,

                            userId:
                                nepId,

                            username:
                                username,

                            name:
                                name,

                            email:
                                email,

                            phone:
                                phone,


                            // -----------------------------
                            // REFERRAL
                            // -----------------------------

                            referralCode:
                                candidate,

                            referrerCode:
                                referral || "",

                            referredBy:
                                referral || "",

                            referrerUid:
                                referrerUid || "",


                            // -----------------------------
                            // WALLET
                            // -----------------------------

                            balance:
                                0,

                            totalEarnings:
                                0,

                            totalReferrals:
                                0,

                            referralCommission:
                                0,


                            // -----------------------------
                            // TASK CREDIT SYSTEM
                            // -----------------------------

                            taskChance:
                                0,

                            selectedTask:
                                "",


                            // -----------------------------
                            // TASK UNLOCK
                            // -----------------------------

                            typingUnlocked:
                                false,

                            editingUnlocked:
                                false,

                            formfillUnlocked:
                                false,

                            microjobUnlocked:
                                false,


                            // -----------------------------
                            // TASK SETTINGS
                            // -----------------------------

                            typingEnabled:
                                false,

                            photoEditingEnabled:
                                false,

                            formFillingEnabled:
                                false,


                            // -----------------------------
                            // PREMIUM / VERIFICATION
                            // -----------------------------

                            premium:
                                false,

                            verified:
                                false,

                            verificationPaid:
                                false,

                            verificationRequested:
                                false,

                            verificationStatus:
                                "not_verified",

                            plan:
                                "free",


                            // -----------------------------
                            // WITHDRAW
                            // -----------------------------

                            withdrawEnabled:
                                false,


                            // -----------------------------
                            // ACCOUNT STATUS
                            // -----------------------------

                            status:
                                "active",

                            blocked:
                                false,

                            role:
                                "user",


                            // -----------------------------
                            // DATE
                            // -----------------------------

                            createdAt:
                                serverTimestamp()

                        }
                    );


                    // ===================================
                    // REFERRAL CODE MAPPING
                    // ===================================

                    batch.set(
                        myCodeRef,
                        {

                            referralCode:
                                candidate,

                            uid:
                                uid,

                            userId:
                                nepId,

                            username:
                                username,

                            createdAt:
                                serverTimestamp()

                        }
                    );


                    // ===================================
                    // REFERRAL RECORD
                    // ===================================

                    if (
                        referrerUid &&
                        referralRecordRef
                    ) {

                        batch.set(
                            referralRecordRef,
                            {

                                referrerUid:
                                    referrerUid,

                                referredUserUid:
                                    uid,

                                referredUserId:
                                    nepId,

                                referredUsername:
                                    username,

                                referralCode:
                                    referral,

                                status:
                                    "active",

                                createdAt:
                                    serverTimestamp()

                            }
                        );

                    }


                    // ===================================
                    // REGISTRATION NOTIFICATION
                    // ===================================

                    batch.set(
                        notificationRef,
                        {

                            uid:
                                uid,

                            userId:
                                uid,

                            userUid:
                                uid,


                            title:
                                "Registration Complete 🎉",


                            message:
                                "Welcome to NetEarn Pro",


                            type:
                                "registration",


                            read:
                                false,


                            createdAt:
                                serverTimestamp()

                        }
                    );


                    // ===================================
                    // COMMIT EVERYTHING TOGETHER
                    // ===================================

                    try {

                        await batch.commit();


                        registrationCompleted =
                            true;

                        break;

                    }

                    catch (batchError) {

                        lastCodeError =
                            batchError;


                        /*
                         * If the referral code was created
                         * by another user between getDoc()
                         * and commit(), Firestore create
                         * permission will fail.
                         *
                         * Because this is a batch, NONE of
                         * the registration documents are
                         * written.
                         *
                         * Try another referral code.
                         */

                        if (
                            batchError.code ===
                            "permission-denied"
                        ) {

                            continue;

                        }


                        throw batchError;

                    }

                }


                // =======================================
                // FINAL REGISTRATION CHECK
                // =======================================

                if (!registrationCompleted) {

                    console.error(
                        "Referral Code Creation Error:",
                        lastCodeError
                    );


                    throw new Error(
                        "REFERRAL_CODE_CREATE_FAILED"
                    );

                }


                // =======================================
                // SUCCESS
                // =======================================

                await alert(
                    "✅ Account Created Successfully"
                );


                // =======================================
                // REDIRECT
                // =======================================

                window.location.href =
                    "login.html";

            }


            catch (error) {

                console.error(
                    "❌ Registration Error:",
                    error
                );


                // =======================================
                // CLEANUP AUTH ACCOUNT
                //
                // If registration fails after Auth
                // account creation, remove that newly
                // created account.
                // =======================================

                if (createdAuthUser) {

                    try {

                        await deleteUser(
                            createdAuthUser
                        );

                    }

                    catch (cleanupError) {

                        console.error(
                            "❌ Auth Cleanup Error:",
                            cleanupError
                        );

                    }

                }


                // =======================================
                // FRIENDLY ERROR MESSAGE
                // =======================================

                if (
                    error.code ===
                    "auth/email-already-in-use"
                ) {

                    alert(
                        "❌ এই Email দিয়ে ইতিমধ্যে Account আছে।"
                    );

                }

                else if (
                    error.code ===
                    "auth/invalid-email"
                ) {

                    alert(
                        "❌ Email Address সঠিক নয়।"
                    );

                }

                else if (
                    error.code ===
                    "auth/weak-password"
                ) {

                    alert(
                        "❌ Password দুর্বল। কমপক্ষে ৬ অক্ষর দিন।"
                    );

                }

                else if (
                    error.code ===
                    "auth/network-request-failed"
                ) {

                    alert(
                        "❌ Network connection সমস্যা হয়েছে।"
                    );

                }

                else if (
                    error.message ===
                    "INVALID_REFERRAL_CODE"
                ) {

                    alert(
    "⚠️ Referral Code খুঁজে পাওয়া যায়নি।\n\nদয়া করে সঠিক Referral Code ব্যবহার করুন।\nReferral Code না থাকলে ঘরটি খালি রেখে Account তৈরি করুন।"
);
                }

                else if (
                    error.message ===
                    "INVALID_REFERRAL_OWNER"
                ) {

                    alert(
                        "❌ এই Referral Code-এর Owner তথ্য পাওয়া যায়নি। অন্য একটি valid Referral Code ব্যবহার করুন।"
                    );

                }

                else if (
                    error.message ===
                    "SELF_REFERRAL"
                ) {

                    alert(
                        "❌ নিজের Referral Code ব্যবহার করা যাবে না।"
                    );

                }

                else if (
                    error.message ===
                    "REFERRAL_CODE_CREATE_FAILED"
                ) {

                    alert(
                        "❌ আপনার Referral Code তৈরি করা যায়নি। আবার চেষ্টা করুন।"
                    );

                }

                else if (
                    error.code ===
                    "permission-denied"
                ) {

                    alert(
                        "❌ Firestore Permission Error। Firestore Rules publish হয়েছে কিনা check করুন।"
                    );

                }

                else {

                    alert(
                        "❌ Account Create করতে সমস্যা হয়েছে:\n\n" +
                        (
                            error.message ||
                            "Unknown Error"
                        )
                    );

                }

            }


            finally {

                registerBtn.disabled =
                    false;

                registerBtn.innerText =
                    oldButtonText;

            }

        }
    );

}


else {

    console.log(
        "⚠️ Register Button Not Found"
    );

}