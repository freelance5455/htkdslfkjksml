/* Firebase Realtime Database config. Fill it with YOUR project values (see README).
   Leave databaseURL empty to run without cloud features (everything is then saved on the device only). */
window.FIREBASE_CONFIG={
  databaseURL:'',root:'g29cfd1206f5620d0280feb8f0f7d5e987ae8a890',relay:'https://ntfy.sh'   // e.g. 'https://YOUR-PROJECT-default-rtdb.firebaseio.com'
  // auth:''       // optional database secret / token if your rules require it
};
