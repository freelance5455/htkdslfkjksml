/* تب امروز: خلاصه، پیگیری، ثبت سریع، کلاس‌ها، برنامه‌ی امروز، مرور، کارها، گزارش پایان روز، تحلیل، ورودی آزاد، ثبت کامل. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var pl = App.plan;
  var ch = App.chart;
  var S = function () { return App.S; };

  App.views.today = function () {
    var A = App, today = u.todayISO(), ds = st.dayStat(today);
    var goal = S().goal || D.DEFAULT_GOAL;
    var pct = goal ? ds.s / goal * 100 : 0;
    var h = App.remind.banner() + App.upgradeNotice() + App.storageNotice() + restoreCard();
    var nowStudy = u.hm(ds.s);
    h += App.card(null,
      '<div class="today-top"><div><div class="mu">مطالعه امروز (جدا از کلاس)</div><div class="big" aria-live="polite">' + nowStudy + ' <span class="mu">ساعت</span></div>' +
      '<div class="mu">' + u.fa(ds.t) + ' تست · ' + u.hours(ds.c) + ' کلاس</div></div>' + ch.ring(pct, 'از هدف روزانه') + '</div>' +
      '<div class="row0 wrap"><span class="streak" title="روزهای پشت‌سرهم با مطالعه">🔥 ' + u.fa(st.streak()) + ' روز پشت‌سرهم</span>' +
      '<label class="inline-lbl" for="goal-in">هدف روزانه (دقیقه)</label><input id="goal-in" class="mini" type="text" inputmode="numeric" value="' + u.esc(u.pd(goal)) + '" data-f="goalf.v" data-t="int"><button type="button" class="sm" data-act="goal-save">ذخیره</button></div>', { key: 'today|summary', open: true, cls: 'hero-card' });

    h += quickCard();
    h += App.remind.dailyCard();
    h += A.card('🔔 پیگیری مشاور', st.followUps().map(function (x) { return '<div class="line">• ' + u.esc(x) + '</div>'; }).join(''), { open: true, icon: '' });
    h += classCard();
    h += planCard();
    h += reviewCard();
    h += todoCard();
    h += ciCard();
    h += A.card('🧠 تحلیل هوشمند', st.insights().slice(0, 6).map(function (x) { return '<div class="line">' + u.esc(x) + '</div>'; }).join('') +
      '<div class="q-row"><button type="button" class="sm" data-act="ai-ask" data-q="analysis" data-tab="today">🤖 تحلیل کامل با مشاور</button></div>', { open: false });
    h += voiceCard();
    h += shortcutCard();
    h += bkWarn();
    h += logFormCard();
    h += A.card('📒 تاریخچه‌ی امروز', historyList(today), { open: true });
    h += aiQuick();
    return h;
  };

  function restoreCard() {
    var S0 = S();
    if (S0.rs || S0.logs.length + S0.exams.length + S0.jr.length > 0) return '';
    return App.card('📥 نسخه‌ی قبلی داری؟', '<p class="mu">اگر از نسخه‌ی قبلی پشتیبان داری، فایلش را بارگذاری کن تا همه‌چیز برگردد.</p>' +
      '<div class="q-row"><button type="button" class="btn" data-act="open-import">📂 بارگذاری یا چسباندن پشتیبان</button><button type="button" class="sm" data-act="fresh-user">کاربر جدیدم</button></div>', { cls: 'notice', open: true });
  }
  App.act['fresh-user'] = function () { App.S.rs = 1; App.save(); App.render(); };
  App.act['goal-save'] = function () {
    var v = u.int(App.form('goalf', {}).v, 10, 1440, null);
    if (v == null) { App.alert('هدف را به دقیقه بین ۱۰ تا ۱۴۴۰ وارد کن'); return; }
    App.S.goal = v; App.save(); App.render(); App.toast('هدف روزانه: ' + u.fa(v) + ' دقیقه');
  };

  // ---- ثبت سریع ----
  function quickCard() {
    var f = App.form('quick', { g: S().mg || 12, s: '', c: 0, t: '', ok: '' });
    var n = App.normSubject('quick', 'g', 's');
    var cls = [];
    return App.card('⚡ ثبت سریع', '<div class="grid2">' +
      App.field('پایه', App.select('quick', 'g', App.gradeOpts(), { rr: true })) +
      App.field('درس', App.subjSelect('quick', 'g', 's')) + '</div>' +
      App.field('فصل', App.chapSelect('quick', 'g', 's', 'c')) +
      '<div class="mu">📖 مطالعه (دقیقه) — جدا از کلاس حساب می‌شود</div><div class="chips-row">' +
      [15, 30, 45, 60, 90].map(function (m) { return App.sm('+' + u.fa(m), 'quick-min', { v: m, k: 's' }); }).join('') + '</div>' +
      '<div class="mu">🏫 کلاس (دقیقه)</div><div class="chips-row">' +
      [45, 60, 90, 120].map(function (m) { return App.sm('+' + u.fa(m), 'quick-min', { v: m, k: 'c' }); }).join('') + '</div>' +
      '<div class="grid2 mt">' + App.field('تعداد تست', App.input('quick', 't', { t: 'int', inputmode: 'numeric', ph: '۰' })) +
      App.field('از آنها درست', App.input('quick', 'ok', { t: 'int', inputmode: 'numeric', ph: 'اختیاری' })) + '</div>' +
      App.btn('ثبت تست', 'quick-test', {}, 'mt'), { key: 'today|⚡ ثبت سریع', open: true, cls: 'quick-primary' });
  }
  App.act['quick-min'] = function (el) {
    var f = App.form('quick', {}), m = +el.getAttribute('data-v'), k = el.getAttribute('data-k');
    var rec = st.addLog({ g: +f.g || S().mg, s: f.s, c: +f.c || 0, m: m, t: 0, k: k === 'c' ? 'c' : undefined, d: u.todayISO() });
    if (!rec) { App.alert('ثبت انجام نشد'); return; }
    App.save(); App.toast('✅ ' + u.fa(m) + ' دقیقه ' + (k === 'c' ? 'کلاس' : 'مطالعه') + ' ثبت شد', { action: { label: '↩️ برگردان', fn: function () { st.delLog(rec.id); App.save(); App.render(); } } });
    App.render();
  };
  App.act['quick-test'] = function () {
    var f = App.form('quick', {});
    var t = u.int(f.t, 1, 5000, 0);
    if (!t) { App.alert('تعداد تست را وارد کن'); return; }
    var ok = f.ok === '' || f.ok == null ? undefined : u.int(f.ok, 0, t, 0);
    if (f.ok !== '' && f.ok != null && ok === undefined) { App.alert('تعداد درست نباید بیشتر از کل تست‌ها باشد'); return; }
    var rec = st.addLog({ g: +f.g || S().mg, s: f.s, c: +f.c || 0, m: 0, t: t, ok: ok, d: u.todayISO() });
    if (!rec) return;
    App.save();
    App.toast('✅ ' + u.fa(t) + ' تست ثبت شد' + (ok != null ? ' · ' + u.fa(ok) + ' درست' : ''), { action: { label: '↩️ برگردان', fn: function () { st.delLog(rec.id); App.save(); App.render(); } } });
    App.form('quick', {}).t = ''; App.form('quick', {}).ok = '';
    App.render();
  };

  // ---- کلاس‌های امروز ----
  function classCard() {
    var C = pl.classesToday();
    if (!C.length) return '';
    var Dd = (S().cl || {})[u.todayISO()] || {};
    return App.card('🏫 کلاس‌های امروز', '<p class="mu">کلاسی که دیدی تیک بزن؛ به زمان مطالعه‌ی کلاس می‌رود. کلاسی که تیک نخورد، بعد از پایانش خودکار به «دیدن کلاس» در کارهای جبران می‌رود.</p>' +
      C.map(function (b, i) {
        var s0 = Dd[pl.clsKey(b)];
        return '<div class="li"><label class="check' + (s0 === 2 ? ' muted' : '') + '"><input type="checkbox" data-act="class-tick" data-i="' + i + '"' + (s0 === 1 ? ' checked' : '') + '><span>' + u.hm(b.s) + ' تا ' + u.hm(b.e) + ' — ' + u.esc(b.t) + (s0 === 2 ? ' <span class="mu">(ندیدم، به جبران رفت)</span>' : '') + '</span></label>' +
          (s0 !== 1 && s0 !== 2 ? App.sm('ندیدم', 'class-miss', { i: i }) : '') + '</div>';
      }).join(''), { open: true });
  }
  App.act['class-tick'] = function (el) {
    var i = +el.getAttribute('data-i');
    pl.classTick(i);
    App.save();
    App.render();
  };
  App.act['class-miss'] = function (el) {
    pl.classMiss(+el.getAttribute('data-i'));
    App.save(); App.render();
  };

  // ---- برنامه‌ی امروز ----
  function planCard() {
    var W = pl.todayWP(), hasStudy = W.some(function (x) { return x.k === 'study'; });
    var body = '';
    if (hasStudy) {
      var Dd = (S().wd || {})[u.todayISO()] || {};
      var a = pl.adh(u.todayISO());
      body += (a ? '<div class="mu">پایبندی امروز: ' + u.fa(a.n) + ' از ' + u.fa(a.t) + ' بلوک مطالعه (' + u.fa(a.p) + '٪)</div>' : '');
      body += W.map(function (x, i) {
        var dn = Dd[pl.bkey(x)] === 1, mv = Dd[pl.bkey(x)] === 2;
        return '<label class="check' + (dn || mv ? ' done' : '') + '"><input type="checkbox" data-act="wd-tick" data-i="' + i + '"' + (dn ? ' checked' : '') + (x.k === 'study' ? '' : ' disabled') + '><span>' + u.hm(u.tmin(x.s0)) + ' تا ' + u.hm(u.tmin(x.e0)) + ' — ' + u.esc(x.t) + (mv ? ' (منتقل شد)' : '') + '</span></label>';
      }).join('');
      var miss = pl.missedToday().length;
      if (miss) body += '<div class="q-row"><button type="button" class="sm" data-act="move-missed">📌 انتقال ' + u.fa(miss) + ' بلوک مانده به لیست جبران</button></div>';
    } else {
      body += '<pre class="plan-text">' + u.esc(pl.planAuto()) + '</pre><div class="mu">از همین الان تا ساعت خواب، دور کارهای ثابتت چیده شده است.</div>';
    }
    var aiTxt = S().plan && S().plan.d === u.todayISO() ? '<div class="plan-ai"><b>🤖 برنامه‌ی مشاور</b><pre class="plan-text">' + u.esc(S().plan.t) + '</pre></div>' : '';
    body += '<div class="q-row"><button type="button" class="sm" data-act="copy-plan">📋 کپی</button><button type="button" class="sm" data-act="ai-ask" data-q="plan" data-tab="today">🤖 برنامه‌ی دقیق‌تر از مشاور</button></div>' + aiTxt;
    return App.card('📅 برنامه‌ی ساعتی امروز', body, { open: true });
  }
  App.act['wd-tick'] = function (el) {
    var W = pl.todayWP(), x = W[+el.getAttribute('data-i')];
    if (!x) return;
    pl.wdTick(x); App.save(); App.render();
  };
  App.act['move-missed'] = function () {
    var n = pl.moveMissed(); App.save(); App.render();
    App.toast('📌 ' + u.fa(n) + ' بلوک به لیست جبران رفت');
  };
  App.act['copy-plan'] = function () {
    var t = pl.todayWP().some(function (x) { return x.k === 'study'; }) ? pl.wpText() : pl.planAuto();
    u.copyText(t).then(function (ok) { App.toast(ok ? 'کپی شد ✅' : 'کپی انجام نشد'); });
  };

  // ---- مرور فاصله‌دار ----
  function reviewCard() {
    var R = st.revDue();
    if (!R.length) return '';
    return App.card('🔁 مرور امروز (فاصله‌دار)', '<p class="mu">فصل‌هایی که ۱، ۳، ۷ یا ۱۴ روز پیش خوندی. مرورشون باعث می‌شه بمونه.</p>' + R.map(function (x) {
      return '<div class="li"><span>' + u.esc(x.s) + ' — ' + u.esc(st.chName(x.g, x.s, x.c)) + '<br><span class="mu">مرور ' + u.fa(x.n) + ' روز بعد</span></span>' + App.sm('✅ مرور شد', 'rev-done', { key: x.k }) + '</div>';
    }).join(''), { open: true });
  }
  App.act['rev-done'] = function (el) { st.revDone(el.getAttribute('data-key')); App.save(); App.render(); };

  // ---- کارهای امروز ----
  // کارهای بدون سررسید؛ پیگیری‌ها در «📌 برنامه‌ی امروز»
  function todoCard() {
    var t = u.todayISO(), T = st.todosOn(t).filter(function (x) { return !x.due; });
    var f = App.form('todo', { txt: '', hd: 0, ht: 0 });
    var later = S().todos.filter(function (x) { return x.due && x.due > t && !x.o; }).length;
    return App.card('✅ کارهای امروز', T.map(function (x) {
      return '<div class="li"><label class="check' + (x.o ? ' done' : '') + '"><input type="checkbox" data-act="todo-toggle" data-key="' + x.id + '"' + (x.o ? ' checked' : '') + '><span>' + u.esc(x.t) + '</span></label>' + App.sm('✕', 'todo-del', { key: x.id }) + '</div>';
    }).join('') + (T.length ? '' : '<p class="mu empty">هنوز کاری برای امروز نداری. یک کار کوچک بنویس، مثلاً «۱۰ تست گسسته».</p>') +
      (later ? '<p class="mu">🔜 ' + u.fa(later) + ' پیگیری برای روزهای بعد ثبت شده است.</p>' : '') +
      '<div class="row0 mt"><input id="todo-in" placeholder="مثلاً ۱۰ تست گسسته" data-f="todo.txt" value="' + u.esc(f.txt) + '" maxlength="200" aria-label="کار جدید"></div>' +
      App.check('todo', 'hd', '⏰ پیگیری با تاریخ و ساعت (یادآوری)', { rr: true }) +
      (f.hd ? App.field('تاریخ پیگیری', App.dateField('todo', 'due', { label: 'تاریخ پیگیری' })) + App.check('todo', 'ht', '🕒 ساعت یادآوری هم مشخص شود', { rr: true }) + (f.ht ? App.field('ساعت یادآوری', App.timeField('todo', 'at', { def: '18:00', label: 'ساعت یادآوری' })) : '') : '') +
      '<div class="q-row"><button type="button" class="sm" data-act="todo-add">+ افزودن</button></div>', { open: true });
  }
  App.act['todo-add'] = function () {
    var f = App.form('todo', {});
    var due = f.hd && u.isISO(f.due) ? f.due : '';
    var o = st.addTodo(f.txt, u.todayISO(), due, due && f.ht && u.validHM(f.at) ? f.at : '');
    if (!o) { App.alert('متن کار را بنویس'); return; }
    f.txt = ''; f.hd = 0; f.ht = 0; App.save(); App.render();
  };
  App.act['todo-toggle'] = function (el) {
    var x = S().todos.find(function (y) { return String(y.id) === String(el.getAttribute('data-key')); });
    if (x) { x.o = x.o ? 0 : 1; App.save(); }
    App.render();
  };
  App.act['todo-del'] = function (el) {
    st.delById(S().todos, el.getAttribute('data-key')); App.save(); App.render();
  };

  // ---- گزارش پایان روز ----
  function ciCard() {
    var today = u.todayISO(), c = (S().ci || {})[today];
    var f = App.form('ci', c ? { p: c.p, f: c.f, n: c.n } : { p: 2, f: 3, n: '' });
    if (c && f.p == null) { f.p = c.p; f.f = c.f; f.n = c.n; }
    var planOpts = [[3, '✅ کامل'], [2, '🟡 نیمه'], [1, '❌ انجام نشد']];
    var focusOpts = [[3, '🙂 خوب'], [4, '🤩 عالی'], [2, '😐 معمولی'], [1, '😞 ضعیف']];
    return App.card('📝 گزارش پایان روز', (c ? '<div class="mu">ثبت شد ✅ برنامه: ' + ['', '❌ انجام نشد', '🟡 نیمه', '✅ کامل'][c.p] + ' · تمرکز: ' + ['', '😞', '😐', '🙂', '🤩'][c.f] + (c.n ? ' · ' + u.esc(c.n) : '') + '</div>' : '<p class="mu">هر شب ۳۰ ثانیه: چقدر طبق برنامه پیش رفتی؟ مدال «گزارش‌دهنده» هم می‌گیری.</p>') +
      App.field('برنامه‌ی امروز چقدر انجام شد؟', App.select('ci', 'p', planOpts.map(function (x) { return [String(x[0]), x[1]]; }), { id: 'ci-p' })) +
      App.field('تمرکز و حال امروز', App.select('ci', 'f', focusOpts.map(function (x) { return [String(x[0]), x[1]]; }), { id: 'ci-f' })) +
      App.field('مانع یا نکته‌ی امروز (اختیاری)', App.input('ci', 'n', { ph: 'مثلاً خسته بودم', maxlength: 200 })) +
      App.btn(c ? 'به‌روزرسانی گزارش' : 'ثبت گزارش', 'ci-save', {}, 'mt'), { open: !c || new Date().getHours() >= 17 });
  }
  App.act['ci-save'] = function () {
    var f = App.form('ci', {});
    var p = +f.p || 2, fo = +f.f || 3;
    (App.S.ci = App.S.ci || {})[u.todayISO()] = { p: u.clamp(p, 1, 3), f: u.clamp(fo, 1, 4), n: String(f.n || '').trim().slice(0, 200) };
    App.save(); App.render(); App.toast('✅ گزارش امروز ثبت شد');
  };

  // ---- ورودی آزاد (صحبت کن و جایگذاری کن) ----
  function voiceCard() {
    var f = App.form('vp', { txt: '' });
    var list = App.ui.vp || [];
    var VL = pl.VL;
    var preview = list.length ? '<div class="vp-list">' + list.map(function (a, i) {
      return '<div class="li vp-item"><div><b>' + u.esc(VL[a.k] || a.k) + '</b> <span class="mu">' + u.esc(vpDesc(a)) + '</span><br><span>' + u.esc(a.k === 'log' ? (a.x || '') : (a.t || a.x || '')) + '</span></div>' + App.sm('🗑', 'vp-remove', { i: i }) + '</div>';
    }).join('') + '<button type="button" class="btn" data-act="vp-apply">✅ ثبت همه (' + u.fa(list.length) + ')</button></div>' : '';
    return App.card('🎙 صحبت کن و جایگذاری کن', '<p class="mu">هر چیزی را بگو یا بنویس: مطالعه و کلاس، تست، نقاط ضعف، عقب‌افتادگی، کار ثابت («کلاس فیزیک از ۴ تا ۶ هر شنبه»)، نتیجه‌ی آزمون، هدف، خواب و بیداری، شروع تایمر. قبل از ثبت، فهرست را می‌بینی.</p>' +
      '<textarea id="vp-in" class="ta" data-f="vp.txt" placeholder="اینجا بگو یا بنویس…" aria-label="متن آزاد برای ثبت">' + u.esc(f.txt) + '</textarea>' +
      '<div class="q-row"><button type="button" class="sm" id="vp-mic" data-act="vp-mic" aria-pressed="false">🎙 میکروفون</button><button type="button" class="sm" data-act="vp-go">⚡ جایگذاری</button><button type="button" class="sm" data-act="vp-ai">🤖 هوشمند</button></div>' +
      '<p class="mu">برای حرف‌های طولانی بدون مکث، «هوشمند» دقیق‌تر است (فقط آنلاین).</p>' + preview, { open: !!list.length });
  }
  function vpDesc(a) {
    var m = {
      log: function () { return u.fa(a.m) + ' دقیقه · ' + u.fa(a.t) + ' تست' + (a.c ? ' · کلاس' : ''); },
      exam: function () { return u.fa(a.t) + ' سؤال · ✔' + u.fa(a.c) + ' ✘' + u.fa(a.w) + (a.z ? ' · تراز ' + u.fa(a.z) : ''); },
      goal: function () { return u.fa(a.m) + ' دقیقه در روز'; },
      wake: function () { return u.pd(a.v); }, sleep: function () { return u.pd(a.v); },
      busy: function () { return u.pd(a.s0) + ' تا ' + u.pd(a.e0) + ' · ' + (a.r === 'all' ? 'هر روز' : a.r === 'today' ? 'فقط امروز' : 'هر ' + u.WD[+a.r]); },
      wp: function () { return u.WD[a.day] + ' ' + u.pd(a.s0) + ' تا ' + u.pd(a.e0); },
      ex2: function () { return (a.d || '') + ' · ' + u.fa((a.r || []).length) + ' محدوده'; }
    };
    return (m[a.k] || function () { return ''; })();
  }
  App.vpDesc = vpDesc;
  App.act['vp-remove'] = function (el) { App.ui.vp.splice(+el.getAttribute('data-i'), 1); App.render(); };
  App.act['vp-go'] = function () {
    var txt = String(App.form('vp', {}).txt || '');
    if (!txt.trim()) { App.alert('چیزی بنویس یا بگو'); return; }
    var J = pl.jsonOf(txt);
    if (J && J.weekly) { var n = pl.wpApply(J); App.save(); App.render(); App.toast(n ? '✅ برنامه‌ی هفتگی ثبت شد (' + u.fa(n) + ' بلوک)' : 'برنامه‌ی هفتگی معتبر پیدا نشد'); return; }
    if (Array.isArray(J)) App.ui.vp = pl.normActs(J);
    else App.ui.vp = pl.parseLocal(txt);
    if (!App.ui.vp.length) { App.alert('چیزی پیدا نشد؛ جمله‌ها را کامل‌تر بگو.'); }
    App.render();
  };
  App.act['vp-apply'] = function () {
    var list = App.ui.vp || [];
    var r = pl.applyActs(list);
    App.ui.vp = [];
    App.form('vp', {}).txt = '';
    App.save();
    if (App.timer) r.timers.forEach(function (a) { App.timer.fromAct(a); });
    App.render();
    App.toast('✅ ' + u.fa(r.n) + ' مورد ثبت شد');
  };
  App.act['vp-mic'] = function (el) { App.voice.toggle(el, 'vp-in', 'vp.txt'); };
  App.act['vp-ai'] = function () {
    var txt = String(App.form('vp', {}).txt || '');
    if (!txt.trim()) return;
    if (App.ai && App.ai.parseVoice) App.ai.parseVoice(txt);
    else App.act['vp-go']();
  };

  // ---- میانبرها ----
  function shortcutCard() {
    var L = App.gamify.league();
    return '<div class="card shortcut"><div class="row0 wrap">' + App.btn('⏱ تایمر مطالعه یا کلاس', 'go', { tab: 'timer' }, 'sm') + App.btn(L.ic + ' لیگ ' + L.name + ' · ' + u.fa(L.x) + ' امتیاز', 'go', { tab: 'stat' }, 'sm') + '</div></div>';
  }
  function bkWarn() {
    if (S().logs.length < 10) return '';
    var d = S().lb ? u.dayDiff(S().lb, u.todayISO()) : 999;
    if (d < 14) return '';
    return App.card('💾 ' + (S().lb ? u.fa(d) + ' روز' : 'هنوز') + ' از آخرین پشتیبان گذشته', '<p class="mu">برای اینکه حافظه‌ات هیچ‌وقت از بین نرود، یک پشتیبان بگیر.</p>' + App.sm('رفتن به پشتیبان‌گیری', 'go', { tab: 'settings' }), { cls: 'notice', open: true });
  }

  // ---- ثبت کامل مطالعه ----
  function logFormCard() {
    var f = App.form('log', { g: S().mg || 12, s: '', c: 0, m: '', t: '', ok: '', k: 's', d: u.todayISO(), q: 0 });
    if (!u.isISO(f.d)) f.d = u.todayISO();
    return App.card('➕ ثبت مطالعه', '<div class="grid2">' + App.field('پایه', App.select('log', 'g', App.gradeOpts(), { rr: true })) +
      App.field('درس', App.subjSelect('log', 'g', 's')) + '</div>' +
      App.field('مبحث (فصل)', App.chapSelect('log', 'g', 's', 'c')) +
      '<div class="grid2">' + App.field('زمان مطالعه (دقیقه)', App.input('log', 'm', { t: 'int', inputmode: 'numeric', ph: 'مثلاً ۹۰' })) +
      App.field('تعداد تست زده‌شده', App.input('log', 't', { t: 'int', inputmode: 'numeric', ph: '۰' })) + '</div>' +
      '<div class="grid2">' + App.field('از آنها درست', App.input('log', 'ok', { t: 'int', inputmode: 'numeric', ph: 'اختیاری' })) +
      App.field('نوع', App.select('log', 'k', [['s', 'مطالعه'], ['c', 'کلاس']])) + '</div>' +
      App.field('تاریخ', App.dateField('log', 'd', { label: 'تاریخ ثبت' })) +
      App.field('تمرکزت چطور بود؟ (اختیاری)', App.select('log', 'q', [['0', '—'], ['1', '😞 ضعیف'], ['2', '😐 معمولی'], ['3', '🙂 خوب'], ['4', '🤩 عالی']])) +
      App.btn('ثبت', 'log-add', {}, 'mt'), { key: 'today|➕ ثبت مطالعه', open: false });
  }
  App.act['log-add'] = function () {
    var f = App.form('log', {});
    var m = u.int(f.m, 0, 1440, 0), t = u.int(f.t, 0, 5000, 0);
    if (!m && !t) { App.alert('زمان یا تعداد تست را وارد کن'); return; }
    var ok = f.ok === '' || f.ok == null ? undefined : u.int(f.ok, 0, t, undefined);
    if (ok === undefined && f.ok !== '' && f.ok != null) { App.alert('تعداد درست نباید بیشتر از تست‌ها باشد'); return; }
    var rec = st.addLog({ g: +f.g || S().mg, s: f.s, c: +f.c || 0, m: m, t: t, ok: ok, k: f.k === 'c' ? 'c' : undefined, d: f.d, q: +f.q || undefined });
    if (!rec) return;
    App.save();
    App.toast('✅ ثبت شد', { action: { label: '↩️ برگردان', fn: function () { st.delLog(rec.id); App.save(); App.render(); } } });
    f.m = ''; f.t = ''; f.ok = '';
    App.render();
  };

  // تاریخچه‌ی یک روز (فهرست کوتاه با ویرایش/حذف)
  function historyList(iso) {
    var L = S().logs.filter(function (l) { return l.d === iso; }).sort(function (a, b) { return b.id - a.id; });
    if (!L.length) return '<p class="mu empty">برای این روز هنوز ثبتی نیست. از «⚡ ثبت سریع» بالا اولین ثبت را بزن؛ حتی ۱۵ دقیقه هم حساب می‌شود.</p>';
    return L.map(function (l) {
      return '<div class="li"><span>' + (l.k === 'c' ? '🏫 کلاس ' : '') + u.esc(l.s) + ' (' + u.esc(D.GN[l.g] || '') + ')' + (l.c ? ' · ' + u.esc(st.chName(l.g, l.s, l.c)) : '') +
        '<br><span class="mu">' + u.fa(l.m) + ' دقیقه · ' + u.fa(l.t) + ' تست' + (l.ok != null ? ' · ✔' + u.fa(l.ok) + '/' + u.fa(l.t) : '') + '</span></span>' +
        App.sm('🗑', 'log-del', { key: l.id }) + '</div>';
    }).join('');
  }
  App.historyList = historyList;
  App.act['log-del'] = function (el) {
    var id = el.getAttribute('data-key');
    var rec = st.delLog(id);
    if (!rec) return;
    App.save(); App.render();
    App.toast('ثبت حذف شد', { action: { label: '↩️ برگردان', fn: function () { App.S.logs.push(rec); App.save(); App.render(); } }, ms: 6000 });
  };

  // ---- هوش مصنوعی: میانبرهای امروز ----
  function aiQuick() {
    return App.card('🤖 از مشاور بخواه', '<div class="q-row">' +
      App.sm('📊 تحلیل وضعیت', 'ai-ask', { q: 'analysis', tab: 'today' }) +
      App.sm('😓 انگیزه ندارم', 'ai-ask', { q: 'motiv', tab: 'today' }) +
      App.sm('🔁 تعهد فردا', 'ai-ask', { q: 'commit', tab: 'today' }) + '</div>', { open: false });
  }
  App.views.todayAIQuick = aiQuick;
})();
