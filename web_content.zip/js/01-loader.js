(function () {
  if (window.ffmLoader) return;
  const S = 40, G = {
    F: ['11111', '10000', '10000', '11110', '10000', '10000', '10000'],
    M: ['10001', '11011', '10001', '10001', '10001', '10001', '10001'],
    2: ['01110', '10001', '00001', '00010', '00100', '01000', '11111'],
    6: ['00110', '01000', '10000', '11110', '10001', '10001', '01110']
  };
  const glyph = (ch, ox, oy, col, shadow) => {
    let s = '';
    G[ch].forEach((row, r) => { for (let c = 0; c < 5; c++) if (row[c] === '1') s += '<rect x="' + (ox + c * S) + '" y="' + (oy + r * S) + '" width="' + S + '" height="' + S + '" fill="' + col + '"/>'; });
    let sh = '';
    G[ch].forEach((row, r) => { for (let c = 0; c < 5; c++) if (row[c] === '1') sh += '<rect x="' + (ox + c * S + 11) + '" y="' + (oy + r * S + 11) + '" width="' + S + '" height="' + S + '" fill="' + shadow + '"/>'; });
    return sh + s;
  };
  let stars = '';
  for (let k = 0; k < 7; k++) for (const y of [60, 402, 744, 1086]) stars += '<rect class="ld-st" style="animation-delay:' + ((k * 3 + y / 100) % 7) * 0.35 + 's" x="' + (171 + 342 * k) + '" y="' + y + '" width="12" height="12" fill="#e8f0ff"/>';
  for (let k = 0; k < 6; k++) for (const y of [231, 573, 915]) stars += '<rect class="ld-st" style="animation-delay:' + ((k + y / 100) % 5) * 0.4 + 's" x="' + (342 + 684 / 2 * k) + '" y="' + y + '" width="8" height="8" fill="#8fa8ff"/>';
  const BAR = { x0: 185, x1: 2100, y0: 1044, y1: 1106 };
  const par = (x0, x1, y0, y1, sk) => (x0 + sk) + ',' + y0 + ' ' + x1 + ',' + y0 + ' ' + (x1 - sk) + ',' + y1 + ' ' + x0 + ',' + y1;
  let seg = ''; for (let k = 1; k <= 9; k++) { const x = 185 + k * 190; seg += '<line x1="' + (x + 32) + '" y1="1044" x2="' + (x - 32) + '" y2="1106" stroke="#12285e" stroke-width="5"/>'; }
  const svg = '<svg viewBox="0 0 2286 1176" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg">' + stars +
    glyph('F', 543, 235, '#fff', '#2a6fdb') + glyph('F', 783, 235, '#fff', '#2a6fdb') + glyph('M', 1023, 235, '#fff', '#2a6fdb') + glyph('2', 1303, 235, '#3fd0ff', '#fff') + glyph('6', 1543, 235, '#3fd0ff', '#fff') +
    '<rect x="700" y="587" width="888" height="92" fill="#0a2a78"/><rect x="703" y="590" width="882" height="86" fill="#4fd9ff"/>' +
    '<text x="1144" y="652" text-anchor="middle" font-family="\'Courier New\',monospace" font-weight="bold" font-size="54" letter-spacing="14" fill="#0b1f66">FOOTBALL MANAGER</text>' +
    '<text id="ld-txt" x="2090" y="1015" text-anchor="end" font-family="\'Courier New\',monospace" font-weight="bold" font-size="56" fill="#fff">Loading...</text>' +
    '<polygon points="' + par(BAR.x0 - 6, BAR.x1 + 6, BAR.y0 - 6, BAR.y1 + 6, 52) + '" fill="#fff"/><polygon points="' + par(BAR.x0, BAR.x1, BAR.y0, BAR.y1, 50) + '" fill="#06144f"/>' +
    '<clipPath id="ld-clip"><polygon points="' + par(BAR.x0, BAR.x1, BAR.y0, BAR.y1, 50) + '"/></clipPath>' +
    '<g clip-path="url(#ld-clip)"><rect id="ld-fill" x="185" y="1044" width="0" height="62" fill="#fdc200"/><rect id="ld-fill2" x="185" y="1044" width="0" height="14" fill="#ffe27a"/><rect id="ld-fill3" x="185" y="1096" width="0" height="10" fill="#b8860b"/>' + seg + '</g>' +
    '<polygon points="143,1074 171,1058 171,1090" fill="#3fd0ff"/><polygon points="2143,1074 2115,1058 2115,1090" fill="#3fd0ff"/></svg>';
  const css = '#ffm-loader{position:fixed;inset:0;z-index:2147483000;background:linear-gradient(180deg,#00003c 0%,#06207a 45%,#1456cc 100%);display:none;align-items:center;justify-content:center;touch-action:none;opacity:1;transition:opacity .45s}#ffm-loader.on{display:flex}#ffm-loader svg{width:100%;max-height:100%}.ld-st{animation:ldTw 2.4s steps(2,end) infinite}@keyframes ldTw{0%,60%{opacity:1}61%,100%{opacity:.25}}';
  const LT = { ar: 'جارٍ التحميل', en: 'Loading', fr: 'Chargement', es: 'Cargando', pt: 'Carregando', de: 'Lädt', tr: 'Yükleniyor' };
  function lang() { try { if (typeof state !== 'undefined' && state.lang) return state.lang; } catch (_) {} const n = (navigator.language || 'en').slice(0, 2); return LT[n] ? n : 'en'; }
  let el = null, timer = 0, busy = false;
  function build() {
    if (el) return el;
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    el = document.createElement('div'); el.id = 'ffm-loader'; el.innerHTML = svg; document.body.appendChild(el); return el;
  }
  function show(ms, done) {
    if (busy) return; busy = true; build(); el.style.opacity = 1; el.classList.add('on');
    const t0 = performance.now(), f1 = document.getElementById('ld-fill'), f2 = document.getElementById('ld-fill2'), f3 = document.getElementById('ld-fill3'), tx = document.getElementById('ld-txt'), W = 1915;
    (function tick() {
      const p = Math.min(1, (performance.now() - t0) / ms), w = Math.round(W * p / 20) * 20; // chunky pixel-style steps
      [f1, f2, f3].forEach(f => f.setAttribute('width', Math.max(0, w)));
      tx.textContent = LT[lang()] + '.'.repeat(1 + Math.floor((performance.now() - t0) / 350) % 3);
      if (p < 1) { timer = requestAnimationFrame(tick); return; }
      [f1, f2, f3].forEach(f => f.setAttribute('width', W));
      el.style.opacity = 0;
      setTimeout(() => { el.classList.remove('on'); busy = false; try { done && done(); } catch (e) { console.error(e); } }, 460);
    })();
  }
  window.ffmLoader = { show: show };
  const boot = () => show(15000, () => { try { window.ffmMenuAnim && ffmMenuAnim(document.getElementById('screen-main-menu')); } catch (_) {} });
  if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);
})();
