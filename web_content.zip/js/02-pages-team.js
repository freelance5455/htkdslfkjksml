
/* =========================
   页面切换
========================= */

function hideScreens(){
  [
    'menuScreen',
    'levelScreen',
    'shopScreen',
    'codexScreen',
    'guideScreen',
    'guideBasicScreen',
    'guideHateScreen',
    'selectScreen',
    'gameScreen'
  ].forEach(id=>{
    const el=$(id);
    if(el)el.classList.add('hidden');
  });
}

function cancelTimers(){
  if(enemyTimer!==null)clearTimeout(enemyTimer);
  enemyTimer=null;

  if(resultTimer!==null)clearTimeout(resultTimer);
  resultTimer=null;
}

function invalidateBattle(){
  cancelTimers();
  battleToken++;
  if(s)s.done=true;
}

function showMenu(){
  invalidateBattle();
  if(typeof updateCoinDisplay==='function')updateCoinDisplay();
  hideScreens();
  $('menuScreen').classList.remove('hidden');
  $('overlay').classList.remove('show');
}

function showLevels(){
  invalidateBattle();
  if(typeof renderLevelCoins==='function')renderLevelCoins();
  $('overlay').classList.remove('show');
  hideScreens();
  $('levelScreen').classList.remove('hidden');
}


function showShop(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('shopScreen').classList.remove('hidden');
}
function renderLevelCoins(){
  for(let level=1;level<=4;level++){
    const el=$('levelCoin'+level);
    if(!el)continue;
    const cleared=!!(playerSave&&playerSave.clearedLevels.includes(level));
    el.textContent=cleared?'🪙✓':'🪙';
    el.classList.toggle('collected',cleared);
    el.title=cleared?'首次通关金币已领取':'首次通关可获得1枚金币';
  }
}

function showCodex(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('codexScreen').classList.remove('hidden');
}

function showGuide(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideScreen').classList.remove('hidden');
}

function showGuideBasic(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideBasicScreen').classList.remove('hidden');
}

/* 🔥 仇恨介绍页面 */
function showGuideHate(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideHateScreen').classList.remove('hidden');
}

function exitGame(){
  $('exitMessage').textContent=
    '浏览器通常不允许网页直接关闭用户主动打开的标签页。你可以关闭当前浏览器标签页退出游戏。';
}

/* =========================
   选关与队伍选择
========================= */

function changeTeam(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('selectScreen').classList.remove('hidden');
  renderSelection();
}

function chooseLevel(level){
  invalidateBattle();
  selectedLevel=level;
  selectedTeam=[];
  $('overlay').classList.remove('show');
  hideScreens();
  $('selectScreen').classList.remove('hidden');
  renderSelection();
}

function teamSize(){
  return selectedLevel===4?3:2;
}

function renderSelection(){
  const labels={
    1:'见面礼（鸭皇、拳头盒子）',
    2:'鸭皇围攻（三只鸭皇）',
    3:'鸭皇队长（鸭皇、鸭皇队长）',
    4:'全明星阵容（女主人、鸭皇队长、拳头盒子）'
  };

  const required=teamSize();

  $('levelSubtitle').textContent=
    `当前选择：第${selectedLevel}关 · ${labels[selectedLevel]}。请选择${required}名出战角色。`;

  const enemyPreviewData={
    1:[{id:'duck',name:'鸭皇',icon:'🦆',hp:100,skills:'普通攻击：造成20点伤害。'},
       {id:'box',name:'拳头盒子',icon:'🥊',hp:150,skills:'拳头重击：造成20点伤害，首次命中尝试附加眩晕。'}],
    2:[1,2,3].map(n=>({id:'duck'+n,name:'鸭皇'+n,icon:'🦆',hp:100,skills:'普通攻击：造成20点伤害。'})),
    3:[{id:'duck',name:'鸭皇',icon:'🦆',hp:100,skills:'普通攻击：造成20点伤害。'},
       {id:'captain',name:'鸭皇队长',icon:'🚩',hp:200,skills:'蓄力后召唤一只随从鸭皇。'}],
    4:[{id:'mistress',name:'女主人',icon:'👩‍🦰',hp:150,skills:'进行长时间蓄力后发动致命一击。'},
       {id:'captain',name:'鸭皇队长',icon:'🚩',hp:200,skills:'蓄力后召唤一只随从鸭皇。'},
       {id:'box',name:'拳头盒子',icon:'🥊',hp:150,skills:'拳头重击：造成20点伤害，首次命中尝试附加眩晕。'}]
  };
  currentEnemyPreview=enemyPreviewData[selectedLevel];
  $('enemyPreview').innerHTML=currentEnemyPreview.map((e,i)=>`
    <article class="enemy-preview-card">
      <button class="info-button" aria-label="查看${e.name}属性技能" onclick="event.stopPropagation();showEnemyInfoByIndex(${i})">!</button>
      <div class="pick-avatar">${e.icon}</div><h3>${e.name}</h3><p>HP：${e.hp}</p>
    </article>`).join('');

  $('selectGrid').innerHTML=Object.values(characterData).filter(c=>isCharacterUnlocked(c.id)).map(c=>{
    const chosen=selectedTeam.includes(c.id);

    return `
      <article class="select-card ${chosen?'chosen':''}"
        role="button"
        tabindex="0"
        aria-pressed="${chosen}"
        onclick="toggleCharacter('${c.id}')"
        onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();toggleCharacter('${c.id}')}">
        <button class="info-button" aria-label="查看${c.name}属性技能" onclick="event.stopPropagation();showCharacterInfo('${c.id}')">!</button>
        <div class="pick-avatar">${c.icon}</div>
        <h3>${c.name}</h3>
        <p>HP：${c.max}</p>
        <p>${c.desc}</p>
        <div class="pick-state">${chosen?'✓ 已选择':'点击选择'}</div>
      </article>
    `;
  }).join('');

  $('selectionCount').textContent=`已选择 ${selectedTeam.length} / ${required}`;
  $('confirmTeamBtn').disabled=selectedTeam.length!==required;

  $('selectHint').textContent=selectedTeam.length===required
    ?`当前队伍：${selectedTeam.map(id=>characterData[id].name).join('、')}。确认后开始第${selectedLevel}关。`
    :`请选择${required}名角色。`;
}

let currentEnemyPreview=[];
function showEnemyInfoByIndex(index){const e=currentEnemyPreview[index];if(e)showEnemyInfo(e.id,e.name,e.icon,e.hp,e.skills);}
const characterSkillInfo={
  jerry:{skills:['大铁锤：对一名存活敌人造成25点伤害。','团队防护：全体存活队友获得30%减伤，抵挡2次敌方攻击。'],type:'八面玲珑'},
  shirley:{skills:['拳击：随机对一名存活敌人造成20伤害。','爱心花束：为所有存活队友恢复各自最大HP的20%。'],type:'支援'},
  tuffy:{skills:['火箭筒：对所有存活敌人造成20点伤害。','奶酪蛋糕：增加30点最大HP并恢复35点当前HP，效果持续至敌方下一轮全体行动结束。'],type:'八面玲珑'},
  swordsman:{skills:['剑舞：对一名存活敌人造成30点伤害。','格挡：敌方本轮行动结束前免疫控制；受击存活后反击40点伤害，冷却1回合。'],type:'主攻手'},
  demon:{skills:['三叉戟：对一名敌人造成25点伤害，并施加持续一轮的仇恨效果。','诅咒符纸：选择一名我方角色施加诅咒并吸引敌方仇恨；敌人攻击诅咒角色后，其下一次攻击伤害降低30%。技能冷却1回合。'],type:'支援'}
};
function showCharacterInfo(id){
  const c=characterData[id], info=characterSkillInfo[id];
  if(!c||!info)return;
  $('characterInfoContent').innerHTML=`<div class="info-hero">${c.icon}</div><h1 id="characterInfoTitle">${c.name}</h1><p class="codex-type">${info.type}</p><p><b>生命值：</b>${c.max} HP</p><h2>技能与属性</h2><ul class="info-skills">${info.skills.map(x=>`<li>${x}</li>`).join('')}</ul>`;
  $('characterInfoScreen').classList.remove('hidden');
}
function showEnemyInfo(id,name,icon,hp,skills){
  $('characterInfoContent').innerHTML=`<div class="info-hero">${icon}</div><h1 id="characterInfoTitle">${name}</h1><p class="codex-type">敌方角色</p><p><b>生命值：</b>${hp} HP</p><h2>属性与技能</h2><ul class="info-skills"><li>${skills}</li></ul>`;
  $('characterInfoScreen').classList.remove('hidden');
}
function closeCharacterInfo(){
  $('characterInfoScreen').classList.add('hidden');
}
function toggleCharacter(id){
  const required=teamSize();

  if(selectedTeam.includes(id)){
    selectedTeam=selectedTeam.filter(x=>x!==id);
  }else{
    if(selectedTeam.length>=required){
      $('selectHint').textContent=
        `已经选满${required}名角色。请先取消一名，再选择其他角色。`;
      return;
    }
    selectedTeam.push(id);
  }

  renderSelection();
}

function confirmTeam(){
  if(selectedTeam.length!==teamSize())return;

  hideScreens();
  $('gameScreen').classList.remove('hidden');

  const titles={
    1:'第一关：见面礼',
    2:'第二关：鸭皇围攻',
    3:'第三关：鸭皇队长',
    4:'第四关：全明星阵容'
  };

  $('gameTitle').textContent=titles[selectedLevel];
  $('teamSubtitle').textContent=
    `出战队伍：${selectedTeam.map(id=>characterData[id].name).join('、')}。`;

  restart();
}