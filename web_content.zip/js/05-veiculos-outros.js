/* Veiculos: demais blindados, helicopteros, antiaereos e corveta */
/* ---------- T-34/85 (URSS): suspensao Christie, tanques extras de combustivel e infantaria na garupa ---------- */
function makeT34(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x4d5f34),g=new THREE.Group(),wheels=[],GX=1.28,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c,FT=0x3d4a2a;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-2.5,.1],[2.3,.1],[2.85,.38],[2.75,.8],[2.25,.98],[-2.2,.98],[-2.8,.8],[-2.95,.42],[-2.75,.16]],64,.5,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,gS,sx,.46,-2.75,.38,s,wheels);wl(g,gW,sx,.44,2.6,.4,s,wheels);for(let i=0;i<5;i++)wl(g,gW,sx,.5,-1.85+i*.92,.42,s,wheels).userData.b=1});
  const hull=new THREE.Group(),H=mb();
  H.b(2.1,.5,5.6,'M',0,.72,0);H.b(2.3,.2,5.4,DK,0,.4,0);H.b(2.55,.5,3.4,'M',0,1.12,-1);H.b(2.5,.1,2.3,'M',0,1.04,1.9,.3);H.b(2.2,.45,.1,'M',0,.52,3.1,-.1);H.b(2.5,.6,.1,'M',0,1,-2.8,.3);
  for(let k=0;k<6;k++)H.b(1.5,.04,.12,MT,0,1.4,-2.4+k*.3);
  H.c(.3,.3,.12,MT,-.5,1.22,1.4,'y');H.b(.25,.07,.06,GL,-.5,1.3,1.62);H.g(new THREE.SphereGeometry(.16,8,6),MT,.6,.74,2.95);H.c(.04,.04,.4,DK,.6,.74,3.2,'z');
  for(const s of[-1,1]){H.b(.8,.05,5.9,'M',s*1.45,1.05,0);H.b(.8,.05,.8,'M',s*1.45,1.1,3.1,.35);H.c(.2,.2,1.1,FT,s*1.5,1.3,-1.9,'z');H.c(.2,.2,1.1,FT,s*1.5,1.3,-.6,'z');H.b(.9,.04,.3,MT,s*.6,1.1,1.8,.3);H.c(.05,.05,3.2,DK,s*1.6,1.14,1,'z');H.c(.1,.1,.5,DK,s*.9,.85,-3,'z');H.b(.1,.1,.4,DK,s*1.2,1.25,2.2);hull.add(bx(.3,.18,.08,brkM,s*.8,1,-2.86))}
  hull.add(bx(.25,.18,.1,lamp,-.9,.95,3.05));
  H.out(hull,mat);g.add(hull);
  const ant=mkAnt(hull,1.2,1.4,-2.3,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.37,.3);
  T.c(1.2,1.25,.55,'M',0,.28,0,'y');T.c(1,1.15,.2,'M',0,.65,0,'y');T.b(1.7,.6,1,'M',0,.35,-1.15);T.b(1.8,.55,.3,'M',0,.3,-1.7,.3);T.b(1.4,.6,.8,'M',0,.35,1.05);T.b(.8,.5,.3,'M',0,.3,1.4);
  T.b(.35,.12,.5,MT,.55,.78,.5);T.b(.25,.14,.04,GL,.55,.8,.76);T.c(.12,.12,.15,MT,-.1,.78,.6,'y');T.c(.4,.44,.14,MT,-.45,.82,-.45,'y');T.b(1.2,.04,.04,MT,0,.4,-2.1);
  for(const s of[-1,1])for(let k=0;k<3;k++)T.b(.04,.3,.04,MT,s*.95,.95,-.9+k*.6);
  T.out(tg,mat);
  const cup=new THREE.Group();cup.position.set(-.45,.92,-.45);cup.add(new THREE.Mesh(new THREE.CylinderGeometry(.34,.36,.14,10),dark));
  for(let k=0;k<5;k++){const a=k/5*6.283,m=bx(.12,.06,.04,gl,Math.sin(a)*.34,.06,Math.cos(a)*.34);m.rotation.y=a;cup.add(m)}tg.add(cup);
  const cl=mkLid(tg,mat,-.45,1,-.45,.26),ll=mkLid(tg,mat,.5,.78,.15,.3),crew=mkCrew(tg,cm,hm,sk,-.45,.6,-.45),cmg=mkMG(tg,.5,.82,.45);
  for(const s of[-1,1])stk(tg,t34N,s*1.235,.3,-.1,s,.8,.4);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,1.5);
  B.b(.9,.56,.3,'M',0,0,.1);B.c(.2,.24,.3,RB,0,0,.35,'z');B.b(.16,.2,.06,GL,-.35,.2,.3);B.out(bp,mat);
  K.c(.1,.095,3.5,DK,0,0,2.2,'z');K.c(.14,.12,.5,'M',0,0,.65,'z');K.c(.12,.12,.1,DK,0,0,3.95,'z');K.out(bar,mat);
  const fl=mkFl(bar,4,.45,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  const r1=mkCrew(hull,cm,hm,sk,-.5,1.38,-2),r2=mkCrew(hull,cm,hm,sk,.5,1.38,-2.15);r1.visible=r2.visible=true;
  return fin(base({g,tg,bp,bar,hull,ant,cup,lid:[cl,ll],crew,cmg,rid:[r1,r2],fl,brkM,wheels,trk,mat,dark,t34:true,cannon:true,spd:1.18,trn:1,L:3.2,W:1.8,mz:4.05,fk:1,rld:1.9,wd:1.5,armor:.88,TY:1.37}));
}
function animT34(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.rid.forEach(r=>r.visible=false);return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/13,0,1),d=trkStep(t,dt,1.28);
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*10+i*1.7)*.03*th});
  t.hull.position.y=Math.sin(now*34+t.x)*(.008+.014*th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.02;t.ant.rotation.x=-t.v*.014+Math.sin(now*3+t.z)*.04;
  const ac=(t.v-t.pv)/Math.max(dt,.001);
  t.rid.forEach((r,i)=>{r.rotation.x=clamp(-ac*.012,-.3,.3)+Math.sin(now*9+i*2)*.04*th;r.position.y=1.38+Math.abs(Math.sin(now*11+i))*.03*th;r.rotation.y=Math.sin(now*.6+i*3)*.5});
  t.cup.rotation.y=Math.sin(now*.8+t.x)*1.3*(1-t.open*.7);
  tankFx(t,dt,now,th,{ex:[[.9,.85,-3.2],[-.9,.85,-3.2]],dk:[[1.3,.2,-3],[-1.3,.2,-3]],mz:4,rr:1.4,rc:.7});
  mgScan(t,dt,48);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);
}

/* ---------- T-35 (URSS): pesado de cinco torres, cada uma mira e atira sozinha ---------- */
function makeT35(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x4f5a36),g=new THREE.Group(),wheels=[],bogs=[],GX=1.42,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-4.5,.1],[4.1,.1],[4.85,.45],[4.75,.95],[4.1,1.15],[-4.1,1.15],[-4.85,.95],[-4.95,.5]],110,.55,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    wl(g,gS5,sx,.55,-4.35,.48,s,wheels);wl(g,gW5,sx,.5,4.3,.42,s,wheels);
    for(let p=0;p<4;p++){const bg=new THREE.Group();bg.position.set(sx,.48,-3+p*2.05);wl(bg,gW5,0,0,-.5,.38,s,wheels);wl(bg,gW5,0,0,.5,.38,s,wheels);bg.add(bx(.14,.12,1.1,dark,0,.08,0),bx(.2,.5,.2,dark,0,.35,0),bx(.4,.12,.4,dark,0,.62,0));g.add(bg);bogs.push(bg)}
    for(let k=0;k<6;k++)wl(g,gRL,sx,.98,-3.5+k*1.4,.16,s,wheels);
  });
  const hull=new THREE.Group(),H=mb();
  H.b(2.3,.8,9.2,'M',0,.9,0);H.b(2.5,.2,9,DK,0,.5,0);H.b(2.6,.5,7.4,'M',0,1.55,-.4);H.b(2.4,.1,1.6,'M',0,1.4,4,.52);H.b(2.3,.5,.1,'M',0,.85,4.7);H.b(2.6,.9,.1,'M',0,1.3,-4.65);
  H.b(1.2,.45,1.1,'M',0,1.95,3);H.b(.7,.08,.04,GL,0,2,3.56);H.c(.3,.3,.1,MT,0,2.2,3,'y');
  for(const s of[-1,1]){for(let k=0;k<8;k++){H.b(.1,.62,1,'M',s*1.85,1.18,-3.6+k*1.03);H.b(.12,.04,.9,MT,s*1.85,1.52,-3.6+k*1.03)}
    H.b(.03,.03,6.2,MT,s*1.3,2.1,0);H.c(.05,.05,3,DK,s*1.6,1.6,-.5,'z');H.c(.16,.16,.7,DK,s*.8,1.6,-4.9,'z');hull.add(bx(.3,.18,.1,lamp,s*.9,1.1,4.75),bx(.3,.2,.08,brkM,s*.9,1.2,-4.72))}
  for(let k=0;k<8;k++)H.b(1.6,.04,.1,MT,0,1.82,-3.9+k*.22);
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-.9,1.8,-3.6,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.8,.15);
  T.c(1,1.05,.7,'M',0,.35,0,'y');T.c(.8,1,.14,'M',0,.77,0,'y');T.b(.9,.5,.7,'M',0,.35,-.95);T.c(.45,.5,.25,MT,.35,.92,-.2,'y');T.b(.3,.12,.04,GL,-.3,.6,.9);
  for(let k=0;k<6;k++)T.b(.04,.04,.04,MT,-.9,.2+k*.1,.3);
  T.out(tg,mat);
  const cl=mkLid(tg,mat,.35,1.05,-.2,.3),ll=mkLid(tg,mat,-.4,.92,.35,.28),crew=mkCrew(tg,cm,hm,sk,.35,.65,-.2),cmg=mkMG(tg,-.4,.95,-.15);
  for(const s of[-1,1])stk(tg,t35N,s*1.06,.35,0,s,.8,.4);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.45,.95);
  B.b(.7,.5,.3,'M',0,0,.1);B.c(.2,.24,.25,RB,0,0,.3,'z');B.out(bp,mat);
  K.c(.11,.1,2.3,DK,0,0,1.35,'z');K.c(.16,.16,.6,'M',0,0,.6,'z');K.c(.14,.14,.12,DK,0,0,2.5,'z');K.out(bar,mat);
  const fl=mkFl(bar,2.6,.4,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  const su=[subT(hull,mat,1,1.8,3,.55,1.5,.06,2.4,1.1,75,.55,0),subT(hull,mat,-1,1.8,-3,.55,1.5,.06,2.4,1.1,75,.55,2),subT(hull,mat,-1,1.8,3.3,.36,1,.035,.6,.13,50,.3,4),subT(hull,mat,1,1.8,-3.3,.36,1,.035,.6,.13,50,.3,6)];
  return fin(base({g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,cmg,subs:su,fl,brkM,wheels,bogs,trk,mat,dark,t35:true,cannon:true,spd:.82,trn:.6,L:4.6,W:1.9,mz:2.7,fk:1.1,rld:2.6,wd:1.7,armor:.7,TY:1.8}));
}
function animT35(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/11,0,1),d=trkStep(t,dt,1.42);
  for(const w of t.wheels)w.rotation.x+=d[w.userData.s]/w.userData.r;
  t.bogs.forEach((b,i)=>b.rotation.x=Math.sin(now*7+i*1.9)*.05*th);
  t.hull.position.y=Math.sin(now*30+t.x)*(.006+.012*th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.015;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  tankFx(t,dt,now,th,{ex:[[.8,1.6,-5],[-.8,1.6,-5]],dk:[[1.4,.2,-4.6],[-1.4,.2,-4.6],[1.4,.2,4.5]],mz:2.6,rr:1.5,rc:.5});
  mgScan(t,dt,75);for(const u of t.subs)subAim(t,dt,u,t.hd,now);
  mgAim(t,dt,t.cmg,t.yaw,.6,[0,.1,1.45],now);
}

/* ---------- Leopard 2A6 (Alemanha): canhao Rh120 L/55, torre em cunha, saias blindadas, 16 lancadores de fumaca ---------- */
function makeLeo(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x6b7b4a,lpT),g=new THREE.Group(),wheels=[],GX=1.62,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-3.1,.1],[3,.1],[3.7,.5],[3.5,.95],[3,1.08],[-2.9,1.08],[-3.65,.95],[-3.7,.5]],90,.66,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,gSL,sx,.55,-3.15,.52,s,wheels);wl(g,gWL,sx,.5,3.3,.46,s,wheels);for(let i=0;i<7;i++)wl(g,gWL,sx,.5,-2.55+i*.88,.46,s,wheels).userData.b=1;for(let k=0;k<4;k++)wl(g,gRL,sx,1.02,-2.2+k*1.3,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb(),fp=[];
  H.b(2.7,.7,7,'M',0,.82,0);H.b(2.5,.2,6.8,DK,0,.45,0);H.b(3.3,.3,5,'M',0,1.3,-.6);H.b(3,.14,2.3,'M',0,1.16,3.05,.38);H.b(2.8,.5,.14,'M',0,.72,3.95,-.2);
  H.b(2.7,.12,2.2,'M',0,1.5,-2.6);H.b(2.7,.7,.1,'M',0,1.1,-3.55,.15);
  for(let k=0;k<8;k++)H.b(2.2,.04,.07,MT,0,1.57,-3.3+k*.2);
  H.c(.34,.36,.12,MT,-.7,1.55,2.1,'y');for(let k=0;k<3;k++)H.b(.14,.07,.07,GL,-.7+(k-1)*.18,1.62,2.4);
  for(const s of[-1,1]){for(let k=0;k<6;k++){H.b(.18,.8,.9,'M',s*1.95,.95,-2.6+k*.98);H.b(.2,.06,.9,MT,s*1.95,1.37,-2.6+k*.98)}
    H.b(.9,.08,1.2,'M',s*1.8,1.45,3.1,.2);H.c(.14,.14,.4,DK,s*.9,1.3,-3.7,'z');H.c(.04,.04,2.6,DK,s*1.8,1.05,-.4,'z');H.b(.3,.2,.5,MT,s*1.4,1.48,-1,0);
    hull.add(bx(.3,.18,.1,lamp,s*1.2,1.5,3.9),bx(.3,.2,.08,brkM,s*1,.95,-3.58));
    const f=new THREE.Group();f.position.set(s*1.8,1.4,3.75);f.add(bx(.05,.7,.9,dark,0,-.35,0));hull.add(f);fp.push(f)}
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.2,1.55,-3,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.5,.25);
  T.b(2.5,.6,2.8,'M',0,.5,0);T.b(2.3,.12,2.6,'M',0,.84,-.1);T.b(2.9,.75,1.5,'M',0,.45,-2);T.b(2.8,.5,.2,'M',0,.48,-2.85,.3);
  for(const s of[-1,1]){T.b(1,.65,1.6,'M',s*.85,.5,1.4,0,-s*.5);T.b(.2,.5,1.2,'M',s*1.3,.5,-2,0);
    for(let k=0;k<8;k++)T.c(.05,.05,.26,DK,s*(1.22-k*.02),.82,.5+k*.13,'y',0,0,-s*.5)}
  T.b(.45,.3,.5,DK,.6,1.02,.8);T.b(.3,.15,.04,GL,.6,1.04,1.07);T.c(.4,.42,.3,MT,.7,.95,-.55,'y');T.c(.4,.4,.1,MT,-.65,.9,-.6,'y');
  for(let k=0;k<6;k++){const a=k/6*6.283;T.b(.12,.08,.05,GL,.7+Math.sin(a)*.4,1.02,-.55+Math.cos(a)*.4,0,a)}
  T.b(2.4,.05,.05,MT,0,.3,-2.95);T.b(2.4,.05,.05,MT,0,.7,-2.95);
  T.out(tg,mat);
  const peri=new THREE.Group();peri.position.set(.3,.9,-.15);peri.add(bx(.22,.22,.3,dark,0,.12,0),bx(.16,.1,.04,gl,0,.14,.17));tg.add(peri);
  const cl=mkLid(tg,mat,.7,1.1,-.55,.3),ll=mkLid(tg,mat,-.65,.94,-.6,.34),crew=mkCrew(tg,cm,hm,sk,.7,.6,-.55),cmg=mkMG(tg,-.65,.95,-.3);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,2.15);
  B.b(1.2,.7,.55,'M',0,0,.1);B.c(.28,.33,.35,RB,0,0,.5,'z');B.b(.3,.2,.06,GL,-.4,.2,.4);B.out(bp,mat);
  K.c(.13,.13,5.9,DK,0,0,3.4,'z');K.c(.19,.19,2,'M',0,0,2.1,'z');for(let k=0;k<4;k++)K.c(.2,.2,.07,DK,0,0,1.2+k*.5,'z');
  K.c(.21,.21,.5,'M',0,0,4.1,'z');K.b(.08,.08,.16,MT,0,.17,5.9);K.c(.15,.15,.15,DK,0,0,6.3,'z');K.out(bar,mat);
  const fl=mkFl(bar,6.3,.55,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,peri,fp,lid:[cl,ll],crew,cmg,fl,brkM,wheels,trk,mat,dark,leo:true,cannon:true,spd:1.3,trn:.95,L:3.8,W:1.9,mz:6.1,fk:1.5,rld:2.3,wd:2.3,armor:.62,TY:1.5}));
}
function animLeo(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/14,0,1),d=trkStep(t,dt,1.62);
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*11+i*1.7)*.02*th});
  t.hull.position.y=Math.sin(now*32+t.x)*(.008+.01*th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.02;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  for(const f of t.fp)f.rotation.x=clamp(-t.v*.03,-.5,.5)+Math.sin(now*14+f.position.x)*.05*th;
  t.peri.rotation.y=Math.sin(now*.9+t.x)*1.6;
  tankFx(t,dt,now,th,{ex:[[.9,1.3,-3.8],[-.9,1.3,-3.8]],dk:[[1.7,.2,-3.6],[-1.7,.2,-3.6]],mz:6.2,rr:1.1,rc:.9});
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);smokeQ(t,dt,1.6,.85,1);
}

/* ---------- T-14 Armata (Russia): torre nao tripulada, radares do APS Afghanit, blindagem reativa e canhao 2A82 de 125 mm ---------- */
function makeArmata(color,fc){
  const{dark,lamp,brkM,flagM,flashM,gl}=mm(fc),mat=mat0(color||0x5b6b3a,plT),led=new THREE.MeshBasicMaterial({color:0x35e0ff}),g=new THREE.Group(),wheels=[],GX=1.62,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,ER=0x3f4430;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-3.1,.1],[3,.1],[3.7,.5],[3.5,.95],[3,1.08],[-2.9,1.08],[-3.65,.95],[-3.7,.5]],90,.66,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,gSL,sx,.55,-3.15,.52,s,wheels);wl(g,gWL,sx,.5,3.3,.46,s,wheels);for(let i=0;i<7;i++)wl(g,gWL,sx,.5,-2.55+i*.88,.46,s,wheels).userData.b=1;for(let k=0;k<4;k++)wl(g,gRL,sx,1.02,-2.2+k*1.3,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb(),fp=[];
  H.b(2.7,.7,7,'M',0,.82,0);H.b(2.5,.2,6.8,DK,0,.45,0);H.b(3.3,.3,4.8,'M',0,1.3,-.7);H.b(3,.14,2.4,'M',0,1.16,3.05,.38);H.b(2.8,.5,.14,'M',0,.72,3.95,-.2);
  H.b(2.7,.12,2.2,'M',0,1.5,-2.6);H.b(2.7,.7,.1,'M',0,1.1,-3.55,.15);
  for(let k=0;k<8;k++)H.b(2.2,.04,.07,MT,0,1.57,-3.3+k*.2);
  for(let r=0;r<4;r++)for(let i=-2;i<=2;i++)H.b(.55,.09,.45,ER,i*.58,1.16-(2.35+r*.55-3.05)*.4+.09,2.35+r*.55,.38);
  H.c(.36,.38,.12,MT,0,1.52,2.2,'y');H.b(.5,.07,.07,GL,0,1.6,2.5);H.b(.18,.14,.1,GL,-.7,1.55,2.55);H.b(.18,.14,.1,GL,.7,1.55,2.55);
  H.b(1.2,.12,.7,DK,0,1.57,-1.2);H.b(.5,.3,.5,MT,-.9,1.62,-1.4);
  for(const s of[-1,1]){for(let k=0;k<6;k++){H.b(.18,.8,.9,'M',s*1.95,.95,-2.6+k*.98);H.b(.2,.06,.9,MT,s*1.95,1.37,-2.6+k*.98);H.b(.08,.5,.8,ER,s*2.07,1.0,-2.6+k*.98)}
    H.b(.9,.08,1.2,'M',s*1.8,1.45,3.1,.2);H.c(.14,.14,.4,DK,s*.9,1.3,-3.7,'z');H.c(.04,.04,2.6,DK,s*1.8,1.05,-.4,'z');H.b(.3,.2,.5,MT,s*1.4,1.48,-1,0);H.b(.5,.28,.7,DK,s*1.2,1.35,-3.1);
    hull.add(bx(.3,.18,.1,lamp,s*1.2,1.5,3.9),bx(.3,.2,.08,brkM,s*1,.95,-3.58),bx(.05,.04,5,led,s*2.03,1.4,-.1));
    const f=new THREE.Group();f.position.set(s*1.8,1.4,3.75);f.add(bx(.05,.7,.9,dark,0,-.35,0));hull.add(f);fp.push(f)}
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.2,1.55,-3,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.5,.25);
  T.b(2.7,.5,3.4,'M',0,.4,.1);T.b(2.3,.3,3,'M',0,.72,.05);T.b(2.4,.4,.8,'M',0,.45,1.6,-.45);T.b(2.8,.55,1.3,'M',0,.45,-2.1);T.b(2.6,.1,1.2,'M',0,.8,-2.1,-.1);T.b(2.5,.35,.2,'M',0,.5,-2.8,.3);
  for(const s of[-1,1]){T.b(.5,.45,3,'M',s*1.3,.5,0,0,0,s*.5);for(let k=0;k<8;k++)T.c(.05,.05,.26,DK,s*1.38,.9,-.9-k*.14,'y',0,0,-s*.4)}
  for(let i=-2;i<=2;i++)T.b(.5,.08,.42,ER,i*.52,.92,1.05);
  T.c(.3,.34,.12,MT,-.6,.94,-.35,'y');T.c(.42,.42,.1,MT,.6,.92,-.5,'y');T.b(.4,.25,.35,DK,.45,.98,.7);T.b(.25,.1,.04,GL,.45,1,.88);T.b(2.4,.05,.05,MT,0,.35,-2.75);
  T.out(tg,mat);
  const aps=[],sens=new THREE.Group();sens.position.set(-.6,1.04,-.35);sens.add(bx(.36,.28,.36,dark,0,.14,0),bx(.2,.1,.04,gl,0,.16,.2));tg.add(sens);
  for(const s of[-1,1]){
    const pf=bx(.75,.48,.06,gl,s*1.32,.66,1.35),pr=bx(.75,.48,.06,gl,s*1.4,.66,-1.5);pf.rotation.y=s*.78;pr.rotation.y=s*2.36;tg.add(pf,pr,bx(.04,.05,3.4,led,s*1.5,.38,0));
    const ap=new THREE.Group(),A=mb();ap.position.set(s*1.1,.8,1.1);for(let k=0;k<3;k++)A.c(.07,.07,.5,MT,(k-1)*.17,.25,0);A.b(.6,.1,.22,DK,0,0,0);A.out(ap,mat);ap.rotation.z=s*1.4;tg.add(ap);aps.push(ap)}
  const lid=[new THREE.Group(),new THREE.Group()],crew=new THREE.Group();crew.userData.by=0;crew.visible=false;tg.add(crew);
  const cmg=mkMG(tg,.75,.98,-.95);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,2.1);
  B.b(1.2,.65,.55,'M',0,0,.1);B.c(.26,.3,.35,RB,0,0,.5,'z');B.c(.04,.04,.9,DK,.42,-.05,.7,'z');B.b(.3,.2,.06,GL,-.4,.2,.4);B.out(bp,mat);
  K.c(.12,.12,5.9,DK,0,0,3.4,'z');K.c(.18,.18,2.2,'M',0,0,2.1,'z');for(let k=0;k<4;k++)K.c(.19,.19,.06,DK,0,0,1.3+k*.55,'z');
  K.c(.2,.2,.45,'M',0,0,3.9,'z');K.c(.14,.14,.2,DK,0,0,6.2,'z');K.out(bar,mat);
  const fl=mkFl(bar,6.3,.5,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,fp,sens,aps,led,gl,lid,crew,cmg,fl,brkM,wheels,trk,mat,dark,arm14:true,cannon:true,spd:1.25,trn:.95,L:3.8,W:1.9,mz:6.1,fk:1.5,rld:2.2,wd:2.2,armor:.5,TY:1.5,apu:0}));
}
function animArmata(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/14,0,1),d=trkStep(t,dt,1.62);
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*11+i*1.7)*.02*th});
  t.hull.position.y=Math.sin(now*32+t.x)*(.008+.01*th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.02;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  for(const f of t.fp)f.rotation.x=clamp(-t.v*.03,-.5,.5)+Math.sin(now*14+f.position.x)*.05*th;
  /* sensor panoramico gira; radares do APS pulsam; lancadores do APS levantam quando ha alvo perto e disparam contramedida */
  t.sens.rotation.y+=dt*2.2;t.gl.emissiveIntensity=.7+.5*Math.sin(now*3.4);t.led.color.setHSL(.5,1,.38+.2*Math.sin(now*4+t.x*.1));
  t.apu+=((t.mgt||t.recoil>0?1:0)-t.apu)*Math.min(1,dt*4);t.aps[0].rotation.z=1.4*(1-t.apu);t.aps[1].rotation.z=-1.4*(1-t.apu);
  if(t.mgt&&t.apu>.8&&Math.random()<dt*.6){const a=t.aps[Math.random()<.5?0:1];a.localToWorld(v2.set(0,.6,0));puff(v2,0xffe08a,.9,3,.25,2);puff(v2,0xcfc8b8,.7,2,.6,1.5)}
  tankFx(t,dt,now,th,{ex:[[.9,1.3,-3.8],[-.9,1.3,-3.8]],dk:[[1.7,.2,-3.6],[-1.7,.2,-3.6]],mz:6.2,rr:1.1,rc:.9});
  mgScan(t,dt,60);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);smokeQ(t,dt,1.6,.85,1);
}

/* ---------- PL-01 (Polonia): conceito furtivo facetado, torre recuada, autoloader e camuflagem adaptativa ---------- */
function makePL(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x59614e,plT),led=new THREE.MeshBasicMaterial({color:0x35e0ff}),g=new THREE.Group(),GX=1.55,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a;
  g.rotation.order='YXZ';
  const sideT=treadTex(true),topT=treadTex(false);sideT.repeat.set(8,1);topT.repeat.set(1,8);
  const sM=new THREE.MeshLambertMaterial({map:sideT}),tM=new THREE.MeshLambertMaterial({map:topT}),trk=[sM,sM,tM,dark,dark,dark];
  for(const s of[-1,1])g.add(new THREE.Mesh(new THREE.BoxGeometry(.75,.9,6.6),trk).translateX(s*GX).translateY(.52));
  const hull=new THREE.Group(),H=mb();
  H.b(3.1,.6,6.2,'M',0,1,0);H.b(2.8,.2,6,DK,0,.62,0);H.b(2.9,.12,3.1,'M',0,1.0,2,.25);H.b(2.7,.12,.9,'M',0,.6,3.4,-.9);H.b(2.6,.1,3,'M',0,1.38,-1.8);H.b(2.8,.6,.1,'M',0,1.05,-3.15,.25);
  for(let k=0;k<8;k++)H.b(1.8,.03,.08,DK,0,1.45,-3+k*.2);
  H.b(.7,.1,.7,'M',0,1.3,2.3,.25);H.b(.5,.06,.05,GL,0,1.36,2.65);H.b(1.2,.1,1.2,'M',0,1.15,1.1);
  for(const s of[-1,1]){H.b(.1,.7,6.6,'M',s*1.9,.62,0,0,0,s*.15);H.b(.1,.7,6.6,'M',s*1.78,1.15,0,0,0,s*.55);H.b(.5,.1,1,'M',s*1.5,1.4,3,.3);H.b(.9,.06,.2,DK,s*.7,1.4,-3.2);
    hull.add(bx(.3,.2,.1,lamp,s*1.3,1.0,3.4),bx(.3,.2,.08,brkM,s*1.1,1,-3.2),bx(.05,.05,5.8,led,s*1.95,.98,0))}
  hull.add(bx(2.2,.04,.04,led,0,.78,3.7));
  for(const[x,z]of[[-1.3,2.6],[1.3,2.6],[-1.3,-2.8],[1.3,-2.8]])hull.add(bx(.2,.2,.2,dark,x,1.45,z),bx(.1,.1,.04,gl,x,1.45,z+(z>0?.12:-.12)));
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1,1.4,-3,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.4,-1.1);
  T.b(2.4,.5,2.6,'M',0,.35,0);T.b(1.7,.12,2.4,'M',0,.72,0);T.b(2.2,.12,1.1,'M',0,.5,1.6,.45);T.b(2.3,.7,1.4,'M',0,.4,-1.85);T.b(1.5,.1,1.3,'M',0,.8,-1.85);
  for(const s of[-1,1]){T.b(.7,.1,2.5,'M',s*1.05,.55,0,0,0,-s*.6);T.b(.05,.2,.8,DK,s*1.2,.4,-.2);T.b(.7,.5,.12,'M',s*.7,.5,-2.6,0,s*.5)}
  T.b(.4,.25,.5,DK,-.5,.95,.8);T.b(.3,.12,.04,GL,-.5,.97,1.06);
  T.out(tg,mat);
  const peri=new THREE.Group();peri.position.set(.55,.8,.1);peri.add(bx(.3,.25,.35,dark,0,.12,0),bx(.22,.12,.04,gl,0,.14,.19));tg.add(peri);
  const ld=new THREE.Group();ld.position.set(0,.86,-1.2);ld.add(bx(1.4,.05,1,mat,0,0,-.5));tg.add(ld);
  const cl=mkLid(tg,mat,.55,.82,-.55,.28),ll=mkLid(tg,mat,-.55,.82,-.45,.26),crew=mkCrew(tg,cm,hm,sk,.55,.55,-.55),cmg=mkMG(tg,-.1,.82,-.9);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,1.95);
  B.b(.9,.55,.4,'M',0,0,.1,.1);B.b(.3,.2,.06,GL,-.35,.12,.34);B.out(bp,mat);
  K.c(.14,.14,5.4,DK,0,0,3.1,'z');K.c(.2,.2,2.6,'M',0,0,1.9,'z');K.c(.17,.17,.3,DK,0,0,5.7,'z');for(let k=0;k<3;k++)K.c(.21,.21,.06,DK,0,0,1+k*.7,'z');K.out(bar,mat);
  const fl=mkFl(bar,5.8,.5,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,peri,ld,led,lid:[cl,ll],crew,cmg,fl,brkM,wheels:[],sideT,topT,mat,dark,pl01:true,cannon:true,spd:1.35,trn:1,L:3.4,W:2.1,mz:5.9,fk:1.25,rld:2,wd:1.9,armor:.75,TY:1.4}));
}
function animPL(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead){t.led.color.set(0x220000);return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/15,0,1),ph=t.v*dt;t.phase+=ph;t.sideT.offset.x=t.phase/.75;t.topT.offset.y=t.phase/.75;
  plT.offset.set((now*.04)%1,(now*.02)%1);t.led.color.setHSL(.5+.04*Math.sin(now*3+t.x),1,.45+.15*Math.sin(now*5+t.z));
  const ac=(t.v-t.pv)/Math.max(dt,.001);t.pt=(t.pt||0)+(clamp(-ac*.003,-.045,.045)-(t.pt||0))*Math.min(1,dt*5);t.rl=(t.rl||0)+(clamp((t.st||0)*t.v*.0014,-.035,.035)-(t.rl||0))*Math.min(1,dt*4);t.hull.position.y=Math.sin(now*34+t.x)*(.006+.01*th)-t.recoil*.03;t.hull.rotation.x=t.pt-t.recoil*.02;t.hull.rotation.z=t.rl;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  t.peri.rotation.y=Math.sin(now*.7+t.z)*1.8;
  t.ld.rotation.x+=((t.clk-t.lf<.7?1.1:0)-t.ld.rotation.x)*Math.min(1,dt*8);
  tankFx(t,dt,now,th*.4,{ex:[[.8,1.3,-3.3],[-.8,1.3,-3.3]],dk:[[1.6,.2,-3.2],[-1.6,.2,-3.2]],mz:5.9,rr:1.3,rc:.8});
  mgScan(t,dt,60);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);smokeQ(t,dt,1.1,.5,1.4);
}

/* ---------- Strv 103 (Suecia), Jagdpanther e Hetzer (Alemanha): cacadores de casamata ---------- */
const camT=cs=>{const t=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);for(let i=0;i<26;i++){x.fillStyle=cs[i%cs.length];x.beginPath();x.ellipse(Math.random()*w,Math.random()*h,8+Math.random()*22,4+Math.random()*10,Math.random()*3,0,7);x.fill()}});t.wrapS=t.wrapT=THREE.RepeatWrapping;return t};
const sdT=camT(['#9a9a78','#6a5a3c','#3a3c30']),jpT=camT(['#7e8f58','#9a7248','#6c6c46']),hzT=camT(['#8e9e60','#a8905a','#767c52']),D0=0x2b2d28,M0=0x4a4b42,G0=0x1d2f3a,R0=0x1b1b1a;
const skirts=(H,hb,mat,s,x,y,n,L,h,z0,st)=>{const q=new THREE.Group(),S=mb();q.position.set(s*x,y,0);for(let k=0;k<n;k++)S.b(.05,h,L,'M',0,-h/2-.05,z0+k*st);S.out(q,mat);hb.add(q);return q};
const CS={col:0x6a7e4c,tex:sdT,gx:1.6,py:.75,n:86,
 pts:[[-3.2,.12],[3,.12],[3.6,.6],[3.35,1.05],[2.9,1.12],[-2.9,1.12],[-3.6,.95],[-3.7,.55]],
 wh:[[3.1,.6,.55,gSL],[-3.2,.5,.46,gWL],...[0,1,2,3,4,5].map(i=>[-2.3+i*.93,.5,.46,gWL,0,1]),...[0,1,2].map(k=>[-1.8+k*1.6,1.02,.16,gRL])],
 hull:(H,hb,o)=>{const{lamp,brkM,glow,fab,mat}=o,sk=[];
  H.b(2.9,.8,5.8,'M',0,.95,-.5);H.b(2.9,.12,1.7,'M',0,1.1,2.95,.4);H.b(2.9,.5,.12,'M',0,.58,3.65,-.3);H.b(2.7,.12,5.4,'M',0,1.42,-.6);H.b(2.4,.1,1.5,'M',0,1.52,-2.6);
  for(let k=0;k<8;k++)H.b(2.1,.04,.07,M0,0,1.58,-3.2+k*.18);
  for(const s of[-1,1]){H.b(.5,.08,6.4,'M',s*1.7,1.22,-.3);H.c(.1,.1,.5,D0,s*.9,1.55,-3.5,'y');H.b(.3,.2,.5,M0,s*1.5,1.3,1.2);
   for(let j=0;j<3;j++)H.c(.05,.05,.2,D0,s*1.2,1.5,2+j*.12,'y');
   hb.add(bx(.3,.18,.1,lamp,s*1.2,.95,3.62),bx(.3,.2,.08,brkM,s*1,1.1,-3.12));sk.push(skirts(H,hb,mat,s,2,1.2,5,1.1,.6,-2.4,1.2))}
  hb.add(bx(.3,.3,.06,glow,-.9,1.4,-3.45));
  const dz=new THREE.Group();dz.position.set(0,.7,3.7);dz.add(bx(3.4,.1,1.5,mat,0,0,.75),bx(3.4,.22,.1,mat,0,0,1.5),bx(.2,.1,1.3,mat,-1.2,.1,.75),bx(.2,.1,1.3,mat,1.2,.1,.75));dz.rotation.x=-2.5;hb.add(dz);
  const scr=new THREE.Group();scr.position.y=1.45;for(const[w,d,x,z]of[[.08,5.2,-1.45,-.6],[.08,5.2,1.45,-.6],[3,.08,0,2],[3,.08,0,-3.2]])scr.add(bx(w,1.1,d,fab,x,.55,z));scr.scale.y=.12;hb.add(scr);
  const ej=new THREE.Group();ej.position.set(0,.9,-3.45);ej.add(bx(.9,.7,.06,mat,0,.35,0));hb.add(ej);
  return{sk,dz,scr,ej}},
 cup:[.85,1.58,-.9,.4],drv:[-.8,1.52,1.3,.3],mg:[.85,1.95,-.7],pe:[.35,1.5,-.2],ant:[-1.1,1.45,-3],tg:[0,1.5,.5],bp:[0,.42,1],mz:5.8,fr:.5,
 tgc:T=>{T.b(1.3,.55,1.5,'M',0,.28,0);T.b(1.1,.4,.8,'M',0,.3,.9,.5);T.b(1,.1,1.2,'M',0,.6,-.1);T.c(.8,.85,.2,'M',0,0,0,'y');T.b(.3,.3,.4,0xfff2b0,.75,.5,.9)},
 gun:(B,K)=>{B.b(.9,.6,.5,'M',0,0,.1);B.c(.3,.36,.4,R0,0,0,.5,'z');K.c(.11,.11,5.4,D0,0,0,3.2,'z');K.c(.17,.19,1.9,'M',0,0,1.5,'z');K.c(.18,.18,.7,D0,0,0,3.4,'z');for(let k=0;k<3;k++)K.c(.2,.2,.06,D0,0,0,3.15+k*.25,'z');K.c(.14,.14,.2,D0,0,0,5.9,'z')},
 fx:{ex:[[.9,1.4,-3.6],[-.9,1.4,-3.6]],dk:[[1.75,.2,-3.8],[-1.75,.2,-3.8]],mz:5.8,rr:1.1,rc:.9},
 p:{stk:true,spd:1.2,trn:.9,L:3.8,W:1.9,mz:5.8,fk:1.25,rld:2.2,wd:2.6,armor:.7,TY:1.5,lim:.05}};
const CJ={col:0xb5a468,tex:jpT,gx:1.55,py:.9,n:96,
 pts:[[-3.4,.2],[3.1,.2],[3.65,.65],[3.5,1.05],[3.1,1.2],[-3,1.2],[-3.7,1],[-3.75,.55]],
 wh:[[3.25,.62,.52,gSL],[-3.35,.58,.5,gWL],...[0,1,2,3,4,5,6,7].map(i=>[-2.7+i*.82,.5,.46,gWL,i%2?.12:-.12,1])],
 hull:(H,hb,o)=>{const{lamp,brkM,glow,mat}=o,sk=[];
  H.b(3.1,.7,6.4,'M',0,.85,-.4);H.b(3.1,.4,.5,'M',0,.65,3.3);H.b(3.1,.14,2.1,'M',0,1.4,2.75,.61);H.b(2.8,.14,3.6,'M',0,2.05,-.3);H.b(2.7,1,.12,'M',0,1.6,-2.2,.2);H.b(3,.14,2.2,'M',0,1.26,-2.9);
  for(let k=0;k<9;k++)H.b(2.4,.04,.08,M0,0,1.35,-2.1-k*.2);
  H.c(.14,.14,.2,D0,-.9,1.7,2.35,'z');
  for(const s of[-1,1]){H.b(.12,1.1,4.8,'M',s*1.4,1.55,-.5,0,0,s*.22);H.c(.1,.12,.8,D0,s*1,1.5,-3.9,'z');H.b(.08,.08,2.6,D0,s*1.6,1.35,-2.4);H.b(.1,.1,.8,M0,s*1.45,1.35,.4);
   hb.add(bx(.2,.2,.2,lamp,s*1,1.2,3.3),bx(.3,.2,.08,brkM,s*1.1,1.1,-3.45),bx(.12,.12,.12,glow,s*1,1.5,-4.32));sk.push(skirts(H,hb,mat,s,2,1.3,6,.95,.7,-2.7,1.05))}
  return{sk}},
 cup:[.9,2.15,-1.1,.38],drv:[-.8,2.1,-.7,.3],mg:[-.8,2.3,-.4],pe:[.4,2.15,-.1],ant:[1.25,2.1,-2],tg:[.25,1.55,1.9],bp:[0,0,.5],mz:6.5,fr:.55,
 tgc:T=>{T.b(.9,.9,.5,'M',0,0,.2)},
 gun:(B,K)=>{B.c(.5,.62,.6,'M',0,0,.3,'z');B.b(1,.8,.3,'M',0,-.05,.1);B.c(.05,.05,.6,D0,.38,.05,.6,'z');K.c(.1,.1,6,D0,0,0,3.6,'z');K.c(.14,.15,2.2,'M',0,0,1.8,'z');K.b(.34,.34,.5,D0,0,0,6.55);for(let k=0;k<3;k++)K.b(.36,.05,.06,M0,0,0,6.4+k*.14)},
 fx:{ex:[[1,1.5,-4.4],[-1,1.5,-4.4]],dk:[[1.7,.2,-3.9],[-1.7,.2,-3.9]],mz:6.5,rr:1,rc:1},
 p:{jp:true,spd:1.05,trn:.8,L:3.9,W:2.1,mz:6.5,fk:1.5,rld:2.6,wd:2,armor:.62,TY:1.55,lim:.3}};
const CH={col:0xa9a066,tex:hzT,gx:1.2,py:.65,n:70,
 pts:[[-2.4,.1],[2.1,.1],[2.6,.5],[2.4,.9],[2,1],[-2,1],[-2.6,.85],[-2.7,.5]],
 wh:[[2.3,.52,.46,gSL],[-2.4,.47,.42,gWL],...[0,1,2,3].map(i=>[-1.35+i*.9,.5,.46,gWL,0,1]),[-.7,.98,.16,gRL],[.7,.98,.16,gRL]],
 hull:(H,hb,o)=>{const{lamp,brkM,glow,mat}=o,sk=[];
  H.b(2.2,.55,4.6,'M',0,.78,-.2);H.b(2.2,.12,1.5,'M',0,1.15,1.95,.63);H.b(2.2,.3,.5,'M',0,.65,2.55,-.4);H.b(1.9,.1,3,'M',0,1.68,.05);H.b(2,.8,.1,'M',0,1.25,-1.55,.12);H.b(2.2,.1,1.5,'M',0,1.08,-1.9);H.c(.1,.1,.6,D0,-.7,1.1,-2.7,'z');
  hb.add(bx(.12,.12,.1,glow,-.7,1.1,-3.02));
  for(const s of[-1,1]){H.b(.1,.8,2.9,'M',s*.95,1.3,-.1,0,0,s*.25);hb.add(bx(.2,.2,.2,lamp,s*.8,.9,2.5),bx(.3,.2,.08,brkM,s*.8,.9,-2.6));sk.push(skirts(H,hb,mat,s,1.45,1.1,4,1.05,.55,-1.6,1.1))}
  return{sk}},
 cup:[-.5,1.73,-.8,.32],drv:[.5,1.73,.1,.27],mg:[-.45,1.85,.6],pe:[.5,1.75,-.9],ant:[.85,1.7,-2.1],tg:[.3,1.1,1.5],bp:[0,0,.45],mz:4.3,fr:.4,
 tgc:T=>{T.b(.5,.5,.4,'M',0,0,.1)},
 gun:(B,K)=>{B.c(.28,.34,.4,'M',0,0,.2,'z');B.c(.3,.34,.1,R0,0,0,.45,'z');K.c(.07,.07,3.9,D0,0,0,2.2,'z');K.c(.11,.12,1.2,'M',0,0,1,'z');K.b(.24,.24,.4,D0,0,0,4.3);K.b(.26,.04,.05,M0,0,0,4.2)},
 fx:{ex:[[-.7,1.1,-3.1],[.7,1.1,-3.1]],dk:[[1.3,.2,-2.6],[-1.3,.2,-2.6]],mz:4.3,rr:1.3,rc:.6},
 p:{hz:true,spd:1.35,trn:1.15,L:2.7,W:1.6,mz:4.3,fk:1.05,rld:1.7,wd:1.7,armor:.8,TY:1.1,lim:.2}};
function buildTD(c,color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||c.col,c.tex),g=new THREE.Group(),wheels=[],GX=c.gx,glow=new THREE.MeshBasicMaterial({color:0xff7a20}),fab=new THREE.MeshLambertMaterial({color:0x56603e});
  g.rotation.order='YXZ';const trk=trackLoop(c.pts,c.n,.66,[-GX,GX]);g.add(trk);
  [[0,-1],[1,1]].forEach(([s,q])=>{for(const w of c.wh){const m=wl(g,w[3],q*GX+(w[4]||0),w[1],w[0],w[2],s,wheels);m.userData.y0=w[1];if(w[5])m.userData.b=1}});
  const hull=new THREE.Group(),hb=new THREE.Group(),H=mb(),T=mb(),B=mb(),K=mb();hull.position.y=c.py;hb.position.y=-c.py;hull.add(hb);
  const x=c.hull(H,hb,{lamp,brkM,glow,fab,mat}),[cx,cy,cz,cr]=c.cup,[dx,dy,dz,dr]=c.drv;
  H.c(cr,cr*1.1,.3,'M',cx,cy,cz,'y');H.c(dr+.04,dr+.04,.1,'M',dx,dy,dz,'y');
  for(let k=0;k<6;k++){const a=k/6*6.283;H.b(.12,.08,.05,G0,cx+Math.sin(a)*cr*1.02,cy+.1,cz+Math.cos(a)*cr*1.02,0,a)}
  H.out(hb,mat);g.add(hull);
  const ant=mkAnt(hb,...c.ant,flagM),peri=new THREE.Group();peri.position.set(...c.pe);peri.add(bx(.22,.22,.3,dark,0,.12,0),bx(.16,.1,.04,gl,0,.14,.17));hb.add(peri);
  const cl=mkLid(hb,mat,cx,cy+.15,cz,cr*.75),ll=mkLid(hb,mat,dx,dy+.06,dz,dr),crew=mkCrew(hb,cm,hm,sk,cx,cy-.6,cz),cmg=mkMG(hb,...c.mg);
  const tg=new THREE.Group(),bp=new THREE.Group(),bar=new THREE.Group();tg.position.set(...c.tg);bp.position.set(...c.bp);
  c.tgc(T);T.out(tg,mat);c.gun(B,K);B.out(bp,mat);K.out(bar,mat);
  const fl=mkFl(bar,c.mz+.2,c.fr,flashM);bp.add(bar);tg.add(bp);hb.add(tg);
  return fin(base(Object.assign({g,tg,bp,bar,hull,ant,peri,lid:[cl,ll],crew,cmg,fl,brkM,wheels,trk,mat,dark,glow,td:true,cannon:true,gx:GX,py:c.py,fx:c.fx,sk:[],tk:0,bl:0,sc:.12},c.p,x)));
}
const makeStrv=(c,f)=>buildTD(CS,c,f),makeJag=(c,f)=>buildTD(CJ,c,f),makeHetzer=(c,f)=>buildTD(CH,c,f);
function animTD(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead){t.glow.color.set(0x220000);return blowOff(t,dt,t.TY)}
  const r=angDiff(t.yaw,t.hd),e=Math.abs(r)-t.lim;if(e>0)t.hd+=Math.sign(r)*Math.min(e,t.trn*1.1*dt); /* casamata: o casco gira para acompanhar a mira */
  const th=clamp(Math.abs(t.v)/14,0,1),d=trkStep(t,dt,t.gx),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),u=t.clk-t.lf;
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=w.userData.y0+Math.sin(now*10+i*1.7)*.02*th});
  if(t.stk){const k=clamp(t.pitch,-.14,.17);t.tk+=(k-t.tk)*Math.min(1,dt*5);t.hull.rotation.x=-t.tk*Math.cos(r)-ac*.004-t.recoil*.03;t.hull.rotation.z=t.tk*Math.sin(r)} /* suspensao hidropneumatica inclina o casco para elevar o canhao */
  else t.hull.rotation.x=-ac*.003-t.recoil*.02;
  t.hull.position.y=t.py+Math.sin(now*32+t.x)*(.008+.01*th)-t.recoil*.03;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.peri.rotation.y=Math.sin(now*.9+t.x)*1.6;
  t.sk.forEach((q,i)=>q.rotation.z=Math.sin(now*9+i*2+t.x)*.025*(.3+th)*(i?-1:1));
  t.glow.color.setHSL(.07,1,.3+.25*th+.08*Math.sin(now*22));
  if(t.dz){const st=Math.abs(t.v)<.8&&u>.4?1:0;t.bl+=(st-t.bl)*Math.min(1,dt*1.6);t.dz.rotation.x=-2.5+t.bl*2.9; /* lamina de escavacao desce quando parado */
    t.sc+=((t.wet>.45?1:.12)-t.sc)*Math.min(1,dt*1.2);t.scr.scale.y=t.sc; /* tela de flutuacao sobe na agua */
    t.ej.rotation.x=-1.2*(u<.6?Math.sin(clamp(u/.6,0,1)*Math.PI):0); /* escotilha traseira ejeta o estojo */
    if(u<.12){if(!t.ejd){t.ejd=1;t.g.localToWorld(v2.set(0,1.1,-4));puff(v2,0xcfc8b8,.7,2,.7,.5);puff(v2,0xffb347,.4,3,.2,0)}}else t.ejd=0}
  tankFx(t,dt,now,th,t.fx);mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.hd,.8,[0,.1,1.45],now);smokeQ(t,dt,1.2,.8,1);
}

/* ---------- Challenger 2 (Reino Unido): blindagem Chobham angular, canhao raiado L30A1 com luva termica ---------- */
const chT=camT(['#8a8f6a','#4a4636','#6b6a50']);
function makeCh2(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x5f6a45,chT),g=new THREE.Group(),wheels=[],GX=1.65,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-3.1,.1],[3,.1],[3.7,.5],[3.5,.95],[3,1.08],[-2.9,1.08],[-3.65,.95],[-3.7,.5]],90,.66,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,gSL,sx,.55,-3.15,.52,s,wheels);wl(g,gWL,sx,.5,3.3,.46,s,wheels);for(let i=0;i<6;i++)wl(g,gWL,sx,.5,-2.4+i*1.0,.46,s,wheels).userData.b=1;for(let k=0;k<3;k++)wl(g,gRL,sx,1.02,-2+k*1.7,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb(),fp=[];
  H.b(2.8,.7,7,'M',0,.82,0);H.b(2.5,.2,6.8,DK,0,.45,0);H.b(3.3,.3,5,'M',0,1.3,-.6);H.b(3,.16,2.4,'M',0,1.2,3.05,.45);H.b(2.8,.5,.14,'M',0,.72,3.95,-.2);H.b(2.8,.14,2.2,'M',0,1.5,-2.6);H.b(2.8,.8,.12,'M',0,1.1,-3.55,.12);
  for(let k=0;k<8;k++)H.b(2.2,.04,.07,MT,0,1.57,-3.3+k*.2);
  H.b(.5,.3,.6,'M',-.7,1.55,2.2,0.2);for(let k=0;k<3;k++)H.b(.14,.07,.07,GL,-.7+(k-1)*.18,1.7,2.5);
  for(const s of[-1,1]){H.b(.4,.8,5.4,'M',s*1.95,1.0,-.3);H.b(.42,.08,5.4,MT,s*1.95,1.43,-.3);H.b(.3,.7,1.3,'M',s*1.9,.95,3.1,0,s*.35);
    for(let k=0;k<4;k++)H.b(.04,.4,.02,RB,s*1.99,.45,-2.7+k*1.7);H.c(.14,.14,.4,DK,s*.9,1.3,-3.7,'z');H.b(.08,.08,2.6,DK,s*1.6,1.5,-.4);
    hull.add(bx(.3,.2,.1,lamp,s*1.2,1.5,3.9),bx(.3,.2,.08,brkM,s*1,.95,-3.58));
    const f=new THREE.Group();f.position.set(s*1.8,1.4,3.75);f.add(bx(.05,.7,.9,dark,0,-.35,0));hull.add(f);fp.push(f)}
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.2,1.55,-3,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.5,.2);
  T.b(2.6,.65,2.9,'M',0,.55,.1);T.b(2.4,.14,2.6,'M',0,.9,0);T.b(2.5,.7,1.1,'M',0,.5,1.7,.5);T.b(2.9,.9,1.7,'M',0,.5,-2.1);T.b(2.7,.5,.2,'M',0,.4,-2.95,.25);
  for(const s of[-1,1]){T.b(.6,.7,2.2,'M',s*1.3,.6,.7,0,s*.2);T.b(.3,.5,1.4,'M',s*1.45,.5,-1.9);
    for(let k=0;k<5;k++)T.c(.05,.05,.28,DK,s*(1.32-k*.02),.98,.9+k*.14,'y',0,0,-s*.5)}
  T.b(.5,.4,.5,DK,-.8,1,1.3);T.b(.3,.15,.04,GL,-.8,1.02,1.57);T.b(.4,.3,.4,DK,.9,1.0,.9);T.b(.3,.12,.04,GL,.9,1.02,1.12);
  T.c(.4,.44,.35,MT,.7,1,-.6,'y');T.b(1,.1,.6,'M',-.4,1,-1.6);T.b(.12,.5,.06,MT,.2,1.1,-.5);
  T.out(tg,mat);
  const peri=new THREE.Group();peri.position.set(.7,1.3,-.6);peri.add(bx(.22,.22,.3,dark,0,.12,0),bx(.16,.1,.04,gl,0,.14,.17));tg.add(peri);
  const cl=mkLid(tg,mat,.7,1.2,-.6,.3),ll=mkLid(tg,mat,-.6,1.02,-.9,.34),crew=mkCrew(tg,cm,hm,sk,.7,.7,-.6),cmg=mkMG(tg,-.6,1.05,-.6);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.55,2.2);
  B.b(1.4,.8,.5,'M',0,0,.1);B.c(.3,.36,.4,RB,0,0,.45,'z');B.b(.3,.2,.06,GL,-.5,.25,.35);B.out(bp,mat);
  K.c(.13,.13,5.8,DK,0,0,3.4,'z');K.c(.2,.2,3.3,'M',0,0,2.3,'z');for(let k=0;k<5;k++)K.c(.21,.21,.06,DK,0,0,1+k*.6,'z');
  K.c(.22,.22,.5,'M',0,0,4.3,'z');K.b(.08,.08,.16,MT,0,.17,6);K.c(.15,.15,.15,DK,0,0,6.35,'z');K.out(bar,mat);
  const fl=mkFl(bar,6.35,.55,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,peri,fp,lid:[cl,ll],crew,cmg,fl,brkM,wheels,trk,mat,dark,ch2:true,cannon:true,spd:1.2,trn:.9,L:3.8,W:1.9,mz:6.2,fk:1.6,rld:2.4,wd:2.4,armor:.55,TY:1.5}));
}
/* ======================================================================
   M4A3E8 Sherman "Easy Eight" (EUA): casco fundido, tampa do diferencial em cupula, suspensao HVSS,
   canhao de 76 mm com freio de boca, torre fundida torneada, metralhadoras de proa, coaxial e .50
   ====================================================================== */
const shT=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);for(let i=0;i<46;i++){x.fillStyle=i%2?'rgba(90,80,50,.22)':'rgba(120,110,80,.14)';x.beginPath();x.ellipse(Math.random()*w,Math.random()*h,5+Math.random()*20,3+Math.random()*9,Math.random()*3,0,7);x.fill()}for(let i=0;i<70;i++){x.fillStyle='rgba(60,45,30,.2)';x.fillRect(Math.random()*w,h*.65+Math.random()*h*.35,2+Math.random()*7,1+Math.random()*2)}});
const shW=tw(.4),shS=tw(.52,1),shI=tw(.46),shR=tw(.17);
const starT=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#efe9d4';x.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?24:54;x.lineTo(64+Math.cos(a)*r,64+Math.sin(a)*r)}x.closePath();x.fill();x.strokeStyle='#efe9d4';x.lineWidth=6;x.beginPath();x.arc(64,64,59,0,7);x.stroke()});
const shN=canvasTex(256,64,(x,w,h)=>{x.font='700 44px Arial,sans-serif';x.textAlign='center';x.textBaseline='middle';x.lineWidth=7;x.strokeStyle='#111';x.strokeText('EASY 8',w/2,h/2);x.fillStyle='#efe9d4';x.fillText('EASY 8',w/2,h/2)});
const shB=numTx('B-24');
function makeSherman(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x59623b,shT),g=new THREE.Group(),wheels=[],bogs=[],GX=1.5,SW=1.35,
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c,WD=0x6a5232,CV=0x76704f,SB=0x9c8d68,JC=0x56602f,TK=0x34352e,CB=0x56503f,RD=0xa8302a;
  g.rotation.order='YXZ';
  /* esteiras em laco com roda motriz na frente, roda guia atras e 3 bogies HVSS por lado */
  const trk=trackLoop([[-2.4,.1],[2,.1],[2.85,.5],[3,.95],[2.65,1.38],[2,1.45],[-2.1,1.45],[-3,1.2],[-3.35,.75],[-3.1,.3]],84,.6,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    wl(g,shS,sx,.98,2.5,.52,s,wheels);wl(g,shI,sx,.72,-2.85,.46,s,wheels);
    for(const z of[-1.9,-.25,1.4]){
      const bg=new THREE.Group();bg.position.set(sx,.45,z);
      wl(bg,shW,0,0,-.42,.4,s,wheels);wl(bg,shW,0,0,.42,.4,s,wheels);
      bg.add(bx(.16,.14,1.1,dark,0,.06,0),bx(.22,.22,.26,dark,0,.2,0),new THREE.Mesh(new THREE.CylinderGeometry(.17,.17,.7,10),dark).translateY(.58),bx(.4,.12,.4,dark,0,.95,0));
      g.add(bg);bogs.push(bg);
    }
    for(const z of[-1.1,.2,1.5])wl(g,shR,sx,1.28,z,.17,s,wheels);
  });
  /* casco */
  const hull=new THREE.Group(),H=mb(),sl=(u,o)=>[1.465-.655*u+.756*o,2.06+.756*u+.655*o];
  H.b(2.3,.95,5.7,'M',0,.97,-.15);H.b(2.1,.14,5.6,DK,0,.5,-.15);
  H.b(2.7,.5,2.5,'M',0,1.7,.25);H.b(2.6,.4,2.2,'M',0,1.65,-2.05);
  H.b(2.6,.14,1.48,'M',0,1.465,2.06,.714);H.b(2.5,1,.14,'M',0,1.15,-3.05,.12);
  /* tampa do diferencial: cupula de tres pecas aparafusada */
  H.g(new THREE.SphereGeometry(1,22,10,0,6.2832,0,1.5708).scale(1.28,.8,.5).rotateX(Math.PI/2),'M',0,.78,2.35);
  for(let k=0;k<18;k++){const a=k/18*6.2832;H.c(.05,.05,.08,MT,Math.cos(a)*1.2,.78+Math.sin(a)*.46,2.66,'z')}
  H.b(.3,.12,.2,MT,-.55,.5,3.05);H.b(.3,.12,.2,MT,.55,.5,3.05);
  /* convés do motor: grades, escotilha central, ventoinhas */
  for(let k=0;k<8;k++){H.b(.9,.03,.09,MT,-.62,1.87,-1.4-k*.2);H.b(.9,.03,.09,MT,.62,1.87,-1.4-k*.2)}
  H.b(.5,.04,.5,DK,0,1.87,-2.3);H.c(.28,.28,.04,DK,-.62,1.86,-3,'y');H.c(.28,.28,.04,DK,.62,1.86,-3,'y');
  /* escotilhas do motorista e do auxiliar, periscopios */
  for(const s of[-1,1]){H.c(.34,.37,.1,MT,s*.65,2,1.15,'y');H.b(.18,.14,.22,DK,s*.65,2.05,1.65);H.b(.12,.06,.04,GL,s*.65,2.06,1.77)}
  /* bola da metralhadora de proa, sacos de areia e esteiras sobressalentes */
  H.g(new THREE.SphereGeometry(.17,10,8),MT,.55,1.67,1.99);H.b(.42,.34,.16,'M',.55,1.7,1.88,.714);
  for(const u of[-.45,-.1,.25])for(const x of[-.95,-.5]){const[y,z]=sl(u,.12);H.g(new THREE.SphereGeometry(1,8,6).scale(.27,.11,.18).rotateX(.714),SB,x,y,z)}
  for(const u of[-.5,-.15,.2]){const[y,z]=sl(u,.07);H.b(.55,.05,.3,TK,1.05,y,z,.714)}
  /* paralamas, escapamentos e estiva */
  for(const s of[-1,1]){
    H.b(.45,.05,5.1,'M',s*1.8,1.58,-.2);H.b(.45,.05,.7,'M',s*1.8,1.5,2.75,.35);H.b(.45,.05,.6,'M',s*1.8,1.5,-2.95,-.3);H.b(.05,.16,5.1,'M',s*2.02,1.5,-.2);
    H.c(.2,.2,.9,DK,s*.9,1.25,-3.35,'z');H.c(.12,.12,.4,MT,s*.9,1.25,-3.85,'z');
    hull.add(bx(.28,.2,.2,lamp,s*1.78,1.7,2.72),bx(.3,.2,.08,brkM,s*1.1,1.1,-3.16));
  }
  H.b(.42,.34,.95,'M',-1.8,1.78,-1.9);H.b(.06,.1,.1,MT,-2.03,1.78,-1.9);H.c(.07,.07,.4,RD,-1.8,1.75,.9,'y');H.b(.1,.1,.9,MT,-1.85,1.66,.4);
  H.c(.05,.05,4.3,CB,1.85,1.66,-.5,'z');H.b(.14,.1,.14,MT,1.85,1.66,1.7);H.b(.14,.1,.14,MT,1.85,1.66,-2.7);
  H.b(.06,.03,1.1,WD,1.6,1.64,-1.9);H.b(.2,.03,.26,MT,1.6,1.64,-1.25);H.b(.05,.03,.9,WD,1.72,1.64,-2.3);
  H.c(.2,.2,2,CV,0,2,-2.85,'x');
  for(const x of[-.9,-.45,.45,.9])H.b(.36,.48,.18,JC,x,1.55,-3.24);
  H.b(.3,.22,.3,MT,0,.85,-3.2);H.c(.07,.07,.18,MT,0,.95,-3.27,'y');
  H.c(.1,.12,.2,MT,-1.1,1.95,-1,'y');
  H.out(hull,mat);g.add(hull);
  /* estrelas aliadas e numero tatico */
  for(const s of[-1,1]){stk(hull,starT,s*(SW+.008),1.7,.4,s,.9,.9);stk(hull,shB,s*(SW+.008),1.76,-.5,s,.8,.38)}
  {const[y,z]=sl(0,.04),m=new THREE.Mesh(new THREE.PlaneGeometry(.7,.7),new THREE.MeshBasicMaterial({map:starT,transparent:true}));m.position.set(.05,y,z);m.rotation.x=-.856;hull.add(m)}
  const ant=mkAnt(hull,-1.1,2.05,-1,flagM);
  const dl=[mkLid(hull,mat,-.65,2.08,1.15,.27),mkLid(hull,mat,.65,2.08,1.15,.27)],drvs=[mkCrew(hull,cm,hm,sk,-.65,1.2,1.15),mkCrew(hull,cm,hm,sk,.65,1.2,1.15)];
  const bmg=mkMG(hull,.55,1.67,2);bmg.scale.set(.7,.7,.55);
  /* torre fundida torneada (lathe) com popa em bustle, cupula do comandante e ventilador */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.95,.3);
  T.g(new THREE.LatheGeometry([[1,0],[1.08,.08],[1.1,.3],[1,.52],[.82,.68],[.5,.78],[.001,.82]].map(p=>new THREE.Vector2(p[0],p[1])),24).scale(1.22,1,1.35),'M',0,0,0);
  T.b(1.8,.5,.7,'M',0,.4,-1.55);T.b(1.7,.14,.5,'M',0,.68,-1.7,.3);T.b(1.6,.5,.14,'M',0,.4,-1.95,.2);
  T.c(.4,.44,.2,'M',.6,.85,-.55,'y');T.c(.46,.46,.06,MT,.6,.96,-.55,'y');
  for(let k=0;k<8;k++){const a=k/8*6.2832;T.b(.1,.06,.04,GL,.6+Math.sin(a)*.43,.93,-.55+Math.cos(a)*.43,0,a)}
  T.c(.3,.34,.1,MT,-.5,.76,-.7,'y');T.c(.22,.22,.12,MT,.15,.72,-1.05,'y');T.b(.28,.16,.26,DK,-.35,.88,.5);T.b(.2,.08,.04,GL,-.35,.9,.64);
  for(const s of[-1,1]){T.b(1,.55,.3,'M',s*.62,.42,1.25,0,s*.5);T.c(.07,.07,.05,MT,s*1.3,.4,-.2,'x');T.b(.04,.04,.45,MT,s*.8,.74,.15);T.b(.04,.04,.45,MT,s*.98,.66,-.7)}
  T.c(.18,.18,1.2,0x6f6a4a,0,.82,-1.95,'x');T.b(.5,.3,.3,0x4f5a34,-.6,.82,-1.95);T.c(.16,.16,.9,0x5d6b3a,.6,.78,-1.95,'x');
  T.out(tg,mat);
  {const sm=new THREE.Mesh(new THREE.PlaneGeometry(.7,.7),new THREE.MeshBasicMaterial({map:starT,transparent:true}));sm.rotation.x=-Math.PI/2;sm.position.set(0,.81,.45);tg.add(sm)}
  for(const s of[-1,1])stk(tg,shN,s*1.3,.42,-.1,s,.85,.22);
  const fan=new THREE.Group();fan.position.set(.15,.82,-1.05);
  for(let k=0;k<3;k++){const bg=new THREE.Group(),b=bx(.3,.02,.06,dark,.15,0,0);bg.rotation.y=k*Math.PI*2/3;bg.add(b);fan.add(bg)}tg.add(fan);
  const cl=mkLid(tg,mat,.6,1.02,-.55,.28),ll=mkLid(tg,mat,-.5,.84,-.7,.3),crew=mkCrew(tg,cm,hm,sk,.6,.5,-.55),crew2=mkCrew(tg,cm,hm,sk,-.5,.45,-.7),cmg=mkMG(tg,.6,1.06,-.55);
  /* mantelete, canhao M1A2 de 76 mm com luva e freio de boca de dois defletores */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.45,1.38);
  B.b(1.15,.76,.4,'M',0,0,.12);B.b(.9,.16,.3,'M',0,.42,.1);B.c(.3,.34,.34,RB,0,0,.4,'z');B.c(.045,.045,.55,DK,.4,-.15,.62,'z');B.b(.2,.2,.08,GL,-.42,.18,.34);B.out(bp,mat);
  K.c(.095,.09,4.3,DK,0,0,2.35,'z');K.c(.13,.12,1.1,'M',0,0,.75,'z');K.c(.15,.15,.24,DK,0,0,4.4,'z');K.c(.18,.18,.05,DK,0,0,4.32,'z');K.c(.18,.18,.05,DK,0,0,4.5,'z');K.b(.04,.22,.2,MT,0,0,4.41);K.out(bar,mat);
  const fl=mkFl(bar,4.6,.5,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,crew2,dl,drvs,cmg,bmg,fan,fl,brkM,wheels,bogs,trk,mat,dark,sher:true,cannon:true,spd:1.1,trn:1,L:3.3,W:1.9,mz:4.55,fk:1,rld:2,wd:1.4,armor:.82,hp:105,TY:1.95}));
}
function animSher(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.drvs.forEach(q=>q.visible=false);t.crew2.visible=false;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.dl[0].rotation.x=-1.5;t.dl[1].rotation.x=-1.5;
    if(t.ck===undefined)t.ck=6;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;
      if(t.ckt<=0){t.ckt=.1+Math.random()*.12;const h=Math.random()<.5?[.6,1.1,-.55]:[-.5,.95,-.7];t.tg.localToWorld(v2.set(h[0],h[1],h[2]));
        puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.1,5,.55,9);puff(v2,0x1f1e1c,1.6,3,1.6,5);
        if(Math.random()<.25){puff(v2,0xff6a20,2.4,8,.4,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY);
  }
  const th=clamp(Math.abs(t.v)/12,0,1),d=trkStep(t,dt,1.5),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  for(const w of t.wheels)w.rotation.x+=d[w.userData.s]/w.userData.r;
  t.bogs.forEach((b,i)=>b.rotation.x=Math.sin(now*9+i*1.9)*.04*th+ac*.002);
  t.hull.position.y=Math.sin(now*34+t.x)*(.007+.012*th)-t.recoil*.03;t.hull.rotation.x=-ac*.003-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.02;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.ant.rotation.z=Math.sin(now*2.2+t.x)*.02;
  t.fan.rotation.y+=dt*(10+th*14);
  tankFx(t,dt,now,th,{ex:[[.9,1.25,-4],[-.9,1.25,-4]],dk:[[1.5,.2,-3.5],[-1.5,.2,-3.5],[1.5,.2,3.1],[-1.5,.2,3.1]],mz:4.5,rr:1.3,rc:.75});
  /* motorista e auxiliar abrem as escotilhas quando parado; o municiador espia pela torre */
  t.dl[0].rotation.x=-t.open*1.5;t.dl[1].rotation.x=-t.open*1.4;
  t.drvs.forEach((q,i)=>{q.visible=t.open>.3&&(i?t.open>.6:true);q.position.y=q.userData.by+Math.min(1,t.open)*.5;q.rotation.y=Math.sin(now*.7+i*2+t.z)*.5});
  t.crew2.visible=t.open>.55;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  /* .50 do comandante e .30 de proa (arco curto) miram sozinhas */
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);
  mgAim(t,dt,t.bmg,t.hd,.5,[0,.1,1.2],now);t.bmg.rotation.y=clamp(t.bmg.rotation.y,-.35,.35);
}
/* ======================================================================
   Panzerkampfwagen VIII Maus (Alemanha): 188 t, casco gigante com saias, torre fundida com dois canhoes
   (KwK 44 de 128 mm e coaxial KwK 44 de 75 mm que dispara sozinho), 7 bogies por lado, tripulacao de 6
   ====================================================================== */
const mauT=camT(['#8c8e78','#6b6e5a','#9a9070']);
const mW=tw(.4),mS=tw(.62,1),mI=tw(.55),mR=tw(.16),mauN=numTx('V2');
function makeMaus(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x6c7062,mauT),g=new THREE.Group(),wheels=[],bogs=[],skirts=[],GX=1.95,
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,WD=0x6a5232,CV=0x76704f,JC=0x56602f,CB=0x56503f,RD=0xa8302a;
  g.rotation.order='YXZ';
  /* esteiras largas em laco; roda motriz na frente, roda guia atras, 7 bogies de rodas intercaladas por lado */
  const trk=trackLoop([[-3.9,.1],[3.4,.1],[4.1,.45],[4.3,.95],[4,1.45],[3.3,1.58],[-3.3,1.58],[-4.1,1.4],[-4.45,.9],[-4.3,.4]],120,1,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    wl(g,mS,sx,.95,3.65,.62,s,wheels);wl(g,mI,sx,.9,-3.85,.55,s,wheels);
    for(let k=0;k<7;k++){
      const bg=new THREE.Group();bg.position.set(sx,.45,-2.9+k*.95);
      wl(bg,mW,.2,0,-.24,.4,s,wheels);wl(bg,mW,-.2,0,.24,.4,s,wheels);
      bg.add(bx(.16,.14,.9,dark,0,.1,0),bx(.3,.3,.3,dark,0,.35,0),bx(.5,.1,.5,dark,0,.7,0));
      g.add(bg);bogs.push(bg);
    }
    for(let k=0;k<5;k++)wl(g,mR,sx,1.42,-3+k*1.5,.16,s,wheels);
  });
  /* casco: glacis inclinado, convés do motor, escapamentos duplos, estiva */
  const hull=new THREE.Group(),H=mb();
  H.b(2.9,.95,8.6,'M',0,1.07,-.1);H.b(2.6,.14,8.4,DK,0,.55,-.1);
  H.b(3.6,.7,7.5,'M',0,1.9,-.55);H.b(3.2,1.5,.2,'M',0,1.4,-4.5,.12);
  H.b(3.3,.2,1.91,'M',0,1.525,3.725,.859);H.b(2.9,.8,.2,'M',0,.95,4.28,.35);
  for(const s of[-1,1]){H.b(1.3,.3,1.3,'M',s*.9,2.4,2);H.c(.4,.44,.1,MT,s*.9,2.58,2,'y');H.b(.3,.12,.08,GL,s*.9,2.45,2.68)}
  H.g(new THREE.SphereGeometry(.15,10,8),MT,.9,2.35,2.68);H.c(.04,.04,.5,DK,.9,2.35,2.95,'z');
  for(let k=0;k<9;k++){H.b(1.2,.04,.12,MT,-.85,2.27,-1.6-k*.25);H.b(1.2,.04,.12,MT,.85,2.27,-1.6-k*.25)}
  H.b(.8,.06,.8,DK,0,2.28,-2.6);H.c(.4,.4,.05,DK,-1.1,2.27,-3.9,'y');H.c(.4,.4,.05,DK,1.1,2.27,-3.9,'y');
  for(const s of[-1,1]){
    H.b(.14,.1,8.4,MT,s*2.55,1.68,-.1);
    H.c(.3,.3,1.1,DK,s*1.1,1.15,-5,'z');H.c(.16,.16,.5,MT,s*1.1,1.15,-5.65,'z');
    H.b(.4,.3,.4,MT,s*1.1,.8,4.4);
    hull.add(bx(.3,.2,.08,brkM,s*1.3,1.2,-4.6));
  }
  H.c(.07,.07,6.2,CB,1.88,1.62,-.6,'z');H.b(.2,.15,.2,MT,1.88,1.62,2.5);H.b(.2,.15,.2,MT,1.88,1.62,-3.7);
  H.b(.08,.04,1.4,WD,-1.88,1.62,.5);H.b(.25,.04,.35,MT,-1.88,1.62,1.3);H.b(.4,.45,1.3,'M',-2,2.05,-2.6);H.c(.1,.1,.5,RD,-1.95,2,.4,'y');
  H.b(.4,.3,.4,MT,0,.9,-4.7);H.c(.1,.1,.2,MT,0,1,-4.85,'y');
  for(const x of[-.8,-.4,.4,.8])H.b(.36,.5,.18,JC,x,1.6,-4.72);
  H.c(.25,.25,2.6,CV,0,2.5,-3.5,'x');H.c(.1,.12,.2,MT,1.5,2.35,-2.2,'y');
  /* saias blindadas (Schuerzen) que balancam */
  for(const s of[-1,1]){
    const q=new THREE.Group(),S=mb();q.position.set(s*2.58,1.65,-.1);
    for(let k=0;k<8;k++){S.b(.08,1.05,1,'M',0,-.55,-3.5+k);S.b(.1,.1,.1,MT,s*.06,-.2,-3.5+k);S.b(.1,.1,.1,MT,s*.06,-.9,-3.5+k)}
    S.out(q,mat);hull.add(q);skirts.push(q);
  }
  H.out(hull,mat);g.add(hull);
  hull.add(bx(.25,.2,.2,lamp,-1.6,2.32,3));
  for(const s of[-1,1]){stk(hull,crossT,s*1.808,2,.3,s,.7,.7);stk(hull,mauN,s*1.808,2.05,-1.6,s,.9,.45)}
  const ant=mkAnt(hull,1.5,2.4,-2.2,flagM);
  const dl=[mkLid(hull,mat,-.9,2.65,2,.36),mkLid(hull,mat,.9,2.65,2,.36)],drvs=[mkCrew(hull,cm,hm,sk,-.9,1.55,2),mkCrew(hull,cm,hm,sk,.9,1.55,2)];
  /* torre fundida (lathe) com cunha frontal, bustle traseiro, cupula e ventiladores */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,2.25,-1);
  T.g(new THREE.LatheGeometry([[1,0],[1.04,.08],[1.06,.4],[1,.75],[.82,.92],[.5,1],[.001,1.03]].map(p=>new THREE.Vector2(p[0],p[1])),28).scale(1.78,1,1.95),'M',0,0,0);
  T.b(2.6,.1,2.4,'M',0,.99,.1);T.b(3,.95,.5,'M',0,.5,1.95,-.4);
  T.b(3,.9,1,'M',0,.5,-2.05);T.b(3,.14,.9,'M',0,.98,-2,.3);T.b(3,.9,.15,'M',0,.5,-2.6,.1);T.c(.36,.36,.06,MT,0,.5,-2.7,'z');T.b(.5,.07,.07,MT,0,.5,-2.75);T.b(.07,.5,.07,MT,0,.5,-2.75);
  T.c(.5,.55,.3,'M',-.8,1.15,-.2,'y');T.c(.56,.56,.06,MT,-.8,1.33,-.2,'y');
  for(let k=0;k<8;k++){const a=k/8*6.2832;T.b(.1,.06,.04,GL,-.8+Math.sin(a)*.55,1.22,-.2+Math.cos(a)*.55,0,a)}
  T.c(.34,.38,.1,MT,.8,1,-.7,'y');
  for(const s of[-1,1]){
    T.b(.35,.2,.3,DK,s*.9,1.1,.9);T.b(.25,.1,.04,GL,s*.9,1.12,1.06);
    T.c(.28,.3,.12,MT,s*.6,1.02,-1.5,'y');
    for(let k=0;k<3;k++)T.c(.06,.06,.32,DK,s*1.6,.85,.7+k*.18,'y',0,0,-s*.5);
  }
  T.c(.18,.18,1.6,0x6f6a4a,-.2,1.1,-2,'x');
  for(const x of[-1.1,-.7,.7,1.1])T.b(.36,.5,.18,JC,x,.6,-2.8);
  T.out(tg,mat);
  for(const s of[-1,1]){stk(tg,crossT,s*1.8,.5,-.45,s,.7,.7);stk(tg,mauN,s*1.72,.52,.75,s,.7,.35)}
  const fans=[-1,1].map(s=>{const f=new THREE.Group();f.position.set(s*.6,1.12,-1.5);for(let k=0;k<3;k++){const bg=new THREE.Group();bg.rotation.y=k*Math.PI*2/3;bg.add(bx(.3,.02,.06,dark,.15,0,0));f.add(bg)}tg.add(f);return f});
  const cl=mkLid(tg,mat,-.8,1.36,-.2,.36),ll=mkLid(tg,mat,.8,1.07,-.7,.34),crew=mkCrew(tg,cm,hm,sk,-.8,.45,-.2),crew2=mkCrew(tg,cm,hm,sk,.8,.4,-.7),cmg=mkMG(tg,-.8,1.4,-.2);
  /* mantelete com os dois canhoes: 128 mm no centro e 75 mm coaxial a direita */
  const bp=new THREE.Group(),bar=new THREE.Group(),cbar=new THREE.Group(),B=mb(),K=mb(),Q=mb();bp.position.set(0,.55,2.15);
  B.b(2.3,1,.5,'M',.38,0,.2);B.c(.55,.62,.5,'M',0,0,.45,'z');B.c(.42,.5,.4,RB,0,0,.7,'z');B.c(.3,.3,.3,RB,.78,-.1,.55,'z');B.b(.2,.2,.08,GL,-.8,.3,.46);B.b(.2,.2,.08,GL,1.4,.3,.46);
  B.out(bp,mat);
  K.c(.17,.15,6.2,DK,0,0,3.4,'z');K.c(.27,.25,2.2,'M',0,0,1.4,'z');for(const z of[.5,1.1,1.7,2.3])K.c(.29,.29,.07,DK,0,0,z,'z');
  K.c(.24,.24,.6,'M',0,0,4.6,'z');K.c(.2,.2,.3,DK,0,0,6.4,'z');K.c(.22,.22,.06,DK,0,0,6.3,'z');K.c(.22,.22,.06,DK,0,0,6.55,'z');K.out(bar,mat);
  cbar.position.set(.78,-.1,0);
  Q.c(.11,.1,2.9,DK,0,0,1.75,'z');Q.c(.17,.16,1,'M',0,0,.8,'z');Q.c(.15,.15,.4,DK,0,0,3.1,'z');Q.c(.17,.17,.06,DK,0,0,3,'z');Q.out(cbar,mat);
  const fl=mkFl(bar,6.7,.7,flashM),fl2=mkFl(cbar,3.35,.3,flashM);fl2.traverse(o=>o.castShadow=false);
  bp.add(bar,cbar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,cbar,hull,ant,lid:[cl,ll],crew,crew2,dl,drvs,cmg,fans,skirts,fl,fl2,brkM,wheels,bogs,trk,mat,dark,maus:true,cannon:true,spd:.5,trn:.5,L:5,W:2.4,mz:6.55,fk:1.8,rld:3.6,wd:2.8,armor:.45,hp:220,TY:2.25}));
}
function animMaus(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.drvs.forEach(q=>q.visible=false);t.crew2.visible=false;t.fl2.visible=false;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.dl[0].rotation.x=-1.5;t.dl[1].rotation.x=-1.5;
    if(t.ck===undefined)t.ck=7;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;
      if(t.ckt<=0){t.ckt=.09+Math.random()*.1;const hs=[[-.8,1.4,-.2],[.8,1.1,-.7],[0,.6,-2.7]],h=hs[(Math.random()*3)|0];t.tg.localToWorld(v2.set(h[0],h[1],h[2]));
        puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.3,5,.55,9);puff(v2,0x1f1e1c,1.9,3,1.8,5);
        if(Math.random()<.25){puff(v2,0xff6a20,2.8,8,.4,10);sfx(.35*near(v2),.25)}}}
    return blowOff(t,dt,t.TY);
  }
  const th=clamp(Math.abs(t.v)/7,0,1),d=trkStep(t,dt,1.95),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  for(const w of t.wheels)w.rotation.x+=d[w.userData.s]/w.userData.r;
  t.bogs.forEach((b,i)=>b.rotation.x=Math.sin(now*6+i*1.7)*.025*th+ac*.0015);
  t.hull.position.y=Math.sin(now*26+t.x)*(.005+.009*th)-t.recoil*.04;t.hull.rotation.x=-ac*.003-t.recoil*.025;t.hull.rotation.z=-(t.st||0)*th*.015;
  t.skirts.forEach((q,i)=>q.rotation.z=Math.sin(now*7+i*2+t.x)*.02*(.3+th)*(i?-1:1));
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.ant.rotation.z=Math.sin(now*2.2+t.x)*.02;
  t.fans.forEach((f,i)=>f.rotation.y+=dt*(9+th*12)*(i?-1:1));
  tankFx(t,dt,now,th,{ex:[[1.1,1.2,-6],[-1.1,1.2,-6]],dk:[[1.95,.2,-4.6],[-1.95,.2,-4.6],[1.95,.2,4.4],[-1.95,.2,4.4]],mz:6.5,rr:.9,rc:1});
  /* escotilhas: motorista, radio-operador, comandante e municiador saem quando parado */
  t.dl[0].rotation.x=-t.open*1.5;t.dl[1].rotation.x=-t.open*1.4;
  t.drvs.forEach((q,i)=>{q.visible=t.open>.3&&(i?t.open>.6:true);q.position.y=q.userData.by+Math.min(1,t.open)*.5;q.rotation.y=Math.sin(now*.7+i*2+t.z)*.5});
  t.crew2.visible=t.open>.55;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  mgScan(t,dt,60);mgAim(t,dt,t.cmg,t.yaw,.9,[0,.1,1.45],now);
  /* canhao coaxial de 75 mm: dispara sozinho no alvo mais proximo que estiver na linha da torre */
  t.xs=(t.xs||0)-dt;if(t.xs<=0){t.xs=.6;t.xt=null;let best=110;for(const o of tanks)if(!o.dead&&hostile(t,o)){const dd=Math.hypot(o.x-t.x,o.z-t.z);if(dd<best){best=dd;t.xt=o}}}
  t.xc=(t.xc||0)-dt;const o=t.xt;
  if(o&&!o.dead&&t.xc<=0&&Math.abs(angDiff(Math.atan2(o.x-t.x,o.z-t.z),t.yaw))<.1){
    t.xc=1.7+Math.random()*.4;damage(o,13,t);t.xr=1;t.xf=.08;
    t.cbar.localToWorld(v2.set(0,0,3.35));puff(v2,0xffd36b,1.2,3,.25,.3);puff(v2,0xcfc8b8,1,3,.8,.4);
    v3.set(o.x,o.y+1.5,o.z);puff(v3,0xffa040,1.2,3,.3,1);snd('light',.4*near(v2));
  }
  t.xf=Math.max(0,(t.xf||0)-dt);t.fl2.visible=t.xf>0;if(t.xf>0)t.fl2.scale.setScalar(.7+Math.random()*.6);
  t.xr=Math.max(0,(t.xr||0)-dt*3);t.cbar.position.z=-t.xr*.55;
  smokeQ(t,dt,1.55,.85,.7);
}
/* ======================================================================
   SU-100 (URSS): cacador de casamata sobre chassi T-34, canhao D-10S de 100 mm, hull gira para mirar
   AMX-13 (Franca): leve com torre oscilante FL-10 (capacete com viseira) e carregador de dois tambores
   ====================================================================== */
const ix=g=>g.setIndex(Array.from({length:g.attributes.position.count},(_,i)=>i));
const suT=camT(['#6d7a4a','#58663a','#7a7550']),amT=camT(['#a39c70','#86845a','#6e7249']);
const redStar=canvasTex(64,64,x=>{x.fillStyle='#c4251c';x.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?12:30;x.lineTo(32+Math.cos(a)*r,32+Math.sin(a)*r)}x.closePath();x.fill()});
const roundel=canvasTex(64,64,x=>{[['#d6232c',30],['#f4f1e6',20],['#1f3f9a',10]].forEach(([c,r])=>{x.fillStyle=c;x.beginPath();x.arc(32,32,r,0,7);x.fill()})});
const suN=numTx('SU-100'),brM=new THREE.MeshLambertMaterial({color:0xc9a24a}),shG=new THREE.CylinderGeometry(.075,.075,.42,8);
const planeM=(tx,w,h)=>new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tx,transparent:true}));
const mkFan=(par,x,y,z,n,L)=>{const f=new THREE.Group();f.position.set(x,y,z);for(let k=0;k<n;k++){const b=new THREE.Group();b.rotation.y=k*Math.PI*2/n;b.add(bx(L,.02,.08,dark0,L/2,0,0));f.add(b)}par.add(f);return f};
function makeSU100(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x5d6b3e,suT),g=new THREE.Group(),wheels=[],GX=1.4,glow=new THREE.MeshBasicMaterial({color:0xff7a20}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,CV=0x6f6a4c,CB=0x56503f,WD=0x6a5232;
  g.rotation.order='YXZ';
  /* esteiras em laco: roda motriz atras, guia na frente, cinco rodas grandes Christie que balancam */
  const trk=trackLoop([[-3.1,.1],[2.6,.1],[3.2,.5],[3.2,.95],[2.8,1.12],[-2.9,1.12],[-3.5,.85],[-3.45,.35]],88,.64,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,gSL,sx,.58,-3.2,.52,s,wheels);wl(g,gWL,sx,.5,3.05,.46,s,wheels);for(let i=0;i<5;i++)wl(g,gWL,sx,.5,-2.3+i*1.1,.46,s,wheels).userData.b=1});
  const hull=new THREE.Group(),H=mb(),sp=s=>ix(new THREE.ExtrudeGeometry(new THREE.Shape([[1.75,0],[-2.2,0],[-.85,1.1],[1.75,1.1]].map(p=>new THREE.Vector2(p[0],p[1]))),{depth:.12,bevelEnabled:false}).rotateY(Math.PI/2).rotateZ(s*.28)).translate(s*1.28,1.45,0);
  H.b(2.6,.75,5.5,'M',0,.98,-.45);H.b(2.4,.14,5.4,DK,0,.55,-.45);H.b(3,.1,5.6,'M',0,1.42,-.45);
  H.b(2.6,.14,1.05,'M',0,1.08,2.7,.68);H.b(2.6,.45,.1,'M',0,.5,3.1);H.b(2.5,.8,.14,'M',0,1,-3.25,.28);
  /* casamata: frente de 75 mm inclinada, laterais inclinadas (placas extrudadas), teto e traseira */
  H.b(2.3,.14,1.71,'M',0,1.975,1.525,.66);H.b(2,.1,2.6,'M',0,2.55,-.45);H.b(2.3,1.1,.12,'M',0,2,-1.8,.08);H.g(sp(1),'M',0,0,0);H.g(sp(-1),'M',0,0,0);
  H.b(.2,.2,.08,DK,-.55,2.18,1.46,.66);H.b(.14,.07,.04,GL,-.55,2.2,1.5,.66);
  for(let k=0;k<8;k++)H.b(1.7,.03,.09,MT,0,1.49,-2.15-k*.13);H.b(.5,.04,.5,DK,0,1.49,-3);
  H.b(.26,.2,.3,DK,.6,2.67,.45);H.b(.18,.08,.04,GL,.6,2.68,.61);
  H.c(.3,.33,.08,MT,-.55,2.6,.5,'y');H.c(.3,.33,.08,MT,-.55,2.6,-.4,'y');H.c(.3,.32,.14,MT,-.5,2.62,-1.3,'y');H.b(.56,.03,.03,DK,-.5,2.7,-1.3);H.b(.03,.03,.56,DK,-.5,2.7,-1.3);H.b(.12,.22,.12,MT,.55,2.65,-1.45);
  for(const s of[-1,1]){
    H.b(.55,.05,5.8,'M',s*1.75,1.38,-.2);H.b(.55,.05,.9,'M',s*1.75,1.2,3.3,.4);H.b(.08,.2,5.8,'M',s*2.02,1.3,-.2);
    H.c(.2,.2,1.9,CV,s*1.7,1.66,-2,'z');for(let k=0;k<3;k++)H.b(.08,.46,.1,MT,s*1.7,1.65,-2.8+k*.8);
    H.c(.05,.05,1.2,CB,s*.6,1.13,2.72,'z',.68);H.b(.2,.2,.25,MT,s*.9,.6,3.2);
    H.c(.13,.13,.7,DK,s*.9,1.25,-3.5,'z');H.c(.12,.12,.55,0x6a6a5a,s*.45,1.15,-3.4,'y');
    hull.add(bx(.3,.2,.08,brkM,s*1.1,1,-3.4),bx(.14,.14,.05,glow,s*.9,1.25,-3.88));
  }
  H.b(.4,.3,.9,'M',-1.78,1.58,.6);H.b(.06,.03,1.1,WD,-1.78,1.76,-.3);H.b(.2,.03,.26,MT,-1.78,1.76,.3);H.c(.15,.15,3.2,WD,1.8,1.58,.7,'z');H.b(.3,.1,.3,MT,0,.9,-3.4);
  hull.add(bx(.28,.2,.2,lamp,-.9,1.2,2.62));
  H.out(hull,mat);g.add(hull);
  const st=planeM(redStar,.6,.6);st.rotation.x=-Math.PI/2;st.position.set(0,2.62,-.45);hull.add(st);
  const rn=planeM(suN,1,.5);rn.rotation.y=Math.PI;rn.position.set(0,1.95,-1.88);hull.add(rn);
  const ant=mkAnt(hull,-.85,2.5,-1.6,flagM);
  /* cupula do comandante (gira, com periscopio) no canto traseiro direito do teto */
  const cup=new THREE.Group(),C=mb();cup.position.set(.62,2.6,-.55);
  C.c(.38,.42,.18,'M',0,.08,0,'y');C.c(.4,.4,.05,MT,0,.2,0,'y');for(let k=0;k<8;k++){const a=k/8*6.2832;C.b(.12,.07,.04,GL,Math.sin(a)*.4,.12,Math.cos(a)*.4,0,a)}
  C.b(.2,.16,.26,DK,-.28,.3,.12);C.b(.14,.07,.04,GL,-.28,.31,.26);C.out(cup,mat);hull.add(cup);
  const cl=mkLid(cup,mat,0,.24,0,.26),ll=mkLid(hull,mat,-.55,2.67,-.4,.28),dl=mkLid(hull,mat,-.55,2.67,.5,.26),
    crew=mkCrew(cup,cm,hm,sk,0,-.3,0),crew2=mkCrew(hull,cm,hm,sk,-.55,2.1,-.4),drv=mkCrew(hull,cm,hm,sk,-.55,2.1,.5),fan=mkFan(hull,-.5,2.68,-1.3,3,.24),cmg=mkMG(hull,.5,2.72,-1.5);
  /* mantelete cilindrico e canhao D-10S de 100 mm; a montagem so mira poucos graus para os lados */
  const tg=new THREE.Group(),bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();tg.position.set(0,1.97,1.45);bp.position.set(0,0,.15);
  B.g(new THREE.SphereGeometry(.45,14,10).scale(1,.9,1.1),'M',0,0,.3);B.b(1.1,.1,.8,'M',0,0,.0,.66);B.c(.5,.5,.1,MT,0,0,.1,'z');B.c(.28,.34,.3,RB,0,0,.72,'z');B.b(.2,.24,.3,'M',-.5,.2,.2);B.c(.04,.04,.6,DK,.36,-.1,.75,'z');B.out(bp,mat);
  K.c(.1,.1,4.8,DK,0,0,3,'z');K.c(.15,.16,2,'M',0,0,1.5,'z');for(const z of[1.4,1.9,2.4])K.c(.17,.17,.06,DK,0,0,z,'z');
  K.c(.15,.15,.3,DK,0,0,5.5,'z');K.c(.18,.18,.05,DK,0,0,5.35,'z');K.c(.18,.18,.05,DK,0,0,5.65,'z');K.b(.04,.2,.2,MT,0,0,5.5);K.out(bar,mat);
  const fl=mkFl(bar,5.7,.55,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,cup,fan,glow,dl,drv,crew,crew2,lid:[cl,ll],cmg,fl,brkM,wheels,trk,mat,dark,su:true,td:true,cannon:true,lim:.28,spd:1.15,trn:.85,L:3.6,W:1.9,mz:5.7,fk:1.45,rld:2.5,wd:1.7,armor:.7,hp:115,TY:1.97}));
}
function animSU(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.glow.color.set(0x220000);t.drv.visible=false;t.crew2.visible=false;t.dl.rotation.x=-1.5;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;
    if(t.ck===undefined)t.ck=6;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;
      if(t.ckt<=0){t.ckt=.1+Math.random()*.12;const h=[[.62,2.9,-.55],[-.55,2.9,-.4],[-.5,2.9,-1.3]][(Math.random()*3)|0];t.hull.localToWorld(v2.set(h[0],h[1],h[2]));
        puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.1,5,.55,9);puff(v2,0x1f1e1c,1.6,3,1.6,5);if(Math.random()<.25){puff(v2,0xff6a20,2.4,8,.4,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY);
  }
  const r=angDiff(t.yaw,t.hd),e=Math.abs(r)-t.lim;if(e>0)t.hd+=Math.sign(r)*Math.min(e,t.trn*1.1*dt); /* casamata: o casco inteiro gira para acompanhar a mira */
  const th=clamp(Math.abs(t.v)/13,0,1),d=trkStep(t,dt,1.4),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),u=t.clk-t.lf;
  for(const w of t.wheels){w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*11+w.position.z*2.3)*.035*th} /* suspensao Christie */
  t.hull.position.y=Math.sin(now*34+t.x)*(.006+.01*th)-t.recoil*.03;t.hull.rotation.x=-ac*.003-t.recoil*.025;t.hull.rotation.z=-(t.st||0)*th*.02;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.fan.rotation.y+=dt*(8+th*22);
  t.glow.color.setHSL(.07,1,.3+.25*th+.08*Math.sin(now*22));
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.6+t.x)*1.3; /* cupula vigia o terreno */
  tankFx(t,dt,now,th,{ex:[[.9,1.3,-3.9],[-.9,1.3,-3.9]],dk:[[1.5,.2,-3.5],[-1.5,.2,-3.5],[1.5,.2,3.2],[-1.5,.2,3.2]],mz:5.6,rr:1.1,rc:.9});
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  t.crew2.visible=t.open>.6;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  if(u<.12){if(!t.ejd){t.ejd=1;t.tg.localToWorld(v2.set(0,.3,-1.2));puff(v2,0xcfc8b8,.7,2,.7,.5)}}else t.ejd=0;
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.hd,.8,[0,.1,1.45],now);smokeQ(t,dt,1,.7,-3);
}
function makeAMX13(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x8f8a5c,amT),g=new THREE.Group(),wheels=[],GX=1.2,glow=new THREE.MeshBasicMaterial({color:0xff7a20}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,CB=0x56503f,JC=0x56602f,CV=0x6f6a4c;
  g.rotation.order='YXZ';
  /* roda motriz elevada na frente, guia atras, cinco rodas e tres roletes de retorno por lado */
  const trk=trackLoop([[-2.1,.1],[1.7,.1],[2.4,.7],[2.4,1.1],[2,1.25],[-1.9,1.2],[-2.55,.85],[-2.5,.3]],72,.58,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,gS5,sx,.85,2.1,.5,s,wheels);wl(g,gW,sx,.55,-2.35,.42,s,wheels);for(let i=0;i<5;i++)wl(g,gW5,sx,.45,-1.6+i*.8,.38,s,wheels).userData.b=1;for(const z of[-1.2,0,1.2])wl(g,gRL,sx,1.1,z,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(2.3,.6,4.7,'M',0,.9,-.2);H.b(2.1,.14,4.5,DK,0,.55,-.2);H.b(2.5,.1,4.6,'M',0,1.25,-.2);H.b(2.3,.14,1.05,'M',0,.98,2.6,.6);H.b(2.3,.45,.1,'M',0,.5,3);H.b(2.3,.7,.1,'M',0,.95,-2.6,.2);
  /* motorista a esquerda, motor SOFAM a direita com grade e ventoinha */
  H.b(.95,.4,1.3,'M',-.62,1.5,1.25);H.b(.95,.1,.6,'M',-.62,1.62,1.95,.55);H.c(.3,.33,.08,MT,-.62,1.72,1.25,'y');for(let k=0;k<3;k++)H.b(.1,.06,.04,GL,-.62+(k-1)*.22,1.62,2.2,.55);
  H.b(1,.12,1.4,DK,.65,1.32,1.3);for(let k=0;k<4;k++)H.b(.9,.03,.08,MT,.65,1.4,.75+k*.17);H.b(.9,.03,.05,MT,.65,1.42,1.6);H.b(.05,.03,.8,MT,.65,1.42,1.65);
  H.c(.1,.1,.9,DK,1.2,1.35,.2,'z');H.b(.04,.2,.9,MT,1.3,1.4,.2);H.c(1.05,1.1,.12,MT,0,1.33,-.75,'y');
  H.b(.9,.3,.6,'M',-.5,1.45,-2.1);H.c(.17,.17,.9,CV,.6,1.42,-2.1,'x');
  for(const s of[-1,1]){H.b(.55,.05,4.6,'M',s*1.45,1.3,-.2);H.b(.55,.05,.7,'M',s*1.45,1.15,2.45,.4);H.b(.06,.22,4.6,'M',s*1.73,1.2,-.2);H.b(.2,.18,.2,MT,s*.9,.6,-2.7);
    hull.add(bx(.26,.2,.18,lamp,s*.9,1,3.05),bx(.3,.2,.08,brkM,s*1,1,-2.68))}
  H.b(.4,.28,.9,'M',-1.45,1.5,-1.3);H.c(.05,.05,2.2,CB,1.45,1.36,.9,'z');H.c(.14,.14,1,CV,1.45,1.45,-1.5,'z');
  for(const x of[-.6,.6])H.b(.34,.44,.16,JC,x,1,-2.75);
  hull.add(bx(.1,.1,.04,glow,1.2,1.35,.67));
  H.out(hull,mat);g.add(hull);
  const fan=mkFan(hull,.65,1.38,1.75,4,.3),ant=mkAnt(hull,-.9,1.35,-2.2,flagM),dl=mkLid(hull,mat,-.62,1.72,1.25,.26),drv=mkCrew(hull,cm,hm,sk,-.62,1.2,1.25);
  /* torre inferior: gira; carrega escotilhas, comandante e lancadores de fumaca */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.38,-.75);
  T.c(1,1.1,.5,'M',0,.25,0,'y');T.b(2.1,.12,1.9,'M',0,.5,0);T.b(1.6,.3,.35,'M',0,.28,1,-.4);T.b(1.9,.35,.3,'M',0,.3,-1.05,.2);
  for(const s of[-1,1]){T.b(.2,.45,1.6,'M',s*1.05,.28,0,0,0,s*.2);for(let k=0;k<4;k++)T.c(.06,.06,.3,DK,s*1.12,.62,-.5+k*.14,'y',0,0,-s*.5)}
  T.out(tg,mat);for(const s of[-1,1])stk(tg,roundel,s*1.2,.35,.1,s,.55,.55);
  const cup=new THREE.Group(),C=mb();cup.position.set(.75,.56,-.3);
  C.c(.32,.35,.2,'M',0,.1,0,'y');C.c(.34,.34,.05,MT,0,.22,0,'y');for(let k=0;k<8;k++){const a=k/8*6.2832;C.b(.1,.06,.04,GL,Math.sin(a)*.34,.14,Math.cos(a)*.34,0,a)}C.b(.16,.14,.2,DK,-.22,.3,.1);C.b(.12,.06,.04,GL,-.22,.31,.21);C.out(cup,mat);tg.add(cup);
  const cl=mkLid(cup,mat,0,.26,0,.24),ll=mkLid(tg,mat,-.75,.58,-.35,.25),crew=mkCrew(cup,cm,hm,sk,0,-.3,0),crew2=mkCrew(tg,cm,hm,sk,-.75,.1,-.35),cmg=mkMG(tg,-.95,.58,.5);
  /* torre superior oscilante (o capacete): viseira, bochechas facetadas, canhao de 75 mm e a caixa do carregador */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.65,.55);
  B.b(1.5,.6,1.1,'M',0,.1,-.2);B.b(1.3,.14,1.2,'M',0,.45,-.1,.05);for(const s of[-1,1]){B.b(.45,.1,1.1,'M',s*.62,.42,-.15,0,0,-s*.45);B.b(.45,.55,.1,'M',s*.62,.1,.62,0,-s*.55)}
  B.b(1.45,.12,.55,'M',0,.5,.6,.35);B.b(1.1,.1,.04,GL,0,.32,.78);B.b(1.3,.4,.12,'M',0,.02,.72,-.12);B.b(1.65,.04,1.3,DK,0,-.2,-.25);
  B.b(.22,.28,.3,DK,.5,.62,.05);B.b(.16,.1,.04,GL,.5,.64,.21);B.c(.3,.36,.35,RB,0,0,.82,'z');B.c(.03,.03,.9,DK,.34,-.1,1,'z');B.b(.1,.1,.3,DK,.34,-.1,.6);
  /* caixinha do carregador: bandeja aberta com divisoria central */
  B.b(1.6,.5,.08,'M',0,.1,-.8);B.b(1.6,.06,1.15,'M',0,-.15,-1.38);B.b(.06,.5,1.1,'M',0,.1,-1.38);B.b(1.6,.2,.08,'M',0,.3,-1.95);
  for(const s of[-1,1]){B.b(.08,.5,1.15,'M',s*.8,.1,-1.38);B.b(.1,.5,.1,'M',s*.7,.1,-1.95)}
  B.out(bp,mat);
  const dr=[-1,1].map(s=>{const d=new THREE.Group(),sh=[];d.position.set(s*.4,.12,-1.4);d.userData.tr=0;
    d.add(new THREE.Mesh(new THREE.CylinderGeometry(.34,.34,.36,16),dark),new THREE.Mesh(new THREE.CylinderGeometry(.1,.1,.46,8),new THREE.MeshLambertMaterial({color:MT})));
    for(let k=0;k<6;k++){const a=k/6*6.2832,m=new THREE.Mesh(shG,brM);m.position.set(Math.sin(a)*.22,.2,Math.cos(a)*.22);d.add(m);sh.push(m)}
    d.userData.sh=sh;bp.add(d);return d});
  const flap=new THREE.Group();flap.position.set(0,-.1,-1.97);flap.add(bx(1.4,.4,.05,mat,0,.2,0));bp.add(flap);
  K.c(.075,.075,4.1,DK,0,0,2.9,'z');K.c(.13,.13,.8,'M',0,0,1.3,'z');K.c(.13,.13,.5,'M',0,0,2.6,'z');for(const z of[2.3,2.9])K.c(.14,.14,.05,DK,0,0,z,'z');
  K.c(.2,.2,.12,DK,0,0,4.5,'z');K.c(.2,.2,.12,DK,0,0,4.82,'z');K.c(.1,.1,.4,MT,0,0,4.66,'z');K.out(bar,mat);
  const fl=mkFl(bar,5.1,.45,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,cup,fan,glow,dl,drv,crew,crew2,dr,flap,lid:[cl,ll],cmg,fl,brkM,wheels,trk,mat,dark,amx:true,cannon:true,spd:1.5,trn:1.25,L:2.7,W:1.6,mz:5,fk:1,rld:1.2,wd:1.5,armor:.95,hp:75,TY:1.38}));
}
function animAMX(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.glow.color.set(0x220000);t.drv.visible=false;t.crew2.visible=false;t.dl.rotation.x=-1.5;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.flap.rotation.x=-1.4;
    if(t.ck===undefined)t.ck=6;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;
      if(t.ckt<=0){t.ckt=.08+Math.random()*.1;const h=[[.4,.6,-1.4],[-.4,.6,-1.4],[0,.3,-1.9]][(Math.random()*3)|0];t.bp.localToWorld(v2.set(h[0],h[1],h[2])); /* os tambores de municao explodem */
        puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.1,5,.55,9);puff(v2,0x1f1e1c,1.5,3,1.6,5);if(Math.random()<.25){puff(v2,0xff6a20,2.4,8,.4,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY);
  }
  const th=clamp(Math.abs(t.v)/16,0,1),d=trkStep(t,dt,1.2),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),u=t.clk-t.lf;
  for(const w of t.wheels){w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.45+Math.sin(now*12+w.position.z*2.1)*.03*th}
  t.hull.position.y=Math.sin(now*38+t.x)*(.006+.012*th)-t.recoil*.02;t.hull.rotation.x=-ac*.004-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.fan.rotation.y+=dt*(12+th*34);t.glow.color.setHSL(.07,1,.3+.25*th+.08*Math.sin(now*22));
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.7+t.x)*1.4;
  /* carregador automatico: cada tiro gira um tambor 60 graus, some um cartucho, o postigo traseiro abre e ejeta o estojo; sem municao, recarrega */
  if(t.lf0===undefined){t.lf0=t.lf;t.ammo=12;t.rt=0;t.fo=0}
  if(t.lf!==t.lf0){t.lf0=t.lf;
    if(t.ammo>0){const i=12-t.ammo,q=t.dr[i&1];q.userData.sh[i>>1].visible=false;q.userData.tr+=Math.PI/3;t.ammo--;
      t.bp.localToWorld(v2.set(0,.3,-2.1));puff(v2,0xd9b24a,.25,3,.7,1.6);puff(v2,0xd9b24a,.25,2,.6,1.2);puff(v2,0xcfc8b8,.5,1,.6,.8);if(!t.ammo)t.rt=.01}}
  if(t.rt>0){t.rt+=dt;if(t.rt>.6){const n=Math.min(12,((t.rt-.6)/.22)|0);for(let i=0;i<12;i++)t.dr[i&1].userData.sh[i>>1].visible=i<n;if(n>=12){t.rt=0;t.ammo=12}}}
  t.dr.forEach((q,i)=>{if(t.rt>0)q.userData.tr+=dt*5*(i?-1:1);q.rotation.y+=(q.userData.tr-q.rotation.y)*Math.min(1,dt*10)});
  t.fo+=(((u<.45||t.rt>0)?1:0)-t.fo)*Math.min(1,dt*9);t.flap.rotation.x=-t.fo*(t.rt>0?1.45:.9);
  tankFx(t,dt,now,th,{ex:[[1.2,1.45,.3]],dk:[[1.3,.2,-2.5],[-1.3,.2,-2.5],[1.3,.2,2.5],[-1.3,.2,2.5]],mz:5,rr:1.6,rc:.55});
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  t.crew2.visible=t.open>.6;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  mgScan(t,dt,50);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);smokeQ(t,dt,1.1,.6,-.5);
}
/* ======================================================================
   SK-105 Kurassier (Austria): atirador de elite (Sniper Tank). Chassi com proa em ponta de lanca,
   torre oscilante com canhao de 105 mm, telemetro a laser, mira termica, anemometro e pa de ancoragem
   ====================================================================== */
const kuT=camT(['#6a7548','#556038','#837c4f']),atT=canvasTex(64,64,x=>{[['#d6232c',30],['#f4f1e6',20],['#d6232c',10]].forEach(([c,r])=>{x.fillStyle=c;x.beginPath();x.arc(32,32,r,0,7);x.fill()})});
const kuW=tw(.4),kuS=tw(.5,1),kuI=tw(.45);
/* solido convexo facetado a partir de vertices e faces (o sentido das faces e corrigido sozinho) */
function facet(V,F){
  const c=[0,0,0];for(const v of V){c[0]+=v[0];c[1]+=v[1];c[2]+=v[2]}c[0]/=V.length;c[1]/=V.length;c[2]/=V.length;
  const P=[],U=[];
  for(const f of F)for(let i=1;i<f.length-1;i++){
    let a=V[f[0]],b=V[f[i]],d=V[f[i+1]];
    const nx=(b[1]-a[1])*(d[2]-a[2])-(b[2]-a[2])*(d[1]-a[1]),ny=(b[2]-a[2])*(d[0]-a[0])-(b[0]-a[0])*(d[2]-a[2]),nz=(b[0]-a[0])*(d[1]-a[1])-(b[1]-a[1])*(d[0]-a[0]);
    if(nx*(a[0]-c[0])+ny*(a[1]-c[1])+nz*(a[2]-c[2])<0){const q=b;b=d;d=q}
    for(const v of[a,b,d]){P.push(v[0],v[1],v[2]);U.push(.5+(v[0]+v[2]*.7)*.1,.5+(v[1]+v[2]*.4)*.1)}
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(P,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(U,2));
  g.computeVertexNormals();g.setIndex(Array.from({length:P.length/3},(_,i)=>i));return g;
}
function makeKu(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x6a7548,kuT),g=new THREE.Group(),wheels=[],GX=1.3,glow=new THREE.MeshBasicMaterial({color:0xff7a20}),
    lasM=new THREE.MeshBasicMaterial({color:0x400000}),lockM=new THREE.MeshBasicMaterial({color:0x100800}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,CB=0x56503f,JC=0x56602f;
  g.rotation.order='YXZ';
  /* roda motriz elevada na frente, guia atras, cinco rodas de apoio e tres roletes de retorno por lado */
  const trk=trackLoop([[-2.2,.1],[2,.1],[2.9,.6],[2.9,1.1],[2.45,1.38],[-2,1.3],[-2.85,.9],[-2.85,.3]],76,.56,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,kuS,sx,.85,2.45,.5,s,wheels);wl(g,kuI,sx,.6,-2.45,.45,s,wheels);for(let i=0;i<5;i++)wl(g,kuW,sx,.5,-1.7+i*.85,.4,s,wheels).userData.b=1;for(const z of[-1.3,-.1,1.1])wl(g,gRL,sx,1.12,z,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(2.1,.55,5,'M',0,.82,-.4);H.b(1.9,.12,5.1,DK,0,.5,-.4);H.b(2.3,.14,5,'M',0,1.25,-.3);H.b(2.1,.5,.1,'M',0,.95,-2.95,.18);
  /* proa em ponta de lanca: placas laterais e glacis em V, muito inclinados, terminando numa aresta estreita */
  H.g(facet([[-1.05,.55,2],[1.05,.55,2],[1.05,1.32,2],[-1.05,1.32,2],[0,.56,3.7],[0,.84,3.7]],[[0,1,2,3],[0,4,5,3],[1,2,5,4],[3,2,5],[0,1,4]]),'M',0,0,0);
  H.g(facet([[-.3,1.32,2],[.3,1.32,2],[0,1.46,2],[-.05,.86,3.6],[.05,.86,3.6],[0,.9,3.6]],[[0,1,2],[3,4,5],[0,3,5,2],[1,4,5,2],[0,1,4,3]]),'M',0,0,0);H.c(.05,.05,.3,DK,0,.68,3.78,'z');H.b(.2,.05,.1,MT,0,.62,3.95);
  /* motor a direita com grade, brilho e ventoinha; motorista a esquerda sob a escotilha */
  H.b(.95,.1,1.2,DK,.55,1.33,1.3);for(let k=0;k<5;k++)H.b(.9,.03,.07,MT,.55,1.4,.8+k*.2);H.b(.05,.03,1,MT,.55,1.41,1.3);
  H.b(.9,.34,1.1,'M',-.55,1.47,1.3);H.b(.9,.1,.5,'M',-.55,1.58,1.95,.55);H.c(.3,.32,.08,MT,-.55,1.66,1.3,'y');
  for(let k=0;k<3;k++)H.b(.15,.07,.04,GL,-.55+(k-1)*.28,1.5,2.08,.55);
  for(const s of[-1,1]){
    H.b(.6,.05,4.9,'M',s*1.55,1.45,-.2);H.b(.05,.2,4.9,'M',s*1.85,1.35,-.2);H.b(.6,.05,.8,'M',s*1.55,1.38,2.7,.35);
    hull.add(bx(.2,.16,.1,lamp,s*.85,1.34,2.15),bx(.3,.2,.08,brkM,s*.9,.95,-3.0));
  }
  H.b(.45,.3,.9,'M',-1.55,1.62,-1.5);H.b(.4,.3,.7,'M',1.55,1.62,-1.7);H.c(.05,.05,2.6,CB,-1.5,1.52,.6,'z');H.b(.5,.12,.9,CB,1.55,1.55,.5);
  H.c(.1,.1,.6,DK,1.5,1.58,-2.65,'z');H.b(.3,.04,.6,MT,1.5,1.66,-2.65);
  for(const x of[-.6,.6])H.b(.34,.44,.16,JC,x,1,-3.05);
  for(const s of[-1,1]){H.b(.6,.3,.04,RB,s*1.55,1.25,-2.75);H.b(.6,.26,.04,RB,s*1.55,1.22,2.95,.25);H.b(.04,.04,.45,MT,s*1.05,1.52,-2.2);H.b(.04,.04,.45,MT,s*1.05,1.52,.2);H.b(.12,.14,.1,MT,s*.8,.7,-3.02);H.b(.26,.2,.14,DK,s*.85,1.4,2.12);H.b(.5,.04,.35,MT,s*1.55,1.5,-1.0)}
  hull.add(bx(.8,.03,1,glow,.55,1.355,1.3));
  H.out(hull,mat);g.add(hull);
  const kuN=numTx('SK-105');for(const s of[-1,1])stk(hull,kuN,s*1.88,1.35,-.2,s,.5,.25);
  const fan=mkFan(hull,.55,1.37,1.3,4,.3),ant=mkAnt(hull,-1.55,1.5,-2.6,flagM),dl=mkLid(hull,mat,-.55,1.66,1.3,.26),drv=mkCrew(hull,cm,hm,sk,-.55,1.2,1.3);
  /* pa de ancoragem traseira: fica dobrada sobre o convés e desce quando o blindado para */
  const spade=new THREE.Group(),S=mb();spade.position.set(0,1.42,-3);
  S.b(1.9,1.2,.08,MT,0,-.6,0);for(const x of[-.65,0,.65])S.b(.1,1.1,.14,DK,x,-.6,.1);S.b(1.9,.14,.22,DK,0,-1.18,.06,.5);
  for(const s of[-1,1]){S.b(.12,.12,.5,DK,s*.8,-.1,.3);S.c(.05,.05,.9,MT,s*.85,-.3,.45,'z')}
  S.out(spade,mat);hull.add(spade);
  /* torre inferior: gira; cupula do comandante fora da torre superior, a esquerda; municiador a direita */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.38,-.5);
  T.c(1.1,1.18,.46,'M',0,.23,0,'y');T.c(1.18,1.12,.16,'M',0,.5,0,'y');T.b(1.5,.3,.5,'M',0,.35,-1.2);T.b(1.6,.3,.35,'M',0,.35,1,-.35);T.c(.28,.3,.08,MT,.88,.6,-.25,'y');
  for(const s of[-1,1])for(let k=0;k<6;k++)T.c(.055,.055,.3,DK,s*1.18,.7,-.3+k*.13,'y',0,0,-s*.5);
  T.out(tg,mat);for(const s of[-1,1])stk(tg,atT,s*1.2,.3,.25,s,.5,.5);
  const cup=new THREE.Group(),C=mb();cup.position.set(-.88,.58,-.35);
  C.c(.34,.37,.24,'M',0,.1,0,'y');C.c(.36,.36,.05,MT,0,.24,0,'y');for(let k=0;k<8;k++){const a=k/8*6.2832;C.b(.1,.07,.04,GL,Math.sin(a)*.36,.16,Math.cos(a)*.36,0,a)}
  C.out(cup,mat);tg.add(cup);tg.add(bx(.08,.26,.08,dark0,-.88,.78,.42));
  const cl=mkLid(cup,mat,0,.28,0,.26),ll=mkLid(tg,mat,.88,.64,-.25,.25),crew=mkCrew(cup,cm,hm,sk,0,-.3,0),crew2=mkCrew(tg,cm,hm,sk,.88,.1,-.25),cmg=mkMG(tg,-.88,.92,.45);
  /* torre superior oscilante: cabeca facetada em ponta, canhao de 105 mm, mira termica, telemetro a laser e anemometro */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.62,.3);
  B.b(1.5,.58,1.3,'M',0,.1,-.35);B.b(1.3,.1,1.2,'M',0,.43,-.35,.04);
  B.g(facet([[-.75,-.19,.3],[.75,-.19,.3],[.75,.39,.3],[-.75,.39,.3],[-.2,-.06,1.2],[.2,-.06,1.2],[.2,.3,1.2],[-.2,.3,1.2]],[[0,1,2,3],[4,5,6,7],[0,3,7,4],[1,2,6,5],[3,2,6,7],[0,1,5,4]]),'M',0,0,0);
  B.c(.28,.32,.4,RB,0,0,1.15,'z');
  B.b(.34,.34,.8,DK,.45,.66,.2);B.b(.24,.2,.04,GL,.45,.66,.62);B.b(.4,.04,.2,DK,.45,.86,.58);
  B.b(.5,.22,.5,DK,-.35,.6,.45);B.b(.2,.14,.2,DK,-.3,.52,-.5);
  for(const s of[-1,1]){B.b(.06,.14,.4,MT,s*.76,.3,0);B.b(.1,.1,.1,MT,s*.55,.5,.5);B.b(.08,.2,.3,'M',s*.78,.15,.6,0,s*.3)}B.b(.5,.06,.3,DK,.3,.53,-.3);
  B.c(.012,.012,.4,MT,.62,.62,-.55,'y');B.c(.05,.05,.02,DK,.62,.82,-.55,'y');
  /* caixa do carregador automatico: bandeja com tampa articulada, dois tambores de seis tiros e postigo de ejecao */
  B.b(1.6,.5,.08,'M',0,.1,-1);B.b(1.6,.06,1.2,'M',0,-.15,-1.6);B.b(.06,.5,1.1,'M',0,.1,-1.6);B.b(1.6,.15,.08,'M',0,.35,-2.2);
  for(const s of[-1,1]){B.b(.08,.5,1.2,'M',s*.8,.1,-1.6);B.b(.1,.5,.1,'M',s*.7,.1,-2.2)}
  B.out(bp,mat);
  bp.add(bx(.12,.12,.04,lasM,-.52,.62,.72),bx(.12,.12,.04,lasM,-.2,.62,.72),bx(.06,.06,.04,lockM,.62,.8,.64));
  const beam=new THREE.Mesh(new THREE.BoxGeometry(.03,.03,1).translate(0,0,.5),new THREE.MeshBasicMaterial({color:0xff2a14,transparent:true,opacity:.6,depthWrite:false}));beam.position.set(-.2,.62,.75);beam.visible=false;bp.add(beam);
  const wind=new THREE.Group();wind.position.set(.62,.84,-.55);for(let k=0;k<3;k++){const a=new THREE.Group();a.rotation.y=k*2.094;a.add(bx(.2,.012,.012,dark0,.1,0,0),new THREE.Mesh(new THREE.SphereGeometry(.035,6,4),dark0).translateX(.2));wind.add(a)}bp.add(wind);
  const cap=new THREE.Group();cap.position.set(.45,.78,.64);cap.add(bx(.3,.22,.04,dark,0,-.11,0));bp.add(cap);
  const lidA=new THREE.Group();lidA.position.set(0,.36,-1.04);lidA.add(new THREE.Mesh(new THREE.BoxGeometry(1.55,.05,1.2),mat).translateZ(-.6));bp.add(lidA);
  const dr=[-1,1].map(s=>{const d=new THREE.Group(),sh=[];d.position.set(s*.4,.12,-1.6);d.userData.tr=0;
    d.add(new THREE.Mesh(new THREE.CylinderGeometry(.34,.34,.36,16),dark),new THREE.Mesh(new THREE.CylinderGeometry(.1,.1,.46,8),new THREE.MeshLambertMaterial({color:MT})));
    for(let k=0;k<6;k++){const a=k/6*6.2832,m=new THREE.Mesh(shG,brM);m.position.set(Math.sin(a)*.22,.2,Math.cos(a)*.22);d.add(m);sh.push(m)}
    d.userData.sh=sh;bp.add(d);return d});
  const flap=new THREE.Group();flap.position.set(0,-.1,-2.22);flap.add(bx(1.4,.4,.05,mat,0,.2,0));bp.add(flap);
  /* canhao longo com evacuador de gases e freio de boca de dois defletores */
  K.c(.14,.12,.9,DK,0,0,1.3,'z');K.c(.11,.09,1.2,DK,0,0,2.2,'z');K.c(.085,.085,3.2,DK,0,0,3.8,'z');
  for(const z of[1.9,2.2,2.5])K.c(.125,.125,.07,MT,0,0,z,'z');
  K.c(.16,.16,.75,DK,0,0,3.3,'z');for(const z of[2.93,3.12,3.3,3.48,3.67])K.c(.175,.175,.05,MT,0,0,z,'z');
  K.b(.28,.28,.5,DK,0,0,5.3);for(const z of[5.1,5.27,5.44])K.b(.38,.38,.045,DK,0,0,z);K.c(.19,.19,.05,MT,0,0,5.6,'z');
  for(const s of[-1,1])for(const z of[5.18,5.36])K.b(.05,.22,.1,RB,s*.2,0,z);for(const z of[5.18,5.36])K.b(.2,.05,.1,RB,0,.2,z);
  K.out(bar,mat);
  const fl=mkFl(bar,5.85,.5,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  const kt=fin(base({g,tg,bp,bar,hull,ant,cup,fan,glow,lasM,lockM,beam,wind,cap,spade,lidA,dl,drv,crew,crew2,dr,flap,lid:[cl,ll],cmg,fl,brkM,wheels,trk,mat,dark,ku:true,cannon:true,spd:1.35,trn:1.1,L:3,W:1.7,mz:5.7,fk:1.5,rld:3.1,wd:1.5,armor:.88,hp:80,TY:1.38}));kt.beam.castShadow=false;return kt;
}
function animKu(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.glow.color.set(0x220000);t.lasM.color.set(0x220000);t.lockM.color.set(0x220000);t.drv.visible=false;t.crew2.visible=false;
    t.dl.rotation.x=-1.5;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.flap.rotation.x=-1.4;t.lidA.rotation.x=1.2;t.cap.rotation.x=-1.5;t.spade.rotation.x=.28;
    if(t.ck===undefined)t.ck=6;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;
      if(t.ckt<=0){t.ckt=.08+Math.random()*.1;const h=[[.4,.6,-1.6],[-.4,.6,-1.6],[0,.3,-2.1]][(Math.random()*3)|0];t.bp.localToWorld(v2.set(h[0],h[1],h[2])); /* os tambores de municao explodem */
        puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.1,5,.55,9);puff(v2,0x1f1e1c,1.5,3,1.6,5);if(Math.random()<.25){puff(v2,0xff6a20,2.4,8,.4,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY);
  }
  const th=clamp(Math.abs(t.v)/16,0,1),d=trkStep(t,dt,1.3),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),u=t.clk-t.lf;
  /* mira estabilizada: parado por cerca de 1 s o telemetro trava, a pa desce e a recarga cai uns 35% */
  const still=Math.abs(t.v)<.6&&Math.abs(t.st||0)<.15,az=t.isPlayer?zf:0;
  t.stead=clamp((t.stead||0)+(still?dt/1.2:-dt*1.8),0,1);t.rld=3.1-1.1*t.stead;
  t.spU=(t.spU||0)+((t.stead>.45?1:0)-(t.spU||0))*Math.min(1,dt*3.2);t.spade.rotation.x=-1.45+t.spU*1.73;
  if(t.spU>.9){if(!t.spL){t.spL=1;t.g.localToWorld(v2.set(0,.3,-3.3));for(let i=0;i<5;i++)puff(v2,0xa89a78,1.2,2.5,.8,1.2)}}else if(t.spU<.6)t.spL=0;
  for(const w of t.wheels){w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*12+w.position.z*2.1)*.03*th}
  const ank=1-.7*t.stead;
  t.hull.position.y=Math.sin(now*38+t.x)*(.006+.012*th)+(1-th)*.003*Math.sin(now*55)-t.recoil*.02*ank;t.bp.position.z=.3-t.recoil*.07;t.wind.rotation.y+=dt*(3+th*14);t.hull.rotation.x=-ac*.004-t.recoil*.02*ank;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.fan.rotation.y+=dt*(12+th*34);t.glow.color.setHSL(.07,1,.3+.25*th+.08*Math.sin(now*22));
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.7+t.x)*1.4;
  /* mira: tampa da lente abre, laser pulsa mais rapido e a luz fica verde quando o alvo esta travado; abre tambem ao usar o zoom */
  const lk=Math.max(t.stead,az),pul=.5+.5*Math.sin(now*(6+22*lk));
  t.cap.rotation.x+=(-lk*1.5-t.cap.rotation.x)*Math.min(1,dt*6);
  t.lasM.color.setRGB(.25+.75*lk*pul,.02,.02);
  t.lockM.color.setRGB(t.stead>.97?.1:.5*Math.max(0,Math.sin(now*10))*t.stead,t.stead>.97?1:.35*t.stead,.05);
  /* laser visivel: mira no alvo mais proximo na frente do canhao enquanto trava ou usa o zoom */
  t.kBt=(t.kBt||0)-dt;if(t.kBt<=0){t.kBt=.25;let best=260,bo=null;for(const o of tanks)if(!o.dead&&hostile(t,o)){const dx=o.x-t.x,dz=o.z-t.z,dd=Math.hypot(dx,dz);if(dd<best&&Math.abs(angDiff(Math.atan2(dx,dz),t.yaw))<.3){best=dd;bo=o}}t.kBo=bo}
  const bo=t.kBo;t.beam.visible=!!bo&&!bo.dead&&(t.stead>.6||az>.5);
  if(t.beam.visible){v1.set(bo.x,bo.y+1.3,bo.z);t.beam.lookAt(v1);t.beam.getWorldPosition(v2);t.beam.scale.z=Math.max(1,v2.distanceTo(v1));t.beam.material.opacity=.35+.25*Math.sin(now*45)}
  /* carregador automatico: cada tiro gira um tambor 60 graus, some um cartucho, a tampa e o postigo abrem; sem municao, recarrega */
  if(t.kLf===undefined){t.kLf=t.lf;t.kAm=12;t.kRt=0;t.kFo=0}
  if(t.lf!==t.kLf){t.kLf=t.lf;
    if(t.kAm>0){const i=12-t.kAm,q=t.dr[i&1];q.userData.sh[i>>1].visible=false;q.userData.tr+=Math.PI/3;t.kAm--;
      t.bp.localToWorld(v2.set(0,.3,-2.3));puff(v2,0xd9b24a,.25,3,.7,1.6);puff(v2,0xd9b24a,.25,2,.6,1.2);puff(v2,0xcfc8b8,.5,1,.6,.8);if(!t.kAm)t.kRt=.01}
    for(const s of[-1,1]){t.bar.localToWorld(v2.set(s*.3,0,5.25));puff(v2,0xe6dcc8,1.1,3,.6,1.8)}
    t.kEv=.45}
  if(t.kEv>0){t.kEv-=dt;t.kEt=(t.kEt||0)-dt;if(t.kEt<=0){t.kEt=.07;t.bar.localToWorld(v2.set(0,.1,3.3));puff(v2,0xcfc8b8,.35,1.2,.8,.4)}}
  if(t.kRt>0){t.kRt+=dt;if(t.kRt>.6){const n=Math.min(12,((t.kRt-.6)/.22)|0);for(let i=0;i<12;i++)t.dr[i&1].userData.sh[i>>1].visible=i<n;if(n>=12){t.kRt=0;t.kAm=12}}}
  t.dr.forEach((q,i)=>{if(t.kRt>0)q.userData.tr+=dt*5*(i?-1:1);q.rotation.y+=(q.userData.tr-q.rotation.y)*Math.min(1,dt*10)});
  t.kFo+=(((u<.45||t.kRt>0)?1:0)-t.kFo)*Math.min(1,dt*9);t.flap.rotation.x=-t.kFo*(t.kRt>0?1.45:.9);t.lidA.rotation.x=t.kFo*(t.kRt>0?1.25:.7);
  tankFx(t,dt,now,th,{ex:[[1.5,1.58,-2.95]],dk:[[1.4,.2,-2.6],[-1.4,.2,-2.6],[1.4,.2,2.6],[-1.4,.2,2.6]],mz:5.7,rr:1.5,rc:.8});
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  t.crew2.visible=t.open>.6;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);smokeQ(t,dt,1.1,.65,-.3);
}
/* ======================================================================
   AMX-10RC (Franca) e Rooikat (Africa do Sul): blindados de rodas de flanqueamento rapido
   ====================================================================== */
function mkWheel(R,W,lugs,bolts){
  const A=Math.PI/2,l=[vcol(new THREE.CylinderGeometry(R,R,W,22).rotateZ(A),0x1b1b1a),vcol(new THREE.CylinderGeometry(R*.6,R*.6,W+.05,16).rotateZ(A),0x4a4b42),vcol(new THREE.CylinderGeometry(R*.3,R*.3,W+.1,12).rotateZ(A),0x2b2d28)];
  for(let k=0;k<lugs;k++){const a=k/lugs*6.283,b=new THREE.BoxGeometry(W*1.04,.12,R*.3);b.rotateX(A-a);b.translate(0,Math.sin(a)*(R+.03),Math.cos(a)*(R+.03));l.push(vcol(b,0x151514))}
  for(let k=0;k<bolts;k++){const a=k/bolts*6.283,b=new THREE.CylinderGeometry(.04,.04,W+.14,6).rotateZ(A);b.translate(0,Math.sin(a)*R*.45,Math.cos(a)*R*.45);l.push(vcol(b,0x6a6b60))}
  return mergeG(l);
}
const BXF=[[0,1,2,3],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]];
const arT=camT(['#c6bd94','#8c9466','#6d7448']),rkT=camT(['#a89c78','#7d7a4e','#59603a']),arW=mkWheel(.62,.5,16,6),rkW=mkWheel(.72,.56,20,8);
/* ---------- AMX-10RC: 6x6 anfibio, torre baixa e angular, canhao de 105 mm, aleta de flutuacao ---------- */
function makeAMR(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x6a7048,arT),led=new THREE.MeshBasicMaterial({color:0xff2a1a}),g=new THREE.Group(),wheels=[],steers=[],DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,JC=0x56602f;
  g.rotation.order='YXZ';
  const AX=[2.4,.9,-2.2]; /* dois eixos dianteiros proximos e esterçantes, um traseiro afastado */
  for(const s of[-1,1])AX.forEach((z,i)=>{
    const w=new THREE.Mesh(arW,vcM);w.userData={r:.62};wheels.push(w);
    if(i<2){const sg=new THREE.Group();sg.position.set(s*1.5,.62,z);sg.add(w,bx(.2,.2,.5,dark,-s*.3,.15,0));g.add(sg);steers.push({g:sg,k:i?.6:1})}
    else{w.position.set(s*1.5,.62,z);g.add(w,bx(.2,.2,.5,dark,s*1.2,.77,z))}
  });
  const hull=new THREE.Group(),H=mb();
  H.b(2.5,.7,4.9,'M',0,1,-.75);H.b(2.3,.14,6.2,DK,0,.62,0);H.b(2.7,.4,4.4,'M',0,1.45,-.9);
  H.g(facet([[-1.3,.65,1.2],[-1.3,.65,3.1],[-1.3,.95,3.2],[-1.3,1.66,1.2],[1.3,.65,1.2],[1.3,.65,3.1],[1.3,.95,3.2],[1.3,1.66,1.2]],BXF),'M',0,0,0);
  H.b(2.5,.8,.14,'M',0,1.05,-3.25);H.b(1.6,.5,.05,DK,0,1.05,-3.33);H.b(2.4,.1,.1,MT,0,.65,3.18);
  H.b(.8,.25,.6,'M',0,1.6,1.55,.3);for(let k=0;k<3;k++)H.b(.15,.07,.04,GL,-.22+k*.22,1.6,1.87,.3);
  H.b(2,.05,1,DK,0,1.67,-2.6);for(let k=0;k<5;k++)H.b(1.8,.04,.08,MT,0,1.7,-3+k*.2);H.c(.12,.14,.9,MT,-1.1,1.77,-2.9,'z');
  for(const s of[-1,1]){
    for(const z of AX){H.b(.75,.08,1.4,'M',s*1.5,1.3,z);H.b(.06,.3,1.4,'M',s*1.85,1.15,z)}
    H.c(.2,.24,.6,DK,s*.8,.95,-3.5,'z');H.b(.2,.2,.3,MT,s*.8,.7,3.3);H.b(.5,.3,.9,'M',s*1.55,1.5,-2.2);H.b(.25,.4,.3,JC,s*1.6,1.55,1.2);H.b(.05,.05,3,MT,s*1.1,1.7,-.6);
    hull.add(bx(.3,.18,.1,lamp,s*.95,.82,3.22),bx(.3,.2,.08,brkM,s*1,1.1,-3.34));
  }
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.1,1.65,-2.5,flagM);
  /* aleta de flutuacao: dobrada sobre o glacis, sobe na agua */
  const vane=new THREE.Group();vane.position.set(0,.98,3.22);vane.rotation.x=.35;vane.add(bx(2.1,.05,1,mat,0,0,-.5),bx(2.1,.08,.06,dark,0,0,-1),bx(.08,.08,1,dark,-.8,.04,-.5),bx(.08,.08,1,dark,.8,.04,-.5));hull.add(vane);
  /* torre baixa e angular de canhao de 105 mm */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.65,.1);
  T.c(1.15,1.2,.14,'M',0,.07,0,'y');
  T.g(facet([[-1.1,.1,-1.2],[1.1,.1,-1.2],[1.1,.1,1],[-1.1,.1,1],[-.8,.62,-1],[.8,.62,-1],[.8,.55,.5],[-.8,.55,.5]],BXF),'M',0,0,0);
  T.g(facet([[-.95,.1,-1.1],[.95,.1,-1.1],[.95,.1,-1.9],[-.95,.1,-1.9],[-.7,.58,-1],[.7,.58,-1],[.7,.4,-1.75],[-.7,.4,-1.75]],BXF),'M',0,0,0);
  for(const s of[-1,1]){T.b(.5,.42,.8,'M',s*.62,.33,1.05,0,s*.35);for(let k=0;k<4;k++)T.c(.05,.05,.3,DK,s*1,.45,.4+k*.12-.5,'y',0,0,-s*.7)}
  T.c(.36,.4,.2,MT,.55,.7,-.45,'y');for(let k=0;k<6;k++){const a=k/6*6.283;T.b(.12,.08,.06,GL,.55+Math.sin(a)*.38,.8,-.45+Math.cos(a)*.38,0,a)}
  T.c(.38,.4,.1,MT,-.55,.65,-.55,'y');T.b(.4,.26,.4,DK,-.6,.72,.2);T.b(.26,.12,.04,GL,-.6,.74,.41);T.b(.3,.2,.3,DK,.4,.62,.15);
  T.out(tg,mat);tg.add(bx(.08,.06,.08,led,-.2,.6,.35));
  const cl=mkLid(tg,mat,.55,.82,-.45,.34),ll=mkLid(tg,mat,-.55,.72,-.55,.32),crew=mkCrew(tg,cm,hm,sk,.55,.55,-.45),cmg=mkMG(tg,-.1,.66,-.8);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.38,1.35);
  B.b(1,.5,.35,'M',0,0,.15);B.c(.26,.3,.3,RB,0,0,.4,'z');B.c(.04,.04,.7,DK,.38,-.03,.6,'z');B.b(.25,.2,.06,GL,-.42,.1,.34);B.out(bp,mat);
  K.c(.13,.13,4.6,DK,0,0,2.6,'z');K.c(.18,.18,1.4,'M',0,0,1.6,'z');K.c(.18,.18,1.1,'M',0,0,3,'z');for(const z of[.9,2.3,3.6])K.c(.2,.2,.07,DK,0,0,z,'z');K.c(.16,.16,.35,DK,0,0,4.75,'z');K.out(bar,mat);
  const fl=mkFl(bar,5.2,.5,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,vane,led,lid:[cl,ll],crew,cmg,fl,brkM,wheels,steers,mat,dark,amr:true,cannon:true,spd:1.7,trn:1.15,L:3.2,W:1.5,mz:5,fk:1.1,rld:1.5,wd:2.6,armor:.85,hp:85,TY:1.65}));
}
function animAMR(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/16,0,1),ph=t.v*dt,ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),wet=t.wet||0;
  for(const w of t.wheels)w.rotation.x+=ph/.62;
  for(const s of t.steers)s.g.rotation.y+=((t.st||0)*.45*s.k-s.g.rotation.y)*Math.min(1,dt*6);
  /* suspensao hidropneumatica: sobe em velocidade, agacha parado, empina ao acelerar */
  t.hy=(t.hy||0)+((th>.45?.07:th<.05?-.04:0)-(t.hy||0))*Math.min(1,dt*2);t.pt=(t.pt||0)+(clamp(-ac*.004,-.05,.05)-(t.pt||0))*Math.min(1,dt*5);
  const by=t.hy+Math.sin(now*34+t.x)*(.008+.012*th)-t.recoil*.03;
  t.hull.position.y=by;t.tg.position.y=t.TY+by;t.hull.rotation.x=t.pt-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.vn=(t.vn||.35)+((wet>.25?1.4:.35)-(t.vn||.35))*Math.min(1,dt*3);t.vane.rotation.x=t.vn;
  if(wet>.25&&Math.abs(t.v)>1){t.jt=(t.jt||0)-dt;if(t.jt<=0){t.jt=.07;for(const s of[-1,1]){t.g.localToWorld(v2.set(s*.8,.2,-4.2));puff(v2,0xe6f3fa,.8,3,.6,1.2)}}}
  t.led.color.setHex(Math.sin(now*5)>.3?0xff2a1a:0x300800);t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  tankFx(t,dt,now,th,{ex:[[-1.1,1.8,-3.7]],dk:[[1.5,.2,-2.6],[-1.5,.2,-2.6]],mz:5,rr:1.3,rc:.9});
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);smokeQ(t,dt,1,.45,.2);
}
/* ---------- Rooikat (Africa do Sul): 8x8, casco longo em ponta de lanca, torre em cunha, canhao de 76 mm ---------- */
function makeRoo(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x6b6a45,rkT),led=new THREE.MeshBasicMaterial({color:0xff2a1a}),g=new THREE.Group(),wheels=[],steers=[],DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,JC=0x56602f;
  g.rotation.order='YXZ';
  const AX=[2.3,.6,-1.15,-2.9];
  for(const s of[-1,1])AX.forEach((z,i)=>{
    const w=new THREE.Mesh(rkW,vcM);w.userData={r:.72};wheels.push(w);
    if(i<2){const sg=new THREE.Group();sg.position.set(s*1.55,.72,z);sg.add(w,bx(.2,.22,.5,dark,-s*.3,.15,0));g.add(sg);steers.push({g:sg,k:i?.65:1})}
    else{w.position.set(s*1.55,.72,z);g.add(w,bx(.2,.22,.5,dark,s*1.25,.87,z))}
  });
  const hull=new THREE.Group(),H=mb();
  H.b(2.5,.85,6.6,'M',0,1.3,-.5);H.b(1.2,.1,6.4,DK,0,.62,-.5);
  H.g(facet([[-1.25,.85,2.8],[1.25,.85,2.8],[1.25,1.725,2.8],[-1.25,1.725,2.8],[0,1,4.4],[0,1.4,4.4]],[[0,1,2,3],[0,3,5,4],[1,2,5,4],[3,2,5],[0,1,4]]),'M',0,0,0);
  H.b(2.2,.14,5,'M',0,1.78,-1.2);for(let k=0;k<6;k++)H.b(1.8,.04,.07,MT,0,1.87,-3.5+k*.25);
  H.b(.8,.28,.8,'M',0,1.86,2.15);H.b(.5,.1,.04,GL,0,1.9,2.57);H.b(1.4,.1,.1,MT,0,1.05,4.1);
  for(const s of[-1,1]){
    H.b(.9,.1,6.3,'M',s*.95,.8,-.5,0,0,s*.4);
    for(const z of AX){H.b(.95,.08,1.5,'M',s*1.55,1.52,z);H.b(.06,.28,1.5,'M',s*2,1.38,z)}
    H.b(.8,.4,.05,RB,s*1.55,1.3,3.07);H.b(.8,.4,.05,RB,s*1.55,1.3,-3.67);
    H.b(.5,.3,1,DK,s*1.55,1.73,.6);H.b(.5,.3,1,DK,s*1.55,1.73,-1.15);H.b(.3,.4,.2,JC,s*.8,2.05,-3.4);
    H.c(.14,.16,.8,DK,s*.9,1.2,-4,'z');H.b(.4,.3,.3,MT,s*.9,1.2,-3.85);H.b(.2,.2,.3,MT,s*.5,.95,3.9);
    hull.add(bx(.28,.18,.1,lamp,s*.8,1.35,3.4),bx(.3,.2,.08,brkM,s*1,1.1,-3.84));
  }
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1,1.85,-3.5,flagM);
  const ant2=new THREE.Group();ant2.position.set(1,1.85,-3.5);const r2=new THREE.Mesh(new THREE.CylinderGeometry(.012,.025,2.6,5),dark);r2.position.y=1.3;ant2.add(r2);hull.add(ant2);
  /* torre em cunha estendida para tras, com porta traseira de municao */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.85,-.4);
  T.c(1.2,1.2,.14,'M',0,.07,0,'y');
  T.g(facet([[-1.15,.1,-2.4],[1.15,.1,-2.4],[1.15,.1,1.1],[-1.15,.1,1.1],[-.85,.82,-2],[.85,.82,-2],[.7,.45,.2],[-.7,.45,.2]],BXF),'M',0,0,0);
  for(const s of[-1,1])for(let k=0;k<4;k++)T.c(.05,.05,.3,DK,s*1.08,.42,-.5+k*.15,'y',0,0,-s*.5);
  T.c(.36,.4,.2,MT,.5,.76,-.9,'y');for(let k=0;k<6;k++){const a=k/6*6.283;T.b(.12,.08,.06,GL,.5+Math.sin(a)*.38,.86,-.9+Math.cos(a)*.38,0,a)}
  T.c(.38,.4,.1,MT,-.5,.72,-1.3,'y');T.b(.4,.28,.4,DK,-.45,.7,-.1);T.b(.26,.12,.04,GL,-.45,.72,.11);T.b(.3,.2,.3,DK,.3,.55,.05);
  T.out(tg,mat);tg.add(bx(.08,.06,.08,led,0,.68,-.3));
  const rd=new THREE.Group();rd.position.set(0,.8,-1.98);const rdp=bx(1.1,.7,.05,dark,0,-.36,-.2);rdp.rotation.x=.51;rd.add(rdp);tg.add(rd);
  const cl=mkLid(tg,mat,.5,.88,-.9,.34),ll=mkLid(tg,mat,-.5,.84,-1.3,.32),crew=mkCrew(tg,cm,hm,sk,.5,.62,-.9),cmg=mkMG(tg,.05,.68,-1.5);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.3,1.2);
  B.b(.9,.5,.4,'M',0,0,.15);B.c(.22,.26,.3,RB,0,0,.4,'z');B.c(.04,.04,.8,DK,.34,-.03,.6,'z');B.b(.22,.18,.06,GL,-.4,.1,.34);B.out(bp,mat);
  K.c(.1,.1,5.4,DK,0,0,3.2,'z');K.c(.15,.15,1.4,'M',0,0,1.3,'z');K.c(.17,.17,.6,'M',0,0,3.4,'z');for(const z of[.8,2.1,4.2])K.c(.18,.18,.07,DK,0,0,z,'z');K.c(.15,.15,.55,DK,0,0,5.7,'z');K.b(.38,.1,.3,DK,0,0,5.7);K.out(bar,mat);
  const fl=mkFl(bar,6.1,.45,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,ant2,rd,led,lid:[cl,ll],crew,cmg,fl,brkM,wheels,steers,mat,dark,roo:true,cannon:true,spd:1.9,trn:1,L:3.6,W:1.55,mz:6,fk:.9,rld:1.4,wd:1.9,armor:.85,hp:105,TY:1.85}));
}
function animRoo(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/17,0,1),ph=t.v*dt,ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  for(const w of t.wheels)w.rotation.x+=ph/.72;
  for(const s of t.steers)s.g.rotation.y+=((t.st||0)*.4*s.k-s.g.rotation.y)*Math.min(1,dt*6);
  /* suspensao hidropneumatica: ao rodar rapido o casco sobe, empina ao acelerar e inclina forte nas curvas */
  t.hy=(t.hy||0)+((th>.4?.09:th<.05?-.03:.02)-(t.hy||0))*Math.min(1,dt*2);t.pt=(t.pt||0)+(clamp(-ac*.005,-.06,.06)-(t.pt||0))*Math.min(1,dt*5);
  const by=t.hy+Math.sin(now*36+t.x)*(.008+.014*th)-t.recoil*.03;
  t.hull.position.y=by;t.tg.position.y=t.TY+by;t.hull.rotation.x=t.pt-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.045;
  t.rd.rotation.x+=((t.clk-t.lf<.8?.95:0)-t.rd.rotation.x)*Math.min(1,dt*7);
  t.led.color.setHex(Math.sin(now*4)>.3?0xff2a1a:0x300800);
  t.ant.rotation.x=-t.v*.014+Math.sin(now*3+t.z)*.03;t.ant2.rotation.x=-t.v*.016+Math.sin(now*2.6+t.x)*.04;t.ant2.rotation.z=Math.sin(now*2+t.z)*.03;
  tankFx(t,dt,now,th,{ex:[[.9,1.25,-4.3],[-.9,1.25,-4.3]],dk:[[1.55,.2,-3.4],[-1.55,.2,-3.4],[1.55,.2,-1.5],[-1.55,.2,-1.5]],mz:6,rr:1.2,rc:.8});
  mgScan(t,dt,60);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);smokeQ(t,dt,1.1,.45,-.3);
}
/* ======================================================================
   T-72B e T-90A (URSS / Russia): carro de combate principal, canhao liso 2A46 de 125 mm com autoloader.
   T-72B: torre fundida em cupula, Kontakt-1, farol infravermelho, snorkel que sobe na agua, saias de borracha
   T-90A: torre soldada angular, Kontakt-5, Shtora-1 (lampadas vermelhas), luva termica, anemometro
   ====================================================================== */
const t72T=camT(['#e4e8d2','#c3cba0','#97a074','#cdbf8a']);
const t90T=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);const cs=['#e6e8d6','#cfd0a8','#a9aa82','#8a8c66'];for(let i=0;i<90;i++){x.fillStyle=cs[i%4];x.fillRect((Math.random()*w/8|0)*8,(Math.random()*h/8|0)*8,8*(1+(Math.random()*3|0)),8)}});t90T.wrapS=t90T.wrapT=THREE.RepeatWrapping;
const t72N=numTx('T-72'),t90N=numTx('T-90');
const t7W=tw(.42),t7S=tw(.5,1),t7I=tw(.4),t7R=tw(.15);
const t7rub=new THREE.MeshLambertMaterial({color:0x34372d});
const t7ovG=(rt,rb,h,sx,sz)=>{const g=new THREE.CylinderGeometry(rt,rb,h,20);g.scale(sx,1,sz);g.computeVertexNormals();return g};
function buildT7x(T90,color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||(T90?0x6a7444:0x5f6e3e),T90?t90T:t72T),g=new THREE.Group(),wheels=[],GX=1.42,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,ER=T90?0x3b4330:0x4a5238,FT=0x3f4a2c,WD=0x6a5236;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-3.05,.1],[3,.1],[3.7,.5],[3.5,.92],[3,1.04],[-2.9,1.04],[-3.6,.92],[-3.7,.5]],86,.62,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    wl(g,t7S,sx,.52,-3.15,.5,s,wheels);wl(g,t7I,sx,.5,3.3,.4,s,wheels);
    for(let i=0;i<6;i++)wl(g,t7W,sx,.5,-2.15+i*.9,.42,s,wheels).userData.b=1;
    for(let k=0;k<3;k++)wl(g,t7R,sx,.98,-1.8+k*1.8,.15,s,wheels)});
  /* ---- casco ---- */
  const hull=new THREE.Group(),H=mb(),sks=[],fp=[],gy=z=>.96-(z-2.4)*.3237+.1;
  H.b(2.62,.5,5.85,'M',0,.62,-.33);H.b(2.62,.36,1.2,'M',0,.42,3.05);H.b(2.4,.14,6.5,DK,0,.4,0);
  H.b(3,.24,4.5,'M',0,1.2,-.9);H.b(2.7,.14,2.21,'M',0,.96,2.4,.313);H.b(2.62,.55,.14,'M',0,.5,3.66,-.35);H.b(2.62,.6,.14,'M',0,.82,-3.3,.2);
  /* blindagem reativa no glacis: tijolos Kontakt-1 (T-72B) ou Kontakt-5 maiores (T-90A) */
  for(let r=0;r<3;r++)for(let i=-2;i<=2;i++){if(r===0&&i===0)continue;if(T90)H.b(.5,.11,.5,ER,i*.52,gy(1.8+r*.62),1.8+r*.62,.313);else H.b(.44,.08,.36,ER,i*.5,gy(1.8+r*.55),1.8+r*.55,.313)}
  for(let k=0;k<8;k++)H.b(1.3,.05,.1,MT,0,1.34,-2.9+k*.22);
  H.c(.3,.32,.1,MT,0,1.27,1.8,'y');for(let k=0;k<3;k++)H.b(.16,.08,.1,GL,(k-1)*.28,1.2,2.08);
  H.c(.13,.13,2.5,WD,0,1.2,-3.5,'x');for(const s of[-1,1])H.b(.05,.35,.05,DK,s*.9,1.1,-3.44);
  for(const s of[-1,1]){
    H.b(.62,.06,5.9,'M',s*1.55,1.1,-.1);H.b(.07,.07,5.9,MT,s*1.87,1.12,-.1);
    H.c(.045,.045,2,DK,s*.95,gy(2.4)+.03,2.4,'z',.313);
    if(s<0){for(let k=0;k<3;k++){H.c(.2,.2,1.05,FT,-1.62,1.3,-2.5+k*1.3,'z');H.c(.21,.21,.05,DK,-1.62,1.3,-2.5+k*1.3,'z')}}
    else{H.b(.42,.3,1,MT,1.62,1.28,-1.35);H.b(.4,.24,.9,'M',1.62,1.25,-.3);H.c(.14,.14,.9,DK,1.62,1.26,1.4,'z');H.b(.45,.3,.6,DK,1.55,1.28,-2.75);H.c(.1,.1,.5,MT,1.55,1.38,-3.1,'z')}
    hull.add(bx(.28,.14,.2,lamp,s*1.1,.78,3.38),bx(.3,.18,.08,brkM,s*1,.72,-3.44));
    if(!T90){H.c(.27,.27,1,FT,s*.98,1.6,-2.75,'z');for(const dz of[-.3,.3])H.c(.28,.28,.05,DK,s*.98,1.6,-2.75+dz,'z')}
    else{H.b(.5,.4,.9,'M',s*1.0,1.52,-2.7);H.b(.5,.04,.9,MT,s*1.0,1.73,-2.7)}
    for(let k=0;k<6;k++){const p=new THREE.Group();p.position.set(s*1.87,1.1,-2.55+k*.95);p.add(new THREE.Mesh(new THREE.BoxGeometry(.05,.5,.9),t7rub).translateY(-.25));
      if(T90&&k>=3)p.add(bx(.08,.3,.72,ER,s*.05,-.2,0));p.userData.s=s;hull.add(p);sks.push(p)}
    const f=new THREE.Group();f.position.set(s*1.84,1.1,3.4);f.add(bx(.05,.6,.7,t7rub,0,-.3,0));hull.add(f);fp.push(f);
  }
  H.out(hull,mat);g.add(hull);
  const ant=mkAnt(hull,1.45,1.35,-2.6,flagM);
  /* aleta de proa (trim vane): deitada no glacis, sobe sozinha ao entrar na agua */
  const vane=new THREE.Group();vane.position.set(0,.78,3.5);vane.add(new THREE.Mesh(new THREE.BoxGeometry(2.3,.05,.8),mat).translateZ(-.4));vane.rotation.x=.313;hull.add(vane);
  /* snorkel: tubo deitado sobre o convés, que se levanta e estica para atravessar rios fundos */
  const snk=new THREE.Group();snk.position.set(0,1.45,-2.95);snk.add(new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,1.4,8),dark).translateY(.7));
  const snx=new THREE.Group();snx.position.y=.3;snx.add(new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,1,8),dark).translateY(.5),new THREE.Mesh(new THREE.CylinderGeometry(.13,.07,.12,8),dark).translateY(1));snk.add(snx);snk.rotation.x=Math.PI/2;hull.add(snk);
  /* escotilha e tripulante do motorista */
  const dl=mkLid(hull,mat,0,1.34,1.8,.28),drv=mkCrew(hull,cm,hm,sk,0,1.0,1.8);
  /* ---- torre ---- */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.32,.2);
  const irM=new THREE.MeshBasicMaterial({color:0x4a1410}),shM=new THREE.MeshBasicMaterial({color:0xb01a14}),alM=new THREE.MeshBasicMaterial({color:0x30d060});
  let ir=null,wind=null,sh=null;
  if(!T90){
    T.g(t7ovG(1.22,1.3,.2,1,1.15),'M',0,.1,0);T.g(t7ovG(1.02,1.24,.52,1,1.2),'M',0,.46,.05);T.g(t7ovG(.62,.98,.16,1,1.15),'M',0,.8,0);
    T.b(1,.64,.55,'M',0,.45,1.45);T.b(1.9,.5,.5,'M',0,.5,-1.55);T.b(1.7,.04,.46,MT,0,.78,-1.55);
    for(let i=-3;i<=3;i++){const a=i*.32;T.b(.4,.13,.3,ER,Math.sin(a)*.95,.78,.2+Math.cos(a)*.98,0,a)}
    T.b(.9,.1,.3,ER,0,.77,1.5);
    for(const s of[-1,1])for(let k=0;k<4;k++)T.c(.055,.055,.28,DK,s*[1.06,1.02,.92,.8][k],.7,.35+k*.22,'y',0,0,-s*.9);
    T.b(.34,.28,.34,DK,.62,.62,1.0);T.b(.22,.14,.04,GL,.62,.64,1.19);
    T.c(.34,.36,.1,MT,.55,.84,-.05,'y');T.c(.36,.4,.1,MT,-.55,.9,-.3,'y');
    ir=new THREE.Group();ir.position.set(-.66,.62,1.0);ir.add(bx(.5,.42,.5,dark,0,0,0),new THREE.Mesh(new THREE.CylinderGeometry(.17,.17,.06,12).rotateX(Math.PI/2),irM).translateZ(.27),bx(.56,.06,.56,dark,0,.24,0));tg.add(ir);
  }else{
    const P=[[-.45,1.7],[.45,1.7],[1.25,.7],[1.3,-.4],[1,-1.5],[-1,-1.5],[-1.3,-.4],[-1.25,.7]],V=[],F=[[0,1,2,3,4,5,6,7],[8,9,10,11,12,13,14,15]];
    P.forEach(p=>V.push([p[0],.15,p[1]]));P.forEach(p=>V.push([p[0]*.86,.87,p[1]*.86]));for(let i=0;i<8;i++)F.push([i,(i+1)%8,8+(i+1)%8,8+i]);
    T.g(facet(V,F),'M',0,0,0);T.c(1.2,1.25,.22,'M',0,.1,0,'y');
    T.b(1.7,.45,.5,'M',0,.45,-1.78);T.b(1.5,.04,.46,MT,0,.7,-1.78);
    for(const s of[-1,1]){
      for(let k=0;k<4;k++){if(k===1)continue;const u=(k+.5)/4,ang=Math.atan2(s*.8,-1);T.b(.1,.5,.26,ER,s*(.45+.8*u)+s*.09,.52,1.7-u-.07+.06,0,ang)}
      for(let k=0;k<4;k++)T.b(.08,.45,.28,ER,s*1.33,.52,.5-k*.3);
      T.b(.14,.14,.14,GL,s*1.05,.9,.55);T.b(.14,.14,.14,GL,s*.8,.9,-1.05);
      T.b(.46,.4,.36,DK,s*.74,.5,1.32);T.b(.4,.06,.4,MT,s*.74,.72,1.3);
    }
    T.b(.34,.28,.34,DK,.62,.99,.9);T.b(.22,.14,.04,GL,.62,1.0,1.08);
    T.c(.34,.36,.1,MT,.55,.9,-.05,'y');T.c(.36,.4,.1,MT,-.55,.93,-.35,'y');
    for(let k=0;k<3;k++)for(const s of[-1,1])T.c(.055,.055,.28,DK,s*1.1,.82,.3+k*.22,'y',0,0,-s*.9);
    T.c(.02,.02,.5,MT,.78,1.12,-1.05,'y');
    sh=new THREE.Group();for(const s of[-1,1])sh.add(bx(.38,.3,.04,shM,s*.74,.5,1.51));tg.add(sh);
    wind=new THREE.Group();wind.position.set(.78,1.4,-1.05);for(let k=0;k<3;k++){const a=k*2.094,arm=bx(.3,.02,.02,dark,Math.sin(a)*.15,0,Math.cos(a)*.15);arm.rotation.y=a-Math.PI/2;wind.add(arm,new THREE.Mesh(new THREE.SphereGeometry(.05,6,5),dark).translateX(Math.sin(a)*.3).translateZ(Math.cos(a)*.3))}tg.add(wind);
  }
  T.out(tg,mat);
  for(const s of[-1,1])stk(tg,T90?t90N:t72N,s*(T90?1.225:1.16),T90?.5:.45,T90?-.3:-.3,s,.8,.4);
  /* cupula do comandante (gira vigiando), escotilhas, MG e lampada do autoloader */
  const cupY=T90?.93:.9,cup=new THREE.Group();cup.position.set(-.55,cupY+.08,T90?-.35:-.3);cup.add(new THREE.Mesh(new THREE.CylinderGeometry(.34,.36,.14,10),dark));
  for(let k=0;k<5;k++){const a=k/5*6.283,m=bx(.12,.06,.04,gl,Math.sin(a)*.34,.06,Math.cos(a)*.34);m.rotation.y=a;cup.add(m)}tg.add(cup);
  const cl=mkLid(tg,mat,-.55,cupY+.18,T90?-.35:-.3,.26),ll=mkLid(tg,mat,.55,T90?.96:.94,-.05,.3),crew=mkCrew(tg,cm,hm,sk,-.55,cupY-.24,T90?-.35:-.3),cmg=mkMG(tg,-.55,cupY+.25,T90?-.1:-.12);
  tg.add(new THREE.Mesh(new THREE.BoxGeometry(.12,.06,.12),alM).translateX(.2).translateY(T90?.9:.88).translateZ(.35));
  /* porta traseira que ejeta o estojo a cada tiro */
  const ej=new THREE.Group();ej.position.set(0,T90?.62:.6,T90?-2.06:-1.82);ej.add(bx(.5,.3,.05,dark,0,-.15,0));tg.add(ej);
  /* canhao */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,T90?1.5:1.75);
  if(T90)B.b(.9,.66,.5,'M',0,0,0);else B.b(1,.62,.42,'M',0,0,.1);
  B.c(.27,.3,.3,RB,0,0,.4,'z');B.c(.035,.035,.85,DK,.42,-.08,.75,'z');B.b(.3,.18,.06,GL,-.35,.22,T90?.26:.33);B.out(bp,mat);
  K.c(.125,.125,5.9,DK,0,0,3.35,'z');K.c(.17,.15,1.1,'M',0,0,1.1,'z');K.c(.15,.15,.12,DK,0,0,6.3,'z');
  if(T90){K.c(.175,.175,3.9,'M',0,0,3.4,'z');for(let k=0;k<7;k++)K.c(.19,.19,.06,DK,0,0,1.6+k*.5,'z')}
  else{K.c(.185,.185,.55,'M',0,0,4.2,'z');for(const z of[3.93,4.47])K.c(.195,.195,.05,DK,0,0,z,'z')}
  K.out(bar,mat);
  const fl=mkFl(bar,6.3,.55,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,fp,sks,vane,snk,snx,cup,ir,irM,sh,shM,alM,ej,wind,lid:[cl,ll],crew,dl,drv,cmg,fl,brkM,wheels,trk,mat,dark,t72:!T90,t90:T90,cannon:true,spd:T90?1.3:1.15,trn:T90?1:.95,L:3.7,W:1.9,mz:6.2,fk:1.4,rld:T90?2.1:2.5,wd:2.8,armor:T90?.58:.7,hp:T90?115:100,TY:1.32,sn:0,eo:0,ejp:0}));
}
const makeT72=(c,f)=>buildT7x(false,c,f),makeT90=(c,f)=>buildT7x(true,c,f);
function animT7x(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.drv.visible=false;t.dl.rotation.x=-1.4;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.ej.rotation.x=1.2;t.alM.color.set(0x220000);t.irM.color.set(0x110000);t.shM.color.set(0x220000);
    if(t.ck===undefined)t.ck=6;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt; /* o carrossel do autoloader explode em chamas */
      if(t.ckt<=0){t.ckt=.09+Math.random()*.1;const h=[[.5,.9,0],[-.5,.9,.3],[0,.8,-.5],[.2,.95,.6]][(Math.random()*4)|0];t.tg.localToWorld(v2.set(h[0],h[1],h[2]));
        puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.1,5,.55,9);puff(v2,0x1f1e1c,1.5,3,1.6,5);if(Math.random()<.25){puff(v2,0xff6a20,2.4,8,.4,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY);
  }
  const th=clamp(Math.abs(t.v)/14,0,1),d=trkStep(t,dt,1.42),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),u=t.clk-t.lf;
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*11+i*1.7)*.025*th});
  t.hull.position.y=Math.sin(now*32+t.x)*(.008+.01*th)-t.recoil*.03;t.hull.rotation.x=-ac*.003-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.025;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  /* saias de borracha balancam, abas dianteiras sobem com o vento */
  t.sks.forEach((p,i)=>{p.rotation.z=p.userData.s*(.03+(.04+.1*th)*Math.sin(now*(8+th*6)+i*.9)+clamp(t.v*.004,-.08,.08))});
  for(const f of t.fp)f.rotation.x=clamp(t.v*.03,-.5,.5)+Math.sin(now*14+f.position.x)*.05*th;
  /* na agua: aleta de proa sobe e o snorkel se levanta e estica */
  const wet=t.wet||0,wk=clamp(wet/.5,0,1);t.vane.rotation.x=.313+wk*.95+Math.sin(now*12+t.z)*.02*th;
  t.sn+=((wet>.9?1:0)-t.sn)*Math.min(1,dt*1.6);t.snk.rotation.x=(1-t.sn)*Math.PI/2+Math.sin(now*3+t.x)*.012*t.sn;t.snx.position.y=.3+t.sn*1.05;
  /* cupula do comandante vigia o terreno */
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.8+t.x)*1.3*(1-t.open*.7);
  if(t.ir){t.ir.rotation.y=Math.sin(now*.9+t.x*.1)*.5;t.irM.color.setHSL(.01,.8,.12+.1*Math.sin(now*3+t.z*.1))} /* farol infravermelho varre o terreno */
  if(t.sh)t.shM.color.setHSL(0,1,.3+.2*Math.sin(now*(t.mgt?16:3.2))); /* Shtora-1 pisca mais rapido com inimigo perto */
  if(t.wind)t.wind.rotation.y+=dt*(3+Math.abs(t.v)*.4+th*8); /* anemometro */
  /* autoloader: lampada ambar enquanto recarrega, verde quando pronto; porta traseira abre para ejetar o estojo */
  t.alM.color.setHex(u<(t.rld||2.3)*1.3?0xffa020:0x30d060);
  const eo=u>.55&&u<1.6?1:0;if(eo&&!t.ejp){t.tg.localToWorld(v2.set(0,.5,t.t90?-2.2:-1.95));puff(v2,0xd9b24a,.25,3,.7,1.6);puff(v2,0xcfc8b8,.5,1,.6,.8)}
  t.ejp=eo;t.eo+=(eo-t.eo)*Math.min(1,dt*10);t.ej.rotation.x=t.eo*1.25;
  /* motor diesel V-12: fumaca preta ao acelerar */
  if(ac>3&&Math.random()<dt*10){t.g.localToWorld(v2.set(1.55,1.4,-3.5));puff(v2,0x1f1e1c,.9,1.2,1,1.4)}
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  tankFx(t,dt,now,th,{ex:[[1.55,1.4,-3.5]],dk:[[1.5,.2,-3.4],[-1.5,.2,-3.4]],mz:6.2,rr:1.1,rc:.9});
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);smokeQ(t,dt,.9,.7,.2);
}


/* ======================================================================
   Merkava Mk 4 (Israel), Boxer CRV (Australia/Alemanha) e T-80BVM (Russia)
   ====================================================================== */
const lof=(a,y0,b,y1)=>{const n=a.length,I=[...Array(n).keys()],V=[...a.map(p=>[p[0],y0,p[1]]),...b.map(p=>[p[0],y1,p[1]])],F=[I,I.map(i=>n+i)];for(let i=0;i<n;i++)F.push([i,(i+1)%n,n+(i+1)%n,n+i]);return facet(V,F)};
const mkvT=camT(['#d9cc9e','#bfb287','#a39a74','#cbbd8e']),bxrT=camT(['#8a8c64','#6c714d','#4d5439','#a29b76']),t80T=camT(['#aeb48a','#8d9568','#6b7448','#c3b98a']);
const mkvW=tw(.46),mkvS=tw(.54,1),mkvI=tw(.5),mkvR=tw(.17),bxrW=mkWheel(.68,.56,18,8),t8W=tw(.46),t8S=tw(.52,1),t8I=tw(.46),t8R=tw(.17),t8N=numTx('T-80');

/* ---------- Merkava Mk 4 (Israel): motor na frente, torre recuada com bustle de correntes, Trophy, porta traseira ---------- */
function makeMerk(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x8c8460,mkvT),g=new THREE.Group(),wheels=[],GX=1.6,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,AR=0x6e6c58,FT=0x3f4a2c;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-3.1,.1],[3,.1],[3.75,.55],[3.5,1.05],[3,1.18],[-3,1.18],[-3.8,.7],[-3.55,.15]],84,.66,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,mkvS,sx,.6,3.35,.54,s,wheels);wl(g,mkvI,sx,.52,-3.45,.5,s,wheels);
    for(let i=0;i<6;i++)wl(g,mkvW,sx,.52,-2.45+i*.95,.46,s,wheels).userData.b=1;
    for(let k=0;k<4;k++)wl(g,mkvR,sx,1.02,-2.1+k*1.55,.17,s,wheels)});
  /* ---- casco: motor na proa, glacis baixo e longo, saias modulares, aletas de borracha ---- */
  const hull=new THREE.Group(),H=mb(),sks=[],sl=Math.atan(.178),gy=z=>1.46-(z-1)*.178;
  H.b(2.9,.85,4.7,'M',0,1,-1.35);H.b(2.4,.14,7.6,DK,0,.4,0);
  H.g(facet([[-1.45,.58,1],[1.45,.58,1],[1.45,1.43,1],[-1.45,1.43,1],[-1.3,.6,3.75],[1.3,.6,3.75],[1.3,.98,3.75],[-1.3,.98,3.75]],BXF),'M',0,0,0);
  for(let k=0;k<7;k++)H.b(1.2,.05,.1,MT,.45,gy(1.5+k*.3)+.04,1.5+k*.3,sl);
  H.c(.04,.04,2.4,DK,-.9,gy(2.6)+.07,2.6,'z',sl);H.b(1,.08,.5,MT,-.4,gy(1.5)+.06,1.5,sl);
  for(const s of[-1,1]){
    H.b(.62,.1,6.9,'M',s*1.72,1.32,-.15);
    for(let k=0;k<5;k++){H.b(.12,.5,1.15,'M',s*2,1,-2.6+k*1.3);H.b(.14,.44,.06,DK,s*2,1,-1.95+k*1.3)}
    H.c(.15,.18,.8,DK,s*1.15,1.3,-3.95,'z');
    if(s>0)H.b(.5,.4,1.2,FT,1.75,1.55,-2.4);else for(let k=0;k<2;k++)H.c(.2,.2,1,FT,-1.75,1.5,-2.8+k*1.3,'z');
    hull.add(bx(.3,.18,.14,lamp,s*1.2,1.1,3.52),bx(.32,.2,.08,brkM,s*1.25,1,-3.88));
    for(let k=0;k<6;k++){const p=new THREE.Group();p.position.set(s*2.07,.78,-2.9+k*1.1);p.add(new THREE.Mesh(new THREE.BoxGeometry(.05,.45,1),t7rub).translateY(-.22));p.userData.s=s;hull.add(p);sks.push(p)}
  }
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,1.3,1.45,-3.5,flagM);
  const dl=mkLid(hull,mat,-.8,gy(2.3)+.08,2.3,.3),drv=mkCrew(hull,cm,hm,sk,-.8,.95,2.3);
  /* porta traseira (rampa de tropa) e dois soldados que desembarcam */
  const rdoor=new THREE.Group();rdoor.position.set(0,.6,-3.76);rdoor.add(bx(1.7,1.05,.1,mat,0,.52,0),bx(1.3,.8,.04,dark,0,.52,-.06),bx(.34,.07,.05,dark,.45,.62,-.1));hull.add(rdoor);
  const troops=[-.5,.5].map(x=>{const c=mkCrew(hull,cm,hm,sk,x,.02,-4.8);c.scale.setScalar(1.55);return c});
  /* ---- torre: cunha baixa e larga, bustle traseiro, modulos de blindagem, Trophy ---- */
  const tg=new THREE.Group(),T=mb(),radM=new THREE.MeshBasicMaterial({color:0x2a4a5a});tg.position.set(0,1.44,-.9);
  T.c(1.3,1.35,.16,'M',0,.08,0,'y');
  T.g(lof([[-.9,2],[.9,2],[1.62,.9],[1.7,-.7],[1.35,-1.5],[-1.35,-1.5],[-1.7,-.7],[-1.62,.9]],.14,[[-.55,1.55],[.55,1.55],[1.12,.8],[1.2,-.6],[.95,-1.4],[-.95,-1.4],[-1.2,-.6],[-1.12,.8]],.68),'M',0,0,0);
  T.g(lof([[-1.3,-1.2],[1.3,-1.2],[1.25,-2.8],[-1.25,-2.8]],.12,[[-1.05,-1.2],[1.05,-1.2],[1,-2.6],[-1,-2.6]],.9),'M',0,0,0);
  const lau=[];
  for(const s of[-1,1]){
    for(let k=0;k<5;k++){const u=k/4;T.b(.16,.52,.62,AR,s*(.86+.7*u),.45,1.9-u,0,-s*.62)}
    for(let k=0;k<3;k++)T.b(.14,.46,.55,AR,s*1.74,.4,.3-k*.62);
    for(let k=0;k<4;k++)T.c(.055,.055,.32,DK,s*1.2,.7,-.95-k*.17,'y',0,0,-s*.8);
    for(const[x,z,ry]of[[s*1,1.2,s*.7],[s*1.25,-1.3,s*(Math.PI/2+.35)]]){const m=bx(.5,.44,.07,radM,x,.85,z);m.rotation.y=ry;tg.add(m)}
    const l=new THREE.Group();l.position.set(s*1.05,.9,-1.8);l.add(bx(.3,.5,.3,dark,0,.25,0),bx(.34,.06,.34,dark,0,.52,0));l.userData.s=s;tg.add(l);lau.push(l);
  }
  const chn=[];for(let k=0;k<9;k++){const c=new THREE.Group();c.position.set(-1+k*.25,.86,-2.62);c.add(bx(.2,.7,.03,dark,0,-.35,0));tg.add(c);chn.push(c)}
  T.c(.4,.44,.14,MT,.7,.76,-.55,'y');T.c(.38,.4,.1,MT,-.72,.72,-.7,'y');T.c(.09,.1,.8,DK,-1.05,.85,-1.05,'y',.35);
  T.b(.42,.34,.38,DK,-.55,.82,.95);T.b(.28,.16,.04,GL,-.55,.84,1.15);T.b(.8,.05,.6,MT,.2,.72,-1.35);
  T.out(tg,mat);
  const cup=new THREE.Group();cup.position.set(.7,.86,-.55);cup.add(new THREE.Mesh(new THREE.CylinderGeometry(.34,.36,.14,10),dark));
  for(let k=0;k<6;k++){const a=k/6*6.283,m=bx(.12,.07,.04,gl,Math.sin(a)*.35,.07,Math.cos(a)*.35);m.rotation.y=a;cup.add(m)}tg.add(cup);
  const rws=new THREE.Group();rws.position.set(0,.9,-1.5);rws.add(bx(.46,.2,.46,dark,0,.1,0),bx(.34,.28,.5,dark,0,.34,.05),new THREE.Mesh(new THREE.CylinderGeometry(.04,.04,1.1,6).rotateX(Math.PI/2),dark).translateY(.36).translateZ(.85),new THREE.Mesh(new THREE.SphereGeometry(.1,8,6),gl).translateY(.5).translateZ(.1));tg.add(rws);
  const cl=mkLid(tg,mat,.7,.94,-.55,.3),ll=mkLid(tg,mat,-.72,.8,-.7,.28),crew=mkCrew(tg,cm,hm,sk,.7,.6,-.55);
  /* canhao liso de 120 mm com luva termica longa e espelho de referencia na boca */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.4,1.6);
  B.b(.95,.62,.5,'M',0,0,.2);B.c(.28,.3,.3,RB,0,0,.5,'z');B.c(.035,.035,.8,DK,.46,-.08,.8,'z');B.b(.3,.18,.06,GL,-.4,.2,.46);B.out(bp,mat);
  K.c(.125,.125,5.7,DK,0,0,3.3,'z');K.c(.18,.17,1.2,'M',0,0,1.3,'z');K.c(.17,.17,3.4,'M',0,0,4,'z');K.c(.21,.21,.45,'M',0,0,4.7,'z');
  for(let k=0;k<5;k++)K.c(.19,.19,.05,DK,0,0,1.8+k*.65,'z');K.b(.25,.14,.2,DK,0,.16,5.95);K.out(bar,mat);
  const fl=mkFl(bar,6.1,.55,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,sks,dl,drv,rdoor,troops,radM,lau,chn,cup,lid:[cl,ll],crew,cmg:rws,fl,brkM,wheels,trk,mat,dark,merk:true,cannon:true,spd:1.15,trn:.9,L:3.7,W:1.95,mz:6.1,fk:1.4,rld:3,wd:1.9,armor:.55,hp:120,TY:1.44,ak:0}));
}
function animMerk(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.drv.visible=false;t.dl.rotation.x=-1.4;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.rdoor.rotation.x=-1.5;t.radM.color.set(0x050505);t.troops.forEach(c=>c.visible=false);
    t.ck=(t.ck===undefined?5:t.ck)-dt;if(t.ck>0){t.ckt=(t.ckt||0)-dt;if(t.ckt<=0){t.ckt=.1+Math.random()*.1;t.tg.localToWorld(v2.set((Math.random()-.5)*1.2,.8,-1.5+Math.random()*.6));puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.2,5,.55,9);puff(v2,0x1f1e1c,1.5,3,1.6,5)}}
    return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/13,0,1),d=trkStep(t,dt,1.6),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.52+Math.sin(now*10+i*1.6)*.03*th});
  t.hull.position.y=Math.sin(now*30+t.x)*(.008+.012*th)-t.recoil*.03;t.hull.rotation.x=-ac*.004-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.025;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  t.sks.forEach((p,i)=>{p.rotation.z=p.userData.s*(.03+(.04+.1*th)*Math.sin(now*(8+th*6)+i*.9)+clamp(t.v*.004,-.08,.08))});
  /* correntes do bustle balancam com a marcha e o recuo */
  t.chn.forEach((c,i)=>{c.rotation.x=Math.sin(now*3+i*.7)*.06*(1+th*2.5)+clamp(ac*.03,-.35,.35)+t.recoil*.15});
  /* Trophy: radares pulsam, lancadores se levantam com inimigo por perto */
  t.radM.color.setHSL(.52,.7,.2+.15*Math.sin(now*(t.mgt?14:3)));t.ak+=((t.mgt?1:0)-t.ak)*Math.min(1,dt*3);
  t.lau.forEach(l=>l.rotation.z=-l.userData.s*(.9-.65*t.ak));
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.8+t.x)*1.3*(1-t.open*.7);
  /* porta traseira abre quando parado e a tropa desembarca */
  const od=clamp(t.open,0,1);t.rdoor.rotation.x=-od*1.5;t.troops.forEach((c,i)=>{c.visible=od>.7;c.rotation.y=Math.sin(now*.9+i*2+t.z)*.6});
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  if(ac>3&&Math.random()<dt*10){t.g.localToWorld(v2.set(1.15,1.4,-4.2));puff(v2,0x1f1e1c,.9,1.2,1,1.4)}
  tankFx(t,dt,now,th,{ex:[[1.15,1.3,-4.2],[-1.15,1.3,-4.2]],dk:[[1.7,.2,-3],[-1.7,.2,-3]],mz:6,rr:1.1,rc:.85});
  mgScan(t,dt,60);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.4,1.3],now);smokeQ(t,dt,1.2,.7,-.7);
}

/* ---------- Boxer CRV (Australia/Alemanha): 8x8, cabine do motorista elevada, torre Lance 30 mm, Spike LR2 ---------- */
function makeBoxer(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x6c714d,bxrT),g=new THREE.Group(),wheels=[],steers=[],DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,AR=0x565c40,AX=[2.45,.95,-.55,-2.05];
  g.rotation.order='YXZ';
  for(const s of[-1,1])AX.forEach((z,i)=>{const w=new THREE.Mesh(bxrW,vcM);w.userData={r:.68};wheels.push(w);
    if(i<2){const sg=new THREE.Group();sg.position.set(s*1.42,.68,z);sg.add(w,bx(.2,.2,.5,dark,-s*.3,.15,0));g.add(sg);steers.push({g:sg,k:i?.6:1})}
    else{w.position.set(s*1.42,.68,z);g.add(w,bx(.2,.2,.5,dark,s*1.1,.83,z))}});
  const hull=new THREE.Group(),H=mb();
  H.b(2.2,.14,6.8,DK,0,.66,0);H.b(2.7,1.15,6.6,'M',0,1.28,-.1);H.b(2.7,.7,.7,'M',0,1.1,3.55);
  H.g(facet([[.05,1.4,3.9],[1.35,1.4,3.9],[1.35,1.4,2],[.05,1.4,2],[.05,1.85,3.3],[1.35,1.85,3.3],[1.35,1.85,2],[.05,1.85,2]],BXF),'M',0,0,0);
  H.g(facet([[-1.3,1.85,3.1],[-.05,1.85,3.1],[-.05,1.85,1.5],[-1.3,1.85,1.5],[-1.3,2.4,2.7],[-.05,2.4,2.7],[-.05,2.4,1.6],[-1.3,2.4,1.6]],BXF),'M',0,0,0);
  H.b(1,.36,.04,GL,-.68,2.14,2.9,-.63);H.b(.04,.3,.6,GL,-1.31,2.12,2.2);for(let k=0;k<5;k++)H.b(.9,.04,.1,MT,.7,1.88,2.2+k*.2);
  H.b(1.9,.1,.2,MT,0,.85,3.92);H.b(1.2,.06,2.5,MT,-.2,1.9,-2.3);for(let k=0;k<4;k++)H.b(1.2,.05,.05,DK,-.2,1.94,-3.2+k*.5);
  for(const s of[-1,1]){
    AX.forEach(z=>{H.b(.8,.1,1.45,'M',s*1.5,1.43,z);H.b(.08,.3,1.45,'M',s*1.88,1.55,z)});
    for(let k=0;k<4;k++)H.b(.16,.65,1.25,AR,s*1.43,1.75,-2.65+k*1.45);
    H.c(.12,.14,.6,DK,s*1,.95,-3.65,'z');
    hull.add(bx(.3,.2,.1,lamp,s*1.05,1.05,3.92),bx(.3,.2,.08,brkM,s*1.1,1.1,-3.44));
  }
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.1,1.9,-3.1,flagM),ant2=new THREE.Group();ant2.position.set(1.1,1.9,-3.1);ant2.add(new THREE.Mesh(new THREE.CylinderGeometry(.012,.025,2.6,5),dark).translateY(1.3));hull.add(ant2);
  const rdoor=new THREE.Group();rdoor.position.set(0,.82,-3.46);rdoor.add(bx(1.9,.95,.1,mat,0,.47,0),bx(1.5,.7,.04,dark,0,.47,-.06));hull.add(rdoor);
  /* ---- torre Lance: compacta, canhao Mk44 de 30 mm, Spike LR2 nas laterais ---- */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.9,-.55);
  T.c(.95,1,.14,'M',0,.07,0,'y');
  T.g(lof([[-.95,1.15],[.95,1.15],[1.15,.5],[1.15,-1],[.9,-1.35],[-.9,-1.35],[-1.15,-1],[-1.15,.5]],.1,[[-.7,.95],[.7,.95],[.95,.4],[.95,-.9],[.75,-1.15],[-.75,-1.15],[-.95,-.9],[-.95,.4]],.72),'M',0,0,0);
  T.b(1.7,.5,.5,'M',0,.42,-1.55);T.b(.42,.32,.36,DK,-.52,.9,.4);T.b(.28,.16,.04,GL,-.52,.92,.6);T.b(.5,.05,.5,MT,.5,.74,.1);
  const spk=[];
  for(const s of[-1,1]){
    for(let k=0;k<4;k++)T.c(.05,.05,.3,DK,s*1,.62,.5-k*.17,'y',0,0,-s*.8);
    const q=new THREE.Group();q.position.set(s*1.32,.42,-.15);q.userData.s=s;q.add(bx(.34,.36,1.5,dark,0,0,.3));
    for(const x of[-.09,.09])q.add(new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,1.5,8).rotateX(Math.PI/2),mat).translateX(x).translateY(.2).translateZ(.45),bx(.14,.14,.05,DK,x,.2,1.22));
    tg.add(q);spk.push(q);
  }
  T.out(tg,mat);
  const pan=new THREE.Group();pan.position.set(0,.95,-.3);pan.add(new THREE.Mesh(new THREE.CylinderGeometry(.08,.1,.3,8),dark).translateY(.15),bx(.34,.22,.3,dark,0,.4,0),bx(.18,.1,.04,gl,0,.4,.16));tg.add(pan);
  const ej=new THREE.Group();ej.position.set(.97,.45,-.1);ej.add(bx(.03,.3,.4,dark,0,0,0));tg.add(ej);
  const cl=mkLid(tg,mat,.55,.8,-.75,.3),ll=mkLid(tg,mat,-.55,.78,-.8,.28),crew=mkCrew(tg,cm,hm,sk,.55,.55,-.75),cmg=mkMG(tg,0,.78,-1.1);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.42,.85);
  B.b(.62,.46,.4,'M',0,0,.2);B.c(.2,.22,.2,RB,0,0,.4,'z');B.c(.03,.03,.6,DK,-.28,-.08,.6,'z');B.out(bp,mat);
  K.c(.065,.065,3,DK,0,0,2,'z');K.c(.11,.1,1.3,'M',0,0,1.2,'z');K.c(.09,.09,.45,DK,0,0,3.4,'z');for(const z of[.7,1.2,1.7])K.c(.12,.12,.05,DK,0,0,z,'z');K.out(bar,mat);
  const fl=mkFl(bar,3.55,.3,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,ant2,rdoor,spk,pan,ej,lid:[cl,ll],crew,cmg,fl,brkM,wheels,steers,mat,dark,boxer:true,cannon:true,spd:1.8,trn:1.1,L:3.4,W:1.5,mz:3.6,fk:.4,rld:1.1,wd:1.5,armor:.8,hp:95,TY:1.9,ak:0,eo:0,ejp:0}));
}
function animBoxer(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.rdoor.rotation.x=-1.5;return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/17,0,1),ph=t.v*dt,ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),u=t.clk-t.lf;
  for(const w of t.wheels)w.rotation.x+=ph/.68;
  for(const s of t.steers)s.g.rotation.y+=((t.st||0)*.42*s.k-s.g.rotation.y)*Math.min(1,dt*6);
  /* suspensao hidropneumatica: sobe em velocidade, agacha parado, empina ao acelerar */
  t.hy=(t.hy||0)+((th>.45?.07:th<.05?-.03:0)-(t.hy||0))*Math.min(1,dt*2);t.pt=(t.pt||0)+(clamp(-ac*.004,-.05,.05)-(t.pt||0))*Math.min(1,dt*5);
  const by=t.hy+Math.sin(now*34+t.x)*(.008+.012*th)-t.recoil*.02;
  t.hull.position.y=by;t.tg.position.y=t.TY+by;t.hull.rotation.x=t.pt-t.recoil*.015;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.ant.rotation.x=-t.v*.014+Math.sin(now*3+t.z)*.03;t.ant2.rotation.x=-t.v*.016+Math.sin(now*2.6+t.x)*.04;
  /* rajada de 3 tiros de 30 mm */
  if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=.11;t.bfi=1;fire(t);t.bfi=0}}
  /* mastro panoramico gira; Spike LR2 sobem com inimigo por perto */
  t.pan.rotation.y+=dt*(t.mgt?2.2:.7);t.ak+=((t.mgt?1:0)-t.ak)*Math.min(1,dt*3);t.spk.forEach(q=>q.rotation.x=-t.ak*.4);
  /* porta de ejecao do estojo abre a cada rajada */
  const eo=u>.1&&u<.9?1:0;if(eo&&!t.ejp){t.tg.localToWorld(v2.set(1.1,.5,-.1));puff(v2,0xd9b24a,.25,3,.7,1.6)}t.ejp=eo;t.eo+=(eo-t.eo)*Math.min(1,dt*10);t.ej.rotation.z=-t.eo*1;
  t.rdoor.rotation.x=-clamp(t.open,0,1)*1.5;
  tankFx(t,dt,now,th,{ex:[[1,.95,-3.8]],dk:[[1.6,.2,-2.1],[-1.6,.2,-2.1],[1.6,.2,-.6],[-1.6,.2,-.6]],mz:3.6,rr:2.2,rc:.3});
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.6,[0,.1,1.45],now);smokeQ(t,dt,1,.6,.3);
}

/* ---------- CV90 (Suecia): IFV de esteiras, canhao Bofors de 40 mm, torre angular, rampa traseira ---------- */
const cvT=camT(['#6b7448','#4f5a35','#2f3a26','#8a8460']),cvW=tw(.46),cvS=tw(.52,1),cvI=tw(.46),cvR=tw(.17);
function makeCV90(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x5d6a3e,cvT),g=new THREE.Group(),wheels=[],GX=1.5,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,AR=0x4c5636;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-2.8,.1],[2.8,.1],[3.4,.5],[3.2,.92],[2.8,1.04],[-2.7,1.04],[-3.3,.92],[-3.4,.5]],80,.6,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,cvS,sx,.52,3,.5,s,wheels);wl(g,cvI,sx,.5,-3,.4,s,wheels);
    for(let i=0;i<6;i++)wl(g,cvW,sx,.5,-2.1+i*.84,.46,s,wheels).userData.b=1;
    for(let k=0;k<3;k++)wl(g,cvR,sx,.98,-1.6+k*1.6,.17,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(2.5,.5,6.3,'M',0,.65,0);H.b(2.4,.14,6.6,DK,0,.4,0);
  H.g(lof([[-1.1,3.5],[1.1,3.5],[1.6,2.3],[1.6,-3.3],[-1.6,-3.3],[-1.6,2.3]],.85,[[-.95,1.9],[.95,1.9],[1.5,1.4],[1.5,-3.25],[-1.5,-3.25],[-1.5,1.4]],1.6),'M',0,0,0);
  H.b(2.6,.9,.14,'M',0,1.2,-3.36);for(let k=0;k<6;k++)H.b(.9,.04,.08,MT,.55,1.62,1.0+k*.14);H.b(.55,.1,.22,GL,-.6,1.64,1.78);
  for(const s of[-1,1]){
    H.b(.5,.14,6.2,'M',s*1.78,1.12,0);H.b(.14,.3,6.2,MT,s*2.02,1.18,0);
    for(let k=0;k<5;k++)H.b(.1,.55,1.05,AR,s*1.95,.78,-2.4+k*1.2);
    H.b(.5,.14,1.5,'M',s*1.6,.98,2.7,.3);H.c(.04,.04,5,DK,s*1.7,1.3,-.2,'z');H.b(.2,.14,.16,MT,s*.8,.95,3.55);
    H.b(.3,.34,.5,DK,s*1.6,1.35,-2.9);H.c(.07,.07,.5,MT,s*1.2,1.1,-3.55,'z');
    hull.add(bx(.3,.18,.1,lamp,s*1.25,1.05,3.38),bx(.3,.18,.08,brkM,s*1.2,1.1,-3.45));
  }
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.2,1.6,-3,flagM);
  const vane=new THREE.Group();vane.position.set(0,.86,3.5);vane.add(new THREE.Mesh(new THREE.BoxGeometry(2,.05,.7),mat).translateZ(-.35));vane.rotation.x=.44;hull.add(vane);
  const rp=new THREE.Group();rp.position.set(0,.85,-3.4);rp.add(bx(2,1,.1,mat,0,.5,0),bx(1.6,.7,.04,dark,0,.5,-.06));hull.add(rp);
  const dl=mkLid(hull,mat,-.6,1.6,1.15,.26);
  /* torre angular com canhao Bofors L/70, mira panoramica e lancadores de fumaca */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.6,-.25);
  T.c(1,1.05,.16,'M',0,.08,0,'y');
  T.g(lof([[-.7,1.55],[.7,1.55],[1.25,.75],[1.25,-.85],[.95,-1.5],[-.95,-1.5],[-1.25,-.85],[-1.25,.75]],.1,[[-.5,1.25],[.5,1.25],[1,.5],[1,-.8],[.75,-1.3],[-.75,-1.3],[-1,-.8],[-1,.5]],.78),'M',0,0,0);
  T.b(1.4,.5,.4,'M',0,.45,1.5);T.b(1.5,.5,.7,'M',0,.42,-1.65);T.b(.5,.3,.4,DK,-.55,.95,.7);T.b(.3,.14,.04,GL,-.55,.97,.92);
  for(const s of[-1,1])for(let k=0;k<3;k++)T.c(.055,.055,.28,DK,s*1.18,.62,.8-k*.2,'y',0,0,-s*.7);
  T.out(tg,mat);
  const cup=new THREE.Group();cup.position.set(.6,.82,.25);cup.add(new THREE.Mesh(new THREE.CylinderGeometry(.22,.24,.18,10),dark),bx(.3,.16,.22,dark,0,.14,.1),bx(.2,.08,.04,gl,0,.14,.22));tg.add(cup);
  const cl=mkLid(tg,mat,.55,.8,-.55,.26),ll=mkLid(tg,mat,-.5,.78,-.6,.24),crew=mkCrew(tg,cm,hm,sk,.55,.55,-.55),cmg=mkMG(tg,-.5,.82,-.5);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.42,1.2);
  B.b(.55,.45,.5,'M',0,0,.1);B.c(.2,.22,.25,RB,0,0,.45,'z');B.out(bp,mat);
  K.c(.07,.07,2.8,DK,0,0,2,'z');K.c(.13,.12,1.1,'M',0,0,1.15,'z');K.c(.11,.11,.4,DK,0,0,3.3,'z');K.c(.1,.1,.18,DK,0,0,2.1,'z');for(const z of[.8,1.5])K.c(.14,.14,.05,DK,0,0,z,'z');K.c(.03,.03,1.3,DK,.26,-.08,1,'z');K.out(bar,mat);
  const fl=mkFl(bar,3.5,.32,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,vane,rp,dl,cup,lid:[cl,ll],crew,cmg,fl,brkM,wheels,trk,mat,dark,cv90:true,cannon:true,spd:1.5,trn:1,L:3.6,W:1.8,mz:3.5,fk:.5,rld:1.1,wd:2.1,armor:.7,hp:110,TY:1.6,ejp:0}));
}
function animCV90(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.dl.rotation.x=-1.4;t.rp.rotation.x=-1.4;return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/14,0,1),d=trkStep(t,dt,1.5),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),u=t.clk-t.lf;
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*11+i*1.7)*.03*th});
  const by=Math.sin(now*30+t.x)*(.008+.012*th)-t.recoil*.03;
  t.hull.position.y=by;t.tg.position.y=t.TY+by;t.hull.rotation.x=-ac*.004-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  /* rajada de 3 tiros de 40 mm; estojos saltam pela lateral da torre */
  if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=.13;t.bfi=1;fire(t);t.bfi=0}}
  const eo=u>.08&&u<.5?1:0;if(eo&&!t.ejp){t.tg.localToWorld(v2.set(-1.2,.6,-.3));puff(v2,0xd9b24a,.25,3,.7,1.6)}t.ejp=eo;
  /* mira do comandante vigia; aleta de proa sobe na agua; rampa e escotilha do motorista abrem parado */
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.8+t.x)*1.2;
  t.vane.rotation.x=.44+clamp((t.wet||0)/.5,0,1)*.9+Math.sin(now*12+t.z)*.02*th;
  t.rp.rotation.x=-clamp(t.open,0,1)*1.4;t.dl.rotation.x=-clamp(t.open,0,1)*1.5;
  if(ac>3&&Math.random()<dt*10){t.g.localToWorld(v2.set(-1.6,1.1,-3.7));puff(v2,0x2a2926,.7,1.2,1,1.5)}
  tankFx(t,dt,now,th,{ex:[[-1.2,1.1,-3.7]],dk:[[1.9,.2,-2.5],[-1.9,.2,-2.5],[1.9,.2,2],[-1.9,.2,2]],mz:3.5,rr:2.2,rc:.35});
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.6,[0,.1,1.45],now);smokeQ(t,dt,1,.6,.3);
}

/* ---------- M1297 AGMV / Infantry Squad Vehicle (EUA): 4x4 leve aberto, gaiola de protecao, esquadra a bordo, metralhadora .50 em anel ---------- */
const agT=camT(['#8d8a63','#74724f','#5f5c42','#a29a74']),agW=mkWheel(.52,.42,18,6);
function makeAGMV(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x8a8763,agT),g=new THREE.Group(),wheels=[],steers=[],legs=[],soldiers=[],DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,WX=1;
  g.rotation.order='YXZ';
  for(const s of[-1,1])[1.65,-1.65].forEach((z,i)=>{const w=new THREE.Mesh(agW,vcM);w.userData={r:.52};wheels.push(w);
    if(i===0){const sg=new THREE.Group();sg.position.set(s*WX,.52,z);sg.add(w);g.add(sg);steers.push({g:sg,k:1});legs.push(sg)}
    else{w.position.set(s*WX,.52,z);g.add(w);legs.push(w)}});
  const hull=new THREE.Group(),H=mb();
  H.b(1.3,.22,5.2,DK,0,.66,0);H.b(1.7,.14,4.6,'M',0,.85,-.1);H.b(1.55,.5,1.5,'M',0,1.05,1.95);H.b(1.5,.08,1.4,'M',0,1.32,1.95,-.1);
  H.b(1.5,.4,.12,DK,0,.98,2.72);for(let k=0;k<5;k++)H.b(1.2,.04,.05,MT,0,.88+k*.08,2.79);H.b(1.7,.1,.1,MT,0,.74,2.82);H.b(1.7,.18,.2,DK,0,.75,-2.7);
  H.b(1.55,.3,.3,DK,0,1.25,1.12);H.b(1.55,.38,.04,GL,0,1.48,1.05,-.3);
  for(const s of[-1,1]){
    for(const z of[1.65,-1.65])H.b(.5,.06,1.2,'M',s*1,1.1,z);
    H.b(.5,.1,.5,DK,s*.4,1.03,.45);H.b(.48,.5,.1,DK,s*.4,1.3,.16);
    H.b(.45,.1,2.7,DK,s*.62,1.02,-1.2);H.b(.08,.45,2.7,DK,s*.88,1.28,-1.2);
    H.b(.08,.35,3.2,'M',s*.88,1.02,-1.1);
    for(const z of[1,-.5,-2.2])H.c(.035,.035,1,DK,s*.9,1.45,z);
    H.c(.035,.035,3.4,DK,s*.9,1.98,-.6,'z');
    hull.add(bx(.22,.14,.06,lamp,s*.55,1.08,2.69),bx(.2,.12,.06,brkM,s*.7,.95,-2.8));
  }
  for(const z of[1,-.5,-2.2])H.c(.035,.035,1.8,DK,0,1.98,z,'x');
  H.c(.05,.05,1.3,DK,.8,1.55,1.5);H.c(.06,.06,.5,MT,.7,.7,-2.1,'z');H.c(.45,.45,.2,RB,0,1.45,-2.82,'z');H.b(.5,.4,.4,'M',.5,1.2,-2.5);
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-.85,1.95,-2.2,flagM);
  const sol=(x,y,z,r)=>{const c=new THREE.Group(),h=new THREE.Mesh(new THREE.SphereGeometry(.14,8,6),hm);h.scale.y=.75;h.position.y=.78;c.position.set(x,y,z);c.rotation.y=r;c.userData={by:y,ry:r};
    c.add(bx(.4,.55,.26,cm,0,.3,0),new THREE.Mesh(new THREE.SphereGeometry(.11,8,6),sk).translateY(.68).translateZ(.04),h,bx(.1,.1,.5,dark,.1,.4,.3));hull.add(c);soldiers.push(c)};
  const Q=Math.PI/2;sol(-.4,1.05,.45,0);sol(.4,1.05,.45,0);sol(-.62,1.07,-.8,-Q);sol(-.62,1.07,-1.7,-Q);sol(.62,1.07,-.8,Q);sol(.62,1.07,-1.7,Q);
  /* anel traseiro com metralhadora .50 e atirador de pe */
  const tg=new THREE.Group(),T=mb(),gnr=new THREE.Group();tg.position.set(0,1,-1.3);
  T.c(.45,.45,.1,'M',0,.08,0,'y');T.b(.1,.5,.1,DK,0,.35,.3);T.out(tg,mat);
  const gh=new THREE.Mesh(new THREE.SphereGeometry(.14,8,6),hm);gh.scale.y=.75;gh.position.y=1.08;
  gnr.add(bx(.42,.7,.26,cm,0,.5,-.1),new THREE.Mesh(new THREE.SphereGeometry(.11,8,6),sk).translateY(.98).translateZ(.03),gh,bx(.1,.1,.4,cm,.2,.7,.1));tg.add(gnr);
  const cmg=mkMG(tg,-.45,.7,.15),lid=[new THREE.Group(),new THREE.Group()],crew=new THREE.Group();crew.userData.by=0;
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.85,.4);
  B.b(.2,.22,.5,'M',0,0,.1);B.b(.22,.26,.3,DK,.22,-.1,.1);B.out(bp,mat);
  K.c(.025,.025,1.1,DK,0,.02,.8,'z');K.c(.045,.045,.45,'M',0,.02,.5,'z');K.out(bar,mat);
  const fl=mkFl(bar,1.4,.18,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,gnr,lid,crew,cmg,fl,brkM,wheels,steers,legs,soldiers,mat,dark,agmv:true,cannon:true,spd:2,trn:1.3,L:2.6,W:1.1,mz:1.5,fk:.3,rld:.5,wd:1,armor:.35,hp:55,TY:1,pt:0,rl:0}));
}
function animAGMV(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.soldiers.forEach(c=>c.visible=false);t.gnr.visible=false;return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/18,0,1),ph=t.v*dt,ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9),k=Math.min(1,dt*5);
  for(const w of t.wheels)w.rotation.x+=ph/.52;
  for(const s of t.steers)s.g.rotation.y+=((t.st||0)*.5-s.g.rotation.y)*Math.min(1,dt*7);
  /* suspensao independente em cada roda; carroceria cabeceia ao acelerar e inclina nas curvas */
  t.legs.forEach((o,i)=>{o.position.y=.52+Math.sin(now*(15+i*2.3)+i*2+t.x*.3)*.045*th});
  t.pt+=(clamp(-ac*.006,-.07,.07)-t.pt)*k;t.rl+=(clamp(-(t.st||0)*th*.09,-.1,.1)-t.rl)*k;
  const by=Math.sin(now*26+t.x)*(.01+.025*th)-t.recoil*.015;
  t.hull.position.y=by;t.hull.rotation.x=t.pt-t.recoil*.01;t.hull.rotation.z=t.rl;t.tg.position.y=t.TY+by;
  /* soldados balancam com o terreno e viram a cabeca; atirador acompanha a metralhadora */
  t.soldiers.forEach((c,i)=>{c.position.y=c.userData.by+Math.sin(now*(18+i)+i)*.014*th;c.rotation.x=-ac*.012+Math.sin(now*2.2+i*1.3)*.03;c.rotation.y=c.userData.ry+Math.sin(now*.7+i*2)*.25*(1-th*.5)});
  t.gnr.rotation.x=-ac*.01+Math.sin(now*2+t.x)*.03;t.gnr.position.y=Math.sin(now*20)*.016*th;
  t.ant.rotation.x=-t.v*.02+Math.sin(now*5+t.z)*.06*(.3+th);
  tankFx(t,dt,now,th,{ex:[[.7,.7,-2.9]],dk:[[1.2,.2,1.6],[-1.2,.2,1.6],[1.2,.2,-1.6],[-1.2,.2,-1.6]],mz:1.5,rr:3,rc:.15});
  mgScan(t,dt,45);mgAim(t,dt,t.cmg,t.yaw,.4,[0,.1,.9],now);smokeQ(t,dt,.6,.5,.2);
}

/* ---------- M1134 Stryker ATGM (EUA): 8x8, lancador duplo TOW-2 em braco hidraulico no teto, 12 misseis (2 prontos), guiagem por fio ate ~4 km ---------- */
const syT=camT(['#8b8a63','#6f7050','#555a3d','#a39b74']),syW=mkWheel(.6,.5,18,8),TOWV=150,TOWR=4000;
const towG=(()=>{const A=Math.PI/2,l=[vcol(new THREE.CylinderGeometry(.075,.075,1.25,8).rotateX(A),0x4b5036),vcol(new THREE.ConeGeometry(.075,.25,8).rotateX(A).translate(0,0,.75),0x2b2d28),vcol(new THREE.CylinderGeometry(.012,.012,.5,4).rotateX(A).translate(0,0,1.1),0xb8bbb0),vcol(new THREE.CylinderGeometry(.09,.09,.16,8).rotateX(A).translate(0,0,-.45),0x8a8c80)];
  for(let k=0;k<4;k++){const g=new THREE.BoxGeometry(k%2?.3:.02,k%2?.02:.3,.16);g.translate(0,0,-.55);l.push(vcol(g,0x2b2d28))}return mergeG(l)})();
const towWireM=new THREE.LineBasicMaterial({color:0xdfe6ea,transparent:true,opacity:.65}),towNoseM=new THREE.MeshLambertMaterial({color:0x4b5036});
function makeStryker(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x7b7b58,syT),g=new THREE.Group(),wheels=[],steers=[],DK=0x2b2d28,MT=0x4a4b42,GL=0x1d2f3a,AR=0x5a5f46,TB=0x3c4030,A=Math.PI/2,AX=[2.55,1.05,-.8,-2.35];
  g.rotation.order='YXZ';
  for(const s of[-1,1])AX.forEach((z,i)=>{const w=new THREE.Mesh(syW,vcM);w.userData={r:.6};wheels.push(w);
    if(i<2){const sg=new THREE.Group();sg.position.set(s*1.42,.6,z);sg.add(w,bx(.2,.2,.5,dark,-s*.3,.15,0));g.add(sg);steers.push({g:sg,k:i?.6:1})}
    else{w.position.set(s*1.42,.6,z);g.add(w,bx(.2,.2,.5,dark,s*1.1,.75,z))}});
  /* casco: fundo em V, capo inclinado a direita, cabine alta com blindagem ceramica e grade anti-RPG */
  const hull=new THREE.Group(),H=mb();
  H.b(2.1,.14,6.9,DK,0,.7,0);
  H.g(lof([[-1,3.5],[1,3.5],[1.2,3],[1.2,-3.5],[-1.2,-3.5],[-1.2,3]],.72,[[-1.15,3.45],[1.15,3.45],[1.4,2.9],[1.4,-3.5],[-1.4,-3.5],[-1.4,2.9]],1.3),'M',0,0,0);
  H.g(lof([[-1.15,3.35],[1.15,3.35],[1.4,2.7],[1.4,1.3],[-1.4,1.3],[-1.4,2.7]],1.3,[[-.95,2.75],[.95,2.75],[1.25,2.2],[1.4,1.3],[-1.4,1.3],[-1.25,2.2]],2),'M',0,0,0);
  H.b(2.8,1.1,4.9,'M',0,1.85,-1.15);H.b(2.5,.1,4.8,'M',0,2.44,-1.15);H.b(1.8,.05,2,DK,0,2.5,-2);
  H.b(2.1,.34,.1,DK,0,1.05,3.55);H.b(.8,.22,.8,'M',-.6,2.1,1.85);for(let k=0;k<3;k++)H.b(.16,.1,.1,GL,-.84+k*.24,2.2,2.26);
  for(let k=0;k<5;k++)H.b(.8,.03,.08,MT,.62,2.02,1.7+k*.18);
  for(const s of[-1,1]){
    for(const z of AX)H.b(.4,.06,1.4,DK,s*1.6,1.33,z);
    for(let k=0;k<7;k++)for(const y of[1.6,2.15])H.b(.08,.5,.6,AR,s*1.44,y,-3.2+k*.7);
    for(let k=0;k<21;k++)H.b(.03,.9,.03,MT,s*1.64,1.95,-3.4+k*.22);
    H.b(.05,.05,4.6,MT,s*1.64,2.42,-1.15);H.b(.05,.05,4.6,MT,s*1.64,1.5,-1.15);H.b(.12,.12,.2,MT,s*.6,.9,3.62);
    for(let k=0;k<4;k++)H.c(.05,.05,.4,DK,s*1.46,2.2,.5+k*.14,0,0,0,-s*.5);
    hull.add(bx(.3,.16,.08,lamp,s*.95,1.55,3.12),bx(.25,.16,.08,brkM,s*1.15,1.3,-3.68));
  }
  H.b(.9,.4,.8,'M',.8,2.68,-3);H.b(.5,.3,.7,DK,-.85,2.64,-3);H.c(.45,.5,.14,'M',.75,2.5,-.2);
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.1,2.45,-3.2,flagM),ant2=new THREE.Group();ant2.position.set(1.1,2.45,-3.2);ant2.add(new THREE.Mesh(new THREE.CylinderGeometry(.012,.025,2.8,5),dark).translateY(1.4));hull.add(ant2);
  const rdoor=new THREE.Group();rdoor.position.set(0,.95,-3.66);rdoor.add(bx(2.2,1.35,.12,mat,0,.67,0),bx(1.8,1,.04,dark,0,.67,-.07));hull.add(rdoor);
  const cl=mkLid(hull,mat,.75,2.58,-.2,.4),ll=mkLid(hull,mat,-.6,2.25,1.85,.3),crew=mkCrew(hull,cm,hm,sk,.75,2.55,-.2);
  /* base giratoria com coluna hidraulica; o lancador sobe ate 1,3 m acima do teto */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,2.5,-2);
  T.c(.62,.68,.16,'M',0,.08,0,'y');T.b(.9,.3,.9,'M',0,.25,0);T.out(tg,mat);
  const col=new THREE.Mesh(new THREE.BoxGeometry(.3,1,.3),new THREE.MeshLambertMaterial({color:MT}));col.position.y=.25;col.scale.y=.01;tg.add(col);
  /* lancador ITAS: berco, cabeca optica FLIR e dois tubos TOW-2 com tampas e misseis */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb(),msl=[],cap=[];bp.position.set(0,.2,0);
  B.b(1,.34,.8,'M',0,0,0);B.b(.4,.2,.5,DK,0,-.22,-.1);B.g(new THREE.SphereGeometry(.2,12,8),DK,-.72,.2,.15);B.c(.09,.09,.3,GL,-.72,.2,.36,'z');B.b(.1,.4,.1,MT,-.72,0,.15);
  for(const s of[-1,1]){K.c(.14,.14,1.9,TB,s*.3,0,.95,'z');K.c(.17,.17,.08,DK,s*.3,0,1.86,'z');K.c(.17,.17,.08,DK,s*.3,0,.25,'z');K.c(.16,.12,.2,DK,s*.3,0,-.1,'z')}
  K.b(.5,.1,.3,'M',0,0,.8);K.out(bar,mat);B.out(bp,mat);
  [-1,1].forEach(s=>{const m=new THREE.Mesh(new THREE.ConeGeometry(.085,.3,8).rotateX(A),towNoseM);m.position.set(s*.3,0,1.9);bar.add(m);msl.push(m);
    const c=new THREE.Group();c.position.set(s*.3,.15,1.95);c.add(new THREE.Mesh(new THREE.CylinderGeometry(.15,.15,.03,10).rotateX(A),dark).translateY(-.15));bar.add(c);cap.push(c)});
  const fl=mkFl(bar,1.95,.24,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,ant2,rdoor,col,msl,cap,lid:[cl,ll],crew,fl,brkM,wheels,steers,mat,dark,stry:true,cannon:true,spd:1.75,trn:1.05,L:3.5,W:1.5,mz:1.95,fk:.4,rld:1.3,wd:1.5,armor:.7,hp:115,TY:2.5,ak:0,tow:12,rdy:[true,true],rt2:[0,0],lift:0,pend:0}));
}
/* braco sobe, tampas abrem, missil sai do tubo; se nao houver tubo pronto, a recarga e feita pelo estoque interno */
function towFire(t){
  if(t.pend)return;
  if(!t.rdy[0]&&!t.rdy[1]){if(t.isPlayer)toast(t.tow>0?'Recarregando o lançador TOW…':'Sem mísseis TOW: pegue uma caixa de munição');t.cd=Math.max(t.cd,t.tow>0?Math.min(t.rt2[0],t.rt2[1])+.3:2);return}
  t.pend=1;t.lf=t.clk;
}
function towLaunch(t){
  const i=t.rdy[0]?0:t.rdy[1]?1:-1;if(i<0)return;
  t.rdy[i]=false;t.msl[i].visible=false;t.rt2[i]=6.5;if(t.isPlayer)t.tow--;
  const d=dirOf(t.yaw,t.pitch),sx=i?.3:-.3;v1.set(sx,0,1.95);t.bar.localToWorld(v1);
  const m=new THREE.Group(),b=new THREE.Mesh(towG,vcM),fl=new THREE.Mesh(rkFlameG,rkFlame);b.scale.setScalar(1.5);fl.position.z=-1.1;fl.scale.z=2.6;m.add(b,fl);m.position.copy(v1);scene.add(m);
  const gw=new THREE.BufferGeometry();gw.setAttribute('position',new THREE.BufferAttribute(new Float32Array(6),3));const w=new THREE.Line(gw,towWireM);w.frustumCulled=false;scene.add(w);
  shells.push({m,v:d.clone().multiplyScalar(26),owner:t,age:0,k:1.35,rk:true,tt:0,tow:true,life:45,wire:w});
  t.bar.localToWorld(v2.set(sx,0,-2.4));puff(v2,0xffe0a0,2.4,6,.3,.5);for(let k=0;k<5;k++)puff(v2,0xd8d2c4,2.6,8,1.1,.8);
  puff(v1,0xffd36b,1.3,4,.3,.4);t.recoil=1;t.fT=.14;t.ev=.6;t.fl.visible=true;snd('rocket',.75*near(v1));
  if(t.isPlayer){shake=Math.max(shake,.5);toast('TOW lançado · '+t.tow+' restantes')}
}
/* guiagem por fio: segue a linha de visada do atirador (ou o alvo da IA) e o fio se rompe se o Stryker for destruido ou o alcance passar de 4 km */
function towGuide(s,dt){
  const o=s.owner,p=s.m.position,sp=Math.min(TOWV,26+(TOWV-26)*Math.min(1,s.age/.9));
  if(!s.cut&&(o.dead||Math.hypot(p.x-o.x,p.z-o.z)>=TOWR)){s.cut=1;if(s.wire)s.wire.visible=false}
  if(s.cut){const L=Math.hypot(s.v.x,s.v.y,s.v.z)||1;s.v.multiplyScalar(sp/L);s.v.y+=G*dt;return}
  let tx,ty,tz;
  if(o.isPlayer){const d=dirOf(o.yaw,o.pitch);o.bp.getWorldPosition(v2);const u=Math.max(0,(p.x-v2.x)*d.x+(p.y-v2.y)*d.y+(p.z-v2.z)*d.z)+clamp(sp*.45,20,70);tx=v2.x+d.x*u;ty=v2.y+d.y*u;tz=v2.z+d.z*u;
    const a=aimLock;if(a&&!a.dead&&Math.hypot(a.x-p.x,a.z-p.z)<260){tx=a.x;ty=a.y+1.3;tz=a.z}}
  else{const a=o.tar;if(a&&!a.dead){tx=a.x+(a.vx||0)*.5;ty=a.y+1.3;tz=a.z+(a.vz||0)*.5}else{tx=p.x+s.v.x;ty=p.y+s.v.y;tz=p.z+s.v.z}}
  const dx=tx-p.x,dy=ty-p.y,dz=tz-p.z,L=Math.hypot(dx,dy,dz)||1,k=Math.min(1,dt*(s.age<.9?1.2:2.8));
  s.v.x+=(dx/L*sp-s.v.x)*k;s.v.y+=(dy/L*sp-s.v.y)*k+G*dt;s.v.z+=(dz/L*sp-s.v.z)*k;
}
function towFx(s){ /* fio entre o lancador e o missil, chama do motor no inicio */
  if(s.wire&&!s.cut){const a=s.wire.geometry.attributes.position,p=s.m.position;s.owner.bp.getWorldPosition(v2);a.setXYZ(0,v2.x,v2.y,v2.z);a.setXYZ(1,p.x,p.y,p.z);a.needsUpdate=true}
  if(s.age<1.2)puff(s.m.position,0xffb040,.55,.2,.16,0);
}
function animStry(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.rdoor.rotation.x=-1.5;t.col.scale.y=.3;return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/17,0,1),ph=t.v*dt,ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  for(const w of t.wheels)w.rotation.x+=ph/.6;
  for(const s of t.steers)s.g.rotation.y+=((t.st||0)*.42*s.k-s.g.rotation.y)*Math.min(1,dt*6);
  /* suspensao hidropneumatica: sobe em velocidade, agacha parado, empina ao acelerar */
  t.hy=(t.hy||0)+((th>.45?.05:th<.05?-.02:0)-(t.hy||0))*Math.min(1,dt*2);t.pt=(t.pt||0)+(clamp(-ac*.004,-.05,.05)-(t.pt||0))*Math.min(1,dt*5);
  const by=t.hy+Math.sin(now*34+t.x)*(.008+.012*th)-t.recoil*.015;
  t.hull.position.y=by;t.tg.position.y=t.TY+by;t.hull.rotation.x=t.pt-t.recoil*.01;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.ant.rotation.x=-t.v*.014+Math.sin(now*3+t.z)*.03;t.ant2.rotation.x=-t.v*.016+Math.sin(now*2.6+t.x)*.04;
  /* braco hidraulico: sobe para disparar (ou parado, para o jogador) e recolhe na marcha */
  const eng=t.clk-t.lf<10||(t.ai&&t.tar&&!t.tar.dead&&Math.hypot(t.tar.x-t.x,t.tar.z-t.z)<760);
  let want=(t.pend||eng||(t.isPlayer&&Math.abs(t.v)<2.5))?1:0;if(inGarage)want=Math.sin(now*.55)>-.25?1:0;
  t.lift+=clamp(want-t.lift,-dt*.8,dt*1.1);const L=t.lift*t.lift*(3-2*t.lift);
  t.col.scale.y=Math.max(.01,L*1.1);t.col.position.y=.25+L*.55;t.bp.position.y=.2+L*1.3;
  t.cap.forEach(c=>c.rotation.x=-1.4*clamp((L-.5)*2,0,1));
  if(t.pend&&t.lift>.92){t.pend=0;towLaunch(t)}
  for(let i=0;i<2;i++)if(!t.rdy[i]){if(t.rt2[i]>0)t.rt2[i]-=dt;else if(!t.isPlayer||t.tow>t.rdy.filter(Boolean).length){t.rdy[i]=true;t.msl[i].visible=true}}
  t.rdoor.rotation.x=-clamp(t.open,0,1)*1.5;
  tankFx(t,dt,now,th,{ex:[[1,.95,-3.95]],dk:[[1.7,.2,2.5],[-1.7,.2,2.5],[1.7,.2,-2.3],[-1.7,.2,-2.3]],mz:1.95,rr:3,rc:.15});smokeQ(t,dt,1.1,.5,.2);
}

/* ---------- T-80BVM (Russia): turbina a gas, blindagem reativa Relikt, jato de escape, venezianas do motor ---------- */
function makeT80(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x727a4a,t80T),g=new THREE.Group(),wheels=[],GX=1.45,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,ER=0x4c5636,FT=0x3f4a2c,WD=0x6a5236;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-3.05,.1],[3,.1],[3.7,.5],[3.5,.92],[3,1.04],[-2.9,1.04],[-3.6,.92],[-3.7,.5]],86,.62,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,t8S,sx,.52,-3.15,.5,s,wheels);wl(g,t8I,sx,.5,3.3,.4,s,wheels);
    for(let i=0;i<6;i++)wl(g,t8W,sx,.5,-2.2+i*.9,.46,s,wheels).userData.b=1;
    for(let k=0;k<4;k++)wl(g,t8R,sx,.98,-2.1+k*1.4,.17,s,wheels)});
  const hull=new THREE.Group(),H=mb(),sks=[],gy=z=>.96-(z-2.4)*.3237+.1;
  H.b(2.62,.5,5.85,'M',0,.62,-.33);H.b(2.62,.36,1.2,'M',0,.42,3.05);H.b(2.4,.14,6.5,DK,0,.4,0);H.b(3,.24,4.5,'M',0,1.2,-.9);H.b(2.7,.14,2.21,'M',0,.96,2.4,.313);H.b(2.62,.55,.14,'M',0,.5,3.66,-.35);H.b(2.62,.6,.14,'M',0,.82,-3.3,.2);
  for(let i=-1;i<=1;i++)for(let r=0;r<2;r++)H.b(.82,.12,.7,ER,i*.88,gy(1.95+r*.8)+.07,1.95+r*.8,.313);
  for(let k=0;k<10;k++)H.b(1.4,.05,.1,MT,.35,1.34,-3.1+k*.18);H.b(.9,.3,.9,DK,-.8,1.36,-3.1);
  H.c(.13,.13,2.5,WD,0,1.2,-3.5,'x');H.c(.3,.34,.08,MT,0,1.27,1.8,'y');for(let k=0;k<3;k++)H.b(.16,.08,.1,GL,(k-1)*.28,1.2,2.08);
  for(const s of[-1,1]){
    H.b(.62,.06,5.9,'M',s*1.55,1.1,-.1);H.b(.07,.07,5.9,MT,s*1.77,1.12,-.1);
    for(let k=0;k<3;k++)H.b(.1,.42,.9,ER,s*1.8,.82,.8+k*1.05);
    if(s<0){for(let k=0;k<3;k++){H.c(.2,.2,1.05,FT,-1.55,1.3,-2.5+k*1.3,'z');H.c(.21,.21,.05,DK,-1.55,1.3,-2.5+k*1.3,'z')}}
    else{H.b(.42,.3,1,MT,1.55,1.28,-1.35);H.b(.4,.24,.9,'M',1.55,1.25,-.3);H.c(.14,.14,.9,DK,1.55,1.26,1.4,'z');H.c(.2,.24,.7,DK,1.55,1.4,-3.5,'z')}
    hull.add(bx(.28,.14,.2,lamp,s*1.1,.78,3.38),bx(.3,.18,.08,brkM,s,.72,-3.44));
    for(let k=0;k<6;k++){const p=new THREE.Group();p.position.set(s*1.77,1.1,-2.55+k*.95);p.add(new THREE.Mesh(new THREE.BoxGeometry(.05,.5,.9),t7rub).translateY(-.25));p.userData.s=s;hull.add(p);sks.push(p)}
  }
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,1.2,1.35,-2.6,flagM);
  /* jato da turbina no escape traseiro e venezianas que abrem com a aceleracao */
  const jetM=new THREE.MeshBasicMaterial({color:0xffb050,transparent:true,opacity:0,depthWrite:false}),jet=new THREE.Mesh(new THREE.ConeGeometry(.2,1.2,8).rotateX(-Math.PI/2).translate(0,0,-.6),jetM);jet.position.set(1.55,1.4,-3.85);hull.add(jet);
  const lv=[];for(let k=0;k<5;k++){const l=new THREE.Group();l.position.set(.35,1.3,-3.2+k*.2);l.add(bx(1.3,.03,.16,dark,0,0,.08));hull.add(l);lv.push(l)}
  const vane=new THREE.Group();vane.position.set(0,.78,3.5);vane.add(new THREE.Mesh(new THREE.BoxGeometry(2.3,.05,.8),mat).translateZ(-.4));vane.rotation.x=.313;hull.add(vane);
  const snk=new THREE.Group();snk.position.set(0,1.45,-2.95);snk.add(new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,1.4,8),dark).translateY(.7));
  const snx=new THREE.Group();snx.position.y=.3;snx.add(new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,1,8),dark).translateY(.5),new THREE.Mesh(new THREE.CylinderGeometry(.13,.07,.12,8),dark).translateY(1));snk.add(snx);snk.rotation.x=Math.PI/2;hull.add(snk);
  const dl=mkLid(hull,mat,0,1.34,1.8,.28),drv=mkCrew(hull,cm,hm,sk,0,1,1.8);
  /* torre soldada com arco frontal de Relikt, mira Sosna-U e lancadores Tucha */
  const tg=new THREE.Group(),T=mb(),irM=new THREE.MeshBasicMaterial({color:0x4a1410}),shM=new THREE.MeshBasicMaterial({color:0xb01a14}),alM=new THREE.MeshBasicMaterial({color:0x30d060});tg.position.set(0,1.32,.2);
  T.c(1.22,1.28,.22,'M',0,.1,0,'y');
  T.g(lof([[-.5,1.75],[.5,1.75],[1.3,.85],[1.38,-.5],[1.1,-1.55],[-1.1,-1.55],[-1.38,-.5],[-1.3,.85]],.15,[[-.4,1.5],[.4,1.5],[1,.7],[1.08,-.45],[.85,-1.3],[-.85,-1.3],[-1.08,-.45],[-1,.7]],.88),'M',0,0,0);
  T.b(1.7,.45,.5,'M',0,.45,-1.78);T.b(1.5,.04,.46,MT,0,.7,-1.78);
  for(const s of[-1,1]){
    for(let k=0;k<5;k++){const u=k/4;T.b(.12,.5,.5,ER,s*(.58+.75*u),.55,1.7-.88*u,0,-s*.73)}
    for(let k=0;k<4;k++)T.b(.12,.45,.5,ER,s*1.43,.45,.55-k*.58);
    for(let k=0;k<3;k++)T.c(.055,.055,.28,DK,s*1.1,.9,.3+k*.22,'y',0,0,-s*.9);
  }
  T.b(.5,.4,.45,DK,-.62,1,1);T.c(.15,.15,.06,GL,-.62,1.02,1.26,'z');T.c(.34,.36,.1,MT,.6,.94,-.3,'y');T.c(.36,.4,.1,MT,-.55,.93,-.35,'y');
  T.out(tg,mat);
  for(const s of[-1,1])stk(tg,t8N,s*1.42,.5,-.5,s,.8,.4);
  const cup=new THREE.Group();cup.position.set(.6,1.02,-.3);cup.add(new THREE.Mesh(new THREE.CylinderGeometry(.34,.36,.14,10),dark));
  for(let k=0;k<5;k++){const a=k/5*6.283,m=bx(.12,.06,.04,gl,Math.sin(a)*.34,.06,Math.cos(a)*.34);m.rotation.y=a;cup.add(m)}tg.add(cup);
  const cl=mkLid(tg,mat,.6,1.1,-.3,.26),ll=mkLid(tg,mat,-.55,.97,-.35,.3),crew=mkCrew(tg,cm,hm,sk,.6,.78,-.3),cmg=mkMG(tg,.6,1.18,-.05);
  tg.add(new THREE.Mesh(new THREE.BoxGeometry(.12,.06,.12),alM).translateX(.2).translateY(.92).translateZ(.35));
  const ej=new THREE.Group();ej.position.set(0,.62,-2.06);ej.add(bx(.5,.3,.05,dark,0,-.15,0));tg.add(ej);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,1.5);
  B.b(.9,.66,.5,'M',0,0,0);B.c(.27,.3,.3,RB,0,0,.4,'z');B.c(.035,.035,.85,DK,.42,-.08,.75,'z');B.b(.3,.18,.06,GL,-.35,.22,.26);B.out(bp,mat);
  K.c(.125,.125,5.9,DK,0,0,3.35,'z');K.c(.17,.15,1.1,'M',0,0,1.1,'z');K.c(.175,.175,3.9,'M',0,0,3.4,'z');for(let k=0;k<7;k++)K.c(.19,.19,.06,DK,0,0,1.6+k*.5,'z');K.out(bar,mat);
  const fl=mkFl(bar,6.3,.55,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,fp:[],sks,vane,snk,snx,cup,ir:null,irM,sh:null,shM,alM,ej,wind:null,lid:[cl,ll],crew,dl,drv,cmg,fl,brkM,wheels,trk,mat,dark,jet,jetM,lv,t80:true,cannon:true,spd:1.3,trn:1,L:3.7,W:1.9,mz:6.2,fk:1.4,rld:2.2,wd:2.4,armor:.58,hp:115,TY:1.32,sn:0,eo:0,ejp:0}));
}
function animT80(t,dt){
  animT7x(t,dt);if(t.dead){t.jetM.opacity=0;return}
  const now=performance.now()/1000,th=clamp(Math.abs(t.v)/14,0,1),ac=(t.v-t.pv)/Math.max(dt,.001);
  t.jet.scale.set(.6+th*.5,.6+th*.5,.5+th*2.4*(.85+.15*Math.sin(now*50)));t.jetM.opacity=.3+th*.5;t.jetM.color.setHSL(.07+.03*Math.sin(now*30),1,.55+.15*th);
  t.lv.forEach((l,i)=>l.rotation.x=-.25-th*1+Math.sin(now*22+i)*.03);
  if(th>.3&&Math.random()<dt*14){t.g.localToWorld(v2.set(1.55,1.4,-4.6));puff(v2,0xe4ded2,1.1,2.2,1.2,1.6)}
}

/* ---------- Gepard 1A2 (Alemanha): canhao antiaereo autopropulsado, 2x35 mm Oerlikon, radar de busca giratorio e radar de tiro ---------- */
function makeGepard(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x59613f,lpT),g=new THREE.Group(),wheels=[],GX=1.5,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,TW=0x3a3a35;
  g.rotation.order='YXZ';
  const radM=new THREE.MeshBasicMaterial({color:0xff2a1a}),dishM=new THREE.MeshLambertMaterial({color:0x8a8c80,side:THREE.DoubleSide}),dishM2=new THREE.MeshLambertMaterial({color:0xb4b6aa,side:THREE.DoubleSide});
  const trk=trackLoop([[-3.1,.1],[3,.1],[3.7,.5],[3.5,.95],[3,1.08],[-2.9,1.08],[-3.65,.95],[-3.7,.5]],88,.66,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,gSL,sx,.55,-3.15,.52,s,wheels);wl(g,gWL,sx,.5,3.3,.46,s,wheels);for(let i=0;i<7;i++)wl(g,gWL,sx,.5,-2.55+i*.88,.46,s,wheels).userData.b=1;for(let k=0;k<4;k++)wl(g,gRL,sx,1.02,-2.2+k*1.3,.16,s,wheels)});
  /* casco baseado no Leopard 1: glacis, saias, grades do motor, faróis, escapes, cabo de reboque */
  const hull=new THREE.Group(),H=mb(),fp=[];
  H.b(2.7,.7,7,'M',0,.82,0);H.b(2.5,.2,6.8,DK,0,.45,0);H.b(3.3,.3,5,'M',0,1.3,-.6);H.b(3,.14,2.3,'M',0,1.16,3.05,.38);H.b(2.8,.5,.14,'M',0,.72,3.95,-.2);
  H.b(2.7,.12,2.2,'M',0,1.5,-2.6);H.b(2.7,.7,.1,'M',0,1.1,-3.55,.15);
  for(let k=0;k<8;k++)H.b(2.2,.04,.07,MT,0,1.57,-3.3+k*.2);
  H.c(.34,.36,.12,MT,-.7,1.55,2.1,'y');for(let k=0;k<3;k++)H.b(.14,.07,.07,GL,-.7+(k-1)*.18,1.62,2.4);
  H.b(1.1,.08,.7,DK,.8,1.56,2.3);H.c(.025,.025,1.4,DK,.8,1.9,2.3,'y');
  for(const s of[-1,1]){for(let k=0;k<6;k++){H.b(.18,.8,.9,'M',s*1.95,.95,-2.6+k*.98);H.b(.2,.06,.9,MT,s*1.95,1.37,-2.6+k*.98);H.b(.05,.5,.05,MT,s*2.06,.95,-2.2+k*.98)}
    H.b(.9,.08,1.2,'M',s*1.8,1.45,3.1,.2);H.c(.14,.14,.4,DK,s*.9,1.3,-3.7,'z');H.c(.04,.04,2.6,DK,s*1.8,1.05,-.4,'z');H.b(.3,.2,.5,MT,s*1.4,1.48,-1,0);H.b(.5,.3,.8,DK,s*1.75,1.5,-2.3);
    hull.add(bx(.3,.18,.1,lamp,s*1.2,1.5,3.9),bx(.3,.2,.08,brkM,s*1,.95,-3.58));
    const f=new THREE.Group();f.position.set(s*1.8,1.4,3.75);f.add(bx(.05,.7,.9,dark,0,-.35,0));hull.add(f);fp.push(f)}
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.2,1.55,-3,flagM);
  /* ---- torre larga e baixa ---- */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.5,-.1);
  T.c(1.25,1.3,.12,'M',0,.06,0,'y');
  T.g(lof([[-1.15,1.5],[1.15,1.5],[1.5,.9],[1.55,-1],[1.2,-1.65],[-1.2,-1.65],[-1.55,-1],[-1.5,.9]],.1,[[-.95,1.3],[.95,1.3],[1.25,.8],[1.3,-.9],[1,-1.45],[-1,-1.45],[-1.3,-.9],[-1.25,.8]],.82),'M',0,0,0);
  T.b(2.9,.5,.5,'M',0,.45,-1.85);T.b(2.5,.06,.5,MT,0,.7,-1.85);
  for(const s of[-1,1]){T.b(.5,.5,2.2,MT,s*1.55,.35,.25);T.b(.1,.4,1.8,DK,s*1.8,.4,.25);
    for(let k=0;k<4;k++)T.c(.06,.06,.3,DK,s*1.45,.7,-.5-k*.2,'y',0,0,-s*.6)}
  T.b(.45,.32,.5,DK,-.55,.98,.55);T.b(.3,.16,.04,GL,-.55,1,.82);T.b(.7,.14,.4,DK,.2,.9,1.1);T.b(.3,.1,.04,GL,.2,.92,1.32);
  T.c(.32,.35,.18,MT,.65,.9,-.3,'y');T.c(.3,.33,.1,MT,-.65,.88,-.45,'y');
  for(let k=0;k<5;k++){const a=k/5*6.283;T.b(.12,.08,.05,GL,.65+Math.sin(a)*.32,.99,-.3+Math.cos(a)*.32,0,a)}
  T.b(.9,.3,.6,MT,0,.9,.1);
  T.out(tg,mat);
  const cl=mkLid(tg,mat,.65,1,-.3,.28),ll=mkLid(tg,mat,-.65,.96,-.45,.3),crew=mkCrew(tg,cm,hm,sk,.65,.7,-.3);
  /* ---- radar de busca: mastro, prato curvo duplo, corneta, IFF e luz vermelha ---- */
  const sr=new THREE.Group();sr.position.set(0,.82,-1.1);
  const mast=new THREE.Mesh(new THREE.CylinderGeometry(.1,.14,1.0,8),dark);mast.position.y=.5;
  const R1=1.3,dish=new THREE.Mesh(new THREE.CylinderGeometry(R1,R1,2.2,20,1,true,Math.PI-.5,1).rotateZ(Math.PI/2).translate(0,1.5,R1+.1),dishM);
  const dish2=new THREE.Mesh(new THREE.CylinderGeometry(R1*.9,R1*.9,1.9,16,1,true,Math.PI-.4,.8).rotateZ(Math.PI/2).translate(0,2.25,R1*.9+.2),dishM2);
  const horn=bx(.1,.1,.4,dark,0,1.5,.7);horn.rotation.x=0;
  const iff=new THREE.Mesh(new THREE.BoxGeometry(1.8,.08,.1),dark);iff.position.set(0,2.65,.1);
  sr.add(mast,dish,dish2,horn,iff,bx(.2,.9,.12,dark,0,1.05,.08),bx(.06,.9,.06,dark,0,1.6,.3));
  const beac=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),radM);beac.position.set(.85,2.7,.1);sr.add(beac);
  tg.add(sr);
  /* ---- radar de tiro: pedestal, garfo, prato parabolico com alimentador oscilante ---- */
  const tgr=new THREE.Group();tgr.position.set(0,.82,1.05);
  tgr.add(bx(.7,.35,.7,MT,0,.17,0),bx(.12,.55,.12,DK,-.42,.65,0),bx(.12,.55,.12,DK,.42,.65,0));
  const tdish=new THREE.Group();tdish.position.set(0,.8,0);
  tdish.add(new THREE.Mesh(new THREE.SphereGeometry(.62,16,8,0,6.283,0,.95).rotateX(Math.PI/2).translate(0,0,-.25),dishM2),bx(.1,.1,.3,DK,0,0,-.35));
  const feed=new THREE.Group();feed.add(bx(.05,.05,.7,DK,0,0,.15),new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),dark).translateZ(.5));feed.position.set(0,0,.1);tdish.add(feed);
  tgr.add(tdish);tg.add(tgr);
  /* ---- canhoes: berços laterais, camisas, freios de boca, tubos de gas, calhas de ejecao ---- */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb();bp.position.set(0,.5,1.35);
  const gb=[];
  for(const s of[-1,1]){B.b(.5,.6,.9,'M',s*1.62,0,.2);B.b(.42,.12,.5,DK,s*1.62,.34,.2);B.c(.19,.22,.2,RB,s*1.62,0,.7,'z');
    const gg=new THREE.Group(),K=mb();gg.position.set(s*1.62,0,0);
    K.c(.075,.075,3.2,DK,0,0,2.1,'z');K.c(.14,.14,1.2,'M',0,0,1.1,'z');K.c(.1,.1,.3,'M',0,0,2.05,'z');
    for(let k=0;k<5;k++)K.c(.11,.11,.05,DK,0,0,1.5+k*.33,'z');
    K.c(.13,.13,.35,DK,0,0,3.55,'z');K.b(.2,.05,.2,DK,0,0,3.5);K.b(.2,.05,.2,DK,0,0,3.65);K.c(.03,.03,1.1,MT,0,.14,1.8,'z');K.c(.1,.1,.4,MT,0,-.12,.3,'z');K.out(gg,mat);
    bar.add(gg);gg.userData.r=0;gb.push(gg)}
  B.out(bp,mat);
  const fl=new THREE.Group();
  for(const s of[-1,1]){const f=new THREE.Group();f.position.set(s*1.62,0,0);
    f.add(new THREE.Mesh(new THREE.ConeGeometry(.3,1.2,10).rotateX(-Math.PI/2),flashM).translateZ(4.3),new THREE.Mesh(new THREE.SphereGeometry(.25,8,6),flashM).translateZ(3.8));fl.add(f)}
  fl.visible=false;bar.add(fl);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,fp,sr,tgr,tdish,feed,beac,radM,gb,lid:[cl,ll],crew,fl,brkM,wheels,trk,mat,dark,gep:true,cannon:true,spd:1.25,trn:.95,L:3.7,W:1.9,mz:4.2,fk:.28,rld:1.1,wd:2.2,armor:.9,hp:95,TY:1.5,gLf:-9,gk:0,ak:0}));
}
function animGep(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.radM.color.setHex(0x220000);return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/14,0,1),d=trkStep(t,dt,1.5);
  t.wheels.forEach((w,i)=>{w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*11+i*1.7)*.02*th});
  t.hull.position.y=Math.sin(now*32+t.x)*(.008+.01*th)-t.recoil*.015;t.hull.rotation.x=-t.recoil*.012;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  for(const f of t.fp)f.rotation.x=clamp(-t.v*.03,-.5,.5)+Math.sin(now*14+f.position.x)*.05*th;
  /* radar de busca gira mais rapido com alvo; radar de tiro acompanha e o alimentador oscila */
  t.ak+=((t.mgt?1:0)-t.ak)*Math.min(1,dt*3);t.sr.rotation.y+=dt*(2.8+t.ak*3.5);
  t.tdish.rotation.y=Math.sin(now*.9+t.x*.1)*(t.mgt?.12:.7);t.tdish.rotation.x=-.25+Math.sin(now*1.3+t.z*.1)*(t.mgt?.04:.15);
  t.feed.rotation.z+=dt*9;t.feed.position.x=Math.sin(now*14)*.015;
  t.radM.color.setHex(Math.sin(now*5)>0?0xff2a1a:0x4a0c08);
  /* rajada de 5 tiros alternando os dois canos */
  if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=.07;t.bfi=1;fire(t);t.bfi=0}}
  if(t.lf!==t.gLf){t.gLf=t.lf;t.gk++;const gg=t.gb[t.gk&1];gg.userData.r=1;gg.localToWorld(v2.set(0,-.1,.6));puff(v2,0xd9b24a,.2,2.5,.5,1.2)}
  for(const gg of t.gb){if(gg.userData.r>0)gg.userData.r=Math.max(0,gg.userData.r-dt*9);gg.position.z=-gg.userData.r*.4}
  tankFx(t,dt,now,th,{ex:[[.9,1.3,-3.8],[-.9,1.3,-3.8]],dk:[[1.7,.2,-3.6],[-1.7,.2,-3.6]],mz:4.3,rr:3,rc:.3});
  if(t.fl.visible){const k=t.gk&1;t.fl.children.forEach((c,i)=>c.visible=i===k)}
  mgScan(t,dt,170);smokeQ(t,dt,1.5,.8,-.8);
}

/* ---------- AH-64 Apache (EUA) ---------- */
const apHf=(()=>{const l=[vcol(new THREE.CylinderGeometry(.075,.075,1.5,8).rotateX(Math.PI/2),0x5b6046),vcol(new THREE.ConeGeometry(.075,.4,8).rotateX(Math.PI/2).translate(0,0,.95),0x2b2d28)];
  for(let k=0;k<4;k++){const g=new THREE.BoxGeometry(k%2?.3:.03,k%2?.03:.3,.28);g.translate(0,0,-.65);l.push(vcol(g,0x2b2d28))}return mergeG(l)})();
const gunG=new THREE.SphereGeometry(.13,6,5),gunM=new THREE.MeshBasicMaterial({color:0xffe08a});
{const st=document.createElement('style');st.textContent='#abtns{position:fixed;right:20px;bottom:calc(150px + env(safe-area-inset-bottom,0px));display:none;flex-direction:column;gap:8px;z-index:3}#altb{position:fixed;left:50%;bottom:calc(16px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);display:none;font:700 18px "Saira Condensed",Arial,sans-serif;color:#f3ecd8;text-shadow:0 0 4px #000,0 0 4px #000;pointer-events:none}.air #altb{display:block}.t.air #abtns{display:grid;grid-template-columns:repeat(2,auto);bottom:calc(36px + 100px*var(--k,1) + env(safe-area-inset-bottom,0px));transform:scale(var(--k,1));transform-origin:right bottom}.t.air #joy{transform:scale(var(--k,1));transform-origin:left bottom}.t.air #fire{transform:scale(var(--k,1));transform-origin:right bottom}.t .ponly{display:none}#aph{position:fixed;left:14px;bottom:calc(74px + env(safe-area-inset-bottom,0px));display:none;font:600 15px "Saira Condensed",Arial,sans-serif;line-height:1.35;color:#f3ecd8;background:rgba(26,30,20,.7);border:1px solid rgba(243,236,216,.3);border-radius:4px;padding:6px 10px;pointer-events:none}.air:not(.t) #aph{display:block}#abtns button{width:74px;height:46px;font-size:17px;padding:0;border-radius:6px;opacity:.85}';document.head.appendChild(st);
  const AL=document.createElement('div');AL.id='altb';document.body.appendChild(AL);const AB=document.createElement('div');AB.id='abtns';AB.innerHTML='<button class="abtn" data-k="KeyR">▲ Subir</button><button class="abtn" data-k="KeyF">▼ Descer</button><button class="abtn" data-k="KeyG">Foguetes</button><button class="abtn" data-k="KeyH">Míssil</button>';document.body.appendChild(AB);
  for(const b of AB.children){const k=b.dataset.k;b.className='abtn';b.addEventListener('touchstart',e=>{keys[k]=true;e.preventDefault()},{passive:false});b.addEventListener('touchend',()=>keys[k]=false);b.addEventListener('touchcancel',()=>keys[k]=false);b.addEventListener('mousedown',()=>keys[k]=true);b.addEventListener('mouseup',()=>keys[k]=false)}}
/* ---------- adaptação a celular, tablet e PC ---------- */
function fitAir(){document.documentElement.style.setProperty('--k',clamp(Math.min(innerWidth,innerHeight)/430,.85,1.7).toFixed(2))}
fitAir();addEventListener('resize',fitAir);
{const H=document.createElement('div');H.id='aph';H.innerHTML='W S A D voar na direção da mira<br>Mouse mirar · Clique canhão<br>G foguetes · H míssil Hellfire<br>R F ou roda do mouse: altitude';document.body.appendChild(H)}
addEventListener('wheel',e=>{if(running&&player.air&&!player.dead){player.aw=clamp((player.aw===undefined?player.alt:player.aw)-Math.sign(e.deltaY)*8,4,90);e.preventDefault()}},{passive:false});
const padS={};let padOn=false;
function padPoll(dt){ /* controle Xbox/PlayStation: analógico esquerdo voa, direito mira, RT atira, RB/LB altitude, X foguetes, Y míssil */
  const pads=navigator.getGamepads?navigator.getGamepads():[];let gp=null;for(const q of pads)if(q&&q.connected){gp=q;break}if(!gp)return;
  const ax=i=>Math.abs(gp.axes[i]||0)>.15?gp.axes[i]:0;
  for(const [b,k] of [[7,'Space'],[5,'KeyR'],[4,'KeyF'],[2,'KeyG'],[3,'KeyH']]){const v=!!(gp.buttons[b]&&gp.buttons[b].pressed);if(padS[k]!==v){padS[k]=v;keys[k]=v}}
  const lx=ax(0),ly=ax(1);if(lx||ly||padOn){if(jid===null){stick.x=lx;stick.y=ly}padOn=!!(lx||ly)}
  const rx=ax(2),ry=ax(3);if(rx||ry){player.yaw-=rx*2.4*dt;player.pitch=clamp(player.pitch-ry*1.5*dt,-.9,.75)}
}
addEventListener('gamepadconnected',()=>toast('Controle conectado'));
renderer.setPixelRatio(Math.min(Math.min(devicePixelRatio||1,2),matchMedia('(pointer:coarse)').matches?1.6:2));
function makeApache(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0x4a5036}),dark=new THREE.MeshLambertMaterial({color:0x26282a}),
    glass=new THREE.MeshLambertMaterial({color:0x2a4a5c,emissive:0x0a1a24,transparent:true,opacity:.62}),flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),
    g=new THREE.Group(),bd=new THREE.Group(),K=0x26282a,Kb=0x3a3d38,eg=(r1,r2,l,sx,sy)=>new THREE.CylinderGeometry(r1,r2,l,14).rotateX(Math.PI/2).scale(sx,sy,1);
  g.rotation.order='YXZ';bd.position.y=.3;g.add(bd);
  const T=mb();
  /* fuselagem afilada, nariz, baias de aviônicos, naceles dos motores e escapes IR */
  T.g(eg(.25,.62,1.7,1,1),'M',0,1.55,5.2);T.g(eg(.62,.95,2.6,1,1),'M',0,1.6,3.2);T.g(eg(.95,.95,3.4,1.05,1.02),'M',0,1.7,.2);
  T.g(eg(.95,.5,2.6,1,1),'M',0,1.85,-2.8);T.g(eg(.5,.26,4.2,.85,1),'M',0,2.1,-6.2,.06);
  T.b(.7,.4,1.4,K,0,2.0,2.3);T.b(.7,.35,1.0,K,0,1.75,4.2);T.b(.38,.3,.5,K,0,2.05,5.35);
  T.b(5.2,.12,1.45,'M',0,1.7,.4);T.g(eg(.55,.75,2,1.15,.7),'M',0,3.0,.2);
  T.c(.2,.24,.95,K,0,3.55,.2);T.c(.1,.1,.5,K,0,4.3,.2);T.g(new THREE.SphereGeometry(.42,12,8).scale(1,.8,1),'M',0,4.7,.2); /* radar Longbow */
  T.b(.14,2.2,1.6,'M',0,3.15,-7.7,-.32);T.b(.5,.5,.8,'M',0,2.3,-8.0);
  for(const s of[-1,1]){
    T.b(.45,.65,2.2,'M',s*.88,1.2,3.2);T.g(eg(.52,.52,3.8,1,.92),'M',s*1.12,2.55,-.8);T.c(.4,.4,.1,K,s*1.12,2.55,1.15,'z');T.c(.26,.2,.9,Kb,s*1.12,2.6,-3.0,'z');
    T.b(.14,.35,.7,K,s*1.45,1.5,.45);T.b(.14,.35,.7,K,s*2.4,1.5,.45);
    T.c(.26,.26,2.3,Kb,s*1.45,1.18,.45,'z');T.c(.24,.24,.04,K,s*1.45,1.18,1.62,'z'); /* casulo de foguetes de 19 tubos */
    for(let k=0;k<7;k++){const a=k*1.047,r=k?.15:0;T.c(.05,.05,.05,0x0e0e0e,s*1.45+Math.cos(a)*r,1.18+Math.sin(a)*r,1.65,'z')}
  }
  T.out(bd,mat);
  const c1=new THREE.Mesh(eg(.5,.58,1.8,.95,.85),glass),c2=new THREE.Mesh(eg(.28,.52,1.7,.95,.8),glass);c1.position.set(0,2.6,2.2);c2.position.set(0,2.2,4.05);bd.add(c1,c2); /* cabines em tandem */
  /* rotor principal de 4 pás com pontas amarelas */
  const rot=new THREE.Group();rot.position.set(0,4.05,.2);const MR=mb();MR.c(.32,.32,.28,K,0,0,0);
  for(let k=0;k<4;k++){const bg=new THREE.BoxGeometry(6.6,.05,.5),tp=new THREE.BoxGeometry(.5,.052,.5);bg.translate(3.8,0,0);bg.rotateX(.08);tp.translate(7.1,0,0);tp.rotateX(.08);MR.g(bg,0x1d1f1c,0,0,0,0,k*Math.PI/2,0);MR.g(tp,0xe8c020,0,0,0,0,k*Math.PI/2,0)}
  MR.out(rot,dark);const disc=new THREE.Mesh(new THREE.CircleGeometry(7.3,32).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0x202020,transparent:true,opacity:.1,depthWrite:false,side:THREE.DoubleSide}));rot.add(disc);bd.add(rot);
  /* rotor de cauda (pás em X assimétrico) e estabilizador móvel */
  const trot=new THREE.Group();trot.position.set(.5,3.0,-8.3);const TR=mb();TR.c(.1,.1,.14,K,0,0,0,'x');
  for(const a of[0,55,180,235]){const bl=new THREE.BoxGeometry(.04,.95,.2);bl.translate(0,.55,0);bl.rotateX(a*Math.PI/180);TR.g(bl,0x1d1f1c,0,0,0)}
  TR.out(trot,dark);bd.add(trot);
  const stab=new THREE.Group();stab.position.set(0,2.35,-7.9);stab.add(new THREE.Mesh(new THREE.BoxGeometry(3.6,.09,1.0),mat));bd.add(stab);
  /* mísseis Hellfire (8) nos pilones externos */
  const hfs=[];for(const s of[-1,1])for(let i=0;i<4;i++){const m=new THREE.Mesh(apHf,vcM);m.position.set(s*2.4+(i%2?.17:-.17),i>1?.96:1.2,.2);bd.add(m);hfs.push(m)}
  /* torre de sensores TADS e canhão M230 de 30 mm */
  const tg=new THREE.Group();tg.position.set(0,1.05,5.0);bd.add(tg);const TD=mb();TD.g(new THREE.SphereGeometry(.32,12,10),K,0,0,0);TD.b(.5,.12,.4,Kb,0,.28,-.1);TD.out(tg,dark);
  const eye=new THREE.Mesh(new THREE.SphereGeometry(.13,8,6),glass);eye.position.set(0,-.02,.27);tg.add(eye);
  const bp=new THREE.Group();bp.position.set(0,-.3,.1);tg.add(bp);const GN=mb();GN.b(.22,.26,.6,Kb,0,0,.2);GN.c(.045,.05,1.8,K,0,0,1.1,'z');GN.c(.075,.075,.18,K,0,0,2.0,'z');GN.out(bp,dark);
  const fl=new THREE.Mesh(new THREE.ConeGeometry(.2,.8,8).rotateX(Math.PI/2),new THREE.MeshBasicMaterial({color:0xffcf5a,transparent:true,opacity:.9,depthWrite:false}));fl.position.z=2.5;fl.visible=false;bp.add(fl);
  /* luzes de navegação, farol anticolisão e antena com a bandeira do time */
  const nl=(c,x,y,z)=>{const m=new THREE.Mesh(new THREE.SphereGeometry(.09,6,5),new THREE.MeshBasicMaterial({color:c}));m.position.set(x,y,z);bd.add(m);return m};
  nl(0xff2020,2.62,1.7,.4);nl(0x20ff40,-2.62,1.7,.4);const bc=nl(0xff2a1a,0,4.3,-8.05);
  const ant=new THREE.Group();ant.position.set(0,4.3,-7.75);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.012,.02,1.2,5),dark),fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);rd.position.y=.6;fg.position.set(0,1.0,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);bd.add(ant);
  /* trem de pouso: duas rodas principais e roda de cauda */
  const GR=mb();for(const s of[-1,1]){GR.b(.1,.95,.14,K,s*1.25,.85,.9,0,0,s*.12);GR.c(.3,.3,.2,K,s*1.3,.32,.9,'x')}
  GR.b(.07,1.8,.1,K,0,1.2,-6.4);GR.c(.2,.2,.1,K,0,.2,-6.4,'x');GR.out(g,dark);
  g.traverse(o=>o.castShadow=true);disc.castShadow=false;scene.add(g);
  const t={g,bd,tg,bp,rot,disc,trot,stab,ant,bc,fl,hfs,hfR:[],mat,dark,air:true,ap:true,wd:99,alt:14,altT:16+Math.random()*14,rpm:1,pit:0,rol:0,gnd:0,x:0,z:0,y:0,hd:0,v:0,yaw:0,pitch:.05,cd:0,hp:100,dead:false,rld:1.3,mz:2.3,clk:0,gn:0,gT:0,fT:0,sv:0,sT:0};
  tanks.push(t);return t;
}
function flyStep(t,dt,thr,turn){
  t.wet=0;t.st=turn;const P=t.isPlayer,sp=t.spd||1;let wx,wz;
  if(P){ /* voo livre: W/S e A/D relativos à mira; o corpo gira para onde você mira */
    const f=Math.sin(t.yaw),c=Math.cos(t.yaw),fw=thr*(thr>0?28:12),sd=turn*18;
    wx=(f*fw+c*sd)*sp;wz=(c*fw-f*sd)*sp;t.hd+=clamp(angDiff(t.yaw,t.hd),-2.6*dt,2.6*dt);
    const inp=(keys.KeyR?1:0)-(keys.KeyF?1:0);if(inp)t.aw=undefined;t.lv=(t.lv||0)+(inp*16-(t.lv||0))*Math.min(1,dt*4);t.alt=clamp(t.alt+t.lv*dt,4,90);if(t.aw!==undefined){t.alt+=(t.aw-t.alt)*Math.min(1,dt*3);if(Math.abs(t.aw-t.alt)<.15)t.aw=undefined}
  }else{
    t.hd+=turn*1.2*dt;const s=(thr>0?thr*26:thr*8)*sp;wx=Math.sin(t.hd)*s;wz=Math.cos(t.hd)*s;t.alt+=((t.altT||18)-t.alt)*Math.min(1,dt*.6);
  }
  const k=Math.min(1,dt*(P?2.2:1.3)*(t.ag||1));t.fvx=(t.fvx||0)+(wx-(t.fvx||0))*k;t.fvz=(t.fvz||0)+(wz-(t.fvz||0))*k;
  const sh=Math.sin(t.hd),ch=Math.cos(t.hd);t.v=t.fvx*sh+t.fvz*ch;const vl=t.fvx*ch-t.fvz*sh;
  const rate=(t.hd-(t.ph===undefined?t.hd:t.ph))/Math.max(dt,.001);t.ph=t.hd;
  const q=Math.min(1,dt*3);t.pit+=(clamp(t.v/28,-.4,1)*.26-t.pit)*q;t.rol+=(-clamp(vl/18,-1,1)*.4-clamp(rate*.1,-.3,.3)-t.rol)*q;
  const nx=t.x+t.fvx*dt,nz=t.z+t.fvz*dt;
  if(Math.hypot(nx,nz)>HALF-6){t.fvx*=-.2;t.fvz*=-.2;return}
  t.x=nx;t.z=nz;const gr=Math.max(getHV(t.x,t.z),WATER);t.gy=t.gy===undefined?gr:t.gy+(gr-t.gy)*Math.min(1,dt*2.5);t.y=Math.max(t.gy+t.alt,gr+3.5);
  for(const b of buildings){const dx=t.x-b.x,dz=t.z-b.z,rx=b.w/2+3.5,rz=b.d/2+3.5;
    if(Math.abs(dx)<rx&&Math.abs(dz)<rz&&t.y<b.y+b.h+3){if(rx-Math.abs(dx)<rz-Math.abs(dz))t.x=b.x+Math.sign(dx||1)*rx;else t.z=b.z+Math.sign(dz||1)*rz;t.fvx*=.4;t.fvz*=.4}}
}
function rkSmall(){const m=new THREE.Group(),b=new THREE.Mesh(rkBody,rkMat),nz=new THREE.Mesh(rkNose,rkTip),fl=new THREE.Mesh(rkFlameG,rkFlame);b.scale.set(.6,.6,.7);nz.scale.set(.6,.6,.7);nz.position.z=.8;fl.position.z=-.75;fl.scale.z=2.2;m.add(b,nz,fl);return m}
function apRound(t){
  t.bp.localToWorld(v1.set(0,0,2.1));const d=dirOf(t.yaw+(Math.random()-.5)*.03,t.pitch+(Math.random()-.5)*.02),m=new THREE.Mesh(gunG,gunM);m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED*1.5),owner:t,age:0,k:.13});t.fT=.05;t.gk=((t.gk||0)+1)%4;if(!t.gk)sfx(.3*near(v1),.1);t.bp.position.z=-.1;
}
function apRocket(t){
  t.rs2=-(t.rs2||1);const s=t.rs2;t.g.localToWorld(v1.set(s*1.45,1.5,1.9));
  const d=dirOf(t.yaw+(Math.random()-.5)*.04,t.pitch+(Math.random()-.5)*.03),m=rkSmall();m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED*1.15),owner:t,age:0,k:.33,rk:true,tt:0});
  puff(v1,0xffe9a0,.8,2,.25,.4);t.g.localToWorld(v2.set(s*1.45,1.5,-.2));puff(v2,0xcfc8b8,1.2,4,.9,.5);if(t.sv%2===0)sfx(.35*near(v1),.2);
}
function apHell(t){
  const m=t.hfs.find(q=>q.visible);if(!m)return false;
  m.visible=false;t.hfR.push({m,at:t.clk+8});m.getWorldPosition(v1);
  const d=dirOf(t.yaw,t.pitch),h=new THREE.Group(),fl=new THREE.Mesh(rkFlameG,rkFlame);fl.position.z=-.9;fl.scale.z=2.2;h.add(new THREE.Mesh(apHf,vcM),fl);h.scale.setScalar(1.3);
  v1.addScaledVector(d,1.2);h.position.copy(v1);scene.add(h);
  shells.push({m:h,v:d.multiplyScalar(SPEED*1.3),owner:t,age:0,k:.85,rk:true,tt:0});
  puff(v1,0xffe9a0,1.2,3,.3,.4);for(let i=0;i<3;i++)puff(v1,0xcfc8b8,1.6,5,1.2,.8);sfx(.6*near(v1),.4);return true;
}
function apFire(t){
  if(!t.isPlayer){const r=Math.random();if(r<.25&&apHell(t))return;if(r<.5){t.sv=4;t.sT=0;return}}
  t.gn=10;t.gT=0;
}
function animApache(t,dt){
  t.clk+=dt;const now=performance.now()/1000;
  if(!t.dead){
    const sp=t.rpm=Math.min(1,t.rpm+dt*.5);
    if(t.isPlayer){t.ab=(t.ab||0)-dt;if(t.ab<=0){t.ab=.2;const e=document.getElementById('altb');if(e)e.textContent='Altitude '+Math.round(t.y-Math.max(getH(t.x,t.z),WATER))+' m · '+Math.round(Math.hypot(t.fvx||0,t.fvz||0)*3.6)+' km/h'}}
    t.rot.rotation.y+=sp*dt*22;t.trot.rotation.x+=sp*dt*40;t.disc.material.opacity=.06+.06*sp;
    t.rot.rotation.x+=(-t.pit*.3-t.rot.rotation.x)*Math.min(1,dt*3);t.rot.rotation.z+=(t.rol*.3-t.rot.rotation.z)*Math.min(1,dt*3);
    t.stab.rotation.x=-.2+clamp(t.v/24,-.3,1)*.5+Math.sin(now*1.3)*.015;
    t.bd.position.y=.3+Math.sin(now*1.7+t.x*.1)*.05+Math.sin(now*23)*.008*sp;
    t.ant.rotation.x=-t.v*.01+Math.sin(now*4)*.05;t.bc.material.color.setHex(now%1<.12?0xff2a1a:0x2a0606);
    const agl=t.y-Math.max(getH(t.x,t.z),WATER); /* vento do rotor levanta poeira ou espuma perto do chão */
    if(agl<16&&Math.random()<dt*9*sp){const a=Math.random()*6.283,r=2+Math.random()*8,px=t.x+Math.cos(a)*r,pz=t.z+Math.sin(a)*r,gh=getH(px,pz);v2.set(px,Math.max(gh,WATER)+.3,pz);puff(v2,gh<WATER?0xdfeff6:0xa89a78,2.8,6,.9,.8)}
    t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.25;for(const s of[-1,1]){t.g.localToWorld(v2.set(s*1.12,2.95,-3.5));puff(v2,0x9a9690,.35,1,.5,.4)}}
    if(t.gn>0){t.gT-=dt;if(t.gT<=0){t.gT=.055;t.gn--;apRound(t)}}
    if(t.sv>0){t.sT-=dt;if(t.sT<=0){t.sT=.09;t.sv--;apRocket(t)}}
    t.fl.visible=t.fT>0;if(t.fT>0){t.fT-=dt;t.fl.scale.setScalar(.7+Math.random()*.6)}
    t.bp.position.z-=t.bp.position.z*Math.min(1,dt*20);
    for(let i=t.hfR.length-1;i>=0;i--)if(t.clk>=t.hfR[i].at){t.hfR[i].m.visible=true;t.hfR.splice(i,1)}
  }else{ /* abatido: gira sem controle, cai e explode no chão */
    t.rpm=Math.max(0,t.rpm-dt*.25);t.rot.rotation.y+=t.rpm*dt*22;t.fl.visible=false;const gp=t.g.position;
    if(!t.gnd){
      t.vy=(t.vy||0)-G*dt*.7;gp.y+=t.vy*dt;t.g.rotation.y+=dt*(2-t.vy*.12);t.g.rotation.z+=dt*.8;
      t.cT=(t.cT||0)-dt;if(t.cT<=0){t.cT=.07;puff(gp,Math.random()<.4?0xff8a2e:0x1f1e1c,1.6,1.5,1.6,1.5)}
      const gh=Math.max(getH(gp.x,gp.z),WATER)+.8;
      if(gp.y<=gh){gp.y=gh;t.gnd=1;t.y=gh;boom(new THREE.Vector3(gp.x,gh+1,gp.z),t,.9);if(t.isPlayer)shake=Math.max(shake,2)}
    }else{t.burn=(t.burn===undefined?25:t.burn)-dt;if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,2.4,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.4,1.5,2,3)}}}
  }
}
/* ---------- CH-47 Chinook (EUA): rotores em tandem, rampa traseira, miniguns nas portas, gancho de carga e tropa a bordo ---------- */
const chCrG=(()=>{const l=[vcol(new THREE.BoxGeometry(1.5,1.05,1.05),0x5b6038)];
  for(const x of[-.45,.45])l.push(vcol(new THREE.BoxGeometry(.1,1.09,1.09).translate(x,0,0),0x2b2d28));
  l.push(vcol(new THREE.BoxGeometry(.55,.03,.55).translate(0,.53,0),0xe8c020));
  for(const z of[-.54,.54])l.push(vcol(new THREE.BoxGeometry(1.2,.12,.03).translate(0,.1,z),0xd8d0b0));
  return mergeG(l)})();
const chFlG=new THREE.ConeGeometry(.13,.6,8).rotateX(Math.PI/2),chFlM=new THREE.MeshBasicMaterial({color:0xffcf5a,transparent:true,opacity:.9,depthWrite:false});
const chStrap=(a,b,r,col)=>{const d=new THREE.Vector3().subVectors(b,a),L=d.length(),g=new THREE.CylinderGeometry(r,r,L,5),
  q=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),d.clone().normalize());
  g.applyMatrix4(new THREE.Matrix4().compose(a.clone().add(b).multiplyScalar(.5),q,new THREE.Vector3(1,1,1)));return vcol(g,col)};
function chSoldier(l,x,y,z,ry){ /* soldado sentado: tronco, pernas, cabeça, capacete e fuzil */
  const P=[[new THREE.BoxGeometry(.5,.62,.34),0x5a6038,0,.62,0],[new THREE.BoxGeometry(.46,.32,.62),0x4c5230,0,.2,.34],
    [new THREE.SphereGeometry(.19,8,6),0xc9a27e,0,1.1,.02],[new THREE.SphereGeometry(.235,8,6,0,6.283,0,1.45),0x3a4a2a,0,1.14,0],[new THREE.BoxGeometry(.07,.07,.85),0x1d1f1c,.12,.75,.2]];
  for(const[g,c,px,py,pz]of P){g.translate(px,py,pz);g.rotateY(ry);g.translate(x,y,z);l.push(vcol(g,c))}
}
function chGun(bd,s,K,Kb){ /* minigun M134 de seis canos que gira ao atirar, com atirador de porta */
  const tg=new THREE.Group();tg.position.set(s*1.95,2.5,2.4);bd.add(tg);const bp=new THREE.Group();tg.add(bp);
  const G0=mb();G0.c(.05,.05,.8,K,0,-.5,-.1);G0.b(.34,.1,.34,K,0,-.9,-.1);G0.b(.5,.5,.34,0x5a6038,0,-.1,-.62);G0.g(new THREE.SphereGeometry(.22,8,6),0x3a4a2a,0,.3,-.62);G0.out(tg,vcM);
  const G1=mb();G1.b(.32,.34,.62,Kb,0,0,.1);G1.c(.1,.1,.16,K,0,0,.48,'z');G1.b(.1,.2,.3,K,0,.26,.0);G1.out(bp,vcM);
  const sp=new THREE.Group();sp.position.set(0,0,.58);bp.add(sp);const B=mb();
  for(let k=0;k<6;k++){const a=k*1.0472;B.c(.028,.028,.95,K,Math.cos(a)*.075,Math.sin(a)*.075,.47,'z')}
  B.c(.1,.1,.05,Kb,0,0,.08,'z');B.c(.1,.1,.05,Kb,0,0,.5,'z');B.c(.1,.1,.05,Kb,0,0,.9,'z');B.out(sp,vcM);
  const fl=new THREE.Mesh(chFlG,chFlM);fl.position.z=1.95;fl.visible=false;bp.add(fl);
  return{tg,bp,sp,fl};
}
function makeCh47(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0x4b5036}),dark=new THREE.MeshLambertMaterial({color:0x26282a}),
    glass=new THREE.MeshLambertMaterial({color:0x2a4a5c,emissive:0x0a1a24,transparent:true,opacity:.58}),flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),
    discM=new THREE.MeshBasicMaterial({color:0x202020,transparent:true,opacity:.1,depthWrite:false,side:THREE.DoubleSide}),
    g=new THREE.Group(),bd=new THREE.Group(),K=0x26282a,Kb=0x3a3d38,RB=0x1b1b1a,eg=(r1,r2,l,sx,sy)=>new THREE.CylinderGeometry(r1,r2,l,14).rotateX(Math.PI/2).scale(sx,sy,1);
  g.rotation.order='YXZ';g.add(bd);const T=mb();
  /* cabine principal arredondada, assoalho, cockpit baixo e nariz */
  T.b(3.5,1.9,8.0,'M',0,2.2,.2);T.g(eg(1,1,8.0,1.75,.55),'M',0,3.15,.2);T.b(3.1,.5,7.6,'M',0,1.0,.2);
  T.g(eg(1,1,2.8,1.4,.8),'M',0,2.4,5.6);T.g(eg(.55,1,1.6,1.4,.75),'M',0,2.2,7.6);T.b(.9,.35,.9,K,0,1.55,8.0);
  /* estufa do cockpit: colunas, teto e pára-brisas em glass */
  T.b(2.8,.12,2.7,'M',0,4.0,5.65);for(const s of[-1,1])for(const z of[4.4,5.7,6.9])T.b(.1,1.0,.1,'M',s*1.38,3.5,z);
  for(const x of[-1.3,0,1.3])T.b(.1,.95,.1,'M',x,3.5,7.0,-.35);
  T.b(1.6,.12,.7,K,0,3.1,6.6);T.b(1.5,.5,.1,K,0,3.3,4.25);
  /* pilone dianteiro, mastro e cubo */
  T.b(1.6,1.2,2.4,'M',0,4.6,5.0);T.c(.3,.38,.7,K,0,5.45,5.7);T.c(.45,.45,.3,Kb,0,5.8,5.7);
  /* sponsons (tanques laterais) com proa e popa afiladas */
  for(const s of[-1,1]){T.g(eg(.55,.55,6.2,1,.95),'M',s*1.65,1.35,.7);T.g(eg(.2,.55,1.0,1,.95),'M',s*1.65,1.35,4.3);T.g(eg(.55,.25,.9,1,.95),'M',s*1.65,1.35,-2.85)}
  /* compartimento traseiro aberto: paredes, teto, piso, anteparo e luz */
  for(const s of[-1,1])T.b(.14,2.95,3.1,'M',s*1.72,2.3,-5.35);
  T.b(3.6,.16,3.1,'M',0,3.75,-5.35);T.g(eg(1,1,3.1,1.8,.3),'M',0,3.62,-5.35);T.b(3.4,.1,3.1,K,0,.98,-5.35);T.b(3.3,2.8,.05,K,0,2.35,-3.82);T.b(.3,.05,2.8,0xfff0c0,0,3.62,-5.35);
  for(const s of[-1,1]){T.b(.08,.5,.5,Kb,s*1.55,2.0,-4.4);T.b(.08,.5,.5,Kb,s*1.55,2.0,-6.3)}
  /* pilone traseiro alto, nacelas dos motores com entrada e escapes, empenagem */
  T.b(1.9,3.4,2.9,'M',0,5.5,-5.9);T.b(.1,1.5,1.3,'M',0,6.9,-7.6);T.c(.3,.38,.7,K,0,7.55,-6.2);T.c(.45,.45,.3,Kb,0,7.9,-6.2);
  for(const s of[-1,1]){T.g(eg(.7,.7,3.4,1.05,.95),'M',s*1.55,4.55,-4.55);T.c(.62,.55,.14,K,s*1.55,4.55,-2.8,'z');T.c(.5,.5,.04,0x111111,s*1.55,4.55,-2.72,'z');
    T.c(.5,.4,.5,K,s*1.55,4.55,-6.55,'z');T.b(.5,1.0,2.6,'M',s*1.2,4.2,-5.1)}
  /* calçadas antiderrapantes, janelas da cabine e janelas das portas */
  T.b(1.4,.03,3.4,0x2b2d28,0,3.72,1.2);T.b(1.2,.03,2.0,0x2b2d28,0,3.9,-5.35);
  for(const s of[-1,1]){for(const z of[.9,-.8,-2.5])T.b(.05,.62,.9,0x1d3340,s*1.77,2.7,z);T.b(.05,.85,1.1,0x101820,s*1.77,2.65,2.4);T.b(.04,1.9,.06,K,s*1.78,2.2,3.45)}
  /* barriga com escotilha do gancho, nariz com farol */
  T.b(.9,.04,1.0,K,0,.74,.4);T.c(.1,.1,.12,0xfff2b0,0,1.7,8.2,'z');
  T.out(bd,mat);
  /* vidros */
  const gl=[],gp=(w,h,d,x,y,z,rx)=>{const q=new THREE.BoxGeometry(w,h,d);if(rx)q.rotateX(rx);q.translate(x,y,z);gl.push(q)};
  gp(1.25,.95,.05,.66,3.52,7.0,-.35);gp(1.25,.95,.05,-.66,3.52,7.0,-.35);
  for(const s of[-1,1]){gp(.05,.9,1.2,s*1.38,3.5,5.0);gp(.05,.9,1.2,s*1.38,3.5,6.3)}
  gp(1.2,.05,1.1,0,3.1,4.3);
  bd.add(new THREE.Mesh(mergeG(gl),glass));
  /* pilotos olhando em volta */
  const mkP=(x)=>{const p=new THREE.Group(),l=[];chSoldier(l,0,0,0,0);p.add(new THREE.Mesh(mergeG(l),vcM));p.position.set(x,2.7,5.55);bd.add(p);return p};
  const pL=mkP(.55),pR=mkP(-.55);
  /* tropa sentada no compartimento traseiro, uma fileira por lado */
  const mkT=(s)=>{const l=[],tr=new THREE.Group();for(const z of[-4.5,-5.35,-6.2]){chSoldier(l,s*1.05,1.45,z,-s*Math.PI/2);l.push(vcol(new THREE.BoxGeometry(.4,.1,.75).translate(s*1.2,1.3,z),Kb))}
    tr.add(new THREE.Mesh(mergeG(l),vcM));bd.add(tr);return tr};
  const trL=mkT(1),trR=mkT(-1);
  /* rotores de 3 pás em tandem, pontas amarelas na frente e vermelhas atrás */
  const mkRot=(tipC)=>{const gr=new THREE.Group(),R=mb();R.c(.2,.26,.5,K,0,0,0);R.c(.52,.52,.22,Kb,0,.18,0);R.c(.34,.34,.12,K,0,-.2,0);
    for(let k=0;k<3;k++){const a=k*2.0944;
      R.g(new THREE.BoxGeometry(1.2,.16,.5).translate(1.05,0,0).rotateZ(.04).rotateY(a),Kb,0,0,0);
      R.g(new THREE.BoxGeometry(6.9,.055,.78).translate(5.1,0,0).rotateX(.05).rotateZ(.05).rotateY(a),0x24262a,0,0,0);
      R.g(new THREE.BoxGeometry(.6,.058,.8).translate(8.85,0,0).rotateX(.05).rotateZ(.055).rotateY(a),tipC,0,0,0)}
    R.out(gr,dark);const d=new THREE.Mesh(new THREE.CircleGeometry(9.3,36).rotateX(-Math.PI/2),discM);gr.add(d);return gr};
  const rotF=mkRot(0xe8c020),rotR=mkRot(0xd0301c);rotF.position.set(0,5.95,5.7);rotR.position.set(0,7.95,-6.2);bd.add(rotF,rotR);
  /* rampa traseira articulada com lâmpada */
  const ramp=new THREE.Group();ramp.position.set(0,1.0,-6.9);bd.add(ramp);const RP=mb();RP.b(3.0,.1,2.2,'M',0,0,-1.1);RP.b(2.6,.02,2.0,Kb,0,.06,-1.1);for(const s of[-1,1])RP.b(.08,.1,2.2,K,s*1.4,.07,-1.1);RP.out(ramp,mat);
  const rl=new THREE.Mesh(new THREE.SphereGeometry(.12,6,5),new THREE.MeshBasicMaterial({color:0x3a3020}));rl.position.set(0,.16,-2.15);ramp.add(rl);
  /* miniguns das portas */
  const gL=chGun(bd,1,K,Kb),gR=chGun(bd,-1,K,Kb);
  /* gancho de carga com caixa pendurada */
  const hkM=mb();hkM.b(.4,.1,.5,K,0,.7,.4);hkM.c(.07,.07,.2,K,0,.6,.4);hkM.out(bd,dark);
  const cb=new THREE.Group();cb.position.set(0,.55,.4);bd.add(cb);const crm=new THREE.Group();cb.add(crm);
  const cl=[chStrap(new THREE.Vector3(0,0,0),new THREE.Vector3(0,-.75,0),.03,0x2b2d28)];
  for(const x of[-.6,.6])for(const z of[-.4,.4])cl.push(chStrap(new THREE.Vector3(0,-.72,0),new THREE.Vector3(x,-1.2,z),.016,0x2b2d28));
  crm.add(new THREE.Mesh(mergeG(cl),vcM));const cm=new THREE.Mesh(chCrG,vcM);cm.position.y=-1.75;crm.add(cm);
  /* luzes de navegação, anticolisão, estrobo e antena com a bandeira do time */
  const nG=new THREE.SphereGeometry(.09,6,5),nl=(c,x,y,z)=>{const m=new THREE.Mesh(nG,new THREE.MeshBasicMaterial({color:c}));m.position.set(x,y,z);bd.add(m);return m};
  nl(0xff2020,2.05,1.75,3.2);nl(0x20ff40,-2.05,1.75,3.2);nl(0xffffff,0,7.6,-7.9);const bc=nl(0xff2a1a,0,5.28,4.5),bs=nl(0xffffff,0,.72,-1.8);
  const ant=new THREE.Group();ant.position.set(0,5.2,4.2);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.012,.02,1.3,5),dark),fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);rd.position.y=.65;fg.position.set(0,1.1,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);bd.add(ant);
  /* trem de pouso fixo: roda dupla na frente e uma roda em cada sponson */
  const GR=mb();GR.c(.09,.09,1.2,K,0,1.0,5.0);GR.c(.06,.06,1.0,K,0,.42,5.0,'x');
  for(const x of[-.4,.4]){GR.c(.4,.4,.22,RB,x,.42,5.0,'x');GR.c(.2,.2,.24,0x5b5c52,x,.42,5.0,'x')}
  for(const s of[-1,1]){GR.c(.08,.08,.9,K,s*1.95,.7,-3.6);GR.b(.08,.1,.5,K,s*1.95,.45,-3.6);GR.c(.42,.42,.24,RB,s*2.02,.42,-3.6,'x');GR.c(.2,.2,.26,0x5b5c52,s*2.02,.42,-3.6,'x')}
  GR.out(g,dark);
  /* grupos usados pelo motor do jogo para mira e disparo */
  const tg=new THREE.Group();tg.position.set(0,3.0,3.0);bd.add(tg);const bp=new THREE.Group();tg.add(bp);
  g.traverse(o=>o.castShadow=true);for(const r of[rotF,rotR])r.children[r.children.length-1].castShadow=false;scene.add(g);
  const t={g,bd,tg,bp,rotF,rotR,discM,ramp,rl,gL,gR,pL,pR,trL,trR,cb,crm,bc,bs,ant,mat,dark,air:true,ch47:true,wd:99,alt:14,altT:16+Math.random()*14,rpm:1,pit:0,rol:0,gnd:0,x:0,z:0,y:0,hd:0,v:0,yaw:0,pitch:.05,cd:0,hp:150,dead:false,rld:1.05,mz:2,clk:0,
    gn:0,gT:0,fTL:0,fTR:0,sp2:0,sd:0,crate:1,crT:0,crS:1,rmp:.75,hr:6,hc:3.0,hh:3.4,ag:.8,cdx:7};
  tanks.push(t);return t;
}
function chRound(t){ /* cada minigun só atira se a mira estiver do seu lado da aeronave */
  const dd=angDiff(t.yaw,t.hd),L=dd>-.45&&dd<2.9,R=dd<.45&&dd>-2.9;if(!L&&!R)return;
  t.sd=!t.sd;const side=L&&R?(t.sd?1:-1):(L?1:-1),G2=side>0?t.gL:t.gR;
  G2.bp.localToWorld(v1.set(0,0,1.7));const d=dirOf(t.yaw+(Math.random()-.5)*.045,t.pitch+(Math.random()-.5)*.03),m=new THREE.Mesh(gunG,gunM);m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED*1.5),owner:t,age:0,k:.09});if(side>0)t.fTL=.05;else t.fTR=.05;t.gk=((t.gk||0)+1)%4;if(!t.gk)sfx(.28*near(v1),.1);
}
function chDrop(t){ /* solta a caixa do gancho: cai girando e explode no impacto */
  if(!t.crate)return false;t.crate=0;t.crT=7;t.crm.visible=false;t.crm.children[1].getWorldPosition(v1);
  const m=new THREE.Mesh(chCrG,vcM),d=dirOf(t.yaw,0);m.position.copy(v1);m.rotation.y=t.hd;scene.add(m);
  shells.push({m,v:new THREE.Vector3((t.fvx||0)+d.x*10,-3,(t.fvz||0)+d.z*10),owner:t,age:0,k:1.25,spin:2.4});sfx(.3*near(v1),.2);return true;
}
function chFire(t){if(!t.isPlayer&&t.crate&&Math.random()<.22){chDrop(t);return}t.gn=14;t.gT=0}
function animCh47(t,dt){
  t.clk+=dt;const now=performance.now()/1000;
  if(!t.dead){
    const sp=t.rpm=Math.min(1,t.rpm+dt*.45),q=Math.min(1,dt*3),agl=t.y-Math.max(getH(t.x,t.z),WATER),spd=Math.hypot(t.fvx||0,t.fvz||0);
    if(t.isPlayer){t.ab=(t.ab||0)-dt;if(t.ab<=0){t.ab=.2;const e=document.getElementById('altb');if(e)e.textContent='Altitude '+Math.round(agl)+' m · '+Math.round(spd*3.6)+' km/h'}}
    t.rotF.rotation.y+=sp*dt*19;t.rotR.rotation.y-=sp*dt*19;t.discM.opacity=.05+.06*sp;
    for(const r of[t.rotF,t.rotR]){r.rotation.x+=(-t.pit*.28-r.rotation.x)*q;r.rotation.z+=(t.rol*.28-r.rotation.z)*q}
    t.bd.position.y=Math.sin(now*1.5+t.x*.1)*.06+Math.sin(now*21)*.008*sp;t.bd.rotation.z=Math.sin(now*.8+t.z*.05)*.006;
    /* a rampa abre sozinha quando a aeronave paira baixo e devagar */
    t.rmp+=((agl<11&&spd<6?-.12:.75)-t.rmp)*Math.min(1,dt*1.4);t.ramp.rotation.x=t.rmp;t.rl.material.color.setHex(t.rmp<.25?0xfff2b0:0x3a3020);
    t.trL.position.y=Math.sin(now*6+1)*.012*sp;t.trR.position.y=Math.sin(now*6.7)*.012*sp;t.trL.rotation.z=t.trR.rotation.z=t.rol*.15;
    t.pL.rotation.y=Math.sin(now*.6)*.4;t.pR.rotation.y=Math.sin(now*.5+2)*.4;
    /* miniguns seguem a mira dentro do arco de cada porta */
    const dd=angDiff(t.yaw,t.hd),k=Math.min(1,dt*10),pt=-clamp(t.pitch,-.8,.55),tL=dd>-.45&&dd<2.9?dd:1.3,tR=dd<.45&&dd>-2.9?dd:-1.3;
    t.gL.tg.rotation.y+=(tL-t.gL.tg.rotation.y)*k;t.gR.tg.rotation.y+=(tR-t.gR.tg.rotation.y)*k;t.gL.bp.rotation.x+=(pt-t.gL.bp.rotation.x)*k;t.gR.bp.rotation.x+=(pt-t.gR.bp.rotation.x)*k;
    if(t.gn>0){t.gT-=dt;if(t.gT<=0){t.gT=.05;t.gn--;chRound(t)}}
    t.sp2+=((t.gn>0?46:0)-t.sp2)*Math.min(1,dt*(t.gn>0?7:1.6));t.gL.sp.rotation.z+=t.sp2*dt;t.gR.sp.rotation.z-=t.sp2*dt;
    t.gL.fl.visible=t.fTL>0;t.gR.fl.visible=t.fTR>0;if(t.fTL>0){t.fTL-=dt;t.gL.fl.scale.setScalar(.7+Math.random()*.6)}if(t.fTR>0){t.fTR-=dt;t.gR.fl.scale.setScalar(.7+Math.random()*.6)}
    /* gancho: nova caixa sobe pelo cabo e balança com o movimento */
    if(!t.crate){t.crT-=dt;if(t.crT<=0){t.crate=1;t.crm.visible=true;t.crS=.05}}
    if(t.crate&&t.crS<1){t.crS=Math.min(1,t.crS+dt*1.2);t.crm.scale.setScalar(t.crS)}
    t.cb.rotation.x=-t.pit+clamp(t.v/28,-.4,1)*.42+Math.sin(now*1.9)*.03;t.cb.rotation.z=-t.rol*.8+Math.sin(now*1.5+1)*.025;
    t.ant.rotation.x=-t.v*.01+Math.sin(now*4)*.05;t.bc.material.color.setHex(now%1<.12?0xff2a1a:0x2a0606);const ph=now%1.4;t.bs.material.color.setHex(ph<.06||(ph>.16&&ph<.22)?0xffffff:0x222222);
    if(agl<20&&Math.random()<dt*14*sp){const a=Math.random()*6.283,r=3+Math.random()*10,px=t.x+Math.cos(a)*r,pz=t.z+Math.sin(a)*r,gh=getH(px,pz);v2.set(px,Math.max(gh,WATER)+.3,pz);puff(v2,gh<WATER?0xdfeff6:0xa89a78,3,7,1,.8)}
    t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.22;for(const s of[-1,1]){t.g.localToWorld(v2.set(s*1.55,4.6,-7.4));puff(v2,0x9a9690,.45,1.1,.55,.45)}}
  }else{ /* abatido: gira sem controle, cai e explode no chão */
    t.rpm=Math.max(0,t.rpm-dt*.25);t.rotF.rotation.y+=t.rpm*dt*19;t.rotR.rotation.y-=t.rpm*dt*19;t.gL.fl.visible=t.gR.fl.visible=false;const gp=t.g.position;
    if(!t.gnd){
      t.vy=(t.vy||0)-G*dt*.7;gp.y+=t.vy*dt;t.g.rotation.y+=dt*(1.6-t.vy*.1);t.g.rotation.z+=dt*.6;
      t.cT=(t.cT||0)-dt;if(t.cT<=0){t.cT=.07;puff(gp,Math.random()<.4?0xff8a2e:0x1f1e1c,1.8,1.5,1.6,1.5)}
      const gh=Math.max(getH(gp.x,gp.z),WATER)+.8;
      if(gp.y<=gh){gp.y=gh;t.gnd=1;t.y=gh;boom(new THREE.Vector3(gp.x,gh+1,gp.z),t,1);if(t.isPlayer)shake=Math.max(shake,2)}
    }else{t.burn=(t.burn===undefined?25:t.burn)-dt;if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,3,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.6,1.5,2,3)}}}
  }
}
/* ---------- H225M Caracal (Franca): helicoptero tatico medio, rotor de 5 pas, trem retratil, portas deslizantes, foguetes ---------- */
function makeH225(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0x4f5a3c}),dark=new THREE.MeshLambertMaterial({color:0x26282a}),glass=new THREE.MeshLambertMaterial({color:0x2a4a5c,emissive:0x0a1a24,transparent:true,opacity:.58}),flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),
    discM=new THREE.MeshBasicMaterial({color:0x202020,transparent:true,opacity:.1,depthWrite:false,side:THREE.DoubleSide}),g=new THREE.Group(),bd=new THREE.Group(),K=0x26282a,Kb=0x3a3d38,RB=0x1b1b1a,eg=(r1,r2,l,sx,sy)=>new THREE.CylinderGeometry(r1,r2,l,14).rotateX(Math.PI/2).scale(sx,sy,1);
  g.rotation.order='YXZ';g.add(bd);const T=mb();
  /* fuselagem, nariz, cauda, fin e empenagem */
  T.g(eg(1,1,6.2,1.45,1.25),'M',0,2.2,.4);T.g(eg(.55,1,2.8,1.3,.75),'M',0,1.55,4.4);T.b(2.5,.5,6,'M',0,1.0,.3);T.g(new THREE.SphereGeometry(.42,10,8).scale(1,.9,1.2),Kb,0,1.55,5.7);
  T.g(eg(1,.4,5.4,.8,.95),'M',0,2.75,-5.2,.1);T.b(.16,2.3,1.7,'M',0,4.15,-7.2,-.32);T.b(.3,.4,.5,K,-.2,4.6,-7.45);T.b(3,.12,.9,'M',0,3.15,-6.4);for(const s of[-1,1])T.b(.08,.75,.9,'M',s*1.5,3.25,-6.4);
  /* estufa do cockpit */
  T.b(2.3,.12,2,'M',0,3.62,4.1);for(const s of[-1,1])T.b(.1,1.2,.1,'M',s*1.22,2.95,3.5);T.b(.1,1.3,.1,'M',0,2.95,5,-.55);T.b(1.4,.1,.7,K,0,2.35,4.4);
  /* caixa de transmissao, mastro, motores Makila com entradas e escapes */
  T.b(1.5,.7,2,'M',0,3.85,.5);T.c(.22,.3,.7,K,0,4.2,.5);
  for(const s of[-1,1]){T.g(eg(.55,.55,2.9,1,.75),'M',s*.62,3.75,-.4);T.c(.52,.56,.14,K,s*.62,3.75,1.08,'z');T.c(.4,.4,.04,0x111111,s*.62,3.75,1.16,'z');T.c(.36,.28,.45,K,s*.62,3.7,-1.95,'z');
    T.g(eg(.35,.5,2.6,.75,.65),'M',s*1.35,1.2,-.1);
    /* asas curtas com casulos de foguetes */
    T.b(.9,.1,1,Kb,s*1.95,1.95,.7);T.b(.12,.45,.5,K,s*2.05,1.75,1);T.c(.26,.26,2.3,K,s*2.05,1.5,1.15,'z');T.c(.27,.27,.08,0x111111,s*2.05,1.5,2.32,'z');
    /* recesso das portas, janelas e guincho */
    T.b(.05,1.4,1.55,K,s*1.455,2.1,.9);T.b(.05,.5,.9,0x1d3340,s*1.43,2.55,-1.7);T.b(.05,.5,.9,0x1d3340,s*1.43,2.55,-2.4)}
  T.b(.3,.3,.6,K,1.55,3.25,.9);T.c(.03,.03,.9,K,.9,2,5.9,'z');
  T.out(bd,mat);
  const gl=[],gp=(w,h,d,x,y,z,rx)=>{const q=new THREE.BoxGeometry(w,h,d);if(rx)q.rotateX(rx);q.translate(x,y,z);gl.push(q)};
  gp(1.1,1.35,.05,.6,2.95,4.9,-.55);gp(1.1,1.35,.05,-.6,2.95,4.9,-.55);for(const s of[-1,1]){gp(.05,1.1,1,s*1.2,2.95,4.35);gp(.05,.8,.8,s*1.1,2.8,3.4)}
  bd.add(new THREE.Mesh(mergeG(gl),glass));
  const mkP=x=>{const p=new THREE.Group(),l=[];chSoldier(l,0,0,0,0);p.add(new THREE.Mesh(mergeG(l),vcM));p.position.set(x,2.15,3.95);bd.add(p);return p},pL=mkP(.5),pR=mkP(-.5);
  /* portas de correr: abrem para tras sobre a fuselagem */
  const drs=[1,-1].map(s=>{const d=new THREE.Group(),D=mb();d.position.set(s*1.5,2.1,.9);D.b(.06,1.4,1.6,'M',0,0,0);D.b(.07,.55,.9,0x1d3340,0,.3,.1);D.b(.08,.06,1.5,K,0,-.55,0);D.out(d,mat);bd.add(d);return d});
  /* rotor principal de 5 pas, ponta amarela e uma vermelha */
  const rot=new THREE.Group(),R=mb();R.c(.2,.26,.5,K,0,0,0);R.c(.5,.5,.2,Kb,0,.2,0);R.c(.3,.3,.12,K,0,-.2,0);
  for(let k=0;k<5;k++){const a=k*1.2566;R.g(new THREE.BoxGeometry(1.1,.14,.4).translate(.95,0,0).rotateZ(.04).rotateY(a),Kb,0,0,0);
    R.g(new THREE.BoxGeometry(6.6,.05,.55).translate(4.9,0,0).rotateX(.05).rotateZ(.06).rotateY(a),0x24262a,0,0,0);
    R.g(new THREE.BoxGeometry(.5,.052,.58).translate(8.45,0,0).rotateX(.05).rotateZ(.065).rotateY(a),k?0xe8c020:0xd0301c,0,0,0)}
  R.out(rot,dark);rot.add(new THREE.Mesh(new THREE.CircleGeometry(8.7,36).rotateX(-Math.PI/2),discM));rot.position.set(0,4.5,.5);bd.add(rot);
  /* rotor de cauda de 5 pas no lado esquerdo */
  const trt=new THREE.Group(),TR=mb();TR.c(.1,.1,.3,K,0,0,0,'x');for(let k=0;k<5;k++)TR.g(new THREE.BoxGeometry(.04,1.35,.22).translate(0,.78,0).rotateX(k*1.2566),0x24262a,0,0,0);
  TR.out(trt,dark);trt.add(new THREE.Mesh(new THREE.CircleGeometry(1.5,20).rotateY(Math.PI/2),discM));trt.position.set(-.42,4.7,-7.7);bd.add(trt);
  /* trem de pouso retratil: rodas duplas na frente, uma em cada lado */
  const gN=new THREE.Group(),GN=mb();gN.position.set(0,1.25,3.3);GN.c(.07,.07,1,K,0,-.5,0);GN.c(.05,.05,.56,K,0,-.89,0,'x');for(const x of[-.28,.28]){GN.c(.34,.34,.18,RB,x,-.89,0,'x');GN.c(.17,.17,.2,0x5b5c52,x,-.89,0,'x')}GN.out(gN,dark);bd.add(gN);
  const gM=[-1,1].map(s=>{const p=new THREE.Group(),M=mb();p.position.set(s*1.4,1.3,-.2);p.userData.s=s;M.c(.08,.08,.95,K,0,-.48,0);M.c(.36,.36,.2,RB,0,-.94,0,'x');M.c(.18,.18,.22,0x5b5c52,0,-.94,0,'x');M.out(p,dark);bd.add(p);return p});
  const gL=chGun(bd,1,K,Kb),gR=chGun(bd,-1,K,Kb);gL.tg.position.set(.5,1.75,.9);gR.tg.position.set(-.5,1.75,.9);
  /* luzes, estrobo, farol do nariz e antena com a bandeira do time */
  const nG=new THREE.SphereGeometry(.09,6,5),nl=(c,x,y,z)=>{const m=new THREE.Mesh(nG,new THREE.MeshBasicMaterial({color:c}));m.position.set(x,y,z);bd.add(m);return m};
  nl(0xff2020,-2.5,1.95,.7);nl(0x20ff40,2.5,1.95,.7);nl(0xffffff,0,4.9,-7.9);nl(0xfff2b0,0,1.05,5.25);const bc=nl(0xff2a1a,0,4.2,-.6),bs=nl(0xffffff,0,.7,-1.6);
  const ant=new THREE.Group();ant.position.set(0,3.2,-2.2);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.012,.02,1.2,5),dark),fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);rd.position.y=.6;fg.position.set(0,1,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);bd.add(ant);
  const tg=new THREE.Group();tg.position.set(0,3,3);bd.add(tg);const bp=new THREE.Group();tg.add(bp);
  g.traverse(o=>o.castShadow=true);rot.children[rot.children.length-1].castShadow=false;trt.children[trt.children.length-1].castShadow=false;scene.add(g);
  const t={g,bd,tg,bp,rot,trt,discM,drs,gL,gR,pL,pR,gN,gM,ant,bc,bs,mat,dark,air:true,h225:true,wd:99,alt:14,altT:16+Math.random()*14,rpm:1,pit:0,rol:0,gnd:0,x:0,z:0,y:0,hd:0,v:0,yaw:0,pitch:.05,cd:0,hp:105,dead:false,rld:1.05,mz:2,clk:0,gn:0,gT:0,fTL:0,fTR:0,sp2:0,sd:0,sv:0,sT:0,gx:1,dop:0,hr:4.6,hc:2.8,hh:2.9,ag:1.1,cdx:6,spd:1.2};
  tanks.push(t);return t;
}
function h2Rocket(t){
  t.rs2=-(t.rs2||1);const s=t.rs2;t.g.localToWorld(v1.set(s*2.05,1.5,2.5));
  const d=dirOf(t.yaw+(Math.random()-.5)*.04,t.pitch+(Math.random()-.5)*.03),m=rkSmall();m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED*1.15),owner:t,age:0,k:.33,rk:true,tt:0});
  puff(v1,0xffe9a0,.8,2,.25,.4);t.g.localToWorld(v2.set(s*2.05,1.5,-.2));puff(v2,0xcfc8b8,1.2,4,.9,.5);if(t.sv%2===0)sfx(.35*near(v1),.2);
}
function animH225(t,dt){
  t.clk+=dt;const now=performance.now()/1000;
  if(!t.dead){
    const sp=t.rpm=Math.min(1,t.rpm+dt*.45),q=Math.min(1,dt*3),agl=t.y-Math.max(getH(t.x,t.z),WATER),spd=Math.hypot(t.fvx||0,t.fvz||0);
    if(t.isPlayer){t.ab=(t.ab||0)-dt;if(t.ab<=0){t.ab=.2;const e=document.getElementById('altb');if(e)e.textContent='Altitude '+Math.round(agl)+' m · '+Math.round(spd*3.6)+' km/h'}}
    t.rot.rotation.y+=sp*dt*21;t.trt.rotation.x+=sp*dt*(60+clamp(t.st||0,-1,1)*20);t.discM.opacity=.05+.06*sp;
    t.rot.rotation.x+=(-t.pit*.28-t.rot.rotation.x)*q;t.rot.rotation.z+=(t.rol*.28-t.rot.rotation.z)*q;
    t.bd.position.y=Math.sin(now*1.7+t.x*.1)*.05+Math.sin(now*24)*.01*sp;t.bd.rotation.z=Math.sin(now*.9+t.z*.05)*.007;
    /* trem retratil: desce para pairar baixo e devagar, sobe em voo */
    t.gx+=clamp((agl<16&&spd<14?1:0)-t.gx,-dt*.6,dt*.6);t.gN.rotation.x=1.5*(1-t.gx);t.gM.forEach(p=>p.rotation.z=-p.userData.s*1.5*(1-t.gx));t.gN.visible=t.gM[0].visible=t.gM[1].visible=t.gx>.02;
    /* portas de correr abrem ao pairar baixo ou ao atirar; as metralhadoras saem pela abertura */
    t.dop+=clamp(((agl<12&&spd<8)||t.gn>0?1:0)-t.dop,-dt*.8,dt*1.6);t.drs.forEach(d=>d.position.z=.9-t.dop*1.7);t.gL.tg.position.x=.5+t.dop*.95;t.gR.tg.position.x=-.5-t.dop*.95;
    t.pL.rotation.y=Math.sin(now*.6)*.4;t.pR.rotation.y=Math.sin(now*.5+2)*.4;
    const dd=angDiff(t.yaw,t.hd),k=Math.min(1,dt*10),pt=-clamp(t.pitch,-.8,.55),tL=dd>-.45&&dd<2.9?dd:1.3,tR=dd<.45&&dd>-2.9?dd:-1.3;
    t.gL.tg.rotation.y+=(tL-t.gL.tg.rotation.y)*k;t.gR.tg.rotation.y+=(tR-t.gR.tg.rotation.y)*k;t.gL.bp.rotation.x+=(pt-t.gL.bp.rotation.x)*k;t.gR.bp.rotation.x+=(pt-t.gR.bp.rotation.x)*k;
    if(t.gn>0){t.gT-=dt;if(t.gT<=0){t.gT=.05;t.gn--;chRound(t)}}
    if(t.sv>0){t.sT-=dt;if(t.sT<=0){t.sT=.09;t.sv--;h2Rocket(t)}}
    t.sp2+=((t.gn>0?46:0)-t.sp2)*Math.min(1,dt*(t.gn>0?7:1.6));t.gL.sp.rotation.z+=t.sp2*dt;t.gR.sp.rotation.z-=t.sp2*dt;
    t.gL.fl.visible=t.fTL>0;t.gR.fl.visible=t.fTR>0;if(t.fTL>0){t.fTL-=dt;t.gL.fl.scale.setScalar(.7+Math.random()*.6)}if(t.fTR>0){t.fTR-=dt;t.gR.fl.scale.setScalar(.7+Math.random()*.6)}
    t.ant.rotation.x=-t.v*.01+Math.sin(now*4)*.05;t.bc.material.color.setHex(now%1<.12?0xff2a1a:0x2a0606);const ph=now%1.4;t.bs.material.color.setHex(ph<.06||(ph>.16&&ph<.22)?0xffffff:0x222222);
    /* poeira do rotor perto do chao e fumaca dos escapes */
    if(agl<20&&Math.random()<dt*14*sp){const a=Math.random()*6.283,r=3+Math.random()*9,px=t.x+Math.cos(a)*r,pz=t.z+Math.sin(a)*r,gh=getH(px,pz);v2.set(px,Math.max(gh,WATER)+.3,pz);puff(v2,gh<WATER?0xdfeff6:0xa89a78,3,7,1,.8)}
    t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.22;for(const s of[-1,1]){t.g.localToWorld(v2.set(s*.62,3.8,-2.5));puff(v2,0x9a9690,.4,1.1,.55,.45)}}
  }else{ /* abatido: gira sem controle, cai e explode no chao */
    t.rpm=Math.max(0,t.rpm-dt*.25);t.rot.rotation.y+=t.rpm*dt*21;t.trt.rotation.x+=t.rpm*dt*60;t.gL.fl.visible=t.gR.fl.visible=false;const gp=t.g.position;
    if(!t.gnd){
      t.vy=(t.vy||0)-G*dt*.7;gp.y+=t.vy*dt;t.g.rotation.y+=dt*(1.6-t.vy*.1);t.g.rotation.z+=dt*.6;
      t.cT=(t.cT||0)-dt;if(t.cT<=0){t.cT=.07;puff(gp,Math.random()<.4?0xff8a2e:0x1f1e1c,1.8,1.5,1.6,1.5)}
      const gh=Math.max(getH(gp.x,gp.z),WATER)+.8;
      if(gp.y<=gh){gp.y=gh;t.gnd=1;t.y=gh;boom(new THREE.Vector3(gp.x,gh+1,gp.z),t,1);if(t.isPlayer)shake=Math.max(shake,2)}
    }else{t.burn=(t.burn===undefined?25:t.burn)-dt;if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,3,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.6,1.5,2,3)}}}
  }
}

function animTank(t,dt){
  if(t.m2lt)return animM2(t,dt);if(t.t27)return animT27(t,dt);if(t.l3)return animL3(t,dt);if(t.pz1)return animPz1(t,dt);if(t.zsu)return animZSU(t,dt);if(t.m109)return animM109(t,dt);if(t.corv)return animCorv(t,dt);if(t.pant)return animPantsir(t,dt);if(t.aven)return animAven(t,dt);if(t.gep)return animGep(t,dt);if(t.ap)return animApache(t,dt);if(t.ch47)return animCh47(t,dt);if(t.h225)return animH225(t,dt);if(t.t80)return animT80(t,dt);if(t.merk)return animMerk(t,dt);if(t.boxer)return animBoxer(t,dt);if(t.cv90)return animCV90(t,dt);if(t.stry)return animStry(t,dt);if(t.agmv)return animAGMV(t,dt);
  if(t.t90||t.t72)return animT7x(t,dt);
  if(t.arm14)return animArmata(t,dt);
  if(t.cro)return animCro(t,dt);if(t.pzh)return animPzh(t,dt);if(t.amr)return animAMR(t,dt);if(t.roo)return animRoo(t,dt);
  if(t.tnk)return animTK(t,dt);
  if(t.ku)return animKu(t,dt);if(t.su)return animSU(t,dt);if(t.amx)return animAMX(t,dt);if(t.maus)return animMaus(t,dt);if(t.sher)return animSher(t,dt);if(t.td)return animTD(t,dt);if(t.ch2)return animLeo(t,dt);if(t.t34)return animT34(t,dt);if(t.t35)return animT35(t,dt);if(t.leo)return animLeo(t,dt);if(t.pl01)return animPL(t,dt);
  if(t.gua)return animGua(t,dt);
  if(t.stuart)return animStuart(t,dt);if(t.mk1)return animMarkI(t,dt);if(t.casc)return animCasc(t,dt);
  if(t.abrams)return animAbrams(t,dt);
  if(t.tiger)return animTiger(t,dt);
  if(t.m270)return animM270(t,dt);
  if(t.astros)return animAstros(t,dt);
  if(t.abv)return animAbv(t,dt);
  const now=performance.now()/1000;
  if(!t.dead){
    const ph=t.v*dt;t.phase+=ph;t.sideT.offset.x=t.phase/.75;t.topT.offset.y=t.phase/.75;
    for(const w of t.wheels)w.rotation.x+=ph/.4;
    t.hull.position.y=Math.sin(now*28+t.x)*.012*(.4+Math.abs(t.v)/11);
    t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
    t.ex=(t.ex||0)-dt;
    if(t.ex<=0){t.ex=.12+Math.random()*.1;t.g.localToWorld(v2.set(0,1.5,-3.2));puff(v2,0x6e6a64,.5,1,.9,1.2)}
  }else{
    t.burn=(t.burn===undefined?25:t.burn)-dt;
    if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,2.2,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.4,1.5,2,3)}}
  }
  if(t.recoil>0){t.recoil=Math.max(0,t.recoil-dt*3);t.bar.position.z=2.1-t.recoil*.9}
}
function place(t){
  if(t.corv){const n=performance.now()/1000,sk=t.sink||0;t.y=WATER+.2-sk;t.g.position.set(t.x,t.y,t.z);t.g.rotation.set(Math.sin(n*1.1+t.x*.03)*.012-t.v*.0015+(t.dead?sk*.05:0),t.hd,Math.sin(n*1.6+t.z*.03)*.02-(t.st||0)*Math.abs(t.v)*.004+(t.dead?sk*.12:0));t.tg.rotation.y=t.yaw-t.hd;t.bp.rotation.x=-t.pitch;return}
  if(t.air){const gy=Math.max(getHV(t.x,t.z),WATER);if(t.gy===undefined)t.gy=gy;t.y=Math.max(t.gy+t.alt,gy+3.5);t.g.position.set(t.x,t.y,t.z);t.g.rotation.set(t.pit,t.hd,t.rol);t.tg.rotation.y=t.yaw-t.hd;t.bp.rotation.x=-t.pitch;return}
  const s=Math.sin(t.hd),c=Math.cos(t.hd);
  const L=t.L||2.6,W=t.W||1.9,hf=getHV(t.x+s*L,t.z+c*L),hb=getHV(t.x-s*L,t.z-c*L),hr=getHV(t.x+c*W,t.z-s*W),hl=getHV(t.x-c*W,t.z+s*W);
  t.y=(hf+hb+hr+hl)/4;t.g.position.set(t.x,t.y,t.z);
  t.g.rotation.set(-Math.atan2(hf-hb,2*L),t.hd,Math.atan2(hr-hl,2*W));
  t.tg.rotation.y=t.yaw-t.hd;t.bp.rotation.x=-t.pitch;if(t.l3)t.tg.rotation.y=clamp(angDiff(t.yaw,t.hd),-t.lim,t.lim);if(t.td){t.tg.rotation.y=clamp(angDiff(t.yaw,t.hd),-t.lim,t.lim);if(t.stk)t.bp.rotation.x=-(t.pitch-t.tk)}
}
const wadeOf=t=>t.wd||(t.abrams?2.3:t.tiger?3.2:t.abv?2:t.astros?1:1.6); /* profundidade maxima que cada veiculo aguenta */
function drive(t,dt,thr,turn){
  if(t.corv)return shipStep(t,dt,thr,turn);
  if(t.air)return flyStep(t,dt,thr,turn);
  const wd=wadeOf(t),wet=Math.max(0,WATER-getHV(t.x,t.z)),deep=wet>wd;t.wet=wet;
  if(deep){
    if(!t.fld){t.fld=1;splash(v1.set(t.x,WATER,t.z));if(t.isPlayer)toast('Motor afogou! Dê ré para sair da água')}
    t.rst=2.5;
  }else if(t.fld){t.rst-=dt;if(t.rst<=0){t.fld=0;if(t.isPlayer)toast('Motor religou')}}
  if(t.fld){thr=Math.min(thr,0)*.6;turn*=.4;t.v*=Math.pow(.05,dt)}
  else if(wet>wd*.7&&t.isPlayer){t.wn=(t.wn||0)-dt;if(t.wn<=0){t.wn=3;toast('Água funda! O motor pode afogar')}}
  if(wet>.15&&(Math.abs(t.v)>.5||deep)){
    t.wp=(t.wp||0)-dt;
    if(t.wp<=0){t.wp=deep?.25:.1;v2.set(t.x+(Math.random()-.5)*4,WATER+.1,t.z+(Math.random()-.5)*4);puff(v2,deep?0x8fc3dc:0xe3f1f8,deep?.8:1.1,deep?1.5:3.5,.7,deep?1.5:2);if(deep&&Math.random()<.4)puff(v2,0x6e6a64,1.2,1,1.2,2)}
  }
  const mul=t.fld?1:wet>0?1-.45*Math.min(1,wet/wd):roadAt(t.x,t.z)>.5?1.12:1;
  const cD=t.cp;t.v+=((thr>0?thr*11:thr*5)*(t.spd||1)*mul*(cD?cD.mob:1)-t.v)*Math.min(1,dt*1.8);t.hd+=(turn*(t.trn||1)*(cD?cD.tmob:1)+(cD?cD.drift:0))*dt;t.st=turn;
  const nx=t.x+Math.sin(t.hd)*t.v*dt,nz=t.z+Math.cos(t.hd)*t.v*dt;
  if(Math.hypot(nx,nz)>HALF-6){t.v*=-.2;return}
  t.x=nx;t.z=nz;
  for(const b of buildings){
    const dx=t.x-b.x,dz=t.z-b.z,rx=b.w/2+2.6,rz=b.d/2+2.6;
    if(Math.abs(dx)<rx&&Math.abs(dz)<rz){
      if(t.abv&&t.v>3){b.hp-=dt*130;scorch(b,.99);t.v*=.985;if(b.hp<=0)destroyB(b);continue}
      const rp=ramOf(t); /* blindados pesados atropelam construcoes em velocidade */
      if(rp&&Math.abs(t.v)>3){
        const f=dt*rp*Math.abs(t.v)*14;b.hp-=f;b.base-=f;scorch(b,.996);
        if(Math.random()<dt*14)puff(v3.set(b.x+(t.x-b.x)*.5,b.y+1.5,b.z+(t.z-b.z)*.5),0xb9b0a0,2.2,4,1.4,2);
        if(t.isPlayer)shake=Math.max(shake,.5);
        if(b.hp<=0){destroyB(b);t.v*=.92;if(t.isPlayer)toast('Você atropelou a construção!');continue}
        if(b.base<=0&&b.h>=8){topple(b,{x:b.x+(b.x-t.x),y:b.y,z:b.z+(b.z-t.z)},t);t.v*=.92;continue}
        crumble(b);
        if(rx-Math.abs(dx)<rz-Math.abs(dz))t.x=b.x+Math.sign(dx||1)*rx;else t.z=b.z+Math.sign(dz||1)*rz;t.v*=1-Math.min(.5,dt*3/rp);continue;
      }
      if(rx-Math.abs(dx)<rz-Math.abs(dz))t.x=b.x+Math.sign(dx||1)*rx;else t.z=b.z+Math.sign(dz||1)*rz;t.v*=.3;
    }
  }
  for(let i=trees.length-1;i>=0;i--){const q=trees[i];
    if(!q.st){if(Math.hypot(q.x-t.x,q.z-t.z)<2.8){q.st=1;q.a=0;q.w=0;q.g.rotation.order='YXZ';q.g.rotation.y=Math.atan2(q.x-t.x,q.z-t.z)}}
    else if(q.st===2&&q.t<=0&&Math.abs(t.v)>.5&&(Math.hypot(q.cx-t.x,q.cz-t.z)<3||Math.hypot(q.x-t.x,q.z-t.z)<2.5))killTree(q);
  }
  for(let i=props.length-1;i>=0;i--){const q=props[i];if(Math.abs(t.v)>.5&&Math.hypot(q.x-t.x,q.z-t.z)<2.6)killProp(q)}
}
let player=makeTank(0x5b6b3a);player.isPlayer=true;
/* ---------- AN/TWQ-1 Avenger (EUA): Humvee com torre Boeing, 8 misseis Stinger guiados contra aereos e metralhadora .50 M3P ---------- */
const avW=mkWheel(.5,.46,16,6);
function makeAvenger(color,fc){
  const{dark,lamp,brkM,flagM,flashM}=mm(fc),mat=mat0(color||0x6a6f4c),g=new THREE.Group(),wheels=[],steers=[],DK=0x2b2d28,MT=0x4a4b42,GL=0x1d2f3a,MS=0xcfd2c4;
  g.rotation.order='YXZ';const lkM=new THREE.MeshBasicMaterial({color:0xffb000});
  for(const s of[-1,1])[1.65,-1.65].forEach((z,i)=>{const w=new THREE.Mesh(avW,vcM);w.userData={r:.5};wheels.push(w);
    if(i===0){const sg=new THREE.Group();sg.position.set(s*1.15,.5,z);sg.add(w,bx(.2,.2,.4,dark,-s*.3,.12,0));g.add(sg);steers.push({g:sg,k:1})}
    else{w.position.set(s*1.15,.5,z);g.add(w,bx(.2,.2,.4,dark,s*.9,.62,z))}});
  /* casco de Humvee: tubo largo, capo inclinado, cabine, cacamba traseira, grade, pneu reserva */
  const hull=new THREE.Group(),H=mb();
  H.b(2,.55,4.6,'M',0,.95,0);H.b(1.8,.4,1.4,'M',0,1.3,1.6);H.b(2,.9,1.5,'M',0,1.75,.25);H.b(1.9,.1,1.6,'M',0,2.25,.25);H.b(2,.12,1.75,'M',0,1.3,-1.45);
  H.b(1.7,.5,.05,GL,0,1.9,1.02,-.25);H.b(1.6,.35,.05,DK,0,1.25,2.32);H.c(.4,.4,.2,DK,0,1.55,-2.4,'z');
  for(const s of[-1,1]){H.b(.05,.45,.9,GL,s*1.01,1.9,.3);H.b(.04,.7,.05,DK,s*1.02,1.75,-.15);H.b(.5,.12,1.3,'M',s*1.15,1.05,1.65);H.b(.5,.12,1.3,'M',s*1.15,1.05,-1.65);H.b(.1,.5,1.7,DK,s*1.03,1.5,-1.45);
    hull.add(bx(.25,.18,.06,lamp,s*.7,1.35,2.33),bx(.2,.15,.06,brkM,s*.8,1.15,-2.33))}
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,.9,2.3,-.4,flagM);
  /* torre Boeing: corpo, sensor FLIR com luz de travamento, bercos laterais */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.36,-1.4);
  T.c(.85,.9,.12,'M',0,.06,0,'y');T.b(1.5,.75,1.4,'M',0,.5,-.1);T.b(1.3,.18,1.2,'M',0,.95,-.15,.12);T.b(1.4,.5,.4,DK,0,.45,-.85);for(const s of[-1,1])T.b(.12,.5,1.2,MT,s*.8,.5,.4);T.out(tg,mat);
  const fir=new THREE.Group();fir.position.set(-.5,1.1,.55);fir.add(new THREE.Mesh(new THREE.SphereGeometry(.2,12,8),dark),new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,.3,10).rotateX(Math.PI/2).translate(0,0,.2),new THREE.MeshLambertMaterial({color:GL})),bx(.08,.08,.34,dark,.17,0,.1),bx(.4,.04,.1,dark,0,-.17,.12));
  const lk=new THREE.Mesh(new THREE.SphereGeometry(.05,8,6),lkM);lk.position.set(0,.24,0);fir.add(lk);tg.add(fir);
  /* conjunto elevavel: dois modulos de 4 Stinger (tubo com missil visivel) e a .50 M3P no centro */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),ms=[];bp.position.set(0,.85,.1);
  const mG=mergeG([vcol(new THREE.CylinderGeometry(.075,.075,1.6,8).rotateX(Math.PI/2),MS),vcol(new THREE.ConeGeometry(.075,.35,8).rotateX(Math.PI/2).translate(0,0,.95),0x2b2d28),vcol(new THREE.BoxGeometry(.3,.02,.14).translate(0,0,-.65),0x2b2d28),vcol(new THREE.BoxGeometry(.02,.3,.14).translate(0,0,-.65),0x2b2d28)]);
  for(const s of[-1,1]){B.b(.82,.7,1.5,'M',s*1.05,0,.1);B.b(.86,.74,.08,DK,s*1.05,0,.85);
    for(const cx of[-.18,.18])for(const cy of[-.16,.16]){const m=new THREE.Mesh(mG,vcM);m.position.set(s*1.05+cx,cy,1.0);bp.add(m);ms.push(m)}}
  B.b(.4,.4,.9,DK,0,.05,.2);B.b(.45,.35,.6,MT,.32,-.12,-.1);B.out(bp,mat);
  const K=mb();K.c(.05,.05,1.6,DK,0,0,1.3,'z');K.c(.09,.09,.5,MT,0,0,.8,'z');K.c(.08,.08,.2,DK,0,0,2.1,'z');K.out(bar,mat);bar.position.set(0,.05,0);
  const fl=new THREE.Group();fl.add(new THREE.Mesh(new THREE.ConeGeometry(.2,.9,8).rotateX(Math.PI/2).translate(0,0,2.5),flashM),new THREE.Mesh(new THREE.SphereGeometry(.15,8,6).translate(0,0,2.2),flashM));fl.visible=false;bar.add(fl);bp.add(bar);tg.add(bp);g.add(tg);
  const crew=new THREE.Group();crew.userData.by=0;
  return fin(base({g,tg,bp,bar,hull,ant,fl,brkM,wheels,steers,mat,dark,lkM,fir,ms,mrl:[0,0,0,0,0,0,0,0],crew,lid:[new THREE.Group(),new THREE.Group()],aven:true,cannon:true,spd:1.75,trn:1.15,L:2.4,W:1.2,mz:2.3,fk:.2,rld:.45,wd:1.2,armor:.45,hp:80,TY:1.36,mcd:0,mi:0}));
}
/* Stinger: missil guiado que persegue o alvo aereo travado */
function stingerFire(t){
  const q=t.lk,i=(t.mi=(t.mi||0)%8);t.mi++;t.mcd=1.6;t.mrl[i]=6;t.ms[i].visible=false;t.ms[i].getWorldPosition(v1);
  const d=dirOf(t.yaw,Math.max(t.pitch,.3)),tv=new THREE.Vector3(q.x-v1.x,q.y+1.5-v1.y,q.z-v1.z).normalize();d.lerp(tv,.6).normalize();
  const m=new THREE.Mesh(apHf,vcM);m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED*1.7),owner:t,age:0,k:2.4,rk:true,tt:0,hm:q});
  for(let k=0;k<6;k++)puff(v1,0xe6dcc8,1.4,4,.8,.6);snd('cannon',.45*near(v1));t.recoil=.5;
}
function animAven(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.lkM.color.setHex(0x220000);return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/17,0,1),ph=t.v*dt,ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  for(const w of t.wheels)w.rotation.x+=ph/.5;
  for(const s of t.steers)s.g.rotation.y+=((t.st||0)*.45*s.k-s.g.rotation.y)*Math.min(1,dt*6);
  t.pt=(t.pt||0)+(clamp(-ac*.005,-.06,.06)-(t.pt||0))*Math.min(1,dt*5);
  const by=Math.sin(now*36+t.x)*(.01+.016*th)-t.recoil*.015;
  t.hull.position.y=by;t.tg.position.y=t.TY+by;t.hull.rotation.x=t.pt;t.hull.rotation.z=-(t.st||0)*th*.05;t.ant.rotation.x=-t.v*.016+Math.sin(now*3+t.z)*.04;
  t.mcd=Math.max(0,t.mcd-dt);
  /* busca de alvo aereo: o FLIR gira para o alvo, a luz fica verde e o Stinger fica pronto */
  t.sc=(t.sc||0)-dt;
  if(t.sc<=0){t.sc=.25;let best=420,b=null;for(const q of tanks)if(!q.dead&&q.air&&hostile(t,q)){const d=Math.hypot(q.x-t.x,q.z-t.z);if(d<best){best=d;b=q}}
    if(b&&!t.lk&&t.isPlayer)toast('Alvo aéreo travado: dispare para lançar o Stinger');t.lk=b}
  const q=t.lk&&!t.lk.dead?t.lk:null,k=Math.min(1,dt*6);
  const ty=q?angDiff(Math.atan2(q.x-t.x,q.z-t.z),t.yaw):Math.sin(now*1.2)*.8,tp=q?-Math.atan2(q.y+1-t.y-2.2,Math.hypot(q.x-t.x,q.z-t.z)):0;
  t.fir.rotation.y+=(ty-t.fir.rotation.y)*k;t.fir.rotation.x+=(tp-t.fir.rotation.x)*k;
  t.lkM.color.setHex(q?(t.mcd<=0?0x3dff5a:0xff3a2a):Math.sin(now*4)>0?0xffb000:0x4a3300);
  /* modulos reabastecem os tubos vazios depois de alguns segundos */
  for(let i=0;i<8;i++)if(t.mrl[i]>0){t.mrl[i]-=dt;if(t.mrl[i]<=0)t.ms[i].visible=true}
  if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=.07;t.bfi=1;fire(t);t.bfi=0}}
  tankFx(t,dt,now,th,{ex:[[.9,.7,-2.3]],dk:[[1.3,.2,-1.65],[-1.3,.2,-1.65],[1.3,.2,1.65],[-1.3,.2,1.65]],mz:2.3,rr:3.5,rc:.25});
  smokeQ(t,dt,.9,.9,-1.2);
}
/* ---------- Pantsir-S1 (Russia): caminhao 8x8 antiaereo, 2 canhoes 2A38M de 30 mm, 12 misseis, radar de busca giratorio e radar de tiro com sensor optico ---------- */
const pnW=mkWheel(.7,.56,18,8);
function makePantsir(color,fc){
  const{dark,lamp,brkM,flagM,flashM}=mm(fc),mat=mat0(color||0x66704a),g=new THREE.Group(),wheels=[],steers=[],DK=0x2b2d28,MT=0x4a4b42,PL=0x9a9d92,GL=0x1d2f3a,AX=[3.3,2,-1.9,-3.2];
  g.rotation.order='YXZ';const radM=new THREE.MeshBasicMaterial({color:0xff2a1a}),plM=new THREE.MeshLambertMaterial({color:PL,side:THREE.DoubleSide});
  for(const s of[-1,1])AX.forEach((z,i)=>{const w=new THREE.Mesh(pnW,vcM);w.userData={r:.7};wheels.push(w);
    if(i<2){const sg=new THREE.Group();sg.position.set(s*1.45,.7,z);sg.add(w,bx(.2,.2,.5,dark,-s*.3,.15,0));g.add(sg);steers.push({g:sg,k:i?.6:1})}
    else{w.position.set(s*1.45,.7,z);g.add(w,bx(.2,.2,.5,dark,s*1.1,.85,z))}});
  /* chassi: quadro, plataforma, cabine avancada, para-lamas, caixas laterais, escape e estabilizadores */
  const hull=new THREE.Group(),H=mb(),jk=[];
  H.b(2.1,.3,9.6,DK,0,.95,-.1);H.b(2.9,.34,7,'M',0,1.3,-1.5);H.b(2.7,1.9,2.2,'M',0,1.85,3.4);H.b(2.3,.8,.06,GL,0,2.3,4.52,-.2);H.b(2.8,.3,.3,DK,0,.85,4.65);
  for(const s of[-1,1]){H.b(.06,.7,1.2,GL,s*1.36,2.3,3.5);H.b(.7,.12,3.2,'M',s*1.45,1.45,2.7);H.b(.7,.12,3.2,'M',s*1.45,1.45,-2.55);H.b(.45,.75,2.2,'M',s*1.55,1.25,0);H.b(.3,.12,.5,MT,s*1.1,2.8,3.1);
    hull.add(bx(.3,.2,.1,lamp,s*.9,1.2,4.56),bx(.3,.2,.08,brkM,s*.9,1.3,-5.02));
    const j=new THREE.Group();j.position.set(s*1.5,.95,-4.5);j.add(bx(.2,1,.2,bx(0,0,0,dark).material,0,-.5,0),bx(.55,.1,.55,dark,0,-1,0));hull.add(j);jk.push(j)}
  H.c(.1,.1,1.4,DK,1.25,2.2,2.1,'y');for(let k=0;k<6;k++)H.b(2.5,.04,.08,MT,0,1.5,-4.4+k*.3);
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.1,2.8,3,flagM);
  /* torre: corpo anguloso, radar de busca giratorio atras, radar de tiro e sensor optico na frente */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.5,-1.4);
  T.c(1.2,1.3,.14,'M',0,.07,0,'y');T.b(2.5,1.1,2.6,'M',0,.65,0);T.b(2.3,.2,1.6,'M',0,1.28,-.3,.1);T.b(2.4,1,.9,'M',0,.75,-1.6);T.b(1,.5,.06,DK,0,.7,1.31);
  for(let k=0;k<5;k++)T.b(1.8,.04,.08,MT,0,1.2,-1.3-k*.18);T.out(tg,mat);
  const sr=new THREE.Group();sr.position.set(0,1.25,-1.6);sr.add(new THREE.Mesh(new THREE.CylinderGeometry(.1,.14,.8,8).translate(0,.4,0),dark),bx(2,.9,.1,plM,0,1.1,0),bx(.18,.9,.14,dark,0,1.1,0),bx(2.1,.08,.16,dark,0,1.58,0));
  const beac=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),radM);beac.position.set(.9,1.68,0);sr.add(beac);tg.add(sr);
  const trk=new THREE.Group();trk.position.set(0,1.3,.7);trk.add(bx(.12,.5,.12,dark,0,.25,0),bx(1,.8,.12,plM,0,.85,0),bx(1.05,.06,.14,dark,0,1.27,0),bx(.9,.06,.14,dark,0,.45,0),new THREE.Mesh(new THREE.SphereGeometry(.22,12,8),dark).translateY(.1).translateZ(.3),bx(.12,.12,.12,GL,0,.1,.5));tg.add(trk);
  /* conjunto elevavel: dois lancadores de 6 tubos com tampas, dois canhoes de 30 mm com berco e freio de boca */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),caps=[],gb=[];bp.position.set(0,.9,.9);
  for(const s of[-1,1]){B.b(.8,1.15,3.2,'M',s*1.7,0,1.2);B.b(.7,.06,3,MT,s*1.7,.6,1.2);
    for(const cx of[-.2,.2])for(const cy of[-.36,0,.36])B.c(.12,.12,.08,DK,s*1.7+cx,cy,2.8,'z');
    const cp=new THREE.Group();cp.position.set(s*1.7,.575,2.83);cp.add(bx(.78,1.1,.05,mat,0,-.55,0));bp.add(cp);caps.push(cp);
    const gg=new THREE.Group(),K=mb();gg.position.set(s*1.7,.85,0);
    K.c(.075,.075,3.2,DK,0,0,2.1,'z');K.c(.13,.13,1.2,'M',0,0,1.1,'z');K.b(.55,.45,1.1,'M',0,-.05,.5);K.c(.12,.12,.3,DK,0,0,3.75,'z');K.c(.03,.03,1,MT,0,.14,1.8,'z');K.out(gg,mat);bar.add(gg);gg.userData.r=0;gb.push(gg)}
  B.out(bp,mat);
  const fl=new THREE.Group();for(const s of[-1,1]){const f=new THREE.Group();f.position.set(s*1.7,.85,0);f.add(new THREE.Mesh(new THREE.ConeGeometry(.28,1.1,10).rotateX(Math.PI/2).translate(0,0,4.4),flashM),new THREE.Mesh(new THREE.SphereGeometry(.22,8,6).translate(0,0,3.95),flashM));fl.add(f)}
  fl.visible=false;bar.add(fl);bp.add(bar);tg.add(bp);g.add(tg);
  const crew=new THREE.Group();crew.userData.by=0;
  return fin(base({g,tg,bp,bar,hull,ant,fl,brkM,wheels,steers,mat,dark,radM,sr,trk,caps,jk,gb,crew,lid:[new THREE.Group(),new THREE.Group()],pant:true,cannon:true,spd:1.7,trn:1.05,L:4,W:1.5,mz:4.3,fk:.3,rld:1,wd:1.4,armor:.7,hp:85,TY:1.5,gLf:-9,gk:0,ak:0,jd:0}));
}
function animPantsir(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.radM.color.setHex(0x220000);return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/17,0,1),ph=t.v*dt,ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  for(const w of t.wheels)w.rotation.x+=ph/.7;
  for(const s of t.steers)s.g.rotation.y+=((t.st||0)*.42*s.k-s.g.rotation.y)*Math.min(1,dt*6);
  t.pt=(t.pt||0)+(clamp(-ac*.004,-.05,.05)-(t.pt||0))*Math.min(1,dt*5);
  /* estabilizadores traseiros descem parado e sobem em movimento */
  t.jd+=((Math.abs(t.v)<.6?1:0)-t.jd)*Math.min(1,dt*1.5);t.jk.forEach(j=>j.position.y=.95+(1-t.jd)*.8);
  const by=(1-t.jd)*Math.sin(now*34+t.x)*(.008+.012*th)-t.recoil*.02;
  t.hull.position.y=by;t.tg.position.y=t.TY+by;t.hull.rotation.x=t.pt-t.recoil*.012;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.ant.rotation.x=-t.v*.014+Math.sin(now*3+t.z)*.03;
  /* radar de busca gira mais rapido com alvo; radar de tiro acompanha; tampas dos tubos de missil abrem */
  t.ak+=((t.mgt?1:0)-t.ak)*Math.min(1,dt*3);t.sr.rotation.y+=dt*(2.4+t.ak*3.2);
  t.trk.rotation.y=Math.sin(now*1.1+t.x*.1)*(t.mgt?.08:.5);t.trk.rotation.x=Math.sin(now*1.7)*(t.mgt?.03:.12);
  t.caps.forEach(c=>c.rotation.x=-t.ak*1.4);t.radM.color.setHex(Math.sin(now*5)>0?0xff2a1a:0x4a0c08);
  if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=.06;t.bfi=1;fire(t);t.bfi=0}}
  if(t.lf!==t.gLf){t.gLf=t.lf;t.gk++;const gg=t.gb[t.gk&1];gg.userData.r=1;gg.localToWorld(v2.set(0,-.1,.6));puff(v2,0xd9b24a,.2,2.5,.5,1.2)}
  for(const gg of t.gb){if(gg.userData.r>0)gg.userData.r=Math.max(0,gg.userData.r-dt*9);gg.position.z=-gg.userData.r*.4}
  tankFx(t,dt,now,th,{ex:[[1.25,1,2.1]],dk:[[1.7,.2,-1.9],[-1.7,.2,-1.9],[1.7,.2,-3.2],[-1.7,.2,-3.2]],mz:4.3,rr:3,rc:.3});
  if(t.fl.visible){const k=t.gk&1;t.fl.children.forEach((c,i)=>c.visible=i===k)}
  mgScan(t,dt,190);smokeQ(t,dt,1.2,.8,-.8);
}
/* ---------- Corveta: navio de guerra que so navega em mar fundo, canhao de 76 mm em rajadas, radar giratorio ---------- */
function makeCorvette(color,fc){
  const{dark,brkM,flashM,flagM}=mm(fc),HM=mat0(color||0x8a949c),DM=mat0(0x5b6268),RM=mat0(0x7a2c24),WM=mat0(0xc9ced1),GL=mat0(0x1d2f3a),g=new THREE.Group();
  [HM,DM,RM].forEach(m=>m.side=THREE.DoubleSide);g.rotation.order='YXZ';
  const out=[[-3.2,-17],[3.2,-17],[3.6,-6],[3.3,8],[1.4,15],[0,18.5],[-1.4,15],[-3.3,8],[-3.6,-6]];
  const sh=()=>{const s=new THREE.Shape();out.forEach(([x,z],i)=>i?s.lineTo(x,z):s.moveTo(x,z));return s};
  const hull=new THREE.Group();
  hull.add(new THREE.Mesh(new THREE.ExtrudeGeometry(sh(),{depth:3.4,bevelEnabled:false}).rotateX(Math.PI/2).translate(0,2.2,0),HM));
  hull.add(new THREE.Mesh(new THREE.ExtrudeGeometry(sh(),{depth:1.4,bevelEnabled:false}).scale(1.012,1,1.004).rotateX(Math.PI/2),RM));
  const A=(w,h,d,m,x,y,z,rx)=>{const o=bx(w,h,d,m,x,y,z);if(rx)o.rotation.x=rx;hull.add(o);return o};
  const C=(r,h,m,x,y,z)=>{const o=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,14),m);o.position.set(x,y,z);hull.add(o);return o};
  A(5.4,2.4,12,HM,0,3.4,-2.5);A(4.6,1.7,3.6,HM,0,5.45,.3);A(4.4,.5,.1,GL,0,5.65,2.12);A(.1,.5,3,GL,2.3,5.65,.4);A(.1,.5,3,GL,-2.3,5.65,.4);
  A(2.6,2.4,3,DM,0,5.8,-6.2);A(2.7,.2,3.1,dark,0,7.05,-6.2);A(5.2,2.6,3.6,HM,0,3.5,-9.5);A(6.2,.12,6.4,DM,0,2.26,-14);A(.5,.03,2.4,WM,0,2.34,-14);A(2,.03,.5,WM,0,2.34,-14);
  for(const s of[-1,1])A(1.1,.7,3.8,dark,s*1.4,2.7,5.8,-.4);
  C(.15,6,dark,0,9.3,-1.5);A(1.6,.2,1.6,dark,0,8.4,-1.5);C(.6,1,DM,0,5.3,-9.5);A(.12,3,.12,dark,0,4.7,-16.5);A(1.2,.7,.04,flagM,.6,5.7,-16.5);
  g.add(hull);
  const sr=new THREE.Group();sr.position.set(0,9.9,-1.5);sr.add(bx(3.4,.5,.2,dark,0,.35,0),bx(.3,.5,.3,dark,0,0,0));g.add(sr);
  const tg=new THREE.Group();tg.position.set(0,2.2,9.5);
  const tb=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,.6,16),DM);tb.position.y=.3;tg.add(tb,bx(2.7,1.1,3.2,HM,0,1.05,0),bx(2.3,.6,1.2,HM,0,.8,2));
  const bp=new THREE.Group(),bar=new THREE.Group(),fl=new THREE.Group();bp.position.set(0,1.0,1.7);
  const br=new THREE.Mesh(new THREE.CylinderGeometry(.17,.17,5,10).rotateX(Math.PI/2).translate(0,0,2.5),dark);bar.add(br,bx(.45,.45,.5,dark,0,0,5.1));
  fl.add(new THREE.Mesh(new THREE.ConeGeometry(.35,1.6,10).rotateX(Math.PI/2).translate(0,0,5.9),flashM));fl.visible=false;bar.add(fl);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,fl,brkM,mat:HM,dark,sr,wheels:[],flagM,corv:true,cannon:true,spd:1.3,trn:1,L:14,W:3.4,mz:5.4,fk:.55,rld:1.5,wd:99,armor:1.2,hp:220,TY:2.2,hr:9,hc:3,hh:4}));
}
function shipStep(t,dt,thr,turn){
  const deepOK=(x,z,h)=>{const s=Math.sin(h),c=Math.cos(h);return getHV(x,z)<WATER-1.6&&getHV(x+s*16,z+c*16)<WATER-1&&getHV(x-s*14,z-c*14)<WATER-1&&getHV(x+c*3.6,z-s*3.6)<WATER-.6&&getHV(x-c*3.6,z+s*3.6)<WATER-.6};
  t.fld=0;t.wet=0;t.v+=((thr>0?thr*15:thr*5)*(t.spd||1)-t.v)*Math.min(1,dt*.7);t.st=turn;
  const sp=Math.min(1,Math.abs(t.v)/6),nh=t.hd+turn*.5*sp*(t.v<0?-1:1)*dt,nx=t.x+Math.sin(nh)*t.v*dt,nz=t.z+Math.cos(nh)*t.v*dt;
  if(Math.hypot(nx,nz)>HALF-24||!deepOK(nx,nz,nh)){if(t.isPlayer&&Math.abs(t.v)>.5&&(t.sw=(t.sw||0)-dt)<=0){t.sw=3;toast('Águas rasas! A corveta encalharia')}t.blk=1;if(deepOK(t.x,t.z,nh))t.hd=nh;t.v*=-.2;return}
  t.hd=nh;t.x=nx;t.z=nz;
  if(Math.abs(t.v)>2&&(t.wp=(t.wp||0)-dt)<=0){t.wp=.07;const s=Math.sin(t.hd),c=Math.cos(t.hd);for(const k of[-1,1]){v2.set(t.x-s*15+c*k*2,WATER+.15,t.z-c*15-s*k*2);puff(v2,0xe3f1f8,1.3,2.5,.8,1.6)}}
}
function animCorv(t,dt){
  t.clk+=dt;
  if(t.dead){t.sink=Math.min(7,(t.sink||0)+dt*.6);place(t);return blowOff(t,dt,t.TY)}
  t.sr.rotation.y+=dt*2.2;
  if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=.14;t.bfi=1;fire(t);t.bfi=0}}
  if(t.recoil>0)t.recoil=Math.max(0,t.recoil-dt*3);t.bar.position.z=-t.recoil*.8;
  if(t.fT>0){t.fT-=dt;if(t.fT<=0)t.fl.visible=false}
  if(!t.idle&&Math.random()<dt*6){t.g.localToWorld(v2.set(0,7.3,-6.2));puff(v2,0x3a3836,1.2,1.5,1.6,2.5)}
}
function toSea(t){
  const ok=(x,z,w)=>Math.hypot(x,z)<HALF-60&&getHV(x,z)<WATER-3&&[[16,0],[-16,0],[0,16],[0,-16]].every(([a,b])=>getHV(x+a,z+b)<WATER-2)&&(!w||[0,1,2,3,4,5,6,7].every(i=>getHV(x+Math.cos(i*.785)*55,z+Math.sin(i*.785)*55)<WATER-1.5));
  for(const w of[1,0])for(let r=0;r<HALF;r+=14)for(let k=0;k<(r?20:1);k++){const a=k/20*6.283+r,x=t.x+Math.cos(a)*r,z=t.z+Math.sin(a)*r;if(ok(x,z,w)){t.x=x;t.z=z;t.hd=t.yaw=Math.atan2(-x,-z);return}}
}
/* corvetas abandonadas no mar: se um inimigo de terra chega perto, ele toma a corveta, que vira um inimigo extra */
const teamCol=m=>m===5?{c:0xa8456f,f:0xff7ac8}:m===4?{c:0x5b3a86,f:0xb06cff}:m===2?{c:0x3d5f86,f:0x4aa3ff}:m===3?{c:0x2f7d3a,f:0xffd400}:{c:0x8a5a3a,f:0xd6452f};
function shipOK(x,z,h){const s=Math.sin(h),c=Math.cos(h);return getHV(x,z)<WATER-3&&getHV(x+s*16,z+c*16)<WATER-2&&getHV(x-s*14,z-c*14)<WATER-2&&getHV(x+c*3.6,z-s*3.6)<WATER-1&&getHV(x-c*3.6,z+s*3.6)<WATER-1}
function spawnShips(){
  let n=2-tanks.filter(q=>q.corv&&q.idle&&!q.dead).length;
  for(let i=0;i<n;i++)for(let k=0;k<60;k++){
    const a=Math.random()*6.283,sn=Math.sin(a),cs=Math.cos(a);let ok=0;
    for(let r=HALF*.5;r<HALF-90;r+=10){const x=cs*r,z=sn*r;
      if(shipOK(x,z,-a)){if(Math.hypot(x-player.x,z-player.z)>80&&!tanks.some(q=>q.corv&&!q.dead&&Math.hypot(q.x-x,q.z-z)<80)){const t=makeCorvette();t.idle=true;t.team=9;t.x=x;t.z=z;t.hd=t.yaw=-a;ok=1}break}}
    if(ok)break}
}
function shipCapture(){
  for(const s of tanks){if(!s.corv||!s.idle||s.dead)continue;
    for(const q of tanks){if(!q.ai||q.dead||q.ally||q.corv||q.air||q.isPlayer)continue;
      if(Math.hypot(q.x-s.x,q.z-s.z)<50){const T=teamCol(q.team);s.idle=false;s.ai=true;s.team=q.team;s.ally=false;s.mat.color.setHex(T.c);s.flagM.color.setHex(T.f);s.cd=3;s.tar=null;
        for(let i=0;i<12;i++)puff(v3.set(s.x,WATER+2,s.z),i%2?T.f:T.c,2.2,5,1.8,4);toast('Um inimigo tomou uma corveta: +1 inimigo');break}}}
}
function aiShip(t,dt){
  t.rt=(t.rt||0)-dt;
  if(t.rt<=0||!t.tar||t.tar.dead){t.rt=.8;let best=1e9,bt=null;for(const q of tanks){if(q.dead||q.idle||!hostile(t,q))continue;const d=Math.hypot(q.x-t.x,q.z-t.z)*(q===player?.7:1);if(d<best){best=d;bt=q}}t.tar=bt}
  const o=t.tar;let th=0,tn=0;
  const dx=o?o.x-t.x:0,dz=o?o.z-t.z:0,d=o?Math.hypot(dx,dz):0,want=o?Math.atan2(dx,dz):t.hd;
  if(t.blk>0){t.blk=0;t.avt=2;t.av=Math.random()<.5?1:-1}
  if(t.avt>0){t.avt-=dt;tn=t.av;th=.6}
  else if(o){t.sd=t.sd||(Math.random()<.5?1:-1);if(d>150){th=.8;tn=clamp(angDiff(want,t.hd)*2,-1,1)}else{th=.25;tn=clamp(angDiff(want+t.sd*1.2,t.hd)*2,-1,1)}}
  drive(t,dt,th,tn);
  if(!o)return;
  const dy=angDiff(want,t.yaw);t.yaw+=clamp(dy,-1.2*dt,1.2*dt);
  t.pitch=.5*Math.asin(Math.min(1,G*d/(SPEED*SPEED)))+(o.y-t.y)/Math.max(d,20)*.6+.02;
  t.cd-=dt;
  if(t.cd<=0&&d<200&&Math.abs(dy)<.06){t.cd=t.rld+1.4+Math.random()*1.8;t.yaw+=(Math.random()-.5)*.05;t.pitch+=(Math.random()-.5)*.03;fire(t)}
}
function toLand(t){for(let r=0;r<HALF;r+=12)for(let k=0;k<(r?20:1);k++){const a=k/20*6.283+r,x=t.x+Math.cos(a)*r,z=t.z+Math.sin(a)*r;if(spawnOK(x,z,6)){t.x=x;t.z=z;return}}}
