/* =========================================================================
   AETHERVALE — Lapisan perbaikan kenyamanan bermain
   Menambal masalah kecil yang mengganggu: tombol nyangkut, jeda otomatis,
   panel saat tumbang, sarang bos yatim, toast bertumpuk, dll.
   Dimuat paling akhir setelah save.js.
   ========================================================================= */
(function fixes() {

  /* 1. tombol arah nyangkut: bersihkan semua tekanan saat panel/jeda/pindah tab */
  const clearHeld = () => {
    Input.keys = {}; Input.just = {};
    Input.mouse.down = false; Input.mouse.clicked = false;
    Input.touchVec.x = 0; Input.touchVec.y = 0;
    document.querySelectorAll('.tbtn.held').forEach(b => b.classList.remove('held'));
  };
  const op = UI.openPanel.bind(UI);
  UI.openPanel = function (kind) {
    if (Game.state === 'play' && Game.player && Game.player.dead) {
      Game.toast('Tunggu sampai kau bangkit kembali.', '#ff7a7a'); return;
    }
    clearHeld(); op(kind);
  };
  const cp = UI.closePanel.bind(UI);
  UI.closePanel = function () { clearHeld(); cp(); };

  /* 2. lepas tombol tetikus di luar kanvas tidak lagi membuat serangan terus jalan */
  addEventListener('mouseup', () => { Input.mouse.down = false; });
  addEventListener('pointercancel', () => { Input.mouse.down = false; });
  document.addEventListener('mouseleave', () => { Input.mouse.down = false; });

  /* 3. jeda otomatis saat tab disembunyikan, dan bersihkan tombol */
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && Game.state === 'play' && !Game.paused) { Game.paused = true; clearHeld(); }
  });
  addEventListener('blur', clearHeld);

  /* 4. jeda juga membersihkan tombol supaya tidak melesat saat dilanjutkan */
  const tp = UI.togglePause.bind(UI);
  UI.togglePause = function () { clearHeld(); tp(); if (Game.paused && Save.write) Save.write(true); };

  /* 5. status efek bisa dibersihkan (dipakai saat respawn / keluar arena) */
  if (!Status.clear) Status.clear = function (e) { if (e) delete e.st; };

  /* 6. toast tidak bertumpuk menutupi kotak dialog */
  const ot = Game.toast.bind(Game);
  Game.toast = function (msg, color) {
    ot(msg, color);
    const cap = (Game.dialog || Game.cutscene) ? 2 : 4;
    while (Game.toasts.length > cap) Game.toasts.pop();
  };

  /* 7. sarang bos yatim: kalau bosnya sudah tak ada di dunia, buka lagi peluang sarang baru */
  const lu = Lairs.update.bind(Lairs);
  Lairs.update = function (dt) {
    if (this.active && (this.active.dead || Game.enemies.indexOf(this.active) < 0)) this.active = null;
    lu(dt);
  };

  /* 8. penduduk tanpa naskah tidak lagi membuat interaksi gagal */
  const oi = Game.interact.bind(Game);
  Game.interact = function () {
    const n = this.nearestNpc();
    if (n && !NPC_LINES[n.id]) {
      this.dialog = { npc: n.id, name: n.name || 'Penduduk', role: n.role || 'Warga Dusun',
        lines: ['"Selamat datang di dusun kami. Hati-hati di luar pagar."'], idx: 0, panel: n.panel || null };
      Audio2.sfx('ui'); return;
    }
    oi();
  };

  /* 9. ramuan: beri tahu kalau masih jeda, jangan diam saja */
  const upo = Game.usePotion.bind(Game);
  Game.usePotion = function () {
    const P = this.player;
    if (P.dead) return;
    if (P.potionCd > 0) { this.floater(P.x, P.y - 30, 'RAMUAN BELUM SIAP', '#8b93a5'); return; }
    if (P.hp >= P.stats.hp) { this.floater(P.x, P.y - 30, 'HP SUDAH PENUH', '#8b93a5'); return; }
    upo();
  };

  /* 10. skill: slot kosong / masih jeda memberi umpan balik, bukan senyap */
  const osk = Game.skill.bind(Game);
  Game.skill = function (i) {
    const P = this.player;
    if (!P || P.dead || this.dialog || this.activePanel || this.state !== 'play') return;
    if (!Skills.slots[i]) { this.floater(P.x, P.y - 34, 'SLOT SKILL KOSONG · TEKAN K', '#8b93a5'); return; }
    if (Skills.cd[i] > 0) { this.floater(P.x, P.y - 34, Skills.cd[i].toFixed(1) + 's', '#8b93a5'); return; }
    osk(i);
  };

  /* 11. partikel & floater dibatasi supaya frame tidak jatuh di pertarungan besar */
  const of = Game.floater.bind(Game);
  Game.floater = function (x, y, text, color, big) {
    if (this.floaters.length > 28) this.floaters.shift();
    of(x, y, text, color, big);
  };

  /* 12. bilah bos hilang begitu bos mati (jangan tunggu animasi lenyap) */
  const kill = Game.killEnemy.bind(Game);
  Game.killEnemy = function (e) {
    kill(e);
    if (e && e.def_boss) { e.aggro = false; e.clash = false; }
  };

  /* 13 & 14 dijalankan setelah antarmuka dibangun */
  const late = () => {
  const pad = document.querySelector('.touchpad');
  if (pad && !pad.querySelector('[data-act="pause"]')) {
    const b = document.createElement('button');
    b.className = 'tbtn'; b.dataset.act = 'pause'; b.textContent = 'JEDA';
    b.addEventListener('click', e => { e.preventDefault(); UI.togglePause(); });
    pad.appendChild(b);
  }

  /* 14. BOSS CLASH dari layar utama memakai simpanan yang ada,
         bukan membuat tokoh baru yang menimpa kemajuanmu */
  const bc = document.getElementById('btnClash');
  if (bc) {
    bc.onclick = () => {
      Audio2.init(); Audio2.sfx('ui');
      if (Save.has()) Save.continueGame();
      else {
        const card = document.querySelector('.class-card.active');
        Game.start((card && card.dataset.cls) || CLASSES[0].id);
      }
      setTimeout(() => Clash.start(), 500);
    };
  }
  };
  if (document.readyState === 'complete') setTimeout(late, 60);
  else addEventListener('load', () => setTimeout(late, 60));

  /* 16. perubahan pengaturan langsung tersimpan, termasuk dari layar utama */
  const ws = UI.wire_settings.bind(UI);
  UI.wire_settings = function () {
    ws();
    this.modal.querySelectorAll('[data-set]').forEach(b => {
      const prev = b.onclick;
      b.onclick = e => { prev && prev(e); Save.writeSettings(); };
    });
  };

})();
