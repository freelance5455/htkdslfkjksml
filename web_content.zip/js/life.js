/* ============================================================
   life.js — rotina, rival, amizade, rádio e hotel
   Truco de Boteco · extensão do modo história
   Carregar DEPOIS de story.js e ANTES de world.js.
   ============================================================ */

/* ---------- Rotina dos personagens ----------
   Cada bloco: from/to em horas (0–24), place, x, y.
   place: 'city' ou id de interior. Se estiver dormindo,
   some do mapa (home: true). */
const SCHEDULES = {
  zeca: [
    { from: 6,  to: 12, place: 'city', x: 10, y: 17 },
    { from: 12, to: 18, place: 'boteco', x: 7, y: 9 },
    { from: 18, to: 23, place: 'city', x: 12, y: 19 },
    { from: 23, to: 6,  place: 'city', x: 10, y: 17, home: true },
  ],
  dona: [
    { from: 7,  to: 11, place: 'city', x: 34, y: 18 },
    { from: 11, to: 16, place: 'city', x: 30, y: 12 },  // perto do mercado
    { from: 16, to: 20, place: 'city', x: 30, y: 16 },
    { from: 20, to: 7,  place: 'city', x: 34, y: 18, home: true },
  ],
  bereba: [
    { from: 10, to: 22, place: 'boteco', x: 5, y: 8 },
    { from: 22, to: 10, place: 'boteco', x: 5, y: 8, home: true },
  ],
  dudu: [
    { from: 9,  to: 21, place: 'fliperama', x: 6, y: 10 },
    { from: 21, to: 9,  place: 'fliperama', x: 6, y: 10, home: true },
  ],
  bigode: [
    { from: 8,  to: 23, place: 'boteco', x: 16, y: 6 },
    { from: 23, to: 8,  place: 'boteco', x: 16, y: 6, home: true },
  ],
  padre: [
    { from: 6,  to: 12, place: 'igreja', x: 8, y: 6 },
    { from: 12, to: 17, place: 'city', x: 40, y: 36 },
    { from: 17, to: 20, place: 'igreja', x: 8, y: 6 },
    { from: 20, to: 6,  place: 'igreja', x: 8, y: 6, home: true },
  ],
  kombi: [
    { from: 7,  to: 12, place: 'city', x: 24, y: 40 },
    { from: 12, to: 18, place: 'oficina', x: 4, y: 7 },
    { from: 18, to: 22, place: 'boteco', x: 12, y: 9 },
    { from: 22, to: 7,  place: 'city', x: 24, y: 40, home: true },
  ],
  dete: [
    { from: 8,  to: 14, place: 'loterica', x: 4, y: 5 },
    { from: 14, to: 20, place: 'city', x: 18, y: 44 },
    { from: 20, to: 8,  place: 'loterica', x: 4, y: 5, home: true },
  ],
  feira: [
    { from: 6,  to: 14, place: 'city', x: 28, y: 48 },
    { from: 14, to: 19, place: 'city', x: 26, y: 54 },  // perto do mercado do centro
    { from: 19, to: 6,  place: 'city', x: 28, y: 48, home: true },
  ],
  sindico: [
    { from: 8,  to: 12, place: 'predio', x: 8, y: 7 },
    { from: 12, to: 17, place: 'city', x: 32, y: 44 },
    { from: 17, to: 21, place: 'predio', x: 8, y: 7 },
    { from: 21, to: 8,  place: 'predio', x: 8, y: 7, home: true },
  ],
  nogueira: [
    { from: 9,  to: 18, place: 'clube', x: 15, y: 6 },
    { from: 18, to: 22, place: 'clube', x: 12, y: 8 },
    { from: 22, to: 9,  place: 'clube', x: 15, y: 6, home: true },
  ],
  taxi: [
    { from: 5,  to: 12, place: 'city', x: 19, y: 75 },
    { from: 12, to: 18, place: 'city', x: 22, y: 70 },
    { from: 18, to: 2,  place: 'city', x: 19, y: 75 },
    { from: 2,  to: 5,  place: 'city', x: 19, y: 75, home: true },
  ],
  dj: [
    { from: 14, to: 4,  place: 'baile', x: 6, y: 8 },
    { from: 4,  to: 14, place: 'baile', x: 6, y: 8, home: true },
  ],
  cotinha: [
    { from: 7,  to: 20, place: 'casa', x: 7, y: 8 },
    { from: 20, to: 7,  place: 'casa', x: 7, y: 8, home: true },
  ],
  lenda: [
    { from: 10, to: 22, place: 'arena', x: 10, y: 8 },
    { from: 22, to: 10, place: 'arena', x: 10, y: 8, home: true },
  ],
};

/* ---------- Apelidos de rival ---------- */
const RIVAL_NICKS = {
  win: [
    { pt: 'o Moleque', en: 'the Kid', es: 'el Pibe' },
    { pt: 'o Sortudo', en: 'Lucky', es: 'el Suertudo' },
    { pt: 'o Blefeiro', en: 'the Bluffer', es: 'el Farolero' },
    { pt: 'o Novato', en: 'the Rookie', es: 'el Novato' },
    { pt: 'o Inseto', en: 'the Bug', es: 'el Bicho' },
  ],
  lose: [
    { pt: 'o Rei', en: 'the King', es: 'el Rey' },
    { pt: 'a Lenda', en: 'the Legend', es: 'la Leyenda' },
    { pt: 'o Carrasco', en: 'the Hangman', es: 'el Verdugo' },
    { pt: 'o Demônio', en: 'the Demon', es: 'el Demonio' },
    { pt: 'o Fantasma', en: 'the Ghost', es: 'el Fantasma' },
  ],
  revenge: [
    { pt: 'Hoje eu te pego.', en: 'Today I get you.', es: 'Hoy te agarro.' },
    { pt: 'Revanche, moleque.', en: 'Rematch, kid.', es: 'Revancha, pibe.' },
    { pt: 'Você não foge de mim.', en: 'You cannot run from me.', es: 'No te escapás de mí.' },
    { pt: 'Dessa vez é pessoal.', en: 'This time it is personal.', es: 'Esta vez es personal.' },
  ],
};

/* ---------- Frases do Rádio do Bairro ---------- */
const RADIO_LINES = {
  win: [
    { pt: 'Acabou de chegar: alguém derrubou o {name} na mesa. A cidade tá falando.', en: 'Breaking: someone just took down {name} at the table. The town is talking.', es: 'Último momento: alguien tumbó a {name} en la mesa. El pueblo habla.' },
    { pt: 'Rádio Cornélio: o {name} perdeu e não gostou. Quem foi o cara de pau?', en: 'Cornélio Radio: {name} lost and did not like it. Who was the bluffer?', es: 'Radio Cornelio: {name} perdió y no le gustó. ¿Quién fue el farolero?' },
    { pt: 'Notícia quente: {name} entregou os pontos. O boteco já tá rindo.', en: 'Hot news: {name} handed over the points. The bar is already laughing.', es: 'Noticia caliente: {name} entregó los puntos. El bar ya se ríe.' },
  ],
  lose: [
    { pt: 'Alguém tentou e não deu. O {name} continua imbatível por aqui.', en: 'Someone tried and failed. {name} remains undefeated around here.', es: 'Alguien intentó y no pudo. {name} sigue invicto por acá.' },
    { pt: 'Rádio do bairro: o novato levou um susto do {name}. Aprende, moleque.', en: 'Neighborhood radio: the rookie got scared by {name}. Learn, kid.', es: 'Radio del barrio: el novato se asustó con {name}. Aprendé, pibe.' },
  ],
  sleep: [
    { pt: 'São altas horas. O bairro dorme, mas o rádio não desliga.', en: 'Late night. The neighborhood sleeps, but the radio never turns off.', es: 'Alta hora. El barrio duerme, pero la radio no se apaga.' },
    { pt: 'Madrugada em Cornélio. Só o farol do boteco e o rádio ligado.', en: 'Dawn in Cornélio. Only the bar light and the radio on.', es: 'Madrugada en Cornelio. Solo la luz del bar y la radio prendida.' },
  ],
  arrive: [
    { pt: 'Chegou um forasteiro com duzentos reais no bolso. Pagou cento e oitenta no hotel. Vinte sobrando. Boa sorte.', en: 'A stranger arrived with two hundred reais. Paid one hundred eighty at the hotel. Twenty left. Good luck.', es: 'Llegó un forastero con doscientos reales. Pagó ciento ochenta en el hotel. Veinte sobrando. Suerte.' },
  ],
  friend: [
    { pt: 'O {name} anda falando bem de alguém. Parece que nasceu uma amizade.', en: '{name} has been talking well about someone. Looks like a friendship was born.', es: '{name} anda hablando bien de alguien. Parece que nació una amistad.' },
  ],
};

/* ---------- Sistema Life ---------- */
const Life = {
  /* estado que vai pro save */
  friends: {},      // id -> { hearts: 0..5, lastGift: day }
  rivals: {},       // id -> { nick, streak, lastResult, revenge: bool, losses: n }
  partner: null,    // id do parceiro fixo de dupla ou null
  partnerElo: 1000, // elo do parceiro
  radioQueue: [],   // frases pendentes { text, t }
  hotelPaid: false, // já pagou o hotel na chegada
  radioMute: false,

  /* ---------- rotina ---------- */
  scheduleOf(id) {
    return SCHEDULES[id] || null;
  },

  /* retorna o bloco de rotina ativo na hora atual */
  blockAt(id, hour) {
    const sch = this.scheduleOf(id);
    if (!sch) return null;
    const h = ((hour % 24) + 24) % 24;
    for (const b of sch) {
      if (b.from < b.to) {
        if (h >= b.from && h < b.to) return b;
      } else {
        // atravessa meia-noite
        if (h >= b.from || h < b.to) return b;
      }
    }
    return sch[0];
  },

  /* posição e lugar atuais do NPC */
  where(n, hour) {
    const b = this.blockAt(n.id, hour);
    if (!b) return { place: n.place, x: n.x, y: n.y, home: false };
    return { place: b.place, x: b.x, y: b.y, home: !!b.home };
  },

  /* NPCs visíveis na cena atual (respeitando rotina e home) */
  npcsInScene(scene, hour) {
    if (!scene) return [];
    const hourNow = hour != null ? hour : (typeof World !== 'undefined' ? World.hour : 12);
    const list = [];
    const all = (window.NPCS || []).concat(window.EGGS || []);
    for (const n of all) {
      if (n.egg && typeof World !== 'undefined' && !World.zoneOpen(n.zone)) continue;
      const w = this.where(n, hourNow);
      if (w.home) continue; // dormindo: some
      if (scene.kind === 'city' && w.place === 'city') {
        list.push({ ...n, x: w.x, y: w.y, _place: 'city' });
      } else if (scene.kind === 'in' && w.place === scene.id) {
        list.push({ ...n, x: w.x, y: w.y, _place: scene.id });
      }
    }
    return list;
  },

  /* ---------- rival ---------- */
  rivalOf(id) {
    if (!this.rivals[id]) this.rivals[id] = { nick: null, streak: 0, lastResult: null, revenge: false, losses: 0, wins: 0 };
    return this.rivals[id];
  },

  /* registra resultado de uma partida contra o NPC */
  recordMatch(id, won) {
    const r = this.rivalOf(id);
    r.lastResult = won ? 'win' : 'lose';
    if (won) {
      r.wins = (r.wins || 0) + 1;
      r.streak = r.streak > 0 ? r.streak + 1 : 1;
      r.revenge = false;
      // gera apelido se ainda não tem ou se streak alto
      if (!r.nick || r.streak >= 3) {
        const pool = RIVAL_NICKS.win;
        r.nick = pool[Math.floor(Math.random() * pool.length)];
      }
      this.pushRadio('win', id);
      this.addHeart(id, 0.4); // vitória justa sobe um pouco a amizade
    } else {
      r.losses = (r.losses || 0) + 1;
      r.streak = r.streak < 0 ? r.streak - 1 : -1;
      r.revenge = true;
      if (!r.nick || r.streak <= -2) {
        const pool = RIVAL_NICKS.lose;
        r.nick = pool[Math.floor(Math.random() * pool.length)];
      }
      this.pushRadio('lose', id);
    }
  },

  nickOf(id) {
    const r = this.rivals[id];
    if (!r || !r.nick) return null;
    const lang = (typeof T !== 'undefined' && T.lang) || 'pt';
    return r.nick[lang] || r.nick.pt;
  },

  revengeLine(id) {
    const pool = RIVAL_NICKS.revenge;
    const line = pool[Math.floor(Math.random() * pool.length)];
    const lang = (typeof T !== 'undefined' && T.lang) || 'pt';
    return line[lang] || line.pt;
  },

  /* ---------- amizade ---------- */
  friendOf(id) {
    if (!this.friends[id]) this.friends[id] = { hearts: 0, lastGift: 0 };
    return this.friends[id];
  },

  addHeart(id, amount) {
    const f = this.friendOf(id);
    const before = f.hearts;
    f.hearts = Math.max(0, Math.min(5, f.hearts + amount));
    if (Math.floor(f.hearts) > Math.floor(before) && f.hearts >= 1) {
      this.pushRadio('friend', id);
    }
    return f.hearts;
  },

  heartsOf(id) {
    return Math.floor(this.friendOf(id).hearts);
  },

  /* pode virar parceiro de dupla? */
  canPartner(id) {
    return this.heartsOf(id) >= 3;
  },

  setPartner(id) {
    if (id && !this.canPartner(id)) return false;
    this.partner = id || null;
    if (id) this.partnerElo = 1000 + this.heartsOf(id) * 80;
    return true;
  },

  /* ---------- rádio ---------- */
  pushRadio(kind, npcId) {
    if (this.radioMute) return;
    const pool = RADIO_LINES[kind];
    if (!pool || !pool.length) return;
    const line = pool[Math.floor(Math.random() * pool.length)];
    const lang = (typeof T !== 'undefined' && T.lang) || 'pt';
    let text = line[lang] || line.pt;
    if (npcId) {
      const n = (window.NPCS || []).find((x) => x.id === npcId) || (window.EGGS || []).find((x) => x.id === npcId);
      const name = n ? n.name : npcId;
      text = text.replace('{name}', name);
    }
    this.radioQueue.push({ text, t: Date.now(), kind });
    // limita fila
    if (this.radioQueue.length > 6) this.radioQueue.shift();
  },

  popRadio() {
    if (!this.radioQueue.length) return null;
    return this.radioQueue.shift();
  },

  /* linha de sono quando é noite */
  maybeSleepRadio(hour) {
    if (hour >= 1 && hour < 5 && Math.random() < 0.15) {
      this.pushRadio('sleep');
    }
  },

  /* ---------- hotel / chegada ---------- */
  applyArrival() {
    if (this.hotelPaid) return false;
    // chega com 200, paga 180, fica com 20 (já é o valor inicial do World.money)
    this.hotelPaid = true;
    this.pushRadio('arrive');
    return true;
  },

  /* ---------- serialização ---------- */
  data() {
    return {
      friends: this.friends,
      rivals: this.rivals,
      partner: this.partner,
      partnerElo: this.partnerElo,
      hotelPaid: this.hotelPaid,
      radioMute: this.radioMute,
    };
  },

  load(d) {
    if (!d) return;
    this.friends = d.friends || {};
    this.rivals = d.rivals || {};
    this.partner = d.partner || null;
    this.partnerElo = d.partnerElo || 1000;
    this.hotelPaid = d.hotelPaid === true;
    this.radioMute = d.radioMute === true;
  },

  reset() {
    this.friends = {};
    this.rivals = {};
    this.partner = null;
    this.partnerElo = 1000;
    this.radioQueue = [];
    this.hotelPaid = false;
    this.radioMute = false;
  },
};

window.Life = Life;
window.SCHEDULES = SCHEDULES;
window.RADIO_LINES = RADIO_LINES;
