'use strict';
/* ============ قسم الطبيب ============ */
let drQ = '';
const emptyDraft = p => ({ bp: '', temp: '', weight: '', height: '', sugar: '', complaint: '', history: (p && p.history) || '', allergies: (p && p.allergies) || '', chronic: (p && p.chronic) || '', diagnosis: '' });

PAGES.dr_queue = {
  title: () => S.pno ? 'ملف المريض' : 'قائمة الانتظار', live: false,
  onData(s) { if (S.pno) return drLive(s); renderPage(); },
  render() {
    if (S.pno) return drProfile();
    const t = today(), W = D.queue.filter(q => q.date === t && q.status !== 'done').sort((a, b) => a.no - b.no);
    const doneN = D.queue.filter(q => q.date === t && q.status === 'done').length;
    const ready = D.labRequests.filter(r => r.status === 'done' && !r.seen).sort((a, b) => b.doneTs - a.doneTs);
    $('page').innerHTML =
      '<div class="stats">' + stat('clock', 'بالانتظار', W.filter(q => q.status === 'waiting').length) + stat('stetho', 'قيد الكشف', W.filter(q => q.status === 'inprogress').length, 'b') + stat('check', 'تم الكشف اليوم', doneN, 'g') + stat('flask', 'نتائج جاهزة', ready.length, 'n') + '</div>' +
      (ready.length ? '<div class="card"><div class="card-h"><h3>' + ic('bell') + 'نتائج فحوصات جاهزة</h3>' + badge(ready.length, 'ok') + '</div>' + ready.map(r => '<div class="row click" onclick="openPatient(' + r.patientNo + ',\'labs\')"><div class="av lt num">' + r.patientNo + '</div><div class="grow"><div class="t">' + esc(r.patientName) + '</div><div class="mut">' + r.tests.map(x => esc(x.name)).join('، ') + '</div></div>' + badge('جاهزة · ' + hm(r.doneTs), 'ok') + ic('chevl', 'sm') + '</div>').join('') + '</div>' : '') +
      '<div class="card"><div class="card-h"><h3>' + ic('list') + 'مرضى اليوم</h3><button class="btn ghost sm" onclick="go(\'dr_patients\')">' + ic('search', 'sm') + 'بحث في السجلات</button></div>' +
      (W.map(q => { const m = Math.max(0, Math.round((nowTs() - q.ts) / 60000)); return '<div class="row click" onclick="startExam(' + q.id + ')"><div class="av num" style="width:52px">' + q.no + '</div><div class="grow"><div class="t">' + esc(q.patientName) + '</div><div class="mut">مريض رقم <span class="num">' + q.patientNo + '</span> · ' + esc(q.age) + ' سنة · ' + GEN[q.gender || ''] + ' · ينتظر <span class="num">' + m + '</span> دقيقة</div></div>' + (q.status === 'inprogress' ? badge('قيد الكشف' + (q.doctorName ? ' · ' + esc(q.doctorName) : ''), 'info') : '') + '<button class="btn sm">' + ic('stetho', 'sm') + (q.status === 'inprogress' ? 'متابعة' : 'بدء الكشف') + '</button></div>'; }).join('') || empty('users', 'لا يوجد مرضى بالانتظار الآن')) + '</div>';
  }
};
PAGES.dr_patients = {
  title: () => S.pno ? 'ملف المريض' : 'سجلات المرضى', live: false,
  onData(s) { if (S.pno) return drLive(s); if (s === 'patients' || s === 'labRequests' || s === 'queue') drpDraw(); },
  render() {
    if (S.pno) return drProfile();
    $('page').innerHTML = pagehead('سجلات المرضى', '<button class="btn accent" onclick="patientForm()">' + ic('plus', 'sm') + 'مريض جديد</button>') +
      '<div class="card"><input id="dq" class="input" placeholder="ابحث بالاسم أو رقم المريض أو الهاتف…" value="' + esc(drQ) + '" oninput="drQ=this.value;drpDraw()" autocomplete="off"></div><div id="dlist"></div>';
    drpDraw();
  }
};
function drpDraw() {
  const e = $('dlist'); if (!e) return;
  const q = drQ.trim().toLowerCase(); let L = [...D.patients].sort((a, b) => b.no - a.no);
  L = q ? L.filter(p => matchPatient(p, q)) : L.slice(0, 40);
  const rd = new Set(D.labRequests.filter(r => r.status === 'done' && !r.seen).map(r => r.patientNo));
  e.innerHTML = L.map(p => '<div class="row click" onclick="openPatient(' + p.no + ')"><div class="av num">' + p.no + '</div><div class="grow"><div class="t">' + esc(p.name) + '</div><div class="mut">' + esc(p.age) + ' سنة · ' + GEN[p.gender || ''] + (p.phone ? ' · <span class="ltr num">' + esc(p.phone) + '</span>' : '') + '</div></div>' + (rd.has(p.no) ? badge('نتيجة جاهزة', 'ok') : '') + ic('chevl', 'sm') + '</div>').join('') || (q ? empty('search', 'لا يوجد مريض مطابق') : empty('users', 'لا يوجد مرضى'));
}

/* ---------- فتح المريض ---------- */
function openPatient(no, tab, qid) {
  const p = get('patients', no); if (!p) return;
  S.pno = no; S.ptab = tab || 'exam'; S.visitId = null; S.rx = []; S.labSel = new Set(); S.draft = emptyDraft(p);
  const q = qid ? get('queue', qid) : D.queue.find(x => x.patientNo === no && x.date === today() && x.status !== 'done');
  S.qid = q ? q.id : null;
  if (q && q.status === 'waiting') put('queue', { id: q.id, status: 'inprogress', doctorName: S.me.name }).catch(() => { });
  go(S.page === 'dr_queue' ? 'dr_queue' : 'dr_patients', { keep: true });
}
function startExam(qid) { const q = get('queue', qid); if (!q) return; openPatient(q.patientNo, 'exam', qid); }
function closePatient() { S.pno = null; S.qid = null; renderPage().then(() => window.scrollTo(0, 0)); }

function drProfile() {
  const p = get('patients', S.pno); if (!p) { S.pno = null; return PAGES[S.page].render(); }
  const al = (S.draft && S.draft.allergies) || p.allergies;
  $('page').innerHTML =
    '<div class="card"><div class="ptop"><button class="btn ghost icon" onclick="closePatient()" aria-label="رجوع">' + ic('chevr') + '</button><div class="av big num">' + p.no + '</div>' +
    '<div class="grow"><h2 style="font-size:1.25rem">' + esc(p.name) + '</h2><div class="mut">' + esc(p.age) + ' سنة · ' + GEN[p.gender || ''] + (p.phone ? ' · <span class="ltr num">' + esc(p.phone) + '</span>' : '') + (p.address ? ' · ' + esc(p.address) : '') + '</div></div>' +
    '<div class="btns"><button class="btn accent" onclick="finishExam()">' + ic('check', 'sm') + 'إنهاء الكشف</button><button class="btn ghost icon" onclick="printCard(' + p.no + ')" title="بطاقة المريض" aria-label="بطاقة المريض">' + ic('idcard', 'sm') + '</button><button class="btn ghost icon" onclick="patientForm(' + p.no + ')" title="تعديل البيانات" aria-label="تعديل البيانات">' + ic('edit', 'sm') + '</button>' +
    (S.me.role === 'admin' ? '<button class="btn ghost icon" onclick="delPatient(' + p.no + ')" title="حذف المريض" aria-label="حذف المريض">' + ic('trash', 'sm') + '</button>' : '') + '</div></div>' +
    (al ? '<div class="alertbox err" style="margin:1rem 0 0">' + ic('alert') + '<div><b>حساسية:</b> ' + esc(al) + '</div></div>' : '') + '</div>' +
    '<div id="ptabs" style="margin-bottom:1rem"></div><div id="ptab"></div>';
  drTabs(); drTab();
}
function drTabs() {
  const e = $('ptabs'); if (!e) return;
  const nL = D.labRequests.filter(r => r.patientNo === S.pno && (r.status === 'waiting' || (r.status === 'done' && !r.seen))).length;
  e.innerHTML = seg([['exam', ic('stetho', 'sm') + 'الكشف'], ['labs', ic('flask', 'sm') + 'الفحوصات', nL || ''], ['rx', ic('pill', 'sm') + 'الوصفة'], ['hist', ic('history', 'sm') + 'السجل']], S.ptab, 'setPTab');
}
function setPTab(t) { S.ptab = t; drTabs(); drTab(); }
function drTab() { ({ exam: drExam, labs: drLabs, rx: drRx, hist: drHist })[S.ptab](); }
function drLive(s) {
  if (!S.pno) return;
  if (!get('patients', S.pno)) { S.pno = null; renderPage(); return toast('تم حذف ملف المريض', '', 'info'); }
  if (s === 'labRequests') { drTabs(); if (S.ptab === 'labs') drLabs(); }
  else if (s === 'prescriptions' && S.ptab === 'rx') drawRxHist();
  else if (s === 'visits' && S.ptab === 'hist') drHist();
  else if (s === 'medicines' && S.ptab === 'rx') S.rx.forEach((r, i) => { const w = $('rw' + i); if (w) w.innerHTML = rxWarn(r); });
}

/* ---------- الكشف ---------- */
function dset(k, v) { S.draft[k] = v; if (k === 'weight' || k === 'height') bmiDraw(); }
function bmiDraw() { const e = $('bmi'); if (!e) return; const w = +S.draft.weight, h = +S.draft.height; e.innerHTML = w && h ? '<span class="chip">مؤشر الكتلة ' + (w / ((h / 100) ** 2)).toFixed(1) + '</span>' : ''; }
function drExam() {
  const d = S.draft, f = (k, l, t, u, step) => '<div class="field"><label>' + l + (u ? ' <span class="faint">' + u + '</span>' : '') + '</label><input type="' + (t || 'text') + '" ' + (step ? 'step="' + step + '" ' : '') + 'value="' + esc(d[k]) + '" oninput="dset(\'' + k + '\',this.value)" inputmode="' + (t === 'number' ? 'decimal' : 'text') + '"></div>';
  const ta = (k, l) => '<div class="field"><label>' + l + '</label><textarea oninput="dset(\'' + k + '\',this.value)">' + esc(d[k]) + '</textarea></div>';
  $('ptab').innerHTML =
    '<div class="card"><div class="card-h"><h3>' + ic('pulse') + 'العلامات الحيوية</h3><span id="bmi"></span></div><div class="vit">' + f('bp', 'الضغط', 'text', 'mmHg') + f('temp', 'الحرارة', 'number', '°C', '0.1') + f('weight', 'الوزن', 'number', 'kg', '0.1') + f('height', 'الطول', 'number', 'cm') + f('sugar', 'سكر الدم', 'number', 'mg/dL') + '</div></div>' +
    '<div class="card"><div class="card-h"><h3>' + ic('stetho') + 'الكشف السريري</h3></div>' + ta('complaint', 'الشكوى الرئيسية') + '<div class="grid g3">' + ta('history', 'التاريخ المرضي') + ta('allergies', 'الحساسية') + ta('chronic', 'الأمراض المزمنة') + '</div>' + ta('diagnosis', 'التشخيص') +
    '<div class="btns"><button class="btn" onclick="saveVisit()">' + ic('check', 'sm') + 'حفظ الزيارة</button></div></div>';
  bmiDraw();
}
async function ensureVisit() {
  const d = S.draft, p = get('patients', S.pno);
  await put('patients', { no: p.no, history: d.history, allergies: d.allergies, chronic: d.chronic });
  const v = Object.assign({}, d, { patientNo: S.pno, doctorName: S.me.name, queueId: S.qid || null });
  if (S.visitId) v.id = S.visitId; else Object.assign(v, stamp());
  const r = await put('visits', v); S.visitId = r.id; return r.id;
}
async function saveVisit() {
  const p = get('patients', S.pno); if (!await safe(ensureVisit)) return;
  log('visit', 'كشف طبي: ' + p.name, p.no); toast('تم حفظ الزيارة');
}
async function finishExam() {
  const p = get('patients', S.pno), d = S.draft;
  const hasData = d.complaint || d.diagnosis || d.bp || d.temp || d.weight || d.height || d.sugar;
  if (hasData || S.visitId) { if (!await safe(ensureVisit)) return; log('visit', 'كشف طبي: ' + p.name, p.no); }
  if (S.qid) await safe(() => put('queue', { id: S.qid, status: 'done', doctorName: S.me.name }));
  toast('تم إنهاء الكشف'); S.pno = null; S.qid = null; renderPage().then(() => window.scrollTo(0, 0));
}
async function delPatient(no) {
  const p = get('patients', no);
  if (!await ask('حذف المريض «' + p.name + '» وكل سجلاته نهائياً؟\nرقم المريض لن يُعاد استخدامه.', { danger: true, ok: 'حذف نهائي' })) return;
  S.pno = null; await safe(() => del('patients', no)); toast('تم الحذف'); renderPage();
}

/* ---------- الفحوصات ---------- */
function labSel(id, on, el) { if (on) S.labSel.add(id); else S.labSel.delete(id); el.parentNode.classList.toggle('on', on); labTotal(); }
function labTotal() { const e = $('labtot'); if (!e) return; const t = sum([...S.labSel], id => (get('labTests', id) || {}).price || 0); e.textContent = S.labSel.size ? S.labSel.size + ' فحص · ' + money(t) : ''; }
function drLabs() {
  const cat = [...D.labTests].sort((a, b) => a.name.localeCompare(b.name));
  const R = D.labRequests.filter(r => r.patientNo === S.pno).sort((a, b) => b.ts - a.ts);
  $('ptab').innerHTML =
    '<div class="card"><div class="card-h"><h3>' + ic('flask') + 'طلب فحوصات جديدة</h3><span class="mut num" id="labtot"></span></div>' +
    (cat.map(t => { const on = S.labSel.has(t.id); return '<label class="chk' + (on ? ' on' : '') + '"><input type="checkbox"' + (on ? ' checked' : '') + ' onchange="labSel(' + t.id + ',this.checked,this)">' + esc(t.name) + (t.price ? ' <small class="num">' + num(t.price) + '</small>' : '') + '</label>'; }).join(' ') || empty('flask', 'لا توجد فحوصات في الكتالوج — يضيفها قسم المعمل')) +
    '<div class="btns" style="margin-top:1rem"><button class="btn ok" onclick="sendLab()">' + ic('send', 'sm') + 'إرسال إلى المعمل</button></div></div>' +
    '<div class="card"><div class="card-h"><h3>' + ic('history') + 'طلبات هذا المريض (' + R.length + ')</h3></div>' +
    (R.map(r => '<div class="tl"><div class="tm num">' + r.date + ' · ' + hm(r.ts) + '</div><div style="margin:.3rem 0">' + (r.status === 'done' ? badge('النتيجة جاهزة', 'ok') : badge('بانتظار المعمل', 'warn')) + '</div>' +
      (r.status === 'done' ? resultsTable(r) + (r.notes ? '<div class="mut" style="margin-top:.4rem">ملاحظات المعمل: ' + esc(r.notes) + '</div>' : '') + '<div class="btns" style="margin-top:.6rem"><button class="btn ghost sm" onclick="printLab(' + r.id + ')">' + ic('printer', 'sm') + 'طباعة التقرير</button></div>' : '<div>' + r.tests.map(t => '<span class="chip">' + esc(t.name) + '</span>').join('') + '</div>') + '</div>').join('') || empty('flask', 'لا توجد طلبات سابقة')) + '</div>';
  labTotal();
  D.labRequests.filter(r => r.patientNo === S.pno && r.status === 'done' && !r.seen).forEach(r => put('labRequests', { id: r.id, seen: true }).then(() => { drTabs(); updateBadges(); }).catch(() => { }));
}
function resultsTable(r) {
  return '<div class="tbl-wrap" style="margin-top:.4rem"><table class="tbl" style="min-width:480px"><tr><th>الفحص</th><th>النتيجة</th><th>الوحدة</th><th>المعدل الطبيعي</th></tr>' +
    r.tests.map(t => { const x = r.results[t.testId] || {}; return '<tr><td>' + esc(t.name) + '</td><td class="' + (x.flag === 'H' || x.flag === 'L' ? 'fH' : '') + '"><b class="num">' + esc(x.value ?? '—') + '</b> ' + (x.flag === 'H' ? '▲ مرتفع' : x.flag === 'L' ? '▼ منخفض' : '') + '</td><td>' + esc(t.unit) + '</td><td class="num">' + esc(x.range || '') + '</td></tr>'; }).join('') + '</table></div>';
}
async function sendLab() {
  const ids = [...S.labSel]; if (!ids.length) return toast('اختر فحصاً واحداً على الأقل', 'err');
  const p = get('patients', S.pno); if (!await safe(ensureVisit)) return;
  const tests = ids.map(id => get('labTests', id)).filter(Boolean).map(t => ({ testId: t.id, name: t.name, unit: t.unit, price: t.price, deviceCode: t.deviceCode || '' }));
  const st = stamp();
  const r = await safe(() => put('labRequests', Object.assign({ patientNo: p.no, patientName: p.name, age: p.age, gender: p.gender, visitId: S.visitId, tests, status: 'waiting', barcode: p.no + '-' + st.date.replace(/-/g, ''), results: {}, notes: '', seen: false, doctorName: S.me.name }, st)));
  if (!r) return;
  log('lab', 'طلب ' + tests.length + ' فحص للمريض ' + p.name, p.no); S.labSel = new Set(); toast('أُرسل الطلب إلى المعمل'); drTabs(); drLabs();
}

/* ---------- الوصفة ---------- */
const medLabel = m => m.tradeName + (m.scientificName ? ' — ' + m.scientificName : '');
function rxWarn(r) {
  const m = r.medId ? get('medicines', r.medId) : null; if (!m) return '';
  if (m.expiry && m.expiry < today()) return '<span class="errx">⚠ هذا الدواء منتهي الصلاحية</span>';
  if (m.qty <= 0) return '<span class="errx">⚠ الدواء غير متوفر في المخزون</span>';
  if (r.qty > m.qty) return '<span class="errx">⚠ الكمية المطلوبة أكبر من المتاح (' + m.qty + ')</span>';
  return '<span class="okx">✓ المتاح في الصيدلية: ' + m.qty + '</span>';
}
function drRx() {
  $('ptab').innerHTML =
    '<div class="card"><div class="card-h"><h3>' + ic('pill') + 'وصفة جديدة</h3></div><div id="rxrows"></div>' +
    '<div class="btns"><button class="btn ghost" onclick="rxAdd()">' + ic('plus', 'sm') + 'إضافة دواء</button><button class="btn ok" onclick="sendRx()">' + ic('send', 'sm') + 'إرسال إلى الصيدلية</button></div></div><div id="rxhist"></div>';
  if (!S.rx.length) S.rx.push({ medId: '', qty: 1, dosage: '', q: '' });
  drawRxRows(); drawRxHist();
}
function rxAdd() { S.rx.push({ medId: '', qty: 1, dosage: '', q: '' }); drawRxRows(); }
function rxDel(i) { S.rx.splice(i, 1); if (!S.rx.length) S.rx.push({ medId: '', qty: 1, dosage: '', q: '' }); drawRxRows(); }
function rxSet(i, k, v) { S.rx[i][k] = k === 'qty' ? (+v || 0) : v; const w = $('rw' + i); if (w) w.innerHTML = rxWarn(S.rx[i]); }
function drawRxRows() {
  const e = $('rxrows'); if (!e) return;
  e.innerHTML = S.rx.map((r, i) => { const m = r.medId ? get('medicines', r.medId) : null;
    return '<div class="rxrow"><div class="ac"><input class="input" placeholder="ابحث عن الدواء بالاسم التجاري أو العلمي" value="' + esc(m ? medLabel(m) : r.q) + '" oninput="rxSearch(' + i + ',this.value)" onfocus="rxSearch(' + i + ',this.value)" autocomplete="off"><div class="res hide" id="rxres' + i + '"></div></div>' +
      '<input class="input num" type="number" min="1" value="' + r.qty + '" oninput="rxSet(' + i + ',\'qty\',this.value)" placeholder="الكمية" aria-label="الكمية"><input class="input" value="' + esc(r.dosage) + '" oninput="rxSet(' + i + ',\'dosage\',this.value)" placeholder="الجرعة (مثال: حبة 3 مرات يومياً)">' +
      '<button class="btn ghost icon" onclick="rxDel(' + i + ')" aria-label="حذف">' + ic('x', 'sm') + '</button><div class="w" id="rw' + i + '">' + rxWarn(r) + '</div></div>'; }).join('');
}
function rxSearch(i, v) {
  const r = S.rx[i]; r.q = v; if (r.medId) { r.medId = ''; const w = $('rw' + i); if (w) w.innerHTML = ''; }
  const q = v.trim().toLowerCase(), res = $('rxres' + i); if (!res) return;
  let L = D.medicines.filter(m => !q || [m.tradeName, m.scientificName, m.manufacturer].some(x => (x || '').toLowerCase().includes(q)));
  L.sort((a, b) => (+(b.tradeName.toLowerCase().startsWith(q) || (b.scientificName || '').toLowerCase().startsWith(q))) - (+(a.tradeName.toLowerCase().startsWith(q) || (a.scientificName || '').toLowerCase().startsWith(q))) || a.tradeName.localeCompare(b.tradeName));
  res.innerHTML = L.slice(0, 8).map(m => { const ex = m.expiry && m.expiry < today(); return '<button type="button" onclick="rxPick(' + i + ',' + m.id + ')"><div class="grow"><b>' + esc(m.tradeName) + '</b> <span class="mut">' + esc(m.scientificName) + '</span>' + (m.manufacturer ? '<div class="mut" style="font-size:.78rem">' + esc(m.manufacturer) + '</div>' : '') + '</div>' + (ex ? badge('منتهي', 'err') : m.qty <= 0 ? badge('نفد', 'err') : badge('المتاح ' + m.qty, m.qty < 10 ? 'warn' : 'ok')) + '</button>'; }).join('') || '<div class="mut" style="padding:.8rem">لا توجد نتائج في مخزون الصيدلية</div>';
  res.classList.remove('hide');
}
function rxPick(i, id) { S.rx[i].medId = id; S.rx[i].q = ''; drawRxRows(); }
document.addEventListener('click', e => { if (!e.target.closest('.ac')) document.querySelectorAll('.ac .res').forEach(r => r.classList.add('hide')); });
function drawRxHist() {
  const e = $('rxhist'); if (!e) return;
  const P = D.prescriptions.filter(r => r.patientNo === S.pno).sort((a, b) => b.ts - a.ts);
  e.innerHTML = '<div class="card"><div class="card-h"><h3>' + ic('history') + 'الوصفات السابقة (' + P.length + ')</h3></div>' +
    (P.map(r => '<div class="tl"><div class="tm num">' + r.date + ' · ' + hm(r.ts) + '</div><div style="margin:.3rem 0">' + (r.status === 'dispensed' ? badge('تم الصرف', 'ok') : badge('بانتظار الصرف', 'warn')) + '</div>' + r.items.map(i => '<div>• ' + esc(i.name) + ' × <span class="num">' + i.qty + '</span> — ' + esc(i.dosage) + '</div>').join('') + '<div class="btns" style="margin-top:.5rem"><button class="btn ghost sm" onclick="printRx(' + r.id + ')">' + ic('printer', 'sm') + 'طباعة</button></div></div>').join('') || empty('pill', 'لا توجد وصفات سابقة')) + '</div>';
}
async function sendRx() {
  const items = S.rx.filter(r => r.medId).map(r => { const m = get('medicines', r.medId); return { medId: m.id, name: m.tradeName, dosage: r.dosage || '', qty: r.qty || 1 }; });
  if (!items.length) return toast('اختر دواءً واحداً على الأقل من القائمة', 'err');
  const p = get('patients', S.pno); if (!await safe(ensureVisit)) return;
  const r = await safe(() => put('prescriptions', Object.assign({ patientNo: p.no, patientName: p.name, age: p.age, gender: p.gender, visitId: S.visitId, items, status: 'pending', doctorName: S.me.name }, stamp())));
  if (!r) return;
  log('rx', 'وصفة طبية (' + items.length + ' دواء) للمريض ' + p.name, p.no); S.rx = []; drRx(); toast('أُرسلت الوصفة إلى الصيدلية');
  if (await ask('تم إرسال الوصفة إلى الصيدلية. هل تريد طباعتها؟', { ok: 'طباعة', title: 'تمت الإضافة' })) printRx(r.id);
}

/* ---------- السجل ---------- */
function drHist() {
  const V = D.visits.filter(v => v.patientNo === S.pno).sort((a, b) => b.ts - a.ts), p = get('patients', S.pno);
  $('ptab').innerHTML =
    (p.chronic || p.history ? '<div class="card"><div class="card-h"><h3>' + ic('file') + 'الخلفية المرضية</h3></div>' + (p.chronic ? '<p><b>أمراض مزمنة:</b> ' + esc(p.chronic) + '</p>' : '') + (p.history ? '<p><b>التاريخ المرضي:</b> ' + esc(p.history) + '</p>' : '') + '</div>' : '') +
    '<div class="card"><div class="card-h"><h3>' + ic('history') + 'الزيارات (' + V.length + ')</h3></div>' +
    (V.map(v => '<div class="tl"><div class="tm num">' + v.date + ' · ' + hm(v.ts) + (v.doctorName ? ' · د. ' + esc(v.doctorName) : '') + '</div>' + (v.complaint ? '<div><b>الشكوى:</b> ' + esc(v.complaint) + '</div>' : '') +
      '<div>' + [['الضغط', v.bp], ['الحرارة', v.temp], ['الوزن', v.weight], ['الطول', v.height], ['السكر', v.sugar]].filter(x => x[1]).map(x => '<span class="chip">' + x[0] + ': <span class="num">' + esc(x[1]) + '</span></span>').join('') + '</div>' + (v.diagnosis ? '<div><b>التشخيص:</b> ' + esc(v.diagnosis) + '</div>' : '') + '</div>').join('') || empty('history', 'لا توجد زيارات مسجلة')) + '</div>';
}
