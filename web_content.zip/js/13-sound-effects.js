(function () {
  'use strict';
  /* FFM 26 sound effects — all synthesised with WebAudio (no files). Each recipe is f(c, out, t) so it also renders offline. */
  let ctx = null, master = null, noiseBuf = null, amb = null;
  const muted = () => { try { const m = document.getElementById('music-muted-toggle'); return !!(m && m.checked); } catch (_) { return false; } };
  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return ctx; }
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain(); master.gain.value = 0.9;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 6;
    master.connect(comp); comp.connect(ctx.destination);
    return ctx;
  }
  function noise(c) {
    if (noiseBuf && noiseBuf.sampleRate === c.sampleRate) return noiseBuf;
    const n = c.sampleRate * 2, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); let seed = 12345;
    for (let i = 0; i < n; i++) { seed = (seed * 1664525 + 1013904223) >>> 0; d[i] = seed / 2147483648 - 1; }
    return (noiseBuf = b);
  }
  const R = {};
  function tone(c, out, t, o) { // {f,f2,type,dur,vol,a,det}
    const os = c.createOscillator(), g = c.createGain(); os.type = o.type || 'sine';
    os.frequency.setValueAtTime(o.f, t); if (o.f2) os.frequency.exponentialRampToValueAtTime(o.f2, t + (o.dur || .2));
    if (o.det) os.detune.value = o.det;
    const a = o.a || .005, v = o.vol || .2, d = o.dur || .2;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    os.connect(g); g.connect(out); os.start(t); os.stop(t + d + .05); return g;
  }
  function burst(c, out, t, o) { // filtered noise {dur,vol,type,f,q,f2}
    const s = c.createBufferSource(); s.buffer = noise(c); const f = c.createBiquadFilter(), g = c.createGain();
    f.type = o.type || 'bandpass'; f.frequency.setValueAtTime(o.f || 1000, t); if (o.f2) f.frequency.exponentialRampToValueAtTime(o.f2, t + o.dur); f.Q.value = o.q || 1;
    const a = o.a || .003; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(o.vol || .3, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    s.connect(f); f.connect(g); g.connect(out); s.start(t, (t * 7.13) % 1); s.stop(t + o.dur + .05);
  }
  function swell(c, out, t, dur, vol, lo, hi) { // crowd roar: noise with slow attack/decay
    const s = c.createBufferSource(); s.buffer = noise(c); s.loop = true; const f = c.createBiquadFilter(), g = c.createGain();
    f.type = 'bandpass'; f.frequency.value = lo; f.Q.value = .7;
    const f2 = c.createBiquadFilter(); f2.type = 'highpass'; f2.frequency.value = hi;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + dur * .25); g.gain.setValueAtTime(vol, t + dur * .45); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(f2); f2.connect(g); g.connect(out); s.start(t); s.stop(t + dur + .05);
  }
  function whistleBlast(c, out, t, dur, base) {
    const os = c.createOscillator(), os2 = c.createOscillator(), lfo = c.createOscillator(), lg = c.createGain(), g = c.createGain();
    os.type = 'sine'; os2.type = 'sine'; os.frequency.value = base; os2.frequency.value = base * 1.12; lfo.frequency.value = 32; lg.gain.value = .06;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(.16, t + .02); g.gain.setValueAtTime(.16, t + dur - .04); g.gain.linearRampToValueAtTime(0.0001, t + dur);
    lfo.connect(lg); lg.connect(g.gain); os.connect(g); os2.connect(g); g.connect(out);
    [os, os2, lfo].forEach(x => { x.start(t); x.stop(t + dur + .05); });
    burst(c, out, t, { dur: dur, vol: .03, f: 5200, q: 3 });
  }
  const NOTE = (n) => 440 * Math.pow(2, (n - 69) / 12);
  /* ---- match ---- */
  R.pass = (c, o, t) => { tone(c, o, t, { f: 170, f2: 80, dur: .09, vol: .28 }); burst(c, o, t, { dur: .04, vol: .18, f: 700, type: 'lowpass' }); };
  R.shot = (c, o, t) => { tone(c, o, t, { f: 240, f2: 50, dur: .16, vol: .42, type: 'triangle' }); burst(c, o, t, { dur: .07, vol: .38, f: 1600, q: .8 }); burst(c, o, t + .02, { dur: .18, vol: .1, f: 400, type: 'lowpass' }); };
  R.tackle = (c, o, t) => { tone(c, o, t, { f: 110, f2: 40, dur: .14, vol: .35 }); burst(c, o, t, { dur: .09, vol: .3, f: 500, type: 'lowpass' }); };
  R.save = (c, o, t) => { burst(c, o, t, { dur: .06, vol: .45, f: 2600, q: 1.2 }); tone(c, o, t, { f: 140, f2: 70, dur: .12, vol: .3 }); tone(c, o, t + .06, { f: 880, dur: .1, vol: .08, type: 'triangle' }); };
  R.post = (c, o, t) => { [1, 2.76, 5.4].forEach((m, i) => tone(c, o, t, { f: 1250 * m, dur: .5 / (i + 1), vol: .22 / (i + 1) })); burst(c, o, t, { dur: .05, vol: .3, f: 3000, q: 2 }); };
  R.whistle = (c, o, t) => { whistleBlast(c, o, t, .32, 2900); };
  R.whistle_end = (c, o, t) => { whistleBlast(c, o, t, .22, 2900); whistleBlast(c, o, t + .32, .22, 2900); whistleBlast(c, o, t + .64, .7, 2900); swell(c, o, t + .6, 2.4, .07, 700, 250); };
  R.crowd = (c, o, t) => { swell(c, o, t, 1.8, .16, 800, 300); };
  R.goal = (c, o, t) => { swell(c, o, t, 3.4, .22, 900, 280); swell(c, o, t + .05, 3.0, .1, 2200, 900);[0, 4, 7].forEach(s => tone(c, o, t, { f: NOTE(57 + s), dur: 1.0, vol: .07, type: 'sawtooth', a: .03 })); tone(c, o, t + .5, { f: NOTE(72), dur: .7, vol: .08, type: 'square' }); whistleBlast(c, o, t + .05, .3, 3000); };
  R.groan = (c, o, t) => { swell(c, o, t, 1.4, .1, 500, 200); tone(c, o, t, { f: 300, f2: 150, dur: .9, vol: .05, type: 'sawtooth' }); };
  /* ---- UI / rewards ---- */
  R.pop = (c, o, t) => { tone(c, o, t, { f: 620, f2: 940, dur: .08, vol: .16, type: 'triangle' }); };
  R.error = (c, o, t) => { tone(c, o, t, { f: 130, dur: .13, vol: .2, type: 'square' }); tone(c, o, t + .16, { f: 98, dur: .22, vol: .2, type: 'square' }); };
  R.coin = (c, o, t) => { tone(c, o, t, { f: 1319, dur: .1, vol: .22, type: 'square' }); tone(c, o, t + .08, { f: 1760, dur: .35, vol: .2, type: 'square' }); };
  R.reward = (c, o, t) => { [72, 76, 79, 84].forEach((n, i) => tone(c, o, t + i * .07, { f: NOTE(n), dur: .3, vol: .17, type: 'triangle' })); tone(c, o, t + .3, { f: NOTE(91), dur: .5, vol: .09 }); };
  R.cash = (c, o, t) => { burst(c, o, t, { dur: .05, vol: .3, f: 4000, q: 2 }); tone(c, o, t + .06, { f: 2093, dur: .5, vol: .18 }); tone(c, o, t + .14, { f: 3136, dur: .6, vol: .16 }); };
  R.tick = (c, o, t) => { tone(c, o, t, { f: 1500, f2: 900, dur: .035, vol: .22, type: 'square' }); };
  R.wheel_win = (c, o, t) => { [60, 64, 67, 72, 76].forEach((n, i) => tone(c, o, t + i * .09, { f: NOTE(n), dur: .5, vol: .16, type: 'triangle' })); burst(c, o, t + .4, { dur: .6, vol: .08, f: 7000, q: 4 }); };
  R.pack = (c, o, t) => { burst(c, o, t, { dur: 1.5, vol: .22, type: 'lowpass', f: 200, f2: 5000, a: 1.2 }); tone(c, o, t, { f: 120, f2: 900, dur: 1.5, vol: .12, type: 'sawtooth', a: .8 }); };
  R.whoosh = (c, o, t) => { burst(c, o, t, { dur: .5, vol: .3, f: 600, f2: 6000, q: .6, a: .08 }); };
  R.card = (c, o, t) => { [1568, 2093, 2637].forEach((f, i) => tone(c, o, t + i * .06, { f, dur: .35, vol: .13 })); burst(c, o, t, { dur: .12, vol: .1, f: 6000, q: 3 }); };
  R.rare = (c, o, t) => { R.card(c, o, t); [0, 4, 7, 12].forEach((s, i) => tone(c, o, t + .15 + i * .08, { f: NOTE(64 + s), dur: .6, vol: .1, type: 'sawtooth' })); swell(c, o, t + .1, 1.6, .08, 1500, 500); };
  R.legend = (c, o, t) => { R.rare(c, o, t); R.goal(c, o, t + .2); [76, 79, 83, 88].forEach((n, i) => tone(c, o, t + .5 + i * .1, { f: NOTE(n), dur: .9, vol: .1, type: 'triangle' })); };
  R.levelup = (c, o, t) => { [60, 64, 67, 72, 79].forEach((n, i) => tone(c, o, t + i * .08, { f: NOTE(n), dur: .4, vol: .16, type: 'square' })); tone(c, o, t + .45, { f: NOTE(84), dur: .7, vol: .12, type: 'triangle' }); };
  R.upgrade = (c, o, t) => { for (let i = 0; i < 3; i++) { burst(c, o, t + i * .16, { dur: .08, vol: .4, f: 1800, q: 1 }); tone(c, o, t + i * .16, { f: 160, f2: 60, dur: .1, vol: .35 }); } R.levelup(c, o, t + .55); swell(c, o, t + .6, 2.2, .12, 900, 300); };
  R.win = (c, o, t) => { [67, 72, 76, 79, 84].forEach((n, i) => tone(c, o, t + i * .11, { f: NOTE(n), dur: .45, vol: .17, type: 'square' })); [60, 64, 67].forEach(s => tone(c, o, t + .55, { f: NOTE(s), dur: .9, vol: .1, type: 'triangle' })); swell(c, o, t + .2, 2.2, .1, 900, 300); };
  R.lose = (c, o, t) => { [64, 62, 59, 55].forEach((n, i) => tone(c, o, t + i * .22, { f: NOTE(n), dur: .5, vol: .16, type: 'triangle' })); swell(c, o, t, 1.4, .05, 500, 200); };
  R.draw = (c, o, t) => { [64, 64, 62].forEach((n, i) => tone(c, o, t + i * .18, { f: NOTE(n), dur: .35, vol: .14, type: 'triangle' })); };
  /* ---- ambience (stadium murmur during a live match) ---- */
  function ambStart() {
    try { if (muted() || amb) return; const c = init(), s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain(), lfo = c.createOscillator(), lg = c.createGain();
      s.buffer = noise(c); s.loop = true; f.type = 'bandpass'; f.frequency.value = 520; f.Q.value = .5; g.gain.value = .035; lfo.frequency.value = .22; lg.gain.value = .012;
      lfo.connect(lg); lg.connect(g.gain); s.connect(f); f.connect(g); g.connect(master); s.start(); lfo.start(); amb = { s, g, lfo }; } catch (_) {}
  }
  function ambStop() { try { if (!amb) return; const a = amb; amb = null; a.g.gain.setTargetAtTime(0, ctx.currentTime, .15); setTimeout(() => { try { a.s.stop(); a.lfo.stop(); } catch (_) {} }, 700); } catch (_) {} }
  function ambSwell() { try { if (!amb || muted()) return; const t = ctx.currentTime; amb.g.gain.cancelScheduledValues(t); amb.g.gain.setTargetAtTime(.09, t, .08); amb.g.gain.setTargetAtTime(.035, t + .7, .6); } catch (_) {} }
  /* ---- public ---- */
  let lastUi = 0;
  function play(name, delay) {
    try { if (muted() || !R[name]) return;
      if (name === 'pop' || name === 'error') { const n = Date.now(); if (n - lastUi < 200) return; lastUi = n; } const c = init(); R[name](c, master, c.currentTime + (delay || 0) + .005); } catch (_) {}
  }
  function wheel(sec) { // decelerating ticks that match the 4 s wheel spin
    try { if (muted()) return; const c = init(), t0 = c.currentTime; let t = 0, gap = .045; while (t < sec - .15) { R.tick(c, master, t0 + t); t += gap; gap *= 1.085; } setTimeout(() => play('wheel_win'), sec * 1000 + 80); } catch (_) {}
  }
  document.addEventListener('pointerdown', () => { try { if (!muted()) init(); } catch (_) {} }, { passive: true, capture: true });
  window.FFMSfx = { play, wheel, ambStart, ambStop, swell: ambSwell, names: Object.keys(R), _R: R, _init: init };

  /* ---- hook UI helpers ---- */
  const wrap = (name, fn) => { const o = window[name]; if (typeof o === 'function') window[name] = function () { try { fn.apply(this, arguments); } catch (_) {} return o.apply(this, arguments); }; };
  wrap('ffmShort', () => play('error'));
  wrap('ffmDialog', () => play('pop'));
  wrap('ffmConfirm', () => play('pop'));
  wrap('stJoin', () => play('card'));
  wrap('stMerge', () => play('levelup'));
  wrap('stExchange', () => play('cash'));
  wrap('engSpin', () => {});
  /* match result jingle (after the result popup is filled) */
  const _sm = window.startMatchSimulation;
  if (typeof _sm === 'function') window.startMatchSimulation = function () {
    const r = _sm.apply(this, arguments);
    try { const pop = document.getElementById('result-popup'); if (pop && pop.style.display === 'flex') { const m = String(document.getElementById('popup-score').innerText).match(/(\d+)\D+(\d+)/); if (m) setTimeout(() => play(+m[1] > +m[2] ? 'win' : +m[1] < +m[2] ? 'lose' : 'draw'), 250); } } catch (_) {}
    return r;
  };
})();
