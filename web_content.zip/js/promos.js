/**
 * Promo injection for cached pages.
 *
 * Post pages and /download/ pages sit behind LiteSpeed and a Cloudflare edge
 * cache, so their HTML carries only empty containers. The creative comes from a
 * small static file that wp-admin rewrites on save — editing a promo costs a
 * two-URL purge instead of a site-wide one.
 *
 * Nodes are built with the DOM API rather than innerHTML: the payload is
 * editor-supplied, and this keeps a stray tag in a title from becoming markup.
 */
(function () {
    'use strict';

    var config = window.liteapksPromos || {};

    var floatHost = document.getElementById('promo-single-float');

    // Container id -> key in the payload. Post pages and download pages each
    // get their own store banner with independent content and switches.
    var STORE_HOSTS = {
        'promo-single-store': 'single_store',
        'promo-download-store': 'download_store'
    };

    // Container id -> [payload key, GA promotion id]. The row on post pages
    // keeps the promotion id it shipped with so its GA history stays one
    // series; the download rows are new and name themselves.
    var GEO_HOSTS = {
        'promo-single-geo': ['single_geo', 'geo_reco'],
        'promo-download-top': ['download_top', 'download_top_reco'],
        'promo-download-popular': ['download_popular', 'download_popular_reco']
    };

    var storeHosts = [];
    Object.keys(STORE_HOSTS).forEach(function (id) {
        var node = document.getElementById(id);
        if (node) {
            storeHosts.push({ node: node, key: STORE_HOSTS[id] });
        }
    });

    var geoHosts = [];
    Object.keys(GEO_HOSTS).forEach(function (id) {
        var node = document.getElementById(id);
        if (node) {
            geoHosts.push({ node: node, key: GEO_HOSTS[id][0], promoId: GEO_HOSTS[id][1] });
        }
    });

    var DISMISS_KEY = 'liteapks_promo_float_dismissed_until';

    /**
     * Tag a placement container and its clickable item for mole.
     *
     * The SDK reads nothing but these attributes, so injected placements are
     * indistinguishable from server-rendered ones as far as reporting goes.
     * A missing slot id simply means this placement reports nothing.
     */
    function moleTag(host, slotId) {
        if (host && slotId) {
            host.setAttribute('data-mole', slotId);
        }
    }

    function moleItem(node, creative, index) {
        if (node && creative) {
            node.setAttribute('data-mole-creative', creative);
            node.setAttribute('data-mole-index', index || 0);
        }
    }

    /** GA4 event helper; a no-op when gtag has not loaded. */
    function track(name, params) {
        try {
            if (typeof window.gtag === 'function') {
                window.gtag('event', name, params || {});
            }
        } catch (e) {
            /* analytics must never break a placement */
        }
    }

    /** Fire view_promotion the first time a node scrolls into view. */
    function trackView(node, params) {
        if (!('IntersectionObserver' in window)) {
            return;
        }
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    track('view_promotion', params);
                    io.disconnect();
                }
            });
        });
        io.observe(node);
    }

    /**
     * Append a download token, same scheme as site.js: the worker gate rejects
     * a bare link with 403. Computed at render time rather than baked into the
     * payload, which would expire in the cache.
     */
    function tokenized(url) {
        try {
            var ttl = Math.floor(Date.now() / 1000) + 3600 * 3;
            var u = new URL(url, window.location.href);
            if (!u.searchParams.has('token')) {
                u.searchParams.set('token', btoa(btoa(ttl)));
            }
            return u.toString();
        } catch (e) {
            return url;
        }
    }

    /**
     * Wire up the placements the server already rendered (homepage).
     *
     * Two things cannot be baked into cached HTML: a download token, which
     * expires, and the click event. Everything else is already in the markup.
     */
    (function hydrateServerRendered() {
        var links = document.querySelectorAll('.promo-store.is-loaded .promo-store__link');

        Array.prototype.forEach.call(links, function (a) {
            if (a.hasAttribute('data-promo-tokenize')) {
                a.href = tokenized(a.href);
            }

            var title = a.querySelector('.promo-store__title');
            var event = {
                promotion_id: 'home_store',
                promotion_name: title ? title.textContent : 'App store',
                creative_slot: 'home_store'
            };

            a.addEventListener('click', function () {
                track('select_promotion', event);
            });

            trackView(a, event);
        });
    })();

    /**
     * Has the visitor closed the floating promo recently?
     *
     * The stored record is tied to the promo version. Any edit in wp-admin bumps
     * that version, which retires every visitor's dismissal — a new creative
     * should get seen, and an editor changing the settings must not be stuck
     * looking at their own stale "closed" state from an earlier one.
     */
    function isDismissed(version) {
        try {
            var raw = window.localStorage.getItem(DISMISS_KEY);
            if (!raw) {
                return false;
            }

            var rec = null;
            try {
                rec = JSON.parse(raw);
            } catch (e) {
                /* pre-versioning format: a bare timestamp */
            }

            if (!rec || rec.v !== version) {
                window.localStorage.removeItem(DISMISS_KEY);
                return false;
            }

            return rec.until > Date.now();
        } catch (e) {
            // Private mode or storage disabled — show the promo rather than hide it.
            return false;
        }
    }

    function rememberDismissal(hours, version) {
        // 0 hours means "do not remember at all": it reappears on the next view.
        if (!hours) {
            return;
        }
        try {
            window.localStorage.setItem(DISMISS_KEY, JSON.stringify({
                until: Date.now() + hours * 3600 * 1000,
                v: version
            }));
        } catch (e) {
            /* nothing we can do; the promo simply reappears next page view */
        }
    }

    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }
        if (text) {
            node.textContent = text;
        }
        return node;
    }

    function link(url, newTab, className) {
        var a = el('a', className);
        a.href = url;
        // Our own placements, so no rel="sponsored" — flagging our own links as
        // paid placement only hurts us in search.
        a.rel = newTab ? 'noopener' : '';
        if (newTab) {
            a.target = '_blank';
        }
        return a;
    }

    function chevron() {
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
        svg.setAttribute('stroke-width', '2');
        svg.setAttribute('class', 'promo-store__chevron');
        svg.setAttribute('aria-hidden', 'true');
        var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('stroke-linecap', 'round');
        path.setAttribute('stroke-linejoin', 'round');
        path.setAttribute('d', 'M9 5l7 7-7 7');
        svg.appendChild(path);
        return svg;
    }

    function star() {
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'currentColor');
        svg.setAttribute('class', 'promo-geo__star');
        svg.setAttribute('aria-hidden', 'true');
        var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z');
        svg.appendChild(path);
        return svg;
    }

    /**
     * The app-store card, same shape as template-parts/promos/store-card.php.
     */
    function renderStore(host, card, slot, moleSlot) {
        // Never advertise an app on its own page.
        if (card.app_id && String(card.app_id) === host.dataset.postId) {
            return;
        }

        var href = card.tokenize ? tokenized(card.url) : card.url;
        var a = link(href, card.new_tab, 'promo-store__link');

        if (card.icon) {
            var img = el('img', 'promo-store__icon');
            img.src = card.icon;
            img.alt = card.title || '';
            img.width = 48;
            img.height = 48;
            img.loading = 'lazy';
            img.decoding = 'async';
            a.appendChild(img);
        }

        var body = el('div', 'promo-store__body');
        if (card.title) {
            body.appendChild(el('p', 'promo-store__title', card.title));
        }
        if (card.desc) {
            body.appendChild(el('p', 'promo-store__desc', card.desc));
        }
        a.appendChild(body);

        var btn = el('span', 'promo-store__btn', card.btn_text || 'Get');
        btn.appendChild(chevron());
        a.appendChild(btn);

        var event = {
            promotion_id: slot,
            promotion_name: card.title || 'App store',
            creative_slot: slot
        };

        a.addEventListener('click', function () {
            track('select_promotion', event);
        });

        moleTag(host, moleSlot);
        moleItem(a, card.mole, 0);

        host.appendChild(a);
        host.classList.add('is-loaded');
        trackView(host, event);
    }

    /**
     * The hand-picked recommendation row. Three placements use it: one on post
     * pages and one on each download view, each with its own payload entry.
     *
     * Country comes from the front zone's /cdn-cgi/trace, which reports the
     * visitor's real country regardless of how many zones the request passes
     * through. It is a separate request rather than a server-side lookup
     * because a single cached page has to serve every country.
     */
    function renderGeo(host, data, moleSlot, promoId) {
        var currentId = host.dataset.postId || '';

        function paint(country) {
            var lists = data.by_country || {};
            var items = (country && lists[country] && lists[country].length)
                ? lists[country]
                : (data['default'] || []);

            items = items.filter(function (item) {
                return String(item.id) !== String(currentId);
            });

            if (!items.length) {
                return;
            }

            var head = el('div', 'promo-geo__head');
            head.appendChild(star());
            head.appendChild(el('h2', 'promo-geo__title', data.title || 'Recommended for you'));
            host.appendChild(head);

            var subtitle = (data.subtitle || '').replace('{app}', host.dataset.app || '');
            if (subtitle) {
                host.appendChild(el('p', 'promo-geo__sub', subtitle));
            }

            var track_ = el('div', 'promo-geo__track');

            items.forEach(function (item, index) {
                var a = link(item.url, false, 'promo-geo__card');

                var thumb = el('span', 'promo-geo__thumb');
                if (item.icon) {
                    var img = el('img');
                    img.src = item.icon;
                    img.alt = item.name || '';
                    img.width = 64;
                    img.height = 64;
                    img.loading = 'lazy';
                    img.decoding = 'async';
                    thumb.appendChild(img);
                }
                if (item.badge) {
                    thumb.appendChild(el(
                        'span',
                        'promo-geo__badge promo-geo__badge--' + String(item.badge).toLowerCase(),
                        item.badge
                    ));
                }
                a.appendChild(thumb);

                a.appendChild(el('span', 'promo-geo__name', item.name || ''));

                if (item.rating) {
                    var rating = el('span', 'promo-geo__rating', String(item.rating));
                    rating.appendChild(star());
                    a.appendChild(rating);
                }

                // On-site apps carry their post id, so the creative code needs
                // no lookup: it is the same 'a{id}' the server would emit.
                moleItem(a, 'a' + item.id, index);

                a.addEventListener('click', function () {
                    track('select_promotion', {
                        promotion_id: promoId,
                        promotion_name: data.title || 'Recommended for you',
                        creative_slot: promoId + '_' + (country || 'XX'),
                        country: country,
                        items: [{
                            item_id: String(item.id),
                            item_name: item.name,
                            index: index
                        }]
                    });
                });

                track_.appendChild(a);
            });

            host.appendChild(track_);
            moleTag(host, moleSlot);
            host.classList.add('is-loaded');

            trackView(host, {
                promotion_id: promoId,
                promotion_name: data.title || 'Recommended for you',
                creative_slot: promoId + '_' + (country || 'XX'),
                country: country,
                items: items.map(function (item, index) {
                    return { item_id: String(item.id), item_name: item.name, index: index };
                })
            });

            // This row paints only once /cdn-cgi/trace answers, which is later
            // than the mole.scan() at the end of the payload handler — that scan
            // ran while this container still had no data-mole, so its impression
            // would never be observed. scan() is idempotent (it marks what it
            // already bound), so calling it again here is free. Clicks were never
            // affected: those ride a delegated listener on the document.
            if (window.mole) {
                window.mole.scan();
            }
        }

        // No Cloudflare in front of the dev box, so this 404s there and the
        // default list is used — which is the intended fallback anyway.
        fetch('/cdn-cgi/trace', { credentials: 'omit' })
            .then(function (res) {
                return res.ok ? res.text() : '';
            })
            .then(function (text) {
                var match = /(?:^|\n)loc=([A-Za-z]{2})/.exec(text);
                paint(match ? match[1].toUpperCase() : '');
            })
            .catch(function () {
                paint('');
            });
    }

    /**
     * The dismissible floating icon bubble on post pages.
     *
     * Deliberately just an icon — same shape on desktop and mobile, anchored to
     * the bottom-right corner rather than stretched across the bottom edge.
     * The title rides along as the tooltip / accessible name.
     */
    function renderFloat(host, card, version, moleSlot) {
        if (isDismissed(version)) {
            return;
        }

        // Never advertise the page the visitor is already on.
        try {
            if (new URL(card.url, window.location.href).pathname === window.location.pathname) {
                return;
            }
        } catch (e) {
            /* unparseable URL: fall through and render it as given */
        }

        var box = el('div', 'promo-float__box');

        var a = link(card.url, card.new_tab, 'promo-float__link');
        if (card.title) {
            a.setAttribute('title', card.title);
            a.setAttribute('aria-label', card.title);
        }

        if (card.image) {
            var img = el('img', 'promo-float__image');
            img.src = card.image;
            img.alt = card.title || '';
            img.loading = 'lazy';
            img.decoding = 'async';
            a.appendChild(img);
        }

        var event = {
            promotion_id: 'single_float',
            promotion_name: card.title || 'Floating',
            creative_slot: 'single_float'
        };

        a.addEventListener('click', function () {
            track('select_promotion', event);
        });

        box.appendChild(a);

        var close = el('button', 'promo-float__close');
        close.type = 'button';
        close.setAttribute('aria-label', 'Close');
        close.textContent = '×';
        close.addEventListener('click', function () {
            // Report the dismissal before tearing the node down - a placement
            // people keep closing is worth knowing about.
            if (window.mole && moleSlot) {
                window.mole.event(moleSlot, 'x', card.mole, 0);
            }
            host.classList.remove('is-loaded');
            host.innerHTML = '';
            rememberDismissal(card.dismiss_hours, version);
        });
        box.appendChild(close);

        moleTag(host, moleSlot);
        moleItem(a, card.mole, 0);

        host.appendChild(box);
        host.classList.add('is-loaded');
        trackView(host, event);
    }

    function allowed(host) {
        return host && host.dataset.promoAllowed !== '0';
    }

    // Nothing on this page is filled from the payload — the homepage only needs
    // the hydration above.
    if (!config.json_url || (!floatHost && !geoHosts.length && !storeHosts.length)) {
        return;
    }

    // cache: 'no-cache' makes the browser revalidate instead of trusting its own
    // copy. The origin sends a long max-age for uploads/, and a Cloudflare purge
    // cannot reach a browser cache — without revalidation a returning visitor
    // could keep seeing a retired creative for days. Revalidating costs one
    // conditional request that the edge answers with a 304.
    fetch(config.json_url, { credentials: 'omit', cache: 'no-cache' })
        .then(function (res) {
            return res.ok ? res.json() : null;
        })
        .then(function (data) {
            if (!data) {
                return;
            }

            var mole = data.mole || {};

            storeHosts.forEach(function (entry) {
                if (allowed(entry.node) && data[entry.key]) {
                    renderStore(entry.node, data[entry.key], entry.key, mole[entry.key]);
                }
            });

            geoHosts.forEach(function (entry) {
                if (allowed(entry.node) && data[entry.key]) {
                    renderGeo(entry.node, data[entry.key], mole[entry.key], entry.promoId);
                }
            });

            if (allowed(floatHost) && data.single_float) {
                renderFloat(floatHost, data.single_float, data.version, mole.single_float);
            }

            // These containers did not exist when the SDK first scanned the page.
            if (window.mole) {
                window.mole.scan();
            }
        })
        .catch(function () {
            /* A missing or unreachable promo file must never break the page. */
        });
})();
