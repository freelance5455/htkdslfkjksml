// ======================================================
// PEMBAYARAN FAKTUR
// ======================================================


// ======================================================
// FORMAT RUPIAH
// ======================================================

function formatRupiahBayar(angka) {

    return "Rp " +
        Number(angka || 0)
        .toLocaleString("id-ID");

}


// ======================================================
// AMBIL FAKTUR
// ======================================================

function ambilFakturBayar() {

    const parameter =
        new URLSearchParams(
            window.location.search
        );

    let id =
        parameter.get("faktur");


    if (!id) {

        id =
            localStorage.getItem(
                "fakturDetailId"
            );

    }


    const data =
        JSON.parse(
            localStorage.getItem(
                "dataFaktur"
            ) || "[]"
        );


    return data.find(function(f) {

        return String(f.id) === String(id);

    });

}


// ======================================================
// TAMPILKAN FORM
// ======================================================

function tampilkanPembayaran() {

    const container =
        document.getElementById(
            "formPembayaran"
        );


    const faktur =
        ambilFakturBayar();


    if (!faktur) {

        container.innerHTML = `
            <div class="bayar-card">
                ❌ Faktur tidak ditemukan.
            </div>
        `;

        return;

    }


    const total =
        Number(faktur.total || 0);

    const retur =
        Number(faktur.totalRetur || 0);

    const dibayar =
        Number(faktur.totalDibayar || 0);


    const sisa =
        Math.max(
            0,
            total - retur - dibayar
        );


    if (sisa <= 0) {

        container.innerHTML = `

            <div class="bayar-card">

                <h2>🟢 Faktur sudah lunas</h2>

                <p>
                    Faktur
                    <strong>${faktur.nomor}</strong>
                    sudah tidak memiliki sisa pembayaran.
                </p>

                <button
                    class="tombol-bayar-kembali"
                    onclick="history.back()">

                    ← Kembali

                </button>

            </div>

        `;

        return;

    }


    container.innerHTML = `

        <div class="bayar-card">

            <h2>${faktur.nomor}</h2>

            <div class="bayar-info">

                <div class="bayar-row">
                    <span>Distributor</span>
                    <strong>
                        ${faktur.distributorNama || "-"}
                    </strong>
                </div>

                <div class="bayar-row">
                    <span>Total Faktur</span>
                    <strong>
                        ${formatRupiahBayar(total)}
                    </strong>
                </div>

                <div class="bayar-row">
                    <span>Total Retur</span>
                    <strong>
                        ${formatRupiahBayar(retur)}
                    </strong>
                </div>

                <div class="bayar-row">
                    <span>Sudah Dibayar</span>
                    <strong>
                        ${formatRupiahBayar(dibayar)}
                    </strong>
                </div>

            </div>


            <div class="bayar-sisa">

                <div>Sisa yang harus dibayar</div>

                <strong>
                    ${formatRupiahBayar(sisa)}
                </strong>

            </div>


            <div class="form-bayar">

                <label>
                    Jumlah Pembayaran
                </label>

                <input
                    type="number"
                    id="jumlahBayar"
                    min="1"
                    max="${sisa}"
                    placeholder="Masukkan jumlah"
                >


                <label>
                    Keterangan
                </label>

                <textarea
                    id="keteranganBayar"
                    rows="3"
                    placeholder="Contoh: Transfer BCA / Tunai"
                ></textarea>


                <button
                    class="tombol-bayar-simpan"
                    onclick="simpanPembayaran()">

                    💰 Simpan Pembayaran

                </button>


                <button
                    class="tombol-bayar-kembali"
                    onclick="history.back()">

                    ← Batal

                </button>

            </div>

        </div>

    `;

}


// ======================================================
// SIMPAN PEMBAYARAN
// ======================================================

function simpanPembayaran() {

    const faktur =
        ambilFakturBayar();


    if (!faktur) {

        alert("Faktur tidak ditemukan.");

        return;

    }


    const input =
        document.getElementById(
            "jumlahBayar"
        );


    const keterangan =
        document.getElementById(
            "keteranganBayar"
        ).value.trim();


    const jumlah =
        Number(input.value);


    const total =
        Number(faktur.total || 0);

    const retur =
        Number(faktur.totalRetur || 0);

    const dibayar =
        Number(faktur.totalDibayar || 0);


    const sisa =
        Math.max(
            0,
            total - retur - dibayar
        );


    if (!jumlah || jumlah <= 0) {

        alert(
            "Jumlah pembayaran harus lebih dari 0."
        );

        return;

    }


    if (jumlah > sisa) {

        alert(
            "Pembayaran tidak boleh melebihi sisa."
        );

        return;

    }


    // ==============================================
    // RIWAYAT PEMBAYARAN
    // ==============================================

    if (!faktur.riwayatPembayaran) {

        faktur.riwayatPembayaran = [];

    }


    const sekarang =
        new Date();


    faktur.riwayatPembayaran.push({

        id: Date.now(),

        tanggal:
            sekarang
            .toISOString()
            .split("T")[0],

        waktu:
            sekarang.toLocaleTimeString(
                "id-ID"
            ),

        jumlah: jumlah,

        keterangan:
            keterangan || "-"

    });


    // ==============================================
    // TOTAL DIBAYAR
    // ==============================================

    faktur.totalDibayar =
        dibayar + jumlah;


    // ==============================================
    // HITUNG SISA
    // ==============================================

    faktur.sisa =
        Math.max(
            0,
            total -
            Number(faktur.totalRetur || 0) -
            faktur.totalDibayar
        );


    // ==============================================
    // STATUS
    // ==============================================

    if (faktur.sisa <= 0) {

        faktur.status = "lunas";

    }

    else if (faktur.totalDibayar > 0) {

        faktur.status = "sebagian";

    }

    else {

        faktur.status = "belum";

    }


    // ==============================================
    // SIMPAN
    // ==============================================

    let dataFaktur =
        JSON.parse(
            localStorage.getItem(
                "dataFaktur"
            ) || "[]"
        );


    const index =
        dataFaktur.findIndex(function(f) {

            return String(f.id) ===
                String(faktur.id);

        });


    if (index === -1) {

        alert("Data faktur tidak ditemukan.");

        return;

    }


    dataFaktur[index] =
        faktur;


    localStorage.setItem(
        "dataFaktur",
        JSON.stringify(dataFaktur)
    );


    alert(
        "Pembayaran berhasil disimpan."
    );


    // Kembali ke detail faktur
    localStorage.setItem(
        "fakturDetailId",
        faktur.id
    );


    location.href =
        "detail-faktur.html";

}


// ======================================================
// JALANKAN
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    tampilkanPembayaran
);