/* زمان‌سنج مطالعه و کلاس (با شروع و توقف و ادامه)، ورود زمان از گفتار، و هشدار حافظه‌ی پرِ مرورگر. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var S = function () { return App.S; };
  var timer = (App.timer = {});
  var iv = null;
  var MAX_MIN = 180;

  timer.running = function () { return !!(S().tm && S().tm.st > 0); };
  // زمان جمع‌شده به میلی‌ثانیه (شروع ثبت‌شده با Date.now است؛ با بسته شدن برنامه هم درست می‌ماند)
  timer.elapsed = function () {
    var t = S().tm;
    return (t.acc || 0) + (t.st ? Math.max(0, Date.now() - t.st) : 0);
  };
  timer.clock = function (ms) {
    var s = Math.floor(ms / 1000);
    return u.pd(u.p2(Math.floor(s / 3600)) + ':' + u.p2(Math.floor((s % 3600) / 60)) + ':' + u.p2(s % 60));
  };
  timer.tick = function () {
    var c = document.getElementById('clk');
    if (c) c.textContent = timer.clock(timer.elapsed());
    timer.pill();
  };
  timer.startTick = function () {
    if (iv) return;
    iv = setInterval(function () {
      if (!timer.running()) { timer.stopTick(); timer.pill(); return; }
      timer.tick();
    }, 1000);
  };
  timer.stopTick = function () { if (iv) clearInterval(iv); iv = null; };
  // نشانگر شناور وقتی تایمر روشن است و کاربر در تب تایمر نیست
  timer.pill = function () {
    var p = document.getElementById('tpill');
    if (!p) return;
    var on = timer.running() && App.ui.tab !== 'timer';
    p.hidden = !on;
    if (on) p.textContent = (S().tm.k === 'c' ? '🏫 ' : '⏱ ') + timer.clock(timer.elapsed()) + ' · در حال شمارش';
  };
  timer.boot = function () {
    if (timer.running()) timer.startTick();
    timer.pill();
  };

  timer.toggle = function () {
    var t = S().tm;
    if (t.st) { t.acc = timer.elapsed(); t.st = 0; timer.stopTick(); }
    else { t.st = Date.now(); timer.startTick(); }
    App.save();
    App.render();
  };

  // پایان و ثبت: اگر زمان بیشتر از ۱۸۰ دقیقه بود، اول مدت درست پرسیده می‌شود
  timer.finish = function () {
    var t = S().tm;
    if (!t.st && !t.acc) { App.toast('تایمر روشن نیست'); return; }
    var m = Math.round(timer.elapsed() / 60000);
    if (m > MAX_MIN) { timer.askCorrection(m); return; }
    timer.commit(m);
  };
  timer.askCorrection = function (m) {
    App.openModal('تایمر ' + u.fa(m) + ' دقیقه شده', '<p class="mu">اگر اشتباه است، مدت درست را به دقیقه وارد کن. اگر انصراف بدهی، تایمر همچنان روشن می‌ماند.</p>' +
      '<div class="field"><label for="tm-fix">مدت درست (دقیقه)</label><input id="tm-fix" type="text" inputmode="numeric" value="' + u.esc(u.pd(m)) + '" autocomplete="off"></div>' +
      '<div class="row0 wrap"><button type="button" class="btn" data-act="tm-fix-ok">ثبت</button><button type="button" class="sm" data-act="close-modal">انصراف</button></div>');
  };
  App.act['tm-fix-ok'] = function () {
    var el = document.getElementById('tm-fix');
    var v = u.int(el ? el.value : '', 0, 1440, null);
    if (v == null) { App.alert('عدد درست (بین ۰ تا ۱۴۴۰) را وارد کن'); return; }
    timer.commit(v);
  };

  // ثبت نهایی: یک ثبت مطالعه/کلاس با زمان جمع‌شده؛ تایمر خالی می‌شود
  timer.commit = function (m) {
    var t = S().tm, kind = t.k, f = App.form('tmf', { q: 0 });
    timer.stopTick();
    var rec = null;
    if (m > 0) {
      rec = st.addLog({ g: t.g || S().mg, s: t.s || '', c: t.c || 0, m: m, t: 0, k: kind === 'c' ? 'c' : undefined, d: u.todayISO(), q: +f.q || undefined });
    }
    S().tm = { acc: 0, st: 0, k: kind, g: t.g, s: t.s, c: t.c };
    f.q = 0;
    App.save();
    App.closeModal();
    App.go('today');
    if (rec) {
      App.toast('✅ ' + u.hm(m) + ' ' + (kind === 'c' ? 'کلاس' : 'مطالعه') + ' ثبت شد', {
        ms: 6000, action: { label: '↩️ برگردان', fn: function () { st.delLog(rec.id); App.save(); App.render(); } }
      });
    } else {
      App.toast('زمانی برای ثبت نبود');
    }
  };

  App.act['tm-toggle'] = function () { timer.toggle(); };
  App.act['tm-finish'] = function () { timer.finish(); };
  App.act['tm-reset'] = function () {
    var t = S().tm;
    if (!t.st && !t.acc) return;
    if (!App.confirm('زمان جمع‌شده پاک شود؟ چیزی ثبت نمی‌شود.')) return;
    timer.stopTick();
    S().tm = { acc: 0, st: 0, k: t.k, g: t.g, s: t.s, c: t.c };
    App.save(); App.render();
  };
  App.act['tm-kind'] = function (el) {
    S().tm.k = el.getAttribute('data-v') === 'c' ? 'c' : 's';
    App.save(); App.render();
  };
  // انتخاب پایه، درس و فصل تایمر (با data-tm)
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (!el || !el.getAttribute || !el.hasAttribute('data-tm')) return;
    var t = S().tm, k = el.getAttribute('data-tm');
    if (k === 'g') {
      t.g = +el.value || S().mg || 12;
      var L = D.subjects(t.g);
      if (!L.some(function (x) { return x.name === t.s; })) t.s = L[0] ? L[0].name : '';
      t.c = 0;
    } else if (k === 's') { t.s = el.value; t.c = 0; }
    else if (k === 'c') { t.c = +el.value || 0; }
    App.save(); App.render();
  }, false);

  // از متن آزاد: «تایمر شروع کن» یا «تایمر تمام شد»
  timer.fromAct = function (a) {
    var t = S().tm;
    if (a.k === 'tstart') {
      if (timer.running()) { App.toast('تایمر از قبل روشن است'); return false; }
      t.k = a.c ? 'c' : 's';
      if (a.s && D.subjects(t.g || S().mg).some(function (x) { return x.name === a.s; })) { t.s = a.s; t.c = 0; }
      t.st = Date.now();
      App.save();
      timer.startTick();
      return true;
    }
    if (a.k === 'tstop') {
      if (!timer.running() && !t.acc) return false;
      var m = Math.round(timer.elapsed() / 60000);
      if (m > MAX_MIN) { timer.stopTick(); t.acc = timer.elapsed(); t.st = 0; App.save(); timer.askCorrection(m); return true; }
      timer.commit(m);
      return true;
    }
    return false;
  };

  // ---- نمای تایمر ----
  App.views.timer = function () {
    var t = S().tm, run = timer.running(), el = timer.elapsed();
    var g = t.g || S().mg || 12;
    var subs = D.subjects(g).map(function (x) { return [x.name, x.name]; });
    var f = App.form('tmf', { q: 0 });
    var today = st.dayStat(u.todayISO());
    var kindTabs = '<div class="tabs" role="group" aria-label="نوع زمان">' +
      '<button type="button" class="' + (t.k !== 'c' ? 'on' : '') + '" aria-pressed="' + (t.k !== 'c') + '" data-act="tm-kind" data-v="s">📖 مطالعه</button>' +
      '<button type="button" class="' + (t.k === 'c' ? 'on' : '') + '" aria-pressed="' + (t.k === 'c') + '" data-act="tm-kind" data-v="c">🏫 کلاس</button></div>';
    var pickers = '<div class="grid3">' +
      '<div class="field"><label for="tm-g">پایه</label><select id="tm-g" data-tm="g">' + App.opts(App.gradeOpts(), String(g)) + '</select></div>' +
      '<div class="field"><label for="tm-s">درس</label><select id="tm-s" data-tm="s">' + App.opts(subs, t.s) + '</select></div>' +
      '<div class="field"><label for="tm-c">فصل</label><select id="tm-c" data-tm="c">' + App.chapOpts(g, t.s, t.c) + '</select></div></div>';
    var body = kindTabs +
      '<div class="timer-clock" id="clk" aria-live="off">' + timer.clock(el) + '</div>' +
      '<p class="mu center">' + (run ? 'در حال شمارش' : (t.acc ? 'متوقف شده؛ ادامه بده یا پایان بده' : 'آماده‌ی شروع')) + ' · امروز تا الان: ' + u.hm(today.s) + ' مطالعه</p>' +
      pickers +
      App.field('تمرکزت چطور بود؟ (موقع پایان، اختیاری)', App.select('tmf', 'q', [['0', '—'], ['1', '😞 ضعیف'], ['2', '😐 معمولی'], ['3', '🙂 خوب'], ['4', '🤩 عالی']])) +
      '<div class="timer-btns">' +
        App.btn(run ? '⏸ توقف' : (t.acc ? '▶ ادامه' : '▶ شروع'), 'tm-toggle', {}, 'accent big-btn') +
        App.btn('✔ پایان و ثبت', 'tm-finish', {}, 'accent2 big-btn') +
      '</div>' +
      '<div class="row0 center mt"><button type="button" class="sm" data-act="tm-reset">↺ پاک‌کردن زمان</button></div>' +
      '<p class="mu">با پایان، زمان به مطالعه‌ی امروز (یا کلاس) اضافه می‌شود. اگر برنامه بسته شود، زمان ادامه دارد و موقع بازکردن دوباره درست نشان داده می‌شود. زمان بیشتر از ۱۸۰ دقیقه را قبل از ثبت می‌پرسد.</p>';
    return App.card('⏱ زمان‌سنج', body, { key: 'timer|main', open: true, cls: 'timer-card' });
  };

  // ---- صدا: تشخیص گفتار فارسی (Web Speech)؛ اگر نبود، متن را دستی وارد کن ----
  var voice = (App.voice = { rec: null, on: false, btn: null });
  function setBtn(el, on) {
    if (!el) return;
    el.setAttribute('aria-pressed', on ? 'true' : 'false');
    if (el.hasAttribute('data-voice-icon')) el.textContent = on ? '⏹' : '🎙';
    else el.textContent = on ? '⏹ توقف' : '🎙 میکروفون';
  }
  // el: دکمه؛ targetId: textarea/input؛ path: مسیر فرم مثل vp.txt
  voice.toggle = function (el, targetId, path) {
    if (voice.on) { voice.stop(); return; }
    var Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Rec) { App.toast('این مرورگر تشخیص صدا ندارد؛ متن را تایپ کن.', { kind: 'err', ms: 6000 }); return; }
    // اجازه‌ی میکروفون پیش از شروع گرفته می‌شود؛ صدا به سرویس تشخیص گفتار مرورگر فرستاده می‌شود
    if (!App.confirm('برای تشخیص صدا، میکروفون لازم است و صدای تو به سرویس تشخیص گفتار مرورگر فرستاده می‌شود. اجازه می‌دهی؟')) return;
    var r;
    try { r = new Rec(); } catch (e) { App.toast('تشخیص صدا در دسترس نیست.', { kind: 'err' }); return; }
    r.lang = 'fa-IR';
    r.continuous = true;
    r.interimResults = true;
    r.maxAlternatives = 1;
    var box = document.getElementById(targetId);
    var base = box ? String(box.value || '') : '';
    if (base && !/\s$/.test(base)) base += ' ';
    var fin = '';
    var parts = String(path || '').split('.');
    function put(v) {
      if (parts.length === 2) App.form(parts[0], {})[parts[1]] = v;
      var b = document.getElementById(targetId);
      if (b) b.value = v;
    }
    r.onresult = function (ev) {
      var interim = '';
      for (var i = ev.resultIndex; i < ev.results.length; i++) {
        var txt = ev.results[i][0] ? ev.results[i][0].transcript : '';
        if (ev.results[i].isFinal) fin += txt + ' ';
        else interim += txt;
      }
      put(base + fin + interim);
    };
    r.onerror = function (ev) {
      var msg = { 'not-allowed': 'دسترسی میکروفون داده نشد.', 'service-not-allowed': 'دسترسی میکروفون داده نشد.', network: 'اتصال تشخیص صدا برقرار نشد.', 'audio-capture': 'میکروفونی پیدا نشد.' }[ev && ev.error];
      if (msg) App.toast(msg, { kind: 'err', ms: 6000 });
    };
    r.onend = function () {
      voice.on = false;
      if (voice.btn && document.contains(voice.btn)) setBtn(voice.btn, false);
      voice.btn = null;
      voice.rec = null;
      var b = document.getElementById(targetId);
      if (b) b.value = b.value.replace(/\s+$/, ' ').replace(/\s+/g, ' ').trim();
      if (parts.length === 2) App.form(parts[0], {})[parts[1]] = b ? b.value : '';
    };
    try { r.start(); }
    catch (e) { App.toast('میکروفون شروع نشد.', { kind: 'err' }); return; }
    voice.rec = r;
    voice.on = true;
    voice.btn = el || null;
    setBtn(el, true);
  };
  voice.stop = function () { try { if (voice.rec) voice.rec.stop(); } catch (e) { /* ignore */ } };

  // ---- هشدار حافظه ----
  App.storageNotice = function () {
    if (!App.storageFull) return '';
    return '<div class="card notice" role="alert"><b>حافظه‌ی مرورگر پر است</b><p>تغییرهای تازه ممکن است ذخیره نشوند. یک پشتیبان بگیر و داده‌های قدیمی را کم کن.</p>' +
      '<button type="button" class="sm" data-act="go" data-tab="settings">رفتن به تنظیمات و پشتیبان</button></div>';
  };
})();
