'use strict';
/* ============ قسم الاستقبال ============ */
const QST = { waiting: ['بالانتظار', 'warn'], inprogress: ['عند الطبيب', 'info'], done: ['تم الكشف', 'ok'] };
let rcQ = '';

PAGES.rc_patients = {
  title: 'المرضى والتسجيل', live: false,
  onData(s) { if (s === 'patients' || s === 'queue') rcDraw(); },
  render() {
    $('page').innerHTML = pagehead('سجل المرضى', '<button class="btn accent" onclick="patientForm()">' + ic('plus', 'sm') + 'مريض جديد</button>') +
      '<div class="card"><input id="rq" class="input" placeholder="ابحث بالاسم أو رقم المريض أو رقم الهاتف…" value="' + esc(rcQ) + '" oninput="rcQ=this.value;rcDraw()" autocomplete="off"></div><div id="rlist"></div>';
    rcDraw();
  }
};
function matchPatient(p, q) { return (/^\d+$/.test(q) && String(p.no).startsWith(q)) || p.name.toLowerCase().includes(q) || (p.phone || '').includes(q); }
function rcDraw() {
  const e = $('rlist'); if (!e) return;
  const q = rcQ.trim().toLowerCase(); let L = [...D.patients].sort((a, b) => b.no - a.no);
  L = q ? L.filter(p => matchPatient(p, q)) : L.slice(0, 40);
  const act = {}; D.queue.filter(x => x.date === today() && x.status !== 'done').forEach(x => act[x.patientNo] = x);
  e.innerHTML = L.map(p => '<div class="row"><div class="av num">' + p.no + '</div><div class="grow"><div class="t">' + esc(p.name) + '</div><div class="mut">' + esc(p.age) + ' سنة · ' + GEN[p.gender || ''] + (p.phone ? ' · <span class="ltr num">' + esc(p.phone) + '</span>' : '') + '</div></div>' +
    (act[p.no] ? badge('في الطابور · دور ' + act[p.no].no, 'warn') : '<button class="btn sm" onclick="sendToDoctor(' + p.no + ')">' + ic('send', 'sm') + 'إرسال للطبيب</button>') +
    '<button class="btn ghost sm icon" onclick="printCard(' + p.no + ')" title="بطاقة المريض" aria-label="بطاقة المريض">' + ic('idcard', 'sm') + '</button>' +
    '<button class="btn ghost sm icon" onclick="patientForm(' + p.no + ')" title="تعديل" aria-label="تعديل">' + ic('edit', 'sm') + '</button></div>').join('') ||
    (q ? empty('search', 'لا يوجد مريض مطابق — يمكنك تسجيله كمريض جديد') : empty('users', 'لم يُسجَّل أي مريض بعد'));
}

function patientForm(no) {
  const p = no ? get('patients', no) : {};
  openModal(mhead(no ? 'تعديل بيانات المريض' : 'تسجيل مريض جديد') +
    '<div class="grid g2"><div class="field"><label>الاسم الكامل *</label><input id="f_name" value="' + esc(p.name) + '" autocomplete="off"></div>' +
    '<div class="field"><label>العمر *</label><input id="f_age" type="number" min="0" max="130" value="' + esc(p.age) + '" inputmode="numeric"></div>' +
    '<div class="field"><label>الجنس</label><select id="f_gen"><option value="">—</option><option value="male"' + (p.gender === 'male' ? ' selected' : '') + '>ذكر</option><option value="female"' + (p.gender === 'female' ? ' selected' : '') + '>أنثى</option></select></div>' +
    '<div class="field"><label>رقم الهاتف</label><input id="f_ph" type="tel" class="ltr" style="direction:ltr;text-align:left" value="' + esc(p.phone) + '"></div></div>' +
    '<div class="field"><label>العنوان</label><input id="f_ad" value="' + esc(p.address) + '"></div>' +
    '<div class="btns"><button class="btn" onclick="savePatient(' + (no || 0) + ')">حفظ</button><button class="btn ghost" onclick="closeModal()">إلغاء</button></div>');
  setTimeout(() => { const f = $('f_name'); if (f) f.focus(); }, 60);
}
async function savePatient(no) {
  const name = $('f_name').value.trim(), age = $('f_age').value;
  if (!name || age === '') return toast('الاسم والعمر مطلوبان', 'err');
  const d = { name, age: +age, gender: $('f_gen').value, phone: $('f_ph').value.trim(), address: $('f_ad').value.trim() };
  if (no) {
    const p = await safe(() => put('patients', Object.assign({ no }, d))); if (!p) return;
    closeModal(); toast('تم تحديث البيانات'); if (S.page && PAGES[S.page].live) renderPage(); else if (S.pno) renderPage(); else rcDraw();
  } else {
    const p = await safe(() => put('patients', Object.assign(d, stamp()))); if (!p) return;
    log('patient', 'تسجيل مريض جديد: ' + p.name, p.no);
    const role = S.me.role;
    openModal(mhead('تم تسجيل المريض') +
      '<div style="text-align:center;padding:.4rem 0 1.2rem"><div class="av big num" style="margin:0 auto .7rem">' + p.no + '</div><div style="font-weight:700;font-size:1.1rem">' + esc(p.name) + '</div><div class="mut">رقم المريض ' + p.no + '</div></div>' +
      '<div class="btns" style="justify-content:center">' + (role === 'doctor' ? '<button class="btn" onclick="closeModal();openPatient(' + p.no + ')">' + ic('stetho', 'sm') + 'فتح الملف</button>' : '<button class="btn" onclick="sendToDoctor(' + p.no + ')">' + ic('send', 'sm') + 'إرسال للطبيب</button>') +
      '<button class="btn ghost" onclick="printCard(' + p.no + ')">' + ic('idcard', 'sm') + 'طباعة البطاقة</button><button class="btn ghost" onclick="closeModal();rcDraw()">إغلاق</button></div>');
    rcDraw();
  }
}
async function sendToDoctor(no) {
  const p = get('patients', no); if (!p) return;
  const ex = D.queue.find(q => q.patientNo === no && q.date === today() && q.status !== 'done');
  if (ex) { closeModal(); return toast('المريض موجود بالفعل في طابور اليوم (دور ' + ex.no + ')', '', 'info'); }
  const q = await safe(() => put('queue', Object.assign({ patientNo: no, patientName: p.name, age: p.age, gender: p.gender, status: 'waiting' }, stamp()))); if (!q) return;
  log('queue', 'إرسال ' + p.name + ' للطبيب — دور ' + q.no, no);
  openModal(mhead('تم الإرسال إلى الطبيب') +
    '<div style="text-align:center;padding:.2rem 0 1.2rem"><div class="mut">رقم الدور</div><div style="font-size:3.6rem;font-weight:300;line-height:1.1;color:var(--navy)" class="num">' + q.no + '</div><div style="font-weight:700">' + esc(p.name) + '</div></div>' +
    '<div class="btns" style="justify-content:center"><button class="btn" onclick="printTicket(' + q.id + ')">' + ic('printer', 'sm') + 'طباعة التذكرة</button><button class="btn ghost" onclick="closeModal()">تم</button></div>');
  if (PAGES[S.page] && PAGES[S.page].onData) PAGES[S.page].onData('queue');
}

PAGES.rc_queue = {
  title: 'طابور المرضى', live: true,
  render() {
    const f = filt(FL.rq), L = D.queue.filter(f).sort((a, b) => FL.rq.mode === 'all' ? b.ts - a.ts : a.ts - b.ts);
    const c = s => L.filter(q => q.status === s).length;
    $('page').innerHTML = pagehead('الطابور — ' + periodLabel(FL.rq), '<button class="btn accent" onclick="patientForm()">' + ic('plus', 'sm') + 'مريض جديد</button><button class="btn ghost" onclick="go(\'rc_patients\')">' + ic('search', 'sm') + 'بحث وإرسال</button>') + filterBar('rq') +
      '<div class="stats">' + stat('clock', 'بالانتظار', c('waiting'), '') + stat('stetho', 'عند الطبيب', c('inprogress'), 'b') + stat('check', 'تم الكشف', c('done'), 'g') + stat('users', 'الإجمالي', L.length, 'n') + '</div>' +
      (L.map(q => { const st = QST[q.status] || QST.waiting; return '<div class="row"><div class="av num" style="width:52px">' + q.no + '</div><div class="grow"><div class="t">' + esc(q.patientName) + '</div><div class="mut">مريض رقم <span class="num">' + q.patientNo + '</span> · ' + esc(q.age) + ' سنة · <span class="num">' + hm(q.ts) + '</span>' + (FL.rq.mode === 'all' ? ' · ' + q.date : '') + (q.doctorName ? ' · د. ' + esc(q.doctorName) : '') + '</div></div>' + badge(st[0], st[1]) +
        '<button class="btn ghost sm icon" onclick="printTicket(' + q.id + ')" title="طباعة التذكرة" aria-label="طباعة التذكرة">' + ic('printer', 'sm') + '</button>' +
        (q.status === 'waiting' ? '<button class="btn ghost sm icon" onclick="cancelQueue(' + q.id + ')" title="إلغاء" aria-label="إلغاء">' + ic('x', 'sm') + '</button>' : '') + '</div>'; }).join('') || '<div class="card">' + empty('list', 'لا يوجد مرضى في الطابور') + '</div>');
  }
};
async function cancelQueue(id) {
  const q = get('queue', id); if (!q) return;
  if (!await ask('إلغاء دور المريض «' + q.patientName + '» من الطابور؟', { danger: true, ok: 'إلغاء الدور' })) return;
  await safe(() => del('queue', id)); renderPage();
}
