'use strict';
const CELL=250;
let mp=MAPS[0],MAP=4800,GN=20,grid=[],walls=[],trees=[],lakes=[],houses=[],loot=[],glooW=[],smokes=[],nades=[],fxs=[],ground=null;

function addObs(o,x0,y0,x1,y1){
  for(let cy=clamp(Math.floor(y0/CELL),0,GN-1);cy<=clamp(Math.floor(y1/CELL),0,GN-1);cy++)
    for(let cx=clamp(Math.floor(x0/CELL),0,GN-1);cx<=clamp(Math.floor(x1/CELL),0,GN-1);cx++)grid[cy*GN+cx].push(o);
}
function addW(x,y,w,hh,H,hs){if(w<2||hh<2)return;const o={k:0,x,y,w,h:hh,H,hs};walls.push(o);addObs(o,x,y,x+w,y+hh)}
function hwall(x,y,len,horiz,door,H,hs){
  const T=16,gap=62;
  if(!door){horiz?addW(x,y,len,T,H,hs):addW(x,y,T,len,H,hs);return}
  const off=rnd(16,len-gap-16);
  if(horiz){addW(x,y,off,T,H,hs);addW(x+off+gap,y,len-off-gap,T,H,hs)}else{addW(x,y,T,off,H,hs);addW(x,y+off+gap,T,len-off-gap,H,hs)}
}
function randLoot(good){
  const r=Math.random();
  const t=good?[['smg',.0],['hornet',.07],['swift',.05],['ranger',.07],['falcon',.05],['titan',.02],['hammer',.03],['pump',.05],['auto12',.04],['hawk',.025],['dmr',.035],['xbow',.03],['revolver',.04],['ammo',.16],['bandage',.07],['medkit',.06],['vest',.06],['grenade',.05],['smoke',.025],['gloo',.05]]
              :[['hornet',.05],['ranger',.05],['pump',.04],['dmr',.02],['revolver',.03],['xbow',.02],['ammo',.2],['bandage',.14],['medkit',.07],['vest',.07],['grenade',.07],['smoke',.04],['gloo',.1],['swift',.03],['pistol',.04]];
  let a=0;for(const [k,p] of t){a+=p;if(r<=a)return k}return 'ammo';
}
function lootQty(t){return t==='bandage'?2:t==='grenade'?2:t==='ammo'?40:1}

function genWorld(mi){
  mp=MAPS[mi];MAP=mp.size;GN=Math.ceil(MAP/CELL);
  grid=Array.from({length:GN*GN},()=>[]);walls=[];trees=[];lakes=[];houses=[];loot=[];glooW=[];smokes=[];nades=[];fxs=[];
  const A=(MAP/3000)**2;
  for(let i=0;i<mp.lk;i++)lakes.push({x:rnd(400,MAP-400),y:rnd(400,MAP-400),r:rnd(120,250)*mp.lkr});
  const nearLake=(x,y,w,hh,m)=>lakes.some(l=>{const px=clamp(l.x,x,x+w),py=clamp(l.y,y,y+hh);return Math.hypot(l.x-px,l.y-py)<l.r+m});
  const target=Math.round(46*A*mp.hd*(mp.urb?1.4:1));
  for(let t=0;t<target*30&&houses.length<target;t++){
    const w=mp.urb?rnd(150,300):rnd(120,230),hh=mp.urb?rnd(140,260):rnd(110,190),x=rnd(140,MAP-140-w),y=rnd(140,MAP-140-hh);
    if(nearLake(x,y,w,hh,36))continue;
    if(houses.some(o=>x<o.x+o.w+70&&x+w>o.x-70&&y<o.y+o.h+70&&y+hh>o.y-70))continue;
    houses.push({x,y,w,h:hh,cx:x+w/2,cy:y+hh/2,H:mp.urb?rnd(34,62):rnd(26,34),ra:1,st:Math.random()});
  }
  for(const hs of houses){
    const d=Math.floor(rnd(0,4)),T=16,H=hs.H;
    hwall(hs.x,hs.y,hs.w,true,d===0,H,hs);hwall(hs.x,hs.y+hs.h-T,hs.w,true,d===2,H,hs);
    hwall(hs.x,hs.y,hs.h,false,d===3,H,hs);hwall(hs.x+hs.w-T,hs.y,hs.h,false,d===1,H,hs);
    const n=(mp.urb?3:2)+Math.floor(rnd(0,3));
    for(let i=0;i<n;i++){const t=randLoot(true);loot.push({x:rnd(hs.x+T+16,hs.x+hs.w-T-16),y:rnd(hs.y+T+16,hs.y+hs.h-T-16),t,q:lootQty(t)})}
  }
  const nt=Math.min(900,Math.round(170*A*mp.td));
  for(let t=0;t<nt*4&&trees.length<nt;t++){
    const x=rnd(60,MAP-60),y=rnd(60,MAP-60),cr=rnd(18,30);
    if(nearLake(x,y,0,0,cr+10))continue;
    if(houses.some(o=>x>o.x-cr-30&&x<o.x+o.w+cr+30&&y>o.y-cr-30&&y<o.y+o.h+cr+30))continue;
    const o={k:1,x,y,r:cr*.4,cr,ty:mp.tr,s:Math.random()};trees.push(o);addObs(o,x-o.r,y-o.r,x+o.r,y+o.r);
  }
  const nl=Math.round(110*A);
  for(let i=0;i<nl;i++){
    const x=rnd(80,MAP-80),y=rnd(80,MAP-80);
    if(nearLake(x,y,0,0,20)||blocked(x,y))continue;
    const t=randLoot(false);loot.push({x,y,t,q:lootQty(t)});
  }
  ground=mkGround();
  if(typeof resize==='function')resize();
}

function mkGround(){
  const q=QL(),G=Math.min(1,q.tex/MAP),sz=Math.round(MAP*G),gc=document.createElement('canvas');gc.width=gc.height=sz;
  const g=gc.getContext('2d');g.scale(G,G);const A=(MAP/3000)**2;
  g.fillStyle=mp.g[0];g.fillRect(0,0,MAP,MAP);
  // soft patches, batched into two paths
  g.globalAlpha=.32;
  for(let c=1;c<=2;c++){g.fillStyle=mp.g[c];g.beginPath();for(let i=0;i<Math.round(260*A);i++){const x=rnd(0,MAP),y=rnd(0,MAP),rx=rnd(40,170),ry=rnd(30,110);g.moveTo(x+rx,y);g.ellipse(x,y,rx,ry,rnd(0,3),0,TAU)}g.fill()}
  g.globalAlpha=1;
  g.lineCap='round';g.strokeStyle=mp.path;g.lineWidth=mp.urb?42:26;
  g.beginPath();
  houses.forEach((a,i)=>{
    houses.map((b,j)=>({b,d:i===j?1e9:Math.hypot(a.cx-b.cx,a.cy-b.cy)})).sort((p,q2)=>p.d-q2.d).slice(0,2).forEach(({b})=>{g.moveTo(a.cx,a.cy);g.lineTo(b.cx,b.cy)});
  });
  g.stroke();
  if(mp.urb){g.strokeStyle='rgba(255,255,255,.22)';g.lineWidth=2;g.setLineDash([16,16]);g.beginPath();houses.forEach((a,i)=>{const b=houses[(i+1)%houses.length];g.moveTo(a.cx,a.cy);g.lineTo(b.cx,b.cy)});g.stroke();g.setLineDash([])}
  const tf=q.tuft,det=mp.det;
  if(tf){
    const n=Math.round(1500*A*tf);
    if(det==='grass'){
      g.lineWidth=1.6;
      for(const col of ['rgba(190,230,130,.28)','rgba(20,50,20,.28)']){g.strokeStyle=col;g.beginPath();for(let i=0;i<n/2;i++){const x=rnd(0,MAP),y=rnd(0,MAP);g.moveTo(x,y);g.lineTo(x-2,y-7);g.moveTo(x+3,y);g.lineTo(x+4,y-8)}g.stroke()}
      for(const col of ['#ffe27a','#ffffff','#ff9bb0','#c9a7ff']){g.fillStyle=col;g.beginPath();for(let i=0;i<40*A*tf;i++){const x=rnd(0,MAP),y=rnd(0,MAP);g.moveTo(x+2,y);g.arc(x,y,2,0,TAU)}g.fill()}
    }else if(det==='sand'){
      g.lineWidth=2;g.strokeStyle='rgba(255,240,200,.22)';g.beginPath();
      for(let i=0;i<Math.round(260*A*tf);i++){const x=rnd(0,MAP),y=rnd(0,MAP),r=rnd(40,130),a=rnd(0,TAU);g.moveTo(x+Math.cos(a)*r,y+Math.sin(a)*r);g.arc(x,y,r,a,a+rnd(.6,1.6))}
      g.stroke();
      g.fillStyle='rgba(90,60,30,.25)';g.beginPath();for(let i=0;i<150*A*tf;i++){const x=rnd(0,MAP),y=rnd(0,MAP);g.moveTo(x+2,y);g.arc(x,y,rnd(1.5,3.5),0,TAU)}g.fill();
    }else if(det==='snow'){
      g.fillStyle='rgba(255,255,255,.5)';g.beginPath();for(let i=0;i<Math.round(160*A*tf);i++){const x=rnd(0,MAP),y=rnd(0,MAP),rx=rnd(30,90);g.moveTo(x+rx,y);g.ellipse(x,y,rx,rnd(10,30),rnd(0,3),0,TAU)}g.fill();
      g.strokeStyle='rgba(150,175,195,.5)';g.lineWidth=1.4;g.beginPath();for(let i=0;i<50*A*tf;i++){let x=rnd(0,MAP),y=rnd(0,MAP);g.moveTo(x,y);for(let k=0;k<4;k++){x+=rnd(-18,18);y+=rnd(-18,18);g.lineTo(x,y)}}g.stroke();
    }else if(det==='rock'||det==='lava'){
      g.fillStyle=det==='rock'?'rgba(60,40,30,.3)':'rgba(10,8,12,.45)';g.beginPath();
      for(let i=0;i<Math.round(200*A*tf);i++){const x=rnd(0,MAP),y=rnd(0,MAP),rx=rnd(8,26);g.moveTo(x+rx,y);g.ellipse(x,y,rx,rnd(6,18),rnd(0,3),0,TAU)}g.fill();
      if(det==='lava'){g.strokeStyle='rgba(255,110,30,.8)';g.lineWidth=3;g.beginPath();for(let i=0;i<40*A*tf;i++){let x=rnd(0,MAP),y=rnd(0,MAP);g.moveTo(x,y);for(let k=0;k<6;k++){x+=rnd(-30,30);y+=rnd(-30,30);g.lineTo(x,y)}}g.stroke()}
    }
  }
  for(const l of lakes){
    g.fillStyle=mp.sh;g.beginPath();g.arc(l.x,l.y,l.r+16,0,TAU);g.fill();
    g.fillStyle=mp.wat;g.beginPath();g.arc(l.x,l.y,l.r,0,TAU);g.fill();
    g.fillStyle='rgba(10,50,80,.35)';g.beginPath();g.arc(l.x+l.r*.1,l.y+l.r*.1,l.r*.78,0,TAU);g.fill();
    g.fillStyle=mp.wat;g.beginPath();g.arc(l.x-l.r*.1,l.y-l.r*.1,l.r*.55,0,TAU);g.fill();
  }
  g.fillStyle=mp.fl;g.beginPath();for(const hs of houses)g.rect(hs.x,hs.y,hs.w,hs.h);g.fill();
  g.fillStyle='rgba(30,20,5,.14)';g.beginPath();
  for(const hs of houses){
    if(mp.urb){for(let y=hs.y+24;y<hs.y+hs.h;y+=24)g.rect(hs.x,y,hs.w,1.5);for(let x=hs.x+24;x<hs.x+hs.w;x+=24)g.rect(x,hs.y,1.5,hs.h)}
    else for(let y=hs.y+18;y<hs.y+hs.h;y+=18)g.rect(hs.x,y,hs.w,2);
  }
  g.fill();
  return gc;
}

/* ---------- collision & visibility ---------- */
function hitDyn(x,y){
  for(let i=0;i<glooW.length;i++){const w=glooW[i],dx=x-w.x,dy=y-w.y,ca=Math.cos(w.a),sa=Math.sin(w.a),lx=dx*ca+dy*sa,ly=-dx*sa+dy*ca;if(lx>-w.hl&&lx<w.hl&&ly>-w.ht&&ly<w.ht)return w}
  return null;
}
function blocked(x,y){
  if(x<0||y<0||x>=MAP||y>=MAP)return true;
  const c=grid[Math.floor(y/CELL)*GN+Math.floor(x/CELL)];
  for(let i=0;i<c.length;i++){const o=c[i];
    if(o.k===0){if(x>o.x&&x<o.x+o.w&&y>o.y&&y<o.y+o.h)return true}
    else{const dx=x-o.x,dy=y-o.y;if(dx*dx+dy*dy<o.r*o.r)return true}}
  return false;
}
function inSmoke(x,y){for(const s of smokes)if((x-s.x)**2+(y-s.y)**2<(s.r*.85)**2)return true;return false}
function los(ax,ay,bx,by){
  const d=Math.hypot(bx-ax,by-ay),n=Math.ceil(d/14);
  for(let i=1;i<n;i++){const f=i/n,x=ax+(bx-ax)*f,y=ay+(by-ay)*f;if(blocked(x,y)||hitDyn(x,y)||inSmoke(x,y))return false}
  return true;
}
function fix(e){
  const r=e.r;
  for(let cy=Math.max(0,Math.floor((e.y-r)/CELL));cy<=Math.min(GN-1,Math.floor((e.y+r)/CELL));cy++)
  for(let cx=Math.max(0,Math.floor((e.x-r)/CELL));cx<=Math.min(GN-1,Math.floor((e.x+r)/CELL));cx++){
    const c=grid[cy*GN+cx];
    for(let i=0;i<c.length;i++){const o=c[i];
      if(o.k===0){
        const px=clamp(e.x,o.x,o.x+o.w),py=clamp(e.y,o.y,o.y+o.h),dx=e.x-px,dy=e.y-py,d2=dx*dx+dy*dy;
        if(d2<r*r){
          if(d2>1e-4){const d=Math.sqrt(d2),k=(r-d)/d;e.x+=dx*k;e.y+=dy*k}
          else{const l=e.x-o.x,rr2=o.x+o.w-e.x,t=e.y-o.y,b=o.y+o.h-e.y,m=Math.min(l,rr2,t,b);
            if(m===l)e.x=o.x-r;else if(m===rr2)e.x=o.x+o.w+r;else if(m===t)e.y=o.y-r;else e.y=o.y+o.h+r}
        }
      }else{
        const dx=e.x-o.x,dy=e.y-o.y,m=r+o.r,d2=dx*dx+dy*dy;
        if(d2<m*m){const d=Math.sqrt(d2)||1,k=(m-d)/d;e.x+=dx*k;e.y+=dy*k}
      }
    }
  }
  for(const w of glooW){
    const ca=Math.cos(w.a),sa=Math.sin(w.a),dx=e.x-w.x,dy=e.y-w.y,lx=dx*ca+dy*sa,ly=-dx*sa+dy*ca;
    const px=clamp(lx,-w.hl,w.hl),py=clamp(ly,-w.ht,w.ht);let ex=lx-px,ey=ly-py;const d2=ex*ex+ey*ey;
    if(d2<r*r){
      let nx,ny;
      if(d2>1e-4){const d=Math.sqrt(d2),k=(r-d)/d;nx=px+ex+ex*k;ny=py+ey+ey*k}
      else{nx=lx;ny=ly>=0?w.ht+r:-w.ht-r}
      e.x=w.x+nx*ca-ny*sa;e.y=w.y+nx*sa+ny*ca;
    }
  }
  e.x=clamp(e.x,r,MAP-r);e.y=clamp(e.y,r,MAP-r);
}
function inWater(e){for(const l of lakes){const dx=e.x-l.x,dy=e.y-l.y;if(dx*dx+dy*dy<l.r*l.r)return true}return false}
function moveE(e,vx,vy,dt){const ox=e.x,oy=e.y;e.x+=vx*dt;fix(e);e.y+=vy*dt;fix(e);e.vx=(e.x-ox)/dt;e.vy=(e.y-oy)/dt}
