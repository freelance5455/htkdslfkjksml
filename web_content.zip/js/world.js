'use strict';
/* ===== World: renderer, city grid, buildings and details, beach, sea, airport, minimap base ===== */
const PITCH = 50, ROAD = 10, NR = 3;               // roads every 50 units at -150..150
const BOUNDS = { x0: -290, x1: 640, z0: -290, z1: 183 };
const SEA_Z = 186;
const colliders = [];
const mapRects = [];
const rnd = (a, b) => a + Math.random() * (b - a);
const rint = (a, b) => Math.floor(rnd(a, b + 1));
const pick = a => a[Math.floor(Math.random() * a.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
let scene, camera, renderer, sun, hemi, waterTex, skyMesh, mapBase;
let curPR = null;                                   // current pixel ratio (lowered automatically when the frame rate drops)
const lampMat = new THREE.MeshBasicMaterial({ color: 0x4a4a48 });   // street-lamp heads, brightened at night

/* The page is drawn landscape. On a portrait phone the #app box is rotated, so the drawing size is swapped. */
function isRot() { return document.documentElement.classList.contains('rot'); }
function localSize() { return isRot() ? [innerHeight, innerWidth] : [innerWidth, innerHeight]; }

function canvasTex(w, h, draw) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

function addCollider(x, z, w, d, h) {
  colliders.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2, h: h || 20 });
}

function pushOut(p, r) {
  let hit = false;
  for (const c of colliders) {
    if (p.x < c.x0 - r || p.x > c.x1 + r || p.z < c.z0 - r || p.z > c.z1 + r) continue;
    const cx = Math.max(c.x0, Math.min(p.x, c.x1)), cz = Math.max(c.z0, Math.min(p.z, c.z1));
    const dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz;
    if (d2 < r * r) {
      if (d2 > 1e-6) { const d = Math.sqrt(d2), k = (r - d) / d; p.x += dx * k; p.z += dz * k; }
      else {
        const l = p.x - c.x0, rr = c.x1 - p.x, t = p.z - c.z0, b = c.z1 - p.z, m = Math.min(l, rr, t, b);
        if (m === l) p.x = c.x0 - r; else if (m === rr) p.x = c.x1 + r; else if (m === t) p.z = c.z0 - r; else p.z = c.z1 + r;
      }
      hit = true;
    }
  }
  return hit;
}

function clampWorld(p) {
  const onPier = Math.abs(p.x - 60) < 3.4 && p.z > 150;
  p.x = clamp(p.x, BOUNDS.x0, BOUNDS.x1);
  p.z = clamp(p.z, BOUNDS.z0, onPier ? 236 : BOUNDS.z1);
}

function slab(p, q, lo, hi, t) {
  if (Math.abs(q) < 1e-9) return p >= lo && p <= hi;
  let a = (lo - p) / q, b = (hi - p) / q;
  if (a > b) { const s = a; a = b; b = s; }
  t[0] = Math.max(t[0], a); t[1] = Math.min(t[1], b);
  return t[0] <= t[1];
}
const _t = [0, 1];
function los(ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az;
  for (const c of colliders) {
    _t[0] = 0; _t[1] = 1;
    if (slab(ax, dx, c.x0, c.x1, _t) && slab(az, dz, c.z0, c.z1, _t)) return false;
  }
  return true;
}

function insideBuilding(x, z, r) {
  for (const c of colliders) if (x > c.x0 - r && x < c.x1 + r && z > c.z0 - r && z < c.z1 + r) return true;
  return false;
}

function zoneName(x, z) {
  if (x > 190) return 'المطار';
  if (z > 150) return 'الشاطئ';
  if (Math.abs(x) < 80 && Math.abs(z) < 80) return 'وسط المدينة';
  return 'الأحياء السكنية';
}

/* ---------- textures ---------- */
function roadTex(vertical) {
  const w = vertical ? 128 : 256, h = vertical ? 256 : 128;
  return canvasTex(w, h, (g) => {
    g.fillStyle = '#3b3e44'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 1400; i++) { g.fillStyle = Math.random() < .5 ? '#33363b' : '#4a4d53'; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
    // patches of repaired asphalt
    for (let i = 0; i < 4; i++) { g.fillStyle = 'rgba(20,20,22,.35)'; g.fillRect(rnd(0, w), rnd(0, h), rnd(10, 30), rnd(6, 14)); }
    g.fillStyle = '#ececec';
    if (vertical) {
      g.fillRect(6, 0, 4, h); g.fillRect(w - 10, 0, 4, h);
      g.fillStyle = '#f2c230'; g.fillRect(w / 2 - 2, 16, 4, 96); g.fillRect(w / 2 - 2, 144, 4, 96);
    } else {
      g.fillRect(0, 6, w, 4); g.fillRect(0, h - 10, w, 4);
      g.fillStyle = '#f2c230'; g.fillRect(16, h / 2 - 2, 96, 4); g.fillRect(144, h / 2 - 2, 96, 4);
    }
  });
}

/* facade textures: glass towers, brick, stucco. Each gets lit and dark windows, and shop-front bands at ground level. */
const FACADE = {
  glass: { base: ['#7f9bb3', '#8fa6bb', '#6c879f'], frame: '#dfe6ec', win: ['#2b4358', '#355068', '#213548'], lit: '#ffe9ad' },
  brick: { base: ['#9a5a43', '#8c4f3a', '#a86a4e'], frame: '#e8dccb', win: ['#263443', '#1d2a38'], lit: '#ffd680' },
  stucco: { base: ['#dcd3c2', '#e6dccb', '#cfc5b0', '#d9c7a6'], frame: '#f4efe6', win: ['#2c3e4f', '#38495c'], lit: '#fff0b8' }
};
const facadeCache = {};
function facadeTex(kind) {
  if (facadeCache[kind]) return facadeCache[kind];
  const F = FACADE[kind];
  const t = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = pick(F.base); g.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 4) { g.fillStyle = 'rgba(0,0,0,.035)'; g.fillRect(0, y, w, 1); }   // subtle course lines
    // 4 columns x 6 rows of windows, each with a frame, glass, and a sill shadow
    const cw = w / 4, rh = h / 6;
    for (let r = 0; r < 6; r++) for (let c = 0; c < 4; c++) {
      const x = c * cw + cw * .2, y = r * rh + rh * .2, ww = cw * .6, hh = rh * .55;
      g.fillStyle = F.frame; g.fillRect(x - 2, y - 2, ww + 4, hh + 4);
      g.fillStyle = Math.random() < .2 ? F.lit : pick(F.win); g.fillRect(x, y, ww, hh);
      g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(x, y, ww * .35, hh);   // glass reflection
      g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(x - 3, y + hh + 2, ww + 6, 2);  // sill shadow
    }
    if (kind === 'glass') for (let c = 0; c < 4; c++) { g.fillStyle = 'rgba(220,235,245,.25)'; g.fillRect(c * cw, 0, 2, h); }
  });
  facadeCache[kind] = t;
  return t;
}
/* a ground-floor shop band: awning colour strip and glass front */
const shopTex = canvasTex(256, 64, (g, w, h) => {
  g.fillStyle = '#2a2d33'; g.fillRect(0, 0, w, h);
  const colors = ['#c2410c', '#15803d', '#1d4ed8', '#a16207', '#be185d'];
  for (let i = 0; i < 4; i++) {
    g.fillStyle = colors[i % colors.length]; g.fillRect(i * 64 + 4, 0, 56, 14);
    g.fillStyle = '#7fb4d6'; g.fillRect(i * 64 + 8, 18, 48, 40);
    g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(i * 64 + 8, 18, 14, 40);
  }
});

/* ---------- shared geometry ---------- */
const UB = new THREE.BoxGeometry(1, 1, 1);
const matC = {};
const mat = c => matC[c] || (matC[c] = new THREE.MeshLambertMaterial({ color: c }));
function bx(w, h, d, c) { const m = new THREE.Mesh(UB, mat(c)); m.scale.set(w, h, d); return m; }
function addBox(x, y, z, w, h, d, c, shadow) {
  const m = bx(w, h, d, c); m.position.set(x, y, z); if (shadow) m.castShadow = true; m.receiveShadow = true; scene.add(m); return m;
}

// materials are shared between buildings with the same look and size, which keeps draw calls and uploads low
const facadeMats = {};
let shopMat = null;
function facadeMat(kind, len, hgt) {
  const rx = Math.max(1, Math.round(len / 9)), ry = Math.max(1, Math.round(hgt / 9)), key = kind + '|' + rx + '|' + ry;
  if (facadeMats[key]) return facadeMats[key];
  const t = facadeTex(kind).clone(); t.needsUpdate = true; t.repeat.set(rx, ry);
  return (facadeMats[key] = new THREE.MeshLambertMaterial({ map: t }));
}
function maxPixelRatio() {
  const h = localSize()[1];
  return Math.min(2, Math.max(1, 1080 / h), (devicePixelRatio || 1) * 1.25);   // aim for about 1080 rows of pixels
}

function addBuilding(x, z, w, d, h) {
  const kind = h > 36 ? (Math.random() < .6 ? 'glass' : 'stucco') : pick(['brick', 'brick', 'stucco', 'glass']);
  const side = facadeMat(kind, d, h), front = facadeMat(kind, w, h);
  const roof = mat(0x5d6168);
  const m = new THREE.Mesh(UB, [side, side, roof, roof, front, front]);
  m.scale.set(w, h, d); m.position.set(x, h / 2 + .2, z);
  m.castShadow = true; m.receiveShadow = true;
  scene.add(m);
  addCollider(x, z, w, d, h + .2);
  mapRects.push({ x, z, w, d, c: kind === 'glass' ? '#6f8aa3' : kind === 'brick' ? '#9a5a43' : '#cbbfa8' });

  // ground-floor shop band on the front side (facing the street)
  const shopW = Math.min(w - 2, 14);
  if (!shopMat) shopMat = new THREE.MeshLambertMaterial({ map: shopTex });
  const shop = new THREE.Mesh(UB, shopMat);
  shop.scale.set(w * .92, 4.2, .25); shop.position.set(x, 2.4 + .2, z + d / 2 + .02);
  scene.add(shop);

  // rooftop details: AC units, water tank, antenna
  const roofY = h + .2;
  if (w > 12 && d > 12) {
    for (let i = 0; i < rint(1, 3); i++) addBox(x + rnd(-w / 3, w / 3), roofY + .8, z + rnd(-d / 3, d / 3), rnd(2.5, 4), 1.6, rnd(2, 3), 0xc8ccd2, true);
    if (Math.random() < .35) {
      const t = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 3.2, 10), mat(0x8a6d4b));
      t.position.set(x - w / 3, roofY + 2.2, z + d / 3); t.castShadow = true; scene.add(t);
      addBox(x - w / 3, roofY + 4.2, z + d / 3, .3, .3, .3, 0x888888);
    }
  }
  if (h > 30 && Math.random() < .7) addBox(x, roofY + 4.2, z, .25, 8, .25, 0xaaaaaa, true);
  else if (Math.random() < .4) addBox(x + w * .15, roofY + .6, z - d * .1, w * .3, 1.2, d * .25, 0x7d838a, true);
}

const trunkG = new THREE.CylinderGeometry(.18, .25, 2.6, 6), crownG = new THREE.IcosahedronGeometry(1.8, 1);
function addTree(x, z, s) {
  const t = new THREE.Mesh(trunkG, mat(0x6b4a2b)); t.position.set(x, 1.3 * s, z); t.scale.setScalar(s); t.castShadow = true;
  const crown = new THREE.Mesh(crownG, mat(pick([0x3f8f3f, 0x4a9a45, 0x357a3a, 0x5aa34c]))); crown.position.set(x, 3.7 * s, z); crown.scale.setScalar(s); crown.castShadow = true;
  scene.add(t, crown);
}
function addPalm(x, z) {
  const t = new THREE.Mesh(new THREE.CylinderGeometry(.16, .26, 6, 6), mat(0x8a6a44));
  t.position.set(x, 3, z); t.rotation.z = rnd(-.15, .15); t.castShadow = true; scene.add(t);
  for (let i = 0; i < 7; i++) {
    const l = bx(.5, .08, 3.4, 0x2f8f3a), a = i / 7 * Math.PI * 2;
    l.position.set(x + Math.sin(a) * 1.4, 6, z + Math.cos(a) * 1.4); l.rotation.y = a; l.rotation.x = -.35; l.castShadow = true;
    scene.add(l);
  }
}

/* street furniture on the sidewalks: benches, bins, parked-car spots are handled in actors */
function addBench(x, z, rot) {
  const g = new THREE.Group();
  const seat = bx(2.2, .12, .6, 0x8b5a2b); seat.position.y = .55; g.add(seat);
  const back = bx(2.2, .5, .1, 0x8b5a2b); back.position.set(0, .85, -.25); g.add(back);
  for (const s of [-1, 1]) { const leg = bx(.1, .55, .5, 0x333333); leg.position.set(s * .9, .28, 0); g.add(leg); }
  g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  g.position.set(x, 0, z); g.rotation.y = rot; scene.add(g);
}
function addBin(x, z) { addBox(x, .5, z, .7, 1, .7, 0x2f5d3a, true); }

/* crosswalks and traffic lights at every grid intersection */
function addIntersectionDetails(i, j) {
  const cx = i * PITCH, cz = j * PITCH, off = ROAD / 2 + 1.6;
  const stripes = (horizontal, sign) => {
    for (let k = -3; k <= 3; k++) {
      const s = bx(horizontal ? .8 : 4, .02, horizontal ? 4 : .8, 0xf2f2f2);
      s.position.set(horizontal ? cx + k * 1.4 : cx + sign * off, .07, horizontal ? cz + sign * off : cz + k * 1.4);
      scene.add(s);
    }
  };
  stripes(true, 1); stripes(true, -1); stripes(false, 1); stripes(false, -1);
  // traffic light pole on one corner
  const px = cx + 6.6, pz = cz + 6.6;
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(.12, .14, 5.6, 6), mat(0x3a3d42)); pole.position.set(px, 2.8, pz); pole.castShadow = true; scene.add(pole);
  const head = bx(.7, 1.9, .7, 0x1c1e22); head.position.set(px, 5.2, pz); scene.add(head);
  const lamp = new THREE.Mesh(new THREE.SphereGeometry(.18, 8, 6), new THREE.MeshBasicMaterial({ color: Math.random() < .5 ? 0xff3b30 : 0x34c759 }));
  lamp.position.set(px, 5.8, pz + .37); scene.add(lamp);
}

function fillBlock(cx, cz) {
  const dist = Math.hypot(cx, cz), hmax = dist < 90 ? 92 : dist < 150 ? 56 : 30, r = Math.random();
  const side = bx(40, .24, 40, 0xbdb9b0); side.position.set(cx, .12, cz); side.receiveShadow = true; scene.add(side);
  // curb ring around the block
  for (const [x, z, w, d] of [[cx, cz - 19.5, 40, .5], [cx, cz + 19.5, 40, .5], [cx - 19.5, cz, .5, 40], [cx + 19.5, cz, .5, 40]]) addBox(x, .28, z, w, .32, d, 0xd0ccc2);
  mapRects.push({ x: cx, z: cz, w: 40, d: 40, c: '#b4b0a6', under: true });
  const hh = () => rnd(12, hmax);
  if (r < .12 && dist > 40) {
    // park with grass, paths, benches and trees
    const g = bx(36, .05, 36, 0x5c9a4c); g.position.set(cx, .27, cz); g.receiveShadow = true; scene.add(g);
    mapRects.push({ x: cx, z: cz, w: 36, d: 36, c: '#4f8a43' });
    for (let i = 0; i < 10; i++) addTree(cx + rnd(-15, 15), cz + rnd(-15, 15), rnd(.9, 1.4));
    addBench(cx - 6, cz + 4, 0); addBench(cx + 5, cz - 6, Math.PI / 2);
    return;
  }
  if (r < .4) addBuilding(cx, cz, 32, 32, hh());
  else if (r < .7) {
    if (Math.random() < .5) { addBuilding(cx - 9, cz, 15, 32, hh()); addBuilding(cx + 9, cz, 15, 32, hh()); }
    else { addBuilding(cx, cz - 9, 32, 15, hh()); addBuilding(cx, cz + 9, 32, 15, hh()); }
  } else for (const sx of [-8.5, 8.5]) for (const sz of [-8.5, 8.5]) addBuilding(cx + sx, cz + sz, 14, 14, hh());
  // a bench and a bin on the sidewalk, and a tree near the curb on some blocks
  if (Math.random() < .5) addBench(cx + rnd(-14, 14), cz + 19, 0);
  if (Math.random() < .6) addBin(cx - 18, cz + rnd(-14, 14));
  if (Math.random() < .5) addTree(cx + rnd(-16, 16), cz - 18.5, rnd(.9, 1.2));
}

function initWorld(canvas) {
  const mobile = Math.min(innerWidth, innerHeight) < 700;
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputEncoding = THREE.sRGBEncoding;
  scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0xbfe3f7, 170, 680);
  camera = new THREE.PerspectiveCamera(60, 1, .3, 1400);
  resizeWorld();

  hemi = new THREE.HemisphereLight(0xcfe8ff, 0x6b7a5a, .8);
  scene.add(hemi);
  sun = new THREE.DirectionalLight(0xfff1d6, 1.15);
  sun.castShadow = true;
  const ms = mobile ? 1024 : 2048; sun.shadow.mapSize.set(ms, ms);
  const sc = sun.shadow.camera; sc.left = -80; sc.right = 80; sc.top = 80; sc.bottom = -80; sc.near = 1; sc.far = 340;
  sc.updateProjectionMatrix();
  sun.shadow.bias = -0.0005; sun.shadow.normalBias = .4;
  scene.add(sun, sun.target);

  // sky dome
  const skyT = canvasTex(8, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#2f7fd6'); gr.addColorStop(.55, '#8cc4ee'); gr.addColorStop(1, '#d6edf8');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
  });
  skyT.wrapT = THREE.ClampToEdgeWrapping;
  skyMesh = new THREE.Mesh(new THREE.SphereGeometry(1100, 16, 12), new THREE.MeshBasicMaterial({ map: skyT, side: THREE.BackSide, fog: false, depthWrite: false }));
  scene.add(skyMesh);

  // ground
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(2600, 2600).rotateX(-Math.PI / 2), mat(0x7aa85e));
  ground.position.set(170, 0, 0); ground.receiveShadow = true; scene.add(ground);

  // roads
  const tv = roadTex(true), th = roadTex(false);
  const asphalt = mat(0x3b3e44);
  const R0 = -NR * PITCH - 5, R1 = NR * PITCH + 5;
  for (let i = -NR; i <= NR; i++) {
    const vLen = R1 - R0;
    const tV = tv.clone(); tV.needsUpdate = true; tV.repeat.set(1, vLen / 18);
    const v = new THREE.Mesh(new THREE.PlaneGeometry(ROAD, vLen).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ map: tV }));
    v.position.set(i * PITCH, .03, 0); v.receiveShadow = true; scene.add(v);
    const x1 = i === 0 ? 215 : R1, len = x1 - R0;
    const tH = th.clone(); tH.needsUpdate = true; tH.repeat.set(len / 18, 1);
    const hz = new THREE.Mesh(new THREE.PlaneGeometry(len, ROAD).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ map: tH }));
    hz.position.set(R0 + len / 2, .035, i * PITCH); hz.receiveShadow = true; scene.add(hz);
  }
  for (let i = -NR; i <= NR; i++) for (let j = -NR; j <= NR; j++) {
    const q = new THREE.Mesh(new THREE.PlaneGeometry(ROAD, ROAD).rotateX(-Math.PI / 2), asphalt);
    q.position.set(i * PITCH, .05, j * PITCH); q.receiveShadow = true; scene.add(q);
    addIntersectionDetails(i, j);
  }

  // blocks and buildings
  for (let i = -NR; i < NR; i++) for (let j = -NR; j < NR; j++) fillBlock(i * PITCH + 25, j * PITCH + 25);

  // street lights
  const poleG = new THREE.CylinderGeometry(.09, .12, 6.5, 6), headG = new THREE.BoxGeometry(1.4, .16, .4);
  const poles = new THREE.InstancedMesh(poleG, mat(0x555a60), 200), heads = new THREE.InstancedMesh(headG, lampMat, 200);
  const mm = new THREE.Matrix4(); let n = 0;
  for (let i = -NR; i <= NR; i++) for (let j = -NR; j <= NR; j++) for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    if (n >= 200) break;
    const x = i * PITCH + sx * 6.5, z = j * PITCH + sz * 6.5;
    mm.makeTranslation(x, 3.25, z); poles.setMatrixAt(n, mm);
    mm.makeTranslation(x - sx * .6, 6.4, z); heads.setMatrixAt(n, mm); n++;
  }
  poles.count = n; heads.count = n;
  poles.castShadow = true;
  scene.add(poles, heads);

  // beach, sea, pier
  const sand = new THREE.Mesh(new THREE.PlaneGeometry(1000, SEA_Z - 155).rotateX(-Math.PI / 2), mat(0xe6d3a0));
  sand.position.set(170, .02, (SEA_Z + 155) / 2); sand.receiveShadow = true; scene.add(sand);
  waterTex = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = '#2380c4'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 260; i++) { g.strokeStyle = Math.random() < .5 ? 'rgba(255,255,255,.18)' : 'rgba(10,60,120,.22)'; g.lineWidth = 1 + Math.random() * 2; const x = Math.random() * w, y = Math.random() * h; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + 10, y - 3, x + 22, y); g.stroke(); }
  });
  waterTex.repeat.set(160, 60);
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(2600, 900).rotateX(-Math.PI / 2), new THREE.MeshPhongMaterial({ map: waterTex, shininess: 90, specular: 0x88aacc }));
  sea.position.set(170, -.35, SEA_Z + 450); scene.add(sea);
  const foam = bx(1000, .02, 3, 0xffffff); foam.position.set(170, .04, SEA_Z - 1); foam.material = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .55 }); scene.add(foam);
  const pier = bx(6, .5, 56, 0x8b6b43); pier.position.set(60, .35, SEA_Z + 22); pier.receiveShadow = true; scene.add(pier);
  for (let k = 0; k < 8; k++) for (const s of [-1, 1]) { const p = bx(.4, 2, .4, 0x5d4630); p.position.set(60 + s * 2.8, -.3, SEA_Z - 4 + k * 7); scene.add(p); }
  for (let x = -280; x < 620; x += rnd(10, 22)) if (Math.abs(x - 60) > 8) addPalm(x, rnd(160, 178));
  addBuilding(-40, 170, 8, 6, 4);   // lifeguard hut
  addBench(-20, 165, 0); addBench(120, 165, 0);

  buildAirport();
  buildMinimapBase();
}

function buildAirport() {
  const rw = canvasTex(256, 64, (g, w, h) => {
    g.fillStyle = '#2c2f34'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#f1f1f1'; g.fillRect(8, h / 2 - 1.5, 120, 3);
    g.fillRect(0, 3, w, 1.5); g.fillRect(0, h - 4.5, w, 1.5);
  });
  rw.repeat.set(400 / 64, 1);
  const run = new THREE.Mesh(new THREE.PlaneGeometry(400, 26).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ map: rw }));
  run.position.set(400, .04, -110); run.receiveShadow = true; scene.add(run);
  const apron = new THREE.Mesh(new THREE.PlaneGeometry(85, 55).rotateX(-Math.PI / 2), mat(0x9b9b98));
  apron.position.set(257.5, .04, -32.5); apron.receiveShadow = true; scene.add(apron);
  const term = bx(70, 14, 14, 0xe8edf2); term.position.set(258, 7.2, -72); term.castShadow = true; term.receiveShadow = true; scene.add(term);
  const glass = bx(70.4, 5, 14.4, 0x2d5575); glass.position.set(258, 4.2, -72); scene.add(glass);
  const roofT = bx(74, 1, 18, 0xc9ced6); roofT.position.set(258, 14.7, -72); roofT.castShadow = true; scene.add(roofT);
  addCollider(258, -72, 70, 14, 14);
  const tw = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 3, 30, 12), mat(0xd7dbe0)); tw.position.set(330, 15, -72); tw.castShadow = true; scene.add(tw);
  const cab = new THREE.Mesh(new THREE.CylinderGeometry(5, 3.6, 5, 12), mat(0x3b6d8f)); cab.position.set(330, 32, -72); scene.add(cab);
  addCollider(330, -72, 6, 6, 36);
  for (const hx of [385, 435]) { const h = bx(40, 14, 28, 0xb0b8c0); h.position.set(hx, 7.2, -62); h.castShadow = true; h.receiveShadow = true; scene.add(h); addCollider(hx, -62, 40, 28, 14); }
  mapRects.push({ x: 400, z: -110, w: 400, d: 26, c: '#4a4d54' }, { x: 257.5, z: -32.5, w: 85, d: 55, c: '#9b9b98' },
    { x: 258, z: -72, w: 70, d: 14, c: '#e8edf2' }, { x: 385, z: -62, w: 40, d: 28, c: '#b0b8c0' }, { x: 435, z: -62, w: 40, d: 28, c: '#b0b8c0' });
}

function buildMinimapBase() {
  const ox = 300, oz = 300, c = document.createElement('canvas');
  c.width = 940; c.height = 560;
  const g = c.getContext('2d');
  g.fillStyle = '#5f8e4c'; g.fillRect(0, 0, 940, 560);
  g.fillStyle = '#e0cd9c'; g.fillRect(0, 155 + oz, 940, SEA_Z - 155);
  g.fillStyle = '#2d79b8'; g.fillRect(0, SEA_Z + oz, 940, 560);
  g.fillStyle = '#8b6b43'; g.fillRect(57 + ox, SEA_Z + oz, 6, 50);
  g.fillStyle = '#444850';
  for (let i = -NR; i <= NR; i++) {
    g.fillRect(i * PITCH - 5 + ox, -155 + oz, 10, 310);
    g.fillRect(-155 + ox, i * PITCH - 5 + oz, i === 0 ? 372 : 310, 10);
  }
  for (const r of mapRects) { g.fillStyle = r.c; g.fillRect(r.x - r.w / 2 + ox, r.z - r.d / 2 + oz, r.w, r.d); }
  mapBase = { canvas: c, ox, oz };
}

function resizeWorld() {
  const [w, h] = localSize();
  const pr = Math.min(curPR == null ? maxPixelRatio() : curPR, maxPixelRatio()); curPR = pr;
  renderer.setPixelRatio(pr);
  renderer.setSize(w, h, false);
  camera.aspect = w / h; camera.updateProjectionMatrix();
}
function updateOrientation() {
  document.documentElement.classList.toggle('rot', innerHeight > innerWidth);
  if (renderer) resizeWorld();
}
addEventListener('resize', updateOrientation);
updateOrientation();
