// ===== world: ground, sky, ruined village, props =====
const emitters = []; // static smoke/fire sources {x,y,z,kind}
const bldRects = [];

function buildGround() {
  const T = MAP.ground, g = new THREE.PlaneGeometry(1400, 1400, 140, 140); g.rotateX(-Math.PI / 2);
  const pos = g.attributes.position, cols = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i), r = Math.hypot(x, z);
    const n = vn(x * 0.02, z * 0.02), n2 = vn(x * 0.09, z * 0.09);
    pos.setY(i, sstep(100, 230, r) * (n * 26 + n2 * 4) * (MAP.hill || 1));
    const gr = sstep(60, 140, r), k = 0.8 + n * 0.4 + n2 * 0.15;
    cols[i * 3] = lerp(T.inn[0], T.out[0], gr) * k; cols[i * 3 + 1] = lerp(T.inn[1], T.out[1], gr) * k; cols[i * 3 + 2] = lerp(T.inn[2], T.out[2], gr) * k;
  }
  g.setAttribute('color', new THREE.BufferAttribute(cols, 3)); g.computeVertexNormals();
  const t = groundTex(T); t.repeat.set(140, 140);
  const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: t, vertexColors: true, roughness: 1 }));
  m.receiveShadow = true; m.userData.ownMat = true; scene.add(m); WORLD.push(m);
}

let skyMesh, skyU;
function buildSky() {
  const S = MAP.sky; skyU = { uSun: { value: SUN_DIR.clone() }, uTime: { value: 0 }, uHor: { value: new THREE.Vector3(...S.hor) }, uMid: { value: new THREE.Vector3(...S.mid) }, uTop: { value: new THREE.Vector3(...S.top) },
    uSunC: { value: new THREE.Vector3(...S.sunC) }, uCD: { value: new THREE.Vector3(...S.cd) }, uCL: { value: new THREE.Vector3(...S.cl) }, uStars: { value: S.stars || 0 }, uCloud: { value: S.cloud === undefined ? .75 : S.cloud } };
  const mat = new THREE.ShaderMaterial({
    uniforms: skyU, side: THREE.BackSide, depthWrite: false, fog: false,
    vertexShader: 'varying vec3 vD; void main(){ vD=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader: `varying vec3 vD; uniform vec3 uSun,uHor,uMid,uTop,uSunC,uCD,uCL; uniform float uTime,uStars,uCloud;
float hs(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float ns(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hs(i),hs(i+vec2(1,0)),f.x),mix(hs(i+vec2(0,1)),hs(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<5;i++){s+=a*ns(p);p*=2.02;a*=.5;}return s;}
void main(){
  vec3 d=normalize(vD); float h=clamp(d.y,0.,1.);
  vec3 col=mix(uHor,uMid,smoothstep(0.,.18,h)); col=mix(col,uTop,smoothstep(.1,.7,h));
  float sd=max(dot(d,normalize(uSun)),0.);
  col+=uSunC*pow(sd,8.)*.6+mix(uSunC,vec3(1.),.6)*pow(sd,220.)*2.;
  if(uStars>0.&&d.y>0.02){ vec2 q=d.xz/(d.y+.3)*140.; float st=step(.992,hs(floor(q))); col+=vec3(.9,.95,1.)*st*uStars*smoothstep(.03,.3,d.y)*(.5+.5*hs(floor(q)+7.)); }
  if(d.y>0.01){ vec2 uv=d.xz/(d.y+.25)*1.2+vec2(uTime*.012,0.); float c=smoothstep(.45,.8,fbm(uv*1.5));
    vec3 cc=mix(uCD,uCL,pow(sd,2.)); col=mix(col,cc,c*uCloud*smoothstep(0.01,.2,d.y)); }
  col=mix(col,uHor,smoothstep(0.,-.08,d.y));
  gl_FragColor=vec4(col,1.);
}`
  });
  skyMesh = new THREE.Mesh(new THREE.SphereGeometry(520, 32, 16), mat);
  skyMesh.frustumCulled = false; skyMesh.renderOrder = -10; scene.add(skyMesh); WORLD.push(skyMesh);
}

// ---- ruined buildings ----
function wallRun(ax, fixed, from, to, h, T, ruin, doorPos) {
  const put = (a, b, y0, y1) => {
    if (b - a < 0.05 || y1 - y0 < 0.05) return;
    const x0 = ax === 'x' ? a : fixed - T / 2, x1 = ax === 'x' ? b : fixed + T / 2;
    const z0 = ax === 'x' ? fixed - T / 2 : a, z1 = ax === 'x' ? fixed + T / 2 : b;
    boxAt(B.brick, x0, y0, z0, x1, y1, z1, 0.5);
    if (y0 < 0.3) col(x0, z0, x1, z1, y1);
  };
  let p = from;
  while (p < to - 0.05) {
    const pw = Math.min(rr(1.0, 2.2), to - p);
    if (ruin && SR() < 0.12) { put(p, p + pw, 0, rr(0.5, 1.1)); p += pw; continue; }
    const ph = ruin ? h * (SR() < 0.4 ? 1 : rr(0.45, 0.95)) : h;
    put(p, p + pw, 0, Math.max(ph, 1.2)); p += pw;
    if (p >= to - 0.4) { if (p < to) put(p, to, 0, Math.max(ph, 1.2)); break; }
    const gw = Math.min(rr(1.4, 2.1), to - p), door = doorPos !== null && Math.abs(p + gw / 2 - doorPos) < 1.2;
    const gh = ruin ? h * rr(0.5, 1) : h;
    if (door) { if (gh > 2.9 && SR() < 0.7) put(p, p + gw, 2.5, gh); }
    else { put(p, p + gw, 0, 1.0); if (gh > 2.7 && SR() < 0.7) put(p, p + gw, 2.4, gh); }
    p += gw;
  }
}
function building(cx, cz, w, d, h, ruin) {
  const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2, T = 0.45, ds = Math.floor(SR() * 4);
  wallRun('x', z0, x0 - T / 2, x1 + T / 2, h, T, ruin, ds === 0 ? cx + rr(-w / 4, w / 4) : null);
  wallRun('x', z1, x0 - T / 2, x1 + T / 2, h, T, ruin, ds === 1 ? cx + rr(-w / 4, w / 4) : null);
  wallRun('z', x0, z0 + T / 2, z1 - T / 2, h, T, ruin, ds === 2 ? cz + rr(-d / 4, d / 4) : null);
  wallRun('z', x1, z0 + T / 2, z1 - T / 2, h, T, ruin, ds === 3 ? cz + rr(-d / 4, d / 4) : null);
  boxAt(B.concrete, x0, 0, z0, x1, 0.1, z1, 0.25, 0.9);
  if (ruin && SR() < 0.7) boxAt(B.concrete, x0, h, z0, x0 + w * rr(0.35, 0.65), h + 0.22, z1, 0.25, 0.7);
  if (w > 10 && SR() < 0.6) { const mz = cz + rr(-1, 1); wallRun('x', mz, x0 + 1, x0 + w * 0.55, h * 0.8, 0.3, true, x0 + w * 0.3); }
  for (let i = 0; i < 4; i++) {
    const rx = rr(x0 + 1, x1 - 1), rz = rr(z0 + 1, z1 - 1), s = rr(0.5, 1.2), hh = rr(0.3, 0.9);
    boxRot(B.concrete, rx, hh / 2, rz, s, hh, s * rr(0.7, 1.5), rr(0, 3), 0.5, rr(0.6, 0.9), rr(-.1, .1), rr(-.1, .1));
    if (hh > 0.5) col(rx - s / 2, rz - s / 2, rx + s / 2, rz + s / 2, hh);
  }
  if (MAP.neon) for (let i = 0; i < 9; i++) { const side = Math.floor(SR() * 4), y = rr(2.2, Math.max(2.4, h - .6)), u = SR(), c = SR() < .5 ? [1, .78, .4] : SR() < .5 ? [.4, .9, 1] : [1, .4, .7];
    if (side < 2) boxAt(B.neon, x0 + 1 + u * (w - 2), y, (side ? z1 : z0) + (side ? .24 : -.24), x0 + 1.9 + u * (w - 2), y + .6, (side ? z1 : z0) + (side ? .3 : -.3), 1, c);
    else boxAt(B.neon, (side === 2 ? x0 : x1) + (side === 2 ? -.24 : .24), y, z0 + 1 + u * (d - 2), (side === 2 ? x0 : x1) + (side === 2 ? -.3 : .3), y + .6, z0 + 1.9 + u * (d - 2), 1, c); }
  bldRects.push({ x0: x0 - 4, x1: x1 + 4, z0: z0 - 4, z1: z1 + 4 });
}
function free(x, z, r) {
  if (Math.hypot(x, z) > ARENA - 4) return false;
  for (const b of bldRects) if (x > b.x0 && x < b.x1 && z > b.z0 && z < b.z1) return false;
  for (const c of colliders) if (x > c.x0 - r && x < c.x1 + r && z > c.z0 - r && z < c.z1 + r) return false;
  return true;
}

// ---- props ----
function crate(x, z, s, stack) {
  boxRot(B.wood, x, s / 2, z, s, s, s, rr(-.15, .15), 1 / s, rr(.8, 1.1)); col(x - s / 2, z - s / 2, x + s / 2, z + s / 2, s, true);
  if (stack) { boxRot(B.wood, x + s * .2, s * 1.5, z, s, s, s, rr(-.3, .3), 1 / s, rr(.8, 1.1)); col(x + s * .2 - s / 2, z - s / 2, x + s * .2 + s / 2, z + s / 2, s * 2, true); }
}
function sandbags(x, z, len, alongX) {
  const t = 0.7, h = 1.15;
  const x0 = alongX ? x - len / 2 : x - t / 2, x1 = alongX ? x + len / 2 : x + t / 2, z0 = alongX ? z - t / 2 : z - len / 2, z1 = alongX ? z + t / 2 : z + len / 2;
  boxAt(B.sand, x0, 0, z0, x1, h, z1, 1, rr(.85, 1)); col(x0, z0, x1, z1, h, true);
}
function barrel(x, z, burning) {
  const t = burning ? [.5, .4, .35] : [rr(.5, 1), rr(.5, .8), rr(.5, .7)];
  cylAt(B.metal, x, 0.45, z, 0.3, 0.3, 0.9, 10, t); col(x - .3, z - .3, x + .3, z + .3, 0.9, true);
  if (burning) emitters.push({ x, y: 1.0, z, kind: 'fire' });
}
function jersey(x, z, alongX) {
  const l = 3, t = 0.6, h = 1.05;
  const x0 = alongX ? x - l / 2 : x - t / 2, x1 = alongX ? x + l / 2 : x + t / 2, z0 = alongX ? z - t / 2 : z - l / 2, z1 = alongX ? z + t / 2 : z + l / 2;
  boxAt(B.concrete, x0, 0, z0, x1, h, z1, 0.5, rr(.8, 1)); col(x0, z0, x1, z1, h, true);
}
function hedgehog(x, z) {
  for (let i = 0; i < 3; i++) boxRot(B.metal, x, .6, z, 0.12, 1.5, 0.12, 0, 1, .7, i === 0 ? .78 : i === 1 ? 0 : -.78, i === 1 ? 0.78 : (i === 0 ? 0 : .78));
  col(x - .6, z - .6, x + .6, z + .6, 1.2, true);
}
function wreck(x, z, alongX) {
  const w = alongX ? 5.6 : 2.5, d = alongX ? 2.5 : 5.6;
  boxAt(B.rust, x - w / 2, 0.5, z - d / 2, x + w / 2, 1.7, z + d / 2, 0.4, .8);
  boxAt(B.rust, alongX ? x + 1.2 : x - 1.2, 1.7, alongX ? z - 1.1 : z + .0, alongX ? x + 2.8 : x + 1.2, 2.5, alongX ? z + 1.1 : z + 1.9, 0.4, .6);
  for (const sx of [-1, 1]) for (const sz of [-.4, .4]) cylAt(B.dark, alongX ? x + sx * 1.8 : x + sz * 3.4, 0.45, alongX ? z + sz * 3.4 : z + sx * 1.8, .5, .5, .4, 10, .8, alongX ? Math.PI / 2 : 0, alongX ? 0 : Math.PI / 2);
  col(x - w / 2, z - d / 2, x + w / 2, z + d / 2, 2.0);
  emitters.push({ x, y: 2.2, z, kind: 'smoke' });
  if (SR() < 0.5) emitters.push({ x, y: 1.8, z, kind: 'fire' });
}
function deadTree(x, z) {
  const h = rr(4, 7); cylAt(B.wood, x, h / 2, z, 0.12, 0.3, h, 7, .45);
  for (let i = 0; i < 4; i++) { const a = rr(0, 6.28), y = rr(h * .4, h * .9); cylAt(B.wood, x + Math.cos(a) * .6, y, z + Math.sin(a) * .6, 0.03, 0.09, 1.8, 5, .45, Math.sin(a) * .9, -Math.cos(a) * .9); }
  col(x - .3, z - .3, x + .3, z + .3, 6, true);
}
function craters() {
  const b = new Batch(new THREE.MeshBasicMaterial({ map: craterTex(), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, vertexColors: true, fog: true }), false);
  for (let i = 0; i < 40; i++) {
    const a = SR() * 6.28, r = Math.sqrt(SR()) * (ARENA - 6), s = rr(2.5, 7);
    const g = new THREE.PlaneGeometry(s, s); g.rotateX(-Math.PI / 2);
    b.add(g, new THREE.Matrix4().makeTranslation(Math.cos(a) * r, 0.03, Math.sin(a) * r), 1); g.dispose();
  }
  b.build();
}
function cactus(x, z) {
  const h = rr(1.8, 3.4); cylAt(B.cactus, x, h / 2, z, .26, .3, h, 8, 1);
  for (const sd of [-1, 1]) if (SR() < .7) { const ah = rr(.8, 1.4); cylAt(B.cactus, x + sd * .55, h * .55, z, .5, .5, .22, 6, 1, 0, Math.PI / 2); cylAt(B.cactus, x + sd * .8, h * .55 + ah / 2, z, .18, .2, ah, 7, 1); }
  col(x - .32, z - .32, x + .32, z + .32, h, true);
}
function palm(x, z) {
  const h = rr(5, 8), lx = rr(-.6, .6); cylAt(B.wood, x + lx / 2, h / 2, z, .14, .24, h, 7, .9, 0, -lx / h);
  for (let i = 0; i < 7; i++) { const a = i / 7 * 6.283 + rr(-.2, .2); boxRot(B.leaf, x + lx + Math.cos(a) * 1.5, h - .15, z + Math.sin(a) * 1.5, 3.4, .06, .9, -a, 1, rr(.8, 1.1), 0, Math.cos(a) * .0 + .35); }
  col(x - .3, z - .3, x + .3, z + .3, h, true);
}
function pine(x, z, snowy) {
  const h = rr(6, 10), n = 4; cylAt(B.wood, x, 1.2, z, .18, .3, 2.4, 6, .7);
  for (let i = 0; i < n; i++) { const r = lerp(2.6, .8, i / n) * rr(.9, 1.1), y = 2 + i * (h - 2.5) / n; cylAt(B.pine, x, y + .9, z, 0.1, r, 2.3, 8, rr(.85, 1.1)); if (snowy) cylAt(B.snow, x, y + 1.35, z, .05, r * .8, 1.5, 8, 1); }
  col(x - .32, z - .32, x + .32, z + .32, h, true);
}
function jtree(x, z) {
  const h = rr(6, 9); cylAt(B.wood, x, h / 2, z, .3, .5, h, 7, .55);
  for (let i = 0; i < 3; i++) cylAt(B.leaf, x + rr(-1, 1), h - .5 + i * .9, z + rr(-1, 1), rr(1.6, 2.4), rr(2.6, 3.6), .9, 9, rr(.7, 1.1));
  col(x - .5, z - .5, x + .5, z + .5, h, true);
}
function boulder(x, z, key, sc) {
  const s = (sc || 1) * rr(1.4, 3), hh = s * rr(.6, 1); boxRot(B[key || 'rock'], x, hh / 2, z, s, hh, s * rr(.8, 1.3), rr(0, 3), .7, rr(.7, 1), rr(-.15, .15), rr(-.15, .15));
  boxRot(B[key || 'rock'], x + s * .3, hh * .9, z - s * .2, s * .6, hh * .6, s * .6, rr(0, 3), .7, rr(.8, 1.1), .2, .1);
  col(x - s * .5, z - s * .5, x + s * .5, z + s * .5, hh * 1.1, true);
}
function lavaRock(x, z) { boulder(x, z, 'lava'); if (SR() < .5) emitters.push({ x, y: 1.0, z, kind: 'fire' }); }
function drift(x, z) { const w = rr(3, 6), d = rr(2, 3.5); boxRot(B.snow, x, .35, z, w, .7, d, rr(0, 3), .6, 1); col(x - w / 2, z - d / 2, x + w / 2, z + d / 2, .6, true); }
function lamp(x, z) {
  cylAt(B.metal, x, 2.8, z, .07, .1, 5.6, 6, .8); boxAt(B.neon, x - .3, 5.5, z - .12, x + .3, 5.65, z + .12, 1, [1, .85, .55]); col(x - .12, z - .12, x + .12, z + .12, 5.6, true);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: 0xffc880, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); sp.scale.setScalar(9); sp.position.set(x, 5.3, z); scene.add(sp); WORLD.push(sp);
}
function sandPatch(x, z) { const w = rr(3, 6); boxAt(B.sandst, x - w / 2, 0, z - w / 2, x + w / 2, .4, z + w / 2, .6, 1); col(x - w / 2, z - w / 2, x + w / 2, z + w / 2, .4, true); }
function skyline() {
  const K = MAP.sky.kind, sc = MAP.sky.sil, b = new Batch(new THREE.MeshBasicMaterial({ vertexColors: true, fog: true }), false);
  if (K === 'ruins' || K === 'city') for (let i = 0; i < 70; i++) {
    const a = i / 70 * 6.283 + SR() * .05, r = rr(150, 200), w = rr(8, 22), h = K === 'city' ? rr(20, 90) : rr(8, 46);
    const g = new THREE.BoxGeometry(w, h, w * rr(.6, 1.2)); b.add(g, new THREE.Matrix4().makeTranslation(Math.cos(a) * r, h / 2 - 2, Math.sin(a) * r), sc); g.dispose();
  } else for (let i = 0; i < 46; i++) {
    const a = i / 46 * 6.283 + SR() * .08, r = rr(190, 260), w = rr(30, 90), h = K === 'mountains' ? rr(40, 120) : K === 'mesas' ? rr(14, 38) : K === 'volcano' ? rr(20, 70) : rr(12, 30);
    const g = K === 'mesas' ? new THREE.CylinderGeometry(w * .35, w * .5, h, 7) : K === 'jungle' ? new THREE.SphereGeometry(w * .45, 8, 6) : new THREE.ConeGeometry(w * .5, h, 7);
    b.add(g, new THREE.Matrix4().makeTranslation(Math.cos(a) * r, K === 'jungle' ? h * .2 : h / 2 - 3, Math.sin(a) * r), sc); g.dispose();
  }
  b.build();
  const st = new THREE.Group(), pc = MAP.sky.plume;
  for (let k = 0; k < 4; k++) {
    const a = k * 1.6 + 0.4, r = rr(230, 280);
    for (let j = 0; j < 9; j++) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: new THREE.Color().setHSL(pc[0], pc[1], pc[2] + j * .02), transparent: true, opacity: pc[3], depthWrite: false, fog: false }));
      s.scale.setScalar(40 + j * 14); s.position.set(Math.cos(a) * r + j * 6, 10 + j * 22, Math.sin(a) * r); st.add(s);
    }
    const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: MAP.sky.glow, transparent: true, opacity: .55, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
    gl.scale.set(70, 40, 1); gl.position.set(Math.cos(a) * r, 8, Math.sin(a) * r); st.add(gl);
  }
  scene.add(st); WORLD.push(st);
}
function clearWorld() {
  for (const m of WORLD) { scene.remove(m); m.traverse && m.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.userData && o.userData.ownMat) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } }); }
  WORLD.length = 0; colliders.length = 0; emitters.length = 0; bldRects.length = 0;
}
let PIT_PROP0;
function buildPit() {
  const W = 40, D = 28, T = .9, Hh = 6.5, wl = (x0, z0, x1, z1) => { boxAt(B.concrete, x0, 0, z0, x1, Hh, z1, .35, .95); col(x0, z0, x1, z1, Hh); };
  wl(-W - T, -D - T, W + T, -D); wl(-W - T, D, W + T, D + T); wl(-W - T, -D, -W, D); wl(W, -D, W + T, D);
  for (let i = -3; i <= 3; i++) { boxAt(B.metal, i * 11 - .5, Hh, -D - T, i * 11 + .5, Hh + 1.6, -D, 1, .8); boxAt(B.metal, i * 11 - .5, Hh, D, i * 11 + .5, Hh + 1.6, D + T, 1, .8); }
  const blk = (cx, cz, w, d, h) => { boxAt(B.concrete, cx - w / 2, 0, cz - d / 2, cx + w / 2, h, cz + d / 2, .5, .9 + SR() * .1); col(cx - w / 2, cz - d / 2, cx + w / 2, cz + d / 2, h); };
  const mir = (fn) => { fn(1); fn(-1); };
  blk(0, 0, 6, 6, 3.4);
  mir(s => { jersey(s * 13, -9, false); jersey(s * 13, 9, false); jersey(s * 13, -6, false); jersey(s * 13, 6, false); sandbags(s * 21, 0, 7, false); crate(s * 21, -13, 1.6, true); crate(s * 21, 13, 1.6, true); sandbags(s * 29, -7, 5, true); sandbags(s * 29, 7, 5, true); blk(s * 8, -19, 7, 2, 2.2); blk(s * 8, 19, 7, 2, 2.2); hedgehog(s * 5, -9); hedgehog(s * 5, 9); barrel(s * 17, -3, false); barrel(s * 17, 3, false); crate(s * 35, 0, 1.4, false); });
  boxAt(B.concrete, -3, 0, -14, 3, 1.3, -13, .5, .9); col(-3, -14, 3, -13, 1.3, true); boxAt(B.concrete, -3, 0, 13, 3, 1.3, 14, .5, .9); col(-3, 13, 3, 14, 1.3, true);
  // team zones
  for (const s of [-1, 1]) boxAt(B.metal, s * 38 - .3, .02, -6, s * 38 + .3, .06, 6, 1, s < 0 ? .5 : 1.2);
  skyline();
  PIT_PROP0 = WORLD.length; for (const k in B) B[k].build();
}
function buildWorld() {
  buildGround(); buildSky();
  if (MAP.pit) { buildPit(); return; }
  bldRects.push({ x0: 10, x1: 100, z0: -9, z1: 9 }); // landing lane for the transport vehicles
  // player fort at the centre
  sandbags(0, -7, 9, true); sandbags(-8, -3, 5, false); sandbags(8, -3, 5, false); sandbags(-5, 7, 4, true); sandbags(5, 7, 4, true);
  crate(-3, -4.5, 1.2, true); crate(3.4, -4.6, 1.2, false); crate(0, 5, 1.2, false);
  // buildings
  let tries = 0, made = 0; const BM = MAP.bld;
  while (made < BM.n && tries++ < 300) {
    const w = rr(8, 15), d = rr(7, 12), a = SR() * 6.283, r = rr(24, 78), cx = Math.cos(a) * r, cz = Math.sin(a) * r;
    if (Math.hypot(cx, cz) + Math.max(w, d) / 2 > ARENA - 3) continue;
    let ok = true;
    for (const b of bldRects) if (cx + w / 2 + 6 > b.x0 && cx - w / 2 - 6 < b.x1 && cz + d / 2 + 6 > b.z0 && cz - d / 2 - 6 < b.z1) { ok = false; break; }
    if (!ok) continue;
    building(cx, cz, w, d, rr(BM.h[0], BM.h[1]), SR() < BM.ruin); made++;
  }
  const scatter = (n, fn, r) => { let k = 0, t = 0; while (k < n && t++ < n * 12) { const a = SR() * 6.283, d = Math.sqrt(SR()) * (ARENA - 6), x = Math.cos(a) * d, z = Math.sin(a) * d; if (d < 13 || !free(x, z, r)) continue; fn(x, z); k++; } };
  for (const [n, fn, r] of MAP.props) scatter(n, fn, r);
  for (let i = 0; i < 64; i++) { const a = i / 64 * 6.283; { const rx = Math.cos(a) * (ARENA - 1.5), rz = Math.sin(a) * (ARENA - 1.5); if (!(rx > 0 && Math.abs(rz) < 10)) MAP.ring(rx, rz); } }
  craters(); skyline();
  for (const k in B) B[k].build();
}
