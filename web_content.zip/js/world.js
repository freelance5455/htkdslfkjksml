/* world.js — builds provinces (Voronoi polygons), adjacency, terrain, resources, capitals. */
(function (G) {
  'use strict';

  // Deterministic PRNG so the world is identical every launch (saves stay valid).
  function rng(seed) {
    let s = seed >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  G.rng = rng;

  G.buildWorld = function () {
    const S = G.scenario || {};
    if (S.type === 'poly') return buildPolyWorld(S);
    G.landRings = null; G.landMask = null;
    return buildGridWorld();
  };

  function buildGridWorld() {
    const rand = rng(20261014);
    const L = G.LAYOUT, C = G.CELL;
    const sites = [];
    for (let r = 0; r < L.length; r++) {
      for (let c = 0; c < L[r].length; c++) {
        const ch = L[r][c];
        sites.push({
          id: sites.length, row: r, col: c,
          x: c * C + C / 2 + (rand() - 0.5) * C * 0.55,
          y: r * C + C / 2 + (rand() - 0.5) * C * 0.55,
          owner: ch === '.' ? null : ch
        });
      }
    }
    const W = G.WORLD_W, H = G.WORLD_H;
    const provinces = sites.map(s => ({
      id: s.id, x: s.x, y: s.y, owner: s.owner, sea: s.owner === null,
      poly: [], adj: [], name: '', terrain: 'plains', capital: false, fort: 0
    }));

    // Voronoi via half-plane clipping against nearby sites (plenty fast for ~100 sites).
    for (const s of sites) {
      let poly = [{ x: 0, y: 0, e: -1 }, { x: W, y: 0, e: -1 }, { x: W, y: H, e: -1 }, { x: 0, y: H, e: -1 }];
      const near = sites.filter(o => o !== s).sort((p, q) =>
        ((p.x - s.x) ** 2 + (p.y - s.y) ** 2) - ((q.x - s.x) ** 2 + (q.y - s.y) ** 2));
      for (const o of near) {
        // points closer to s than o: (o-s)·p <= (|o|^2-|s|^2)/2
        const a = o.x - s.x, b = o.y - s.y;
        const c = (o.x * o.x + o.y * o.y - s.x * s.x - s.y * s.y) / 2;
        poly = clipLabeled(poly, a, b, c, o.id);
        if (poly.length < 3) break;
      }
      provinces[s.id].poly = poly;
    }

    // Adjacency from edge labels; only keep land-land and land-sea (sea kept for coast detection).
    for (const p of provinces) {
      const set = new Set();
      for (const v of p.poly) if (v.e >= 0) set.add(v.e);
      p.nbrs = Array.from(set);
    }
    // Symmetrise
    for (const p of provinces) for (const n of p.nbrs) {
      if (!provinces[n].nbrs.includes(p.id)) provinces[n].nbrs.push(p.id);
    }
    for (const p of provinces) {
      p.adj = p.nbrs.filter(n => !provinces[n].sea);
      p.coastal = p.nbrs.some(n => provinces[n].sea) || p.poly.some(v => v.x <= 0.01 || v.y <= 0.01 || v.x >= W - 0.01 || v.y >= H - 0.01);
      let cx = 0, cy = 0;
      for (const v of p.poly) { cx += v.x; cy += v.y; }
      p.cx = cx / p.poly.length; p.cy = cy / p.poly.length;
    }

    // Names, terrain, resources, capitals.
    const counters = {};
    const rr = rng(5050);   // separate stream so older terrain/resources stay unchanged
    const tr = ['plains', 'plains', 'plains', 'forest', 'forest', 'hills', 'hills', 'mountain', 'marsh'];
    for (const p of provinces) {
      if (p.sea) continue;
      const o = p.owner;
      const i = counters[o] = (counters[o] || 0);
      counters[o]++;
      const names = G.PROVINCE_NAMES[o];
      p.name = names[i] || (names[i % names.length] + ' ' + (Math.floor(i / names.length) + 1));
      p.terrain = tr[Math.floor(rand() * tr.length)];
      const base = p.terrain === 'mountain' ? 0.6 : p.terrain === 'plains' ? 1.2 : 1.0;
      p.pop = Math.round((30 + rand() * 90) * base) * 1000;      // inhabitants
      p.income = Math.round((2 + rand() * 6) * base);            // gold/day
      p.manpower = Math.round(p.pop * 0.012 / 10) * 10 + 20;     // manpower pool contribution
      p.res = {
        steel: p.terrain === 'mountain' || p.terrain === 'hills' ? Math.round(rand() * 6) : Math.round(rand() * 2),
        coal: p.terrain === 'hills' || p.terrain === 'mountain' ? Math.round(rand() * 5) : Math.round(rand() * 2),
        oil: rand() < 0.15 ? 1 + Math.round(rand() * 4) : 0,
        food: p.terrain === 'plains' ? 2 + Math.round(rand() * 5) : Math.round(rand() * 3)
      };
      p.res.rubber = (p.terrain === 'marsh' || p.terrain === 'forest') && rr() < 0.4 ? 1 + Math.round(rr() * 3) : (rr() < 0.05 ? 1 : 0);
      p.fort = 0;
      p.infra = 1 + Math.floor(rand() * 3);
    }
    // Capital = land province of each country closest to its centroid; capitals become urban.
    for (const id in G.COUNTRIES) {
      const own = provinces.filter(p => p.owner === id);
      let mx = 0, my = 0;
      own.forEach(p => { mx += p.cx; my += p.cy; });
      mx /= own.length; my /= own.length;
      own.sort((a, b) => ((a.cx - mx) ** 2 + (a.cy - my) ** 2) - ((b.cx - mx) ** 2 + (b.cy - my) ** 2));
      const cap = own[0];
      cap.capital = true; cap.terrain = 'urban';
      cap.pop = 220000; cap.income = 14; cap.infra = 4; cap.fort = 1;
      G.COUNTRIES[id].capitalId = cap.id;
      G.COUNTRIES[id].capital = cap.name;
    }
    G.buildSeaZones(provinces);
    return provinces;
  }

  // Labeled clip: each output vertex's `e` = id of the neighbour whose bisector forms the edge
  // starting at that vertex (going to the next vertex), -1 for map border.
  function clipLabeled(poly, a, b, c, label) {
    const out = [];
    const n = poly.length;
    for (let i = 0; i < n; i++) {
      const p = poly[i], q = poly[(i + 1) % n];
      const dp = a * p.x + b * p.y - c, dq = a * q.x + b * q.y - c;
      const pin = dp <= 0, qin = dq <= 0;
      if (pin && qin) {
        out.push({ x: p.x, y: p.y, e: p.e });
      } else if (pin && !qin) {
        const t = dp / (dp - dq);
        out.push({ x: p.x, y: p.y, e: p.e });
        out.push({ x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t, e: label });
      } else if (!pin && qin) {
        const t = dp / (dp - dq);
        out.push({ x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t, e: p.e });
      }
    }
    return out;
  }

  /* ================= Phase 9: polygon (real-world) scenarios ================= */
  function pip(poly, x, y) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i], b = poly[j];
      if ((a[1] > y) !== (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
    }
    return inside;
  }
  G.makeProj = function (S) {
    const b = S.bounds, kx = S.kx, k = kx * 180 / Math.PI;
    const m = lat => 1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * lat * Math.PI / 180)), y1 = m(b.lat1);
    return { x: lon => (lon - b.lon0) * kx, y: lat => (y1 - m(lat)) * k, W: (b.lon1 - b.lon0) * kx, H: (y1 - m(b.lat0)) * k };
  };
  // Even-odd land mask with row buckets (fast point-in-land test in world units).
  function makeMask(rings, W, H) {
    const RH = 3, rows = Math.ceil(H / RH) + 1, bk = [];
    for (let i = 0; i < rows; i++) bk.push([]);
    rings.forEach(r => {
      for (let i = 0, n = r.length; i < n; i++) {
        const a = r[i], c = r[(i + 1) % n]; if (a[1] === c[1]) continue;
        const lo = Math.max(0, Math.floor(Math.min(a[1], c[1]) / RH)), hi = Math.min(rows - 1, Math.floor(Math.max(a[1], c[1]) / RH));
        for (let k = lo; k <= hi; k++) bk[k].push(a[0], a[1], c[0], c[1]);
      }
    });
    return { has: function (x, y) {
      if (x < 0 || y < 0 || x > W || y > H) return false;
      const e = bk[Math.floor(y / RH)]; let ins = false;
      for (let i = 0; i < e.length; i += 4) { const y1 = e[i + 1], y2 = e[i + 3]; if ((y1 > y) !== (y2 > y) && x < (e[i + 2] - e[i]) * (y - y1) / (y2 - y1) + e[i]) ins = !ins; }
      return ins;
    } };
  }
  function inPolyXY(poly, x, y) {
    let ins = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i], b = poly[j];
      if ((a.y > y) !== (b.y > y) && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) ins = !ins;
    }
    return ins;
  }

  // Shared geometry: Voronoi cells (bucketed, early-terminating), neighbour lists, centroids.
  function voronoi(sites, W, H) {
    const B = 100, bw = Math.ceil(W / B), bh = Math.ceil(H / B), grid = {};
    sites.forEach(s => { const k = Math.floor(s.x / B) + Math.floor(s.y / B) * bw; (grid[k] = grid[k] || []).push(s); });
    const polys = [];
    for (const s of sites) {
      let poly = [{ x: 0, y: 0, e: -1 }, { x: W, y: 0, e: -1 }, { x: W, y: H, e: -1 }, { x: 0, y: H, e: -1 }];
      const bx = Math.floor(s.x / B), by = Math.floor(s.y / B), done = new Set([s.id]);
      let k = 1;
      for (;;) {
        const cand = [];
        for (let yy = by - k; yy <= by + k; yy++) for (let xx = bx - k; xx <= bx + k; xx++) {
          if (xx < 0 || yy < 0 || xx >= bw || yy >= bh) continue;
          const list = grid[xx + yy * bw]; if (!list) continue;
          for (const o of list) if (!done.has(o.id)) { done.add(o.id); cand.push(o); }
        }
        cand.sort((p, q) => ((p.x - s.x) ** 2 + (p.y - s.y) ** 2) - ((q.x - s.x) ** 2 + (q.y - s.y) ** 2));
        for (const o of cand) {
          const a = o.x - s.x, b = o.y - s.y, c = (o.x * o.x + o.y * o.y - s.x * s.x - s.y * s.y) / 2;
          poly = clipLabeled(poly, a, b, c, o.id);
          if (poly.length < 3) break;
        }
        let mx = 0; for (const v of poly) mx = Math.max(mx, Math.hypot(v.x - s.x, v.y - s.y));
        const need = Math.ceil(2 * mx / B) + 1;
        if (need <= k || k > Math.max(bw, bh)) break;
        k = need;
      }
      polys[s.id] = poly;
    }
    return polys;
  }
  G.voronoi = voronoi;

  function geometry(provinces, W, H) {
    for (const p of provinces) {
      const set = new Set();
      for (const v of p.poly) if (v.e >= 0) set.add(v.e);
      p.nbrs = Array.from(set);
    }
    for (const p of provinces) for (const n of p.nbrs) if (!provinces[n].nbrs.includes(p.id)) provinces[n].nbrs.push(p.id);
    for (const p of provinces) {
      p.adj = p.nbrs.filter(n => !provinces[n].sea);
      p.coastal = p.nbrs.some(n => provinces[n].sea);
      let cx = 0, cy = 0;
      for (const v of p.poly) { cx += v.x; cy += v.y; }
      p.cx = cx / p.poly.length; p.cy = cy / p.poly.length;
    }
  }

  function buildPolyWorld(S) {
    const rand = rng(20261112), b = S.bounds;
    const PR = S.proj = G.makeProj(S), W = PR.W, H = PR.H;
    G.WORLD_W = S.w = Math.round(W); G.WORLD_H = S.h = Math.round(H);
    const toX = PR.x, toY = PR.y;
    const rings = []; S.land.forEach(pl => pl.forEach(r => { const q = []; for (let i = 0; i < r.length; i += 2) q.push([toX(r[i]), toY(r[i + 1])]); rings.push(q); }));
    const mask = makeMask(rings, W, H);
    G.landRings = rings; G.landMask = mask;
    const isLandW = (lon, lat) => mask.has(toX(lon), toY(lat));
    const WINS = [
      { lon0: -12, lon1: 48, lat0: 28, lat1: 71, dx: 3.6, dy: 2.9 },       // Europe / Mediterranean / Near East
      { lon0: -118, lon1: -60, lat0: 8, lat1: 33, dx: 5.6, dy: 4.6 },      // Mexico / Caribbean
      { lon0: 100, lon1: 147, lat0: 20, lat1: 47, dx: 5.2, dy: 4.4 },      // East Asia
      { lon0: 66, lon1: 100, lat0: 5, lat1: 32, dx: 6.2, dy: 5.2 },        // India / Bay of Bengal
      { lon0: 95, lon1: 128, lat0: -10, lat1: 20, dx: 6.2, dy: 5.2 }       // South-East Asia
    ];
    const inW = (w, lon, lat, m) => lon >= w.lon0 - m && lon <= w.lon1 + m && lat >= w.lat0 - m && lat <= w.lat1 + m;
    const inAnyWin = (lon, lat, m) => WINS.some(w => inW(w, lon, lat, m));
    // 1. candidate sites: denser hex grids inside the windows, coarse everywhere else
    const cand = [];
    const dxM = 9.0, dyM = 7.5;
    WINS.forEach((w, wi) => {
      for (let j = 0, lat = w.lat0; lat <= w.lat1; lat += w.dy, j++)
        for (let i = 0, lon = w.lon0 + (j % 2 ? w.dx / 2 : 0); lon <= w.lon1; lon += w.dx, i++) {
          const lo = lon + (rand() - 0.5) * w.dx * 0.5, la = lat + (rand() - 0.5) * w.dy * 0.5;
          if (WINS.some((o, oi) => oi < wi && inW(o, lo, la, 0))) continue;     // earlier window wins overlaps
          cand.push({ lon: lo, lat: la, dense: true, gi: i, gj: j });
        }
    });
    for (let j = 0, lat = b.lat0 + 2; lat <= b.lat1 - 1; lat += dyM, j++)
      for (let i = 0, lon = b.lon0 + 2 + (j % 2 ? dxM / 2 : 0); lon <= b.lon1 - 1; lon += dxM, i++) {
        if (inAnyWin(lon, lat, 3.2)) continue;
        cand.push({ lon: lon + (rand() - 0.5) * dxM * 0.5, lat: lat + (rand() - 0.5) * dyM * 0.5, dense: false, gi: i, gj: j });
      }
    cand.forEach(c => { c.land = isLandW(c.lon, c.lat); c.x = toX(c.lon); c.y = toY(c.lat); });
    // sparse regions (high north, big deserts) get half the density
    const sparse = c => !c.dense && c.land && (c.lat > 56 || (c.lon > 50 && c.lon < 135 && c.lat > 38) || S.terr.some(t => t[0] === 'desert' && t[3] >= 8 && (c.lon - t[1]) ** 2 * 0.7 + (c.lat - t[2]) ** 2 <= t[3] * t[3]));
    for (let i = cand.length - 1; i >= 0; i--) if (sparse(cand[i]) && (cand[i].gi + cand[i].gj) % 2 === 1) cand.splice(i, 1);
    // every capital city gets a province of its own, centred on the city
    const AV = S.avgCell || 33;
    for (const cid of Object.keys(G.COUNTRIES)) {
      const cp = G.COUNTRIES[cid].cap; if (!cp) continue;
      let x = toX(cp[1]), y = toY(cp[2]);
      if (!mask.has(x, y)) {                       // coastal city just outside the simplified outline: snap inland
        let found = false;
        for (let r = 2; r <= AV * 0.7 && !found; r += 2) for (let k = 0; k < 12 && !found; k++) {
          const xx = x + r * Math.cos(k * Math.PI / 6), yy = y + r * Math.sin(k * Math.PI / 6);
          if (mask.has(xx, yy)) { x = xx; y = yy; found = true; }
        }
        if (!found) continue;
      }
      let nl = 1e9; cand.forEach(c => { if (c.land) { const d = Math.hypot(c.x - x, c.y - y); if (d < nl) nl = d; } });
      if (nl > AV * 0.6) {
        for (let i = cand.length - 1; i >= 0; i--) if (Math.hypot(cand[i].x - x, cand[i].y - y) < AV * 0.4) cand.splice(i, 1);
        cand.push({ lon: cp[1], lat: cp[2], dense: true, gi: 0, gj: 0, land: true, x: x, y: y });
      }
    }
    // 2. thin out deep ocean
    const landPts = cand.filter(c => c.land);
    const keep = cand.filter(c => {
      if (c.land) return true;
      let md = 1e9; for (const l of landPts) { const d = Math.hypot(l.x - c.x, l.y - c.y); if (d < md) md = d; if (md < 90) break; }
      return md < 90 || (c.gi % 2 === 0 && c.gj % 2 === 0) || (c.dense && md < 140);
    });
    const sites = keep.map((c, id) => Object.assign(c, { id: id }));
    // 3. ownership by weighted nearest seed
    const ids = Object.keys(G.COUNTRIES), seedList = [];
    ids.forEach(id => G.COUNTRIES[id].seeds.forEach(sd => seedList.push({ id: id, lon: sd[0], lat: sd[1], w: sd[2] || 0, m: sd[3] || 1 })));
    const ownerOf = (lon, lat) => {
      const cl = Math.cos(lat * Math.PI / 180); let best = null, bd = 1e9;
      for (const sd of seedList) {
        const dx = (lon - sd.lon) * Math.max(0.45, cl), dy = lat - sd.lat, d = dx * dx + dy * dy - sd.w;
        if (d < bd) { bd = d; best = sd; }
      }
      return best;
    };
    const provinces = sites.map(s => {
      const sd = s.land ? ownerOf(s.lon, s.lat) : null;
      return { id: s.id, x: s.x, y: s.y, lon: s.lon, lat: s.lat, owner: sd ? sd.id : null, pm: sd ? sd.m : 1, sea: !s.land, poly: [], adj: [], name: '', terrain: 'plains', capital: false, fort: 0 };
    });
    // every nation owns at least its capital
    for (const id of ids) {
      const cap = G.COUNTRIES[id].cap; let best = null, bd = 1e9;
      provinces.forEach(p => { if (p.sea) return; const d = (p.lon - cap[1]) ** 2 + (p.lat - cap[2]) ** 2; if (d < bd) { bd = d; best = p; } });
      if (best && best.owner !== id) { best.owner = id; best.pm = 1; }
    }
    // 4. geometry
    const polys = voronoi(sites, W, H);
    provinces.forEach(p => { p.poly = polys[p.id]; });
    geometry(provinces, W, H);
    // 4b. land-only cells, clipped to the real coastline at draw time; area and label point from the land mask
    const lp = voronoi(provinces.filter(p => !p.sea).map(p => ({ id: p.id, x: p.x, y: p.y })), W, H), stp = Math.max(2.5, (S.avgCell || 33) / 9);
    for (const p of provinces) {
      if (p.sea) continue;
      p.fpoly = p.poly; p.poly = lp[p.id];
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      p.poly.forEach(v => { x0 = Math.min(x0, v.x); y0 = Math.min(y0, v.y); x1 = Math.max(x1, v.x); y1 = Math.max(y1, v.y); });
      const pts = []; let sx = 0, sy = 0;
      for (let y = y0 + stp / 2; y < y1; y += stp) for (let x = x0 + stp / 2; x < x1; x += stp)
        if (mask.has(x, y) && inPolyXY(p.poly, x, y)) { pts.push([x, y]); sx += x; sy += y; }
      p.area = Math.max(stp * stp, pts.length * stp * stp);
      if (pts.length) {
        const mx = sx / pts.length, my = sy / pts.length; let best = pts[0], bd = 1e18;
        for (const q of pts) { const d = (q[0] - mx) ** 2 + (q[1] - my) ** 2; if (d < bd) { bd = d; best = q; } }
        p.cx = best[0]; p.cy = best[1];
      } else { p.cx = p.x; p.cy = p.y; }
    }
    // 5. attributes
    const rr = rng(9091), used = {};
    const feat = (kind, lon, lat) => S.terr.some(t => t[0] === kind && (lon - t[1]) ** 2 * 0.7 + (lat - t[2]) ** 2 <= t[3] * t[3]);
    const areaOf = p => p.area * 1.25;
    const order = provinces.filter(p => !p.sea);
    // capitals first so their city names are reserved
    for (const id of ids) {
      const c = G.COUNTRIES[id], mine = order.filter(p => p.owner === id);
      mine.sort((x, y) => ((x.lon - c.cap[1]) ** 2 + (x.lat - c.cap[2]) ** 2) - ((y.lon - c.cap[1]) ** 2 + (y.lat - c.cap[2]) ** 2));
      const cp = mine[0]; cp.capital = true; cp.name = c.cap[0]; used[c.cap[0]] = true;
      c.capitalId = cp.id; c.capital = cp.name;
    }
    const regionCount = {};
    for (const p of order) {
      const c = G.COUNTRIES[p.owner], pw = c.pow;
      if (!p.name) {
        p.name = G.nameFromCities(c, p.lon, p.lat, used);
        if (!p.name) {
          let near = c.cities[0], bd = 1e9; c.cities.forEach(ct => { const d = (ct[1] - p.lon) ** 2 + (ct[2] - p.lat) ** 2; if (d < bd) { bd = d; near = ct; } });
          const base = near[0] + ' Region', n = regionCount[base] = (regionCount[base] || 0) + 1;
          p.name = n > 1 ? base + ' ' + n : base;
        }
      }
      let t;
      if (feat('mountain', p.lon, p.lat)) t = 'mountain';
      else if (feat('desert', p.lon, p.lat)) t = 'desert';
      else if (feat('marsh', p.lon, p.lat)) t = 'marsh';
      else if (feat('forest', p.lon, p.lat)) t = rand() < 0.75 ? 'forest' : 'hills';
      else t = ['plains', 'plains', 'plains', 'hills', 'forest', 'hills'][Math.floor(rand() * 6)];
      p.terrain = t;
      const ar = Math.max(0.6, Math.min(2.5, Math.pow(areaOf(p) / 1100, 0.6)));
      const base = t === 'mountain' ? 0.6 : t === 'plains' ? 1.2 : t === 'desert' ? 0.4 : t === 'marsh' ? 0.7 : 1.0;
      p.pop = Math.round((30 + rand() * 90) * base * ar * p.pm) * 1000;
      p.income = Math.max(1, Math.round((2 + rand() * 6) * base * ar * (0.7 + 0.12 * pw) * Math.min(1.6, 0.6 + p.pm * 0.4)));
      p.manpower = Math.round(p.pop * 0.012 / 10) * 10 + 20;
      p.res = {
        steel: t === 'mountain' || t === 'hills' ? Math.round(rand() * 3) : Math.round(rand() * 1),
        coal: t === 'hills' || t === 'mountain' ? Math.round(rand() * 3) : Math.round(rand() * 1),
        oil: 0, food: t === 'plains' ? 1 + Math.round(rand() * 3) : t === 'desert' ? 0 : Math.round(rand() * 2), rubber: 0
      };
      for (const f of S.terr) {
        if (f[0] !== 'res') continue;
        if ((p.lon - f[1]) ** 2 * 0.7 + (p.lat - f[2]) ** 2 <= f[3] * f[3]) p.res[f[4]] = Math.max(p.res[f[4]], Math.round(f[5] * (0.7 + rr() * 0.6)));
      }
      p.fort = 0; p.infra = 1 + Math.floor(rand() * 3) + (c.pow >= 4 ? 1 : 0);
      if (t === 'desert' || t === 'mountain') p.infra = Math.max(1, p.infra - 1);
      p.infra = Math.min(5, p.infra);
    }
    for (const id of ids) {
      const cp = provinces[G.COUNTRIES[id].capitalId];
      cp.terrain = 'urban'; cp.pop = 220000; cp.income = 14 + G.COUNTRIES[id].pow; cp.infra = 4; cp.fort = 1;
    }
    G.buildSeaZones(provinces);
    return provinces;
  }

  /* ================= sea zones (both scenario kinds) ================= */
  G.buildSeaZones = function (provinces) {
    const S = G.scenario || {}, P = provinces;
    const anchors = (S.type === 'poly')
      ? S.seaAnchors.map(a => ({ name: a.name, x: S.proj.x(a.lon), y: S.proj.y(a.lat) }))
      : (S.seas || []).map(a => ({ name: a.name, x: a.x, y: a.y }));
    const seaIds = P.filter(p => p.sea).map(p => p.id);
    const zones = [], zoneOf = {};
    // multi-source Dijkstra over the sea-cell graph
    const dist = {}, src = {}, open = [];
    anchors.forEach((a, ai) => {
      let best = null, bd = 1e9;
      for (const id of seaIds) { const d = Math.hypot(P[id].x - a.x, P[id].y - a.y); if (d < bd) { bd = d; best = id; } }
      if (best == null) return;
      if (dist[best] === undefined || bd < dist[best]) { dist[best] = 0; src[best] = ai; open.push(best); }
    });
    const heap = open.map(id => ({ id: id, d: 0 }));
    const pop = () => { let bi = 0; for (let i = 1; i < heap.length; i++) if (heap[i].d < heap[bi].d) bi = i; return heap.splice(bi, 1)[0]; };
    const fin = {};
    while (heap.length) {
      const cur = pop(); if (fin[cur.id]) continue; fin[cur.id] = true;
      for (const n of P[cur.id].nbrs) {
        if (!P[n].sea) continue;
        const nd = dist[cur.id] + Math.hypot(P[n].x - P[cur.id].x, P[n].y - P[cur.id].y);
        if (dist[n] === undefined || nd < dist[n]) { dist[n] = nd; src[n] = src[cur.id]; heap.push({ id: n, d: nd }); }
      }
    }
    const zoneIdx = {};
    anchors.forEach((a, ai) => { zoneIdx[ai] = null; });
    for (const id of seaIds) {
      if (src[id] === undefined) continue;
      const ai = src[id];
      if (zoneIdx[ai] == null) { zoneIdx[ai] = zones.length; zones.push({ id: 'z' + zones.length, name: anchors[ai].name, cells: [], adj: [], ports: [] }); }
      zones[zoneIdx[ai]].cells.push(id); zoneOf[id] = zones[zoneIdx[ai]].id;
    }
    // unreachable cells (lakes without an anchor) form their own inland waters
    let lake = 0;
    for (const id of seaIds) {
      if (zoneOf[id]) continue;
      const z = { id: 'z' + zones.length, name: 'Inland Water ' + (++lake), cells: [], adj: [], ports: [] };
      const stack = [id]; zoneOf[id] = z.id;
      while (stack.length) { const c = stack.pop(); z.cells.push(c); for (const n of P[c].nbrs) if (P[n].sea && !zoneOf[n]) { zoneOf[n] = z.id; stack.push(n); } }
      zones.push(z);
    }
    const byId = {}; zones.forEach(z => { byId[z.id] = z; });
    for (const id of seaIds) P[id].zone = zoneOf[id];
    // zone centre = the member cell nearest to the anchor, adjacency from neighbouring cells
    zones.forEach(z => {
      let mx = 0, my = 0; z.cells.forEach(c => { mx += P[c].cx; my += P[c].cy; });
      mx /= z.cells.length; my /= z.cells.length;
      let best = z.cells[0], bd = 1e9;
      z.cells.forEach(c => { const d = Math.hypot(P[c].cx - mx, P[c].cy - my); if (d < bd) { bd = d; best = c; } });
      z.cx = P[best].cx; z.cy = P[best].cy; z.anchorCell = best;
      const set = new Set();
      z.cells.forEach(c => P[c].nbrs.forEach(n => { if (P[n].sea && zoneOf[n] !== z.id) set.add(zoneOf[n]); }));
      z.adj = Array.from(set);
    });
    // straits (explicit links between zones that coarse geometry keeps apart)
    G.straits = [];
    (S.straits || []).forEach(st => {
      const a = zones.find(z => z.name === st.a), b = zones.find(z => z.name === st.b);
      if (!a || !b) return;
      let ctrl = null, bd = 1e9;
      if (st.at && S.type === 'poly') {
        const x = S.proj.x(st.at[0]), y = S.proj.y(st.at[1]);
        P.forEach(p => { if (p.sea) return; const d = Math.hypot(p.cx - x, p.cy - y); if (d < bd) { bd = d; ctrl = p.id; } });
      }
      if (!a.adj.includes(b.id)) a.adj.push(b.id);
      if (!b.adj.includes(a.id)) b.adj.push(a.id);
      G.straits.push({ a: a.id, b: b.id, name: st.name, ctrl: ctrl });
    });
    // connectivity repair: join isolated groups of zones to the nearest zone of the main body
    const comp = {}; let nc = 0;
    zones.forEach(z => {
      if (comp[z.id] != null) return;
      const st = [z.id]; comp[z.id] = nc;
      while (st.length) { const c = st.pop(); byId[c].adj.forEach(n => { if (comp[n] == null) { comp[n] = nc; st.push(n); } }); }
      nc++;
    });
    for (let guard = 0; guard < 40 && nc > 1; guard++) {
      const main = comp[zones.reduce((b, z) => (zones.filter(q => comp[q.id] === comp[z.id]).length > zones.filter(q => comp[q.id] === comp[b.id]).length ? z : b), zones[0]).id];
      let bp = null, bd = 1e9;
      zones.forEach(a => { if (comp[a.id] === main) return; zones.forEach(b => { if (comp[b.id] !== main) return; const d = Math.hypot(a.cx - b.cx, a.cy - b.cy); if (d < bd) { bd = d; bp = [a, b]; } }); });
      if (!bp) break;
      bp[0].adj.push(bp[1].id); bp[1].adj.push(bp[0].id);
      const old = comp[bp[0].id]; zones.forEach(z => { if (comp[z.id] === old) comp[z.id] = main; });
      nc = new Set(Object.values(comp)).size;
    }
    // ports: every land province touching the sea
    P.forEach(p => {
      if (p.sea) { return; }
      const set = new Set(); p.nbrs.forEach(n => { if (P[n].sea) set.add(P[n].zone); });
      p.seaZones = Array.from(set);
      p.seaZones.forEach(zid => byId[zid].ports.push(p.id));
    });
    G.zones = zones; G.zoneById = byId;
  };

})(window.EMP = window.EMP || {});
