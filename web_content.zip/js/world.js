// Static, original arena layout. Same hardcoded obstacle list on every
// client, so no network sync is needed for the environment itself in
// Stage 1. Named zones (city/military base/forest/etc.) come in a later
// stage once this foundation is proven.
const World = {
  OBSTACLES: [
    { x: 10, z: 10, w: 6, h: 4, d: 6 },
    { x: -15, z: 5, w: 4, h: 6, d: 4 },
    { x: 0, z: -20, w: 10, h: 3, d: 10 },
    { x: 25, z: -10, w: 5, h: 5, d: 5 },
    { x: -25, z: -25, w: 8, h: 4, d: 8 },
    { x: 30, z: 30, w: 6, h: 6, d: 6 },
    { x: -30, z: 20, w: 5, h: 4, d: 5 },
    { x: -8, z: 35, w: 4, h: 4, d: 4 },
  ],

  build(scene) {
    const groundGeo = new THREE.PlaneGeometry(200, 200);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x3a4a3a });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    scene.add(ground);

    scene.add(new THREE.HemisphereLight(0xbfd7ff, 0x3a3a2a, 1.1));
    const sun = new THREE.DirectionalLight(0xffffff, 0.8);
    sun.position.set(50, 80, 30);
    scene.add(sun);

    this.OBSTACLES.forEach(o => {
      const geo = new THREE.BoxGeometry(o.w, o.h, o.d);
      const mat = new THREE.MeshStandardMaterial({ color: 0x555f66 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(o.x, o.h / 2, o.z);
      scene.add(mesh);
    });
  },
};
