/* ============================================================
   AETHERVALE — Dunia terbuka tak terbatas (streaming chunk)
   Peta dibuat prosedural per chunk saat pemain melewati batas.
   ============================================================ */
const World = (() => {
  const TS = 16;
  const CH = 24;                 // tile per chunk
  const CHPX = CH * TS;
  const T = { GROUND: 0, WATER: 1, SOLID: 2, PATH: 3, FLOOR: 4, SAND: 5 };

  const chunks = new Map();      // "cx,cy" -> {tiles, objs, canvas}
  const biomeCache = new Map();  // "bx,by" (blok 2 tile) -> biome
  const overrides = new Map();   // "tx,ty" -> tile (kota, jalan, arena)
  const SEED = 20260919;

  /* ---------------- noise ---------------- */
  function hash2(x, y, s) {
    let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 1442695041) + SEED) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    h = Math.imul(h, 2246822519);
    h ^= h >>> 13;
    return (h >>> 0) / 4294967296;
  }
  function smooth(t) { return t * t * (3 - 2 * t); }
  function vnoise(x, y, s) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = smooth(x - xi), yf = smooth(y - yi);
    const a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s);
    const c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
    return (a + (b - a) * xf) * (1 - yf) + (c + (d - c) * xf) * yf;
  }
  function fbm(x, y, freq, oct, s) {
    let v = 0, amp = 0.5, f = freq, norm = 0;
    for (let i = 0; i < (oct || 3); i++) {
      v += vnoise(x * f, y * f, (s || 0) + i * 31) * amp;
      norm += amp; amp *= 0.5; f *= 2.05;
    }
    v = v / norm;
    // sebaran value-noise menumpuk di tengah; regangkan agar seluruh ambang bioma terpakai
    const k = (v - 0.5) * 2;
    return 0.5 + 0.5 * Math.max(-1, Math.min(1, k * 1.85 - 0.55 * k * k * k));
  }

  /* ---------------- kota & penanda ---------------- */
  const TOWN = { cx: 0, cy: 0, w: 38, h: 30 };
  const BUILDINGS = [];
  const NPCS = [];
  const ARENAS = { alpha: [80, -60], magmaris: [-150, 110], vaelor: [430, -320] };
  const LANDMARKS = {};          // {forest:[tx,ty], nether:[tx,ty], ...}

  function inTown(tx, ty, pad) {
    pad = pad || 0;
    return tx > TOWN.cx - TOWN.w / 2 - pad && tx < TOWN.cx + TOWN.w / 2 + pad &&
           ty > TOWN.cy - TOWN.h / 2 - pad && ty < TOWN.cy + TOWN.h / 2 + pad;
  }
  function nearArena(tx, ty) {
    for (const k in ARENAS) { const a = ARENAS[k]; if (Math.hypot(tx - a[0], ty - a[1]) < 13) return true; }
    return false;
  }

  /* ---------------- pemilihan bioma ---------------- */
  function realmAt(tx, ty) {
    const dist = Math.hypot(tx, ty);
    if (dist < 110) return 'overworld';
    const cave = fbm(tx, ty, 0.0085, 2, 71);
    if (dist > 150 && cave > 0.90) return 'cave';
    if (dist > 240) {
      const rn = fbm(tx, ty, 0.0011, 2, 17);
      const gate = fbm(tx, ty, 0.0035, 2, 18);
      if (rn > 0.87) return gate > 0.45 ? 'nether' : 'end';
    }
    return 'overworld';
  }

  function pickOverworld(tx, ty, cont, temp, hum, ero, weird) {
    // sungai memotong daratan
    const riv = fbm(tx, ty, 0.0032, 2, 55);
    const near = Math.hypot(tx, ty) < 110;

    if (!near) {
      if (cont < 0.285) {                       // laut
        const deep = cont < 0.175;
        if (temp > 0.74) return 'warm_ocean';
        if (temp > 0.58) return deep ? 'deep_lukewarm_ocean' : 'lukewarm_ocean';
        if (temp > 0.40) return deep ? 'deep_ocean' : 'ocean';
        if (temp > 0.24) return deep ? 'deep_cold_ocean' : 'cold_ocean';
        return deep ? 'deep_frozen_ocean' : 'frozen_ocean';
      }
      if (cont < 0.345) {                       // pesisir
        if (temp < 0.26) return 'snowy_beach';
        if (ero > 0.66) return 'stony_shore';
        return 'beach';
      }
    }
    if (Math.abs(riv - 0.5) < 0.017 && cont > 0.36) return temp < 0.26 ? 'frozen_river' : 'river';
    if (!near && weird > 0.925 && hum > 0.52) return 'mushroom_fields';

    if (ero > 0.795 && !near) {                 // puncak
      if (temp < 0.32) return ero > 0.89 ? 'frozen_peaks' : 'snowy_slopes';
      if (ero > 0.885) return 'jagged_peaks';
      return 'stony_peaks';
    }
    if (ero > 0.70 && !near) {                  // bukit terpaan angin
      if (hum > 0.60) return 'windswept_forest';
      if (temp > 0.72 && hum < 0.35) return 'windswept_savanna';
      return ero > 0.745 ? 'windswept_gravelly_hills' : 'windswept_hills';
    }
    // rawa di dataran rendah lembap
    if (cont < 0.44 && hum > 0.63 && temp > 0.34) return temp > 0.62 ? 'mangrove_swamp' : 'swamp';

    if (temp < 0.25) {                          // sangat dingin
      if (hum > 0.6) return 'snowy_taiga';
      if (weird > 0.86) return 'ice_spikes';
      return ero > 0.55 ? 'grove' : 'snowy_plains';
    }
    if (temp < 0.40) {                          // dingin
      if (hum > 0.72) return 'old_growth_spruce_taiga';
      if (hum > 0.58) return weird > 0.62 ? 'old_growth_pine_taiga' : 'taiga';
      return 'plains';
    }
    if (temp < 0.63) {                          // sedang
      if (hum > 0.80) return weird > 0.78 ? 'pale_garden' : 'dark_forest';
      if (hum > 0.66) return 'forest';
      if (hum > 0.56) return weird > 0.70 ? 'old_growth_birch_forest' : 'birch_forest';
      if (hum > 0.48) return 'flower_forest';
      if (weird > 0.68) return 'cherry_grove';
      return near ? 'meadow' : (weird > 0.5 ? 'meadow' : 'plains');
    }
    if (temp < 0.80) {                          // hangat
      if (hum > 0.78) return weird > 0.66 ? 'bamboo_jungle' : 'jungle';
      if (hum > 0.62) return 'sparse_jungle';
      if (hum > 0.42) return weird > 0.7 ? 'sunflower_plains' : 'plains';
      return ero > 0.58 ? 'savanna_plateau' : 'savanna';
    }
    // panas
    if (hum < 0.26) return 'desert';
    if (hum < 0.45) return ero > 0.62 ? 'eroded_badlands' : 'badlands';
    if (hum < 0.62) return 'wooded_badlands';
    return 'savanna';
  }

  function pickBiome(tx, ty) {
    const realm = realmAt(tx, ty);
    const weird = fbm(tx, ty, 0.012, 2, 5);
    if (realm === 'cave') {
      const d = fbm(tx, ty, 0.006, 2, 91);
      if (d > 0.62) return 'deep_dark';
      return d > 0.40 ? 'lush_caves' : 'dripstone_caves';
    }
    if (realm === 'nether') {
      const n = fbm(tx, ty, 0.009, 2, 33);
      if (n > 0.74) return 'crimson_forest';
      if (n > 0.58) return 'warped_forest';
      if (n > 0.44) return 'soul_sand_valley';
      if (n < 0.24) return 'basalt_deltas';
      return 'nether_wastes';
    }
    if (realm === 'end') {
      const n = fbm(tx, ty, 0.008, 2, 44);
      const island = fbm(tx, ty, 0.013, 2, 66);
      if (island < 0.40) return 'small_end_islands';
      if (Math.hypot(tx, ty) < 360) return 'the_end';
      if (n > 0.68) return 'end_highlands';
      if (n > 0.46) return 'end_midlands';
      return 'end_barrens';
    }
    // regangkan tiap parameter iklim agar seluruh rentang bioma tercapai
    const sp = v => Math.max(0, Math.min(1, 0.5 + (v - 0.5) * 2.3));
    const cont = sp(fbm(tx, ty, 0.0042, 3, 1));
    let temp = sp(fbm(tx, ty, 0.0021, 2, 2));
    // sekitar kota dibuat sejuk-sedang agar awal permainan ramah
    const dNear = Math.hypot(tx, ty);
    if (dNear < 220) { const m = 1 - dNear / 220; temp = temp * (1 - m * 0.85) + 0.52 * m * 0.85; }
    const hum = sp(fbm(tx, ty, 0.0029, 2, 3));
    const ero = sp(fbm(tx, ty, 0.0068, 3, 4));
    return pickOverworld(tx, ty, cont, temp, hum, ero, weird);
  }

  function biomeAt(tx, ty) {
    if (inTown(tx, ty, 6)) return BIOMES.meadow;
    const bx = tx >> 1, by = ty >> 1;
    const k = bx + ',' + by;
    let b = biomeCache.get(k);
    if (b) return b;
    b = BIOMES[pickBiome(bx << 1, by << 1)] || BIOMES.meadow;
    biomeCache.set(k, b);
    if (biomeCache.size > 60000) biomeCache.clear();
    return b;
  }
  function biomeAtPx(px, py) { return biomeAt(Math.floor(px / TS), Math.floor(py / TS)); }
  function realmAtPx(px, py) { return biomeAtPx(px, py).realm; }

  /* ---------------- tile ---------------- */
  function pondiness(b) {
    if (b.fluid) return 1;
    if (b.id === 'swamp' || b.id === 'mangrove_swamp') return 0.30;
    if (b.realm === 'nether') return 0.10;      // kolam lava
    if (b.realm === 'cave') return 0.08;
    if (b.realm === 'end') return 0;
    if (b.sandy) return 0.03;
    return 0.06;
  }
  function baseTile(tx, ty, b) {
    if (b.fluid) {
      // pulau kecil sesekali di perairan
      if (fbm(tx, ty, 0.06, 2, 12) > 0.86) return b.sandy ? T.SAND : T.GROUND;
      return T.WATER;
    }
    if (b.realm === 'end') {
      const island = fbm(tx, ty, 0.014, 3, 66);
      if (island < 0.355) return T.WATER;       // jurang kehampaan
    }
    const n = fbm(tx, ty, 0.055, 2, 8);
    const pond = pondiness(b);
    if (pond > 0 && n > 1 - pond) return T.WATER;
    if (b.rocky && n < 0.20) return T.SOLID;
    if (!b.rocky && n < 0.055) return T.SOLID;
    if (b.id === 'jagged_peaks' && n < 0.34) return T.SOLID;
    return b.sandy ? T.SAND : T.GROUND;
  }

  function genChunk(cx, cy) {
    const tiles = new Uint8Array(CH * CH);
    const objs = [];
    for (let ty = 0; ty < CH; ty++) {
      for (let tx = 0; tx < CH; tx++) {
        const wx = cx * CH + tx, wy = cy * CH + ty;
        const ov = overrides.get(wx + ',' + wy);
        const b = biomeAt(wx, wy);
        let t = ov === undefined ? baseTile(wx, wy, b) : ov;
        tiles[ty * CH + tx] = t;
        if (ov !== undefined) continue;
        if (t !== T.GROUND && t !== T.SAND) continue;
        if (inTown(wx, wy, 5) || nearArena(wx, wy)) continue;
        const h = hash2(wx * 3 + 7, wy * 5 + 11, 99);
        if (b.treeStyle !== 'none' && h < b.dens) {
          objs.push({ x: wx * TS + 8, y: wy * TS + 14, kind: 'tree', biome: b.id, variant: (h * 1000 | 0) % 4, cr: 5 });
        } else if (h < b.dens + 0.013) {
          objs.push({ x: wx * TS + 8, y: wy * TS + 12, kind: 'rock', biome: b.id, variant: (h * 977 | 0) % 4, cr: 6 });
        }
      }
    }
    objs.sort((a, b) => a.y - b.y);
    return { tiles, objs, canvas: null };
  }

  function chunkAt(cx, cy) {
    const k = cx + ',' + cy;
    let c = chunks.get(k);
    if (!c) {
      c = genChunk(cx, cy);
      chunks.set(k, c);
      if (chunks.size > 260) {
        // buang chunk terjauh dari pemain
        const P = (typeof Game !== 'undefined' && Game.player) ? Game.player : { x: 0, y: 0 };
        const pcx = Math.floor(P.x / CHPX), pcy = Math.floor(P.y / CHPX);
        let worst = null, wd = -1;
        for (const key of chunks.keys()) {
          const p = key.split(','), d = Math.hypot(+p[0] - pcx, +p[1] - pcy);
          if (d > wd) { wd = d; worst = key; }
        }
        if (worst && wd > 4) chunks.delete(worst);
      }
    }
    return c;
  }

  function getT(tx, ty) {
    const cx = Math.floor(tx / CH), cy = Math.floor(ty / CH);
    const c = chunkAt(cx, cy);
    return c.tiles[(ty - cy * CH) * CH + (tx - cx * CH)];
  }

  /* ---------------- pembangunan kota, jalan, arena ---------------- */
  let rngState = SEED;
  function rnd() { rngState = (rngState * 1664525 + 1013904223) >>> 0; return rngState / 4294967296; }
  function setOv(tx, ty, v) { overrides.set(tx + ',' + ty, v); }

  function road(x0, y0, x1, y1) {
    if (x0 === x1) { const a = Math.min(y0, y1), b = Math.max(y0, y1); for (let y = a; y <= b; y++) for (let w = -2; w <= 2; w++) setOv(x0 + w, y, T.PATH); }
    else { const a = Math.min(x0, x1), b = Math.max(x0, x1); for (let x = a; x <= b; x++) for (let w = -2; w <= 2; w++) setOv(x, y0 + w, T.PATH); }
  }

  function findBiomeSpot(pred, rMin, rMax) {
    for (let r = rMin; r <= rMax; r += 5) {
      for (let i = 0; i < 64; i++) {
        const a = (i / 64) * Math.PI * 2 + r * 0.11;
        const tx = Math.round(Math.cos(a) * r), ty = Math.round(Math.sin(a) * r);
        if (pred(biomeAt(tx, ty), tx, ty)) return [tx, ty];
      }
    }
    return null;
  }

  function buildTown() {
    const x0 = TOWN.cx - TOWN.w / 2, y0 = TOWN.cy - TOWN.h / 2;
    for (let ty = y0; ty < y0 + TOWN.h; ty++)
      for (let tx = x0; tx < x0 + TOWN.w; tx++) setOv(tx, ty, (tx + ty) % 17 === 0 ? T.GROUND : T.FLOOR);
    for (let tx = x0 - 2; tx < x0 + TOWN.w + 2; tx++) { setOv(tx, TOWN.cy, T.PATH); setOv(tx, TOWN.cy + 1, T.PATH); }
    for (let ty = y0 - 2; ty < y0 + TOWN.h + 2; ty++) { setOv(TOWN.cx, ty, T.PATH); setOv(TOWN.cx + 1, ty, T.PATH); }

    const defs = [
      { kind: 'hall',    npc: 'rangga', tx: TOWN.cx - 3,  ty: y0 + 2,  w: 5, h: 5 },
      { kind: 'auction', npc: 'mira',   tx: x0 + 4,       ty: y0 + 3,  w: 4, h: 4 },
      { kind: 'smith',   npc: 'borin',  tx: x0 + 4,       ty: TOWN.cy + 6, w: 4, h: 4 },
      { kind: 'gem',     npc: 'wen',    tx: x0 + 13,      ty: TOWN.cy + 6, w: 4, h: 4 },
      { kind: 'enchant', npc: 'ilya',   tx: x0 + 23,      ty: TOWN.cy + 6, w: 4, h: 4 },
      { kind: 'inherit', npc: 'nadia',  tx: x0 + 29,      ty: y0 + 3,  w: 4, h: 4 },
      { kind: 'shop',    npc: 'tama',   tx: x0 + 22,      ty: y0 + 3,  w: 4, h: 4 },
    ];
    for (const d of defs) {
      for (let ty = d.ty; ty < d.ty + d.h; ty++)
        for (let tx = d.tx; tx < d.tx + d.w; tx++) setOv(tx, ty, T.SOLID);
      const doorTx = d.tx + Math.floor(d.w / 2), doorTy = d.ty + d.h;
      BUILDINGS.push(Object.assign({}, d, { doorX: doorTx * TS + 8, doorY: doorTy * TS + 4 }));
      NPCS.push({
        id: d.npc, x: doorTx * TS + 8, y: doorTy * TS + 14, dir: 0, frame: 0, t: rnd() * 10,
        panel: (NPC_LINES[d.npc] || {}).panel || null,
      });
    }
  }

  function carveArena(tx, ty) {
    for (let y = ty - 12; y <= ty + 12; y++)
      for (let x = tx - 12; x <= tx + 12; x++) {
        const d = Math.hypot(x - tx, y - ty);
        if (d < 11) setOv(x, y, d < 10 ? T.SAND : T.PATH);
      }
  }

  function generate() {
    chunks.clear(); biomeCache.clear(); overrides.clear();
    BUILDINGS.length = 0; NPCS.length = 0;
    rngState = SEED;

    // penanda dunia: dicari sekali, deterministik
    const forest = findBiomeSpot(b => ['forest', 'dark_forest', 'birch_forest', 'taiga', 'old_growth_pine_taiga', 'windswept_forest', 'old_growth_birch_forest', 'flower_forest', 'sparse_jungle', 'jungle', 'old_growth_spruce_taiga', 'snowy_taiga', 'pale_garden'].includes(b.id), 62, 260) || [80, -60];
    const hot = findBiomeSpot(b => ['badlands', 'eroded_badlands', 'wooded_badlands', 'desert', 'savanna', 'savanna_plateau', 'windswept_savanna'].includes(b.id), 110, 420) || [-150, 110];
    const nether = findBiomeSpot(b => b.realm === 'nether', 260, 900) || [430, -320];
    const end = findBiomeSpot(b => b.realm === 'end', 260, 900) || [-430, 320];
    const cave = findBiomeSpot(b => b.realm === 'cave', 160, 420) || [200, 200];
    const swamp = findBiomeSpot(b => b.id === 'swamp' || b.id === 'mangrove_swamp', 90, 340) || [-120, -120];
    LANDMARKS.swamp = swamp;
    LANDMARKS.forest = forest; LANDMARKS.hot = hot; LANDMARKS.nether = nether; LANDMARKS.end = end; LANDMARKS.cave = cave;
    ARENAS.alpha = forest; ARENAS.magmaris = hot; ARENAS.vaelor = nether;

    buildTown();
    // jalan keluar kota ke empat arah + menuju penanda
    road(TOWN.cx, TOWN.cy, TOWN.cx, TOWN.cy - 70);
    road(TOWN.cx, TOWN.cy, TOWN.cx, TOWN.cy + 70);
    road(TOWN.cx, TOWN.cy, TOWN.cx - 70, TOWN.cy);
    road(TOWN.cx, TOWN.cy, TOWN.cx + 70, TOWN.cy);
    for (const k of ['alpha', 'magmaris']) {
      const a = ARENAS[k];
      road(TOWN.cx, TOWN.cy, a[0], TOWN.cy);
      road(a[0], TOWN.cy, a[0], a[1]);
    }
    for (const k in ARENAS) carveArena(ARENAS[k][0], ARENAS[k][1]);

    NPCS.push({ id: 'sela', x: (forest[0] + 6) * TS, y: (forest[1] + 6) * TS, dir: 0, frame: 0, t: 0, panel: null, hidden: false });
  }

  /* ---------------- tabrakan ---------------- */
  function solidAtPx(px, py) {
    const t = getT(Math.floor(px / TS), Math.floor(py / TS));
    return t === T.SOLID || t === T.WATER;
  }
  function objBlockedFast(px, py, r) {
    const cx = Math.floor(px / CHPX), cy = Math.floor(py / CHPX);
    for (let x = cx - 1; x <= cx + 1; x++) for (let y = cy - 1; y <= cy + 1; y++) {
      const c = chunks.get(x + ',' + y); if (!c) continue;
      for (const o of c.objs) {
        if (Math.abs(o.x - px) > 24 || Math.abs(o.y - py) > 24) continue;
        if (Math.hypot(o.x - px, o.y - py) < o.cr + r) return true;
      }
    }
    return false;
  }
  function walkable(px, py, r) {
    r = r || 4;
    if (solidAtPx(px - r, py) || solidAtPx(px + r, py) || solidAtPx(px, py - r) || solidAtPx(px, py + r)) return false;
    if (objBlockedFast(px, py + 2, r * 0.7)) return false;
    return true;
  }
  function visibleObjects(cam) {
    const out = [];
    const c0 = Math.floor((cam.x - 40) / CHPX), c1 = Math.floor((cam.x + cam.w + 40) / CHPX);
    const r0 = Math.floor((cam.y - 60) / CHPX), r1 = Math.floor((cam.y + cam.h + 60) / CHPX);
    for (let cy = r0; cy <= r1; cy++) for (let cx = c0; cx <= c1; cx++) {
      const c = chunkAt(cx, cy);
      for (const o of c.objs) out.push(o);
    }
    return out;
  }
  function buildObjGrid() { /* tidak diperlukan lagi: objek tersimpan per chunk */ }

  /* ---------------- render chunk ---------------- */
  function renderChunk(cx, cy) {
    const c = chunkAt(cx, cy);
    if (c.canvas) return c.canvas;
    const { c: cv, x: g } = Art.makeCanvas(CHPX, CHPX);
    for (let ty = 0; ty < CH; ty++) {
      for (let tx = 0; tx < CH; tx++) {
        const wx = cx * CH + tx, wy = cy * CH + ty;
        const b = biomeAt(wx, wy);
        const t = c.tiles[ty * CH + tx];
        const h = hash2(wx, wy, 3);
        let col;
        if (t === T.WATER) col = b.water;
        else if (t === T.SOLID) col = b.rock;
        else if (t === T.PATH) col = Art.shade(b.ground[0], 26);
        else if (t === T.FLOOR) col = '#a99878';
        else if (t === T.SAND) col = Art.shade(b.ground[1], 14);
        else col = b.ground[Math.floor(h * 3)];
        g.fillStyle = col;
        g.fillRect(tx * TS, ty * TS, TS, TS);
        if (t === T.GROUND || t === T.SAND) {
          g.fillStyle = Art.shade(col, 12);
          for (let i = 0; i < 4; i++) {
            const hx = hash2(wx * 7 + i, wy * 13 + i, 4);
            g.fillRect(tx * TS + Math.floor(hx * 14), ty * TS + Math.floor(hash2(wy * 5 + i, wx * 3 + i, 5) * 14), 2, 2);
          }
          if (h > 0.965) {
            g.fillStyle = b.flower[Math.floor(hash2(wx, wy + 99, 6) * b.flower.length)];
            g.fillRect(tx * TS + 5, ty * TS + 6, 2, 2); g.fillRect(tx * TS + 9, ty * TS + 9, 2, 2);
          } else if (h > 0.9) {
            g.fillStyle = b.accent;
            g.fillRect(tx * TS + 4, ty * TS + 10, 1, 3); g.fillRect(tx * TS + 6, ty * TS + 9, 1, 4); g.fillRect(tx * TS + 8, ty * TS + 11, 1, 2);
          }
        } else if (t === T.SOLID) {
          g.fillStyle = Art.shade(col, 22); g.fillRect(tx * TS, ty * TS, TS, 3);
          g.fillStyle = Art.shade(col, -28); g.fillRect(tx * TS, ty * TS + TS - 3, TS, 3);
          g.fillStyle = Art.shade(col, -12); g.fillRect(tx * TS + (h > 0.5 ? 3 : 8), ty * TS + 6, 5, 4);
        } else if (t === T.WATER) {
          g.fillStyle = Art.shade(col, 20);
          if (h > 0.6) g.fillRect(tx * TS + 3, ty * TS + 5, 6, 1);
          if (h > 0.8) g.fillRect(tx * TS + 8, ty * TS + 10, 5, 1);
          g.fillStyle = Art.shade(col, -22); g.fillRect(tx * TS, ty * TS + TS - 2, TS, 2);
        } else if (t === T.PATH) {
          g.fillStyle = Art.shade(col, -14);
          if (h > 0.5) g.fillRect(tx * TS + 4, ty * TS + 4, 3, 2);
          if (h > 0.75) g.fillRect(tx * TS + 10, ty * TS + 9, 3, 2);
        } else if (t === T.FLOOR) {
          g.fillStyle = 'rgba(0,0,0,0.13)';
          g.fillRect(tx * TS, ty * TS + TS - 1, TS, 1); g.fillRect(tx * TS + TS - 1, ty * TS, 1, TS);
        }
      }
    }
    c.canvas = cv;
    return cv;
  }

  function drawGround(ctx, cam) {
    const c0 = Math.floor(cam.x / CHPX), c1 = Math.floor((cam.x + cam.w) / CHPX);
    const r0 = Math.floor(cam.y / CHPX), r1 = Math.floor((cam.y + cam.h) / CHPX);
    for (let cy = r0; cy <= r1; cy++) for (let cx = c0; cx <= c1; cx++) {
      ctx.drawImage(renderChunk(cx, cy), cx * CHPX - Math.round(cam.x), cy * CHPX - Math.round(cam.y));
    }
  }

  function drawBuildings(ctx, cam) {
    for (const b of BUILDINGS) {
      const px = b.tx * TS, py = (b.ty + b.h) * TS;
      const img = Art.building(b.kind);
      const dx = Math.round(px + (b.w * TS) / 2 - img.width / 2 - cam.x);
      const dy = Math.round(py - img.height - cam.y);
      if (dx > cam.w + 90 || dx < -120 || dy > cam.h + 90 || dy < -120) continue;
      ctx.drawImage(img, dx, dy);
      const lbl = { hall: 'BALAI', auction: 'LELANG', smith: 'TEMPA', gem: 'PERMATA', enchant: 'SIHIR', inherit: 'WARIS', shop: 'TOKO' }[b.kind];
      if (typeof Game !== 'undefined' && Game.label) Game.label(lbl, dx + img.width / 2, dy + 33, '#ffe9b8', 7, { bold: true, bg: 'rgba(15,12,22,0.7)' });
    }
  }

  /* ---------------- suasana bioma (gua / nether / end) ---------------- */
  function drawAmbient(ctx, cam, t) {
    const P = (typeof Game !== 'undefined' && Game.player) ? Game.player : null;
    if (!P) return;
    const b = biomeAtPx(P.x, P.y);
    const dark = b.dark || 0;
    if (dark <= 0) return;
    const px = P.x - cam.x, py = P.y - cam.y;
    const g = ctx.createRadialGradient(px, py, 20, px, py, Math.max(cam.w, cam.h) * 0.62);
    const tint = b.realm === 'nether' ? '20,6,4' : b.realm === 'end' ? '8,6,20' : '4,6,10';
    g.addColorStop(0, `rgba(${tint},0)`);
    g.addColorStop(0.45, `rgba(${tint},${dark * 0.55})`);
    g.addColorStop(1, `rgba(${tint},${Math.min(0.94, dark * 1.5)})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, cam.w, cam.h);
    if (b.realm === 'nether' || b.id === 'deep_dark') {
      ctx.fillStyle = b.realm === 'nether' ? 'rgba(255,150,80,0.30)' : 'rgba(60,220,220,0.28)';
      for (let i = 0; i < 24; i++) {
        const sx = (i * 137 + t * 13) % cam.w, sy = (i * 83 + Math.sin(t * 0.7 + i) * 24 + i * 11) % cam.h;
        ctx.fillRect(Math.round(sx), Math.round(sy), 2, 2);
      }
    }
  }

  return {
    TS, CH, CHPX, T, TOWN, BUILDINGS, NPCS, ARENAS, LANDMARKS,
    generate, getT, biomeAt, biomeAtPx, realmAt, realmAtPx,
    walkable, solidAtPx, visibleObjects, buildObjGrid,
    drawGround, drawBuildings, drawAmbient, inTown,
    get loadedChunks() { return chunks.size; },
  };
})();
