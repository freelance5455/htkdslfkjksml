// ===== Geração da ilha =====
const MW = 150, MH = 115, TS = 32;
const T = { DEEP: 0, SHALLOW: 1, SAND: 2, TIDE: 3, GRASS: 4, MUD: 5, MWATER: 6, PLATEAU: 7, CAVE: 8, VOLC: 9, RIVER: 10, SPRING: 11, HOT: 12, ASH: 13 };
const B = { MAR: 0, PRAIA: 1, FLORESTA: 2, MANGUE: 3, PLANALTO: 4, VULCAO: 5 };
const TILE_COLOR = {
  0: '#0f4866', 1: '#2a8aa3', 2: '#e6cf98', 3: '#cdb47c', 4: '#3f7a3a', 5: '#6e5c3c', 6: '#4c6c58',
  7: '#8c8a6c', 8: '#4c4740', 9: '#4e3f3a', 10: '#3b9cbd', 11: '#6ccfe0', 12: '#93d6d2', 13: '#2f2725',
};
const VX = 0.55, VY = 0.17;

function genWorld(seed) {
  const N = MW * MH;
  const type = new Uint8Array(N), biome = new Uint8Array(N), hgt = new Float32Array(N), vari = new Float32Array(N);
  const land = new Uint8Array(N);
  for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) {
    const i = y * MW + x, nx = x / MW, ny = y / MH;
    const dx = (nx - 0.5) / 0.45, dy = (ny - 0.53) / 0.43;
    const d = Math.sqrt(dx * dx + dy * dy);
    const n = fbm(x * 0.045, y * 0.045, seed);
    let h = 1 - d + (n - 0.5) * 0.55;
    const vd = Math.hypot((nx - VX) * 1.25, ny - VY);
    h += 0.35 * Math.exp(-(vd * vd) / 0.006);
    if (x < 4 || y < 4 || x > MW - 5 || y > MH - 5) h = -1;
    hgt[i] = h;
    vari[i] = hash2(x, y, seed + 7);
    land[i] = h >= 0.1 ? 1 : 0;
    type[i] = h < 0.02 ? T.DEEP : T.SHALLOW;
  }
  // mantém só a ilha principal
  const keep = new Uint8Array(N);
  const start = Math.floor(MH * 0.55) * MW + Math.floor(MW * 0.5);
  const q = [start]; keep[start] = 1;
  while (q.length) {
    const i = q.pop(), x = i % MW, y = (i / MW) | 0;
    for (const [ax, ay] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const j = (y + ay) * MW + (x + ax);
      if (land[j] && !keep[j]) { keep[j] = 1; q.push(j); }
    }
  }
  // lagos internos viram terra
  const sea = new Uint8Array(N); const q2 = [0]; sea[0] = 1;
  while (q2.length) {
    const i = q2.pop(), x = i % MW, y = (i / MW) | 0;
    for (const [ax, ay] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + ax, ny = y + ay; if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
      const j = ny * MW + nx;
      if (!keep[j] && !sea[j]) { sea[j] = 1; q2.push(j); }
    }
  }
  for (let i = 0; i < N; i++) { land[i] = keep[i] || !sea[i] ? 1 : 0; if (!land[i] && type[i] === T.DEEP && hgt[i] > 0.0 ) type[i] = T.SHALLOW; }
  // distância até a costa
  const cd = new Int16Array(N).fill(999); const bq = [];
  for (let i = 0; i < N; i++) if (!land[i]) { cd[i] = 0; bq.push(i); }
  for (let h = 0; h < bq.length; h++) {
    const i = bq[h], x = i % MW, y = (i / MW) | 0;
    for (const [ax, ay] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + ax, ny = y + ay; if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
      const j = ny * MW + nx; if (cd[j] > cd[i] + 1) { cd[j] = cd[i] + 1; bq.push(j); }
    }
  }
  const centers = [[0.47, 0.64, 2], [0.64, 0.62, 2], [0.33, 0.64, 2], [0.5, 0.46, 2], [0.62, 0.42, 2], [0.85, 0.46, 3], [0.8, 0.6, 3], [0.27, 0.33, 4], [0.38, 0.25, 4], [0.18, 0.46, 4]];
  for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) {
    const i = y * MW + x; if (!land[i]) continue;
    const nx = x / MW, ny = y / MH;
    const jx = nx + (fbm(x * 0.06 + 50, y * 0.06, seed + 3) - 0.5) * 0.18;
    const jy = ny + (fbm(x * 0.06, y * 0.06 + 80, seed + 5) - 0.5) * 0.18;
    let best = 2, bd = 9;
    for (const c of centers) { const dd = Math.hypot(jx - c[0], jy - c[1]); if (dd < bd) { bd = dd; best = c[2]; } }
    const vd = Math.hypot((jx - VX) * 1.25, jy - VY);
    if (vd < 0.15) best = 5;
    const beachW = ny > 0.6 ? 4 : 2;
    if (cd[i] <= beachW && best !== 3) best = 1;
    biome[i] = best;
    if (best === 1) type[i] = cd[i] === 1 && ny > 0.5 ? T.TIDE : T.SAND;
    else if (best === 2) type[i] = T.GRASS;
    else if (best === 3) type[i] = fbm(x * 0.12, y * 0.12, seed + 11) > 0.56 ? T.MWATER : T.MUD;
    else if (best === 4) type[i] = T.PLATEAU;
    else type[i] = Math.hypot((nx - VX) * 1.25, ny - VY) < 0.045 ? T.ASH : T.VOLC;
  }
  for (let i = 0; i < N; i++) if (!land[i]) biome[i] = 0;
  const W = { type, biome, vari, cd, land, seed };
  const nearest = (fx, fy, pred) => {
    const cx = Math.floor(fx * MW), cy = Math.floor(fy * MH);
    for (let r = 0; r < 60; r++) for (let yy = cy - r; yy <= cy + r; yy++) for (let xx = cx - r; xx <= cx + r; xx++) {
      if (xx < 0 || yy < 0 || xx >= MW || yy >= MH) continue;
      if (Math.max(Math.abs(xx - cx), Math.abs(yy - cy)) !== r) continue;
      if (pred(yy * MW + xx, xx, yy)) return [xx, yy];
    }
    return [cx, cy];
  };
  W.nearest = nearest;
  // nascente e rio
  const [sx, sy] = nearest(0.47, 0.41, (i) => biome[i] === 2 && cd[i] > 8);
  W.spring = [sx, sy];
  let rx = sx;
  for (let y = sy; y < MH; y++) {
    rx += (vnoise(y * 0.09, 3, seed) - 0.5) * 1.6;
    let hitSea = false;
    for (let k = -1; k <= 0; k++) {
      const xx = Math.round(rx) + k, i = y * MW + xx;
      if (!land[i]) { hitSea = true; continue; }
      type[i] = T.RIVER;
    }
    if (hitSea) break;
  }
  for (let yy = sy - 1; yy <= sy + 1; yy++) for (let xx = sx - 1; xx <= sx + 1; xx++) type[yy * MW + xx] = T.SPRING;
  // caverna do planalto
  const [cx, cy] = nearest(0.28, 0.31, (i) => biome[i] === 4 && cd[i] > 6);
  W.cave = [cx, cy];
  for (let yy = cy - 4; yy <= cy + 4; yy++) for (let xx = cx - 4; xx <= cx + 4; xx++) {
    if (Math.hypot(xx - cx, yy - cy) < 4.3 + vnoise(xx * 0.5, yy * 0.5, seed) && land[yy * MW + xx]) type[yy * MW + xx] = T.CAVE;
  }
  // fontes termais
  W.hot = [];
  for (const fx of [0.43, 0.67]) {
    const [hx, hy] = nearest(fx, 0.2, (i) => biome[i] === 5 && type[i] === T.VOLC);
    W.hot.push([hx, hy]);
    for (let yy = hy; yy <= hy + 1; yy++) for (let xx = hx; xx <= hx + 1; xx++) type[yy * MW + xx] = T.HOT;
  }
  // zonas de gás
  const px = Math.round(VX * MW), py = Math.round(VY * MH);
  W.peak = [px, py];
  W.gas = [[px, py, 6], [px - 6, py + 4, 3.5], [px + 7, py + 2, 3.5]];
  return W;
}

function tileAt(W, tx, ty) {
  if (tx < 0 || ty < 0 || tx >= MW || ty >= MH) return T.DEEP;
  return W.type[ty * MW + tx];
}
function isWaterType(t) { return t === T.DEEP || t === T.SHALLOW || t === T.RIVER || t === T.SPRING || t === T.MWATER || t === T.HOT; }
