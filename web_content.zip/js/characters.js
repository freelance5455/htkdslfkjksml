"use strict";

const Characters = (() => {
  const TIER_LABELS = {
    core: "أساسي",
    basic: "أساسي",
    medium: "متوسط",
    advanced: "متقدم",
  };

  function addLine(parent, title, text) {
    const row = document.createElement("p");
    const label = document.createElement("b");
    label.textContent = title + ": ";
    row.appendChild(label);
    row.appendChild(document.createTextNode(text));
    parent.appendChild(row);
  }

  function buildCard(role) {
    const card = document.createElement("div");
    card.className = "role-card";
    card.style.setProperty("--role-color", role.color);

    const head = document.createElement("div");
    head.className = "role-head";

    const icon = document.createElement("span");
    icon.className = "role-icon";
    icon.textContent = role.icon;

    const name = document.createElement("span");
    name.className = "role-name";
    name.textContent = role.name;

    const badge = document.createElement("span");
    badge.className = "role-badge";
    badge.textContent = TIER_LABELS[role.tier];

    head.append(icon, name, badge);

    const desc = document.createElement("p");
    desc.className = "role-desc";
    desc.textContent = role.description;

    const details = document.createElement("div");
    details.className = "role-details";
    addLine(details, "القدرة", role.ability);
    addLine(details, "شرط الفوز", role.win);

    card.append(head, desc, details);
    card.addEventListener("click", () => card.classList.toggle("open"));
    return card;
  }

  function render() {
    const container = document.getElementById("characters-list");
    if (!container) return;
    container.innerHTML = "";
    ["mafia", "town", "neutral"].forEach((team) => {
      const title = document.createElement("h3");
      title.className = "team-title";
      title.textContent = Roles.TEAMS[team];
      container.appendChild(title);
      Roles.all()
        .filter((role) => role.team === team)
        .forEach((role) => container.appendChild(buildCard(role)));
    });
  }

  return { render };
})();