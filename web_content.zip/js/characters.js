// ===== CHARACTERS: original hero roster for the select screen =====
// These are all original designs (color + element theme only) -- no
// licensed characters, names, or likenesses from any franchise.

const CHARACTER_ROSTER = [
  { id: 'ember', name: 'Ember', color: 0xe0602a, tagline: 'Fire-forged fighter' },
  { id: 'volt', name: 'Volt', color: 0x3fc7dd, tagline: 'Lightning-quick striker' },
  { id: 'verdant', name: 'Verdant', color: 0x4a9d4a, tagline: 'Nature-bound guardian' },
  { id: 'shade', name: 'Shade', color: 0x8a5ac9, tagline: 'Shadow-step duelist' },
];

let selectedCharacterId = CHARACTER_ROSTER[0].id;
let auraPhase = 0;

function applyCharacter(id) {
  const c = CHARACTER_ROSTER.find(ch => ch.id === id) || CHARACTER_ROSTER[0];
  selectedCharacterId = c.id;
  player.userData.bodyMat.color.setHex(c.color);
  playerAura.material.color.setHex(c.color);
}

function setupCharacterSelect() {
  const wrap = document.getElementById('characterSelect');
  if (!wrap) return;
  CHARACTER_ROSTER.forEach(c => {
    const btn = document.createElement('button');
    btn.className = 'charBtn';
    btn.innerHTML = c.name + '<br><span class="charTagline">' + c.tagline + '</span>';
    btn.style.borderColor = '#' + c.color.toString(16).padStart(6, '0');
    if (c.id === selectedCharacterId) btn.classList.add('charBtnActive');
    btn.addEventListener('click', () => {
      applyCharacter(c.id);
      wrap.querySelectorAll('.charBtn').forEach(b => b.classList.remove('charBtnActive'));
      btn.classList.add('charBtnActive');
    });
    wrap.appendChild(btn);
  });
  applyCharacter(selectedCharacterId);
}
setupCharacterSelect();

function updateAura(dt) {
  auraPhase += dt * 2;
  playerAura.scale.setScalar(1 + Math.sin(auraPhase) * 0.08);
}
