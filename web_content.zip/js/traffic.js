/* ============================================================
   traffic.js — AI traffic, race rivals, police, pickups
   ============================================================ */
'use strict';

const TRAFFIC_COLORS = [0x2f3542, 0xb8bec9, 0x8a2f2a, 0x24557a, 0x3a4d2f, 0xc9c2b4, 0x1d1f24, 0x6a4a8a, 0xd9a520, 0x2f7a6a];
const RIVAL_COLORS = [0xff6a00, 0x2ee6ff, 0x9dff1a, 0xff2e88, 0xffc400];

const TRAFFIC_TYPES = {
  sedan:  { L: 4.55, W: 1.86, H: 1.45 },
  suv:    { L: 4.95, W: 2.02, H: 1.86 },
  sports: { L: 4.6,  W: 1.95, H: 1.24 },
  truck:  { L: 8.6,  W: 2.45, H: 3.2 },
};

class TrafficCar {
  constructor() {
    this.group = new THREE.Group();
    this.active = false;
    this.speed = 20;
    this.baseSpeed = 20;
    this.lane = 0;
    this.targetX = 0;
    this.direction = -1;
    this.passed = false;
    this.nearMissed = false;
    this.cool = 0;
    this.length = 4.5;
    this.width = 1.85;
    this.type = 'sedan';
    this.isRival = false;
    this.isPolice = false;
    this.lights = [];
  }
}

class Traffic {
  constructor(scene, envMap) {
    this.scene = scene;
    this.envMap = envMap;
    this.mode = 'free';
    this.forward = [];
    this.oncoming = [];
    this.rivals = [];
    this.police = [];
    this.pickups = [];
    this._geoCache = {};
    this._pickupGeo = {};
    this._buildMaterials();
    this._buildPools();
    this._buildPickups();
  }

  _buildMaterials() {
    this.bodyMat = new THREE.MeshStandardMaterial({
      vertexColors: true, metalness: 0.55, roughness: 0.38,
      envMap: this.envMap, envMapIntensity: 0.85,
    });
    this.lightsMat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
    this.policeRed = new THREE.MeshStandardMaterial({ color: 0x2a0000, emissive: 0xff1a08, emissiveIntensity: 0.2, roughness: 0.4 });
    this.policeBlue = new THREE.MeshStandardMaterial({ color: 0x001030, emissive: 0x1a6bff, emissiveIntensity: 0.2, roughness: 0.4 });
    this.coinMat = new THREE.MeshStandardMaterial({ color: 0xffc400, emissive: 0xff9d00, emissiveIntensity: 1.0, metalness: 0.9, roughness: 0.25 });
    this.fuelMat = new THREE.MeshStandardMaterial({ color: 0x22cc66, emissive: 0x0a5522, emissiveIntensity: 0.6, metalness: 0.4, roughness: 0.4 });
    this.nitroMat = new THREE.MeshStandardMaterial({ color: 0x2ee6ff, emissive: 0x0088aa, emissiveIntensity: 1.2, metalness: 0.6, roughness: 0.25 });
    this.pickupGlow = new THREE.MeshBasicMaterial({
      map: AD.glowTexture('rgba(255,220,120,0.9)', 'rgba(255,180,40,0)'),
      transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending,
    });
  }

  /* ---------------- model geometry ---------------- */
  _carGeo(type, color) {
    const key = type + '_' + color;
    if (this._geoCache[key]) return this._geoCache[key];
    const d = TRAFFIC_TYPES[type] || TRAFFIC_TYPES.sedan;
    const L = d.L, W = d.W, H = d.H;
    const body = [], lights = [];

    if (type === 'truck') {
      body.push(AD.P(AD.taperBox(W * 0.96, 1.5, 2.4, 0.95, 0.9), color, 0, 1.25, -L * 0.34));
      body.push(AD.P(new THREE.BoxGeometry(W * 0.98, 0.5, 2.2), 0x0b0d10, 0, 2.35, -L * 0.34));
      body.push(AD.P(new THREE.BoxGeometry(W, 2.4, 5.4), 0xd8dde3, 0, 1.75, L * 0.18));
      body.push(AD.P(new THREE.BoxGeometry(W * 0.9, 0.9, 0.12), 0x0a141c, 0, 1.95, -L * 0.34 - 1.22));
      for (const sx of [-1, 1]) {
        for (const z of [-L * 0.34, L * 0.32, L * 0.42]) {
          const w = new THREE.CylinderGeometry(0.45, 0.45, 0.34, 12);
          w.rotateZ(Math.PI / 2);
          body.push(AD.P(w, 0x08090b, sx * (W / 2 - 0.04), 0.45, z));
        }
      }
      lights.push(AD.P(new THREE.BoxGeometry(W * 0.8, 0.2, 0.08), 0xfff4d8, 0, 0.95, -L / 2 + 0.02));
      lights.push(AD.P(new THREE.BoxGeometry(W * 0.8, 0.2, 0.08), 0xff2200, 0, 0.95, L / 2 - 0.02));
    } else {
      const tall = type === 'suv';
      const bodyH = tall ? 0.75 : 0.55;
      const bodyBottom = 0.16;
      const bodyTop = bodyBottom + bodyH;
      const bodyY = bodyBottom + bodyH / 2;
      body.push(AD.P(AD.taperBox(W * 0.98, bodyH, L * 0.96, 0.99, 0.92), color, 0, bodyY, 0));
      body.push(AD.P(AD.taperBox(W * 0.9, bodyH * 0.7, L * 0.18, 0.86, 0.72), color, 0, bodyY - 0.02, -L * 0.45));
      const cabH = tall ? 0.78 : 0.52;
      const cabL = tall ? 2.7 : 2.15;
      body.push(AD.P(AD.taperBox(W * 0.86, cabH, cabL, 0.82, 0.66), color, 0, bodyTop + cabH / 2 - 0.02, tall ? 0.1 : 0.1));
      // glass
      body.push(AD.P(new THREE.BoxGeometry(W * 0.76, cabH * 0.86, 0.05), 0x0a141c, 0, bodyTop + cabH * 0.5, 0.1 - cabL * 0.48, -0.5, 0, 0));
      body.push(AD.P(new THREE.BoxGeometry(W * 0.74, cabH * 0.8, 0.05), 0x0a141c, 0, bodyTop + cabH * 0.5, 0.1 + cabL * 0.48, 0.5, 0, 0));
      for (const sx of [-1, 1]) {
        body.push(AD.P(new THREE.BoxGeometry(0.04, cabH * 0.62, cabL * 0.7), 0x0a141c,
          sx * W * 0.42, bodyTop + cabH * 0.55, 0.1));
      }
      // bumpers
      body.push(AD.P(new THREE.BoxGeometry(W * 0.95, 0.16, 0.2), 0x15171c, 0, 0.3, -L / 2 + 0.05));
      body.push(AD.P(new THREE.BoxGeometry(W * 0.95, 0.16, 0.2), 0x15171c, 0, 0.3, L / 2 - 0.05));
      // wheels
      for (const sx of [-1, 1]) {
        for (const z of [-L * 0.31, L * 0.31]) {
          const w = new THREE.CylinderGeometry(0.34, 0.34, 0.28, 10);
          w.rotateZ(Math.PI / 2);
          body.push(AD.P(w, 0x08090b, sx * (W / 2 - 0.02), 0.34, z));
        }
      }
      lights.push(AD.P(new THREE.BoxGeometry(W * 0.3, 0.12, 0.06), 0xfff4d8, -W * 0.3, bodyTop - 0.15, -L / 2 + 0.01));
      lights.push(AD.P(new THREE.BoxGeometry(W * 0.3, 0.12, 0.06), 0xfff4d8, W * 0.3, bodyTop - 0.15, -L / 2 + 0.01));
      lights.push(AD.P(new THREE.BoxGeometry(W * 0.7, 0.13, 0.06), 0xff2200, 0, bodyTop - 0.15, L / 2 - 0.01));
    }

    const g = { body: AD.merge(body), lights: AD.merge(lights) };
    this._geoCache[key] = g;
    return g;
  }

  _makeCar(type, color, isRival = false, isPolice = false) {
    const c = new TrafficCar();
    const d = TRAFFIC_TYPES[type] || TRAFFIC_TYPES.sedan;
    c.type = type; c.length = d.L; c.width = d.W;
    c.isRival = isRival; c.isPolice = isPolice;
    const geo = this._carGeo(type, color);
    const body = new THREE.Mesh(geo.body, this.bodyMat);
    body.castShadow = true;
    const lights = new THREE.Mesh(geo.lights, this.lightsMat);
    c.group.add(body, lights);
    if (isPolice) {
      const bar = new THREE.Group();
      const r = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.14, 0.24), this.policeRed);
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.14, 0.24), this.policeBlue);
      r.position.set(-0.34, d.H + 0.12, 0.1);
      b.position.set(0.34, d.H + 0.12, 0.1);
      bar.add(r, b);
      c.group.add(bar);
      const pl = new THREE.PointLight(0xff2244, 1.0, 16, 2);
      pl.position.set(0, d.H + 0.4, 0.1);
      c.group.add(pl);
      c.policeLight = pl;
      c.lightBar = bar;
    }
    c.group.visible = false;
    this.scene.add(c.group);
    return c;
  }

  _buildPools() {
    const types = ['sedan', 'sedan', 'suv', 'sports', 'truck'];
    for (let i = 0; i < 40; i++) {
      const t = types[(Math.random() * types.length) | 0];
      const col = TRAFFIC_COLORS[(Math.random() * TRAFFIC_COLORS.length) | 0];
      this.forward.push(this._makeCar(t, col));
    }
    for (let i = 0; i < 8; i++) {
      const t = types[(Math.random() * types.length) | 0];
      this.oncoming.push(this._makeCar(t, TRAFFIC_COLORS[(Math.random() * TRAFFIC_COLORS.length) | 0]));
    }
    for (let i = 0; i < 5; i++) {
      this.rivals.push(this._makeCar('sports', RIVAL_COLORS[i], true, false));
    }
    for (let i = 0; i < 3; i++) {
      this.police.push(this._makeCar('sedan', 0xf0f2f5, false, true));
    }
  }

  /* ---------------- pickups ---------------- */
  _buildPickups() {
    const coinGeo = new THREE.CylinderGeometry(0.34, 0.34, 0.09, 16);
    coinGeo.rotateX(Math.PI / 2);
    this._pickupGeo.coin = coinGeo;
    this._pickupGeo.fuel = new THREE.BoxGeometry(0.5, 0.62, 0.32);
    this._pickupGeo.nitro = new THREE.CylinderGeometry(0.24, 0.24, 0.8, 10);

    for (let i = 0; i < 28; i++) {
      const g = new THREE.Group();
      const coin = new THREE.Mesh(this._pickupGeo.coin, this.coinMat);
      coin.position.y = 0.9;
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({
        map: this.pickupGlow.map, color: 0xffd060, transparent: true,
        opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending,
      }));
      glow.scale.set(2.2, 2.2, 1);
      glow.position.y = 0.9;
      g.add(coin, glow);
      g.visible = false;
      g.userData = { type: 'coin', coin, glow, active: false, spin: Math.random() * 6 };
      this.scene.add(g);
      this.pickups.push(g);
    }
    // fuel + nitro pickups reuse the pool but swap meshes
    for (let i = 0; i < 10; i++) {
      const g = new THREE.Group();
      const fuel = new THREE.Mesh(this._pickupGeo.fuel, this.fuelMat);
      fuel.position.y = 0.55;
      const nitro = new THREE.Mesh(this._pickupGeo.nitro, this.nitroMat);
      nitro.position.y = 0.55;
      nitro.rotation.z = Math.PI / 2;
      nitro.visible = false;
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({
        map: this.pickupGlow.map, color: 0x66ffcc, transparent: true,
        opacity: 0.4, depthWrite: false, blending: THREE.AdditiveBlending,
      }));
      glow.scale.set(2, 2, 1);
      glow.position.y = 0.6;
      g.add(fuel, nitro, glow);
      g.visible = false;
      g.userData = { type: 'fuel', fuel, nitro, glow, active: false, spin: Math.random() * 6 };
      this.scene.add(g);
      this.pickups.push(g);
    }
  }

  _spawnPickup(p, playerZ, forceType) {
    const r = Math.random();
    let type;
    if (p.userData.coin) type = 'coin';
    else type = forceType || (r < 0.62 ? 'nitro' : 'fuel');
    p.userData.type = type;
    p.userData.active = true;
    p.userData.collected = false;
    p.visible = true;
    const lane = ENV.lanes[(Math.random() * ENV.lanes.length) | 0];
    p.position.set(lane + AD.rand(-0.4, 0.4), 0, playerZ - AD.rand(120, 950));
    if (p.userData.fuel) {
      p.userData.fuel.visible = type === 'fuel';
      p.userData.nitro.visible = type === 'nitro';
      p.userData.glow.material.color.setHex(type === 'fuel' ? 0x66ff99 : 0x66ccff);
    }
    if (p.userData.coin) p.userData.coin.visible = type === 'coin';
  }

  /* ---------------- configure / reset ---------------- */
  _counts() {
    switch (this.mode) {
      case 'traffic': return { fwd: 34, onc: 5, rivals: 0, police: 0, pickups: 14 };
      case 'race': return { fwd: 14, onc: 4, rivals: 5, police: 0, pickups: 12 };
      case 'drift': return { fwd: 14, onc: 3, rivals: 0, police: 0, pickups: 10 };
      case 'police': return { fwd: 20, onc: 4, rivals: 0, police: 3, pickups: 10 };
      case 'time': return { fwd: 16, onc: 4, rivals: 0, police: 0, pickups: 12 };
      case 'extreme': return { fwd: 36, onc: 6, rivals: 0, police: 0, pickups: 16 };
      default: return { fwd: 24, onc: 7, rivals: 0, police: 0, pickups: 18 };
    }
  }

  reset(playerZ, modeId) {
    this.mode = modeId || 'free';
    const n = this._counts();
    this.forward.forEach((c, i) => { c.active = i < n.fwd; c.group.visible = c.active; });
    this.oncoming.forEach((c, i) => { c.active = i < n.onc; c.group.visible = c.active; });
    this.rivals.forEach((c, i) => { c.active = i < n.rivals; c.group.visible = c.active; });
    this.police.forEach((c, i) => { c.active = i < n.police; c.group.visible = c.active; });

    for (const c of this.forward) if (c.active) this._respawnForward(c, playerZ);
    for (const c of this.oncoming) if (c.active) this._respawnOncoming(c, playerZ);
    for (const c of this.police) if (c.active) this._respawnPolice(c, playerZ);

    this.rivals.forEach((c, i) => {
      if (!c.active) return;
      c.lane = ENV.lanes[i % ENV.lanes.length];
      c.targetX = c.lane;
      c.group.position.set(c.lane, 0, playerZ - (18 + i * 13));
      c.speed = 56 + i * 3;
      c.baseSpeed = c.speed;
      c.passed = false; c.nearMissed = false; c.cool = 0;
      c.group.rotation.y = 0;
    });

    /* pool layout: indices 0..27 are coins, 28..37 are fuel/nitro.
       Mix both kinds so boosts actually appear on the road. */
    const fuelCount = Math.max(2, Math.round(n.pickups * 0.28));
    const coinCount = n.pickups - fuelCount;
    let coinsUsed = 0, fuelsUsed = 0;
    for (const p of this.pickups) {
      const coinPool = !!p.userData.coin;
      let use = false;
      if (coinPool && coinsUsed < coinCount) { use = true; coinsUsed++; }
      else if (!coinPool && fuelsUsed < fuelCount) { use = true; fuelsUsed++; }
      if (use) this._spawnPickup(p, playerZ);
      else { p.visible = false; p.userData.active = false; }
    }
    this._playerZ = playerZ;
  }

  _respawnForward(c, playerZ) {
    c.lane = ENV.lanes[(Math.random() * ENV.lanes.length) | 0];
    c.targetX = c.lane;
    c.speed = (48 + Math.random() * 75) / 3.6;
    if (this.mode === 'extreme') c.speed = (80 + Math.random() * 90) / 3.6;
    c.baseSpeed = c.speed;
    const dist = 70 + Math.random() * 720;
    c.group.position.set(c.lane, 0, playerZ - dist);
    c.group.rotation.y = 0;
    c.direction = -1;
    c.passed = false; c.nearMissed = false; c.cool = 0;
    c.active = true;
    c.group.visible = true;
  }

  _respawnOncoming(c, playerZ) {
    c.lane = ENV.oncomingLanes[(Math.random() * ENV.oncomingLanes.length) | 0];
    c.targetX = c.lane;
    c.speed = 20 + Math.random() * 14;
    c.baseSpeed = c.speed;
    c.group.position.set(c.lane, 0, playerZ - AD.rand(120, 620));
    c.group.rotation.y = Math.PI;
    c.direction = 1;
    c.active = true;
    c.group.visible = true;
    c.cool = 0;
  }

  _respawnPolice(c, playerZ) {
    c.lane = ENV.lanes[(Math.random() * ENV.lanes.length) | 0];
    c.targetX = c.lane;
    c.speed = 30;
    c.baseSpeed = 60;
    c.group.position.set(c.lane, 0, playerZ + AD.rand(38, 90));
    c.group.rotation.y = 0;
    c.direction = -1;
    c.active = true;
    c.group.visible = true;
    c.cool = 0;
    c.passed = false;
  }

  setPoliceCount(n) {
    this.police.forEach((c, i) => {
      const on = i < n;
      if (on && !c.active) {
        this._respawnPolice(c, this._playerZ || 0);
      }
      c.active = on;
      c.group.visible = on;
    });
  }

  /* ---------------- update ---------------- */
  update(dt, player, cb) {
    cb = cb || {};
    const pz = player.pos.z;
    const px = player.pos.x;
    this._playerZ = pz;
    let crash = null;
    let overtakes = 0;
    let nearMiss = 0;
    let policeContact = null;

    // police light flashing
    const phase = performance.now() / 1000;
    this.policeRed.emissiveIntensity = Math.sin(phase * 9) > 0 ? 4 : 0.15;
    this.policeBlue.emissiveIntensity = Math.sin(phase * 9) > 0 ? 0.15 : 4;

    // ---- forward traffic ----
    for (const c of this.forward) {
      if (!c.active) continue;
      c.cool = Math.max(0, c.cool - dt);
      const ahead = this._aheadInLane(c, player);
      if (ahead) {
        const gap = c.group.position.z - ahead.z;
        const closing = c.speed - ahead.speed;
        if (gap < 30 && closing > -2) {
          if (!this._tryLaneChange(c, player)) {
            c.speed = Math.max(ahead.speed * 0.9, c.speed - (closing * 1.6 + 5) * dt);
          }
        } else if (gap > 44 && c.speed < c.baseSpeed) {
          c.speed = Math.min(c.baseSpeed, c.speed + 2.4 * dt);
        }
      } else if (c.speed < c.baseSpeed) {
        c.speed = Math.min(c.baseSpeed, c.speed + 2 * dt);
      }
      this._laneEase(c, dt);
      c.group.position.z -= c.speed * dt;

      if (c.group.position.z < pz - 760 || c.group.position.z > pz + 240) {
        this._respawnForward(c, pz);
        continue;
      }
      if (!c.passed && c.group.position.z > pz && Math.abs(c.group.position.x - px) < 7) {
        c.passed = true;
        overtakes++;
      }
      // near miss
      const dx = c.group.position.x - px;
      const dz = c.group.position.z - pz;
      if (!c.nearMissed && !c.passed && Math.abs(dx) < 2.8 && Math.abs(dz) < 4.2 && player.speed > 14) {
        c.nearMissed = true;
        nearMiss++;
      }
      const hit = this._collision(c, player, false);
      if (hit && !crash && c.cool <= 0) {
        c.cool = 0.8;
        crash = hit;
      }
    }

    // ---- rivals ----
    for (const c of this.rivals) {
      if (!c.active) continue;
      c.cool = Math.max(0, c.cool - dt);
      const dz = c.group.position.z - pz;
      // rubber band so the race stays close
      let target = c.baseSpeed;
      if (dz < -220) target *= 0.92;
      else if (dz > 150) target *= 1.1;
      c.speed = AD.damp(c.speed, target, 1.2, dt);
      this._laneEase(c, dt);
      c.group.position.z -= c.speed * dt;
      const hit = this._collision(c, player, false);
      if (hit && !crash && c.cool <= 0) { c.cool = 0.8; crash = hit; }
    }

    // ---- police ----
    for (const c of this.police) {
      if (!c.active) continue;
      c.cool = Math.max(0, c.cool - dt);
      const dz = c.group.position.z - pz;
      if (dz > 220) { this._respawnPolice(c, pz); continue; }
      const targetX = px + Math.sin(performance.now() / 1400 + c.group.position.z) * 1.6;
      c.targetX = AD.clamp(targetX, ENV.lanes[0] - 1, ENV.lanes[2] + 1);
      this._laneEase(c, dt, 1.8);
      const targetSpeed = Math.min(72, Math.max(22, Math.abs(player.speed) + 7));
      c.speed = AD.damp(c.speed, targetSpeed, 1.4, dt);
      c.group.position.z -= c.speed * dt;
      const hit = this._collision(c, player, true);
      if (hit && c.cool <= 0) {
        c.cool = 0.7;
        if (!crash) crash = hit;
        policeContact = hit;
      }
      // flashing point light
      if (c.policeLight) {
        c.policeLight.color.setHex(Math.sin(phase * 9) > 0 ? 0xff2244 : 0x2266ff);
        c.policeLight.intensity = 1.4;
      }
    }

    // ---- oncoming ----
    for (const c of this.oncoming) {
      if (!c.active) continue;
      c.group.position.z += c.speed * dt;
      if (c.group.position.z > pz + 90) this._respawnOncoming(c, pz);
    }

    // ---- pickups ----
    for (const p of this.pickups) {
      if (!p.visible || !p.userData.active) continue;
      p.userData.spin += dt * 2.4;
      if (p.userData.coin) p.userData.coin.rotation.y = p.userData.spin;
      p.position.y = Math.sin(performance.now() / 500 + p.userData.spin) * 0.12;
      const dx = p.position.x - px;
      const dz = p.position.z - pz;
      if (Math.abs(dx) < 1.9 && Math.abs(dz) < 2.4) {
        p.userData.active = false;
        p.visible = false;
        if (cb.onPickup) cb.onPickup(p.userData.type);
      } else if (p.position.z > pz + 80) {
        this._spawnPickup(p, pz);
      }
    }

    if (overtakes > 0 && cb.onOvertake) cb.onOvertake(overtakes);
    if (nearMiss > 0 && cb.onNearMiss) cb.onNearMiss(nearMiss);
    if (crash && cb.onCrash) cb.onCrash(crash);
    if (policeContact && cb.onPoliceContact) cb.onPoliceContact(policeContact);
  }

  _laneEase(c, dt, speed = 2.8) {
    if (c.targetX === undefined) return;
    const dx = c.targetX - c.group.position.x;
    if (Math.abs(dx) > 0.03) {
      c.group.position.x += Math.sign(dx) * Math.min(Math.abs(dx), speed * dt);
    } else {
      c.group.position.x = c.targetX;
      c.lane = c.targetX;
    }
  }

  _collision(c, player, isPolice) {
    const dz = c.group.position.z - player.pos.z;
    const dx = c.group.position.x - player.pos.x;
    const latLimit = (c.width + player.spec.W) / 2 - 0.1;
    const longLimit = (c.length + player.spec.L) / 2 - 0.2;
    if (Math.abs(dx) >= latLimit || Math.abs(dz) >= longLimit) return null;
    let impact;
    if (isPolice) impact = Math.max(6, Math.abs(player.speed - c.speed) + 8);
    else impact = Math.max(0, player.speed - c.speed);
    const pushX = -Math.sign(dx || 1) * (latLimit - Math.abs(dx) + 0.08);
    const pushZ = -Math.sign(dz || 1) * (longLimit - Math.abs(dz) + 0.08);
    c.speed = Math.max(4, c.speed * 0.55);
    c.baseSpeed = Math.min(c.baseSpeed, c.speed);
    return {
      car: c, impact, pushX, pushZ, police: !!isPolice,
      side: Math.abs(dx) > Math.abs(dz) * 0.6 ? Math.sign(dx) : 0,
    };
  }

  _aheadInLane(c, player) {
    let best = null, bestZ = -1e9;
    const cx = c.targetX !== undefined ? c.targetX : c.group.position.x;
    for (const o of this.forward) {
      if (o === c || !o.active) continue;
      if (Math.abs((o.targetX ?? o.group.position.x) - cx) > 2.2) continue;
      const z = o.group.position.z;
      if (z < c.group.position.z && z > bestZ) { bestZ = z; best = { z, speed: o.speed }; }
    }
    if (player && Math.abs(player.pos.x - cx) <= 2.4) {
      const z = player.pos.z;
      if (z < c.group.position.z && z > bestZ) best = { z, speed: Math.max(0, player.speed) };
    }
    return best;
  }

  _tryLaneChange(c, player) {
    if (c.targetX === undefined) return false;
    const laneIdx = ENV.lanes.indexOf(c.targetX);
    if (laneIdx < 0) return false;
    const options = [];
    if (laneIdx > 0) options.push(ENV.lanes[laneIdx - 1]);
    if (laneIdx < ENV.lanes.length - 1) options.push(ENV.lanes[laneIdx + 1]);
    for (const lane of options) {
      let free = true;
      for (const o of this.forward) {
        if (o === c || !o.active) continue;
        if (Math.abs((o.targetX ?? o.group.position.x) - lane) > 2.2) continue;
        const dz = o.group.position.z - c.group.position.z;
        if (dz > -12 && dz < 55) { free = false; break; }
      }
      if (player && Math.abs(player.pos.x - lane) <= 2.4) {
        const dz = player.pos.z - c.group.position.z;
        if (dz > -14 && dz < 65) free = false;
      }
      if (free) { c.targetX = lane; return true; }
    }
    return false;
  }

  getRank(playerZ) {
    let ahead = 0;
    for (const c of this.rivals) {
      if (c.active && c.group.position.z < playerZ) ahead++;
    }
    return ahead + 1;
  }

  nearestPolice(player) {
    let best = 1e9;
    for (const c of this.police) {
      if (!c.active) continue;
      const d = Math.hypot(c.group.position.x - player.pos.x, c.group.position.z - player.pos.z);
      if (d < best) best = d;
    }
    return best;
  }
}
