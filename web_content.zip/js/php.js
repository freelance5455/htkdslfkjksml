/* =============================================================
   LAMPION POS · js/php.js
   Pengganti includes/functions.php
   -------------------------------------------------------------
   Berisi padanan JavaScript untuk helper PHP:
     e()                      -> esc()
     rupiah()                 -> money()
     money_input()            -> parseMoney()
     get_setting()            -> LPDB.getSetting()
     generate_order_number()  -> generateOrderNumber()
     csrf_token()/csrf_check()-> csrfToken()/csrfCheck()
     log_activity()           -> logActivity()
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;

  /* ---------- format & parse uang (rupiah / money_input) ---------- */
  function money(n) {
    var v = Math.round(Number(n) || 0);
    try {
      return 'Rp ' + v.toLocaleString('id-ID');
    } catch (e) {
      return 'Rp ' + v;
    }
  }

  /** Parse input harga "Rp 18.000,50" / "18000" -> float (padanan money_input) */
  function parseMoney(s) {
    s = String(s === null || s === undefined ? '' : s).trim();
    if (s === '') { return 0; }
    s = s.replace(/Rp/gi, '').replace(/[\s.]/g, '').replace(/,/g, '.');
    var v = parseFloat(s);
    return isFinite(v) ? v : 0;
  }

  /* ---------- HTML escape (padanan e()) ---------- */
  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /* ---------- pembulatan 2 desimal (padanan round(x*100)/100) ---------- */
  function round2(n) {
    return Math.round((Number(n) || 0) * 100) / 100;
  }

  /* =============================================================
     Nomor nota — padanan generate_order_number()
     Format: DI-20260922-0001
     Counter disimpan di tabel settings, reset otomatis saat ganti hari.
     ============================================================= */
  var TYPE_PREFIX = DB.ORDER_TYPE_PREFIX;

  function generateOrderNumber(type) {
    var today = DB.todayCompact();
    var keys = Object.keys(TYPE_PREFIX);

    return DB.getSetting('counter_date', '').then(function (saved) {
      var step = Promise.resolve();
      if (String(saved) !== today) {
        step = Promise.all(keys.map(function (t) {
          return DB.setSetting('counter_' + t, '0');
        })).then(function () {
          return DB.setSetting('counter_date', today);
        });
      }
      return step;
    }).then(function () {
      return DB.getSetting('counter_' + type, '0');
    }).then(function (cur) {
      var next = (parseInt(cur, 10) || 0) + 1;
      return DB.setSetting('counter_' + type, String(next)).then(function () {
        var prefix = TYPE_PREFIX[type] || 'OT';
        var pad = String(next);
        while (pad.length < 4) { pad = '0' + pad; }
        return prefix + '-' + today + '-' + pad;
      });
    });
  }

  /* =============================================================
     CSRF — padanan csrf_token() / csrf_check()
     Karena tidak ada lagi server, token berperan sebagai penanda
     sesi internal (mencegah submit dari konteks luar).
     ============================================================= */
  var CSRF_LS_KEY = 'lpos_csrf';

  function csrfToken() {
    var t = null;
    try { t = localStorage.getItem(CSRF_LS_KEY); } catch (e) { t = null; }
    if (!t) {
      t = DB.randomHex(16);
      try { localStorage.setItem(CSRF_LS_KEY, t); } catch (e2) { /* mode privat */ }
    }
    return t;
  }

  function csrfField() {
    return '<input type="hidden" name="_token" value="' + csrfToken() + '">';
  }

  function csrfCheck(given) {
    return String(csrfToken()) === String(given || '');
  }

  /* ---------- total keranjang (padanan _totals() di api/orders.php) ---------- */
  function computeTotals(subtotal, discount, taxRate) {
    subtotal = Number(subtotal) || 0;
    discount = Number(discount) || 0;
    if (discount > subtotal) { discount = subtotal; }
    var taxable = subtotal - discount;
    var tax = round2(taxable * (Number(taxRate) || 0) / 100);
    return { subtotal: subtotal, discount: discount, tax: tax, total: taxable + tax };
  }


  /* =============================================================
     Activity log — padanan log_activity()
     Selalu best-effort: kegagalan log tidak boleh memutus alur.
     ============================================================= */
  var currentUserGetter = function () { return null; };

  /** dipasang oleh js/auth.js supaya tidak ada circular dependency */
  function setUserGetter(fn) { currentUserGetter = fn; }

  function logActivity(action, target, detail) {
    try {
      var u = currentUserGetter();
      var uid = (u && u.id) ? Number(u.id) : 0;
      var det = '';
      if (detail !== undefined && detail !== null) {
        det = (typeof detail === 'object') ? JSON.stringify(detail) : String(detail);
      }
      return db.activity_log.add({
        user_id: uid > 0 ? uid : null,
        action: String(action),
        target: (target === undefined || target === null) ? null : String(target),
        detail: det !== '' ? det : null,
        ip: 'local',
        user_agent: (global.navigator && navigator.userAgent) ? navigator.userAgent.slice(0, 255) : '',
        created_at: DB.now()
      }).catch(function () { return null; });
    } catch (e) {
      return Promise.resolve(null);
    }
  }

  /* =============================================================
     Flash message — padanan flash_set() / flash_dump()
     Dulu di $_SESSION; sekarang sessionStorage (per-tab).
     ============================================================= */
  var FLASH_KEY = 'lpos_flash';

  function flashSet(type, msg) {
    var list = [];
    try { list = JSON.parse(sessionStorage.getItem(FLASH_KEY) || '[]'); } catch (e) { list = []; }
    list.push({ type: type, msg: msg });
    try { sessionStorage.setItem(FLASH_KEY, JSON.stringify(list)); } catch (e2) { /* noop */ }
  }

  function flashDump() {
    var list = [];
    try { list = JSON.parse(sessionStorage.getItem(FLASH_KEY) || '[]'); } catch (e) { list = []; }
    try { sessionStorage.removeItem(FLASH_KEY); } catch (e2) { /* noop */ }
    return list;
  }

  global.LPHP = {
    money: money,
    parseMoney: parseMoney,
    esc: esc,
    round2: round2,
    generateOrderNumber: generateOrderNumber,
    csrfToken: csrfToken,
    csrfField: csrfField,
    csrfCheck: csrfCheck,
    logActivity: logActivity,
    setUserGetter: setUserGetter,
    flashSet: flashSet,
    flashDump: flashDump,
    computeTotals: computeTotals
  };
})(window);

