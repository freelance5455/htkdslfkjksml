/* economy-ui.js — Phase 4 interface: Industry panel (Overview / Production / Construction / Trade). */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const fmt = n => Math.round(n).toLocaleString('en-US');
  const f1 = n => (Math.round(n * 10) / 10).toFixed(1);
  const sgn = n => (n >= 0 ? '+' : '−') + f1(Math.abs(n));
  let tab = 'overview', buildProv = null;

  function bar(frac, cls) { return '<div class="bar ' + (cls || '') + '"><i style="width:' + Math.max(0, Math.min(100, frac * 100)).toFixed(0) + '%"></i></div>'; }
  function cell(l, v) { return '<div class="cell"><span>' + l + '</span>' + v + '</div>'; }
  const me = () => G.state.player;

  G.showIndustry = function (which, prov) {
    if (which) tab = which;
    if (prov != null) buildProv = prov;
    const st = G.state, id = me(), c = st.countries[id];
    if (buildProv == null || st.owners[buildProv] !== id) {
      buildProv = (G.selected != null && st.owners[G.selected] === id) ? G.selected : G.COUNTRIES[id].capitalId;
    }
    const names = { overview: 'Overview', production: 'Production', construction: 'Construction (' + st.construct.filter(x => x.owner === id).length + ')', trade: 'Trade' };
    let h = '<h3>🏭 Industry — ' + G.COUNTRIES[id].name + '</h3>' +
      '<div class="tabs">' + Object.keys(names).map(t => '<button data-t="' + t + '" class="' + (tab === t ? 'on' : '') + '">' + names[t] + '</button>').join('') + '</div>';
    if (c.starving) h += '<div class="alert">🌾 Food shortage — manpower growth halved and morale falling. Buy food in the Trade tab.</div>';
    { const fnet = (c.dRes.food || 0) - (c.foodNeed || 0);
      if (fnet < 0 && !c.starving) h += '<div class="alert">🌾 Food deficit ' + f1(fnet) + '/day. Fix it: build Farm Estates (Construction tab), research Agricultural Methods (🔬), or buy food (Trade tab).</div>'; }
    if (c.broke) h += '<div class="alert">💰 Treasury empty — morale falling. Raise taxes or cut costs.</div>';
    h += ({ overview: overviewTab, production: productionTab, construction: constructionTab, trade: tradeTab })[tab](id, c);
    h += '<div class="row"><button id="in-close">Close</button></div>';
    $('modal-box').innerHTML = h; $('modal').classList.remove('hidden');
    $('in-close').onclick = G.closeModal;
    document.querySelectorAll('#modal-box .tabs button[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; G.showIndustry(); });
    bind(id);
  };

  /* ----- overview ----- */
  function overviewTab(id, c) {
    const st = G.state, t = G.totals(id), tax = G.TAX[st.tax[id]];
    let h = '<div class="grid">' +
      cell('Civilian factories', t.civ + '<br><small class="dim">effective ' + f1(G.civEfficiency(id)) + ' (consumer goods ' + Math.round(G.consumerShare(id) * 100) + '%)</small>') +
      cell('Military factories', t.mil + '<br><small class="dim">' + G.allocTotal(id) + ' assigned</small>') +
      cell('Shipyards / Ports', t.dock + ' / ' + t.port + '<br><small class="dim">trade cap ' + G.tradeCap(id) + '/mo</small>') +
      cell('Construction', f1(G.constructionPoints(id)) + ' pts/day') + '</div>';
    h += '<h3>Budget (per day)</h3><div class="grid">' +
      cell('Taxes', '<b style="color:var(--green)">' + sgn(c.income || 0) + '</b>') +
      cell('Army upkeep', '<b style="color:#ff9a8a">−' + f1(c.expArmy || 0) + '</b>') +
      cell('Industry upkeep', '<b style="color:#ff9a8a">−' + f1(c.expInd || 0) + '</b>') +
      cell('Net income', '<b>' + sgn(c.dIncome || 0) + '</b>') + '</div>';
    h += '<div class="chips" style="align-items:center"><span class="dim">Tax policy:</span>' +
      Object.keys(G.TAX).map(k => '<button data-tax="' + k + '" class="' + (st.tax[id] === k ? 'primary' : '') + '">' + G.TAX[k].name + '</button>').join('') +
      '<span class="dim" style="font-size:12px">' + tax.desc + '</span></div>';
    h += '<h3>Resources</h3><div class="rtable"><div class="rh"><span></span><span>Stock</span><span>Prod</span><span>Use</span><span>Net</span></div>' +
      G.RESOURCES.map(r => {
        const prod = c.dRes[r] || 0, use = r === 'food' ? (c.foodNeed || 0) : (c.consume && c.consume[r]) || 0, net = prod - use;
        const warn = net < 0 && c.res[r] < Math.abs(net) * 30;
        return '<div class="' + (warn ? 'rw warn' : 'rw') + '"><span>' + G.RES_ICONS[r] + ' ' + G.RES_NAMES[r] + '</span><span>' + fmt(c.res[r]) + '</span><span>' + f1(prod) + '</span><span>' + f1(use) + '</span><span>' + sgn(net) + '</span></div>';
      }).join('') + '</div>';
    h += '<h3>Equipment stockpile</h3><div class="grid">' + G.EQUIP.map(k => {
      const made = (c.produce && c.produce[k]) || 0;
      return cell(G.EQUIP_NAMES[k], fmt(c.equip[k]) + (G.RECIPES[k] ? '<br><small class="dim">' + sgn(made) + '/day</small>' : '<br><small class="dim">+' + f1((c.provCount || 0) * 6 / 30) + '/day (breeding)</small>'));
    }).join('') + '</div>';
    return h;
  }

  /* ----- production ----- */
  function productionTab(id, c) {
    const st = G.state, t = G.totals(id), a = st.alloc[id], idle = t.mil - G.allocTotal(id);
    let h = '<p class="dim">Military factories turn steel, coal, oil and rubber into equipment. Recruiting and reinforcing units uses this stockpile. Horses breed on farmland.</p>';
    h += '<div class="eqline">Military factories: ' + t.mil + ' · assigned ' + G.allocTotal(id) + ' · idle ' + idle + '</div>';
    h += G.LINES.map(l => {
      const rc = G.RECIPES[l], n = a[l], eff = c.lineEff && c.lineEff[l] != null ? c.lineEff[l] : 1;
      const need = Object.keys(rc.need).map(r => G.RES_ICONS[r] + ' ' + f1(rc.need[r] * n) + '/d').join('  ');
      return '<div class="slot"><div class="info"><b>' + rc.name + '</b> <small>stock ' + fmt(c.equip[l]) + '</small><br>' +
        '<small>Output ' + f1(rc.out * n * eff) + '/day at ' + Math.round(eff * 100) + '% efficiency · needs ' + (n ? need : '—') + '</small>' + bar(eff, eff < 0.7 ? 'y' : 'g') + '</div>' +
        '<div class="stepper"><button data-a="' + l + '" data-d="-1">−</button><b>' + n + '</b><button data-a="' + l + '" data-d="1"' + (idle <= 0 ? ' disabled' : '') + '>+</button></div></div>';
    }).join('');
    h += '<div class="chips"><button id="in-auto">Auto-balance factories</button></div>';
    return h;
  }

  /* ----- construction ----- */
  function constructionTab(id, c) {
    const st = G.state;
    const own = G.provinces.filter(p => !p.sea && st.owners[p.id] === id);
    const pb = st.pb[buildProv], p = G.provinces[buildProv];
    let h = '<div class="eqline">Capacity ' + f1(G.constructionPoints(id)) + ' points/day · 💰 ' + fmt(c.treasury) + '</div>';
    h += '<div style="margin:6px 0">Province: <select id="in-prov">' + own.map(q => '<option value="' + q.id + '"' + (q.id === buildProv ? ' selected' : '') + '>' + q.name + (q.capital ? ' ★' : '') + '</option>').join('') + '</select> ' +
      '<small class="dim">🏭' + pb.civ + ' 🔧' + pb.mil + ' ⚓' + pb.dock + ' · infra ' + pb.infra + ' · rail ' + pb.rail + ' · port ' + pb.port + ' · 🌾' + pb.farm + ' · slots ' + G.slotsUsed(buildProv) + '/' + G.slotsOf(buildProv) + '</small></div>';
    h += '<div class="ucards">' + Object.keys(G.BUILD).map(k => {
      const chk = G.canBuild(id, k, buildProv), cost = G.buildCost(k, buildProv);
      const lvl = k === 'infra' ? ' (lvl ' + pb.infra + '→' + (pb.infra + 1) + ')' : (G.BUILD[k].max ? ' (lvl ' + pb[k] + '→' + (pb[k] + 1) + ')' : '');
      return '<div class="ucard"><div class="uh"><span class="utag">' + G.BUILD[k].icon + '</span><b>' + G.BUILD[k].name + lvl + '</b></div>' +
        '<div class="ucost">💰 ' + cost.gold + ' · ' + cost.points + ' pts</div>' +
        '<button class="' + (chk.ok ? 'primary' : '') + '" data-b="' + k + '"' + (chk.ok ? '' : ' disabled') + '>' + (chk.ok ? 'Build' : chk.msg) + '</button></div>';
    }).join('') + '</div>';
    const q = st.construct.filter(x => x.owner === id);
    h += '<h3>Queue</h3>' + (q.length ? q.map(it => '<div class="slot"><div class="info"><b>' + G.BUILD[it.type].icon + ' ' + G.BUILD[it.type].name + '</b> <small>at ' + G.provinces[it.prov].name + ' · ' + Math.ceil(it.left) + ' pts left</small>' +
      bar(1 - it.left / it.total, 'g') + '</div><button class="danger" data-cb="' + it.id + '">Cancel</button></div>').join('') : '<p class="dim">Nothing under construction.</p>');
    return h;
  }

  /* ----- trade ----- */
  function tradeTab(id, c) {
    let h = '<div class="eqline">Trade capacity left this month: ' + G.tradeLeft(id) + ' / ' + G.tradeCap(id) + ' · 💰 ' + fmt(c.treasury) + '</div>' +
      '<p class="dim">Ports and shipyards raise capacity. Prices drift over time; buying costs more than selling pays.</p>';
    h += G.RESOURCES.map(r => '<div class="slot"><div class="info"><b>' + G.RES_ICONS[r] + ' ' + G.RES_NAMES[r] + '</b> <small>stock ' + fmt(c.res[r]) + '</small><br><small>Buy ' + G.buyPrice(r) + ' · Sell ' + G.sellPrice(r) + ' gold each</small></div>' +
      '<div class="tbtns"><button data-t2="' + r + '" data-q="-50">−50</button><button data-t2="' + r + '" data-q="-10">−10</button><button class="primary" data-t2="' + r + '" data-q="10">+10</button><button class="primary" data-t2="' + r + '" data-q="50">+50</button></div></div>').join('');
    return h;
  }

  function bind(id) {
    document.querySelectorAll('#modal-box button[data-tax]').forEach(b => b.onclick = () => { G.state.tax[id] = b.dataset.tax; G.refreshBudget(); G.updateTopBar(); G.showIndustry(); });
    document.querySelectorAll('#modal-box button[data-a]').forEach(b => b.onclick = () => { G.setAlloc(id, b.dataset.a, +b.dataset.d); G.showIndustry(); });
    const au = $('in-auto'); if (au) au.onclick = () => { G.autoAlloc(id); G.showIndustry(); };
    const sel = $('in-prov'); if (sel) sel.onchange = () => { buildProv = +sel.value; G.showIndustry(); };
    document.querySelectorAll('#modal-box button[data-b]').forEach(b => b.onclick = () => {
      const r = G.startBuild(id, b.dataset.b, buildProv);
      G.toast(r.ok ? G.BUILD[b.dataset.b].name + ' queued' : r.msg); G.updateTopBar(); G.showIndustry();
    });
    document.querySelectorAll('#modal-box button[data-cb]').forEach(b => b.onclick = () => { G.cancelBuild(id, +b.dataset.cb); G.toast('Cancelled — gold refunded'); G.updateTopBar(); G.showIndustry(); });
    document.querySelectorAll('#modal-box button[data-t2]').forEach(b => b.onclick = () => {
      const r = G.trade(id, b.dataset.t2, +b.dataset.q);
      G.toast(r.ok ? (+b.dataset.q > 0 ? 'Bought ' : 'Sold ') + Math.abs(b.dataset.q) + ' ' + G.RES_NAMES[b.dataset.t2].toLowerCase() : r.msg);
      G.updateTopBar(); G.showIndustry();
    });
  }

  /* ----- province panel hook ----- */
  G.provinceEconHtml = function (prov) {
    const st = G.state, b = st.pb[prov]; if (!b) return '';
    let h = '<div class="chips"><span class="dim" style="font-size:12px;align-self:center">🏭 ' + b.civ + ' · 🔧 ' + b.mil + ' · ⚓ ' + b.dock + ' · rail ' + b.rail + ' · port ' + b.port + ' · 🌾 ' + b.farm + ' · slots ' + G.slotsUsed(prov) + '/' + G.slotsOf(prov) + '</span>';
    if (st.owners[prov] === st.player) h += '<button id="pv-build">🏗 Build…</button>';
    return h + '</div>';
  };
  G.bindProvinceEcon = function (prov) {
    const b = $('pv-build'); if (b) b.onclick = () => G.showIndustry('construction', prov);
  };

  G.bindEconomyUI = function () { $('btn-ind').onclick = () => G.showIndustry(); };

  G.onBuilt = function (it) { G.toast(G.BUILD[it.type].name + ' completed at ' + G.provinces[it.prov].name); G.refreshPanel(); };
})(window.EMP = window.EMP || {});
