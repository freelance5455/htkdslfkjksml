/* يمكن هدف؟ — SVG visualisations */
(function () {
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const col = (c, fb) => (c && /^[0-9a-f]{6}$/i.test(c) ? '#' + c : fb);
  function lum(hex) { const h = hex.replace('#', ''); const r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16); return (0.299 * r + 0.587 * g + 0.114 * b) / 255; }
  /* pick a team colour that reads on the dark lapis background and differs from the opponent */
  function teamColors(h, a) {
    let ch = col(h && h.color, '#3b82f6'), ca = col(a && a.color, '#f97316');
    if (lum(ch) < 0.22) ch = col(h && h.alt, '#3b82f6');
    if (lum(ca) < 0.22) ca = col(a && a.alt, '#f97316');
    if (lum(ch) < 0.22) ch = '#3b82f6';
    if (lum(ca) < 0.22) ca = '#f97316';
    const dist = (x, y) => { const p = s => [1, 3, 5].map(i => parseInt(s.substr(i, 2), 16)); const A = p(x), B = p(y); return Math.hypot(A[0] - B[0], A[1] - B[1], A[2] - B[2]); };
    if (dist(ch, ca) < 90) ca = ch.toLowerCase() === '#3b82f6' ? '#f97316' : '#3b82f6';
    if (dist(ch, ca) < 90) { ch = '#3b82f6'; ca = '#f97316'; }
    return { home: ch, away: ca };
  }

  function pitchLines(w, h, vertical) {
    // pitch drawn in 105x68 (horizontal) or 68x105 (vertical)
    if (!vertical) return `
      <rect x="0" y="0" width="105" height="68" class="pl-turf"/>
      ${Array.from({ length: 7 }, (_, i) => `<rect x="${i * 15}" y="0" width="7.5" height="68" class="pl-stripe"/>`).join('')}
      <g class="pl-line"><rect x=".5" y=".5" width="104" height="67"/><line x1="52.5" y1=".5" x2="52.5" y2="67.5"/><circle cx="52.5" cy="34" r="9.15"/>
      <rect x=".5" y="13.84" width="16.5" height="40.32"/><rect x="88" y="13.84" width="16.5" height="40.32"/>
      <rect x=".5" y="24.84" width="5.5" height="18.32"/><rect x="99" y="24.84" width="5.5" height="18.32"/>
      <path d="M17 26.7 A9.15 9.15 0 0 1 17 41.3"/><path d="M88 26.7 A9.15 9.15 0 0 0 88 41.3"/>
      <circle cx="11" cy="34" r=".5" class="pl-dot"/><circle cx="94" cy="34" r=".5" class="pl-dot"/><circle cx="52.5" cy="34" r=".6" class="pl-dot"/></g>
      <rect x="-1.6" y="30.34" width="1.6" height="7.32" class="pl-goal"/><rect x="105" y="30.34" width="1.6" height="7.32" class="pl-goal"/>`;
    return `
      <rect x="0" y="0" width="68" height="105" class="pl-turf"/>
      ${Array.from({ length: 7 }, (_, i) => `<rect x="0" y="${i * 15}" width="68" height="7.5" class="pl-stripe"/>`).join('')}
      <g class="pl-line"><rect x=".5" y=".5" width="67" height="104"/><line x1=".5" y1="52.5" x2="67.5" y2="52.5"/><circle cx="34" cy="52.5" r="9.15"/>
      <rect x="13.84" y=".5" width="40.32" height="16.5"/><rect x="13.84" y="88" width="40.32" height="16.5"/>
      <rect x="24.84" y=".5" width="18.32" height="5.5"/><rect x="24.84" y="99" width="18.32" height="5.5"/>
      <path d="M26.7 17 A9.15 9.15 0 0 0 41.3 17"/><path d="M26.7 88 A9.15 9.15 0 0 1 41.3 88"/></g>`;
  }

  /* ---------- formation pitch ---------- */
  const DEPTH = [
    [/^G$/, 0], [/^(CD|CB|SW|D)(-[LR])?$/, 1], [/^(LB|RB|LWB|RWB|WB|D-[LR])$/, 1.1], [/^(DM|CDM)(-[LR])?$/, 2],
    [/^(CM|M)(-[LR])?$/, 3], [/^(LM|RM)$/, 3.1], [/^(AM)(-[LR])?$/, 4], [/^(LW|RW|LF|RF)$/, 4.2], [/^(F|CF|ST|SS)(-[LR])?$/, 5],
  ];
  const depthOf = p => { for (const [re, d] of DEPTH) if (re.test(p)) return d; return 3; };
  const latOf = p => /^(LB|LWB|LM|LW|LF)$/.test(p) ? -2 : /-L$/.test(p) ? -1 : /^(RB|RWB|RM|RW|RF)$/.test(p) ? 2 : /-R$/.test(p) ? 1 : 0;
  function lines(roster, formation) {
    const starters = roster.filter(p => p.starter);
    const gk = starters.filter(p => p.position && p.position.abbreviation === 'G');
    const out = starters.filter(p => !(p.position && p.position.abbreviation === 'G'))
      .map(p => ({ p, d: depthOf((p.position && p.position.abbreviation) || ''), l: latOf((p.position && p.position.abbreviation) || ''), fp: +p.formationPlace || 0 }))
      .sort((a, b) => a.d - b.d || a.fp - b.fp);
    let counts = (formation || '').split('-').map(Number).filter(Boolean);
    if (counts.reduce((a, b) => a + b, 0) !== out.length) counts = out.length === 10 ? [4, 3, 3] : [out.length];
    const res = [gk.map(p => ({ p, l: 0 }))]; let i = 0;
    counts.forEach(c => {
      const row = out.slice(i, i + c); i += c;
      row.sort((a, b) => a.l - b.l || a.fp - b.fp);
      res.push(row);
    });
    return res;
  }
  function lineupPitch(sum, colors, onlySide, photoOf) {
    const rs = sum.rosters || [];
    let body = '';
    rs.forEach(r => {
      const s = r.homeAway; if (onlySide && s !== onlySide) return;
      const L = lines(r.roster || [], r.formation);
      const c = colors[s];
      L.forEach((row, li) => {
        const nL = L.length;
        const yHome = 98.3 - li * (39.8 / Math.max(1, nL - 1));
        const y = s === 'home' ? yHome : 105 - yHome;
        row.forEach((it, k) => {
          const n = row.length;
          let x = 68 * (k + 1) / (n + 1);
          if (s === 'away') x = 68 - x;
          const p = it.p, ath = p.athlete || {};
          const sub = p.subbedOut, g = (p.stats || []).find(z => z.name === 'totalGoals'), yc = (p.stats || []).find(z => z.name === 'yellowCards'), rc = (p.stats || []).find(z => z.name === 'redCards');
          const nm = (ath.lastName || ath.shortName || ath.displayName || '').replace(/^.\.\s*/, '');
          body += `<g class="pl-player" style="--d:${(li * 0.12 + k * 0.05).toFixed(2)}s" transform="translate(${x.toFixed(2)} ${y.toFixed(2)}) scale(.86)" data-pid="${esc(ath.id)}" tabindex="0" role="button" aria-label="${esc(ath.displayName)}">
            <g class="pl-pop"><circle r="3.6" fill="${c}" class="pl-shirt"/>${(() => { const u = photoOf && photoOf(ath); return u ? `<image href="${esc(u)}" x="-3.3" y="-3.3" width="6.6" height="6.6" clip-path="url(#plClip)" preserveAspectRatio="xMidYMin slice" class="pl-img"/><g transform="translate(2.7 2.5)"><circle r="1.45" fill="${c}" stroke="#fff" stroke-width=".25"/><text class="pl-num sm" y=".55">${esc(p.jersey)}</text></g>` : `<text class="pl-num" y="1.15">${esc(p.jersey)}</text>`; })()}
            <text class="pl-name" y="6.6">${esc(nm.length > 10 ? nm.slice(0, 9) + '…' : nm)}</text>
            ${g && g.value ? `<g transform="translate(3 -3)"><circle r="1.5" class="pl-ball"/><text class="pl-badge" y=".55">${g.value > 1 ? g.value : ''}</text></g>` : ''}
            ${rc && rc.value ? `<rect x="-4.4" y="-4.6" width="1.6" height="2.2" rx=".3" fill="#e2483b"/>` : yc && yc.value ? `<rect x="-4.4" y="-4.6" width="1.6" height="2.2" rx=".3" fill="#f5c542"/>` : ''}
            ${sub ? `<g transform="translate(-3.2 3)"><circle r="1.25" fill="#0b0f16" stroke="#e2483b" stroke-width=".3"/><path d="M-.6 -.3 L0 .4 L.6 -.3" stroke="#e2483b" stroke-width=".35" fill="none"/></g>` : ''}</g></g>`;
        });
      });
    });
    const vb = onlySide ? (onlySide === 'home' ? '0 50 68 55' : '0 0 68 55') : '0 0 68 105';
    return `<svg class="pitch pitch-v" viewBox="${vb}" role="img" aria-label="التشكيلة على أرض الملعب"><defs><clipPath id="plClip"><circle r="3.3"/></clipPath></defs>${pitchLines(68, 105, true)}${body}</svg>`;
  }

  /* ---------- shot map ---------- */
  function shotMap(shots, colors, { animate = true } = {}) {
    const dots = shots.map((s, i) => {
      if (s.x == null) return '';
      const x = s.side === 'home' ? (100 - s.x) * 1.05 : s.x * 1.05;
      const y = s.side === 'home' ? (100 - s.y) * 0.68 : s.y * 0.68;
      const r = 0.9 + Math.sqrt(s.xg) * 3.2;
      const c = colors[s.side];
      return `<g transform="translate(${x.toFixed(2)} ${y.toFixed(2)})"><g class="shot ${s.goal ? 'is-goal' : ''}" style="--d:${animate ? (i * 0.07).toFixed(2) : 0}s">
        <circle r="${r.toFixed(2)}" fill="${s.goal ? c : 'none'}" stroke="${c}" stroke-width="${s.onTarget ? 0.55 : 0.3}" fill-opacity="${s.goal ? 0.95 : 0}" ${s.onTarget ? '' : 'stroke-dasharray=".8 .6"'}>
        <title>${esc(Math.floor(s.min))}' ${esc(s.who || '')} — xG ${s.xg.toFixed(2)}${s.goal ? ' ⚽' : ''}</title></circle>
        ${s.goal ? `<circle r="${(r + 1.6).toFixed(2)}" fill="none" stroke="${c}" stroke-width=".25" class="shot-ring"/>` : ''}</g></g>`;
    }).join('');
    return `<svg class="pitch pitch-h" viewBox="-2 -1 109 70" role="img" aria-label="خريطة التسديدات">${pitchLines(105, 68, false)}${dots}</svg>`;
  }

  /* ---------- animated goal replay ---------- */
  function goalReplay(s, colors, key) {
    if (!s || s.x == null) return `<div class="replay-empty">لا تتوفر إحداثيات لهذا الهدف</div>`;
    const home = s.side === 'home';
    const x1 = home ? (100 - s.x) * 1.05 : s.x * 1.05, y1 = home ? (100 - s.y) * 0.68 : s.y * 0.68;
    const gy = s.gy != null ? s.gy : 50;
    const x2 = home ? -0.9 : 105.9, y2 = home ? (100 - gy) * 0.68 : gy * 0.68;
    const yGoal = Math.max(30.6, Math.min(37.4, y2));
    const c = colors[s.side];
    const mx = (x1 + x2) / 2, my = Math.min(y1, yGoal) - 6;
    const id = 'rp' + key;
    return `<svg class="pitch pitch-h replay" viewBox="-2 -1 109 70" role="img" aria-label="إعادة رسومية للهدف">${pitchLines(105, 68, false)}
      <path id="${id}" d="M${x1.toFixed(2)} ${y1.toFixed(2)} Q${mx.toFixed(2)} ${my.toFixed(2)} ${x2.toFixed(2)} ${yGoal.toFixed(2)}" class="rp-trail" stroke="${c}"/>
      <g transform="translate(${x1.toFixed(2)} ${y1.toFixed(2)})"><circle r="2.6" fill="${c}" class="rp-shooter"/><text class="rp-who" y="-4">${esc((s.who || '').split(' ').slice(-1)[0])}</text></g>
      <circle r="1.1" class="rp-ball"><animateMotion dur="1.1s" begin="0.6s" fill="freeze" calcMode="spline" keySplines=".3 0 .2 1" keyTimes="0;1"><mpath href="#${id}"/></animateMotion></circle>
      <g class="rp-net" transform="translate(${home ? -1.2 : 106.2} 34)"><rect x="-1.4" y="-3.66" width="2.8" height="7.32" fill="${c}"/></g>
      <text x="52.5" y="36" class="rp-goal-txt">گووول!</text>
    </svg>`;
  }

  /* ---------- momentum wave ---------- */
  function momentumChart(mom, colors, goals, { W = 640, Hh = 170 } = {}) {
    const n = mom.length; if (!n) return '';
    const max = Math.max(1, ...mom.map(m => Math.max(m.home, m.away)));
    const mid = Hh / 2, sx = i => W - (i / (n - 1)) * W;
    const ptsH = mom.map((m, i) => [sx(i), mid - (m.home / max) * (mid - 10)]);
    const ptsA = mom.map((m, i) => [sx(i), mid + (m.away / max) * (mid - 10)]);
    const smooth = pts => pts.map((p, i) => i ? `S${(p[0] - (pts[i][0] - pts[i - 1][0]) / 2).toFixed(1)} ${p[1].toFixed(1)} ${p[0].toFixed(1)} ${p[1].toFixed(1)}` : `M${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
    const areaH = `${smooth(ptsH)} L0 ${mid} L${W} ${mid}Z`, areaA = `${smooth(ptsA)} L0 ${mid} L${W} ${mid}Z`;
    const tx = m => W - (m / 5) / (n - 1) * W;
    const gm = (goals || []).map(g => {
      const x = Math.min(W, tx(g.min));
      const up = g.side === 'home';
      return `<g transform="translate(${x.toFixed(1)} ${up ? 14 : Hh - 14})"><g class="mm-goal"><circle r="7" fill="${colors[g.side]}"/><circle r="2.6" fill="#0b0f16"/><title>${Math.floor(g.min)}' ${esc(g.who || '')}</title></g></g>`;
    }).join('');
    const ticks = [0, 15, 30, 45, 60, 75, 90].map(t => `<g transform="translate(${tx(t).toFixed(1)} 0)"><line y1="0" y2="${Hh}" class="mm-tick"/><text y="${mid + 4}" x="-3" text-anchor="end" class="mm-tlabel">${t}'</text></g>`).join('');
    return `<svg class="momentum" viewBox="0 0 ${W} ${Hh}" preserveAspectRatio="none" role="img" aria-label="موجة الزخم الهجومي">
      <defs><clipPath id="mmclip"><rect x="${W}" y="0" width="${W}" height="${Hh}"><animate attributeName="x" from="${W}" to="0" dur="2.4s" fill="freeze" calcMode="spline" keySplines=".4 0 .2 1" keyTimes="0;1"/></rect></clipPath>
      <linearGradient id="mmH" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${colors.home}" stop-opacity=".95"/><stop offset="1" stop-color="${colors.home}" stop-opacity=".15"/></linearGradient>
      <linearGradient id="mmA" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="${colors.away}" stop-opacity=".95"/><stop offset="1" stop-color="${colors.away}" stop-opacity=".15"/></linearGradient></defs>
      ${ticks}<g clip-path="url(#mmclip)"><path d="${areaH}" fill="url(#mmH)"/><path d="${areaA}" fill="url(#mmA)"/><line x1="0" x2="${W}" y1="${mid}" y2="${mid}" class="mm-mid"/></g>${gm}</svg>`;
  }

  /* ---------- radar ---------- */
  function radar(dna, colors, size = 300) {
    const c = size / 2, R = size / 2 - 46, n = dna.axes.length;
    const pt = (i, v) => { const a = -Math.PI / 2 + i * 2 * Math.PI / n; return [c + Math.cos(a) * R * v, c + Math.sin(a) * R * v]; };
    const rings = [0.25, 0.5, 0.75, 1].map(v => `<polygon points="${dna.axes.map((_, i) => pt(i, v).join(',')).join(' ')}" class="rd-ring"/>`).join('');
    const spokes = dna.axes.map((a, i) => { const [x, y] = pt(i, 1); const [lx, ly] = pt(i, 1.2); return `<line x1="${c}" y1="${c}" x2="${x}" y2="${y}" class="rd-spoke"/><text x="${lx}" y="${ly}" class="rd-label">${a.ar}</text>`; }).join('');
    const poly = (side, d) => `<polygon class="rd-poly" style="--d:${d}s;transform-origin:${c}px ${c}px" points="${dna.axes.map((a, i) => pt(i, Math.max(0.04, dna[side][a.k])).join(',')).join(' ')}" fill="${colors[side]}" stroke="${colors[side]}"/>`;
    return `<svg class="radar" viewBox="0 0 ${size} ${size}" role="img" aria-label="بصمة أسلوب اللعب">${rings}${spokes}${poly('away', 0.5)}${poly('home', 0.2)}</svg>`;
  }

  /* ---------- probability bar ---------- */
  function probBar(p, colors, labels) {
    const pc = v => Math.round(v * 100);
    return `<div class="pbar" role="img" aria-label="احتمالات: ${labels[0]} ${pc(p.home)}٪، تعادل ${pc(p.draw)}٪، ${labels[2]} ${pc(p.away)}٪">
      <span style="--w:${pc(p.home)}%;--c:${colors.home}"><b>${pc(p.home)}%</b></span>
      <span class="draw" style="--w:${pc(p.draw)}%"><b>${pc(p.draw)}%</b></span>
      <span style="--w:${pc(p.away)}%;--c:${colors.away}"><b>${pc(p.away)}%</b></span></div>`;
  }

  function gauge(v, label, color) {
    const r = 42, C = 2 * Math.PI * r, f = Math.max(0, Math.min(1, v / 100));
    return `<svg class="gauge" viewBox="0 0 100 100" role="img" aria-label="${label} ${Math.round(v)}"><circle cx="50" cy="50" r="${r}" class="g-bg"/>
      <circle cx="50" cy="50" r="${r}" class="g-fg" stroke="${color || 'var(--accent)'}" style="--c:${C};--o:${(C * (1 - f)).toFixed(1)}" transform="rotate(-90 50 50)"/>
      <text x="50" y="52" class="g-num">${Math.round(v)}</text><text x="50" y="68" class="g-lbl">${label}</text></svg>`;
  }

  YH.viz = { lines, pitchLines, lineupPitch, shotMap, goalReplay, momentumChart, radar, probBar, gauge, teamColors, esc };
})();
