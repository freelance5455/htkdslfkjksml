/* =============================================================
   LAMPION POS · js/lp.js
   Pengganti assets/js/app.js  (helper UI umum)
   -------------------------------------------------------------
   KUNCI KONVERSI:
   Seluruh kode lama memanggil `LP.api('api/orders.php', {...})`.
   Di sini LP.api() TIDAK melakukan fetch ke jaringan, melainkan
   diarahkan ke router lokal di js/lp-core.js (LPCORE.api).
   Jadi tidak ada lagi PHP/HTTP, tapi kontrak pemanggilan sama.
   ============================================================= */
(function (global) {
  'use strict';

  var LP = {
    /* CSRF tidak lagi dari meta tag server, tapi token lokal */
    csrf: function () { return global.LPHP.csrfToken(); },

    esc: function (s) { return global.LPHP.esc(s); },

    money: function (n) { return global.LPHP.money(n); },

    /**
     * Pengganti fetch JSON.
     * Melempar Error bila gagal — persis seperti versi PHP lama
     * sehingga try/catch di pos.js dan halaman lain tetap jalan.
     */
    api: function (url, opts) {
      return global.LPCORE.api(url, opts);
    },

    /** Versi mentah tanpa throw: -> { status, data } */
    apiRaw: function (url, opts) {
      return global.LPCORE.apiRaw(url, opts);
    },

    /* ---------- TOAST ---------- */
    toast: function (msg, type, ms) {
      type = type || 'ok';
      ms = ms || 3600;
      var holder = document.getElementById('toast-holder');
      if (!holder) { console.log('[toast]', type, msg); return; }
      var t = document.createElement('div');
      t.className = 'toast ' + type;
      t.textContent = msg;
      holder.appendChild(t);
      setTimeout(function () {
        t.style.opacity = '0';
        setTimeout(function () {
          if (t.parentNode === holder) { holder.removeChild(t); }
        }, 220);
      }, ms);
    },

    /* ---------- MODAL ---------- */
    openModal: function (el) {
      el = (typeof el === 'string') ? document.getElementById(el) : el;
      if (!el) { return; }
      el.classList.add('open');
      document.body.style.overflow = 'hidden';
      var first = el.querySelector('.modal input, .modal select, .modal button');
      if (first) { setTimeout(function () { first.focus({ preventScroll: true }); }, 40); }
    },

    closeModal: function (el) {
      el = (typeof el === 'string') ? document.getElementById(el) : el;
      if (!el) { return; }
      el.classList.remove('open');
      document.body.style.overflow = '';
    },

    bindModals: function () {
      if (LP._modalsBound) { return; }   /* cegah pemasangan ganda */
      LP._modalsBound = true;

      document.addEventListener('click', function (e) {
        var ov = e.target.closest && e.target.closest('.modal-overlay');
        if (ov && e.target === ov) { LP.closeModal(ov); }
        var closer = e.target.closest && e.target.closest('[data-close-modal]');
        if (closer) { LP.closeModal(closer.getAttribute('data-close-modal')); }
        var opener = e.target.closest && e.target.closest('[data-open-modal]');
        if (opener) { LP.openModal(opener.getAttribute('data-open-modal')); }
      });

      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
          document.querySelectorAll('.modal-overlay.open').forEach(function (m) {
            LP.closeModal(m);
          });
        }
      });
    },

    /* ---------- CONFIRM ---------- */
    confirm: function (msg) {
      return Promise.resolve(!!(global.confirm && global.confirm(msg)));
    },

    /* ---------- form data helper ---------- */
    formData: function (formID) {
      var f = document.getElementById(formID);
      if (!f) { return {}; }
      return Object.fromEntries(new FormData(f).entries());
    },

    /** Logout + kembali ke halaman login (dipakai tombol topbar) */
    logout: function () {
      return global.LPAUTH.doLogout().then(function () {
        global.location.replace('login.html');
      });
    }
  };

  global.LP = LP;

  /* ---------- init umum ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    LP.bindModals();

    /* dropdown user topbar */
    var tb = document.getElementById('tb-user');
    if (tb) {
      tb.addEventListener('click', function (e) {
        if (e.target.closest('.user-drop')) { return; }
        tb.classList.toggle('open');
      });
      document.addEventListener('click', function (e) {
        if (tb.classList.contains('open') && !tb.contains(e.target)) {
          tb.classList.remove('open');
        }
      });
    }
  });
})(window);
