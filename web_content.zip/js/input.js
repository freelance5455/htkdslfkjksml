/**
 * Snake Escape — Advanced Multi-Input Controller
 * Handles touch swipes, cell tapping, keyboard (WASD/Arrows/Hotkeys),
 * and on-screen virtual directional D-pad controls (48px+ touch targets).
 */
(function() {
  'use strict';

  class InputHandler {
    constructor() {
      this.enabled = false;
      this.callbacks = {};
      this.boardElement = null;
      this.renderer = null;

      // Touch gesture coordinates
      this.touchStartX = 0;
      this.touchStartY = 0;
      this.touchStartTime = 0;
      this.swipeThreshold = 24; // Min distance for swipe in pixels
      this.maxSwipeTime = 700;   // Max time for swipe in ms

      this._handleKeyDown = this._handleKeyDown.bind(this);
      this._handleTouchStart = this._handleTouchStart.bind(this);
      this._handleTouchEnd = this._handleTouchEnd.bind(this);
      this._handleBoardClick = this._handleBoardClick.bind(this);
    }

    init(boardElement, renderer, callbacks = {}) {
      this.boardElement = boardElement;
      this.renderer = renderer;
      this.callbacks = callbacks;

      // Keyboard Controls
      window.addEventListener('keydown', this._handleKeyDown);

      // Touch Gestures on Board Container
      if (this.boardElement) {
        this.boardElement.style.touchAction = 'none'; // Prevent browser scrolling
        this.boardElement.addEventListener('touchstart', this._handleTouchStart, { passive: false });
        this.boardElement.addEventListener('touchend', this._handleTouchEnd, { passive: false });
        this.boardElement.addEventListener('click', this._handleBoardClick);
      }

      // Wire Virtual On-Screen D-Pad buttons (touch-friendly targets)
      const setupButton = (id, action) => {
        const btn = document.getElementById(id);
        if (btn) {
          btn.addEventListener('click', (e) => {
            e.preventDefault();
            if (this.enabled && action) action();
          });
        }
      };

      setupButton('btn-dpad-up', () => this._emitMove('UP'));
      setupButton('btn-dpad-down', () => this._emitMove('DOWN'));
      setupButton('btn-dpad-left', () => this._emitMove('LEFT'));
      setupButton('btn-dpad-right', () => this._emitMove('RIGHT'));

      // Bottom Control Buttons
      setupButton('btn-game-hint', () => { if (this.callbacks.hint) this.callbacks.hint(); });
      setupButton('btn-game-reset', () => { if (this.callbacks.reset) this.callbacks.reset(); });
      setupButton('btn-game-undo', () => { if (this.callbacks.undo) this.callbacks.undo(); });
      setupButton('btn-game-pause', () => { if (this.callbacks.pause) this.callbacks.pause(); });
    }

    setEnabled(enabled) {
      this.enabled = !!enabled;
    }

    _emitMove(direction) {
      if (!this.enabled) return;
      if (this.callbacks.move) {
        this.callbacks.move(direction);
      }
    }

    _handleKeyDown(e) {
      if (!this.enabled) return;

      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          e.preventDefault();
          this._emitMove('UP');
          break;

        case 'ArrowDown':
        case 's':
        case 'S':
          e.preventDefault();
          this._emitMove('DOWN');
          break;

        case 'ArrowLeft':
        case 'a':
        case 'A':
          e.preventDefault();
          this._emitMove('LEFT');
          break;

        case 'ArrowRight':
        case 'd':
        case 'D':
          e.preventDefault();
          this._emitMove('RIGHT');
          break;

        case 'u':
        case 'U':
        case 'z':
        case 'Z':
          e.preventDefault();
          if (this.callbacks.undo) this.callbacks.undo();
          break;

        case 'r':
        case 'R':
          e.preventDefault();
          if (this.callbacks.reset) this.callbacks.reset();
          break;

        case 'h':
        case 'H':
          e.preventDefault();
          if (this.callbacks.hint) this.callbacks.hint();
          break;

        case 'Escape':
        case 'p':
        case 'P':
          e.preventDefault();
          if (this.callbacks.pause) this.callbacks.pause();
          break;
      }
    }

    _handleTouchStart(e) {
      if (!this.enabled || e.touches.length !== 1) return;
      e.preventDefault();
      const touch = e.touches[0];
      this.touchStartX = touch.clientX;
      this.touchStartY = touch.clientY;
      this.touchStartTime = performance.now();
    }

    _handleTouchEnd(e) {
      if (!this.enabled || !e.changedTouches.length) return;
      e.preventDefault();

      const touch = e.changedTouches[0];
      const deltaX = touch.clientX - this.touchStartX;
      const deltaY = touch.clientY - this.touchStartY;
      const elapsedTime = performance.now() - this.touchStartTime;

      // 1. Detect Swipe Gesture
      if (elapsedTime <= this.maxSwipeTime) {
        const absX = Math.abs(deltaX);
        const absY = Math.abs(deltaY);

        if (Math.max(absX, absY) >= this.swipeThreshold) {
          if (absX > absY) {
            this._emitMove(deltaX > 0 ? 'RIGHT' : 'LEFT');
          } else {
            this._emitMove(deltaY > 0 ? 'DOWN' : 'UP');
          }
          return;
        }
      }

      // 2. Otherwise treat as a precise Cell Tap
      if (this.renderer && this.callbacks.tapCell) {
        const gridCoord = this.renderer.clientToGrid(touch.clientX, touch.clientY);
        if (gridCoord) {
          this.callbacks.tapCell(gridCoord);
        }
      }
    }

    _handleBoardClick(e) {
      if (!this.enabled || !this.renderer || !this.callbacks.tapCell) return;
      const gridCoord = this.renderer.clientToGrid(e.clientX, e.clientY);
      if (gridCoord) {
        this.callbacks.tapCell(gridCoord);
      }
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.InputHandler = InputHandler;
})();
