/* ============================================================
   input.js — unified touch + keyboard controls
   steering wheel / steering buttons / pedals / nitro / handbrake
   gears / camera / horn / pause / restart
   ============================================================ */
'use strict';

class InputManager {
  constructor() {
    this.steer = 0;
    this.throttle = 0;
    this.brake = 0;
    this.nitro = false;
    this.handbrake = false;
    this.steeringMode = 'wheel';

    this._wheelAngle = 0;
    this._maxWheel = Math.PI * 1.25;
    this._wheelDrag = null;
    this._btnSteer = 0;
    this._kbSteer = 0;
    this._touchGas = false;
    this._touchBrake = false;
    this._edges = { up: 0, down: 0, pause: 0, camera: 0, horn: 0, restart: 0 };
    this._keys = {};

    this._buildWheel();
    this._buildButtons();
    this._buildKeyboard();
    this._preventGestures();
  }

  setSteeringMode(mode) {
    this.steeringMode = mode === 'buttons' ? 'buttons' : 'wheel';
    document.body.dataset.steering = this.steeringMode;
  }

  /* ---------------- steering wheel ---------------- */
  _buildWheel() {
    this.wheelEl = document.getElementById('steering-wheel');
    this.wheelWrap = document.getElementById('wheel-wrap');
    if (!this.wheelEl || !this.wheelWrap) return;

    const setFromPointer = (e) => {
      const r = this.wheelEl.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const a = Math.atan2(e.clientY - cy, e.clientX - cx);
      if (!this._wheelDrag) {
        this._wheelDrag = { grab: a, startAngle: this._wheelAngle };
        return;
      }
      let delta = a - this._wheelDrag.grab;
      while (delta > Math.PI) delta -= Math.PI * 2;
      while (delta < -Math.PI) delta += Math.PI * 2;
      const target = this._wheelDrag.startAngle + delta;
      this._wheelAngle = AD.clamp(target, -this._maxWheel, this._maxWheel);
    };

    this.wheelWrap.addEventListener('pointerdown', (e) => {
      if (this.steeringMode !== 'wheel') return;
      e.preventDefault();
      try { this.wheelWrap.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      this._wheelDrag = null;
      setFromPointer(e);
    });
    this.wheelWrap.addEventListener('pointermove', (e) => {
      if (this.steeringMode !== 'wheel' || !this._wheelDrag) return;
      e.preventDefault();
      setFromPointer(e);
    });
    const release = () => { this._wheelDrag = null; };
    this.wheelWrap.addEventListener('pointerup', release);
    this.wheelWrap.addEventListener('pointercancel', release);
    this.wheelWrap.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  /* ---------------- buttons ---------------- */
  _buildButtons() {
    this._bindPedal('pedal-gas', 'gas');
    this._bindPedal('pedal-brake', 'brake');

    this._bindHold('btn-nitro', (on) => { this._touchNitro = on; });
    this._bindHold('btn-handbrake', (on) => { this._touchHandbrake = on; });

    this._bindHold('steer-left', (on) => {
      if (on) this._btnSteer = -1;
      else if (this._btnSteer === -1) this._btnSteer = 0;
    });
    this._bindHold('steer-right', (on) => {
      if (on) this._btnSteer = 1;
      else if (this._btnSteer === 1) this._btnSteer = 0;
    });

    const edge = (id, name) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        this._edges[name] = 1;
        el.classList.add('pressed');
      });
      const up = () => el.classList.remove('pressed');
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
      el.addEventListener('pointerleave', up);
      el.addEventListener('contextmenu', (e) => e.preventDefault());
    };
    edge('btn-gear-up', 'up');
    edge('btn-gear-down', 'down');
    edge('btn-camera', 'camera');
    edge('btn-horn', 'horn');
    edge('btn-pause', 'pause');
    edge('btn-restart-hud', 'restart');
  }

  _bindPedal(id, kind) {
    const el = document.getElementById(id);
    if (!el) return;
    const down = (e) => {
      e.preventDefault();
      try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      el.classList.add('active');
      if (kind === 'gas') this._touchGas = true; else this._touchBrake = true;
    };
    const up = () => {
      el.classList.remove('active');
      if (kind === 'gas') this._touchGas = false; else this._touchBrake = false;
    };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('lostpointercapture', up);
    el.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  _bindHold(id, cb) {
    const el = document.getElementById(id);
    if (!el) return;
    const down = (e) => {
      e.preventDefault();
      try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      el.classList.add('active');
      cb(true);
    };
    const up = () => { el.classList.remove('active'); cb(false); };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('lostpointercapture', up);
    el.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  /* ---------------- keyboard ---------------- */
  _buildKeyboard() {
    const prevent = new Set(['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space']);
    window.addEventListener('keydown', (e) => {
      if (prevent.has(e.code)) e.preventDefault();
      if (e.repeat) return;
      this._keys[e.code] = true;
      switch (e.code) {
        case 'ShiftLeft': case 'ShiftRight': case 'KeyE': this._edges.up = 1; break;
        case 'ControlLeft': case 'ControlRight': case 'KeyQ': this._edges.down = 1; break;
        case 'Escape': case 'KeyP': this._edges.pause = 1; break;
        case 'KeyC': this._edges.camera = 1; break;
        case 'KeyH': this._edges.horn = 1; break;
        case 'KeyR': this._edges.restart = 1; break;
      }
    });
    window.addEventListener('keyup', (e) => { this._keys[e.code] = false; });
    window.addEventListener('blur', () => { this._keys = {}; });
  }

  _preventGestures() {
    document.addEventListener('gesturestart', (e) => e.preventDefault());
    document.addEventListener('dblclick', (e) => e.preventDefault());
    document.addEventListener('touchmove', (e) => {
      if (e.target.closest && e.target.closest('#controls')) e.preventDefault();
    }, { passive: false });
  }

  /* ---------------- per-frame ---------------- */
  update(dt) {
    // spring wheel back to centre
    if (!this._wheelDrag && this._wheelAngle !== 0) {
      const spring = 8.5 * dt;
      if (Math.abs(this._wheelAngle) < spring) this._wheelAngle = 0;
      else this._wheelAngle -= Math.sign(this._wheelAngle) * spring;
    }
    if (this.wheelEl) this.wheelEl.style.transform = `rotate(${this._wheelAngle}rad)`;

    // keyboard steering eases in/out
    let kbTarget = 0;
    if (this._keys['ArrowLeft'] || this._keys['KeyA']) kbTarget -= 1;
    if (this._keys['ArrowRight'] || this._keys['KeyD']) kbTarget += 1;
    this._kbSteer = AD.damp(this._kbSteer, kbTarget, 9, dt);

    let wheelSteer = this._wheelAngle / this._maxWheel;
    let target = 0;
    if (this.steeringMode === 'buttons') target = this._btnSteer;
    else if (Math.abs(wheelSteer) > 0.02) target = wheelSteer;
    if (kbTarget !== 0) target = kbTarget;

    this.steer = AD.damp(this.steer, AD.clamp(target + (kbTarget !== 0 ? 0 : this._kbSteer * 0.35), -1, 1), 14, dt);
    if (Math.abs(this.steer) < 0.004) this.steer = 0;

    let gas = this._touchGas ? 1 : 0;
    let brk = this._touchBrake ? 1 : 0;
    if (this._keys['ArrowUp'] || this._keys['KeyW']) gas = 1;
    if (this._keys['ArrowDown'] || this._keys['KeyS']) brk = 1;
    this.throttle = AD.damp(this.throttle, gas, gas ? 12 : 18, dt);
    this.brake = AD.damp(this.brake, brk, brk ? 14 : 20, dt);

    this.nitro = !!(this._touchNitro || this._keys['KeyN'] || this._keys['ShiftLeft'] && false);
    this.handbrake = !!(this._touchHandbrake || this._keys['Space']);
  }

  consumeGearUp() { const v = this._edges.up; this._edges.up = 0; return v; }
  consumeGearDown() { const v = this._edges.down; this._edges.down = 0; return v; }
  consumePause() { const v = this._edges.pause; this._edges.pause = 0; return v; }
  consumeCamera() { const v = this._edges.camera; this._edges.camera = 0; return v; }
  consumeHorn() { const v = this._edges.horn; this._edges.horn = 0; return v; }
  consumeRestart() { const v = this._edges.restart; this._edges.restart = 0; return v; }

  reset() {
    this._wheelAngle = 0;
    this._wheelDrag = null;
    this._btnSteer = 0;
    this._kbSteer = 0;
    this._touchGas = false;
    this._touchBrake = false;
    this._touchNitro = false;
    this._touchHandbrake = false;
    this._keys = {};
    this._edges = { up: 0, down: 0, pause: 0, camera: 0, horn: 0, restart: 0 };
    this.steer = 0; this.throttle = 0; this.brake = 0;
    this.nitro = false; this.handbrake = false;
    document.querySelectorAll('.pedal, .ctl-btn').forEach(p => p.classList.remove('active', 'pressed'));
  }
}
