/* سينما زمان: عدّ تنازلي، انتقالات دائرية، خدوش فيلم قديم وموسيقى */
window.Cinema = (function () {
  var el = document.getElementById('cinema');
  var frame = document.getElementById('frame');
  var film = document.getElementById('film');
  var countdown = document.getElementById('countdown');
  var card = document.getElementById('card');
  var canvas = document.getElementById('grain');
  var pen = canvas.getContext('2d');
  var pauseBtn = document.getElementById('pause');
  var nextBtn = document.getElementById('next');

  var SHOW_MS = 4200, IRIS_MS = 760;
  var list = [], index = 0, paused = false, running = false;
  var job = null;               // المؤقت الحالي (قابل للإيقاف المؤقت)
  var grainTimer = null, wake = null;

  /* مؤقت يمكن إيقافه واستئنافه */
  function wait(ms, fn) {
    cancel();
    job = { left: ms, fn: fn, id: null, at: 0 };
    if (!paused) resume();
  }
  function resume() {
    if (!job) return;
    job.at = Date.now();
    job.id = setTimeout(function () { var f = job.fn; job = null; f(); }, job.left);
  }
  function hold() {
    if (!job || job.id === null) return;
    clearTimeout(job.id); job.id = null;
    job.left = Math.max(0, job.left - (Date.now() - job.at));
  }
  function cancel() { if (job) clearTimeout(job.id); job = null; }

  function count(num, ticks) {
    countdown.firstChild.textContent = num;
    countdown.style.setProperty('--a', (ticks / 10 * 360) + 'deg');
    wait(90, function () {
      if (ticks < 10) return count(num, ticks + 1);
      if (num > 1) { Sound.beep(72); return count(num - 1, 0); }
      countdown.hidden = true;
      nextBtn.disabled = false;
      Sound.restart(); if (!paused) Sound.music();
      show();
    });
  }

  function show() {
    if (index >= list.length) return finish();
    film.classList.remove('move');
    film.onload = function () {
      film.onload = null;
      if (!running) return;
      void film.offsetWidth;                  // إعادة تشغيل الحركة
      film.classList.add('move');
      frame.classList.add('open');
      wait(SHOW_MS, leave);
    };
    film.src = 'images/full/' + list[index].f;
  }

  function leave() {
    frame.classList.remove('open');
    wait(IRIS_MS, function () { index++; show(); });
  }

  function finish() {
    card.hidden = false;
    nextBtn.disabled = true;
    pauseBtn.textContent = 'إعادة العرض';
    Sound.stopMusic(); Sound.win();
    running = false;
  }

  function grain() {
    var W = canvas.width, H = canvas.height;
    pen.clearRect(0, 0, W, H);
    for (var i = 0; i < 380; i++) {
      pen.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,.16)' : 'rgba(0,0,0,.3)';
      var s = Math.random() * 1.8 + 0.4;
      pen.fillRect(Math.random() * W, Math.random() * H, s, s);
    }
    if (Math.random() < 0.35) {               // خدش عمودي
      pen.fillStyle = 'rgba(255,245,220,.22)';
      pen.fillRect(Math.random() * W, 0, 1, H);
    }
  }

  function setPaused(p) {
    paused = p;
    el.classList.toggle('paused', p);
    pauseBtn.textContent = p ? 'متابعة' : 'إيقاف مؤقت';
    if (p) { hold(); Sound.stopMusic(); }
    else { resume(); if (countdown.hidden) Sound.music(); }
  }

  function lockScreen() {                      // إبقاء الشاشة مضيئة إن كان مدعوماً
    if (navigator.wakeLock) navigator.wakeLock.request('screen').then(function (w) {
      if (running) wake = w; else w.release();
    }).catch(function () {});
  }

  function begin() {
    list = Gallery.shuffled();
    index = 0; running = true;
    setPaused(false);
    cancel();
    card.hidden = true; countdown.hidden = false; nextBtn.disabled = true;
    frame.classList.remove('open');
    Sound.stopMusic(); Sound.beep(72);
    count(3, 0);
  }

  function stop() {
    running = false; cancel(); clearInterval(grainTimer); Sound.stopMusic();
    film.onload = null; paused = false; el.classList.remove('paused');
    if (wake) { wake.release(); wake = null; }
  }

  pauseBtn.addEventListener('click', function () { if (running) setPaused(!paused); else begin(); });
  nextBtn.addEventListener('click', function () {
    if (!running) return;
    if (paused) setPaused(false);
    leave();
  });
  document.getElementById('mute').addEventListener('click', function () {
    this.textContent = Sound.toggleMute() ? '🔇' : '🔊';
  });
  document.addEventListener('visibilitychange', function () {
    if (!running) return;
    if (document.hidden) setPaused(true); else lockScreen();
  });

  document.getElementById('ticket').addEventListener('click', function () {
    Screens.open('cinema', stop);
    canvas.width = Math.ceil(window.innerWidth / 2);
    canvas.height = Math.ceil(window.innerHeight / 2);
    grainTimer = setInterval(grain, 90);
    lockScreen();
    begin();
  });

  return {};
})();
