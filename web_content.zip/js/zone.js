class SafeZone {
  constructor(scene) {
    this.scene = scene;
    this.center = new THREE.Vector3(0, 0, 0);
    this.radius = 95;
    this.targetRadius = 95;
    this.shrinkSpeed = 0;
    this.phase = 0;
    this.timer = 120; // seconds until next shrink
    this.damagePerSecond = 0;
    this.active = true;

    // Visual ring (simple circle on ground)
    this.createVisual();
  }

  createVisual() {
    const geo = new THREE.RingGeometry(this.radius - 1.5, this.radius, 64);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.45
    });
    this.ring = new THREE.Mesh(geo, mat);
    this.ring.rotation.x = -Math.PI / 2;
    this.ring.position.y = 0.15;
    this.scene.add(this.ring);

    // Danger fog indicator (larger sphere-ish)
    const dangerGeo = new THREE.RingGeometry(this.radius, this.radius + 40, 64);
    const dangerMat = new THREE.MeshBasicMaterial({
      color: 0xff2244,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.12
    });
    this.dangerRing = new THREE.Mesh(dangerGeo, dangerMat);
    this.dangerRing.rotation.x = -Math.PI / 2;
    this.dangerRing.position.y = 0.12;
    this.scene.add(this.dangerRing);
  }

  update(dt) {
    if (!this.active) return;

    this.timer -= dt;

    if (this.timer <= 0) {
      this.nextPhase();
    }

    // Smooth shrink
    if (this.radius > this.targetRadius) {
      this.radius = Math.max(this.targetRadius, this.radius - this.shrinkSpeed * dt);
      this.updateVisual();
    }

    // Damage outside
    this.damagePerSecond = this.phase === 0 ? 0 : 4 + this.phase * 3;
  }

  nextPhase() {
    this.phase++;
    const phases = [
      { radius: 70, time: 90, speed: 2.5 },
      { radius: 45, time: 75, speed: 3.0 },
      { radius: 25, time: 60, speed: 3.5 },
      { radius: 12, time: 45, speed: 2.8 },
      { radius: 5, time: 30, speed: 1.5 }
    ];

    if (this.phase > phases.length) {
      this.targetRadius = 0;
      this.shrinkSpeed = 1;
      this.timer = 999;
      return;
    }

    const p = phases[this.phase - 1];
    this.targetRadius = p.radius;
    this.timer = p.time;
    this.shrinkSpeed = p.speed;

    // Move center a bit randomly
    this.center.x += Utils.randomRange(-15, 15);
    this.center.z += Utils.randomRange(-15, 15);
    this.center.x = Utils.clamp(this.center.x, -40, 40);
    this.center.z = Utils.clamp(this.center.z, -40, 40);

    AudioManager.zoneWarning();
  }

  updateVisual() {
    this.scene.remove(this.ring);
    this.scene.remove(this.dangerRing);

    const geo = new THREE.RingGeometry(Math.max(0.5, this.radius - 1.2), Math.max(1, this.radius), 64);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.5
    });
    this.ring = new THREE.Mesh(geo, mat);
    this.ring.rotation.x = -Math.PI / 2;
    this.ring.position.set(this.center.x, 0.15, this.center.z);
    this.scene.add(this.ring);

    const dangerGeo = new THREE.RingGeometry(this.radius, this.radius + 50, 64);
    const dangerMat = new THREE.MeshBasicMaterial({
      color: 0xff2244,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.15
    });
    this.dangerRing = new THREE.Mesh(dangerGeo, dangerMat);
    this.dangerRing.rotation.x = -Math.PI / 2;
    this.dangerRing.position.set(this.center.x, 0.12, this.center.z);
    this.scene.add(this.dangerRing);
  }

  isInside(pos) {
    const dx = pos.x - this.center.x;
    const dz = pos.z - this.center.z;
    return Math.sqrt(dx * dx + dz * dz) <= this.radius;
  }

  getTimerText() {
    const m = Math.floor(this.timer / 60);
    const s = Math.floor(this.timer % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
}
