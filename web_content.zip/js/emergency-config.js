                                                   
(function (S) {
    'use strict';

    S.TIMING.sosRingMin = 1;
    S.TIMING.sosRingMax = 2;
    S.TIMING.callPickup = 750;
    S.TIMING.sosHint = 1900;

    S.EMERGENCY = {};

    S.EMERGENCY_SEQUENCE = null;
    S.EMERGENCY_SEQUENCE_MIN = null;
    S.AD_BASE = 'assets/audio/ad/';
    S.AD_BEEP = 'audio-025.ogg';
})(window.Celular = window.Celular || {});
