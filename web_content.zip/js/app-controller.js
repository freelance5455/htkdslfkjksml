const config=WorkspaceConfig,state=WorkspaceState,router=WorkspaceRouter,ui=WorkspaceUI,assets=WorkspaceAssets,apiClient=WorkspaceApi,notifications=WorkspaceNotifications,dialogs=WorkspaceDialogs,settings=WorkspaceSettings,homeHub=WorkspaceHomeHub,sidebar=WorkspaceSidebar,topbar=WorkspaceTopbar,worldHub=WorkspaceFalloutWorldHub,worldTransition=WorkspaceFalloutWorldTransition,modLibrary=window.WorkspaceModLibraryHub,archiveHub=window.WorkspaceArchiveHub,modDetail=window.WorkspaceModDetailHub,researchIntake=window.WorkspaceResearchIntakeHub,questsHub=window.WorkspaceQuestsHub,compatibilityHub=window.WorkspaceCompatibilityHub,compatibilityModel=window.WorkspaceCompatibilityModel,compatibilityLocalVerification=window.WorkspaceCompatibilityLocalVerification,compatibilityFusion=window.WorkspaceCompatibilityFusion,mo2Profiles=window.WorkspaceMo2ProfilesHub,gameSections=window.WorkspaceGameSections,gameDataRegistry=window.WorkspaceGameDataRegistry,gamePackLoader=window.WorkspaceGamePackLoader,knowledgeHub=window.WorkspaceKnowledgeHub,mo2Library=window.WorkspaceModLibraryInstalledState||window.WorkspaceMo2LibraryOverlay,pluginOwnership=window.WorkspacePluginOwnership,fileOverlaps=window.WorkspaceFileOverlaps,pluginRecords=window.WorkspacePluginRecords,questEvidence=window.WorkspaceQuestEvidence,relationshipEvidence=window.WorkspaceRelationshipEvidence,loadOrderInterpretation=window.WorkspaceLoadOrderInterpretation;
const $=id=>document.getElementById(id),fields=['name','game','status','version','installed_version','author','source_url','installed_path','tags','notes','archive_reason'];
let homeWorldArmed=null,modKnowledge=[];
const active=()=>state.records.active,archivedRecords=()=>state.records.archived,currentPage=()=>state.route.page||state.route.screen;
const api=(url,opt)=>apiClient.request(url,opt);
function recentIds(){const rows=settings.migrateLegacy('recent-mods','modRecent',[]);return Array.isArray(rows)?rows.slice(0,5):[]}
function remember(id){const ids=[id,...recentIds().filter(value=>value!==id)].slice(0,5);settings.set('recent-mods',ids);renderRecent()}
function currentWorld(){return config.worlds[state.route.world]||config.worlds.fallout}
function currentGame(){const world=currentWorld();return world.games.find(game=>game.key===state.route.game)||world.games.find(game=>game.key===world.defaultGame)||world.games[0]}
function recordGames(){return [...new Set(active().map(mod=>mod.game&&mod.game.trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b))}
function gameDbName(game=currentGame()){return game.dbNames.find(name=>[...active(),...archivedRecords()].some(mod=>mod.game===name))||game.dbNames[0]}
async function registerRuntimeGamePackProviders(){
  const version=window.WorkspaceVersion?.current?.().version||'0.0.0';
  return gamePackLoader?.discover?.({registry:gameDataRegistry,workspaceVersion:version});
}
function setSidebarActive(target,game=''){sidebar.setActive(target,game)}
function showPage(target,game=''){
  state.route.gameFilter=game;setSidebarActive(target,game);
  if(target==='home'){homeWorldArmed=null;router.show('home','Home',{page:'home',gameFilter:''});renderHome();assets.apply();return}
  if(target==='library'){router.show('library',game||'Mod library',{page:'library',gameFilter:game});renderLibrary();mo2Library.ensure(api).then(()=>{if(currentPage()==='library')renderLibrary()});return}
  if(target==='archive'){router.show('library','Archive',{page:'archive',gameFilter:game});renderLibrary();return}
  const placeholder=config.placeholders[target];if(placeholder){router.showPlaceholder(...placeholder);state.route.page=target}
}
function showGameModLibrary(){
  const game=gameDbName();state.route.gameFilter=game;setSidebarActive('library',game);
  router.showElement('gameMods','libraryPage','Mod Library',{page:'library',game:state.route.game,gameFilter:game});
  document.body.dataset.worldTheme=currentWorld().theme;document.body.dataset.gameKey=state.route.game;renderLibrary();assets.apply();
  mo2Library.ensure(api).then(()=>{if(currentPage()==='library'&&document.body.dataset.screen==='gameMods')renderLibrary()})
}
function animateWorldEntry(world,sourceCard){homeWorldArmed=null;worldTransition.enter({world,sourceCard,assets,onEnter:()=>showWorld(world.key)})}
function selectHomeWorld(key,sourceCard){
  const world=config.worlds[key];if(!world||worldTransition.isBusy())return;
  if(homeWorldArmed===world.key&&state.route.world===world.key){animateWorldEntry(world,sourceCard);return}
  state.route.world=world.key;state.route.game=world.defaultGame;homeWorldArmed=world.key;
  WorkspaceHomeWorldPicker.close();renderHome();assets.apply();
}
function showWorld(key='fallout'){
  const world=config.worlds[key]||config.worlds.fallout;state.route.world=world.key;if(!world.games.some(game=>game.key===state.route.game))state.route.game=world.defaultGame;
  WorkspaceHomeWorldPicker.close();worldHub.show({world,selectedKey:state.route.game,router,assets})
}
function showGame(key){
  const world=currentWorld(),game=world.games.find(item=>item.key===key)||world.games.find(item=>item.key===world.defaultGame)||world.games[0];state.route.game=game.key;
  if(game.key==='fallout-new-vegas'&&window.WorkspaceNewVegasHub){WorkspaceNewVegasHub.show({world,game,records:active(),ui,router,assets,api,normalizeRows:normalizeMo2Rows});return}
  const gameMods=active().filter(mod=>game.dbNames.includes(mod.game)),installed=gameMods.filter(mod=>mod.status==='Installed').length;ui.renderGameChrome(config,gameMods.length);$('gameTitle').textContent=game.title;$('gameRegion').textContent=game.region;$('gameTagline').innerHTML=`Welcome back.<br>${ui.escape(game.region)} is waiting.<br>Your setup is in your hands.`;$('gamePage').dataset.gameKey=game.key;$('gamePage').dataset.artSlot=`${game.key}-hub`;$('gamePage').dataset.worldTheme=world.theme;$('gameWorldBack').dataset.world=world.key;$('gameWorldBack').textContent='‹';$('gameWorldBack').title=`Back to ${world.title} world`;$('gameInstalledStatus').textContent=`${installed} Mod${installed===1?'':'s'} Installed`;router.show('game',game.title,{page:'game',game:game.key,gameFilter:''});document.body.dataset.worldTheme=world.theme;document.body.dataset.gameKey=game.key;assets.apply()
}
function knowledgeFor(mod){return modKnowledge.find(item=>Number(item.id)===Number(mod?.id))||null}
function showModDetail(mod=null){return modDetail.show(mod)}
function fnvMods(){return compatibilityModel.fnvMods()}
function modNexusIdentity(mod,k=knowledgeFor(mod)||{}){return compatibilityModel.modNexusIdentity(mod,k)}
function showCompatibility(){return compatibilityHub.showCenter()}
function showAdvanced(){return compatibilityHub.showAdvanced()}
function showGameSectionPage(screen,title){router.show(screen,title,{page:screen});document.body.dataset.worldTheme=currentWorld().theme}
function showGamePlaceholder(section){const placeholder=config.gamePlaceholders[section];if(!placeholder)return;router.showPlaceholder(...placeholder);state.route.page='placeholder'}
function asArray(value){return Array.isArray(value)?value:(value?[value]:[])}
function normalizeMo2Rows(value){let rows=value;for(let i=0;i<4;i++){if(typeof rows==='string'){try{rows=JSON.parse(rows);continue}catch{return[]}}if(Array.isArray(rows)&&rows.length===1&&(Array.isArray(rows[0])||typeof rows[0]==='string')){rows=rows[0];continue}break}if(!Array.isArray(rows))rows=rows&&typeof rows==='object'?[rows]:[];return rows.flat(4).filter(row=>row&&typeof row==='object'&&!Array.isArray(row))}
function openGameSection(section){if(section==='overview')showGame(state.route.game);else if(section==='mods')showGameModLibrary();else if(['knowledge','tools','settings'].includes(section))gameSections.show(section);else if(section==='research')researchIntake.show();else if(section==='quests')questsHub.show();else if(section==='archive'){state.route.gameFilter=gameDbName();showPage('archive',gameDbName());}else if(section==='profiles')mo2Profiles.show();else if(section==='compatibility')showCompatibility();else showGamePlaceholder(section)}
function renderLibrary(){return currentPage()==='archive'?archiveHub.render():modLibrary.render()}
function renderSidebar(){const games=recordGames();sidebar.render({records:active(),archived:archivedRecords(),games,recentIds:recentIds(),escape:ui.escape.bind(ui)})}
function renderRecent(){const games=recordGames();renderSidebar();WorkspaceHomeRecent.render({records:active(),games,recentIds:recentIds(),escape:ui.escape.bind(ui)})}
function renderHome(){const games=recordGames();homeHub.render({config,state,records:active(),games,recentIds:recentIds(),escape:ui.escape.bind(ui)})}
function renderAll(){renderSidebar();renderHome();if(currentPage()==='library'||currentPage()==='archive')renderLibrary();if(currentPage()==='game')showGame(state.route.game);assets.apply()}
async function load(){const [activeRows,archivedRows,knowledge]=await Promise.all([api('/api/mods'),api('/api/archive'),api('/api/game-pack/fallout-new-vegas/mod-knowledge').catch(()=>({mods:[]}))]);state.records.active=activeRows;state.records.archived=archivedRows;modKnowledge=knowledge.mods||[];renderAll()}
function openEditor(id){return modLibrary.openEditor(id)}
function toast(message){notifications.show(message)}
document.addEventListener('click',event=>{const target=event.target.closest('button,[data-open],[data-compat-mod]');if(!target)return;if(target.dataset.open){const mod=active().find(item=>item.id===Number(target.dataset.open))||archivedRecords().find(item=>item.id===Number(target.dataset.open));showModDetail(mod);return}if(target.dataset.previewMod){showModDetail();return}if(target.dataset.recordId){openEditor(Number(target.dataset.recordId));return}if(target.dataset.gameKey){if(target.dataset.world&&config.worlds[target.dataset.world])state.route.world=target.dataset.world;showGame(target.dataset.gameKey);return}if(target.dataset.world){if(currentPage()==='home')selectHomeWorld(target.dataset.world,target);else showWorld(target.dataset.world);return}if(target.dataset.action==='compat'){showCompatibility();return}if(target.dataset.action==='advanced'){showAdvanced();return}if(target.dataset.gameSection){openGameSection(target.dataset.gameSection);return}if(target.dataset.game){showPage('library',target.dataset.game);return}if(target.dataset.page){showPage(target.dataset.page);return}if(target.dataset.go){showPage(target.dataset.go);return}if(target.dataset.toggle)$(target.dataset.toggle).classList.toggle('open')});
$('modDetailBack').onclick=()=>showGame(state.route.game);
homeHub.bind();sidebar.bind();topbar.bind({onSync:async()=>{await load();await mo2Library.refresh(api);if(currentPage()==='library')renderLibrary();toast('Local workspace refreshed')},onSearch:value=>{showPage('library');$('search').value=value;renderLibrary()},onAdd:()=>openEditor()});
modLibrary.configure({
  state,ui,fields,filters:WorkspaceModLibraryFilters,items:WorkspaceModLibraryItems,installedState:mo2Library,editor:WorkspaceModLibraryEditor,importer:WorkspaceModLibraryImport,
  active,archived:archivedRecords,currentPage,knowledgeFor,renderCurrent:renderLibrary,
  editorDeps:{api,active,archived:archivedRecords,fields,remember,recentIds,settings,dialogs,load,showPage,toast},
  importDeps:{api,active,archived:archivedRecords,load,showPage,toast,gameFilter:()=>state.route.gameFilter||''}
});
archiveHub.configure({stateOwner:WorkspaceArchiveState,presentation:WorkspaceArchivePresentation,items:WorkspaceArchiveItems,filters:WorkspaceModLibraryFilters,state,ui,fields,archived:archivedRecords,knowledgeFor});
knowledgeHub.configure({registry:gameDataRegistry,gameKey:()=>state.route.game||'fallout-new-vegas',openSpecialCategory:openGameSection,api,escape:ui.escape.bind(ui)});knowledgeHub.bind();
gameSections.configure({shellOwner:WorkspaceGameSectionShell,deps:{router,worldTheme:()=>currentWorld().theme,gameKey:()=>state.route.game||'fallout-new-vegas'},owners:[WorkspaceKnowledgeSection,WorkspaceToolsSection,WorkspaceSettingsSection]});
modLibrary.bind();
compatibilityHub.configure({model:WorkspaceCompatibilityModel,library:WorkspaceCompatibilityLibrary,recommendation:WorkspaceCompatibilityRecommendation,localVerification:compatibilityLocalVerification,fusion:compatibilityFusion,center:WorkspaceCompatibilityCenter,advanced:WorkspaceCompatibilityAdvanced,ui,router,api,installedState:mo2Library,active,knowledgeFor,currentWorldTheme:()=>currentWorld().theme,showGameHub:()=>showGame(state.route.game),toast});
compatibilityHub.bind();
mo2Profiles.configure({state:WorkspaceMo2ProfilesState,profileState:WorkspaceMo2ProfileState,modPriority:WorkspaceMo2ModPriority,pluginLoadOrder:WorkspaceMo2PluginLoadOrder,evidence:WorkspaceMo2ProfilesEvidence,scans:WorkspaceMo2ProfilesScans,ui,api,installedState:mo2Library,pluginOwnership,fileOverlaps,pluginRecords,questEvidence,relationshipEvidence,loadOrderInterpretation,modNameFor:id=>active().find(mod=>Number(mod.id)===Number(id))?.name||'',toast,showSection:showGameSectionPage});
mo2Profiles.bind();
modDetail.configure({
  ui,router,assets,api,knowledgeFor,remember,currentPage,installedState:mo2Library,pluginOwnership,fileOverlaps,pluginRecords,questEvidence,relationshipEvidence,
  setSelectedId:compatibilityHub.setSelectedId,getSelectedId:compatibilityHub.getSelectedId
});
researchIntake.configure({ui,toast,fnvMods,modNexusIdentity,showSection:showGameSectionPage});
researchIntake.bind();
questsHub.configure({data:WorkspaceQuestsData,filters:WorkspaceQuestsFilters,list:WorkspaceQuestsList,detail:WorkspaceQuestsDetail,ui,router,currentGameKey:()=>state.route.game,currentWorldTheme:()=>currentWorld().theme});
questsHub.bind();
let assetVersion=null;async function checkAssets(){try{const version=(await api('/api/assets-version')).version;if(assetVersion===null)assetVersion=version;else if(version!==assetVersion)location.reload()}catch{}}
renderHome();assets.apply();setInterval(checkAssets,2500);checkAssets();
(async()=>{try{await window.WorkspaceVersion?.load?.();await registerRuntimeGamePackProviders();if(currentPage()==='gameKnowledge')await knowledgeHub.render()}catch(error){console.error('Game Pack discovery failed',error)}await load()})().catch(error=>alert(error.message));
