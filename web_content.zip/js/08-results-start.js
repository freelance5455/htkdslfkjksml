/* =========================
   战斗结算
========================= */

function finish(win){
  if(!s||s.done||s.resultPending)return;

  s.resultPending=true;
  s.phase='result';

  const battle=s;
  const token=battle.token;

  log(
    win
      ?'战斗结束：我方胜利！正在结算……'
      :'战斗结束：我方失败！正在结算……',
    'system'
  );

  render();

  resultTimer=setTimeout(()=>{
    resultTimer=null;

    if(s!==battle||battle.token!==token||battle.done)return;

    battle.done=true;
    let earned=false;
    if(win && typeof awardFirstClear==='function'){
      earned=awardFirstClear(selectedLevel);
      if(earned)log(`首次通关第${selectedLevel}关，获得🪙1枚金币！`,'good');
      else log('由于不是首次通关，无法获得金币。','system');
    }

    render();

    $('resultIcon').textContent=win?'🏆':'💥';
    $('resultTitle').textContent=win
      ?`第${selectedLevel}关胜利！`
      :'挑战失败';

    $('resultText').textContent=win
      ?`我方（${battle.allies.map(a=>a.name).join('、')}）成功击败本关所有敌人！${earned?' 首次通关奖励已计入存档，获得🪙1枚金币。':' 由于不是首次通关，无法获得金币。'}`
      :'我方全员倒下了。尝试调整作战方案或更换队伍，再试一次吧。';

    $('overlay').classList.add('show');

  },1800);
}
/* =========================
   重开本关
========================= */

function restart(){
  cancelTimers();

  battleToken++;

  s=initial();

  $('logList').innerHTML='';
  $('fxLayer').innerHTML='';
  $('overlay').classList.remove('show');

  log(
    `第${selectedLevel}关开始！我方出战：${s.allies.map(a=>a.name).join('、')}。`,
    'system'
  );

  if(selectedLevel===1){
    log('敌方阵容：鸭皇、拳头盒子。','system');
  }

  if(selectedLevel===2){
    log('敌方阵容：鸭皇1、鸭皇2、鸭皇3。','system');
  }

  if(selectedLevel===3){
    log(
      '敌方阵容：鸭皇、鸭皇队长。队长开局无蓄力状态；轮到自己行动且没有随从时才开始2回合蓄力。',
      'system'
    );
  }

  if(selectedLevel===4){
    log('敌方阵容：女主人、鸭皇队长、拳头盒子。','system');
  }

  log('我方先行动。','system');

  render();
}
/* =========================
   启动游戏
========================= */

showMenu();
renderSelection();
