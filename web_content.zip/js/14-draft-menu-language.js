(function () {
  const L = (...a) => ffmL.apply(null, a);
  const SLOT = { GK: 0, LB: 1, CB: 2, RB: 4, CM: 5, CDM: 6, CAM: 7, LW: 8, ST: 9, RW: 10 };
  const TRAIT = { CB: 'tackler', LB: 'tackler', RB: 'tackler', CDM: 'tackler', CM: 'passer', CAM: 'passer', LW: 'speed', RW: 'speed', ST: 'clinical' };
  const POSES = ['ST', 'LW', 'RW', 'CAM', 'CM', 'CDM', 'CB', 'LB', 'RB'];
  function candidates() {
    if (Array.isArray(state.draftList) && state.draftList.length === 9) return state.draftList;
    const F = (window.FFMStoreData && FFMStoreData.FAMOUS || []).filter(f => f[4] >= 81 && f[4] <= 83 && SLOT[f[2]] != null && f[2] !== 'GK');
    const out = [], used = new Set();
    for (const pos of POSES) {
      const pool = F.filter(f => f[2] === pos && !used.has(f[0]));
      if (!pool.length) continue; const f = pool[Math.floor(Math.random() * pool.length)];
      used.add(f[0]); out.push({ name: f[0], nat: f[1], pos: f[2], age: f[3], rating: f[4] });
    }
    for (const f of F) { if (out.length >= 9) break; if (!used.has(f[0])) { used.add(f[0]); out.push({ name: f[0], nat: f[1], pos: f[2], age: f[3], rating: f[4] }); } }
    state.draftList = out.slice(0, 9); try { saveGame(); } catch (_) {}
    return state.draftList;
  }
  let sel = -1;
  function render() {
    let m = document.getElementById('draft-modal');
    if (!m) {
      m = document.createElement('div'); m.id = 'draft-modal';
      m.style.cssText = 'position:fixed;inset:0;z-index:9500;background:#060a1e;display:flex;flex-direction:column;align-items:center;padding:14px 10px;overflow:auto;font-family:inherit;color:#fff';
      document.body.appendChild(m);
    }
    const c = candidates();
    m.innerHTML = '<div style="font-size:20px;color:#ffd23f;text-align:center;margin:6px 0 4px">👑 ' + L('اختر قائد فريقك', 'Choose your Team Captain', 'Choisis ton capitaine', 'Elige a tu capitán', 'Escolha seu capitão', 'Wähle deinen Kapitän', 'Takım kaptanını seç') + '</div>' +
      '<div style="font-size:12px;color:#9fb3d9;text-align:center;margin-bottom:12px;max-width:340px">' + L('بقية لاعبي فريقك تقييمهم بين 60 و 69. القائد يبدأ أساسيًا.', 'The rest of your squad is rated 60–69. The captain starts in your XI.', 'Le reste de ton équipe est noté 60–69. Le capitaine est titulaire.', 'El resto de tu plantilla tiene 60–69. El capitán es titular.', 'O resto do elenco tem 60–69. O capitão começa jogando.', 'Der Rest deines Kaders ist 60–69. Der Kapitän startet.', 'Kadronun geri kalanı 60–69. Kaptan ilk 11’de başlar.') + '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;width:100%;max-width:380px">' +
      c.map((p, i) => '<div data-i="' + i + '" style="cursor:pointer;padding:4px;border:3px solid ' + (i === sel ? '#ffd23f' : 'transparent') + ';background:' + (i === sel ? 'rgba(255,210,63,.18)' : 'transparent') + ';display:flex;justify-content:center">' + (window.FFMStore && FFMStore.cardHTML ? FFMStore.cardHTML(p) : p.name) + '</div>').join('') + '</div>' +
      '<div style="display:flex;gap:10px;margin-top:16px"><button class="godot-btn" id="draft-ok" style="padding:10px 22px;background:#2e9e4f;opacity:' + (sel >= 0 ? 1 : .45) + '">' + L('تأكيد', 'Confirm', 'Confirmer', 'Confirmar', 'Confirmar', 'Bestätigen', 'Onayla') + '</button>' +
      '<button class="godot-btn" id="draft-back" style="padding:10px 22px">' + L('رجوع', 'Back', 'Retour', 'Volver', 'Voltar', 'Zurück', 'Geri') + '</button></div>';
    m.querySelectorAll('[data-i]').forEach(e => e.onclick = () => { sel = +e.dataset.i; render(); });
    document.getElementById('draft-back').onclick = () => { m.remove(); sel = -1; showScreen('screen-main-menu'); };
    document.getElementById('draft-ok').onclick = () => {
      if (sel < 0) return; const p = c[sel], pl = state.teams.team_1.players, idx = SLOT[p.pos], old = pl[idx];
      pl[idx] = { number: old.number, name: p.name + ' ©', rating: p.rating, contractMatches: 10, pos: p.pos, nat: p.nat, age: p.age, captain: true };
      state.draftPending = false; delete state.draftList; state.captainName = p.name; sel = -1;
      try { saveGame(); } catch (_) {} m.remove(); enterCareerMode();
    };
  }
  window.ffmShowDraft = render;
})();

/* ---- Delete account (settings) ---- */
(function () {
  const L = (...a) => ffmL.apply(null, a);
  function wipe() {
    window.__ffmWiped = true;
    try { localStorage.clear(); } catch (_) {}
    try { sessionStorage.clear(); } catch (_) {}
    try { localStorage.setItem('ffm26_native_restore_declined', '1'); } catch (_) {}
    try { const b = window.FFM26Bridge; if (b && typeof b.saveBackup === 'function') b.saveBackup(''); } catch (_) {}
    try { if (indexedDB && indexedDB.databases) indexedDB.databases().then(ds => ds.forEach(d => indexedDB.deleteDatabase(d.name))); } catch (_) {}
    location.reload();
  }
  function ask() {
    if (!confirm(L('⚠️ سيتم حذف حسابك وكل تقدمك (اللاعبون والتوكنات والمسار المهني) نهائيًا ولا يمكن التراجع. هل أنت متأكد؟',
      '⚠️ This permanently deletes your account and ALL progress (players, tokens, career). This cannot be undone. Are you sure?',
      '⚠️ Cela supprime définitivement ton compte et TOUTE ta progression (joueurs, jetons, carrière). Irréversible. Es-tu sûr ?',
      '⚠️ Esto elimina permanentemente tu cuenta y TODO tu progreso (jugadores, fichas, carrera). No se puede deshacer. ¿Seguro?',
      '⚠️ Isto apaga permanentemente sua conta e TODO o progresso (jogadores, fichas, carreira). Não dá para desfazer. Tem certeza?',
      '⚠️ Dein Konto und ALLER Fortschritt (Spieler, Tokens, Karriere) werden endgültig gelöscht. Nicht rückgängig zu machen. Sicher?',
      '⚠️ Hesabın ve TÜM ilerlemen (oyuncular, jetonlar, kariyer) kalıcı olarak silinir. Geri alınamaz. Emin misin?'))) return;
    if (!confirm(L('تأكيد أخير: حذف الحساب الآن؟', 'Final confirmation: delete the account now?', 'Dernière confirmation : supprimer le compte maintenant ?', 'Última confirmación: ¿eliminar la cuenta ahora?', 'Última confirmação: apagar a conta agora?', 'Letzte Bestätigung: Konto jetzt löschen?', 'Son onay: hesap şimdi silinsin mi?'))) return;
    wipe();
  }
  function ensure() {
    const scr = document.getElementById('screen-settings'); if (!scr) return;
    let b = document.getElementById('delete-account-btn');
    if (!b) {
      b = document.createElement('button'); b.id = 'delete-account-btn'; b.className = 'godot-btn';
      b.style.cssText = 'margin-top:18px;background:#b3261e;width:100%;padding:12px';
      b.style.setProperty('background', '#b3261e', 'important'); b.style.setProperty('border-color', '#5a0f0b', 'important'); b.onclick = ask;
      const ref = scr.querySelector('a.godot-btn'); scr.insertBefore(b, ref);
    }
    b.textContent = '🗑️ ' + L('حذف الحساب', 'Delete Account', 'Supprimer le compte', 'Eliminar cuenta', 'Excluir conta', 'Konto löschen', 'Hesabı Sil');
  }
  const ws = window.showScreen; if (typeof ws === 'function') window.showScreen = function (id) { const r = ws.apply(this, arguments); if (id === 'screen-settings') ensure(); return r; };
  const wl = window.changeLanguage; if (typeof wl === 'function') window.changeLanguage = function () { const r = wl.apply(this, arguments); ensure(); return r; };
  if (document.readyState !== 'loading') ensure(); else document.addEventListener('DOMContentLoaded', ensure);
})();

/* ---- menu transition animation (Web Animations API: not disabled by OS reduced-motion) ---- */
(function () {
  function items(scr) {
    let kids = [...scr.children].filter(e => e.offsetParent !== null || getComputedStyle(e).position === 'fixed');
    for (let d = 0; d < 2 && kids.length <= 2; d++) {
      const big = kids.slice().sort((a, b) => b.children.length - a.children.length)[0];
      if (!big || big.children.length < 3) break;
      kids = [...big.children].filter(e => e.offsetParent !== null);
    }
    return kids;
  }
  function animate(el) {
    if (!el || !el.animate) return;
    requestAnimationFrame(() => {
      try {
        el.animate([{ opacity: 0, transform: 'scale(.94)' }, { opacity: 1, transform: 'scale(1)' }], { duration: 380, easing: 'cubic-bezier(.2,.8,.2,1)' });
        items(el).slice(0, 40).forEach((e, i) => e.animate([{ opacity: 0, transform: 'translateY(34px) scale(.92)' }, { opacity: 1, transform: 'translateY(0) scale(1)' }], { duration: 520, delay: Math.min(i, 12) * 60, easing: 'cubic-bezier(.2,.9,.25,1.15)', fill: 'backwards' }));
      } catch (_) {}
    });
  }
  window.ffmMenuAnim = animate;
  const ws = window.showScreen;
  if (typeof ws === 'function') window.showScreen = function (id) {
    const el = document.getElementById(id), was = el && el.classList.contains('active');
    const r = ws.apply(this, arguments);
    if (el && !was && id !== 'screen-live') animate(el);
    return r;
  };
  // sub-pages of the Rewards/Season/Compete hub live in one screen: animate when the page changes
  let lastView = null;
  const wrapEng = () => {
    const E = window.FFMEng; if (!E || E.__anim || typeof E.go !== 'function') return !!(E && E.__anim);
    const g = E.go; E.__anim = 1;
    E.go = function (v) { const r = g.apply(this, arguments); if (v !== 'menu' && v !== lastView) animate(document.getElementById('screen-eng')); lastView = v === 'menu' ? null : v; return r; };
    return true;
  };
  if (!wrapEng()) { let n = 0; const t = setInterval(() => { if (wrapEng() || ++n > 40) clearInterval(t); }, 250); }
})();

/* ---- loading screen before matches (6s) ---- */
(function () {
  const s0 = window.startLiveMatch; if (typeof s0 !== 'function') return;
  window.startLiveMatch = function () {
    const args = arguments, self = this;
    try { if (matchContext.type === 'career' && state.teams.team_1.players.find(p => Number(p.contractMatches) <= 0)) return s0.apply(self, args); } catch (_) {}
    if (!window.ffmLoader) return s0.apply(self, args);
    ffmLoader.show(6000, () => s0.apply(self, args));
  };
})();
