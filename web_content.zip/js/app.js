(function () {
  "use strict";
  var CL = ["৪+ বেবি", "৫+ বেবি", "প্রথম শ্রেণি", "দ্বিতীয় শ্রেণি", "তৃতীয় শ্রেণি", "চতুর্থ শ্রেণি", "পঞ্চম শ্রেণি"];
  var KS = "crgs_students_v1", KA = "crgs_auth_v1";
  var root = document.getElementById("root");

  function load(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }

  var S = load(KS, []), auth = load(KA, null);
  var admin = false, cls = "all", q = "", modal = "", pend = null, msg = "", err = "";

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  async function hash(s) {
    if (window.crypto && crypto.subtle) {
      var b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("crgs:" + s));
      return Array.from(new Uint8Array(b)).map(function (x) { return x.toString(16).padStart(2, "0"); }).join("");
    }
    var h = 5381;
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
    return "f" + h;
  }

  function list() {
    var t = q.trim().toLowerCase();
    return S.filter(function (s) {
      return (cls === "all" || s.c === +cls) &&
        (!t || [s.n, s.f, s.b, s.p].some(function (v) { return String(v).toLowerCase().indexOf(t) > -1; }));
    });
  }

  function rows() {
    var L = list();
    if (!L.length) return '<div class="em">কোনো শিক্ষার্থী পাওয়া যায়নি</div>';
    return "<table><tr><th>#</th><th>শিক্ষার্থীর নাম</th><th>পিতার নাম</th><th>জন্ম নিবন্ধন</th><th>অভিভাবকের ফোন</th><th>শ্রেণি</th>" +
      (admin ? "<th></th>" : "") + "</tr>" +
      L.map(function (s, i) {
        return "<tr><td>" + (i + 1) + "</td><td>" + esc(s.n) + "</td><td>" + esc(s.f) + "</td><td>" + esc(s.b) +
          "</td><td>" + esc(s.p) + "</td><td>" + CL[s.c] + "</td>" +
          (admin ? '<td><button class="btn s" data-del="' + s.id + '">মুছুন</button></td>' : "") + "</tr>";
      }).join("") + "</table>";
  }

  function modalHtml() {
    var h = "";
    if (modal === "setup" || modal === "login") {
      h = '<h2>' + (modal === "setup" ? "প্রথমবার: ইউজারনেম ও পাসওয়ার্ড তৈরি করুন" : "লগইন") + '</h2>' +
        '<label>ইউজারনেম</label><input id="lu" autocomplete="username">' +
        '<label>পাসওয়ার্ড</label><input id="lp" type="password" autocomplete="current-password">' +
        (modal === "setup" ? '<p class="note">এটি মনে রাখুন। ভুলে গেলে তথ্য যোগ বা মোছা যাবে না।</p>' : "") +
        '<div class="err">' + esc(err) + '</div><div class="act"><button class="btn g" data-a="close">বাতিল</button><button class="btn" data-a="' + modal + 'go">' + (modal === "setup" ? "তৈরি করুন" : "লগইন") + '</button></div>';
    } else if (modal === "add") {
      h = '<h2>নতুন শিক্ষার্থী</h2><label>শিক্ষার্থীর নাম</label><input id="fn"><label>পিতার নাম</label><input id="ff">' +
        '<label>জন্ম নিবন্ধন নম্বর</label><input id="fb" inputmode="numeric"><label>অভিভাবকের ফোন নম্বর</label><input id="fp" type="tel">' +
        '<label>শ্রেণি</label><select id="fc">' + CL.map(function (n, i) { return '<option value="' + i + '"' + (String(i) === cls ? " selected" : "") + ">" + n + "</option>"; }).join("") + "</select>" +
        '<div class="err">' + esc(err) + '</div><div class="act"><button class="btn g" data-a="close">বাতিল</button><button class="btn" data-a="addgo">সংরক্ষণ করুন</button></div>';
    } else if (modal === "del" && pend) {
      h = "<h2>সতর্কতা</h2><p>আপনি কি নিশ্চিত যে <b>" + esc(pend.n) + "</b> (" + CL[pend.c] + ") এর তথ্য মুছে ফেলতে চান? মুছে ফেললে আর ফিরিয়ে আনা যাবে না।</p>" +
        '<div class="act"><button class="btn g" data-a="close">না, থাক</button><button class="btn d" data-a="delgo">হ্যাঁ, মুছে ফেলুন</button></div>';
    } else if (modal === "pw") {
      h = '<h2>পাসওয়ার্ড বদলান</h2><label>নতুন পাসওয়ার্ড</label><input id="np" type="password">' +
        '<div class="err">' + esc(err) + '</div><div class="act"><button class="btn g" data-a="close">বাতিল</button><button class="btn" data-a="pwgo">বদলান</button></div>';
    }
    return h ? '<div class="ov"><div class="md">' + h + "</div></div>" : "";
  }

  function render() {
    var tabs = [["all", "সব (" + S.length + ")"]].concat(CL.map(function (n, i) {
      return [String(i), n + " (" + S.filter(function (s) { return s.c === i; }).length + ")"];
    }));
    root.innerHTML = '<div class="w"><div class="top"><div><h1>Char Rajibpur Government School</h1><p class="sub">শিক্ষার্থীদের তথ্য</p></div>' +
      (admin ? '<button class="btn" data-a="add">+ নতুন শিক্ষার্থী</button>'
             : '<button class="btn g" data-a="' + (auth ? "login" : "setup") + '">লগইন</button>') + "</div>" +
      (msg ? '<div class="msg">' + esc(msg) + "</div>" : "") +
      (admin ? '<div class="bar"><button class="btn g m" data-a="export">ব্যাকআপ নিন</button><button class="btn g m" data-a="import">ব্যাকআপ ফেরত আনুন</button>' +
        '<button class="btn g m" data-a="pw">পাসওয়ার্ড বদলান</button><button class="btn g m" data-a="logout">লগআউট</button>' +
        '<input id="imp" type="file" accept=".json,application/json" style="display:none"></div>' : "") +
      '<div class="tabs">' + tabs.map(function (t) { return '<button class="tab' + (t[0] === cls ? " on" : "") + '" data-c="' + t[0] + '">' + esc(t[1]) + "</button>"; }).join("") + "</div>" +
      '<input id="q" placeholder="নাম, পিতার নাম, ফোন বা জন্ম নিবন্ধন দিয়ে খুঁজুন" value="' + esc(q) + '">' +
      '<div class="tw" id="tb">' + rows() + "</div>" +
      (admin ? "" : '<p class="note">এটি শুধু দেখার জন্য। তথ্য যোগ বা মোছার জন্য লগইন করুন।</p>') + "</div>" + modalHtml();
  }

  function persist() {
    if (!save(KS, S)) { msg = "সংরক্ষণ করা যায়নি। ফোনের জায়গা বা ব্রাউজার সেটিং দেখুন।"; }
  }
  function v(id) { return document.getElementById(id).value.trim(); }

  async function act(a) {
    err = ""; msg = "";
    if (a === "close") { modal = ""; pend = null; }
    else if (a === "login" || a === "setup" || a === "add" || a === "pw") { modal = a; }
    else if (a === "setupgo") {
      var u = v("lu"), p = document.getElementById("lp").value;
      if (!u || p.length < 4) { err = "ইউজারনেম দিন এবং পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের দিন।"; }
      else { auth = { u: u, h: await hash(p) }; save(KA, auth); admin = true; modal = ""; }
    }
    else if (a === "logingo") {
      var u2 = v("lu"), p2 = document.getElementById("lp").value;
      if (auth && u2 === auth.u && (await hash(p2)) === auth.h) { admin = true; modal = ""; }
      else err = "ইউজারনেম বা পাসওয়ার্ড ভুল।";
    }
    else if (a === "logout") { admin = false; }
    else if (a === "pwgo") {
      var np = document.getElementById("np").value;
      if (np.length < 4) err = "কমপক্ষে ৪ অক্ষর দিন।";
      else { auth.h = await hash(np); save(KA, auth); modal = ""; msg = "পাসওয়ার্ড বদলানো হয়েছে।"; }
    }
    else if (a === "addgo") {
      var n = v("fn"), f = v("ff"), b = v("fb"), p3 = v("fp"), c = +document.getElementById("fc").value;
      if (!n || !f || !b || !p3) err = "সব ঘর পূরণ করুন।";
      else if (S.some(function (s) { return s.b === b; })) err = "এই জন্ম নিবন্ধন নম্বর আগেই আছে।";
      else { S.push({ id: Date.now() + Math.floor(Math.random() * 1000), n: n, f: f, b: b, p: p3, c: c }); persist(); modal = ""; msg = msg || "শিক্ষার্থী যোগ হয়েছে।"; }
    }
    else if (a === "delgo") {
      S = S.filter(function (s) { return s.id !== pend.id; }); persist(); pend = null; modal = ""; msg = msg || "মুছে ফেলা হয়েছে।";
    }
    else if (a === "export") {
      var blob = new Blob([JSON.stringify(S, null, 1)], { type: "application/json" });
      var link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "students-backup.json";
      document.body.appendChild(link); link.click(); link.remove();
      msg = "ব্যাকআপ ফাইল ডাউনলোড হচ্ছে।";
    }
    else if (a === "import") { var el = document.getElementById("imp"); if (el) el.click(); return; }
    render();
  }

  root.addEventListener("click", function (e) {
    var t = e.target;
    if (t.dataset.c !== undefined) { cls = t.dataset.c; render(); }
    else if (t.dataset.del) {
      pend = S.filter(function (s) { return String(s.id) === t.dataset.del; })[0];
      modal = "del"; render();
    }
    else if (t.dataset.a) act(t.dataset.a);
  });
  root.addEventListener("input", function (e) {
    if (e.target.id === "q") { q = e.target.value; document.getElementById("tb").innerHTML = rows(); }
  });
  root.addEventListener("change", function (e) {
    if (e.target.id !== "imp" || !e.target.files[0]) return;
    var r = new FileReader();
    r.onload = function () {
      try {
        var d = JSON.parse(r.result), add = 0;
        d.forEach(function (x) {
          if (x && x.n && x.b && !S.some(function (s) { return s.b === String(x.b); })) {
            S.push({ id: Date.now() + Math.floor(Math.random() * 100000), n: String(x.n), f: String(x.f || ""), b: String(x.b), p: String(x.p || ""), c: +x.c || 0 });
            add++;
          }
        });
        persist(); msg = add + " জন শিক্ষার্থী ফেরত আনা হয়েছে।";
      } catch (ex) { msg = "ফাইলটি পড়া যায়নি।"; }
      render();
    };
    r.readAsText(e.target.files[0]);
  });
  render();
})();
