const chats = [
  { name: "Design Team", last: "Alex: Looking good on Android", time: "10:22", members: "12 members" },
  { name: "Family", last: "Mom: Call me later", time: "09:41", members: "5 members" },
  { name: "Work", last: "You: Done", time: "Yesterday", members: "8 members" },
  { name: "Friends", last: "Sam: See you", time: "Yesterday", members: "15 members" },
  { name: "Project X", last: "Bot: Build finished", time: "Mon", members: "4 members" },
  { name: "Night Crew", last: "You: 🔥", time: "Sun", members: "9 members" },
];

let currentChat = null;
let messages = [];

const chatListEl = document.getElementById("chat-list-items");
const messagesEl = document.getElementById("messages");
const msgInput = document.getElementById("msg-input");

function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

function renderChatList() {
  chatListEl.innerHTML = "";
  chats.forEach((c, i) => {
    const item = document.createElement("div");
    item.className = "chat-item";
    item.innerHTML = `
      <div class="avatar">👥</div>
      <div class="chat-meta">
        <div class="chat-name">${c.name}</div>
        <div class="chat-last">${c.last}</div>
      </div>
      <div class="chat-time">${c.time}</div>
    `;
    item.onclick = () => openChat(i);
    chatListEl.appendChild(item);
  });
}

function openChat(index) {
  currentChat = chats[index];
  document.getElementById("chat-title").textContent = currentChat.name;
  document.getElementById("chat-subtitle").textContent = currentChat.members;
  document.getElementById("group-name-display").textContent = currentChat.name;
  document.getElementById("group-members").textContent = currentChat.members;

  messages = [
    { text: "Hey everyone", out: false, time: "10:21", sender: "Alex" },
    { text: "Looking good on Android", out: true, time: "10:22", read: true },
    { text: "Liquid glass is perfect", out: false, time: "10:23", sender: "Sam" },
  ];
  renderMessages();
  showScreen("chat-screen");
}

function renderMessages() {
  messagesEl.innerHTML = "";
  messages.forEach(m => {
    if (!m.out && m.sender) {
      const name = document.createElement("div");
      name.className = "sender-name";
      name.textContent = m.sender;
      messagesEl.appendChild(name);
    }
    const row = document.createElement("div");
    row.className = "bubble-row " + (m.out ? "out" : "in");
    row.innerHTML = `
      <div class="bubble ${m.out ? "out" : "in"}">
        ${m.text}
        <div class="bubble-time">
          ${m.time}
          ${m.out ? (m.read ? " ✓✓" : " ✓") : ""}
        </div>
      </div>
    `;
    messagesEl.appendChild(row);
  });
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function sendMessage() {
  const text = msgInput.value.trim();
  if (!text) return;
  messages.push({ text, out: true, time: "now", read: false });
  msgInput.value = "";
  renderMessages();
}

// Events
document.getElementById("back-btn").onclick = () => showScreen("chat-list");
document.getElementById("info-btn").onclick = () => showScreen("group-info");
document.getElementById("open-group-info").onclick = () => showScreen("group-info");
document.getElementById("info-back").onclick = () => showScreen("chat-screen");
document.getElementById("send-btn").onclick = sendMessage;
msgInput.addEventListener("keydown", e => {
  if (e.key === "Enter") sendMessage();
});

// Group name edit (exact iOS flow)
const editBtn = document.getElementById("edit-name-btn");
const nameDisplay = document.getElementById("group-name-display");
const nameEdit = document.getElementById("group-name-edit");
const doneBtn = document.getElementById("done-btn");

function startEdit() {
  nameDisplay.classList.add("hidden");
  nameEdit.classList.remove("hidden");
  nameEdit.value = nameDisplay.textContent;
  nameEdit.focus();
  doneBtn.classList.remove("hidden");
}

function saveName() {
  const newName = nameEdit.value.trim() || nameDisplay.textContent;
  nameDisplay.textContent = newName;
  document.getElementById("chat-title").textContent = newName;
  if (currentChat) currentChat.name = newName;
  nameEdit.classList.add("hidden");
  nameDisplay.classList.remove("hidden");
  doneBtn.classList.add("hidden");
}

editBtn.onclick = startEdit;
nameDisplay.onclick = startEdit;
doneBtn.onclick = saveName;
nameEdit.addEventListener("keydown", e => {
  if (e.key === "Enter") saveName();
});

// Init
renderChatList();
showScreen("chat-list");
