window.addEventListener('error',function(){var s=document.getElementById('splash');if(s)s.classList.add('hide')});

(()=>{
"use strict";
const DB="SalahTrackerDB",ST="days",LSK="salahTrackerV1";
const T={f:"Farz",sm:"Sunnat-e-Muakkadah",sg:"Sunnat-e-Ghair Muakkadah",w:"Witr Wajib",n:"Nafl"};
const FS=[["j","Jamaat"],["o","On Time (Alone)"],["q","Qaza"],["m","Missed"]],OS=[["y","Padhi"],["n","Nahi Padhi"]];
const MN=["January","February","March","April","May","June","July","August","September","October","November","December"];
const DN=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const PR=[
{id:"fajr",n:"Fajr",i:[["sm",2],["f",2]]},
{id:"zuhr",n:"Zuhr",i:[["sm",4,"Before Farz"],["f",4],["sm",2,"After Farz"],["n",2]]},
{id:"asr",n:"Asr",i:[["sg",4],["f",4]]},
{id:"mag",n:"Maghrib",i:[["f",3],["sm",2],["n",2]]},
{id:"isha",n:"Isha",i:[["sg",4,"Before Farz"],["f",4],["sm",2,"After Farz"],["w",3],["n",2]]}];
/* ASSUMPTION: the Jumu'ah chart was not supplied. Standard Hanafi layout used. Edit this one line to change it. */
const JUM={id:"jum",n:"Jumu'ah",i:[["sm",4,"Before Farz"],["f",2],["sm",4,"After Farz"],["sm",2,"After Farz"],["n",2]]};
const $=s=>document.querySelector(s),pad=n=>String(n).padStart(2,"0");
const idOf=(y,m,d)=>y+"-"+pad(m+1)+"-"+pad(d);
const prayers=dt=>dt.getDay()===5?[PR[0],JUM,PR[2],PR[3],PR[4]]:PR;
let now=new Date();let cur={y:now.getFullYear(),m:now.getMonth()},db=null,data={},open={},first=true;
const say=(t,bad)=>{const e=$("#sv");e.textContent=t;e.className=bad?"bad":""};
let tt;const toast=(t,ms)=>{const e=$("#msg");e.textContent=t;e.className="show";clearTimeout(tt);tt=setTimeout(()=>e.className="",ms||3500)};
const warn=t=>{const e=$("#warn");e.textContent=t;e.hidden=false};

/* ---------- storage ---------- */
function openDB(){return new Promise((res,rej)=>{if(!window.indexedDB)return rej(new Error("IndexedDB unavailable"));
 const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(ST))r.result.createObjectStore(ST,{keyPath:"id"})};
 r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);r.onblocked=()=>rej(new Error("blocked"))})}
const idbAll=()=>new Promise((res,rej)=>{const q=db.transaction(ST).objectStore(ST).getAll();q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});
const idbPut=rec=>new Promise((res,rej)=>{const t=db.transaction(ST,"readwrite");t.objectStore(ST).put(rec);t.oncomplete=res;t.onerror=t.onabort=()=>rej(t.error)});
const lsSave=()=>{try{localStorage.setItem(LSK,JSON.stringify(data));return true}catch(e){return false}};
async function persist(ids){
 say("Saving…");const ls=lsSave();let ok=false;
 if(db){try{for(const id of ids)await idbPut(data[id]);ok=true}catch(e){console.error(e)}}
 if(ok)say("Saved ✓ (database confirmed)");
 else if(ls)say("⚠ Database unavailable. Saved only to fallback storage. Export a backup.",1);
 else say("⚠ NOT saved. Export a backup now.",1);
}

/* ---------- rendering (weekly pages) ---------- */
const MS=MN.map(x=>x.slice(0,3)),SYM={j:"✓",o:"○",q:"△",m:"×"},RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const FI=p=>p.i.findIndex(x=>x[0]==="f"),qaza=(p,rec)=>{const v=rec[p.id+FI(p)];return v==="q"||v==="m"};
let weeks=[],wi=0,fitT,ro=null;
function buildWeeks(y,m){const n=new Date(y,m+1,0).getDate(),w=[];let a=1;for(let d=1;d<=n;d++)if(new Date(y,m,d).getDay()===6||d===n){w.push([a,d]);a=d+1}return w}
function dayHTML(y,m,d){
 const dt=new Date(y,m,d),id=idOf(y,m,d),rec=data[id]?data[id].v:{},op=open[id],ps=prayers(dt);
 const td=y===now.getFullYear()&&m===now.getMonth()&&d===now.getDate(),dl=DN[dt.getDay()]+", "+d+" "+MS[m];
 let h=`<section class="day${td?" today":""}${dt.getDay()===5?" fri":""}" data-day="${id}"><div class="wr"><div class="dc"><span>${DN[dt.getDay()]}</span><b>${d} ${MS[m]}</b></div>`;
 ps.forEach(p=>{const fv=rec[p.id+FI(p)],done=p.i.filter((_,i)=>rec[p.id+i]).length;
  h+=`<button class="pc${op===p.id?" open":""}" data-pc="${p.id}" aria-label="${p.n}"><span class="dot s-${fv||"u"}">${fv?SYM[fv]:""}</span><span class="cap">${p.id==="jum"?"Jumu'ah":done+"/"+p.i.length}</span></button>`});
 h+=`</div>`;
 ps.forEach(p=>{const qz=qaza(p,rec);
  h+=`<div class="pn${op===p.id?" open":""}" data-p="${p.id}"><div><div class="ph">${p.n} · ${dl}</div>`+(qz?`<div class="qn">Farz is Qaza/Missed: Sunnat, Nafl and Witr are disabled (your saved values are kept).</div>`:"");
  p.i.forEach(([t,r,note],i)=>{const k=p.id+i,dis=qz&&t!=="f";
   h+=`<div class="it t-${t}${dis?" dis":""}"><div class="lb"><b>${r} Rakat ${T[t]}</b>${t==="sm"||t==="w"?`<span class="tag ${t}">${t==="sm"?"Muakkadah":"Wajib"}</span>`:""}${note?`<small>${note}</small>`:""}</div><div class="op ${t==="f"?"g4":"g2"}">`+
   (t==="f"?FS.map(([c,l])=>`<button class="st c-${c}${rec[k]===c?" on":""}" data-k="${k}" data-c="${c}">${l}</button>`).join(""):
   `<button class="st sy c-y${rec[k]==="y"?" on":""}" data-k="${k}" data-c="y" aria-label="Padhi"${dis?" disabled":""}>✓</button><button class="st sy c-n${rec[k]==="n"?" on":""}" data-k="${k}" data-c="n" aria-label="Nahi Padhi"${dis?" disabled":""}>✕</button>`)+`</div></div>`});
  h+=`<button class="done" data-done>Save &amp; Close</button></div></div>`});
 return h+"</section>";
}
function fit(){const c=$("#weeks"),pg=c.children[wi];if(pg)c.style.height=pg.offsetHeight+"px"}
function label(){const n=weeks.length,last=wi>=n;$("#wl").textContent=last?"Monthly Summary":`Week ${wi+1} of ${n} · ${weeks[wi][0]}–${weeks[wi][1]} ${MS[cur.m]}`;$("#wp").disabled=wi<=0;$("#wnx").disabled=last}
function render(){
 const {y,m}=cur;weeks=buildWeeks(y,m);if(wi>weeks.length)wi=weeks.length;let h="";
 weeks.forEach(([a,b])=>{h+=`<div class="wk"><div class="wcard"><div class="wh"><span></span><b>Fajr</b><b>Zuhr</b><b>Asr</b><b>Maghrib</b><b>Isha</b></div>`;for(let d=a;d<=b;d++)h+=dayHTML(y,m,d);h+=`</div></div>`});
 h+=`<div class="wk"><div id="sum"></div></div>`;
 const c=$("#weeks");c.innerHTML=h;$("#mo").value=m;$("#yr").value=y;renderSum();
 if(window.ResizeObserver){if(!ro)ro=new ResizeObserver(fit);ro.disconnect();[...c.children].forEach(x=>ro.observe(x))}
 requestAnimationFrame(()=>{c.style.scrollBehavior="auto";c.scrollLeft=wi*c.clientWidth;c.style.scrollBehavior="";fit();label()});
}
function renderSum(){
 const {y,m}=cur,n=new Date(y,m+1,0).getDate(),S={};
 for(const t in T)S[t]={};
 const add=(t,c,r)=>{const a=S[t][c]||(S[t][c]=[0,0]);a[0]++;a[1]+=r};
 for(let d=1;d<=n;d++){const rec=(data[idOf(y,m,d)]||{v:{}}).v;
  prayers(new Date(y,m,d)).forEach(p=>{const q=qaza(p,rec);p.i.forEach(([t,r],i)=>{if(q&&t!=="f"){add(t,"x",r);return}add(t,"A",r);add(t,rec[p.id+i]||"u",r)})})}
 const g=(t,c)=>S[t][c]||[0,0];
 const row=(l,a,cls)=>`<tr><td>${cls?`<i class="sd s-${cls}"></i>`:""}${l}</td><td>${a[0]}</td><td>${a[1]}</td></tr>`;
 const tbl=(t,rows)=>`<div class="card"><h4>${t}</h4><table><tr><th></th><th>Prayers</th><th>Rakats</th></tr>${rows}</table></div>`;
 let h=`<h3>Monthly Summary — ${MN[m]} ${y}</h3>`;
 h+=tbl("Farz",row("Total assigned",g("f","A"))+FS.map(([c,l])=>row(l,g("f",c),c)).join("")+row("Not recorded",g("f","u")));
 [["sm","Sunnat-e-Muakkadah"],["sg","Sunnat-e-Ghair Muakkadah"],["n","Nafl"],["w","Witr Wajib"]].forEach(([t,l])=>{
  h+=tbl(l,row("Total assigned",g(t,"A"))+row("Prayed (✓)",g(t,"y"))+row("Not prayed (✕)",g(t,"n"))+row("Not recorded",g(t,"u"))+row("Disabled (Farz Qaza/Missed, not counted)",g(t,"x")))});
 const cf=[0,1].map(i=>g("f","j")[i]+g("f","o")[i]+g("f","q")[i]),cs=[0,1].map(i=>g("sm","y")[i]+g("sg","y")[i]);
 let ce=cf[0]+cs[0]+g("n","y")[0]+g("w","y")[0],ae=0;for(const t in T)ae+=g(t,"A")[0];
 h+=tbl("Progress",row("Completed Farz",cf)+row("Completed Sunnat",cs)+row("Completed Nafl",g("n","y"))+row("Completed Witr",g("w","y")))+
 `<div class="card"><h4>Overall monthly completion</h4><div class="big">${ae?(ce/ae*100).toFixed(1):0}%</div><div class="note">${ce} of ${ae} prayer entries completed. Completed Farz = Jamaat + On Time + Qaza. Blank and disabled entries are never counted. Prayers = entries, Rakats = total rakats.</div></div>`;
 $("#sum").innerHTML=h;
}
function redrawDay(id){const [y,m,d]=id.split("-").map(Number);const e=document.querySelector(`[data-day="${id}"]`);if(e)e.outerHTML=dayHTML(y,m-1,d)}

/* ---------- events ---------- */
$("#weeks").addEventListener("click",e=>{
 const day=e.target.closest(".day");if(!day)return;const id=day.dataset.day;
 const st=e.target.closest(".st"),pc=e.target.closest(".pc"),dn=e.target.closest("[data-done]");
 const sync=()=>{day.querySelectorAll(".pc").forEach(b=>b.classList.toggle("open",open[id]===b.dataset.pc));day.querySelectorAll(".pn").forEach(n=>n.classList.toggle("open",open[id]===n.dataset.p))};
 if(st){if(st.disabled)return;const rec=data[id]||(data[id]={id,v:{},u:0}),k=st.dataset.k,c=st.dataset.c;
  if(rec.v[k]===c)delete rec.v[k];else rec.v[k]=c;rec.u=Date.now();
  redrawDay(id);renderSum();persist([id]);return}
 if(pc){open[id]=open[id]===pc.dataset.pc?null:pc.dataset.pc;sync();
  if(open[id])setTimeout(()=>{const n=day.querySelector(".pn.open");if(n)n.scrollIntoView({block:"nearest",behavior:RM?"auto":"smooth"})},280);return}
 if(dn){open[id]=null;sync();toast("Saved")}
});
const tw=()=>{const i=weeks.findIndex(([a,b])=>now.getDate()>=a&&now.getDate()<=b);return i<0?0:i};
$("#mo").innerHTML=MN.map((n,i)=>`<option value="${i}">${n}</option>`).join("");
let yo="";for(let y=2000;y<=2100;y++)yo+=`<option>${y}</option>`;$("#yr").innerHTML=yo;
const go=(y,m)=>{cur={y,m};weeks=buildWeeks(y,m);wi=(y===now.getFullYear()&&m===now.getMonth())?tw():0;render();window.scrollTo(0,0)};
$("#mo").onchange=()=>go(cur.y,+$("#mo").value);$("#yr").onchange=()=>go(+$("#yr").value,cur.m);
$("#pv").onclick=()=>{const d=new Date(cur.y,cur.m-1,1);go(d.getFullYear(),d.getMonth())};
$("#nx").onclick=()=>{const d=new Date(cur.y,cur.m+1,1);go(d.getFullYear(),d.getMonth())};
$("#td").onclick=()=>go(now.getFullYear(),now.getMonth());
function pageTo(i){const c=$("#weeks");wi=Math.max(0,Math.min(weeks.length,i));c.scrollTo({left:wi*c.clientWidth,behavior:RM?"auto":"smooth"});label();fit()}
$("#wp").onclick=()=>pageTo(wi-1);$("#wnx").onclick=()=>pageTo(wi+1);
$("#weeks").addEventListener("scroll",()=>{clearTimeout(fitT);fitT=setTimeout(()=>{const c=$("#weeks");wi=Math.max(0,Math.min(weeks.length,Math.round(c.scrollLeft/c.clientWidth)));fit();label()},90)},{passive:true});
addEventListener("resize",()=>{const c=$("#weeks");c.scrollLeft=wi*c.clientWidth;fit()});

/* ---------- in-app dialogs (replace confirm(); WebViews often block it) ---------- */
let dlgRes=null,dlgOn=false,pendBack=false,pushAfter=false;
function pushDlg(){if(pendBack){pushAfter=true;return}try{history.pushState({dlg:1},"")}catch(e){}}
function closeDlg(r){if(!dlgOn)return;dlgOn=false;$("#dlgbg").classList.remove("show");const f=dlgRes;dlgRes=null;
 try{if(history.state&&history.state.dlg){pendBack=true;history.back()}}catch(e){pendBack=false}if(f)f(r)}
function dlg(o){return new Promise(res=>{
 if(dlgOn)closeDlg({v:null,t:""});
 dlgRes=res;dlgOn=true;const box=$("#dlg");box.innerHTML="";
 const h=document.createElement("h3");h.textContent=o.title||"";box.appendChild(h);
 if(o.text){const p=document.createElement("p");p.textContent=o.text;box.appendChild(p)}
 let ta=null;if(o.textarea!==undefined){ta=document.createElement("textarea");ta.value=o.textarea;ta.readOnly=!!o.ro;ta.placeholder=o.ph||"";ta.setAttribute("autocomplete","off");ta.setAttribute("spellcheck","false");box.appendChild(ta)}
 const bx=document.createElement("div");bx.className="btns";
 (o.buttons||[]).forEach(b=>{const el=document.createElement("button");el.textContent=b.label;if(b.pri)el.className="pri";
  el.onclick=()=>{if(b.fn)b.fn(ta);if(!b.keep)closeDlg({v:b.value,t:ta?ta.value:""})};bx.appendChild(el)});
 box.appendChild(bx);$("#dlgbg").classList.add("show");
 pushDlg();
 if(ta&&o.ro)setTimeout(()=>{try{ta.focus();ta.select()}catch(e){}},50)})}
const ask=(text,ok,no)=>dlg({title:"Please confirm",text,buttons:[{label:ok||"OK",value:true,pri:true},{label:no||"Cancel",value:false}]}).then(r=>r.v===true);
addEventListener("popstate",()=>{if(pendBack){pendBack=false;if(pushAfter){pushAfter=false;if(dlgOn)try{history.pushState({dlg:1},"")}catch(e){}}return}if(dlgOn){dlgOn=false;$("#dlgbg").classList.remove("show");const f=dlgRes;dlgRes=null;if(f)f({v:null,t:""})}});
$("#dlgbg").addEventListener("click",e=>{if(e.target.id==="dlgbg")closeDlg({v:null,t:""})});

/* ---------- backup ---------- */
function copyText(ta){try{ta.focus();ta.select();ta.setSelectionRange(0,ta.value.length);
 if(document.execCommand&&document.execCommand("copy")){toast("Copied to clipboard");return}}catch(e){}
 try{if(navigator.clipboard){navigator.clipboard.writeText(ta.value).then(()=>toast("Copied to clipboard"),()=>toast("Copy blocked. Long-press the text and choose Copy."));return}}catch(e){}
 toast("Copy blocked. Long-press the text and choose Copy.")}
function saveFile(text,name){try{const a=document.createElement("a"),u=URL.createObjectURL(new Blob([text],{type:"application/json"}));
 a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),2000);toast("Save requested: "+name+" (if nothing appears, use Copy instead)",5000)}catch(e){toast("Saving a file is not supported here. Use Copy.",5000)}}
$("#ex").onclick=async()=>{
 const out={app:"SalahTracker",version:1,exported:new Date().toISOString(),days:{}};
 for(const id in data)out.days[id]=data[id];
 const txt=JSON.stringify(out,null,1),name="AQEEM_Salah_Backup_"+idOf(now.getFullYear(),now.getMonth(),now.getDate())+".json",n=Object.keys(out.days).length;
 const bt=[{label:"Copy Backup Text",keep:true,pri:true,fn:copyText},{label:"Save as File",keep:true,fn:()=>saveFile(txt,name)}];
 if(navigator.share)bt.push({label:"Share…",keep:true,fn:()=>{navigator.share({title:"AQEEM backup",text:txt}).catch(()=>{})}});
 bt.push({label:"Close",value:"x"});
 await dlg({title:"Backup ready ("+n+" day"+(n===1?"":"s")+")",text:"Copy this text and keep it safe (Notes, a message to yourself, email). To restore later, use Import Backup and paste it back.",textarea:txt,ro:true,buttons:bt});
};
$("#im").onclick=async()=>{
 const r=await dlg({title:"Import Backup",text:"Paste your backup text below, or choose a backup .json file.",textarea:"",ph:"Paste backup text here…",buttons:[
  {label:"Restore from Pasted Text",value:"go",pri:true},{label:"Choose Backup File…",keep:true,fn:()=>{closeDlg({v:null,t:""});setTimeout(()=>$("#fi").click(),60)}},{label:"Cancel",value:"x"}]});
 if(r&&r.v==="go"){if(!r.t.trim()){toast("Nothing pasted.");return}await importText(r.t)}
};
async function importText(txt){
 try{const o=JSON.parse(txt);
  if(!o||o.app!=="SalahTracker"||!o.days||typeof o.days!=="object")throw new Error("Not a Salah Tracker backup");
  const inc={};
  for(const id in o.days){if(!/^\d{4}-\d{2}-\d{2}$/.test(id))throw new Error("Bad date: "+id);
   const v=(o.days[id]||{}).v;if(!v||typeof v!=="object")throw new Error("Bad record: "+id);
   for(const k in v)if(!validCode(k,v[k]))throw new Error("Bad entry in "+id);
   inc[id]={id,v:{...v},u:o.days[id].u||0}}
  const changed=[],conf=[];
  for(const id in inc){const ex=data[id];
   if(!ex||!Object.keys(ex.v).length){changed.push(id);continue}
   const s=JSON.stringify(Object.entries(ex.v).sort()),b=JSON.stringify(Object.entries(inc[id].v).sort());
   if(s!==b)conf.push(id)}
  let over=false;
  if(conf.length)over=await ask(conf.length+" date(s) in the backup differ from your saved records.\n\nReplace = use the backup values for those dates.\nKeep mine = keep your existing records for those dates (everything else is still merged).","Replace","Keep mine");
  const ids=[...changed,...(over?conf:[])];
  ids.forEach(id=>{data[id]=inc[id]});
  if(ids.length)await persist(ids);render();
  toast("Backup read: "+Object.keys(inc).length+" day(s) in file. Restored/added: "+ids.length+". Kept your existing: "+(over?0:conf.length)+". Already identical: "+(Object.keys(inc).length-ids.length-(over?0:conf.length))+".",7000);
 }catch(err){toast("Import failed: "+err.message+". Use the text or .json file made by Export Backup.",7000)}
}
const OK={f:"joqm",sm:"yn",sg:"yn",w:"yn",n:"yn"};
function validCode(k,c){return typeof c==="string"&&c.length===1&&/^(fajr|zuhr|jum|asr|mag|isha)\d$/.test(k)&&"joqmyn".includes(c)}
$("#fi").onchange=async e=>{
 const inp=e.target,f=inp.files&&inp.files[0];if(!f)return;
 try{const txt=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(new Error("Could not read the file"));r.readAsText(f)});inp.value="";toast("Reading "+f.name+"…",2500);await importText(txt)}
 catch(err){inp.value="";toast("Import failed: "+err.message,7000)}
};
$("#clr").onclick=async()=>{
 if(!await ask("Delete ALL saved Salah records? This cannot be undone. Export a backup first.","Continue","Cancel"))return;
 if(!await ask("Final confirmation: permanently delete everything?","Delete Everything","Cancel"))return;
 try{if(db)await new Promise((r,j)=>{const t=db.transaction(ST,"readwrite");t.objectStore(ST).clear();t.oncomplete=r;t.onerror=()=>j(t.error)});
  localStorage.removeItem(LSK);data={};open={};render();say("All data cleared");toast("All data cleared")}
 catch(e){toast("Could not clear: "+e.message)}
};

/* ---------- start ---------- */
(async()=>{
 let ls={};try{ls=JSON.parse(localStorage.getItem(LSK)||"{}")||{}}catch(e){}
 try{db=await openDB();(await idbAll()).forEach(r=>{data[r.id]=r})}
 catch(e){db=null;warn("Database could not be opened ("+e.message+"). Entries are kept in fallback storage only. Export a backup regularly.")}
 for(const id in ls){const r=ls[id];if(!r||!r.v)continue;if(!data[id]||(r.u||0)>(data[id].u||0)){data[id]=r;if(db)idbPut(r).catch(()=>{})}}
 go(cur.y,cur.m);say(db?"Ready. Changes save automatically.":"Ready (fallback storage only).",!db);
 if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().then(()=>{$("#pst").textContent="Storage: saved privately inside this app on this phone."}).catch(()=>{});
 else $("#pst").textContent="Storage: saved privately inside this app on this phone.";
 setTimeout(()=>{const s=$("#splash");if(s){s.classList.add("hide");setTimeout(()=>s.remove(),700)}},900);
 document.addEventListener("visibilitychange",()=>{if(!document.hidden){const n=new Date();if(n.toDateString()!==now.toDateString()){now=n;go(now.getFullYear(),now.getMonth())}}});
})();
})();
