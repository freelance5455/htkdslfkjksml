const calculators=[
{cat:"🧵 FABRIC",items:[
{id:"gsm",icon:"🧶",title:"GSM Calculator",desc:"Sample weight and dimensions → GSM",fields:[["weight","Sample weight (grams)"],["length","Length (cm)"],["width","Width (cm)"]]},
{id:"consumption",icon:"📏",title:"Fabric Consumption",desc:"Order quantity × consumption + wastage",fields:[["qty","Order quantity (pcs)"],["cons","Consumption (kg/pc)"],["waste","Wastage (%)"]]},
{id:"weight",icon:"⚖️",title:"Fabric Weight",desc:"Total garment fabric requirement",fields:[["qty","Garment quantity (pcs)"],["cons","Fabric consumption (kg/pc)"],["waste","Wastage (%)"]]}
]},
{cat:"💰 COSTING",items:[
{id:"orderValue",icon:"💵",title:"Order Value",desc:"Quantity × price per piece",fields:[["qty","Order quantity (pcs)"],["price","Price / FOB per pc"]]},
{id:"fob",icon:"💰",title:"FOB Costing",desc:"Component cost + profit margin",fields:[["fabric","Fabric cost / pc"],["acc","Accessories / pc"],["cm","CM / CMT / pc"],["wash","Wash / processing / pc"],["other","Other cost / pc"],["profit","Profit (%)"]]}
]},
{cat:"📦 CARTON & SHIPMENT",items:[
{id:"carton",icon:"📦",title:"Carton Calculator",desc:"Cartons and total CBM",fields:[["qty","Order quantity (pcs)"],["pcs","Pieces / carton"],["l","Carton length (cm)"],["w","Carton width (cm)"],["h","Carton height (cm)"]]},
{id:"cbm",icon:"🚢",title:"CBM Calculator",desc:"Carton dimensions → total CBM",fields:[["cartons","Number of cartons"],["l","Length (cm)"],["w","Width (cm)"],["h","Height (cm)"]]}
]},
{cat:"📊 ORDER",items:[
{id:"dozen",icon:"🔢",title:"PCS ↔ Dozen",desc:"Convert pieces to dozens",fields:[["qty","Quantity (pcs)"]]},
{id:"ratio",icon:"📊",title:"Size Ratio",desc:"Calculate S/M/L/XL quantities",fields:[["qty","Total quantity (pcs)"],["s","S (%)"],["m","M (%)"],["l","L (%)"],["xl","XL (%)"]]}
]},
{cat:"🏭 PRODUCTION",items:[
{id:"production",icon:"🏭",title:"Production Capacity",desc:"Operators × time × efficiency / SMV",fields:[["operators","Operators"],["hours","Working hours"],["smv","SMV"],["eff","Efficiency (%)"]]},
{id:"efficiency",icon:"⚙️",title:"Line Efficiency",desc:"Output × SMV / available minutes",fields:[["output","Actual output (pcs)"],["smv","SMV"],["minutes","Available minutes"]]}
]}];
let current=null;
const $=id=>document.getElementById(id), val=k=>parseFloat($("f_"+k)?.value||0);
function renderHome(filter=""){const box=$("cards");box.innerHTML="";calculators.forEach(c=>{let a=c.items.filter(x=>(x.title+" "+x.desc).toLowerCase().includes(filter.toLowerCase()));if(!a.length)return;box.insertAdjacentHTML("beforeend",`<div class="cat">${c.cat}</div>`);a.forEach(x=>box.insertAdjacentHTML("beforeend",`<div class="card" onclick="openCalc('${x.id}')"><div class="icon">${x.icon}</div><h3>${x.title}</h3><p>${x.desc}</p></div>`))})}
function findCalc(id){for(const c of calculators){const x=c.items.find(i=>i.id===id);if(x)return x}}
function openCalc(id){current=findCalc(id);showScreen("calculator");$("calcIcon").textContent=current.icon;$("calcTitle").textContent=current.title;$("calcDesc").textContent=current.desc;$("form").innerHTML=current.fields.map(f=>`<div class="field"><label>${f[1]}</label><input id="f_${f[0]}" type="number" step="any" min="0"></div>`).join("");$("result").classList.add("hidden")}
function fmt(n){return Number.isFinite(n)?n.toLocaleString(undefined,{maximumFractionDigits:2}):"—"}
function calculate(){let lines=[],big="";
switch(current.id){
case"gsm":big=fmt(val("weight")*10000/(val("length")*val("width")))+" GSM";break;
case"consumption":{let b=val("qty")*val("cons"),t=b*(1+val("waste")/100);big=fmt(t)+" kg";lines=[["Base fabric",fmt(b)+" kg"],["Wastage",fmt(t-b)+" kg"]];break}
case"weight":{let b=val("qty")*val("cons"),t=b*(1+val("waste")/100);big=fmt(t)+" kg";lines=[["Base weight",fmt(b)+" kg"],["Wastage",fmt(t-b)+" kg"]];break}
case"orderValue":big="$"+fmt(val("qty")*val("price"));break;
case"fob":{let b=val("fabric")+val("acc")+val("cm")+val("wash")+val("other"),t=b*(1+val("profit")/100);big="$"+fmt(t)+"/pc";lines=[["Base cost","$"+fmt(b)+"/pc"],["Profit","$"+fmt(t-b)+"/pc"]];break}
case"carton":{let c=Math.ceil(val("qty")/val("pcs")),cb=c*val("l")*val("w")*val("h")/1e6;big=fmt(c)+" cartons";lines=[["Pieces/carton",fmt(val("pcs"))],["Total CBM",fmt(cb)+" m³"]];break}
case"cbm":big=fmt(val("cartons")*val("l")*val("w")*val("h")/1e6)+" m³";break;
case"dozen":big=fmt(val("qty")/12)+" dozen";break;
case"ratio":{let t=val("s")+val("m")+val("l")+val("xl");big=fmt(t)+"% ratio";lines=[["S",fmt(val("qty")*val("s")/100)+" pcs"],["M",fmt(val("qty")*val("m")/100)+" pcs"],["L",fmt(val("qty")*val("l")/100)+" pcs"],["XL",fmt(val("qty")*val("xl")/100)+" pcs"]];break}
case"production":big=fmt(val("operators")*val("hours")*60/val("smv")*val("eff")/100)+" pcs/day";break;
case"efficiency":big=fmt(val("output")*val("smv")/val("minutes")*100)+"%";break}
$("result").innerHTML=`<div>Estimated result</div><div class="big">${big}</div>`+lines.map(x=>`<div class="line"><span>${x[0]}</span><strong>${x[1]}</strong></div>`).join("");$("result").classList.remove("hidden");saveHistory(current.title,big)}
function saveHistory(title,result){let h=JSON.parse(localStorage.getItem("gcp_history")||"[]");h.unshift({title,result,date:new Date().toLocaleString()});localStorage.setItem("gcp_history",JSON.stringify(h.slice(0,50)))}
function showHistory(){showScreen("history");let h=JSON.parse(localStorage.getItem("gcp_history")||"[]");$("historyList").innerHTML=h.length?h.map(x=>`<div class="history-item"><strong>${x.title}</strong>${x.result}<small>${x.date}</small></div>`).join(""):"<p>No saved calculations yet.</p>"}
function clearHistory(){localStorage.removeItem("gcp_history");showHistory()}
function showScreen(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active")}
function goHome(){showScreen("home")}
function resetCalc(){$("form").querySelectorAll("input").forEach(x=>x.value="");$("result").classList.add("hidden")}
function showPro(){$("modal").classList.remove("hidden")}function closeModal(){$("modal").classList.add("hidden")}
function demoPurchase(){alert("Demo only. Google Play Billing needs to be connected before selling Pro.");closeModal()}
$("search").addEventListener("input",e=>renderHome(e.target.value));$("proBtn").onclick=showPro;renderHome();