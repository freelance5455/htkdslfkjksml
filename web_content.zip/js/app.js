// Deep Contextual Story Engine (100% dynamic simulation matching user persona)
const EngineDB = {
    funny: {
        themes: [
            "في يوم مليء بالضحكات والشقاوة، تبدأ مغامرتنا غير المتوقعة بالمرة! {HERO} كان يتجول دائماً بفضول كبير وابتسامة واسعة تغطي وجهه السعيد.",
            "هل سمعتم يوماً عن أغرب ما يمكن أن يحدث في وضح النهار؟ حسنًا، بطلنا {HERO} كان على وشك الغوص في مغامرة هزلية مضحكة للغاية ستجعل الغابة بأكملها تبتسم!",
            "بقلب نابض بالمرح والشقاوة الطريفة، قرر {HERO} أن يقلب الموازين اليوم ويخلق فكرة عجيبة ومرحة لم يفكر بها أحد من قبل!"
        ],
        twists: {
            "جحا": "وفجأة! ظهر جحا المشهور بذكائه الطريف وحركاته المضحكة، راكباً حماره بشكل مقلوب تماماً! الحمار كان يرتدي نظارة شمسية زرقاء ويحاول التحدث مع {HERO} بلغة العصافير، مما جعل الجميع ينفجرون من الضحك!",
            "حمار": "وفجأة! ظهر حمار جحا اللطيف وهو يمشي على قدمين ويرتدي قبعة قش دائرية! الحمار قرر أن يفتح مدرسة لتعليم الضحك والمقالب البريئة، وكان {HERO} هو المساعد الأول له وسط دهشة الجميع وسعادتهم المفروطة!",
            "أرنب": "وفجأة! قفز أرنب عملاق يرتدي بدلة فضاء لامعة مصنوعة من ورق الحلوى الملون! الأرنب كان يظن أن النجوم عبارة عن قطع بسكويت لذيذة، وحاول الطيران مستخدماً بالونات هيدروجينية عملاقة بمساعدة {HERO} اللطيف في مشهد كوميدي ساحر!",
            "فضاء": "وفجأة! انطلقت مركبة فضائية تشبه ثمرة البطيخ الكبيرة! طارت في السماء وبدأت تمطر ألعاباً ودمى ناعمة تصدر أصواتاً مضحكة، بينما كان {HERO} يرقص مع الكائنات الفضائية اللطيفة التي تبحث عن أصدقاء مرحين!",
            "أسد": "وفجأة! زأر أسد ضخم.. لكن زئيره تحول إلى زقزقة عصفور رقيقة! الأسد كان مسكيناً وخجولاً للغاية، يرتدي جوارب صوفية ملونة ويطلب من {HERO} أن يعلمه كيف يكون شجاعاً ومضحكاً في نفس الوقت!"
        },
        genericTwists: [
            "وفي وسط الساحة، بدأت الأشجار تتراقص وتطلق نكاتاً طريفة، بينما كانت السناجب تصفق وتطلق ضحكات مجنونة ومبهجة، ليشاركهم {HERO} المغامرة الفكاهية الأكثر روعة في التاريخ والكل يتعلم أن الابتسامة هي مفتاح القلوب!",
            "وقعت مفارقة غريبة جعلت الأرانب تطارد الثعالب في لعبة غميضة مضحكة للغاية! {HERO} قاد هذه اللعبة بذكاء وحس دعابة منقطع النظير، لتنتهي الأزمة بضحكات جماعية صافية تملأ الأرجاء."
        ],
        endings: [
            "وهكذا، انتهى اليوم المليء بالمقالب البريئة والضحك المتواصل، وعاد {HERO} إلى البيت وهو لا يزال يبتسم ويتذكر تفاصيل هذا الموقف الطريف جداً، لينام سعيداً مبتهجاً.",
            "ضحك الجميع حتى تعبت بطونهم اللطيفة، وتأكد {HERO} أن الفرح ومشاركة الابتسامة مع الأصدقاء هي أجمل ما في الكون. أحلاماً سعيدة ومضحكة يا بطل!"
        ]
    },
    sleep: {
        themes: [
            "كان يا ما كان، في غابة بعيدة تملؤها السكينة والأسرار الدافئة، حيث تهمس النجوم للسماء الزرقاء وتنام الزهور مستسلمة للنسيم اللطيف، عاش بطلنا المحبوب {HERO}.",
            "عندما بدأ المساء يرخي ستائره المخملية الدافئة، وتنشر الطمأنينة أنوارها الخافتة في كل زاوية، استرخى بطلنا الصغير {HERO} متأملاً سحر الليل الهادئ.",
            "في عالم الأحلام الهادئة، حيث تمشي السحب ببطء شديد وتغني العصافير أنشودة النوم العذبة، انطلق {HERO} في رحلة ذهنية مريحة تملأ القلب سلاماً."
        ],
        twists: {
            "جحا": "وفي هذه الأجواء الساحرة، مر جحا وحماره يمشيان بخطوات هادئة جداً على العشب الناعم المنعش. جحا كان يلقي على {HERO} كلمات دافئة عن السلام والرضا، بينما كان حماره الصغير يستمع في خشوع مريح للنفس.",
            "حمار": "وفي تلك اللحظة، رقد حمار صغير ولطيف بجانب شجرة الصفصاف العتيقة، مغلقاً عينيه الصغيرتين ومستمعاً لخرير الماء العذب، ليشارك {HERO} شعور الاسترخاء التام والهدوء البديع.",
            "أرنب": "ومن بعيد، شوهد أرنب صغير ناعم الفراء يتثاءب بلطف شديد وهو يغطي نفسه بعباءة من أوراق الأشجار الخضراء المريحة، ليعلم {HERO} أن وقت الراحة والاسترخاء قد حان الآن.",
            "فضاء": "وعند النظر لأعلى، كانت النجوم البعيدة تتلألأ برفق ونعومة شديدة، كأنها مصابيح صغيرة تدعو {HERO} لتصفية ذهنه والنظر إلى اتساع الكون الساحر المليء بالهدوء والصمت الجميل.",
            "أسد": "وفجأة، ظهر أسد حكيم ومسالم للغاية، جلس على العشب الدافئ وبدأ يتنفس بعمق وهدوء، ملقياً السلام والاطمئنان في قلب {HERO}، ليعلمه كيف يسترخي جسده تماماً ويستعد للنوم البديع."
        },
        genericTwists: [
            "بدأت الغيوم البيضاء الناعمة تتقارب لتمسح برفق على جبين بطلنا، ناشرةً عطراً ذكياً من زهور الياسمين البرية التي تساعد النفس على الهدوء التام والانسجام البديع مع الطبيعة الصامتة الحالمة.",
            "هدأت الحركة تماماً في الأرجاء، وأغلقت الحيوانات الصغيرة عيونها تلو الأخرى في طمأنينة تامة، ليدرك {HERO} كم هو رائع أن يستسلم الجسد للراحة بعد يوم جميل ومفيد."
        ],
        endings: [
            "ومع آخر همسة من النجوم المتلألئة، أغلق بطلنا براء عينيه الصغيرتين، لينام في دفء وسلام تام، غارقاً في أحلام وردية رائعة. تصبح على خير يا بطل الصغير.",
            "تثاءب الكون بأسره، واحتضن الفراش الدافئ بطلنا الذكي، لتسكن الطمأنينة روحه النقية الصافية وينام نوماً عميقاً ومريحاً للغاية إلى أن تشرق شمس يوم جديد سعيد."
        ]
    },
    adventure: {
        themes: [
            "بشغف لا يعرف الحدود وعينين تشعان ذكاءً وحماساً، قرر المغامر البطل {HERO} فتح بوابة الاستكشاف اليوم وخوض رحلة مشوقة تملأها الألغاز!",
            "في قلب الغابة الأسطورية المليئة بالمسارات السرية والكنوز المفقودة، انطلق بطلنا الشجاع {HERO} حاملاً خريطته السحرية ومستعداً لكل التحديات.",
            "لم يكن {HERO} يوماً طفلاً عادياً، بل كان يمتلك فضولاً خارقاً يدفعه دائماً لفك الأسرار واستكشاف المجهول بكل شجاعة وعزيمة!"
        ],
        twists: {
            "جحا": "وفي قمة الحماس، عثر {HERO} على مغارة سرية، وبداخلها وجد جحا الحكيم يفك شفرة خريطة قديمة تدل على مكان كنز الأخلاق والذكاء! جحا وحماره انضما فوراً للبطل بذكاء وسرعة وخفة حركية مذهلة للوصول للهدف!",
            "حمار": "وفجأة، تعثر بطلنا بصخرة غريبة، ليجد خلفها حماراً أسطورياً يمتلك بوصلة ذهبية سحرية ترشده للممرات المفقودة! الحمار بدأ يركض بذكاء متفادياً العقبات وقاد {HERO} نحو قمة الجبل الشاهق لخوض التحدي الكبير!",
            "أرنب": "وفجأة، ظهر أرنب بري سريع كالبرق، يرتدي وشاحاً أحمر مخصصاً للمستكشفين! الأرنب كان يعرف الممرات السرية المؤدية لقلعة الألغاز، وقرر مساعدة {HERO} في فك لغز الغابة المحيرة بأسلوب تشويقي خارق!",
            "فضاء": "وعند عبور الممر الضيق، انفتحت فجوة زمنية سحرية أخذت {HERO} إلى عالم الفضاء اللامتناهي بين النيازك الملونة والمجرات الدوارة، حيث توجب عليه استخدام ذكائه السريع للملاحة والعودة للديار بنجاح مبهر!",
            "أسد": "وفجأة، ظهر أسد جبار يحرس بوابة الكنز الأسطوري! لم يخف {HERO}، بل واجه الأسد بالشجاعة والابتسامة، ليتضح أن الأسد يطلب حل أحجية ذكية ليسمح له بالمرور والتفوق في هذا التحدي الحماسي!"
        },
        genericTwists: [
            "توالت الأحداث سريعة ومثيرة، وتطلب الأمر تعاوناً جماعياً كبيراً واستغلالاً ذكياً لكل تفصيلة صغيرة في البيئة المحيطة، لينجح {HERO} في النهاية بتخطي الصعاب ببراعة لا مثيل لها.",
            "انفتحت الأبواب المغلقة بفضل الذكاء والإصرار، ووجد الأصدقاء أنفسهم أمام مشهد رائع يثبت أن الشجاعة والتعاون المشترك قادران على قهر أصعب التحديات والمخاطر."
        ],
        endings: [
            "وهكذا عاد البطل المغامر {HERO} إلى دياره حاملاً وسام الشجاعة وذكريات قصة حماسية ومشوقة للغاية لن ينساها أبداً، مستعداً للمغامرة القادمة بكل شغف.",
            "انتهت المغامرة بنجاح ساحق وعاد السلام للغابة بفضل ذكاء {HERO} الخارق، ليتعلم الجميع أن البطل الحقيقي هو من يستخدم عقله وقلبه لعمل الخير دائماً."
        ]
    }
};

function generateStoryText(prompt, age, style, hero) {
    const db = EngineDB[style] || EngineDB['funny'];
    const selectedHero = hero.trim() ? hero.trim() : "براء";
    
    // Select dynamic blocks
    let intro = db.themes[Math.floor(Math.random() * db.themes.length)];
    intro = intro.replace(/{HERO}/g, selectedHero);
    
    // Process twists contextually based on prompts input tokens
    let midSection = "";
    let matched = false;
    
    for (let key in db.twists) {
        if (prompt.includes(key)) {
            midSection += db.twists[key].replace(/{HERO}/g, selectedHero) + "\n\n";
            matched = true;
        }
    }
    
    if (!matched) {
        let gt = db.genericTwists[Math.floor(Math.random() * db.genericTwists.length)];
        midSection += gt.replace(/{HERO}/g, selectedHero) + "\n\n";
    }
    
    let outro = db.endings[Math.floor(Math.random() * db.endings.length)];
    outro = outro.replace(/{HERO}/g, selectedHero);
    
    // Form titles contextually
    let title = "";
    if (style === 'funny') title = `مغامرة ${selectedHero} الطريفة والمضحكة`;
    else if (style === 'sleep') title = `حكاية نوم هادئة لـ ${selectedHero}`;
    else title = `رحلة ${selectedHero} الاستكشافية الخارقة`;
    
    const fullStory = `${intro}\n\n${midSection}${outro}`;
    return { title, text: fullStory };
}

// App global states
let currentStory = null;
let synth = window.speechSynthesis;
let utterance = null;
let isSpeaking = false;

function switchTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    
    if(tab === 'create') {
        document.querySelector("button[onclick*='create']").classList.add('active');
        document.getElementById('create-screen').classList.add('active');
    } else {
        document.querySelector("button[onclick*='library']").classList.add('active');
        document.getElementById('library-screen').classList.add('active');
        renderLibrary();
    }
    // Stop speech on switch
    if (isSpeaking) toggleSpeech();
}

function generateStory() {
    const prompt = document.getElementById('story-prompt').value;
    const age = document.getElementById('child-age').value;
    const style = document.getElementById('story-style').value;
    const hero = document.getElementById('hero-name').value;
    
    if(!prompt.trim()) {
        alert("الرجاء كتابة فكرة أو بعض الكلمات للقصة أولاً! ✨");
        return;
    }
    
    // Immediate instant generation emulation with true intelligence
    const storyData = generateStoryText(prompt, age, style, hero);
    currentStory = storyData;
    
    document.getElementById('result-title').innerText = storyData.title;
    document.getElementById('result-text').innerText = storyData.text;
    
    document.getElementById('result-container').classList.remove('hidden');
    document.getElementById('result-container').scrollIntoView({ behavior: 'smooth' });
}

function toggleSpeech() {
    if(!currentStory) return;
    
    if(isSpeaking) {
        synth.cancel();
        isSpeaking = false;
        document.getElementById('listen-text').innerText = "استمع للقصة";
    } else {
        synth.cancel(); // safety flush
        utterance = new SpeechSynthesisUtterance(currentStory.text);
        utterance.lang = 'ar-EG'; // Safe native arabic rendering accent
        utterance.rate = 0.85;    // Child-friendly warm slow reading pace
        
        utterance.onend = () => {
            isSpeaking = false;
            document.getElementById('listen-text').innerText = "استمع للقصة";
        };
        
        synth.speak(utterance);
        isSpeaking = true;
        document.getElementById('listen-text').innerText = "إيقاف الاستماع";
    }
}

function saveToLibrary() {
    if(!currentStory) return;
    
    let library = JSON.parse(localStorage.getItem('kid_stories')) || [];
    
    // Prevent duplicate entries
    if(library.some(s => s.title === currentStory.title && s.text === currentStory.text)) {
        alert("هذه القصة محفوظة بالفعل في مكتبتك! 📚");
        return;
    }
    
    library.push({
        title: currentStory.title,
        text: currentStory.text,
        date: new Date().toLocaleDateString('ar-EG')
    });
    
    localStorage.setItem('kid_stories', JSON.stringify(library));
    alert("تم حفظ القصة بنجاح في المكتبة (Bib)! 🎉");
}

function renderLibrary() {
    const container = document.getElementById('library-container');
    let library = JSON.parse(localStorage.getItem('kid_stories')) || [];
    
    if(library.length === 0) {
        container.innerHTML = `<div class="empty-library">مكتبتك فارغة حالياً. اصنع قصتك السحرية الأولى واحفظها هنا! 🌟</div>`;
        return;
    }
    
    container.innerHTML = library.map((story, index) => `
        <div class="lib-item">
            <h3>${story.title}</h3>
            <div class="lib-meta">📅 تم الحفظ: ${story.date}</div>
            <div class="lib-actions">
                <button class="btn-small btn-small-read" onclick="readFromLib(${index})">📖 قراءة واستماع</button>
                <button class="btn-small btn-small-delete" onclick="deleteFromLib(${index})">🗑️ حذف</button>
            </div>
        </div>
    `).join('');
}

function readFromLib(index) {
    let library = JSON.parse(localStorage.getItem('kid_stories')) || [];
    if(!library[index]) return;
    
    currentStory = library[index];
    
    document.getElementById('result-title').innerText = currentStory.title;
    document.getElementById('result-text').innerText = currentStory.text;
    
    switchTab('create');
    document.getElementById('result-container').classList.remove('hidden');
    document.getElementById('result-container').scrollIntoView({ behavior: 'smooth' });
}

function deleteFromLib(index) {
    if(!confirm("هل أنت متأكد من حذف هذه القصة من مكتبتك؟ 🧐")) return;
    
    let library = JSON.parse(localStorage.getItem('kid_stories')) || [];
    library.splice(index, 1);
    localStorage.setItem('kid_stories', JSON.stringify(library));
    renderLibrary();
}
