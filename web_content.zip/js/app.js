'use strict';

const STORAGE = {
  servers: 'hardpanel.pro.servers.v1',
  history: 'hardpanel.pro.history.v1',
  settings: 'hardpanel.pro.settings.v1'
};
const API_BASE = 'https://api.mcquery.net/java';
const DEFAULT_SERVERS = [
  { id: 'hardday-default', name: 'HardDay', host: 'mc.HardDay.top', port: 25565, favorite: true, status: null, checkedAt: null }
];

const state = {
  tab: 'home',
  morePage: 'tools',
  servers: loadJSON(STORAGE.servers, DEFAULT_SERVERS),
  history: loadJSON(STORAGE.history, []),
  settings: loadJSON(STORAGE.settings, { refreshSeconds: 60 }),
  busy: new Set(),
  editingId: null,
  pingSamples: [],
  pingRunning: false,
  toolBusy: '',
  toolResult: null
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const screen = $('#screen');
let toastTimer = null;

function loadJSON(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return value ?? fallback;
  } catch (_) { return fallback; }
}
function saveJSON(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
function saveServers() { saveJSON(STORAGE.servers, state.servers); }
function saveHistory() { state.history = state.history.slice(-300); saveJSON(STORAGE.history, state.history); }
function saveSettings() { saveJSON(STORAGE.settings, state.settings); }
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}
function toast(message) {
  const node = $('#toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove('show'), 2600);
}
function fmtTime(timestamp) {
  return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(timestamp));
}
function formatMs(value) { return Number.isFinite(value) ? `${Math.round(value)} ms` : '—'; }
function statusBadge(status) {
  const kind = status?.online === true ? 'online' : status?.online === false ? 'offline' : 'unknown';
  const label = kind === 'online' ? 'ONLINE' : kind === 'offline' ? 'OFFLINE' : 'UNKNOWN';
  return `<span class="status ${kind}"><i class="dot"></i>${label}</span>`;
}
function serverHost(server) { return `${server.host}:${server.port}`; }
function recordHistory(server, status) {
  state.history.push({
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    timestamp: Date.now(), name: server.name, host: server.host, port: server.port,
    online: status.online === true ? true : status.online === false ? false : null, latency_ms: status.latency_ms ?? null,
    api_rtt_ms: status.api_rtt_ms ?? null,
    players_online: status.players_online ?? null,
    players_max: status.players_max ?? null
  });
  saveHistory();
}

async function fetchTimed(url, options = {}, timeoutMs = 12000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(timeout); }
}

async function fetchMinecraftStatus(server) {
  const url = new URL(API_BASE);
  url.searchParams.set('target', server.host);
  url.searchParams.set('port', String(server.port));
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  const started = performance.now();
  try {
    const response = await fetch(url.toString(), { method: 'GET', mode: 'cors', cache: 'no-store', signal: controller.signal });
    const apiRtt = performance.now() - started;
    if (!response.ok) {
      if (response.status === 429) throw new Error('Лимит внешнего API. Подожди немного и повтори.');
      throw new Error(`API вернул HTTP ${response.status}`);
    }
    const data = await response.json();
    if (data.ok === false) throw new Error(data.msg || 'Не удалось проверить сервер');
    const connection = data.connection || {};
    const online = !!(connection.host || data.version?.name || data.players || data.description || data.favicon);
    const version = data.version?.name || data.version || null;
    const players = data.players || {};
    const latency = Number.isFinite(data.latency_ms) ? data.latency_ms : null;
    return {
      online,
      latency_ms: latency,
      api_rtt_ms: Math.round(apiRtt),
      version: typeof version === 'string' ? version : null,
      motd: flattenMotd(data.description || data.motd || ''),
      players_online: Number.isFinite(players.online) ? players.online : null,
      players_max: Number.isFinite(players.max) ? players.max : null,
      checked_at: new Date().toISOString(),
      cached: !!data.cached,
      provider: 'McQuery'
    };
  } catch (error) {
    const message = error.name === 'AbortError' ? 'Время ожидания API истекло' : (error.message || 'Ошибка сетевого запроса');
    throw new Error(message);
  } finally {
    clearTimeout(timeout);
  }
}
function flattenMotd(value) {
  if (typeof value === 'string') return value.replace(/§[0-9a-fk-or]/gi, '').replace(/<[^>]*>/g, '').trim();
  if (Array.isArray(value)) return value.map(flattenMotd).filter(Boolean).join('\n');
  if (value && typeof value === 'object') {
    return `${value.text || ''}${(value.extra || []).map(flattenMotd).join('')}`.replace(/§[0-9a-fk-or]/gi, '').trim();
  }
  return '';
}

async function checkServer(server, { silent = false } = {}) {
  if (state.busy.has(server.id)) return;
  state.busy.add(server.id);
  render();
  try {
    const status = await fetchMinecraftStatus(server);
    server.status = status;
    server.checkedAt = Date.now();
    recordHistory(server, status);
    saveServers();
    if (!silent) toast(`${server.name}: ${status.online ? 'сервер отвечает' : 'офлайн'}`);
  } catch (error) {
    const status = { online: null, error: error.message, api_rtt_ms: null, checked_at: new Date().toISOString() };
    server.status = status;
    server.checkedAt = Date.now();
    recordHistory(server, status);
    saveServers();
    if (!silent) toast(`${server.name}: ${error.message}`);
  } finally {
    state.busy.delete(server.id);
    render();
  }
}

async function refreshAll() {
  if (state.busy.size) return toast('Проверка уже выполняется');
  if (!state.servers.length) return toast('Сначала добавь сервер');
  for (const server of state.servers) await checkServer(server, { silent: true });
  toast('Обновление завершено');
}

function render() {
  $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.tab === state.tab));
  switch (state.tab) {
    case 'ping': renderPing(); break;
    case 'servers': renderServers(); break;
    case 'more': renderMore(); break;
    default: renderHome(); break;
  }
  if (state.tab === 'ping') drawPingChart();
}

function renderHome() {
  const featured = state.servers.find(s => s.favorite) || state.servers[0];
  const status = featured?.status;
  const remotePing = status?.latency_ms;
  const apiRtt = status?.api_rtt_ms;
  screen.innerHTML = `
    <div class="section-heading"><div><div class="eyebrow">CONTROL CENTER / 01</div><h1>Главная</h1><p>Мониторинг публичных серверов</p></div><span class="tag">PRO</span></div>
    ${featured ? `
      <section class="panel">
        <div class="panel-title">ИЗБРАННЫЙ СЕРВЕР</div>
        <div class="server-main"><div><div class="server-name">${esc(featured.name)}</div><div class="server-host">${esc(serverHost(featured))}</div></div>${statusBadge(status)}</div>
        <div class="metrics">
          <div class="metric"><span>${remotePing != null ? 'SERVER PING' : 'API RTT'}</span><strong>${formatMs(remotePing ?? apiRtt)}</strong></div>
          <div class="metric"><span>ОНЛАЙН</span><strong>${status?.online ? `${status.players_online ?? '—'} / ${status.players_max ?? '—'}` : status?.online === false ? 'Офлайн' : '—'}</strong></div>
          <div class="metric"><span>ВЕРСИЯ</span><strong>${esc(status?.version || '—')}</strong></div>
        </div>
        ${status?.motd ? `<div class="motd">${esc(status.motd)}</div>` : ''}
        ${status?.error ? `<div class="meta-note">${esc(status.error)}</div>` : ''}
        <div class="meta-note">${status?.checked_at ? `Последняя проверка: ${fmtTime(new Date(status.checked_at).getTime())}` : 'Данные ещё не загружались'}${status?.cached ? ' • ответ из кэша' : ''}</div>
        <button class="button primary full" data-action="refresh-server" data-id="${esc(featured.id)}" ${state.busy.has(featured.id) ? 'disabled' : ''}>${state.busy.has(featured.id) ? '<i class="spinner"></i> Проверяем...' : '↻ Обновить статус'}</button>
      </section>` : `<div class="empty">Список серверов пуст.<br>Добавь свой первый Minecraft-сервер.</div>`}
    <div class="section-heading"><div><div class="eyebrow">SHORTCUTS</div><h1>Быстрый доступ</h1></div></div>
    <div class="quick-grid">
      <button class="quick-card" data-tab="ping"><span class="tool-icon"><svg viewBox="0 0 24 24"><path d="M3 17h3v4H3zm5-6h3v10H8zm5-5h3v15h-3zm5-4h3v19h-3z"/></svg></span><span><b>Ping и графики</b><small>Время ответа проверок</small></span></button>
      <button class="quick-card" data-tab="servers"><span class="tool-icon"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/></svg></span><span><b>Мои серверы</b><small>Список и избранное</small></span></button>
      <button class="quick-card" data-tab="more" data-page="tools"><span class="tool-icon">⌁</span><span><b>Сетевые инструменты</b><small>DNS, сайт, скорость</small></span></button>
      <button class="quick-card" data-tab="more" data-page="history"><span class="tool-icon">◷</span><span><b>История</b><small>Последние измерения</small></span></button>
    </div>
    <section class="panel" style="margin-top:12px"><div class="tool-head"><span class="tool-icon">i</span><div><b style="font-size:13px">Как считается ping</b><div class="meta-note" style="margin:3px 0 0">Браузер не умеет напрямую открывать произвольные TCP/ICMP-сокеты. Minecraft-статус получает внешний API; время ответа API показывается отдельно от ping сервера, если источник его не возвращает.</div></div></div><div class="meta-note">Нет плагинов, RCON и подключения к панели хостинга. Список и история хранятся локально.</div></section>
  `;
}

function renderServers() {
  const rows = state.servers.map(server => {
    const status = server.status;
    const ping = status?.latency_ms != null ? formatMs(status.latency_ms) : status?.api_rtt_ms != null ? `${formatMs(status.api_rtt_ms)} API` : '—';
    return `<article class="server-row">
      <div class="row-top"><div class="server-avatar">${esc(server.name.slice(0, 2).toUpperCase())}</div><div class="row-info"><b>${esc(server.name)}</b><small>${esc(serverHost(server))}</small></div>${statusBadge(status)}</div>
      <div class="row-status">${status?.online ? `${status.players_online ?? '—'} / ${status.players_max ?? '—'} игроков • ${esc(status.version || 'Версия неизвестна')}` : status?.online === false ? 'Сервер не ответил' : status?.error ? `Ошибка проверки: ${esc(status.error)}` : 'Ещё не проверен'}${status?.checked_at ? ` • ${fmtTime(new Date(status.checked_at).getTime())}` : ''}</div>
      <div class="row-actions"><span style="margin-right:auto;align-self:center;font-size:11px;color:var(--muted)">${ping}</span><button class="mini-action ${server.favorite ? 'active' : ''}" data-action="favorite" data-id="${esc(server.id)}" aria-label="Избранное">${server.favorite ? '★' : '☆'}</button><button class="mini-action" data-action="check" data-id="${esc(server.id)}" aria-label="Проверить">↻</button><button class="mini-action" data-action="edit" data-id="${esc(server.id)}" aria-label="Изменить">✎</button><button class="mini-action" data-action="delete" data-id="${esc(server.id)}" aria-label="Удалить">×</button></div>
    </article>`;
  }).join('');
  screen.innerHTML = `<div class="section-heading"><div><div class="eyebrow">SERVER MANAGER / 02</div><h1>Серверы</h1><p>Добавляй любые публичные Minecraft-серверы</p></div><button class="button primary small" data-action="add-server">＋ Добавить</button></div>
    <div class="server-list">${rows || '<div class="empty">Список пуст.<br>Добавь сервер, чтобы начать мониторинг.</div>'}</div>
    <p class="disclaimer">Статус запрашивается через публичный Minecraft Status API. Ответы могут кэшироваться сторонним провайдером и обновляться не каждую секунду.</p>`;
}

function renderPing() {
  const target = state.servers.find(s => s.favorite) || state.servers[0];
  const last = state.pingSamples.at(-1);
  const values = state.pingSamples.map(v => v.api_rtt_ms).filter(Number.isFinite);
  const avg = values.length ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : null;
  screen.innerHTML = `<div class="section-heading"><div><div class="eyebrow">LATENCY ANALYTICS / 03</div><h1>Ping и графики</h1><p>Измерение задержки HTTP-проверок</p></div><span class="tag">LIVE</span></div>
    <section class="panel">
      <div class="panel-title">ЦЕЛЕВОЙ СЕРВЕР</div>
      <select id="ping-target" class="field" style="margin-top:8px">${state.servers.map(s => `<option value="${esc(s.id)}" ${target?.id === s.id ? 'selected' : ''}>${esc(s.name)} · ${esc(serverHost(s))}</option>`).join('')}</select>
      <button class="button primary full" data-action="ping-sample" ${state.pingRunning || !target ? 'disabled' : ''}>${state.pingRunning ? '<i class="spinner"></i> Идёт серия проверок...' : '▶ Запустить 5 проверок'}</button>
      <p class="disclaimer">Каждая проверка обращается к внешнему Minecraft API. График показывает RTT между телефоном и API, а не прямой ICMP ping до игрового хоста. Пять замеров выполняются с интервалом 6 секунд.</p>
    </section>
    <section class="latency-card"><div class="panel-title">СРЕДНЕЕ ВРЕМЯ ОТВЕТА API</div><div class="big-value">${avg ?? '—'} <small>ms</small></div><div class="chart-wrap"><canvas id="ping-chart"></canvas></div>
      <div class="chart-stats"><div class="metric"><span>ПОСЛЕДНЕЕ</span><strong>${last ? formatMs(last.api_rtt_ms) : '—'}</strong></div><div class="metric"><span>МИНИМУМ</span><strong>${values.length ? `${Math.min(...values)} ms` : '—'}</strong></div><div class="metric"><span>МАКСИМУМ</span><strong>${values.length ? `${Math.max(...values)} ms` : '—'}</strong></div></div>
    </section>
    <div class="section-heading" style="margin-top:18px"><div><div class="eyebrow">RECENT SAMPLES</div><h1 style="font-size:18px">Замеры сессии</h1></div><span class="tag">${values.length} / 5</span></div>
    <div class="history-list">${state.pingSamples.length ? [...state.pingSamples].reverse().map((v, i) => `<div class="history-item"><span class="dot" style="background:${v.online ? 'var(--green)' : 'var(--red)'}"></span><div class="left"><b>${v.online ? 'Сервер ответил' : 'Сервер не ответил'}</b><small>${fmtTime(v.timestamp)} • ${esc(v.host)}</small></div><strong>${formatMs(v.api_rtt_ms)}</strong></div>`).join('') : '<div class="empty">Пока нет замеров. Запусти серию проверок.</div>'}</div>`;
}

function drawPingChart() {
  const canvas = $('#ping-chart');
  if (!canvas) return;
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 320;
  const height = canvas.clientHeight || 150;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  const ctx = canvas.getContext('2d');
  ctx.scale(ratio, ratio);
  ctx.clearRect(0, 0, width, height);
  const values = state.pingSamples.map(v => Number(v.api_rtt_ms)).filter(Number.isFinite);
  ctx.strokeStyle = '#292c36'; ctx.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    const y = 8 + i * (height - 16) / 3;
    ctx.beginPath(); ctx.moveTo(4, y); ctx.lineTo(width - 4, y); ctx.stroke();
  }
  if (values.length < 2) return;
  const max = Math.max(...values, 20) * 1.15;
  const min = Math.min(0, ...values);
  const xStep = (width - 16) / (values.length - 1);
  const points = values.map((v, i) => ({ x: 8 + i * xStep, y: height - 10 - ((v - min) / Math.max(1, max - min)) * (height - 22) }));
  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, 'rgba(255,38,63,.23)'); gradient.addColorStop(1, 'rgba(255,38,63,0)');
  ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
  ctx.lineTo(points.at(-1).x, height - 8); ctx.lineTo(points[0].x, height - 8); ctx.closePath(); ctx.fillStyle = gradient; ctx.fill();
  ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); ctx.strokeStyle = '#ff263f'; ctx.lineWidth = 2.6; ctx.lineJoin = 'round'; ctx.stroke();
  points.forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); ctx.fillStyle = '#ff263f'; ctx.fill(); });
}

function renderMore() {
  const page = state.morePage;
  const head = `<div class="section-heading"><div><div class="eyebrow">TOOLS / 04</div><h1>Ещё</h1><p>Диагностика и настройки HardPanel</p></div></div>
    <div class="quick-grid" style="margin-bottom:14px"><button class="quick-card" data-page="tools"><span class="tool-icon">⌁</span><span><b>Инструменты</b><small>Проверка сети</small></span></button><button class="quick-card" data-page="history"><span class="tool-icon">◷</span><span><b>История</b><small>Локальные записи</small></span></button><button class="quick-card" data-page="settings"><span class="tool-icon">⚙</span><span><b>Настройки</b><small>Параметры приложения</small></span></button></div>`;
  screen.innerHTML = head + (page === 'history' ? renderHistoryHTML() : page === 'settings' ? renderSettingsHTML() : renderToolsHTML());
}
function renderToolsHTML() {
  return `<div class="section-heading"><div><div class="eyebrow">NETWORK TOOLS</div><h1 style="font-size:18px">Диагностика сети</h1></div></div>
    <section class="tool-card"><div class="tool-head"><span class="tool-icon">⌕</span><div><h3>DNS lookup</h3><p>Получить IPv4/IPv6-адреса через DNS-over-HTTPS.</p></div></div><input class="field" id="dns-host" value="mc.HardDay.top" autocapitalize="off" spellcheck="false"><button class="button secondary full" data-action="dns">Найти DNS-записи</button><div class="result-box hidden" id="dns-result"></div></section>
    <section class="tool-card"><div class="tool-head"><span class="tool-icon">↗</span><div><h3>Проверка сайта</h3><p>Проверка HTTP-ответа через публичный fetch-прокси. Не работает для всех сайтов.</p></div></div><input class="field" id="http-url" value="https://hardday.top" autocapitalize="off" spellcheck="false"><button class="button secondary full" data-action="http">Проверить сайт</button><div class="result-box hidden" id="http-result"></div></section>
    <section class="tool-card"><div class="tool-head"><span class="tool-icon">⇩</span><div><h3>Тест скорости</h3><p>Измерение примерной скорости загрузки через публичный тестовый узел Cloudflare.</p></div></div><button class="button secondary full" data-action="speed" ${state.toolBusy === 'speed' ? 'disabled' : ''}>${state.toolBusy === 'speed' ? '<i class="spinner"></i> Тестируем...' : 'Запустить download-тест'}</button><div class="result-box ${state.toolResult?.kind === 'error' ? 'error' : ''} ${state.toolResult?.tool === 'speed' ? '' : 'hidden'}" id="speed-result">${state.toolResult?.tool === 'speed' ? esc(state.toolResult.text) : ''}</div></section>
    <section class="tool-card"><div class="tool-head"><span class="tool-icon">⊙</span><div><h3>Что недоступно в WebView</h3><p>Произвольные ICMP/TCP-сокеты и сканирование портов браузер не предоставляет. Нужен нативный Android-модуль или собственный сетевой агент.</p></div></div><span class="tag">НЕ ИМИТИРУЕТСЯ</span></section>
    <p class="disclaimer">DNS-запросы выполняются через Cloudflare DNS-over-HTTPS. HTTP-проверка использует сторонний публичный прокси, поэтому не отправляй через неё приватные адреса или секретные URL.</p>`;
}
function renderHistoryHTML() {
  const rows = [...state.history].reverse().slice(0, 80).map(item => `<div class="history-item"><span class="dot" style="background:${item.online === true ? 'var(--green)' : item.online === false ? 'var(--red)' : 'var(--muted)'}"></span><div class="left"><b>${esc(item.name)} · ${item.online === true ? 'ONLINE' : item.online === false ? 'OFFLINE' : 'NO DATA'}</b><small>${esc(item.host)}:${item.port} • ${fmtTime(item.timestamp)}</small></div><strong>${formatMs(item.latency_ms ?? item.api_rtt_ms)}</strong></div>`).join('');
  return `<div class="section-heading"><div><div class="eyebrow">LOCAL STORAGE</div><h1 style="font-size:18px">История проверок</h1></div><button class="button ghost small" data-action="clear-history">Очистить</button></div><div class="history-list">${rows || '<div class="empty">История пока пуста.<br>Проверь любой сервер, чтобы сохранить результат.</div>'}</div><p class="disclaimer">История хранится в локальном хранилище приложения на этом устройстве. Удаление данных приложения очистит историю.</p>`;
}
function renderSettingsHTML() {
  return `<div class="section-heading"><div><div class="eyebrow">PREFERENCES</div><h1 style="font-size:18px">Настройки</h1></div></div>
    <section class="panel"><div class="panel-title">ПРИЛОЖЕНИЕ</div><div class="settings-row"><div><b>Тема</b><small>Чёрная с красными акцентами</small></div><span class="tag">BLACK</span></div><div class="settings-row"><div><b>Версия</b><small>HardPanel Pro · Web build 1.0</small></div><b>1.0.0</b></div></section>
    <section class="panel"><div class="panel-title">МОНИТОРИНГ</div><div class="settings-row"><div><b>Фоновые проверки</b><small>В ZIPtoAPK WebView JavaScript не может гарантированно работать в фоне после закрытия приложения.</small></div><span class="tag">ОГРАНИЧЕНО</span></div><div class="settings-row"><div><b>Автообновление</b><small>Проверяй вручную, чтобы не превышать лимиты внешнего API.</small></div><span class="tag">MANUAL</span></div></section>
    <section class="panel"><div class="panel-title">ЛОКАЛЬНЫЕ ДАННЫЕ</div><div class="settings-row"><div><b>Сохранённые серверы</b><small>${state.servers.length} сервер(ов)</small></div><b>${state.servers.length}</b></div><div class="settings-row"><div><b>История проверок</b><small>${state.history.length} записей</small></div><b>${state.history.length}</b></div><button class="button secondary full" data-action="export">Экспортировать данные JSON</button><button class="button ghost full" data-action="reset">Сбросить HardPanel</button></section>
    <p class="disclaimer">Для настоящего ICMP/TCP ping, стабильных фоновых задач, сканера портов и системных уведомлений нужна нативная Android-сборка. ZIPtoAPK создаёт WebView-оболочку.</p>`;
}

function openServerModal(server = null) {
  state.editingId = server?.id ?? null;
  $('#modal-title').textContent = server ? 'Изменить сервер' : 'Новый сервер';
  $('#server-name').value = server?.name || '';
  $('#server-host').value = server?.host || '';
  $('#server-port').value = server?.port || 25565;
  $('#server-id').value = server?.id || '';
  $('#server-modal').classList.remove('hidden');
  setTimeout(() => $('#server-name').focus(), 50);
}
function closeServerModal() { $('#server-modal').classList.add('hidden'); }
function normalizeHost(value) {
  return value.trim().replace(/^https?:\/\//i, '').split('/')[0].trim();
}
function onServerSubmit(event) {
  event.preventDefault();
  const name = $('#server-name').value.trim();
  const host = normalizeHost($('#server-host').value);
  const port = Number($('#server-port').value);
  if (!name || !host || !Number.isInteger(port) || port < 1 || port > 65535) return toast('Проверь название, адрес и порт');
  if (state.editingId) {
    const server = state.servers.find(s => s.id === state.editingId);
    if (server) Object.assign(server, { name, host, port });
  } else {
    state.servers.push({ id: `srv-${Date.now()}`, name, host, port, favorite: state.servers.length === 0, status: null, checkedAt: null });
  }
  saveServers(); closeServerModal(); render(); toast('Сервер сохранён');
}

async function runPingSeries() {
  const id = $('#ping-target')?.value;
  const server = state.servers.find(s => s.id === id);
  if (!server) return toast('Добавь сервер для проверки');
  if (state.pingRunning) return;
  state.pingRunning = true; state.pingSamples = []; render();
  for (let i = 0; i < 5; i++) {
    const startedAt = Date.now();
    try {
      const status = await fetchMinecraftStatus(server);
      server.status = status; server.checkedAt = Date.now();
      state.pingSamples.push({ timestamp: Date.now(), host: server.host, online: status.online, api_rtt_ms: status.api_rtt_ms });
      recordHistory(server, status); saveServers();
    } catch (error) {
      state.pingSamples.push({ timestamp: Date.now(), host: server.host, online: null, api_rtt_ms: null, error: error.message });
      recordHistory(server, { online: null, error: error.message });
    }
    render();
    if (i < 4) await new Promise(resolve => setTimeout(resolve, Math.max(0, 6000 - (Date.now() - startedAt))));
  }
  state.pingRunning = false; render(); toast('Серия проверок завершена');
}

async function runDns() {
  const box = $('#dns-result'); const host = $('#dns-host').value.trim();
  box.classList.remove('hidden'); box.textContent = 'Запрашиваем DNS...';
  try {
    const answers = [];
    for (const type of ['A', 'AAAA']) {
      const url = `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(host)}&type=${type}`;
      const response = await fetch(url, { headers: { accept: 'application/dns-json' }, cache: 'no-store' });
      if (!response.ok) throw new Error(`DNS HTTP ${response.status}`);
      const data = await response.json();
      (data.Answer || []).filter(a => a.type === (type === 'A' ? 1 : 28)).forEach(a => answers.push(`${type}: ${a.data}`));
    }
    box.textContent = answers.length ? answers.join('\n') : 'A/AAAA-записи не найдены';
  } catch (error) { box.textContent = `Ошибка DNS: ${error.message}`; box.classList.add('error'); }
}
async function runHttpCheck() {
  const box = $('#http-result'); const target = $('#http-url').value.trim();
  box.classList.remove('hidden'); box.textContent = 'Проверяем через публичный прокси...';
  try {
    const url = new URL(target.startsWith('http') ? target : `https://${target}`);
    if (['localhost', '127.0.0.1', '0.0.0.0'].includes(url.hostname) || url.hostname.endsWith('.local')) throw new Error('Локальные адреса не поддерживаются');
    const started = performance.now();
    const proxy = `https://api.allorigins.win/get?url=${encodeURIComponent(url.toString())}`;
    const response = await fetchTimed(proxy, { cache: 'no-store' }, 10000);
    const elapsed = Math.round(performance.now() - started);
    if (!response.ok) throw new Error(`Прокси вернул HTTP ${response.status}`);
    const payload = await response.json();
    if (!payload.status) throw new Error('Прокси не вернул статус целевого сайта');
    box.textContent = `HTTP ${payload.status.http_code} • ${elapsed} ms до прокси • ${url.hostname}. Это не гарантирует доступность из каждой сети.`;
  } catch (error) { box.textContent = `Проверка не удалась: ${error.message}`; box.classList.add('error'); }
}
async function runSpeedTest() {
  state.toolBusy = 'speed'; state.toolResult = null; renderMore();
  try {
    const bytes = 8_000_000;
    const url = `https://speed.cloudflare.com/__down?bytes=${bytes}&cb=${Date.now()}`;
    const start = performance.now();
    const response = await fetchTimed(url, { cache: 'no-store' }, 20000);
    if (!response.ok) throw new Error(`Cloudflare ответил HTTP ${response.status}`);
    const data = await response.arrayBuffer();
    const seconds = (performance.now() - start) / 1000;
    const mbps = (data.byteLength * 8 / seconds) / 1_000_000;
    state.toolResult = { tool: 'speed', kind: 'ok', text: `Скорость загрузки: ${mbps.toFixed(1)} Mbps\nПолучено: ${(data.byteLength / 1_000_000).toFixed(2)} MB\nВремя: ${seconds.toFixed(2)} сек.` };
  } catch (error) {
    state.toolResult = { tool: 'speed', kind: 'error', text: `Тест не прошёл: ${error.message}` };
  } finally { state.toolBusy = ''; renderMore(); }
}

function handleAction(action, element) {
  const id = element.dataset.id;
  const server = state.servers.find(s => s.id === id);
  switch (action) {
    case 'add-server': openServerModal(); break;
    case 'refresh-server': if (server) checkServer(server); break;
    case 'check': if (server) checkServer(server); break;
    case 'favorite':
      if (server) { server.favorite = !server.favorite; if (server.favorite) state.servers.forEach(s => { if (s.id !== server.id) s.favorite = false; }); saveServers(); render(); }
      break;
    case 'edit': if (server) openServerModal(server); break;
    case 'delete':
      if (server && confirm(`Удалить сервер «${server.name}»?`)) { state.servers = state.servers.filter(s => s.id !== id); saveServers(); render(); toast('Сервер удалён'); }
      break;
    case 'ping-sample': runPingSeries(); break;
    case 'dns': runDns(); break;
    case 'http': runHttpCheck(); break;
    case 'speed': runSpeedTest(); break;
    case 'clear-history': if (confirm('Очистить историю проверок?')) { state.history = []; saveHistory(); render(); } break;
    case 'export': exportData(); break;
    case 'reset': if (confirm('Сбросить все серверы, историю и настройки?')) { localStorage.removeItem(STORAGE.servers); localStorage.removeItem(STORAGE.history); localStorage.removeItem(STORAGE.settings); location.reload(); } break;
  }
}
function exportData() {
  const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), servers: state.servers, history: state.history, settings: state.settings }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const a = document.createElement('a');
  a.href = url; a.download = `hardpanel-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click();
  URL.revokeObjectURL(url); toast('Экспорт подготовлен');
}

document.addEventListener('click', event => {
  const tab = event.target.closest('[data-tab]');
  if (tab) {
    state.tab = tab.dataset.tab;
    if (tab.dataset.page) state.morePage = tab.dataset.page;
    render(); return;
  }
  const page = event.target.closest('[data-page]');
  if (page) { state.morePage = page.dataset.page; render(); return; }
  const action = event.target.closest('[data-action]');
  if (action) handleAction(action.dataset.action, action);
});
$('#header-refresh').addEventListener('click', refreshAll);
$('#server-form').addEventListener('submit', onServerSubmit);
$('#modal-close').addEventListener('click', closeServerModal);
$('#modal-cancel').addEventListener('click', closeServerModal);
$('#server-modal').addEventListener('click', event => { if (event.target.id === 'server-modal') closeServerModal(); });
window.addEventListener('resize', () => { if (state.tab === 'ping') drawPingChart(); });
window.addEventListener('focus', () => {
  const featured = state.servers.find(s => s.favorite) || state.servers[0];
  if (featured && (!featured.checkedAt || Date.now() - featured.checkedAt > 60_000) && !state.busy.has(featured.id)) checkServer(featured, { silent: true });
});

render();
const startupServer = state.servers.find(s => s.favorite) || state.servers[0];
if (startupServer) setTimeout(() => checkServer(startupServer, { silent: true }), 450);
