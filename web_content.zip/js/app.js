/**
 * College Hostel Management System (CHMS)
 * Clean, Standard, Normal College Website Logic & Handlers
 */

// Global State
let appData = null;
let currentRole = "login"; // 'login', 'landing', 'admin', 'student'
let currentStudentId = 1; // Default logged in student (Rahul Sharma)
let loggedInUser = null;
let currentAdminTab = "dashboard";
let currentStudentTab = "dashboard";
let activeLoginRole = "admin";

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  loadData();
  setupEventListeners();
  renderApp();
});

// =========================================================
// DATA & LOCALSTORAGE
// =========================================================
function loadData() {
  const DATA_VERSION = "2026.11.11.100rooms.60students";
  const storedVersion = localStorage.getItem("CHMS_DATA_VERSION");
  const stored = localStorage.getItem("CHMS_DATA_STORE");

  if (stored && storedVersion === DATA_VERSION) {
    try {
      appData = JSON.parse(stored);
      if (!appData.rooms || appData.rooms.length < 100 || !appData.students || appData.students.length < 60) {
        appData = JSON.parse(JSON.stringify(DEFAULT_DATA));
        saveData();
      }
    } catch (e) {
      console.error("Error reading localStorage, resetting to default", e);
      appData = JSON.parse(JSON.stringify(DEFAULT_DATA));
      saveData();
    }
  } else {
    // Initialize fresh store with 100 rooms across 5 floors and 60 students (25 girls, 35 boys)
    appData = JSON.parse(JSON.stringify(DEFAULT_DATA));
    localStorage.setItem("CHMS_DATA_VERSION", DATA_VERSION);
    saveData();
  }
}

function saveData() {
  localStorage.setItem("CHMS_DATA_STORE", JSON.stringify(appData));
}

function resetAllData() {
  if (confirm("Are you sure you want to reset all demo data to default settings?")) {
    appData = JSON.parse(JSON.stringify(DEFAULT_DATA));
    saveData();
    showToast("All demo data has been reset to default values.", "info");
    renderApp();
  }
}

// =========================================================
// THEME (DARK / LIGHT MODE)
// =========================================================
function initTheme() {
  const savedTheme = localStorage.getItem("CHMS_THEME") || "light";
  document.documentElement.setAttribute("data-theme", savedTheme);
  updateThemeIcon(savedTheme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute("data-theme") || "light";
  const newTheme = current === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("CHMS_THEME", newTheme);
  updateThemeIcon(newTheme);
  renderDonutChart();
  renderReportsCharts();
}

function updateThemeIcon(theme) {
  const btn = document.getElementById("theme-toggle-btn");
  if (btn) {
    btn.innerHTML = theme === "dark" ? "☀️" : "🌙";
    btn.setAttribute("title", theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode");
    btn.setAttribute("aria-label", theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode");
  }
}

// =========================================================
// CLEAN NORMAL LOGIN
// =========================================================
function setLoginRoleTab(role) {
  activeLoginRole = role;
  document.querySelectorAll(".login-tab-item").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.role === role);
  });

  const usernameLabel = document.getElementById("login-username-label");
  const usernameInput = document.getElementById("login-username");
  const passwordInput = document.getElementById("login-password");
  const formTitle = document.getElementById("login-form-title");
  const formSubtitle = document.getElementById("login-form-subtitle");
  const submitBtnText = document.getElementById("login-submit-text");

  if (role === "admin") {
    if (formTitle) formTitle.textContent = "Warden Login";
    if (formSubtitle) formSubtitle.textContent = "Hostel administration & management access";
    if (submitBtnText) submitBtnText.textContent = "Sign In as Warden";
    if (usernameLabel) usernameLabel.textContent = "Warden Username";
    if (usernameInput) {
      usernameInput.placeholder = "Enter 'admin' or 'warden'";
      usernameInput.value = "admin";
    }
    if (passwordInput) passwordInput.value = "admin123";
  } else {
    if (formTitle) formTitle.textContent = "Student Login";
    if (formSubtitle) formSubtitle.textContent = "Resident student account access";
    if (submitBtnText) submitBtnText.textContent = "Sign In as Student";
    if (usernameLabel) usernameLabel.textContent = "Student Roll Number";
    if (usernameInput) {
      usernameInput.placeholder = "e.g. CS2024-001";
      usernameInput.value = "CS2024-001";
    }
    if (passwordInput) passwordInput.value = "student123";
  }
}

function quickFillCredentials(role) {
  setLoginRoleTab(role);
  if (role === "admin") {
    document.getElementById("login-username").value = "admin";
    document.getElementById("login-password").value = "admin123";
    showToast("Filled demo credentials for Warden (admin / admin123).", "info");
  } else {
    document.getElementById("login-username").value = "CS2024-001";
    document.getElementById("login-password").value = "student123";
    showToast("Filled demo credentials for Student (CS2024-001 / student123).", "info");
  }
}

function togglePasswordVisibility() {
  const pwdInput = document.getElementById("login-password");
  const icon = document.getElementById("password-toggle-icon");
  if (!pwdInput) return;
  if (pwdInput.type === "password") {
    pwdInput.type = "text";
    if (icon) icon.textContent = "🙈";
  } else {
    pwdInput.type = "password";
    if (icon) icon.textContent = "👁️";
  }
}

function handleLoginSubmit(e) {
  e.preventDefault();
  const username = document.getElementById("login-username").value.trim();
  const password = document.getElementById("login-password").value.trim();

  if (!username || !password) {
    showToast("Please enter both username and password to proceed.", "warning");
    return;
  }

  if (activeLoginRole === "admin") {
    if (username.toLowerCase() === "admin" || username.toLowerCase() === "warden") {
      loggedInUser = {
        name: "Dr. Ramesh Kumar (Warden)",
        role: "admin",
        designation: "Hostel Warden"
      };
      showToast(`Welcome back, ${loggedInUser.name}!`, "success");
      switchRole("admin");
    } else {
      showToast("Invalid warden username. Please enter 'admin' or 'warden'.", "error");
    }
  } else {
    const student = appData.students.find(s => s.rollNumber.toLowerCase() === username.toLowerCase());
    if (student) {
      currentStudentId = student.id;
      loggedInUser = {
        name: student.name,
        role: "student",
        rollNumber: student.rollNumber,
        designation: `${student.course} - ${student.branch}`
      };
      showToast(`Welcome back, ${student.name}!`, "success");
      switchRole("student");
    } else {
      showToast(`Roll number "${username}" was not found. Please try "CS2024-001".`, "error");
    }
  }
}

function handleLogout() {
  loggedInUser = null;
  switchRole("login");
  showToast("You have been logged out successfully.", "info");
}

// =========================================================
// NAVIGATION & VIEW SWITCHING
// =========================================================
function switchRole(role) {
  currentRole = role;

  const loginView = document.getElementById("login-view");
  const adminView = document.getElementById("admin-portal-view");
  const studentView = document.getElementById("student-portal-view");
  const navbar = document.querySelector(".navbar");
  const tail = document.querySelector(".app-tail");
  const rolePill = document.getElementById("navbar-role-pill");

  if (loginView) loginView.style.display = role === "login" ? "flex" : "none";
  if (adminView) adminView.style.display = role === "admin" ? "flex" : "none";
  if (studentView) studentView.style.display = role === "student" ? "flex" : "none";

  if (role === "login") {
    if (navbar) navbar.style.display = "none";
    if (tail) tail.style.display = "none";
  } else {
    if (navbar) navbar.style.display = "flex";
    if (tail) tail.style.display = "block";
  }

  if (rolePill) {
    rolePill.textContent = role === "admin" ? "Warden Portal" : "Student Portal";
  }

  updateNavbarUserBadge();

  if (role === "admin") {
    switchAdminTab(currentAdminTab);
  } else if (role === "student") {
    switchStudentTab(currentStudentTab);
  }
}

function updateNavbarUserBadge() {
  const badgeContainer = document.getElementById("navbar-user-badge");
  if (!badgeContainer) return;

  if (currentRole === "admin") {
    badgeContainer.innerHTML = `
      <div class="user-info-pill">
        <div class="pill-details">
          <strong>${loggedInUser ? loggedInUser.name : "Warden"}</strong>
          <small>Hostel Warden</small>
        </div>
      </div>
    `;
  } else if (currentRole === "student") {
    const student = getStudent(currentStudentId);
    badgeContainer.innerHTML = `
      <div class="user-info-pill">
        <div class="pill-details">
          <strong>${student ? student.name : "Student"}</strong>
          <small>${student ? student.rollNumber : ""}</small>
        </div>
      </div>
    `;
  } else {
    badgeContainer.innerHTML = "";
  }
}

function switchAdminTab(tabName) {
  closeMobileSidebar();
  currentAdminTab = tabName;
  document.querySelectorAll("#admin-sidebar .nav-item").forEach(item => {
    item.classList.toggle("active", item.dataset.tab === tabName);
  });
  document.querySelectorAll("#admin-portal-view .tab-pane").forEach(pane => {
    pane.style.display = pane.id === `tab-${tabName}` ? "block" : "none";
  });

  if (tabName === "dashboard") renderAdminDashboard();
  if (tabName === "rooms") renderRoomsGrid();
  if (tabName === "allocation") renderAllocationTab();
  if (tabName === "students") renderStudentsTable();
  if (tabName === "fees") renderFeesTab();
  if (tabName === "complaints") renderAdminComplaints();
  if (tabName === "leaves") renderAdminLeaves();
  if (tabName === "visitors") renderVisitorsTab();
  if (tabName === "notices") renderNoticesTab();
  if (tabName === "reports") renderReportsTab();
}

function switchStudentTab(tabName) {
  closeMobileSidebar();
  currentStudentTab = tabName;
  document.querySelectorAll("#student-sidebar .nav-item").forEach(item => {
    item.classList.toggle("active", item.dataset.tab === tabName);
  });
  document.querySelectorAll("#student-portal-view .tab-pane").forEach(pane => {
    pane.style.display = pane.id === `student-tab-${tabName}` ? "block" : "none";
  });

  if (tabName === "dashboard") renderStudentDashboard();
  if (tabName === "room") renderStudentMyRoom();
  if (tabName === "fees") renderStudentFees();
  if (tabName === "complaints") renderStudentComplaints();
  if (tabName === "leaves") renderStudentLeaves();
  if (tabName === "mess") renderStudentMess();
  if (tabName === "contacts") renderEmergencyContacts();
}

// =========================================================
// SLIDING EXPLORER (SIDEBAR) CONTROLS
// =========================================================
function toggleSidebar() {
  const activeSidebar = currentRole === "admin"
    ? document.getElementById("admin-sidebar")
    : document.getElementById("student-sidebar");
  const backdrop = document.getElementById("sidebar-backdrop");
  if (!activeSidebar) return;

  if (window.innerWidth <= 992) {
    const isOpen = activeSidebar.classList.toggle("sidebar-open");
    if (backdrop) backdrop.style.display = isOpen ? "block" : "none";
  } else {
    activeSidebar.classList.toggle("sidebar-collapsed");
  }
}

function closeMobileSidebar() {
  const adminSidebar = document.getElementById("admin-sidebar");
  const studentSidebar = document.getElementById("student-sidebar");
  const backdrop = document.getElementById("sidebar-backdrop");
  if (adminSidebar) adminSidebar.classList.remove("sidebar-open");
  if (studentSidebar) studentSidebar.classList.remove("sidebar-open");
  if (backdrop) backdrop.style.display = "none";
}

// =========================================================
// EVENT LISTENERS SETUP
// =========================================================
function setupEventListeners() {
  const themeBtn = document.getElementById("theme-toggle-btn");
  if (themeBtn) themeBtn.addEventListener("click", toggleTheme);

  const loginForm = document.getElementById("login-form");
  if (loginForm) loginForm.addEventListener("submit", handleLoginSubmit);

  document.querySelectorAll(".role-tab-btn").forEach(btn => {
    btn.addEventListener("click", () => switchRole(btn.dataset.role));
  });

  document.querySelectorAll("#admin-sidebar .nav-item").forEach(item => {
    item.addEventListener("click", (e) => {
      e.preventDefault();
      switchAdminTab(item.dataset.tab);
    });
  });

  document.querySelectorAll("#student-sidebar .nav-item").forEach(item => {
    item.addEventListener("click", (e) => {
      e.preventDefault();
      switchStudentTab(item.dataset.tab);
    });
  });

  const studentSelector = document.getElementById("student-user-select");
  if (studentSelector) {
    studentSelector.addEventListener("change", (e) => {
      currentStudentId = parseInt(e.target.value);
      updateNavbarUserBadge();
      if (currentRole === "student") {
        switchStudentTab(currentStudentTab);
      }
      showToast(`Switched profile to ${getStudent(currentStudentId)?.name}`, "info");
    });
  }

  const roomTypeSelect = document.getElementById("new-room-type");
  const roomCapacityInput = document.getElementById("new-room-capacity");
  if (roomTypeSelect && roomCapacityInput) {
    roomTypeSelect.addEventListener("change", (e) => {
      const type = e.target.value;
      if (type === "Single") roomCapacityInput.value = 1;
      else if (type === "Double") roomCapacityInput.value = 2;
      else if (type === "Triple") roomCapacityInput.value = 3;
    });
  }

  setupSearch("students-search", "students-table-body");
  setupSearch("fees-search", "fees-table-body");
  setupSearch("visitors-search", "visitors-table-body");
  setupSearch("complaints-search", "admin-complaints-table-body");
  setupSearch("leaves-search", "admin-leaves-table-body");

  window.addEventListener("resize", () => {
    if (window.innerWidth > 992) {
      closeMobileSidebar();
    }
  });
}

function setupSearch(inputId, tableBodyId) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener("input", (e) => {
    const term = e.target.value.toLowerCase().trim();
    const rows = document.querySelectorAll(`#${tableBodyId} tr`);
    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(term) ? "" : "none";
    });
  });
}

function renderApp() {
  populateStudentSelectOptions();
  switchRole(currentRole);
}

function populateStudentSelectOptions() {
  const sel = document.getElementById("student-user-select");
  if (!sel) return;
  sel.innerHTML = appData.students.map(s => `
    <option value="${s.id}" ${s.id === currentStudentId ? "selected" : ""}>
      ${s.name} (${s.rollNumber})
    </option>
  `).join("");
}

// Helpers
function getStudent(id) {
  return appData.students.find(s => s.id === id);
}

function getRoom(id) {
  return appData.rooms.find(r => r.id === id);
}

function getRoomAllocations(roomId) {
  return appData.allocations.filter(a => a.roomId === roomId);
}

function getStudentAllocation(studentId) {
  return appData.allocations.find(a => a.studentId === studentId);
}

function getRoomStatus(roomId) {
  const room = getRoom(roomId);
  if (!room) return "Unknown";
  const occ = getRoomAllocations(roomId).length;
  if (occ === 0) return "Available";
  if (occ >= room.capacity) return "Occupied";
  return "Partially Occupied";
}

// =========================================================
// 1. ADMIN DASHBOARD
// =========================================================
function renderAdminDashboard() {
  const totalStudents = appData.students.length;
  const boysCount = appData.students.filter(s => s.gender === "Male").length;
  const girlsCount = appData.students.filter(s => s.gender === "Female").length;
  const totalRooms = appData.rooms.length;
  const totalBeds = appData.rooms.reduce((acc, r) => acc + r.capacity, 0);
  const occupiedBeds = appData.allocations.length;
  const availableBeds = totalBeds - occupiedBeds;
  const pendingComplaints = appData.complaints.filter(c => c.status === "Open" || c.status === "In Progress").length;
  const pendingLeaves = appData.leaves.filter(l => l.status === "Pending").length;

  document.getElementById("stat-total-students").textContent = totalStudents;
  const breakdownEl = document.getElementById("stat-students-breakdown");
  if (breakdownEl) breakdownEl.innerHTML = `<strong>${boysCount}</strong> Boys &bull; <strong>${girlsCount}</strong> Girls`;

  document.getElementById("stat-total-rooms").textContent = totalRooms;
  document.getElementById("stat-occupied-beds").textContent = `${occupiedBeds} / ${totalBeds}`;
  document.getElementById("stat-pending-complaints").textContent = pendingComplaints;
  document.getElementById("stat-pending-leaves").textContent = pendingLeaves;

  renderDonutChart(occupiedBeds, availableBeds);

  const recentComplaints = [...appData.complaints].reverse().slice(0, 5);
  const listEl = document.getElementById("dashboard-recent-complaints");
  if (listEl) {
    if (recentComplaints.length === 0) {
      listEl.innerHTML = `<p style="text-align:center; padding:15px; color:var(--text-muted);">No complaints recorded yet.</p>`;
    } else {
      listEl.innerHTML = recentComplaints.map(c => {
        const student = getStudent(c.studentId);
        return `
          <div style="display:flex; align-items:center; justify-content:space-between; padding:10px 12px; background:var(--bg-body); border:1px solid var(--border-light); border-radius:var(--radius-sm); margin-bottom:8px;">
            <div>
              <div style="font-weight:600; font-size:0.88rem;">${c.title}</div>
              <small style="color:var(--text-muted);">${student ? student.name : "Resident"} &bull; <span class="badge badge-${c.category.toLowerCase()}" style="font-size:0.7rem; padding:2px 8px;">${c.category}</span> &bull; ${c.date}</small>
            </div>
            <span class="badge badge-${c.status.toLowerCase().replace(" ", "-")}">${c.status}</span>
          </div>
        `;
      }).join("");
    }
  }
}

// Pure SVG Donut Chart
function renderDonutChart(occupied, available) {
  const container = document.getElementById("donut-chart-svg-container");
  if (!container) return;

  if (occupied === undefined || available === undefined) {
    const totalBeds = appData.rooms.reduce((acc, r) => acc + r.capacity, 0);
    occupied = appData.allocations.length;
    available = Math.max(0, totalBeds - occupied);
  }
  const total = occupied + available;
  const occPct = total > 0 ? (occupied / total) * 100 : 0;
  const availPct = total > 0 ? (available / total) * 100 : 0;

  const circumference = 314.16;
  const strokeDashoffset = circumference - (occPct / 100) * circumference;

  container.innerHTML = `
    <div style="position: relative; width: 150px; height: 150px;">
      <svg width="150" height="150" viewBox="0 0 140 140" style="transform: rotate(-90deg);">
        <circle cx="70" cy="70" r="50" fill="transparent" stroke="#16a34a" stroke-width="16"></circle>
        <circle cx="70" cy="70" r="50" fill="transparent" stroke="#dc2626" stroke-width="16"
                stroke-dasharray="${circumference}" stroke-dashoffset="${strokeDashoffset}"
                style="transition: stroke-dashoffset 0.6s ease;"></circle>
      </svg>
      <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
        <span style="font-size: 1.5rem; font-weight: 700;">${Math.round(occPct)}%</span>
        <div style="font-size: 0.7rem; color: var(--text-muted); font-weight: 600;">OCCUPIED</div>
      </div>
    </div>
    <div style="display:flex; flex-direction:column; gap:10px;">
      <div style="display:flex; align-items:center; gap:8px; font-size:0.88rem;">
        <span style="width:12px; height:12px; border-radius:3px; background:#dc2626;"></span>
        <span>Occupied Beds: <strong>${occupied}</strong> (${Math.round(occPct)}%)</span>
      </div>
      <div style="display:flex; align-items:center; gap:8px; font-size:0.88rem;">
        <span style="width:12px; height:12px; border-radius:3px; background:#16a34a;"></span>
        <span>Available Beds: <strong>${available}</strong> (${Math.round(availPct)}%)</span>
      </div>
      <div style="display:flex; align-items:center; gap:8px; font-size:0.88rem;">
        <span style="width:12px; height:12px; border-radius:3px; background:#2563eb;"></span>
        <span>Total Capacity: <strong>${total} Beds</strong></span>
      </div>
    </div>
  `;
}

// =========================================================
// 2. ROOMS MANAGEMENT
// =========================================================
function renderRoomsGrid() {
  const container = document.getElementById("rooms-grid-container");
  if (!container) return;

  const blockFilter = document.getElementById("rooms-block-filter")?.value || "all";
  const acFilter = document.getElementById("rooms-ac-filter")?.value || "all";
  const floorFilter = document.getElementById("rooms-floor-filter")?.value || "all";
  const statusFilter = document.getElementById("rooms-status-filter")?.value || "all";

  let filtered = appData.rooms.filter(room => {
    const status = getRoomStatus(room.id);
    if (blockFilter !== "all" && room.block !== blockFilter) return false;
    if (acFilter !== "all" && (room.acType || "Non-AC") !== acFilter) return false;
    if (floorFilter !== "all" && room.floor !== parseInt(floorFilter)) return false;
    if (statusFilter !== "all" && status !== statusFilter) return false;
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted);">No rooms match the selected filters.</div>`;
    return;
  }

  container.innerHTML = filtered.map(room => {
    const allocs = getRoomAllocations(room.id);
    const status = getRoomStatus(room.id);

    let badgeClass = "badge-available";
    if (status === "Occupied") badgeClass = "badge-occupied";
    else if (status === "Partially Occupied") badgeClass = "badge-partial";

    let bedSlotsHtml = "";
    for (let i = 1; i <= room.capacity; i++) {
      const alloc = allocs.find(a => a.bedNumber === i);
      if (alloc) {
        const student = getStudent(alloc.studentId);
        bedSlotsHtml += `
          <div class="bed-row-clean occupied">
            <span><strong>Bed ${i}:</strong> ${student ? student.name : "Occupied"}</span>
            <button class="btn btn-sm btn-outline" style="padding: 2px 6px; font-size: 0.72rem; color: var(--danger);" 
                    onclick="vacateStudentAllocation(${alloc.id}, '${student ? escapeHtml(student.name) : "Student"}', '${room.roomNumber}')" title="Vacate Bed">
              Vacate
            </button>
          </div>
        `;
      } else {
        bedSlotsHtml += `
          <div class="bed-row-clean vacant">
            <span><strong>Bed ${i}:</strong> <span style="color:var(--success);">Vacant</span></span>
            <button class="btn btn-sm btn-primary" style="padding: 2px 8px; font-size: 0.72rem;" 
                    onclick="openAllotModalForRoom(${room.id}, ${i})">
              + Allot
            </button>
          </div>
        `;
      }
    }

    return `
      <div class="room-card-clean">
        <div>
          <div class="room-header-row">
            <div class="room-title-clean">
              Room ${room.roomNumber}
            </div>
            <span class="badge ${badgeClass}">${status}</span>
          </div>
          <div class="room-submeta">
            <span class="badge ${room.acType === 'AC' ? 'badge-ac' : 'badge-non-ac'}" style="font-size:0.75rem; padding:2px 7px;">
              ${room.acType || 'Non-AC'}
            </span>
            <span>${room.block}</span>
            <span>Floor ${room.floor}</span>
            <span>${room.roomType}</span>
          </div>
          <div class="bed-list-clean">
            ${bedSlotsHtml}
          </div>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border-light); padding-top:10px; font-size:0.84rem; color:var(--text-muted);">
          <span><strong>₹${room.rent.toLocaleString()}</strong>/month</span>
          <span>${allocs.length} / ${room.capacity} Beds Booked</span>
        </div>
      </div>
    `;
  }).join("");
}

function handleAddRoomSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const roomNumber = form.roomNumber.value.trim();
  const block = form.block.value;
  const floor = parseInt(form.floor.value);
  const roomType = form.roomType.value;
  const capacity = parseInt(form.capacity.value);
  const rent = parseFloat(form.rent.value) || 4000;
  const acType = form.acType ? form.acType.value : "Non-AC";
  const genderType = (block && block.toLowerCase().includes("c-block")) ? "Girls" : "Boys";

  if (!roomNumber) {
    showToast("Please enter a valid room number.", "warning");
    return;
  }

  if (appData.rooms.some(r => r.roomNumber.toLowerCase() === roomNumber.toLowerCase())) {
    showToast(`Room "${roomNumber}" already exists in the system.`, "error");
    return;
  }

  const newId = appData.rooms.length > 0 ? Math.max(...appData.rooms.map(r => r.id)) + 1 : 1;
  appData.rooms.push({
    id: newId,
    roomNumber,
    block,
    floor,
    roomType,
    capacity,
    rent,
    acType,
    genderType
  });

  saveData();
  renderRoomsGrid();
  closeModal("add-room-modal");
  form.reset();
  showToast(`Room ${roomNumber} (${block}, ${acType}, ${roomType}) created successfully.`, "success");
}

// =========================================================
// 3. ROOM ALLOCATION (GENDER-SEGREGATED)
// =========================================================
function renderAllocationTab() {
  populateAllocationDropdowns();
  renderActiveAllocationsTable();
}

function populateAllocationDropdowns() {
  const studentSelect = document.getElementById("alloc-student-select");
  const roomSelect = document.getElementById("alloc-room-select");
  const bedSelect = document.getElementById("alloc-bed-select");

  if (studentSelect) {
    const unallocated = appData.students.filter(s => !getStudentAllocation(s.id));
    if (unallocated.length === 0) {
      studentSelect.innerHTML = `<option value="">-- All students are already allocated --</option>`;
      if (roomSelect) roomSelect.innerHTML = `<option value="">-- No unallocated students --</option>`;
      if (bedSelect) bedSelect.innerHTML = `<option value="">-- Choose room first --</option>`;
    } else {
      studentSelect.innerHTML = `<option value="">-- Select Unallocated Student --</option>` + unallocated.map(s => `
        <option value="${s.id}">${s.name} (${s.rollNumber}) - ${s.course} ${s.branch}</option>
      `).join("");

      studentSelect.onchange = (e) => {
        const studentId = parseInt(e.target.value);
        updateRoomSelectForStudent(studentId);
      };
    }
  }

  // Set initial state for room select
  updateRoomSelectForStudent(studentSelect ? parseInt(studentSelect.value) : null);
}

function updateRoomSelectForStudent(studentId) {
  const roomSelect = document.getElementById("alloc-room-select");
  const bedSelect = document.getElementById("alloc-bed-select");
  if (!roomSelect) return;

  if (bedSelect) bedSelect.innerHTML = `<option value="">-- Choose room first --</option>`;

  if (!studentId) {
    roomSelect.innerHTML = `<option value="">-- Choose student first --</option>`;
    return;
  }

  const student = getStudent(studentId);
  if (!student) {
    roomSelect.innerHTML = `<option value="">-- Select Room --</option>`;
    return;
  }

  roomSelect.innerHTML = `<option value="">-- Select Room --</option>` + appData.rooms.map(r => {
    const occ = getRoomAllocations(r.id).length;
    const isFull = occ >= r.capacity;
    const label = `${r.roomNumber} (${r.block}, Floor ${r.floor}) - ${r.acType || 'Non-AC'} - ${occ}/${r.capacity} Beds ${isFull ? '[FULL]' : ''}`;
    return `<option value="${r.id}" ${isFull ? 'disabled style="color:var(--danger);"' : ''}>${label}</option>`;
  }).join("");

  roomSelect.onchange = (e) => {
    updateBedSelectForRoom(parseInt(e.target.value));
  };
}

function updateBedSelectForRoom(roomId) {
  const bedSelect = document.getElementById("alloc-bed-select");
  if (!bedSelect) return;
  if (!roomId) {
    bedSelect.innerHTML = `<option value="">-- Choose room first --</option>`;
    return;
  }
  const room = getRoom(roomId);
  const allocs = getRoomAllocations(roomId);
  let options = `<option value="">-- Select Bed --</option>`;
  for (let i = 1; i <= room.capacity; i++) {
    const taken = allocs.some(a => a.bedNumber === i);
    options += `<option value="${i}" ${taken ? 'disabled style="color:var(--danger);"' : ''}>Bed ${i} ${taken ? '(Booked)' : '(Available)'}</option>`;
  }
  bedSelect.innerHTML = options;
}

function handleAllocateSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const studentId = parseInt(form.studentId.value);
  const roomId = parseInt(form.roomId.value);
  const bedNumber = parseInt(form.bedNumber.value);

  if (!studentId || !roomId || !bedNumber) {
    showToast("Please select a student, room, and bed number.", "warning");
    return;
  }

  const student = getStudent(studentId);
  const room = getRoom(roomId);

  if (!student || !room) {
    showToast("Invalid student or room selection.", "error");
    return;
  }

  // 1. Strict Gender / Hostel Wing Check
  const expectedWing = student.gender === "Female" ? "Girls" : "Boys";
  const roomWing = room.genderType || (room.block && room.block.toLowerCase().includes("c-block") ? "Girls" : "Boys");

  if (expectedWing !== roomWing) {
    if (student.gender === "Female") {
      showToast(`Allocation Denied: Female student "${student.name}" can only be allocated to Girls Hostel (Block C).`, "error");
    } else {
      showToast(`Allocation Denied: Male student "${student.name}" can only be allocated to Boys Hostel (Block A & Block B).`, "error");
    }
    return;
  }

  // 2. Strict Check for existing occupants in room (No mixed genders allowed)
  const currentAllocs = getRoomAllocations(roomId);
  for (const a of currentAllocs) {
    const occStudent = getStudent(a.studentId);
    if (occStudent && occStudent.gender !== student.gender) {
      showToast(`Allocation Denied: Room ${room.roomNumber} already has ${occStudent.gender} resident (${occStudent.name}). Mixed-gender rooms are strictly forbidden.`, "error");
      return;
    }
  }

  if (currentAllocs.length >= room.capacity) {
    showToast(`Room ${room.roomNumber} is currently at full capacity.`, "error");
    return;
  }

  if (currentAllocs.some(a => a.bedNumber === bedNumber)) {
    showToast(`Bed ${bedNumber} is already occupied in Room ${room.roomNumber}.`, "error");
    return;
  }

  if (getStudentAllocation(studentId)) {
    showToast("This student already has an active room allocation.", "error");
    return;
  }

  const newId = appData.allocations.length > 0 ? Math.max(...appData.allocations.map(a => a.id)) + 1 : 1;
  const today = new Date().toISOString().split("T")[0];
  appData.allocations.push({
    id: newId,
    roomId,
    studentId,
    bedNumber,
    date: today
  });

  saveData();
  renderAllocationTab();
  renderRoomsGrid();
  renderAdminDashboard();
  form.reset();
  showToast(`Room ${room.roomNumber} (Bed ${bedNumber}) successfully allocated to ${student.name}.`, "success");
}

function renderActiveAllocationsTable() {
  const tbody = document.getElementById("allocations-table-body");
  if (!tbody) return;

  if (appData.allocations.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);">No active allocations. Select a student and room above to allot.</td></tr>`;
    return;
  }

  tbody.innerHTML = appData.allocations.map(a => {
    const student = getStudent(a.studentId);
    const room = getRoom(a.roomId);
    if (!student || !room) return "";

    return `
      <tr>
        <td><strong>${room.roomNumber}</strong> <span style="font-size:0.75rem; color:var(--text-muted);">(${room.block})</span></td>
        <td>Bed ${a.bedNumber}</td>
        <td>
          <div style="font-weight:600;">${student.name}</div>
          <small style="color:var(--text-muted);">${student.rollNumber}</small>
        </td>
        <td>${student.course} - ${student.branch}</td>
        <td>${student.phone}</td>
        <td>${a.date}</td>
        <td>
          <button class="btn btn-sm btn-danger" onclick="vacateStudentAllocation(${a.id}, '${escapeHtml(student.name)}', '${room.roomNumber}')">
            Vacate
          </button>
        </td>
      </tr>
    `;
  }).join("");
}

function openAllotModalForRoom(roomId, bedNumber) {
  switchAdminTab("allocation");
  const room = getRoom(roomId);
  if (!room) return;

  const roomSelect = document.getElementById("alloc-room-select");
  if (roomSelect) {
    roomSelect.value = roomId;
    updateBedSelectForRoom(roomId);
    const bedSelect = document.getElementById("alloc-bed-select");
    if (bedSelect) bedSelect.value = bedNumber;
  }
}

// =========================================================
// 4. STUDENTS MANAGEMENT
// =========================================================
function renderStudentsTable() {
  const tbody = document.getElementById("students-table-body");
  if (!tbody) return;

  const query = document.getElementById("students-search")?.value.toLowerCase().trim() || "";

  let list = appData.students.filter(s => {
    if (query) {
      const text = `${s.name} ${s.rollNumber} ${s.course} ${s.branch} ${s.phone}`.toLowerCase();
      if (!text.includes(query)) return false;
    }
    return true;
  });

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);">No student records found in hostel database.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(s => {
    const alloc = getStudentAllocation(s.id);
    let roomInfo = `<span class="badge badge-available">Not Allotted</span>`;
    if (alloc) {
      const room = getRoom(alloc.roomId);
      roomInfo = `<span class="badge badge-occupied">Room ${room ? room.roomNumber : "?"} (Bed ${alloc.bedNumber})</span>`;
    }

    return `
      <tr>
        <td><strong>${s.rollNumber}</strong></td>
        <td>
          <div style="font-weight:600;">${s.name}</div>
          <small style="color:var(--text-muted);">${s.email || "No email"}</small>
        </td>
        <td>${s.course} - ${s.branch} (Yr ${s.year})</td>
        <td>${s.phone}</td>
        <td>${roomInfo}</td>
        <td>
          <div style="font-size:0.8rem;">
            <strong>${s.guardianName || "-"}</strong><br>
            <span style="color:var(--text-muted);">${s.guardianPhone || ""}</span>
          </div>
        </td>
        <td>
          <button class="btn btn-sm btn-danger" onclick="confirmDeleteStudent(${s.id}, '${escapeHtml(s.name)}')">
            Delete
          </button>
        </td>
      </tr>
    `;
  }).join("");
}

function handleAddStudentSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const roll = form.rollNumber.value.trim();
  const name = form.name.value.trim();
  const phone = form.phone.value.trim();
  const course = form.course.value.trim();
  const branch = form.branch.value.trim();
  const year = parseInt(form.year.value);
  const email = form.email.value.trim();
  const guardianName = form.guardianName.value.trim();
  const guardianPhone = form.guardianPhone.value.trim();
  const address = form.address.value.trim();

  if (!roll || !name || !phone || !course || !branch) {
    showToast("Please fill all required student basic fields.", "warning");
    return;
  }

  if (!guardianName) {
    showToast("Father / Guardian Name is compulsory.", "warning");
    return;
  }

  if (!guardianPhone) {
    showToast("Guardian Phone Number is compulsory.", "warning");
    return;
  }

  if (!address) {
    showToast("Permanent Residential Address is compulsory.", "warning");
    return;
  }

  const phoneRegex = /^[0-9]{10}$/;
  if (!phoneRegex.test(phone)) {
    showToast("Student mobile number must be exactly 10 digits.", "warning");
    return;
  }

  if (!phoneRegex.test(guardianPhone)) {
    showToast("Guardian phone number must be exactly 10 digits.", "warning");
    return;
  }

  if (appData.students.some(s => s.rollNumber.toLowerCase() === roll.toLowerCase())) {
    showToast(`Student roll number "${roll}" is already registered.`, "error");
    return;
  }

  const newId = appData.students.length > 0 ? Math.max(...appData.students.map(r => r.id)) + 1 : 1;
  const newStudent = {
    id: newId,
    rollNumber: roll,
    name,
    email,
    phone,
    course,
    branch,
    year,
    gender: form.gender.value,
    guardianName,
    guardianPhone,
    address
  };

  appData.students.push(newStudent);
  appData.fees.push({
    studentId: newId,
    total: 48000,
    paid: 0,
    due: 48000,
    status: "Due",
    lastDate: null
  });

  saveData();
  populateStudentSelectOptions();
  renderStudentsTable();
  closeModal("add-student-modal");
  form.reset();
  showToast(`Student "${name}" registered successfully.`, "success");
}

function confirmDeleteStudent(studentId, studentName) {
  if (confirm(`Are you sure you want to delete student "${studentName}"?\nTheir room allocation and associated records will be permanently removed.`)) {
    appData.students = appData.students.filter(s => s.id !== studentId);
    appData.allocations = appData.allocations.filter(a => a.studentId !== studentId);
    appData.fees = appData.fees.filter(f => f.studentId !== studentId);
    appData.complaints = appData.complaints.filter(c => c.studentId !== studentId);
    appData.leaves = appData.leaves.filter(l => l.studentId !== studentId);

    saveData();
    populateStudentSelectOptions();
    renderStudentsTable();
    showToast(`Student record for "${studentName}" deleted successfully.`, "info");
  }
}

// =========================================================
// 5. FEES MANAGEMENT & OFFICIAL RECEIPT PRINTING
// =========================================================
function renderFeesTab() {
  const totalFeesExpected = appData.fees.reduce((acc, f) => acc + f.total, 0);
  const totalPaid = appData.fees.reduce((acc, f) => acc + f.paid, 0);
  const totalDue = appData.fees.reduce((acc, f) => acc + f.due, 0);

  document.getElementById("fee-stat-total").textContent = `₹${totalFeesExpected.toLocaleString()}`;
  document.getElementById("fee-stat-paid").textContent = `₹${totalPaid.toLocaleString()}`;
  document.getElementById("fee-stat-due").textContent = `₹${totalDue.toLocaleString()}`;

  renderFeesTable();
  populateFeePaymentModalStudentSelect();
}

function renderFeesTable() {
  const tbody = document.getElementById("fees-table-body");
  if (!tbody) return;

  tbody.innerHTML = appData.fees.map(f => {
    const student = getStudent(f.studentId);
    if (!student) return "";

    let badge = "badge-approved";
    if (f.status === "Due") badge = "badge-rejected";
    else if (f.status === "Partial") badge = "badge-pending";

    const payments = appData.feePayments.filter(p => p.studentId === f.studentId);
    const latestPayment = payments.length > 0 ? payments[payments.length - 1] : null;

    return `
      <tr>
        <td><strong>${student.rollNumber}</strong></td>
        <td>${student.name}</td>
        <td>₹${f.total.toLocaleString()}</td>
        <td style="color:var(--success); font-weight:600;">₹${f.paid.toLocaleString()}</td>
        <td style="color:var(--danger); font-weight:600;">₹${f.due.toLocaleString()}</td>
        <td><span class="badge ${badge}">${f.status}</span></td>
        <td>${f.lastDate || "No Payment"}</td>
        <td>
          <div style="display:flex; gap:6px;">
            ${f.due > 0 ? `
              <button class="btn btn-sm btn-primary" onclick="openAddPaymentModal(${f.studentId})">
                + Pay
              </button>
            ` : ""}
            ${latestPayment ? `
              <button class="btn btn-sm btn-outline" onclick="printFeeReceipt('${latestPayment.receiptNo}')">
                Receipt
              </button>
            ` : ""}
          </div>
        </td>
      </tr>
    `;
  }).join("");
}

function populateFeePaymentModalStudentSelect() {
  const sel = document.getElementById("payment-student-select");
  if (!sel) return;
  sel.innerHTML = `<option value="">-- Select Student --</option>` + appData.students.map(s => {
    const f = appData.fees.find(x => x.studentId === s.id);
    const due = f ? f.due : 0;
    return `<option value="${s.id}">${s.name} (${s.rollNumber}) - Due: ₹${due}</option>`;
  }).join("");
}

function openAddPaymentModal(studentId) {
  const sel = document.getElementById("payment-student-select");
  if (sel) sel.value = studentId;
  const f = appData.fees.find(x => x.studentId === studentId);
  const amtInput = document.getElementById("payment-amount");
  if (amtInput && f) amtInput.value = f.due;
  openModal("add-fee-payment-modal");
}

function handleAddPaymentSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const studentId = parseInt(form.studentId.value);
  const amount = parseFloat(form.amount.value);
  const mode = form.paymentMode.value;
  const ref = form.ref.value.trim() || `TXN-${Date.now().toString().slice(-6)}`;
  const notes = form.notes.value.trim() || "Hostel Fee Installment";

  if (!studentId || !amount || amount <= 0) {
    showToast("Please enter a valid payment amount.", "warning");
    return;
  }

  const feeRec = appData.fees.find(f => f.studentId === studentId);
  if (!feeRec) return;

  if (amount > feeRec.due) {
    showToast(`Entered amount ₹${amount.toLocaleString()} exceeds outstanding due balance of ₹${feeRec.due.toLocaleString()}.`, "warning");
    return;
  }

  const receiptNo = `REC-2026-${Math.floor(1000 + Math.random() * 9000)}`;
  const today = new Date().toISOString().split("T")[0];

  feeRec.paid += amount;
  feeRec.due = Math.max(0, feeRec.total - feeRec.paid);
  feeRec.status = feeRec.due === 0 ? "Paid" : "Partial";
  feeRec.lastDate = today;

  appData.feePayments.push({
    id: appData.feePayments.length + 1,
    receiptNo,
    studentId,
    amount,
    mode,
    ref,
    date: today,
    notes
  });

  saveData();
  renderFeesTab();
  closeModal("add-fee-payment-modal");
  form.reset();
  showToast(`Payment of ₹${amount.toLocaleString()} recorded successfully. Receipt #${receiptNo} generated.`, "success");

  if (confirm(`Payment recorded successfully!\nWould you like to print official Fee Receipt #${receiptNo} now?`)) {
    printFeeReceipt(receiptNo);
  }
}

function printFeeReceipt(receiptNo) {
  const payment = appData.feePayments.find(p => p.receiptNo === receiptNo);
  if (!payment) {
    showToast("Fee payment receipt record not found.", "error");
    return;
  }
  const student = getStudent(payment.studentId);
  const alloc = getStudentAllocation(student.id);
  const room = alloc ? getRoom(alloc.roomId) : null;
  const feeRec = appData.fees.find(f => f.studentId === student.id);

  const printDoc = document.getElementById("print-document-container");
  if (!printDoc) return;

  printDoc.innerHTML = `
    <div class="print-slip-box">
      <div class="print-header">
        <h1>COLLEGE HOSTEL MANAGEMENT SYSTEM</h1>
        <p>Hostel Administration & Accounts Office | Campus Block C, Ground Floor</p>
        <p>Email: accounts.hostel@college.edu | Tel: +91 11 2345 6789</p>
        <div style="margin-top: 10px; font-weight: bold; font-size: 15px; text-decoration: underline;">
          OFFICIAL HOSTEL FEE PAYMENT RECEIPT
        </div>
      </div>

      <div style="display:flex; justify-content:space-between; margin-bottom:15px; font-size:13px;">
        <div>
          <strong>Receipt No:</strong> ${payment.receiptNo}<br>
          <strong>Date of Payment:</strong> ${payment.date}<br>
          <strong>Transaction Ref:</strong> ${payment.ref}
        </div>
        <div>
          <strong>Payment Mode:</strong> ${payment.mode}<br>
          <strong>Status:</strong> <span style="color:green; font-weight:bold;">CLEARED / SUCCESS</span>
        </div>
      </div>

      <table class="print-table">
        <tr>
          <th style="width: 35%;">Student Name</th>
          <td><strong>${student.name}</strong></td>
        </tr>
        <tr>
          <th>Roll Number</th>
          <td>${student.rollNumber}</td>
        </tr>
        <tr>
          <th>Course & Branch</th>
          <td>${student.course} - ${student.branch} (Year ${student.year})</td>
        </tr>
        <tr>
          <th>Allocated Room / Bed</th>
          <td>${room ? `Room ${room.roomNumber} (${room.block}, Bed ${alloc.bedNumber})` : "Not Allotted"}</td>
        </tr>
        <tr>
          <th>Description</th>
          <td>${payment.notes}</td>
        </tr>
        <tr style="background:#f3f4f6; font-size:15px;">
          <th>AMOUNT PAID (INR)</th>
          <td><strong>₹${payment.amount.toLocaleString()} /-</strong></td>
        </tr>
        <tr>
          <th>Remaining Balance / Due</th>
          <td>₹${feeRec ? feeRec.due.toLocaleString() : "0"} /-</td>
        </tr>
      </table>

      <div class="print-signatures">
        <div class="sig-line">Student Signature</div>
        <div class="sig-line">Cashier / Accounts Officer</div>
        <div class="sig-line">Hostel Warden Seal</div>
      </div>
    </div>
  `;

  window.print();
}

// =========================================================
// 6. COMPLAINTS MANAGEMENT
// =========================================================
function renderAdminComplaints() {
  const tbody = document.getElementById("admin-complaints-table-body");
  if (!tbody) return;

  const catFilter = document.getElementById("complaints-cat-filter")?.value || "all";
  const statusFilter = document.getElementById("complaints-status-filter")?.value || "all";

  let filtered = appData.complaints.filter(c => {
    if (catFilter !== "all" && c.category !== catFilter) return false;
    if (statusFilter !== "all" && c.status !== statusFilter) return false;
    return true;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);">No complaints match the filter.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(c => {
    const student = getStudent(c.studentId);
    const alloc = student ? getStudentAllocation(student.id) : null;
    const room = alloc ? getRoom(alloc.roomId) : null;

    return `
      <tr>
        <td>#C-${c.id}</td>
        <td>
          <strong>${c.title}</strong><br>
          <small style="color:var(--text-muted);">${c.description}</small>
        </td>
        <td><span class="badge badge-${c.category.toLowerCase()}">${c.category}</span></td>
        <td>
          ${student ? student.name : "Resident"}<br>
          <small style="color:var(--text-muted);">${room ? `Room ${room.roomNumber}` : ""}</small>
        </td>
        <td>${c.date}</td>
        <td>
          <select class="form-control" style="padding:4px 8px; font-size:0.8rem; width:130px;" onchange="updateComplaintStatus(${c.id}, this.value)">
            <option value="Open" ${c.status === "Open" ? "selected" : ""}>Open</option>
            <option value="In Progress" ${c.status === "In Progress" ? "selected" : ""}>In Progress</option>
            <option value="Resolved" ${c.status === "Resolved" ? "selected" : ""}>Resolved</option>
            <option value="Closed" ${c.status === "Closed" ? "selected" : ""}>Closed</option>
          </select>
        </td>
        <td>
          <button class="btn btn-sm btn-outline" onclick="openComplaintRemarksModal(${c.id})">
            Note
          </button>
        </td>
      </tr>
    `;
  }).join("");
}

function updateComplaintStatus(complaintId, newStatus) {
  const c = appData.complaints.find(x => x.id === complaintId);
  if (c) {
    c.status = newStatus;
    saveData();
    showToast(`Complaint #C-${complaintId} status updated to "${newStatus}".`, "info");
    renderAdminDashboard();
  }
}

function openComplaintRemarksModal(complaintId) {
  const c = appData.complaints.find(x => x.id === complaintId);
  if (!c) return;
  const remarks = prompt("Enter Warden maintenance notes / resolution remarks:", c.remarks || "");
  if (remarks !== null) {
    c.remarks = remarks.trim();
    saveData();
    showToast("Complaint resolution notes updated successfully.", "success");
  }
}

// =========================================================
// 7. LEAVE APPLICATIONS
// =========================================================
function renderAdminLeaves() {
  const tbody = document.getElementById("admin-leaves-table-body");
  if (!tbody) return;

  tbody.innerHTML = appData.leaves.map(l => {
    const student = getStudent(l.studentId);
    if (!student) return "";

    let badge = "badge-pending";
    if (l.status === "Approved") badge = "badge-approved";
    else if (l.status === "Rejected") badge = "badge-rejected";

    return `
      <tr>
        <td>#L-${l.id}</td>
        <td>
          <strong>${student.name}</strong><br>
          <small style="color:var(--text-muted);">${student.rollNumber} &bull; ${student.phone}</small>
        </td>
        <td><strong>${l.fromDate}</strong> to <strong>${l.toDate}</strong></td>
        <td>
          ${l.reason}
          ${l.rejectionReason ? `<div style="color:var(--danger); font-size:0.75rem; margin-top:4px;">Reason: ${l.rejectionReason}</div>` : ""}
        </td>
        <td><span class="badge ${badge}">${l.status}</span></td>
        <td>
          <div style="display:flex; gap:6px;">
            ${l.status === "Pending" ? `
              <button class="btn btn-sm btn-primary" onclick="approveLeave(${l.id})">
                Approve
              </button>
              <button class="btn btn-sm btn-danger" onclick="openRejectLeaveModal(${l.id})">
                Reject
              </button>
            ` : ""}
            ${l.status === "Approved" ? `
              <button class="btn btn-sm btn-outline" onclick="printLeavePassSlip(${l.id})">
                Pass Slip
              </button>
            ` : ""}
          </div>
        </td>
      </tr>
    `;
  }).join("");
}

function approveLeave(leaveId) {
  const leave = appData.leaves.find(l => l.id === leaveId);
  if (leave) {
    leave.status = "Approved";
    leave.approvedBy = "Dr. Ramesh Kumar (Warden)";
    saveData();
    renderAdminLeaves();
    renderAdminDashboard();
    showToast(`Leave request #L-${leaveId} approved. Security gate pass is ready to print.`, "success");
  }
}

function openRejectLeaveModal(leaveId) {
  const reason = prompt("Please enter the reason for rejecting this leave application:");
  if (reason && reason.trim()) {
    const leave = appData.leaves.find(l => l.id === leaveId);
    if (leave) {
      leave.status = "Rejected";
      leave.rejectionReason = reason.trim();
      leave.approvedBy = "Dr. Ramesh Kumar (Warden)";
      saveData();
      renderAdminLeaves();
      renderAdminDashboard();
      showToast(`Leave request #L-${leaveId} has been rejected.`, "warning");
    }
  } else if (reason !== null) {
    showToast("A reason is required to reject a leave application.", "error");
  }
}

function printLeavePassSlip(leaveId) {
  const leave = appData.leaves.find(l => l.id === leaveId);
  if (!leave || leave.status !== "Approved") {
    showToast("Security gate pass can only be printed for Approved leave requests.", "error");
    return;
  }
  const student = getStudent(leave.studentId);
  const alloc = getStudentAllocation(student.id);
  const room = alloc ? getRoom(alloc.roomId) : null;

  const printDoc = document.getElementById("print-document-container");
  if (!printDoc) return;

  printDoc.innerHTML = `
    <div class="print-slip-box">
      <div class="print-header">
        <h1>HOSTEL GATE PASS & OUTSTATION LEAVE SLIP</h1>
        <p>College Hostel Management System Administration</p>
        <div style="margin-top: 8px; font-weight: bold; font-size: 15px; color:#16a34a; text-decoration: underline;">
          APPROVED RESIDENT OUTSTATION PASS
        </div>
      </div>

      <div style="display:flex; justify-content:space-between; margin-bottom:15px; font-size:13px;">
        <div>
          <strong>Pass ID:</strong> GP-${leave.id}-${student.rollNumber}<br>
          <strong>Issue Date:</strong> ${new Date().toISOString().split("T")[0]}
        </div>
        <div>
          <strong>Status:</strong> <span style="color:#16a34a; font-weight:bold;">APPROVED BY WARDEN</span>
        </div>
      </div>

      <table class="print-table">
        <tr>
          <th style="width: 35%;">Resident Name</th>
          <td><strong>${student.name}</strong></td>
        </tr>
        <tr>
          <th>Roll Number</th>
          <td>${student.rollNumber}</td>
        </tr>
        <tr>
          <th>Course & Branch</th>
          <td>${student.course} - ${student.branch} (Year ${student.year})</td>
        </tr>
        <tr>
          <th>Hostel Room</th>
          <td>${room ? `Room ${room.roomNumber} (${room.block}, Bed ${alloc.bedNumber})` : "N/A"}</td>
        </tr>
        <tr>
          <th>Student Phone</th>
          <td>${student.phone}</td>
        </tr>
        <tr>
          <th>Parent / Guardian Contact</th>
          <td>${student.guardianName} (${student.guardianPhone})</td>
        </tr>
        <tr style="background:#f0fdf4;">
          <th>LEAVE DURATION</th>
          <td><strong>From: ${leave.fromDate} &nbsp; To: ${leave.toDate}</strong></td>
        </tr>
        <tr>
          <th>Reason for Leave</th>
          <td>${leave.reason}</td>
        </tr>
        <tr>
          <th>Sanctioned By</th>
          <td>${leave.approvedBy || "Chief Hostel Warden"}</td>
        </tr>
      </table>

      <div class="print-signatures">
        <div class="sig-line">Student Signature</div>
        <div class="sig-line">Hostel Warden Signature</div>
        <div class="sig-line">Main Gate Security Stamp & Time</div>
      </div>
    </div>
  `;

  window.print();
}

// =========================================================
// 8. VISITORS MANAGEMENT
// =========================================================
function renderVisitorsTab() {
  const tbody = document.getElementById("visitors-table-body");
  if (!tbody) return;

  tbody.innerHTML = appData.visitors.map(v => {
    const student = getStudent(v.studentId);

    return `
      <tr>
        <td>#V-${v.id}</td>
        <td><strong>${v.visitorName}</strong></td>
        <td>${v.phone}</td>
        <td>${student ? `${student.name} (${student.rollNumber})` : "Resident"}</td>
        <td>${v.purpose}</td>
        <td>${v.checkIn}</td>
        <td>${v.checkOut || `<span class="badge badge-pending">Active</span>`}</td>
        <td>
          ${v.status === "Checked In" ? `
            <button class="btn btn-sm btn-primary" onclick="checkOutVisitor(${v.id})">
              Check Out
            </button>
          ` : `
            <span class="badge badge-closed">Completed</span>
          `}
        </td>
      </tr>
    `;
  }).join("");

  populateVisitorStudentSelect();
}

function populateVisitorStudentSelect() {
  const sel = document.getElementById("visitor-student-select");
  if (!sel) return;
  sel.innerHTML = `<option value="">-- Select Resident Student --</option>` + appData.students.map(s => `
    <option value="${s.id}">${s.name} (${s.rollNumber})</option>
  `).join("");
}

function handleAddVisitorSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const visitorName = form.visitorName.value.trim();
  const studentId = parseInt(form.studentId.value);
  const phone = form.phone.value.trim();
  const purpose = form.purpose.value.trim();

  if (!visitorName || !studentId || !phone || !purpose) {
    showToast("Please complete all required visitor information fields.", "warning");
    return;
  }

  const now = new Date();
  const timeStr = `${now.toISOString().split("T")[0]} ${now.toTimeString().split(" ")[0].slice(0, 5)}`;

  const newId = appData.visitors.length > 0 ? Math.max(...appData.visitors.map(v => v.id)) + 1 : 1;
  appData.visitors.unshift({
    id: newId,
    visitorName,
    studentId,
    phone,
    purpose,
    checkIn: timeStr,
    checkOut: null,
    status: "Checked In"
  });

  saveData();
  renderVisitorsTab();
  closeModal("add-visitor-modal");
  form.reset();
  showToast(`Visitor "${visitorName}" checked in successfully.`, "success");
}

function checkOutVisitor(visitorId) {
  const v = appData.visitors.find(x => x.id === visitorId);
  if (v) {
    const now = new Date();
    const timeStr = `${now.toISOString().split("T")[0]} ${now.toTimeString().split(" ")[0].slice(0, 5)}`;
    v.checkOut = timeStr;
    v.status = "Checked Out";
    saveData();
    renderVisitorsTab();
    showToast(`Visitor "${v.visitorName}" checked out at ${timeStr}.`, "info");
  }
}

// =========================================================
// 9. NOTICES / ANNOUNCEMENTS
// =========================================================
function renderNoticesTab() {
  const container = document.getElementById("notices-grid-container");
  if (!container) return;

  if (appData.notices.length === 0) {
    container.innerHTML = `<p style="text-align:center; padding:30px; color:var(--text-muted);">No notices published yet.</p>`;
    return;
  }

  container.innerHTML = appData.notices.map(n => `
    <div class="card" style="margin-bottom: 16px;">
      <div class="card-header" style="margin-bottom: 10px; padding-bottom: 10px;">
        <div style="display:flex; align-items:center; gap:10px;">
          <span class="badge badge-${n.priority.toLowerCase()}">${n.priority}</span>
          <h3 style="font-size:1.15rem;">${n.title}</h3>
        </div>
        <button class="btn btn-sm btn-outline" style="color:var(--danger);" onclick="deleteNotice(${n.id})">
          Delete
        </button>
      </div>
      <p style="margin-bottom: 12px; line-height: 1.6;">${n.content}</p>
      <div style="display:flex; justify-content:space-between; font-size:0.8rem; color:var(--text-muted); border-top:1px solid var(--border-light); padding-top:8px;">
        <span>Posted by: <strong>${n.postedBy}</strong></span>
        <span>Date: ${n.date}</span>
      </div>
    </div>
  `).join("");
}

function handleAddNoticeSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const title = form.title.value.trim();
  const content = form.content.value.trim();
  const priority = form.priority.value;
  const postedBy = form.postedBy.value.trim() || "Hostel Warden";

  if (!title || !content) {
    showToast("Both notice title and announcement content are required.", "warning");
    return;
  }

  const today = new Date().toISOString().split("T")[0];
  const newId = appData.notices.length > 0 ? Math.max(...appData.notices.map(n => n.id)) + 1 : 1;
  appData.notices.unshift({
    id: newId,
    title,
    content,
    priority,
    postedBy,
    date: today
  });

  saveData();
  renderNoticesTab();
  closeModal("add-notice-modal");
  form.reset();
  showToast("Notice announcement published successfully.", "success");
}

function deleteNotice(noticeId) {
  if (confirm("Are you sure you want to delete this notice? This action cannot be undone.")) {
    appData.notices = appData.notices.filter(n => n.id !== noticeId);
    saveData();
    renderNoticesTab();
    showToast("Notice announcement deleted successfully.", "info");
  }
}

// =========================================================
// 10. REPORTS & ANALYTICS
// =========================================================
function renderReportsTab() {
  renderReportsCharts();
}

function renderReportsCharts() {
  const blockA_rooms = appData.rooms.filter(r => r.block === "A-Block");
  const blockB_rooms = appData.rooms.filter(r => r.block === "B-Block");
  const blockC_rooms = appData.rooms.filter(r => r.block === "C-Block");

  const blockA_cap = blockA_rooms.reduce((acc, r) => acc + r.capacity, 0);
  const blockA_occ = appData.allocations.filter(a => blockA_rooms.some(r => r.id === a.roomId)).length;

  const blockB_cap = blockB_rooms.reduce((acc, r) => acc + r.capacity, 0);
  const blockB_occ = appData.allocations.filter(a => blockB_rooms.some(r => r.id === a.roomId)).length;

  const blockC_cap = blockC_rooms.reduce((acc, r) => acc + r.capacity, 0);
  const blockC_occ = appData.allocations.filter(a => blockC_rooms.some(r => r.id === a.roomId)).length;

  const blockContainer = document.getElementById("report-block-occupancy-bars");
  if (blockContainer) {
    const pctA = blockA_cap > 0 ? Math.round((blockA_occ / blockA_cap) * 100) : 0;
    const pctB = blockB_cap > 0 ? Math.round((blockB_occ / blockB_cap) * 100) : 0;
    const pctC = blockC_cap > 0 ? Math.round((blockC_occ / blockC_cap) * 100) : 0;

    blockContainer.innerHTML = `
      <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
        <span style="width:80px; font-weight:600; font-size:0.86rem;">A-Block</span>
        <div style="flex:1; height:20px; background:var(--bg-body); border-radius:6px; overflow:hidden; border:1px solid var(--border-light);">
          <div style="width:${pctA}%; height:100%; background:linear-gradient(90deg, #4f46e5, #7c3aed); border-radius:4px;"></div>
        </div>
        <span style="width:90px; font-size:0.82rem; font-weight:600; color:var(--text-main);">${blockA_occ}/${blockA_cap} (${pctA}%)</span>
      </div>
      <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
        <span style="width:80px; font-weight:600; font-size:0.86rem;">B-Block</span>
        <div style="flex:1; height:20px; background:var(--bg-body); border-radius:6px; overflow:hidden; border:1px solid var(--border-light);">
          <div style="width:${pctB}%; height:100%; background:linear-gradient(90deg, #0284c7, #06b6d4); border-radius:4px;"></div>
        </div>
        <span style="width:90px; font-size:0.82rem; font-weight:600; color:var(--text-main);">${blockB_occ}/${blockB_cap} (${pctB}%)</span>
      </div>
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="width:80px; font-weight:600; font-size:0.86rem;">C-Block</span>
        <div style="flex:1; height:20px; background:var(--bg-body); border-radius:6px; overflow:hidden; border:1px solid var(--border-light);">
          <div style="width:${pctC}%; height:100%; background:linear-gradient(90deg, #ec4899, #f43f5e); border-radius:4px;"></div>
        </div>
        <span style="width:90px; font-size:0.82rem; font-weight:600; color:var(--text-main);">${blockC_occ}/${blockC_cap} (${pctC}%)</span>
      </div>
    `;
  }

  const totalPaid = appData.fees.reduce((acc, f) => acc + f.paid, 0);
  const totalDue = appData.fees.reduce((acc, f) => acc + f.due, 0);
  const totalFees = totalPaid + totalDue;
  const paidPct = totalFees > 0 ? Math.round((totalPaid / totalFees) * 100) : 0;
  const duePct = totalFees > 0 ? Math.round((totalDue / totalFees) * 100) : 0;

  const feesChartContainer = document.getElementById("report-fees-bar-container");
  if (feesChartContainer) {
    feesChartContainer.innerHTML = `
      <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
        <span style="width:80px; font-weight:600; font-size:0.86rem;">Collected</span>
        <div style="flex:1; height:20px; background:var(--bg-body); border-radius:6px; overflow:hidden; border:1px solid var(--border-light);">
          <div style="width:${paidPct}%; height:100%; background:linear-gradient(90deg, #059669, #10b981); border-radius:4px;"></div>
        </div>
        <span style="width:120px; font-size:0.82rem; font-weight:600; color:#15803d;">₹${totalPaid.toLocaleString()} (${paidPct}%)</span>
      </div>
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="width:80px; font-weight:600; font-size:0.86rem;">Due</span>
        <div style="flex:1; height:20px; background:var(--bg-body); border-radius:6px; overflow:hidden; border:1px solid var(--border-light);">
          <div style="width:${duePct}%; height:100%; background:linear-gradient(90deg, #e11d48, #f43f5e); border-radius:4px;"></div>
        </div>
        <span style="width:120px; font-size:0.82rem; font-weight:600; color:#b91c1c;">₹${totalDue.toLocaleString()} (${duePct}%)</span>
      </div>
    `;
  }

  const categoryGradients = {
    Water: "linear-gradient(90deg, #0284c7, #06b6d4)",
    Electrical: "linear-gradient(90deg, #d97706, #f59e0b)",
    Internet: "linear-gradient(90deg, #4f46e5, #818cf8)",
    Cleaning: "linear-gradient(90deg, #059669, #34d399)",
    Furniture: "linear-gradient(90deg, #7c3aed, #a855f7)"
  };

  const categories = ["Water", "Electrical", "Internet", "Cleaning", "Furniture"];
  const compContainer = document.getElementById("report-complaints-bar-container");
  if (compContainer) {
    const totalComps = appData.complaints.length;
    compContainer.innerHTML = categories.map(cat => {
      const count = appData.complaints.filter(c => c.category === cat).length;
      const pct = totalComps > 0 ? Math.round((count / totalComps) * 100) : 0;
      const grad = categoryGradients[cat] || "linear-gradient(90deg, #d97706, #f59e0b)";
      return `
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:10px;">
          <span style="width:90px; font-weight:600; font-size:0.86rem;">${cat}</span>
          <div style="flex:1; height:20px; background:var(--bg-body); border-radius:6px; overflow:hidden; border:1px solid var(--border-light);">
            <div style="width:${pct}%; height:100%; background:${grad}; border-radius:4px;"></div>
          </div>
          <span style="width:70px; font-size:0.82rem; font-weight:600; color:var(--text-main);">${count} (${pct}%)</span>
        </div>
      `;
    }).join("");
  }
}

function exportStudentsCSV() {
  let csv = "Roll Number,Name,Email,Phone,Course,Branch,Year,Gender,Room Number,Bed Number,Guardian Name,Guardian Phone\n";
  appData.students.forEach(s => {
    const alloc = getStudentAllocation(s.id);
    const room = alloc ? getRoom(alloc.roomId) : null;
    const roomNo = room ? room.roomNumber : "Not Allotted";
    const bedNo = alloc ? alloc.bedNumber : "N/A";

    csv += `"${s.rollNumber}","${s.name}","${s.email || ''}","${s.phone}","${s.course}","${s.branch}",${s.year},"${s.gender}","${roomNo}","${bedNo}","${s.guardianName || ''}","${s.guardianPhone || ''}"\n`;
  });

  downloadCSV(csv, "Hostel_Students_Report.csv");
  showToast("Student directory CSV report downloaded successfully.", "success");
}

function exportFeesCSV() {
  let csv = "Roll Number,Student Name,Total Fee,Paid Amount,Due Amount,Status,Last Payment Date\n";
  appData.fees.forEach(f => {
    const s = getStudent(f.studentId);
    if (!s) return;
    csv += `"${s.rollNumber}","${s.name}",${f.total},${f.paid},${f.due},"${f.status}","${f.lastDate || 'None'}"\n`;
  });

  downloadCSV(csv, "Hostel_Fees_Report.csv");
  showToast("Fee ledger CSV report downloaded successfully.", "success");
}

function downloadCSV(csvContent, filename) {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// =========================================================
// 11. STUDENT PORTAL
// =========================================================
function renderStudentDashboard() {
  const student = getStudent(currentStudentId);
  if (!student) return;

  const alloc = getStudentAllocation(student.id);
  const room = alloc ? getRoom(alloc.roomId) : null;
  const feeRec = appData.fees.find(f => f.studentId === student.id);
  const openComps = appData.complaints.filter(c => c.studentId === student.id && (c.status === "Open" || c.status === "In Progress")).length;
  const activeLeave = appData.leaves.find(l => l.studentId === student.id && l.status === "Approved");

  document.getElementById("student-banner-name").textContent = student.name;
  document.getElementById("student-banner-course").textContent = `${student.course} - ${student.branch} (Year ${student.year}) | Roll: ${student.rollNumber}`;
  
  document.getElementById("student-dash-room").textContent = room ? `Room ${room.roomNumber} (Bed ${alloc.bedNumber})` : "Not Allotted";
  document.getElementById("student-dash-block").textContent = room ? `${room.block}, Floor ${room.floor}` : "No Allocation";
  document.getElementById("student-dash-fee-due").textContent = feeRec ? `₹${feeRec.due.toLocaleString()}` : "₹0";
  document.getElementById("student-dash-complaints").textContent = `${openComps} Open`;
  document.getElementById("student-dash-leave-status").textContent = activeLeave ? `Pass GP-${activeLeave.id}` : "None";

  const noticeContainer = document.getElementById("student-dash-notices");
  if (noticeContainer) {
    noticeContainer.innerHTML = appData.notices.slice(0, 3).map(n => `
      <div style="padding:14px; background:var(--bg-body); border:1px solid var(--border-light); border-radius:var(--radius-sm); margin-bottom:10px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
          <h4 style="font-size:0.95rem; font-weight:600;">${n.title}</h4>
          <span class="badge badge-${n.priority.toLowerCase()}">${n.priority}</span>
        </div>
        <p style="font-size:0.86rem; color:var(--text-muted); margin-bottom:8px;">${n.content}</p>
        <small style="color:var(--text-light); font-size:0.75rem;">Date: ${n.date} | By: ${n.postedBy}</small>
      </div>
    `).join("");
  }
}

function renderStudentMyRoom() {
  const student = getStudent(currentStudentId);
  const alloc = getStudentAllocation(student.id);
  const container = document.getElementById("student-my-room-container");
  if (!container) return;

  if (!alloc) {
    container.innerHTML = `
      <div class="card" style="text-align:center; padding:40px;">
        <h3>No Room Allotted Yet</h3>
        <p class="text-muted">You have not been assigned a hostel room yet. Please contact the Hostel Warden office.</p>
      </div>
    `;
    return;
  }

  const room = getRoom(alloc.roomId);
  const allAllocs = getRoomAllocations(room.id);
  const acBadge = `<span class="badge ${room.acType === 'AC' ? 'badge-ac' : 'badge-non-ac'}" style="font-size:0.75rem; padding:2px 7px;">${room.acType || 'Non-AC'} Room</span>`;

  container.innerHTML = `
    <div class="card" style="margin-bottom: 24px;">
      <div class="card-header">
        <div>
          <div style="display:flex; align-items:center; gap:8px;">
            <h3 style="margin:0;">Room ${room.roomNumber} Overview</h3>
            ${acBadge}
          </div>
          <p class="text-muted" style="margin-top:4px;">${room.block} &bull; Floor ${room.floor} &bull; ${room.roomType} (${room.capacity} Sharing)</p>
        </div>
        <span class="badge badge-occupied">${allAllocs.length} / ${room.capacity} Beds Occupied</span>
      </div>
      <p style="font-size: 0.92rem;">
        Your assigned bed is <strong>Bed #${alloc.bedNumber}</strong>.
      </p>
    </div>

    <h3 style="margin-bottom: 16px;">Roommates in Room ${room.roomNumber}</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:16px;">
      ${allAllocs.map(a => {
        const mate = getStudent(a.studentId);
        const isSelf = mate.id === student.id;
        return `
          <div class="card" style="margin-bottom:0; ${isSelf ? 'border: 2px solid var(--primary);' : ''}">
            <h4 style="font-size:1.05rem; margin-bottom:4px;">${mate.name} ${isSelf ? '<span class="badge badge-available">You</span>' : ''}</h4>
            <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:4px;">Bed #${a.bedNumber}</p>
            <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:4px;">${mate.course} - ${mate.branch} (Year ${mate.year})</p>
            <p style="font-size:0.85rem; color:var(--text-muted);">Phone: ${mate.phone}</p>
          </div>
        `;
      }).join("")}
    </div>
  `;
}

function renderStudentFees() {
  const student = getStudent(currentStudentId);
  const feeRec = appData.fees.find(f => f.studentId === student.id);
  const container = document.getElementById("student-fees-container");
  if (!container || !feeRec) return;

  const payments = appData.feePayments.filter(p => p.studentId === student.id);

  let badge = "badge-approved";
  if (feeRec.status === "Due") badge = "badge-rejected";
  else if (feeRec.status === "Partial") badge = "badge-pending";

  container.innerHTML = `
    <div class="stats-grid" style="margin-bottom:24px;">
      <div class="stat-card-clean card-students">
        <div class="stat-data">
          <p>Total Fee</p>
          <h3>₹${feeRec.total.toLocaleString()}</h3>
        </div>
        <div class="stat-icon-square">💰</div>
      </div>
      <div class="stat-card-clean card-beds">
        <div class="stat-data">
          <p>Total Paid</p>
          <h3>₹${feeRec.paid.toLocaleString()}</h3>
        </div>
        <div class="stat-icon-square">✓</div>
      </div>
      <div class="stat-card-clean card-leaves">
        <div class="stat-data">
          <p>Pending Due</p>
          <h3>₹${feeRec.due.toLocaleString()}</h3>
        </div>
        <div class="stat-icon-square">⏳</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h3>My Fee Payment Receipts</h3>
        <span class="badge ${badge}">${feeRec.status}</span>
      </div>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Receipt No</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Payment Mode</th>
              <th>Ref / Txn ID</th>
              <th>Remarks</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${payments.length === 0 ? `
              <tr><td colspan="7" style="text-align:center; padding:20px; color:var(--text-muted);">No payments recorded yet.</td></tr>
            ` : payments.map(p => `
              <tr>
                <td><strong>${p.receiptNo}</strong></td>
                <td>${p.date}</td>
                <td style="color:var(--success); font-weight:600;">₹${p.amount.toLocaleString()}</td>
                <td>${p.mode}</td>
                <td>${p.ref}</td>
                <td>${p.notes}</td>
                <td>
                  <button class="btn btn-sm btn-outline" onclick="printFeeReceipt('${p.receiptNo}')">
                    Print Slip
                  </button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderStudentComplaints() {
  const tbody = document.getElementById("student-complaints-table-body");
  if (!tbody) return;

  const myComplaints = appData.complaints.filter(c => c.studentId === currentStudentId);

  if (myComplaints.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:25px; color:var(--text-muted);">You have not filed any complaints. Click "File Complaint" above.</td></tr>`;
    return;
  }

  tbody.innerHTML = myComplaints.map(c => {
    let badge = "badge-open";
    if (c.status === "In Progress") badge = "badge-in-progress";
    else if (c.status === "Resolved") badge = "badge-resolved";
    else if (c.status === "Closed") badge = "badge-closed";

    return `
      <tr>
        <td>#C-${c.id}</td>
        <td><span class="badge badge-${c.category.toLowerCase()}">${c.category}</span></td>
        <td><strong>${c.title}</strong><br><small style="color:var(--text-muted);">${c.description}</small></td>
        <td>${c.date}</td>
        <td><span class="badge ${badge}">${c.status}</span></td>
        <td>${c.remarks || "<span style='color:var(--text-muted);'>No remarks yet</span>"}</td>
      </tr>
    `;
  }).join("");
}

function handleStudentRaiseComplaintSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const category = form.category.value;
  const title = form.title.value.trim();
  const description = form.description.value.trim();

  if (!title || !description) {
    showToast("Please provide both a title and description for your complaint.", "warning");
    return;
  }

  const today = new Date().toISOString().split("T")[0];
  const newId = appData.complaints.length > 0 ? Math.max(...appData.complaints.map(c => c.id)) + 1 : 1;

  appData.complaints.unshift({
    id: newId,
    studentId: currentStudentId,
    category,
    title,
    description,
    status: "Open",
    date: today,
    remarks: ""
  });

  saveData();
  renderStudentComplaints();
  closeModal("student-raise-complaint-modal");
  form.reset();
  showToast("Your maintenance ticket has been submitted to the Warden.", "success");
}

function renderStudentLeaves() {
  const tbody = document.getElementById("student-leaves-table-body");
  if (!tbody) return;

  const myLeaves = appData.leaves.filter(l => l.studentId === currentStudentId);

  if (myLeaves.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:25px; color:var(--text-muted);">No leave applications found. Click "Apply Leave" above.</td></tr>`;
    return;
  }

  tbody.innerHTML = myLeaves.map(l => {
    let badge = "badge-pending";
    if (l.status === "Approved") badge = "badge-approved";
    else if (l.status === "Rejected") badge = "badge-rejected";

    return `
      <tr>
        <td>#L-${l.id}</td>
        <td><strong>${l.fromDate}</strong> to <strong>${l.toDate}</strong></td>
        <td>
          ${l.reason}
          ${l.rejectionReason ? `<div style="color:var(--danger); font-size:0.75rem;">Reason: ${l.rejectionReason}</div>` : ""}
        </td>
        <td>${l.appliedAt}</td>
        <td><span class="badge ${badge}">${l.status}</span></td>
        <td>
          ${l.status === "Approved" ? `
            <button class="btn btn-sm btn-outline" onclick="printLeavePassSlip(${l.id})">
              Gate Pass
            </button>
          ` : "-"}
        </td>
      </tr>
    `;
  }).join("");
}

function handleStudentApplyLeaveSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const fromDate = form.fromDate.value;
  const toDate = form.toDate.value;
  const reason = form.reason.value.trim();

  if (!fromDate || !toDate || !reason) {
    showToast("Please fill all required leave application fields.", "warning");
    return;
  }

  if (new Date(toDate) < new Date(fromDate)) {
    showToast("Return date cannot be earlier than departure date.", "error");
    return;
  }

  const today = new Date().toISOString().split("T")[0];
  const newId = appData.leaves.length > 0 ? Math.max(...appData.leaves.map(l => l.id)) + 1 : 1;

  appData.leaves.unshift({
    id: newId,
    studentId: currentStudentId,
    fromDate,
    toDate,
    reason,
    status: "Pending",
    appliedAt: today,
    rejectionReason: "",
    approvedBy: ""
  });

  saveData();
  renderStudentLeaves();
  closeModal("student-apply-leave-modal");
  form.reset();
  showToast("Leave application submitted successfully for Warden approval.", "success");
}

function renderStudentMess() {
  const tbody = document.getElementById("mess-menu-table-body");
  if (!tbody) return;

  tbody.innerHTML = appData.messMenu.map(m => `
    <tr>
      <td><strong>${m.day}</strong></td>
      <td>${m.breakfast}</td>
      <td>${m.lunch}</td>
      <td>${m.snacks}</td>
      <td>${m.dinner}</td>
    </tr>
  `).join("");
}

function renderEmergencyContacts() {
  const container = document.getElementById("emergency-contacts-container");
  if (!container) return;

  container.innerHTML = appData.emergencyContacts.map(c => `
    <div class="card" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px; margin-bottom:12px;">
      <div>
        <h4 style="font-size:1.05rem; font-weight:700; margin-bottom:2px;">${c.designation}</h4>
        <p style="font-size:0.9rem; color:var(--text-muted);">${c.name} &bull; <span class="badge badge-normal">${c.hours}</span></p>
        <small style="color:var(--text-light);">${c.email || ""}</small>
      </div>
      <div>
        <a href="tel:${c.phone}" class="btn btn-primary" style="text-decoration:none;">
          📞 Call ${c.phone}
        </a>
      </div>
    </div>
  `).join("");
}

// =========================================================
// MODALS & TOAST NOTIFICATIONS
// =========================================================
function openModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.add("active");
}

function closeModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.remove("active");
}

function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  let icon = "ℹ️";
  let title = "Notice";
  if (type === "success") { icon = "✅"; title = "Success"; }
  if (type === "error") { icon = "❌"; title = "Error"; }
  if (type === "warning") { icon = "⚠️"; title = "Attention"; }
  if (type === "info") { icon = "ℹ️"; title = "Information"; }

  toast.innerHTML = `
    <div class="toast-icon-badge">${icon}</div>
    <div class="toast-content-col">
      <div class="toast-headline">${title}</div>
      <div class="toast-message-text">${escapeHtml(message)}</div>
    </div>
    <button type="button" class="toast-close-btn" onclick="this.parentElement.remove()" title="Dismiss">&times;</button>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    setTimeout(() => toast.remove(), 250);
  }, 4000);
}

function escapeHtml(text) {
  if (!text) return "";
  return text.toString()
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
