/* NOVA ULTIMATE AI — HTML/CSS/JS pur. Les clés restent sur l'appareil (localStorage). */
(function(){
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const store={get:(k,d)=>{try{return JSON.parse(localStorage.getItem('nova_'+k))??d}catch(e){return d}},set:(k,v)=>localStorage.setItem('nova_'+k,JSON.stringify(v))};
const DEF={chatProvider:'openai',chatKey:'',chatModel:'',chatUrl:'',imgProvider:'openai',imgKey:'',imgModel:'',imgUrl:'',vidProvider:'replicate',vidKey:'',vidModel:'',vidUrl:'',system:"Tu es NOVA, un assistant IA brillant, créatif et bienveillant. Réponds en français sauf demande contraire."};
let S=Object.assign({},DEF,store.get('settings',{}));
const CHAT_BASE={openai:'https://api.openai.com/v1',openrouter:'https://openrouter.ai/api/v1',groq:'https://api.groq.com/openai/v1'};
const CHAT_MODEL={openai:'gpt-4o-mini',gemini:'gemini-2.0-flash',openrouter:'openai/gpt-4o-mini',groq:'llama-3.3-70b-versatile',custom:''};
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('show'),2600)}
const esc=s=>s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function md(t){return esc(t).replace(/```([\s\S]*?)```/g,'<pre>$1</pre>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*(.+?)\*\*/g,'<b>$1</b>')}
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);

/* ---------- Cerveau IA ---------- */
async function askAI(messages){
  if(!S.chatKey) throw new Error("Ajoute ta clé API « Cerveau IA » dans ⚙ Paramètres.");
  const model=S.chatModel||CHAT_MODEL[S.chatProvider];
  if(S.chatProvider==='gemini'){
    const contents=messages.filter(m=>m.role!=='system').map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.content}]}));
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':S.chatKey},body:JSON.stringify({systemInstruction:{parts:[{text:S.system}]},contents})});
    const j=await r.json(); if(!r.ok) throw new Error(j.error?.message||r.status);
    return j.candidates?.[0]?.content?.parts?.map(p=>p.text).join('')||'(réponse vide)';
  }
  const base=(S.chatUrl||CHAT_BASE[S.chatProvider]||'').replace(/\/$/,'');
  if(!base) throw new Error("Indique l'URL de base du fournisseur personnalisé.");
  const r=await fetch(base+'/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+S.chatKey},body:JSON.stringify({model,messages:[{role:'system',content:S.system},...messages]})});
  const j=await r.json(); if(!r.ok) throw new Error(j.error?.message||('Erreur '+r.status));
  return j.choices?.[0]?.message?.content||'(réponse vide)';
}

/* ---------- Chat & historique ---------- */
let convs=store.get('convs',[]), cur=store.get('cur',null);
const saveConvs=()=>{store.set('convs',convs);store.set('cur',cur)};
const curConv=()=>convs.find(c=>c.id===cur);
function newConv(){cur=null;saveConvs();renderMsgs();renderList();closeDrawer();$('#chatInput').focus()}
function renderList(){
  $('#convList').innerHTML=convs.length?'':'<li class="hint" style="padding:12px">Aucune conversation</li>';
  convs.slice().sort((a,b)=>b.t-a.t).forEach(c=>{
    const li=document.createElement('li'); if(c.id===cur) li.className='on';
    li.innerHTML=`<button class="open">${esc(c.title)}</button><button class="del" aria-label="Supprimer">🗑</button>`;
    li.querySelector('.open').onclick=()=>{cur=c.id;saveConvs();renderMsgs();renderList();closeDrawer()};
    li.querySelector('.del').onclick=()=>{convs=convs.filter(x=>x.id!==c.id);if(cur===c.id)cur=null;saveConvs();renderList();renderMsgs()};
    $('#convList').appendChild(li);
  });
}
function bubble(role,text,cls=''){
  const d=document.createElement('div'); d.className='msg '+(role==='user'?'user':'ai')+' '+cls;
  d.innerHTML=role==='user'?esc(text):`<div class="av"></div><div class="body">${text}</div>`;
  $('#messages').appendChild(d); $('#messages').scrollTop=1e9; return d;
}
function renderMsgs(){
  $('#messages').innerHTML=''; const c=curConv();
  $('#welcome').classList.toggle('hide',!!(c&&c.msgs.length));
  c&&c.msgs.forEach(m=>bubble(m.role,m.role==='user'?m.content:md(m.content)));
}
let busy=false;
async function send(text){
  text=text.trim(); if(!text||busy) return;
  let c=curConv(); if(!c){c={id:uid(),title:text.slice(0,40),msgs:[],t:Date.now()};convs.push(c);cur=c.id}
  c.msgs.push({role:'user',content:text}); c.t=Date.now(); saveConvs(); renderList();
  $('#welcome').classList.add('hide'); bubble('user',text);
  const ty=bubble('ai','<span class="typing"><span></span><span></span><span></span></span>');
  busy=true;
  try{const a=await askAI(c.msgs.slice(-20)); c.msgs.push({role:'assistant',content:a}); saveConvs(); ty.querySelector('.body').innerHTML=md(a)}
  catch(e){ty.classList.add('err');ty.querySelector('.body').textContent='⚠ '+e.message}
  busy=false; $('#messages').scrollTop=1e9;
}
const inp=$('#chatInput');
inp.addEventListener('input',()=>{inp.style.height='auto';inp.style.height=Math.min(inp.scrollHeight,140)+'px'});
inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&window.innerWidth>700){e.preventDefault();$('#chatForm').requestSubmit()}});
$('#chatForm').onsubmit=e=>{e.preventDefault();const t=inp.value;inp.value='';inp.style.height='auto';send(t)};
$$('.chip').forEach(b=>b.onclick=()=>send(b.textContent));

/* ---------- Drawer / Tabs / Settings ---------- */
function closeDrawer(){$('#drawer').classList.remove('open');$('#scrim').classList.remove('show')}
$('#menuBtn').onclick=()=>{$('#drawer').classList.add('open');$('#scrim').classList.add('show')};
$('#closeDrawer').onclick=closeDrawer; $('#scrim').onclick=closeDrawer; $('#newChat').onclick=newConv;
$$('.tabs button').forEach(b=>b.onclick=()=>{$$('.tabs button').forEach(x=>x.classList.toggle('on',x===b));$$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+b.dataset.v))});
const FIELDS=Object.keys(DEF);
function openSettings(){FIELDS.forEach(k=>{const el=$('#s_'+k);if(el)el.value=S[k]||''});$('#settings').classList.add('open')}
$('#settingsBtn').onclick=openSettings; $('#closeSettings').onclick=()=>$('#settings').classList.remove('open');
$('#settings').onclick=e=>{if(e.target.id==='settings')$('#settings').classList.remove('open')};
$('#saveSettings').onclick=()=>{FIELDS.forEach(k=>{const el=$('#s_'+k);if(el)S[k]=el.value.trim()});if(!S.system)S.system=DEF.system;store.set('settings',S);$('#settings').classList.remove('open');toast('Paramètres enregistrés ✓')};
$('#wipe').onclick=()=>{if(confirm('Effacer clés, conversations, créations et histoires ?')){Object.keys(localStorage).filter(k=>k.startsWith('nova_')).forEach(k=>localStorage.removeItem(k));location.reload()}};

/* ---------- Studio : images / anime / manga / vidéo ---------- */
let mode='image', gallery=store.get('gallery',[]);
const STYLE={image:'',anime:', style anime japonais, couleurs vives, cel shading, haute qualité',manga:', planche de manga en noir et blanc, encrage, trames, cases de bande dessinée japonaise'};
$$('#createMode button').forEach(b=>b.onclick=()=>{mode=b.dataset.m;$$('#createMode button').forEach(x=>x.classList.toggle('on',x===b))});
function renderGallery(){
  $('#gallery').innerHTML='';
  gallery.slice().reverse().forEach(g=>{const f=document.createElement('figure');
    f.innerHTML=(g.type==='video'?`<video src="${g.src}" controls playsinline></video>`:`<img src="${g.src}" alt="">`)+`<figcaption><span>${esc(g.mode)}</span><a href="${g.src}" download="nova-${g.id}" target="_blank">⬇</a></figcaption>`;
    $('#gallery').appendChild(f)});
}
function addG(o){gallery.push(o);if(gallery.length>30)gallery.shift();try{store.set('gallery',gallery)}catch(e){gallery=gallery.slice(-6);store.set('gallery',gallery)}renderGallery()}
async function genImage(prompt,size){
  if(!S.imgKey) throw new Error("Ajoute ta clé API « Génération d'images » dans ⚙ Paramètres.");
  if(S.imgProvider==='stability'){
    const fd=new FormData(); fd.append('prompt',prompt); fd.append('output_format','png');
    fd.append('aspect_ratio',size==='1024x1792'?'9:16':size==='1792x1024'?'16:9':'1:1');
    const r=await fetch('https://api.stability.ai/v2beta/stable-image/generate/core',{method:'POST',headers:{Authorization:'Bearer '+S.imgKey,Accept:'application/json'},body:fd});
    const j=await r.json(); if(!r.ok) throw new Error(j.errors?.join(', ')||j.message||r.status);
    return 'data:image/png;base64,'+j.image;
  }
  const base=(S.imgUrl||'https://api.openai.com/v1').replace(/\/$/,'');
  const model=S.imgModel||'dall-e-3';
  const body={model,prompt,n:1,size}; if(model.startsWith('dall-e')) body.response_format='b64_json';
  const r=await fetch(base+'/images/generations',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+S.imgKey},body:JSON.stringify(body)});
  const j=await r.json(); if(!r.ok) throw new Error(j.error?.message||r.status);
  const d=j.data?.[0]; return d.b64_json?'data:image/png;base64,'+d.b64_json:d.url;
}
async function genVideo(prompt){
  if(!S.vidKey) throw new Error("Ajoute ta clé API « Génération de vidéos » dans ⚙ Paramètres.");
  if(S.vidProvider==='custom'){
    if(!S.vidUrl) throw new Error("Indique l'URL de l'API vidéo personnalisée.");
    const r=await fetch(S.vidUrl,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+S.vidKey},body:JSON.stringify({model:S.vidModel,prompt})});
    const j=await r.json(); if(!r.ok) throw new Error(j.error?.message||j.detail||r.status);
    return j.video_url||j.url||j.output||j.data?.[0]?.url;
  }
  const model=S.vidModel||'minimax/video-01';
  const r=await fetch(`https://api.replicate.com/v1/models/${model}/predictions`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+S.vidKey,Prefer:'wait'},body:JSON.stringify({input:{prompt}})});
  let p=await r.json(); if(!r.ok) throw new Error(p.detail||r.status);
  for(let i=0;i<120&&!['succeeded','failed','canceled'].includes(p.status);i++){
    await new Promise(z=>setTimeout(z,5000)); toast('Vidéo en cours… '+(i*5+5)+'s');
    p=await (await fetch(p.urls.get,{headers:{Authorization:'Bearer '+S.vidKey}})).json();
  }
  if(p.status!=='succeeded') throw new Error(p.error||'Génération vidéo échouée');
  return Array.isArray(p.output)?p.output[0]:p.output;
}
$('#createBtn').onclick=async()=>{
  const prompt=$('#createPrompt').value.trim(); if(!prompt) return toast('Décris ta création');
  const b=$('#createBtn'); b.disabled=true; b.textContent='⏳ Génération…';
  try{
    if(mode==='video'){const src=await genVideo(prompt);addG({id:uid(),type:'video',mode:'Vidéo',src})}
    else{const src=await genImage(prompt+STYLE[mode],$('#createSize').value);addG({id:uid(),type:'image',mode:{image:'Image',anime:'Anime',manga:'Manga'}[mode],src})}
    toast('Création terminée ✓');
  }catch(e){toast('⚠ '+e.message)}
  b.disabled=false; b.textContent='✦ Générer';
};

/* ---------- Histoires & épisodes ---------- */
let series=store.get('series',[]);
const saveSeries=()=>store.set('series',series);
function renderSeries(){
  const box=$('#seriesList'); box.innerHTML=series.length?'':'<p class="hint">Crée ta première série ci-dessus. NOVA écrira les épisodes en gardant la continuité.</p>';
  series.slice().reverse().forEach(s=>{
    const d=document.createElement('div'); d.className='card series';
    d.innerHTML=`<h4>${esc(s.title)}</h4><div class="meta">${esc(s.genre)} · ${s.eps.length} épisode(s)</div>
      ${s.eps.map((e,i)=>`<details ${i===s.eps.length-1?'open':''}><summary>Épisode ${i+1}</summary><div class="ep">${md(e)}</div></details>`).join('')}
      <input class="field dir" placeholder="Direction pour le prochain épisode (optionnel)">
      <div class="row"><button class="btn primary next" style="flex:1">✦ Écrire l'épisode ${s.eps.length+1}</button><button class="btn del">🗑</button></div>`;
    d.querySelector('.del').onclick=()=>{if(confirm('Supprimer cette série ?')){series=series.filter(x=>x.id!==s.id);saveSeries();renderSeries()}};
    d.querySelector('.next').onclick=async e=>{
      const btn=e.target; btn.disabled=true; btn.textContent='⏳ NOVA écrit…';
      const prev=s.eps.map((x,i)=>`Épisode ${i+1} :\n${x}`).join('\n\n').slice(-6000);
      const p=`Série : « ${s.title} » (genre : ${s.genre}).\nConcept : ${s.idea||'libre'}\n${prev?'Épisodes précédents :\n'+prev+'\n':''}${d.querySelector('.dir').value?'Consigne : '+d.querySelector('.dir').value+'\n':''}Écris l'épisode ${s.eps.length+1} avec un titre, des dialogues vivants et un cliffhanger final. Environ 600 mots.`;
      try{const t=await askAI([{role:'user',content:p}]);s.eps.push(t);saveSeries();renderSeries()}
      catch(err){toast('⚠ '+err.message);btn.disabled=false;btn.textContent='Réessayer'}
    };
    box.appendChild(d);
  });
}
$('#stNew').onclick=()=>{const title=$('#stTitle').value.trim();if(!title)return toast('Donne un titre à ta série');
  series.push({id:uid(),title,genre:$('#stGenre').value,idea:$('#stIdea').value.trim(),eps:[]});saveSeries();
  $('#stTitle').value=$('#stIdea').value='';renderSeries();toast('Série créée ✓')};

renderList(); renderMsgs(); renderGallery(); renderSeries();
if(!S.chatKey) setTimeout(()=>toast('Astuce : configure tes clés API via ⚙'),800);
})();
