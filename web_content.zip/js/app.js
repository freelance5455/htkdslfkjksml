const AppController = {
    init: function() {
        this.bindNavEvents();
    },

    bindNavEvents: function() {
        const navButtons = document.querySelectorAll('.nav-btn');
        const views = document.querySelectorAll('.view');

        navButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                navButtons.forEach(b => b.classList.remove('active'));
                views.forEach(v => v.style.display = 'none');

                const clickedBtn = e.currentTarget;
                clickedBtn.classList.add('active');

                const viewId = clickedBtn.id.replace('nav-', 'view-');
                document.getElementById(viewId).style.display = 'block';
            });
        });
    }
};

document.addEventListener('DOMContentLoaded', () => {
    AppController.init();
});
