// ControlMax Comercial - inicialización
"use strict";
console.log("ControlMax Comercial iniciado.");
