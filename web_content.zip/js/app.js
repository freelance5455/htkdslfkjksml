/* App bootstrap: wires everything together */
(function () {
  "use strict";

  const DEFAULT_FILES = [
    {
      name: "index.html",
      content: '<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>مشروعي</title>\n  <link rel="stylesheet" href="style.css" />\n</head>\n<body>\n  <h1>مرحبًا بك في Mobile Code Studio</h1>\n  <p>عدّل هذا الملف ثم اضغط «تشغيل».</p>\n  <button id="btn">اضغطني</button>\n  <script src="script.js"><\\/script>\n</body>\n</html>\n',
    },
    {
      name: "style.css",
      content: "body {\n  font-family: system-ui, sans-serif;\n  background: #0f172a;\n  color: #e2e8f0;\n  padding: 24px;\n}\nh1 { color: #22d3ee; }\nbutton {\n  padding: 10px 18px;\n  border-radius: 10px;\n  border: none;\n  background: #0ea5e9;\n  color: #00121f;\n  font-weight: 600;\n}\n",
    },
    {
      name: "script.js",
      content: 'document.getElementById("btn").addEventListener("click", function () {\n  console.log("تم الضغط!");\n  alert("مرحبًا من JavaScript");\n});\n',
    },
  ];

  const settings = {
    dark: true,
    showLines: true,
    wrap: false,
    autoSave: true,
    fontSize: 13,
    tabSize: 2,
  };

  let activeFileId = null;
  let dirty = false;
  let autoSaveTimer = null;

  const statusSave = document.getElementById("status-save");
  const tabsEl = document.getElementById("tabs");
  const drawer = document.getElementById("drawer");
  const scrim = document.getElementById("scrim");
  const settingsPanel = document.getElementById("settings-panel");
  const modal = document.getElementById("modal");
  const modalTitle = document.getElementById("modal-title");
  const modalMsg = document.getElementById("modal-msg");
  const modalInput = document.getElementById("modal-input");
  const toastEl = document.getElementById("toast");

  let modalResolve = null;

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => toastEl.classList.remove("show"), 1800);
  }

  function ask(title, msg, withInput, defaultValue) {
    return new Promise((resolve) => {
      modalTitle.textContent = title;
      modalMsg.textContent = msg || "";
      modalInput.value = defaultValue || "";
      modalInput.classList.toggle("show", !!withInput);
      modal.classList.add("open");
      modalResolve = resolve;
      if (withInput) setTimeout(() => modalInput.focus(), 50);
    });
  }

  function closeModal(result) {
    modal.classList.remove("open");
    if (modalResolve) { modalResolve(result); modalResolve = null; }
  }

  document.getElementById("modal-cancel").addEventListener("click", () => closeModal(null));
  document.getElementById("modal-ok").addEventListener("click", () => {
    const val = modalInput.classList.contains("show") ? modalInput.value : true;
    closeModal(val);
  });
  modalInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") document.getElementById("modal-ok").click();
  });

  function setDirty(v) {
    dirty = v;
    statusSave.textContent = v ? "غير محفوظ" : "محفوظ";
    statusSave.className = v ? "dirty" : "saved";
    renderTabs();
  }

  function renderTabs() {
    const files = window.Files.all();
    tabsEl.innerHTML = files.map((f) => {
      const active = f.id === activeFileId ? " active" : "";
      const dot = (f.id === activeFileId && dirty) ? '<span class="dot"></span>' : "";
      return '<div class="tab' + active + '" data-tab="' + f.id + '">' + dot +
        window.Highlighter.esc(f.name) +
        '<span class="close" data-close="' + f.id + '">×</span></div>';
    }).join("");
  }

  function openFile(f) {
    activeFileId = f.id;
    window.Files.setActive(f.id);
    window.Editor.setValue(f.content, f.lang);
    window.Editor.setLang(f.lang);
    setDirty(false);
    renderTabs();
  }

  async function saveActive() {
    const f = window.Files.get(activeFileId);
    if (!f) return;
    window.Files.updateContent(f.id, window.Editor.getValue());
    setDirty(false);
    await persist();
    toast("تم الحفظ");
    if (document.getElementById("set-autosave").checked) {
      // preview refresh handled by user via run button
    }
  }

  async function persist() {
    const data = {
      files: window.Files.toJSON(),
      activeId: activeFileId,
      settings,
    };
    await window.Storage.set("session", data);
  }

  function scheduleAutoSave() {
    if (!settings.autoSave) return;
    clearTimeout(autoSaveTimer);
    autoSaveTimer = setTimeout(() => {
      const f = window.Files.get(activeFileId);
      if (f) {
        window.Files.updateContent(f.id, window.Editor.getValue());
        setDirty(false);
        persist();
      }
    }, 1200);
  }

  function applySettings() {
    document.body.classList.toggle("light", !settings.dark);
    document.body.classList.toggle("wrap", settings.wrap);
    document.getElementById("set-dark").checked = settings.dark;
    document.getElementById("set-lines").checked = settings.showLines;
    document.getElementById("set-wrap").checked = settings.wrap;
    document.getElementById("set-autosave").checked = settings.autoSave;
    document.getElementById("set-font").value = settings.fontSize;
    document.getElementById("set-tab").value = settings.tabSize;
    window.Editor.setShowLines(settings.showLines);
    const ta = window.Editor.getTextarea();
    ta.style.fontSize = settings.fontSize + "px";
    document.getElementById("highlight").style.fontSize = settings.fontSize + "px";
    document.getElementById("gutter").style.fontSize = settings.fontSize + "px";
    ta.style.tabSize = settings.tabSize;
    document.getElementById("highlight").style.tabSize = settings.tabSize;
  }

  /* ---------- Event wiring ---------- */

  document.getElementById("btn-menu").addEventListener("click", () => {
    drawer.classList.add("open");
    scrim.classList.add("show");
  });
  function closeDrawer() {
    drawer.classList.remove("open");
    scrim.classList.remove("show");
  }
  document.getElementById("drawer-close").addEventListener("click", closeDrawer);
  scrim.addEventListener("click", closeDrawer);

  document.getElementById("btn-save").addEventListener("click", saveActive);
  document.getElementById("btn-undo").addEventListener("click", () => window.Editor.undo());
  document.getElementById("btn-redo").addEventListener("click", () => window.Editor.redo());
  document.getElementById("btn-run").addEventListener("click", () => window.Preview.open());

  document.getElementById("btn-new-file").addEventListener("click", async () => {
    const name = await ask("ملف جديد", "أدخل اسم الملف مع الامتداد", true, "new.html");
    if (!name) return;
    const f = window.Files.create(name, "");
    openFile(f);
    closeDrawer();
    persist();
  });

  document.getElementById("btn-new-folder").addEventListener("click", async () => {
    const name = await ask("مجلد جديد", "أدخل اسم المجلد", true, "assets");
    if (!name) return;
    toast("المجلدات تُدار عبر أسماء الملفات (مثال: assets/img.png)");
    closeDrawer();
  });

  document.getElementById("btn-import").addEventListener("click", () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json,.json";
    input.onchange = async () => {
      const file = input.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        const data = JSON.parse(text);
        if (data.files) {
          window.Files.loadFrom(data.files);
          if (data.settings) Object.assign(settings, data.settings);
          applySettings();
          const first = window.Files.all()[0];
          if (first) openFile(first);
          persist();
          toast("تم الاستيراد");
        }
      } catch (e) {
        toast("فشل الاستيراد: ملف غير صالح");
      }
    };
    input.click();
  });

  document.getElementById("btn-export").addEventListener("click", () => {
    const data = JSON.stringify({ files: window.Files.toJSON(), settings }, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mobile-code-studio-project.json";
    a.click();
    URL.revokeObjectURL(url);
    toast("تم التصدير");
  });

  document.getElementById("file-list").addEventListener("click", async (e) => {
    const del = e.target.closest("[data-del]");
    if (del) {
      const id = del.getAttribute("data-del");
      const f = window.Files.get(id);
      const ok = await ask("حذف الملف", "هل تريد حذف «" + f.name + "»؟");
      if (ok) {
        window.Files.remove(id);
        if (activeFileId === id) {
          const first = window.Files.all()[0];
          if (first) openFile(first);
          else { window.Editor.setValue("", "txt"); activeFileId = null; }
        }
        persist();
        toast("تم الحذف");
      }
      return;
    }
    const item = e.target.closest("[data-id]");
    if (item) {
      window.Files.open(item.getAttribute("data-id"));
      closeDrawer();
    }
  });

  tabsEl.addEventListener("click", async (e) => {
    const close = e.target.closest("[data-close]");
    if (close) {
      const id = close.getAttribute("data-close");
      if (id === activeFileId && dirty) {
        const ok = await ask("تعديلات غير محفوظة", "هل تريد إغلاق الملف دون حفظ؟");
        if (!ok) return;
      }
      window.Files.remove(id);
      const first = window.Files.all()[0];
      if (first) openFile(first);
      else { window.Editor.setValue("", "txt"); activeFileId = null; }
      persist();
      return;
    }
    const tab = e.target.closest("[data-tab]");
    if (tab) {
      const id = tab.getAttribute("data-tab");
      if (id === activeFileId) return;
      if (dirty) {
        const ok = await ask("تعديلات غير محفوظة", "هل تريد التبديل دون حفظ؟");
        if (!ok) return;
      }
      window.Files.open(id);
    }
  });

  document.querySelectorAll(".bottomnav button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const view = btn.getAttribute("data-view");
      document.querySelectorAll(".bottomnav button").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      if (view === "files") {
        drawer.classList.add("open");
        scrim.classList.add("show");
      } else if (view === "preview") {
        window.Preview.open();
      } else if (view === "settings") {
        settingsPanel.classList.add("open");
      } else {
        window.Editor.focus();
      }
    });
  });

  document.getElementById("settings-close").addEventListener("click", () => {
    settingsPanel.classList.remove("open");
    document.querySelectorAll(".bottomnav button").forEach((b) => b.classList.remove("active"));
    document.querySelector('[data-view="editor"]').classList.add("active");
  });

  document.getElementById("set-dark").addEventListener("change", (e) => { settings.dark = e.target.checked; applySettings(); persist(); });
  document.getElementById("set-lines").addEventListener("change", (e) => { settings.showLines = e.target.checked; applySettings(); persist(); });
  document.getElementById("set-wrap").addEventListener("change", (e) => { settings.wrap = e.target.checked; applySettings(); persist(); });
  document.getElementById("set-autosave").addEventListener("change", (e) => { settings.autoSave = e.target.checked; persist(); });
  document.getElementById("set-font").addEventListener("input", (e) => { settings.fontSize = +e.target.value; applySettings(); persist(); });
  document.getElementById("set-tab").addEventListener("input", (e) => { settings.tabSize = +e.target.value; applySettings(); persist(); });
  document.getElementById("set-reset").addEventListener("click", async () => {
    const ok = await ask("إعادة الضبط", "سيتم استعادة الإعدادات الافتراضية.");
    if (!ok) return;
    Object.assign(settings, { dark: true, showLines: true, wrap: false, autoSave: true, fontSize: 13, tabSize: 2 });
    applySettings();
    persist();
    toast("تمت إعادة الضبط");
  });

  document.getElementById("symbol-bar").addEventListener("click", (e) => {
    const b = e.target.closest("[data-ins]");
    if (!b) return;
    const raw = b.getAttribute("data-ins");
    const text = raw === "&#9;" ? "  " : raw;
    window.Editor.insertText(text);
  });

  window.Editor.onChange(() => {
    setDirty(true);
    scheduleAutoSave();
  });

  window.Files.onOpen((f) => {
    activeFileId = f.id;
    window.Editor.setValue(f.content, f.lang);
    window.Editor.setLang(f.lang);
    setDirty(false);
    renderTabs();
  });

  /* ---------- Boot ---------- */
  async function boot() {
    const persistent = await window.Storage.probe();
    let session = await window.Storage.get("session");

    if (!session || !session.files || !session.files.length) {
      const created = DEFAULT_FILES.map((f) => window.Files.create(f.name, f.content));
      session = { files: window.Files.toJSON(), activeId: created[0].id, settings };
    } else {
      window.Files.loadFrom(session.files);
      if (session.settings) Object.assign(settings, session.settings);
    }

    applySettings();

    const first = window.Files.get(session.activeId) || window.Files.all()[0];
    if (first) openFile(first);

    if (!persistent) {
      toast("تنبيه: التخزين الدائم غير متاح — استخدم «تصدير» للاحتفاظ بالعمل");
    }
  }

  boot();
})();