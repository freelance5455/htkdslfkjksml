/* زندگی من | Daily Life Manager — Vanilla JS, no dependencies */
(function () {
    'use strict';

    /* ---------- helpers ---------- */
    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => [...r.querySelectorAll(s)];
    const pad = n => String(n).padStart(2, '0');
    const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const num = n => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
    const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
    const today = () => ymd(new Date());
    const parseYmd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
    const addDays = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };
    const weekStart = d => { const r = new Date(d.getFullYear(), d.getMonth(), d.getDate()); r.setDate(r.getDate() - ((r.getDay() + 1) % 7)); return r; };
    const inWeek = s => { const d = parseYmd(s), w = weekStart(new Date()); return d >= w && d < addDays(w, 7); };
    const inMonth = s => s.slice(0, 7) === today().slice(0, 7);

    // DOM builder (uses textContent → safe against XSS)
    function h(tag, attrs, ...kids) {
        const e = document.createElement(tag);
        if (attrs) for (const k in attrs) {
            const v = attrs[k];
            if (v == null || v === false) continue;
            if (k === 'class') e.className = v;
            else if (k === 'text') e.textContent = v;
            else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
            else if (v === true) e.setAttribute(k, '');
            else e.setAttribute(k, v);
        }
        kids.flat().forEach(c => { if (c == null || c === false) return; e.append(c.nodeType ? c : document.createTextNode(String(c))); });
        return e;
    }

    // ---- Font Awesome icons: emoji -> <i class="fa-solid ..."> ----
    const EM_RAW = {
        '🏠': 'house', '📅': 'calendar-day', '✅': 'square-check', '🗓': 'calendar-days', '📝': 'note-sticky', '💰': 'wallet',
        '📚': 'book-open', '😴': 'bed', '📊': 'chart-pie', '⚙': 'gear', '🔔': 'bell', '🌙': 'moon', '☀': 'sun', '👤': 'user', '🔍': 'magnifying-glass',
        '☰': 'bars', '✕': 'xmark', '✏': 'pen', '🗑': 'trash', '📋': 'clipboard-list', '👋': 'hand', '🎨': 'palette', '🌐': 'globe', '💾': 'floppy-disk',
        '⬇': 'download', '⬆': 'upload', '⏱': 'stopwatch', '🎉': 'champagne-glasses', '✓': 'circle-check', '⚠': 'triangle-exclamation', '⋯': 'ellipsis'
    };
    const EM = {};
    for (const k in EM_RAW) EM[k.replace(/\uFE0F/g, '')] = EM_RAW[k];
    const EM_SPLIT = new RegExp('(' + Object.keys(EM).join('|') + ')\\uFE0F?');
    function iconize(root) {
        const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), nodes = [];
        while (w.nextNode()) nodes.push(w.currentNode);
        nodes.forEach(n => {
            const parts = n.nodeValue.split(EM_SPLIT);
            if (parts.length < 2) return;
            const frag = document.createDocumentFragment();
            parts.forEach((p, i) => {
                if (i % 2) frag.append(h('i', { class: 'fa-solid fa-' + EM[p], 'aria-hidden': 'true' }));
                else if (p) frag.append(document.createTextNode(p));
            });
            n.replaceWith(frag);
        });
    }

    /* ---------- storage ---------- */
    const P = 'dailyLife_';
    const K = {
        tasks: P + 'tasks', notes: P + 'notes', schedule: P + 'schedule', expenses: P + 'expenses', study: P + 'study',
        sleep: P + 'sleep', studyLog: P + 'studyLog', settings: P + 'settings', profile: P + 'profile', notifs: P + 'notifications', onboarded: P + 'onboarded'
    };
    const COLS = ['tasks', 'notes', 'schedule', 'expenses', 'study', 'studyLog', 'sleep', 'notifs'];
    const DEF_SETTINGS = { theme: 'light', lang: 'fa', notif: true, taskRem: true, studyRem: true };
    const DEF_PROFILE = { name: '', title: '' };
    const S = {
        tasks: [], notes: [], schedule: [], expenses: [], study: [], studyLog: [], sleep: [], notifs: [],
        settings: {}, profile: {}, query: '', page: 'dashboard', chart: 'study', taskFilter: 'all',
        calMonth: new Date(), calSel: today(), schedDate: today()
    };

    function read(key, fb) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fb; } catch (e) { return fb; } }
    function write(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); return true; } catch (e) { toast(t('storage_err'), 'error'); return false; } }
    const save = name => write(K[name], S[name]);
    const saveSettings = () => write(K.settings, S.settings);
    function loadAll() {
        COLS.forEach(c => { const v = read(K[c], []); S[c] = Array.isArray(v) ? v : []; });
        S.settings = Object.assign({}, DEF_SETTINGS, read(K.settings, {}));
        S.profile = Object.assign({}, DEF_PROFILE, read(K.profile, {}));
    }

    /* ---------- i18n ---------- */
    const I = {
        skip: ['رفتن به محتوا', 'Skip to content'], menu: ['منو', 'Menu'], search_ph: ['جستجو...', 'Search...'],
        notifications: ['اعلان‌ها', 'Notifications'], theme_toggle: ['تغییر تم', 'Toggle theme'], profile: ['پروفایل', 'Profile'], close: ['بستن', 'Close'],
        no_notifs: ['اعلانی وجود ندارد.', 'No notifications.'], clear_notifs: ['پاک کردن', 'Clear'],
        nav_dashboard: ['داشبورد', 'Dashboard'], nav_schedule: ['برنامه روزانه', 'Daily Schedule'], nav_tasks: ['وظایف', 'Tasks'],
        nav_calendar: ['تقویم', 'Calendar'], nav_notes: ['یادداشت‌ها', 'Notes'], nav_expenses: ['مصارف', 'Expenses'],
        nav_study: ['برنامه مطالعه', 'Study Planner'], nav_sleep: ['خواب', 'Sleep'], nav_reports: ['گزارش‌ها', 'Reports'], nav_settings: ['تنظیمات', 'Settings'],
        nav_more: ['بیشتر', 'More'],
        good_morning: ['صبح بخیر', 'Good morning'], good_afternoon: ['بعد از ظهر بخیر', 'Good afternoon'], good_evening: ['شام بخیر', 'Good evening'],
        comma: ['، ', ', '], hero_sub: ['برنامه امروز خود را مدیریت کنید.', 'Manage your day.'],
        st_tasks: ['کارهای امروز', "Today's Tasks"], st_done: ['کارهای تکمیل‌شده', 'Completed Tasks'], st_study: ['ساعات مطالعه', 'Study Hours'], st_exp: ['مصارف امروز', "Today's Expenses"],
        u_task: ['کار', 'tasks'], u_done: ['تکمیل شده', 'done'], u_hour: ['ساعت', 'h'], progress: ['پیشرفت امروز', "Today's progress"],
        today_plan: ['برنامه امروز', "Today's Plan"], today_tasks: ['وظایف امروز', "Today's Tasks"], weekly: ['نمودار هفتگی', 'Weekly Chart'],
        ch_study: ['مطالعه', 'Study'], ch_tasks: ['وظایف', 'Tasks'],
        f_title: ['عنوان', 'Title'], f_desc: ['توضیحات', 'Description'], f_date: ['تاریخ', 'Date'], f_time: ['زمان', 'Time'], f_start: ['زمان شروع', 'Start Time'],
        f_end: ['زمان پایان', 'End Time'], f_type: ['نوع فعالیت', 'Activity Type'], f_priority: ['اولویت', 'Priority'], f_status: ['وضعیت', 'Status'],
        f_content: ['متن', 'Content'], f_category: ['دسته‌بندی', 'Category'], f_amount: ['مبلغ (AFN)', 'Amount (AFN)'], f_subject: ['نام درس', 'Subject'],
        f_duration: ['مدت مطالعه (دقیقه)', 'Duration (minutes)'], f_goal: ['هدف', 'Goal'], f_sleep: ['زمان خواب', 'Sleep Time'], f_wake: ['زمان بیداری', 'Wake Time'],
        f_quality: ['کیفیت خواب', 'Sleep Quality'], f_note: ['یادداشت', 'Note'],
        o_Study: ['مطالعه', 'Study'], o_Work: ['کار', 'Work'], o_University: ['دانشگاه', 'University'], o_Exercise: ['ورزش', 'Exercise'], o_Personal: ['شخصی', 'Personal'],
        o_Other: ['دیگر', 'Other'], o_Low: ['کم', 'Low'], o_Medium: ['متوسط', 'Medium'], o_High: ['زیاد', 'High'], o_Pending: ['در انتظار', 'Pending'],
        o_Completed: ['تکمیل‌شده', 'Completed'], o_Idea: ['ایده', 'Idea'], o_Food: ['غذا', 'Food'], o_Transport: ['ترانسپورت', 'Transport'], o_Education: ['تعلیم و تحصیل', 'Education'],
        o_Internet: ['انترنت', 'Internet'], o_Shopping: ['خرید', 'Shopping'], o_Health: ['صحت', 'Health'],
        o_poor: ['ضعیف', 'Poor'], o_average: ['متوسط', 'Average'], o_good: ['خوب', 'Good'], o_excellent: ['عالی', 'Excellent'],
        add: ['افزودن', 'Add'], edit: ['ویرایش', 'Edit'], delete: ['حذف', 'Delete'], cancel: ['لغو', 'Cancel'], save: ['ذخیره', 'Save'], confirm: ['تأیید', 'Confirm'], ok: ['تأیید', 'OK'],
        ent_tasks: ['وظیفه', 'Task'], ent_notes: ['یادداشت', 'Note'], ent_schedule: ['برنامه', 'Schedule Item'], ent_expenses: ['مصرف', 'Expense'], ent_study: ['درس', 'Study Plan'], ent_sleep: ['سابقه خواب', 'Sleep Record'],
        toast_added: ['{x} با موفقیت اضافه شد.', '{x} added successfully.'], toast_updated: ['{x} ویرایش شد.', '{x} updated.'], toast_deleted: ['{x} حذف شد.', '{x} deleted.'],
        confirm_delete: ['آیا مطمئن هستید که می‌خواهید این مورد را حذف کنید؟', 'Are you sure you want to delete this item?'],
        err_required: ['پر کردن این فیلد الزامی است', 'This field is required'], err_number: ['یک عدد معتبر وارد کنید', 'Enter a valid number'],
        err_positive: ['مقدار باید بیشتر از صفر باشد', 'Value must be greater than zero'], err_end: ['زمان پایان باید بعد از زمان شروع باشد', 'End time must be after start time'],
        err_sleep: ['زمان بیداری باید بعد از زمان خواب باشد (حداکثر 24 ساعت)', 'Wake time must be after sleep time (max 24 hours)'],
        empty_tasks: ['هنوز هیچ وظیفه‌ای ثبت نشده است.', 'No tasks yet.'], empty_notes: ['هنوز هیچ یادداشتی ثبت نشده است.', 'No notes yet.'],
        empty_schedule: ['برای این روز برنامه‌ای ثبت نشده است.', 'Nothing scheduled for this day.'], empty_expenses: ['هنوز هیچ مصرفی ثبت نشده است.', 'No expenses yet.'],
        empty_study: ['هنوز هیچ درسی در برنامه مطالعه نیست.', 'No study plans yet.'], empty_sleep: ['هنوز هیچ سابقه خواب ثبت نشده است.', 'No sleep records yet.'],
        empty_search: ['نتیجه‌ای پیدا نشد.', 'No results found.'],
        flt_all: ['همه', 'All'], today: ['امروز', 'Today'], prev_m: ['ماه قبل', 'Previous month'], next_m: ['ماه بعد', 'Next month'],
        cal_on: ['فعالیت‌های {d}', 'Activities on {d}'], cal_sched: ['برنامه‌ها', 'Schedule'], cal_tasks: ['وظایف', 'Tasks'],
        sum_today: ['مصارف امروز', "Today's Expenses"], sum_week: ['این هفته', 'This Week'], sum_month: ['این ماه', 'This Month'], sum_total: ['مجموع مصارف', 'Total Expenses'],
        timer: ['تایمر مطالعه', 'Study Timer'], start: ['شروع', 'Start'], pause: ['توقف', 'Pause'], resume: ['ادامه', 'Resume'], reset: ['ریست', 'Reset'],
        custom_min: ['دقیقه دلخواه', 'Custom minutes'], set: ['تنظیم', 'Set'], min_s: ['دقیقه', 'min'], today_studied: ['مطالعه امروز', 'Studied today'],
        timer_done: ['آفرین! زمان مطالعه شما تمام شد.', 'Well done! Your study time is over.'], use_timer: ['استفاده در تایمر', 'Use in timer'],
        t_idle: ['آماده', 'Ready'], t_running: ['در حال مطالعه', 'Studying'], t_paused: ['متوقف', 'Paused'], plans: ['برنامه‌های مطالعه', 'Study Plans'],
        avg_sleep: ['میانگین خواب', 'Average sleep'],
        r_tasks: ['وظایف', 'Tasks'], r_total_tasks: ['کل وظایف', 'Total Tasks'], r_completed: ['تکمیل‌شده', 'Completed'], r_pending: ['در انتظار', 'Pending'],
        r_study: ['مطالعه', 'Study'], r_total_study: ['مجموع زمان مطالعه', 'Total Study Time'], r_today_study: ['مطالعه امروز', "Today's Study"], r_week_study: ['مطالعه هفتگی', 'Weekly Study'],
        r_exp: ['مصارف', 'Expenses'], r_prod: ['بهره‌وری', 'Productivity'],
        s_profile: ['پروفایل', 'Profile'], s_name: ['نام', 'Name'], s_title: ['عنوان', 'Title'], s_appearance: ['ظاهر', 'Appearance'], light: ['حالت روشن', 'Light Mode'], dark: ['حالت تاریک', 'Dark Mode'],
        s_lang: ['زبان', 'Language'], s_notif: ['اعلان‌ها', 'Notifications'], n_enable: ['فعال‌سازی اعلان‌ها', 'Enable Notifications'], n_task: ['یادآوری وظایف', 'Task Reminders'],
        n_study: ['یادآوری مطالعه', 'Study Reminders'],
        n_note: ['توجه: یادآورها فقط وقتی کار می‌کنند که این برنامه در مرورگر باز و فعال باشد (برنامه سرور ندارد).', 'Note: reminders only work while this app is open and active in the browser (there is no server).'],
        n_unsupported: ['مرورگر شما اعلان سیستمی را پشتیبانی نمی‌کند؛ یادآورهای داخلی برنامه فعال می‌مانند.', 'Your browser does not support system notifications; in-app reminders stay active.'],
        n_denied: ['اجازه اعلان سیستمی داده نشد؛ یادآورهای داخلی فعال می‌مانند.', 'System notifications are not allowed; in-app reminders stay active.'],
        s_data: ['اطلاعات', 'Data'], export: ['خروجی گرفتن از اطلاعات', 'Export Data'], import: ['وارد کردن اطلاعات', 'Import Data'], clear_all: ['پاک کردن همه اطلاعات', 'Clear All Data'],
        confirm_import: ['با وارد کردن این فایل، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهید؟', 'Importing this file will replace your current data. Continue?'],
        confirm_clear: ['این کار تمام اطلاعات برنامه را حذف می‌کند. آیا مطمئن هستید؟', 'This will delete all app data. Are you sure?'],
        import_ok: ['اطلاعات با موفقیت وارد شد.', 'Data imported successfully.'], import_bad: ['فایل نامعتبر است.', 'Invalid file.'],
        export_ok: ['فایل پشتیبان ذخیره شد.', 'Backup file saved.'], cleared: ['همه اطلاعات حذف شد.', 'All data deleted.'],
        profile_saved: ['پروفایل ذخیره شد.', 'Profile saved.'], storage_err: ['ذخیره‌سازی ممکن نیست (حافظه مرورگر پر یا غیرفعال است).', 'Cannot save (browser storage is full or disabled).'],
        notif_new_task: ['یک وظیفه جدید برای امروز دارید.', 'You have a new task for today.'], rem_task: ['زمان انجام وظیفه شما رسیده است.', "It's time for your task."],
        rem_study: ['یادآوری: زمان مطالعه شما نزدیک است.', 'Reminder: your study time is near.'],
        w_title: ['به «زندگی من» خوش آمدید', 'Welcome to “My Life”'],
        w_sub: ['برای شروع، اطلاعات خود را وارد کنید. تمام اطلاعات فقط در همین مرورگر ذخیره می‌شود.', 'Enter your details to get started. All data stays in this browser only.'],
        w_name: ['نام و تخلص', 'Full name'], w_job: ['عنوان (مثلاً دانشجو)', 'Title (e.g. Student)'],
        w_start: ['شروع', 'Get started'], w_done: ['خوش آمدید! برنامه شما آماده است.', 'Welcome! Your app is ready.']
    };
    const t = k => { const v = I[k]; return v ? v[S.settings.lang === 'en' ? 1 : 0] : k; };
    const isFa = () => S.settings.lang !== 'en';

    const AF_MONTHS = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
    const G_FA = ['جنوری', 'فبروری', 'مارچ', 'اپریل', 'می', 'جون', 'جولای', 'اگست', 'سپتمبر', 'اکتوبر', 'نومبر', 'دسمبر'];
    const WD_FA = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
    const WD_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const wdName = d => isFa() ? WD_FA[d.getDay()] : WD_EN[d.getDay()];

    function solar(d) {
        try {
            const p = new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(d);
            const g = k => parseInt((p.find(x => x.type === k) || {}).value, 10);
            const r = { y: g('year'), m: g('month'), d: g('day') };
            return r.y && r.m && r.d ? r : null;
        } catch (e) { return null; }
    }
    function fmtDate(s) {
        if (!s) return '';
        const d = parseYmd(s);
        if (isFa()) { const p = solar(d); return p ? p.d + ' ' + AF_MONTHS[p.m - 1] + ' ' + p.y : s; }
        return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    }
    function longDate(d) {
        if (isFa()) { const p = solar(d); return WD_FA[d.getDay()] + '، ' + (p ? p.d + ' ' + AF_MONTHS[p.m - 1] + ' ' + p.y : d.toLocaleDateString('en-GB')); }
        return d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    }
    function fmtClock(d) {
        const hh = d.getHours();
        return (hh % 12 || 12) + ':' + pad(d.getMinutes()) + ' ' + (hh < 12 ? (isFa() ? 'ق.ظ' : 'AM') : (isFa() ? 'ب.ظ' : 'PM'));
    }
    const fmtDur = m => Math.floor(m / 60) + ' ' + (isFa() ? 'ساعت' : 'h') + ' ' + (m % 60) + ' ' + t('min_s');
    const fmtH = m => +(m / 60).toFixed(1) + ' ' + t('u_hour');
    const sumExp = fn => S.expenses.filter(fn).reduce((a, x) => a + (+x.amount || 0), 0);
    const sumMin = fn => S.studyLog.filter(fn).reduce((a, x) => a + (+x.minutes || 0), 0);
    const match = (item, keys) => !S.query || keys.some(k => String(item[k] || '').toLowerCase().includes(S.query.toLowerCase()));

    /* ---------- toast / modal / confirm ---------- */
    function toast(msg, type) {
        const el = h('div', { class: 'toast ' + (type || ''), role: 'status' }, (type === 'error' ? '⚠ ' : type === 'info' ? '' : '✓ ') + msg);
        $('#toasts').append(el);
        iconize(el);
        setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 320); }, 3200);
    }
    let lastFocus = null;
    function openModal(title, body, footer) {
        closeModal();
        lastFocus = document.activeElement;
        const dlg = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'modal-title' },
            h('div', { class: 'modal-head' }, h('h2', { id: 'modal-title', text: title }),
                h('button', { class: 'icon-btn', type: 'button', 'aria-label': t('close'), onclick: closeModal, text: '✕' })),
            h('div', { class: 'modal-body' }, body),
            footer ? h('div', { class: 'modal-foot' }, footer) : null);
        const bd = h('div', { class: 'backdrop', onmousedown: e => { if (e.target === bd) closeModal(); } }, dlg);
        $('#modal-root').append(bd);
        iconize(bd);
        document.body.classList.add('no-scroll');
        const f = $('[data-af]', dlg) || $('input,select,textarea', dlg);
        if (f) f.focus();
    }
    function closeModal() {
        const r = $('#modal-root');
        if (!r.firstChild) return;
        r.textContent = '';
        document.body.classList.remove('no-scroll');
        if (lastFocus && lastFocus.focus) lastFocus.focus();
    }
    function confirmDlg(msg, onOk, okText) {
        openModal(t('confirm'), h('p', { class: 'big-msg', text: msg }), [
            h('button', { class: 'btn ghost', type: 'button', 'data-af': '1', onclick: closeModal, text: t('cancel') }),
            h('button', { class: 'btn danger', type: 'button', onclick: () => { closeModal(); onOk(); }, text: okText || t('delete') })]);
    }
    function openForm({ title, fields, values, validate, onSave }) {
        const form = h('form', { class: 'form', id: 'modal-form', novalidate: true });
        const err = h('div', { class: 'form-err', role: 'alert' });
        const inputs = {};
        fields.forEach(f => {
            const id = 'f_' + f.name;
            let el;
            if (f.type === 'select') el = h('select', { id, name: f.name }, f.opts.map(o => h('option', { value: o, text: t('o_' + o) })));
            else if (f.type === 'textarea') el = h('textarea', { id, name: f.name, rows: 3 });
            else el = h('input', { id, name: f.name, type: f.type || 'text', step: f.step });
            const dv = typeof f.def === 'function' ? f.def() : f.def;
            el.value = values && values[f.name] != null ? values[f.name] : (dv != null ? dv : '');
            inputs[f.name] = el;
            form.append(h('div', { class: 'field' + (f.wide ? ' wide' : '') }, h('label', { for: id, text: t(f.label) + (f.req ? ' *' : '') }), el));
        });
        form.append(err);
        form.addEventListener('submit', e => {
            e.preventDefault();
            const data = {};
            for (const f of fields) {
                let v = inputs[f.name].value;
                if (f.type !== 'select') v = v.trim();
                if (f.req && !v) { err.textContent = t('err_required') + ': ' + t(f.label); inputs[f.name].focus(); return; }
                if (f.type === 'number') {
                    v = v === '' ? '' : Number(v);
                    if (v !== '' && (isNaN(v) || v < 0)) { err.textContent = t('err_number'); inputs[f.name].focus(); return; }
                }
                data[f.name] = v;
            }
            const m = validate && validate(data);
            if (m) { err.textContent = t(m); return; }
            onSave(data);
            closeModal();
        });
        openModal(title, form, [
            h('button', { class: 'btn ghost', type: 'button', onclick: closeModal, text: t('cancel') }),
            h('button', { class: 'btn primary', type: 'submit', form: 'modal-form', text: t('save') })]);
    }

    /* ---------- entities (CRUD) ---------- */
    const F = (name, label, type, o) => Object.assign({ name, label, type }, o);
    const ENT = {
        tasks: {
            fields: [F('title', 'f_title', 'text', { req: 1, wide: 1 }), F('description', 'f_desc', 'textarea', { wide: 1 }), F('date', 'f_date', 'date', { req: 1, def: today }),
            F('time', 'f_time', 'time'), F('priority', 'f_priority', 'select', { opts: ['Low', 'Medium', 'High'], def: 'Medium' }), F('status', 'f_status', 'select', { opts: ['Pending', 'Completed'], def: 'Pending' })]
        },
        notes: {
            fields: [F('title', 'f_title', 'text', { req: 1, wide: 1 }), F('content', 'f_content', 'textarea', { req: 1, wide: 1 }), F('date', 'f_date', 'date', { req: 1, def: today }),
            F('category', 'f_category', 'select', { opts: ['Study', 'Personal', 'Work', 'Idea', 'Other'], def: 'Personal' })]
        },
        schedule: {
            fields: [F('title', 'f_title', 'text', { req: 1, wide: 1 }), F('description', 'f_desc', 'textarea', { wide: 1 }), F('date', 'f_date', 'date', { req: 1, def: today }),
            F('type', 'f_type', 'select', { opts: ['Study', 'Work', 'University', 'Exercise', 'Personal', 'Other'], def: 'Study' }),
            F('start', 'f_start', 'time', { req: 1, def: '09:00' }), F('end', 'f_end', 'time', { req: 1, def: '10:00' })],
            validate: d => d.end <= d.start ? 'err_end' : null
        },
        expenses: {
            fields: [F('title', 'f_title', 'text', { req: 1, wide: 1 }), F('amount', 'f_amount', 'number', { req: 1, step: 'any' }), F('category', 'f_category', 'select', { opts: ['Food', 'Transport', 'Education', 'Internet', 'Shopping', 'Health', 'Other'], def: 'Food' }),
            F('date', 'f_date', 'date', { req: 1, def: today }), F('description', 'f_desc', 'textarea', { wide: 1 })],
            validate: d => d.amount <= 0 ? 'err_positive' : null
        },
        study: {
            fields: [F('subject', 'f_subject', 'text', { req: 1, wide: 1 }), F('date', 'f_date', 'date', { req: 1, def: today }), F('time', 'f_time', 'time', { def: '18:00' }),
            F('duration', 'f_duration', 'number', { req: 1, def: 60 }), F('goal', 'f_goal', 'text', { wide: 1 })],
            validate: d => d.duration <= 0 ? 'err_positive' : null
        },
        sleep: {
            fields: [F('sleep', 'f_sleep', 'datetime-local', { req: 1, def: () => ymd(addDays(new Date(), -1)) + 'T23:00' }), F('wake', 'f_wake', 'datetime-local', { req: 1, def: () => today() + 'T06:00' }),
            F('quality', 'f_quality', 'select', { opts: ['poor', 'average', 'good', 'excellent'], def: 'good' }), F('note', 'f_note', 'textarea', { wide: 1 })],
            validate: d => { const ms = new Date(d.wake) - new Date(d.sleep); return ms > 0 && ms <= 864e5 ? null : 'err_sleep'; },
            derive: d => ({ duration: Math.round((new Date(d.wake) - new Date(d.sleep)) / 60000), date: d.wake.slice(0, 10) })
        }
    };
    function openEntity(type, id, defaults) {
        const E = ENT[type], item = id ? S[type].find(x => x.id === id) : null;
        openForm({
            title: t(item ? 'edit' : 'add') + ' ' + t('ent_' + type), fields: E.fields, values: item || defaults || null, validate: E.validate,
            onSave: data => {
                if (E.derive) Object.assign(data, E.derive(data));
                if (item) { Object.assign(item, data); if (type === 'tasks') item.reminded = false; }
                else {
                    const n = Object.assign({ id: uid() }, data);
                    if (type === 'tasks') n.reminded = false;
                    S[type].unshift(n);
                    if (type === 'tasks' && n.date === today()) pushNotif('task', t('notif_new_task'), true);
                }
                save(type); refresh();
                toast(t(item ? 'toast_updated' : 'toast_added').replace('{x}', t('ent_' + type)));
            }
        });
    }
    function deleteEntity(type, id) {
        confirmDlg(t('confirm_delete'), () => {
            S[type] = S[type].filter(x => x.id !== id);
            save(type); refresh();
            toast(t('toast_deleted').replace('{x}', t('ent_' + type)));
        });
    }
    function toggleTask(id) {
        const x = S.tasks.find(i => i.id === id);
        if (!x) return;
        x.status = x.status === 'Completed' ? 'Pending' : 'Completed';
        save('tasks'); refresh();
        toast(t('toast_updated').replace('{x}', t('ent_tasks')));
    }

    /* ---------- notifications & reminders ---------- */
    function pushNotif(kind, msg, quiet) {
        S.notifs.unshift({ id: uid(), kind, msg, time: Date.now(), read: false });
        S.notifs = S.notifs.slice(0, 30);
        save('notifs'); updateBadge();
        if (!quiet) toast(msg, 'info');
        if (S.settings.notif && 'Notification' in window && Notification.permission === 'granted') {
            try { new Notification('زندگی من | Daily Life Manager', { body: msg }); } catch (e) { /* ignore */ }
        }
    }
    function updateBadge() {
        const n = S.notifs.filter(x => !x.read).length, b = $('#badge');
        b.hidden = !n; b.textContent = n;
    }
    function renderNotifPanel() {
        const p = $('#notif-panel');
        p.textContent = '';
        p.append(h('div', { class: 'np-head' }, h('strong', { text: t('notifications') }),
            S.notifs.length ? h('button', { class: 'link', type: 'button', onclick: () => { S.notifs = []; save('notifs'); updateBadge(); renderNotifPanel(); }, text: t('clear_notifs') }) : null));
        if (!S.notifs.length) p.append(h('p', { class: 'muted pad', text: t('no_notifs') }));
        S.notifs.forEach(n => p.append(h('div', { class: 'np-item' }, h('div', { text: n.msg }),
            h('small', { class: 'muted', text: new Date(n.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }))));
        iconize(p);
    }
    function toggleNotifPanel() {
        const p = $('#notif-panel'), open = p.hidden;
        if (open) { renderNotifPanel(); S.notifs.forEach(n => { n.read = true; }); save('notifs'); updateBadge(); }
        p.hidden = !open;
        $('#notif-btn').setAttribute('aria-expanded', String(open));
    }
    function closeNotifPanel() { $('#notif-panel').hidden = true; $('#notif-btn').setAttribute('aria-expanded', 'false'); }

    const remS = new Set();
    function checkReminders() {
        if (!S.settings.notif) return;
        const now = new Date(), td = today(), nowMin = now.getHours() * 60 + now.getMinutes();
        let changed = false;
        S.tasks.forEach(tk => {
            if (tk.status !== 'Pending' || tk.reminded || !tk.time || tk.date !== td) return;
            const [hh, mm] = tk.time.split(':').map(Number), diff = nowMin - (hh * 60 + mm);
            if (diff >= 0) {
                tk.reminded = true; changed = true;
                if (diff <= 10 && S.settings.taskRem) pushNotif('task', '🔔 ' + t('rem_task') + ' — ' + tk.title);
            }
        });
        if (changed) save('tasks');
        if (S.settings.studyRem) S.schedule.forEach(s => {
            if (s.type !== 'Study' || s.date !== td || remS.has(s.id + td)) return;
            const [hh, mm] = s.start.split(':').map(Number), d = hh * 60 + mm - nowMin;
            if (d >= 0 && d <= 10) { remS.add(s.id + td); pushNotif('study', t('rem_study') + ' — ' + s.title); }
        });
    }
    function setNotif(on) {
        S.settings.notif = on; saveSettings();
        if (on) {
            if (!('Notification' in window)) toast(t('n_unsupported'), 'info');
            else if (Notification.permission === 'default') Notification.requestPermission().then(p => { if (p !== 'granted') toast(t('n_denied'), 'info'); });
            else if (Notification.permission === 'denied') toast(t('n_denied'), 'info');
        }
        render();
    }

    /* ---------- study timer ---------- */
    const C = 2 * Math.PI * 54;
    const T = { total: 25 * 60, left: 25 * 60, state: 'idle', end: 0 };
    function timerToggle() {
        if (T.state === 'running') { T.left = Math.max(0, Math.ceil((T.end - Date.now()) / 1000)); T.state = 'paused'; }
        else { T.end = Date.now() + T.left * 1000; T.state = 'running'; }
        updateTimerUI();
    }
    function timerReset() { T.left = T.total; T.state = 'idle'; updateTimerUI(); }
    function setPreset(min) {
        min = Math.round(Number(min));
        if (!min || min < 1 || min > 600 || T.state === 'running') return;
        T.total = T.left = min * 60; T.state = 'idle'; updateTimerUI();
    }
    function timerTick() {
        if (T.state !== 'running') return;
        T.left = Math.max(0, Math.ceil((T.end - Date.now()) / 1000));
        updateTimerUI();
        if (T.left <= 0) timerFinish();
    }
    function timerFinish() {
        const minutes = Math.round(T.total / 60);
        T.state = 'idle'; T.left = T.total;
        S.studyLog.push({ id: uid(), date: today(), minutes });
        save('studyLog');
        pushNotif('study', t('timer_done'), true);
        refresh();
        openModal('🎉', h('p', { class: 'big-msg', text: t('timer_done') }), [h('button', { class: 'btn primary', type: 'button', 'data-af': '1', onclick: closeModal, text: t('ok') })]);
    }
    function updateTimerUI() {
        const el = $('#t-time');
        if (!el) return;
        el.textContent = pad(Math.floor(T.left / 60)) + ':' + pad(T.left % 60);
        $('#t-ring').style.strokeDashoffset = String(C * (1 - (T.total ? T.left / T.total : 0)));
        $('#t-btn').textContent = t(T.state === 'running' ? 'pause' : T.state === 'paused' ? 'resume' : 'start');
        $('#t-state').textContent = t('t_' + T.state);
        $$('.preset').forEach(b => b.classList.toggle('on', +b.dataset.min * 60 === T.total));
    }

    /* ---------- view helpers ---------- */
    const ICON = { tasks: '✅', notes: '📝', schedule: '📅', expenses: '💰', study: '📚', sleep: '😴' };
    const iconBtn = (ic, label, fn) => h('button', { class: 'icon-btn', type: 'button', 'aria-label': label, title: label, onclick: fn, text: ic });
    const actions = (type, id) => h('div', { class: 'row-actions' }, iconBtn('✏️', t('edit'), () => openEntity(type, id)), iconBtn('🗑️', t('delete'), () => deleteEntity(type, id)));
    const addLabel = type => '+ ' + t('add') + ' ' + t('ent_' + type);
    const addBtn = (type, defaults) => h('button', { class: 'btn primary', type: 'button', onclick: () => openEntity(type, null, defaults) }, addLabel(type));
    const pageHead = (key, ...acts) => h('div', { class: 'page-head' }, h('h1', { text: t(key) }), h('div', { class: 'page-actions' }, acts));
    function emptyState(type, searching, defaults) {
        return h('div', { class: 'empty' }, h('div', { class: 'empty-ic', text: ICON[type] }), h('p', { text: t(searching ? 'empty_search' : 'empty_' + type) }),
            searching ? null : h('button', { class: 'btn primary', type: 'button', onclick: () => openEntity(type, null, defaults) }, addLabel(type)));
    }
    function statCard(icon, label, value, unit) {
        return h('div', { class: 'card stat' }, h('div', { class: 'stat-ic', 'aria-hidden': 'true', text: icon }),
            h('div', null, h('div', { class: 'stat-label', text: t(label) }), h('div', { class: 'stat-val' }, String(value), unit ? h('small', { text: ' ' + t(unit) }) : null)));
    }
    function taskRow(tk) {
        const done = tk.status === 'Completed';
        return h('div', { class: 'item' + (done ? ' done' : '') },
            h('input', { type: 'checkbox', checked: done, 'aria-label': tk.title, onchange: () => toggleTask(tk.id) }),
            h('div', { class: 'item-main' }, h('div', { class: 'item-title', text: tk.title }),
                tk.description ? h('div', { class: 'item-sub', text: tk.description }) : null,
                h('div', { class: 'meta' }, h('span', { class: 'badge p-' + tk.priority, text: t('o_' + tk.priority) }),
                    h('span', { text: fmtDate(tk.date) + (tk.time ? ' · ' + tk.time : '') }),
                    h('button', { class: 'badge', type: 'button', title: t('f_status'), onclick: () => toggleTask(tk.id), text: t('o_' + tk.status) }))),
            actions('tasks', tk.id));
    }
    function timeline(items, defaults) {
        if (!items.length) return emptyState('schedule', false, defaults);
        return h('div', { class: 'tl' }, items.slice().sort((a, b) => a.start.localeCompare(b.start)).map(s =>
            h('div', { class: 'tl-item' }, h('div', { class: 'tl-time', text: s.start + ' – ' + s.end }),
                h('div', { class: 'item-main' }, h('div', { class: 'item-title', text: s.title }),
                    s.description ? h('div', { class: 'item-sub', text: s.description }) : null, h('span', { class: 'badge', text: t('o_' + s.type) })),
                actions('schedule', s.id))));
    }
    function chartCard() {
        const days = [6, 5, 4, 3, 2, 1, 0].map(i => addDays(new Date(), -i));
        const vals = days.map(d => { const k = ymd(d); return S.chart === 'study' ? sumMin(x => x.date === k) : S.tasks.filter(x => x.date === k && x.status === 'Completed').length; });
        const max = Math.max(1, ...vals);
        return h('div', { class: 'card' },
            h('div', { class: 'card-head' }, h('h2', { text: t('weekly') }),
                h('div', { class: 'seg' }, ['study', 'tasks'].map(c => h('button', { class: 'chip', type: 'button', 'aria-pressed': String(S.chart === c), onclick: () => { S.chart = c; render(); }, text: t('ch_' + c) })))),
            days.map((d, i) => h('div', { class: 'bar-row' }, h('span', { text: wdName(d) }),
                h('div', { class: 'bar-track' }, h('div', { class: 'bar-fill', style: 'width:' + (vals[i] / max * 100) + '%' })),
                h('span', { class: 'bar-val', text: S.chart === 'study' ? vals[i] + ' ' + t('min_s') : vals[i] }))));
    }

    /* ---------- views ---------- */
    function viewDashboard() {
        const td = today(), tt = S.tasks.filter(x => x.date === td), done = tt.filter(x => x.status === 'Completed').length;
        const sm = sumMin(x => x.date === td), ex = sumExp(x => x.date === td);
        const pct = tt.length ? Math.round(done / tt.length * 100) : 0;
        const hr = new Date().getHours(), g = hr < 12 ? 'good_morning' : hr < 17 ? 'good_afternoon' : 'good_evening';
        const first = (S.profile.name || '').split(' ')[0];
        return h('div', null,
            h('section', { class: 'hero card' }, h('div', null, h('h1', { text: t(g) + t('comma') + first + ' 👋' }), h('p', { text: t('hero_sub') })),
                h('div', { class: 'clock' }, h('div', { id: 'clock-time', class: 'clock-time' }), h('div', { id: 'clock-date', class: 'clock-date' }))),
            h('div', { class: 'grid stats' }, statCard('📋', 'st_tasks', tt.length, 'u_task'), statCard('✅', 'st_done', done, 'u_done'),
                statCard('📚', 'st_study', fmtH(sm)), statCard('💰', 'st_exp', num(ex) + ' AFN')),
            h('div', { class: 'card', style: 'margin-bottom:16px' }, h('div', { class: 'prog-row' }, h('span', { text: t('progress') }), h('b', { text: pct + '%' })),
                h('div', { class: 'progress', role: 'progressbar', 'aria-valuenow': String(pct), 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-label': t('progress') }, h('div', { class: 'progress-fill', style: 'width:' + pct + '%' }))),
            h('div', { class: 'grid two' },
                h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', { text: t('today_plan') }), addBtn('schedule')), timeline(S.schedule.filter(x => x.date === td), { date: td })),
                chartCard()),
            h('div', { class: 'card', style: 'margin-top:16px' }, h('div', { class: 'card-head' }, h('h2', { text: t('today_tasks') }), addBtn('tasks')),
                tt.length ? h('div', { class: 'list' }, tt.map(taskRow)) : emptyState('tasks', false)));
    }
    function viewSchedule() {
        const dateIn = h('input', { type: 'date', value: S.schedDate, 'aria-label': t('f_date'), style: 'width:auto', onchange: e => { if (e.target.value) { S.schedDate = e.target.value; render(); } } });
        return h('div', null, pageHead('nav_schedule', dateIn, addBtn('schedule', { date: S.schedDate })),
            h('div', { class: 'card' }, timeline(S.schedule.filter(x => x.date === S.schedDate), { date: S.schedDate })));
    }
    function viewTasks() {
        const list = S.tasks.filter(x => (S.taskFilter === 'all' || x.status === S.taskFilter) && match(x, ['title', 'description']));
        list.sort((a, b) => (a.status === b.status ? 0 : a.status === 'Pending' ? -1 : 1) || (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')));
        const chips = h('div', { class: 'seg' }, ['all', 'Pending', 'Completed'].map(f => h('button', { class: 'chip', type: 'button', 'aria-pressed': String(S.taskFilter === f), onclick: () => { S.taskFilter = f; render(); }, text: f === 'all' ? t('flt_all') : t('o_' + f) })));
        return h('div', null, pageHead('nav_tasks', chips, addBtn('tasks')),
            list.length ? h('div', { class: 'list' }, list.map(taskRow)) : h('div', { class: 'card' }, emptyState('tasks', !!(S.query || S.taskFilter !== 'all') && S.tasks.length > 0)));
    }
    function viewCalendar() {
        const m = S.calMonth, y = m.getFullYear(), mo = m.getMonth(), fa = isFa();
        const lead = (new Date(y, mo, 1).getDay() - (fa ? 6 : 0) + 7) % 7, days = new Date(y, mo + 1, 0).getDate();
        const names = fa ? ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const has = new Set([...S.tasks, ...S.schedule].map(x => x.date)), td = today();
        const grid = h('div', { class: 'cal-grid', role: 'group' }, names.map(n => h('div', { class: 'cal-wd', text: n })));
        for (let i = 0; i < lead; i++) grid.append(h('div'));
        for (let d = 1; d <= days; d++) {
            const key = ymd(new Date(y, mo, d));
            grid.append(h('button', {
                type: 'button', class: 'cal-day' + (key === td ? ' today' : '') + (key === S.calSel ? ' sel' : '') + (has.has(key) ? ' has' : ''),
                'aria-label': fmtDate(key), 'aria-pressed': String(key === S.calSel), onclick: () => { S.calSel = key; render(); }, text: String(d)
            }));
        }
        const title = fa ? G_FA[mo] + ' ' + y : m.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        const sel = S.calSel;
        return h('div', null, pageHead('nav_calendar'),
            h('div', { class: 'grid two' },
                h('div', { class: 'card' }, h('div', { class: 'cal-head' },
                    iconBtn(fa ? '›' : '‹', t('prev_m'), () => { S.calMonth = new Date(y, mo - 1, 1); render(); }), h('strong', { text: title }),
                    h('button', { class: 'btn sm', type: 'button', onclick: () => { S.calMonth = new Date(); S.calSel = today(); render(); }, text: t('today') }),
                    iconBtn(fa ? '‹' : '›', t('next_m'), () => { S.calMonth = new Date(y, mo + 1, 1); render(); })), grid),
                h('div', { class: 'card' }, h('h2', { text: t('cal_on').replace('{d}', fmtDate(sel)) }),
                    h('div', { class: 'card-head' }, h('strong', { text: t('cal_sched') }), addBtn('schedule', { date: sel })),
                    timeline(S.schedule.filter(x => x.date === sel), { date: sel }),
                    h('div', { class: 'card-head', style: 'margin-top:14px' }, h('strong', { text: t('cal_tasks') }), addBtn('tasks', { date: sel })),
                    (() => { const l = S.tasks.filter(x => x.date === sel); return l.length ? h('div', { class: 'list' }, l.map(taskRow)) : emptyState('tasks', false, { date: sel }); })())));
    }
    function viewNotes() {
        const list = S.notes.filter(n => match(n, ['title', 'content', 'category'])).sort((a, b) => b.date.localeCompare(a.date));
        return h('div', null, pageHead('nav_notes', addBtn('notes')),
            list.length ? h('div', { class: 'grid cards' }, list.map(n => h('div', { class: 'card note-card' },
                h('div', { class: 'card-head', style: 'margin:0' }, h('h3', { text: n.title }), actions('notes', n.id)),
                h('div', { class: 'note-body', text: n.content }),
                h('div', { class: 'note-foot' }, h('span', { class: 'badge', text: t('o_' + n.category) }), h('span', { text: fmtDate(n.date) }))))) :
                h('div', { class: 'card' }, emptyState('notes', !!S.query && S.notes.length > 0)));
    }
    function viewExpenses() {
        const list = S.expenses.filter(e => match(e, ['title', 'description', 'category'])).sort((a, b) => b.date.localeCompare(a.date));
        const sum = (k, v) => statCard('💰', k, num(v) + ' AFN');
        return h('div', null, pageHead('nav_expenses', addBtn('expenses')),
            h('div', { class: 'grid stats' }, sum('sum_today', sumExp(x => x.date === today())), sum('sum_week', sumExp(x => inWeek(x.date))), sum('sum_month', sumExp(x => inMonth(x.date))), sum('sum_total', sumExp(() => true))),
            list.length ? h('div', { class: 'list' }, list.map(e => h('div', { class: 'item' },
                h('div', { class: 'item-main' }, h('div', { class: 'item-title', text: e.title }), e.description ? h('div', { class: 'item-sub', text: e.description }) : null,
                    h('div', { class: 'meta' }, h('span', { class: 'badge', text: t('o_' + e.category) }), h('span', { text: fmtDate(e.date) }))),
                h('div', { class: 'amount', text: num(e.amount) + ' AFN' }), actions('expenses', e.id)))) :
                h('div', { class: 'card' }, emptyState('expenses', !!S.query && S.expenses.length > 0)));
    }
    function viewStudy() {
        const presets = h('div', { class: 'timer-row' }, [25, 45, 60, 90].map(m => h('button', { class: 'btn sm preset', type: 'button', 'data-min': String(m), onclick: () => setPreset(m), text: m + ' ' + t('min_s') })));
        const ring = h('div', { class: 'ring-box' });
        ring.innerHTML = '<svg viewBox="0 0 120 120" aria-hidden="true"><circle class="ring-bg" cx="60" cy="60" r="54"/><circle id="t-ring" class="ring-fg" cx="60" cy="60" r="54" stroke-dasharray="' + C + '"/></svg>';
        ring.append(h('div', { class: 'ring-center' }, h('div', { id: 't-time' }), h('small', { id: 't-state', class: 'muted' })));
        const cin = h('input', { type: 'number', min: '1', max: '600', id: 'custom-min', 'aria-label': t('custom_min'), placeholder: t('custom_min') });
        const plans = S.study.slice().sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')));
        return h('div', null, pageHead('nav_study', addBtn('study')),
            h('div', { class: 'grid two' },
                h('div', { class: 'card timer' }, h('h2', { text: t('timer') }), presets,
                    h('div', { class: 'custom' }, cin, h('button', { class: 'btn sm', type: 'button', onclick: () => setPreset(cin.value), text: t('set') })),
                    ring,
                    h('div', { class: 'timer-row' }, h('button', { class: 'btn primary', id: 't-btn', type: 'button', onclick: timerToggle }), h('button', { class: 'btn', type: 'button', onclick: timerReset, text: t('reset') })),
                    h('p', { class: 'muted', text: t('today_studied') + ': ' + fmtH(sumMin(x => x.date === today())) })),
                h('div', { class: 'card' }, h('h2', { text: t('plans') }),
                    plans.length ? h('div', { class: 'list' }, plans.map(p => h('div', { class: 'item' },
                        h('div', { class: 'item-main' }, h('div', { class: 'item-title', text: p.subject }), p.goal ? h('div', { class: 'item-sub', text: p.goal }) : null,
                            h('div', { class: 'meta' }, h('span', { class: 'badge', text: p.duration + ' ' + t('min_s') }), h('span', { text: fmtDate(p.date) + (p.time ? ' · ' + p.time : '') }),
                                h('button', { class: 'badge', type: 'button', onclick: () => { if (T.state === 'running') return; setPreset(p.duration); }, text: '⏱ ' + t('use_timer') }))),
                        actions('study', p.id)))) : emptyState('study', false))));
    }
    function viewSleep() {
        const list = S.sleep.slice().sort((a, b) => b.wake.localeCompare(a.wake));
        const avg = list.length ? Math.round(list.slice(0, 7).reduce((a, x) => a + x.duration, 0) / Math.min(7, list.length)) : 0;
        return h('div', null, pageHead('nav_sleep', addBtn('sleep')),
            list.length ? h('div', { class: 'grid stats' }, statCard('😴', 'avg_sleep', fmtDur(avg))) : null,
            list.length ? h('div', { class: 'list' }, list.map(s => h('div', { class: 'item' },
                h('div', { class: 'item-main' }, h('div', { class: 'item-title', text: fmtDur(s.duration) }),
                    h('div', { class: 'item-sub', text: fmtDate(s.sleep.slice(0, 10)) + ' ' + s.sleep.slice(11, 16) + '  →  ' + fmtDate(s.wake.slice(0, 10)) + ' ' + s.wake.slice(11, 16) }),
                    s.note ? h('div', { class: 'item-sub', text: s.note }) : null,
                    h('div', { class: 'meta' }, h('span', { class: 'badge s-' + s.quality, text: t('o_' + s.quality) }))), actions('sleep', s.id)))) :
                h('div', { class: 'card' }, emptyState('sleep', false)));
    }
    function viewReports() {
        const total = S.tasks.length, comp = S.tasks.filter(x => x.status === 'Completed').length, pct = total ? Math.round(comp / total * 100) : 0;
        const row = (k, v) => h('div', { class: 'rep-row' }, h('span', { text: t(k) }), h('b', { text: v }));
        return h('div', null, pageHead('nav_reports'),
            h('div', { class: 'grid two' },
                h('div', { class: 'card' }, h('h2', { text: t('r_prod') }),
                    h('div', { class: 'prod', style: 'background:conic-gradient(var(--primary) ' + pct * 3.6 + 'deg,var(--border) 0)' }, h('div', { class: 'prod-in' }, h('b', { text: pct + '%' }), h('small', { class: 'muted', text: t('r_prod') })))),
                h('div', { class: 'card' }, h('h2', { text: '✅ ' + t('r_tasks') }), row('r_total_tasks', total), row('r_completed', comp), row('r_pending', total - comp)),
                h('div', { class: 'card' }, h('h2', { text: '📚 ' + t('r_study') }), row('r_total_study', fmtH(sumMin(() => true))), row('r_today_study', fmtH(sumMin(x => x.date === today()))), row('r_week_study', fmtH(sumMin(x => inWeek(x.date))))),
                h('div', { class: 'card' }, h('h2', { text: '💰 ' + t('r_exp') }), row('sum_total', num(sumExp(() => true)) + ' AFN'), row('sum_today', num(sumExp(x => x.date === today())) + ' AFN'),
                    row('sum_week', num(sumExp(x => inWeek(x.date))) + ' AFN'), row('sum_month', num(sumExp(x => inMonth(x.date))) + ' AFN'))));
    }
    function viewSettings() {
        const seg = (items, cur, fn) => h('div', { class: 'seg' }, items.map(([v, label]) => h('button', { class: 'btn' + (cur === v ? ' on' : ''), type: 'button', 'aria-pressed': String(cur === v), onclick: () => fn(v), text: label })));
        const sw = (key, checked, fn) => h('label', { class: 'switch-row' }, h('span', { text: t(key) }), h('input', { type: 'checkbox', checked, onchange: e => fn(e.target.checked) }));
        const nameIn = h('input', { id: 'p-name', value: S.profile.name }), titleIn = h('input', { id: 'p-title', value: S.profile.title });
        const file = h('input', { type: 'file', accept: '.json,application/json', hidden: true, id: 'import-file', onchange: e => { importData(e.target.files[0]); e.target.value = ''; } });
        return h('div', null, pageHead('nav_settings'),
            h('div', { class: 'set-grid' },
                h('div', { class: 'card' }, h('h2', { text: '👤 ' + t('s_profile') }),
                    h('div', { class: 'form', style: 'grid-template-columns:1fr' }, h('div', { class: 'field' }, h('label', { for: 'p-name', text: t('s_name') }), nameIn), h('div', { class: 'field' }, h('label', { for: 'p-title', text: t('s_title') }), titleIn),
                        h('button', { class: 'btn primary', type: 'button', onclick: () => { S.profile.name = nameIn.value.trim() || S.profile.name; S.profile.title = titleIn.value.trim(); write(K.profile, S.profile); refresh(); toast(t('profile_saved')); }, text: t('save') }))),
                h('div', { class: 'card' }, h('h2', { text: '🎨 ' + t('s_appearance') }), seg([['light', '☀️ ' + t('light')], ['dark', '🌙 ' + t('dark')]], S.settings.theme, setTheme),
                    h('h2', { style: 'margin-top:18px', text: '🌐 ' + t('s_lang') }), seg([['fa', 'فارسی / دری'], ['en', 'English']], S.settings.lang, setLang)),
                h('div', { class: 'card' }, h('h2', { text: '🔔 ' + t('s_notif') }), sw('n_enable', S.settings.notif, setNotif),
                    sw('n_task', S.settings.taskRem, v => { S.settings.taskRem = v; saveSettings(); }), sw('n_study', S.settings.studyRem, v => { S.settings.studyRem = v; saveSettings(); }),
                    h('p', { class: 'note-small', text: t('n_note') })),
                h('div', { class: 'card' }, h('h2', { text: '💾 ' + t('s_data') }),
                    h('div', { class: 'btn-col' }, h('button', { class: 'btn', type: 'button', onclick: exportData, text: '⬇️ ' + t('export') }), file,
                        h('button', { class: 'btn', type: 'button', onclick: () => file.click(), text: '⬆️ ' + t('import') }),
                        h('button', { class: 'btn danger', type: 'button', onclick: clearData, text: '🗑️ ' + t('clear_all') })))));
    }
    const VIEWS = { dashboard: viewDashboard, schedule: viewSchedule, tasks: viewTasks, calendar: viewCalendar, notes: viewNotes, expenses: viewExpenses, study: viewStudy, sleep: viewSleep, reports: viewReports, settings: viewSettings };

    /* ---------- data: export / import / clear ---------- */
    function exportData() {
        const data = {};
        Object.values(K).forEach(k => { const v = localStorage.getItem(k); if (v !== null) { try { data[k] = JSON.parse(v); } catch (e) { /* skip */ } } });
        const blob = new Blob([JSON.stringify({ app: 'daily-life-manager', version: 1, exportedAt: new Date().toISOString(), data }, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob), a = h('a', { href: url, download: 'daily-life-backup.json' });
        document.body.append(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1500);
        toast(t('export_ok'));
    }
    function importData(file) {
        if (!file) return;
        const rd = new FileReader();
        rd.onload = () => {
            let obj = null;
            try { obj = JSON.parse(rd.result); if (obj && obj.data && typeof obj.data === 'object') obj = obj.data; } catch (e) { obj = null; }
            const keys = obj && typeof obj === 'object' ? Object.values(K).filter(k => k in obj) : [];
            if (!keys.length) { toast(t('import_bad'), 'error'); return; }
            confirmDlg(t('confirm_import'), () => {
                Object.values(K).forEach(k => localStorage.removeItem(k));
                keys.forEach(k => write(k, obj[k]));
                write(K.onboarded, 1);
                loadAll(); applyAll(); render();
                toast(t('import_ok'));
            }, t('import'));
        };
        rd.readAsText(file);
    }
    function clearData() {
        confirmDlg(t('confirm_clear'), () => {
            Object.values(K).forEach(k => localStorage.removeItem(k));
            loadAll(); applyAll(); render(); showWelcome();
        }, t('clear_all'));
    }

    /* ---------- app shell ---------- */
    function setTheme(v) { S.settings.theme = v; saveSettings(); applyTheme(); if (S.page === 'settings') render(); }
    function setLang(v) { S.settings.lang = v; saveSettings(); applyLang(); render(); }
    function applyTheme() {
        document.documentElement.dataset.theme = S.settings.theme;
        const b = $('#theme-btn');
        b.textContent = S.settings.theme === 'dark' ? '☀️' : '🌙';
        iconize(b);
    }
    function applyLang() {
        const fa = isFa();
        document.documentElement.lang = fa ? 'fa' : 'en';
        document.documentElement.dir = fa ? 'rtl' : 'ltr';
        $$('[data-i18n]').forEach(e => { e.textContent = t(e.dataset.i18n); });
        $$('[data-i18n-ph]').forEach(e => { e.placeholder = t(e.dataset.i18nPh); });
        $$('[data-i18n-label]').forEach(e => { e.setAttribute('aria-label', t(e.dataset.i18nLabel)); e.title = t(e.dataset.i18nLabel); });
        tickClock();
    }
    function applyAll() { applyTheme(); applyLang(); updateBadge(); }
    function tickClock() {
        const n = new Date(), a = $('#clock-time'), b = $('#clock-date');
        if (a) a.textContent = fmtClock(n);
        if (b) b.textContent = longDate(n);
    }
    function render() {
        const v = $('#view');
        v.textContent = '';
        v.append((VIEWS[S.page] || viewDashboard)());
        iconize(v);
        document.title = t('nav_' + S.page) + ' | زندگی من';
        $$('#nav a, #bottom-nav a').forEach(a => {
            const on = a.dataset.page === S.page;
            a.classList.toggle('active', on);
            if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
        });
        $('#more-btn').classList.toggle('active', !['dashboard', 'schedule', 'tasks', 'study'].includes(S.page));
        $('#sb-name').textContent = S.profile.name;
        $('#sb-title').textContent = S.profile.title;
        $('#sb-av').textContent = (S.profile.name || '').trim().charAt(0);
        tickClock(); updateTimerUI();
    }
    function refresh() { render(); updateBadge(); }

    const SEARCHABLE = ['tasks', 'notes', 'expenses'];
    const PAGES = Object.keys(VIEWS);
    let keepQ = false;
    function route() {
        const p = location.hash.slice(1);
        S.page = PAGES.includes(p) ? p : 'dashboard';
        if (!keepQ) { S.query = ''; $('#global-search').value = ''; }
        keepQ = false;
        closeDrawer(); render(); window.scrollTo(0, 0);
    }
    function openDrawer() { $('#sidebar').classList.add('open'); $('#overlay').hidden = false; $('#menu-btn').setAttribute('aria-expanded', 'true'); $('#more-btn').setAttribute('aria-expanded', 'true'); }
    function closeDrawer() { $('#sidebar').classList.remove('open'); $('#overlay').hidden = true; $('#menu-btn').setAttribute('aria-expanded', 'false'); $('#more-btn').setAttribute('aria-expanded', 'false'); }

    function bind() {
        $('#menu-btn').addEventListener('click', () => {
            if (window.innerWidth <= 900) { $('#sidebar').classList.contains('open') ? closeDrawer() : openDrawer(); }
            else document.body.classList.toggle('sb-collapsed');
        });
        $('#overlay').addEventListener('click', closeDrawer);
        $('#more-btn').addEventListener('click', () => { $('#sidebar').classList.contains('open') ? closeDrawer() : openDrawer(); });
        $('#nav').addEventListener('click', e => { if (e.target.closest('a')) closeDrawer(); });
        $('#bottom-nav').addEventListener('click', e => { if (e.target.closest('a')) closeDrawer(); });
        $('#theme-btn').addEventListener('click', () => setTheme(S.settings.theme === 'dark' ? 'light' : 'dark'));
        $('#notif-btn').addEventListener('click', toggleNotifPanel);
        $('#profile-btn').addEventListener('click', () => { location.hash = '#settings'; setTimeout(() => { const i = $('#p-name'); if (i) i.focus(); }, 50); });
        $('#global-search').addEventListener('input', e => {
            S.query = e.target.value.trim();
            if (S.query && !SEARCHABLE.includes(S.page)) { keepQ = true; location.hash = '#tasks'; } else render();
        });
        document.addEventListener('click', e => { if (!e.target.closest('.notif-wrap')) closeNotifPanel(); });
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') { closeModal(); closeDrawer(); closeNotifPanel(); }
            if (e.key === 'Tab') {
                const d = $('#modal-root .modal');
                if (!d) return;
                const f = $$('button,input,select,textarea,[href]', d).filter(x => !x.disabled && !x.hidden);
                if (!f.length) return;
                const a = f[0], b = f[f.length - 1];
                if (e.shiftKey && document.activeElement === a) { e.preventDefault(); b.focus(); }
                else if (!e.shiftKey && document.activeElement === b) { e.preventDefault(); a.focus(); }
            }
        });
        window.addEventListener('hashchange', route);
    }

    /* ---------- welcome / onboarding ---------- */
    function showWelcome(draft) {
        const box = $('#welcome');
        document.body.classList.add('welcome-on');
        box.hidden = false; box.textContent = '';
        const err = h('div', { class: 'form-err', role: 'alert' });
        const name = h('input', { id: 'w-name', autocomplete: 'name' }), job = h('input', { id: 'w-job' });
        if (draft) { name.value = draft.n; job.value = draft.j; }
        const langs = h('div', { class: 'seg' }, [['fa', 'فارسی / دری'], ['en', 'English']].map(([v, l]) =>
            h('button', {
                class: 'btn' + (S.settings.lang === v ? ' on' : ''), type: 'button', 'aria-pressed': String(S.settings.lang === v),
                onclick: () => { const d = { n: name.value, j: job.value }; S.settings.lang = v; applyLang(); showWelcome(d); }, text: l
            })));
        const form = h('form', { class: 'welcome-card card', novalidate: true },
            h('div', { class: 'w-logo' }, '🗓️'), h('h1', { text: t('w_title') }), h('p', { class: 'muted', text: t('w_sub') }), langs,
            h('div', { class: 'field' }, h('label', { for: 'w-name', text: t('w_name') + ' *' }), name),
            h('div', { class: 'field' }, h('label', { for: 'w-job', text: t('w_job') }), job), err,
            h('button', { class: 'btn primary w-btn', type: 'submit', text: t('w_start') }));
        form.addEventListener('submit', e => {
            e.preventDefault();
            const n = name.value.trim();
            if (!n) { err.textContent = t('err_required') + ': ' + t('w_name'); name.focus(); return; }
            S.profile = { name: n, title: job.value.trim() };
            write(K.profile, S.profile); saveSettings(); write(K.onboarded, 1);
            box.hidden = true; box.textContent = '';
            document.body.classList.remove('welcome-on');
            applyAll(); location.hash = '#dashboard'; render();
            toast(t('w_done'));
        });
        box.append(form); iconize(box); name.focus();
    }

    /* ---------- init ---------- */
    loadAll();
    applyAll();
    bind();
    route();
    iconize($('.app'));
    if (!localStorage.getItem(K.onboarded)) showWelcome();
    setInterval(tickClock, 1000);
    setInterval(timerTick, 250);
    setInterval(checkReminders, 20000);
    setTimeout(checkReminders, 1500);
})();