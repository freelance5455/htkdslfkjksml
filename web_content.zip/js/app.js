/**
 * StockPro Comercial - Lógica principal
 * 100% Offline
 */

let carrito = []; // { id, nombre, precio, cantidad, stock }
let licenciaOk = false; // actualizado por verificarLicencia()

// ==================== INICIALIZACIÓN ====================
document.addEventListener("DOMContentLoaded", () => {
  // Tema
  if (localStorage.getItem("sp_theme") === "dark") {
    document.body.classList.add("dark");
    document.getElementById("themeBtn").textContent = "☀️";
  }

  document.getElementById("themeBtn").addEventListener("click", () => {
    document.body.classList.toggle("dark");
    const isDark = document.body.classList.contains("dark");
    localStorage.setItem("sp_theme", isDark ? "dark" : "light");
    document.getElementById("themeBtn").textContent = isDark ? "☀️" : "🌙";
  });

  // Tabs
  document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(tab.dataset.panel).classList.add("active");

      // Refrescar datos al cambiar de panel
      if (tab.dataset.panel === "productos") renderProductos();
      if (tab.dataset.panel === "hoy") renderVentasHoy();
      if (tab.dataset.panel === "historial") mostrarTodoHistorial();
      if (tab.dataset.panel === "config") cargarConfigUI();
      if (tab.dataset.panel === "pos") renderProductList();
    });
  });

  // Buscador en vivo
  document.getElementById("prodSearch").addEventListener("input", e => {
    renderProductList(e.target.value.trim());
  });

  // Enter en buscador → agregar primer resultado
  document.getElementById("prodSearch").addEventListener("keydown", e => {
    if (e.key === "Enter") {
      const productos = filtrarProductos(e.target.value.trim());
      if (productos.length > 0) agregarAlCarrito(productos[0]);
    }
  });

  // Verificar licencia y cargar UI
  (async () => {
    licenciaOk = await verificarLicencia();
    cargarConfigUI();
    renderProductList();
    renderProductos();
    renderVentasHoy();
  })();

  // Fechas por defecto en historial
  const hoy = new Date().toISOString().slice(0, 10);
  document.getElementById("filtroDesde").value = hoy;
  document.getElementById("filtroHasta").value = hoy;
});

// ==================== PRODUCTOS (LISTA PARA POS) ====================
function filtrarProductos(texto) {
  const todos = DB.getProductos();
  if (!texto) return todos;
  const t = texto.toLowerCase();
  return todos.filter(p =>
    p.nombre.toLowerCase().includes(t) ||
    (p.codigo && p.codigo.toLowerCase().includes(t)) ||
    (p.categoria && p.categoria.toLowerCase().includes(t))
  );
}

function renderProductList(filtro = "") {
  const cont = document.getElementById("productList");
  const productos = filtrarProductos(filtro);

  if (productos.length === 0) {
    cont.innerHTML = `<div class="empty-msg">${filtro ? "No se encontraron productos" : "No hay productos. Ve a la pestaña Productos y agrega algunos."}</div>`;
    return;
  }

  cont.innerHTML = productos.map(p => `
    <div class="product-card ${p.stock <= 0 ? "sin-stock" : ""}" onclick="agregarAlCarrito(${JSON.stringify(p).replace(/"/g, '&quot;')})">
      <div class="name">${esc(p.nombre)}</div>
      <div class="price">${formatoDinero(p.precio)}</div>
      <div class="stock">Stock: ${p.stock || 0}</div>
    </div>
  `).join("");
}

function limpiarBusqueda() {
  document.getElementById("prodSearch").value = "";
  renderProductList();
  document.getElementById("prodSearch").focus();
}

// ==================== CARRITO ====================
function agregarAlCarrito(prod) {
  if (!licenciaOk) { alert("Licencia no válida o no cargada."); return; }

  if (prod.stock <= 0) {
    alert("Sin stock disponible");
    return;
  }

  const existente = carrito.find(c => c.id === prod.id);
  if (existente) {
    if (existente.cantidad >= prod.stock) {
      alert("No hay más stock disponible");
      return;
    }
    existente.cantidad++;
  } else {
    carrito.push({
      id: prod.id,
      nombre: prod.nombre,
      precio: prod.precio,
      cantidad: 1,
      stock: prod.stock
    });
  }

  renderCarrito();
  // Limpiar búsqueda para siguiente producto
  document.getElementById("prodSearch").value = "";
  renderProductList();
  document.getElementById("prodSearch").focus();
}

function cambiarCantidad(id, delta) {
  const item = carrito.find(c => c.id === id);
  if (!item) return;

  const nueva = item.cantidad + delta;
  if (nueva <= 0) {
    carrito = carrito.filter(c => c.id !== id);
  } else if (nueva > item.stock) {
    alert("No hay más stock");
    return;
  } else {
    item.cantidad = nueva;
  }
  renderCarrito();
}

function eliminarDelCarrito(id) {
  carrito = carrito.filter(c => c.id !== id);
  renderCarrito();
}

function vaciarCarrito() {
  if (carrito.length === 0) return;
  if (confirm("¿Vaciar el carrito?")) {
    carrito = [];
    renderCarrito();
  }
}

function actualizarTotales() {
  const subtotal = carrito.reduce((s, i) => s + i.precio * i.cantidad, 0);
  const descuento = parseFloat(document.getElementById("descuento").value) || 0;
  const total = Math.max(0, subtotal - descuento);

  document.getElementById("cartSubtotal").textContent = formatoDinero(subtotal);
  document.getElementById("cartTotal").textContent = formatoDinero(total);
  document.getElementById("cartCount").textContent = carrito.reduce((s, i) => s + i.cantidad, 0);
}

function renderCarrito() {
  const cont = document.getElementById("cartItems");

  if (carrito.length === 0) {
    cont.innerHTML = `<div class="empty-msg">Carrito vacío</div>`;
  } else {
    cont.innerHTML = carrito.map(item => `
      <div class="cart-item">
        <div class="info">
          <div class="nombre">${esc(item.nombre)}</div>
          <div class="detalle">${formatoDinero(item.precio)} × ${item.cantidad} = ${formatoDinero(item.precio * item.cantidad)}</div>
        </div>
        <div class="qty-controls">
          <button class="qty-btn" onclick="cambiarCantidad('${item.id}', -1)">−</button>
          <span class="qty">${item.cantidad}</span>
          <button class="qty-btn" onclick="cambiarCantidad('${item.id}', 1)">+</button>
          <button class="qty-btn" style="color:var(--danger);margin-left:4px;" onclick="eliminarDelCarrito('${item.id}')">✕</button>
        </div>
      </div>
    `).join("");
  }
  actualizarTotales();
}

// ==================== FINALIZAR VENTA ====================
function finalizarVenta() {
  if (!licenciaOk) { alert("Licencia no válida o no cargada."); return; }

  if (carrito.length === 0) {
    alert("El carrito está vacío");
    return;
  }

  const subtotal = carrito.reduce((s, i) => s + i.precio * i.cantidad, 0);
  const descuento = parseFloat(document.getElementById("descuento").value) || 0;
  const total = Math.max(0, subtotal - descuento);
  const gestor = document.getElementById("gestor").value.trim() || "Cajero";
  const mpago = document.getElementById("mpago").value;
  const cfg = DB.getConfig();

  const venta = {
    fecha: new Date().toISOString().slice(0, 10),
    hora: new Date().toTimeString().slice(0, 5),
    items: carrito.map(i => ({
      id: i.id,
      nombre: i.nombre,
      precio: i.precio,
      cantidad: i.cantidad,
      subtotal: i.precio * i.cantidad
    })),
    subtotal,
    descuento,
    total,
    moneda: cfg.moneda || "CUP",
    pago: mpago,
    gestor
  };

  // Descontar stock
  carrito.forEach(item => {
    DB.ajustarStock(item.id, -item.cantidad);
  });

  // Guardar venta
  DB.addVenta(venta);

  // Imprimir ticket
  imprimirTicket(venta);

  // Limpiar
  carrito = [];
  document.getElementById("descuento").value = 0;
  renderCarrito();
  renderProductList();
  renderVentasHoy();

  alert("✅ Venta registrada\nTotal: " + formatoDinero(total));
}

// ==================== IMPRESIÓN ====================
function imprimirTicket(venta) {
  const cfg = DB.getConfig();
  const logo = localStorage.getItem("sp_logo");

  const ticketLogo = document.getElementById("ticketLogo");
  if (logo) {
    ticketLogo.src = logo;
    ticketLogo.style.display = "block";
  } else {
    ticketLogo.style.display = "none";
  }

  document.getElementById("ticketTitle").textContent = (cfg.nombre || "TIENDA").toUpperCase();
  document.getElementById("ticketFechaHora").textContent = `${venta.fecha}  ${venta.hora}`;

  document.getElementById("ticketItems").innerHTML = venta.items.map(i => `
    <tr>
      <td>${i.cantidad}</td>
      <td>${esc(i.nombre)}</td>
      <td>${formatoDinero(i.subtotal)}</td>
    </tr>
  `).join("");

  document.getElementById("ticketSubtotal").textContent = formatoDinero(venta.subtotal);
  if (venta.descuento > 0) {
    document.getElementById("ticketDescuentoRow").style.display = "block";
    document.getElementById("ticketDescuento").textContent = "-" + formatoDinero(venta.descuento);
  } else {
    document.getElementById("ticketDescuentoRow").style.display = "none";
  }
  document.getElementById("ticketTotal").textContent = formatoDinero(venta.total) + " " + (venta.moneda || "");
  document.getElementById("ticketPago").textContent = venta.pago;
  document.getElementById("ticketGestor").textContent = venta.gestor;

  const area = document.getElementById("ticketPrintArea");
  area.style.display = "block";
  window.print();
  area.style.display = "none";
}

// ==================== CATÁLOGO DE PRODUCTOS ====================
function renderProductos() {
  const tbody = document.getElementById("tablaProductos");
  const productos = DB.getProductos();

  if (productos.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-msg">No hay productos registrados</td></tr>`;
    return;
  }

  tbody.innerHTML = productos.map(p => `
    <tr>
      <td>${esc(p.codigo || "—")}</td>
      <td>${esc(p.nombre)}</td>
      <td>${formatoDinero(p.precio)}</td>
      <td>${p.stock || 0}</td>
      <td>${esc(p.categoria || "—")}</td>
      <td>
        <button class="btn btn-sm btn-outline" onclick="editarProducto('${p.id}')">✏️</button>
        <button class="btn btn-sm btn-danger" onclick="eliminarProducto('${p.id}')">🗑️</button>
      </td>
    </tr>
  `).join("");
}

function mostrarFormProducto(prod = null) {
  document.getElementById("formProducto").style.display = "block";
  document.getElementById("formProductoTitulo").textContent = prod ? "Editar Producto" : "Nuevo Producto";

  document.getElementById("prodId").value = prod ? prod.id : "";
  document.getElementById("prodNombre").value = prod ? prod.nombre : "";
  document.getElementById("prodCodigo").value = prod ? (prod.codigo || "") : "";
  document.getElementById("prodPrecio").value = prod ? prod.precio : "";
  document.getElementById("prodStock").value = prod ? (prod.stock || 0) : 0;
  document.getElementById("prodCategoria").value = prod ? (prod.categoria || "") : "";
  document.getElementById("prodCosto").value = prod ? (prod.costo || "") : "";
}

function ocultarFormProducto() {
  document.getElementById("formProducto").style.display = "none";
}

function guardarProducto() {
  const id = document.getElementById("prodId").value;
  const nombre = document.getElementById("prodNombre").value.trim();
  const precio = parseFloat(document.getElementById("prodPrecio").value);

  if (!nombre) return alert("El nombre es obligatorio");
  if (isNaN(precio) || precio < 0) return alert("Precio inválido");

  const data = {
    nombre,
    codigo: document.getElementById("prodCodigo").value.trim(),
    precio,
    stock: parseInt(document.getElementById("prodStock").value) || 0,
    categoria: document.getElementById("prodCategoria").value.trim(),
    costo: parseFloat(document.getElementById("prodCosto").value) || 0
  };

  if (id) {
    DB.updateProducto(id, data);
  } else {
    DB.addProducto(data);
  }

  ocultarFormProducto();
  renderProductos();
  renderProductList();
}

function editarProducto(id) {
  const prod = DB.getProducto(id);
  if (prod) mostrarFormProducto(prod);
}

function eliminarProducto(id) {
  if (confirm("¿Eliminar este producto?")) {
    DB.deleteProducto(id);
    renderProductos();
    renderProductList();
  }
}

// ==================== VENTAS DE HOY ====================
function renderVentasHoy() {
  const ventas = DB.getVentasHoy();
  const tbody = document.getElementById("tablaHoy");

  document.getElementById("hoyCantidad").textContent = ventas.length;
  const total = ventas.reduce((s, v) => s + v.total, 0);
  document.getElementById("hoyTotal").textContent = formatoDinero(total);

  if (ventas.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-msg">No hay ventas hoy</td></tr>`;
    return;
  }

  tbody.innerHTML = ventas.map(v => `
    <tr>
      <td>${v.hora}</td>
      <td>${v.items.map(i => `${i.cantidad}× ${esc(i.nombre)}`).join(", ")}</td>
      <td>${formatoDinero(v.total)}</td>
      <td>${v.pago}</td>
      <td>${esc(v.gestor)}</td>
      <td><button class="btn btn-sm btn-outline" onclick='reimprimirTicket(${JSON.stringify(v).replace(/'/g, "&#39;")})'>🖨️</button></td>
    </tr>
  `).join("");
}

function reimprimirTicket(venta) {
  imprimirTicket(venta);
}

// ==================== HISTORIAL ====================
function filtrarHistorial() {
  const desde = document.getElementById("filtroDesde").value;
  const hasta = document.getElementById("filtroHasta").value;
  const ventas = DB.getVentasRango(desde, hasta);
  renderHistorial(ventas);
}

function mostrarTodoHistorial() {
  renderHistorial(DB.getVentas());
}

function renderHistorial(ventas) {
  const tbody = document.getElementById("tablaHistorial");
  document.getElementById("histCantidad").textContent = ventas.length;
  document.getElementById("histTotal").textContent = formatoDinero(ventas.reduce((s, v) => s + v.total, 0));

  if (ventas.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-msg">No hay ventas en este rango</td></tr>`;
    return;
  }

  tbody.innerHTML = ventas.map(v => `
    <tr>
      <td>${v.fecha}</td>
      <td>${v.hora}</td>
      <td>${v.items.map(i => `${i.cantidad}× ${esc(i.nombre)}`).join(", ")}</td>
      <td>${formatoDinero(v.total)}</td>
      <td>${v.pago}</td>
      <td>${esc(v.gestor)}</td>
    </tr>
  `).join("");
}

// ==================== CONFIGURACIÓN ====================
function cargarConfigUI() {
  const cfg = DB.getConfig();
  document.getElementById("cfgNombre").value = cfg.nombre || "";
  document.getElementById("cfgMoneda").value = cfg.moneda || "CUP";

  const logo = localStorage.getItem("sp_logo");
  const img = document.getElementById("logoPreview");
  const btnQuitar = document.getElementById("btnQuitarLogo");
  if (logo) {
    img.src = logo;
    img.style.display = "block";
    btnQuitar.style.display = "inline-flex";
  } else {
    img.style.display = "none";
    btnQuitar.style.display = "none";
  }

  verificarLicencia().then(ok => { licenciaOk = ok; }); // actualiza info de licencia
}

function guardarConfig() {
  const cfg = {
    nombre: document.getElementById("cfgNombre").value.trim() || "Mi Tienda",
    moneda: document.getElementById("cfgMoneda").value
  };
  DB.saveConfig(cfg);
  alert("✅ Configuración guardada");
}

function guardarLogo(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 500000) {
    alert("La imagen es muy pesada. Usa una de menos de 500 KB.");
    return;
  }
  const reader = new FileReader();
  reader.onload = e => {
    localStorage.setItem("sp_logo", e.target.result);
    cargarConfigUI();
    alert("✅ Logo guardado");
  };
  reader.readAsDataURL(file);
}

function quitarLogo() {
  localStorage.removeItem("sp_logo");
  cargarConfigUI();
}

// ==================== BACKUP ====================
function exportarBackup() {
  const data = DB.exportarTodo();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `stockpro_backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
}

function importarBackup(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!confirm("¿Importar este backup?\nSe reemplazarán los productos y ventas actuales.")) return;

  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      DB.importarTodo(data);
      alert("✅ Backup importado correctamente");
      location.reload();
    } catch (err) {
      alert("❌ Error al importar: archivo inválido");
    }
  };
  reader.readAsText(file);
  event.target.value = "";
}

function confirmarBorrarDatos() {
  if (!confirm("⚠️ ¿Está seguro de borrar TODOS los productos y ventas?\nEsta acción no se puede deshacer fácilmente.")) return;
  if (!confirm("Última confirmación: se borrarán todos los datos (excepto la licencia).")) return;
  DB.borrarTodo();
  carrito = [];
  alert("Datos borrados");
  location.reload();
}

// ==================== UTILIDADES ====================
function formatoDinero(n) {
  const cfg = DB.getConfig();
  const num = Number(n) || 0;
  return "$" + num.toFixed(2);
}

function esc(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
