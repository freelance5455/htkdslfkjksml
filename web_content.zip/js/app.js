
let data = getData();
let currentSubjectId = null;
let confirmCallback = null;
let activeFileUrl = null;

const AVAILABLE_THEMES = ["dark", "light", "ocean", "emerald"];

const THEME_COLORS = {
    dark: "#101426",
    light: "#f3f5fa",
    ocean: "#081b2b",
    emerald: "#0d211b"
};

// إنشاء معرف فريد
function makeId() {
    return Date.now().toString(36) +
        Math.random().toString(36).slice(2, 8);
}

// حماية النصوص المعروضة
function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

// الإشعارات
function notify(message) {
    const toast = document.getElementById("toast");
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => {
        toast.classList.remove("show");
    }, 2500);
}

// ================================
// نظام الثيمات
// ================================

// التأكد من صحة اسم الثيم
function getValidTheme(theme) {
    return AVAILABLE_THEMES.includes(theme) ? theme : "dark";
}

// تطبيق الثيم على الموقع
function applyTheme(theme) {
    const selectedTheme = getValidTheme(theme);

    document.documentElement.setAttribute(
        "data-theme",
        selectedTheme
    );

    const metaTheme = document.getElementById("themeColorMeta");

    if (metaTheme) {
        metaTheme.content = THEME_COLORS[selectedTheme];
    }

    const themeSelect = document.getElementById("themeSelect");

    if (themeSelect) {
        themeSelect.value = selectedTheme;
    }

    document.querySelectorAll(".theme-preview").forEach(button => {
        const isActive = button.classList.contains(
            `theme-${selectedTheme}`
        );

        button.classList.toggle("selected", isActive);
        button.setAttribute("aria-pressed", String(isActive));
    });

    return selectedTheme;
}

// تغيير الثيم وحفظه تلقائيًا
function changeTheme(theme) {
    const selectedTheme = getValidTheme(theme);

    if (!data.settings || typeof data.settings !== "object") {
        data.settings = {};
    }

    data.settings.theme = selectedTheme;

    applyTheme(selectedTheme);
    saveData(data);

    notify("تم تغيير الثيم وحفظ اختيارك 🎨");
}

// استرجاع الثيم المحفوظ
function initializeTheme() {
    if (!data.settings || typeof data.settings !== "object") {
        data.settings = {};
    }

    const savedTheme = getValidTheme(data.settings.theme);

    data.settings.theme = savedTheme;

    applyTheme(savedTheme);
}

// ================================
// التأكيدات والنوافذ
// ================================

function askConfirm(title, message, buttonText = "تأكيد", danger = false) {
    return new Promise(resolve => {
        confirmCallback = resolve;

        document.getElementById("confirmTitle").textContent = title;
        document.getElementById("confirmMessage").textContent = message;

        const yesButton = document.getElementById("confirmYes");

        yesButton.textContent = buttonText;
        yesButton.style.background = danger ? "#a83f58" : "";

        document.getElementById("confirmModal").classList.add("show");
    });
}

function resolveConfirm(answer) {
    document.getElementById("confirmModal").classList.remove("show");

    if (confirmCallback) {
        const callback = confirmCallback;
        confirmCallback = null;
        callback(answer);
    }
}

function closeModal(id) {
    document.getElementById(id).classList.remove("show");
}

// ================================
// تسجيل الدخول
// ================================

function login() {
    const name = document.getElementById("userName").value.trim();
    const gender = document.getElementById("userGender").value;

    if (!name) {
        notify("اكتب اسمك الأول ❤️");
        return;
    }

    data.user = { name, gender };

    saveData(data);
    showApp();
}

// عرض التطبيق
function showApp() {
    if (!data.user) return;

    document.getElementById("loginScreen").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");

    applyTheme(data.settings?.theme);

    document.getElementById("headerName").textContent = data.user.name;

    document.getElementById("welcomeMessage").textContent =
        data.user.gender === "female"
        ? `أنتِ قدها يا ${data.user.name}! 💜`
        : `أنت قدها يا ${data.user.name}! 💜`;

    document.getElementById("settingsName").value = data.user.name;
    document.getElementById("settingsGender").value = data.user.gender;

    renderAll();
}

// تسجيل الخروج
function logout() {
    document.getElementById("app").classList.add("hidden");
    document.getElementById("loginScreen").classList.remove("hidden");

    document.getElementById("userName").value = data.user?.name || "";
    document.getElementById("userGender").value =
        data.user?.gender || "male";

    applyTheme(data.settings?.theme);
}

// ================================
// التنقل
// ================================

function navigate(pageId, button) {
    document.querySelectorAll(".page").forEach(page => {
        page.classList.remove("active");
    });

    document.getElementById(pageId).classList.add("active");

    document.querySelectorAll(".nav-btn").forEach(btn => {
        btn.classList.remove("active");
    });

    button.classList.add("active");

    renderAll();
}

// ================================
// المواد
// ================================

function openSubjectModal() {
    document.getElementById("subjectName").value = "";
    document.getElementById("subjectModal").classList.add("show");
}

function addSubject() {
    const name = document.getElementById("subjectName").value.trim();

    if (!name) {
        notify("اكتب اسم المادة");
        return;
    }

    data.subjects.push({
        id: makeId(),
        name,
        lessons: []
    });

    saveData(data);
    closeModal("subjectModal");
    renderAll();

    notify("تم إنشاء المادة بنجاح 📚");
}

// ================================
// الدروس
// ================================

function openLessonModal(subjectId) {
    currentSubjectId = subjectId;

    document.getElementById("lessonName").value = "";
    document.getElementById("lessonNotes").value = "";
    document.getElementById("lessonFile").value = "";

    document.getElementById("lessonModal").classList.add("show");
}

// إضافة درس
async function addLesson() {
    const name = document.getElementById("lessonName").value.trim();
    const notes = document.getElementById("lessonNotes").value.trim();
    const fileInput = document.getElementById("lessonFile");
    const file = fileInput.files[0];

    if (!name) {
        notify("اكتب اسم الدرس");
        return;
    }

    if (file && !(
        file.type === "application/pdf" ||
        file.type.startsWith("image/")
    )) {
        notify("نوع الملف غير مدعوم");
        return;
    }

    if (file && file.size > 15 * 1024 * 1024) {
        notify("حجم الملف أكبر من 15 ميجابايت");
        return;
    }

    const subject = data.subjects.find(
        item => item.id === currentSubjectId
    );

    if (!subject) return;

    const button = document.getElementById("addLessonBtn");

    button.disabled = true;
    button.textContent = "جاري الحفظ...";

    const lessonId = makeId();

    try {
        if (file) {
            await saveAttachment(lessonId, file);
        }

        subject.lessons.push({
            id: lessonId,
            name,
            notes,
            completed: false,
            completedAt: null,
            attachment: file ? {
                name: file.name,
                type: file.type,
                size: file.size
            } : null
        });

        saveData(data);

        closeModal("lessonModal");
        renderAll();

        notify("تم حفظ الدرس بنجاح 📖");

    } catch (error) {
        console.error(error);
        notify("تعذر حفظ الملف. حاول مرة أخرى.");
    } finally {
        button.disabled = false;
        button.textContent = "حفظ الدرس";
    }
}

// ================================
// الإنجازات
// ================================

// إكمال الدرس
async function completeLesson(subjectId, lessonId) {
    const subject = data.subjects.find(
        item => item.id === subjectId
    );

    const lesson = subject?.lessons.find(
        item => item.id === lessonId
    );

    if (!lesson || lesson.completed) return;

    const accepted = await askConfirm(
        "تأكيد إنهاء الدرس",
        `هل أنت متأكد يا ${data.user.name} إنك خلصت درس "${lesson.name}"؟ سيتم تسجيل الإنجاز وإضافة 10 نقاط.`,
        "نعم، أنهيت الدرس"
    );

    if (!accepted) return;

    lesson.completed = true;
    lesson.completedAt = new Date().toISOString();

    data.points += 10;

    data.achievements.unshift({
        id: makeId(),
        title: "إنهاء درس: " + lesson.name,
        type: "lesson",
        lessonId: lesson.id,
        date: lesson.completedAt,
        points: 10
    });

    saveData(data);
    renderAll();
    showCelebration();
}

// التراجع عن الإنجاز
async function undoLesson(subjectId, lessonId) {
    const subject = data.subjects.find(
        item => item.id === subjectId
    );

    const lesson = subject?.lessons.find(
        item => item.id === lessonId
    );

    if (!lesson || !lesson.completed) return;

    const accepted = await askConfirm(
        "إلغاء إنجاز الدرس",
        `هل تريد إعادة "${lesson.name}" إلى قائمة الدروس غير المكتملة؟`,
        "إلغاء الإنجاز"
    );

    if (!accepted) return;

    const index = data.achievements.findIndex(
        item => item.type === "lesson" &&
        item.lessonId === lesson.id
    );

    if (index !== -1) {
        data.points = Math.max(
            0,
            data.points - data.achievements[index].points
        );

        data.achievements.splice(index, 1);
    }

    lesson.completed = false;
    lesson.completedAt = null;

    saveData(data);
    renderAll();

    notify("تم إلغاء الإنجاز");
}

// حذف درس
async function deleteLesson(subjectId, lessonId) {
    const subject = data.subjects.find(
        item => item.id === subjectId
    );

    const lesson = subject?.lessons.find(
        item => item.id === lessonId
    );

    if (!lesson) return;

    const accepted = await askConfirm(
        "حذف الدرس",
        `هل أنت متأكد من حذف "${lesson.name}"؟ سيتم حذف ملفاته وسجل إنجازه أيضاً.`,
        "حذف الدرس",
        true
    );

    if (!accepted) return;

    if (lesson.completed) {
        const index = data.achievements.findIndex(
            item => item.type === "lesson" &&
            item.lessonId === lesson.id
        );

        if (index !== -1) {
            data.points = Math.max(
                0,
                data.points - data.achievements[index].points
            );

            data.achievements.splice(index, 1);
        }
    }

    try {
        await deleteAttachment(lesson.id);
    } catch (error) {
        console.error(error);
    }

    subject.lessons = subject.lessons.filter(
        item => item.id !== lessonId
    );

    saveData(data);
    renderAll();

    notify("تم حذف الدرس");
}

// حذف مادة
async function deleteSubject(subjectId) {
    const subject = data.subjects.find(
        item => item.id === subjectId
    );

    if (!subject) return;

    const accepted = await askConfirm(
        "حذف المادة",
        `سيتم حذف مادة "${subject.name}" وكل دروسها ومرفقاتها وإنجازاتها. هل تريد المتابعة؟`,
        "حذف المادة",
        true
    );

    if (!accepted) return;

    for (const lesson of subject.lessons) {
        if (lesson.completed) {
            const index = data.achievements.findIndex(
                item => item.type === "lesson" &&
                item.lessonId === lesson.id
            );

            if (index !== -1) {
                data.points = Math.max(
                    0,
                    data.points - data.achievements[index].points
                );

                data.achievements.splice(index, 1);
            }
        }

        try {
            await deleteAttachment(lesson.id);
        } catch (error) {
            console.error(error);
        }
    }

    data.subjects = data.subjects.filter(
        item => item.id !== subjectId
    );

    saveData(data);
    renderAll();

    notify("تم حذف المادة");
}

// ================================
// المرفقات
// ================================

async function openAttachment(lessonId) {
    try {
        const attachment = await getAttachment(lessonId);

        if (!attachment) {
            notify("الملف غير موجود");
            return;
        }

        if (activeFileUrl) {
            URL.revokeObjectURL(activeFileUrl);
        }

        activeFileUrl = URL.createObjectURL(attachment.file);

        const opened = window.open(activeFileUrl, "_blank");

        if (!opened) {
            notify("اسمح بفتح النوافذ المنبثقة لعرض الملف");
        }

    } catch (error) {
        console.error(error);
        notify("تعذر فتح الملف");
    }
}

// ================================
// رسالة التحفيز
// ================================

function showCelebration() {
    const name = data.user.name;
    const female = data.user.gender === "female";

    document.getElementById("celebrationMessage").textContent =
        female
        ? `عاش يا ${name}! 💜 خلصتي درس جديد. استمري، أنتِ بتتقدمي!`
        : `عاش يا ${name}! 💜 خلصت درس جديد. استمر، أنت بتتقدم!`;

    document.getElementById("celebrationModal").classList.add("show");
}

// ================================
// عرض المواد
// ================================

function renderSubjects() {
    const container = document.getElementById("subjectsList");

    if (!data.subjects.length) {
        container.innerHTML = `
            <div class="empty-state">
                مفيش مواد لسه. أضف أول مادة 📚
            </div>
        `;
        return;
    }

    container.innerHTML = data.subjects.map(subject => {
        const completed = subject.lessons.filter(
            lesson => lesson.completed
        ).length;

        const percent = subject.lessons.length
            ? Math.round(completed / subject.lessons.length * 100)
            : 0;

        const lessonsHTML = subject.lessons.length
            ? subject.lessons.map(lesson => {
                const notesHTML = lesson.notes
                    ? `<div class="lesson-notes">${escapeHTML(lesson.notes)}</div>`
                    : "";

                const fileHTML = lesson.attachment
                    ? `
                        <div class="lesson-file">
                            <button class="file-btn"
                                onclick="openAttachment('${lesson.id}')">
                                📎 فتح ${escapeHTML(lesson.attachment.name)}
                            </button>
                        </div>
                    `
                    : "";

                return `
                    <div class="lesson-item ${lesson.completed ? "done" : ""}">
                        <div class="lesson-name">
                            ${lesson.completed ? "✅" : "📖"}
                            ${escapeHTML(lesson.name)}
                        </div>

                        ${notesHTML}
                        ${fileHTML}

                        <div class="lesson-controls">
                            ${
                                lesson.completed
                                ? `
                                    <button class="lesson-done-btn undo-btn"
                                        onclick="undoLesson('${subject.id}','${lesson.id}')">
                                        إلغاء الإنجاز
                                    </button>
                                `
                                : `
                                    <button class="lesson-done-btn"
                                        onclick="completeLesson('${subject.id}','${lesson.id}')">
                                        أنهيت الدرس
                                    </button>
                                `
                            }

                            <button class="delete-lesson-btn"
                                onclick="deleteLesson('${subject.id}','${lesson.id}')"
                                title="حذف الدرس">
                                🗑️
                            </button>
                        </div>
                    </div>
                `;
            }).join("")
            : `<p>لسه مفيش دروس في المادة.</p>`;

        return `
            <div class="subject-card">
                <h3>📘 ${escapeHTML(subject.name)}</h3>

                <p>${completed} من ${subject.lessons.length} درس مكتمل</p>

                <div class="progress-track">
                    <div class="progress-bar" style="width:${percent}%"></div>
                </div>

                ${lessonsHTML}

                <div class="subject-actions">
                    <button class="secondary-btn"
                        onclick="openLessonModal('${subject.id}')">
                        + إضافة درس
                    </button>

                    <button class="secondary-btn"
                        onclick="deleteSubject('${subject.id}')">
                        حذف المادة
                    </button>
                </div>
            </div>
        `;
    }).join("");
}

// ================================
// عرض الإنجازات
// ================================

function renderAchievements() {
    document.getElementById("achievementPoints").textContent = data.points;

    const container = document.getElementById("achievementsList");

    if (!data.achievements.length) {
        container.innerHTML = `
            <div class="empty-state">
                إنجازاتك هتظهر هنا بعد أول درس 💪
            </div>
        `;
        return;
    }

    container.innerHTML = data.achievements.map(item => `
        <div class="achievement-item">
            <strong>🏆 ${escapeHTML(item.title)}</strong>
            <div style="color:var(--muted);margin-top:5px">
                ${new Date(item.date).toLocaleString("ar-EG")}
                · +${item.points} XP
            </div>
        </div>
    `).join("");
}

// ================================
// الرئيسية
// ================================

function renderDashboard() {
    const lessons = data.subjects.flatMap(
        subject => subject.lessons
    );

    const completed = lessons.filter(
        lesson => lesson.completed
    ).length;

    const percent = lessons.length
        ? Math.round(completed / lessons.length * 100)
        : 0;

    document.getElementById("subjectsCount").textContent =
        data.subjects.length;

    document.getElementById("completedCount").textContent =
        completed;

    document.getElementById("pointsCount").textContent =
        data.points;

    document.getElementById("examsCount").textContent =
        data.achievements.filter(item => item.type === "exam").length;

    document.getElementById("progressPercent").textContent =
        percent + "%";

    document.getElementById("progressBar").style.width =
        percent + "%";

    const recent = document.getElementById("recentAchievements");

    if (!data.achievements.length) {
        recent.textContent = "لسه مفيش إنجازات. ابدأ أول درس! 💪";
    } else {
        recent.innerHTML = data.achievements.slice(0, 3).map(item => `
            <div class="achievement-item">
                🏆 ${escapeHTML(item.title)}
                <span style="color:var(--success)">
                    +${item.points} XP
                </span>
            </div>
        `).join("");
    }
}

function renderAll() {
    renderDashboard();
    renderSubjects();
    renderAchievements();
}

// ================================
// إعدادات المستخدم
// ================================

function saveSettings() {
    const name = document.getElementById("settingsName").value.trim();
    const gender = document.getElementById("settingsGender").value;

    if (!name) {
        notify("اكتب اسم المستخدم");
        return;
    }

    data.user.name = name;
    data.user.gender = gender;

    saveData(data);
    showApp();

    notify("تم حفظ الإعدادات ❤️");
}

// ================================
// إعادة ضبط البيانات
// ================================

async function resetData() {
    const accepted = await askConfirm(
        "حذف جميع البيانات",
        "سيتم حذف حساب التجربة والمواد والدروس والملفات والإنجازات نهائياً من هذا المتصفح. هل أنت متأكد؟",
        "حذف الكل",
        true
    );

    if (!accepted) return;

    localStorage.removeItem(STORAGE_KEY);

    try {
        const db = await openFilesDB();

        await new Promise((resolve, reject) => {
            const transaction = db.transaction(STORE_NAME, "readwrite");

            transaction.objectStore(STORE_NAME).clear();

            transaction.oncomplete = resolve;
            transaction.onerror = () => reject(transaction.error);
        });

        db.close();

    } catch (error) {
        console.error(error);
    }

    location.reload();
}

// ================================
// تشغيل التطبيق
// ================================

document.addEventListener("DOMContentLoaded", () => {
    data = getData();

    initializeTheme();

    if (data.user) {
        showApp();
    }
});
