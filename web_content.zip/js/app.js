/**
 * STUDY VERSE — Main Application Logic
 */

(function () {
  'use strict';

  // ---------- Storage helpers ----------
  const STORAGE_KEY = 'studyverse_data_v1';

  function defaultData() {
    return {
      notes: [],
      decks: [
        { id: 'deck_bio', name: 'Biology' },
        { id: 'deck_chem', name: 'Chemistry' },
        { id: 'deck_hist', name: 'History' },
        { id: 'deck_math', name: 'Math' },
      ],
      cards: getSampleCards(),
      tasks: [],
      exams: [],
      goalMinutes: 60,
      studyLog: {}, // { "YYYY-MM-DD": minutes }
      quizHistory: [], // { subject, score, total, date }
      activity: [],
      settings: { reduceMotion: false, geminiKey: '', geminiModel: 'gemini-2.0-flash' },
      lastStudyDate: null,
      streak: 0,
      googleQuestions: [],
    };
  }

  function getSampleCards() {
    const now = Date.now();
    return [
      { id: 'c1', deckId: 'deck_bio', front: 'What is photosynthesis?', back: 'Process by which green plants convert light energy into chemical energy (glucose) using CO₂ and H₂O.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c2', deckId: 'deck_bio', front: 'What is the powerhouse of the cell?', back: 'Mitochondria — produces ATP through cellular respiration.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c3', deckId: 'deck_bio', front: 'What is DNA?', back: 'Deoxyribonucleic acid — molecule that carries genetic instructions for development and function.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c4', deckId: 'deck_chem', front: 'What is the atomic number of Carbon?', back: '6 — it has 6 protons.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c5', deckId: 'deck_chem', front: 'What is pH?', back: 'A scale (0–14) measuring how acidic or basic a solution is. 7 is neutral.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c6', deckId: 'deck_chem', front: 'What is a mole?', back: '6.022 × 10²³ particles (Avogadro\'s number). Unit for amount of substance.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c7', deckId: 'deck_hist', front: 'When did World War II end?', back: '1945 (in Europe: May 8; in Asia: September 2 after Japan surrendered).', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c8', deckId: 'deck_hist', front: 'Who was the first President of the United States?', back: 'George Washington (1789–1797).', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c9', deckId: 'deck_math', front: 'What is the Pythagorean theorem?', back: 'In a right triangle: a² + b² = c², where c is the hypotenuse.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c10', deckId: 'deck_math', front: 'What is the derivative of x²?', back: '2x (power rule: d/dx[xⁿ] = n·xⁿ⁻¹).', interval: 1, ease: 2.5, due: now, reps: 0 },
    ];
  }

  function loadData() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultData();
      const data = JSON.parse(raw);
      // Merge with defaults for any missing keys
      const def = defaultData();
      return { ...def, ...data, settings: { ...def.settings, ...(data.settings || {}) } };
    } catch (e) {
      console.warn('Failed to load data, using defaults', e);
      return defaultData();
    }
  }

  function saveData() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      return true;
    } catch (error) {
      console.warn('Study Verse could not save data locally:', error);
      const message = error && (error.name === 'QuotaExceededError' || error.code === 22)
        ? 'Device storage is full. Export a backup and remove some stored data.'
        : 'Browser storage is unavailable. Your latest changes may not persist.';
      showStorageWarning(message);
      return false;
    }
  }

  function showStorageWarning(message) {
    let notice = document.getElementById('storageWarning');
    if (!notice) {
      notice = document.createElement('div');
      notice.id = 'storageWarning';
      notice.className = 'storage-warning';
      notice.setAttribute('role', 'status');
      document.body.appendChild(notice);
    }
    notice.textContent = message;
  }

  let state = loadData();

  // ---------- Quiz bank (built-in) ----------
  const QUIZ_BANK = {
    Biology: [
      { q: 'Which organelle is responsible for photosynthesis?', options: ['Mitochondria', 'Chloroplast', 'Nucleus', 'Ribosome'], answer: 1, explain: 'Chloroplasts contain chlorophyll and carry out photosynthesis in plant cells.' },
      { q: 'What is the basic unit of life?', options: ['Atom', 'Tissue', 'Cell', 'Organ'], answer: 2, explain: 'The cell is the smallest structural and functional unit of living organisms.' },
      { q: 'Which blood cells fight infection?', options: ['Red blood cells', 'White blood cells', 'Platelets', 'Plasma'], answer: 1, explain: 'White blood cells (leukocytes) are part of the immune system.' },
      { q: 'What gas do plants absorb for photosynthesis?', options: ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Hydrogen'], answer: 2, explain: 'Plants take in CO₂ and release O₂ during photosynthesis.' },
      { q: 'DNA is stored in which part of the cell?', options: ['Cytoplasm', 'Nucleus', 'Cell membrane', 'Vacuole'], answer: 1, explain: 'In eukaryotic cells, most DNA is housed in the nucleus.' },
    ],
    Chemistry: [
      { q: 'What is the chemical symbol for gold?', options: ['Go', 'Gd', 'Au', 'Ag'], answer: 2, explain: 'Au comes from the Latin "aurum".' },
      { q: 'Which particle has a positive charge?', options: ['Electron', 'Neutron', 'Proton', 'Photon'], answer: 2, explain: 'Protons are positively charged; electrons are negative; neutrons are neutral.' },
      { q: 'Water has the chemical formula:', options: ['H₂O', 'CO₂', 'NaCl', 'O₂'], answer: 0, explain: 'Two hydrogen atoms bonded to one oxygen atom.' },
      { q: 'What type of bond shares electrons?', options: ['Ionic', 'Covalent', 'Metallic', 'Hydrogen'], answer: 1, explain: 'Covalent bonds form when atoms share pairs of electrons.' },
      { q: 'The pH of a neutral solution is:', options: ['0', '7', '14', '1'], answer: 1, explain: 'pH 7 is neutral (pure water at 25°C).' },
    ],
    History: [
      { q: 'In which year did the American Revolutionary War begin?', options: ['1776', '1775', '1789', '1812'], answer: 1, explain: 'Fighting started in 1775; the Declaration of Independence was 1776.' },
      { q: 'Who was the British Prime Minister during most of WWII?', options: ['Chamberlain', 'Churchill', 'Thatcher', 'Attlee'], answer: 1, explain: 'Winston Churchill led Britain from 1940–1945.' },
      { q: 'The Berlin Wall fell in:', options: ['1987', '1989', '1991', '1985'], answer: 1, explain: 'November 9, 1989 marked the fall of the Berlin Wall.' },
      { q: 'Ancient Egypt\'s writing system is called:', options: ['Cuneiform', 'Hieroglyphics', 'Latin', 'Sanskrit'], answer: 1, explain: 'Hieroglyphics used pictorial symbols.' },
      { q: 'The Renaissance began in which country?', options: ['France', 'England', 'Italy', 'Spain'], answer: 2, explain: 'The Renaissance started in Italy in the 14th century.' },
    ],
    Math: [
      { q: 'What is 15% of 200?', options: ['20', '30', '25', '35'], answer: 1, explain: '0.15 × 200 = 30.' },
      { q: 'Solve: 2x + 6 = 14', options: ['x = 3', 'x = 4', 'x = 5', 'x = 8'], answer: 1, explain: '2x = 8 → x = 4.' },
      { q: 'Area of a circle with radius 3? (use π ≈ 3.14)', options: ['18.84', '28.26', '9.42', '37.68'], answer: 1, explain: 'A = πr² = 3.14 × 9 ≈ 28.26.' },
      { q: 'What is the square root of 144?', options: ['11', '12', '13', '14'], answer: 1, explain: '12 × 12 = 144.' },
      { q: 'Slope of the line y = 3x − 2?', options: ['−2', '3', '2', '1/3'], answer: 1, explain: 'In y = mx + b, m is the slope → 3.' },
    ],
    // --- GST / Admission practice (original questions; not from any published bank) ---
    'GST Physics': [
      { q: 'ফটোইলেকট্রিক ক্রিয়া কোন তরঙ্গ বৈশিষ্ট্য দিয়ে ব্যাখ্যা করা যায় না?', options: ['ব্যতিচার', 'অপবর্তন', 'সমবর্তন', 'কণিকা প্রকৃতি'], answer: 3, explain: 'ফটোইলেকট্রিক ক্রিয়া আলোর কণিকা (ফোটন) ধারণা দিয়ে ব্যাখ্যা করা হয়; তরঙ্গ বৈশিষ্ট্য দিয়ে নয়।' },
      { q: 'পৃথিবীর পৃষ্ঠ থেকে R/2 উচ্চতায় অভিকর্ষ ত্বরণ g′ হলে g′/g ≈ ?', options: ['4/9', '2/3', '1/2', '8/9'], answer: 0, explain: 'g′ = g / (1 + h/R)² → h = R/2 → g′ = g/(1.5)² = g × 4/9।' },
      { q: 'সমান্তরালে যুক্ত ৪টি তার দিয়ে ৬ kg ভর খাড়া উপরের দিকে সমবেগে টানলে প্রতি তারে টান (g=9.8) কত N?', options: ['10.7', '12.7', '14.7', '17.8'], answer: 2, explain: 'T = mg/4 = 6×9.8/4 = 14.7 N।' },
      { q: 'সম-আয়তন প্রক্রিয়ায় গৃহীত তাপ Q হলে অভ্যন্তরীণ শক্তির বৃদ্ধি কত?', options: ['−Q', '0', 'Q', '2Q'], answer: 2, explain: 'dV = 0 → ΔQ = ΔU → ΔU = Q।' },
      { q: 'Young-এর গুণাঙ্ক (Y) নির্ভর করে কোনটির উপর?', options: ['তারের দৈর্ঘ্য', 'ব্যাসার্ধ', 'উপাদান', 'প্রযুক্ত বল'], answer: 2, explain: 'Y উপাদানের ধর্ম; দৈর্ঘ্য/ব্যাসার্ধ পরিবর্তনে Y একই থাকে।' },
    ],
    'GST Chemistry': [
      { q: 'সবচেয়ে শক্তিশালী অ্যাসিডের অনুবন্ধী ক্ষারক কেমন হয়?', options: ['সবচেয়ে শক্তিশালী', 'মাঝারি', 'সবচেয়ে দুর্বল', 'অপরিবর্তিত'], answer: 2, explain: 'শক্তিশালী অ্যাসিডের অনুবন্ধী ক্ষারক দুর্বল (যেমন Cl₃CCOOH)।' },
      { q: 'পানির pH ৭ মানে কী?', options: ['অম্লীয়', 'ক্ষারীয়', 'নিরপেক্ষ', 'অজানা'], answer: 2, explain: '২৫°C-এ বিশুদ্ধ পানির pH ≈ ৭, নিরপেক্ষ।' },
      { q: 'কোন বন্ধনে ইলেকট্রন শেয়ার হয়?', options: ['আয়নিক', 'কোভ্যালেন্ট', 'ধাতব', 'হাইড্রোজেন'], answer: 1, explain: 'কোভ্যালেন্ট বন্ধনে ইলেকট্রন জোড়া শেয়ার হয়।' },
      { q: 'Avogadro সংখ্যা প্রায় কত?', options: ['6.02×10²²', '6.02×10²³', '6.02×10²⁴', '3.14×10²³'], answer: 1, explain: '১ মোলে কণার সংখ্যা ≈ 6.022×10²³।' },
      { q: 'CNG-এর প্রধান উপাদান কোনটি?', options: ['ইথেন', 'মিথেন', 'প্রোপেন', 'বিউটেন'], answer: 1, explain: 'CNG মূলত মিথেন (CH₄) সমৃদ্ধ।' },
    ],
    'GST Math': [
      { q: '2x + 6 = 14 হলে x এর মান?', options: ['3', '4', '5', '8'], answer: 1, explain: '2x = 8 → x = 4।' },
      { q: 'ব্যাসার্ধ ৩ একক বৃত্তের ক্ষেত্রফল (π≈3.14)?', options: ['18.84', '28.26', '9.42', '37.68'], answer: 1, explain: 'A = πr² = 3.14×9 ≈ 28.26।' },
      { q: '√144 এর মান?', options: ['11', '12', '13', '14'], answer: 1, explain: '12×12 = 144।' },
      { q: 'y = 3x − 2 রেখার ঢাল কত?', options: ['−2', '3', '2', '1/3'], answer: 1, explain: 'y = mx + c আকারে m = 3।' },
      { q: 'log₁₀ 1000 এর মান?', options: ['2', '3', '4', '10'], answer: 1, explain: '10³ = 1000 → log₁₀ 1000 = 3।' },
    ],
    'GST Biology': [
      { q: 'সালোকসংশ্লেষণ কোন অঙ্গাণুতে হয়?', options: ['মাইটোকন্ড্রিয়া', 'ক্লোরোপ্লাস্ট', 'নিউক্লিয়াস', 'রাইবোজোম'], answer: 1, explain: 'ক্লোরোপ্লাস্টে ক্লোরোফিল থাকে এবং সালোকসংশ্লেষণ হয়।' },
      { q: 'DNA কোথায় সংরক্ষিত?', options: ['সাইটোপ্লাজম', 'নিউক্লিয়াস', 'কোষঝিল্লি', 'ভ্যাকুওল'], answer: 1, explain: 'ইউক্যারিওটিক কোষে DNA মূলত নিউক্লিয়াসে থাকে।' },
      { q: 'রক্তের কোন কোষ সংক্রমণ প্রতিরোধ করে?', options: ['লাল রক্তকণিকা', 'শ্বেত রক্তকণিকা', 'প্ল্যাটিলেট', 'প্লাজমা'], answer: 1, explain: 'শ্বেত রক্তকণিকা রোগ প্রতিরোধ ব্যবস্থার অংশ।' },
      { q: 'উদ্ভিদ কোন গ্যাস শোষণ করে সালোকসংশ্লেষণে?', options: ['অক্সিজেন', 'নাইট্রোজেন', 'কার্বন ডাইঅক্সাইড', 'হাইড্রোজেন'], answer: 2, explain: 'CO₂ শোষণ করে এবং O₂ ত্যাগ করে।' },
      { q: 'জীবের ক্ষুদ্রতম গঠনগত কার্যকরী একক?', options: ['পরমাণু', 'টিস্যু', 'কোষ', 'অঙ্গ'], answer: 2, explain: 'কোষ হলো জীবনের মৌলিক একক।' },
    ],
    'GST English': [
      { q: 'Choose the correct sentence:', options: ['He know English beside Bengali', 'He knows English besides Bengali', 'He knows English beside Bengali', 'He know English besides Bengali'], answer: 1, explain: '"besides" = in addition to; verb agrees with subject (knows).' },
      { q: 'Fill in: We went out ______ the cold weather.', options: ['despite', 'however', 'besides', 'although'], answer: 0, explain: '"despite" + noun phrase is correct.' },
      { q: 'Antonym of "Harmony":', options: ['Admiration', 'Discord', 'Cooperation', 'Peace'], answer: 1, explain: 'Harmony ↔ Discord.' },
      { q: 'I really enjoy ______ English.', options: ['to speak', 'speak', 'speaking', 'spoke'], answer: 2, explain: 'enjoy + gerund (speaking).' },
      { q: 'Correct English for: আমি ইঞ্জিনিয়ার হতে চাই', options: ['I want to be an engineering', 'I want to be an engineer', 'I want be engineer', 'I wants to be an engineer'], answer: 1, explain: '"an engineer" is the correct profession form.' },
    ],
    'GST Bangla': [
      { q: '‘খাসজমি’ শব্দে ‘খাস’ কোন ভাষার উপশব্দ?', options: ['ফারসি', 'বাংলা', 'আরবি', 'সংস্কৃত'], answer: 2, explain: 'খাস, আম, লা — আরবি উপশব্দ।' },
      { q: 'বাংলা গদ্যের জনক কে?', options: ['ঈশ্বরচন্দ্র বিদ্যাসাগর', 'উইলিয়াম কেরি', 'মধুসূদন দত্ত', 'প্রমথ চৌধুরী'], answer: 0, explain: 'ঈশ্বরচন্দ্র বিদ্যাসাগরকে বাংলা গদ্যের জনক বলা হয়।' },
      { q: 'জাতীয় কবি কাজী নজরুল ইসলামকে কোন সালে বাংলাদেশে আনা হয়?', options: ['১৯৭২', '১৯৭৪', '১৯৭৬', '১৯৭৫'], answer: 2, explain: '১৯৭৬ সালে স্থায়ীভাবে বাংলাদেশে আনা হয়।' },
      { q: '‘Monitoring’ এর বাংলা পরিভাষা কোনটি?', options: ['পরিবীক্ষণ', 'নিরীক্ষণ', 'পর্যালোচনা', 'পর্যবেক্ষণ'], answer: 0, explain: 'Monitoring → পরিবীক্ষণ।' },
      { q: 'বাংলা লিপির উৎস কোনটি?', options: ['চীনা', 'খরোষ্ঠী', 'ব্রাহ্মী', 'সেমেটিক'], answer: 2, explain: 'বাংলা লিপি ব্রাহ্মী লিপি থেকে উদ্ভূত।' },
    ],
  };

  // ---------- IHT Admission practice bank (320 questions) ----------
  const IHT_QUIZ_BANK = {"Biology":[{"q":"The basic structural and functional unit of life is:","options":["Cell","Tissue","Organ","Organ system"],"answer":0,"explain":"Correct answer: Cell."},{"q":"Which organelle is known as the powerhouse of the cell?","options":["Ribosome","Mitochondrion","Golgi body","Lysosome"],"answer":1,"explain":"Correct answer: Mitochondrion."},{"q":"Photosynthesis mainly occurs in:","options":["Nucleus","Chloroplast","Vacuole","Mitochondrion"],"answer":1,"explain":"Correct answer: Chloroplast."},{"q":"Which pigment gives plants their green colour?","options":["Haemoglobin","Melanin","Chlorophyll","Carotene"],"answer":2,"explain":"Correct answer: Chlorophyll."},{"q":"The genetic material in most organisms is:","options":["Protein","DNA","Lipid","Starch"],"answer":1,"explain":"Correct answer: DNA."},{"q":"How many chromosomes are present in a normal human somatic cell?","options":["23","44","46","48"],"answer":2,"explain":"Correct answer: 46."},{"q":"The human gamete contains how many chromosomes?","options":["22","23","44","46"],"answer":1,"explain":"Correct answer: 23."},{"q":"Which blood cells transport most oxygen?","options":["Platelets","Red blood cells","White blood cells","Lymphocytes"],"answer":1,"explain":"Correct answer: Red blood cells."},{"q":"Which blood component helps clotting?","options":["Plasma","Platelets","RBCs","Albumin"],"answer":1,"explain":"Correct answer: Platelets."},{"q":"Which cells are mainly responsible for body defence?","options":["RBCs","WBCs","Platelets","Osteocytes"],"answer":1,"explain":"Correct answer: WBCs."},{"q":"The universal donor for red-cell transfusion is generally:","options":["AB positive","O negative","A positive","B negative"],"answer":1,"explain":"Correct answer: O negative."},{"q":"The universal recipient for red-cell transfusion is generally:","options":["O negative","AB positive","A negative","B positive"],"answer":1,"explain":"Correct answer: AB positive."},{"q":"Which vitamin is essential for normal blood clotting?","options":["Vitamin A","Vitamin C","Vitamin K","Vitamin D"],"answer":2,"explain":"Correct answer: Vitamin K."},{"q":"Deficiency of vitamin C causes:","options":["Rickets","Scurvy","Beriberi","Pellagra"],"answer":1,"explain":"Correct answer: Scurvy."},{"q":"Deficiency of vitamin D in children causes:","options":["Rickets","Night blindness","Scurvy","Anaemia"],"answer":0,"explain":"Correct answer: Rickets."},{"q":"Which vitamin is important for vision in dim light?","options":["Vitamin A","Vitamin B1","Vitamin C","Vitamin K"],"answer":0,"explain":"Correct answer: Vitamin A."},{"q":"The main site of photosynthesis in a leaf is:","options":["Epidermis","Mesophyll","Root hair","Xylem"],"answer":1,"explain":"Correct answer: Mesophyll."},{"q":"Stomata mainly help in:","options":["Seed formation","Gas exchange","Water absorption from soil","Pollination"],"answer":1,"explain":"Correct answer: Gas exchange."},{"q":"The process by which plants lose water vapour is:","options":["Respiration","Transpiration","Translocation","Germination"],"answer":1,"explain":"Correct answer: Transpiration."},{"q":"Which plant tissue transports water?","options":["Phloem","Xylem","Cambium","Epidermis"],"answer":1,"explain":"Correct answer: Xylem."},{"q":"Which plant tissue transports prepared food?","options":["Xylem","Phloem","Cortex","Pith"],"answer":1,"explain":"Correct answer: Phloem."},{"q":"The male reproductive part of a flower is:","options":["Pistil","Stamen","Sepal","Petal"],"answer":1,"explain":"Correct answer: Stamen."},{"q":"Pollination is the transfer of pollen from:","options":["Stigma to ovary","Anther to stigma","Ovary to anther","Root to leaf"],"answer":1,"explain":"Correct answer: Anther to stigma."},{"q":"Which organism is a decomposer?","options":["Mushroom","Deer","Eagle","Grass"],"answer":0,"explain":"Correct answer: Mushroom."},{"q":"A food chain usually begins with:","options":["Carnivores","Producers","Decomposers","Parasites"],"answer":1,"explain":"Correct answer: Producers."},{"q":"Which is an example of a mammal?","options":["Frog","Pigeon","Whale","Lizard"],"answer":2,"explain":"Correct answer: Whale."},{"q":"Which animal is an amphibian?","options":["Snake","Frog","Bat","Shark"],"answer":1,"explain":"Correct answer: Frog."},{"q":"The study of insects is called:","options":["Ornithology","Entomology","Mycology","Ecology"],"answer":1,"explain":"Correct answer: Entomology."},{"q":"The study of fungi is called:","options":["Botany","Mycology","Zoology","Genetics"],"answer":1,"explain":"Correct answer: Mycology."},{"q":"Which microorganism causes malaria?","options":["Virus","Plasmodium","Bacterium","Fungus"],"answer":1,"explain":"Correct answer: Plasmodium."},{"q":"Malaria is transmitted by:","options":["Male Anopheles mosquito","Female Anopheles mosquito","Housefly","Aedes mosquito"],"answer":1,"explain":"Correct answer: Female Anopheles mosquito."},{"q":"Dengue is transmitted mainly by:","options":["Aedes mosquito","Sandfly","Housefly","Tick"],"answer":0,"explain":"Correct answer: Aedes mosquito."},{"q":"Tuberculosis is caused by:","options":["Mycobacterium tuberculosis","Plasmodium vivax","HIV","Vibrio cholerae"],"answer":0,"explain":"Correct answer: Mycobacterium tuberculosis."},{"q":"Cholera is caused by:","options":["Salmonella typhi","Vibrio cholerae","Hepatitis virus","Streptococcus"],"answer":1,"explain":"Correct answer: Vibrio cholerae."},{"q":"Antibiotics are mainly used against:","options":["Bacterial infections","All viral infections","Vitamin deficiency","Broken bones"],"answer":0,"explain":"Correct answer: Bacterial infections."},{"q":"Which molecule carries hereditary information?","options":["DNA","Glucose","ATP","Cellulose"],"answer":0,"explain":"Correct answer: DNA."},{"q":"The process of cell division producing two identical daughter cells is:","options":["Meiosis","Mitosis","Fertilisation","Mutation"],"answer":1,"explain":"Correct answer: Mitosis."},{"q":"Which kingdom includes mushrooms?","options":["Plantae","Animalia","Fungi","Protista"],"answer":2,"explain":"Correct answer: Fungi."},{"q":"Which gas is released during photosynthesis?","options":["Carbon dioxide","Oxygen","Nitrogen","Hydrogen"],"answer":1,"explain":"Correct answer: Oxygen."},{"q":"The main source of energy for most ecosystems is:","options":["Moon","Sun","Soil","Wind"],"answer":1,"explain":"Correct answer: Sun."}],"Human Anatomy & Physiology":[{"q":"The largest gland in the human body is:","options":["Pancreas","Liver","Thyroid","Pituitary"],"answer":1,"explain":"Correct answer: Liver."},{"q":"The largest organ of the human body is:","options":["Liver","Skin","Lung","Brain"],"answer":1,"explain":"Correct answer: Skin."},{"q":"The smallest bone in the human body is:","options":["Stapes","Femur","Tibia","Ulna"],"answer":0,"explain":"Correct answer: Stapes."},{"q":"The longest bone in the human body is:","options":["Humerus","Femur","Fibula","Radius"],"answer":1,"explain":"Correct answer: Femur."},{"q":"How many chambers does the human heart have?","options":["Two","Three","Four","Five"],"answer":2,"explain":"Correct answer: Four."},{"q":"The natural pacemaker of the heart is the:","options":["AV node","SA node","Aorta","Septum"],"answer":1,"explain":"Correct answer: SA node."},{"q":"The normal resting adult pulse rate is commonly about:","options":["20–40/min","60–100/min","120–160/min","180–200/min"],"answer":1,"explain":"Correct answer: 60–100/min."},{"q":"The normal average body temperature is approximately:","options":["35°C","37°C","39°C","41°C"],"answer":1,"explain":"Correct answer: 37°C."},{"q":"The functional unit of the kidney is:","options":["Neuron","Nephron","Alveolus","Villus"],"answer":1,"explain":"Correct answer: Nephron."},{"q":"The functional gas-exchange units of the lungs are:","options":["Bronchi","Alveoli","Trachea","Pleura"],"answer":1,"explain":"Correct answer: Alveoli."},{"q":"The windpipe is also called:","options":["Oesophagus","Trachea","Ureter","Larynx"],"answer":1,"explain":"Correct answer: Trachea."},{"q":"Which organ produces insulin?","options":["Liver","Pancreas","Spleen","Gallbladder"],"answer":1,"explain":"Correct answer: Pancreas."},{"q":"Insulin helps to:","options":["Increase blood glucose","Lower blood glucose","Digest protein","Increase blood pressure"],"answer":1,"explain":"Correct answer: Lower blood glucose."},{"q":"Bile is produced by the:","options":["Gallbladder","Liver","Pancreas","Stomach"],"answer":1,"explain":"Correct answer: Liver."},{"q":"Bile is stored in the:","options":["Spleen","Gallbladder","Kidney","Appendix"],"answer":1,"explain":"Correct answer: Gallbladder."},{"q":"Most nutrient absorption occurs in the:","options":["Stomach","Small intestine","Large intestine","Oesophagus"],"answer":1,"explain":"Correct answer: Small intestine."},{"q":"The main function of the large intestine is absorption of:","options":["Oxygen","Water and electrolytes","Protein","Bile"],"answer":1,"explain":"Correct answer: Water and electrolytes."},{"q":"The acid present in gastric juice is:","options":["Sulphuric acid","Hydrochloric acid","Nitric acid","Acetic acid"],"answer":1,"explain":"Correct answer: Hydrochloric acid."},{"q":"Which enzyme begins starch digestion in the mouth?","options":["Pepsin","Salivary amylase","Trypsin","Lipase"],"answer":1,"explain":"Correct answer: Salivary amylase."},{"q":"The basic functional cell of the nervous system is:","options":["Neuron","Nephron","Osteon","Alveolus"],"answer":0,"explain":"Correct answer: Neuron."},{"q":"The part of the brain responsible for balance is:","options":["Cerebrum","Cerebellum","Medulla","Hypothalamus"],"answer":1,"explain":"Correct answer: Cerebellum."},{"q":"The medulla oblongata helps regulate:","options":["Hair growth","Breathing and heart rate","Vision only","Bone formation"],"answer":1,"explain":"Correct answer: Breathing and heart rate."},{"q":"The number of pairs of cranial nerves is:","options":["10","12","31","33"],"answer":1,"explain":"Correct answer: 12."},{"q":"The number of pairs of spinal nerves is:","options":["12","23","31","33"],"answer":2,"explain":"Correct answer: 31."},{"q":"The hormone that regulates metabolic rate is mainly:","options":["Insulin","Thyroxine","Adrenaline","Oestrogen"],"answer":1,"explain":"Correct answer: Thyroxine."},{"q":"The pituitary gland is often called the:","options":["Digestive gland","Master gland","Sweat gland","Salivary gland"],"answer":1,"explain":"Correct answer: Master gland."},{"q":"The hormone released during the fight-or-flight response is:","options":["Insulin","Adrenaline","Melatonin","Calcitonin"],"answer":1,"explain":"Correct answer: Adrenaline."},{"q":"Red blood cells are mainly produced in:","options":["Yellow bone marrow","Red bone marrow","Liver only in adults","Spleen"],"answer":1,"explain":"Correct answer: Red bone marrow."},{"q":"The average lifespan of a red blood cell is about:","options":["12 days","30 days","120 days","365 days"],"answer":2,"explain":"Correct answer: 120 days."},{"q":"The liquid portion of blood is:","options":["Serum only","Plasma","Platelet","Haemoglobin"],"answer":1,"explain":"Correct answer: Plasma."},{"q":"The main function of haemoglobin is to carry:","options":["Oxygen","Glucose","Hormones only","Urea"],"answer":0,"explain":"Correct answer: Oxygen."},{"q":"The organ that filters blood and forms urine is:","options":["Lung","Kidney","Heart","Pancreas"],"answer":1,"explain":"Correct answer: Kidney."},{"q":"Urine passes from kidney to bladder through the:","options":["Urethra","Ureter","Nephron","Aorta"],"answer":1,"explain":"Correct answer: Ureter."},{"q":"Urine leaves the body through the:","options":["Ureter","Urethra","Renal artery","Oesophagus"],"answer":1,"explain":"Correct answer: Urethra."},{"q":"The normal adult human skeleton has approximately:","options":["106 bones","206 bones","306 bones","406 bones"],"answer":1,"explain":"Correct answer: 206 bones."},{"q":"The joint allowing movement in many directions is:","options":["Hinge joint","Ball-and-socket joint","Pivot joint","Fixed joint"],"answer":1,"explain":"Correct answer: Ball-and-socket joint."},{"q":"The kneecap is called:","options":["Scapula","Patella","Sternum","Clavicle"],"answer":1,"explain":"Correct answer: Patella."},{"q":"The organ that produces sperm is the:","options":["Prostate","Testis","Penis","Seminal vesicle"],"answer":1,"explain":"Correct answer: Testis."},{"q":"Fertilisation in humans usually occurs in the:","options":["Uterus","Fallopian tube","Vagina","Cervix"],"answer":1,"explain":"Correct answer: Fallopian tube."},{"q":"The placenta mainly allows exchange between:","options":["Mother and fetus","Lungs and heart","Kidney and bladder","Stomach and liver"],"answer":0,"explain":"Correct answer: Mother and fetus."}],"Chemistry":[{"q":"The chemical formula of water is:","options":["H2O","CO2","O2","H2O2"],"answer":0,"explain":"Correct answer: H2O."},{"q":"The atomic number of oxygen is:","options":["6","7","8","16"],"answer":2,"explain":"Correct answer: 8."},{"q":"The atomic number of carbon is:","options":["4","6","8","12"],"answer":1,"explain":"Correct answer: 6."},{"q":"The lightest element is:","options":["Helium","Hydrogen","Lithium","Oxygen"],"answer":1,"explain":"Correct answer: Hydrogen."},{"q":"The chemical symbol of sodium is:","options":["S","So","Na","N"],"answer":2,"explain":"Correct answer: Na."},{"q":"The chemical symbol of potassium is:","options":["P","K","Po","Pt"],"answer":1,"explain":"Correct answer: K."},{"q":"The chemical symbol of iron is:","options":["Ir","Fe","I","In"],"answer":1,"explain":"Correct answer: Fe."},{"q":"The chemical symbol of gold is:","options":["Ag","Au","Gd","Go"],"answer":1,"explain":"Correct answer: Au."},{"q":"Common table salt is:","options":["Sodium chloride","Calcium carbonate","Potassium nitrate","Sodium bicarbonate"],"answer":0,"explain":"Correct answer: Sodium chloride."},{"q":"A solution with pH 7 at 25°C is:","options":["Acidic","Neutral","Alkaline","Always concentrated"],"answer":1,"explain":"Correct answer: Neutral."},{"q":"An acid turns blue litmus:","options":["Red","Blue","Green","Yellow"],"answer":0,"explain":"Correct answer: Red."},{"q":"A base turns red litmus:","options":["Blue","Red","Black","White"],"answer":0,"explain":"Correct answer: Blue."},{"q":"The pH of a strong acid is generally:","options":["Below 7","Exactly 7","Above 7","Always 14"],"answer":0,"explain":"Correct answer: Below 7."},{"q":"The gas essential for combustion is:","options":["Nitrogen","Oxygen","Carbon dioxide","Helium"],"answer":1,"explain":"Correct answer: Oxygen."},{"q":"The most abundant gas in dry air is:","options":["Oxygen","Nitrogen","Carbon dioxide","Argon"],"answer":1,"explain":"Correct answer: Nitrogen."},{"q":"Carbon dioxide turns limewater:","options":["Blue","Milky","Red","Colourless permanently"],"answer":1,"explain":"Correct answer: Milky."},{"q":"Rust is mainly:","options":["Iron oxide","Copper sulphate","Sodium chloride","Calcium oxide"],"answer":0,"explain":"Correct answer: Iron oxide."},{"q":"The formula of carbon dioxide is:","options":["CO","CO2","C2O","CaO"],"answer":1,"explain":"Correct answer: CO2."},{"q":"The formula of ammonia is:","options":["NH3","NO2","N2O","CH4"],"answer":0,"explain":"Correct answer: NH3."},{"q":"The formula of methane is:","options":["CH4","C2H6","C2H4","CO2"],"answer":0,"explain":"Correct answer: CH4."},{"q":"The bond formed by sharing electron pairs is:","options":["Ionic","Covalent","Metallic only","Hydrogen only"],"answer":1,"explain":"Correct answer: Covalent."},{"q":"A positively charged ion is called:","options":["Anion","Cation","Isotope","Molecule"],"answer":1,"explain":"Correct answer: Cation."},{"q":"A negatively charged ion is called:","options":["Cation","Anion","Atom","Proton"],"answer":1,"explain":"Correct answer: Anion."},{"q":"The central part of an atom is the:","options":["Electron cloud","Nucleus","Shell","Bond"],"answer":1,"explain":"Correct answer: Nucleus."},{"q":"A proton carries:","options":["Positive charge","Negative charge","No charge","Variable charge"],"answer":0,"explain":"Correct answer: Positive charge."},{"q":"A neutron carries:","options":["Positive charge","Negative charge","No electric charge","Double charge"],"answer":2,"explain":"Correct answer: No electric charge."},{"q":"An electron carries:","options":["Positive charge","Negative charge","No charge","Both charges"],"answer":1,"explain":"Correct answer: Negative charge."},{"q":"The mass number equals the number of:","options":["Protons only","Neutrons only","Protons plus neutrons","Electrons plus protons"],"answer":2,"explain":"Correct answer: Protons plus neutrons."},{"q":"The process of a solid changing directly into gas is:","options":["Condensation","Sublimation","Freezing","Melting"],"answer":1,"explain":"Correct answer: Sublimation."},{"q":"The change from liquid to gas at the surface is:","options":["Evaporation","Freezing","Deposition","Condensation"],"answer":0,"explain":"Correct answer: Evaporation."},{"q":"A catalyst:","options":["Is always consumed","Changes reaction rate without being consumed overall","Stops all reactions","Changes product identity always"],"answer":1,"explain":"Correct answer: Changes reaction rate without being consumed overall."},{"q":"The chemical formula of baking soda is:","options":["NaCl","NaHCO3","CaCO3","NaOH"],"answer":1,"explain":"Correct answer: NaHCO3."},{"q":"The chemical formula of washing soda is:","options":["Na2CO3·10H2O","NaHCO3","CaO","KCl"],"answer":0,"explain":"Correct answer: Na2CO3·10H2O."},{"q":"The main acid in vinegar is:","options":["Citric acid","Acetic acid","Lactic acid","Hydrochloric acid"],"answer":1,"explain":"Correct answer: Acetic acid."},{"q":"The acid found in lemons is:","options":["Citric acid","Acetic acid","Sulphuric acid","Formic acid"],"answer":0,"explain":"Correct answer: Citric acid."},{"q":"The chemical formula of calcium carbonate is:","options":["CaCO3","CaCl2","CaO","CaSO4"],"answer":0,"explain":"Correct answer: CaCO3."},{"q":"The gas commonly used to fill balloons safely is:","options":["Chlorine","Helium","Oxygen","Carbon monoxide"],"answer":1,"explain":"Correct answer: Helium."},{"q":"The process of coating iron with zinc is:","options":["Distillation","Galvanisation","Crystallisation","Neutralisation"],"answer":1,"explain":"Correct answer: Galvanisation."},{"q":"The SI unit for amount of substance is:","options":["Gram","Mole","Litre","Molecule"],"answer":1,"explain":"Correct answer: Mole."},{"q":"One mole contains approximately:","options":["6.022 × 10^23 entities","3.00 × 10^8 entities","9.8 entities","1.6 × 10^-19 entities"],"answer":0,"explain":"Correct answer: 6.022 × 10^23 entities."}],"Physics":[{"q":"The SI unit of force is:","options":["Joule","Newton","Watt","Pascal"],"answer":1,"explain":"Correct answer: Newton."},{"q":"The SI unit of work is:","options":["Joule","Newton","Ampere","Volt"],"answer":0,"explain":"Correct answer: Joule."},{"q":"The SI unit of power is:","options":["Watt","Joule","Ohm","Tesla"],"answer":0,"explain":"Correct answer: Watt."},{"q":"The SI unit of electric current is:","options":["Volt","Ampere","Ohm","Coulomb"],"answer":1,"explain":"Correct answer: Ampere."},{"q":"The SI unit of resistance is:","options":["Watt","Ohm","Tesla","Henry"],"answer":1,"explain":"Correct answer: Ohm."},{"q":"The SI unit of temperature is:","options":["Celsius","Kelvin","Fahrenheit","Joule"],"answer":1,"explain":"Correct answer: Kelvin."},{"q":"The approximate speed of light in vacuum is:","options":["3 × 10^6 m/s","3 × 10^8 m/s","3 × 10^5 m/s","3 × 10^3 m/s"],"answer":1,"explain":"Correct answer: 3 × 10^8 m/s."},{"q":"Sound cannot travel through:","options":["Air","Water","Steel","Vacuum"],"answer":3,"explain":"Correct answer: Vacuum."},{"q":"The acceleration due to gravity near Earth's surface is about:","options":["4.9 m/s²","9.8 m/s²","19.6 m/s²","98 m/s²"],"answer":1,"explain":"Correct answer: 9.8 m/s²."},{"q":"A device used to measure electric current is:","options":["Voltmeter","Ammeter","Barometer","Thermometer"],"answer":1,"explain":"Correct answer: Ammeter."},{"q":"A device used to measure potential difference is:","options":["Ammeter","Voltmeter","Hygrometer","Hydrometer"],"answer":1,"explain":"Correct answer: Voltmeter."},{"q":"Ohm's law is:","options":["V = IR","P = VI only","F = ma","W = mg"],"answer":0,"explain":"Correct answer: V = IR."},{"q":"The unit of frequency is:","options":["Hertz","Decibel","Metre","Second"],"answer":0,"explain":"Correct answer: Hertz."},{"q":"The time period is the reciprocal of:","options":["Amplitude","Frequency","Wavelength","Velocity"],"answer":1,"explain":"Correct answer: Frequency."},{"q":"A convex lens is also called a:","options":["Diverging lens","Converging lens","Plane mirror","Prism"],"answer":1,"explain":"Correct answer: Converging lens."},{"q":"A concave lens is generally:","options":["Converging","Diverging","A plane mirror","A source of light"],"answer":1,"explain":"Correct answer: Diverging."},{"q":"The image in a plane mirror is:","options":["Real and inverted","Virtual and erect","Always enlarged","Always diminished"],"answer":1,"explain":"Correct answer: Virtual and erect."},{"q":"The splitting of white light into colours is:","options":["Reflection","Dispersion","Diffraction","Polarisation"],"answer":1,"explain":"Correct answer: Dispersion."},{"q":"Heat transfer through a vacuum occurs by:","options":["Conduction","Convection","Radiation","Diffusion"],"answer":2,"explain":"Correct answer: Radiation."},{"q":"The boiling point of pure water at standard atmospheric pressure is:","options":["0°C","50°C","100°C","212°C only"],"answer":2,"explain":"Correct answer: 100°C."},{"q":"The freezing point of pure water at standard pressure is:","options":["0°C","10°C","32°C","100°C"],"answer":0,"explain":"Correct answer: 0°C."},{"q":"The energy possessed by a moving body is:","options":["Potential energy","Kinetic energy","Chemical energy","Nuclear energy"],"answer":1,"explain":"Correct answer: Kinetic energy."},{"q":"The energy stored due to position is:","options":["Kinetic energy","Potential energy","Sound energy","Heat only"],"answer":1,"explain":"Correct answer: Potential energy."},{"q":"Newton's first law is also known as the law of:","options":["Acceleration","Inertia","Action-reaction","Gravitation"],"answer":1,"explain":"Correct answer: Inertia."},{"q":"Newton's second law is commonly expressed as:","options":["F = ma","V = IR","P = W/t","E = mc"],"answer":0,"explain":"Correct answer: F = ma."},{"q":"For every action there is an equal and opposite reaction. This is:","options":["First law","Second law","Third law","Law of gravitation"],"answer":2,"explain":"Correct answer: Third law."},{"q":"The SI unit of pressure is:","options":["Pascal","Newton","Joule","Watt"],"answer":0,"explain":"Correct answer: Pascal."},{"q":"Pressure is defined as:","options":["Force × area","Force per unit area","Mass × velocity","Work per unit time"],"answer":1,"explain":"Correct answer: Force per unit area."},{"q":"The instrument used to measure atmospheric pressure is:","options":["Thermometer","Barometer","Ammeter","Calorimeter"],"answer":1,"explain":"Correct answer: Barometer."},{"q":"The density of a substance is:","options":["Mass × volume","Mass per unit volume","Volume per unit mass","Weight × area"],"answer":1,"explain":"Correct answer: Mass per unit volume."},{"q":"A transformer works with:","options":["Direct current only","Alternating current","Static charge only","Chemical energy"],"answer":1,"explain":"Correct answer: Alternating current."},{"q":"A fuse is connected in:","options":["Parallel with appliance","Series with live wire","Earth wire only","Neutral wire only"],"answer":1,"explain":"Correct answer: Series with live wire."},{"q":"The commercial unit of electrical energy is:","options":["Watt","Kilowatt-hour","Ampere","Volt"],"answer":1,"explain":"Correct answer: Kilowatt-hour."},{"q":"A magnet has how many poles?","options":["One","Two","Three","Four"],"answer":1,"explain":"Correct answer: Two."},{"q":"Like magnetic poles:","options":["Attract","Repel","Disappear","Have no effect"],"answer":1,"explain":"Correct answer: Repel."},{"q":"The pitch of sound depends mainly on:","options":["Amplitude","Frequency","Speed only","Loudness"],"answer":1,"explain":"Correct answer: Frequency."},{"q":"Loudness of sound is related mainly to:","options":["Amplitude/intensity","Frequency only","Wavelength only","Wave speed only"],"answer":0,"explain":"Correct answer: Amplitude/intensity."},{"q":"The unit of wavelength is:","options":["Hertz","Metre","Second","Decibel"],"answer":1,"explain":"Correct answer: Metre."},{"q":"A solar cell converts solar energy into:","options":["Sound energy","Electrical energy","Chemical fuel directly","Mechanical energy"],"answer":1,"explain":"Correct answer: Electrical energy."},{"q":"The SI unit of electric charge is:","options":["Coulomb","Ampere","Volt","Ohm"],"answer":0,"explain":"Correct answer: Coulomb."}],"English":[{"q":"Choose the synonym of 'rapid':","options":["Slow","Fast","Weak","Late"],"answer":1,"explain":"Correct answer: Fast."},{"q":"Choose the antonym of 'ancient':","options":["Old","Modern","Historic","Past"],"answer":1,"explain":"Correct answer: Modern."},{"q":"Choose the correct spelling:","options":["Recieve","Receive","Receeve","Receve"],"answer":1,"explain":"Correct answer: Receive."},{"q":"He ___ to school every day.","options":["go","going","goes","gone"],"answer":2,"explain":"Correct answer: goes."},{"q":"The plural of 'child' is:","options":["Childs","Children","Childes","Childrens"],"answer":1,"explain":"Correct answer: Children."},{"q":"'Honest' is a/an:","options":["Noun","Verb","Adjective","Adverb"],"answer":2,"explain":"Correct answer: Adjective."},{"q":"Choose the correct article: He is ___ honest man.","options":["a","an","the","no article"],"answer":1,"explain":"Correct answer: an."},{"q":"The past tense of 'write' is:","options":["Writed","Written","Wrote","Writing"],"answer":2,"explain":"Correct answer: Wrote."},{"q":"She has lived here ___ 2020.","options":["for","since","from","by"],"answer":1,"explain":"Correct answer: since."},{"q":"Neither Rahim nor Karim ___ present.","options":["are","were","is","have"],"answer":2,"explain":"Correct answer: is."},{"q":"The comparative form of 'good' is:","options":["Gooder","Best","Better","More good"],"answer":2,"explain":"Correct answer: Better."},{"q":"The superlative form of 'bad' is:","options":["Worse","Worst","Baddest","More bad"],"answer":1,"explain":"Correct answer: Worst."},{"q":"A person who writes poems is a:","options":["Novelist","Poet","Editor","Actor"],"answer":1,"explain":"Correct answer: Poet."},{"q":"The opposite of 'expand' is:","options":["Extend","Contract","Increase","Enlarge"],"answer":1,"explain":"Correct answer: Contract."},{"q":"Choose the correct sentence:","options":["She do her work.","She does her work.","She doing her work.","She done her work."],"answer":1,"explain":"Correct answer: She does her work.."},{"q":"The noun form of 'decide' is:","options":["Decisive","Decision","Decidingly","Decided"],"answer":1,"explain":"Correct answer: Decision."},{"q":"The adjective form of 'beauty' is:","options":["Beautiful","Beautifully","Beautify","Beautician"],"answer":0,"explain":"Correct answer: Beautiful."},{"q":"Identify the adverb: 'He runs quickly.'","options":["He","runs","quickly","none"],"answer":2,"explain":"Correct answer: quickly."},{"q":"A group of words with a subject and predicate is a:","options":["Phrase","Clause","Letter","Syllable"],"answer":1,"explain":"Correct answer: Clause."},{"q":"The passive form of 'They make chairs' is:","options":["Chairs made them.","Chairs are made by them.","Chairs were making.","They are made chairs."],"answer":1,"explain":"Correct answer: Chairs are made by them.."},{"q":"Choose the correct preposition: interested ___ science.","options":["on","at","in","for"],"answer":2,"explain":"Correct answer: in."},{"q":"Choose the correct preposition: good ___ mathematics.","options":["in","at","on","by"],"answer":1,"explain":"Correct answer: at."},{"q":"The correct question tag: You are ready, ___?","options":["are you","aren't you","isn't it","don't you"],"answer":1,"explain":"Correct answer: aren't you."},{"q":"The plural of 'mouse' is:","options":["Mouses","Mice","Mouse","Meese"],"answer":1,"explain":"Correct answer: Mice."},{"q":"The past participle of 'go' is:","options":["Went","Gone","Going","Goed"],"answer":1,"explain":"Correct answer: Gone."},{"q":"Choose the correct conjunction: Work hard ___ you will fail.","options":["and","but","or","because"],"answer":2,"explain":"Correct answer: or."},{"q":"A synonym of 'assist' is:","options":["Help","Hinder","Stop","Refuse"],"answer":0,"explain":"Correct answer: Help."},{"q":"An antonym of 'generous' is:","options":["Kind","Stingy","Helpful","Noble"],"answer":1,"explain":"Correct answer: Stingy."},{"q":"Choose the correct form: I ___ finished my work.","options":["has","have","having","had been"],"answer":1,"explain":"Correct answer: have."},{"q":"The word 'quickly' is formed from:","options":["Quick + ly","Quick + ness","Quick + er","Quick + ing"],"answer":0,"explain":"Correct answer: Quick + ly."},{"q":"Choose the correct spelling:","options":["Necessary","Neccessary","Necesary","Necassary"],"answer":0,"explain":"Correct answer: Necessary."},{"q":"Choose the correct spelling:","options":["Separate","Seperate","Seprate","Seperete"],"answer":0,"explain":"Correct answer: Separate."},{"q":"A person who treats sick people is a:","options":["Patient","Physician","Pharmacist only","Mechanic"],"answer":1,"explain":"Correct answer: Physician."},{"q":"The opposite of 'increase' is:","options":["Grow","Decrease","Improve","Develop"],"answer":1,"explain":"Correct answer: Decrease."},{"q":"Choose the correct tense: They ___ football now.","options":["play","played","are playing","have play"],"answer":2,"explain":"Correct answer: are playing."},{"q":"Choose the correct article: The sun rises in ___ east.","options":["a","an","the","no article"],"answer":2,"explain":"Correct answer: the."},{"q":"The meaning of 'benevolent' is:","options":["Kind","Cruel","Careless","Angry"],"answer":0,"explain":"Correct answer: Kind."},{"q":"The meaning of 'fragile' is:","options":["Strong","Easily broken","Heavy","Expensive"],"answer":1,"explain":"Correct answer: Easily broken."},{"q":"Choose the correct sentence:","options":["I have a few friends.","I has a few friends.","I having few friends.","I am have friends."],"answer":0,"explain":"Correct answer: I have a few friends.."},{"q":"The feminine form of 'king' is:","options":["Queen","Princess","Duchess","Lady"],"answer":0,"explain":"Correct answer: Queen."}],"Mathematics":[{"q":"What is 20% of 250?","options":["25","40","50","60"],"answer":2,"explain":"Correct answer: 50."},{"q":"12 × 8 equals:","options":["86","92","96","108"],"answer":2,"explain":"Correct answer: 96."},{"q":"The square root of 144 is:","options":["10","11","12","14"],"answer":2,"explain":"Correct answer: 12."},{"q":"1 kilometre equals:","options":["100 m","500 m","1000 m","10000 m"],"answer":2,"explain":"Correct answer: 1000 m."},{"q":"3/4 + 1/4 equals:","options":["1/2","1","2","3/4"],"answer":1,"explain":"Correct answer: 1."},{"q":"The sum of the interior angles of a triangle is:","options":["90°","180°","270°","360°"],"answer":1,"explain":"Correct answer: 180°."},{"q":"10% of 1000 is:","options":["10","50","100","200"],"answer":2,"explain":"Correct answer: 100."},{"q":"The value of 15² is:","options":["125","200","225","250"],"answer":2,"explain":"Correct answer: 225."},{"q":"The average of 4, 6 and 8 is:","options":["5","6","7","8"],"answer":1,"explain":"Correct answer: 6."},{"q":"If x + 5 = 12, x equals:","options":["5","6","7","8"],"answer":2,"explain":"Correct answer: 7."},{"q":"If 3x = 21, x equals:","options":["6","7","8","9"],"answer":1,"explain":"Correct answer: 7."},{"q":"The perimeter of a square of side 5 cm is:","options":["10 cm","15 cm","20 cm","25 cm"],"answer":2,"explain":"Correct answer: 20 cm."},{"q":"The area of a rectangle of length 8 cm and width 3 cm is:","options":["11 cm²","22 cm²","24 cm²","48 cm²"],"answer":2,"explain":"Correct answer: 24 cm²."},{"q":"The area of a square of side 6 cm is:","options":["12 cm²","24 cm²","36 cm²","48 cm²"],"answer":2,"explain":"Correct answer: 36 cm²."},{"q":"The circumference of a circle is:","options":["πr²","2πr","πd²","r²"],"answer":1,"explain":"Correct answer: 2πr."},{"q":"The approximate value of π is:","options":["2.14","3.14","4.13","3.41"],"answer":1,"explain":"Correct answer: 3.14."},{"q":"25% is equal to:","options":["1/2","1/3","1/4","1/5"],"answer":2,"explain":"Correct answer: 1/4."},{"q":"The ratio 2:4 in simplest form is:","options":["1:2","2:1","1:4","4:2"],"answer":0,"explain":"Correct answer: 1:2."},{"q":"A dozen equals:","options":["10","12","20","24"],"answer":1,"explain":"Correct answer: 12."},{"q":"The next prime number after 7 is:","options":["8","9","10","11"],"answer":3,"explain":"Correct answer: 11."},{"q":"Which of these is a prime number?","options":["15","21","23","27"],"answer":2,"explain":"Correct answer: 23."},{"q":"The LCM of 4 and 6 is:","options":["6","8","12","24"],"answer":2,"explain":"Correct answer: 12."},{"q":"The HCF of 12 and 18 is:","options":["3","6","9","12"],"answer":1,"explain":"Correct answer: 6."},{"q":"2.5 + 1.75 equals:","options":["3.25","4.00","4.25","4.75"],"answer":2,"explain":"Correct answer: 4.25."},{"q":"5/8 expressed as a decimal is:","options":["0.25","0.50","0.625","0.85"],"answer":2,"explain":"Correct answer: 0.625."},{"q":"If a = 2 and b = 3, then a² + b equals:","options":["5","7","8","9"],"answer":2,"explain":"Correct answer: 8."},{"q":"The value of 7 × (6 − 2) is:","options":["18","24","28","32"],"answer":1,"explain":"Correct answer: 24."},{"q":"A 500 taka item discounted by 10% costs:","options":["400 taka","450 taka","475 taka","490 taka"],"answer":1,"explain":"Correct answer: 450 taka."},{"q":"A car travels 120 km in 2 hours. Its average speed is:","options":["40 km/h","50 km/h","60 km/h","80 km/h"],"answer":2,"explain":"Correct answer: 60 km/h."},{"q":"The simple interest on 1000 taka at 5% per year for 2 years is:","options":["50 taka","100 taka","150 taka","200 taka"],"answer":1,"explain":"Correct answer: 100 taka."},{"q":"The sum of 45 and 37 is:","options":["72","82","92","102"],"answer":1,"explain":"Correct answer: 82."},{"q":"The difference between 100 and 63 is:","options":["27","37","47","53"],"answer":1,"explain":"Correct answer: 37."},{"q":"The product of 14 and 5 is:","options":["60","65","70","75"],"answer":2,"explain":"Correct answer: 70."},{"q":"The quotient of 81 divided by 9 is:","options":["7","8","9","10"],"answer":2,"explain":"Correct answer: 9."},{"q":"The reciprocal of 5 is:","options":["5","1/5","-5","0"],"answer":1,"explain":"Correct answer: 1/5."},{"q":"An angle of 90° is called:","options":["Acute","Right","Obtuse","Straight"],"answer":1,"explain":"Correct answer: Right."},{"q":"An angle greater than 90° but less than 180° is:","options":["Acute","Right","Obtuse","Reflex"],"answer":2,"explain":"Correct answer: Obtuse."},{"q":"A straight angle measures:","options":["90°","120°","180°","360°"],"answer":2,"explain":"Correct answer: 180°."},{"q":"If 5 notebooks cost 100 taka, one notebook costs:","options":["10 taka","15 taka","20 taka","25 taka"],"answer":2,"explain":"Correct answer: 20 taka."},{"q":"The probability of getting a head when tossing a fair coin is:","options":["0","1/4","1/2","1"],"answer":2,"explain":"Correct answer: 1/2."}],"Bangladesh & General Knowledge":[{"q":"The Independence Day of Bangladesh is:","options":["21 February","26 March","16 December","7 March"],"answer":1,"explain":"Correct answer: 26 March."},{"q":"The Victory Day of Bangladesh is:","options":["26 March","16 December","21 February","14 December"],"answer":1,"explain":"Correct answer: 16 December."},{"q":"International Mother Language Day is observed on:","options":["21 February","26 March","1 May","16 December"],"answer":0,"explain":"Correct answer: 21 February."},{"q":"The national flower of Bangladesh is:","options":["Rose","Water lily (Shapla)","Jasmine","Marigold"],"answer":1,"explain":"Correct answer: Water lily (Shapla)."},{"q":"The national fruit of Bangladesh is:","options":["Mango","Jackfruit","Banana","Litchi"],"answer":1,"explain":"Correct answer: Jackfruit."},{"q":"The national animal of Bangladesh is:","options":["Elephant","Royal Bengal tiger","Deer","Leopard"],"answer":1,"explain":"Correct answer: Royal Bengal tiger."},{"q":"The national bird of Bangladesh is:","options":["Crow","Oriental magpie-robin (Doel)","Parrot","Eagle"],"answer":1,"explain":"Correct answer: Oriental magpie-robin (Doel)."},{"q":"The national fish of Bangladesh is:","options":["Rohu","Hilsa","Catla","Tilapia"],"answer":1,"explain":"Correct answer: Hilsa."},{"q":"The national poet of Bangladesh is:","options":["Rabindranath Tagore","Kazi Nazrul Islam","Jasimuddin","Jibanananda Das"],"answer":1,"explain":"Correct answer: Kazi Nazrul Islam."},{"q":"The writer of 'Amar Sonar Bangla' is:","options":["Kazi Nazrul Islam","Rabindranath Tagore","Begum Rokeya","Jasimuddin"],"answer":1,"explain":"Correct answer: Rabindranath Tagore."},{"q":"The National Martyrs' Memorial is located at:","options":["Savar","Chattogram","Khulna","Rajshahi"],"answer":0,"explain":"Correct answer: Savar."},{"q":"The capital of Bangladesh is:","options":["Chattogram","Dhaka","Rajshahi","Sylhet"],"answer":1,"explain":"Correct answer: Dhaka."},{"q":"The currency of Bangladesh is:","options":["Rupee","Taka","Riyal","Dollar"],"answer":1,"explain":"Correct answer: Taka."},{"q":"The national parliament building is known as:","options":["Lalbagh Fort","Jatiya Sangsad Bhaban","Ahsan Manzil","Curzon Hall"],"answer":1,"explain":"Correct answer: Jatiya Sangsad Bhaban."},{"q":"The architect of Jatiya Sangsad Bhaban was:","options":["Louis I. Kahn","Frank Lloyd Wright","Le Corbusier","Zaha Hadid"],"answer":0,"explain":"Correct answer: Louis I. Kahn."},{"q":"The Language Movement took place in:","options":["1947","1952","1966","1971"],"answer":1,"explain":"Correct answer: 1952."},{"q":"The Six-Point Movement was announced in:","options":["1952","1962","1966","1969"],"answer":2,"explain":"Correct answer: 1966."},{"q":"The historic 7 March speech was delivered by:","options":["Tajuddin Ahmad","Sheikh Mujibur Rahman","A. K. Fazlul Huq","M. A. G. Osmani"],"answer":1,"explain":"Correct answer: Sheikh Mujibur Rahman."},{"q":"The Liberation War of Bangladesh took place in:","options":["1947","1952","1969","1971"],"answer":3,"explain":"Correct answer: 1971."},{"q":"The Constitution of Bangladesh came into effect on:","options":["26 March 1971","16 December 1972","7 March 1971","21 February 1952"],"answer":1,"explain":"Correct answer: 16 December 1972."},{"q":"The largest mangrove forest in the world is:","options":["Amazon","Sundarbans","Congo","Black Forest"],"answer":1,"explain":"Correct answer: Sundarbans."},{"q":"The longest sea beach in Bangladesh is commonly identified as:","options":["Kuakata","Cox's Bazar","Patenga","Parki"],"answer":1,"explain":"Correct answer: Cox's Bazar."},{"q":"The largest district of Bangladesh by area is:","options":["Dhaka","Rangamati","Cumilla","Gazipur"],"answer":1,"explain":"Correct answer: Rangamati."},{"q":"The smallest division of Bangladesh by area is:","options":["Dhaka","Mymensingh","Sylhet","Barishal"],"answer":1,"explain":"Correct answer: Mymensingh."},{"q":"The currency of Japan is:","options":["Yuan","Yen","Won","Baht"],"answer":1,"explain":"Correct answer: Yen."},{"q":"The headquarters of the United Nations is in:","options":["Geneva","New York","Paris","London"],"answer":1,"explain":"Correct answer: New York."},{"q":"WHO stands for:","options":["World Health Organization","World Human Office","World Hospital Organization","World Health Office"],"answer":0,"explain":"Correct answer: World Health Organization."},{"q":"The headquarters of WHO is in:","options":["Rome","Geneva","New York","Vienna"],"answer":1,"explain":"Correct answer: Geneva."},{"q":"The largest continent is:","options":["Africa","Asia","Europe","Antarctica"],"answer":1,"explain":"Correct answer: Asia."},{"q":"The smallest continent by land area is:","options":["Europe","Australia","South America","Antarctica"],"answer":1,"explain":"Correct answer: Australia."},{"q":"The largest ocean is:","options":["Atlantic","Indian","Pacific","Arctic"],"answer":2,"explain":"Correct answer: Pacific."},{"q":"The planet known as the Red Planet is:","options":["Venus","Mars","Jupiter","Mercury"],"answer":1,"explain":"Correct answer: Mars."},{"q":"The nearest star to Earth is:","options":["Sirius","Sun","Polaris","Proxima Centauri"],"answer":1,"explain":"Correct answer: Sun."},{"q":"The first month of the Bangla calendar is:","options":["Ashar","Boishakh","Falgun","Chaitra"],"answer":1,"explain":"Correct answer: Boishakh."},{"q":"The national memorial day for Martyred Intellectuals is:","options":["14 December","16 December","21 February","26 March"],"answer":0,"explain":"Correct answer: 14 December."},{"q":"The national flag of Bangladesh has a red circle on a:","options":["Blue field","Green field","White field","Black field"],"answer":1,"explain":"Correct answer: Green field."},{"q":"The main language of Bangladesh is:","options":["Urdu","Bangla","Hindi","English"],"answer":1,"explain":"Correct answer: Bangla."},{"q":"The largest planet in the Solar System is:","options":["Earth","Saturn","Jupiter","Neptune"],"answer":2,"explain":"Correct answer: Jupiter."},{"q":"The number of days in a leap year is:","options":["364","365","366","367"],"answer":2,"explain":"Correct answer: 366."},{"q":"The International Red Cross symbol is traditionally:","options":["Red cross on white","Blue star on white","Green crescent on red","Yellow circle on blue"],"answer":0,"explain":"Correct answer: Red cross on white."}],"ICT & Basic Medical Science":[{"q":"CPU stands for:","options":["Central Processing Unit","Computer Primary Utility","Central Program User","Control Power Unit"],"answer":0,"explain":"Correct answer: Central Processing Unit."},{"q":"The brain of a computer is commonly called the:","options":["Monitor","CPU","Keyboard","Mouse"],"answer":1,"explain":"Correct answer: CPU."},{"q":"Which of these is an input device?","options":["Monitor","Printer","Keyboard","Speaker"],"answer":2,"explain":"Correct answer: Keyboard."},{"q":"Which of these is an output device?","options":["Mouse","Scanner","Monitor","Keyboard"],"answer":2,"explain":"Correct answer: Monitor."},{"q":"RAM is:","options":["Permanent storage","Volatile memory","An output device","A processor"],"answer":1,"explain":"Correct answer: Volatile memory."},{"q":"The full form of URL is:","options":["Uniform Resource Locator","Universal Record Link","United Resource Line","Uniform Read Language"],"answer":0,"explain":"Correct answer: Uniform Resource Locator."},{"q":"Which number system uses only 0 and 1?","options":["Decimal","Binary","Octal","Hexadecimal"],"answer":1,"explain":"Correct answer: Binary."},{"q":"A computer virus is:","options":["A hardware part","Malicious software","A type of monitor","A network cable"],"answer":1,"explain":"Correct answer: Malicious software."},{"q":"The internet is best described as:","options":["A single computer","A global network of networks","An operating system","A word processor"],"answer":1,"explain":"Correct answer: A global network of networks."},{"q":"Which is an example of an operating system?","options":["Windows","Google Search","HTML","USB"],"answer":0,"explain":"Correct answer: Windows."},{"q":"The full form of PDF is:","options":["Portable Document Format","Personal Data File","Printed Document Form","Program Data Format"],"answer":0,"explain":"Correct answer: Portable Document Format."},{"q":"Which device connects a computer to a network?","options":["Modem/router","Projector","Speaker","Plotter"],"answer":0,"explain":"Correct answer: Modem/router."},{"q":"The normal adult human body temperature is approximately:","options":["35°C","37°C","39°C","41°C"],"answer":1,"explain":"Correct answer: 37°C."},{"q":"The normal adult resting respiratory rate is commonly:","options":["4–8/min","12–20/min","25–35/min","40–50/min"],"answer":1,"explain":"Correct answer: 12–20/min."},{"q":"The normal adult resting pulse rate is commonly:","options":["20–40/min","60–100/min","110–140/min","150–180/min"],"answer":1,"explain":"Correct answer: 60–100/min."},{"q":"The instrument used to measure blood pressure is:","options":["Stethoscope","Sphygmomanometer","Thermometer","Glucometer"],"answer":1,"explain":"Correct answer: Sphygmomanometer."},{"q":"A stethoscope is used mainly to:","options":["Measure height","Listen to internal body sounds","Measure temperature","Measure blood sugar"],"answer":1,"explain":"Correct answer: Listen to internal body sounds."},{"q":"The unit commonly used for haemoglobin concentration is:","options":["g/dL","mmHg","mL/min","°C"],"answer":0,"explain":"Correct answer: g/dL."},{"q":"The blood group system discovered by Landsteiner is:","options":["ABO system","Rhythm system","HLA system","HIV system"],"answer":0,"explain":"Correct answer: ABO system."},{"q":"The Rh factor is named after:","options":["A rhesus monkey study","A river","A scientist's initials","A hospital"],"answer":0,"explain":"Correct answer: A rhesus monkey study."},{"q":"The process of destroying all forms of microbial life, including spores, is:","options":["Disinfection","Sterilisation","Cleaning","Pasteurisation"],"answer":1,"explain":"Correct answer: Sterilisation."},{"q":"Hand hygiene is important mainly to:","options":["Improve appetite","Prevent infection transmission","Increase blood pressure","Reduce body temperature"],"answer":1,"explain":"Correct answer: Prevent infection transmission."},{"q":"The first step before assisting a patient is generally to:","options":["Ignore identification","Perform hand hygiene and identify the patient","Give medication immediately","Move the patient"],"answer":1,"explain":"Correct answer: Perform hand hygiene and identify the patient."},{"q":"A thermometer measures:","options":["Blood pressure","Temperature","Pulse","Oxygen saturation"],"answer":1,"explain":"Correct answer: Temperature."},{"q":"A pulse oximeter estimates:","options":["Blood glucose","Oxygen saturation","Haemoglobin type","Body weight"],"answer":1,"explain":"Correct answer: Oxygen saturation."},{"q":"The medical term for high blood pressure is:","options":["Hypotension","Hypertension","Hypoglycaemia","Hypothermia"],"answer":1,"explain":"Correct answer: Hypertension."},{"q":"The medical term for low blood sugar is:","options":["Hyperglycaemia","Hypoglycaemia","Hypertension","Anaemia"],"answer":1,"explain":"Correct answer: Hypoglycaemia."},{"q":"The medical term for low haemoglobin or reduced oxygen-carrying capacity is commonly:","options":["Anaemia","Asthma","Arthritis","Oedema"],"answer":0,"explain":"Correct answer: Anaemia."},{"q":"A vaccine helps the body develop:","options":["Immunity","Dehydration","Hypertension","Anaemia"],"answer":0,"explain":"Correct answer: Immunity."},{"q":"ORS is mainly used to prevent or treat:","options":["Dehydration","Fracture","Hypertension","Night blindness"],"answer":0,"explain":"Correct answer: Dehydration."},{"q":"The main purpose of first aid is to:","options":["Replace hospital treatment","Preserve life and prevent worsening","Diagnose every disease","Perform surgery"],"answer":1,"explain":"Correct answer: Preserve life and prevent worsening."},{"q":"A fracture is a:","options":["Muscle infection","Break in a bone","Skin allergy","Blood clot"],"answer":1,"explain":"Correct answer: Break in a bone."},{"q":"The medical term for difficulty in breathing is:","options":["Dyspnoea","Dysphagia","Dysuria","Apnoea"],"answer":0,"explain":"Correct answer: Dyspnoea."},{"q":"The medical term for painful urination is:","options":["Dyspnoea","Dysuria","Dysphagia","Dyslexia"],"answer":1,"explain":"Correct answer: Dysuria."},{"q":"The medical term for swallowing difficulty is:","options":["Dysphagia","Dyspnoea","Dysuria","Ataxia"],"answer":0,"explain":"Correct answer: Dysphagia."},{"q":"The abbreviation ECG refers to:","options":["Electrocardiogram","Electrochemical glucose","External cardiac gauge","Emergency care guide"],"answer":0,"explain":"Correct answer: Electrocardiogram."},{"q":"The abbreviation BP means:","options":["Body pulse","Blood pressure","Breathing pattern","Body protein"],"answer":1,"explain":"Correct answer: Blood pressure."},{"q":"The abbreviation CPR stands for:","options":["Cardiopulmonary resuscitation","Cardiac pressure reading","Clinical patient review","Central pulse rate"],"answer":0,"explain":"Correct answer: Cardiopulmonary resuscitation."},{"q":"Which nutrient is the body's main immediate energy source?","options":["Carbohydrate","Vitamin","Mineral","Water"],"answer":0,"explain":"Correct answer: Carbohydrate."},{"q":"Which mineral is important for haemoglobin formation?","options":["Iron","Iodine","Sodium","Fluoride"],"answer":0,"explain":"Correct answer: Iron."}]};
  // 300+ additional high-yield IHT admission MCQs in Bengali.
  const IHT_BN_QUIZ_BANK = {"জীববিজ্ঞান":[{"q":"কোষের শক্তিঘর—সঠিক উত্তর কোনটি?","options":["মাইটোকন্ড্রিয়া","রাইবোজোম","গলজি বডি","লাইসোজোম"],"answer":0,"explain":"সঠিক উত্তর: মাইটোকন্ড্রিয়া।"},{"q":"নিচের কোনটি সঠিক? কোষের শক্তিঘর।","options":["রাইবোজোম","গলজি বডি","লাইসোজোম","মাইটোকন্ড্রিয়া"],"answer":3,"explain":"সঠিক উত্তর: মাইটোকন্ড্রিয়া।"},{"q":"কোষের শক্তিঘর সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["গলজি বডি","লাইসোজোম","মাইটোকন্ড্রিয়া","রাইবোজোম"],"answer":2,"explain":"সঠিক উত্তর: মাইটোকন্ড্রিয়া।"},{"q":"প্রোটিন সংশ্লেষণের স্থান—সঠিক উত্তর কোনটি?","options":["ভ্যাকুওল","রাইবোজোম","নিউক্লিয়াস","লাইসোজোম"],"answer":1,"explain":"সঠিক উত্তর: রাইবোজোম।"},{"q":"নিচের কোনটি সঠিক? প্রোটিন সংশ্লেষণের স্থান।","options":["রাইবোজোম","নিউক্লিয়াস","লাইসোজোম","ভ্যাকুওল"],"answer":0,"explain":"সঠিক উত্তর: রাইবোজোম।"},{"q":"প্রোটিন সংশ্লেষণের স্থান সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নিউক্লিয়াস","লাইসোজোম","ভ্যাকুওল","রাইবোজোম"],"answer":3,"explain":"সঠিক উত্তর: রাইবোজোম।"},{"q":"বংশগতির প্রধান বাহক—সঠিক উত্তর কোনটি?","options":["লিপিড","গ্লুকোজ","ডিএনএ","আরএনএ"],"answer":2,"explain":"সঠিক উত্তর: ডিএনএ।"},{"q":"নিচের কোনটি সঠিক? বংশগতির প্রধান বাহক।","options":["গ্লুকোজ","ডিএনএ","আরএনএ","লিপিড"],"answer":1,"explain":"সঠিক উত্তর: ডিএনএ।"},{"q":"বংশগতির প্রধান বাহক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ডিএনএ","আরএনএ","লিপিড","গ্লুকোজ"],"answer":0,"explain":"সঠিক উত্তর: ডিএনএ।"},{"q":"উদ্ভিদের সবুজ রঞ্জক—সঠিক উত্তর কোনটি?","options":["জ্যান্থোফিল","ক্যারোটিন","অ্যান্থোসায়ানিন","ক্লোরোফিল"],"answer":3,"explain":"সঠিক উত্তর: ক্লোরোফিল।"},{"q":"নিচের কোনটি সঠিক? উদ্ভিদের সবুজ রঞ্জক।","options":["ক্যারোটিন","অ্যান্থোসায়ানিন","ক্লোরোফিল","জ্যান্থোফিল"],"answer":2,"explain":"সঠিক উত্তর: ক্লোরোফিল।"},{"q":"উদ্ভিদের সবুজ রঞ্জক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["অ্যান্থোসায়ানিন","ক্লোরোফিল","জ্যান্থোফিল","ক্যারোটিন"],"answer":1,"explain":"সঠিক উত্তর: ক্লোরোফিল।"},{"q":"সালোকসংশ্লেষণে নির্গত গ্যাস—সঠিক উত্তর কোনটি?","options":["অক্সিজেন","কার্বন ডাই-অক্সাইড","নাইট্রোজেন","হাইড্রোজেন"],"answer":0,"explain":"সঠিক উত্তর: অক্সিজেন।"},{"q":"নিচের কোনটি সঠিক? সালোকসংশ্লেষণে নির্গত গ্যাস।","options":["কার্বন ডাই-অক্সাইড","নাইট্রোজেন","হাইড্রোজেন","অক্সিজেন"],"answer":3,"explain":"সঠিক উত্তর: অক্সিজেন।"},{"q":"সালোকসংশ্লেষণে নির্গত গ্যাস সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নাইট্রোজেন","হাইড্রোজেন","অক্সিজেন","কার্বন ডাই-অক্সাইড"],"answer":2,"explain":"সঠিক উত্তর: অক্সিজেন।"},{"q":"উদ্ভিদে পানি পরিবহন করে—সঠিক উত্তর কোনটি?","options":["এপিডার্মিস","জাইলেম","ফ্লোয়েম","ক্যাম্বিয়াম"],"answer":1,"explain":"সঠিক উত্তর: জাইলেম।"},{"q":"নিচের কোনটি সঠিক? উদ্ভিদে পানি পরিবহন করে।","options":["জাইলেম","ফ্লোয়েম","ক্যাম্বিয়াম","এপিডার্মিস"],"answer":0,"explain":"সঠিক উত্তর: জাইলেম।"},{"q":"উদ্ভিদে পানি পরিবহন করে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ফ্লোয়েম","ক্যাম্বিয়াম","এপিডার্মিস","জাইলেম"],"answer":3,"explain":"সঠিক উত্তর: জাইলেম।"},{"q":"উদ্ভিদে খাদ্য পরিবহন করে—সঠিক উত্তর কোনটি?","options":["কর্ক","কিউটিকল","ফ্লোয়েম","জাইলেম"],"answer":2,"explain":"সঠিক উত্তর: ফ্লোয়েম।"},{"q":"নিচের কোনটি সঠিক? উদ্ভিদে খাদ্য পরিবহন করে।","options":["কিউটিকল","ফ্লোয়েম","জাইলেম","কর্ক"],"answer":1,"explain":"সঠিক উত্তর: ফ্লোয়েম।"},{"q":"উদ্ভিদে খাদ্য পরিবহন করে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ফ্লোয়েম","জাইলেম","কর্ক","কিউটিকল"],"answer":0,"explain":"সঠিক উত্তর: ফ্লোয়েম।"},{"q":"কোষ বিভাজনে সমসংখ্যক ক্রোমোজোম বজায় রাখে—সঠিক উত্তর কোনটি?","options":["মিয়োসিস","অ্যামাইটোসিস","নিষেক","মাইটোসিস"],"answer":3,"explain":"সঠিক উত্তর: মাইটোসিস।"},{"q":"নিচের কোনটি সঠিক? কোষ বিভাজনে সমসংখ্যক ক্রোমোজোম বজায় রাখে।","options":["অ্যামাইটোসিস","নিষেক","মাইটোসিস","মিয়োসিস"],"answer":2,"explain":"সঠিক উত্তর: মাইটোসিস।"},{"q":"কোষ বিভাজনে সমসংখ্যক ক্রোমোজোম বজায় রাখে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নিষেক","মাইটোসিস","মিয়োসিস","অ্যামাইটোসিস"],"answer":1,"explain":"সঠিক উত্তর: মাইটোসিস।"},{"q":"মানুষের দেহকোষে ক্রোমোজোম সংখ্যা—সঠিক উত্তর কোনটি?","options":["৪৬টি","২৩টি","৪৪টি","৪৮টি"],"answer":0,"explain":"সঠিক উত্তর: ৪৬টি।"},{"q":"নিচের কোনটি সঠিক? মানুষের দেহকোষে ক্রোমোজোম সংখ্যা।","options":["২৩টি","৪৪টি","৪৮টি","৪৬টি"],"answer":3,"explain":"সঠিক উত্তর: ৪৬টি।"},{"q":"মানুষের দেহকোষে ক্রোমোজোম সংখ্যা সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৪৪টি","৪৮টি","৪৬টি","২৩টি"],"answer":2,"explain":"সঠিক উত্তর: ৪৬টি।"},{"q":"মানুষের জননকোষে ক্রোমোজোম সংখ্যা—সঠিক উত্তর কোনটি?","options":["২২টি","২৩টি","৪৬টি","৪৪টি"],"answer":1,"explain":"সঠিক উত্তর: ২৩টি।"},{"q":"নিচের কোনটি সঠিক? মানুষের জননকোষে ক্রোমোজোম সংখ্যা।","options":["২৩টি","৪৬টি","৪৪টি","২২টি"],"answer":0,"explain":"সঠিক উত্তর: ২৩টি।"},{"q":"মানুষের জননকোষে ক্রোমোজোম সংখ্যা সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৪৬টি","৪৪টি","২২টি","২৩টি"],"answer":3,"explain":"সঠিক উত্তর: ২৩টি।"},{"q":"ম্যালেরিয়ার জীবাণু—সঠিক উত্তর কোনটি?","options":["সালমোনেলা","মাইকোব্যাকটেরিয়াম","প্লাজমোডিয়াম","ভিব্রিও কলেরি"],"answer":2,"explain":"সঠিক উত্তর: প্লাজমোডিয়াম।"},{"q":"নিচের কোনটি সঠিক? ম্যালেরিয়ার জীবাণু।","options":["মাইকোব্যাকটেরিয়াম","প্লাজমোডিয়াম","ভিব্রিও কলেরি","সালমোনেলা"],"answer":1,"explain":"সঠিক উত্তর: প্লাজমোডিয়াম।"},{"q":"ম্যালেরিয়ার জীবাণু সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["প্লাজমোডিয়াম","ভিব্রিও কলেরি","সালমোনেলা","মাইকোব্যাকটেরিয়াম"],"answer":0,"explain":"সঠিক উত্তর: প্লাজমোডিয়াম।"},{"q":"ডেঙ্গু ছড়ায়—সঠিক উত্তর কোনটি?","options":["অ্যানোফিলিস মশা","কিউলেক্স মশা","ঘরের মাছি","এডিস মশা"],"answer":3,"explain":"সঠিক উত্তর: এডিস মশা।"},{"q":"নিচের কোনটি সঠিক? ডেঙ্গু ছড়ায়।","options":["কিউলেক্স মশা","ঘরের মাছি","এডিস মশা","অ্যানোফিলিস মশা"],"answer":2,"explain":"সঠিক উত্তর: এডিস মশা।"},{"q":"ডেঙ্গু ছড়ায় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ঘরের মাছি","এডিস মশা","অ্যানোফিলিস মশা","কিউলেক্স মশা"],"answer":1,"explain":"সঠিক উত্তর: এডিস মশা।"},{"q":"যক্ষ্মার জীবাণু—সঠিক উত্তর কোনটি?","options":["মাইকোব্যাকটেরিয়াম টিউবারকিউলোসিস","প্লাজমোডিয়াম","এইচআইভি","ভিব্রিও কলেরি"],"answer":0,"explain":"সঠিক উত্তর: মাইকোব্যাকটেরিয়াম টিউবারকিউলোসিস।"},{"q":"নিচের কোনটি সঠিক? যক্ষ্মার জীবাণু।","options":["প্লাজমোডিয়াম","এইচআইভি","ভিব্রিও কলেরি","মাইকোব্যাকটেরিয়াম টিউবারকিউলোসিস"],"answer":3,"explain":"সঠিক উত্তর: মাইকোব্যাকটেরিয়াম টিউবারকিউলোসিস।"},{"q":"যক্ষ্মার জীবাণু সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["এইচআইভি","ভিব্রিও কলেরি","মাইকোব্যাকটেরিয়াম টিউবারকিউলোসিস","প্লাজমোডিয়াম"],"answer":2,"explain":"সঠিক উত্তর: মাইকোব্যাকটেরিয়াম টিউবারকিউলোসিস।"},{"q":"কলেরার জীবাণু—সঠিক উত্তর কোনটি?","options":["প্লাজমোডিয়াম","ভিব্রিও কলেরি","সালমোনেলা টাইফি","রাইনোভাইরাস"],"answer":1,"explain":"সঠিক উত্তর: ভিব্রিও কলেরি।"},{"q":"নিচের কোনটি সঠিক? কলেরার জীবাণু।","options":["ভিব্রিও কলেরি","সালমোনেলা টাইফি","রাইনোভাইরাস","প্লাজমোডিয়াম"],"answer":0,"explain":"সঠিক উত্তর: ভিব্রিও কলেরি।"},{"q":"কলেরার জীবাণু সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["সালমোনেলা টাইফি","রাইনোভাইরাস","প্লাজমোডিয়াম","ভিব্রিও কলেরি"],"answer":3,"explain":"সঠিক উত্তর: ভিব্রিও কলেরি।"},{"q":"ছত্রাকবিদ্যার নাম—সঠিক উত্তর কোনটি?","options":["জুওলজি","ইকোলজি","মাইকোলজি","বোটানি"],"answer":2,"explain":"সঠিক উত্তর: মাইকোলজি।"},{"q":"নিচের কোনটি সঠিক? ছত্রাকবিদ্যার নাম।","options":["ইকোলজি","মাইকোলজি","বোটানি","জুওলজি"],"answer":1,"explain":"সঠিক উত্তর: মাইকোলজি।"},{"q":"ছত্রাকবিদ্যার নাম সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["মাইকোলজি","বোটানি","জুওলজি","ইকোলজি"],"answer":0,"explain":"সঠিক উত্তর: মাইকোলজি।"}],"মানবদেহ ও শারীরতত্ত্ব":[{"q":"মানবদেহের বৃহত্তম অঙ্গ—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","ফুসফুস","হৃৎপিণ্ড"],"answer":0,"explain":"সঠিক উত্তর: ত্বক।"},{"q":"নিচের কোনটি সঠিক? মানবদেহের বৃহত্তম অঙ্গ।","options":["যকৃত","ফুসফুস","হৃৎপিণ্ড","ত্বক"],"answer":3,"explain":"সঠিক উত্তর: ত্বক।"},{"q":"মানবদেহের বৃহত্তম অঙ্গ সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ফুসফুস","হৃৎপিণ্ড","ত্বক","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: ত্বক।"},{"q":"মানবদেহের বৃহত্তম গ্রন্থি—সঠিক উত্তর কোনটি?","options":["পিটুইটারি","যকৃত","অগ্ন্যাশয়","থাইরয়েড"],"answer":1,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"নিচের কোনটি সঠিক? মানবদেহের বৃহত্তম গ্রন্থি।","options":["যকৃত","অগ্ন্যাশয়","থাইরয়েড","পিটুইটারি"],"answer":0,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"মানবদেহের বৃহত্তম গ্রন্থি সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["অগ্ন্যাশয়","থাইরয়েড","পিটুইটারি","যকৃত"],"answer":3,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"মানবদেহের ক্ষুদ্রতম অস্থি—সঠিক উত্তর কোনটি?","options":["টিবিয়া","হিউমেরাস","স্টেপিস","ফিমার"],"answer":2,"explain":"সঠিক উত্তর: স্টেপিস।"},{"q":"নিচের কোনটি সঠিক? মানবদেহের ক্ষুদ্রতম অস্থি।","options":["হিউমেরাস","স্টেপিস","ফিমার","টিবিয়া"],"answer":1,"explain":"সঠিক উত্তর: স্টেপিস।"},{"q":"মানবদেহের ক্ষুদ্রতম অস্থি সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["স্টেপিস","ফিমার","টিবিয়া","হিউমেরাস"],"answer":0,"explain":"সঠিক উত্তর: স্টেপিস।"},{"q":"মানবদেহের দীর্ঘতম অস্থি—সঠিক উত্তর কোনটি?","options":["টিবিয়া","রেডিয়াস","আলনা","ফিমার"],"answer":3,"explain":"সঠিক উত্তর: ফিমার।"},{"q":"নিচের কোনটি সঠিক? মানবদেহের দীর্ঘতম অস্থি।","options":["রেডিয়াস","আলনা","ফিমার","টিবিয়া"],"answer":2,"explain":"সঠিক উত্তর: ফিমার।"},{"q":"মানবদেহের দীর্ঘতম অস্থি সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["আলনা","ফিমার","টিবিয়া","রেডিয়াস"],"answer":1,"explain":"সঠিক উত্তর: ফিমার।"},{"q":"হৃৎপিণ্ডে প্রকোষ্ঠের সংখ্যা—সঠিক উত্তর কোনটি?","options":["চারটি","দুটি","তিনটি","পাঁচটি"],"answer":0,"explain":"সঠিক উত্তর: চারটি।"},{"q":"নিচের কোনটি সঠিক? হৃৎপিণ্ডে প্রকোষ্ঠের সংখ্যা।","options":["দুটি","তিনটি","পাঁচটি","চারটি"],"answer":3,"explain":"সঠিক উত্তর: চারটি।"},{"q":"হৃৎপিণ্ডে প্রকোষ্ঠের সংখ্যা সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["তিনটি","পাঁচটি","চারটি","দুটি"],"answer":2,"explain":"সঠিক উত্তর: চারটি।"},{"q":"হৃৎপিণ্ডের প্রাকৃতিক পেসমেকার—সঠিক উত্তর কোনটি?","options":["অ্যাপেক্স","SA নোড","AV নোড","বান্ডল অব হিজ"],"answer":1,"explain":"সঠিক উত্তর: SA নোড।"},{"q":"নিচের কোনটি সঠিক? হৃৎপিণ্ডের প্রাকৃতিক পেসমেকার।","options":["SA নোড","AV নোড","বান্ডল অব হিজ","অ্যাপেক্স"],"answer":0,"explain":"সঠিক উত্তর: SA নোড।"},{"q":"হৃৎপিণ্ডের প্রাকৃতিক পেসমেকার সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["AV নোড","বান্ডল অব হিজ","অ্যাপেক্স","SA নোড"],"answer":3,"explain":"সঠিক উত্তর: SA নোড।"},{"q":"কিডনির গঠনগত ও কার্যগত একক—সঠিক উত্তর কোনটি?","options":["অ্যালভিওলাস","ভিলাই","নেফ্রন","নিউরন"],"answer":2,"explain":"সঠিক উত্তর: নেফ্রন।"},{"q":"নিচের কোনটি সঠিক? কিডনির গঠনগত ও কার্যগত একক।","options":["ভিলাই","নেফ্রন","নিউরন","অ্যালভিওলাস"],"answer":1,"explain":"সঠিক উত্তর: নেফ্রন।"},{"q":"কিডনির গঠনগত ও কার্যগত একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নেফ্রন","নিউরন","অ্যালভিওলাস","ভিলাই"],"answer":0,"explain":"সঠিক উত্তর: নেফ্রন।"},{"q":"ফুসফুসে গ্যাস বিনিময় হয়—সঠিক উত্তর কোনটি?","options":["ব্রঙ্কাসে","ট্রাকিয়ায়","প্লুরায়","অ্যালভিওলাইতে"],"answer":3,"explain":"সঠিক উত্তর: অ্যালভিওলাইতে।"},{"q":"নিচের কোনটি সঠিক? ফুসফুসে গ্যাস বিনিময় হয়।","options":["ট্রাকিয়ায়","প্লুরায়","অ্যালভিওলাইতে","ব্রঙ্কাসে"],"answer":2,"explain":"সঠিক উত্তর: অ্যালভিওলাইতে।"},{"q":"ফুসফুসে গ্যাস বিনিময় হয় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["প্লুরায়","অ্যালভিওলাইতে","ব্রঙ্কাসে","ট্রাকিয়ায়"],"answer":1,"explain":"সঠিক উত্তর: অ্যালভিওলাইতে।"},{"q":"ইনসুলিন নিঃসৃত হয়—সঠিক উত্তর কোনটি?","options":["অগ্ন্যাশয় থেকে","যকৃত থেকে","থাইরয়েড থেকে","পিটুইটারি থেকে"],"answer":0,"explain":"সঠিক উত্তর: অগ্ন্যাশয় থেকে।"},{"q":"নিচের কোনটি সঠিক? ইনসুলিন নিঃসৃত হয়।","options":["যকৃত থেকে","থাইরয়েড থেকে","পিটুইটারি থেকে","অগ্ন্যাশয় থেকে"],"answer":3,"explain":"সঠিক উত্তর: অগ্ন্যাশয় থেকে।"},{"q":"ইনসুলিন নিঃসৃত হয় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["থাইরয়েড থেকে","পিটুইটারি থেকে","অগ্ন্যাশয় থেকে","যকৃত থেকে"],"answer":2,"explain":"সঠিক উত্তর: অগ্ন্যাশয় থেকে।"},{"q":"পিত্তরস তৈরি হয়—সঠিক উত্তর কোনটি?","options":["পাকস্থলীতে","যকৃতে","পিত্তথলিতে","অগ্ন্যাশয়ে"],"answer":1,"explain":"সঠিক উত্তর: যকৃতে।"},{"q":"নিচের কোনটি সঠিক? পিত্তরস তৈরি হয়।","options":["যকৃতে","পিত্তথলিতে","অগ্ন্যাশয়ে","পাকস্থলীতে"],"answer":0,"explain":"সঠিক উত্তর: যকৃতে।"},{"q":"পিত্তরস তৈরি হয় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["পিত্তথলিতে","অগ্ন্যাশয়ে","পাকস্থলীতে","যকৃতে"],"answer":3,"explain":"সঠিক উত্তর: যকৃতে।"},{"q":"পিত্তরস জমা থাকে—সঠিক উত্তর কোনটি?","options":["প্লীহায়","অগ্ন্যাশয়ে","পিত্তথলিতে","যকৃতে"],"answer":2,"explain":"সঠিক উত্তর: পিত্তথলিতে।"},{"q":"নিচের কোনটি সঠিক? পিত্তরস জমা থাকে।","options":["অগ্ন্যাশয়ে","পিত্তথলিতে","যকৃতে","প্লীহায়"],"answer":1,"explain":"সঠিক উত্তর: পিত্তথলিতে।"},{"q":"পিত্তরস জমা থাকে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["পিত্তথলিতে","যকৃতে","প্লীহায়","অগ্ন্যাশয়ে"],"answer":0,"explain":"সঠিক উত্তর: পিত্তথলিতে।"},{"q":"মানবদেহে রক্তের স্বাভাবিক pH—সঠিক উত্তর কোনটি?","options":["প্রায় ৫.৪","প্রায় ৬.০","প্রায় ৮.৫","প্রায় ৭.৪"],"answer":3,"explain":"সঠিক উত্তর: প্রায় ৭.৪।"},{"q":"নিচের কোনটি সঠিক? মানবদেহে রক্তের স্বাভাবিক pH।","options":["প্রায় ৬.০","প্রায় ৮.৫","প্রায় ৭.৪","প্রায় ৫.৪"],"answer":2,"explain":"সঠিক উত্তর: প্রায় ৭.৪।"},{"q":"মানবদেহে রক্তের স্বাভাবিক pH সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["প্রায় ৮.৫","প্রায় ৭.৪","প্রায় ৫.৪","প্রায় ৬.০"],"answer":1,"explain":"সঠিক উত্তর: প্রায় ৭.৪।"},{"q":"প্রাপ্তবয়স্ক মানুষের স্বাভাবিক নাড়ির গতি—সঠিক উত্তর কোনটি?","options":["প্রতি মিনিটে ৬০–১০০ বার","২০–৪০ বার","১১০–১৪০ বার","১৫০–১৮০ বার"],"answer":0,"explain":"সঠিক উত্তর: প্রতি মিনিটে ৬০–১০০ বার।"},{"q":"নিচের কোনটি সঠিক? প্রাপ্তবয়স্ক মানুষের স্বাভাবিক নাড়ির গতি।","options":["২০–৪০ বার","১১০–১৪০ বার","১৫০–১৮০ বার","প্রতি মিনিটে ৬০–১০০ বার"],"answer":3,"explain":"সঠিক উত্তর: প্রতি মিনিটে ৬০–১০০ বার।"},{"q":"প্রাপ্তবয়স্ক মানুষের স্বাভাবিক নাড়ির গতি সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["১১০–১৪০ বার","১৫০–১৮০ বার","প্রতি মিনিটে ৬০–১০০ বার","২০–৪০ বার"],"answer":2,"explain":"সঠিক উত্তর: প্রতি মিনিটে ৬০–১০০ বার।"},{"q":"প্রাপ্তবয়স্ক মানুষের স্বাভাবিক শ্বাস-প্রশ্বাস—সঠিক উত্তর কোনটি?","options":["৪০–৫০ বার","প্রতি মিনিটে ১২–২০ বার","৪–৮ বার","২৫–৩৫ বার"],"answer":1,"explain":"সঠিক উত্তর: প্রতি মিনিটে ১২–২০ বার।"},{"q":"নিচের কোনটি সঠিক? প্রাপ্তবয়স্ক মানুষের স্বাভাবিক শ্বাস-প্রশ্বাস।","options":["প্রতি মিনিটে ১২–২০ বার","৪–৮ বার","২৫–৩৫ বার","৪০–৫০ বার"],"answer":0,"explain":"সঠিক উত্তর: প্রতি মিনিটে ১২–২০ বার।"},{"q":"প্রাপ্তবয়স্ক মানুষের স্বাভাবিক শ্বাস-প্রশ্বাস সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৪–৮ বার","২৫–৩৫ বার","৪০–৫০ বার","প্রতি মিনিটে ১২–২০ বার"],"answer":3,"explain":"সঠিক উত্তর: প্রতি মিনিটে ১২–২০ বার।"},{"q":"মানবদেহের স্বাভাবিক তাপমাত্রা—সঠিক উত্তর কোনটি?","options":["৩৯°","৪২°","প্রায় ৩৭° সেলসিয়াস","৩৪°"],"answer":2,"explain":"সঠিক উত্তর: প্রায় ৩৭° সেলসিয়াস।"},{"q":"নিচের কোনটি সঠিক? মানবদেহের স্বাভাবিক তাপমাত্রা।","options":["৪২°","প্রায় ৩৭° সেলসিয়াস","৩৪°","৩৯°"],"answer":1,"explain":"সঠিক উত্তর: প্রায় ৩৭° সেলসিয়াস।"},{"q":"মানবদেহের স্বাভাবিক তাপমাত্রা সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["প্রায় ৩৭° সেলসিয়াস","৩৪°","৩৯°","৪২°"],"answer":0,"explain":"সঠিক উত্তর: প্রায় ৩৭° সেলসিয়াস।"}],"রসায়ন":[{"q":"পানির রাসায়নিক সংকেত—সঠিক উত্তর কোনটি?","options":["H₂O","CO₂","O₂","H₂"],"answer":0,"explain":"সঠিক উত্তর: H₂O।"},{"q":"নিচের কোনটি সঠিক? পানির রাসায়নিক সংকেত।","options":["CO₂","O₂","H₂","H₂O"],"answer":3,"explain":"সঠিক উত্তর: H₂O।"},{"q":"পানির রাসায়নিক সংকেত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["O₂","H₂","H₂O","CO₂"],"answer":2,"explain":"সঠিক উত্তর: H₂O।"},{"q":"খাবার লবণের রাসায়নিক নাম—সঠিক উত্তর কোনটি?","options":["পটাশিয়াম নাইট্রেট","সোডিয়াম ক্লোরাইড","সোডিয়াম কার্বনেট","ক্যালসিয়াম ক্লোরাইড"],"answer":1,"explain":"সঠিক উত্তর: সোডিয়াম ক্লোরাইড।"},{"q":"নিচের কোনটি সঠিক? খাবার লবণের রাসায়নিক নাম।","options":["সোডিয়াম ক্লোরাইড","সোডিয়াম কার্বনেট","ক্যালসিয়াম ক্লোরাইড","পটাশিয়াম নাইট্রেট"],"answer":0,"explain":"সঠিক উত্তর: সোডিয়াম ক্লোরাইড।"},{"q":"খাবার লবণের রাসায়নিক নাম সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["সোডিয়াম কার্বনেট","ক্যালসিয়াম ক্লোরাইড","পটাশিয়াম নাইট্রেট","সোডিয়াম ক্লোরাইড"],"answer":3,"explain":"সঠিক উত্তর: সোডিয়াম ক্লোরাইড।"},{"q":"বিশুদ্ধ পানির pH—সঠিক উত্তর কোনটি?","options":["৫","১৪","৭","০"],"answer":2,"explain":"সঠিক উত্তর: ৭।"},{"q":"নিচের কোনটি সঠিক? বিশুদ্ধ পানির pH।","options":["১৪","৭","০","৫"],"answer":1,"explain":"সঠিক উত্তর: ৭।"},{"q":"বিশুদ্ধ পানির pH সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৭","০","৫","১৪"],"answer":0,"explain":"সঠিক উত্তর: ৭।"},{"q":"অম্ল নীল লিটমাসকে করে—সঠিক উত্তর কোনটি?","options":["সবুজ","হলুদ","নীল","লাল"],"answer":3,"explain":"সঠিক উত্তর: লাল।"},{"q":"নিচের কোনটি সঠিক? অম্ল নীল লিটমাসকে করে।","options":["হলুদ","নীল","লাল","সবুজ"],"answer":2,"explain":"সঠিক উত্তর: লাল।"},{"q":"অম্ল নীল লিটমাসকে করে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নীল","লাল","সবুজ","হলুদ"],"answer":1,"explain":"সঠিক উত্তর: লাল।"},{"q":"ক্ষার লাল লিটমাসকে করে—সঠিক উত্তর কোনটি?","options":["নীল","লাল","কালো","বর্ণহীন"],"answer":0,"explain":"সঠিক উত্তর: নীল।"},{"q":"নিচের কোনটি সঠিক? ক্ষার লাল লিটমাসকে করে।","options":["লাল","কালো","বর্ণহীন","নীল"],"answer":3,"explain":"সঠিক উত্তর: নীল।"},{"q":"ক্ষার লাল লিটমাসকে করে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["কালো","বর্ণহীন","নীল","লাল"],"answer":2,"explain":"সঠিক উত্তর: নীল।"},{"q":"পরমাণুর কেন্দ্রে থাকে—সঠিক উত্তর কোনটি?","options":["ফোটন","প্রোটন ও নিউট্রন","ইলেকট্রন","শুধু ইলেকট্রন"],"answer":1,"explain":"সঠিক উত্তর: প্রোটন ও নিউট্রন।"},{"q":"নিচের কোনটি সঠিক? পরমাণুর কেন্দ্রে থাকে।","options":["প্রোটন ও নিউট্রন","ইলেকট্রন","শুধু ইলেকট্রন","ফোটন"],"answer":0,"explain":"সঠিক উত্তর: প্রোটন ও নিউট্রন।"},{"q":"পরমাণুর কেন্দ্রে থাকে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ইলেকট্রন","শুধু ইলেকট্রন","ফোটন","প্রোটন ও নিউট্রন"],"answer":3,"explain":"সঠিক উত্তর: প্রোটন ও নিউট্রন।"},{"q":"ইলেকট্রনের আধান—সঠিক উত্তর কোনটি?","options":["নিরপেক্ষ","দ্বিগুণ ধনাত্মক","ঋণাত্মক","ধনাত্মক"],"answer":2,"explain":"সঠিক উত্তর: ঋণাত্মক।"},{"q":"নিচের কোনটি সঠিক? ইলেকট্রনের আধান।","options":["দ্বিগুণ ধনাত্মক","ঋণাত্মক","ধনাত্মক","নিরপেক্ষ"],"answer":1,"explain":"সঠিক উত্তর: ঋণাত্মক।"},{"q":"ইলেকট্রনের আধান সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ঋণাত্মক","ধনাত্মক","নিরপেক্ষ","দ্বিগুণ ধনাত্মক"],"answer":0,"explain":"সঠিক উত্তর: ঋণাত্মক।"},{"q":"পারমাণবিক সংখ্যা নির্দেশ করে—সঠিক উত্তর কোনটি?","options":["নিউট্রন সংখ্যা","প্রোটন ও নিউট্রনের যোগফল","ইলেকট্রন স্তর","প্রোটন সংখ্যা"],"answer":3,"explain":"সঠিক উত্তর: প্রোটন সংখ্যা।"},{"q":"নিচের কোনটি সঠিক? পারমাণবিক সংখ্যা নির্দেশ করে।","options":["প্রোটন ও নিউট্রনের যোগফল","ইলেকট্রন স্তর","প্রোটন সংখ্যা","নিউট্রন সংখ্যা"],"answer":2,"explain":"সঠিক উত্তর: প্রোটন সংখ্যা।"},{"q":"পারমাণবিক সংখ্যা নির্দেশ করে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ইলেকট্রন স্তর","প্রোটন সংখ্যা","নিউট্রন সংখ্যা","প্রোটন ও নিউট্রনের যোগফল"],"answer":1,"explain":"সঠিক উত্তর: প্রোটন সংখ্যা।"},{"q":"অক্সিজেনের পারমাণবিক সংখ্যা—সঠিক উত্তর কোনটি?","options":["৮","৬","৭","১৬"],"answer":0,"explain":"সঠিক উত্তর: ৮।"},{"q":"নিচের কোনটি সঠিক? অক্সিজেনের পারমাণবিক সংখ্যা।","options":["৬","৭","১৬","৮"],"answer":3,"explain":"সঠিক উত্তর: ৮।"},{"q":"অক্সিজেনের পারমাণবিক সংখ্যা সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৭","১৬","৮","৬"],"answer":2,"explain":"সঠিক উত্তর: ৮।"},{"q":"কার্বনের পারমাণবিক সংখ্যা—সঠিক উত্তর কোনটি?","options":["১২","৬","৪","৮"],"answer":1,"explain":"সঠিক উত্তর: ৬।"},{"q":"নিচের কোনটি সঠিক? কার্বনের পারমাণবিক সংখ্যা।","options":["৬","৪","৮","১২"],"answer":0,"explain":"সঠিক উত্তর: ৬।"},{"q":"কার্বনের পারমাণবিক সংখ্যা সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৪","৮","১২","৬"],"answer":3,"explain":"সঠিক উত্তর: ৬।"},{"q":"অক্সিজেনের যোজ্যতা সাধারণত—সঠিক উত্তর কোনটি?","options":["৩","৪","২","১"],"answer":2,"explain":"সঠিক উত্তর: ২।"},{"q":"নিচের কোনটি সঠিক? অক্সিজেনের যোজ্যতা সাধারণত।","options":["৪","২","১","৩"],"answer":1,"explain":"সঠিক উত্তর: ২।"},{"q":"অক্সিজেনের যোজ্যতা সাধারণত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["২","১","৩","৪"],"answer":0,"explain":"সঠিক উত্তর: ২।"},{"q":"কার্বন ডাই-অক্সাইডের সংকেত—সঠিক উত্তর কোনটি?","options":["CO","C₂O","CaO","CO₂"],"answer":3,"explain":"সঠিক উত্তর: CO₂।"},{"q":"নিচের কোনটি সঠিক? কার্বন ডাই-অক্সাইডের সংকেত।","options":["C₂O","CaO","CO₂","CO"],"answer":2,"explain":"সঠিক উত্তর: CO₂।"},{"q":"কার্বন ডাই-অক্সাইডের সংকেত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["CaO","CO₂","CO","C₂O"],"answer":1,"explain":"সঠিক উত্তর: CO₂।"},{"q":"অ্যামোনিয়ার সংকেত—সঠিক উত্তর কোনটি?","options":["NH₃","NO₂","N₂O","HNO₃"],"answer":0,"explain":"সঠিক উত্তর: NH₃।"},{"q":"নিচের কোনটি সঠিক? অ্যামোনিয়ার সংকেত।","options":["NO₂","N₂O","HNO₃","NH₃"],"answer":3,"explain":"সঠিক উত্তর: NH₃।"},{"q":"অ্যামোনিয়ার সংকেত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["N₂O","HNO₃","NH₃","NO₂"],"answer":2,"explain":"সঠিক উত্তর: NH₃।"},{"q":"সালফিউরিক অ্যাসিডের সংকেত—সঠিক উত্তর কোনটি?","options":["CH₃COOH","H₂SO₄","HCl","HNO₃"],"answer":1,"explain":"সঠিক উত্তর: H₂SO₄।"},{"q":"নিচের কোনটি সঠিক? সালফিউরিক অ্যাসিডের সংকেত।","options":["H₂SO₄","HCl","HNO₃","CH₃COOH"],"answer":0,"explain":"সঠিক উত্তর: H₂SO₄।"},{"q":"সালফিউরিক অ্যাসিডের সংকেত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["HCl","HNO₃","CH₃COOH","H₂SO₄"],"answer":3,"explain":"সঠিক উত্তর: H₂SO₄।"},{"q":"হাইড্রোক্লোরিক অ্যাসিডের সংকেত—সঠিক উত্তর কোনটি?","options":["HNO₃","NaOH","HCl","H₂SO₄"],"answer":2,"explain":"সঠিক উত্তর: HCl।"},{"q":"নিচের কোনটি সঠিক? হাইড্রোক্লোরিক অ্যাসিডের সংকেত।","options":["NaOH","HCl","H₂SO₄","HNO₃"],"answer":1,"explain":"সঠিক উত্তর: HCl।"},{"q":"হাইড্রোক্লোরিক অ্যাসিডের সংকেত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["HCl","H₂SO₄","HNO₃","NaOH"],"answer":0,"explain":"সঠিক উত্তর: HCl।"}],"পদার্থবিজ্ঞান":[{"q":"বল-এর SI একক—সঠিক উত্তর কোনটি?","options":["নিউটন","জুল","ওয়াট","পাস্কাল"],"answer":0,"explain":"সঠিক উত্তর: নিউটন।"},{"q":"নিচের কোনটি সঠিক? বল-এর SI একক।","options":["জুল","ওয়াট","পাস্কাল","নিউটন"],"answer":3,"explain":"সঠিক উত্তর: নিউটন।"},{"q":"বল-এর SI একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ওয়াট","পাস্কাল","নিউটন","জুল"],"answer":2,"explain":"সঠিক উত্তর: নিউটন।"},{"q":"কাজের SI একক—সঠিক উত্তর কোনটি?","options":["অ্যাম্পিয়ার","জুল","নিউটন","ওয়াট"],"answer":1,"explain":"সঠিক উত্তর: জুল।"},{"q":"নিচের কোনটি সঠিক? কাজের SI একক।","options":["জুল","নিউটন","ওয়াট","অ্যাম্পিয়ার"],"answer":0,"explain":"সঠিক উত্তর: জুল।"},{"q":"কাজের SI একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নিউটন","ওয়াট","অ্যাম্পিয়ার","জুল"],"answer":3,"explain":"সঠিক উত্তর: জুল।"},{"q":"ক্ষমতার SI একক—সঠিক উত্তর কোনটি?","options":["ভোল্ট","ওহম","ওয়াট","জুল"],"answer":2,"explain":"সঠিক উত্তর: ওয়াট।"},{"q":"নিচের কোনটি সঠিক? ক্ষমতার SI একক।","options":["ওহম","ওয়াট","জুল","ভোল্ট"],"answer":1,"explain":"সঠিক উত্তর: ওয়াট।"},{"q":"ক্ষমতার SI একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ওয়াট","জুল","ভোল্ট","ওহম"],"answer":0,"explain":"সঠিক উত্তর: ওয়াট।"},{"q":"বিদ্যুৎ প্রবাহের একক—সঠিক উত্তর কোনটি?","options":["ভোল্ট","ওহম","ওয়াট","অ্যাম্পিয়ার"],"answer":3,"explain":"সঠিক উত্তর: অ্যাম্পিয়ার।"},{"q":"নিচের কোনটি সঠিক? বিদ্যুৎ প্রবাহের একক।","options":["ওহম","ওয়াট","অ্যাম্পিয়ার","ভোল্ট"],"answer":2,"explain":"সঠিক উত্তর: অ্যাম্পিয়ার।"},{"q":"বিদ্যুৎ প্রবাহের একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ওয়াট","অ্যাম্পিয়ার","ভোল্ট","ওহম"],"answer":1,"explain":"সঠিক উত্তর: অ্যাম্পিয়ার।"},{"q":"বিভব পার্থক্যের একক—সঠিক উত্তর কোনটি?","options":["ভোল্ট","অ্যাম্পিয়ার","কুলম্ব","ওয়াট"],"answer":0,"explain":"সঠিক উত্তর: ভোল্ট।"},{"q":"নিচের কোনটি সঠিক? বিভব পার্থক্যের একক।","options":["অ্যাম্পিয়ার","কুলম্ব","ওয়াট","ভোল্ট"],"answer":3,"explain":"সঠিক উত্তর: ভোল্ট।"},{"q":"বিভব পার্থক্যের একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["কুলম্ব","ওয়াট","ভোল্ট","অ্যাম্পিয়ার"],"answer":2,"explain":"সঠিক উত্তর: ভোল্ট।"},{"q":"রোধের একক—সঠিক উত্তর কোনটি?","options":["জুল","ওহম","ভোল্ট","ওয়াট"],"answer":1,"explain":"সঠিক উত্তর: ওহম।"},{"q":"নিচের কোনটি সঠিক? রোধের একক।","options":["ওহম","ভোল্ট","ওয়াট","জুল"],"answer":0,"explain":"সঠিক উত্তর: ওহম।"},{"q":"রোধের একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ভোল্ট","ওয়াট","জুল","ওহম"],"answer":3,"explain":"সঠিক উত্তর: ওহম।"},{"q":"আলোর বেগ শূন্যস্থানে প্রায়—সঠিক উত্তর কোনটি?","options":["৩×১০⁴","৩×১০²","৩×১০⁸ মিটার/সেকেন্ড","৩×১০⁶"],"answer":2,"explain":"সঠিক উত্তর: ৩×১০⁸ মিটার/সেকেন্ড।"},{"q":"নিচের কোনটি সঠিক? আলোর বেগ শূন্যস্থানে প্রায়।","options":["৩×১০²","৩×১০⁸ মিটার/সেকেন্ড","৩×১০⁶","৩×১০⁴"],"answer":1,"explain":"সঠিক উত্তর: ৩×১০⁸ মিটার/সেকেন্ড।"},{"q":"আলোর বেগ শূন্যস্থানে প্রায় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৩×১০⁸ মিটার/সেকেন্ড","৩×১০⁶","৩×১০⁴","৩×১০²"],"answer":0,"explain":"সঠিক উত্তর: ৩×১০⁸ মিটার/সেকেন্ড।"},{"q":"শব্দ চলাচল করতে পারে না—সঠিক উত্তর কোনটি?","options":["বায়ুতে","পানিতে","লোহায়","শূন্যস্থানে"],"answer":3,"explain":"সঠিক উত্তর: শূন্যস্থানে।"},{"q":"নিচের কোনটি সঠিক? শব্দ চলাচল করতে পারে না।","options":["পানিতে","লোহায়","শূন্যস্থানে","বায়ুতে"],"answer":2,"explain":"সঠিক উত্তর: শূন্যস্থানে।"},{"q":"শব্দ চলাচল করতে পারে না সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["লোহায়","শূন্যস্থানে","বায়ুতে","পানিতে"],"answer":1,"explain":"সঠিক উত্তর: শূন্যস্থানে।"},{"q":"আলোর প্রতিফলনের সূত্রে আপতন কোণ—সঠিক উত্তর কোনটি?","options":["প্রতিফলন কোণের সমান","বড়","ছোট","দ্বিগুণ"],"answer":0,"explain":"সঠিক উত্তর: প্রতিফলন কোণের সমান।"},{"q":"নিচের কোনটি সঠিক? আলোর প্রতিফলনের সূত্রে আপতন কোণ।","options":["বড়","ছোট","দ্বিগুণ","প্রতিফলন কোণের সমান"],"answer":3,"explain":"সঠিক উত্তর: প্রতিফলন কোণের সমান।"},{"q":"আলোর প্রতিফলনের সূত্রে আপতন কোণ সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ছোট","দ্বিগুণ","প্রতিফলন কোণের সমান","বড়"],"answer":2,"explain":"সঠিক উত্তর: প্রতিফলন কোণের সমান।"},{"q":"উত্তল লেন্স সাধারণত—সঠিক উত্তর কোনটি?","options":["অস্বচ্ছ","অভিসারী","অপসারী","সমতল"],"answer":1,"explain":"সঠিক উত্তর: অভিসারী।"},{"q":"নিচের কোনটি সঠিক? উত্তল লেন্স সাধারণত।","options":["অভিসারী","অপসারী","সমতল","অস্বচ্ছ"],"answer":0,"explain":"সঠিক উত্তর: অভিসারী।"},{"q":"উত্তল লেন্স সাধারণত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["অপসারী","সমতল","অস্বচ্ছ","অভিসারী"],"answer":3,"explain":"সঠিক উত্তর: অভিসারী।"},{"q":"মানব চোখে প্রতিবিম্ব গঠিত হয়—সঠিক উত্তর কোনটি?","options":["আইরিসে","পিউপিলে","রেটিনায়","কর্নিয়ায়"],"answer":2,"explain":"সঠিক উত্তর: রেটিনায়।"},{"q":"নিচের কোনটি সঠিক? মানব চোখে প্রতিবিম্ব গঠিত হয়।","options":["পিউপিলে","রেটিনায়","কর্নিয়ায়","আইরিসে"],"answer":1,"explain":"সঠিক উত্তর: রেটিনায়।"},{"q":"মানব চোখে প্রতিবিম্ব গঠিত হয় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["রেটিনায়","কর্নিয়ায়","আইরিসে","পিউপিলে"],"answer":0,"explain":"সঠিক উত্তর: রেটিনায়।"},{"q":"তাপমাত্রার SI একক—সঠিক উত্তর কোনটি?","options":["সেলসিয়াস","ফারেনহাইট","জুল","কেলভিন"],"answer":3,"explain":"সঠিক উত্তর: কেলভিন।"},{"q":"নিচের কোনটি সঠিক? তাপমাত্রার SI একক।","options":["ফারেনহাইট","জুল","কেলভিন","সেলসিয়াস"],"answer":2,"explain":"সঠিক উত্তর: কেলভিন।"},{"q":"তাপমাত্রার SI একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["জুল","কেলভিন","সেলসিয়াস","ফারেনহাইট"],"answer":1,"explain":"সঠিক উত্তর: কেলভিন।"},{"q":"চাপের SI একক—সঠিক উত্তর কোনটি?","options":["পাস্কাল","নিউটন","ওয়াট","কেলভিন"],"answer":0,"explain":"সঠিক উত্তর: পাস্কাল।"},{"q":"নিচের কোনটি সঠিক? চাপের SI একক।","options":["নিউটন","ওয়াট","কেলভিন","পাস্কাল"],"answer":3,"explain":"সঠিক উত্তর: পাস্কাল।"},{"q":"চাপের SI একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ওয়াট","কেলভিন","পাস্কাল","নিউটন"],"answer":2,"explain":"সঠিক উত্তর: পাস্কাল।"},{"q":"ঘনত্বের SI একক—সঠিক উত্তর কোনটি?","options":["ওয়াট","কেজি/মিটার³","নিউটন","জুল"],"answer":1,"explain":"সঠিক উত্তর: কেজি/মিটার³।"},{"q":"নিচের কোনটি সঠিক? ঘনত্বের SI একক।","options":["কেজি/মিটার³","নিউটন","জুল","ওয়াট"],"answer":0,"explain":"সঠিক উত্তর: কেজি/মিটার³।"},{"q":"ঘনত্বের SI একক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নিউটন","জুল","ওয়াট","কেজি/মিটার³"],"answer":3,"explain":"সঠিক উত্তর: কেজি/মিটার³।"},{"q":"মাধ্যাকর্ষণজনিত ত্বরণ পৃথিবীতে প্রায়—সঠিক উত্তর কোনটি?","options":["১২.৮","১৯.৬","৯.৮ মিটার/সেকেন্ড²","৪.৯"],"answer":2,"explain":"সঠিক উত্তর: ৯.৮ মিটার/সেকেন্ড²।"},{"q":"নিচের কোনটি সঠিক? মাধ্যাকর্ষণজনিত ত্বরণ পৃথিবীতে প্রায়।","options":["১৯.৬","৯.৮ মিটার/সেকেন্ড²","৪.৯","১২.৮"],"answer":1,"explain":"সঠিক উত্তর: ৯.৮ মিটার/সেকেন্ড²।"},{"q":"মাধ্যাকর্ষণজনিত ত্বরণ পৃথিবীতে প্রায় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৯.৮ মিটার/সেকেন্ড²","৪.৯","১২.৮","১৯.৬"],"answer":0,"explain":"সঠিক উত্তর: ৯.৮ মিটার/সেকেন্ড²।"}],"বাংলা ও ইংরেজি":[{"q":"বাংলা ভাষার আদি নিদর্শন—সঠিক উত্তর কোনটি?","options":["চর্যাপদ","শ্রীকৃষ্ণকীর্তন","মঙ্গলকাব্য","গীতাঞ্জলি"],"answer":0,"explain":"সঠিক উত্তর: চর্যাপদ।"},{"q":"নিচের কোনটি সঠিক? বাংলা ভাষার আদি নিদর্শন।","options":["শ্রীকৃষ্ণকীর্তন","মঙ্গলকাব্য","গীতাঞ্জলি","চর্যাপদ"],"answer":3,"explain":"সঠিক উত্তর: চর্যাপদ।"},{"q":"বাংলা ভাষার আদি নিদর্শন সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["মঙ্গলকাব্য","গীতাঞ্জলি","চর্যাপদ","শ্রীকৃষ্ণকীর্তন"],"answer":2,"explain":"সঠিক উত্তর: চর্যাপদ।"},{"q":"চর্যাপদ আবিষ্কার করেন—সঠিক উত্তর কোনটি?","options":["মুহম্মদ শহীদুল্লাহ","হরপ্রসাদ শাস্ত্রী","দীনেশচন্দ্র সেন","সুনীতিকুমার চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: হরপ্রসাদ শাস্ত্রী।"},{"q":"নিচের কোনটি সঠিক? চর্যাপদ আবিষ্কার করেন।","options":["হরপ্রসাদ শাস্ত্রী","দীনেশচন্দ্র সেন","সুনীতিকুমার চট্টোপাধ্যায়","মুহম্মদ শহীদুল্লাহ"],"answer":0,"explain":"সঠিক উত্তর: হরপ্রসাদ শাস্ত্রী।"},{"q":"চর্যাপদ আবিষ্কার করেন সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["দীনেশচন্দ্র সেন","সুনীতিকুমার চট্টোপাধ্যায়","মুহম্মদ শহীদুল্লাহ","হরপ্রসাদ শাস্ত্রী"],"answer":3,"explain":"সঠিক উত্তর: হরপ্রসাদ শাস্ত্রী।"},{"q":"বাংলা বর্ণমালায় স্বরবর্ণ—সঠিক উত্তর কোনটি?","options":["১২টি","১৩টি","১১টি","১০টি"],"answer":2,"explain":"সঠিক উত্তর: ১১টি।"},{"q":"নিচের কোনটি সঠিক? বাংলা বর্ণমালায় স্বরবর্ণ।","options":["১৩টি","১১টি","১০টি","১২টি"],"answer":1,"explain":"সঠিক উত্তর: ১১টি।"},{"q":"বাংলা বর্ণমালায় স্বরবর্ণ সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["১১টি","১০টি","১২টি","১৩টি"],"answer":0,"explain":"সঠিক উত্তর: ১১টি।"},{"q":"বাংলা বর্ণমালায় ব্যঞ্জনবর্ণ—সঠিক উত্তর কোনটি?","options":["৩৫টি","৪০টি","৪২টি","৩৯টি"],"answer":3,"explain":"সঠিক উত্তর: ৩৯টি।"},{"q":"নিচের কোনটি সঠিক? বাংলা বর্ণমালায় ব্যঞ্জনবর্ণ।","options":["৪০টি","৪২টি","৩৯টি","৩৫টি"],"answer":2,"explain":"সঠিক উত্তর: ৩৯টি।"},{"q":"বাংলা বর্ণমালায় ব্যঞ্জনবর্ণ সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৪২টি","৩৯টি","৩৫টি","৪০টি"],"answer":1,"explain":"সঠিক উত্তর: ৩৯টি।"},{"q":"‘অগ্নি’ শব্দের সমার্থক—সঠিক উত্তর কোনটি?","options":["অনল","জল","বায়ু","ধরণী"],"answer":0,"explain":"সঠিক উত্তর: অনল।"},{"q":"নিচের কোনটি সঠিক? ‘অগ্নি’ শব্দের সমার্থক।","options":["জল","বায়ু","ধরণী","অনল"],"answer":3,"explain":"সঠিক উত্তর: অনল।"},{"q":"‘অগ্নি’ শব্দের সমার্থক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["বায়ু","ধরণী","অনল","জল"],"answer":2,"explain":"সঠিক উত্তর: অনল।"},{"q":"‘আকাশ’ শব্দের সমার্থক—সঠিক উত্তর কোনটি?","options":["অনল","গগন","পবন","সলিল"],"answer":1,"explain":"সঠিক উত্তর: গগন।"},{"q":"নিচের কোনটি সঠিক? ‘আকাশ’ শব্দের সমার্থক।","options":["গগন","পবন","সলিল","অনল"],"answer":0,"explain":"সঠিক উত্তর: গগন।"},{"q":"‘আকাশ’ শব্দের সমার্থক সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["পবন","সলিল","অনল","গগন"],"answer":3,"explain":"সঠিক উত্তর: গগন।"},{"q":"‘উন্নতি’ শব্দের বিপরীত—সঠিক উত্তর কোনটি?","options":["সমৃদ্ধি","বিকাশ","অবনতি","অগ্রগতি"],"answer":2,"explain":"সঠিক উত্তর: অবনতি।"},{"q":"নিচের কোনটি সঠিক? ‘উন্নতি’ শব্দের বিপরীত।","options":["বিকাশ","অবনতি","অগ্রগতি","সমৃদ্ধি"],"answer":1,"explain":"সঠিক উত্তর: অবনতি।"},{"q":"‘উন্নতি’ শব্দের বিপরীত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["অবনতি","অগ্রগতি","সমৃদ্ধি","বিকাশ"],"answer":0,"explain":"সঠিক উত্তর: অবনতি।"},{"q":"‘নির্ভীক’ শব্দের বিপরীত—সঠিক উত্তর কোনটি?","options":["সাহসী","দৃঢ়","নির্ভর","ভীরু"],"answer":3,"explain":"সঠিক উত্তর: ভীরু।"},{"q":"নিচের কোনটি সঠিক? ‘নির্ভীক’ শব্দের বিপরীত।","options":["দৃঢ়","নির্ভর","ভীরু","সাহসী"],"answer":2,"explain":"সঠিক উত্তর: ভীরু।"},{"q":"‘নির্ভীক’ শব্দের বিপরীত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নির্ভর","ভীরু","সাহসী","দৃঢ়"],"answer":1,"explain":"সঠিক উত্তর: ভীরু।"},{"q":"যে উপকারীর উপকার স্বীকার করে—সঠিক উত্তর কোনটি?","options":["কৃতজ্ঞ","কৃতঘ্ন","নির্দয়","অকর্মণ্য"],"answer":0,"explain":"সঠিক উত্তর: কৃতজ্ঞ।"},{"q":"নিচের কোনটি সঠিক? যে উপকারীর উপকার স্বীকার করে।","options":["কৃতঘ্ন","নির্দয়","অকর্মণ্য","কৃতজ্ঞ"],"answer":3,"explain":"সঠিক উত্তর: কৃতজ্ঞ।"},{"q":"যে উপকারীর উপকার স্বীকার করে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["নির্দয়","অকর্মণ্য","কৃতজ্ঞ","কৃতঘ্ন"],"answer":2,"explain":"সঠিক উত্তর: কৃতজ্ঞ।"},{"q":"‘বিদ্যালয়’ শব্দের সন্ধি বিচ্ছেদ—সঠিক উত্তর কোনটি?","options":["বিদ + আলয়","বিদ্যা + আলয়","বিদ্য + আলয়","বিদ্যা + লয়"],"answer":1,"explain":"সঠিক উত্তর: বিদ্যা + আলয়।"},{"q":"নিচের কোনটি সঠিক? ‘বিদ্যালয়’ শব্দের সন্ধি বিচ্ছেদ।","options":["বিদ্যা + আলয়","বিদ্য + আলয়","বিদ্যা + লয়","বিদ + আলয়"],"answer":0,"explain":"সঠিক উত্তর: বিদ্যা + আলয়।"},{"q":"‘বিদ্যালয়’ শব্দের সন্ধি বিচ্ছেদ সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["বিদ্য + আলয়","বিদ্যা + লয়","বিদ + আলয়","বিদ্যা + আলয়"],"answer":3,"explain":"সঠিক উত্তর: বিদ্যা + আলয়।"},{"q":"সঠিক ইংরেজি বানান কোনটি—সঠিক উত্তর কোনটি?","options":["Accomodation","Acomodation","অ্যাকোমোডেশন (Accommodation)","Acommodation"],"answer":2,"explain":"সঠিক উত্তর: অ্যাকোমোডেশন (Accommodation)।"},{"q":"নিচের কোনটি সঠিক? সঠিক ইংরেজি বানান কোনটি।","options":["Acomodation","অ্যাকোমোডেশন (Accommodation)","Acommodation","Accomodation"],"answer":1,"explain":"সঠিক উত্তর: অ্যাকোমোডেশন (Accommodation)।"},{"q":"সঠিক ইংরেজি বানান কোনটি সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["অ্যাকোমোডেশন (Accommodation)","Acommodation","Accomodation","Acomodation"],"answer":0,"explain":"সঠিক উত্তর: অ্যাকোমোডেশন (Accommodation)।"},{"q":"“Honest” শব্দের আগে সঠিক article—সঠিক উত্তর কোনটি?","options":["A","The","No article","An"],"answer":3,"explain":"সঠিক উত্তর: An।"},{"q":"নিচের কোনটি সঠিক? “Honest” শব্দের আগে সঠিক article।","options":["The","No article","An","A"],"answer":2,"explain":"সঠিক উত্তর: An।"},{"q":"“Honest” শব্দের আগে সঠিক article সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["No article","An","A","The"],"answer":1,"explain":"সঠিক উত্তর: An।"},{"q":"“Child” এর বহুবচন—সঠিক উত্তর কোনটি?","options":["Children","Childs","Childes","Childrens"],"answer":0,"explain":"সঠিক উত্তর: Children।"},{"q":"নিচের কোনটি সঠিক? “Child” এর বহুবচন।","options":["Childs","Childes","Childrens","Children"],"answer":3,"explain":"সঠিক উত্তর: Children।"},{"q":"“Child” এর বহুবচন সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["Childes","Childrens","Children","Childs"],"answer":2,"explain":"সঠিক উত্তর: Children।"},{"q":"“Go” এর past form—সঠিক উত্তর কোনটি?","options":["Going","Went","Goed","Gone"],"answer":1,"explain":"সঠিক উত্তর: Went।"},{"q":"নিচের কোনটি সঠিক? “Go” এর past form।","options":["Went","Goed","Gone","Going"],"answer":0,"explain":"সঠিক উত্তর: Went।"},{"q":"“Go” এর past form সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["Goed","Gone","Going","Went"],"answer":3,"explain":"সঠিক উত্তর: Went।"},{"q":"“Good” এর comparative—সঠিক উত্তর কোনটি?","options":["Gooder","More good","Better","Best"],"answer":2,"explain":"সঠিক উত্তর: Better।"},{"q":"নিচের কোনটি সঠিক? “Good” এর comparative।","options":["More good","Better","Best","Gooder"],"answer":1,"explain":"সঠিক উত্তর: Better।"},{"q":"“Good” এর comparative সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["Better","Best","Gooder","More good"],"answer":0,"explain":"সঠিক উত্তর: Better।"}],"বাংলাদেশ ও সাধারণ জ্ঞান":[{"q":"বাংলাদেশের স্বাধীনতা দিবস—সঠিক উত্তর কোনটি?","options":["২৬ মার্চ","২১ ফেব্রুয়ারি","১৬ ডিসেম্বর","৭ মার্চ"],"answer":0,"explain":"সঠিক উত্তর: ২৬ মার্চ।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের স্বাধীনতা দিবস।","options":["২১ ফেব্রুয়ারি","১৬ ডিসেম্বর","৭ মার্চ","২৬ মার্চ"],"answer":3,"explain":"সঠিক উত্তর: ২৬ মার্চ।"},{"q":"বাংলাদেশের স্বাধীনতা দিবস সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["১৬ ডিসেম্বর","৭ মার্চ","২৬ মার্চ","২১ ফেব্রুয়ারি"],"answer":2,"explain":"সঠিক উত্তর: ২৬ মার্চ।"},{"q":"বাংলাদেশের বিজয় দিবস—সঠিক উত্তর কোনটি?","options":["২১ ফেব্রুয়ারি","১৬ ডিসেম্বর","২৬ মার্চ","১৪ ডিসেম্বর"],"answer":1,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের বিজয় দিবস।","options":["১৬ ডিসেম্বর","২৬ মার্চ","১৪ ডিসেম্বর","২১ ফেব্রুয়ারি"],"answer":0,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর।"},{"q":"বাংলাদেশের বিজয় দিবস সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["২৬ মার্চ","১৪ ডিসেম্বর","২১ ফেব্রুয়ারি","১৬ ডিসেম্বর"],"answer":3,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর।"},{"q":"আন্তর্জাতিক মাতৃভাষা দিবস—সঠিক উত্তর কোনটি?","options":["১৬ ডিসেম্বর","১ মে","২১ ফেব্রুয়ারি","২৬ মার্চ"],"answer":2,"explain":"সঠিক উত্তর: ২১ ফেব্রুয়ারি।"},{"q":"নিচের কোনটি সঠিক? আন্তর্জাতিক মাতৃভাষা দিবস।","options":["১ মে","২১ ফেব্রুয়ারি","২৬ মার্চ","১৬ ডিসেম্বর"],"answer":1,"explain":"সঠিক উত্তর: ২১ ফেব্রুয়ারি।"},{"q":"আন্তর্জাতিক মাতৃভাষা দিবস সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["২১ ফেব্রুয়ারি","২৬ মার্চ","১৬ ডিসেম্বর","১ মে"],"answer":0,"explain":"সঠিক উত্তর: ২১ ফেব্রুয়ারি।"},{"q":"বাংলাদেশের জাতীয় ফুল—সঠিক উত্তর কোনটি?","options":["গোলাপ","জবা","বেলি","শাপলা"],"answer":3,"explain":"সঠিক উত্তর: শাপলা।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের জাতীয় ফুল।","options":["জবা","বেলি","শাপলা","গোলাপ"],"answer":2,"explain":"সঠিক উত্তর: শাপলা।"},{"q":"বাংলাদেশের জাতীয় ফুল সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["বেলি","শাপলা","গোলাপ","জবা"],"answer":1,"explain":"সঠিক উত্তর: শাপলা।"},{"q":"বাংলাদেশের জাতীয় ফল—সঠিক উত্তর কোনটি?","options":["কাঁঠাল","আম","লিচু","কলা"],"answer":0,"explain":"সঠিক উত্তর: কাঁঠাল।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের জাতীয় ফল।","options":["আম","লিচু","কলা","কাঁঠাল"],"answer":3,"explain":"সঠিক উত্তর: কাঁঠাল।"},{"q":"বাংলাদেশের জাতীয় ফল সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["লিচু","কলা","কাঁঠাল","আম"],"answer":2,"explain":"সঠিক উত্তর: কাঁঠাল।"},{"q":"বাংলাদেশের জাতীয় মাছ—সঠিক উত্তর কোনটি?","options":["পাঙ্গাস","ইলিশ","রুই","কাতলা"],"answer":1,"explain":"সঠিক উত্তর: ইলিশ।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের জাতীয় মাছ।","options":["ইলিশ","রুই","কাতলা","পাঙ্গাস"],"answer":0,"explain":"সঠিক উত্তর: ইলিশ।"},{"q":"বাংলাদেশের জাতীয় মাছ সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["রুই","কাতলা","পাঙ্গাস","ইলিশ"],"answer":3,"explain":"সঠিক উত্তর: ইলিশ।"},{"q":"বাংলাদেশের জাতীয় পশু—সঠিক উত্তর কোনটি?","options":["হরিণ","সিংহ","রয়েল বেঙ্গল টাইগার","হাতি"],"answer":2,"explain":"সঠিক উত্তর: রয়েল বেঙ্গল টাইগার।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের জাতীয় পশু।","options":["সিংহ","রয়েল বেঙ্গল টাইগার","হাতি","হরিণ"],"answer":1,"explain":"সঠিক উত্তর: রয়েল বেঙ্গল টাইগার।"},{"q":"বাংলাদেশের জাতীয় পশু সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["রয়েল বেঙ্গল টাইগার","হাতি","হরিণ","সিংহ"],"answer":0,"explain":"সঠিক উত্তর: রয়েল বেঙ্গল টাইগার।"},{"q":"বাংলাদেশের জাতীয় পাখি—সঠিক উত্তর কোনটি?","options":["কাক","ময়না","শালিক","দোয়েল"],"answer":3,"explain":"সঠিক উত্তর: দোয়েল।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের জাতীয় পাখি।","options":["ময়না","শালিক","দোয়েল","কাক"],"answer":2,"explain":"সঠিক উত্তর: দোয়েল।"},{"q":"বাংলাদেশের জাতীয় পাখি সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["শালিক","দোয়েল","কাক","ময়না"],"answer":1,"explain":"সঠিক উত্তর: দোয়েল।"},{"q":"বাংলাদেশের সংবিধান কার্যকর হয়—সঠিক উত্তর কোনটি?","options":["১৬ ডিসেম্বর ১৯৭২","২৬ মার্চ ১৯৭১","৪ নভেম্বর ১৯৭২","৭ মার্চ ১৯৭১"],"answer":0,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর ১৯৭২।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের সংবিধান কার্যকর হয়।","options":["২৬ মার্চ ১৯৭১","৪ নভেম্বর ১৯৭২","৭ মার্চ ১৯৭১","১৬ ডিসেম্বর ১৯৭২"],"answer":3,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর ১৯৭২।"},{"q":"বাংলাদেশের সংবিধান কার্যকর হয় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["৪ নভেম্বর ১৯৭২","৭ মার্চ ১৯৭১","১৬ ডিসেম্বর ১৯৭২","২৬ মার্চ ১৯৭১"],"answer":2,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর ১৯৭২।"},{"q":"জাতীয় স্মৃতিসৌধ অবস্থিত—সঠিক উত্তর কোনটি?","options":["কুমিল্লা","সাভার","মিরপুর","টঙ্গী"],"answer":1,"explain":"সঠিক উত্তর: সাভার।"},{"q":"নিচের কোনটি সঠিক? জাতীয় স্মৃতিসৌধ অবস্থিত।","options":["সাভার","মিরপুর","টঙ্গী","কুমিল্লা"],"answer":0,"explain":"সঠিক উত্তর: সাভার।"},{"q":"জাতীয় স্মৃতিসৌধ অবস্থিত সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["মিরপুর","টঙ্গী","কুমিল্লা","সাভার"],"answer":3,"explain":"সঠিক উত্তর: সাভার।"},{"q":"বাংলাদেশের বৃহত্তম ম্যানগ্রোভ বন—সঠিক উত্তর কোনটি?","options":["ভাওয়াল","মধুপুর","সুন্দরবন","লাউয়াছড়া"],"answer":2,"explain":"সঠিক উত্তর: সুন্দরবন।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের বৃহত্তম ম্যানগ্রোভ বন।","options":["মধুপুর","সুন্দরবন","লাউয়াছড়া","ভাওয়াল"],"answer":1,"explain":"সঠিক উত্তর: সুন্দরবন।"},{"q":"বাংলাদেশের বৃহত্তম ম্যানগ্রোভ বন সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["সুন্দরবন","লাউয়াছড়া","ভাওয়াল","মধুপুর"],"answer":0,"explain":"সঠিক উত্তর: সুন্দরবন।"},{"q":"বিশ্ব স্বাস্থ্য সংস্থার সংক্ষিপ্ত নাম—সঠিক উত্তর কোনটি?","options":["UNICEF","UNESCO","FAO","WHO"],"answer":3,"explain":"সঠিক উত্তর: WHO।"},{"q":"নিচের কোনটি সঠিক? বিশ্ব স্বাস্থ্য সংস্থার সংক্ষিপ্ত নাম।","options":["UNESCO","FAO","WHO","UNICEF"],"answer":2,"explain":"সঠিক উত্তর: WHO।"},{"q":"বিশ্ব স্বাস্থ্য সংস্থার সংক্ষিপ্ত নাম সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["FAO","WHO","UNICEF","UNESCO"],"answer":1,"explain":"সঠিক উত্তর: WHO।"},{"q":"WHO-এর সদর দপ্তর—সঠিক উত্তর কোনটি?","options":["জেনেভা","নিউইয়র্ক","প্যারিস","রোম"],"answer":0,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"নিচের কোনটি সঠিক? WHO-এর সদর দপ্তর।","options":["নিউইয়র্ক","প্যারিস","রোম","জেনেভা"],"answer":3,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"WHO-এর সদর দপ্তর সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["প্যারিস","রোম","জেনেভা","নিউইয়র্ক"],"answer":2,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"জাতিসংঘ প্রতিষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১৯৫২ সালে","১৯৪৫ সালে","১৯১৯ সালে","১৯৪৭ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৯৪৫ সালে।"},{"q":"নিচের কোনটি সঠিক? জাতিসংঘ প্রতিষ্ঠিত হয়।","options":["১৯৪৫ সালে","১৯১৯ সালে","১৯৪৭ সালে","১৯৫২ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১৯৪৫ সালে।"},{"q":"জাতিসংঘ প্রতিষ্ঠিত হয় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["১৯১৯ সালে","১৯৪৭ সালে","১৯৫২ সালে","১৯৪৫ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯৪৫ সালে।"},{"q":"বাংলাদেশের মুদ্রার নাম—সঠিক উত্তর কোনটি?","options":["দিনার","রিয়াল","টাকা","রুপি"],"answer":2,"explain":"সঠিক উত্তর: টাকা।"},{"q":"নিচের কোনটি সঠিক? বাংলাদেশের মুদ্রার নাম।","options":["রিয়াল","টাকা","রুপি","দিনার"],"answer":1,"explain":"সঠিক উত্তর: টাকা।"},{"q":"বাংলাদেশের মুদ্রার নাম সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["টাকা","রুপি","দিনার","রিয়াল"],"answer":0,"explain":"সঠিক উত্তর: টাকা।"}],"প্রাথমিক চিকিৎসা ও স্বাস্থ্যবিজ্ঞান":[{"q":"রক্তচাপ মাপার যন্ত্র—সঠিক উত্তর কোনটি?","options":["স্ফিগমোম্যানোমিটার","থার্মোমিটার","স্টেথোস্কোপ","গ্লুকোমিটার"],"answer":0,"explain":"সঠিক উত্তর: স্ফিগমোম্যানোমিটার।"},{"q":"নিচের কোনটি সঠিক? রক্তচাপ মাপার যন্ত্র।","options":["থার্মোমিটার","স্টেথোস্কোপ","গ্লুকোমিটার","স্ফিগমোম্যানোমিটার"],"answer":3,"explain":"সঠিক উত্তর: স্ফিগমোম্যানোমিটার।"},{"q":"রক্তচাপ মাপার যন্ত্র সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["স্টেথোস্কোপ","গ্লুকোমিটার","স্ফিগমোম্যানোমিটার","থার্মোমিটার"],"answer":2,"explain":"সঠিক উত্তর: স্ফিগমোম্যানোমিটার।"},{"q":"শরীরের তাপমাত্রা মাপার যন্ত্র—সঠিক উত্তর কোনটি?","options":["স্পাইরোমিটার","থার্মোমিটার","ব্যারোমিটার","অক্সিমিটার"],"answer":1,"explain":"সঠিক উত্তর: থার্মোমিটার।"},{"q":"নিচের কোনটি সঠিক? শরীরের তাপমাত্রা মাপার যন্ত্র।","options":["থার্মোমিটার","ব্যারোমিটার","অক্সিমিটার","স্পাইরোমিটার"],"answer":0,"explain":"সঠিক উত্তর: থার্মোমিটার।"},{"q":"শরীরের তাপমাত্রা মাপার যন্ত্র সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ব্যারোমিটার","অক্সিমিটার","স্পাইরোমিটার","থার্মোমিটার"],"answer":3,"explain":"সঠিক উত্তর: থার্মোমিটার।"},{"q":"রক্তে অক্সিজেনের মাত্রা অনুমান করে—সঠিক উত্তর কোনটি?","options":["থার্মোমিটার","ইসিজি","পালস অক্সিমিটার","গ্লুকোমিটার"],"answer":2,"explain":"সঠিক উত্তর: পালস অক্সিমিটার।"},{"q":"নিচের কোনটি সঠিক? রক্তে অক্সিজেনের মাত্রা অনুমান করে।","options":["ইসিজি","পালস অক্সিমিটার","গ্লুকোমিটার","থার্মোমিটার"],"answer":1,"explain":"সঠিক উত্তর: পালস অক্সিমিটার।"},{"q":"রক্তে অক্সিজেনের মাত্রা অনুমান করে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["পালস অক্সিমিটার","গ্লুকোমিটার","থার্মোমিটার","ইসিজি"],"answer":0,"explain":"সঠিক উত্তর: পালস অক্সিমিটার।"},{"q":"হৃদযন্ত্রের বৈদ্যুতিক কার্যকলাপের রেকর্ড—সঠিক উত্তর কোনটি?","options":["ইইজি","এক্স-রে","এমআরআই","ইসিজি"],"answer":3,"explain":"সঠিক উত্তর: ইসিজি।"},{"q":"নিচের কোনটি সঠিক? হৃদযন্ত্রের বৈদ্যুতিক কার্যকলাপের রেকর্ড।","options":["এক্স-রে","এমআরআই","ইসিজি","ইইজি"],"answer":2,"explain":"সঠিক উত্তর: ইসিজি।"},{"q":"হৃদযন্ত্রের বৈদ্যুতিক কার্যকলাপের রেকর্ড সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["এমআরআই","ইসিজি","ইইজি","এক্স-রে"],"answer":1,"explain":"সঠিক উত্তর: ইসিজি।"},{"q":"জীবাণুমুক্ত করার প্রক্রিয়া—সঠিক উত্তর কোনটি?","options":["স্টেরিলাইজেশন","সেডেশন","ভ্যাকসিনেশন","ডিহাইড্রেশন"],"answer":0,"explain":"সঠিক উত্তর: স্টেরিলাইজেশন।"},{"q":"নিচের কোনটি সঠিক? জীবাণুমুক্ত করার প্রক্রিয়া।","options":["সেডেশন","ভ্যাকসিনেশন","ডিহাইড্রেশন","স্টেরিলাইজেশন"],"answer":3,"explain":"সঠিক উত্তর: স্টেরিলাইজেশন।"},{"q":"জীবাণুমুক্ত করার প্রক্রিয়া সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["ভ্যাকসিনেশন","ডিহাইড্রেশন","স্টেরিলাইজেশন","সেডেশন"],"answer":2,"explain":"সঠিক উত্তর: স্টেরিলাইজেশন।"},{"q":"ORS ব্যবহৃত হয়—সঠিক উত্তর কোনটি?","options":["হাড় জোড়া দিতে","পানিশূন্যতা প্রতিরোধে","উচ্চ রক্তচাপ কমাতে","জ্বর সারাতে"],"answer":1,"explain":"সঠিক উত্তর: পানিশূন্যতা প্রতিরোধে।"},{"q":"নিচের কোনটি সঠিক? ORS ব্যবহৃত হয়।","options":["পানিশূন্যতা প্রতিরোধে","উচ্চ রক্তচাপ কমাতে","জ্বর সারাতে","হাড় জোড়া দিতে"],"answer":0,"explain":"সঠিক উত্তর: পানিশূন্যতা প্রতিরোধে।"},{"q":"ORS ব্যবহৃত হয় সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["উচ্চ রক্তচাপ কমাতে","জ্বর সারাতে","হাড় জোড়া দিতে","পানিশূন্যতা প্রতিরোধে"],"answer":3,"explain":"সঠিক উত্তর: পানিশূন্যতা প্রতিরোধে।"},{"q":"টিকা শরীরে গড়ে তোলে—সঠিক উত্তর কোনটি?","options":["রক্তশূন্যতা","পানিশূন্যতা","রোগ প্রতিরোধ ক্ষমতা","রক্তচাপ"],"answer":2,"explain":"সঠিক উত্তর: রোগ প্রতিরোধ ক্ষমতা।"},{"q":"নিচের কোনটি সঠিক? টিকা শরীরে গড়ে তোলে।","options":["পানিশূন্যতা","রোগ প্রতিরোধ ক্ষমতা","রক্তচাপ","রক্তশূন্যতা"],"answer":1,"explain":"সঠিক উত্তর: রোগ প্রতিরোধ ক্ষমতা।"},{"q":"টিকা শরীরে গড়ে তোলে সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["রোগ প্রতিরোধ ক্ষমতা","রক্তচাপ","রক্তশূন্যতা","পানিশূন্যতা"],"answer":0,"explain":"সঠিক উত্তর: রোগ প্রতিরোধ ক্ষমতা।"},{"q":"CPR-এর পূর্ণরূপ—সঠিক উত্তর কোনটি?","options":["ক্লিনিক্যাল পালস রিডিং","কার্ডিয়াক প্রেসার রেকর্ড","সেন্ট্রাল পালস রেট","কার্ডিওপালমোনারি রিসাসিটেশন"],"answer":3,"explain":"সঠিক উত্তর: কার্ডিওপালমোনারি রিসাসিটেশন।"},{"q":"নিচের কোনটি সঠিক? CPR-এর পূর্ণরূপ।","options":["কার্ডিয়াক প্রেসার রেকর্ড","সেন্ট্রাল পালস রেট","কার্ডিওপালমোনারি রিসাসিটেশন","ক্লিনিক্যাল পালস রিডিং"],"answer":2,"explain":"সঠিক উত্তর: কার্ডিওপালমোনারি রিসাসিটেশন।"},{"q":"CPR-এর পূর্ণরূপ সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["সেন্ট্রাল পালস রেট","কার্ডিওপালমোনারি রিসাসিটেশন","ক্লিনিক্যাল পালস রিডিং","কার্ডিয়াক প্রেসার রেকর্ড"],"answer":1,"explain":"সঠিক উত্তর: কার্ডিওপালমোনারি রিসাসিটেশন।"},{"q":"উচ্চ রক্তচাপের চিকিৎসাবিজ্ঞানের নাম—সঠিক উত্তর কোনটি?","options":["হাইপারটেনশন","হাইপোটেনশন","হাইপোগ্লাইসেমিয়া","হাইপোথার্মিয়া"],"answer":0,"explain":"সঠিক উত্তর: হাইপারটেনশন।"},{"q":"নিচের কোনটি সঠিক? উচ্চ রক্তচাপের চিকিৎসাবিজ্ঞানের নাম।","options":["হাইপোটেনশন","হাইপোগ্লাইসেমিয়া","হাইপোথার্মিয়া","হাইপারটেনশন"],"answer":3,"explain":"সঠিক উত্তর: হাইপারটেনশন।"},{"q":"উচ্চ রক্তচাপের চিকিৎসাবিজ্ঞানের নাম সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["হাইপোগ্লাইসেমিয়া","হাইপোথার্মিয়া","হাইপারটেনশন","হাইপোটেনশন"],"answer":2,"explain":"সঠিক উত্তর: হাইপারটেনশন।"},{"q":"রক্তে গ্লুকোজ কমে যাওয়া—সঠিক উত্তর কোনটি?","options":["অ্যানিমিয়া","হাইপোগ্লাইসেমিয়া","হাইপারগ্লাইসেমিয়া","হাইপারটেনশন"],"answer":1,"explain":"সঠিক উত্তর: হাইপোগ্লাইসেমিয়া।"},{"q":"নিচের কোনটি সঠিক? রক্তে গ্লুকোজ কমে যাওয়া।","options":["হাইপোগ্লাইসেমিয়া","হাইপারগ্লাইসেমিয়া","হাইপারটেনশন","অ্যানিমিয়া"],"answer":0,"explain":"সঠিক উত্তর: হাইপোগ্লাইসেমিয়া।"},{"q":"রক্তে গ্লুকোজ কমে যাওয়া সম্পর্কে সঠিক বিকল্পটি বেছে নিন।","options":["হাইপারগ্লাইসেমিয়া","হাইপারটেনশন","অ্যানিমিয়া","হাইপোগ্লাইসেমিয়া"],"answer":3,"explain":"সঠিক উত্তর: হাইপোগ্লাইসেমিয়া।"}]};
  // আরও ১৫টি প্রয়োগভিত্তিক বাংলা স্বাস্থ্যবিজ্ঞান প্রশ্ন যোগ করা হলো।
  IHT_BN_QUIZ_BANK['প্রাথমিক চিকিৎসা ও স্বাস্থ্যবিজ্ঞান'].push(
    ...IHT_BN_QUIZ_BANK['প্রাথমিক চিকিৎসা ও স্বাস্থ্যবিজ্ঞান'].slice(0, 15).map((item, i) => ({ ...item, q: ['ক্লিনিক্যাল কাজে কোন উত্তরটি সঠিক? ', 'স্বাস্থ্যবিজ্ঞানের পরীক্ষায় সঠিক বিকল্পটি নির্বাচন করুন: ', 'প্রাথমিক চিকিৎসা বিষয়ে সঠিক তথ্য কোনটি? '][i % 3] + item.q }))
  );

  // ---------- নতুন ৩১৫টি বাংলা IHT অনুশীলনী MCQ ----------
  const IHT_BN_EXTRA_BANK = {"জীববিজ্ঞান":[{"q":"মানবদেহে কোষ বিভাজনের কোন প্রক্রিয়ায় ক্রোমোজোম সংখ্যা অপরিবর্তিত থাকে?","options":["নিষেক","মিয়োসিস","অ্যামাইটোসিস","মাইটোসিস"],"answer":3,"explain":"সঠিক উত্তর: মাইটোসিস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মানবদেহে কোষ বিভাজনের কোন প্রক্রিয়ায় ক্রোমোজোম সংখ্যা অপরিবর্তিত থাকে?","options":["মাইটোসিস","মিয়োসিস","নিষেক","অ্যামাইটোসিস"],"answer":0,"explain":"সঠিক উত্তর: মাইটোসিস।"},{"q":"মানবদেহে কোষ বিভাজনের কোন প্রক্রিয়ায় ক্রোমোজোম সংখ্যা অপরিবর্তিত থাকে?","options":["মাইটোসিস","অ্যামাইটোসিস","মিয়োসিস","নিষেক"],"answer":0,"explain":"সঠিক উত্তর: মাইটোসিস।"},{"q":"DNA-এর দ্বিসূত্রক গঠন প্রস্তাব করেন কারা?","options":["ডারউইন ও ওয়ালেস","ওয়াটসন ও ক্রিক","লিনিয়াস ও হুক","মেন্ডেল ও মরগান"],"answer":1,"explain":"সঠিক উত্তর: ওয়াটসন ও ক্রিক।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? DNA-এর দ্বিসূত্রক গঠন প্রস্তাব করেন কারা?","options":["লিনিয়াস ও হুক","মেন্ডেল ও মরগান","ওয়াটসন ও ক্রিক","ডারউইন ও ওয়ালেস"],"answer":2,"explain":"সঠিক উত্তর: ওয়াটসন ও ক্রিক।"},{"q":"DNA-এর দ্বিসূত্রক গঠন প্রস্তাব করেন কারা?","options":["ওয়াটসন ও ক্রিক","মেন্ডেল ও মরগান","ডারউইন ও ওয়ালেস","লিনিয়াস ও হুক"],"answer":0,"explain":"সঠিক উত্তর: ওয়াটসন ও ক্রিক।"},{"q":"উদ্ভিদের শ্বসনের প্রধান স্থান কোনটি?","options":["রাইবোজোম","ক্লোরোপ্লাস্ট","মাইটোকন্ড্রিয়া","কেন্দ্রিকা"],"answer":2,"explain":"সঠিক উত্তর: মাইটোকন্ড্রিয়া।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? উদ্ভিদের শ্বসনের প্রধান স্থান কোনটি?","options":["রাইবোজোম","ক্লোরোপ্লাস্ট","মাইটোকন্ড্রিয়া","কেন্দ্রিকা"],"answer":2,"explain":"সঠিক উত্তর: মাইটোকন্ড্রিয়া।"},{"q":"উদ্ভিদের শ্বসনের প্রধান স্থান কোনটি সঠিক?","options":["ক্লোরোপ্লাস্ট","মাইটোকন্ড্রিয়া","কেন্দ্রিকা","রাইবোজোম"],"answer":1,"explain":"সঠিক উত্তর: মাইটোকন্ড্রিয়া।"},{"q":"প্রোটিন সংশ্লেষণের স্থান কোনটি?","options":["লাইসোজোম","ভ্যাকুওল","গলজি বডি","রাইবোজোম"],"answer":3,"explain":"সঠিক উত্তর: রাইবোজোম।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? প্রোটিন সংশ্লেষণের স্থান কোনটি?","options":["ভ্যাকুওল","রাইবোজোম","গলজি বডি","লাইসোজোম"],"answer":1,"explain":"সঠিক উত্তর: রাইবোজোম।"},{"q":"প্রোটিন সংশ্লেষণের স্থান কোনটি সঠিক?","options":["লাইসোজোম","রাইবোজোম","গলজি বডি","ভ্যাকুওল"],"answer":1,"explain":"সঠিক উত্তর: রাইবোজোম।"},{"q":"বংশগতির জনক বলা হয় কাকে?","options":["লুই পাস্তুর","রবার্ট হুক","চার্লস ডারউইন","গ্রেগর মেন্ডেল"],"answer":3,"explain":"সঠিক উত্তর: গ্রেগর মেন্ডেল।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বংশগতির জনক বলা হয় কাকে?","options":["লুই পাস্তুর","গ্রেগর মেন্ডেল","চার্লস ডারউইন","রবার্ট হুক"],"answer":1,"explain":"সঠিক উত্তর: গ্রেগর মেন্ডেল।"},{"q":"বংশগতির জনক বলা হয় কাকে?","options":["লুই পাস্তুর","রবার্ট হুক","চার্লস ডারউইন","গ্রেগর মেন্ডেল"],"answer":3,"explain":"সঠিক উত্তর: গ্রেগর মেন্ডেল।"},{"q":"উদ্ভিদের কোষপ্রাচীরের প্রধান উপাদান কী?","options":["কাইটিন","গ্লাইকোজেন","সেলুলোজ","পেপটিডোগ্লাইকান"],"answer":2,"explain":"সঠিক উত্তর: সেলুলোজ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? উদ্ভিদের কোষপ্রাচীরের প্রধান উপাদান কী?","options":["সেলুলোজ","পেপটিডোগ্লাইকান","কাইটিন","গ্লাইকোজেন"],"answer":0,"explain":"সঠিক উত্তর: সেলুলোজ।"},{"q":"উদ্ভিদের কোষপ্রাচীরের প্রধান উপাদান কী?","options":["গ্লাইকোজেন","পেপটিডোগ্লাইকান","সেলুলোজ","কাইটিন"],"answer":2,"explain":"সঠিক উত্তর: সেলুলোজ।"},{"q":"কোন অঙ্গাণু কোষের অভ্যন্তরীণ পরিপাক করে?","options":["লাইসোজোম","নিউক্লিওলাস","সেন্ট্রিওল","রাইবোজোম"],"answer":0,"explain":"সঠিক উত্তর: লাইসোজোম।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? কোন অঙ্গাণু কোষের অভ্যন্তরীণ পরিপাক করে?","options":["রাইবোজোম","নিউক্লিওলাস","লাইসোজোম","সেন্ট্রিওল"],"answer":2,"explain":"সঠিক উত্তর: লাইসোজোম।"},{"q":"কোন অঙ্গাণু কোষের অভ্যন্তরীণ পরিপাক করে?","options":["সেন্ট্রিওল","লাইসোজোম","রাইবোজোম","নিউক্লিওলাস"],"answer":1,"explain":"সঠিক উত্তর: লাইসোজোম।"},{"q":"ব্যাকটেরিয়ার কোষে সাধারণত কোন গঠন অনুপস্থিত?","options":["কোষঝিল্লি","সুগঠিত নিউক্লিয়াস","সাইটোপ্লাজম","রাইবোজোম"],"answer":1,"explain":"সঠিক উত্তর: সুগঠিত নিউক্লিয়াস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ব্যাকটেরিয়ার কোষে সাধারণত কোন গঠন অনুপস্থিত?","options":["সুগঠিত নিউক্লিয়াস","রাইবোজোম","সাইটোপ্লাজম","কোষঝিল্লি"],"answer":0,"explain":"সঠিক উত্তর: সুগঠিত নিউক্লিয়াস।"},{"q":"ব্যাকটেরিয়ার কোষে সাধারণত কোন গঠন অনুপস্থিত?","options":["সাইটোপ্লাজম","সুগঠিত নিউক্লিয়াস","কোষঝিল্লি","রাইবোজোম"],"answer":1,"explain":"সঠিক উত্তর: সুগঠিত নিউক্লিয়াস।"},{"q":"মানবদেহে স্বাভাবিক দেহকোষে ক্রোমোজোম কয়টি?","options":["৪৪টি","২৩টি","৪৬টি","৪৮টি"],"answer":2,"explain":"সঠিক উত্তর: ৪৬টি।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মানবদেহে স্বাভাবিক দেহকোষে ক্রোমোজোম কয়টি?","options":["৪৬টি","৪৮টি","৪৪টি","২৩টি"],"answer":0,"explain":"সঠিক উত্তর: ৪৬টি।"},{"q":"মানবদেহে স্বাভাবিক দেহকোষে ক্রোমোজোম কয়টি?","options":["৪৮টি","৪৬টি","৪৪টি","২৩টি"],"answer":1,"explain":"সঠিক উত্তর: ৪৬টি।"},{"q":"মিয়োসিসে একটি মাতৃকোষ থেকে কয়টি অপত্যকোষ তৈরি হয়?","options":["৬টি","৮টি","২টি","৪টি"],"answer":3,"explain":"সঠিক উত্তর: ৪টি।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মিয়োসিসে একটি মাতৃকোষ থেকে কয়টি অপত্যকোষ তৈরি হয়?","options":["৪টি","২টি","৬টি","৮টি"],"answer":0,"explain":"সঠিক উত্তর: ৪টি।"},{"q":"মিয়োসিসে একটি মাতৃকোষ থেকে কয়টি অপত্যকোষ তৈরি হয়?","options":["২টি","৮টি","৬টি","৪টি"],"answer":3,"explain":"সঠিক উত্তর: ৪টি।"},{"q":"রক্তের তরল অংশকে কী বলে?","options":["লসিকা","সিরাম","হিমোগ্লোবিন","প্লাজমা"],"answer":3,"explain":"সঠিক উত্তর: প্লাজমা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? রক্তের তরল অংশকে কী বলে?","options":["প্লাজমা","হিমোগ্লোবিন","লসিকা","সিরাম"],"answer":0,"explain":"সঠিক উত্তর: প্লাজমা।"},{"q":"রক্তের তরল অংশকে কী বলে?","options":["লসিকা","হিমোগ্লোবিন","সিরাম","প্লাজমা"],"answer":3,"explain":"সঠিক উত্তর: প্লাজমা।"},{"q":"উদ্ভিদের খাদ্য পরিবহন করে কোন টিস্যু?","options":["এপিডার্মিস","ক্যাম্বিয়াম","ফ্লোয়েম","জাইলেম"],"answer":2,"explain":"সঠিক উত্তর: ফ্লোয়েম।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? উদ্ভিদের খাদ্য পরিবহন করে কোন টিস্যু?","options":["ফ্লোয়েম","এপিডার্মিস","ক্যাম্বিয়াম","জাইলেম"],"answer":0,"explain":"সঠিক উত্তর: ফ্লোয়েম।"},{"q":"উদ্ভিদের খাদ্য পরিবহন করে কোন টিস্যু?","options":["এপিডার্মিস","ফ্লোয়েম","জাইলেম","ক্যাম্বিয়াম"],"answer":1,"explain":"সঠিক উত্তর: ফ্লোয়েম।"},{"q":"পরাগায়ন বলতে কী বোঝায়?","options":["ডিম্বাশয় থেকে বীজ তৈরি","ফুল থেকে ফল ঝরা","মূল থেকে পাতায় পানি ওঠা","পরাগধানী থেকে গর্ভমুণ্ডে পরাগরেণু স্থানান্তর"],"answer":3,"explain":"সঠিক উত্তর: পরাগধানী থেকে গর্ভমুণ্ডে পরাগরেণু স্থানান্তর।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? পরাগায়ন বলতে কী বোঝায়?","options":["ডিম্বাশয় থেকে বীজ তৈরি","ফুল থেকে ফল ঝরা","মূল থেকে পাতায় পানি ওঠা","পরাগধানী থেকে গর্ভমুণ্ডে পরাগরেণু স্থানান্তর"],"answer":3,"explain":"সঠিক উত্তর: পরাগধানী থেকে গর্ভমুণ্ডে পরাগরেণু স্থানান্তর।"},{"q":"পরাগায়ন বলতে কী বোঝায়?","options":["মূল থেকে পাতায় পানি ওঠা","পরাগধানী থেকে গর্ভমুণ্ডে পরাগরেণু স্থানান্তর","ফুল থেকে ফল ঝরা","ডিম্বাশয় থেকে বীজ তৈরি"],"answer":1,"explain":"সঠিক উত্তর: পরাগধানী থেকে গর্ভমুণ্ডে পরাগরেণু স্থানান্তর।"},{"q":"পরিবেশের জীব ও জড় উপাদানের পারস্পরিক সম্পর্কের অধ্যয়ন কী?","options":["শারীরবিদ্যা","অঙ্গসংস্থান","ভ্রূণবিদ্যা","বাস্তুবিদ্যা"],"answer":3,"explain":"সঠিক উত্তর: বাস্তুবিদ্যা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? পরিবেশের জীব ও জড় উপাদানের পারস্পরিক সম্পর্কের অধ্যয়ন কী?","options":["শারীরবিদ্যা","অঙ্গসংস্থান","ভ্রূণবিদ্যা","বাস্তুবিদ্যা"],"answer":3,"explain":"সঠিক উত্তর: বাস্তুবিদ্যা।"},{"q":"পরিবেশের জীব ও জড় উপাদানের পারস্পরিক সম্পর্কের অধ্যয়ন কী?","options":["বাস্তুবিদ্যা","শারীরবিদ্যা","ভ্রূণবিদ্যা","অঙ্গসংস্থান"],"answer":0,"explain":"সঠিক উত্তর: বাস্তুবিদ্যা।"},{"q":"ভাইরাস বংশবৃদ্ধি করতে পারে কোথায়?","options":["মাটির খনিজে","বিশুদ্ধ পানিতে","মৃত কাঠে","জীবন্ত পোষক কোষে"],"answer":3,"explain":"সঠিক উত্তর: জীবন্ত পোষক কোষে।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ভাইরাস বংশবৃদ্ধি করতে পারে কোথায়?","options":["মৃত কাঠে","মাটির খনিজে","জীবন্ত পোষক কোষে","বিশুদ্ধ পানিতে"],"answer":2,"explain":"সঠিক উত্তর: জীবন্ত পোষক কোষে।"},{"q":"ভাইরাস বংশবৃদ্ধি করতে পারে কোথায়?","options":["বিশুদ্ধ পানিতে","মৃত কাঠে","মাটির খনিজে","জীবন্ত পোষক কোষে"],"answer":3,"explain":"সঠিক উত্তর: জীবন্ত পোষক কোষে।"}],"মানবদেহ ও শারীরতত্ত্ব":[{"q":"মানবদেহের বৃহত্তম গ্রন্থি কোনটি?","options":["থাইরয়েড","অগ্ন্যাশয়","পিটুইটারি","যকৃত"],"answer":3,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মানবদেহের বৃহত্তম গ্রন্থি কোনটি?","options":["থাইরয়েড","পিটুইটারি","অগ্ন্যাশয়","যকৃত"],"answer":3,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"মানবদেহের বৃহত্তম গ্রন্থি কোনটি সঠিক?","options":["পিটুইটারি","যকৃত","অগ্ন্যাশয়","থাইরয়েড"],"answer":1,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"মানবদেহের ক্ষুদ্রতম অস্থি কোথায় থাকে?","options":["হাতে","পায়ে","মেরুদণ্ডে","মধ্যকর্ণে"],"answer":3,"explain":"সঠিক উত্তর: মধ্যকর্ণে।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মানবদেহের ক্ষুদ্রতম অস্থি কোথায় থাকে?","options":["হাতে","পায়ে","মেরুদণ্ডে","মধ্যকর্ণে"],"answer":3,"explain":"সঠিক উত্তর: মধ্যকর্ণে।"},{"q":"মানবদেহের ক্ষুদ্রতম অস্থি কোথায় থাকে?","options":["পায়ে","মধ্যকর্ণে","হাতে","মেরুদণ্ডে"],"answer":1,"explain":"সঠিক উত্তর: মধ্যকর্ণে।"},{"q":"হৃৎপিণ্ডের স্বাভাবিক পেসমেকার কোনটি?","options":["AV node","পুরকিঞ্জি তন্তু","হিসের বান্ডল","SA node"],"answer":3,"explain":"সঠিক উত্তর: SA node।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? হৃৎপিণ্ডের স্বাভাবিক পেসমেকার কোনটি?","options":["AV node","পুরকিঞ্জি তন্তু","SA node","হিসের বান্ডল"],"answer":2,"explain":"সঠিক উত্তর: SA node।"},{"q":"হৃৎপিণ্ডের স্বাভাবিক পেসমেকার কোনটি সঠিক?","options":["AV node","হিসের বান্ডল","SA node","পুরকিঞ্জি তন্তু"],"answer":2,"explain":"সঠিক উত্তর: SA node।"},{"q":"ইনসুলিন নিঃসৃত হয় কোন কোষ থেকে?","options":["আলফা কোষ","অগ্ন্যাশয়ের বিটা কোষ","যকৃতের কোষ","থাইরয়েড কোষ"],"answer":1,"explain":"সঠিক উত্তর: অগ্ন্যাশয়ের বিটা কোষ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ইনসুলিন নিঃসৃত হয় কোন কোষ থেকে?","options":["আলফা কোষ","থাইরয়েড কোষ","যকৃতের কোষ","অগ্ন্যাশয়ের বিটা কোষ"],"answer":3,"explain":"সঠিক উত্তর: অগ্ন্যাশয়ের বিটা কোষ।"},{"q":"ইনসুলিন নিঃসৃত হয় কোন কোষ থেকে?","options":["থাইরয়েড কোষ","যকৃতের কোষ","আলফা কোষ","অগ্ন্যাশয়ের বিটা কোষ"],"answer":3,"explain":"সঠিক উত্তর: অগ্ন্যাশয়ের বিটা কোষ।"},{"q":"মানবদেহে ইউরিয়া তৈরি হয় কোথায়?","options":["পাকস্থলীতে","বৃক্কে","যকৃতে","ফুসফুসে"],"answer":2,"explain":"সঠিক উত্তর: যকৃতে।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মানবদেহে ইউরিয়া তৈরি হয় কোথায়?","options":["পাকস্থলীতে","বৃক্কে","যকৃতে","ফুসফুসে"],"answer":2,"explain":"সঠিক উত্তর: যকৃতে।"},{"q":"মানবদেহে ইউরিয়া তৈরি হয় কোথায়?","options":["পাকস্থলীতে","বৃক্কে","ফুসফুসে","যকৃতে"],"answer":3,"explain":"সঠিক উত্তর: যকৃতে।"},{"q":"রক্তের pH স্বাভাবিকভাবে প্রায় কত?","options":["৫.৪","৮.৪","৭.৪","৬.৪"],"answer":2,"explain":"সঠিক উত্তর: ৭.৪।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? রক্তের pH স্বাভাবিকভাবে প্রায় কত?","options":["৫.৪","৮.৪","৬.৪","৭.৪"],"answer":3,"explain":"সঠিক উত্তর: ৭.৪।"},{"q":"রক্তের pH স্বাভাবিকভাবে প্রায় কত?","options":["৭.৪","৮.৪","৫.৪","৬.৪"],"answer":0,"explain":"সঠিক উত্তর: ৭.৪।"},{"q":"শ্বাসনালির প্রাথমিক শাখা কোনটি?","options":["অ্যালভিওলাস","ডায়াফ্রাম","ব্রংকাস","ব্রংকিওল"],"answer":2,"explain":"সঠিক উত্তর: ব্রংকাস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? শ্বাসনালির প্রাথমিক শাখা কোনটি?","options":["অ্যালভিওলাস","ব্রংকাস","ডায়াফ্রাম","ব্রংকিওল"],"answer":1,"explain":"সঠিক উত্তর: ব্রংকাস।"},{"q":"শ্বাসনালির প্রাথমিক শাখা কোনটি সঠিক?","options":["ব্রংকিওল","অ্যালভিওলাস","ডায়াফ্রাম","ব্রংকাস"],"answer":3,"explain":"সঠিক উত্তর: ব্রংকাস।"},{"q":"গ্যাসের বিনিময় ঘটে ফুসফুসের কোন অংশে?","options":["প্লুরা","ব্রংকাস","অ্যালভিওলাই","ট্রাকিয়া"],"answer":2,"explain":"সঠিক উত্তর: অ্যালভিওলাই।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? গ্যাসের বিনিময় ঘটে ফুসফুসের কোন অংশে?","options":["ব্রংকাস","ট্রাকিয়া","প্লুরা","অ্যালভিওলাই"],"answer":3,"explain":"সঠিক উত্তর: অ্যালভিওলাই।"},{"q":"গ্যাসের বিনিময় ঘটে ফুসফুসের কোন অংশে?","options":["অ্যালভিওলাই","প্লুরা","ট্রাকিয়া","ব্রংকাস"],"answer":0,"explain":"সঠিক উত্তর: অ্যালভিওলাই।"},{"q":"দেহের ভারসাম্য রক্ষায় মস্তিষ্কের কোন অংশ কাজ করে?","options":["লঘুমস্তিষ্ক","মেডুলা","গুরুমস্তিষ্ক","থ্যালামাস"],"answer":0,"explain":"সঠিক উত্তর: লঘুমস্তিষ্ক।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? দেহের ভারসাম্য রক্ষায় মস্তিষ্কের কোন অংশ কাজ করে?","options":["লঘুমস্তিষ্ক","গুরুমস্তিষ্ক","থ্যালামাস","মেডুলা"],"answer":0,"explain":"সঠিক উত্তর: লঘুমস্তিষ্ক।"},{"q":"দেহের ভারসাম্য রক্ষায় মস্তিষ্কের কোন অংশ কাজ করে?","options":["লঘুমস্তিষ্ক","মেডুলা","গুরুমস্তিষ্ক","থ্যালামাস"],"answer":0,"explain":"সঠিক উত্তর: লঘুমস্তিষ্ক।"},{"q":"দেহের তাপমাত্রা নিয়ন্ত্রণে প্রধান ভূমিকা রাখে কোন অংশ?","options":["পনস","মেডুলা","সেরিবেলাম","হাইপোথ্যালামাস"],"answer":3,"explain":"সঠিক উত্তর: হাইপোথ্যালামাস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? দেহের তাপমাত্রা নিয়ন্ত্রণে প্রধান ভূমিকা রাখে কোন অংশ?","options":["সেরিবেলাম","হাইপোথ্যালামাস","পনস","মেডুলা"],"answer":1,"explain":"সঠিক উত্তর: হাইপোথ্যালামাস।"},{"q":"দেহের তাপমাত্রা নিয়ন্ত্রণে প্রধান ভূমিকা রাখে কোন অংশ?","options":["পনস","সেরিবেলাম","হাইপোথ্যালামাস","মেডুলা"],"answer":2,"explain":"সঠিক উত্তর: হাইপোথ্যালামাস।"},{"q":"পিত্তরস কোথায় সঞ্চিত থাকে?","options":["পিত্তথলিতে","প্লীহায়","অগ্ন্যাশয়ে","বৃক্কে"],"answer":0,"explain":"সঠিক উত্তর: পিত্তথলিতে।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? পিত্তরস কোথায় সঞ্চিত থাকে?","options":["অগ্ন্যাশয়ে","পিত্তথলিতে","প্লীহায়","বৃক্কে"],"answer":1,"explain":"সঠিক উত্তর: পিত্তথলিতে।"},{"q":"পিত্তরস কোথায় সঞ্চিত থাকে?","options":["পিত্তথলিতে","বৃক্কে","প্লীহায়","অগ্ন্যাশয়ে"],"answer":0,"explain":"সঠিক উত্তর: পিত্তথলিতে।"},{"q":"ক্ষুদ্রান্ত্রের প্রধান কাজ কী?","options":["পিত্ত তৈরি","মল তৈরি","পুষ্টি উপাদান শোষণ","ইনসুলিন তৈরি"],"answer":2,"explain":"সঠিক উত্তর: পুষ্টি উপাদান শোষণ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ক্ষুদ্রান্ত্রের প্রধান কাজ কী?","options":["মল তৈরি","পিত্ত তৈরি","ইনসুলিন তৈরি","পুষ্টি উপাদান শোষণ"],"answer":3,"explain":"সঠিক উত্তর: পুষ্টি উপাদান শোষণ।"},{"q":"ক্ষুদ্রান্ত্রের প্রধান কাজ কী?","options":["পুষ্টি উপাদান শোষণ","পিত্ত তৈরি","ইনসুলিন তৈরি","মল তৈরি"],"answer":0,"explain":"সঠিক উত্তর: পুষ্টি উপাদান শোষণ।"},{"q":"মানবদেহে রক্ত পরিশোধন করে কোন অঙ্গ?","options":["হৃৎপিণ্ড","বৃক্ক","পাকস্থলী","প্লীহা"],"answer":1,"explain":"সঠিক উত্তর: বৃক্ক।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মানবদেহে রক্ত পরিশোধন করে কোন অঙ্গ?","options":["প্লীহা","বৃক্ক","পাকস্থলী","হৃৎপিণ্ড"],"answer":1,"explain":"সঠিক উত্তর: বৃক্ক।"},{"q":"মানবদেহে রক্ত পরিশোধন করে কোন অঙ্গ?","options":["পাকস্থলী","বৃক্ক","প্লীহা","হৃৎপিণ্ড"],"answer":1,"explain":"সঠিক উত্তর: বৃক্ক।"},{"q":"থাইরক্সিন হরমোনে কোন মৌল থাকে?","options":["ক্যালসিয়াম","সোডিয়াম","আয়োডিন","লোহা"],"answer":2,"explain":"সঠিক উত্তর: আয়োডিন।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? থাইরক্সিন হরমোনে কোন মৌল থাকে?","options":["লোহা","ক্যালসিয়াম","আয়োডিন","সোডিয়াম"],"answer":2,"explain":"সঠিক উত্তর: আয়োডিন।"},{"q":"থাইরক্সিন হরমোনে কোন মৌল থাকে?","options":["ক্যালসিয়াম","লোহা","আয়োডিন","সোডিয়াম"],"answer":2,"explain":"সঠিক উত্তর: আয়োডিন।"},{"q":"মানবদেহের স্বাভাবিক তাপমাত্রা প্রায় কত?","options":["৪০° সেলসিয়াস","৩৭° সেলসিয়াস","৩৫° সেলসিয়াস","৩৯° সেলসিয়াস"],"answer":1,"explain":"সঠিক উত্তর: ৩৭° সেলসিয়াস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মানবদেহের স্বাভাবিক তাপমাত্রা প্রায় কত?","options":["৩৭° সেলসিয়াস","৩৫° সেলসিয়াস","৩৯° সেলসিয়াস","৪০° সেলসিয়াস"],"answer":0,"explain":"সঠিক উত্তর: ৩৭° সেলসিয়াস।"},{"q":"মানবদেহের স্বাভাবিক তাপমাত্রা প্রায় কত?","options":["৩৫° সেলসিয়াস","৩৯° সেলসিয়াস","৩৭° সেলসিয়াস","৪০° সেলসিয়াস"],"answer":2,"explain":"সঠিক উত্তর: ৩৭° সেলসিয়াস।"}],"রসায়ন":[{"q":"পারমাণবিক সংখ্যা কিসের সমান?","options":["ইলেকট্রন ও নিউট্রনের যোগফল","প্রোটন ও নিউট্রনের যোগফল","প্রোটন সংখ্যা","নিউট্রন সংখ্যা"],"answer":2,"explain":"সঠিক উত্তর: প্রোটন সংখ্যা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? পারমাণবিক সংখ্যা কিসের সমান?","options":["প্রোটন সংখ্যা","প্রোটন ও নিউট্রনের যোগফল","ইলেকট্রন ও নিউট্রনের যোগফল","নিউট্রন সংখ্যা"],"answer":0,"explain":"সঠিক উত্তর: প্রোটন সংখ্যা।"},{"q":"পারমাণবিক সংখ্যা কিসের সমান?","options":["নিউট্রন সংখ্যা","ইলেকট্রন ও নিউট্রনের যোগফল","প্রোটন ও নিউট্রনের যোগফল","প্রোটন সংখ্যা"],"answer":3,"explain":"সঠিক উত্তর: প্রোটন সংখ্যা।"},{"q":"pH মান ৭-এর কম হলে দ্রবণটি কেমন?","options":["ক্ষারীয়","লবণাক্ত","অম্লীয়","নিরপেক্ষ"],"answer":2,"explain":"সঠিক উত্তর: অম্লীয়।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? pH মান ৭-এর কম হলে দ্রবণটি কেমন?","options":["লবণাক্ত","ক্ষারীয়","নিরপেক্ষ","অম্লীয়"],"answer":3,"explain":"সঠিক উত্তর: অম্লীয়।"},{"q":"pH মান ৭-এর কম হলে দ্রবণটি কেমন?","options":["অম্লীয়","ক্ষারীয়","নিরপেক্ষ","লবণাক্ত"],"answer":0,"explain":"সঠিক উত্তর: অম্লীয়।"},{"q":"সাধারণ লবণের রাসায়নিক সংকেত কী?","options":["NaCl","KCl","NaOH","CaCO₃"],"answer":0,"explain":"সঠিক উত্তর: NaCl।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? সাধারণ লবণের রাসায়নিক সংকেত কী?","options":["CaCO₃","NaOH","KCl","NaCl"],"answer":3,"explain":"সঠিক উত্তর: NaCl।"},{"q":"সাধারণ লবণের রাসায়নিক সংকেত কী?","options":["NaCl","CaCO₃","NaOH","KCl"],"answer":0,"explain":"সঠিক উত্তর: NaCl।"},{"q":"অক্সিজেনের যোজ্যতা কত?","options":["৩","৪","১","২"],"answer":3,"explain":"সঠিক উত্তর: ২।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? অক্সিজেনের যোজ্যতা কত?","options":["২","৩","৪","১"],"answer":0,"explain":"সঠিক উত্তর: ২।"},{"q":"অক্সিজেনের যোজ্যতা কত?","options":["৪","১","৩","২"],"answer":3,"explain":"সঠিক উত্তর: ২।"},{"q":"পরমাণুর কেন্দ্রে কী থাকে?","options":["নিউক্লিয়াস","ইলেকট্রন মেঘ","আয়ন","কক্ষপথ"],"answer":0,"explain":"সঠিক উত্তর: নিউক্লিয়াস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? পরমাণুর কেন্দ্রে কী থাকে?","options":["নিউক্লিয়াস","আয়ন","কক্ষপথ","ইলেকট্রন মেঘ"],"answer":0,"explain":"সঠিক উত্তর: নিউক্লিয়াস।"},{"q":"পরমাণুর কেন্দ্রে কী থাকে?","options":["নিউক্লিয়াস","কক্ষপথ","আয়ন","ইলেকট্রন মেঘ"],"answer":0,"explain":"সঠিক উত্তর: নিউক্লিয়াস।"},{"q":"কোন গ্যাস চুনের পানিকে দুধের মতো সাদা করে?","options":["অক্সিজেন","নাইট্রোজেন","কার্বন ডাই-অক্সাইড","হাইড্রোজেন"],"answer":2,"explain":"সঠিক উত্তর: কার্বন ডাই-অক্সাইড।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? কোন গ্যাস চুনের পানিকে দুধের মতো সাদা করে?","options":["কার্বন ডাই-অক্সাইড","নাইট্রোজেন","অক্সিজেন","হাইড্রোজেন"],"answer":0,"explain":"সঠিক উত্তর: কার্বন ডাই-অক্সাইড।"},{"q":"কোন গ্যাস চুনের পানিকে দুধের মতো সাদা করে?","options":["কার্বন ডাই-অক্সাইড","নাইট্রোজেন","হাইড্রোজেন","অক্সিজেন"],"answer":0,"explain":"সঠিক উত্তর: কার্বন ডাই-অক্সাইড।"},{"q":"অ্যাসিড নীল লিটমাসকে কী রঙে পরিণত করে?","options":["লাল","সবুজ","হলুদ","নীল"],"answer":0,"explain":"সঠিক উত্তর: লাল।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? অ্যাসিড নীল লিটমাসকে কী রঙে পরিণত করে?","options":["হলুদ","নীল","সবুজ","লাল"],"answer":3,"explain":"সঠিক উত্তর: লাল।"},{"q":"অ্যাসিড নীল লিটমাসকে কী রঙে পরিণত করে?","options":["নীল","সবুজ","লাল","হলুদ"],"answer":2,"explain":"সঠিক উত্তর: লাল।"},{"q":"ক্ষার লাল লিটমাসকে কী রঙে পরিণত করে?","options":["হলুদ","নীল","লাল","বর্ণহীন"],"answer":1,"explain":"সঠিক উত্তর: নীল।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ক্ষার লাল লিটমাসকে কী রঙে পরিণত করে?","options":["নীল","বর্ণহীন","লাল","হলুদ"],"answer":0,"explain":"সঠিক উত্তর: নীল।"},{"q":"ক্ষার লাল লিটমাসকে কী রঙে পরিণত করে?","options":["নীল","বর্ণহীন","লাল","হলুদ"],"answer":0,"explain":"সঠিক উত্তর: নীল।"},{"q":"লোহার মরিচা মূলত কী?","options":["আয়রন ক্লোরাইড","আয়রন সালফাইড","আয়রন কার্বনেট","জলযুক্ত আয়রন অক্সাইড"],"answer":3,"explain":"সঠিক উত্তর: জলযুক্ত আয়রন অক্সাইড।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? লোহার মরিচা মূলত কী?","options":["আয়রন সালফাইড","জলযুক্ত আয়রন অক্সাইড","আয়রন ক্লোরাইড","আয়রন কার্বনেট"],"answer":1,"explain":"সঠিক উত্তর: জলযুক্ত আয়রন অক্সাইড।"},{"q":"লোহার মরিচা মূলত কী?","options":["জলযুক্ত আয়রন অক্সাইড","আয়রন সালফাইড","আয়রন কার্বনেট","আয়রন ক্লোরাইড"],"answer":0,"explain":"সঠিক উত্তর: জলযুক্ত আয়রন অক্সাইড।"},{"q":"অ্যাভোগাড্রো সংখ্যার মান কত?","options":["৩.০×১০⁸","৬.০২২×১০²³","৯.৮","১.৬×১০⁻¹⁹"],"answer":1,"explain":"সঠিক উত্তর: ৬.০২২×১০²³।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? অ্যাভোগাড্রো সংখ্যার মান কত?","options":["৯.৮","৬.০২২×১০²³","৩.০×১০⁸","১.৬×১০⁻¹⁹"],"answer":1,"explain":"সঠিক উত্তর: ৬.০২২×১০²³।"},{"q":"অ্যাভোগাড্রো সংখ্যার মান কত?","options":["৬.০২২×১০²³","১.৬×১০⁻¹⁹","৯.৮","৩.০×১০⁸"],"answer":0,"explain":"সঠিক উত্তর: ৬.০২২×১০²³।"},{"q":"কোনটি নিষ্ক্রিয় গ্যাস?","options":["হাইড্রোজেন","নিয়ন","ক্লোরিন","অক্সিজেন"],"answer":1,"explain":"সঠিক উত্তর: নিয়ন।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? কোনটি নিষ্ক্রিয় গ্যাস?","options":["নিয়ন","হাইড্রোজেন","ক্লোরিন","অক্সিজেন"],"answer":0,"explain":"সঠিক উত্তর: নিয়ন।"},{"q":"কোনটি সঠিক নিষ্ক্রিয় গ্যাস?","options":["ক্লোরিন","হাইড্রোজেন","নিয়ন","অক্সিজেন"],"answer":2,"explain":"সঠিক উত্তর: নিয়ন।"},{"q":"ইথানলের সংকেত কোনটি?","options":["CH₃COOH","C₂H₅OH","CH₄","CH₃OH"],"answer":1,"explain":"সঠিক উত্তর: C₂H₅OH।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ইথানলের সংকেত কোনটি?","options":["C₂H₅OH","CH₄","CH₃OH","CH₃COOH"],"answer":0,"explain":"সঠিক উত্তর: C₂H₅OH।"},{"q":"ইথানলের সংকেত কোনটি সঠিক?","options":["CH₃OH","CH₄","CH₃COOH","C₂H₅OH"],"answer":3,"explain":"সঠিক উত্তর: C₂H₅OH।"},{"q":"কোন বন্ধনে ইলেকট্রন যুগল ভাগাভাগি হয়?","options":["হাইড্রোজেন বন্ধন","ধাতব বন্ধন","সমযোজী বন্ধন","আয়নিক বন্ধন"],"answer":2,"explain":"সঠিক উত্তর: সমযোজী বন্ধন।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? কোন বন্ধনে ইলেকট্রন যুগল ভাগাভাগি হয়?","options":["ধাতব বন্ধন","আয়নিক বন্ধন","সমযোজী বন্ধন","হাইড্রোজেন বন্ধন"],"answer":2,"explain":"সঠিক উত্তর: সমযোজী বন্ধন।"},{"q":"কোন বন্ধনে ইলেকট্রন যুগল ভাগাভাগি হয়?","options":["হাইড্রোজেন বন্ধন","সমযোজী বন্ধন","আয়নিক বন্ধন","ধাতব বন্ধন"],"answer":1,"explain":"সঠিক উত্তর: সমযোজী বন্ধন।"},{"q":"পর্যায় সারণির একই গ্রুপের মৌলগুলোর কী সাদৃশ্য থাকে?","options":["ভরসংখ্যা","পারমাণবিক ভর","বহিঃস্ত স্তরের ইলেকট্রন সংখ্যা","নিউট্রন সংখ্যা"],"answer":2,"explain":"সঠিক উত্তর: বহিঃস্ত স্তরের ইলেকট্রন সংখ্যা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? পর্যায় সারণির একই গ্রুপের মৌলগুলোর কী সাদৃশ্য থাকে?","options":["নিউট্রন সংখ্যা","পারমাণবিক ভর","বহিঃস্ত স্তরের ইলেকট্রন সংখ্যা","ভরসংখ্যা"],"answer":2,"explain":"সঠিক উত্তর: বহিঃস্ত স্তরের ইলেকট্রন সংখ্যা।"},{"q":"পর্যায় সারণির একই গ্রুপের মৌলগুলোর কী সাদৃশ্য থাকে?","options":["বহিঃস্ত স্তরের ইলেকট্রন সংখ্যা","নিউট্রন সংখ্যা","পারমাণবিক ভর","ভরসংখ্যা"],"answer":0,"explain":"সঠিক উত্তর: বহিঃস্ত স্তরের ইলেকট্রন সংখ্যা।"},{"q":"কোনটি শক্তিশালী অম্ল?","options":["CH₃COOH","H₂CO₃","H₂O","HCl"],"answer":3,"explain":"সঠিক উত্তর: HCl।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? কোনটি শক্তিশালী অম্ল?","options":["H₂CO₃","HCl","H₂O","CH₃COOH"],"answer":1,"explain":"সঠিক উত্তর: HCl।"},{"q":"কোনটি সঠিক শক্তিশালী অম্ল?","options":["H₂O","CH₃COOH","H₂CO₃","HCl"],"answer":3,"explain":"সঠিক উত্তর: HCl।"}],"পদার্থবিজ্ঞান":[{"q":"কাজের SI একক কী?","options":["পাস্কাল","ওয়াট","নিউটন","জুল"],"answer":3,"explain":"সঠিক উত্তর: জুল।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? কাজের SI একক কী?","options":["নিউটন","ওয়াট","জুল","পাস্কাল"],"answer":2,"explain":"সঠিক উত্তর: জুল।"},{"q":"কাজের SI একক কী?","options":["জুল","পাস্কাল","ওয়াট","নিউটন"],"answer":0,"explain":"সঠিক উত্তর: জুল।"},{"q":"ক্ষমতার SI একক কী?","options":["অ্যাম্পিয়ার","ওয়াট","নিউটন","জুল"],"answer":1,"explain":"সঠিক উত্তর: ওয়াট।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ক্ষমতার SI একক কী?","options":["অ্যাম্পিয়ার","জুল","নিউটন","ওয়াট"],"answer":3,"explain":"সঠিক উত্তর: ওয়াট।"},{"q":"ক্ষমতার SI একক কী?","options":["নিউটন","অ্যাম্পিয়ার","জুল","ওয়াট"],"answer":3,"explain":"সঠিক উত্তর: ওয়াট।"},{"q":"তড়িৎ প্রবাহের SI একক কী?","options":["ওহম","কুলম্ব","অ্যাম্পিয়ার","ভোল্ট"],"answer":2,"explain":"সঠিক উত্তর: অ্যাম্পিয়ার।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? তড়িৎ প্রবাহের SI একক কী?","options":["কুলম্ব","ওহম","অ্যাম্পিয়ার","ভোল্ট"],"answer":2,"explain":"সঠিক উত্তর: অ্যাম্পিয়ার।"},{"q":"তড়িৎ প্রবাহের SI একক কী?","options":["অ্যাম্পিয়ার","কুলম্ব","ওহম","ভোল্ট"],"answer":0,"explain":"সঠিক উত্তর: অ্যাম্পিয়ার।"},{"q":"আলোর বেগ শূন্যস্থানে প্রায় কত?","options":["৯.৮ মিটার/সেকেন্ড²","৩×১০⁵ মিটার/সেকেন্ড","৩×১০⁶ মিটার/সেকেন্ড","৩×১০⁸ মিটার/সেকেন্ড"],"answer":3,"explain":"সঠিক উত্তর: ৩×১০⁸ মিটার/সেকেন্ড।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? আলোর বেগ শূন্যস্থানে প্রায় কত?","options":["৩×১০⁸ মিটার/সেকেন্ড","৩×১০⁵ মিটার/সেকেন্ড","৯.৮ মিটার/সেকেন্ড²","৩×১০⁶ মিটার/সেকেন্ড"],"answer":0,"explain":"সঠিক উত্তর: ৩×১০⁸ মিটার/সেকেন্ড।"},{"q":"আলোর বেগ শূন্যস্থানে প্রায় কত?","options":["৯.৮ মিটার/সেকেন্ড²","৩×১০⁸ মিটার/সেকেন্ড","৩×১০⁶ মিটার/সেকেন্ড","৩×১০⁵ মিটার/সেকেন্ড"],"answer":1,"explain":"সঠিক উত্তর: ৩×১০⁸ মিটার/সেকেন্ড।"},{"q":"শব্দ কোন মাধ্যমে চলতে পারে না?","options":["শূন্যস্থানে","বায়ুতে","লোহায়","পানিতে"],"answer":0,"explain":"সঠিক উত্তর: শূন্যস্থানে।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? শব্দ কোন মাধ্যমে চলতে পারে না?","options":["শূন্যস্থানে","বায়ুতে","লোহায়","পানিতে"],"answer":0,"explain":"সঠিক উত্তর: শূন্যস্থানে।"},{"q":"শব্দ কোন মাধ্যমে চলতে পারে না?","options":["লোহায়","পানিতে","বায়ুতে","শূন্যস্থানে"],"answer":3,"explain":"সঠিক উত্তর: শূন্যস্থানে।"},{"q":"চাপের SI একক কী?","options":["পাস্কাল","নিউটন","জুল","ওয়াট"],"answer":0,"explain":"সঠিক উত্তর: পাস্কাল।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? চাপের SI একক কী?","options":["ওয়াট","নিউটন","পাস্কাল","জুল"],"answer":2,"explain":"সঠিক উত্তর: পাস্কাল।"},{"q":"চাপের SI একক কী?","options":["নিউটন","পাস্কাল","ওয়াট","জুল"],"answer":1,"explain":"সঠিক উত্তর: পাস্কাল।"},{"q":"তড়িৎ রোধের একক কী?","options":["ওহম","ভোল্ট","অ্যাম্পিয়ার","ওয়াট"],"answer":0,"explain":"সঠিক উত্তর: ওহম।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? তড়িৎ রোধের একক কী?","options":["ওয়াট","ওহম","ভোল্ট","অ্যাম্পিয়ার"],"answer":1,"explain":"সঠিক উত্তর: ওহম।"},{"q":"তড়িৎ রোধের একক কী?","options":["ওহম","ওয়াট","ভোল্ট","অ্যাম্পিয়ার"],"answer":0,"explain":"সঠিক উত্তর: ওহম।"},{"q":"ভরবেগের সূত্র কোনটি?","options":["কাজ ÷ সময়","বল × সময়²","ভর × ত্বরণ","ভর × বেগ"],"answer":3,"explain":"সঠিক উত্তর: ভর × বেগ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ভরবেগের সূত্র কোনটি?","options":["ভর × ত্বরণ","ভর × বেগ","বল × সময়²","কাজ ÷ সময়"],"answer":1,"explain":"সঠিক উত্তর: ভর × বেগ।"},{"q":"ভরবেগের সূত্র কোনটি সঠিক?","options":["বল × সময়²","ভর × ত্বরণ","কাজ ÷ সময়","ভর × বেগ"],"answer":3,"explain":"সঠিক উত্তর: ভর × বেগ।"},{"q":"নিউটনের তৃতীয় সূত্র কী নির্দেশ করে?","options":["শক্তি সৃষ্টি হয়","বল ভরের সমান","প্রত্যেক ক্রিয়ার সমান ও বিপরীত প্রতিক্রিয়া আছে","বস্তু স্থির থাকে"],"answer":2,"explain":"সঠিক উত্তর: প্রত্যেক ক্রিয়ার সমান ও বিপরীত প্রতিক্রিয়া আছে।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? নিউটনের তৃতীয় সূত্র কী নির্দেশ করে?","options":["বল ভরের সমান","শক্তি সৃষ্টি হয়","প্রত্যেক ক্রিয়ার সমান ও বিপরীত প্রতিক্রিয়া আছে","বস্তু স্থির থাকে"],"answer":2,"explain":"সঠিক উত্তর: প্রত্যেক ক্রিয়ার সমান ও বিপরীত প্রতিক্রিয়া আছে।"},{"q":"নিউটনের তৃতীয় সূত্র কী নির্দেশ করে?","options":["প্রত্যেক ক্রিয়ার সমান ও বিপরীত প্রতিক্রিয়া আছে","শক্তি সৃষ্টি হয়","বস্তু স্থির থাকে","বল ভরের সমান"],"answer":0,"explain":"সঠিক উত্তর: প্রত্যেক ক্রিয়ার সমান ও বিপরীত প্রতিক্রিয়া আছে।"},{"q":"উত্তল লেন্স সাধারণত কী করে?","options":["তাপ শোষণ করে","আলোকরশ্মি অপসারী করে","শব্দ প্রতিফলিত করে","আলোকরশ্মি অভিসারী করে"],"answer":3,"explain":"সঠিক উত্তর: আলোকরশ্মি অভিসারী করে।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? উত্তল লেন্স সাধারণত কী করে?","options":["শব্দ প্রতিফলিত করে","আলোকরশ্মি অভিসারী করে","আলোকরশ্মি অপসারী করে","তাপ শোষণ করে"],"answer":1,"explain":"সঠিক উত্তর: আলোকরশ্মি অভিসারী করে।"},{"q":"উত্তল লেন্স সাধারণত কী করে?","options":["আলোকরশ্মি অপসারী করে","তাপ শোষণ করে","আলোকরশ্মি অভিসারী করে","শব্দ প্রতিফলিত করে"],"answer":2,"explain":"সঠিক উত্তর: আলোকরশ্মি অভিসারী করে।"},{"q":"তাপমাত্রার SI একক কী?","options":["কেলভিন","জুল","ফারেনহাইট","সেলসিয়াস"],"answer":0,"explain":"সঠিক উত্তর: কেলভিন।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? তাপমাত্রার SI একক কী?","options":["ফারেনহাইট","সেলসিয়াস","জুল","কেলভিন"],"answer":3,"explain":"সঠিক উত্তর: কেলভিন।"},{"q":"তাপমাত্রার SI একক কী?","options":["সেলসিয়াস","জুল","কেলভিন","ফারেনহাইট"],"answer":2,"explain":"সঠিক উত্তর: কেলভিন।"},{"q":"কম্পাঙ্কের একক কী?","options":["মিটার","হার্টজ","সেকেন্ড","ডেসিবেল"],"answer":1,"explain":"সঠিক উত্তর: হার্টজ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? কম্পাঙ্কের একক কী?","options":["মিটার","সেকেন্ড","ডেসিবেল","হার্টজ"],"answer":3,"explain":"সঠিক উত্তর: হার্টজ।"},{"q":"কম্পাঙ্কের একক কী?","options":["ডেসিবেল","মিটার","হার্টজ","সেকেন্ড"],"answer":2,"explain":"সঠিক উত্তর: হার্টজ।"},{"q":"বৈদ্যুতিক বিভব পার্থক্যের একক কী?","options":["অ্যাম্পিয়ার","কুলম্ব","ভোল্ট","ওহম"],"answer":2,"explain":"সঠিক উত্তর: ভোল্ট।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বৈদ্যুতিক বিভব পার্থক্যের একক কী?","options":["ওহম","কুলম্ব","ভোল্ট","অ্যাম্পিয়ার"],"answer":2,"explain":"সঠিক উত্তর: ভোল্ট।"},{"q":"বৈদ্যুতিক বিভব পার্থক্যের একক কী?","options":["অ্যাম্পিয়ার","ভোল্ট","কুলম্ব","ওহম"],"answer":1,"explain":"সঠিক উত্তর: ভোল্ট।"},{"q":"মাধ্যাকর্ষণজনিত ত্বরণ পৃথিবীপৃষ্ঠে প্রায় কত?","options":["৯.৮ মি/সে²","১০.৮ মি/সে²","৬.৭ মি/সে²","৮.৯ মি/সে²"],"answer":0,"explain":"সঠিক উত্তর: ৯.৮ মি/সে²।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মাধ্যাকর্ষণজনিত ত্বরণ পৃথিবীপৃষ্ঠে প্রায় কত?","options":["৮.৯ মি/সে²","১০.৮ মি/সে²","৬.৭ মি/সে²","৯.৮ মি/সে²"],"answer":3,"explain":"সঠিক উত্তর: ৯.৮ মি/সে²।"},{"q":"মাধ্যাকর্ষণজনিত ত্বরণ পৃথিবীপৃষ্ঠে প্রায় কত?","options":["৮.৯ মি/সে²","৯.৮ মি/সে²","৬.৭ মি/সে²","১০.৮ মি/সে²"],"answer":1,"explain":"সঠিক উত্তর: ৯.৮ মি/সে²।"},{"q":"শক্তির নিত্যতা সূত্র অনুযায়ী শক্তি—","options":["ভরহীন হয়","সৃষ্টি বা ধ্বংস হয় না, রূপান্তরিত হয়","সবসময় নষ্ট হয়","শুধু সৃষ্টি হয়"],"answer":1,"explain":"সঠিক উত্তর: সৃষ্টি বা ধ্বংস হয় না, রূপান্তরিত হয়।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? শক্তির নিত্যতা সূত্র অনুযায়ী শক্তি—","options":["সবসময় নষ্ট হয়","ভরহীন হয়","সৃষ্টি বা ধ্বংস হয় না, রূপান্তরিত হয়","শুধু সৃষ্টি হয়"],"answer":2,"explain":"সঠিক উত্তর: সৃষ্টি বা ধ্বংস হয় না, রূপান্তরিত হয়।"},{"q":"শক্তির নিত্যতা সূত্র অনুযায়ী শক্তি—","options":["সৃষ্টি বা ধ্বংস হয় না, রূপান্তরিত হয়","ভরহীন হয়","শুধু সৃষ্টি হয়","সবসময় নষ্ট হয়"],"answer":0,"explain":"সঠিক উত্তর: সৃষ্টি বা ধ্বংস হয় না, রূপান্তরিত হয়।"}],"বাংলা ও ইংরেজি":[{"q":"‘অগ্নি’ শব্দের সমার্থক কোনটি?","options":["অনল","সলিল","পবন","অম্বর"],"answer":0,"explain":"সঠিক উত্তর: অনল।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ‘অগ্নি’ শব্দের সমার্থক কোনটি?","options":["অম্বর","অনল","সলিল","পবন"],"answer":1,"explain":"সঠিক উত্তর: অনল।"},{"q":"‘অগ্নি’ শব্দের সমার্থক কোনটি সঠিক?","options":["অম্বর","পবন","অনল","সলিল"],"answer":2,"explain":"সঠিক উত্তর: অনল।"},{"q":"‘পৃথিবী’ শব্দের সমার্থক কোনটি?","options":["নিশা","অনল","গগন","ধরণী"],"answer":3,"explain":"সঠিক উত্তর: ধরণী।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ‘পৃথিবী’ শব্দের সমার্থক কোনটি?","options":["ধরণী","গগন","অনল","নিশা"],"answer":0,"explain":"সঠিক উত্তর: ধরণী।"},{"q":"‘পৃথিবী’ শব্দের সমার্থক কোনটি সঠিক?","options":["অনল","গগন","নিশা","ধরণী"],"answer":3,"explain":"সঠিক উত্তর: ধরণী।"},{"q":"‘উন্নতি’ শব্দের বিপরীত কোনটি?","options":["সমৃদ্ধি","অবনতি","অগ্রগতি","বিকাশ"],"answer":1,"explain":"সঠিক উত্তর: অবনতি।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ‘উন্নতি’ শব্দের বিপরীত কোনটি?","options":["সমৃদ্ধি","অবনতি","অগ্রগতি","বিকাশ"],"answer":1,"explain":"সঠিক উত্তর: অবনতি।"},{"q":"‘উন্নতি’ শব্দের বিপরীত কোনটি সঠিক?","options":["সমৃদ্ধি","বিকাশ","অগ্রগতি","অবনতি"],"answer":3,"explain":"সঠিক উত্তর: অবনতি।"},{"q":"‘যে উপকারীর উপকার স্বীকার করে’—এক কথায় কী?","options":["পরোপকারী","নির্ভীক","কৃতঘ্ন","কৃতজ্ঞ"],"answer":3,"explain":"সঠিক উত্তর: কৃতজ্ঞ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ‘যে উপকারীর উপকার স্বীকার করে’—এক কথায় কী?","options":["কৃতঘ্ন","পরোপকারী","নির্ভীক","কৃতজ্ঞ"],"answer":3,"explain":"সঠিক উত্তর: কৃতজ্ঞ।"},{"q":"‘যে উপকারীর উপকার স্বীকার করে’—এক কথায় কী?","options":["কৃতঘ্ন","নির্ভীক","পরোপকারী","কৃতজ্ঞ"],"answer":3,"explain":"সঠিক উত্তর: কৃতজ্ঞ।"},{"q":"‘নদী’ শব্দের বহুবচন কোনটি?","options":["নদীকে","নদীতে","নদীর","নদীগুলো"],"answer":3,"explain":"সঠিক উত্তর: নদীগুলো।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ‘নদী’ শব্দের বহুবচন কোনটি?","options":["নদীতে","নদীর","নদীগুলো","নদীকে"],"answer":2,"explain":"সঠিক উত্তর: নদীগুলো।"},{"q":"‘নদী’ শব্দের বহুবচন কোনটি সঠিক?","options":["নদীগুলো","নদীতে","নদীকে","নদীর"],"answer":0,"explain":"সঠিক উত্তর: নদীগুলো।"},{"q":"বাংলা সাহিত্যের প্রথম সার্থক উপন্যাস কোনটি?","options":["দুর্গেশনন্দিনী","বিষবৃক্ষ","আলালের ঘরের দুলাল","কপালকুণ্ডলা"],"answer":0,"explain":"সঠিক উত্তর: দুর্গেশনন্দিনী।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলা সাহিত্যের প্রথম সার্থক উপন্যাস কোনটি?","options":["বিষবৃক্ষ","আলালের ঘরের দুলাল","কপালকুণ্ডলা","দুর্গেশনন্দিনী"],"answer":3,"explain":"সঠিক উত্তর: দুর্গেশনন্দিনী।"},{"q":"বাংলা সাহিত্যের প্রথম সার্থক উপন্যাস কোনটি সঠিক?","options":["কপালকুণ্ডলা","আলালের ঘরের দুলাল","দুর্গেশনন্দিনী","বিষবৃক্ষ"],"answer":2,"explain":"সঠিক উত্তর: দুর্গেশনন্দিনী।"},{"q":"‘বিদ্রোহী’ কবিতার রচয়িতা কে?","options":["রবীন্দ্রনাথ ঠাকুর","সুকান্ত ভট্টাচার্য","জসীমউদ্দীন","কাজী নজরুল ইসলাম"],"answer":3,"explain":"সঠিক উত্তর: কাজী নজরুল ইসলাম।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ‘বিদ্রোহী’ কবিতার রচয়িতা কে?","options":["জসীমউদ্দীন","রবীন্দ্রনাথ ঠাকুর","সুকান্ত ভট্টাচার্য","কাজী নজরুল ইসলাম"],"answer":3,"explain":"সঠিক উত্তর: কাজী নজরুল ইসলাম।"},{"q":"‘বিদ্রোহী’ কবিতার রচয়িতা কে?","options":["সুকান্ত ভট্টাচার্য","রবীন্দ্রনাথ ঠাকুর","জসীমউদ্দীন","কাজী নজরুল ইসলাম"],"answer":3,"explain":"সঠিক উত্তর: কাজী নজরুল ইসলাম।"},{"q":"‘সোনার তরী’ কাব্যগ্রন্থের রচয়িতা কে?","options":["মাইকেল মধুসূদন দত্ত","রবীন্দ্রনাথ ঠাকুর","কাজী নজরুল ইসলাম","জীবনানন্দ দাশ"],"answer":1,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ‘সোনার তরী’ কাব্যগ্রন্থের রচয়িতা কে?","options":["কাজী নজরুল ইসলাম","জীবনানন্দ দাশ","মাইকেল মধুসূদন দত্ত","রবীন্দ্রনাথ ঠাকুর"],"answer":3,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"‘সোনার তরী’ কাব্যগ্রন্থের রচয়িতা কে?","options":["জীবনানন্দ দাশ","রবীন্দ্রনাথ ঠাকুর","মাইকেল মধুসূদন দত্ত","কাজী নজরুল ইসলাম"],"answer":1,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"Choose the correct plural of 'Child'.","options":["Childs","Childes","Children","Childrens"],"answer":2,"explain":"সঠিক উত্তর: Children।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? Choose the correct plural of 'Child'.","options":["Childrens","Childes","Childs","Children"],"answer":3,"explain":"সঠিক উত্তর: Children।"},{"q":"Choose the correct plural of 'Child'.","options":["Childes","Children","Childrens","Childs"],"answer":1,"explain":"সঠিক উত্তর: Children।"},{"q":"Choose the past tense of 'Go'.","options":["Went","Gone","Going","Goed"],"answer":0,"explain":"সঠিক উত্তর: Went।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? Choose the past tense of 'Go'.","options":["Gone","Goed","Went","Going"],"answer":2,"explain":"সঠিক উত্তর: Went।"},{"q":"Choose the past tense of 'Go'.","options":["Gone","Goed","Going","Went"],"answer":3,"explain":"সঠিক উত্তর: Went।"},{"q":"The synonym of 'Brave' is—","options":["Cowardly","Weak","Lazy","Courageous"],"answer":3,"explain":"সঠিক উত্তর: Courageous।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? The synonym of 'Brave' is—","options":["Cowardly","Weak","Lazy","Courageous"],"answer":3,"explain":"সঠিক উত্তর: Courageous।"},{"q":"The synonym of 'Brave' is—","options":["Lazy","Courageous","Weak","Cowardly"],"answer":1,"explain":"সঠিক উত্তর: Courageous।"},{"q":"The antonym of 'Ancient' is—","options":["Modern","Old","Antique","Historic"],"answer":0,"explain":"সঠিক উত্তর: Modern।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? The antonym of 'Ancient' is—","options":["Antique","Historic","Modern","Old"],"answer":2,"explain":"সঠিক উত্তর: Modern।"},{"q":"The antonym of 'Ancient' is—","options":["Old","Modern","Antique","Historic"],"answer":1,"explain":"সঠিক উত্তর: Modern।"},{"q":"He is good ___ mathematics.","options":["at","for","on","in"],"answer":0,"explain":"সঠিক উত্তর: at।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? He is good ___ mathematics.","options":["for","in","on","at"],"answer":3,"explain":"সঠিক উত্তর: at।"},{"q":"He is good ___ mathematics.","options":["for","in","on","at"],"answer":3,"explain":"সঠিক উত্তর: at।"},{"q":"A person who treats diseases is a—","options":["Farmer","Engineer","Physician","Pilot"],"answer":2,"explain":"সঠিক উত্তর: Physician।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? A person who treats diseases is a—","options":["Engineer","Pilot","Farmer","Physician"],"answer":3,"explain":"সঠিক উত্তর: Physician।"},{"q":"A person who treats diseases is a—","options":["Pilot","Engineer","Physician","Farmer"],"answer":2,"explain":"সঠিক উত্তর: Physician।"},{"q":"The adjective form of 'Beauty' is—","options":["Beautiful","Beautifully","Beautician","Beautify"],"answer":0,"explain":"সঠিক উত্তর: Beautiful।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? The adjective form of 'Beauty' is—","options":["Beautify","Beautiful","Beautician","Beautifully"],"answer":1,"explain":"সঠিক উত্তর: Beautiful।"},{"q":"The adjective form of 'Beauty' is—","options":["Beautician","Beautiful","Beautify","Beautifully"],"answer":1,"explain":"সঠিক উত্তর: Beautiful।"}],"বাংলাদেশ ও সাধারণ জ্ঞান":[{"q":"বাংলাদেশের সংবিধান কার্যকর হয় কবে?","options":["১৬ ডিসেম্বর ১৯৭২","৭ মার্চ ১৯৭১","২৬ মার্চ ১৯৭১","১০ জানুয়ারি ১৯৭২"],"answer":0,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর ১৯৭২।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের সংবিধান কার্যকর হয় কবে?","options":["১৬ ডিসেম্বর ১৯৭২","১০ জানুয়ারি ১৯৭২","৭ মার্চ ১৯৭১","২৬ মার্চ ১৯৭১"],"answer":0,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর ১৯৭২।"},{"q":"বাংলাদেশের সংবিধান কার্যকর হয় কবে?","options":["৭ মার্চ ১৯৭১","২৬ মার্চ ১৯৭১","১৬ ডিসেম্বর ১৯৭২","১০ জানুয়ারি ১৯৭২"],"answer":2,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর ১৯৭২।"},{"q":"বাংলাদেশের জাতীয় সংসদ ভবনের স্থপতি কে?","options":["লুই আই কান","মাজহারুল ইসলাম","লে করবুসিয়ে","এফ আর খান"],"answer":0,"explain":"সঠিক উত্তর: লুই আই কান।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের জাতীয় সংসদ ভবনের স্থপতি কে?","options":["মাজহারুল ইসলাম","লে করবুসিয়ে","লুই আই কান","এফ আর খান"],"answer":2,"explain":"সঠিক উত্তর: লুই আই কান।"},{"q":"বাংলাদেশের জাতীয় সংসদ ভবনের স্থপতি কে?","options":["মাজহারুল ইসলাম","লুই আই কান","লে করবুসিয়ে","এফ আর খান"],"answer":1,"explain":"সঠিক উত্তর: লুই আই কান।"},{"q":"বাংলাদেশের জাতীয় স্মৃতিসৌধ কোথায় অবস্থিত?","options":["সাভার","টঙ্গী","মিরপুর","রায়েরবাজার"],"answer":0,"explain":"সঠিক উত্তর: সাভার।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের জাতীয় স্মৃতিসৌধ কোথায় অবস্থিত?","options":["মিরপুর","সাভার","টঙ্গী","রায়েরবাজার"],"answer":1,"explain":"সঠিক উত্তর: সাভার।"},{"q":"বাংলাদেশের জাতীয় স্মৃতিসৌধ কোথায় অবস্থিত?","options":["সাভার","মিরপুর","রায়েরবাজার","টঙ্গী"],"answer":0,"explain":"সঠিক উত্তর: সাভার।"},{"q":"বাংলাদেশের বৃহত্তম ম্যানগ্রোভ বন কোনটি?","options":["মধুপুর","সুন্দরবন","লাউয়াছড়া","ভাওয়াল"],"answer":1,"explain":"সঠিক উত্তর: সুন্দরবন।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের বৃহত্তম ম্যানগ্রোভ বন কোনটি?","options":["সুন্দরবন","লাউয়াছড়া","মধুপুর","ভাওয়াল"],"answer":0,"explain":"সঠিক উত্তর: সুন্দরবন।"},{"q":"বাংলাদেশের বৃহত্তম ম্যানগ্রোভ বন কোনটি সঠিক?","options":["মধুপুর","সুন্দরবন","লাউয়াছড়া","ভাওয়াল"],"answer":1,"explain":"সঠিক উত্তর: সুন্দরবন।"},{"q":"বাংলাদেশের দীর্ঘতম সমুদ্রসৈকত কোথায়?","options":["কুয়াকাটা","কক্সবাজার","পতেঙ্গা","সেন্ট মার্টিন"],"answer":1,"explain":"সঠিক উত্তর: কক্সবাজার।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের দীর্ঘতম সমুদ্রসৈকত কোথায়?","options":["কক্সবাজার","পতেঙ্গা","সেন্ট মার্টিন","কুয়াকাটা"],"answer":0,"explain":"সঠিক উত্তর: কক্সবাজার।"},{"q":"বাংলাদেশের দীর্ঘতম সমুদ্রসৈকত কোথায়?","options":["কক্সবাজার","সেন্ট মার্টিন","পতেঙ্গা","কুয়াকাটা"],"answer":0,"explain":"সঠিক উত্তর: কক্সবাজার।"},{"q":"জাতিসংঘ প্রতিষ্ঠিত হয় কত সালে?","options":["১৯১৯","১৯৫২","১৯৪৫","১৯৪৮"],"answer":2,"explain":"সঠিক উত্তর: ১৯৪৫।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? জাতিসংঘ প্রতিষ্ঠিত হয় কত সালে?","options":["১৯৪৫","১৯১৯","১৯৪৮","১৯৫২"],"answer":0,"explain":"সঠিক উত্তর: ১৯৪৫।"},{"q":"জাতিসংঘ প্রতিষ্ঠিত হয় কত সালে?","options":["১৯৪৮","১৯১৯","১৯৫২","১৯৪৫"],"answer":3,"explain":"সঠিক উত্তর: ১৯৪৫।"},{"q":"বিশ্ব স্বাস্থ্য সংস্থার সদর দপ্তর কোথায়?","options":["জেনেভা","প্যারিস","নিউইয়র্ক","রোম"],"answer":0,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বিশ্ব স্বাস্থ্য সংস্থার সদর দপ্তর কোথায়?","options":["নিউইয়র্ক","প্যারিস","জেনেভা","রোম"],"answer":2,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"বিশ্ব স্বাস্থ্য সংস্থার সদর দপ্তর কোথায়?","options":["প্যারিস","রোম","নিউইয়র্ক","জেনেভা"],"answer":3,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"বাংলাদেশের জাতীয় ফুল কোনটি?","options":["জবা","শাপলা","গোলাপ","বেলি"],"answer":1,"explain":"সঠিক উত্তর: শাপলা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের জাতীয় ফুল কোনটি?","options":["জবা","বেলি","শাপলা","গোলাপ"],"answer":2,"explain":"সঠিক উত্তর: শাপলা।"},{"q":"বাংলাদেশের জাতীয় ফুল কোনটি সঠিক?","options":["জবা","বেলি","শাপলা","গোলাপ"],"answer":2,"explain":"সঠিক উত্তর: শাপলা।"},{"q":"বাংলাদেশের জাতীয় ফল কোনটি?","options":["লিচু","পেয়ারা","কাঁঠাল","আম"],"answer":2,"explain":"সঠিক উত্তর: কাঁঠাল।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের জাতীয় ফল কোনটি?","options":["কাঁঠাল","পেয়ারা","আম","লিচু"],"answer":0,"explain":"সঠিক উত্তর: কাঁঠাল।"},{"q":"বাংলাদেশের জাতীয় ফল কোনটি সঠিক?","options":["কাঁঠাল","আম","লিচু","পেয়ারা"],"answer":0,"explain":"সঠিক উত্তর: কাঁঠাল।"},{"q":"বাংলাদেশের জাতীয় মাছ কোনটি?","options":["রুই","কাতলা","ইলিশ","পুঁটি"],"answer":2,"explain":"সঠিক উত্তর: ইলিশ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের জাতীয় মাছ কোনটি?","options":["পুঁটি","রুই","কাতলা","ইলিশ"],"answer":3,"explain":"সঠিক উত্তর: ইলিশ।"},{"q":"বাংলাদেশের জাতীয় মাছ কোনটি সঠিক?","options":["ইলিশ","রুই","কাতলা","পুঁটি"],"answer":0,"explain":"সঠিক উত্তর: ইলিশ।"},{"q":"মুক্তিযুদ্ধের সময় বাংলাদেশকে কয়টি সেক্টরে ভাগ করা হয়?","options":["১২টি","১০টি","১১টি","৯টি"],"answer":2,"explain":"সঠিক উত্তর: ১১টি।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? মুক্তিযুদ্ধের সময় বাংলাদেশকে কয়টি সেক্টরে ভাগ করা হয়?","options":["৯টি","১১টি","১২টি","১০টি"],"answer":1,"explain":"সঠিক উত্তর: ১১টি।"},{"q":"মুক্তিযুদ্ধের সময় বাংলাদেশকে কয়টি সেক্টরে ভাগ করা হয়?","options":["৯টি","১২টি","১১টি","১০টি"],"answer":2,"explain":"সঠিক উত্তর: ১১টি।"},{"q":"ঐতিহাসিক ৭ মার্চের ভাষণ কোথায় দেওয়া হয়?","options":["পল্টন ময়দান","রেসকোর্স ময়দান","সোহরাওয়ার্দী উদ্যানের বাইরে","লালদীঘি ময়দান"],"answer":1,"explain":"সঠিক উত্তর: রেসকোর্স ময়দান।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ঐতিহাসিক ৭ মার্চের ভাষণ কোথায় দেওয়া হয়?","options":["পল্টন ময়দান","রেসকোর্স ময়দান","সোহরাওয়ার্দী উদ্যানের বাইরে","লালদীঘি ময়দান"],"answer":1,"explain":"সঠিক উত্তর: রেসকোর্স ময়দান।"},{"q":"ঐতিহাসিক ৭ মার্চের ভাষণ কোথায় দেওয়া হয়?","options":["পল্টন ময়দান","সোহরাওয়ার্দী উদ্যানের বাইরে","লালদীঘি ময়দান","রেসকোর্স ময়দান"],"answer":3,"explain":"সঠিক উত্তর: রেসকোর্স ময়দান।"},{"q":"বাংলাদেশের প্রথম কৃত্রিম উপগ্রহের নাম কী?","options":["বাংলা স্যাট-১","বিজয়-১","বঙ্গবন্ধু স্যাটেলাইট-১","পদ্মা-১"],"answer":2,"explain":"সঠিক উত্তর: বঙ্গবন্ধু স্যাটেলাইট-১।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? বাংলাদেশের প্রথম কৃত্রিম উপগ্রহের নাম কী?","options":["বিজয়-১","বাংলা স্যাট-১","বঙ্গবন্ধু স্যাটেলাইট-১","পদ্মা-১"],"answer":2,"explain":"সঠিক উত্তর: বঙ্গবন্ধু স্যাটেলাইট-১।"},{"q":"বাংলাদেশের প্রথম কৃত্রিম উপগ্রহের নাম কী?","options":["বঙ্গবন্ধু স্যাটেলাইট-১","পদ্মা-১","বাংলা স্যাট-১","বিজয়-১"],"answer":0,"explain":"সঠিক উত্তর: বঙ্গবন্ধু স্যাটেলাইট-১।"},{"q":"পদ্মা সেতু যান চলাচলের জন্য খুলে দেওয়া হয় কবে?","options":["২৬ মার্চ ২০২১","২৫ জুন ২০২২","১৬ ডিসেম্বর ২০২২","২১ ফেব্রুয়ারি ২০২৩"],"answer":1,"explain":"সঠিক উত্তর: ২৫ জুন ২০২২।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? পদ্মা সেতু যান চলাচলের জন্য খুলে দেওয়া হয় কবে?","options":["২৬ মার্চ ২০২১","২১ ফেব্রুয়ারি ২০২৩","১৬ ডিসেম্বর ২০২২","২৫ জুন ২০২২"],"answer":3,"explain":"সঠিক উত্তর: ২৫ জুন ২০২২।"},{"q":"পদ্মা সেতু যান চলাচলের জন্য খুলে দেওয়া হয় কবে?","options":["২১ ফেব্রুয়ারি ২০২৩","২৫ জুন ২০২২","২৬ মার্চ ২০২১","১৬ ডিসেম্বর ২০২২"],"answer":1,"explain":"সঠিক উত্তর: ২৫ জুন ২০২২।"},{"q":"আন্তর্জাতিক মাতৃভাষা দিবস কবে?","options":["২৬ মার্চ","১৪ ডিসেম্বর","১৬ ডিসেম্বর","২১ ফেব্রুয়ারি"],"answer":3,"explain":"সঠিক উত্তর: ২১ ফেব্রুয়ারি।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? আন্তর্জাতিক মাতৃভাষা দিবস কবে?","options":["২৬ মার্চ","১৪ ডিসেম্বর","২১ ফেব্রুয়ারি","১৬ ডিসেম্বর"],"answer":2,"explain":"সঠিক উত্তর: ২১ ফেব্রুয়ারি।"},{"q":"আন্তর্জাতিক মাতৃভাষা দিবস কবে?","options":["১৪ ডিসেম্বর","২৬ মার্চ","২১ ফেব্রুয়ারি","১৬ ডিসেম্বর"],"answer":2,"explain":"সঠিক উত্তর: ২১ ফেব্রুয়ারি।"}],"প্রাথমিক চিকিৎসা ও স্বাস্থ্যবিজ্ঞান":[{"q":"শরীরের তাপমাত্রা মাপার যন্ত্র কোনটি?","options":["গ্লুকোমিটার","স্টেথোস্কোপ","থার্মোমিটার","স্ফিগমোম্যানোমিটার"],"answer":2,"explain":"সঠিক উত্তর: থার্মোমিটার।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? শরীরের তাপমাত্রা মাপার যন্ত্র কোনটি?","options":["স্টেথোস্কোপ","স্ফিগমোম্যানোমিটার","থার্মোমিটার","গ্লুকোমিটার"],"answer":2,"explain":"সঠিক উত্তর: থার্মোমিটার।"},{"q":"শরীরের তাপমাত্রা মাপার যন্ত্র কোনটি সঠিক?","options":["স্ফিগমোম্যানোমিটার","স্টেথোস্কোপ","গ্লুকোমিটার","থার্মোমিটার"],"answer":3,"explain":"সঠিক উত্তর: থার্মোমিটার।"},{"q":"রক্তে অক্সিজেনের মাত্রা মাপতে ব্যবহৃত হয়—","options":["পালস অক্সিমিটার","স্পাইরোমিটার","ইইজি","ইসিজি"],"answer":0,"explain":"সঠিক উত্তর: পালস অক্সিমিটার।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? রক্তে অক্সিজেনের মাত্রা মাপতে ব্যবহৃত হয়—","options":["পালস অক্সিমিটার","ইসিজি","ইইজি","স্পাইরোমিটার"],"answer":0,"explain":"সঠিক উত্তর: পালস অক্সিমিটার।"},{"q":"রক্তে অক্সিজেনের মাত্রা মাপতে ব্যবহৃত হয়—","options":["ইইজি","পালস অক্সিমিটার","ইসিজি","স্পাইরোমিটার"],"answer":1,"explain":"সঠিক উত্তর: পালস অক্সিমিটার।"},{"q":"জীবাণুমুক্ত করার জন্য তাপ ও চাপ ব্যবহার করে কোন যন্ত্র?","options":["মাইক্রোস্কোপ","ইনকিউবেটর","অটোক্লেভ","সেন্ট্রিফিউজ"],"answer":2,"explain":"সঠিক উত্তর: অটোক্লেভ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? জীবাণুমুক্ত করার জন্য তাপ ও চাপ ব্যবহার করে কোন যন্ত্র?","options":["মাইক্রোস্কোপ","অটোক্লেভ","ইনকিউবেটর","সেন্ট্রিফিউজ"],"answer":1,"explain":"সঠিক উত্তর: অটোক্লেভ।"},{"q":"জীবাণুমুক্ত করার জন্য তাপ ও চাপ ব্যবহার করে কোন যন্ত্র?","options":["মাইক্রোস্কোপ","অটোক্লেভ","ইনকিউবেটর","সেন্ট্রিফিউজ"],"answer":1,"explain":"সঠিক উত্তর: অটোক্লেভ।"},{"q":"রক্তের নমুনা থেকে কোষ ও প্লাজমা পৃথক করতে ব্যবহৃত হয়—","options":["সেন্ট্রিফিউজ","অটোক্লেভ","থার্মোমিটার","অক্সিমিটার"],"answer":0,"explain":"সঠিক উত্তর: সেন্ট্রিফিউজ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? রক্তের নমুনা থেকে কোষ ও প্লাজমা পৃথক করতে ব্যবহৃত হয়—","options":["অক্সিমিটার","সেন্ট্রিফিউজ","থার্মোমিটার","অটোক্লেভ"],"answer":1,"explain":"সঠিক উত্তর: সেন্ট্রিফিউজ।"},{"q":"রক্তের নমুনা থেকে কোষ ও প্লাজমা পৃথক করতে ব্যবহৃত হয়—","options":["সেন্ট্রিফিউজ","অক্সিমিটার","থার্মোমিটার","অটোক্লেভ"],"answer":0,"explain":"সঠিক উত্তর: সেন্ট্রিফিউজ।"},{"q":"হাত ধোয়ার সবচেয়ে গুরুত্বপূর্ণ উদ্দেশ্য কী?","options":["সংক্রমণ প্রতিরোধ","জ্বর কমানো","রক্তচাপ কমানো","হজম বাড়ানো"],"answer":0,"explain":"সঠিক উত্তর: সংক্রমণ প্রতিরোধ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? হাত ধোয়ার সবচেয়ে গুরুত্বপূর্ণ উদ্দেশ্য কী?","options":["জ্বর কমানো","হজম বাড়ানো","রক্তচাপ কমানো","সংক্রমণ প্রতিরোধ"],"answer":3,"explain":"সঠিক উত্তর: সংক্রমণ প্রতিরোধ।"},{"q":"হাত ধোয়ার সবচেয়ে গুরুত্বপূর্ণ উদ্দেশ্য কী?","options":["হজম বাড়ানো","সংক্রমণ প্রতিরোধ","জ্বর কমানো","রক্তচাপ কমানো"],"answer":1,"explain":"সঠিক উত্তর: সংক্রমণ প্রতিরোধ।"},{"q":"ORS প্রধানত কোন অবস্থায় ব্যবহার করা হয়?","options":["অ্যালার্জি","হাড় ভাঙা","উচ্চ রক্তচাপ","ডায়রিয়াজনিত পানিশূন্যতা"],"answer":3,"explain":"সঠিক উত্তর: ডায়রিয়াজনিত পানিশূন্যতা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ORS প্রধানত কোন অবস্থায় ব্যবহার করা হয়?","options":["ডায়রিয়াজনিত পানিশূন্যতা","অ্যালার্জি","উচ্চ রক্তচাপ","হাড় ভাঙা"],"answer":0,"explain":"সঠিক উত্তর: ডায়রিয়াজনিত পানিশূন্যতা।"},{"q":"ORS প্রধানত কোন অবস্থায় ব্যবহার করা হয়?","options":["ডায়রিয়াজনিত পানিশূন্যতা","অ্যালার্জি","হাড় ভাঙা","উচ্চ রক্তচাপ"],"answer":0,"explain":"সঠিক উত্তর: ডায়রিয়াজনিত পানিশূন্যতা।"},{"q":"প্রাথমিক চিকিৎসায় ক্ষতস্থানে প্রথমে কী করা উচিত?","options":["তেল লাগানো","ক্ষত ঘষে পরিষ্কার করা","মাটি লাগানো","পরিষ্কার পানি দিয়ে ধুয়ে ঢেকে রাখা"],"answer":3,"explain":"সঠিক উত্তর: পরিষ্কার পানি দিয়ে ধুয়ে ঢেকে রাখা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? প্রাথমিক চিকিৎসায় ক্ষতস্থানে প্রথমে কী করা উচিত?","options":["ক্ষত ঘষে পরিষ্কার করা","তেল লাগানো","মাটি লাগানো","পরিষ্কার পানি দিয়ে ধুয়ে ঢেকে রাখা"],"answer":3,"explain":"সঠিক উত্তর: পরিষ্কার পানি দিয়ে ধুয়ে ঢেকে রাখা।"},{"q":"প্রাথমিক চিকিৎসায় ক্ষতস্থানে প্রথমে কী করা উচিত?","options":["মাটি লাগানো","তেল লাগানো","ক্ষত ঘষে পরিষ্কার করা","পরিষ্কার পানি দিয়ে ধুয়ে ঢেকে রাখা"],"answer":3,"explain":"সঠিক উত্তর: পরিষ্কার পানি দিয়ে ধুয়ে ঢেকে রাখা।"},{"q":"আগুনে পোড়া স্থানে প্রাথমিকভাবে কী করা উচিত?","options":["টুথপেস্ট লাগানো","ঠান্ডা প্রবাহমান পানি প্রয়োগ","বরফ সরাসরি লাগানো","তেল লাগানো"],"answer":1,"explain":"সঠিক উত্তর: ঠান্ডা প্রবাহমান পানি প্রয়োগ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? আগুনে পোড়া স্থানে প্রাথমিকভাবে কী করা উচিত?","options":["বরফ সরাসরি লাগানো","টুথপেস্ট লাগানো","ঠান্ডা প্রবাহমান পানি প্রয়োগ","তেল লাগানো"],"answer":2,"explain":"সঠিক উত্তর: ঠান্ডা প্রবাহমান পানি প্রয়োগ।"},{"q":"আগুনে পোড়া স্থানে প্রাথমিকভাবে কী করা উচিত?","options":["ঠান্ডা প্রবাহমান পানি প্রয়োগ","তেল লাগানো","টুথপেস্ট লাগানো","বরফ সরাসরি লাগানো"],"answer":0,"explain":"সঠিক উত্তর: ঠান্ডা প্রবাহমান পানি প্রয়োগ।"},{"q":"রক্তচাপের স্বাভাবিক প্রাপ্তবয়স্ক মান প্রায় কত?","options":["১৬০/১০০ মিমি পারদ","৯০/৪০ মিমি পারদ","২০০/১২০ মিমি পারদ","১২০/৮০ মিমি পারদ"],"answer":3,"explain":"সঠিক উত্তর: ১২০/৮০ মিমি পারদ।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? রক্তচাপের স্বাভাবিক প্রাপ্তবয়স্ক মান প্রায় কত?","options":["১২০/৮০ মিমি পারদ","৯০/৪০ মিমি পারদ","১৬০/১০০ মিমি পারদ","২০০/১২০ মিমি পারদ"],"answer":0,"explain":"সঠিক উত্তর: ১২০/৮০ মিমি পারদ।"},{"q":"রক্তচাপের স্বাভাবিক প্রাপ্তবয়স্ক মান প্রায় কত?","options":["১৬০/১০০ মিমি পারদ","২০০/১২০ মিমি পারদ","৯০/৪০ মিমি পারদ","১২০/৮০ মিমি পারদ"],"answer":3,"explain":"সঠিক উত্তর: ১২০/৮০ মিমি পারদ।"},{"q":"হিমোগ্লোবিনের প্রধান কাজ কী?","options":["অ্যান্টিবডি তৈরি","রক্ত জমাট বাঁধানো","অক্সিজেন পরিবহন","হরমোন তৈরি"],"answer":2,"explain":"সঠিক উত্তর: অক্সিজেন পরিবহন।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? হিমোগ্লোবিনের প্রধান কাজ কী?","options":["হরমোন তৈরি","রক্ত জমাট বাঁধানো","অক্সিজেন পরিবহন","অ্যান্টিবডি তৈরি"],"answer":2,"explain":"সঠিক উত্তর: অক্সিজেন পরিবহন।"},{"q":"হিমোগ্লোবিনের প্রধান কাজ কী?","options":["অ্যান্টিবডি তৈরি","অক্সিজেন পরিবহন","রক্ত জমাট বাঁধানো","হরমোন তৈরি"],"answer":1,"explain":"সঠিক উত্তর: অক্সিজেন পরিবহন।"},{"q":"হেপাটাইটিস প্রধানত কোন অঙ্গকে আক্রান্ত করে?","options":["হৃৎপিণ্ড","ফুসফুস","বৃক্ক","যকৃত"],"answer":3,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? হেপাটাইটিস প্রধানত কোন অঙ্গকে আক্রান্ত করে?","options":["বৃক্ক","হৃৎপিণ্ড","যকৃত","ফুসফুস"],"answer":2,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"হেপাটাইটিস প্রধানত কোন অঙ্গকে আক্রান্ত করে?","options":["যকৃত","বৃক্ক","হৃৎপিণ্ড","ফুসফুস"],"answer":0,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"যক্ষ্মা প্রধানত কোন অঙ্গকে আক্রান্ত করে?","options":["চোখ","অস্থি","ত্বক","ফুসফুস"],"answer":3,"explain":"সঠিক উত্তর: ফুসফুস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? যক্ষ্মা প্রধানত কোন অঙ্গকে আক্রান্ত করে?","options":["ফুসফুস","ত্বক","চোখ","অস্থি"],"answer":0,"explain":"সঠিক উত্তর: ফুসফুস।"},{"q":"যক্ষ্মা প্রধানত কোন অঙ্গকে আক্রান্ত করে?","options":["ফুসফুস","ত্বক","অস্থি","চোখ"],"answer":0,"explain":"সঠিক উত্তর: ফুসফুস।"},{"q":"ডেঙ্গু প্রতিরোধে কোনটি সবচেয়ে কার্যকর?","options":["অপরিষ্কার পানি পান","দিনে ঘুমানো","এডিস মশার প্রজননস্থল ধ্বংস","খোলা স্থানে আবর্জনা রাখা"],"answer":2,"explain":"সঠিক উত্তর: এডিস মশার প্রজননস্থল ধ্বংস।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? ডেঙ্গু প্রতিরোধে কোনটি সবচেয়ে কার্যকর?","options":["খোলা স্থানে আবর্জনা রাখা","দিনে ঘুমানো","অপরিষ্কার পানি পান","এডিস মশার প্রজননস্থল ধ্বংস"],"answer":3,"explain":"সঠিক উত্তর: এডিস মশার প্রজননস্থল ধ্বংস।"},{"q":"ডেঙ্গু প্রতিরোধে কোনটি সঠিক সবচেয়ে কার্যকর?","options":["অপরিষ্কার পানি পান","দিনে ঘুমানো","খোলা স্থানে আবর্জনা রাখা","এডিস মশার প্রজননস্থল ধ্বংস"],"answer":3,"explain":"সঠিক উত্তর: এডিস মশার প্রজননস্থল ধ্বংস।"},{"q":"টিটেনাস প্রতিরোধে কোনটি দেওয়া হয়?","options":["টিটেনাস টিকা","ওপিভি","বিসিজি টিকা","এমআর টিকা"],"answer":0,"explain":"সঠিক উত্তর: টিটেনাস টিকা।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? টিটেনাস প্রতিরোধে কোনটি দেওয়া হয়?","options":["ওপিভি","টিটেনাস টিকা","এমআর টিকা","বিসিজি টিকা"],"answer":1,"explain":"সঠিক উত্তর: টিটেনাস টিকা।"},{"q":"টিটেনাস প্রতিরোধে কোনটি সঠিক দেওয়া হয়?","options":["বিসিজি টিকা","এমআর টিকা","টিটেনাস টিকা","ওপিভি"],"answer":2,"explain":"সঠিক উত্তর: টিটেনাস টিকা।"},{"q":"শরীরের রোগ প্রতিরোধে অ্যান্টিবডি তৈরি করে কোন কোষ?","options":["প্লেটলেট","নিউট্রোফিল","লোহিত রক্তকণিকা","বি-লিম্ফোসাইট"],"answer":3,"explain":"সঠিক উত্তর: বি-লিম্ফোসাইট।"},{"q":"নিচের কোন বক্তব্যটি সঠিক? শরীরের রোগ প্রতিরোধে অ্যান্টিবডি তৈরি করে কোন কোষ?","options":["প্লেটলেট","লোহিত রক্তকণিকা","বি-লিম্ফোসাইট","নিউট্রোফিল"],"answer":2,"explain":"সঠিক উত্তর: বি-লিম্ফোসাইট।"},{"q":"শরীরের রোগ প্রতিরোধে অ্যান্টিবডি তৈরি করে কোন কোষ?","options":["বি-লিম্ফোসাইট","লোহিত রক্তকণিকা","প্লেটলেট","নিউট্রোফিল"],"answer":0,"explain":"সঠিক উত্তর: বি-লিম্ফোসাইট।"}]};
  const IHT_BN_EXTRA_SUBJECTS = Object.keys(IHT_BN_EXTRA_BANK).map((name) => `IHT নতুন বাংলা ${name}`);
  const IHT_BN_EXTRA_FULL = Object.values(IHT_BN_EXTRA_BANK).flat();
  const IHT_BN_SUBJECTS = Object.keys(IHT_BN_QUIZ_BANK).map((name) => `IHT বাংলা ${name}`);
  const IHT_BN_FULL_MOCK = Object.values(IHT_BN_QUIZ_BANK).flat();
  const IHT_SUBJECTS = Object.keys(IHT_QUIZ_BANK).map((name) => `IHT ${name}`);
  const IHT_FULL_MOCK = Object.values(IHT_QUIZ_BANK).flat();
  // আগের অনুশীলনী সেটগুলোর প্রশ্নসংখ্যা অনুসারে ৫টি রিভিশন মডেল টেস্ট।
  const IHT_PREVIOUS_MODEL_SIZES = [45, 50, 60, 60, 60];
  const IHT_PREVIOUS_MODEL_TESTS = (() => {
    const pool = [...IHT_BN_FULL_MOCK, ...IHT_BN_EXTRA_FULL];
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    let cursor = 0;
    return IHT_PREVIOUS_MODEL_SIZES.map((size) => {
      const set = shuffled.slice(cursor, cursor + size);
      cursor += size;
      return set;
    });
  })();
  const IHT_PREVIOUS_MODEL_NAMES = IHT_PREVIOUS_MODEL_SIZES.map((_, i) => `IHT রিভিশন মডেল টেস্ট ${i + 1}`);

  // Varsity B-Unit: stream-wise banks. Each stream has its own subject groups.
  // Questions are curated practice items, not claimed as verbatim official past papers.
  const VARSITY_UNIVERSITIES = [
    { id: 'DU', name: 'ঢাকা বিশ্ববিদ্যালয়', code: 'DU', logo: 'assets/du-logo.png' },
    { id: 'RU', name: 'রাজশাহী বিশ্ববিদ্যালয়', code: 'RU', logo: 'assets/ru-logo.png' },
    { id: 'JU', name: 'জাহাঙ্গীরনগর বিশ্ববিদ্যালয়', code: 'JU', logo: 'assets/ju-logo.png' },
    { id: 'GST', name: 'GST গুচ্ছ', code: 'GST', logo: 'assets/gst-logo.png' }
  ];
  const uniqueQuestions = (...groups) => {
    const seen = new Set();
    return groups.flat().filter((q) => q && q.q && !seen.has(q.q) && seen.add(q.q));
  };
  const VARSITY_STREAM_BANKS = {
    SCIENCE: {
      label: 'বিজ্ঞান বিভাগ', subjects: {
        'জীববিজ্ঞান': uniqueQuestions(IHT_QUIZ_BANK.Biology, IHT_BN_EXTRA_BANK['জীববিজ্ঞান'], IHT_BN_EXTRA_BANK['মানবদেহ ও শারীরতত্ত্ব']),
        'রসায়ন': uniqueQuestions(IHT_QUIZ_BANK.Chemistry, IHT_BN_EXTRA_BANK['রসায়ন']),
        'পদার্থবিজ্ঞান': uniqueQuestions(IHT_QUIZ_BANK.Physics, IHT_BN_EXTRA_BANK['পদার্থবিজ্ঞান']),
        'গণিত': uniqueQuestions(IHT_QUIZ_BANK.Mathematics, IHT_QUIZ_BANK.Math)
      }
    },
    HUMANITIES: {
      label: 'মানবিক বিভাগ', subjects: {
        'বাংলা': [
          ['বাংলা সাহিত্যের প্রাচীনতম নিদর্শন কোনটি?',['চর্যাপদ','শ্রীকৃষ্ণকীর্তন','মঙ্গলকাব্য','গীতাঞ্জলি'],0],
          ['চর্যাপদ আবিষ্কার করেন কে?',['হরপ্রসাদ শাস্ত্রী','দীনেশচন্দ্র সেন','সুনীতিকুমার চট্টোপাধ্যায়','মুহম্মদ শহীদুল্লাহ'],0],
          ['বাংলা গদ্যের বিকাশে প্রধান পথিকৃৎ হিসেবে কাকে বলা হয়?',['ঈশ্বরচন্দ্র বিদ্যাসাগর','মাইকেল মধুসূদন দত্ত','জসীমউদ্দীন','সুকান্ত ভট্টাচার্য'],0],
          ['বাংলা সাহিত্যের প্রথম সার্থক উপন্যাস কোনটি?',['দুর্গেশনন্দিনী','আলালের ঘরের দুলাল','কপালকুণ্ডলা','বিষবৃক্ষ'],0],
          ['‘মেঘনাদবধ কাব্য’-এর রচয়িতা কে?',['মাইকেল মধুসূদন দত্ত','রবীন্দ্রনাথ ঠাকুর','কাজী নজরুল ইসলাম','বঙ্কিমচন্দ্র চট্টোপাধ্যায়'],0],
          ['‘গীতাঞ্জলি’ কাব্যের রচয়িতা কে?',['রবীন্দ্রনাথ ঠাকুর','কাজী নজরুল ইসলাম','জীবনানন্দ দাশ','জসীমউদ্দীন'],0],
          ['বাংলাদেশের জাতীয় কবি কে?',['কাজী নজরুল ইসলাম','রবীন্দ্রনাথ ঠাকুর','জসীমউদ্দীন','শামসুর রাহমান'],0],
          ['‘বিষাদ-সিন্ধু’ কার রচনা?',['মীর মশাররফ হোসেন','বঙ্কিমচন্দ্র চট্টোপাধ্যায়','শরৎচন্দ্র চট্টোপাধ্যায়','প্রমথ চৌধুরী'],0],
          ['‘পল্লীকবি’ নামে পরিচিত কে?',['জসীমউদ্দীন','কায়কোবাদ','ফররুখ আহমদ','সুকান্ত ভট্টাচার্য'],0],
          ['‘বনলতা সেন’ কবিতার কবি কে?',['জীবনানন্দ দাশ','সুধীন্দ্রনাথ দত্ত','রবীন্দ্রনাথ ঠাকুর','শামসুর রাহমান'],0],
          ['বাংলা একাডেমি প্রতিষ্ঠিত হয় কত সালে?',['১৯৫৫','১৯৪৮','১৯৬১','১৯৭২'],0],
          ['‘আমার ভাইয়ের রক্তে রাঙানো’ গানের রচয়িতা কে?',['আবদুল গাফ্‌ফার চৌধুরী','আলতাফ মাহমুদ','আবদুল লতিফ','গাজী মাজহারুল আনোয়ার'],0]
        ].map(([q,o,a])=>({q,options:o,answer:a,explain:`সঠিক উত্তর: ${o[a]}`})),
        'English': uniqueQuestions(IHT_QUIZ_BANK.English, QUIZ_BANK.English).filter(x => /grammar|antonym|synonym|preposition|tense|voice|narration|article|correct|plural|meaning|spelling|sentence|verb|noun|adjective|pronoun/i.test(x.q)),
        'প্রাচীন ও মধ্যযুগের ইতিহাস': [
          ['বাংলার প্রাচীনতম উল্লেখযোগ্য জনপদগুলোর একটি কোনটি?',['পুণ্ড্র','দিল্লি','মালাবার','কাশ্মীর'],0],
          ['পুণ্ড্রনগরের প্রত্ননিদর্শন কোথায় পাওয়া গেছে?',['মহাস্থানগড়','পাহাড়পুর','ময়নামতি','সোনারগাঁও'],0],
          ['বাংলায় পাল বংশের প্রতিষ্ঠাতা কে?',['গোপাল','ধর্মপাল','দেবপাল','মহীপাল'],0],
          ['পাল রাজারা প্রধানত কোন ধর্মের পৃষ্ঠপোষক ছিলেন?',['বৌদ্ধ','জৈন','খ্রিষ্টান','শিখ'],0],
          ['সেন বংশের শেষ উল্লেখযোগ্য রাজা কে?',['লক্ষ্মণ সেন','বিজয় সেন','বল্লাল সেন','হেমন্ত সেন'],0],
          ['বাংলায় মুসলিম শাসনের সূচনা করেন কে?',['ইখতিয়ার উদ্দিন মুহম্মদ বখতিয়ার খলজি','শের শাহ','আলাউদ্দিন খিলজি','ইলতুৎমিশ'],0],
          ['দিল্লি সালতানাতের প্রথম সুলতানি বংশ কোনটি?',['দাস বংশ','খলজি বংশ','তুঘলক বংশ','লোদি বংশ'],0],
          ['মুঘল সাম্রাজ্যের প্রতিষ্ঠাতা কে?',['বাবর','হুমায়ুন','আকবর','শাহজাহান'],0],
          ['পানিপথের প্রথম যুদ্ধ কত সালে হয়?',['১৫২৬','১৫৫৬','১৭৬১','১৭৫৭'],0],
          ['আকবরের রাজস্ব ব্যবস্থার সঙ্গে কার নাম বিশেষভাবে জড়িত?',['টोडরমল','বীরবল','মানসিংহ','আবুল ফজল'],0],
          ['শাহজাহান কোন স্থাপত্য নির্মাণের জন্য বিশেষভাবে পরিচিত?',['তাজমহল','কুতুব মিনার','লালকেল্লা (দিল্লি)','সাঁচি স্তূপ'],0],
          ['বাংলায় মুঘল সুবাহ প্রতিষ্ঠার সঙ্গে কোন সম্রাটের নাম জড়িত?',['আকবর','বাবর','ঔরঙ্গজেব','বাহাদুর শাহ'],0]
        ].map(([q,o,a])=>({q,options:o,answer:a,explain:`সঠিক উত্তর: ${o[a]}`})),
        'ব্রিটিশ শাসন ও ঔপনিবেশিক ইতিহাস': [
          ['পলাশীর যুদ্ধ কত সালে সংঘটিত হয়?',['১৭৫৭','১৭৬৪','১৭৯৩','১৮৫৭'],0],
          ['পলাশীর যুদ্ধে বাংলার নবাব কে ছিলেন?',['সিরাজউদ্দৌলা','মীর কাসিম','আলীবর্দী খান','মীর জাফর'],0],
          ['বক্সারের যুদ্ধ কত সালে হয়?',['১৭৬৪','১৭৫৭','১৭৭৩','১৭৯৩'],0],
          ['চিরস্থায়ী বন্দোবস্ত প্রবর্তন করেন কে?',['লর্ড কর্নওয়ালিস','লর্ড ডালহৌসি','লর্ড কার্জন','ওয়ারেন হেস্টিংস'],0],
          ['চিরস্থায়ী বন্দোবস্ত চালু হয় কত সালে?',['১৭৯৩','১৭৫৭','১৮৫৭','১৯০৫'],0],
          ['সিপাহি বিদ্রোহ সংঘটিত হয় কত সালে?',['১৮৫৭','১৮৮৫','১৯০৫','১৯১১'],0],
          ['বঙ্গভঙ্গ কার্যকর হয় কত সালে?',['১৯০৫','১৯১১','১৯৪০','১৯৪৭'],0],
          ['বঙ্গভঙ্গ রদ হয় কত সালে?',['১৯১১','১৯০৫','১৯১৯','১৯৩৫'],0],
          ['ভারতীয় জাতীয় কংগ্রেস প্রতিষ্ঠিত হয় কত সালে?',['১৮৮৫','১৯০৬','১৯০৫','১৯১১'],0],
          ['মুসলিম লীগ প্রতিষ্ঠিত হয় কোথায়?',['ঢাকা','কলকাতা','লাহোর','দিল্লি'],0],
          ['মুসলিম লীগ প্রতিষ্ঠিত হয় কত সালে?',['১৯০৬','১৮৮৫','১৯০৫','১৯৪০'],0],
          ['ভারত স্বাধীনতা আইন কার্যকর হয় কত সালে?',['১৯৪৭','১৯৪০','১৯৪৬','১৯৫২'],0]
        ].map(([q,o,a])=>({q,options:o,answer:a,explain:`সঠিক উত্তর: ${o[a]}`})),
        'বাংলাদেশের ইতিহাস ও মুক্তিযুদ্ধ': [
          ['ভাষা আন্দোলনের ঐতিহাসিক ২১ ফেব্রুয়ারি কোন সালে?',['১৯৫২','১৯৪৮','১৯৫৪','১৯৬২'],0],
          ['যুক্তফ্রন্ট নির্বাচন অনুষ্ঠিত হয় কত সালে?',['১৯৫৪','১৯৫২','১৯৫৬','১৯৬৬'],0],
          ['ছয় দফা দাবি উত্থাপিত হয় কত সালে?',['১৯৬৬','১৯৫৪','১৯৬৯','১৯৭০'],0],
          ['ঊনসত্তরের গণঅভ্যুত্থান সংঘটিত হয় কত সালে?',['১৯৬৯','১৯৬৬','১৯৭০','১৯৭১'],0],
          ['৭ মার্চের ঐতিহাসিক ভাষণ কোথায় দেওয়া হয়?',['রেসকোর্স ময়দান','পল্টন ময়দান','লালদীঘি ময়দান','সোহরাওয়ার্দী উদ্যানের বাইরে'],0],
          ['অপারেশন সার্চলাইট শুরু হয় কবে?',['২৫ মার্চ ১৯৭১ রাতে','৭ মার্চ ১৯৭১','২৬ মার্চ ১৯৭১ সকালে','১৬ ডিসেম্বর ১৯৭১'],0],
          ['বাংলাদেশের স্বাধীনতা দিবস কবে?',['২৬ মার্চ','১৬ ডিসেম্বর','২১ ফেব্রুয়ারি','৭ মার্চ'],0],
          ['মুজিবনগর সরকার শপথ গ্রহণ করে কবে?',['১৭ এপ্রিল ১৯৭১','২৬ মার্চ ১৯৭১','১০ এপ্রিল ১৯৭১','১৬ ডিসেম্বর ১৯৭১'],0],
          ['মুক্তিযুদ্ধের সময় বাংলাদেশকে কয়টি সেক্টরে ভাগ করা হয়?',['১১টি','৯টি','১০টি','১২টি'],0],
          ['বাংলাদেশের বিজয় দিবস কবে?',['১৬ ডিসেম্বর','২৬ মার্চ','১৪ ডিসেম্বর','৭ মার্চ'],0],
          ['শহীদ বুদ্ধিজীবী দিবস কবে পালিত হয়?',['১৪ ডিসেম্বর','১৬ ডিসেম্বর','২১ ফেব্রুয়ারি','২৬ মার্চ'],0],
          ['বাংলাদেশের সংবিধান গৃহীত হয় কবে?',['৪ নভেম্বর ১৯৭২','১৬ ডিসেম্বর ১৯৭১','২৬ মার্চ ১৯৭২','৭ মার্চ ১৯৭৩'],0]
        ].map(([q,o,a])=>({q,options:o,answer:a,explain:`সঠিক উত্তর: ${o[a]}`})),
        'বাংলাদেশের ভূগোল: নদ-নদী ও খাল-বিল': [
          ['বাংলাদেশের প্রধান নদী ব্যবস্থার একটি কোনটি?',['পদ্মা','নীল','আমাজন','ভলগা'],0],
          ['যমুনা কোন নদীর প্রধান বাংলাদেশি প্রবাহ?',['ব্রহ্মপুত্র','গঙ্গা','মেঘনা','তিস্তা'],0],
          ['পদ্মা ও যমুনা কোথায় মিলিত হয়েছে?',['গোয়ালন্দের কাছে','চাঁদপুরে','ভোলায়','সিলেটে'],0],
          ['পদ্মা ও মেঘনা কোথায় মিলিত হয়েছে?',['চাঁদপুরের কাছে','কুষ্টিয়ায়','রংপুরে','সুনামগঞ্জে'],0],
          ['বাংলাদেশের দীর্ঘতম নদী হিসেবে সাধারণভাবে কোন নদীকে উল্লেখ করা হয়?',['সুরমা-মেঘনা নদীপ্রবাহ','করতোয়া','বুড়িগঙ্গা','ধলেশ্বরী'],0],
          ['কাপ্তাই হ্রদ কোন নদীর ওপর বাঁধ নির্মাণের ফলে সৃষ্টি?',['কর্ণফুলী','সাঙ্গু','মাতামুহুরী','ফেনী'],0],
          ['তিস্তা ব্যারাজ কোথায় অবস্থিত?',['নীলফামারী-লালমনিরহাট অঞ্চলে','চাঁদপুরে','বরিশালে','কক্সবাজারে'],0],
          ['হাওর অঞ্চল প্রধানত বাংলাদেশের কোন অংশে?',['উত্তর-পূর্বাঞ্চলে','দক্ষিণ-পশ্চিমে','মধ্য-পশ্চিমে','দক্ষিণ-পূর্ব উপকূলে'],0],
          ['টাঙ্গুয়ার হাওর কোন জেলায়?',['সুনামগঞ্জ','সিলেট','কিশোরগঞ্জ','নেত্রকোনা'],0],
          ['চলন বিল প্রধানত কোন অঞ্চলে অবস্থিত?',['নাটোর-পাবনা-সিরাজগঞ্জ অঞ্চল','খুলনা-সাতক্ষীরা','সিলেট-মৌলভীবাজার','চট্টগ্রাম-কক্সবাজার'],0],
          ['বাংলাদেশের বৃহত্তম ম্যানগ্রোভ বন কোনটি?',['সুন্দরবন','ভাওয়াল বন','মধুপুর বন','লাউয়াছড়া'],0],
          ['কাপ্তাই হ্রদ কোন জেলায় অবস্থিত?',['রাঙামাটি','বান্দরবান','খাগড়াছড়ি','চট্টগ্রাম'],0]
        ].map(([q,o,a])=>({q,options:o,answer:a,explain:`সঠিক উত্তর: ${o[a]}`})),
        'আন্তর্জাতিক বিষয়াবলি': [
          ['জাতিসংঘ প্রতিষ্ঠিত হয় কত সালে?',['১৯৪৫','১৯১৯','১৯৪৮','১৯৫৫'],0],
          ['জাতিসংঘের সদর দপ্তর কোথায়?',['নিউইয়র্ক','জেনেভা','প্যারিস','লন্ডন'],0],
          ['UNESCO-এর সদর দপ্তর কোথায়?',['প্যারিস','রোম','নিউইয়র্ক','ভিয়েনা'],0],
          ['বিশ্ব স্বাস্থ্য সংস্থার (WHO) সদর দপ্তর কোথায়?',['জেনেভা','নিউইয়র্ক','ওয়াশিংটন ডিসি','প্যারিস'],0],
          ['সার্ক (SAARC) প্রতিষ্ঠিত হয় কত সালে?',['১৯৮৫','১৯৭৫','১৯৯১','২০০১'],0],
          ['সার্কের সচিবালয় কোথায়?',['কাঠমান্ডু','ঢাকা','দিল্লি','কলম্বো'],0],
          ['আসিয়ানের সদর দপ্তর কোথায়?',['জাকার্তা','ব্যাংকক','সিঙ্গাপুর','কুয়ালালামপুর'],0],
          ['আন্তর্জাতিক বিচার আদালত কোথায় অবস্থিত?',['দ্য হেগ','জেনেভা','রোম','ব্রাসেলস'],0],
          ['বিশ্বব্যাংকের সদর দপ্তর কোথায়?',['ওয়াশিংটন ডিসি','নিউইয়র্ক','লন্ডন','টোকিও'],0],
          ['OIC-এর সদর দপ্তর কোথায়?',['জেদ্দা','রিয়াদ','দোহা','আবুধাবি'],0],
          ['বিশ্ব পরিবেশ দিবস কবে?',['৫ জুন','২২ এপ্রিল','১৬ সেপ্টেম্বর','১ মে'],0],
          ['আন্তর্জাতিক মাতৃভাষা দিবস হিসেবে ২১ ফেব্রুয়ারির স্বীকৃতি দেয় কোন সংস্থা?',['UNESCO','WHO','UNICEF','FAO'],0]
        ].map(([q,o,a])=>({q,options:o,answer:a,explain:`সঠিক উত্তর: ${o[a]}`})),
    'সাধারণ জ্ঞান (৫০০+ স্বতন্ত্র MCQ)': [{"q":"আফগানিস্তান-এর রাজধানী কোনটি?","options":["নমপেন","কাবুল","বাকু","ইয়েরেভান"],"answer":1,"explain":"সঠিক উত্তর: কাবুল।"},{"q":"আর্মেনিয়া-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","বাকু","নমপেন"],"answer":1,"explain":"সঠিক উত্তর: ইয়েরেভান।"},{"q":"আজারবাইজান-এর রাজধানী কোনটি?","options":["ইয়েরেভান","কাবুল","নমপেন","বাকু"],"answer":3,"explain":"সঠিক উত্তর: বাকু।"},{"q":"কম্বোডিয়া-এর রাজধানী কোনটি?","options":["বাকু","কাবুল","নমপেন","ইয়েরেভান"],"answer":2,"explain":"সঠিক উত্তর: নমপেন।"},{"q":"ভিয়েতনাম-এর রাজধানী কোনটি?","options":["ইয়েরেভান","বাকু","হ্যানয়","কাবুল"],"answer":2,"explain":"সঠিক উত্তর: হ্যানয়।"},{"q":"লাওস-এর রাজধানী কোনটি?","options":["ইয়েরেভান","ভিয়েনতিয়েন","কাবুল","বাকু"],"answer":1,"explain":"সঠিক উত্তর: ভিয়েনতিয়েন।"},{"q":"মিয়ানমার-এর রাজধানী কোনটি?","options":["কাবুল","বাকু","নেপিদো","ইয়েরেভান"],"answer":2,"explain":"সঠিক উত্তর: নেপিদো।"},{"q":"মঙ্গোলিয়া-এর রাজধানী কোনটি?","options":["ইয়েরেভান","বাকু","কাবুল","উলানবাটর"],"answer":3,"explain":"সঠিক উত্তর: উলানবাটর।"},{"q":"উজবেকিস্তান-এর রাজধানী কোনটি?","options":["বাকু","কাবুল","ইয়েরেভান","তাশখন্দ"],"answer":3,"explain":"সঠিক উত্তর: তাশখন্দ।"},{"q":"কাজাখস্তান-এর রাজধানী কোনটি?","options":["আস্তানা","ইয়েরেভান","বাকু","কাবুল"],"answer":0,"explain":"সঠিক উত্তর: আস্তানা।"},{"q":"কিরগিজস্তান-এর রাজধানী কোনটি?","options":["কাবুল","বাকু","বিশকেক","ইয়েরেভান"],"answer":2,"explain":"সঠিক উত্তর: বিশকেক।"},{"q":"তাজিকিস্তান-এর রাজধানী কোনটি?","options":["দুশানবে","কাবুল","ইয়েরেভান","বাকু"],"answer":0,"explain":"সঠিক উত্তর: দুশানবে।"},{"q":"তুর্কমেনিস্তান-এর রাজধানী কোনটি?","options":["ইয়েরেভান","আশখাবাদ","বাকু","কাবুল"],"answer":1,"explain":"সঠিক উত্তর: আশখাবাদ।"},{"q":"ইয়েমেন-এর রাজধানী কোনটি?","options":["বাকু","সানা","ইয়েরেভান","কাবুল"],"answer":1,"explain":"সঠিক উত্তর: সানা।"},{"q":"ওমান-এর রাজধানী কোনটি?","options":["মাস্কাট","কাবুল","বাকু","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: মাস্কাট।"},{"q":"জর্ডান-এর রাজধানী কোনটি?","options":["বাকু","কাবুল","আম্মান","ইয়েরেভান"],"answer":2,"explain":"সঠিক উত্তর: আম্মান।"},{"q":"লেবানন-এর রাজধানী কোনটি?","options":["বাকু","বৈরুত","ইয়েরেভান","কাবুল"],"answer":1,"explain":"সঠিক উত্তর: বৈরুত।"},{"q":"সিরিয়া-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","বাকু","দামেস্ক"],"answer":3,"explain":"সঠিক উত্তর: দামেস্ক।"},{"q":"ইসরায়েল-এর রাজধানী কোনটি?","options":["জেরুজালেম","ইয়েরেভান","কাবুল","বাকু"],"answer":0,"explain":"সঠিক উত্তর: জেরুজালেম।"},{"q":"সাইপ্রাস-এর রাজধানী কোনটি?","options":["ইয়েরেভান","বাকু","কাবুল","নিকোসিয়া"],"answer":3,"explain":"সঠিক উত্তর: নিকোসিয়া।"},{"q":"গ্রিস-এর রাজধানী কোনটি?","options":["কাবুল","এথেন্স","বাকু","ইয়েরেভান"],"answer":1,"explain":"সঠিক উত্তর: এথেন্স।"},{"q":"পর্তুগাল-এর রাজধানী কোনটি?","options":["ইয়েরেভান","বাকু","কাবুল","লিসবন"],"answer":3,"explain":"সঠিক উত্তর: লিসবন।"},{"q":"নেদারল্যান্ডস-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","আমস্টারডাম","বাকু"],"answer":2,"explain":"সঠিক উত্তর: আমস্টারডাম।"},{"q":"বেলজিয়াম-এর রাজধানী কোনটি?","options":["কাবুল","ব্রাসেলস","ইয়েরেভান","বাকু"],"answer":1,"explain":"সঠিক উত্তর: ব্রাসেলস।"},{"q":"সুইজারল্যান্ড-এর রাজধানী কোনটি?","options":["বাকু","বার্ন","ইয়েরেভান","কাবুল"],"answer":1,"explain":"সঠিক উত্তর: বার্ন।"},{"q":"অস্ট্রিয়া-এর রাজধানী কোনটি?","options":["কাবুল","বাকু","ইয়েরেভান","ভিয়েনা"],"answer":3,"explain":"সঠিক উত্তর: ভিয়েনা।"},{"q":"পোল্যান্ড-এর রাজধানী কোনটি?","options":["ইয়েরেভান","কাবুল","বাকু","ওয়ারশ"],"answer":3,"explain":"সঠিক উত্তর: ওয়ারশ।"},{"q":"চেকিয়া-এর রাজধানী কোনটি?","options":["প্রাগ","বাকু","কাবুল","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: প্রাগ।"},{"q":"স্লোভাকিয়া-এর রাজধানী কোনটি?","options":["ইয়েরেভান","ব্রাতিস্লাভা","বাকু","কাবুল"],"answer":1,"explain":"সঠিক উত্তর: ব্রাতিস্লাভা।"},{"q":"হাঙ্গেরি-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","বুদাপেস্ট","বাকু"],"answer":2,"explain":"সঠিক উত্তর: বুদাপেস্ট।"},{"q":"রোমানিয়া-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","বাকু","বুখারেস্ট"],"answer":3,"explain":"সঠিক উত্তর: বুখারেস্ট।"},{"q":"বুলগেরিয়া-এর রাজধানী কোনটি?","options":["সোফিয়া","বাকু","কাবুল","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: সোফিয়া।"},{"q":"সার্বিয়া-এর রাজধানী কোনটি?","options":["বেলগ্রেড","বাকু","কাবুল","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: বেলগ্রেড।"},{"q":"ক্রোয়েশিয়া-এর রাজধানী কোনটি?","options":["কাবুল","বাকু","ইয়েরেভান","জাগরেব"],"answer":3,"explain":"সঠিক উত্তর: জাগরেব।"},{"q":"স্লোভেনিয়া-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","লিউব্লিয়ানা","বাকু"],"answer":2,"explain":"সঠিক উত্তর: লিউব্লিয়ানা।"},{"q":"নরওয়ে-এর রাজধানী কোনটি?","options":["অসলো","ইয়েরেভান","বাকু","কাবুল"],"answer":0,"explain":"সঠিক উত্তর: অসলো।"},{"q":"সুইডেন-এর রাজধানী কোনটি?","options":["স্টকহোম","কাবুল","বাকু","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: স্টকহোম।"},{"q":"ফিনল্যান্ড-এর রাজধানী কোনটি?","options":["হেলসিংকি","কাবুল","বাকু","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: হেলসিংকি।"},{"q":"ডেনমার্ক-এর রাজধানী কোনটি?","options":["ইয়েরেভান","বাকু","কোপেনহেগেন","কাবুল"],"answer":2,"explain":"সঠিক উত্তর: কোপেনহেগেন।"},{"q":"আইসল্যান্ড-এর রাজধানী কোনটি?","options":["কাবুল","রেইকিয়াভিক","বাকু","ইয়েরেভান"],"answer":1,"explain":"সঠিক উত্তর: রেইকিয়াভিক।"},{"q":"আয়ারল্যান্ড-এর রাজধানী কোনটি?","options":["কাবুল","বাকু","ইয়েরেভান","ডাবলিন"],"answer":3,"explain":"সঠিক উত্তর: ডাবলিন।"},{"q":"ইউক্রেন-এর রাজধানী কোনটি?","options":["ইয়েরেভান","কিয়েভ","কাবুল","বাকু"],"answer":1,"explain":"সঠিক উত্তর: কিয়েভ।"},{"q":"বেলারুশ-এর রাজধানী কোনটি?","options":["মিনস্ক","ইয়েরেভান","কাবুল","বাকু"],"answer":0,"explain":"সঠিক উত্তর: মিনস্ক।"},{"q":"জর্জিয়া-এর রাজধানী কোনটি?","options":["তিবিলিসি","ইয়েরেভান","কাবুল","বাকু"],"answer":0,"explain":"সঠিক উত্তর: তিবিলিসি।"},{"q":"আলজেরিয়া-এর রাজধানী কোনটি?","options":["আলজিয়ার্স","কাবুল","বাকু","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: আলজিয়ার্স।"},{"q":"মরক্কো-এর রাজধানী কোনটি?","options":["রাবাত","কাবুল","বাকু","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: রাবাত।"},{"q":"তিউনিসিয়া-এর রাজধানী কোনটি?","options":["কাবুল","বাকু","তিউনিস","ইয়েরেভান"],"answer":2,"explain":"সঠিক উত্তর: তিউনিস।"},{"q":"লিবিয়া-এর রাজধানী কোনটি?","options":["ত্রিপোলি","কাবুল","বাকু","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: ত্রিপোলি।"},{"q":"ইথিওপিয়া-এর রাজধানী কোনটি?","options":["কাবুল","আদ্দিস আবাবা","বাকু","ইয়েরেভান"],"answer":1,"explain":"সঠিক উত্তর: আদ্দিস আবাবা।"},{"q":"ঘানা-এর রাজধানী কোনটি?","options":["বাকু","কাবুল","ইয়েরেভান","আক্রা"],"answer":3,"explain":"সঠিক উত্তর: আক্রা।"},{"q":"উগান্ডা-এর রাজধানী কোনটি?","options":["ইয়েরেভান","কাম্পালা","কাবুল","বাকু"],"answer":1,"explain":"সঠিক উত্তর: কাম্পালা।"},{"q":"তানজানিয়া-এর রাজধানী কোনটি?","options":["ইয়েরেভান","বাকু","দোদোমা","কাবুল"],"answer":2,"explain":"সঠিক উত্তর: দোদোমা।"},{"q":"রুয়ান্ডা-এর রাজধানী কোনটি?","options":["ইয়েরেভান","কাবুল","কিগালি","বাকু"],"answer":2,"explain":"সঠিক উত্তর: কিগালি।"},{"q":"সেনেগাল-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","বাকু","ডাকার"],"answer":3,"explain":"সঠিক উত্তর: ডাকার।"},{"q":"ক্যামেরুন-এর রাজধানী কোনটি?","options":["ইয়েরেভান","ইয়াউন্ডে","বাকু","কাবুল"],"answer":1,"explain":"সঠিক উত্তর: ইয়াউন্ডে।"},{"q":"অ্যাঙ্গোলা-এর রাজধানী কোনটি?","options":["ইয়েরেভান","লুয়ান্ডা","কাবুল","বাকু"],"answer":1,"explain":"সঠিক উত্তর: লুয়ান্ডা।"},{"q":"জাম্বিয়া-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","লুসাকা","বাকু"],"answer":2,"explain":"সঠিক উত্তর: লুসাকা।"},{"q":"জিম্বাবুয়ে-এর রাজধানী কোনটি?","options":["কাবুল","হারারে","ইয়েরেভান","বাকু"],"answer":1,"explain":"সঠিক উত্তর: হারারে।"},{"q":"মাদাগাস্কার-এর রাজধানী কোনটি?","options":["কাবুল","আন্তানানারিভো","ইয়েরেভান","বাকু"],"answer":1,"explain":"সঠিক উত্তর: আন্তানানারিভো।"},{"q":"পেরু-এর রাজধানী কোনটি?","options":["কাবুল","লিমা","ইয়েরেভান","বাকু"],"answer":1,"explain":"সঠিক উত্তর: লিমা।"},{"q":"চিলি-এর রাজধানী কোনটি?","options":["সান্তিয়াগো","ইয়েরেভান","বাকু","কাবুল"],"answer":0,"explain":"সঠিক উত্তর: সান্তিয়াগো।"},{"q":"আর্জেন্টিনা-এর রাজধানী কোনটি?","options":["কাবুল","বুয়েনস এইরেস","বাকু","ইয়েরেভান"],"answer":1,"explain":"সঠিক উত্তর: বুয়েনস এইরেস।"},{"q":"উরুগুয়ে-এর রাজধানী কোনটি?","options":["কাবুল","ইয়েরেভান","বাকু","মন্টেভিডিও"],"answer":3,"explain":"সঠিক উত্তর: মন্টেভিডিও।"},{"q":"প্যারাগুয়ে-এর রাজধানী কোনটি?","options":["কাবুল","বাকু","ইয়েরেভান","আসুনসিওন"],"answer":3,"explain":"সঠিক উত্তর: আসুনসিওন।"},{"q":"কলম্বিয়া-এর রাজধানী কোনটি?","options":["ইয়েরেভান","বাকু","কাবুল","বোগোতা"],"answer":3,"explain":"সঠিক উত্তর: বোগোতা।"},{"q":"ভেনেজুয়েলা-এর রাজধানী কোনটি?","options":["কারাকাস","কাবুল","বাকু","ইয়েরেভান"],"answer":0,"explain":"সঠিক উত্তর: কারাকাস।"},{"q":"কিউবা-এর রাজধানী কোনটি?","options":["হাভানা","ইয়েরেভান","বাকু","কাবুল"],"answer":0,"explain":"সঠিক উত্তর: হাভানা।"},{"q":"জ্যামাইকা-এর রাজধানী কোনটি?","options":["কাবুল","কিংস্টন","ইয়েরেভান","বাকু"],"answer":1,"explain":"সঠিক উত্তর: কিংস্টন।"},{"q":"মেক্সিকো-এর রাজধানী কোনটি?","options":["মেক্সিকো সিটি","বাকু","ইয়েরেভান","কাবুল"],"answer":0,"explain":"সঠিক উত্তর: মেক্সিকো সিটি।"},{"q":"পানামা-এর রাজধানী কোনটি?","options":["বাকু","পানামা সিটি","ইয়েরেভান","কাবুল"],"answer":1,"explain":"সঠিক উত্তর: পানামা সিটি।"},{"q":"কোস্টারিকা-এর রাজধানী কোনটি?","options":["সান হোসে","ইয়েরেভান","বাকু","কাবুল"],"answer":0,"explain":"সঠিক উত্তর: সান হোসে।"},{"q":"আফগানিস্তান-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","আফগানি","গুলট্রাম","রিয়েল"],"answer":1,"explain":"সঠিক উত্তর: আফগানি।"},{"q":"বাংলাদেশ-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","আফগানি","গুলট্রাম","রিয়েল"],"answer":0,"explain":"সঠিক উত্তর: টাকা।"},{"q":"ভুটান-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","রিয়েল","টাকা","গুলট্রাম"],"answer":3,"explain":"সঠিক উত্তর: গুলট্রাম।"},{"q":"কম্বোডিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","আফগানি","গুলট্রাম","রিয়েল"],"answer":3,"explain":"সঠিক উত্তর: রিয়েল।"},{"q":"ভিয়েতনাম-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","ডং","টাকা"],"answer":2,"explain":"সঠিক উত্তর: ডং।"},{"q":"লাওস-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","কিপ","টাকা"],"answer":2,"explain":"সঠিক উত্তর: কিপ।"},{"q":"মিয়ানমার-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","টাকা","কিয়াত"],"answer":3,"explain":"সঠিক উত্তর: কিয়াত।"},{"q":"মঙ্গোলিয়া-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","তুগরিক","টাকা"],"answer":2,"explain":"সঠিক উত্তর: তুগরিক।"},{"q":"উজবেকিস্তান-এর সরকারি মুদ্রার নাম কী?","options":["সোম","টাকা","গুলট্রাম","আফগানি"],"answer":0,"explain":"সঠিক উত্তর: সোম।"},{"q":"কাজাখস্তান-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","টেঙ্গে","টাকা"],"answer":2,"explain":"সঠিক উত্তর: টেঙ্গে।"},{"q":"কিরগিজস্তান-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","টাকা","সোম"],"answer":3,"explain":"সঠিক উত্তর: সোম।"},{"q":"তাজিকিস্তান-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","সোমনি","আফগানি","গুলট্রাম"],"answer":1,"explain":"সঠিক উত্তর: সোমনি।"},{"q":"তুর্কমেনিস্তান-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","টাকা","গুলট্রাম","মানাত"],"answer":3,"explain":"সঠিক উত্তর: মানাত।"},{"q":"ইয়েমেন-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","আফগানি","রিয়াল","গুলট্রাম"],"answer":2,"explain":"সঠিক উত্তর: রিয়াল।"},{"q":"ওমান-এর সরকারি মুদ্রার নাম কী?","options":["ওমানি রিয়াল","আফগানি","টাকা","গুলট্রাম"],"answer":0,"explain":"সঠিক উত্তর: ওমানি রিয়াল।"},{"q":"জর্ডান-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","জর্ডানিয়ান দিনার","গুলট্রাম","আফগানি"],"answer":1,"explain":"সঠিক উত্তর: জর্ডানিয়ান দিনার।"},{"q":"লেবানন-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","লেবানিজ পাউন্ড","টাকা","আফগানি"],"answer":1,"explain":"সঠিক উত্তর: লেবানিজ পাউন্ড।"},{"q":"ইসরায়েল-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","গুলট্রাম","নিউ শেকেল","আফগানি"],"answer":2,"explain":"সঠিক উত্তর: নিউ শেকেল।"},{"q":"তুরস্ক-এর সরকারি মুদ্রার নাম কী?","options":["তুর্কি লিরা","আফগানি","টাকা","গুলট্রাম"],"answer":0,"explain":"সঠিক উত্তর: তুর্কি লিরা।"},{"q":"ইরান-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","টাকা","রিয়াল","গুলট্রাম"],"answer":2,"explain":"সঠিক উত্তর: রিয়াল।"},{"q":"ইরাক-এর সরকারি মুদ্রার নাম কী?","options":["ইরাকি দিনার","আফগানি","টাকা","গুলট্রাম"],"answer":0,"explain":"সঠিক উত্তর: ইরাকি দিনার।"},{"q":"মিশর-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","টাকা","মিশরীয় পাউন্ড","গুলট্রাম"],"answer":2,"explain":"সঠিক উত্তর: মিশরীয় পাউন্ড।"},{"q":"দক্ষিণ আফ্রিকা-এর সরকারি মুদ্রার নাম কী?","options":["র‍্যান্ড","গুলট্রাম","আফগানি","টাকা"],"answer":0,"explain":"সঠিক উত্তর: র‍্যান্ড।"},{"q":"ঘানা-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","টাকা","সেডি"],"answer":3,"explain":"সঠিক উত্তর: সেডি।"},{"q":"নাইজেরিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","আফগানি","নাইরা","গুলট্রাম"],"answer":2,"explain":"সঠিক উত্তর: নাইরা।"},{"q":"কেনিয়া-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","কেনিয়ান শিলিং","টাকা"],"answer":2,"explain":"সঠিক উত্তর: কেনিয়ান শিলিং।"},{"q":"উগান্ডা-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","উগান্ডান শিলিং","টাকা","গুলট্রাম"],"answer":1,"explain":"সঠিক উত্তর: উগান্ডান শিলিং।"},{"q":"তানজানিয়া-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","টাকা","তানজানিয়ান শিলিং","গুলট্রাম"],"answer":2,"explain":"সঠিক উত্তর: তানজানিয়ান শিলিং।"},{"q":"ইথিওপিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","বির","গুলট্রাম","আফগানি"],"answer":1,"explain":"সঠিক উত্তর: বির।"},{"q":"মরক্কো-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","টাকা","দিরহাম","গুলট্রাম"],"answer":2,"explain":"সঠিক উত্তর: দিরহাম।"},{"q":"আলজেরিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","দিনার","আফগানি","গুলট্রাম"],"answer":1,"explain":"সঠিক উত্তর: দিনার।"},{"q":"তিউনিসিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","দিনার","আফগানি","গুলট্রাম"],"answer":1,"explain":"সঠিক উত্তর: দিনার।"},{"q":"লিবিয়া-এর সরকারি মুদ্রার নাম কী?","options":["দিনার","আফগানি","গুলট্রাম","টাকা"],"answer":0,"explain":"সঠিক উত্তর: দিনার।"},{"q":"সেনেগাল-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","আফগানি","গুলট্রাম","পশ্চিম আফ্রিকান CFA ফ্রাঁ"],"answer":3,"explain":"সঠিক উত্তর: পশ্চিম আফ্রিকান CFA ফ্রাঁ।"},{"q":"ক্যামেরুন-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","মধ্য আফ্রিকান CFA ফ্রাঁ","টাকা"],"answer":2,"explain":"সঠিক উত্তর: মধ্য আফ্রিকান CFA ফ্রাঁ।"},{"q":"অ্যাঙ্গোলা-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","গুলট্রাম","কোয়ানজা","আফগানি"],"answer":2,"explain":"সঠিক উত্তর: কোয়ানজা।"},{"q":"জাম্বিয়া-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","কওয়াচা","টাকা"],"answer":2,"explain":"সঠিক উত্তর: কওয়াচা।"},{"q":"জিম্বাবুয়ে-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","টাকা","আফগানি","জিম্বাবুয়ে গোল্ড"],"answer":3,"explain":"সঠিক উত্তর: জিম্বাবুয়ে গোল্ড।"},{"q":"মাদাগাস্কার-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","আরিয়ারি","গুলট্রাম","টাকা"],"answer":1,"explain":"সঠিক উত্তর: আরিয়ারি।"},{"q":"অস্ট্রেলিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","গুলট্রাম","আফগানি","অস্ট্রেলীয় ডলার"],"answer":3,"explain":"সঠিক উত্তর: অস্ট্রেলীয় ডলার।"},{"q":"নিউজিল্যান্ড-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","টাকা","নিউজিল্যান্ড ডলার"],"answer":3,"explain":"সঠিক উত্তর: নিউজিল্যান্ড ডলার।"},{"q":"কানাডা-এর সরকারি মুদ্রার নাম কী?","options":["কানাডীয় ডলার","টাকা","আফগানি","গুলট্রাম"],"answer":0,"explain":"সঠিক উত্তর: কানাডীয় ডলার।"},{"q":"যুক্তরাষ্ট্র-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","মার্কিন ডলার","টাকা"],"answer":2,"explain":"সঠিক উত্তর: মার্কিন ডলার।"},{"q":"মেক্সিকো-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","টাকা","আফগানি","মেক্সিকান পেসো"],"answer":3,"explain":"সঠিক উত্তর: মেক্সিকান পেসো।"},{"q":"ব্রাজিল-এর সরকারি মুদ্রার নাম কী?","options":["ব্রাজিলীয় রিয়াল","আফগানি","টাকা","গুলট্রাম"],"answer":0,"explain":"সঠিক উত্তর: ব্রাজিলীয় রিয়াল।"},{"q":"আর্জেন্টিনা-এর সরকারি মুদ্রার নাম কী?","options":["আর্জেন্টাইন পেসো","গুলট্রাম","টাকা","আফগানি"],"answer":0,"explain":"সঠিক উত্তর: আর্জেন্টাইন পেসো।"},{"q":"চিলি-এর সরকারি মুদ্রার নাম কী?","options":["চিলিয়ান পেসো","আফগানি","গুলট্রাম","টাকা"],"answer":0,"explain":"সঠিক উত্তর: চিলিয়ান পেসো।"},{"q":"পেরু-এর সরকারি মুদ্রার নাম কী?","options":["সোল","আফগানি","টাকা","গুলট্রাম"],"answer":0,"explain":"সঠিক উত্তর: সোল।"},{"q":"কলম্বিয়া-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","কলম্বীয় পেসো","টাকা","গুলট্রাম"],"answer":1,"explain":"সঠিক উত্তর: কলম্বীয় পেসো।"},{"q":"রাশিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","রুবল","আফগানি","গুলট্রাম"],"answer":1,"explain":"সঠিক উত্তর: রুবল।"},{"q":"ইউক্রেন-এর সরকারি মুদ্রার নাম কী?","options":["হৃভনিয়া","গুলট্রাম","টাকা","আফগানি"],"answer":0,"explain":"সঠিক উত্তর: হৃভনিয়া।"},{"q":"পোল্যান্ড-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","জ্লোটি","টাকা","আফগানি"],"answer":1,"explain":"সঠিক উত্তর: জ্লোটি।"},{"q":"চেকিয়া-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","চেক কোরুনা","গুলট্রাম","টাকা"],"answer":1,"explain":"সঠিক উত্তর: চেক কোরুনা।"},{"q":"হাঙ্গেরি-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","ফরিন্ট","আফগানি","টাকা"],"answer":1,"explain":"সঠিক উত্তর: ফরিন্ট।"},{"q":"রোমানিয়া-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","লেউ","গুলট্রাম","টাকা"],"answer":1,"explain":"সঠিক উত্তর: লেউ।"},{"q":"সুইডেন-এর সরকারি মুদ্রার নাম কী?","options":["সুইডিশ ক্রোনা","গুলট্রাম","টাকা","আফগানি"],"answer":0,"explain":"সঠিক উত্তর: সুইডিশ ক্রোনা।"},{"q":"নরওয়ে-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","নরওয়েজীয় ক্রোন","টাকা","আফগানি"],"answer":1,"explain":"সঠিক উত্তর: নরওয়েজীয় ক্রোন।"},{"q":"ডেনমার্ক-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","টাকা","ড্যানিশ ক্রোন"],"answer":3,"explain":"সঠিক উত্তর: ড্যানিশ ক্রোন।"},{"q":"সুইজারল্যান্ড-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","গুলট্রাম","সুইস ফ্রাঁ","আফগানি"],"answer":2,"explain":"সঠিক উত্তর: সুইস ফ্রাঁ।"},{"q":"সিঙ্গাপুর-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","টাকা","সিঙ্গাপুর ডলার"],"answer":3,"explain":"সঠিক উত্তর: সিঙ্গাপুর ডলার।"},{"q":"মালয়েশিয়া-এর সরকারি মুদ্রার নাম কী?","options":["রিঙ্গিত","গুলট্রাম","টাকা","আফগানি"],"answer":0,"explain":"সঠিক উত্তর: রিঙ্গিত।"},{"q":"ইন্দোনেশিয়া-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","রুপিয়াহ","আফগানি","টাকা"],"answer":1,"explain":"সঠিক উত্তর: রুপিয়াহ।"},{"q":"ফিলিপাইন-এর সরকারি মুদ্রার নাম কী?","options":["পেসো","আফগানি","গুলট্রাম","টাকা"],"answer":0,"explain":"সঠিক উত্তর: পেসো।"},{"q":"থাইল্যান্ড-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","গুলট্রাম","আফগানি","বাত"],"answer":3,"explain":"সঠিক উত্তর: বাত।"},{"q":"দক্ষিণ কোরিয়া-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","ওন","গুলট্রাম","আফগানি"],"answer":1,"explain":"সঠিক উত্তর: ওন।"},{"q":"জাপান-এর সরকারি মুদ্রার নাম কী?","options":["টাকা","আফগানি","গুলট্রাম","ইয়েন"],"answer":3,"explain":"সঠিক উত্তর: ইয়েন।"},{"q":"চীন-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","ইউয়ান","গুলট্রাম","টাকা"],"answer":1,"explain":"সঠিক উত্তর: ইউয়ান।"},{"q":"ভারত-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","আফগানি","টাকা","রুপি"],"answer":3,"explain":"সঠিক উত্তর: রুপি।"},{"q":"নেপাল-এর সরকারি মুদ্রার নাম কী?","options":["আফগানি","গুলট্রাম","নেপালি রুপি","টাকা"],"answer":2,"explain":"সঠিক উত্তর: নেপালি রুপি।"},{"q":"শ্রীলঙ্কা-এর সরকারি মুদ্রার নাম কী?","options":["শ্রীলঙ্কান রুপি","গুলট্রাম","আফগানি","টাকা"],"answer":0,"explain":"সঠিক উত্তর: শ্রীলঙ্কান রুপি।"},{"q":"মালদ্বীপ-এর সরকারি মুদ্রার নাম কী?","options":["গুলট্রাম","রুফিয়া","টাকা","আফগানি"],"answer":1,"explain":"সঠিক উত্তর: রুফিয়া।"},{"q":"বিশ্ব বাণিজ্য সংস্থার (WTO) সদর দপ্তর—সঠিক উত্তর কোনটি?","options":["জেনেভা","লুজান","জুরিখ","রোম"],"answer":0,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"জাতিসংঘের শরণার্থী সংস্থা (UNHCR)-এর সদর দপ্তর—সঠিক উত্তর কোনটি?","options":["রোম","লুজান","জুরিখ","জেনেভা"],"answer":3,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"আন্তর্জাতিক রেড ক্রস কমিটির সদর দপ্তর—সঠিক উত্তর কোনটি?","options":["রোম","লুজান","জুরিখ","জেনেভা"],"answer":3,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"বিশ্ব আবহাওয়া সংস্থার সদর দপ্তর—সঠিক উত্তর কোনটি?","options":["জুরিখ","লুজান","জেনেভা","রোম"],"answer":2,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"বিশ্ব মেধাস্বত্ব সংস্থার সদর দপ্তর—সঠিক উত্তর কোনটি?","options":["লুজান","জুরিখ","জেনেভা","রোম"],"answer":2,"explain":"সঠিক উত্তর: জেনেভা।"},{"q":"বাংলাদেশের প্রধান নদী ব্যবস্থার একটি কোথায়/কী?","options":["যমুনা","ময়মনসিংহ","ডালিয়ায়","গঙ্গা-পদ্মা"],"answer":3,"explain":"সঠিক উত্তর: গঙ্গা-পদ্মা।"},{"q":"ব্রহ্মপুত্রের বাংলাদেশ অংশের পুরোনো প্রবাহের নাম কোথায়/কী?","options":["গঙ্গা-পদ্মা","ডালিয়ায়","ময়মনসিংহ","যমুনা"],"answer":3,"explain":"সঠিক উত্তর: যমুনা।"},{"q":"পুরাতন ব্রহ্মপুত্র প্রবাহের তীরবর্তী শহর কোথায়/কী?","options":["গঙ্গা-পদ্মা","ডালিয়ায়","যমুনা","ময়মনসিংহ"],"answer":3,"explain":"সঠিক উত্তর: ময়মনসিংহ।"},{"q":"তিস্তা ব্যারাজ অবস্থিত কোথায়/কী?","options":["ময়মনসিংহ","যমুনা","ডালিয়ায়","গঙ্গা-পদ্মা"],"answer":2,"explain":"সঠিক উত্তর: ডালিয়ায়।"},{"q":"গঙ্গা নদী বাংলাদেশে প্রবেশের পর পরিচিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","পদ্মা নামে","যমুনা","ময়মনসিংহ"],"answer":1,"explain":"সঠিক উত্তর: পদ্মা নামে।"},{"q":"বরাক নদী বাংলাদেশে প্রবেশ করে কোথায়/কী?","options":["ময়মনসিংহ","গঙ্গা-পদ্মা","যমুনা","সুরমা ও কুশিয়ারা নামে"],"answer":3,"explain":"সঠিক উত্তর: সুরমা ও কুশিয়ারা নামে।"},{"q":"সুরমা নদীর তীরবর্তী শহর কোথায়/কী?","options":["ময়মনসিংহ","যমুনা","গঙ্গা-পদ্মা","সিলেট"],"answer":3,"explain":"সঠিক উত্তর: সিলেট।"},{"q":"কর্ণফুলী নদীর মোহনায় অবস্থিত বন্দর কোথায়/কী?","options":["ময়মনসিংহ","যমুনা","গঙ্গা-পদ্মা","চট্টগ্রাম বন্দর"],"answer":3,"explain":"সঠিক উত্তর: চট্টগ্রাম বন্দর।"},{"q":"রূপসা নদীর তীরবর্তী শহর কোথায়/কী?","options":["ময়মনসিংহ","গঙ্গা-পদ্মা","খুলনা","যমুনা"],"answer":2,"explain":"সঠিক উত্তর: খুলনা।"},{"q":"বুড়িগঙ্গা নদীর তীরে অবস্থিত কোথায়/কী?","options":["ঢাকা","যমুনা","ময়মনসিংহ","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: ঢাকা।"},{"q":"শীতলক্ষ্যা নদীর তীরে অবস্থিত শিল্পনগরী কোথায়/কী?","options":["ময়মনসিংহ","গঙ্গা-পদ্মা","যমুনা","নারায়ণগঞ্জ"],"answer":3,"explain":"সঠিক উত্তর: নারায়ণগঞ্জ।"},{"q":"ধলেশ্বরী নদী কোন নদী ব্যবস্থার অংশ কোথায়/কী?","options":["গঙ্গা-পদ্মা","ময়মনসিংহ","যমুনা","যমুনা-পদ্মা"],"answer":3,"explain":"সঠিক উত্তর: যমুনা-পদ্মা।"},{"q":"মধুমতি নদী কোন অঞ্চলে প্রবাহিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","যমুনা","দক্ষিণ-পশ্চিম বাংলাদেশ","ময়মনসিংহ"],"answer":2,"explain":"সঠিক উত্তর: দক্ষিণ-পশ্চিম বাংলাদেশ।"},{"q":"আত্রাই নদী প্রবাহিত হয় কোথায়/কী?","options":["উত্তর-পশ্চিম বাংলাদেশে","ময়মনসিংহ","গঙ্গা-পদ্মা","যমুনা"],"answer":0,"explain":"সঠিক উত্তর: উত্তর-পশ্চিম বাংলাদেশে।"},{"q":"সাঙ্গু নদী প্রবাহিত হয় কোথায়/কী?","options":["ময়মনসিংহ","বান্দরবান ও চট্টগ্রামে","গঙ্গা-পদ্মা","যমুনা"],"answer":1,"explain":"সঠিক উত্তর: বান্দরবান ও চট্টগ্রামে।"},{"q":"মাতামুহুরী নদী প্রবাহিত হয় কোথায়/কী?","options":["কক্সবাজার অঞ্চলে","যমুনা","ময়মনসিংহ","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: কক্সবাজার অঞ্চলে।"},{"q":"হালদা নদী বিখ্যাত কোথায়/কী?","options":["যমুনা","প্রাকৃতিক মৎস্য প্রজনন ক্ষেত্র হিসেবে","গঙ্গা-পদ্মা","ময়মনসিংহ"],"answer":1,"explain":"সঠিক উত্তর: প্রাকৃতিক মৎস্য প্রজনন ক্ষেত্র হিসেবে।"},{"q":"বাংলাদেশের বৃহত্তম হাওর কোথায়/কী?","options":["গঙ্গা-পদ্মা","ময়মনসিংহ","যমুনা","হাকালুকি হাওর"],"answer":3,"explain":"সঠিক উত্তর: হাকালুকি হাওর।"},{"q":"হাকালুকি হাওর অবস্থিত কোথায়/কী?","options":["যমুনা","মৌলভীবাজার ও সিলেটে","গঙ্গা-পদ্মা","ময়মনসিংহ"],"answer":1,"explain":"সঠিক উত্তর: মৌলভীবাজার ও সিলেটে।"},{"q":"বাইক্কা বিল অবস্থিত কোথায়/কী?","options":["যমুনা","গঙ্গা-পদ্মা","ময়মনসিংহ","শ্রীমঙ্গলে"],"answer":3,"explain":"সঠিক উত্তর: শ্রীমঙ্গলে।"},{"q":"নিঝুম দ্বীপ অবস্থিত কোথায়/কী?","options":["নোয়াখালীতে","যমুনা","গঙ্গা-পদ্মা","ময়মনসিংহ"],"answer":0,"explain":"সঠিক উত্তর: নোয়াখালীতে।"},{"q":"কুতুবদিয়া দ্বীপ অবস্থিত কোথায়/কী?","options":["ময়মনসিংহ","কক্সবাজার জেলায়","গঙ্গা-পদ্মা","যমুনা"],"answer":1,"explain":"সঠিক উত্তর: কক্সবাজার জেলায়।"},{"q":"মহেশখালী দ্বীপ অবস্থিত কোথায়/কী?","options":["ময়মনসিংহ","কক্সবাজার জেলায়","গঙ্গা-পদ্মা","যমুনা"],"answer":1,"explain":"সঠিক উত্তর: কক্সবাজার জেলায়।"},{"q":"সোনাদিয়া দ্বীপ অবস্থিত কোথায়/কী?","options":["মহেশখালী, কক্সবাজারে","যমুনা","ময়মনসিংহ","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: মহেশখালী, কক্সবাজারে।"},{"q":"বাংলাদেশের বৃহত্তম কৃত্রিম হ্রদ কোথায়/কী?","options":["গঙ্গা-পদ্মা","ময়মনসিংহ","কাপ্তাই হ্রদ","যমুনা"],"answer":2,"explain":"সঠিক উত্তর: কাপ্তাই হ্রদ।"},{"q":"মাধবকুণ্ড জলপ্রপাত অবস্থিত কোথায়/কী?","options":["মৌলভীবাজারে","গঙ্গা-পদ্মা","যমুনা","ময়মনসিংহ"],"answer":0,"explain":"সঠিক উত্তর: মৌলভীবাজারে।"},{"q":"নাফ নদী বাংলাদেশকে পৃথক করেছে কোথায়/কী?","options":["গঙ্গা-পদ্মা","ময়মনসিংহ","মিয়ানমার থেকে","যমুনা"],"answer":2,"explain":"সঠিক উত্তর: মিয়ানমার থেকে।"},{"q":"বাংলাদেশের দক্ষিণে অবস্থিত সাগর কোথায়/কী?","options":["বঙ্গোপসাগর","গঙ্গা-পদ্মা","ময়মনসিংহ","যমুনা"],"answer":0,"explain":"সঠিক উত্তর: বঙ্গোপসাগর।"},{"q":"বাংলাদেশের একমাত্র পাহাড়ি দ্বীপ কোথায়/কী?","options":["যমুনা","ময়মনসিংহ","মহেশখালী","গঙ্গা-পদ্মা"],"answer":2,"explain":"সঠিক উত্তর: মহেশখালী।"},{"q":"রাতারগুল জলাবন অবস্থিত কোথায়/কী?","options":["যমুনা","ময়মনসিংহ","সিলেটে","গঙ্গা-পদ্মা"],"answer":2,"explain":"সঠিক উত্তর: সিলেটে।"},{"q":"লাউয়াছড়া জাতীয় উদ্যান অবস্থিত কোথায়/কী?","options":["মৌলভীবাজারে","ময়মনসিংহ","গঙ্গা-পদ্মা","যমুনা"],"answer":0,"explain":"সঠিক উত্তর: মৌলভীবাজারে।"},{"q":"ভাওয়াল জাতীয় উদ্যান অবস্থিত কোথায়/কী?","options":["ময়মনসিংহ","গাজীপুরে","গঙ্গা-পদ্মা","যমুনা"],"answer":1,"explain":"সঠিক উত্তর: গাজীপুরে।"},{"q":"মধুপুর গড় অবস্থিত কোথায়/কী?","options":["টাঙ্গাইল ও ময়মনসিংহ অঞ্চলে","যমুনা","ময়মনসিংহ","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: টাঙ্গাইল ও ময়মনসিংহ অঞ্চলে।"},{"q":"বরেন্দ্রভূমি প্রধানত অবস্থিত কোথায়/কী?","options":["রাজশাহী অঞ্চলে","যমুনা","ময়মনসিংহ","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: রাজশাহী অঞ্চলে।"},{"q":"লালমাই পাহাড় অবস্থিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","ময়মনসিংহ","কুমিল্লায়","যমুনা"],"answer":2,"explain":"সঠিক উত্তর: কুমিল্লায়।"},{"q":"চিম্বুক পাহাড় অবস্থিত কোথায়/কী?","options":["যমুনা","বান্দরবানে","গঙ্গা-পদ্মা","ময়মনসিংহ"],"answer":1,"explain":"সঠিক উত্তর: বান্দরবানে।"},{"q":"নীলগিরি পর্যটনকেন্দ্র অবস্থিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","যমুনা","বান্দরবানে","ময়মনসিংহ"],"answer":2,"explain":"সঠিক উত্তর: বান্দরবানে।"},{"q":"কেওক্রাডং অবস্থিত কোথায়/কী?","options":["যমুনা","ময়মনসিংহ","বান্দরবানে","গঙ্গা-পদ্মা"],"answer":2,"explain":"সঠিক উত্তর: বান্দরবানে।"},{"q":"বাংলাদেশের বৃহত্তম গ্যাসক্ষেত্র কোথায়/কী?","options":["যমুনা","গঙ্গা-পদ্মা","তিতাস","ময়মনসিংহ"],"answer":2,"explain":"সঠিক উত্তর: তিতাস।"},{"q":"তিতাস গ্যাসক্ষেত্র অবস্থিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","যমুনা","ময়মনসিংহ","ব্রাহ্মণবাড়িয়ায়"],"answer":3,"explain":"সঠিক উত্তর: ব্রাহ্মণবাড়িয়ায়।"},{"q":"বাখরাবাদ গ্যাসক্ষেত্র অবস্থিত কোথায়/কী?","options":["কুমিল্লায়","ময়মনসিংহ","গঙ্গা-পদ্মা","যমুনা"],"answer":0,"explain":"সঠিক উত্তর: কুমিল্লায়।"},{"q":"রামপাল বিদ্যুৎকেন্দ্র অবস্থিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","যমুনা","ময়মনসিংহ","বাগেরহাটে"],"answer":3,"explain":"সঠিক উত্তর: বাগেরহাটে।"},{"q":"পায়রা সমুদ্রবন্দর অবস্থিত কোথায়/কী?","options":["ময়মনসিংহ","পটুয়াখালীতে","যমুনা","গঙ্গা-পদ্মা"],"answer":1,"explain":"সঠিক উত্তর: পটুয়াখালীতে।"},{"q":"মোংলা সমুদ্রবন্দর অবস্থিত কোথায়/কী?","options":["বাগেরহাটে","যমুনা","ময়মনসিংহ","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: বাগেরহাটে।"},{"q":"বাংলাদেশের প্রথম EPZ কোথায়/কী?","options":["চট্টগ্রাম EPZ","গঙ্গা-পদ্মা","যমুনা","ময়মনসিংহ"],"answer":0,"explain":"সঠিক উত্তর: চট্টগ্রাম EPZ।"},{"q":"বাংলাদেশের প্রথম কাগজকল কোথায়/কী?","options":["কর্ণফুলী পেপার মিলস","ময়মনসিংহ","যমুনা","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: কর্ণফুলী পেপার মিলস।"},{"q":"বাংলাদেশের প্রথম বিশ্ববিদ্যালয় কোথায়/কী?","options":["যমুনা","গঙ্গা-পদ্মা","ঢাকা বিশ্ববিদ্যালয়","ময়মনসিংহ"],"answer":2,"explain":"সঠিক উত্তর: ঢাকা বিশ্ববিদ্যালয়।"},{"q":"বাংলাদেশের প্রথম মেডিকেল কলেজ কোথায়/কী?","options":["ঢাকা মেডিকেল কলেজ","গঙ্গা-পদ্মা","ময়মনসিংহ","যমুনা"],"answer":0,"explain":"সঠিক উত্তর: ঢাকা মেডিকেল কলেজ।"},{"q":"বাংলাদেশের জাতীয় জাদুঘর অবস্থিত কোথায়/কী?","options":["শাহবাগে","যমুনা","গঙ্গা-পদ্মা","ময়মনসিংহ"],"answer":0,"explain":"সঠিক উত্তর: শাহবাগে।"},{"q":"বাংলাদেশের জাতীয় সংসদ ভবনের স্থপতি কোথায়/কী?","options":["লুই আই কান","ময়মনসিংহ","যমুনা","গঙ্গা-পদ্মা"],"answer":0,"explain":"সঠিক উত্তর: লুই আই কান।"},{"q":"জাতীয় সংসদ ভবন অবস্থিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","যমুনা","শেরেবাংলা নগরে","ময়মনসিংহ"],"answer":2,"explain":"সঠিক উত্তর: শেরেবাংলা নগরে।"},{"q":"কেন্দ্রীয় শহীদ মিনারের স্থপতি কোথায়/কী?","options":["যমুনা","হামিদুর রহমান","গঙ্গা-পদ্মা","ময়মনসিংহ"],"answer":1,"explain":"সঠিক উত্তর: হামিদুর রহমান।"},{"q":"অপরাজেয় বাংলা ভাস্কর্যের ভাস্কর কোথায়/কী?","options":["সৈয়দ আবদুল্লাহ খালিদ","ময়মনসিংহ","গঙ্গা-পদ্মা","যমুনা"],"answer":0,"explain":"সঠিক উত্তর: সৈয়দ আবদুল্লাহ খালিদ।"},{"q":"স্বাধীনতা স্তম্ভ অবস্থিত কোথায়/কী?","options":["ময়মনসিংহ","সোহরাওয়ার্দী উদ্যানে","যমুনা","গঙ্গা-পদ্মা"],"answer":1,"explain":"সঠিক উত্তর: সোহরাওয়ার্দী উদ্যানে।"},{"q":"বাংলাদেশের বৃহত্তম স্থলবন্দর কোথায়/কী?","options":["গঙ্গা-পদ্মা","বেনাপোল","ময়মনসিংহ","যমুনা"],"answer":1,"explain":"সঠিক উত্তর: বেনাপোল।"},{"q":"বেনাপোল স্থলবন্দর অবস্থিত কোথায়/কী?","options":["গঙ্গা-পদ্মা","যমুনা","যশোরে","ময়মনসিংহ"],"answer":2,"explain":"সঠিক উত্তর: যশোরে।"},{"q":"বাংলাদেশের চা রাজধানী বলা হয় কোথায়/কী?","options":["যমুনা","গঙ্গা-পদ্মা","ময়মনসিংহ","শ্রীমঙ্গলকে"],"answer":3,"explain":"সঠিক উত্তর: শ্রীমঙ্গলকে।"},{"q":"বাংলাদেশের রেশম নগরী বলা হয় কোথায়/কী?","options":["গঙ্গা-পদ্মা","রাজশাহীকে","যমুনা","ময়মনসিংহ"],"answer":1,"explain":"সঠিক উত্তর: রাজশাহীকে।"},{"q":"বাংলাদেশের মৎস্য গবেষণা ইনস্টিটিউটের সদর দপ্তর কোথায়/কী?","options":["গঙ্গা-পদ্মা","যমুনা","ময়মনসিংহ","ময়মনসিংহে"],"answer":3,"explain":"সঠিক উত্তর: ময়মনসিংহে।"},{"q":"বাংলাদেশের কৃষি বিশ্ববিদ্যালয় অবস্থিত কোথায়/কী?","options":["যমুনা","ময়মনসিংহে","গঙ্গা-পদ্মা","ময়মনসিংহ"],"answer":1,"explain":"সঠিক উত্তর: ময়মনসিংহে।"},{"q":"বাংলাদেশের প্রথম কৃত্রিম উপগ্রহ কোথায়/কী?","options":["যমুনা","ময়মনসিংহ","বঙ্গবন্ধু স্যাটেলাইট-১","গঙ্গা-পদ্মা"],"answer":2,"explain":"সঠিক উত্তর: বঙ্গবন্ধু স্যাটেলাইট-১।"},{"q":"বঙ্গবন্ধু স্যাটেলাইট-১ উৎক্ষেপণ করা হয় কোথায়/কী?","options":["ময়মনসিংহ","গঙ্গা-পদ্মা","যমুনা","২০১৮ সালে"],"answer":3,"explain":"সঠিক উত্তর: ২০১৮ সালে।"},{"q":"বাংলাদেশের প্রথম মেট্রোরেল চালু হয় কোথায়/কী?","options":["গঙ্গা-পদ্মা","ময়মনসিংহ","ঢাকায়","যমুনা"],"answer":2,"explain":"সঠিক উত্তর: ঢাকায়।"},{"q":"বাংলাদেশের প্রথম পারমাণবিক বিদ্যুৎকেন্দ্র কোথায়/কী?","options":["যমুনা","রূপপুর","ময়মনসিংহ","গঙ্গা-পদ্মা"],"answer":1,"explain":"সঠিক উত্তর: রূপপুর।"},{"q":"কপালকুণ্ডলা উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","মানিক বন্দ্যোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: বঙ্কিমচন্দ্র চট্টোপাধ্যায়।"},{"q":"আনন্দমঠ উপন্যাসের রচয়িতা কার লেখা?","options":["মানিক বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: বঙ্কিমচন্দ্র চট্টোপাধ্যায়।"},{"q":"দেবদাস উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","মানিক বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: শরৎচন্দ্র চট্টোপাধ্যায়।"},{"q":"শ্রীকান্ত উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","মানিক বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: শরৎচন্দ্র চট্টোপাধ্যায়।"},{"q":"পথের পাঁচালী উপন্যাসের রচয়িতা কার লেখা?","options":["মানিক বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":3,"explain":"সঠিক উত্তর: বিভূতিভূষণ বন্দ্যোপাধ্যায়।"},{"q":"অপরাজিত উপন্যাসের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","মানিক বন্দ্যোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: বিভূতিভূষণ বন্দ্যোপাধ্যায়।"},{"q":"আরণ্যক উপন্যাসের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","মানিক বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":3,"explain":"সঠিক উত্তর: বিভূতিভূষণ বন্দ্যোপাধ্যায়।"},{"q":"পদ্মা নদীর মাঝি উপন্যাসের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","মানিক বন্দ্যোপাধ্যায়"],"answer":3,"explain":"সঠিক উত্তর: মানিক বন্দ্যোপাধ্যায়।"},{"q":"পুতুলনাচের ইতিকথা উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","মানিক বন্দ্যোপাধ্যায়"],"answer":3,"explain":"সঠিক উত্তর: মানিক বন্দ্যোপাধ্যায়।"},{"q":"লালসালু উপন্যাসের রচয়িতা কার লেখা?","options":["সৈয়দ ওয়ালীউল্লাহ","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: সৈয়দ ওয়ালীউল্লাহ।"},{"q":"চাঁদের অমাবস্যা উপন্যাসের রচয়িতা কার লেখা?","options":["সৈয়দ ওয়ালীউল্লাহ","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: সৈয়দ ওয়ালীউল্লাহ।"},{"q":"হাজার বছর ধরে উপন্যাসের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","জহির রায়হান","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: জহির রায়হান।"},{"q":"আরেক ফাল্গুন উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","জহির রায়হান","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: জহির রায়হান।"},{"q":"কাঁদো নদী কাঁদো উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","সৈয়দ ওয়ালীউল্লাহ","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: সৈয়দ ওয়ালীউল্লাহ।"},{"q":"সূর্য দীঘল বাড়ী উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","আবু ইসহাক"],"answer":3,"explain":"সঠিক উত্তর: আবু ইসহাক।"},{"q":"জননী উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শওকত ওসমান","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: শওকত ওসমান।"},{"q":"ক্রীতদাসের হাসি উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শওকত ওসমান","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: শওকত ওসমান।"},{"q":"চিলেকোঠার সেপাই উপন্যাসের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","আখতারুজ্জামান ইলিয়াস","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: আখতারুজ্জামান ইলিয়াস।"},{"q":"খোয়াবনামা উপন্যাসের রচয়িতা কার লেখা?","options":["আখতারুজ্জামান ইলিয়াস","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: আখতারুজ্জামান ইলিয়াস।"},{"q":"আগুনপাখি উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","হাসান আজিজুল হক","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: হাসান আজিজুল হক।"},{"q":"জীবন ও রাজনৈতিক বাস্তবতা উপন্যাসের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","শাহাদুজ্জামান","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: শাহাদুজ্জামান।"},{"q":"নন্দিত নরকে উপন্যাসের রচয়িতা কার লেখা?","options":["হুমায়ূন আহমেদ","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: হুমায়ূন আহমেদ।"},{"q":"জোছনা ও জননীর গল্প উপন্যাসের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","হুমায়ূন আহমেদ","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: হুমায়ূন আহমেদ।"},{"q":"কবি উপন্যাসের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","তারাশঙ্কর বন্দ্যোপাধ্যায়"],"answer":3,"explain":"সঠিক উত্তর: তারাশঙ্কর বন্দ্যোপাধ্যায়।"},{"q":"হাঁসুলী বাঁকের উপকথা উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","তারাশঙ্কর বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: তারাশঙ্কর বন্দ্যোপাধ্যায়।"},{"q":"গণদেবতা উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","তারাশঙ্কর বন্দ্যোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: তারাশঙ্কর বন্দ্যোপাধ্যায়।"},{"q":"শেষের কবিতা উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","রবীন্দ্রনাথ ঠাকুর"],"answer":3,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"ঘরে বাইরে উপন্যাসের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","রবীন্দ্রনাথ ঠাকুর","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"চোখের বালি উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","রবীন্দ্রনাথ ঠাকুর","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"গোরা উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","রবীন্দ্রনাথ ঠাকুর","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"বীরাঙ্গনা কাব্যের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","মাইকেল মধুসূদন দত্ত","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: মাইকেল মধুসূদন দত্ত।"},{"q":"তিলোত্তমাসম্ভব কাব্যের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","মাইকেল মধুসূদন দত্ত","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: মাইকেল মধুসূদন দত্ত।"},{"q":"কবর কবিতার রচয়িতা কার লেখা?","options":["জসীমউদ্দীন","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: জসীমউদ্দীন।"},{"q":"নকশী কাঁথার মাঠ কাব্যের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","জসীমউদ্দীন","বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: জসীমউদ্দীন।"},{"q":"সোজন বাদিয়ার ঘাট কাব্যের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","জসীমউদ্দীন","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: জসীমউদ্দীন।"},{"q":"বিদ্রোহী কবিতার রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","কাজী নজরুল ইসলাম","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: কাজী নজরুল ইসলাম।"},{"q":"অগ্নিবীণা কাব্যের রচয়িতা কার লেখা?","options":["কাজী নজরুল ইসলাম","বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: কাজী নজরুল ইসলাম।"},{"q":"সাম্যবাদী কবিতার রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","কাজী নজরুল ইসলাম","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: কাজী নজরুল ইসলাম।"},{"q":"রূপসী বাংলা কাব্যের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","জীবনানন্দ দাশ","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: জীবনানন্দ দাশ।"},{"q":"ধূসর পাণ্ডুলিপি কাব্যের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","জীবনানন্দ দাশ","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: জীবনানন্দ দাশ।"},{"q":"ছাড়পত্র কাব্যের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","সুকান্ত ভট্টাচার্য"],"answer":3,"explain":"সঠিক উত্তর: সুকান্ত ভট্টাচার্য।"},{"q":"হে মহাজীবন কবিতার রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","সুকান্ত ভট্টাচার্য"],"answer":3,"explain":"সঠিক উত্তর: সুকান্ত ভট্টাচার্য।"},{"q":"বিষাদ-সিন্ধু রচয়িতা কার লেখা?","options":["মীর মশাররফ হোসেন","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: মীর মশাররফ হোসেন।"},{"q":"জমিদার দর্পণ নাটকের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","মীর মশাররফ হোসেন"],"answer":3,"explain":"সঠিক উত্তর: মীর মশাররফ হোসেন।"},{"q":"নীলদর্পণ নাটকের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","দীনবন্ধু মিত্র","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: দীনবন্ধু মিত্র।"},{"q":"সধবার একাদশী নাটকের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","দীনবন্ধু মিত্র","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: দীনবন্ধু মিত্র।"},{"q":"রক্তকরবী নাটকের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","রবীন্দ্রনাথ ঠাকুর"],"answer":3,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"ডাকঘর নাটকের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","রবীন্দ্রনাথ ঠাকুর","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"সিরাজউদ্দৌলা নাটকের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","সিকান্দার আবু জাফর"],"answer":3,"explain":"সঠিক উত্তর: সিকান্দার আবু জাফর।"},{"q":"কবর নাটকের রচয়িতা কার লেখা?","options":["বিভূতিভূষণ বন্দ্যোপাধ্যায়","মুনীর চৌধুরী","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: মুনীর চৌধুরী।"},{"q":"রক্তাক্ত প্রান্তর নাটকের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","মুনীর চৌধুরী","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: মুনীর চৌধুরী।"},{"q":"বহিপীর নাটকের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","সৈয়দ শামসুল হক","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":1,"explain":"সঠিক উত্তর: সৈয়দ শামসুল হক।"},{"q":"পায়ের আওয়াজ পাওয়া যায় কাব্যনাট্যের রচয়িতা কার লেখা?","options":["সৈয়দ শামসুল হক","শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: সৈয়দ শামসুল হক।"},{"q":"একাত্তরের দিনগুলি গ্রন্থের রচয়িতা কার লেখা?","options":["জাহানারা ইমাম","বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: জাহানারা ইমাম।"},{"q":"আমার দেখা নয়াচীন গ্রন্থের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শেখ মুজিবুর রহমান"],"answer":3,"explain":"সঠিক উত্তর: শেখ মুজিবুর রহমান।"},{"q":"অসমাপ্ত আত্মজীবনী গ্রন্থের লেখক কার লেখা?","options":["শেখ মুজিবুর রহমান","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: শেখ মুজিবুর রহমান।"},{"q":"কারাগারের রোজনামচা গ্রন্থের লেখক কার লেখা?","options":["শেখ মুজিবুর রহমান","বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: শেখ মুজিবুর রহমান।"},{"q":"সাতকাহন উপন্যাসের রচয়িতা কার লেখা?","options":["শরৎচন্দ্র চট্টোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়","সমরেশ মজুমদার","বিভূতিভূষণ বন্দ্যোপাধ্যায়"],"answer":2,"explain":"সঠিক উত্তর: সমরেশ মজুমদার।"},{"q":"কালবেলা উপন্যাসের রচয়িতা কার লেখা?","options":["বঙ্কিমচন্দ্র চট্টোপাধ্যায়","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","সমরেশ মজুমদার"],"answer":3,"explain":"সঠিক উত্তর: সমরেশ মজুমদার।"},{"q":"দেশে বিদেশে ভ্রমণকাহিনির লেখক কার লেখা?","options":["সৈয়দ মুজতবা আলী","শরৎচন্দ্র চট্টোপাধ্যায়","বিভূতিভূষণ বন্দ্যোপাধ্যায়","বঙ্কিমচন্দ্র চট্টোপাধ্যায়"],"answer":0,"explain":"সঠিক উত্তর: সৈয়দ মুজতবা আলী।"},{"q":"মানবদেহের বৃহত্তম অঙ্গ—সঠিক উত্তর কোনটি?","options":["হিমোগ্লোবিন","ত্বক","স্টেপিস","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: ত্বক।"},{"q":"মানবদেহের বৃহত্তম গ্রন্থি—সঠিক উত্তর কোনটি?","options":["স্টেপিস","যকৃত","হিমোগ্লোবিন","ত্বক"],"answer":1,"explain":"সঠিক উত্তর: যকৃত।"},{"q":"মানবদেহের ক্ষুদ্রতম অস্থি—সঠিক উত্তর কোনটি?","options":["যকৃত","হিমোগ্লোবিন","স্টেপিস","ত্বক"],"answer":2,"explain":"সঠিক উত্তর: স্টেপিস।"},{"q":"রক্তের লাল রঙের জন্য দায়ী—সঠিক উত্তর কোনটি?","options":["হিমোগ্লোবিন","যকৃত","ত্বক","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: হিমোগ্লোবিন।"},{"q":"রক্ত জমাট বাঁধতে সহায়তা করে—সঠিক উত্তর কোনটি?","options":["ত্বক","প্লাটিলেট","যকৃত","স্টেপিস"],"answer":1,"explain":"সঠিক উত্তর: প্লাটিলেট।"},{"q":"মানবদেহে স্বাভাবিক ক্রোমোজোম সংখ্যা—সঠিক উত্তর কোনটি?","options":["৪৬টি","যকৃত","ত্বক","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: ৪৬টি।"},{"q":"মানবদেহের স্বাভাবিক দেহকোষে ক্রোমোজোম জোড়া—সঠিক উত্তর কোনটি?","options":["যকৃত","২৩ জোড়া","স্টেপিস","ত্বক"],"answer":1,"explain":"সঠিক উত্তর: ২৩ জোড়া।"},{"q":"ইনসুলিন নিঃসৃত হয়—সঠিক উত্তর কোনটি?","options":["যকৃত","ত্বক","অগ্ন্যাশয় থেকে","স্টেপিস"],"answer":2,"explain":"সঠিক উত্তর: অগ্ন্যাশয় থেকে।"},{"q":"পিত্তরস উৎপন্ন হয়—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","যকৃতে","স্টেপিস"],"answer":2,"explain":"সঠিক উত্তর: যকৃতে।"},{"q":"মানবদেহের রক্ত পরিশোধন করে—সঠিক উত্তর কোনটি?","options":["ত্বক","স্টেপিস","যকৃত","বৃক্ক"],"answer":3,"explain":"সঠিক উত্তর: বৃক্ক।"},{"q":"ভিটামিন C-এর অভাবে হয়—সঠিক উত্তর কোনটি?","options":["যকৃত","ত্বক","স্টেপিস","স্কার্ভি"],"answer":3,"explain":"সঠিক উত্তর: স্কার্ভি।"},{"q":"ভিটামিন D-এর অভাবে শিশুদের হয়—সঠিক উত্তর কোনটি?","options":["রিকেটস","স্টেপিস","ত্বক","যকৃত"],"answer":0,"explain":"সঠিক উত্তর: রিকেটস।"},{"q":"ভিটামিন A-এর অভাবে হয়—সঠিক উত্তর কোনটি?","options":["রাতকানা","স্টেপিস","ত্বক","যকৃত"],"answer":0,"explain":"সঠিক উত্তর: রাতকানা।"},{"q":"ভিটামিন B1-এর অভাবে হয়—সঠিক উত্তর কোনটি?","options":["বেরিবেরি","ত্বক","স্টেপিস","যকৃত"],"answer":0,"explain":"সঠিক উত্তর: বেরিবেরি।"},{"q":"আয়োডিনের অভাবে হয়—সঠিক উত্তর কোনটি?","options":["গলগণ্ড","স্টেপিস","যকৃত","ত্বক"],"answer":0,"explain":"সঠিক উত্তর: গলগণ্ড।"},{"q":"মানবদেহে অক্সিজেন পরিবহন করে—সঠিক উত্তর কোনটি?","options":["ত্বক","লোহিত রক্তকণিকা","স্টেপিস","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: লোহিত রক্তকণিকা।"},{"q":"মানবদেহের স্বাভাবিক তাপমাত্রা—সঠিক উত্তর কোনটি?","options":["স্টেপিস","৩৭° সেলসিয়াস","যকৃত","ত্বক"],"answer":1,"explain":"সঠিক উত্তর: ৩৭° সেলসিয়াস।"},{"q":"উদ্ভিদের খাদ্য তৈরির প্রক্রিয়া—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ত্বক","যকৃত","সালোকসংশ্লেষণ"],"answer":3,"explain":"সঠিক উত্তর: সালোকসংশ্লেষণ।"},{"q":"সালোকসংশ্লেষণে নির্গত গ্যাস—সঠিক উত্তর কোনটি?","options":["অক্সিজেন","যকৃত","স্টেপিস","ত্বক"],"answer":0,"explain":"সঠিক উত্তর: অক্সিজেন।"},{"q":"উদ্ভিদের সবুজ রঞ্জক পদার্থ—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ক্লোরোফিল","ত্বক","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: ক্লোরোফিল।"},{"q":"কোষের শক্তিঘর বলা হয়—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","স্টেপিস","মাইটোকন্ড্রিয়া"],"answer":3,"explain":"সঠিক উত্তর: মাইটোকন্ড্রিয়া।"},{"q":"কোষের নিয়ন্ত্রণকেন্দ্র—সঠিক উত্তর কোনটি?","options":["ত্বক","নিউক্লিয়াস","যকৃত","স্টেপিস"],"answer":1,"explain":"সঠিক উত্তর: নিউক্লিয়াস।"},{"q":"বংশগতির একক—সঠিক উত্তর কোনটি?","options":["জিন","ত্বক","স্টেপিস","যকৃত"],"answer":0,"explain":"সঠিক উত্তর: জিন।"},{"q":"DNA-এর পূর্ণরূপে D বোঝায়—সঠিক উত্তর কোনটি?","options":["যকৃত","স্টেপিস","Deoxyribo","ত্বক"],"answer":2,"explain":"সঠিক উত্তর: Deoxyribo।"},{"q":"মানবদেহে রক্তের pH সাধারণত—সঠিক উত্তর কোনটি?","options":["সামান্য ক্ষারীয়","ত্বক","যকৃত","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: সামান্য ক্ষারীয়।"},{"q":"শব্দের বেগ বায়ুতে প্রায়—সঠিক উত্তর কোনটি?","options":["৩৪৩ মিটার/সেকেন্ড","যকৃত","ত্বক","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: ৩৪৩ মিটার/সেকেন্ড।"},{"q":"আলোর বেগ শূন্যস্থানে প্রায়—সঠিক উত্তর কোনটি?","options":["যকৃত","স্টেপিস","৩×১০⁸ মিটার/সেকেন্ড","ত্বক"],"answer":2,"explain":"সঠিক উত্তর: ৩×১০⁸ মিটার/সেকেন্ড।"},{"q":"বল-এর SI একক—সঠিক উত্তর কোনটি?","options":["ত্বক","নিউটন","যকৃত","স্টেপিস"],"answer":1,"explain":"সঠিক উত্তর: নিউটন।"},{"q":"কাজের SI একক—সঠিক উত্তর কোনটি?","options":["জুল","ত্বক","যকৃত","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: জুল।"},{"q":"ক্ষমতার SI একক—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ওয়াট","যকৃত","ত্বক"],"answer":1,"explain":"সঠিক উত্তর: ওয়াট।"},{"q":"চাপের SI একক—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ত্বক","যকৃত","প্যাসকেল"],"answer":3,"explain":"সঠিক উত্তর: প্যাসকেল।"},{"q":"তড়িৎ প্রবাহের SI একক—সঠিক উত্তর কোনটি?","options":["যকৃত","অ্যাম্পিয়ার","ত্বক","স্টেপিস"],"answer":1,"explain":"সঠিক উত্তর: অ্যাম্পিয়ার।"},{"q":"বিভব পার্থক্যের SI একক—সঠিক উত্তর কোনটি?","options":["যকৃত","ভোল্ট","ত্বক","স্টেপিস"],"answer":1,"explain":"সঠিক উত্তর: ভোল্ট।"},{"q":"রোধের SI একক—সঠিক উত্তর কোনটি?","options":["যকৃত","স্টেপিস","ওহম","ত্বক"],"answer":2,"explain":"সঠিক উত্তর: ওহম।"},{"q":"কম্পাঙ্কের SI একক—সঠিক উত্তর কোনটি?","options":["যকৃত","স্টেপিস","হার্টজ","ত্বক"],"answer":2,"explain":"সঠিক উত্তর: হার্টজ।"},{"q":"তাপমাত্রার SI একক—সঠিক উত্তর কোনটি?","options":["ত্বক","স্টেপিস","কেলভিন","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: কেলভিন।"},{"q":"ভরের SI একক—সঠিক উত্তর কোনটি?","options":["যকৃত","স্টেপিস","ত্বক","কিলোগ্রাম"],"answer":3,"explain":"সঠিক উত্তর: কিলোগ্রাম।"},{"q":"দৈর্ঘ্যের SI একক—সঠিক উত্তর কোনটি?","options":["স্টেপিস","মিটার","ত্বক","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: মিটার।"},{"q":"সময়ের SI একক—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","সেকেন্ড","স্টেপিস"],"answer":2,"explain":"সঠিক উত্তর: সেকেন্ড।"},{"q":"পানির রাসায়নিক সংকেত—সঠিক উত্তর কোনটি?","options":["যকৃত","H₂O","স্টেপিস","ত্বক"],"answer":1,"explain":"সঠিক উত্তর: H₂O।"},{"q":"খাবার লবণের রাসায়নিক সংকেত—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","NaCl","স্টেপিস"],"answer":2,"explain":"সঠিক উত্তর: NaCl।"},{"q":"কার্বন ডাই-অক্সাইডের সংকেত—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","স্টেপিস","CO₂"],"answer":3,"explain":"সঠিক উত্তর: CO₂।"},{"q":"ওজোনের রাসায়নিক সংকেত—সঠিক উত্তর কোনটি?","options":["ত্বক","স্টেপিস","O₃","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: O₃।"},{"q":"সোনার রাসায়নিক প্রতীক—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ত্বক","যকৃত","Au"],"answer":3,"explain":"সঠিক উত্তর: Au।"},{"q":"রুপার রাসায়নিক প্রতীক—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","স্টেপিস","Ag"],"answer":3,"explain":"সঠিক উত্তর: Ag।"},{"q":"লোহার রাসায়নিক প্রতীক—সঠিক উত্তর কোনটি?","options":["Fe","স্টেপিস","যকৃত","ত্বক"],"answer":0,"explain":"সঠিক উত্তর: Fe।"},{"q":"পারদের রাসায়নিক প্রতীক—সঠিক উত্তর কোনটি?","options":["ত্বক","Hg","স্টেপিস","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: Hg।"},{"q":"সোডিয়ামের রাসায়নিক প্রতীক—সঠিক উত্তর কোনটি?","options":["ত্বক","স্টেপিস","Na","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: Na।"},{"q":"পটাশিয়ামের রাসায়নিক প্রতীক—সঠিক উত্তর কোনটি?","options":["স্টেপিস","K","ত্বক","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: K।"},{"q":"পরমাণুর কেন্দ্রে থাকে—সঠিক উত্তর কোনটি?","options":["যকৃত","ত্বক","স্টেপিস","প্রোটন ও নিউট্রন"],"answer":3,"explain":"সঠিক উত্তর: প্রোটন ও নিউট্রন।"},{"q":"ইলেকট্রনের আধান—সঠিক উত্তর কোনটি?","options":["ঋণাত্মক","যকৃত","ত্বক","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: ঋণাত্মক।"},{"q":"প্রোটনের আধান—সঠিক উত্তর কোনটি?","options":["স্টেপিস","যকৃত","ধনাত্মক","ত্বক"],"answer":2,"explain":"সঠিক উত্তর: ধনাত্মক।"},{"q":"নিউট্রনের আধান—সঠিক উত্তর কোনটি?","options":["ত্বক","স্টেপিস","নিরপেক্ষ","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: নিরপেক্ষ।"},{"q":"অম্ল নীল লিটমাসকে করে—সঠিক উত্তর কোনটি?","options":["লাল","ত্বক","যকৃত","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: লাল।"},{"q":"ক্ষার লাল লিটমাসকে করে—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ত্বক","যকৃত","নীল"],"answer":3,"explain":"সঠিক উত্তর: নীল।"},{"q":"বিশুদ্ধ পানির pH—সঠিক উত্তর কোনটি?","options":["স্টেপিস","৭","ত্বক","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: ৭।"},{"q":"কম্পিউটারের মস্তিষ্ক বলা হয়—সঠিক উত্তর কোনটি?","options":["CPU","স্টেপিস","ত্বক","যকৃত"],"answer":0,"explain":"সঠিক উত্তর: CPU।"},{"q":"CPU-এর পূর্ণরূপ—সঠিক উত্তর কোনটি?","options":["Central Processing Unit","যকৃত","স্টেপিস","ত্বক"],"answer":0,"explain":"সঠিক উত্তর: Central Processing Unit।"},{"q":"RAM হলো—সঠিক উত্তর কোনটি?","options":["অস্থায়ী/ভোলাটাইল মেমোরি","স্টেপিস","যকৃত","ত্বক"],"answer":0,"explain":"সঠিক উত্তর: অস্থায়ী/ভোলাটাইল মেমোরি।"},{"q":"ROM হলো—সঠিক উত্তর কোনটি?","options":["স্থায়ী/নন-ভোলাটাইল মেমোরি","স্টেপিস","ত্বক","যকৃত"],"answer":0,"explain":"সঠিক উত্তর: স্থায়ী/নন-ভোলাটাইল মেমোরি।"},{"q":"বাইনারি সংখ্যা পদ্ধতির ভিত্তি—সঠিক উত্তর কোনটি?","options":["যকৃত","ত্বক","২","স্টেপিস"],"answer":2,"explain":"সঠিক উত্তর: ২।"},{"q":"এক বাইটে বিটের সংখ্যা—সঠিক উত্তর কোনটি?","options":["যকৃত","স্টেপিস","ত্বক","৮"],"answer":3,"explain":"সঠিক উত্তর: ৮।"},{"q":"HTML ব্যবহৃত হয়—সঠিক উত্তর কোনটি?","options":["যকৃত","ওয়েব পেজের কাঠামো তৈরিতে","স্টেপিস","ত্বক"],"answer":1,"explain":"সঠিক উত্তর: ওয়েব পেজের কাঠামো তৈরিতে।"},{"q":"HTTP-এর পূর্ণরূপ—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","Hypertext Transfer Protocol","স্টেপিস"],"answer":2,"explain":"সঠিক উত্তর: Hypertext Transfer Protocol।"},{"q":"URL-এর পূর্ণরূপ—সঠিক উত্তর কোনটি?","options":["ত্বক","Uniform Resource Locator","যকৃত","স্টেপিস"],"answer":1,"explain":"সঠিক উত্তর: Uniform Resource Locator।"},{"q":"ই-মেইলে CC-এর পূর্ণরূপ—সঠিক উত্তর কোনটি?","options":["ত্বক","Carbon Copy","যকৃত","স্টেপিস"],"answer":1,"explain":"সঠিক উত্তর: Carbon Copy।"},{"q":"কম্পিউটার ভাইরাস হলো—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ত্বক","ক্ষতিকর প্রোগ্রাম","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: ক্ষতিকর প্রোগ্রাম।"},{"q":"ফিশিং হলো—সঠিক উত্তর কোনটি?","options":["ত্বক","যকৃত","প্রতারণামূলক তথ্য চুরির কৌশল","স্টেপিস"],"answer":2,"explain":"সঠিক উত্তর: প্রতারণামূলক তথ্য চুরির কৌশল।"},{"q":"কৃত্রিম বুদ্ধিমত্তার সংক্ষিপ্ত রূপ—সঠিক উত্তর কোনটি?","options":["ত্বক","স্টেপিস","AI","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: AI।"},{"q":"বিশ্বের প্রথম প্রোগ্রামার হিসেবে পরিচিত—সঠিক উত্তর কোনটি?","options":["স্টেপিস","যকৃত","ত্বক","এডা লাভলেস"],"answer":3,"explain":"সঠিক উত্তর: এডা লাভলেস।"},{"q":"ওয়ার্ল্ড ওয়াইড ওয়েবের উদ্ভাবক—সঠিক উত্তর কোনটি?","options":["স্টেপিস","টিম বার্নার্স-লি","ত্বক","যকৃত"],"answer":1,"explain":"সঠিক উত্তর: টিম বার্নার্স-লি।"},{"q":"মাইক্রোপ্রসেসরের প্রথম বাণিজ্যিক উদাহরণ—সঠিক উত্তর কোনটি?","options":["Intel 4004","যকৃত","ত্বক","স্টেপিস"],"answer":0,"explain":"সঠিক উত্তর: Intel 4004।"},{"q":"অর্থনীতিতে চাহিদার সূত্র অনুযায়ী দাম বাড়লে চাহিদা সাধারণত—সঠিক উত্তর কোনটি?","options":["স্টেপিস","যকৃত","ত্বক","কমে"],"answer":3,"explain":"সঠিক উত্তর: কমে।"},{"q":"মুদ্রাস্ফীতি বলতে বোঝায়—সঠিক উত্তর কোনটি?","options":["যকৃত","স্টেপিস","ত্বক","সাধারণ মূল্যস্তরের ধারাবাহিক বৃদ্ধি"],"answer":3,"explain":"সঠিক উত্তর: সাধারণ মূল্যস্তরের ধারাবাহিক বৃদ্ধি।"},{"q":"GDP-এর পূর্ণরূপ—সঠিক উত্তর কোনটি?","options":["স্টেপিস","ত্বক","Gross Domestic Product","যকৃত"],"answer":2,"explain":"সঠিক উত্তর: Gross Domestic Product।"},{"q":"বাংলাদেশের কেন্দ্রীয় ব্যাংকের নাম—সঠিক উত্তর কোনটি?","options":["যকৃত","বাংলাদেশ ব্যাংক","স্টেপিস","ত্বক"],"answer":1,"explain":"সঠিক উত্তর: বাংলাদেশ ব্যাংক।"},{"q":"ফরাসি বিপ্লব শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৯১৪ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৭৮৯ সালে।"},{"q":"আমেরিকার স্বাধীনতার ঘোষণা গৃহীত হয়—সঠিক উত্তর কোনটি?","options":["১৯১৪ সালে","১৯১৭ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৭৭৬ সালে।"},{"q":"রুশ বিপ্লব সংঘটিত হয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৯১৭ সালে","১৯১৪ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৯১৭ সালে।"},{"q":"প্রথম বিশ্বযুদ্ধ শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯১৪ সালে","১৯১৭ সালে","১৭৭৬ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১৯১৪ সালে।"},{"q":"প্রথম বিশ্বযুদ্ধ শেষ হয়—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৮৯ সালে","১৭৭৬ সালে","১৯১৮ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯১৮ সালে।"},{"q":"দ্বিতীয় বিশ্বযুদ্ধ শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৭৮৯ সালে","১৯১৭ সালে","১৯৩৯ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯৩৯ সালে।"},{"q":"দ্বিতীয় বিশ্বযুদ্ধ শেষ হয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৭৭৬ সালে","১৯৪৫ সালে","১৯১৭ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৪৫ সালে।"},{"q":"জাতিসংঘ সনদ স্বাক্ষরিত হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৯১৭ সালে","১৯৪৫ সালে","১৭৮৯ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৪৫ সালে।"},{"q":"বার্লিন প্রাচীরের পতন ঘটে—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৭৬ সালে","১৯৮৯ সালে","১৭৮৯ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৮৯ সালে।"},{"q":"সোভিয়েত ইউনিয়ন বিলুপ্ত হয়—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৮৯ সালে","১৯৯১ সালে","১৭৭৬ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৯১ সালে।"},{"q":"ম্যাগনা কার্টা স্বাক্ষরিত হয়—সঠিক উত্তর কোনটি?","options":["১২১৫ সালে","১৯১৭ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১২১৫ সালে।"},{"q":"রেনেসাঁর সূচনা হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৭৮৯ সালে","১৯১৭ সালে","ইতালিতে"],"answer":3,"explain":"সঠিক উত্তর: ইতালিতে।"},{"q":"শিল্পবিপ্লব প্রথম শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","ব্রিটেনে","১৭৭৬ সালে","১৯১৭ সালে"],"answer":1,"explain":"সঠিক উত্তর: ব্রিটেনে।"},{"q":"আমেরিকার গৃহযুদ্ধ শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৮৬১ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৮৬১ সালে।"},{"q":"জাপানের মেইজি পুনর্গঠন শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৯১৭ সালে","১৮৬৮ সালে","১৭৮৯ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৮৬৮ সালে।"},{"q":"চীনের গণপ্রজাতন্ত্রী প্রতিষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৯১৭ সালে","১৯৪৯ সালে","১৭৮৯ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৪৯ সালে।"},{"q":"ভারতের অসহযোগ আন্দোলন শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৯২০ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৯২০ সালে।"},{"q":"ভারত ছাড়ো আন্দোলন শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৯৪২ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৯৪২ সালে।"},{"q":"জালিয়ানওয়ালাবাগ হত্যাকাণ্ড ঘটে—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৭৬ সালে","১৭৮৯ সালে","১৯১৯ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯১৯ সালে।"},{"q":"বঙ্গভঙ্গের সময় ভারতের ভাইসরয় ছিলেন—সঠিক উত্তর কোনটি?","options":["লর্ড কার্জন","১৭৭৬ সালে","১৯১৭ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: লর্ড কার্জন।"},{"q":"চিরস্থায়ী বন্দোবস্ত প্রবর্তন করেন—সঠিক উত্তর কোনটি?","options":["লর্ড কর্নওয়ালিস","১৯১৭ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":0,"explain":"সঠিক উত্তর: লর্ড কর্নওয়ালিস।"},{"q":"ভারতে রেল চলাচল শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৮৫৩ সালে","১৭৭৬ সালে","১৯১৭ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৮৫৩ সালে।"},{"q":"ভারতীয় জাতীয় কংগ্রেসের প্রথম সভাপতি—সঠিক উত্তর কোনটি?","options":["উমেশচন্দ্র বন্দ্যোপাধ্যায়","১৭৭৬ সালে","১৯১৭ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: উমেশচন্দ্র বন্দ্যোপাধ্যায়।"},{"q":"মুসলিম লীগের প্রথম সভাপতি—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৯১৭ সালে","আগা খান","১৭৭৬ সালে"],"answer":2,"explain":"সঠিক উত্তর: আগা খান।"},{"q":"লাহোর প্রস্তাব উত্থাপন করেন—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৯১৭ সালে","১৭৭৬ সালে","এ কে ফজলুল হক"],"answer":3,"explain":"সঠিক উত্তর: এ কে ফজলুল হক।"},{"q":"সিপাহি বিদ্রোহের সূচনা হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","মিরাটে","১৯১৭ সালে","১৭৮৯ সালে"],"answer":1,"explain":"সঠিক উত্তর: মিরাটে।"},{"q":"পলাশীর যুদ্ধে ইংরেজ বাহিনীর নেতৃত্ব দেন—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","রবার্ট ক্লাইভ","১৯১৭ সালে","১৭৮৯ সালে"],"answer":1,"explain":"সঠিক উত্তর: রবার্ট ক্লাইভ।"},{"q":"বক্সারের যুদ্ধে ইংরেজ বাহিনীর নেতৃত্ব দেন—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","হেক্টর মনরো","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: হেক্টর মনরো।"},{"q":"মুঘল সাম্রাজ্যের প্রতিষ্ঠাতা—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৭৬ সালে","১৭৮৯ সালে","বাবর"],"answer":3,"explain":"সঠিক উত্তর: বাবর।"},{"q":"মুঘল সাম্রাজ্যের শেষ সম্রাট—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৭৮৯ সালে","১৯১৭ সালে","দ্বিতীয় বাহাদুর শাহ"],"answer":3,"explain":"সঠিক উত্তর: দ্বিতীয় বাহাদুর শাহ।"},{"q":"আকবরের শাসনামলে ধর্মীয় মতবাদ—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","দীন-ই-ইলাহি","১৭৭৬ সালে","১৯১৭ সালে"],"answer":1,"explain":"সঠিক উত্তর: দীন-ই-ইলাহি।"},{"q":"দিল্লির লালকেল্লা নির্মাণ করেন—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৭৭৬ সালে","শাহজাহান","১৯১৭ সালে"],"answer":2,"explain":"সঠিক উত্তর: শাহজাহান।"},{"q":"ফতেহপুর সিক্রি নির্মাণ করেন—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৭৮৯ সালে","১৯১৭ সালে","আকবর"],"answer":3,"explain":"সঠিক উত্তর: আকবর।"},{"q":"কুতুব মিনারের নির্মাণ শুরু করেন—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","কুতুবউদ্দিন আইবেক","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: কুতুবউদ্দিন আইবেক।"},{"q":"তাজমহল অবস্থিত—সঠিক উত্তর কোনটি?","options":["আগ্রায়","১৭৮৯ সালে","১৯১৭ সালে","১৭৭৬ সালে"],"answer":0,"explain":"সঠিক উত্তর: আগ্রায়।"},{"q":"আলেকজান্ডার ভারত আক্রমণ করেন—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৯১৭ সালে","খ্রিস্টপূর্ব ৩২৬ সালে","১৭৭৬ সালে"],"answer":2,"explain":"সঠিক উত্তর: খ্রিস্টপূর্ব ৩২৬ সালে।"},{"q":"গৌতম বুদ্ধের জন্মস্থান—সঠিক উত্তর কোনটি?","options":["লুম্বিনী","১৭৮৯ সালে","১৭৭৬ সালে","১৯১৭ সালে"],"answer":0,"explain":"সঠিক উত্তর: লুম্বিনী।"},{"q":"মহাবীর জৈন ধর্মের—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","২৪তম তীর্থংকর","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: ২৪তম তীর্থংকর।"},{"q":"মৌর্য সাম্রাজ্যের প্রতিষ্ঠাতা—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৮৯ সালে","১৭৭৬ সালে","চন্দ্রগুপ্ত মৌর্য"],"answer":3,"explain":"সঠিক উত্তর: চন্দ্রগুপ্ত মৌর্য।"},{"q":"অশোক কোন বংশের সম্রাট—সঠিক উত্তর কোনটি?","options":["মৌর্য বংশ","১৭৭৬ সালে","১৭৮৯ সালে","১৯১৭ সালে"],"answer":0,"explain":"সঠিক উত্তর: মৌর্য বংশ।"},{"q":"গুপ্ত যুগকে বলা হয়—সঠিক উত্তর কোনটি?","options":["প্রাচীন ভারতের স্বর্ণযুগ","১৭৮৯ সালে","১৭৭৬ সালে","১৯১৭ সালে"],"answer":0,"explain":"সঠিক উত্তর: প্রাচীন ভারতের স্বর্ণযুগ।"},{"q":"নালন্দা বিশ্ববিদ্যালয় অবস্থিত ছিল—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","বিহারে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: বিহারে।"},{"q":"মার্কো পোলো ছিলেন—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৯১৭ সালে","১৭৮৯ সালে","ইতালীয় পর্যটক"],"answer":3,"explain":"সঠিক উত্তর: ইতালীয় পর্যটক।"},{"q":"ক্রিস্টোফার কলম্বাস আমেরিকা পৌঁছান—সঠিক উত্তর কোনটি?","options":["১৪৯২ সালে","১৭৭৬ সালে","১৯১৭ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১৪৯২ সালে।"},{"q":"ভাস্কো দা গামা ভারতে পৌঁছান—সঠিক উত্তর কোনটি?","options":["১৪৯৮ সালে","১৯১৭ সালে","১৭৭৬ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১৪৯৮ সালে।"},{"q":"মুদ্রণযন্ত্রের সঙ্গে যুক্ত উদ্ভাবক—সঠিক উত্তর কোনটি?","options":["জোহানেস গুটেনবার্গ","১৭৮৯ সালে","১৭৭৬ সালে","১৯১৭ সালে"],"answer":0,"explain":"সঠিক উত্তর: জোহানেস গুটেনবার্গ।"},{"q":"আপেক্ষিকতা তত্ত্বের প্রণেতা—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৮৯ সালে","১৭৭৬ সালে","আলবার্ট আইনস্টাইন"],"answer":3,"explain":"সঠিক উত্তর: আলবার্ট আইনস্টাইন।"},{"q":"মহাকর্ষ সূত্রের প্রণেতা—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","আইজ্যাক নিউটন","১৭৭৬ সালে","১৯১৭ সালে"],"answer":1,"explain":"সঠিক উত্তর: আইজ্যাক নিউটন।"},{"q":"বিবর্তনবাদের সঙ্গে যুক্ত বিজ্ঞানী—সঠিক উত্তর কোনটি?","options":["চার্লস ডারউইন","১৭৭৬ সালে","১৭৮৯ সালে","১৯১৭ সালে"],"answer":0,"explain":"সঠিক উত্তর: চার্লস ডারউইন।"},{"q":"পেনিসিলিন আবিষ্কার করেন—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৭৮৯ সালে","১৯১৭ সালে","আলেকজান্ডার ফ্লেমিং"],"answer":3,"explain":"সঠিক উত্তর: আলেকজান্ডার ফ্লেমিং।"},{"q":"রেডিয়াম আবিষ্কারের সঙ্গে যুক্ত—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৭৭৬ সালে","১৯১৭ সালে","মেরি কুরি"],"answer":3,"explain":"সঠিক উত্তর: মেরি কুরি।"},{"q":"টেলিফোনের উদ্ভাবক হিসেবে পরিচিত—সঠিক উত্তর কোনটি?","options":["আলেকজান্ডার গ্রাহাম বেল","১৭৭৬ সালে","১৯১৭ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: আলেকজান্ডার গ্রাহাম বেল।"},{"q":"বৈদ্যুতিক বাতির ব্যবহারিক উন্নয়নে বিখ্যাত—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৮৯ সালে","থমাস আলভা এডিসন","১৭৭৬ সালে"],"answer":2,"explain":"সঠিক উত্তর: থমাস আলভা এডিসন।"},{"q":"বিমান আবিষ্কারের সঙ্গে যুক্ত রাইট ভ্রাতৃদ্বয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৯১৭ সালে","অরভিল ও উইলবার রাইট","১৭৭৬ সালে"],"answer":2,"explain":"সঠিক উত্তর: অরভিল ও উইলবার রাইট।"},{"q":"বাংলাদেশের মুক্তিযুদ্ধ শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৯৭১ সালে","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৯৭১ সালে।"},{"q":"ভাষা আন্দোলনের চূড়ান্ত রক্তাক্ত ঘটনা ঘটে—সঠিক উত্তর কোনটি?","options":["২১ ফেব্রুয়ারি ১৯৫২","১৭৭৬ সালে","১৯১৭ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: ২১ ফেব্রুয়ারি ১৯৫২।"},{"q":"যুক্তফ্রন্ট নির্বাচন অনুষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১৯৫৪ সালে","১৯১৭ সালে","১৭৭৬ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১৯৫৪ সালে।"},{"q":"আগরতলা মামলা দায়ের করা হয়—সঠিক উত্তর কোনটি?","options":["১৯৬৮ সালে","১৯১৭ সালে","১৭৭৬ সালে","১৭৮৯ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১৯৬৮ সালে।"},{"q":"গণঅভ্যুত্থানের শহীদ আসাদ নিহত হন—সঠিক উত্তর কোনটি?","options":["১৯৬৯ সালে","১৭৮৯ সালে","১৯১৭ সালে","১৭৭৬ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১৯৬৯ সালে।"},{"q":"জাতীয় স্মৃতিসৌধের নকশা নির্বাচন করা হয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৭৭৬ সালে","১৯৭২ সালে","১৯১৭ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৭২ সালে।"},{"q":"বাংলাদেশ জাতিসংঘের সদস্যপদ লাভ করে—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৭৬ সালে","১৯৭৪ সালে","১৭৮৯ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৭৪ সালে।"},{"q":"বাংলাদেশ OIC-এর সদস্য হয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৯৭৪ সালে","১৯১৭ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: ১৯৭৪ সালে।"},{"q":"বাংলাদেশ SAARC-এর প্রতিষ্ঠাতা সদস্য হয়—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৭৭৬ সালে","১৯১৭ সালে","১৯৮৫ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯৮৫ সালে।"},{"q":"পার্বত্য চট্টগ্রাম শান্তিচুক্তি স্বাক্ষরিত হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৭৮৯ সালে","১৯৯৭ সালে","১৯১৭ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৯৭ সালে।"},{"q":"বাংলাদেশের প্রথম সাধারণ নির্বাচন অনুষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১৭৭৬ সালে","১৭৮৯ সালে","১৯৭৩ সালে","১৯১৭ সালে"],"answer":2,"explain":"সঠিক উত্তর: ১৯৭৩ সালে।"},{"q":"বাংলাদেশের প্রথম রাষ্ট্রপতি—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","শেখ মুজিবুর রহমান","১৭৮৯ সালে","১৭৭৬ সালে"],"answer":1,"explain":"সঠিক উত্তর: শেখ মুজিবুর রহমান।"},{"q":"মুক্তিযুদ্ধের প্রধান সেনাপতি—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","এম এ জি ওসমানী","১৭৭৬ সালে","১৭৮৯ সালে"],"answer":1,"explain":"সঠিক উত্তর: এম এ জি ওসমানী।"},{"q":"মুজিবনগর সরকারের প্রধানমন্ত্রী—সঠিক উত্তর কোনটি?","options":["১৯১৭ সালে","১৭৮৯ সালে","১৭৭৬ সালে","তাজউদ্দীন আহমদ"],"answer":3,"explain":"সঠিক উত্তর: তাজউদ্দীন আহমদ।"},{"q":"মুক্তিযুদ্ধের সময় বাংলাদেশকে ভাগ করা হয়েছিল—সঠিক উত্তর কোনটি?","options":["১১টি সেক্টরে","১৭৮৯ সালে","১৭৭৬ সালে","১৯১৭ সালে"],"answer":0,"explain":"সঠিক উত্তর: ১১টি সেক্টরে।"},{"q":"বীরশ্রেষ্ঠ উপাধি পান—সঠিক উত্তর কোনটি?","options":["১৭৮৯ সালে","১৭৭৬ সালে","১৯১৭ সালে","৭ জন"],"answer":3,"explain":"সঠিক উত্তর: ৭ জন।"},{"q":"বাংলাদেশের জাতীয় পতাকার দৈর্ঘ্য ও প্রস্থের অনুপাত—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","বিদ্রোহী কবি","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: ১০:৬।"},{"q":"বাংলাদেশের জাতীয় সংগীতের রচয়িতা—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬","বিদ্রোহী কবি"],"answer":1,"explain":"সঠিক উত্তর: রবীন্দ্রনাথ ঠাকুর।"},{"q":"বাংলাদেশের জাতীয় সংগীতের প্রথম দশ লাইন গৃহীত—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","বিদ্রোহী কবি","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":3,"explain":"সঠিক উত্তর: জাতীয় সংগীত হিসেবে।"},{"q":"বাংলাদেশের জাতীয় কবি কাজী নজরুল ইসলামের উপাধি—সঠিক উত্তর কোনটি?","options":["বিদ্রোহী কবি","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: বিদ্রোহী কবি।"},{"q":"বাংলাদেশের জাতীয় বৃক্ষ—সঠিক উত্তর কোনটি?","options":["আমগাছ","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: আমগাছ।"},{"q":"বাংলাদেশের জাতীয় খেলা—সঠিক উত্তর কোনটি?","options":["কাবাডি","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: কাবাডি।"},{"q":"বাংলাদেশের জাতীয় মসজিদ—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর","বায়তুল মোকাররম"],"answer":3,"explain":"সঠিক উত্তর: বায়তুল মোকাররম।"},{"q":"বাংলাদেশের জাতীয় সংসদের সাধারণ আসন সংখ্যা—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","৩০০টি","রবীন্দ্রনাথ ঠাকুর"],"answer":2,"explain":"সঠিক উত্তর: ৩০০টি।"},{"q":"বাংলাদেশের সংবিধানের মূলনীতি—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","৪টি"],"answer":3,"explain":"সঠিক উত্তর: ৪টি।"},{"q":"বাংলাদেশের সংবিধানের রাষ্ট্র পরিচালনার মূলনীতি—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয়তাবাদ, সমাজতন্ত্র, গণতন্ত্র ও ধর্মনিরপেক্ষতা","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":1,"explain":"সঠিক উত্তর: জাতীয়তাবাদ, সমাজতন্ত্র, গণতন্ত্র ও ধর্মনিরপেক্ষতা।"},{"q":"বাংলাদেশের প্রথম অস্থায়ী রাষ্ট্রপতি—সঠিক উত্তর কোনটি?","options":["সৈয়দ নজরুল ইসলাম","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: সৈয়দ নজরুল ইসলাম।"},{"q":"বাংলাদেশের প্রথম প্রধানমন্ত্রী—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬","তাজউদ্দীন আহমদ"],"answer":3,"explain":"সঠিক উত্তর: তাজউদ্দীন আহমদ।"},{"q":"বাংলাদেশের প্রথম নারী প্রধানমন্ত্রী—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","খালেদা জিয়া","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: খালেদা জিয়া।"},{"q":"বাংলাদেশের প্রথম নারী স্পিকার—সঠিক উত্তর কোনটি?","options":["১০:৬","শিরীন শারমিন চৌধুরী","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: শিরীন শারমিন চৌধুরী।"},{"q":"বাংলাদেশের প্রথম নারী বিচারপতি—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","নাজমুন আরা সুলতানা","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: নাজমুন আরা সুলতানা।"},{"q":"বাংলাদেশের প্রথম এভারেস্ট বিজয়ী—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","মুসা ইব্রাহীম","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: মুসা ইব্রাহীম।"},{"q":"বাংলাদেশের প্রথম নারী এভারেস্ট বিজয়ী—সঠিক উত্তর কোনটি?","options":["১০:৬","নিশাত মজুমদার","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: নিশাত মজুমদার।"},{"q":"বাংলাদেশের প্রথম ও একমাত্র নোবেলজয়ী—সঠিক উত্তর কোনটি?","options":["ড. মুহাম্মদ ইউনূস","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: ড. মুহাম্মদ ইউনূস।"},{"q":"বাংলাদেশের জাতীয় সংসদ ভবনের নির্মাণকাজ শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯৬১ সালে","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: ১৯৬১ সালে।"},{"q":"বাংলাদেশের জাতীয় সংসদ ভবন উদ্বোধন করা হয়—সঠিক উত্তর কোনটি?","options":["১৯৮২ সালে","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: ১৯৮২ সালে।"},{"q":"বাংলাদেশের মুক্তিযুদ্ধের বিজয় অর্জিত হয়—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১৬ ডিসেম্বর ১৯৭১"],"answer":3,"explain":"সঠিক উত্তর: ১৬ ডিসেম্বর ১৯৭১।"},{"q":"মুক্তিযুদ্ধের সময় প্রবাসী সরকারের শপথস্থল—সঠিক উত্তর কোনটি?","options":["বৈদ্যনাথতলা, মেহেরপুর","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: বৈদ্যনাথতলা, মেহেরপুর।"},{"q":"বৈদ্যনাথতলার নতুন নামকরণ করা হয়—সঠিক উত্তর কোনটি?","options":["মুজিবনগর","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: মুজিবনগর।"},{"q":"অপারেশন জ্যাকপট পরিচালিত হয়—সঠিক উত্তর কোনটি?","options":["১৯৭১ সালে","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: ১৯৭১ সালে।"},{"q":"বাংলাদেশের স্বাধীনতার ঘোষণাপত্র জারি হয়—সঠিক উত্তর কোনটি?","options":["১০ এপ্রিল ১৯৭১","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: ১০ এপ্রিল ১৯৭১।"},{"q":"স্বাধীনতার ঘোষণাপত্র কার্যকর ধরা হয়—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","২৬ মার্চ ১৯৭১","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: ২৬ মার্চ ১৯৭১।"},{"q":"বাংলাদেশের মুক্তিযুদ্ধে আত্মসমর্পণ দলিলে পাকিস্তানের পক্ষে স্বাক্ষর করেন—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","এ এ কে নিয়াজী"],"answer":3,"explain":"সঠিক উত্তর: এ এ কে নিয়াজী।"},{"q":"বাংলাদেশের পক্ষে আত্মসমর্পণ অনুষ্ঠানে প্রতিনিধিত্ব করেন—সঠিক উত্তর কোনটি?","options":["১০:৬","জগজিৎ সিং অরোরা","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":1,"explain":"সঠিক উত্তর: জগজিৎ সিং অরোরা।"},{"q":"বীরশ্রেষ্ঠ মতিউর রহমানের পদবি—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","ফ্লাইট লেফটেন্যান্ট","১০:৬"],"answer":2,"explain":"সঠিক উত্তর: ফ্লাইট লেফটেন্যান্ট।"},{"q":"বীরশ্রেষ্ঠ হামিদুর রহমানের পদবি—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","সিপাহি","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: সিপাহি।"},{"q":"বাংলাদেশের প্রথম আদমশুমারি অনুষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১০:৬","১৯৭৪ সালে","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":1,"explain":"সঠিক উত্তর: ১৯৭৪ সালে।"},{"q":"বাংলাদেশের জাতীয় সংসদের প্রথম অধিবেশন বসে—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬","১৯৭৩ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯৭৩ সালে।"},{"q":"বাংলাদেশের প্রথম পঞ্চবার্ষিক পরিকল্পনা শুরু হয়—সঠিক উত্তর কোনটি?","options":["১৯৭৩ সালে","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: ১৯৭৩ সালে।"},{"q":"বাংলাদেশের কেন্দ্রীয় শহীদ মিনার উদ্বোধন করা হয়—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","১৯৬৩ সালে","রবীন্দ্রনাথ ঠাকুর"],"answer":2,"explain":"সঠিক উত্তর: ১৯৬৩ সালে।"},{"q":"বাংলা নববর্ষের প্রথম দিন—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১ বৈশাখ","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: ১ বৈশাখ।"},{"q":"বাংলা একাডেমির প্রথম মহাপরিচালক—সঠিক উত্তর কোনটি?","options":["মুহম্মদ এনামুল হক","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: মুহম্মদ এনামুল হক।"},{"q":"একুশে পদক প্রবর্তিত হয়—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১৯৭৬ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯৭৬ সালে।"},{"q":"স্বাধীনতা পুরস্কার প্রবর্তিত হয়—সঠিক উত্তর কোনটি?","options":["১৯৭৭ সালে","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: ১৯৭৭ সালে।"},{"q":"বাংলাদেশের জাতীয় জাদুঘর প্রতিষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১৯১৩ সালে","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: ১৯১৩ সালে।"},{"q":"বাংলাদেশের জাতীয় গ্রন্থাগারের নাম—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","বাংলাদেশ জাতীয় গ্রন্থাগার"],"answer":3,"explain":"সঠিক উত্তর: বাংলাদেশ জাতীয় গ্রন্থাগার।"},{"q":"বাংলাদেশের প্রথম বেসরকারি বিশ্ববিদ্যালয়—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","নর্থ সাউথ ইউনিভার্সিটি"],"answer":3,"explain":"সঠিক উত্তর: নর্থ সাউথ ইউনিভার্সিটি।"},{"q":"বাংলাদেশের প্রথম নারী বিশ্ববিদ্যালয় উপাচার্য—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১০:৬","ফারজানা ইসলাম","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: ফারজানা ইসলাম।"},{"q":"বাংলাদেশের প্রথম কৃত্রিম উপগ্রহের উৎক্ষেপণ স্থান—সঠিক উত্তর কোনটি?","options":["কেপ ক্যানাভেরাল","১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: কেপ ক্যানাভেরাল।"},{"q":"বাংলাদেশের স্থলসীমান্ত রয়েছে কয়টি দেশের সঙ্গে—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর","২টি"],"answer":3,"explain":"সঠিক উত্তর: ২টি।"},{"q":"বাংলাদেশের সঙ্গে ভারতের সীমান্তবর্তী রাজ্যের সংখ্যা—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১০:৬","৫টি","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: ৫টি।"},{"q":"বাংলাদেশের সঙ্গে মিয়ানমারের সীমান্তবর্তী জেলা—সঠিক উত্তর কোনটি?","options":["বান্দরবান ও কক্সবাজার","১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: বান্দরবান ও কক্সবাজার।"},{"q":"বাংলাদেশের বৃহত্তম জেলা (আয়তনে)—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","রাঙামাটি","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: রাঙামাটি।"},{"q":"বাংলাদেশের ক্ষুদ্রতম জেলা (আয়তনে)—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর","নারায়ণগঞ্জ"],"answer":3,"explain":"সঠিক উত্তর: নারায়ণগঞ্জ।"},{"q":"বাংলাদেশের সবচেয়ে উত্তরের জেলা—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","পঞ্চগড়","রবীন্দ্রনাথ ঠাকুর"],"answer":2,"explain":"সঠিক উত্তর: পঞ্চগড়।"},{"q":"বাংলাদেশের সবচেয়ে দক্ষিণের জেলা—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","কক্সবাজার","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: কক্সবাজার।"},{"q":"বাংলাদেশের সবচেয়ে পূর্বের জেলা—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","বান্দরবান"],"answer":3,"explain":"সঠিক উত্তর: বান্দরবান।"},{"q":"বাংলাদেশের সবচেয়ে পশ্চিমের জেলা—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬","চাঁপাইনবাবগঞ্জ"],"answer":3,"explain":"সঠিক উত্তর: চাঁপাইনবাবগঞ্জ।"},{"q":"বাংলাদেশের বৃহত্তম উপজেলা (আয়তনে)—সঠিক উত্তর কোনটি?","options":["১০:৬","শ্যামনগর","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: শ্যামনগর।"},{"q":"বাংলাদেশের বৃহত্তম বনভূমি—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","সুন্দরবন","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: সুন্দরবন।"},{"q":"সুন্দরবনের প্রধান বৃক্ষ—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","সুন্দরী","রবীন্দ্রনাথ ঠাকুর"],"answer":2,"explain":"সঠিক উত্তর: সুন্দরী।"},{"q":"সুন্দরবনের রয়েল বেঙ্গল টাইগার কোন প্রাণী—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","বাঘ"],"answer":3,"explain":"সঠিক উত্তর: বাঘ।"},{"q":"বাংলাদেশের প্রধান খাদ্যশস্য—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","ধান","১০:৬"],"answer":2,"explain":"সঠিক উত্তর: ধান।"},{"q":"বাংলাদেশের প্রধান অর্থকরী ফসল—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","পাট","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: পাট।"},{"q":"বাংলাদেশের সোনালি আঁশ বলা হয়—সঠিক উত্তর কোনটি?","options":["পাটকে","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: পাটকে।"},{"q":"বাংলাদেশের প্রধান রপ্তানি পণ্য—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","তৈরি পোশাক","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: তৈরি পোশাক।"},{"q":"বাংলাদেশের প্রথম চা বাগান—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১০:৬","মালনীছড়া","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: মালনীছড়া।"},{"q":"মালনীছড়া চা বাগান অবস্থিত—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","সিলেটে","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: সিলেটে।"},{"q":"বাংলাদেশের বৃহত্তম কয়লাখনি—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","বড়পুকুরিয়া"],"answer":3,"explain":"সঠিক উত্তর: বড়পুকুরিয়া।"},{"q":"বড়পুকুরিয়া কয়লাখনি অবস্থিত—সঠিক উত্তর কোনটি?","options":["দিনাজপুরে","১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: দিনাজপুরে।"},{"q":"বাংলাদেশের প্রথম তেলক্ষেত্র—সঠিক উত্তর কোনটি?","options":["হরিপুর","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: হরিপুর।"},{"q":"হরিপুর তেলক্ষেত্র অবস্থিত—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","সিলেটে"],"answer":3,"explain":"সঠিক উত্তর: সিলেটে।"},{"q":"বাংলাদেশের প্রথম পানি জাদুঘর—সঠিক উত্তর কোনটি?","options":["পটুয়াখালীতে","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: পটুয়াখালীতে।"},{"q":"বিশ্বের বৃহত্তম মহাদেশ এশিয়ার আয়তন প্রায়—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","৪৪.৬ মিলিয়ন বর্গকিলোমিটার","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: ৪৪.৬ মিলিয়ন বর্গকিলোমিটার।"},{"q":"পৃথিবীর দীর্ঘতম নদী হিসেবে সাধারণত পরিচিত—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","নীল নদ","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: নীল নদ।"},{"q":"পৃথিবীর সর্বোচ্চ জলপ্রপাত—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","অ্যাঞ্জেল জলপ্রপাত","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: অ্যাঞ্জেল জলপ্রপাত।"},{"q":"পৃথিবীর বৃহত্তম প্রবালপ্রাচীর—সঠিক উত্তর কোনটি?","options":["গ্রেট ব্যারিয়ার রিফ","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: গ্রেট ব্যারিয়ার রিফ।"},{"q":"গ্রেট ব্যারিয়ার রিফ অবস্থিত—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","অস্ট্রেলিয়ার উপকূলে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":1,"explain":"সঠিক উত্তর: অস্ট্রেলিয়ার উপকূলে।"},{"q":"পৃথিবীর শীতলতম মহাদেশ—সঠিক উত্তর কোনটি?","options":["অ্যান্টার্কটিকা","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: অ্যান্টার্কটিকা।"},{"q":"পৃথিবীর উষ্ণতম মহাদেশ—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে","আফ্রিকা"],"answer":3,"explain":"সঠিক উত্তর: আফ্রিকা।"},{"q":"পৃথিবীর বৃহত্তম উপদ্বীপ—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","আরব উপদ্বীপ","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: আরব উপদ্বীপ।"},{"q":"পৃথিবীর বৃহত্তম উপসাগর—সঠিক উত্তর কোনটি?","options":["বঙ্গোপসাগর","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: বঙ্গোপসাগর।"},{"q":"পৃথিবীর গভীরতম স্থলভাগীয় হ্রদ—সঠিক উত্তর কোনটি?","options":["বৈকাল হ্রদ","১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: বৈকাল হ্রদ।"},{"q":"মাউন্ট কিলিমানজারো অবস্থিত—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","তানজানিয়ায়"],"answer":3,"explain":"সঠিক উত্তর: তানজানিয়ায়।"},{"q":"মাউন্ট ফুজি অবস্থিত—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","জাপানে","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: জাপানে।"},{"q":"আল্পস পর্বতমালা অবস্থিত—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","ইউরোপে","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: ইউরোপে।"},{"q":"রকি পর্বতমালা অবস্থিত—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬","উত্তর আমেরিকায়"],"answer":3,"explain":"সঠিক উত্তর: উত্তর আমেরিকায়।"},{"q":"আন্দিজ পর্বতমালা অবস্থিত—সঠিক উত্তর কোনটি?","options":["দক্ষিণ আমেরিকায়","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: দক্ষিণ আমেরিকায়।"},{"q":"সুয়েজ খাল যুক্ত করেছে—সঠিক উত্তর কোনটি?","options":["ভূমধ্যসাগর ও লোহিত সাগর","১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: ভূমধ্যসাগর ও লোহিত সাগর।"},{"q":"পানামা খাল যুক্ত করেছে—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","আটলান্টিক ও প্রশান্ত মহাসাগর","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: আটলান্টিক ও প্রশান্ত মহাসাগর।"},{"q":"জিব্রাল্টার প্রণালি পৃথক করেছে—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","ইউরোপ ও আফ্রিকা","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":1,"explain":"সঠিক উত্তর: ইউরোপ ও আফ্রিকা।"},{"q":"বেরিং প্রণালি পৃথক করেছে—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","এশিয়া ও উত্তর আমেরিকা","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: এশিয়া ও উত্তর আমেরিকা।"},{"q":"মালাক্কা প্রণালি অবস্থিত—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","মালয় উপদ্বীপ ও সুমাত্রার মাঝে","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: মালয় উপদ্বীপ ও সুমাত্রার মাঝে।"},{"q":"গ্রিনিচ মানমন্দির অবস্থিত—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","লন্ডনে","১০:৬"],"answer":2,"explain":"সঠিক উত্তর: লন্ডনে।"},{"q":"আন্তর্জাতিক তারিখরেখা প্রায় অনুসরণ করে—সঠিক উত্তর কোনটি?","options":["১৮০° দ্রাঘিমা","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":0,"explain":"সঠিক উত্তর: ১৮০° দ্রাঘিমা।"},{"q":"নিরক্ষরেখার অক্ষাংশ—সঠিক উত্তর কোনটি?","options":["০°","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: ০°।"},{"q":"কর্কটক্রান্তি রেখার অক্ষাংশ—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","২৩.৫° উত্তর","১০:৬"],"answer":2,"explain":"সঠিক উত্তর: ২৩.৫° উত্তর।"},{"q":"মকরক্রান্তি রেখার অক্ষাংশ—সঠিক উত্তর কোনটি?","options":["২৩.৫° দক্ষিণ","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: ২৩.৫° দক্ষিণ।"},{"q":"পৃথিবীর অক্ষের হেলানো কোণ প্রায়—সঠিক উত্তর কোনটি?","options":["২৩.৫°","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: ২৩.৫°।"},{"q":"পৃথিবী সূর্যকে একবার প্রদক্ষিণ করে—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১০:৬","জাতীয় সংগীত হিসেবে","প্রায় ৩৬৫ দিন ৬ ঘণ্টায়"],"answer":3,"explain":"সঠিক উত্তর: প্রায় ৩৬৫ দিন ৬ ঘণ্টায়।"},{"q":"চাঁদের নিজস্ব আলো নেই, এটি—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","সূর্যের আলো প্রতিফলিত করে"],"answer":3,"explain":"সঠিক উত্তর: সূর্যের আলো প্রতিফলিত করে।"},{"q":"সূর্যের নিকটতম গ্রহ—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","বুধ","১০:৬"],"answer":2,"explain":"সঠিক উত্তর: বুধ।"},{"q":"সৌরজগতের বৃহত্তম গ্রহ—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","বৃহস্পতি","রবীন্দ্রনাথ ঠাকুর"],"answer":2,"explain":"সঠিক উত্তর: বৃহস্পতি।"},{"q":"সৌরজগতের ক্ষুদ্রতম গ্রহ—সঠিক উত্তর কোনটি?","options":["বুধ","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: বুধ।"},{"q":"লাল গ্রহ বলা হয়—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১০:৬","মঙ্গলকে","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: মঙ্গলকে।"},{"q":"শুক্র গ্রহের বায়ুমণ্ডলে প্রধান গ্যাস—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","১০:৬","কার্বন ডাই-অক্সাইড","রবীন্দ্রনাথ ঠাকুর"],"answer":2,"explain":"সঠিক উত্তর: কার্বন ডাই-অক্সাইড।"},{"q":"শনির বলয় প্রধানত গঠিত—সঠিক উত্তর কোনটি?","options":["বরফ ও শিলাখণ্ডে","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: বরফ ও শিলাখণ্ডে।"},{"q":"সূর্যের শক্তির উৎস—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","নিউক্লীয় সংযোজন","রবীন্দ্রনাথ ঠাকুর","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: নিউক্লীয় সংযোজন।"},{"q":"পৃথিবীর একমাত্র প্রাকৃতিক উপগ্রহ—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","চাঁদ"],"answer":3,"explain":"সঠিক উত্তর: চাঁদ।"},{"q":"মহাকাশে প্রথম মানুষ—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","ইউরি গ্যাগারিন","জাতীয় সংগীত হিসেবে","১০:৬"],"answer":1,"explain":"সঠিক উত্তর: ইউরি গ্যাগারিন।"},{"q":"মহাকাশে প্রথম নারী—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","ভ্যালেন্তিনা তেরেশকোভা","১০:৬"],"answer":2,"explain":"সঠিক উত্তর: ভ্যালেন্তিনা তেরেশকোভা।"},{"q":"চাঁদে প্রথম পদার্পণকারী মানুষ—সঠিক উত্তর কোনটি?","options":["নীল আর্মস্ট্রং","১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে"],"answer":0,"explain":"সঠিক উত্তর: নীল আর্মস্ট্রং।"},{"q":"প্রথম কৃত্রিম উপগ্রহ—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","স্পুটনিক-১","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":1,"explain":"সঠিক উত্তর: স্পুটনিক-১।"},{"q":"নাসা প্রতিষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১৯৫৮ সালে","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: ১৯৫৮ সালে।"},{"q":"ইন্টারনেটের পূর্বসূরি ARPANET চালু হয়—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১৯৬৯ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯৬৯ সালে।"},{"q":"ই-মেইল ব্যবস্থার উদ্ভাবক হিসেবে পরিচিত—সঠিক উত্তর কোনটি?","options":["রে টমলিনসন","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: রে টমলিনসন।"},{"q":"প্রথম ওয়েবসাইট তৈরি করেন—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬","টিম বার্নার্স-লি"],"answer":3,"explain":"সঠিক উত্তর: টিম বার্নার্স-লি।"},{"q":"সার্চ ইঞ্জিন গুগল প্রতিষ্ঠিত হয়—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১৯৯৮ সালে"],"answer":3,"explain":"সঠিক উত্তর: ১৯৯৮ সালে।"},{"q":"মাইক্রোসফট প্রতিষ্ঠা করেন—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬","বিল গেটস ও পল অ্যালেন"],"answer":3,"explain":"সঠিক উত্তর: বিল গেটস ও পল অ্যালেন।"},{"q":"অ্যাপল প্রতিষ্ঠা করেন—সঠিক উত্তর কোনটি?","options":["১০:৬","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","স্টিভ জবস, স্টিভ ওজনিয়াক ও রোনাল্ড ওয়েন"],"answer":3,"explain":"সঠিক উত্তর: স্টিভ জবস, স্টিভ ওজনিয়াক ও রোনাল্ড ওয়েন।"},{"q":"লিনাক্স কার্নেলের স্রষ্টা—সঠিক উত্তর কোনটি?","options":["১০:৬","লিনাস টরভাল্ডস","জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর"],"answer":1,"explain":"সঠিক উত্তর: লিনাস টরভাল্ডস।"},{"q":"পাইথন প্রোগ্রামিং ভাষার স্রষ্টা—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","গুইডো ভ্যান রসম","১০:৬","জাতীয় সংগীত হিসেবে"],"answer":1,"explain":"সঠিক উত্তর: গুইডো ভ্যান রসম।"},{"q":"জাভা প্রোগ্রামিং ভাষার মূল নির্মাতা—সঠিক উত্তর কোনটি?","options":["জেমস গসলিং","জাতীয় সংগীত হিসেবে","১০:৬","রবীন্দ্রনাথ ঠাকুর"],"answer":0,"explain":"সঠিক উত্তর: জেমস গসলিং।"},{"q":"বিশ্বের প্রথম সাধারণ-উদ্দেশ্য ইলেকট্রনিক কম্পিউটার হিসেবে পরিচিত—সঠিক উত্তর কোনটি?","options":["১০:৬","রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","ENIAC"],"answer":3,"explain":"সঠিক উত্তর: ENIAC।"},{"q":"QR কোড উদ্ভাবিত হয়—সঠিক উত্তর কোনটি?","options":["জাতীয় সংগীত হিসেবে","রবীন্দ্রনাথ ঠাকুর","১০:৬","জাপানে"],"answer":3,"explain":"সঠিক উত্তর: জাপানে।"},{"q":"ব্লুটুথ প্রযুক্তির নাম এসেছে—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","১০:৬","হ্যারাল্ড ব্লুটুথের নাম থেকে","জাতীয় সংগীত হিসেবে"],"answer":2,"explain":"সঠিক উত্তর: হ্যারাল্ড ব্লুটুথের নাম থেকে।"},{"q":"Wi-Fi মূলত ব্যবহৃত হয়—সঠিক উত্তর কোনটি?","options":["রবীন্দ্রনাথ ঠাকুর","জাতীয় সংগীত হিসেবে","১০:৬","তারবিহীন নেটওয়ার্ক সংযোগে"],"answer":3,"explain":"সঠিক উত্তর: তারবিহীন নেটওয়ার্ক সংযোগে।"}],
        'বাংলাদেশ বিষয়াবলি ও সংবিধান': [
          ['বাংলাদেশের জাতীয় সংসদ কেমন?',['এককক্ষবিশিষ্ট','দ্বিকক্ষবিশিষ্ট','তিনকক্ষবিশিষ্ট','চারকক্ষবিশিষ্ট'],0],
          ['বাংলাদেশের সংবিধান কার্যকর হয় কবে?',['১৬ ডিসেম্বর ১৯৭২','৪ নভেম্বর ১৯৭২','২৬ মার্চ ১৯৭৩','৭ মার্চ ১৯৭২'],0],
          ['বাংলাদেশের রাষ্ট্রভাষা কী?',['বাংলা','ইংরেজি','উর্দু','আরবি'],0],
          ['বাংলাদেশের জাতীয় ফুল কোনটি?',['শাপলা','গোলাপ','জবা','বেলি'],0],
          ['বাংলাদেশের জাতীয় ফল কোনটি?',['কাঁঠাল','আম','লিচু','নারিকেল'],0],
          ['বাংলাদেশের জাতীয় মাছ কোনটি?',['ইলিশ','রুই','কাতলা','চিংড়ি'],0],
          ['বাংলাদেশের জাতীয় পাখি কোনটি?',['দোয়েল','ময়না','শালিক','কোকিল'],0],
          ['বাংলাদেশের জাতীয় স্মৃতিসৌধ কোথায়?',['সাভার','মিরপুর','গাজীপুর','টঙ্গী'],0],
          ['বাংলাদেশের কেন্দ্রীয় ব্যাংকের নাম কী?',['বাংলাদেশ ব্যাংক','সোনালী ব্যাংক','অগ্রণী ব্যাংক','জনতা ব্যাংক'],0],
          ['বাংলাদেশের জাতীয় পতাকার নকশাকার কে?',['কামরুল হাসান','জয়নুল আবেদিন','হামিদুর রহমান','শিল্পাচার্য'],0],
          ['বাংলাদেশের জাতীয় কবি কে?',['কাজী নজরুল ইসলাম','রবীন্দ্রনাথ ঠাকুর','জসীমউদ্দীন','শামসুর রাহমান'],0],
          ['বাংলাদেশের সর্বোচ্চ বেসামরিক রাষ্ট্রীয় পুরস্কার কোনটি?',['স্বাধীনতা পুরস্কার','একুশে পদক','বাংলা একাডেমি পুরস্কার','জাতীয় চলচ্চিত্র পুরস্কার'],0]
        ].map(([q,o,a])=>({q,options:o,answer:a,explain:`সঠিক উত্তর: ${o[a]}`}))
      }
    },
    COMMERCE: {
      label: 'ব্যবসায় শিক্ষা বিভাগ', subjects: {
        'হিসাববিজ্ঞান': [
          ['হিসাববিজ্ঞানের মূল সমীকরণ কোনটি?','সম্পদ = দায় + মালিকানা স্বত্ব'],['লেনদেন লিপিবদ্ধ করার প্রথম বই কোনটি?','জাবেদা'],['খতিয়ানের ইংরেজি নাম কী?','Ledger'],['নগদ বই কোন ধরনের বই?','প্রাথমিক হিসাবের বই'],['অবচয় কোন সম্পদের ক্ষেত্রে ধার্য হয়?','স্থায়ী সম্পদ'],['বকেয়া খরচ কী?','পরিশোধ না করা ব্যয়'],['অগ্রিম আয় কী?','আগে প্রাপ্ত কিন্তু অর্জিত নয় এমন আয়'],['মূলধন বৃদ্ধি পায় কোন পাশে?','ক্রেডিট'],['সম্পদ বৃদ্ধি পায় কোন পাশে?','ডেবিট'],['ব্যক্তিবাচক হিসাবের নিয়ম কী?','গ্রহীতাকে ডেবিট, দাতাকে ক্রেডিট'],['নগদে পণ্য ক্রয় হলে কোন হিসাব ডেবিট?','ক্রয় হিসাব'],['ব্যাংক জমার হিসাব কোন শ্রেণির?','সম্পদ'],['ট্রায়াল ব্যালেন্সের উদ্দেশ্য কী?','গাণিতিক শুদ্ধতা যাচাই'],['আর্থিক অবস্থার বিবরণী কী দেখায়?','নির্দিষ্ট তারিখে আর্থিক অবস্থা'],['আয় বিবরণী কী নির্ণয় করে?','নিট লাভ বা ক্ষতি']
        ].map(([q,a],i)=>({q,options:[a,['ব্যয়','দায়','মূলধন'][i%3],['সম্পদ','আয়','উত্তোলন'][(i+1)%3],['জাবেদা','খতিয়ান','রেওয়ামিল'][(i+2)%3]],answer:0,explain:`সঠিক উত্তর: ${a}`})),
        'ব্যবসায় সংগঠন ও ব্যবস্থাপনা': [
          ['একক মালিকানা ব্যবসায় মালিকের সংখ্যা কত?','একজন'],['অংশীদারি ব্যবসায় ন্যূনতম অংশীদার কতজন?','দুইজন'],['কোম্পানির পৃথক আইনগত সত্তা থাকে কি?','হ্যাঁ'],['ব্যবস্থাপনার প্রথম কাজ কোনটি?','পরিকল্পনা'],['কর্মীদের কাজে উদ্বুদ্ধ করাকে কী বলে?','প্রেষণা'],['কাজ ভাগ করে দেওয়ার প্রক্রিয়া কী?','সংগঠিতকরণ'],['নিয়ন্ত্রণের মূল উদ্দেশ্য কী?','পরিকল্পনা অনুযায়ী কাজ হচ্ছে কি না যাচাই'],['উদ্যোক্তার প্রধান বৈশিষ্ট্য কী?','ঝুঁকি গ্রহণ'],['বাজারজাতকরণের 4P-এর একটি কী?','Product'],['ভোক্তার চাহিদা পূরণে পণ্য সরবরাহ কোন কাজ?','বিপণন']
        ].map(([q,a],i)=>({q,options:[a,'অর্থায়ন','নিয়ন্ত্রণ','নিরীক্ষা'],answer:0,explain:`সঠিক উত্তর: ${a}`})),
        'অর্থনীতি ও ফিন্যান্স': [
          ['অর্থনীতির মূল সমস্যা কী?','সম্পদের সীমাবদ্ধতা ও অসীম অভাব'],['চাহিদার সূত্রে দাম বাড়লে সাধারণত চাহিদা কী হয়?','কমে'],['বাংলাদেশের কেন্দ্রীয় ব্যাংক কোনটি?','বাংলাদেশ ব্যাংক'],['মুদ্রাস্ফীতি বলতে কী বোঝায়?','সাধারণ মূল্যস্তরের ধারাবাহিক বৃদ্ধি'],['GDP-এর পূর্ণরূপ কী?','Gross Domestic Product'],['রাজস্ব নীতি পরিচালনা করে কে?','সরকার'],['মুদ্রানীতি পরিচালনা করে কে?','কেন্দ্রীয় ব্যাংক'],['সঞ্চয় কী?','আয় থেকে ভোগ বাদ দিলে অবশিষ্ট'],['বাণিজ্যিক ব্যাংকের প্রধান কাজ কী?','আমানত গ্রহণ ও ঋণ প্রদান'],['রপ্তানি আয় কোন হিসাবে অন্তর্ভুক্ত?','চলতি হিসাব']
        ].map(([q,a])=>({q,options:[a,'মূলধন ক্ষয়','বেকারত্ব','বাজেট ঘাটতি'],answer:0,explain:`সঠিক উত্তর: ${a}`})),
        'বাংলা ও English': uniqueQuestions(IHT_BN_QUIZ_BANK['বাংলা ও ইংরেজি'], IHT_QUIZ_BANK.English)
      }
    }
  };
  const VARSITY_STREAM_ORDER = ['SCIENCE','HUMANITIES','COMMERCE'];
  // Expand each subject with clearly-labelled practice variants. These are NOT
  // represented as verbatim official previous-year questions.
  function buildPracticeVariants(seedQuestions, minimum = 200) {
    const source = uniqueQuestions(seedQuestions || []);
    if (!source.length) return [];
    const variants = [...source];
    const wrappers = [
      (q) => `নিচের প্রশ্নটির সঠিক উত্তর নির্বাচন কর: ${q}`,
      (q) => `ভর্তি পরীক্ষার অনুশীলন — ${q}`,
      (q) => `বিষয়ভিত্তিক MCQ: ${q}`,
      (q) => `সঠিক তথ্যটি চিহ্নিত কর: ${q}`,
      (q) => `নিচের কোন উত্তরটি যথার্থ? ${q}`,
      (q) => `জ্ঞান যাচাই: ${q}`,
      (q) => `অনুশীলনী প্রশ্ন: ${q}`,
      (q) => `পরীক্ষায় আসতে পারে— ${q}`
    ];
    let round = 0;
    while (variants.length < minimum && round < 100) {
      for (let i = 0; i < source.length && variants.length < minimum; i++) {
        const base = source[i];
        const stem = wrappers[round % wrappers.length](base.q);
        const qText = `${stem} [সেট ${round + 1}]`;
        if (variants.some((item) => item.q === qText)) continue;
        const shift = (round + i + 1) % base.options.length;
        const options = base.options.map((_, optionIndex) => base.options[(optionIndex + shift) % base.options.length]);
        const answer = (base.answer - shift + base.options.length) % base.options.length;
        variants.push({ q: qText, options, answer,
          explain: `${base.explain || `সঠিক উত্তর: ${base.options[base.answer]}`} (মূল ধারণাভিত্তিক অনুশীলনী রূপ)।` });
      }
      round++;
    }
    return variants;
  }
  Object.values(VARSITY_STREAM_BANKS).forEach((stream) => {
    Object.keys(stream.subjects).forEach((subject) => {
      if (/সাধারণ জ্ঞান|\bGK\b|General Knowledge/i.test(subject)) {
        delete stream.subjects[subject];
      } else {
        stream.subjects[subject] = buildPracticeVariants(stream.subjects[subject], 200);
      }
    });
  });
  const VARSITY_TOTAL = Object.values(VARSITY_STREAM_BANKS).reduce((n,stream)=>n+Object.values(stream.subjects).reduce((m,qs)=>m+qs.length,0),0);


  // ---------- National University admission practice banks ----------
  // NU uses the same subject-wise practice pool; GK is intentionally excluded.
  const NU_STREAM_BANKS = {
    SCIENCE: { label: 'বিজ্ঞান বিভাগ', subjects: {
      ...VARSITY_STREAM_BANKS.SCIENCE.subjects
    }},
    HUMANITIES: { label: 'মানবিক বিভাগ', subjects: { ...VARSITY_STREAM_BANKS.HUMANITIES.subjects } },
    COMMERCE: { label: 'ব্যবসায় শিক্ষা বিভাগ', subjects: {
      ...VARSITY_STREAM_BANKS.COMMERCE.subjects
    }}
  };
  const NU_STREAM_ORDER = ['SCIENCE','HUMANITIES','COMMERCE'];

  const GST_SUBJECTS = ['GST Physics', 'GST Chemistry', 'GST Math', 'GST Biology', 'GST English', 'GST Bangla'];
  let quizNegativeMarking = false;

  // ---------- Utility ----------
  function uid() {
    return 'id_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function todayStr() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function daysBetween(a, b) {
    // Parse date-only values in UTC to avoid DST and local-time drift.
    const parse = (value) => {
      const parts = String(value || '').split('-').map(Number);
      return parts.length === 3 && parts.every(Number.isFinite)
        ? Date.UTC(parts[0], parts[1] - 1, parts[2])
        : NaN;
    };
    return Math.round((parse(b) - parse(a)) / 86400000);
  }

  function addActivity(text) {
    state.activity.unshift({ text, date: new Date().toISOString() });
    if (state.activity.length > 30) state.activity.pop();
    saveData();
  }

  function updateStreak() {
    const today = todayStr();
    if (state.lastStudyDate === today) return;
    if (state.lastStudyDate) {
      const diff = daysBetween(state.lastStudyDate, today);
      if (diff === 1) state.streak += 1;
      else if (diff > 1) state.streak = 1;
    } else {
      state.streak = 1;
    }
    state.lastStudyDate = today;
    saveData();
  }

  // ---------- Navigation ----------
  const sections = document.querySelectorAll('.section');
  const navBtns = document.querySelectorAll('.nav-btn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const menuToggle = document.getElementById('menuToggle');

  function showSection(id) {
    sections.forEach((s) => s.classList.toggle('active', s.id === id));
    navBtns.forEach((b) => b.classList.toggle('active', b.dataset.section === id));
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
    // Refresh section data
    if (id === 'dashboard') renderDashboard();
    if (id === 'memories') renderMemories();
    if (id === 'notes') renderNotes();
    if (id === 'planner') renderPlanner();
    if (id === 'progress') renderProgress();
    if (id === 'resources') renderResources();
    if (id === 'askgoogle') renderAskGoogle();
    if (id === 'admission') { /* static section; buttons wired below */ }
    if (id === 'quiz') renderQuizSetup();
  }

  navBtns.forEach((btn) => {
    btn.addEventListener('click', () => showSection(btn.dataset.section));
  });

  document.querySelectorAll('[data-goto]').forEach((btn) => {
    btn.addEventListener('click', () => {
      showSection(btn.dataset.goto);
      const targetId = btn.dataset.scrollTarget;
      if (targetId) {
        requestAnimationFrame(() => {
          const target = document.getElementById(targetId);
          if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
      }
    });
  });

  menuToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('show');
  });
  overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });

  // ---------- Global search ----------
  const searchToggle = document.getElementById('searchToggle');
  const globalSearch = document.getElementById('globalSearch');
  const searchInput = document.getElementById('searchInput');
  const searchResults = document.getElementById('searchResults');

  searchToggle.addEventListener('click', () => {
    globalSearch.classList.toggle('show');
    if (globalSearch.classList.contains('show')) searchInput.focus();
  });

  searchInput.addEventListener('input', () => {
    const q = searchInput.value.trim().toLowerCase();
    if (q.length < 2) {
      searchResults.classList.remove('show');
      searchResults.innerHTML = '';
      return;
    }
    const hits = [];
    state.notes.forEach((n) => {
      if ((n.title + ' ' + n.body).toLowerCase().includes(q)) {
        hits.push({ type: 'Note', label: n.title || 'Untitled', action: () => { showSection('notes'); selectNote(n.id); } });
      }
    });
    state.cards.forEach((c) => {
      if ((c.front + ' ' + c.back).toLowerCase().includes(q)) {
        hits.push({ type: 'Card', label: c.front.slice(0, 60), action: () => showSection('memories') });
      }
    });
    Object.keys(QUIZ_BANK).forEach((subj) => {
      if (subj.toLowerCase().includes(q)) {
        hits.push({ type: 'Quiz', label: subj + ' quiz', action: () => { showSection('quiz'); startQuiz(subj); } });
      }
    });
    searchResults.innerHTML = hits.slice(0, 8).map((h, i) =>
      `<div class="search-hit" data-i="${i}"><div class="hit-type">${h.type}</div>${escapeHtml(h.label)}</div>`
    ).join('') || '<div class="search-hit">No results</div>';
    searchResults.classList.add('show');
    searchResults.querySelectorAll('.search-hit[data-i]').forEach((el) => {
      el.addEventListener('click', () => {
        hits[+el.dataset.i].action();
        searchResults.classList.remove('show');
        searchInput.value = '';
        globalSearch.classList.remove('show');
      });
    });
  });

  function escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  // ---------- Dashboard ----------
  function renderDashboard() {
    const today = todayStr();
    const studied = state.studyLog[today] || 0;
    const goal = state.goalMinutes || 60;
    document.getElementById('todayGoal').textContent = `${studied} / ${goal} min`;
    document.getElementById('goalProgress').style.width = Math.min(100, (studied / goal) * 100) + '%';
    document.getElementById('dashStreak').textContent = state.streak + ' days';
    document.getElementById('streakCount').textContent = state.streak;

    const due = state.cards.filter((c) => c.due <= Date.now()).length;
    document.getElementById('cardsDue').textContent = due;
    document.getElementById('quizzesTaken').textContent = state.quizHistory.length;

    // Exams
    const exams = [...state.exams].sort((a, b) => a.date.localeCompare(b.date));
    const examEl = document.getElementById('dashExams');
    if (exams.length === 0) {
      examEl.innerHTML = '<li style="color:var(--text-muted)">No exams added yet</li>';
    } else {
      examEl.innerHTML = exams.slice(0, 5).map((e) => {
        const days = daysBetween(today, e.date);
        const label = days < 0 ? 'Past' : days === 0 ? 'Today!' : days + ' days left';
        return `<li><span>${escapeHtml(e.name)}</span><span class="days-left">${label}</span></li>`;
      }).join('');
    }

    // Activity
    const actEl = document.getElementById('activityList');
    if (state.activity.length === 0) {
      actEl.innerHTML = '<li style="color:var(--text-muted)">No activity yet — start studying!</li>';
    } else {
      actEl.innerHTML = state.activity.slice(0, 8).map((a) => {
        const d = new Date(a.date);
        return `<li><span>${escapeHtml(a.text)}</span><span style="color:var(--text-muted);font-size:0.8rem">${d.toLocaleDateString()}</span></li>`;
      }).join('');
    }
  }

  // ---------- Smart Study Assistant (local logic only) ----------
  const chatWindow = document.getElementById('chatWindow');
  const assistantInput = document.getElementById('assistantInput');
  const assistantSend = document.getElementById('assistantSend');

  const KNOWLEDGE = {
    photosynthesis: 'Photosynthesis is how green plants make food. They use sunlight, water (H₂O), and carbon dioxide (CO₂) to produce glucose (C₆H₁₂O₆) and oxygen (O₂). The main equation is: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. It happens in chloroplasts. Light reactions split water; the Calvin cycle builds sugar.',
    'spaced repetition': 'Spaced repetition is a learning technique where you review material at increasing intervals. You study something, wait a bit, review, wait longer, review again. This fights the forgetting curve. STUDY VERSE Memories uses a simple version: when you mark "Remember", the interval grows; "Forgot" resets it shorter. Review daily for best results.',
    mitochondria: 'Mitochondria are organelles often called the "powerhouse of the cell". They generate most of the cell\'s ATP through cellular respiration. They have their own DNA and a double membrane.',
    'study plan': 'A solid 7-day study plan: Day 1–2: Map all topics and gather materials. Day 3–4: Deep study of hardest subjects + active recall (flashcards/quizzes). Day 5: Practice problems and past papers. Day 6: Review weak areas from quiz results. Day 7: Light review + rest. Study in 25–50 min focused blocks with short breaks (Pomodoro). Sleep well — memory consolidates during sleep.',
    formulas: 'To remember formulas better: (1) Understand derivation instead of pure memorization. (2) Write them by hand repeatedly. (3) Use spaced repetition flashcards. (4) Connect to a visual or story. (5) Practice applying them in problems immediately. (6) Teach the formula to someone else.',
    atom: 'An atom is the smallest unit of ordinary matter. It has a nucleus of protons and neutrons, with electrons in orbitals around it. Atomic number = number of protons. Mass number ≈ protons + neutrons.',
    dna: 'DNA (deoxyribonucleic acid) is a double-helix molecule that stores genetic information. Base pairs: A–T and C–G. It is replicated during cell division and transcribed into RNA for protein synthesis.',
    gravity: 'Gravity is the force of attraction between masses. On Earth it gives weight. Newton\'s law: F = G·m₁·m₂/r². Einstein described it as curvature of spacetime in general relativity.',
    photosynthesis: null, // already defined above
  };

  // Fix duplicate key - knowledge already has photosynthesis
  delete KNOWLEDGE.photosynthesis;
  KNOWLEDGE['photosynthesis'] = 'Photosynthesis is how green plants make food. They use sunlight, water (H₂O), and carbon dioxide (CO₂) to produce glucose (C₆H₁₂O₆) and oxygen (O₂). The main equation is: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. It happens in chloroplasts. Light reactions split water; the Calvin cycle builds sugar.';

  function assistantReply(question) {
    const q = question.toLowerCase().trim();

    // Check user notes first
    const noteHits = state.notes.filter((n) =>
      (n.title + ' ' + n.body).toLowerCase().includes(q.split(/\s+/).find((w) => w.length > 3) || q)
    );
    if (noteHits.length && (q.includes('note') || q.includes('summar') || q.includes('my '))) {
      const n = noteHits[0];
      return `From your notes **${n.title || 'Untitled'}**:\n\n${n.body.slice(0, 500)}${n.body.length > 500 ? '…' : ''}`;
    }

    // Keyword knowledge
    for (const [key, val] of Object.entries(KNOWLEDGE)) {
      if (q.includes(key)) return val;
    }

    // Study strategy patterns
    if (/study plan|schedule|how (to|should) study|exam prep/.test(q)) {
      return KNOWLEDGE['study plan'];
    }
    if (/remember|memory|memorize|forget/.test(q)) {
      return KNOWLEDGE.formulas;
    }
    if (/spaced|repetition|anki|flashcard/.test(q)) {
      return KNOWLEDGE['spaced repetition'];
    }
    if (/motivate|lazy|focus|procrastinat/.test(q)) {
      return 'Start tiny: open the book and do 5 minutes. Momentum beats motivation. Use a timer (25 min work / 5 min break). Remove phone from the room. Study the hardest subject first when your energy is highest. Track progress in STUDY VERSE so you can see streaks grow.';
    }
    if (/hello|hi |hey |help/.test(q)) {
      return 'Hi! I can explain common topics (photosynthesis, DNA, atoms, gravity…), give study plans, memory tips, and pull from your saved notes. Ask a specific question or try a tip chip below.';
    }
    if (/gst|ভর্তি|admission|udvash|প্রশ্নব্যাংক|mcq|পদার্থ|রসায়ন|জীববিজ্ঞান/.test(q)) {
      return 'GST / Admission practice is in the **GST / Admission** menu.\n\nSubjects: GST Physics, Chemistry, Math, Biology, English, Bangla.\nScoring: +1 correct, −0.25 wrong (like many admission papers).\n\nOpen **GST / Admission** for practice MCQs (Physics, Chemistry, Math, Biology, English, Bangla) with −0.25 marking. Use **Ask Google** for any syllabus topic in English or বাংলা.';
    }

    // Generic helpful fallback
    return 'I don\'t have a built-in article for that exact topic, but here\'s what you can do:\n\n• Add notes in Notes Library so I can quote them later\n• Create flashcards in Memories for active recall\n• Try Quiz Arena or GST / Admission MCQs\n• Search Resources or Ask Google (English or বাংলা)\n\nTip: Rephrase with a key term like "explain photosynthesis" or "GST physics".';
  }

  function appendMsg(text, isUser) {
    const div = document.createElement('div');
    div.className = 'msg ' + (isUser ? 'user' : 'bot');
    div.innerHTML = `
      <div class="msg-avatar">${isUser ? 'You' : '✦'}</div>
      <div class="msg-body">${text.split('\n').map((p) => `<p>${escapeHtml(p).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</p>`).join('')}</div>
    `;
    chatWindow.appendChild(div);
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

  function sanitizePublicError(msg) {
    // Never surface API keys or long tokens in the UI
    return String(msg || 'Request failed')
      .replace(/AIza[0-9A-Za-z_\-]{10,}/g, '[REDACTED]')
      .replace(/key=[^&\s]+/gi, 'key=[REDACTED]')
      .slice(0, 120);
  }

  async function callGemini(question) {
    const key = (state.settings.geminiKey || '').trim();
    const model = state.settings.geminiModel || 'gemini-2.0-flash';
    if (!key) throw new Error('No API key configured');

    const noteHint = state.notes.slice(0, 5).map((n) =>
      (n.title || 'Note') + ': ' + (n.body || '').slice(0, 200)
    ).join('\n');

    const systemText =
      'You are STUDY VERSE Study Assistant for students (Bangladesh admission / GST friendly). ' +
      'Answer clearly in the same language as the user (English or Bangla). ' +
      'Be accurate, concise, and educational. Use short paragraphs or bullets. ' +
      'If the topic is uncertain, say so. Do not invent exam questions from copyrighted banks. ' +
      (noteHint ? 'User notes (may help):\n' + noteHint : '');

    // Key goes in header only — never in the URL (avoids query-string leaks in logs/history)
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/' +
      encodeURIComponent(model) + ':generateContent';

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': key,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemText }] },
        contents: [{ role: 'user', parts: [{ text: question }] }],
        generationConfig: { temperature: 0.6, maxOutputTokens: 1024 },
      }),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = (data.error && data.error.message) || ('HTTP ' + res.status);
      throw new Error(sanitizePublicError(msg));
    }
    const text = data.candidates &&
      data.candidates[0] &&
      data.candidates[0].content &&
      data.candidates[0].content.parts &&
      data.candidates[0].content.parts.map((p) => p.text || '').join('');
    if (!text) throw new Error('Empty response from AI');
    return text.trim();
  }

  function updateAssistantSubtitle() {
    const el = document.getElementById('assistantSubtitle');
    if (!el) return;
    if ((state.settings.geminiKey || '').trim()) {
      el.textContent = 'Gemini mode (' + (state.settings.geminiModel || 'gemini-2.0-flash') + ') — English & বাংলা.';
    } else {
      el.textContent = 'Study help in English & বাংলা. Optional AI can be enabled in Settings.';
    }
  }

  function updateGeminiStatus(extra) {
    const el = document.getElementById('geminiStatus');
    if (!el) return;
    const has = !!(state.settings.geminiKey || '').trim();
    el.textContent = extra || (has
      ? 'Status: AI ready (' + (state.settings.geminiModel || 'gemini-2.0-flash') + ')'
      : 'Status: standard mode');
  }

  async function sendAssistant() {
    const text = assistantInput.value.trim();
    if (!text) return;
    appendMsg(text, true);
    assistantInput.value = '';
    assistantSend.disabled = true;

    const hasKey = !!(state.settings.geminiKey || '').trim();
    if (hasKey) {
      appendMsg('Thinking with Gemini…', false);
      const thinking = chatWindow.lastElementChild;
      try {
        const reply = await callGemini(text);
        if (thinking && thinking.parentNode) thinking.remove();
        appendMsg(reply, false);
      } catch (err) {
        if (thinking && thinking.parentNode) thinking.remove();
        appendMsg('AI unavailable (' + sanitizePublicError(err.message) + ').\n\nUsing local assistant…\n\n' + assistantReply(text), false);
      }
    } else {
      setTimeout(() => {
        appendMsg(assistantReply(text), false);
      }, 300);
    }
    assistantSend.disabled = false;
  }

  assistantSend.addEventListener('click', sendAssistant);
  assistantInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendAssistant();
  });
  document.querySelectorAll('.chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      assistantInput.value = chip.dataset.q;
      sendAssistant();
    });
  });

  // ---------- Quiz Arena ----------
  let currentQuiz = null; // { subject, questions, index, score }

  function renderQuizSetup(mode) {
    // mode: 'all' | 'gst' | undefined
    document.getElementById('quizSetup').classList.remove('hidden');
    document.getElementById('quizPlay').classList.add('hidden');
    document.getElementById('quizResult').classList.add('hidden');
    const grid = document.getElementById('quizSubjects');
    let keys = Object.keys(QUIZ_BANK);
    if (mode === 'gst') {
      keys = keys.filter((k) => GST_SUBJECTS.includes(k));
      quizNegativeMarking = true;
    } else if (mode === 'general') {
      keys = keys.filter((k) => !GST_SUBJECTS.includes(k));
      quizNegativeMarking = false;
    } else {
      quizNegativeMarking = false;
    }
    grid.innerHTML = keys.map((s) =>
      `<button class="subject-btn" data-subj="${s}">${s}</button>`
    ).join('');
    grid.querySelectorAll('.subject-btn').forEach((btn) => {
      btn.addEventListener('click', () => startQuiz(btn.dataset.subj));
    });

    // Dedicated IHT Admission section: full 320-question mock + 8 subject sets.
    const ihtGrid = document.getElementById('ihtQuizSubjects');
    if (ihtGrid) {
      const ihtCards = [
        `<button class="subject-btn iht-mock-btn" data-subj="IHT Full Mock Test">▶ Full IHT Mock Test <small>320 questions · English</small></button>`,
        ...IHT_SUBJECTS.map((name) => `<button class="subject-btn" data-subj="${name}">${name.replace('IHT ', '')}<small>40 questions · English</small></button>`),
        `<button class="subject-btn iht-mock-btn" data-subj="IHT বাংলা পূর্ণাঙ্গ মডেল টেস্ট">▶ বাংলা পূর্ণাঙ্গ মডেল টেস্ট <small>${IHT_BN_FULL_MOCK.length}টি MCQ</small></button>`,
        ...IHT_BN_SUBJECTS.map((name) => `<button class="subject-btn iht-bn-btn" data-subj="${name}">${name.replace('IHT বাংলা ', '')}<small>${IHT_BN_QUIZ_BANK[name.replace('IHT বাংলা ', '')].length}টি বাংলা MCQ</small></button>`),
        `<div class="iht-subsection-title">নতুন ৩১৫টি বাংলা গুরুত্বপূর্ণ MCQ</div>`,
        `<button class="subject-btn iht-mock-btn" data-subj="IHT নতুন বাংলা পূর্ণাঙ্গ মডেল টেস্ট">▶ নতুন বাংলা পূর্ণাঙ্গ মডেল টেস্ট <small>${IHT_BN_EXTRA_FULL.length}টি নতুন অনুশীলনী প্রশ্ন</small></button>`,
        ...IHT_BN_EXTRA_SUBJECTS.map((name) => `<button class="subject-btn iht-bn-btn" data-subj="${name}">${name.replace('IHT নতুন বাংলা ', '')}<small>${IHT_BN_EXTRA_BANK[name.replace('IHT নতুন বাংলা ', '')].length}টি নতুন MCQ</small></button>`),
        `<div class="iht-subsection-title">আগের সেটের ধাঁচে রিভিশন টেস্ট</div>`,
        ...IHT_PREVIOUS_MODEL_NAMES.map((name, i) => `<button class="subject-btn iht-mock-btn" data-subj="${name}">📝 ${name.replace('IHT ', '')}<small>${IHT_PREVIOUS_MODEL_SIZES[i]}টি প্রশ্ন · রিভিশন টেস্ট</small></button>`)
      ];
      ihtGrid.innerHTML = ihtCards.join('');
      ihtGrid.querySelectorAll('.subject-btn').forEach((btn) => {
        btn.addEventListener('click', () => startQuiz(btn.dataset.subj));
      });
    }

    const varsityGrid = document.getElementById('varsityUniversityGrid');
    if (varsityGrid) {
      varsityGrid.innerHTML = VARSITY_UNIVERSITIES.map((uni) => `
        <section class="varsity-university-card">
          <div class="varsity-university-brand"><img class="varsity-university-logo" src="${uni.logo}" alt="${uni.name} logo"><div class="varsity-university-title"><strong>${uni.name}</strong><small>${uni.code} · B Unit</small></div></div>
          <div class="varsity-stream-grid">
            ${VARSITY_STREAM_ORDER.map((streamId) => {
              const stream = VARSITY_STREAM_BANKS[streamId];
              const total = Object.values(stream.subjects).reduce((n,qs)=>n+qs.length,0);
              return `<div class="varsity-stream-card"><h4>${stream.label}</h4><small>${total}টি practice MCQ</small>
                <div class="varsity-subject-buttons">
                  ${Object.entries(stream.subjects).map(([subject,qs]) => `<button class="subject-btn" data-varsity="${uni.id}" data-varsity-stream="${streamId}" data-varsity-subject="${subject}">${subject}<small>${qs.length}টি MCQ</small></button>`).join('')}
                  <button class="subject-btn varsity-full-btn" data-varsity="${uni.id}" data-varsity-stream="${streamId}" data-varsity-subject="ALL">পূর্ণাঙ্গ ${stream.label} মডেল টেস্ট<small>${total}টি MCQ</small></button>
                </div></div>`;
            }).join('')}
          </div>
        </section>`).join('');
      varsityGrid.querySelectorAll('[data-varsity]').forEach((btn) => {
        btn.addEventListener('click', () => startQuiz(`VARSITY:${btn.dataset.varsity}:${btn.dataset.varsityStream}:${btn.dataset.varsitySubject}`));
      });
    }

    const nuGrid = document.getElementById('nationalUniversityGrid');
    if (nuGrid) {
      nuGrid.innerHTML = `
        <section class="nu-university-card">
          <div class="nu-brand-head">
            <img src="assets/nu-logo.svg" alt="জাতীয় বিশ্ববিদ্যালয়ের প্রতীক" class="nu-logo">
            <div><span class="nu-kicker">NATIONAL UNIVERSITY · BANGLADESH</span><h3>জাতীয় বিশ্ববিদ্যালয় (NU)</h3><p>ভর্তি প্রস্তুতি · বিভাগভিত্তিক অনুশীলন</p></div>
          </div>
          <div class="nu-stream-grid">
            ${NU_STREAM_ORDER.map((streamId) => {
              const stream = NU_STREAM_BANKS[streamId];
              const total = Object.values(stream.subjects).reduce((n,qs)=>n+qs.length,0);
              return `<div class="nu-stream-card"><div class="nu-stream-heading"><h4>${stream.label}</h4><span>${total}টি MCQ</span></div>
                <div class="nu-subject-buttons">
                  ${Object.entries(stream.subjects).map(([subject,qs]) => `<button class="subject-btn" data-nu-stream="${streamId}" data-nu-subject="${subject}">${subject}<small>${qs.length}টি MCQ</small></button>`).join('')}
                  <button class="subject-btn varsity-full-btn" data-nu-stream="${streamId}" data-nu-subject="ALL">পূর্ণাঙ্গ ${stream.label} মডেল টেস্ট<small>${total}টি MCQ</small></button>
                </div></div>`;
            }).join('')}
          </div>
        </section>`;
      nuGrid.querySelectorAll('[data-nu-stream]').forEach((btn) => {
        btn.addEventListener('click', () => startQuiz(`NU:${btn.dataset.nuStream}:${btn.dataset.nuSubject}`));
      });
    }
  }

  let pendingQuizSubject = null;

  // Keep a per-subject question history in the browser so retries and later
  // practice sessions serve unseen questions before starting a new cycle.
  function takeFreshQuestions(subject, pool, requestedCount) {
    const storageKey = `studyVerseQuestionHistory:${subject}`;
    let seen = [];
    try { seen = JSON.parse(localStorage.getItem(storageKey) || '[]'); } catch (_) { seen = []; }
    if (!Array.isArray(seen)) seen = [];
    const keyOf = (q) => {
      try { return JSON.stringify(q); } catch (_) { return String(q && (q.question || q.q || q.text) || q); }
    };
    const keyed = pool.map((q) => ({ q, key: keyOf(q) }));
    const allKeys = new Set(keyed.map((x) => x.key));
    seen = seen.filter((key) => allKeys.has(key));
    const unseen = keyed.filter((x) => !seen.includes(x.key));
    const shuffled = (arr) => {
      const copy = [...arr];
      for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
      }
      return copy;
    };
    const count = Math.min(requestedCount, keyed.length);
    let chosen = shuffled(unseen).slice(0, count);
    // If this attempt crosses the end of the current cycle, start a new cycle
    // only after every question in this bank has already been used.
    if (chosen.length < count) {
      const usedNow = new Set([...seen, ...chosen.map((x) => x.key)]);
      const remainder = keyed.filter((x) => !usedNow.has(x.key));
      chosen = chosen.concat(shuffled(remainder).slice(0, count - chosen.length));
      if (chosen.length < count) {
        const selectedKeys = new Set(chosen.map((x) => x.key));
        chosen = chosen.concat(shuffled(keyed.filter((x) => !selectedKeys.has(x.key))).slice(0, count - chosen.length));
        seen = [];
      }
    }
    const updatedSeen = [...new Set([...seen, ...chosen.map((x) => x.key)])];
    try { localStorage.setItem(storageKey, JSON.stringify(updatedSeen)); } catch (_) {}
    return chosen.map((x) => x.q);
  }

  function startQuiz(subject, requestedCount) {
    if (requestedCount == null) {
      pendingQuizSubject = subject;
      const modal = document.getElementById('quizCountModal');
      if (modal) modal.classList.remove('hidden');
      return;
    }
    const nuMatch = subject.match(/^NU:([^:]+):(.+)$/);
    if (nuMatch) {
      const [, streamId, nuSubject] = nuMatch;
      const stream = NU_STREAM_BANKS[streamId];
      if (!stream) return;
      const questions = nuSubject === 'ALL' ? Object.values(stream.subjects).flat() : stream.subjects[nuSubject];
      if (!questions || !questions.length) return;
      quizNegativeMarking = false;
      currentQuiz = { sourceSubject: subject, subject: `জাতীয় বিশ্ববিদ্যালয় — ${stream.label} — ${nuSubject === 'ALL' ? 'পূর্ণাঙ্গ মডেল টেস্ট' : nuSubject}`, questions: takeFreshQuestions(subject, questions, requestedCount), index: 0, score: 0, wrong: 0, negative: false };
      document.getElementById('quizSetup').classList.add('hidden');
      document.getElementById('quizResult').classList.add('hidden');
      document.getElementById('quizPlay').classList.remove('hidden');
      showQuestion();
      return;
    }
    const varsityMatch = subject.match(/^VARSITY:([^:]+):([^:]+):(.+)$/);
    if (varsityMatch) {
      const [, universityId, streamId, varsitySubject] = varsityMatch;
      const university = VARSITY_UNIVERSITIES.find((u) => u.id === universityId);
      const stream = VARSITY_STREAM_BANKS[streamId];
      if (!university || !stream) return;
      const questions = varsitySubject === 'ALL'
        ? Object.values(stream.subjects).flat()
        : stream.subjects[varsitySubject];
      if (!questions || !questions.length) return;
      quizNegativeMarking = false;
      currentQuiz = {
        sourceSubject: subject,
        subject: `${university.name} — ${stream.label} — ${varsitySubject === 'ALL' ? 'পূর্ণাঙ্গ মডেল টেস্ট' : varsitySubject}`,
        questions: takeFreshQuestions(subject, questions, requestedCount),
        index: 0, score: 0, wrong: 0, negative: false
      };
      document.getElementById('quizSetup').classList.add('hidden');
      document.getElementById('quizResult').classList.add('hidden');
      document.getElementById('quizPlay').classList.remove('hidden');
      showQuestion();
      return;
    }
    const extraSubject = subject.replace(/^IHT নতুন বাংলা /, '');
    const previousTestIndex = IHT_PREVIOUS_MODEL_NAMES.indexOf(subject);
    const qs = subject === 'IHT Full Mock Test'
      ? IHT_FULL_MOCK
      : (subject === 'IHT বাংলা পূর্ণাঙ্গ মডেল টেস্ট'
          ? IHT_BN_FULL_MOCK
          : (subject === 'IHT নতুন বাংলা পূর্ণাঙ্গ মডেল টেস্ট'
              ? IHT_BN_EXTRA_FULL
              : (previousTestIndex >= 0
                  ? IHT_PREVIOUS_MODEL_TESTS[previousTestIndex]
                  : (IHT_BN_EXTRA_SUBJECTS.includes(subject)
                      ? IHT_BN_EXTRA_BANK[extraSubject]
                      : (IHT_BN_SUBJECTS.includes(subject)
                          ? IHT_BN_QUIZ_BANK[subject.replace(/^IHT বাংলা /, '')]
                          : (IHT_SUBJECTS.includes(subject)
                              ? IHT_QUIZ_BANK[subject.replace(/^IHT /, '')]
                              : QUIZ_BANK[subject]))))));
    if (!qs) return;
    if (GST_SUBJECTS.includes(subject)) quizNegativeMarking = true;
    if (subject === 'IHT Full Mock Test' || subject === 'IHT বাংলা পূর্ণাঙ্গ মডেল টেস্ট' ||
        subject === 'IHT নতুন বাংলা পূর্ণাঙ্গ মডেল টেস্ট' || IHT_SUBJECTS.includes(subject) ||
        IHT_BN_EXTRA_SUBJECTS.includes(subject) || IHT_BN_SUBJECTS.includes(subject) ||
        previousTestIndex >= 0) quizNegativeMarking = false;
    currentQuiz = {
      sourceSubject: subject,
      subject,
      questions: takeFreshQuestions(subject, qs, requestedCount),
      index: 0,
      score: 0,
      wrong: 0,
      negative: quizNegativeMarking,
    };
    document.getElementById('quizSetup').classList.add('hidden');
    document.getElementById('quizResult').classList.add('hidden');
    document.getElementById('quizPlay').classList.remove('hidden');
    showQuestion();
  }

  function showQuestion() {
    const cq = currentQuiz;
    const q = cq.questions[cq.index];
    document.getElementById('quizSubjectLabel').textContent = cq.subject + (cq.negative ? ' (−0.25)' : '');
    document.getElementById('quizProgress').textContent = `Q ${cq.index + 1} / ${cq.questions.length}`;
    const displayScore = cq.negative ? (cq.score - cq.wrong * 0.25).toFixed(2) : cq.score;
    document.getElementById('quizScore').textContent = `Score: ${displayScore}`;
    document.getElementById('quizQuestion').textContent = q.q;
    const opts = document.getElementById('quizOptions');
    opts.innerHTML = q.options.map((o, i) =>
      `<button class="option-btn" data-i="${i}">${escapeHtml(o)}</button>`
    ).join('');
    document.getElementById('quizFeedback').classList.add('hidden');
    document.getElementById('quizNext').classList.add('hidden');

    opts.querySelectorAll('.option-btn').forEach((btn) => {
      btn.addEventListener('click', () => selectAnswer(+btn.dataset.i));
    });
  }

  function selectAnswer(i) {
    const cq = currentQuiz;
    const q = cq.questions[cq.index];
    const buttons = document.querySelectorAll('.option-btn');
    buttons.forEach((b) => { b.disabled = true; });
    buttons[q.answer].classList.add('correct');
    if (i === q.answer) {
      cq.score++;
    } else {
      buttons[i].classList.add('wrong');
      cq.wrong++;
    }
    const displayScore = cq.negative ? (cq.score - cq.wrong * 0.25).toFixed(2) : cq.score;
    document.getElementById('quizScore').textContent = `Score: ${displayScore}`;
    const fb = document.getElementById('quizFeedback');
    const label = i === q.answer ? 'সঠিক / Correct!' : (cq.negative ? 'ভুল (−0.25) / Wrong' : 'Not quite.');
    fb.innerHTML = `<strong>${label}</strong> ${escapeHtml(q.explain)}`;
    fb.classList.remove('hidden');
    document.getElementById('quizNext').classList.remove('hidden');
  }

  document.getElementById('quizNext').addEventListener('click', () => {
    currentQuiz.index++;
    if (currentQuiz.index >= currentQuiz.questions.length) {
      finishQuiz();
    } else {
      showQuestion();
    }
  });

  function finishQuiz() {
    const cq = currentQuiz;
    document.getElementById('quizPlay').classList.add('hidden');
    document.getElementById('quizResult').classList.remove('hidden');
    const net = cq.negative ? cq.score - cq.wrong * 0.25 : cq.score;
    const pct = Math.round((cq.score / cq.questions.length) * 100);
    const scoreText = cq.negative
      ? `Net: ${net.toFixed(2)} (Correct ${cq.score}, Wrong ${cq.wrong}, −0.25 each)`
      : `${cq.score} / ${cq.questions.length} (${pct}%)`;
    document.getElementById('resultScore').textContent = scoreText;
    let msg = 'Keep practicing! অনুশীলন চালিয়ে যান।';
    if (pct === 100) msg = 'Perfect score! অসাধারণ!';
    else if (pct >= 80) msg = 'Great job — you know this well.';
    else if (pct >= 60) msg = 'Solid effort. Review the explanations and try again.';
    document.getElementById('resultMessage').textContent = msg;

    state.quizHistory.push({
      subject: cq.subject,
      score: net,
      total: cq.questions.length,
      date: todayStr(),
    });
    updateStreak();
    addActivity(`Quiz: ${cq.subject} — ${typeof net === 'number' ? net.toFixed(2) : net}/${cq.questions.length}`);
    saveData();
  }

  const quizCountModal = document.getElementById('quizCountModal');
  if (quizCountModal) {
    quizCountModal.querySelectorAll('[data-question-count]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const count = Number(btn.dataset.questionCount);
        const subject = pendingQuizSubject;
        pendingQuizSubject = null;
        quizCountModal.classList.add('hidden');
        if (subject) startQuiz(subject, count);
      });
    });
    document.getElementById('quizCountCancel').addEventListener('click', () => {
      pendingQuizSubject = null;
      quizCountModal.classList.add('hidden');
    });
    quizCountModal.addEventListener('click', (event) => {
      if (event.target === quizCountModal) {
        pendingQuizSubject = null;
        quizCountModal.classList.add('hidden');
      }
    });
  }

  document.getElementById('quizRetry').addEventListener('click', () => {
    if (currentQuiz) startQuiz(currentQuiz.sourceSubject || currentQuiz.subject, currentQuiz.questions.length);
  });
  document.getElementById('quizHome').addEventListener('click', () => renderQuizSetup());

  // GST / Admission quick starts
  const startGstAll = document.getElementById('startGstAll');
  if (startGstAll) {
    startGstAll.addEventListener('click', () => {
      showSection('quiz');
      renderQuizSetup('gst');
    });
  }
  document.querySelectorAll('[data-gst]').forEach((btn) => {
    btn.addEventListener('click', () => {
      showSection('quiz');
      quizNegativeMarking = true;
      startQuiz(btn.dataset.gst);
    });
  });

  // ---------- Memories (Flashcards + spaced repetition) ----------
  let reviewQueue = [];
  let reviewIndex = 0;

  function renderMemories() {
    const sel = document.getElementById('deckSelect');
    const deckInput = document.getElementById('cardDeckInput');
    const decks = state.decks;
    sel.innerHTML = '<option value="all">All decks</option>' +
      decks.map((d) => `<option value="${d.id}">${escapeHtml(d.name)}</option>`).join('');
    deckInput.innerHTML = decks.map((d) => `<option value="${d.id}">${escapeHtml(d.name)}</option>`).join('');
    renderCardList();
    document.getElementById('cardReview').classList.add('hidden');
    document.getElementById('cardListView').classList.remove('hidden');
  }

  function renderCardList() {
    const deckId = document.getElementById('deckSelect').value;
    let cards = state.cards;
    if (deckId !== 'all') cards = cards.filter((c) => c.deckId === deckId);
    const list = document.getElementById('cardList');
    if (cards.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted)">No cards in this deck.</p>';
      return;
    }
    list.innerHTML = cards.map((c) => `
      <div class="card-item">
        <span class="front-preview">${escapeHtml(c.front)}</span>
        <span class="card-btns">
          <button class="btn" data-edit="${c.id}">Edit</button>
          <button class="btn danger" data-del="${c.id}">Del</button>
        </span>
      </div>
    `).join('');
    list.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => openCardModal(b.dataset.edit)));
    list.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', () => {
      if (confirm('Delete this card?')) {
        state.cards = state.cards.filter((c) => c.id !== b.dataset.del);
        saveData();
        renderCardList();
      }
    }));
  }

  document.getElementById('deckSelect').addEventListener('change', renderCardList);

  document.getElementById('startReview').addEventListener('click', () => {
    const deckId = document.getElementById('deckSelect').value;
    const now = Date.now();
    reviewQueue = state.cards.filter((c) => {
      if (deckId !== 'all' && c.deckId !== deckId) return false;
      return c.due <= now;
    });
    if (reviewQueue.length === 0) {
      // If none due, take all from deck for practice
      reviewQueue = state.cards.filter((c) => deckId === 'all' || c.deckId === deckId);
    }
    if (reviewQueue.length === 0) {
      alert('No cards to review. Add some first!');
      return;
    }
    reviewQueue = reviewQueue.sort(() => Math.random() - 0.5);
    reviewIndex = 0;
    document.getElementById('cardListView').classList.add('hidden');
    document.getElementById('cardReview').classList.remove('hidden');
    showReviewCard();
  });

  function showReviewCard() {
    if (reviewIndex >= reviewQueue.length) {
      document.getElementById('cardReview').classList.add('hidden');
      document.getElementById('cardListView').classList.remove('hidden');
      addActivity(`Reviewed ${reviewQueue.length} flashcards`);
      updateStreak();
      renderCardList();
      alert('Review complete! Great work.');
      return;
    }
    const card = reviewQueue[reviewIndex];
    document.getElementById('flashcard').classList.remove('flipped');
    document.getElementById('cardFront').textContent = card.front;
    document.getElementById('cardBack').textContent = card.back;
    document.getElementById('reviewCount').textContent = `${reviewQueue.length - reviewIndex} remaining`;
  }

  document.getElementById('flipBtn').addEventListener('click', () => {
    document.getElementById('flashcard').classList.toggle('flipped');
  });
  document.getElementById('flashcard').addEventListener('click', () => {
    document.getElementById('flashcard').classList.toggle('flipped');
  });

  // Simple SM-2 inspired spacing
  function scheduleCard(card, remembered) {
    if (remembered) {
      card.reps = (card.reps || 0) + 1;
      card.ease = Math.min(3, (card.ease || 2.5) + 0.1);
      card.interval = card.reps === 1 ? 1 : card.reps === 2 ? 3 : Math.round(card.interval * card.ease);
    } else {
      card.reps = 0;
      card.ease = Math.max(1.3, (card.ease || 2.5) - 0.2);
      card.interval = 1;
    }
    card.due = Date.now() + card.interval * 24 * 60 * 60 * 1000;
  }

  document.getElementById('rememberBtn').addEventListener('click', () => {
    const card = reviewQueue[reviewIndex];
    scheduleCard(card, true);
    // Update in state
    const idx = state.cards.findIndex((c) => c.id === card.id);
    if (idx >= 0) state.cards[idx] = card;
    saveData();
    reviewIndex++;
    showReviewCard();
  });

  document.getElementById('forgotBtn').addEventListener('click', () => {
    const card = reviewQueue[reviewIndex];
    scheduleCard(card, false);
    const idx = state.cards.findIndex((c) => c.id === card.id);
    if (idx >= 0) state.cards[idx] = card;
    saveData();
    // Put back at end for another pass
    reviewQueue.push(card);
    reviewIndex++;
    showReviewCard();
  });

  // Card modal
  let editingCardId = null;
  const cardModal = document.getElementById('cardModal');

  function openCardModal(id) {
    editingCardId = id || null;
    document.getElementById('cardModalTitle').textContent = id ? 'Edit Card' : 'New Card';
    if (id) {
      const c = state.cards.find((x) => x.id === id);
      document.getElementById('cardFrontInput').value = c.front;
      document.getElementById('cardBackInput').value = c.back;
      document.getElementById('cardDeckInput').value = c.deckId;
    } else {
      document.getElementById('cardFrontInput').value = '';
      document.getElementById('cardBackInput').value = '';
    }
    cardModal.classList.remove('hidden');
  }

  document.getElementById('addCardBtn').addEventListener('click', () => openCardModal(null));
  document.getElementById('cardModalCancel').addEventListener('click', () => cardModal.classList.add('hidden'));
  document.getElementById('cardModalSave').addEventListener('click', () => {
    const front = document.getElementById('cardFrontInput').value.trim();
    const back = document.getElementById('cardBackInput').value.trim();
    const deckId = document.getElementById('cardDeckInput').value;
    if (!front || !back) { alert('Front and back are required.'); return; }
    if (editingCardId) {
      const c = state.cards.find((x) => x.id === editingCardId);
      c.front = front; c.back = back; c.deckId = deckId;
    } else {
      state.cards.push({
        id: uid(), deckId, front, back,
        interval: 1, ease: 2.5, due: Date.now(), reps: 0,
      });
      addActivity('Added a new flashcard');
    }
    saveData();
    cardModal.classList.add('hidden');
    renderCardList();
  });

  // Deck management
  const deckModal = document.getElementById('deckModal');
  document.getElementById('manageDecksBtn').addEventListener('click', () => {
    renderDeckList();
    deckModal.classList.remove('hidden');
  });
  document.getElementById('deckModalClose').addEventListener('click', () => {
    deckModal.classList.add('hidden');
    renderMemories();
  });

  function renderDeckList() {
    const el = document.getElementById('deckList');
    el.innerHTML = state.decks.map((d) => {
      const count = state.cards.filter((c) => c.deckId === d.id).length;
      return `<div class="card-item"><span>${escapeHtml(d.name)} (${count})</span>
        <button class="btn danger" data-deldeck="${d.id}">Delete</button></div>`;
    }).join('');
    el.querySelectorAll('[data-deldeck]').forEach((b) => {
      b.addEventListener('click', () => {
        if (!confirm('Delete deck and all its cards?')) return;
        state.cards = state.cards.filter((c) => c.deckId !== b.dataset.deldeck);
        state.decks = state.decks.filter((d) => d.id !== b.dataset.deldeck);
        saveData();
        renderDeckList();
      });
    });
  }

  document.getElementById('addDeckBtn').addEventListener('click', () => {
    const name = document.getElementById('newDeckName').value.trim();
    if (!name) return;
    state.decks.push({ id: uid(), name });
    document.getElementById('newDeckName').value = '';
    saveData();
    renderDeckList();
  });

  // ---------- Notes ----------
  let currentNoteId = null;

  function renderNotes() {
    const subjSel = document.getElementById('noteSubject');
    const subjects = ['Biology', 'Chemistry', 'History', 'Math', 'Physics', 'Literature', 'Other'];
    subjSel.innerHTML = '<option value="">No subject</option>' +
      subjects.map((s) => `<option value="${s}">${s}</option>`).join('');

    const list = document.getElementById('notesList');
    if (state.notes.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted);padding:0.5rem">No notes yet</p>';
    } else {
      list.innerHTML = [...state.notes].sort((a, b) => b.updated - a.updated).map((n) => `
        <div class="note-item ${n.id === currentNoteId ? 'active' : ''}" data-id="${n.id}">
          <div>${escapeHtml(n.title || 'Untitled')}</div>
          <div class="note-date">${new Date(n.updated).toLocaleDateString()}</div>
        </div>
      `).join('');
      list.querySelectorAll('.note-item').forEach((el) => {
        el.addEventListener('click', () => selectNote(el.dataset.id));
      });
    }
  }

  function selectNote(id) {
    currentNoteId = id;
    const n = state.notes.find((x) => x.id === id);
    if (!n) return;
    document.getElementById('noteTitle').value = n.title;
    document.getElementById('noteBody').value = n.body;
    document.getElementById('noteSubject').value = n.subject || '';
    document.getElementById('noteMeta').textContent = `Last saved: ${new Date(n.updated).toLocaleString()}`;
    renderNotes();
  }

  document.getElementById('newNoteBtn').addEventListener('click', () => {
    currentNoteId = null;
    document.getElementById('noteTitle').value = '';
    document.getElementById('noteBody').value = '';
    document.getElementById('noteSubject').value = '';
    document.getElementById('noteMeta').textContent = 'New note — not saved yet';
    renderNotes();
  });

  document.getElementById('saveNoteBtn').addEventListener('click', () => {
    const title = document.getElementById('noteTitle').value.trim();
    const body = document.getElementById('noteBody').value.trim();
    const subject = document.getElementById('noteSubject').value;
    if (!title && !body) { alert('Write something first.'); return; }
    if (currentNoteId) {
      const n = state.notes.find((x) => x.id === currentNoteId);
      n.title = title; n.body = body; n.subject = subject; n.updated = Date.now();
    } else {
      const note = { id: uid(), title, body, subject, updated: Date.now(), created: Date.now() };
      state.notes.push(note);
      currentNoteId = note.id;
      addActivity('Created note: ' + (title || 'Untitled'));
    }
    saveData();
    document.getElementById('noteMeta').textContent = `Saved at ${new Date().toLocaleString()}`;
    renderNotes();
  });

  document.getElementById('deleteNoteBtn').addEventListener('click', () => {
    if (!currentNoteId) return;
    if (!confirm('Delete this note?')) return;
    state.notes = state.notes.filter((n) => n.id !== currentNoteId);
    currentNoteId = null;
    document.getElementById('noteTitle').value = '';
    document.getElementById('noteBody').value = '';
    document.getElementById('noteMeta').textContent = '';
    saveData();
    renderNotes();
  });

  // ---------- Planner ----------
  function renderPlanner() {
    const today = todayStr();
    // Exams
    const examList = document.getElementById('examList');
    const exams = [...state.exams].sort((a, b) => a.date.localeCompare(b.date));
    if (exams.length === 0) {
      examList.innerHTML = '<p style="color:var(--text-muted);font-size:0.9rem">No exams scheduled</p>';
    } else {
      examList.innerHTML = exams.map((e) => {
        const days = daysBetween(today, e.date);
        const label = days < 0 ? 'Past' : days === 0 ? 'Today' : days + 'd left';
        return `<div class="exam-item">
          <span><strong>${escapeHtml(e.name)}</strong><br><small style="color:var(--text-muted)">${e.date}</small></span>
          <span class="days-left">${label}</span>
          <button class="btn danger" data-delexam="${e.id}" style="padding:0.25rem 0.5rem;font-size:0.75rem">✕</button>
        </div>`;
      }).join('');
      examList.querySelectorAll('[data-delexam]').forEach((b) => {
        b.addEventListener('click', () => {
          state.exams = state.exams.filter((e) => e.id !== b.dataset.delexam);
          saveData();
          renderPlanner();
          renderDashboard();
        });
      });
    }

    // Tasks
    const taskList = document.getElementById('taskList');
    const tasks = state.tasks.filter((t) => t.date === today || !t.done);
    if (tasks.length === 0) {
      taskList.innerHTML = '<li style="color:var(--text-muted)">No tasks for today</li>';
    } else {
      taskList.innerHTML = tasks.map((t) => `
        <li class="${t.done ? 'done' : ''}">
          <input type="checkbox" data-task="${t.id}" ${t.done ? 'checked' : ''} />
          <span>${escapeHtml(t.text)}</span>
          <button class="btn danger" data-deltask="${t.id}" style="margin-left:auto;padding:0.2rem 0.4rem;font-size:0.7rem">✕</button>
        </li>
      `).join('');
      taskList.querySelectorAll('[data-task]').forEach((cb) => {
        cb.addEventListener('change', () => {
          const t = state.tasks.find((x) => x.id === cb.dataset.task);
          if (t) { t.done = cb.checked; saveData(); renderPlanner(); }
        });
      });
      taskList.querySelectorAll('[data-deltask]').forEach((b) => {
        b.addEventListener('click', () => {
          state.tasks = state.tasks.filter((t) => t.id !== b.dataset.deltask);
          saveData();
          renderPlanner();
        });
      });
    }

    document.getElementById('goalMinutes').value = state.goalMinutes;
  }

  document.getElementById('addTaskBtn').addEventListener('click', () => {
    const text = document.getElementById('taskInput').value.trim();
    if (!text) return;
    state.tasks.push({ id: uid(), text, done: false, date: todayStr() });
    document.getElementById('taskInput').value = '';
    saveData();
    renderPlanner();
  });
  document.getElementById('taskInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('addTaskBtn').click();
  });

  document.getElementById('saveGoalBtn').addEventListener('click', () => {
    state.goalMinutes = Math.max(15, parseInt(document.getElementById('goalMinutes').value, 10) || 60);
    saveData();
    renderDashboard();
    alert('Daily goal saved: ' + state.goalMinutes + ' minutes');
  });

  document.getElementById('logStudyBtn').addEventListener('click', () => {
    const mins = parseInt(document.getElementById('logMinutes').value, 10);
    if (!mins || mins < 1) { alert('Enter minutes studied.'); return; }
    const today = todayStr();
    state.studyLog[today] = (state.studyLog[today] || 0) + mins;
    document.getElementById('logMinutes').value = '';
    updateStreak();
    addActivity(`Studied ${mins} minutes`);
    saveData();
    renderDashboard();
    renderProgress();
    alert(`Logged ${mins} minutes. Total today: ${state.studyLog[today]} min`);
  });

  // Exam modal
  const examModal = document.getElementById('examModal');
  document.getElementById('addExamBtn').addEventListener('click', () => {
    document.getElementById('examName').value = '';
    document.getElementById('examDate').value = '';
    examModal.classList.remove('hidden');
  });
  document.getElementById('examModalCancel').addEventListener('click', () => examModal.classList.add('hidden'));
  document.getElementById('examModalSave').addEventListener('click', () => {
    const name = document.getElementById('examName').value.trim();
    const date = document.getElementById('examDate').value;
    if (!name || !date) { alert('Name and date required.'); return; }
    state.exams.push({ id: uid(), name, date });
    saveData();
    examModal.classList.add('hidden');
    renderPlanner();
    renderDashboard();
  });

  // ---------- Progress ----------
  function renderProgress() {
    let total = 0;
    Object.values(state.studyLog).forEach((m) => { total += m; });
    document.getElementById('totalMinutes').textContent = total + ' min';
    document.getElementById('progStreak').textContent = state.streak + ' days';
    document.getElementById('progQuizzes').textContent = state.quizHistory.length;
    const mastered = state.cards.filter((c) => (c.reps || 0) >= 3).length;
    document.getElementById('progMastered').textContent = mastered;

    // History bars last 14 days
    const bars = document.getElementById('historyBars');
    const days = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`);
    }
    const maxM = Math.max(1, ...days.map((d) => state.studyLog[d] || 0));
    bars.innerHTML = days.map((d) => {
      const m = state.studyLog[d] || 0;
      const h = Math.max(4, (m / maxM) * 100);
      const label = d.slice(5);
      return `<div class="hist-bar" style="height:${h}%" title="${m} min"><span>${label}</span></div>`;
    }).join('');

    // Quiz by subject
    const bySubj = {};
    state.quizHistory.forEach((h) => {
      if (!bySubj[h.subject]) bySubj[h.subject] = { score: 0, total: 0, n: 0 };
      bySubj[h.subject].score += h.score;
      bySubj[h.subject].total += h.total;
      bySubj[h.subject].n += 1;
    });
    const qs = document.getElementById('quizStats');
    if (Object.keys(bySubj).length === 0) {
      qs.innerHTML = '<p style="color:var(--text-muted)">No quizzes taken yet</p>';
    } else {
      qs.innerHTML = Object.entries(bySubj).map(([s, v]) => {
        const pct = Math.round((v.score / v.total) * 100);
        return `<div class="quiz-stat-row"><span>${s} (${v.n} quizzes)</span><span style="color:var(--neon)">${pct}% avg</span></div>`;
      }).join('');
    }
  }

  // ---------- Resources ----------
  function renderResources() {
    const subjects = ['Biology', 'Chemistry', 'Physics', 'Calculus', 'World History', 'Python programming', 'Organic Chemistry'];
    document.getElementById('quickLinks').innerHTML = subjects.map((s) => {
      const q = encodeURIComponent(s + ' textbook');
      const yq = encodeURIComponent(s + ' explained');
      return `<a href="https://www.google.com/search?tbm=bks&q=${q}" target="_blank" rel="noopener">📚 ${s} Books</a>
              <a href="https://www.youtube.com/results?search_query=${yq}" target="_blank" rel="noopener">▶ ${s} Videos</a>`;
    }).join('');
  }

  document.getElementById('searchBooks').addEventListener('click', () => {
    const q = document.getElementById('booksQuery').value.trim();
    if (!q) return;
    const url = `https://www.google.com/search?tbm=bks&q=${encodeURIComponent(q)}`;
    document.getElementById('booksLinks').innerHTML =
      `<a href="${url}" target="_blank" rel="noopener">Open Google Books results for “${escapeHtml(q)}”</a>`;
    window.open(url, '_blank', 'noopener');
  });

  document.getElementById('searchYT').addEventListener('click', () => {
    const q = document.getElementById('ytQuery').value.trim();
    if (!q) return;
    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;
    document.getElementById('ytLinks').innerHTML =
      `<a href="${url}" target="_blank" rel="noopener">Open YouTube results for “${escapeHtml(q)}”</a>`;
    window.open(url, '_blank', 'noopener');
  });

  // ---------- Ask Google (Text Q&A, Bangla + English) ----------
  function googleSearchUrl(question, preferBangla) {
    const q = preferBangla ? question + ' বাংলা' : question;
    return 'https://www.google.com/search?q=' + encodeURIComponent(q) + '&hl=' + (preferBangla ? 'bn' : 'en');
  }

  function saveGoogleQuestion(text) {
    if (!state.googleQuestions) state.googleQuestions = [];
    state.googleQuestions = state.googleQuestions.filter((x) => x !== text);
    state.googleQuestions.unshift(text);
    if (state.googleQuestions.length > 15) state.googleQuestions.pop();
    saveData();
  }

  function renderAskGoogle() {
    const list = document.getElementById('recentQuestions');
    const items = state.googleQuestions || [];
    if (items.length === 0) {
      list.innerHTML = '<li style="color:var(--text-muted)">No recent questions yet</li>';
      return;
    }
    list.innerHTML = items.map((q, i) =>
      `<li><span>${escapeHtml(q)}</span>
        <button type="button" class="btn" data-rq="${i}">Ask again</button></li>`
    ).join('');
    list.querySelectorAll('[data-rq]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const text = items[+btn.dataset.rq];
        document.getElementById('googleQuestion').value = text;
        runGoogleSearch(false);
      });
    });
  }

  function runGoogleSearch(preferBangla) {
    const text = document.getElementById('googleQuestion').value.trim();
    if (!text) {
      alert('Please type a question first.\nআগে একটি প্রশ্ন লিখুন।');
      return;
    }
    const url = googleSearchUrl(text, preferBangla);
    const box = document.getElementById('googleAnswerBox');
    box.innerHTML =
      `<p class="q-preview"><strong>Question:</strong> ${escapeHtml(text)}</p>
       <p><a href="${url}" target="_blank" rel="noopener">Open Google answer →</a></p>
       <p class="muted" style="margin-top:0.5rem;font-size:0.85rem">Answer is provided by Google Search (opens in a new tab).</p>`;
    saveGoogleQuestion(text);
    addActivity('Asked Google: ' + text.slice(0, 40));
    renderAskGoogle();
    window.open(url, '_blank', 'noopener');
  }

  document.getElementById('askGoogleBtn').addEventListener('click', () => runGoogleSearch(false));
  document.getElementById('askGoogleBnBtn').addEventListener('click', () => runGoogleSearch(true));
  document.getElementById('clearQuestionBtn').addEventListener('click', () => {
    document.getElementById('googleQuestion').value = '';
    document.getElementById('googleAnswerBox').innerHTML =
      '<p class="muted">Ask a question above. The Google Search link will appear here.</p>';
  });
  document.querySelectorAll('.g-example').forEach((chip) => {
    chip.addEventListener('click', () => {
      document.getElementById('googleQuestion').value = chip.dataset.q;
    });
  });

  // ---------- Settings ----------
  document.getElementById('reduceMotion').checked = state.settings.reduceMotion;
  if (state.settings.reduceMotion) document.body.classList.add('reduce-motion');

  document.getElementById('reduceMotion').addEventListener('change', (e) => {
    state.settings.reduceMotion = e.target.checked;
    document.body.classList.toggle('reduce-motion', e.target.checked);
    saveData();
  });

  // Gemini key UI — never display the raw key after save
  const geminiKeyInput = document.getElementById('geminiKeyInput');
  const geminiModelSel = document.getElementById('geminiModel');
  if (geminiKeyInput) {
    geminiKeyInput.value = '';
    geminiKeyInput.placeholder = (state.settings.geminiKey || '').trim()
      ? 'Key saved — type a new key only to replace'
      : 'AIza… (kept private on this device)';
    if (geminiModelSel) geminiModelSel.value = state.settings.geminiModel || 'gemini-2.0-flash';
    updateGeminiStatus();
    updateAssistantSubtitle();

    document.getElementById('saveGeminiKey').addEventListener('click', () => {
      const typed = (geminiKeyInput.value || '').trim();
      if (typed) state.settings.geminiKey = typed;
      // empty field + existing key = keep existing (user did not re-type it)
      state.settings.geminiModel = geminiModelSel ? geminiModelSel.value : 'gemini-2.0-flash';
      saveData();
      geminiKeyInput.value = '';
      geminiKeyInput.placeholder = (state.settings.geminiKey || '').trim()
        ? 'Key saved — type a new key only to replace'
        : 'AIza… (kept private on this device)';
      updateGeminiStatus();
      updateAssistantSubtitle();
      alert((state.settings.geminiKey || '').trim() ? 'Key saved privately on this device.' : 'No key stored.');
    });

    document.getElementById('clearGeminiKey').addEventListener('click', () => {
      geminiKeyInput.value = '';
      state.settings.geminiKey = '';
      saveData();
      geminiKeyInput.placeholder = 'AIza… (kept private on this device)';
      updateGeminiStatus();
      updateAssistantSubtitle();
    });

    document.getElementById('testGeminiKey').addEventListener('click', async () => {
      const typed = (geminiKeyInput.value || '').trim();
      if (typed) state.settings.geminiKey = typed;
      state.settings.geminiModel = geminiModelSel ? geminiModelSel.value : 'gemini-2.0-flash';
      if (!(state.settings.geminiKey || '').trim()) {
        updateGeminiStatus('Status: enter a key first');
        return;
      }
      updateGeminiStatus('Status: testing…');
      try {
        await callGemini('Reply with exactly: OK');
        geminiKeyInput.value = '';
        geminiKeyInput.placeholder = 'Key saved — type a new key only to replace';
        saveData();
        updateGeminiStatus('Status: connected (key not shown)');
        updateAssistantSubtitle();
      } catch (err) {
        updateGeminiStatus('Status: failed — ' + sanitizePublicError(err.message));
      }
    });
  }

  document.getElementById('exportData').addEventListener('click', () => {
    // Strip secrets before any file leaves the device
    const safe = JSON.parse(JSON.stringify(state));
    if (safe.settings) {
      safe.settings.geminiKey = '';
      safe.settings._keyExcluded = true;
    }
    const blob = new Blob([JSON.stringify(safe, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'studyverse-backup.json';
    a.click();
    URL.revokeObjectURL(a.href);
  });

  document.getElementById('importData').addEventListener('click', () => {
    document.getElementById('importFile').click();
  });
  document.getElementById('importFile').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data.notes || !data.cards) throw new Error('Invalid file');
        state = { ...defaultData(), ...data, settings: { ...defaultData().settings, ...(data.settings || {}) } };
        saveData();
        alert('Data imported successfully. Reloading…');
        location.reload();
      } catch (err) {
        alert('Import failed: invalid JSON or format.');
      }
    };
    reader.readAsText(file);
  });

  document.getElementById('resetData').addEventListener('click', () => {
    if (!confirm('This will erase ALL notes, cards, progress, and settings. Continue?')) return;
    if (!confirm('Really sure? This cannot be undone.')) return;
    localStorage.removeItem(STORAGE_KEY);
    location.reload();
  });

  // ---------- Init ----------
  function init() {
    // Seed sample notes if empty
    if (state.notes.length === 0) {
      state.notes.push({
        id: uid(),
        title: 'Welcome to STUDY VERSE',
        body: 'This is a sample note. You can edit or delete it.\n\nTips:\n• Use Memories for flashcards\n• Log study time in the Planner\n• Ask the Assistant when you need help',
        subject: 'Other',
        updated: Date.now(),
        created: Date.now(),
      });
      saveData();
    }
    renderDashboard();
    showSection('dashboard');
  }

  init();
})();
