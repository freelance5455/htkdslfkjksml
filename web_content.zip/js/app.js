/* يمكن هدف؟ — application shell & views */
(function () {
  const { api, ai, viz } = YH; const esc = viz.esc; const AR = ai.AR;
  const $ = (s, r = document) => r.querySelector(s); const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const app = $('#app');
  const S = {
    view: 'home', dayOffset: 0, league: 'all', q: '', events: [], loading: false, lastFetch: 0,
    match: null, sum: null, tab: null, scores: new Map(), tableLeague: 'eng.1', storyIdx: 0, storyTimer: null,
    predictEvents: null, nextRefresh: 0, refreshEvery: 60, sumCache: new Map(),
  };
  const DEFAULT_LEAGUES = YH.LEAGUES.map(l => l.id);

  /* ---------- formatting ---------- */
  const fmtTime = iso => new Date(iso).toLocaleTimeString('ar-IQ-u-nu-latn', { hour: '2-digit', minute: '2-digit', hour12: false });
  const fmtDay = d => d.toLocaleDateString('ar-IQ-u-nu-latn', { weekday: 'long', day: 'numeric', month: 'long' });
  const dayLabel = off => off === 0 ? 'اليوم' : off === -1 ? 'أمس' : off === 1 ? 'باچر' : null;
  const dateAt = off => { const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + off); return d; };
  const leagueAr = id => (YH.LEAGUE_BY_ID[id] || {}).ar || id;
  const statusAr = e => {
    const n = e.statusName || '';
    if (/HALFTIME/.test(n)) return 'استراحة';
    if (/POSTPONED/.test(n)) return 'مؤجلة';
    if (/CANCELED|CANCELLED/.test(n)) return 'ملغاة';
    if (/PEN/.test(n)) return 'انتهت بركلات الترجيح';
    if (/AET/.test(n)) return 'انتهت بعد التمديد';
    if (e.state === 'post') return 'انتهت';
    if (e.state === 'in') return e.clock || 'مباشر';
    return fmtTime(e.date);
  };
  const logo = (src, alt, cls = 'crest') => src ? `<img class="${cls}" src="${esc(src)}" alt="${esc(alt)}" loading="lazy" decoding="async" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'${cls} crest-fb',textContent:'${esc((alt || '?').slice(0, 1))}'}))">` : `<span class="${cls} crest-fb">${esc((alt || '?').slice(0, 1))}</span>`;
  function countdown(iso) {
    const ms = new Date(iso) - Date.now(); if (ms <= 0) return 'على وشك البداية';
    const h = Math.floor(ms / 36e5), m = Math.floor(ms % 36e5 / 6e4);
    return h >= 24 ? `بعد ${Math.floor(h / 24)} يوم` : h ? `بعد ${h} س ${m} د` : `بعد ${m} دقيقة`;
  }
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 2600); }

  /* ---------- servers UI ---------- */
  function renderServer(st) {
    const s = st.activeServer;
    $('#serverName').textContent = 'سيرفر ' + s.name;
    $('#serverMeta').textContent = s.status === 'down' ? 'تبديل تلقائي…' : s.latency ? `${s.latency} ms · متصل` : 'جارِ الاتصال…';
    $('#serverPill').dataset.status = s.status;
    const p = $('#serverPanel');
    if (!p.hidden) drawServerPanel();
  }
  function drawServerPanel() {
    const st = api.state(); const p = $('#serverPanel');
    p.innerHTML = `<div class="sp-head"><b>سيرفرات البيانات</b><button class="icon-btn" data-close aria-label="إغلاق">×</button></div>
      <p class="sp-note">ثلاثة سيرفرات تتبدّل تلقائياً عند أي عطل، وتتحدّث النتائج كل ${S.refreshEvery} ثانية${S.refreshEvery <= 20 ? ' (وضع المباراة المباشرة)' : ''}.</p>
      ${st.servers.map((s, i) => `<button class="sp-row ${i === st.active ? 'on' : ''}" data-srv="${i}"><i class="sp-dot ${s.status}"></i><span>سيرفر ${s.name} <small>${s.role || ''}</small></span><small>${s.latency ? s.latency + ' ms' : '—'}</small></button>`).join('')}
      <button class="btn btn-ghost sp-refresh" data-refresh>تحديث الآن</button>`;
  }
  $('#serverPill').addEventListener('click', () => { const p = $('#serverPanel'); p.hidden = !p.hidden; if (!p.hidden) drawServerPanel(); });
  $('#serverPanel').addEventListener('click', e => {
    if (e.target.closest('[data-close]')) $('#serverPanel').hidden = true;
    const r = e.target.closest('[data-srv]'); if (r) { api.setActive(+r.dataset.srv); toast('تم التحويل إلى سيرفر ' + api.SERVERS[+r.dataset.srv].name); refresh(true); }
    if (e.target.closest('[data-refresh]')) refresh(true);
  });
  api.onServer(renderServer);

  /* ---------- refresh loop ---------- */
  function setCountdown() { S.nextRefresh = Date.now() + S.refreshEvery * 1000; }
  setInterval(() => {
    const left = Math.max(0, S.nextRefresh - Date.now());
    const C = 2 * Math.PI * 15; const f = left / (S.refreshEvery * 1000);
    const fg = $('#ringFg'); if (fg) { fg.style.strokeDasharray = C; fg.style.strokeDashoffset = C * (1 - f); }
    if (left <= 0 && !document.hidden && !S.loading) refresh(false);
  }, 500);
  async function refresh(force) {
    setCountdown();
    if (S.view === 'home') await loadHome(true);
    else if (S.view === 'match' && S.match) await loadMatch(true);
    if (force) toast('تم التحديث');
  }

  function detectGoals(list) {
    list.forEach(e => {
      const prev = S.scores.get(e.id);
      const cur = [e.home.score, e.away.score];
      if (prev && e.state === 'in') {
        if (cur[0] > prev[0]) goalBurst(e, 'home');
        else if (cur[1] > prev[1]) goalBurst(e, 'away');
      }
      S.scores.set(e.id, cur);
    });
  }
  function goalBurst(e, side) {
    const b = $('#goalBurst'); const t = e[side];
    b.innerHTML = `<div class="gb-inner"><div class="gb-flash"></div><div class="gb-word">گووول</div>
      <div class="gb-team">${logo(t.logo, t.name, 'crest crest-lg')}<b>${esc(AR(t.name))}</b></div>
      <div class="gb-score sc2"><span>${e.home.score}</span><i>-</i><span>${e.away.score}</span></div>
      <p class="gb-note">نجيبلك فيديو الهدف بالتعليق العربي أول ما ينزل</p></div>`;
    b.hidden = false; b.classList.remove('play'); void b.offsetWidth; b.classList.add('play');
    YH.robot.voice.speak(`جووووول! هدف لـ${AR(t.name)}! النتيجة ${e.home.score} ${e.away.score}`, { rate: 1.12, pitch: 1.25 });
    clearTimeout(b._h); b._h = setTimeout(() => { b.hidden = true; }, 4200);
    watchGoalClip(e, side);
  }
  /* after a live goal, keep checking for the Arabic-commentary clip and alert as soon as one appears */
  const clipWatch = new Map();
  function watchGoalClip(e, side) {
    const key = e.id + ':' + e.home.score + '-' + e.away.score; if (clipWatch.has(key)) return;
    const t0 = Date.now(); const teamsAr = [AR(e.home.name), AR(e.away.name)];
    const tick = async () => {
      if (Date.now() - t0 > 15 * 60e3) { clipWatch.delete(key); return; }
      const v = await api.arabicClips({ teamsAr, teamsEn: [e.home.name, e.away.name], date: new Date(t0 - 10 * 60e3).toISOString(), kind: 'goal' }).catch(() => []);
      const fresh = v.find(x => !x.uploaded || x.uploaded > t0 - 5 * 60e3);
      if (fresh) { clipWatch.delete(key); clipToast(fresh, e); return; }
      clipWatch.set(key, setTimeout(tick, 45000));
    };
    clipWatch.set(key, setTimeout(tick, 20000));
  }
  function clipToast(v, e) {
    const t = $('#clipToast');
    t.innerHTML = `<img src="${esc(v.thumb)}" alt=""><div><b>وصل فيديو الهدف بالتعليق العربي</b><small>${esc(v.title)}</small></div><button class="btn" data-play-clip="${esc(v.id)}">شغّل</button><button class="icon-btn" data-x aria-label="إغلاق">×</button>`;
    t.hidden = false;
    t.onclick = ev => { if (ev.target.closest('[data-x]')) t.hidden = true; const p = ev.target.closest('[data-play-clip]'); if (p) { t.hidden = true; openPlayer(p.dataset.playClip, v.title); } };
  }
  function openPlayer(id, title) {
    const m = $('#player');
    m.innerHTML = `<div class="pm-box" role="dialog" aria-label="${esc(title || 'فيديو')}"><div class="pm-top"><b>${esc(title || '')}</b><button class="icon-btn" data-x aria-label="إغلاق">×</button></div><div class="yt"><iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0&playsinline=1" title="${esc(title || 'فيديو الهدف')}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe></div></div>`;
    m.hidden = false; YH.robot.voice.cancel();
    m.onclick = ev => { if (ev.target === m || ev.target.closest('[data-x]')) { m.hidden = true; m.innerHTML = ''; } };
  }

  /* ---------- nav ---------- */
  function go(view, params = {}) {
    clearInterval(S.storyTimer); YH.studio.stop(); YH.analyst.close();
    S.view = view; Object.assign(S, params);
    $$('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === view || (view === 'match' && b.dataset.nav === 'home')));
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
    render();
  }
  document.addEventListener('click', e => {
    const n = e.target.closest('[data-nav]'); if (n) { e.preventDefault(); go(n.dataset.nav); return; }
    const m = e.target.closest('[data-match]');
    if (m) { e.preventDefault(); const [lg, id] = m.dataset.match.split(':'); const ev = S.events.find(x => x.id === id) || (S.predictEvents || []).find(x => x.id === id) || null; go('match', { match: { league: lg, id, ev }, sum: null, tab: null, storyIdx: 0 }); }
  });

  function render() {
    if (S.view === 'home') return renderHome();
    if (S.view === 'match') return renderMatchShell();
    if (S.view === 'predict') return renderPredict();
    if (S.view === 'table') return renderTable();
    if (S.view === 'about') return renderAbout();
  }

  /* ======================= HOME ======================= */
  async function loadHome(silent) {
    const off = S.dayOffset;
    if (!silent) { S.loading = true; drawHomeList(); }
    S.loading = true;
    try {
      const ev = await api.allScoreboards(dateAt(off), DEFAULT_LEAGUES);
      if (off !== S.dayOffset) return;
      const uniq = [...new Map(ev.map(e => [e.id, e])).values()];
      detectGoals(uniq);
      S.events = uniq; S.lastFetch = Date.now(); S.error = null;
    } catch (e) { S.error = 'تعذّر الوصول لكل السيرفرات. سنعيد المحاولة تلقائياً.'; }
    S.loading = false;
    const live = S.events.some(e => e.state === 'in');
    S.refreshEvery = live ? 15 : 60; setCountdown();
    if (S.view === 'home') { drawHero(); drawHomeList(); drawLeagueChips(); }
  }

  function renderHome() {
    app.innerHTML = `
      <section class="hero" id="hero"><div class="hero-skel skel"></div></section>
      <section class="daybar" aria-label="اختيار اليوم">
        <div class="days" id="days">${[-3, -2, -1, 0, 1, 2, 3].map(o => { const d = dateAt(o); return `<button class="day ${o === S.dayOffset ? 'on' : ''}" data-day="${o}"><small>${dayLabel(o) || d.toLocaleDateString('ar-IQ', { weekday: 'short' })}</small><b>${d.getDate()}</b></button>`; }).join('')}</div>
        <label class="search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input id="q" type="search" placeholder="ابحث عن فريق…" value="${esc(S.q)}" aria-label="ابحث عن فريق"></label>
      </section>
      <div class="chips" id="chips"></div>
      <section id="list" class="list" aria-live="polite"></section>`;
    $('#days').addEventListener('click', e => { const b = e.target.closest('[data-day]'); if (!b) return; S.dayOffset = +b.dataset.day; S.events = []; renderHome(); });
    $('#q').addEventListener('input', e => { S.q = e.target.value; drawHomeList(); });
    drawLeagueChips(); drawHomeList();
    if (S.events.length && Date.now() - S.lastFetch < 15000) { drawHero(); } else loadHome(false);
  }

  function drawLeagueChips() {
    const el = $('#chips'); if (!el) return;
    const present = new Set(S.events.map(e => e.league));
    const list = YH.LEAGUES.filter(l => present.has(l.id));
    el.innerHTML = `<button class="chip ${S.league === 'all' ? 'on' : ''}" data-lg="all">الكل <i>${S.events.length}</i></button>
      <button class="chip chip-live ${S.league === 'live' ? 'on' : ''}" data-lg="live"><span class="pulse"></span>مباشر <i>${S.events.filter(e => e.state === 'in').length}</i></button>
      ${list.map(l => `<button class="chip ${S.league === l.id ? 'on' : ''}" data-lg="${l.id}">${l.short} <i>${S.events.filter(e => e.league === l.id).length}</i></button>`).join('')}`;
    el.onclick = e => { const b = e.target.closest('[data-lg]'); if (!b) return; S.league = b.dataset.lg; drawLeagueChips(); drawHomeList(); };
  }

  function pickFeatured() {
    const ev = S.events.slice();
    const score = e => (e.state === 'in' ? 100 : e.state === 'pre' ? 40 : 20) - e.tier * 10 + (e.home.score || 0) + (e.away.score || 0);
    return ev.sort((a, b) => score(b) - score(a))[0];
  }
  function drawHero() {
    const el = $('#hero'); if (!el) return;
    const e = pickFeatured();
    const d = dateAt(S.dayOffset);
    const liveN = S.events.filter(x => x.state === 'in').length;
    if (!e) {
      el.innerHTML = `<div class="hero-copy"><p class="eyebrow">${fmtDay(d)}</p><h1>شكو ماكو بالملاعب؟</h1><p class="lede">${S.loading ? 'نجمع المباريات من كل الدوريات…' : 'لا مباريات كبرى في هذا اليوم. جرّب يوماً آخر.'}</p></div>`;
      return;
    }
    const c = viz.teamColors(e.home, e.away);
    el.innerHTML = `
      <div class="hero-bg" style="--ch:${c.home};--ca:${c.away}"></div>
      
      <div class="hero-copy">
        <p class="eyebrow">${fmtDay(d)} · ${liveN ? `<span class="live-tag"><span class="pulse"></span>${liveN} مباشر الآن</span>` : `${S.events.length} مباراة`}</p>
        <h1>شكو ماكو بالملاعب؟</h1>
      </div>
      <button class="feature" data-match="${e.league}:${e.id}" aria-label="افتح مباراة ${esc(AR(e.home.name))} و${esc(AR(e.away.name))}">
        <span class="f-league">${esc(leagueAr(e.league))}</span>
        <span class="f-team">${logo(e.home.logo, e.home.name, 'crest crest-xl')}<b>${esc(AR(e.home.name))}</b></span>
        <span class="f-mid">
          ${e.state === 'pre' ? `<span class="f-time">${fmtTime(e.date)}</span><span class="f-q">يمكن هدف؟</span>` : `<span class="f-score"><span>${e.home.score}</span><i>:</i><span>${e.away.score}</span></span>`}
          <span class="f-status ${e.state}">${e.state === 'in' ? '<span class="pulse"></span>' : ''}${e.state === 'pre' ? esc(countdown(e.date)) : esc(statusAr(e))}</span>
        </span>
        <span class="f-team">${logo(e.away.logo, e.away.name, 'crest crest-xl')}<b>${esc(AR(e.away.name))}</b></span>
        <span class="f-cta">${e.state === 'pre' ? 'المحلل يشرح المباراة' : e.state === 'in' ? 'تابع مباشر' : 'الأهداف والتحليل'} ←</span>
      </button>
      <button class="hero-robo" data-match="${e.league}:${e.id}"><span class="hero-toons"><img src="assets/toon1-head.webp" alt=""><img src="assets/toon7-head.webp" alt=""></span><span><b>استوديو المحللين جاهز يشرحلك</b><small>${e.state === 'pre' ? `شلون راح يلعب ${esc(AR(e.home.name))} و${esc(AR(e.away.name))}، ومنو يفوز وليش` : 'شنو صار بالمباراة، بالرسوم والصوت'}</small></span></button>`;
  }

  function matchRow(e) {
    const live = e.state === 'in', post = e.state === 'post';
    const hw = post && e.home.score > e.away.score, aw = post && e.away.score > e.home.score;
    return `<button class="row ${e.state}" data-match="${e.league}:${e.id}">
      <span class="r-status">${live ? '<span class="pulse"></span>' : ''}${esc(statusAr(e))}</span>
      <span class="r-team r-home ${aw ? 'lose' : ''}"><b>${esc(AR(e.home.name))}</b>${logo(e.home.logo, e.home.name)}</span>
      <span class="r-score">${e.state === 'pre' ? '<i class="vs">ضد</i>' : `<b>${e.home.score}</b><i>-</i><b>${e.away.score}</b>`}</span>
      <span class="r-team r-away ${hw ? 'lose' : ''}">${logo(e.away.logo, e.away.name)}<b>${esc(AR(e.away.name))}</b></span>
      <span class="r-go" aria-hidden="true">‹</span>
    </button>`;
  }
  function drawHomeList() {
    const el = $('#list'); if (!el) return;
    if (S.loading && !S.events.length) { el.innerHTML = Array.from({ length: 3 }, () => `<div class="group"><div class="skel skel-h"></div>${'<div class="skel skel-row"></div>'.repeat(4)}</div>`).join(''); return; }
    if (S.error && !S.events.length) { el.innerHTML = `<div class="empty"><img class="robo-ico lg" src="assets/robot-head.webp" alt=""><p>${S.error}</p><button class="btn" data-refresh-home>إعادة المحاولة</button></div>`; el.querySelector('[data-refresh-home]').onclick = () => loadHome(false); return; }
    let ev = S.events.slice();
    if (S.league === 'live') ev = ev.filter(e => e.state === 'in'); else if (S.league !== 'all') ev = ev.filter(e => e.league === S.league);
    if (S.q.trim()) { const q = S.q.trim().toLowerCase(); ev = ev.filter(e => [e.home.name, e.away.name, AR(e.home.name), AR(e.away.name)].some(n => n.toLowerCase().includes(q))); }
    if (!ev.length) { el.innerHTML = `<div class="empty"><img class="robo-ico lg" src="assets/robot-head.webp" alt=""><p>${S.league === 'live' ? 'لا توجد مباريات مباشرة حالياً.' : 'لا توجد مباريات مطابقة.'}</p></div>`; return; }
    const order = id => YH.LEAGUES.findIndex(l => l.id === id);
    const groups = {}; ev.forEach(e => (groups[e.league] = groups[e.league] || []).push(e));
    el.innerHTML = Object.keys(groups).sort((a, b) => order(a) - order(b)).map(lg => {
      const arr = groups[lg].sort((a, b) => (a.state === 'in' ? -1 : 0) - (b.state === 'in' ? -1 : 0) || new Date(a.date) - new Date(b.date));
      return `<div class="group"><h2 class="g-head">${logo(arr[0].leagueLogo, arr[0].leagueName, 'lg-logo')}<span>${esc(leagueAr(lg))}</span><i>${arr.length}</i></h2>${arr.map(matchRow).join('')}</div>`;
    }).join('');
  }

  /* ======================= MATCH ======================= */
  async function loadMatch(silent) {
    const m = S.match; if (!m) return;
    S.loading = true;
    try {
      const sum = await api.summary(m.league, m.id);
      if (!S.match || S.match.id !== m.id) return;
      const prev = S.sum;
      S.sum = sum; S.sumCache.set(m.id, sum);
      const ev = headerEvent(sum, m);
      if (prev) detectGoals([ev]); else S.scores.set(ev.id, [ev.home.score, ev.away.score]);
      m.ev = { ...(m.ev || {}), ...ev };
      S.refreshEvery = ev.state === 'in' ? 15 : 60; setCountdown();
      if (S.view === 'match') {
        drawMatchHeader();
        if (!S.tab) S.tab = defTab();
        drawTabs();
        if (!silent || ['live', 'stats', 'lineup'].includes(S.tab)) drawTab();
      }
      if (!prev) setTimeout(() => { if (S.match && S.match.id === m.id) getCtx(); }, 50); // prefetch analyst context
    } catch (e) {
      if (!S.sum) app.querySelector('#tabBody').innerHTML = `<div class="empty"><img class="robo-ico lg" src="assets/robot-head.webp" alt=""><p>تعذّر تحميل بيانات المباراة. سنعيد المحاولة عبر سيرفر آخر.</p></div>`;
    }
    S.loading = false;
  }
  function headerEvent(sum, m) {
    const c = sum.header.competitions[0];
    const t = s => { const x = c.competitors.find(k => k.homeAway === s); const base = m.ev && m.ev[s] ? m.ev[s] : {};
      return { ...base, id: x.team.id, name: x.team.displayName, logo: (x.team.logos && x.team.logos[0] && x.team.logos[0].href) || base.logo, color: x.team.color || base.color, alt: x.team.alternateColor || base.alt, score: x.score != null ? +x.score : null, form: x.form || base.form || '', shootout: x.shootoutScore }; };
    return { id: m.id, league: m.league, date: c.date, state: c.status.type.state, statusName: c.status.type.name, clock: c.status.displayClock, completed: c.status.type.completed, home: t('home'), away: t('away'), tier: 1 };
  }

  function renderMatchShell() {
    const ev = S.match.ev;
    app.innerHTML = `<button class="back" data-nav="home">→ رجوع للمباريات</button>
      <section class="mhead" id="mhead">${ev && ev.home ? '' : '<div class="skel" style="height:220px"></div>'}</section>
      <button class="ai-cta" id="aiBtn" type="button"><span class="ai-faces">${[1, 2, 3, 7].map(i => `<img src="assets/toon${i}-head.webp" alt="">`).join('')}</span><span class="ai-txt"><b>استوديو المحللين</b><small>7 شخصيات كارتونية تشرح التكتيك وشلون جات الأهداف</small></span><span class="ai-go" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M16 6v12L7 12z"/></svg></span></button>
      <nav class="tabs" id="tabs" role="tablist"></nav>
      <section id="tabBody" class="tabbody"><div class="skel" style="height:320px"></div></section>`;
    app.querySelector('#aiBtn').onclick = openAnalyst;
    if (ev && ev.home) drawMatchHeader();
    const cached = S.sumCache.get(S.match.id);
    if (cached) { S.sum = cached; drawMatchHeader(); S.tab = S.tab || defTab(); drawTabs(); drawTab(); }
    loadMatch(false);
  }

  const defTab = () => S.match.ev && S.match.ev.state === 'pre' ? 'lineup' : 'live';
  async function openAnalyst() {
    const btn = $('#aiBtn'); if (!btn || btn.classList.contains('busy')) return;
    if (!S.sum) { toast('لحظة، نجيب بيانات المباراة…'); return; }
    const id = S.match.ev.id; let cx = ctxDone.get(id);
    if (!cx) {
      btn.classList.add('busy'); btn.querySelector('small').textContent = 'لحظة، المحلل يحضّر الشاشة…';
      cx = await within(getCtx(), 1200, null);
      btn.classList.remove('busy'); btn.querySelector('small').textContent = 'محلل يشرح التكتيك كامل على شاشة إلكترونية';
    }
    if (S.view !== 'match') return;
    YH.analyst.open({ ev: S.match.ev, sum: S.sum, c: colors(), mode: S.match.ev.state, ppH: null, ppA: null, lmH: null, lmA: null, P: null, ...(cx || {}) });
    if (!cx) getCtx().then(v => { if (YH.analyst.isOpen() && S.match && S.match.ev.id === id) YH.analyst.refresh(v); });
  }
  function colors() { const e = S.match.ev; return viz.teamColors(e.home, e.away); }

  function drawMatchHeader() {
    const el = $('#mhead'); if (!el) return;
    const e = S.match.ev; const c = colors();
    const sum = S.sum;
    const goals = sum ? (sum.keyEvents || []).filter(k => k.scoringPlay) : [];
    const cxh = ctxDone.get(e.id) || null;
    const gl = side => goals.filter(g => g.team && g.team.id === e[side].id).map(g => `<li>${esc(arName(cxh, (g.participants && g.participants[0] && g.participants[0].athlete.displayName) || '', side))} <i>${esc(g.clock && g.clock.displayValue)}${/penalty/i.test(g.type && g.type.text) ? ' (ج)' : ''}${/own/i.test(g.type && g.type.text) ? ' (ع.م)' : ''}</i></li>`).join('');
    const venue = sum && sum.gameInfo && sum.gameInfo.venue ? sum.gameInfo.venue.fullName : '';
    el.innerHTML = `<div class="mh-bg" style="--ch:${c.home};--ca:${c.away}"></div>
      <p class="mh-league">${esc(leagueAr(e.league))}${venue ? ' · ' + esc(venue) : ''}</p>
      <div class="mh-grid">
        <div class="mh-team">${logo(e.home.logo, e.home.name, 'crest crest-xl')}<b>${esc(AR(e.home.name))}</b><ul class="mh-scorers">${gl('home')}</ul></div>
        <div class="mh-mid">
          ${e.state === 'pre' ? `<div class="mh-time">${fmtTime(e.date)}</div><div class="mh-date">${fmtDay(new Date(e.date))}</div>` : `<div class="mh-score"><span>${e.home.score}</span><i>:</i><span>${e.away.score}</span></div>`}
          ${e.home.shootout != null ? `<div class="mh-pen">ركلات الترجيح ${e.home.shootout}-${e.away.shootout}</div>` : ''}
          <div class="mh-status ${e.state}">${e.state === 'in' ? '<span class="pulse"></span>' : ''}${esc(statusAr(e))}</div>
        </div>
        <div class="mh-team">${logo(e.away.logo, e.away.name, 'crest crest-xl')}<b>${esc(AR(e.away.name))}</b><ul class="mh-scorers">${gl('away')}</ul></div>
      </div>`;
  }

  const TABS = [
    { k: 'live', ar: 'مباشر', when: ['in', 'post'] },
    { k: 'goals', ar: 'الأهداف', when: ['in', 'post'] },
    { k: 'ai', ar: 'التحليل', when: ['in', 'post'] },
    { k: 'lineup', ar: 'التشكيلة', when: ['pre', 'in', 'post'] },
    { k: 'stats', ar: 'الإحصائيات', when: ['in', 'post'] },
    { k: 'predict', ar: 'التوقع', when: ['pre', 'in', 'post'] },
    { k: 'watch', ar: 'وين أشوفها؟', when: ['pre', 'in', 'post'] },
  ];
  function drawTabs() {
    const st = S.match.ev.state;
    const el = $('#tabs');
    el.innerHTML = TABS.filter(t => t.when.includes(st)).map(t => `<button role="tab" aria-selected="${S.tab === t.k}" class="tab ${S.tab === t.k ? 'on' : ''} ${t.hot ? 'hot' : ''}" data-tab="${t.k}">${t.ar}</button>`).join('');
    el.onclick = e => { const b = e.target.closest('[data-tab]'); if (!b) return; S.tab = b.dataset.tab; clearInterval(S.storyTimer); YH.studio.stop(); S.storyIdx = 0; drawTabs(); drawTab(); };
  }
  function drawTab() {
    const b = $('#tabBody'); if (!b || !S.sum) return;
    const fn = { robo: tabRobo, live: tabLive, goals: tabGoals, ai: tabAI, lineup: tabLineup, stats: tabStats, predict: tabPredict, watch: tabWatch }[S.tab];
    try { fn(b); } catch (err) { console.error(err); b.innerHTML = `<div class="empty"><p>لا تتوفر بيانات كافية لهذا القسم بعد.</p></div>`; }
  }

  /* ---- Arabic commentary ---- */
  function arPlay(p, sum) {
    const t = (p.type && p.type.type) || ''; const who = p.participants && p.participants[0] && p.participants[0].athlete.displayName;
    const w2 = p.participants && p.participants[1] && p.participants[1].athlete.displayName;
    const side = ai.playTeamSide(sum, p); const tm = side ? AR(S.match.ev[side].name) : '';
    const M = {
      'goal': `هدف! ${who || ''} يسجّل لـ${tm}${w2 ? ` بصناعة ${w2}` : ''}`, 'goal---header': `هدف برأسية! ${who || ''} (${tm})${w2 ? ` من عرضية ${w2}` : ''}`,
      'goal---free-kick': `هدف من ركلة حرة مباشرة! ${who || ''} (${tm})`, 'penalty---scored': `هدف من ركلة جزاء! ${who || ''} (${tm})`,
      'penalty---saved': `الحارس يتصدّى لركلة جزاء ${who || ''}!`, 'penalty---missed': `${who || ''} يهدر ركلة جزاء`,
      'own-goal': `هدف عكسي عن طريق ${who || ''}`, 'shot-on-target': `تسديدة على المرمى من ${who || ''} (${tm}) — الحارس يتصدّى`,
      'shot-off-target': `تسديدة من ${who || ''} (${tm}) تمرّ خارج المرمى`, 'shot-blocked': `تسديدة ${who || ''} (${tm}) تُصدّ من الدفاع`,
      'shot-hit-woodwork': `القائم يحرم ${who || ''} (${tm}) من هدف!`, 'corner-awarded': `ركنية لـ${tm}`, 'offside': `تسلل على ${who || ''} (${tm})`,
      'foul': `خطأ من ${who || ''} (${tm})`, 'yellow-card': `بطاقة صفراء لـ${who || ''} (${tm})`, 'red-card': `بطاقة حمراء! طرد ${who || ''} (${tm})`,
      'substitution': `تبديل لـ${tm}: دخول ${who || ''}${w2 ? ` بدلاً من ${w2}` : ''}`, 'kickoff': 'صافرة البداية', 'halftime': 'نهاية الشوط الأول',
      'end-regular-time': 'نهاية المباراة', 'start-2nd-half': 'انطلاق الشوط الثاني', 'start-delay': 'توقف مؤقت للعب', 'end-delay': 'استئناف اللعب',
      'penalty---awarded': `ركلة جزاء لـ${tm}!`, 'var': 'مراجعة تقنية الفيديو', 'free-kick': `ركلة حرة لـ${tm}`,
    };
    return M[t] || null;
  }
  const ICON = t => /goal|scored/.test(t) ? 'goal' : /yellow/.test(t) ? 'yc' : /red-card/.test(t) ? 'rc' : /substitution/.test(t) ? 'sub' : /shot|woodwork|saved|missed/.test(t) ? 'shot' : /corner/.test(t) ? 'corner' : 'dot';

  function tabLive(b) {
    const sum = S.sum; const c = colors();
    const ps = (sum.commentary || []).slice().reverse();
    const mom = ai.momentum(sum);
    const goals = ai.shots(sum).filter(s => s.goal);
    b.innerHTML = `<div class="grid2">
      <div class="card"><div class="card-h"><h3>موجة الزخم الهجومي</h3><span class="legend"><i style="background:${c.home}"></i>${esc(AR(S.match.ev.home.name))} <i style="background:${c.away}"></i>${esc(AR(S.match.ev.away.name))}</span></div>${viz.momentumChart(mom, c, goals)}<p class="hint">كل موجة تمثّل الضغط الهجومي (تسديدات، ركنيات، فرص) كل 5 دقائق.</p></div>
      <div class="card feed"><div class="card-h"><h3>التعليق لحظة بلحظة</h3>${S.match.ev.state === 'in' ? '<span class="live-tag"><span class="pulse"></span>مباشر</span>' : ''}</div>
      <ol class="feedlist">${ps.map(x => { const p = x.play || {}; const t = (p.type && p.type.type) || ''; const ar = x.play ? arPlay(p, sum) : null; const side = x.play ? ai.playTeamSide(sum, p) : null;
        return `<li class="fi ${ICON(t)} ${side || ''}" style="${side ? `--tc:${c[side]}` : ''}"><span class="fi-min">${esc((x.time && x.time.displayValue) || '')}</span><span class="fi-ico"></span><span class="fi-txt">${ar ? `<b>${esc(ar)}</b>` : `<small>${esc(x.text || '')}</small>`}</span></li>`; }).join('') || '<li class="fi"><span class="fi-txt">التعليق يبدأ مع صافرة البداية.</span></li>'}</ol></div></div>`;
  }

  /* ---------- robot context: people (photos/Arabic names/coaches), last matches, prediction ---------- */
  const ROBO = '<img class="robo-ico" src="assets/robot-head.webp" alt="">';
  const ctxCache = new Map(), ctxDone = new Map();
  const within = (pr, ms, fb) => Promise.race([Promise.resolve(pr).catch(() => fb), new Promise(r => setTimeout(() => r(fb), ms))]);
  function getCtx() {
    const e = S.match.ev; const k = e.id;
    if (ctxCache.has(k)) return ctxCache.get(k);
    const p = (async () => {
      const nat = YH.NATIONAL_LEAGUES.test(e.league);
      const [ppH, ppA, lmH, lmA, P] = await Promise.all([
        within(api.people(e.home, nat), 6000, null), within(api.people(e.away, nat), 6000, null),
        within(api.lastMatch(e.home.id, e.date), 6000, null), within(api.lastMatch(e.away.id, e.date), 6000, null),
        within(buildPrediction(e, S.sum), 6000, null),
      ]);
      if (P) [[lmH, 'home'], [lmA, 'away']].forEach(([lm, sd]) => {
        if (!lm) return; try { const x = ai.analyze(lm.sum).xg[lm.side]; P.reasons.push(`بآخر مباراة صنع ${AR(e[sd].name)} فرصاً بقيمة ${x.toFixed(2)} xG ${lm.gf > lm.ga ? 'وفاز' : lm.gf < lm.ga ? 'وخسر' : 'وتعادل'} ${lm.gf}-${lm.ga} أمام ${AR(lm.opp)}.`); } catch (er) {}
      });
      const v = { ppH, ppA, lmH, lmA, P }; ctxDone.set(k, v); return v;
    })();
    ctxCache.set(k, p); return p;
  }
  const ppOf = (cx, side) => cx ? (side === 'home' ? cx.ppH : cx.ppA) : null;
  function arName(cx, name, side) {
    if (!cx || !name) return name || '';
    const sides = side ? [side] : ['home', 'away'];
    for (const sd of sides) { const r = api.personFor(ppOf(cx, sd), { displayName: name }); if (r && r.ar && /[\u0600-\u06FF]/.test(r.ar)) return r.ar; }
    return name;
  }
  function imgOf(cx, ath, side) { if (!cx) return null; for (const sd of side ? [side] : ['home', 'away']) { const r = api.personFor(ppOf(cx, sd), ath); if (r && r.img) return r.img; } return null; }

  async function tabRobo(b) {
    b.innerHTML = `<div class="card"><div class="think">${ROBO.replace('robo-ico', 'robo-ico lg spin-soft')}<p>روبو يحضّر الشرح: يجمع التشكيلات، صور اللاعبين والمدربين، أسلوب كل فريق، المراهنات وأسواق التوقعات…</p></div></div>`;
    const cx = await getCtx();
    drawMatchHeader();
    if (S.tab !== 'robo' || S.view !== 'match') return;
    YH.studio.mount(b, { ev: S.match.ev, sum: S.sum, c: colors(), mode: S.match.ev.state, ...cx });
  }

  function tabGoals(b) {
    const sum = S.sum; const c = colors(); const e = S.match.ev;
    const goals = ai.shots(sum).filter(s => s.goal).sort((a, b) => a.min - b.min);
    const cx = ctxDone.get(e.id) || null;
    if (!cx) getCtx().then(() => { if (S.tab === 'goals') tabGoals(b); });
    const H = AR(e.home.name), Aw = AR(e.away.name);
    const ytQ = encodeURIComponent(`ملخص اهداف ${H} و${Aw} تعليق عربي`);
    const prevMain = b.querySelector('#ytMain');
    const vclips = YH.analyst.goalClips(sum).filter(v => v.goal || v.hl).sort((x, y) => (y.goal - x.goal));
    const vcard = vclips.length ? `<div class="card vcard"><div class="card-h"><h3>فيديو الأهداف</h3><span class="muted">${vclips.length} ${vclips.length === 1 ? 'مقطع' : 'مقاطع'} · تعليق أجنبي</span></div>
        <div class="vplay"><video id="vMain" src="${esc(vclips[0].src)}" poster="${esc(vclips[0].thumb || '')}" controls playsinline preload="metadata"></video></div>
        <div class="alts">${vclips.map((v, i) => `<button class="alt ${i ? '' : 'on'}" data-vc="${i}"><img src="${esc(v.thumb || '')}" alt="" loading="lazy"><span>${esc(v.goal ? 'هدف · ' + v.title : 'ملخص · ' + v.title)}</span></button>`).join('')}</div></div>` : '';
    b.innerHTML = vcard + `
      <div class="card"><div class="card-h"><h3>ملخص الأهداف بالتعليق العربي</h3><span class="muted">${goals.length} ${goals.length === 1 ? 'هدف' : goals.length === 2 ? 'هدفين' : 'أهداف'}</span></div>
        <div id="ytMain">${prevMain ? prevMain.innerHTML : `<div class="yt-wait">${ROBO}<p>روبو يدوّر على ملخص الأهداف بصوت المعلقين العرب…</p></div>`}</div>
        <div class="alts" id="ytAlts"></div>
        <p class="hint">نعرض الأهداف فقط وبالتعليق العربي، من قنوات يوتيوب عامة تُرفع عليها المقاطع. أول ما ينزل مقطع جديد يظهر هنا تلقائياً.</p>
      </div>
      <div class="card"><div class="card-h"><h3>الأهداف هدف بهدف</h3><span class="muted">فيديو + إعادة رسومية</span></div>
        ${goals.length ? `<ol class="goal-list">${goals.map((g, i) => { const img = imgOf(cx, { displayName: g.who }, g.side); const nm = arName(cx, g.who, g.side);
          return `<li class="gl" style="--tc:${c[g.side]}"><span class="gl-min">${Math.floor(g.min)}'</span><span class="gl-ph">${img ? `<img src="${esc(img)}" alt="" loading="lazy">` : logo(e[g.side].logo, e[g.side].name)}</span><span class="gl-who"><b>${esc(nm)}</b><small>${esc(AR(e[g.side].name))}${/penalty/i.test(g.type) ? ' · ركلة جزاء' : /own/i.test(g.type) ? ' · هدف عكسي' : /header/i.test(g.type) ? ' · رأسية' : ''}</small></span>
            <span class="gl-acts"><button class="btn btn-sm" data-gv="${i}">فيديو الهدف</button><button class="btn btn-ghost btn-sm" data-g="${i}">إعادة رسومية</button></span></li>`; }).join('')}</ol>
          <div class="replay-stage" id="stage" hidden></div>`
        : `<p class="muted pad">لا أهداف ${e.state === 'in' ? 'حتى الآن… يمكن هدف؟' : 'في هذه المباراة.'}</p>`}
      </div>`;
    const play = i => {
      const g = goals[i]; const st = $('#stage'); st.hidden = false;
      st.innerHTML = viz.goalReplay(g, c, i + '_' + Date.now()) + `<div class="stage-cap">${esc(Math.floor(g.min) + "' " + arName(cx, g.who, g.side))}</div>`;
      setTimeout(() => YH.robot.voice.speak(`جووول! ${arName(cx, g.who, g.side)} يسجّل لـ${AR(e[g.side].name)}!`, { rate: 1.12, pitch: 1.25 }), 900);
      st.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    };
    b.querySelectorAll('[data-g]').forEach(x => x.onclick = () => play(+x.dataset.g));
    b.querySelectorAll('[data-vc]').forEach(x => x.onclick = () => { const v = vclips[+x.dataset.vc], m = b.querySelector('#vMain'); m.src = v.src; m.poster = v.thumb || ''; m.play().catch(() => {}); b.querySelectorAll('[data-vc]').forEach(k => k.classList.toggle('on', k === x)); m.scrollIntoView({ behavior: 'smooth', block: 'center' }); });
    b.querySelectorAll('[data-gv]').forEach(x => x.onclick = async () => {
      const g = goals[+x.dataset.gv]; const nm = arName(cx, g.who, g.side);
      const ec = vclips.length && YH.analyst.goalClips && vclips.find(v => v.goal && v.title.toLowerCase().includes(shortName(g.who).toLowerCase()));
      if (ec) { const m = b.querySelector('#vMain'); m.src = ec.src; m.poster = ec.thumb || ''; m.play().catch(() => {}); m.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
      x.disabled = true; x.textContent = 'نبحث…';
      const v = await api.arabicClips({ teamsAr: [H, Aw], teamsEn: [e.home.name, e.away.name], date: e.date, scorer: nm !== g.who ? nm : shortName(g.who), kind: 'goal' }).catch(() => []);
      x.disabled = false; x.textContent = 'فيديو الهدف';
      if (v.length) openPlayer(v[0].id, v[0].title);
      else { toast('ما نزل مقطع منفصل لهذا الهدف بعد، شغّلنا ملخص الأهداف'); const m = b.querySelector('[data-yt]'); if (m) m.click(); else window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent('هدف ' + nm + ' ' + H + ' ' + Aw)}`, '_blank', 'noopener'); }
    });
    if (prevMain && b._clipsFor === e.id) return;
    b._clipsFor = e.id;
    api.arabicClips({ teamsAr: [H, Aw], teamsEn: [e.home.name, e.away.name], date: e.date, kind: 'match' }).catch(() => []).then(v => {
      const main = b.querySelector('#ytMain'), alts = b.querySelector('#ytAlts'); if (!main || S.tab !== 'goals') return;
      if (!v.length) { main.innerHTML = `<div class="yt-wait">${ROBO}<p>${e.state === 'in' ? 'المقاطع تنزل بعد كل هدف بدقائق. روبو يراقب ويجيبها لك هنا.' : 'ما لگينا ملخص بالتعليق العربي لحد الآن.'}</p><a class="btn" href="https://www.youtube.com/results?search_query=${ytQ}" target="_blank" rel="noopener">ابحث بيوتيوب</a></div>`; return; }
      const embed = (x, auto) => `<div class="yt"><iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(x.id)}?rel=0&playsinline=1${auto ? '&autoplay=1' : ''}" title="${esc(x.title)}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen loading="lazy"></iframe></div><p class="yt-cap"><b>${esc(x.title)}</b><small>${esc(x.channel)}${x.verified ? ' ✓' : ''}</small></p>`;
      main.innerHTML = embed(v[0]);
      alts.innerHTML = v.slice(0, 5).map((x, i) => `<button class="alt ${i ? '' : 'on'}" data-yt="${i}"><img src="${esc(x.thumb)}" alt="" loading="lazy"><span>${esc(x.title)}</span></button>`).join('');
      alts.onclick = ev => { const k = ev.target.closest('[data-yt]'); if (!k) return; main.innerHTML = embed(v[+k.dataset.yt], true); alts.querySelectorAll('.alt').forEach(a => a.classList.toggle('on', a === k)); };
    });
  }
  const shortName = n => (n || '').split(' ').slice(-1)[0];

  function tabStats(b) {
    const ts = ai.teamStats(S.sum); const c = colors(); const e = S.match.ev;
    const rows = YH.STAT_ORDER.filter(k => ts.home[k] != null || ts.away[k] != null).map(k => {
      const h = ts.home[k] || 0, a = ts.away[k] || 0, tot = h + a || 1;
      return `<div class="srow"><b>${h}${k.endsWith('Pct') ? '%' : ''}</b><span class="slab">${YH.STAT_AR[k] || k}</span><b>${a}${k.endsWith('Pct') ? '%' : ''}</b>
        <div class="sbar"><i style="--w:${(h / tot * 100).toFixed(1)}%;--c:${c.home}" class="${h >= a ? 'lead' : ''}"></i><i style="--w:${(a / tot * 100).toFixed(1)}%;--c:${c.away}" class="${a >= h ? 'lead' : ''}"></i></div></div>`;
    }).join('');
    b.innerHTML = `<div class="card"><div class="card-h"><h3>إحصائيات الفريقين</h3><span class="legend"><i style="background:${c.home}"></i>${esc(AR(e.home.name))} <i style="background:${c.away}"></i>${esc(AR(e.away.name))}</span></div><div class="stats">${rows || '<p class="muted pad">الإحصائيات تظهر بعد انطلاق المباراة.</p>'}</div></div>`;
  }

  function coachCards(cx, c) {
    const e = S.match.ev;
    return `<div class="card"><div class="card-h"><h3>المدربين</h3><span class="muted">الأسلوب حسب المحلل</span></div><div class="coaches">${['home', 'away'].map(sd => {
      const pr = YH.studio.coachProfile(ppOf(cx, sd), cx && (sd === 'home' ? cx.lmH : cx.lmA));
      return `<div class="coach" style="--tc:${c[sd]}">${pr.img ? `<img src="${esc(pr.img)}" alt="${esc(pr.name)}" loading="lazy">` : '<span class="cc-fb">م</span>'}<div><small>${esc(AR(e[sd].name))}</small><b>${esc(pr.name || '—')}</b><span class="cc-tags">${pr.tags.map(t => `<i>${esc(YH.COACH_TAG_AR[t] || t)}</i>`).join('')}</span><p>${esc(pr.style)}</p></div></div>`; }).join('')}</div></div>`;
  }
  function tabLineup(b) {
    let sum = S.sum; const c = colors(); const e = S.match.ev;
    const cx = ctxDone.get(e.id) || null;
    if (!cx) { getCtx().then(() => { if (S.tab === 'lineup') drawTab(); }); }
    let rs = sum.rosters || [];
    let hasStarters = rs.some(r => (r.roster || []).some(p => p.starter));
    let expected = false;
    if (!hasStarters && cx && cx.lmH && cx.lmA) {
      rs = [{ ...cx.lmH.roster, homeAway: 'home' }, { ...cx.lmA.roster, homeAway: 'away' }];
      sum = { ...sum, rosters: rs }; hasStarters = true; expected = true;
    }
    const photoOf = ath => imgOf(cx, ath);
    if (!hasStarters) {
      b.innerHTML = `<div class="card"><div class="empty">${ROBO.replace('robo-ico', 'robo-ico lg')}<p>${cx ? 'التشكيلات الرسمية تُعلن عادةً قبل ساعة من صافرة البداية. سنحدّثها تلقائياً.' : 'روبو يجهّز التشكيلة المتوقعة وصور اللاعبين…'}</p></div></div>${cx ? coachCards(cx, c) : ''}`;
      return;
    }
    const rt = ai.ratings(sum); const rmap = new Map(rt.map(r => [r.name, r.rating]));
    const bench = r => (r.roster || []).filter(p => !p.starter).map(p => `<li class="${p.subbedIn ? 'in' : ''}"><span class="num" style="--tc:${c[r.homeAway]}">${esc(p.jersey)}</span>${esc(p.athlete.displayName)}${p.subbedIn ? `<small>دخل ${esc((p.plays || []).find(x => x.substitution) ? (p.plays.find(x => x.substitution).clock.displayValue) : '')}</small>` : ''}${rmap.has(p.athlete.displayName) && p.subbedIn ? `<em class="rt">${rmap.get(p.athlete.displayName).toFixed(1)}</em>` : ''}</li>`).join('');
    const fm = s => (rs.find(r => r.homeAway === s) || {}).formation || '';
    b.innerHTML = `<div class="lineup-wrap">
      <div class="card pitch-card"><div class="card-h"><h3>${expected ? 'التشكيلة المتوقعة (حسب آخر مباراة)' : 'التشكيلة على أرض الملعب'}</h3><span class="muted">اضغط على أي لاعب</span></div>
        <div class="fm-row"><span style="--tc:${c.away}">${esc(AR(e.away.name))} <b dir="ltr">${esc(fm('away'))}</b></span></div>
        <div class="pitch-holder">${viz.lineupPitch(sum, c, null, photoOf)}<div class="pop" id="pop" hidden></div></div>
        <div class="fm-row"><span style="--tc:${c.home}">${esc(AR(e.home.name))} <b dir="ltr">${esc(fm('home'))}</b></span></div></div>
      ${coachCards(cx, c)}<div class="card"><div class="card-h"><h3>الاحتياط والتبديلات</h3></div>
        <div class="grid2">${['home', 'away'].map(s => { const r = rs.find(x => x.homeAway === s) || {}; return `<div><h4 class="bh">${esc(AR(e[s].name))}</h4><ul class="bench">${bench(r)}</ul></div>`; }).join('')}</div></div></div>`;
    const pop = $('#pop');
    b.querySelectorAll('.pl-player').forEach(g => {
      const show = () => {
        const pid = g.dataset.pid; let pl, side;
        rs.forEach(r => (r.roster || []).forEach(p => { if (p.athlete.id === pid) { pl = p; side = r.homeAway; } }));
        if (!pl) return;
        const st = {}; (pl.stats || []).forEach(x => st[x.name] = x.displayValue);
        const rr = rmap.get(pl.athlete.displayName);
        const items = [['totalGoals', 'أهداف'], ['goalAssists', 'صناعة'], ['totalShots', 'تسديدات'], ['shotsOnTarget', 'على المرمى'], ['saves', 'تصديات'], ['foulsCommitted', 'أخطاء'], ['foulsSuffered', 'تعرّض لخطأ']].filter(([k]) => st[k] != null && (k !== 'saves' || pl.position.abbreviation === 'G'));
        const ph = imgOf(cx, pl.athlete, side);
        pop.innerHTML = `<div class="pop-h" style="--tc:${c[side]}">${ph ? `<img class="pop-img" src="${esc(ph)}" alt="">` : `<span class="num">${esc(pl.jersey)}</span>`}<div><b>${esc(arName(cx, pl.athlete.displayName, side))}</b><small>${esc(pl.position && pl.position.displayName)} · ${esc(AR(e[side].name))}</small></div>${rr ? `<em class="rt big">${rr.toFixed(1)}</em>` : ''}</div>
          <div class="pop-grid">${items.map(([k, l]) => `<span><b>${st[k]}</b><small>${l}</small></span>`).join('')}</div>${pl.subbedOut ? `<p class="muted">خرج في الدقيقة ${esc(((pl.plays || []).find(x => x.substitution) || { clock: {} }).clock.displayValue || '')}</p>` : ''}`;
        pop.hidden = false;
      };
      g.addEventListener('click', show); g.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); show(); } });
    });
    b.querySelector('.pitch-holder').addEventListener('click', ev => { if (!ev.target.closest('.pl-player') && !ev.target.closest('.pop')) pop.hidden = true; });
  }

  /* ---- AI story ---- */
  function tabAI(b) {
    const A = ai.analyze(S.sum); const c = colors(); const e = S.match.ev;
    if (!A.sh.length && !A.ts.home.totalShots) { b.innerHTML = `<div class="card"><div class="empty"><img class="robo-ico lg" src="assets/robot-head.webp" alt=""><p>التحليل يبدأ بعد الدقائق الأولى من المباراة.</p></div></div>`; return; }
    const H = AR(e.home.name), Aw = AR(e.away.name);
    const st = Object.fromEntries(A.story.map(s => [s.k, s]));
    const star = A.rt[0]; const topH = A.rt.filter(r => r.side === 'home').slice(0, 3), topA = A.rt.filter(r => r.side === 'away').slice(0, 3);
    const scenes = [
      { t: 'حكم المباراة', html: () => `<div class="sc-verdict"><div class="xg-duel"><div style="--tc:${c.home}"><small>${esc(H)}</small><b class="count" data-to="${A.xg.home.toFixed(2)}">0.00</b><i>xG</i></div><span class="xg-vs">الأهداف المتوقعة</span><div style="--tc:${c.away}"><small>${esc(Aw)}</small><b class="count" data-to="${A.xg.away.toFixed(2)}">0.00</b><i>xG</i></div></div><p class="sc-text">${esc(st.verdict.text)}</p><p class="sc-sub">${esc(st.eff.text)}</p></div>` },
      { t: 'من سيطر؟', html: () => `<div class="sc-mom">${viz.momentumChart(A.mom, c, A.goals)}<div class="dom"><span style="--w:${(A.domShare.home * 100).toFixed(0)}%;--c:${c.home}">${Math.round(A.domShare.home * 100)}%</span><span style="--w:${(A.domShare.away * 100).toFixed(0)}%;--c:${c.away}">${Math.round(A.domShare.away * 100)}%</span></div><p class="sc-text">${esc(st.control.text)}</p><p class="sc-sub">${esc(st.phases.text)}</p></div>` },
      { t: 'خريطة الفرص', html: () => `<div class="sc-shots">${viz.shotMap(A.sh, c)}<div class="shot-legend"><span><i class="lg-goal"></i>هدف</span><span><i class="lg-on"></i>على المرمى</span><span><i class="lg-off"></i>خارج المرمى</span><span>حجم الدائرة = خطورة الفرصة</span></div><p class="sc-sub">${A.sh.filter(s => s.side === 'home').length} تسديدة لـ${esc(H)} (يهاجم نحو اليسار) · ${A.sh.filter(s => s.side === 'away').length} لـ${esc(Aw)} (يهاجم نحو اليمين)</p></div>` },
      { t: 'بصمة الأسلوب', html: () => `<div class="sc-style">${viz.radar(A.dna, c)}<div class="style-tags">${['home', 'away'].map(s => `<div class="st-team" style="--tc:${c[s]}"><h4>${esc(s === 'home' ? H : Aw)}</h4>${A.styles[s].map(x => `<p><b>${esc(x.t)}</b><small>${esc(x.d)}</small></p>`).join('')}</div>`).join('')}</div></div>` },
      { t: 'نجم المباراة', html: () => star ? `<div class="sc-star"><div class="star-card" style="--tc:${c[star.side]}"><span class="num">${esc(star.jersey)}</span><b>${esc(star.name)}</b><small>${esc(AR(e[star.side].name))}</small><em class="rt huge count" data-to="${star.rating.toFixed(1)}" data-dec="1">0.0</em></div><div class="top3">${[['home', topH], ['away', topA]].map(([s, arr]) => `<div style="--tc:${c[s]}"><h4>${esc(s === 'home' ? H : Aw)}</h4>${arr.map(r => `<p><span>${esc(r.name)}</span><em class="rt">${r.rating.toFixed(1)}</em></p>`).join('')}</div>`).join('')}</div></div>` : '' },
      { t: 'نقاط التحوّل', html: () => `<div class="sc-tp"><ol class="tp">${A.tps.map((t, i) => `<li style="--tc:${c[t.side] || 'var(--accent)'};--d:${i * 0.25}s" class="${t.red ? 'red' : ''}">${esc(t.txt)}</li>`).join('') || '<li>لم تشهد المباراة أهدافاً — قصتها كانت في التفاصيل الدفاعية.</li>'}</ol></div>` },
    ];
    b.innerHTML = `<div class="story card">
      <div class="story-top"><div class="story-bars">${scenes.map((_, i) => `<span class="sb" data-i="${i}"><i></i></span>`).join('')}</div>
        <div class="story-meta"><img class="robo-ico" src="assets/robot-head.webp" alt=""><b>محلل روبو الذكي</b><small>تحليل آلي لحظي من بيانات المباراة</small></div></div>
      <h3 class="story-title" id="stT"></h3><div class="story-scene" id="stS"></div>
      <div class="story-nav"><button class="btn btn-ghost" data-st="prev">→ السابق</button><button class="btn btn-ghost" data-st="pause" aria-label="إيقاف مؤقت">إيقاف</button><button class="btn" data-st="next">التالي ←</button></div></div>
      <div class="card"><div class="card-h"><h3>التقرير الكامل</h3></div><div class="report">${A.story.map(s => `<p><b>${esc(s.title)}:</b> ${esc(s.text)}</p>`).join('')}</div></div>`;
    let paused = false; const DUR = 7000; let t0 = 0;
    const show = i => {
      S.storyIdx = (i + scenes.length) % scenes.length;
      $('#stT').textContent = scenes[S.storyIdx].t;
      const sc = $('#stS'); sc.classList.remove('in'); sc.innerHTML = scenes[S.storyIdx].html(); void sc.offsetWidth; sc.classList.add('in');
      countUps(sc);
      $$('.sb', b).forEach((x, k) => { x.classList.toggle('done', k < S.storyIdx); x.classList.toggle('cur', k === S.storyIdx); x.querySelector('i').style.width = k < S.storyIdx ? '100%' : '0%'; });
      t0 = Date.now();
    };
    clearInterval(S.storyTimer);
    S.storyTimer = setInterval(() => {
      if (paused || S.tab !== 'ai') return;
      const f = Math.min(1, (Date.now() - t0) / DUR); const cur = b.querySelector('.sb.cur i'); if (cur) cur.style.width = (f * 100) + '%';
      if (f >= 1) show(S.storyIdx + 1);
    }, 80);
    b.querySelector('.story-nav').onclick = ev => { const k = ev.target.closest('[data-st]'); if (!k) return; const a = k.dataset.st;
      if (a === 'next') show(S.storyIdx + 1); else if (a === 'prev') show(S.storyIdx - 1); else { paused = !paused; k.textContent = paused ? 'تشغيل' : 'إيقاف'; if (!paused) t0 = Date.now() - 0; } };
    b.querySelector('.story-bars').onclick = ev => { const k = ev.target.closest('[data-i]'); if (k) show(+k.dataset.i); };
    show(S.storyIdx || 0);
  }
  function countUps(root) {
    root.querySelectorAll('.count').forEach(el => {
      const to = parseFloat(el.dataset.to); const dec = el.dataset.dec ? +el.dataset.dec : (String(el.dataset.to).split('.')[1] || '').length; const t0 = performance.now();
      if (matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = to.toFixed(dec); return; }
      const step = t => { const f = Math.min(1, (t - t0) / 1400); const v = to * (1 - Math.pow(1 - f, 3)); el.textContent = v.toFixed(dec); if (f < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }

  /* ---- prediction ---- */
  async function buildPrediction(ev, sum) {
    let table = null; try { table = await api.standings(ev.league); } catch (e) {}
    let formH = ev.home.form, formA = ev.away.form;
    if (sum && sum.lastFiveGames) {
      const f = tid => { const t = sum.lastFiveGames.find(x => x.team && x.team.id === tid); return t ? (t.events || []).map(x => x.gameResult).filter(Boolean).reverse().join('') : ''; };
      formH = formH || f(ev.home.id); formA = formA || f(ev.away.id);
    }
    let odds = ev.odds && ev.odds.home != null ? ev.odds : null;
    if (!odds && sum && (sum.pickcenter || sum.odds)) {
      const o = (sum.pickcenter || sum.odds)[0];
      if (o && o.homeTeamOdds) odds = { home: o.homeTeamOdds.moneyLine, away: o.awayTeamOdds && o.awayTeamOdds.moneyLine, draw: o.drawOdds && o.drawOdds.moneyLine, ou: o.overUnder, provider: o.provider && o.provider.name };
    }
    const poly = ev.state === 'post' ? null : await api.polymarket(ev.home.name, ev.away.name, ev.date);
    return ai.predict({ home: ev.home.name, away: ev.away.name, homeId: ev.home.id, awayId: ev.away.id, table, formH, formA, odds, poly, leadersH: ev.home.leaders, leadersA: ev.away.leaders });
  }
  async function tabPredict(b) {
    const e = S.match.ev; const c = colors();
    b.innerHTML = `<div class="card"><div class="think"><img class="robo-ico spin-soft" src="assets/robot-head.webp" alt=""><p>روبو يجمع الترتيب، الفورمة، المراهنات، أسواق التوقعات وأداء اللاعبين…</p></div></div>`;
    const P = await buildPrediction(e, S.sum);
    if (S.tab !== 'predict') return;
    const pc = v => Math.round(v * 100);
    const pickTxt = P.pick === 'draw' ? 'تعادل' : `فوز ${P.pick === 'home' ? P.H : P.A}`;
    const actual = e.state === 'post' ? (e.home.score > e.away.score ? 'home' : e.away.score > e.home.score ? 'away' : 'draw') : null;
    const analysts = [];
    if (S.sum.article && S.sum.article.headline) analysts.push({ h: S.sum.article.headline, d: S.sum.article.description, u: S.sum.article.links && S.sum.article.links.web && S.sum.article.links.web.href, type: S.sum.article.type });
    ((S.sum.news && S.sum.news.articles) || []).slice(0, 3).forEach(a => analysts.push({ h: a.headline, d: a.description, u: a.links && a.links.web && a.links.web.href, type: a.type }));
    b.innerHTML = `
      <div class="pred-hero card">
        <div class="ph-left">
          <p class="eyebrow">توقّع روبو${e.state !== 'pre' ? ' (قبل المباراة)' : ''}</p>
          <div class="ph-score"><span style="--tc:${c.home}">${P.score.h}</span><i>-</i><span style="--tc:${c.away}">${P.score.a}</span></div>
          <p class="ph-pick">${esc(pickTxt)}</p>
          ${actual ? `<p class="ph-check ${actual === P.pick ? 'ok' : 'no'}">${actual === P.pick ? 'التوقع أصاب النتيجة ✓' : 'المباراة خالفت التوقع'} — النتيجة الفعلية ${e.home.score}-${e.away.score}</p>` : ''}
        </div>
        <div class="ph-gauges">${viz.gauge(P.confidence, 'الثقة')}${viz.gauge(pc(P.pOver), 'أكثر من 2.5', '#22c55e')}${viz.gauge(pc(P.pBtts), 'الفريقان يسجلان', '#f5b83d')}</div>
      </div>
      <div class="card"><div class="card-h"><h3>الاحتمالات النهائية</h3><span class="legend"><i style="background:${c.home}"></i>${esc(P.H)} <i style="background:var(--muted)"></i>تعادل <i style="background:${c.away}"></i>${esc(P.A)}</span></div>
        ${viz.probBar(P.fin, c, [P.H, 'تعادل', P.A])}
        <h4 class="sub-h">من أين جاء التوقع؟</h4>
        <div class="sources">${P.sources.map(s => `<div class="src"><div class="src-h"><b>${esc(s.ar)}</b><small>وزن ${Math.round(s.w / P.sources.reduce((a, x) => a + x.w, 0) * 100)}%${s.extra ? ' · ' + esc(s.extra) : ''}${s.url ? ` · <a href="${esc(s.url)}" target="_blank" rel="noopener">السوق</a>` : ''}</small></div>${viz.probBar(s, c, [P.H, 'تعادل', P.A])}</div>`).join('')}</div>
        ${!P.sources.some(s => s.k === 'poly') && e.state !== 'post' ? '<p class="hint">لا يوجد سوق Polymarket نشط لهذه المباراة حالياً.</p>' : ''}
      </div>
      <div class="grid2">
        <div class="card"><div class="card-h"><h3>لماذا هذا التوقع؟</h3></div><ul class="reasons">${P.reasons.map(r => `<li>${esc(r)}</li>`).join('') || '<li>بيانات الموسم محدودة؛ اعتمد التوقع على أفضلية الأرض والأسواق.</li>'}</ul>
          <h4 class="sub-h">أرجح النتائج</h4><div class="topscores">${P.topScores.map(s => `<span><b class="sc2"><span>${s.h}</span><i>-</i><span>${s.a}</span></b><small>${(s.p * 100).toFixed(1)}%</small></span>`).join('')}</div></div>
        <div class="card"><div class="card-h"><h3>قراءات المحللين</h3></div>${analysts.length ? `<ul class="news">${analysts.map(a => `<li><a href="${esc(a.u || '#')}" target="_blank" rel="noopener"><b>${esc(a.h)}</b><small>${esc(a.d || '')}</small><em>ESPN${a.type ? ' · ' + esc(a.type) : ''}</em></a></li>`).join('')}</ul>` : '<p class="muted pad">لا توجد تحليلات منشورة لهذه المباراة بعد.</p>'}</div>
      </div>
      <p class="disclaimer">التوقعات تقديرات إحصائية للترفيه والمعرفة، وليست نصيحة للمراهنة.</p>`;
  }

  function tabWatch(b) {
    const e = S.match.ev; const bc = (S.sum.broadcasts || []).map(x => x.media && (x.media.name || x.media.shortName)).filter(Boolean);
    b.innerHTML = `<div class="card watch">
      <div class="card-h"><h3>المشاهدة القانونية</h3></div>
      <p class="lede-s">«يمكن هدف؟» لا يعيد بث المباريات، لأن حقوق النقل محمية. نوجّهك إلى الناقل الرسمي في منطقتك، ونعطيك كل شيء آخر لحظة بلحظة: النتيجة، التعليق، الزخم، التشكيلة والتحليل.</p>
      <div class="bcast">${YH.BROADCAST_MENA.map(x => `<a class="bc" href="${x.url}" target="_blank" rel="noopener"><b>${esc(x.name)}</b><small>${esc(x.note)}</small><span>افتح الموقع الرسمي ←</span></a>`).join('')}</div>
      ${bc.length ? `<h4 class="sub-h">النقل التلفزيوني المسجّل لهذه المباراة (حسب البلد)</h4><div class="tags">${[...new Set(bc)].map(x => `<span class="tag">${esc(x)}</span>`).join('')}</div>` : ''}
    </div>`;
  }

  /* ======================= PREDICT HUB ======================= */
  async function renderPredict() {
    app.innerHTML = `<section class="page-h"><p class="eyebrow">محلل روبو الذكي</p><h1>توقعات الأيام القادمة</h1><p class="lede">نمزج الترتيب، الفورمة، الهدّافين، أسعار المراهنات وأسواق التوقعات العالمية لنقدّم احتمالاً واحداً واضحاً لكل مباراة كبيرة.</p></section><section id="plist" class="plist">${'<div class="skel skel-card"></div>'.repeat(6)}</section>`;
    if (!S.predictEvents) {
      const big = YH.LEAGUES.filter(l => l.tier <= 2).map(l => l.id);
      const days = await Promise.all([0, 1, 2, 3].map(o => api.allScoreboards(dateAt(o), big).catch(() => [])));
      S.predictEvents = [...new Map(days.flat().filter(e => e.state === 'pre').map(e => [e.id, e])).values()].sort((a, b) => a.tier - b.tier || new Date(a.date) - new Date(b.date)).slice(0, 18);
    }
    if (S.view !== 'predict') return;
    const el = $('#plist');
    if (!S.predictEvents.length) { el.innerHTML = `<div class="empty"><img class="robo-ico lg" src="assets/robot-head.webp" alt=""><p>لا مباريات كبرى مجدولة في الأيام الأربعة القادمة.</p></div>`; return; }
    el.innerHTML = S.predictEvents.map(e => `<button class="pcard" data-match="${e.league}:${e.id}" id="pc${e.id}"><span class="pc-lg">${esc(leagueAr(e.league))} · ${fmtDay(new Date(e.date))} ${fmtTime(e.date)}</span>
      <span class="pc-teams"><span>${logo(e.home.logo, e.home.name)}<b>${esc(AR(e.home.name))}</b></span><span class="pc-score skel-inline">…</span><span>${logo(e.away.logo, e.away.name)}<b>${esc(AR(e.away.name))}</b></span></span><span class="pc-bar"></span><span class="pc-why"></span></button>`).join('');
    for (const e of S.predictEvents) {
      if (S.view !== 'predict') return;
      try {
        const P = await buildPrediction(e, null);
        const card = $('#pc' + e.id); if (!card) continue;
        const c = viz.teamColors(e.home, e.away);
        card.querySelector('.pc-score').outerHTML = `<span class="pc-score"><b class="sc2"><span>${P.score.h}</span><i>-</i><span>${P.score.a}</span></b><small>ثقة ${P.confidence}%</small></span>`;
        card.querySelector('.pc-bar').innerHTML = viz.probBar(P.fin, c, [P.H, 'تعادل', P.A]);
        card.querySelector('.pc-why').textContent = P.sources.map(s => s.ar.split(' (')[0]).join(' · ');
      } catch (err) {}
    }
  }

  /* ======================= TABLE ======================= */
  async function renderTable() {
    app.innerHTML = `<section class="page-h"><p class="eyebrow">جدول الترتيب</p><h1>منو فوق ومنو جوّه؟</h1></section>
      <div class="chips">${YH.TABLE_LEAGUES.map(id => `<button class="chip ${S.tableLeague === id ? 'on' : ''}" data-tl="${id}">${YH.LEAGUE_BY_ID[id].short}</button>`).join('')}</div>
      <section class="card" id="tbl"><div class="skel" style="height:520px"></div></section>`;
    app.querySelector('.chips').onclick = e => { const b = e.target.closest('[data-tl]'); if (!b) return; S.tableLeague = b.dataset.tl; renderTable(); };
    try {
      const t = await api.standings(S.tableLeague);
      if (S.view !== 'table') return;
      $('#tbl').innerHTML = `<div class="card-h"><h3>${esc(leagueAr(S.tableLeague))}</h3><span class="muted">يتحدث تلقائياً</span></div><div class="tscroll"><table class="table"><thead><tr><th>#</th><th class="tl">الفريق</th><th>لعب</th><th>ف</th><th>ت</th><th>خ</th><th>له</th><th>عليه</th><th>±</th><th>نقاط</th></tr></thead><tbody>
        ${t.map(r => `<tr style="${r.noteColor ? `--nc:${r.noteColor}` : ''}" class="${r.noteColor ? 'noted' : ''}" title="${esc(r.note || '')}"><td class="rk">${r.rank}</td><td class="tl">${logo(r.logo, r.name)}<b>${esc(AR(r.name))}</b></td><td>${r.gp}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gd > 0 ? '+' : ''}${r.gd}</td><td class="pts">${r.pts}</td></tr>`).join('')}</tbody></table></div>
        <div class="notes">${[...new Map(t.filter(r => r.note).map(r => [r.note, r.noteColor])).entries()].map(([n, cl]) => `<span><i style="background:${cl}"></i>${esc(n)}</span>`).join('')}</div>`;
    } catch (e) { $('#tbl').innerHTML = `<div class="empty"><p>تعذّر تحميل الترتيب. حاول لاحقاً.</p></div>`; }
  }

  /* ======================= ABOUT ======================= */
  function renderAbout() {
    app.innerHTML = `<section class="page-h about-h"><img class="about-robo" src="assets/robot.webp" alt="روبو"><div><p class="eyebrow">عن التطبيق</p><h1>يمكن هدف؟</h1><p class="lede">تطبيق كرة قدم ذكي: نتائج مباشرة، أهداف بالتعليق العربي، تشكيلات بالصور، ومحلل آلي اسمه روبو يشرح كل مباراة قبلها وبعدها.</p></div></section>
      <section class="features">
        ${[['روبو يشرح', 'قبل كل مباراة يحرّك اللاعبين على لوحة تكتيكية بيده، ويشرح شلون راح يلعب كل فريق، منو أقرب للفوز وليش.'],
          ['ثلاثة سيرفرات', 'S1 وS2 وS3 تتبدّل تلقائياً عند أي عطل، والنتائج تتحدّث كل 15 ثانية أثناء المباريات المباشرة.'],
          ['الأهداف بالتعليق العربي', 'ملخص الأهداف فقط وبصوت المعلقين العرب، ومع كل هدف مباشر نراقب وننبهك أول ما ينزل المقطع.'],
          ['تشكيلات بالصور', 'صور اللاعبين والمدربين، خطة اللعب، التبديلات وتقييم كل لاعب.'],
          ['تحليل ذكي', 'الأهداف المتوقعة xG، موجة الزخم، خريطة الفرص، بصمة الأسلوب ونقاط التحوّل، يشرحها روبو بالصوت.'],
          ['توقعات قوية', 'نمزج الترتيب والفورمة والهدّافين وآخر مباراة وأسعار المراهنات وسوق Polymarket، مع احتمال مباشر يتغيّر أثناء اللعب.']].map(([t, d], i) => `<article class="feat" style="--d:${i * 0.06}s"><span class="feat-n">${String(i + 1).padStart(2, '0')}</span><h3>${t}</h3><p>${d}</p></article>`).join('')}
      </section>
      <section class="card"><div class="card-h"><h3>مصادر البيانات</h3></div><p class="muted pad">النتائج والتشكيلات والإحصائيات: ESPN. صور اللاعبين والمدربين والأسماء العربية: ويكي داتا. مقاطع الأهداف: قنوات يوتيوب عامة. أسواق التوقعات: Polymarket. البث المباشر للمباريات عبر الناقلين الرسميين فقط احتراماً لحقوق النقل.</p></section>`;
  }

  /* boot */
  YH.robot.splash(() => { const v = $('#voiceBtn'); if (v) v.setAttribute('aria-pressed', YH.robot.voice.enabled); });
  const vb = $('#voiceBtn'); if (vb) vb.onclick = () => { const V = YH.robot.voice; V.enabled = !V.enabled; if (V.enabled) { V.pick(); V.speak('الصوت شغّال'); } else V.cancel(); vb.setAttribute('aria-pressed', V.enabled); toast(V.enabled ? 'صوت روبو والمعلق: شغّال' : 'الصوت: مطفي'); };
  document.addEventListener('yh-voice', () => { if (vb) vb.setAttribute('aria-pressed', YH.robot.voice.enabled); });
  render();
  setCountdown();
})();
