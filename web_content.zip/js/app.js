(function(){
'use strict';
var $=function(i){return document.getElementById(i)},Q=function(s){return document.querySelector(s)},QA=function(s){return [].slice.call(document.querySelectorAll(s))};
var KEY='first-letters:v3',persist=true;
var S={items:[],d:'',t:'',g:'',h:{},cur:null,st:'new',col:{},scope:'all',sn:0,rz:1,p:true,b:true,c:false,r:false,mode:'letters',lvl:50,size:1,theme:'auto'};
var cur=null,st='new',H={},cells=[],last='',lastOrig='',all=false,timer,armNew,armReset;
var src=$('src'),ttl=$('ttl'),cat=$('cat'),out=$('out'),ttlOut=$('ttlOut'),topicOut=$('topicOut'),hint=$('hint'),legend=$('legend'),toast=$('toast');
var save=$('save'),cancel=$('cancel'),peek=$('peek'),reset=$('reset'),newBtn=$('newBtn'),lockNote=$('lockNote'),sheet=Q('.sheet');
var oP=$('oP'),oB=$('oB'),oC=$('oC'),oR=$('oR'),list=$('list'),note=$('note'),q=$('q');
var seq=$('seq'),seqLbl=$('seqLbl'),prev=$('prev'),next=$('next');

function lv(c){return c>=5?3:c>=3?2:c>=1?1:0;}
var ABBR=' mr mrs ms dr prof st vs rev jr sr fr e.g i.e ';
function ends(tail,core){return /[.!?\u2026]/.test(tail)&&!/^\d{1,3}$/.test(core)&&!/^\p{Lu}$/u.test(core)&&ABBR.indexOf(' '+core.toLowerCase()+' ')<0;}
function segment(text,br){
  var re=/[^\s\u2013\u2014]+|[\u2013\u2014]/g,m,out=[],prev=0,cnt=0,cs=null,last=0;
  while((m=re.exec(text))){
    if(br&&cnt>0&&text.slice(prev,m.index).indexOf('\n')>-1){out.push({a:cs,b:last});cs=null;cnt=0;}
    prev=m.index+m[0].length;
    var mm=m[0].match(/^([^\p{L}\p{N}]*)([\p{L}\p{N}])([\s\S]*)$/u);
    if(!mm)continue;
    if(cs===null)cs=m.index;
    last=prev;cnt++;
    var tail=mm[3].match(/[^\p{L}\p{N}]*$/u)[0],core=mm[2]+mm[3].slice(0,mm[3].length-tail.length);
    if(ends(tail,core)){out.push({a:cs,b:last});cs=null;cnt=0;}
  }
  if(cnt>0)out.push({a:cs,b:last});
  return out;
}
function build(el,r,cs){
  el.textContent='';
  r.lines.forEach(function(l,li){
    if(li)el.appendChild(document.createElement('br'));
    l.forEach(function(t,i){
      if(i)el.appendChild(document.createTextNode(' '));
      var e=document.createElement('span');e.textContent=t.s;
      if(t.w){
        e.className='w';e.tabIndex=0;e.setAttribute('role','button');e.setAttribute('aria-pressed','false');
        var d=lv(H[t.k]||0);if(d)e.dataset.h=d;
        e.dataset.k=cs.length;cs.push({t:t,e:e});
      }
      el.appendChild(e);
    });
  });
}
function convert(text,o){
  var words=[],seen={},H0=o.H||{},si=0,cnt=0;
  text=text.normalize('NFC');
  var lines=(o.br?text.split(/\r?\n/):[text]).map(function(line){
    var a=[];
    line.replace(/[\u2013\u2014]/g,' $& ').split(/\s+/).filter(Boolean).forEach(function(tok){
      var m=tok.match(/^([^\p{L}\p{N}]*)([\p{L}\p{N}])([\s\S]*)$/u);
      if(!m){if(o.kp)a.push({o:tok,s:tok,w:false,n:si});return;}
      var tail=m[3].match(/[^\p{L}\p{N}]*$/u)[0],core=m[2]+m[3].slice(0,m[3].length-tail.length);
      var lead=o.kp?m[1]:'',end=o.kp?tail:'',key=core.toLowerCase()+'#';
      seen[key]=(seen[key]||0)+1;
      var t={o:tok,w:true,n:si,k:key+seen[key],s:lead+(o.caps?m[2].toUpperCase():m[2])+end,b:lead+'_'.repeat(Math.max(2,core.length))+end};
      a.push(t);words.push(t);cnt++;
      if(ends(tail,core)){si++;cnt=0;}
    });
    if(o.br&&cnt>0){si++;cnt=0;}
    return a;
  });
  var total=words.length?words[words.length-1].n+1:0,sn=total?Math.min(Math.max(o.sn||0,0),total-1):0;
  var lo=0,hi=1e9;
  if(o.scope==='one')lo=hi=sn;else if(o.scope==='build')hi=sn;
  var vis=function(t){return t.n>=lo&&t.n<=hi;},vw=words.filter(vis);
  if(o.scope==='one'||o.scope==='build')lines=lines.map(function(l){return l.filter(vis);}).filter(function(l){return l.length;});
  if(o.mode==='blanks'){
    var pick={};
    if(o.lvl==='hard'){vw.forEach(function(t,i){if(H0[t.k]>0)pick[i]=1;});}
    else{
      var idx=vw.map(function(_,i){return i}),n=Math.round(vw.length*o.lvl/100);
      for(var i=idx.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),x=idx[i];idx[i]=idx[j];idx[j]=x;}
      idx.slice(0,n).forEach(function(k){pick[k]=1;});
    }
    vw.forEach(function(t,i){if(pick[i])t.s=t.b;else{t.s=t.o;t.w=false;}});
  }
  var join=function(f){return lines.map(function(l){return l.map(f).join(' ')}).join(o.br?'\n':' ').trim();};
  return{lines:lines,words:vw.length,total:total,sn:sn,text:join(function(x){return x.s;}),orig:join(function(x){return x.o;})};
}
function opts(){return{kp:oP.checked,caps:oC.checked,br:oB.checked,mode:S.mode,lvl:S.lvl,H:H,scope:S.scope,sn:S.sn};}

function load(){
  try{var d=JSON.parse(localStorage.getItem(KEY)||'null');if(d&&Array.isArray(d.items))S=Object.assign(S,d);}catch(e){persist=false;}
}
function store(){try{localStorage.setItem(KEY,JSON.stringify(S));}catch(e){persist=false;}}
function find(id){return S.items.filter(function(x){return x.id===id})[0];}
function say(s){toast.textContent=s;clearTimeout(timer);if(s)timer=setTimeout(function(){toast.textContent='';},2600);}
function title(t){var w=t.split(/\s+/);return w.slice(0,5).join(' ')+(w.length>5?'…':'');}
function isAuto(it){return it.auto!==undefined?it.auto:it.title===title(it.text);}
function plural(n,w){return n+' '+w+(n===1?'':'s');}
function setNav(){$('tabLib').textContent='Library ('+S.items.length+')';}
function setH(){var it=cur&&find(cur);H=it?(it.h=it.h||{}):(S.h=S.h||{});}
function look(){
  var r=document.documentElement;r.style.setProperty('--zoom',S.size);
  if(S.theme==='auto')r.removeAttribute('data-theme');else r.setAttribute('data-theme',S.theme);
}
function topics(){
  var m=new Map();
  S.items.slice().sort(function(a,b){return (a.t||0)-(b.t||0);}).forEach(function(x){if(x.cat&&!m.has(x.cat.toLowerCase()))m.set(x.cat.toLowerCase(),x.cat);});
  return Array.from(m.values()).sort(function(a,b){return a.localeCompare(b);});
}
function refreshCats(){
  var dl=$('cats');dl.textContent='';
  topics().forEach(function(t){var o=document.createElement('option');o.value=t;dl.appendChild(o);});
}

function setState(s){
  st=s;S.st=s;S.cur=cur;
  var ro=s==='view';
  src.readOnly=ttl.readOnly=cat.readOnly=ro;
  lockNote.hidden=!ro;cancel.hidden=s!=='edit';
  save.textContent=s==='view'?'Edit':s==='edit'?'Save changes':'Save text';
  store();
}
function sync(){
  S.d=src.value;S.t=ttl.value.trim();S.g=cat.value.trim();
  S.p=oP.checked;S.b=oB.checked;S.c=oC.checked;S.r=oR.checked;
  S.mode=$('mB').checked?'blanks':'letters';
  S.scope=$('sO').checked?'one':$('sB').checked?'build':'all';
  var l=Q('input[name=lvl]:checked');S.lvl=l?(l.value==='hard'?'hard':+l.value):50;
  store();draw();
}
function fill(it){src.value=it.text;ttl.value=isAuto(it)?'':it.title;cat.value=it.cat||'';sync();}

function show(c,on){
  c.t.r=on;c.e.textContent=on?c.t.o:c.t.s;
  c.e.classList.toggle('on',on);c.e.setAttribute('aria-pressed',String(on));
}
function draw(){
  var r=convert(src.value,opts()),blanks=S.mode==='blanks',hk=Object.keys(H).length;
  if(S.sn!==r.sn){S.sn=r.sn;store();}
  var multi=S.scope!=='all';seq.hidden=!multi;$('focusBtn').hidden=!(multi&&r.total>0);
  if(multi){
    seqLbl.textContent=r.total?(S.scope==='build'&&r.sn>0?'Sentences 1–'+(r.sn+1):'Sentence '+(r.sn+1))+' of '+r.total:'No sentences yet';
    prev.disabled=r.sn<=0;next.disabled=r.sn>=r.total-1;
  }
  ttlOut.textContent=ttl.value.trim();ttlOut.hidden=!ttlOut.textContent;
  topicOut.textContent=cat.value.trim();topicOut.hidden=!topicOut.textContent;
  sheet.classList.toggle('ruled',!!S.r);
  last=r.text;lastOrig=r.orig;cells=[];all=false;
  peek.textContent='Reveal all';peek.setAttribute('aria-pressed','false');
  $('lvlRow').hidden=!blanks;$('shuffle').hidden=!blanks;
  legend.hidden=reset.hidden=!hk;
  out.textContent='';
  if(!r.words){
    out.className='empty';out.textContent='Paste text above to see its '+(blanks?'blanks.':'first letters.');hint.textContent='';return;
  }
  out.className='';
  build(out,r,cells);
  hint.textContent=cells.length||!blanks
    ?plural(r.words,'word')+'. Tap '+(blanks?'a blank':'a letter')+' to reveal its word.'
    :'Nothing is hidden yet.'+(S.lvl==='hard'?' Reveal words in First letters mode to mark them as hard.':'');
}
function tog(e,cs){
  var c=cs[+e.dataset.k];if(!c)return;
  if(!c.t.r){
    H[c.t.k]=(H[c.t.k]||0)+1;store();
    var d=lv(H[c.t.k]);if(d)e.dataset.h=d;
    legend.hidden=reset.hidden=false;
  }
  show(c,!c.t.r);
}
out.addEventListener('click',function(e){var s=e.target.closest('.w');if(s)tog(s,cells);});
out.addEventListener('keydown',function(e){
  if((e.key==='Enter'||e.key===' ')&&e.target.classList&&e.target.classList.contains('w')){e.preventDefault();tog(e.target,cells);}
});
peek.addEventListener('click',function(){
  all=!all;cells.forEach(function(c){show(c,all);});
  peek.textContent=all?'Hide all':'Reveal all';peek.setAttribute('aria-pressed',String(all));
});
$('shuffle').addEventListener('click',draw);
prev.addEventListener('click',function(){S.sn=Math.max(0,S.sn-1);store();draw();});
next.addEventListener('click',function(){S.sn+=1;store();draw();});
reset.addEventListener('click',function(){
  if(!armReset){armReset=1;reset.textContent='Tap again to reset';setTimeout(function(){armReset=0;reset.textContent='Reset colours';},3000);return;}
  armReset=0;reset.textContent='Reset colours';
  Object.keys(H).forEach(function(k){delete H[k];});store();draw();say('Colours reset.');
});

[src,ttl,cat,oP,oB,oC,oR,$('mL'),$('mB')].concat(QA('input[name=lvl]'),QA('input[name=scope]')).forEach(function(el){
  el.addEventListener('input',sync);el.addEventListener('change',sync);
});

newBtn.addEventListener('click',function(){
  var dirty=st!=='view'&&(src.value.trim()||ttl.value.trim());
  if(dirty&&!armNew){armNew=1;newBtn.textContent='Discard and start new?';setTimeout(function(){armNew=0;newBtn.textContent='+ New text';},3000);return;}
  armNew=0;newBtn.textContent='+ New text';
  cur=null;S.h={};S.sn=0;src.value=ttl.value=cat.value='';
  setH();setState('new');sync();src.focus();
});

save.addEventListener('click',function(){
  if(st==='view'){setState('edit');say('You can edit now.');src.focus();return;}
  var t=src.value.trim(),tt=ttl.value.trim(),g=cat.value.trim();
  if(!t){say('Type or paste some text first.');return;}
  topics().forEach(function(x){if(x.toLowerCase()===g.toLowerCase())g=x;});
  var it=cur&&find(cur),msg;
  if(it){
    it.text=t;it.title=tt||title(t);it.auto=!tt;it.cat=g;msg='Changes saved.';
  }else{
    if(S.items.some(function(x){return x.text===t;})){say('This text is already saved. Open it from the Library.');return;}
    it={id:Date.now().toString(36),title:tt||title(t),auto:!tt,text:t,cat:g,star:false,t:Date.now(),h:S.h||{}};
    S.items.unshift(it);S.h={};msg='Saved.';
  }
  cur=it.id;setH();fill(it);setState('view');setNav();refreshCats();
  say(persist?msg:'Saved for this session only.');
});
cancel.addEventListener('click',function(){fill(find(cur));setState('view');say('Changes discarded.');});

function fallback(t){
  try{
    var ta=document.createElement('textarea');ta.value=t;ta.setAttribute('readonly','');
    ta.style.cssText='position:fixed;top:0;left:0;opacity:0';
    document.body.appendChild(ta);ta.select();ta.setSelectionRange(0,t.length);
    var ok=document.execCommand('copy');document.body.removeChild(ta);return ok;
  }catch(e){return false;}
}
function copy(t,msg){
  var p=(navigator.clipboard&&navigator.clipboard.writeText)
    ?navigator.clipboard.writeText(t).then(function(){return true;},function(){return fallback(t);})
    :Promise.resolve(fallback(t));
  p.then(function(ok){say(ok?msg:'Couldn’t copy automatically. Press and hold the text to select it.');});
}
$('copy').addEventListener('click',function(){if(!last){say('Nothing to copy yet.');return;}copy(last,'Copied.');});
$('speak').addEventListener('click',function(){
  var ss=window.speechSynthesis;
  if(!ss||!window.SpeechSynthesisUtterance){say('Listening isn’t supported here.');return;}
  if(ss.speaking){ss.cancel();return;}
  var whole=S.scope==='all',t=whole?src.value.trim():lastOrig;if(!t){say('Type or paste some text first.');return;}
  ss.speak(new SpeechSynthesisUtterance((whole&&ttl.value.trim()?ttl.value.trim()+'. ':'')+t));
});

function drawList(){
  var k=q.value.trim().toLowerCase(),gm=new Map();
  S.items.slice().sort(function(a,b){return (a.t||0)-(b.t||0);}).filter(function(x){return !k||(x.title+' '+(x.cat||'')+' '+x.text).toLowerCase().indexOf(k)>-1;}).forEach(function(it){
    var key=(it.cat||'').toLowerCase();
    if(!gm.has(key))gm.set(key,{name:it.cat||'No topic',items:[]});
    gm.get(key).items.push(it);
  });
  var groups=Array.from(gm.values()).sort(function(a,b){
    return (a.name==='No topic')-(b.name==='No topic')||a.name.localeCompare(b.name);
  });
  list.textContent='';
  note.textContent=!persist?'Saving isn’t available here, so texts last only until you close the app.'
    :(S.items.length?(groups.length?'':'No texts match your search.'):'Nothing saved yet. Paste a text on the Practise page, then tap Save text.');
  groups.forEach(function(g){
    var dt=document.createElement('details'),sm=document.createElement('summary'),sc=document.createElement('span'),ul=document.createElement('ul');
    dt.className='grp';sm.textContent=g.name;sc.textContent='('+g.items.length+')';sm.appendChild(sc);dt.appendChild(sm);
    g.items.sort(function(a,b){return (b.star?1:0)-(a.star?1:0)||(b.t||0)-(a.t||0);}).forEach(function(it){
      var li=document.createElement('li'),b=document.createElement('button'),s=document.createElement('strong'),m=document.createElement('span'),
          sb=document.createElement('button'),d=document.createElement('button');
      var n=convert(it.text,{kp:true,br:true,mode:'letters'}).words,hd=Object.keys(it.h||{}).filter(function(x){return it.h[x]>0;}).length;
      b.type=sb.type=d.type='button';b.className='item';sb.className='star';d.className='del';
      b.dataset.id=sb.dataset.id=d.dataset.id=it.id;
      s.textContent=it.title;m.textContent=plural(n,'word')+(hd?', '+hd+' hard':'');
      b.appendChild(s);b.appendChild(m);
      sb.textContent=it.star?'★':'☆';sb.setAttribute('aria-label',it.star?'Remove from favourites':'Add to favourites');
      d.textContent='Delete';
      li.appendChild(b);li.appendChild(sb);li.appendChild(d);ul.appendChild(li);
    });
    dt.appendChild(ul);
    dt.open=!!k||!S.col[g.name];
    dt.addEventListener('toggle',function(){
      if(q.value.trim()||!!S.col[g.name]===!dt.open)return;
      S.col[g.name]=!dt.open;store();
    });
    list.appendChild(dt);
  });
}
q.addEventListener('input',drawList);
list.addEventListener('click',function(e){
  var b=e.target.closest('button');if(!b)return;var id=b.dataset.id,it=find(id);
  if(b.classList.contains('item')){
    if(!it)return;cur=id;S.sn=0;setH();fill(it);setState('view');go('practise');say('Opened.');
  }else if(b.classList.contains('star')){
    if(it){it.star=!it.star;store();drawList();}
  }else if(b.dataset.arm){
    S.items=S.items.filter(function(x){return x.id!==id;});
    if(cur===id){cur=null;S.h={};setH();setState('new');sync();}
    store();setNav();refreshCats();drawList();
  }else{
    b.dataset.arm='1';b.textContent='Tap again';
    setTimeout(function(){delete b.dataset.arm;b.textContent='Delete';},3000);
  }
});

$('bkCopy').addEventListener('click',function(){copy(JSON.stringify({app:'first-letters',items:S.items}),'Backup copied.');});
$('bkRestore').addEventListener('click',function(){
  try{
    var d=JSON.parse($('bk').value),n=0;if(!d||!Array.isArray(d.items))throw 0;
    d.items.forEach(function(x){
      if(x&&typeof x.text==='string'&&!S.items.some(function(y){return y.text===x.text;})){
        S.items.push({id:(x.id||Date.now().toString(36))+n,title:x.title||title(x.text),auto:x.title?!!x.auto:true,text:x.text,
          cat:typeof x.cat==='string'?x.cat:'',star:!!x.star,t:x.t||Date.now(),h:x.h&&typeof x.h==='object'?x.h:{}});n++;
      }
    });
    store();setNav();refreshCats();$('bk').value='';say(plural(n,'text')+' restored.');
  }catch(e){say('That doesn’t look like a backup.');}
});
QA('input[name=theme]').forEach(function(r){r.addEventListener('change',function(){S.theme=r.value;store();look();});});
$('sz').addEventListener('input',function(){S.size=+this.value;store();look();});

function go(t){
  ['practise','library','settings'].forEach(function(n){$('v-'+n).hidden=n!==t;});
  QA('.tabs button').forEach(function(b){b.setAttribute('aria-current',b.dataset.tab===t?'page':'false');});
  if(t==='library')drawList();
  window.scrollTo(0,0);
}
QA('.tabs button').forEach(function(b){b.addEventListener('click',function(){go(b.dataset.tab);});});

var fc={k:0,show:true,mode:'letters',all:false},fcCells=[],segs=[],sel=-1,pushed=0;
function ovOpen(el){el.hidden=false;document.documentElement.style.overflow='hidden';try{history.pushState({ov:1},'');pushed++;}catch(e){}}
function ovClose(){
  var f=$('focus'),r=$('reader');
  if(!f.hidden){f.hidden=true;draw();}else if(!r.hidden){r.hidden=true;}
  if(f.hidden&&r.hidden)document.documentElement.style.overflow='';
}
function ovBack(){if(pushed>0)history.back();else ovClose();}
window.addEventListener('popstate',function(){if(pushed>0)pushed--;ovClose();});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&(!$('focus').hidden||!$('reader').hidden))ovBack();});

function readerOpen(){
  var T=src.value.normalize('NFC');
  if(!T.trim()){say('Type or paste some text first.');return;}
  segs=segment(T,oB.checked);sel=-1;
  var box=$('rdText'),at=0;box.textContent='';
  segs.forEach(function(s,i){
    if(s.a>at)box.appendChild(document.createTextNode(T.slice(at,s.a)));
    var e=document.createElement('span');e.className='sen';e.dataset.i=i;e.textContent=T.slice(s.a,s.b);box.appendChild(e);at=s.b;
  });
  if(at<T.length)box.appendChild(document.createTextNode(T.slice(at)));
  $('rdTitle').textContent=ttl.value.trim()||'Reading';
  box.style.fontSize=(1.35*S.rz)+'rem';$('rdFoot').hidden=true;
  ovOpen($('reader'));$('reader').querySelector('.ovbody').scrollTop=0;
}
function zoomRd(d){S.rz=Math.min(2.1,Math.max(.85,Math.round((S.rz+d)*100)/100));$('rdText').style.fontSize=(1.35*S.rz)+'rem';store();}
$('readBtn').addEventListener('click',readerOpen);
src.addEventListener('click',function(){if(st==='view')readerOpen();});
$('rdClose').addEventListener('click',ovBack);$('fcClose').addEventListener('click',ovBack);
$('rdSmall').addEventListener('click',function(){zoomRd(-.15);});
$('rdBig').addEventListener('click',function(){zoomRd(.15);});
$('rdText').addEventListener('click',function(e){
  var s=e.target.closest('.sen');if(!s)return;
  QA('#rdText .sen.sel').forEach(function(x){x.classList.remove('sel');});
  s.classList.add('sel');sel=+s.dataset.i;
  $('rdSel').textContent='Sentence '+(sel+1)+' of '+segs.length;$('rdFoot').hidden=false;
});

function focusDraw(){
  var o=opts();o.scope='one';o.sn=fc.k;o.br=oB.checked;o.mode=fc.mode;o.lvl=50;
  var r=convert(src.value,o);fc.k=r.sn;fc.all=false;
  fcCells=[];build($('fcOut'),r,fcCells);
  $('fcSheet').classList.toggle('ruled',!!S.r);
  $('fcOrig').textContent=r.orig;$('fcOrig').hidden=!fc.show;
  $('fcOrigBtn').textContent=fc.show?'Hide text':'Show text';
  $('fcMode').textContent=fc.mode==='blanks'?'Show letters':'Show blanks';
  $('fcPeek').textContent='Reveal all';
  $('fcLbl').textContent='Sentence '+(r.sn+1)+' of '+r.total;
  $('fcPrev').disabled=r.sn<=0;$('fcNext').disabled=r.sn>=r.total-1;
}
function openFocus(){focusDraw();ovOpen($('focus'));$('focus').querySelector('.ovbody').scrollTop=0;}
$('focusBtn').addEventListener('click',function(){fc.k=S.sn;fc.show=true;fc.mode='letters';openFocus();});
$('rdGo').addEventListener('click',function(){if(sel<0)return;fc.k=sel;fc.show=true;fc.mode='letters';openFocus();});
$('fcPrev').addEventListener('click',function(){fc.k=Math.max(0,fc.k-1);focusDraw();});
$('fcNext').addEventListener('click',function(){fc.k+=1;focusDraw();});
$('fcOrigBtn').addEventListener('click',function(){fc.show=!fc.show;focusDraw();});
$('fcMode').addEventListener('click',function(){fc.mode=fc.mode==='blanks'?'letters':'blanks';focusDraw();});
$('fcPeek').addEventListener('click',function(){
  fc.all=!fc.all;fcCells.forEach(function(c){show(c,fc.all);});$('fcPeek').textContent=fc.all?'Hide all':'Reveal all';
});
$('fcOut').addEventListener('click',function(e){var s=e.target.closest('.w');if(s)tog(s,fcCells);});
$('fcOut').addEventListener('keydown',function(e){
  if((e.key==='Enter'||e.key===' ')&&e.target.classList&&e.target.classList.contains('w')){e.preventDefault();tog(e.target,fcCells);}
});

load();
cur=S.cur&&find(S.cur)?S.cur:null;
var st0=cur?(S.st==='edit'?'edit':'view'):'new';
setH();
if(cur&&st0==='view'){var it0=find(cur);src.value=it0.text;ttl.value=isAuto(it0)?'':it0.title;cat.value=it0.cat||'';}
else{src.value=S.d||'';ttl.value=S.t||'';cat.value=S.g||'';}
oP.checked=!!S.p;oB.checked=!!S.b;oC.checked=!!S.c;oR.checked=!!S.r;
$(S.mode==='blanks'?'mB':'mL').checked=true;
$(S.scope==='one'?'sO':S.scope==='build'?'sB':'sA').checked=true;
var lv0=Q('input[name=lvl][value="'+S.lvl+'"]');if(lv0)lv0.checked=true;
var th=Q('input[name=theme][value="'+S.theme+'"]');if(th)th.checked=true;
$('sz').value=S.size;
look();refreshCats();setState(st0);sync();setNav();
if('serviceWorker' in navigator&&/^https?:/.test(location.protocol)){navigator.serviceWorker.register('sw.js').catch(function(){});}
})();
