/**
 * EthioEvents Pro - Home File Hub Controller
 */
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await dbEngine.init();
        await loadStoredFiles();
    } catch (e) {
        console.error("DB Init error", e);
    }

    // Navigation Logic
    const navButtons = document.querySelectorAll('.nav-btn');
    const views = document.querySelectorAll('.content-view');
    const pageTitle = document.getElementById('page-title');

    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            const target = button.getAttribute('data-target');
            navButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            views.forEach(view => {
                if (view.id === `${target}-view`) view.classList.add('active');
                else view.classList.remove('active');
            });
            if (pageTitle) pageTitle.innerText = button.innerText.trim();
            const sidebar = document.getElementById('sidebar');
            if (sidebar) sidebar.classList.remove('open');
        });
    });

    const mobileToggle = document.getElementById('mobile-menu-toggle');
    const sidebar = document.getElementById('sidebar');
    if (mobileToggle && sidebar) {
        mobileToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
    }

    const themeBtn = document.getElementById('theme-toggle-btn');
    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            const current = document.documentElement.getAttribute('data-theme');
            const next = current === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            themeBtn.innerHTML = next === 'dark' ? '<i class="fa-solid fa-moon"></i> Light Mode' : '<i class="fa-solid fa-sun"></i> Dark Mode';
        });
    }

    // --- FILE UPLOAD & DOWNLOAD CONTROLLER ---
    const fileUploader = document.getElementById('file-uploader');
    const uploadStatus = document.getElementById('upload-status');
    const downloadBtn = document.getElementById('file-downloader-btn');
    const downloadStatus = document.getElementById('download-status');

    if (fileUploader) {
        fileUploader.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            uploadStatus.innerText = `Uploading ${file.name}...`;
            
            const reader = new FileReader();
            reader.onload = async function(event) {
                try {
                    const fileRecord = {
                        name: file.name,
                        type: file.type || 'application/json',
                        size: file.size,
                        date: new Date().toLocaleDateString(),
                        content: event.target.result
                    };
                    await dbEngine.add('files', fileRecord);
                    uploadStatus.innerText = `Successfully uploaded: ${file.name}!`;
                    await loadStoredFiles();
                } catch (err) {
                    uploadStatus.innerText = "Error saving file to local database.";
                }
            };
            reader.readAsText(file);
        });
    }

    async function loadStoredFiles() {
        const tbody = document.getElementById('stored-files-tbody');
        if (!tbody) return;

        try {
            const files = await dbEngine.getAll('files');
            if (files.length === 0) {
                tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-secondary);">No custom files uploaded yet. Use the upload button above.</td></tr>`;
                return;
            }

            tbody.innerHTML = files.map(f => `
                <tr>
                    <td><strong>${f.name}</strong></td>
                    <td>${f.type}</td>
                    <td>${f.date}</td>
                    <td><button class="btn btn-secondary" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;" onclick="downloadStoredFile(${f.id})"><i class="fa-solid fa-download"></i> Save</button></td>
                </tr>
            `).join('');
        } catch (e) {
            console.error("Error loading files", e);
        }
    }

    if (downloadBtn) {
        downloadBtn.addEventListener('click', async () => {
            downloadStatus.innerText = "Generating system backup...";
            try {
                const events = await dbEngine.getAll('events');
                const guests = await dbEngine.getAll('guests');
                const backupData = {
                    appName: "EthioEvents Pro",
                    exportDate: new Date().toISOString(),
                    events: events,
                    guests: guests
                };

                const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
                const downloadAnchor = document.createElement('a');
                downloadAnchor.setAttribute("href", dataStr);
                downloadAnchor.setAttribute("download", `EthioEvents_Backup_${new Date().toISOString().slice(0,10)}.json`);
                document.body.appendChild(downloadAnchor);
                downloadAnchor.click();
                downloadAnchor.remove();

                downloadStatus.innerText = "Backup downloaded successfully!";
            } catch (err) {
                downloadStatus.innerText = "Error generating backup file.";
            }
        });
    }

    window.downloadStoredFile = async (id) => {
        const files = await dbEngine.getAll('files');
        const file = files.find(f => f.id === id);
        if (!file) return;

        const blob = new Blob([file.content], { type: file.type });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        a.remove();
    };
});