(function () {
  'use strict';

  /* ---------- สถานะ ---------- */
  var S = { users: [], posts: [], session: null, gaccounts: [], searches: {}, views: {} };
  var KEYS = Object.keys(S);
  var root = document.getElementById('root');
  var tab = 'home';
  var query = '';
  var draft = { img: '', cap: '' };

  /* ---------- ตัวช่วย ---------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function norm(s) { return String(s).trim().replace(/\s+/g, ' '); }
  function hash(s) {
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      h1 = Math.imul(h1 ^ c, 2654435761);
      h2 = Math.imul(h2 ^ c, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }
  function fmt(t) {
    try { return new Date(t).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' }); }
    catch (e) { return ''; }
  }
  function userById(id) { return S.users.find(function (u) { return u.id === id; }); }
  function me() { return userById(S.session); }

  function save(k) {
    return Store.set(k, S[k]).then(function () { return true; }).catch(function () {
      toast('บันทึกไม่สำเร็จ พื้นที่จัดเก็บอาจเต็ม');
      return false;
    });
  }

  var tt;
  function toast(m) {
    var t = $('#toast');
    t.textContent = m;
    t.classList.add('on');
    clearTimeout(tt);
    tt = setTimeout(function () { t.classList.remove('on'); }, 2300);
  }

  function ask(msg, ok) {
    return new Promise(function (res) {
      var d = document.createElement('div');
      d.className = 'dlg';
      d.innerHTML = '<div class="dbox"><p>' + esc(msg) + '</p><div class="drow">' +
        '<button class="btn sec" data-r="0">ยกเลิก</button>' +
        '<button class="btn" data-r="1">' + esc(ok || 'ตกลง') + '</button></div></div>';
      d.onclick = function (e) {
        var b = e.target.closest('[data-r]');
        if (b || e.target === d) { d.remove(); res(!!b && b.dataset.r === '1'); }
      };
      document.body.appendChild(d);
    });
  }

  /* ---------- รูปภาพ ---------- */
  function readFile(f) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
      r.readAsDataURL(f);
    });
  }
  function loadImg(src) {
    return new Promise(function (res, rej) {
      var i = new Image();
      i.onload = function () { res(i); };
      i.onerror = function () { rej(new Error('img')); };
      i.src = src;
    });
  }
  function compress(src, max, q, square) {
    var p = (src instanceof Blob) ? readFile(src) : Promise.resolve(src);
    return p.then(loadImg).then(function (img) {
      var w = img.naturalWidth, h = img.naturalHeight;
      var c = document.createElement('canvas');
      var ctx = c.getContext('2d');
      if (square) {
        var s = Math.min(w, h);
        c.width = c.height = Math.min(max, s);
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
        ctx.drawImage(img, (w - s) / 2, (h - s) / 2, s, s, 0, 0, c.width, c.height);
      } else {
        var k = Math.min(1, max / Math.max(w, h));
        c.width = Math.round(w * k); c.height = Math.round(h * k);
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
        ctx.drawImage(img, 0, 0, c.width, c.height);
      }
      return c.toDataURL('image/jpeg', q);
    });
  }

  /* ---------- ไอคอน ---------- */
  function ic(p) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + p + '</svg>';
  }
  var I = {
    home: ic('<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'),
    search: ic('<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>'),
    add: ic('<path d="M12 5v14M5 12h14"/>'),
    me: ic('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>'),
    back: ic('<path d="M15 5l-7 7 7 7"/>'),
    pencil: ic('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>'),
    logout: ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>'),
    eye: ic('<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    eyeOff: ic('<path d="M17.9 17.9A10.9 10.9 0 0 1 12 19c-6.4 0-10-7-10-7a18 18 0 0 1 5.1-5.9M9.9 4.2A9.7 9.7 0 0 1 12 4c6.4 0 10 7 10 7a18 18 0 0 1-2.2 3.2M1 1l22 22"/>'),
    camera: ic('<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>'),
    close: ic('<path d="M18 6 6 18M6 6l12 12"/>'),
    trash: ic('<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/>'),
    image: ic('<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>'),
    google: '<svg viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>'
  };

  /* ---------- ชื่อสุ่ม ---------- */
  function nameTaken(n, exceptId) {
    var k = norm(n).toLowerCase();
    return S.users.some(function (x) { return x.id !== exceptId && norm(x.name).toLowerCase() === k; });
  }
  function genName() {
    for (var i = 0; i < 300; i++) {
      var n = pick(NAMES.first) + ' ' + pick(NAMES.last);
      if (!nameTaken(n)) return n;
    }
    var base = pick(NAMES.first) + ' ' + pick(NAMES.last), c = 2;
    while (nameTaken(base + ' ' + c)) c++;
    return base + ' ' + c;
  }
  function genNick() { return pick(NAMES.nick); }

  /* ---------- ส่วนประกอบ UI ---------- */
  function avatar(u, s) {
    if (u && u.avatar) {
      return '<img class="av" style="width:' + s + 'px;height:' + s + 'px" src="' + u.avatar + '" alt="">';
    }
    var nick = (u && u.nick) || '?';
    var m = nick.match(/[ก-ฮA-Za-z0-9]/);
    var ch = esc((m ? m[0] : '?').toUpperCase());
    return '<span class="av ph" style="width:' + s + 'px;height:' + s + 'px;font-size:' + Math.round(s * 0.44) + 'px">' + ch + '</span>';
  }
  function cardHTML(p) {
    var u = userById(p.uid) || { nick: 'ผู้ใช้' };
    return '<div class="card" data-post="' + p.id + '">' +
      '<img class="pic" src="' + p.img + '" alt="">' +
      (p.cap ? '<div class="cap">' + esc(p.cap) + '</div>' : '') +
      '<div class="by">' + avatar(u, 22) + '<span>' + esc(u.nick) + '</span></div></div>';
  }
  function gridHTML(list) {
    return '<div class="grid">' + list.map(cardHTML).join('') + '</div>';
  }
  function byTime(a, b) { return b.t - a.t; }

  /* ---------- หน้าซ้อน (page stack) + ปุ่มย้อนกลับของเครื่อง ---------- */
  var pages = [];
  function openPage(html, cls) {
    var p = document.createElement('div');
    p.className = 'page ' + (cls || '');
    p.innerHTML = html;
    document.body.appendChild(p);
    pages.push(p);
    history.pushState({ pg: pages.length }, '');
    requestAnimationFrame(function () { requestAnimationFrame(function () { p.classList.add('in'); }); });
    return p;
  }
  function back() { history.back(); }
  function closeAllPages() {
    var n = pages.length;
    pages.splice(0).forEach(function (p) { p.remove(); });
    if (n) history.go(-n);
  }
  window.addEventListener('popstate', function () {
    var p = pages.pop();
    if (p) { p.classList.remove('in'); setTimeout(function () { p.remove(); }, 260); }
  });
  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-back]')) back();
    var eye = e.target.closest('[data-eye]');
    if (eye) {
      var inp = eye.parentNode.querySelector('input');
      var show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      eye.innerHTML = show ? I.eyeOff : I.eye;
    }
  });

  /* ================= หน้าเข้าสู่ระบบ ================= */
  function renderAuth() {
    closeAllPages();
    root.innerHTML =
      '<div class="auth">' +
      '<div class="hero"><div class="logo">' + I.image + '</div><h1>Snaply</h1><p>แบ่งปันภาพถ่ายของคุณให้ทุกคนได้เห็น</p></div>' +
      '<div class="sheet">' +
      '<h2>เริ่มต้นใช้งาน</h2>' +
      '<label>อีเมล</label><div class="field"><input id="em" type="email" autocomplete="email" placeholder="you@example.com"></div>' +
      '<label>รหัสผ่าน</label><div class="field"><input id="pw" type="password" autocomplete="current-password" placeholder="อย่างน้อย 6 ตัวอักษร"><button type="button" class="eye" data-eye>' + I.eye + '</button></div>' +
      '<div class="err" id="aerr"></div>' +
      '<button class="btn" id="ok">ตกลง</button>' +
      '<div class="or"><span>หรือ</span></div>' +
      '<button class="gbtn" id="gb"><span class="gl">' + I.google + '</span>Google</button>' +
      '<p class="hint">ถ้ายังไม่มีบัญชี ระบบจะสมัครให้ด้วยอีเมลนี้โดยอัตโนมัติ</p>' +
      '</div></div>';
    var em = $('#em'), pw = $('#pw'), err = $('#aerr');
    function setErr(m) { err.textContent = m || ''; return false; }
    function go() { doAuth(em.value, pw.value, setErr, false); }
    $('#ok').onclick = go;
    pw.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
    em.addEventListener('keydown', function (e) { if (e.key === 'Enter') pw.focus(); });
    $('#gb').onclick = openGoogle;
  }

  function doAuth(email, pw, setErr, viaGoogle) {
    email = String(email).trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return Promise.resolve(setErr('รูปแบบอีเมลไม่ถูกต้อง'));
    if (pw.length < 6) return Promise.resolve(setErr('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร'));
    var h = hash('snaply::' + email + '::' + pw);
    var u = S.users.find(function (x) { return x.email === email; });
    var p = Promise.resolve(true), created = false;
    if (u) {
      if (u.pass !== h) return Promise.resolve(setErr('รหัสผ่านไม่ถูกต้อง'));
    } else {
      u = { id: uid(), email: email, pass: h, nick: genNick(), name: genName(), avatar: '', created: Date.now() };
      S.users.push(u);
      created = true;
      p = save('users').then(function (ok) {
        if (!ok) { S.users.pop(); setErr('สมัครไม่สำเร็จ ลองใหม่อีกครั้ง'); }
        return ok;
      });
    }
    return p.then(function (ok) {
      if (!ok) return false;
      if (viaGoogle && S.gaccounts.indexOf(email) < 0) { S.gaccounts.push(email); save('gaccounts'); }
      S.session = u.id;
      return save('session').then(function () {
        renderApp();
        if (created) toast('สมัครบัญชีสำเร็จ ยินดีต้อนรับ');
        return true;
      });
    });
  }

  /* ---------- Google (จำลองในเครื่อง ไม่ใช้ API) ---------- */
  function openGoogle() {
    var accs = S.gaccounts;
    var rows = accs.map(function (a) {
      return '<button class="grow" data-em="' + esc(a) + '"><span class="gav">' + esc(a.charAt(0).toUpperCase()) + '</span>' +
        '<span class="gt"><b>' + esc(a.split('@')[0]) + '</b><small>' + esc(a) + '</small></span></button>';
    }).join('');
    var pg = openPage(
      '<div class="gpage"><div class="vtop"><button class="ib" data-back>' + I.back + '</button><span></span><span class="ib"></span></div>' +
      '<div class="gbody"><div class="gbig">' + I.google + '</div><h2>เลือกบัญชี</h2><p class="mut c">เพื่อดำเนินการต่อไปยัง Snaply</p>' +
      '<div class="glist">' + rows +
      '<button class="grow" id="gnew"><span class="gav plus">+</span><span class="gt"><b>ใช้บัญชีอื่น</b></span></button></div>' +
      '<div id="gform" hidden><label>อีเมล Google</label><div class="field"><input id="gem" type="email" placeholder="yourname@gmail.com"></div>' +
      '<div class="err" id="gerr"></div><button class="btn" id="gnext">ถัดไป</button></div>' +
      '</div></div>');
    pg.addEventListener('click', function (e) {
      var r = e.target.closest('[data-em]');
      if (r) { openGooglePw(r.dataset.em); return; }
      if (e.target.closest('#gnew')) {
        $('#gform', pg).hidden = false;
        $('#gem', pg).focus();
      }
      if (e.target.closest('#gnext')) {
        var v = $('#gem', pg).value.trim().toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) { $('#gerr', pg).textContent = 'รูปแบบอีเมลไม่ถูกต้อง'; return; }
        openGooglePw(v);
      }
    });
  }

  function openGooglePw(email) {
    var exists = S.users.some(function (u) { return u.email === email; });
    var pg = openPage(
      '<div class="gpage"><div class="vtop"><button class="ib" data-back>' + I.back + '</button><span></span><span class="ib"></span></div>' +
      '<div class="gbody"><div class="gbig">' + I.google + '</div><h2>' + (exists ? 'ยินดีต้อนรับกลับ' : 'ตั้งรหัสผ่าน') + '</h2>' +
      '<div class="gpill"><span class="gav">' + esc(email.charAt(0).toUpperCase()) + '</span><span>' + esc(email) + '</span></div>' +
      '<label>รหัสผ่าน</label><div class="field"><input id="gpw" type="password" placeholder="อย่างน้อย 6 ตัวอักษร"><button type="button" class="eye" data-eye>' + I.eye + '</button></div>' +
      '<div class="err" id="gperr"></div><button class="btn" id="gok">ตกลง</button>' +
      '<p class="hint">' + (exists ? 'ใส่รหัสผ่านที่เคยตั้งไว้กับอีเมลนี้' : 'ระบบจะสมัครบัญชีด้วยอีเมลนี้ให้อัตโนมัติ') + '</p>' +
      '</div></div>');
    var pw = $('#gpw', pg), err = $('#gperr', pg);
    function setErr(m) { err.textContent = m || ''; return false; }
    function go() { doAuth(email, pw.value, setErr, true); }
    $('#gok', pg).onclick = go;
    pw.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
    setTimeout(function () { pw.focus(); }, 300);
  }

  /* ================= โครงแอป ================= */
  function renderApp() {
    closeAllPages();
    root.innerHTML =
      '<div class="app"><div class="view" id="view"></div>' +
      '<nav class="nav">' +
      ['home', 'search', 'add', 'me'].map(function (t) {
        return '<button data-tab="' + t + '" class="' + (t === 'add' ? 'plus' : '') + '" aria-label="' + t + '">' + I[t] + '</button>';
      }).join('') + '</nav></div>';
    $('.nav').onclick = function (e) {
      var b = e.target.closest('[data-tab]');
      if (b) setTab(b.dataset.tab);
    };
    $('#view').onclick = onViewClick;
    setTab('home');
  }

  function onViewClick(e) {
    var post = e.target.closest('[data-post]');
    if (post) {
      if (tab === 'search' && query.trim()) addSearch(query);
      openViewer(post.dataset.post);
      return;
    }
    var term = e.target.closest('[data-term]');
    if (term) {
      query = term.dataset.term;
      var q = $('#q'); if (q) q.value = query;
      addSearch(query); drawSearch(); return;
    }
    var rm = e.target.closest('[data-rm]');
    if (rm) {
      var t = rm.dataset.rm;
      S.searches[S.session] = (S.searches[S.session] || []).filter(function (x) { return x !== t; });
      save('searches'); drawSearch(); return;
    }
    if (e.target.closest('[data-clear]')) {
      S.searches[S.session] = []; save('searches'); drawSearch(); return;
    }
  }

  function setTab(t) {
    tab = t;
    var navs = document.querySelectorAll('.nav [data-tab]');
    for (var i = 0; i < navs.length; i++) navs[i].classList.toggle('on', navs[i].dataset.tab === t);
    var v = $('#view');
    v.scrollTop = 0;
    if (t === 'home') renderHome();
    else if (t === 'search') renderSearch();
    else if (t === 'add') renderAdd();
    else renderProfile();
  }
  function refresh() { if (tab === 'home') renderHome(); else if (tab === 'me') renderProfile(); else if (tab === 'search') drawSearch(); }

  /* ---------- หน้าแรก ---------- */
  function renderHome() {
    var list = S.posts.slice().sort(byTime);
    $('#view').innerHTML = '<div class="topbar"><h1 class="brand">Snaply</h1></div>' +
      (list.length ? gridHTML(list) :
        '<div class="empty">' + I.image + '<h3>ยังไม่มีรูปภาพ</h3><p>กดปุ่ม + ด้านล่างเพื่อโพสต์รูปแรก</p></div>');
  }

  /* ---------- ดูรูป ---------- */
  function pushView(id) {
    var l = (S.views[S.session] || []).filter(function (x) { return x !== id; });
    l.unshift(id);
    S.views[S.session] = l.slice(0, 18);
    save('views');
    if (tab === 'search') drawSearch();
  }
  function openViewer(id) {
    var p = S.posts.find(function (x) { return x.id === id; });
    if (!p) return;
    var u = userById(p.uid) || { nick: 'ผู้ใช้ที่ถูกลบ', name: '' };
    pushView(id);
    var own = p.uid === S.session;
    var pg = openPage(
      '<div class="vtop"><button class="ib" data-back>' + I.back + '</button><h3>รูปภาพ</h3>' +
      (own ? '<button class="ib" id="del">' + I.trash + '</button>' : '<span class="ib"></span>') + '</div>' +
      '<div class="vbody"><div class="vuser">' + avatar(u, 42) + '<div><b>' + esc(u.nick) + '</b><small>' + esc(u.name) + '</small></div></div>' +
      '<img class="vimg" src="' + p.img + '" alt="">' +
      '<div class="vcap">' + (p.cap ? esc(p.cap) : '<span class="mut">ไม่มีคำอธิบาย</span>') + '</div>' +
      '<div class="vdate">' + fmt(p.t) + '</div></div>');
    if (own) {
      $('#del', pg).onclick = function () {
        ask('ลบโพสต์นี้ใช่ไหม', 'ลบ').then(function (yes) {
          if (!yes) return;
          S.posts = S.posts.filter(function (x) { return x.id !== id; });
          save('posts');
          back();
          setTimeout(refresh, 50);
          toast('ลบโพสต์แล้ว');
        });
      };
    }
  }

  /* ---------- ค้นหา ---------- */
  function addSearch(term) {
    var t = String(term).trim();
    if (!t) return;
    var l = (S.searches[S.session] || []).filter(function (x) { return x !== t; });
    l.unshift(t);
    S.searches[S.session] = l.slice(0, 12);
    save('searches');
  }
  function renderSearch() {
    $('#view').innerHTML =
      '<div class="topbar"><div class="sbox">' + I.search +
      '<input id="q" type="text" placeholder="ค้นหารูปภาพ ชื่อ หรือคำอธิบาย" enterkeyhint="search" autocomplete="off">' +
      '<button class="x" id="qx" hidden>' + I.close + '</button></div></div><div id="sres"></div>';
    var q = $('#q');
    q.value = query;
    q.addEventListener('input', function () { query = q.value; drawSearch(); });
    q.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { addSearch(query); q.blur(); drawSearch(); }
    });
    $('#qx').onclick = function () { query = ''; q.value = ''; drawSearch(); q.focus(); };
    drawSearch();
  }
  function drawSearch() {
    var r = $('#sres');
    if (!r) return;
    var qx = $('#qx'); if (qx) qx.hidden = !query;
    var t = query.trim().toLowerCase();
    if (!t) {
      var hist = S.searches[S.session] || [];
      var recent = (S.views[S.session] || []).map(function (id) {
        return S.posts.find(function (p) { return p.id === id; });
      }).filter(Boolean);
      r.innerHTML =
        '<div class="sec"><div class="sech"><h3>ค้นหาล่าสุด</h3>' + (hist.length ? '<button class="lnk" data-clear>ล้างทั้งหมด</button>' : '') + '</div>' +
        (hist.length ? '<div class="chips">' + hist.map(function (h) {
          return '<div class="chip"><span data-term="' + esc(h) + '">' + esc(h) + '</span><button data-rm="' + esc(h) + '" aria-label="ลบ">' + I.close + '</button></div>';
        }).join('') + '</div>' : '<p class="mut pad">ยังไม่มีประวัติการค้นหา</p>') + '</div>' +
        '<div class="sec"><div class="sech"><h3>รูปภาพที่ดูล่าสุด</h3></div>' +
        (recent.length ? '<div class="thumbs">' + recent.map(function (p) {
          return '<div class="th" data-post="' + p.id + '"><img src="' + p.img + '" alt=""></div>';
        }).join('') + '</div>' : '<p class="mut pad">ยังไม่มีรูปที่ดูล่าสุด</p>') + '</div>';
    } else {
      var res = S.posts.filter(function (p) {
        var u = userById(p.uid) || {};
        return (p.cap || '').toLowerCase().indexOf(t) >= 0 ||
          (u.nick || '').toLowerCase().indexOf(t) >= 0 ||
          (u.name || '').toLowerCase().indexOf(t) >= 0;
      }).sort(byTime);
      r.innerHTML = res.length
        ? '<div class="sech"><h3>พบ ' + res.length + ' รูป</h3></div>' + gridHTML(res)
        : '<div class="empty">' + I.search + '<h3>ไม่พบผลการค้นหา</h3><p>ลองใช้คำอื่น หรือค้นหาจากชื่อผู้ใช้</p></div>';
    }
  }

  /* ---------- โพสต์ใหม่ ---------- */
  function renderAdd() {
    $('#view').innerHTML =
      '<div class="topbar"><h1>โพสต์ใหม่</h1></div><div class="form">' +
      '<div class="pickbox" id="pick">' + (draft.img
        ? '<img src="' + draft.img + '" alt="">'
        : '<div class="ph2">' + I.image + '<b>แตะเพื่อเลือกรูปภาพ</b><small>เลือกจากอัลบั้มในเครื่องของคุณ</small></div>') + '</div>' +
      '<input type="file" id="file" accept="image/*" hidden>' +
      '<label>คำอธิบาย</label><div class="field area"><textarea id="cap" rows="4" maxlength="300" placeholder="เขียนคำอธิบายรูปภาพ"></textarea></div>' +
      '<button class="btn" id="save">บันทึก</button></div>';
    var cap = $('#cap'), file = $('#file');
    cap.value = draft.cap;
    cap.addEventListener('input', function () { draft.cap = cap.value; });
    $('#pick').onclick = function () { file.click(); };
    file.onchange = function () {
      var f = file.files && file.files[0];
      if (!f) return;
      toast('กำลังเตรียมรูปภาพ...');
      compress(f, 1080, 0.82, false).then(function (d) {
        draft.img = d;
        renderAdd();
      }).catch(function () { toast('เปิดรูปภาพนี้ไม่ได้ ลองเลือกรูปอื่น'); });
    };
    $('#save').onclick = function () {
      if (!draft.img) { toast('กรุณาเลือกรูปภาพก่อน'); return; }
      var btn = $('#save'); btn.disabled = true;
      var post = { id: uid(), uid: S.session, cap: draft.cap.trim(), img: draft.img, t: Date.now() };
      S.posts.push(post);
      save('posts').then(function (ok) {
        if (!ok) { S.posts.pop(); btn.disabled = false; return; }
        draft = { img: '', cap: '' };
        setTab('home');
        toast('โพสต์เรียบร้อยแล้ว');
      });
    };
  }

  /* ---------- โปรไฟล์ ---------- */
  function renderProfile() {
    var u = me();
    if (!u) { renderAuth(); return; }
    var mine = S.posts.filter(function (p) { return p.uid === u.id; }).sort(byTime);
    $('#view').innerHTML =
      '<div class="topbar"><h1>โปรไฟล์</h1><button class="ib" id="lo" aria-label="ออกจากระบบ">' + I.logout + '</button></div>' +
      '<div class="phead"><div class="pav">' + avatar(u, 108) + '</div>' +
      '<h2>' + esc(u.nick) + '</h2><div class="pname">' + esc(u.name) + '</div>' +
      '<div class="pmail"><span>' + esc(u.email) + '</span><button class="pen" id="pen" aria-label="แก้ไขโปรไฟล์">' + I.pencil + '</button></div>' +
      '<div class="pstat"><b>' + mine.length + '</b> โพสต์</div></div>' +
      '<div class="sech"><h3>รูปของฉัน</h3></div>' +
      (mine.length ? gridHTML(mine) : '<p class="mut c pad">คุณยังไม่ได้โพสต์รูปภาพ</p>');
    $('#pen').onclick = openEdit;
    $('#lo').onclick = function () {
      ask('ออกจากระบบใช่ไหม', 'ออกจากระบบ').then(function (yes) {
        if (!yes) return;
        S.session = null;
        save('session').then(function () { query = ''; draft = { img: '', cap: '' }; renderAuth(); });
      });
    };
  }

  function openEdit() {
    var u = me();
    var ed = { avatar: u.avatar || '' };
    var pg = openPage(
      '<div class="vtop"><button class="ib" data-back>' + I.back + '</button><h3>แก้ไขโปรไฟล์</h3><span class="ib"></span></div>' +
      '<div class="ebody"><div class="eav" id="eav"></div><p class="mut c small">แตะรูปเพื่อเปลี่ยนโปรไฟล์</p>' +
      '<label>ชื่อเล่น</label><div class="field"><input id="en" maxlength="30" placeholder="ชื่อเล่น"></div>' +
      '<label>ชื่อจริง</label><div class="field" id="erf"><input id="er" maxlength="40" placeholder="ชื่อจริง"></div>' +
      '<div class="msg" id="emsg"></div>' +
      '<button class="btn" id="esave">บันทึก</button></div>');
    var en = $('#en', pg), er = $('#er', pg), msg = $('#emsg', pg), erf = $('#erf', pg);
    en.value = u.nick; er.value = u.name;
    function drawAv() {
      $('#eav', pg).innerHTML = avatar({ avatar: ed.avatar, nick: en.value || u.nick }, 112) + '<span class="cam">' + I.camera + '</span>';
    }
    drawAv();
    function checkName() {
      var n = norm(er.value);
      erf.classList.remove('bad', 'good');
      if (!n) { msg.className = 'msg bad'; msg.textContent = 'กรุณาใส่ชื่อจริง'; erf.classList.add('bad'); return false; }
      if (nameTaken(n, u.id)) { msg.className = 'msg bad'; msg.textContent = 'ชื่อจริงนี้มีผู้ใช้อื่นใช้แล้ว กรุณาตั้งชื่ออื่น'; erf.classList.add('bad'); return false; }
      msg.className = 'msg good'; msg.textContent = 'ใช้ชื่อนี้ได้'; erf.classList.add('good');
      return true;
    }
    er.addEventListener('input', checkName);
    en.addEventListener('input', function () { if (!ed.avatar) drawAv(); });
    $('#eav', pg).onclick = function () { openAvatarPicker(function (d) { ed.avatar = d; drawAv(); }); };
    $('#esave', pg).onclick = function () {
      var nick = norm(en.value);
      if (!nick) { toast('กรุณาใส่ชื่อเล่น'); return; }
      if (!checkName()) return;
      var old = { nick: u.nick, name: u.name, avatar: u.avatar };
      u.nick = nick; u.name = norm(er.value); u.avatar = ed.avatar;
      save('users').then(function (ok) {
        if (!ok) { u.nick = old.nick; u.name = old.name; u.avatar = old.avatar; return; }
        back();
        setTimeout(function () { refresh(); }, 50);
        toast('บันทึกโปรไฟล์แล้ว');
      });
    };
  }

  function openAvatarPicker(onPick) {
    var mine = S.posts.filter(function (p) { return p.uid === S.session; }).sort(byTime);
    var pg = openPage(
      '<div class="vtop"><button class="ib" data-back>' + I.back + '</button><h3>เลือกรูปโปรไฟล์</h3><span class="ib"></span></div>' +
      '<div class="ebody"><div class="row2"><button class="btn sec" id="apdev">เลือกจากเครื่อง</button><button class="btn sec" id="aprm">ไม่ใช้รูป</button></div>' +
      '<div class="sech nopad"><h3>รูปในอัลบั้มของคุณ</h3></div>' +
      (mine.length ? '<div class="thumbs big">' + mine.map(function (p) {
        return '<div class="th" data-pid="' + p.id + '"><img src="' + p.img + '" alt=""></div>';
      }).join('') + '</div>' : '<p class="mut">ยังไม่มีรูปที่คุณโพสต์ ลองโพสต์รูปก่อน หรือเลือกจากเครื่อง</p>') +
      '<input type="file" id="apf" accept="image/*" hidden></div>');
    pg.addEventListener('click', function (e) {
      var th = e.target.closest('[data-pid]');
      if (th) {
        var p = S.posts.find(function (x) { return x.id === th.dataset.pid; });
        if (!p) return;
        compress(p.img, 360, 0.85, true).then(function (d) { onPick(d); back(); });
        return;
      }
      if (e.target.closest('#apdev')) $('#apf', pg).click();
      if (e.target.closest('#aprm')) { onPick(''); back(); }
    });
    $('#apf', pg).onchange = function (e) {
      var f = e.target.files && e.target.files[0];
      if (!f) return;
      compress(f, 360, 0.85, true).then(function (d) { onPick(d); back(); })
        .catch(function () { toast('เปิดรูปภาพนี้ไม่ได้'); });
    };
  }

  /* ---------- เริ่มทำงาน ---------- */
  (function init() {
    Store.open().then(function () {
      return Promise.all(KEYS.map(function (k) {
        return Store.get(k).then(function (v) { if (v !== undefined && v !== null) S[k] = v; });
      }));
    }).then(function () {
      if (S.session && userById(S.session)) renderApp();
      else { S.session = null; renderAuth(); }
    }).catch(function () { renderAuth(); });
  })();
})();
