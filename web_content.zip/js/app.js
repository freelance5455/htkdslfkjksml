(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = {
    songs: [], favorites: new Set(JSON.parse(localStorage.getItem('vyro-favorites') || '[]')),
    recent: JSON.parse(localStorage.getItem('vyro-recent') || '[]'), current: -1,
    native: false, playing: false, shuffle: false, repeat: false,
    audio: null, covers: {}, poller: null, currentDuration: 0, currentPosition: 0,
    activeView: 'homeView', search: '', browserUrls: []
  };

  const icons = {
    play: '<path d="m8 5 12 7-12 7z"/>',
    pause: '<path d="M7 5h3v14H7zM14 5h3v14h-3z"/>'
  };

  function toast(message) {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2600);
  }
  function formatTime(ms) {
    const seconds = Math.max(0, Math.floor((Number(ms) || 0) / 1000));
    return String(Math.floor(seconds / 60)).padStart(2, '0') + ':' + String(seconds % 60).padStart(2, '0');
  }
  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function nativeCall(method, ...args) {
    return new Promise((resolve, reject) => {
      if (!window.LocalMusic || typeof window.LocalMusic[method] !== 'function') return reject(new Error('Native audio bridge is unavailable'));
      window.LocalMusic[method](resolve, reject, ...args);
    });
  }

  function init() {
    state.native = !!(window.cordova && window.LocalMusic);
    bindEvents();
    renderHome(); renderFavorites();
    if (state.native) loadNativeLibrary(true);
    else {
      $('permissionStatus').classList.add('inactive');
      toast('Preview mode: open this app as an Android APK to scan the phone music library.');
    }
    state.poller = setInterval(updatePlaybackStatus, 650);
  }

  function bindEvents() {
    document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => switchView(button.dataset.view)));
    $('navPlay').addEventListener('click', togglePlayback);
    $('heroPlay').addEventListener('click', () => state.current < 0 ? firstSong() : togglePlayback());
    $('searchToggle').addEventListener('click', () => { $('searchBar').classList.toggle('hidden'); if (!$('searchBar').classList.contains('hidden')) $('searchInput').focus(); });
    $('searchInput').addEventListener('input', e => { state.search = e.target.value.trim().toLowerCase(); renderSongs(); });
    $('clearSearch').addEventListener('click', () => { $('searchInput').value = ''; state.search = ''; renderSongs(); });
    $('seeAll').addEventListener('click', () => { switchView('playlistView'); });
    $('closePlayer').addEventListener('click', () => { $('playerView').classList.remove('player-visible'); $('app').classList.remove('player-open'); });
    $('mainPlayButton').addEventListener('click', togglePlayback);
    $('previousButton').addEventListener('click', previousSong);
    $('nextButton').addEventListener('click', nextSong);
    $('shuffleButton').addEventListener('click', () => { state.shuffle = !state.shuffle; $('shuffleButton').classList.toggle('selected', state.shuffle); toast(state.shuffle ? 'Shuffle on' : 'Shuffle off'); });
    $('repeatButton').addEventListener('click', () => { state.repeat = !state.repeat; $('repeatButton').classList.toggle('selected', state.repeat); toast(state.repeat ? 'Repeat on' : 'Repeat off'); });
    $('favoriteButton').addEventListener('click', toggleFavorite);
    $('progress').addEventListener('input', e => {
      const target = Number(e.target.value) / 1000 * state.currentDuration;
      $('currentTime').textContent = formatTime(target);
    });
    $('progress').addEventListener('change', e => seekTo(Number(e.target.value) / 1000 * state.currentDuration));
    $('volume').addEventListener('input', e => setVolume(Number(e.target.value) / 100));
    $('rescanButton').addEventListener('click', () => loadNativeLibrary(false));
    $('filePicker').addEventListener('change', importBrowserFiles);
    $('playLiked').addEventListener('click', () => {
      const liked = state.songs.filter(s => state.favorites.has(String(s.id)));
      if (liked.length) playSong(state.songs.indexOf(liked[0])); else toast('No favorite songs yet.');
    });
    $('moreButton').addEventListener('click', () => toast('Your music. No account or internet needed.'));
    $('playerMore').addEventListener('click', () => toast('VYRO Music · Offline player'));
  }

  async function loadNativeLibrary(firstRun) {
    if (!state.native) return;
    $('songList').innerHTML = '<div class="empty-state"><span class="loader"></span><p>Scanning your music...</p></div>';
    try {
      const tracks = await nativeCall('listAudio');
      state.songs = (tracks || []).map(t => ({...t, id: String(t.id), duration: Number(t.duration || 0), isBrowser: false}));
      $('permissionStatus').classList.remove('inactive'); $('permissionStatus').classList.add('active');
      $('songCount').textContent = `${state.songs.length} TRACKS`;
      renderHome(); renderFavorites();
      if (!state.songs.length) {
        $('songList').innerHTML = '<div class="empty-state"><span>♫</span><h3>No music found</h3><p>Add audio files to your phone, then rescan your library.</p></div>';
      } else if (firstRun) toast(`${state.songs.length} songs found on your device`);
    } catch (error) {
      $('permissionStatus').classList.add('inactive');
      $('songList').innerHTML = '<div class="empty-state"><span>♫</span><h3>Music access needed</h3><p>Allow VYRO Music to read audio files, then scan again.</p><button class="outline-action" id="grantAgain">Allow music access</button></div>';
      const grant = $('grantAgain'); if (grant) grant.addEventListener('click', () => loadNativeLibrary(false));
      toast('Audio permission was not granted.');
    }
  }

  function renderHome() {
    const recentSongs = state.recent.map(id => state.songs.find(s => String(s.id) === String(id))).filter(Boolean).slice(0, 4);
    const display = recentSongs.length ? recentSongs : state.songs.slice(0, 4);
    $('recentGrid').innerHTML = display.length ? display.map((song, i) => `
      <button class="recent-card" data-play-index="${state.songs.indexOf(song)}">
        <div class="recent-art" id="recent-art-${escapeHtml(song.id)}"><span>♫</span><span class="mini-play" aria-hidden="true">▶</span></div>
        <span class="recent-title">${escapeHtml(song.title)}</span><span class="recent-subtitle">${escapeHtml(song.artist)}</span>
      </button>`).join('') : `<div class="empty-recent"><div class="empty-art">♫</div><div><b>Your sound starts here</b><span>Allow music access to find songs stored on your phone.</span><button id="emptyImport" class="inline-action">Import audio for preview</button></div></div>`;
    document.querySelectorAll('.recent-card').forEach(el => el.addEventListener('click', () => playSong(Number(el.dataset.playIndex))));
    const emptyImport = $('emptyImport'); if (emptyImport) emptyImport.addEventListener('click', () => $('filePicker').click());
    $('songCount').textContent = `${state.songs.length} TRACKS`;
    renderSongs();
    display.forEach(song => loadCover(song, $(`recent-art-${song.id}`)));
  }

  function renderSongs() {
    const list = state.songs.filter(s => !state.search || `${s.title} ${s.artist} ${s.album}`.toLowerCase().includes(state.search));
    $('songList').innerHTML = list.length ? list.map(song => {
      const index = state.songs.indexOf(song);
      return `<div class="song-row"><button class="song-cover" id="row-art-${escapeHtml(song.id)}" data-play-index="${index}"><span>♫</span></button><button class="song-details" data-play-index="${index}"><b>${escapeHtml(song.title)}</b><span>${escapeHtml(song.artist)}</span></button><span class="song-duration">${formatTime(song.duration)}</span><button class="row-more" data-favorite-id="${escapeHtml(song.id)}" aria-label="Favorite">${state.favorites.has(String(song.id)) ? '♥' : '♡'}</button></div>`;
    }).join('') : (state.songs.length ? '<div class="empty-state">No matching songs.</div>' : '<div class="empty-state"><span class="loader"></span><p>Waiting for your music library...</p></div>');
    $('songList').querySelectorAll('[data-play-index]').forEach(el => el.addEventListener('click', () => playSong(Number(el.dataset.playIndex))));
    $('songList').querySelectorAll('[data-favorite-id]').forEach(el => el.addEventListener('click', () => toggleFavoriteById(el.dataset.favoriteId)));
    list.forEach(song => loadCover(song, $(`row-art-${song.id}`)));
  }

  function renderFavorites() {
    const liked = state.songs.filter(s => state.favorites.has(String(s.id)));
    $('likedCount').textContent = `${liked.length} ${liked.length === 1 ? 'song' : 'songs'} saved`;
    $('favoriteList').innerHTML = liked.length ? liked.map(song => {
      const index = state.songs.indexOf(song);
      return `<div class="song-row"><button class="song-cover" id="fav-art-${escapeHtml(song.id)}" data-play-index="${index}"><span>♫</span></button><button class="song-details" data-play-index="${index}"><b>${escapeHtml(song.title)}</b><span>${escapeHtml(song.artist)}</span></button><span class="song-duration">${formatTime(song.duration)}</span><button class="row-more liked" data-favorite-id="${escapeHtml(song.id)}">♥</button></div>`;
    }).join('') : '<div class="empty-state"><span>♡</span><h3>No favorites yet</h3><p>Tap the heart on a song to save it here.</p></div>';
    $('favoriteList').querySelectorAll('[data-play-index]').forEach(el => el.addEventListener('click', () => playSong(Number(el.dataset.playIndex))));
    $('favoriteList').querySelectorAll('[data-favorite-id]').forEach(el => el.addEventListener('click', () => toggleFavoriteById(el.dataset.favoriteId)));
    liked.forEach(song => loadCover(song, $(`fav-art-${song.id}`)));
  }

  async function loadCover(song, element) {
    if (!element || !song) return;
    if (state.covers[song.id]) { applyCover(element, state.covers[song.id]); return; }
    if (!state.native || !song.albumId) return;
    try {
      const data = await nativeCall('getCover', song.albumId);
      if (data) { state.covers[song.id] = data; applyCover(element, data); }
    } catch (_) { /* artwork is optional */ }
  }
  function applyCover(element, data) {
    if (!element) return;
    if (element.tagName === 'IMG') { element.src = data; return; }
    element.style.backgroundImage = `linear-gradient(145deg, rgba(3,12,24,.08), rgba(2,7,14,.45)), url("${data}")`;
    element.classList.add('has-cover');
    if (element.tagName === 'IMG') { element.style.display = 'block'; $('coverFallback').style.display = 'none'; }
    const span = element.querySelector('span'); if (span) span.style.opacity = '0';
  }

  async function playSong(index) {
    const song = state.songs[index];
    if (!song) { toast('Your music library is empty.'); return; }
    state.current = index; state.currentPosition = 0; state.currentDuration = song.duration || 0;
    $('playerTitle').textContent = song.title; $('playerArtist').textContent = song.artist;
    $('currentTime').textContent = '00:00'; $('totalTime').textContent = formatTime(song.duration);
    $('progress').value = 0; updateFavoriteButton(); $('playerView').classList.add('player-visible'); $('app').classList.add('player-open');
    const cover = state.covers[song.id]; if (cover) setPlayerCover(cover); else { $('playerCover').removeAttribute('src'); $('coverFallback').style.display = 'grid'; $('playerBackdrop').style.backgroundImage = ''; }
    loadCover(song, $('playerCover'));
    state.recent = [String(song.id), ...state.recent.filter(id => String(id) !== String(song.id))].slice(0, 12);
    localStorage.setItem('vyro-recent', JSON.stringify(state.recent));
    renderRecentOnly();
    try {
      if (state.native) await nativeCall('play', song.uri);
      else if (song.objectUrl) {
        if (state.audio) { state.audio.pause(); state.audio = null; }
        state.audio = new Audio(song.objectUrl); state.audio.volume = Number($('volume').value) / 100;
        state.audio.addEventListener('ended', onEnded); await state.audio.play();
      } else throw new Error('This file is not playable in preview mode.');
      state.playing = true; syncPlayIcons();
    } catch (error) { state.playing = false; syncPlayIcons(); toast(error.message || 'Could not play this song.'); }
    renderSongs();
  }

  function renderRecentOnly() { renderHome(); }
  function setPlayerCover(data) {
    $('playerCover').src = data; $('playerCover').style.display = 'block'; $('coverFallback').style.display = 'none';
    $('playerBackdrop').style.backgroundImage = `linear-gradient(rgba(1,5,12,.55), rgba(1,5,12,.85)), url("${data}")`;
    $('playerBackdrop').style.backgroundSize = 'cover'; $('playerBackdrop').style.backgroundPosition = 'center';
    extractTheme(data);
  }
  function extractTheme(data) {
    const img = new Image(); img.onload = () => {
      try {
        const canvas = document.createElement('canvas'); canvas.width = 20; canvas.height = 20;
        const ctx = canvas.getContext('2d', {willReadFrequently:true}); ctx.drawImage(img, 0, 0, 20, 20);
        const pixels = ctx.getImageData(0, 0, 20, 20).data; let r=0,g=0,b=0,count=0;
        for(let i=0;i<pixels.length;i+=16){ const rr=pixels[i], gg=pixels[i+1], bb=pixels[i+2]; if(Math.max(rr,gg,bb)-Math.min(rr,gg,bb)>25){r+=rr;g+=gg;b+=bb;count++;} }
        if (!count) return; r=Math.round(r/count);g=Math.round(g/count);b=Math.round(b/count);
        const accent = `rgb(${Math.min(255,Math.round(r*.85+40))}, ${Math.min(255,Math.round(g*.85+40))}, ${Math.min(255,Math.round(b*.85+40))})`;
        document.documentElement.style.setProperty('--dynamic-accent', accent);
        document.documentElement.style.setProperty('--dynamic-glow', `rgba(${r},${g},${b},.35)`);
      } catch (_) { /* canvas may be unavailable in preview */ }
    }; img.src = data;
  }

  async function togglePlayback() {
    if (state.current < 0) { firstSong(); return; }
    try {
      if (state.native) {
        if (state.playing) await nativeCall('pause'); else await nativeCall('resume');
      } else if (state.audio) {
        if (state.playing) state.audio.pause(); else await state.audio.play();
      }
      state.playing = !state.playing; syncPlayIcons();
    } catch (_) { toast('Choose a song to start playback.'); }
  }
  function syncPlayIcons() {
    const icon = state.playing ? icons.pause : icons.play;
    $('mainPlayIcon').innerHTML = icon; $('navPlayIcon').innerHTML = icon; $('navPlay').classList.toggle('is-playing', state.playing);
    $('mainPlayButton').setAttribute('aria-label', state.playing ? 'Pause' : 'Play');
  }
  function firstSong() { if (state.songs.length) playSong(0); else toast('No songs found on this device.'); }
  function nextSong() {
    if (!state.songs.length) return;
    const next = state.shuffle ? Math.floor(Math.random() * state.songs.length) : (state.current + 1) % state.songs.length;
    playSong(next);
  }
  function previousSong() {
    if (!state.songs.length) return;
    if (state.currentPosition > 3000) { seekTo(0); return; }
    playSong((state.current - 1 + state.songs.length) % state.songs.length);
  }
  function onEnded() { if (state.repeat && state.current >= 0) playSong(state.current); else nextSong(); }
  async function updatePlaybackStatus() {
    if (state.current < 0) return;
    try {
      let status;
      if (state.native) status = await nativeCall('status');
      else if (state.audio) status = {isPlaying:!state.audio.paused, position:state.audio.currentTime*1000, duration:(state.audio.duration||0)*1000};
      else return;
      if (status.duration) state.currentDuration = status.duration;
      state.currentPosition = status.position || 0;
      if (status.isPlaying !== state.playing) { state.playing = status.isPlaying; syncPlayIcons(); }
      const duration = state.currentDuration || 1;
      $('progress').value = Math.min(1000, state.currentPosition / duration * 1000);
      $('currentTime').textContent = formatTime(state.currentPosition);
      $('totalTime').textContent = formatTime(duration);
      if (!status.isPlaying && status.prepared && status.duration > 0 && status.position >= status.duration - 500) onEnded();
    } catch (_) { /* avoid interrupting playback UI */ }
  }
  async function seekTo(ms) {
    try { if (state.native) await nativeCall('seek', ms); else if (state.audio) state.audio.currentTime = ms / 1000; } catch (_) {}
  }
  async function setVolume(value) {
    try { if (state.native) await nativeCall('setVolume', value); else if (state.audio) state.audio.volume = value; } catch (_) {}
  }
  function toggleFavorite() { if (state.current >= 0) toggleFavoriteById(state.songs[state.current].id); }
  function toggleFavoriteById(id) {
    id = String(id);
    if (state.favorites.has(id)) state.favorites.delete(id); else state.favorites.add(id);
    localStorage.setItem('vyro-favorites', JSON.stringify([...state.favorites]));
    updateFavoriteButton(); renderFavorites(); renderSongs();
  }
  function updateFavoriteButton() {
    const liked = state.current >= 0 && state.favorites.has(String(state.songs[state.current].id));
    $('favoriteButton').textContent = liked ? '♥' : '♡'; $('favoriteButton').classList.toggle('liked', liked);
  }

  function switchView(id) {
    state.activeView = id;
    document.querySelectorAll('.view').forEach(view => view.classList.toggle('active-view', view.id === id));
    document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.view === id));
    $('playerView').classList.remove('player-visible'); $('app').classList.remove('player-open');
    if (id === 'playlistView') renderFavorites();
  }
  function importBrowserFiles(event) {
    const files = [...(event.target.files || [])].filter(f => f.type.startsWith('audio/'));
    if (!files.length) return;
    state.browserUrls.forEach(URL.revokeObjectURL); state.browserUrls = [];
    const imported = files.map((file, i) => {
      const objectUrl = URL.createObjectURL(file); state.browserUrls.push(objectUrl);
      return {id:`local-${Date.now()}-${i}`, title:file.name.replace(/\.[^.]+$/, ''), artist:'Local audio file', album:'On this device', duration:0, objectUrl, isBrowser:true};
    });
    state.songs = [...imported, ...state.songs.filter(s => !s.isBrowser)];
    renderHome(); toast(`${imported.length} audio files imported for preview`); event.target.value = '';
  }

  document.addEventListener('deviceready', init, {once:true});
  if (!window.cordova) document.addEventListener('DOMContentLoaded', () => setTimeout(init, 60), {once:true});
})();
