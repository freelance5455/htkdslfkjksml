(function (EP) {
  'use strict';
  const { t, fmt, store: S, config: CFG, api: API } = EP;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const sum = a => a.reduce((x, y) => x + y, 0);
  const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const daysBetween = (a, b) => Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 864e5);
  const draft = { destination: '', place: '' };
  const pb = { lang: null, cc: null };
  const go = { from: null, date: '' };
  const cal = { key: '', y: 0, m: 0, sel: '' };
  const optF = { type: 'all', min: '', max: '', sort: 'asc' };
  const poiS = {};
  const POI_DEFAULT = { sights: 5000, food: 2000, stay: 3000 };
  const KIND_TYPES = { sights: ['attraction', 'museum', 'gallery', 'viewpoint', 'zoo', 'theme_park', 'aquarium', 'historic'], food: ['restaurant', 'cafe', 'fast_food', 'bar', 'pub'], stay: ['hotel', 'hostel', 'guest_house', 'apartment', 'motel'] };
  let pickCache = [], searchSeq = 0, devTaps = 0;

  // ---------- chrome ----------
  function setLang(l) {
    EP.lang = EP.S[l] ? l : 'en';
    document.documentElement.lang = EP.lang;
    document.documentElement.dir = EP.RTL.includes(EP.lang) ? 'rtl' : 'ltr';
    $('#skip').textContent = t('skip');
    $('#brandLang').setAttribute('aria-label', t('language'));
    $('#brandLang').innerHTML = Object.keys(EP.langs).map(k => `<option value="${k}"${k === EP.lang ? ' selected' : ''}>${esc(EP.langs[k])}</option>`).join('');
    const nav = [['#/', 'nHome', '⌕'], ['#/trips', 'nTrips', '✈'], ['#/weather', 'wxTitle', '☁'], ['#/tools', 'nTools', '⚙'], ['#/more', 'nMore', '☰']];
    $('#tabs').innerHTML = nav.map(n => `<a href="${n[0]}" data-tab="${n[0]}"><span aria-hidden="true">${n[2]}</span>${esc(t(n[1]))}</a>`).join('');
  }
  function say(msg) {
    const l = $('#live'); l.textContent = ''; setTimeout(() => { l.textContent = msg; }, 20);
    const el = $('#toast'); el.textContent = msg; el.hidden = false; clearTimeout(say.t); say.t = setTimeout(() => { el.hidden = true; }, 3200);
  }
  function ask(message, okLabel, danger) {
    return new Promise(res => {
      const d = $('#dlg');
      $('#dlgMsg', d).textContent = message;
      const ok = $('#dlgOk', d), no = $('#dlgNo', d);
      ok.textContent = okLabel || t('ok'); no.textContent = t('cancel');
      ok.className = danger ? 'btn danger' : 'btn primary';
      const done = v => { d.close(); ok.onclick = no.onclick = d.oncancel = null; res(v); };
      ok.onclick = () => done(true); no.onclick = () => done(false); d.oncancel = () => done(false);
      d.showModal(); no.focus();
    });
  }
  function download(name, mime, text) {
    const url = URL.createObjectURL(new Blob([text], { type: mime }));
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  const field = (label, inner) => `<label>${esc(label)}${inner}</label>`;
  const curOptions = sel => EP.currencies.map(c => `<option value="${c}"${c === sel ? ' selected' : ''}>${c} – ${esc(fmt.currency(c))}</option>`).join('');
  const badge = cc => `<span class="cc" aria-hidden="true">${esc(cc || '··')}</span>`;
  const placeLabel = p => p.name + (p.region && p.region !== p.name ? ', ' + p.region : '') + (p.cc ? ' · ' + fmt.country(p.cc) : '');
  const pid = p => encodeURIComponent(p.id);
  const kindLabel = k => t('kd_' + k);
  const heroCache = {};
  let wxShown = 7;
  const photoFor = k => (CFG.photos && CFG.photos[k]) || '';
  const artOrPhoto = k => (photoFor(k) ? `<img src="${esc(photoFor(k))}" alt="" loading="lazy">` : EP.art(k));
  const sectionHead = (kind, title, sub) => `<header class="shead"><div class="shtext"><h1>${esc(title)}</h1>${sub ? `<p class="muted">${esc(sub)}</p>` : ''}</div><div class="shart">${artOrPhoto(kind)}</div></header>`;
  const tabIntro = (kind, subKey) => `<div class="tabintro"><div class="shart sm">${artOrPhoto(kind)}</div><p>${esc(t(subKey))}</p></div>`;

  // ---------- place search widgets ----------
  function searchBox(mode, name, ph, value, hidden) {
    return `<div class="searchwrap" data-searchwrap><input type="search" data-search="${mode}" ${name ? `name="${name}"` : 'id="q"'} placeholder="${esc(ph)}" value="${esc(value || '')}" autocomplete="off" enterkeyhint="search" ${mode === 'nav' ? 'aria-label="' + esc(t('search')) + '"' : ''}>
      ${hidden !== undefined ? `<input type="hidden" name="place" value="${esc(hidden)}">` : ''}<ul class="results" data-list aria-live="polite"></ul></div>`;
  }
  function placeRow(p, i, mode) {
    const act = mode === 'nav' ? 'openplace' : mode === 'go' ? 'pickfrom' : 'pickplace';
    return `<li><button type="button" class="citycard" data-act="${act}" data-i="${i}">${badge(p.cc)}<strong>${esc(p.name)}</strong><span>${esc([p.region, p.cc ? fmt.country(p.cc) : ''].filter(Boolean).join(' · '))}</span></button></li>`;
  }
  async function runSearch(el) {
    const q = el.value.trim(), list = $('[data-list]', el.closest('[data-searchwrap]')), mode = el.dataset.search;
    if (q.length < 2) { list.innerHTML = ''; return; }
    const seq = ++searchSeq;
    list.innerHTML = `<li class="empty">${esc(t('hBusy'))}</li>`;
    const r = await API.search(q, S.get().online);
    if (seq !== searchSeq) return;
    pickCache = r.places;
    let html = '';
    if (r.needOnline) html += `<li class="notice">${esc(t('hNeed'))} <button type="button" class="btn primary sm" data-act="enableonline">${esc(t('hEnable'))}</button></li>`;
    else if (r.failed) html += `<li class="notice">${esc(t('hFail'))}</li>`;
    html += r.places.map((p, i) => placeRow(p, i, mode)).join('');
    if (!r.places.length && !r.needOnline) html += `<li class="empty">${esc(t('noResults'))}</li>`;
    list.innerHTML = html;
  }

  // ---------- home ----------
  function tripCard(x) {
    const now = today();
    const status = x.endDate < now ? t('tPast') : x.startDate <= now ? t('tNow') : t('tDaysLeft', { n: daysBetween(now, x.startDate) });
    return `<a class="tripcard" href="#/trip/${x.id}"><strong>${esc(x.title)}</strong><span>${esc(x.destination)}</span><small>${esc(fmt.date(x.startDate))} – ${esc(fmt.date(x.endDate))} · ${esc(status)}</small></a>`;
  }
  function placeChip(p) { return `<li><button class="citycard" data-act="gotoplace" data-id="${esc(p.id)}">${badge(p.cc)}<strong>${esc(p.name)}</strong><span>${esc(p.region || (p.cc ? fmt.country(p.cc) : ''))}</span></button></li>`; }
  function homeView() {
    const st = S.get();
    const next = st.trips.filter(x => x.status === 'active' && x.endDate >= today()).sort((a, b) => a.startDate.localeCompare(b.startDate))[0];
    return `<section class="hero"><div class="herotop"><h1>${esc(t('tagline'))}</h1><div class="shart hero-art">${artOrPhoto('home')}</div></div>
      <form id="searchForm" role="search" autocomplete="off">${searchBox('nav', '', t('searchPh2'))}</form>
      ${!st.online ? `<p class="notice">${esc(t('hNeed'))} <button class="btn primary sm" data-act="enableonline">${esc(t('hEnable'))}</button></p>` : ''}
      <p class="muted">${esc(t('hHint'))}</p>
      <a class="wxbtn" href="#/weather"><span class="wxbtn-ico">${EP.wxIcon(1, true, 'wxi lg')}</span><span class="wxbtn-txt"><strong>${esc(t('wxList'))}</strong><small>${esc(t('shWx'))}</small></span><span class="wxbtn-go" aria-hidden="true">›</span></a></section>
      ${next ? `<section aria-labelledby="h-next"><h2 id="h-next">${esc(t('nextTrip'))}</h2>${tripCard(next)}</section>` : ''}
      ${st.recent.length ? `<section aria-labelledby="h-rec"><h2 id="h-rec">${esc(t('hRecent'))}</h2><ul class="grid">${st.recent.map(placeChip).join('')}</ul></section>` : ''}
      ${st.saved.length ? `<section aria-labelledby="h-saved"><h2 id="h-saved">${esc(t('savedTitle'))}</h2><ul class="grid">${st.saved.map(placeChip).join('')}</ul></section>` : ''}`;
  }

  // ---------- place page ----------
  const PTABS = ['info', 'wx', 'sights', 'food', 'stay', 'go'];
  const PTKEY = { info: 'pInfo', wx: 'wxTitle', sights: 'pSights', food: 'pFood', stay: 'pStay', go: 'pGo' };
  function placeView(id, tab) {
    const p = S.findPlace(id); if (!p) return notFound();
    tab = PTABS.includes(tab) ? tab : 'info';
    const st = S.get();
    if (!st.recent.length || st.recent[0].id !== p.id) S.remember(p);
    const saved = S.isSaved(p.id);
    const nav = `<nav class="subtabs" aria-label="${esc(p.name)}">${PTABS.map(k => `<a href="#/place/${pid(p)}/${k}"${k === tab ? ' aria-current="page"' : ''}>${esc(t(PTKEY[k]))}</a>`).join('')}</nav>`;
    const hp = heroCache[p.id];
    const head = `<a class="back" href="#/">${esc(t('back'))}</a>
      <header class="phero" id="phero"><div class="phbg">${hp ? `<img src="${esc(hp.src)}" alt="">` : EP.art(tab === 'info' ? 'sights' : tab === 'wx' ? 'wx' : tab)}</div><div class="phtext">${badge(p.cc)}<h1>${esc(p.name)}</h1><p>${esc([p.region, p.cc ? fmt.country(p.cc) : ''].filter(Boolean).join(' · '))}</p></div><small class="phcredit" id="phcredit">${hp && hp.page ? `Photo: <a href="${esc(hp.page)}" target="_blank" rel="noopener noreferrer">Wikipedia</a>` : ''}</small></header>
      <div class="row2"><button class="btn primary" data-act="plan" data-id="${esc(p.id)}">${esc(t('startTrip'))}</button>
      <button class="btn ghost" data-act="savecity" data-id="${esc(p.id)}" aria-pressed="${saved}">${esc(saved ? t('unsaveCity') : t('saveCity'))}</button></div>${nav}`;
    if (tab === 'info') return head + infoTab(p);
    if (tab === 'wx') return head + wxTab(p);
    if (tab === 'go') return head + goTab(p);
    return head + poiTab(p, tab);
  }
  function emergencyBlock(cc) {
    const c = EP.countries[cc], em = c && c.em;
    if (!em) return `<p class="muted">${esc(t('emNote'))} <a href="https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers" target="_blank" rel="noopener noreferrer">Wikipedia ↗</a></p>`;
    const rows = [['general', 'emGeneral'], ['police', 'emPolice'], ['ambulance', 'emAmb'], ['fire', 'emFire']].filter(k => em[k[0]]);
    return `<ul class="em">${rows.map((k, i) => `<li><a class="btn ${i === 0 ? 'danger' : 'ghost'}" href="tel:${em[k[0]]}">${esc(t(k[1]))} · ${em[k[0]]}</a></li>`).join('')}</ul><p class="muted small">${esc(t('emNote'))}</p>`;
  }
  function wxFull(p, w) {
    if (!w) return EP.wx.card(p, null);
    return `${EP.wx.card(p, w, { big: true, link: false })}<h2>${esc(t('wxHourly'))}</h2><div class="card">${EP.wx.hourly(w)}</div>${EP.wx.tiles(w)}
      <h2>${esc(t('wxDaily'))}</h2><div class="card">${EP.wx.daily(w, wxShown, p.id)}</div>${w.daily.length > wxShown ? `<button class="btn ghost" data-act="wxmore">${esc(t('wxMore'))}</button>` : ''}
      <p class="muted small">${esc(t('wxUpd', { t: fmt.stamp(w.at) }))} · <button class="linklike" data-act="wxrefresh" data-id="${esc(p.id)}">${esc(t('wxRefresh'))}</button></p>`;
  }
  function wxTab(p) {
    const st = S.get();
    if (!st.online) return `${tabIntro('wx', 'shWx')}<p class="notice">${esc(t('wxNeed'))} <button class="btn primary sm" data-act="enableonline">${esc(t('hEnable'))}</button></p>`;
    return `${tabIntro('wx', 'shWx')}<div id="wxbox">${wxFull(p, st.wx[p.id])}</div>`;
  }
  function weatherPlaces() {
    const st = S.get(), seen = new Set(), out = [], add = p => { if (p && !seen.has(p.id)) { seen.add(p.id); out.push(p); } };
    st.trips.filter(x => x.status === 'active').forEach(x => add(x.place)); st.saved.forEach(add); st.recent.slice(0, 3).forEach(add);
    return out.slice(0, 12);
  }
  function weatherView() {
    const st = S.get(), ps = weatherPlaces();
    return `${sectionHead('wx', t('wxList'), t('shWx'))}
      <div class="wxbar"><div class="seg" role="group" aria-label="${esc(t('wxUnit'))}"><button class="btn ${st.tempUnit === 'c' ? 'primary' : 'ghost'} sm" dir="ltr" data-act="wxunit" data-u="c" aria-pressed="${st.tempUnit === 'c'}">°C</button><button class="btn ${st.tempUnit === 'f' ? 'primary' : 'ghost'} sm" dir="ltr" data-act="wxunit" data-u="f" aria-pressed="${st.tempUnit === 'f'}">°F</button></div>
      <button class="btn ghost sm" data-act="wxrefreshall">↻ ${esc(t('wxRefresh'))}</button></div>
      ${!st.online ? `<p class="notice">${esc(t('wxNeed'))} <button class="btn primary sm" data-act="enableonline">${esc(t('hEnable'))}</button></p>` : ''}
      ${ps.length ? `<div class="wxgrid" id="wxList">${ps.map(p => EP.wx.card(p, st.wx[p.id])).join('')}</div>` : `<p class="empty">${esc(t('wxNone'))}</p>`}`;
  }
  async function hydrateWeatherList(force) {
    const ps = weatherPlaces();
    await Promise.all(ps.map(async p => { const w = await EP.wx.load(p, force); const el = document.getElementById('wxc-' + p.id); if (el && w) el.outerHTML = EP.wx.card(p, w); }));
  }
  function diffText(tz) {
    const dev = -new Date().getTimezoneOffset(), diff = fmt.offsetMin(tz) - dev;
    if (!diff) return t('clSame');
    const h = Math.abs(diff) / 60, hs = fmt.num(Math.round(h * 10) / 10);
    return t(diff > 0 ? 'clAhead' : 'clBehind', { h: hs });
  }
  function infoTab(p) {
    const st = S.get(), cc = EP.countries[p.cc];
    const map = st.online
      ? `<iframe class="osm" title="${esc(p.name)}" loading="lazy" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin" src="https://www.openstreetmap.org/export/embed.html?bbox=${p.lon - 0.06}%2C${p.lat - 0.035}%2C${p.lon + 0.06}%2C${p.lat + 0.035}&amp;layer=mapnik&amp;marker=${p.lat}%2C${p.lon}"></iframe>
         <p class="muted small">${esc(t('mapAttr'))} · <a href="${esc(API.links.osm(p))}" target="_blank" rel="noopener noreferrer">${esc(t('viewMap'))} ↗</a></p>`
      : `<p class="muted">${esc(t('mapNeed'))}</p>`;
    return `<div class="clockcard card"><div class="bigclock" data-clock="${esc(p.tz)}" aria-label="${esc(t('localTime'))}">${esc(fmt.clock(p.tz))}</div><div data-cdate="${esc(p.tz)}">${esc(fmt.longDate(p.tz))}</div>
        <small class="muted">${esc(p.tz)} · ${esc(diffText(p.tz))} · ${esc(t('clGreg'))}</small></div>
      <dl class="facts">${cc ? `<div><dt>${esc(t('currencyLbl'))}</dt><dd>${esc(cc.cur)} · ${esc(fmt.currency(cc.cur))}</dd></div><div><dt>${esc(t('speaks'))}</dt><dd>${esc(cc.langs.map(fmt.language).join(', '))}</dd></div>` : ''}
        ${p.pop ? `<div><dt>👥</dt><dd>${esc(fmt.num(p.pop))}</dd></div>` : ''}</dl>
      <section><h2>${esc(t('weather'))}</h2>${st.online ? `<div id="wxbox">${EP.wx.card(p, st.wx[p.id], { link: false })}</div><p><a class="btn ghost" href="#/place/${pid(p)}/wx">${esc(t('wxOpen'))} →</a></p>` : `<p class="notice">${esc(t('wxNeed'))} <button class="btn primary sm" data-act="enableonline">${esc(t('hEnable'))}</button></p>`}</section>
      <section><h2>${esc(t('pSights'))} · ${esc(t('pFood'))} · ${esc(t('pStay'))}</h2><div class="row2">${['wx', 'sights', 'food', 'stay', 'go'].map(k => `<a class="btn ghost" href="#/place/${pid(p)}/${k}">${esc(t(PTKEY[k]))} →</a>`).join('')}</div></section>
      <section><h2>${esc(t('mapTitle'))}</h2>${map}</section>
      <section><h2>${esc(t('emergencyLbl'))}</h2>${emergencyBlock(p.cc)}</section>`;
  }

  // ---------- places of interest tabs ----------
  function poiTab(p, kind) {
    let s = poiS[kind];
    if (!s || s.pid !== p.id) s = poiS[kind] = { pid: p.id, radius: POI_DEFAULT[kind], q: '', sort: 'rel', type: 'any', cls: 'any', wheel: false, site: false, hours: false, free: false, veg: false, vegan: false, shown: 30, items: null, status: 'idle' };
    const chk = (k, label) => `<label class="check"><input type="checkbox" data-pf="${k}"${s[k] ? ' checked' : ''}> <span>${esc(t(label))}</span></label>`;
    const radii = [1000, 2000, 3000, 5000, 10000, 20000];
    const sorts = kind === 'stay' ? [['rel', 'sRel'], ['dist', 'sDist'], ['name', 'sName'], ['stars', 'sStars']] : [['rel', 'sRel'], ['dist', 'sDist'], ['name', 'sName']];
    const extra = kind === 'stay' ? stayForm(p) : kind === 'food' ? `<p><a class="btn ghost" href="${esc(API.links.tables(p.name))}" target="_blank" rel="noopener noreferrer">${esc(t('tableGo'))} ↗</a></p>` : `<p><a class="btn ghost" href="${esc(API.links.tours(p.name))}" target="_blank" rel="noopener noreferrer">${esc(t('gTours'))} ↗</a></p>`;
    return `${tabIntro(kind, kind === 'sights' ? 'shSights' : kind === 'food' ? 'shFood' : 'shStay')}${extra}<form class="card form" data-nofilter onsubmit="return false">
      <div class="row3">${field(t('fRadius'), `<select data-pf="radius">${radii.map(r => `<option value="${r}"${r === s.radius ? ' selected' : ''}>${esc(fmt.dist(r / 1000))}</option>`).join('')}</select>`)}
      ${field(t('fSort'), `<select data-pf="sort">${sorts.map(o => `<option value="${o[0]}"${o[0] === s.sort ? ' selected' : ''}>${esc(t(o[1]))}</option>`).join('')}</select>`)}
      ${field(t('oType'), `<select data-pf="type"><option value="any">${esc(t('fAny'))}</option>${KIND_TYPES[kind].map(k => `<option value="${k}"${k === s.type ? ' selected' : ''}>${esc(kindLabel(k))}</option>`).join('')}</select>`)}</div>
      ${field(t('search'), `<input type="search" data-pf="q" value="${esc(s.q)}" placeholder="${esc(t('fText'))}" autocomplete="off">`)}
      ${kind === 'stay' ? field(t('fClass'), `<select data-pf="cls">${[['any', 'fAny'], ['budget', 'fBudget'], ['mid', 'fMid'], ['up', 'fUp']].map(o => `<option value="${o[0]}"${o[0] === s.cls ? ' selected' : ''}>${esc(t(o[1]))}</option>`).join('')}</select>`) : ''}
      <div class="checks">${chk('wheel', 'fWheel')}${chk('site', 'fSite')}${kind !== 'stay' ? chk('hours', 'fHours') : ''}${kind === 'sights' ? chk('free', 'fFree') : ''}${kind === 'food' ? chk('veg', 'fVeg') + chk('vegan', 'fVegan') : ''}</div></form>
      <div id="poiOut" data-kind="${kind}"></div><p class="muted small">${esc(t('poiSrc'))} Photos: Wikipedia / Wikimedia Commons.</p>`;
  }
  function stayForm(p) {
    const tr = S.get().trips.find(x => x.status === 'active' && x.place && x.place.id === p.id) || {};
    return `<form class="card form" data-nofilter onsubmit="return false"><div class="row3">${field(t('stayIn'), `<input type="date" id="stIn" value="${esc(tr.startDate || '')}">`)}${field(t('stayOut'), `<input type="date" id="stOut" value="${esc(tr.endDate || '')}">`)}${field(t('stayAd'), `<input type="number" id="stAd" min="1" max="20" value="${esc(tr.travelers || 2)}">`)}</div>
      <button type="button" class="btn primary" data-act="booking" data-id="${esc(p.id)}">${esc(t('stayGo'))} ↗</button><p class="muted small">${esc(t('linksNote'))}</p></form>`;
  }
  function applyFilters(kind, items, f) {
    let a = items.filter(x => {
      if (f.type !== 'any' && x.kind !== f.type) return false;
      if (f.q && !EP.norm(x.name + ' ' + x.cuisine).includes(EP.norm(f.q))) return false;
      if (f.wheel && !x.wheelchair) return false;
      if (f.site && !x.site) return false;
      if (f.hours && !x.hours) return false;
      if (f.free && x.fee !== 'no') return false;
      if (f.veg && !x.veg) return false;
      if (f.vegan && !x.vegan) return false;
      if (kind === 'stay' && f.cls !== 'any') {
        if (f.cls === 'budget' && !((x.stars && x.stars <= 2) || x.kind === 'hostel')) return false;
        if (f.cls === 'mid' && x.stars !== 3) return false;
        if (f.cls === 'up' && !(x.stars && x.stars >= 4)) return false;
      }
      return true;
    });
    const by = { dist: (a, b) => a.dist - b.dist, name: (a, b) => a.name.localeCompare(b.name, EP.lang), stars: (a, b) => (b.stars || 0) - (a.stars || 0) || a.dist - b.dist, rel: (a, b) => (b.notable - a.notable) || a.dist - b.dist };
    return a.sort(by[f.sort] || by.rel);
  }
  function poiCard(x, kind) {
    const chips = [];
    if (x.notable) chips.push(`<li class="chip star">★ ${esc(t('notable'))}</li>`);
    if (kind === 'sights') chips.push(x.fee === 'no' ? `<li class="chip ok">${esc(t('freeEntry'))}</li>` : x.fee === 'yes' ? `<li class="chip">${esc(t('paidEntry'))}</li>` : '');
    if (x.wheelchair) chips.push(`<li class="chip" title="${esc(t('fWheel'))}">♿ ${esc(t('fWheel'))}</li>`);
    if (x.vegan) chips.push(`<li class="chip">${esc(t('fVegan'))}</li>`); else if (x.veg) chips.push(`<li class="chip">${esc(t('fVeg'))}</li>`);
    const meta = [kindLabel(x.kind), x.cuisine && x.cuisine.replace(/[;_]/g, ', '), x.stars ? t('starsN', { n: fmt.num(x.stars) }) : ''].filter(Boolean).join(' · ');
    return `<li class="poi"><div class="thumb"${x.wiki ? ` data-wl="${esc(x.wiki.lang)}" data-wt="${esc(x.wiki.title)}"` : ''}>${EP.art(kind)}</div><div class="poi-main"><strong>${esc(x.name)}</strong><small>${esc(meta)}</small><small>${esc(t('away', { d: fmt.dist(x.dist) }))}${x.addr ? ' · ' + esc(x.addr) : ''}</small>
      ${chips.length ? `<ul class="chips">${chips.join('')}</ul>` : ''}${x.hours ? `<small class="muted">${esc(t('hoursLbl'))}: ${esc(x.hours)}</small>` : ''}${kind === 'stay' ? `<small class="muted">${esc(t('priceCheck'))}</small>` : ''}</div>
      <div class="poi-actions"><button class="btn primary sm" data-act="poiadd" data-kind="${kind}" data-id="${esc(x.id)}">＋ ${esc(t('addTrip'))}</button><button class="btn ghost sm" data-act="poishort" data-kind="${kind}" data-id="${esc(x.id)}">${esc(t('toShort'))}</button>
      <a class="btn ghost sm" href="${esc(API.links.dir(x))}" target="_blank" rel="noopener noreferrer">${esc(t('dirs'))} ↗</a>${x.site ? `<a class="btn ghost sm" href="${esc(x.site)}" target="_blank" rel="noopener noreferrer">${esc(t('site'))} ↗</a>` : ''}${x.phone ? `<a class="btn ghost sm" href="tel:${esc(x.phone.replace(/[^\d+]/g, ''))}">${esc(t('callIt'))}</a>` : ''}</div></li>`;
  }
  function paintPoi(kind) {
    const out = $('#poiOut'); const s = poiS[kind]; if (!out || !s || out.dataset.kind !== kind) return;
    if (s.status === 'need') { out.innerHTML = `<p class="notice">${esc(t('poiNeed'))} <button class="btn primary sm" data-act="enableonline">${esc(t('hEnable'))}</button></p>`; return; }
    if (s.status === 'loading') { out.innerHTML = `<p class="muted" role="status">${esc(t('poiLoad'))}</p>`; return; }
    if (s.status === 'error') { out.innerHTML = `<p class="error" role="alert">${esc(t('poiFail'))}</p><button class="btn ghost" data-act="poireload" data-kind="${kind}">↻</button>`; return; }
    const list = applyFilters(kind, s.items || [], s);
    setTimeout(hydrateThumbs, 0);
    out.innerHTML = list.length ? `<p class="muted small" role="status">${esc(fmt.num(list.length))}</p><ul class="poilist">${list.slice(0, s.shown).map(x => poiCard(x, kind)).join('')}</ul>${list.length > s.shown ? `<button class="btn ghost" data-act="poimore" data-kind="${kind}">${esc(t('more'))}</button>` : ''}` : `<p class="empty">${esc(t('poiNone'))}</p>`;
  }
  async function hydrateThumbs() {
    const queue = $$('#poiOut .thumb[data-wl]:not([data-done])').slice(0, 24);
    const run = async () => {
      while (queue.length) {
        const el = queue.shift(); el.dataset.done = '1';
        const r = await API.poiPhoto({ lang: el.dataset.wl, title: el.dataset.wt });
        if (r && el.isConnected) { el.innerHTML = `<img src="${esc(r.src)}" alt="" loading="lazy" referrerpolicy="no-referrer">`; el.classList.add('photo'); }
      }
    };
    await Promise.all([run(), run(), run(), run()]);
  }
  async function loadCityPhoto(p) {
    if (heroCache[p.id] || !S.get().online) return;
    const r = await API.cityPhoto(p);
    if (!r) return;
    heroCache[p.id] = r;
    const hero = $('#phero'), bg = hero && $('.phbg', hero);
    if (bg && location.hash.indexOf(pid(p)) > -1) { bg.innerHTML = `<img src="${esc(r.src)}" alt="">`; $('#phcredit').innerHTML = r.page ? `Photo: <a href="${esc(r.page)}" target="_blank" rel="noopener noreferrer">Wikipedia</a>` : ''; }
  }
  async function loadPoi(kind, p) {
    const s = poiS[kind]; if (!s) return;
    if (!S.get().online) { s.status = 'need'; return paintPoi(kind); }
    if (s.items && s.loadedRadius === s.radius) { s.status = 'ready'; return paintPoi(kind); }
    s.status = 'loading'; paintPoi(kind);
    const radius = s.radius;
    try { const items = await API.poi(kind, p, radius); if (poiS[kind] !== s) return; s.items = items; s.loadedRadius = radius; s.status = 'ready'; }
    catch (e) { if (poiS[kind] !== s) return; s.status = 'error'; }
    paintPoi(kind);
  }

  // ---------- getting there ----------
  function goTab(p) {
    const st = S.get(), tr = st.trips.find(x => x.status === 'active' && x.place && x.place.id === p.id);
    const date = go.date || (tr ? tr.startDate : '');
    let body = `<p class="muted">${esc(t('gPick'))}</p>`;
    if (go.from) {
      const f = go.from, km = API.haversine(f, p);
      const modes = [['flight', 'gFlight', km >= 150], ['train', 'gTrain', km <= 2500], ['bus', 'gBus', km <= 2500], ['car', 'gCar', km <= 3500]].filter(m => m[2]);
      body = `<dl class="facts"><div><dt>${esc(t('gDist'))}</dt><dd>${esc(fmt.dist(km))}</dd></div>${modes.map(m => `<div><dt>${esc(t(m[1]))}</dt><dd>≈ ${esc(fmt.hm(API.estimate(m[0], km)))}</dd></div>`).join('')}</dl>
        <p class="muted small">${esc(t('gEstNote'))}</p>
        <h2>${esc(t('gLinks'))}</h2><ul class="links"><li><a class="btn ghost" href="${esc(API.links.rome2rio(f.name, p.name))}" target="_blank" rel="noopener noreferrer">${esc(t('gRome'))} ↗</a></li>
        <li><a class="btn ghost" href="${esc(API.links.flights(f.name, p.name, date))}" target="_blank" rel="noopener noreferrer">${esc(t('gFlights'))} ↗</a></li>
        <li><a class="btn ghost" href="${esc(API.links.trains())}" target="_blank" rel="noopener noreferrer">${esc(t('gTrains'))} ↗</a></li>
        <li><a class="btn ghost" href="${esc(API.links.buses())}" target="_blank" rel="noopener noreferrer">${esc(t('gBuses'))} ↗</a></li></ul><p class="muted small">${esc(t('linksNote'))}</p>`;
    }
    return `${tabIntro('go', 'shGo')}<form class="card form" data-nofilter onsubmit="return false"><div class="row2">${field(t('gFrom'), searchBox('go', '', t('searchPh2'), go.from ? go.from.name : ''))}${field(t('gDate'), `<input type="date" id="goDate" value="${esc(date)}">`)}</div></form>${body}
      <h2>${esc(t('gAir'))}</h2><div id="airOut" class="muted">${esc(t('hBusy'))}</div>
      <h2>${esc(t('gSta'))}</h2><div id="staOut" class="muted">${esc(t('hBusy'))}</div><p class="muted small">${esc(t('poiSrc'))}</p>`;
  }
  async function loadTransportLists(p) {
    const a = $('#airOut'), s = $('#staOut'); if (!a || !s) return;
    if (!S.get().online) { a.innerHTML = s.innerHTML = `<p class="notice">${esc(t('poiNeed'))} <button class="btn primary sm" data-act="enableonline">${esc(t('hEnable'))}</button></p>`; return; }
    try {
      const air = await API.airports(p);
      if ($('#airOut')) $('#airOut').innerHTML = air.length ? `<ul class="ledger">${air.map(x => `<li><span><strong>${esc(x.name)}</strong><small>${esc(t('away', { d: fmt.dist(x.dist) }))}</small></span><span class="chip">${esc(x.iata)}</span></li>`).join('')}</ul>` : `<p class="muted">${esc(t('gNoAir'))}</p>`;
    } catch (e) { if ($('#airOut')) $('#airOut').innerHTML = `<p class="error">${esc(t('poiFail'))}</p>`; }
    try {
      const sta = await API.stations(p);
      const row = x => `<li><span><strong>${esc(x.name)}</strong><small>${esc(t('away', { d: fmt.dist(x.dist) }))}</small></span><a class="btn ghost sm" href="${esc(API.links.dir(x))}" target="_blank" rel="noopener noreferrer">${esc(t('dirs'))} ↗</a></li>`;
      const tr = sta.filter(x => x.type === 'train').slice(0, 6), bu = sta.filter(x => x.type === 'bus').slice(0, 6);
      if ($('#staOut')) $('#staOut').innerHTML = `<h3>${esc(t('gTrainSt'))}</h3><ul class="ledger">${tr.map(row).join('') || '<li class="muted">–</li>'}</ul><h3>${esc(t('gBusSt'))}</h3><ul class="ledger">${bu.map(row).join('') || '<li class="muted">–</li>'}</ul>`;
    } catch (e) { if ($('#staOut')) $('#staOut').innerHTML = `<p class="error">${esc(t('poiFail'))}</p>`; }
  }

  // ---------- trips ----------
  function tripsView() {
    const st = S.get();
    const act = st.trips.filter(x => x.status === 'active').sort((a, b) => a.startDate.localeCompare(b.startDate));
    const arc = st.trips.filter(x => x.status === 'archived');
    const lim = S.canAddTrip();
    const d = Object.assign({}, draft); draft.destination = ''; draft.place = '';
    const pl = d.place ? JSON.parse(d.place) : null;
    return `${sectionHead('trips', t('tTitle'), t('shTrips'))}
      ${act.length ? `<h2>${esc(t('tActive'))}</h2><div class="stack">${act.map(tripCard).join('')}</div>` : `<p class="empty">${esc(t('tNone'))}</p>`}
      ${arc.length ? `<h2>${esc(t('tArchived'))}</h2><div class="stack">${arc.map(tripCard).join('')}</div>` : ''}
      <h2>${esc(t('tNew'))}</h2>
      ${lim ? `<form class="card form" data-form="trip">
        ${field(t('tName'), `<input name="title" required maxlength="120" value="${esc(d.destination)}">`)}
        ${field(t('tPlace'), searchBox('pick', 'destination', t('searchPh2'), pl ? pl.name : d.destination, d.place))}
        <div class="row2">${field(t('tStart'), '<input name="start" type="date" required>')}${field(t('tEnd'), '<input name="end" type="date" required>')}</div>
        <div class="row2">${field(t('tTrav'), '<input name="travelers" type="number" min="1" max="50" value="1" inputmode="numeric">')}${field(t('tBudget') + ' (' + t('optional') + ')', '<input name="budget" type="number" min="0" step="0.01" inputmode="decimal">')}</div>
        ${field(t('tCur'), `<select name="currency">${curOptions(pl && EP.countries[pl.cc] ? EP.countries[pl.cc].cur : st.currency)}</select>`)}
        <button class="btn primary">${esc(t('tCreate'))}</button></form>`
        : `<div class="card"><p>${esc(t('tLimit', { n: S.limits().trips }))}</p><a class="btn primary" href="#/more/plans">${esc(t('upgrade'))}</a></div>`}`;
  }
  const TABS = ['itin', 'cal', 'opts', 'budget', 'docs', 'pack', 'export'];
  const TABKEY = { itin: 'kItin', cal: 'kCal', opts: 'kOpts', budget: 'kBudget', docs: 'kDocs', pack: 'kPack', export: 'kExport' };

  function tripView(id, tab) {
    const x = S.trip(id); if (!x) return notFound();
    tab = TABS.includes(tab) ? tab : 'itin';
    const nav = `<nav class="subtabs" aria-label="${esc(x.title)}">${TABS.map(k => `<a href="#/trip/${id}/${k}"${k === tab ? ' aria-current="page"' : ''}>${esc(t(TABKEY[k]))}</a>`).join('')}</nav>`;
    const pl = x.place;
    return `<a class="back" href="#/trips">${esc(t('nTrips'))}</a><h1>${esc(x.title)}</h1><p class="muted">${pl ? `<a href="#/place/${pid(pl)}">${esc(pl.name)}</a>` : esc(x.destination)} · ${esc(fmt.date(x.startDate))} – ${esc(fmt.date(x.endDate))}</p>${nav}${tripTab(x, tab)}
      <details class="card"><summary>${esc(t('tEdit'))}</summary><form class="form" data-form="tripedit" data-id="${x.id}">
        ${field(t('tName'), `<input name="title" required maxlength="120" value="${esc(x.title)}">`)}
        ${field(t('tPlace'), searchBox('pick', 'destination', t('searchPh2'), pl ? pl.name : x.destination, pl ? JSON.stringify(pl) : ''))}
        <div class="row2">${field(t('tStart'), `<input name="start" type="date" required value="${x.startDate}">`)}${field(t('tEnd'), `<input name="end" type="date" required value="${x.endDate}">`)}</div>
        <div class="row2">${field(t('tBudget'), `<input name="budget" type="number" min="0" step="0.01" value="${x.budget === null ? '' : x.budget}">`)}${field(t('tCur'), `<select name="currency">${curOptions(x.currency)}</select>`)}</div>
        <div class="row2"><button class="btn primary">${esc(t('save'))}</button>
        <button type="button" class="btn ghost" data-act="archive" data-id="${x.id}">${esc(x.status === 'active' ? t('tArchive') : t('tRestore'))}</button>
        <button type="button" class="btn danger" data-act="deltrip" data-id="${x.id}">${esc(t('del'))}</button></div></form></details>`;
  }
  function tripTab(x, tab) {
    const A = { itin: ['trips', 'shTrips'], cal: ['cal', 'shCal'], opts: ['opts', 'shOpts'], budget: ['budget', 'shBudget'], docs: ['docs', 'shDocs'], pack: ['pack', 'shPack'], export: ['exp', 'shExp'] }[tab];
    const body = tab === 'itin' ? itinTab(x) : tab === 'cal' ? calTab(x) : tab === 'opts' ? optsTab(x) : tab === 'budget' ? budgetTab(x) : tab === 'docs' ? docsTab(x) : tab === 'pack' ? packTab(x) : exportTab(x);
    return tabIntro(A[0], A[1]) + body;
  }

  const KIND = { activity: 'kActivity', transport: 'kTransport', stay: 'kStay', meal: 'kMeal' };
  function itinTab(x) {
    const days = {};
    x.items.slice().sort((a, b) => (a.day + a.time).localeCompare(b.day + b.time)).forEach(i => (days[i.day] = days[i.day] || []).push(i));
    const route = Object.keys(days).length ? `<ol class="route">${Object.keys(days).map(d => `<li><h3>${esc(fmt.weekday(d))} ${EP.wx.badge(x.place, d)}</h3><ul>${days[d].map(i => `<li><span class="time">${esc(i.time)}</span><span class="what"><strong>${esc(i.title)}</strong><small>${esc(t(KIND[i.kind]))}${i.lat !== null && i.lon !== null ? ` · <a href="${esc(API.links.dir(i))}" target="_blank" rel="noopener noreferrer">${esc(t('dirs'))} ↗</a>` : ''}</small>${i.note ? `<small class="muted">${esc(i.note)}</small>` : ''}</span>${i.cost !== null ? `<button class="chip ${i.confirmed ? 'ok' : ''}" data-act="toggleconf" data-trip="${x.id}" data-id="${i.id}" aria-label="${esc(i.confirmed ? t('iMarkEst') : t('iMarkConf'))}">${esc(fmt.money(i.cost, x.currency))} · ${esc(i.confirmed ? t('confirmedLbl') : t('estimate'))}</button>` : ''}<button class="btn ghost sm" data-act="edititem" data-trip="${x.id}" data-id="${i.id}" aria-label="${esc(t('eEdit'))}: ${esc(i.title)}">✎</button><button class="btn ghost sm" data-act="delitem" data-trip="${x.id}" data-id="${i.id}" aria-label="${esc(t('del'))}: ${esc(i.title)}">✕</button></li>`).join('')}</ul></li>`).join('')}</ol>` : `<p class="empty">${esc(t('iNone'))}</p>`;
    const dayDefault = x.startDate <= today() && today() <= x.endDate ? today() : x.startDate;
    return `<form class="card form" data-form="item" data-id="${x.id}">
      <div class="row2">${field(t('iDay'), `<input name="day" type="date" required min="${x.startDate}" max="${x.endDate}" value="${dayDefault}">`)}${field(t('iTime') + ' (' + t('optional') + ')', '<input name="time" type="time">')}</div>
      ${field(t('iTitle'), '<input name="title" required maxlength="160">')}
      <div class="row2">${field(t('iKind'), `<select name="kind">${Object.keys(KIND).map(k => `<option value="${k}">${esc(t(KIND[k]))}</option>`).join('')}</select>`)}${field(t('iCost') + ' (' + x.currency + ', ' + t('estimate') + ')', '<input name="cost" type="number" min="0" step="0.01" inputmode="decimal">')}</div>
      <button class="btn primary">${esc(t('iAdd'))}</button></form>
      <details class="card"><summary>${esc(t('pdBtn'))}</summary><form class="form" data-form="planday" data-id="${x.id}"><div class="row2">${field(t('iDay'), `<input name="day" type="date" required min="${x.startDate}" max="${x.endDate}" value="${dayDefault}">`)}${field(t('pdStops'), '<input name="n" type="number" min="2" max="6" value="4">')}</div>
      <p class="muted small">${esc(t('pdNote'))}</p><button class="btn primary">${esc(t('pdMake'))}</button></form></details>${route}`;
  }

  // ---------- calendar ----------
  function calMarks(trips) {
    const m = {};
    trips.forEach(x => x.items.forEach(i => { m[i.day] = (m[i.day] || 0) + 1; }));
    return m;
  }
  function calHtml(trips) {
    const ws = S.get().weekStart, marks = calMarks(trips), now = today();
    const first = new Date(Date.UTC(cal.y, cal.m, 1)), lead = (first.getUTCDay() - ws + 7) % 7, n = new Date(Date.UTC(cal.y, cal.m + 1, 0)).getUTCDate();
    const dow = []; for (let i = 0; i < 7; i++) dow.push(`<span class="dow">${esc(fmt.dow(((ws + 6) % 7) + i))}</span>`);
    const cells = []; for (let i = 0; i < lead; i++) cells.push('<span></span>');
    for (let d = 1; d <= n; d++) {
      const iso = cal.y + '-' + String(cal.m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
      const inTrip = trips.some(x => iso >= x.startDate && iso <= x.endDate);
      cells.push(`<button type="button" class="day${inTrip ? ' intrip' : ''}${iso === now ? ' today' : ''}${iso === cal.sel ? ' sel' : ''}" data-act="calday" data-date="${iso}"${iso === cal.sel ? ' aria-pressed="true"' : ''}>${esc(fmt.num(d))}${marks[iso] ? '<i class="dotm"></i>' : ''}</button>`);
    }
    const items = []; trips.forEach(x => x.items.filter(i => i.day === cal.sel).forEach(i => items.push({ i, x })));
    items.sort((a, b) => a.i.time.localeCompare(b.i.time));
    const detail = cal.sel ? `<h3>${esc(fmt.date(cal.sel))}</h3>${items.length ? `<ul class="ledger">${items.map(o => `<li><span><strong>${esc((o.i.time ? o.i.time + ' ' : '') + o.i.title)}</strong><small>${esc(o.x.title)}</small></span></li>`).join('')}</ul>` : `<p class="muted">${esc(t('clNone'))}</p>`}` : '';
    return `<div class="card"><div class="calhead"><button class="btn ghost sm" data-act="calnav" data-d="-1" aria-label="${esc(t('clPrev'))}">‹</button><strong aria-live="polite">${esc(fmt.month(cal.y, cal.m))}</strong><button class="btn ghost sm" data-act="calnav" data-d="1" aria-label="${esc(t('clNext'))}">›</button></div>
      <div class="calgrid" role="group" aria-label="${esc(fmt.month(cal.y, cal.m))}">${dow.join('')}${cells.join('')}</div><p class="muted small">${esc(t('clGreg'))}</p></div>${detail}`;
  }
  function calInit(key, y, m) { if (cal.key !== key) { const d = new Date(); cal.key = key; cal.y = y !== undefined ? y : d.getFullYear(); cal.m = m !== undefined ? m : d.getMonth(); cal.sel = ''; } }
  function calTab(x) { calInit('trip' + x.id, +x.startDate.slice(0, 4), +x.startDate.slice(5, 7) - 1); return calHtml([x]); }

  // ---------- compare options (user-entered prices) ----------
  const OPT = { flight: 'dFlight', train: 'dTrain', hotel: 'dHotel', restaurant: 'dRest', attraction: 'kd_attraction', other: 'dOther' };
  function optsTab(x) {
    const rows = x.options.map(o => ({ o, v: o.price === null ? null : S.convert(o.price, o.currency, x.currency) }));
    const minN = optF.min === '' ? null : Number(optF.min), maxN = optF.max === '' ? null : Number(optF.max), filtering = minN !== null || maxN !== null;
    let hidden = 0;
    let list = rows.filter(r => {
      if (optF.type !== 'all' && r.o.type !== optF.type) return false;
      if (filtering) { if (r.v === null) { hidden++; return false; } if (minN !== null && r.v < minN) return false; if (maxN !== null && r.v > maxN) return false; }
      return true;
    });
    list.sort((a, b) => (a.v === null) - (b.v === null) || (optF.sort === 'asc' ? a.v - b.v : b.v - a.v));
    const lowest = list.find(r => r.v !== null);
    return `<p class="notice">${esc(t('oMine'))}</p>
      <form class="card form" data-form="option" data-id="${x.id}">
        <div class="row2">${field(t('oType'), `<select name="type">${Object.keys(OPT).map(k => `<option value="${k}">${esc(t(OPT[k]))}</option>`).join('')}</select>`)}${field(t('oName'), '<input name="name" required maxlength="120">')}</div>
        <div class="row3">${field(t('oPrice'), '<input name="price" type="number" min="0" step="0.01" inputmode="decimal">')}${field(t('tCur'), `<select name="currency">${curOptions(x.currency)}</select>`)}${field(t('oDate') + ' (' + t('optional') + ')', '<input name="date" type="date">')}</div>
        <div class="row2">${field(t('oLink') + ' (' + t('optional') + ')', '<input name="link" type="url" inputmode="url" maxlength="500">')}${field(t('oNote') + ' (' + t('optional') + ')', '<input name="note" maxlength="200">')}</div>
        <button class="btn primary">${esc(t('oAdd'))}</button></form>
      <div class="card form"><div class="row3">${field(t('oType'), `<select data-of="type"><option value="all">${esc(t('oAll'))}</option>${Object.keys(OPT).map(k => `<option value="${k}"${k === optF.type ? ' selected' : ''}>${esc(t(OPT[k]))}</option>`).join('')}</select>`)}
        ${field(t('oMin') + ' (' + x.currency + ')', `<input type="number" min="0" step="any" data-of="min" value="${esc(optF.min)}">`)}${field(t('oMax') + ' (' + x.currency + ')', `<input type="number" min="0" step="any" data-of="max" value="${esc(optF.max)}">`)}</div>
        ${field(t('oSort'), `<select data-of="sort"><option value="asc"${optF.sort === 'asc' ? ' selected' : ''}>${esc(t('oAsc'))}</option><option value="desc"${optF.sort === 'desc' ? ' selected' : ''}>${esc(t('oDesc'))}</option></select>`)}</div>
      ${hidden ? `<p class="muted small">${esc(t('oHidden', { n: hidden }))}</p>` : ''}
      ${list.length ? `<ul class="poilist">${list.map(r => `<li class="poi"><div class="poi-main"><strong>${esc(r.o.name)}</strong><small>${esc(t(OPT[r.o.type]))}${r.o.date ? ' · ' + esc(fmt.date(r.o.date)) : ''}${r.o.note ? ' · ' + esc(r.o.note) : ''}</small>
        <ul class="chips"><li class="chip">${r.o.price === null ? esc(t('oNoPrice')) : esc(fmt.money(r.o.price, r.o.currency))}${r.v !== null && r.o.currency !== x.currency ? ' ≈ ' + esc(fmt.money(r.v, x.currency)) : ''}</li>${lowest && r === lowest && list.filter(q => q.v !== null).length > 1 ? `<li class="chip ok">★ ${esc(t('sDist') && t('oAsc').split(':')[1] ? t('oAsc').split(':')[0] : '')}</li>` : ''}</ul></div>
        <div class="poi-actions"><button class="btn primary sm" data-act="opttoitin" data-trip="${x.id}" data-id="${r.o.id}">＋ ${esc(t('oToItin'))}</button>${r.o.link ? `<a class="btn ghost sm" href="${esc(r.o.link)}" target="_blank" rel="noopener noreferrer">${esc(t('oLink'))} ↗</a>` : ''}<button class="btn ghost sm" data-act="editopt" data-trip="${x.id}" data-id="${r.o.id}" aria-label="${esc(t('eEdit'))}">✎</button><button class="btn ghost sm" data-act="delopt" data-trip="${x.id}" data-id="${r.o.id}" aria-label="${esc(t('del'))}">✕</button></div></li>`).join('')}</ul>` : `<p class="empty">${esc(t('oNone'))}</p>`}`;
  }

  // ---------- budget ----------
  function totals(x) {
    const planned = sum(x.items.map(i => i.cost || 0));
    let spent = 0; const unconv = {};
    x.expenses.forEach(e => { const v = S.convert(e.amount, e.currency, x.currency); if (v === null) unconv[e.currency] = (unconv[e.currency] || 0) + e.amount; else spent += v; });
    return { planned, spent, unconv };
  }
  function budgetTab(x) {
    const T = totals(x), left = x.budget === null ? null : x.budget - T.spent;
    const un = Object.keys(T.unconv);
    return `<dl class="summary"><div><dt>${esc(t('bPlanned'))} (${esc(t('estimate'))})</dt><dd>${esc(fmt.money(T.planned, x.currency))}</dd></div>
      <div><dt>${esc(t('bSpent'))}</dt><dd>${esc(fmt.money(T.spent, x.currency))}</dd></div>
      ${left !== null ? `<div><dt>${esc(t('bLeft'))}</dt><dd class="${left < 0 ? 'neg' : ''}">${esc(fmt.money(left, x.currency))}</dd></div>` : ''}</dl>
      ${x.budget ? `<meter min="0" max="${x.budget}" value="${Math.min(T.spent, x.budget)}" aria-label="${esc(t('bSpent'))}"></meter>` : ''}
      ${left !== null && left < 0 ? `<p class="error" role="status">${esc(t('bOver'))}</p>` : ''}
      ${un.length ? `<p class="muted small">${esc(t('bUnconv'))} ${esc(un.map(c => fmt.money(T.unconv[c], c)).join(', '))}</p>` : ''}
      <p class="muted small">${esc(t('bRates'))}</p>
      <form class="card form" data-form="expense" data-id="${x.id}">
        <div class="row2">${field(t('bAmount'), '<input name="amount" type="number" min="0" step="0.01" required inputmode="decimal">')}${field(t('tCur'), `<select name="currency">${curOptions(x.currency)}</select>`)}</div>
        <div class="row2">${field(t('iDay'), `<input name="date" type="date" required value="${today()}">`)}${field(t('bCat'), '<input name="category" maxlength="40">')}</div>
        ${field(t('bNote') + ' (' + t('optional') + ')', '<input name="note" maxlength="200">')}
        <button class="btn primary">${esc(t('bAdd'))}</button></form>
      ${x.expenses.length ? `<ul class="ledger">${x.expenses.slice().sort((a, b) => b.date.localeCompare(a.date)).map(e => `<li><span>${esc(fmt.date(e.date))}${e.category ? ' · ' + esc(e.category) : ''}${e.note ? '<small>' + esc(e.note) + '</small>' : ''}</span><strong>${esc(fmt.money(e.amount, e.currency))}</strong><button class="btn ghost sm" data-act="editexp" data-trip="${x.id}" data-id="${e.id}" aria-label="${esc(t('eEdit'))}">✎</button><button class="btn ghost sm" data-act="delexp" data-trip="${x.id}" data-id="${e.id}" aria-label="${esc(t('del'))}">✕</button></li>`).join('')}</ul>` : `<p class="empty">${esc(t('bNone'))}</p>`}`;
  }

  const DOCT = { flight: 'dFlight', train: 'dTrain', hotel: 'dHotel', restaurant: 'dRest', ticket: 'dTicket', insurance: 'dIns', other: 'dOther' };
  function locked() { return `<div class="card"><p><strong>${esc(t('proOnly'))}</strong></p><a class="btn primary" href="#/more/plans">${esc(t('upgrade'))}</a></div>`; }
  function docsTab(x) {
    if (!S.isPro()) return locked();
    return `<p class="notice">${esc(t('dNotice'))}</p><form class="card form" data-form="doc" data-id="${x.id}">
      <div class="row2">${field(t('dType'), `<select name="type">${Object.keys(DOCT).map(k => `<option value="${k}">${esc(t(DOCT[k]))}</option>`).join('')}</select>`)}${field(t('dRef') + ' (' + t('optional') + ')', '<input name="ref" maxlength="60" autocomplete="off">')}</div>
      ${field(t('dTitle'), '<input name="title" required maxlength="120">')}${field(t('dLink'), '<input name="link" type="url" inputmode="url" maxlength="500">')}
      <button class="btn primary">${esc(t('dAdd'))}</button></form>
      ${x.docs.length ? `<ul class="ledger">${x.docs.map(d => `<li><span><strong>${esc(d.title)}</strong><small>${esc(t(DOCT[d.type]))}${d.ref ? ' · ' + esc(d.ref) : ''}</small>${d.link ? `<small><a href="${esc(d.link)}" target="_blank" rel="noopener noreferrer">${esc(d.link.replace(/^https?:\/\//, '').slice(0, 40))} ↗</a></small>` : ''}</span><button class="btn ghost sm" data-act="editdoc" data-trip="${x.id}" data-id="${d.id}" aria-label="${esc(t('eEdit'))}">✎</button><button class="btn ghost sm" data-act="deldoc" data-trip="${x.id}" data-id="${d.id}" aria-label="${esc(t('del'))}">✕</button></li>`).join('')}</ul>` : `<p class="empty">${esc(t('dNone'))}</p>`}`;
  }
  function packTab(x) {
    return `<form class="card form" data-form="pack" data-id="${x.id}"><div class="row2">${field(t('pAdd'), '<input name="text" required maxlength="120">')}<button class="btn primary">${esc(t('add'))}</button></div></form>
      <p><button class="btn ghost" data-act="packtpl" data-id="${x.id}">${esc(t('pTemplate'))}</button></p>
      ${x.packing.length ? `<ul class="checklist">${x.packing.map(p => `<li><label class="check"><input type="checkbox" data-act="packtick" data-trip="${x.id}" data-id="${p.id}"${p.done ? ' checked' : ''}> <span>${esc(p.text)}</span></label><button class="btn ghost sm" data-act="delpack" data-trip="${x.id}" data-id="${p.id}" aria-label="${esc(t('del'))}">✕</button></li>`).join('')}</ul>` : `<p class="empty">${esc(t('pNone'))}</p>`}`;
  }
  function exportTab(x) {
    if (!S.isPro()) return locked();
    return `<div class="card stack"><p class="muted">${esc(t('xNote'))}</p>
      <button class="btn primary" data-act="ics" data-id="${x.id}">${esc(t('xIcs'))}</button>
      <button class="btn ghost" data-act="print">${esc(t('xPrint'))}</button>
      <button class="btn ghost" data-act="share" data-id="${x.id}">${esc(t('xShare'))}</button></div>`;
  }

  // ---------- tools ----------
  function toolsView() {
    const st = S.get(), r = st.rates, has = Object.keys(r.map).length > 1;
    const lang = pb.lang || EP.lang, cc = pb.cc || (st.saved[0] && st.saved[0].cc && EP.countries[st.saved[0].cc] ? st.saved[0].cc : 'FR');
    const co = sel => EP.currencies.map(c => `<option value="${c}"${c === sel ? ' selected' : ''}>${c}</option>`).join('');
    const dev = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    const zones = [{ name: t('clDevice'), tz: dev }].concat(st.saved.slice(0, 8).map(p => ({ name: p.name, tz: p.tz })));
    calInit('all');
    return `${sectionHead('tools', t('nTools'), t('shTools'))}
      <section class="card" aria-labelledby="h-clk"><h2 id="h-clk">${esc(t('clWorld'))}</h2>
        <ul class="clocks">${zones.map(z => `<li><span><strong>${esc(z.name)}</strong><small class="muted" data-cdate="${esc(z.tz)}">${esc(fmt.longDate(z.tz))}</small></span><span class="bigclock sm" data-clock="${esc(z.tz)}">${esc(fmt.clock(z.tz))}</span></li>`).join('')}</ul>
        ${st.saved.length ? '' : `<p class="muted small">${esc(t('clSaveHint'))}</p>`}</section>
      <section aria-labelledby="h-cal"><h2 id="h-cal">${esc(t('clTitle'))}</h2>${calHtml(st.trips)}</section>
      <section class="card form" aria-labelledby="h-cv"><h2 id="h-cv">${esc(t('cvTitle'))}</h2>
        <div class="row3">${field(t('cvAmount'), '<input id="cvAmt" type="number" min="0" step="any" value="100" inputmode="decimal">')}${field(t('cvFrom'), `<select id="cvFrom">${co('EUR')}</select>`)}${field(t('cvTo'), `<select id="cvTo">${co(st.currency === 'EUR' ? 'USD' : st.currency)}</select>`)}</div>
        <p id="cvOut" class="big" aria-live="polite"></p>
        <p class="muted small" id="cvSrc">${has ? esc(t('cvSrc', { d: r.date || '' })) + (Object.keys(r.manual).length ? ' · ' + esc(t('cvManual')) : '') : esc(t('cvNone'))}</p>
        <button class="btn ghost" data-act="rates">${esc(t('cvUpdate'))}</button>
        <details><summary>${esc(t('cvSet'))}</summary><div class="row3">${field('1 EUR =', '<input id="mrVal" type="number" min="0" step="any" inputmode="decimal">')}${field(t('cvTo'), `<select id="mrCur">${co('USD')}</select>`)}<button class="btn primary" data-act="manualrate">${esc(t('cvSetBtn'))}</button></div></details></section>
      <section class="card" aria-labelledby="h-pb"><h2 id="h-pb">${esc(t('pbTitle'))}</h2>
        ${field(t('pbTo'), `<select id="pbLang">${Object.keys(EP.langs).map(k => `<option value="${k}"${k === lang ? ' selected' : ''}>${esc(EP.langs[k])}</option>`).join('')}</select>`)}
        <ul class="phrases">${EP.phrases.map((p, i) => `<li><span class="muted">${esc(p[EP.lang])}</span><strong lang="${lang}" dir="${EP.RTL.includes(lang) ? 'rtl' : 'ltr'}">${esc(p[lang])}</strong><button class="btn ghost sm" data-act="speak" data-i="${i}" aria-label="${esc(t('pbSpeak'))}: ${esc(p[lang])}">🔊</button></li>`).join('')}</ul></section>
      <section class="card" aria-labelledby="h-em"><h2 id="h-em">${esc(t('emTitle'))}</h2>
        ${field(t('emCountry'), `<select id="emCc">${Object.keys(EP.countries).sort((a, b) => fmt.country(a).localeCompare(fmt.country(b), EP.lang)).map(k => `<option value="${k}"${k === cc ? ' selected' : ''}>${esc(fmt.country(k))}</option>`).join('')}</select>`)}
        ${emergencyBlock(cc)}</section>`;
  }
  function updateConverter() {
    const out = $('#cvOut'); if (!out) return;
    const a = Number($('#cvAmt').value), f = $('#cvFrom').value, to = $('#cvTo').value;
    const v = isFinite(a) ? S.convert(a, f, to) : null;
    out.textContent = v === null ? t('cvNoRate') : fmt.money(a, f) + ' = ' + fmt.money(v, to);
  }
  async function fetchRates() {
    if (!S.get().online) return say(t('cvOnlineNeed'));
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 12000);
      const r = await fetch(CFG.services.rates, { cache: 'no-store', signal: ctl.signal }); clearTimeout(to);
      if (!r.ok) throw new Error(r.status);
      const j = await r.json(), map = { EUR: 1 };
      for (const k in j.rates) if (/^[A-Z]{3}$/.test(k) && Number(j.rates[k]) > 0) map[k] = Number(j.rates[k]);
      const st = S.get(), man = {};
      for (const k in st.rates.manual) if (!(k in j.rates) && st.rates.map[k]) { map[k] = st.rates.map[k]; man[k] = true; }
      st.rates = { date: String(j.date || '').slice(0, 10), map, manual: man }; S.save(); render();
    } catch (e) { say(t('cvFail')); }
  }
  // ---------- more ----------
  function moreView(sub) {
    const st = S.get();
    if (sub === 'plans') return plansView();
    if (sub === 'privacy') return legalView('lpTitle', 'lpP', EP.legal.privacy());
    if (sub === 'terms') return legalView('ltTitle', 'ltP', EP.legal.terms());
    if (sub === 'data') return dataView();
    if (sub === 'access') return `<a class="back" href="#/more">${esc(t('mTitle'))}</a><h1>${esc(t('yTitle'))}</h1><p>${esc(t('yText'))}</p>${CFG.supportEmail ? `<p><a class="btn ghost" href="mailto:${esc(CFG.supportEmail)}">${esc(t('mSupport'))}</a></p>` : ''}`;
    if (sub === 'about') return aboutView();
    return `${sectionHead('more', t('mTitle'), t('shMore'))}
      <div class="card form">${field(t('mLang'), `<select id="setLang">${Object.keys(EP.langs).map(k => `<option value="${k}"${k === EP.lang ? ' selected' : ''}>${esc(EP.langs[k])}</option>`).join('')}</select>`)}
        ${field(t('mCur'), `<select id="setCur">${curOptions(st.currency)}</select>`)}
        ${field(t('wxUnit'), `<select id="setUnit"><option value="c"${st.tempUnit === 'c' ? ' selected' : ''}>${esc(t('wxC'))}</option><option value="f"${st.tempUnit === 'f' ? ' selected' : ''}>${esc(t('wxF'))}</option></select>`)}
        ${field(t('clWeek'), `<select id="setWeek">${[[1, 'wMon'], [0, 'wSun'], [6, 'wSat']].map(o => `<option value="${o[0]}"${o[0] === st.weekStart ? ' selected' : ''}>${esc(t(o[1]))}</option>`).join('')}</select>`)}
        <label class="check switch"><input type="checkbox" id="setDigits"${st.digits === 'latn' ? ' checked' : ''}> <span>${esc(t('clDigits'))}</span></label>
        <label class="check switch"><input type="checkbox" id="setOnline"${st.online ? ' checked' : ''}> <span><strong>${esc(t('mOnline'))}</strong><small>${esc(t('mOnlineDesc'))}</small></span></label></div>
      <ul class="menu">${[['plans', 'mPlans'], ['privacy', 'mPrivacy'], ['terms', 'mTerms'], ['data', 'mData'], ['access', 'mAccess'], ['about', 'mAbout']].map(m => `<li><a href="#/more/${m[0]}">${esc(t(m[1]))}<span aria-hidden="true">›</span></a></li>`).join('')}
      ${CFG.supportEmail ? `<li><a href="mailto:${esc(CFG.supportEmail)}">${esc(t('mSupport'))}<span aria-hidden="true">›</span></a></li>` : ''}</ul>`;
  }
  function legalView(titleKey, pre, full) {
    return `<a class="back" href="#/more">${esc(t('mTitle'))}</a><h1>${esc(t(titleKey))}</h1><ul class="bul">${[1, 2, 3, 4, 5].map(i => `<li>${esc(t(pre + i))}</li>`).join('')}</ul>
      <details class="card legal"><summary>${esc(t('lFull'))}</summary><div lang="en" dir="ltr">${full}</div></details>${CFG.privacyUrl && pre === 'lpP' ? `<p><a href="${esc(CFG.privacyUrl)}" target="_blank" rel="noopener noreferrer">${esc(CFG.privacyUrl)}</a></p>` : ''}`;
  }
  function plansView() {
    const st = S.get(), P = [['FREE', 'plFree', 'plFreeF', '€0'], ['PRO', 'plPro', 'plProF', CFG.prices.PRO], ['TRAVEL_PLUS', 'plPlus', 'plPlusF', CFG.prices.TRAVEL_PLUS]];
    const card = p => {
      const cur = st.plan === p[0], url = CFG.checkout[p[0]];
      const feats = t(p[2], { n: CFG.free.saved }).split('|').map(f => `<li>${esc(f)}</li>`).join('');
      const cta = p[0] === 'FREE' ? '' : cur ? `<span class="chip ok">${esc(t('plCurrent'))}</span>` : url ? `<a class="btn primary" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(t('plBuy'))}</a>` : `<button class="btn ghost" disabled>${esc(t('plNA'))}</button>`;
      return `<article class="card plan${cur ? ' current' : ''}"><h2>${esc(t(p[1]))}</h2><p class="price">${esc(p[3])}${p[0] === 'FREE' ? '' : ' <small>' + esc(t('plPerMonth')) + '</small>'}</p>${p[0] === 'FREE' && cur ? `<span class="chip ok">${esc(t('plCurrent'))}</span>` : ''}<ul class="bul">${feats}</ul>${p[0] === 'TRAVEL_PLUS' ? `<p class="muted small">${esc(t('plSoon'))}</p>` : ''}${cta}</article>`;
    };
    return `<a class="back" href="#/more">${esc(t('mTitle'))}</a><h1>${esc(t('plTitle'))}</h1>${st.test ? `<p class="notice">${esc(t('plTest'))}</p>` : ''}
      <div class="plans">${P.map(card).join('')}</div><p class="muted small">${esc(t('plSoonList'))}</p>
      ${CFG.supportEmail ? `<p><a class="btn ghost" href="mailto:${esc(CFG.supportEmail)}?subject=${encodeURIComponent(CFG.appName + ' waitlist')}">${esc(t('plWaitlist'))}</a></p>` : ''}
      ${CFG.licenseEndpoint ? `<form class="card form" data-form="license">${field(t('plLicense'), '<input name="code" required maxlength="80" autocomplete="off">')}<button class="btn primary">${esc(t('plActivate'))}</button></form>` : ''}`;
  }
  function dataView() {
    return `<a class="back" href="#/more">${esc(t('mTitle'))}</a><h1>${esc(t('mData'))}</h1><p>${esc(t('dNote'))}</p>
      <div class="card stack"><button class="btn primary" data-act="export">${esc(t('dExport'))}</button>
      <label class="btn ghost filebtn">${esc(t('dImport'))}<input type="file" id="importFile" accept="application/json,.json" hidden></label>
      <button class="btn danger" data-act="wipe">${esc(t('dDelete'))}</button></div>`;
  }
  function aboutView() {
    return `<a class="back" href="#/more">${esc(t('mTitle'))}</a><h1>${esc(CFG.appName)}</h1><p class="muted">${esc(t('tagline'))}</p>
      <p><button class="linklike" data-act="devtap">${esc(t('aVersion'))} ${esc(CFG.version)}</button> · ${esc(CFG.buildDate)}</p>
      <h2>${esc(t('aCredits'))}</h2><ul class="bul"><li>Map and places data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a> (ODbL)</li>
      <li>City search and weather: <a href="https://open-meteo.com/" target="_blank" rel="noopener noreferrer">Open-Meteo.com</a> (CC BY 4.0; GeoNames)</li>
      <li>Exchange rates: ECB reference rates via <a href="https://frankfurter.dev/" target="_blank" rel="noopener noreferrer">Frankfurter</a></li></ul>`;
  }
  function consentView() {
    const opts = Object.keys(EP.langs).map(k => `<option value="${k}"${k === EP.lang ? ' selected' : ''}>${esc(EP.langs[k])}</option>`).join('');
    return `<section class="welcome"><h1>${esc(t('wTitle'))}</h1><p>${esc(t('wText'))}</p>
      <label>${esc(t('language'))}<select id="wLang">${opts}</select></label>
      <ul class="bul">${[1, 2, 3].map(i => `<li>${esc(t('wP' + i))}</li>`).join('')}</ul>
      <form data-form="consent" class="form"><label class="check"><input type="checkbox" name="ok" required> <span>${esc(t('wAccept'))} (<a href="#/more/terms">${esc(t('mTerms'))}</a>, <a href="#/more/privacy">${esc(t('mPrivacy'))}</a>)</span></label>
      <label class="check"><input type="checkbox" name="online"> <span>${esc(t('wOnline'))}</span></label>
      <button class="btn primary">${esc(t('wStart'))}</button></form></section>`;
  }
  function notFound() { return `<p class="empty">${esc(t('notFound'))}</p><a class="btn primary" href="#/">${esc(t('nHome'))}</a>`; }

  // ---------- router ----------
  function tickClocks() {
    $$('[data-clock]').forEach(el => { el.textContent = fmt.clock(el.dataset.clock); });
    $$('[data-cdate]').forEach(el => { const v = fmt.longDate(el.dataset.cdate); if (el.textContent !== v) el.textContent = v; });
  }
  function render() {
    const app = $('#app');
    const st = S.get();
    const p = (location.hash || '#/').slice(1).split('/').filter(Boolean);
    let html, tab = '#/', title = CFG.appName;
    if (!st.consentAt) { html = p[0] === 'more' && (p[1] === 'privacy' || p[1] === 'terms') ? moreView(p[1]) : consentView(); tab = ''; }
    else if (!p.length) html = homeView();
    else if (p[0] === 'place') { html = placeView(decodeURIComponent(p[1] || ''), p[2]); const pl = S.findPlace(decodeURIComponent(p[1] || '')); if (pl) title = pl.name + ' · ' + CFG.appName; }
    else if (p[0] === 'trips') { html = tripsView(); tab = '#/trips'; }
    else if (p[0] === 'trip') { html = tripView(p[1], p[2]); tab = '#/trips'; }
    else if (p[0] === 'weather') { html = weatherView(); tab = '#/weather'; }
    else if (p[0] === 'tools') { html = toolsView(); tab = '#/tools'; }
    else if (p[0] === 'more') { html = moreView(p[1]); tab = '#/more'; }
    else html = notFound();
    app.innerHTML = html;
    document.title = title;
    $$('#tabs a').forEach(a => { if (a.dataset.tab === tab) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    $('#tabs').hidden = !st.consentAt;
    if (!st.consentAt) return;
    if (p[0] === 'tools') updateConverter();
    if (p[0] === 'weather' && st.online) hydrateWeatherList(false);
    if (p[0] === 'trip') {
      const tr = S.trip(p[1]), hashNow = location.hash;
      if (tr && tr.place && st.online && (!p[2] || p[2] === 'itin')) { const had = !!st.wx[tr.place.id]; EP.wx.load(tr.place).then(w => { if (w && !had && location.hash === hashNow) render(); }); }
    }
    if (p[0] === 'place') {
      const pl = S.findPlace(decodeURIComponent(p[1] || ''));
      if (pl) {
        const tb = p[2] || 'info';
        loadCityPhoto(pl);
        if (tb === 'info') EP.wx.load(pl).then(w => { const b = $('#wxbox'); if (b && w && location.hash.indexOf(pid(pl)) > -1) b.innerHTML = EP.wx.card(pl, w, { link: false }); });
        else if (tb === 'wx') EP.wx.load(pl).then(w => { const b = $('#wxbox'); if (b && w && location.hash.indexOf(pid(pl)) > -1) b.innerHTML = wxFull(pl, w); });
        else if (['sights', 'food', 'stay'].includes(tb)) loadPoi(tb, pl);
        else if (tb === 'go') loadTransportLists(pl);
      }
    }
  }
  let lastKey = '';
  function onRoute() {
    const key = (location.hash || '#/').split('/').slice(0, 4).join('/');
    render();
    if (key !== lastKey) { window.scrollTo(0, 0); const a = $('#app'); a.focus({ preventScroll: true }); }
    lastKey = key;
  }

  // ---------- generic edit dialog ----------
  function editDialog(title, fields, v, validate) {
    return new Promise(res => {
      const d = $('#dlg3'), f = $('#dlg3form');
      $('#dlg3title').textContent = title;
      f.innerHTML = fields.map(fl => {
        const val = v[fl.name] == null ? '' : v[fl.name];
        if (fl.type === 'select') return field(fl.label, `<select name="${fl.name}">${fl.options.map(o => `<option value="${esc(o[0])}"${String(o[0]) === String(val) ? ' selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`);
        return field(fl.label, `<input name="${fl.name}" type="${fl.type || 'text'}" value="${esc(val)}" ${fl.attrs || ''}>`);
      }).join('') + `<p class="error" id="dlg3err" role="alert"></p><div class="row2"><button type="button" class="btn ghost" id="dlg3no">${esc(t('cancel'))}</button><button class="btn primary">${esc(t('save'))}</button></div>`;
      const done = out => { d.close(); f.onsubmit = null; d.oncancel = null; res(out); };
      $('#dlg3no', f).onclick = () => done(null); d.oncancel = () => done(null);
      f.onsubmit = e => { e.preventDefault(); const o = Object.fromEntries(new FormData(f)); const err = validate ? validate(o) : ''; if (err) { $('#dlg3err').textContent = err; return; } done(o); };
      d.showModal(); const first = $('input,select', f); if (first) first.focus();
    });
  }
  const confirmDel = () => ask(t('eDelAsk'), t('del'), true);

  // ---------- add-to-trip dialog ----------
  function chooseTrip(title, withDay, place) {
    return new Promise(res => {
      const trips = S.get().trips.filter(x => x.status === 'active');
      if (!trips.length) { say(t('atNone')); return res(null); }
      trips.sort((a, b) => ((b.place && place && b.place.id === place.id) - (a.place && place && a.place.id === place.id)) || a.startDate.localeCompare(b.startDate));
      const d = $('#dlg2'), f = $('#dlg2form');
      $('#dlg2title').textContent = title;
      f.innerHTML = `${field(t('atTrip'), `<select name="trip">${trips.map(x => `<option value="${x.id}">${esc(x.title)} · ${esc(fmt.date(x.startDate))}</option>`).join('')}</select>`)}
        ${withDay ? field(t('atDay'), `<input name="day" type="date" required value="${trips[0].startDate}">`) : ''}
        <div class="row2"><button type="button" class="btn ghost" id="dlg2no">${esc(t('cancel'))}</button><button class="btn primary">${esc(t('ok'))}</button></div><p class="error" id="dlg2err" role="alert"></p>`;
      const sel = $('select', f), day = $('input[name=day]', f);
      const sync = () => { const tr = S.trip(sel.value); if (day && tr) { day.min = tr.startDate; day.max = tr.endDate; if (day.value < tr.startDate || day.value > tr.endDate) day.value = tr.startDate; } };
      sel.onchange = sync; sync();
      const done = v => { d.close(); f.onsubmit = null; d.oncancel = null; res(v); };
      $('#dlg2no', f).onclick = () => done(null); d.oncancel = () => done(null);
      f.onsubmit = e => { e.preventDefault(); const tr = S.trip(sel.value); if (withDay && (day.value < tr.startDate || day.value > tr.endDate)) { $('#dlg2err').textContent = t('iDayErr'); return; } done({ trip: tr, day: day ? day.value : '' }); };
      d.showModal();
    });
  }
  const currentPlace = () => { const p = (location.hash || '').slice(1).split('/').filter(Boolean); return p[0] === 'place' ? S.findPlace(decodeURIComponent(p[1] || '')) : null; };

  // ---------- events ----------
  function curTripId(el) { return el.dataset.trip || el.dataset.id; }
  document.addEventListener('submit', async e => {
    const f = e.target.closest('form[data-form]'); if (!f) return;
    e.preventDefault();
    const d = new FormData(f), kind = f.dataset.form, st = S.get();
    const tr = f.dataset.id && S.trip(f.dataset.id);
    if (kind === 'consent') { st.consentAt = Date.now(); st.lang = EP.lang; st.online = d.get('online') === 'on'; S.save(); render(); return; }
    if (kind === 'trip') {
      if (!S.canAddTrip()) return say(t('tLimit', { n: S.limits().trips }));
      const s = d.get('start'), en = d.get('end');
      if (en < s) return say(t('tDateErr'));
      let place = null; try { place = d.get('place') ? JSON.parse(d.get('place')) : null; } catch (x) { place = null; }
      const nt = S.normTrip({ id: S.uid(), title: d.get('title'), destination: d.get('destination'), place, startDate: s, endDate: en, currency: d.get('currency'), travelers: d.get('travelers'), budget: d.get('budget'), status: 'active' });
      if (!nt) return say(t('tDateErr'));
      st.trips.push(nt); S.save(); location.hash = '#/trip/' + nt.id; return;
    }
    if (kind === 'license') {
      fetch(CFG.licenseEndpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code: d.get('code'), device: S.uid() }) })
        .then(r => r.json()).then(j => { if (['PRO', 'TRAVEL_PLUS'].includes(j.plan)) { st.plan = j.plan; st.test = false; S.save(); say(t('plActOk')); render(); } else say(t('plActFail')); })
        .catch(() => say(t('plActFail')));
      return;
    }
    if (!tr) return;
    if (kind === 'tripedit') {
      const s = d.get('start'), en = d.get('end'); if (en < s) return say(t('tDateErr'));
      let place = tr.place; try { place = d.get('place') ? JSON.parse(d.get('place')) : null; } catch (x) { /* keep */ }
      const nt = S.normTrip(Object.assign({}, tr, { title: d.get('title'), destination: d.get('destination'), place, startDate: s, endDate: en, budget: d.get('budget'), currency: d.get('currency') }));
      if (nt) { Object.assign(tr, nt); S.save(); render(); say(t('saved')); }
      return;
    }
    if (kind === 'item') {
      const day = d.get('day'); if (day < tr.startDate || day > tr.endDate) return say(t('iDayErr'));
      const n = S.normTrip(Object.assign({}, tr, { items: [{ id: S.uid(), day, time: d.get('time') || '', title: d.get('title'), kind: d.get('kind'), cost: d.get('cost'), confirmed: false }] })).items[0];
      if (n) { tr.items.push(n); S.save(); render(); }
      return;
    }
    if (kind === 'planday') {
      if (!tr.place) return say(t('pdNeedPlace'));
      if (!st.online) return say(t('poiNeed'));
      const n = Math.min(6, Math.max(2, Number(d.get('n')) || 4)), day = d.get('day');
      try {
        const items = await API.poi('sights', tr.place, 6000);
        const pool = items.slice().sort((a, b) => (b.notable - a.notable) || a.dist - b.dist).slice(0, Math.max(n * 3, 12)).slice(0, 12);
        const pick = pool.filter(x => x.notable).concat(pool.filter(x => !x.notable)).slice(0, n);
        if (!pick.length) return say(t('pdNoData'));
        pick.sort((a, b) => a.dist - b.dist);
        const ordered = API.orderByProximity(pick);
        ordered.forEach((x, i) => {
          const mins = 9 * 60 + 30 + i * 120, time = String(Math.floor(mins / 60)).padStart(2, '0') + ':' + String(mins % 60).padStart(2, '0');
          const walk = i ? (API.haversine(ordered[i - 1], x) * 1.3) / 4.5 : 0;
          const it = S.normTrip(Object.assign({}, tr, { items: [{ id: S.uid(), day, time, title: x.name, kind: 'activity', cost: null, lat: x.lat, lon: x.lon, note: i ? t('pdWalk', { d: fmt.hm(Math.max(5 / 60, Math.round(walk * 12) / 12)) }) : '' }] })).items[0];
          if (it) tr.items.push(it);
        });
        S.save(); say(t('pdDone')); render();
      } catch (x) { say(t('poiFail')); }
      return;
    }
    if (kind === 'option') {
      const n = S.normTrip(Object.assign({}, tr, { options: [{ id: S.uid(), type: d.get('type'), name: d.get('name'), price: d.get('price'), currency: d.get('currency'), date: d.get('date'), link: d.get('link'), note: d.get('note'), at: Date.now() }] })).options[0];
      if (n) { tr.options.push(n); S.save(); render(); }
      return;
    }
    if (kind === 'expense') {
      const n = S.normTrip(Object.assign({}, tr, { expenses: [{ id: S.uid(), amount: d.get('amount'), currency: d.get('currency'), category: d.get('category'), note: d.get('note'), date: d.get('date') }] })).expenses[0];
      if (n) { tr.expenses.push(n); S.save(); render(); }
      return;
    }
    if (kind === 'doc' && S.isPro()) {
      const n = S.normTrip(Object.assign({}, tr, { docs: [{ id: S.uid(), type: d.get('type'), title: d.get('title'), ref: d.get('ref'), link: d.get('link') }] })).docs[0];
      if (n) { tr.docs.push(n); S.save(); render(); }
      return;
    }
    if (kind === 'pack') { tr.packing.push({ id: S.uid(), text: String(d.get('text')).slice(0, 120), done: false }); S.save(); render(); }
  });
  document.addEventListener('submit', e => { if (e.target.id === 'searchForm') { e.preventDefault(); if (pickCache[0]) openPlace(pickCache[0]); } });

  function openPlace(p) { const np = S.normPlace(p); if (!np) return; S.remember(np); location.hash = '#/place/' + encodeURIComponent(np.id); }

  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b || b.tagName === 'INPUT') return;
    const act = b.dataset.act, st = S.get(), tr = S.trip(curTripId(b));
    if (act === 'enableonline') {
      st.online = true; S.save(); say(t('saved'));
      const q = $('[data-search]'); if (q && q.value.trim().length >= 2) runSearch(q); else render();
    }
    else if (act === 'openplace') openPlace(pickCache[Number(b.dataset.i)]);
    else if (act === 'gotoplace') { const p = S.findPlace(b.dataset.id); if (p) openPlace(p); }
    else if (act === 'pickplace') {
      const p = S.normPlace(pickCache[Number(b.dataset.i)]); if (!p) return;
      const w = b.closest('[data-searchwrap]'); $('[data-search]', w).value = p.name; $('input[name=place]', w).value = JSON.stringify(p); $('[data-list]', w).innerHTML = '';
      const sel = b.closest('form') && $('select[name=currency]', b.closest('form')); if (sel && EP.countries[p.cc] && b.closest('[data-form=trip]')) sel.value = EP.countries[p.cc].cur;
    }
    else if (act === 'pickfrom') { const p = S.normPlace(pickCache[Number(b.dataset.i)]); if (p) { go.from = p; render(); } }
    else if (act === 'plan') { const p = S.findPlace(b.dataset.id); if (p) { draft.destination = p.name; draft.place = JSON.stringify(p); location.hash = '#/trips'; } }
    else if (act === 'savecity') {
      const p = S.findPlace(b.dataset.id); if (!p) return;
      const i = st.saved.findIndex(x => x.id === p.id);
      if (i >= 0) st.saved.splice(i, 1); else if (S.canSavePlace()) st.saved.push(p); else return say(t('savedLimit', { n: S.limits().saved }));
      S.save(); render();
    }
    else if (act === 'booking') {
      const p = S.findPlace(b.dataset.id); if (!p) return;
      const u = API.links.hotels(p.name, $('#stIn').value, $('#stOut').value, Number($('#stAd').value) || 2, (EP.countries[p.cc] || {}).cur || st.currency);
      window.open(u, '_blank', 'noopener,noreferrer');
    }
    else if (act === 'poimore') { poiS[b.dataset.kind].shown += 30; paintPoi(b.dataset.kind); }
    else if (act === 'poireload') { const p = currentPlace(); if (p) { poiS[b.dataset.kind].items = null; loadPoi(b.dataset.kind, p); } }
    else if (act === 'poiadd' || act === 'poishort') {
      const kind = b.dataset.kind, s = poiS[kind], item = s && s.items && s.items.find(x => x.id === b.dataset.id), p = currentPlace(); if (!item) return;
      const r = await chooseTrip(t('atTitle', { n: item.name }), act === 'poiadd', p); if (!r) return;
      if (act === 'poiadd') {
        const n = S.normTrip(Object.assign({}, r.trip, { items: [{ id: S.uid(), day: r.day, time: '', title: item.name, kind: kind === 'food' ? 'meal' : kind === 'stay' ? 'stay' : 'activity', cost: null, lat: item.lat, lon: item.lon, note: item.addr }] })).items[0];
        if (n) { r.trip.items.push(n); S.save(); say(t('atDone')); }
      } else {
        const n = S.normTrip(Object.assign({}, r.trip, { options: [{ id: S.uid(), type: kind === 'food' ? 'restaurant' : kind === 'stay' ? 'hotel' : 'attraction', name: item.name, price: null, currency: r.trip.currency, link: item.site, note: '', at: Date.now() }] })).options[0];
        if (n) { r.trip.options.push(n); S.save(); say(t('stDone')); }
      }
    }
    else if (act === 'archive' && tr) { tr.status = tr.status === 'active' ? 'archived' : 'active'; if (tr.status === 'active' && S.activeTrips() > S.limits().trips) { tr.status = 'archived'; return say(t('tLimit', { n: S.limits().trips })); } S.save(); location.hash = '#/trips'; }
    else if (act === 'deltrip' && tr) { if (await ask(t('tDelConfirm'), t('del'), true)) { st.trips = st.trips.filter(x => x !== tr); S.save(); location.hash = '#/trips'; } }
    else if (act === 'delitem' && tr) { if (!(await confirmDel())) return; tr.items = tr.items.filter(i => i.id !== b.dataset.id); S.save(); say(t('eDeleted')); render(); }
    else if (act === 'toggleconf' && tr) { const i = tr.items.find(i => i.id === b.dataset.id); if (i) { i.confirmed = !i.confirmed; S.save(); render(); } }
    else if (act === 'delexp' && tr) { if (!(await confirmDel())) return; tr.expenses = tr.expenses.filter(i => i.id !== b.dataset.id); S.save(); say(t('eDeleted')); render(); }
    else if (act === 'deldoc' && tr) { if (!(await confirmDel())) return; tr.docs = tr.docs.filter(i => i.id !== b.dataset.id); S.save(); say(t('eDeleted')); render(); }
    else if (act === 'delopt' && tr) { if (!(await confirmDel())) return; tr.options = tr.options.filter(i => i.id !== b.dataset.id); S.save(); say(t('eDeleted')); render(); }
    else if (act === 'opttoitin' && tr) {
      const o = tr.options.find(i => i.id === b.dataset.id); if (!o) return;
      const day = o.date && o.date >= tr.startDate && o.date <= tr.endDate ? o.date : tr.startDate;
      const cost = o.price === null ? null : S.convert(o.price, o.currency, tr.currency);
      const kindMap = { flight: 'transport', train: 'transport', hotel: 'stay', restaurant: 'meal', attraction: 'activity', other: 'activity' };
      const n = S.normTrip(Object.assign({}, tr, { items: [{ id: S.uid(), day, time: '', title: o.name, kind: kindMap[o.type], cost: cost === null ? null : Math.round(cost * 100) / 100, confirmed: false }] })).items[0];
      if (n) { tr.items.push(n); S.save(); say(t('atDone')); }
    }
    else if (act === 'edititem' && tr) {
      const it = tr.items.find(i => i.id === b.dataset.id); if (!it) return;
      const o = await editDialog(t('eEdit'), [
        { name: 'day', label: t('iDay'), type: 'date', attrs: `required min="${tr.startDate}" max="${tr.endDate}"` }, { name: 'time', label: t('iTime'), type: 'time' },
        { name: 'title', label: t('iTitle'), attrs: 'required maxlength="160"' }, { name: 'kind', label: t('iKind'), type: 'select', options: Object.keys(KIND).map(k => [k, t(KIND[k])]) },
        { name: 'cost', label: t('iCost') + ' (' + tr.currency + ')', type: 'number', attrs: 'min="0" step="0.01"' }, { name: 'note', label: t('oNote'), attrs: 'maxlength="200"' }
      ], it, v => (v.day < tr.startDate || v.day > tr.endDate ? t('iDayErr') : ''));
      if (!o) return;
      const n = S.normTrip(Object.assign({}, tr, { items: [Object.assign({}, it, o)] })).items[0];
      if (n) { Object.assign(it, n, { id: it.id, confirmed: it.confirmed, lat: it.lat, lon: it.lon }); S.save(); say(t('eSaved')); render(); }
    }
    else if (act === 'editexp' && tr) {
      const ex = tr.expenses.find(i => i.id === b.dataset.id); if (!ex) return;
      const o = await editDialog(t('eEdit'), [
        { name: 'amount', label: t('bAmount'), type: 'number', attrs: 'required min="0" step="0.01"' }, { name: 'currency', label: t('tCur'), type: 'select', options: EP.currencies.map(c => [c, c]) },
        { name: 'date', label: t('iDay'), type: 'date', attrs: 'required' }, { name: 'category', label: t('bCat'), attrs: 'maxlength="40"' }, { name: 'note', label: t('bNote'), attrs: 'maxlength="200"' }
      ], ex);
      if (!o) return;
      const n = S.normTrip(Object.assign({}, tr, { expenses: [Object.assign({}, ex, o)] })).expenses[0];
      if (n) { Object.assign(ex, n, { id: ex.id }); S.save(); say(t('eSaved')); render(); }
    }
    else if (act === 'editopt' && tr) {
      const op = tr.options.find(i => i.id === b.dataset.id); if (!op) return;
      const o = await editDialog(t('eEdit'), [
        { name: 'type', label: t('oType'), type: 'select', options: Object.keys(OPT).map(k => [k, t(OPT[k])]) }, { name: 'name', label: t('oName'), attrs: 'required maxlength="120"' },
        { name: 'price', label: t('oPrice'), type: 'number', attrs: 'min="0" step="0.01"' }, { name: 'currency', label: t('tCur'), type: 'select', options: EP.currencies.map(c => [c, c]) },
        { name: 'date', label: t('oDate'), type: 'date' }, { name: 'link', label: t('oLink'), type: 'url', attrs: 'maxlength="500"' }, { name: 'note', label: t('oNote'), attrs: 'maxlength="200"' }
      ], op);
      if (!o) return;
      const n = S.normTrip(Object.assign({}, tr, { options: [Object.assign({}, op, o)] })).options[0];
      if (n) { Object.assign(op, n, { id: op.id }); S.save(); say(t('eSaved')); render(); }
    }
    else if (act === 'editdoc' && tr && S.isPro()) {
      const dc = tr.docs.find(i => i.id === b.dataset.id); if (!dc) return;
      const o = await editDialog(t('eEdit'), [
        { name: 'type', label: t('dType'), type: 'select', options: Object.keys(DOCT).map(k => [k, t(DOCT[k])]) }, { name: 'title', label: t('dTitle'), attrs: 'required maxlength="120"' },
        { name: 'ref', label: t('dRef'), attrs: 'maxlength="60" autocomplete="off"' }, { name: 'link', label: t('dLink'), type: 'url', attrs: 'maxlength="500"' }
      ], dc);
      if (!o) return;
      const n = S.normTrip(Object.assign({}, tr, { docs: [Object.assign({}, dc, o)] })).docs[0];
      if (n) { Object.assign(dc, n, { id: dc.id }); S.save(); say(t('eSaved')); render(); }
    }
    else if (act === 'wxunit') { st.tempUnit = b.dataset.u === 'f' ? 'f' : 'c'; S.save(); render(); }
    else if (act === 'wxmore') { wxShown = 16; const pl = currentPlace(); if (pl) { const bx = $('#wxbox'); if (bx) bx.innerHTML = wxFull(pl, st.wx[pl.id]); } }
    else if (act === 'wxrefresh') { const pl = S.findPlace(b.dataset.id); if (pl) { const w = await EP.wx.load(pl, true); const bx = $('#wxbox'); if (bx && w) bx.innerHTML = wxFull(pl, w); } }
    else if (act === 'wxrefreshall') { if (!st.online) return say(t('wxNeed')); hydrateWeatherList(true); }
    else if (act === 'delpack' && tr) { tr.packing = tr.packing.filter(i => i.id !== b.dataset.id); S.save(); render(); }
    else if (act === 'packtpl' && tr) { for (let i = 1; i <= 10; i++) tr.packing.push({ id: S.uid(), text: t('pack' + i), done: false }); S.save(); render(); }
    else if (act === 'calnav') { cal.m += Number(b.dataset.d); if (cal.m < 0) { cal.m = 11; cal.y--; } if (cal.m > 11) { cal.m = 0; cal.y++; } render(); }
    else if (act === 'calday') { cal.sel = cal.sel === b.dataset.date ? '' : b.dataset.date; render(); }
    else if (act === 'ics' && tr && S.isPro()) { if (!tr.items.length) return say(t('xEmpty')); download(tr.title.replace(/[^\w-]+/g, '_') + '.ics', 'text/calendar', buildIcs(tr)); }
    else if (act === 'print' && S.isPro()) window.print();
    else if (act === 'share' && tr && S.isPro()) {
      const text = summaryText(tr);
      if (navigator.share) navigator.share({ title: tr.title, text }).catch(() => {});
      else if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => say(t('copied')), () => say(text));
    }
    else if (act === 'rates') fetchRates();
    else if (act === 'manualrate') {
      const v = Number($('#mrVal').value), c = $('#mrCur').value;
      if (v > 0 && c !== 'EUR') { st.rates.map[c] = v; st.rates.manual[c] = true; if (!st.rates.date) st.rates.date = today(); S.save(); render(); say(t('saved')); }
    }
    else if (act === 'speak') {
      const lang = pb.lang || EP.lang, txt = EP.phrases[Number(b.dataset.i)][lang];
      if ('speechSynthesis' in window) { const u = new SpeechSynthesisUtterance(txt); u.lang = EP.speechLang[lang]; speechSynthesis.cancel(); speechSynthesis.speak(u); }
    }
    else if (act === 'export') download('europath-backup-' + today() + '.json', 'application/json', S.exportJson());
    else if (act === 'wipe') { if (await ask(t('dDelConfirm'), t('dDelete'), true)) { S.reset(); EP.digits = 'auto'; say(t('dDeleted')); setLang('en'); location.hash = '#/'; render(); } }
    else if (act === 'devtap') { if (++devTaps >= 7) { devTaps = 0; st.plan = 'PRO'; st.test = true; S.save(); say(t('aDev')); } }
  });

  document.addEventListener('change', e => {
    const el = e.target, st = S.get();
    if (el.id === 'brandLang' || el.id === 'setLang' || el.id === 'wLang') { setLang(el.value); st.lang = EP.lang; S.save(); render(); }
    else if (el.id === 'setCur') { st.currency = el.value; S.save(); }
    else if (el.id === 'setOnline') { st.online = el.checked; S.save(); }
    else if (el.id === 'setUnit') { st.tempUnit = el.value === 'f' ? 'f' : 'c'; S.save(); }
    else if (el.id === 'setWeek') { st.weekStart = Number(el.value); S.save(); }
    else if (el.id === 'setDigits') { st.digits = el.checked ? 'latn' : 'auto'; EP.digits = st.digits; S.save(); render(); }
    else if (el.id === 'pbLang') { pb.lang = el.value; render(); }
    else if (el.id === 'emCc') { pb.cc = el.value; render(); }
    else if (el.id === 'cvFrom' || el.id === 'cvTo') updateConverter();
    else if (el.id === 'goDate') { go.date = el.value; render(); }
    else if (el.dataset.of) { optF[el.dataset.of] = el.value; render(); }
    else if (el.dataset.pf) {
      const out = $('#poiOut'); if (!out) return; const kind = out.dataset.kind, s = poiS[kind], k = el.dataset.pf, p = currentPlace(); if (!s) return;
      if (k === 'radius') { s.radius = Number(el.value); s.items = null; if (p) loadPoi(kind, p); return; }
      s[k] = el.type === 'checkbox' ? el.checked : el.value; s.shown = 30; paintPoi(kind);
    }
    else if (el.id === 'importFile' && el.files[0]) {
      const fr = new FileReader();
      fr.onload = () => { try { const j = JSON.parse(String(fr.result).slice(0, 5e6)); if (!j || (j.app !== 'europath-pro' && !Array.isArray(j.trips))) throw 0; const cur = S.get(), keep = { consentAt: cur.consentAt, plan: cur.plan, test: cur.test }; S.replace(j); const n = S.get(); n.consentAt = keep.consentAt || n.consentAt; n.plan = keep.plan; n.test = keep.test; S.save(); EP.digits = n.digits; setLang(n.lang || EP.lang); say(t('dImpOk')); render(); } catch (err) { say(t('dImpBad')); } };
      fr.readAsText(el.files[0]);
    }
    else if (el.dataset && el.dataset.act === 'packtick') { const tr = S.trip(el.dataset.trip); const p = tr && tr.packing.find(x => x.id === el.dataset.id); if (p) { p.done = el.checked; S.save(); } }
  });
  document.addEventListener('input', e => {
    const el = e.target;
    if (el.matches && el.matches('[data-search]')) {
      const hid = $('input[name=place]', el.closest('[data-searchwrap]')); if (hid) hid.value = '';
      clearTimeout(el._t); el._t = setTimeout(() => runSearch(el), 350);
    } else if (el.dataset && el.dataset.pf === 'q') {
      const out = $('#poiOut'); if (!out) return; const s = poiS[out.dataset.kind]; if (!s) return;
      clearTimeout(el._t); el._t = setTimeout(() => { s.q = el.value; s.shown = 30; paintPoi(out.dataset.kind); }, 200);
    } else if (el.id === 'cvAmt') updateConverter();
  });

  // ---------- exports ----------
  function icsEsc(s) { return String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n'); }
  function fold(l) { const o = []; while (l.length > 73) { o.push(l.slice(0, 73)); l = ' ' + l.slice(73); } o.push(l); return o.join('\r\n'); }
  function buildIcs(tr) {
    const stamp = new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z';
    const ev = tr.items.map(i => {
      const d = i.day.replace(/-/g, '');
      let when;
      if (i.time) { const s = d + 'T' + i.time.replace(':', '') + '00'; const end = new Date(Date.UTC(+i.day.slice(0, 4), +i.day.slice(5, 7) - 1, +i.day.slice(8, 10), +i.time.slice(0, 2) + 1, +i.time.slice(3, 5))); const e = end.toISOString().replace(/[-:]/g, '').slice(0, 15); when = ['DTSTART:' + s, 'DTEND:' + e]; }
      else { const nx = new Date(Date.parse(i.day + 'T00:00:00Z') + 864e5).toISOString().slice(0, 10).replace(/-/g, ''); when = ['DTSTART;VALUE=DATE:' + d, 'DTEND;VALUE=DATE:' + nx]; }
      const geo = i.lat !== null && i.lon !== null ? ['GEO:' + i.lat + ';' + i.lon] : [];
      return ['BEGIN:VEVENT', 'UID:' + i.id + '@europath.app', 'DTSTAMP:' + stamp].concat(when, ['SUMMARY:' + icsEsc(i.title), 'DESCRIPTION:' + icsEsc(tr.title + (i.cost !== null ? ' · ' + fmt.money(i.cost, tr.currency) + (i.confirmed ? '' : ' (estimate)') : ''))], geo, ['END:VEVENT']).map(fold).join('\r\n');
    });
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//EuroPath Pro//EN', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:' + icsEsc(tr.title)].concat(ev, ['END:VCALENDAR']).join('\r\n') + '\r\n';
  }
  function summaryText(tr) {
    const days = {};
    tr.items.slice().sort((a, b) => (a.day + a.time).localeCompare(b.day + b.time)).forEach(i => (days[i.day] = days[i.day] || []).push(i));
    return tr.title + ' – ' + tr.destination + '\n' + fmt.date(tr.startDate) + ' – ' + fmt.date(tr.endDate) + '\n\n' + Object.keys(days).map(d => fmt.weekday(d) + '\n' + days[d].map(i => '  ' + (i.time ? i.time + ' ' : '') + i.title).join('\n')).join('\n\n');
  }

  // ---------- boot ----------
  const st0 = S.get();
  EP.digits = st0.digits;
  const nav = (navigator.language || 'en').slice(0, 2);
  setLang(st0.lang || (EP.S[nav] ? nav : 'en'));
  window.addEventListener('hashchange', onRoute);
  setInterval(tickClocks, 1000);
  onRoute();
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
})(window.EP);
