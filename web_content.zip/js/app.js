(function(){
'use strict';
var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var cfg={};try{cfg=JSON.parse($('#zcfg').textContent)}catch(e){}
var t0=Date.now();
var LNG=(document.documentElement.lang||'de').slice(0,2);
function store(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}}

/* ---------- theme / menu / language memory ---------- */
var tb=$('#theme');
if(tb)tb.addEventListener('click',function(){
  var cur=document.documentElement.getAttribute('data-theme');
  if(!cur)cur=(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches)?'dark':'light';
  var nx=cur==='dark'?'light':'dark';
  document.documentElement.setAttribute('data-theme',nx);store('z-theme',nx);
});
var mb=$('#menu'),mn=$('#mnav');
function menu(open){if(!mb||!mn)return;mb.setAttribute('aria-expanded',open?'true':'false');mn.setAttribute('data-open',open?'true':'false')}
if(mb)mb.addEventListener('click',function(){menu(mb.getAttribute('aria-expanded')!=='true')});
if(mn)mn.addEventListener('click',function(e){if(e.target.closest('a'))menu(false)});
document.addEventListener('keydown',function(e){if(e.key==='Escape')menu(false)});
$$('.langs a').forEach(function(a){a.addEventListener('click',function(){store('z-lang',a.getAttribute('data-lang'))})});
store('z-lang',document.documentElement.lang);

/* ---------- planner ---------- */
var pf=$('#planner-form');
var lastPlan=null;
function nf(n,o){try{return new Intl.NumberFormat(document.documentElement.lang,o||{}).format(n)}catch(e){return String(n)}}
if(pf&&cfg.plan){
  var P=cfg.plan,VOL=[6,12,22,32,46],CREW=[2,2,3,3,4];
  pf.addEventListener('submit',function(ev){
    ev.preventDefault();
    var i=Math.max(0,Math.min(4,parseInt(pf.size.value,10)||0));
    var fl=Math.max(0,Math.min(12,parseInt(pf.floors.value,10)||0));
    var lift=pf.lift.value==='yes';
    var d=Math.max(0,Math.min(1500,parseFloat(pf.dist.value)||0));
    var vol=VOL[i],crew=CREW[i];
    var factor=1+fl*(lift?0.03:0.14);
    var work=vol*0.55*factor/crew;
    var total=work+d/55;
    var hours=Math.max(2,Math.ceil(total*2)/2);
    var v=vol<=10?0:vol<=18?1:vol<=36?2:3;
    lastPlan={i:i,fl:fl,lift:lift,d:d,vol:vol,crew:crew,hours:hours,v:v};
    var out=$('#plan-out'),h='';
    function kv(a,b){return '<div class="kv"><dt>'+a+'</dt><dd>'+b+'</dd></div>'}
    h+='<h3>'+P.res_h+'</h3><dl>';
    h+=kv(P.veh,P.vehicles[v]);
    h+=kv(P.crew,nf(crew)+' '+P.crew_u);
    h+=kv(P.time,'≈ '+nf(hours)+' '+P.h_u);
    h+=kv(P.vol,'≈ '+nf(vol)+' '+P.m3);
    var r=cfg.rates;
    if(r&&r.showPrice&&r.perPersonHour){
      var price=crew*hours*r.perPersonHour+(r.perKm?d*r.perKm:0);
      if(r.minimum)price=Math.max(price,r.minimum);
      h+=kv(P.price,'≈ '+nf(Math.round(price/10)*10,{style:'currency',currency:'EUR',maximumFractionDigits:0}));
    }
    h+='</dl><p class="note">'+P.note+'</p><button type="button" class="btn" id="use-plan">'+P.use+'</button>';
    out.innerHTML=h;out.hidden=false;
    $('#use-plan').addEventListener('click',usePlan);
  });
}
function el(f,n){return f.elements.namedItem(n)}
function usePlan(){
  var f=$('#quote-form');if(!f||!lastPlan)return;
  var map=[2,2,3,4,5];
  if(el(f,'size'))el(f,'size').selectedIndex=map[lastPlan.i];
  var mg=el(f,'message');
  if(mg&&!mg.value.trim()&&cfg.plan.pf){
    mg.value=cfg.plan.pf.replace('{f}',lastPlan.fl).replace('{l}',lastPlan.lift?cfg.plan.lift_yes:cfg.plan.lift_no).replace('{d}',Math.round(lastPlan.d));
  }
  var q=$('#quote');if(q)q.scrollIntoView({behavior:'smooth',block:'start'});
  setTimeout(function(){var n=el(f,'name'),x=n&&!n.value?n:el(f,'from');if(x)x.focus({preventScroll:true})},450);
}

/* ---------- photos: resize on device, send as JPEG data URLs (EXIF is dropped by the canvas) ---------- */
var photos=[];
function loadImg(file){
  if(window.createImageBitmap)return createImageBitmap(file,{imageOrientation:'from-image'}).catch(function(){return viaReader(file)});
  return viaReader(file);
}
function viaReader(file){
  return new Promise(function(res,rej){var fr=new FileReader();fr.onload=function(){var im=new Image();im.onload=function(){res(im)};im.onerror=rej;im.src=fr.result};fr.onerror=rej;fr.readAsDataURL(file)});
}
function toJpeg(file){
  return loadImg(file).then(function(img){
    var w=img.width||img.naturalWidth,h=img.height||img.naturalHeight,s=Math.min(1,1600/Math.max(w,h));
    var cv=document.createElement('canvas');cv.width=Math.max(1,Math.round(w*s));cv.height=Math.max(1,Math.round(h*s));
    var cx=cv.getContext('2d');cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);cx.drawImage(img,0,0,cv.width,cv.height);
    var q=0.82,out=cv.toDataURL('image/jpeg',q);
    while(out.length>1200000&&q>0.4){q-=0.12;out=cv.toDataURL('image/jpeg',q)}
    if(out.indexOf('data:image/jpeg')!==0||out.length>1200000)throw new Error('img');
    return out;
  });
}
function drawThumbs(){
  var box=$('#photo-prev');if(!box)return;box.textContent='';
  photos.forEach(function(p,i){
    var w=document.createElement('div');w.className='thumb';var im=new Image();im.src=p;im.alt='';
    var b=document.createElement('button');b.type='button';b.setAttribute('aria-label',cfg.f.remove);b.textContent='×';
    b.addEventListener('click',function(){photos.splice(i,1);drawThumbs()});
    w.appendChild(im);w.appendChild(b);box.appendChild(w);
  });
}
var pin=$('#photos-in');
if(pin&&cfg.photos)pin.addEventListener('change',function(){
  var files=Array.prototype.slice.call(pin.files||[]).slice(0,4-photos.length);pin.value='';
  var bad=false;
  files.reduce(function(chain,f){return chain.then(function(){return toJpeg(f).then(function(d){if(photos.length<4)photos.push(d)},function(){bad=true})})},Promise.resolve())
    .then(function(){drawThumbs();var st=$('#quote-status');if(bad&&st){st.className='status bad';st.textContent=cfg.f.photos_err;st.hidden=false}});
});

/* ---------- quote form ---------- */
var qf=$('#quote-form');
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function summary(d,F){
  var L=[];
  function add(k,v){if(v)L.push(F[k]+': '+v)}
  add('name',d.name);add('email',d.email);add('phone',d.phone);add('service',d.service);add('from_',d.from);add('to',d.to);add('date',d.date);add('size',d.size);add('lang',d.replyLang);
  if(d.message)L.push('',d.message);
  return L.join('\n');
}
function copy(text){
  if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(text);
  return new Promise(function(res,rej){try{var ta=document.createElement('textarea');ta.value=text;ta.setAttribute('readonly','');ta.className='hp';document.body.appendChild(ta);ta.select();var ok=document.execCommand('copy');document.body.removeChild(ta);ok?res():rej()}catch(e){rej(e)}});
}
if(qf&&cfg.f){
  var F=cfg.f,st=$('#quote-status'),btn=$('button[type=submit]',qf);
  var show=function(html,cls){st.className='status '+cls;st.innerHTML=html;st.hidden=false;st.setAttribute('tabindex','-1');st.focus({preventScroll:false})};
  var fallback=function(d,msg){
    var text=summary(d,F),h='<p>'+esc(msg)+'</p>';
    if(cfg.email){
      var href='mailto:'+cfg.email+'?subject='+encodeURIComponent(cfg.brand+' – '+d.name)+'&body='+encodeURIComponent(text);
      h+='<a class="btn sm" href="'+esc(href)+'">'+esc(F.fallback_mail)+'</a>';
    }
    if(cfg.wa)h+='<a class="btn sm ghost" href="https://wa.me/'+esc(cfg.wa)+'?text='+encodeURIComponent(text)+'" rel="noopener">WhatsApp</a> ';
    h+='<button type="button" class="btn sm ghost" id="copy-q">'+esc(F.fallback_copy)+'</button>';
    show(h,'bad');
    var c=$('#copy-q');if(c)c.addEventListener('click',function(){copy(text).then(function(){c.textContent=F.copied},function(){})});
  };
  qf.addEventListener('submit',function(ev){
    ev.preventDefault();
    var fd=new FormData(qf),d={};
    ['name','email','phone','service','from','to','date','size','message','replyLang','website'].forEach(function(k){d[k]=String(fd.get(k)||'').trim()});
    var sv=el(qf,'service'),sz=el(qf,'size');
    d.service=sv.options[sv.selectedIndex].text;
    d.size=sz.options[sz.selectedIndex].text;
    d.replyLang=el(qf,'replyLang').value;
    d.lang=document.documentElement.lang;d.t=Date.now()-t0;
    var bad=[];
    function mark(el,isBad){el.setAttribute('aria-invalid',isBad?'true':'false');if(isBad)bad.push(el)}
    mark(el(qf,'name'),d.name.length<2);
    mark(el(qf,'email'),!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email));
    mark(el(qf,'consent'),!el(qf,'consent').checked);
    if(bad.length){show(esc(F.invalid),'bad');bad[0].focus();return}
    d.consent=true;d.photos=photos.slice();d.video=!!(el(qf,'video')&&el(qf,'video').checked);
    if(cfg.form.mode!=='api'){fallback(d,F.offline);return}
    if(!navigator.onLine){
      if(photos.length){fallback(d,F.err);return}
      window.__zq.add(d);show('<strong>'+esc(F.qh)+'</strong><p>'+esc(F.qp)+'</p>','ok');qf.reset();return;
    }
    btn.disabled=true;var old=btn.textContent;btn.textContent=F.sending;
    var ctl=window.AbortController?new AbortController():null,to=setTimeout(function(){ctl&&ctl.abort()},photos.length?90000:15000);
    fetch('/api/quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d),signal:ctl?ctl.signal:undefined})
      .then(function(r){return r.json().then(function(j){return {ok:r.ok,j:j}})})
      .then(function(x){
        if(x.ok&&x.j&&x.j.ok){
          show('<strong>'+esc(F.ok_h)+'</strong><p>'+esc(F.ok_p)+' <span class="ref">'+esc(x.j.ref)+'</span></p>','ok');
          qf.reset();photos=[];drawThumbs();$$('[aria-invalid]',qf).forEach(function(e){e.removeAttribute('aria-invalid')});
        }else fallback(d,F.err);
      })
      .catch(function(){fallback(d,F.err)})
      .then(function(){clearTimeout(to);btn.disabled=false;btn.textContent=old});
  });
  $$('input,textarea,select',qf).forEach(function(el){el.addEventListener('input',function(){el.removeAttribute('aria-invalid')})});
}

/* ---------- thanks page ---------- */
var ro=$('#ref-out');
if(ro){var m=/[?&]ref=([A-Z0-9-]{6,24})\b/.exec(location.search);if(m){ro.textContent=m[1];var w=$('#ref-wrap');if(w)w.hidden=false}}

/* ---------- owner-controlled notice + guide prices (from /api/public), offline bar, offline queue, service worker ---------- */
(function(){
var web=/^https?:$/.test(location.protocol),api=cfg.form&&cfg.form.mode==='api';
function bar(text,cls){var e=document.createElement('div');e.className=cls;e.setAttribute('role','status');e.textContent=text;return e}
if(web&&api){
  fetch('/api/public',{cache:'no-cache'}).then(function(r){return r.ok?r.json():null}).then(function(j){
    if(!j)return;
    if(j.rates&&cfg.plan)cfg.rates=j.rates;
    var t=j.banner&&j.banner.enabled&&j.banner[LNG];
    if(t){var key='z-n-'+t.length+t.slice(0,12),gone=null;try{gone=sessionStorage.getItem(key)}catch(e){}
      if(!gone){var n=bar(t,'notice'),x=document.createElement('button');x.type='button';x.setAttribute('aria-label','×');x.textContent='×';x.onclick=function(){n.remove();try{sessionStorage.setItem(key,'1')}catch(e){}};n.appendChild(x);var hd=$('.hdr');if(hd)hd.after(n)}}
  }).catch(function(){});
}
var off=null;
function net(){var F=cfg.f||{};if(navigator.onLine){if(off){off.remove();off=null}}else if(!off&&F.offbar){off=bar(F.offbar,'offbar');document.body.appendChild(off)}}
addEventListener('online',net);addEventListener('offline',net);net();
if(web&&'serviceWorker' in navigator)addEventListener('load',function(){navigator.serviceWorker.register(new URL('../sw.js',location.href).pathname).catch(function(){})});
/* offline queue for the quote form (text only, kept in this browser until it can be sent) */
var K='z-queue',busy=false;
function rd(){try{return JSON.parse(localStorage.getItem(K)||'[]')}catch(e){return[]}}
function wr(a){try{localStorage.setItem(K,JSON.stringify(a.slice(-10)))}catch(e){}}
window.__zq={add:function(d){var a=rd();d.photos=[];a.push(d);wr(a)},
 flush:function(){
  if(busy||!navigator.onLine||!api)return;var a=rd();if(!a.length)return;busy=true;
  (function next(){var a=rd();if(!a.length){busy=false;return}
    var d=Object.assign({},a[0],{t:30000});
    fetch('/api/quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}).then(function(r){return r.json().then(function(j){return{r:r,j:j}})}).then(function(o){
      if(o.r.ok||(o.r.status>=400&&o.r.status<500&&o.r.status!==429)){var b=rd();b.shift();wr(b);var st=$('#quote-status');if(o.r.ok&&st&&o.j.ref){st.className='status ok';st.innerHTML='';var s=document.createElement('strong');s.textContent=((cfg.f||{}).sentq||'')+' ';var rf=document.createElement('span');rf.className='ref';rf.textContent=o.j.ref;st.appendChild(s);st.appendChild(rf);st.hidden=false}next()}
      else busy=false}).catch(function(){busy=false})})();
 }};
addEventListener('online',function(){setTimeout(window.__zq.flush,800)});addEventListener('load',function(){setTimeout(window.__zq.flush,2000)});
})();
})();
