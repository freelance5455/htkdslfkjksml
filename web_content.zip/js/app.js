const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const store={get:(k,d)=>JSON.parse(localStorage.getItem(k)||'null')??d,set:(k,v)=>localStorage.setItem(k,JSON.stringify(v))};
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(t._);t._=setTimeout(()=>t.classList.remove('show'),2800)};
const esc=s=>s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const md=s=>esc(s).replace(/```[\w]*\n?([\s\S]*?)```/g,'<pre>$1</pre>').replace(/\*\*(.+?)\*\*/g,'<b>$1</b>');
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const DEFAULT_SYS='Tu es NOVA ULTIMATE AI, un assistant futuriste, brillant et chaleureux. Réponds dans la langue de l\'utilisateur.';

/* Navigation */
$$('.tab').forEach(b=>b.onclick=()=>{$$('.tab').forEach(x=>x.classList.toggle('on',x===b));$$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+b.dataset.v))});
const drawer=(o)=>{$('#drawer').classList.toggle('open',o);$('#scrim').classList.toggle('show',o)};
$('#menuBtn').onclick=()=>{renderConvs();drawer(true)}; $('#closeDrawer').onclick=$('#scrim').onclick=()=>drawer(false);

/* Paramètres */
const FIELDS=['brainProvider','brainKey','brainModel','brainUrl','imageProvider','imageKey','imageModel','videoProvider','videoKey','videoModel','videoUrl','systemPrompt'];
function loadSettings(){const s=JSON.parse(localStorage.getItem('nova_settings')||sessionStorage.getItem('nova_settings')||'{}');
  FIELDS.forEach(f=>{if(s[f]!=null)$('#'+f).value=s[f]}); if(!s.systemPrompt)$('#systemPrompt').value=DEFAULT_SYS;
  $('#rememberKeys').checked=s.remember!==false;}
function saveSettings(){const s={remember:$('#rememberKeys').checked};FIELDS.forEach(f=>s[f]=$('#'+f).value.trim());
  localStorage.removeItem('nova_settings');sessionStorage.removeItem('nova_settings');
  (s.remember?localStorage:sessionStorage).setItem('nova_settings',JSON.stringify(s));}
$('#gearBtn').onclick=()=>{loadSettings();$('#settings').classList.add('open')};
$('#closeSettings').onclick=()=>$('#settings').classList.remove('open');
$('#saveSettings').onclick=()=>{saveSettings();toast('Paramètres enregistrés');$('#settings').classList.remove('open')};
$$('[data-test]').forEach(b=>b.onclick=async()=>{saveSettings();b.disabled=true;b.textContent='…';
  try{toast(await NovaAPI.test(b.dataset.test))}catch(e){toast(e.message)}b.disabled=false;b.textContent='Tester'});
$('#wipeAll').onclick=()=>{if(confirm('Effacer toutes les clés, conversations et créations ?')){localStorage.clear();sessionStorage.clear();location.reload()}};

/* Conversations */
let convs=store.get('nova_convs',[]), cur=store.get('nova_cur',null);
const saveConvs=()=>{store.set('nova_convs',convs);store.set('nova_cur',cur)};
const active=()=>convs.find(c=>c.id===cur);
function newConv(){const c={id:uid(),title:'Nouvelle conversation',messages:[]};convs.unshift(c);cur=c.id;saveConvs();renderMessages();renderConvs();}
function renderConvs(){$('#convList').innerHTML='';convs.forEach(c=>{const d=document.createElement('div');d.className='conv'+(c.id===cur?' on':'');
  d.innerHTML=`<span>${esc(c.title)}</span><button aria-label="Supprimer">🗑</button>`;
  d.querySelector('span').onclick=()=>{cur=c.id;saveConvs();renderMessages();drawer(false)};
  d.querySelector('button').onclick=()=>{convs=convs.filter(x=>x.id!==c.id);if(cur===c.id)cur=convs[0]?.id||null;saveConvs();renderConvs();renderMessages()};
  $('#convList').appendChild(d)})}
$('#newChat').onclick=()=>{newConv();drawer(false)};
function bubble(role,text){const d=document.createElement('div');d.className='msg '+(role==='user'?'user':'ai');d.innerHTML=role==='user'?esc(text):md(text);$('#messages').appendChild(d);$('#messages').scrollTop=1e9;return d}
function renderMessages(){const c=active();$('#messages').innerHTML='';
  if(!c||!c.messages.length){$('#messages').innerHTML='<div class="welcome"><h1>Bonjour, je suis NOVA</h1><p>Posez une question, demandez une idée ou une histoire.</p></div>';return}
  c.messages.forEach(m=>bubble(m.role,m.content))}
const input=$('#chatInput');
input.oninput=()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,140)+'px'};
input.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&window.innerWidth>700){e.preventDefault();$('#chatForm').requestSubmit()}};
$('#chatForm').onsubmit=async e=>{e.preventDefault();const text=input.value.trim();if(!text)return;
  if(!active())newConv();const c=active();if(!c.messages.length)$('#messages').innerHTML='';
  c.messages.push({role:'user',content:text});if(c.messages.length===1)c.title=text.slice(0,40);saveConvs();
  bubble('user',text);input.value='';input.oninput();
  const ai=bubble('ai','');ai.innerHTML='<div class="typing"><span></span><span></span><span></span></div>';
  const sys=$('#systemPrompt').value||JSON.parse(localStorage.getItem('nova_settings')||'{}').systemPrompt||DEFAULT_SYS;
  try{const full=await NovaAPI.chat([{role:'system',content:sys},...c.messages.slice(-20)],t=>{ai.innerHTML=md(t);$('#messages').scrollTop=1e9});
    c.messages.push({role:'assistant',content:full});saveConvs();}
  catch(err){ai.classList.add('err');ai.textContent='⚠ '+err.message;c.messages.pop();saveConvs()}
  input.focus()};

/* Studio */
let ctype='image';
const STYLE={image:'',anime:', style anime japonais, cel shading, couleurs vives, qualité studio',manga:', planche de manga noir et blanc, encrage détaillé, trames, cases dynamiques',video:''};
$$('#createType .chip').forEach(b=>b.onclick=()=>{ctype=b.dataset.t;$$('#createType .chip').forEach(x=>x.classList.toggle('on',x===b))});
$('#enhanceBtn').onclick=async()=>{const p=$('#createPrompt').value.trim();if(!p)return toast('Écrivez une idée d\'abord');
  const b=$('#enhanceBtn');b.disabled=true;try{$('#createPrompt').value=(await NovaAPI.complete(`Réécris ce prompt de ${ctype} en un prompt visuel détaillé, en anglais, en une seule phrase, sans commentaire : ${p}`)).trim()}catch(e){toast(e.message)}b.disabled=false};
let gallery=store.get('nova_gallery',[]);
function renderGallery(){$('#gallery').innerHTML=gallery.map(g=>`<div class="gitem">${g.kind==='video'?`<video src="${g.url}" controls playsinline loop></video>`:`<img src="${g.url}" loading="lazy">`}<div class="cap">${esc(g.prompt.slice(0,60))}</div><a href="${g.url}" target="_blank" download>Ouvrir / télécharger</a></div>`).join('')}
$('#createBtn').onclick=async()=>{const p=$('#createPrompt').value.trim();if(!p)return toast('Décrivez votre création');
  const b=$('#createBtn'),ratio=$('#createRatio').value;b.disabled=true;b.textContent='Génération en cours…';
  try{let url,kind=ctype==='video'?'video':'image';
    if(kind==='video')url=await NovaAPI.video(p,ratio,s=>b.textContent='Vidéo : '+(s||'…'));else url=await NovaAPI.image(p+STYLE[ctype],ratio);
    if(!url)throw new Error('Aucun résultat reçu');
    gallery.unshift({url,kind,prompt:p});
    try{store.set('nova_gallery',gallery.filter(g=>!g.url.startsWith('blob:')).slice(0,30))}catch{store.set('nova_gallery',gallery.filter(g=>!g.url.startsWith('data:')&&!g.url.startsWith('blob:')).slice(0,30))}
    renderGallery();toast('Création terminée ✓')}
  catch(e){toast(e.message)}b.disabled=false;b.textContent='Générer'};

/* Histoires */
let stories=store.get('nova_stories',[]);
function renderStories(){$('#storyList').innerHTML=stories.map(s=>`<div class="story"><h4>${esc(s.title)} <small style="color:var(--mute)">· ${esc(s.genre)}</small></h4>${s.episodes.map((e,i)=>`<div class="ep"><b>Épisode ${i+1}</b>\n${md(e)}</div>`).join('')}<div class="row" style="margin-top:10px"><button class="btn small" data-cont="${s.id}">Continuer</button><button class="btn small danger" data-del="${s.id}">Supprimer</button></div></div>`).join('');
  $$('[data-cont]').forEach(b=>b.onclick=()=>{const s=stories.find(x=>x.id===b.dataset.cont);$('#storyTitle').value=s.title;$('#storyGenre').value=s.genre;$('#storyIdea').value=s.idea;window.scrollTo(0,0);$('#view-story').scrollTop=0;toast('Appuyez sur « Écrire l\'épisode suivant »')});
  $$('[data-del]').forEach(b=>b.onclick=()=>{stories=stories.filter(x=>x.id!==b.dataset.del);store.set('nova_stories',stories);renderStories()})}
$('#storyBtn').onclick=async()=>{const title=$('#storyTitle').value.trim()||'Sans titre',genre=$('#storyGenre').value,idea=$('#storyIdea').value.trim(),len=$('#storyLen').value;
  let s=stories.find(x=>x.title.toLowerCase()===title.toLowerCase());if(!s){s={id:uid(),title,genre,idea,episodes:[]};stories.unshift(s)}
  s.genre=genre;s.idea=idea||s.idea;
  const words={court:300,moyen:700,long:1400}[len];
  const prev=s.episodes.slice(-3).map((e,i)=>`Épisode précédent ${s.episodes.length-Math.min(3,s.episodes.length)+i+1} :\n${e}`).join('\n\n');
  const prompt=`Série « ${title} », genre ${genre}. Idée : ${s.idea||'libre'}.\n${prev||'Ceci est le premier épisode.'}\n\nÉcris l'épisode ${s.episodes.length+1} (environ ${words} mots), avec un titre, des dialogues vivants et une fin qui donne envie de lire la suite.`;
  const b=$('#storyBtn');b.disabled=true;b.textContent='Écriture…';
  const tmp=document.createElement('div');tmp.className='story';$('#storyList').prepend(tmp);
  try{const txt=await NovaAPI.chat([{role:'system',content:'Tu es un auteur professionnel de romans, anime et mangas.'},{role:'user',content:prompt}],t=>tmp.innerHTML=`<div class="ep">${md(t)}</div>`);
    s.episodes.push(txt);store.set('nova_stories',stories);toast('Épisode écrit ✓')}
  catch(e){if(!s.episodes.length)stories=stories.filter(x=>x!==s);toast(e.message)}
  renderStories();b.disabled=false;b.textContent='Écrire l\'épisode suivant'};

/* Init */
loadSettings();renderMessages();renderGallery();renderStories();
if(!JSON.parse(localStorage.getItem('nova_settings')||sessionStorage.getItem('nova_settings')||'{}').brainKey)setTimeout(()=>toast('Touchez ⚙ pour ajouter vos clés API'),800);
