/* AYMAN CASHFLOW — منطق التطبيق (يُحمَّل بعد اكتمال التخزين) */
const KEY='ayman_cashflow_v1';let certs=JSON.parse(AStore.getItem(KEY)||'[]');
const CC_KEY='ayman_cashflow_credit_cards_v1';let creditCards=JSON.parse(AStore.getItem(CC_KEY)||'[]');
const OB_KEY='ayman_cashflow_opening_balances_v1';let openingBalances=JSON.parse(AStore.getItem(OB_KEY)||'[]');
let calendarMonth=new Date(new Date().getFullYear(),new Date().getMonth(),1),selectedCalendarDay=new Date().toISOString().slice(0,10);
const TXN_KEY='ayman_cashflow_transactions_v1';let transactions=JSON.parse(AStore.getItem(TXN_KEY)||'[]');
const AUDIT_KEY='ayman_cashflow_audit_log_v1';let auditLog=JSON.parse(AStore.getItem(AUDIT_KEY)||'[]');if(!Array.isArray(auditLog))auditLog=[];

/* ══════════ البيانات وسجل العمليات ══════════ */
function logOperation(type,entity,name,bank='',amount='',details=''){const entry={id:crypto.randomUUID(),timestamp:new Date().toISOString(),date:new Date().toISOString().slice(0,10),type,entity,name:String(name||''),bank:String(bank||''),amount:Number.isFinite(Number(amount))&&amount!==''?Number(amount):'',details:String(details||'')};auditLog.unshift(entry);AStore.setItem(AUDIT_KEY,JSON.stringify(auditLog));}
const $=id=>document.getElementById(id);const money=n=>(Number(n)||0).toLocaleString('ar-EG',{maximumFractionDigits:2})+' ج.م';const moneyEn=n=>(Number(n)||0).toLocaleString('en-US',{maximumFractionDigits:2})+' ج.م';
function persist(){AStore.setItem(KEY,JSON.stringify(certs));render()}
function showPage(id){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===id));if(id==='cashflow')renderCashflow();lazyPages(id);}
/* يرسم الصفحات الثقيلة (السجل/الحركات/البطاقات) عند فتحها فقط */
function lazyPages(id){if(!id){const a=document.querySelector('.page.active');id=a&&a.id}if(id==='audit')return renderAuditLog();else if(id==='transactions')return renderTransactions();}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>showPage(b.dataset.page));

/* ══════════ التواريخ وحساب العوائد ══════════ */
function dateAdd(date,months){let d=new Date(date+'T12:00:00');let day=d.getDate();d.setDate(1);d.setMonth(d.getMonth()+months);let last=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(day,last));return d}
function dateKeyLocal(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function syncMaturityFromDuration(){const mode=$('durationYears')?.value||'custom';const custom=mode==='custom';$('maturityField').style.display=custom?'':'none';$('maturity').required=custom;if(!custom&&$('start').value){const d=dateAdd($('start').value,Number(mode)*12);$('maturity').value=dateKeyLocal(d);$('maturityPreview').textContent='تاريخ الاستحقاق المحسوب: '+$('maturity').value;}else if(custom){$('maturityPreview').textContent='أدخل تاريخ الاستحقاق يدوياً.'}else{$('maturityPreview').textContent='أدخل تاريخ بداية الشهادة لحساب الاستحقاق.'}}
$('durationYears').addEventListener('change',syncMaturityFromDuration);$('start').addEventListener('change',syncMaturityFromDuration);$('maturity').addEventListener('change',()=>{if($('durationYears').value!=='custom'){$('durationYears').value='custom';syncMaturityFromDuration()}});
function rateAt(c,date){let changes=[...(c.rateChanges||[])].filter(x=>x.date<=date).sort((a,b)=>a.date.localeCompare(b.date));return changes.length?Number(changes[changes.length-1].rate):Number(c.rate)}
/* نتائج payments() تُخزَّن مؤقتاً لكل شهادة حتى تتغير بياناتها */
const _payCache=new Map();
function payments(c){const k=JSON.stringify(c);let v=_payCache.get(k);if(!v){v=paymentsRaw(c);if(_payCache.size>400)_payCache.clear();_payCache.set(k,v)}return v.map(p=>({...p}))}
function paymentsRaw(c){
 let start=new Date(c.start+'T12:00:00'),end=new Date(c.maturity+'T12:00:00');
 const stopDate=c.status==='closed'?c.closeDate:c.status==='cancelled'?c.cancelDate:'';
 if(stopDate&&new Date(stopDate+'T12:00:00')<end)end=new Date(stopDate+'T12:00:00');
 let first=c.firstPay?new Date(c.firstPay+'T12:00:00'):dateAdd(c.start,1);
 let step=c.frequency==='monthly'?1:c.frequency==='quarterly'?3:12;
 // Keep payment dates anchored to the certificate's original day of month.
 const anchorDay=start.getDate();
 const makePaymentDate=(index)=>{
   const monthIndex=first.getMonth()+index*step;
   const year=first.getFullYear()+Math.floor(monthIndex/12);
   const month=((monthIndex%12)+12)%12;
   const lastDay=new Date(year,month+1,0).getDate();
   return new Date(year,month,Math.min(anchorDay,lastDay),12,0,0);
 };
 const dateKey=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
 const dayDiff=(a,b)=>Math.round((b.getTime()-a.getTime())/86400000);
 const changes=[...(c.rateChanges||[])].filter(x=>x&&x.date&&Number.isFinite(Number(x.rate))).map(x=>{
   // Bank statements in the supplied examples show that a rate entered after
   // the first day of a month starts affecting accrual from the first day of
   // the following month. A change entered on day 1 applies that same day.
   const entered=new Date(x.date+'T12:00:00');
   const effective=new Date(entered.getFullYear(),entered.getMonth()+(entered.getDate()===1?0:1),1,12,0,0);
   return {...x,effectiveDate:dateKey(effective)};
 }).sort((a,b)=>a.effectiveDate.localeCompare(b.effectiveDate));
 const effectiveRateAt=(date)=>{
   const active=changes.filter(x=>x.effectiveDate<=date);
   return active.length?Number(active[active.length-1].rate):Number(c.rate);
 };
 // In the month of a rate change, retain the normal monthly accrual at the
 // previous rate and add the rate difference for the remaining actual days
 // using the bank's 360-day basis. Unchanged months remain annualRate / 12.
 const monthSliceAmount=(sliceStart,sliceEnd)=>{
   if(sliceEnd<=sliceStart)return 0;
   const from=dateKey(sliceStart),to=dateKey(sliceEnd);
   const inSlice=changes.filter(x=>x.effectiveDate>=from&&x.effectiveDate<to);
   if(!inSlice.length)return Number(c.principal)*(effectiveRateAt(to)/100)/12;
   let baseRate=Number(c.rate);
   const before=changes.filter(x=>x.effectiveDate<from);
   if(before.length)baseRate=Number(before[before.length-1].rate);
   let total=Number(c.principal)*(baseRate/100)/12;
   for(let i=0;i<inSlice.length;i++){
     const change=inSlice[i];
     const segmentStart=new Date(change.effectiveDate+'T12:00:00');
     const nextChange=inSlice[i+1];
     const segmentEnd=nextChange?new Date(nextChange.effectiveDate+'T12:00:00'):sliceEnd;
     const days=dayDiff(segmentStart,segmentEnd);
     const priorRate=i===0?baseRate:Number(inSlice[i-1].rate);
     const delta=Number(change.rate)-priorRate;
     if(days>0&&delta!==0)total+=Number(c.principal)*(delta/100)*days/360;
   }
   return total;
 };
 // Split a payout interval into certificate-anchored monthly slices so that
 // a rate change affects only its own month, including quarterly/annual payouts.
 const intervalAmount=(from,to)=>{
   let total=0,cursor=from,guard=0;
   while(cursor<to&&guard++<24){
     const nextMonth=dateAdd(dateKey(start), Math.max(1, (cursor.getFullYear()-start.getFullYear())*12 + cursor.getMonth()-start.getMonth()+1));
     const sliceEnd=nextMonth<to?nextMonth:to;
     total+=monthSliceAmount(cursor,sliceEnd);
     cursor=sliceEnd;
   }
   return total;
 };
 // firstPay is the next scheduled payment date; accrue only one payment interval,
 // not the entire period since certificate inception.
 let out=[],guard=0,index=0,d=makePaymentDate(index);
 const previousScheduled=dateAdd(dateKey(first),-step);
 let previous=previousScheduled>start?previousScheduled:start;
 while(d<=end&&guard++<500){
   const date=dateKey(d);
   const amount=intervalAmount(previous,d);
   if(d>=dateAdd(c.start,1))out.push({date,amount,bank:c.bank,name:c.name});
   previous=d;
   d=makePaymentDate(++index);
 }
 return out;
}
function remaining(c){let now=new Date();return payments(c).filter(p=>new Date(p.date+'T23:59:59')>=now).reduce((s,p)=>s+p.amount,0)}

function refreshCertificateSuggestions(){
 const fill=(id,values)=>{const el=$(id);if(!el)return;const unique=[...new Set(values.map(v=>String(v||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ar'));el.innerHTML=unique.map(v=>'<option value="'+esc(v)+'"></option>').join('')};
 fill('certificateBanks',[...certs.map(c=>c.bank),...openingBalances.map(x=>x.bank),...creditCards.map(x=>x.bank),...transactions.map(x=>x.bank)]);
 fill('certificateNames',certs.map(c=>c.name));
 fill('certificateAccounts',certs.map(c=>c.account));
}


/* ══════════ لوحة التحكم ══════════ */
function render(){
 refreshCertificateSuggestions();lazyPages();renderCreditCards();
 const today=localISO(new Date());
 let active=certs.filter(c=>(!c.status||c.status==='active')&&c.start<=today&&c.maturity>=today);
 $('capital').textContent=money(active.reduce((s,c)=>s+Number(c.principal||0),0));
 const futurePayments=certs.flatMap(c=>payments(c).map(p=>({...p,certStatus:c.status||'active'}))).filter(p=>p.date>=today).sort((a,b)=>a.date.localeCompare(b.date));
 const monthEndKey=localISO(new Date(new Date().getFullYear(),new Date().getMonth()+1,0));
 $('returns').textContent=money(futurePayments.filter(p=>p.date<=monthEndKey).reduce((s,p)=>s+p.amount,0));
 $('count').textContent=active.length;
 const nearestDate=futurePayments.length?futurePayments[0].date:'';const nearestDayPayments=nearestDate?futurePayments.filter(p=>p.date===nearestDate):[];const nearestTotal=nearestDayPayments.reduce((sum,p)=>sum+Number(p.amount||0),0);$('nextPay').textContent=nearestDate?nearestDate+' · إجمالي العائد '+money(nearestTotal):'—';$('nextPayByBank').innerHTML=nearestDate?[...new Set(nearestDayPayments.map(p=>p.bank).filter(Boolean))].map(bank=>'<span>'+esc(bank)+': '+money(nearestDayPayments.filter(p=>p.bank===bank).reduce((sum,p)=>sum+Number(p.amount||0),0))+'</span>').join(''):'<span>لا توجد دفعات عائد قادمة</span>';
 $('dashTable').innerHTML=table(active);$('certTable').innerHTML=table(certs,true);
 let banks=[...new Set([...certs.map(c=>c.bank),...creditCards.map(c=>c.bank),...openingBalances.map(x=>x.bank),...transactions.map(t=>t.bank)].filter(Boolean))];
 $('bankList').innerHTML=banks.length?'<div class="table-wrap"><table><tr><th>البنك</th><th>عدد الشهادات</th><th>التفاصيل</th></tr>'+banks.map(b=>'<tr><td>'+esc(b)+'</td><td>'+certs.filter(c=>c.bank===b).length+' شهادة</td><td><button class="primary" data-bank-cert-details="'+esc(b)+'">أظهر التفاصيل</button></td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد بنوك مسجلة بعد</div>';
 renderOpeningBalances();renderCashflow();renderBankStatement();renderDashboardExtras();renderAlerts();
}
function renderDashboardExtras(){
 const now=new Date(),todayKey=localISO(now),monthStart=localISO(new Date(now.getFullYear(),now.getMonth(),1)),monthEnd=localISO(new Date(now.getFullYear(),now.getMonth()+1,0));
 const monthHeading=document.getElementById('dashboardMonth');if(monthHeading)monthHeading.textContent=now.toLocaleDateString('ar-EG',{month:'long',year:'numeric'});
 const bankNames=[...new Set([...certs.map(c=>c.bank),...openingBalances.map(o=>o.bank),...creditCards.map(c=>c.bank),...transactions.map(t=>t.bank)].filter(Boolean))];
 // Use the latest saved opening-balance snapshot for each bank, not the sum of historical snapshots.
 const latestOpeningByBank=bankNames.map(bank=>{
   const rows=openingBalances.filter(o=>String(o.bank||'').trim()===String(bank||'').trim())
     .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
   return rows.length?{bank,amount:Number(rows[0].amount||0),date:rows[0].date}:null;
 }).filter(Boolean);
 const openingTotal=latestOpeningByBank.reduce((sum,o)=>sum+o.amount,0);
 const actualEvents=[];
 // Net flow for the whole current month: include certificate payouts scheduled
 // through month-end, not only payouts that have already happened today.
 certs.forEach(c=>payments(c).forEach(p=>{if(p.date>=monthStart&&p.date<=monthEnd)actualEvents.push({bank:p.bank,in:Number(p.amount||0),out:0,source:'certificate'} )}));
 // Income and expenses are user-recorded transactions; include all dates in this month.
 transactions.forEach(t=>{if(t.date>=monthStart&&t.date<=monthEnd)actualEvents.push({bank:t.bank,in:t.type==='income'?Number(t.amount||0):0,out:t.type==='expense'?Number(t.amount||0):0,source:'transaction'})});
 // Count only card payments actually recorded, never the card's outstanding balance/minimum.
 creditCards.forEach(c=>cardPaymentEvents(c).filter(p=>p.date>=monthStart&&p.date<=monthEnd).forEach(p=>actualEvents.push({bank:c.bank,in:0,out:p.amount,source:'card-payment'}))); 
 const monthIn=actualEvents.reduce((a,e)=>a+e.in,0),monthOut=actualEvents.reduce((a,e)=>a+e.out,0),net=monthIn-monthOut;
 const debt=creditCards.reduce((a,c)=>a+Number(c.balance||0),0);
 const active=certs.filter(c=>(!c.status||c.status==='active')&&c.start<=todayKey&&c.maturity>=todayKey);
 const paymentsRemaining=certs.flatMap(c=>payments(c).map(p=>({...p}))).filter(p=>p.date>=todayKey&&p.date<=monthEnd);
 const bankHTML=(fn,formatter=money)=>bankNames.map(b=>'<span>'+esc(b)+': '+formatter(fn(b))+'</span>').join('');
 const netByBank=b=>actualEvents.filter(e=>e.bank===b).reduce((a,e)=>a+e.in-e.out,0);
 // Use the exact all-banks closing balance calculated by the bank statement.
 // Do not rebuild it from monthly dashboard totals: that omits carried-forward movements.
 const expectedRemaining=allBanksStatementClosing;
 if($('heroBalance'))$('heroBalance').textContent=money(expectedRemaining);
 if($('heroNet'))$('heroNet').textContent=money(net);
 if($('heroDebt'))$('heroDebt').textContent=money(debt);
 if($('heroReturns'))$('heroReturns').textContent=money(openingTotal);
 const heroLabel=document.querySelector('.hero-label');if(heroLabel)heroLabel.textContent='الرصيد التراكمي الصافي بنهاية المدة';
 const heroFoot=document.querySelector('.hero-foot');if(heroFoot){let formula= document.getElementById('heroExpectedFormula');if(!formula){formula=document.createElement('div');formula.id='heroExpectedFormula';formula.className='muted';formula.style.cssText='margin-top:8px;font-size:12px;line-height:1.8';heroFoot.parentNode.appendChild(formula)}formula.textContent='الرصيد المعروض مطابق للرصيد الختامي في كشف حساب البنوك (جميع البنوك): '+money(expectedRemaining)}
 $('heroBankBreakdown')?.remove();
 if($('heroNet'))$('heroNet').insertAdjacentHTML('afterend','<div class="muted" id="heroBankBreakdown" style="margin-top:6px">'+bankHTML(netByBank)+'</div>');
 const byBank=(id,fn,fmt=money)=>{const el=$(id);if(el)el.innerHTML=bankHTML(fn,fmt)};
 byBank('capitalByBank',b=>active.filter(c=>c.bank===b).reduce((a,c)=>a+Number(c.principal||0),0));
 byBank('returnsByBank',b=>paymentsRemaining.filter(p=>p.bank===b).reduce((a,p)=>a+p.amount,0));
 byBank('countByBank',b=>active.filter(c=>c.bank===b).length,v=>String(v)+' شهادة');

 byBank('cardDebtByBank',b=>creditCards.filter(c=>c.bank===b).reduce((a,c)=>a+Number(c.balance||0),0));
 $('todayLabel').textContent='آخر تحديث: '+now.toLocaleDateString('ar-EG',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
 $('bankSummary').innerHTML=bankNames.length?bankNames.map(b=>{const snap=latestOpeningByBank.find(o=>o.bank===b),bal=snap?snap.amount:0,principal=active.filter(c=>c.bank===b).reduce((a,c)=>a+Number(c.principal||0),0),debtB=creditCards.filter(c=>c.bank===b).reduce((a,c)=>a+Number(c.balance||0),0);return '<div class="row" style="padding:9px 0;border-bottom:1px solid var(--line)"><span>'+esc(b)+'</span><b>'+money(bal)+'</b></div><div class="muted" style="font-size:11px;margin-bottom:7px">رصيد آخر تسجيل '+(snap?'('+esc(snap.date)+')':'')+' · رأس المال المستثمر '+money(principal)+' · بطاقات '+money(debtB)+'</div>'}).join(''):'لا توجد أرصدة مسجلة بعد';
 const days=[];for(let i=6;i>=0;i--){const d=new Date(now);d.setDate(now.getDate()-i);days.push(localISO(d))}
 const bankChartNames=bankNames,colors=['#5d91ff','#e2b75e','#43d6ad','#e77aa4','#b28cff','#ff9b62'];
 const flowFor=(bank,day)=>{const inc=certs.filter(c=>c.bank===bank).flatMap(payments).filter(p=>p.date===day).reduce((a,p)=>a+p.amount,0)+transactions.filter(t=>t.bank===bank&&t.type==='income'&&t.date===day).reduce((a,t)=>a+Number(t.amount||0),0);const out=transactions.filter(t=>t.bank===bank&&t.type==='expense'&&t.date===day).reduce((a,t)=>a+Number(t.amount||0),0)+creditCards.filter(c=>c.bank===bank).flatMap(cardPaymentEvents).filter(p=>p.date===day).reduce((a,p)=>a+p.amount,0);return inc-out};
 const vals=days.map(day=>bankChartNames.reduce((sum,b)=>sum+flowFor(b,day),0)),max=Math.max(1,...vals.map(Math.abs));
 $('dashboardChart').innerHTML='<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px">'+bankChartNames.map((b,i)=>'<span style="font-size:11px"><i class="dot" style="background:'+colors[i%colors.length]+'"></i>'+esc(b)+'</span>').join('')+'<span style="font-size:11px"><i class="dot" style="background:#fff"></i>المجموع</span></div><div style="display:flex;align-items:end;gap:8px;height:175px;padding:8px;border-bottom:1px solid var(--line)">'+days.map(day=>{const total=bankChartNames.reduce((sum,b)=>sum+flowFor(b,day),0);return '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:end;height:100%;gap:3px"><div style="font-size:10px;color:var(--muted)">'+money(total)+'</div><div style="display:flex;align-items:end;gap:2px;height:125px;width:100%;justify-content:center">'+bankChartNames.map((bank,i)=>{const v=flowFor(bank,day);return '<div title="'+esc(bank)+' '+money(v)+'" style="width:9px;max-width:16%;height:'+Math.max(2,Math.abs(v)/max*110)+'px;background:'+colors[i%colors.length]+';border-radius:3px 3px 0 0"></div>'}).join('')+'<div title="المجموع '+money(total)+'" style="width:12px;height:'+Math.max(2,Math.abs(total)/max*110)+'px;background:#fff;border-radius:3px 3px 0 0"></div></div><small style="font-size:10px">'+day.slice(8)+'</small></div>'}).join('')+'</div>';
}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function table(list,edit=false){if(!list.length)return '<div class="empty">لا توجد شهادات مسجلة حتى الآن</div>';return '<div class="table-wrap"><table><tr><th>م</th><th>الشهادة</th><th>البنك</th><th>القيمة</th><th>العائد %</th><th>الاستحقاق</th>'+(edit?'<th>الحالة</th><th>إجراءات</th>':'')+'</tr>'+list.map((c,index)=>{const status=c.status||'active';const statusLabel=status==='closed'?'مغلقة':status==='cancelled'?'ملغاة':'نشطة';const statusDate=status==='closed'?c.closeDate:status==='cancelled'?c.cancelDate:'';return '<tr><td>'+(index+1)+'</td><td>'+(edit?'<button type="button" class="link-button" data-cert-details="'+esc(c.id)+'" title="عرض تفاصيل الشهادة وسجل العائد">'+esc(c.name)+'</button>':esc(c.name))+'</td><td>'+esc(c.bank)+'</td><td>'+money(c.principal)+'</td><td>'+esc(c.rate)+'%</td><td>'+esc(c.maturity)+'</td>'+(edit?'<td>'+statusLabel+(statusDate?' · '+esc(statusDate):'')+'</td><td><button data-edit="'+esc(c.id)+'">تعديل</button> '+(status==='active'?'<button data-rate="'+esc(c.id)+'">تعديل العائد</button> <button data-close="'+esc(c.id)+'">غلق</button> <button data-cancel="'+esc(c.id)+'" class="danger">إلغاء</button> ':'')+'<button class="danger" data-delete="'+esc(c.id)+'">حذف</button></td>':'')+'</tr>'}).join('')+'</table></div>'}document.addEventListener('click',e=>{const details=e.target.closest('[data-cert-details]');const edit=e.target.closest('[data-edit]');const del=e.target.closest('[data-delete]');const close=e.target.closest('[data-close]');const cancel=e.target.closest('[data-cancel]');const rate=e.target.closest('[data-rate]');if(details)showCertificateDetails(details.dataset.certDetails);if(edit)editCert(edit.dataset.edit);if(del)deleteCert(del.dataset.delete);if(close)closeCertificate(close.dataset.close);if(cancel)cancelCertificate(cancel.dataset.cancel);if(rate)changeCertificateRate(rate.dataset.rate)});
function showCertificateDetails(id){
 const c=certs.find(x=>String(x.id)===String(id));if(!c)return;
 const statusLabel=({active:'نشطة',closed:'مغلقة',cancelled:'ملغاة'}[c.status||'active']||c.status||'نشطة');
 const frequency=({monthly:'شهري',quarterly:'ربع سنوي',annual:'سنوي'}[c.frequency]||c.frequency||'—');
 const interestType=({fixed:'ثابت',tiered:'متدرج',variable:'متغير'}[c.interestType]||c.interestType||'—');
 const fields=[['البنك',c.bank],['الحساب',c.account],['رقم الشهادة',c.number],['رأس المال',money(c.principal)],['تاريخ البداية',c.start],['تاريخ أول صرف',c.firstPay||'—'],['مدة الشهادة',c.durationYears?({1:'سنة واحدة',3:'ثلاث سنوات',5:'خمس سنوات'}[c.durationYears]||c.durationYears+' سنة'):'تاريخ محدد'],['تاريخ الاستحقاق',c.maturity],['نوع العائد',interestType],['العائد الأساسي',String(c.rate??'—')+'%'],['دورية الصرف',frequency],['الحالة',statusLabel],['تاريخ الغلق / الإلغاء',c.closeDate||c.cancelDate||'—'],['مبلغ الغلق',c.closeAmount!=null?money(c.closeAmount):'—'],['ملاحظات',c.notes||'—']];
 const details='<div class="grid">'+fields.map(([k,v])=>'<div class="card"><div class="metric-label">'+esc(k)+'</div><div style="margin-top:7px;font-weight:700;overflow-wrap:anywhere">'+esc(String(v??'—'))+'</div></div>').join('')+'</div>';
 const changes=[...(Array.isArray(c.rateChanges)?c.rateChanges:[])].filter(x=>x&&x.date).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
 let previous=Number(c.rate||0);
 const rateRows=changes.map((x,i)=>{const next=Number(x.rate);const row='<tr><td>'+(i+1)+'</td><td>'+esc(x.date)+'</td><td>'+esc(String(previous))+'%</td><td>'+esc(String(Number.isFinite(next)?next:x.rate))+'%</td><td><button type="button" onclick="editRateChange(\''+esc(String(c.id))+'\',\''+esc(String(x.date))+'\')">تعديل المرحلة</button> <button type="button" class="danger" onclick="deleteRateChange(\''+esc(String(c.id))+'\',\''+esc(String(x.date))+'\')">حذف المرحلة</button></td></tr>';previous=Number.isFinite(next)?next:previous;return row;}).join('');
 const rateHistory='<div class="section"><h2>سجل مراحل تعديل العائد</h2><p class="muted">يمكنك حذف أي مرحلة أُدخلت بالخطأ. حذف المرحلة يعيد تطبيق آخر عائد سابق لها على الفترات التالية حتى تسجيل تغيير آخر.</p><div class="table-wrap"><table><tr><th>م</th><th>تاريخ السريان</th><th>العائد السابق</th><th>العائد الجديد</th><th>الإجراء</th></tr><tr><td>—</td><td>'+esc(c.start||'—')+'</td><td>—</td><td>'+esc(String(c.rate??'—'))+'% (أساسي)</td><td>—</td></tr>'+(rateRows||'<tr><td colspan="5" class="empty">لا توجد تعديلات مسجلة على العائد</td></tr>')+'</table></div><div class="note section">العائد الساري حالياً: <b>'+esc(String(rateAt(c,localISO(new Date()))))+'%</b></div></div>';
 $('certificateDetailsTitle').textContent='تفاصيل الشهادة: '+(c.name||'');$('certificateDetailsContent').innerHTML=details+rateHistory;$('certificateDetailsModal').style.display='block';$('certificateDetailsModal').scrollIntoView({behavior:'smooth',block:'start'});
}
function closeCertificateDetails(){$('certificateDetailsModal').style.display='none';$('certificateDetailsContent').innerHTML='';}
function editRateChange(certificateId,changeDate){
 const c=certs.find(x=>String(x.id)===String(certificateId));if(!c)return;
 const change=(c.rateChanges||[]).find(x=>String(x.date)===String(changeDate));if(!change)return;
 const newDate=prompt('تاريخ سريان مرحلة العائد (YYYY-MM-DD):',String(change.date||''));
 if(newDate===null)return;
 if(!/^\d{4}-\d{2}-\d{2}$/.test(newDate)||Number.isNaN(new Date(newDate+'T12:00:00').getTime())){alert('يرجى إدخال تاريخ صحيح بصيغة YYYY-MM-DD.');return;}
 const newRateText=prompt('نسبة العائد السنوي الجديدة (%):',String(change.rate??''));
 if(newRateText===null)return;
 const newRate=Number(newRateText);
 if(!Number.isFinite(newRate)||newRate<0){alert('يرجى إدخال نسبة عائد صحيحة.');return;}
 const duplicate=(c.rateChanges||[]).some(x=>x!==change&&String(x.date)===newDate);
 if(duplicate){alert('توجد مرحلة أخرى مسجلة في التاريخ نفسه.');return;}
 if(!confirm('تأكيد تعديل المرحلة من '+change.date+' بنسبة '+change.rate+'% إلى '+newDate+' بنسبة '+newRate+'%؟'))return;
 const updated=(c.rateChanges||[]).map(x=>x===change?{...x,date:newDate,rate:newRate}:x).sort((a,b)=>a.date.localeCompare(b.date));
 certs=certs.map(x=>String(x.id)===String(certificateId)?{...x,rateChanges:updated}:x);
 logOperation('تعديل مرحلة تغيير عائد','شهادة',c.name,c.bank,c.principal,'تعديل المرحلة من '+changeDate+' إلى '+newDate+' بنسبة '+newRate+'%');
 persist();
 showCertificateDetails(certificateId);
 alert('تم تعديل مرحلة تغيير العائد وإعادة تحديث الحسابات والتدفقات.');
}
function deleteRateChange(certificateId,changeDate){
 const c=certs.find(x=>String(x.id)===String(certificateId));if(!c)return;
 const change=(c.rateChanges||[]).find(x=>String(x.date)===String(changeDate));if(!change)return;
 if(!confirm('هل تريد حذف مرحلة تغيير العائد بتاريخ '+changeDate+'؟ سيتم إعادة حساب العوائد والتدفقات وفق آخر عائد سابق لهذا التاريخ.'))return;
 const updated=(c.rateChanges||[]).filter(x=>String(x.date)!==String(changeDate));
 certs=certs.map(x=>String(x.id)===String(certificateId)?{...x,rateChanges:updated}:x);
 logOperation('حذف مرحلة تغيير عائد','شهادة',c.name,c.bank,c.principal,'حذف مرحلة العائد بتاريخ '+changeDate);
 persist();
 showCertificateDetails(certificateId);
 alert('تم حذف مرحلة تغيير العائد وإعادة تحديث الحسابات والتدفقات.');
}


/* ══════════ الشهادات ══════════ */
function saveCertificate(){syncMaturityFromDuration();let ids=['bank','account','name','number','principal','start','maturity','interestType','rate','frequency','firstPay','notes'];let v=Object.fromEntries(ids.map(k=>[k,$(k).value]));v.durationYears=$('durationYears').value==='custom'?'':Number($('durationYears').value);if(!v.bank||!v.name||!v.principal||!v.start||!v.maturity||!v.rate){alert('يرجى استكمال الحقول المطلوبة');return}if(new Date(v.maturity)<new Date(v.start)){alert('تاريخ الاستحقاق يجب أن يكون بعد تاريخ البداية');return}let id=$('editId').value;if(id){certs=certs.map(c=>c.id===id?{...c,...v,id}:c);logOperation('تعديل','شهادة',v.name,v.bank,v.principal,'تعديل بيانات الشهادة')}else {certs.push({...v,id:crypto.randomUUID(),status:'active'});logOperation('إضافة','شهادة',v.name,v.bank,v.principal,'إضافة شهادة جديدة')}persist();resetForm();alert('تم حفظ الشهادة')}
function resetForm(){ $('certForm').reset();$('editId').value='';$('durationYears').value='1';syncMaturityFromDuration();$('formTitle').textContent='إضافة شهادة جديدة'}
function editCert(id){let c=certs.find(x=>x.id===id);if(!c)return;Object.keys(c).forEach(k=>{if($(k))$(k).value=c[k]});$('durationYears').value=c.durationYears?[String(c.durationYears)]: 'custom';$('durationYears').value=c.durationYears?String(c.durationYears):'custom';syncMaturityFromDuration();if($('durationYears').value==='custom')$('maturity').value=c.maturity||'';$('editId').value=id;$('formTitle').textContent='تعديل الشهادة';showPage('certificates');window.scrollTo(0,0)}
function changeCertificateRate(id){const c=certs.find(x=>x.id===id);if(!c)return;if(c.interestType!=='variable'&&c.interestType!=='متغير'&&c.interestType!=='متغيرة'){if(!confirm('نوع الشهادة مسجل حالياً كغير متغير. هل تريد تسجيل تغيير عائد لها على أي حال؟'))return}const date=prompt('اعتباراً من أي تاريخ يسري العائد الجديد؟ (YYYY-MM-DD)',new Date().toISOString().slice(0,10));if(date===null)return;if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<c.start||date>c.maturity){alert('التاريخ غير صحيح؛ يجب أن يكون بين بداية الشهادة والاستحقاق');return}const rate=prompt('أدخل نسبة العائد السنوي الجديدة (%)',String(rateAt(c,date)));if(rate===null)return;if(rate.trim()===''||!Number.isFinite(Number(rate))||Number(rate)<0||Number(rate)>100){alert('نسبة العائد غير صحيحة');return}const changes=[...(c.rateChanges||[])].filter(x=>x.date!==date);changes.push({date,rate:Number(rate)});changes.sort((a,b)=>a.date.localeCompare(b.date));certs=certs.map(x=>x.id===id?{...x,rateChanges:changes}:x);logOperation('تغيير عائد','شهادة',c.name,c.bank,c.principal,'العائد '+rate+'% اعتباراً من '+date);persist();alert('تم تسجيل العائد الجديد اعتباراً من '+date+' وتحديث التدفقات المتوقعة')}
function closeCertificate(id){const c=certs.find(x=>x.id===id);if(!c)return;const date=prompt('أدخل تاريخ غلق الشهادة (YYYY-MM-DD):',new Date().toISOString().slice(0,10));if(date===null)return;if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<c.start||date>c.maturity){alert('تاريخ الغلق غير صحيح؛ يجب أن يكون بين بداية الشهادة والاستحقاق');return}if(!confirm('سيتم اعتبار الشهادة مغلقة اعتباراً من '+date+' وإيقاف العوائد بعدها. هل تريد المتابعة؟'))return;certs=certs.map(x=>x.id===id?{...x,status:'closed',closeDate:date}:x);logOperation('غلق','شهادة',c.name,c.bank,c.principal,'تاريخ الغلق '+date);persist();alert('تم غلق الشهادة وتحديث التدفقات')}
function cancelCertificate(id){const c=certs.find(x=>x.id===id);if(!c)return;const date=prompt('أدخل تاريخ إلغاء الشهادة (YYYY-MM-DD):',new Date().toISOString().slice(0,10));if(date===null)return;if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<c.start||date>c.maturity){alert('تاريخ الإلغاء غير صحيح؛ يجب أن يكون بين بداية الشهادة والاستحقاق');return}if(!confirm('سيتم تسجيل الشهادة كملغاة اعتباراً من '+date+' وإيقاف العوائد بعدها. هل تريد المتابعة؟'))return;certs=certs.map(x=>x.id===id?{...x,status:'cancelled',cancelDate:date}:x);logOperation('إلغاء','شهادة',c.name,c.bank,c.principal,'تاريخ الإلغاء '+date);persist();alert('تم إلغاء الشهادة وتحديث التدفقات')}
function deleteCert(id){if(confirm('هل تريد حذف هذه الشهادة نهائياً؟ لا يمكن التراجع عن الحذف إلا من نسخة احتياطية.')){const c=certs.find(x=>x.id===id);if(c)logOperation('حذف','شهادة',c.name,c.bank,c.principal,'حذف نهائي');certs=certs.filter(c=>c.id!==id);persist()}}

/* ══════════ الحركات والأرصدة الافتتاحية ══════════ */
function saveTransaction(){
 const v={type:$('txnType').value,date:$('txnDate').value,bank:$('txnBank').value.trim(),category:$('txnCategory').value,description:$('txnDescription').value.trim(),amount:Number($('txnAmount').value),notes:$('txnNotes').value};
 if(!v.date||!v.bank||!v.description||!Number.isFinite(v.amount)||v.amount<=0){alert('يرجى استكمال التاريخ والبنك والبيان والمبلغ الصحيح');return}
 const id=$('txnEditId').value;
 if(id){transactions=transactions.map(t=>t.id===id?{...v,id}:t);logOperation('تعديل','حركة مالية',v.description,v.bank,v.amount,v.type==='income'?'إيراد · '+v.date:'مصروف · '+v.date)}else {transactions.push({...v,id:crypto.randomUUID()});logOperation('إضافة','حركة مالية',v.description,v.bank,v.amount,(v.type==='income'?'إيراد':'مصروف')+' · '+v.date)}
 AStore.setItem(TXN_KEY,JSON.stringify(transactions));resetTransactionForm();render();alert('تم حفظ الحركة المالية');
}
document.getElementById('txnForm')?.addEventListener('submit',e=>{e.preventDefault();saveTransaction()});
function resetTransactionForm(){$('txnForm').reset();$('txnEditId').value='';$('txnFormTitle').textContent='تسجيل حركة مالية'}
function editTransaction(id){const t=transactions.find(x=>x.id===id);if(!t)return;$('txnEditId').value=id;$('txnType').value=t.type;$('txnDate').value=t.date;$('txnBank').value=t.bank;$('txnCategory').value=t.category;$('txnDescription').value=t.description;$('txnAmount').value=t.amount;$('txnNotes').value=t.notes||'';$('txnFormTitle').textContent='تعديل الحركة المالية';showPage('transactions');window.scrollTo(0,0)}
function deleteTransaction(id){if(confirm('هل تريد حذف هذه الحركة؟')){const t=transactions.find(x=>x.id===id);if(t)logOperation('حذف','حركة مالية',t.description,t.bank,t.amount,'حذف حركة '+t.date);transactions=transactions.filter(t=>t.id!==id);AStore.setItem(TXN_KEY,JSON.stringify(transactions));render()}}
function renderTransactions(){
 const income=transactions.filter(t=>t.type==='income').reduce((a,t)=>a+Number(t.amount),0),expense=transactions.filter(t=>t.type==='expense').reduce((a,t)=>a+Number(t.amount),0);
 $('otherIncomeTotal').textContent=money(income);$('otherExpenseTotal').textContent=money(expense);$('otherNetTotal').textContent=money(income-expense);
 $('txnTable').innerHTML=transactions.length?'<div class="table-wrap"><table><tr><th>التاريخ</th><th>النوع</th><th>البنك</th><th>التصنيف</th><th>البيان</th><th>المبلغ</th><th>إجراءات</th></tr>'+transactions.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(t=>'<tr><td>'+esc(t.date)+'</td><td>'+(t.type==='income'?'إيراد':'مصروف')+'</td><td>'+esc(t.bank)+'</td><td>'+esc(t.category)+'</td><td>'+esc(t.description)+'</td><td>'+money(t.amount)+'</td><td><button data-txn-edit="'+esc(t.id)+'">تعديل</button> <button class="danger" data-txn-delete="'+esc(t.id)+'">حذف</button></td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد إيرادات أو مصروفات مسجلة</div>';
}
document.addEventListener('click',e=>{const edit=e.target.closest('[data-txn-edit]'),del=e.target.closest('[data-txn-delete]');if(edit)editTransaction(edit.dataset.txnEdit);if(del)deleteTransaction(del.dataset.txnDelete)});
function saveOpeningBalance(){
 const date=$('obDate').value,bank=$('obBank').value.trim(),amount=$('obAmount').value;
 if(!date||!bank||amount===''){alert('يرجى إدخال التاريخ واسم البنك والمبلغ');return}
 openingBalances.push({id:crypto.randomUUID(),date,bank,amount:Number(amount)});logOperation('إضافة','رصيد بداية مدة',bank,bank,Number(amount),'تاريخ الرصيد '+date);
 AStore.setItem(OB_KEY,JSON.stringify(openingBalances));$('openingForm').reset();render();alert('تم حفظ رصيد بداية المدة');
}
function renderOpeningBalances(){
 const names=[...new Set([...certs.map(c=>c.bank),...creditCards.map(c=>c.bank),...openingBalances.map(x=>x.bank)])];
 $('knownBanks').innerHTML=names.map(n=>'<option value="'+esc(n)+'">').join('');
 $('openingList').innerHTML=openingBalances.length?'<div class="table-wrap"><table><tr><th>التاريخ</th><th>البنك</th><th>رصيد بداية المدة</th><th>إجراء</th></tr>'+openingBalances.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>'<tr><td>'+esc(x.date)+'</td><td>'+esc(x.bank)+'</td><td>'+money(x.amount)+'</td><td><button class="danger" data-ob-delete="'+esc(x.id)+'">حذف</button></td></tr>').join('')+'</table></div>':'<div class="empty">لم يتم إدخال أرصدة بداية مدة بعد</div>';
}

/* ══════════ التدفقات النقدية والتقويم ══════════ */
function setFlowPeriod(kind){
 const now=new Date(),from=new Date(now.getFullYear(),kind==='year'?0:now.getMonth(),1),to=kind==='year'?new Date(now.getFullYear(),11,31):new Date(now.getFullYear(),now.getMonth()+1,0);
 // Use local calendar dates; toISOString() shifts midnight to the previous day in UTC+ time zones.
 $('flowFrom').value=localISODate(from);$('flowTo').value=localISODate(to);renderCashflow();
}
function drawLineChart(targetId,labels,seriesA,seriesB){
 const el=$(targetId);if(!el)return;
 if(!labels.length){el.innerHTML='<div class="empty">لا توجد بيانات في الفترة المحددة</div>';return}
 const max=Math.max(1,...seriesA,...seriesB),w=560,h=180,step=labels.length>1?w/(labels.length-1):0;
 const pts=arr=>arr.map((v,i)=>`${i*step},${145-(v/max)*120}`).join(' ');
 el.innerHTML='<svg viewBox="0 0 560 180" role="img" aria-label="مخطط التدفقات الداخلة والخارجة">'+[0,1,2,3].map(i=>'<line x1="0" y1="'+(25+i*40)+'" x2="560" y2="'+(25+i*40)+'" stroke="#ffffff18"/>').join('')+'<polyline fill="none" stroke="#5d91ff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="'+pts(seriesA)+'"/><polyline fill="none" stroke="#e77aa4" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="'+pts(seriesB)+'"/>'+labels.map((l,i)=>'<text x="'+(i*step)+'" y="170" fill="#a9b8d3" font-size="10" text-anchor="middle">'+esc(l)+'</text>').join('')+'</svg>';
}
function drawBars(targetId,items,color){
 const el=$(targetId);if(!el)return;
 const valid=items.filter(x=>x.value>0);
 if(!valid.length){el.innerHTML='<div class="empty">لا توجد بيانات مسجلة لعرضها</div>';return}
 const max=Math.max(1,...valid.map(x=>x.value));
 el.innerHTML='<div style="display:grid;gap:13px;padding:8px 0">'+valid.map(x=>'<div><div class="row" style="font-size:12px;margin-bottom:5px"><span>'+esc(x.label)+'</span><b>'+money(x.value)+'</b></div><div style="height:10px;background:#ffffff12;border-radius:20px;overflow:hidden"><div style="height:100%;width:'+Math.max(2,x.value/max*100)+'%;background:'+color+';border-radius:20px"></div></div></div>').join('')+'</div>';
}
function shiftCalendar(delta){calendarMonth=new Date(calendarMonth.getFullYear(),calendarMonth.getMonth()+delta,1);renderCashflow()}
function renderCashCalendar(events){
 const title=$('calendarTitle'),root=$('cashCalendar');if(!root)return;
 const y=calendarMonth.getFullYear(),m=calendarMonth.getMonth(),first=new Date(y,m,1),last=new Date(y,m+1,0);
 title.textContent=first.toLocaleDateString('ar-EG-u-nu-latn',{month:'long',year:'numeric'});
 const week=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
 let html=week.map(x=>'<div class="cal-head">'+x+'</div>').join('');
 const offset=first.getDay(),total=Math.ceil((offset+last.getDate())/7)*7;
 for(let cell=0;cell<total;cell++){
  const dayNum=cell-offset+1,valid=dayNum>=1&&dayNum<=last.getDate();
  const d=valid?new Date(y,m,dayNum):new Date(y,m,dayNum),key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  const daily=events.filter(e=>e.date===key),inc=daily.reduce((a,e)=>a+Number(e.in||0),0),out=daily.reduce((a,e)=>a+Number(e.out||0),0);
  const today=new Date().toISOString().slice(0,10);
  html+='<button class="cal-day '+(!valid?'muted-day ':'')+(key===today?'today ':'')+(key===selectedCalendarDay?'selected':'')+'" data-cal-date="'+key+'" '+(!valid?'disabled':'')+'><span class="daynum">'+(valid?String(dayNum):'')+'</span>'+(inc?'<span class="inflow">＋'+moneyEn(inc)+'</span>':'')+(out?'<span class="outflow">−'+moneyEn(out)+'</span>':'')+'</button>';
 }
 root.innerHTML=html;renderCalendarDetails(events);
}
function renderCalendarDetails(events){
 const el=$('calendarDayDetails');if(!el)return;
 const list=events.filter(e=>e.date===selectedCalendarDay),inc=list.reduce((a,e)=>a+Number(e.in||0),0),out=list.reduce((a,e)=>a+Number(e.out||0),0);
 const certDetails=e=>{const c=certs.find(x=>x.id===e.certId);if(!c)return '';return '<div class="note section"><b>تفاصيل الشهادة</b><div>اسم الشهادة: '+esc(c.name||'—')+'</div><div>البنك: '+esc(c.bank||'—')+'</div><div>رقم الشهادة: '+esc(c.number||'—')+'</div><div>الحساب: '+esc(c.account||'—')+'</div><div>قيمة الشهادة: '+moneyEn(c.principal)+'</div><div>العائد السنوي: '+esc(c.rate)+'%</div><div>دورية الصرف: '+esc(c.frequency==='monthly'?'شهري':c.frequency==='quarterly'?'ربع سنوي':'سنوي')+'</div><div>تاريخ البداية: '+esc(c.start)+'</div><div>تاريخ الاستحقاق: '+esc(c.maturity)+'</div></div>'};
 el.innerHTML='<div class="row"><h2>تفاصيل يوم '+esc(selectedCalendarDay)+'</h2><span class="pill">الصافي: '+moneyEn(inc-out)+'</span></div>'+(list.length?'<div class="table-wrap"><table><tr><th>البنك</th><th>البيان</th><th>داخل</th><th>خارج</th></tr>'+list.map(e=>'<tr><td>'+esc(e.bank)+'</td><td>'+(e.certId?'<button type="button" data-cert-detail="'+esc(e.certId)+'">'+esc(e.description)+' · عرض تفاصيل الشهادة</button>':esc(e.description))+'</td><td>'+moneyEn(e.in||0)+'</td><td>'+moneyEn(e.out||0)+'</td></tr>'+(e.certId?'<tr id="certDetail_'+esc(e.certId)+'" hidden><td colspan="4">'+certDetails(e)+'</td></tr>':'')).join('')+'</table></div>':'<div class="empty">لا توجد تدفقات مسجلة في هذا اليوم</div>');
}
document.addEventListener('click',e=>{const db=e.target.closest('[data-cert-detail]');if(db){const row=$('certDetail_'+db.dataset.certDetail);if(row)row.hidden=!row.hidden;return}const day=e.target.closest('[data-cal-date]');if(day){selectedCalendarDay=day.dataset.calDate;renderCashflow()}});
let lastCashflowCalendarEvents=[];
function exportCashflowToGoogleCalendar(){
 const events=lastCashflowCalendarEvents.filter(e=>/^\d{4}-\d{2}-\d{2}$/.test(String(e.date||'')));
 if(!events.length){alert('لا توجد تدفقات في الفترة الحالية لتصديرها');return}
 const escICS=v=>String(v??'').replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
 const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
 const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//AYMAN CASHFLOW//AR','CALSCALE:GREGORIAN','METHOD:PUBLISH'];
 events.forEach(e=>{
   const date=String(e.date).replace(/-/g,'');
   const amount=Number(e.in||0)>0?('داخل: '+moneyEn(e.in)):('خارج: '+moneyEn(e.out));
   const summary=(e.description||'تدفق نقدي')+' - '+amount;
   const details=['البنك: '+(e.bank||'—'),'البيان: '+(e.description||'—'),amount,'مصدر الحدث: AYMAN CASHFLOW'].join('\n');
   const uid='ayman-cashflow-'+encodeURIComponent([e.type||'',e.date,e.bank||'',e.description||'',e.in||0,e.out||0].join('|'))+'@local';
   const d=new Date(e.date+'T12:00:00');d.setDate(d.getDate()+1);
   lines.push('BEGIN:VEVENT','UID:'+escICS(uid),'DTSTAMP:'+stamp,'DTSTART;VALUE=DATE:'+date,'DTEND;VALUE=DATE:'+localISODate(d).replace(/-/g,''),'SUMMARY:'+escICS(summary),'DESCRIPTION:'+escICS(details),'END:VEVENT');
 });
 lines.push('END:VCALENDAR');
 const blob=new Blob([lines.join('\r\n')+'\r\n'],{type:'text/calendar;charset=utf-8'});
 const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='AYMAN_CASHFLOW_Google_Calendar.ics';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
 alert('تم إنشاء ملف التقويم. افتحه على الهاتف واختر إضافته إلى Google Calendar. التصدير من التطبيق إلى Google فقط؛ أعد التصدير عند تغيير المواعيد.');
}
function renderCashflow(){
 const today=new Date(),mode=$('flowMode').value;
 let from=$('flowFrom').value,to=$('flowTo').value;
 if(!from)from=localISODate(new Date(today.getFullYear(),today.getMonth(),1));
 if(!to)to=localISODate(new Date(today.getFullYear(),today.getMonth()+1,0));
 if(mode==='monthly'){
   const d=new Date(from+'T12:00:00'),y=d.getFullYear(),m=d.getMonth();
   from=String(y)+'-'+String(m+1).padStart(2,'0')+'-01';
   to=String(y)+'-'+String(m+1).padStart(2,'0')+'-'+String(new Date(y,m+1,0).getDate());
   $('flowFrom').value=from;$('flowTo').value=to;
 }
 if(from>to){$('flowTable').innerHTML='<div class="empty">تاريخ البداية يجب أن يكون قبل تاريخ النهاية</div>';return}
 // The opening-balance date is a report-specific reference point, not a permanent
 // change to certificate history. Select the latest balance snapshot on or before
 // the report end date; a future snapshot must not affect an earlier report.
 // Interest is counted strictly AFTER the reference date; the reference day itself is excluded.
 const allBanks=[...new Set([
   ...certs.map(c=>c.bank),...openingBalances.map(o=>o.bank),
   ...transactions.map(t=>t.bank),...creditCards.map(c=>c.bank)
 ].map(v=>String(v||'').trim()).filter(Boolean))].sort();
 const openingByBank=allBanks.map(bank=>{
   const candidates=openingBalances.filter(o=>
     String(o.bank||'').trim()===bank && /^\d{4}-\d{2}-\d{2}$/.test(String(o.date||'')) && o.date<=to
   ).sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
   return candidates.length?{bank,date:candidates[0].date,amount:Number(candidates[0].amount||0)}:null;
 }).filter(Boolean);
 const interestEvents=[];
 certs.forEach(c=>{
   const bankOpening=openingByBank.find(o=>String(o.bank||'').trim()===String(c.bank||'').trim());
   const calculationStart=bankOpening?.date||c.start||'';
   payments(c).forEach(p=>{
     if(p.date>=from&&p.date<=to&&(!calculationStart||p.date>calculationStart))interestEvents.push({
       date:p.date,bank:c.bank||'',description:'عائد شهادة: '+(p.name||c.name||''),
       in:Number(p.amount||0),out:0,type:'interest',certId:c.id,
       details:{'اسم الشهادة':c.name||p.name||'—','رقم الشهادة':c.number||'—','قيمة الشهادة':money(c.principal||0),'معدل العائد':(c.rate??'—')+'%','دورية الصرف':c.frequency||'—','تاريخ صرف العائد':p.date,'قيمة العائد':money(p.amount||0)}
     });
   });
 });
 const openingEvents=openingByBank.filter(o=>o.date<=to).map(o=>({
   // If the balance was registered before the selected period, carry it as the period's starting balance.
   // If it was registered inside the period, show it on its actual registration date.
   date:o.date<from?from:o.date,bank:o.bank,description:'رصيد بداية المدة ('+o.date+')',
   in:o.amount,out:0,type:'opening',
   details:{'البنك':o.bank,'تاريخ تسجيل الرصيد':o.date,'التاريخ المرجعي لهذا التقرير':o.date,'رصيد بداية المدة':money(o.amount)}
 }));
 const expenseEvents=transactions.filter(t=>{
   const kind=String(t.type||'').trim().toLowerCase();
   const isOutgoing=['expense','outgoing','out','مصروف','مصروفات','خارج','تدفق خارج'].includes(kind);
   const d=String(t.date||t.transactionDate||t.due||'');
   return isOutgoing&&d>=from&&d<=to;
 }).map(t=>{
   const d=String(t.date||t.transactionDate||t.due||'');
   const amount=Number(t.amount??t.value??t.total??0);
   return {
     date:d,bank:t.bank||'',description:(t.description||t.name||'مصروف')+' ('+(t.category||'')+')',
     in:0,out:amount,type:'expense',
     details:{'نوع الحركة':t.type||'مصروف','البيان':t.description||t.name||'مصروف','التصنيف':t.category||'—','البنك':t.bank||'—','التاريخ':d,'المبلغ':money(amount),'ملاحظات':t.notes||'—'}
   };
 });
 // Actual payments and remaining unpaid debt are separate, non-duplicated outflows.
 // A payment reduces c.balance; only that remaining balance is forecast on the due date.
 const cardPaymentEvents=creditCards.flatMap(c=>cardPaymentEventsForCashflow(c,from,to));
 const cardDebtEvents=creditCards.filter(c=>Number(c.balance||0)>0).map(c=>{
   const dueDate=String(c.due||c.dueDate||c.paymentDate||'').slice(0,10);
   return {
     date:dueDate,bank:c.bank||'',description:'الرصيد المتبقي المستحق للبطاقة: '+(c.name||''),
     in:0,out:Number(c.balance||0),type:'card-debt',
     details:{'البنك':c.bank||'—','اسم البطاقة':c.name||'—','تاريخ الاستحقاق':dueDate||'غير محدد','المديونية المتبقية':money(c.balance||0),'الحد الائتماني':money(c.limit||0),'الحد الأدنى للسداد':money(c.minimum||0),'ملاحظات':c.notes||'—'}
   };
 }).filter(e=>/^\d{4}-\d{2}-\d{2}$/.test(e.date)&&e.date>=from&&e.date<=to);
 const inPeriod=[...interestEvents,...openingEvents,...expenseEvents,...cardPaymentEvents,...cardDebtEvents]
   .filter(e=>e.date>=from&&e.date<=to).sort((a,b)=>a.date.localeCompare(b.date));
 lastCashflowCalendarEvents=inPeriod;
 const certificateReturns=interestEvents.reduce((a,e)=>a+e.in,0);
 const openingTotal=openingEvents.reduce((a,e)=>a+e.in,0);
 const incoming=certificateReturns+openingTotal;
 const outgoing=inPeriod.reduce((a,e)=>a+e.out,0);
 const cardsWithoutDue=creditCards.filter(c=>Number(c.balance||0)>0&&!/^\d{4}-\d{2}-\d{2}$/.test(String(c.due||c.dueDate||c.paymentDate||'')));
 const net=incoming-outgoing;
 $('flowIn').textContent=money(incoming);
 $('flowOut').textContent=money(outgoing);
 $('flowNet').textContent=money(net);
 $('flowCumulative').textContent=money(net);
 // Make the two components visible, so the total can be reconciled bank by bank.
 const flowInCard=$('flowIn')?.closest('.card');
 if(flowInCard){
   const breakdown=$('flowInBreakdown');
   if(breakdown)breakdown.innerHTML='<div>عوائد الشهادات: '+money(certificateReturns)+'</div><div>أرصدة بداية المدة: '+money(openingTotal)+'</div>'+
     openingByBank.map(o=>'<div>'+esc(o.bank)+' · رصيد بداية المدة: '+money(o.amount)+'</div>').join('');
 }
 const groups={};
 inPeriod.forEach(e=>{
   const key=mode==='monthly'?e.date.slice(0,7):e.date;
   if(!groups[key])groups[key]={in:0,out:0,items:[]};
   groups[key].in+=e.in;groups[key].out+=e.out;groups[key].items.push(e);
 });
 let running=0;
 const rows=Object.keys(groups).sort().map(key=>{
   const g=groups[key],n=g.in-g.out;running+=n;return {key,g,n,running};
 });
 $('flowTable').innerHTML=rows.length?
   '<div class="table-wrap section"><table><tr><th>'+(mode==='monthly'?'الشهر':'التاريخ')+'</th><th>التدفقات الداخلة</th><th>التدفقات الخارجة</th><th>صافي التدفق</th><th>الرصيد التراكمي</th></tr>'+
   rows.map(r=>'<tr><td>'+esc(r.key)+'</td><td>'+money(r.g.in)+'</td><td>'+money(r.g.out)+'</td><td>'+money(r.n)+'</td><td>'+money(r.running)+'</td></tr>').join('')+
   '</table></div><h2 class="section">تفاصيل الحركات خلال الفترة</h2><div class="table-wrap"><table><tr><th>التاريخ</th><th>البنك</th><th>البيان (اضغط للتفاصيل)</th><th>داخل</th><th>خارج</th></tr>'+
   inPeriod.map((e,i)=>'<tr><td>'+esc(e.date)+'</td><td>'+esc(e.bank)+'</td><td><button type="button" class="link-button" data-flow-detail="'+i+'" aria-expanded="false">'+esc(e.description)+' <span aria-hidden="true">⌄</span></button></td><td>'+money(e.in)+'</td><td>'+money(e.out)+'</td></tr><tr id="flowDetail_'+i+'" class="flow-detail-row" hidden><td colspan="5"><div class="flow-detail-box">'+Object.entries(e.details||{}).map(([k,v])=>'<div><strong>'+esc(k)+':</strong> '+esc(String(v))+'</div>').join('')+'</div></td></tr>').join('')+
   '</table></div>'+(cardsWithoutDue.length?'<div class="muted" style="margin-top:8px">تنبيه: توجد '+cardsWithoutDue.length+' بطاقة/بطاقات عليها مديونية دون تاريخ استحقاق صحيح. حدّث تاريخ الاستحقاق من صفحة مديونية البطاقات لتظهر في يومها الصحيح.</div>':''):'<div class="empty">لا توجد حركات مسجلة في الفترة المحددة.</div>';
 drawLineChart('flowTrendChart',rows.map(r=>mode==='monthly'?r.key.slice(5):r.key.slice(8)),rows.map(r=>r.g.in),rows.map(r=>r.g.out));
 drawBars('flowNetChart',rows.map(r=>({label:r.key,value:Math.abs(r.n)})), '#43d6ad');
 const bankNames=[...new Set(certs.map(c=>c.bank).concat(openingByBank.map(o=>o.bank)).filter(Boolean))];
 drawBars('bankCapitalChart',bankNames.map(b=>({label:b,value:certs.filter(c=>c.bank===b).reduce((a,c)=>a+Number(c.principal||0),0)})),'#5d91ff');
 const debtBanks=[...new Set(creditCards.map(c=>c.bank))];
 drawBars('bankDebtChart',debtBanks.map(b=>({label:b,value:creditCards.filter(c=>c.bank===b).reduce((a,c)=>a+Number(c.balance||0),0)})),'#e77aa4');
 renderCashCalendar(inPeriod);
}
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-flow-detail]');
 if(!b)return;
 const i=b.dataset.flowDetail,row=$('flowDetail_'+i);
 if(!row)return;
 const opening=row.hidden;
 row.hidden=!opening;
 b.setAttribute('aria-expanded',String(opening));
 const arrow=b.querySelector('span');if(arrow)arrow.textContent=opening?'⌃':'⌄';
});
document.addEventListener('click',e=>{const b=e.target.closest('[data-ob-delete]');if(b&&confirm('حذف رصيد بداية المدة؟')){const ob=openingBalances.find(x=>x.id===b.dataset.obDelete);if(ob)logOperation('حذف','رصيد بداية مدة',ob.bank,ob.bank,ob.amount,'تاريخ الرصيد '+ob.date);openingBalances=openingBalances.filter(x=>x.id!==b.dataset.obDelete);AStore.setItem(OB_KEY,JSON.stringify(openingBalances));render()}});

/* ══════════ بطاقات الائتمان ══════════ */
function renderCreditCards(){
 const total=creditCards.reduce((a,c)=>a+Number(c.balance||0),0);
 const limits=creditCards.reduce((a,c)=>a+Number(c.limit||0),0);
 const available=creditCards.reduce((a,c)=>a+Math.max(0,Number(c.limit||0)-Number(c.balance||0)),0);
 if($('cardDebtTotal'))$('cardDebtTotal').textContent=money(total);
 $('ccTotal').textContent=money(total);$('ccLimits').textContent=money(limits);$('ccAvailable').textContent=money(available);$('ccCount').textContent=creditCards.length;
 $('ccTable').innerHTML=creditCards.length?'<div class="table-wrap"><table><tr><th>البنك</th><th>البطاقة</th><th>المديونية</th><th>الحد الائتماني</th><th>المتاح</th><th>استحقاق السداد</th><th>الحد الأدنى</th><th>إجراءات</th></tr>'+creditCards.map(c=>'<tr><td>'+esc(c.bank)+'</td><td>'+esc(c.name)+'</td><td>'+money(c.balance)+'</td><td>'+money(c.limit)+'</td><td>'+money(Math.max(0,Number(c.limit||0)-Number(c.balance||0)))+'</td><td>'+esc(c.due||'—')+'</td><td>'+money(c.minimum||0)+'</td><td><button data-cc-edit="'+esc(c.id)+'">تعديل</button> <button data-cc-pay="'+esc(c.id)+'">تسجيل سداد</button> <button class="danger" data-cc-delete="'+esc(c.id)+'">حذف</button></td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد بطاقات ائتمان مسجلة</div>';
}
function saveCreditCard(){
 const v={bank:$('ccBank').value.trim(),name:$('ccName').value.trim(),balance:Number($('ccBalance').value),limit:Number($('ccLimit').value||0),due:$('ccDue').value,minimum:Number($('ccMinimum').value||0),notes:$('ccNotes').value};
 if(!v.bank||!v.name||$('ccBalance').value===''){alert('يرجى إدخال البنك واسم البطاقة والمديونية الحالية');return}
 if(v.limit>0&&v.balance>v.limit){if(!confirm('المديونية أكبر من الحد الائتماني المدخل. هل تريد الحفظ؟'))return}
 const id=$('ccEditId').value;
 if(id){creditCards=creditCards.map(c=>c.id===id?{...c,...v,id,paymentHistory:Array.isArray(c.paymentHistory)?c.paymentHistory:undefined,lastPayment:c.lastPayment}:c);logOperation('تعديل','بطاقة ائتمان',v.name,v.bank,v.balance,'تعديل بيانات البطاقة')}else {creditCards.push({...v,id:crypto.randomUUID()});logOperation('إضافة','بطاقة ائتمان',v.name,v.bank,v.balance,'إضافة بطاقة ائتمان')}
 AStore.setItem(CC_KEY,JSON.stringify(creditCards));resetCCForm();render();alert('تم حفظ بيانات البطاقة');
}
function resetCCForm(){$('ccForm').reset();$('ccEditId').value='';$('ccFormTitle').textContent='إضافة بطاقة ائتمان'}
function editCreditCard(id){const c=creditCards.find(x=>x.id===id);if(!c)return;$('ccEditId').value=id;$('ccBank').value=c.bank;$('ccName').value=c.name;$('ccBalance').value=c.balance;$('ccLimit').value=c.limit;$('ccDue').value=c.due;$('ccMinimum').value=c.minimum;$('ccNotes').value=c.notes||'';$('ccFormTitle').textContent='تعديل بيانات البطاقة';showPage('creditcards');window.scrollTo(0,0)}
function cardPaymentEventsForCashflow(c,from,to){
 return cardPaymentEvents(c).filter(p=>p.date>=from&&p.date<=to).map(p=>({
   date:p.date,bank:c.bank||'',description:'سداد فعلي لبطاقة: '+(c.name||''),
   in:0,out:p.amount,type:'card-payment',
   details:{'البنك':c.bank||'—','اسم البطاقة':c.name||'—','تاريخ السداد':p.date,'مبلغ السداد':money(p.amount),'المديونية المتبقية حالياً':money(c.balance||0)}
 }));
}
function cardPaymentEvents(c){
 const history=Array.isArray(c.paymentHistory)?c.paymentHistory:[];
 // Backward compatibility: older versions stored only the most recent payment.
 const source=history.length?history:(c.lastPayment?[c.lastPayment]:[]);
 return source.filter(x=>x&&/^\d{4}-\d{2}-\d{2}$/.test(String(x.date||''))&&Number(x.amount)>0)
   .map(x=>({date:String(x.date),amount:Number(x.amount),id:x.id||''}));
}
function payCreditCard(id){
 const c=creditCards.find(x=>x.id===id);if(!c)return;
 const amount=Number(prompt('أدخل مبلغ السداد بالجنيه:'));
 if(!Number.isFinite(amount)||amount<=0){alert('أدخل مبلغاً صحيحاً');return}
 if(amount>Number(c.balance)&&!confirm('مبلغ السداد أكبر من المديونية الحالية. هل تريد تسجيله؟'))return;
 const payment={id:crypto.randomUUID(),amount,date:localISODate(new Date())};
 c.balance=Math.max(0,Number(c.balance)-amount);
 c.paymentHistory=Array.isArray(c.paymentHistory)?c.paymentHistory:[];
 c.paymentHistory.push(payment);c.lastPayment=payment;
 logOperation('سداد','بطاقة ائتمان',c.name,c.bank,amount,'المديونية المتبقية '+c.balance);
 AStore.setItem(CC_KEY,JSON.stringify(creditCards));render();alert('تم تسجيل السداد وتحديث المديونية')
}
function deleteCreditCard(id){if(confirm('هل تريد حذف بيانات هذه البطاقة؟')){const card=creditCards.find(x=>x.id===id);if(card)logOperation('حذف','بطاقة ائتمان',card.name,card.bank,card.balance,'حذف بيانات البطاقة');creditCards=creditCards.filter(c=>c.id!==id);AStore.setItem(CC_KEY,JSON.stringify(creditCards));render()}}
document.addEventListener('click',e=>{const a=e.target.closest('[data-cc-edit]'),b=e.target.closest('[data-cc-pay]'),c=e.target.closest('[data-cc-delete]');if(a)editCreditCard(a.dataset.ccEdit);if(b)payCreditCard(b.dataset.ccPay);if(c)deleteCreditCard(c.dataset.ccDelete)});



/* ══════════ كشف حساب البنوك ══════════ */
function normalizeStatementBank(value){
 return String(value||'').normalize('NFKC').replace(/[\u0640\s]+/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').toLowerCase();
}
function normalizeStatementDate(value){
 const v=String(value||'').trim();
 if(/^\d{4}-\d{2}-\d{2}$/.test(v))return v;
 let m=v.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
 if(m)return m[3]+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0');
 m=v.match(/^(\d{4})[\/.-](\d{1,2})[\/.-](\d{1,2})$/);
 if(m)return m[1]+'-'+m[2].padStart(2,'0')+'-'+m[3].padStart(2,'0');
 return v;
}
function statementEvents(){
 const ev=[];
 transactions.forEach(t=>ev.push({date:normalizeStatementDate(t.date),bank:t.bank||'',description:(t.description||'')+' · '+(t.category||''),incoming:t.type==='income'?Number(t.amount||0):0,outgoing:t.type==='expense'?Number(t.amount||0):0,kind:t.type==='income'?'إيراد':'مصروف'}));
 certs.forEach(c=>payments(c).forEach(p=>ev.push({date:normalizeStatementDate(p.date),bank:c.bank||'',description:'عائد شهادة: '+(p.name||c.name||''),incoming:Number(p.amount||0),outgoing:0,kind:'عائد شهادة',certId:c.id})));
 openingBalances.forEach(o=>ev.push({date:normalizeStatementDate(o.date),bank:o.bank||'',description:'رصيد بداية المدة',incoming:Number(o.amount||0),outgoing:0,kind:'رصيد افتتاحي'}));
 creditCards.forEach(c=>{
  // Actual payments are cash outflows. Keep the full history to avoid losing
  // earlier payments when a newer payment is entered.
  cardPaymentEvents(c).forEach(p=>ev.push({date:normalizeStatementDate(p.date),bank:c.bank||'',description:'سداد بطاقة: '+(c.name||''),incoming:0,outgoing:p.amount,kind:'سداد بطاقة',paymentId:p.id}));
 });
 return ev;
}
function localISODate(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
let statementPeriodUserSelected=false;
// Canonical all-banks closing balance, captured from the bank-statement calculation.
let allBanksStatementClosing=0;
function calendarMonthBounds(d=new Date()){
 const y=d.getFullYear(),m=d.getMonth();
 return {from:String(y)+'-'+String(m+1).padStart(2,'0')+'-01',
         to:String(y)+'-'+String(m+1).padStart(2,'0')+'-'+String(new Date(y,m+1,0).getDate()).padStart(2,'0')};
}
function setStatementPeriod(kind){
 const now=new Date(),bounds=calendarMonthBounds(now);
 const from=kind==='year'?String(now.getFullYear())+'-01-01':bounds.from;
 const to=kind==='year'?String(now.getFullYear())+'-12-31':bounds.to;
 statementPeriodUserSelected=true;
 $('statementFrom').value=from;$('statementTo').value=to;renderBankStatement();
}
$('statementFrom')?.addEventListener('change',()=>{
 // Keep the exact date selected by the user; do not force it to the first of the month.
 statementPeriodUserSelected=true;
 renderBankStatement();
});
$('statementTo')?.addEventListener('change',()=>{statementPeriodUserSelected=true;renderBankStatement()});
function renderBankStatement(){
 if(!$('statementBank'))return;
 const all=statementEvents(),banks=[...new Set([...all.map(e=>e.bank),...certs.map(c=>c.bank),...creditCards.map(c=>c.bank),...openingBalances.map(o=>o.bank)].filter(Boolean))].sort();
 const select=$('statementBank'),selected=select.value||'__all';
 select.innerHTML='<option value="__all">جميع البنوك</option>'+banks.map(b=>'<option value="'+esc(b)+'">'+esc(b)+'</option>').join('');
 select.value=banks.includes(selected)?selected:'__all';
 const bounds=calendarMonthBounds(new Date());
 // On first opening, always start on day 1 and end on the true last calendar day.
 // Avoid timezone/UTC date shifts that can turn the range into Oct 31–Nov 29.
 if(!statementPeriodUserSelected){
   $('statementFrom').value=bounds.from;
   $('statementTo').value=bounds.to;
 }
 const from=$('statementFrom').value,to=$('statementTo').value;
 if(from>to){$('statementTable').innerHTML='<div class="empty">تاريخ البداية يجب أن يسبق تاريخ النهاية</div>';return}
 const bank=select.value;
 // Select the latest opening-balance snapshot not later than the report end.
 // For each bank, movements on/before that snapshot date are not rolled into
 // the cumulative balance; movements strictly after it are.
 const openingFor=b=>{
   const key=String(b||'').trim();
   const candidates=openingBalances.filter(o=>String(o.bank||'').trim()===key&&/^\d{4}-\d{2}-\d{2}$/.test(String(o.date||''))&&o.date<=to)
     .sort((a,z)=>String(z.date||'').localeCompare(String(a.date||'')));
   return candidates.length?{date:String(candidates[0].date),amount:Number(candidates[0].amount||0)}:null;
 };
 const relevantBanks=bank==='__all'?[...new Set([...banks,...openingBalances.map(o=>String(o.bank||'').trim())].filter(Boolean))]:[bank];
 const openingRefs=new Map(relevantBanks.map(b=>[b,openingFor(b)]));
 const opening=relevantBanks.reduce((sum,b)=>sum+(openingRefs.get(b)?.amount||0),0);
 const events=all.filter(e=>(bank==='__all'||normalizeStatementBank(e.bank)===normalizeStatementBank(bank))&&e.kind!=='رصيد افتتاحي');
 const actualPeriod=events.filter(e=>e.date>=from&&e.date<=to);
 // A card liability is recognized as an outgoing obligation only on its due date,
 // and only when that due date falls inside the selected statement period.
 const cardDebtRows=creditCards.filter(c=>(bank==='__all'||normalizeStatementBank(c.bank)===normalizeStatementBank(bank))&&Number(c.balance||0)>0).map(c=>({
   date:String(c.due||c.dueDate||c.paymentDate||'').slice(0,10),bank:c.bank||'',
   description:'الرصيد المتبقي المستحق للبطاقة: '+(c.name||''),
   incoming:0,outgoing:Number(c.balance||0),kind:'مديونية بطاقة ائتمان'
 })).filter(e=>/^\d{4}-\d{2}-\d{2}$/.test(e.date)&&e.date>=from&&e.date<=to);
 const period=[...actualPeriod,...cardDebtRows].sort((a,b)=>a.date.localeCompare(b.date));
 const countedPeriod=period.filter(e=>{const ref=openingRefs.get(String(e.bank||'').trim());return !ref||e.date>ref.date;});
 const inc=countedPeriod.reduce((a,e)=>a+Number(e.incoming||0),0),out=countedPeriod.reduce((a,e)=>a+Number(e.outgoing||0),0);
 const statementClosingValue=opening+inc-out;
 if(bank==='__all')allBanksStatementClosing=statementClosingValue;
 $('statementOpening').textContent=money(opening);$('statementIn').textContent=money(inc);$('statementOut').textContent=money(out);$('statementClosing').textContent=money(statementClosingValue);
 if(bank==='__all'){
  const rows=relevantBanks.map(b=>{
    const ref=openingRefs.get(b),op=ref?.amount||0,refDate=ref?.date||'';
    const pe=all.filter(e=>String(e.bank||'').trim()===String(b).trim()&&e.kind!=='رصيد افتتاحي'&&e.date>=from&&e.date<=to&&(!refDate||e.date>refDate));
    const bi=pe.reduce((a,e)=>a+Number(e.incoming||0),0),paidOut=pe.reduce((a,e)=>a+Number(e.outgoing||0),0);
    const debt=cardDebtRows.filter(e=>String(e.bank||'').trim()===String(b).trim()).reduce((a,e)=>a+Number(e.outgoing||0),0);
    const bo=paidOut+debt;return {bank:b,opening:op,in:bi,out:bo,closing:op+bi-bo};
  });
  $('statementBankSummary').innerHTML=rows.length?'<h2>ملخص كل بنك</h2><div class="table-wrap"><table><tr><th>البنك</th><th>رصيد أول الفترة</th><th>داخل</th><th>خارج</th><th>رصيد آخر الفترة</th></tr>'+rows.map(r=>'<tr><td>'+esc(r.bank)+'</td><td>'+money(r.opening)+'</td><td>'+money(r.in)+'</td><td>'+money(r.out)+'</td><td>'+money(r.closing)+'</td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد بنوك أو حركات مسجلة</div>';
 }else $('statementBankSummary').innerHTML='';
 const detail=period.map(e=>({...e})).sort((a,b)=>a.date.localeCompare(b.date)||String(a.bank||'').localeCompare(String(b.bank||''),'ar'));
 // Carry each bank's post-opening movements up to the selected period, then
 // maintain a single shared running balance for the all-banks statement.
 const carriedBeforePeriod=relevantBanks.reduce((sum,b)=>{
   const ref=openingRefs.get(b),refDate=ref?.date||'';
   const prior=all.filter(e=>normalizeStatementBank(e.bank)===normalizeStatementBank(b)&&e.kind!=='رصيد افتتاحي'&&e.date<from&&(!refDate||e.date>refDate));
   return sum+prior.reduce((v,e)=>v+Number(e.incoming||0)-Number(e.outgoing||0),0);
 },0);
 let unifiedRunning=opening+carriedBeforePeriod;
 const runningByBank=new Map(relevantBanks.map(b=>[b,openingRefs.get(b)?.amount||0]));
 const detailWithBalance=detail.map(e=>{
   const b=String(e.bank||'').trim(),bankKey=relevantBanks.find(x=>normalizeStatementBank(x)===normalizeStatementBank(b))||b,ref=openingRefs.get(bankKey),refDate=ref?.date||'';
   const delta=(!refDate||e.date>refDate)?Number(e.incoming||0)-Number(e.outgoing||0):0;
   let balance;
   if(bank==='__all'){
     unifiedRunning+=delta;balance=unifiedRunning;
   }else{
     balance=(runningByBank.get(bankKey)||0)+delta;runningByBank.set(bankKey,balance);
   }
   return {...e,balance};
 });
 const certInfo=c=>'<div class="note section"><b>تفاصيل الشهادة</b><div>اسم الشهادة: '+esc(c.name||'—')+'</div><div>البنك: '+esc(c.bank||'—')+'</div><div>رقم الشهادة: '+esc(c.number||'—')+'</div><div>الحساب: '+esc(c.account||'—')+'</div><div>قيمة الشهادة: '+money(c.principal)+'</div><div>نوع العائد: '+esc(c.interestType||'—')+'</div><div>العائد السنوي: '+esc(c.rate??'—')+'%</div><div>دورية الصرف: '+esc(c.frequency==='monthly'?'شهري':c.frequency==='quarterly'?'ربع سنوي':c.frequency==='annual'?'سنوي':c.frequency||'—')+'</div><div>تاريخ البداية: '+esc(c.start||'—')+'</div><div>تاريخ الاستحقاق: '+esc(c.maturity||'—')+'</div><div>الحالة: '+esc(c.status||'نشطة')+'</div><div>ملاحظات: '+esc(c.notes||'—')+'</div></div>';
 $('statementTable').innerHTML=detail.length?'<h2>تفاصيل كشف الحساب · '+(bank==='__all'?'جميع البنوك':esc(bank))+'</h2><div class="table-wrap"><table><tr><th>التاريخ</th><th>البنك</th><th>البيان</th><th>النوع</th><th>داخل</th><th>خارج</th><th>الرصيد التراكمي</th></tr>'+detailWithBalance.map(e=>'<tr><td>'+esc(e.date)+'</td><td>'+esc(e.bank)+'</td><td>'+(e.certId?'<button type="button" data-statement-cert-detail="'+esc(e.certId)+'">'+esc(e.description)+' · عرض التفاصيل</button>':esc(e.description))+'</td><td>'+esc(e.kind)+'</td><td>'+money(e.incoming)+'</td><td>'+money(e.outgoing)+'</td><td>'+money(e.balance)+'</td></tr>'+(e.certId?'<tr id="statementCertDetail_'+esc(e.certId)+'" hidden><td colspan="7">'+(certs.find(c=>c.id===e.certId)?certInfo(certs.find(c=>c.id===e.certId)):'')+'</td></tr>':'')).join('')+'</table></div>':'<div class="empty">لا توجد حركات في الفترة المحددة لهذا الاختيار</div>';
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-statement-cert-detail]');if(!b)return;const row=$('statementCertDetail_'+b.dataset.statementCertDetail);if(row)row.hidden=!row.hidden});

function statementExportHtml(){
 const bank=$('statementBank')?.value||'__all',from=$('statementFrom')?.value||'',to=$('statementTo')?.value||'';
 const title='AYMAN CASHFLOW · كشف حساب '+(bank==='__all'?'جميع البنوك':bank);
 const summary=$('statementBankSummary')?.innerHTML||'';
 const metrics='<div class="metrics"><div>رصيد ما قبل الفترة: '+esc($('statementOpening')?.textContent||'—')+'</div><div>إجمالي الداخل: '+esc($('statementIn')?.textContent||'—')+'</div><div>إجمالي الخارج: '+esc($('statementOut')?.textContent||'—')+'</div><div>الرصيد الختامي: '+esc($('statementClosing')?.textContent||'—')+'</div></div>';
 return {title,html:'<h2>'+title+'</h2><p>الفترة: '+esc(from)+' إلى '+esc(to)+'</p>'+metrics+summary+($('statementTable')?.innerHTML||'')};
}
function printBankStatement(){
 const d=statementExportHtml();if(!$('statementTable')?.innerHTML){alert('اعرض الكشف أولاً');return}
 const w=window.open('','_blank');if(!w){alert('يرجى السماح بالنوافذ المنبثقة للطباعة');return}
 w.document.open();w.document.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>'+esc(d.title)+'</title><style>body{font-family:Tahoma,Arial,sans-serif;padding:20px;color:#172033}h2{text-align:center;color:#18345d}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:16px 0}.metrics div{border:1px solid #bbb;padding:10px;font-weight:bold}.table-wrap{overflow:visible}table{width:100%;border-collapse:collapse;font-size:11px;margin:12px 0}th,td{border:1px solid #aaa;padding:7px;text-align:right}th{background:#e9eef5}button{display:none}tr{break-inside:avoid}@media print{body{padding:0}}</style></head><body>'+d.html+'</body></html>');w.document.close();w.focus();setTimeout(()=>w.print(),350);
}
function exportBankStatementExcel(){
 if(!$('statementTable')?.querySelector('table')){alert('اعرض الكشف أولاً');return}
 if(!window.XLSX){alert('تعذر تحميل مكتبة Excel. تأكد من الاتصال بالإنترنت.');return}
 const d=statementExportHtml(),wb=XLSX.utils.book_new();
 const addTable=(containerId,sheetName)=>{const table=$(containerId)?.querySelector('table');if(table){const ws=XLSX.utils.table_to_sheet(table,{raw:true});XLSX.utils.book_append_sheet(wb,ws,sheetName)}};
 const meta=XLSX.utils.aoa_to_sheet([[d.title],['الفترة',$('statementFrom').value,$('statementTo').value],['رصيد ما قبل الفترة',$('statementOpening').textContent],['إجمالي الداخل',$('statementIn').textContent],['إجمالي الخارج',$('statementOut').textContent],['الرصيد الختامي',$('statementClosing').textContent]]);
 XLSX.utils.book_append_sheet(wb,meta,'ملخص الكشف');addTable('statementBankSummary','ملخص البنوك');addTable('statementTable','تفاصيل الحركات');
 XLSX.writeFile(wb,'AYMAN_CASHFLOW_BANK_STATEMENT_'+new Date().toISOString().slice(0,10)+'.xlsx');
}



let importDraft=null;
const importSchemas={
 certificates:{label:'الشهادات',headers:['bank','account','name','number','principal','start','maturity','durationYears','interestType','rate','frequency','firstPay','notes'],aliases:{bank:['bank','البنك'],account:['account','الحساب'],name:['name','اسم الشهادة','الشهادة'],number:['number','رقم الشهادة'],principal:['principal','المبلغ','رأس المال'],start:['start','تاريخ البداية','تاريخ الشراء'],maturity:['maturity','تاريخ الاستحقاق'],durationYears:['durationyears','مدة الشهادة','المدة بالسنوات'],interestType:['interesttype','نوع العائد'],rate:['rate','العائد','نسبة العائد'],frequency:['frequency','دورية الصرف'],firstPay:['firstpay','اول تاريخ صرف','أول تاريخ صرف'],notes:['notes','ملاحظات']}},
 creditCards:{label:'البطاقات',headers:['bank','name','balance','limit','due','minimum','notes'],aliases:{bank:['bank','البنك'],name:['name','اسم البطاقة'],balance:['balance','المديونية'],limit:['limit','الحد الائتماني'],due:['due','تاريخ الاستحقاق'],minimum:['minimum','الحد الادنى','الحد الأدنى'],notes:['notes','ملاحظات']}},
 openingBalances:{label:'الأرصدة الافتتاحية',headers:['date','bank','amount'],aliases:{date:['date','التاريخ'],bank:['bank','البنك'],amount:['amount','المبلغ','الرصيد']}},
 transactions:{label:'الإيرادات والمصروفات',headers:['type','date','bank','category','description','amount','notes'],aliases:{type:['type','النوع'],date:['date','التاريخ'],bank:['bank','البنك'],category:['category','التصنيف'],description:['description','البيان'],amount:['amount','المبلغ'],notes:['notes','ملاحظات']}}
};

/* ══════════ استيراد Excel/CSV ══════════ */
function normalizeHeader(v){return String(v||'').trim().toLowerCase().replace(/[\\s_\\-ـ]/g,'')}
function parseCSV(text){let rows=[],row=[],cell='',quoted=false;for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'&&quoted&&text[i+1]==='"'){cell+='"';i++}else if(c==='"'){quoted=!quoted}else if(c===','&&!quoted){row.push(cell);cell=''}else if((c==='\\n'||c==='\\r')&&!quoted){if(c==='\\r'&&text[i+1]==='\\n')i++;row.push(cell);if(row.some(x=>String(x).trim()!==''))rows.push(row);row=[];cell=''}else cell+=c}row.push(cell);if(row.some(x=>String(x).trim()!==''))rows.push(row);return rows}
function downloadImportTemplate(){const type=$('importType').value,schema=importSchemas[type],csv=schema.headers.join(',')+'\\r\\n';const blob=new Blob(['\\ufeff'+csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AYMAN_CASHFLOW_'+type+'_template.csv';a.click();URL.revokeObjectURL(a.href)}
function previewImport(){
 const file=$('importFile').files[0];if(!file){alert('اختر ملفاً أولاً');return}
 const type=$('importType').value,ext=file.name.split('.').pop().toLowerCase();
 const readRows=rows=>{try{if(!rows||rows.length<2)throw Error('الملف لا يحتوي على صفوف بيانات');const schema=importSchemas[type],headers=rows[0].map(normalizeHeader),map={};Object.entries(schema.aliases).forEach(([key,aliases])=>{const idx=headers.findIndex(h=>[key,...aliases].map(normalizeHeader).includes(h));if(idx>=0)map[key]=idx});const required=type==='certificates'?['bank','name','principal','start','rate']:type==='creditCards'?['bank','name','balance']:type==='openingBalances'?['date','bank','amount']:['type','date','bank','amount'];const missing=required.filter(k=>map[k]===undefined);if(missing.length)throw Error('أعمدة مطلوبة غير موجودة: '+missing.join('، '));let valid=[],errors=[];rows.slice(1).forEach((r,i)=>{let o={};schema.headers.forEach(k=>{if(map[k]!==undefined)o[k]=String(r[map[k]]??'').trim()});const rowNo=i+2;const numKeys=type==='certificates'?['principal','rate']:type==='creditCards'?['balance','limit','minimum']:['amount'];numKeys.forEach(k=>{if(o[k]!==undefined)o[k]=Number(String(o[k]).replace(/,/g,''))});if(type==='transactions'){o.type=/^(income|إيراد|ايراد)$/i.test(o.type)?'income':/^(expense|مصروف)$/i.test(o.type)?'expense':o.type}if(type==='certificates'){o.durationYears=Number(o.durationYears)||'';if(!o.maturity&&[1,3,5].includes(o.durationYears)){const md=dateAdd(o.start,o.durationYears*12);o.maturity=dateKeyLocal(md)}o.interestType=o.interestType||'fixed';o.frequency=/ربع|quarter/i.test(o.frequency||'')?'quarterly':/سنوي|annual/i.test(o.frequency||'')?'annual':'monthly';o.status='active'}const bad=!o.bank&&type!=='openingBalances'||(type==='openingBalances'&&!o.bank)||!o.date&&type!=='certificates'&&type!=='creditCards'||numKeys.some(k=>o[k]!==undefined&&!Number.isFinite(o[k]))||numKeys.some(k=>required.includes(k)&&!(o[k]>0))||(type==='certificates'&&(!o.name||!o.start||!o.maturity||o.maturity<o.start))||(type==='transactions'&&!['income','expense'].includes(o.type));if(bad)errors.push({row:rowNo,reason:'بيانات ناقصة أو غير صحيحة'});else valid.push(o)});importDraft={type,valid,errors};$('commitImportBtn').disabled=!valid.length;$('importStatus').textContent='تمت قراءة '+(rows.length-1)+' صفاً: '+valid.length+' صالح، '+errors.length+' به أخطاء. لن يتم حفظ أي شيء قبل الضغط على اعتماد الاستيراد.';const preview=valid.slice(0,10);$('importPreview').innerHTML='<h3>معاينة أول '+preview.length+' صفوف صالحة</h3><div class="table-wrap"><table><tr>'+schema.headers.map(h=>'<th>'+esc(h)+'</th>').join('')+'</tr>'+preview.map(o=>'<tr>'+schema.headers.map(h=>'<td>'+esc(o[h]??'')+'</td>').join('')+'</tr>').join('')+'</table></div>'+(errors.length?'<h3>أخطاء الصفوف</h3><div class="table-wrap"><table><tr><th>رقم الصف</th><th>السبب</th></tr>'+errors.slice(0,20).map(e=>'<tr><td>'+e.row+'</td><td>'+e.reason+'</td></tr>').join('')+'</table></div>':'');}catch(e){importDraft=null;$('commitImportBtn').disabled=true;$('importStatus').textContent=e.message;$('importPreview').innerHTML=''}}
 if(ext==='csv'||ext==='txt'){const r=new FileReader();r.onload=()=>readRows(parseCSV(String(r.result).replace(/^\\ufeff/,'')));r.readAsText(file,'UTF-8')}
 else if(ext==='xlsx'||ext==='xls'){if(!window.XLSX){$('importStatus').textContent='تعذر تحميل قارئ Excel. تأكد من الاتصال بالإنترنت أو احفظ الملف بصيغة CSV.';return}const r=new FileReader();r.onload=e=>{try{const wb=XLSX.read(e.target.result,{type:'array'});readRows(XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,defval:''}))}catch(err){$('importStatus').textContent='تعذر قراءة ملف Excel'}};r.readAsArrayBuffer(file)}
 else $('importStatus').textContent='صيغة الملف غير مدعومة. استخدم CSV أو XLSX.';
}
function commitImport(){
 if(!importDraft||!importDraft.valid.length)return;
 const {type,valid}=importDraft;let target=type==='certificates'?certs:type==='creditCards'?creditCards:type==='openingBalances'?openingBalances:transactions;
 const keyFor=o=>type==='certificates'?[o.bank,o.name,o.number,o.start].join('|'):type==='creditCards'?[o.bank,o.name].join('|'):type==='openingBalances'?[o.bank,o.date,o.amount].join('|'):[o.type,o.date,o.bank,o.description,o.amount].join('|');
 const existing=new Set(target.map(keyFor));const fresh=valid.filter(o=>!existing.has(keyFor(o)));const duplicates=valid.length-fresh.length;
 if(!fresh.length){alert('كل الصفوف موجودة بالفعل أو مكررة. لم تتم إضافة بيانات.');return}
 if(!confirm('سيتم إضافة '+fresh.length+' سجل جديد وتجاهل '+duplicates+' سجل مكرر. يُفضّل تنزيل نسخة احتياطية أولاً. هل تعتمد الاستيراد؟'))return;
 fresh.forEach(o=>target.push({...o,id:crypto.randomUUID()}));
 AStore.setItem(KEY,JSON.stringify(certs));AStore.setItem(CC_KEY,JSON.stringify(creditCards));AStore.setItem(OB_KEY,JSON.stringify(openingBalances));AStore.setItem(TXN_KEY,JSON.stringify(transactions));logOperation('استيراد','استيراد بيانات',importSchemas[type].label,'',fresh.length,'إضافة '+fresh.length+' سجل وتجاهل '+duplicates+' مكرر');importDraft=null;$('commitImportBtn').disabled=true;$('importPreview').innerHTML='';$('importStatus').textContent='اكتمل الاستيراد بنجاح.';render();alert('تم استيراد '+fresh.length+' سجل بنجاح، وتجاهل '+duplicates+' مكرر.');
}


let currentReport=null;

/* ══════════ التقارير والطباعة ══════════ */
function setReportPeriod(kind){
 const now=new Date(),from=kind==='year'?new Date(now.getFullYear(),0,1):new Date(now.getFullYear(),now.getMonth(),1),to=kind==='year'?new Date(now.getFullYear(),11,31):new Date(now.getFullYear(),now.getMonth()+1,0);
 // Use local calendar dates; toISOString() shifts dates in UTC+ time zones.
 $('reportFrom').value=localISODate(from);$('reportTo').value=localISODate(to);generateReport();
}
function generateReport(){
 const bankSel=$('reportBank'),allEvents=statementEvents();
 const banks=[...new Set([...allEvents.map(e=>e.bank),...certs.map(c=>c.bank),...creditCards.map(c=>c.bank),...openingBalances.map(o=>o.bank)].filter(Boolean))].sort();
 const selected=bankSel.value||'__all';
 bankSel.innerHTML='<option value="__all">جميع البنوك</option>'+banks.map(b=>'<option value="'+esc(b)+'">'+esc(b)+'</option>').join('');
 bankSel.value=banks.includes(selected)?selected:'__all';
 const now=new Date(),from=$('reportFrom').value||localISODate(new Date(now.getFullYear(),now.getMonth(),1)),to=$('reportTo').value||localISODate(new Date(now.getFullYear(),now.getMonth()+1,0)),bank=bankSel.value;
 if(from>to){$('reportStatus').textContent='تاريخ البداية يجب أن يسبق تاريخ النهاية';return}
 const events=allEvents.filter(e=>e.kind!=='رصيد افتتاحي'&&(bank==='__all'||e.bank===bank)&&e.date>=from&&e.date<=to).sort((a,b)=>a.date.localeCompare(b.date));
 // Include the currently outstanding credit-card balance in the report's outgoing total.
 // This is shown as a separate liability line so it is not confused with an actual cash payment.
 const cardDebtEvents=creditCards.filter(c=>(bank==='__all'||c.bank===bank)&&Number(c.balance||0)>0).map(c=>({
   date:String(c.due||c.dueDate||c.paymentDate||'').slice(0,10),
   bank:c.bank||'',description:'الرصيد المتبقي المستحق للبطاقة: '+(c.name||''),
   incoming:0,outgoing:Number(c.balance||0),kind:'مديونية بطاقة ائتمان'
 })).filter(e=>/^\d{4}-\d{2}-\d{2}$/.test(e.date)&&e.date>=from&&e.date<=to);
 const selectedBanks=bank==='__all'
   ?[...new Set([...banks,...openingBalances.map(o=>String(o.bank||'').trim()).filter(Boolean)])]
   :[bank];
 const openingBalanceEvents=selectedBanks.map(b=>{
   const snapshots=openingBalances.filter(o=>String(o.bank||'').trim()===String(b||'').trim()&&String(o.date||'')<=to)
     .sort((a,z)=>String(z.date||'').localeCompare(String(a.date||'')));
   const latest=snapshots[0];
   return latest&&latest.date>=from?{date:latest.date,bank:b,description:'رصيد بداية المدة',incoming:Number(latest.amount||0),outgoing:0,kind:'رصيد افتتاحي'}:null;
 }).filter(Boolean);
 const reportEvents=[...events,...openingBalanceEvents,...cardDebtEvents].sort((a,b)=>a.date.localeCompare(b.date));
 // Opening balance is the latest saved opening-balance amount for each selected bank,
 // regardless of the record's date. Do not roll historical transactions or certificate
 // returns into this figure; period movements are calculated separately below.
 let prior=0;
 selectedBanks.forEach(b=>{
   const snapshots=openingBalances
     .filter(o=>String(o.bank||'').trim()===String(b||'').trim()&&String(o.date||'')<=from)
     .sort((a,z)=>String(z.date||'').localeCompare(String(a.date||'')));
   if(snapshots.length)prior+=Number(snapshots[0].amount||0);
 });
 const incoming=reportEvents.reduce((a,e)=>a+Number(e.incoming||0),0),outgoing=reportEvents.reduce((a,e)=>a+Number(e.outgoing||0),0);
 const certList=certs.filter(c=>bank==='__all'||c.bank===bank),cards=creditCards.filter(c=>bank==='__all'||c.bank===bank);
 const incomeTx=transactions.filter(t=>t.type==='income'&&(bank==='__all'||t.bank===bank)&&t.date>=from&&t.date<=to).reduce((a,t)=>a+Number(t.amount||0),0);
 const expenseTx=transactions.filter(t=>t.type==='expense'&&(bank==='__all'||t.bank===bank)&&t.date>=from&&t.date<=to).reduce((a,t)=>a+Number(t.amount||0),0);
 currentReport={from,to,bank,events:reportEvents,prior,incoming,outgoing,closing:prior+incoming-outgoing,certList,cards,incomeTx,expenseTx,cardDebt:cardDebtEvents.reduce((a,e)=>a+e.outgoing,0)};
 const reportType=$('reportType')?.value||'all';currentReport.type=reportType;
 const status=c=>c.status==='closed'?'مغلقة':c.status==='cancelled'?'ملغاة':'نشطة';
 const movementTable=reportEvents.length?'<div class="table-wrap"><table><tr><th>التاريخ</th><th>البنك</th><th>البيان</th><th>النوع</th><th>داخل</th><th>خارج</th></tr>'+reportEvents.map(e=>'<tr><td>'+esc(e.date)+'</td><td>'+esc(e.bank)+'</td><td>'+esc(e.description)+'</td><td>'+esc(e.kind)+'</td><td>'+money(e.incoming)+'</td><td>'+money(e.outgoing)+'</td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد حركات خلال الفترة</div>';
 if(reportType==='certificates'){
   const certRows=certList.map(c=>'<tr><td>'+esc(c.name)+'</td><td>'+money(c.principal)+'</td><td>'+esc(c.rate)+'%</td><td>'+esc(c.payoutFrequency||c.frequency||'—')+'</td><td>'+esc(c.startDate||c.start||'—')+'</td><td>'+esc(c.maturity||'—')+'</td><td>'+status(c)+'</td></tr>').join('');
   $('financialReport').innerHTML='<div id="printReport"><h2>AYMAN CASHFLOW · بيان شهادات '+esc(bank==='__all'?'جميع البنوك':bank)+'</h2><p>تاريخ التقرير: '+new Date().toLocaleDateString('en-GB')+'</p><div class="table-wrap"><table><tr><th>الشهادة</th><th>رأس المال</th><th>العائد %</th><th>دورية الصرف</th><th>تاريخ الشراء</th><th>الاستحقاق</th><th>الحالة</th></tr>'+certRows+'</table></div></div>';
   $('reportStatus').textContent='بيان الشهادات جاهز · '+certList.length+' شهادة';return;
 }
 if(reportType==='cashflow'){
   $('financialReport').innerHTML='<div id="printReport"><h2>AYMAN CASHFLOW · تقرير التدفقات النقدية</h2><p>'+from+' إلى '+to+' · '+esc(bank==='__all'?'جميع البنوك':bank)+'</p><div class="grid"><div class="card">رصيد أول الفترة: '+money(prior)+'</div><div class="card">إجمالي الداخل: '+money(incoming)+'</div><div class="card">إجمالي الخارج: '+money(outgoing)+'</div><div class="card">صافي التدفق: '+money(incoming-outgoing)+'</div><div class="card">الرصيد الختامي: '+money(prior+incoming-outgoing)+'</div></div>'+movementTable+'</div>';
   $('reportStatus').textContent='تقرير التدفقات النقدية جاهز · '+reportEvents.length+' حركة';return;
 }
 const label=bank==='__all'?'جميع البنوك':bank;
 const certTable=certList.length?'<div class="table-wrap"><table><tr><th>الشهادة</th><th>البنك</th><th>رأس المال</th><th>العائد الأساسي</th><th>الاستحقاق</th><th>الحالة</th></tr>'+certList.map(c=>'<tr><td>'+esc(c.name)+'</td><td>'+esc(c.bank)+'</td><td>'+money(c.principal)+'</td><td>'+esc(c.rate)+'%</td><td>'+esc(c.maturity)+'</td><td>'+status(c)+'</td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد شهادات</div>';
 const cardTable=cards.length?'<div class="table-wrap"><table><tr><th>البنك</th><th>البطاقة</th><th>المديونية الحالية</th><th>الحد الائتماني</th><th>المتاح</th><th>الاستحقاق</th></tr>'+cards.map(c=>'<tr><td>'+esc(c.bank)+'</td><td>'+esc(c.name)+'</td><td>'+money(c.balance)+'</td><td>'+money(c.limit)+'</td><td>'+money(Math.max(0,Number(c.limit||0)-Number(c.balance||0)))+'</td><td>'+esc(c.due||'—')+'</td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد بطاقات</div>';
 $('financialReport').innerHTML='<div id="printReport"><div class="report-heading"><h2>AYMAN CASHFLOW</h2><h3>التقرير المالي</h3><p>الفترة: '+from+' إلى '+to+' · '+label+'</p></div><div class="grid"><div class="card metric-card"><div class="metric-label">رصيد أول الفترة</div><div class="metric">'+money(prior)+'</div></div><div class="card metric-card"><div class="metric-label">إجمالي الداخل</div><div class="metric">'+money(incoming)+'</div></div><div class="card metric-card"><div class="metric-label">إجمالي الخارج</div><div class="metric">'+money(outgoing)+'</div></div><div class="card metric-card"><div class="metric-label">منها مديونية بطاقات الائتمان القائمة</div><div class="metric">'+money(currentReport.cardDebt)+'</div></div><div class="card metric-card"><div class="metric-label">صافي التدفق</div><div class="metric">'+money(incoming-outgoing)+'</div></div><div class="card metric-card"><div class="metric-label">الرصيد الختامي</div><div class="metric">'+money(prior+incoming-outgoing)+'</div></div></div><h3>ملخص الإيرادات والمصروفات المسجلة</h3><p>إيرادات أخرى: '+money(incomeTx)+' · مصروفات أخرى: '+money(expenseTx)+' · الصافي: '+money(incomeTx-expenseTx)+'</p><h3>حركة الحسابات</h3>'+movementTable+'<h3>ملخص الشهادات</h3>'+certTable+'<h3>ملخص بطاقات الائتمان</h3>'+cardTable+'<p class="muted">تم إنشاء التقرير بواسطة AYMAN CASHFLOW · '+new Date().toLocaleDateString('ar-EG')+'</p></div>';
 $('reportStatus').textContent='التقرير جاهز للفترة من '+from+' إلى '+to+' · '+label+' · '+events.length+' حركة';
}
function csvCell(v){let x=String(v??'');return '"'+x.replace(/"/g,'""')+'"'}
function exportReportCSV(){
 if(!currentReport)generateReport();if(!currentReport)return;
 const r=currentReport;
 const rows=r.type==='certificates'?[['البنك','الشهادة','رأس المال','العائد %','الاستحقاق','الحالة'],...r.certList.map(c=>[c.bank,c.name,c.principal,c.rate,c.maturity,c.status])]:[['التاريخ','البنك','البيان','النوع','داخل (ج.م)','خارج (ج.م)'],...r.events.map(e=>[e.date,e.bank,e.description,e.kind,e.incoming,e.outgoing])];
 const csv='\\ufeff'+rows.map(row=>row.map(csvCell).join(',')).join('\\r\\n');
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AYMAN_CASHFLOW_Report_'+r.from+'_to_'+r.to+'.csv';a.click();URL.revokeObjectURL(a.href);
}
function printFinancialReport(){
 if(!currentReport)generateReport();if(!currentReport)return;
 const content=$('printReport');if(!content){alert('أنشئ التقرير أولاً');return}
 const w=window.open('','_blank');if(!w){alert('اسمح بفتح النوافذ المنبثقة للطباعة');return}
 const printHtml=`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>AYMAN CASHFLOW Report</title><style>
 body{font-family:Tahoma,Arial,sans-serif;color:#172033;padding:24px}
 h2,h3{color:#15294a}table{width:100%;border-collapse:collapse;margin:12px 0 24px;font-size:11px}
 th,td{border:1px solid #bbb;padding:7px;text-align:right}th{background:#e9eef5}
 .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
 .metric-card{border:1px solid #ccc;padding:10px}.metric{font-weight:bold;margin-top:8px}
 .report-heading{text-align:center;margin-bottom:20px}.muted{color:#666;font-size:10px}
 @media print{body{padding:0}tr{break-inside:avoid}h3{break-after:avoid}}
 </style></head><body>${content.innerHTML}
</body></html>`;
 w.document.open();w.document.write(printHtml);w.document.close();w.focus();setTimeout(()=>w.print(),350);
}


/* ══════════ تصدير/استيراد الشهادات ══════════ */
function exportCertificatesFile(){
  try{
    if(typeof XLSX==='undefined')throw new Error('مكتبة Excel غير متاحة. اتصل بالإنترنت ثم أعد المحاولة.');
    const rows=certs.map(c=>{
      const row={};
      Object.keys(c).forEach(k=>{
        const v=c[k];
        row[k]=(v!==null && typeof v==='object')?JSON.stringify(v):v;
      });
      return row;
    });
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(rows),'الشهادات');
    const info=XLSX.utils.aoa_to_sheet([
      ['AYMAN CASHFLOW - ملف الشهادات'],
      ['تاريخ التصدير',new Date().toISOString()],
      ['عدد الشهادات',certs.length],
      ['ملاحظة','لا تحذف الأعمدة أو تغيّر أسماء الحقول عند إعادة الاستيراد.']
    ]);
    XLSX.utils.book_append_sheet(wb,info,'معلومات');
    XLSX.writeFile(wb,'AYMAN_CASHFLOW_CERTIFICATES_'+new Date().toISOString().slice(0,10)+'.xlsx');
    alert('تم تصدير '+certs.length+' شهادة إلى ملف Excel بنجاح.');
  }catch(err){alert('تعذر تصدير الشهادات: '+err.message);}
}
function importCertificatesFile(event){
  const input=event.target,file=input.files&&input.files[0];
  if(!file)return;
  const reader=new FileReader();
  reader.onload=function(){
    try{
      if(typeof XLSX==='undefined')throw new Error('مكتبة Excel غير متاحة. اتصل بالإنترنت ثم أعد المحاولة.');
      const wb=XLSX.read(reader.result,{type:'array',cellDates:false});
      const sheetName=wb.SheetNames.find(n=>n==='الشهادات')||wb.SheetNames[0];
      if(!sheetName)throw new Error('ملف Excel لا يحتوي على ورقة بيانات.');
      const rows=XLSX.utils.sheet_to_json(wb.Sheets[sheetName],{defval:'',raw:false});
      if(!rows.length)throw new Error('ورقة الشهادات فارغة.');
      const incoming=rows.map((row,index)=>{
        const item={...row};
        ['rateChanges'].forEach(k=>{
          if(typeof item[k]==='string'&&item[k].trim()){
            try{item[k]=JSON.parse(item[k]);}catch(e){throw new Error('تعذر قراءة '+k+' في الصف '+(index+2));}
          }
        });
        ['principal','rate','closeAmount'].forEach(k=>{
          if(item[k]!==''&&item[k]!==undefined&&Number.isFinite(Number(item[k])))item[k]=Number(item[k]);
        });
        ['id','bank','name','start','maturity'].forEach(k=>{if(item[k]!==undefined)item[k]=String(item[k]);});
        if(!item.bank||!item.name)throw new Error('بيانات البنك أو اسم الشهادة ناقصة في الصف '+(index+2));
        return item;
      });
      if(!confirm('سيتم دمج '+incoming.length+' شهادة من ملف Excel مع الشهادات الحالية. إذا تطابق معرّف الشهادة سيتم تحديثها. هل تريد المتابعة؟'))return;
      const map=new Map(certs.map(c=>[String(c.id||''),c]));
      let added=0,updated=0;
      incoming.forEach((item,index)=>{
        if(!item.id)item.id=(crypto&&crypto.randomUUID)?crypto.randomUUID():'import-'+Date.now()+'-'+index;
        const key=String(item.id);
        if(map.has(key))updated++;else added++;
        map.set(key,item);
      });
      certs=Array.from(map.values());
      AStore.setItem(KEY,JSON.stringify(certs));
      if(typeof logOperation==='function')logOperation('استيراد','ملف الشهادات','استيراد '+incoming.length+' شهادة','','','إضافة '+added+' وتحديث '+updated+' من Excel');
      if(typeof render==='function')render();
      alert('تم استيراد ملف Excel بنجاح.\\nشهادات جديدة: '+added+'\\nشهادات محدثة: '+updated);
    }catch(err){alert('تعذر استيراد ملف Excel: '+err.message);}
    finally{input.value='';}
  };
  reader.onerror=function(){alert('تعذر قراءة الملف المحدد.');input.value='';};
  reader.readAsArrayBuffer(file);
}

const ALERT_PREF_KEY='ayman_cashflow_alert_settings_v1';
let alertSettings=JSON.parse(AStore.getItem(ALERT_PREF_KEY)||'{"leadDays":7}');
function localISO(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function dayDiff(from,to){return Math.round((new Date(to+'T12:00:00')-new Date(from+'T12:00:00'))/86400000)}

/* ══════════ التنبيهات ══════════ */
function buildAlerts(){
 const today=localISO(new Date()),lead=Math.max(0,Math.min(90,Number(alertSettings.leadDays)||0)),items=[];
 certs.forEach(c=>{
  if(c.status&&c.status!=='active')return;
  payments(c).forEach(p=>items.push({date:p.date,type:'interest',title:'موعد صرف عائد شهادة',detail:(c.name||'شهادة')+' · '+(c.bank||''),amount:p.amount}));
  if(c.maturity)items.push({date:String(c.maturity),type:'maturity',title:'استحقاق شهادة',detail:(c.name||'شهادة')+' · '+(c.bank||''),amount:Number(c.principal||0),certId:c.id});
 });
 creditCards.forEach(c=>{const due=String(c.due||c.dueDate||c.paymentDate||'').slice(0,10);if(/^\d{4}-\d{2}-\d{2}$/.test(due))items.push({date:due,type:'card',title:'موعد سداد بطاقة ائتمان',detail:(c.name||'بطاقة')+' · '+(c.bank||''),amount:Number(c.minimum||0),cardBalance:Number(c.balance||0)});});
 return items.filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(String(x.date||''))).map(x=>({...x,days:dayDiff(today,x.date)})).sort((a,b)=>a.date.localeCompare(b.date));
}
function saveAlertSettings(){
 const n=Number($('alertLeadDays').value);
 if(!Number.isInteger(n)||n<0||n>90){alert('أدخل عدداً من 0 إلى 90 يوماً');return}
 alertSettings.leadDays=n;alertSettings.typeFilter=$('alertTypeFilter')?.value||'all';AStore.setItem(ALERT_PREF_KEY,JSON.stringify(alertSettings));renderAlerts();alert('تم حفظ إعدادات التنبيهات');
}
function renderAlerts(){
 if(!$('alertList'))return;
 $('alertLeadDays').value=alertSettings.leadDays??7;
 const typeFilter=$('alertTypeFilter')?.value||alertSettings.typeFilter||'all';
 $('alertTypeFilter').value=typeFilter;
 const completeAlerts=buildAlerts();const all=completeAlerts.filter(x=>(typeFilter==='all'||x.type===typeFilter)&&x.days<=Math.max(0,Math.min(90,Number(alertSettings.leadDays)||0)));
 const overdue=all.filter(x=>x.days<0),today=all.filter(x=>x.days===0),upcoming=all.filter(x=>x.days>0);
 $('alertOverdueCount').textContent=overdue.length;$('alertTodayCount').textContent=today.length;$('alertUpcomingCount').textContent=upcoming.length;
 const viewFilter=$('alertFilter')?.value||alertSettings.viewFilter||'all';
 if($('alertFilter'))$('alertFilter').value=viewFilter;
 alertSettings.viewFilter=viewFilter;
 const label=x=>x.days<0?'متأخر '+Math.abs(x.days)+' يوم':x.days===0?'اليوم':'بعد '+x.days+' يوم';
 const table=list=>list.length?'<div class="table-wrap"><table><tr><th>التاريخ</th><th>نوع التنبيه</th><th>التفاصيل</th><th>المبلغ</th><th>الحالة</th></tr>'+list.map(x=>'<tr><td>'+esc(x.date)+'</td><td>'+esc(x.title)+'</td><td>'+esc(x.detail)+'</td><td>'+money(x.amount)+'</td><td>'+(x.type==='card'?money(x.cardBalance||0):'—')+'</td><td>'+label(x)+'</td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد تنبيهات في هذا القسم</div>';
 $('alertOverdueList').innerHTML=table(overdue);$('alertTodayList').innerHTML=table(today);$('alertUpcomingList').innerHTML=table(upcoming);
 const allMaturities=completeAlerts.filter(x=>x.type==='maturity'&&x.days>=0&&(typeFilter==='all'||typeFilter==='maturity'));const allCards=completeAlerts.filter(x=>x.type==='card'&&(typeFilter==='all'||typeFilter==='card'));$('alertAllMaturities').innerHTML=table(allMaturities);$('alertAllCards').innerHTML=table(allCards);
 const sections=[['overdue',$('alertOverdueList').parentElement],['today',$('alertTodayList').parentElement],['upcoming',$('alertUpcomingList').parentElement]];
 sections.forEach(([key,el])=>{if(el)el.style.display=(viewFilter==='all'||viewFilter===key)?'':'none'});
 AStore.setItem(ALERT_PREF_KEY,JSON.stringify(alertSettings));
 const perm=('Notification'in window)?Notification.permission:'غير مدعوم';
 $('notificationPermission').textContent=perm==='granted'?'إشعارات المتصفح مفعلة. ستظهر عند فتح التطبيق أو تحديثه.':perm==='denied'?'تم حظر الإشعارات من إعدادات المتصفح. يمكنك تعديل الإذن من إعدادات الموقع.':'إشعارات المتصفح: '+(perm==='default'?'لم يتم منح الإذن بعد':'غير مدعومة في هذا المتصفح')+'. التنبيهات داخل التطبيق تظل متاحة.';
}
function enableBrowserNotifications(){
 if(!('Notification'in window)){alert('هذا المتصفح لا يدعم إشعارات سطح المكتب');return}
 Notification.requestPermission().then(permission=>{renderAlerts();if(permission==='granted'){new Notification('AYMAN CASHFLOW',{body:'تم تفعيل إشعارات التطبيق أثناء تشغيله.'})}else alert('لم يتم السماح بالإشعارات. يمكنك تفعيلها من إعدادات المتصفح.')});
}
function notifyDueItems(){
 if(!('Notification'in window)||Notification.permission!=='granted')return;
 const today=localISO(new Date()),key='ayman_cashflow_notified_'+today;
 if(AStore.getItem(key))return;
 const due=buildAlerts().filter(x=>x.days<=0);
 if(due.length){new Notification('AYMAN CASHFLOW · تذكير مالي',{body:'لديك '+due.length+' موعد متأخر أو مستحق اليوم. افتح قسم التنبيهات للتفاصيل.'});}
 AStore.setItem(key,'1');
}


/* ══════════ سجل العمليات ══════════ */
function renderAuditLog(){
 const root=$('auditTable');if(!root)return;
 const from=$('auditFrom')?.value||'',to=$('auditTo')?.value||'',bank=($('auditBank')?.value||'').trim().toLowerCase(),type=$('auditType')?.value||'';
 const list=auditLog.filter(x=>(!from||x.date>=from)&&(!to||x.date<=to)&&(!bank||String(x.bank||'').toLowerCase().includes(bank))&&(!type||x.type===type));
 $('auditSummary').innerHTML='<div class="pill">إجمالي العمليات: '+auditLog.length+' · النتائج المعروضة: '+list.length+'</div>';
 root.innerHTML=list.length?'<div class="table-wrap"><table><tr><th>التاريخ والوقت</th><th>العملية</th><th>النوع</th><th>الاسم / البيان</th><th>البنك</th><th>القيمة</th><th>التفاصيل</th></tr>'+list.map(x=>'<tr><td>'+esc(new Date(x.timestamp).toLocaleString('ar-EG'))+'</td><td>'+esc(x.type)+'</td><td>'+esc(x.entity)+'</td><td>'+esc(x.name)+'</td><td>'+esc(x.bank||'—')+'</td><td>'+(x.amount===''?'—':money(x.amount))+'</td><td>'+esc(x.details||'—')+'</td></tr>').join('')+'</table></div>':'<div class="empty">لا توجد عمليات مطابقة للفلاتر. العمليات الجديدة ستظهر هنا تلقائياً.</div>';
}
function clearAuditFilters(){['auditFrom','auditTo','auditBank','auditType'].forEach(id=>$(id).value='');renderAuditLog()}
function exportAuditCSV(){const from=$('auditFrom')?.value||'',to=$('auditTo')?.value||'',bank=($('auditBank')?.value||'').trim().toLowerCase(),type=$('auditType')?.value||'';const list=auditLog.filter(x=>(!from||x.date>=from)&&(!to||x.date<=to)&&(!bank||String(x.bank||'').toLowerCase().includes(bank))&&(!type||x.type===type));const rows=[['التاريخ والوقت','العملية','النوع','الاسم / البيان','البنك','القيمة','التفاصيل'],...list.map(x=>[x.timestamp,x.type,x.entity,x.name,x.bank,x.amount,x.details])];const csv='\ufeff'+rows.map(r=>r.map(csvCell).join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AYMAN_CASHFLOW_Audit_Log.csv';a.click();URL.revokeObjectURL(a.href)}


let selectedBankForCertificates='';
document.addEventListener('click',e=>{const b=e.target.closest('[data-bank-cert-details]');if(b)showBankCertificates(b.getAttribute('data-bank-cert-details'))});

/* ══════════ شهادات كل بنك ══════════ */
function bankCertificateRows(bank){return certs.filter(c=>c.bank===bank).sort((a,b)=>(a.name||'').localeCompare(b.name||'','ar')).map(c=>({bank:c.bank||'',account:c.account||'',name:c.name||'',number:c.number||'',principal:Number(c.principal)||0,rate:c.rate||'',frequency:({monthly:'شهري',quarterly:'ربع سنوي',annual:'سنوي'}[c.frequency]||c.frequency||''),start:c.start||'',maturity:c.maturity||'',status:({active:'نشطة',closed:'مغلقة',cancelled:'ملغاة'}[c.status||'active']||c.status||'نشطة'),notes:c.notes||''}));}
function showBankCertificates(bank){selectedBankForCertificates=bank;const rows=bankCertificateRows(bank);$('bankCertificatesTitle').textContent='بيان شهادات '+bank+' · '+rows.length+' شهادة';const headers=['البنك','الحساب','اسم الشهادة','رقم الشهادة','رأس المال','العائد %','دورية الصرف','تاريخ الشراء','تاريخ الاستحقاق','الحالة','ملاحظات'];$('bankCertificatesTable').innerHTML=rows.length?'<div class="table-wrap"><table><tr>'+headers.map(x=>'<th>'+x+'</th>').join('')+'</tr>'+rows.map(r=>'<tr>'+[r.bank,r.account,r.name,r.number,money(r.principal),r.rate,r.frequency,r.start,r.maturity,r.status,r.notes].map(x=>'<td>'+esc(String(x||'—'))+'</td>').join('')+'</tr>').join('')+'</table></div>':'<div class="empty">لا توجد شهادات مسجلة لهذا البنك.</div>';$('bankCertificatesModal').style.display='block';$('bankCertificatesModal').scrollIntoView({behavior:'smooth',block:'start'});}
function closeBankCertificates(){$('bankCertificatesModal').style.display='none';selectedBankForCertificates=''}
function bankCertificatesExportData(){const rows=bankCertificateRows(selectedBankForCertificates);return {rows,aoa:[['البنك','الحساب','اسم الشهادة','رقم الشهادة','رأس المال','العائد %','دورية الصرف','تاريخ الشراء','تاريخ الاستحقاق','الحالة','ملاحظات'],...rows.map(r=>[r.bank,r.account,r.name,r.number,r.principal,r.rate,r.frequency,r.start,r.maturity,r.status,r.notes])]}}
function exportBankCertificatesCSV(){if(!selectedBankForCertificates)return;const d=bankCertificatesExportData();const csv='\ufeff'+d.aoa.map(r=>r.map(csvCell).join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AYMAN_CASHFLOW_Certificates_'+selectedBankForCertificates+'.csv';a.click();URL.revokeObjectURL(a.href)}
function exportBankCertificatesExcel(){if(!selectedBankForCertificates)return;const d=bankCertificatesExportData();if(window.XLSX){const ws=XLSX.utils.aoa_to_sheet(d.aoa),wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'الشهادات');XLSX.writeFile(wb,'AYMAN_CASHFLOW_Certificates.xlsx')}else exportBankCertificatesCSV()}
function printBankCertificates(){if(!selectedBankForCertificates)return;const content=$('bankCertificatesTable').innerHTML;const w=window.open('','_blank');if(!w){alert('يرجى السماح بالنوافذ المنبثقة للطباعة');return}w.document.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>بيان شهادات '+esc(selectedBankForCertificates)+'</title><style>body{font-family:Tahoma,Arial,sans-serif;padding:20px;color:#172033}h2{text-align:center}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #999;padding:7px;text-align:right}th{background:#e9eef5}@media print{tr{break-inside:avoid}}<\\/style></head><body><h2>AYMAN CASHFLOW – بيان شهادات '+esc(selectedBankForCertificates)+'</h2><p>تاريخ الطباعة: '+new Date().toLocaleDateString('ar-EG')+'</p>'+content+'</body></html>');w.document.close();w.focus();setTimeout(()=>w.print(),300)}


/* ══════════ النسخ الاحتياطي والاستعادة ══════════ */
function currentBackupObject(){return {app:'AYMAN CASHFLOW',version:4,createdAt:new Date().toISOString(),certificates:certs,creditCards:creditCards,openingBalances:openingBalances,transactions:transactions,auditLog:auditLog};}
function backup(){let blob=new Blob([JSON.stringify(currentBackupObject(),null,2)],{type:'application/json'});let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ayman-cashflow-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
let restoreCandidate=null;
function validateFullBackup(x){if(!x||typeof x!=='object'||Array.isArray(x)||x.app!=='AYMAN CASHFLOW'||![3,4].includes(Number(x.version)))throw new Error('ليس ملف نسخة احتياطية كاملة أو أن إصداره غير مدعوم');for(const k of ['certificates','creditCards','openingBalances','transactions','auditLog'])if(!Array.isArray(x[k]))throw new Error('النسخة غير مكتملة: '+k);return x;}
function previewRestore(){const f=$('restoreFile').files[0],box=$('restorePreview');restoreCandidate=null;if(!f){box.innerHTML='اختر ملف JSON أولاً.';return}if(!/\.json$/i.test(f.name)){box.innerHTML='الاستعادة تقبل ملفات JSON الخاصة بالنسخة الكاملة فقط. استخدم قسم استيراد Excel للملفات الجدولية.';return}const r=new FileReader();r.onload=()=>{try{const x=validateFullBackup(JSON.parse(r.result));restoreCandidate=x;const dt=x.createdAt?new Date(x.createdAt).toLocaleString('ar-EG'):'غير مسجل في هذه النسخة';box.innerHTML='<div class="note"><b>النسخة صالحة للاستعادة</b><br>إصدار النسخة: '+esc(String(x.version))+'<br>تاريخ الإنشاء: '+esc(dt)+'<br>عدد الشهادات: '+x.certificates.length+'<br>عدد البطاقات: '+x.creditCards.length+'<br>عدد الحركات: '+x.transactions.length+'<br>الأرصدة الافتتاحية: '+x.openingBalances.length+'<br>سجلات التدقيق: '+x.auditLog.length+'</div>';}catch(e){box.textContent='تعذر قبول النسخة: '+e.message;}};r.readAsText(f);}
function restore(){if(!restoreCandidate){previewRestore();alert('راجع ملخص النسخة أولاً، ثم اضغط الاستعادة مرة أخرى.');return}const x=restoreCandidate;const summary='سيتم استبدال بيانات التطبيق الحالية.\n\nالنسخة: '+x.version+'\nالشهادات: '+x.certificates.length+'\nالبطاقات: '+x.creditCards.length+'\nالحركات: '+x.transactions.length+'\nتاريخ الإنشاء: '+(x.createdAt||'غير متاح')+'\n\nسيتم حفظ نسخة تلقائية من بياناتك الحالية قبل الاستعادة. هل تريد المتابعة؟';if(!confirm(summary))return;try{const before=currentBackupObject();AStore.setItem('ayman_cashflow_pre_restore_backup_v1',JSON.stringify(before));AStore.setItem('ayman_cashflow_pre_restore_backup_at_v1',new Date().toISOString());certs=x.certificates;creditCards=x.creditCards;openingBalances=x.openingBalances;transactions=x.transactions;auditLog=x.auditLog;AStore.setItem(AUDIT_KEY,JSON.stringify(auditLog));AStore.setItem(TXN_KEY,JSON.stringify(transactions));AStore.setItem(CC_KEY,JSON.stringify(creditCards));AStore.setItem(OB_KEY,JSON.stringify(openingBalances));persist();restoreCandidate=null;$('restorePreview').textContent='تمت الاستعادة. تم الاحتفاظ بنسخة تلقائية من البيانات السابقة في هذا المتصفح.';alert('تمت الاستعادة بنجاح.');render();}catch(e){alert('فشلت الاستعادة ولم تكتمل: '+e.message)}}
$('themeBtn').onclick=()=>{let light=document.body.dataset.theme!=='light';document.body.dataset.theme=light?'light':'dark';if(light){document.documentElement.style.setProperty('--bg','#f3f5f1');document.documentElement.style.setProperty('--panel','#fff');document.documentElement.style.setProperty('--panel2','#e8eee8');document.documentElement.style.setProperty('--text','#17251e');document.documentElement.style.setProperty('--muted','#5d6d63');document.documentElement.style.setProperty('--line','#d7e0d8');document.documentElement.style.setProperty('--gold','#9a7428');document.documentElement.style.setProperty('--green','#28754a');$('themeBtn').textContent='الوضع الداكن'}else{['--bg','--panel','--panel2','--text','--muted','--line','--gold','--green'].forEach((k,i)=>document.documentElement.style.removeProperty(k));$('themeBtn').textContent='الوضع الفاتح'}};
// Local application PIN lock. This is an access screen, not encryption of stored financial data.
const APP_PIN_HASH_KEY='ayman_cashflow_app_pin_hash_v1';
const APP_PIN_SALT_KEY='ayman_cashflow_app_pin_salt_v1';
const APP_PIN_ENABLED_KEY='ayman_cashflow_app_pin_enabled_v1';

/* ══════════ القفل بالرقم السري ══════════ */
function appPinHash(pin,salt){
 if(!window.crypto||!crypto.subtle)throw new Error('المتصفح لا يدعم التحقق الآمن من الرقم السري. افتح التطبيق في إصدار حديث من Chrome.');
 return crypto.subtle.digest('SHA-256',new TextEncoder().encode(salt+':'+pin)).then(buf=>Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join(''));
}
function appPinIsEnabled(){return AStore.getItem(APP_PIN_ENABLED_KEY)==='1'&&!!AStore.getItem(APP_PIN_HASH_KEY)&&!!AStore.getItem(APP_PIN_SALT_KEY)}
function pinStatus(message){const el=document.getElementById('pinStatus');if(el)el.textContent=message;}
async function saveAppPin(){
 const current=document.getElementById('pinCurrent').value.trim(),pin=document.getElementById('pinNew').value.trim(),confirmPin=document.getElementById('pinConfirm').value.trim();
 try{
  if(appPinIsEnabled()){
   const oldHash=await appPinHash(current,AStore.getItem(APP_PIN_SALT_KEY));
   if(oldHash!==AStore.getItem(APP_PIN_HASH_KEY)){pinStatus('الرقم السري الحالي غير صحيح.');return;}
  }
  if(!/^\d{4,8}$/.test(pin)){pinStatus('يجب أن يتكون الرقم السري الجديد من 4 إلى 8 أرقام.');return;}
  if(pin!==confirmPin){pinStatus('تأكيد الرقم السري غير مطابق.');return;}
  const salt=Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b=>b.toString(16).padStart(2,'0')).join('');
  const hash=await appPinHash(pin,salt);
  AStore.setItem(APP_PIN_SALT_KEY,salt);AStore.setItem(APP_PIN_HASH_KEY,hash);AStore.setItem(APP_PIN_ENABLED_KEY,'1');
  ['pinCurrent','pinNew','pinConfirm'].forEach(id=>document.getElementById(id).value='');
  pinStatus('تم تفعيل الرقم السري وحفظه على هذا الجهاز. سيُطلب عند فتح التطبيق لاحقاً.');
 }catch(e){pinStatus(e.message||'تعذر حفظ الرقم السري.');}
}
async function disableAppPin(){
 if(!appPinIsEnabled()){pinStatus('القفل غير مفعّل حالياً.');return;}
 try{const current=document.getElementById('pinCurrent').value.trim(),hash=await appPinHash(current,AStore.getItem(APP_PIN_SALT_KEY));
  if(hash!==AStore.getItem(APP_PIN_HASH_KEY)){pinStatus('الرقم السري الحالي غير صحيح؛ لم يتم إلغاء القفل.');return;}
  [APP_PIN_HASH_KEY,APP_PIN_SALT_KEY,APP_PIN_ENABLED_KEY].forEach(k=>AStore.removeItem(k));
  document.getElementById('pinCurrent').value='';pinStatus('تم إلغاء القفل برقم سري.');
 }catch(e){pinStatus(e.message||'تعذر إلغاء القفل.');}
}
function lockAppNow(){if(!appPinIsEnabled()){pinStatus('فعّل الرقم السري أولاً ثم يمكنك قفل التطبيق.');return;}showAppPinOverlay();}
function showAppPinOverlay(){const overlay=document.getElementById('appPinOverlay');if(!overlay)return;overlay.style.display='flex';const input=document.getElementById('pinUnlockInput');input.value='';document.getElementById('pinUnlockError').textContent='';setTimeout(()=>input.focus(),80);}
async function unlockApp(){
 const input=document.getElementById('pinUnlockInput'),error=document.getElementById('pinUnlockError');
 try{const pin=input.value.trim();if(!/^\d{4,8}$/.test(pin)){error.textContent='أدخل الرقم السري المكوّن من 4 إلى 8 أرقام.';return;}
  const hash=await appPinHash(pin,AStore.getItem(APP_PIN_SALT_KEY));
  if(hash!==AStore.getItem(APP_PIN_HASH_KEY)){error.textContent='الرقم السري غير صحيح. حاول مرة أخرى.';input.value='';input.focus();return;}
  document.getElementById('appPinOverlay').style.display='none';error.textContent='';
 }catch(e){error.textContent=e.message||'تعذر التحقق من الرقم السري.';}
}
document.addEventListener('DOMContentLoaded',()=>{if(appPinIsEnabled())showAppPinOverlay();const input=document.getElementById('pinUnlockInput');if(input)input.addEventListener('keydown',e=>{if(e.key==='Enter')unlockApp();});});
if(document.readyState!=='loading'&&appPinIsEnabled())showAppPinOverlay();

render();setFlowPeriod('month');setReportPeriod('month');notifyDueItems();



(function(){
 'use strict';
 const URL_KEY='ayman_gas_webapp_url_v1', SECRET_KEY='ayman_gas_shared_secret_v1';
 const $=id=>document.getElementById(id), status=t=>{const e=$('gasBackupStatus');if(e)e.textContent=t;};
 const savedUrl=AStore.getItem(URL_KEY)||'', savedSecret=AStore.getItem(SECRET_KEY)||'';
 $('gasWebAppUrl').value=savedUrl; $('gasSharedSecret').value=savedSecret;
 function settings(){const url=$('gasWebAppUrl').value.trim(),secret=$('gasSharedSecret').value.trim();
   if(!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec(?:\?.*)?$/.test(url))throw Error('رابط Apps Script غير صحيح. استخدم رابط النشر الذي ينتهي بـ /exec.');
   if(!/^\d{6}$/.test(secret))throw Error('أدخل الرمز السري المكوّن من 6 أرقام بالضبط.');
   AStore.setItem(URL_KEY,url);AStore.setItem(SECRET_KEY,secret);return {url,secret};
 }
 function collect(){const storage={};for(let i=0;i<AStore.length;i++){const k=AStore.key(i);if(!k||k===SECRET_KEY||k===URL_KEY||k.startsWith('ayman_gas_'))continue; if(k.startsWith('ayman_cashflow_'))storage[k]=AStore.getItem(k);}
   return {app:'AYMAN CASHFLOW',formatVersion:2,createdAt:new Date().toISOString(),storage};
 }
 function submitBackup(){let c;try{c=settings();}catch(e){status(e.message);return;}
   const payload=JSON.stringify(collect());const form=document.createElement('form');form.method='POST';form.action=c.url;form.target='gasBackupFrame';form.acceptCharset='UTF-8';
   const fields={action:'backup',secret:c.secret,payload};Object.entries(fields).forEach(([name,value])=>{const input=document.createElement('input');input.type='hidden';input.name=name;input.value=value;form.appendChild(input);});
   document.body.appendChild(form);status('جارٍ إرسال النسخة الاحتياطية إلى Google Drive...');
   let finished=false;const frame=$('gasBackupFrame');const done=()=>{if(finished)return;finished=true;status('تم إرسال طلب النسخ. افتح Google Drive وتحقق من تحديث ملف AYMAN_CASHFLOW_latest.json للتأكد من اكتماله.');form.remove();};
   frame.addEventListener('load',done,{once:true});form.submit();setTimeout(()=>{if(!finished){status('أُرسل الطلب، لكن لم يصل تأكيد من Google. تحقق من مجلد AYMAN CASHFLOW في Drive.');form.remove();}},12000);
 }
 window.aymanGasBackup=submitBackup;
 $('gasSaveSettings').addEventListener('click',()=>{try{settings();status('تم حفظ الإعدادات على هذا الجهاز. يمكنك الآن إجراء النسخ الاحتياطي.');}catch(e){status(e.message);}});
 $('gasBackupNow').addEventListener('click',submitBackup);
 
 $('gasRestoreNow').addEventListener('click',()=>{
   let c;try{c=settings();}catch(e){status(e.message);return;}
   status('جارٍ طلب آخر نسخة احتياطية...');
   const callback='aymanGasRestore_'+Date.now();
   window[callback]=data=>{try{if(!data||!data.ok)throw Error(data&&data.error||'لم يتم العثور على نسخة احتياطية.');
       if(!confirm('سيتم استبدال بيانات AYMAN CASHFLOW الحالية بالنسخة المحفوظة بتاريخ '+(data.createdAt||'غير معروف')+'. يُفضّل تصدير نسخة Excel/احتياطية من بياناتك الحالية أولاً. هل تريد المتابعة؟')){status('تم إلغاء الاستعادة.');return;}
       const storage=data.storage||{};Object.keys(storage).forEach(k=>{if(k.startsWith('ayman_cashflow_'))AStore.setItem(k,storage[k]);});
       status('تمت استعادة البيانات. سيتم إعادة تحميل التطبيق الآن.');setTimeout(()=>location.reload(),1200);
     }catch(e){status('تعذرت الاستعادة: '+e.message);}finally{delete window[callback];script.remove();}};
   const script=document.createElement('script');script.src=c.url+'?action=restore&secret='+encodeURIComponent(c.secret)+'&callback='+callback+'&_='+Date.now();script.onerror=()=>{status('تعذر الاتصال. تحقق من رابط النشر وصلاحية الوصول إلى تطبيق الويب.');delete window[callback];script.remove();};document.head.appendChild(script);
 });
 // Google Drive backup is manual only: it runs solely when the user presses the backup button.
})();



(function(){
  document.addEventListener('click',function(ev){
    const button=ev.target.closest('nav button[data-page]');
    if(!button)return;
    const target=button.getAttribute('data-page');
    if(!target)return;
    document.querySelectorAll('main .page').forEach(section=>section.classList.toggle('active',section.id===target));
    document.querySelectorAll('nav button[data-page]').forEach(item=>item.classList.toggle('active',item===button));
    if(target==='cashflow'&&typeof renderCashflow==='function')renderCashflow();
    window.scrollTo(0,0);
  },true);
})();



(function(){
 document.addEventListener('click',function(ev){
  const b=ev.target.closest('nav button[data-page]'); if(!b)return;
  const id=b.dataset.page;
  if(id==='dashboard'&&typeof render==='function')render();
  else if(id==='alerts'&&typeof renderAlerts==='function')renderAlerts();
  else if(id==='audit'&&typeof renderAuditLog==='function')renderAuditLog();
 },true);
})();
