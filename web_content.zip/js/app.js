/* UrbaAlerte — cœur : état, navigation, alertes de proximité, simulation, notifications */
(function(w){
'use strict';
const C=w.URBA_CONFIG;
const UA=w.UA={S:{user:null,reports:[],alerts:[],cfg:{radius:C.RADIUS_KM,push:true,sim:true,gateway:C.SMS_GATEWAY||'',seeded:false,onbDone:false,permAsked:false},filter:null,_z:null,screen:null},ACT:{},R:{},leave:{}};
const S=UA.S;
UA.saveCfg=()=>DB.kvSet('cfg',S.cfg);
UA.pos=()=>GEO.last||GEO.DEFAULT;
UA.mine=()=>S.user?S.reports.filter(r=>r.userId===S.user.id).sort((a,b)=>b.created-a.created):[];
UA.dist=r=>{const p=UA.pos();return haversine(p.lat,p.lng,r.lat,r.lng)};
UA.zones=()=>S._z||(S._z=RISK.compute(S.reports));
UA.unread=()=>S.alerts.filter(a=>!a.read).length;
UA.changed=()=>{S._z=null;if(UA.R.refresh)UA.R.refresh()};
UA.online=()=>navigator.onLine!==false;

/* ---------- notifications ---------- */
UA.notify=async(title,body,tag)=>{
 try{if(!S.cfg.push||!('Notification' in w)||Notification.permission!=='granted')return;
  const o={body,tag,icon:'assets/icons/icon-192.png',badge:'assets/icons/icon-96.png',vibrate:[120,60,120],lang:'fr'};
  const reg=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration();
  if(reg&&reg.showNotification)reg.showNotification(title,o);else new Notification(title,o)}catch(e){}};
UA.addAlert=async a=>{if(S.alerts.some(x=>x.id===a.id))return;S.alerts.unshift(a);await DB.put('alerts',a);if(UA.R.refresh)UA.R.refresh()};
UA.checkNearby=async r=>{if(!S.user||r.userId===S.user.id||!S.cfg.push)return;if(r.demo&&!r.live)return;
 const d=UA.dist(r);if(d>S.cfg.radius)return;const ty=TYPE(r.type);
 await UA.addAlert({id:'al-'+r.id,rid:r.id,kind:'near',t:Date.now(),read:false,dist:d,text:`${ty.label} à ${fmtKm(d)} de vous`});
 toast(`<b>Alerte à proximité</b><br>${esc(ty.label)} · ${fmtKm(d)}`,'alert',5200,ty.icon);vibrate([120,60,120]);
 UA.notify('UrbaAlerte · incident à '+fmtKm(d),ty.label+' — '+r.desc.slice(0,90),'near-'+r.id)};

/* ---------- données ---------- */
UA.addReport=async(r,quiet)=>{S.reports.push(r);await DB.put('reports',r);S._z=null;if(UA.R.refresh)UA.R.refresh();if(!quiet)await UA.checkNearby(r)};
UA.setStatus=async(r,st,sim)=>{r.status=st;(r.history=r.history||[]).push({s:st,t:Date.now(),sim:!!sim});await DB.put('reports',r);S._z=null;
 if(r.userId===(S.user&&S.user.id)){const m=`Votre signalement ${r.ref} : ${STATUT_LABEL[st]}`;await UA.addAlert({id:'st-'+r.id+'-'+st,rid:r.id,kind:'status',t:Date.now(),read:false,text:m});toast(m,'ok',4200,'check');UA.notify('UrbaAlerte',m,'st-'+r.id)}
 if(UA.R.refresh)UA.R.refresh()};
UA.flush=async()=>{const p=UA.mine().filter(r=>r.sync==='pending');if(!p.length)return;let n=0;
 for(const r of p){try{if(API.enabled){const x=await API.createIncident(r);if(x&&x.id)r.remoteId=x.id}r.sync='synced';r.syncedAt=Date.now();await DB.put('reports',r);n++}catch(e){}}
 if(n){toast(`${n} signalement${n>1?'s':''} envoyé${n>1?'s':''} à la reconnexion`,'ok',4200,'send');if(UA.R.refresh)UA.R.refresh()}};

/* ---------- navigation ---------- */
const NAV=['home','map','history','profile'];
UA.go=name=>{const prev=S.screen;if(prev&&UA.leave[prev])UA.leave[prev]();S.screen=name;
 $$('.screen').forEach(s=>s.classList.toggle('on',s.id==='s-'+name));
 $('#app').classList.toggle('nonav',['onb','auth','report'].includes(name));
 $$('.nav [data-go]').forEach(b=>b.classList.toggle('on',b.dataset.go===name));
 if(UA.R[name])UA.R[name]();closeSheet()};
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]');if(g&&!g.dataset.act){UA.go(g.dataset.go);return}
 const a=e.target.closest('[data-act]');if(a){const f=UA.ACT[a.dataset.act];if(f)f(a,e)}});

/* ---------- simulation (démo locale) ---------- */
let simT=0,tickT=0;
UA.startSim=()=>{clearInterval(simT);clearInterval(tickT);
 tickT=setInterval(async()=>{if(!S.user)return;
  if(S.cfg.sim&&!API.enabled){const now=Date.now(),TH=[[20,'VALIDE'],[60,'AFFECTE'],[120,'EN_COURS'],[240,'RESOLU']];
   for(const r of UA.mine()){if(r.sync!=='synced'||r.demo||['RESOLU','CLOS','REJETE'].includes(r.status))continue;const age=(now-(r.syncedAt||r.created))/1000;
    let tgt=null;TH.forEach(t=>{if(age>=t[0])tgt=t[1]});if(tgt&&STATUTS.indexOf(tgt)>STATUTS.indexOf(r.status))await UA.setStatus(r,tgt,true)}}
  if(API.enabled&&UA.online()){try{const l=await API.listIncidents(S.cfg.lastPoll);S.cfg.lastPoll=Date.now();UA.saveCfg();(l||[]).forEach(x=>UA.mergeRemote(x))}catch(e){}}},6000);
 simT=setInterval(async()=>{if(!S.user||!S.cfg.sim||API.enabled||!UA.online())return;const r=DEMO.spawn(UA.pos());r.fresh=Date.now();await UA.addReport(r)},38000);
 setTimeout(async()=>{if(S.user&&S.cfg.sim&&!API.enabled&&UA.online()){const r=DEMO.spawn(UA.pos());await UA.addReport(r)}},14000)};
UA.mergeRemote=async x=>{/* adaptation minimale du format API → format interne */
 const id='r-'+x.id;if(S.reports.some(r=>r.id===id))return;
 const r={id,ref:x.reference||('UA-'+x.id),userId:x.utilisateur_id===(S.user&&S.user.id)?S.user.id:'remote',type:x.type||'voirie',desc:x.description||'',lat:+x.latitude,lng:+x.longitude,status:x.statut||'EN_ATTENTE',created:new Date(x.created_at||Date.now()).getTime(),mediaIds:[],sync:'synced',live:true,history:[]};
 await UA.addReport(r)};

/* ---------- connexion / session ---------- */
UA.enter=async user=>{S.user=user;try{localStorage.setItem('ua_session',user.id)}catch(e){}
 S.reports=await DB.all('reports');S.alerts=(await DB.all('alerts')).sort((a,b)=>b.t-a.t);
 if(!S.cfg.seeded&&!API.enabled){await Promise.race([GEO.once().catch(()=>{}),sleep(4500)]);const c=UA.pos();const seed=DEMO.seed(c);for(const r of seed){await DB.put('reports',r);S.reports.push(r)}S.cfg.seeded=true;S.cfg.demoCenter=c;await UA.saveCfg()}
 S._z=null;GEO.watch();UA.startSim();UA.go('home');
 if(!S.cfg.permAsked)setTimeout(()=>UA.R.permSheet(),900)};
UA.logout=async()=>{S.user=null;try{localStorage.removeItem('ua_session')}catch(e){}GEO.stop();clearInterval(simT);clearInterval(tickT);API.token=null;UA.go('auth')};

/* ---------- réseau ---------- */
function net(){document.body.classList.toggle('off',!UA.online());if(UA.online()){UA.flush();if(S.screen&&UA.R.refresh)UA.R.refresh()}}
w.addEventListener('online',()=>{toast('Connexion rétablie','ok',2600,'check');net()});
w.addEventListener('offline',()=>{toast('Vous êtes hors ligne — mode SMS disponible','bad',4200,'wifioff');net()});

/* ---------- démarrage ---------- */
UA.boot=async()=>{const t0=Date.now();
 $('.offline').innerHTML=I('wifioff')+'<span style="flex:1">Hors ligne — vos signalements sont enregistrés puis envoyés à la reconnexion.</span><button class="btn gh sm" data-act="sms">SMS</button>';
 $$('.nav [data-ic]').forEach(b=>b.insertAdjacentHTML('afterbegin',I(b.dataset.ic)));
 try{const c=await DB.kvGet('cfg');if(c)Object.assign(S.cfg,c)}catch(e){}
 GEO.restore();net();
 if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol))navigator.serviceWorker.register('sw.js').catch(()=>{});
 let user=null;try{const id=localStorage.getItem('ua_session');if(id)user=await DB.get('users',id)}catch(e){}
 await sleep(Math.max(0,2300-(Date.now()-t0)));
 $('#splash').classList.add('out');setTimeout(()=>$('#splash').remove(),700);
 if(user)await UA.enter(user);else if(!S.cfg.onbDone)UA.go('onb');else UA.go('auth')};
w.addEventListener('DOMContentLoaded',()=>UA.boot().catch(e=>{console.error(e);toast('Erreur de démarrage : '+esc(e.message),'bad',6000,'alert');$('#splash')&&$('#splash').remove();UA.go('auth')}));
})(window);
