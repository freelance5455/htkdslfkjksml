document.addEventListener("DOMContentLoaded", () => {
  const views = [...document.querySelectorAll(".view")];
  const toast = document.getElementById("toast");
  const sideMenu = document.getElementById("sideMenu");
  const overlay = document.getElementById("overlay");
  const moreMenu = document.getElementById("moreMenu");

  window.showToast = (message) => {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(window.__toast);
    window.__toast = setTimeout(() => toast.classList.remove("show"), 2200);
  };

  function closeMenus(){
    sideMenu.classList.remove("open");
    overlay.classList.remove("show");
    moreMenu.classList.remove("open");
  }

  window.goTo = (id) => {
    views.forEach(v => v.classList.toggle("active", v.id === id));
    document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.go === id));
    closeMenus();
    window.scrollTo({top:0, behavior:"smooth"});
  };

  document.addEventListener("click", e => {
    const go = e.target.closest("[data-go]");
    if(go) window.goTo(go.dataset.go);
  });

  document.getElementById("menuBtn").onclick = () => { sideMenu.classList.add("open"); overlay.classList.add("show"); };
  document.getElementById("closeMenu").onclick = closeMenus;
  overlay.onclick = closeMenus;
  document.getElementById("moreBtn").onclick = e => { e.stopPropagation(); moreMenu.classList.toggle("open"); };
  document.addEventListener("click", e => {
    if(!e.target.closest("#moreMenu") && !e.target.closest("#moreBtn")) moreMenu.classList.remove("open");
  });

  const share = async () => {
    const text = "Découvre My Study Life by Abdoulaye, une application pour organiser ses études.";
    if(navigator.share){
      try { await navigator.share({title:"My Study Life by Abdoulaye", text}); } catch(_){}
    } else {
      try { await navigator.clipboard.writeText(text); showToast("Texte de partage copié"); }
      catch(_) { showToast("My Study Life by Abdoulaye"); }
    }
  };
  document.getElementById("shareBtn").onclick = share;
  document.getElementById("shareBtn2").onclick = share;

  document.getElementById("askAiBtn").onclick = () => {
    const input = document.getElementById("aiInput").value.trim();
    const response = document.getElementById("aiResponse");
    response.classList.remove("hidden");
    response.textContent = input
      ? "Mode V1 : ta question a bien été reçue. Le moteur IA sera connecté dans une prochaine version."
      : "Écris d'abord une question d'étude.";
  };

  document.getElementById("demoDocBtn").onclick = () => {
    const list = document.getElementById("documentList");
    const item = document.createElement("div");
    item.className = "document-item";
    item.innerHTML = "<span>📄</span><div><b>Document démo</b><small>Ajouté maintenant</small></div>";
    list.prepend(item);
    showToast("Document démo ajouté");
  };
});
