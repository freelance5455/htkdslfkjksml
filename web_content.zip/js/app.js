const $ = s => document.querySelector(s);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

/* ---------- Bank soal: My Family dan Daily Activities ---------- */
// [pertanyaan, jawaban benar, [pilihan salah], penjelasan, topik]
const F = "My Family", D = "Daily Activities";
const Q = [
  ["My father’s mother is my ___.", "grandmother", ["aunt", "sister", "cousin"], "Grandmother = nenek, grandfather = kakek.", F],
  ["My mother’s brother is my ___.", "uncle", ["cousin", "nephew", "grandfather"], "Uncle = paman.", F],
  ["My uncle’s daughter is my ___.", "cousin", ["sister", "aunt", "niece"], "Cousin = sepupu (laki-laki maupun perempuan).", F],
  ["My father and my mother are my ___.", "parents", ["siblings", "cousins", "children"], "Parents = orang tua.", F],
  ["My mother’s sister is my ___.", "aunt", ["uncle", "cousin", "grandmother"], "Aunt = bibi atau tante.", F],
  ["There are five people in my family: my parents and three ___.", "children", ["childs", "childrens", "childes"], "Bentuk jamak dari child adalah children.", F],
  ["This is my brother. ___ name is Doni.", "His", ["Her", "Its", "Our"], "His = miliknya (laki-laki), her = miliknya (perempuan).", F],
  ["Rina is my sister. ___ is twelve years old.", "She", ["He", "It", "They"], "Untuk perempuan gunakan she.", F],
  ["My grandfather ___ seventy years old.", "is", ["am", "are", "be"], "Grandfather adalah satu orang (he), jadi pakai is.", F],
  ["My parents ___ teachers.", "are", ["is", "am", "be"], "Parents jamak, jadi pakai are.", F],
  ["Which sentence is correct?", "I have two brothers.", ["I has two brothers.", "I am have two brothers.", "I haves two brothers."], "Subjek I berpasangan dengan have.", F],
  ["Which sentence is correct?", "My mother is a nurse.", ["My mother are a nurse.", "My mother am a nurse.", "My mother a nurse."], "My mother = she, jadi pakai is.", F],
  ["A boy child in a family is a ___.", "son", ["daughter", "uncle", "aunt"], "Son = anak laki-laki, daughter = anak perempuan.", F],
  ["“Adik perempuan” in English is ___.", "younger sister", ["older sister", "younger brother", "older brother"], "Younger = lebih muda, older = lebih tua.", F],
  ["I ___ up at 5.30 every morning.", "wake", ["wakes", "waking", "am wake"], "Subjek I memakai kata kerja dasar: wake.", D],
  ["She ___ breakfast at 6.30.", "has", ["have", "haves", "having"], "She/he/it memakai has pada simple present.", D],
  ["We ___ to school at seven o’clock.", "go", ["goes", "going", "are go"], "Subjek we memakai go.", D],
  ["My father ___ to work by motorbike.", "goes", ["go", "going", "are go"], "He/she/it + kata kerja + s/es: goes.", D],
  ["Doni ___ his teeth after breakfast.", "brushes", ["brush", "brushing", "brushs"], "Kata berakhiran sh ditambah -es: brushes.", D],
  ["“Mandi” in English is ___.", "take a bath", ["make a bath", "do a bath", "play a bath"], "Take a bath = mandi.", D],
  ["Which sentence is correct?", "I go to bed at nine.", ["I goes to bed at nine.", "I going to bed at nine.", "I am go to bed at nine."], "I + go. Tidur = go to bed.", D],
  ["06.15 is ___.", "a quarter past six", ["a quarter to six", "half past six", "six fifty"], "A quarter past = lewat lima belas menit.", D],
  ["07.45 is ___.", "a quarter to eight", ["a quarter past seven", "half past seven", "seven fourteen"], "A quarter to = kurang lima belas menit.", D],
  ["I eat lunch ___ noon.", "at", ["in", "on", "to"], "Waktu tertentu memakai at: at noon, at seven.", D],
  ["I take a bath ___ the morning.", "in", ["at", "on", "of"], "in the morning, in the afternoon, in the evening.", D],
  ["Rina ___ her homework in the evening.", "does", ["do", "doing", "dos"], "Do homework. Untuk she, pakai does.", D],
  ["My mother ___ dinner for the family every night.", "cooks", ["cook", "cooking", "cookes"], "She/he/it + s: cooks.", D],
  ["On Sunday morning, we ___ to church.", "go", ["goes", "going", "are go"], "We + go.", D],
  ["I ___ TV after dinner.", "watch", ["watches", "watching", "am watch"], "Subjek I + watch.", D],
  ["“Every day” means ___.", "setiap hari", ["setiap minggu", "kadang-kadang", "tidak pernah"], "Every day = setiap hari.", D],
  ["“Never” means ___.", "tidak pernah", ["selalu", "sering", "kadang-kadang"], "Never = tidak pernah, always = selalu.", D]
];

const PAIRS = [
  ["mother","ibu"],["father","ayah"],["sister","saudara perempuan"],["brother","saudara laki-laki"],["grandmother","nenek"],["grandfather","kakek"],
  ["uncle","paman"],["aunt","bibi"],["cousin","sepupu"],["parents","orang tua"],["wake up","bangun"],["take a bath","mandi"],
  ["have breakfast","sarapan"],["go to school","pergi ke sekolah"],["study","belajar"],["sleep","tidur"],["cook","memasak"],["sweep","menyapu"],
  ["help","membantu"],["watch TV","menonton TV"]
];

const WORDS = [
  ["MOTHER","👩","ibu"],["FATHER","👨","ayah"],["SISTER","👧","saudara perempuan"],["BROTHER","👦","saudara laki-laki"],
  ["GRANDMOTHER","👵","nenek"],["GRANDFATHER","👴","kakek"],["FAMILY","👨‍👩‍👧‍👦","keluarga"],["BREAKFAST","🍳","sarapan"],
  ["HOMEWORK","📚","pekerjaan rumah"],["SCHOOL","🏫","sekolah"],["SLEEP","😴","tidur"],["LUNCH","🍱","makan siang"],
  ["DINNER","🍽️","makan malam"],["SHOWER","🚿","mandi"],["TEETH","🦷","gigi"],["SUNDAY","⛪","hari Minggu"]
];

const SENT = [
  ["I wake up at five thirty.", "Saya bangun pukul lima tiga puluh."],
  ["She has breakfast with her family.", "Dia sarapan bersama keluarganya."],
  ["My father goes to work by motorbike.", "Ayahku pergi bekerja naik motor."],
  ["We go to church on Sunday.", "Kami pergi ke gereja pada hari Minggu."],
  ["My mother cooks dinner every night.", "Ibuku memasak makan malam setiap malam."],
  ["He brushes his teeth after breakfast.", "Dia menyikat giginya setelah sarapan."],
  ["They study English at school.", "Mereka belajar Bahasa Inggris di sekolah."],
  ["My grandmother lives in Waikabubak.", "Nenekku tinggal di Waikabubak."],
  ["I have two brothers and one sister.", "Aku punya dua saudara laki-laki dan satu saudara perempuan."],
  ["My aunt is a teacher.", "Bibiku adalah seorang guru."],
  ["I do my homework in the evening.", "Aku mengerjakan PR pada malam hari."],
  ["Our family is small and happy.", "Keluarga kami kecil dan bahagia."]
];

// [adegan, pernyataan, benar?, penjelasan]
const TF = [
  ["fam","Sinta is Budi’s sister.",true,"Sinta adalah anak perempuan Mr. Yosef, jadi dia saudara perempuan Budi."],
  ["fam","Mrs. Maria is Budi’s aunt.",false,"Mrs. Maria adalah ibu Budi (mother), bukan bibi (aunt)."],
  ["fam","Mr. Petrus is Budi’s grandfather.",true,"Mr. Petrus adalah ayah dari Mr. Yosef, jadi kakek Budi."],
  ["fam","Dedi is Budi’s father.",false,"Dedi adalah adik laki-laki Budi (brother), bukan ayah."],
  ["fam","Mr. Yosef and Mrs. Maria are Budi’s parents.",true,"Parents = orang tua."],
  ["fam","Budi has two sisters.",false,"Budi hanya punya satu saudara perempuan (Sinta) dan satu adik laki-laki (Dedi)."],
  ["fam","Mrs. Lidia is Budi’s grandmother.",true,"Mrs. Lidia adalah ibu dari Mr. Yosef, jadi nenek Budi."],
  ["fam","There are seven people in this family.",true,"Petrus, Lidia, Yosef, Maria, Budi, Sinta, dan Dedi: tujuh orang."],
  ["day","Sinta takes a bath at six o’clock.",true,"Di jadwal: 06.00 mandi."],
  ["day","Sinta goes to school at half past six.",false,"Dia berangkat sekolah pukul 07.00 (seven o’clock)."],
  ["day","Sinta has lunch at one o’clock.",true,"13.00 adalah pukul satu siang."],
  ["day","Sinta does her homework in the morning.",false,"PR dikerjakan pukul 19.00, yaitu malam hari (evening)."],
  ["day","Sinta goes to bed at nine o’clock.",true,"21.00 = nine o’clock malam."],
  ["day","Sinta wakes up at six o’clock.",false,"Dia bangun pukul 05.30 (half past five)."],
  ["day","Sinta plays with her friends at four o’clock.",true,"16.00 = four o’clock."],
  ["day","Sinta has breakfast after she takes a bath.",true,"Mandi pukul 06.00, sarapan pukul 06.30."]
];
const SCENES = {
  fam: `<div class="scene"><div class="stitle">Keluarga Budi</div>
    <div class="trow"><span class="pp">👴<b>Mr. Petrus</b></span><span class="pp">👵<b>Mrs. Lidia</b></span></div>
    <div class="trow"><span class="pp">👨<b>Mr. Yosef</b></span><span class="pp">👩<b>Mrs. Maria</b></span></div>
    <div class="trow"><span class="pp me">👦<b>Budi</b></span><span class="pp">👧<b>Sinta</b></span><span class="pp">👶<b>Dedi</b></span></div>
    <p class="note">Mr. Petrus dan Mrs. Lidia adalah orang tua Mr. Yosef. Budi, Sinta, dan Dedi adalah anak Mr. Yosef dan Mrs. Maria. Dedi adalah yang termuda.</p></div>`,
  day: `<div class="scene"><div class="stitle">Hari Sinta</div><div class="sched">
    <div class="sc"><span>🛏️</span><div>05.30<small>wake up</small></div></div>
    <div class="sc"><span>🚿</span><div>06.00<small>take a bath</small></div></div>
    <div class="sc"><span>🍳</span><div>06.30<small>have breakfast</small></div></div>
    <div class="sc"><span>🏫</span><div>07.00<small>go to school</small></div></div>
    <div class="sc"><span>🍱</span><div>13.00<small>have lunch</small></div></div>
    <div class="sc"><span>⚽</span><div>16.00<small>play with friends</small></div></div>
    <div class="sc"><span>📚</span><div>19.00<small>do homework</small></div></div>
    <div class="sc"><span>😴</span><div>21.00<small>go to bed</small></div></div></div></div>`
};

/* ---------- Simpanan ---------- */
const KEY = "english-island-v1";
let S = { name: "", xp: 0, mute: false, best: { quiz: 0, match: 0, scramble: 0, sent: 0, tf: 0 } };
try { const d = JSON.parse(localStorage.getItem(KEY) || "null"); if (d) S = { ...S, ...d, best: { ...S.best, ...(d.best || {}) } }; } catch (e) {}
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };

const LEVELS = [[0,"Pemula 🌱"],[100,"Penjelajah 🧭"],[250,"Jagoan 🦸"],[500,"Juara 🏆"]];
function levelInfo() {
  let i = 0; LEVELS.forEach((l, k) => { if (S.xp >= l[0]) i = k; });
  const cur = LEVELS[i], nxt = LEVELS[i + 1];
  const pct = nxt ? Math.round((S.xp - cur[0]) / (nxt[0] - cur[0]) * 100) : 100;
  return { label: cur[1], pct };
}
function drawXP() {
  const L = levelInfo();
  $("#xp").innerHTML = `<b>${L.label}</b><span style="font-weight:600;font-size:.8rem;color:var(--muted)">${S.xp} poin</span><div class="bar"><i style="width:${L.pct}%"></i></div>`;
}
const starsHTML = (n, max = 3) => Array.from({ length: max }, (_, i) => `<span class="${i < n ? "" : "off"}">★</span>`).join("");
const screen = $("#screen");
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let timers = [];
const later = (fn, ms) => { const t = setTimeout(fn, ms); timers.push(t); };
const clearTimers = () => { timers.forEach(clearTimeout); timers = []; };

/* ---------- Audio (berkas di folder audio/) ---------- */
const MUSIC = new Audio("audio/musik-sumba.wav");
MUSIC.loop = true; MUSIC.volume = 0; MUSIC.preload = "auto";
const SFX_FILES = { ok: "benar", no: "salah", tap: "ketuk", pair: "cocok", miss: "meleset", win: "menang", done: "selesai" };
const SFX_AUDIO = {};
Object.entries(SFX_FILES).forEach(([k, f]) => { const a = new Audio("audio/" + f + ".wav"); a.preload = "auto"; SFX_AUDIO[k] = a; });
let playing = false, fadeT = null;
function fadeTo(v, ms, done) {
  clearInterval(fadeT);
  const s = MUSIC.volume, n = Math.max(1, ms / 20); let i = 0;
  fadeT = setInterval(() => {
    i++; MUSIC.volume = Math.max(0, Math.min(1, s + (v - s) * i / n));
    if (i >= n) { clearInterval(fadeT); if (done) done(); }
  }, 20);
}
function startMusic() {
  if (playing || S.mute) return;
  playing = true;
  const p = MUSIC.play();
  if (p && p.then) p.then(() => fadeTo(0.5, 600)).catch(() => { playing = false; updateSoundBtn(); });
  else fadeTo(0.5, 600);
}
function stopMusic() {
  if (!playing) return;
  playing = false;
  fadeTo(0, 350, () => { if (!playing) MUSIC.pause(); });
}
function sfx(k) {
  if (S.mute) return;
  const a = SFX_AUDIO[k]; if (!a) return;
  const c = a.cloneNode(); c.volume = 0.9;
  const p = c.play(); if (p && p.catch) p.catch(() => {});
}
function updateSoundBtn() {
  const b = $("#snd"); if (!b) return;
  b.textContent = S.mute ? "🔇" : "🔊";
  b.setAttribute("aria-pressed", String(!S.mute));
  b.setAttribute("aria-label", S.mute ? "Nyalakan suara" : "Matikan suara");
  const h = $("#mhint"); if (h) h.hidden = playing || S.mute;
}
function syncMusic() {
  const want = !S.mute && !!$(".islands");
  if (want) startMusic(); else stopMusic();
  updateSoundBtn();
}
function toggleSound() {
  S.mute = !S.mute; save();
  if (!S.mute) sfx("tap");
  syncMusic();
}
document.addEventListener("visibilitychange", () => {
  if (document.hidden) MUSIC.pause(); else if (playing) { const p = MUSIC.play(); if (p && p.catch) p.catch(() => {}); }
});

/* ---------- Menu utama ---------- */
function island(act, cls, icon, title, desc, key) {
  return `<button class="island ${cls}" data-act="${act}"><span class="pic" aria-hidden="true">${icon}</span>
    <h3>${title}</h3><p>${desc}</p>
    <span class="stars" aria-label="Bintang terbaik ${S.best[key]} dari 3">${starsHTML(S.best[key])}</span></button>`;
}
function home() {
  clearTimers(); drawXP();
  const nameBlock = S.name ? `
    <div class="hello"><h2>Halo, ${esc(S.name)}!</h2>
    <p>Pilih satu pulau dan kumpulkan bintang.</p>
    <div class="topics"><span class="chip sea">My Family</span><span class="chip grape">Daily Activities</span></div></div>` : `
    <div class="card name-form"><h2>Selamat datang!</h2>
    <label for="nm" style="font-weight:600;color:var(--muted)">Siapa namamu?</label>
    <input id="nm" maxlength="20" autocomplete="off" placeholder="Tulis namamu di sini">
    <button class="btn leaf" data-act="saveName">Mulai bermain</button></div>`;
  screen.innerHTML = nameBlock + `<p class="note" id="mhint" style="margin:0 0 12px">🎵 Ketuk layar untuk memutar musik Sumba</p>` + `<div class="islands" style="margin-top:6px">` +
    island("quiz", "", "🧠", "Kuis kilat", "10 soal pilihan ganda tentang keluarga dan kegiatan sehari-hari.", "quiz") +
    island("match", "coral", "🃏", "Pasangkan kartu", "Buka dua kartu dan cocokkan kata Inggris dengan artinya.", "match") +
    island("scramble", "grape", "🔤", "Susun huruf", "Susun huruf yang acak menjadi kata Inggris yang benar.", "scramble") +
    island("sent", "leaf", "🧩", "Susun kalimat", "Urutkan kata-kata menjadi kalimat yang tepat.", "sent") +
    island("tf", "tang", "✅", "Benar atau salah", "Baca keluarga Budi dan jadwal Sinta, lalu nilai pernyataannya.", "tf") +
    `</div>`;
  updateSoundBtn();
}

/* ---------- Kuis ---------- */
let G = {};
function quiz() {
  clearTimers();
  G = { mode: "quiz", i: 0, score: 0, locked: false,
    items: shuffle(Q).slice(0, 10).map(([q, a, w, t, c]) => ({ q, a, t, c, opts: shuffle([a, ...w]) })) };
  quizView();
}
function quizView() {
  const it = G.items[G.i];
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    <span class="chip ${it.c === F ? "sea" : "grape"}">${esc(it.c)}</span>
    <p class="q">${esc(it.q)}</p>
    <div class="opts">${it.opts.map((o, k) => `<button class="opt" data-act="opt" data-k="${k}">${esc(o)}</button>`).join("")}</div>
    <div id="fb"></div>`;
}
function pickOpt(btn) {
  if (G.locked) return; G.locked = true;
  const it = G.items[G.i], k = +btn.dataset.k, ok = it.opts[k] === it.a;
  sfx(ok ? "ok" : "no");
  document.querySelectorAll(".opt").forEach((b, i) => {
    b.disabled = true;
    if (it.opts[i] === it.a) b.classList.add("right");
    else if (i === k) b.classList.add("wrong");
  });
  if (ok) G.score++;
  const last = G.i === G.items.length - 1;
  $("#fb").innerHTML = `
    <div class="tip ${ok ? "good" : "bad"}"><b>${ok ? "Benar! 🎉" : "Belum tepat."}</b> ${esc(it.t)}</div>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn ${ok ? "leaf" : ""}" data-act="next">${last ? "Lihat hasil" : "Soal berikutnya"}</button></div>`;
  $("#fb .btn").focus();
}
function nextQ() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, stars = s >= 9 ? 3 : s >= 6 ? 2 : s >= 3 ? 1 : 0;
    return finish("quiz", `${s} dari ${G.items.length} soal benar`, stars, s * 10);
  }
  G.i++; G.locked = false; quizView();
}

/* ---------- Pasangkan kartu ---------- */
function match() {
  clearTimers();
  const pairs = shuffle(PAIRS).slice(0, 6);
  const cards = shuffle(pairs.flatMap(([en, id], p) => [{ p, t: en, l: "en" }, { p, t: id, l: "id" }]));
  G = { mode: "match", cards, open: [], moves: 0, found: 0, locked: false };
  screen.innerHTML = `
    <div class="gtop"><h2 class="disp" style="font-size:1.5rem">Pasangkan kartu</h2>
      <span class="chip" id="mv" style="margin-left:auto">0 langkah</span></div>
    <p style="margin:0 0 14px;color:var(--muted);font-weight:600">Kartu biru berisi kata Inggris, kartu kuning berisi artinya.</p>
    <div class="grid">${cards.map((c, i) => `<button class="tile" data-act="flip" data-i="${i}" aria-label="Kartu ${i + 1}">?</button>`).join("")}</div>`;
}
function setTile(i) {
  const c = G.cards[i], el = document.querySelector(`.tile[data-i="${i}"]`);
  const show = c.up || c.done;
  el.className = "tile" + (c.done ? " done" : c.up ? ` up ${c.l}` : "") + (show && c.t.length > 10 ? " sm" : "");
  el.textContent = show ? c.t : "?";
}
function flip(i) {
  const c = G.cards[i];
  if (G.locked || c.up || c.done) return;
  sfx("tap"); c.up = true; setTile(i); G.open.push(i);
  if (G.open.length < 2) return;
  G.moves++; $("#mv").textContent = G.moves + " langkah";
  const [a, b] = G.open.map(k => G.cards[k]);
  if (a.p === b.p) {
    a.done = b.done = true; sfx("pair"); G.open.forEach(setTile); G.open = []; G.found++;
    if (G.found === 6) later(() => { const m = G.moves, stars = m <= 9 ? 3 : m <= 13 ? 2 : 1; finish("match", `Selesai dalam ${m} langkah`, stars, stars * 20); }, 700);
  } else {
    G.locked = true; sfx("miss");
    later(() => { G.open.forEach(k => { G.cards[k].up = false; setTile(k); }); G.open = []; G.locked = false; }, 850);
  }
}

/* ---------- Susun huruf ---------- */
function scramble() {
  clearTimers();
  G = { mode: "scramble", i: 0, score: 0, items: shuffle(WORDS).slice(0, 8) };
  scrView();
}
function scrView() {
  const [w, emo, hint] = G.items[G.i];
  let L = shuffle(w.split("")); let n = 0; while (L.join("") === w && n++ < 9) L = shuffle(L);
  G.tiles = L.map(ch => ({ ch, used: false })); G.slots = Array(w.length).fill(null); G.locked = false;
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    <div class="pic-big" aria-hidden="true">${emo}</div>
    <div class="hint">Artinya: ${esc(hint)}</div>
    <div class="slots" id="slots"></div><div class="pool" id="pool"></div>
    <div class="row" style="justify-content:center;margin-top:8px">
      <button class="btn ghost" data-act="clear">Hapus</button>
      <button class="btn ghost" data-act="mix">Acak lagi</button>
      <button class="btn coral" data-act="skip">Lewati</button></div>`;
  scrDraw();
}
function scrDraw() {
  $("#slots").innerHTML = G.slots.map((t, i) => `<button class="slot ${t !== null ? "fill" : ""}" data-act="slot" data-i="${i}" aria-label="Huruf ke-${i + 1}">${t !== null ? G.tiles[t].ch : ""}</button>`).join("");
  $("#pool").innerHTML = G.tiles.map((t, i) => `<button class="ltr ${t.used ? "used" : ""}" data-act="tile" data-i="${i}">${t.ch}</button>`).join("");
}
function tapTile(i) {
  if (G.locked || G.tiles[i].used) return;
  const s = G.slots.indexOf(null); if (s < 0) return;
  sfx("tap"); G.slots[s] = i; G.tiles[i].used = true; scrDraw();
  if (G.slots.indexOf(null) < 0) checkWord();
}
function tapSlot(i) { if (G.locked || G.slots[i] === null) return; G.tiles[G.slots[i]].used = false; G.slots[i] = null; scrDraw(); }
function checkWord() {
  const w = G.items[G.i][0], got = G.slots.map(t => G.tiles[t].ch).join("");
  G.locked = true; const box = $("#slots");
  if (got === w) { G.score++; sfx("ok"); box.classList.add("ok"); later(nextWord, 1000); }
  else { sfx("no"); box.classList.add("no"); later(() => { clearSlots(); G.locked = false; }, 700); }
}
function clearSlots() { G.slots.fill(null); G.tiles.forEach(t => t.used = false); scrDraw(); }
function mixTiles() { if (G.locked) return; clearSlots(); G.tiles = shuffle(G.tiles); scrDraw(); }
function skipWord() {
  if (G.locked) return; G.locked = true;
  const w = G.items[G.i][0];
  $("#slots").innerHTML = w.split("").map(c => `<span class="slot fill">${c}</span>`).join("");
  $("#pool").innerHTML = `<p class="tip bad" style="width:100%;margin:0">Jawabannya: <b>${w}</b></p>`;
  later(nextWord, 1600);
}
function nextWord() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, stars = s >= 7 ? 3 : s >= 5 ? 2 : s >= 3 ? 1 : 0;
    return finish("scramble", `${s} dari ${G.items.length} kata benar`, stars, s * 10);
  }
  G.i++; scrView();
}

/* ---------- Susun kalimat ---------- */
function sent() {
  clearTimers();
  G = { mode: "sent", i: 0, score: 0, items: shuffle(SENT).slice(0, 6) };
  sentView();
}
function sentView() {
  const [s, tr] = G.items[G.i], words = s.split(" ");
  let L = shuffle(words); let n = 0; while (L.join(" ") === s && n++ < 9) L = shuffle(L);
  G.target = s; G.tiles = L.map(w => ({ ch: w, used: false })); G.slots = []; G.locked = false;
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    <div class="hint" style="text-align:left;font-size:1.1rem">Artinya: ${esc(tr)}</div>
    <div class="sline" id="sline" aria-live="polite"></div>
    <div class="pool" id="pool"></div>
    <div class="row" style="justify-content:center;margin-top:8px">
      <button class="btn ghost" data-act="wclear">Hapus</button>
      <button class="btn coral" data-act="wskip">Lewati</button></div>`;
  sentDraw();
}
function sentDraw() {
  $("#sline").innerHTML = G.slots.length ? G.slots.map((t, i) => `<button class="wchip in" data-act="wslot" data-i="${i}">${esc(G.tiles[t].ch)}</button>`).join("") : `<span class="ph">Ketuk kata di bawah untuk menyusun kalimat</span>`;
  $("#pool").innerHTML = G.tiles.map((t, i) => `<button class="wchip ${t.used ? "used" : ""}" data-act="wtile" data-i="${i}">${esc(t.ch)}</button>`).join("");
}
function tapWord(i) {
  if (G.locked || G.tiles[i].used) return;
  sfx("tap"); G.slots.push(i); G.tiles[i].used = true; sentDraw();
  if (G.slots.length === G.tiles.length) checkSent();
}
function tapWordSlot(i) {
  if (G.locked) return;
  const t = G.slots.splice(i, 1)[0]; G.tiles[t].used = false; sentDraw();
}
function clearWords() { if (G.locked) return; G.slots = []; G.tiles.forEach(t => t.used = false); sentDraw(); }
function checkSent() {
  const got = G.slots.map(t => G.tiles[t].ch).join(" "); G.locked = true; const box = $("#sline");
  if (got === G.target) { G.score++; sfx("ok"); box.classList.add("ok"); box.querySelectorAll(".wchip").forEach(b => { b.style.background = "#fff"; b.style.color = "#148A55"; b.style.boxShadow = "none"; }); later(nextSent, 1500); }
  else { sfx("no"); box.classList.add("no"); later(() => { box.classList.remove("no"); G.locked = false; clearWords(); }, 800); }
}
function skipSent() {
  if (G.locked) return; G.locked = true;
  $("#sline").innerHTML = `<span class="ph" style="color:var(--ink)">Jawabannya: <b>${esc(G.target)}</b></span>`;
  $("#pool").innerHTML = "";
  later(nextSent, 2200);
}
function nextSent() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, stars = s >= 6 ? 3 : s >= 4 ? 2 : s >= 2 ? 1 : 0;
    return finish("sent", `${s} dari ${G.items.length} kalimat benar`, stars, s * 15);
  }
  G.i++; sentView();
}

/* ---------- Benar atau salah ---------- */
function tf() {
  clearTimers();
  G = { mode: "tf", i: 0, score: 0, locked: false, items: shuffle(TF).slice(0, 8) };
  tfView();
}
function tfView() {
  const [sc, st] = G.items[G.i]; G.locked = false;
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    ${SCENES[sc]}
    <p class="stmt">${esc(st)}</p>
    <div class="row"><button class="btn leaf big" data-act="ans" data-v="1">Benar</button><button class="btn coral big" data-act="ans" data-v="0">Salah</button></div>
    <div id="fb"></div>`;
}
function tfAnswer(btn) {
  if (G.locked) return; G.locked = true;
  const [, , truth, why] = G.items[G.i], ok = (btn.dataset.v === "1") === truth;
  if (ok) G.score++;
  sfx(ok ? "ok" : "no");
  document.querySelectorAll(".big").forEach(b => b.disabled = true);
  const last = G.i === G.items.length - 1;
  $("#fb").innerHTML = `
    <div class="tip ${ok ? "good" : "bad"}"><b>${ok ? "Tepat! 🎉" : "Belum tepat."}</b> Pernyataan ini ${truth ? "benar" : "salah"}. ${esc(why)}</div>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn ${ok ? "leaf" : ""}" data-act="tfnext">${last ? "Lihat hasil" : "Berikutnya"}</button></div>`;
  $("#fb .btn").focus();
}
function tfNext() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, stars = s >= 7 ? 3 : s >= 5 ? 2 : s >= 3 ? 1 : 0;
    return finish("tf", `${s} dari ${G.items.length} jawaban tepat`, stars, s * 10);
  }
  G.i++; tfView();
}

/* ---------- Hasil ---------- */
function finish(mode, summary, stars, gain) {
  clearTimers();
  const newBest = stars > S.best[mode];
  if (newBest) S.best[mode] = stars;
  S.xp += gain; save(); drawXP();
  const n = esc(S.name || "teman");
  const msg = stars === 3 ? `Luar biasa, ${n}!` : stars === 2 ? `Bagus sekali, ${n}!` : stars === 1 ? `Lumayan, ${n}. Ayo coba lagi!` : `Jangan menyerah, ${n}. Coba sekali lagi!`;
  screen.innerHTML = `
    <div class="card result">
      <div class="big" aria-label="${stars} dari 3 bintang">${starsHTML(stars)}</div>
      <h2>${msg}</h2><p>${esc(summary)}</p>
      <div class="gain">+${gain} poin</div>
      ${newBest && stars > 0 ? `<p style="color:var(--leaf);font-weight:800">Rekor bintang baru!</p>` : ""}
      <div class="row" style="justify-content:center;margin-top:16px">
        <button class="btn leaf" data-act="${mode}">Main lagi</button>
        <button class="btn ghost" data-act="home">Menu utama</button></div>
    </div>`;
  sfx(stars >= 2 ? "win" : "done");
  if (stars >= 2) confetti();
}
function confetti() {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const cols = ["#FFC93C", "#1B9AF5", "#FF5D73", "#22B573", "#7C4DFF", "#FF8A3D"];
  for (let i = 0; i < 44; i++) {
    const d = document.createElement("i"); d.className = "confetti";
    d.style.left = Math.random() * 100 + "vw"; d.style.background = cols[i % cols.length];
    d.style.animationDelay = Math.random() * .8 + "s"; d.style.animationDuration = 2 + Math.random() * 1.6 + "s";
    document.body.appendChild(d); setTimeout(() => d.remove(), 4600);
  }
}

/* ---------- Event ---------- */
const actions = {
  home, quiz, match, scramble, sent, tf, next: nextQ,
  opt: b => pickOpt(b), flip: b => flip(+b.dataset.i),
  tile: b => tapTile(+b.dataset.i), slot: b => tapSlot(+b.dataset.i),
  clear: () => { if (!G.locked) clearSlots(); }, mix: mixTiles, skip: skipWord,
  wtile: b => tapWord(+b.dataset.i), wslot: b => tapWordSlot(+b.dataset.i), wclear: clearWords, wskip: skipSent,
  ans: b => tfAnswer(b), tfnext: tfNext,
  saveName: () => {
    const v = ($("#nm").value || "").trim();
    if (!v) { $("#nm").focus(); return; }
    S.name = v; save(); home();
  }
};
document.addEventListener("click", e => {
  if (e.target.closest("#snd")) { toggleSound(); return; }
  const b = e.target.closest("[data-act]");
  if (b) { const f = actions[b.dataset.act]; if (f) f(b); }
  syncMusic();
});
document.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.id === "nm") actions.saveName(); });
home();
