import { preload as preloadGrades, GradeManager } from "./engines/gradeManager.js";
import { UnifiedQuestionEngine } from "./engines/unifiedEngine.js";
import * as db from "./db.js";
import { applyTheme } from "./theme.js";
import { el, bottomNav, showAlert, showPrompt } from "./ui/widgets.js";

import { Login } from "./screens/login.js";
import { Home } from "./screens/home.js";
import { Learn, TopicDetail, TopicDetailLite } from "./screens/learn.js";
import { PracticeSetup, PracticeSession } from "./screens/practice.js";
import { Papers, PaperViewer } from "./screens/papers.js";
import { Profile } from "./screens/profile.js";
import { Settings } from "./screens/settings.js";
import { DiagramGallery } from "./screens/diagramGallery.js";
import { Labs, GeometryLab, DataLab, ProbabilityLab, Mental, SolidsLab } from "./screens/labs.js";
import { TheoremLab, TheoremRound } from "./screens/theoremLab.js";
import { WorkshopSession } from "./screens/workshopSession.js";
import { syncFromSettings, startMusic, playSfx } from "./engines/audioEngine.js";
import { TeachHub, TeachDeck } from "./screens/teach.js";
import { StructuredPractice, StructuredHub } from "./screens/structured.js";
import { Achievements, Economy, DevMode, Rewards } from "./screens/gamification.js";
import { Science, ScienceTopic, Quiz, TipsTricks } from "./screens/science.js";
import { PsQuizSession } from "./screens/psQuiz.js";
import { SubjectHub, SubjectTopic, SubjectQuiz, SubjectPaperViewer } from "./screens/subjectHub.js";
import { WorksheetSession } from "./screens/worksheet.js";
import { ReferenceSheets } from "./screens/referenceSheets.js";
import { LearningCardHub, LearningCard } from "./screens/learningCard.js";

/** Invite-only access password (once-off at first launch). */
export const INVITE_PASSWORD = "childrenofthesun";
export const ACCESS_CODE = "childrenofthesun";
export const ACTIVATION_CODE = "childrenofthesun";
export const LOCKED_GRADE = 10;
export const SUPPORTED_GRADES = [10];
export const PRODUCT = "Learnly Grade 10 · The Elites Academy";
export const OWNER = "The Elites Academy";
export const SINGLE_CODE = "G10";
export const LICENCE_DAYS = 15;

const SESSION_KEY = "learnly_g10:session_active";
const INVITE_KEY = "learnly_g10:invite_ok";

const SCREENS = {
  login: Login, home: Home, learn: Learn, topicDetail: TopicDetail, topicDetailLite: TopicDetailLite,
  practiceSetup: PracticeSetup, practiceSession: PracticeSession, papers: Papers, paperViewer: PaperViewer,
  profile: Profile, settings: Settings, diagramGallery: DiagramGallery, labs: Labs, theoremLab: TheoremLab, theoremRound: TheoremRound, workshopSession: WorkshopSession, geometryLab: GeometryLab, dataLab: DataLab,
  probabilityLab: ProbabilityLab, mental: Mental, solidsLab: SolidsLab, teachHub: TeachHub, teachDeck: TeachDeck, structuredPractice: StructuredPractice, structuredHub: StructuredHub,
  achievements: Achievements, economy: Economy, rewards: Rewards, devMode: DevMode,
  science: Science, scienceTopic: ScienceTopic, quiz: Quiz, tipsTricks: TipsTricks,
  psQuizSession: PsQuizSession,
  subjectHub: SubjectHub, subjectTopic: SubjectTopic, subjectQuiz: SubjectQuiz, subjectPaperViewer: SubjectPaperViewer, worksheet: WorksheetSession,
  referenceSheets: ReferenceSheets,
  learningCardHub: LearningCardHub, learningCard: LearningCard
};

export const app = {
  student: null,
  history: [],
  _current: null,

  gradeManager() { return new GradeManager(this.student?.grade ?? LOCKED_GRADE); },
  questionEngine() { return new UnifiedQuestionEngine(this.student?.grade ?? LOCKED_GRADE); },

  saveStudent() { if (this.student) db.writeStudentRaw(this.student); },
  loadStudentByCode(code) { return db.readStudentRaw(code); },
  saveStudentByCode(student) { db.writeStudentRaw(student); },

  applyThemeAndFont() {
    const s = this.student?.settings || {};
    applyTheme(s.theme || "Candy", s.font_scale || "Normal");
  },
  syncAudioFromSettings() {
    const s = this.student?.settings || {};
    try { syncFromSettings(s); } catch (e) { /* audio optional */ }
  },

  async navigate(name, params = {}) {
    if (this._current) this.history.push(this._current);
    await this._render(name, params);
  },
  async replace(name, params = {}) { await this._render(name, params); },
  async resetTo(name, params = {}) { this.history = []; await this._render(name, params); },
  async goBack() {
    const prev = this.history.pop();
    if (prev) await this._render(prev.name, prev.params);
    else await this._render("home", {});
  },
  async refreshCurrentScreen() {
    if (this._current) await this._render(this._current.name, this._current.params, true);
  },

  async _render(name, params, isRefresh = false) {
    const fn = SCREENS[name];
    if (!fn) { console.error("Unknown screen:", name); return; }
    if (this._cleanup) { try { this._cleanup(); } catch { /* ignore */ } this._cleanup = null; }
    if (this.student && name !== "login") this.saveStudent();
    const root = document.getElementById("app");
    root.innerHTML = "";
    root.className = "";
    let def;
    try {
      def = await fn(this, params);
    } catch (err) {
      console.error(err);
      def = {
        title: "Oops",
        showBack: true,
        body: [el("div", { class: "card" }, [
          el("div", { class: "role-heading" }, "Something went wrong"),
          el("div", { class: "role-subtitle wrap" }, String(err && err.message || err))
        ])]
      };
    }
    if (!isRefresh) this._current = { name, params };
    this._cleanup = def.onUnmount || null;
    this._mount(def);
  },

  _mount(def) {
    const root = document.getElementById("app");
    const showBack = def.showBack === false ? false : true;
    const top = !showBack
      ? el("div", { class: "screen-top" }, [el("div", { class: "screen-title" }, def.title)])
      : el("div", { class: "screen-top" }, [
          el("button", { class: "btn-secondary btn-sm", style: "width:2.6rem;flex:none;", onClick: () => this.goBack() }, "←"),
          el("div", { class: "screen-title" }, def.title)
        ]);
    const screen = el("div", { class: "screen" }, [top, el("div", { class: "screen-body" }, def.body || [])]);
    if (def.bottomNavKey) root.className = "has-bottomnav";
    root.appendChild(screen);
    if (def.bottomNavKey) root.appendChild(bottomNav(this, def.bottomNavKey));
    window.scrollTo(0, 0);
  },

  showHome() { return this.resetTo("home"); },
  showLearn() {
    return this.navigate("subjectHub");
  },
  showTopicDetail(topicId) {
    return this.navigate("subjectTopic", { topicId });
  },
  showTopicPicker() { return this.navigate("subjectHub"); },
  showPractice(mode, topics) {
    return this.navigate("practiceSetup", { mode: mode || "choose", topics: topics || null });
  },
  launchPracticeSession(opts) { return this.navigate("practiceSession", opts); },
  showPapers() {
    return this.navigate("papers", { view: "hub" });
  },
  showPaperViewer(paperId, opts = {}) { return this.navigate("paperViewer", { paperId, ...opts }); },
  showProfile() { return this.navigate("profile"); },
  showSettings() { return this.navigate("settings"); },
  showDiagramGallery() { return this.navigate("diagramGallery"); },
  showLabs() { return this.navigate("labs"); },
  showGeometryLab() { return this.navigate("geometryLab"); },
  showDataLab() { return this.navigate("dataLab"); },
  showProbabilityLab() { return this.navigate("probabilityLab"); },
  showMental() { return this.navigate("mental"); },
  showScience() { return this.navigate("subjectHub"); },
  showWorksheet(opts = {}) { return this.navigate("worksheet", opts); },
  showSubjectHub() {
    return this.navigate("subjectHub");
  },
  showScienceTopic(topicId) { return this.navigate("scienceTopic", { topicId }); },
  showQuiz(subject = "math", topicId = null) { return this.navigate("quiz", { subject, topicId }); },
  showTipsTricks() { return this.navigate("tipsTricks"); },
  showAchievements() { return this.navigate("achievements"); },
  showEconomy() { return this.navigate("economy"); },
  showRewards() { return this.navigate("rewards"); },
  showTeach() { return this.navigate("teachHub"); },
  showStructured() { return this.navigate("structuredHub"); },
  showSolidsLab() { return this.navigate("solidsLab"); },
  showReferenceSheets() { return this.navigate("referenceSheets"); },

  async showDevModeGate() {
    const code = await showPrompt("Dev Mode", "Access code:", "", true);
    if (code === null) return;
    if (code.trim().toLowerCase() === ACCESS_CODE) this.navigate("devMode");
    else showAlert("Access denied", "Incorrect code.");
  },

  // -------- auth (Grade 10 lock) --------
  async login(code, grade = LOCKED_GRADE, name = null, opts = {}) {
    const g = LOCKED_GRADE;
    this.student = db.login(code || SINGLE_CODE, g, name);
    this.student.grade = LOCKED_GRADE;
    this.student.programme_name = this.student.programme_name || OWNER;
    if (opts && opts.gender) this.student.gender = opts.gender;
    if (opts && opts.theme) {
      this.student.settings = this.student.settings || {};
      this.student.settings.theme = opts.theme;
      try {
        const { applyTheme } = await import("./theme.js");
        applyTheme(opts.theme, this.student.settings.font_scale || "Normal");
      } catch { /* ignore */ }
    }
    try {
      const { loadSubjectRegistry, defaultSubject } = await import("./engines/subjectRegistry.js");
      await loadSubjectRegistry();
      this.student.subject = this.student.subject || defaultSubject(LOCKED_GRADE);
      const allowed = ["mathematical_literacy", "business_studies", "tourism"];
      if (!allowed.includes(this.student.subject)) this.student.subject = "mathematical_literacy";
    } catch {
      this.student.subject = this.student.subject || "mathematical_literacy";
    }
    this.student.settings = this.student.settings || {};
    if (opts.theme) this.student.settings.theme = opts.theme;
    try {
      const { EconomyEngine } = await import("./engines/economyEngine.js");
      const granted = new EconomyEngine(this.student).grantStarterStars(2000);
      if (granted) this.saveStudent();
    } catch { /* ignore */ }
    this.saveStudent();
    try { localStorage.setItem(SESSION_KEY, "1"); } catch { /* ignore */ }
    this.applyThemeAndFont();
    this.syncAudioFromSettings();
    await this.resetTo("home");
  },

  async logout() {
    // Soft sign-out only clears in-memory state; invite remains valid and profile stays.
    this.saveStudent();
    this.student = null;
    this.history = [];
    try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
    await this.resetTo("login");
  },

  async changeGrade() {
    showAlert("Grade locked", "This build is Grade 10 only — Mathematical Literacy, Business Studies and Tourism.");
  }
};

function inviteAccepted() {
  try { return localStorage.getItem(INVITE_KEY) === "1"; } catch { return false; }
}
function markInviteAccepted() {
  try { localStorage.setItem(INVITE_KEY, "1"); } catch { /* ignore */ }
}
function sessionActive() {
  try { return localStorage.getItem(SESSION_KEY) === "1"; } catch { return false; }
}

/** 15-day rolling licence — implemented in db.js */
export const getLicenceUntil = db.getLicenceUntil;
export const licenceDaysLeft = db.licenceDaysLeft;
export const isLicenceValid = db.isLicenceValid;
export const activateLicence = db.activateLicence;

async function showInviteGate() {
  const root = document.getElementById("app");
  root.innerHTML = "";
  root.className = "";
  applyTheme("Midnight", "Normal");

  const pw = el("input", {
    type: "password",
    placeholder: "Invite password",
    autocomplete: "current-password",
    style: "width:100%;letter-spacing:0.12em;font-size:1.08rem;padding:0.95rem 1.1rem;border-radius:0.9rem;" +
      "border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.07);color:#f8fafc;" +
      "outline:none;box-shadow:inset 0 1px 0 rgba(255,255,255,0.06);"
  });

  const status = el("div", {
    class: "role-muted wrap center",
    style: "min-height:1.35rem;margin-top:0.45rem;font-weight:600;font-size:0.88rem;"
  }, "");

  const enter = async () => {
    const val = (pw.value || "").trim().toLowerCase();
    if (val === INVITE_PASSWORD.toLowerCase()) {
      markInviteAccepted();
      activateLicence(LICENCE_DAYS);
      status.textContent = "Access granted · preparing your academy workspace…";
      status.style.color = "#34d399";
      await bootAfterInvite();
    } else {
      status.textContent = "Incorrect password. This app is invite only.";
      status.style.color = "#f87171";
      pw.value = "";
      pw.focus();
    }
  };

  pw.addEventListener("keydown", (e) => { if (e.key === "Enter") enter(); });

  const subjects = el("div", {
    style: "display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;margin:1rem 0 1.15rem;"
  }, [
    ["📐", "Math Literacy", "Finance · Data · Maps"],
    ["💼", "Business Studies", "Environments · Ventures"],
    ["✈️", "Tourism", "Sectors · Service"],
    ["📜", "CAPS · ATP", "Grade 10 exam ready"]
  ].map(([icon, t, s]) => el("div", {
    style: "padding:0.65rem 0.7rem;border-radius:0.85rem;background:rgba(255,255,255,0.05);" +
      "border:1px solid rgba(255,255,255,0.09);backdrop-filter:blur(8px);"
  }, [
    el("div", { style: "font-size:1.15rem;line-height:1;" }, icon),
    el("div", { style: "font-weight:800;font-size:0.8rem;margin-top:0.35rem;letter-spacing:0.02em;" }, t),
    el("div", { style: "opacity:0.65;font-size:0.7rem;margin-top:0.12rem;" }, s)
  ])));

  const panel = el("div", {
    style: "max-width:26rem;width:100%;margin:0 auto;padding:1.75rem 1.45rem 1.55rem;border-radius:1.5rem;" +
      "background:linear-gradient(165deg,rgba(30,27,75,0.92),rgba(15,23,42,0.96));" +
      "border:1px solid rgba(167,139,250,0.28);box-shadow:0 25px 60px rgba(0,0,0,0.45),0 0 0 1px rgba(255,255,255,0.04) inset;"
  }, [
    el("div", {
      style: "text-align:center;margin-bottom:0.35rem;"
    }, [
      el("div", {
        style: "display:inline-flex;align-items:center;justify-content:center;width:3.4rem;height:3.4rem;border-radius:1rem;" +
          "background:linear-gradient(135deg,#6366f1,#a855f7);font-size:1.45rem;box-shadow:0 8px 24px rgba(99,102,241,0.45);"
      }, "☀️"),
      el("div", {
        style: "margin-top:0.85rem;font-size:0.72rem;font-weight:800;letter-spacing:0.18em;text-transform:uppercase;" +
          "color:#c4b5fd;"
      }, "THE ELITES ACADEMY"),
      el("div", {
        style: "margin-top:0.35rem;font-size:1.55rem;font-weight:900;letter-spacing:-0.03em;color:#f8fafc;"
      }, "Learnly Grade 10"),
      el("div", {
        style: "margin-top:0.4rem;font-size:0.88rem;opacity:0.78;line-height:1.45;color:#e2e8f0;"
      }, "Invite-only CAPS workspace for Mathematical Literacy, Business Studies and Tourism.")
    ]),
    subjects,
    el("label", {
      class: "field-label",
      style: "opacity:0.85;color:#e2e8f0;font-size:0.78rem;letter-spacing:0.04em;"
    }, "INVITE PASSWORD"),
    pw,
    el("button", {
      class: "btn",
      style: "margin-top:0.95rem;width:100%;padding:0.95rem;font-weight:800;border-radius:0.9rem;font-size:1rem;" +
        "background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 50%,#a855f7 100%);border:none;" +
        "box-shadow:0 10px 28px rgba(99,102,241,0.4);color:#fff;",
      onClick: enter
    }, "Unlock academy access"),
    status,
    el("div", {
      style: "margin-top:1.2rem;text-align:center;font-size:0.72rem;opacity:0.5;line-height:1.5;color:#cbd5e1;"
    }, "One-time unlock on this device · 15-day licence · then renew with an activation code from The Elites Academy")
  ]);

  root.appendChild(el("div", {
    class: "screen",
    style: "display:flex;align-items:center;justify-content:center;min-height:100dvh;padding:1.35rem;" +
      "background:" +
      "radial-gradient(ellipse at 15% 5%,rgba(99,102,241,0.35),transparent 55%)," +
      "radial-gradient(ellipse at 85% 95%,rgba(168,85,247,0.28),transparent 50%)," +
      "radial-gradient(ellipse at 50% 50%,rgba(15,23,42,0.5),#070b16 80%);"
  }, [panel]));

  setTimeout(() => pw.focus(), 80);
}

async function showLicenceGate() {
  const root = document.getElementById("app");
  root.innerHTML = "";
  root.className = "";
  applyTheme("Midnight", "Normal");

  const code = el("input", {
    type: "password",
    placeholder: "Activation code",
    autocomplete: "off",
    style: "width:100%;letter-spacing:0.1em;font-size:1.05rem;padding:0.9rem 1rem;border-radius:0.85rem;" +
      "border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.07);color:#f8fafc;"
  });
  const status = el("div", {
    style: "min-height:1.3rem;margin-top:0.4rem;font-weight:600;font-size:0.88rem;text-align:center;"
  }, "");

  const renew = () => {
    const val = (code.value || "").trim().toLowerCase();
    if (val === ACTIVATION_CODE.toLowerCase() || val === INVITE_PASSWORD.toLowerCase()) {
      const until = activateLicence(LICENCE_DAYS);
      status.textContent = `Licence renewed · valid until ${until.toLocaleDateString()}`;
      status.style.color = "#34d399";
      setTimeout(() => bootAfterInvite(), 600);
    } else {
      status.textContent = "Invalid activation code.";
      status.style.color = "#f87171";
      code.value = "";
      code.focus();
    }
  };
  code.addEventListener("keydown", (e) => { if (e.key === "Enter") renew(); });

  const panel = el("div", {
    style: "max-width:26rem;width:100%;margin:0 auto;padding:1.7rem 1.4rem;border-radius:1.4rem;" +
      "background:linear-gradient(165deg,rgba(30,27,75,0.95),rgba(15,23,42,0.98));" +
      "border:1px solid rgba(251,191,36,0.35);box-shadow:0 24px 50px rgba(0,0,0,0.5);"
  }, [
    el("div", { style: "text-align:center;" }, [
      el("div", { style: "font-size:2rem;" }, "⏳"),
      el("div", {
        style: "margin-top:0.5rem;font-size:0.72rem;font-weight:800;letter-spacing:0.16em;color:#fcd34d;text-transform:uppercase;"
      }, "LICENCE EXPIRED"),
      el("div", {
        style: "margin-top:0.4rem;font-size:1.25rem;font-weight:900;color:#f8fafc;"
      }, "Renew to continue"),
      el("div", {
        style: "margin-top:0.55rem;font-size:0.88rem;line-height:1.5;opacity:0.8;color:#e2e8f0;"
      }, "Your 15-day access has ended. Contact The Elites Academy for an update or enter your activation code to renew for another 15 days.")
    ]),
    el("div", {
      style: "margin:1rem 0;padding:0.75rem 0.85rem;border-radius:0.85rem;background:rgba(251,191,36,0.08);border:1px solid rgba(251,191,36,0.2);font-size:0.82rem;line-height:1.45;color:#fde68a;"
    }, "Developer: The Elites Academy · Activation renews this device for 15 days."),
    el("label", { style: "font-size:0.75rem;font-weight:700;letter-spacing:0.06em;color:#e2e8f0;opacity:0.85;" }, "ACTIVATION CODE"),
    code,
    el("button", {
      class: "btn",
      style: "margin-top:0.85rem;width:100%;padding:0.9rem;font-weight:800;border-radius:0.85rem;" +
        "background:linear-gradient(135deg,#f59e0b,#eab308);border:none;color:#1c1917;",
      onClick: renew
    }, "Renew licence"),
    status
  ]);

  root.appendChild(el("div", {
    class: "screen",
    style: "display:flex;align-items:center;justify-content:center;min-height:100dvh;padding:1.35rem;" +
      "background:radial-gradient(ellipse at 30% 20%,rgba(245,158,11,0.18),transparent 50%),#070b16;"
  }, [panel]));
  setTimeout(() => code.focus(), 80);
}

async function bootAfterInvite() {
  applyTheme("Candy", "Normal");
  if (!isLicenceValid()) {
    await showLicenceGate();
    return;
  }
  // Restore session if student already signed in on this device
  if (sessionActive()) {
    const existing = db.readStudentRaw(SINGLE_CODE);
    if (existing && existing.name) {
      app.student = existing;
      app.student.grade = LOCKED_GRADE;
      app.student.programme_name = app.student.programme_name || OWNER;
      try {
        const { loadSubjectRegistry, defaultSubject } = await import("./engines/subjectRegistry.js");
        await loadSubjectRegistry();
        const allowed = ["mathematical_literacy", "business_studies", "tourism"];
        if (!app.student.subject || !allowed.includes(app.student.subject)) {
          app.student.subject = defaultSubject(LOCKED_GRADE);
        }
      } catch {
        app.student.subject = app.student.subject || "mathematical_literacy";
      }
      app.applyThemeAndFont();
      app.syncAudioFromSettings();
      await app.resetTo("home");
      return;
    }
  }
  await app.resetTo("login");
}

export async function boot() {
  try {
    await preloadGrades();
  } catch (err) {
    document.getElementById("app").innerHTML =
      `<div class="screen"><div class="card"><div class="role-heading">Could not load Learnly</div><div class="role-subtitle wrap">${String(err.message || err)}</div></div></div>`;
    return;
  }
  if (!inviteAccepted()) {
    await showInviteGate();
    return;
  }
  if (!isLicenceValid()) {
    // If invite was accepted previously but licence never set, start one; if expired, gate
    if (!getLicenceUntil()) {
      activateLicence(LICENCE_DAYS);
    } else {
      await showLicenceGate();
      return;
    }
  }
  await bootAfterInvite();
}
