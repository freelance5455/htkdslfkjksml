(function(){
"use strict";
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
const money=n=>new Intl.NumberFormat("fa-IR").format(Math.round(Number(n)||0));
const today=()=>new Date().toLocaleDateString("fa-IR");
const state={page:"home",editingService:null,editingVehicle:null,editingOp:null,invoice:{vehicleId:"",items:[],customer:{name:"",mobile:"",plate:"",mileage:"",notes:""},discountType:"amount",discountValue:0},detailId:null};

function shell(){
 const s=DB.settings();
 $("#app").innerHTML=`<header><div class="brand">${esc(s.business_name)}</div><button class="primary small" onclick="newInvoice()">+ فاکتور جدید</button></header>
 <main id="view"></main>
 <nav class="bottom">
  <button onclick="go('home')">⌂<span>خانه</span></button><button onclick="go('invoices')">▤<span>فاکتورها</span></button>
  <button onclick="go('services')">⚙<span>خدمات</span></button><button onclick="go('vehicles')">🚗<span>خودروها</span></button><button onclick="go('settings')">☰<span>تنظیمات</span></button>
 </nav>`;
 render();
}
function go(p){state.page=p;render()}
function newInvoice(){state.invoice={vehicleId:"",items:[],customer:{name:"",mobile:"",plate:"",mileage:"",notes:""},discountType:"amount",discountValue:0};state.page="new";render()}
function render(){if(state.page==="home")home();else if(state.page==="new")invoicePage();else if(state.page==="invoices")invoices();else if(state.page==="detail")detail();else if(state.page==="services")services();else if(state.page==="vehicles")vehicles();else if(state.page==="settings")settings();window.scrollTo(0,0);if(window.normalizePlateNumbers)normalizePlateNumbers()}

function home(){
 const inv=DB.invoices(), sv=DB.services(), vh=DB.allVehicles();
 $("#view").innerHTML=`<section class="hero"><div><div class="eyebrow">OFFLINE WORKSHOP TOOL</div><h1>${esc(DB.settings().business_name)}</h1><p>محاسبه اجرت و صدور فاکتور، بدون نیاز به اینترنت.</p></div><button class="primary heroBtn" onclick="newInvoice()">فاکتور جدید</button></section>
 <div class="grid3"><div class="stat"><b>${inv.length}</b><span>فاکتور ثبت‌شده</span></div><div class="stat"><b>${sv.length}</b><span>خدمت</span></div><div class="stat"><b>${vh.length}</b><span>خودرو</span></div></div>
 <div class="sectionHead"><h2>دسترسی سریع</h2></div><div class="cards">
 <button class="card action" onclick="newInvoice()"><strong>＋ فاکتور جدید</strong><span>انتخاب خودرو و خدمات</span></button>
 <button class="card action" onclick="go('invoices')"><strong>▤ فاکتورهای قبلی</strong><span>جستجو، مشاهده و حذف</span></button>
 <button class="card action" onclick="go('services')"><strong>⚙ خدمات و قیمت‌ها</strong><span>مدیریت خدمت، عملیات و اجرت</span></button>
 <button class="card action" onclick="go('vehicles')"><strong>🚗 خودروها</strong><span>دسته‌بندی قیمت‌گذاری</span></button>
 </div>`;
}

function invoicePage(){
 const d=state.invoice, vs=DB.vehicles(), services=DB.services();
 const v=vs.find(x=>x.id===d.vehicleId), tier=v?v.tier:"other";
 const subtotal=d.items.reduce((a,i)=>a+i.price,0), disc=d.discountType==="percent"?subtotal*(Number(d.discountValue)||0)/100:Number(d.discountValue)||0, total=Math.max(0,subtotal-disc);
 $("#view").innerHTML=`<div class="pageHead"><button class="back" onclick="go('home')">←</button><div><h2>فاکتور جدید</h2><small>مرحله ۱ و ۲ و ۳ در یک صفحه</small></div></div>
 <div class="card formCard"><label>خودرو</label><select onchange="setVehicle(this.value)"><option value="">انتخاب خودرو...</option>${vs.map(x=>`<option value="${x.id}" ${x.id===d.vehicleId?"selected":""}>${esc(x.name)}</option>`).join("")}</select>
 ${v?`<div class="hint">گروه قیمت: ${tierLabel(tier)}</div>`:""}</div>
 <div class="card"><div class="sectionHead"><h3>خدمات و عملیات</h3></div>${services.length?services.map(s=>servicePicker(s,tier)).join(""):`<div class="empty">هنوز خدمتی تعریف نشده. از بخش خدمات اضافه کن.</div>`}</div>
 <div class="card"><h3>آیتم‌های انتخاب‌شده</h3>${d.items.length?d.items.map((i,n)=>`<div class="line"><div><b>${esc(i.operationName)}</b><small>${esc(i.serviceName)}</small></div><div class="lineRight"><input class="miniPrice" type="number" value="${i.price}" onchange="changeItemPrice(${n},this.value)"><button class="dangerText" onclick="removeItem(${n})">×</button></div></div>`).join(""):`<div class="empty">هنوز عملیاتی انتخاب نشده.</div>`}</div>
 <div class="card"><h3>اطلاعات مشتری</h3><div class="formGrid">
 <label>نام مشتری<input id="cname" value="${esc(d.customer.name)}"></label><label>موبایل<input id="cmobile" inputmode="tel" value="${esc(d.customer.mobile)}"></label>
 <div><label>پلاک</label>${plateEditor(d.customer.plate)}</div><label>کیلومتر<input id="cmileage" inputmode="numeric" value="${esc(d.customer.mileage)}"></label>
 <label class="full">یادداشت<textarea id="cnotes">${esc(d.customer.notes)}</textarea></label></div></div>
 <div class="card"><h3>تخفیف</h3><div class="discountRow"><select id="dtype"><option value="amount" ${d.discountType==="amount"?"selected":""}>مبلغ</option><option value="percent" ${d.discountType==="percent"?"selected":""}>درصد</option></select><input id="dval" type="number" value="${d.discountValue||""}" placeholder="0"></div></div>
 <div class="totalBox"><div><span>جمع خدمات</span><b>${money(subtotal)} ${esc(DB.settings().currency_label)}</b></div><div><span>تخفیف</span><b>${money(disc)}</b></div><div class="final"><span>مبلغ نهایی</span><strong>${money(total)} ${esc(DB.settings().currency_label)}</strong></div></div>
 <button class="primary wide" onclick="saveInvoice()">ثبت فاکتور</button>`;
}
function tierLabel(t){return t==="saipa"?"سایپا":t==="irankhodro"?"ایران‌خودرو":"سایر"}
function servicePicker(s,tier){
 const ops=DB.operations(s.id); return `<div class="serviceBlock"><div class="serviceTitle">${esc(s.name)}</div>${ops.map(o=>`<label class="opRow"><span><input type="checkbox" ${state.invoice.items.some(i=>i.operationId===o.id)?"checked":""} onchange="toggleItem('${o.id}')"><span>${esc(o.name)}</span></span><b>${money(o.prices?.[tier]||0)}</b></label>`).join("")}</div>`
}
function setVehicle(id){state.invoice.vehicleId=id;render()}
function toggleItem(id){
 const op=DB.allOperations().find(x=>x.id===id), s=DB.allServices().find(x=>x.id===op.service_id), v=DB.allVehicles().find(x=>x.id===state.invoice.vehicleId), tier=v?.tier||"other";
 const idx=state.invoice.items.findIndex(i=>i.operationId===id);
 if(idx>=0)state.invoice.items.splice(idx,1);else state.invoice.items.push({operationId:id,operationName:op.name,serviceName:s?.name||"",price:Number(op.prices?.[tier]||0)});
 render()
}
function removeItem(i){state.invoice.items.splice(i,1);render()}
function changeItemPrice(i,v){state.invoice.items[i].price=Number(v)||0;render()}
function readCustomer(){state.invoice.customer={name:$("#cname")?.value||"",mobile:$("#cmobile")?.value||"",plate:getPlateValue(),mileage:$("#cmileage")?.value||"",notes:$("#cnotes")?.value||""};state.invoice.discountType=$("#dtype")?.value||"amount";state.invoice.discountValue=Number($("#dval")?.value)||0}
function saveInvoice(){
 readCustomer(); const d=state.invoice;if(!d.vehicleId){alert("ابتدا خودرو را انتخاب کن.");return} if(!d.items.length){alert("حداقل یک عملیات انتخاب کن.");return}
 const v=DB.allVehicles().find(x=>x.id===d.vehicleId), subtotal=d.items.reduce((a,i)=>a+i.price,0), disc=d.discountType==="percent"?subtotal*d.discountValue/100:d.discountValue;
 const invNo=`${DB.settings().invoice_prefix||"HE"}-${new Date().toISOString().slice(2,10).replace(/-/g,"")}-${String(Date.now()).slice(-4)}`;
 DB.addInvoice({invoice_no:invNo,vehicle_name:v.name,vehicle_tier:v.tier,customer:d.customer,items:d.items,subtotal,discount:Math.min(subtotal,Math.max(0,disc)),discount_type:d.discountType,discount_value:d.discountValue,total:Math.max(0,subtotal-Math.min(subtotal,Math.max(0,disc)))});
 state.detailId=DB.invoices()[0].id;state.page="detail";render();
}

function invoices(){
 const arr=DB.invoices();
 $("#view").innerHTML=`<div class="pageHead"><div><h2>فاکتورهای قبلی</h2><small>${arr.length} فاکتور ثبت شده</small></div><button class="primary small" onclick="newInvoice()">+ جدید</button></div>
 <div class="card formCard"><input id="invoiceSearch" placeholder="جستجو: نام، موبایل، پلاک یا شماره فاکتور" oninput="filterInvoices(this.value)"></div>
 <div id="invoiceList">${invoiceRows(arr)}</div>`;
}
function invoiceRows(arr){return arr.length?arr.map(i=>`<button class="invoiceRow" onclick="openDetail('${i.id}')"><div><b>${esc(i.invoice_no)}</b><span>${esc(i.vehicle_name)} · ${esc(i.customer?.name||"بدون نام")}</span><small>${new Date(i.created_at).toLocaleDateString("fa-IR")}</small></div><strong>${money(i.total)}</strong></button>`).join(""):`<div class="empty">فاکتوری وجود ندارد.</div>`}
function filterInvoices(q){q=q.trim().toLowerCase();const a=DB.invoices().filter(i=>[i.customer?.name,i.customer?.mobile,i.customer?.plate,i.vehicle_name,i.invoice_no].some(x=>String(x||"").toLowerCase().includes(q)));$("#invoiceList").innerHTML=invoiceRows(a)}
function openDetail(id){state.detailId=id;state.page="detail";render()}
function detail(){
 const i=DB.invoices().find(x=>x.id===state.detailId);if(!i){go("invoices");return}
 $("#view").innerHTML=`<div class="pageHead"><button class="back" onclick="go('invoices')">←</button><div><h2>جزئیات فاکتور</h2><small>${esc(i.invoice_no)}</small></div></div>
 <div class="card printCard"><div class="invoiceTop"><div><b>${esc(DB.settings().business_name)}</b><span>${esc(i.invoice_no)}</span></div><span>${new Date(i.created_at).toLocaleDateString("fa-IR")}</span></div>
 <div class="customerBox"><b>${esc(i.vehicle_name)}</b><span>مشتری: ${esc(i.customer?.name||"-")}</span><span>پلاک: ${esc(i.customer?.plate||"-")}</span><span>موبایل: ${esc(i.customer?.mobile||"-")}</span><span>کیلومتر: ${esc(i.customer?.mileage||"-")}</span></div>
 ${i.items.map(x=>`<div class="line"><div><b>${esc(x.operationName)}</b><small>${esc(x.serviceName)}</small></div><b>${money(x.price)}</b></div>`).join("")}
 <div class="summary"><div>جمع خدمات <b>${money(i.subtotal)}</b></div><div>تخفیف <b>${money(i.discount)}</b></div><div class="final">نهایی <strong>${money(i.total)} ${esc(DB.settings().currency_label)}</strong></div></div>
 ${i.customer?.notes?`<div class="notes"><b>یادداشت:</b> ${esc(i.customer.notes)}</div>`:""}</div>
 <button class="primary wide noPrint" onclick="printInvoice()">پرینت / ذخیره به PDF (A4)</button>
 <button class="danger wide noPrint" onclick="deleteInvoice('${i.id}')">حذف فاکتور</button>`;
}
function closeInvoiceView(){
  if(typeof renderInvoiceList==="function"){ renderInvoiceList(); }
  else if(typeof go==="function"){ go("invoices"); }
}
function printInvoice(){
  const id=state.detailId||state.currentInvoiceId||state.invoiceId;
  const i=DB.invoices().find(x=>String(x.id)===String(id))||state.currentInvoice||state.detail;
  if(!i){alert("ابتدا یک فاکتور را باز کنید.");return;}
  const settings=DB.settings();
  const fa=n=>new Intl.NumberFormat("fa-IR").format(Math.round(Number(n)||0));
  const esc=x=>String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
  const rows=(i.items||[]).map((x,n)=>`<tr><td>${n+1}</td><td>${esc(x.serviceName||"-")}</td><td>${esc(x.operationName||"-")}</td><td>${fa(x.price)}</td></tr>`).join("");
  const app=document.getElementById("app");
  app.innerHTML=`<div class="invoiceShot" dir="rtl">
    <div class="shotHead">
      <div><div class="shotBrand">${esc(settings.business_name||"Hadi Engine Tuning")}</div><div class="shotTitle">فاکتور خدمات</div></div>
      <div class="shotMeta">شماره: ${esc(i.invoice_no||"-")}<br>تاریخ: ${new Date(i.created_at||Date.now()).toLocaleDateString("fa-IR")}</div>
    </div>
    <div class="shotInfo">
      <div><b>مشتری</b><br>${esc(i.customer?.name||"-")}<br>${esc(i.customer?.mobile||"-")}</div>
      <div><b>خودرو</b><br>${esc(i.vehicle_name||"-")}<br>پلاک: ${esc(i.customer?.plate||"-")}<br>کیلومتر: ${esc(i.customer?.mileage||"-")}</div>
    </div>
    <table class="shotTable"><thead><tr><th>ردیف</th><th>خدمت</th><th>عملیات</th><th>مبلغ</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="shotTotals">
      <div><span>جمع خدمات</span><b>${fa(i.subtotal)} ${esc(settings.currency_label||"تومان")}</b></div>
      <div><span>تخفیف</span><b>${fa(i.discount)} ${esc(settings.currency_label||"تومان")}</b></div>
      <div class="grand"><span>مبلغ نهایی</span><b>${fa(i.total)} ${esc(settings.currency_label||"تومان")}</b></div>
    </div>
    ${i.customer?.notes?`<div class="shotNotes"><b>یادداشت:</b> ${esc(i.customer.notes)}</div>`:""}
    <div class="shotFooter">Hadi Engine Tuning</div>
    
  <button type="button" class="invoiceClose" data-close-invoice="1" aria-label="بستن فاکتور">×</button></div>`;
  const closeBtn=app.querySelector('[data-close-invoice="1"]');
  if(closeBtn){
    closeBtn.addEventListener("click",function(e){
      e.preventDefault();
      e.stopPropagation();
      renderInvoiceList();
    });
  }

} 
function deleteInvoice(id){if(confirm("این فاکتور حذف شود؟")){DB.deleteInvoice(id);go("invoices")}}

function services(){
 const sv=DB.allServices();
 $("#view").innerHTML=`<div class="pageHead"><div><h2>خدمات و قیمت‌ها</h2><small>سه سطح قیمت: سایپا، ایران‌خودرو، سایر</small></div><button class="primary small" onclick="serviceForm()">+ خدمت</button></div>
 <div class="card">${sv.length?sv.map((s,idx)=>`<div class="serviceAdmin"><div class="adminHead"><div><b>${esc(s.name)}</b>${s.enabled===false?`<em>غیرفعال</em>`:""}</div><div class="adminBtns"><button onclick="DB.reorderService('${s.id}',-1);services()">↑</button><button onclick="DB.reorderService('${s.id}',1);services()">↓</button><button onclick="serviceForm('${s.id}')">ویرایش</button><button onclick="toggleService('${s.id}')">${s.enabled===false?"فعال":"خاموش"}</button><button class="dangerText" onclick="deleteService('${s.id}')">حذف</button></div></div>
 <div class="ops">${DB.allOperations(s.id).map(o=>`<div class="opAdmin"><span>${esc(o.name)}${o.enabled===false?" · خاموش":""}</span><span class="prices">${money(o.prices?.saipa)} / ${money(o.prices?.irankhodro)} / ${money(o.prices?.other)}</span><span><button onclick="opForm('${o.id}')">ویرایش</button><button onclick="DB.reorderOperation('${o.id}',-1);services()">↑</button><button onclick="DB.reorderOperation('${o.id}',1);services()">↓</button></span></div>`).join("")}
 <button class="addOp" onclick="opForm(null,'${s.id}')">＋ عملیات</button></div></div>`).join(""):`<div class="empty">خدمتی ثبت نشده.</div>`}</div>`;
}


function normalizePlateNumbers(){
 document.querySelectorAll(".plateNum2,.plateNum3").forEach(el=>{
   el.addEventListener("input",()=>{el.value=el.value.replace(/[^\d۰-۹]/g,"");});
   el.addEventListener("focus",()=>{try{el.setAttribute("inputmode","numeric");}catch(e){}});
 });
}

function plateEditor(value=""){
  const p=String(value||"").split("-");
  const a=p[0]||"", letter=p[1]||"", b=p[2]||"", iran=p[3]||"59";
  const letters=["الف","ب","پ","ت","ث","ج","چ","ح","خ","د","ذ","ر","ز","ژ","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ک","گ","ل","م","ن","و","ه","ی"];
  return `<div class="plateEditor">
    <div class="platePreview">
      <input class="plateNum2" inputmode="numeric" maxlength="2" value="${a}" placeholder="۱۲">
      <input class="plateLetter plateLetterInput" maxlength="1" inputmode="text" value="${letter||""}" placeholder="ب" aria-label="حرف پلاک">
      <input class="plateNum3" inputmode="numeric" maxlength="3" value="${b}" placeholder="۱۲۳">
      <span class="plateIran">ایران<br><b>${iran}</b></span>
    </div>
    <input type="hidden" class="plateValue" value="${value}">
  </div>`;
}
function openLetterPad(btn){
  const letters=["الف","ب","پ","ت","ث","ج","چ","ح","خ","د","ذ","ر","ز","ژ","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ک","گ","ل","م","ن","و","ه","ی"];
  const html=`<div class="letterGrid">${letters.map(x=>`<button type="button" onclick="pickPlateLetter(this,'${x}')">${x}</button>`).join("")}</div>`;
  modal("انتخاب حرف پلاک",html+`<button class="wide" onclick="closeModal()">بستن</button>`);
  window._plateLetterButton=btn;
}
function pickPlateLetter(btn,letter){
  if(window._plateLetterButton){window._plateLetterButton.textContent=letter;}
  closeModal();
}
function getPlateValue(){
  const box=document.querySelector(".plateEditor");
  if(!box)return "";
  const a=box.querySelector(".plateNum2")?.value||"";
  const l=box.querySelector(".plateLetter")?.value||"";
  const b=box.querySelector(".plateNum3")?.value||"";
  return `${a}-${l}-${b}-59`;
}

function closeModal(){const m=document.querySelector(".modalWrap");if(m)m.remove()}
function modal(title,body,saveFn){
 closeModal();
 const w=document.createElement("div");w.className="modalWrap";
 w.innerHTML=`<div class="modal"><div class="modalHead"><h3>${esc(title)}</h3><button onclick="closeModal()">×</button></div><div class="modalBody">${body}</div><div class="modalActions"><button class="secondary" onclick="closeModal()">انصراف</button><button class="primary" id="modalSave">ذخیره</button></div></div>`;
 document.body.appendChild(w); $("#modalSave").onclick=saveFn;
}
function serviceForm(id){
 const s=id?DB.allServices().find(x=>x.id===id):{name:""};
 modal(id?"ویرایش خدمت":"ثبت خدمت",`<label class="modalLabel">نام خدمت / قطعه<input id="mServiceName" value="${esc(s.name)}"></label>`,()=>{
   const name=$("#mServiceName").value.trim(); if(!name){alert("نام خدمت را وارد کن.");return}
   if(id)DB.updateService(id,{name});else DB.addService({name}); closeModal();services();
 });
}
function deleteService(id){if(confirm("خدمت و تمام عملیاتش حذف شود؟")){DB.deleteService(id);services()}}
function toggleService(id){const s=DB.allServices().find(x=>x.id===id);DB.updateService(id,{enabled:s.enabled===false});services()}
function opForm(id,serviceId){
 const o=id?DB.allOperations().find(x=>x.id===id):{name:"",service_id:serviceId,prices:{saipa:0,irankhodro:0,other:0}},p=o.prices||{};
 modal(id?"ویرایش عملیات":"ثبت عملیات",`
 <label class="modalLabel">نام عملیات<input id="mOpName" value="${esc(o.name)}"></label>
 <div class="priceGrid">
 <label class="modalLabel">سایپا<input id="mP1" type="number" inputmode="numeric" value="${p.saipa||0}"></label>
 <label class="modalLabel">ایران‌خودرو<input id="mP2" type="number" inputmode="numeric" value="${p.irankhodro||0}"></label>
 <label class="modalLabel">سایر<input id="mP3" type="number" inputmode="numeric" value="${p.other||0}"></label>
 </div>`,()=>{
   const name=$("#mOpName").value.trim(); if(!name){alert("نام عملیات را وارد کن.");return}
   const x={name,prices:{saipa:Number($("#mP1").value)||0,irankhodro:Number($("#mP2").value)||0,other:Number($("#mP3").value)||0}};
   if(id)DB.updateOperation(id,x);else DB.addOperation(Object.assign(x,{service_id:serviceId}));
   closeModal();services();
 });
}

function vehicles(){
 const vs=DB.allVehicles();
 $("#view").innerHTML=`<div class="pageHead"><div><h2>خودروها</h2><small>گروه قیمت‌گذاری هر خودرو</small></div><button class="primary small" onclick="vehicleForm()">+ خودرو</button></div>
 <div class="card">${vs.length?vs.map(v=>`<div class="vehicleRow"><div><b>${esc(v.name)}</b><span>${tierLabel(v.tier)} ${v.enabled===false?"· غیرفعال":""}</span></div><div><button onclick="vehicleForm('${v.id}')">ویرایش</button><button onclick="toggleVehicle('${v.id}')">${v.enabled===false?"فعال":"خاموش"}</button><button class="dangerText" onclick="deleteVehicle('${v.id}')">حذف</button></div></div>`).join(""):`<div class="empty">خودرویی ثبت نشده.</div>`}</div>`;
}
function vehicleForm(id){
 const v=id?DB.allVehicles().find(x=>x.id===id):{name:"",tier:"other"};
 modal(id?"ویرایش خودرو":"ثبت خودرو",`
 <label class="modalLabel">نام خودرو<input id="mVehicleName" value="${esc(v.name)}"></label>
 <label class="modalLabel">گروه قیمت<select id="mVehicleTier">
 <option value="saipa" ${v.tier==="saipa"?"selected":""}>سایپا</option>
 <option value="irankhodro" ${v.tier==="irankhodro"?"selected":""}>ایران‌خودرو</option>
 <option value="other" ${v.tier==="other"?"selected":""}>سایر</option>
 </select></label>`,()=>{
   const name=$("#mVehicleName").value.trim();if(!name){alert("نام خودرو را وارد کن.");return}
   const tier=$("#mVehicleTier").value;
   if(id)DB.updateVehicle(id,{name,tier});else DB.addVehicle({name,tier});
   closeModal();vehicles();
 });
}
function toggleVehicle(id){const v=DB.allVehicles().find(x=>x.id===id);DB.updateVehicle(id,{enabled:v.enabled===false});vehicles()}
function deleteVehicle(id){if(confirm("خودرو حذف شود؟")){DB.deleteVehicle(id);vehicles()}}

function settings(){
 const s=DB.settings();
 $("#view").innerHTML=`<div class="pageHead"><div><h2>تنظیمات</h2><small>اطلاعات برنامه و پشتیبان</small></div></div>
 <div class="card formCard"><label>نام کسب‌وکار<input id="biz" value="${esc(s.business_name)}"></label><label>واحد پول<input id="currency" value="${esc(s.currency_label)}"></label><label>پیشوند فاکتور<input id="prefix" value="${esc(s.invoice_prefix)}"></label><button class="primary wide" onclick="saveSettings()">ذخیره تنظیمات</button></div>
 <div class="card"><h3>پشتیبان‌گیری</h3><p class="muted">اطلاعات فقط روی همین گوشی ذخیره می‌شود. برای جلوگیری از دست‌رفتن اطلاعات، گاهی خروجی بگیر.</p><button class="secondary wide" onclick="exportBackup()">خروجی JSON</button><label class="fileBtn">ورود JSON<input type="file" accept=".json,application/json" onchange="importBackup(this.files[0])"></label></div>
 <div class="card"><h3>درباره</h3><p>Hadi Engine Tuning — Offline Edition</p><p class="muted">بدون سرور، بدون حساب کاربری، بدون وابستگی به اینترنت.</p></div>`;
}
function saveSettings(){DB.setSettings({business_name:$("#biz").value.trim()||"Hadi Engine Tuning",currency_label:$("#currency").value.trim()||"تومان",invoice_prefix:$("#prefix").value.trim()||"HE"});shell()}
function exportBackup(){const blob=new Blob([DB.export()],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="Hadi-Engine-Tuning-backup.json";a.click();URL.revokeObjectURL(a.href)}
function importBackup(file){if(!file)return;const r=new FileReader();r.onload=()=>{try{DB.import(r.result);alert("پشتیبان با موفقیت وارد شد.");shell()}catch(e){alert("فایل پشتیبان معتبر نیست.")}};r.readAsText(file)}

window.go=go;window.newInvoice=newInvoice;window.setVehicle=setVehicle;window.toggleItem=toggleItem;window.removeItem=removeItem;window.changeItemPrice=changeItemPrice;window.saveInvoice=saveInvoice;window.filterInvoices=filterInvoices;window.openDetail=openDetail;window.printInvoice=printInvoice;window.deleteInvoice=deleteInvoice;
window.serviceForm=serviceForm;window.deleteService=deleteService;window.toggleService=toggleService;window.opForm=opForm;window.vehicleForm=vehicleForm;window.toggleVehicle=toggleVehicle;window.deleteVehicle=deleteVehicle;window.saveSettings=saveSettings;window.exportBackup=exportBackup;window.importBackup=importBackup;window.services=services;window.vehicles=vehicles;
shell();
})();
window.closeInvoiceView=closeInvoiceView;
