document.addEventListener('DOMContentLoaded', () => {
    // Navigation Tabs
    const navButtons = document.querySelectorAll('.nav-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const currentTabTitle = document.getElementById('currentTabTitle');

    navButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.getAttribute('data-tab');
            navButtons.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(`tab-${targetTab}`).classList.add('active');
            currentTabTitle.textContent = btn.textContent.trim();
        });
    });

    // Mobile Sidebar Toggle
    const sidebar = document.getElementById('sidebar');
    document.getElementById('toggleSidebar').addEventListener('click', () => sidebar.classList.add('open'));
    document.getElementById('closeSidebar').addEventListener('click', () => sidebar.classList.remove('open'));

    // Mode Online/Offline Switch
    const modeSwitch = document.getElementById('modeSwitch');
    const statusText = document.getElementById('statusText');
    const modeLabel = document.getElementById('modeLabel');
    modeSwitch.addEventListener('change', (e) => {
        if (e.target.checked) {
            statusText.textContent = "Mode En Ligne";
            modeLabel.textContent = "En ligne";
        } else {
            statusText.textContent = "Mode Hors-Ligne";
            modeLabel.textContent = "Hors-Ligne";
        }
    });

    // Chat Assistant Logic
    const chatInput = document.getElementById('chatInput');
    const sendMessage = document.getElementById('sendMessage');
    const chatMessages = document.getElementById('chatMessages');

    function appendMessage(sender, text) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${sender === 'user' ? 'user-msg' : 'system-msg'}`;
        msgDiv.innerHTML = `
            <i class="fa-solid ${sender === 'user' ? 'fa-user' : 'fa-robot'}"></i>
            <div class="msg-content"><p>${text}</p></div>
        `;
        chatMessages.appendChild(msgDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    sendMessage.addEventListener('click', () => {
        const text = chatInput.value.trim();
        if (!text) return;
        appendMessage('user', text);
        chatInput.value = '';

        setTimeout(() => {
            appendMessage('system', `Analyse de votre demande : "${text}". Traitement avec les modèles de NOVA ULTIMATE AI en cours...`);
        }, 800);
    });

    // Modals
    const settingsModal = document.getElementById('settingsModal');
    document.getElementById('openSettings').addEventListener('click', () => settingsModal.style.display = 'flex');
    document.getElementById('closeSettings').addEventListener('click', () => settingsModal.style.display = 'none');
    document.getElementById('saveSettings').addEventListener('click', () => {
        alert("Paramètres serveur enregistrés avec succès.");
        settingsModal.style.display = 'none';
    });

    // Simulation de génération d'image
    document.getElementById('btnGenerateImage').addEventListener('click', () => {
        const display = document.getElementById('imageDisplay');
        const style = document.getElementById('imageStyle').value;
        display.innerHTML = `<div class="placeholder"><i class="fa-solid fa-spinner fa-spin"></i><p>Rendu du style ${style} en haute définition...</p></div>`;
        setTimeout(() => {
            display.innerHTML = `<div style="padding:20px; text-align:center;"><i class="fa-solid fa-circle-check" style="font-size:48px; color:#00d2ff;"></i><p style="margin-top:10px;">Image haute qualité générée avec succès ! (Style: ${style})</p></div>`;
        }, 2000);
    });

    // Simulation pipeline de film
    document.getElementById('btnStartMoviePipeline').addEventListener('click', () => {
        const status = document.getElementById('movieStatusText');
        const bar = document.getElementById('movieProgressBar');
        const display = document.getElementById('movieDisplay');

        let progress = 0;
        status.textContent = "Étape 1/6 : Analyse sémantique et découpage des scènes...";
        const interval = setInterval(() => {
            progress += 20;
            bar.style.width = `${progress}%`;
            if (progress === 40) status.textContent = "Étape 3/6 : Génération des visuels (Anime/Manhwa Premium)...";
            if (progress === 80) status.textContent = "Étape 5/6 : Synthèse des voix et de la musique d'ambiance...";
            if (progress >= 100) {
                clearInterval(interval);
                status.textContent = "Production terminée ! Film MP4 disponible.";
                display.innerHTML = `<div style="padding:20px; text-align:center;"><i class="fa-solid fa-circle-play" style="font-size:60px; color:#00d2ff;"></i><p style="margin-top:10px;">Votre film MP4 est prêt à être lu et exporté !</p></div>`;
            }
        }, 1200);
    });
});