/**
 * BD BLOOD DONATION - Application Core Controller & Client Router
 * Pure Vanilla JavaScript ES6 Modular Architecture
 * Developer: Ibna Mahmud Robin
 */

import { onAuthChanged, getCurrentUser, getCurrentUserProfile } from './auth.js';
import { onUnreadCountChanged } from './notifications.js';
import { getLanguage, setLanguage, t } from './utils.js';

// Views
import { renderHomePage } from './home.js';
import { renderDonorSearchPage } from './donor-search.js';
import { renderBloodRequestPage } from './blood-request.js';
import { renderMyRequestsPage } from './my-requests.js';
import { renderNotificationsPage } from './notifications.js';
import { renderChatPage } from './chat.js';
import { renderDonationHistoryPage } from './donation-history.js';
import { renderProfilePage, renderEditProfilePage } from './profile.js';
import { renderLoginPage, renderRegisterPage, renderForgotPasswordPage } from './auth-views.js';
import { renderAboutPage } from './about.js';

// DOM Containers
const headerEl = document.getElementById('app-header');
const contentEl = document.getElementById('app-content');
const bottomNavEl = document.getElementById('bottom-nav');

let currentActiveRoute = '';
let currentUnreadCount = 0;
let isDarkMode = localStorage.getItem('bd_blood_theme') === 'dark';

if (isDarkMode) {
  document.body.classList.remove('theme-light');
  document.body.classList.add('theme-dark');
}

/**
 * Render Top Application Header
 */
function renderHeader() {
  if (!headerEl) return;
  const isBn = getLanguage() === 'bn';

  headerEl.innerHTML = `
    <div class="header-left">
      <a href="#/home" class="header-brand">
        <div class="header-logo-icon">🩸</div>
        <div class="header-title-box">
          <span class="header-title">BD BLOOD DONATION</span>
          <span class="header-subtitle">${isBn ? 'রক্তের প্রয়োজনে, পাশে আছি আমরা' : 'Standing together for humanity'}</span>
        </div>
      </a>
    </div>

    <div class="header-actions">
      <!-- Language Switcher -->
      <button id="btn-toggle-lang" class="header-icon-btn" title="${isBn ? 'English-এ পরিবর্তন করুন' : 'বাংলা ভাষায় পরিবর্তন করুন'}">
        <span style="font-weight: 700; font-size: 11px;">${isBn ? 'EN' : 'বাং'}</span>
      </button>

      <!-- Dark Mode Switcher -->
      <button id="btn-toggle-theme" class="header-icon-btn" title="Toggle Theme">
        <span style="font-size: 15px;">${isDarkMode ? '☀️' : '🌙'}</span>
      </button>

      <!-- Notifications Shortcut -->
      <a href="#/notifications" class="header-icon-btn" title="${t('notifications')}">
        <span style="font-size: 16px;">🔔</span>
        ${currentUnreadCount > 0 ? `<span class="badge-counter">${currentUnreadCount}</span>` : ''}
      </a>
    </div>
  `;

  // Attach language toggle
  document.getElementById('btn-toggle-lang').addEventListener('click', () => {
    const nextLang = getLanguage() === 'bn' ? 'en' : 'bn';
    setLanguage(nextLang);
    renderHeader();
    renderBottomNav();
    route();
  });

  // Attach theme toggle
  document.getElementById('btn-toggle-theme').addEventListener('click', () => {
    isDarkMode = !isDarkMode;
    localStorage.setItem('bd_blood_theme', isDarkMode ? 'dark' : 'light');
    if (isDarkMode) {
      document.body.classList.remove('theme-light');
      document.body.classList.add('theme-dark');
    } else {
      document.body.classList.remove('theme-dark');
      document.body.classList.add('theme-light');
    }
    renderHeader();
  });
}

/**
 * Render Fixed Mobile Bottom Navigation Bar (5 tabs)
 */
function renderBottomNav() {
  if (!bottomNavEl) return;
  const isBn = getLanguage() === 'bn';

  bottomNavEl.innerHTML = `
    <a href="#/home" class="nav-item ${currentActiveRoute === '#/home' ? 'active' : ''}">
      <span class="nav-icon">🏠</span>
      <span>${isBn ? 'হোম' : 'Home'}</span>
    </a>
    <a href="#/donor-search" class="nav-item ${currentActiveRoute.startsWith('#/donor-search') ? 'active' : ''}">
      <span class="nav-icon">🔍</span>
      <span>${isBn ? 'রক্তদাতা' : 'Donors'}</span>
    </a>
    <a href="#/blood-request" class="nav-item ${currentActiveRoute.startsWith('#/blood-request') || currentActiveRoute.startsWith('#/my-requests') ? 'active' : ''}">
      <span class="nav-icon">🩸</span>
      <span>${isBn ? 'আবেদন' : 'Requests'}</span>
    </a>
    <a href="#/notifications" class="nav-item ${currentActiveRoute.startsWith('#/notifications') ? 'active' : ''}">
      <span class="nav-icon">🔔</span>
      <span>${isBn ? 'বিজ্ঞপ্তি' : 'Alerts'}</span>
      ${currentUnreadCount > 0 ? `<span class="nav-badge">${currentUnreadCount}</span>` : ''}
    </a>
    <a href="#/profile" class="nav-item ${currentActiveRoute.startsWith('#/profile') || currentActiveRoute.startsWith('#/login') || currentActiveRoute.startsWith('#/register') ? 'active' : ''}">
      <span class="nav-icon">👤</span>
      <span>${isBn ? 'প্রোফাইল' : 'Profile'}</span>
    </a>
  `;
}

/**
 * Client-Side Router
 */
async function route() {
  const hash = window.location.hash || '#/home';
  currentActiveRoute = hash;

  // Cleanup any active subscriptions in current view
  if (contentEl._unsubscribe) {
    try {
      contentEl._unsubscribe();
      contentEl._unsubscribe = null;
    } catch (e) {}
  }

  // Parse path & params
  const [path, queryString] = hash.split('?');
  const params = {};
  if (queryString) {
    const urlParams = new URLSearchParams(queryString);
    for (const [k, v] of urlParams.entries()) {
      params[k] = v;
    }
  }

  renderBottomNav();
  window.scrollTo(0, 0);

  switch (path) {
    case '#/home':
      await renderHomePage(contentEl);
      break;
    case '#/donor-search':
      await renderDonorSearchPage(contentEl, params);
      break;
    case '#/blood-request':
      await renderBloodRequestPage(contentEl, params);
      break;
    case '#/my-requests':
      await renderMyRequestsPage(contentEl, params);
      break;
    case '#/notifications':
      await renderNotificationsPage(contentEl);
      break;
    case '#/chat':
      await renderChatPage(contentEl, params);
      break;
    case '#/donation-history':
      await renderDonationHistoryPage(contentEl);
      break;
    case '#/profile':
      await renderProfilePage(contentEl);
      break;
    case '#/edit-profile':
      await renderEditProfilePage(contentEl);
      break;
    case '#/login':
      renderLoginPage(contentEl);
      break;
    case '#/register':
      renderRegisterPage(contentEl);
      break;
    case '#/forgot-password':
      renderForgotPasswordPage(contentEl);
      break;
    case '#/about':
      renderAboutPage(contentEl);
      break;
    default:
      await renderHomePage(contentEl);
      break;
  }
}

// Global initialization
window.addEventListener('DOMContentLoaded', () => {
  renderHeader();
  renderBottomNav();
  route();

  // Listen for hash navigation
  window.addEventListener('hashchange', () => {
    route();
  });

  // Listen for unread notification count
  onUnreadCountChanged((count) => {
    currentUnreadCount = count;
    renderHeader();
    renderBottomNav();
  });

  // Listen for auth state changes
  onAuthChanged(() => {
    renderHeader();
    renderBottomNav();
  });

  // Register Service Worker for PWA
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js').catch((err) => {
      console.log('[PWA Service Worker notice]:', err.message);
    });
  }
});
