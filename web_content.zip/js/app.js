/**
 * EthioEvents Pro - Controller with Sitting Permission Management
 */
document.addEventListener('DOMContentLoaded', async () => {
    const statusText = document.getElementById('db-status-text');
    try {
        await dbEngine.init();
        if (statusText) {
            statusText.innerText = "IndexedDB Ready. Database connected with zero internet reliance.";
            statusText.style.color = "var(--gold-primary)";
        }
        await loadGuestList();
    } catch (error) {
        if (statusText) {
            statusText.innerText = "Error initializing local database.";
            statusText.style.color = "#ff4d4d";
        }
    }

    // Navigation Logic
    const navButtons = document.querySelectorAll('.nav-btn');
    const views = document.querySelectorAll('.content-view');
    const pageTitle = document.getElementById('page-title');

    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            const target = button.getAttribute('data-target');

            navButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            views.forEach(view => {
                if (view.id === `${target}-view`) {
                    view.classList.add('active');
                } else {
                    view.classList.remove('active');
                }
            });

            if (pageTitle) {
                pageTitle.innerText = button.innerText.trim();
            }

            const sidebar = document.getElementById('sidebar');
            if (sidebar) sidebar.classList.remove('open');
        });
    });

    // Mobile Sidebar Toggle
    const mobileToggle = document.getElementById('mobile-menu-toggle');
    const sidebar = document.getElementById('sidebar');
    if (mobileToggle && sidebar) {
        mobileToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }

    // Theme Switcher
    const themeBtn = document.getElementById('theme-toggle-btn');
    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', newTheme);
            themeBtn.innerHTML = newTheme === 'dark' 
                ? '<i class="fa-solid fa-moon"></i> Light Mode' 
                : '<i class="fa-solid fa-sun"></i> Dark Mode';
        });
    }

    // --- SEATING PERMISSION & GUEST MANAGEMENT CONTROLLER ---
    const guestModal = document.getElementById('guest-modal');
    const addGuestBtn = document.getElementById('add-guest-btn');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const cancelModalBtn = document.getElementById('cancel-modal-btn');
    const guestForm = document.getElementById('guest-form');
    const searchInput = document.getElementById('guest-search-input');
    const filterSelect = document.getElementById('seating-perm-filter');

    let allGuests = [];

    async function loadGuestList() {
        allGuests = await dbEngine.getAll('guests');
        
        // Populate default demo data if empty
        if (allGuests.length === 0) {
            const demoGuests = [
                { name: "Ato Dawit Tadesse", category: "VIP", rsvp: "Confirmed", table: "Table A (VIP Front)", seatingPermission: "VIP Reserved", notes: "Head Table Guest" },
                { name: "W/ro Bethlehem Alemu", category: "Family", rsvp: "Confirmed", table: "Table B-2", seatingPermission: "Standard Granted", notes: "Near Stage" },
                { name: "Yonas Gebre", category: "Friend", rsvp: "Pending", table: "Unassigned", seatingPermission: "Pending Approval", notes: "" },
                { name: "Tewodros Girma", category: "Corporate", rsvp: "Confirmed", table: "Standing Area", seatingPermission: "Restricted", notes: "Media access only" }
            ];
            for (const item of demoGuests) {
                await dbEngine.add('guests', item);
            }
            allGuests = await dbEngine.getAll('guests');
        }
        renderGuestsTable();
        updateSeatingMetrics();
    }

    function renderGuestsTable() {
        const tbody = document.getElementById('guest-table-body');
        if (!tbody) return;

        const query = searchInput ? searchInput.value.toLowerCase() : '';
        const filterPerm = filterSelect ? filterSelect.value : 'all';

        const filtered = allGuests.filter(g => {
            const matchesSearch = g.name.toLowerCase().includes(query) || (g.table && g.table.toLowerCase().includes(query));
            const matchesPerm = filterPerm === 'all' || g.seatingPermission === filterPerm;
            return matchesSearch && matchesPerm;
        });

        tbody.innerHTML = filtered.map(g => {
            let badgeClass = 'badge-pending';
            if (g.seatingPermission === 'VIP Reserved') badgeClass = 'badge-vip';
            else if (g.seatingPermission === 'Standard Granted') badgeClass = 'badge-granted';
            else if (g.seatingPermission === 'Restricted') badgeClass = 'badge-restricted';

            return `
                <tr>
                    <td><strong>${escapeHtml(g.name)}</strong></td>
                    <td>${escapeHtml(g.category)}</td>
                    <td>${escapeHtml(g.rsvp)}</td>
                    <td>${escapeHtml(g.table || 'Unassigned')}</td>
                    <td><span class="badge ${badgeClass}">${escapeHtml(g.seatingPermission)}</span></td>
                    <td>
                        <button class="action-btn edit-btn" onclick="openEditGuestModal(${g.id})"><i class="fa-solid fa-pen-to-square"></i></button>
                        <button class="action-btn delete action-btn-del" onclick="deleteGuestItem(${g.id})"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    function updateSeatingMetrics() {
        const seatingStat = document.getElementById('stat-seating-granted');
        if (!seatingStat) return;
        
        const total = allGuests.length;
        const granted = allGuests.filter(g => g.seatingPermission === 'VIP Reserved' || g.seatingPermission === 'Standard Granted').length;
        seatingStat.innerText = `${granted} / ${total}`;
    }

    function openModal(isEdit = false) {
        document.getElementById('modal-title').innerText = isEdit ? 'Edit Guest & Seating Permission' : 'Add Guest & Seating Permission';
        guestModal.classList.add('open');
    }

    function closeModal() {
        guestModal.classList.remove('open');
        guestForm.reset();
        document.getElementById('guest-id').value = '';
    }

    if (addGuestBtn) addGuestBtn.addEventListener('click', () => openModal(false));
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
    if (cancelModalBtn) cancelModalBtn.addEventListener('click', closeModal);

    if (guestForm) {
        guestForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const id = document.getElementById('guest-id').value;
            const guestData = {
                name: document.getElementById('guest-name').value.trim(),
                category: document.getElementById('guest-category').value,
                rsvp: document.getElementById('rsvp-status').value,
                table: document.getElementById('assigned-table').value.trim(),
                seatingPermission: document.getElementById('seating-permission').value,
                notes: document.getElementById('seating-notes').value.trim()
            };

            if (id) {
                guestData.id = parseInt(id);
                await dbEngine.update('guests', guestData);
            } else {
                await dbEngine.add('guests', guestData);
            }

            closeModal();
            await loadGuestList();
        });
    }

    if (searchInput) searchInput.addEventListener('input', renderGuestsTable);
    if (filterSelect) filterSelect.addEventListener('change', renderGuestsTable);

    // Global Handlers for Edit/Delete
    window.openEditGuestModal = (id) => {
        const guest = allGuests.find(g => g.id === id);
        if (!guest) return;
        document.getElementById('guest-id').value = guest.id;
        document.getElementById('guest-name').value = guest.name;
        document.getElementById('guest-category').value = guest.category;
        document.getElementById('rsvp-status').value = guest.rsvp;
        document.getElementById('assigned-table').value = guest.table || '';
        document.getElementById('seating-permission').value = guest.seatingPermission;
        document.getElementById('seating-notes').value = guest.notes || '';
        openModal(true);
    };

    window.deleteGuestItem = async (id) => {
        if (confirm("Are you sure you want to delete this guest seating permission record?")) {
            await dbEngine.delete('guests', id);
            await loadGuestList();
        }
    };

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>"']/g, (m) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
        })[m]);
    }
});