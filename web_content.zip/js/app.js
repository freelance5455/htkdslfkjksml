import { preload as preloadGrades, GradeManager } from "./engines/gradeManager.js";
import { UnifiedQuestionEngine } from "./engines/unifiedEngine.js";
import * as db from "./db.js";
import { applyTheme } from "./theme.js";
import { el, bottomNav, showAlert, showPrompt } from "./ui/widgets.js";

import { Login } from "./screens/login.js";
import { Home } from "./screens/home.js";
import { Learn, TopicDetail, TopicDetailLite } from "./screens/learn.js";
import { PracticeSetup, PracticeSession } from "./screens/practice.js";
import { Papers, PaperViewer } from "./screens/papers.js";
import { Profile } from "./screens/profile.js";
import { Settings } from "./screens/settings.js";
import { Labs, GeometryLab, DataLab, ProbabilityLab, Mental, SolidsLab } from "./screens/labs.js";
import { TheoremLab, TheoremRound } from "./screens/theoremLab.js";
import { WorkshopSession } from "./screens/workshopSession.js";
import { syncFromSettings, startMusic, playSfx } from "./engines/audioEngine.js";
import { Parent } from "./screens/parent.js";
import { TeachHub, TeachDeck } from "./screens/teach.js";
import { StructuredPractice, StructuredHub } from "./screens/structured.js";
import { ChallengesHub, ChallengeSetup, ChallengeRun } from "./screens/challenges.js";
import { MathsLessonsHub, MathsLesson } from "./screens/lessons.js";
import { Achievements, Economy, DevMode, Rewards } from "./screens/gamification.js";
import { Science, ScienceTopic, Quiz, TipsTricks } from "./screens/science.js";
import { PsQuizSession } from "./screens/psQuiz.js";

export const ACCESS_CODE = "children of the sun";
export const LOCKED_GRADE = 5;
export const SUPPORTED_GRADES = [5, 11];

const SCREENS = {
  login: Login, home: Home, learn: Learn, topicDetail: TopicDetail, topicDetailLite: TopicDetailLite,
  practiceSetup: PracticeSetup, practiceSession: PracticeSession, papers: Papers, paperViewer: PaperViewer,
  profile: Profile, settings: Settings, labs: Labs, theoremLab: TheoremLab, theoremRound: TheoremRound, workshopSession: WorkshopSession, geometryLab: GeometryLab, dataLab: DataLab,
  probabilityLab: ProbabilityLab, mental: Mental, solidsLab: SolidsLab, parent: Parent, teachHub: TeachHub, teachDeck: TeachDeck, structuredPractice: StructuredPractice, structuredHub: StructuredHub,
  challengesHub: ChallengesHub, challengeSetup: ChallengeSetup, challengeRun: ChallengeRun,
  mathsLessonsHub: MathsLessonsHub, mathsLesson: MathsLesson,
  achievements: Achievements, economy: Economy, rewards: Rewards, devMode: DevMode,
  science: Science, scienceTopic: ScienceTopic, quiz: Quiz, tipsTricks: TipsTricks,
  psQuizSession: PsQuizSession
};

export const app = {
  student: null,
  history: [],
  _current: null,

  gradeManager() { return new GradeManager(this.student?.grade ?? LOCKED_GRADE); },
  questionEngine() { return new UnifiedQuestionEngine(this.student?.grade ?? LOCKED_GRADE); },

  saveStudent() { if (this.student) db.writeStudentRaw(this.student); },
  loadStudentByCode(code) { return db.readStudentRaw(code); },
  saveStudentByCode(student) { db.writeStudentRaw(student); },

  applyThemeAndFont() {
    const s = this.student?.settings || {};
    applyTheme(s.theme || "Candy", s.font_scale || "Normal");
  },
  syncAudioFromSettings() {
    const s = this.student?.settings || {};
    try { syncFromSettings(s); } catch (e) { /* audio optional */ }
  },

  async navigate(name, params = {}) {
    if (this._current) this.history.push(this._current);
    await this._render(name, params);
  },
  async replace(name, params = {}) { await this._render(name, params); },
  async resetTo(name, params = {}) { this.history = []; await this._render(name, params); },
  async goBack() {
    const prev = this.history.pop();
    if (prev) await this._render(prev.name, prev.params);
    else await this._render("home", {});
  },
  async refreshCurrentScreen() {
    if (this._current) await this._render(this._current.name, this._current.params, true);
  },

  async _render(name, params, isRefresh = false) {
    const fn = SCREENS[name];
    if (!fn) { console.error("Unknown screen:", name); return; }
    if (this._cleanup) { try { this._cleanup(); } catch { /* ignore */ } this._cleanup = null; }
    if (this.student && name !== "login") this.saveStudent();
    const root = document.getElementById("app");
    root.innerHTML = "";
    root.className = "";
    let def;
    try {
      def = await fn(this, params);
    } catch (err) {
      console.error(err);
      def = {
        title: "Oops",
        showBack: true,
        body: [el("div", { class: "card" }, [
          el("div", { class: "role-heading" }, "Something went wrong"),
          el("div", { class: "role-subtitle wrap" }, String(err && err.message || err))
        ])]
      };
    }
    if (!isRefresh) this._current = { name, params };
    this._cleanup = def.onUnmount || null;
    this._mount(def);
  },

  _mount(def) {
    const root = document.getElementById("app");
    const showBack = def.showBack === false ? false : true;
    const top = !showBack
      ? el("div", { class: "screen-top" }, [el("div", { class: "screen-title" }, def.title)])
      : el("div", { class: "screen-top" }, [
          el("button", { class: "btn-secondary btn-sm", style: "width:2.6rem;flex:none;", onClick: () => this.goBack() }, "←"),
          el("div", { class: "screen-title" }, def.title)
        ]);
    const screen = el("div", { class: "screen" }, [top, el("div", { class: "screen-body" }, def.body || [])]);
    if (def.bottomNavKey) root.className = "has-bottomnav";
    root.appendChild(screen);
    if (def.bottomNavKey) root.appendChild(bottomNav(this, def.bottomNavKey));
    window.scrollTo(0, 0);
  },

  showHome() { return this.resetTo("home"); },
  showLearn() {
    if (this.student?.subject === "physical_sciences") return this.navigate("science");
    return this.navigate("learn");
  },
  showTopicDetail(topicId) {
    // Grade 5 uses lite notes enriched with guides; grade 8 still has deep notes if switched in data
    const g = this.student?.grade ?? LOCKED_GRADE;
    return this.navigate(g === 8 ? "topicDetail" : "topicDetailLite", { topicId });
  },
  showTopicPicker() { return this.navigate("practiceSetup", { mode: "choose" }); },
  showPractice(mode, topics) {
    if (this.student?.subject === "physical_sciences" && !(topics && topics.length && String(topics[0]).startsWith("ps_"))) {
      return this.navigate("science");
    }
    return this.navigate("practiceSetup", { mode, topics });
  },
  launchPracticeSession(opts) { return this.navigate("practiceSession", opts); },
  showPapers() {
    return this.navigate("papers", { view: "hub" });
  },
  showPaperViewer(paperId, opts = {}) { return this.navigate("paperViewer", { paperId, ...opts }); },
  showProfile() { return this.navigate("profile"); },
  showSettings() { return this.navigate("settings"); },
  showLabs() { return this.navigate("labs"); },
  showGeometryLab() { return this.navigate("geometryLab"); },
  showDataLab() { return this.navigate("dataLab"); },
  showProbabilityLab() { return this.navigate("probabilityLab"); },
  showMental() { return this.navigate("mental"); },
  showScience() { return this.navigate("science"); },
  showScienceTopic(topicId) { return this.navigate("scienceTopic", { topicId }); },
  showQuiz(subject = "math", topicId = null) { return this.navigate("quiz", { subject, topicId }); },
  showTipsTricks() { return this.navigate("tipsTricks"); },
  showAchievements() { return this.navigate("achievements"); },
  showEconomy() { return this.navigate("economy"); },
  showRewards() { return this.navigate("rewards"); },
  showParent() { return this.navigate("parent"); },
  showTeach() { return this.navigate("teachHub"); },
  showStructured() { return this.navigate("structuredHub"); },
  showChallenges() { return this.navigate("challengesHub"); },
  showMathsLessons() { return this.navigate("mathsLessonsHub"); },
  showSolidsLab() { return this.navigate("solidsLab"); },

  async showDevModeGate() {
    const code = await showPrompt("Dev Mode", "Access code:", "", true);
    if (code === null) return;
    if (code.trim().toLowerCase() === ACCESS_CODE) this.navigate("devMode");
    else showAlert("Access denied", "Incorrect code.");
  },

  // -------- auth (Grade 5 lock) --------
  async login(code, grade = LOCKED_GRADE, name = null) {
    const g = SUPPORTED_GRADES.includes(parseInt(grade, 10)) ? parseInt(grade, 10) : LOCKED_GRADE;
    this.student = db.login(code, g, name);
    try {
      const { EconomyEngine } = await import("./engines/economyEngine.js");
      const granted = new EconomyEngine(this.student).grantStarterStars(2000);
      if (granted) this.saveStudent();
    } catch { /* ignore */ }
    // Keep grade within supported set (Grade 5 default; Grade 11 maths available)
    if (!SUPPORTED_GRADES.includes(this.student.grade)) {
      db.changeGrade(this.student, LOCKED_GRADE);
      this.student.grade = LOCKED_GRADE;
    }
    this.applyThemeAndFont();
    this.syncAudioFromSettings();
    await this.resetTo("home");
  },
  async logout() {
    this.saveStudent();
    this.student = null;
    this.history = [];
    await this.resetTo("login");
  },
  async changeGrade(newGrade) {
    const g = parseInt(newGrade, 10);
    if (!SUPPORTED_GRADES.includes(g)) {
      showAlert("Grade", `This build supports Grade ${SUPPORTED_GRADES.join(" and ")}.`);
      return;
    }
    if (!this.student) return;
    db.changeGrade(this.student, g);
    this.student.grade = g;
    this.saveStudent();
    showAlert("Grade updated", `Now learning as Grade ${g}.`);
    await this.showHome();
  }
};

export async function boot() {
  try {
    await preloadGrades();
  } catch (err) {
    document.getElementById("app").innerHTML =
      `<div class="screen"><div class="card"><div class="role-heading">Could not load Learnly</div><div class="role-subtitle wrap">${String(err.message || err)}</div></div></div>`;
    return;
  }
  applyTheme("Candy", "Normal");
  await app.resetTo("login");
}
