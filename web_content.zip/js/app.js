import { BattleGame } from "./game.js";
import { ApiError, api } from "./api.js";
import { RealtimeArena } from "./realtime.js";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

const views = {
  home: $("#home-view"),
  game: $("#game-view"),
  social: $("#social-view"),
};
const modalBackdrop = $("#modal-backdrop");
const modalContent = $("#modal-content");
const databaseWarning = $("#database-warning");
const canvas = $("#battle-canvas");
const arenaToast = $("#arena-toast");
const gameOverlay = $("#game-overlay");
const overlayActions = $("#overlay-actions");
const battleBottom = $(".arena-bottom");
const campaignBottomHTML = battleBottom.innerHTML;

let currentUser = null;
let accountProfile = null;
let progress = { level: 1, bestLevel: 1, coins: 280, wins: 0 };
let game = new BattleGame(canvas, {
  onHud: renderHud,
  onFps: (fps) => { $("#fps-meter").textContent = `${fps} FPS`; },
  onClock: (clock) => { $("#battle-clock").textContent = clock; },
  onToast: toast,
  onSound: playEffect,
  onPause: renderPause,
  onEnd: handleGameEnd,
});
let online = null;
let activeRoom = null;
let roomInfo = null;
let roomPlayers = [];
let ambient = null;
let toastTimer = 0;
let campaignResultSaved = false;
let currentCampaignLevel = 1;
let selectedRoomMode = "duel";
let settings = loadSettings();
let uploadedAvatarUrl = null;

function loadSettings() {
  try {
    return { sound: true, fps: true, contrast: false, ...JSON.parse(localStorage.getItem("desert-arena-settings") ?? "{}") };
  } catch {
    return { sound: true, fps: true, contrast: false };
  }
}

function saveSettings() {
  localStorage.setItem("desert-arena-settings", JSON.stringify(settings));
  document.body.classList.toggle("high-contrast", settings.contrast);
  $("#fps-meter").hidden = !settings.fps;
  if (!settings.sound && ambient) ambient.pause();
  else if (settings.sound && ambient && game.running) ambient.play().catch(() => {});
  else if (settings.sound && game.running) startAmbient();
}

function localProgress() {
  try {
    const saved = JSON.parse(localStorage.getItem("desert-arena-progress") ?? "null");
    if (saved && Number(saved.level) >= 1) {
      return {
        level: clamp(Math.floor(saved.level), 1, 12),
        bestLevel: clamp(Math.floor(saved.bestLevel ?? saved.level), 1, 12),
        coins: clamp(Math.floor(saved.coins ?? 280), 0, 999999),
        wins: Math.max(0, Math.floor(saved.wins ?? 0)),
      };
    }
  } catch {}
  return { level: 1, bestLevel: 1, coins: 280, wins: 0 };
}

function persistLocalProgress() {
  localStorage.setItem("desert-arena-progress", JSON.stringify(progress));
  $("#save-state").textContent = currentUser ? "BULUT KAYDI" : "YEREL KAYIT";
  renderProgress();
}

async function persistProgress() {
  persistLocalProgress();
  if (!currentUser || !accountProfile) return;
  try {
    await api.saveProgress(progress);
    $("#save-state").textContent = "BULUT KAYDI ✓";
  } catch (error) {
    if (error.code === "unavailable") databaseUnavailable(error.message);
    else console.warn("İlerleme buluta kaydedilemedi:", error);
  }
}

function renderProgress() {
  const level = clamp(progress.level, 1, 12);
  $("#home-level").textContent = `SEVİYE ${String(level).padStart(2, "0")}`;
  $("#best-level").innerHTML = `${String(progress.bestLevel).padStart(2, "0")} <small>/ 12</small>`;
  $("#home-progress").style.width = `${Math.min(100, (progress.bestLevel / 12) * 100)}%`;
  const labels = ["İLK ADIMLAR", "KILIÇ SESLERİ", "KUM FIRTINASI", "KIZIL YARIK", "ÇÖL AVCISI", "KIRIK MIZRAK", "KANLI GÜNBATIMI", "KUM KRALLIĞI", "SON KALE", "FIRTINA GÖZÜ", "SAVAŞ LORDU", "SON MUHAREBE"];
  $("#home-progress-label").textContent = labels[level - 1];
}

function showView(name) {
  Object.entries(views).forEach(([key, element]) => element.classList.toggle("active", key === name));
}

function openModal(templateId) {
  const template = document.getElementById(templateId);
  if (!template) return;
  modalContent.replaceChildren(template.content.cloneNode(true));
  modalBackdrop.hidden = false;
  if (templateId === "settings-template") syncSettingsModal();
  if (templateId === "profile-template") setupProfileModal();
  if (templateId === "multiplayer-template") setupMultiplayerModal();
}

function closeModal({ keepRoom = false } = {}) {
  modalBackdrop.hidden = true;
  if (!keepRoom && activeRoom && !game.running) {
    activeRoom.close();
    activeRoom = null;
    roomInfo = null;
    roomPlayers = [];
  }
}

function toast(message) {
  arenaToast.textContent = message;
  arenaToast.classList.add("show");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => arenaToast.classList.remove("show"), 2200);
}

function playEffect(name) {
  if (!settings.sound) return;
  const paths = {
    sword: "./sfx/sword-swing.wav",
    hit: "./sfx/armor-hit.wav",
    coin: "./sfx/coins.wav",
  };
  if (!paths[name]) return;
  const audio = new Audio(paths[name]);
  audio.volume = name === "coin" ? .28 : .2;
  audio.play().catch(() => {});
}

function startAmbient() {
  if (!settings.sound || ambient) return;
  ambient = new Audio("./sfx/desert-wind.wav");
  ambient.loop = true;
  ambient.volume = .12;
  ambient.play().catch(() => { ambient = null; });
}

function renderHud(state) {
  if (state.mode === "online") {
    $("#blue-hp").style.width = `${state.blue}%`;
    $("#red-hp").style.width = `${state.red}%`;
    $("#blue-hp-label").textContent = `${state.blue}%`;
    $("#red-hp-label").textContent = `${state.red}%`;
    const selfHealth = $("#online-self-hp");
    if (selfHealth) selfHealth.textContent = `${state.selfHp}%`;
    return;
  }
  $("#gold-count").textContent = state.gold;
  $("#blue-hp").style.width = `${state.blue}%`;
  $("#red-hp").style.width = `${state.red}%`;
  $("#blue-hp-label").textContent = `${state.blue}%`;
  $("#red-hp-label").textContent = `${state.red}%`;
  $("#arena-level").textContent = `BÖLÜM ${String(state.level).padStart(2, "0")}`;
  $("#arena-wave").textContent = `DALGA ${Math.min(state.wave, state.maxWaves)} / ${state.maxWaves}`;
  $("#battle-mode").textContent = `SEFER · SEVİYE ${String(state.level).padStart(2, "0")}`;
}

function renderPause(paused) {
  if (!paused) {
    gameOverlay.hidden = true;
    return;
  }
  showOverlay("SEFER", "Savaş duraklatıldı", "Ordun seni bekliyor.", [
    ["SAVAŞA DÖN", () => game.pause(), "primary"],
    ["ANA MENÜ", leaveCampaign, "outline"],
  ]);
}

function renderCampaignEnd(result) {
  if (result === "win") {
    const completed = currentCampaignLevel;
    if (!campaignResultSaved) {
      campaignResultSaved = true;
      progress.wins++;
      progress.coins = game.gold + 50 + completed * 8;
      progress.bestLevel = Math.max(progress.bestLevel, completed);
      progress.level = Math.min(12, completed + 1);
      persistProgress();
    }
    const last = completed >= 12;
    showOverlay(last ? "SEFER TAMAMLANDI" : `BÖLÜM ${String(completed).padStart(2, "0")} TAMAMLANDI`, last ? "Çöl efsanesi oldun." : "Kale düştü. Bir sonraki cephe seni bekliyor.", `+${50 + completed * 8} altın · İlerlemen kaydedildi.`, [
      [last ? "TEKRAR OYNA" : "SONRAKİ BÖLÜM", () => startCampaign(last ? 1 : completed + 1), "primary"],
      ["ANA MENÜ", leaveCampaign, "outline"],
    ]);
  } else {
    showOverlay("KALE DÜŞTÜ", "Birliklerin geri çekildi.", "Dizilişini değiştirip tekrar dene.", [
      ["TEKRAR DENE", () => startCampaign(currentCampaignLevel), "primary"],
      ["ANA MENÜ", leaveCampaign, "outline"],
    ]);
  }
}

function showOverlay(kicker, title, description, actions) {
  $("#overlay-kicker").textContent = kicker;
  $("#overlay-title").textContent = title;
  $("#overlay-description").textContent = description;
  overlayActions.replaceChildren(...actions.map(([label, action, kind]) => {
    const button = document.createElement("button");
    button.className = `button ${kind === "primary" ? "button-primary" : "button-outline"}`;
    button.textContent = label;
    button.addEventListener("click", action, { once: true });
    return button;
  }));
  gameOverlay.hidden = false;
}

function startCampaign(level = progress.level) {
  if (activeRoom) {
    activeRoom.close();
    activeRoom = null;
  }
  currentCampaignLevel = clamp(level, 1, 12);
  progress.level = currentCampaignLevel;
  campaignResultSaved = false;
  battleBottom.innerHTML = campaignBottomHTML;
  $("#game-view [data-action=leave-game]").dataset.action = "leave-game";
  $(".pause-button").hidden = false;
  $("#online-top-actions").hidden = true;
  $("#online-chat-panel").hidden = true;
  showView("game");
  gameOverlay.hidden = true;
  $("#battle-heading").textContent = ["KIZIL KUM DENİZİ", "KURU NEHİR", "KIZIL YARIK"][((level - 1) % 3)];
  game.startCampaign(currentCampaignLevel, progress.coins);
  startAmbient();
  if (currentUser && accountProfile) persistProgress();
}

function leaveCampaign() {
  game.dispose();
  ambient?.pause();
  gameOverlay.hidden = true;
  showView("home");
}

function leaveOnline() {
  game.dispose();
  ambient?.pause();
  gameOverlay.hidden = true;
  activeRoom?.close();
  activeRoom = null;
  roomInfo = null;
  roomPlayers = [];
  battleBottom.innerHTML = campaignBottomHTML;
  $("#game-view [data-action=leave-game]").dataset.action = "leave-game";
  $(".pause-button").hidden = false;
  $("#online-top-actions").hidden = true;
  $("#online-chat-panel").hidden = true;
  showView("home");
  closeModal({ keepRoom: true });
}

function databaseUnavailable(reason = "") {
  const suffix = reason && reason.length < 180 ? ` ${reason}` : "";
  databaseWarning.textContent = `VERİ TABANI BAĞLANTISI KURULAMADI.${suffix} Sunucu tarafındaki veri tabanı hazır olduğunda oda kodları, profil ve bulut kayıtları etkinleşir.`;
  databaseWarning.hidden = false;
}

function requireAccount(feature) {
  if (!currentUser) {
    toast(`${feature} için Websim hesabınla giriş yap.`);
    openModal("database-template");
    return false;
  }
  if (!accountProfile) {
    toast("Önce savaşçı profilini oluştur.");
    openModal("profile-template");
    return false;
  }
  return true;
}

function syncSettingsModal() {
  $$("[data-setting]", modalContent).forEach((button) => {
    button.classList.toggle("on", Boolean(settings[button.dataset.setting]));
  });
}

function setupProfileModal() {
  const input = $("#profile-name-input", modalContent);
  if (accountProfile?.username) input.value = accountProfile.username;
  $("#account-notice", modalContent).textContent = currentUser
    ? `Hesabın @${currentUser.username} olarak bağlı. Kullanıcı adları benzersizdir.`
    : "Çevrim içi profil için Websim hesabınla giriş yap. Misafir olarak seferi cihazında kaydedebilirsin.";
  if (accountProfile?.avatar_url) {
    uploadedAvatarUrl = accountProfile.avatar_url;
    $("#profile-image-preview", modalContent).src = uploadedAvatarUrl;
    $("#profile-image-preview", modalContent).hidden = false;
  }
}

function setupMultiplayerModal() {
  selectedRoomMode = "duel";
  if (!currentUser) {
    const note = document.createElement("div");
    note.className = "account-notice";
    note.textContent = "Oda kodları ve arkadaş davetleri Websim hesabına kaydedilir. Sefer modunu misafir olarak oynayabilirsin.";
    modalContent.append(note);
  }
}

async function requireOnline() {
  if (!requireAccount("Çok oyunculu savaş")) return false;
  return true;
}

async function createRoom() {
  if (!await requireOnline()) return;
  try {
    const created = await api.createRoom(selectedRoomMode);
    await enterRoom(created.code);
  } catch (error) {
    handleApiError(error);
  }
}

async function enterRoom(code) {
  if (!await requireOnline()) return;
  closeModal({ keepRoom: true });
  if (activeRoom) activeRoom.close();
  roomPlayers = [];
  activeRoom = new RealtimeArena({ onEvent: onRoomEvent });
  try {
    roomInfo = await api.joinRoom(code);
    const joined = await activeRoom.connect(roomInfo.code);
    roomInfo = { ...roomInfo, ...joined };
    roomPlayers = joined.players ?? [];
    openRoomModal();
  } catch (error) {
    activeRoom?.close();
    activeRoom = null;
    roomInfo = null;
    toast(error.message || "Odaya bağlanılamadı.");
    if (error.code === "unavailable") databaseUnavailable(error.message);
    else if (error.code === "PROFILE_REQUIRED") openModal("profile-template");
    else openMultiplayerModal();
  }
}

function openMultiplayerModal() {
  openModal("multiplayer-template");
}

function openRoomModal() {
  openModal("room-template");
  $("#room-code-text", modalContent).textContent = roomInfo?.code ?? "------";
  $("#room-status", modalContent).textContent = `LOBBY · ${roomInfo?.mode === "trio" ? "2'YE 1" : "1'E 1"}`;
  renderLobby();
}

function renderLobby() {
  if (!$("#lobby-blue", modalContent)) return;
  const blue = roomPlayers.filter((player) => player.team === "blue");
  const red = roomPlayers.filter((player) => player.team === "red");
  const makePlayer = (player) => {
    const row = document.createElement("div");
    row.className = "lobby-player";
    if (player.avatarUrl) {
      const image = document.createElement("img");
      image.src = player.avatarUrl;
      image.alt = "";
      row.append(image);
    } else {
      const chip = document.createElement("span");
      chip.className = `team-chip ${player.team === "blue" ? "blue-chip" : "red-chip"}`;
      row.append(chip);
    }
    const name = document.createElement("span");
    name.textContent = player.username + (player.userId === roomInfo?.hostId ? " · KURUCU" : "");
    row.append(name);
    return row;
  };
  $("#lobby-blue", modalContent).replaceChildren(...blue.map(makePlayer));
  $("#lobby-red", modalContent).replaceChildren(...red.map(makePlayer));
  $("#start-online", modalContent).hidden = roomInfo?.hostId !== currentUser?.id;
  $("#start-online", modalContent).disabled = roomPlayers.length < 2;
  $("#lobby-note", modalContent).textContent = roomPlayers.length < 2
    ? "Savaşa başlamak için en az iki savaşçı gerekli."
    : `${roomPlayers.length}/${roomInfo?.maxPlayers ?? 2} savaşçı hazır.`;
}

function onRoomEvent(type, message) {
  if (type === "joined" || type === "lobby") {
    if (!message.ok) return toast(message.error ?? "Oda bağlantısı kesildi.");
    roomInfo = { ...roomInfo, ...message };
    roomPlayers = message.players ?? roomPlayers;
    if (!modalBackdrop.hidden) renderLobby();
    return;
  }
  if (type === "player-joined") {
    if (!roomPlayers.some((player) => player.id === message.player?.id)) roomPlayers.push(message.player);
    if (!modalBackdrop.hidden) renderLobby();
    return;
  }
  if (type === "player-left") {
    roomPlayers = roomPlayers.filter((player) => player.id !== message.id);
    if (!modalBackdrop.hidden) renderLobby();
    return;
  }
  if (type === "chat") {
    addChat(message.from, message.text);
    return;
  }
  if (type === "snapshot") {
    const updates = new Map((message.players ?? []).map((player) => [player.id, player]));
    roomPlayers = roomPlayers.map((player) => ({ ...player, ...updates.get(player.id) }));
    if (game.mode === "online") game.setOnlineState(roomPlayers);
    return;
  }
  if (type === "combat-hit") {
    playEffect("hit");
    roomPlayers = roomPlayers.map((player) => player.id === message.target ? { ...player, hp: message.hp } : player);
    if (message.winner) game.setOnlineState(roomPlayers, { winner: message.winner });
    else game.setOnlineState(roomPlayers);
    return;
  }
  if (type === "match-ended") {
    game.setOnlineState(roomPlayers, { winner: message.winner });
    return;
  }
  if (type === "game-start") {
    roomInfo = { ...roomInfo, ...message, started: true };
    roomPlayers = message.players ?? roomPlayers;
    startOnlineGame(message);
    return;
  }
  if (type === "notice") toast(message.text);
  if (type === "disconnect") toast(message.reason);
}

function addChat(from, text) {
  for (const feed of [$("#chat-feed", modalContent), $("#online-chat-feed")]) {
    if (!feed) continue;
    const line = document.createElement("div");
    line.className = "chat-line";
    const name = document.createElement("strong");
    name.textContent = `${from}:`;
    const message = document.createElement("span");
    message.textContent = text;
    line.append(name, message);
    feed.append(line);
    feed.scrollTop = feed.scrollHeight;
  }
}

function startOnlineGame(message) {
  roomPlayers = message.players ?? roomPlayers;
  const self = roomPlayers.find((player) => player.id === activeRoom?.playerId);
  const other = roomPlayers.find((player) => player.team !== self?.team);
  closeModal({ keepRoom: true });
  showView("game");
  gameOverlay.hidden = true;
  $("#battle-heading").textContent = `ODA ${roomInfo?.code ?? message.code}`;
  $("#game-view [data-action=leave-game]").dataset.action = "leave-online";
  $(".pause-button").hidden = true;
  $("#battle-mode").textContent = roomInfo?.mode === "trio" ? "TAKIM SAVAŞI · 2'YE 1" : "DÜELLO · 1'E 1";
  $("#gold-count").textContent = "";
  $("#arena-level").textContent = "CANLI ARENA";
  $("#arena-wave").textContent = "TAKIM SAVAŞI";
  battleBottom.innerHTML = `
    <div class="resource-pill"><span>◈</span><strong id="online-self-hp">100</strong><small>CAN</small></div>
    <div class="unit-controls online-controls">
      <button class="online-control" data-online="left" type="button">◂ <small>GERİ</small></button>
      <button class="online-control online-hit" data-online="hit" type="button">⚔ <small>VUR</small></button>
      <button class="online-control" data-online="right" type="button">▸ <small>İLERİ</small></button>
    </div>
    <button class="online-exit" data-action="leave-online" type="button">ÇIKIŞ</button>`;
  $("#online-top-actions").hidden = false;
  $("#online-chat-panel").hidden = true;
  $("#game-voice-button").classList.toggle("active", Boolean(activeRoom?.voiceEnabled));
  startAmbient();
  modalBackdrop.hidden = true;
  game.startOnline({ playerId: activeRoom?.playerId, player: self, players: roomPlayers, send: (value) => activeRoom?.send(value) });
  if (!self) toast("Savaşçı bilgisi yükleniyor...");
  if (other) {
    $("#blue-hp-label").textContent = "MAVİ";
    $("#red-hp-label").textContent = "KIRMIZI";
    $("#blue-hp").style.width = "100%";
    $("#red-hp").style.width = "100%";
  }
}

function handleGameEnd(result) {
  if (game.mode === "campaign") {
    renderCampaignEnd(result);
    return;
  }
  const self = roomPlayers.find((player) => player.id === activeRoom?.playerId);
  const winner = game.winner;
  const won = winner && winner === self?.team;
  showOverlay(won ? "ARENA GALİBİ" : "SAVAŞ SONA ERDİ", won ? "Zafer senin." : "Bu seferlik olmadı.", "Oda menüsüne dönmek için devam et.", [
    ["ANA MENÜ", leaveOnline, "primary"],
  ]);
}

function setDatabaseWarning(enabled, text = "") {
  if (enabled) databaseUnavailable(text);
  else databaseWarning.hidden = true;
}

function handleApiError(error) {
  if (error instanceof ApiError && error.code === "unavailable") {
    databaseUnavailable(error.message);
    return;
  }
  if (error.status === 401) {
    toast("Bu işlem için Websim hesabıyla giriş yap.");
    return;
  }
  if (error.code === "PROFILE_REQUIRED") {
    openModal("profile-template");
    return;
  }
  toast(error.message ?? "İşlem tamamlanamadı.");
}

async function refreshFriends() {
  if (!requireAccount("Arkadaş listesi")) return;
  try {
    const [friendData, inbox] = await Promise.all([api.friends(), api.inbox()]);
    renderFriends(friendData, inbox.invites ?? []);
  } catch (error) {
    handleApiError(error);
  }
}

function renderFriends(data, invites) {
  const list = $("#friends-list");
  const incomingList = $("#invites-list");
  if (!list || !incomingList) return;
  $("#friend-count").textContent = String(data.friends.length);
  if (!data.friends.length) {
    list.innerHTML = '<div class="empty-state">Henüz arkadaşın yok. Kullanıcı adıyla ara.</div>';
  } else {
    list.replaceChildren(...data.friends.map((friend) => {
      const row = personRow(friend.username, friend.avatar_url, "ARKADAŞ", "DAVET ET", async () => {
        if (!requireAccount("Arkadaş daveti")) return;
        try {
          const room = await api.createRoom("duel");
          await api.invite(friend.username, room.code);
          toast(`@${friend.username} için arena daveti gönderildi.`);
          await enterRoom(room.code);
        } catch (error) {
          handleApiError(error);
        }
      }));
      return row;
    }));
  }
  if (!data.incoming.length && !invites.length) incomingList.innerHTML = '<div class="empty-state">Bekleyen istek veya davet yok.</div>';
  else {
    const rows = [];
    for (const request of data.incoming) {
      rows.push(personRow(request.username, request.avatar_url, "ARKADAŞLIK İSTEĞİ", "KABUL ET", async () => {
        try { await api.acceptFriend(request.requester_id); refreshFriends(); }
        catch (error) { handleApiError(error); }
      }));
    }
    for (const invite of invites) {
      rows.push(personRow(invite.username, invite.avatar_url, `ODA ${invite.room_code}`, "KATIL", () => enterRoom(invite.room_code)));
    }
    incomingList.replaceChildren(...rows);
  }
}

function personRow(username, avatarUrl, state, actionLabel, action) {
  const row = document.createElement("div");
  row.className = "person-row";
  if (avatarUrl) {
    const img = document.createElement("img");
    img.className = "person-avatar";
    img.src = avatarUrl;
    img.alt = "";
    row.append(img);
  } else {
    const avatar = document.createElement("span");
    avatar.className = "person-avatar";
    avatar.textContent = username?.[0]?.toUpperCase() ?? "✦";
    row.append(avatar);
  }
  const name = document.createElement("strong");
  name.className = "person-name";
  name.textContent = `@${username ?? "savaşçı"}`;
  const status = document.createElement("small");
  status.className = "person-state";
  status.textContent = state;
  row.append(name, status);
  if (actionLabel) {
    const button = document.createElement("button");
    button.className = "mini-button";
    button.textContent = actionLabel;
    button.addEventListener("click", action);
    row.append(button);
  }
  return row;
}

function setupSettings() {
  syncSettingsModal();
  saveSettings();
}

function updateUserDisplay() {
  const name = accountProfile?.username ?? currentUser?.username ?? "Misafir";
  $("#account-name").textContent = name.startsWith("@") ? name : `@${name}`;
  $("#profile-username").textContent = name.startsWith("@") ? name : `@${name}`;
  const avatarUrl = accountProfile?.avatar_url;
  if (avatarUrl) {
    $("#avatar-small").innerHTML = `<img src="${avatarUrl}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`;
    $("#profile-avatar").style.backgroundImage = `url("${avatarUrl}")`;
    $("#profile-avatar").textContent = "";
  } else {
    $("#avatar-small").textContent = currentUser?.username?.[0]?.toUpperCase() ?? "✦";
    $("#profile-avatar").style.backgroundImage = "";
    $("#profile-avatar").textContent = "✦";
  }
  $("#account-pill").title = currentUser ? "Websim hesabı bağlı" : "Misafir olarak oynuyorsun";
}

async function initialize() {
  setupSettings();
  progress = localProgress();
  renderProgress();
  try {
    currentUser = await window.websim?.getUser?.() ?? null;
  } catch {
    currentUser = null;
  }
  updateUserDisplay();
  let status;
  try {
    status = await api.status();
    setDatabaseWarning(!status.database);
  } catch (error) {
    if (error.code === "unavailable") databaseUnavailable(error.message);
    else console.warn("Veri tabanı durumu alınamadı:", error);
    return;
  }
  if (!currentUser) return;
  try {
    accountProfile = status.profile;
    if (accountProfile) {
      const remoteProgress = await api.getProgress();
      progress = { ...progress, ...remoteProgress.progress };
      persistLocalProgress();
    } else {
      const platformName = String(currentUser.username ?? "").replace(/[^a-zA-Z0-9_]/g, "_").slice(0, 20);
      if (platformName.length >= 3) {
        try {
          const result = await api.saveProfile({ username: platformName, avatarUrl: currentUser.avatar_url ?? null });
          accountProfile = result.profile;
        } catch (error) {
          if (error.code === "unavailable") databaseUnavailable(error.message);
        }
      }
      if (!accountProfile) openModal("profile-template");
    }
    updateUserDisplay();
  } catch (error) {
    if (error.code === "unavailable") databaseUnavailable(error.message);
    else if (error.status !== 401) console.warn("Hesap durumu alınamadı:", error);
  }
}

document.addEventListener("click", async (event) => {
  const actionElement = event.target.closest("[data-action]");
  if (!actionElement) return;
  const action = actionElement.dataset.action;
  if (action === "home") {
    if (game.running) game.dispose();
    showView("home");
    closeModal();
  } else if (action === "campaign") startCampaign(progress.level);
  else if (action === "multiplayer") openMultiplayerModal();
  else if (action === "friends") {
    showView("social");
    $("#social-title").textContent = "Arkadaşlar";
    $("#social-kicker").textContent = "TOPLULUK";
    refreshFriends();
  } else if (action === "settings") openModal("settings-template");
  else if (action === "profile") openModal("profile-template");
  else if (action === "close-modal") closeModal();
  else if (action === "pause") game.pause();
  else if (action === "leave-game") leaveCampaign();
  else if (action === "leave-online") leaveOnline();
  else if (action === "ability") game.lightning();
  else if (action === "create-room") createRoom();
  else if (action === "copy-code") {
    try {
      await navigator.clipboard.writeText(roomInfo?.code ?? "");
      toast("Oda kodu kopyalandı.");
    } catch {
      toast(`Oda kodu: ${roomInfo?.code}`);
    }
  } else if (action === "start-online") {
    activeRoom?.send({ type: "start" });
    $("#lobby-note", modalContent).textContent = "Savaş başlatılıyor…";
  } else if (action === "voice") {
    if (!activeRoom) return;
    try {
      const enabled = await activeRoom.toggleVoice();
      $$("[data-action=voice]").forEach((button) => {
        button.classList.toggle("active", enabled);
        button.textContent = enabled ? "◖ SES AÇIK" : "◖ SES";
      });
    } catch {
      toast("Ses için mikrofon izni ver ve güvenli bağlantı kullan.");
    }
  } else if (action === "toggle-chat") {
    $("#online-chat-panel").hidden = !$("#online-chat-panel").hidden;
  }
});

document.addEventListener("click", (event) => {
  const option = event.target.closest("[data-mode]");
  if (!option) return;
  selectedRoomMode = option.dataset.mode;
  $$("[data-mode]", modalContent).forEach((button) => button.classList.toggle("selected", button === option));
});

document.addEventListener("click", (event) => {
  const toggle = event.target.closest("[data-setting]");
  if (!toggle) return;
  const key = toggle.dataset.setting;
  settings[key] = !settings[key];
  toggle.classList.toggle("on", settings[key]);
  saveSettings();
});

document.addEventListener("click", (event) => {
  const unitButton = event.target.closest("[data-unit]");
  if (unitButton && game.mode === "campaign") game.recruit(unitButton.dataset.unit);
  const onlineButton = event.target.closest("[data-online]");
  if (onlineButton && game.mode === "online" && onlineButton.dataset.online === "hit") game.onlineAttack();
});

document.addEventListener("pointerdown", (event) => {
  const control = event.target.closest("[data-online]");
  if (!control || control.dataset.online === "hit") return;
  const direction = control.dataset.online === "left" ? -1 : 1;
  game.onlineMove(direction);
  control.setPointerCapture?.(event.pointerId);
  control._moveTimer = window.setInterval(() => game.onlineMove(direction), 110);
});

for (const type of ["pointerup", "pointercancel", "lostpointercapture"]) {
  document.addEventListener(type, (event) => {
    const control = event.target.closest?.("[data-online]");
    if (control?._moveTimer) {
      clearInterval(control._moveTimer);
      control._moveTimer = null;
    }
  });
}

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    if (!modalBackdrop.hidden) closeModal();
    else if (game.mode === "campaign" && game.running) game.pause();
  }
  if (modalBackdrop.hidden && game.running && game.mode === "campaign") {
    const key = event.key.toLowerCase();
    if (key === "q") game.recruit("swordsman");
    if (key === "w") game.recruit("archer");
    if (key === "e") game.recruit("giant");
    if (event.code === "Space") {
      event.preventDefault();
      game.lightning();
    }
  } else if (modalBackdrop.hidden && game.running && game.mode === "online") {
    if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") game.onlineMove(-1);
    if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") game.onlineMove(1);
    if (event.code === "Space" || event.key === "Enter") game.onlineAttack();
  }
});

document.addEventListener("submit", async (event) => {
  const form = event.target;
  event.preventDefault();
  if (form.id === "join-form") {
    const code = $("#room-code-input", form).value.trim();
    await enterRoom(code);
  } else if (form.id === "friend-form") {
    if (!requireAccount("Arkadaş ekleme")) return;
    const input = $("#friend-username");
    try {
      await api.addFriend(input.value);
      input.value = "";
      toast("Arkadaşlık isteği gönderildi.");
      refreshFriends();
    } catch (error) {
      handleApiError(error);
    }
  } else if (form.id === "chat-form") {
    const input = $("#chat-input");
    const text = input.value.trim();
    if (text && activeRoom) activeRoom.chat(text);
    input.value = "";
  } else if (form.id === "online-chat-form") {
    const input = $("#online-chat-input");
    const text = input.value.trim();
    if (text && activeRoom) activeRoom.chat(text);
    input.value = "";
  } else if (form.id === "lobby-invite-form") {
    const input = $("#lobby-invite-name");
    if (!requireAccount("Arkadaş daveti")) return;
    try {
      await api.invite(input.value, roomInfo.code);
      toast(`@${input.value.replace(/^@/, "")} için davet gönderildi.`);
      input.value = "";
    } catch (error) {
      handleApiError(error);
    }
  } else if (form.id === "profile-form") {
    if (!currentUser) {
      toast("Profilini çevrim içi kaydetmek için Websim hesabınla giriş yap.");
      return;
    }
    const username = $("#profile-name-input").value.trim();
    const file = $("#profile-image-input").files?.[0];
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      toast("Kullanıcı adı 3–20 karakter; harf, sayı ve alt çizgi kullan.");
      return;
    }
    if (file && file.size > 5 * 1024 * 1024) {
      toast("Profil görseli en fazla 5 MB olabilir.");
      return;
    }
    try {
      if (file) uploadedAvatarUrl = await window.websim.upload(file);
      const response = await api.saveProfile({ username, avatarUrl: uploadedAvatarUrl ?? accountProfile?.avatar_url ?? null });
      accountProfile = response.profile;
      updateUserDisplay();
      closeModal();
      toast("Savaşçı profilin kaydedildi.");
      if (views.social.classList.contains("active")) refreshFriends();
    } catch (error) {
      handleApiError(error);
    }
  }
});

document.addEventListener("change", (event) => {
  if (event.target.id !== "profile-image-input") return;
  const file = event.target.files?.[0];
  if (!file) return;
  const preview = $("#profile-image-preview", modalContent);
  preview.src = URL.createObjectURL(file);
  preview.hidden = false;
});

window.addEventListener("arena:error", (event) => toast(event.detail));
window.addEventListener("beforeunload", () => {
  game.dispose();
  activeRoom?.close();
  ambient?.pause();
});

initialize();
