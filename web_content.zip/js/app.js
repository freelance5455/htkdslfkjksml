var SH=[["fn","Flight number","TK0511",6],["dt","Date of flight","04",2],["reg","Aircraft registration","TCJHU",6],["dep","Departure airport","PZU",4],["dst","Destination airport","IST",4]];
var DEP=[["choff","Chocks off (HHMM)","0315",4],["air","Airborne (HHMM)","0320",4],["ft","Flight time (HHMM)","0240",4],["pax","Total PAX","123",3],["inf","Total INF","4",3]];
var TABS=[
{id:"arr",name:"Arrival",f:[["ata","ATA (HHMM)","0300",4],["chon","Chocks on (HHMM)","0317",4]]},
{id:"adc",name:"All doors closed",f:[["dcl","All doors closed time (HHMM)","0400",4]]},
{id:"dep",name:"Departure",f:DEP},
{id:"dly",name:"Departure with delay code",f:DEP.concat([["dly","Delay code and durations (DL added automatically)","86/02/0010/0007",30],["rmk","Delay remarks (DLA added automatically)","86J/02B",40]])}
];
var S={},cur=0,$=function(i){return document.getElementById(i)};
try{S=JSON.parse(localStorage.getItem("am1")||"{}")||{}}catch(e){S={}}
function save(){try{localStorage.setItem("am1",JSON.stringify(S))}catch(e){}}
function field(f,box){
 var d=document.createElement("div");
 if(f[0]==="rmk"||f[0]==="dly"||f[0]==="fn")d.style.gridColumn="1/-1";
 var l=document.createElement("label");l.textContent=f[1];l.htmlFor="f_"+f[0];
 var i=document.createElement("input");i.id="f_"+f[0];i.maxLength=f[3];i.placeholder=f[2];
 i.autocomplete="off";i.autocapitalize="characters";
 if(/HHMM|^(Total|Delay sub|Date)/.test(f[1]))i.inputMode="numeric";
 i.value=S[f[0]]||"";
 i.oninput=function(){S[f[0]]=i.value.toUpperCase().replace(/\s/g,"");if(i.value!==S[f[0]])i.value=S[f[0]];save();i.classList.remove("bad")};
 d.appendChild(l);d.appendChild(i);box.appendChild(d);
}
function render(){
 var t=$("tabs");t.innerHTML="";
 TABS.forEach(function(x,n){var b=document.createElement("button");b.textContent=x.name;b.setAttribute("role","tab");b.setAttribute("aria-selected",n===cur);b.onclick=function(){cur=n;render()};t.appendChild(b)});
 $("shared").innerHTML="";SH.forEach(function(f){field(f,$("shared"))});
 $("extra").innerHTML="";TABS[cur].f.forEach(function(f){field(f,$("extra"))});
 $("ttl").textContent=TABS[cur].name+" message";
 $("err").textContent="";$("out").textContent="The message appears here.";
}
function ok(k,label,errs,len){
 var v=S[k]||"";
 if(!/^\d{4}$/.test(v)||+v.slice(0,2)>23||+v.slice(2)>59){errs.push(k)}
 return v;
}
function pad(v,n){v=String(v||"");while(v.length<n)v="0"+v;return v}
function gen(){
 var e=[],m=[],h,id=TABS[cur].id,fl=TABS[cur].f,g=function(k){return S[k]||""};
 SH.forEach(function(f){if(!g(f[0]))e.push(f[0])});
 // time checks
 fl.forEach(function(f){
  if(/HHMM/.test(f[1])&&f[0]!=="d1"&&f[0]!=="d2"){var v=g(f[0]);if(!/^\d{4}$/.test(v)||+v.slice(0,2)>23||+v.slice(2)>59)e.push(f[0])}
  else if(/^d[12]$/.test(f[0])){if(!/^\d{4}$/.test(g(f[0]))||+g(f[0]).slice(2)>59)e.push(f[0])}
  else if(!g(f[0])&&f[0]!=="rmk")e.push(f[0]);
 });
 document.querySelectorAll("input").forEach(function(i){i.classList.toggle("bad",e.indexOf(i.id.slice(2))>-1)});
 if(e.length){$("err").textContent="Fill in or fix the highlighted fields. Times use 4 digits, 0000–2359.";$("out").textContent="";return null}
 $("err").textContent="";
 h=g("fn")+"/"+pad(g("dt"),2)+"."+g("reg")+"."+g("dep");
 var out;
 if(id==="arr")out=["MVT",h,"AA"+g("ata")+"/"+g("chon")];
 else if(id==="adc")out=["ALL DOORS CLOSED",h,g("dcl"),"","END"];
 else{
  var a=g("air"),f=g("ft"),mins=(+a.slice(0,2)*60+ +a.slice(2)+ +f.slice(0,2)*60+ +f.slice(2))%1440;
  var eta=pad(Math.floor(mins/60),2)+pad(mins%60,2);
  if(id==="dep")out=["MVT",h,"AD"+g("choff")+"/"+a+"   EA"+eta+" "+g("dst"),"TTL PAX "+g("pax"),pad(g("inf"),2)+" INF"];
  else out=["MVT",h,"AD"+g("choff")+"/"+a+" EA"+eta+" "+g("dst"),"DL"+g("dly").replace(/^DL/,""),"TTL PAX "+g("pax"),pad(g("inf"),2)+" INF"].concat(g("rmk")?["DLA"+g("rmk").replace(/^DLA/,"")]:[]);
 }
 var txt=out.join("\n");$("out").textContent=txt;return txt;
}
$("gen").onclick=gen;
$("clr").onclick=function(){TABS[cur].f.forEach(function(f){delete S[f[0]]});save();render()};
$("cp").onclick=function(){
 var t=gen();if(!t)return;
 var done=function(){$("err").style.color="var(--ink)";$("err").textContent="Copied.";setTimeout(function(){$("err").style.color="";$("err").textContent=""},1500)};
 var fb=function(){var r=document.createRange();r.selectNodeContents($("out"));var s=getSelection();s.removeAllRanges();s.addRange(r);try{document.execCommand("copy");done()}catch(x){$("err").textContent="Press and hold the message to copy it."}};
 try{navigator.clipboard.writeText(t).then(done,fb)}catch(x){fb()}
};
render();
