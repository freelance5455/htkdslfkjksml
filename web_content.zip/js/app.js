(function(){
"use strict";
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
const money=n=>new Intl.NumberFormat("fa-IR").format(Math.round(Number(n)||0));
const invoicePrice=n=>Math.round((Number(n)||0)*1000);
const today=()=>new Date().toLocaleDateString("fa-IR");
const state={page:"home",editingService:null,editingVehicle:null,editingOp:null,invoice:{vehicleId:"",items:[],customer:{name:"",mobile:"",plate:"",mileage:"",notes:""},discountType:"amount",discountValue:0},detailId:null};

function shell(){
 const s=DB.settings();
 document.body.classList.toggle("darkMode",s.theme==="dark");
 $("#app").innerHTML=`<header><div class="brand">${esc(s.business_name)}</div></header>
 <main id="view"></main>
 <nav class="bottom">
  <button class="navItem" data-nav="home"><svg viewBox="0 0 24 24"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-7h6v7"/></svg><span>خانه</span></button>
  <button class="navItem" data-nav="invoices"><svg viewBox="0 0 24 24"><path d="M6 3h9l3 3v15H6z"/><path d="M15 3v4h4M9 12h6M9 16h6"/></svg><span>فاکتورها</span></button>
  <button class="navItem" data-nav="services"><svg viewBox="0 0 24 24"><path d="m14.7 6.3 3-3 3 3-3 3"/><path d="m12 9 3 3"/><path d="M4 20l7-7 3 3-7 7H4z"/><path d="m17 10 3 3"/></svg><span>خدمات</span></button>
  <button class="navItem" data-nav="vehicles"><svg viewBox="0 0 24 24"><path d="M5 17h14l-1.2-6H6.2z"/><path d="m7 11 1.5-4h7L17 11M5 17v2M19 17v2"/><circle cx="8" cy="17" r="1.5"/><circle cx="16" cy="17" r="1.5"/></svg><span>خودروها</span></button>
  <button class="navItem" data-nav="settings"><svg viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"/><path d="M4.9 4.9 7 7m10 10 2.1 2.1M12 3v3m0 12v3M3 12h3m12 0h3M4.9 19.1 7 17m10-10 2.1-2.1"/></svg><span>تنظیمات</span></button>
 </nav>`;
 bindNav();
 render();
}
function bindNav(){document.querySelectorAll(".navItem").forEach(btn=>btn.addEventListener("click",()=>go(btn.dataset.nav)))}
function go(p){state.page=p;render()}
function newInvoice(){state.invoice={vehicleId:"",items:[],customer:{name:"",mobile:"",plate:"",mileage:"",notes:""},discountType:"amount",discountValue:0};state.page="new";render()}
function render(){if(state.page==="home")home();else if(state.page==="new")invoicePage();else if(state.page==="invoices")invoices();else if(state.page==="detail")detail();else if(state.page==="services")services();else if(state.page==="vehicles")vehicles();else if(state.page==="settings")settings();window.scrollTo(0,0);if(window.normalizePlateNumbers)normalizePlateNumbers();document.querySelectorAll(".navItem").forEach(b=>b.classList.toggle("active",b.dataset.nav===state.page||(state.page==="detail"&&b.dataset.nav==="invoices")))}

function home(){
 const inv=DB.invoices(), sv=DB.services(), vh=DB.allVehicles();
 $("#view").innerHTML=`<section class="hero"><div><div class="eyebrow">OFFLINE WORKSHOP TOOL</div><h1>${esc(DB.settings().business_name)}</h1><p>محاسبه اجرت و صدور فاکتور، بدون نیاز به اینترنت.</p></div><button class="primary heroBtn" onclick="newInvoice()">فاکتور جدید</button></section>
 <div class="grid3"><div class="stat"><b>${inv.length}</b><span>فاکتور ثبت‌شده</span></div><div class="stat"><b>${sv.length}</b><span>خدمت</span></div><div class="stat"><b>${vh.length}</b><span>خودرو</span></div></div>
 <div class="sectionHead"><h2>دسترسی سریع</h2></div><div class="cards">
 <button class="card action" onclick="newInvoice()"><div class="quickIcon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div><strong>فاکتور جدید</strong><span>انتخاب خودرو و خدمات</span></button>
 <button class="card action" onclick="go('invoices')"><div class="quickIcon"><svg viewBox="0 0 24 24"><path d="M6 3h9l3 3v15H6z"/><path d="M15 3v4h4M9 12h6M9 16h6"/></svg></div><strong>فاکتورهای قبلی</strong><span>جستجو، مشاهده و حذف</span></button>
 <button class="card action" onclick="go('services')"><div class="quickIcon"><svg viewBox="0 0 24 24"><path d="m14.7 6.3 3-3 3 3-3 3"/><path d="m12 9 3 3"/><path d="M4 20l7-7 3 3-7 7H4z"/></svg></div><strong>خدمات و قیمت‌ها</strong><span>مدیریت خدمت، عملیات و اجرت</span></button>
 <button class="card action" onclick="go('vehicles')"><div class="quickIcon"><svg viewBox="0 0 24 24"><path d="M5 17h14l-1.2-6H6.2z"/><path d="m7 11 1.5-4h7L17 11M5 17v2M19 17v2"/><circle cx="8" cy="17" r="1.5"/><circle cx="16" cy="17" r="1.5"/></svg></div><strong>خودروها</strong><span>دسته‌بندی قیمت‌گذاری</span></button>
 </div>`;
}

function invoicePage(){
 const d=state.invoice, vs=DB.vehicles(), services=DB.services();
 const v=vs.find(x=>x.id===d.vehicleId), tier=v?v.tier:"other";
 const subtotal=d.items.reduce((a,i)=>a+i.price,0), disc=d.discountType==="percent"?subtotal*(Number(d.discountValue)||0)/100:Number(d.discountValue)||0, total=Math.max(0,subtotal-disc);
 $("#view").innerHTML=`<div class="pageHead"><button class="back" onclick="go('home')">←</button><div><h2>فاکتور جدید</h2><small>مرحله ۱ و ۲ و ۳ در یک صفحه</small></div></div>
 <div class="card formCard vehicleSelectCard"><label for="vehicleSearch">خودرو</label><input id="vehicleSearch" class="vehicleSearch" type="search" placeholder="برای جستجو نام خودرو را بنویس..." autocomplete="off" oninput="filterVehiclePicker(this.value)">
 <div id="selectedVehicle" class="selectedVehicle">${v?`<span>خودروی انتخاب‌شده</span><b>${esc(v.name)}</b>`:`<span>هنوز خودرویی انتخاب نشده</span>`}</div>
 <div id="vehiclePickerList" class="vehiclePickerList" hidden></div>
 ${v?`<div class="hint">گروه قیمت: ${tierLabel(tier)}</div>`:""}</div>
 <div class="card"><div class="sectionHead"><h3>خدمات و عملیات</h3></div>${services.length?services.map(s=>servicePicker(s,tier)).join(""):`<div class="empty">هنوز خدمتی تعریف نشده. از بخش خدمات اضافه کن.</div>`}</div>
 <div class="card"><h3>آیتم‌های انتخاب‌شده</h3>${d.items.length?d.items.map((i,n)=>`<div class="line"><div><b>${esc(i.operationName)}</b><small>${esc(i.serviceName)}</small></div><div class="lineRight"><input class="miniPrice" type="number" value="${i.price}" onchange="changeItemPrice(${n},this.value)"><button class="dangerText" onclick="removeItem(${n})">×</button></div></div>`).join(""):`<div class="empty">هنوز عملیاتی انتخاب نشده.</div>`}</div>
 <div class="card"><h3>اطلاعات مشتری</h3><div class="formGrid">
 <label>نام مشتری<input id="cname" value="${esc(d.customer.name)}"></label><label>موبایل<input id="cmobile" inputmode="tel" value="${esc(d.customer.mobile)}"></label>
 <div><label>پلاک</label>${plateEditor(d.customer.plate)}</div><label>کیلومتر<input id="cmileage" inputmode="numeric" value="${esc(d.customer.mileage)}"></label>
 <label class="full">یادداشت<textarea id="cnotes">${esc(d.customer.notes)}</textarea></label></div></div>
 <div class="card"><h3>تخفیف</h3><div class="discountRow"><select id="dtype"><option value="amount" ${d.discountType==="amount"?"selected":""}>مبلغ</option><option value="percent" ${d.discountType==="percent"?"selected":""}>درصد</option></select><input id="dval" type="number" value="${d.discountValue||""}" placeholder="0"></div></div>
 <div class="totalBox"><div><span>جمع خدمات</span><b>${money(subtotal)} ${esc(DB.settings().currency_label)}</b></div><div><span>تخفیف</span><b>${money(disc)}</b></div><div class="final"><span>مبلغ نهایی</span><strong>${money(total)} ${esc(DB.settings().currency_label)}</strong></div></div>
 <button class="primary wide" onclick="saveInvoice()">ثبت فاکتور</button>`;
}
function tierLabel(t){return t==="saipa"?"سایپا":t==="irankhodro"?"ایران‌خودرو":"سایر"}
function servicePicker(s,tier){
 const ops=DB.operations(s.id); return `<div class="serviceBlock"><div class="serviceTitle">${esc(s.name)}</div>${ops.map(o=>`<label class="opRow"><span><input type="checkbox" ${state.invoice.items.some(i=>i.operationId===o.id)?"checked":""} onchange="toggleItem('${o.id}')"><span>${esc(o.name)}</span></span><b>${money(o.prices?.[tier]||0)}</b></label>`).join("")}</div>`
}
function vehiclePickerRows(vs,selectedId,q){
 const query=String(q||"").trim().toLowerCase();
 const filtered=vs.filter(x=>!query||String(x.name||"").toLowerCase().includes(query));
 if(!filtered.length)return `<div class="empty vehicleNoResult">خودرویی پیدا نشد.</div>`;
 return filtered.map(x=>`<button type="button" class="vehiclePick ${x.id===selectedId?"selected":""}" onclick="setVehicle('${x.id}')"><span>${esc(x.name)}</span>${x.id===selectedId?`<b>✓</b>`:""}</button>`).join("");
}
function filterVehiclePicker(q){
 const box=$("#vehiclePickerList"); if(!box)return;
 const query=String(q||"").trim();
 if(!query){box.innerHTML="";box.hidden=true;return;}
 box.innerHTML=vehiclePickerRows(DB.vehicles(),state.invoice.vehicleId,query);
 box.hidden=false;
}
function setVehicle(id){state.invoice.vehicleId=id;render()}
function restoreInvoiceScroll(y){
 const restore=()=>window.scrollTo(0,y);
 requestAnimationFrame(restore);
 setTimeout(restore,0);
 setTimeout(restore,50);
}
function toggleItem(id){
 const scrollY=window.scrollY||window.pageYOffset||0;
 const op=DB.allOperations().find(x=>x.id===id), s=DB.allServices().find(x=>x.id===op.service_id), v=DB.allVehicles().find(x=>x.id===state.invoice.vehicleId), tier=v?.tier||"other";
 const idx=state.invoice.items.findIndex(i=>i.operationId===id);
 if(idx>=0)state.invoice.items.splice(idx,1);else state.invoice.items.push({operationId:id,operationName:op.name,serviceName:s?.name||"",price:invoicePrice(op.prices?.[tier]||0)});
 render();
 restoreInvoiceScroll(scrollY);
}
function removeItem(i){const scrollY=window.scrollY||window.pageYOffset||0;state.invoice.items.splice(i,1);render();restoreInvoiceScroll(scrollY)}
function changeItemPrice(i,v){const scrollY=window.scrollY||window.pageYOffset||0;state.invoice.items[i].price=Number(v)||0;render();restoreInvoiceScroll(scrollY)}
function readCustomer(){state.invoice.customer={name:$("#cname")?.value||"",mobile:$("#cmobile")?.value||"",plate:getPlateValue(),mileage:$("#cmileage")?.value||"",notes:$("#cnotes")?.value||""};state.invoice.discountType=$("#dtype")?.value||"amount";state.invoice.discountValue=Number($("#dval")?.value)||0}
function saveInvoice(){
 readCustomer(); const d=state.invoice;if(!d.vehicleId){alert("ابتدا خودرو را انتخاب کن.");return} if(!d.items.length){alert("حداقل یک عملیات انتخاب کن.");return}
 const v=DB.allVehicles().find(x=>x.id===d.vehicleId), subtotal=d.items.reduce((a,i)=>a+i.price,0), disc=d.discountType==="percent"?subtotal*d.discountValue/100:d.discountValue;
 const invNo=`${DB.settings().invoice_prefix||"HE"}-${new Date().toISOString().slice(2,10).replace(/-/g,"")}-${String(Date.now()).slice(-4)}`;
 DB.addInvoice({invoice_no:invNo,vehicle_name:v.name,vehicle_tier:v.tier,customer:d.customer,items:d.items,subtotal,discount:Math.min(subtotal,Math.max(0,disc)),discount_type:d.discountType,discount_value:d.discountValue,total:Math.max(0,subtotal-Math.min(subtotal,Math.max(0,disc)))});
 state.detailId=DB.invoices()[0].id;state.page="detail";render();
}

function invoices(){
 const arr=DB.invoices();
 $("#view").innerHTML=`<div class="pageHead"><div><h2>فاکتورهای قبلی</h2><small>${arr.length} فاکتور ثبت شده</small></div><button class="primary small" onclick="newInvoice()">+ جدید</button></div>
 <div class="card formCard"><input id="invoiceSearch" placeholder="جستجو: نام، موبایل، پلاک یا شماره فاکتور" oninput="filterInvoices(this.value)"></div>
 <div id="invoiceList">${invoiceRows(arr)}</div>`;
}
function invoiceRows(arr){return arr.length?arr.map(i=>`<button class="invoiceRow" onclick="openDetail('${i.id}')"><div><b>${esc(i.invoice_no)}</b><span>${esc(i.vehicle_name)} · ${esc(i.customer?.name||"بدون نام")}</span><small>${new Date(i.created_at).toLocaleDateString("fa-IR")}</small></div><strong>${money(i.total)}</strong></button>`).join(""):`<div class="empty">فاکتوری وجود ندارد.</div>`}
function filterInvoices(q){q=q.trim().toLowerCase();const a=DB.invoices().filter(i=>[i.customer?.name,i.customer?.mobile,i.customer?.plate,i.vehicle_name,i.invoice_no].some(x=>String(x||"").toLowerCase().includes(q)));$("#invoiceList").innerHTML=invoiceRows(a)}
function openDetail(id){state.detailId=id;state.page="detail";render()}
function detail(){
 const i=DB.invoices().find(x=>x.id===state.detailId);if(!i){go("invoices");return}
 const fs=DB.settings();
 const invoiceFont=`font-family:${esc(fs.invoice_font_family||"Arial")};font-size:${esc(fs.invoice_font_size||"14")}px;font-weight:${esc(fs.invoice_font_weight||"400")}`;
 $("#view").innerHTML=`<div class="pageHead"><button class="back" onclick="go('invoices')">←</button><div><h2>جزئیات فاکتور</h2><small>${esc(i.invoice_no)}</small></div></div>
 <div class="card printCard" style="${invoiceFont}"><div class="invoiceTop"><div><b>${esc(DB.settings().business_name)}</b><span>${esc(i.invoice_no)}</span></div><span>${new Date(i.created_at).toLocaleDateString("fa-IR")}</span></div>
 <div class="customerBox"><b>${esc(i.vehicle_name)}</b><span>مشتری: ${esc(i.customer?.name||"-")}</span><span>پلاک: ${esc(i.customer?.plate||"-")}</span><span>موبایل: ${esc(i.customer?.mobile||"-")}</span><span>کیلومتر: ${esc(i.customer?.mileage||"-")}</span></div>
 ${i.items.map(x=>`<div class="line"><div><b>${esc(x.operationName)}</b><small>${esc(x.serviceName)}</small></div><b>${money(x.price)}</b></div>`).join("")}
 <div class="summary"><div>جمع خدمات <b>${money(i.subtotal)}</b></div><div>تخفیف <b>${money(i.discount)}</b></div><div class="final">نهایی <strong>${money(i.total)} ${esc(DB.settings().currency_label)}</strong></div></div>
 ${i.customer?.notes?`<div class="notes"><b>یادداشت:</b> ${esc(i.customer.notes)}</div>`:""}</div>
 <button class="primary wide noPrint" id="printInvoiceBtn">پرینت / ذخیره به PDF (A4)</button>
 <button class="danger wide noPrint" id="deleteInvoiceBtn" data-invoice-id="${i.id}">حذف فاکتور</button>`;
 const printBtn=$("#printInvoiceBtn");
 if(printBtn) printBtn.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();printInvoice();});
 const deleteBtn=$("#deleteInvoiceBtn");
 if(deleteBtn) deleteBtn.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();deleteInvoice(this.dataset.invoiceId);});
}
function closeInvoiceView(){
  if(typeof renderInvoiceList==="function"){ renderInvoiceList(); }
  else if(typeof go==="function"){ go("invoices"); }
}
function printInvoice(){
  const id=state.detailId||state.currentInvoiceId||state.invoiceId;
  const i=DB.invoices().find(x=>String(x.id)===String(id))||state.currentInvoice||state.detail;
  if(!i){alert("ابتدا یک فاکتور را باز کنید.");return;}
  const settings=DB.settings();
  const fa=n=>new Intl.NumberFormat("fa-IR").format(Math.round(Number(n)||0));
  const esc=x=>String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
  const rows=(i.items||[]).map((x,n)=>`<tr><td>${n+1}</td><td>${esc(x.serviceName||"-")}</td><td>${esc(x.operationName||"-")}</td><td>${fa(x.price)}</td></tr>`).join("");
  const app=document.getElementById("app");
  app.innerHTML=`<div class="invoiceShot" dir="rtl" style="font-family:${esc(settings.invoice_font_family||"Arial")};font-size:${esc(settings.invoice_font_size||"14")}px;font-weight:${esc(settings.invoice_font_weight||"400")}">
    <div class="shotHead">
      <div><div class="shotBrand">${esc(settings.business_name||"Hadi Engine Tuning")}</div><div class="shotTitle">فاکتور خدمات</div></div>
      <div class="shotMeta">شماره: ${esc(i.invoice_no||"-")}<br>تاریخ: ${new Date(i.created_at||Date.now()).toLocaleDateString("fa-IR")}</div>
    </div>
    <div class="shotInfo">
      <div><b>مشتری</b><br>${esc(i.customer?.name||"-")}<br>${esc(i.customer?.mobile||"-")}</div>
      <div><b>خودرو</b><br>${esc(i.vehicle_name||"-")}<br>پلاک: ${esc(i.customer?.plate||"-")}<br>کیلومتر: ${esc(i.customer?.mileage||"-")}</div>
    </div>
    <table class="shotTable"><thead><tr><th>ردیف</th><th>خدمت</th><th>عملیات</th><th>مبلغ</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="shotTotals">
      <div><span>جمع خدمات</span><b>${fa(i.subtotal)} ${esc(settings.currency_label||"تومان")}</b></div>
      <div><span>تخفیف</span><b>${fa(i.discount)} ${esc(settings.currency_label||"تومان")} (${i.subtotal>0?Math.round((Number(i.discount)||0)/Number(i.subtotal)*100):0}%)</b></div>
      <div class="grand"><span>مبلغ نهایی</span><b>${fa(i.total)} ${esc(settings.currency_label||"تومان")}</b></div>
    </div>
    ${i.customer?.notes?`<div class="shotNotes"><b>یادداشت:</b> ${esc(i.customer.notes)}</div>`:""}
    <div class="shotFooter">Hadi Engine Tuning</div>
    
  <button type="button" class="invoiceBackBtn" id="invoiceBackBtn">← بازگشت به صفحه خانه</button></div>`;
  const backBtn=app.querySelector("#invoiceBackBtn");
  if(backBtn){
    backBtn.addEventListener("click",function(e){
      e.preventDefault();
      e.stopPropagation();
      state.page="home";
      shell();
    });
  }

} 
function deleteInvoice(id){
  const invoice=DB.invoices().find(x=>String(x.id)===String(id));
  if(!invoice){state.detailId=null;state.page="invoices";render();return}
  const html=`<div class="card formCard" style="text-align:center"><h3>حذف فاکتور</h3><p>فاکتور <b>${esc(invoice.invoice_no||"")}</b> حذف شود؟</p><div style="display:flex;gap:10px"><button type="button" id="cancelDelete" class="secondary wide">انصراف</button><button type="button" id="confirmDelete" class="danger wide">حذف فاکتور</button></div></div>`;
  modal("تأیید حذف",html);
  const cancel=document.getElementById("cancelDelete");
  const confirmBtn=document.getElementById("confirmDelete");
  if(cancel) cancel.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();closeModal();});
  if(confirmBtn) confirmBtn.addEventListener("click",function(e){
    e.preventDefault();e.stopPropagation();
    DB.deleteInvoice(String(invoice.id));
    state.detailId=null;
    state.page="invoices";
    closeModal();
    render();
  });
}

function services(){
 const sv=DB.allServices();
 const serviceCards=sv.map((s)=>{
   const ops=DB.allOperations(s.id).map(o=>`<div class="opAdmin"><span>${esc(o.name)}${o.enabled===false?" · خاموش":""}</span><span class="prices">${money(invoicePrice(o.prices?.saipa))} / ${money(invoicePrice(o.prices?.irankhodro))} / ${money(invoicePrice(o.prices?.other))}</span><span class="adminBtns"><button type="button" onclick="opForm('${o.id}')">ویرایش</button><button type="button" onclick="DB.reorderOperation('${o.id}',-1);services()">↑</button><button type="button" onclick="DB.reorderOperation('${o.id}',1);services()">↓</button><button type="button" class="dangerText deleteOpBtn" data-id="${o.id}">حذف</button></span></div>`).join("");
   return `<div class="serviceAdmin"><div class="adminHead"><div><b>${esc(s.name)}</b>${s.enabled===false?`<em>غیرفعال</em>`:""}</div><div class="adminBtns"><button type="button" onclick="DB.reorderService('${s.id}',-1);services()">↑</button><button type="button" onclick="DB.reorderService('${s.id}',1);services()">↓</button><button type="button" onclick="serviceForm('${s.id}')">ویرایش</button><button type="button" onclick="toggleService('${s.id}')">${s.enabled===false?"فعال":"خاموش"}</button><button type="button" class="dangerText deleteServiceBtn" data-id="${s.id}">حذف</button></div></div>
 <div class="ops">${ops}<button type="button" class="addOp" onclick="opForm(null,'${s.id}')">＋ عملیات</button></div></div>`;
 }).join("");
 const html=`<div class="pageHead"><div><h2>خدمات و قیمت‌ها</h2><small>سه سطح قیمت: سایپا، ایران‌خودرو، سایر</small></div><button type="button" class="primary small" onclick="serviceForm()">+ خدمت</button></div>
 <div class="card">${serviceCards||`<div class="empty">خدمتی ثبت نشده.</div>`}</div><button class="primary wide" type="button" onclick="serviceForm()">＋ افزودن خدمت / قطعه جدید</button>`;
 $("#view").innerHTML=html;
 document.querySelectorAll(".deleteServiceBtn").forEach(btn=>btn.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();deleteService(btn.dataset.id);}));
 document.querySelectorAll(".deleteOpBtn").forEach(btn=>btn.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();deleteOperation(btn.dataset.id);}));
}


function normalizePlateNumbers(){
 document.querySelectorAll(".plateNum2,.plateNum3").forEach(el=>{
   el.addEventListener("input",()=>{el.value=el.value.replace(/[^\d۰-۹]/g,"");});
   el.addEventListener("focus",()=>{try{el.setAttribute("inputmode","numeric");}catch(e){}});
 });
}

function plateEditor(value=""){
  const p=String(value||"").split("-");
  const a=p[0]||"", letter=p[1]||"", b=p[2]||"";
  // New format: 2 digits - letter - 3 digits - ایران - 2 digits.
  // Backward compatibility: old saved values ended in the 2-digit region code.
  const region=p.length>=5 ? (p[4]||"") : (p[3]||"");
  const letters=["الف","ب","پ","ت","ث","ج","چ","ح","خ","د","ذ","ر","ز","ژ","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ک","گ","ل","م","ن","و","ه","ی"];
  return `<div class="plateEditor">
    <div class="platePreview">
      <input class="plateNum2" inputmode="numeric" maxlength="2" value="${a}" placeholder="۱۲">
      <input class="plateLetter plateLetterInput" maxlength="1" inputmode="text" value="${letter||""}" placeholder="ب" aria-label="حرف پلاک">
      <input class="plateNum3" inputmode="numeric" maxlength="3" value="${b}" placeholder="۱۲۳">
      <span class="plateIran">ایران</span>
      <input class="plateNum2 plateRegion" inputmode="numeric" maxlength="2" value="${region}" placeholder="۵۹" aria-label="دو رقم آخر پلاک">
    </div>
    <input type="hidden" class="plateValue" value="${value}">
  </div>`;
}
function openLetterPad(btn){
  const letters=["الف","ب","پ","ت","ث","ج","چ","ح","خ","د","ذ","ر","ز","ژ","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ک","گ","ل","م","ن","و","ه","ی"];
  const html=`<div class="letterGrid">${letters.map(x=>`<button type="button" onclick="pickPlateLetter(this,'${x}')">${x}</button>`).join("")}</div>`;
  modal("انتخاب حرف پلاک",html+`<button class="wide" onclick="closeModal()">بستن</button>`);
  window._plateLetterButton=btn;
}
function pickPlateLetter(btn,letter){
  if(window._plateLetterButton){window._plateLetterButton.textContent=letter;}
  closeModal();
}
function getPlateValue(){
  const box=document.querySelector(".plateEditor");
  if(!box)return "";
  const a=box.querySelector(".plateNum2")?.value||"";
  const l=box.querySelector(".plateLetter")?.value||"";
  const b=box.querySelector(".plateNum3")?.value||"";
  const region=box.querySelector(".plateRegion")?.value||"";
  return `${a}-${l}-${b}-ایران-${region}`;
}

function closeModal(){const m=document.querySelector(".modalWrap");if(m)m.remove()}
function modal(title,body,saveFn){
 closeModal();
 const w=document.createElement("div");w.className="modalWrap";
 w.innerHTML=`<div class="modal"><div class="modalHead"><h3>${esc(title)}</h3><button type="button" class="modalCloseBtn" aria-label="بستن">×</button></div><div class="modalBody">${body}</div><div class="modalActions"><button type="button" class="secondary modalCancelBtn">انصراف</button><button type="button" class="primary" id="modalSave">ذخیره</button></div></div>`;
 document.body.appendChild(w);
 const cancel=w.querySelector(".modalCancelBtn");
 const close=w.querySelector(".modalCloseBtn");
 if(cancel) cancel.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();closeModal();});
 if(close) close.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();closeModal();});
 $("#modalSave").addEventListener("click",saveFn);
}
function serviceForm(id){
 const s=id?DB.allServices().find(x=>x.id===id):{name:""};
 modal(id?"ویرایش خدمت":"ثبت خدمت",`<label class="modalLabel">نام خدمت / قطعه<input id="mServiceName" value="${esc(s.name)}"></label>`,()=>{
   const name=$("#mServiceName").value.trim(); if(!name){alert("نام خدمت را وارد کن.");return}
   if(id)DB.updateService(id,{name});else DB.addService({name}); closeModal();services();
 });
}
function deleteService(id){
 const item=DB.allServices().find(x=>x.id===id); if(!item)return;
 const html=`<div class="card formCard" style="text-align:center"><h3>حذف خدمت / قطعه</h3><p>«${esc(item.name)}» و تمام عملیات‌های داخل آن حذف شود؟</p><div style="display:flex;gap:10px"><button type="button" id="cancelDeleteService" class="secondary wide">انصراف</button><button type="button" id="confirmDeleteService" class="danger wide">حذف</button></div></div>`;
 modal("تأیید حذف",html,()=>{});
 const save=$("#modalSave"); if(save)save.style.display="none";
 const cancel=$("#cancelDeleteService"); const confirmBtn=$("#confirmDeleteService");
 if(cancel)cancel.addEventListener("click",e=>{e.preventDefault();closeModal()});
 if(confirmBtn)confirmBtn.addEventListener("click",e=>{e.preventDefault();DB.deleteService(id);closeModal();services();});
}
function deleteOperation(id){
 const item=DB.allOperations().find(x=>x.id===id); if(!item)return;
 const html=`<div class="card formCard" style="text-align:center"><h3>حذف عملیات</h3><p>عملیات «${esc(item.name)}» حذف شود؟</p><div style="display:flex;gap:10px"><button type="button" id="cancelDeleteOp" class="secondary wide">انصراف</button><button type="button" id="confirmDeleteOp" class="danger wide">حذف</button></div></div>`;
 modal("تأیید حذف",html,()=>{});
 const save=$("#modalSave"); if(save)save.style.display="none";
 const cancel=$("#cancelDeleteOp"); const confirmBtn=$("#confirmDeleteOp");
 if(cancel)cancel.addEventListener("click",e=>{e.preventDefault();closeModal()});
 if(confirmBtn)confirmBtn.addEventListener("click",e=>{e.preventDefault();DB.deleteOperation(id);closeModal();services();});
}
function toggleService(id){const s=DB.allServices().find(x=>x.id===id);DB.updateService(id,{enabled:s.enabled===false});services()}
function opForm(id,serviceId){
 const o=id?DB.allOperations().find(x=>x.id===id):{name:"",service_id:serviceId,prices:{saipa:0,irankhodro:0,other:0}},p=o.prices||{};
 modal(id?"ویرایش عملیات":"ثبت عملیات",`
 <label class="modalLabel">نام عملیات<input id="mOpName" value="${esc(o.name)}"></label>
 <div class="priceGrid">
 <label class="modalLabel">سایپا<input id="mP1" type="number" inputmode="numeric" value="${p.saipa||0}"></label>
 <label class="modalLabel">ایران‌خودرو<input id="mP2" type="number" inputmode="numeric" value="${p.irankhodro||0}"></label>
 <label class="modalLabel">سایر<input id="mP3" type="number" inputmode="numeric" value="${p.other||0}"></label>
 </div>`,()=>{
   const name=$("#mOpName").value.trim(); if(!name){alert("نام عملیات را وارد کن.");return}
   const x={name,prices:{saipa:Number($("#mP1").value)||0,irankhodro:Number($("#mP2").value)||0,other:Number($("#mP3").value)||0}};
   if(id)DB.updateOperation(id,x);else DB.addOperation(Object.assign(x,{service_id:serviceId}));
   closeModal();services();
 });
}

function vehicles(){
 const vs=DB.allVehicles();
 $("#view").innerHTML=`<div class="pageHead"><div><h2>خودروها</h2><small>گروه قیمت‌گذاری هر خودرو</small></div><button class="primary small" onclick="vehicleForm()">+ خودرو</button></div>
 <div class="card">${vs.length?vs.map(v=>`<div class="vehicleRow"><div><b>${esc(v.name)}</b><span>${tierLabel(v.tier)} ${v.enabled===false?"· غیرفعال":""}</span></div><div><button onclick="vehicleForm('${v.id}')">ویرایش</button><button onclick="toggleVehicle('${v.id}')">${v.enabled===false?"فعال":"خاموش"}</button><button class="dangerText" onclick="deleteVehicle('${v.id}')">حذف</button></div></div>`).join(""):`<div class="empty">خودرویی ثبت نشده.</div>`}</div>`;
}
function vehicleForm(id){
 const v=id?DB.allVehicles().find(x=>x.id===id):{name:"",tier:"other"};
 modal(id?"ویرایش خودرو":"ثبت خودرو",`
 <label class="modalLabel">نام خودرو<input id="mVehicleName" value="${esc(v.name)}"></label>
 <label class="modalLabel">گروه قیمت<select id="mVehicleTier">
 <option value="saipa" ${v.tier==="saipa"?"selected":""}>سایپا</option>
 <option value="irankhodro" ${v.tier==="irankhodro"?"selected":""}>ایران‌خودرو</option>
 <option value="other" ${v.tier==="other"?"selected":""}>سایر</option>
 </select></label>`,()=>{
   const name=$("#mVehicleName").value.trim();if(!name){alert("نام خودرو را وارد کن.");return}
   const tier=$("#mVehicleTier").value;
   if(id)DB.updateVehicle(id,{name,tier});else DB.addVehicle({name,tier});
   closeModal();vehicles();
 });
}
function toggleVehicle(id){const v=DB.allVehicles().find(x=>x.id===id);DB.updateVehicle(id,{enabled:v.enabled===false});vehicles()}
function deleteVehicle(id){if(confirm("خودرو حذف شود؟")){DB.deleteVehicle(id);vehicles()}}

function settings(){
 const s=DB.settings();
 const fontFamily=s.invoice_font_family||"Arial";
 const fontSize=String(s.invoice_font_size||"14");
 const fontWeight=String(s.invoice_font_weight||"400");
 const fontOptions=[["Arial","Arial (پیش‌فرض)"],["Javan","Javan"],["Sahel","ساحل"],["Shahgosh","شاهگوش"],["Kaghaz Alef","کاغذ الف"],["Digi Paeez","پاییز"],["Shokoh","شکوه"],["B Titr","B Titr / تیتر"],["Mj Tehran","تهران"],["Tahoma","Tahoma"],["Segoe UI","Segoe UI"],["Georgia","Georgia"],["Times New Roman","Times New Roman"],["system-ui","سیستم گوشی"]];
 const fontLabel=fontOptions.map(([v,l])=>`<option value="${v}" ${fontFamily===v?"selected":""}>${l}</option>`).join("");
 const sizeLabel=[12,13,14,15,16,17,18].map(n=>`<option value="${n}" ${fontSize===String(n)?"selected":""}>${n} px</option>`).join("");
 const weightLabel=`<option value="400" ${fontWeight==="400"?"selected":""}>معمولی</option><option value="600" ${fontWeight==="600"?"selected":""}>نیمه‌پررنگ</option><option value="700" ${fontWeight==="700"?"selected":""}>پررنگ</option>`;
 $("#view").innerHTML=`<div class="pageHead"><div><h2>تنظیمات</h2><small>اطلاعات برنامه و ظاهر فاکتور</small></div></div>
 <div class="card formCard"><label>نام کسب‌وکار<input id="biz" value="${esc(s.business_name)}"></label><label>واحد پول<input id="currency" value="${esc(s.currency_label)}"></label><label>پیشوند فاکتور<input id="prefix" value="${esc(s.invoice_prefix)}"></label></div>
 <div class="card formCard"><h3 style="margin-top:0">ظاهر برنامه</h3><div class="themeChooser" id="themeChooser" role="group" aria-label="حالت نمایش"><span class="themeLabel darkLabel">دارک</span><button type="button" class="themeSwitch ${s.theme==="dark"?"isDark":"isLight"}" id="themeSwitch" aria-label="تغییر حالت نمایش"><span class="themeKnob"></span></button><span class="themeLabel lightLabel">لایت</span></div><div class="themeHint">با انتخاب حالت، تنظیمات همان لحظه اعمال می‌شود.</div></div>
 <div class="card formCard"><h3 style="margin-top:0">فونت فاکتور</h3><p class="muted">این تنظیمات فقط روی فاکتور نهایی و نسخه چاپی آن اعمال می‌شود.</p><label>نوع فونت<select id="invoiceFontFamily">${fontLabel}</select></label><label>اندازه فونت<select id="invoiceFontSize">${sizeLabel}</select></label><label>وزن فونت<select id="invoiceFontWeight">${weightLabel}</select></label><div class="fontPreview" id="fontPreview">نمونه متن فاکتور — مشتری، خودرو، مبلغ نهایی</div></div>
 <button class="primary wide" id="saveSettingsBtn">ذخیره تنظیمات</button>
 <div class="card"><h3>درباره</h3><p>Hadi Engine Tuning — Offline Edition</p><p class="muted">بدون سرور، بدون حساب کاربری، بدون وابستگی به اینترنت.</p></div>`;
 const family=$("#invoiceFontFamily"),size=$("#invoiceFontSize"),weight=$("#invoiceFontWeight"),preview=$("#fontPreview");
 const themeSwitch=$("#themeSwitch");
 if(themeSwitch) themeSwitch.addEventListener("click",()=>{
   const next=DB.settings().theme==="dark"?"light":"dark";
   DB.setSettings({theme:next});
   shell();
 });
 const previewFont=()=>{if(preview){preview.style.fontFamily=family.value;preview.style.fontSize=size.value+"px";preview.style.fontWeight=weight.value;}};
 [family,size,weight].forEach(el=>el&&el.addEventListener("change",previewFont));
 previewFont();
 const saveBtn=$("#saveSettingsBtn");
 if(saveBtn)saveBtn.addEventListener("click",saveSettings);
}
function saveSettings(){
 DB.setSettings({business_name:$("#biz").value.trim()||"Hadi Engine Tuning",currency_label:$("#currency").value.trim()||"تومان",invoice_prefix:$("#prefix").value.trim()||"HE",theme:$("#appTheme")?.value||"light",invoice_font_family:$("#invoiceFontFamily")?.value||"Arial",invoice_font_size:$("#invoiceFontSize")?.value||"14",invoice_font_weight:$("#invoiceFontWeight")?.value||"400"});
 shell();
}

window.go=go;window.newInvoice=newInvoice;window.setVehicle=setVehicle;window.filterVehiclePicker=filterVehiclePicker;window.toggleItem=toggleItem;window.removeItem=removeItem;window.changeItemPrice=changeItemPrice;window.saveInvoice=saveInvoice;window.filterInvoices=filterInvoices;window.openDetail=openDetail;window.printInvoice=printInvoice;window.deleteInvoice=deleteInvoice;
window.serviceForm=serviceForm;window.deleteService=deleteService;window.deleteOperation=deleteOperation;window.toggleService=toggleService;window.opForm=opForm;window.vehicleForm=vehicleForm;window.toggleVehicle=toggleVehicle;window.deleteVehicle=deleteVehicle;window.saveSettings=saveSettings;window.services=services;window.vehicles=vehicles;
shell();
})();
window.closeInvoiceView=closeInvoiceView;
