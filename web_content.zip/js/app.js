const KEY="game_genie_aufa_games";
let games=JSON.parse(localStorage.getItem(KEY)||"[]");
const $=id=>document.getElementById(id);
let toastTimer;
function toast(text){$("toast").textContent=text;$("toast").classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("toast").classList.remove("show"),1900)}
async function ping(){
  toast("PING BOOSTER • TESTING...");
  try{const t=performance.now();await fetch("https://www.google.com/generate_204?x="+Date.now(),{mode:"no-cors",cache:"no-store"});toast("PING • "+Math.round(performance.now()-t)+" ms")}
  catch(e){toast("PING • TEST FAILED")}
}
async function clearCache(){
  try{sessionStorage.clear();if("caches"in window){const keys=await caches.keys();await Promise.all(keys.map(k=>caches.delete(k)))}toast("CACHE • APP CACHE CLEARED")}
  catch(e){toast("CACHE • DONE")}
}
document.querySelectorAll(".tool").forEach(btn=>btn.addEventListener("click",()=>{
  const a=btn.dataset.action;
  if(a==="ram")toast("RAM BOOSTER • OPTIMIZATION MODE ACTIVE");
  if(a==="fps")toast("FPS BOOSTER • PERFORMANCE MODE ACTIVE");
  if(a==="ping")ping();
  if(a==="cache")clearCache();
}));
function render(){
  const list=$("gameList");list.innerHTML="";
  if(!games.length){list.innerHTML='<div class="game"><div><div class="game-name">No games added</div><div class="game-url">Tap ＋ ADD GAME</div></div></div>';return}
  games.forEach((g,i)=>{
    const row=document.createElement("div");row.className="game";
    const info=document.createElement("div");const name=document.createElement("div");const url=document.createElement("div");
    name.className="game-name";url.className="game-url";name.textContent=g.name;url.textContent=g.url;info.append(name,url);
    const play=document.createElement("button");play.className="play";play.textContent="PLAY ›";play.onclick=()=>{location.href=g.url};
    row.append(info,play);list.appendChild(row);
  });
}
$("addGame").onclick=()=>{$("modal").classList.add("show");$("modal").setAttribute("aria-hidden","false");$("gameName").focus()};
$("cancel").onclick=()=>{$("modal").classList.remove("show");$("modal").setAttribute("aria-hidden","true")};
$("save").onclick=()=>{
  const name=$("gameName").value.trim(),url=$("gameUrl").value.trim();
  if(!name||!url){toast("ISI NAMA DAN URL DULU");return}
  games.push({name,url});localStorage.setItem(KEY,JSON.stringify(games));render();
  $("gameName").value="";$("gameUrl").value="";$("modal").classList.remove("show");toast("GAME • ADDED");
};
render();
