// ============================================================
//  js/app.js — full template
// ============================================================

// ---------- reusable components ----------
function toggleIconBtn(name, onClasses) {
  const b = iconBtn(name);
  b.onClick = () => {
    const on = b.toggleClass(onClasses);
    b.el.querySelector('svg').setAttribute('fill', on ? 'currentColor' : 'none');
  };
  return b;
}

function miniCard(text) {
  const c = create('div', text);
  c.style = 'bg-white rounded-xl p-4 shadow-sm';
  return c;
}

function inputBox(placeholder) {
  const n = create('input');
  n.placeholder = placeholder || '';
  n.style = 'w-full p-3 rounded-xl border border-gray-200 bg-white outline-none text-base';
  return n;
}

function chip(text, active) {
  const n = create('button', text);
  n.style = 'px-4 py-2 rounded-full font-semibold ' +
    (active ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700');
  return n;
}

// ---------- styles ----------
styles({
  primary:   'bg-blue-500 text-white p-3 rounded-xl font-bold active:opacity-80',
  secondary: 'bg-gray-100 text-gray-800 p-3 rounded-xl font-bold active:opacity-80',
  danger:    'bg-red-500 text-white p-3 rounded-xl font-bold active:opacity-80',
  ghost:     'bg-transparent text-blue-500 p-3 rounded-xl font-bold',
  card:      'bg-white rounded-2xl p-4 shadow-sm flex flex-col gap-2',
  title:     'text-2xl font-bold text-black',
  subtitle:  'text-lg font-bold text-black',
  body:      'text-base text-gray-800',
  muted:     'text-sm text-gray-500',
  tiny:      'text-xs text-gray-400',
  row:       'flex flex-row items-center',
  col:       'flex flex-col',
  between:   'flex items-center justify-between',
  gap2:      'gap-2',
  gap4:      'gap-4',
  full:      'w-full',
  input:     'w-full p-3 rounded-xl border border-gray-200 bg-white outline-none text-base',
  divider:   'h-px bg-gray-200 my-2',
});

// ---------- mount ----------
const root = app();
root.style = 'bg-gray-50 min-h-screen pb-24';

// ---------- shared app data ----------
let tasks = [
  { text: 'Buy milk',   done: false },
  { text: 'Walk dog',   done: true  },
  { text: 'Write code', done: false },
];

// ============================================================
//  SCREEN: HOME
// ============================================================
const home = create('div');
home.id = 'home';
home.style = 'flex flex-col gap-4 p-4';

// header
const homeHeader = create('div');
homeHeader.style = 'flex flex-row items-center justify-between p-4 bg-white rounded-2xl shadow-sm gap-2';

const homeTitle = create('h1', 'My Tasks').use('title');
const menuBtn   = iconBtn('menu');
const bellBtn   = iconBtn('bell');
const searchBtn = iconBtn('search');

homeHeader.push(homeTitle, spacer(), menuBtn, bellBtn, searchBtn);

// toggle: menu collapses header to column
menuBtn.onClick = () => {
  homeHeader.toggleClass('flex-row flex-col items-center items-start');
};

// search toggles a search bar
const searchBar = inputBox('Search tasks...');
searchBar.addClass('hidden');

searchBtn.onClick = () => {
  searchBar.toggleClass('hidden');
};

// tasks list
const listBox = create('div');
listBox.style = 'flex flex-col gap-2';

function renderTasks() {
  listBox.el.replaceChildren();

  if (tasks.length === 0) {
    const empty = create('div', 'No tasks yet').use('muted');
    empty.style = 'text-center p-6';
    listBox.push(empty);
    return;
  }

  for (let i = 0; i < tasks.length; i++) {
    const t = tasks[i];

    const rowEl = create('div');
    rowEl.style = 'bg-white rounded-2xl p-4 shadow-sm flex items-center gap-3';

    const checkBtn = iconBtn(t.done ? 'check' : 'x');
    checkBtn.addClass(t.done ? 'text-green-500' : 'text-gray-400');

    const label = create('div', t.text);
    label.style = 'flex-1 ' + (t.done ? 'line-through text-gray-400' : 'text-black font-medium');

    const delBtn = iconBtn('trash', 'text-red-500');

    checkBtn.onClick = () => {
      tasks[i].done = !tasks[i].done;
      renderTasks();
    };

    delBtn.onClick = () => {
      tasks.splice(i, 1);
      renderTasks();
    };

    rowEl.push(checkBtn, label, delBtn);
    listBox.push(rowEl);
  }
}

// add task row
const addRow = create('div');
addRow.style = 'flex flex-row items-center gap-2';

const newInput = inputBox('Add a task...');
newInput.addClass('flex-1');

const addBtn = iconBtn('plus', 'bg-blue-500 text-white');

addBtn.onClick = () => {
  const text = newInput.value.trim();
  if (!text) return;
  tasks.push({ text, done: false });
  newInput.value = '';
  renderTasks();
};

newInput.on('keydown', (e) => {
  if (e.key === 'Enter') addBtn.el.click();
});

addRow.push(newInput, addBtn);

// assemble home
home.push(homeHeader, searchBar, addRow, listBox);

// ============================================================
//  SCREEN: EXPLORE
// ============================================================
const explore = create('div');
explore.id = 'explore';
explore.style = 'p-4 flex flex-col gap-4';

const exploreTitle = create('h1', 'Explore').use('title');

const chipsRow = scrollX(
  chip('All', true),
  chip('Work', false),
  chip('Home', false),
  chip('Ideas', false)
);

const cards = scrollX(
  miniCard('Project A'),
  miniCard('Project B'),
  miniCard('Project C')
);

const exploreCard = create('div').use('card');
exploreCard.push(
  create('div', 'Featured').use('subtitle'),
  create('div', 'Try the new task filter').use('muted'),
  chipsRow,
  cards
);

explore.push(exploreTitle, exploreCard);

// ============================================================
//  SCREEN: PROFILE
// ============================================================
const profile = create('div');
profile.id = 'profile';
profile.style = 'p-4 flex flex-col gap-4';

const profileTitle = create('h1', 'Profile').use('title');

// avatar + name
const profileTop = create('div').use('card');
profileTop.push(
  avatar('https://i.pravatar.cc/100?img=12'),
  create('div', 'Sam').use('subtitle'),
  create('div', 'sam@example.com').use('muted')
);

// toggles
const settingsCard = create('div').use('card');

const darkToggle  = toggleIconBtn('star',  'text-yellow-500');
const notifToggle = toggleIconBtn('bell',  'text-blue-500');
const favToggle   = toggleIconBtn('heart', 'text-red-500');

const toggleRow = create('div');
toggleRow.style = 'flex flex-row items-center justify-between gap-4 p-2';
toggleRow.push(
  create('div', 'Notifications').use('body'),
  notifToggle
);

const darkRow = create('div');
darkRow.style = 'flex flex-row items-center justify-between gap-4 p-2';
darkRow.push(
  create('div', 'Dark mode').use('body'),
  darkToggle
);

const favRow = create('div');
favRow.style = 'flex flex-row items-center justify-between gap-4 p-2';
favRow.push(
  create('div', 'Favorite').use('body'),
  favToggle
);

settingsCard.push(
  create('div', 'Settings').use('subtitle'),
  toggleRow,
  darkRow,
  favRow
);

const logoutBtn = create('button', 'Log out').use('danger');
logoutBtn.addClass('w-full');

profile.push(profileTitle, profileTop, settingsCard, logoutBtn);

// ============================================================
//  BOTTOM NAV
// ============================================================
const nav = create('div');
nav.style = 'fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-2';

function navItem(name, label, target, active) {
  const item = create('div');
  item.style = 'flex flex-col items-center gap-1 px-4 py-1';
  item.addClass(active ? 'text-blue-500' : 'text-gray-400');

  const ic = svg(name, 'w-6 h-6');
  const t  = create('div', label);
  t.style = 'text-xs font-medium';

  item.push(ic, t);
  item.onClick = () => {
    route(target);
    updateNav(target);
  };
  return item;
}

const navItems = {};

function updateNav(target) {
  for (const k in navItems) {
    navItems[k].removeClass('text-blue-500');
    navItems[k].addClass('text-gray-400');
  }
  if (navItems[target]) {
    navItems[target].removeClass('text-gray-400');
    navItems[target].addClass('text-blue-500');
  }
}

navItems.home    = navItem('home',   'Home',    'home',    true);
navItems.explore = navItem('search', 'Explore', 'explore', false);
navItems.profile = navItem('user',   'Profile', 'profile', false);

nav.push(navItems.home, navItems.explore, navItems.profile);

// ============================================================
//  BOOT
// ============================================================
renderTasks();
root.push(home, explore, profile, nav);
route('home');