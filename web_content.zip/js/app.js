/**
 * DailyTracker — Professional PWA
 * Modular, accessible, offline-capable
 */

// ===================== STATE =====================
const PRAYERS = ['Fajr', 'Zuhr', 'Asr', 'Maghrib', 'Isha'];
const STORAGE_KEY = 'dt_v3';
const today = () => new Date().toISOString().split('T')[0];

const defaultState = () => ({
  user: '',
  prayers: {},
  nafl: [],
  dhikrList: [],
  tasks: [],
  work: [],
  courses: [],
  transactions: [],
  settings: {
    currency: '₨',
    darkMode: null, // null = auto
    soundEnabled: true,
    hapticEnabled: true,
    weekStart: 1, // Monday
  },
  streaks: {
    prayerStreak: 0,
    lastPrayerDate: null,
    dhikrStreak: 0,
    lastDhikrDate: null,
  }
});

let state = defaultState();
let timerSec = 0, timerRunning = false, timerInterval = null;
let currentScreen = 'dash';

// ===================== UTILITIES =====================
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const on = (el, evt, fn, opts = {}) => el.addEventListener(evt, fn, opts);

function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function formatNumber(n) {
  return Math.round(n).toLocaleString();
}

function formatCurrency(amount) {
  const sym = state.settings?.currency || '₨';
  return sym + formatNumber(amount);
}

function formatTime(sec) {
  const h = String(Math.floor(sec / 3600)).padStart(2, '0');
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
  const s = String(sec % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function formatDate(d) {
  return new Date(d).toLocaleDateString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric'
  });
}

function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n));
}

function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ===================== ICONS =====================
const icons = {
  check: '<svg class="icon" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
  trash: '<svg class="icon" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
  bell: '<svg class="icon" viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
  download: '<svg class="icon" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
  upload: '<svg class="icon" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
  moon: '<svg class="icon" viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
  sun: '<svg class="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
  settings: '<svg class="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.67 15 1.65 1.65 0 0 0 3 13.51V13a2 2 0 0 1 2-2 1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  chart: '<svg class="icon" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
  export: '<svg class="icon" viewBox="0 0 24 24"><polyline points="7 13 12 18 17 13"/><polyline points="7 6 12 11 17 6"/></svg>',
};

// ===================== PERSISTENCE =====================
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      state = { ...defaultState(), ...parsed };
      // Ensure nested defaults exist
      state.settings = { ...defaultState().settings, ...state.settings };
      state.streaks = { ...defaultState().streaks, ...state.streaks };
    }
  } catch (e) {
    console.error('Failed to load state', e);
  }
  const t = today();
  if (!state.prayers[t]) state.prayers[t] = {};
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save state', e);
  }
}

const saveStateDebounced = debounce(saveState, 300);

// ===================== TOASTS =====================
function showToast(message, type = 'info', duration = 2500) {
  let container = $('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `${message}`;
  container.appendChild(toast);

  if (state.settings?.hapticEnabled && navigator.vibrate) {
    navigator.vibrate(type === 'error' ? [50, 30, 50] : 40);
  }

  setTimeout(() => {
    toast.classList.add('toast-out');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ===================== NAVIGATION =====================
function nav(id, push = true) {
  currentScreen = id;
  $$('.screen').forEach(s => s.classList.remove('active'));
  $$('.navbtn').forEach(b => b.classList.remove('active'));
  const screen = $(`#screen-${id}`);
  const btn = $(`#nav-${id}`);
  if (screen) screen.classList.add('active');
  if (btn) btn.classList.add('active');

  // Update URL hash without scrolling
  if (push && window.history) {
    window.history.replaceState(null, '', `#${id}`);
  }

  // Refresh screen-specific renders
  if (id === 'dash') renderDash();
  if (id === 'prayer') { renderPrayers(); renderNafl(); renderMonthlySummary(); }
  if (id === 'dhikr') renderDhikr();
  if (id === 'tasks') renderTasks();
  if (id === 'work') renderWork();
  if (id === 'courses') renderCourses();
  if (id === 'finance') renderFinance();

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function handleHash() {
  const hash = window.location.hash.replace('#', '');
  const valid = ['dash','prayer','dhikr','tasks','work','courses','finance','settings'];
  if (valid.includes(hash)) nav(hash, false);
}

// ===================== USER =====================
function showUserModal() {
  const modal = $('#user-modal');
  if (modal) modal.classList.add('show');
  const input = $('#user-name-input');
  if (input) { input.value = state.user || ''; input.focus(); }
}

function hideUserModal() {
  const modal = $('#user-modal');
  if (modal) modal.classList.remove('show');
}

function saveUser() {
  const input = $('#user-name-input');
  const v = input?.value.trim();
  if (!v) {
    showToast('Please enter your name', 'error');
    return;
  }
  state.user = v;
  const badge = $('#userBadge');
  if (badge) badge.textContent = v;
  hideUserModal();
  saveState();
  renderDash();
  showToast(`Welcome, ${v}!`, 'success');
}

// ===================== DASHBOARD =====================
function renderDash() {
  const t = today();
  const pd = state.prayers[t] || {};

  // Prayer mini
  const dashPrayers = $('#dash-prayers');
  if (dashPrayers) {
    dashPrayers.innerHTML = PRAYERS.map(p => {
      const st = pd[p];
      const cls = st === 'done' ? 'done' : st === 'missed' ? 'missed' : '';
      return `<div class="mini-p ${cls}" title="${p}: ${st || 'pending'}">${p.substring(0, 2)}</div>`;
    }).join('');
  }

  // Dhikr summary
  const dl = $('#dash-dhikr');
  if (dl) {
    if (!state.dhikrList.length) {
      dl.innerHTML = '<span style="color:var(--text-2);font-size:13px">No dhikr added yet</span>';
    } else {
      const done = state.dhikrList.filter(d => {
        const cur = d.lastDate === t ? (d.today || 0) : 0;
        return cur >= d.target;
      }).length;
      dl.innerHTML = `<span style="font-size:24px;font-weight:800;color:var(--accent)">${done}</span><span style="color:var(--text-2);font-size:12px;margin-left:6px">/ ${state.dhikrList.length} targets reached today</span>`;
    }
  }

  // Tasks
  const pending = state.tasks.filter(t => !t.done).length;
  const dashTasks = $('#dash-tasks');
  if (dashTasks) dashTasks.textContent = pending;

  // Balance
  const bal = state.transactions.reduce((a, tr) => tr.type === 'income' ? a + tr.amount : a - tr.amount, 0);
  const dashBal = $('#dash-balance');
  if (dashBal) dashBal.textContent = formatCurrency(bal);

  // Work today
  const todayWork = state.work.filter(w => w.date === t);
  let wh = 0;
  todayWork.forEach(w => {
    if (w.start && w.end) {
      const [sh, sm] = w.start.split(':').map(Number);
      const [eh, em] = w.end.split(':').map(Number);
      wh += (eh * 60 + em - sh * 60 - sm) / 60;
    }
  });
  const dashWork = $('#dash-work');
  if (dashWork) dashWork.textContent = wh.toFixed(1) + 'h';

  // Study this week
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const wkMins = state.courses
    .filter(c => new Date(c.date) >= weekAgo)
    .reduce((a, c) => a + (Number(c.duration) || 0), 0);
  const dashCourses = $('#dash-courses');
  if (dashCourses) dashCourses.textContent = (wkMins / 60).toFixed(1) + 'h';

  // Streak
  const streakEl = $('#dash-streak');
  if (streakEl) {
    streakEl.innerHTML = `🔥 ${state.streaks.prayerStreak} day streak`;
  }
}

// ===================== PRAYERS =====================
function renderPrayers() {
  const dateEl = $('#prayer-date');
  if (dateEl) {
    dateEl.textContent = new Date().toLocaleDateString('en-US', {
      weekday: 'long', month: 'short', day: 'numeric', year: 'numeric'
    });
  }
  const t = today();
  const pd = state.prayers[t] || {};
  const grid = $('#prayer-grid');
  if (!grid) return;

  grid.innerHTML = PRAYERS.map(p => {
    const st = pd[p];
    const cls = st === 'done' ? 'done' : st === 'missed' ? 'missed' : '';
    const ico = st === 'done' ? '✓' : st === 'missed' ? '✗' : '○';
    const label = st === 'done' ? 'Prayed' : st === 'missed' ? 'Missed' : 'Pending';
    return `<button class="prayer-btn ${cls}" onclick="togglePrayer('${p}')" aria-label="${p}: ${label}">
      <span>${p}</span>
      <span class="status-icon">${ico}</span>
    </button>`;
  }).join('');
}

function togglePrayer(p) {
  const t = today();
  const pd = state.prayers[t];
  const cur = pd[p];
  // Cycle: undefined -> done -> missed -> undefined
  pd[p] = cur === 'done' ? 'missed' : cur === 'missed' ? undefined : 'done';
  if (!pd[p]) delete pd[p];

  updateStreaks();
  saveState();
  renderPrayers();
  renderDash();
  renderMonthlySummary();
  showToast(`${p} marked ${pd[p] || 'pending'}`, pd[p] === 'done' ? 'success' : 'info');
}

function updateStreaks() {
  const t = today();
  const pd = state.prayers[t] || {};
  const allDone = PRAYERS.every(p => pd[p] === 'done');

  if (allDone) {
    const last = state.streaks.lastPrayerDate;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = yesterday.toISOString().split('T')[0];

    if (last === yStr || last === t) {
      if (last !== t) state.streaks.prayerStreak++;
    } else {
      state.streaks.prayerStreak = 1;
    }
    state.streaks.lastPrayerDate = t;
  }
}

// ===================== NAFL =====================
function addNafl() {
  const sel = $('#nafl-select');
  const cnt = $('#nafl-count');
  const name = sel?.value || 'Other Nafl';
  const count = clamp(parseInt(cnt?.value) || 2, 1, 100);

  state.nafl.push({ id: generateId(), name, count, date: today() });
  if (cnt) cnt.value = '';
  saveState();
  renderNafl();
  renderMonthlySummary();
  showToast(`${name} (${count} raka'at) added`, 'success');
}

function renderNafl() {
  const list = state.nafl.filter(n => n.date === today());
  const el = $('#nafl-list');
  if (!el) return;
  el.innerHTML = list.length
    ? list.map(n => `<div class="nafl-item">
        <span>${escapeHtml(n.name)}</span>
        <span class="badge badge-g">${n.count} raka'at</span>
        <button class="del-btn tooltip" data-tip="Remove" onclick="removeNafl('${n.id}')">${icons.trash}</button>
      </div>`).join('')
    : '<p class="empty" style="padding:6px 0">No nafl logged today</p>';
}

function removeNafl(id) {
  state.nafl = state.nafl.filter(n => n.id !== id);
  saveState();
  renderNafl();
  renderMonthlySummary();
  showToast('Nafl removed', 'info');
}

// ===================== MONTHLY SUMMARY =====================
function renderMonthlySummary() {
  const month = today().substring(0, 7);
  let done = 0, missed = 0, naflCount = 0;

  Object.keys(state.prayers).filter(d => d.startsWith(month)).forEach(d => {
    PRAYERS.forEach(p => {
      if (state.prayers[d][p] === 'done') done++;
      else if (state.prayers[d][p] === 'missed') missed++;
    });
  });

  naflCount = state.nafl.filter(n => n.date && n.date.startsWith(month)).length;
  const total = done + missed;
  const pct = Math.round(done / Math.max(1, total) * 100);

  const el = $('#monthly-stats');
  if (!el) return;

  // Build mini bar chart for last 7 days
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().split('T')[0];
    const pd = state.prayers[ds] || {};
    const dDone = PRAYERS.filter(p => pd[p] === 'done').length;
    days.push({ date: ds, label: d.getDate(), done: dDone });
  }

  const maxDone = 5;

  el.innerHTML = `
    <div class="stat-row">
      <div class="stat"><div class="stat-val" style="color:var(--success)">${done}</div><div class="stat-lbl">Prayed</div></div>
      <div class="stat"><div class="stat-val" style="color:var(--danger)">${missed}</div><div class="stat-lbl">Missed</div></div>
      <div class="stat"><div class="stat-val" style="color:var(--accent)">${naflCount}</div><div class="stat-lbl">Nafl</div></div>
      <div class="stat"><div class="stat-val">${pct}%</div><div class="stat-lbl">Rate</div></div>
    </div>
    <div class="card card-highlight">
      <div class="sect-title">${icons.chart} Last 7 Days</div>
      <div class="chart-bar-container">
        ${days.map(d => `
          <div class="chart-bar" style="height:${(d.done / maxDone * 100)}%">
            <span class="chart-bar-value">${d.done}</span>
            <span class="chart-bar-label">${d.label}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

// ===================== DHIKR =====================
function addDhikr() {
  const nEl = $('#dhikr-name');
  const tEl = $('#dhikr-target');
  const name = nEl?.value.trim();
  const target = clamp(parseInt(tEl?.value) || 33, 1, 100000);
  if (!name) {
    showToast('Enter a dhikr name', 'error');
    return;
  }
  state.dhikrList.push({
    id: generateId(),
    name,
    target,
    today: 0,
    total: 0,
    lastDate: today()
  });
  if (nEl) nEl.value = '';
  if (tEl) tEl.value = '';
  saveState();
  renderDhikr();
  renderDash();
  showToast(`"${name}" added with target ${target}`, 'success');
}

function tapDhikr(id) {
  const d = state.dhikrList.find(x => x.id === id);
  if (!d) return;
  const t = today();
  if (d.lastDate !== t) { d.today = 0; d.lastDate = t; }
  d.today = (d.today || 0) + 1;
  saveState();
  renderDhikr();
  renderDash();

  if (d.today === d.target) {
    showToast(`🎉 Target reached for ${d.name}!`, 'success');
    if (state.settings?.hapticEnabled && navigator.vibrate) navigator.vibrate([30, 40, 30, 40, 30]);
  }
}

function commitDhikr() {
  const t = today();
  let added = 0;
  state.dhikrList.forEach(d => {
    const val = d.today || 0;
    if (val > 0) {
      d.total = (d.total || 0) + val;
      added += val;
    }
    d.today = 0;
    d.lastDate = t;
  });
  saveState();
  renderDhikr();
  renderDash();
  showToast(`${added} counts saved to all-time totals`, 'success');
}

function removeDhikr(id) {
  state.dhikrList = state.dhikrList.filter(x => x.id !== id);
  saveState();
  renderDhikr();
  renderDash();
  showToast('Dhikr removed', 'info');
}

function renderDhikr() {
  const el = $('#dhikr-list');
  if (!el) return;
  const t = today();
  el.innerHTML = state.dhikrList.length
    ? state.dhikrList.map(d => {
        const cur = d.lastDate === t ? (d.today || 0) : 0;
        const pct = Math.min(100, Math.round(cur / d.target * 100));
        const reached = cur >= d.target;
        return `<div class="dhikr-item">
          <div class="dhikr-name">
            <span>${escapeHtml(d.name)} ${reached ? '✓' : ''}</span>
            <button class="del-btn tooltip" data-tip="Remove" onclick="removeDhikr('${d.id}')">${icons.trash}</button>
          </div>
          <div class="dhikr-counts">Today: <strong>${cur}</strong> / ${d.target} · All-time: <strong>${formatNumber(d.total || 0)}</strong></div>
          <div class="dhikr-actions">
            <button class="tap-btn ${reached ? 'success' : ''}" onclick="tapDhikr('${d.id}')">+ Tap</button>
          </div>
          <div class="progress-bar"><div class="progress-fill ${pct >= 100 ? 'done-fill' : ''}" style="width:${pct}%"></div></div>
        </div>`;
      }).join('')
    : '<div class="empty"><div class="empty-icon">📿</div>Add your first dhikr above</div>';
}

// ===================== TASKS =====================
function addTask() {
  const tEl = $('#task-input');
  const nEl = $('#task-note');
  const text = tEl?.value.trim();
  const note = nEl?.value.trim();
  if (!text) {
    showToast('Enter a task', 'error');
    return;
  }
  state.tasks.unshift({ id: generateId(), text, note, done: false, createdAt: new Date().toISOString() });
  if (tEl) tEl.value = '';
  if (nEl) nEl.value = '';
  saveState();
  renderTasks();
  renderDash();
  showToast('Task added', 'success');
}

function toggleTask(id) {
  const t = state.tasks.find(x => x.id === id);
  if (!t) return;
  t.done = !t.done;
  t.completedAt = t.done ? new Date().toISOString() : null;
  saveState();
  renderTasks();
  renderDash();
  showToast(t.done ? 'Task completed!' : 'Task reopened', t.done ? 'success' : 'info');
}

function deleteTask(id) {
  state.tasks = state.tasks.filter(x => x.id !== id);
  saveState();
  renderTasks();
  renderDash();
  showToast('Task deleted', 'info');
}

function renderTasks() {
  const pendingEl = $('#tasks-pending');
  const doneEl = $('#tasks-done');
  if (!pendingEl || !doneEl) return;

  const renderItem = t => `<div class="task-item">
    <div class="task-check ${t.done ? 'done' : ''}" onclick="toggleTask('${t.id}')" role="button" aria-label="Toggle task" tabindex="0">
      ${t.done ? icons.check : ''}
    </div>
    <div class="flex-1">
      <div class="task-text ${t.done ? 'done' : ''}">${escapeHtml(t.text)}</div>
      ${t.note ? `<div class="task-note">${escapeHtml(t.note)}</div>` : ''}
    </div>
    <button class="del-btn tooltip" data-tip="Delete" onclick="deleteTask('${t.id}')">${icons.trash}</button>
  </div>`;

  const pending = state.tasks.filter(t => !t.done);
  const done = state.tasks.filter(t => t.done).slice(0, 8);

  pendingEl.innerHTML = pending.length ? pending.map(renderItem).join('') : '<p class="empty"><div class="empty-icon">🎉</div>All done!</p>';
  doneEl.innerHTML = done.length ? done.map(renderItem).join('') : '<p class="empty">No completed tasks yet</p>';
}

// ===================== WORK =====================
function addWork() {
  const label = $('#work-label')?.value.trim();
  const date = $('#work-date')?.value || today();
  const start = $('#work-start')?.value;
  const end = $('#work-end')?.value;
  if (!label) {
    showToast('Enter a work label', 'error');
    return;
  }
  if (start && end) {
    const [sh, sm] = start.split(':').map(Number);
    const [eh, em] = end.split(':').map(Number);
    if (eh * 60 + em <= sh * 60 + sm) {
      showToast('End time must be after start time', 'error');
      return;
    }
  }
  state.work.unshift({ id: generateId(), label, date, start, end });
  $('#work-label').value = '';
  saveState();
  renderWork();
  renderDash();
  showToast('Work entry added', 'success');
}

function removeWork(id) {
  state.work = state.work.filter(w => w.id !== id);
  saveState();
  renderWork();
  renderDash();
  showToast('Work entry removed', 'info');
}

function renderWork() {
  const el = $('#work-list');
  if (!el) return;
  const items = state.work.slice(0, 20).map(w => {
    let hrs = 0;
    if (w.start && w.end) {
      const [sh, sm] = w.start.split(':').map(Number);
      const [eh, em] = w.end.split(':').map(Number);
      hrs = (eh * 60 + em - sh * 60 - sm) / 60;
    }
    const pct = Math.min(100, Math.round((hrs / 8) * 100));
    return `<div class="work-item">
      <div>
        <div class="work-label">${escapeHtml(w.label)}</div>
        <div class="work-time">${formatDate(w.date)}${w.start ? ' · ' + w.start + ' – ' + w.end : ''}</div>
      </div>
      <div style="text-align:right">
        ${hrs > 0 ? `<div class="work-pct">${hrs.toFixed(1)}h</div><div style="font-size:10px;color:var(--text-3)">${pct}% of 8h</div>` : '<div style="font-size:11px;color:var(--text-3)">No duration</div>'}
        <button class="del-btn tooltip" data-tip="Remove" onclick="removeWork('${w.id}')">${icons.trash}</button>
      </div>
    </div>`;
  }).join('');
  el.innerHTML = items || '<p class="empty"><div class="empty-icon">⏰</div>No work entries yet</p>';
}

function requestNotif() {
  if (!('Notification' in window)) {
    showToast('Notifications not supported', 'error');
    return;
  }
  Notification.requestPermission().then(p => {
    if (p === 'granted') {
      showToast('Reminders enabled!', 'success');
    } else {
      showToast('Enable notifications in browser settings', 'error');
    }
  });
}

// ===================== TIMER & COURSES =====================
function toggleTimer() {
  if (!timerRunning) {
    timerRunning = true;
    const cn = $('#course-name')?.value.trim();
    $('#timer-course-name').textContent = cn || 'Session in progress';
    const btn = $('#timer-btn');
    btn.textContent = 'Pause';
    btn.className = 't-btn stop';
    timerInterval = setInterval(() => {
      timerSec++;
      $('#timer-display').textContent = formatTime(timerSec);
    }, 1000);
  } else {
    timerRunning = false;
    clearInterval(timerInterval);
    const btn = $('#timer-btn');
    btn.textContent = 'Resume';
    btn.className = 't-btn start';
    if (timerSec > 60) {
      const dur = $('#course-duration');
      if (dur) dur.value = Math.round(timerSec / 60);
    }
  }
}

function resetTimer() {
  clearInterval(timerInterval);
  timerRunning = false;
  timerSec = 0;
  $('#timer-display').textContent = '00:00:00';
  const btn = $('#timer-btn');
  btn.textContent = 'Start';
  btn.className = 't-btn start';
  $('#timer-course-name').textContent = 'No course selected';
}

function addCourse() {
  const name = $('#course-name')?.value.trim();
  const platform = $('#course-platform')?.value.trim();
  const date = $('#course-date')?.value || today();
  const duration = clamp(parseInt($('#course-duration')?.value) || 0, 0, 10000);
  if (!name) {
    showToast('Enter a course name', 'error');
    return;
  }
  state.courses.unshift({ id: generateId(), name, platform, date, duration });
  $('#course-name').value = '';
  $('#course-platform').value = '';
  $('#course-duration').value = '';
  resetTimer();
  saveState();
  renderCourses();
  renderDash();
  showToast('Session logged', 'success');
}

function removeCourse(id) {
  state.courses = state.courses.filter(c => c.id !== id);
  saveState();
  renderCourses();
  renderDash();
  showToast('Session removed', 'info');
}

function renderCourses() {
  const el = $('#course-list');
  if (!el) return;
  const totals = {};
  state.courses.forEach(c => {
    totals[c.name] = (totals[c.name] || 0) + (c.duration || 0);
  });
  el.innerHTML = state.courses.slice(0, 20).map(c =>
    `<div class="course-item">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div class="course-name">${escapeHtml(c.name)}</div>
        <div style="display:flex;gap:8px;align-items:center">
          <span class="badge badge-b">${c.duration}m</span>
          <button class="del-btn tooltip" data-tip="Remove" onclick="removeCourse('${c.id}')">${icons.trash}</button>
        </div>
      </div>
      <div class="course-meta">${formatDate(c.date)}${c.platform ? ' · ' + escapeHtml(c.platform) : ''} · Total: ${(totals[c.name] / 60).toFixed(1)}h</div>
    </div>`
  ).join('') || '<p class="empty"><div class="empty-icon">📚</div>No sessions logged yet</p>';
}

// ===================== FINANCE =====================
function addTransaction() {
  const type = $('#txn-type')?.value;
  const amount = parseFloat($('#txn-amount')?.value) || 0;
  const person = $('#txn-person')?.value.trim();
  const category = $('#txn-category')?.value.trim();
  const date = $('#txn-date')?.value || today();
  const time = $('#txn-time')?.value;
  const notes = $('#txn-notes')?.value.trim();
  if (!amount || amount <= 0) {
    showToast('Enter a valid amount', 'error');
    return;
  }
  state.transactions.unshift({
    id: generateId(), type, amount, person, category, date, time, notes
  });
  $('#txn-amount').value = '';
  $('#txn-person').value = '';
  $('#txn-notes').value = '';
  saveState();
  renderFinance();
  renderDash();
  showToast(`${type === 'income' ? 'Income' : 'Expense'} added`, 'success');
}

function removeTxn(id) {
  state.transactions = state.transactions.filter(t => t.id !== id);
  saveState();
  renderFinance();
  renderDash();
  showToast('Transaction removed', 'info');
}

function renderFinance() {
  const inc = state.transactions.filter(t => t.type === 'income').reduce((a, t) => a + t.amount, 0);
  const exp = state.transactions.filter(t => t.type === 'expense').reduce((a, t) => a + t.amount, 0);
  const bal = inc - exp;

  $('#balance-val').textContent = formatCurrency(bal);
  $('#total-in').textContent = formatCurrency(inc);
  $('#total-out').textContent = formatCurrency(exp);

  const list = $('#txn-list');
  if (!list) return;
  list.innerHTML = state.transactions.slice(0, 25).map(t =>
    `<div class="ledger-item">
      <div style="flex:1">
        <div class="ledger-desc">${escapeHtml(t.person || (t.type === 'income' ? 'Income' : 'Expense'))}</div>
        <div class="ledger-meta">${formatDate(t.date)}${t.time ? ' · ' + t.time : ''}${t.category ? ' · ' + escapeHtml(t.category) : ''}${t.notes ? ' · ' + escapeHtml(t.notes) : ''}</div>
      </div>
      <div style="display:flex;align-items:center;gap:10px">
        <div class="ledger-amt ${t.type}">${t.type === 'income' ? '+' : '-'}${formatCurrency(t.amount)}</div>
        <button class="del-btn tooltip" data-tip="Remove" onclick="removeTxn('${t.id}')">${icons.trash}</button>
      </div>
    </div>`
  ).join('') || '<p class="empty"><div class="empty-icon">💰</div>No transactions yet</p>';
}

// ===================== SETTINGS =====================
function renderSettings() {
  const el = $('#settings-content');
  if (!el) return;
  el.innerHTML = `
    <div class="card">
      <div class="sect-title">${icons.settings} Appearance</div>
      <div class="input-row" style="align-items:center">
        <label style="font-size:13px;font-weight:600;flex:1">Dark Mode</label>
        <select id="setting-darkmode" onchange="updateSetting('darkMode', this.value)">
          <option value="auto" ${state.settings.darkMode === null ? 'selected' : ''}>Auto</option>
          <option value="dark" ${state.settings.darkMode === true ? 'selected' : ''}>Dark</option>
          <option value="light" ${state.settings.darkMode === false ? 'selected' : ''}>Light</option>
        </select>
      </div>
    </div>
    <div class="card">
      <div class="sect-title">${icons.settings} Preferences</div>
      <div class="input-row" style="align-items:center;margin-bottom:8px">
        <label style="font-size:13px;font-weight:600;flex:1">Currency Symbol</label>
        <input type="text" id="setting-currency" value="${escapeHtml(state.settings.currency || '₨')}" style="width:80px;text-align:center" onchange="updateSetting('currency', this.value)">
      </div>
      <div class="input-row" style="align-items:center;margin-bottom:8px">
        <label style="font-size:13px;font-weight:600;flex:1">Haptic Feedback</label>
        <select id="setting-haptic" onchange="updateSetting('hapticEnabled', this.value === 'true')">
          <option value="true" ${state.settings.hapticEnabled ? 'selected' : ''}>On</option>
          <option value="false" ${!state.settings.hapticEnabled ? 'selected' : ''}>Off</option>
        </select>
      </div>
    </div>
    <div class="card">
      <div class="sect-title">${icons.download} Data</div>
      <div class="data-actions">
        <button class="add-btn" onclick="exportData()">${icons.download} Export JSON</button>
        <button class="add-btn secondary" onclick="document.getElementById('import-file').click()">${icons.upload} Import JSON</button>
        <input type="file" id="import-file" accept=".json" style="display:none" onchange="importData(this)">
        <button class="add-btn danger" onclick="clearAllData()">${icons.trash} Clear All</button>
      </div>
    </div>
  `;
  applyTheme();
}

function updateSetting(key, value) {
  state.settings[key] = value;
  saveState();
  if (key === 'darkMode') applyTheme();
  if (key === 'currency') renderFinance();
  showToast('Setting saved', 'success');
}

function applyTheme() {
  const dm = state.settings.darkMode;
  if (dm === true) document.documentElement.classList.add('force-dark');
  else if (dm === false) document.documentElement.classList.add('force-light');
  else {
    document.documentElement.classList.remove('force-dark', 'force-light');
  }
}

function exportData() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `dailytracker-backup-${today()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('Data exported', 'success');
}

function importData(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (!data.prayers || !Array.isArray(data.tasks)) throw new Error('Invalid file');
      state = { ...defaultState(), ...data };
      state.settings = { ...defaultState().settings, ...state.settings };
      saveState();
      location.reload();
    } catch (e) {
      showToast('Invalid backup file', 'error');
    }
  };
  reader.readAsText(file);
}

function clearAllData() {
  if (!confirm('Are you sure? This will erase ALL data permanently.')) return;
  localStorage.removeItem(STORAGE_KEY);
  showToast('All data cleared. Reloading...', 'info');
  setTimeout(() => location.reload(), 1200);
}

// ===================== INIT =====================
function init() {
  loadState();

  // Apply theme
  applyTheme();

  // Set default dates
  const t = today();
  const wd = $('#work-date'); if (wd) wd.value = t;
  const cd = $('#course-date'); if (cd) cd.value = t;
  const td = $('#txn-date'); if (td) td.value = t;

  // Wire course name -> timer label
  const cn = $('#course-name');
  if (cn) {
    cn.addEventListener('input', () => {
      const el = $('#timer-course-name');
      if (el) el.textContent = cn.value.trim() || 'No course selected';
    });
  }

  // Enter key handlers
  $('#task-input')?.addEventListener('keypress', e => { if (e.key === 'Enter') addTask(); });
  $('#dhikr-name')?.addEventListener('keypress', e => { if (e.key === 'Enter') addDhikr(); });
  $('#user-name-input')?.addEventListener('keypress', e => { if (e.key === 'Enter') saveUser(); });

  // Hash navigation
  on(window, 'hashchange', handleHash);
  handleHash();

  // User badge
  const badge = $('#userBadge');
  if (badge) badge.textContent = state.user || 'Set Name';

  // Initial renders
  renderDash();
  renderPrayers();
  renderNafl();
  renderMonthlySummary();
  renderDhikr();
  renderTasks();
  renderWork();
  renderCourses();
  renderFinance();
  renderSettings();

  // Show welcome modal if no user
  if (!state.user) {
    setTimeout(showUserModal, 500);
  }

  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }

  // Before unload: save timer if running
  on(window, 'beforeunload', () => {
    if (timerRunning) {
      // Optionally auto-save timer state here
    }
  });
}

// Start
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
