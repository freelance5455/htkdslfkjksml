/* =================================
   GAMEHUB - MAIN APP
   ================================= */


/* =================================
   APP START
   ================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const data =
            GameHubStorage.getData();

        applySettings(data);

        updateDashboard(data);

    }
);



/* =================================
   APPLY SETTINGS
   ================================= */

function applySettings(data) {

    if (
        data.settings &&
        data.settings.darkMode === false
    ) {

        document.body.classList.add(
            "light-mode"
        );

    }

    else {

        document.body.classList.remove(
            "light-mode"
        );

    }

}



/* =================================
   GAMEHUB SOUND SYSTEM
   ================================= */

function playGameSound(
    type = "click"
) {


    /* STORAGE CHECK */

    if (
        typeof GameHubStorage ===
        "undefined"
    ) {

        return;

    }


    /* SOUND SETTING CHECK */

    if (
        !GameHubStorage.isSoundEnabled()
    ) {

        return;

    }


    try {


        const AudioContext =
            window.AudioContext ||
            window.webkitAudioContext;


        if (!AudioContext) {

            return;

        }


        const audioContext =
            new AudioContext();


        const oscillator =
            audioContext.createOscillator();


        const gainNode =
            audioContext.createGain();



        /* ==============================
           SOUND TYPES
           ============================== */

        const soundSettings = {


            click: {

                frequency: 500,

                duration: 0.08

            },


            success: {

                frequency: 700,

                duration: 0.15

            },


            error: {

                frequency: 180,

                duration: 0.15

            },


            win: {

                frequency: 850,

                duration: 0.20

            }

        };



        const selectedSound =
            soundSettings[type] ||
            soundSettings.click;



        /* FREQUENCY */

        oscillator.frequency.value =
            selectedSound.frequency;



        /* SOUND TYPE */

        oscillator.type =
            "sine";



        /* VOLUME */

        gainNode.gain.setValueAtTime(
            0.08,
            audioContext.currentTime
        );


        gainNode.gain.exponentialRampToValueAtTime(
            0.001,
            audioContext.currentTime +
            selectedSound.duration
        );



        /* CONNECT */

        oscillator.connect(
            gainNode
        );


        gainNode.connect(
            audioContext.destination
        );



        /* PLAY */

        oscillator.start();


        oscillator.stop(
            audioContext.currentTime +
            selectedSound.duration
        );



        /* CLOSE AUDIO */

        oscillator.onended =
            function () {

                audioContext.close();

            };


    }

    catch (error) {

        console.log(
            "GameHub sound unavailable:",
            error
        );

    }

}



/* =================================
   UPDATE DASHBOARD
   ================================= */

function updateDashboard(data) {


    /* ==============================
       BASIC ELEMENTS
       ============================== */

    const totalScoreElement =
        document.getElementById(
            "totalScore"
        );


    const playerLevelElement =
        document.getElementById(
            "playerLevel"
        );


    const gamesPlayedElement =
        document.getElementById(
            "gamesPlayed"
        );



    /* ==============================
       XP ELEMENTS
       ============================== */

    const currentXPElement =
        document.getElementById(
            "currentXP"
        );


    const nextLevelXPElement =
        document.getElementById(
            "nextLevelXP"
        );


    const xpProgressBar =
        document.getElementById(
            "xpProgressBar"
        );


    const xpProgressText =
        document.getElementById(
            "xpProgressText"
        );



    /* ==============================
       RECENT GAMES
       ============================== */

    const recentGamesElement =
        document.getElementById(
            "recentGames"
        );



    /* ==============================
       ACHIEVEMENTS
       ============================== */

    const achievementCountElement =
        document.getElementById(
            "achievementCount"
        );


    const totalAchievementCountElement =
        document.getElementById(
            "totalAchievementCount"
        );


    const achievementMessageElement =
        document.getElementById(
            "achievementMessage"
        );



    /* ==============================
       BASIC STATISTICS
       ============================== */

    if (totalScoreElement) {

        totalScoreElement.textContent =
            data.totalScore;

    }


    if (playerLevelElement) {

        playerLevelElement.textContent =
            data.level;

    }


    if (gamesPlayedElement) {

        gamesPlayedElement.textContent =
            data.gamesPlayed;

    }



    /* ==============================
       XP PROGRESS
       ============================== */

    if (
        currentXPElement &&
        nextLevelXPElement &&
        xpProgressBar &&
        xpProgressText
    ) {


        const xpProgress =
            GameHubStorage.getXPProgress();


        currentXPElement.textContent =
            xpProgress.currentXP;


        nextLevelXPElement.textContent =
            xpProgress.nextLevelXP;


        xpProgressBar.style.width =
            xpProgress.progress + "%";


        xpProgressText.textContent =
            xpProgress.progress +
            "% progress";

    }



    /* ==============================
       RECENT GAMES
       ============================== */

    if (recentGamesElement) {


        const recentGames =
            data.recentGames || [];


        if (
            recentGames.length === 0
        ) {

            recentGamesElement.innerHTML =
                "<p>No games played yet.</p>";

        }

        else {


            recentGamesElement.innerHTML =
                recentGames
                    .map(
                        function (game) {

                            return `
                                <p>
                                    🎮
                                    ${GameHubStorage.getGameName(game)}
                                </p>
                            `;

                        }
                    )
                    .join("");

        }

    }



    /* ==============================
       ACHIEVEMENT PROGRESS
       ============================== */

    if (
        achievementCountElement &&
        achievementMessageElement
    ) {


        const unlockedCount =
            GameHubStorage
                .getAchievementCount();


        const totalCount =
            GameHubStorage
                .getTotalAchievementCount();



        achievementCountElement.textContent =
            unlockedCount;



        if (totalAchievementCountElement) {

            totalAchievementCountElement.textContent =
                totalCount;

        }



        /* MESSAGE */

        if (
            unlockedCount >=
            totalCount
        ) {

            achievementMessageElement.textContent =
                "🏆 All achievements unlocked!";

        }

        else if (
            unlockedCount > 0
        ) {

            achievementMessageElement.textContent =
                "🔥 Keep playing to unlock more achievements!";

        }

        else {

            achievementMessageElement.textContent =
                "🎮 Play games to unlock achievements!";

        }

    }

}