"use strict";

const App = (() => {
  function handleClick(event) {
    const goBtn = event.target.closest("[data-go]");
    if (goBtn) {
      UI.showScreen(goBtn.dataset.go);
      return;
    }

    const actionBtn = event.target.closest("[data-action]");
    if (!actionBtn) return;

    switch (actionBtn.dataset.action) {
      case "new-game":
        UI.showScreen("setup");
        break;
      case "continue-game":
        MenuUI.resume();
        break;
      default:
        console.warn("إجراء غير معروف:", actionBtn.dataset.action);
    }
  }

  function init() {
    document.addEventListener("click", handleClick);
    Prefs.load();
    UI.onScreen(Saver.onScreen);
    Sound.init();
    Setup.init();
    Characters.render();
    Reveal.init();
    NightUI.init();
    DayUI.init();
    WinUI.init();
    Panel.init();
    MenuUI.init();
    UI.showScreen("home");
  }

  return { init };
})();

document.addEventListener("DOMContentLoaded", App.init);