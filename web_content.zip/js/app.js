// Fungsi untuk membuka halaman tertentu
// Contoh: bukaHalaman("barang")
function bukaHalaman(namaHalaman) {

    // Mencari semua elemen yang memiliki class "halaman"
    document.querySelectorAll('.halaman').forEach(function(halaman) {

        // Menyembunyikan halaman tersebut
        halaman.classList.remove('aktif');
    });


    // Mencari halaman berdasarkan ID yang diberikan
    // Contoh: jika namaHalaman = "barang",
    // maka yang dicari adalah id="barang"
    document.getElementById(namaHalaman).classList.add('aktif');


    // Mencari semua tombol yang ada di menu bawah
    document.querySelectorAll('.menu button').forEach(function(tombol) {

        // Menghapus tanda "aktif" dari semua tombol
        tombol.classList.remove('aktif');
    });


    // Jika halaman yang dibuka adalah Dashboard
    if (namaHalaman === 'dashboard') {

        // Memberikan tanda aktif pada tombol Dashboard
        document.getElementById('menuDashboard').classList.add('aktif');
    }


    // Jika halaman yang dibuka adalah Barang
    if (namaHalaman === 'barang') {

        // Memberikan tanda aktif pada tombol Barang
        document.getElementById('menuBarang').classList.add('aktif');
    }
}