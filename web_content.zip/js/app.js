/**
 * Panchal Business Manager - Master Application Controller
 * Integrates all ERP modules: Dashboard, Parties, Inventory, Billing, Accounting,
 * Projects, Payroll, Visual Template Designer, Invoice/Tax/Numbering Settings,
 * Security/PIN Lock, Business Switcher & JSON Backup/Restore.
 */
(function () {
  "use strict";

  const STORAGE_KEYS = {
    LANG: "pbm_ui_lang",
    THEME: "pbm_ui_theme",
    ROUTE: "pbm_last_route"
  };

  const I18N = {
    en: {
      appName: "Panchal Business Manager",
      activeBusinessField: "Active Business",
      menuCore: "Core ERP",
      menuOperations: "Site & Team",
      menuSystem: "System",
      navDashboard: "Dashboard",
      navParties: "Parties (Customers / Suppliers)",
      navInventory: "Inventory & Warehouses",
      navBilling: "Invoices, Quotes & Docs (15)",
      navAccounting: "Accounting, GST & Reports",
      navTemplates: "Invoice Templates (32)",
      navProjects: "Contractor / Interior Projects",
      navPayroll: "Staff & Payroll",
      navDocuments: "Documents Vault",
      navSettings: "Business, Tax & Backup Settings",
      tabHome: "Home",
      tabBilling: "Billing",
      tabParties: "Parties",
      tabInventory: "Stock",
      tabProjects: "Projects",
      toggleLangLabel: "हिन्दी",
      kpiReceivable: "Total Receivable",
      kpiPayable: "Total Payable",
      kpiStockAlerts: "Low Stock Items",
      kpiActiveProjects: "Active Sites",
      quickActionsTitle: "All ERP Modules & Quick Actions",
      btnNewBill: "15 Docs & Billing",
      btnTemplates: "Invoice Templates",
      btnAddParty: "Parties & Ledgers",
      btnInventory: "Inventory & Godowns",
      btnAccounting: "P&L, GST & Books",
      btnProjects: "Site Projects",
      btnPayroll: "Staff & Payroll",
      btnBackup: "Business & Backup",
      switchBusinessBtn: "Switch",
      bizProfilesTitle: "Business Profiles & Bank/Tax Info",
      bizProfilesDesc: "Manage multiple shops/companies with Logo, Stamp, Signature & Bank details.",
      addBusinessBtn: "+ Add Business",
      bizSignBtn: "Signature",
      activeStatus: "Active",
      editBtn: "Edit",
      deleteBtn: "Delete",
      cancelBtn: "Cancel",
      saveBtn: "Save",
      confirmBtn: "Confirm",
      fyLabel: "FY",
      noGstin: "Unregistered (No GSTIN)",
      modalAddBusiness: "Add Business Profile",
      modalEditBusiness: "Edit Business Profile",
      fieldBizName: "Business / Firm Name *",
      fieldGstin: "GSTIN (15 characters, optional)",
      fieldPhone: "Phone Number (10 digits, optional)",
      fieldEmail: "Email (optional)",
      fieldState: "Home State (Place of Supply)",
      fieldAuthPerson: "Authorized Signatory Name",
      fieldAddress: "Business Address (optional)",
      fieldFy: "Financial Year",
      fieldBankName: "Bank Name",
      fieldBankAc: "Bank A/C Number",
      fieldBankIfsc: "IFSC Code",
      fieldUpi: "UPI ID",
      uploadLogoBtn: "Upload Logo",
      uploadStampBtn: "Upload Stamp",
      errBizNameReq: "Business name must be at least 2 characters.",
      errGstinInvalid: "GSTIN must be a valid 15-character code (e.g., 24ABCDE1234F1Z5).",
      errPhoneInvalid: "Phone number must be 10 digits.",
      confirmDeleteBizTitle: "Delete Business Profile?",
      confirmDeleteBizMsg: "This will permanently delete this business profile and all its local records on this device.",
      errLastBizDelete: "At least one business profile must remain active.",
      docSettingsTitle: "Invoice, Numbering & Tax Settings",
      docSettingsDesc: "Customize 10+10 Invoice/Quotation designs, numbering series, currency, round-off & terms.",
      openDocSettingsBtn: "Numbering, Currency & Terms",
      openDesignerBtn: "Open Visual Template Designer",
      backupSectionTitle: "Backup, Multi-Device Transfer & PWA",
      backupSectionDesc: "Export all IndexedDB data to a JSON file or restore from a saved backup file.",
      exportBackupBtn: "Download JSON Backup",
      importBackupBtn: "Restore JSON Backup",
      installPwaBtn: "Install App on Device",
      lastBackupLabel: "Last Backup",
      neverBackedUp: "Not yet backed up — take a JSON backup regularly",
      backupOfflineNote: "Offline Sync Notice: All data is stored privately inside this browser's IndexedDB. To move data to another phone, export a JSON backup, send it via WhatsApp/Files, and import it on the second device.",
      confirmRestoreTitle: "Restore Backup File?",
      confirmRestoreMsg: "Restoring a backup will replace all current local businesses and records on this device. Continue?",
      toastBizSwitched: "Active business switched.",
      toastBizSaved: "Business profile saved.",
      toastBizDeleted: "Business profile deleted.",
      toastSigSaved: "Authorized signature saved for prints.",
      toastSettingsSaved: "Document & tax settings saved.",
      toastBackupExported: "Backup JSON downloaded.",
      toastBackupRestored: "Backup restored successfully.",
      toastBackupError: "Could not restore backup. Please check the JSON file."
    },
    hi: {
      appName: "पांचाल बिज़नेस मैनेजर",
      activeBusinessField: "सक्रिय बिज़नेस",
      menuCore: "मुख्य ERP",
      menuOperations: "साइट और टीम",
      menuSystem: "सिस्टम",
      navDashboard: "डैशबोर्ड",
      navParties: "पार्टियाँ (ग्राहक / सप्लायर)",
      navInventory: "इन्वेंटरी और गोदाम",
      navBilling: "बिल, कोटेशन व 15 दस्तावेज़",
      navAccounting: "अकाउंटिंग, GST व रिपोर्ट्स",
      navTemplates: "बिल टेम्पलेट्स (32)",
      navProjects: "कॉन्ट्रैक्टर / इंटीरियर प्रोजेक्ट्स",
      navPayroll: "स्टाफ़ और सैलरी",
      navDocuments: "दस्तावेज़ (Documents)",
      navSettings: "बिज़नेस, टैक्स व बैकअप सेटिंग्स",
      tabHome: "होम",
      tabBilling: "बिलिंग",
      tabParties: "पार्टियाँ",
      tabInventory: "स्टॉक",
      tabProjects: "प्रोजेक्ट्स",
      toggleLangLabel: "English",
      kpiReceivable: "लेना बाकी (Receivable)",
      kpiPayable: "देना बाकी (Payable)",
      kpiStockAlerts: "कम स्टॉक आइटम",
      kpiActiveProjects: "चालू साइट्स",
      quickActionsTitle: "सभी ERP मॉड्यूल्स",
      btnNewBill: "15 बिल व कोटेशन",
      btnTemplates: "बिल टेम्पलेट्स",
      btnAddParty: "पार्टियाँ व खाता",
      btnInventory: "इन्वेंटरी व गोदाम",
      btnAccounting: "अकाउंटिंग / GST",
      btnProjects: "साइट प्रोजेक्ट्स",
      btnPayroll: "स्टाफ़ व सैलरी",
      btnBackup: "बिज़नेस व बैकअप",
      switchBusinessBtn: "चुनें",
      bizProfilesTitle: "बिज़नेस प्रोफ़ाइल्स व बैंक/टैक्स",
      bizProfilesDesc: "लोगो, मुहर (Stamp), हस्ताक्षर और बैंक विवरण के साथ कई बिज़नेस चलाएँ।",
      addBusinessBtn: "+ नया बिज़नेस",
      bizSignBtn: "हस्ताक्षर",
      activeStatus: "सक्रिय",
      editBtn: "बदलें",
      deleteBtn: "हटाएँ",
      cancelBtn: "रद्द करें",
      saveBtn: "सेव करें",
      confirmBtn: "पुष्टि करें",
      fyLabel: "वित्तीय वर्ष",
      noGstin: "बिना GSTIN",
      modalAddBusiness: "नया बिज़नेस जोड़ें",
      modalEditBusiness: "बिज़नेस प्रोफ़ाइल बदलें",
      fieldBizName: "बिज़नेस / फ़र्म का नाम *",
      fieldGstin: "GSTIN (15 अंक, वैकल्पिक)",
      fieldPhone: "फ़ोन नंबर (10 अंक, वैकल्पिक)",
      fieldEmail: "ईमेल (वैकल्पिक)",
      fieldState: "मुख्य राज्य (Place of Supply)",
      fieldAuthPerson: "अधिकृत व्यक्ति का नाम",
      fieldAddress: "बिज़नेस का पता (वैकल्पिक)",
      fieldFy: "वित्तीय वर्ष (Financial Year)",
      fieldBankName: "बैंक का नाम",
      fieldBankAc: "बैंक खाता संख्या",
      fieldBankIfsc: "IFSC कोड",
      fieldUpi: "UPI ID",
      uploadLogoBtn: "लोगो अपलोड करें",
      uploadStampBtn: "मुहर (Stamp) अपलोड",
      errBizNameReq: "बिज़नेस का नाम कम से कम 2 अक्षर का होना चाहिए।",
      errGstinInvalid: "सही 15-अंकीय GSTIN डालें (जैसे 24ABCDE1234F1Z5)।",
      errPhoneInvalid: "फ़ोन नंबर 10 अंकों का होना चाहिए।",
      confirmDeleteBizTitle: "बिज़नेस प्रोफ़ाइल हटाएँ?",
      confirmDeleteBizMsg: "यह बिज़नेस प्रोफ़ाइल और इससे जुड़ा सारा लोकल डेटा फ़ोन से हमेशा के लिए हट जाएगा।",
      errLastBizDelete: "कम से कम एक बिज़नेस प्रोफ़ाइल रहना ज़रूरी है।",
      docSettingsTitle: "इनवॉइस, नंबरिंग और टैक्स सेटिंग्स",
      docSettingsDesc: "10+10 बिल/कोटेशन डिज़ाइन, नंबर सीरीज़, मुद्रा, राउंड-ऑफ़ व नियम सेट करें।",
      openDocSettingsBtn: "नंबर सीरीज़, मुद्रा व नियम",
      openDesignerBtn: "विज़ुअल टेम्पलेट डिज़ाइनर खोलें",
      backupSectionTitle: "बैकअप, मल्टी-डिवाइस ट्रांसफ़र और PWA",
      backupSectionDesc: "पूरे IndexedDB डेटा को JSON फ़ाइल में डाउनलोड करें या पुरानी बैकअप फ़ाइल से वापस रीस्टोर करें।",
      exportBackupBtn: "JSON बैकअप डाउनलोड करें",
      importBackupBtn: "JSON बैकअप रीस्टोर करें",
      installPwaBtn: "फ़ोन में App इंस्टॉल करें",
      lastBackupLabel: "अंतिम बैकअप",
      neverBackedUp: "अभी तक बैकअप नहीं लिया — नियमित JSON बैकअप लें",
      backupOfflineNote: "ऑफ़लाइन सिंक नोट: सारा डेटा आपके फ़ोन के IndexedDB में सुरक्षित रहता है। दूसरे फ़ोन में डेटा भेजने के लिए JSON बैकअप डाउनलोड करें, WhatsApp/Files से भेजें और दूसरे फ़ोन में Restore करें।",
      confirmRestoreTitle: "बैकअप फ़ाइल रीस्टोर करें?",
      confirmRestoreMsg: "बैकअप रीस्टोर करने से फ़ोन में मौजूद अभी का सारा लोकल डेटा नई फ़ाइल से बदल जाएगा। क्या आप आगे बढ़ना चाहते हैं?",
      toastBizSwitched: "सक्रिय बिज़नेस बदल दिया गया।",
      toastBizSaved: "बिज़नेस प्रोफ़ाइल सेव हो गई।",
      toastBizDeleted: "बिज़नेस प्रोफ़ाइल हटा दी गई।",
      toastSigSaved: "प्रिंट बिल के लिए हस्ताक्षर सेव हो गया।",
      toastSettingsSaved: "डॉक्यूमेंट व टैक्स सेटिंग्स सेव हो गईं।",
      toastBackupExported: "JSON बैकअप डाउनलोड हो गया।",
      toastBackupRestored: "बैकअप सफलतापूर्वक रीस्टोर हो गया।",
      toastBackupError: "बैकअप रीस्टोर नहीं हो सका। कृपया सही JSON फ़ाइल चुनें।"
    }
  };

  const ROUTE_TITLE_KEYS = {
    dashboard: "navDashboard",
    parties: "navParties",
    inventory: "navInventory",
    billing: "navBilling",
    accounting: "navAccounting",
    templates: "navTemplates",
    projects: "navProjects",
    payroll: "navPayroll",
    documents: "navDocuments",
    settings: "navSettings"
  };

  const state = {
    lang: localStorage.getItem(STORAGE_KEYS.LANG) === "hi" ? "hi" : "en",
    theme: localStorage.getItem(STORAGE_KEYS.THEME) === "dark" ? "dark" : "light",
    route: localStorage.getItem(STORAGE_KEYS.ROUTE) || "dashboard",
    dashTab: "dashboard",
    ieBasis: "ACCRUAL",
    iePeriod: "fy",
    dashTimerInterval: null,
    businesses: [],
    activeBusinessId: null,
    activeCurrencySymbol: "₹",
    lastBackupAt: null,
    deferredInstallPrompt: null
  };

  const dom = {
    html: document.documentElement,
    metaThemeColor: document.getElementById("metaThemeColor"),
    drawer: document.getElementById("appDrawer"),
    drawerBackdrop: document.getElementById("drawerBackdrop"),
    openDrawerBtn: document.getElementById("openDrawerBtn"),
    closeDrawerBtn: document.getElementById("closeDrawerBtn"),
    drawerMonogram: document.getElementById("drawerMonogram"),
    activeBusinessLabel: document.getElementById("activeBusinessLabel"),
    activeBusinessSub: document.getElementById("activeBusinessSub"),
    drawerBusinessSelect: document.getElementById("drawerBusinessSelect"),
    pageTitle: document.getElementById("pageTitle"),
    viewContainer: document.getElementById("viewContainer"),
    quickCreateHeaderBtn: document.getElementById("quickCreateHeaderBtn"),
    notifBellBtn: document.getElementById("notifBellBtn"),
    notifBadge: document.getElementById("notifBadge"),
    langToggleBtn: document.getElementById("langToggleBtn"),
    langBadgeText: document.getElementById("langBadgeText"),
    themeToggleBtn: document.getElementById("themeToggleBtn"),
    themeIconSun: document.getElementById("themeIconSun"),
    themeIconMoon: document.getElementById("themeIconMoon"),
    appModalBackdrop: document.getElementById("appModalBackdrop"),
    appModalTitle: document.getElementById("appModalTitle"),
    appModalBody: document.getElementById("appModalBody"),
    appModalCloseBtn: document.getElementById("appModalCloseBtn"),
    toastContainer: document.getElementById("toastContainer")
  };

  function t(key) {
    return (I18N[state.lang] && I18N[state.lang][key]) || I18N.en[key] || key;
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function formatCurrency(amount) {
    const num = Number(amount) || 0;
    return (state.activeCurrencySymbol || "₹") + num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function showToast(message, isError) {
    const el = document.createElement("div");
    el.className = "toast" + (isError ? " is-error" : "");
    el.textContent = message;
    dom.toastContainer.appendChild(el);
    setTimeout(function () {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 3000);
  }

  function getActiveBusiness() {
    return (
      state.businesses.find(function (b) { return b.id === state.activeBusinessId; }) ||
      state.businesses[0] ||
      null
    );
  }

  function refreshBusinessState() {
    return Promise.all([
      window.PBM_DB.getAll("businesses"),
      window.PBM_DB.getActiveBusinessId(),
      window.PBM_DB.getLastBackupDate ? window.PBM_DB.getLastBackupDate() : Promise.resolve(null)
    ]).then(function (results) {
      state.businesses = results[0].sort(function (a, b) {
        return (a.createdAt || "").localeCompare(b.createdAt || "");
      });
      state.activeBusinessId = results[1];
      state.lastBackupAt = results[2];
      renderBusinessSwitcher();
      return window.PBM_DB.getByBusiness("docSettings", state.activeBusinessId).then(function (ds) {
        state.activeCurrencySymbol = (ds[0] && ds[0].currencySymbol) || "₹";
      });
    });
  }

  function renderBusinessSwitcher() {
    const activeBiz = getActiveBusiness();
    const bizName = activeBiz ? activeBiz.name : "Panchal Furnitures";
    dom.activeBusinessLabel.textContent = bizName;
    if (dom.drawerMonogram) {
      dom.drawerMonogram.textContent = (bizName.trim()[0] || "P").toUpperCase();
    }
    if (dom.activeBusinessSub) {
      dom.activeBusinessSub.textContent =
        (activeBiz && (activeBiz.email || activeBiz.gstin || activeBiz.phone)) || t("appName");
    }

    dom.drawerBusinessSelect.innerHTML = "";
    state.businesses.forEach(function (biz) {
      const option = document.createElement("option");
      option.value = biz.id;
      option.textContent = biz.name;
      option.selected = biz.id === state.activeBusinessId;
      dom.drawerBusinessSelect.appendChild(option);
    });
  }

  function switchActiveBusiness(businessId) {
    if (!businessId || businessId === state.activeBusinessId) {
      return Promise.resolve();
    }
    return window.PBM_DB.setActiveBusinessId(businessId)
      .then(function () { return window.PBM_DB.ensureBusinessMasters(businessId); })
      .then(function () { return refreshBusinessState(); })
      .then(function () {
        showToast(t("toastBizSwitched"), false);
        renderCurrentRoute();
      });
  }

  function applyTheme() {
    dom.html.setAttribute("data-theme", state.theme);
    const isDark = state.theme === "dark";
    dom.themeIconSun.classList.toggle("hidden", !isDark);
    dom.themeIconMoon.classList.toggle("hidden", isDark);
    dom.metaThemeColor.setAttribute("content", isDark ? "#131c31" : "#0f4c81");
  }

  function applyTranslations() {
    dom.html.setAttribute("lang", state.lang);
    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      const key = el.getAttribute("data-i18n");
      el.textContent = t(key);
    });
    dom.langBadgeText.textContent = t("toggleLangLabel");
    updateHeaderTitle();
  }

  function updateHeaderTitle() {
    if (state.route === "dashboard") {
      const activeBiz = getActiveBusiness();
      dom.pageTitle.textContent = activeBiz && activeBiz.name ? activeBiz.name : "PANCHAL FURNITURES";
      return;
    }
    const titleKey = ROUTE_TITLE_KEYS[state.route] || "navDashboard";
    dom.pageTitle.textContent = t(titleKey);
  }

  function updateNotificationBadge() {
    if (!dom.notifBadge || !state.activeBusinessId || !window.PBM_DB) return;
    const businessId = state.activeBusinessId;
    Promise.all([
      window.PBM_DB.getByBusiness("vouchers", businessId),
      window.PBM_DB.getByBusiness("items", businessId)
    ])
      .then(function (res) {
        const vouchers = res[0] || [];
        const items = res[1] || [];
        const today = new Date().toISOString().slice(0, 10);

        const overdueCount = vouchers.filter(function (v) {
          if (v.status === "VOID") return false;
          if (v.voucherType !== "SALE_INVOICE" && v.voucherType !== "BILL_OF_SUPPLY") return false;
          const due = (Number(v.grandTotal || v.amount) || 0) - (Number(v.paidAmount) || 0);
          return due > 0.01 && (v.dueDate || v.date || today) < today;
        }).length;

        const lowStockCount = items.filter(function (it) {
          if (it.type === "SERVICE") return false;
          const map = it.stockByWarehouse || {};
          const total = Object.keys(map).reduce(function (s, k) { return s + (Number(map[k]) || 0); }, 0);
          return total <= (Number(it.lowStockThreshold) || 0);
        }).length;

        const unbilledCount = window.PBM_ZOHO
          ? window.PBM_ZOHO.getTimeEntries(businessId).filter(function (x) { return !x.billed; }).length
          : 0;

        const totalAlerts = overdueCount + lowStockCount + (unbilledCount > 0 ? 1 : 0);
        dom.notifBadge.textContent = totalAlerts > 99 ? "99+" : String(totalAlerts);
        dom.notifBadge.classList.toggle("hidden", totalAlerts <= 0);
      })
      .catch(function () {});
  }

  function openDrawer() {
    dom.drawer.classList.add("open");
    dom.drawerBackdrop.classList.add("open");
    dom.drawerBackdrop.setAttribute("aria-hidden", "false");
  }

  function closeDrawer() {
    dom.drawer.classList.remove("open");
    dom.drawerBackdrop.classList.remove("open");
    dom.drawerBackdrop.setAttribute("aria-hidden", "true");
  }

  function openModal(title, htmlContent) {
    dom.appModalTitle.textContent = title;
    dom.appModalBody.innerHTML = htmlContent;
    dom.appModalBackdrop.classList.remove("hidden");
    dom.appModalBackdrop.setAttribute("aria-hidden", "false");
  }

  function closeModal() {
    dom.appModalBackdrop.classList.add("hidden");
    dom.appModalBackdrop.setAttribute("aria-hidden", "true");
    dom.appModalBody.innerHTML = "";
  }

  function confirmDialog(options) {
    return new Promise(function (resolve) {
      const btnClass = options.isDanger ? "danger-btn" : "primary-btn";
      const html = `
        <p class="card-subtitle">${escapeHtml(options.message)}</p>
        <div class="modal-actions">
          <button id="modalCancelAction" class="secondary-btn" type="button">${t("cancelBtn")}</button>
          <button id="modalConfirmAction" class="${btnClass}" type="button">${escapeHtml(options.confirmText || t("confirmBtn"))}</button>
        </div>
      `;
      openModal(options.title, html);

      function cleanup(result) {
        closeModal();
        resolve(result);
      }

      document.getElementById("modalCancelAction").addEventListener("click", function () { cleanup(false); });
      document.getElementById("modalConfirmAction").addEventListener("click", function () { cleanup(true); });
    });
  }

  function resizeImageFileToDataUrl(file, maxDim) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader();
      reader.onload = function (ev) {
        const img = new Image();
        img.onload = function () {
          let w = img.width;
          let h = img.height;
          if (w > maxDim || h > maxDim) {
            const scale = Math.min(maxDim / w, maxDim / h);
            w = Math.round(w * scale);
            h = Math.round(h * scale);
          }
          const canvas = document.createElement("canvas");
          canvas.width = w;
          canvas.height = h;
          canvas.getContext("2d").drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL("image/png"));
        };
        img.onerror = reject;
        img.src = ev.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function openBusinessFormModal(existingBiz) {
    const isEdit = Boolean(existingBiz);
    const biz = existingBiz
      ? JSON.parse(JSON.stringify(existingBiz))
      : {
          name: "",
          gstin: "",
          phone: "",
          email: "",
          stateName: "Gujarat",
          authorizedPerson: "",
          address: "",
          financialYear: "2026-27",
          bankName: "",
          bankAccountNo: "",
          bankIfsc: "",
          upiId: "",
          logoDataUrl: "",
          stampDataUrl: "",
          signatureDataUrl: ""
        };

    const formHtml = `
      <form id="businessForm" class="form-grid" novalidate>
        <div id="bizFormError" class="form-error hidden"></div>
        <div class="form-group">
          <label class="form-label" for="bizNameInput">${t("fieldBizName")}</label>
          <input id="bizNameInput" class="form-input" type="text" required value="${escapeHtml(biz.name)}" />
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="bizGstinInput">${t("fieldGstin")}</label>
            <input id="bizGstinInput" class="form-input" type="text" maxlength="15" value="${escapeHtml(biz.gstin)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="bizStateInput">${t("fieldState")}</label>
            <input id="bizStateInput" class="form-input" type="text" value="${escapeHtml(biz.stateName || "Gujarat")}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="bizPhoneInput">${t("fieldPhone")}</label>
            <input id="bizPhoneInput" class="form-input" type="tel" maxlength="10" value="${escapeHtml(biz.phone)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="bizEmailInput">${t("fieldEmail")}</label>
            <input id="bizEmailInput" class="form-input" type="email" value="${escapeHtml(biz.email || "")}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="bizFyInput">${t("fieldFy")}</label>
            <input id="bizFyInput" class="form-input" type="text" value="${escapeHtml(biz.financialYear || "2026-27")}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="bizAuthInput">${t("fieldAuthPerson")}</label>
            <input id="bizAuthInput" class="form-input" type="text" value="${escapeHtml(biz.authorizedPerson || "")}" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="bizAddressInput">${t("fieldAddress")}</label>
          <textarea id="bizAddressInput" class="form-textarea">${escapeHtml(biz.address)}</textarea>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="bizBankName">${t("fieldBankName")}</label>
            <input id="bizBankName" class="form-input" type="text" value="${escapeHtml(biz.bankName || "")}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="bizBankAc">${t("fieldBankAc")}</label>
            <input id="bizBankAc" class="form-input" type="text" value="${escapeHtml(biz.bankAccountNo || "")}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="bizBankIfsc">${t("fieldBankIfsc")}</label>
            <input id="bizBankIfsc" class="form-input" type="text" value="${escapeHtml(biz.bankIfsc || "")}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="bizUpi">${t("fieldUpi")}</label>
            <input id="bizUpi" class="form-input" type="text" value="${escapeHtml(biz.upiId || "")}" />
          </div>
        </div>
        <div class="btn-row">
          <button id="bizLogoBtn" class="secondary-btn" type="button">${t("uploadLogoBtn")}</button>
          <input id="bizLogoFile" class="hidden-file-input" type="file" accept="image/*" />
          <span id="bizLogoStatus" class="list-item-meta">${biz.logoDataUrl ? "Logo ✓" : ""}</span>
          <button id="bizStampBtn" class="secondary-btn" type="button">${t("uploadStampBtn")}</button>
          <input id="bizStampFile" class="hidden-file-input" type="file" accept="image/*" />
          <span id="bizStampStatus" class="list-item-meta">${biz.stampDataUrl ? "Stamp ✓" : ""}</span>
        </div>
        <div class="modal-actions">
          <button id="bizCancelBtn" class="secondary-btn" type="button">${t("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${t("saveBtn")}</button>
        </div>
      </form>
    `;

    openModal(isEdit ? t("modalEditBusiness") : t("modalAddBusiness"), formHtml);

    const logoFile = document.getElementById("bizLogoFile");
    document.getElementById("bizLogoBtn").addEventListener("click", function () { logoFile.click(); });
    logoFile.addEventListener("change", function (e) {
      if (e.target.files && e.target.files[0]) {
        resizeImageFileToDataUrl(e.target.files[0], 300).then(function (url) {
          biz.logoDataUrl = url;
          document.getElementById("bizLogoStatus").textContent = "Logo ✓";
        });
      }
    });

    const stampFile = document.getElementById("bizStampFile");
    document.getElementById("bizStampBtn").addEventListener("click", function () { stampFile.click(); });
    stampFile.addEventListener("change", function (e) {
      if (e.target.files && e.target.files[0]) {
        resizeImageFileToDataUrl(e.target.files[0], 240).then(function (url) {
          biz.stampDataUrl = url;
          document.getElementById("bizStampStatus").textContent = "Stamp ✓";
        });
      }
    });

    document.getElementById("bizCancelBtn").addEventListener("click", closeModal);
    document.getElementById("businessForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const errBox = document.getElementById("bizFormError");
      const name = document.getElementById("bizNameInput").value.trim();
      const gstin = document.getElementById("bizGstinInput").value.trim().toUpperCase();
      const phone = document.getElementById("bizPhoneInput").value.trim();

      if (name.length < 2) {
        errBox.textContent = t("errBizNameReq");
        errBox.classList.remove("hidden");
        return;
      }

      if (gstin && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(gstin)) {
        errBox.textContent = t("errGstinInvalid");
        errBox.classList.remove("hidden");
        return;
      }

      if (phone && !/^[0-9]{10}$/.test(phone)) {
        errBox.textContent = t("errPhoneInvalid");
        errBox.classList.remove("hidden");
        return;
      }

      const now = new Date().toISOString();
      const record = {
        id: isEdit ? biz.id : window.PBM_DB.generateId("biz"),
        name: name,
        gstin: gstin,
        stateName: document.getElementById("bizStateInput").value.trim() || "Gujarat",
        phone: phone,
        email: document.getElementById("bizEmailInput").value.trim(),
        financialYear: document.getElementById("bizFyInput").value.trim() || "2026-27",
        authorizedPerson: document.getElementById("bizAuthInput").value.trim(),
        address: document.getElementById("bizAddressInput").value.trim(),
        bankName: document.getElementById("bizBankName").value.trim(),
        bankAccountNo: document.getElementById("bizBankAc").value.trim(),
        bankIfsc: document.getElementById("bizBankIfsc").value.trim().toUpperCase(),
        upiId: document.getElementById("bizUpi").value.trim(),
        logoDataUrl: biz.logoDataUrl || "",
        stampDataUrl: biz.stampDataUrl || "",
        signatureDataUrl: biz.signatureDataUrl || "",
        createdAt: isEdit ? biz.createdAt : now,
        updatedAt: now
      };

      window.PBM_DB.put("businesses", record)
        .then(function () { return window.PBM_DB.ensureBusinessMasters(record.id); })
        .then(function () { return !isEdit ? window.PBM_DB.setActiveBusinessId(record.id) : null; })
        .then(function () { return window.PBM_DB.logAudit(record.id, isEdit ? "UPDATE" : "CREATE", "business", record.name); })
        .then(function () {
          closeModal();
          return refreshBusinessState();
        })
        .then(function () {
          showToast(t("toastBizSaved"), false);
          renderCurrentRoute();
        });
    });
  }

  function openDocSettingsModal() {
    const businessId = state.activeBusinessId;
    window.PBM_DB.getByBusiness("docSettings", businessId).then(function (list) {
      const ds = list[0] || window.PBM_DB.getDefaultDocSettings(businessId);
      const seriesKeys = Object.keys(ds.series || {});
      const seriesRows = seriesKeys
        .map(function (k) {
          const s = ds.series[k];
          return `
            <div class="list-item-card" style="padding:10px;background:var(--bg-canvas);">
              <strong style="font-size:0.84rem;">${escapeHtml(k)}</strong>
              <div class="form-row-4">
                <div class="form-group">
                  <label class="form-label">Prefix</label>
                  <input class="form-input" data-ser-pre="${k}" type="text" value="${escapeHtml(s.prefix || "")}" />
                </div>
                <div class="form-group">
                  <label class="form-label">Next No</label>
                  <input class="form-input" data-ser-nxt="${k}" type="number" min="1" value="${Number(s.nextNo || 1)}" />
                </div>
                <div class="form-group">
                  <label class="form-label">Suffix</label>
                  <input class="form-input" data-ser-suf="${k}" type="text" value="${escapeHtml(s.suffix || "")}" />
                </div>
              </div>
            </div>
          `;
        })
        .join("");

      const html = `
        <form id="docSetForm" class="form-grid" novalidate>
          <div class="form-row-2">
            <div class="form-group">
              <label class="form-label" for="dsCurSym">Currency Symbol</label>
              <input id="dsCurSym" class="form-input" type="text" value="${escapeHtml(ds.currencySymbol || "₹")}" />
            </div>
            <div class="form-group">
              <label class="form-label" for="dsDefTerms">Default Payment Terms</label>
              <select id="dsDefTerms" class="form-select">
                <option value="Due on Receipt" ${ds.defaultPaymentTerms === "Due on Receipt" ? "selected" : ""}>Due on Receipt</option>
                <option value="Net 7 Days" ${ds.defaultPaymentTerms === "Net 7 Days" ? "selected" : ""}>Net 7 Days</option>
                <option value="Net 15 Days" ${ds.defaultPaymentTerms === "Net 15 Days" ? "selected" : ""}>Net 15 Days</option>
                <option value="Net 30 Days" ${ds.defaultPaymentTerms === "Net 30 Days" ? "selected" : ""}>Net 30 Days</option>
              </select>
            </div>
          </div>
          <div class="btn-row">
            <label class="check-chip"><input id="dsFyPre" type="checkbox" ${ds.useFyPrefix ? "checked" : ""}/> FY-wise Number Prefix</label>
            <label class="check-chip"><input id="dsRound" type="checkbox" ${ds.enableRoundOff !== false ? "checked" : ""}/> Enable Auto Round-Off</label>
          </div>
          <div class="form-group">
            <label class="form-label" for="dsTermsLib">Terms &amp; Conditions Library (1 per line)</label>
            <textarea id="dsTermsLib" class="form-textarea">${escapeHtml((ds.termsLibrary || []).join("\n"))}</textarea>
          </div>
          <strong style="font-size:0.9rem;">Document Numbering Series</strong>
          <div class="list-stack" style="max-height:240px;overflow:auto;">${seriesRows}</div>
          <div class="modal-actions">
            <button id="dsCancelBtn" class="secondary-btn" type="button">${t("cancelBtn")}</button>
            <button class="primary-btn" type="submit">${t("saveBtn")}</button>
          </div>
        </form>
      `;

      openModal(t("docSettingsTitle"), html);
      document.getElementById("dsCancelBtn").addEventListener("click", closeModal);
      document.getElementById("docSetForm").addEventListener("submit", function (e) {
        e.preventDefault();
        ds.currencySymbol = document.getElementById("dsCurSym").value.trim() || "₹";
        ds.defaultPaymentTerms = document.getElementById("dsDefTerms").value;
        ds.useFyPrefix = document.getElementById("dsFyPre").checked;
        ds.enableRoundOff = document.getElementById("dsRound").checked;
        ds.termsLibrary = document.getElementById("dsTermsLib").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
        seriesKeys.forEach(function (k) {
          ds.series[k] = {
            prefix: document.querySelector('[data-ser-pre="' + k + '"]').value,
            nextNo: Math.max(1, parseInt(document.querySelector('[data-ser-nxt="' + k + '"]').value, 10) || 1),
            suffix: document.querySelector('[data-ser-suf="' + k + '"]').value
          };
        });
        ds.updatedAt = new Date().toISOString();
        window.PBM_DB.put("docSettings", ds).then(function () {
          state.activeCurrencySymbol = ds.currencySymbol;
          closeModal();
          showToast(t("toastSettingsSaved"), false);
          renderCurrentRoute();
        });
      });
    });
  }

  function handleDeleteBusiness(bizId) {
    if (window.PBM_SECURITY && window.PBM_SECURITY.getRole() !== "ADMIN") {
      window.PBM_SECURITY.showRestrictedToast();
      return;
    }
    if (state.businesses.length <= 1) {
      showToast(t("errLastBizDelete"), true);
      return;
    }

    confirmDialog({
      title: t("confirmDeleteBizTitle"),
      message: t("confirmDeleteBizMsg"),
      confirmText: t("deleteBtn"),
      isDanger: true
    }).then(function (confirmed) {
      if (!confirmed) return;
      window.PBM_DB.deleteRecordsByBusiness(bizId)
        .then(function () { return window.PBM_DB.remove("businesses", bizId); })
        .then(function () { return refreshBusinessState(); })
        .then(function () {
          showToast(t("toastBizDeleted"), false);
          renderCurrentRoute();
        });
    });
  }

  function handleExportBackup() {
    window.PBM_DB.exportAllData().then(function (payload) {
      state.lastBackupAt = payload.exportedAt;
      const jsonString = JSON.stringify(payload, null, 2);
      const blob = new Blob([jsonString], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const dateStamp = new Date().toISOString().slice(0, 10);
      const link = document.createElement("a");
      link.href = url;
      link.download = "panchal-erp-backup-" + dateStamp + ".json";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
      showToast(t("toastBackupExported"), false);
      if (state.route === "settings" || state.route === "dashboard") renderCurrentRoute();
    });
  }

  function handleImportBackupFile(file) {
    if (!file) return;
    if (window.PBM_SECURITY && window.PBM_SECURITY.getRole() !== "ADMIN") {
      window.PBM_SECURITY.showRestrictedToast();
      return;
    }

    const reader = new FileReader();
    reader.onload = function (event) {
      let parsed = null;
      try {
        parsed = JSON.parse(event.target.result);
      } catch (e) {
        showToast(t("toastBackupError"), true);
        return;
      }

      confirmDialog({
        title: t("confirmRestoreTitle"),
        message: t("confirmRestoreMsg"),
        confirmText: t("confirmBtn"),
        isDanger: true
      }).then(function (confirmed) {
        if (!confirmed) return;
        window.PBM_DB.importAllData(parsed)
          .then(function () { return refreshBusinessState(); })
          .then(function () {
            showToast(t("toastBackupRestored"), false);
            renderCurrentRoute();
          })
          .catch(function () {
            showToast(t("toastBackupError"), true);
          });
      });
    };
    reader.readAsText(file);
  }

  function syncActiveNavButtons() {
    document.querySelectorAll(".drawer-item").forEach(function (btn) {
      btn.classList.toggle("active", btn.getAttribute("data-route") === state.route);
    });
    document.querySelectorAll(".bottom-tab").forEach(function (btn) {
      btn.classList.toggle("active", btn.getAttribute("data-route") === state.route);
    });
  }

  function renderBusinessContextStrip() {
    const activeBiz = getActiveBusiness();
    if (!activeBiz) return "";
    const gstText = activeBiz.gstin ? activeBiz.gstin : t("noGstin");
    return `
      <div class="context-strip">
        <div>
          <div class="context-strip-title">${escapeHtml(activeBiz.name)}</div>
          <div class="context-strip-meta">${escapeHtml(gstText)} · ${t("fyLabel")} ${escapeHtml(activeBiz.financialYear || "2026-27")}</div>
        </div>
        <button class="secondary-btn" type="button" data-quick-route="settings">${t("switchBusinessBtn")}</button>
      </div>
    `;
  }

  function bindQuickRoutes(container) {
    container.querySelectorAll("[data-quick-route]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        navigateTo(btn.getAttribute("data-quick-route"));
      });
    });
  }

  function formatCompactMoney(amount) {
    const num = Math.abs(Number(amount) || 0);
    if (num >= 100000) return "₹" + (num / 100000).toFixed(1) + "L";
    if (num >= 1000) return "₹" + (num / 1000).toFixed(1) + "K";
    return "₹" + Math.round(num);
  }

  function clearDashTimerInterval() {
    if (state.dashTimerInterval) {
      clearInterval(state.dashTimerInterval);
      state.dashTimerInterval = null;
    }
  }

  function renderDashboardView() {
    clearDashTimerInterval();
    const businessId = state.activeBusinessId;
    const isHi = state.lang === "hi";
    const zoho = window.PBM_ZOHO;

    const partyTotalsPromise = window.PBM_PARTIES
      ? window.PBM_PARTIES.getBusinessTotals(businessId)
      : Promise.resolve({ totalReceivable: 0, totalPayable: 0 });
    const invSummaryPromise = window.PBM_INVENTORY
      ? window.PBM_INVENTORY.getSummary(businessId)
      : Promise.resolve({ lowStockCount: 0 });
    const prjSummaryPromise = window.PBM_PROJECTS
      ? window.PBM_PROJECTS.getSummary(businessId)
      : Promise.resolve({ activeCount: 0 });
    const vouchersPromise = window.PBM_DB.getByBusiness("vouchers", businessId);
    const partiesPromise = window.PBM_DB.getByBusiness("parties", businessId);

    Promise.all([partyTotalsPromise, invSummaryPromise, prjSummaryPromise, vouchersPromise, partiesPromise]).then(function (results) {
      const partyTotals = results[0];
      const invSummary = results[1];
      const prjSummary = results[2];
      const vouchers = results[3] || [];
      const parties = results[4] || [];
      const activeBiz = getActiveBusiness();
      const backupText = state.lastBackupAt
        ? state.lastBackupAt.slice(0, 16).replace("T", " ")
        : t("neverBackedUp");

      const dashTabsHtml = `
        <div class="segmented-bar" style="margin-bottom:4px;">
          <button type="button" class="seg-btn ${state.dashTab === "dashboard" ? "active" : ""}" data-dash-tab="dashboard">${isHi ? "डैशबोर्ड (Dashboard)" : "Dashboard"}</button>
          <button type="button" class="seg-btn ${state.dashTab === "announcements" ? "active" : ""}" data-dash-tab="announcements">${isHi ? "सूचनाएँ (Announcements)" : "Announcements"}</button>
          <button type="button" class="seg-btn ${state.dashTab === "help" ? "active" : ""}" data-dash-tab="help">${isHi ? "मदद (Help)" : "Help"}</button>
        </div>
      `;

      if (state.dashTab === "announcements") {
        const anns = zoho ? zoho.getAnnouncements() : [];
        const annRows = anns
          .map(function (a) {
            return `
              <div class="tx-row">
                <div>
                  <div class="tx-row-title">${escapeHtml(a.title)}</div>
                  <div class="tx-row-meta">${escapeHtml(a.body)}</div>
                </div>
                <span class="badge-pill">${escapeHtml(a.date || "")}</span>
              </div>
            `;
          })
          .join("");

        dom.viewContainer.innerHTML = `
          ${renderBusinessContextStrip()}
          ${dashTabsHtml}
          <div class="card">
            <div class="card-header-row">
              <div>
                <h2 class="card-title">${isHi ? "बिज़नेस सूचनाएँ व अपडेट्स" : "Business Announcements & Team Notices"}</h2>
                <p class="card-subtitle">${isHi ? "साइट व शोरूम अपडेट्स ऑफ़लाइन सेव करें" : "Important internal updates & offline announcements"}</p>
              </div>
            </div>
            <form id="addAnnouncementForm" class="form-grid" style="margin-top:10px;">
              <div class="form-row-2">
                <input id="annTitleInput" class="form-input" type="text" placeholder="${isHi ? "शीर्षक लिखें..." : "Announcement title..."}" required />
                <button class="primary-btn" type="submit">+ ${isHi ? "सूचना जोड़ें" : "Post Notice"}</button>
              </div>
              <input id="annBodyInput" class="form-input" type="text" placeholder="${isHi ? "विवरण लिखें (जैसे नया स्टॉक / GST नियम)..." : "Details for your staff or workshop..."}" required />
            </form>
            <div class="tx-feed" style="margin-top:14px;">${annRows}</div>
          </div>
        `;

        dom.viewContainer.querySelectorAll("[data-dash-tab]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            state.dashTab = btn.getAttribute("data-dash-tab");
            renderDashboardView();
          });
        });
        bindQuickRoutes(dom.viewContainer);

        const annForm = document.getElementById("addAnnouncementForm");
        if (annForm && zoho) {
          annForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const ttl = document.getElementById("annTitleInput").value.trim();
            const bdy = document.getElementById("annBodyInput").value.trim();
            if (!ttl || !bdy) return;
            zoho.addAnnouncement(ttl, bdy);
            showToast(isHi ? "सूचना सेव हो गई!" : "Announcement posted offline!", false);
            renderDashboardView();
          });
        }
        return;
      }

      if (state.dashTab === "help") {
        dom.viewContainer.innerHTML = `
          ${renderBusinessContextStrip()}
          ${dashTabsHtml}
          <div class="card">
            <h2 class="card-title">${isHi ? "ऑफ़लाइन बिज़नेस गाइड और शॉर्टकट्स" : "Offline Business Manager — Quick Help & Support"}</h2>
            <p class="card-subtitle">${isHi ? "बिना इंटरनेट के पूरा बिज़नेस कैसे चलाएँ:" : "Everything works 100% offline using IndexedDB & localStorage."}</p>
            <div class="tx-feed" style="margin-top:12px;">
              <div class="tx-row">
                <div>
                  <div class="tx-row-title">1. ${isHi ? "15 GST बिल, कोटेशन और चालान" : "Sales & Purchase Vouchers (15 Types)"}</div>
                  <div class="tx-row-meta">${isHi ? "टॉप बार में '+' बटन या साइड मेन्यू से Sales/Purchases खोलें।" : "Use the '+' Quick Create icon or Drawer → Sales / Purchases to create Invoices, Quotes, Orders & Bills."}</div>
                </div>
                <button type="button" class="secondary-btn" data-quick-route="billing">${isHi ? "खोलें" : "Open"}</button>
              </div>
              <div class="tx-row">
                <div>
                  <div class="tx-row-title">2. ${isHi ? "29 रेडीमेड बिल टेम्पलेट्स व PDF शेयर" : "29 Readymade PDF Templates & WhatsApp Share"}</div>
                  <div class="tx-row-meta">${isHi ? "Classic, Spreadsheet, Elite आदि 29 डिज़ाइन चुनें और सीधे असली PDF डाउनलोड/शेयर करें।" : "Switch between 29 Zoho-style layouts, customize editable T&C, and share real A4 PDFs offline."}</div>
                </div>
                <button type="button" class="secondary-btn" id="helpOpenTplBtn">${isHi ? "टेम्पलेट्स" : "Templates"}</button>
              </div>
              <div class="tx-row">
                <div>
                  <div class="tx-row-title">3. ${isHi ? "डॉक्यूमेंट्स वॉल्ट व टाइम ट्रैकिंग" : "Project Timer, Time Entries & Documents Vault"}</div>
                  <div class="tx-row-meta">${isHi ? "डैशबोर्ड से लाइव टाइमर चलाएँ और Documents में साइट फ़ोटो/फ़ाइलें सेव रखें।" : "Track workshop/site hours with the live Project Timer and store agreements/photos in Documents."}</div>
                </div>
                <button type="button" class="secondary-btn" data-quick-route="documents">${isHi ? "दस्तावेज़" : "Documents"}</button>
              </div>
              <div class="tx-row">
                <div>
                  <div class="tx-row-title">4. ${isHi ? "JSON बैकअप (डेटा सुरक्षा)" : "Weekly JSON Backup & Multi-Device Restore"}</div>
                  <div class="tx-row-meta">${isHi ? "Settings में जाकर JSON Backup डाउनलोड करें ताकि फ़ोन बदलने पर डेटा सुरक्षित रहे।" : "Export a JSON backup anytime from Settings to keep a portable copy of all records."}</div>
                </div>
                <button type="button" class="secondary-btn" data-quick-route="settings">${isHi ? "सेटिंग्स" : "Settings"}</button>
              </div>
            </div>
          </div>
        `;

        dom.viewContainer.querySelectorAll("[data-dash-tab]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            state.dashTab = btn.getAttribute("data-dash-tab");
            renderDashboardView();
          });
        });
        bindQuickRoutes(dom.viewContainer);
        const hTpl = document.getElementById("helpOpenTplBtn");
        if (hTpl) {
          hTpl.addEventListener("click", function () { navigateTo("templates"); });
        }
        return;
      }

      // Compute Quick Create top 4 selected module shortcuts
      const selectedQuickIds = zoho ? zoho.getSelectedQuickModules() : [];
      const quickCatalog = zoho ? zoho.QUICK_MODULE_CATALOG : [];
      const quickTilesHtml = selectedQuickIds
        .map(function (id) {
          const mod = quickCatalog.find(function (m) { return m.id === id; });
          if (!mod) return "";
          return `
            <button type="button" class="qc-shortcut-tile" data-qc-dash-launch="${mod.id}">
              <span class="qc-tile-icon">${zoho.getModuleIconSvg(mod.icon)}</span>
              <span class="qc-tile-lbl">${escapeHtml(mod.label)}</span>
            </button>
          `;
        })
        .join("");

      // Compute Income & Expense (Accrual / Cash) analytics
      const ieData = zoho
        ? zoho.buildIncomeExpenseAnalytics(vouchers, state.ieBasis, state.iePeriod)
        : { totalIncome: 0, totalExpense: 0, netValue: 0, monthBuckets: [] };
      const maxIe = Math.max(
        1,
        ieData.monthBuckets.reduce(function (m, b) {
          return Math.max(m, b.income, b.expense);
        }, 0)
      );
      const ieBarsHtml = ieData.monthBuckets
        .map(function (b) {
          const incPct = b.income > 0 ? Math.max(10, Math.round((b.income / maxIe) * 100)) : 5;
          const expPct = b.expense > 0 ? Math.max(10, Math.round((b.expense / maxIe) * 100)) : 5;
          return `
            <div class="ie-month-col" title="${escapeHtml(b.label)}: Income ${formatCurrency(b.income)} | Expense ${formatCurrency(b.expense)}">
              <div class="ie-bars-pair">
                <div class="ie-bar" style="height:${incPct}%;background:${b.income > 0 ? "#16a34a" : "var(--border-hairline)"};"></div>
                <div class="ie-bar" style="height:${expPct}%;background:${b.expense > 0 ? "#ef4444" : "var(--border-hairline)"};"></div>
              </div>
              <div class="aging-col-lbl">${escapeHtml(b.label)}</div>
            </div>
          `;
        })
        .join("");

      // Compute Project Timer + Unbilled Hours & Expenses
      const timerSt = zoho ? zoho.getTimerState() : { running: false, projectName: "Workshop" };
      const elapsedSec = zoho ? zoho.getElapsedTimerSeconds(timerSt) : 0;
      const timerDisplayStr = zoho ? zoho.formatDuration(elapsedSec) : "00:00:00";
      const timeEntries = zoho ? zoho.getTimeEntries(businessId) : [];
      const unbilledTime = timeEntries.filter(function (e) { return !e.billed; });
      const unbilledHours = unbilledTime.reduce(function (s, e) { return s + (Number(e.hours) || 0); }, 0);
      const unbilledTimeAmt = unbilledTime.reduce(function (s, e) { return s + (Number(e.amount) || 0); }, 0);
      const unbilledExpenseAmt = vouchers
        .filter(function (v) { return v.status !== "VOID" && v.voucherType === "EXPENSE_VOUCHER" && v.status !== "BILLED"; })
        .reduce(function (s, v) { return s + (Number(v.grandTotal || v.amount) || 0); }, 0);

      // Top Expenses list
      const topExpenses = zoho ? zoho.buildTopExpensesList(vouchers) : [];
      const topExpensesHtml = topExpenses.length
        ? topExpenses
            .map(function (ex) {
              return `
                <div class="tx-row">
                  <div class="tx-row-title" style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(ex.name)}</div>
                  <strong class="tabular-nums text-payable">${formatCurrency(ex.amount)}</strong>
                </div>
              `;
            })
            .join("")
        : `<div class="list-item-meta" style="padding:10px 0;">${isHi ? "अभी तक कोई खर्च दर्ज नहीं है — '+ Record Expense' दबाएँ।" : "No expenses logged yet — tap '+ Record Expense' above."}</div>`;

      // Compute Receivables Aging from real unpaid/partial Sale Invoices & Debit Notes
      const todayMs = new Date(new Date().toISOString().slice(0, 10)).getTime();
      const buckets = { current: 0, d15: 0, d30: 0, d45: 0, d45Plus: 0 };
      let currentTotal = 0;
      let overdueTotal = 0;

      vouchers.forEach(function (v) {
        if (v.status === "VOID") return;
        if (v.voucherType !== "SALE_INVOICE" && v.voucherType !== "BILL_OF_SUPPLY" && v.voucherType !== "DEBIT_NOTE") {
          return;
        }
        const total = Number(v.grandTotal || v.amount) || 0;
        const paid = Number(v.paidAmount) || 0;
        const due = Math.max(0, total - paid);
        if (due <= 0.01) return;

        const refDateStr = v.dueDate || v.date || new Date().toISOString().slice(0, 10);
        const refMs = new Date(refDateStr).getTime();
        const daysOverdue = isNaN(refMs) ? 0 : Math.floor((todayMs - refMs) / 86400000);

        if (daysOverdue <= 0) {
          buckets.current += due;
          currentTotal += due;
        } else {
          overdueTotal += due;
          if (daysOverdue <= 15) buckets.d15 += due;
          else if (daysOverdue <= 30) buckets.d30 += due;
          else if (daysOverdue <= 45) buckets.d45 += due;
          else buckets.d45Plus += due;
        }
      });

      const computedAgingSum = currentTotal + overdueTotal;
      if (computedAgingSum <= 0 && partyTotals.totalReceivable > 0) {
        buckets.current = partyTotals.totalReceivable;
        currentTotal = partyTotals.totalReceivable;
      }

      const maxBucket = Math.max(
        1,
        buckets.current,
        buckets.d15,
        buckets.d30,
        buckets.d45,
        buckets.d45Plus
      );

      const agingColumns = [
        { label: "Current", value: buckets.current, color: "#0ea5e9" },
        { label: "1-15d", value: buckets.d15, color: "#f59e0b" },
        { label: "16-30d", value: buckets.d30, color: "#f97316" },
        { label: "31-45d", value: buckets.d45, color: "#ef4444" },
        { label: ">45d", value: buckets.d45Plus, color: "#b91c1c" }
      ];

      const agingBarsHtml = agingColumns
        .map(function (col) {
          const pct = col.value > 0 ? Math.max(12, Math.round((col.value / maxBucket) * 100)) : 5;
          return `
            <div class="aging-col">
              <div class="aging-col-val tabular-nums">${formatCompactMoney(col.value)}</div>
              <div class="aging-bar-track">
                <div class="aging-bar-fill" style="height:${pct}%;background:${col.value > 0 ? col.color : "var(--border-hairline)"};"></div>
              </div>
              <div class="aging-col-lbl">${col.label}</div>
            </div>
          `;
        })
        .join("");

      const recentVouchers = vouchers
        .slice()
        .sort(function (a, b) {
          return (b.createdAt || b.date || "").localeCompare(a.createdAt || a.date || "");
        })
        .slice(0, 6);

      const recentTxHtml = recentVouchers.length
        ? recentVouchers
            .map(function (v) {
              const isOutflow =
                v.voucherType === "PURCHASE_BILL" ||
                v.voucherType === "EXPENSE_VOUCHER" ||
                v.voucherType === "PAYMENT" ||
                v.voucherType === "PURCHASE_ORDER" ||
                v.voucherType === "CREDIT_NOTE";
              const amt = Number(v.grandTotal || v.amount) || 0;
              return `
                <div class="tx-row">
                  <div style="min-width:0;">
                    <div class="tx-row-title">${escapeHtml(v.partyName || "Walk-in Party")} · ${escapeHtml(v.voucherNo || "-")}</div>
                    <div class="tx-row-meta">${escapeHtml((v.voucherType || "").replace(/_/g, " "))} · ${escapeHtml(v.date || "-")} · ${escapeHtml(v.status || "OPEN")}</div>
                  </div>
                  <div class="tx-row-right">
                    <div class="tabular-nums ${isOutflow ? "text-payable" : "text-receivable"}" style="font-weight:700;font-size:0.88rem;">
                      ${isOutflow ? "-" : "+"}${formatCurrency(amt)}
                    </div>
                    <button type="button" class="secondary-btn" data-dash-preview="${escapeHtml(v.id)}" style="min-height:26px;padding:2px 8px;font-size:0.72rem;margin-top:4px;">PDF / View</button>
                  </div>
                </div>
              `;
            })
            .join("")
        : `<div class="list-item-meta" style="padding:10px 0;">${isHi ? "अभी तक कोई बिल या ट्रांज़ैक्शन नहीं है — ऊपर नया बिल बनाएँ।" : "No transactions recorded yet — tap a Quick Create shortcut above to create your first GST bill."}</div>`;

      dom.viewContainer.innerHTML = `
        ${renderBusinessContextStrip()}
        ${dashTabsHtml}

        <div class="card">
          <div class="card-header-row" style="margin-bottom:8px;">
            <div>
              <h2 class="card-title">${isHi ? "क्विक क्रिएट शॉर्टकट्स (Quick Create)" : "Quick Create Shortcuts"}</h2>
              <p class="card-subtitle">${escapeHtml((activeBiz && activeBiz.name) || "Panchal Furnitures")} · ${isHi ? "अपने पसंदीदा 4 मॉड्यूल्स चुनें" : "Your 4 customizable instant launch actions"}</p>
            </div>
            <button type="button" id="dashCustomizeQuickBtn" class="secondary-btn" style="min-height:34px;padding:4px 10px;font-size:0.78rem;">+ ${isHi ? "4 मॉड्यूल बदलें" : "Customize 4"}</button>
          </div>
          <div class="qc-top-grid">${quickTilesHtml}</div>
        </div>

        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-label">${t("kpiReceivable")}</div>
            <div class="kpi-value tabular-nums text-receivable">${formatCurrency(partyTotals.totalReceivable)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${t("kpiPayable")}</div>
            <div class="kpi-value tabular-nums text-payable">${formatCurrency(partyTotals.totalPayable)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${t("kpiStockAlerts")}</div>
            <div class="kpi-value tabular-nums ${invSummary.lowStockCount > 0 ? "text-payable" : ""}">${invSummary.lowStockCount}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${t("kpiActiveProjects")}</div>
            <div class="kpi-value tabular-nums">${prjSummary.activeCount}</div>
          </div>
        </div>

        <div class="card">
          <div class="card-header-row" style="margin-bottom:8px;">
            <div>
              <h2 class="card-title">${isHi ? "आय और खर्च (Income & Expense)" : "Income & Expense"}</h2>
              <p class="card-subtitle">${state.ieBasis === "CASH" ? "Cash Basis" : "Accrual Basis"} · ${isHi ? "मासिक तुलना" : "Monthly inflow vs outflow"}</p>
            </div>
            <div class="btn-row">
              <div class="segmented-bar" style="margin:0;">
                <button type="button" class="seg-btn ${state.ieBasis === "ACCRUAL" ? "active" : ""}" data-ie-basis="ACCRUAL" style="min-height:32px;padding:4px 10px;font-size:0.75rem;">Accrual</button>
                <button type="button" class="seg-btn ${state.ieBasis === "CASH" ? "active" : ""}" data-ie-basis="CASH" style="min-height:32px;padding:4px 10px;font-size:0.75rem;">Cash</button>
              </div>
              <select id="iePeriodSelect" class="form-select" style="width:auto;min-height:34px;font-size:0.78rem;padding:4px 8px;">
                <option value="fy" ${state.iePeriod === "fy" ? "selected" : ""}>This Fiscal Year</option>
                <option value="half" ${state.iePeriod === "half" ? "selected" : ""}>Last 6 Months</option>
                <option value="quarter" ${state.iePeriod === "quarter" ? "selected" : ""}>This Quarter</option>
              </select>
            </div>
          </div>

          <div class="aging-split-row" style="margin-top:4px;padding-top:8px;grid-template-columns:repeat(3,minmax(0,1fr));">
            <div>
              <div class="list-item-meta">${isHi ? "कुल आय (Income)" : "Total Income"}</div>
              <strong class="tabular-nums text-receivable">${formatCurrency(ieData.totalIncome)}</strong>
            </div>
            <div>
              <div class="list-item-meta">${isHi ? "कुल खर्च (Expense)" : "Total Expense"}</div>
              <strong class="tabular-nums text-payable">${formatCurrency(ieData.totalExpense)}</strong>
            </div>
            <div style="text-align:right;">
              <div class="list-item-meta">${isHi ? "शुद्ध लाभ (Net)" : "Net Margin"}</div>
              <strong class="tabular-nums ${ieData.netValue >= 0 ? "text-receivable" : "text-payable"}">${formatCurrency(ieData.netValue)}</strong>
            </div>
          </div>

          <div class="ie-chart-grid" style="grid-template-columns:repeat(${Math.max(1, ieData.monthBuckets.length)}, minmax(0, 1fr));">
            ${ieBarsHtml}
          </div>
          <div style="display:flex;gap:14px;margin-top:8px;font-size:0.74rem;color:var(--text-muted);">
            <span style="display:inline-flex;align-items:center;gap:5px;"><span style="width:10px;height:10px;border-radius:3px;background:#16a34a;display:inline-block;"></span> Income</span>
            <span style="display:inline-flex;align-items:center;gap:5px;"><span style="width:10px;height:10px;border-radius:3px;background:#ef4444;display:inline-block;"></span> Expense</span>
          </div>
        </div>

        <div class="dash-overview-grid">
          <div class="card">
            <div class="card-header-row" style="margin-bottom:6px;">
              <div>
                <h2 class="card-title">${isHi ? "प्रोजेक्ट टाइमर व अनबिल्ड समय" : "Project Timer & Unbilled Summary"}</h2>
                <p class="card-subtitle">${escapeHtml(timerSt.projectName || "Workshop / Site Work")}</p>
              </div>
              <button type="button" id="dashTimeEntriesBtn" class="secondary-btn" style="min-height:32px;padding:4px 10px;font-size:0.75rem;">${isHi ? "सभी लॉग" : "Time Entries"} (${timeEntries.length})</button>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:10px 12px;border:1px solid var(--border-hairline);border-radius:var(--radius-md);background:var(--bg-canvas);margin-top:8px;">
              <div id="dashTimerDisplay" class="timer-display">${timerDisplayStr}</div>
              <div class="btn-row">
                <button type="button" id="dashTimerToggleBtn" class="primary-btn" style="min-height:36px;padding:6px 12px;font-size:0.8rem;">${timerSt.running ? (isHi ? "रोकें (Pause)" : "Pause Timer") : (isHi ? "टाइमर शुरू करें" : "Start Timer")}</button>
                ${elapsedSec > 0 ? `<button type="button" id="dashTimerStopBtn" class="secondary-btn" style="min-height:36px;padding:6px 10px;font-size:0.8rem;">${isHi ? "सेव करें" : "Stop & Log"}</button>` : ""}
                <button type="button" id="dashLogTimeBtn" class="secondary-btn" style="min-height:36px;padding:6px 10px;font-size:0.8rem;">+ Log Time</button>
              </div>
            </div>
            <div class="aging-split-row">
              <div>
                <div class="list-item-meta">${isHi ? "अनबिल्ड घंटे (Unbilled Hours)" : "Unbilled Hours"}</div>
                <strong class="tabular-nums">${unbilledHours.toFixed(1)} hrs (${formatCurrency(unbilledTimeAmt)})</strong>
              </div>
              <div style="text-align:right;">
                <div class="list-item-meta">${isHi ? "अनबिल्ड खर्च (Unbilled Expenses)" : "Unbilled Expenses"}</div>
                <strong class="tabular-nums text-payable">${formatCurrency(unbilledExpenseAmt)}</strong>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-header-row" style="margin-bottom:6px;">
              <div>
                <h2 class="card-title">${isHi ? "प्रमुख खर्च (Top Expenses)" : "Top Expenses"}</h2>
                <p class="card-subtitle">${isHi ? "सबसे अधिक खर्च श्रेणियाँ" : "Highest expense heads & mileage"}</p>
              </div>
              <div class="btn-row">
                <button type="button" id="dashMileageBtn" class="secondary-btn" style="min-height:32px;padding:4px 8px;font-size:0.74rem;">+ Mileage</button>
                <button type="button" class="primary-btn" data-dash-new-doc="EXPENSE_VOUCHER" style="min-height:32px;padding:4px 10px;font-size:0.75rem;">+ Record Expense</button>
              </div>
            </div>
            <div class="tx-feed">${topExpensesHtml}</div>
          </div>
        </div>

        <div class="dash-overview-grid">
          <div class="card">
            <div class="card-header-row" style="margin-bottom:4px;">
              <div>
                <h2 class="card-title">${isHi ? "प्राप्ति सारांश (Receivables Summary)" : "Receivables Summary"}</h2>
                <p class="card-subtitle">${isHi ? "लंबित बिल व ओवरड्यू एजिंग" : "Unpaid invoice aging across buckets"}</p>
              </div>
              <strong class="tabular-nums text-receivable">${formatCurrency(Math.max(partyTotals.totalReceivable, computedAgingSum))}</strong>
            </div>
            <div class="aging-chart">${agingBarsHtml}</div>
            <div class="aging-split-row">
              <div>
                <div class="list-item-meta">${isHi ? "चालू (Current)" : "Current"}</div>
                <strong class="tabular-nums text-receivable">${formatCurrency(currentTotal)}</strong>
              </div>
              <div style="text-align:right;">
                <div class="list-item-meta">${isHi ? "ओवरड्यू (Overdue)" : "Overdue"}</div>
                <strong class="tabular-nums text-payable">${formatCurrency(overdueTotal)}</strong>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-header-row" style="margin-bottom:4px;">
              <div>
                <h2 class="card-title">${isHi ? "हालिया लेन-देन (Recent Transactions)" : "Recent Transactions"}</h2>
                <p class="card-subtitle">${isHi ? "नवीनतम बिल, कोटेशन व वाउचर" : "Latest vouchers & PDF previews"}</p>
              </div>
              <button class="secondary-btn" type="button" data-quick-route="billing" style="min-height:32px;padding:4px 10px;font-size:0.78rem;">${isHi ? "सभी देखें" : "View All"}</button>
            </div>
            <div class="tx-feed">${recentTxHtml}</div>
          </div>
        </div>

        <div class="card">
          <h2 class="card-title">${t("quickActionsTitle")}</h2>
          <div class="quick-actions-grid">
            <button class="secondary-btn" type="button" data-quick-route="billing">${t("btnNewBill")}</button>
            <button class="secondary-btn" type="button" id="dashTemplatesBtn">${t("btnTemplates")}</button>
            <button class="secondary-btn" type="button" data-quick-route="inventory">${t("btnInventory")}</button>
            <button class="secondary-btn" type="button" data-quick-route="accounting">${t("btnAccounting")}</button>
            <button class="secondary-btn" type="button" data-quick-route="payroll">${t("btnPayroll")}</button>
            <button class="secondary-btn" type="button" data-quick-route="projects">${t("btnProjects")}</button>
            <button class="secondary-btn" type="button" data-quick-route="documents">${t("navDocuments")}</button>
            <button class="secondary-btn" type="button" data-quick-route="settings">${t("btnBackup")}</button>
          </div>
          <div class="info-note"><strong>${t("lastBackupLabel")}:</strong> ${escapeHtml(backupText)}</div>
        </div>
      `;

      bindQuickRoutes(dom.viewContainer);

      dom.viewContainer.querySelectorAll("[data-dash-tab]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          state.dashTab = btn.getAttribute("data-dash-tab");
          renderDashboardView();
        });
      });

      const custQuickBtn = document.getElementById("dashCustomizeQuickBtn");
      if (custQuickBtn && zoho) {
        custQuickBtn.addEventListener("click", function () {
          zoho.openQuickCreateModal(renderDashboardView);
        });
      }

      dom.viewContainer.querySelectorAll("[data-qc-dash-launch]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          if (zoho) zoho.launchQuickModule(btn.getAttribute("data-qc-dash-launch"));
        });
      });

      dom.viewContainer.querySelectorAll("[data-ie-basis]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          state.ieBasis = btn.getAttribute("data-ie-basis");
          renderDashboardView();
        });
      });

      const ieSel = document.getElementById("iePeriodSelect");
      if (ieSel) {
        ieSel.addEventListener("change", function () {
          state.iePeriod = ieSel.value;
          renderDashboardView();
        });
      }

      const timerDisp = document.getElementById("dashTimerDisplay");
      if (timerSt.running && timerDisp && zoho) {
        state.dashTimerInterval = setInterval(function () {
          const el = document.getElementById("dashTimerDisplay");
          if (!el) {
            clearDashTimerInterval();
            return;
          }
          el.textContent = zoho.formatDuration(zoho.getElapsedTimerSeconds());
        }, 1000);
      }

      const timerToggleBtn = document.getElementById("dashTimerToggleBtn");
      if (timerToggleBtn && zoho) {
        timerToggleBtn.addEventListener("click", function () {
          zoho.startOrPauseTimer();
          renderDashboardView();
        });
      }

      const timerStopBtn = document.getElementById("dashTimerStopBtn");
      if (timerStopBtn && zoho) {
        timerStopBtn.addEventListener("click", function () {
          zoho.stopAndSaveTimer(businessId);
          showToast(isHi ? "टाइमर समय सेव हो गया!" : "Timer logged to Time Entries!", false);
          updateNotificationBadge();
          renderDashboardView();
        });
      }

      const logTimeBtn = document.getElementById("dashLogTimeBtn");
      if (logTimeBtn && zoho) {
        logTimeBtn.addEventListener("click", function () {
          zoho.openLogTimeModal(function () {
            updateNotificationBadge();
            renderDashboardView();
          });
        });
      }

      const timeEntriesBtn = document.getElementById("dashTimeEntriesBtn");
      if (timeEntriesBtn && zoho) {
        timeEntriesBtn.addEventListener("click", zoho.openTimeEntriesModal);
      }

      const milBtn = document.getElementById("dashMileageBtn");
      if (milBtn && zoho) {
        milBtn.addEventListener("click", zoho.openMileageModal);
      }

      const dtBtn = document.getElementById("dashTemplatesBtn");
      if (dtBtn) {
        dtBtn.addEventListener("click", function () { navigateTo("templates"); });
      }

      dom.viewContainer.querySelectorAll("[data-dash-new-doc]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const docType = btn.getAttribute("data-dash-new-doc");
          if (window.PBM_BILLING && typeof window.PBM_BILLING.openDocumentModal === "function") {
            window.PBM_BILLING.openDocumentModal(null, docType);
          } else {
            navigateTo("billing");
          }
        });
      });

      dom.viewContainer.querySelectorAll("[data-dash-preview]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const vId = btn.getAttribute("data-dash-preview");
          const voucher = vouchers.find(function (x) { return x.id === vId; });
          if (!voucher || !window.PBM_PRINT) return;
          const party = parties.find(function (p) { return p.id === voucher.partyId; }) || null;
          window.PBM_PRINT.openDocumentPreviewModal(voucher, activeBiz, party, function () {
            renderDashboardView();
          });
        });
      });
    });
  }

  function renderSettingsView() {
    const backupText = state.lastBackupAt
      ? state.lastBackupAt.slice(0, 16).replace("T", " ")
      : t("neverBackedUp");

    const bizCardsHtml = state.businesses
      .map(function (biz) {
        const isActive = biz.id === state.activeBusinessId;
        const gstLabel = biz.gstin ? biz.gstin : t("noGstin");
        const phoneLabel = biz.phone ? " · " + biz.phone : "";
        return `
          <div class="list-item-card ${isActive ? "is-active" : ""}">
            <div class="list-item-top">
              <div>
                <h3 class="list-item-title">${escapeHtml(biz.name)}</h3>
                <div class="list-item-meta">${escapeHtml(gstLabel)}${escapeHtml(phoneLabel)} · ${t("fyLabel")} ${escapeHtml(biz.financialYear || "2026-27")}</div>
              </div>
              ${isActive ? `<span class="status-text">${t("activeStatus")}</span>` : ""}
            </div>
            <div class="btn-row">
              ${isActive ? "" : `<button class="primary-btn" type="button" data-biz-switch="${escapeHtml(biz.id)}">${t("switchBusinessBtn")}</button>`}
              <button class="secondary-btn" type="button" data-biz-sign="${escapeHtml(biz.id)}">${t("bizSignBtn")}</button>
              <button class="secondary-btn" type="button" data-biz-edit="${escapeHtml(biz.id)}">${t("editBtn")}</button>
              <button class="danger-btn" type="button" data-biz-delete="${escapeHtml(biz.id)}" ${state.businesses.length <= 1 ? "disabled" : ""}>${t("deleteBtn")}</button>
            </div>
          </div>
        `;
      })
      .join("");

    dom.viewContainer.innerHTML = `
      <div class="card">
        <div class="card-header-row">
          <div>
            <h2 class="card-title">${t("bizProfilesTitle")}</h2>
            <p class="card-subtitle">${t("bizProfilesDesc")}</p>
          </div>
          <button id="addBusinessBtn" class="primary-btn" type="button">${t("addBusinessBtn")}</button>
        </div>
        <div class="list-stack">${bizCardsHtml}</div>
      </div>

      <div class="card">
        <h2 class="card-title">${t("docSettingsTitle")}</h2>
        <p class="card-subtitle">${t("docSettingsDesc")}</p>
        <div class="btn-row" style="margin-top: 12px;">
          <button id="openDesignerBtn" class="primary-btn" type="button">${t("openDesignerBtn")}</button>
          <button id="openDocSettingsBtn" class="secondary-btn" type="button">${t("openDocSettingsBtn")}</button>
        </div>
      </div>

      <div class="card">
        <h2 class="card-title">${t("backupSectionTitle")}</h2>
        <p class="card-subtitle">${t("backupSectionDesc")}</p>
        <div class="info-note" style="margin-top:10px;"><strong>${t("lastBackupLabel")}:</strong> ${escapeHtml(backupText)}</div>
        <div class="btn-row" style="margin-top: 12px;">
          <button id="exportBackupBtn" class="primary-btn" type="button">${t("exportBackupBtn")}</button>
          <button id="importBackupBtn" class="secondary-btn" type="button">${t("importBackupBtn")}</button>
          ${state.deferredInstallPrompt ? `<button id="installPwaBtn" class="secondary-btn" type="button">${t("installPwaBtn")}</button>` : ""}
          <input id="importBackupInput" class="hidden-file-input" type="file" accept=".json,application/json" />
        </div>
        <div class="info-note">${t("backupOfflineNote")}</div>
      </div>

      <div id="settingsExtendedWrap" class="list-stack"></div>
      <div id="settingsSecurityWrap" class="list-stack"></div>
    `;

    document.getElementById("addBusinessBtn").addEventListener("click", function () { openBusinessFormModal(null); });
    document.getElementById("openDocSettingsBtn").addEventListener("click", openDocSettingsModal);
    document.getElementById("openDesignerBtn").addEventListener("click", function () {
      navigateTo("templates");
    });

    dom.viewContainer.querySelectorAll("[data-biz-switch]").forEach(function (btn) {
      btn.addEventListener("click", function () { switchActiveBusiness(btn.getAttribute("data-biz-switch")); });
    });

    dom.viewContainer.querySelectorAll("[data-biz-sign]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const bizId = btn.getAttribute("data-biz-sign");
        const found = state.businesses.find(function (b) { return b.id === bizId; });
        if (!found || !window.PBM_PRINT) return;
        window.PBM_PRINT.openSignaturePadModal(t("bizSignBtn"), found.signatureDataUrl || "", function (sigUrl) {
          found.signatureDataUrl = sigUrl;
          found.updatedAt = new Date().toISOString();
          window.PBM_DB.put("businesses", found)
            .then(function () { return refreshBusinessState(); })
            .then(function () { showToast(t("toastSigSaved"), false); });
        });
      });
    });

    dom.viewContainer.querySelectorAll("[data-biz-edit]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const found = state.businesses.find(function (b) { return b.id === btn.getAttribute("data-biz-edit"); });
        if (found) openBusinessFormModal(found);
      });
    });

    dom.viewContainer.querySelectorAll("[data-biz-delete]").forEach(function (btn) {
      btn.addEventListener("click", function () { handleDeleteBusiness(btn.getAttribute("data-biz-delete")); });
    });

    document.getElementById("exportBackupBtn").addEventListener("click", handleExportBackup);

    const fileInput = document.getElementById("importBackupInput");
    document.getElementById("importBackupBtn").addEventListener("click", function () {
      fileInput.value = "";
      fileInput.click();
    });
    fileInput.addEventListener("change", function (event) {
      if (event.target.files && event.target.files[0]) handleImportBackupFile(event.target.files[0]);
    });

    const installBtn = document.getElementById("installPwaBtn");
    if (installBtn && state.deferredInstallPrompt) {
      installBtn.addEventListener("click", function () {
        state.deferredInstallPrompt.prompt();
        state.deferredInstallPrompt.userChoice.then(function () {
          state.deferredInstallPrompt = null;
          renderSettingsView();
        });
      });
    }

    if (window.PBM_ZOHO) {
      window.PBM_ZOHO.renderExtendedSettingsCards(document.getElementById("settingsExtendedWrap"));
    }

    if (window.PBM_SECURITY) {
      window.PBM_SECURITY.renderSettingsSecurityCard(document.getElementById("settingsSecurityWrap"));
    }
  }

  function renderCurrentRoute() {
    clearDashTimerInterval();
    syncActiveNavButtons();
    updateHeaderTitle();
    updateNotificationBadge();

    const strip = renderBusinessContextStrip();
    let renderPromise = null;

    if (state.route === "dashboard") {
      renderDashboardView();
      return;
    } else if (state.route === "parties" && window.PBM_PARTIES) {
      renderPromise = window.PBM_PARTIES.render(dom.viewContainer, strip);
    } else if (state.route === "inventory" && window.PBM_INVENTORY) {
      renderPromise = window.PBM_INVENTORY.render(dom.viewContainer, strip);
    } else if (state.route === "billing" && window.PBM_BILLING) {
      renderPromise = window.PBM_BILLING.render(dom.viewContainer, strip);
    } else if (state.route === "accounting" && window.PBM_ACCOUNTING) {
      renderPromise = window.PBM_ACCOUNTING.render(dom.viewContainer, strip);
    } else if (state.route === "templates" && window.PBM_TEMPLATES) {
      renderPromise = window.PBM_TEMPLATES.render(dom.viewContainer, strip);
    } else if (state.route === "projects" && window.PBM_PROJECTS) {
      renderPromise = window.PBM_PROJECTS.render(dom.viewContainer, strip);
    } else if (state.route === "payroll" && window.PBM_PAYROLL) {
      renderPromise = window.PBM_PAYROLL.render(dom.viewContainer, strip);
    } else if (state.route === "documents" && window.PBM_ZOHO) {
      renderPromise = window.PBM_ZOHO.renderDocumentsView(dom.viewContainer, strip);
    } else if (state.route === "settings") {
      renderSettingsView();
      return;
    }

    if (renderPromise && typeof renderPromise.then === "function") {
      renderPromise.then(function () { bindQuickRoutes(dom.viewContainer); });
    }
  }

  function navigateTo(route) {
    if (!ROUTE_TITLE_KEYS[route]) route = "dashboard";
    if (route === "accounting" && window.PBM_SECURITY && !window.PBM_SECURITY.canAccess("accounting")) {
      window.PBM_SECURITY.showRestrictedToast();
      return;
    }
    state.route = route;
    localStorage.setItem(STORAGE_KEYS.ROUTE, route);
    renderCurrentRoute();
    closeDrawer();
  }

  function registerServiceWorker() {
    const isSecureContext =
      window.location.protocol === "https:" ||
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1";

    if ("serviceWorker" in navigator && isSecureContext) {
      navigator.serviceWorker.register("./sw.js").catch(function () {});
    }
  }

  function bindEvents() {
    dom.openDrawerBtn.addEventListener("click", openDrawer);
    dom.closeDrawerBtn.addEventListener("click", closeDrawer);
    dom.drawerBackdrop.addEventListener("click", closeDrawer);
    dom.appModalCloseBtn.addEventListener("click", closeModal);
    dom.appModalBackdrop.addEventListener("click", function (event) {
      if (event.target === dom.appModalBackdrop) closeModal();
    });

    dom.drawerBusinessSelect.addEventListener("change", function (event) {
      switchActiveBusiness(event.target.value).then(function () { closeDrawer(); });
    });

    document.querySelectorAll("[data-route]").forEach(function (btn) {
      btn.addEventListener("click", function () { navigateTo(btn.getAttribute("data-route")); });
    });

    document.querySelectorAll("[data-submenu-toggle]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const group = btn.closest(".drawer-group");
        if (group) {
          group.classList.toggle("is-open");
        }
      });
    });

    document.querySelectorAll("[data-new-doc]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const docType = btn.getAttribute("data-new-doc");
        closeDrawer();
        if (window.PBM_BILLING && typeof window.PBM_BILLING.openDocumentModal === "function") {
          window.PBM_BILLING.openDocumentModal(null, docType);
        } else {
          navigateTo("billing");
        }
      });
    });

    if (dom.quickCreateHeaderBtn) {
      dom.quickCreateHeaderBtn.addEventListener("click", function () {
        if (window.PBM_ZOHO) window.PBM_ZOHO.openQuickCreateModal();
      });
    }

    if (dom.notifBellBtn) {
      dom.notifBellBtn.addEventListener("click", function () {
        if (window.PBM_ZOHO) window.PBM_ZOHO.openNotificationsModal();
      });
    }

    document.querySelectorAll("[data-bill-filter]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const filter = btn.getAttribute("data-bill-filter") || "ALL";
        if (window.PBM_BILLING && typeof window.PBM_BILLING.setFilter === "function") {
          window.PBM_BILLING.setFilter(filter);
        }
        navigateTo("billing");
      });
    });

    document.querySelectorAll("[data-acc-tab]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const tab = btn.getAttribute("data-acc-tab") || "cashbank";
        if (window.PBM_ACCOUNTING && typeof window.PBM_ACCOUNTING.setTab === "function") {
          window.PBM_ACCOUNTING.setTab(tab);
        }
        navigateTo("accounting");
      });
    });

    document.querySelectorAll("[data-doc-view]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        window.__pbmDocTabState = { tab: btn.getAttribute("data-doc-view") || "all", folder: "ALL" };
        navigateTo("documents");
      });
    });

    document.querySelectorAll('[data-action="time-entries"]').forEach(function (btn) {
      btn.addEventListener("click", function () {
        closeDrawer();
        if (window.PBM_ZOHO) window.PBM_ZOHO.openTimeEntriesModal();
      });
    });

    document.querySelectorAll('[data-action="template-designer"]').forEach(function (btn) {
      btn.addEventListener("click", function () {
        navigateTo("templates");
      });
    });

    dom.langToggleBtn.addEventListener("click", function () {
      state.lang = state.lang === "en" ? "hi" : "en";
      localStorage.setItem(STORAGE_KEYS.LANG, state.lang);
      applyTranslations();
      renderCurrentRoute();
    });

    dom.themeToggleBtn.addEventListener("click", function () {
      state.theme = state.theme === "light" ? "dark" : "light";
      localStorage.setItem(STORAGE_KEYS.THEME, state.theme);
      applyTheme();
    });

    window.addEventListener("beforeinstallprompt", function (e) {
      e.preventDefault();
      state.deferredInstallPrompt = e;
      if (state.route === "settings") renderSettingsView();
    });
  }

  window.PBM_APP = {
    t: t,
    getLang: function () { return state.lang; },
    escapeHtml: escapeHtml,
    formatCurrency: formatCurrency,
    openModal: openModal,
    closeModal: closeModal,
    confirmDialog: confirmDialog,
    showToast: showToast,
    getActiveBusinessId: function () { return state.activeBusinessId; },
    getActiveBusiness: getActiveBusiness,
    navigateTo: navigateTo,
    renderCurrentRoute: renderCurrentRoute
  };

  function init() {
    if (!localStorage.getItem(STORAGE_KEYS.ROUTE) && window.PBM_ZOHO) {
      const prefScreen = window.PBM_ZOHO.getPrefs().openingScreen;
      if (prefScreen && ROUTE_TITLE_KEYS[prefScreen]) state.route = prefScreen;
    }

    applyTheme();
    applyTranslations();
    bindEvents();
    registerServiceWorker();

    window.PBM_DB.init()
      .then(function () { return refreshBusinessState(); })
      .then(function () { return window.PBM_SECURITY ? window.PBM_SECURITY.init() : null; })
      .then(function () {
        updateNotificationBadge();
        navigateTo(state.route);
      })
      .catch(function (err) {
        showToast(err && err.message ? err.message : "Database error", true);
      });
  }

  init();
})();
