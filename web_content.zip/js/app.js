const $ = s => document.querySelector(s);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

/* ---------- Bank soal: My Family dan Daily Activities ---------- */
// [pertanyaan, jawaban benar, [pilihan salah], penjelasan, topik]
const F = "My Family", D = "Daily Activities";
const Q = [
  ["My father’s mother is my ___.", "grandmother", ["aunt", "sister", "cousin"], "Grandmother = nenek, grandfather = kakek.", F],
  ["My mother’s brother is my ___.", "uncle", ["cousin", "nephew", "grandfather"], "Uncle = paman.", F],
  ["My uncle’s daughter is my ___.", "cousin", ["sister", "aunt", "niece"], "Cousin = sepupu (laki-laki maupun perempuan).", F],
  ["My father and my mother are my ___.", "parents", ["siblings", "cousins", "children"], "Parents = orang tua.", F],
  ["My mother’s sister is my ___.", "aunt", ["uncle", "cousin", "grandmother"], "Aunt = bibi atau tante.", F],
  ["There are five people in my family: my parents and three ___.", "children", ["childs", "childrens", "childes"], "Bentuk jamak dari child adalah children.", F],
  ["This is my brother. ___ name is Doni.", "His", ["Her", "Its", "Our"], "His = miliknya (laki-laki), her = miliknya (perempuan).", F],
  ["Rina is my sister. ___ is twelve years old.", "She", ["He", "It", "They"], "Untuk perempuan gunakan she.", F],
  ["My grandfather ___ seventy years old.", "is", ["am", "are", "be"], "Grandfather adalah satu orang (he), jadi pakai is.", F],
  ["My parents ___ teachers.", "are", ["is", "am", "be"], "Parents jamak, jadi pakai are.", F],
  ["Which sentence is correct?", "I have two brothers.", ["I has two brothers.", "I am have two brothers.", "I haves two brothers."], "Subjek I berpasangan dengan have.", F],
  ["Which sentence is correct?", "My mother is a nurse.", ["My mother are a nurse.", "My mother am a nurse.", "My mother a nurse."], "My mother = she, jadi pakai is.", F],
  ["A boy child in a family is a ___.", "son", ["daughter", "uncle", "aunt"], "Son = anak laki-laki, daughter = anak perempuan.", F],
  ["“Adik perempuan” in English is ___.", "younger sister", ["older sister", "younger brother", "older brother"], "Younger = lebih muda, older = lebih tua.", F],
  ["I ___ up at 5.30 every morning.", "wake", ["wakes", "waking", "am wake"], "Subjek I memakai kata kerja dasar: wake.", D],
  ["She ___ breakfast at 6.30.", "has", ["have", "haves", "having"], "She/he/it memakai has pada simple present.", D],
  ["We ___ to school at seven o’clock.", "go", ["goes", "going", "are go"], "Subjek we memakai go.", D],
  ["My father ___ to work by motorbike.", "goes", ["go", "going", "are go"], "He/she/it + kata kerja + s/es: goes.", D],
  ["Doni ___ his teeth after breakfast.", "brushes", ["brush", "brushing", "brushs"], "Kata berakhiran sh ditambah -es: brushes.", D],
  ["“Mandi” in English is ___.", "take a bath", ["make a bath", "do a bath", "play a bath"], "Take a bath = mandi.", D],
  ["Which sentence is correct?", "I go to bed at nine.", ["I goes to bed at nine.", "I going to bed at nine.", "I am go to bed at nine."], "I + go. Tidur = go to bed.", D],
  ["06.15 is ___.", "a quarter past six", ["a quarter to six", "half past six", "six fifty"], "A quarter past = lewat lima belas menit.", D],
  ["07.45 is ___.", "a quarter to eight", ["a quarter past seven", "half past seven", "seven fourteen"], "A quarter to = kurang lima belas menit.", D],
  ["I eat lunch ___ noon.", "at", ["in", "on", "to"], "Waktu tertentu memakai at: at noon, at seven.", D],
  ["I take a bath ___ the morning.", "in", ["at", "on", "of"], "in the morning, in the afternoon, in the evening.", D],
  ["Rina ___ her homework in the evening.", "does", ["do", "doing", "dos"], "Do homework. Untuk she, pakai does.", D],
  ["My mother ___ dinner for the family every night.", "cooks", ["cook", "cooking", "cookes"], "She/he/it + s: cooks.", D],
  ["On Sunday morning, we ___ to church.", "go", ["goes", "going", "are go"], "We + go.", D],
  ["I ___ TV after dinner.", "watch", ["watches", "watching", "am watch"], "Subjek I + watch.", D],
  ["“Every day” means ___.", "setiap hari", ["setiap minggu", "kadang-kadang", "tidak pernah"], "Every day = setiap hari.", D],
  ["“Never” means ___.", "tidak pernah", ["selalu", "sering", "kadang-kadang"], "Never = tidak pernah, always = selalu.", D]
];

const PAIRS = [
  ["mother","ibu"],["father","ayah"],["sister","saudara perempuan"],["brother","saudara laki-laki"],["grandmother","nenek"],["grandfather","kakek"],
  ["uncle","paman"],["aunt","bibi"],["cousin","sepupu"],["parents","orang tua"],["wake up","bangun"],["take a bath","mandi"],
  ["have breakfast","sarapan"],["go to school","pergi ke sekolah"],["study","belajar"],["sleep","tidur"],["cook","memasak"],["sweep","menyapu"],
  ["help","membantu"],["watch TV","menonton TV"]
];

const WORDS = [
  ["MOTHER","👩","ibu"],["FATHER","👨","ayah"],["SISTER","👧","saudara perempuan"],["BROTHER","👦","saudara laki-laki"],
  ["GRANDMOTHER","👵","nenek"],["GRANDFATHER","👴","kakek"],["FAMILY","👨‍👩‍👧‍👦","keluarga"],["BREAKFAST","🍳","sarapan"],
  ["HOMEWORK","📚","pekerjaan rumah"],["SCHOOL","🏫","sekolah"],["SLEEP","😴","tidur"],["LUNCH","🍱","makan siang"],
  ["DINNER","🍽️","makan malam"],["SHOWER","🚿","mandi"],["TEETH","🦷","gigi"],["SUNDAY","⛪","hari Minggu"]
];

const SENT = [
  ["I wake up at five thirty.", "Saya bangun pukul lima tiga puluh."],
  ["She has breakfast with her family.", "Dia sarapan bersama keluarganya."],
  ["My father goes to work by motorbike.", "Ayahku pergi bekerja naik motor."],
  ["We go to church on Sunday.", "Kami pergi ke gereja pada hari Minggu."],
  ["My mother cooks dinner every night.", "Ibuku memasak makan malam setiap malam."],
  ["He brushes his teeth after breakfast.", "Dia menyikat giginya setelah sarapan."],
  ["They study English at school.", "Mereka belajar Bahasa Inggris di sekolah."],
  ["My grandmother lives in Waikabubak.", "Nenekku tinggal di Waikabubak."],
  ["I have two brothers and one sister.", "Aku punya dua saudara laki-laki dan satu saudara perempuan."],
  ["My aunt is a teacher.", "Bibiku adalah seorang guru."],
  ["I do my homework in the evening.", "Aku mengerjakan PR pada malam hari."],
  ["Our family is small and happy.", "Keluarga kami kecil dan bahagia."]
];

// [adegan, pernyataan, benar?, penjelasan]
const TF = [
  ["fam","Sinta is Budi’s sister.",true,"Sinta adalah anak perempuan Mr. Yosef, jadi dia saudara perempuan Budi."],
  ["fam","Mrs. Maria is Budi’s aunt.",false,"Mrs. Maria adalah ibu Budi (mother), bukan bibi (aunt)."],
  ["fam","Mr. Petrus is Budi’s grandfather.",true,"Mr. Petrus adalah ayah dari Mr. Yosef, jadi kakek Budi."],
  ["fam","Dedi is Budi’s father.",false,"Dedi adalah adik laki-laki Budi (brother), bukan ayah."],
  ["fam","Mr. Yosef and Mrs. Maria are Budi’s parents.",true,"Parents = orang tua."],
  ["fam","Budi has two sisters.",false,"Budi hanya punya satu saudara perempuan (Sinta) dan satu adik laki-laki (Dedi)."],
  ["fam","Mrs. Lidia is Budi’s grandmother.",true,"Mrs. Lidia adalah ibu dari Mr. Yosef, jadi nenek Budi."],
  ["fam","There are seven people in this family.",true,"Petrus, Lidia, Yosef, Maria, Budi, Sinta, dan Dedi: tujuh orang."],
  ["day","Sinta takes a bath at six o’clock.",true,"Di jadwal: 06.00 mandi."],
  ["day","Sinta goes to school at half past six.",false,"Dia berangkat sekolah pukul 07.00 (seven o’clock)."],
  ["day","Sinta has lunch at one o’clock.",true,"13.00 adalah pukul satu siang."],
  ["day","Sinta does her homework in the morning.",false,"PR dikerjakan pukul 19.00, yaitu malam hari (evening)."],
  ["day","Sinta goes to bed at nine o’clock.",true,"21.00 = nine o’clock malam."],
  ["day","Sinta wakes up at six o’clock.",false,"Dia bangun pukul 05.30 (half past five)."],
  ["day","Sinta plays with her friends at four o’clock.",true,"16.00 = four o’clock."],
  ["day","Sinta has breakfast after she takes a bath.",true,"Mandi pukul 06.00, sarapan pukul 06.30."]
];
const SCENES = {
  fam: `<div class="scene"><div class="stitle">Keluarga Budi</div>
    <div class="trow"><span class="pp">👴<b>Mr. Petrus</b></span><span class="pp">👵<b>Mrs. Lidia</b></span></div>
    <div class="trow"><span class="pp">👨<b>Mr. Yosef</b></span><span class="pp">👩<b>Mrs. Maria</b></span></div>
    <div class="trow"><span class="pp me">👦<b>Budi</b></span><span class="pp">👧<b>Sinta</b></span><span class="pp">👶<b>Dedi</b></span></div>
    <p class="note">Mr. Petrus dan Mrs. Lidia adalah orang tua Mr. Yosef. Budi, Sinta, dan Dedi adalah anak Mr. Yosef dan Mrs. Maria. Dedi adalah yang termuda.</p></div>`,
  day: `<div class="scene"><div class="stitle">Hari Sinta</div><div class="sched">
    <div class="sc"><span>🛏️</span><div>05.30<small>wake up</small></div></div>
    <div class="sc"><span>🚿</span><div>06.00<small>take a bath</small></div></div>
    <div class="sc"><span>🍳</span><div>06.30<small>have breakfast</small></div></div>
    <div class="sc"><span>🏫</span><div>07.00<small>go to school</small></div></div>
    <div class="sc"><span>🍱</span><div>13.00<small>have lunch</small></div></div>
    <div class="sc"><span>⚽</span><div>16.00<small>play with friends</small></div></div>
    <div class="sc"><span>📚</span><div>19.00<small>do homework</small></div></div>
    <div class="sc"><span>😴</span><div>21.00<small>go to bed</small></div></div></div></div>`
};

/* ---------- Topik tambahan: Food and Drinks, My House, Clean Environment ---------- */
const FD = "Food and Drinks", H = "My House", E = "Clean Environment";
const CHIP = { [F]: "sea", [D]: "grape", [FD]: "tang", [H]: "leaf", [E]: "coral" };

Q.push(
  // Food and Drinks
  ["I drink a glass of ___ every morning.", "milk", ["rice", "bread", "fish"], "Kita drink (minum) milk. Rice, bread, dan fish dimakan (eat).", FD],
  ["She eats ___ with fish for lunch.", "rice", ["tea", "milk", "juice"], "Rice = nasi. Nasi dimakan, jadi pakai eat.", FD],
  ["Which one is a drink?", "Water", ["Bread", "Rice", "Fish"], "Water = air minum.", FD],
  ["“Would you like some tea?” — “Yes, ___.”", "please", ["welcome", "sorry", "fine"], "Menerima tawaran dengan sopan: Yes, please.", FD],
  ["I’m thirsty. I want to drink ___.", "water", ["rice", "bread", "a banana"], "Thirsty = haus, jadi butuh minuman: water.", FD],
  ["I’m hungry. I want to ___ some noodles.", "eat", ["drink", "sleep", "wash"], "Hungry = lapar. Noodles dimakan: eat.", FD],
  ["“Sayuran” in English is ___.", "vegetables", ["fruits", "noodles", "drinks"], "Vegetables = sayuran, fruits = buah-buahan.", FD],
  ["“What would you like?” — “___ a cup of coffee, please.”", "I’d like", ["I likes", "I am like", "I’m want"], "I’d like = saya ingin (sopan saat memesan).", FD],
  ["There ___ some milk in the glass.", "is", ["are", "am", "be"], "Milk tidak bisa dihitung, jadi pakai is.", FD],
  ["There ___ three apples on the table.", "are", ["is", "am", "be"], "Three apples jamak, jadi pakai are.", FD],
  ["Which one is yellow?", "Banana", ["Cabbage", "Carrot", "Spinach"], "Banana = pisang, warnanya kuning.", FD],
  ["Apple, mango, and banana are ___.", "fruits", ["vegetables", "drinks", "meat"], "Fruits = buah-buahan.", FD],
  ["Sugar is ___.", "sweet", ["sour", "salty", "bitter"], "Sweet = manis, salty = asin, bitter = pahit.", FD],
  // My House
  ["We sleep in the ___.", "bedroom", ["kitchen", "bathroom", "garage"], "Bedroom = kamar tidur.", H],
  ["My mother cooks in the ___.", "kitchen", ["bedroom", "garden", "bathroom"], "Kitchen = dapur.", H],
  ["We take a bath in the ___.", "bathroom", ["living room", "garage", "garden"], "Bathroom = kamar mandi.", H],
  ["We watch TV in the ___.", "living room", ["bathroom", "garage", "kitchen"], "Living room = ruang tamu atau ruang keluarga.", H],
  ["My father parks his car in the ___.", "garage", ["kitchen", "bedroom", "dining room"], "Garage = garasi.", H],
  ["We eat dinner in the ___.", "dining room", ["bathroom", "garage", "bedroom"], "Dining room = ruang makan.", H],
  ["There are flowers and trees in the ___.", "garden", ["kitchen", "bedroom", "bathroom"], "Garden = taman atau kebun.", H],
  ["The ___ is on the wall. It shows the time.", "clock", ["lamp", "sofa", "broom"], "Clock = jam dinding.", H],
  ["Where is the lamp? — It’s ___ the table.", "on", ["in", "at", "to"], "On = di atas permukaan: on the table.", H],
  ["“Di bawah” in English is ___.", "under", ["behind", "between", "above"], "Under = di bawah, above = di atas, behind = di belakang.", H],
  ["There ___ two bedrooms in my house.", "are", ["is", "am", "be"], "Two bedrooms jamak, jadi pakai are.", H],
  ["The bed is ___ the bedroom.", "in", ["on", "at", "to"], "In the bedroom = di dalam kamar tidur.", H],
  // Clean Environment
  ["We must put trash in the ___.", "trash bin", ["river", "street", "garden"], "Trash bin = tempat sampah.", E],
  ["Don’t throw rubbish in the ___!", "river", ["trash bin", "bag", "box"], "Membuang sampah ke sungai (river) merusak lingkungan.", E],
  ["___ throw trash on the street!", "Don’t", ["Doesn’t", "Not", "Isn’t"], "Don’t + kata kerja dipakai untuk larangan.", E],
  ["Let’s ___ our classroom every day.", "clean", ["dirty", "break", "lose"], "Clean = membersihkan atau bersih.", E],
  ["We use a ___ to sweep the floor.", "broom", ["spoon", "pencil", "bottle"], "Broom = sapu, sweep = menyapu.", E],
  ["Plastic bottles can be ___.", "recycled", ["eaten", "worn", "sung"], "Recycle = mendaur ulang.", E],
  ["Planting trees is good for the ___.", "environment", ["kitchen", "bedroom", "shoe"], "Environment = lingkungan.", E],
  ["A clean river is ___ for fish.", "good", ["bad", "dirty", "angry"], "Good = baik. Sungai bersih baik untuk ikan.", E],
  ["A banana peel is ___ waste.", "organic", ["plastic", "metal", "glass"], "Organic waste = sampah organik yang bisa membusuk.", E],
  ["We should save ___.", "water", ["trash", "dirt", "mud"], "Save water = hemat air.", E],
  ["“Sampah” in English is ___.", "trash", ["soap", "tree", "fish"], "Trash, rubbish, atau garbage = sampah.", E],
  ["Which sentence is correct?", "Please keep the school clean.", ["Please keeps the school clean.", "Please keep clean school the.", "Please keep the school cleans."], "Pola: keep + benda + sifat (adjective).", E]
);

PAIRS.push(
  ["rice","nasi"],["bread","roti"],["egg","telur"],["water","air"],["milk","susu"],["tea","teh"],
  ["bedroom","kamar tidur"],["kitchen","dapur"],["bathroom","kamar mandi"],["living room","ruang tamu"],["garage","garasi"],["garden","taman"],
  ["trash bin","tempat sampah"],["broom","sapu"],["soap","sabun"],["tree","pohon"],["river","sungai"],["recycle","daur ulang"],["clean","bersih"],["dirty","kotor"]
);

WORDS.push(
  ["RICE","🍚","nasi"],["BREAD","🍞","roti"],["BANANA","🍌","pisang"],["MILK","🥛","susu"],["KITCHEN","🍳","dapur"],["BEDROOM","🛏️","kamar tidur"],
  ["GARAGE","🚗","garasi"],["GARDEN","🌻","taman"],["BROOM","🧹","sapu"],["TREE","🌳","pohon"],["RIVER","🏞️","sungai"],["SOAP","🧼","sabun"]
);

SENT.push(
  ["I eat rice and fish for lunch.", "Aku makan nasi dan ikan saat makan siang."],
  ["She drinks a glass of milk every morning.", "Dia minum segelas susu setiap pagi."],
  ["I would like a cup of tea, please.", "Aku mau secangkir teh, tolong."],
  ["My mother cooks in the kitchen.", "Ibuku memasak di dapur."],
  ["There are two bedrooms in my house.", "Ada dua kamar tidur di rumahku."],
  ["We watch TV in the living room.", "Kami menonton TV di ruang tamu."],
  ["My house has a small garden.", "Rumahku punya taman kecil."],
  ["Please put the trash in the bin.", "Tolong buang sampah ke tempat sampah."],
  ["We clean our classroom every day.", "Kami membersihkan kelas kami setiap hari."],
  ["Don’t throw rubbish in the river.", "Jangan buang sampah ke sungai."],
  ["We must keep our environment clean.", "Kita harus menjaga lingkungan tetap bersih."]
);

TF.push(
  ["house","Budi’s house has two bedrooms.",true,"Di gambar ada 2 bedrooms (kamar tidur)."],
  ["house","There are three bathrooms in Budi’s house.",false,"Hanya ada satu bathroom (kamar mandi)."],
  ["house","Budi’s family has a garage.",true,"Di gambar ada 1 garage (garasi)."],
  ["house","Budi’s house has a swimming pool.",false,"Tidak ada kolam renang di gambar."],
  ["house","The garden is in front of the house.",true,"Tertulis: in front of the house (di depan rumah)."],
  ["house","There is a TV in the living room.",true,"Living room (ruang tamu) dilengkapi TV."],
  ["house","Budi’s mother cooks in the garage.",false,"Memasak di kitchen (dapur), bukan di garage."],
  ["house","Budi’s house has one kitchen.",true,"Di gambar ada 1 kitchen."],
  ["menu","Tea costs three thousand rupiah.",true,"Teh: Rp 3.000."],
  ["menu","Milk costs five thousand rupiah.",true,"Susu: Rp 5.000."],
  ["menu","Noodles cost ten thousand rupiah.",false,"Mi: Rp 8.000 (eight thousand)."],
  ["menu","Cake costs six thousand rupiah.",true,"Kue: Rp 6.000."],
  ["menu","Rice and fish cost ten thousand rupiah.",true,"Nasi dan ikan: Rp 10.000."],
  ["menu","You can buy pizza at this warung.",false,"Tidak ada pizza di daftar menu."],
  ["menu","Coffee costs three thousand rupiah.",false,"Kopi: Rp 4.000 (four thousand)."],
  ["menu","Tea and coffee are drinks.",true,"Tea dan coffee adalah minuman (drinks)."],
  ["env","Sinta sweeps the floor on Monday.",true,"Senin: Sinta menyapu lantai."],
  ["env","Budi waters the plants on Tuesday.",false,"Selasa: Budi mengosongkan tempat sampah. Dedi menyiram tanaman hari Rabu."],
  ["env","Dedi waters the plants on Wednesday.",true,"Rabu: Dedi menyiram tanaman."],
  ["env","Rina sorts the rubbish on Friday.",true,"Jumat: Rina memilah sampah."],
  ["env","The class cleans the room on Saturday.",false,"Jadwal piket hanya Senin sampai Jumat."],
  ["env","Budi empties the trash bin.",true,"Budi mengosongkan tempat sampah (Selasa)."],
  ["env","Sinta sorts the rubbish on Friday.",false,"Yang memilah sampah hari Jumat adalah Rina."],
  ["env","Andi cleans the board on Thursday.",true,"Kamis: Andi membersihkan papan."]
);

SCENES.house = `<div class="scene"><div class="stitle">Rumah Budi</div><div class="sched">
    <div class="sc"><span>🛏️</span><div>2 bedrooms</div></div>
    <div class="sc"><span>🍳</span><div>1 kitchen</div></div>
    <div class="sc"><span>🛁</span><div>1 bathroom</div></div>
    <div class="sc"><span>🛋️</span><div>1 living room<small>with a TV</small></div></div>
    <div class="sc"><span>🚗</span><div>1 garage</div></div>
    <div class="sc"><span>🌻</span><div>1 garden<small>in front of the house</small></div></div></div></div>`;
SCENES.menu = `<div class="scene"><div class="stitle">Warung Bu Maria</div><div class="sched">
    <div class="sc"><span>🍚</span><div>Rice and fish<small>Rp 10.000</small></div></div>
    <div class="sc"><span>🍜</span><div>Noodles<small>Rp 8.000</small></div></div>
    <div class="sc"><span>🍰</span><div>Cake<small>Rp 6.000</small></div></div>
    <div class="sc"><span>🍵</span><div>Tea<small>Rp 3.000</small></div></div>
    <div class="sc"><span>☕</span><div>Coffee<small>Rp 4.000</small></div></div>
    <div class="sc"><span>🥛</span><div>Milk<small>Rp 5.000</small></div></div></div></div>`;
SCENES.env = `<div class="scene"><div class="stitle">Piket kelas</div><div class="sched">
    <div class="sc"><span>🧹</span><div>Monday<small>Sinta sweeps the floor</small></div></div>
    <div class="sc"><span>🗑️</span><div>Tuesday<small>Budi empties the trash bin</small></div></div>
    <div class="sc"><span>🌱</span><div>Wednesday<small>Dedi waters the plants</small></div></div>
    <div class="sc"><span>🧼</span><div>Thursday<small>Andi cleans the board</small></div></div>
    <div class="sc"><span>♻️</span><div>Friday<small>Rina sorts the rubbish</small></div></div></div></div>`;

// [kata, arti, emoji, topik, jenis (khusus Food and Drinks)]
const VOC = [
  ["mother","ibu","👩",F],["father","ayah","👨",F],["sister","saudara perempuan","👧",F],["brother","saudara laki-laki","👦",F],
  ["grandmother","nenek","👵",F],["grandfather","kakek","👴",F],["baby","bayi","👶",F],
  ["school","sekolah","🏫",D],["homework","pekerjaan rumah","📚",D],["sleep","tidur","😴",D],["lunch","makan siang","🍱",D],["church","gereja","⛪",D],["clock","jam","⏰",D],
  ["rice","nasi","🍚",FD,"food"],["bread","roti","🍞",FD,"food"],["egg","telur","🥚",FD,"food"],["fish","ikan","🐟",FD,"food"],["chicken","ayam","🍗",FD,"food"],
  ["vegetables","sayuran","🥬",FD,"food"],["apple","apel","🍎",FD,"food"],["banana","pisang","🍌",FD,"food"],["orange","jeruk","🍊",FD,"food"],["mango","mangga","🥭",FD,"food"],
  ["corn","jagung","🌽",FD,"food"],["noodles","mi","🍜",FD,"food"],["soup","sup","🍲",FD,"food"],["cake","kue","🍰",FD,"food"],["tomato","tomat","🍅",FD,"food"],["potato","kentang","🥔",FD,"food"],
  ["water","air","💧",FD,"drink"],["milk","susu","🥛",FD,"drink"],["tea","teh","🍵",FD,"drink"],["coffee","kopi","☕",FD,"drink"],["juice","jus","🥤",FD,"drink"],
  ["bedroom","kamar tidur","🛏️",H],["kitchen","dapur","🍳",H],["bathroom","kamar mandi","🛁",H],["living room","ruang tamu","🛋️",H],["dining room","ruang makan","🍽️",H],
  ["garage","garasi","🚗",H],["garden","taman","🌻",H],["door","pintu","🚪",H],["lamp","lampu","💡",H],["toilet","toilet","🚽",H],
  ["broom","sapu","🧹",E],["soap","sabun","🧼",E],["tree","pohon","🌳",E],["river","sungai","🏞️",E],["earth","bumi","🌍",E],
  ["recycle","daur ulang","♻️",E],["trash bin","tempat sampah","🗑️",E],["plant","tanaman","🌱",E],["leaf","daun","🍃",E]
];

// [pertanyaan, ruangan yang benar, penjelasan]
const ROOMS = { "bedroom": "🛏️", "kitchen": "🍳", "bathroom": "🛁", "living room": "🛋️", "garage": "🚗", "garden": "🌻" };
const HQ = [
  ["Where do we sleep?", "bedroom", "We sleep in the bedroom (kamar tidur)."],
  ["Where does Mother cook?", "kitchen", "Mother cooks in the kitchen (dapur)."],
  ["Where do we take a bath?", "bathroom", "We take a bath in the bathroom (kamar mandi)."],
  ["Where do we watch TV?", "living room", "We watch TV in the living room (ruang tamu)."],
  ["Where does Father park the car?", "garage", "Father parks the car in the garage (garasi)."],
  ["Where do we plant flowers?", "garden", "We plant flowers in the garden (taman)."],
  ["Where do we brush our teeth?", "bathroom", "We brush our teeth in the bathroom."],
  ["Where do we cook rice?", "kitchen", "We cook rice in the kitchen."],
  ["Where do we welcome guests?", "living room", "We welcome guests in the living room."],
  ["Where do we read a bedtime story?", "bedroom", "We read a bedtime story in the bedroom."],
  ["Where do we keep the motorbike?", "garage", "We keep the motorbike in the garage."],
  ["Where do we wash our hands after the toilet?", "bathroom", "We wash our hands in the bathroom."]
];

// [emoji, nama Inggris, arti, tong sampah]
const BINS = { organic: "🟢 organic (sampah organik)", plastic: "🟡 plastic (plastik)", paper: "🔵 paper (kertas)" };
const BINWHY = { organic: "mudah membusuk dan bisa jadi pupuk.", plastic: "sulit terurai, kumpulkan untuk didaur ulang.", paper: "bisa didaur ulang menjadi kertas baru." };
const SORTI = [
  ["🍌","banana peel","kulit pisang","organic"],["🍎","apple core","bonggol apel","organic"],["🍃","dry leaves","daun kering","organic"],
  ["🐟","fish bone","tulang ikan","organic"],["🥚","egg shell","kulit telur","organic"],
  ["🧴","plastic bottle","botol plastik","plastic"],["🛍️","plastic bag","kantong plastik","plastic"],["🥤","plastic cup","gelas plastik","plastic"],
  ["🍬","candy wrapper","bungkus permen","plastic"],
  ["📰","newspaper","koran","paper"],["📦","cardboard box","kardus","paper"],["📄","used paper","kertas bekas","paper"],["✉️","envelope","amplop","paper"]
];

// Cerita untuk uji menyimak: tiap cerita punya 3 pertanyaan [tanya, jawaban, [pilihan salah], penjelasan]
const STORIES = [
  { title: "Budi’s Family", c: F,
    text: "My name is Budi. I have a big family. There are seven people in my family. My father is a farmer and my mother is a teacher. I have one sister and one little brother. My grandfather and grandmother live with us. We are a happy family.",
    qs: [
      ["How many people are there in Budi’s family?", "Seven", ["Five", "Nine", "Three"], "Di cerita: “There are seven people in my family.”"],
      ["What is Budi’s mother’s job?", "She is a teacher.", ["She is a farmer.", "She is a nurse.", "She is a driver."], "Di cerita: “My mother is a teacher.” Ayahnya yang petani (farmer)."],
      ["Who lives with Budi’s family?", "His grandparents", ["His uncle", "His cousin", "His friend"], "Di cerita: “My grandfather and grandmother live with us.”"]
    ] },
  { title: "Sinta’s Morning", c: D,
    text: "Sinta wakes up at half past five every morning. She takes a bath at six o’clock. Then she has breakfast with her family at half past six. She goes to school at seven o’clock. After school, she helps her mother at home.",
    qs: [
      ["What time does Sinta wake up?", "Half past five", ["Six o’clock", "Half past six", "Seven o’clock"], "Di cerita: “wakes up at half past five.”"],
      ["What does Sinta do at six o’clock?", "She takes a bath.", ["She has breakfast.", "She goes to school.", "She helps her mother."], "Di cerita: “She takes a bath at six o’clock.”"],
      ["Who does Sinta help after school?", "Her mother", ["Her father", "Her teacher", "Her brother"], "Di cerita: “she helps her mother at home.”"]
    ] },
  { title: "At the Warung", c: FD,
    text: "Doni and his sister go to a warung after school. Doni is hungry, so he eats rice and fish. His sister is thirsty. She drinks a glass of tea. The rice and fish cost ten thousand rupiah. The tea costs three thousand rupiah.",
    qs: [
      ["Why does Doni eat rice and fish?", "He is hungry.", ["He is thirsty.", "He is sleepy.", "He is angry."], "Di cerita: “Doni is hungry, so he eats rice and fish.”"],
      ["What does Doni’s sister drink?", "Tea", ["Milk", "Coffee", "Water"], "Di cerita: “She drinks a glass of tea.”"],
      ["How much is the tea?", "Three thousand rupiah", ["Thirteen thousand rupiah", "Ten thousand rupiah", "Five thousand rupiah"], "Di cerita: “The tea costs three thousand rupiah.” Hati-hati: three beda dengan thirteen."]
    ] },
  { title: "Rina’s House", c: H,
    text: "Rina lives in a small house in Waikabubak. There are two bedrooms, one kitchen, and one bathroom. There is a living room with a big sofa. Rina’s father parks his motorbike in the garage. In front of the house, there is a garden with beautiful flowers.",
    qs: [
      ["How many bedrooms are there in Rina’s house?", "Two", ["One", "Three", "Four"], "Di cerita: “There are two bedrooms.”"],
      ["Where does Rina’s father park his motorbike?", "In the garage", ["In the kitchen", "In the garden", "In the bedroom"], "Di cerita: “parks his motorbike in the garage.”"],
      ["What is in front of the house?", "A garden", ["A garage", "A kitchen", "A river"], "Di cerita: “In front of the house, there is a garden.”"]
    ] },
  { title: "Clean School Day", c: E,
    text: "On Friday, our class cleans the school. Sinta sweeps the floor. Budi puts the trash in the trash bin. Dedi waters the plants. We do not throw rubbish on the ground. A clean school is good for everyone.",
    qs: [
      ["When does the class clean the school?", "On Friday", ["On Monday", "On Sunday", "On Saturday"], "Di cerita: “On Friday, our class cleans the school.”"],
      ["What does Dedi do?", "He waters the plants.", ["He sweeps the floor.", "He washes the windows.", "He sorts the plastic."], "Di cerita: “Dedi waters the plants.”"],
      ["Where does Budi put the trash?", "In the trash bin", ["In the river", "On the ground", "In the garden"], "Di cerita: “Budi puts the trash in the trash bin.”"]
    ] },
  { title: "Sunday in Sumba", c: F,
    text: "On Sunday, my family goes to church in the morning. After church, we eat lunch together at home. My mother cooks rice, vegetables, and chicken. In the afternoon, my brother and I play football in the garden. In the evening, we watch TV in the living room.",
    qs: [
      ["Where does the family go on Sunday morning?", "To church", ["To school", "To the market", "To the river"], "Di cerita: “my family goes to church in the morning.”"],
      ["What does the mother cook?", "Rice, vegetables, and chicken", ["Noodles and cake", "Fish and bread", "Soup and eggs"], "Di cerita: “My mother cooks rice, vegetables, and chicken.”"],
      ["What do the children do in the afternoon?", "They play football.", ["They watch TV.", "They sleep.", "They study."], "Di cerita: “my brother and I play football in the garden.” Menonton TV dilakukan malam hari."]
    ] }
];

/* ---------- Simpanan ---------- */
const KEY = "english-island-v1";
let S = { name: "", xp: 0, mute: false, best: { quiz: 0, match: 0, scramble: 0, sent: 0, tf: 0, pic: 0, listen: 0, story: 0, house: 0, sort: 0, fd: 0, rush: 0 } };
try { const d = JSON.parse(localStorage.getItem(KEY) || "null"); if (d) S = { ...S, ...d, best: { ...S.best, ...(d.best || {}) } }; } catch (e) {}
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };

const LEVELS = [[0,"Pemula 🌱"],[100,"Penjelajah 🧭"],[250,"Jagoan 🦸"],[500,"Juara 🏆"]];
function levelInfo() {
  let i = 0; LEVELS.forEach((l, k) => { if (S.xp >= l[0]) i = k; });
  const cur = LEVELS[i], nxt = LEVELS[i + 1];
  const pct = nxt ? Math.round((S.xp - cur[0]) / (nxt[0] - cur[0]) * 100) : 100;
  return { label: cur[1], pct };
}
function drawXP() {
  const L = levelInfo();
  $("#xp").innerHTML = `<b>${L.label}</b><span style="font-weight:600;font-size:.8rem;color:var(--muted)">${S.xp} poin</span><div class="bar"><i style="width:${L.pct}%"></i></div>`;
}
const starsHTML = (n, max = 3) => Array.from({ length: max }, (_, i) => `<span class="${i < n ? "" : "off"}">★</span>`).join("");
const screen = $("#screen");
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let timers = [];
let editingName = false;
let rushIV = null;
const later = (fn, ms) => { const t = setTimeout(fn, ms); timers.push(t); };
const clearTimers = () => { timers.forEach(clearTimeout); timers = []; clearInterval(rushIV); stopSay(); };

/* ---------- Audio (berkas di folder audio/) ---------- */
const MUSIC = new Audio("audio/musik-sumba.wav");
MUSIC.loop = true; MUSIC.volume = 0; MUSIC.preload = "auto";
const SFX_FILES = { ok: "benar", no: "salah", tap: "ketuk", pair: "cocok", miss: "meleset", win: "menang", done: "selesai" };
const SFX_AUDIO = {};
Object.entries(SFX_FILES).forEach(([k, f]) => { const a = new Audio("audio/" + f + ".wav"); a.preload = "auto"; SFX_AUDIO[k] = a; });
let playing = false, fadeT = null;
function fadeTo(v, ms, done) {
  clearInterval(fadeT);
  const s = MUSIC.volume, n = Math.max(1, ms / 20); let i = 0;
  fadeT = setInterval(() => {
    i++; MUSIC.volume = Math.max(0, Math.min(1, s + (v - s) * i / n));
    if (i >= n) { clearInterval(fadeT); if (done) done(); }
  }, 20);
}
function startMusic() {
  if (playing || S.mute) return;
  playing = true;
  const p = MUSIC.play();
  if (p && p.then) p.then(() => fadeTo(0.5, 600)).catch(() => { playing = false; updateSoundBtn(); });
  else fadeTo(0.5, 600);
}
function stopMusic() {
  if (!playing) return;
  playing = false;
  fadeTo(0, 350, () => { if (!playing) MUSIC.pause(); });
}
function sfx(k) {
  if (S.mute) return;
  const a = SFX_AUDIO[k]; if (!a) return;
  const c = a.cloneNode(); c.volume = 0.9;
  const p = c.play(); if (p && p.catch) p.catch(() => {});
}
function updateSoundBtn() {
  const b = $("#snd"); if (!b) return;
  b.textContent = S.mute ? "🔇" : "🔊";
  b.setAttribute("aria-pressed", String(!S.mute));
  b.setAttribute("aria-label", S.mute ? "Nyalakan suara" : "Matikan suara");
  const h = $("#mhint"); if (h) h.hidden = playing || S.mute;
}
function syncMusic() {
  const want = !S.mute && !!$(".islands") && !$("#splash");
  if (want) startMusic(); else stopMusic();
  updateSoundBtn();
}
function toggleSound() {
  S.mute = !S.mute; save();
  if (!S.mute) sfx("tap");
  syncMusic();
}
document.addEventListener("visibilitychange", () => {
  if (document.hidden) MUSIC.pause(); else if (playing) { const p = MUSIC.play(); if (p && p.catch) p.catch(() => {}); }
});

/* ---------- Menu utama ---------- */
function island(act, cls, icon, title, desc, key) {
  return `<button class="island ${cls}" data-act="${act}"><span class="pic" aria-hidden="true">${icon}</span>
    <h3>${title}</h3><p>${desc}</p>
    <span class="stars" aria-label="Bintang terbaik ${S.best[key]} dari 3">${starsHTML(S.best[key])}</span></button>`;
}
function home() {
  clearTimers(); drawXP();
  const nameBlock = (S.name && !editingName) ? `
    <div class="hello"><h2>Halo, ${esc(S.name)}!</h2>
    <p>Pilih satu pulau dan kumpulkan bintang.</p>
    <div class="topics"><span class="chip sea">My Family</span><span class="chip grape">Daily Activities</span><span class="chip tang">Food and Drinks</span><span class="chip leaf">My House</span><span class="chip coral">Clean Environment</span><button class="btn ghost" data-act="rename" style="padding:2px 14px;font-size:.9rem;box-shadow:0 3px 0 var(--line)">Ganti nama</button></div></div>` : `
    <div class="card name-form"><h2>${S.name ? "Ganti nama" : "Selamat datang!"}</h2>
    <label for="nm" style="font-weight:600;color:var(--muted)">Siapa namamu?</label>
    <input id="nm" maxlength="20" autocomplete="off" placeholder="Tulis namamu di sini" value="${esc(S.name)}">
    <div class="row"><button class="btn leaf" data-act="saveName">${S.name ? "Simpan nama" : "Mulai bermain"}</button>${S.name ? '<button class="btn ghost" data-act="cancelName">Batal</button>' : ""}</div></div>`;
  screen.innerHTML = nameBlock + `<p class="note" id="mhint" style="margin:0 0 4px">🎵 Ketuk layar untuk memutar musik Sumba</p>` +
    `<h3 class="grp">Semua topik</h3><div class="islands">` +
    island("quiz", "", "🧠", "Kuis kilat", "10 soal pilihan ganda dari lima topik.", "quiz") +
    island("match", "coral", "🃏", "Pasangkan kartu", "Buka dua kartu dan cocokkan kata Inggris dengan artinya.", "match") +
    island("scramble", "grape", "🔤", "Susun huruf", "Susun huruf yang acak menjadi kata Inggris yang benar.", "scramble") +
    island("sent", "leaf", "🧩", "Susun kalimat", "Urutkan kata-kata menjadi kalimat yang tepat.", "sent") +
    island("tf", "tang", "✅", "Benar atau salah", "Baca bagan atau jadwal, lalu nilai pernyataannya.", "tf") +
    island("pic", "teal", "🖼️", "Tebak gambar", "Lihat gambar dan pilih kata Inggris yang tepat.", "pic") +
    island("listen", "pink", "🎧", "Dengar dan pilih", "Dengarkan ucapan kata, lalu pilih kata yang benar.", "listen") +
    island("story", "indigo", "📖", "Cerita bersuara", "Dengarkan dua cerita pendek, lalu jawab pertanyaannya.", "story") +
    island("rush", "slate", "⏱️", "Adu cepat 30 detik", "Jawab sebanyak mungkin sebelum waktu habis.", "rush") +
    `</div><h3 class="grp">Pulau khusus topik</h3><div class="islands">` +
    island("house", "brown", "🏠", "Keliling rumah", "My House: di ruangan mana kegiatan dilakukan?", "house") +
    island("sort", "lime", "♻️", "Pilah sampah", "Clean Environment: pilih tong sampah yang tepat.", "sort") +
    island("fd", "sun", "🍽️", "Makanan atau minuman", "Food and Drinks: kita makan atau minum?", "fd") +
    `</div>`;
  updateSoundBtn();
  if (editingName) { const i = $("#nm"); if (i) { i.focus(); i.select(); } }
}

/* ---------- Kuis ---------- */
let G = {};
function mcStart(key, items, o = {}) {
  clearTimers();
  G = { mode: "mc", key, i: 0, score: 0, locked: false, items, fmt: o.fmt, cols: o.cols, xp: o.xp };
  quizView();
}
function quiz() {
  mcStart("quiz", shuffle(Q).slice(0, 10).map(([q, a, w, t, c]) => ({ q, a, t, c, opts: shuffle([a, ...w]) })));
}
function quizView() {
  const it = G.items[G.i], fmt = G.fmt || (o => esc(o));
  const centered = it.big || it.html ? ' style="text-align:center"' : "";
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    <span class="chip ${CHIP[it.c] || "sea"}">${esc(it.c)}</span>
    ${it.html || ""}${it.big ? `<div class="pic-big" aria-hidden="true">${it.big}</div>` : ""}
    <p class="q ${it.mask ? "mask" : ""}"${centered}>${esc(it.q)}</p>
    <div class="opts ${G.cols === 2 ? "two" : ""}">${it.opts.map((o, k) => `<button class="opt" data-act="opt" data-k="${k}">${fmt(o)}</button>`).join("")}</div>
    <div id="fb"></div>`;
  if (it.say && it.auto !== false) later(() => say(it.say, 0, it.sk), 350);
}
function pickOpt(btn) {
  if (G.locked) return; G.locked = true;
  stopSay();
  const it = G.items[G.i], k = +btn.dataset.k, ok = it.opts[k] === it.a;
  sfx(ok ? "ok" : "no");
  document.querySelectorAll(".opt").forEach((b, i) => {
    b.disabled = true;
    if (it.opts[i] === it.a) b.classList.add("right");
    else if (i === k) b.classList.add("wrong");
  });
  if (ok) G.score++;
  const last = G.i === G.items.length - 1;
  $("#fb").innerHTML = `
    <div class="tip ${ok ? "good" : "bad"}"><b>${ok ? "Benar! 🎉" : "Belum tepat."}</b> ${esc(it.t)}</div>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn ${ok ? "leaf" : ""}" data-act="next">${last ? "Lihat hasil" : "Soal berikutnya"}</button></div>`;
  $("#fb .btn").focus();
}
function nextQ() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, r = s / G.items.length, stars = r >= 0.9 ? 3 : r >= 0.6 ? 2 : r >= 0.3 ? 1 : 0;
    return finish(G.key || "quiz", `${s} dari ${G.items.length} soal benar`, stars, s * (G.xp || 10));
  }
  G.i++; G.locked = false; quizView();
}

/* ---------- Pasangkan kartu ---------- */
function match() {
  clearTimers();
  const pairs = shuffle(PAIRS).slice(0, 6);
  const cards = shuffle(pairs.flatMap(([en, id], p) => [{ p, t: en, l: "en" }, { p, t: id, l: "id" }]));
  G = { mode: "match", cards, open: [], moves: 0, found: 0, locked: false };
  screen.innerHTML = `
    <div class="gtop"><h2 class="disp" style="font-size:1.5rem">Pasangkan kartu</h2>
      <span class="chip" id="mv" style="margin-left:auto">0 langkah</span></div>
    <p style="margin:0 0 14px;color:var(--muted);font-weight:600">Kartu biru berisi kata Inggris, kartu kuning berisi artinya.</p>
    <div class="grid">${cards.map((c, i) => `<button class="tile" data-act="flip" data-i="${i}" aria-label="Kartu ${i + 1}">?</button>`).join("")}</div>`;
}
function setTile(i) {
  const c = G.cards[i], el = document.querySelector(`.tile[data-i="${i}"]`);
  const show = c.up || c.done;
  el.className = "tile" + (c.done ? " done" : c.up ? ` up ${c.l}` : "") + (show && c.t.length > 10 ? " sm" : "");
  el.textContent = show ? c.t : "?";
}
function flip(i) {
  const c = G.cards[i];
  if (G.locked || c.up || c.done) return;
  sfx("tap"); c.up = true; setTile(i); G.open.push(i);
  if (G.open.length < 2) return;
  G.moves++; $("#mv").textContent = G.moves + " langkah";
  const [a, b] = G.open.map(k => G.cards[k]);
  if (a.p === b.p) {
    a.done = b.done = true; sfx("pair"); G.open.forEach(setTile); G.open = []; G.found++;
    if (G.found === 6) later(() => { const m = G.moves, stars = m <= 9 ? 3 : m <= 13 ? 2 : 1; finish("match", `Selesai dalam ${m} langkah`, stars, stars * 20); }, 700);
  } else {
    G.locked = true; sfx("miss");
    later(() => { G.open.forEach(k => { G.cards[k].up = false; setTile(k); }); G.open = []; G.locked = false; }, 850);
  }
}

/* ---------- Susun huruf ---------- */
function scramble() {
  clearTimers();
  G = { mode: "scramble", i: 0, score: 0, items: shuffle(WORDS).slice(0, 8) };
  scrView();
}
function scrView() {
  const [w, emo, hint] = G.items[G.i];
  let L = shuffle(w.split("")); let n = 0; while (L.join("") === w && n++ < 9) L = shuffle(L);
  G.tiles = L.map(ch => ({ ch, used: false })); G.slots = Array(w.length).fill(null); G.locked = false;
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    <div class="pic-big" aria-hidden="true">${emo}</div>
    <div class="hint">Artinya: ${esc(hint)}</div>
    <div class="slots" id="slots"></div><div class="pool" id="pool"></div>
    <div class="row" style="justify-content:center;margin-top:8px">
      <button class="btn ghost" data-act="clear">Hapus</button>
      <button class="btn ghost" data-act="mix">Acak lagi</button>
      <button class="btn coral" data-act="skip">Lewati</button></div>`;
  scrDraw();
}
function scrDraw() {
  $("#slots").innerHTML = G.slots.map((t, i) => `<button class="slot ${t !== null ? "fill" : ""}" data-act="slot" data-i="${i}" aria-label="Huruf ke-${i + 1}">${t !== null ? G.tiles[t].ch : ""}</button>`).join("");
  $("#pool").innerHTML = G.tiles.map((t, i) => `<button class="ltr ${t.used ? "used" : ""}" data-act="tile" data-i="${i}">${t.ch}</button>`).join("");
}
function tapTile(i) {
  if (G.locked || G.tiles[i].used) return;
  const s = G.slots.indexOf(null); if (s < 0) return;
  sfx("tap"); G.slots[s] = i; G.tiles[i].used = true; scrDraw();
  if (G.slots.indexOf(null) < 0) checkWord();
}
function tapSlot(i) { if (G.locked || G.slots[i] === null) return; G.tiles[G.slots[i]].used = false; G.slots[i] = null; scrDraw(); }
function checkWord() {
  const w = G.items[G.i][0], got = G.slots.map(t => G.tiles[t].ch).join("");
  G.locked = true; const box = $("#slots");
  if (got === w) { G.score++; sfx("ok"); box.classList.add("ok"); later(nextWord, 1000); }
  else { sfx("no"); box.classList.add("no"); later(() => { clearSlots(); G.locked = false; }, 700); }
}
function clearSlots() { G.slots.fill(null); G.tiles.forEach(t => t.used = false); scrDraw(); }
function mixTiles() { if (G.locked) return; clearSlots(); G.tiles = shuffle(G.tiles); scrDraw(); }
function skipWord() {
  if (G.locked) return; G.locked = true;
  const w = G.items[G.i][0];
  $("#slots").innerHTML = w.split("").map(c => `<span class="slot fill">${c}</span>`).join("");
  $("#pool").innerHTML = `<p class="tip bad" style="width:100%;margin:0">Jawabannya: <b>${w}</b></p>`;
  later(nextWord, 1600);
}
function nextWord() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, stars = s >= 7 ? 3 : s >= 5 ? 2 : s >= 3 ? 1 : 0;
    return finish("scramble", `${s} dari ${G.items.length} kata benar`, stars, s * 10);
  }
  G.i++; scrView();
}

/* ---------- Susun kalimat ---------- */
function sent() {
  clearTimers();
  G = { mode: "sent", i: 0, score: 0, items: shuffle(SENT).slice(0, 6) };
  sentView();
}
function sentView() {
  const [s, tr] = G.items[G.i], words = s.split(" ");
  let L = shuffle(words); let n = 0; while (L.join(" ") === s && n++ < 9) L = shuffle(L);
  G.target = s; G.tiles = L.map(w => ({ ch: w, used: false })); G.slots = []; G.locked = false;
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    <div class="hint" style="text-align:left;font-size:1.1rem">Artinya: ${esc(tr)}</div>
    <div class="sline" id="sline" aria-live="polite"></div>
    <div class="pool" id="pool"></div>
    <div class="row" style="justify-content:center;margin-top:8px">
      <button class="btn ghost" data-act="wclear">Hapus</button>
      <button class="btn coral" data-act="wskip">Lewati</button></div>`;
  sentDraw();
}
function sentDraw() {
  $("#sline").innerHTML = G.slots.length ? G.slots.map((t, i) => `<button class="wchip in" data-act="wslot" data-i="${i}">${esc(G.tiles[t].ch)}</button>`).join("") : `<span class="ph">Ketuk kata di bawah untuk menyusun kalimat</span>`;
  $("#pool").innerHTML = G.tiles.map((t, i) => `<button class="wchip ${t.used ? "used" : ""}" data-act="wtile" data-i="${i}">${esc(t.ch)}</button>`).join("");
}
function tapWord(i) {
  if (G.locked || G.tiles[i].used) return;
  sfx("tap"); G.slots.push(i); G.tiles[i].used = true; sentDraw();
  if (G.slots.length === G.tiles.length) checkSent();
}
function tapWordSlot(i) {
  if (G.locked) return;
  const t = G.slots.splice(i, 1)[0]; G.tiles[t].used = false; sentDraw();
}
function clearWords() { if (G.locked) return; G.slots = []; G.tiles.forEach(t => t.used = false); sentDraw(); }
function checkSent() {
  const got = G.slots.map(t => G.tiles[t].ch).join(" "); G.locked = true; const box = $("#sline");
  if (got === G.target) { G.score++; sfx("ok"); box.classList.add("ok"); box.querySelectorAll(".wchip").forEach(b => { b.style.background = "#fff"; b.style.color = "#148A55"; b.style.boxShadow = "none"; }); later(nextSent, 1500); }
  else { sfx("no"); box.classList.add("no"); later(() => { box.classList.remove("no"); G.locked = false; clearWords(); }, 800); }
}
function skipSent() {
  if (G.locked) return; G.locked = true;
  $("#sline").innerHTML = `<span class="ph" style="color:var(--ink)">Jawabannya: <b>${esc(G.target)}</b></span>`;
  $("#pool").innerHTML = "";
  later(nextSent, 2200);
}
function nextSent() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, stars = s >= 6 ? 3 : s >= 4 ? 2 : s >= 2 ? 1 : 0;
    return finish("sent", `${s} dari ${G.items.length} kalimat benar`, stars, s * 15);
  }
  G.i++; sentView();
}

/* ---------- Benar atau salah ---------- */
function tf() {
  clearTimers();
  G = { mode: "tf", i: 0, score: 0, locked: false, items: shuffle(TF).slice(0, 8) };
  tfView();
}
function tfView() {
  const [sc, st] = G.items[G.i]; G.locked = false;
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i style="width:${G.i / G.items.length * 100}%"></i></div></div>
      <span class="chip">${G.i + 1} dari ${G.items.length}</span></div>
    ${SCENES[sc]}
    <p class="stmt">${esc(st)}</p>
    <div class="row"><button class="btn leaf big" data-act="ans" data-v="1">Benar</button><button class="btn coral big" data-act="ans" data-v="0">Salah</button></div>
    <div id="fb"></div>`;
}
function tfAnswer(btn) {
  if (G.locked) return; G.locked = true;
  const [, , truth, why] = G.items[G.i], ok = (btn.dataset.v === "1") === truth;
  if (ok) G.score++;
  sfx(ok ? "ok" : "no");
  document.querySelectorAll(".big").forEach(b => b.disabled = true);
  const last = G.i === G.items.length - 1;
  $("#fb").innerHTML = `
    <div class="tip ${ok ? "good" : "bad"}"><b>${ok ? "Tepat! 🎉" : "Belum tepat."}</b> Pernyataan ini ${truth ? "benar" : "salah"}. ${esc(why)}</div>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn ${ok ? "leaf" : ""}" data-act="tfnext">${last ? "Lihat hasil" : "Berikutnya"}</button></div>`;
  $("#fb .btn").focus();
}
function tfNext() {
  if (G.i >= G.items.length - 1) {
    const s = G.score, stars = s >= 7 ? 3 : s >= 5 ? 2 : s >= 3 ? 1 : 0;
    return finish("tf", `${s} dari ${G.items.length} jawaban tepat`, stars, s * 10);
  }
  G.i++; tfView();
}

/* ---------- Pulau baru: gambar, suara, cerita, rumah, sampah, makanan, adu cepat ---------- */
const pick = (arr, n) => shuffle(arr).slice(0, n);
function vocOpts(v) {
  const same = VOC.filter(x => x[3] === v[3] && x !== v), other = VOC.filter(x => x[3] !== v[3]);
  const d = [...shuffle(same), ...shuffle(other)].slice(0, 3).map(x => x[0]);
  return shuffle([v[0], ...d]);
}
const SPEECH = {"w:mother": "audio/ucapan/w-mother.mp3", "w:father": "audio/ucapan/w-father.mp3", "w:sister": "audio/ucapan/w-sister.mp3", "w:brother": "audio/ucapan/w-brother.mp3", "w:grandmother": "audio/ucapan/w-grandmother.mp3", "w:grandfather": "audio/ucapan/w-grandfather.mp3", "w:baby": "audio/ucapan/w-baby.mp3", "w:school": "audio/ucapan/w-school.mp3", "w:homework": "audio/ucapan/w-homework.mp3", "w:sleep": "audio/ucapan/w-sleep.mp3", "w:lunch": "audio/ucapan/w-lunch.mp3", "w:church": "audio/ucapan/w-church.mp3", "w:clock": "audio/ucapan/w-clock.mp3", "w:rice": "audio/ucapan/w-rice.mp3", "w:bread": "audio/ucapan/w-bread.mp3", "w:egg": "audio/ucapan/w-egg.mp3", "w:fish": "audio/ucapan/w-fish.mp3", "w:chicken": "audio/ucapan/w-chicken.mp3", "w:vegetables": "audio/ucapan/w-vegetables.mp3", "w:apple": "audio/ucapan/w-apple.mp3", "w:banana": "audio/ucapan/w-banana.mp3", "w:orange": "audio/ucapan/w-orange.mp3", "w:mango": "audio/ucapan/w-mango.mp3", "w:corn": "audio/ucapan/w-corn.mp3", "w:noodles": "audio/ucapan/w-noodles.mp3", "w:soup": "audio/ucapan/w-soup.mp3", "w:cake": "audio/ucapan/w-cake.mp3", "w:tomato": "audio/ucapan/w-tomato.mp3", "w:potato": "audio/ucapan/w-potato.mp3", "w:water": "audio/ucapan/w-water.mp3", "w:milk": "audio/ucapan/w-milk.mp3", "w:tea": "audio/ucapan/w-tea.mp3", "w:coffee": "audio/ucapan/w-coffee.mp3", "w:juice": "audio/ucapan/w-juice.mp3", "w:bedroom": "audio/ucapan/w-bedroom.mp3", "w:kitchen": "audio/ucapan/w-kitchen.mp3", "w:bathroom": "audio/ucapan/w-bathroom.mp3", "w:living room": "audio/ucapan/w-living-room.mp3", "w:dining room": "audio/ucapan/w-dining-room.mp3", "w:garage": "audio/ucapan/w-garage.mp3", "w:garden": "audio/ucapan/w-garden.mp3", "w:door": "audio/ucapan/w-door.mp3", "w:lamp": "audio/ucapan/w-lamp.mp3", "w:toilet": "audio/ucapan/w-toilet.mp3", "w:broom": "audio/ucapan/w-broom.mp3", "w:soap": "audio/ucapan/w-soap.mp3", "w:tree": "audio/ucapan/w-tree.mp3", "w:river": "audio/ucapan/w-river.mp3", "w:earth": "audio/ucapan/w-earth.mp3", "w:recycle": "audio/ucapan/w-recycle.mp3", "w:trash bin": "audio/ucapan/w-trash-bin.mp3", "w:plant": "audio/ucapan/w-plant.mp3", "w:leaf": "audio/ucapan/w-leaf.mp3", "s:Budi’s Family": "audio/ucapan/s-budi-s-family.mp3", "s:Sinta’s Morning": "audio/ucapan/s-sinta-s-morning.mp3", "s:At the Warung": "audio/ucapan/s-at-the-warung.mp3", "s:Rina’s House": "audio/ucapan/s-rina-s-house.mp3", "s:Clean School Day": "audio/ucapan/s-clean-school-day.mp3", "s:Sunday in Sumba": "audio/ucapan/s-sunday-in-sumba.mp3"};
let SPEAK = null;
const ttsOK = () => "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;
const hasSpeech = () => Object.keys(SPEECH).length > 0 || ttsOK();
function stopSay() {
  if (SPEAK) { try { SPEAK.pause(); } catch (e) {} SPEAK = null; }
  try { if (ttsOK()) speechSynthesis.cancel(); } catch (e) {}
}
function ttsSay(t, rate) {
  try {
    if (!ttsOK()) return;
    const u = new SpeechSynthesisUtterance(t); u.lang = "en-US"; u.rate = rate || 0.85;
    const v = (speechSynthesis.getVoices() || []).find(x => /^en/i.test(x.lang)); if (v) u.voice = v;
    setTimeout(() => { try { speechSynthesis.speak(u); } catch (e) {} }, 60);
  } catch (e) {}
}
// Memutar rekaman ucapan bawaan (folder audio/ucapan). Jika tidak ada atau gagal, memakai suara HP.
function say(t, rate, key) {
  stopSay();
  const f = key && SPEECH[key];
  if (!f) return ttsSay(t, rate);
  const a = new Audio(f); SPEAK = a;
  a.playbackRate = rate && rate < 0.8 ? 0.75 : 1;
  a.onerror = () => ttsSay(t, rate);
  const p = a.play(); if (p && p.catch) p.catch(() => {});
}
function noSpeech() {
  clearTimers();
  screen.innerHTML = `<div class="card result"><h2>Suara ucapan belum tersedia</h2>
    <p>Perangkat ini belum mendukung suara ucapan Bahasa Inggris. Coba periksa pengaturan Text-to-speech di HP, atau pilih pulau lain.</p>
    <div class="row" style="justify-content:center;margin-top:16px"><button class="btn ghost" data-act="home">Menu utama</button></div></div>`;
}

function picGame() {
  mcStart("pic", pick(VOC, 10).map(v => ({ big: v[2], q: "What is this?", a: v[0], opts: vocOpts(v), t: `${v[2]} = ${v[0]} (${v[1]})`, c: v[3] })));
}

const WORD_BTN = `<div class="row" style="justify-content:center;margin:12px 0 4px"><button class="btn sun" data-act="say" style="font-size:1.4rem;padding:14px 26px">🔊 Dengarkan</button><button class="btn ghost" data-act="sayslow" style="font-size:1.1rem;padding:12px 16px">🐢 Pelan</button></div>`;
function listenGame() {
  if (!hasSpeech()) return noSpeech();
  mcStart("listen", pick(VOC, 10).map(v => ({ html: WORD_BTN, say: v[0], sk: "w:" + v[0], q: "Kata apa yang kamu dengar?", a: v[0], opts: vocOpts(v), t: `Kata yang diucapkan: ${v[0]} (${v[1]})`, c: v[3] })));
}

const STORY_BTN = `<div class="row" style="justify-content:center;margin:8px 0 4px"><button class="btn sun" data-act="say" style="font-size:1.25rem;padding:14px 22px">🔊 Dengarkan cerita</button><button class="btn ghost" data-act="sayslow" style="font-size:1.1rem;padding:12px 16px">🐢 Pelan</button></div>`;
function storyGame() {
  if (!hasSpeech()) return noSpeech();
  const items = pick(STORIES, 2).flatMap((s, si) => s.qs.map(([q, a, w, t], qi) => ({
    html: `<p class="note" style="text-align:center;margin:10px 0 0">Cerita ${si + 1} dari 2: ${esc(s.title)}</p>` + STORY_BTN,
    say: s.text, sk: "s:" + s.title, auto: qi === 0, q, a, opts: shuffle([a, ...w]), t, c: s.c
  })));
  mcStart("story", items, { xp: 15 });
}

function houseGame() {
  mcStart("house", pick(HQ, 10).map(([q, a, t]) => ({ q, a, opts: Object.keys(ROOMS), t, c: H })), { cols: 2, fmt: o => `${ROOMS[o]} ${esc(o)}` });
}

function sortGame() {
  mcStart("sort", pick(SORTI, 10).map(([em, en, id, bin]) => ({
    big: em, q: `${en} (${id})`, a: bin, opts: Object.keys(BINS), t: `${en} masuk tong ${bin}: ${BINWHY[bin]}`, c: E
  })), { fmt: o => esc(BINS[o]) });
}

function foodGame() {
  const items = VOC.filter(v => v[4]);
  const foods = pick(items.filter(v => v[4] === "food"), 5), drinks = pick(items.filter(v => v[4] === "drink"), 5);
  mcStart("fd", shuffle([...foods, ...drinks]).map(v => ({
    big: v[2], q: `${v[0]} (${v[1]})`, a: v[4], opts: ["food", "drink"],
    t: `${v[0]} = ${v[1]}. We ${v[4] === "food" ? "eat" : "drink"} ${v[0]}.`, c: FD
  })), { cols: 2, fmt: o => o === "food" ? "🍽️ food (makanan)" : "🥤 drink (minuman)" });
}

function rushGame() {
  clearTimers();
  G = { mode: "rush", score: 0, locked: false, t0: Date.now(), last: null };
  rushNext(); rushIV = setInterval(rushTick, 100);
}
function rushNext() {
  let v; do { v = VOC[Math.floor(Math.random() * VOC.length)]; } while (G.last === v);
  G.last = v; G.locked = false;
  const opts = vocOpts(v), left = Math.max(0, 30 - (Date.now() - G.t0) / 1000);
  G.cur = { v, opts };
  screen.innerHTML = `
    <div class="gtop"><div class="prog"><div class="bar"><i id="rbar" style="width:${left / 30 * 100}%"></i></div></div>
      <span class="chip" id="rt">${Math.ceil(left)} detik</span><span class="chip sea">Benar: ${G.score}</span></div>
    <div class="pic-big" aria-hidden="true">${v[2]}</div>
    <p class="q" style="text-align:center">${esc(v[1])}</p>
    <div class="opts two">${opts.map((o, k) => `<button class="opt" data-act="ropt" data-k="${k}">${esc(o)}</button>`).join("")}</div>`;
}
function rushAnswer(btn) {
  if (G.locked) return; G.locked = true;
  const k = +btn.dataset.k, ok = G.cur.opts[k] === G.cur.v[0];
  if (ok) G.score++;
  sfx(ok ? "ok" : "no");
  document.querySelectorAll(".opt").forEach((b, i) => {
    if (G.cur.opts[i] === G.cur.v[0]) b.classList.add("right"); else if (i === k) b.classList.add("wrong");
  });
  later(rushNext, 380);
}
function rushTick() {
  const left = 30 - (Date.now() - G.t0) / 1000;
  if (left <= 0) {
    clearInterval(rushIV);
    const s = G.score;
    return finish("rush", `${s} jawaban benar dalam 30 detik`, s >= 12 ? 3 : s >= 8 ? 2 : s >= 4 ? 1 : 0, s * 5);
  }
  const b = $("#rbar"); if (b) b.style.width = (left / 30 * 100) + "%";
  const t = $("#rt"); if (t) t.textContent = Math.ceil(left) + " detik";
}

/* ---------- Hasil ---------- */
function finish(mode, summary, stars, gain) {
  clearTimers();
  const newBest = stars > S.best[mode];
  if (newBest) S.best[mode] = stars;
  S.xp += gain; save(); drawXP();
  const n = esc(S.name || "teman");
  const msg = stars === 3 ? `Luar biasa, ${n}!` : stars === 2 ? `Bagus sekali, ${n}!` : stars === 1 ? `Lumayan, ${n}. Ayo coba lagi!` : `Jangan menyerah, ${n}. Coba sekali lagi!`;
  screen.innerHTML = `
    <div class="card result">
      <div class="big" aria-label="${stars} dari 3 bintang">${starsHTML(stars)}</div>
      <h2>${msg}</h2><p>${esc(summary)}</p>
      <div class="gain">+${gain} poin</div>
      ${newBest && stars > 0 ? `<p style="color:var(--leaf);font-weight:800">Rekor bintang baru!</p>` : ""}
      <div class="row" style="justify-content:center;margin-top:16px">
        <button class="btn leaf" data-act="${mode}">Main lagi</button>
        <button class="btn ghost" data-act="home">Menu utama</button></div>
    </div>`;
  sfx(stars >= 2 ? "win" : "done");
  if (stars >= 2) confetti();
}
function confetti() {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const cols = ["#FFC93C", "#1B9AF5", "#FF5D73", "#22B573", "#7C4DFF", "#FF8A3D"];
  for (let i = 0; i < 44; i++) {
    const d = document.createElement("i"); d.className = "confetti";
    d.style.left = Math.random() * 100 + "vw"; d.style.background = cols[i % cols.length];
    d.style.animationDelay = Math.random() * .8 + "s"; d.style.animationDuration = 2 + Math.random() * 1.6 + "s";
    document.body.appendChild(d); setTimeout(() => d.remove(), 4600);
  }
}

/* ---------- Event ---------- */
const actions = {
  home: () => { editingName = false; home(); }, rename: () => { editingName = true; home(); }, cancelName: () => { editingName = false; home(); },
  quiz, match, scramble, sent, tf, next: nextQ,
  pic: picGame, listen: listenGame, story: storyGame, house: houseGame, sort: sortGame, fd: foodGame, rush: rushGame,
  say: () => say(G.items[G.i].say, 0, G.items[G.i].sk), sayslow: () => say(G.items[G.i].say, 0.6, G.items[G.i].sk), ropt: b => rushAnswer(b),
  opt: b => pickOpt(b), flip: b => flip(+b.dataset.i),
  tile: b => tapTile(+b.dataset.i), slot: b => tapSlot(+b.dataset.i),
  clear: () => { if (!G.locked) clearSlots(); }, mix: mixTiles, skip: skipWord,
  wtile: b => tapWord(+b.dataset.i), wslot: b => tapWordSlot(+b.dataset.i), wclear: clearWords, wskip: skipSent,
  ans: b => tfAnswer(b), tfnext: tfNext,
  saveName: () => {
    const v = ($("#nm").value || "").trim();
    if (!v) { $("#nm").focus(); return; }
    S.name = v; editingName = false; save(); home();
  }
};
document.addEventListener("click", e => {
  if (e.target.closest("#snd")) { toggleSound(); return; }
  const b = e.target.closest("[data-act]");
  if (b) { const f = actions[b.dataset.act]; if (f) f(b); }
  syncMusic();
});
document.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.id === "nm") actions.saveName(); });
home();

/* ---------- Layar pembuka (video logo) ---------- */
(function () {
  const sp = $("#splash"), v = $("#sv");
  if (!sp || !v) return;
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) { sp.remove(); return; }
  let done = false;
  const close = () => {
    if (done) return; done = true;
    sp.removeAttribute("id"); sp.classList.add("out");
    try { v.pause(); } catch (e) {}
    setTimeout(() => sp.remove(), 600);
  };
  $("#ssk").addEventListener("click", close);
  $("#ssn").addEventListener("click", () => {
    v.muted = !v.muted;
    $("#ssn").textContent = v.muted ? "🔇" : "🔊";
    $("#ssn").setAttribute("aria-pressed", String(!v.muted));
    if (!v.muted) { const q = v.play(); if (q && q.catch) q.catch(() => {}); }
  });
  v.addEventListener("ended", close);
  v.addEventListener("error", close);
  const src = v.querySelector("source"); if (src) src.addEventListener("error", close);
  const p = v.play(); if (p && p.catch) p.catch(close);
  setTimeout(close, 12000);
})();
