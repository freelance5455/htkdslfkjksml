
const $=id=>document.getElementById(id);
let stops=[];

function pad(n){return String(n).padStart(2,'0')}
function todayStr(){const d=new Date();return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`}
function showToast(t){const x=$('toast');x.textContent=t;x.style.display='block';setTimeout(()=>x.style.display='none',1800)}
function init(){
 $('today').textContent=todayStr().replaceAll('-','/');
 $('date').value=todayStr();
 $('changeDate').value=todayStr();
 const s=JSON.parse(localStorage.getItem('gyomu_settings')||'{}');
 $('driver').value=s.driver||'';$('vehicle').value=s.vehicle||'';
 $('setDriver').value=s.driver||'';$('setVehicle').value=s.vehicle||'';
 addStop();
 calc();
}
function addStop(data={}) {
 const id=Date.now()+Math.random();
 stops.push({id,...data});
 renderStops();
}
function removeStop(id){stops=stops.filter(x=>x.id!==id);renderStops()}
function renderStops(){
 const box=$('stops');box.innerHTML='';
 stops.forEach((s,i)=>{
  const d=document.createElement('div');d.className='stop';
  const selected=s.placeSelect||((s.place||'')==='横浜緑営業所'?'横浜緑営業所':((s.place||'')==='配達エリア'?'配達エリア':((s.place||'')?'その他':'')));
  const custom=s.customPlace||((selected==='その他'&&s.place)?s.place:'');
  d.innerHTML=`<div class="muted">経過地点 ${i+1}</div>
  <div class="stopgrid">
  <select data-k="placeSelect">
    <option value="">地点を選択</option>
    <option value="横浜緑営業所" ${selected==='横浜緑営業所'?'selected':''}>横浜緑営業所</option>
    <option value="配達エリア" ${selected==='配達エリア'?'selected':''}>配達エリア</option>
    <option value="その他" ${selected==='その他'?'selected':''}>その他</option>
  </select>
  <input class="custom-place" placeholder="その他の地点を入力" value="${esc(custom)}" data-k="customPlace" style="display:${selected==='その他'?'block':'none'}">
  <input type="time" value="${s.arrive||''}" data-k="arrive">
  <input type="time" value="${s.leave||''}" data-k="leave">
  <input placeholder="備考" value="${esc(s.note||'')}" data-k="note">
  <button class="danger" style="grid-column:2/-1" onclick="removeStop(${s.id})">削除</button>
  </div>`;
  d.querySelectorAll('input,select').forEach(inp=>inp.oninput=()=>{
    s[inp.dataset.k]=inp.value;
    if(inp.dataset.k==='placeSelect'){
      s.placeSelect=inp.value;
      s.place=inp.value==='その他'?(s.customPlace||''):inp.value;
      const cp=d.querySelector('.custom-place');
      cp.style.display=inp.value==='その他'?'block':'none';
    } else if(inp.dataset.k==='customPlace'){
      s.place=inp.value;
    }
  });
  box.appendChild(d);
 });
}
function esc(v){return String(v).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}
function calc(){
 const a=parseFloat($('startKm').value),b=parseFloat($('endKm').value);
 $('distance').textContent=`業務に従事した距離：${Number.isFinite(a)&&Number.isFinite(b)&&b>=a?(b-a):'—'} km`;
}
$('startKm').oninput=calc;$('endKm').oninput=calc;

document.querySelectorAll('.tabs button').forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');
 document.querySelectorAll('.tab').forEach(x=>x.style.display='none');$(btn.dataset.tab).style.display='block';
 if(btn.dataset.tab==='history')renderHistory();
});

function collect(){
 const a=parseFloat($('startKm').value),b=parseFloat($('endKm').value);
 return {id:Date.now(),driver:$('driver').value,vehicle:$('vehicle').value,date:$('date').value,
 startPlace:$('startPlace').value,startTime:$('startTime').value,startKm:$('startKm').value,
 endPlace:$('endPlace').value,endTime:$('endTime').value,endKm:$('endKm').value,
 distance:Number.isFinite(a)&&Number.isFinite(b)&&b>=a?b-a:'',
 stops:JSON.parse(JSON.stringify(stops)),
 changePlace:$('changePlace').value,changeDate:$('changeDate').value,changeTime:$('changeTime').value};
}
function saveRecord(){
 const r=collect(); if(!r.date){showToast('日にちを入力してね');return}
 const all=JSON.parse(localStorage.getItem('gyomu_records')||'[]');
 const idx=all.findIndex(x=>x.date===r.date);
 if(idx>=0)all[idx]=r;else all.push(r);
 all.sort((a,b)=>a.date.localeCompare(b.date));
 localStorage.setItem('gyomu_records',JSON.stringify(all));
 saveSettings(true);showToast(idx>=0?'記録を更新したよ':'今日の記録を保存したよ');
}
function loadRecord(r){
 $('driver').value=r.driver||'';$('vehicle').value=r.vehicle||'';$('date').value=r.date||'';
 $('startPlace').value='自宅';$('startTime').value=r.startTime||'';$('startKm').value=r.startKm||'';
 $('endPlace').value='自宅';$('endTime').value=r.endTime||'';$('endKm').value=r.endKm||'';
 stops=(r.stops||[]).map(s=>({...s,id:Date.now()+Math.random()}));if(!stops.length)addStop();else renderStops();calc();
 document.querySelector('[data-tab="input"]').click();showToast('記録を読み込んだよ');
}
function renderHistory(){
 const all=JSON.parse(localStorage.getItem('gyomu_records')||'[]');
 const f=$('filterMonth').value;
 const list=f?all.filter(r=>r.date.startsWith(f)):all;
 const box=$('historyList');box.innerHTML='';
 if(!list.length){box.innerHTML='<div class="empty">まだ保存された記録がないよ</div>';return}
 [...list].reverse().forEach(r=>{
  const d=document.createElement('div');d.className='history-item';
  d.innerHTML=`<strong>${r.date}　${esc(r.driver||'')}</strong>
  <div class="muted">${esc(r.startPlace||'')} → ${esc(r.endPlace||'')}　｜ ${r.distance!==''?r.distance+' km':'距離未入力'}</div>
  <div class="actions"><button class="secondary" onclick='loadRecordById(${r.id})'>編集</button><button class="primary" onclick='printRecordById(${r.id})'>PDF / 印刷</button><button class="danger" onclick='deleteRecord(${r.id})'>削除</button></div>`;
  box.appendChild(d);
 });
}
function loadRecordById(id){const r=JSON.parse(localStorage.getItem('gyomu_records')||'[]').find(x=>x.id===id);if(r)loadRecord(r)}
function printRecordById(id){const r=JSON.parse(localStorage.getItem('gyomu_records')||'[]').find(x=>x.id===id);if(r){loadRecord(r);setTimeout(previewPrint,80)}}
function deleteRecord(id){if(!confirm('この記録を削除する？'))return;localStorage.setItem('gyomu_records',JSON.stringify(JSON.parse(localStorage.getItem('gyomu_records')||'[]').filter(x=>x.id!==id)));renderHistory()}
function clearFilter(){$('filterMonth').value='';renderHistory()}
function saveSettings(silent=false){
 const s={driver:$('setDriver').value||$('driver').value,vehicle:$('setVehicle').value||$('vehicle').value};
 localStorage.setItem('gyomu_settings',JSON.stringify(s));
 if(!silent)showToast('設定を保存したよ');
}
function exportData(){
 const blob=new Blob([localStorage.getItem('gyomu_records')||'[]'],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='業務記録バックアップ.json';a.click();URL.revokeObjectURL(a.href);
}
function deleteAll(){if(confirm('保存した全記録を削除する？')){localStorage.removeItem('gyomu_records');renderHistory();showToast('削除したよ')}}
function escPrint(v){return esc(v||'')}
function buildPrintMarkup(r){
 const rows=(r.stops||[]).slice(0,10).map(s=>`<tr><td>${escPrint(s.placeSelect==='その他'?(s.customPlace||'その他'):((s.placeSelect||s.place)||''))}</td><td>${escPrint(s.arrive)}</td><td>${escPrint(s.leave)}</td><td>${escPrint(s.note)}</td></tr>`).join('');
 return `<div class="previewPaper print-page">
 <div class="print-title">業務の記録</div>
 <table class="print-table">
 <tr><th class="label">運転者の氏名</th><td colspan="3" class="value">${escPrint(r.driver)}</td></tr>
 <tr><th>車両番号</th><td>${escPrint(r.vehicle)}</td><th>アルコール検知器</th><td>${escPrint(r.alcoholUsed||'有')}</td></tr>
 <tr><th>日にち</th><td>${escPrint(r.date)}</td><th>酒気帯びの有無</th><td>${escPrint(r.drinkingStatus||'無')}</td></tr>
 <tr><th>業務開始地点・日時</th><td>自宅</td><td colspan="2">${escPrint(r.startTime)}</td></tr>
 <tr><th>業務終了地点・日時</th><td>自宅</td><td colspan="2">${escPrint(r.endTime)}</td></tr>
 <tr><th>走行距離計の表示</th><td class="distancebox">出発時 ${escPrint(r.startKm)} km</td><td class="distancebox">到着時 ${escPrint(r.endKm)} km</td><td class="distancebox">${r.distance!==''?escPrint(r.distance):'—'} km</td></tr>
 <tr><th>業務に従事した距離</th><td colspan="3" class="distancebox">${r.distance!==''?escPrint(r.distance):'—'} km</td></tr>
 </table>
 <div class="stops"><table class="print-table">
 <tr><th>主な経過地点</th><th>到着時刻</th><th>発時刻</th><th>備考</th></tr>
 ${rows || '<tr><td></td><td></td><td></td><td></td></tr>'.repeat(5)}
 </table></div>
 <div class="notes">業務記録</div>
 </div>`;
}
function drawPdfCanvas(r){
 const c=document.createElement('canvas');
 c.width=1240;c.height=1754;
 const ctx=c.getContext('2d');
 ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);
 ctx.fillStyle='#111';ctx.strokeStyle='#111';
 const font='Noto Sans JP, Yu Gothic, Meiryo, sans-serif';
 const left=55,right=1185,width=1130;
 ctx.textAlign='center';ctx.font=`bold 30px ${font}`;ctx.fillText('業務の記録',620,65);
 ctx.textAlign='left';ctx.font=`bold 16px ${font}`;
 let y=100;
 function cell(x,w,label,value,lh=52){
   ctx.strokeRect(x,y,w,lh); ctx.font=`bold 15px ${font}`;ctx.fillText(label,x+8,y+20);
   ctx.font=`15px ${font}`;ctx.fillText(String(value??''),x+8,y+43);
 }
 // Header rows
 cell(left,1130,'運転者の氏名',r.driver||''); y+=52;
 cell(left,565,'車両番号',r.vehicle||''); cell(left+565,565,'日にち',r.date||''); y+=52;
 cell(left,565,'アルコール検知器',r.alcoholUsed||'有'); cell(left+565,565,'酒気帯びの有無',r.drinkingStatus||'無'); y+=52;
 cell(left,565,'業務開始地点・時刻','自宅　'+(r.startTime||'')); cell(left+565,565,'業務終了地点・時刻','自宅　'+(r.endTime||'')); y+=52;
 cell(left,565,'出発時の走行距離',`${r.startKm||''} km`); cell(left+565,565,'到着時の走行距離',`${r.endKm||''} km`); y+=52;
 cell(left,1130,'業務に従事した距離',`${r.distance!==''?r.distance:'—'} km`); y+=70;
 // stops table
 ctx.font=`bold 17px ${font}`;ctx.fillText('主な経過地点',left,y);y+=28;
 const cols=[380,180,180,390]; const heads=['地点','到着時刻','発時刻','備考'];
 let x=left;
 heads.forEach((hd,i)=>{ctx.strokeRect(x,y,cols[i],42);ctx.font=`bold 15px ${font}`;ctx.fillText(hd,x+8,y+27);x+=cols[i]});
 y+=42;
 const arr=(r.stops||[]).slice(0,10);
 for(let i=0;i<10;i++){
   const s=arr[i]||{}; const place=s.placeSelect==='その他'?(s.customPlace||'その他'):((s.placeSelect||s.place)||'');
   const vals=[place,s.arrive||'',s.leave||'',s.note||''];x=left;
   vals.forEach((v,j)=>{ctx.strokeRect(x,y,cols[j],42);ctx.font=`14px ${font}`;ctx.fillText(String(v).slice(0,45),x+8,y+27);x+=cols[j]});y+=42;
 }
 ctx.font=`12px ${font}`;ctx.fillText('業務記録',left,y+25);
 return c;
}
function makePdfFromJpeg(dataUrl,width,height){
 const b64=dataUrl.split(',')[1], bin=atob(b64), img=new Uint8Array(bin.length);
 for(let i=0;i<bin.length;i++)img[i]=bin.charCodeAt(i);
 const enc=new TextEncoder(), chunks=[], offsets=[];let pos=0;
 function add(s){const b=typeof s==='string'?enc.encode(s):s;chunks.push(b);pos+=b.length}
 add('%PDF-1.4\n%âãÏÓ\n');
 function obj(n,body){offsets[n]=pos;add(`${n} 0 obj\n${body}\nendobj\n`)}
 obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
 obj(2,'<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
 obj(3,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im1 5 0 R >> >> /Contents 4 0 R >>');
 const stream='q\n595 0 0 842 0 0 cm\n/Im1 Do\nQ\n';
 obj(4,`<< /Length ${enc.encode(stream).length} >>\nstream\n${stream}endstream`);
 offsets[5]=pos;add(`5 0 obj\n<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.length} >>\nstream\n`);chunks.push(img);pos+=img.length;add('\nendstream\nendobj\n');
 const xref=pos;add(`xref\n0 6\n0000000000 65535 f \n`);for(let i=1;i<=5;i++)add(String(offsets[i]).padStart(10,'0')+' 00000 n \n');
 add(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
 let total=0;for(const c of chunks)total+=c.length;const out=new Uint8Array(total);let at=0;for(const c of chunks){out.set(c,at);at+=c.length}
 return new Blob([out],{type:'application/pdf'});
}
function previewPrint(){
 const r=collect();
 const c=drawPdfCanvas(r);
 const img=document.createElement('img');img.className='pdfCanvas';img.src=c.toDataURL('image/jpeg',0.92);
 $('previewContent').innerHTML='';
 const wrap=document.createElement('div');wrap.className='previewPaper';wrap.appendChild(img);$('previewContent').appendChild(wrap);
 $('previewModal').classList.add('open');
 window._pdfCanvas=c;
}
function downloadPdf(){
 const r=collect(); const c=drawPdfCanvas(r); window._pdfCanvas=c;
 const pdfBytes=makePdfFromJpeg(c.toDataURL('image/jpeg',0.92),c.width,c.height);
 // APK/WebViewでBlob URLが使えない場合に備え、data URIで直接ダウンロードする
 const b64=bytesToBase64(pdfBytes);
 const a=document.createElement('a');
 a.href='data:application/pdf;base64,'+b64;
 a.download=`業務記録_${r.date||todayStr()}.pdf`;
 a.setAttribute('download',`業務記録_${r.date||todayStr()}.pdf`);
 document.body.appendChild(a);
 try{a.click()}catch(e){location.href=a.href}
 a.remove();
 showToast('PDF保存を開始したよ');
}
function bytesToBase64(bytes){
 let binary=''; const chunk=0x8000;
 for(let i=0;i<bytes.length;i+=chunk) binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));
 return btoa(binary);
}
function closePreview(){$('previewModal').classList.remove('open')}
function printPreview(){
 // APK内ではwindow.openが動かないことが多いため、同じ画面を印刷モードにしてwindow.printする
 const r=collect(); const c=drawPdfCanvas(r); window._pdfCanvas=c;
 const img=c.toDataURL('image/jpeg',0.92);
 const old=document.getElementById('apkPrintLayer');
 if(old)old.remove();
 const layer=document.createElement('div'); layer.id='apkPrintLayer';
 layer.innerHTML='<img src="'+img+'">';
 document.body.appendChild(layer);
 document.body.classList.add('apk-printing');
 setTimeout(()=>{try{window.print()}catch(e){showToast('このAPKでは直接印刷できません。PDF保存を使ってください')}},250);
 setTimeout(()=>{document.body.classList.remove('apk-printing');layer.remove()},1500);
}
function apkStorageTest(){
 try{const k='gyomu_test';localStorage.setItem(k,'ok');const ok=localStorage.getItem(k)==='ok';localStorage.removeItem(k);showToast(ok?'端末保存は正常に使えるよ':'端末保存が使えないAPKです');}
 catch(e){showToast('このAPKでは端末保存が制限されています')}
}

init();
