/**
 * Snake Escape — Application Bootstrapper & Global Navigation Router
 */
(function() {
  'use strict';

  document.addEventListener('DOMContentLoaded', () => {
    const { storage, audio, animation, ui, settings, progress } = window.SnakeEscape;
    const game = new window.SnakeEscape.Game();
    window.SnakeEscape.gameInstance = game;

    // Initialize UI and Settings
    ui.init();
    settings.init();
    game.init();

    // Spawn ambient jungle fireflies
    const bgContainer = document.querySelector('.jungle-bg-layer');
    if (bgContainer) {
      animation.createFireflies(bgContainer, 14);
    }

    // -------------------------------------------------------------------------
    // Navigation & Screen Transitions
    // -------------------------------------------------------------------------

    // Splash Screen: Auto-advance after 1.8s or on tap
    let splashHandled = false;
    const finishSplash = () => {
      if (splashHandled) return;
      splashHandled = true;

      // Check URL parameters for direct deep-linking
      const params = new URLSearchParams(window.location.search);
      const levelParam = params.get('level');
      const screenParam = params.get('screen');

      if (levelParam) {
        const lvl = parseInt(levelParam, 10);
        if (!isNaN(lvl)) {
          ui.showScreen('game');
          game.loadLevel(lvl);
          return;
        }
      }

      if (screenParam && ['menu', 'levels', 'settings', 'how-to-play', 'game'].includes(screenParam)) {
        ui.showScreen(screenParam);
        if (screenParam === 'levels') {
          renderCurrentTabLevels('easy');
        } else if (screenParam === 'game') {
          game.loadLevel(storage.data.currentLevel || 1);
        }
        return;
      }

      ui.showScreen('menu');
      audio.startMusic();
    };

    setTimeout(finishSplash, 1800);
    const splashEl = document.getElementById('screen-splash');
    if (splashEl) {
      splashEl.addEventListener('click', finishSplash);
    }

    // -------------------------------------------------------------------------
    // Main Menu Buttons
    // -------------------------------------------------------------------------

    const btnPlay = document.getElementById('btn-menu-play');
    if (btnPlay) {
      btnPlay.addEventListener('click', () => {
        audio.playClick();
        ui.showScreen('game');
        game.loadLevel(storage.data.currentLevel || 1);
      });
    }

    const btnLevelSelect = document.getElementById('btn-menu-levels');
    if (btnLevelSelect) {
      btnLevelSelect.addEventListener('click', () => {
        audio.playClick();
        ui.showScreen('levels');
        renderCurrentTabLevels(1);
      });
    }

    const btnHowToPlay = document.getElementById('btn-menu-how');
    if (btnHowToPlay) {
      btnHowToPlay.addEventListener('click', () => {
        audio.playClick();
        ui.showScreen('how-to-play');
      });
    }

    const btnSettings = document.getElementById('btn-menu-settings');
    const btnTopSettings = document.getElementById('btn-top-settings');
    const openSettings = () => {
      audio.playClick();
      ui.showScreen('settings');
      syncSettingsUI();
    };
    if (btnSettings) btnSettings.addEventListener('click', openSettings);
    if (btnTopSettings) btnTopSettings.addEventListener('click', openSettings);

    // -------------------------------------------------------------------------
    // Back Buttons (Consistent navigation)
    // -------------------------------------------------------------------------

    document.querySelectorAll('.btn-nav-back').forEach(btn => {
      btn.addEventListener('click', () => {
        audio.playClick();
        ui.showScreen('menu');
      });
    });

    const btnGameBack = document.getElementById('btn-game-back');
    if (btnGameBack) {
      btnGameBack.addEventListener('click', () => {
        audio.playClick();
        ui.showScreen('menu');
      });
    }

    // -------------------------------------------------------------------------
    // In-Game Controls Bar & HUD
    // -------------------------------------------------------------------------

    const btnPause = document.getElementById('btn-game-pause');
    if (btnPause) {
      btnPause.addEventListener('click', () => game.togglePause());
    }

    const btnHint = document.getElementById('btn-game-hint');
    if (btnHint) {
      btnHint.addEventListener('click', () => game.showHint());
    }

    const btnReset = document.getElementById('btn-game-reset');
    if (btnReset) {
      btnReset.addEventListener('click', () => game.resetLevel());
    }

    const btnUndo = document.getElementById('btn-game-undo');
    if (btnUndo) {
      btnUndo.addEventListener('click', () => game.undoMove());
    }

    // -------------------------------------------------------------------------
    // Modals Action Handlers
    // -------------------------------------------------------------------------

    // Pause Modal
    const btnResume = document.getElementById('btn-pause-resume');
    if (btnResume) {
      btnResume.addEventListener('click', () => game.togglePause());
    }
    const btnRestart = document.getElementById('btn-pause-restart');
    if (btnRestart) {
      btnRestart.addEventListener('click', () => {
        game.togglePause();
        game.resetLevel();
      });
    }
    const btnPauseHome = document.getElementById('btn-pause-home');
    if (btnPauseHome) {
      btnPauseHome.addEventListener('click', () => {
        ui.hideAllModals();
        ui.showScreen('menu');
      });
    }

    // Hint Modal
    const btnHintOk = document.getElementById('btn-hint-ok');
    const btnHintClose = document.getElementById('btn-hint-close');
    const closeHint = () => {
      audio.playClick();
      ui.hideModal('modal-hint');
    };
    if (btnHintOk) btnHintOk.addEventListener('click', closeHint);
    if (btnHintClose) btnHintClose.addEventListener('click', closeHint);

    // Level Complete Modal
    const btnCompleteNext = document.getElementById('btn-complete-next');
    if (btnCompleteNext) {
      btnCompleteNext.addEventListener('click', () => {
        audio.playClick();
        ui.hideAllModals();
        game.nextLevel();
      });
    }
    const btnCompleteHome = document.getElementById('btn-complete-home');
    if (btnCompleteHome) {
      btnCompleteHome.addEventListener('click', () => {
        audio.playClick();
        ui.hideAllModals();
        ui.showScreen('menu');
      });
    }

    // Level Failed Modal
    const btnFailedUndo = document.getElementById('btn-failed-undo');
    if (btnFailedUndo) {
      btnFailedUndo.addEventListener('click', () => {
        audio.playClick();
        game.undoMove();
      });
    }

    const btnFailedRetry = document.getElementById('btn-failed-retry');
    if (btnFailedRetry) {
      btnFailedRetry.addEventListener('click', () => {
        audio.playClick();
        ui.hideAllModals();
        game.resetLevel();
      });
    }
    const btnFailedHome = document.getElementById('btn-failed-home');
    if (btnFailedHome) {
      btnFailedHome.addEventListener('click', () => {
        audio.playClick();
        ui.hideAllModals();
        ui.showScreen('menu');
      });
    }

    // Board Cleared Modal
    const btnClearedNext = document.getElementById('btn-cleared-next');
    if (btnClearedNext) {
      btnClearedNext.addEventListener('click', () => {
        audio.playClick();
        ui.hideAllModals();
        game.nextLevel();
      });
    }
    const btnClearedHome = document.getElementById('btn-cleared-home');
    if (btnClearedHome) {
      btnClearedHome.addEventListener('click', () => {
        audio.playClick();
        ui.hideAllModals();
        ui.showScreen('menu');
      });
    }

    // -------------------------------------------------------------------------
    // Level Select Tabs & Rendering (12 Worlds)
    // -------------------------------------------------------------------------

    let currentWorldTab = 1;
    function renderCurrentTabLevels(worldNum = 1) {
      currentWorldTab = Number(worldNum) || 1;
      document.querySelectorAll('.world-tabs .tab-btn').forEach(btn => {
        btn.classList.toggle('active', Number(btn.getAttribute('data-world')) === currentWorldTab);
      });

      ui.renderLevelGrid(currentWorldTab, storage, progress, (selectedLevelId) => {
        audio.playClick();
        ui.showScreen('game');
        game.loadLevel(selectedLevelId);
      });
    }

    document.querySelectorAll('.world-tabs .tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        audio.playClick();
        renderCurrentTabLevels(btn.getAttribute('data-world'));
      });
    });

    // Daily Challenge quick launch
    const bannerDaily = document.getElementById('banner-daily-challenge');
    if (bannerDaily) {
      bannerDaily.addEventListener('click', () => {
        audio.playClick();
        ui.showScreen('game');
        game.loadLevel(999);
      });
    }

    // -------------------------------------------------------------------------
    // How to Play Screen
    // -------------------------------------------------------------------------

    const btnHowGotIt = document.getElementById('btn-how-got-it');
    if (btnHowGotIt) {
      btnHowGotIt.addEventListener('click', () => {
        audio.playClick();
        ui.showScreen('menu');
      });
    }

    // -------------------------------------------------------------------------
    // Settings Screen Toggles & Modals
    // -------------------------------------------------------------------------

    function syncSettingsUI() {
      const s = storage.data.settings;
      const soundTgl = document.getElementById('toggle-sound');
      if (soundTgl) soundTgl.checked = s.soundEnabled;

      const musicTgl = document.getElementById('toggle-music');
      if (musicTgl) musicTgl.checked = s.musicEnabled;

      const vibTgl = document.getElementById('toggle-vibration');
      if (vibTgl) vibTgl.checked = s.vibrationEnabled;

      const darkTgl = document.getElementById('toggle-dark');
      if (darkTgl) darkTgl.checked = s.darkMode;

      const langVal = document.getElementById('setting-lang-val');
      if (langVal) langVal.textContent = s.language === 'hi' ? 'हिंदी' : 'English';
    }

    const tglSound = document.getElementById('toggle-sound');
    if (tglSound) {
      tglSound.addEventListener('change', (e) => {
        settings.setSound(e.target.checked);
        audio.playClick();
      });
    }

    const tglMusic = document.getElementById('toggle-music');
    if (tglMusic) {
      tglMusic.addEventListener('change', (e) => {
        settings.setMusic(e.target.checked);
        audio.playClick();
      });
    }

    const tglVib = document.getElementById('toggle-vibration');
    if (tglVib) {
      tglVib.addEventListener('change', (e) => {
        settings.setVibration(e.target.checked);
        audio.playClick();
        if (e.target.checked) animation.vibrate(40);
      });
    }

    const tglDark = document.getElementById('toggle-dark');
    if (tglDark) {
      tglDark.addEventListener('change', (e) => {
        settings.setDarkMode(e.target.checked);
        audio.playClick();
      });
    }

    const rowLang = document.getElementById('row-setting-lang');
    if (rowLang) {
      rowLang.addEventListener('click', () => {
        audio.playClick();
        const newLang = settings.toggleLanguage();
        const langVal = document.getElementById('setting-lang-val');
        if (langVal) langVal.textContent = newLang === 'hi' ? 'हिंदी' : 'English';
      });
    }

    // Privacy Policy & About Us Modals
    const rowPrivacy = document.getElementById('row-setting-privacy');
    if (rowPrivacy) {
      rowPrivacy.addEventListener('click', () => {
        audio.playClick();
        ui.showModal('modal-privacy');
      });
    }
    const btnPrivacyClose = document.getElementById('btn-privacy-close');
    if (btnPrivacyClose) {
      btnPrivacyClose.addEventListener('click', () => {
        audio.playClick();
        ui.hideModal('modal-privacy');
      });
    }

    const rowAbout = document.getElementById('row-setting-about');
    if (rowAbout) {
      rowAbout.addEventListener('click', () => {
        audio.playClick();
        ui.showModal('modal-about');
      });
    }
    const btnAboutClose = document.getElementById('btn-about-close');
    if (btnAboutClose) {
      btnAboutClose.addEventListener('click', () => {
        audio.playClick();
        ui.hideModal('modal-about');
      });
    }

    // Reset Progress
    const btnResetProgress = document.getElementById('btn-reset-progress');
    if (btnResetProgress) {
      btnResetProgress.addEventListener('click', () => {
        audio.playClick();
        ui.showModal('modal-reset-confirm');
      });
    }
    const btnResetConfirmYes = document.getElementById('btn-reset-confirm-yes');
    if (btnResetConfirmYes) {
      btnResetConfirmYes.addEventListener('click', () => {
        audio.playClick();
        storage.resetProgress();
        ui.hideModal('modal-reset-confirm');
        ui.showToast('Progress has been reset!');
        syncSettingsUI();
      });
    }
    const btnResetConfirmCancel = document.getElementById('btn-reset-confirm-cancel');
    if (btnResetConfirmCancel) {
      btnResetConfirmCancel.addEventListener('click', () => {
        audio.playClick();
        ui.hideModal('modal-reset-confirm');
      });
    }
  });
})();
