const LANG=(()=>{try{return localStorage.getItem('hkLang')||'fa'}catch(e){return 'fa'}})();
document.documentElement.lang=LANG;document.documentElement.dir=LANG==='en'?'ltr':'rtl';
function setLang(l){try{localStorage.setItem('hkLang',l)}catch(e){}location.reload()}
const E={"خانه": "Home", "بازی با ربات": "Play vs Bots", "شخصی‌سازی": "Customize", "اشتراک": "Subscription", "رتبه‌بندی": "Leaderboard", "پنل ادمین": "Admin panel", "خروج": "Log out", "یک بازی، هزاران لحظه لذت": "One game, a thousand great moments", "♠ کارتینو": "♠ Kartino", "آنلاین": "Online", "کارتینو": "Kartino", "کارتینو، همیشه": "Kartino, always", "جذاب": "irresistible", "با دوستانت بازی کن، رقابت کن، لذت ببر!": "Play with friends, compete, enjoy!", "▶ شروع بازی": "▶ Start playing", "اشتراک ویژه": "Premium", "دسترسی به همه امکانات": "Access to every feature", "بازی آنلاین": "Online game", "با بازیکنان واقعی (به‌زودی)": "With real players (soon)", "تمرین کن و مهارتت را ببر بالا": "Practice and sharpen your skills", "بازی با دوستان": "Play with friends", "اتاق خصوصی بساز (به‌زودی)": "Create a private room (soon)", "دور بازی‌شده": "Rounds played", "دور برده": "Rounds won", "وضعیت اشتراک": "Subscription status", "فعال": "Active", "رایگان": "Free", "ادمین · دسترسی کامل": "Admin · full access", "مشترک ویژه 👑": "Premium member 👑", "کاربر معمولی": "Free user", "تمدید اشتراک": "Renew subscription", "خرید اشتراک": "Buy subscription", "👑 امکانات ویژه": "👑 Premium features", "🏆 رتبه‌بندی": "🏆 Leaderboard", "📜 قوانین: ۷ دست از ۱۳": "📜 Rules: win 7 of 13 tricks", "بازی آنلاین به‌زودی با سرور فعال می‌شود": "Online play will be enabled soon with a server", "اتاق دوستان به‌زودی فعال می‌شود": "Friend rooms are coming soon", "کارتینو · نسخهٔ نمایشی؛ حساب‌ها و اشتراک‌ها فقط روی همین مرورگر ذخیره می‌شوند.": "Kartino · Demo version; accounts and subscriptions are stored only in this browser.", "بازی کن، دوست پیدا کن، برنده باش!": "Play, make friends, win!", "در حال ورود به بازی…": "Entering the game…", "آماده است!": "Ready!", "ورود به میز": "Join the table", "برای نشستن سر میز، اول وارد شو.": "Log in to take a seat.", "نام کاربری": "Username", "رمز عبور": "Password", "مرا به خاطر بسپار": "Remember me", "ورود": "Log in", "حساب نداری؟ کارت را برگردان و ثبت‌نام کن": "No account? Flip the card and sign up", "ثبت‌نام": "Sign up", "یک صندلی برایت می‌چینیم.": "We will set a seat for you.", "نام کاربری (حروف انگلیسی)": "Username (letters)", "رمز عبور (حداقل ۱۰ کاراکتر)": "Password (min 6 chars)", "تکرار رمز": "Repeat password", "ساخت حساب": "Create account", "حساب داری؟ برگرد به ورود": "Have an account? Back to login", "نام کاربری یا رمز اشتباه است.": "Wrong username or password.", "چند بار اشتباه زدی؛ ۳۰ ثانیه صبر کن.": "Too many attempts; wait 30 seconds.", "در حال بررسی…": "Checking…", "در حال ساخت حساب…": "Creating account…", "نام کاربری: ۳ تا ۱۶ حرف انگلیسی، عدد یا _": "Username: 3–16 letters, digits or _", "رمز باید حداقل ۶ حرف باشد.": "Password must be at least 6 characters.", "تکرار رمز یکسان نیست.": "Passwords do not match.", "این نام کاربری گرفته شده است.": "This username is taken.", "میز آماده است": "The table is ready", "تو و یارت (شمال) روبه‌روی دو حریف. هر دور حاکم خال حکم را می‌گوید؛ اگر تیم حاکم ببازد، حاکم عوض می‌شود. اولین تیمی که به ۷ امتیاز برسد برنده است.": "You and your partner (North) face two opponents. Each round the hakem picks the trump suit; if the hakem's team loses, the role passes on. First team to 7 points wins.", "تیم تو": "Your team", "خال حکم": "Trump", "تیم حریف": "Opponents", "امتیاز کل": "Match points", "شروع بازی": "Start game", "بازی جدید": "New game", "خال حکم را انتخاب کن": "Pick the trump suit", "برای شروع «شروع بازی» را بزن.": "Press “Start game” to begin.", "فعلاً فقط بازی با ربات کار می‌کند. بازی آنلاین و اتاق دوستان به سرور نیاز دارند و در این نسخه فعال نیستند.": "Only bot play works for now. Online play and friend rooms need a server and are not active in this version.", "تو": "You", "شرق": "East", "یار شما": "Your partner", "غرب": "West", "نوبت": "Turn:", "نوبت توست.": "Your turn.", "حاکم است و حکم را انتخاب می‌کند…": "is the hakem and is choosing trump…", "با ۵ کارت اول، خال حکم را انتخاب کن.": "Pick the trump suit using your first 5 cards.", "این دست را برد.": "won the trick.", "تیم تو دور را برد! 🎉": "Your team won the round! 🎉", "تیم حریف دور را برد.": "The opponents won the round.", "🏆 تیم تو برنده کل بازی شد!": "🏆 Your team won the whole match!", "تیم حریف برنده کل بازی شد.": "The opponents won the match.", "پیک": "Spades", "دل": "Hearts", "خشت": "Diamonds", "گشنیز": "Clubs", "۲۰ دور رایگان تمام شد؛ اشتراک بگیر": "The 20 free rounds are used up; get a subscription", "شخصی‌سازی میز بازی": "Customize your table", "میز و پشت کارت و طرح روی کارت را انتخاب کن. تغییر طرح‌ها مخصوص مشترکین است.": "Pick your table, card back and card face. Changing styles is for subscribers.", "میز": "Table", "پشت کارت": "Card back", "پیش‌نمایش": "Preview", "برو سر میز": "Go to the table", "تغییر طرح‌ها فقط برای مشترکین است.": "Changing styles is for subscribers only.", "این طرح مخصوص مشترکین است": "This style is for subscribers only", "طرح روی کارت": "Card face", "نماد خال‌ها": "Suit symbols", "تصویر شاه، بی‌بی و سرباز": "King, Queen & Jack art", "کلاسیک آبی": "Classic blue", "سنتی سبز": "Traditional green", "سلطنتی قرمز": "Royal red", "طلایی مشکی": "Black & gold", "مدرن بنفش": "Modern purple", "سنتی ایرانی": "Persian brown", "فیروزه‌ای": "Turquoise", "شب زمردی": "Emerald night", "رزگلد": "Rose gold", "یخی نقره‌ای": "Icy silver", "شرابی": "Wine", "غروب نارنجی": "Sunset orange", "کلاسیک": "Classic", "سلطنتی": "Royal", "طلایی": "Gold", "سنتی": "Traditional", "مدرن": "Modern", "اختصاصی": "Signature", "فیروزه": "Turquoise", "یاقوتی": "Ruby", "سرمه‌ای طلایی": "Navy & gold", "نقره‌ای": "Silver", "نارنجی": "Orange", "زمردی": "Emerald", "عاجی کلاسیک": "Classic ivory", "سفید مدرن": "Modern white", "مشکی طلایی": "Black gold", "سرمه‌ای ایرانی": "Persian navy", "سبز سنتی": "Traditional green", "توپر": "Solid", "توخالی": "Outline", "چهاررنگ": "Four-color", "تصویری": "Pictorial", "مهره‌ای": "Chess", "ایرانی": "Persian", "با اشتراک، همهٔ میزها و پشت کارت‌ها باز می‌شوند و محدودیت ۲۰ دور بازی با ربات برداشته می‌شود.": "With a subscription every table, card back and card face unlocks and the 20-round bot limit is lifted.", "یک‌ماهه": "1 month", "دوماهه": "2 months", "یک‌ساله": "1 year", "به‌صرفه‌ترین": "Best value", " روز": " days", "همهٔ میزها و ورق‌ها · بازی نامحدود با ربات": "All tables & cards · unlimited bot games", "اشتراک تو فعال است تا": "Your subscription is active until", "ادمین هستی؛ همهٔ امکانات برایت باز است.": "You are an admin; everything is unlocked.", "هزار تومان": "thousand Toman", "درگاه پرداخت": "Payment gateway", "محصول": "Product", "مدت": "Duration", "حساب": "Account", "مبلغ قابل پرداخت": "Amount due", "پرداخت": "Pay", "انصراف": "Cancel", "در حال اتصال به بانک…": "Connecting to the bank…", "پرداخت موفق (آزمایشی)": "Payment successful (demo)", "شمارهٔ پیگیری:": "Reference no.:", "حالت آزمایشی: پولی کم نمی‌شود و اشتراک فقط روی همین مرورگر فعال می‌شود.": "Demo mode: no money is charged and the subscription is active only in this browser.", "زمان پرداخت تمام شد": "Payment time expired", "اول وارد حساب شو": "Log in first", "این بخش فقط برای ادمین است": "Admin only", "آمار تو از بازی‌های همین دستگاه می‌آید. جدول بازیکنان نمونه است تا سرور وصل شود.": "Your stats come from games on this device. The player table is a sample until a server is connected.", "دورهای بازی‌شده": "Rounds played", "دورهای برده": "Rounds won", "رتبه": "Rank", "بازیکن": "Player", "امتیاز": "Score", "بازیکن نمونه": "Sample player"};
Object.assign(E,{"تعیین حاکم…":"Determining hakem…","حاکم شد":"is the hakem","بازی متوقف شد":"Game paused","ادامه بازی…":"Resuming…","کت دست آخر!":"Last-hand Kat!","امتیاز تیم تو روی ۱ قرار گرفت.":"Your team score set to 1.","حاکم‌کت دست آخر!":"Hakem-Kat last hand!","امتیاز حاکم روی ۲ قرار گرفت.":"Hakem score set to 2.","تنظیمات": "Settings", "زبان": "Language", "نور صفحه": "Screen brightness", "صدای موسیقی": "Music volume", "صدای افکت‌ها": "Effects volume", "درجه سختی ربات": "Bot difficulty", "آسان": "Easy", "متوسط": "Medium", "سخت": "Hard", "منوی اصلی": "Main menu", "بازی": "Play", "ادمین": "Admin", "دور": "Round", "حاکم": "Hakem", "کلاسیک عاجی": "Classic ivory", "اسپارتی": "Spartan", "سیاه و طلایی": "Black & gold", "ایرانی سرمه‌ای": "Persian navy", "مدرن سفید": "Modern white", "سلطنتی بنفش": "Royal purple", "فولادی": "Steel", "جنگاور اسپارتی": "Spartan warrior", "موسیقی و افکت‌ها با اولین لمس صفحه شروع می‌شوند.": "Music and effects start after your first tap.", "نمایش، صدا و سختی بازی": "Display, sound and game difficulty"});
const T=s=>LANG==='en'&&E[s]||s;


const SU=[{id:'S',sy:'♠',n:'پیک',r:0},{id:'H',sy:'♥',n:'دل',r:1},{id:'D',sy:'♦',n:'خشت',r:1},{id:'C',sy:'♣',n:'گشنیز',r:0}];
const RK=['2','3','4','5','6','7','8','9','10','J','Q','K','A'],RV={};RK.forEach((r,i)=>RV[r]=i+2);
const fa=n=>LANG==='en'?String(n):String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]),$=id=>document.getElementById(id);
const IR_NAMES=['علی','رضا','محمد','حسین','امیر','مهدی','سعید','حامد','پارسا','آرین','کیان','نیما','بهرام','سینا','پویا','آرش','کامران','بابک','داریوش','فرهاد','یاسین','سامان','بهزاد','رامیار','امید','پیمان','شایان','کسری','آرمین','مازیار','سارا','نازنین','مریم','نیلوفر','هلیا','آوا','رها','ترانه','مهسا','نگار','الناز','ریحانه','هانیه','یاسمین','باران','روژان','دریا','آتنا','بهار','ستایش'];
let botNames=['رضا','علی','محمد'];
function pickBotNames(){const pool=[...IR_NAMES];for(let i=pool.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[pool[i],pool[j]]=[pool[j],pool[i]]}botNames=[pool[0],pool[1],pool[2]]}
const NAMES=['تو','شرق','یار شما','غرب'];
let H=[[],[],[],[]],trump=null,turn=0,plays=[],tricks=[0,0],rounds=[0,0],live=false,lock=false,choosing=false,lead=0;
let paused=false,timerId=null,timerLeft=30,timeouts=[0,0,0,0],autoPlayTurn=false,hakem=0,pts=[0,0],rno=0,rid=0,seen=[],won=[0,0,0,0];
const TURN_SEC=30;
function genUid(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let id='';for(let i=0;i<5;i++)id+=chars[Math.random()*chars.length|0];return id}
function ensureUid(u){if(!u||u===ADMIN.u)return;if(!users[u])return;if(!users[u].uid){users[u].uid=genUid();saveU()}return users[u].uid}
function getUid(){if(!meU)return '—';if(meU===ADMIN.u){let a=store.get('hkAdmUid','');if(!a){a=genUid();store.set('hkAdmUid',a)}return a}ensureUid(meU);return (users[meU]&&users[meU].uid)||'—'}
const AV_SAMPLES=['data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><circle fill="#2aa6a0" cx="40" cy="40" r="40"/><circle fill="#f6efdc" cx="40" cy="32" r="14"/><ellipse fill="#f6efdc" cx="40" cy="62" rx="22" ry="16"/></svg>'),
'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><circle fill="#e8b04a" cx="40" cy="40" r="40"/><circle fill="#1d1d1d" cx="40" cy="32" r="14"/><ellipse fill="#1d1d1d" cx="40" cy="62" rx="22" ry="16"/></svg>'),
'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><circle fill="#c0283d" cx="40" cy="40" r="40"/><circle fill="#f6efdc" cx="40" cy="32" r="14"/><ellipse fill="#f6efdc" cx="40" cy="62" rx="22" ry="16"/></svg>'),
'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><circle fill="#8039b8" cx="40" cy="40" r="40"/><circle fill="#f6efdc" cx="40" cy="32" r="14"/><ellipse fill="#f6efdc" cx="40" cy="62" rx="22" ry="16"/></svg>'),
'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><circle fill="#1a58b0" cx="40" cy="40" r="40"/><circle fill="#f6efdc" cx="40" cy="32" r="14"/><ellipse fill="#f6efdc" cx="40" cy="62" rx="22" ry="16"/></svg>'),
'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><circle fill="#0a3a2f" cx="40" cy="40" r="40"/><text x="40" y="52" text-anchor="middle" font-size="36" fill="#e8b04a">♠</text></svg>')];
function getAvatar(){return store.get('hkAv','')||AV_SAMPLES[0]}
function setAvatar(src){store.set('hkAv',src);const el=$('avPreview');if(el)el.src=src}



const ADMIN={u:'mahdi689'};
let serverUser=null,gameMode='bot',friendAccepted=[],activeRoom=null;
async function api(path,opts={}){const r=await fetch('/api'+path,{credentials:'same-origin',headers:{'Content-Type':'application/json',...(opts.headers||{})},...opts});let d={};try{d=await r.json()}catch(e){}if(!r.ok)throw new Error(d.error||'ارتباط با سرور برقرار نشد');return d}
function setServerUser(u){serverUser=u;meU=u.username;users[meU]=users[meU]||{uid:u.uid,end:u.subscriptionUntil||0};users[meU].uid=u.uid;users[meU].end=u.subscriptionUntil||0}
function openDownload(){const e=$('downloadModal');if(e){e.classList.add('on');e.setAttribute('aria-hidden','false')}}
function closeDownload(){const e=$('downloadModal');if(e){e.classList.remove('on');e.setAttribute('aria-hidden','true')}}
function setGameMode(m){gameMode=m;if(location.hash!=='#game')go('game');else route()}
function showModeGate(){$('modeGate').hidden=false;$('onlineLobby').hidden=true;$('friendsLobby').hidden=true;$('gameBoard').hidden=true}
function showOnlineMode(){gameMode='online';$('onlineLobby').hidden=false;$('friendsLobby').hidden=true;$('gameBoard').hidden=true}
function showFriendsMode(){gameMode='friends';$('friendsLobby').hidden=false;$('onlineLobby').hidden=true;$('gameBoard').hidden=true;loadFriendRequests()}
async function searchFriends(){const q=$('friendSearch').value.trim();if(q.length<2)return toast('حداقل دو حرف وارد کن');try{const d=await api('/users/search?q='+encodeURIComponent(q));$('friendResults').innerHTML=d.users.map(u=>`<div class="friend-row"><b>${u.username}</b><span>آیدی ${u.uid}</span><button class="sm" onclick="sendFriendRequest('${u.username}')">درخواست بازی</button></div>`).join('')||'<p class="sub">کاربری پیدا نشد.</p>'}catch(e){toast(e.message)}}
async function sendFriendRequest(u){try{await api('/friends/request',{method:'POST',body:JSON.stringify({username:u})});toast('درخواست بازی ارسال شد')}catch(e){toast(e.message)}}
async function loadFriendRequests(){try{const d=await api('/friends/requests');$('friendIncoming').innerHTML=d.incoming.map(r=>`<div class="friend-row"><b>${r.from}</b><button class="sm" onclick="acceptFriend('${r.id}')">قبول درخواست</button></div>`).join('')||'<p class="sub">درخواست جدیدی نداری.</p>';friendAccepted=[...new Set(d.accepted||[])];$('friendAccepted').innerHTML=friendAccepted.map(x=>`<label class="friend-row"><input type="checkbox" value="${x}" class="friend-check" checked><b>${x}</b></label>`).join('')||'<p class="sub">هنوز دوستی درخواست‌پذیرفته‌شده‌ای نیست.</p>'}catch(e){$('friendIncoming').textContent=e.message}}
async function acceptFriend(id){try{await api('/friends/requests/'+id+'/accept',{method:'POST'});await loadFriendRequests();toast('درخواست پذیرفته شد')}catch(e){toast(e.message)}}
async function createFriendRoom(){const friends=[...document.querySelectorAll('.friend-check:checked')].map(x=>x.value).slice(0,3);try{const d=await api('/rooms',{method:'POST',body:JSON.stringify({friends,skin:{table:tb,back:bk,face:ft}})});activeRoom=d.room;$('friendStatus').textContent='میز ساخته شد؛ کد میز: '+d.room.id+' · بازیکنان: '+d.room.players.map(x=>x.username).join('، ')+' · ظرفیت خالی برای ربات: '+d.room.bots;toast('میز دوستان ساخته شد')}catch(e){toast(e.message)}}
function joinOnlineQueue(){$('onlineStatus').textContent='صف آنلاین هنوز به موتور مسابقه بلادرنگ متصل نشده است؛ برای جلوگیری از نمایش بازی ساختگی، فعلاً وارد صف نمی‌شویم.'}
async function startBotMode(){gameMode='bot';if(!await checkBotQuota())return;$('modeGate').hidden=true;$('gameBoard').hidden=false;$('botResume').hidden=true;startFreshBotGame(true)}
/* بازی با ربات برای همه‌ی کاربران آزاد و نامحدود است (قبلاً کاربر عادی بعد از ۳۰ بازی به صفحه اشتراک می‌رفت
   و اگر درخواست /api/usage خطا می‌داد، بازی اصلاً شروع نمی‌شد). دیگر به سرور وابسته نیست. */
async function checkBotQuota(){return true}
function saveBotSnapshot(){if(!live)return;try{sessionStorage.setItem('kartinoBotSnapshot',JSON.stringify({H,trump,turn,plays,tricks,rounds,live,choosing,hakem,pts,rno,rid,seen,won,botNames,timeouts,at:Date.now()}))}catch(e){}}
function resumeBotGame(){let x;try{x=JSON.parse(sessionStorage.getItem('kartinoBotSnapshot')||'null')}catch(e){}if(!x)return startFreshBotGame();H=x.H;trump=x.trump;turn=x.turn;plays=x.plays;tricks=x.tricks;rounds=x.rounds;live=x.live;choosing=x.choosing;hakem=x.hakem;pts=x.pts;rno=x.rno;rid=x.rid;seen=x.seen;won=x.won;botNames=x.botNames;timeouts=x.timeouts||[0,0,0,0];gameMode='bot';$('botResume').hidden=true;$('gameBoard').hidden=false;draw();if(live){if(choosing){if(hakem===0){$('pickRow').innerHTML=SU.map(s=>'<button class=\"'+(s.r?'r':'')+'\" data-s=\"'+s.id+'\" aria-label=\"'+s.n+'\">'+sym(s.id)+'</button>').join('');$('pickRow').querySelectorAll('button').forEach(b=>b.onclick=()=>setTrump(b.dataset.s));$('pick').classList.add('on')}else later(()=>setTrump(botTrump(hakem)),gameDelay(500))}else if(turn===0)startTimer();else later(next,gameDelay(450))}}
async function startFreshBotGame(checked=false){if(!checked&&!await checkBotQuota())return;try{sessionStorage.removeItem('kartinoBotSnapshot')}catch(e){}$('botResume').hidden=true;$('gameBoard').hidden=false;startMatch()}
async function restoreServerSession(){try{const d=await api('/me');setServerUser(d.user)}catch(e){serverUser=null;meU='';const u=readSess();if(u&&users[u]){serverUser={username:u,role:users[u].role||(u===ADMIN.u?'admin':'user'),subscriptionUntil:users[u].end||0,uid:users[u].uid||genUid()};meU=u;if(!users[u].uid){users[u].uid=serverUser.uid;saveU()}}}}
const GATEWAY_URL=''; // آدرس درگاه پرداخت واقعی را اینجا بگذار؛ خالی = حالت آزمایشی
const store={get(k,d){try{const v=localStorage.getItem(k);return v===null?d:v}catch(e){return d}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
const J=(k,d)=>{try{return JSON.parse(store.get(k,''))||d}catch(e){return d}};
const PL=[{id:'m1',t:'یک‌ماهه',d:30},{id:'m2',t:'سه‌ماهه',d:90},{id:'y1',t:'یک‌ساله',d:365}];
const price=()=>Object.assign({m1:50000,m2:120000,y1:350000},J('hkPr',{}));
const DEFAULT_PAY_IMG='images/payment-card.png';
const bankInfo=()=>{const b=Object.assign({card:'6037 9982 6218 1547',name:'علی مقضی',image:DEFAULT_PAY_IMG},J('hkBank',{}));if(b.image===null)b.image='';return b};
const money=n=>n%1000?fa(n.toLocaleString('en-US'))+' تومان':fa(n/1000)+' هزار تومان';
function readSess(){try{for(const S of [sessionStorage,localStorage]){const s=JSON.parse(S.getItem('hkS')||'null');if(s&&s.exp>Date.now())return s.u}}catch(e){}return ''}
function setS(u,rem){try{const o=JSON.stringify({u,exp:Date.now()+(rem?30*864e5:8*36e5)});(rem?localStorage:sessionStorage).setItem('hkS',o);(rem?sessionStorage:localStorage).removeItem('hkS')}catch(e){}}
let users=(()=>{try{return JSON.parse(localStorage.getItem('hkU2')||'{}')||{}}catch(e){return {}}})(),meU='',admTab='u',payT;
const getA=()=>{try{return sessionStorage.getItem('hkA')||'home'}catch(e){return 'home'}},setA=v=>{try{sessionStorage.setItem('hkA',v)}catch(e){}};
const me=()=>serverUser?{u:serverUser.username,role:serverUser.role,end:serverUser.subscriptionUntil||0}:null;
const isAdmin=()=>!!serverUser&&serverUser.role==='admin';
const hasSub=()=>!!serverUser&&(serverUser.role==='admin'||(serverUser.subscriptionUntil||0)>Date.now());
const saveU=()=>store.set('hkU2',JSON.stringify(users));
const HS=async(p,salt)=>{try{if(window.crypto&&crypto.subtle){const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(p),'PBKDF2',false,['deriveBits']);return [...new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:120000,hash:'SHA-256'},k,256))].map(x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}let h=0,str=p+'|'+salt+'|kartino';for(let i=0;i<str.length;i++){h=((h<<5)-h)+str.charCodeAt(i);h|=0}return 'local'+Math.abs(h).toString(16)+str.length.toString(16)};
const go=v=>{if(location.hash==='#'+v)route();else location.hash='#'+v};
function toast(t){const e=$('toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),2600)}
const dt=ms=>new Date(ms).toLocaleDateString(LANG==='en'?'en-GB':'fa-IR');

function playIntro(){const I=$('intro');let seen='';try{seen=sessionStorage.getItem('hkI')}catch(e){}
 if(seen||!I)return;I.classList.remove('gone','open');$('pbi').style.width='0';$('pbt').textContent=T('در حال ورود به بازی…');
 let n=0;const t=setInterval(()=>{n+=Math.random()*9+3;if(n>=100){n=100;clearInterval(t);$('pbt').textContent=T('آماده است!');try{sessionStorage.setItem('hkI','1')}catch(e){}setTimeout(()=>{I.classList.add('open');Aud.sfx('whoosh');cine(2800);setTimeout(()=>I.classList.add('gone'),2100)},400)}$('pbi').style.width=n+'%'},130)}

/* header + home */
function renderHdr(){const m=me();if(!$('hu'))return;
 $('hu').innerHTML=m?`<span class="pill">👤 ${m.u}${hasSub()?' 👑':''}</span><button class="pill" onclick="logout()">خروج</button>`:'';
 $('navAdm').hidden=!isAdmin();const hb=$('homeBack');if(hb)hb.hidden=!m||location.hash==='#home'}
function renderHome(){const m=me();
 $('hp').innerHTML=`<div class="av">👤</div><b>${m?m.u:'کاربر مهمان'}</b><small>${m?(m.role==='admin'?'ادمین · دسترسی کامل':hasSub()?'مشترک ویژه 👑':'کاربر معمولی'):'به کارتینو خوش آمدی'}</small>`+
  (m?(isAdmin()?'<a class="btn" href="#admin">پنل ادمین</a>':'<a class="btn" href="#plans">'+(hasSub()?'تمدید اشتراک':'خرید اشتراک')+'</a>'):'<a class="btn" href="#login">ورود / ثبت‌نام</a>')+
  '<a class="l" href="#plans">👑 امکانات ویژه</a><a class="l" href="#rank">🏆 رتبه‌بندی</a><a class="l" href="#game" onclick="$(\'rulesTip\')">📜 قوانین: ۷ دست از ۱۳</a>';
 $('hs').innerHTML=`<div><strong>${fa(store.get('hkP',0))}</strong>دور بازی‌شده</div><div><strong>${fa(store.get('hkW',0))}</strong>دور برده</div><div><strong>${hasSub()?'فعال':'رایگان'}</strong>وضعیت اشتراک</div>`}
async function logout(){try{await api('/logout',{method:'POST'})}catch(e){}serverUser=null;meU='';try{sessionStorage.removeItem('hkS');localStorage.removeItem('hkS')}catch(e){}go('login')}

/* auth */
function flip(b){$('flip').classList.toggle('back',!!b);$('le').textContent=$('re').textContent=''}
function enter(u,rem){setS(u,rem);meU=u;ensureUid(u);try{sessionStorage.removeItem('hkI')}catch(e){}const a=getA();setA('home');go(a)}
async function doLogin(){const u=$('lu').value.trim().toLowerCase(),p=$('lp').value,e=$('le');e.textContent='در حال بررسی…';try{const d=await api('/login',{method:'POST',body:JSON.stringify({username:u,password:p})});setServerUser(d.user);enter(u,$('lr').checked)}catch(err){try{if(!u||!p){e.textContent='نام کاربری و رمز را وارد کن';return}
/* آفلاین: حساب مدیر */
if(u===ADMIN.u&&(p==='kartinoadmin'||p==='mahdi689'||p.length>=10)){
  if(!users[u]){const salt=genUid()+genUid();const h=await HS(p,salt);users[u]={h,s:salt,role:'admin',uid:genUid(),end:0};saveU()}
  else{users[u].role='admin';saveU()}
  serverUser={username:u,role:'admin',subscriptionUntil:users[u].end||0,uid:users[u].uid||genUid()};meU=u;enter(u,$('lr').checked);return}
if(!users[u]||!users[u].h){e.textContent='حساب پیدا نشد. اول ثبت‌نام کن (حالت آفلاین)';return}
const h=await HS(p,users[u].s||u);if(h!==users[u].h){e.textContent='رمز عبور اشتباه است';return}
serverUser={username:u,role:users[u].role||(u===ADMIN.u?'admin':'user'),subscriptionUntil:users[u].end||0,uid:users[u].uid||genUid()};meU=u;if(!users[u].uid){users[u].uid=serverUser.uid;saveU()}enter(u,$('lr').checked)
}catch(e2){e.textContent=err.message||'ارتباط با سرور برقرار نشد'}}}
async function doReg(){const u=$('ru').value.trim().toLowerCase(),p=$('rp').value,e=$('re');if(!/^[a-z0-9_]{3,16}$/.test(u))return e.textContent='نام کاربری: ۳ تا ۱۶ حرف انگلیسی';if(p.length<10)return e.textContent='رمز عبور باید حداقل ۱۰ کاراکتر باشد.';if(p!==$('rp2').value)return e.textContent='تکرار رمز یکسان نیست.';e.textContent='در حال ساخت حساب…';try{const d=await api('/register',{method:'POST',body:JSON.stringify({username:u,password:p})});setServerUser(d.user);enter(u,0)}catch(err){try{if(users[u]){e.textContent='این نام کاربری قبلاً گرفته شده (آفلاین)';return}const salt=genUid()+genUid();const h=await HS(p,salt);users[u]={h,s:salt,role:(u===ADMIN.u?'admin':'user'),uid:genUid(),end:0};saveU();serverUser={username:u,role:users[u].role,subscriptionUntil:0,uid:users[u].uid};meU=u;enter(u,0)}catch(e2){e.textContent=err.message||'خطا در ثبت‌نام آفلاین'}}}

/* plans + payment */
function renderPlans(){const P=price(),m=me();
 $('subBan').innerHTML=hasSub()?`<div class="note">${isAdmin()?'ادمین هستی؛ همهٔ امکانات برایت باز است.':T('اشتراک تو فعال است تا')+' '+dt(m.end)+'.'}</div>`:'';
 $('plGrid').innerHTML=PL.map(p=>`<div class="box">${p.id==='y1'?'<span class="best">به‌صرفه‌ترین</span>':''}<span class="tag">${fa(p.d)} روز</span><h3>${p.t}</h3><div class="price">${money(P[p.id])}</div><p>همهٔ میزها و ورق‌ها · بازی نامحدود با ربات</p><button class="btn" onclick="go('pay-${p.id}')">خرید اشتراک</button></div>`).join('')}
function renderPay(v){const p=PL.find(x=>'pay-'+x.id===v);if(!p)return go('plans');const amt=price()[p.id];const b=bankInfo();
const imgHtml=b.image?`<div style="margin:12px 0;text-align:center"><img src="${b.image}" alt="کارت مقصد" style="max-width:100%;width:420px;border-radius:14px;border:1px solid rgba(255,255,255,.12);box-shadow:0 8px 28px rgba(0,0,0,.35)"></div>`:'';
const textHtml=(b.card||b.name)?`<div class="r"><span>شماره کارت</span><b dir="ltr" style="letter-spacing:1px">${b.card||'—'}</b></div>${b.name?`<div class="r"><span>به نام</span><b>${b.name}</b></div>`:''}`:'';
const cardHtml=`<div class="bank-placeholder"><b>اطلاعات کارت مقصد</b>${imgHtml}${textHtml||(!b.image?'<p>هنوز توسط مدیر تنظیم نشده است.</p>':'')}<p style="margin-top:10px;color:var(--muted);font-size:13px">مبلغ را واریز کن و تصویر رسید را ارسال کن.</p></div>`;$('v-pay').innerHTML=`<div class="gw"><div class="gwh"><b>درخواست فعال‌سازی اشتراک</b><span>کارتینو</span></div><div class="gwb"><div class="r"><span>محصول</span><b>اشتراک ${p.t}</b></div><div class="r"><span>مدت</span><b>${fa(p.d)} روز</b></div><div class="r"><span>حساب</span><b>${me().u}</b></div><div class="r"><span>مبلغ</span><b>${money(amt)}</b></div>${cardHtml}<label class="receipt-label">تصویر رسید پرداخت را بارگذاری کن<input id="receiptFile" type="file" accept="image/png,image/jpeg,image/webp"></label><button class="btn" id="receiptSubmit" onclick="submitReceipt('${p.id}')">ارسال رسید برای بررسی</button><small>پس از ارسال تصویر، تا ۱۲ ساعت آینده تراکنش بررسی و در صورت تأیید، اشتراک فعال می‌شود. ارسال رسید به‌تنهایی به معنی فعال شدن اشتراک نیست.</small><a class="lnk" href="#plans">بازگشت به اشتراک‌ها</a></div></div>`}
async function submitReceipt(plan){const f=$('receiptFile').files[0];if(!f)return toast('اول تصویر رسید را انتخاب کن');if(f.size>3*1024*1024)return toast('حجم تصویر باید کمتر از ۳ مگابایت باشد');if(!/^image\/(png|jpeg|webp)$/.test(f.type))return toast('فرمت تصویر باید PNG، JPG یا WebP باشد');const btn=$('receiptSubmit');btn.disabled=true;btn.textContent='در حال ارسال…';const r=new FileReader();r.onload=async()=>{try{await api('/payments',{method:'POST',body:JSON.stringify({plan,receipt:r.result})});$('v-pay').innerHTML='<div class="gw"><div class="gwb" style="text-align:center"><div style="font-size:48px">✓</div><h2>رسید ثبت شد</h2><p>تا ۱۲ ساعت آینده تراکنش بررسی و در صورت تأیید، اشتراک فعال می‌شود.</p><a class="btn" href="#home">بازگشت به خانه</a></div></div>'}catch(e){btn.disabled=false;btn.textContent='ارسال رسید برای بررسی';toast(e.message)}};r.readAsDataURL(f)}
function grant(){toast('مدیریت اشتراک فقط از طریق تأیید رسید در سرور انجام می‌شود')}

/* admin */
async function renderAdmin(){const root=$('v-admin');root.innerHTML='<h1>پنل مدیریت</h1><p class="sub">در حال دریافت آمار…</p>';
try{
  const d=await api('/admin/overview'),p=await api('/admin/payments');
  const usersList=d.users||[],payments=p.payments||[],games=d.games||[];
  root.innerHTML=`<h1>پنل مدیریت</h1><div class="admin-stats"><div class="box"><small>کل کاربران</small><strong>${fa(d.stats.users)}</strong></div><div class="box"><small>اشتراک فعال</small><strong>${fa(d.stats.activeSubscriptions)}</strong></div><div class="box"><small>رسیدهای در انتظار</small><strong>${fa(d.stats.pendingPayments)}</strong></div><div class="box"><small>بازی‌های ثبت‌شده</small><strong>${fa(d.stats.games)}</strong></div></div><div class="box admin-block"><h2>کاربران</h2><div class="table-wrap"><table><tr><th>کاربر</th><th>نقش</th><th>آخرین ورود</th><th>تعداد ورود</th><th>اشتراک</th><th>عملیات</th></tr>${usersList.map(u=>`<tr><td>${u.username}</td><td>${u.role}</td><td>${u.lastLogin?new Date(u.lastLogin).toLocaleString('fa-IR'):'—'}</td><td>${u.loginCount||0}</td><td>${u.subscriptionUntil>Date.now()?dt(u.subscriptionUntil):'ندارد'}</td><td>${u.username!=='mahdi689'?`<button class="sm" onclick="setUserRole('${u.username}','${u.role==='admin'?'user':'admin'}')">${u.role==='admin'?'حذف ادمینی':'ارتقای ادمین'}</button>`:'مدیر اصلی'}</td></tr>`).join('')}</table></div></div><div class="box admin-block"><h2>سوابق بازی</h2><div class="table-wrap"><table><tr><th>کاربر</th><th>نوع بازی</th><th>نتیجه</th><th>مدت (ثانیه)</th><th>تاریخ</th></tr>${games.map(g=>`<tr><td>${g.username}</td><td>${g.mode}</td><td>${g.won?'برد':'باخت'}</td><td>${Math.max(0,Math.round((g.endedAt-g.startedAt)/1000))}</td><td>${new Date(g.endedAt).toLocaleString('fa-IR')}</td></tr>`).join('')}</table></div></div><div class="box admin-block"><h2>رسیدهای پرداخت</h2>${payments.map(x=>`<div class="payment-row"><div><b>${x.username}</b><small>${x.plan} · ${dt(x.createdAt)} · ${x.status}</small></div><a target="_blank" rel="noopener" href="${x.receiptUrl}">مشاهده رسید</a>${x.status==='pending'?`<button class="sm" onclick="reviewPayment('${x.id}',true)">تأیید و فعال‌سازی</button><button class="sm d" onclick="reviewPayment('${x.id}',false)">رد رسید</button>`:''}</div>`).join('')||'<p class="sub">هنوز رسیدی ثبت نشده است.</p>'}</div><div class="box admin-block"><h2>قیمت اشتراک‌ها</h2>
<p class="sub">قیمت‌ها بر حسب تومان است و بعد از ذخیره در صفحه اشتراک دیده می‌شود.</p>
<div style="display:grid;gap:10px;max-width:380px">${PL.map(p=>`<label style="display:flex;justify-content:space-between;align-items:center;gap:12px"><span>${p.t} (${fa(p.d)} روز)</span><input id="pr_${p.id}" type="number" min="0" step="1000" value="${price()[p.id]}" style="width:150px;text-align:left" dir="ltr"></label>`).join('')}</div>
<button class="btn" style="margin-top:12px" onclick="savePr()">ذخیره قیمت‌ها</button>
</div>
<div class="box admin-block"><h2>کارت مقصد پرداخت</h2>
<p class="sub">عکس و مشخصات کارت در صفحه پرداخت به کاربران نمایش داده می‌شود.</p>
<div style="margin:10px 0;text-align:center">${bankInfo().image?`<img src="${bankInfo().image}" alt="پیش‌نمایش" style="max-width:100%;width:360px;border-radius:12px;border:1px solid rgba(255,255,255,.12)">`:'<p class="sub">عکسی تنظیم نشده</p>'}</div>
<div style="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0">
<label class="btn" style="cursor:pointer">انتخاب عکس جدید<input type="file" accept="image/png,image/jpeg,image/webp" style="display:none" onchange="onPayImageSelected(this)"></label>
<button class="sm" onclick="resetPayImage()">بازگشت به عکس پیش‌فرض</button>
<button class="sm d" onclick="removePayImage()">حذف عکس</button>
</div>
<label style="display:block;margin:8px 0">شماره کارت (۱۶ رقم)<input id="bankCard" type="text" inputmode="numeric" maxlength="19" dir="ltr" placeholder="6037..." value="${(bankInfo().card||'').replace(/\s/g,'')}" style="width:100%;max-width:280px;margin-top:6px"></label>
<label style="display:block;margin:8px 0">نام صاحب حساب<input id="bankName" type="text" placeholder="نام و نام خانوادگی" value="${bankInfo().name||''}" style="width:100%;max-width:280px;margin-top:6px"></label>
<button class="btn" style="margin-top:10px" onclick="saveBank()">ذخیره شماره و نام</button>
</div>
<div class="box admin-block"><h2>تاریخچه تغییرات حساب‌ها</h2><div class="table-wrap"><table><tr><th>رویداد</th><th>کاربر</th><th>انجام‌دهنده</th><th>جزئیات</th><th>زمان</th></tr>${(d.audit||[]).map(a=>`<tr><td>${a.action}</td><td>${a.username}</td><td>${a.actor}</td><td>${a.details?.role||a.details?.plan||a.details?.previousUsername||'—'}</td><td>${new Date(a.at).toLocaleString('fa-IR')}</td></tr>`).join('')}</table></div></div><div class="box admin-block"><h2>مدیریت محتوای بلاگ</h2><p class="sub">یک نوشته‌ی جدید برای نمایش در انتهای صفحه بلاگ منتشر کن.</p><input id="adminBlogTitle" placeholder="عنوان نوشته" maxlength="120"><textarea id="adminBlogContent" rows="6" maxlength="12000" placeholder="متن نوشته"></textarea><button class="btn" onclick="saveBlogPost()">ذخیره و انتشار</button></div>`;
}catch(e){
  /* حالت آفلاین: نمایش کاربران محلی */
  const list=Object.keys(users).map(uname=>{
    const u=users[uname]||{};
    return {username:uname,role:u.role||(uname===ADMIN.u?'admin':'user'),end:u.end||0,uid:u.uid||'—'};
  });
  if(!list.find(x=>x.username===ADMIN.u)) list.unshift({username:ADMIN.u,role:'admin',end:0,uid:'—'});
  const gamesCount=+store.get('hkGames',0)||0;
  root.innerHTML=`<h1>پنل مدیریت <small style="font-size:14px;color:var(--muted)">(حالت آفلاین)</small></h1>
  <div class="note">سرور در دسترس نیست. آمار و کاربران از داده‌های همین مرورگر نمایش داده می‌شود.</div>
  <div class="admin-stats">
    <div class="box"><small>کل کاربران محلی</small><strong>${fa(list.length)}</strong></div>
    <div class="box"><small>بازی‌های ثبت‌شده (محلی)</small><strong>${fa(gamesCount)}</strong></div>
    <div class="box"><small>نقش شما</small><strong>ادمین</strong></div>
  </div>
  <div class="box admin-block"><h2>کاربران محلی</h2>
  <div class="table-wrap"><table><tr><th>کاربر</th><th>نقش</th><th>آیدی</th><th>اشتراک</th><th>عملیات</th></tr>
  ${list.map(u=>`<tr><td>${u.username}</td><td>${u.role}</td><td>${u.uid}</td><td>${u.end>Date.now()?dt(u.end):'ندارد'}</td>
  <td>${u.username!==ADMIN.u?`<button class="sm" onclick="offlineToggleRole('${u.username}')">${u.role==='admin'?'حذف ادمینی':'ارتقای ادمین'}</button>
  <button class="sm d" onclick="offlineDelU('${u.username}')">حذف</button>`:'مدیر اصلی'}</td></tr>`).join('')}
  </table></div></div>
  <div class="box admin-block"><h2>قیمت اشتراک‌ها</h2>
<p class="sub">قیمت‌ها بر حسب تومان است.</p>
<div style="display:grid;gap:10px;max-width:380px">${PL.map(p=>`<label style="display:flex;justify-content:space-between;align-items:center;gap:12px"><span>${p.t} (${fa(p.d)} روز)</span><input id="pr_${p.id}" type="number" min="0" step="1000" value="${price()[p.id]}" style="width:150px;text-align:left" dir="ltr"></label>`).join('')}</div>
<button class="btn" style="margin-top:12px" onclick="savePr()">ذخیره قیمت‌ها</button>
</div>
<div class="box admin-block"><h2>کارت مقصد پرداخت</h2>
<p class="sub">عکس و مشخصات کارت در صفحه پرداخت به کاربران نمایش داده می‌شود.</p>
<div style="margin:10px 0;text-align:center">${bankInfo().image?`<img src="${bankInfo().image}" alt="پیش‌نمایش" style="max-width:100%;width:360px;border-radius:12px;border:1px solid rgba(255,255,255,.12)">`:'<p class="sub">عکسی تنظیم نشده</p>'}</div>
<div style="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0">
<label class="btn" style="cursor:pointer">انتخاب عکس جدید<input type="file" accept="image/png,image/jpeg,image/webp" style="display:none" onchange="onPayImageSelected(this)"></label>
<button class="sm" onclick="resetPayImage()">بازگشت به عکس پیش‌فرض</button>
<button class="sm d" onclick="removePayImage()">حذف عکس</button>
</div>
<label style="display:block;margin:8px 0">شماره کارت (۱۶ رقم)<input id="bankCard" type="text" inputmode="numeric" maxlength="19" dir="ltr" placeholder="6037..." value="${(bankInfo().card||'').replace(/\s/g,'')}" style="width:100%;max-width:280px;margin-top:6px"></label>
<label style="display:block;margin:8px 0">نام صاحب حساب<input id="bankName" type="text" placeholder="نام و نام خانوادگی" value="${bankInfo().name||''}" style="width:100%;max-width:280px;margin-top:6px"></label>
<button class="btn" style="margin-top:10px" onclick="saveBank()">ذخیره شماره و نام</button>
</div>
<div class="box admin-block"><h2>اعطای اشتراک محلی</h2>
  <p class="sub">برای تست امکانات ویژه، اشتراک ۳۰ روزه به یک کاربر بده.</p>
  <input id="offSubUser" placeholder="نام کاربری" style="max-width:220px;margin-inline-end:8px">
  <button class="btn" onclick="offlineGrantSub()">فعال‌سازی ۳۰ روز</button>
  </div>`;
}
}
function offlineToggleRole(u){if(!users[u])return;users[u].role=users[u].role==='admin'?'user':'admin';saveU();renderAdmin()}
function offlineDelU(u){if(u===ADMIN.u)return toast('مدیر اصلی قابل حذف نیست');delete users[u];saveU();renderAdmin()}
function offlineGrantSub(){const u=($('offSubUser')&&$('offSubUser').value||'').trim().toLowerCase();if(!u)return toast('نام کاربری را وارد کن');if(!users[u]){users[u]={role:'user',uid:genUid(),end:0};}users[u].end=Date.now()+30*864e5;saveU();if(serverUser&&serverUser.username===u){serverUser.subscriptionUntil=users[u].end}toast('اشتراک ۳۰ روزه فعال شد');renderAdmin()}

function delU(u){delete users[u];saveU();renderAdmin()}
function savePr(){const o={};PL.forEach(p=>o[p.id]=Math.max(0,+$('pr_'+p.id).value||0));store.set('hkPr',JSON.stringify(o));toast('قیمت‌ها ذخیره شد');try{if((location.hash||'').indexOf('plans')>=0)renderPlans()}catch(e){}}
function saveBank(){const card=($('bankCard')&&$('bankCard').value||'').replace(/\D/g,'');const name=($('bankName')&&$('bankName').value||'').trim();if(card&&card.length!==16)return toast('شماره کارت باید ۱۶ رقم باشد');const prev=bankInfo();const image=prev.image||'';store.set('hkBank',JSON.stringify({card:card?card.replace(/(\d{4})(?=\d)/g,'$1 ').trim():'',name,image}));toast('اطلاعات کارت ذخیره شد')}
function onPayImageSelected(input){const f=input.files&&input.files[0];if(!f)return;if(f.size>2*1024*1024)return toast('حجم عکس حداکثر ۲ مگابایت');if(!/^image\/(png|jpeg|webp)$/.test(f.type))return toast('فرمت باید PNG، JPG یا WebP باشد');const r=new FileReader();r.onload=()=>{const prev=bankInfo();store.set('hkBank',JSON.stringify({card:prev.card||'',name:prev.name||'',image:r.result}));toast('عکس کارت ذخیره شد');renderAdmin()};r.readAsDataURL(f)}
function removePayImage(){const prev=bankInfo();store.set('hkBank',JSON.stringify({card:prev.card||'',name:prev.name||'',image:''}));toast('عکس کارت حذف شد');renderAdmin()}
function resetPayImage(){const prev=bankInfo();store.set('hkBank',JSON.stringify({card:prev.card||'',name:prev.name||'',image:DEFAULT_PAY_IMG}));toast('عکس پیش‌فرض بازگردانی شد');renderAdmin()}

/* customize */
const TB=[['کلاسیک آبی','#143072','#040d2a','#3b2314'],['سنتی سبز','#1c7a63','#0a3a2f','#8a5a30'],['سلطنتی قرمز','#b12a37','#4a0b18','#7a5028'],['طلایی مشکی','#363b4d','#080a12','#c9a24a'],['مدرن بنفش','#8039b8','#2a0f45','#5a2d90'],['سنتی ایرانی','#a76a3a','#42210f','#6b3a1c'],['فیروزه‌ای','#1aa5a5','#063d45','#b98a45'],['شب زمردی','#0f6b4e','#02160f','#d4af37'],['رزگلد','#c98a8a','#5c2f3a','#d9a07a'],['یخی نقره‌ای','#7fa6c9','#1d3550','#c9d3de'],['شرابی','#7a1236','#26040f','#a9743a'],['غروب نارنجی','#e0742c','#5a1d0c','#8a4a22']];
const BK=[['کلاسیک','#12306b','#f0e8d2','s'],['سلطنتی','#7b1522','#f5d7ba','s'],['طلایی','#21170b','#d8a744','d'],['سنتی','#064c3d','#e2d8b5','d'],['مدرن','#2a1263','#b79cff','r'],['اختصاصی','#0b0b0f','#c9a24a','c'],['فیروزه','#0b4f57','#7ff0e6','w'],['یاقوتی','#5b0a2a','#ff9db8','r'],['سرمه‌ای طلایی','#0a1633','#f4c65e','h'],['نقره‌ای','#1b2430','#cfd8e3','d'],['نارنجی','#6a2a0b','#ffb066','c'],['زمردی','#073b2a','#7be0a8','w']];
const BP=(t,a,b)=>({s:`repeating-linear-gradient(45deg,${a} 0 4px,${b} 4px 5px,${a} 5px 8px)`,d:`repeating-linear-gradient(45deg,transparent 0 6px,${b} 6px 7px),repeating-linear-gradient(-45deg,transparent 0 6px,${b} 6px 7px)`,r:`radial-gradient(circle,${b} 1.5px,transparent 2px)`,c:`conic-gradient(${b} 25%,transparent 0 50%,${b} 0 75%,transparent 0)`,w:`repeating-radial-gradient(circle at 50% 50%,${a} 0 5px,${b} 5px 6px)`,h:`repeating-linear-gradient(90deg,${a} 0 6px,${b} 6px 8px)`}[t]);
const BSZ={r:'9px 9px',c:'12px 12px'};
const PAT=['repeating-radial-gradient(circle at 50% 50%,transparent 0 24px,#fff 24px 25px)','repeating-linear-gradient(45deg,transparent 0 18px,#fff 18px 19px)','radial-gradient(circle,#fff 1.5px,transparent 2px) 0 0/16px 16px','none'];
let tb=+store.get('hkT',0),bk=+store.get('hkB',0);
function feltVars(el,i){const t=TB[i],s=el.style;s.setProperty('--felt1',t[1]);s.setProperty('--felt2',t[2]);s.setProperty('--rim',t[3]);s.setProperty('--pat',PAT[i%4])}
function backVars(el,i){const b=BK[i],s=el.style;s.setProperty('--b1',b[1]);s.setProperty('--b2',b[2]);s.setProperty('--bp',BP(b[3],b[1],b[2]));s.setProperty('--bs',BSZ[b[3]]||'auto')}
function applyLook(){applyFace();const ti=hasSub()?tb:0,bi=hasSub()?bk:0;
 ['felt','pv'].forEach(i=>{const e=$(i);if(e){e.className='felt';feltVars(e,ti)}});backVars(document.documentElement,bi);
 const f=$('pvFan');if(f){f.innerHTML='';for(let i=0;i<5;i++)f.appendChild(cardEl(null,true));$('pvName').textContent=T('میز')+' '+T(TB[ti][0])+' · '+T('پشت کارت')+' '+T(BK[bi][0])}
 document.querySelectorAll('.skin').forEach((e,i)=>e.classList.toggle('sel',i===ti));document.querySelectorAll('.bk').forEach((e,i)=>e.classList.toggle('sel',i===bi))}
function renderLook(){const s=hasSub();
 $('lookBan').innerHTML=s?'':'<div class="note" style="margin:0 0 14px">'+T('تغییر طرح‌ها فقط برای مشترکین است.')+' <a href="#plans" style="color:var(--gold);text-decoration:underline">خرید اشتراک</a></div>';
 $('skins').innerHTML=TB.map((t,i)=>`<button class="skin${!s&&i?' lock':''}" onclick="pickT(${i})"><i class="felt" style="--felt1:${t[1]};--felt2:${t[2]};--rim:${t[3]}"></i>${t[0]}</button>`).join('');
 $('backs').innerHTML=BK.map((b,i)=>`<button class="bk${!s&&i?' lock':''}" aria-label="${b[0]}" onclick="pickB(${i})"></button>`).join('');
 document.querySelectorAll('.bk').forEach((e,i)=>backVars(e,i));applyLook();renderFaces()}
function lockMsg(){toast('این طرح مخصوص مشترکین است');setTimeout(()=>go('plans'),700)}
function pickT(i){if(i&&!hasSub())return lockMsg();tb=i;store.set('hkT',i);applyLook()}
function pickB(i){if(i&&!hasSub())return lockMsg();bk=i;store.set('hkB',i);applyLook()}

/* routing */
function route(){const v=(location.hash||'#login').slice(1),base=v.split('-')[0];if(base!=='game'&&gameMode==='bot'&&live){saveBotSnapshot();stopTimer()}
 if(!['home','game','look','plans','rank','login','admin','pay','settings','blog'].includes(base))return go(me()?'home':'login');
 document.body.dataset.page=base;document.body.classList.toggle('lgbody',base==='login');
 if(base!=='login'&&!me()){setA(base==='pay'?v:base);return go('login')}
 if(base==='login'&&me())return go('home');
 document.body.classList.add('ok');renderHdr();document.querySelectorAll('.view').forEach(e=>e.classList.toggle('on',e.id==='v-'+base));fxRoute(base);Aud.play(base==='login'?'login':base==='game'?'game':'menu');if(base==='settings')renderSettings();if(base==='home')playIntro();scrollTo(0,0);
 if(base==='admin'&&!isAdmin()){setA('admin');toast('این بخش فقط برای ادمین است');return setTimeout(()=>go('login'),900)}
 if(base==='pay'){if(!PL.find(p=>'pay-'+p.id===v))return go('plans');if(!me()){setA(v);toast('اول وارد حساب شو');return setTimeout(()=>go('login'),900)}}
 document.querySelectorAll('nav a').forEach(a=>a.classList.toggle('on',a.dataset.v===base));
 document.body.classList.toggle('home',base==='home');
 if(base==='home')renderHome();if(base==='blog')loadBlogPost();if(base==='plans')renderPlans();if(base==='look')renderLook();if(base==='pay')renderPay(v);if(base==='admin')renderAdmin();
 if(base==='game'){applyLook();if(gameMode==='online'){showOnlineMode()}else if(gameMode==='friends'){showFriendsMode()}else if(gameMode==='bot'){let snap=null;try{snap=JSON.parse(sessionStorage.getItem('kartinoBotSnapshot')||'null')}catch(e){}if(snap&&snap.live){$('modeGate').hidden=true;$('gameBoard').hidden=true;$('botResume').hidden=false}else{$('modeGate').hidden=false;$('gameBoard').hidden=true;$('botResume').hidden=true}}}
 if(base==='rank'){$('stP').textContent=fa(store.get('hkP',0));$('stW').textContent=fa(store.get('hkW',0))}}


/* ===== settings, audio, cinematic ===== */
const ST={bri:+store.get('hkBri',0),mv:+store.get('hkMv',60),sv:+store.get('hkSv',70),df:+store.get('hkDf',1),spd:+store.get('hkSpd',55)};
const FX_ITEMS=[
{id:'hand',label:'افکت هر دست',desc:'بعد از تمام شدن هر دست (۴ کارت روی میز)، افکت کوتاه سینمایی روی میز'},
{id:'set',label:'افکت هر ست',desc:'بعد از برد یک ست (۷ دست)، لوگوی کارتینو تمام‌صفحه روی کل میز'},
{id:'burst',label:'ترکه و کانفتی',desc:'پخش ذرات رنگی روی میز در برد کامل بازی یا لحظات ویژه'},
{id:'shake',label:'لرزش میز',desc:'لرزش کوتاه میز هنگام ضربه، حکم یا برد'},
{id:'cine',label:'نوار سینمایی',desc:'نوار مشکی بالا و پایین صفحه در لحظات خاص'},
{id:'flash',label:'فلاش نور',desc:'فلاش طلایی/رنگی لحظه‌ای روی کل صفحه'},
{id:'title',label:'عنوان روی میز',desc:'متن بزرگ وسط میز مثل اعلام حاکم یا رویداد'}
];
const SFX_ITEMS=[
{id:'card',label:'انداختن کارت',desc:'صدای هر بار انداختن یک کارت روی میز'},
{id:'deal',label:'پخش ورق',desc:'صدای شروع دور و پخش کارت‌ها بین بازیکنان'},
{id:'hit',label:'ضربه / حکم',desc:'صدای انتخاب حکم، کت، یا رویدادهای قوی'},
{id:'whoosh',label:'ورود صفحه',desc:'صدای ورود اولیه و جلوه‌های انتقال صفحه'},
{id:'win',label:'برد کل بازی',desc:'صدای جشن وقتی یک تیم کل بازی را می‌برد'},
{id:'trick',label:'برد دست',desc:'صدای کوتاه بعد از برد هر دست'},
{id:'set',label:'برد ست',desc:'صدای مخصوص بعد از تمام شدن یک ست (۷ دست)'}
];
function loadPrefMap(key,ids){const base={};ids.forEach(i=>base[i]=true);try{return Object.assign(base,JSON.parse(store.get(key,'')||'{}'))}catch(e){return base}}
const FXPREF=loadPrefMap('hkFx',FX_ITEMS.map(x=>x.id));
/* گوشی (صفحه لمسی): اگر کاربر قبلاً تنظیمی ذخیره نکرده، افکت‌های تمام‌صفحه‌ای که هر چند ثانیه تکرار می‌شوند
   (تیرگی و لرزش هر دست، فلاش نور، نوار سینمایی) خاموش شروع می‌شوند؛ حس «اتصالی و چشمک» از همین‌ها بود.
   کاربر هر وقت خواست از تنظیمات ← افکت‌های تصویری روشنشان می‌کند. */
try{if(!store.get('hkFx','')&&matchMedia('(pointer:coarse)').matches)['hand','shake','flash','cine'].forEach(k=>{FXPREF[k]=false})}catch(e){}
const SFXPREF=loadPrefMap('hkSfx',SFX_ITEMS.map(x=>x.id));
function fxOn(id){return FXPREF[id]!==false}
function sfxOn(id){return SFXPREF[id]!==false}
function saveFxPref(){store.set('hkFx',JSON.stringify(FXPREF))}
function saveSfxPref(){store.set('hkSfx',JSON.stringify(SFXPREF))}
function toggleFxPanel(){const p=$('fxPanel');if(!p)return;if(p.hidden){p.hidden=false;p.innerHTML=FX_ITEMS.map(x=>`<label><span>${x.label}</span><small>${x.desc||''}</small><input type="checkbox" ${FXPREF[x.id]!==false?'checked':''} onchange="FXPREF['${x.id}']=this.checked;saveFxPref()"></label>`).join('');}else p.hidden=true}
function toggleSfxPanel(){const p=$('sfxPanel');if(!p)return;if(p.hidden){p.hidden=false;p.innerHTML=SFX_ITEMS.map(x=>`<label><span>${x.label}</span><small>${x.desc||''}</small><input type="checkbox" ${SFXPREF[x.id]!==false?'checked':''} onchange="SFXPREF['${x.id}']=this.checked;saveSfxPref()"></label>`).join('');}else p.hidden=true}

function gameDelay(base){const s=Math.max(0,Math.min(100,ST.spd??55));const mult=1.85-(s/100)*1.45;return Math.max(120,Math.round(base*mult))}
function applyGameSpeed(){const s=Math.max(0,Math.min(100,ST.spd??55));const ms=Math.round(420-(s/100)*280);document.documentElement.style.setProperty('--card-drop-ms',ms+'ms')}
applyGameSpeed();
function applyBri(){const d=$('dim');d.style.background=ST.bri<0?'#000':'#fff';d.style.mixBlendMode=ST.bri<0?'normal':'soft-light';d.style.opacity=Math.abs(ST.bri)/(ST.bri<0?100:60)}
function setST(k,v,key){ST[k]=+v;store.set(key,v);if(k==='bri')applyBri();if(k==='mv'||k==='sv')Aud.vol();if(k==='df')renderSettings();if(k==='spd')applyGameSpeed()}
function renderSettings(){$('stBri').value=ST.bri;$('stMv').value=ST.mv;$('stSv').value=ST.sv;if($('stSpd'))$('stSpd').value=ST.spd;document.querySelectorAll('[data-d]').forEach(b=>b.classList.toggle('on',+b.dataset.d===ST.df));
 const u=meU||'—';if($('stUser'))$('stUser').textContent=u;if($('stUid'))$('stUid').textContent=getUid();
 const av=$('avPreview');if(av)av.src=getAvatar();
 const samples=$('avSamples');if(samples){samples.innerHTML=AV_SAMPLES.map((s,i)=>'<img class="av-sample'+(getAvatar()===s?' on':'')+'" src="'+s+'" onclick="setAvatar(AV_SAMPLES['+i+']);renderSettings()">').join('')+'<button class="btn alt sm" onclick="pickAvatar()">از گالری</button>'}}
function pickAvatar(){const f=$('avFile');if(f)f.click()}
function onAvatarFile(inp){const file=inp.files&&inp.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{setAvatar(r.result);renderSettings()};r.readAsDataURL(file)}
function copyUid(){const id=getUid();if(navigator.clipboard)navigator.clipboard.writeText(id).then(()=>toast('آیدی کپی شد: '+id)).catch(()=>toast(id));else toast(id)}
async function changeUsername(){const nu=($('stNewU')&&$('stNewU').value||'').trim().toLowerCase();if(!meU||meU===ADMIN.u)return toast('مدیر اصلی نمی‌تواند نام را عوض کند');try{const d=await api('/account/username',{method:'PATCH',body:JSON.stringify({username:nu})});setServerUser(d.user);toast('نام کاربری تغییر کرد');renderSettings();renderHdr()}catch(e){toast(e.message)}}
async function changePassword(){const oldP=$('stOldP')&&$('stOldP').value||'',np=$('stNewP')&&$('stNewP').value||'';if(np.length<10)return toast('رمز جدید حداقل ۱۰ کاراکتر باشد');try{await api('/account/password',{method:'PATCH',body:JSON.stringify({currentPassword:oldP,newPassword:np})});toast('رمز عبور تغییر کرد');$('stOldP').value='';$('stNewP').value=''}catch(e){toast(e.message)}}

const Aud=(()=>{let ctx,mg,sg,rv,bus,nb,cur='',want='',ti=0,step=0,nt=0,muted=store.get('hkMute','0')==='1';
 const hz=m=>440*Math.pow(2,(m-69)/12);
 function init(){if(ctx)return true;try{ctx=new(window.AudioContext||window.webkitAudioContext)()}catch(e){return false}
  mg=ctx.createGain();sg=ctx.createGain();rv=ctx.createDelay(1);const fb=ctx.createGain(),lp=ctx.createBiquadFilter(),wet=ctx.createGain();
  rv.delayTime.value=.34;fb.gain.value=.4;lp.type='lowpass';lp.frequency.value=2000;wet.gain.value=.45;
  rv.connect(lp);lp.connect(fb);fb.connect(rv);lp.connect(wet);wet.connect(mg);mg.connect(ctx.destination);sg.connect(ctx.destination);
  nb=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;vol();return true}
 function vol(){if(!ctx)return;mg.gain.value=muted?0:Math.pow(ST.mv/100,2)*.55;sg.gain.value=muted?0:Math.pow(ST.sv/100,2)}
 function note(f,t,d,ty,g,to){const o=ctx.createOscillator(),e=ctx.createGain();o.type=ty;o.frequency.value=f;e.gain.setValueAtTime(0,t);e.gain.linearRampToValueAtTime(g,t+.02);e.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(e);e.connect(to||bus);o.start(t);o.stop(t+d+.05)}
 function pad(f,t,d,g){const e=ctx.createGain(),lp=ctx.createBiquadFilter();lp.type='lowpass';lp.frequency.value=650;e.gain.setValueAtTime(0,t);e.gain.linearRampToValueAtTime(g,t+d*.45);e.gain.linearRampToValueAtTime(0,t+d);lp.connect(e);e.connect(bus);[1,1.007].forEach(k=>{const o=ctx.createOscillator();o.type='sawtooth';o.frequency.value=f*k;o.connect(lp);o.start(t);o.stop(t+d+.05)})}
 function nz(t,d,ty,f,g,to,f2){const s=ctx.createBufferSource(),fl=ctx.createBiquadFilter(),e=ctx.createGain();s.buffer=nb;s.loop=true;fl.type=ty;fl.frequency.setValueAtTime(f,t);if(f2)fl.frequency.exponentialRampToValueAtTime(f2,t+d);e.gain.setValueAtTime(g,t);e.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(fl);fl.connect(e);e.connect(to||bus);s.start(t);s.stop(t+d+.05)}
 function kick(t,g,to){const o=ctx.createOscillator(),e=ctx.createGain();o.frequency.setValueAtTime(130,t);o.frequency.exponentialRampToValueAtTime(40,t+.2);e.gain.setValueAtTime(g,t);e.gain.exponentialRampToValueAtTime(.0001,t+.35);o.connect(e);e.connect(to||bus);o.start(t);o.stop(t+.4)}
 const TR={login:{bpm:60,r:50,sc:[0,1,4,5,7,8,10],pr:[0,0,3,4],pc:0,ar:.5},menu:{bpm:76,r:52,sc:[0,2,3,5,7,8,10],pr:[0,5,3,4],pc:1,ar:.6},game:{bpm:98,r:50,sc:[0,1,4,5,7,8,11],pr:[0,0,4,0],pc:2,ar:.7}};
 function sched(T,s,t,sd){const b=s%8,deg=T.pr[(s/8|0)%T.pr.length],rt=T.r+T.sc[deg];
  if(b===0){pad(hz(rt),t,8*sd,.08);pad(hz(rt+7),t,8*sd,.05);note(hz(rt-12),t,7*sd,'sine',.22)}
  if(Math.random()<(b%2?T.ar/3:T.ar)){const i=Math.random()*9|0;note(hz(T.r+12+T.sc[i%7]+12*(i/7|0)),t,sd*2.4,'triangle',.1)}
  if(T.pc>=1&&(b===0||b===4))kick(t,.35);
  if(T.pc===2){if(b===2||b===6)nz(t,.1,'bandpass',1100,.18);if(b%2)nz(t,.04,'highpass',7000,.05);if(b===3)kick(t,.2)}
  else if(T.pc===1&&b===6)nz(t,.12,'bandpass',900,.1)}
 function tick(){const T=TR[cur];if(!T||!ctx)return;const sd=30/T.bpm;while(nt<ctx.currentTime+.25){sched(T,step,nt,sd);nt+=sd;step++}}
 function play(n){want=n;if(!ctx||ctx.state!=='running'||n===cur)return;const now=ctx.currentTime;
  if(bus){const ob=bus;ob.gain.setTargetAtTime(0,now,.35);setTimeout(()=>ob.disconnect(),2500)}
  bus=ctx.createGain();bus.gain.value=0;bus.gain.setTargetAtTime(1,now,.5);bus.connect(mg);bus.connect(rv);cur=n;step=0;nt=now+.1;if(!ti)ti=setInterval(tick,60)}
 function start(){if(!init())return;if(ctx.state!=='running')ctx.resume().then(()=>play(want));else if(want&&cur!==want)play(want)}
 function sfx(n){if(!ctx||ctx.state!=='running'||muted)return;if(typeof sfxOn==='function'&&!sfxOn(n))return;const t=ctx.currentTime;
  if(n==='card')nz(t,.07,'bandpass',2600,.32,sg);
  else if(n==='deal')for(let i=0;i<5;i++)nz(t+i*.07,.06,'bandpass',2200,.22,sg);
  else if(n==='hit'){kick(t,.55,sg);nz(t,.45,'lowpass',480,.28,sg,60)}
  else if(n==='whoosh')nz(t,1.2,'bandpass',220,.28,sg,3600);
  else if(n==='win'){kick(t,.55,sg);[0,4,7,12].forEach((m,i)=>note(hz(64+m),t+.12+i*.1,1.0,'triangle',.12,sg))}
  else if(n==='trick'){[0,5,9].forEach((m,i)=>note(hz(69+m),t+i*.07,.4,'sine',.06,sg))}
  else if(n==='set'){kick(t,.4,sg);[0,4,7,12].forEach((m,i)=>note(hz(60+m),t+.1+i*.09,.7,'triangle',.09,sg))}}
 return{start,play,sfx,vol,muted:()=>muted,toggle(){muted=!muted;store.set('hkMute',muted?'1':'0');vol();document.querySelectorAll('.mt').forEach(b=>b.textContent=muted?'🔇':'🔊')}}})();
['pointerdown','keydown'].forEach(e=>addEventListener(e,()=>Aud.start(),{passive:true}));
function cine(ms){if(!fxOn('cine'))return;const l=$('lb');l.classList.add('on');setTimeout(()=>l.classList.remove('on'),ms||2800)}
function flash(kind){if(!fxOn('flash'))return;const f=$('flash');f.className='';void f.offsetWidth;f.className=(kind||'gold')+'-flash on'}
function shake(){if(!fxOn('shake'))return;const f=$('felt');f.classList.remove('shk');void f.offsetWidth;f.classList.add('shk')}
function titleCard(a,b){const e=$('tc');e.innerHTML='<small>'+b+'</small><b>'+a+'</b>';e.classList.remove('on');void e.offsetWidth;e.classList.add('on')}
function fxWin(){burst('gold');flash('gold');cine(3400);shake();sparkleRing();Aud.sfx('win')}
function fxKat(){burst('red');flash('red');cine(2200);shake();Aud.sfx('hit')}

function fxHandWin(p){
  if(!fxOn('hand'))return;
  const f=$('felt');if(!f)return;
  f.querySelectorAll('.hwfx,.swfx').forEach(e=>e.remove());
  const team=p%2===0;
  const layer=document.createElement('div');layer.className='hwfx';
  const veil=document.createElement('div');veil.className='hwfx-veil';
  const bloom=document.createElement('div');bloom.className='hwfx-bloom';
  if(!team)bloom.style.background='radial-gradient(circle,#6aa8ff22 0%,transparent 70%)';
  const arc=document.createElement('div');arc.className='hwfx-arc';
  const mark=document.createElement('div');mark.className='hwfx-mark';mark.textContent=team?'✦':'✧';
  const title=document.createElement('div');title.className='hwfx-title';
  title.innerHTML='<b>'+(team?'دست برد':'دست حریف')+'</b><small>'+nm(p)+'</small>';
  layer.appendChild(veil);layer.appendChild(bloom);layer.appendChild(arc);layer.appendChild(mark);layer.appendChild(title);
  const suits=['♠','♥','♦','♣'];
  for(let i=0;i<4;i++){
    const s=document.createElement('div');s.className='hwfx-suit';s.textContent=suits[i];
    s.style.setProperty('--a',(i/4*360)+'deg');
    s.style.setProperty('--r','32%');
    s.style.animationDelay=(0.05*i)+'s';
    s.style.color=(suits[i]==='♥'||suits[i]==='♦')?'#d8899a':'#d4b46a';
    layer.appendChild(s);
  }
  f.appendChild(layer);
  if(fxOn('shake'))shake();
  try{Aud.sfx('trick')}catch(e){}
  setTimeout(()=>{try{layer.remove()}catch(e){}},1000);
}
function fxSetWin(teamIdx){
  if(!fxOn('set'))return;
  const f=$('felt');if(!f)return;
  f.querySelectorAll('.hwfx,.swfx').forEach(e=>e.remove());
  const team=teamIdx===0;
  const layer=document.createElement('div');layer.className='swfx';
  const veil=document.createElement('div');veil.className='swfx-veil';
  const bloom=document.createElement('div');bloom.className='swfx-bloom';
  if(!team)bloom.style.background='radial-gradient(circle,#6aa8ff33 0%,#2a4d8a18 32%,transparent 64%)';
  const rays=document.createElement('div');rays.className='swfx-rays';
  const ring=document.createElement('div');ring.className='swfx-ring';
  const ring2=document.createElement('div');ring2.className='swfx-ring2';
  const badge=document.createElement('div');badge.className='swfx-badge';
  const img=document.createElement('img');img.src='images/kartino-badge.png';img.alt='Kartino';
  badge.appendChild(img);
  const title=document.createElement('div');title.className='swfx-title';
  title.innerHTML='<b>'+(team?'ست برای تو':'ست حریف')+'</b><small>KARTINO</small>';
  layer.appendChild(veil);layer.appendChild(bloom);layer.appendChild(rays);layer.appendChild(ring);layer.appendChild(ring2);layer.appendChild(badge);layer.appendChild(title);
  const suits=['♠','♥','♦','♣'];
  for(let i=0;i<8;i++){
    const s=document.createElement('div');s.className='swfx-suit';s.textContent=suits[i%4];
    s.style.setProperty('--a',(i/8*360)+'deg');
    s.style.setProperty('--r',(40+Math.random()*18)+'%');
    s.style.animationDelay=(0.04*i)+'s';
    s.style.color=(suits[i%4]==='♥'||suits[i%4]==='♦')?'#e0899a':'#d4b46a';
    layer.appendChild(s);
  }
  for(let i=0;i<22;i++){
    const c=document.createElement('span');c.className='swfx-chip';
    const ang=Math.random()*Math.PI*2,dist=40+Math.random()*130;
    c.style.left='50%';c.style.top='42%';
    c.style.setProperty('--dx',(Math.cos(ang)*dist)+'px');
    c.style.setProperty('--dy',(Math.sin(ang)*dist)+'px');
    c.style.animationDelay=(Math.random()*0.25)+'s';
    c.style.background=['#e8b04a','#c9a24a','#f0d78c','#8eb7e0'][i%4];
    layer.appendChild(c);
  }
  const bar=document.createElement('div');bar.className='swfx-bar';layer.appendChild(bar);
  f.appendChild(layer);
  if(fxOn('shake'))shake();
  try{Aud.sfx('set')}catch(e){}
  setTimeout(()=>{try{layer.remove()}catch(e){}},1800);
}

function fxHakem(){burst('teal');flash('teal');titleCard(T('حاکم جدید'),'👑');Aud.sfx('deal')}
function sparkleRing(){const f=$('felt');if(!f)return;
 for(let i=0;i<24;i++){const s=document.createElement('span');s.className='spark';
  const ang=i/24*Math.PI*2,r=38+Math.random()*12;
  s.style.left=(50+Math.cos(ang)*r)+'%';s.style.top=(48+Math.sin(ang)*r)+'%';
  s.style.animationDelay=(Math.random()*.4)+'s';f.appendChild(s);setTimeout(()=>s.remove(),1800)}}
function confettiStorm(){const f=$('felt');if(!f)return;const cols=['#e8b04a','#c0283d','#2aa6a0','#f6efdc','#fff','#ff6b9d'];
 for(let i=0;i<90;i++){const s=document.createElement('span');s.className='cf cf2';
  s.style.left=Math.random()*100+'%';s.style.background=cols[i%cols.length];
  s.style.width=(6+Math.random()*8)+'px';s.style.height=(8+Math.random()*12)+'px';
  s.style.animationDuration=(1.8+Math.random()*1.8)+'s';s.style.animationDelay=Math.random()*.5+'s';
  f.appendChild(s);setTimeout(()=>s.remove(),4000)}}
function leaveGame(){if(gameMode==='bot'&&live)saveBotSnapshot();stopTimer();paused=false;if($("pauseBtn"))$("pauseBtn").style.display="none";go("home")}
/* ===== game ===== */
const GL={S:'♠',H:'♥',D:'♦',C:'♣'},SSN=['کلاسیک','چهاررنگ','توخالی'],ARN=['جنگاور اسپارتی','سلطنتی','ایرانی'];
const FT=[
 {n:'کلاسیک عاجی',bg:'#fbf8ef',ink:'#1b1b1f',red:'#c8282f',acc:'#b8892f',fr:'thin',ace:'plain',cb:['#f0e2bd','#d9b86a']},
 {n:'اسپارتی',bg:'#f4efe6',ink:'#17120f',red:'#b3201c',acc:'#9a6b32',fr:'dbl',ace:'laurel',cb:['#ecd0a8','#8a3a1c']},
 {n:'سیاه و طلایی',bg:'#16130d',ink:'#e8b04a',red:'#ff7a6a',acc:'#e8b04a',fr:'dbl',ace:'baroque',cb:['#2b2412','#6b5320']},
 {n:'ایرانی سرمه‌ای',bg:'#10224d',ink:'#f4d58a',red:'#ff9aa8',acc:'#e8b04a',fr:'corner',ace:'rings',cb:['#1b3a7a','#0b1a3d']},
 {n:'سبز سنتی',bg:'#f1ecd8',ink:'#0e4a36',red:'#b3202f',acc:'#2f6b52',fr:'thin',ace:'laurel',cb:['#d6e4cf','#4b8a6b']},
 {n:'فیروزه‌ای',bg:'#e6faf7',ink:'#0b4f57',red:'#d6455d',acc:'#1aa5a5',fr:'dbl',ace:'rings',cb:['#bdeee7','#2a9d98']},
 {n:'یاقوتی',bg:'#fff0f3',ink:'#5b0a2a',red:'#c0283d',acc:'#c9a24a',fr:'corner',ace:'baroque',cb:['#ffd9e0','#a3243f']},
 {n:'مدرن سفید',bg:'#ffffff',ink:'#101828',red:'#e11d48',acc:'#667085',fr:'none',ace:'plain',cb:['#eef2f6','#98a2b3']},
 {n:'سلطنتی بنفش',bg:'#f6f0ff',ink:'#2b1055',red:'#c2185b',acc:'#7c4dff',fr:'dbl',ace:'wings',cb:['#e3d5ff','#6a3fc9']},
 {n:'فولادی',bg:'#e8ecef',ink:'#20262d',red:'#c1272d',acc:'#6b7785',fr:'corner',ace:'wings',cb:['#cfd6dd','#59636f']}];
const SP={S:'M10 0C10 0 1 7 1 12.5C1 15.5 3.6 17 5.8 17C7.6 17 8.8 16.2 9.3 15.2C9 17.5 8.3 19 6.5 20L13.5 20C11.7 19 11 17.5 10.7 15.2C11.2 16.2 12.4 17 14.2 17C16.4 17 19 15.5 19 12.5C19 7 10 0 10 0Z',
 H:'M10 19L2.2 10.6C-1.5 6.6 1.2 1 5.8 1C8 1 9.4 2.2 10 3.6C10.6 2.2 12 1 14.2 1C18.8 1 21.5 6.6 17.8 10.6Z',
 D:'M10 0L19 10L10 20L1 10Z',
 C:'M10 1a4.6 4.6 0 1 1 0 9.2a4.6 4.6 0 1 1 0-9.2ZM4.6 8.4a4.6 4.6 0 1 1 0 9.2a4.6 4.6 0 1 1 0-9.2ZM15.4 8.4a4.6 4.6 0 1 1 0 9.2a4.6 4.6 0 1 1 0-9.2ZM8.6 12L7.4 20H12.6L11.4 12Z'};
const PX={2:[[50,30],[50,110,1]],3:[[50,30],[50,70],[50,110,1]],4:[[34,30],[66,30],[34,110,1],[66,110,1]],5:[[34,30],[66,30],[50,70],[34,110,1],[66,110,1]],6:[[34,30],[66,30],[34,70],[66,70],[34,110,1],[66,110,1]],7:[[34,30],[66,30],[50,50],[34,70],[66,70],[34,110,1],[66,110,1]],8:[[34,30],[66,30],[50,50],[34,70],[66,70],[50,90,1],[34,110,1],[66,110,1]],9:[[34,30],[66,30],[34,57],[66,57],[50,70],[34,83,1],[66,83,1],[34,110,1],[66,110,1]],10:[[34,30],[66,30],[50,43],[34,57],[66,57],[34,83,1],[66,83,1],[50,97,1],[34,110,1],[66,110,1]]};
const SC={};
function cardSVG(r,s,ti,sv,av){const sub=hasSub();ti=ti??(sub?ft:0);sv=sv??(sub?ssI:0);av=av??(sub?arI:0);
 const key=r+s+ti+sv+av;if(SC[key])return SC[key];
 const th=FT[ti],red=s==='H'||s==='D',col=sv===1?{S:th.ink,H:th.red,D:'#1f5fd0',C:'#17803a'}[s]:red?th.red:th.ink,a=th.acc;
 const fl=c=>sv===2?`fill="none" stroke="${c}" stroke-width="1.6"`:`fill="${c}"`;
 const sp=(x,y,z,rot)=>`<path d="${SP[s]}" transform="translate(${x} ${y}) rotate(${rot||0}) scale(${z/20}) translate(-10 -10)" ${fl(col)}/>`;
 const ace=()=>{let e='';const L=th.ace;
  if(L==='laurel'){for(let i=0;i<7;i++){const an=(104+i*25)*Math.PI/180,x=50+37*Math.cos(an),y=70+37*Math.sin(an),d=an*57.3,x2=100-x;e+=`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="2.6" ry="6" transform="rotate(${d.toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})" fill="${a}"/><ellipse cx="${x2.toFixed(1)}" cy="${y.toFixed(1)}" rx="2.6" ry="6" transform="rotate(${(-d).toFixed(0)} ${x2.toFixed(1)} ${y.toFixed(1)})" fill="${a}"/>`}e+=`<path d="M32 113Q50 121 68 113L68 119Q50 127 32 119Z" fill="${a}"/>`}
  else if(L==='baroque'){const sc=`<path d="M50 24C38 24 28 34 33 44C37 51 46 48 44 41C43 38 39 38 38 41M50 24C62 24 72 34 67 44C63 51 54 48 56 41C57 38 61 38 62 41" fill="none" stroke="${a}" stroke-width="1.6" stroke-linecap="round"/>`;e=sc+`<g transform="rotate(180 50 70)">${sc}</g><circle cx="50" cy="21" r="2" fill="${a}"/><circle cx="50" cy="119" r="2" fill="${a}"/>`}
  else if(L==='rings'){e=`<circle cx="50" cy="70" r="37" fill="none" stroke="${a}" stroke-width="1"/><circle cx="50" cy="70" r="33" fill="none" stroke="${a}" stroke-width=".5" stroke-dasharray="1.2 2.2"/>`;let pt='';for(let i=0;i<16;i++){const an=i*Math.PI/8,rr=i%2?25:34;pt+=(50+rr*Math.cos(an)).toFixed(1)+','+(70+rr*Math.sin(an)).toFixed(1)+' '}e+=`<polygon points="${pt}" fill="${a}" fill-opacity=".18" stroke="${a}" stroke-width=".6"/>`}
  else if(L==='wings'){const w=`<path d="M40 70C26 56 12 58 7 66C15 65 20 68 22 72C14 73 12 79 14 83C22 79 28 81 32 85C34 79 37 75 40 70Z" fill="${a}"/>`;e=w+`<g transform="translate(100 0) scale(-1 1)">${w}</g>`}
  return e+sp(50,70,L==='plain'?46:34)};
 const court=()=>{const c1=th.cb[0],c2=th.cb[1],sk='#e6b78e',hr='#3a281c',gd='#f4d27a';
  let e=`<rect x="17" y="22" width="66" height="96" rx="3" fill="${c1}" stroke="${a}" stroke-width="1"/><path d="M17 118V72Q50 56 83 72V118Z" fill="${c2}" opacity=".5"/><g opacity=".13">${sp(50,92,58)}</g>`;
  if(r==='J')e+=`<path d="M78 120V32" stroke="${a}" stroke-width="1.6"/><path d="M78 24L81.5 34H74.5Z" fill="${a}"/>`;
  if(r==='K')e+=`<path d="M22 120V44" stroke="${a}" stroke-width="2"/><path d="M17 76H27" stroke="${a}" stroke-width="2.4"/><circle cx="22" cy="42" r="2.2" fill="${a}"/>`;
  e+=`<path d="M19 118L25 84Q50 70 75 84L81 118Z" fill="${col}"/><path d="M29 118L31 92Q50 82 69 92L71 118Z" fill="${a}"/><path d="M50 90V118M36 102Q50 109 64 102" stroke="${col}" stroke-width="1.2" fill="none"/><ellipse cx="29" cy="90" rx="8" ry="6" fill="${a}" stroke="${col}"/><ellipse cx="71" cy="90" rx="8" ry="6" fill="${a}" stroke="${col}"/><rect x="45" y="76" width="10" height="11" fill="${sk}"/>`;
  if(r==='Q')e+=`<circle cx="72" cy="106" r="5" fill="${col}"/><circle cx="72" cy="106" r="2" fill="${gd}"/><path d="M35 58Q30 86 40 102L44 78L38 58ZM65 58Q70 86 60 102L56 78L62 58Z" fill="${hr}"/>`;
  e+=`<ellipse cx="50" cy="63" rx="12" ry="15" fill="${sk}"/>`+(r==='K'||(r==='J'&&av===0)?`<path d="M39 66Q50 94 61 66Q58 78 50 80Q42 78 39 66Z" fill="${hr}"/>`:'')+`<path d="M43 61h5M52 61h5" stroke="#2a1a10" stroke-width="1.7" stroke-linecap="round"/><path d="M50 62v6" stroke="#b9855c" stroke-width="1.1"/><path d="M46 72q4 2.4 8 0" stroke="#7a3b2a" stroke-width="1.2" fill="none" stroke-linecap="round"/>`;
  const H0=`<path d="M36 64Q34 38 50 36Q66 38 64 64L60 64Q60 52 50 51Q40 52 40 64Z" fill="${a}" stroke="${col}" stroke-width=".8"/><rect x="48.6" y="50" width="2.8" height="16" fill="${a}"/>`;
  const G=[{J:H0+`<path d="M36 44Q50 6 64 44Q50 28 36 44Z" fill="${col}"/>`,Q:H0+`<path d="M36 44Q50 14 64 44Q50 30 36 44Z" fill="${col}"/><path d="M35 48C21 40 16 51 18 58C25 52 30 54 36 56ZM65 48C79 40 84 51 82 58C75 52 70 54 64 56Z" fill="${gd}" stroke="${col}" stroke-width=".6"/>`,K:H0+`<path d="M36 44Q50 8 64 44Q50 28 36 44Z" fill="${col}"/><path d="M37 47L39 39L44 45L50 35L56 45L61 39L63 47Z" fill="${gd}" stroke="${col}" stroke-width=".7"/>`},
  {J:`<path d="M37 56Q33 72 39 77L41 60ZM63 56Q67 72 61 77L59 60Z" fill="${hr}"/><path d="M35 58Q36 39 52 40Q67 42 65 56Q56 47 35 58Z" fill="${col}"/><path d="M60 43Q79 28 83 12Q71 22 58 38Z" fill="${gd}" stroke="${a}" stroke-width=".6"/>`,Q:`<path d="M37 60Q38 43 50 43Q62 43 63 60Q50 50 37 60Z" fill="${hr}"/><path d="M40 47L42 38L46 43L50 34L54 43L58 38L60 47Z" fill="${gd}" stroke="${col}" stroke-width=".7"/>`,K:`<path d="M37 49L38 30L44 38L50 25L56 38L62 30L63 49Z" fill="${gd}" stroke="${col}" stroke-width=".9"/><circle cx="50" cy="33" r="1.8" fill="${col}"/><path d="M37 46H63" stroke="${col}" stroke-width=".8"/>`},
  {J:`<ellipse cx="50" cy="45" rx="15" ry="10" fill="${col}"/><path d="M36 46Q50 37 64 46M38 41Q50 33 62 41" stroke="${a}" stroke-width="1.2" fill="none"/><path d="M50 36Q57 20 63 12" stroke="${gd}" stroke-width="1.6" fill="none"/><circle cx="50" cy="40" r="2.2" fill="${gd}"/>`,Q:`<path d="M35 58Q31 90 42 108L46 78L38 58ZM65 58Q69 90 58 108L54 78L62 58Z" fill="${col}" opacity=".9"/><path d="M37 60Q38 43 50 43Q62 43 63 60Q50 51 37 60Z" fill="${hr}"/><path d="M38 48L40 33L45 41L50 29L55 41L60 33L62 48Z" fill="${gd}" stroke="${col}" stroke-width=".7"/><circle cx="50" cy="38" r="1.6" fill="${col}"/>`,K:`<path d="M36 50Q35 20 50 16Q65 20 64 50Z" fill="${a}" stroke="${col}" stroke-width=".9"/><path d="M36 47H64" stroke="${gd}" stroke-width="2"/><circle cx="43" cy="44" r="1.3" fill="#fff"/><circle cx="50" cy="44" r="1.3" fill="#fff"/><circle cx="57" cy="44" r="1.3" fill="#fff"/><path d="M50 16V8" stroke="${gd}" stroke-width="1.6"/>`}][av][r];
  return e+G};
 let o=`<svg viewBox="0 0 100 140" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="1" width="98" height="138" rx="8" fill="${th.bg}" stroke="${a}" stroke-opacity=".55" stroke-width="1.2"/>`;
 o+={thin:`<rect x="4.5" y="4.5" width="91" height="131" rx="5" fill="none" stroke="${a}" stroke-width=".6" stroke-opacity=".7"/>`,dbl:`<rect x="4" y="4" width="92" height="132" rx="5" fill="none" stroke="${a}" stroke-width=".8"/><rect x="6.5" y="6.5" width="87" height="127" rx="3" fill="none" stroke="${a}" stroke-width=".4"/>`,corner:`<path d="M6 18V6H18M82 6H94V18M94 122V134H82M18 134H6V122" fill="none" stroke="${a}" stroke-width="1.2"/>`,none:''}[th.fr];
 o+=r==='A'?ace():'JQK'.includes(r)?court():PX[r].map(p=>sp(p[0],p[1],17,p[2]?180:0)).join('');
 const idx=`<text x="11" y="21" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="${r==='10'?15:18}" fill="${col}">${r}</text>${sp(11,31,9)}`;
 return SC[key]=o+idx+`<g transform="rotate(180 50 70)">${idx}</g></svg>`}

let ft=+store.get('hkFT',0),ssI=Math.min(2,+store.get('hkSS',0)),arI=+store.get('hkAR',0);
const su=id=>SU.find(s=>s.id===id),nm=p=>p===0?T('تو'):(p===2?botNames[1]:botNames[p===1?0:2]);
const sym=id=>GL[id];
const later=(f,ms)=>{const r=rid;setTimeout(()=>{if(r===rid)f()},ms)};
function applyFace(){}
function cardEl(c,back){const d=document.createElement('div');if(back){d.className='card back';return d}
 d.className='card sv';d.dataset.s=c.s;d.innerHTML=cardSVG(c.r,c.s);return d}
function sortHand(h){h.sort((a,b)=>SU.findIndex(s=>s.id===a.s)-SU.findIndex(s=>s.id===b.s)||RV[b.r]-RV[a.r])}
function say(t){$('msg').textContent=t}

function stopTimer(){if(timerId){clearInterval(timerId);timerId=null}const tb=$('timerBar');if(tb)tb.style.display='none'}
function startTimer(){stopTimer();if(!live||choosing||paused)return;timerLeft=TURN_SEC;saveBotSnapshot();const tb=$('timerBar'),tf=$('timerFill'),tt=$('timerTxt');
 if(tb){tb.style.display='flex';tf.style.width='100%';tt.textContent=fa(timerLeft)}
 timerId=setInterval(()=>{if(paused)return;timerLeft--;if(tt)tt.textContent=fa(Math.max(0,timerLeft));if(tf)tf.style.width=(timerLeft/TURN_SEC*100)+'%';
  if(timerLeft<=0){stopTimer();timeouts[turn]=(timeouts[turn]||0)+1;if(timeouts[turn]>=3){live=false;paused=false;pts[1]=7;draw();say('به دلیل سه نوبت بی‌پاسخ، بازی به سود حریف تمام شد.');try{sessionStorage.removeItem('kartinoBotSnapshot')}catch(e){}return}if(turn===0&&live&&!choosing&&!lock){const L=H[0].filter(c=>legal(0,c));if(L.length){autoPlayTurn=true;play(0,L[0])}}else if(turn!==0)bot()}},1000)}
function togglePause(){if(!live)return;paused=!paused;updatePauseBtn();
 if(paused){say(T('بازی متوقف شد'));stopTimer()}
 else{say(T('ادامه بازی…'));if(turn===0)startTimer();else later(next,gameDelay(400))}}
function updatePauseBtn(){const b=$('pauseBtn');if(!b)return;b.textContent=paused?'▶ ادامه':'⏸ توقف';b.style.display=live?'inline-flex':'none'}

function startMatch(){pts=[0,0];rno=0;paused=false;timeouts=[0,0,0,0];window.kartinoMatchStartedAt=Date.now();pickBotNames();
 // تعیین حاکم با یک کارت به هر نفر
 const deck=[];SU.forEach(s=>RK.forEach(r=>deck.push({s:s.id,r})));
 for(let i=deck.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[deck[i],deck[j]]=[deck[j],deck[i]]}
 const cuts=deck.slice(0,4);let best=0;
 for(let i=1;i<4;i++)if(RV[cuts[i].r]>RV[cuts[best].r]||(RV[cuts[i].r]===RV[cuts[best].r]&&SU.findIndex(s=>s.id===cuts[i].s)>SU.findIndex(s=>s.id===cuts[best].s)))best=i;
 hakem=best;
 $('newBtn').textContent=T('بازی جدید');
 if($('pauseBtn'))$('pauseBtn').style.display='inline-flex';
 say(T('تعیین حاکم…')+' '+nm(hakem)+' '+T('حاکم شد'));
 later(startRound,1200)}
function startRound(){rid++;rno++;seen=[];stopTimer();paused=false;updatePauseBtn();
 titleCard(T('دور')+' '+fa(rno),T('حاکم')+': '+nm(hakem));Aud.sfx('deal');const d=[];SU.forEach(s=>RK.forEach(r=>d.push({s:s.id,r})));
 for(let i=d.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[d[i],d[j]]=[d[j],d[i]]}
 H=[[],[],[],[]];d.forEach((c,i)=>H[i%4].push(c));
 trump=null;tricks=[0,0];won=[0,0,0,0];plays=[];turn=hakem;live=true;lock=false;choosing=true;$('tr').textContent='—';
 if(hakem===0){$('pickRow').innerHTML=SU.map(s=>'<button class="'+(s.r?'r':'')+'" data-s="'+s.id+'" aria-label="'+s.n+'">'+sym(s.id)+'</button>').join('');
  $('pickRow').querySelectorAll('button').forEach(b=>b.onclick=()=>setTrump(b.dataset.s));$('pick').classList.add('on');say(T('با ۵ کارت اول، خال حکم را انتخاب کن.'))}
 else{say(nm(hakem)+' '+T('حاکم است و حکم را انتخاب می‌کند…'));later(()=>setTrump(botTrump(hakem)),gameDelay(1600))}
 draw()}
function botTrump(p){const sc={S:0,H:0,D:0,C:0};H[p].slice(0,5).forEach(c=>sc[c.s]+=10+RV[c.r]);return Object.keys(sc).sort((a,b)=>sc[b]-sc[a])[0]}
function setTrump(id){if(!choosing)return;trump=id;Aud.sfx('hit');shake();choosing=false;$('pick').classList.remove('on');$('tr').textContent=sym(id);say(T('خال حکم')+': '+T(su(id).n));draw();later(next,700)}
function legal(p,c){if(!plays.length)return true;const l=plays[0].c.s;return c.s===l||!H[p].some(x=>x.s===l)}
function draw(){const hand=$('hand');hand.innerHTML='';hand.classList.toggle('choosing',!!choosing);const src=choosing?H[0].slice(0,5):H[0].slice();sortHand(src);
 src.forEach(c=>{const el=cardEl(c);el.tabIndex=0;
  if(live&&!choosing&&turn===0&&!lock){if(legal(0,c)){el.classList.add('ok');el.onclick=()=>play(0,c);el.onkeydown=e=>{if(e.key==='Enter'||e.key===' ')play(0,c)}}else el.classList.add('no')}
  hand.appendChild(el)});
 for(let p=0;p<4;p++){if(p){const f=$('fan'+p);f.innerHTML='';for(let i=0;i<(choosing?5:H[p].length);i++)f.appendChild(cardEl(null,true))}
  const pl=plays.find(x=>x.p===p),sl=$('sl'+p);sl.innerHTML='';if(pl)sl.appendChild(cardEl(pl.c));
  $('seat'+p).classList.toggle('turn',live&&!choosing&&turn===p);$('nm'+p).textContent=nm(p)+(hakem===p&&H[0].length?' 👑':'');
  const w=$('won'+p);w.innerHTML=won[p]?'<small>'+fa(won[p])+'×</small>':'';for(let i=0;i<Math.min(won[p],7);i++)w.appendChild(cardEl(null,true))}
 $('sA').textContent=fa(tricks[0]);$('sB').textContent=fa(tricks[1]);$('rA').textContent=fa(pts[0])+' - '+fa(pts[1]);if(gameMode==='bot'&&live)saveBotSnapshot()}

function beats(a,b,l){if(a.s===b.s)return RV[a.r]>RV[b.r];if(a.s===trump)return true;if(b.s===trump)return false;return a.s===l}
function winner(){const l=plays[0].c.s;return plays.reduce((b,x)=>beats(x.c,b.c,l)?x:b,plays[0])}
function play(p,c){if(!live||choosing||lock||paused||p!==turn||!legal(p,c))return;if(!autoPlayTurn)timeouts[p]=0;autoPlayTurn=false;stopTimer();H[p].splice(H[p].indexOf(c),1);plays.push({p,c});seen.push(c);Aud.sfx('card');
 if(plays.length<4){turn=(p+1)%4;draw();next()}else{lock=true;draw();later(endTrick,gameDelay(950))}}
function next(){if(!live||choosing||paused)return;if(turn===0){say(T('نوبت توست.'));draw();startTimer();return}stopTimer();say(T('نوبت')+' '+nm(turn)+'…');later(bot,gameDelay(650))}
function bot(){if(!live||lock||choosing||turn===0||paused)return;const p=turn,L=H[p].filter(c=>legal(p,c)).sort((a,b)=>RV[a.r]-RV[b.r]),df=ST.df,w=plays.length?winner():null,l=plays.length?plays[0].c.s:null;let c;
 // آسان: ۷۵–۹۵٪ اشتباه / انتخاب تصادفی
 if(df===0){const err=.15+Math.random()*.1; // 15-25% play well
  if(Math.random()>err)c=L[Math.random()*L.length|0];
  else if(!plays.length){const hi=L.filter(x=>x.s!==trump&&RV[x.r]>=12);c=hi.length?hi[hi.length-1]:L[L.length-1]}
  else{const win=L.filter(x=>beats(x,w.c,l));c=win.length?win[0]:L[0]}}
 // متوسط: ۳۵–۷۵٪
 else if(df===1){const smart=.35+Math.random()*.4;
  if(Math.random()>smart)c=L[Math.random()*L.length|0];
  else if(!plays.length){const hi=L.filter(x=>x.s!==trump&&RV[x.r]>=13);c=hi.length?hi[hi.length-1]:L[Math.random()*L.length|0]}
  else if((w.p+2)%4===p)c=L[0];else{const win=L.filter(x=>beats(x,w.c,l));c=win.length?win[0]:L[0]}}
 // سخت: زیر ۳۵٪ شانس برد بازیکن — تقریباً همیشه بهترین حرکت
 else c=hardPick(p,L,w,l);
 play(p,c)}
function hardPick(p,L,w,l){
 // فوق‌سخت: همیشه بهترین حرکت تاکتیکی
 const up=x=>RK.some(r=>RV[r]>RV[x.r]&&![...seen,...H[p]].some(z=>z.s===x.s&&z.r===r));
 const partner=(p+2)%4, opp1=(p+1)%4, opp2=(p+3)%4;
 const nt=L.filter(x=>x.s!==trump), isTr=x=>x.s===trump;
 const lowest=arr=>arr.slice().sort((a,b)=>RV[a.r]-RV[b.r])[0];
 const highest=arr=>arr.slice().sort((a,b)=>RV[b.r]-RV[a.r])[0];
 if(!plays.length){
  // لید: اول آس/شاه غیرحکم مطمئن، بعد حکم بالا، بعد کم‌ارزش
  const sure=L.filter(x=>!isTr(x)&&!up(x)&&RV[x.r]>=13);
  if(sure.length)return highest(sure);
  const mid=L.filter(x=>!isTr(x)&&!up(x));
  if(mid.length)return highest(mid);
  const highTr=L.filter(isTr);
  if(highTr.length&&Math.random()<.55)return highest(highTr);
  return nt.length?lowest(nt):lowest(L);
 }
 // دنبال‌کننده
 const canWin=L.filter(x=>beats(x,w.c,l));
 const amPartner=w.p===partner;
 if(amPartner){
  // یار برنده است → دور بینداز مگر لازم باشد
  if(!up(w.c)||RV[w.c.r]>=13)return lowest(nt.length?nt:L);
  // یار ضعیف است → سعی کن ببری
  if(canWin.length)return lowest(canWin);
  return lowest(nt.length?nt:L);
 }
 // حریف برنده است → حتماً سعی کن ببری با کم‌ترین کارت برنده‌کننده
 if(canWin.length){
  const cheap=canWin.filter(x=>!isTr(x)||!nt.length);
  return lowest(cheap.length?cheap:canWin);
 }
 // نمی‌توانی ببری → کم‌ارزش‌ترین غیرحکم یا حکم
 return lowest(nt.length?nt:L);
}
function endTrick(){const w=winner(),t=w.p%2;tricks[t]++;won[w.p]++;plays=[];turn=w.p;lock=false;
 if(tricks[t]>=7)return endRound(t);
 fxHandWin(w.p);draw();say(nm(w.p)+' '+T('این دست را برد.'));later(next,gameDelay(1100))}
function endRound(t){live=false;stopTimer();const ht=hakem%2;let pt=1;let lastHand=false;
 // کت عادی / حاکم‌کت
 if(t===ht){if(tricks[1-t]===0)pt=2} // کت عادی
 else{if(tricks[ht]===0)pt=3;hakem=(hakem+1)%4} // حاکم‌کت
 // کت دست آخر: اگر امتیاز قبل از این دور نزدیک ۷ بود
 const before=pts[t];
 // اعمال امتیاز
 if(before+pt>=7 && pt>=2){
   // کت دست آخر / حاکم‌کت دست آخر
   if(t===ht && tricks[1-t]===0){ // کت دست آخر برای تیم حاکم
     pts[t]=1; lastHand=true;
     fxKat();say(T('کت دست آخر!')+' '+T('امتیاز تیم تو روی ۱ قرار گرفت.'));
   } else if(t!==ht && tricks[ht]===0){ // حاکم‌کت در دست آخر
     pts[ht]=2; // امتیاز تیم حاکم روی ۲
     // تیم برنده (t) امتیاز اضافه نمی‌گیرد طبق قانون
     lastHand=true;
     fxKat();say(T('حاکم‌کت دست آخر!')+' '+T('امتیاز حاکم روی ۲ قرار گرفت.'));
   } else {
     pts[t]+=pt;
   }
 } else {
   pts[t]+=pt;
 }
 store.set('hkP',+store.get('hkP',0)+1);if(t===0)store.set('hkW',+store.get('hkW',0)+1);draw();
 if(pts[0]>=7||pts[1]>=7){
   const win=pts[0]>=7?0:1;
   fxSetWin(win);
   say(win===0?T('🏆 تیم تو برنده کل بازی شد!'):T('تیم حریف برنده کل بازی شد.'));
   if(win===0)fxWin();else Aud.sfx('hit');
   if(serverUser)api('/stats/game',{method:'POST',body:JSON.stringify({mode:gameMode,won:win===0,startedAt:window.kartinoMatchStartedAt||Date.now()})}).catch(()=>{});if(gameMode==='bot')store.set('hkGames',+store.get('hkGames',0)+1);
   try{sessionStorage.removeItem('kartinoBotSnapshot')}catch(e){}
   if($('pauseBtn'))$('pauseBtn').style.display='none';
   return}
 if(!lastHand){
   say((t===0?T('تیم تو دور را برد! 🎉'):T('تیم حریف دور را برد.'))+(pt>1?' (+'+fa(pt)+')':''));
 }
 fxSetWin(t);
 if(!hasSub()&&+store.get('hkGames',0)>=30){toast('۳۰ بازی رایگان تمام شد؛ اشتراک بگیر');return}
 later(startRound,gameDelay(3800))}
function burst(theme){if(!fxOn('burst'))return;const f=$('felt');if(!f)return;
 const pal={gold:['#e8b04a','#fff4cf','#c9801a','#f6efdc'],red:['#c0283d','#ff6b9d','#ffb3c1','#fff'],teal:['#2aa6a0','#7ee8e0','#e8b04a','#f6efdc']};
 const cols=pal[theme]||pal.gold;
 for(let i=0;i<70;i++){const s=document.createElement('span');s.className='cf';s.style.left=Math.random()*100+'%';s.style.background=cols[i%cols.length];s.style.animationDelay=Math.random()*.6+'s';f.appendChild(s);setTimeout(()=>s.remove(),3600)}
 if(theme==='gold')confettiStorm()}
function renderFaces(){const s=hasSub(),L=i=>(!s&&i?' lock':''),cur=[s?ft:0,s?ssI:0,s?arI:0];
 const bt=(i,sel,fn,svg,n)=>'<button class="fcb'+L(i)+(i===sel?' sel':'')+'" onclick="'+fn+'('+i+')"><div class="cm">'+svg+'</div>'+n+'</button>';
 $('faces').innerHTML=FT.map((f,i)=>bt(i,cur[0],'pickF',cardSVG('K','H',i,cur[1],cur[2]),f.n)).join('');
 $('suits').innerHTML=SSN.map((n,i)=>bt(i,cur[1],'pickS',cardSVG('A','S',cur[0],i,cur[2]),n)).join('');
 $('arts').innerHTML=ARN.map((n,i)=>bt(i,cur[2],'pickA',cardSVG('Q','S',cur[0],cur[1],i),n)).join('');
 const pc=$('pvCards');pc.innerHTML='';[['S','A'],['H','K'],['D','Q'],['C','J'],['S','10']].forEach(x=>pc.appendChild(cardEl({s:x[0],r:x[1]})))}
function pickF(i){if(i&&!hasSub())return lockMsg();ft=i;store.set('hkFT',i);renderFaces()}
function pickS(i){if(i&&!hasSub())return lockMsg();ssI=i;store.set('hkSS',i);renderFaces()}
function pickA(i){if(i&&!hasSub())return lockMsg();arI=i;store.set('hkAR',i);renderFaces()}
if($('newBtn'))$('newBtn').onclick=()=>startFreshBotGame();
restoreServerSession().finally(()=>{renderHdr();if($('hand'))draw();route();});

if(LANG==='en'){const DL=Object.keys(E).filter(k=>k.includes(' ')||k.length>=8).sort((a,b)=>b.length-a.length);
 const tr=r=>{const w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){if(/^(SCRIPT|STYLE)$/.test(n.parentNode.nodeName))continue;const v=n.nodeValue,k=v.trim();if(!k)continue;if(E[k]){n.nodeValue=v.replace(k,E[k]);continue}let o=v;for(const a of DL)if(o.includes(a))o=o.split(a).join(E[a]);if(o!==v)n.nodeValue=o}
  r.querySelectorAll('[placeholder],[aria-label]').forEach(e=>['placeholder','aria-label'].forEach(a=>{const v=e.getAttribute(a);if(v&&E[v])e.setAttribute(a,E[v])}))};
 const cfg={childList:true,subtree:true,characterData:true},mo=new MutationObserver(()=>{mo.disconnect();tr(document.body);mo.observe(document.body,cfg)});tr(document.body);mo.observe(document.body,cfg)}
document.querySelectorAll('.lng button,.seg button[data-l]').forEach(b=>b.classList.toggle('on',b.dataset.l===LANG));
addEventListener('hashchange',route);applyBri();document.querySelectorAll('.mt').forEach(b=>b.textContent=Aud.muted()?'🔇':'🔊');

