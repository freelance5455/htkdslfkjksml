'use strict';

const App = (() => {
  const screens = { hub: 'screen-hub', ttt: 'screen-ttt', db: 'screen-db', mem: 'screen-mem' };
  let current = 'hub';

  function go(name) {
    if (!screens[name]) return;
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(screens[name]).classList.add('active');
    current = name;
    if (name === 'ttt') TTT.ensureStarted();
    if (name === 'db')  DB.ensureStarted();
    if (name === 'mem') MEM.ensureStarted();
    if (name === 'hub') refreshHubStats();
    window.scrollTo(0, 0);
  }

  function refreshHubStats() {
    const t = document.getElementById('hub-ttt-stat');
    const d = document.getElementById('hub-db-stat');
    const m = document.getElementById('hub-mem-stat');
    if (t) t.textContent = TTT.statText();
    if (d) d.textContent = DB.statText();
    if (m) m.textContent = MEM.statText();
  }

  function showModal(emoji, title, msg, againCb) {
    document.getElementById('modal-emoji').textContent = emoji;
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-msg').textContent = msg || '';
    const btn = document.getElementById('modal-again');
    btn.onclick = () => { closeModal(); if (againCb) againCb(); };
    const m = document.getElementById('modal');
    m.classList.remove('hidden'); m.classList.add('flex');
  }
  function closeModal() {
    const m = document.getElementById('modal');
    m.classList.add('hidden'); m.classList.remove('flex');
  }

  // prevent double-tap zoom on older WebViews
  document.addEventListener('dblclick', e => e.preventDefault(), { passive: false });

  return { go, showModal, closeModal, refreshHubStats, get current() { return current; } };
})();