/* یادآوری: بنر و پیگیری‌ها، کار امروز، ساعت خلاصه، و اعلان سیستم (فقط با اجازه‌ی کاربر). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var st = App.study;
  var S = function () { return App.S; };
  var R = (App.remind = { last: '' });
  var SS_KEY = 'study_rm';
  var DEF = { on: 1, at: '20:00' };

  function cfg() { return S().remind || DEF; }
  function daily(iso) { return (S().daily || {})[iso || u.todayISO()] || []; }
  function dailyOpen() { return daily().filter(function (x) { return !x.done; }); }
  // وضعیت نشست امروز: بنر بسته‌شده و موارد گذشته
  function ss() {
    var o = null;
    try { o = JSON.parse(sessionStorage.getItem(SS_KEY) || 'null'); } catch (e) { o = null; }
    return o && o.d === u.todayISO() ? o : { d: u.todayISO(), dis: '', seen: [] };
  }
  function saveSS(o) { try { sessionStorage.setItem(SS_KEY, JSON.stringify(o)); } catch (e) { /* حافظه‌ی نشست در دسترس نیست */ } }

  // پیگیری‌های تا امروز؛ انجام‌شده‌های امروز هم تا پایان روز می‌مانند
  R.fuList = function () {
    var t = u.todayISO();
    return S().todos.filter(function (x) { return x.due && x.due <= t && (!x.o || x.due === t); }).sort(function (a, b) {
      var p = a.due + ' ' + (a.at || ''), q = b.due + ' ' + (b.at || '');
      return p < q ? -1 : p > q ? 1 : 0;
    });
  };
  R.pending = function () { return R.fuList().filter(function (x) { return !x.o; }); };

  // بنر: پیگیری‌های باز، یا کارهای باز پس از ساعت خلاصه
  R.state = function () {
    var c = cfg(), f = R.pending(), dp = dailyOpen(), msg = '', key = '';
    if (f.length) { msg = '⏰ ' + u.fa(f.length) + ' پیگیری برای امروز داری'; key = 'f' + f.length; }
    else if (dp.length && u.minutesNow() >= u.tmin(c.at)) { msg = '📋 ' + u.fa(dp.length) + ' کار امروز باز مانده؛ قبل از خواب مرورش کن'; key = 's' + dp.length; }
    return { show: !!c.on && !!msg && ss().dis !== key, msg: msg, key: key };
  };
  R.banner = function () {
    var s = R.state();
    if (!s.show) return '';
    return '<div class="card notice rm-banner" role="status"><b>' + u.esc(s.msg) + '</b><div class="q-row">' +
      App.sm('📌 نمایش برنامه‌ی امروز', 'rm-open') + App.sm('✕ بستن', 'rm-dismiss') + '</div></div>';
  };
  App.act['rm-dismiss'] = function () { var o = ss(); o.dis = R.state().key; saveSS(o); App.render(); };
  App.act['rm-open'] = function () {
    App.go('today');
    var el = document.getElementById('daily-card');
    if (el) { el.open = true; el.scrollIntoView({ block: 'start' }); }
  };

  // هر ۶۰ ثانیه: موارد رسیده و ساعت خلاصه؛ در شروع، موارد گذشته بی‌صدا علامت می‌خورند.
  R.tick = function (boot) {
    var c = cfg(), o = ss(), fired = [], now = u.minutesNow();
    R.pending().forEach(function (x) {
      if (x.at && u.tmin(x.at) <= now && o.seen.indexOf(x.id) < 0) { o.seen.push(x.id); o.dis = ''; fired.push(x); }
    });
    if (now >= u.tmin(c.at) && dailyOpen().length && o.seen.indexOf('sum') < 0) { o.seen.push('sum'); o.dis = ''; fired.push('sum'); }
    saveSS(o);
    var quiet = boot || !c.on;
    if (!quiet && fired.length) {
      var msg = fired.length > 1 ? '⏰ ' + u.fa(fired.length) + ' مورد رسید' : fired[0] === 'sum' ? '📋 کارهای امروز هنوز باز است' : '⏰ ' + fired[0].t + ' · ' + u.pd(fired[0].at);
      fired.forEach(function (x) {
        if (x === 'sum') R.notify('📋 کارهای امروز', 'هنوز کارهای باز داری.');
        else R.notify('⏰ پیگیری', x.t + (x.at ? ' · ' + u.pd(x.at) : ''));
      });
      App.toast(msg, { action: { label: 'نمایش', fn: App.act['rm-open'] }, ms: 8000 });
    }
    var s = R.state(), cur = s.show ? s.msg : '', changed = cur !== R.last;
    R.last = cur;
    if (!quiet && App.ui.tab === 'today' && (fired.length || changed)) App.render();
  };
  R.boot = function () {
    R.tick(true);
    setInterval(function () { R.tick(false); }, 60000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) R.tick(false); });
  };

  // اعلان سیستم فقط با اجازه؛ در WebView بی‌صدا رد می‌شود
  R.notify = function (title, body) {
    var N = window.Notification;
    if (!N || N.permission !== 'granted') return;
    try { new N(title, { body: body, lang: 'fa', icon: 'icon-192.png' }); } catch (e) { /* سازنده در این محیط در دسترس نیست */ }
  };
  // درخواست اجازه فقط با کلیک کاربر
  App.act['rm-notif'] = function () {
    var N = window.Notification;
    if (!N) return;
    try {
      Promise.resolve(N.requestPermission()).then(function (p) { App.render(); if (p === 'granted') App.toast('اعلان‌ها فعال شد ✅'); }, function () { App.render(); });
    } catch (e) { App.render(); }
  };

  // ---- کارت «برنامه‌ی امروز» ----
  R.dailyCard = function () {
    var t = u.todayISO(), f = App.form('dly', { txt: '' }), rows = '';
    R.fuList().forEach(function (x) {
      var late = u.dayDiff(x.due, t);
      rows += '<div class="li"><label class="check' + (x.o ? ' done' : '') + '"><input type="checkbox" data-act="todo-toggle" data-key="' + x.id + '"' + (x.o ? ' checked' : '') + '><span>' + u.esc(x.t) + (x.at ? ' <span class="mu">· ' + u.pd(x.at) + '</span>' : '') + '</span></label>' +
        (late > 0 && !x.o ? '<span class="late">⚠️ ' + u.fa(late) + ' روز تأخیر</span>' : '') + App.sm('✕', 'todo-del', { key: x.id }, 'muted') + '</div>';
    });
    daily().forEach(function (x) {
      rows += '<div class="li"><label class="check' + (x.done ? ' done' : '') + '"><input type="checkbox" data-act="daily-toggle" data-key="' + x.id + '"' + (x.done ? ' checked' : '') + '><span>' + u.esc(x.text) + '</span></label>' + App.sm('✕', 'daily-del', { key: x.id }, 'muted') + '</div>';
    });
    return App.card('📌 برنامه‌ی امروز', (rows || '<div class="mu empty">امروز کاری نداری. یک پیگیری یا کار امروز اضافه کن.<div class="q-row">' + App.sm('+ کار امروز', 'daily-focus') + '</div></div>') +
      '<div class="row0 mt"><input id="daily-in" placeholder="مثلاً ۲۰ دقیقه مرور فیزیک" data-f="dly.txt" value="' + u.esc(f.txt) + '" maxlength="200" aria-label="کار امروز"><button type="button" class="sm" data-act="daily-add">+ افزودن</button></div>' +
      '<p class="mu">پیگیری با تاریخ و ساعت را از «✅ کارهای امروز» اضافه کن.</p>', { id: 'daily-card', open: true });
  };
  App.act['daily-focus'] = function () { var i = document.getElementById('daily-in'); if (i) i.focus(); };
  App.act['daily-add'] = function () {
    var f = App.form('dly', {}), t = String(f.txt || '').trim().slice(0, 200);
    if (!t) { App.alert('متن کار امروز را بنویس'); return; }
    var S0 = S(), k = u.todayISO();
    S0.daily = S0.daily || {};
    (S0.daily[k] = S0.daily[k] || []).push({ id: u.uid(), text: t, done: 0 });
    f.txt = ''; App.save(); App.render();
  };
  App.act['daily-toggle'] = function (el) {
    var x = daily().find(function (y) { return String(y.id) === String(el.getAttribute('data-key')); });
    if (x) { x.done = x.done ? 0 : 1; App.save(); }
    App.render();
  };
  App.act['daily-del'] = function (el) { st.delById(daily(), el.getAttribute('data-key')); App.save(); App.render(); };
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && e.target && e.target.id === 'daily-in') { e.preventDefault(); App.act['daily-add'](); }
  });

  // ---- بخش «یادآوری» در تنظیمات ----
  R.settingsCard = function () {
    var c = cfg(), N = window.Notification, perm = N ? N.permission : '';
    var notif = !N ? '<p class="mu">اعلان‌های سیستمی در این نسخه‌ی اپ در دسترس نیست؛ یادآوری داخل برنامه نشان داده می‌شود.</p>'
      : perm === 'granted' ? '<p class="mu">اعلان‌های سیستمی فعال است ✅</p>'
      : perm === 'denied' ? '<p class="mu">اعلان‌ها در تنظیمات مرورگر بسته شده است.</p>'
      : '<div class="q-row">' + App.sm('🔔 فعال‌سازی اعلان‌ها', 'rm-notif') + '</div>';
    return App.card('🔔 یادآوری و پیگیری', '<p class="mu">پیگیری‌هایی که با تاریخ و ساعت ثبت می‌کنی، داخل برنامه یادآوری می‌شوند. اگر ساعت یادآوری روزانه برسد و کار باز مانده باشد، خلاصه‌ی آن نشان داده می‌شود.</p>' +
      '<label class="check" for="rm-on"><input id="rm-on" type="checkbox" data-rm="on"' + (c.on ? ' checked' : '') + '><span>نمایش یادآوری داخل برنامه (بنر بالای امروز)</span></label>' +
      '<div class="field"><label for="rm-at">ساعت یادآوری روزانه (مثلاً ۲۰:۰۰)</label><input id="rm-at" type="text" inputmode="numeric" dir="ltr" maxlength="5" data-rm="at" value="' + u.esc(u.pd(c.at)) + '"></div>' + notif, { key: 'set|remind', open: true });
  };
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (!el || !el.getAttribute || !el.hasAttribute('data-rm')) return;
    var c = S().remind = Object.assign({}, DEF, S().remind);
    if (el.getAttribute('data-rm') === 'on') c.on = el.checked ? 1 : 0;
    else {
      var v = u.ascii(el.value);
      if (!u.validHM(v)) { App.alert('ساعت را به شکل ۲۰:۰۰ وارد کن'); App.render(); return; }
      c.at = u.normHM(v);
    }
    App.save(); App.render(); App.toast('تنظیم ذخیره شد');
  }, false);
})();
