import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.117.2/+esm";

const cfg = window.FADL_CONFIG || {};
if (!cfg.supabaseUrl || !cfg.supabaseAnonKey) throw new Error("Supabase configuration is missing");

// Singleton: all browser modules share the same GoTrueClient instance.
export const db = createClient(cfg.supabaseUrl.trim(), cfg.supabaseAnonKey.trim());
