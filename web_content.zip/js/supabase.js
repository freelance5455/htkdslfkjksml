(function(){
  const src='https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';
  window.WS_SUPABASE_READY=import(src).then(({createClient})=>{
    const c=window.WS_CONFIG||{};
    if(!c.supabaseUrl||!c.supabaseAnonKey) return null;
    window.supabaseClient=createClient(c.supabaseUrl,c.supabaseAnonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    return window.supabaseClient;
  }).catch(e=>{console.warn('Supabase SDK indisponible',e);return null;});
})();
