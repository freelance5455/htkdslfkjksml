/* ============================================================
   camera.js — chase / far chase / first-person rig
   ============================================================ */
'use strict';

class CameraRig {
  constructor(camera) {
    this.cam = camera;
    this.mode = 'chase';
    this.pos = new THREE.Vector3(0, 4, 10);
    this.look = new THREE.Vector3(0, 1, -10);
    this.shake = 0;
    this.shakeT = 0;
    this._fov = 62;
    this._roll = 0;
    this._initialized = false;
  }

  setMode(mode) {
    if (!CAMERA_MODES.includes(mode)) mode = 'chase';
    this.mode = mode;
    this._initialized = false;
  }

  cycle() {
    const i = CAMERA_MODES.indexOf(this.mode);
    this.setMode(CAMERA_MODES[(i + 1) % CAMERA_MODES.length]);
    return this.mode;
  }

  addShake(amount) { this.shake = Math.min(1.8, this.shake + amount); }

  snap(car) {
    this._initialized = false;
    this.update(1 / 60, car, null, true);
  }

  update(dt, car, env, instant = false) {
    const speed = Math.abs(car.speed);
    const speedFrac = Math.min(1, speed / 80);
    const heading = car.heading;
    const sin = Math.sin(heading), cos = Math.cos(heading);
    const spec = car.spec;

    let tx, ty, tz, lookX, lookY, lookZ, followK, fov;

    if (this.mode === 'first') {
      // hood / cockpit view
      const fz = -spec.L * 0.33;
      const fy = car._bodyTop * 0.92 + 0.06;
      tx = car.pos.x + sin * fz;
      ty = fy;
      tz = car.pos.z + cos * fz;
      lookX = car.pos.x + sin * -40;
      lookY = fy + 0.4;
      lookZ = car.pos.z + cos * -40;
      followK = 22;
      fov = 72 + speedFrac * 12;
      this.pos.set(tx, ty, tz);
      this.look.lerp(new THREE.Vector3(lookX, lookY, lookZ), instant ? 1 : Math.min(1, 14 * dt));
      this.cam.position.copy(this.pos);
      this.cam.lookAt(this.look);
      // subtle steering roll
      this._roll = AD.damp(this._roll, -car.steerAngle * 0.11, 8, dt);
      this.cam.rotateZ(this._roll);
      this._applyShake(dt, 0.35);
      this._applyFov(fov, dt);
      return;
    }

    const far = this.mode === 'far';
    const back = (far ? 11.5 : 7.4) + speedFrac * (far ? 3.4 : 2.4);
    const height = (far ? 4.9 : 2.95) + speedFrac * 0.55;
    const side = -car.steerAngle * (far ? 1.8 : 1.3) * speedFrac;

    tx = car.pos.x + sin * back + cos * side;
    ty = height;
    tz = car.pos.z + cos * back - sin * side;

    const ahead = 10 + speedFrac * 20;
    lookX = car.pos.x - sin * ahead * 0.55;
    lookY = 1.35;
    lookZ = car.pos.z - cos * ahead;

    followK = 4.2 + speedFrac * 6;

    if (instant || !this._initialized) {
      this.pos.set(tx, ty, tz);
      this.look.set(lookX, lookY, lookZ);
      this._initialized = true;
    } else {
      this.pos.x = AD.damp(this.pos.x, tx, followK, dt);
      this.pos.y = AD.damp(this.pos.y, ty, 5, dt);
      this.pos.z = AD.damp(this.pos.z, tz, followK, dt);
      this.look.x = AD.damp(this.look.x, lookX, 7, dt);
      this.look.y = AD.damp(this.look.y, lookY, 5, dt);
      this.look.z = AD.damp(this.look.z, lookZ, 7, dt);
    }

    this.cam.position.copy(this.pos);
    this.cam.lookAt(this.look);

    // roll into corners + shake
    this._roll = AD.damp(this._roll, -car.steerAngle * 0.045 * speedFrac, 6, dt);
    this.cam.rotateZ(this._roll);
    this._applyShake(dt, 1);
    fov = 60 + speedFrac * 17 + (car.nitroActive ? 8 : 0);
    this._applyFov(fov, dt);
  }

  _applyShake(dt, scale) {
    this.shake = Math.max(0, this.shake - dt * 2.2);
    this.shakeT += dt * 38;
    const sh = this.shake * this.shake * scale;
    const x = Math.sin(this.shakeT * 1.9) * sh * 0.5;
    const y = Math.cos(this.shakeT * 2.3) * sh * 0.38;
    const z = Math.sin(this.shakeT * 1.3) * sh * 0.25;
    this.cam.position.x += x;
    this.cam.position.y += y;
    this.cam.position.z += z;
  }

  _applyFov(fov, dt) {
    this._fov = AD.damp(this._fov, fov, 3.5, dt);
    if (Math.abs(this.cam.fov - this._fov) > 0.05) {
      this.cam.fov = this._fov;
      this.cam.updateProjectionMatrix();
    }
  }
}
