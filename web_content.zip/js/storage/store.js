/* Penyimpanan ber-namespace ("ular_super:") + migrasi non-destruktif dari key lama (snake*) + backup/restore.
   Fase 1 memakai localStorage; IndexedDB direncanakan untuk riwayat/statistik di Fase 2. */
(function (g) {
  'use strict';
  const SU = g.SU, C = SU.config, P = C.PREFIX;
  const LEG = { highScore: 'snakeHighScore', theme: 'snakeTheme', bgSound: 'snakeBgSound', fxSound: 'snakeFxSound',
    control: 'snakeControls', bgVolume: 'snakeBgVolume', fxVolume: 'snakeFxVolume', special: 'specialThemeUnlocked', save: 'snakeSaveGame' };
  const THEMES = ['classic', 'dark', 'forest', 'neon', 'light', 'special'];
  const DEF = { schema: 1, theme: 'classic', bgSound: true, fxSound: true, bgVolume: 20, fxVolume: 80, control: 'swipe', showFps: false, reducedMotion: false };

  function createStore(ls) {
    const rd = function (k) { try { return ls.getItem(k); } catch (e) { return null; } };
    const wr = function (k, v) { try { ls.setItem(k, v); return { ok: true }; } catch (e) { return { ok: false, error: /quota/i.test(String(e && (e.name + e.message))) ? 'quota' : 'error' }; } };
    const rm = function (k) { try { ls.removeItem(k); } catch (e) { /* abaikan */ } };
    const json = function (k) { const r = rd(k); if (r === null) return undefined; try { return JSON.parse(r); } catch (e) { return null; } };
    const cleanSettings = function (o) {
      const s = Object.assign({}, DEF), i = o || {};
      if (THEMES.indexOf(i.theme) >= 0) s.theme = i.theme;
      ['bgSound', 'fxSound', 'showFps', 'reducedMotion'].forEach(function (k) { if (typeof i[k] === 'boolean') s[k] = i[k]; });
      ['bgVolume', 'fxVolume'].forEach(function (k) { if (SU.util.isNum(i[k], 1, 100)) s[k] = Math.round(i[k]); });
      if (i.control === 'swipe' || i.control === 'dpad') s.control = i.control;
      return s;
    };
    const R = {
      migrate: function () {
        if (rd(P + 'settings') === null) {
          const num = function (k, d) { const n = parseInt(rd(LEG[k]), 10); return isFinite(n) ? n : d; };
          const s = cleanSettings({ theme: rd(LEG.theme), bgSound: rd(LEG.bgSound) !== 'off', fxSound: rd(LEG.fxSound) !== 'off',
            control: rd(LEG.control), bgVolume: num('bgVolume', DEF.bgVolume), fxVolume: num('fxVolume', DEF.fxVolume) });
          wr(P + 'settings', JSON.stringify(s));
          if (rd(LEG.special) === 'true' && rd(P + 'unlocks') === null) wr(P + 'unlocks', JSON.stringify({ special: true }));
        }
        if (rd(P + 'highScore') === null) { const h = parseInt(rd(LEG.highScore), 10); if (isFinite(h) && h > 0) wr(P + 'highScore', String(h)); }
        wr(P + 'schema', String(C.SCHEMA)); /* key lama TIDAK dihapus (rollback aman) */
      },
      getSettings: function () { return cleanSettings(json(P + 'settings')); },
      setSettings: function (patch) { return wr(P + 'settings', JSON.stringify(cleanSettings(Object.assign(R.getSettings(), patch)))); },
      getHigh: function () { const h = parseInt(rd(P + 'highScore'), 10); return isFinite(h) && h > 0 ? h : 0; },
      setHigh: function (n) { return wr(P + 'highScore', String(Math.max(0, Math.floor(n)))); },
      getUnlocks: function () { const u = json(P + 'unlocks'); return { special: !!(u && u.special === true) }; },
      setUnlock: function (k) { const u = R.getUnlocks(); u[k] = true; return wr(P + 'unlocks', JSON.stringify(u)); },
      hasSave: function () { return rd(P + 'save') !== null || rd(LEG.save) !== null; },
      saveSession: function (snap) { return wr(P + 'save', JSON.stringify({ schemaVersion: C.SCHEMA, savedAt: Date.now(), session: snap })); },
      /* status: none | ok | corrupt. Save rusak TIDAK dihapus otomatis. */
      loadSave: function (rng) {
        const cur = json(P + 'save');
        if (cur === null) return { status: 'corrupt', errors: ['JSON rusak'] };
        if (cur !== undefined) {
          if (!cur || cur.schemaVersion !== C.SCHEMA) return { status: 'corrupt', errors: ['versi skema tidak dikenal'] };
          const r = SU.engine.restore(cur.session, rng);
          return r.ok ? { status: 'ok', session: r.session, savedAt: cur.savedAt } : { status: 'corrupt', errors: r.errors };
        }
        const old = json(LEG.save);
        if (old === undefined) return { status: 'none' };
        if (old === null) return { status: 'corrupt', errors: ['JSON lama rusak'] };
        const r = SU.engine.fromLegacy(old, rng);
        return r.ok ? { status: 'ok', session: r.session, legacy: true } : { status: 'corrupt', errors: r.errors };
      },
      /* scope: settings | progress | save | all. Hanya key milik game ini. */
      reset: function (scope) {
        const keys = [];
        const add = function (a) { a.forEach(function (k) { keys.push(k); }); };
        if (scope === 'settings' || scope === 'all') add([P + 'settings', LEG.theme, LEG.bgSound, LEG.fxSound, LEG.control, LEG.bgVolume, LEG.fxVolume]);
        if (scope === 'progress' || scope === 'all') add([P + 'highScore', P + 'unlocks', P + 'save', LEG.highScore, LEG.special, LEG.save]);
        if (scope === 'save') add([P + 'save', LEG.save]);
        if (scope === 'all') add([P + 'schema']);
        keys.forEach(rm); return keys;
      },
      exportBackup: function () {
        const sv = json(P + 'save');
        return JSON.stringify({ app: 'game-ular-super', schemaVersion: C.SCHEMA, exportedAt: new Date().toISOString(),
          data: { settings: R.getSettings(), highScore: R.getHigh(), unlocks: R.getUnlocks(), save: sv && sv.session ? sv : null } }, null, 1);
      },
      parseBackup: function (text) {
        let o; try { o = JSON.parse(text); } catch (e) { return { ok: false, errors: ['Berkas bukan JSON yang valid'] }; }
        if (!o || o.app !== 'game-ular-super') return { ok: false, errors: ['Bukan berkas backup Game Ular Super'] };
        if (o.schemaVersion !== C.SCHEMA || !o.data) return { ok: false, errors: ['Versi backup tidak didukung'] };
        const d = o.data, e = [];
        if (!Number.isInteger(d.highScore) || d.highScore < 0 || d.highScore > 1e7) e.push('highScore tidak valid');
        if (!d.settings || typeof d.settings !== 'object') e.push('settings tidak valid');
        if (d.save) { const v = SU.engine.validate(d.save.session); if (!v.ok) e.push('save tidak valid: ' + v.errors.join(',')); }
        return e.length ? { ok: false, errors: e } : { ok: true, data: d };
      },
      /* mode: overwrite | merge (merge: skor tertinggi & unlock digabung; pengaturan & save saat ini dipertahankan) */
      applyBackup: function (d, mode) {
        if (mode === 'merge') {
          if (d.highScore > R.getHigh()) R.setHigh(d.highScore);
          if (d.unlocks && d.unlocks.special) R.setUnlock('special');
          return;
        }
        wr(P + 'settings', JSON.stringify(cleanSettings(d.settings))); R.setHigh(d.highScore);
        if (d.unlocks && d.unlocks.special) R.setUnlock('special'); else rm(P + 'unlocks');
        if (d.save) wr(P + 'save', JSON.stringify(d.save)); else rm(P + 'save');
      }
    };
    return R;
  }
  SU.createStore = createStore; SU.THEME_IDS = THEMES; SU.LEGACY_KEYS = LEG;
})(typeof window !== 'undefined' ? window : globalThis);
