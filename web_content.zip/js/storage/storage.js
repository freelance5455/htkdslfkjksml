/* ===================================================================
 * VFL.Storage
 * لایه ذخیره‌سازی — فعلاً روی localStorage، اما پشت یک رابط ساده
 * قرار دارد تا در آینده بتوان آن را با روش دیگری (مثلاً سرور) عوض کرد.
 * =================================================================== */
(function (VFL) {
  "use strict";

  var SAVE_KEY = "vfl_save_v1";

  VFL.Storage = {
    isAvailable: function () {
      try {
        var testKey = "__vfl_test__";
        window.localStorage.setItem(testKey, "1");
        window.localStorage.removeItem(testKey);
        return true;
      } catch (e) {
        return false;
      }
    },

    save: function (state) {
      if (!VFL.Storage.isAvailable()) return false;
      try {
        var payload = VFL.Utils.clone(state);
        payload.meta.updatedAt = new Date().toISOString();
        window.localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
        return true;
      } catch (e) {
        console.error("VFL.Storage.save failed:", e);
        return false;
      }
    },

    load: function () {
      if (!VFL.Storage.isAvailable()) return null;
      try {
        var raw = window.localStorage.getItem(SAVE_KEY);
        if (!raw) return null;
        return JSON.parse(raw);
      } catch (e) {
        console.error("VFL.Storage.load failed:", e);
        return null;
      }
    },

    hasSave: function () {
      if (!VFL.Storage.isAvailable()) return false;
      return window.localStorage.getItem(SAVE_KEY) !== null;
    },

    clear: function () {
      if (!VFL.Storage.isAvailable()) return false;
      window.localStorage.removeItem(SAVE_KEY);
      return true;
    }
  };
})(window.VFL || (window.VFL = {}));
