/**
 * Módulo de Armazenamento e Persistência do aplicativo Contagem Regressiva
 * Gerencia leitura, gravação e remoção em localStorage e IndexedDB.
 * Preserva 100% dos nomes das chaves, versões de migração (v1, v2, v3, v4) e schema do IndexedDB.
 * Totalmente compatível com Android WebView (file:// e http://).
 */
(function(root){
  var S = {};

  // Chaves canônicas do localStorage mantidas estritamente idênticas
  S.KEYS = {
    K4: "contagem-v4",
    K3: "contagem-v3",
    K2: "contagem-v2",
    K1: "contagem-v1",
    PK: "contagem-prefs",
    PRK: "contagem-profile",
    AK: "contagem-admin",
    EXK: "contagem-ex"
  };

  // Nome do banco e object store do IndexedDB
  S.IDB_NAME = "contagem-media";
  S.IDB_STORE = "m";
  S.IDB_VERSION = 1;

  var idbInstance = null;

  // Leitura segura do localStorage com deserialização JSON
  S.read = function(k){
    try {
      var r = localStorage.getItem(k);
      return r ? JSON.parse(r) : null;
    } catch(e) {
      return null;
    }
  };

  // Gravação segura no localStorage com serialização JSON
  S.write = function(k, v){
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch(e) {}
  };

  // Remoção segura no localStorage
  S.remove = function(k){
    try {
      localStorage.removeItem(k);
    } catch(e) {}
  };

  // Abertura e obtenção da conexão IndexedDB com tratamento de erro
  S.idb = function(){
    return new Promise(function(res, rej){
      if (idbInstance) {
        res(idbInstance);
        return;
      }
      if (!window.indexedDB) {
        rej(new Error("IndexedDB não disponível"));
        return;
      }
      var req = indexedDB.open(S.IDB_NAME, S.IDB_VERSION);
      req.onupgradeneeded = function(){
        req.result.createObjectStore(S.IDB_STORE);
      };
      req.onsuccess = function(){
        idbInstance = req.result;
        res(idbInstance);
      };
      req.onerror = function(){
        rej(req.error);
      };
    });
  };

  // Armazenamento de Blob/mídia no IndexedDB
  S.idbPut = function(k, b){
    return S.idb().then(function(db){
      return new Promise(function(res, rej){
        var t = db.transaction(S.IDB_STORE, "readwrite");
        t.objectStore(S.IDB_STORE).put(b, k);
        t.oncomplete = res;
        t.onerror = function(){ rej(t.error); };
      });
    });
  };

  // Recuperação de Blob/mídia no IndexedDB
  S.idbGet = function(k){
    return S.idb().then(function(db){
      return new Promise(function(res, rej){
        var q = db.transaction(S.IDB_STORE).objectStore(S.IDB_STORE).get(k);
        q.onsuccess = function(){ res(q.result); };
        q.onerror = function(){ rej(q.error); };
      });
    });
  };

  // Exclusão de Blob/mídia no IndexedDB
  S.idbDel = function(k){
    return S.idb().then(function(db){
      return new Promise(function(res){
        var t = db.transaction(S.IDB_STORE, "readwrite");
        t.objectStore(S.IDB_STORE).delete(k);
        t.oncomplete = res;
        t.onerror = res;
      });
    }).catch(function(){});
  };

  root.AppStorage = S;
})(typeof window !== "undefined" ? window : this);
