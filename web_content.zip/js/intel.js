/* intel.js — Phase 6: espionage and intelligence.
   Agencies and agents, spy networks per target nation, covert operations, counter-espionage,
   fog of war for foreign armies, masked foreign statistics, and AI espionage. */
(function (G) {
  'use strict';

  const cname = id => G.COUNTRIES[id].name;
  G.AGENCY_MAX = 5; G.COUNTER_MAX = 5;
  G.AGENT_COST = { gold: 60, manpower: 200, days: 15 };
  G.agentCap = function (id) { return 2 + 2 * G.state.intel[id].level; };
  G.agencyUpgradeCost = function (id) { return 200 * G.state.intel[id].level; };
  G.counterUpgradeCost = function (id) { return 150 * (G.state.intel[id].counter + 1); };

  // type: cost, days (0 = ongoing), min network, difficulty penalty
  G.OPS = {
    infiltrate: { name: 'Infiltrate', icon: '🕵', cost: 40, days: 0, min: 0, diff: 0, desc: 'Ongoing: builds a spy network in the target (+0.6/day). A network lets you see its army, treasury and stockpiles and unlocks other operations.' },
    plans:      { name: 'Steal war plans', icon: '📜', cost: 90, days: 12, min: 20, diff: 0.05, desc: 'Reveals everything about the target — armies, treasury, resources — for 60 days.' },
    propaganda: { name: 'Propaganda', icon: '📣', cost: 80, days: 15, min: 15, diff: 0, desc: 'Improves the target\'s relations with you by 10.' },
    discord:    { name: 'Sow discord', icon: '🗯', cost: 120, days: 20, min: 35, diff: 0.12, desc: 'Damages the target\'s relations with its closest partner by 20; may break their treaty.' },
    unrest:     { name: 'Incite unrest', icon: '🔥', cost: 100, days: 25, min: 30, diff: 0.12, desc: 'For 60 days the target gains 40% less manpower and 10% less income.' },
    sabotage:   { name: 'Sabotage industry', icon: '💣', cost: 120, days: 20, min: 25, diff: 0.10, desc: 'Destroys 25% of the target\'s equipment stockpile and 20% of its steel, coal and oil.' },
    agitate:    { name: 'Agitate province', icon: '📢', cost: 90, days: 15, min: 30, diff: 0.08, prov: true, desc: 'Raises discontent in one province of the target (+30, neighbours +10). Discontent fades slowly, faster rises when the nation starves or is broke.' },
    revolution: { name: 'Incite revolution', icon: '✊', cost: 250, days: 40, min: 60, diff: 0.30, prov: true, desc: 'The province rebels and joins YOU without a war. Needs discontent 40+, a province bordering your land, and a network of 60% (capitals: 85% and discontent 70+). Failure or exposure causes an incident.' },
    steal:      { name: 'Steal technology', icon: '🧪', cost: 150, days: 25, min: 40, diff: 0.15, desc: 'Steals a technology the target has and you lack: gives 60% of its research cost as progress.' },
    assassinate:{ name: 'Assassinate general', icon: '🎯', cost: 200, days: 30, min: 50, diff: 0.30, desc: 'Kills the target\'s best general. A failure here causes a diplomatic incident.' }
  };
  G.OP_TYPES = ['infiltrate', 'plans', 'steal', 'propaganda', 'discord', 'unrest', 'sabotage', 'assassinate'];
  G.counterOf = function (id) { return G.state.intel[id].counter + G.techEff(id, 'counter'); };
  G.PROV_OP_TYPES = ['agitate', 'revolution'];

  const FIRST = ['Mara', 'Ilya', 'Corin', 'Sable', 'Teo', 'Vera', 'Anselm', 'Nadia', 'Orin', 'Lysa', 'Dmitri', 'Kael', 'Zora', 'Henrik'];
  const LAST = ['Quill', 'Marsh', 'Vance', 'Roke', 'Thorn', 'Ashby', 'Lorne', 'Kestrel', 'Dunn', 'Sorel', 'Vick', 'Hale'];

  G.initIntel = function (st, fresh) {
    st.intel = st.intel || {}; st.ops = st.ops || []; st.effects = st.effects || [];
    st.reveal = st.reveal || {}; st.disc = st.disc || {}; st.intelLog = st.intelLog || []; st.nextOp = st.nextOp || 1; st.nextAgent = st.nextAgent || 1;
    let s = 4242; const rnd = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
    for (const id in G.COUNTRIES) {
      if (!st.intel[id]) {
        st.intel[id] = { level: 1, counter: id === st.player ? 0 : 1, agents: [], training: [], net: {} };
        for (let i = 0; i < 2; i++) st.intel[id].agents.push(newAgent(st, rnd, 1 + Math.floor(rnd() * 3)));
      }
      const it = st.intel[id]; it.training = it.training || []; it.net = it.net || {};
    }
  };
  function newAgent(st, rnd, skill) {
    return { id: st.nextAgent++, name: FIRST[Math.floor(rnd() * FIRST.length)] + ' ' + LAST[Math.floor(rnd() * LAST.length)], skill: skill, op: null };
  }
  function irnd() { return G.rand(); }

  G.netLevel = function (a, t) { return a === t ? 100 : ((G.state.intel[a] && G.state.intel[a].net[t]) || 0); };
  G.revealLeft = function (viewer, target) { return Math.max(0, ((G.state.reveal[viewer + '|' + target]) || 0) - G.state.day); };

  // 0..100: how much `viewer` knows about `target`
  G.intelLevel = function (viewer, target) {
    if (viewer === target || G.allied(viewer, target)) return 100;
    if (G.revealLeft(viewer, target) > 0) return 100;
    return G.netLevel(viewer, target);
  };
  // Masked number for UI: exact with good intel, rounded with partial, hidden without.
  G.intelVal = function (target, v, fmt) {
    const lv = G.intelLevel(G.state.player, target); fmt = fmt || (n => Math.round(n).toLocaleString('en-US'));
    if (lv >= 50) return fmt(v);
    if (lv >= 20) { const m = Math.pow(10, Math.max(1, String(Math.round(Math.abs(v))).length - 1)); return '~' + fmt(Math.round(v / m) * m); }
    return '?';
  };

  /* ---------- fog of war ---------- */
  let visKey = null, visSet = null;
  function visibleProvinces(viewer) {
    const st = G.state, key = viewer + ':' + st.day + ':' + st.armies.length + ':' + st.treaties.length;
    if (key === visKey) return visSet;
    const set = {}, P = G.provinces;
    const friend = o => o === viewer || G.allied(o, viewer);
    const add = p => { set[p] = true; P[p].adj.forEach(n => { set[n] = true; }); };
    P.forEach(p => { if (!p.sea && friend(st.owners[p.id])) add(p.id); });
    st.armies.forEach(a => { if (friend(a.owner)) add(a.prov); });
    visKey = key; visSet = set; return set;
  }
  G.canSee = function (a) {
    const st = G.state, me = st.player;
    if (!me || a.owner === me) return true;
    if (G.intelLevel(me, a.owner) >= 50) return true;
    const set = visibleProvinces(me);
    return !!set[a.prov] || (a.path.length > 0 && !!set[a.path[0]]);
  };

  /* ---------- effects ---------- */
  G.hasEffect = function (id, type) { return G.state.effects.some(e => e.target === id && e.type === type && e.until > G.state.day); };
  G.effectMult = function (id, kind) {
    if (!G.hasEffect(id, 'unrest')) return 1;
    return kind === 'manpower' ? 0.6 : kind === 'income' ? 0.9 : 1;
  };

  function note(id, text) {
    const st = G.state;
    if (id !== st.player) return;
    st.intelLog.unshift(G.dateString() + ' — ' + text);
    if (st.intelLog.length > 40) st.intelLog.length = 40;
    G.toast && G.toast(text);
    G.onIntelNote && G.onIntelNote();
  }

  /* ---------- operations ---------- */
  G.idleAgents = function (id) { return G.state.intel[id].agents.filter(a => !a.op); };
    G.discontent = function (prov) { return (G.state.disc && G.state.disc[prov]) || 0; };
  G.opChance = function (owner, type, target, agent, prov) {
    const O = G.OPS[type], it = G.state.intel[owner], tc = G.counterOf(target);
    const net = type === 'infiltrate' ? 20 : G.netLevel(owner, target);
    let p = 0.25 + 0.006 * net + 0.07 * (agent ? agent.skill : 1) - 0.09 * tc - O.diff + G.techEff(owner, 'spy');
    if (type === 'revolution' && prov != null) {
      p += 0.004 * (G.discontent(prov) - 40);
      p -= Math.min(0.3, 0.12 * G.armiesAt(prov).filter(a => a.owner === target).length);
    }
    return Math.max(0.05, Math.min(0.95, p));
  };
  G.revolutionCheck = function (owner, target, prov) {
    const st = G.state, P = G.provinces[prov];
    if (prov == null || !P || P.sea || st.owners[prov] !== target) return { ok: false, msg: 'Pick a province of the target' };
    if (!P.adj.some(n => st.owners[n] === owner)) return { ok: false, msg: 'The province must border your land' };
    const cap = G.COUNTRIES[target].capitalId === prov, net = G.netLevel(owner, target), d = G.discontent(prov);
    if (cap && net < 85) return { ok: false, msg: 'A capital needs a network of 85%' };
    if (d < (cap ? 70 : 40)) return { ok: false, msg: 'Discontent too low (' + Math.floor(d) + ' / ' + (cap ? 70 : 40) + ') — agitate first' };
    return { ok: true };
  };
  G.canLaunch = function (owner, type, target, prov) {
    const st = G.state, O = G.OPS[type], c = st.countries[owner];
    if (O.prov) {
      if (prov == null || st.owners[prov] !== target || G.provinces[prov].sea) return { ok: false, msg: 'Pick a province of the target first' };
      if (st.ops.some(o => o.owner === owner && o.type === type && o.prov === prov)) return { ok: false, msg: 'Already operating there' };
      if (type === 'revolution') { const r = G.revolutionCheck(owner, target, prov); if (!r.ok) { if (G.netLevel(owner, target) >= O.min) return r; } }
    }
    if (owner === target || G.isDead(target)) return { ok: false, msg: 'Invalid target' };
    if (G.allied(owner, target) && type !== 'infiltrate') return { ok: false, msg: 'Cannot act against an ally' };
    if (G.netLevel(owner, target) < O.min) return { ok: false, msg: 'Needs a network of ' + O.min + ' (now ' + Math.floor(G.netLevel(owner, target)) + ')' };
    if (c.treasury < O.cost) return { ok: false, msg: 'Not enough gold (' + O.cost + ')' };
    if (!G.idleAgents(owner).length) return { ok: false, msg: 'No idle agent' };
    if (type === 'infiltrate' && st.ops.some(o => o.owner === owner && o.target === target && o.type === 'infiltrate')) return { ok: false, msg: 'Already infiltrating' };
    if (type === 'assassinate' && G.state.generals[target].length < 2) return { ok: false, msg: 'They have too few generals' };
    return { ok: true };
  };
  G.launchOp = function (owner, type, target, prov) {
    const chk = G.canLaunch(owner, type, target, prov); if (!chk.ok) return chk;
    const st = G.state, O = G.OPS[type];
    const ag = G.idleAgents(owner).sort((a, b) => b.skill - a.skill)[0];
    st.countries[owner].treasury -= O.cost;
    const op = { id: st.nextOp++, owner: owner, type: type, target: target, agent: ag.id, left: O.days, total: O.days, start: st.day, prov: O.prov ? prov : null };
    ag.op = op.id; st.ops.push(op);
    return { ok: true, op: op, agent: ag };
  };
  G.abortOp = function (id) {
    const st = G.state, i = st.ops.findIndex(o => o.id === id); if (i < 0) return;
    const op = st.ops[i], ag = st.intel[op.owner].agents.find(a => a.id === op.agent);
    if (ag) ag.op = null;
    st.ops.splice(i, 1);
  };

  function exposed(op, severity) {
    const st = G.state;
    G.addRelation(op.owner, op.target, -10 * severity);
    st.infamy[op.owner] = Math.min(100, (st.infamy[op.owner] || 0) + 4 * severity);
    note(op.target, '🕵 Agents of ' + cname(op.owner) + ' were exposed (' + G.OPS[op.type].name + ')');
    if (op.owner === st.player) note(op.owner, '⚠ Your operation was exposed — ' + cname(op.target) + ' knows it was you');
  }

  function applyOp(op) {
    const st = G.state, t = st.countries[op.target], o = op.owner;
    switch (op.type) {
      case 'plans':
        st.reveal[o + '|' + op.target] = st.day + 60;
        note(o, '📜 War plans of ' + cname(op.target) + ' stolen — full intel for 60 days');
        break;
      case 'propaganda':
        G.addRelation(o, op.target, 10);
        note(o, '📣 Propaganda in ' + cname(op.target) + ' worked (relations +10)');
        break;
      case 'discord': {
        const partners = G.treatiesOf(op.target).map(x => x.a === op.target ? x.b : x.a).filter(x => x !== o);
        let p = partners.sort((x, y) => G.relation(op.target, y) - G.relation(op.target, x))[0];
        if (p == null) p = Object.keys(G.COUNTRIES).filter(x => x !== o && x !== op.target && !G.isDead(x)).sort((x, y) => G.relation(op.target, y) - G.relation(op.target, x))[0];
        if (p != null) {
          G.addRelation(op.target, p, -20);
          note(o, '🗯 Discord between ' + cname(op.target) + ' and ' + cname(p));
          if (op.target === st.player) note(op.target, '🗯 Relations with ' + cname(p) + ' soured mysteriously');
        }
        break;
      }
      case 'unrest':
        st.effects.push({ target: op.target, type: 'unrest', until: st.day + 60, by: o });
        note(o, '🔥 Unrest spreads in ' + cname(op.target));
        if (op.target === st.player) note(op.target, '🔥 Unrest is spreading in your country — manpower and income suffer');
        break;
      case 'sabotage':
        for (const k in t.equip) if (k !== 'horses') t.equip[k] = Math.floor(t.equip[k] * 0.75);
        ['steel', 'coal', 'oil'].forEach(r => { t.res[r] = Math.floor(t.res[r] * 0.8); });
        note(o, '💣 Sabotage struck ' + cname(op.target) + "'s industry");
        if (op.target === st.player) note(op.target, '💣 Saboteurs destroyed part of your stockpiles');
        break;
      case 'steal': {
        const nm = G.stealTech(o, op.target);
        note(o, nm ? '🧪 Stole technology: ' + nm : '🧪 Nothing worth stealing in ' + cname(op.target));
        if (nm && op.target === st.player) note(op.target, '🧪 Foreign agents stole your technology!');
        break;
      }
      case 'agitate': {
        const P = G.provinces[op.prov];
        st.disc[op.prov] = Math.min(100, G.discontent(op.prov) + 30);
        P.adj.forEach(n => { if (st.owners[n] === op.target && !G.provinces[n].sea) st.disc[n] = Math.min(100, G.discontent(n) + 10); });
        note(o, '📢 Discontent rises in ' + P.name + ' (' + Math.round(st.disc[op.prov]) + ')');
        break;
      }
      case 'revolution': {
        const chk = G.revolutionCheck(o, op.target, op.prov);
        if (!chk.ok) { note(o, '✊ Revolution in ' + G.provinces[op.prov].name + ' fizzled: ' + chk.msg); break; }
        const nameP = G.provinces[op.prov].name;
        st.disc[op.prov] = 0;
        G.transferProvince(op.prov, o);
        G.armiesAt(op.prov).filter(a => a.owner !== o && !G.canEnter(a, op.prov)).forEach(() => {});
        G.expelForeignArmies();
        note(o, '✊ ' + nameP + ' rose up and joined you!');
        if (op.target === st.player) note(op.target, '✊ ' + nameP + ' has rebelled and joined ' + cname(o) + '!');
        G.addRelation(o, op.target, -20);
        if (irnd() < 0.5) { st.infamy[o] = Math.min(100, (st.infamy[o] || 0) + 8); G.addRelation(o, op.target, -15); }
        break;
      }
      case 'assassinate': {
        const gl = st.generals[op.target].slice().sort((a, b) => b.skill - a.skill)[0];
        if (gl) {
          const army = gl.army ? st.armies.find(x => x.general === gl.id) : null;
          if (army) army.general = null;
          st.generals[op.target] = st.generals[op.target].filter(x => x !== gl);
          note(o, '🎯 General ' + gl.name + ' of ' + cname(op.target) + ' was assassinated');
          if (op.target === st.player) note(op.target, '🎯 General ' + gl.name + ' was assassinated!');
        }
        break;
      }
    }
  }

  function resolveOp(op) {
    const st = G.state, it = st.intel[op.owner], ag = it.agents.find(a => a.id === op.agent);
    const idx = st.ops.indexOf(op); if (idx >= 0) st.ops.splice(idx, 1);
    if (!ag) return;
    ag.op = null;
    const p = G.opChance(op.owner, op.type, op.target, ag, op.prov), tc = G.counterOf(op.target);
    if (irnd() < p) {
      applyOp(op);
      if (irnd() < 0.10 + 0.05 * tc + (op.type === 'revolution' ? 0.15 : 0)) exposed(op, op.type === 'assassinate' || op.type === 'revolution' ? 2 : op.type === 'propaganda' ? 0 : 1);
      if (ag.skill < 5 && irnd() < 0.25) { ag.skill++; if (op.owner === st.player) note(op.owner, '⭐ ' + ag.name + ' gained experience'); }
    } else {
      const caught = irnd() < 0.5;
      if (caught) it.agents = it.agents.filter(a => a !== ag);
      if (op.type === 'revolution') st.disc[op.prov] = Math.max(0, G.discontent(op.prov) - 20);
      note(op.owner, '❌ ' + G.OPS[op.type].name + ' on ' + cname(op.target) + ' failed' + (caught ? ' — ' + ag.name + ' was captured' : ' — agent returned'));
      if (irnd() < (caught ? 0.7 : 0.3) + 0.04 * tc) exposed(op, op.type === 'assassinate' || op.type === 'revolution' ? 3 : 1);
    }
  }

  /* ---------- upgrades and recruitment ---------- */
  G.recruitAgent = function (id) {
    const st = G.state, it = st.intel[id], c = st.countries[id], K = G.AGENT_COST;
    if (it.agents.length + it.training.length >= G.agentCap(id)) return { ok: false, msg: 'Agency is full — upgrade it' };
    if (c.treasury < K.gold) return { ok: false, msg: 'Not enough gold (' + K.gold + ')' };
    if (c.manpower < K.manpower) return { ok: false, msg: 'Not enough manpower (' + K.manpower + ')' };
    c.treasury -= K.gold; c.manpower -= K.manpower;
    it.training.push({ ready: st.day + K.days });
    return { ok: true };
  };
  G.upgradeAgency = function (id) {
    const it = G.state.intel[id], c = G.state.countries[id], cost = G.agencyUpgradeCost(id);
    if (it.level >= G.AGENCY_MAX) return { ok: false, msg: 'Maximum level' };
    if (c.treasury < cost) return { ok: false, msg: 'Not enough gold (' + cost + ')' };
    c.treasury -= cost; it.level++; return { ok: true };
  };
  G.upgradeCounter = function (id) {
    const it = G.state.intel[id], c = G.state.countries[id], cost = G.counterUpgradeCost(id);
    if (it.counter >= G.COUNTER_MAX) return { ok: false, msg: 'Maximum level' };
    if (c.treasury < cost) return { ok: false, msg: 'Not enough gold (' + cost + ')' };
    c.treasury -= cost; it.counter++; return { ok: true };
  };

  /* ---------- AI ---------- */
  function aiIntel(id) {
    const st = G.state, it = st.intel[id], c = st.countries[id];
    if (it.agents.length + it.training.length < Math.min(G.agentCap(id), 4) && c.treasury > 250) G.recruitAgent(id);
    if (it.counter < 2 && c.treasury > 700) G.upgradeCounter(id);
    if (it.level < 2 && c.treasury > 900) G.upgradeAgency(id);
    if (!G.idleAgents(id).length || c.treasury < 250) return;
    const enemies = G.warsOf(id), rivals = Object.keys(G.COUNTRIES).filter(x => x !== id && !G.isDead(x) && !G.allied(id, x) && G.relation(id, x) < -10);
    const pool = enemies.concat(rivals);
    if (!pool.length) return;
    const target = pool[Math.floor(irnd() * pool.length)], net = G.netLevel(id, target);
    let types;
    if (net < 25 && !st.ops.some(o => o.owner === id && o.target === target && o.type === 'infiltrate')) types = ['infiltrate'];
    else if (enemies.includes(target)) types = ['sabotage', 'unrest', 'plans', 'steal', 'assassinate', 'infiltrate'];
    else types = ['discord', 'plans', 'steal', 'sabotage', 'unrest'];
    for (const t of types.sort(() => irnd() - 0.5)) if (!G.OPS[t].prov && G.canLaunch(id, t, target).ok) { G.launchOp(id, t, target); return; }
  }

  /* ---------- daily ---------- */
  G.intelDay = function () {
    const st = G.state; if (!st.intel) return;
    // training agents arrive
    for (const id in st.intel) {
      const it = st.intel[id];
      if (G.isDead(id)) continue;
      it.training = it.training.filter(tr => {
        if (tr.ready > st.day) return true;
        let s = st.day + 17; const rnd = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
        const ag = newAgent(st, rnd, 1 + Math.floor(irnd() * 2)); it.agents.push(ag);
        note(id, '🕵 Agent ' + ag.name + ' finished training');
        return false;
      });
    }
    // ongoing and timed operations
    for (const op of st.ops.slice()) {
      if (G.isDead(op.target) || G.isDead(op.owner)) { G.abortOp(op.id); continue; }
      if (op.type === 'infiltrate') {
        const it = st.intel[op.owner], ag = it.agents.find(a => a.id === op.agent);
        const tc = G.counterOf(op.target);
        const gain = 0.6 * G.techMult(op.owner, 'netgrowth') * (1 - 0.12 * tc) * (0.8 + 0.1 * (ag ? ag.skill : 1));
        it.net[op.target] = Math.min(100, (it.net[op.target] || 0) + gain);
        if (ag && irnd() < 0.0015 * (1 + tc)) {                       // spy caught
          it.agents = it.agents.filter(a => a !== ag); G.abortOp(op.id);
          note(op.owner, '❌ Agent ' + ag.name + ' was caught in ' + cname(op.target));
          if (irnd() < 0.6) exposed(op, 1);
        }
      } else if (--op.left <= 0) resolveOp(op);
    }
    // networks decay where nobody works
    for (const id in st.intel) {
      const net = st.intel[id].net;
      for (const t in net) if (!st.ops.some(o => o.owner === id && o.target === t && o.type === 'infiltrate')) net[t] = Math.max(0, net[t] - 0.1);
    }
    for (const k in st.disc) {
      const o = st.owners[k], c = o && st.countries[o];
      let d = st.disc[k] - 0.15 + (c && (c.starving || c.broke) ? 0.35 : 0);
      if (d <= 0.5) delete st.disc[k]; else st.disc[k] = Math.min(100, d);
    }
    st.effects = st.effects.filter(e => e.until > st.day);
    for (const k in st.reveal) if (st.reveal[k] <= st.day) delete st.reveal[k];
    // AI
    if (st.day % 10 === 4) for (const id of Object.keys(st.countries)) if (id !== st.player && !st.countries[id].dead) aiIntel(id);
  };
})(window.EMP = window.EMP || {});
