(() => {
    const snap = document.getElementById('ffm26-click-sound'), tick = document.getElementById('ffm26-click2-sound');
    let ctx = null, buf = null, busy = false;
    const play = (a) => { try { a.currentTime = 0; const p = a.play(); if (p && p.catch) p.catch(() => {}); } catch (_) {} };
    function prep() {
        try {
            if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
            if (ctx.state === 'suspended') ctx.resume();
            if (!buf && !busy) {
                busy = true;
                /* audio now lives in assets/audio/click2.wav (was an inline data: URI) */
                fetch(tick.src).then((r) => r.arrayBuffer()).then((ab) => {
                    const pr = ctx.decodeAudioData(ab, (x) => { buf = x; }, () => {});
                    if (pr && pr.catch) pr.catch(() => {});
                }).catch(() => {});
            }
        } catch (_) {}
    }
    function playTick() {
        prep();
        if (ctx && buf && ctx.state === 'running') { const s = ctx.createBufferSource(); s.buffer = buf; s.connect(ctx.destination); s.start(0); }
        else play(tick);
    }
    ['pointerdown', 'touchstart', 'keydown'].forEach((e) => document.addEventListener(e, prep, { passive: true, capture: true }));
    document.addEventListener('click', (event) => {
        const target = event.target;
        if (!target || !target.closest) return;
        if (!target.closest('button, [onclick], a, input, select, textarea, [role="button"], [role="tab"], label, .player-card, .eng-tile, .eng-day, .eng-mday')) return;
        /* original finger-snap only on the big main-menu buttons; everything else uses the new click */
        if (target.closest('.mm-car button, .mm-row button')) play(snap); else playTick();
    }, true);
})();
