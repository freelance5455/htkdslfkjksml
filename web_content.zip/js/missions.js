/* ============================================================
   missions.js — daily missions (3 per day, date-seeded)
   ============================================================ */
'use strict';

class MissionSystem {
  constructor(save) {
    this.save = save;
    this.ensure();
  }

  todayKey() {
    const d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }

  ensure() {
    const today = this.todayKey();
    const m = this.save.data.missions;
    if (m.date === today && Array.isArray(m.list) && m.list.length) return;
    this._generate(today);
  }

  _generate(today) {
    const seed = 0;
    let s = 0;
    for (let i = 0; i < today.length; i++) s = (s * 31 + today.charCodeAt(i)) >>> 0;
    const rng = AD.seeded(s || 1234567);
    const pool = MISSION_POOL.slice();
    const chosen = [];
    while (chosen.length < 3 && pool.length) {
      const idx = Math.floor(rng() * pool.length);
      chosen.push(pool.splice(idx, 1)[0]);
    }
    const list = chosen.map((tpl, i) => {
      const steps = Math.floor((tpl.max - tpl.min) / tpl.step) + 1;
      const target = tpl.min + Math.floor(rng() * steps) * tpl.step;
      return {
        id: today + '_' + i,
        type: tpl.type,
        label: tpl.label.replace('{t}', target.toLocaleString('en-US')),
        target,
        reward: tpl.reward,
        progress: 0,
        claimed: false,
      };
    });
    this.save.data.missions = { date: today, list };
    this.save.save();
  }

  list() {
    this.ensure();
    return this.save.data.missions.list;
  }

  track(type, amount) {
    const completed = [];
    for (const m of this.list()) {
      if (m.claimed || m.progress >= m.target) continue;
      if (m.type !== type) continue;
      m.progress = Math.min(m.target, m.progress + amount);
      if (m.progress >= m.target) completed.push(m);
    }
    if (completed.length) this.save.save();
    return completed;
  }

  trackMax(type, value) {
    const completed = [];
    for (const m of this.list()) {
      if (m.claimed || m.progress >= m.target) continue;
      if (m.type !== type) continue;
      if (value > m.progress) m.progress = Math.min(m.target, value);
      if (m.progress >= m.target) completed.push(m);
    }
    if (completed.length) this.save.save();
    return completed;
  }

  claim(id) {
    const m = this.list().find(x => x.id === id);
    if (!m || m.claimed || m.progress < m.target) return 0;
    m.claimed = true;
    this.save.addCoins(m.reward);
    this.save.save();
    return m.reward;
  }

  claimableCount() {
    return this.list().filter(m => !m.claimed && m.progress >= m.target).length;
  }
}
