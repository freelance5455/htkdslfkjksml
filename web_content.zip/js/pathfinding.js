/**
 * Snake Escape — BFS Pathfinding & Dynamic Puzzle Solver (Hint Engine)
 * Analyzes board state, mechanism dependencies, and multi-snake blockages.
 */
(function() {
  'use strict';

  class PathfindingSolver {
    /**
     * Standard 4-directional BFS on logical grid
     * @returns Array of {x, y} coordinates from start to goal inclusive, or null
     */
    findPath(start, goal, grid, obstacleCoords = []) {
      if (!start || !goal) return null;
      if (start.x === goal.x && start.y === goal.y) return [start];

      const queue = [[start]];
      const visited = new Set();
      const key = (p) => `${p.x},${p.y}`;

      visited.add(key(start));

      const obstacleSet = new Set();
      obstacleCoords.forEach(o => obstacleSet.add(key(o)));

      // Don't treat goal itself as an obstacle even if marked
      obstacleSet.delete(key(goal));

      const directions = [
        { x: 0, y: -1 }, // UP
        { x: 0, y: 1 },  // DOWN
        { x: -1, y: 0 }, // LEFT
        { x: 1, y: 0 }   // RIGHT
      ];

      while (queue.length > 0) {
        const path = queue.shift();
        const current = path[path.length - 1];

        if (current.x === goal.x && current.y === goal.y) {
          return path;
        }

        for (const dir of directions) {
          const next = { x: current.x + dir.x, y: current.y + dir.y };
          const k = key(next);

          if (
            next.x >= 0 && next.x < grid.cols &&
            next.y >= 0 && next.y < grid.rows &&
            !obstacleSet.has(k) &&
            !visited.has(k)
          ) {
            visited.add(k);
            queue.push([...path, next]);
          }
        }
      }

      return null;
    }

    /**
     * Solves and generates an intelligent hint based on current puzzle state
     */
    findHint(state) {
      const { snakes, activeSnakeId, walls, keys, gates, switches, portals, bridges, blocks, traps, grid } = state;
      const activeSnake = snakes.find(s => s.id === activeSnakeId && !s.escaped) || snakes.find(s => !s.escaped);
      if (!activeSnake) return null;

      // 1. Collect all static and dynamic impassable obstacles
      const baseObstacles = [];
      if (walls) walls.forEach(w => baseObstacles.push(w));
      if (gates) gates.filter(g => !g.isOpen).forEach(g => baseObstacles.push(g));
      if (bridges) bridges.filter(b => !b.active).forEach(b => baseObstacles.push(b));
      if (blocks) blocks.forEach(b => baseObstacles.push(b));
      if (traps) traps.filter(t => t.state === 'active').forEach(t => baseObstacles.push(t));

      // Other snakes' bodies
      snakes.forEach(s => {
        if (s.escaped) return;
        s.segments.forEach((seg, idx) => {
          if (s.id === activeSnake.id && idx === 0) return; // ignore active head
          baseObstacles.push(seg);
        });
      });

      const head = activeSnake.getHead();

      // Priority 1: Check uncollected matching keys
      const uncollectedKeys = (keys || []).filter(k => !k.collected);
      if (uncollectedKeys.length > 0) {
        // Find if there's an uncollected key of active snake's color or gold
        const matchingKey = uncollectedKeys.find(k => k.color === activeSnake.color || k.color === 'gold') || uncollectedKeys[0];
        const pathToKey = this.findPath(head, matchingKey, grid, baseObstacles);
        if (pathToKey && pathToKey.length > 1) {
          return {
            type: 'key',
            nextStep: pathToKey[1],
            path: pathToKey,
            targetCoord: matchingKey,
            message: `Collect the ${matchingKey.color} key first!`
          };
        }
      }

      // Priority 2: Check unpressed switches needed for closed gates or inactive bridges
      const hasClosedGate = (gates || []).some(g => !g.isOpen);
      const hasInactiveBridge = (bridges || []).some(b => !b.active);
      if ((hasClosedGate || hasInactiveBridge) && switches && switches.length > 0) {
        const unpressedSwitch = switches.find(sw => !sw.pressed);
        if (unpressedSwitch) {
          const pathToSwitch = this.findPath(head, unpressedSwitch, grid, baseObstacles);
          if (pathToSwitch && pathToSwitch.length > 1) {
            return {
              type: 'switch',
              nextStep: pathToSwitch[1],
              path: pathToSwitch,
              targetCoord: unpressedSwitch,
              message: 'Step on the ancient pressure switch!'
            };
          }
        }
      }

      // Priority 3: Path directly to exit portal
      const exitPath = this.findPath(head, activeSnake.exit, grid, baseObstacles);
      if (exitPath && exitPath.length > 1) {
        return {
          type: 'exit',
          nextStep: exitPath[1],
          path: exitPath,
          targetCoord: activeSnake.exit,
          message: 'Follow the glowing trail to the exit!'
        };
      }

      // Priority 4: Check teleport portals if exit is unreachable directly
      if (portals && portals.length >= 2) {
        for (const portal of portals) {
          const pathToPortal = this.findPath(head, portal, grid, baseObstacles);
          if (pathToPortal && pathToPortal.length > 1) {
            return {
              type: 'portal',
              nextStep: pathToPortal[1],
              path: pathToPortal,
              targetCoord: portal,
              message: 'Take the teleport portal!'
            };
          }
        }
      }

      // Priority 5: Active snake is blocked! Find another snake that CAN move
      for (const otherSnake of snakes) {
        if (otherSnake.id === activeSnake.id || otherSnake.escaped) continue;
        const otherHead = otherSnake.getHead();
        const otherExitPath = this.findPath(otherHead, otherSnake.exit, grid, baseObstacles);
        if (otherExitPath && otherExitPath.length > 1) {
          return {
            type: 'select_snake',
            targetSnakeId: otherSnake.id,
            nextStep: otherExitPath[1],
            path: otherExitPath,
            message: `Switch to ${otherSnake.color} snake first!`
          };
        }
      }

      return null;
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.pathfinding = new PathfindingSolver();
})();
