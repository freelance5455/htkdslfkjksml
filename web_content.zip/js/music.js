/* يمكن هدف؟ — calm sports studio music, generated live with Web Audio (no files, no licences) */
(function () {
  let ctx = null, master = null, duck = null, timer = 0, step = 0, nextT = 0, on = false;
  const BPM = 92, SPB = 60 / BPM / 4; // 16th note length
  // A minor feel: Am – F – C – G (two bars each)
  const CH = [[57, 60, 64], [53, 57, 60], [48, 55, 60], [55, 59, 62]];
  const BASS = [45, 41, 36, 43];
  const ARP = [0, 1, 2, 1, 2, 0, 1, 2];
  const f = m => 440 * Math.pow(2, (m - 69) / 12);

  function init() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0;
    duck = ctx.createGain(); duck.gain.value = 1;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 3;
    // soft room reverb
    const conv = ctx.createConvolver(); const len = ctx.sampleRate * 2.2; const ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    conv.buffer = ir; const wet = ctx.createGain(); wet.gain.value = 0.28;
    duck.connect(comp); duck.connect(conv); conv.connect(wet); wet.connect(comp); comp.connect(master); master.connect(ctx.destination);
  }
  function env(g, t, a, peak, d) { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + d); }
  function pad(notes, t, dur) {
    notes.forEach(n => [-6, 6].forEach(det => {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f(n); o.detune.value = det;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; lp.Q.value = 0.3;
      const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.018, t + 0.9); g.gain.linearRampToValueAtTime(0.014, t + dur - 0.4); g.gain.linearRampToValueAtTime(0.0001, t + dur + 0.6);
      o.connect(lp); lp.connect(g); g.connect(duck); o.start(t); o.stop(t + dur + 0.7);
    }));
  }
  function pluck(n, t, v = 0.05) {
    const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = f(n);
    const g = ctx.createGain(); env(g, t, 0.005, v, 0.32);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2400;
    o.connect(lp); lp.connect(g); g.connect(duck); o.start(t); o.stop(t + 0.4);
  }
  function bass(n, t, d) {
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f(n);
    const g = ctx.createGain(); env(g, t, 0.01, 0.12, d);
    o.connect(g); g.connect(duck); o.start(t); o.stop(t + d + 0.05);
  }
  function kick(t) {
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(120, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.18);
    const g = ctx.createGain(); env(g, t, 0.003, 0.22, 0.28); o.connect(g); g.connect(duck); o.start(t); o.stop(t + 0.32);
  }
  let noiseBuf = null;
  function hat(t, v) {
    if (!noiseBuf) { noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.1, ctx.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 7000;
    const g = ctx.createGain(); env(g, t, 0.002, v, 0.05); s.connect(hp); hp.connect(g); g.connect(duck); s.start(t); s.stop(t + 0.08);
  }
  function schedule() {
    while (nextT < ctx.currentTime + 0.25) {
      const bar = Math.floor(step / 16), s16 = step % 16, ci = Math.floor(bar / 2) % 4, t = nextT;
      if (s16 === 0 && bar % 2 === 0) pad(CH[ci], t, SPB * 32);
      if (s16 === 0 || s16 === 10) bass(BASS[ci], t, SPB * 5);
      if (s16 === 0 || s16 === 8) kick(t);
      if (s16 % 2 === 0) hat(t, s16 % 4 === 2 ? 0.035 : 0.014);
      if (s16 % 2 === 0 && bar % 4 !== 3) pluck(CH[ci][ARP[(s16 / 2) % 8]] + 12, t, 0.035);
      nextT += SPB; step++;
    }
  }
  const music = {
    get on() { return on; },
    start() {
      init(); if (!ctx) return; if (ctx.state === 'suspended') ctx.resume();
      if (on) return; on = true; nextT = ctx.currentTime + 0.1; step = 0;
      master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setValueAtTime(master.gain.value, ctx.currentTime); master.gain.linearRampToValueAtTime(0.55, ctx.currentTime + 2.5);
      clearInterval(timer); timer = setInterval(schedule, 60); schedule();
    },
    stop() {
      if (!ctx || !on) return; on = false;
      master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setValueAtTime(master.gain.value, ctx.currentTime); master.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.8);
      setTimeout(() => { if (!on) clearInterval(timer); }, 900);
    },
    duck(d) { if (!ctx) return; duck.gain.cancelScheduledValues(ctx.currentTime); duck.gain.setTargetAtTime(d ? 0.35 : 1, ctx.currentTime, 0.25); },
  };
  YH.music = music;
})();
