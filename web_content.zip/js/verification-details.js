// ==========================================
// NetEarn Pro
// PREMIUM VERIFICATION DETAILS
// FINAL STABLE VERSION
// ==========================================

import { db } from "./firebase.js";
import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// ==========================================
// CONFIG
// ==========================================

const DEFAULT_VERIFICATION_FEE = null;

const PAYMENT_PAGE =
    "subscription-payment.html";


// ==========================================
// DOM ELEMENTS
// ==========================================

const feeDisplay =
    document.getElementById(
        "verificationFeeDisplay"
    );

const stepFeeDisplay =
    document.getElementById(
        "stepFeeDisplay"
    );

const termsCheckbox =
    document.getElementById(
        "termsCheckbox"
    );

const continueButton =
    document.querySelector(
        ".continue-btn"
    );


// ==========================================
// FORMAT MONEY
// ==========================================

function formatFee(amount) {

    const value =
        Number(amount);

    if (
        !Number.isFinite(value) ||
        value < 0
    ) {

        return (
            "—"
        );

    }

    return (
        "৳" +
        value.toLocaleString(
            "en-US"
        )
    );
}


// ==========================================
// UPDATE FEE DISPLAY
// ==========================================

function updateFeeDisplay(fee) {

    const formatted =
        formatFee(fee);


    if (feeDisplay) {

        feeDisplay.textContent =
            formatted;

    }


    if (stepFeeDisplay) {

        stepFeeDisplay.textContent =
            formatted;

    }

}


// ==========================================
// LOAD VERIFICATION FEE
// ==========================================

async function loadVerificationFee() {

    try {

        const settingsSnap =
            await getDoc(doc(db, "settings", "main"));

        if (!settingsSnap.exists()) {
            updateFeeDisplay(null);
            return;
        }

        const premiumFee = Number(
            settingsSnap.data()?.premiumFee
        );

        if (Number.isFinite(premiumFee) && premiumFee >= 0) {
            updateFeeDisplay(premiumFee);
            return;
        }

        updateFeeDisplay(null);

    } catch (error) {

        console.error(
            "❌ Verification fee load failed:",
            error
        );

        updateFeeDisplay(null);

    }

}

// ==========================================
// CONTINUE TO VERIFICATION
// ==========================================

async function goToVerification() {

    if (!termsCheckbox || !termsCheckbox.checked) {

        await alert(
            "Please agree to the Terms & Conditions first."
        );

        return;

    }

    window.location.href = PAYMENT_PAGE;

}

// ==========================================
// BUTTON EVENT
// ==========================================

if (continueButton) {

    continueButton.addEventListener(
        "click",
        goToVerification
    );

}


// ==========================================
// TERMS CHECKBOX
// ==========================================

if (termsCheckbox) {

    termsCheckbox.addEventListener(
        "change",
        () => {

            if (
                termsCheckbox.checked
            ) {

                continueButton?.classList.add(
                    "terms-accepted"
                );

            }
            else {

                continueButton?.classList.remove(
                    "terms-accepted"
                );

            }

        }
    );

}


// ==========================================
// INITIALIZE
// ==========================================

loadVerificationFee();