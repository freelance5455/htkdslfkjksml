(function(){
  "use strict";
  const KEY="HET_DB_V1";
  const defaults={
    settings:{business_name:"Hadi Engine Tuning",currency_label:"تومان",invoice_prefix:"HE",default_discount_type:"amount",default_discount_value:""},
    vehicles:[],
    services:[],
    operations:[],
    invoices:[]
  };
  function load(){
    try{
      const raw=localStorage.getItem(KEY);
      if(!raw) return structuredClone(defaults);
      const d=JSON.parse(raw);
      return Object.assign(structuredClone(defaults),d);
    }catch(e){ return structuredClone(defaults); }
  }
  let db=load();
  function save(){ localStorage.setItem(KEY,JSON.stringify(db)); }
  function uid(p){return (p||"id")+"_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,7);}
  function clone(x){return JSON.parse(JSON.stringify(x));}
  window.DB={
    get(){return clone(db)},
    save(){save()},
    uid,
    settings(){return db.settings},
    setSettings(x){db.settings=Object.assign({},db.settings,x);save()},
    vehicles(){return db.vehicles.filter(x=>x.enabled!==false).sort((a,b)=>a.name.localeCompare(b.name))},
    allVehicles(){return db.vehicles.slice().sort((a,b)=>a.name.localeCompare(b.name))},
    addVehicle(x){const v=Object.assign({id:uid("veh"),enabled:true,tier:"other"},x);db.vehicles.push(v);save();return v},
    updateVehicle(id,x){const v=db.vehicles.find(x=>x.id===id);if(v)Object.assign(v,x);save()},
    deleteVehicle(id){db.vehicles=db.vehicles.filter(x=>x.id!==id);save()},
    services(){return db.services.filter(x=>x.enabled!==false).sort((a,b)=>(a.order||0)-(b.order||0))},
    allServices(){return db.services.slice().sort((a,b)=>(a.order||0)-(b.order||0))},
    addService(x){const max=db.services.reduce((m,s)=>Math.max(m,s.order||0),0);const s=Object.assign({id:uid("svc"),enabled:true,order:max+1},x);db.services.push(s);save();return s},
    updateService(id,x){const s=db.services.find(x=>x.id===id);if(s)Object.assign(s,x);save()},
    deleteService(id){db.services=db.services.filter(x=>x.id!==id);db.operations=db.operations.filter(x=>x.service_id!==id);save()},
    reorderService(id,dir){const a=db.services.slice().sort((x,y)=>(x.order||0)-(y.order||0));const i=a.findIndex(x=>x.id===id),j=i+dir;if(i<0||j<0||j>=a.length)return;[a[i].order,a[j].order]=[a[j].order,a[i].order];save()},
    operations(serviceId){return db.operations.filter(x=>x.service_id===serviceId&&x.enabled!==false).sort((a,b)=>(a.order||0)-(b.order||0))},
    allOperations(serviceId){return db.operations.filter(x=>!serviceId||x.service_id===serviceId).sort((a,b)=>(a.order||0)-(b.order||0))},
    addOperation(x){const max=db.operations.filter(o=>o.service_id===x.service_id).reduce((m,o)=>Math.max(m,o.order||0),0);const o=Object.assign({id:uid("op"),enabled:true,order:max+1,prices:{saipa:0,irankhodro:0,other:0}},x);db.operations.push(o);save();return o},
    updateOperation(id,x){const o=db.operations.find(x=>x.id===id);if(o)Object.assign(o,x);save()},
    deleteOperation(id){db.operations=db.operations.filter(x=>x.id!==id);save()},
    reorderOperation(id,dir){const o=db.operations.find(x=>x.id===id);if(!o)return;const a=db.operations.filter(x=>x.service_id===o.service_id).sort((x,y)=>(x.order||0)-(y.order||0));const i=a.findIndex(x=>x.id===id),j=i+dir;if(j<0||j>=a.length)return;[a[i].order,a[j].order]=[a[j].order,a[i].order];save()},
    addInvoice(x){const i=Object.assign({id:uid("inv"),created_at:new Date().toISOString()},x);db.invoices.push(i);save();return i},
    invoices(){return db.invoices.slice().sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at)))},
    deleteInvoice(id){db.invoices=db.invoices.filter(x=>x.id!==id);save()},
    export(){return JSON.stringify(db,null,2)},
    import(s){const x=JSON.parse(s);if(!x.settings||!Array.isArray(x.vehicles)||!Array.isArray(x.services)||!Array.isArray(x.operations)||!Array.isArray(x.invoices))throw Error("Invalid backup");db=x;save()}
  };
})();