const DB_NAME="calisten-db",STORE="app";
let db;
export async function openDB(){if(db)return db;db=await new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});return db}
export async function idbGet(key){const d=await openDB();return new Promise((res,rej)=>{const r=d.transaction(STORE,"readonly").objectStore(STORE).get(key);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
export async function idbSet(key,value){const d=await openDB();return new Promise((res,rej)=>{const r=d.transaction(STORE,"readwrite").objectStore(STORE).put(value,key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
export async function idbClear(){const d=await openDB();return new Promise((res,rej)=>{const r=d.transaction(STORE,"readwrite").objectStore(STORE).clear();r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}