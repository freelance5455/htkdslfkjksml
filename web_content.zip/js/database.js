const DB={
  name:"HesabAsanDB",version:2,db:null,
  open(){return new Promise((res,rej)=>{const r=indexedDB.open(this.name,this.version);r.onupgradeneeded=e=>{const d=e.target.result;for(const s of ["members","expenses","food","settings"])if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:s==="settings"?"key":"id",autoIncrement:s!=="settings"});};r.onsuccess=()=>{this.db=r.result;res()};r.onerror=()=>rej(r.error)})},
  all(s){return new Promise((res,rej)=>{const r=this.db.transaction(s).objectStore(s).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})},
  get(s,k){return new Promise((res,rej)=>{const r=this.db.transaction(s).objectStore(s).get(k);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})},
  add(s,o){return new Promise((res,rej)=>{const r=this.db.transaction(s,"readwrite").objectStore(s).add(o);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})},
  put(s,o){return new Promise((res,rej)=>{const r=this.db.transaction(s,"readwrite").objectStore(s).put(o);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})},
  del(s,k){return new Promise((res,rej)=>{const r=this.db.transaction(s,"readwrite").objectStore(s).delete(k);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})},
  clear(s){return new Promise((res,rej)=>{const r=this.db.transaction(s,"readwrite").objectStore(s).clear();r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
};