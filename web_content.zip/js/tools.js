(function () {
  "use strict";

  function getLines() {
    const ta = window.Editor.getTextarea();
    const val = ta.value;
    const start = ta.selectionStart;
    const before = val.slice(0, start);
    const lineStart = before.lastIndexOf("\n") + 1;
    let lineEnd = val.indexOf("\n", start);
    if (lineEnd === -1) lineEnd = val.length;
    return { val, start, lineStart, lineEnd, line: val.slice(lineStart, lineEnd) };
  }

  function replaceRange(start, end, text) {
    const ta = window.Editor.getTextarea();
    ta.value = ta.value.slice(0, start) + text + ta.value.slice(end);
    ta.selectionStart = ta.selectionEnd = start + text.length;
    window.Editor.render();
  }

  function duplicateLine() {
    const { val, lineStart, lineEnd, line } = getLines();
    replaceRange(lineEnd, lineEnd, "\n" + line);
  }

  function deleteLine() {
    const { val, lineStart, lineEnd } = getLines();
    let end = lineEnd;
    if (val[lineEnd] === "\n") end++;
    replaceRange(lineStart, end, "");
  }

  function moveLine(dir) {
    const ta = window.Editor.getTextarea();
    const val = ta.value;
    const lines = val.split("\n");
    const pos = ta.selectionStart;
    const before = val.slice(0, pos);
    const idx = before.split("\n").length - 1;
    if (dir === -1 && idx > 0) {
      const tmp = lines[idx - 1];
      lines[idx - 1] = lines[idx];
      lines[idx] = tmp;
      ta.value = lines.join("\n");
      ta.selectionStart = ta.selectionEnd = pos - lines[idx].length - 1;
    } else if (dir === 1 && idx < lines.length - 1) {
      const tmp = lines[idx + 1];
      lines[idx + 1] = lines[idx];
      lines[idx] = tmp;
      ta.value = lines.join("\n");
      ta.selectionStart = ta.selectionEnd = pos + lines[idx].length + 1;
    }
    window.Editor.render();
  }

  function copyLine() {
    const { line } = getLines();
    if (navigator.clipboard) navigator.clipboard.writeText(line).catch(() => {});
  }

  function formatCode() {
    const ta = window.Editor.getTextarea();
    let code = ta.value;
    const lang = (document.getElementById("status-lang").textContent || "").toLowerCase();

    if (lang === "json") {
      try { code = JSON.stringify(JSON.parse(code), null, 2); } catch (e) {}
    } else if (lang === "html" || lang === "xml") {
      code = formatHTML(code);
    } else if (lang === "css") {
      code = formatCSS(code);
    } else if (lang === "js") {
      code = formatJS(code);
    }
    ta.value = code;
    window.Editor.render();
  }

  function formatHTML(code) {
    const tokens = code.replace(/>\s*</g, ">\n<").split("\n");
    let indent = 0;
    return tokens.map((line) => {
      const t = line.trim();
      if (/^<\//.test(t)) indent = Math.max(0, indent - 1);
      const out = "  ".repeat(indent) + t;
      if (/^<[^/!][^>]*[^/]>$/.test(t) && !/^<(br|hr|img|input|meta|link)/i.test(t)) indent++;
      return out;
    }).join("\n");
  }

  function formatCSS(code) {
    return code
      .replace(/\s*{\s*/g, " {\n  ")
      .replace(/;\s*/g, ";\n  ")
      .replace(/\s*}\s*/g, "\n}\n")
      .replace(/\n\s*\n/g, "\n")
      .trim();
  }

  function formatJS(code) {
    let indent = 0;
    return code.split("\n").map((line) => {
      const t = line.trim();
      if (/^[}\])]/.test(t)) indent = Math.max(0, indent - 1);
      const out = "  ".repeat(indent) + t;
      if (/[{[(]$/.test(t)) indent++;
      return out;
    }).join("\n");
  }

  function gotoLine(n) {
    const ta = window.Editor.getTextarea();
    const lines = ta.value.split("\n");
    n = Math.max(1, Math.min(n, lines.length));
    let pos = 0;
    for (let i = 0; i < n - 1; i++) pos += lines[i].length + 1;
    window.Editor.setSelection(pos, pos);
    const lineH = parseFloat(getComputedStyle(ta).lineHeight) || 20;
    document.getElementById("editor-scroll").scrollTop = (n - 1) * lineH - 100;
  }

  /* Find & Replace */
  let matches = [];
  let matchIdx = -1;

  function buildRegex() {
    const text = document.getElementById("find-text").value;
    if (!text) return null;
    const isRegex = document.getElementById("find-regex").checked;
    const isCase = document.getElementById("find-case").checked;
    try {
      return new RegExp(isRegex ? text : text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), isCase ? "g" : "gi");
    } catch (e) { return null; }
  }

  function find() {
    const ta = window.Editor.getTextarea();
    const re = buildRegex();
    matches = [];
    matchIdx = -1;
    if (!re) { document.getElementById("find-count").textContent = "0"; return; }
    let m;
    while ((m = re.exec(ta.value)) !== null) {
      matches.push({ start: m.index, end: m.index + m[0].length });
      if (m.index === re.lastIndex) re.lastIndex++;
    }
    document.getElementById("find-count").textContent = String(matches.length);
    if (matches.length) next();
  }

  function next() {
    if (!matches.length) return;
    matchIdx = (matchIdx + 1) % matches.length;
    const m = matches[matchIdx];
    window.Editor.setSelection(m.start, m.end);
    const ta = window.Editor.getTextarea();
    const lineH = parseFloat(getComputedStyle(ta).lineHeight) || 20;
    const line = ta.value.slice(0, m.start).split("\n").length;
    document.getElementById("editor-scroll").scrollTop = (line - 1) * lineH - 100;
  }

  function prev() {
    if (!matches.length) return;
    matchIdx = (matchIdx - 1 + matches.length) % matches.length;
    const m = matches[matchIdx];
    window.Editor.setSelection(m.start, m.end);
  }

  function replaceOne() {
    if (!matches.length) return;
    const ta = window.Editor.getTextarea();
    const m = matches[matchIdx];
    const replacement = document.getElementById("replace-text").value;
    ta.value = ta.value.slice(0, m.start) + replacement + ta.value.slice(m.end);
    window.Editor.render();
    find();
  }

  function replaceAll() {
    const ta = window.Editor.getTextarea();
    const re = buildRegex();
    if (!re) return;
    const replacement = document.getElementById("replace-text").value;
    ta.value = ta.value.replace(re, replacement);
    window.Editor.render();
    find();
  }

  document.getElementById("tool-dup").addEventListener("click", duplicateLine);
  document.getElementById("tool-del").addEventListener("click", deleteLine);
  document.getElementById("tool-up").addEventListener("click", () => moveLine(-1));
  document.getElementById("tool-down").addEventListener("click", () => moveLine(1));
  document.getElementById("tool-copy").addEventListener("click", copyLine);
  document.getElementById("tool-format").addEventListener("click", formatCode);
  document.getElementById("goto-btn").addEventListener("click", () => {
    const n = parseInt(document.getElementById("goto-line").value, 10);
    if (n > 0) gotoLine(n);
  });
  document.getElementById("find-next").addEventListener("click", next);
  document.getElementById("find-prev").addEventListener("click", prev);
  document.getElementById("find-replace").addEventListener("click", replaceOne);
  document.getElementById("find-replace-all").addEventListener("click", replaceAll);
  document.getElementById("find-text").addEventListener("input", find);

  window.Tools = { formatCode, gotoLine, find };
})();