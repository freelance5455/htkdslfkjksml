/* painel de ferramentas por baixo da pré-visualização: fonte, espaço, layout, cores (com seletor arrastável e gradiente) */
const SW=['#2d3748','#1b5e55','#6b2a3a','#4e5a45','#5e4d86','#6f93be','#c9a063','#2563eb','#e11d48','#f59e0b','#10b981','#111827'];
let HSV={h:0,s:0,v:0},PD=null;
/* o que cada ferramenta controla: "Repor" só limpa isto, sem tocar nas outras ferramentas nem nas margens do PDF */
const RS={font:['font','fs'],space:['lh','gap'],layout:['shape','flip'],margin:['mt','mb','mx'],color:['primary','primary2','text','paper','grad','ga','ct']},RL={font:'Repor fonte',space:'Repor espaço',layout:'Repor layout',margin:'Repor margens',color:'Repor cores'};
const clamp=x=>Math.max(0,Math.min(1,x));
/* chave da cor em edição (a "Cor 2" só existe com o gradiente ligado) */
const ck=()=>{const k=S.ct||'primary';return k=='primary2'&&!GC()?'primary':k};
const curC=k=>hex6(k=='primary2'?(S.primary2||g2(S.primary||def('primary'))):(S[k]||def(k)));
function panel(){const p=$('#panel'),t=S.tool||'';p.hidden=!t;document.querySelectorAll('#bar button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));if(!t||!TP[T])return;
const Rg=(k,l,mn,mx,st,v)=>`<label>${l}: <output>${v}</output><input type="range" data-s="${k}" min="${mn}" max="${mx}" step="${st}" value="${v}"></label>`;let h='';
if(t=='font')h=`<label>Fonte<select data-s="font"><option value="">Padrão do modelo</option>${Object.keys(FM).map(n=>`<option${S.font==n?' selected':''}>${n}</option>`).join('')}</select></label>`+Rg('fs','Tamanho (pt)',8,13,.5,S.fs??parseFloat(def('fs')));
else if(t=='space')h=Rg('lh','Entrelinha',1.1,2,.05,S.lh??parseFloat(def('lh')))+Rg('gap','Espaço entre secções (px)',4,40,2,S.gap??parseFloat(def('gap')));
else if(t=='margin')h=Rg('mt','Margem superior (mm, páginas 2+)',10,40,1,Math.max(10,S.mt??18))+Rg('mb','Margem inferior (mm)',10,40,1,Math.max(10,S.mb??18))+Rg('mx','Margens laterais (mm, extra)',0,20,1,S.mx??0);
else if(t=='layout'){const m=MAN.find(x=>x.id==T)||{};h=(D.photo||m.slot?'<div class="seg">Foto: '+[['50%','Círculo'],['12%','Arredondada'],['0','Quadrada']].map(([v,n])=>`<button type="button" data-sh="${v}"${(S.shape??'50%')==v?' class="on"':''}>${n}</button>`).join('')+'</div>':'')+(m.flip?'<div class="seg">Barra lateral: '+[['','Padrão'],['1','Invertida']].map(([v,n])=>`<button type="button" data-fl="${v}"${(S.flip?'1':'')==v?' class="on"':''}>${n}</button>`).join('')+'</div>':'')}
else{const m=MAN.find(x=>x.id==T)||{},gr=!!m.gradient,on=GC(),k=ck(),cv=curC(k);HSV=h2v(cv);
const tabs=[['primary','Principal'],...(on?[['primary2','Cor 2']]:[]),['text','Texto'],['paper','Fundo']];
h=`<div class="seg3">${tabs.map(([q,n])=>`<button type="button" data-ct="${q}"${k==q?' class="on"':''}>${n}</button>`).join('')}</div>`
+`<div class="sw">${SW.map(c=>`<i data-sw="${c}"${c==cv?' class="sel"':''} style="background:${c}"></i>`).join('')}<i class="rb${SW.includes(cv)?'':' sel'}" data-rb title="Personalizada"></i></div>`
+`<div class="pk"><div class="sv" id="sv"><i id="svd"></i></div><div class="hue" id="hue"><i id="hud"></i></div></div>`
+`<div class="hexrow"><i id="cpv"></i><input id="hx" data-s="hex" value="${cv}" maxlength="7" spellcheck="false" autocapitalize="off" autocomplete="off"></div>`
+(gr?`<label class="tgl"><input type="checkbox" data-s="grad"${S.grad?' checked':''}><span class="sw-t"></span><b>Gradiente</b><small>${on?'ligado':'neste modelo'}</small></label>`:'')
+(on?Rg('ga','Direção do gradiente (°)',0,360,15,S.ga??135):'')}
p.innerHTML=h+'<button type="button" data-reset="1">'+(RL[t]||'Repor')+'</button>';if(t=='color')syncPk()}
/* atualiza o ponto, a barra de tons, a pré-visualização e o campo hex sem refazer o painel (para o arrasto ser fluido) */
function syncPk(skipHex){const sv=$('#sv');if(!sv)return;const c=v2h(HSV);
sv.style.setProperty('--hue',HSV.h);$('#svd').style.cssText=`left:${HSV.s*100}%;top:${(1-HSV.v)*100}%`;$('#hud').style.top=HSV.h/360*100+'%';$("#cpv").style.background=c;if(!skipHex)$('#hx').value=c;
document.querySelectorAll('#panel [data-sw]').forEach(i=>i.classList.toggle('sel',i.dataset.sw==c));const rb=$('#panel .rb');if(rb)rb.classList.toggle('sel',!SW.includes(c))}
function move(e){const a=PD,r=a.getBoundingClientRect(),x=clamp((e.clientX-r.left)/r.width),y=clamp((e.clientY-r.top)/r.height);
if(a.id=='sv'){HSV.s=x;HSV.v=1-y}else HSV.h=y*360;S[ck()]=v2h(HSV);syncPk();theme()}
const P=$('#panel');
P.addEventListener('pointerdown',e=>{const a=e.target.closest('#sv,#hue');if(!a)return;e.preventDefault();PD=a;try{a.setPointerCapture(e.pointerId)}catch{}move(e)});
P.addEventListener('pointermove',e=>{if(PD)move(e)});
for(const n of['pointerup','pointercancel'])P.addEventListener(n,()=>{if(PD){PD=null;save()}});
P.oninput=e=>{const t=e.target,k=t.dataset.s;if(!k)return;const v=t.value;
if(k=='grad'){S.grad=t.checked;panel();theme();save();return}
if(k=='hex'){const x=v.startsWith('#')?v:'#'+v;if(!/^#[0-9a-f]{6}$/i.test(x))return;S[ck()]=x.toLowerCase();HSV=h2v(x);syncPk(true)}
else{S[k]=t.type=='range'?+v:v;const o=t.parentNode.querySelector('output');if(o)o.value=v}theme();save()};
P.onclick=e=>{const b=e.target.closest('button,i');if(!b)return;const d=b.dataset;
if(d.rb!==undefined){$('#hx').focus();return}
if(d.ct)S.ct=d.ct;else if(d.sw)S[ck()]=d.sw;else if(d.sh!==undefined)S.shape=d.sh;else if(d.fl!==undefined){if(d.fl)S.flip='1';else delete S.flip}else if(d.reset){for(const k of RS[S.tool]||[])delete S[k]}else return;panel();theme();save()};
document.querySelectorAll('#bar button').forEach(b=>b.onclick=()=>{S.tool=S.tool==b.dataset.t?'':b.dataset.t;panel();save();setTimeout(fit,0)});

/* Regra do botão Layout: só aparece quando há algo a ajustar (foto adicionada e/ou modelo com barra lateral invertível) */
function toolVis(){const m=MAN.find(x=>x.id==T)||{},ok=!!D.photo||!!m.slot||!!m.flip,b=document.querySelector('#bar [data-t=layout]');if(b)b.hidden=!ok;if(!ok&&S.tool=='layout'){S.tool='';panel()}}
