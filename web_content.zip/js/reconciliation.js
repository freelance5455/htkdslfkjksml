window.WS_RECON={
  weekBounds(date=new Date()){
    const d=(date.getDay()+6)%7,s=new Date(date);s.setDate(date.getDate()-d);s.setHours(0,0,0,0);
    const e=new Date(s);e.setDate(s.getDate()+6);e.setHours(23,59,59,999);return [s,e];
  },
  expected(operations,from,to,agentId=null){
    return operations.filter(o=>!o.deleted&&(!agentId||o.agentId===agentId)&&o.type==='Recette'&&o.payment!=='Crédit'&&new Date(o.date||o.createdAt)>=from&&new Date(o.date||o.createdAt)<=to).reduce((n,o)=>n+Number(o.total||0),0);
  },
  snapshot(operations,handovers,from,to,agentId=null){
    const relevant=operations.filter(o=>!o.deleted&&(!agentId||o.agentId===agentId)&&new Date(o.date||o.createdAt)>=from&&new Date(o.date||o.createdAt)<=to);
    const expected=this.expected(operations,from,to,agentId);
    const hand=handovers.filter(h=>h.weekStart===from.toISOString().slice(0,10)&&h.weekEnd===to.toISOString().slice(0,10)&&(!agentId||h.handedOverBy===agentId));
    const handed=hand.reduce((n,h)=>n+Number(h.amountHanded||0),0);
    return {operations:relevant,expected,handed,difference:handed-expected,handovers:hand};
  }
};
