/* جنة القرآن v6 — مركز التذكيرات والآية اليومية المخصّصة */
'use strict';
const RD={wird:{on:false,t:'20:00'},am:{on:false,t:'06:30'},pm:{on:false,t:'17:30'},ayah:{on:false,t:'08:00'},pre:{on:false,m:10},day:{src:'all',s:1}};
const REM=()=>{const o=ls.get('rem',{}),r={};Object.keys(RD).forEach(k=>r[k]=Object.assign({},RD[k],o[k]||{}));return r};
const rset=(k,f)=>{const R=REM();f(R[k]);ls.set('rem',R);scheduleTriggers()};
const FIRED=ls.get('rfired',{});
async function reminders(){enter('more');const R=REM(),perm=typeof Notification!='undefined'?Notification.permission:'unsupported';
  const tm=(k,l)=>`<div class="card"><label class="lb" style="display:flex;justify-content:space-between;align-items:center"><span><input type="checkbox" ${R[k].on?'checked':''} onchange="rset('${k}',o=>o.on=this.checked)"> ${l}</span><input type="time" class="in" style="width:120px;margin:0" value="${R[k].t}" onchange="rset('${k}',o=>o.t=this.value)"></label></div>`;
  v.innerHTML=head('🔔 مركز التذكيرات')+`<div class="card"><b>الإذن بالإشعارات:</b> ${perm=='granted'?'✅ مفعّل':perm=='denied'?'⛔ محظور من إعدادات المتصفح':perm=='unsupported'?'غير مدعوم':'لم يُطلب بعد'}${perm=='default'?'<button class="b w" onclick="reqPerm()">تفعيل الإشعارات</button>':''}<button class="o w" onclick="notify(\'جنة القرآن\',\'هذا إشعار تجريبي ✅\',\'test\').then(ok=>toast(ok?\'أُرسل الإشعار\':\'تعذّر الإرسال، فعّل الإذن\'))">🔔 إشعار تجريبي</button></div>
  ${tm('wird','📖 تذكير بالورد اليومي')}${tm('am','🌅 أذكار الصباح')}${tm('pm','🌇 أذكار المساء')}${tm('ayah','⭐ آية اليوم')}
  <div class="card"><label class="lb" style="display:flex;justify-content:space-between;align-items:center"><span><input type="checkbox" ${R.pre.on?'checked':''} onchange="rset('pre',o=>o.on=this.checked)"> 🕌 تنبيه قبل الصلاة</span><select onchange="rset('pre',o=>o.m=+this.value)">${[5,10,15,20,30].map(m=>`<option value="${m}" ${m==R.pre.m?'selected':''}>${AR(m)} دقيقة</option>`).join('')}</select></label><div class="sub">يحتاج تحديد المدينة في صفحة الصلاة.</div>
  <button class="o w" onclick="go('prayer')">🕌 أوقات الصلاة والآذان</button></div>
  <div class="card"><b>⭐ مصدر آية اليوم</b><select id="dsrc" class="w" onchange="rset('day',o=>o.src=this.value);reminders()"><option value="all" ${R.day.src=='all'?'selected':''}>كل القرآن</option><option value="favs" ${R.day.src=='favs'?'selected':''}>من مفضلتي</option><option value="bm" ${R.day.src=='bm'?'selected':''}>من علاماتي</option><option value="nt" ${R.day.src=='nt'?'selected':''}>من ملاحظاتي</option><option value="surah" ${R.day.src=='surah'?'selected':''}>من سورة محددة</option></select>${R.day.src=='surah'?`<select class="w" onchange="rset('day',o=>o.s=+this.value)">${surahOpts(R.day.s)}</select>`:''}</div>
  <div class="sub">⚠️ التنبيهات تصل بدقة عندما يكون التطبيق مفتوحًا أو يعمل في الخلفية. إغلاق التطبيق أو توفير البطارية قد يمنعها على بعض الأجهزة؛ لضمانها بالكامل لاحقًا نحتاج خادم إشعارات.</div>`}
async function reqPerm(){try{await Notification.requestPermission()}catch(e){}reminders();scheduleTriggers()}
async function dailyKey(){const R=REM().day,d=td(),ov=ls.get('dayov');if(ov&&ov.d==d)return ov.k;const L=lib().it;let c=[];
  if(R.src=='favs')c=S.favs;else if(R.src=='bm')c=Object.keys(L).filter(k=>L[k].bm);else if(R.src=='nt')c=Object.keys(L).filter(k=>L[k].nt||L[k].td);
  else if(R.src=='surah'){await names();c=Array.from({length:S.cnt[R.s-1]},(_,i)=>R.s+':'+(i+1))}
  const n=dayN(d);if(c.length)return c[(n*7919)%c.length];const g=(Math.floor(Date.now()/864e5)*7919)%6236+1;await names();const o=offs();let s=1;while(o[s]<g)s++;return s+':'+(g-o[s-1])}
daily=async function(){try{const k=await dailyKey(),[s,a]=KP(k),el=$('#ayd');if(!el)return;const t=await ayahT(s,a);
  el.innerHTML=`<div class="card" onclick="openS(${s},${a})"><b>⭐ آية اليوم</b> · ${esc(nm(s))} ${AR(a)}<div class="qt sm">${esc(t)}</div></div><div class="row"><button class="o" onclick="dayRnd()">🔀 آية أخرى</button><button class="o" onclick="reminders()">⚙️ تخصيص</button></div>`}catch(e){}};
async function dayRnd(){await names();const g=Math.floor(Math.random()*6236)+1,o=offs();let s=1;while(o[s]<g)s++;ls.set('dayov',{d:td(),k:s+':'+(g-o[s-1])});daily()}
/* حلقة التذكير داخل التطبيق */
const hm=()=>{const n=new Date();return z2(n.getHours())+':'+z2(n.getMinutes())};
async function fireR(id,title,body,hash){const k=td()+id;if(FIRED[k])return;FIRED[k]=1;ls.set('rfired',Object.fromEntries(Object.entries(FIRED).filter(x=>x[0].startsWith(td()))));if(!(await notify(title,body,id,hash)))toast('🔔 '+title+' — '+body)}
async function remTick(){try{const R=REM(),t=hm(),d=td();
  if(R.wird.on&&t>=R.wird.t&&t<addMin(R.wird.t,5)){const L=ls.get('log',{})[d]||{};if(!(L.wd>0)){const P=ls.get('plan');await fireR('wird','📖 وردك اليوم',P?'صفحة '+AR(P.done+1)+' ← '+AR(Math.min(604,P.done+Math.ceil(604/P.days))):'اقرأ وردك من القرآن اليوم','#wird')}}
  if(R.am.on&&t>=R.am.t&&t<addMin(R.am.t,5))await fireR('am','🌅 أذكار الصباح','أصبحنا وأصبح الملك لله… ابدأ يومك بالذكر','#azkar');
  if(R.pm.on&&t>=R.pm.t&&t<addMin(R.pm.t,5))await fireR('pm','🌇 أذكار المساء','أمسينا وأمسى الملك لله… اختم يومك بالذكر','#azkar');
  if(R.ayah.on&&t>=R.ayah.t&&t<addMin(R.ayah.t,5)&&!FIRED[d+'ayah']){const k=await dailyKey(),[s,a]=KP(k);await fireR('ayah','⭐ آية اليوم',snip(await ayahT(s,a),140)+' ﴿'+AR(a)+'﴾ — '+nm(s),'#ayah')}
  if(R.pre.on){const L=ls.get('loc');if(L){const T=await ptoday(L),n=tzNow(L.tz);for(const p of PR){if(p[0]=='Sunrise')continue;const[h,m]=T[p[0]].split(':'),s=h*3600+m*60,diff=s-n.sec;if(diff>0&&diff<=R.pre.m*60&&diff>(R.pre.m*60-90))await fireR('pre'+p[0],'🕌 اقتربت صلاة '+p[1],'بقي نحو '+AR(R.pre.m)+' دقائق على أذان '+p[1],'#prayer')}}}}catch(e){}}
function addMin(t,m){const[h,n]=t.split(':').map(Number),x=h*60+n+m;return z2(Math.floor(x/60)%24)+':'+z2(x%60)}
setInterval(remTick,20000);setTimeout(remTick,3000);
/* جدولة اختيارية (إن دعمها المتصفح) */
async function scheduleTriggers(){try{if(!window.TimestampTrigger||Notification.permission!='granted')return;const reg=await navigator.serviceWorker.getRegistration();if(!reg)return;
  (await reg.getNotifications({includeTriggered:false})).filter(n=>String(n.tag).startsWith('sch-')).forEach(n=>n.close());const R=REM();
  const at=(t,off)=>{const[h,m]=t.split(':').map(Number),d=new Date();d.setDate(d.getDate()+off);d.setHours(h,m,0,0);return d.getTime()};
  const items=[['wird','📖 وردك اليوم','حان وقت وردك من القرآن'],['am','🌅 أذكار الصباح','ابدأ يومك بالذكر'],['pm','🌇 أذكار المساء','اختم يومك بالذكر'],['ayah','⭐ آية اليوم','افتح التطبيق لتقرأ آية اليوم']];
  for(const it of items){if(!R[it[0]].on)continue;for(let off=0;off<3;off++){const ts=at(R[it[0]].t,off);if(ts>Date.now())await reg.showNotification(it[1],{body:it[2],tag:'sch-'+it[0]+off,showTrigger:new TimestampTrigger(ts),icon:'icon-192.png',data:{hash:'#'+it[0]}})}}}catch(e){}}
