/* UrbaAlerte — zones à risques (indicatives) : densité pondérée des signalements sur une grille d'environ 500 m */
(function(w){
'use strict';
const STEP=0.0045;
const LV=[null,{n:'Modéré',c:'#fbbf24'},{n:'Élevé',c:'#ff8a3d'},{n:'Critique',c:'#ff4d6d'}];
const R=w.RISK={STEP,LV,
 compute(reports){const now=Date.now(),cells={};
  reports.forEach(r=>{if(r.status==='REJETE')return;const age=(now-r.created)/864e5;const rec=Math.pow(.5,age/14);const sf=(r.status==='RESOLU'||r.status==='CLOS')?.3:(r.status==='EN_ATTENTE'?.8:1);const wt=TYPE(r.type).w*rec*sf;if(wt<.02)return;
   const k=Math.floor(r.lat/STEP)+':'+Math.floor(r.lng/STEP);const c=cells[k]||(cells[k]={key:k,score:0,count:0,sl:0,sg:0,sw:0,by:{}});c.score+=wt;c.count++;c.sl+=r.lat*wt;c.sg+=r.lng*wt;c.sw+=wt;c.by[r.type]=(c.by[r.type]||0)+wt});
  return Object.values(cells).map(c=>{const lvl=c.score>=7?3:c.score>=4?2:c.score>=2?1:0;const dom=Object.keys(c.by).sort((a,b)=>c.by[b]-c.by[a])[0];return {key:c.key,lat:c.sl/c.sw,lng:c.sg/c.sw,score:c.score,count:c.count,lvl,dom,level:lvl?LV[lvl].n:null,color:lvl?LV[lvl].c:null}}).filter(z=>z.lvl).sort((a,b)=>b.score-a.score)},
 at(zones,lat,lng){const k=Math.floor(lat/STEP)+':'+Math.floor(lng/STEP);return zones.find(z=>z.key===k)||null}
};
})(window);
