/* UNKNOWN X V17 phase 3 — detective evidence board, world map/regions, stats, achievements, win effect */
(function(){"use strict";
const V=typeof module!=="undefined"&&module.exports?require("./v17.js"):window.V17;
const RM=["المكتبة","المختبر","القبو","الشرفة","الخزنة","المطبخ"],NM=["سالم","ليلى","كريم","نورة","ياسر","هدى"],DOC=["سجل الدخول","كاميرا المراقبة","رسالة مصوّرة","بصمة على الباب","إيصال إلكتروني"],CN={easy:{n:3,e:2},normal:{n:4,e:3},hard:{n:5,e:4}};
/* ---- Detective case: one testimony contradicts the evidence ---- */
V.verifyCase=p=>{const bad=p.tests.map((t,s)=>p.evidence.some(e=>e.s===s&&e.r!==t.r)?s:-1).filter(s=>s>=0);
 return p.tests.length>=3&&bad.length===1&&bad[0]===p.culprit&&p.evidence.every(e=>p.truth[e.s]===e.r)&&p.tests.every((t,s)=>s===p.culprit?t.r!==p.truth[s]:t.r===p.truth[s])};
V.genCase=(seed,lv)=>{const{n,e}=CN[lv];for(let a=0;a<20;a++){const r=V.rng(seed+a*53),names=V.shuffle(r,NM).slice(0,n),rooms=V.shuffle(r,RM).slice(0,n),truth=V.shuffle(r,[...Array(n).keys()]),culprit=Math.floor(r()*n);
 const tests=truth.map((t,s)=>({r:s===culprit?(t+1+Math.floor(r()*(n-1)))%n:t})),others=V.shuffle(r,[...Array(n).keys()].filter(s=>s!==culprit)).slice(0,e-1),
 evidence=V.shuffle(r,[culprit,...others]).map((s,i)=>({s,r:truth[s],d:DOC[i%DOC.length]})),p={type:"case",lv,seed,names,rooms,truth,tests,evidence,culprit};if(V.verifyCase(p))return p}throw new Error("case generation failed")};
V.linkCase=(p,t,j)=>{const e=p.evidence[j];return e.s!==t?"none":p.tests[t].r!==e.r?"contradiction":"consistent"};
const msg=c=>c.msg?`<p class="v17-msg">${c.msg}</p>`:"";
V.reg("case","لوحة التحقيق: من يكذب؟",{gen:V.genCase,init:()=>({seen:[],sel:-1,found:false}),
 view:(c,h,x)=>{const p=c.p;return `${h}<h2>اربط الشهادات بالأدلة</h2><p>افحص كل دليل، اختر شهادة ثم دليلاً لربطهما، وابحث عن التناقض.</p><h3>الشهادات</h3><div class="v17-col">${p.tests.map((t,i)=>`<button class="btn${c.sel===i?" v17-on":""}" data-v17="tst:${i}">${p.names[i]}: «كنت في ${p.rooms[t.r]}»</button>`).join("")}</div><h3>الأدلة</h3><div class="v17-col">${p.evidence.map((e,j)=>`<button class="btn" data-v17="ev:${j}">${c.seen.includes(j)?`${e.d}: يُظهر أن ${p.names[e.s]} كان في ${p.rooms[e.r]}`:`🔒 افحص دليلاً (${e.d})`}</button>`).join("")}</div>${msg(c)}${c.found?`<p>من الكاذب؟</p><div class="hero-actions">${p.names.map((n,i)=>`<button class="btn" data-v17="ask:${i}">${n}</button>`).join("")}</div>`:""}<div class="hero-actions">${x}</div>`},
 act:(a,i,_,c)=>{i=+i;if(a==="tst"){c.sel=c.sel===i?-1:i;c.msg="";V.api.refresh();return true}
  if(a==="ev"){if(!c.seen.includes(i)){c.seen.push(i);c.msg="تم فحص الدليل"}else if(c.sel<0)c.msg="اختر شهادة أولاً لربطها بهذا الدليل";else{const r=V.linkCase(c.p,c.sel,i);c.msg=r==="none"?"لا صلة بين الدليل وهذه الشهادة":r==="consistent"?"الدليل يؤكد هذه الشهادة":"⚠ تناقض! هذه الشهادة تخالف الدليل";if(r==="contradiction"){c.found=true;V.api.sfx("open")}else V.api.sfx("ok")}V.api.refresh();return true}
  if(a==="ask"){if(i===c.p.culprit)V.api.won();else{c.msg="ليس هو — الكاذب هو من يناقضه دليل";V.api.sfx("bad");V.api.refresh()}return true}return false}});
/* ---- World regions, stats, achievements ---- */
V.REGIONS=[{id:"harbor",name:"الميناء المهجور",icon:"⚓",need:0,types:["cipher","gears"],c:"#6be59a",story:"أقفال صدئة وتروس رافعات قديمة تخفي أول مفتاح."},
 {id:"library",name:"مكتبة الظلال",icon:"📚",need:3,types:["hidden","photo"],c:"#ffd36b",story:"رسائل مخبأة وصورة ممزقة لمدينة لم تعد موجودة."},
 {id:"vault",name:"قبو التحقيق",icon:"🕵️",need:7,types:["case","detective"],c:"#ff6e6e",story:"شهادات متضاربة، وأحدهم يعرف سر X."},
 {id:"tower",name:"برج X",icon:"🗼",need:12,types:["room"],c:"#6bb7ff",story:"الغرفة الأخيرة: طرفية وباب وقطعة تكشف الحقيقة."}];
V.unlocked=n=>V.REGIONS.filter(r=>n>=r.need).map(r=>r.id);
V.stats=s=>{const by={},lv={},d=Object.keys(s.done||{});d.forEach(k=>{const[t,l]=k.split("_");by[t]=(by[t]||0)+1;lv[l]=(lv[l]||0)+1});return{total:d.length,by,lv,types:Object.keys(by).length}};
V.ACH=[{id:"first",t:"أول خطوة",d:"أنجز مرحلة واحدة",xp:10,ok:s=>s.total>=1},{id:"five",t:"محقق مبتدئ",d:"أنجز 5 مراحل",xp:30,ok:s=>s.total>=5},{id:"mix",t:"متعدد المواهب",d:"أنجز 5 أنواع مختلفة",xp:60,ok:s=>s.types>=5},
 {id:"hard",t:"عقل لا يُخدع",d:"أنجز 3 مراحل صعبة",xp:60,ok:s=>(s.lv.hard||0)>=3},{id:"room",t:"هارب من الغرفة",d:"اخرج من غرفة 3D",xp:40,ok:s=>(s.by.room||0)>=1},{id:"twenty",t:"أسطورة X",d:"أنجز 20 مرحلة",xp:100,ok:s=>s.total>=20}];
V.claim=(s,id)=>{const a=V.ACH.find(x=>x.id===id);s.ach=s.ach||{};if(!a||s.ach[id]||!a.ok(V.stats(s)))return 0;s.ach[id]=1;return a.xp};
V.page=()=>{const s=state.v17=V.sanitize(state.v17);const st=V.stats(s),n=st.total,L={easy:"سهل",normal:"متوسط",hard:"صعب"};
 return `<div class="eyebrow">V17 · UNKNOWN X</div><h1>خريطة العالم</h1><p>أنجزت ${n} مرحلة. تُفتح المناطق بالتقدم، وكل مرحلة مولَّدة ومُتحقَّق من حلها.</p><div class="field"><label for="v17lv">الصعوبة</label><select id="v17lv">${Object.keys(L).map(k=>`<option value="${k}">${L[k]}</option>`).join("")}</select></div>
<div class="v17-grid">${V.REGIONS.map(r=>`<div class="v17-card" style="border-color:${r.c}"><h3 style="color:${r.c}">${r.icon} ${r.name}</h3>${n>=r.need?`<small>${r.story}</small><div class="hero-actions">${r.types.map(t=>`<button class="btn" data-v17="new:${t}">${V.TYPES[t]}</button>`).join("")}<button class="btn" data-v17="daily:${r.types[0]}">التحدي اليومي</button></div>`:`<small>🔒 مقفلة: أنجز ${r.need} مراحل (متبقٍ ${r.need-n})</small>`}</div>`).join("")}</div>
<h2>الإحصائيات</h2><p>المراحل: ${n} · سهل ${st.lv.easy||0} · متوسط ${st.lv.normal||0} · صعب ${st.lv.hard||0} · تلميحات: ${state.hintsUsed||0} · XP: ${state.xp}</p><p>${Object.keys(st.by).map(t=>`${V.TYPES[t]||t}: ${st.by[t]}`).join(" · ")||"لا مراحل بعد"}</p>
<h2>الإنجازات</h2><div class="v17-col">${V.ACH.map(a=>`<div class="clue">${s.ach[a.id]?"✅":a.ok(st)?"🎁":"🔒"} <b>${a.t}</b> — ${a.d} (+${a.xp} XP) ${a.ok(st)&&!s.ach[a.id]?`<button class="btn" data-v17="claim:${a.id}">استلام</button>`:""}</div>`).join("")}</div>`};
V.fx=()=>{try{if(matchMedia("(prefers-reduced-motion: reduce)").matches||state.settings.compact)return;const f=document.createElement("div");f.className="v17-fx";f.innerHTML=Array.from({length:16},(_,i)=>`<i style="--a:${i*22.5}deg;--d:${60+i%4*25}px"></i>`).join("");document.body.appendChild(f);setTimeout(()=>f.remove(),1100)}catch(e){}};
if(typeof document!=="undefined")document.addEventListener("click",e=>{const tgt=e.target&&e.target.closest?e.target:(e.target&&e.target.parentElement)||null;const b=tgt&&tgt.closest&&tgt.closest("[data-v17^='claim:']");if(!b)return;state.v17=V.sanitize(state.v17);const xp=V.claim(state.v17,b.dataset.v17.slice(6));if(!xp)return;state.xp+=xp;save();toast(`إنجاز جديد! +${xp} XP`);render("v17")});
})();
