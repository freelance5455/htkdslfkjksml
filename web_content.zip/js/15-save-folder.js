(function () {
  const L = (...a) => ffmL.apply(null, a);
  const FILE = 'FFM26_Save.ffm', DIRNAME = 'FFM26';
  const supported = typeof window.showDirectoryPicker === 'function';
  /* --- tiny IndexedDB key/value for the directory handle --- */
  const idb = (mode, fn) => new Promise((res, rej) => {
    const r = indexedDB.open('ffm26_fs', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onerror = () => rej(r.error);
    r.onsuccess = () => { const tx = r.result.transaction('kv', mode), st = tx.objectStore('kv'), q = fn(st); tx.oncomplete = () => res(q && q.result); tx.onerror = () => rej(tx.error); };
  });
  const getH = () => idb('readonly', s => s.get('dir')).catch(() => null);
  const setH = h => idb('readwrite', s => h ? s.put(h, 'dir') : s.delete('dir')).catch(() => {});
  let dirH = null, pending = null, writing = false, lastOk = 0, lastErr = '';
  async function perm(h, ask) {
    try { let p = await h.queryPermission({ mode: 'readwrite' }); if (p !== 'granted' && ask) p = await h.requestPermission({ mode: 'readwrite' }); return p === 'granted'; } catch (_) { return false; }
  }
  async function writeNow(text) {
    if (!dirH) return;
    if (!(await perm(dirH, false))) { lastErr = 'perm'; return; }
    const sub = await dirH.getDirectoryHandle(DIRNAME, { create: true });
    const fh = await sub.getFileHandle(FILE, { create: true });
    const w = await fh.createWritable(); await w.write(text); await w.close(); lastOk = Date.now(); lastErr = '';
  }
  async function pump() {
    if (writing) return; writing = true;
    try { while (pending != null) { const t = pending; pending = null; try { await writeNow(t); } catch (e) { lastErr = String(e && e.name || e); } await new Promise(r => setTimeout(r, 800)); } } finally { writing = false; ui(); }
  }
  async function readFile() {
    if (!dirH || !(await perm(dirH, false))) return null;
    try { const sub = await dirH.getDirectoryHandle(DIRNAME); const fh = await sub.getFileHandle(FILE); return await (await fh.getFile()).text(); } catch (_) { return null; }
  }
  window.ffmFolder = {
    supported,
    write(text) { if (!dirH) return; pending = text; pump(); },
    async choose() {
      if (!supported) { alert(L('متصفحك لا يدعم اختيار مجلد. استخدم متصفح Chrome (أندرويد أو كمبيوتر) أو نسخة التطبيق.', 'Your browser cannot pick a folder. Use Chrome (Android or desktop) or the app version.', 'Ton navigateur ne peut pas choisir de dossier. Utilise Chrome (Android ou PC) ou l’application.', 'Tu navegador no permite elegir una carpeta. Usa Chrome (Android o PC) o la app.', 'Seu navegador não permite escolher uma pasta. Use o Chrome (Android ou PC) ou o app.', 'Dein Browser kann keinen Ordner wählen. Nutze Chrome (Android/PC) oder die App.', 'Tarayıcın klasör seçemiyor. Chrome (Android/PC) veya uygulamayı kullan.')); return; }
      try {
        const h = await window.showDirectoryPicker({ id: 'ffm26', mode: 'readwrite', startIn: 'documents' });
        if (!(await perm(h, true))) return;
        dirH = h; await setH(h); try { localStorage.setItem('ffm26_folder_on', '1'); } catch (_) {}
        pending = ffmSealedSave(); await pump(); ui();
        alert(L('تم! سيُحفظ تقدمك تلقائيًا في المجلد: ', 'Done! Your progress now auto-saves into the folder: ', 'Fait ! Ta progression est sauvegardée automatiquement dans le dossier : ', '¡Listo! Tu progreso se guarda automáticamente en la carpeta: ', 'Pronto! Seu progresso é salvo automaticamente na pasta: ', 'Fertig! Dein Fortschritt wird automatisch gespeichert in: ', 'Tamam! İlerlemen otomatik olarak şu klasöre kaydedilir: ') + h.name + '/' + DIRNAME + '/' + FILE);
      } catch (e) { if (e && e.name !== 'AbortError') console.warn(e); }
    },
    async disable() { dirH = null; await setH(null); try { localStorage.removeItem('ffm26_folder_on'); } catch (_) {} ui(); },
    async loadFromFolder() {
      const t = await readFile(); if (!t) { alert(L('لا يوجد ملف حفظ في المجلد.', 'No save file found in the folder.', 'Aucun fichier de sauvegarde dans le dossier.', 'No hay archivo de guardado en la carpeta.', 'Nenhum arquivo de salvamento na pasta.', 'Keine Speicherdatei im Ordner.', 'Klasörde kayıt dosyası yok.')); return; }
      try { pendingRestoreState = parseSavePayload(t, true); showRestoreDialog('file'); } catch (_) { alert((dict[state.lang] || dict.ar).backup_invalid_message); }
    }
  };
  /* --- settings UI --- */
  function ui() {
    const scr = document.getElementById('screen-settings'); if (!scr) return;
    let g = document.getElementById('folder-group');
    if (!g) {
      g = document.createElement('div'); g.id = 'folder-group'; g.style.cssText = 'margin-top:16px;border-top:2px solid #25418a;padding-top:12px';
      const ref = document.getElementById('delete-account-btn') || scr.querySelector('a.godot-btn'); scr.insertBefore(g, ref);
    }
    const on = !!dirH;
    const ok = lastOk ? L('آخر حفظ: ', 'Last saved: ', 'Dernière sauvegarde : ', 'Último guardado: ', 'Último salvamento: ', 'Zuletzt gespeichert: ', 'Son kayıt: ') + new Date(lastOk).toLocaleTimeString() : '';
    g.innerHTML = '<div style="font-size:15px;font-weight:bold;margin-bottom:6px">📁 ' + L('حفظ تلقائي في مجلد على الجهاز', 'Auto-save to a device folder', 'Sauvegarde auto dans un dossier', 'Guardado automático en carpeta', 'Salvamento automático em pasta', 'Automatisch in Ordner speichern', 'Klasöre otomatik kaydet') + '</div>' +
      '<div style="font-size:12px;color:#9fb3d9;margin-bottom:8px">' + (supported ? L('اختر مجلدًا مرة واحدة (مثلًا داخل المستندات). تُنشأ فيه مجلد ' + DIRNAME + ' وملف الحفظ المشفر ويتحدث تلقائيًا مع كل تغيير.', 'Pick a folder once (e.g. inside Documents). A ' + DIRNAME + ' folder with the encrypted save file is created and updated automatically on every change.', 'Choisis un dossier une fois (ex. dans Documents). Un dossier ' + DIRNAME + ' avec le fichier chiffré y est créé et mis à jour automatiquement.', 'Elige una carpeta una vez (p. ej. en Documentos). Se crea una carpeta ' + DIRNAME + ' con el archivo cifrado y se actualiza solo.', 'Escolha uma pasta uma vez (ex.: em Documentos). Uma pasta ' + DIRNAME + ' com o arquivo criptografado é criada e atualizada sozinha.', 'Wähle einmal einen Ordner (z. B. in Dokumente). Dort entsteht ein Ordner ' + DIRNAME + ' mit der verschlüsselten Datei, automatisch aktualisiert.', 'Bir kez klasör seç (ör. Belgeler). İçinde ' + DIRNAME + ' klasörü ve şifreli kayıt dosyası oluşur, otomatik güncellenir.') : L('هذا المتصفح لا يدعم الحفظ في مجلد. استخدم Chrome (أندرويد/كمبيوتر) أو نسخة التطبيق.', 'This browser cannot save to a folder. Use Chrome (Android/desktop) or the app version.', 'Ce navigateur ne peut pas sauvegarder dans un dossier. Utilise Chrome ou l’application.', 'Este navegador no puede guardar en una carpeta. Usa Chrome o la app.', 'Este navegador não salva em pasta. Use o Chrome ou o app.', 'Dieser Browser kann nicht in einen Ordner speichern. Nutze Chrome oder die App.', 'Bu tarayıcı klasöre kaydedemez. Chrome veya uygulamayı kullan.')) + '</div>' +
      (on ? '<div style="font-size:12px;color:#7bff8a;margin-bottom:8px">✅ ' + dirH.name + '/' + DIRNAME + '/' + FILE + (ok ? '<br>' + ok : '') + (lastErr === 'perm' ? '<br><span style="color:#ffd23f">' + L('اضغط في أي مكان لإعادة منح الإذن', 'Tap anywhere to re-grant permission', 'Touche l’écran pour réautoriser', 'Toca la pantalla para reautorizar', 'Toque na tela para autorizar de novo', 'Tippe zum erneuten Erlauben', 'İzni yenilemek için dokun') + '</span>' : '') + '</div>' : '') +
      '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
      '<button class="godot-btn" id="fo-choose" style="padding:9px 14px;font-size:13px">' + (on ? L('تغيير المجلد', 'Change folder', 'Changer de dossier', 'Cambiar carpeta', 'Trocar pasta', 'Ordner ändern', 'Klasörü değiştir') : L('اختيار مجلد', 'Choose folder', 'Choisir un dossier', 'Elegir carpeta', 'Escolher pasta', 'Ordner wählen', 'Klasör seç')) + '</button>' +
      (on ? '<button class="godot-btn" id="fo-load" style="padding:9px 14px;font-size:13px">' + L('تحميل من المجلد', 'Load from folder', 'Charger depuis le dossier', 'Cargar desde carpeta', 'Carregar da pasta', 'Aus Ordner laden', 'Klasörden yükle') + '</button><button class="godot-btn" id="fo-off" style="padding:9px 14px;font-size:13px;background:#555">' + L('إيقاف', 'Turn off', 'Désactiver', 'Desactivar', 'Desativar', 'Ausschalten', 'Kapat') + '</button>' : '') + '</div>';
    const c = document.getElementById('fo-choose'); if (c) c.onclick = () => ffmFolder.choose();
    const l = document.getElementById('fo-load'); if (l) l.onclick = () => ffmFolder.loadFromFolder();
    const o = document.getElementById('fo-off'); if (o) o.onclick = () => ffmFolder.disable();
  }
  const ws = window.showScreen; if (typeof ws === 'function') window.showScreen = function (id) { const r = ws.apply(this, arguments); if (id === 'screen-settings') ui(); return r; };
  const wl = window.changeLanguage; if (typeof wl === 'function') window.changeLanguage = function () { const r = wl.apply(this, arguments); ui(); return r; };
  /* --- boot: restore handle, re-grant on first tap, offer restore when local data is gone --- */
  (async function () {
    if (!supported) return;
    dirH = await getH(); if (!dirH) return;
    const g = await perm(dirH, false);
    if (g) { setTimeout(async () => { if (!localStorage.getItem('godot_football_save')) { const t = await readFile(); if (t) { try { pendingRestoreState = parseSavePayload(t, true); showRestoreDialog('file'); } catch (_) {} } } else { pending = ffmSealedSave(); pump(); } }, 1800); }
    else { const once = async () => { document.removeEventListener('click', once, true); if (await perm(dirH, true)) { pending = ffmSealedSave(); pump(); } }; document.addEventListener('click', once, true); }
  })();
})();
