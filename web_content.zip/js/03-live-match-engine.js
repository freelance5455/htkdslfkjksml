(function () {
'use strict';
/* ===== FFM 26 LIVE MATCH ENGINE (pixel-art, top-down broadcast camera) ===== */
const PW = 900, PH = 560, M = 60, GW = 96, GD = 22, K = 1.35;
const WW = PW + 2 * M, WH = PH + 2 * M, MATCH_SECONDS = 300;
const FORM = [[0.035,0.5],[0.2,0.12],[0.18,0.37],[0.18,0.63],[0.2,0.88],[0.4,0.25],[0.37,0.5],[0.4,0.75],[0.62,0.17],[0.66,0.5],[0.62,0.83]];
const ROLE = ['GK','DEF','DEF','DEF','DEF','MID','MID','MID','FWD','FWD','FWD'];
const FORMS = {
  '4-3-3': { pos: FORM, role: ROLE },
  '4-4-2': { pos: [[0.035,0.5],[0.2,0.12],[0.18,0.37],[0.18,0.63],[0.2,0.88],[0.42,0.12],[0.4,0.37],[0.4,0.63],[0.42,0.88],[0.64,0.37],[0.64,0.63]], role: ['GK','DEF','DEF','DEF','DEF','MID','MID','MID','MID','FWD','FWD'] },
  '3-5-2': { pos: [[0.035,0.5],[0.18,0.25],[0.16,0.5],[0.18,0.75],[0.38,0.1],[0.38,0.3],[0.36,0.5],[0.38,0.7],[0.38,0.9],[0.64,0.37],[0.64,0.63]], role: ['GK','DEF','DEF','DEF','MID','MID','MID','MID','MID','FWD','FWD'] },
  '4-2-3-1': { pos: [[0.035,0.5],[0.2,0.12],[0.18,0.37],[0.18,0.63],[0.2,0.88],[0.36,0.37],[0.36,0.63],[0.52,0.17],[0.52,0.5],[0.52,0.83],[0.68,0.5]], role: ['GK','DEF','DEF','DEF','DEF','MID','MID','MID','MID','MID','FWD'] },
  '5-3-2': { pos: [[0.035,0.5],[0.2,0.08],[0.17,0.3],[0.15,0.5],[0.17,0.7],[0.2,0.92],[0.4,0.25],[0.38,0.5],[0.4,0.75],[0.62,0.37],[0.62,0.63]], role: ['GK','DEF','DEF','DEF','DEF','DEF','MID','MID','MID','FWD','FWD'] }
};
window.FFMLiveCfg = window.FFMLiveCfg || { oppBoost: 0, formation: '4-3-3', press: 'normal' };
const FADJ = { '4-3-3': 0, '4-4-2': 13, '3-5-2': -11, '4-2-3-1': 11, '5-3-2': -8 };
const KRX = { GK: 0, DEF: 0.35, MID: 0.55, FWD: 0.7 };
const KITS = [
  { shirt: '#2d6cdf', stripe: '#ffffff', short: '#ffffff', sock: '#2d6cdf', gk: '#f2c230' },
  { shirt: '#e23b3b', stripe: null, short: '#2a2a33', sock: '#e23b3b', gk: '#37b24d' }
];
const SKINS = ['#f1c9a0', '#c98e62', '#8a5a3b'];
const HAIRS = ['#1d1410', '#4a2f1b', '#d9b24a', '#7a2b1b'];

let VW = 440, VH = 248, S = 2;
let canvas, ctx, world, overlay, hintEl, pauseMenu;
let G = null, B = null, raf = 0, lastT = 0, acc = 0, bound = false;
const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);
const hyp = Math.hypot, rand = Math.random;
const gauss = () => rand() + rand() + rand() - 1.5;

/* ---------- 3x5 pixel font ---------- */
const GL = {
 '0':'111101101101111','1':'010110010010111','2':'110001010100111','3':'110001010001110','4':'101101111001001',
 '5':'111100110001110','6':'011100111101111','7':'111001010010010','8':'111101111101111','9':'111101111001110',
 'A':'010101111101101','B':'110101110101110','C':'011100100100011','D':'110101101101110','E':'111100110100111',
 'F':'111100110100100','G':'011100101101011','H':'101101111101101','I':'111010010010111','J':'001001001101010',
 'K':'101101110101101','L':'100100100100111','M':'101111111101101','N':'111101101101101','O':'010101101101010',
 'P':'110101110100100','Q':'010101101011001','R':'110101110101101','S':'011100010001110','T':'111010010010010',
 'U':'101101101101111','V':'101101101101010','W':'101101111111101','X':'101101010101101','Y':'101101010010010',
 'Z':'111001010100111',':':'000010000010000','-':'000000111000000','_':'000000000000111','.':'000000000000010',
 '!':'010010010000010','+':'000010111010000','%':'101001010100101',' ':'000000000000000','#':'101111101111101','?':'111001010000010','/':'001001010100100'
};
function drawText(c, str, x, y, sc, col, sh) {
  str = String(str).toUpperCase();
  for (let pass = sh ? 0 : 1; pass < 2; pass++) {
    let cx = x;
    c.fillStyle = pass === 0 ? sh : col;
    const off = pass === 0 ? sc : 0;
    for (const ch of str) {
      const g = GL[ch] || GL['?'];
      for (let i = 0; i < 15; i++) if (g[i] === '1') c.fillRect(cx + (i % 3) * sc + off, y + ((i / 3) | 0) * sc + off, sc, sc);
      cx += 4 * sc;
    }
  }
}
const textW = (s, sc) => String(s).length * 4 * sc - sc;
function drawTextC(c, str, cx, y, sc, col, sh) { drawText(c, str, Math.round(cx - textW(str, sc) / 2), y, sc, col, sh); }

/* ---------- static world (pre-rendered once) ---------- */
function buildWorld() {
  world = document.createElement('canvas'); world.width = WW; world.height = WH;
  const c = world.getContext('2d');
  let seed = 7771; const r = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
  c.fillStyle = '#171a30'; c.fillRect(0, 0, WW, WH);
  const heads = ['#e5484d','#f5c542','#f2f2f2','#3d8bfd','#ff8a3d','#7bd88f','#c77dff'];
  for (let y = 0; y < WH; y += 4) for (let x = 0; x < WW; x += 4) {
    const px = x + ((y >> 2) & 1) * 2;
    c.fillStyle = heads[(r() * heads.length) | 0]; c.fillRect(px, y, 2, 2);
    c.fillStyle = 'rgba(0,0,0,.38)'; c.fillRect(px, y + 2, 2, 2);
  }
  const R = 24, bx0 = M - R, by0 = M - R, bw = PW + 2 * R, bh = PH + 2 * R;
  c.fillStyle = '#255c25'; c.fillRect(bx0, by0, bw, bh);
  for (let i = 0; i < 1400; i++) { c.fillStyle = r() < .5 ? '#2c6a2a' : '#1f4f20'; c.fillRect(bx0 + (r() * bw | 0), by0 + (r() * bh | 0), 1, 1); }
  // ad boards ring
  const bc = ['#d65821','#293370','#1abf62','#f5c542','#c2185b','#00838f'];
  const txt = ['FFM 26','KICKOFF','GOAL!','PIXEL FC','36 DAYS','FFM 26'];
  c.fillStyle = '#0c0c14';
  c.fillRect(bx0 - 9, by0 - 9, bw + 18, 9); c.fillRect(bx0 - 9, by0 + bh, bw + 18, 9);
  c.fillRect(bx0 - 9, by0 - 9, 9, bh + 18); c.fillRect(bx0 + bw, by0 - 9, 9, bh + 18);
  let k = 0;
  for (let x = bx0; x < bx0 + bw; x += 56, k++) {
    const w = Math.min(56, bx0 + bw - x);
    for (const yy of [by0 - 8, by0 + bh + 1]) { c.fillStyle = bc[k % bc.length]; c.fillRect(x, yy, w - 1, 7); drawText(c, txt[k % txt.length], x + 3, yy + 1, 1, '#fff'); }
  }
  k = 0;
  for (let y = by0; y < by0 + bh; y += 40, k++) {
    const h = Math.min(40, by0 + bh - y);
    for (const xx of [bx0 - 8, bx0 + bw + 1]) { c.fillStyle = bc[(k + 2) % bc.length]; c.fillRect(xx, y, 7, h - 1); }
  }
  // pitch
  const X = M, Y = M;
  for (let i = 0; i * 50 < PW; i++) { c.fillStyle = i % 2 ? '#3f8f35' : '#48993b'; c.fillRect(X + i * 50, Y, 50, PH); }
  for (let i = 0; i < 3200; i++) { c.fillStyle = r() < .5 ? '#37802f' : '#58b049'; c.fillRect(X + (r() * PW | 0), Y + (r() * PH | 0), 1, 1); }
  // lines
  const L = '#eef3e6';
  c.fillStyle = L;
  const hl = (x1, x2, y) => c.fillRect(X + x1, Y + y - 1, x2 - x1, 2);
  const vl = (x, y1, y2) => c.fillRect(X + x - 1, Y + y1, 2, y2 - y1);
  hl(0, PW, 0); hl(0, PW, PH); vl(0, 0, PH); vl(PW, 0, PH); vl(PW / 2, 0, PH);
  const pa = 130, pw2 = 125, sa = 44, sw2 = 55;
  for (const side of [0, 1]) {
    const gx = side ? PW : 0, d = side ? -1 : 1;
    const xr = (dep) => gx + d * dep;
    const rect = (dep, w2) => { const x1 = Math.min(gx, xr(dep)), x2 = Math.max(gx, xr(dep)); hl(x1, x2, PH / 2 - w2); hl(x1, x2, PH / 2 + w2); vl(xr(dep), PH / 2 - w2, PH / 2 + w2); };
    rect(pa, pw2); rect(sa, sw2);
    c.fillRect(X + xr(88) - 1, Y + PH / 2 - 1, 3, 3);
    for (let a = 0; a < 6.2832; a += 0.012) {
      const px = xr(88) + Math.cos(a) * 46, py = PH / 2 + Math.sin(a) * 46;
      if ((px - gx) * d > pa) c.fillRect(X + Math.round(px), Y + Math.round(py), 2, 2);
    }
    // goal net
    const y1 = PH / 2 - GW / 2, nx = side ? PW : -GD;
    c.fillStyle = '#b9c6d2'; c.fillRect(X + nx, Y + y1, GD, GW);
    c.fillStyle = '#8fa2b3';
    for (let yy = 0; yy < GW; yy += 3) for (let xx = (yy / 3 & 1) * 3; xx < GD; xx += 6) c.fillRect(X + nx + xx, Y + y1 + yy, 2, 2);
    c.fillStyle = '#fff';
    c.fillRect(X + nx, Y + y1 - 2, GD, 3); c.fillRect(X + nx, Y + y1 + GW - 1, GD, 3);
    c.fillRect(X + (side ? PW + GD - 2 : -GD), Y + y1, 2, GW);
    c.fillRect(X + (side ? PW - 1 : -2), Y + y1 - 2, 3, 4); c.fillRect(X + (side ? PW - 1 : -2), Y + y1 + GW - 2, 3, 4);
    c.fillStyle = L;
  }
  c.fillRect(X + PW / 2 - 2, Y + PH / 2 - 2, 4, 4);
  for (let a = 0; a < 6.2832; a += 0.01) c.fillRect(X + Math.round(PW / 2 + Math.cos(a) * 56), Y + Math.round(PH / 2 + Math.sin(a) * 56), 2, 2);
  for (const [cx2, cy2] of [[0,0],[PW,0],[0,PH],[PW,PH]]) for (let a = 0; a < 6.2832; a += 0.08) {
    const px = Math.round(cx2 + Math.cos(a) * 9), py = Math.round(cy2 + Math.sin(a) * 9);
    if (px >= 0 && px <= PW && py >= 0 && py <= PH) c.fillRect(X + px, Y + py, 2, 2);
  }
}

/* ---------- game setup ---------- */
function buildTeam(side, data, name) {
  let ck = null;
  if (side === 0 && window.FFMKit) {
    ck = FFMKit.forMatch();
    KITS[0] = Object.assign({}, KITS[0], { shirt: ck.shirt, short: ck.short, sock: ck.sock, stripe: ck.grid ? null : ck.stripe });
    const hx = (h) => [1, 3, 5].map(i => parseInt(h.substr(i, 2), 16)), a = hx(ck.shirt), b = hx('#e23b3b');
    const clash = Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) < 120;
    KITS[1] = clash ? { shirt: '#f2f2f2', stripe: null, short: '#2a2a33', sock: '#f2f2f2', gk: '#37b24d' } : { shirt: '#e23b3b', stripe: null, short: '#2a2a33', sock: '#e23b3b', gk: '#37b24d' };
  }
  const dir = side === 0 ? 1 : -1, kit = KITS[side], players = [];
  const cfg = window.FFMLiveCfg || {}, F = FORMS[(side === 0 && FORMS[cfg.formation]) ? cfg.formation : '4-3-3'];
  const pm = side === 0 ? ({ low: 0.9, normal: 1, high: 1.1 }[cfg.press] || 1) : 1, boost = side === 1 ? (cfg.oppBoost || 0) : (FADJ[cfg.formation] || 0);
  for (let i = 0; i < 11; i++) {
    const src = data.players[i] || { number: i + 1, name: 'Player', rating: 60 };
    players.push({
      team: side, idx: i, num: src.number, name: src.name, rating: (Number(src.rating) || 60) + boost, role: F.role[i],
      u: i === 0 ? F.pos[i][0] : Math.min(0.85, F.pos[i][0] * pm), v: F.pos[i][1], x: 0, y: 0, vx: 0, vy: 0, dvx: 0, dvy: 0, fx: dir, fy: 0, anim: rand() * 6,
      cd: 0, tcd: 0, frz: 0, grace: 0, think: rand() * 0.5, hold: 0, shotCd: 0, mustPass: false,
      trait: src.trait || null, skin: SKINS[(i * 7 + side * 3) % 3], hair: HAIRS[(i * 5 + side) % 4],
      kit: { grid: (i === 0 || !ck) ? null : ck.grid, sleeve: (i === 0 || !ck) ? null : ck.sleeve, shirt: i === 0 ? kit.gk : kit.shirt, stripe: i === 0 ? null : kit.stripe, short: i === 0 ? '#222' : kit.short, sock: i === 0 ? '#222' : kit.sock, glove: i === 0 }
    });
  }
  return { side, dir, name: String(name), players, score: 0, chaser: null, cover: null };
}
const teamOf = p => G.teams[p.team], oppOf = p => G.teams[1 - p.team];
const homeX = (p) => p.team === 0 ? p.u * PW : (1 - p.u) * PW;
const maxSpeed = p => (62 + (p.rating - 60) * 0.5) * (B.owner === p ? 0.9 : 1) * (p.trait === 'speed' ? 1 + TRAIT_BOOST : 1);
const isClin = p => p.trait === 'clinical';

const FREEZE_SECONDS = 6;
const TRAIT_BOOST = 0.39;
const TRAIT_META = { clinical: ['SHOOTING', '#d32f2f', '#ff3b30'], passer: ['PASSING', '#1e88e5', '#64b5f6'], tackler: ['TACKLE + CUT', '#ef6c00', '#ffb74d'], speed: ['SPEED', '#f9a825', '#fff176'], keeper: ['SAVING', '#2e7d32', '#81c784'] };
function traitFire(p, why) {
  if (!p || !p.trait || !TRAIT_META[p.trait]) return;
  p.tfx = 1.4; p.tfxWhy = why || '';
  if (G) burst(p.x, p.y - 8, 18, [TRAIT_META[p.trait][2], TRAIT_META[p.trait][1], '#ffffff'], 120, 120);
} // +39% shot power and accuracy for players with a shooting trait
function triggerFreeze(p) {
  if (!G || G.bot || G.mode !== 'play' || p.team !== 0 || !G.ff) return;
  G.freezeT = FREEZE_SECONDS; G.active = p; p.frz = 0; inp.aim = null;
}
function giveBall(p) {
  const prev = B.owner;
  B.owner = p; B.vx = B.vy = 0; B.lastTeam = p.team; B.lastPlayer = p; B.pass = null; p.hold = 0; p.grace = 0.35;
  if (B.indirect && p !== B.taker) B.indirect = false;
  if (B.set && p !== B.set.taker) clearSet();
  if (prev !== p) triggerFreeze(p);
}
function setupKickoff(kTeam) {
  for (const t of G.teams) for (const p of t.players) {
    p.x = homeX(p); p.y = p.v * PH; p.vx = p.vy = p.dvx = p.dvy = 0; p.fx = t.dir; p.fy = 0; p.cd = 0; p.tcd = 0; p.frz = 1.0; p.mustPass = false;
    if (t.side === 0) p.x = Math.min(p.x, PW / 2 - 8); else p.x = Math.max(p.x, PW / 2 + 8);
  }
  const tk = kTeam.players[9];
  tk.x = PW / 2 - kTeam.dir * 4; tk.y = PH / 2; tk.frz = 0.5; tk.mustPass = true;
  clearSet(); B.indirect = false; B.taker = null;
  B.x = PW / 2; B.y = PH / 2; B.prot = 1.4; giveBall(tk);
  G.active = null; G.snapCam = true;
}
function newGame(opts) {
  const mc = opts.ctx;
  const H = state.teams[mc.myTeamId], A = state.teams[mc.oppTeamId];
  B = { x: PW / 2, y: PH / 2, vx: 0, vy: 0, owner: null, lastTeam: 0, lastPlayer: null, prot: 0, pass: null, trail: [], set: null, indirect: false, taker: null };
  G = {
    freezeT: 0, mode: 'intro', modeT: 2.4, clock: 0, t: 0, bot: !!opts.bot, ts: opts.timeScale || 1, paused: false,
    home: buildTeam(0, H, H.name), away: buildTeam(1, A, A.name), banner: null, parts: [], active: null, snapCam: true,
    cam: { x: PW / 2 - VW / 2, y: PH / 2 - VH / 2 }, switchT: 0, stats: { passes: 0, shots: 0, tackles: 0, saves: 0, fouls: 0, direct: 0, indirect: 0, pens: 0 }, lastScorer: null, endT: 0,
    mc, onFinish: opts.onFinish, aimInfo: null
  };
  G.teams = [G.home, G.away]; G.all = G.home.players.concat(G.away.players); G.human = G.home;
  setupKickoff(G.home);
  banner('KICK OFF', 2.2);
}
function banner(text, t, col) { G.banner = { text, t, max: t, col: col || '#fff' }; if (text === 'SAVE!') sfx('save'); else if (text === 'POST!') sfx('post'); }

/* ---------- audio (tiny synthesized sfx) ---------- */
let actx = null;
function sfx(kind) {
  if (window.FFMSfx && window.FFMSfx.names.indexOf(kind) >= 0) { window.FFMSfx.play(kind); return; }
  try {
    const mt = document.getElementById('music-muted-toggle'); if (mt && mt.checked) return;
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t = actx.currentTime, g = actx.createGain(); g.connect(actx.destination);
    const o = actx.createOscillator(); o.connect(g);
    if (kind === 'kick') { o.type = 'square'; o.frequency.setValueAtTime(190, t); o.frequency.exponentialRampToValueAtTime(60, t + .08); g.gain.setValueAtTime(.12, t); g.gain.exponentialRampToValueAtTime(.001, t + .09); o.start(t); o.stop(t + .1); }
    else if (kind === 'whistle') { o.type = 'sine'; o.frequency.setValueAtTime(2500, t); g.gain.setValueAtTime(.1, t); g.gain.setValueAtTime(.1, t + .35); g.gain.exponentialRampToValueAtTime(.001, t + .5); o.start(t); o.stop(t + .5); }
    else if (kind === 'goal') { o.type = 'triangle'; o.frequency.setValueAtTime(330, t); o.frequency.linearRampToValueAtTime(660, t + .5); g.gain.setValueAtTime(.1, t); g.gain.exponentialRampToValueAtTime(.001, t + .9); o.start(t); o.stop(t + .9); }
    else { o.type = 'square'; o.frequency.value = 120; g.gain.setValueAtTime(.08, t); g.gain.exponentialRampToValueAtTime(.001, t + .06); o.start(t); o.stop(t + .07); }
  } catch (_) {}
}

/* ---------- particles ---------- */
function burst(x, y, n, cols, spd, up) {
  for (let i = 0; i < n && G.parts.length < 160; i++) {
    const a = rand() * 6.283, s = spd * (0.3 + rand());
    G.parts.push({ x, y, z: 2, vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.6, vz: up * (0.4 + rand()), life: 0.5 + rand() * 0.6, max: 1.1, col: cols[(rand() * cols.length) | 0], s: rand() < .5 ? 2 : 1 });
  }
}

/* ---------- ball actions ---------- */
function kick(p, dx, dy, speed, target, shot) {
  const l = hyp(dx, dy) || 1; dx /= l; dy /= l;
  if (!shot && p.trait === 'passer') { speed = Math.min(speed * (1 + TRAIT_BOOST), 640); traitFire(p, 'PASS'); }
  B.owner = null; B.x = p.x + dx * 8; B.y = p.y + dy * 6 + 1; B.vx = dx * speed; B.vy = dy * speed;
  B.lastTeam = p.team; B.lastPlayer = p; B.pass = target || null; B.prot = 0;
  if (B.set && B.set.kind === 'pen') G.pen = { until: G.t + 0.5, gy: PH / 2 + (rand() < 0.5 ? 1 : -1) * (dy >= 0 ? 1 : -1) * 30, team: 1 - p.team };
  clearSet();
  p.cd = 0.45; p.mustPass = false; p.fx = dx; p.fy = dy;
  burst(B.x, B.y, 5, ['#cfd8c4', '#e8efe0'], 40, 30);
  if (shot) G.stats.shots++; else G.stats.passes++;
  sfx(shot ? 'shot' : 'pass'); if (shot && window.FFMSfx) FFMSfx.swell();
  if (shot && isClin(p)) traitFire(p, 'SHOT');
  if (!shot && target && p.team === 0 && !G.bot) G.active = target;
}

function computePass(p, dx, dy, t, noisy, force) {
  const T = teamOf(p), l = hyp(dx, dy) || 1; dx /= l; dy /= l;
  let speed = 150 + 410 * t, target = null, shot = false;
  const reach = speed / K;
  let bestA = 0.4;
  for (const q of T.players) {
    if (q === p || (B.set && B.set.kind === 'pen') || force === 'shot') continue;
    const qx = q.x - p.x, qy = q.y - p.y, d = hyp(qx, qy);
    if (d < 24 || d > reach * 1.35 + 60) continue;
    const ang = Math.acos(clamp((qx * dx + qy * dy) / d, -1, 1));
    if (ang < bestA) { bestA = ang; target = q; }
  }
  if (target) {
    const qx = target.x - p.x, qy = target.y - p.y, d = hyp(qx, qy);
    const lead = Math.min(0.55, d / 320);
    const tx = target.x + target.vx * lead - p.x, ty = target.y + target.vy * lead - p.y;
    const dd = hyp(tx, ty) || 1; dx = tx / dd; dy = ty / dd;
    speed = clamp(Math.max(d * K * 1.12 + 40, 0.65 * speed), 130, 560);
  } else {
    const goalX = T.dir > 0 ? PW : 0, dg = Math.abs(goalX - p.x);
    if (force === 'shot' || (dx * T.dir > 0.15 && dg < 360 && t > 0.4)) {
      const yAt = Math.abs(dx) > 0.05 ? p.y + dy * ((goalX - p.x) / dx) : PH / 2;
      if (force === 'shot' || Math.abs(yAt - PH / 2) < GW / 2 + 18) {
        shot = true; speed = force === 'shot' ? 170 + 430 * t : Math.max(speed, 390);
        if (isClin(p)) speed = Math.min(speed * (1 + TRAIT_BOOST), 780);
        const ty = clamp(yAt, PH / 2 - GW / 2 + 9, PH / 2 + GW / 2 - 9);
        const vx = goalX - p.x, vy = ty - p.y, vl = hyp(vx, vy); dx = vx / vl; dy = vy / vl;
      }
    }
  }
  if (noisy) {
    const sk = clamp((p.rating - 50) / 50, 0.1, 1);
    const dg = Math.abs((T.dir > 0 ? PW : 0) - p.x);
    const sig = (shot ? 0.05 * (dg / 160) * (1.25 - sk) : 0.02 * (1.25 - sk)) / ((shot && isClin(p)) ? 1 + TRAIT_BOOST : (!shot && p.trait === 'passer') ? 1 + TRAIT_BOOST : 1);
    const a = Math.atan2(dy, dx) + gauss() * sig;
    dx = Math.cos(a); dy = Math.sin(a);
  }
  return { dx, dy, speed, target, shot, reach: speed / K };
}

/* ---------- AI helpers ---------- */
function bestPass(p, T, O, maxD) {
  let best = null, bs = -1e9;
  for (const q of T.players) {
    if (q === p || q.role === 'GK') continue;
    const dx = q.x - p.x, dy = q.y - p.y, d = hyp(dx, dy);
    if (d < 30 || d > (maxD || 330)) continue;
    let open = 110; for (const o of O.players) { const od = hyp(o.x - q.x, o.y - q.y); if (od < open) open = od; }
    let block = 0;
    for (const o of O.players) {
      const t = clamp(((o.x - p.x) * dx + (o.y - p.y) * dy) / (d * d), 0, 1);
      if (t > 0.08 && t < 1 && hyp(o.x - (p.x + dx * t), o.y - (p.y + dy * t)) < 14) block++;
    }
    const s = dx * T.dir * 0.9 + open * 1.1 - d * 0.25 - block * 150 + rand() * 30 + (q.role === 'FWD' ? 25 : 0);
    if (s > bs) { bs = s; best = q; }
  }
  return best ? { q: best, s: bs } : null;
}
function aiPass(p, T, O, q) {
  const dx = q.x - p.x, dy = q.y - p.y, d = hyp(dx, dy), lead = Math.min(0.5, d / 340);
  const tx = q.x + q.vx * lead - p.x, ty = q.y + q.vy * lead - p.y;
  const sk = clamp((p.rating - 50) / 50, 0.1, 1);
  const a = Math.atan2(ty, tx) + gauss() * 0.04 * (1.3 - sk) / (p.trait === 'passer' ? 1 + TRAIT_BOOST : 1);
  kick(p, Math.cos(a), Math.sin(a), clamp(d * K * 1.15 + 45, 140, 520), q, false);
}
function aiShoot(p, T, O) {
  const goalX = T.dir > 0 ? PW : 0, dg = Math.abs(goalX - p.x), gk = O.players[0];
  const side = (B.set && B.set.kind === 'pen') ? (rand() < 0.5 ? -1 : 1) : (gk.y > PH / 2 ? -1 : 1);
  const ty = PH / 2 + side * (GW / 2 - 14) * (0.55 + rand() * 0.45);
  const sk = clamp((p.rating - 50) / 50, 0.1, 1);
  const tb = isClin(p) ? 1 + TRAIT_BOOST : 1;
  const a = Math.atan2(ty - p.y, goalX - p.x) + gauss() * (0.05 + (1.2 - sk) * 0.07) * Math.max(0.5, dg / 170) / tb;
  kick(p, Math.cos(a), Math.sin(a), Math.min(((B.set && B.set.kind === 'pen') ? 330 + rand() * 70 : 400 + rand() * 80) * tb, 780), null, true);
  p.shotCd = 2;
}
function dribbleDir(p, T, O) {
  let vx = T.dir, vy = (PH / 2 - p.y) / PH * 0.7;
  for (const o of O.players) {
    const d = hyp(p.x - o.x, p.y - o.y);
    if (d < 52 && d > 0.1) { const w = (52 - d) / 52; vx += (p.x - o.x) / d * w * 1.7; vy += (p.y - o.y) / d * w * 1.7; }
  }
  if (p.y < 30) vy += 0.8; if (p.y > PH - 30) vy -= 0.8;
  if ((T.dir > 0 && p.x > PW - 60) || (T.dir < 0 && p.x < 60)) vx = 0.15 * T.dir;
  const l = hyp(vx, vy) || 1; return [vx / l, vy / l];
}
function moveTo(p, tx, ty, sp, slow) {
  const dx = tx - p.x, dy = ty - p.y, d = hyp(dx, dy);
  if (d < 1.5) { p.dvx = p.dvy = 0; return; }
  const k = slow ? clamp(d / 14, 0.15, 1) : 1;
  p.dvx = dx / d * sp * k; p.dvy = dy / d * sp * k;
}
function formTarget(p, T) {
  const hx0 = homeX(p), hy = p.v * PH, k = KRX[p.role];
  let tx = hx0 + (B.x - PW / 2) * k, ty = hy + (B.y - PH / 2) * (p.role === 'FWD' ? 0.18 : 0.3);
  const o = B.owner;
  if (o && o.team === T.side) {
    tx += T.dir * ({ DEF: 25, MID: 55, FWD: 75 }[p.role] || 0);
    if (p.role === 'FWD') tx = T.dir > 0 ? Math.min(PW - 45, Math.max(tx, o.x + 45)) : Math.max(45, Math.min(tx, o.x - 45));
  } else if (o) tx += T.dir * ({ DEF: -20, MID: -25, FWD: -10 }[p.role] || 0);
  return [clamp(tx, 30, PW - 30), clamp(ty, 20, PH - 20)];
}

/* ---------- roles / human control ---------- */
function assignRoles() {
  const o = B.owner;
  for (const T of G.teams) {
    T.chaser = null; T.cover = null;
    if (o && o.team === T.side) continue;
    const gx = T.side === 0 ? 0 : PW;
    const tx = o ? o.x : B.x + B.vx * 0.25, ty = o ? o.y : B.y + B.vy * 0.25;
    const c = [];
    for (const p of T.players) {
      if (p.frz > 0) continue;
      if (p.role === 'GK') { if (!o && Math.abs(B.x - gx) < 140 && Math.abs(B.y - PH / 2) < 125 && B.lastTeam !== T.side) c.push([hyp(p.x - tx, p.y - ty) * 0.8, p]); continue; }
      let d = hyp(p.x - tx, p.y - ty); if (!o && B.pass === p) d *= 0.4; c.push([d, p]);
    }
    c.sort((a, b) => a[0] - b[0]);
    if (c[0]) T.chaser = c[0][1]; if (o && c[1]) T.cover = c[1][1];
  }
}
function pickActive() {
  const T = G.human, o = B.owner;
  if (o && o.team === T.side) { G.active = o; G.switchT = 0.2; return; }
  if (G.press && G.press.p) { G.active = G.press.p; G.switchT = 0.2; return; }
  const cur = G.active;
  if (G.switchT > 0 && cur && cur.team === 0) return;
  let best = null, bd = 1e9;
  const tx = o ? o.x : B.x + B.vx * 0.3, ty = o ? o.y : B.y + B.vy * 0.3;
  for (const p of T.players) {
    if (p.role === 'GK' && Math.abs(B.x) > 150) continue;
    let d = hyp(p.x - tx, p.y - ty); if (!o && B.pass === p) d *= 0.4;
    if (d < bd) { bd = d; best = p; }
  }
  if (!cur || cur.team !== 0 || (best !== cur && bd + 14 < hyp(cur.x - tx, cur.y - ty))) { if (best !== cur) G.switchT = 0.3; G.active = best; }
}
const inp = { kx: 0, ky: 0, joy: null, aim: null, keys: {} };
const pad = { chg: null, jx: 0, jy: 0, cH: { 1: false, 2: false }, c: false };
function ctrlMode() { try { return localStorage.getItem('ffm26_ctrl') === 'drag' ? 'drag' : 'pad'; } catch (_) { return 'pad'; } }
const padOn = () => !!G && !G.bot && ctrlMode() === 'pad';
const sprintOn = () => padOn() && pad.c && (G.stam == null || G.stam > 0.03);
function inputVec() {
  let x = inp.kx, y = inp.ky;
  if (inp.joy) { const dx = inp.joy.x - inp.joy.ox, dy = inp.joy.y - inp.joy.oy, l = hyp(dx, dy); if (l > 5) { const m = Math.min(1, l / 26); x += dx / l * m; y += dy / l * m; } }
  if (padOn()) { x += pad.jx; y += pad.jy; }
  const l = hyp(x, y); if (l > 1) { x /= l; y /= l; } return [x, y];
}

function control(p, dt) {
  const T = teamOf(p), O = oppOf(p);
  if (G.mode !== 'play' || p.frz > 0) { p.dvx = p.dvy = 0; return; }
  if (p.setHold) { p.dvx = p.dvy = 0; return; }
  const human = !G.bot && p.team === 0, sp = maxSpeed(p);
  if (p.slideT > 0) { p.slideT -= dt; p.dvx = p.sdx * sp * 1.9; p.dvy = p.sdy * sp * 1.9; if (Math.random() < 0.5) burst(p.x, p.y, 1, ['#cfd8c4', '#9bbf86'], 30, 20); if (p.slideT <= 0) { p.slideT = 0; p.frz = 0.5; } return; }
  if (B.set && B.set.taker === p) { if (!human) { aiCarrier(p, T, O, dt, sp); } p.dvx = p.dvy = 0; return; }
  let manual = false;
  if (human && G.active === p) {
    const [ix, iy] = inputVec();
    if (hyp(ix, iy) > 0.15) { const spr = sprintOn(); p.dvx = ix * sp * (spr ? 1.3 : 1); p.dvy = iy * sp * (spr ? 1.3 : 1); manual = true; if (spr) G.sprintNow = true; if (G.press && G.press.p === p) G.press = null; }
  }
  if (B.owner === p) {
    if (manual) return;
    if (human) {
      if (p.role === 'GK') { p.dvx = p.dvy = 0; return; }
      if (padOn()) { p.dvx = p.dvy = 0; return; }
      const d = dribbleDir(p, T, O); p.dvx = d[0] * sp * 0.85; p.dvy = d[1] * sp * 0.85; return;
    }
    aiCarrier(p, T, O, dt, sp); return;
  }
  if (manual) return;
  if (human && G.press && G.press.p === p) { const tg = (B.owner && B.owner.team === 1) ? B.owner : B, spr = sprintOn(); if (spr) G.sprintNow = true; moveTo(p, tg.x, tg.y, sp * (spr ? 1.3 : 1), false); return; }
  aiOff(p, T, O, sp);
}
function aiCarrier(p, T, O, dt, sp) {
  p.hold += dt; p.think -= dt;
  if (p.shotCd > 0) p.shotCd -= dt;
  if (p.role === 'GK') { p.dvx = p.dvy = 0; } else {
    const d = dribbleDir(p, T, O); p.dvx = d[0] * sp * 0.9; p.dvy = d[1] * sp * 0.9;
  }
  if (p.think > 0) return;
  p.think = 0.25 + rand() * 0.35;
  if (B.set && B.set.taker === p) { autoSetPiece(); return; }
  const goalX = T.dir > 0 ? PW : 0, dg = Math.abs(goalX - p.x);
  let near = 999; for (const o of O.players) near = Math.min(near, hyp(o.x - p.x, o.y - p.y));
  if (p.mustPass || p.role === 'GK') {
    const b = bestPass(p, T, O, p.role === 'GK' ? 420 : 260);
    if (b) { aiPass(p, T, O, b.q); return; }
    if (p.role === 'GK') { aiPass(p, T, O, T.players[2 + ((rand() * 3) | 0)]); return; }
    p.mustPass = false; return;
  }
  const inRange = dg < 240 && Math.abs(p.y - PH / 2) < 200;
  if (inRange && p.shotCd <= 0 && rand() < (dg < 140 ? 0.9 : 0.5)) { aiShoot(p, T, O); return; }
  const pressured = near < 34;
  if ((pressured && rand() < 0.8) || rand() < 0.2 || p.hold > 3) {
    const b = bestPass(p, T, O);
    if (b && (b.s > 0 || p.hold > 3 || pressured)) aiPass(p, T, O, b.q);
  }
}
function aiOff(p, T, O, sp) {
  const o = B.owner;
  if (p.role === 'GK' && T.chaser !== p) {
    const gx = T.side === 0 ? 16 : PW - 16, ownX = T.side === 0 ? 0 : PW;
    if (G.pen && G.pen.team === p.team && G.t < G.pen.until) { moveTo(p, T.side === 0 ? 6 : PW - 6, G.pen.gy, sp * 2.0, false); return; }
    let ty = PH / 2 + clamp((B.y - PH / 2) * 0.5, -GW / 2 + 8, GW / 2 - 8), mul = 0.9;
    if (!o && B.lastTeam !== T.side && B.vx * (ownX === 0 ? -1 : 1) > 80) {
      const tt = (ownX - B.x) / B.vx;
      if (tt > 0 && tt < 1.7) { const py = B.y + B.vy * tt; if (Math.abs(py - PH / 2) < GW / 2 + 12) { ty = clamp(py, PH / 2 - GW / 2 + 3, PH / 2 + GW / 2 - 3); mul = 1.7; } }
    }
    moveTo(p, gx, ty, sp * mul, true); return;
  }
  if (T.chaser === p) {
    if (o) moveTo(p, o.x + o.fx * 6, o.y + o.fy * 6, sp * 1.02, false);
    else moveTo(p, B.x + B.vx * 0.3, B.y + B.vy * 0.3, sp * 1.05, false);
    return;
  }
  if (o && o.team !== T.side && T.cover === p) {
    const ownX = T.side === 0 ? 0 : PW;
    moveTo(p, o.x + (ownX - o.x) * 0.18, o.y + (PH / 2 - o.y) * 0.18, sp, true); return;
  }
  const [tx, ty] = formTarget(p, T);
  moveTo(p, tx, ty, sp * 0.92, true);
}

/* ---------- physics ---------- */
function integrate(dt) {
  for (const p of G.all) {
    const a = Math.min(1, 10 * dt);
    p.vx += (p.dvx - p.vx) * a; p.vy += (p.dvy - p.vy) * a;
    p.x = clamp(p.x + p.vx * dt, -12, PW + 12); p.y = clamp(p.y + p.vy * dt, -14, PH + 14);
    const s = hyp(p.vx, p.vy);
    if (s > 14) { const f = Math.min(1, 12 * dt); p.fx += (p.vx / s - p.fx) * f; p.fy += (p.vy / s - p.fy) * f; const l = hyp(p.fx, p.fy) || 1; p.fx /= l; p.fy /= l; }
    p.anim += s * dt * 0.11;
  }
  const A = G.all;
  for (let i = 0; i < A.length; i++) for (let j = i + 1; j < A.length; j++) {
    const a = A[i], b = A[j], dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy;
    if (d2 < 100 && d2 > 0.01) { const d = Math.sqrt(d2), push = (10 - d) * 0.5; const nx = dx / d, ny = dy / d; a.x -= nx * push; a.y -= ny * push; b.x += nx * push; b.y += ny * push; }
  }
}
function restartAt(team, x, y, taker, msg, frz, col, bt) {
  clearSet(); B.indirect = false; B.taker = null; B.owner = null;
  B.x = x; B.y = y; B.vx = B.vy = 0;
  taker.x = x; taker.y = y; taker.vx = taker.vy = 0; taker.frz = frz; taker.mustPass = true;
  G.ff = true; giveBall(taker); G.ff = false; B.prot = frz + 0.9;
  banner(msg, bt || 1.2, col); sfx('whistle');
}
function nearestField(T, x, y) {
  let best = null, bd = 1e9;
  for (const p of T.players) { if (p.role === 'GK') continue; const d = hyp(p.x - x, p.y - y); if (d < bd) { bd = d; best = p; } }
  return best;
}
function scoreGoal(side) {
  const T = G.teams[side]; T.score++; G.kickTeam = 1 - side; clearSet(); B.indirect = false;
  G.mode = 'goal'; G.modeT = 3.2; G.lastScorer = B.lastPlayer;
  const lp = B.lastPlayer; G.scorerLabel = lp ? ('#' + lp.num + ' ' + lp.name) : '';
  banner('GOAL!', 3, '#ffd23f'); sfx('goal');
  burst(B.x, B.y, 70, ['#ffd23f', '#ff5a5a', '#5ad1ff', '#ffffff', '#7bff8a'], 170, 160);
  for (const p of G.all) { p.dvx = p.dvy = 0; }
  B.owner = null;
}
function updateBall(dt) {
  if (B.owner) {
    const o = B.owner; B.x = o.x + o.fx * 6; B.y = o.y + o.fy * 4 + 1; B.vx = B.vy = 0; B.lastTeam = o.team; B.lastPlayer = o; return;
  }
  const px = B.x;
  B.x += B.vx * dt; B.y += B.vy * dt;
  const f = Math.exp(-K * dt); B.vx *= f; B.vy *= f;
  const sp = hyp(B.vx, B.vy); if (sp < 6) B.vx = B.vy = 0;
  if (sp > 200) { B.trail.push([B.x, B.y]); if (B.trail.length > 5) B.trail.shift(); } else if (B.trail.length) B.trail.shift();
  if (G.mode !== 'play') {
    B.y = clamp(B.y, -30, PH + 30);
    if (B.x < -GD + 3) { B.x = -GD + 3; B.vx *= -0.2; } if (B.x > PW + GD - 3) { B.x = PW + GD - 3; B.vx *= -0.2; }
    return;
  }
  // ball fully across the line inside the mouth = goal (checked before keeper/player traps)
  if (((px >= 0 && B.x < 0) || (px <= PW && B.x > PW)) && !B.indirect && Math.abs(B.y - PH / 2) < GW / 2 - 3) { scoreGoal(B.x < 0 ? 1 : 0); return; }
  // traps
  let best = null, bd = 1e9;
  for (const p of G.all) {
    if (p.cd > 0 || p.frz > 0) continue;
    const d = hyp(B.x - p.x, B.y - (p.y - 2)), rr = p.role === 'GK' ? (((G.pen && G.pen.team === p.team && G.t < G.pen.until + 0.3) ? 16 : 12) * (p.trait === 'keeper' ? 1 + TRAIT_BOOST : 1)) : 7.5 * (p.trait === 'tackler' && p.team !== B.lastTeam ? 1 + TRAIT_BOOST : 1) * (p.slideT > 0 ? 2.1 : 1);
    if (d < rr && d < bd) { bd = d; best = p; }
  }
  if (best) {
    const p = best, s = hyp(B.vx, B.vy);
    if (p.role === 'GK' && s > 150 && p.team !== B.lastTeam) {
      const ch = clamp((0.62 + (p.rating - 65) * 0.006 - Math.max(0, s - 300) * 0.0009) * (p.trait === 'keeper' ? 1 + TRAIT_BOOST : 1), 0.25, p.trait === 'keeper' ? 0.97 : 0.9);
      if (rand() < ch) { G.stats.saves++; traitFire(p, 'SAVE'); giveBall(p); p.frz = 0.9; p.mustPass = true; burst(B.x, B.y, 8, ['#fff', '#ffd23f'], 60, 40); banner('SAVE!', 0.9, '#9be7ff'); }
      else { p.cd = 0.4; if (B.indirect && p !== B.taker) B.indirect = false; if (rand() < 0.5) { B.vx = -B.vx * 0.35; B.vy = (rand() - 0.5) * 240; B.lastTeam = p.team; B.pass = null; banner('SAVE!', 0.9, '#9be7ff'); } }
    } else if (s <= 130) { giveBall(p); if (p.trait === 'tackler' && p.team !== B.lastTeam) traitFire(p, 'CUT'); }
    else {
      const cut = p.trait === 'tackler' && p.team !== B.lastTeam;
      const ctrl = clamp((0.92 - (s - 130) / 520 + (p.rating - 70) * 0.004 + (B.pass === p ? 0.25 : 0) + (p.slideT > 0 ? 0.35 : 0)) * (cut ? 1 + TRAIT_BOOST : 1), 0.2, 0.99);
      if (rand() < ctrl) { giveBall(p); if (cut) { traitFire(p, 'CUT'); banner('INTERCEPT!', 0.8, '#ffb74d'); } }
      else { const a = Math.atan2(B.vy, B.vx) + (rand() - 0.5) * 1.8; B.vx = Math.cos(a) * s * 0.55; B.vy = Math.sin(a) * s * 0.55; p.cd = 0.3; B.lastTeam = p.team; B.lastPlayer = p; B.pass = null; if (B.indirect && p !== B.taker) B.indirect = false; }
    }
    if (B.owner) return;
  }
  // goal line / posts
  const cy = PH / 2;
  if (B.x < 0 || B.x > PW) {
    const side = B.x < 0 ? 0 : 1, dy = Math.abs(B.y - cy);
    const crossing = (px >= 0 && B.x < 0) || (px <= PW && B.x > PW);
    if (crossing && Math.abs(dy - GW / 2) < 3) { B.vx = -B.vx * 0.5; B.vy += (rand() - 0.5) * 80; B.x = side ? PW - 1 : 1; B.lastTeam = 1 - side; burst(B.x, B.y, 6, ['#fff'], 50, 30); banner('POST!', 0.8, '#fff'); return; }
    if (dy < GW / 2 && !B.indirect) { scoreGoal(1 - side); return; }
    // out behind the line
    const gx = side ? PW : 0;
    if (B.lastTeam === side) {
      const T = G.teams[1 - side], cyy = B.y < cy ? 3 : PH - 3, cxx = side ? PW - 3 : 3;
      restartAt(T, cxx, cyy, nearestField(T, cxx, cyy), 'CORNER', 1.3);
    } else {
      const T = G.teams[side];
      restartAt(T, side ? PW - 26 : 26, cy, T.players[0], 'GOAL KICK', 1.4);
    }
    return;
  }
  if (B.y < 0 || B.y > PH) {
    const T = G.teams[1 - B.lastTeam], sx = clamp(B.x, 12, PW - 12), sy = B.y < 0 ? -2 : PH + 2;
    restartAt(T, sx, sy, nearestField(T, sx, sy), 'THROW IN', 1.1);
  }
}
function tackles() {
  const o = B.owner; if (!o || B.prot > 0 || o.grace > 0 || o.frz > 0) return;
  for (const p of G.all) {
    if (p.team === o.team || p.tcd > 0 || p.frz > 0 || p.role === 'GK' && false) continue;
    if (hyp(p.x - o.x, p.y - o.y) > (p.slideT > 0 ? 17 : 10) * (p.trait === 'tackler' ? 1 + TRAIT_BOOST : 1)) continue;
    p.tcd = p.team === 0 && !G.bot ? 0.6 : 0.8;
    if (rand() < clamp(0.12 + (68 - p.rating) * 0.002, 0.06, 0.2) + (p.slideT > 0 ? 0.1 : 0)) { foul(p, o); return; }
    let pw = clamp(0.36 + (p.rating - o.rating) * 0.012, 0.15, 0.65);
    if (o.team === 0 && !G.bot) pw *= 0.85;
    if (p.trait === 'tackler') pw = Math.min(0.9, pw * (1 + TRAIT_BOOST));
    if (p.slideT > 0) pw = Math.min(0.92, pw * 1.5 + 0.2);
    if (rand() < pw) {
      G.stats.tackles++;
      if (rand() < Math.min(0.97, 0.7 * (p.trait === 'tackler' ? 1 + TRAIT_BOOST : 1))) { giveBall(p); if (p.trait === 'tackler') traitFire(p, 'TACKLE'); p.cd = 0; burst(p.x, p.y, 4, ['#cfd8c4'], 40, 25); sfx('tackle'); }
      else { B.owner = null; const a = rand() * 6.283; B.x = o.x; B.y = o.y; B.vx = Math.cos(a) * 90; B.vy = Math.sin(a) * 90; B.lastTeam = p.team; B.pass = null; o.cd = 0.5; sfx('tackle'); }
      return;
    }
  }
}

/* ---------- fouls & set pieces ---------- */
function clearSet() { if (B.set && G) for (const q of G.all) q.setHold = false; B.set = null; }
function autoSetPiece() {
  const st = B.set; if (!st) return;
  const p = st.taker;
  if (!p || B.owner !== p) { clearSet(); return; }
  const T = teamOf(p), O = oppOf(p), gx = T.dir > 0 ? PW : 0, dgg = hyp(gx - p.x, PH / 2 - p.y);
  if (p.frz > 0) return;
  if (st.kind === 'pen' || (st.kind === 'direct' && dgg < 300)) aiShoot(p, T, O);
  else { const b = bestPass(p, T, O, 330); aiPass(p, T, O, b ? b.q : T.players[5 + ((rand() * 3) | 0)]); }
}
function foul(f, v) {
  const kind = rand() < 0.22 ? 'indirect' : 'direct';
  const T = G.teams[v.team], F = G.teams[f.team], ownX = F.side === 0 ? 0 : PW;
  let x = clamp(v.x, 8, PW - 8), y = clamp(v.y, 8, PH - 8);
  const inBox = Math.abs(x - ownX) < 130 && Math.abs(y - PH / 2) < 125;
  const col = T.side === 0 ? '#7bff8a' : '#ff9a9a';
  G.stats.fouls++;
  if (inBox && kind === 'direct') { penaltyKick(T, col); return; }
  if (inBox && Math.abs(x - ownX) < 44) x = ownX + (F.side === 0 ? 44 : -44);
  freeKick(T, kind, x, y, col);
}
function penaltyKick(T, col) {
  G.stats.pens++;
  const aX = T.dir > 0 ? PW : 0, spotX = aX - T.dir * 88;
  let taker = null, br = -1; for (const q of T.players) if (q.role !== 'GK' && q.rating > br) { br = q.rating; taker = q; }
  restartAt(T, spotX - T.dir * 6, PH / 2, taker, 'PENALTY!', 2.0, '#ffd23f', 1.6);
  taker.fx = T.dir; taker.fy = 0;
  B.set = { kind: 'pen', team: T.side, taker };
  const list = G.all.filter(q => q !== taker && q.role !== 'GK').sort((a, b) => a.idx - b.idx || a.team - b.team);
  list.forEach((q, i) => { q.x = aX - T.dir * (165 + (i % 2) * 26); q.y = 40 + i * (PH - 80) / (list.length - 1); q.vx = q.vy = 0; q.setHold = true; });
  const gk = G.teams[1 - T.side].players[0]; gk.x = aX - T.dir * 4; gk.y = PH / 2; gk.vx = gk.vy = 0; gk.setHold = true;
}
function freeKick(T, kind, x, y, col) {
  G.stats[kind]++;
  const O = G.teams[1 - T.side], taker = nearestField(T, x, y);
  restartAt(T, x - T.dir * 6, y, taker, kind === 'direct' ? 'FOUL! FREE KICK' : 'FOUL! INDIRECT KICK', 1.6, col, 1.6);
  taker.fx = T.dir; taker.fy = 0;
  B.set = { kind, team: T.side, taker, x, y }; B.indirect = kind === 'indirect'; B.taker = taker;
  const gX = T.dir > 0 ? PW : 0, gd = hyp(gX - x, PH / 2 - y), wall = [];
  if (kind === 'direct' && gd > 110 && gd < 340) {
    const c = O.players.filter(q => q.role !== 'GK').sort((a, b) => hyp(a.x - x, a.y - y) - hyp(b.x - x, b.y - y)).slice(0, 3);
    const ux = (gX - x) / gd, uy = (PH / 2 - y) / gd;
    c.forEach((q, i) => { q.x = clamp(x + ux * 80 - uy * (i - 1) * 11, 4, PW - 4); q.y = clamp(y + uy * 80 + ux * (i - 1) * 11, 4, PH - 4); wall.push(q); });
  }
  for (const q of O.players) {
    if (q.role === 'GK') continue;
    if (!wall.includes(q)) { const d = hyp(q.x - x, q.y - y); if (d < 80 && d > 0.1) { q.x = clamp(x + (q.x - x) / d * 84, 4, PW - 4); q.y = clamp(y + (q.y - y) / d * 84, 4, PH - 4); } }
    q.vx = q.vy = 0; q.setHold = true;
  }
}

/* ---------- main step ---------- */
function step(dt) {
  if (!G || G.paused) return;
  G.t += dt;
  if (G.banner) { G.banner.t -= dt; if (G.banner.t <= 0) G.banner = null; }
  for (const q of G.all) if (q.tfx > 0) q.tfx -= dt;
  for (let i = G.parts.length - 1; i >= 0; i--) {
    const q = G.parts[i]; q.life -= dt; if (q.life <= 0) { G.parts.splice(i, 1); continue; }
    q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt; q.vz -= 380 * dt; if (q.z < 0) { q.z = 0; q.vz *= -0.3; q.vx *= 0.7; q.vy *= 0.7; }
  }
  if (G.mode === 'intro') {
    G.modeT -= dt; integrateStatic(dt);
    if (G.modeT <= 0) { G.mode = 'play'; sfx('whistle'); if (B.owner) triggerFreeze(B.owner); }
    updateCam(dt); return;
  }
  if (G.mode === 'ended') { G.endT -= dt; integrateStatic(dt); updateCam(dt); if (G.endT <= 0) finish(); return; }
  if (G.mode === 'play' && G.freezeT > 0) { G.freezeT = Math.max(0, G.freezeT - dt); updateCam(dt); if (G.freezeT === 0) autoSetPiece(); return; }
  G.clock += dt;
  if (G.clock >= MATCH_SECONDS) {
    G.clock = MATCH_SECONDS; G.mode = 'ended'; G.endT = 3; banner('FULL TIME', 3, '#fff'); sfx('whistle_end'); if (window.FFMSfx) FFMSfx.ambStop();
    for (const p of G.all) p.dvx = p.dvy = 0; inp.aim = null; return;
  }
  if (G.mode === 'goal') {
    G.modeT -= dt; integrate(dt * 0.3); updateBall(dt); updateCam(dt);
    for (const p of G.all) { p.dvx = p.dvy = 0; }
    if (G.modeT <= 0) { G.mode = 'play'; setupKickoff(G.teams[G.kickTeam]); banner('KICK OFF', 1.2); sfx('whistle'); }
    return;
  }
  for (const p of G.all) { p.cd = Math.max(0, p.cd - dt); p.tcd = Math.max(0, p.tcd - dt); p.frz = Math.max(0, p.frz - dt); p.grace = Math.max(0, p.grace - dt); p.slideCd = Math.max(0, (p.slideCd || 0) - dt); p.lieT = Math.max(0, (p.lieT || 0) - dt); }
  B.prot = Math.max(0, B.prot - dt); G.switchT = Math.max(0, G.switchT - dt);
  assignRoles();
  if (G.press) { G.press.t -= dt; if (G.press.t <= 0 || (B.owner && B.owner.team === 0)) G.press = null; }
  if (!G.bot) pickActive(); else G.active = null;
  G.sprintNow = false; if (G.stam == null) G.stam = 1;
  for (const p of G.all) control(p, dt);
  G.stam = clamp(G.stam + (G.sprintNow ? -0.3 : 0.14) * dt, 0, 1);
  integrate(dt); updateBall(dt); tackles(); updateCam(dt);
}
function integrateStatic(dt) { for (const p of G.all) { p.vx = p.vy = 0; } updateBall(dt); }
function updateCam(dt) {
  const c = G.cam; let tx, ty;
  if (B.owner) { tx = B.owner.x + B.owner.fx * 40; ty = B.owner.y + B.owner.fy * 20; }
  else { tx = B.x + clamp(B.vx * 0.28, -80, 80); ty = B.y + clamp(B.vy * 0.2, -40, 40); }
  tx -= VW / 2; ty -= VH / 2;
  if (G.snapCam) { c.x = tx; c.y = ty; G.snapCam = false; } else { const f = 1 - Math.exp(-4.5 * dt); c.x += (tx - c.x) * f; c.y += (ty - c.y) * f; }
  c.x = clamp(c.x, -M, PW + M - VW); c.y = clamp(c.y, -M, PH + M - VH);
}

/* ---------- rendering ---------- */
function ring(c, x, y, r, col, sz) {
  c.fillStyle = col; const n = Math.max(12, Math.ceil(6.283 * r / (sz + 1)));
  for (let i = 0; i < n; i++) { const a = i / n * 6.283; c.fillRect(Math.round(x + Math.cos(a) * r), Math.round(y + Math.sin(a) * r), sz, sz); }
}
function drawPlayer(c, p, sx, sy, isActive) {
  if (p.lieT > 0) {
    c.save(); c.translate(sx, sy - 3); c.rotate(p.fx >= 0 ? -1.5 : 1.5); drawPlayerBase(c, p, 0, 3, false); c.restore();
    c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(sx - 9, sy - 1, 18, 3);
    return;
  }
  drawPlayerBase(c, p, sx, sy, isActive);
}
function drawPlayerBase(c, p, sx, sy, isActive) {
  const k = p.kit, moving = hyp(p.vx, p.vy) > 12, fr = moving ? ((p.anim | 0) & 1) : 2;
  c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(sx - 4, sy - 1, 9, 3);
  const O = '#12141c';
  // legs
  const lh = fr === 0 ? 5 : (fr === 1 ? 3 : 5), rh = fr === 1 ? 5 : (fr === 0 ? 3 : 5);
  c.fillStyle = O; c.fillRect(sx - 4, sy - 6, 4, 7); c.fillRect(sx, sy - 6, 4, 7);
  c.fillStyle = k.sock; c.fillRect(sx - 3, sy - lh, 2, lh); c.fillRect(sx + 1, sy - rh, 2, rh);
  c.fillStyle = '#e9e9e9'; c.fillRect(sx - 3, sy - 1, 2, 1); c.fillRect(sx + 1, sy - 1, 2, 1);
  // shorts + torso
  c.fillStyle = O; c.fillRect(sx - 5, sy - 15, 10, 10);
  c.fillStyle = k.short; c.fillRect(sx - 4, sy - 7, 8, 3);
  c.fillStyle = k.shirt; c.fillRect(sx - 4, sy - 14, 8, 7);
  if (k.grid) for (let gi = 0; gi < 56; gi++) { c.fillStyle = k.grid[gi]; c.fillRect(sx - 4 + (gi % 8), sy - 14 + ((gi / 8) | 0), 1, 1); }
  if (k.stripe) { c.fillStyle = k.stripe; c.fillRect(sx - 3, sy - 14, 1, 7); c.fillRect(sx - 1, sy - 14, 1, 7); c.fillRect(sx + 1, sy - 14, 1, 7); }
  // arms
  const sw = fr === 0 ? 1 : (fr === 1 ? -1 : 0);
  c.fillStyle = O; c.fillRect(sx - 7, sy - 13 + sw, 3, 6); c.fillRect(sx + 4, sy - 13 - sw, 3, 6);
  c.fillStyle = k.sleeve || k.shirt; c.fillRect(sx - 6, sy - 12 + sw, 2, 2); c.fillRect(sx + 4, sy - 12 - sw, 2, 2);
  c.fillStyle = k.glove ? '#fff' : p.skin; c.fillRect(sx - 6, sy - 10 + sw, 2, 2); c.fillRect(sx + 4, sy - 10 - sw, 2, 2);
  // head
  c.fillStyle = O; c.fillRect(sx - 4, sy - 21, 8, 8);
  c.fillStyle = p.skin; c.fillRect(sx - 3, sy - 20, 6, 6);
  const up = p.fy < -0.5 && Math.abs(p.fy) > Math.abs(p.fx), side = Math.abs(p.fx) >= Math.abs(p.fy);
  c.fillStyle = p.hair;
  if (up) c.fillRect(sx - 3, sy - 20, 6, 6);
  else if (side) { c.fillRect(sx - 3, sy - 20, 6, 2); c.fillRect(p.fx > 0 ? sx - 3 : sx + 1, sy - 18, 2, 4); }
  else c.fillRect(sx - 3, sy - 20, 6, 2);
  c.fillStyle = '#1b1b24';
  if (!up) { if (side) c.fillRect(p.fx > 0 ? sx + 1 : sx - 2, sy - 17, 1, 1); else { c.fillRect(sx - 2, sy - 17, 1, 1); c.fillRect(sx + 1, sy - 17, 1, 1); } }
  if (isActive) {
    const bob = Math.round(Math.sin(G.t * 8) * 1.5);
    c.fillStyle = '#12141c'; c.fillRect(sx - 4, sy - 31 + bob, 9, 5); c.fillRect(sx - 2, sy - 27 + bob, 5, 3);
    c.fillStyle = '#ffd23f'; c.fillRect(sx - 3, sy - 30 + bob, 7, 2); c.fillRect(sx - 2, sy - 28 + bob, 5, 1); c.fillRect(sx - 1, sy - 27 + bob, 3, 1);
  }
}
function drawBall(c, sx, sy) {
  c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(sx - 2, sy, 5, 2);
  c.fillStyle = '#14161f'; c.fillRect(sx - 3, sy - 5, 6, 6);
  c.fillStyle = '#fff'; c.fillRect(sx - 2, sy - 4, 4, 4);
  c.fillStyle = '#14161f'; c.fillRect(sx - 1, sy - 3, 1, 1); c.fillRect(sx, sy - 2, 1, 1);
}
function aimGeom() {
  const a = inp.aim, p = G.active;
  if (!a || !p || G.mode !== 'play' || B.owner !== p || p.team !== 0 || p.frz > 0 || G.bot) return null;
  const dx = a.x - a.ox, dy = a.y - a.oy, lenLow = hyp(dx, dy), len = lenLow * S;
  const thr = 24, max = clamp(canvas.getBoundingClientRect().width * 0.3, 110, 220);
  const t = clamp((len - thr) / (max - thr), 0, 1);
  if (len < thr) return { short: true, ox: a.ox, oy: a.oy, dx, dy };
  return { short: false, t, ox: a.ox, oy: a.oy, res: computePass(p, dx, dy, t, false), dx, dy };
}
function drawTraitLabel(c, sx, sy, hot, tr, why) {
  const M_ = TRAIT_META[tr] || TRAIT_META.clinical, txt = M_[0] + ' +39%', w = textW(txt, 1) + 18, x0 = Math.round(sx - w / 2), y0 = sy - 54 - (hot ? Math.round(Math.sin(G.t * 14) * 1) : 0);
  c.fillStyle = '#12141c'; c.fillRect(x0 - 2, y0 - 2, w + 4, 15);
  c.fillStyle = hot ? M_[2] : M_[1]; c.fillRect(x0, y0, w, 11);
  c.fillStyle = '#12141c'; c.fillRect(sx - 4, y0 + 11, 9, 4); c.fillRect(sx - 2, y0 + 15, 5, 2);
  c.fillStyle = hot ? M_[2] : M_[1]; c.fillRect(sx - 3, y0 + 11, 7, 3); c.fillRect(sx - 1, y0 + 14, 3, 2);
  c.fillStyle = '#fff'; for (let r = 0; r < 5; r++) c.fillRect(x0 + 3, y0 + 2 + r, 5 - r, 1);
  drawText(c, txt, x0 + 11, y0 + 3, 1, '#fff', 'rgba(0,0,0,.45)');
}
function render() {
  const c = ctx; c.imageSmoothingEnabled = false;
  const cx = Math.round(G.cam.x), cy = Math.round(G.cam.y);
  c.drawImage(world, cx + M, cy + M, VW, VH, 0, 0, VW, VH);
  // ball trail
  for (let i = 0; i < B.trail.length; i++) { c.fillStyle = 'rgba(255,255,255,' + (0.1 + i * 0.08) + ')'; c.fillRect(Math.round(B.trail[i][0] - cx) - 1, Math.round(B.trail[i][1] - cy) - 3, 2, 2); }
  // carrier ring + aim
  const act = G.active, ag = aimGeom();
  if (!G.bot && act && B.owner === act && G.mode === 'play') {
    const sx = Math.round(act.x - cx), sy = Math.round(act.y - cy);
    ring(c, sx, sy - 2, 13, (G.t * 3 | 0) % 2 ? 'rgba(255,255,255,.75)' : 'rgba(255,210,63,.9)', 2);
  }
  if (B.set && B.owner === B.set.taker) ring(c, Math.round(B.x - cx), Math.round(B.y - cy) - 2, 7, (G.t * 4 | 0) % 2 ? '#fff' : '#ffd23f', 2);
  // entities sorted by depth
  const list = G.all.slice(); list.sort((a, b) => a.y - b.y);
  let ballDrawn = false;
  const by = B.y;
  for (const p of list) {
    if (!ballDrawn && by <= p.y) { drawBall(c, Math.round(B.x - cx), Math.round(B.y - cy)); ballDrawn = true; }
    const sx = Math.round(p.x - cx), sy = Math.round(p.y - cy);
    if (sx < -20 || sx > VW + 20 || sy < -10 || sy > VH + 40) continue;
    drawPlayer(c, p, sx, sy, p === act && !G.bot);
  }
  if (!ballDrawn) drawBall(c, Math.round(B.x - cx), Math.round(B.y - cy));
  // particles
  for (const q of G.parts) { c.fillStyle = q.col; c.globalAlpha = clamp(q.life / 0.5, 0, 1); c.fillRect(Math.round(q.x - cx), Math.round(q.y - cy - q.z), q.s, q.s); }
  c.globalAlpha = 1;
  // trait markers above every trait player; full label when active / triggered
  for (const q of G.all) {
    if (!q.trait || !TRAIT_META[q.trait]) continue;
    const sx = Math.round(q.x - cx), sy = Math.round(q.y - cy);
    if (sx < -30 || sx > VW + 30 || sy < -30 || sy > VH + 30) continue;
    const hot = q.tfx > 0, TM = TRAIT_META[q.trait];
    const sprint = q.trait === 'speed' && hyp(q.vx || 0, q.vy || 0) > maxSpeed(q) * 0.85;
    const full = hot || sprint || q === act || B.owner === q;
    if (hot) ring(c, sx, sy - 2, 9 + ((G.t * 30) % 8), TM[2], 2);
    if (full) drawTraitLabel(c, sx, sy, hot || (ag && !ag.short && ag.res.shot && q === act && q.trait === 'clinical'), q.trait, q.tfxWhy);
    else { // small persistent chevron marker
      const my = sy - 34 - Math.round(Math.sin(G.t * 5 + q.x) * 1);
      c.fillStyle = '#12141c'; c.fillRect(sx - 5, my - 1, 11, 4); c.fillRect(sx - 3, my + 3, 7, 3); c.fillRect(sx - 1, my + 6, 3, 2);
      c.fillStyle = TM[1]; c.fillRect(sx - 4, my, 9, 2); c.fillRect(sx - 2, my + 2, 5, 2); c.fillRect(sx, my + 4, 1, 1);
      c.fillStyle = TM[2]; c.fillRect(sx - 4, my, 9, 1);
    }
  }
  // aim line
  if (ag) {
    c.fillStyle = 'rgba(255,255,255,.18)'; ring(c, ag.ox, ag.oy, 16, 'rgba(255,255,255,.55)', 2);
    c.fillStyle = '#fff'; c.fillRect(ag.ox - 1, ag.oy - 1, 3, 3);
    if (!ag.short) {
      const r = ag.res, sx0 = Math.round(act.x - cx), sy0 = Math.round(act.y - cy - 2);
      const Ln = Math.min(r.reach * 0.6, 260), ux = r.dx, uy = r.dy;
      for (let pass = 0; pass < 2; pass++) {
        c.fillStyle = pass === 0 ? 'rgba(0,0,0,.55)' : '#ffffff';
        for (let i = 8; i < Ln; i += 1) { if (i % 6 > 3 && pass === 1 && false) continue; c.fillRect(Math.round(sx0 + ux * i) + (pass ? 0 : 1), Math.round(sy0 + uy * i) + (pass ? 0 : 1), 2, 2); }
        const ex = sx0 + ux * Ln, ey = sy0 + uy * Ln;
        for (const sg of [-1, 1]) { const a = Math.atan2(uy, ux) + Math.PI + sg * 0.5; for (let i = 0; i < 9; i++) c.fillRect(Math.round(ex + Math.cos(a) * i) + (pass ? 0 : 1), Math.round(ey + Math.sin(a) * i) + (pass ? 0 : 1), 2, 2); }
      }
      if (r.target) {
        const tx = Math.round(r.target.x - cx), ty = Math.round(r.target.y - cy);
        c.fillStyle = '#fff';
        c.fillRect(tx - 9, ty - 24, 4, 2); c.fillRect(tx - 9, ty - 24, 2, 4); c.fillRect(tx + 6, ty - 24, 4, 2); c.fillRect(tx + 8, ty - 24, 2, 4);
        c.fillRect(tx - 9, ty + 1, 4, 2); c.fillRect(tx - 9, ty - 1, 2, 4); c.fillRect(tx + 6, ty + 1, 4, 2); c.fillRect(tx + 8, ty - 1, 2, 4);
      } else if (r.shot) drawTextC(c, 'SHOOT!', sx0 + ux * Ln, Math.round(sy0 + uy * Ln) - 12, 1, '#ffd23f', '#000');
      // power bar
      const bx = ag.ox - 14, byy = ag.oy + 22;
      c.fillStyle = '#000'; c.fillRect(bx - 1, byy - 1, 30, 5); c.fillStyle = '#444'; c.fillRect(bx, byy, 28, 3);
      c.fillStyle = ag.t > 0.8 ? '#ff5a5a' : (ag.t > 0.45 ? '#ffd23f' : '#7bff8a'); c.fillRect(bx, byy, Math.round(28 * ag.t), 3);
    } else drawTextC(c, 'DRAG', ag.ox, ag.oy + 22, 1, '#fff', '#000');
  }
  // pad charge power bar
  if (pad.chg && act && B.owner === act && G.mode === 'play') {
    const t = chgT(pad.chg.k), sx = Math.round(act.x - cx), sy = Math.round(act.y - cy), bx = sx - 15, byy = sy + 6;
    c.fillStyle = '#000'; c.fillRect(bx - 1, byy - 1, 32, 6); c.fillStyle = '#444'; c.fillRect(bx, byy, 30, 4);
    c.fillStyle = t > 0.8 ? '#ff5a5a' : (t > 0.45 ? '#ffd23f' : '#7bff8a'); c.fillRect(bx, byy, Math.round(30 * t), 4);
  }
  // joystick
  if (inp.joy) {
    const j = inp.joy, dx = j.x - j.ox, dy = j.y - j.oy, l = hyp(dx, dy), m = Math.min(l, 26), kx = l ? j.ox + dx / l * m : j.ox, ky = l ? j.oy + dy / l * m : j.oy;
    ring(c, j.ox, j.oy, 26, 'rgba(255,255,255,.5)', 2);
    c.fillStyle = 'rgba(255,255,255,.7)'; c.fillRect(Math.round(kx) - 6, Math.round(ky) - 6, 12, 12);
    c.fillStyle = 'rgba(0,0,0,.5)'; c.fillRect(Math.round(kx) - 4, Math.round(ky) - 4, 8, 8);
  }
  drawHUD(c);
}
function drawHUD(c) {
  const H = G.home, A = G.away;
  // scoreboard
  const bw = 214, bx = Math.round(VW / 2 - bw / 2);
  c.fillStyle = '#0c0c14'; c.fillRect(bx - 2, 0, bw + 4, 34);
  c.fillStyle = '#293370'; c.fillRect(bx, 0, bw, 32);
  c.fillStyle = KITS[0].shirt; c.fillRect(bx, 0, 4, 22); c.fillStyle = KITS[1].shirt; c.fillRect(bx + bw - 4, 0, 4, 22);
  drawText(c, H.name.slice(0, 7), bx + 8, 8, 2, '#fff', '#0c0c14');
  const an = A.name.slice(0, 7); drawText(c, an, bx + bw - 8 - textW(an, 2), 8, 2, '#fff', '#0c0c14');
  drawTextC(c, H.score + '-' + A.score, VW / 2, 5, 3, '#ffd23f', '#0c0c14');
  const rem = Math.max(0, Math.ceil(MATCH_SECONDS - G.clock)), mm = (rem / 60 | 0), ss = rem % 60;
  drawTextC(c, (mm < 10 ? '0' : '') + mm + ':' + (ss < 10 ? '0' : '') + ss, VW / 2, 24, 1, '#fff');
  // minimap
  const mx = 4, my = 4, ms = 0.07, mw = Math.round(PW * ms), mh = Math.round(PH * ms);
  c.fillStyle = 'rgba(0,0,0,.6)'; c.fillRect(mx - 1, my - 1, mw + 2, mh + 2);
  c.fillStyle = 'rgba(60,140,50,.75)'; c.fillRect(mx, my, mw, mh);
  c.fillStyle = 'rgba(255,255,255,.6)'; c.fillRect(mx + (mw >> 1), my, 1, mh);
  const vx = Math.round((G.cam.x) * ms), vy = Math.round((G.cam.y) * ms);
  c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 1; c.strokeRect(mx + clamp(vx, 0, mw) + .5, my + clamp(vy, 0, mh) + .5, Math.min(Math.round(VW * ms), mw), Math.min(Math.round(VH * ms), mh));
  for (const p of G.all) { c.fillStyle = KITS[p.team].shirt; c.fillRect(mx + Math.round(clamp(p.x, 0, PW) * ms), my + Math.round(clamp(p.y, 0, PH) * ms), 2, 2); }
  c.fillStyle = '#fff'; c.fillRect(mx + Math.round(clamp(B.x, 0, PW) * ms), my + Math.round(clamp(B.y, 0, PH) * ms), 2, 2);
  if (G.freezeT > 0) {
    const w = 120, x0 = Math.round(VW / 2 - w / 2), y0 = 38, f = G.freezeT / FREEZE_SECONDS;
    c.fillStyle = 'rgba(0,0,0,.65)'; c.fillRect(x0 - 2, y0 - 2, w + 4, 26);
    drawTextC(c, (B.set ? (B.set.kind === 'pen' ? 'AIM THE PENALTY ' : 'AIM THE FREE KICK ') : 'AIM YOUR PASS ') + Math.ceil(G.freezeT), VW / 2, y0 + 1, 1, '#fff');
    c.fillStyle = '#444'; c.fillRect(x0, y0 + 11, w, 8);
    c.fillStyle = f > 0.5 ? '#7bff8a' : (f > 0.25 ? '#ffd23f' : '#ff5a5a'); c.fillRect(x0, y0 + 11, Math.round(w * f), 8);
  }
  // active player panel
  const p = G.active;
  if (p && !G.bot) {
    c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(0, VH - 26, 120, 26);
    drawText(c, p.num + ' ' + p.name.slice(0, 13), 4, VH - 22, 1, '#fff');
    if (p.trait) { c.fillStyle = '#e53935'; for (let r = 0; r < 9; r++) c.fillRect(120 - (9 - r), r, 9 - r, 1); }
    drawText(c, 'OVR ' + p.rating, 4, VH - 13, 1, '#ffd23f');
    const stars = clamp(Math.round((p.rating - 50) / 10), 0, 5);
    for (let i = 0; i < 5; i++) { c.fillStyle = i < stars ? '#ffd23f' : '#555'; const sx = 48 + i * 9, sy = VH - 14; c.fillRect(sx + 2, sy, 1, 7); c.fillRect(sx, sy + 2, 5, 3); c.fillRect(sx + 1, sy + 1, 3, 5); }
  }
  // banner
  if (G.banner) {
    const b = G.banner, a = clamp(b.t / 0.3, 0, 1);
    c.globalAlpha = a;
    const sc = b.text.length > 7 ? 3 : 4, w = textW(b.text, sc) + 16;
    c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(Math.round(VW / 2 - w / 2), Math.round(VH * 0.36), w, sc * 5 + 12);
    drawTextC(c, b.text, VW / 2, Math.round(VH * 0.36) + 6, sc, b.col, '#000');
    if (b.text === 'GOAL!' && G.scorerLabel) drawTextC(c, G.scorerLabel.slice(0, 22), VW / 2, Math.round(VH * 0.36) + sc * 5 + 18, 1, '#fff', '#000');
    c.globalAlpha = 1;
  }
}

/* ---------- input ---------- */
function toLow(e) { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * VW / r.width, y: (e.clientY - r.top) * VH / r.height }; }
function onDown(e) {
  if (!G || G.paused) return; e.preventDefault();
  try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
  if (padOn()) return;
  const p = toLow(e), touch = e.pointerType !== 'mouse';
  if (touch && p.x < VW * 0.36 && p.y > VH * 0.3 && !inp.joy) { inp.joy = { id: e.pointerId, ox: p.x, oy: p.y, x: p.x, y: p.y }; return; }
  if (!inp.aim) inp.aim = { id: e.pointerId, ox: p.x, oy: p.y, x: p.x, y: p.y };
}
function onMove(e) {
  const p = toLow(e);
  if (inp.joy && inp.joy.id === e.pointerId) { inp.joy.x = p.x; inp.joy.y = p.y; }
  if (inp.aim && inp.aim.id === e.pointerId) { inp.aim.x = p.x; inp.aim.y = p.y; }
}
function onUp(e) {
  if (inp.joy && inp.joy.id === e.pointerId) inp.joy = null;
  if (inp.aim && inp.aim.id === e.pointerId) {
    const a = inp.aim; a.x = toLow(e).x || a.x; a.y = toLow(e).y || a.y;
    const g = aimGeom(); inp.aim = null;
    if (g && !g.short) humanKick(g.dx, g.dy, g.t);
  }
}
function humanKick(dx, dy, t) {
  const p = G.active; if (!p || B.owner !== p || p.team !== 0 || p.frz > 0 || G.mode !== 'play') return;
  const r = computePass(p, dx, dy, t, true);
  G.freezeT = 0;
  kick(p, r.dx, r.dy, r.speed, r.target, r.shot);
}
function quickPass() {
  const p = G.active; if (!p || B.owner !== p) return;
  const [ix, iy] = inputVec(); const dx = hyp(ix, iy) > 0.2 ? ix : p.fx, dy = hyp(ix, iy) > 0.2 ? iy : p.fy;
  humanKick(dx, dy, 0.45);
}
const KEYMAP = { ArrowLeft: 'l', a: 'l', A: 'l', ArrowRight: 'r', d: 'r', D: 'r', ArrowUp: 'u', w: 'u', W: 'u', ArrowDown: 'd', s: 'd', S: 'd' };
function recalcKeys() { inp.kx = (inp.keys.r ? 1 : 0) - (inp.keys.l ? 1 : 0); inp.ky = (inp.keys.d ? 1 : 0) - (inp.keys.u ? 1 : 0); }
function onKeyDown(e) {
  if (!G) return;
  if (e.key === 'Escape') { togglePause(); e.preventDefault(); return; }
  if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); if (!e.repeat) quickPass(); return; }
  const k = KEYMAP[e.key]; if (k) { inp.keys[k] = true; recalcKeys(); e.preventDefault(); }
}
function onKeyUp(e) { const k = KEYMAP[e.key]; if (k) { inp.keys[k] = false; recalcKeys(); } }

/* ---------- pad controls (joystick + A/B/C) ---------- */
function padReset() { pad.chg = null; pad.jx = pad.jy = 0; pad.cH[1] = pad.cH[2] = false; pad.c = false; const k = document.getElementById('lp-knob'); if (k) k.style.transform = ''; const pe = document.getElementById('lm-pad'); if (pe) { pe.classList.remove('on'); pe.querySelectorAll('.dn').forEach(e => e.classList.remove('dn')); } if (G) G.press = null; }
const CHG_FULL = 800, chgT = k => (pad.chg && pad.chg.k === k) ? clamp((performance.now() - pad.chg.t0) / CHG_FULL, 0.12, 1) : 0.12;
function padShoot(t) {
  const p = G && G.active; if (!p || B.owner !== p || p.team !== 0 || p.frz > 0 || G.mode !== 'play') return;
  const T = teamOf(p), gx = T.dir > 0 ? PW : 0, [ix, iy] = inputVec(), sm = hyp(ix, iy);
  let dx = gx - p.x, dy = PH / 2 + (sm > 0.2 ? iy * (GW / 2 - 12) : 0) - p.y;
  if (sm > 0.5 && ix * T.dir > 0.3) { dx = ix; dy = iy; }
  const r = computePass(p, dx, dy, t == null ? 1 : t, true, 'shot'); G.freezeT = 0;
  kick(p, r.dx, r.dy, r.speed, null, true);
}
function padPass(t) { const p = G && G.active; if (!p || B.owner !== p || p.team !== 0) return; const [ix, iy] = inputVec(), m = hyp(ix, iy) > 0.2; humanKick(m ? ix : p.fx, m ? iy : p.fy, t == null ? 0.45 : t); }
function padSlide() {
  const p = G && G.active; if (!p || p.team !== 0 || G.mode !== 'play' || p.slideT > 0 || p.slideCd > 0 || p.frz > 0 || p.role === 'GK' || (B.owner && B.owner.team === 0)) return;
  let [dx, dy] = inputVec(); if (hyp(dx, dy) < 0.3) { const tg = (B.owner && B.owner.team === 1) ? B.owner : B; dx = tg.x - p.x; dy = tg.y - p.y; }
  let l = hyp(dx, dy); if (l < 1) { dx = p.fx; dy = p.fy; l = 1; }
  p.sdx = dx / l; p.sdy = dy / l; p.fx = p.sdx; p.fy = p.sdy; p.slideT = 0.5; p.slideCd = 1.5; p.lieT = 0.95; G.press = null;
  sfx('tackle'); burst(p.x, p.y, 8, ['#cfd8c4', '#9bbf86', '#fff'], 70, 30);
}
function padPress() {
  if (!padOn() || G.mode !== 'play') return; const o = B.owner; if (o && o.team === 0) return;
  const tx = o ? o.x : B.x, ty = o ? o.y : B.y; let best = null, bd = 1e9;
  for (const p of G.teams[0].players) { if (p.role === 'GK' || p.frz > 0 || p.slideT > 0) continue; const d = hyp(p.x - tx, p.y - ty); if (d < bd) { bd = d; best = p; } }
  if (best) { G.press = { p: best, t: 5 }; G.active = best; G.switchT = 0.3; }
}
const LBL = {
  shoot: ['تسديد', 'SHOOT', 'TIR', 'TIRO', 'CHUTE', 'SCHUSS', 'ŞUT'], pass: ['تمرير', 'PASS', 'PASSE', 'PASE', 'PASSE', 'PASS', 'PAS'],
  sprint: ['ركض', 'SPRINT', 'SPRINT', 'CORRER', 'CORRER', 'SPRINT', 'KOŞ'], tackle: ['تدخل', 'TACKLE', 'TACLE', 'ENTRADA', 'DESARME', 'GRÄTSCHE', 'KAYMA'],
  press: ['ضغط', 'PRESS', 'PRESSING', 'PRESIÓN', 'PRESSÃO', 'PRESSING', 'BASKI']
};
const lblT = k => ffmL.apply(null, LBL[k]);
let padBuilt = false;
function buildPad() {
  if (padBuilt) return; padBuilt = true;
  const st = document.createElement('style');
  const PX = 'polygon(0 25%,6% 25%,6% 12%,12% 12%,12% 6%,25% 6%,25% 0,75% 0,75% 6%,88% 6%,88% 12%,94% 12%,94% 25%,100% 25%,100% 75%,94% 75%,94% 88%,88% 88%,88% 94%,75% 94%,75% 100%,25% 100%,25% 94%,12% 94%,12% 88%,6% 88%,6% 75%,0 75%)';
  st.textContent = '#lm-pad{position:absolute;inset:0;pointer-events:none;z-index:4;display:none}#lm-pad.on{display:block}' +
    '.lp-g{position:absolute;left:0;bottom:0;width:240px;height:200px;display:none}' +
    '.lp-btn{position:absolute;width:68px;height:68px;pointer-events:auto;touch-action:none;background:#12141c;clip-path:' + PX + ';color:#fff;font:bold 26px "Courier New",monospace;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1;-webkit-user-select:none;user-select:none;text-shadow:2px 2px 0 #000;image-rendering:pixelated}' +
    '.lp-btn::before{content:"";position:absolute;inset:5px;background:var(--c);clip-path:' + PX + ';box-shadow:inset -5px -5px 0 rgba(0,0,0,.35),inset 4px 4px 0 rgba(255,255,255,.3);z-index:-1}' +
    '.lp-btn{isolation:isolate}.lp-btn small{font-size:9px;margin-top:3px;letter-spacing:0}.lp-btn.dn{filter:brightness(1.4)}.lp-btn.dn::before{inset:7px}' +
    '#lp-joy{position:absolute;right:16px;bottom:24px;width:154px;height:154px;background:#12141c;clip-path:' + PX + ';pointer-events:auto;touch-action:none;opacity:.85;isolation:isolate}' +
    '#lp-joy::before{content:"";position:absolute;inset:6px;background:rgba(255,255,255,.2);clip-path:' + PX + ';z-index:-1}' +
    '#lp-knob{position:absolute;left:50%;top:50%;width:62px;height:62px;margin:-31px 0 0 -31px;background:#12141c;clip-path:' + PX + ';isolation:isolate}' +
    '#lp-knob::before{content:"";position:absolute;inset:5px;background:#e8efe0;clip-path:' + PX + ';box-shadow:inset -5px -5px 0 rgba(0,0,0,.3),inset 4px 4px 0 #fff;z-index:-1}';
  document.head.appendChild(st);
  const pe = document.createElement('div'); pe.id = 'lm-pad';
  const def = (g, k, letter, col, left, bottom) => '<div class="lp-btn" id="p' + g + k + '" data-g="' + g + '" data-k="' + k + '" style="left:' + left + 'px;bottom:' + bottom + 'px;--c:' + col + '">' + letter.toUpperCase() + '<small></small></div>';
  let h = '';
  for (const g of [1, 2]) h += '<div class="lp-g" id="lp-g' + g + '">' + def(g, 'a', 'A', '#d32f2f', 160, 34) + def(g, 'b', 'B', '#1e88e5', 92, 92) + def(g, 'c', 'C', '#f9a825', 18, 34) + '</div>';
  h += '<div id="lp-joy"><div id="lp-knob"></div></div>';
  pe.innerHTML = h; document.getElementById('live-match').appendChild(pe);
  const hold = (el, down, up) => {
    el.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); try { el.setPointerCapture(e.pointerId); } catch (_) {} el.classList.add('dn'); down && down(); });
    el.addEventListener('pointerup', () => { el.classList.remove('dn'); up && up(false); });
    el.addEventListener('pointercancel', () => { el.classList.remove('dn'); up && up(true); });
  };
  const sprintHold = g => ({ d: () => { pad.cH[g] = true; pad.c = pad.cH[1] || pad.cH[2]; }, u: () => { pad.cH[g] = false; pad.c = pad.cH[1] || pad.cH[2]; } });
  const chargeBtn = (id, k, fire) => hold(document.getElementById(id), () => { if (padOn()) pad.chg = { k: k, t0: performance.now() }; }, cancel => { const t = chgT(k), on = pad.chg && pad.chg.k === k; pad.chg = null; if (!cancel && on && padOn()) fire(t); });
  chargeBtn('p1a', 'a', padShoot); chargeBtn('p1b', 'b', padPass);
  hold(document.getElementById('p2a'), () => { if (padOn()) padSlide(); });
  hold(document.getElementById('p2b'), () => { if (padOn()) padPress(); });
  for (const g of [1, 2]) { const sh = sprintHold(g); hold(document.getElementById('p' + g + 'c'), sh.d, sh.u); }
  const joy = document.getElementById('lp-joy'), knob = document.getElementById('lp-knob');
  let jid = null;
  const setJ = e => { const r = joy.getBoundingClientRect(), R = r.width / 2; let dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R); const l = hyp(dx, dy), m = Math.min(l, R * 0.8); if (l > 0) { dx = dx / l * m; dy = dy / l * m; } pad.jx = dx / (R * 0.8); pad.jy = dy / (R * 0.8); knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)'; };
  joy.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); jid = e.pointerId; try { joy.setPointerCapture(jid); } catch (_) {} setJ(e); });
  joy.addEventListener('pointermove', e => { if (e.pointerId === jid) setJ(e); });
  const jend = e => { if (e.pointerId === jid) { jid = null; pad.jx = pad.jy = 0; knob.style.transform = ''; } };
  joy.addEventListener('pointerup', jend); joy.addEventListener('pointercancel', jend);
}
let padLbl = '';
function updatePadUI() {
  const pe = document.getElementById('lm-pad'); if (!pe) return;
  const on = padOn() && G.mode !== 'ended'; pe.classList.toggle('on', !!on); if (!on) return;
  const mine = !!(B.owner && B.owner.team === 0);
  document.getElementById('lp-g1').style.display = mine ? 'block' : 'none';
  document.getElementById('lp-g2').style.display = mine ? 'none' : 'block';
  const key = (mine ? '1' : '2') + state.lang;
  if (key !== padLbl) {
    padLbl = key;
    const set = (id, k) => { document.getElementById(id).querySelector('small').textContent = lblT(k); };
    set('p1a', 'shoot'); set('p1b', 'pass'); set('p1c', 'sprint'); set('p2a', 'tackle'); set('p2b', 'press'); set('p2c', 'sprint');
  }
  const f = Math.round((G.stam == null ? 1 : G.stam) * 100);
  for (const g of [1, 2]) document.getElementById('p' + g + 'c').style.setProperty('--c', 'linear-gradient(to top,#f9a825 ' + f + '%,#6b5316 ' + f + '%)');
  const p = G.active, a2 = document.getElementById('p2a'); a2.style.opacity = (p && p.slideCd > 0) ? '.4' : '.9';
}
function ensureCtrlSettings() {
  const scr = document.getElementById('screen-settings'); if (!scr) return;
  let g = document.getElementById('ctrl-mode-group');
  if (!g) {
    g = document.createElement('div'); g.className = 'form-group'; g.id = 'ctrl-mode-group'; g.style.marginTop = '16px';
    g.innerHTML = '<label id="ctrl-mode-lbl"></label><select id="ctrl-mode-select"><option value="pad"></option><option value="drag"></option></select>';
    const ref = scr.querySelector('a.godot-btn'); scr.insertBefore(g, ref);
    g.querySelector('select').addEventListener('change', e => { try { localStorage.setItem('ffm26_ctrl', e.target.value); } catch (_) {} });
  }
  g.querySelector('label').textContent = '🎮 ' + ffmL('التحكم في المباراة', 'Match Controls', 'Commandes du match', 'Controles del partido', 'Controles da partida', 'Spielsteuerung', 'Maç Kontrolleri');
  const o = g.querySelectorAll('option');
  o[0].textContent = ffmL('جويستيك + أزرار (A / B / C)', 'Joystick + Buttons (A / B / C)', 'Joystick + boutons (A / B / C)', 'Joystick + botones (A / B / C)', 'Joystick + botões (A / B / C)', 'Joystick + Tasten (A / B / C)', 'Joystick + Tuşlar (A / B / C)');
  o[1].textContent = ffmL('السحب (الطريقة القديمة)', 'Drag (classic)', 'Glisser (classique)', 'Arrastrar (clásico)', 'Arrastar (clássico)', 'Ziehen (klassisch)', 'Sürükle (klasik)');
  g.querySelector('select').value = ctrlMode();
}
(function () {
  const ws = window.showScreen; if (typeof ws === 'function') window.showScreen = function (id) { const r = ws.apply(this, arguments); if (id === 'screen-settings') ensureCtrlSettings(); return r; };
  const wl = window.changeLanguage; if (typeof wl === 'function') window.changeLanguage = function () { const r = wl.apply(this, arguments); ensureCtrlSettings(); return r; };
  if (document.readyState !== 'loading') ensureCtrlSettings(); else document.addEventListener('DOMContentLoaded', ensureCtrlSettings);
})();

/* ---------- lifecycle ---------- */
function resize() {
  if (!canvas) return;
  const vw = window.innerWidth, vh = window.innerHeight;
  VW = 440; VH = clamp(Math.round(VW * vh / vw), 190, 340);
  S = Math.min(vw / VW, vh / VH);
  canvas.width = VW; canvas.height = VH;
  canvas.style.width = (VW * S) + 'px'; canvas.style.height = (VH * S) + 'px';
}
function loop(now) {
  raf = requestAnimationFrame(loop);
  if (!G) return;
  const dt = Math.min(0.1, (now - lastT) / 1000); lastT = now;
  if (!G.paused) {
    acc += dt * G.ts; let n = 0;
    while (acc >= 1 / 60 && n < 600) { step(1 / 60); acc -= 1 / 60; n++; if (!G) return; }
  }
  if (G) { render(); updatePadUI(); }
}
function togglePause(force) {
  if (!G || G.mode === 'ended') return;
  G.paused = typeof force === 'boolean' ? force : !G.paused;
  pauseMenu.style.display = G.paused ? 'flex' : 'none';
  if (window.FFMSfx) { G.paused ? FFMSfx.ambStop() : FFMSfx.ambStart(); }
  inp.aim = null; inp.joy = null; padReset();
}
function finish() {
  const g = G; G = null;
  cancelAnimationFrame(raf); raf = 0; if (window.FFMSfx) FFMSfx.ambStop();
  overlay.classList.remove('on'); pauseMenu.style.display = 'none';
  window.removeEventListener('keydown', onKeyDown); window.removeEventListener('keyup', onKeyUp);
  inp.aim = inp.joy = null; inp.keys = {}; inp.kx = inp.ky = 0; padReset();
  if (g.onFinish) g.onFinish(g.home.score, g.away.score, g.stats);
}
function quit() {
  const msg = tx('lm_quit_confirm');
  if (!window.__qOk) { ffmConfirm(msg, () => { window.__qOk = true; try { quit(); } finally { window.__qOk = false; } }); return; }
  G = null; cancelAnimationFrame(raf); raf = 0; if (window.FFMSfx) FFMSfx.ambStop();
  overlay.classList.remove('on'); pauseMenu.style.display = 'none';
  window.removeEventListener('keydown', onKeyDown); window.removeEventListener('keyup', onKeyUp);
  inp.aim = inp.joy = null; inp.keys = {}; inp.kx = inp.ky = 0; padReset();
}
function start(opts) {
  opts = opts || {};
  overlay = document.getElementById('live-match'); canvas = document.getElementById('live-canvas'); hintEl = document.getElementById('lm-hint'); pauseMenu = document.getElementById('lm-pause-menu');
  ctx = canvas.getContext('2d');
  if (!world) buildWorld();
  if (!bound) {
    bound = true;
    canvas.addEventListener('pointerdown', onDown); canvas.addEventListener('pointermove', onMove);
    canvas.addEventListener('pointerup', onUp); canvas.addEventListener('pointercancel', onUp);
    canvas.addEventListener('contextmenu', e => e.preventDefault());
    window.addEventListener('resize', resize);
    document.addEventListener('visibilitychange', () => { if (document.hidden && G && !G.bot) togglePause(true); });
    document.getElementById('lm-pause').addEventListener('click', () => togglePause());
    document.getElementById('lm-resume').addEventListener('click', () => togglePause(false));
    document.getElementById('lm-quit').addEventListener('click', quit);
  }
  buildPad(); overlay.classList.add('on'); resize(); if (window.FFMSfx) FFMSfx.ambStart();
  newGame({ ctx: opts.ctx || matchContext, bot: opts.bot, timeScale: opts.timeScale, onFinish: opts.onFinish });
  window.addEventListener('keydown', onKeyDown); window.addEventListener('keyup', onKeyUp);
  hintEl.textContent = ctrlMode() === 'pad' ? ffmL('الأزرار A/B/C على اليسار • الجويستيك على اليمين', 'Buttons A/B/C on the left • Joystick on the right', 'Boutons A/B/C à gauche • Joystick à droite', 'Botones A/B/C a la izquierda • Joystick a la derecha', 'Botões A/B/C à esquerda • Joystick à direita', 'Tasten A/B/C links • Joystick rechts', 'A/B/C tuşları solda • Joystick sağda') : tx('lm_hint'); hintEl.style.opacity = '1'; hintEl.style.display = 'block';
  setTimeout(() => { hintEl.style.opacity = '0'; }, 6500); setTimeout(() => { hintEl.style.display = 'none'; }, 7200);
  lastT = performance.now(); acc = 0; if (!raf) raf = requestAnimationFrame(loop);
}

/* ---------- integration with the existing game ---------- */
const extra = {
  ar: { live_start: '⚽ ابدأ المباراة (5 دقائق)', quick_sim: '⚡ محاكاة سريعة (بدون لعب)', lm_paused: 'إيقاف مؤقت', lm_resume: '▶ متابعة', lm_quit: '✖ إنهاء المباراة', lm_quit_confirm: 'هل تريد الخروج؟ لن تُحتسب هذه المباراة.', lm_hint: '🎮 اسحب بإصبعك أو الماوس لتمرير الكرة أو تسديدها، وكلما طال السحب زادت القوة. حرّك اللاعب بالعصا على يسار الشاشة أو بأسهم لوحة المفاتيح. زر المسافة للتمريرة السريعة.' },
  en: { live_start: '⚽ Play Match (5 min)', quick_sim: '⚡ Quick Simulate (no play)', lm_paused: 'Paused', lm_resume: '▶ Resume', lm_quit: '✖ Quit Match', lm_quit_confirm: 'Quit the match? It will not count.', lm_hint: '🎮 Drag with finger/mouse to pass or shoot (longer drag = stronger) • Left-side joystick or Arrows/WASD to move • Space = quick pass' },
  fr: { live_start: '⚽ Jouer le match (5 min)', quick_sim: '⚡ Simulation rapide', lm_paused: 'Pause', lm_resume: '▶ Reprendre', lm_quit: '✖ Quitter le match', lm_quit_confirm: 'Quitter le match ? Il ne comptera pas.', lm_hint: '🎮 Glissez pour passer/tirer (plus long = plus fort) • Joystick à gauche ou flèches/WASD • Espace = passe rapide' }
};
for (const l of ['ar', 'en', 'fr']) Object.assign(dict[l], extra[l]);

window.startLiveMatch = function (opts) {
  if (matchContext.type === 'career') {
    const bad = state.teams.team_1.players.find(p => Number(p.contractMatches) <= 0);
    if (bad) { startMatchSimulation(); return; } // reuses the existing contract warning
  }
  const ctxCopy = { type: matchContext.type, myTeamId: matchContext.myTeamId, oppTeamId: matchContext.oppTeamId, eventStage: matchContext.eventStage };
  start(Object.assign({ ctx: ctxCopy, onFinish: function (my, opp) { startMatchSimulation({ my: my, opp: opp }); } }, opts || {}));
};
window.FFMLive = { freeKick: freeKick, penaltyKick: penaltyKick, humanKick: humanKick, start: start, step: step, debug: function () { return { G: G, B: B, inp: inp, computePass: computePass }; }, finishNow: finish, PW: PW, PH: PH };
})();
