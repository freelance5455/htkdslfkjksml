                            

(function (global) {
    'use strict';

    var steps = global.IntroSteps;
    var effects = global.IntroEffects;

    var root = null;
    var stage = null;
    var warn = null;
    var button = null;

    var siteTimer = 0;
    var bootTimer = 0;
    var initTimer = 0;
    var initTimers = [];

    var storming = false;

    var whiteoutMs = 1800;
    var initMs = 4600;
    var initReduced = 2600;

    var CLASS_SITE = 'is-site-glitch';
    var CLASS_ARMED = 'is-intro-armed';
    var CLASS_LIVE = 'is-intro-live';
    var CLASS_WHITE = 'is-white';
    var CLASS_WHITEOUT = 'is-whiteout';
    var CLASS_BOOTING = 'is-booting';
    var CLASS_INIT = 'is-initing';

    var WHITE_MS = 1250;
    var WHITE_PEAK = 690;
    var WARN_MS = 460;

    var CHARGE_CLASSES = [
        'is-white', 'is-cabling', 'is-cabled',
        'is-charging', 'is-calm',
        'is-unplugging'
    ];

    function readDurations() {
        var cs = global.getComputedStyle ? global.getComputedStyle(document.documentElement) : null;
        if (!cs) return;

        var white = parseFloat(cs.getPropertyValue('--whiteout-ms'));
        if (white > 0) whiteoutMs = white;

        var init = parseFloat(cs.getPropertyValue('--init-ms'));
        if (init > 0) initMs = init;

        var reduced = parseFloat(cs.getPropertyValue('--init-reduced-ms'));
        if (reduced > 0) initReduced = reduced;
    }

    function prefersReducedMotion() {
        return !!(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
    }

    function motionAllowed() {
        return !prefersReducedMotion();
    }

    function storm(force) {
        if (storming) return;
        storming = true;
        effects.setStorming(true);

        if (!motionAllowed() && !force) return;

        global.glitch.hold(false);
        global.glitch.storm(true);
        effects.siteStrike();
    }

    function flash(done) {
        clearTimeout(bootTimer);
        root.classList.remove(CLASS_WHITE);
        void root.offsetWidth;
        root.classList.add(CLASS_WHITE);

        if (global.sound && global.sound.playRiser) global.sound.playRiser();

        bootTimer = setTimeout(function () {
            if (typeof done === 'function') done();
        }, WHITE_PEAK);

        setTimeout(function () {
            root.classList.remove(CLASS_WHITE);
        }, WHITE_MS);
    }

    function chaos(opts) {
        storm();

        if (!motionAllowed()) {
            bootTimer = setTimeout(function () { reveal(opts); }, 400);
            return;
        }

        root.classList.add(CLASS_WHITEOUT);
        bootTimer = setTimeout(function () { reveal(opts); }, whiteoutMs + 500);
    }

    function reveal(opts) {
        opts = opts || {};

        clearTimeout(bootTimer);
        clearTimeout(siteTimer);
        clearTimeout(initTimer);
        for (var i = 0; i < initTimers.length; i++) clearTimeout(initTimers[i]);
        initTimers = [];
        if (global.IntroSteps && global.IntroSteps.cancel) global.IntroSteps.cancel();
        storming = false;
        effects.stop();

        root.classList.remove(CLASS_SITE);
        root.classList.remove(CLASS_WHITEOUT);

        if (opts.boot !== false) root.classList.add(CLASS_BOOTING);

        CHARGE_CLASSES.forEach(function (name) {
            root.classList.remove(name);
        });

        global.glitch.stop();

        if (global.Celular && global.Celular.device && global.Celular.device.fit) {
            global.Celular.device.fit();
        }

        if (opts.init === false) {
            if (typeof opts.onReveal === 'function') opts.onReveal();
            return;
        }

        initing();
    }

    function initing() {
        var step = document.getElementById('bootStep');
        var total = prefersReducedMotion() ? initReduced : initMs;

        root.classList.add(CLASS_INIT);

        if (step) step.textContent = steps.INIT_STEPS[0].text;

        steps.INIT_STEPS.forEach(function (entry, index) {
            if (!index) return;
            initTimers.push(setTimeout(function () {
                if (step) step.textContent = entry.text;
            }, Math.round(total * entry.at)));
        });

        initTimer = setTimeout(finishBoot, total);
    }

    function finishBoot() {
        clearTimeout(initTimer);
        for (var i = 0; i < initTimers.length; i++) clearTimeout(initTimers[i]);
        initTimers = [];

        root.classList.remove(CLASS_INIT);
        root.classList.remove(CLASS_BOOTING);

        if (typeof global.intro.onBooted === 'function') global.intro.onBooted();
    }

    function confirm(event) {
        if (event) event.preventDefault();
        if (warn.classList.contains('is-gone')) return;

        warn.classList.add('is-gone');

        if (global.sound && global.sound.startAmbient) global.sound.startAmbient();

        setTimeout(function () {
            if (warn.parentNode) warn.parentNode.removeChild(warn);
        }, WARN_MS);

        setTimeout(function () {
            steps.play();
        }, WARN_MS);
    }

    function boot() {
        root = document.documentElement;
        stage = document.querySelector('.stage');
        warn = document.getElementById('intro-warn');
        button = document.getElementById('intro-warn-btn');

        if (!root || !stage) return;

        readDurations();

        if (!warn || !button) {
            reveal();
            return;
        }

        if (button.addEventListener) button.addEventListener('click', confirm, false);
        else button.attachEvent('onclick', confirm);

        root.classList.add(CLASS_ARMED);

        try {
            button.focus({ preventScroll: true });
        } catch (err) {
            button.focus();
        }
    }

    (function claim() {
        if (!global.glitch || !global.glitch.hold) return;
        if (global.location && global.location.search.indexOf('glitch') !== -1) return;

        steps.init();
        effects.init();
        global.glitch.hold(true);
        document.addEventListener('DOMContentLoaded', boot);
    })();

    global.intro = {
        onDone: null,
        onBooted: null,
        chaos: chaos,
        storm: storm,
        flash: flash,
        reveal: reveal
    };

})(window);
