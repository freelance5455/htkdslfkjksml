
"use strict";

// ===============================
// 1. DATA DAN KONFIGURASI
// ===============================

const STORAGE_KEY = "otlog_v2_data";
let absensi = [];

const $ = id => document.getElementById(id);

// ===============================
// 2. NOTIFIKASI
// ===============================

function tampilNotif(judul, pesan) {
  const notif = $("notifOTLOG");

  if (!notif) {
    alert(judul + "\n" + pesan);
    return;
  }

  const judulEl = $("judulNotif");
  const pesanEl = $("pesanNotif");

  if (judulEl) judulEl.textContent = judul;
  if (pesanEl) pesanEl.textContent = pesan;

  notif.classList.add("aktif");
}

function tutupNotif() {
  const notif = $("notifOTLOG");
  if (notif) notif.classList.remove("aktif");
}

// ===============================
// 3. FORMAT TANGGAL DAN JAM
// ===============================

function tanggalLokal(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");

  return `${y}-${m}-${d}`;
}

function formatJam(date) {
  return date.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
}

function durasi(ms) {
  const menit = Math.floor(Math.max(0, ms) / 60000);
  const jam = Math.floor(menit / 60);
  const sisaMenit = menit % 60;

  return `${jam} jam ${sisaMenit} menit`;
}

// ===============================
// 4. PENYIMPANAN DATA
// ===============================

function bacaData() {
  try {
    const data = JSON.parse(
      localStorage.getItem(STORAGE_KEY) || "[]"
    );

    absensi = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("Gagal membaca data:", error);
    tampilNotif(
      "Gagal Membaca Data",
      "Data tidak dapat dibaca. Jangan reset aplikasi."
    );
    absensi = [];
  }
}

function simpanData() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(absensi)
    );

    return true;
  } catch (error) {
    console.error("Gagal menyimpan data:", error);

    tampilNotif(
      "Penyimpanan Gagal",
      "Data gagal disimpan. Periksa penyimpanan browser."
    );

    return false;
  }
}

function cariHariIni() {
  return absensi.find(
    item => item.tanggal === tanggalLokal()
  );
}

// ===============================
// 5. HITUNG JAM LEMBUR
// ===============================

function hitungLembur(item) {
  if (!item.masuk || !item.pulang) return 0;

  const masuk = new Date(item.masuk);
  const pulang = new Date(item.pulang);

  if (
    Number.isNaN(masuk.getTime()) ||
    Number.isNaN(pulang.getTime()) ||
    pulang <= masuk
  ) {
    return 0;
  }

  let total = 0;
  let waktu = new Date(masuk);

  while (waktu < pulang) {
    const hari = waktu.getDay();

    // Minggu (0) dan Sabtu (6): mulai 08.00
    // Senin-Jumat: mulai 17.00
    const jamBatas =
      hari === 0 || hari === 6 ? 8 : 17;

    const batas = new Date(waktu);
    batas.setHours(jamBatas, 0, 0, 0);

    // Batas akhir hari ini
    const besok = new Date(waktu);
    besok.setHours(24, 0, 0, 0);

    const akhir = new Date(
      Math.min(pulang.getTime(), besok.getTime())
    );

    const mulaiLembur = Math.max(
      waktu.getTime(),
      batas.getTime()
    );

    if (akhir > mulaiLembur) {
      total += akhir.getTime() - mulaiLembur;
    }

    waktu = akhir;
  }

  // Maksimal 12 jam lembur per absensi
  return Math.min(total, 12 * 60 * 60 * 1000);
}

// ===============================
// 6. JAM DIGITAL
// ===============================

let tanggalTerakhir = "";

function renderJam() {
  const sekarang = new Date();
  const tanggalSekarang = tanggalLokal(sekarang);

  const tanggalEl = $("tanggalHariIni");
  const jamEl = $("jamSekarang");

  if (tanggalEl) {
    tanggalEl.textContent =
      sekarang.toLocaleDateString("id-ID", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric"
      });
  }

  if (jamEl) {
    jamEl.textContent =
      sekarang.toLocaleTimeString("id-ID", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
      });
  }

  if (tanggalSekarang !== tanggalTerakhir) {
    tanggalTerakhir = tanggalSekarang;
    renderDashboard();
  }
}

// ===============================
// 7. DASHBOARD
// ===============================

function renderDashboard() {
  const hariIni = cariHariIni();

  const status = $("statusAbsensi");
  const waktuMasuk = $("waktuMasuk");
  const waktuPulang = $("waktuPulang");
  const btnCheckIn = $("btnCheckIn");
  const btnCheckOut = $("btnCheckOut");

  if (status) {
    status.textContent = !hariIni
      ? "Belum Check In"
      : hariIni.pulang
        ? "Absensi Selesai"
        : "Sudah Check In";
  }

  if (waktuMasuk) {
    waktuMasuk.textContent = hariIni?.masuk
      ? formatJam(new Date(hariIni.masuk))
      : "--:--";
  }

  if (waktuPulang) {
    waktuPulang.textContent = hariIni?.pulang
      ? formatJam(new Date(hariIni.pulang))
      : "--:--";
  }

  if (btnCheckIn) {
    btnCheckIn.disabled = !!hariIni;
  }

  if (btnCheckOut) {
    btnCheckOut.disabled =
      !hariIni || !!hariIni.pulang;
  }

  renderRiwayat();
  renderTotal();
}

// ===============================
// 8. CHECK IN
// ===============================

function checkIn() {
  if (cariHariIni()) {
    tampilNotif(
      "Check In Ditolak",
      "Kamu sudah Check In hari ini."
    );
    return;
  }

  const sekarang = new Date();

  const dataBaru = {
    tanggal: tanggalLokal(sekarang),
    masuk: sekarang.toISOString(),
    pulang: null
  };

  absensi.unshift(dataBaru);

  if (simpanData()) {
    renderDashboard();

    tampilNotif(
      "Check In Berhasil",
      "Waktu masuk: " + formatJam(sekarang)
    );
  } else {
    absensi = absensi.filter(
      item => item !== dataBaru
    );
  }
}

// ===============================
// 9. CHECK OUT
// ===============================

function checkOut() {
  const hariIni = cariHariIni();

  if (!hariIni || hariIni.pulang) {
    tampilNotif(
      "Check Out Ditolak",
      "Kamu belum Check In atau sudah Check Out."
    );
    return;
  }

  const sekarang = new Date();

  if (sekarang <= new Date(hariIni.masuk)) {
    tampilNotif(
      "Waktu Tidak Valid",
      "Waktu Check Out harus setelah Check In."
    );
    return;
  }

  const pulangLama = hariIni.pulang;
  hariIni.pulang = sekarang.toISOString();

  if (simpanData()) {
    renderDashboard();

    tampilNotif(
      "Check Out Berhasil",
      "Durasi lembur: " + durasi(hitungLembur(hariIni))
    );
  } else {
    hariIni.pulang = pulangLama;
  }
}

// ===============================
// 10. RIWAYAT ABSENSI
// ===============================

function renderRiwayat() {
  const wadah = $("riwayatAbsensi");

  if (!wadah) {
    console.error(
      'Elemen "riwayatAbsensi" tidak ditemukan.'
    );
    return;
  }

  wadah.replaceChildren();

  if (!absensi.length) {
    const kosong = document.createElement("p");
    kosong.className = "empty";
    kosong.textContent = "Belum ada riwayat absensi.";

    wadah.appendChild(kosong);
    return;
  }

  absensi.forEach(item => {
    const kartu = document.createElement("div");
    kartu.className = "history-item";

    const tanggal = document.createElement("p");

    tanggal.textContent = item.tanggal
      ? new Date(
          item.tanggal + "T12:00:00"
        ).toLocaleDateString("id-ID", {
          day: "numeric",
          month: "long",
          year: "numeric"
        })
      : "Tanggal tidak tersedia";

    const detail = document.createElement("p");

    detail.textContent =
      `Masuk: ${
        item.masuk
          ? formatJam(new Date(item.masuk))
          : "--:--"
      } | Pulang: ${
        item.pulang
          ? formatJam(new Date(item.pulang))
          : "--:--"
      }`;

    const lembur = document.createElement("p");

    lembur.textContent = item.pulang
      ? "Lembur: " + durasi(hitungLembur(item))
      : "Menunggu Check Out";

    kartu.append(tanggal, detail, lembur);
    wadah.appendChild(kartu);
  });
}

// ===============================
// 11. TOTAL LEMBUR DAN HARI
// ===============================

function renderTotal() {
  const selesai = absensi.filter(
    item => item.pulang
  );

  const total = selesai.reduce(
    (jumlah, item) =>
      jumlah + hitungLembur(item),
    0
  );

  const totalLembur = $("totalLembur");
  const totalHari = $("totalHari");

  if (totalLembur) {
    totalLembur.textContent =
      (total / 3600000).toFixed(1) + " jam";
  }

  if (totalHari) {
    totalHari.textContent =
      absensi.length + " hari";
  }
}

// ===============================
// 12. RESET SYSTEM
// ===============================

function resetSystem() {
  const konfirmasi = $("konfirmasiReset");

  if (konfirmasi) {
    konfirmasi.classList.add("aktif");
  }
}

function tutupKonfirmasiReset() {
  const konfirmasi = $("konfirmasiReset");

  if (konfirmasi) {
    konfirmasi.classList.remove("aktif");
  }
}

function konfirmasiResetSekarang() {
  try {
    localStorage.removeItem(STORAGE_KEY);
    absensi = [];

    tutupKonfirmasiReset();
    renderDashboard();

    tampilNotif(
      "Reset Berhasil",
      "Semua data OTLOG telah dihapus. Silakan Check In kembali."
    );
  } catch (error) {
    console.error("Reset gagal:", error);

    tampilNotif(
      "Reset Gagal",
      "Data gagal direset. Silakan coba lagi."
    );
  }
}

// ===============================
// 13. MULAI OTLOG
// ===============================

function mulaiOTLOG() {
  bacaData();

  const btnCheckIn = $("btnCheckIn");
  const btnCheckOut = $("btnCheckOut");
  const tombolReset = $("btnResetSystem");

  if (btnCheckIn) {
    btnCheckIn.addEventListener("click", checkIn);
  }

  if (btnCheckOut) {
    btnCheckOut.addEventListener("click", checkOut);
  }

  if (tombolReset) {
    tombolReset.addEventListener("click", resetSystem);
  }

  renderJam();
  renderDashboard();

  setInterval(renderJam, 1000);

  console.log("OTLOG V2 berhasil dimuat.");
}

mulaiOTLOG();
