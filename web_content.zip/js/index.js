
const STORAGE_KEY = "otlog_v2_data";
let absensi = [];

const $ = id => document.getElementById(id);


function tampilNotif(judul, pesan) {
  const notif = $("notifOTLOG");

  if (!notif) {
    alert(judul + "\n" + pesan);
    return;
  }

  $("judulNotif").textContent = judul;
  $("pesanNotif").textContent = pesan;
  notif.classList.add("aktif");
}

function tutupNotif() {
  $("notifOTLOG").classList.remove("aktif");
}


// ===============================
// 1. FORMAT TANGGAL DAN JAM
// ===============================

function tanggalLokal(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function formatJam(date) {
  return date.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
}

// ===============================
// 2. PENYIMPANAN DATA
// ===============================

function bacaData() {
  try {
    const data = JSON.parse(
      localStorage.getItem(STORAGE_KEY) || "[]"
    );
    absensi = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("Gagal membaca data:", error);
    absensi = [];
  }
}

function simpanData() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(absensi)
    );
    return true;
  } catch (error) {
    alert("Data gagal disimpan di browser.");
    return false;
  }
}

function cariHariIni() {
  return absensi.find(
    item => item.tanggal === tanggalLokal()
  );
}

// ===============================
// 3. HITUNG LEMBUR
// ===============================

function hitungLembur(item) {
  if (!item.masuk || !item.pulang) return 0;

  const masuk = new Date(item.masuk);
  const pulang = new Date(item.pulang);

  if (pulang <= masuk) return 0;

  const batas = new Date(masuk);
  const hari = batas.getDay();

  if (hari === 0 || hari === 6) {
    batas.setHours(8, 0, 0, 0);
  } else {
    batas.setHours(17, 0, 0, 0);
  }

  const mulaiLembur = Math.max(
    masuk.getTime(),
    batas.getTime()
  );

  const total = Math.max(
    0,
    pulang.getTime() - mulaiLembur
  );

  return Math.min(total, 12 * 60 * 60 * 1000);
}

function durasi(ms) {
  const menit = Math.floor(ms / 60000);
  return `${Math.floor(menit / 60)} jam ${menit % 60} menit`;
}

// ===============================
// 4. JAM DIGITAL
// ===============================


let tanggalTerakhir = "";

function renderJam() {
  const sekarang = new Date();
  const tanggalSekarang = tanggalLokal(sekarang);

  $("tanggalHariIni").textContent =
    sekarang.toLocaleDateString("id-ID", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    });

  $("jamSekarang").textContent =
    sekarang.toLocaleTimeString("id-ID", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    });

  if (tanggalSekarang !== tanggalTerakhir) {
    tanggalTerakhir = tanggalSekarang;
    renderDashboard();
  }
}


// ===============================
// 5. DASHBOARD
// ===============================

function renderDashboard() {
  const hariIni = cariHariIni();

  $("statusAbsensi").textContent = !hariIni
    ? "Belum Check In"
    : hariIni.pulang
      ? "Absensi Selesai"
      : "Sudah Check In";

  $("waktuMasuk").textContent =
    hariIni?.masuk
      ? formatJam(new Date(hariIni.masuk))
      : "--:--";

  $("waktuPulang").textContent =
    hariIni?.pulang
      ? formatJam(new Date(hariIni.pulang))
      : "--:--";

  $("btnCheckIn").disabled = !!hariIni;
  $("btnCheckOut").disabled =
    !hariIni || !!hariIni.pulang;

  renderRiwayat();
  renderTotal();
}

// ===============================
// 6. CHECK IN
// ===============================

function checkIn() {
  if (cariHariIni()) {
    alert("Kamu sudah Check In hari ini.");
    return;
  }

  const sekarang = new Date();

  absensi.unshift({
    tanggal: tanggalLokal(sekarang),
    masuk: sekarang.toISOString(),
    pulang: null
  });

  if (simpanData()) {
    renderDashboard();
    tampilNotif(
  "Check In Berhasil",
 "Waktu masuk: " + formatJam(sekarang)
);
  } else {
    absensi.shift();
  }
}

// ===============================
// 7. CHECK OUT
// ===============================

function checkOut() {
  const hariIni = cariHariIni();

  if (!hariIni || hariIni.pulang) {
    alert("Kamu belum Check In.");
    return;
  }

  const sekarang = new Date();

  if (sekarang <= new Date(hariIni.masuk)) {
    alert("Waktu Check Out tidak valid.");
    return;
  }

  hariIni.pulang = sekarang.toISOString();

  if (simpanData()) {
    renderDashboard();

    tampilNotif(
  "Check Out Berhasil",
  "Durasi lembur: " + durasi(hitungLembur(hariIni))
);
  } else {
    hariIni.pulang = null;
  }
}

// ===============================
// 8. RIWAYAT ABSENSI
// ===============================

function renderRiwayat() {
  const wadah = $("riwayatAbsensi");
  wadah.replaceChildren();

  if (!absensi.length) {
    const kosong = document.createElement("p");
    kosong.className = "empty";
    kosong.textContent = "Belum ada riwayat absensi.";
    wadah.appendChild(kosong);
    return;
  }

  absensi.forEach(item => {
    const kartu = document.createElement("div");
    kartu.className = "history-item";

    const tanggal = document.createElement("p");
    tanggal.textContent = new Date(
      item.tanggal + "T12:00:00"
    ).toLocaleDateString("id-ID", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });

    const detail = document.createElement("p");
    detail.textContent =
      `Masuk: ${item.masuk ? formatJam(new Date(item.masuk)) : "--:--"} | ` +
      `Pulang: ${item.pulang ? formatJam(new Date(item.pulang)) : "--:--"}`;

    const lembur = document.createElement("p");
    lembur.textContent = item.pulang
      ? "Lembur: " + durasi(hitungLembur(item))
      : "Menunggu Check Out";

    kartu.append(tanggal, detail, lembur);
    wadah.appendChild(kartu);
  });
}

// ===============================
// 9. TOTAL LEMBUR DAN HARI
// ===============================

function renderTotal() {
  const selesai = absensi.filter(item => item.pulang);

  const total = selesai.reduce(
    (jumlah, item) => jumlah + hitungLembur(item),
    0
  );

  $("totalLembur").textContent =
    (total / 3600000).toFixed(1) + " jam";

  $("totalHari").textContent =
    absensi.length + " hari";
}

// ===============================
// 10. RESET SYSTEM
// ===============================



function resetSystem() {
  $("konfirmasiReset").classList.add("aktif");
}

function tutupKonfirmasiReset() {
  $("konfirmasiReset").classList.remove("aktif");
}

function konfirmasiResetSekarang() {
  tutupKonfirmasiReset();

  try {
    localStorage.removeItem(STORAGE_KEY);
    absensi = [];

    renderDashboard();

    tampilNotif(
      "Reset Berhasil",
      "Semua data OTLOG telah dihapus. Silakan Check In kembali."
    );
  } catch (error) {
    console.error("Reset gagal:", error);

    tampilNotif(
      "Reset Gagal",
      "Data gagal direset. Silakan coba lagi."
    );
  }
}

// ===============================
// 11. MULAI OTLOG
// ===============================

function mulaiOTLOG() {
  bacaData();

  $("btnCheckIn").addEventListener("click", checkIn);
  $("btnCheckOut").addEventListener("click", checkOut);

  const tombolReset = $("btnResetSystem");

  if (tombolReset) {
    tombolReset.addEventListener("click", resetSystem);
  }

  renderJam();
  renderDashboard();

  setInterval(renderJam, 1000);

  console.log("OTLOG V2 berhasil dimuat.");
}

mulaiOTLOG();
