document.addEventListener('DOMContentLoaded', () => {
  const pasteBtn = document.getElementById('pasteBtn');
  const videoUrlInput = document.getElementById('videoUrl');
  const downloadBtn = document.getElementById('downloadBtn');
  const backBtn = document.getElementById('backBtn');

  const homePage = document.getElementById('homePage');
  const resultPage = document.getElementById('resultPage');

  const mediaBox = document.getElementById('mediaBox');
  const loaderBox = document.getElementById('loaderBox');
  const videoIframe = document.getElementById('videoIframe');
  const thumbnailImg = document.getElementById('thumbnail');
  const videoTitle = document.getElementById('videoTitle');
  const platformTag = document.getElementById('platformTag');

  const mainDownloadBtn = document.getElementById('mainDownloadBtn');
  const qualityMenu = document.getElementById('qualityMenu');
  const videoQualityList = document.getElementById('videoQualityList');
  const audioQualityList = document.getElementById('audioQualityList');

  const downloadProgressBox = document.getElementById('downloadProgressBox');
  const progressBar = document.getElementById('progressBar');
  const progressPercent = document.getElementById('progressPercent');
  const downloadStatusText = document.getElementById('downloadStatusText');

  // ক্লিপবোর্ড থেকে পেস্ট (ক্র্যাশ রোধে নিরাপদ হ্যান্ডলিং)
  pasteBtn.addEventListener('click', async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        videoUrlInput.value = text;
      } else {
        alert('আপনার ব্রাউজারে অটো-পেস্ট সাপোর্ট করছে না। ম্যানুয়ালি পেস্ট করুন।');
      }
    } catch (err) {
      alert('ক্লিপবোর্ড থেকে লিঙ্ক পেস্ট করার অনুমতি পাওয়া যায়নি!');
    }
  });

  // ১ম পেজ থেকে ২য় পেজে যাওয়া ও প্রসেস করা
  downloadBtn.addEventListener('click', async () => {
    const url = videoUrlInput.value.trim();

    if (!url) {
      alert('অনুগ্রহ করে একটি লিঙ্ক পেস্ট করুন!');
      return;
    }

    homePage.classList.remove('active-page');
    homePage.classList.add('hidden-page');
    
    resultPage.classList.remove('hidden-page');
    resultPage.classList.add('active-page');

    resetResultUI();
    showLoader(true);

    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      processYouTube(url);
    } else if (url.includes('tiktok.com')) {
      await processTikTok(url);
    } else if (url.includes('facebook.com') || url.includes('fb.watch')) {
      await processFacebook(url);
    } else {
      showLoader(false);
      showError("সমর্থিত লিঙ্ক নয়! YouTube, Facebook বা TikTok লিঙ্ক দিন।");
    }
  });

  // ইউটিউব প্রসেসিং
  function processYouTube(url) {
    platformTag.textContent = 'YouTube';
    const videoId = extractYouTubeId(url);
    showLoader(false);

    if (videoId) {
      videoIframe.src = `https://www.youtube.com/embed/${videoId}`;
      videoIframe.classList.remove('hidden');
      videoTitle.textContent = 'ইউটিউব ভিডিও প্রস্তুত। ডাউনলোড অপশন নির্বাচন করুন।';

      renderQualityButtons([
        { label: '720p (HD)', type: 'video', url: url },
        { label: '360p (SD)', type: 'video', url: url }
      ], [
        { label: '128 kbps', type: 'audio', url: url }
      ]);
    } else {
      showError("ইউটিউব ভিডিওর সঠিক ID পাওয়া যায়নি!");
    }
  }

  // টিকটক প্রসেসিং (TikWM API) - CORS safe
  async function processTikTok(url) {
    platformTag.textContent = 'TikTok';
    try {
      const response = await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`);
      if (!response.ok) throw new Error("HTTP Error");
      const res = await response.json();

      showLoader(false);

      if (res.code === 0 && res.data) {
        const data = res.data;
        thumbnailImg.src = data.cover || '';
        thumbnailImg.classList.remove('hidden');
        videoTitle.textContent = data.title || 'TikTok Video';

        renderQualityButtons([
          { label: 'No Watermark (HD)', type: 'video', url: data.play },
          { label: 'With Watermark', type: 'video', url: data.wmplay }
        ], [
          { label: 'Original Sound (MP3)', type: 'audio', url: data.music }
        ]);
      } else {
        showError("টিকটক ভিডিও প্রসেস করা সম্ভব হয়নি! ভিডিওটি প্রাইভেট হতে পারে।");
      }
    } catch (err) {
      showLoader(false);
      showError("সার্ভারে সমস্যা হয়েছে বা নেটওয়ার্ক সংযোগ বিচ্ছিন্ন।");
    }
  }

  // ফেসবুক প্রসেসিং
  async function processFacebook(url) {
    platformTag.textContent = 'Facebook';
    try {
      // Fallback/Safe Handling for CORS/Network error
      const response = await fetch('https://co.wuk.sh/api/json', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: url })
      });

      if (!response.ok) throw new Error("API Error");
      const res = await response.json();
      showLoader(false);

      if (res && res.url) {
        thumbnailImg.src = 'https://via.placeholder.com/600x330/1e293b/1877f2?text=Facebook+Video+Ready';
        thumbnailImg.classList.remove('hidden');
        videoTitle.textContent = 'ফেসবুক ভিডিও সফলভাবে প্রসেস করা হয়েছে।';

        renderQualityButtons([
          { label: 'HD / SD Video (MP4)', type: 'video', url: res.url }
        ], []);
      } else {
        showError("ফেসবুক ভিডিওটি প্রসেস করা যায়নি। ভিডিওটি পাবলিক কিনা নিশ্চিত করুন।");
      }
    } catch (err) {
      showLoader(false);
      showError("নেটওয়ার্ক সমস্যা বা API সাপোর্ট করছে না। লিংকটি চেক করুন।");
    }
  }

  // ডাউনলোড বাটন জেনারেট করার ফাংশন
  function renderQualityButtons(videos, audios) {
    videoQualityList.innerHTML = '';
    audioQualityList.innerHTML = '';

    if (videos && videos.length > 0) {
      videos.forEach(v => {
        const btn = document.createElement('button');
        btn.className = 'quality-item';
        btn.innerHTML = `<span class="q-res">${v.label}</span> <span class="q-size">MP4</span>`;
        btn.onclick = () => triggerDownload(v.url, 'video');
        videoQualityList.appendChild(btn);
      });
    } else {
      videoQualityList.innerHTML = '<p style="font-size:12px; color:#64748b;">কোনো ভিডিও ফাইল পাওয়া যায়নি</p>';
    }

    if (!audios || audios.length === 0) {
      audioQualityList.innerHTML = '<p style="font-size:12px; color:#64748b;">কোনো আলাদা অডিও ফাইল নেই</p>';
    } else {
      audios.forEach(a => {
        const btn = document.createElement('button');
        btn.className = 'quality-item audio';
        btn.innerHTML = `<span class="q-res">${a.label}</span> <span class="q-size">MP3</span>`;
        btn.onclick = () => triggerDownload(a.url, 'audio');
        audioQualityList.appendChild(btn);
      });
    }
  }

  // ডাউনলোড শুরু করার প্রসেস
  function triggerDownload(fileUrl, type) {
    if (!fileUrl) return;

    qualityMenu.classList.add('hidden-menu');
    downloadProgressBox.classList.remove('hidden');
    
    let progress = 0;
    progressBar.style.width = '0%';
    progressPercent.textContent = '0%';
    downloadStatusText.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ডাউনলোড হচ্ছে...`;

    const interval = setInterval(() => {
      progress += 20;
      progressBar.style.width = `${progress}%`;
      progressPercent.textContent = `${progress}%`;

      if (progress >= 100) {
        clearInterval(interval);
        downloadStatusText.innerHTML = `<i class="fa-solid fa-circle-check"></i> ডাউনলোড রেডি!`;

        // ফাইল ডাউনলোড ট্রিগার
        const a = document.createElement('a');
        a.href = fileUrl;
        a.target = '_blank';
        a.download = `Downloaded_Media_${Date.now()}.${type === 'audio' ? 'mp3' : 'mp4'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        setTimeout(() => {
          downloadProgressBox.classList.add('hidden');
        }, 4000);
      }
    }, 200);
  }

  // ড্রপডাউন টগল
  mainDownloadBtn.addEventListener('click', () => {
    qualityMenu.classList.toggle('hidden-menu');
  });

  // ব্যাক বাটন
  backBtn.addEventListener('click', () => {
    resetResultUI();
    resultPage.classList.remove('active-page');
    resultPage.classList.add('hidden-page');

    homePage.classList.remove('hidden-page');
    homePage.classList.add('active-page');
  });

  function resetResultUI() {
    videoIframe.src = '';
    videoIframe.classList.add('hidden');
    thumbnailImg.src = '';
    thumbnailImg.classList.add('hidden');
    qualityMenu.classList.add('hidden-menu');
    downloadProgressBox.classList.add('hidden');
    videoQualityList.innerHTML = '';
    audioQualityList.innerHTML = '';
  }

  function showLoader(show) {
    if (show) {
      loaderBox.classList.remove('hidden');
      mediaBox.classList.add('hidden');
    } else {
      loaderBox.classList.add('hidden');
      mediaBox.classList.remove('hidden');
    }
  }

  function showError(msg) {
    videoTitle.textContent = msg;
    videoQualityList.innerHTML = '';
    audioQualityList.innerHTML = '';
  }

  function extractYouTubeId(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  }
});