/**
 * models.js
 * "Modelos/tipos" das entidades do marketplace. Como o projeto é JavaScript
 * puro (sem TypeScript), cada modelo é uma função-fábrica que garante que
 * todos os campos existam com valores padrão, além de um validador simples.
 * Isso documenta o formato de dados esperado por cada tabela (equivalente a
 * um "schema") e evita registros incompletos no banco simulado (db.js).
 */
const Models = {

  // ---------- USERS ----------
  // tipo_usuario: 'anfitriao' | 'profissional' | 'administrador'
  // status: 'ativo' | 'suspenso'
  novoUsuario({ nome, email, telefone, tipo_usuario, senha_hash, cpf }){
    return {
      nome, email, telefone, tipo_usuario,
      cpf: cpf || '', // usado para pré-preencher termos que exigem identificação (ex: Termo de Intermediação)
      senha_hash,
      status: 'ativo',
      // exclusão lógica (nunca remove o cadastro; preserva histórico/avaliações/auditoria)
      excluido: false,
      excluido_em: null,
      admin_responsavel_exclusao_id: null,
    };
  },
  validarUsuario({ nome, email, telefone, tipo_usuario, senha }){
    const erros = {};
    if(!nome || nome.trim().length < 3) erros.nome = 'Informe seu nome completo.';
    if(!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) erros.email = 'E-mail inválido.';
    if(!telefone || telefone.replace(/\D/g,'').length < 10) erros.telefone = 'Telefone inválido.';
    if(!['anfitriao','profissional','morador'].includes(tipo_usuario)) erros.tipo_usuario = 'Escolha um perfil.';
    if(!senha || senha.length < 4) erros.senha = 'A senha precisa ter ao menos 4 caracteres.';
    return erros;
  },

  // ---------- PROVIDERS (perfil profissional) ----------
  // status (legado — continua sendo o "portão" usado pelo matching/mapa): 'pendente' | 'aprovado' | 'suspenso'
  // status_aprovacao (novo — workflow granular): 'PENDENTE' | 'ENVIADO' | 'EM_ANALISE' | 'APROVADO' | 'REJEITADO'
  // documentos[tipo].status: 'pendente' | 'enviado' | 'em_analise' | 'aprovado' | 'rejeitado'
  novoProvider({ user_id, cpf, rg, data_nascimento, endereco, cidade, selfie, categorias }){
    return {
      user_id,
      // identificação
      cpf: cpf || '', rg: rg || '', data_nascimento: data_nascimento || '',
      endereco: endereco || '', cidade: cidade || '',
      selfie: selfie || '', // foto oficial de identificação (base64) — nunca confundir com "foto de perfil casual"
      foto: '', // reservado para uma futura foto de exibição pública separada da selfie de identificação
      descricao: '',
      categorias: categorias || [],

      status: 'pendente',
      status_aprovacao: 'PENDENTE',
      data_aprovacao: null,
      admin_responsavel_aprovacao_id: null,
      motivo_rejeicao: null,

      // exclusão lógica (nunca remove o cadastro; preserva histórico/avaliações/auditoria)
      excluido: false,
      excluido_em: null,
      admin_responsavel_exclusao_id: null,

      // documentação (não obrigatória em DEV — ver Models.validarDocumentoObrigatorioEmProducao)
      documentos: {
        rg_cpf: Models._novoDocumento(),
        comprovante_residencia: Models._novoDocumento(),
        certidao_antecedentes: Models._novoDocumento(),
      },

      verificado: false,
      reputacao: 0,
      disponibilidade: [],
      latitude: null,
      longitude: null,
    };
  },
  _novoDocumento(){
    return { status: 'pendente', arquivo: null, enviado_em: null, analisado_em: null, admin_id: null, motivo_rejeicao: null };
  },
  validarCadastroProfissional({ selfie, categorias }){
    // Nesta fase de TESTE só a selfie e a categoria são pedidas no cadastro;
    // CPF/RG/documentos ficam disponíveis para preencher depois no perfil,
    // sem bloquear o cadastro.
    const erros = {};
    if(!selfie) erros.selfie = 'Envie uma selfie para identificação.';
    if(!categorias || categorias.length === 0){
      erros.categorias = 'Escolha sua categoria de atuação (Faxineira, Marido de aluguel ou Roupa de cama).';
    }
    return erros;
  },

  // ---------- PROPERTIES (imóveis) ----------
  // status: 'ativo' | 'inativo'
  // tipo: 'Apartamento' | 'Casa' | 'Kitnet/Studio' | 'Sobrado' | 'Outro'
  novoImovel({ owner_id }){
    return {
      owner_id,
      nome: '',
      endereco: '',
      cep: '',
      cidade: '',
      estado: '',
      bairro: '',
      tipo: 'Apartamento',
      latitude: null,
      longitude: null,
      quartos: 1,
      banheiros: 1,
      camas: 1,
      capacidade: 2,
      metragem_m2: null, // opcional
      acesso: '', // ex: "Portaria 24h, retirar chave com síndico", código de portão, etc.
      condominio: '', // nome do condomínio/regras relevantes para o profissional
      caracteristicas: { cozinha:false, sala:false, varanda:false, garagem:false },
      observacoes: '',
      fotos: [],
      status: 'ativo',
      // exclusão lógica (arquivamento) — preserva histórico de serviços/checklist/inventário
      excluido: false,
      excluido_em: null,
      admin_responsavel_exclusao_id: null,
    };
  },
  validarImovel({ nome, cidade, estado, bairro, endereco }){
    const erros = {};
    if(!nome || nome.trim().length < 2) erros.nome = 'Dê um nome/apelido para o imóvel.';
    if(!endereco) erros.endereco = 'Informe o endereço.';
    if(!estado) erros.estado = 'Selecione o estado.';
    if(!cidade) erros.cidade = 'Selecione a cidade.';
    if(!bairro) erros.bairro = 'Selecione o bairro.';
    return erros;
  },

  // ---------- PROPERTY_ROOMS (ambientes/cômodos do imóvel) ----------
  novoAmbiente({ property_id, nome, observacoes, fotos, video }){
    return { property_id, nome, observacoes: observacoes || '', fotos: fotos || [], video: video || null };
  },

  // ---------- PROPERTY_INVENTORY (inventário vinculado ao imóvel) ----------
  // estado: 'NOVO' | 'BOM' | 'REGULAR' | 'DANIFICADO' | 'NAO_FUNCIONA' | 'NAO_TESTADO' | 'NAO_APLICAVEL'
  novoItemInventario({ property_id, room_id, item, quantidade, estado, observacao, evidencias }){
    return {
      property_id, room_id: room_id || null, item,
      quantidade: quantidade || 1, estado: estado || 'NAO_TESTADO',
      observacao: observacao || '', evidencias: evidencias || [],
    };
  },
  ESTADOS_INVENTARIO: ['NOVO','BOM','REGULAR','DANIFICADO','NAO_FUNCIONA','NAO_TESTADO','NAO_APLICAVEL'],

  // ---------- PROPERTY_CHECKLIST_RUNS (execução do checklist na pré-vistoria) ----------
  novoChecklistRun({ property_id, service_request_id, provider_id, itens, tipo, pre_run_id }){
    return {
      property_id, service_request_id, provider_id,
      tipo: tipo || 'pre', // 'pre' (pré-vistoria) | 'pos' (pós-vistoria, Etapa 4 — comparativo antes/depois)
      pre_run_id: pre_run_id || null, // referência ao checklist de pré-vistoria, quando tipo==='pos'
      itens, // [{ tipo:'ambiente'|'inventario', referencia_id, descricao, ok:null, observacao:'', fotos:[] }]
      video: null, // vídeo obrigatório (base64) — exigido para concluir o checklist (pré e pós)
      video_registrado_em: null, // data/hora em que o vídeo foi anexado
      observacao_geral: '', // observações do profissional sobre a vistoria (obrigatório na pré-vistoria)
      concluido: false, concluido_em: null,
    };
  },

  // ---------- TERM_ACCEPTANCES (aceite de termos versionados) ----------
  // service_request_id é opcional: usado quando o aceite está vinculado a um
  // serviço específico (ex.: vistoria de entrada/saída), não apenas ao usuário.
  novoAceiteTermo({ user_id, tipo, nome, cpf, versao, service_request_id }){
    return { user_id, tipo, nome, cpf: cpf || '', versao, service_request_id: service_request_id || null, aceito_em: new Date().toISOString() };
  },

  // ---------- SERVICE_REQUESTS (solicitações de serviço) ----------
  // status: ver STATUS_SOLICITACAO (statusMachine.js)
  novaSolicitacao({ owner_id, property_id, categoria }){
    return {
      owner_id, property_id, categoria,
      status: STATUS_SOLICITACAO.DRAFT,
      data: null, horario: null, urgencia: 'Programado',
      detalhes: {},          // campos específicos da categoria (ver camposPorCategoria)
      observacoes: '',
      fotos: [],
      precificacao: null,    // snapshot do resultado do PricingService
      snapshot: null,        // fotografia completa no momento da publicação
      accepted_provider_id: null,
      accepted_at: null,
      historico_alteracoes: [], // cada alteração formal pós-aceite entra aqui
      alteracao_pendente: null, // proposta do profissional aguardando aprovação do anfitrião
      reclassificacao_pendente: null, // proposta de reclassificar modalidade de Limpeza, aguardando decisão do ADM
      finalizacao: null,        // { fotos, checklist, observacoes, horario_termino }
    };
  },
  validarSolicitacao({ property_id, categoria, data, horario, detalhes }){
    const erros = {};
    if(!property_id) erros.property_id = 'Selecione o imóvel.';
    if(!categoria) erros.categoria = 'Selecione a categoria.';
    if(!data) erros.data = 'Selecione a data.';
    if(!horario) erros.horario = 'Selecione o horário.';
    if(categoria === CATEGORIAS_SERVICO.REPAROS){
      if(!detalhes || (!detalhes.descricao && !detalhes.necessitaAvaliacao)){
        erros.descricao = 'Descreva o problema ou marque "necessita avaliação".';
      }
    }
    return erros;
  },

  // ---------- OCCURRENCES (ocorrências operacionais do profissional — NUNCA "antecedentes") ----------
  // tipo: 'atraso' | 'cancelamento' | 'divergencia' | 'problema_execucao' | 'descumprimento_procedimento' | 'ocorrencia_resolvida'
  novaOcorrencia({ provider_id, tipo, descricao, service_request_id, registrado_por }){
    return { provider_id, tipo, descricao: descricao || '', service_request_id: service_request_id || null, registrado_por: registrado_por || null };
  },

  // ---------- INTERESTS (interesse de profissionais numa solicitação) ----------
  // status: 'interessado' | 'aceito' | 'recusado' | 'cancelado'
  novoInteresse({ service_request_id, provider_id }){
    return { service_request_id, provider_id, status: 'interessado' };
  },

  // ---------- CHAT_MESSAGES (chat oficial por solicitação) ----------
  // tipo: 'texto' | 'foto' | 'video' | 'documento' | 'sistema' | 'alteracao_formal' | 'ocorrencia'
  novaMensagem({ service_request_id, remetente_id, tipo, texto, anexos }){
    return {
      service_request_id, remetente_id, tipo,
      texto: texto || '', anexos: anexos || [], // anexos: [{tipo, nome, dataUrl}]
      bloqueada: false, motivo_bloqueio: null,
    };
  },

  // ---------- EVIDENCES (ocorrências/evidências vinculadas à solicitação) ----------
  novaEvidencia({ service_request_id, user_id, tipo, texto, fotos, videos, gps }){
    return {
      service_request_id, user_id, tipo, texto: texto || '',
      fotos: fotos || [], videos: videos || [], gps: gps || null,
    };
  },

  // ---------- PAYMENTS (arquitetura financeira — sandbox, ver README) ----------
  // status: ver FINANCIAL_STATUS (statusMachine.js)
  novoPagamento({ service_request_id, valor_anfitriao, valor_profissional, comissao_plataforma, taxa_conveniencia }){
    return {
      service_request_id,
      valor_anfitriao, valor_profissional, comissao_plataforma, taxa_conveniencia,
      taxa_deslocamento_disponibilidade: 0,
      ajustes: [], // [{descricao, valor, em}]
      status: FINANCIAL_STATUS.PENDING,
      gateway: 'sandbox', // identifica claramente que não é um provedor real
      gateway_referencia: null,
      historico_status: [{ status: FINANCIAL_STATUS.PENDING, em: new Date().toISOString() }],
    };
  },

  // ---------- DISPUTES (protocolo de divergência) ----------
  // status: 'aberta' | 'respondida' | 'decidida'
  novaDivergencia({ service_request_id, aberta_por_user_id, motivo, descricao, evidencia_id, status_antes_disputa, severidade }){
    return {
      service_request_id, aberta_por_user_id, motivo, descricao: descricao || '',
      severidade: severidade || 'media', // 'baixa'|'media'|'alta'|'critica' — ver SEVERIDADES_DIVERGENCIA
      evidencia_id: evidencia_id || null,
      status_antes_disputa: status_antes_disputa || null, // status da solicitação no momento em que a divergência foi aberta — usado para retomar corretamente
      status: 'aberta',
      resposta_anfitriao: null,       // { texto, evidencia_id, em }
      decisao: null,                  // { decisao_de, responsavel, aplicar_taxa, valor_taxa, texto, em }
    };
  },

  // ---------- SERVICE_CATEGORIES ----------
  // status: 'ativo' | 'inativo'
  novaCategoria({ nome }){
    return { nome, status: 'ativo' };
  },

  // ---------- AVAILABILITY ----------
  // status: 'livre' | 'reservado'
  novaDisponibilidade({ provider_id, data, horario_inicio, horario_fim }){
    return { provider_id, data, horario_inicio, horario_fim, status: 'livre' };
  },

  // ---------- NOTIFICATIONS ----------
  novaNotificacao({ user_id, tipo, titulo, mensagem }){
    return { user_id, tipo, titulo, mensagem, lida: false };
  },

  // ---------- AUDIT_LOGS ----------
  novoAuditLog({ user_id, acao, entidade, entidade_id, dados_anteriores, dados_novos }){
    return { user_id, acao, entidade, entidade_id, dados_anteriores: dados_anteriores || null, dados_novos: dados_novos || null };
  },

  // ---------- REVIEWS ----------
  novaReview({ service_request_id, avaliador_id, avaliado_id, nota, comentario }){
    return { service_request_id: service_request_id || null, avaliador_id, avaliado_id, nota, comentario: comentario || '' };
  },
};
