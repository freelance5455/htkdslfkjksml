/* Veiculos novos: M2, T-27, L3/35, Panzer I, ZSU-23-4, M109 */
/* ---------- M2 Light Tank, T-27, L3/35, Panzer I, ZSU-23-4 Shilka e M109: modelos e animacoes ---------- */
const n6W={m:tw(.3),ms:tw(.4,1),mi:tw(.36),k:tw(.16),tw:tw(.22),ts:tw(.3,1),ti:tw(.26),lw:tw(.2),ls:tw(.28,1),li:tw(.24),pw:tw(.3),ps:tw(.42,1),pi:tw(.38),zw:tw(.42),zs:tw(.5,1),zi:tw(.46),hw:tw(.4),hs:tw(.5,1),hi:tw(.45)};
const n6Star=c=>canvasTex(64,64,x=>{x.fillStyle=c;x.beginPath();for(let i=0;i<10;i++){const a=-1.5708+i*.6283,r=i%2?12:28;x[i?'lineTo':'moveTo'](32+Math.cos(a)*r,32+Math.sin(a)*r)}x.fill()});
const n6Us=n6Star('#f3ecd8'),n6Ru=n6Star('#d6452f'),n6It=canvasTex(96,64,(x,w,h)=>{['#2f8a3a','#f3ecd8','#d6452f'].forEach((c,i)=>{x.fillStyle=c;x.fillRect(i*w/3,0,w/3,h)})});
const n6N={m2:numTx('M2'),t27:numTx('T-27'),l3:numTx('L3/35'),pz:numTx('Pz I'),zsu:numTx('ZSU'),m109:numTx('M109')};
const n6Dish=new THREE.MeshLambertMaterial({color:0x8a8c80,side:THREE.DoubleSide}),n6Red=new THREE.MeshBasicMaterial({color:0xff2a1a});
/* rodagem comum: rodas giram, truques balancam, casco vibra, antena balanca */
function n6Run(t,dt,now,th,gx,fr,amp,vb){const d=trkStep(t,dt,gx);for(const w of t.wheels){w.rotation.x+=d[w.userData.s]/w.userData.r}
  if(t.bogs)t.bogs.forEach((b,i)=>b.rotation.x=Math.sin(now*fr+i*1.9)*amp*th);
  t.hull.position.y=Math.sin(now*34+t.x)*((vb||1)*(.008+.014*th))-t.recoil*.03;t.hull.rotation.x=-t.recoil*.02;t.ant.rotation.x=-t.v*.014+Math.sin(now*3+t.z)*.04}
function n6Burst(t,dt,gap){if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=gap;t.bfi=1;fire(t);t.bfi=0}}}
/* canos multiplos: a cada tiro um cano recua, solta cartucho e acende o seu clarao */
function n6Gun(t,dt,k,n,rec){
  if(t.lf!==t.gLf){t.gLf=t.lf;t.gk=(t.gk||0)+1;const gg=t.gb[t.gk%n];gg.userData.r=1;gg.localToWorld(v2.set(0,-.1,rec));puff(v2,0xd9b24a,.18,2.5,.4,1)}
  for(const gg of t.gb){if(gg.userData.r>0)gg.userData.r=Math.max(0,gg.userData.r-dt*9);gg.position.z=-gg.userData.r*k}
  if(t.fl.visible){const q=(t.gk||0)%n;t.fl.children.forEach((c,i)=>c.visible=i===q)}}
const n6Fl=(bar,pts,z,r,fm)=>{const fl=new THREE.Group();for(const p of pts){const f=new THREE.Group();f.position.set(p[0],p[1],0);f.add(new THREE.Mesh(new THREE.ConeGeometry(r,r*3.6,10).rotateX(-Math.PI/2),fm).translateZ(z+r*1.8),new THREE.Mesh(new THREE.SphereGeometry(r*.8,8,6),fm).translateZ(z));fl.add(f)}fl.visible=false;bar.add(fl);return fl};
/* truque VVSS: duas rodas num balanceiro com mola */
const n6Bog=(g,G,sx,y,z,r,s,wheels,bogs,dk,sp)=>{const b=new THREE.Group();b.position.set(sx,y,z);wl(b,G,0,0,-sp,r,s,wheels);wl(b,G,0,0,sp,r,s,wheels);b.add(bx(.12,.1,sp*2.3,dk,0,.1,0),bx(.16,.3,.16,dk,0,.3,0),bx(.3,.08,.3,dk,0,.48,0));g.add(b);bogs.push(b)};

/* ===== M2 Light Tank (EUA, 1935): torre unica com canhao de 37 mm, metralhadoras, casco rebitado, truques VVSS ===== */
function makeM2(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x5a6a3a),g=new THREE.Group(),wheels=[],bogs=[],GX=1.12,DK=0x2b2d28,MT=0x4a4b42,GL=0x2a4a5c;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-1.9,.14],[1.5,.14],[1.95,.5],[1.85,.85],[1.5,.97],[-1.6,.97],[-2.05,.75],[-2.1,.35]],54,.42,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,n6W.ms,sx,.58,1.75,.4,s,wheels);wl(g,n6W.mi,sx,.48,-1.95,.36,s,wheels);
    n6Bog(g,n6W.m,sx,.42,-.85,.3,s,wheels,bogs,dark,.38);n6Bog(g,n6W.m,sx,.42,.6,.3,s,wheels,bogs,dark,.38);
    for(const z of[-.1,1.3])wl(g,n6W.k,sx,.8,z,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(1.9,.55,4.3,'M',0,.78,0);H.b(2.1,.16,3.9,DK,0,.45,0);H.b(2.15,.42,2.5,'M',0,1.2,-.3);H.b(1.9,.1,1.2,'M',0,1.02,1.55,.5);H.b(2,.46,.1,'M',0,.72,2.2,-.12);H.b(2.15,.55,.1,'M',0,.95,-2.2,.12);
  for(let k=0;k<7;k++)H.b(1.2,.03,.1,MT,0,1.43,-1.6+k*.22);
  H.b(.34,.07,.05,GL,-.55,1.12,1.97);H.c(.08,.08,.06,DK,.7,1.0,2.22,'z');H.c(.035,.035,.55,DK,.7,1,2.5,'z');H.b(.4,.2,.05,DK,.7,.9,2.3);
  for(const s of[-1,1]){for(let k=0;k<10;k++)H.b(.05,.05,.05,MT,s*1.08,1.25,-1.5+k*.33);
    H.b(.5,.05,4.5,'M',s*1.15,1.0,0);H.b(.5,.05,.7,'M',s*1.15,1.1,2.25,.4);H.b(.34,.2,.8,MT,s*1.15,1.12,-.9);H.c(.08,.08,.45,DK,s*1.2,1.2,-1.8,'z');
    hull.add(bx(.2,.16,.08,lamp,s*.8,.98,2.24),bx(.26,.16,.08,brkM,s*.8,1,-2.3))}
  H.c(.1,.1,.45,DK,.65,.95,-2.4,'z');H.c(.15,.15,.5,DK,.65,1.05,-2.1,'z');H.c(.04,.04,2.2,DK,-.9,1.06,.4,'z');
  H.out(hull,mat);g.add(hull);
  for(const s of[-1,1]){stk(hull,n6Us,s*1.09,1.2,.55,s,.6,.6);stk(hull,n6N.m2,s*1.09,1.15,-.5,s,.6,.3)}
  const ll=mkLid(hull,mat,-.55,1.43,.8,.28),ant=mkAnt(hull,.9,1.3,-1.9,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.41,.15);
  T.c(.85,.95,.5,'M',0,.25,0,'y');T.c(.7,.8,.16,'M',0,.58,0,'y');T.b(1.2,.4,.5,'M',0,.28,-.7);T.c(.28,.3,.14,MT,-.3,.7,-.2,'y');
  for(let k=0;k<5;k++){const a=k/5*6.283;T.b(.1,.06,.04,GL,-.3+Math.sin(a)*.28,.78,-.2+Math.cos(a)*.28,0,a)}
  T.b(.5,.35,.05,DK,.4,.3,.74);T.c(.05,.05,.04,DK,.93,.3,0,'x');T.c(.05,.05,.04,DK,-.93,.3,0,'x');T.b(.3,.06,.5,MT,.4,.7,-.5);
  T.out(tg,mat);for(const s of[-1,1])stk(tg,n6N.m2,s*.96,.28,-.25,s,.7,.35);
  const cl=mkLid(tg,mat,-.3,.78,-.2,.24),crew=mkCrew(tg,cm,hm,sk,-.3,.45,-.2),cmg=mkMG(tg,.4,.76,.1);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.3,.72);
  B.b(.42,.34,.22,'M',0,0,.1);B.c(.14,.16,.2,DK,0,0,.28,'z');B.out(bp,mat);
  K.c(.05,.043,2,DK,0,0,1.1,'z');K.c(.075,.075,.5,'M',0,0,.45,'z');K.c(.065,.065,.1,DK,0,0,2.1,'z');K.c(.022,.022,.5,DK,.16,0,.55,'z');K.out(bar,mat);
  const fl=mkFl(bar,2.2,.3,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,cmg,fl,brkM,wheels,bogs,trk,mat,dark,m2lt:true,cannon:true,spd:1.25,trn:1.1,L:2.4,W:1.4,mz:2.3,fk:.7,rld:1.5,wd:1.4,armor:.6,hp:70,TY:1.41}));
}
function animM2(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/13,0,1);n6Run(t,dt,now,th,1.12,9,.05);
  tankFx(t,dt,now,th,{ex:[[.65,1,-2.6]],dk:[[1.3,.2,-2.1],[-1.3,.2,-2.1]],mz:2.3,rr:1.8,rc:.4});
  mgScan(t,dt,50);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);
}

/* ===== T-27 (URSS, 1931): tankette de dois tripulantes, torre minuscula deslocada para a direita com metralhadora DT ===== */
function makeT27(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x4f5a36),g=new THREE.Group(),wheels=[],bogs=[],GX=.82,DK=0x2b2d28,MT=0x4a4b42,GL=0x2a4a5c;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-1.1,.1],[.85,.1],[1.15,.32],[1.1,.6],[.85,.7],[-.9,.7],[-1.25,.5],[-1.25,.25]],36,.3,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,n6W.ts,sx,.4,.9,.3,s,wheels);wl(g,n6W.ti,sx,.36,-1.0,.26,s,wheels);
    n6Bog(g,n6W.tw,sx,.32,-.35,.22,s,wheels,bogs,dark,.2);n6Bog(g,n6W.tw,sx,.32,.3,.22,s,wheels,bogs,dark,.2)});
  const hull=new THREE.Group(),H=mb();
  H.b(1.45,.45,2.5,'M',0,.6,0);H.b(1.6,.12,2.3,DK,0,.34,0);H.b(1.5,.5,1.3,'M',0,1,-.15);H.b(1.45,.1,.9,'M',0,.86,.95,.3);H.b(1.5,.4,.08,'M',0,.5,1.28,-.1);H.b(1.6,.5,.08,'M',0,.6,-1.28,.1);
  for(let k=0;k<4;k++)H.b(.9,.03,.07,MT,0,.98-k*.05,.75+k*.18);
  H.b(.4,.08,.04,GL,-.4,1.1,.5);H.b(.25,.06,.2,DK,0,.35,1.4);H.c(.04,.04,.3,DK,0,.5,-1.45,'z');H.c(.06,.06,.5,DK,.55,.7,-1.5,'z');
  for(const s of[-1,1]){H.b(.3,.04,2.8,'M',s*.9,.78,0);H.b(.3,.04,.5,'M',s*.9,.85,1.4,.4);H.b(.25,.12,.6,MT,s*.9,.86,-.4);
    for(let k=0;k<6;k++)H.b(.04,.04,.04,MT,s*.76,1.0,-.7+k*.28);hull.add(bx(.16,.14,.08,lamp,s*.55,.7,1.3),bx(.2,.14,.08,brkM,s*.6,.7,-1.33))}
  H.out(hull,mat);g.add(hull);
  for(const s of[-1,1]){stk(hull,n6Ru,s*.76,1.05,.15,s,.4,.4);stk(hull,n6N.t27,s*.76,.78,-.55,s,.5,.25)}
  const ll=mkLid(hull,mat,-.4,1.26,-.25,.24),ant=mkAnt(hull,-.6,.95,-1.1,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(.38,1.25,-.3);
  T.c(.38,.42,.4,'M',0,.2,0,'y');T.c(.3,.36,.1,'M',0,.45,0,'y');T.b(.1,.06,.04,GL,-.2,.3,.34);T.b(.1,.06,.04,GL,.2,.3,.34);T.out(tg,mat);
  const cl=mkLid(tg,mat,0,.5,0,.2),crew=mkCrew(tg,cm,hm,sk,0,.1,0);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.22,.38);
  B.b(.2,.22,.2,'M',0,0,.08);B.c(.1,.12,.1,DK,0,0,.2,'z');B.out(bp,mat);
  K.c(.025,.022,.9,DK,0,0,.6,'z');K.c(.05,.05,.35,MT,0,0,.4,'z');K.c(.12,.12,.06,MT,0,.12,.1,'y');for(let k=0;k<4;k++)K.c(.056,.056,.02,DK,0,0,.28+k*.07,'z');K.out(bar,mat);
  const fl=mkFl(bar,1.05,.14,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,fl,brkM,wheels,bogs,trk,mat,dark,t27:true,cannon:true,spd:1.35,trn:1.3,L:1.5,W:1,mz:1.15,fk:.3,rld:.6,wd:1,armor:.4,hp:45,TY:1.25}));
}
function animT27(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/13,0,1);n6Run(t,dt,now,th,.82,12,.07,1.6);
  t.hull.rotation.z=Math.sin(now*47+t.z)*.005*(.4+th);t.hull.position.x=Math.sin(now*53+t.x)*.004*(.4+th);
  n6Burst(t,dt,.11);
  tankFx(t,dt,now,th,{ex:[[.55,.7,-1.8]],dk:[[.9,.2,-1.3],[-.9,.2,-1.3]],mz:1.15,rr:2.4,rc:.12});
}

/* ===== L3/35 (Italia): tankette com duas metralhadoras Breda de 8 mm num reparo frontal de giro limitado ===== */
function makeL3(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x7a7352),g=new THREE.Group(),wheels=[],bogs=[],GX=.72,DK=0x2b2d28,MT=0x4a4b42,GL=0x2a4a5c;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-1.15,.1],[.95,.1],[1.2,.3],[1.15,.55],[.9,.65],[-.95,.65],[-1.25,.45],[-1.2,.25]],34,.26,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,n6W.ls,sx,.38,.9,.28,s,wheels);wl(g,n6W.li,sx,.34,-1.0,.24,s,wheels);
    n6Bog(g,n6W.lw,sx,.3,-.4,.2,s,wheels,bogs,dark,.18);n6Bog(g,n6W.lw,sx,.3,.3,.2,s,wheels,bogs,dark,.18)});
  const hull=new THREE.Group(),H=mb();
  H.b(1.3,.42,3,'M',0,.58,0);H.b(1.4,.12,2.7,DK,0,.34,0);H.b(1.2,.5,1.5,'M',0,1,-.1);H.b(1.2,.1,.8,'M',0,.9,1.15,.6);H.b(1.2,.4,.08,'M',0,.45,1.5,-.1);H.b(1.4,.5,.08,'M',0,.6,-1.5,.12);
  H.b(.3,.08,.04,GL,-.4,1.12,.67);for(let k=0;k<5;k++)H.b(.7,.03,.07,MT,0,.78,-1.0+k*.15,.1);
  H.c(.07,.07,.7,DK,.45,.65,-1.7,'z');H.c(.11,.11,.4,DK,.45,.72,-1.4,'z');H.b(.25,.06,.2,DK,0,.35,1.6);H.c(.04,.04,.3,DK,0,.5,-1.65,'z');
  for(const s of[-1,1]){H.b(.26,.04,3,'M',s*.78,.8,0);H.b(.26,.04,.5,'M',s*.78,.88,1.6,.4);H.b(.2,.12,.6,MT,s*.78,.86,-.6);
    for(let k=0;k<7;k++)H.b(.04,.05,.05,MT,s*.61,1.1,-.8+k*.25);hull.add(bx(.14,.14,.08,lamp,s*.5,.72,1.52),bx(.18,.14,.08,brkM,s*.5,.72,-1.55))}
  H.out(hull,mat);g.add(hull);
  for(const s of[-1,1]){stk(hull,n6It,s*.61,1.0,-.1,s,.42,.28);stk(hull,n6N.l3,s*.67,.62,.3,s,.5,.25)}
  const cl=mkLid(hull,mat,.3,1.26,-.35,.22),ll=mkLid(hull,mat,-.3,1.26,-.35,.22),crew=mkCrew(hull,cm,hm,sk,.3,1.0,-.35),ant=mkAnt(hull,-.55,.85,-1.2,flagM);
  /* reparo frontal: escudo, berco e duas metralhadoras com camisas de refrigeracao perfuradas */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.0,.65);
  T.b(.8,.46,.3,'M',0,0,.12);T.b(.9,.5,.06,'M',0,0,.3);T.b(.3,.06,.05,DK,-.2,.12,.34);T.b(.3,.06,.05,DK,.2,.12,.34);T.out(tg,mat);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb();bp.position.set(0,0,.3);
  B.b(.6,.3,.2,DK,0,0,.05);B.out(bp,mat);const gb=[];
  for(const x of[-.17,.17]){const gg=new THREE.Group(),K=mb();gg.position.set(x,0,0);K.c(.022,.02,.8,DK,0,0,.6,'z');K.c(.045,.045,.5,MT,0,0,.4,'z');for(let k=0;k<5;k++)K.c(.055,.055,.025,DK,0,0,.2+k*.09,'z');K.b(.08,.1,.3,DK,0,.1,.08);K.out(gg,mat);bar.add(gg);gg.userData.r=0;gb.push(gg)}
  const fl=n6Fl(bar,[[-.17,0],[.17,0]],1.05,.12,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,gb,lid:[cl,ll],crew,fl,brkM,wheels,bogs,trk,mat,dark,l3:true,lim:.3,cannon:true,spd:1.3,trn:1.25,L:1.4,W:.9,mz:1.15,fk:.3,rld:.6,wd:1,armor:.4,hp:42,TY:1.0,gLf:-9}));
}
function animL3(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const r=angDiff(t.yaw,t.hd),e=Math.abs(r)-t.lim;if(e>0)t.hd+=Math.sign(r)*Math.min(e,t.trn*1.1*dt); /* reparo fixo: o casco inteiro gira para acompanhar a mira */
  const th=clamp(Math.abs(t.v)/13,0,1);n6Run(t,dt,now,th,.72,12,.07,1.5);
  t.hull.rotation.z=Math.sin(now*44+t.z)*.005*(.4+th);
  n6Burst(t,dt,.1);n6Gun(t,dt,.12,2,.9);
  tankFx(t,dt,now,th,{ex:[[.45,.72,-2.1]],dk:[[.75,.2,-1.5],[-.75,.2,-1.5]],mz:1.15,rr:2.4,rc:.05});
}

/* ===== Panzer I Ausf. B (Alemanha): duas MG 13 em torre cilindrica deslocada, 5 rodas com molas de lamina ===== */
function makePz1(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x5f6258),g=new THREE.Group(),wheels=[],bogs=[],GX=.85,DK=0x2b2d28,MT=0x4a4b42,GL=0x2a4a5c;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-2.1,.1],[1.8,.1],[2.2,.4],[2.15,.8],[1.75,.98],[-1.75,.98],[-2.3,.8],[-2.35,.35]],56,.36,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,n6W.ps,sx,.5,1.95,.42,s,wheels);wl(g,n6W.pi,sx,.48,-2.0,.38,s,wheels);wl(g,n6W.pw,sx,.4,1.2,.3,s,wheels);
    for(const z of[-1.05,.35]){const b=new THREE.Group();b.position.set(sx,.4,z);wl(b,n6W.pw,0,0,-.3,.3,s,wheels);wl(b,n6W.pw,0,0,.3,.3,s,wheels);b.add(bx(.1,.06,1.1,dark,0,.24,0),bx(.12,.3,.1,dark,0,.38,0));g.add(b);bogs.push(b)}
    for(const z of[-1.5,-.4,.7])wl(g,n6W.k,sx,.82,z,.14,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(1.7,.5,4.2,'M',0,.75,0);H.b(1.9,.14,3.8,DK,0,.45,0);H.b(1.7,.55,2,'M',0,1.25,.4);H.b(1.7,.1,.9,'M',0,1.0,1.75,.6);H.b(1.5,.4,.7,'M',0,.98,2.0);H.b(1.7,.4,.1,'M',0,.6,2.15,-.1);
  H.b(1.7,.35,1.5,'M',0,1.2,-1.45);H.b(1.7,.5,.1,'M',0,.9,-2.15,.15);for(let k=0;k<6;k++)H.b(1.2,.03,.08,MT,0,1.4,-2.0+k*.2);
  H.b(.3,.12,.05,GL,-.4,1.3,1.42);H.b(.22,.12,.05,GL,.4,1.3,1.42);H.c(.12,.12,.8,DK,.6,.85,-2.4,'z');H.c(.03,.03,1.1,DK,-.75,1.2,-1.4,'z');
  for(const s of[-1,1]){H.b(.4,.05,4.4,'M',s*1.0,.95,0);H.b(.4,.05,.6,'M',s*1,1.02,2.3,.4);H.b(.3,.2,.8,MT,s*1,1.08,-.8);H.c(.04,.04,2.6,DK,s*.9,1.03,.5,'z');H.b(.04,.4,.6,MT,s*.86,1.25,.2);
    hull.add(bx(.18,.18,.08,lamp,s*.7,1.1,2.2),bx(.22,.16,.08,brkM,s*.7,1,-2.2))}
  H.out(hull,mat);g.add(hull);
  for(const s of[-1,1])stk(hull,crossT,s*.87,1.25,.4,s,.4,.4);
  const ll=mkLid(hull,mat,-.4,1.55,.5,.25),ant=mkAnt(hull,.75,1.3,-1.7,flagM);
  const tg=new THREE.Group(),T=mb();tg.position.set(.3,1.53,.1);
  T.c(.62,.7,.5,'M',0,.25,0,'y');T.c(.55,.6,.14,'M',0,.58,0,'y');T.b(.6,.1,.5,'M',0,.5,-.3);T.c(.04,.04,.04,DK,.6,.3,.1,'x');T.c(.04,.04,.04,DK,-.6,.3,.1,'x');
  for(let k=0;k<3;k++)T.b(.1,.06,.04,GL,-.3+k*.3,.55,.58);T.out(tg,mat);
  for(const s of[-1,1])stk(tg,n6N.pz,s*.67,.3,-.1,s,.45,.22);
  const cl=mkLid(tg,mat,0,.65,-.1,.22),crew=mkCrew(tg,cm,hm,sk,0,.3,-.1);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb();bp.position.set(0,.28,.55);
  B.b(.55,.3,.2,'M',0,0,0);B.b(.46,.22,.1,DK,0,0,.12);B.out(bp,mat);const gb=[];
  for(const x of[-.12,.12]){const gg=new THREE.Group(),K=mb();gg.position.set(x,0,0);K.c(.025,.025,.7,DK,0,0,.55,'z');K.c(.045,.045,.6,MT,0,0,.4,'z');for(let k=0;k<4;k++)K.c(.056,.056,.03,DK,0,0,.2+k*.12,'z');K.c(.04,.04,.1,DK,0,0,.93,'z');K.out(gg,mat);bar.add(gg);gg.userData.r=0;gb.push(gg)}
  const fl=n6Fl(bar,[[-.12,0],[.12,0]],1.0,.14,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,gb,lid:[cl,ll],crew,fl,brkM,wheels,bogs,trk,mat,dark,pz1:true,cannon:true,spd:1.3,trn:1.15,L:2.3,W:1.2,mz:1.1,fk:.3,rld:.55,wd:1.3,armor:.5,hp:50,TY:1.53,gLf:-9}));
}
function animPz1(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/13,0,1);n6Run(t,dt,now,th,.85,10,.06,1.3);
  n6Burst(t,dt,.09);n6Gun(t,dt,.14,2,.9);
  tankFx(t,dt,now,th,{ex:[[.6,.85,-2.9]],dk:[[.95,.2,-2.2],[-.95,.2,-2.2]],mz:1.1,rr:2.4,rc:.05});
}

/* ===== ZSU-23-4 Shilka (Uniao Sovietica): 4 canhoes de 23 mm, radar RPK-2 que dobra em marcha e gira parado ===== */
function makeZSU(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x4d5a3a),g=new THREE.Group(),wheels=[],GX=1.5,DK=0x2b2d28,MT=0x4a4b42,GL=0x1d2f3a;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-2.8,.1],[2.8,.1],[3.25,.5],[3.2,.85],[2.8,1],[-2.8,1],[-3.3,.85],[-3.3,.45]],84,.6,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,n6W.zs,sx,.6,-2.8,.5,s,wheels);wl(g,n6W.zi,sx,.56,2.8,.46,s,wheels);
    for(let i=0;i<6;i++)wl(g,n6W.zw,sx,.52,-1.9+i*.76,.42,s,wheels).userData.b=1;for(const z of[-1.5,0,1.5])wl(g,gRL,sx,.82,z,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(2.7,.7,6.2,'M',0,.9,0);H.b(2.4,.14,5.9,DK,0,.5,0);H.b(3.2,.28,5.4,'M',0,1.2,-.35);H.b(2.8,.1,1.5,'M',0,1.15,2.7,.35);H.b(2.9,.5,.1,'M',0,.85,3.12,-.15);
  H.b(1.4,.4,1.2,'M',-.55,1.5,2.2);H.b(2.4,.45,.06,'M',0,1.5,3.15,.5);for(let k=0;k<3;k++)H.b(.28,.1,.05,GL,-.55+(k-1)*.35,1.58,2.82);
  H.b(2.6,.2,1.5,'M',0,1.45,-2.45);for(let k=0;k<8;k++)H.b(2,.03,.08,MT,0,1.56,-3.1+k*.18);H.b(2.5,.3,.2,DK,0,1.5,-3.3);H.c(.12,.12,2.8,DK,0,1.6,-3.35,'x');
  for(const s of[-1,1]){H.b(.05,.5,5.2,'M',s*1.6,1.05,-.2);H.b(.3,.25,.9,MT,s*1.45,1.42,-1.7);H.c(.1,.1,.5,DK,s*1,1.1,-3.3,'z');H.c(.04,.04,3,DK,s*1.4,1.38,.8,'z');
    for(let k=0;k<4;k++)H.b(.06,.25,.9,MT,s*1.62,1.0,1.9-k*1.2);hull.add(bx(.2,.2,.1,lamp,s*1.1,1.1,3.15),bx(.3,.2,.08,brkM,s*1.1,1.15,-3.4))}
  H.out(hull,mat);g.add(hull);
  const dl=mkLid(hull,mat,-.55,1.72,2.2,.27),drv=mkCrew(hull,cm,hm,sk,-.55,1.5,2.2),ant=mkAnt(hull,1.3,1.4,-2.8,flagM);
  for(const s of[-1,1])stk(hull,n6N.zsu,s*1.63,1.0,-2.1,s,.7,.35);
  /* torre larga e baixa de casamata, cavidade escura entre os dois pares de canhoes */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.34,-.2);
  T.b(2.8,.9,2.4,'M',0,.45,-.1);T.b(2.8,.12,.9,'M',0,.85,1.1,.5);T.b(1.3,.6,.3,DK,0,.5,1.1);T.b(1.6,.3,.9,DK,0,.95,-.9);T.c(.3,.34,.2,MT,0,.98,-.9,'y');
  for(const s of[-1,1]){T.b(.5,.6,.9,'M',s*1.35,.45,.65);T.b(.2,.35,1.4,MT,s*1.5,.5,-.7);for(let k=0;k<3;k++)T.c(.05,.05,.3,DK,s*1.25,.95,.5+k*.15,'y',0,0,-s*.5)}
  T.b(.4,.3,.5,DK,-.7,1.0,.4);T.b(.3,.12,.04,GL,-.7,1.02,.66);T.out(tg,mat);
  for(const s of[-1,1])stk(tg,n6N.zsu,s*1.41,.55,-.2,s,.7,.35);
  const cl=mkLid(tg,mat,.85,.92,-.6,.28),ll=mkLid(tg,mat,-.85,.92,-.6,.28),crew=mkCrew(tg,cm,hm,sk,-.85,.5,-.6),tant=mkAnt(tg,1.2,.9,-1.2,flagM);
  /* radar RPK-2: pedestal, prato parabolico articulado (dobra para tras), alimentador e luz vermelha */
  const rad=new THREE.Group();rad.position.set(0,1.1,-.9);const rd=new THREE.Group();
  rd.add(new THREE.Mesh(new THREE.SphereGeometry(.8,18,8,0,6.283,0,.9).rotateX(-Math.PI/2).translate(0,.8,.8),n6Dish),bx(.06,.06,.7,dark,0,.8,.3),bx(.1,.7,.1,dark,0,.35,-.05));
  const feed=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),dark);feed.position.set(0,.8,.65);rd.add(feed);rad.add(rd,bx(.5,.16,.5,dark,0,-.08,0));
  const beac=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),n6Red);beac.position.set(.5,.2,-.3);rad.add(beac);tg.add(rad);
  /* quatro canos: pares esquerdo/direito, cada um com camisa, freio de boca e recuo proprio */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb();bp.position.set(0,.55,1.2);const gb=[];
  for(const s of[-1,1]){B.b(.5,.8,.5,'M',s*.95,0,.3);B.b(.16,.16,.6,MT,s*.65,.2,.3);B.c(.12,.12,.3,0x1b1b1a,s*.95,0,.6,'z')}
  B.out(bp,mat);
  for(const[x,y]of[[-.95,.2],[-.95,-.2],[.95,.2],[.95,-.2]]){const gg=new THREE.Group(),K=mb();gg.position.set(x,y,0);
    K.c(.1,.1,1,'M',0,0,.7,'z');K.c(.05,.05,2.8,DK,0,0,1.8,'z');K.c(.08,.08,.5,DK,0,0,3.3,'z');for(let k=0;k<4;k++)K.c(.11,.11,.04,MT,0,0,.4+k*.18,'z');K.out(gg,mat);bar.add(gg);gg.userData.r=0;gb.push(gg)}
  const fl=n6Fl(bar,[[-.95,.2],[-.95,-.2],[.95,.2],[.95,-.2]],3.6,.26,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,tant,gb,rad,rd,feed,beac,dl,drv,lid:[cl,ll],crew,fl,brkM,wheels,trk,mat,dark,zsu:true,cannon:true,spd:1.2,trn:.95,L:3.5,W:1.9,mz:3.65,fk:.28,rld:1.1,wd:1.6,armor:.6,hp:75,TY:1.34,gLf:-9}));
}
function animZSU(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.drv.visible=false;t.dl.rotation.x=-1.4;return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/14,0,1);n6Run(t,dt,now,th,1.5,10,0);
  t.wheels.forEach(w=>{if(w.userData.b)w.position.y=.52+Math.sin(now*11+w.position.z*2)*.02*th});
  t.tant.rotation.x=-t.v*.01+Math.sin(now*2.5+t.x)*.03;
  /* radar: de pe e girando quando parado ou com alvo, dobrado para tras em marcha */
  const up=(Math.abs(t.v)<4||t.mgt)?1:0;t.ru=(t.ru||0)+(up-(t.ru||0))*Math.min(1,dt*2.2);
  t.rd.rotation.x=-1.45*(1-t.ru);t.rad.rotation.y+=dt*(t.mgt?9:4)*t.ru;t.feed.position.x=Math.sin(now*16)*.04*t.ru;
  t.beac.material.color.setHex(Math.sin(now*5)>0?0xff2a1a:0x4a0c08);
  n6Burst(t,dt,.06);n6Gun(t,dt,.4,4,3.4);
  tankFx(t,dt,now,th,{ex:[[1,1.1,-3.5],[-1,1.1,-3.5]],dk:[[1.7,.2,-3.3],[-1.7,.2,-3.3],[1.7,.2,3.2],[-1.7,.2,3.2]],mz:3.65,rr:3,rc:.05});
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  mgScan(t,dt,170);
}

/* ===== M109 (EUA): obuseiro autopropulsado de 155 mm, casco de aluminio, torre traseira, pa de ancoragem e escotilha de municao ===== */
function makeM109(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x56603f),g=new THREE.Group(),wheels=[],GX=1.48,DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,brM=new THREE.MeshLambertMaterial({color:0xb08a3a});
  g.rotation.order='YXZ';
  const trk=trackLoop([[-2.95,.1],[2.7,.1],[3.2,.45],[3.15,.95],[2.8,1.12],[-2.7,1.08],[-3.2,.8],[-3.15,.3]],80,.52,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{wl(g,n6W.hs,sx,.6,2.95,.5,s,wheels);wl(g,n6W.hi,sx,.55,-2.95,.45,s,wheels);
    for(let i=0;i<7;i++)wl(g,n6W.hw,sx,.5,-2.2+i*.72,.4,s,wheels).userData.b=1;for(const z of[-1.4,0,1.4])wl(g,gRL,sx,.93,z,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(2.8,.7,6,'M',0,.9,-.2);H.b(2.5,.12,5.8,DK,0,.5,-.2);H.b(3.1,.1,5.2,'M',0,1.28,-.3);H.b(2.8,.1,1.2,'M',0,1.15,2.6,.45);H.b(2.8,.5,.1,'M',0,.8,3.1,-.1);H.b(2.9,.6,.3,'M',0,.95,-3.2);
  H.b(.9,.34,.9,'M',-.85,1.5,2.2);H.c(.3,.32,.06,MT,-.85,1.7,2.2,'y');for(let k=0;k<3;k++)H.b(.2,.09,.05,GL,-.85+(k-1)*.28,1.55,2.67);
  H.b(1.4,.2,1.8,'M',.85,1.45,2.3);for(let k=0;k<7;k++)H.b(1.28,.03,.07,MT,.85,1.56,1.55+k*.25);
  for(const s of[-1,1]){for(let k=0;k<5;k++)H.b(.06,.55,1,'M',s*1.65,.95,2.2-k*1.15);H.b(.4,.3,.9,MT,s*1.45,1.5,-2.5);H.c(.05,.05,2.8,DK,s*1.3,1.4,.9,'z');H.b(.3,.12,.5,DK,s*1.3,1.38,-3.3);
    hull.add(bx(.2,.18,.1,lamp,s*1.3,1.4,3.12),bx(.3,.2,.08,brkM,s*1.2,1,-3.37))}
  H.out(hull,mat);g.add(hull);
  for(const s of[-1,1]){stk(hull,n6Us,s*1.69,.95,1.4,s,.55,.55);stk(hull,n6N.m109,s*1.69,.95,-.2,s,.7,.35)}
  const dl=mkLid(hull,mat,-.85,1.75,2.2,.27),drv=mkCrew(hull,cm,hm,sk,-.85,1.4,2.2);
  /* pa de ancoragem traseira, dobrada sobre o casco e cravada no chao quando para */
  const spade=new THREE.Group(),S=mb();spade.position.set(0,1.1,-3.35);
  S.b(3,1,.1,'M',0,-.5,0);for(const x of[-1,0,1])S.b(.12,.9,.16,DK,x,-.5,.1);S.b(3,.14,.26,DK,0,-1,.08,.5);S.out(spade,mat);hull.add(spade);
  /* torre grande e alta a ré, com recesso escuro e escotilha traseira de municao */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.33,-.9);
  T.b(3,1.15,3.2,'M',0,.58,-.2);T.b(2.8,.1,1.1,'M',0,1.17,.9,.25);T.b(1.5,.7,.1,DK,0,.55,1.42);T.b(2.6,.9,.4,'M',0,.5,-1.95);T.b(1.5,.8,.06,DK,0,.5,-2.17);
  for(const s of[-1,1]){T.b(.3,.5,1,'M',s*1.65,.6,-1.2);for(let k=0;k<4;k++)T.c(.06,.06,.42,DK,s*1.58,.95,.7+k*.15,'y',0,0,-s*.5)}
  T.b(.5,.14,.7,MT,-.8,1.2,-.5);T.out(tg,mat);
  for(const s of[-1,1])stk(tg,n6N.m109,s*1.51,.6,-.3,s,.8,.4);
  const cup=new THREE.Group(),C=mb();cup.position.set(.8,1.15,.1);C.c(.42,.46,.3,'M',0,.15,0,'y');for(let k=0;k<8;k++){const a=k/8*6.2832;C.b(.1,.07,.04,GL,Math.sin(a)*.44,.2,Math.cos(a)*.44,0,a)}C.out(cup,mat);tg.add(cup);
  const cl=mkLid(cup,mat,0,.32,0,.26),ll=mkLid(tg,mat,-.8,1.2,-.5,.27),crew=mkCrew(cup,cm,hm,sk,0,-.1,0),crew2=mkCrew(tg,cm,hm,sk,-.8,.85,-.5),cmg=mkMG(tg,.8,1.55,.3),ant=mkAnt(tg,1.3,1.15,-1.5,flagM);
  const rh=new THREE.Group(),RH=mb();rh.position.set(0,.1,-2.2);RH.b(1.5,.8,.06,'M',0,.4,0);RH.b(1.3,.06,.1,MT,0,.8,0);RH.out(rh,mat);tg.add(rh);
  const shl=new THREE.Group();shl.position.set(0,.6,-2.4);shl.visible=false;shl.add(new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,.7,8).rotateX(Math.PI/2),dark),new THREE.Mesh(new THREE.CylinderGeometry(.08,.08,.3,8).rotateX(Math.PI/2),brM).translateZ(-.5));tg.add(shl);
  /* canhao M284 L/39: berco, cilindros de recuo, extrator de gases e freio de boca de dois defletores */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.65,1.35);
  B.b(1,.8,.7,'M',0,0,.3);B.c(.3,.34,.3,DK,0,0,.7,'z');for(const s of[-1,1])B.c(.07,.07,1.4,MT,s*.28,.4,.9,'z');B.out(bp,mat);
  K.c(.2,.18,.7,DK,0,0,.9,'z');K.c(.14,.14,1.8,DK,0,0,2,'z');K.c(.1,.1,5.4,DK,0,0,3.6,'z');K.c(.17,.17,.9,DK,0,0,4.4,'z');K.c(.18,.18,.05,MT,0,0,3.95,'z');K.c(.18,.18,.05,MT,0,0,4.85,'z');
  K.c(.19,.19,.8,DK,0,0,6.3,'z');for(const z of[6,6.3,6.6])K.c(.23,.23,.05,MT,0,0,z,'z');K.out(bar,mat);
  const fl=mkFl(bar,6.9,.55,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,spade,rh,shl,dl,drv,crew,crew2,lid:[cl,ll],cup,cmg,fl,brkM,wheels,trk,mat,dark,m109:true,cannon:true,spd:1.1,trn:.85,L:3.7,W:2,mz:6.8,fk:1.5,rld:3.6,wd:1.9,armor:.7,hp:100,TY:1.33}));
}
function animM109(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){t.drv.visible=false;t.crew2.visible=false;t.shl.visible=false;t.dl.rotation.x=-1.5;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.rh.rotation.x=-1.5;t.spade.rotation.x=.3;
    if(t.ck===undefined)t.ck=6;if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;if(t.ckt<=0){t.ckt=.1+Math.random()*.1;t.tg.localToWorld(v2.set((Math.random()-.5)*2,.9,-1.6-Math.random()*.6));puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.1,5,.5,8);puff(v2,0x1f1e1c,1.5,3,1.5,5);if(Math.random()<.25){puff(v2,0xff6a20,2.4,8,.4,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY)}
  const th=clamp(Math.abs(t.v)/14,0,1),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);n6Run(t,dt,now,th,1.48,10,0);
  t.wheels.forEach(w=>{if(w.userData.b)w.position.y=.5+Math.sin(now*11+w.position.z*2.1)*.025*th});t.hull.rotation.x-=ac*.004;t.hull.rotation.z=-(t.st||0)*th*.03;
  /* parado cerca de 1 s a pa desce e crava: recarga mais rapida e menos recuo */
  const still=Math.abs(t.v)<.6&&Math.abs(t.st||0)<.15;t.stead=clamp((t.stead||0)+(still?dt/1.3:-dt*1.8),0,1);t.rld=3.6-1.3*t.stead;
  t.spU=(t.spU||0)+((t.stead>.45?1:0)-(t.spU||0))*Math.min(1,dt*3);t.spade.rotation.x=-1.3+t.spU*1.6;
  if(t.spU>.9){if(!t.spL){t.spL=1;t.g.localToWorld(v2.set(0,.3,-3.5));for(let i=0;i<6;i++)puff(v2,0xa89a78,1.3,2.5,.8,1.2)}}else if(t.spU<.6)t.spL=0;
  /* cada tiro: freio de boca sopra poeira dos lados, escotilha abre e o projetil desliza para o carregador */
  if(t.pLf===undefined){t.pLf=t.lf;t.pRt=-1}
  if(t.lf!==t.pLf){t.pLf=t.lf;t.pRt=0;for(const s of[-1,1]){t.bar.localToWorld(v2.set(s*.4,0,6.3));puff(v2,0xe6dcc8,1.4,4,.7,1.2)}t.g.localToWorld(v2.set(0,.3,2.4));for(let i=0;i<4;i++)puff(v2,0xb5a584,2.2,6,1,.5)}
  if(t.pRt>=0){t.pRt+=dt;const u=t.pRt,op=u<.25?u/.25:u<1.6?1:Math.max(0,1-(u-1.6)/.3);t.rh.rotation.x=-1.4*op;t.shl.visible=u>.3&&u<1.5;t.shl.position.z=-2.4+clamp((u-.3)/.9,0,1)*1.1;if(u>1.95){t.pRt=-1;t.rh.rotation.x=0;t.shl.visible=false}}
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.6+t.x)*1.3;
  tankFx(t,dt,now,th,{ex:[[1.25,1.55,2.6]],dk:[[1.7,.2,-3.1],[-1.7,.2,-3.1],[1.7,.2,3.1],[-1.7,.2,3.1]],mz:6.8,rr:.7,rc:1.1});
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  t.crew2.visible=t.open>.6;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  mgScan(t,dt,50);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);
}

