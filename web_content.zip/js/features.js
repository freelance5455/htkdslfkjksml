/* =========================================================================
   Aethervale — Fitur lanjutan
   Status & DoT, efek senjata, mesin skill, sarang bos per bioma, pedesaan,
   AI pola bos, Mode Boss Clash, dan pasca-proses shader (DLSS 5).
   Dimuat SETELAH main.js — menambal beberapa kait Game.
   ========================================================================= */

/* ---------- utilitas ---------- */
function hash32(a, b, c) {
  let h = 2166136261 ^ (a * 374761393) ^ (b * 668265263) ^ ((c || 0) * 2246822519);
  h = Math.imul(h ^ (h >>> 15), 2246822519);
  h ^= h >>> 13; h = Math.imul(h, 3266489917); h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

/* ======================= STATUS & DOT PADA MUSUH ======================= */
const Status = {
  apply(e, kind, data) {
    e.st = e.st || {};
    const cur = e.st[kind];
    if (kind === 'poison' || kind === 'soulmark') {
      const st = cur || (e.st[kind] = { t: 0, stacks: 0, dps: 0 });
      st.stacks = Math.min(5, st.stacks + 1); st.t = data.t; st.dps = data.dps; return;
    }
    if (!cur || (data.t || 0) > cur.t) e.st[kind] = Object.assign({ t: 0 }, data);
  },
  spdMul(e) {
    if (!e.st) return 1;
    let m = 1;
    if (e.st.freeze && e.st.freeze.t > 0) m *= 1 - (e.st.freeze.amt || 0.45);
    if (Skills.timeslow > 0) m *= 0.35;
    return m;
  },
  update(dt) {
    const G = Game;
    for (const e of G.enemies) {
      if (e.dead || !e.st) continue;
      for (const k in e.st) {
        const s = e.st[k];
        s.t -= dt; if (s.t <= 0) { delete e.st[k]; continue; }
        if (s.dps) {
          s.acc = (s.acc || 0) + dt;
          if (s.acc >= 0.5) {
            s.acc -= 0.5;
            const mul = k === 'poison' ? (s.stacks || 1) : 1;
            G.dealRaw(e, s.dps * 0.5 * mul, s.color || '#9ae66e', true);
            if (G.particles.length < 380) G.particles.push({ x: e.x + (Math.random() * 10 - 5), y: e.y - 10, vx: 0, vy: -20, life: 0.4, max: 0.4, color: s.color || '#9ae66e', size: 2 });
          }
        }
      }
    }
  },
  draw(ctx, e, cam) {
    if (!e.st) return;
    const sx = Math.round(e.x - cam.x), sy = Math.round(e.y - cam.y);
    let i = 0;
    for (const k in e.st) {
      const col = { burn: '#ff8a4f', poison: '#9ae66e', bleed: '#ff5d6c', freeze: '#9fe8ff', shadow: '#8f7bff', soulmark: '#6fe8f0' }[k];
      if (!col) continue;
      ctx.fillStyle = col; ctx.fillRect(sx - 6 + i * 4, sy + 2, 3, 2); i++;
    }
    if (e.st.freeze) { ctx.globalAlpha = 0.22; ctx.fillStyle = '#9fe8ff'; ctx.fillRect(sx - 9, sy - 22, 18, 24); ctx.globalAlpha = 1; }
  },
};

/* ======================= EFEK SENJATA ======================= */
const WeaponFx = {
  spec() {
    const w = Game.player.equip.weapon;
    return w ? ITEMS[w.tid] : null;
  },
  snd() { const s = this.spec(); return (s && s.snd) || { w: 'square', f: 230, s: 0.5, n: 0.32, ring: 900, d: 0.2 }; },
  onHit(e, dmg, crit) {
    const s = this.spec(); if (!s || !s.fx) return;
    const P = Game.player, G = Game;
    switch (s.fx) {
      case 'burn': Status.apply(e, 'burn', { t: 3, dps: Math.max(6, dmg * 0.18), color: '#ff8a4f' }); break;
      case 'poison': Status.apply(e, 'poison', { t: 4, dps: Math.max(4, dmg * 0.1), color: '#9ae66e' }); break;
      case 'bleed': Status.apply(e, 'bleed', { t: 4, dps: dmg * 0.08, color: '#ff5d6c' }); break;
      case 'freeze': Status.apply(e, 'freeze', { t: 2.5, amt: 0.45 }); Fx.ring(e.x, e.y - 8, 20, '#9fe8ff'); break;
      case 'chain': {
        let n = 0;
        for (const o of G.enemies) {
          if (o === e || o.dead || n >= 3) continue;
          if (Math.hypot(o.x - e.x, o.y - e.y) < 90) { Fx.bolt(e.x, e.y - 8, o.x, o.y - 8, '#ffe066'); G.dealRaw(o, dmg * 0.45, '#ffe066', true); n++; }
        }
        break;
      }
      case 'shadow': {
        const dirv = [[0, 1], [0, -1], [-1, 0], [1, 0]][P.dir];
        const behind = (e.x - P.x) * dirv[0] + (e.y - P.y) * dirv[1] > 0 && e.dir === P.dir;
        if (behind) { G.dealRaw(e, dmg * 0.6, '#8f7bff', true); Fx.ring(e.x, e.y - 8, 16, '#8f7bff'); }
        Status.apply(e, 'shadow', { t: 2 });
        break;
      }
      case 'wind': {
        const dirv = [[0, 1], [0, -1], [-1, 0], [1, 0]][P.dir];
        G.projectiles.push({ x: P.x, y: P.y - 6, vx: dirv[0] * 250, vy: dirv[1] * 250, life: 0.6, dmgMul: 0.5, friendly: true, pierce: 3, hitIds: [], color: '#bff3ff', r: 6 });
        break;
      }
      case 'vampiric': { const h = Math.max(1, Math.round(dmg * 0.1)); P.hp = Math.min(P.stats.hp, P.hp + h); G.floater(P.x, P.y - 34, '+' + h, '#ff7a9c'); break; }
      case 'quake': Fx.shock(e.x, e.y, 48, dmg * 0.35, '#c9a36a'); break;
      case 'holy': {
        const def = ENEMIES[e.type];
        if (/revenant|fiend/.test(def.art)) { G.dealRaw(e, dmg * 0.8, '#ffe9a8', true); Fx.ring(e.x, e.y - 8, 22, '#fff4c8'); }
        break;
      }
      case 'stun': if (Math.random() < 0.25) { e.stun = Math.max(e.stun || 0, 1.2); Fx.ring(e.x, e.y - 8, 18, '#ffffff'); G.floater(e.x, e.y - 30, 'PINGSAN', '#ffffff'); } break;
      case 'sandstorm': Fx.zones.push({ type: 'cloud', x: e.x, y: e.y, r: 44, t: 1.6, max: 1.6, dps: dmg * 0.5, color: '#e0c78a' }); break;
      case 'magma': Fx.zones.push({ type: 'magma', x: e.x, y: e.y, r: 26, t: 3.5, max: 3.5, dps: dmg * 0.55, color: '#ff7a2f' }); break;
      case 'soul': break;   // ditangani di killEnemy
      case 'void': Fx.zones.push({ type: 'vortex', x: e.x, y: e.y, r: 54, t: 1.2, max: 1.2, dps: dmg * 0.4, pull: 120, color: '#b07bff' }); break;
      case 'meteor': if (crit) Fx.meteor(e.x, e.y, dmg * 0.9, '#ff8a4f', 1); break;
      case 'flower': {
        Status.apply(e, 'burn', { t: 4, dps: dmg * 0.22, color: '#ff9ec4' });
        const h = Math.max(2, Math.round(dmg * 0.08)); P.hp = Math.min(P.stats.hp, P.hp + h);
        for (let i = 0; i < 6; i++) {
          const a = Math.random() * 6.28;
          G.particles.push({ x: e.x, y: e.y - 8, vx: Math.cos(a) * 70, vy: Math.sin(a) * 70 - 20, life: 0.6, max: 0.6, color: i % 2 ? '#ff9ec4' : '#ffd9a8', size: 2 });
        }
        if (crit) Fx.shock(e.x, e.y, 70, dmg * 0.7, '#ff9ec4');
        break;
      }
    }
  },
  onKill(e) {
    const s = this.spec(); if (!s) return;
    if (s.fx === 'soul') {
      const P = Game.player;
      P.soulStacks = Math.min(10, (P.soulStacks || 0) + 1);
      P.base.atkSoul = P.soulStacks * 6;
      Game.floater(P.x, P.y - 40, 'JIWA +' + (P.soulStacks * 6) + ' ATK', '#6fe8f0');
      Game.recalc();
    }
  },
};

/* ======================= ZONA & EFEK VISUAL ======================= */
const Fx = {
  zones: [], bolts: [], rings: [],
  ring(x, y, r, color) { this.rings.push({ x, y, r0: 4, r1: r, t: 0.35, max: 0.35, color }); },
  bolt(x1, y1, x2, y2, color) { this.bolts.push({ x1, y1, x2, y2, t: 0.18, max: 0.18, color }); },
  shock(x, y, r, dmg, color) {
    this.ring(x, y, r, color);
    for (const o of Game.enemies) if (!o.dead && Math.hypot(o.x - x, o.y - y) < r) Game.dealRaw(o, dmg, color, true);
  },
  meteor(x, y, dmg, color, count) {
    for (let i = 0; i < (count || 1); i++) {
      const a = Math.random() * 6.28, d = i === 0 ? 0 : 20 + Math.random() * 60;
      this.zones.push({ type: 'meteor', x: x + Math.cos(a) * d, y: y + Math.sin(a) * d, r: 30, t: 0.6 + i * 0.09, max: 0.6, dmg, color, fall: true });
    }
  },
  clear() { this.zones.length = 0; this.bolts.length = 0; this.rings.length = 0; },
  update(dt) {
    const G = Game, P = G.player;
    for (let i = this.zones.length - 1; i >= 0; i--) {
      const z = this.zones[i];
      z.t -= dt;
      if (z.follow) { z.x = P.x; z.y = P.y; }
      if (z.type === 'vortex' || z.type === 'blackhole') {
        for (const e of G.enemies) {
          if (e.dead) continue;
          const dx = z.x - e.x, dy = z.y - e.y, d = Math.hypot(dx, dy) || 1;
          if (d < z.r) { e.x += dx / d * (z.pull || 90) * dt; e.y += dy / d * (z.pull || 90) * dt; e.aggro = true; }
        }
      }
      if (z.dps) {
        z.acc = (z.acc || 0) + dt;
        if (z.acc >= 0.35) {
          z.acc -= 0.35;
          for (const e of G.enemies) if (!e.dead && Math.hypot(e.x - z.x, e.y - 8 - z.y) < z.r) G.dealRaw(e, z.dps * 0.35, z.color, true);
        }
      }
      if (z.hostile && z.hdps) {
        z.hacc = (z.hacc || 0) + dt;
        if (z.hacc >= 0.7) { z.hacc -= 0.7; if (Math.hypot(P.x - z.x, P.y - z.y) < z.r) G.hurtPlayer(z.hdps * 0.7); }
      }
      if (z.type === 'meteor' && z.t <= 0 && !z.done) {
        z.done = true; G.shake = Math.max(G.shake, 4); Audio2.sfx('hit');
        this.shock(z.x, z.y, z.r, z.dmg, z.color);
        G.burst(z.x, z.y, 14, z.color, 110);
      }
      if (z.type === 'pillar' && z.t <= 0 && !z.done) {
        z.done = true; this.shock(z.x, z.y, z.r, z.dmg, z.color); G.burst(z.x, z.y, 10, z.color, 70);
      }
      if (z.type === 'petal') {
        // kelopak pemandu: cari musuh terdekat lalu kejar
        if (!z.target || z.target.dead) {
          let best = null, bd = 260;
          for (const e of G.enemies) { if (e.dead) continue; const d = Math.hypot(e.x - z.x, e.y - z.y); if (d < bd) { bd = d; best = e; } }
          z.target = best;
        }
        if (z.target) {
          const dx = z.target.x - z.x, dy = z.target.y - 8 - z.y, d = Math.hypot(dx, dy) || 1;
          z.vx += dx / d * 900 * dt; z.vy += dy / d * 900 * dt;
          const sp = Math.hypot(z.vx, z.vy); if (sp > 260) { z.vx = z.vx / sp * 260; z.vy = z.vy / sp * 260; }
          if (d < 12) { G.dealRaw(z.target, z.dmg, z.color, true); WeaponFx.onHit(z.target, z.dmg, false); G.burst(z.x, z.y, 6, z.color, 60); z.t = 0; }
        }
        z.x += z.vx * dt; z.y += z.vy * dt;
        if (G.particles.length < 400) G.particles.push({ x: z.x, y: z.y, vx: 0, vy: 0, life: 0.3, max: 0.3, color: z.color, size: 2 });
      }
      if (z.type === 'clone') {
        const a = z.phase + G.time * 2.2;
        z.x = P.x + Math.cos(a) * 26; z.y = P.y + Math.sin(a) * 18;
        z.acc2 = (z.acc2 || 0) + dt;
        if (z.acc2 > 0.5) {
          z.acc2 = 0;
          let best = null, bd = 60;
          for (const e of G.enemies) { if (e.dead) continue; const d = Math.hypot(e.x - z.x, e.y - z.y); if (d < bd) { bd = d; best = e; } }
          if (best) { G.dealRaw(best, P.stats.atk * 0.7, z.color, true); this.bolt(z.x, z.y - 8, best.x, best.y - 8, z.color); }
        }
      }
      if (z.t <= 0) this.zones.splice(i, 1);
    }
    for (let i = this.bolts.length - 1; i >= 0; i--) { this.bolts[i].t -= dt; if (this.bolts[i].t <= 0) this.bolts.splice(i, 1); }
    for (let i = this.rings.length - 1; i >= 0; i--) { this.rings[i].t -= dt; if (this.rings[i].t <= 0) this.rings.splice(i, 1); }
  },
  /* lapisan bawah (di atas tanah, bawah entitas) */
  drawGround(ctx, cam) {
    for (const z of this.zones) {
      const sx = Math.round(z.x - cam.x), sy = Math.round(z.y - cam.y);
      if (z.type === 'magma' || z.type === 'cloud') {
        const a = Math.min(0.55, z.t / z.max * 0.55);
        ctx.globalAlpha = a; ctx.fillStyle = z.color;
        for (let i = 0; i < 8; i++) {
          const ang = i / 8 * 6.28 + Game.time * (z.type === 'cloud' ? 0.8 : 0.3);
          const rr = z.r * (0.4 + (i % 3) * 0.2);
          ctx.beginPath(); ctx.arc(sx + Math.cos(ang) * z.r * 0.3, sy + Math.sin(ang) * z.r * 0.2, rr * 0.5, 0, 6.28); ctx.fill();
        }
        ctx.globalAlpha = 1;
      }
      if (z.type === 'vortex' || z.type === 'blackhole') {
        ctx.save(); ctx.translate(sx, sy);
        for (let i = 0; i < 4; i++) {
          const rr = z.r * (1 - i * 0.2) * (0.6 + 0.4 * Math.sin(Game.time * 6 + i));
          ctx.globalAlpha = 0.45 - i * 0.08; ctx.strokeStyle = z.type === 'blackhole' ? '#7a5bd8' : z.color; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.ellipse(0, 0, rr, rr * 0.55, Game.time * 2 + i, 0, 6.28); ctx.stroke();
        }
        if (z.type === 'blackhole') { ctx.globalAlpha = 0.85; ctx.fillStyle = '#0a0614'; ctx.beginPath(); ctx.ellipse(0, 0, z.r * 0.25, z.r * 0.16, 0, 0, 6.28); ctx.fill(); }
        ctx.restore(); ctx.globalAlpha = 1;
      }
      if (z.type === 'meteor' && !z.done) {
        const p = 1 - z.t / z.max;
        ctx.globalAlpha = 0.5; ctx.strokeStyle = z.color; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(sx, sy, z.r * (0.4 + p * 0.6), z.r * 0.4 * (0.4 + p * 0.6), 0, 0, 6.28); ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
  },
  /* lapisan atas (di atas entitas) */
  drawOver(ctx, cam) {
    for (const r of this.rings) {
      const p = 1 - r.t / r.max, rr = r.r0 + (r.r1 - r.r0) * p;
      ctx.globalAlpha = 0.8 * (1 - p); ctx.strokeStyle = r.color; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(Math.round(r.x - cam.x), Math.round(r.y - cam.y), rr, rr * 0.6, 0, 0, 6.28); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    for (const b of this.bolts) {
      ctx.globalAlpha = b.t / b.max; ctx.strokeStyle = b.color; ctx.lineWidth = 2;
      ctx.beginPath();
      let x = b.x1 - cam.x, y = b.y1 - cam.y;
      ctx.moveTo(x, y);
      const n = 5, ex = b.x2 - cam.x, ey = b.y2 - cam.y;
      for (let i = 1; i <= n; i++) {
        const t = i / n;
        ctx.lineTo(x + (ex - x) * t + (i < n ? (Math.random() - 0.5) * 10 : 0), y + (ey - y) * t + (i < n ? (Math.random() - 0.5) * 10 : 0));
      }
      ctx.stroke(); ctx.globalAlpha = 1;
    }
    for (const z of this.zones) {
      const sx = Math.round(z.x - cam.x), sy = Math.round(z.y - cam.y);
      if (z.type === 'meteor' && !z.done) {
        const p = 1 - z.t / z.max;
        ctx.fillStyle = z.color; ctx.globalAlpha = 0.9;
        const my = sy - 120 * (1 - p);
        ctx.fillRect(sx - 4, my - 6, 8, 12);
        ctx.globalAlpha = 0.4; ctx.fillRect(sx - 2, my - 22, 4, 16); ctx.globalAlpha = 1;
      }
      if (z.type === 'pillar' && !z.done) {
        ctx.globalAlpha = 0.35 + 0.35 * Math.sin(Game.time * 18); ctx.fillStyle = z.color;
        ctx.fillRect(sx - 7, sy - 90, 14, 90); ctx.globalAlpha = 1;
      }
      if (z.type === 'beam') {
        ctx.globalAlpha = Math.max(0, z.t / z.max); ctx.strokeStyle = z.color; ctx.lineWidth = z.w || 8;
        ctx.beginPath(); ctx.moveTo(z.x - cam.x, z.y - cam.y); ctx.lineTo(z.x2 - cam.x, z.y2 - cam.y); ctx.stroke();
        ctx.lineWidth = 2; ctx.strokeStyle = '#fff'; ctx.stroke(); ctx.globalAlpha = 1;
      }
      if (z.type === 'breath') {
        ctx.globalAlpha = 0.45 * Math.max(0, z.t / z.max);
        const a0 = z.ang - 0.4, a1 = z.ang + 0.4;
        const gr = ctx.createRadialGradient(sx, sy, 4, sx, sy, z.r);
        gr.addColorStop(0, z.color); gr.addColorStop(1, 'rgba(255,120,40,0)');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.arc(sx, sy, z.r, a0, a1); ctx.fill(); ctx.globalAlpha = 1;
      }
      if (z.type === 'blades') {
        for (let i = 0; i < 4; i++) {
          const a = Game.time * 9 + i * 1.57;
          ctx.globalAlpha = 0.9; ctx.fillStyle = z.color;
          ctx.fillRect(Math.round(sx + Math.cos(a) * 34) - 2, Math.round(sy - 8 + Math.sin(a) * 22) - 5, 4, 11);
        }
        ctx.globalAlpha = 1;
      }
      if (z.type === 'clone') {
        ctx.globalAlpha = 0.55;
        const img = Art.humanoid({ key: 'pc' + Game.cls.id, skin: '#b9a8ff', hair: '#2f2440', tunic: z.color, pants: '#2b2540', weapon: true, weaponColor: '#dfe6f2' }, Game.player.dir, Game.player.frame);
        ctx.drawImage(img, Math.round(z.x - 8 - cam.x), Math.round(z.y - 18 - cam.y));
        ctx.globalAlpha = 1;
      }
      if (z.type === 'petal') {
        ctx.fillStyle = z.color; ctx.fillRect(sx - 2, sy - 2, 4, 4);
        ctx.fillStyle = '#fff6fb'; ctx.fillRect(sx - 1, sy - 1, 2, 2);
      }
      if (z.type === 'shieldfx') {
        ctx.globalAlpha = 0.3 + 0.15 * Math.sin(Game.time * 6); ctx.strokeStyle = z.color; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(sx, sy - 8, 20, 24, 0, 0, 6.28); ctx.stroke(); ctx.globalAlpha = 1;
      }
    }
  },
};

/* ======================= MESIN SKILL ======================= */
const Skills = {
  unlocked: [], slots: [null, null, null], cd: [0, 0, 0], timeslow: 0,
  buffs: { shield: 0, shieldAmt: 0, haste: 0 },
  reset(clsId) {
    this.unlocked = (CLASS_SKILLS[clsId] || CLASS_SKILLS.guardian).slice();
    this.slots = this.unlocked.slice(0, 3);
    this.cd = [0, 0, 0]; this.timeslow = 0;
    this.buffs = { shield: 0, shieldAmt: 0, haste: 0 };
  },
  unlock(id) {
    if (!SKILLS[id] || this.unlocked.includes(id)) return false;
    this.unlocked.push(id);
    const empty = this.slots.indexOf(null);
    if (empty >= 0) this.slots[empty] = id;
    return true;
  },
  equip(slot, id) { if (SKILLS[id] && this.unlocked.includes(id)) { const o = this.slots.indexOf(id); if (o >= 0) this.slots[o] = this.slots[slot]; this.slots[slot] = id; this.cd[slot] = 0; } },
  cdMul() { const a = Game.player.equip.armor; return a && ITEMS[a.tid].id === 'ar_star2' ? 0.85 : 1; },
  hasteMul() { return this.buffs.haste > 0 ? 1.6 : 1; },
  spdMul() { return this.buffs.haste > 0 ? 1.6 : 1; },
  dmgTakenMul() { return this.buffs.shield > 0 ? 1 - this.buffs.shieldAmt : 1; },
  update(dt) {
    for (let i = 0; i < 3; i++) this.cd[i] = Math.max(0, this.cd[i] - dt);
    for (const k of ['shield', 'haste']) if (this.buffs[k] > 0) this.buffs[k] -= dt;
    if (this.timeslow > 0) this.timeslow -= dt;
  },
  use(slot) {
    const P = Game.player, id = this.slots[slot];
    if (!id) { Game.toast('Slot skill ' + (slot + 1) + ' masih kosong (tekan K).', '#8b93a5'); return; }
    if (this.cd[slot] > 0) { Game.toast(SKILLS[id].name + ' siap dalam ' + this.cd[slot].toFixed(1) + 's', '#8b93a5'); return; }
    const sk = SKILLS[id];
    this.cd[slot] = sk.cd * this.cdMul();
    this.cast(sk);
    UI.syncHUD();
  },
  cast(sk) {
    const G = Game, P = G.player;
    const dirv = [[0, 1], [0, -1], [-1, 0], [1, 0]][P.dir];
    const ang = Math.atan2(dirv[1], dirv[0]);
    const atk = P.stats.atk;
    const big = ['meteor', 'blackhole', 'timeslow', 'beam', 'pillars'].includes(sk.kind);
    Audio2.skillCast(sk.color, big);
    G.floater(P.x, P.y - 44, sk.name, sk.color);
    switch (sk.kind) {
      case 'nova':
        G.shake = 5; Fx.ring(P.x, P.y - 6, sk.radius, sk.color); Fx.ring(P.x, P.y - 6, sk.radius * 0.6, '#ffffff');
        for (const e of G.enemies) if (!e.dead && Math.hypot(e.x - P.x, e.y - 8 - (P.y - 8)) < sk.radius) {
          G.damageEnemy(e, sk.dmg);
          if (sk.stun) e.stun = Math.max(e.stun || 0, sk.stun);
          if (sk.freeze) Status.apply(e, 'freeze', { t: sk.freeze, amt: 0.6 });
        }
        for (let i = 0; i < 30; i++) { const a = i / 30 * 6.28; G.particles.push({ x: P.x + Math.cos(a) * 10, y: P.y - 6 + Math.sin(a) * 7, vx: Math.cos(a) * 170, vy: Math.sin(a) * 110, life: 0.45, max: 0.45, color: i % 3 ? sk.color : '#fff', size: 2 }); }
        break;
      case 'quake': {
        G.shake = 7;
        for (let k = 0; k < 3; k++) setTimeout(() => {
          if (G.state !== 'play') return;
          Fx.shock(P.x, P.y, sk.radius * (0.5 + k * 0.28), atk * sk.dmg / 3, sk.color);
        }, k * 160);
        break;
      }
      case 'shield':
        this.buffs.shield = sk.dur; this.buffs.shieldAmt = sk.id === 'sk_bulwark' ? 0.65 : 0.45;
        Fx.zones.push({ type: 'shieldfx', x: P.x, y: P.y, t: sk.dur, max: sk.dur, color: sk.color, follow: true });
        G.toast('Perisai aktif ' + sk.dur + 's', sk.color);
        break;
      case 'haste':
        this.buffs.haste = sk.dur;
        Fx.zones.push({ type: 'shieldfx', x: P.x, y: P.y, t: sk.dur, max: sk.dur, color: sk.color, follow: true });
        break;
      case 'dash':
        P.dash = { vx: dirv[0] * 340, vy: dirv[1] * 340, t: 0.2 };
        for (let k = 0; k < (sk.hits || 3); k++) setTimeout(() => { if (G.state === 'play') { G.meleeHit(dirv, 28, sk.dmg); Fx.ring(P.x, P.y - 6, 20, sk.color); } }, k * 90);
        break;
      case 'fan':
        for (let k = 0; k < sk.count; k++) {
          const a = ang + (k - (sk.count - 1) / 2) * 0.22;
          G.projectiles.push({ x: P.x, y: P.y - 6, vx: Math.cos(a) * 230, vy: Math.sin(a) * 230, life: 1.2, dmgMul: sk.dmg, friendly: true, pierce: 4, hitIds: [], color: sk.color, r: 7 });
        }
        break;
      case 'beam': {
        const len = 260;
        const x2 = P.x + dirv[0] * len, y2 = P.y - 6 + dirv[1] * len;
        Fx.zones.push({ type: 'beam', x: P.x, y: P.y - 6, x2, y2, t: 0.3, max: 0.3, color: sk.color, w: sk.dmg > 4 ? 16 : 8 });
        G.shake = sk.dmg > 4 ? 8 : 4;
        for (const e of G.enemies) {
          if (e.dead) continue;
          const t = ((e.x - P.x) * dirv[0] + (e.y - 8 - (P.y - 6)) * dirv[1]);
          if (t < 0 || t > len) continue;
          const px = P.x + dirv[0] * t, py = P.y - 6 + dirv[1] * t;
          if (Math.hypot(e.x - px, e.y - 8 - py) < (sk.dmg > 4 ? 26 : 18) + e.def_r) G.damageEnemy(e, sk.dmg);
        }
        break;
      }
      case 'heal': {
        const h = Math.round(P.stats.hp * sk.heal);
        P.hp = Math.min(P.stats.hp, P.hp + h);
        G.floater(P.x, P.y - 30, '+' + h, '#8fffc0', true);
        for (let i = 0; i < 24; i++) { const a = Math.random() * 6.28; G.particles.push({ x: P.x + Math.cos(a) * 14, y: P.y + Math.sin(a) * 10, vx: 0, vy: -50 - Math.random() * 40, life: 0.8, max: 0.8, color: i % 2 ? '#8fffc0' : '#e8fff4', size: 2 }); }
        break;
      }
      case 'meteor': {
        let tx = P.x + dirv[0] * 90, ty = P.y + dirv[1] * 90;
        let best = null, bd = 240;
        for (const e of G.enemies) { if (e.dead) continue; const d = Math.hypot(e.x - P.x, e.y - P.y); if (d < bd) { bd = d; best = e; } }
        if (best) { tx = best.x; ty = best.y; }
        Fx.meteor(tx, ty, atk * sk.dmg / 2, sk.color, sk.count);
        break;
      }
      case 'chain': {
        let cur = null, bd = 220;
        for (const e of G.enemies) { if (e.dead) continue; const d = Math.hypot(e.x - P.x, e.y - P.y); if (d < bd) { bd = d; cur = e; } }
        if (!cur) { G.toast('Tidak ada sasaran.', '#8b93a5'); break; }
        const hit = [];
        let from = { x: P.x, y: P.y - 8 };
        for (let j = 0; j < (sk.jumps || 6) && cur; j++) {
          Fx.bolt(from.x, from.y, cur.x, cur.y - 8, sk.color);
          G.damageEnemy(cur, sk.dmg);
          hit.push(cur); from = { x: cur.x, y: cur.y - 8 };
          let nx = null, nd = 120;
          for (const e of G.enemies) { if (e.dead || hit.includes(e)) continue; const d = Math.hypot(e.x - cur.x, e.y - cur.y); if (d < nd) { nd = d; nx = e; } }
          cur = nx;
        }
        break;
      }
      case 'vortex':
      case 'blackhole':
        Fx.zones.push({ type: sk.kind, x: P.x + dirv[0] * 50, y: P.y + dirv[1] * 40, r: sk.kind === 'blackhole' ? 110 : 76, t: sk.dur, max: sk.dur, dps: atk * sk.dmg, pull: sk.kind === 'blackhole' ? 190 : 120, color: sk.color });
        G.shake = sk.kind === 'blackhole' ? 8 : 4;
        break;
      case 'bladestorm':
        Fx.zones.push({ type: 'blades', x: P.x, y: P.y, r: 46, t: sk.dur, max: sk.dur, dps: atk * sk.dmg * 2, color: sk.color, follow: true });
        break;
      case 'cloud':
        Fx.zones.push({ type: 'cloud', x: P.x + dirv[0] * 60, y: P.y + dirv[1] * 46, r: 68, t: sk.dur, max: sk.dur, dps: atk * sk.dmg, color: sk.color });
        break;
      case 'pillars':
        for (let k = 0; k < sk.count; k++) {
          const a = k / sk.count * 6.28, d = 40 + Math.random() * 70;
          Fx.zones.push({ type: 'pillar', x: P.x + Math.cos(a) * d, y: P.y + Math.sin(a) * d * 0.7, r: 30, t: 0.45 + k * 0.08, max: 0.45, dmg: atk * sk.dmg / 2, color: sk.color });
        }
        break;
      case 'clones':
        for (let k = 0; k < 2; k++) Fx.zones.push({ type: 'clone', x: P.x, y: P.y, t: sk.dur, max: sk.dur, phase: k * Math.PI, color: sk.color });
        break;
      case 'breath': {
        Fx.zones.push({ type: 'breath', x: P.x, y: P.y - 6, r: 110, ang, t: sk.dur, max: sk.dur, color: sk.color });
        const step = sk.dur / 4;
        for (let k = 0; k < 4; k++) setTimeout(() => {
          if (G.state !== 'play') return;
          for (const e of G.enemies) {
            if (e.dead) continue;
            const dx = e.x - P.x, dy = e.y - 8 - (P.y - 6), d = Math.hypot(dx, dy);
            if (d > 110) continue;
            if (Math.abs(Math.atan2(Math.sin(Math.atan2(dy, dx) - ang), Math.cos(Math.atan2(dy, dx) - ang))) < 0.45) {
              G.damageEnemy(e, sk.dmg / 2); Status.apply(e, 'burn', { t: 3, dps: atk * 0.12, color: '#ff8a4f' });
            }
          }
        }, k * step * 1000);
        break;
      }
      case 'timeslow':
        this.timeslow = sk.dur; G.toast('Waktu melambat ' + sk.dur + 's', sk.color);
        for (let i = 0; i < 36; i++) { const a = Math.random() * 6.28, d = 20 + Math.random() * 90; G.particles.push({ x: P.x + Math.cos(a) * d, y: P.y + Math.sin(a) * d * 0.7, vx: 0, vy: -10, life: 1, max: 1, color: sk.color, size: 2 }); }
        break;
      case 'petals':
        for (let k = 0; k < sk.count; k++) {
          const a = k / sk.count * 6.28;
          Fx.zones.push({ type: 'petal', x: P.x + Math.cos(a) * 12, y: P.y - 6 + Math.sin(a) * 10, vx: Math.cos(a) * 140, vy: Math.sin(a) * 140, t: 2.6, max: 2.6, dmg: atk * sk.dmg, color: k % 2 ? sk.color : '#ffd9a8' });
        }
        break;
      case 'drain': {
        let total = 0;
        for (const e of G.enemies) if (!e.dead && Math.hypot(e.x - P.x, e.y - P.y) < 96) {
          const before = e.hp; G.damageEnemy(e, sk.dmg); total += Math.max(0, before - e.hp);
          Fx.bolt(e.x, e.y - 8, P.x, P.y - 8, sk.color);
        }
        const h = Math.round(total * 0.35);
        if (h > 0) { P.hp = Math.min(P.stats.hp, P.hp + h); G.floater(P.x, P.y - 34, '+' + h, sk.color); }
        break;
      }
    }
  },
};

/* ======================= AI POLA BOS ======================= */
const BossAI = {
  cast(e) {
    const G = Game, P = G.player, def = ENEMIES[e.type];
    const pat = def.pattern || 'ring';
    const col = def.color || '#ff7a45';
    const shoot = (a, sp, dmg) => G.projectiles.push({ x: e.x, y: e.y - 10, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 2.6, friendly: false, dmg, color: col, r: 5 });
    const aim = Math.atan2(P.y - 8 - (e.y - 10), P.x - e.x);
    G.shake = 4; Audio2.sfx('boss');
    switch (pat) {
      case 'slam':
        Fx.ring(e.x, e.y, 90, col);
        setTimeout(() => { if (G.state === 'play' && Math.hypot(P.x - e.x, P.y - e.y) < 90) G.hurtPlayer(e.atk * 1.4, e); }, 400);
        break;
      case 'charge': {
        const d = Math.hypot(P.x - e.x, P.y - e.y) || 1;
        e.knock = { x: (P.x - e.x) / d * 240, y: (P.y - e.y) / d * 240 };
        Fx.ring(e.x, e.y, 40, col);
        break;
      }
      case 'ring': for (let k = 0; k < 12; k++) shoot(k / 12 * 6.28, 110, e.atk * 0.7); break;
      case 'spiral': for (let k = 0; k < 10; k++) setTimeout(() => { if (G.state === 'play') shoot(k * 0.7 + G.time, 120, e.atk * 0.6); }, k * 90); break;
      case 'summon': {
        const pool = (BIOMES[def.biome] && BIOMES[def.biome].enemies) || [];
        for (let k = 0; k < 3 && pool.length; k++) {
          const t = pool[Math.floor(Math.random() * Math.min(8, pool.length))];
          const m = G.spawnEnemy(t, Math.floor(e.x / 16) + (k - 1) * 2, Math.floor(e.y / 16) + 2);
          m.aggro = true;
        }
        G.floater(e.x, e.y - 40, 'MEMANGGIL!', col);
        break;
      }
      case 'sweep': for (let k = -3; k <= 3; k++) shoot(aim + k * 0.16, 150, e.atk * 0.55); break;
      case 'meteor': Fx.meteor(P.x, P.y, e.atk * 1.2, col, 5); break;
      case 'blink': {
        const a = Math.random() * 6.28;
        e.x = P.x + Math.cos(a) * 40; e.y = P.y + Math.sin(a) * 30;
        Fx.ring(e.x, e.y, 34, col);
        for (let k = 0; k < 6; k++) shoot(a + k, 130, e.atk * 0.6);
        break;
      }
      case 'cloud': Fx.zones.push({ type: 'cloud', x: P.x, y: P.y, r: 70, t: 4, max: 4, color: col, hostile: true, hdps: e.atk * 0.5 }); break;
      case 'shock':
        Fx.bolt(e.x, e.y - 10, P.x, P.y - 8, col);
        setTimeout(() => { if (G.state === 'play') G.hurtPlayer(e.atk * 1.1, e); }, 250);
        break;
    }
  },
};

/* ======================= SARANG BOS PER BIOMA ======================= */
const Lairs = {
  site: null, active: null,
  reset() { this.site = null; this.active = null; },
  siteFor(b, P) {
    // titik sarang deterministik per wilayah bioma (grid 6 petak)
    const gx = Math.floor(P.x / (World.CHPX * 3)), gy = Math.floor(P.y / (World.CHPX * 3));
    const h1 = hash32(gx, gy, b.id.length), h2 = hash32(gy, gx, b.id.charCodeAt(0));
    const okSpot = (x, y) => World.walkable(x, y, 8)
      && World.biomeAtPx(x, y).id === b.id
      && !World.inTown(Math.floor(x / 16), Math.floor(y / 16), 26);
    const a = h1 * 6.283, d = 620 + h2 * 340;
    let x = P.x + Math.cos(a) * d, y = P.y + Math.sin(a) * d;
    for (let k = 0; k < 48; k++) {
      if (okSpot(x, y)) break;
      const aa = (h1 + k * 0.37) * 6.283, dd = 560 + ((k * 61) % 420);
      x = P.x + Math.cos(aa) * dd; y = P.y + Math.sin(aa) * dd;
    }
    return { biome: b.id, x, y, spawned: false };
  },
  update(dt) {
    const G = Game, P = G.player;
    if (Clash.active) return;
    const b = World.biomeAtPx(P.x, P.y);
    if (!BOSSES[b.id]) return;
    if (G.bossDefeated[b.id]) { this.site = null; return; }
    if (!this.site || this.site.biome !== b.id) this.site = this.siteFor(b, P);
    const s = this.site;
    const d = Math.hypot(P.x - s.x, P.y - s.y);
    if (!s.spawned && d < 190) {
      s.spawned = true;
      const bid = BOSSES[b.id].id;
      if (!G.enemies.some(e => e.type === bid && !e.dead)) {
        const e = G.spawnEnemy(bid, Math.floor(s.x / 16), Math.floor(s.y / 16));
        e.lair = true; this.active = e;
        G.toast('SARANG BOS: ' + ENEMIES[bid].name + ' terbangun!', '#ff7a45');
        Audio2.sfx('boss'); Audio2.setIntensity(2); G.shake = 8;
        Fx.ring(e.x, e.y, 140, BOSSES[b.id].color);
      }
    }
    if (s.spawned && d > 620) { s.spawned = false; Audio2.setIntensity(0); }
  },
  draw(ctx, cam) {
    const s = this.site; if (!s || Clash.active) return;
    const sx = Math.round(s.x - cam.x), sy = Math.round(s.y - cam.y);
    // batu sarang + gerbang
    if (sx > -80 && sy > -80 && sx < G.VW + 80 && sy < G.VH + 80) {
      const pulse = 0.5 + 0.35 * Math.sin(Game.time * 3);
      ctx.globalAlpha = 0.5; ctx.strokeStyle = BOSSES[s.biome].color; ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.ellipse(sx, sy, 60 - i * 16, (60 - i * 16) * 0.55, 0, 0, 6.28); ctx.stroke(); }
      ctx.globalAlpha = pulse;
      for (let i = 0; i < 8; i++) {
        const a = i / 8 * 6.28 + Game.time * 0.4;
        ctx.fillStyle = BOSSES[s.biome].color;
        ctx.fillRect(Math.round(sx + Math.cos(a) * 58) - 2, Math.round(sy + Math.sin(a) * 32) - 6, 4, 12);
      }
      ctx.globalAlpha = 1;
      if (!s.spawned) Game.label('SARANG BOS', sx, sy - 44, '#ff9a6b', 6, { bold: true, bg: 'rgba(15,12,22,0.8)' });
    }
  },
  // penanda arah di tepi layar
  marker(h, cam) {
    const s = this.site; if (!s || Clash.active) return null;
    return { x: s.x, y: s.y, color: BOSSES[s.biome].color, label: BOSSES[s.biome].short };
  },
  onBossKill(e) {
    const def = ENEMIES[e.type];
    if (!def.biome || !BOSSES[def.biome] || BOSSES[def.biome].id !== e.type) return;
    const G = Game;
    G.bossDefeated[def.biome] = true;
    const r = def.reward || {};
    if (r.weapon) { Inv.add(r.weapon); G.toast('Rampasan bos: ' + ITEMS[r.weapon].name, '#ffd24d'); }
    if (r.armor) { Inv.add(r.armor); G.toast('Rampasan bos: ' + ITEMS[r.armor].name, '#ffd24d'); }
    if (r.skill && Skills.unlock(r.skill)) { G.toast('SKILL BARU: ' + SKILLS[r.skill].name + ' (atur di menu K)', '#c07bff'); Audio2.sfx('unlock'); }
    if (r.gold) { G.player.gold += r.gold; G.toast('+' + fmt(r.gold) + ' gold dari harta bos', '#ffd24d'); }
    Inv.add('m_bosscore');
    Audio2.sfx('unlock'); Audio2.setIntensity(0);
    if (this.site && this.site.biome === def.biome) this.site = null;
  },
};

/* ======================= PEDESAAN DI SETIAP BIOMA ======================= */
const VILLAGE_NAMES = ['Tepi', 'Lembah', 'Batu', 'Gapura', 'Selasar', 'Muara', 'Pelita', 'Randu', 'Kembang', 'Sabit'];
const VILLAGER_ROLES = [
  { role: 'Kepala Dusun', tint: '#e9d5a1', lines: ['"Dusun kami kecil, tapi pintunya selalu terbuka."', '"Bos di sarang sana membuat ternak kami hilang."'] },
  { role: 'Pedagang Dusun', tint: '#9ae6b4', panel: 'shop', lines: ['"Ramuan segar, harga dusun."'] },
  { role: 'Pandai Besi Dusun', tint: '#d98c4a', panel: 'craft', lines: ['"Bawa Inti Bos, kutempa jadi legenda."'] },
  { role: 'Penjaga', tint: '#7dd3fc', lines: ['"Jangan ke arah sarang tanpa persiapan."'] },
  { role: 'Petani', tint: '#f6a5c0', lines: ['"Panen kami tumbuh aneh sejak kabut datang."'] },
];
const Villages = {
  sites: [], byKey: {},
  dropNpcs(pred) {
    const L = World.NPCS;
    for (let i = L.length - 1; i >= 0; i--) if (pred(L[i])) L.splice(i, 1);
  },
  reset() { this.sites.length = 0; this.byKey = {}; this.dropNpcs(n => n.village); },
  keyFor(P) { return Math.floor(P.x / (World.CHPX * 4)) + ':' + Math.floor(P.y / (World.CHPX * 4)); },
  update(dt) {
    const G = Game, P = G.player;
    if (Clash.active) return;
    const key = this.keyFor(P);
    if (!this.byKey[key]) this.byKey[key] = this.build(key, P);
    // buang desa jauh agar hemat
    if (this.sites.length > 6) {
      const far = this.sites.shift();
      this.dropNpcs(n => n.vkey === far.key);
      delete this.byKey[far.key];
      // bersihkan naskah penduduk dusun lama agar memori tidak terus menumpuk
      const pre = 'vil_' + far.key.replace(':', '_') + '_';
      for (const id in NPC_LINES) if (id.indexOf(pre) === 0) delete NPC_LINES[id];
    }
  },
  build(key, P) {
    const gx = Math.floor(P.x / (World.CHPX * 4)), gy = Math.floor(P.y / (World.CHPX * 4));
    const h = hash32(gx * 7 + 13, gy * 11 + 5, 99);
    const a = h * 6.283, d = 240 + hash32(gy, gx, 3) * 320;
    let x = P.x + Math.cos(a) * d, y = P.y + Math.sin(a) * d;
    for (let k = 0; k < 30; k++) {
      if (World.walkable(x, y, 10) && !World.inTown(Math.floor(x / 16), Math.floor(y / 16), 24)) break;
      const aa = (h + k * 0.41) * 6.283, dd = 220 + ((k * 41) % 300);
      x = P.x + Math.cos(aa) * dd; y = P.y + Math.sin(aa) * dd;
    }
    const b = World.biomeAtPx(x, y);
    const name = 'Dusun ' + VILLAGE_NAMES[Math.floor(h * VILLAGE_NAMES.length) % VILLAGE_NAMES.length] + ' ' + b.name;
    const huts = [];
    const nHut = 4 + Math.floor(hash32(gx, gy, 7) * 3);
    for (let i = 0; i < nHut; i++) {
      const ang = i / nHut * 6.28 + h * 3, rr = 46 + (i % 2) * 26;
      huts.push({ x: x + Math.cos(ang) * rr, y: y + Math.sin(ang) * rr * 0.7, kind: i === 0 ? 'hall' : (i === 1 ? 'shop' : 'smith'), seed: hash32(i, gx, gy) });
    }
    const site = { key, x, y, name, huts, biome: b.id, accent: b.accent };
    this.sites.push(site);
    // penduduk
    const nV = 3 + Math.floor(hash32(gy, gx, 17) * 3);
    for (let i = 0; i < nV; i++) {
      const rdef = VILLAGER_ROLES[i % VILLAGER_ROLES.length];
      const id = 'vil_' + key.replace(':', '_') + '_' + i;
      NPC_LINES[id] = { name: rdef.role + ' ' + name.split(' ')[1], role: rdef.role + ' — ' + name, tint: rdef.tint, panel: rdef.panel || null, idle: rdef.lines };
      const ang = i / nV * 6.28 + 0.6;
      World.NPCS.push({
        id, x: x + Math.cos(ang) * 30, y: y + Math.sin(ang) * 22, dir: 0, frame: 0, t: Math.random() * 10,
        panel: rdef.panel || null, village: true, vkey: key,
      });
    }
    return site;
  },
  // dipanggil dari render agar pondok tersortir bersama entitas
  collect(list, ctx, cam) {
    for (const s of this.sites) {
      if (Math.abs(s.x - cam.x - G.VW / 2) > 520 || Math.abs(s.y - cam.y - G.VH / 2) > 460) continue;
      list.push({ y: s.y - 60, draw: () => {
        Game.label(s.name, Math.round(s.x - cam.x), Math.round(s.y - 74 - cam.y), s.accent || '#ffe9b8', 6, { bold: true, bg: 'rgba(15,12,22,0.78)' });
      } });
      for (const hu of s.huts) {
        if (Math.abs(hu.x - cam.x - G.VW / 2) > 380 || Math.abs(hu.y - cam.y - G.VH / 2) > 340) continue;
        list.push({ y: hu.y, draw: () => {
          const img = Art.building(hu.kind);
          const w = Math.round(img.width * 0.62), hh = Math.round(img.height * 0.62);
          ctx.drawImage(img, Math.round(hu.x - w / 2 - cam.x), Math.round(hu.y - hh - cam.y), w, hh);
        } });
      }
    }
  },
};

/* ======================= MODE BOSS CLASH ======================= */
const Clash = {
  active: false, wave: 0, boss: null, arena: null, saved: null, t: 0, done: false,
  ARENA_R: 210,
  start() {
    const G = Game;
    if (G.state !== 'play' || this.active) return;      // tekan dua kali tidak lagi menghapus posisi asli
    if (G.player.dead) { G.toast('Pulihkan dirimu dulu sebelum masuk arena.', '#ff7a7a'); return; }
    this.saved = { x: G.player.x, y: G.player.y };
    Status.clear && Status.clear(G.player);
    Skills.cd = [0, 0, 0]; Skills.timeslow = 0;
    this.active = true; this.wave = 0; this.done = false; this.t = 0;
    // arena terbatas jauh di luar peta biasa
    this.arena = { x: 40000 + 8, y: 40000 + 8, r: this.ARENA_R };
    G.player.x = this.arena.x; G.player.y = this.arena.y + this.ARENA_R - 40;
    G.enemies.length = 0; G.projectiles.length = 0; Fx.clear();
    G.player.hp = G.player.stats.hp;
    G.toast('BOSS CLASH — 16 bos, dari terlemah ke terkuat!', '#ff9a6b');
    Audio2.sfx('clash'); Audio2.setIntensity(2);
    this.spawnWave();
    UI.syncHUD();
  },
  exit(win) {
    const G = Game;
    const reached = this.wave;
    this.active = false; this.boss = null;
    G.enemies.length = 0; G.projectiles.length = 0; Fx.clear();
    if (this.saved) { G.player.x = this.saved.x; G.player.y = this.saved.y; this.saved = null; }
    G.cam.x = G.player.x - G.VW / 2; G.cam.y = G.player.y - G.VH / 2;
    Status.clear && Status.clear(G.player);
    Skills.cd = [0, 0, 0]; Skills.timeslow = 0;
    // jangan lempar pemain ke alam bebas dengan sisa darah setipis kertas
    G.player.hp = Math.max(G.player.hp, Math.round(G.player.stats.hp * 0.5));
    this.wave = 0;
    Audio2.setIntensity(0);
    if (win) {
      Inv.add('sw_flower');
      Inv.add('m_petal', 3);
      G.toast('PEDANG RAHASIA DIDAPAT: Flowers Flame!', '#ff9ec4');
      Audio2.sfx('unlock');
      G.cutscene = {
        title: 'Flowers Flame', lines: [
          'Enam belas bos tumbang di arena. Debu mereka berkumpul menjadi kelopak api.',
          'Kau menggenggam Flowers Flame — bilah rahasia yang membakar sekaligus menyembuhkan.',
        ], idx: 0, after: () => { G.state = 'play'; UI.syncHUD(); },
      };
      G.state = 'cutscene';
    } else {
      G.toast('Boss Clash berakhir di gelombang ' + reached + '/16.', '#8b93a5');
    }
    UI.syncHUD();
  },
  spawnWave() {
    const G = Game;
    const bid = CLASH_LADDER[this.wave];
    if (!bid) { this.exit(true); return; }
    const e = G.spawnEnemy(bid, Math.floor(this.arena.x / 16), Math.floor((this.arena.y - 90) / 16));
    e.aggro = true; e.clash = true;
    this.boss = e;
    G.toast('Gelombang ' + (this.wave + 1) + '/16 — ' + ENEMIES[bid].name, '#ff7a45');
    Audio2.sfx('boss'); G.shake = 7;
    Fx.ring(e.x, e.y, 150, ENEMIES[bid].color);
  },
  update(dt) {
    if (!this.active) return;
    const G = Game, P = G.player, A = this.arena;
    this.t += dt;
    // kurung pemain & musuh di dalam arena
    const clamp = (o, pad) => {
      const dx = o.x - A.x, dy = (o.y - A.y) / 0.78, d = Math.hypot(dx, dy);
      if (d > A.r - pad) { const k = (A.r - pad) / d; o.x = A.x + dx * k; o.y = A.y + dy * k * 0.78; }
    };
    clamp(P, 10);
    for (const e of G.enemies) if (!e.dead) clamp(e, 18);
    if (this.boss && this.boss.dead) {
      this.boss = null; this.wave++;
      if (this.wave >= 16) { this.exit(true); return; }
      G.player.hp = Math.min(G.player.stats.hp, G.player.hp + Math.round(G.player.stats.hp * 0.35));
      G.toast('Bos tumbang! HP dipulihkan 35%. Gelombang berikutnya...', '#6fe08a');
      setTimeout(() => { if (this.active) this.spawnWave(); }, 1600);
    }
  },
  draw(ctx, cam) {
    if (!this.active) return;
    const A = this.arena;
    const sx = Math.round(A.x - cam.x), sy = Math.round(A.y - cam.y);
    // lantai arena
    ctx.save();
    const g = ctx.createRadialGradient(sx, sy, 20, sx, sy, A.r);
    g.addColorStop(0, '#2a1f38'); g.addColorStop(0.7, '#1b1428'); g.addColorStop(1, '#0d0918');
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(sx, sy, A.r, A.r * 0.78, 0, 0, 6.28); ctx.fill();
    // cincin rune
    for (let i = 0; i < 3; i++) {
      ctx.globalAlpha = 0.5 - i * 0.12; ctx.strokeStyle = i ? '#9a7bff' : '#f5b53c'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(sx, sy, A.r - 8 - i * 26, (A.r - 8 - i * 26) * 0.78, 0, 0, 6.28); ctx.stroke();
    }
    ctx.globalAlpha = 0.85;
    for (let i = 0; i < 24; i++) {
      const a = i / 24 * 6.28 + Game.time * 0.15;
      const px = sx + Math.cos(a) * (A.r - 4), py = sy + Math.sin(a) * (A.r - 4) * 0.78;
      ctx.fillStyle = i % 3 === 0 ? '#f5b53c' : '#6a4fa8';
      ctx.fillRect(Math.round(px) - 3, Math.round(py) - 10, 6, 20);
    }
    ctx.globalAlpha = 1; ctx.restore();
  },
};

/* ======================= SHADER / DLSS 5 ======================= */
const Shader = {
  buf: null, bctx: null, vg: null, vgKey: '',
  ensure(w, h) {
    const bw = Math.max(1, Math.round(w / 2)), bh = Math.max(1, Math.round(h / 2));
    if (!this.buf || this.buf.width !== bw || this.buf.height !== bh) {
      this.buf = document.createElement('canvas'); this.buf.width = bw; this.buf.height = bh;
      this.bctx = this.buf.getContext('2d');
    }
  },
  vignette(ctx, w, h) {
    const key = w + 'x' + h;
    if (this.vgKey !== key) {
      this.vg = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.28, w / 2, h / 2, Math.max(w, h) * 0.72);
      this.vg.addColorStop(0, 'rgba(255,255,255,1)');
      this.vg.addColorStop(0.72, 'rgba(226,222,236,1)');
      this.vg.addColorStop(1, 'rgba(120,116,140,1)');
      this.vgKey = key;
    }
    return this.vg;
  },
  apply(ctx, w, h) {
    const S = Game.settings;
    if (!S.shader || S.shader === 'off') return;
    const ultra = S.shader === 'ultra';
    this.ensure(w, h);
    const b = this.bctx, bw = this.buf.width, bh = this.buf.height;

    // --- 1. bloom ambang: hanya sorot terang yang ikut menyala ---
    b.clearRect(0, 0, bw, bh);
    b.filter = ultra ? 'brightness(150%) contrast(320%) blur(2px)' : 'brightness(140%) contrast(280%) blur(1.5px)';
    b.drawImage(ctx.canvas, 0, 0, bw, bh);
    b.filter = 'none';
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = ultra ? 0.16 : 0.1;
    ctx.drawImage(this.buf, 0, 0, w, h);
    if (ultra) { // aberasi kromatik tipis di sorotan
      ctx.globalAlpha = 0.05; ctx.drawImage(this.buf, 1.2, 0, w, h);
      ctx.globalAlpha = 0.04; ctx.drawImage(this.buf, -1.2, 0.8, w, h);
    }
    ctx.restore();

    // --- 2. gradasi warna sinematik: bayangan dingin, sorot hangat ---
    ctx.save();
    ctx.globalCompositeOperation = 'soft-light';
    ctx.globalAlpha = ultra ? 0.26 : 0.16;
    const g = ctx.createLinearGradient(0, 0, w * 0.35, h);
    g.addColorStop(0, '#ffd9a8'); g.addColorStop(0.55, '#8d8fb0'); g.addColorStop(1, '#2b3550');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    ctx.restore();

    // --- 3. vignette lembut (kontras tepi) ---
    ctx.save();
    ctx.globalCompositeOperation = 'multiply';
    ctx.globalAlpha = ultra ? 0.6 : 0.4;
    ctx.fillStyle = this.vignette(ctx, w, h);
    ctx.fillRect(0, 0, w, h);
    ctx.restore();

    // --- 3b. sedikit kurangi saturasi agar terasa filmis, bukan kartun ---
    ctx.save();
    ctx.globalCompositeOperation = 'saturation';
    ctx.globalAlpha = ultra ? 0.24 : 0.14;
    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, w, h);
    ctx.restore();

    if (ultra) {
      // --- 4. sinar volumetrik tipis dari kiri atas ---
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.05;
      const gr = ctx.createLinearGradient(0, 0, w * 0.55, h * 0.9);
      gr.addColorStop(0, '#fff3d6'); gr.addColorStop(1, 'rgba(255,243,214,0)');
      ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
      ctx.restore();
      // --- 5. grain film halus ---
      ctx.save();
      ctx.globalAlpha = 0.045;
      for (let i = 0; i < 55; i++) {
        ctx.fillStyle = Math.random() > 0.5 ? '#fff' : '#000';
        ctx.fillRect(Math.random() * w | 0, Math.random() * h | 0, 1, 1);
      }
      ctx.restore();
    }
  },
};

/* ======================= TAMBALAN KE GAME ======================= */
// kerusakan mentah (DoT, efek, zona) tanpa menghitung kritis pemain
Game.dealRaw = function (e, dmg, color, small) {
  if (!e || e.dead) return;
  dmg = Math.max(1, Math.round(dmg));
  e.hp -= dmg; e.flash = 0.1; e.aggro = true;
  this.floater(e.x + (Math.random() * 8 - 4), e.y - (small ? 16 : 22), String(dmg), color || '#ffffff');
  if (e.hp <= 0) this.killEnemy(e);
};
Game.bossDefeated = {};
Game.skillPanelOpen = false;

/* DLSS 5 masuk ke daftar mode */
DLSS_MODES.dlss5 = { label: 'DLSS 5 (Ultra Realistis)', scale: 0.5, sharp: 1.35 };
SETTINGS.shader = 'off';
