import { auth, db } from "./firebase.js";
import {
  doc,
  onSnapshot,
  collection,
  query,
  where
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

// NetEarn Pro Dashboard UI bridge
// IMPORTANT: this file does not reimplement business logic.
// It only maps the new visual controls to the original tested dashboard-v12.js controls.
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function trigger(selector){
  const el = document.querySelector(selector);
  if (el) { el.click(); return true; }
  return false;
}

function verified(){
  return window.__netearnDashboardData?.verified === true;
}

function routeService(type){
  switch(type){
    case 'typing': return trigger('#legacyTyping');
    case 'photo': return trigger('#legacyEditing');
    case 'form': return trigger('#legacyForm');
    case 'micro': return trigger('#legacyMicro');
    case 'dataentry': return trigger('#legacyData');
    case 'social': return trigger('#legacySocial');
    case 'bonus': return trigger('#legacyDaily');
    case 'referral': window.location.href='referral.html'; return true;
    case 'verification':
      if (verified()) window.location.href='premium-status.html';
      else if (typeof window.goVerify === 'function') window.goVerify();
      else window.location.href='verification-details.html';
      return true;
  }
  return false;
}

function bind(){
  $$('.service[data-service]').forEach(btn=>{
    btn.addEventListener('click',()=>routeService(btn.dataset.service));
  });
}

let liveStartedForUid = null;
let liveUnsubs = [];

function formatMoney(value){
  const n = Number(value);
  return `৳${(Number.isFinite(n) ? n : 0).toLocaleString('en-BD')}`;
}

function setText(id, value){
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function clearLiveListeners(){
  liveUnsubs.forEach(unsub => {
    try { unsub(); } catch (_) {}
  });
  liveUnsubs = [];
  liveStartedForUid = null;
}

function startLiveDashboardStats(uid, initialData = {}){
  if (!uid || liveStartedForUid === uid) return;

  clearLiveListeners();
  liveStartedForUid = uid;

  // Initial values are rendered immediately, then kept live by Firestore listeners.
  const initialBalance = Number(initialData.balance ?? initialData.creditBalance ?? 0);
  const initialRefs = Number(initialData.totalReferrals ?? initialData.referralCount ?? 0);
  const initialToday = Number(initialData.todayIncome ?? initialData.todayEarning ?? 0);
  const initialCompleted = Number(
    initialData.completedTasks ??
    initialData.completedTaskCount ??
    initialData.totalCompleted ??
    initialData.totalTasksCompleted ??
    0
  );

  setText('dashboardBalance', formatMoney(initialBalance));
  setText('dashboardCompleted', String(Number.isFinite(initialCompleted) ? initialCompleted : 0).padStart(2, '0'));
  setText('dashboardReferrals', String(Number.isFinite(initialRefs) ? initialRefs : 0).padStart(2, '0'));
  setText('dashboardToday', formatMoney(initialToday));

  // 1) Credit Balance — live from the member's own users/{uid} document.
  liveUnsubs.push(onSnapshot(
    doc(db, 'users', uid),
    snap => {
      if (!snap.exists()) return;
      const data = snap.data() || {};
      window.__netearnDashboardData = data;
      setText('dashboardBalance', formatMoney(data.balance ?? data.creditBalance ?? 0));
    },
    error => console.error('Dashboard live balance listener error:', error)
  ));

  // 2) Completed — live count of approved/completed task submissions for this member.
  liveUnsubs.push(onSnapshot(
    query(collection(db, 'taskSubmissions'), where('userUid', '==', uid)),
    snap => {
      let completed = 0;
      snap.forEach(item => {
        const status = String(item.data()?.status || '').trim().toLowerCase();
        if (status === 'approved' || status === 'completed') completed += 1;
      });
      setText('dashboardCompleted', String(completed).padStart(2, '0'));
    },
    error => console.error('Dashboard live completed listener error:', error)
  ));

  // 3) Referrals — live count of users linked to this member's referral code.
  const referralCode = String(initialData.referralCode || '').trim();
  if (referralCode) {
    liveUnsubs.push(onSnapshot(
      query(collection(db, 'users'), where('referrerCode', '==', referralCode)),
      snap => setText('dashboardReferrals', String(snap.size).padStart(2, '0')),
      error => console.error('Dashboard live referral listener error:', error)
    ));
  }

  // 4) Today — live from task rewards plus non-task credit transactions.
  // Task rewards are stored in rewardHistory; referral/bonus/other credits are stored in transactions.
  let liveRewardSnap = null;
  let liveTransactionSnap = null;

  const renderTodayIncome = () => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const validStatuses = new Set(['approved', 'completed', 'complete', 'success', 'successful']);
    const debitTypes = new Set(['debit', 'withdraw', 'withdrawal', 'purchase', 'payment', 'subscription', 'expense']);
    let today = 0;

    if (liveRewardSnap) {
      liveRewardSnap.forEach(item => {
        const data = item.data() || {};
        const status = String(data.status || '').trim().toLowerCase();
        if (!validStatuses.has(status)) return;

        const type = String(data.type || '').trim().toLowerCase();
        if (debitTypes.has(type)) return;

        const amount = Number(data.reward ?? data.amount ?? 0);
        if (!Number.isFinite(amount) || amount <= 0) return;

        const rawDate = data.createdAt;
        let date = null;
        if (rawDate?.toDate) date = rawDate.toDate();
        else if (rawDate instanceof Date) date = rawDate;
        else if (typeof rawDate === 'string' || typeof rawDate === 'number') date = new Date(rawDate);
        if (!date || Number.isNaN(date.getTime())) return;

        if (date >= todayStart) today += amount;
      });
    }

    if (liveTransactionSnap) {
      liveTransactionSnap.forEach(item => {
        const data = item.data() || {};
        const status = String(data.status || '').trim().toLowerCase();
        if (!validStatuses.has(status)) return;

        const type = String(data.type || '').trim().toLowerCase();
        if (type !== 'credit' || debitTypes.has(type)) return;

        const reason = String(data.reason || data.title || '').trim().toLowerCase();
        const title = String(data.title || '').trim().toLowerCase();
        if (reason.includes('task reward') || title.includes('task reward') || type === 'task_reward') return;

        const amount = Number(data.amount ?? data.reward ?? 0);
        if (!Number.isFinite(amount) || amount <= 0) return;

        const rawDate = data.createdAt;
        let date = null;
        if (rawDate?.toDate) date = rawDate.toDate();
        else if (rawDate instanceof Date) date = rawDate;
        else if (typeof rawDate === 'string' || typeof rawDate === 'number') date = new Date(rawDate);
        if (!date || Number.isNaN(date.getTime())) return;

        if (date >= todayStart) today += amount;
      });
    }

    setText('dashboardToday', formatMoney(today));
  };

  liveUnsubs.push(onSnapshot(
    query(collection(db, 'rewardHistory'), where('userUid', '==', uid)),
    snap => { liveRewardSnap = snap; renderTodayIncome(); },
    error => console.error('Dashboard live today reward listener error:', error)
  ));

  liveUnsubs.push(onSnapshot(
    query(collection(db, 'transactions'), where('uid', '==', uid)),
    snap => { liveTransactionSnap = snap; renderTodayIncome(); },
    error => console.error('Dashboard live today transaction listener error:', error)
  ));
}

window.addEventListener('netearn:user-data-ready', event => {
  const data = event.detail?.data || {};
  window.__netearnDashboardData = data;
  const uid = event.detail?.user?.uid || auth.currentUser?.uid;
  startLiveDashboardStats(uid, data);
});

// Safety fallback in case this bridge loads after the dashboard event was dispatched.
if (auth.currentUser?.uid && window.__netearnDashboardData) {
  startLiveDashboardStats(auth.currentUser.uid, window.__netearnDashboardData);
}

bind();
