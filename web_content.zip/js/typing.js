// =======================================
// NetEarn Pro
// Typing Task System V3
// Firebase Auth + Task Status Validation
// =======================================

import { auth, db } from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    getDoc,
    collection,
    query,
    where,
    limit,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// ELEMENTS
// =======================================

const statusBox =
    document.getElementById("taskStatus");

const startBtn =
    document.getElementById("startTypingBtn");


// =======================================
// TASK PAGE
// =======================================

const TASK_PAGE =
    "typing-work.html";

// ⚡ Share the single fresh Business Settings read across the page.
// This prevents the reward display and task loader from requesting
// settings/main independently during the same page load.
let sharedSettingsPromise = null;

function getSharedBusinessSettings() {

    if (!sharedSettingsPromise) {
        sharedSettingsPromise =
            getBusinessSettings({ force: true });
    }

    return sharedSettingsPromise;
}


// =======================================
// FIND ACTIVE TYPING TASK
// =======================================

async function getActiveTypingTask() {

    const tasksRef =
        collection(
            db,
            "tasks"
        );

    const q =
        query(
            tasksRef,

            where(
                "category",
                "==",
                "Typing"
            ),

            where(
                "status",
                "==",
                "Active"
            ),

            limit(1)
        );

    // ⚡ Load task and business settings in parallel.
    const settingsPromise =
        getSharedBusinessSettings();

    const [snap, settings] =
        await Promise.all([
            getDocs(q),
            settingsPromise
        ]);

    if (snap.empty) {

        throw new Error(
            "ACTIVE_TYPING_TASK_NOT_FOUND"
        );

    }

    const taskDoc =
        snap.docs[0];

    const task = {
        id: taskDoc.id,
        ...taskDoc.data()
    };

    task.reward =
        getConfiguredTaskReward(task, settings);

    return task;

}

// =======================================
// SHOW STATUS
// =======================================

function showStatus(message, className = "status locked"){

    if(!statusBox)
        return;

    statusBox.innerHTML =
        message;

    statusBox.className =
        className;

}


// =======================================
// DISABLE START BUTTON
// =======================================

function disableTask(){

    if(startBtn){

        startBtn.style.display =
            "none";

        startBtn.disabled =
            true;

    }

}


// =======================================
// ENABLE START BUTTON
// =======================================

function enableTask(){

    if(startBtn){

        startBtn.style.display =
            "block";

        startBtn.disabled =
            false;

    }

}


// =======================================
// LOAD CENTRAL TYPING REWARD
// =======================================

async function loadTypingReward() {

    const rewardElement =
        document.getElementById("typingTaskReward");

    if (!rewardElement) return;

    try {

        // Reuse the same fresh settings request used by the task loader.
        // No fallback/default is used for this visible amount.
        const settings =
            await getSharedBusinessSettings();

        const reward =
            Number(settings?.typingReward);

        if (Number.isFinite(reward) && reward >= 0) {
            rewardElement.textContent =
                `৳${reward.toLocaleString("en-BD")}`;
        }

    } catch (error) {

        console.error("Typing reward load failed:", error);

    }

}


// =======================================
// AUTH CHECK
// =======================================

onAuthStateChanged(
    auth,
    async(user)=>{

        // ===================================
        // NOT LOGGED IN
        // ===================================

        if(!user){

            window.location.href =
                "index.html";

            return;

        }


        // ===================================
        // INITIAL STATE
        // ===================================

        loadTypingReward();

        disableTask();

        showStatus(
            "⏳ Checking Task Status..."
        );


        try{

            // ===================================
            // LOAD FRESH USER DATA
            // ===================================

            const userRef =
                doc(
                    db,
                    "users",
                    user.uid
                );


            const snap =
                await getDoc(
                    userRef
                );


            // ===================================
            // USER DATA NOT FOUND
            // ===================================

            if(!snap.exists()){

                showStatus(
                    "⚠️ User Data Not Found"
                );

                disableTask();

                return;

            }


            const userData =
                snap.data();


            // ===================================
            // VERIFY CHECK
            // ===================================

            const verified =

                userData.verified === true ||

                userData.verified === "true";


            if(!verified){

                showStatus(
                    "🔒 Please Verify Your Account First"
                );

                disableTask();

                return;

            }


            // ===================================
            // TYPING TASK STATUS
            // ===================================

            const typingStatus =
                userData.typingTaskStatus ||
                "none";


            // ===================================
            // PENDING
            // ===================================

            if(
                typingStatus ===
                "pending"
            ){

                showStatus(
                    "⏳ Typing Task Submitted — Waiting for Admin Approval"
                );

                disableTask();

                return;

            }


            // ===================================
            // APPROVED
            // ===================================

            if(
                typingStatus ===
                "approved"
            ){

                showStatus(
                    "✅ Typing Task Already Approved"
                );

                disableTask();

                return;

            }


            // ===================================
            // ACTIVE
            // ===================================

            if(
                typingStatus ===
                "active"
            ){

                showStatus(
                    "🟢 Typing Task In Progress",
                    "status available"
                );

                enableTask();


                startBtn.onclick =
    async () => {

        try {

            startBtn.disabled = true;

            startBtn.textContent =
                "⏳ Loading Task...";

            const task =
                await getActiveTypingTask();

            const rewardElement =
                document.getElementById("typingTaskReward");

            if (rewardElement) {
                rewardElement.textContent =
                    `৳${Number(task.reward || 0).toLocaleString("en-BD")}`;
            }

            window.location.href =
                `${TASK_PAGE}?taskId=${task.id}`;

        }

        catch(error) {

            console.error(
                "Typing Task Start Error:",
                error
            );

            alert(
                "❌ Active Typing Task পাওয়া যায়নি।"
            );

            startBtn.disabled = false;

            startBtn.textContent =
                "▶ Start Typing Task";

        }

    };

                return;

            }


            // ===================================
            // REJECTED
            // ===================================

            if(
                typingStatus ===
                "rejected"
            ){

                // Rejected task can be selected
                // again according to chance system.

                console.log(
                    "Typing Task was rejected."
                );

            }


            // ===================================
            // TASK CHANCE CHECK
            // ===================================

            const chance =
                Number(
                    userData.taskChance || 0
                );


            if(chance < 1){

                showStatus(
                    "👥 Need 1 Referral = 1 Task Chance"
                );

                disableTask();

                return;

            }


            // ===================================
            // SELECTED TASK CHECK
            // ===================================

            const selectedTask =
                userData.selectedTask ||
                null;


            // ===================================
            // ANOTHER TASK SELECTED
            // ===================================

            if(
                selectedTask &&
                selectedTask !== "typing"
            ){

                const taskNames = {

                    editing:
                        "Photo Editing",

                    formfill:
                        "Form Fill",

                    microjob:
                        "Micro Job",

                    dataentry:
                        "Data Entry",

                    social:
                        "Social Task"

                };


                const selectedName =
                    taskNames[selectedTask] ||
                    selectedTask;


                showStatus(
                    `🔒 ${selectedName} Task Already Selected`
                );

                disableTask();

                return;

            }


            // ===================================
            // READY
            // ===================================

            showStatus(
                "✅ Typing Task Ready",
                "status available"
            );


            enableTask();


            // ===================================
            // START TYPING
            // ===================================

            startBtn.onclick =
    async () => {

        try {

            startBtn.disabled = true;

            startBtn.textContent =
                "⏳ Loading Task...";

            const task =
                await getActiveTypingTask();

            const rewardElement =
                document.getElementById("typingTaskReward");

            if (rewardElement) {
                rewardElement.textContent =
                    `৳${Number(task.reward || 0).toLocaleString("en-BD")}`;
            }

            window.location.href =
                `${TASK_PAGE}?taskId=${task.id}`;

        }

        catch(error) {

            console.error(
                "Typing Task Start Error:",
                error
            );

            alert(
                "❌ Active Typing Task পাওয়া যায়নি।"
            );

            startBtn.disabled = false;

            startBtn.textContent =
                "▶ Start Typing Task";

        }

    };
            
        }

        catch(error){

            console.error(
                "Typing Task Error:",
                error
            );


            showStatus(
                "⚠️ Task Load করা যায়নি। আবার চেষ্টা করুন।"
            );

            disableTask();

        }

    }
);


console.log(
    "✅ NetEarn Pro Typing Task V3 Loaded"
);