document.addEventListener("DOMContentLoaded", () => {
  const display = document.getElementById("calcDisplay");
  let expression = "";
  const write = value => { expression += value; display.value = expression || "0"; };
  document.querySelectorAll("[data-calc]").forEach(btn => btn.onclick = () => write(btn.dataset.calc));
  document.getElementById("calcClear").onclick = () => { expression=""; display.value="0"; };
  document.getElementById("calcEquals").onclick = () => {
    try {
      let e = expression.replace(/\^/g,"**").replace(/\bpi\b/g,"Math.PI")
        .replace(/sqrt\(/g,"Math.sqrt(").replace(/sin\(/g,"Math.sin(")
        .replace(/cos\(/g,"Math.cos(").replace(/tan\(/g,"Math.tan(");
      const result = Function('"use strict"; return ('+e+')')();
      if(!Number.isFinite(result)) throw new Error();
      expression = String(Number(result.toFixed(12)));
      display.value = expression;
    } catch(_) { display.value="Erreur"; expression=""; }
  };
});
