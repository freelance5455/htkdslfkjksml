// ======================================================
// DATA BARANG BISNISAPP
// File: js/barang.js
//
// Fungsi:
// 1. Menambah barang
// 2. Mengedit barang
// 3. Menghapus data supplier lama
// 4. Menyimpan data ke localStorage
// 5. Memberikan ID unik setiap barang
//
// Database:
// dataBarang
// ======================================================



// ======================================================
// AMBIL DATA BARANG
// ======================================================

function ambilDataBarang() {

    try {

        const data =
            localStorage.getItem("dataBarang");

        if (!data) {
            return [];
        }

        const hasil =
            JSON.parse(data);

        if (!Array.isArray(hasil)) {
            return [];
        }

        return hasil;

    }

    catch (error) {

        console.error(
            "Gagal membaca dataBarang:",
            error
        );

        return [];

    }

}



// ======================================================
// SIMPAN DATA BARANG
// ======================================================

function simpanDataBarang(data) {

    localStorage.setItem(
        "dataBarang",
        JSON.stringify(data)
    );

}



// ======================================================
// AMBIL NILAI INPUT
// ======================================================

function nilaiInput(id) {

    const elemen =
        document.getElementById(id);

    if (!elemen) {
        return "";
    }

    return elemen.value.trim();

}



// ======================================================
// SIMPAN / UPDATE BARANG
// ======================================================

function simpanBarang() {


    // -----------------------------------------------
    // AMBIL DATA FORM
    // -----------------------------------------------

    const kode =
        nilaiInput("kodeBarang");

    const nama =
        nilaiInput("namaBarang");

    const satuan =
        nilaiInput("satuanBarang");

    const stok =
        Number(
            nilaiInput("stokBarang")
        ) || 0;

    const hargaBeli =
        Number(
            nilaiInput("hargaBeli")
        ) || 0;

    const hargaJual =
        Number(
            nilaiInput("hargaJual")
        ) || 0;

    const minimumStok =
        Number(
            nilaiInput("minimumStok")
        ) || 0;



    // -----------------------------------------------
    // VALIDASI KODE
    // -----------------------------------------------

    if (!kode) {

        alert(
            "Kode barang wajib diisi."
        );

        document
            .getElementById("kodeBarang")
            .focus();

        return;

    }



    // -----------------------------------------------
    // VALIDASI NAMA
    // -----------------------------------------------

    if (!nama) {

        alert(
            "Nama barang wajib diisi."
        );

        document
            .getElementById("namaBarang")
            .focus();

        return;

    }



    // -----------------------------------------------
    // VALIDASI SATUAN
    // -----------------------------------------------

    if (!satuan) {

        alert(
            "Satuan barang wajib diisi."
        );

        document
            .getElementById("satuanBarang")
            .focus();

        return;

    }



    // -----------------------------------------------
    // VALIDASI ANGKA
    // -----------------------------------------------

    if (
        stok < 0 ||
        hargaBeli < 0 ||
        hargaJual < 0 ||
        minimumStok < 0
    ) {

        alert(
            "Nilai angka tidak boleh negatif."
        );

        return;

    }



    // -----------------------------------------------
    // AMBIL DATABASE
    // -----------------------------------------------

    let dataBarang =
        ambilDataBarang();



    // -----------------------------------------------
    // CEK MODE EDIT
    // -----------------------------------------------

    const editId =
        localStorage.getItem(
            "editBarangId"
        );



    // =================================================
    // MODE EDIT
    // =================================================

    if (editId) {


        const index =
            dataBarang.findIndex(
                function(barang) {

                    return String(barang.id)
                        === String(editId);

                }
            );


        if (index === -1) {

            alert(
                "Data barang yang akan diedit tidak ditemukan."
            );

            localStorage.removeItem(
                "editBarangId"
            );

            return;

        }



        // ---------------------------------------------
        // CEK KODE DUPLIKAT
        // ---------------------------------------------

        const kodeDipakai =
            dataBarang.some(
                function(barang, i) {

                    return (
                        i !== index &&
                        String(barang.kode)
                            .toLowerCase()
                        ===
                        String(kode)
                            .toLowerCase()
                    );

                }
            );


        if (kodeDipakai) {

            alert(
                "Kode barang sudah digunakan oleh barang lain."
            );

            return;

        }



        // ---------------------------------------------
        // PERTAHANKAN DATA LAMA
        // ---------------------------------------------

        const barangLama =
            dataBarang[index];



        dataBarang[index] = {

            // ID TIDAK BERUBAH
            id:
                barangLama.id ||
                Date.now(),


            kode:
                kode,

            nama:
                nama,

            satuan:
                satuan,

            stok:
                stok,

            hargaBeli:
                hargaBeli,

            hargaJual:
                hargaJual,

            minimumStok:
                minimumStok,


            // -----------------------------------------
            // DATA DARI PEMBELIAN TETAP DIPERTAHANKAN
            // -----------------------------------------

            distributorTerakhir:
                barangLama.distributorTerakhir || "",

            distributorTerakhirId:
                barangLama.distributorTerakhirId || "",

            riwayatHarga:
                Array.isArray(
                    barangLama.riwayatHarga
                )
                    ? barangLama.riwayatHarga
                    : []

        };



        simpanDataBarang(
            dataBarang
        );


        localStorage.removeItem(
            "editBarangId"
        );


        alert(
            "Data barang berhasil diperbarui."
        );


        kosongkanForm();


        return;

    }



    // =================================================
    // MODE TAMBAH BARANG BARU
    // =================================================



    // -----------------------------------------------
    // CEK KODE DUPLIKAT
    // -----------------------------------------------

    const kodeSudahAda =
        dataBarang.some(
            function(barang) {

                return String(barang.kode)
                    .toLowerCase()
                ===
                String(kode)
                    .toLowerCase();

            }
        );


    if (kodeSudahAda) {

        alert(
            "Kode barang sudah digunakan.\n\n" +
            "Gunakan kode barang yang berbeda."
        );

        return;

    }



    // -----------------------------------------------
    // BUAT BARANG BARU
    // -----------------------------------------------

    const barangBaru = {

        // ID UNIK
        id:
            Date.now(),


        kode:
            kode,

        nama:
            nama,

        satuan:
            satuan,

        stok:
            stok,

        hargaBeli:
            hargaBeli,

        hargaJual:
            hargaJual,

        minimumStok:
            minimumStok,


        // Belum ada distributor
        distributorTerakhir:
            "",

        distributorTerakhirId:
            "",


        // Riwayat harga awal
        riwayatHarga:
            []

    };



    // -----------------------------------------------
    // MASUKKAN KE DATABASE
    // -----------------------------------------------

    dataBarang.push(
        barangBaru
    );



    // -----------------------------------------------
    // SIMPAN LOCALSTORAGE
    // -----------------------------------------------

    simpanDataBarang(
        dataBarang
    );



    // -----------------------------------------------
    // BERHASIL
    // -----------------------------------------------

    alert(
        "Barang berhasil disimpan."
    );



    // -----------------------------------------------
    // BERSIHKAN FORM
    // -----------------------------------------------

    kosongkanForm();

}



// ======================================================
// KOSONGKAN FORM
// ======================================================

function kosongkanForm() {


    const daftarInput = [

        "kodeBarang",
        "namaBarang",
        "satuanBarang",
        "stokBarang",
        "hargaBeli",
        "hargaJual",
        "minimumStok"

    ];


    daftarInput.forEach(
        function(id) {

            const elemen =
                document.getElementById(id);

            if (elemen) {

                elemen.value = "";

            }

        }
    );



    // Nilai default angka

    const stok =
        document.getElementById(
            "stokBarang"
        );

    if (stok) {
        stok.value = "0";
    }


    const beli =
        document.getElementById(
            "hargaBeli"
        );

    if (beli) {
        beli.value = "0";
    }


    const jual =
        document.getElementById(
            "hargaJual"
        );

    if (jual) {
        jual.value = "0";
    }


    const minimum =
        document.getElementById(
            "minimumStok"
        );

    if (minimum) {
        minimum.value = "0";
    }


    // Kembalikan judul

    const judul =
        document.getElementById(
            "judulFormBarang"
        );

    if (judul) {

        judul.textContent =
            "Tambah Barang";

    }


    const tombol =
        document.getElementById(
            "tombolSimpanBarang"
        );

    if (tombol) {

        tombol.textContent =
            "Simpan Barang";

    }


    const batal =
        document.getElementById(
            "tombolBatalEdit"
        );

    if (batal) {

        batal.style.display =
            "none";

    }

}



// ======================================================
// BATAL EDIT
// ======================================================

function batalEditBarang() {

    localStorage.removeItem(
        "editBarangId"
    );

    kosongkanForm();

}



// ======================================================
// LOAD DATA UNTUK EDIT
// ======================================================

function muatDataEdit() {


    const editId =
        localStorage.getItem(
            "editBarangId"
        );


    if (!editId) {
        return;
    }



    const dataBarang =
        ambilDataBarang();



    const barang =
        dataBarang.find(
            function(item) {

                return String(item.id)
                    === String(editId);

            }
        );



    if (!barang) {

        localStorage.removeItem(
            "editBarangId"
        );

        return;

    }



    // -----------------------------------------------
    // ISI FORM
    // -----------------------------------------------

    document.getElementById(
        "kodeBarang"
    ).value =
        barang.kode || "";


    document.getElementById(
        "namaBarang"
    ).value =
        barang.nama || "";


    document.getElementById(
        "satuanBarang"
    ).value =
        barang.satuan || "";


    document.getElementById(
        "stokBarang"
    ).value =
        Number(barang.stok) || 0;


    document.getElementById(
        "hargaBeli"
    ).value =
        Number(barang.hargaBeli) || 0;


    document.getElementById(
        "hargaJual"
    ).value =
        Number(barang.hargaJual) || 0;


    document.getElementById(
        "minimumStok"
    ).value =
        Number(barang.minimumStok) || 0;



    // -----------------------------------------------
    // UBAH TAMPILAN
    // -----------------------------------------------

    const judul =
        document.getElementById(
            "judulFormBarang"
        );

    if (judul) {

        judul.textContent =
            "Edit Barang";

    }


    const tombol =
        document.getElementById(
            "tombolSimpanBarang"
        );

    if (tombol) {

        tombol.textContent =
            "Simpan Perubahan";

    }


    const batal =
        document.getElementById(
            "tombolBatalEdit"
        );

    if (batal) {

        batal.style.display =
            "block";

    }

}



// ======================================================
// JALANKAN
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        muatDataEdit();

    }
);