import {appState,patch} from "./state.js";import {render} from "./ui.js";
const steps=[
["experience","Nível",["beginner","basic","intermediate"],["Iniciante","Básico","Intermediário"]],
["location","Local",["home","park","gym"],["Casa","Parque","Academia"]],
["equipment","Equipamento",["none","bar","parallettes"],["Nenhum","Barra","Paralelas"]],
["time","Tempo",["10","20","30","45"],["10 min","20 min","30 min","45+ min"]],
["goal","Objetivo",["fundamentals","strength","control","skills","consistency"],["Fundamentos","Força","Controlo corporal","Skills","Consistência"]]
];
export function onboardingView(step=0){const [key,title,vals,labels]=steps[step];return `<main class="screen"><div class="topbar"><span class="brand">CALISTEN</span><span class="pill">${step+1}/${steps.length}</span></div><h1 class="title">${title}</h1><p class="subtitle">Isto será usado para personalizar o treino.</p><div class="stack">${vals.map((v,i)=>`<button class="btn ${((appState.profile[key]||appState.settings[key])===v||(Array.isArray(appState.profile[key])&&appState.profile[key].includes(v)))?"primary":""}" data-onboard="${key}" data-value="${v}">${labels[i]}</button>`).join("")}</div></main>`}
export function bindOnboarding(step){document.querySelectorAll("[data-onboard]").forEach(b=>b.onclick=async()=>{const k=b.dataset.onboard,v=b.dataset.value;if(k==="equipment"){appState.profile.equipment=[v];appState.settings.equipment=[v]}else if(k==="time"){appState.profile.time=+v;appState.settings.duration=+v}else appState.profile[k]=v;if(step+1<steps.length)render(onboardingView(step+1),()=>bindOnboarding(step+1));else{appState.onboarding.complete=true;await patch(()=>{});location.reload()}})}
export const startOnboarding=()=>{render(onboardingView(),()=>bindOnboarding(0))};