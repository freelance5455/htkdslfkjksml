'use strict';

const MEM = (() => {
  const ICONS = ['🍎','🍌','🍇','🍒','🍓','🍑','🥝','🍍'];
  let deck = [], flipped = [], moves = 0, matched = 0, lock = false;
  let started = false;

  function ensureStarted() { if (!started) { started = true; build(); } }

  function build() {
    const grid = document.getElementById('mem-grid');
    grid.innerHTML = '';
    deck = [];
    flipped = []; moves = 0; matched = 0; lock = false;

    const pairs = ICONS.concat(ICONS).map(i => ({ icon: i, matched: false }));
    for (let i = pairs.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pairs[i], pairs[j]] = [pairs[j], pairs[i]];
    }
    deck = pairs;

    pairs.forEach((card, idx) => {
      const el = document.createElement('button');
      el.className = 'mem-card';
      el.dataset.idx = idx;
      el.innerHTML = '<span class="face">' + card.icon + '</span>';
      el.addEventListener('click', () => flip(idx));
      grid.appendChild(el);
    });
    updateStats();
  }

  function flip(idx) {
    if (lock) return;
    const card = deck[idx];
    if (card.matched) return;
    const node = document.querySelector('.mem-card[data-idx="' + idx + '"]');
    if (node.classList.contains('flipped')) return;
    node.classList.add('flipped');

    if (flipped.length === 0) {
      flipped.push(idx);
      return;
    }
    const first = flipped[0];
    flipped = [];
    moves++;
    updateStats();

    if (deck[first].icon === deck[idx].icon) {
      deck[first].matched = true; deck[idx].matched = true;
      matched++;
      const n1 = document.querySelector('.mem-card[data-idx="' + first + '"]');
      const n2 = document.querySelector('.mem-card[data-idx="' + idx + '"]');
      n1.classList.add('matched'); n2.classList.add('matched');
      updateStats();
      if (matched === ICONS.length) {
        setTimeout(() => App.showModal('🎉', 'You did it!', 'Completed in ' + moves + ' moves', build), 260);
      }
    } else {
      lock = true;
      const n1 = document.querySelector('.mem-card[data-idx="' + first + '"]');
      const n2 = document.querySelector('.mem-card[data-idx="' + idx + '"]');
      setTimeout(() => {
        n1.classList.remove('flipped'); n2.classList.remove('flipped');
        lock = false;
      }, 650);
    }
  }

  function updateStats() {
    document.getElementById('mem-moves').textContent = moves;
    document.getElementById('mem-pairs').textContent = matched + '/' + ICONS.length;
  }

  function reset() { build(); }
  function statText() {
    if (!started) return '—';
    return matched + '/' + ICONS.length + ' · ' + moves + ' moves';
  }

  return { ensureStarted, reset, statText };
})();