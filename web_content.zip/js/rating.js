/**
 * BD BLOOD DONATION - Rating & Review System
 * Authentic receiver-to-donor rating submission, average recalculation, and duplicate protection.
 */

import { 
  db, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  serverTimestamp 
} from './firebase-config.js';
import { getCurrentUser, getCurrentUserProfile } from './auth.js';
import { showToast } from './utils.js';

export async function submitDonorRating({
  requestId,
  donorId,
  rating,
  reviewType = 'good', // 'good' | 'bad'
  feedbackText = ''
}) {
  const user = getCurrentUser();
  const profile = getCurrentUserProfile();
  if (!user) throw new Error('রেটিং প্রদান করতে লগইন আবশ্যক।');

  const ratingNum = Number(rating);
  if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
    throw new Error('১ থেকে ৫ তারকার মধ্যে রেটিং নির্বাচন করুন।');
  }

  // 1. Verify blood request
  const reqRef = doc(db, 'blood_requests', requestId);
  const reqSnap = await getDoc(reqRef);
  if (!reqSnap.exists()) {
    throw new Error('অনুরোধটি খুঁজে পাওয়া যায়নি।');
  }
  const reqData = reqSnap.data();

  if (reqData.requesterId !== user.uid) {
    throw new Error('শুধুমাত্র অনুরোধকারী এই রক্তদাতাকে রিভিউ দিতে পারবেন।');
  }

  if (reqData.isRated) {
    throw new Error('এই রক্তদানের জন্য ইতোমধ্যে রিভিউ ও রেটিং জমা দেওয়া হয়েছে।');
  }

  // 2. Add rating document
  const ratingData = {
    requestId,
    donorId,
    receiverId: user.uid,
    receiverName: profile?.fullName || user.displayName || 'সেবাগ্রহীতা',
    rating: ratingNum,
    reviewType,
    feedbackText: feedbackText.trim(),
    createdAt: serverTimestamp()
  };

  await addDoc(collection(db, 'ratings'), ratingData);

  // 3. Mark blood request as rated
  await updateDoc(reqRef, {
    isRated: true,
    ratedAt: serverTimestamp()
  });

  // 4. Update Donor's rating summary
  const donorRef = doc(db, 'users', donorId);
  const donorSnap = await getDoc(donorRef);
  if (donorSnap.exists()) {
    const donorData = donorSnap.data();
    const currentCount = donorData.ratingCount || 0;
    const currentSum = donorData.ratingSum || 0;
    const newCount = currentCount + 1;
    const newSum = currentSum + ratingNum;
    const newAverage = Number((newSum / newCount).toFixed(1));

    await updateDoc(donorRef, {
      ratingCount: newCount,
      ratingSum: newSum,
      averageRating: newAverage
    });
  }

  // 5. Notify donor
  try {
    await addDoc(collection(db, 'notifications'), {
      recipientId: donorId,
      requestId,
      type: 'rating_received',
      title: '⭐ নতুন রেটিং ও রিভিউ!',
      message: `${profile?.fullName || 'সেবাগ্রহীতা'} আপনাকে ${ratingNum}★ রেটিং ও মূল্যবান মতামত দিয়েছেন।`,
      read: false,
      createdAt: serverTimestamp()
    });
  } catch (e) {
    console.warn('[Rating Notification Error]', e.message);
  }

  showToast('ধন্যবাদ! আপনার মূল্যবান রেটিং ও রিভিউ সংরক্ষিত হয়েছে।', 'success');
}

/**
 * Get reviews for a specific donor
 */
export async function getDonorReviews(donorId, limitCount = 10) {
  try {
    const q = query(
      collection(db, 'ratings'),
      where('donorId', '==', donorId),
      orderBy('createdAt', 'desc'),
      limit(limitCount)
    );
    const snap = await getDocs(q);
    const reviews = [];
    snap.forEach(d => reviews.push({ id: d.id, ...d.data() }));
    return reviews;
  } catch (e) {
    console.warn('[Get Reviews Error]', e.message);
    return [];
  }
}
