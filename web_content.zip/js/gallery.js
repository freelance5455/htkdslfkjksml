/* شبكة المعرض */
window.Gallery = (function () {
  var grid = document.getElementById('grid');
  // إزالة أي تكرار في القائمة
  var seen = {};
  var items = window.GALLERY_IMAGES.filter(function (m) { return seen[m.f] ? false : (seen[m.f] = true); });
  var columns = 0;
  var tiles = {};

  function columnCount() {
    var w = window.innerWidth;
    return w < 520 ? 2 : w < 820 ? 3 : w < 1100 ? 4 : 5;
  }

  /* توزيع الصور على أقصر عمود للحفاظ على الترتيب والتناسق */
  function render() {
    columns = columnCount();
    grid.innerHTML = ''; tiles = {};
    var cols = [], heights = [];
    for (var c = 0; c < columns; c++) {
      var col = document.createElement('div');
      col.className = 'col';
      grid.appendChild(col); cols.push(col); heights.push(0);
    }
    items.forEach(function (m, i) {
      var k = heights.indexOf(Math.min.apply(null, heights));
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'tile';
      var im = new Image();
      im.loading = i < 12 ? 'eager' : 'lazy';
      im.decoding = 'async';
      im.width = m.w; im.height = m.h;
      im.style.background = m.c;
      im.alt = 'صورة ' + (i + 1);
      im.src = 'images/thumbs/' + m.f;
      b.appendChild(im);
      b.addEventListener('click', function () { Viewer.open(items, i); });
      cols[k].appendChild(b);
      heights[k] += m.h / m.w;
      tiles[m.f] = b;
    });
    document.getElementById('total').textContent = items.length + ' صورة';
  }

  function shuffled() {
    var a = items.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)), t = a[i];
      a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  document.getElementById('shuffle').addEventListener('click', function () { items = shuffled(); render(); });
  window.addEventListener('resize', function () { if (columnCount() !== columns) render(); });
  render();

  return {
    shuffled: shuffled,
    /* بعد إغلاق العارض: نعرض مكان آخر صورة شاهدها المستخدم */
    reveal: function (m) {
      var t = tiles[m.f];
      if (!t) return;
      setTimeout(function () {
        var r = t.getBoundingClientRect();
        if (r.bottom < 60 || r.top > window.innerHeight - 60) t.scrollIntoView({ block: 'center' });
      }, 50);
    }
  };
})();
