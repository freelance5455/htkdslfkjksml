window.WorkspaceVersion=(()=>{
  let current={product:'Modding Workspace',version:'0.20.28',display_version:'v0.20.28',channel:'Local Edition',build:'02028',database_schema:8,release_stage:'pre-release'};
  function render(){
    const badge=document.getElementById('workspaceVersionBadge');
    if(!badge)return;
    badge.textContent=current.display_version||`v${current.version||'0.0.0'}`;
    badge.title=`${current.product||'Modding Workspace'} ${badge.textContent} · ${current.channel||'Local Edition'} · Build ${current.build||'—'} · DB Schema ${current.database_schema??'—'}`;
    badge.dataset.channel=current.channel||'';
  }
  async function load(){
    try{
      const response=await fetch('app-version.json',{cache:'no-store'});
      if(response.ok){const value=await response.json();if(value&&typeof value==='object')current={...current,...value}}
    }catch{}
    render();return current
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load,{once:true});else load();
  return{load,current:()=>({...current})};
})();
