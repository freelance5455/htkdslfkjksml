"use strict";

const Reveal = (() => {
  const LOCK_MS = 1500;
  let cardOpen = false;
  let lockTimer = null;

  const $ = (id) => document.getElementById(id);

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function section(title, text) {
    const box = el("div", "rc-section");
    box.append(el("b", "", title + ": "), el("span", "", text));
    return box;
  }

  /* ---------- شاشة تسليم الهاتف ---------- */
  function showHandover() {
    const st = Game.getRevealState();
    if (!st || st.done) {
      UI.showScreen("reveal-done");
      return;
    }
    $("handover-progress").textContent = `اللاعب ${st.index + 1} من ${st.total}`;
    $("handover-name").textContent = st.player.name;
    $("btn-reveal-role").textContent = `👁️ أنا ${st.player.name} — جاهز`;
    UI.showScreen("reveal-handover");
  }

  /* ---------- البطاقة المقلوبة ---------- */
  function prepareCard() {
    cardOpen = false;
    $("flip-card").classList.remove("flipped");
    $("card-back").innerHTML = "";
    $("btn-hide-role").hidden = true;
    $("card-hint").hidden = false;
    UI.showScreen("reveal-card");
  }

  function buildBack(role, partners) {
    const back = $("card-back");
    back.innerHTML = "";
    back.style.setProperty("--role-color", role.color);
    back.append(
      el("div", "rc-icon", role.icon),
      el("div", "rc-name", role.name),
      el("div", "rc-team", "الفريق: " + Roles.TEAMS[role.team]),
      el("p", "rc-desc", role.description),
      section("القدرة", role.ability),
      section("شرط الفوز", role.win)
    );
    if (role.team === "mafia") {
      const text = partners.length > 0 ? partners.join("، ") : "أنت وحدك في المافيا";
      back.append(section("شركاؤك في المافيا", text));
    }
    back.append(el("div", "rc-secret", "🤫 " + role.secret));
  }

  function onFlip() {
    if (cardOpen) return;
    const st = Game.getRevealState();
    if (!st || st.done) return;
    const role = Roles.get(Game.getRoleIdOf(st.player.id));
    if (!role) {
      UI.toast("خطأ في قراءة الدور");
      return;
    }
    buildBack(role, Game.getMafiaPartnersOf(st.player.id));
    cardOpen = true;
    $("flip-card").classList.add("flipped");
    $("card-hint").hidden = true;
    $("btn-hide-role").hidden = false;
  }

  /* ---------- إخفاء الدور وشاشة القفل ---------- */
  function onHide() {
    if (!cardOpen) return; // حماية من الضغط المزدوج
    cardOpen = false;
    $("flip-card").classList.remove("flipped");
    $("card-back").innerHTML = "";
    $("btn-hide-role").hidden = true;
    const st = Game.advanceReveal();
    showTransition(st);
  }

  function showTransition(st) {
    const btn = $("btn-next-player");
    clearTimeout(lockTimer);
    btn.disabled = true;
    btn.textContent = "⏳ انتظر…";
    UI.showScreen("reveal-transition");
    lockTimer = setTimeout(() => {
      btn.disabled = false;
      btn.textContent = st && !st.done ? "👤 اللاعب التالي" : "✅ إنهاء التوزيع";
    }, LOCK_MS);
  }

  function onNext() {
    const btn = $("btn-next-player");
    if (btn.disabled) return;
    btn.disabled = true;
    showHandover();
  }

  /* ---------- البدء والتهيئة ---------- */
  function start() {
    clearTimeout(lockTimer);
    cardOpen = false;
    showHandover();
  }

  function init() {
    $("btn-reveal-role").addEventListener("click", prepareCard);
    $("flip-card").addEventListener("click", onFlip);
    $("btn-hide-role").addEventListener("click", onHide);
    $("btn-next-player").addEventListener("click", onNext);
    $("btn-start-night").addEventListener("click", () => {
      NightUI.start();
    });
  }

  return { init, start };
})();