/**
 * StockPro Comercial - Sistema de Licencia Offline
 * Formato: StockPro-Signed-License-v2
 * Algoritmo: ECDSA P-256 + SHA-256
 *
 * Compatible con el generador "StockPro Admin".
 * Método principal de carga: PEGAR el contenido del archivo .dat
 * (recomendado para APKForge, donde el selector de archivos suele fallar).
 */

/* ============================================================
   CLAVE PÚBLICA
   Sustituye este objeto por la clave pública que genera
   StockPro Admin (sección Llaves → Copiar pública).
   ============================================================ */
const PUBLIC_KEY_JWK = {
  "kty": "EC",
  "crv": "P-256",
  "x": "h7AnhPnGsPJyLiVkVcK1Gi6Fk2otneJQovBA7V7vJac",
  "y": "TzA-jAlmETUTbwrryLPGbw9x9JzVV_xkwaUxFsvrKd0",
  "ext": true
};

const LICENSE_STORAGE_KEY = "stockpro_license_v2";
const DEVICE_ID_KEY = "stockpro_device_id";

/* ---------- Utilidades Base64URL ---------- */
function base64urlToBytes(str) {
  const pad = "=".repeat((4 - (str.length % 4)) % 4);
  const b64 = (str + pad).replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function bytesToHex(bytes) {
  return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
}

/* ---------- ID de instalación ---------- */
function obtenerOCrearDeviceId() {
  let id = localStorage.getItem(DEVICE_ID_KEY);
  if (id) return id;

  const bytes = crypto.getRandomValues(new Uint8Array(6));
  id = "SP-" + bytesToHex(bytes).toUpperCase();
  localStorage.setItem(DEVICE_ID_KEY, id);
  return id;
}

function mostrarDeviceId() {
  const id = obtenerOCrearDeviceId();
  const elModal = document.getElementById("licenseDeviceId");
  const elCfg = document.getElementById("cfgDeviceId");
  if (elModal) elModal.textContent = id;
  if (elCfg) elCfg.textContent = id;
  return id;
}

/* ---------- Verificar firma ECDSA ---------- */
async function verificarFirmaECDSA(envelope) {
  if (!envelope || envelope.formato !== "StockPro-Signed-License-v2") {
    throw new Error("Formato de licencia no reconocido. Se espera StockPro-Signed-License-v2.");
  }
  if (!envelope.payload || !envelope.firma) {
    throw new Error("La licencia no contiene payload o firma.");
  }

  // Comprobar que la clave pública esté configurada
  if (!PUBLIC_KEY_JWK.x || PUBLIC_KEY_JWK.x.startsWith("REEMPLAZAR")) {
    throw new Error("Clave pública no configurada. El administrador debe pegar PUBLIC_KEY_JWK en license.js.");
  }

  const publicKey = await crypto.subtle.importKey(
    "jwk",
    PUBLIC_KEY_JWK,
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["verify"]
  );

  const payloadBytes = base64urlToBytes(envelope.payload);
  const signatureBytes = base64urlToBytes(envelope.firma);

  const ok = await crypto.subtle.verify(
    { name: "ECDSA", hash: "SHA-256" },
    publicKey,
    signatureBytes,
    payloadBytes
  );

  if (!ok) {
    throw new Error("Firma digital inválida. La licencia no fue firmada con la clave correcta o fue alterada.");
  }

  // Decodificar payload
  const payloadText = new TextDecoder().decode(payloadBytes);
  const payload = JSON.parse(payloadText);
  return payload;
}

/* ---------- Validar payload de negocio ---------- */
function validarPayload(payload) {
  if (!payload || typeof payload !== "object") {
    throw new Error("Payload de licencia inválido.");
  }

  if (payload.producto && payload.producto !== "StockPro Comercial") {
    throw new Error("Esta licencia no es para StockPro Comercial.");
  }

  const deviceId = obtenerOCrearDeviceId();
  if (payload.equipo && payload.equipo !== deviceId) {
    throw new Error(
      "Esta licencia está vinculada a otro equipo.\n" +
      "ID de esta instalación: " + deviceId + "\n" +
      "ID de la licencia: " + payload.equipo
    );
  }

  const hoy = new Date().toISOString().slice(0, 10);

  if (payload.inicio && hoy < payload.inicio) {
    throw new Error("La licencia aún no ha comenzado (inicio: " + payload.inicio + ").");
  }

  if (payload.expira && hoy > payload.expira) {
    throw new Error("La licencia venció el " + payload.expira + ".");
  }

  return true;
}

/* ---------- Verificar licencia al arrancar ---------- */
async function verificarLicencia() {
  const modal = document.getElementById("licenseModal");
  const statusText = document.getElementById("licenseStatusText");
  const badge = document.getElementById("licenseBadge");
  const cfgInfo = document.getElementById("cfgLicenciaInfo");

  mostrarDeviceId();

  const raw = localStorage.getItem(LICENSE_STORAGE_KEY);

  if (!raw) {
    if (statusText) statusText.textContent = "No hay licencia activa. Pegue el contenido del archivo .dat que le entregó el administrador.";
    if (modal) modal.style.display = "flex";
    if (badge) badge.textContent = "Sin licencia";
    if (cfgInfo) cfgInfo.textContent = "No hay licencia cargada.";
    return false;
  }

  try {
    const envelope = JSON.parse(raw);
    const payload = await verificarFirmaECDSA(envelope);
    validarPayload(payload);

    // Licencia válida
    if (modal) modal.style.display = "none";

    const diasRestantes = payload.expira
      ? Math.ceil((new Date(payload.expira) - new Date()) / (1000 * 60 * 60 * 24))
      : "—";

    if (badge) badge.textContent = typeof diasRestantes === "number" ? diasRestantes + " días" : "OK";

    if (cfgInfo) {
      cfgInfo.innerHTML =
        "<strong>Cliente:</strong> " + (payload.cliente || "—") + "<br>" +
        "<strong>Equipo:</strong> " + (payload.equipo || "—") + "<br>" +
        "<strong>Inicio:</strong> " + (payload.inicio || "—") + "<br>" +
        "<strong>Vence:</strong> " + (payload.expira || "—") +
        (typeof diasRestantes === "number" ? " (" + diasRestantes + " días restantes)" : "") + "<br>" +
        "<strong>ID licencia:</strong> " + (payload.idLicencia || "—");
    }
    return true;
  } catch (e) {
    const msg = e.message || "Error al verificar la licencia.";
    if (statusText) statusText.textContent = msg;
    if (modal) modal.style.display = "flex";
    if (badge) badge.textContent = "Error";
    if (cfgInfo) cfgInfo.textContent = msg;
    return false;
  }
}

/* ---------- Procesar y activar licencia (desde texto o archivo) ---------- */
async function procesarYActivarLicencia(contenido) {
  try {
    const limpio = String(contenido || "").replace(/^\uFEFF/, "").trim();
    if (!limpio) {
      alert("El contenido está vacío.\nPegue el texto completo del archivo .dat");
      return false;
    }

    let envelope;
    try {
      envelope = JSON.parse(limpio);
    } catch (e) {
      alert("El contenido no es un JSON válido.\nAsegúrese de copiar TODO el texto del archivo .dat");
      return false;
    }

    const payload = await verificarFirmaECDSA(envelope);
    validarPayload(payload);

    localStorage.setItem(LICENSE_STORAGE_KEY, limpio);
    alert(
      "Licencia activada correctamente.\n\n" +
      "Cliente: " + (payload.cliente || "—") + "\n" +
      "Vence: " + (payload.expira || "—")
    );
    location.reload();
    return true;
  } catch (err) {
    alert("Error: " + (err.message || "Licencia no válida."));
    return false;
  }
}

/** Cargar desde archivo (puede no funcionar en APKForge) */
function cargarLicencia(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (e) {
    procesarYActivarLicencia(e.target.result);
  };
  reader.readAsText(file);
  event.target.value = "";
}

/** Activar pegando el texto (método recomendado para APK) */
function activarLicenciaDesdeTexto(textareaId) {
  const id = textareaId || "licensePasteText";
  const textarea = document.getElementById(id);
  if (!textarea) {
    alert("Error interno: no se encontró el campo de texto.");
    return;
  }
  procesarYActivarLicencia(textarea.value);
}

// Exponer para uso global
window.activarLicenciaDesdeTexto = activarLicenciaDesdeTexto;
window.cargarLicencia = cargarLicencia;
window.verificarLicencia = verificarLicencia;
window.obtenerOCrearDeviceId = obtenerOCrearDeviceId;
