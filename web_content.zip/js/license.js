/* ControlMax Comercial - licencia firmada compatible con StockPro Admin v2 */
"use strict";

/*
  PASO OBLIGATORIO:
  Copia aquí el objeto JSON de CLAVE PÚBLICA que genera StockPro Admin.
  No copies la clave privada. La clave pública comienza con {"kty":"EC","crv":"P-256"...}
*/
const PUBLIC_KEY_JWK = null;

const LICENSE_STORAGE_KEY = "controlmax_comercial_license_v2";
const INSTALL_ID_KEY = "controlmax_install_id_v1";

function getInstallId(){
  let id = localStorage.getItem(INSTALL_ID_KEY);
  if(!id){
    const bytes = crypto.getRandomValues(new Uint8Array(8));
    id = "SP-" + Array.from(bytes,b=>b.toString(16).padStart(2,"0")).join("").toUpperCase();
    localStorage.setItem(INSTALL_ID_KEY,id);
  }
  return id;
}
function fromB64Url(value){
  let s = value.replace(/-/g,"+").replace(/_/g,"/");
  while(s.length%4) s += "=";
  const raw = atob(s);
  return Uint8Array.from(raw,c=>c.charCodeAt(0));
}
function decodeUtf8(bytes){ return new TextDecoder().decode(bytes); }
async function verifyLicense(envelope){
  if(!PUBLIC_KEY_JWK || !PUBLIC_KEY_JWK.x || !PUBLIC_KEY_JWK.y)
    throw new Error("Falta configurar la clave pública de StockPro Admin en js/license.js.");
  if(!envelope || envelope.formato !== "StockPro-Signed-License-v2" ||
     envelope.algoritmo !== "ECDSA-P256-SHA256" || !envelope.payload || !envelope.firma)
    throw new Error("El archivo no tiene el formato de licencia StockPro v2.");
  const payloadBytes = fromB64Url(envelope.payload);
  const signature = fromB64Url(envelope.firma);
  const key = await crypto.subtle.importKey("jwk",PUBLIC_KEY_JWK,
    {name:"ECDSA",namedCurve:"P-256"},false,["verify"]);
  const valid = await crypto.subtle.verify({name:"ECDSA",hash:"SHA-256"},key,signature,payloadBytes);
  if(!valid) throw new Error("Firma no válida. La licencia no fue emitida por tu generador autorizado.");
  const payload = JSON.parse(decodeUtf8(payloadBytes));
  if(payload.producto !== "StockPro Comercial") throw new Error("La licencia pertenece a otro producto.");
  if(payload.equipo !== getInstallId()) throw new Error("Esta licencia fue emitida para otro ID de instalación.");
  const today = new Date();
  const localToday = today.getFullYear()+"-"+String(today.getMonth()+1).padStart(2,"0")+"-"+String(today.getDate()).padStart(2,"0");
  if(!/^\d{4}-\d{2}-\d{2}$/.test(payload.inicio) || !/^\d{4}-\d{2}-\d{2}$/.test(payload.expira))
    throw new Error("Fechas de licencia incorrectas.");
  if(localToday < payload.inicio) throw new Error("La licencia todavía no está vigente. Inicio: "+payload.inicio);
  if(localToday >= payload.expira) throw new Error("La licencia venció el "+payload.expira+".");
  return payload;
}
function showStatus(message,ok){
  const el=document.getElementById("licenseStatus");
  el.textContent=message;
  el.className=ok?"ok":"";
}
async function activateFromFile(file){
  if(!file) throw new Error("Selecciona el archivo .dat que te entregó el administrador.");
  const envelope=JSON.parse(await file.text());
  const payload=await verifyLicense(envelope);
  localStorage.setItem(LICENSE_STORAGE_KEY,JSON.stringify(envelope));
  showApplication(payload);
}
function showApplication(payload){
  document.getElementById("licenseGate").hidden=true;
  document.getElementById("appContent").hidden=false;
  document.getElementById("licenseInfo").textContent=
    "Cliente: "+payload.cliente+" · Válida hasta: "+payload.expira;
}
async function initializeLicense(){
  document.getElementById("installId").value=getInstallId();
  document.getElementById("copyId").addEventListener("click",async()=>{
    const id=getInstallId();
    try{await navigator.clipboard.writeText(id);showStatus("ID copiado.",true);}
    catch(e){document.getElementById("installId").select();showStatus("Selecciona y copia el ID.",true);}
  });
  document.getElementById("activateBtn").addEventListener("click",async()=>{
    const btn=document.getElementById("activateBtn");btn.disabled=true;
    try{await activateFromFile(document.getElementById("licenseFile").files[0]);}
    catch(e){showStatus(e.message || "No se pudo validar la licencia.",false);}
    finally{btn.disabled=false;}
  });
  try{
    const saved=localStorage.getItem(LICENSE_STORAGE_KEY);
    if(saved){
      const payload=await verifyLicense(JSON.parse(saved));
      showApplication(payload);
    }
  }catch(e){
    localStorage.removeItem(LICENSE_STORAGE_KEY);
    showStatus("La activación guardada no es válida: "+e.message,false);
  }
}
document.addEventListener("DOMContentLoaded",initializeLicense);
