/**
 * StockPro - Sistema de Licencia Offline
 * Formato del archivo .dat: Base64 de un JSON con firma simple
 *
 * Estructura del JSON:
 * {
 *   "cliente": "Nombre del negocio",
 *   "expira": "2027-12-31",
 *   "plan": "12 meses",
 *   "emitido": "2026-10-31",
 *   "firma": "hash_simple"
 * }
 *
 * La "firma" es un hash simple para dificultar manipulación casual.
 * Para producción real se recomienda RSA, pero esto funciona offline y es práctico.
 */

const LICENSE_SECRET = "StockPro_Cuba_2026_Offline_Key_X7kP"; // Cambiar solo si regeneras todas las licencias

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16) + str.length.toString(16);
}

function generarFirma(data) {
  const payload = `${data.cliente}|${data.expira}|${data.plan}|${data.emitido}|${LICENSE_SECRET}`;
  return simpleHash(payload);
}

function verificarLicencia() {
  const raw = localStorage.getItem("stockpro_license");
  const modal = document.getElementById("licenseModal");
  const statusText = document.getElementById("licenseStatusText");
  const badge = document.getElementById("licenseBadge");
  const cfgInfo = document.getElementById("cfgLicenciaInfo");

  if (!raw) {
    statusText.textContent = "No hay licencia activa. Cargue el archivo .dat que le entregó el administrador.";
    modal.style.display = "flex";
    if (badge) badge.textContent = "Sin licencia";
    if (cfgInfo) cfgInfo.textContent = "No hay licencia cargada.";
    return false;
  }

  try {
    const licencia = JSON.parse(atob(raw));
    const firmaEsperada = generarFirma(licencia);

    if (licencia.firma !== firmaEsperada) {
      statusText.textContent = "Licencia inválida o manipulada. Solicite un nuevo archivo al administrador.";
      modal.style.display = "flex";
      if (badge) badge.textContent = "Inválida";
      if (cfgInfo) cfgInfo.textContent = "Licencia inválida (firma incorrecta).";
      return false;
    }

    const hoy = new Date().toISOString().slice(0, 10);

    if (hoy > licencia.expira) {
      statusText.textContent = `Su licencia venció el ${licencia.expira}. Contacte al administrador para renovar (planes de 1, 3, 6 o 12 meses).`;
      modal.style.display = "flex";
      if (badge) badge.textContent = "Vencida";
      if (cfgInfo) cfgInfo.textContent = `Licencia vencida el ${licencia.expira}. Cliente: ${licencia.cliente}`;
      return false;
    }

    // Licencia válida
    modal.style.display = "none";
    const diasRestantes = Math.ceil((new Date(licencia.expira) - new Date()) / (1000 * 60 * 60 * 24));
    if (badge) badge.textContent = `${diasRestantes} días`;
    if (cfgInfo) {
      cfgInfo.innerHTML = `
        <strong>Cliente:</strong> ${licencia.cliente}<br>
        <strong>Plan:</strong> ${licencia.plan}<br>
        <strong>Vence:</strong> ${licencia.expira} (${diasRestantes} días restantes)<br>
        <strong>Emitida:</strong> ${licencia.emitido || "—"}
      `;
    }
    return true;
  } catch (e) {
    statusText.textContent = "El archivo de licencia está corrupto o no es válido.";
    modal.style.display = "flex";
    if (badge) badge.textContent = "Error";
    if (cfgInfo) cfgInfo.textContent = "Error al leer la licencia.";
    return false;
  }
}

/**
 * Procesa y activa una licencia a partir de su contenido (texto Base64).
 * Usado tanto por el input file como por el pegado manual.
 */
function procesarYActivarLicencia(contenido) {
  try {
    const limpio = String(contenido || "").replace(/^\uFEFF/, "").trim();
    if (!limpio) {
      alert("❌ El contenido está vacío. Pegue o seleccione una licencia válida.");
      return false;
    }

    // Intentar decodificar Base64 → JSON
    const decoded = atob(limpio);
    const licencia = JSON.parse(decoded);

    // Verificar firma
    const firmaEsperada = generarFirma(licencia);
    if (licencia.firma !== firmaEsperada) {
      alert("❌ Licencia inválida: la firma no coincide.\nSolicite un archivo válido al administrador.");
      return false;
    }

    const hoy = new Date().toISOString().slice(0, 10);
    if (hoy > licencia.expira) {
      alert("⚠️ Esta licencia ya está vencida (" + licencia.expira + ").\nSe guardará igual para que vea el estado.");
    }

    localStorage.setItem("stockpro_license", limpio);
    alert("✅ Licencia cargada correctamente.\nCliente: " + licencia.cliente + "\nVence: " + licencia.expira);
    location.reload();
    return true;
  } catch (err) {
    alert("❌ Error: El contenido no es una licencia válida.\nAsegúrese de copiar el texto completo del archivo .dat.");
    return false;
  }
}

/**
 * Cargar licencia desde archivo (input type=file).
 * En muchos APK (APKForge) este método no abre el selector de archivos.
 */
function cargarLicencia(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (e) {
    procesarYActivarLicencia(e.target.result);
  };
  reader.readAsText(file);
  // Limpiar input para poder cargar el mismo archivo de nuevo
  event.target.value = "";
}

/**
 * Activar licencia pegando el texto (método recomendado para APKForge).
 * @param {string} [textareaId] - ID del textarea (por defecto el del modal)
 */
function activarLicenciaDesdeTexto(textareaId) {
  const id = textareaId || "licensePasteText";
  const textarea = document.getElementById(id);
  if (!textarea) {
    alert("Error interno: no se encontró el campo de texto.");
    return;
  }
  procesarYActivarLicencia(textarea.value);
}

/**
 * Función auxiliar para QUE TÚ generes licencias.
 * Ábrela en la consola del navegador o úsala en una herramienta aparte.
 *
 * Ejemplo:
 * generarLicenciaArchivo("Bodega El Sol", "2027-04-30", "6 meses")
 */
function generarLicenciaArchivo(cliente, expira, plan) {
  const data = {
    cliente: cliente,
    expira: expira,
    plan: plan,
    emitido: new Date().toISOString().slice(0, 10),
    firma: ""
  };
  data.firma = generarFirma(data);
  const encoded = btoa(JSON.stringify(data));
  console.log("=== LICENCIA GENERADA ===");
  console.log(encoded);
  console.log("=========================");
  // Descargar automáticamente
  const blob = new Blob([encoded], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `licencia_${cliente.replace(/\s+/g, "_")}_${expira}.dat`;
  a.click();
  return encoded;
}

// Exponer para uso del administrador
window.generarLicenciaArchivo = generarLicenciaArchivo;
