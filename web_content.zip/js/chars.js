'use strict';
/* ---------- characters, abilities, emotes, loot pickup ---------- */
const U=32,SHR=78; // 1 meter ~ 32px
const CH=[
 {id:'alok',n:'Alok',em:'🎧',ab:'ड्रॉप द बीट',cd:45,desc:'5 मीटर का ऑरा 10 सेकंड: खुद और टीममेट की स्पीड +15%, हर सेकंड +5 HP (कुल 50 HP)',look:{skin:'#c68b63',top:'#7a4bd6',top2:'#ffd34d',pants:'#2c2a4a',shoes:'#ffd34d',hair:'#111',hat:'cap',hatc:'#ffd34d',glass:true}},
 {id:'chrono',n:'Chrono',em:'🛡️',ab:'फ़ोर्स फ़ील्ड',cd:40,desc:'एनर्जी शील्ड 5 सेकंड, 800 डैमेज सोखता है। शील्ड के अंदर से बाहर फायरिंग नहीं हो सकती',look:{skin:'#e8c4a0',top:'#1c5cff',top2:'#6fe9ff',pants:'#1b2a55',shoes:'#cfd8e6',hair:'#222',hat:'helmet',hatc:'#cfd8e6',mask:'visor',glow:'#6fe9ff'}},
 {id:'wukong',n:'Wukong',em:'🐵',ab:'झाड़ी रूप',cd:35,desc:'10 सेकंड के लिए झाड़ी बन जाओ (स्पीड -10%)। फायर करते ही रूप ख़त्म',look:{skin:'#c68b63',top:'#c9382c',top2:'#ffd34d',pants:'#8a2a1f',shoes:'#ffd34d',hair:'#5a3b1e',hat:'crown',hatc:'#ffd34d'}},
 {id:'skyler',n:'Skyler',em:'🎤',ab:'साउंड वेव',cd:30,desc:'आगे साउंड वेव छोड़ता है जो ग्लू वॉल तोड़ देती है (वेव 6 सेकंड तक चलती है)',look:{skin:'#f0c9a8',top:'#ff6fae',top2:'#ffffff',pants:'#3a2a6a',shoes:'#ff6fae',hair:'#ff6fae',hat:'phones',hatc:'#222'}},
 {id:'tatsuya',n:'Tatsuya',em:'🥷',ab:'शैडो डैश',cd:12,desc:'आगे तेज़ डैश (0.25 सेकंड), 2 चार्ज जमा हो सकते हैं',look:{skin:'#e8b690',top:'#1f1f27',top2:'#ff5d6c',pants:'#15151a',shoes:'#ff5d6c',hair:'#111',hat:'bandana',hatc:'#ff5d6c',mask:'ninja'}},
 {id:'oscar',n:'Oscar',em:'💪',ab:'बुल रश',cd:25,desc:'सीधी दिशा में डैश: रास्ते की ग्लू वॉल टूटती है, दुश्मन को डैमेज और धक्का',look:{skin:'#a8734a',top:'#e07a1f',top2:'#222222',pants:'#2e2a26',shoes:'#222',hair:'#111',hat:'none',mask:'bandit'}},
 {id:'ryden',n:'Ryden',em:'🕷️',ab:'मैकेनिकल स्पाइडर',cd:40,desc:'रोबोट स्पाइडर (60 सेकंड तक) दुश्मन ढूँढकर पकड़ता है: स्पीड -80% और ब्लीडिंग 4-5 सेकंड',look:{skin:'#d9b08c',top:'#2b2f3a',top2:'#2dffd0',pants:'#1a1d26',shoes:'#2dffd0',hair:'#111',hat:'hood',hatc:'#2b2f3a',mask:'visor',glow:'#2dffd0'}},
 {id:'santino',n:'Santino',em:'🎩',ab:'मैनिकिन',cd:35,desc:'आगे मैनिकिन (25 सेकंड) बनाता है। 3 सेकंड में दोबारा दबाओ तो उसकी जगह टेलीपोर्ट',look:{skin:'#e3b08a',top:'#f2f2f2',top2:'#c9a227',pants:'#15151a',shoes:'#c9a227',hair:'#3a1c0f',hat:'tophat',hatc:'#111'}},
 {id:'agni',n:'Agni',em:'🔥',ab:'फ़ायर रिंग',cd:35,desc:'ज़मीन पर आग का घेरा 6 सेकंड: अंदर खड़े दुश्मनों को लगातार डैमेज',look:{skin:'#b97c50',top:'#ff6a1f',top2:'#ffd36b',pants:'#4a1a0f',shoes:'#ffd36b',hair:'#ff3d1f',hat:'topknot',hatc:'#ff3d1f',glow:'#ff8a1f'}},
 {id:'tara',n:'Tara',em:'📡',ab:'सैटेलाइट रडार',cd:40,desc:'8 सेकंड तक सारे दुश्मन मिनी-मैप पर लाल दिखते हैं',look:{skin:'#f0c9a8',top:'#1fb5a3',top2:'#e9fffb',pants:'#1d3d52',shoes:'#e9fffb',hair:'#2a1a10',hat:'cap',hatc:'#1fb5a3',glass:true}}
];
const CHL={};CH.forEach(c=>CHL[c.id]=c);
const _cl={};
function charLook(id){const c=CHL[id]||CH[0];return _cl[c.id]||(_cl[c.id]=Object.assign({id:'ch_'+c.id,n:c.n,r:2,c:'g',p:0,cat:'o'},c.look))}
function myLook(){return prof.eq.o&&prof.eq.o!=='o0'&&ITEMS[prof.eq.o]?ITEMS[prof.eq.o]:charLook(prof.ch)}
function botLook(){return Math.random()<.5?pick(OUT):charLook(pick(CH).id)}
const EMO=[{e:'😂',t:'हा हा हा!'},{e:'💃',t:'नाच मेरी जान'},{e:'😎',t:'मैं हूँ डॉन'},{e:'🤡',t:'जोकर मोड ON'},{e:'😭',t:'ये क्या हो गया'},{e:'🙏',t:'माफ़ करना भाई'},{e:'🥱',t:'बहुत बोर है'},{e:'🔥',t:'आग लगा दी!'},{e:'🕺',t:'भांगड़ा पाओ'},{e:'🤪',t:'पागल हो गया'}];
const NEWL={helmet:{e:'👷',c:'#6fb7ff',n:'हेलमेट'},energy:{e:'🥤',c:'#7bd88f',n:'एनर्जी ड्रिंक'},adren:{e:'💉',c:'#ff5d6c',n:'एड्रेनालाइन'},ammobox:{e:'📦',c:'#ffd36b',n:'गोलियों का बॉक्स'},coin:{e:'💰',c:'#ffd34d',n:'सोने का सिक्का'},cell:{e:'🔋',c:'#b27cff',n:'एनर्जी सेल'}};
const NEWK=['helmet','helmet','energy','energy','adren','ammobox','coin','cell'];
const LOOTN={ammo:'गोलियाँ',bandage:'बैंडेज',medkit:'मेडकिट',grenade:'ग्रेनेड',smoke:'स्मोक',gloo:'ग्लू वॉल',vest:'बुलेटप्रूफ वेस्ट'};
const lootName=t=>WP[t]?WP[t].n:NEWL[t]?NEWL[t].n:LOOTN[t]||t;
let waves=[],spiders=[],fires=[],pickCand=null,lobbyEmo=null;

/* ---------- abilities ---------- */
const AB={
  alok:p=>{p.aura=10},
  chrono:p=>{p.shield={t:5,hp:800}},
  wukong:p=>{p.camo=10},
  skyler:p=>{waves.push({x:p.x+Math.cos(p.ang)*20,y:p.y+Math.sin(p.ang)*20,a:p.ang,t:6,fl:p.fl|0,team:p.team,owner:p,hit:new Set()})},
  tatsuya:p=>{p.dash={t:.25,vx:Math.cos(p.ang)*900,vy:Math.sin(p.ang)*900}},
  oscar:p=>{p.dash={t:.2,vx:Math.cos(p.ang)*1500,vy:Math.sin(p.ang)*1500,oscar:true,hit:new Set()}},
  ryden:p=>{spiders.push({x:p.x,y:p.y,r:8,fl:p.fl|0,team:p.team,owner:p,t:60,ph:0})},
  santino:p=>{let x=p.x+Math.cos(p.ang)*110,y=p.y+Math.sin(p.ang)*110;if(blocked(x,y,p.fl))[x,y]=[p.x,p.y];p.mq={x,y,t:25,tpT:3};toast('मैनिकिन बना — 3 सेकंड में दोबारा दबाओ = टेलीपोर्ट')},
  agni:p=>{fires.push({x:p.x,y:p.y,r:120,t:6,fl:p.fl|0,team:p.team,owner:p,acc:0})},
  tara:p=>{p.radarT=8}
};
function useAbility(p){
  p=p||player;if(!p||!p.alive||state!=='play')return;
  const c=CHL[p.ch];if(!c)return;
  if(p.ch==='tatsuya'){if((p.abCh|0)<=0){toast('डैश चार्ज नहीं है');return}AB.tatsuya(p);p.abCh--;if(!(p.abRec>0))p.abRec=c.cd;snd('click');return}
  if(p.ch==='santino'&&p.mq&&p.mq.tpT>0){p.x=p.mq.x;p.y=p.mq.y;fix(p);spark(p.x,p.y,'#c9a227',18);p.mq.tpT=0;toast('टेलीपोर्ट!');return}
  if(p.abCd>0){toast(c.ab+': '+Math.ceil(p.abCd)+' सेकंड में तैयार');return}
  AB[p.ch](p);p.abCd=c.cd;snd('click');toast(c.em+' '+c.ab);
}
function resetAbil(){
  waves=[];spiders=[];fires=[];pickCand=null;
  for(const p of players){p.ch='';p.abCd=0;p.abSpd=1}
  player.ch=prof.ch;player.abCh=2;player.abRec=0;
  const c=CHL[player.ch]||CH[0];player.ch=c.id;
  $('bSkill').innerHTML='<b class="em">'+c.em+'</b><i class="bd"></i><span class="cdt"></span>';
}
function updAbilities(dt){
  if(state!=='play'&&state!=='done')return;
  for(const p of players)p.abSpd=1;
  for(const p of players){
    if(!p.alive)continue;
    if(p.emo){p.emo.t-=dt;if(p.emo.t<=0)p.emo=null}
    if(p.abCd>0)p.abCd-=dt;
    if(p.ch==='tatsuya'&&p.abRec>0){p.abRec-=dt;if(p.abRec<=0&&p.abCh<2){p.abCh++;if(p.abCh<2)p.abRec=CHL.tatsuya.cd}}
    if(p.camo>0){p.camo-=dt;p.abSpd*=.9}
    if(p.shield){p.shield.t-=dt;if(p.shield.t<=0||p.shield.hp<=0){spark(p.x,p.y,'#8fd8ff',14);p.shield=null}}
    if(p.spdT>0){p.spdT-=dt;p.abSpd*=1.3}
    if(p.slowT>0){p.slowT-=dt;p.abSpd*=.2}
    if(p.bleedT>0){p.bleedT-=dt;p.bleedAcc=(p.bleedAcc||0)+dt;if(p.bleedAcc>=1){p.bleedAcc-=1;hurtP(p,5,p.bleedSrc)}}
    if(p.radarT>0)p.radarT-=dt;
    if(p.mq){p.mq.t-=dt;p.mq.tpT-=dt;if(p.mq.t<=0)p.mq=null}
    if(p.aura>0){p.aura-=dt;for(const q of players)if(q.alive&&q.team===p.team&&(q.fl|0)===(p.fl|0)&&Math.hypot(q.x-p.x,q.y-p.y)<5*U){q.abSpd*=1.15;if(q.hp<100)q.hp=Math.min(100,q.hp+5*dt)}}
    const d=p.dash;
    if(d){
      d.t-=dt;const sx=d.vx*dt,sy=d.vy*dt,n=Math.max(1,Math.ceil(Math.hypot(sx,sy)/10));
      for(let i=0;i<n;i++){
        p.x+=sx/n;fix(p);p.y+=sy/n;fix(p);
        if(d.oscar){
          for(let j=glooW.length-1;j>=0;j--){const w=glooW[j];if((w.fl|0)===(p.fl|0)&&Math.hypot(w.x-p.x,w.y-p.y)<58){spark(w.x,w.y,w.col,10);glooW.splice(j,1)}}
          for(const q of players)if(q.alive&&q.team!==p.team&&!d.hit.has(q)&&(q.fl|0)===(p.fl|0)&&Math.hypot(q.x-p.x,q.y-p.y)<36){d.hit.add(q);hurtP(q,25,p);const a=Math.atan2(q.y-p.y,q.x-p.x);q.x+=Math.cos(a)*70;q.y+=Math.sin(a)*70;fix(q)}
        }
      }
      spark(p.x,p.y,d.oscar?'#e07a1f':'#ff5d6c',2);
      if(d.t<=0)p.dash=null;
    }
  }
  for(let i=waves.length-1;i>=0;i--){
    const w=waves[i];w.t-=dt;w.x+=Math.cos(w.a)*230*dt;w.y+=Math.sin(w.a)*230*dt;
    for(let j=glooW.length-1;j>=0;j--){const g=glooW[j];if((g.fl|0)===w.fl&&Math.hypot(g.x-w.x,g.y-w.y)<62){spark(g.x,g.y,g.col,12);glooW.splice(j,1)}}
    for(const q of players)if(q.alive&&q.team!==w.team&&(q.fl|0)===w.fl&&!w.hit.has(q)&&Math.hypot(q.x-w.x,q.y-w.y)<50){w.hit.add(q);hurtP(q,10,w.owner)}
    if(w.t<=0||blocked(w.x,w.y,w.fl))waves.splice(i,1);
  }
  for(let i=fires.length-1;i>=0;i--){
    const f=fires[i];f.t-=dt;f.acc+=dt;
    if(f.acc>=.5){f.acc-=.5;for(const q of players)if(q.alive&&q.team!==f.team&&(q.fl|0)===f.fl&&Math.hypot(q.x-f.x,q.y-f.y)<f.r)hurtP(q,7,f.owner)}
    if(f.t<=0)fires.splice(i,1);
  }
  for(let i=spiders.length-1;i>=0;i--){
    const s=spiders[i];s.t-=dt;s.ph+=dt;let best=null,bd=900;
    for(const q of players)if(q.alive&&q.team!==s.team&&(q.fl|0)===s.fl){const d=Math.hypot(q.x-s.x,q.y-s.y);if(d<bd){bd=d;best=q}}
    if(best){
      if(bd<20){best.slowT=4.5;best.bleedT=4.5;best.bleedAcc=0;best.bleedSrc=s.owner;spark(best.x,best.y,'#ff5d6c',10);if(best===player)toast('🕷️ स्पाइडर ने पकड़ लिया!');spiders.splice(i,1);continue}
      const a=Math.atan2(best.y-s.y,best.x-s.x);s.x+=Math.cos(a)*150*dt;fix(s);s.y+=Math.sin(a)*150*dt;fix(s);s.a=a;
    }
    if(s.t<=0)spiders.splice(i,1);
  }
  if(state==='play')findPick();
}
function shieldHit(b){
  for(const p of players){
    const s=p.shield;if(!s||!p.alive||(p.fl|0)!==(b.fl|0))continue;
    if(Math.abs(Math.hypot(b.x-p.x,b.y-p.y)-SHR)<6){s.hp-=b.d;spark(b.x,b.y,'#8fd8ff',4);return true}
  }
  return false;
}

/* ---------- emotes ---------- */
function doEmote(p,i){p.emo={i,t:2.8};if(p===player)snd('click')}
function toggleEmo(){const e=$('emoW');e.hidden=!e.hidden}
function playLobbyEmo(i){lobbyEmo={i,t:3};snd('click')}
function drawBubble(c,x,y,e,sc){
  sc=sc||1;c.save();c.translate(x,y);c.scale(sc,sc);
  c.font='600 10px Hind,system-ui,sans-serif';const w=Math.max(56,c.measureText(e.t).width+18);
  c.fillStyle='rgba(255,255,255,.96)';rr(c,-w/2,-32,w,38,9);c.fill();c.beginPath();c.moveTo(-5,5);c.lineTo(0,12);c.lineTo(5,5);c.fill();
  c.textAlign='center';c.font='20px sans-serif';c.fillStyle='#000';c.fillText(e.e,0,-11);
  c.font='600 10px Hind,system-ui,sans-serif';c.fillStyle='#222';c.fillText(e.t,0,2);c.restore();
}
function lobbyBounce(sc){const e=lobbyEmo;if(!e)return[0,0];return[Math.sin(lobbyT*14)*sc*.35,-Math.abs(Math.sin(lobbyT*9))*sc*2.2]}
function lobbyExtra(w,hh,cy,sc,dt){
  if(lobbyEmo){lobbyEmo.t-=dt;if(lobbyEmo.t<=0)lobbyEmo=null}
  if(lobbyEmo)drawBubble(lx,w/2,cy-sc*50,EMO[lobbyEmo.i],Math.max(1,sc/3.2));
  const c=CHL[prof.ch]||CH[0];lx.textAlign='left';
  lx.font='700 '+Math.max(15,sc*4.4)+'px Rajdhani,Hind,system-ui,sans-serif';lx.fillStyle='#ffb347';lx.fillText(c.em+' '+c.n,w/2+sc*27,cy-sc*34);
  lx.font='500 '+Math.max(11,sc*2.8)+'px Hind,system-ui,sans-serif';lx.fillStyle='#e6ebf2';lx.fillText(c.ab,w/2+sc*27,cy-sc*28);
  lx.fillStyle='rgba(230,235,242,.55)';lx.fillText('किरदार पर टैप = इमोट',w/2+sc*27,cy-sc*22);
  const L=$('lchar');L.style.left=(w/2-sc*24)+'px';L.style.top=(cy-sc*54)+'px';L.style.width=(sc*48)+'px';L.style.height=(sc*58)+'px';
}

/* ---------- gates, bush, FX drawing ---------- */
function drawGates(hs){
  const c=ctx,a=.32+.2*Math.sin(time*5);
  for(const g of hs.gates||[]){
    const hz=g.hz,w=hz?62:16,h=hz?16:62;
    c.fillStyle='rgba(255,40,40,'+a+')';c.fillRect(g.x-w/2,g.y-h/2,w,h);
    c.strokeStyle='#ff3b3b';c.lineWidth=2;c.strokeRect(g.x-w/2,g.y-h/2,w,h);
    c.fillStyle='#ff3b3b';c.beginPath();c.arc(hz?g.x-w/2:g.x,hz?g.y:g.y-h/2,4,0,TAU);c.arc(hz?g.x+w/2:g.x,hz?g.y:g.y+h/2,4,0,TAU);c.fill();
    c.font='700 9px Hind,system-ui,sans-serif';c.textAlign='center';c.lineWidth=3;c.strokeStyle='rgba(0,0,0,.7)';
    const ty=hz?g.y-12:g.y-h/2-5;c.strokeText('गेट',g.x,ty);c.fillStyle='#ff6b6b';c.fillText('गेट',g.x,ty);
  }
}
function drawBush(c,x,y){
  const sw=Math.sin(time*3)*1.2;
  c.fillStyle='rgba(0,0,0,.28)';c.beginPath();c.ellipse(x+2,y+1,15,6,0,0,TAU);c.fill();
  const bl=[[-9,-12,11,'#2f7d3a'],[9,-12,11,'#2f7d3a'],[0,-22,12,'#3a9447'],[-6,-30,9,'#43a853'],[7,-29,9,'#3a9447'],[0,-14,12,'#348a41']];
  for(const [dx,dy,r,col] of bl){c.fillStyle=col;c.beginPath();c.arc(x+dx+sw*(-dy/30),y+dy,r,0,TAU);c.fill()}
  c.fillStyle='rgba(255,255,255,.18)';c.beginPath();c.arc(x-3,y-28,4,0,TAU);c.fill();
}
function drawPlayerBody(c,p,op,isMe){
  if(p.aura>0){c.fillStyle='rgba(120,255,160,'+(.12+Math.sin(time*5)*.04)+')';c.beginPath();c.arc(p.x,p.y,5*U,0,TAU);c.fill();c.strokeStyle='rgba(120,255,160,.6)';c.lineWidth=2;c.stroke()}
  const e=p.emo,eo=e&&e.t>0,bx=eo?Math.sin(e.t*14)*3:0,by=eo?-Math.abs(Math.sin(e.t*9))*7:0;
  if(p.camo>0){c.globalAlpha=isMe?.6:1;drawBush(c,p.x,p.y);c.globalAlpha=1}
  else drawChar(c,p.out,p.x+bx,p.y+by,1,p.ang,p.wt,op);
  if(p.shield){const s=p.shield;c.fillStyle='rgba(90,170,255,'+(.14+.1*Math.sin(time*6))+')';c.beginPath();c.arc(p.x,p.y,SHR,0,TAU);c.fill();c.strokeStyle='rgba(140,210,255,.9)';c.lineWidth=3;c.stroke();
    c.fillStyle='#fff';c.font='700 10px sans-serif';c.textAlign='center';c.fillText(Math.max(0,Math.ceil(s.hp)),p.x,p.y-SHR-4)}
  if(eo)drawBubble(c,p.x,p.y-78,EMO[e.i]);
}
function drawAbilityFx(f){
  const c=ctx,off=fl=>-(fl|0)*FH;
  for(const g of fires){c.save();c.translate(0,off(g.fl));const k=g.t/6;
    const gr=c.createRadialGradient(g.x,g.y,10,g.x,g.y,g.r);gr.addColorStop(0,'rgba(255,200,60,.5)');gr.addColorStop(1,'rgba(255,70,20,.15)');
    c.fillStyle=gr;c.beginPath();c.arc(g.x,g.y,g.r,0,TAU);c.fill();c.strokeStyle='rgba(255,120,30,.9)';c.lineWidth=3;c.stroke();
    for(let i=0;i<9;i++){const a=i/9*TAU+time*.8,r=g.r*(.35+.55*((i*37)%10)/10),fx=g.x+Math.cos(a)*r,fy=g.y+Math.sin(a)*r*.9,h=10+6*Math.sin(time*9+i);
      c.fillStyle=i%2?'#ffb347':'#ff6a1f';c.beginPath();c.moveTo(fx-4,fy);c.quadraticCurveTo(fx,fy-h*1.6,fx+4,fy);c.fill()}
    c.restore()}
  for(const w of waves){c.save();c.translate(0,off(w.fl));c.strokeStyle='rgba(255,111,174,.85)';c.lineWidth=3;
    for(let i=0;i<3;i++){c.globalAlpha=.8-i*.22;c.beginPath();c.arc(w.x-Math.cos(w.a)*i*16,w.y-Math.sin(w.a)*i*16,26+i*8,w.a-1,w.a+1);c.stroke()}c.restore()}
  for(const s of spiders){c.save();c.translate(s.x,s.y+off(s.fl));c.rotate(s.a||0);
    c.strokeStyle='#cfd8e6';c.lineWidth=1.6;for(let i=-1;i<=1;i+=2)for(let j=0;j<3;j++){const a=Math.sin(s.ph*14+j*2)*.4;c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(1.2+j*.5+a)*10,i*Math.sin(1.2+j*.5+a)*10);c.stroke()}
    c.fillStyle='#2dffd0';c.beginPath();c.ellipse(0,0,7,5,0,0,TAU);c.fill();c.fillStyle='#ff3b3b';c.fillRect(3,-1.5,2,3);c.restore()}
  for(const p of players){const m=p.mq;if(!m||!p.alive)continue;
    c.save();c.translate(0,off(p.fl));c.globalAlpha=.85;drawChar(c,{skin:'#cfcfcf',top:'#b5b5b5',top2:'#d9d9d9',pants:'#9a9a9a',shoes:'#777',hair:'#aaa',hat:'none'},m.x,m.y,1,.6,0,{front:true});c.globalAlpha=1;
    if(m.tpT>0){c.strokeStyle='#ffd34d';c.setLineDash([5,4]);c.lineWidth=2;c.beginPath();c.arc(m.x,m.y,20,0,TAU);c.stroke();c.setLineDash([]);c.fillStyle='#ffd34d';c.font='700 10px sans-serif';c.textAlign='center';c.fillText('TP '+Math.ceil(m.tpT),m.x,m.y-58)}
    c.restore()}
}

/* ---------- loot pickup ---------- */
function findPick(){
  if(!player||!player.alive){pickCand=null;return}
  let best=null,bd=40*40;
  for(const l of loot){const dx=l.x-player.x,dy=l.y-player.y,d=dx*dx+dy*dy;if(d<bd&&(l.fl|0)===(player.fl|0)){bd=d;best=l}}
  pickCand=best;
}
function doPick(){
  if(!pickCand||!player.alive)return;
  const i=loot.indexOf(pickCand);if(i<0)return;
  if(take(player,pickCand)){loot.splice(i,1);snd('pick')}else toast('अभी ज़रूरत नहीं / भरा हुआ है');
}
const _hc={};
function skillHud(){
  const p=player;if(!p)return;
  const c=CHL[p.ch],e=$('bSkill');
  if(c&&e){
    let f=p.abCd>0?Math.min(1,p.abCd/c.cd):0,t=p.abCd>0?String(Math.ceil(p.abCd)):'';
    if(p.ch==='tatsuya'){f=p.abCh>0?0:Math.min(1,(p.abRec||0)/c.cd);t=p.abCh>0?'':String(Math.ceil(p.abRec||0))}
    if(p.ch==='santino'&&p.mq&&p.mq.tpT>0){f=0;t='TP'}
    e.style.setProperty('--cd',f);
    const sp=e.querySelector('.cdt'),bd=e.querySelector('.bd');
    if(sp&&_hc.t!==t){_hc.t=t;sp.textContent=t}
    if(bd){const b=p.ch==='tatsuya'?String(p.abCh):'';if(_hc.b!==b){_hc.b=b;bd.textContent=b;bd.style.display=b?'':'none'}}
  }
  const pb=$('bPick'),show=!!pickCand&&p.alive;
  if(show){const l=pickCand,s=lootName(l.t)+((l.q||1)>1?' ×'+l.q:'');if(_hc.p!==s){_hc.p=s;pb.querySelector('span').textContent=s}}
  if(pb.hidden===show)pb.hidden=!show;
}

/* ---------- character panel ---------- */
function pChar(){
  const w=h('div');
  w.append(tabs('char',[['ch','किरदार (एबिलिटी)'],['out','आउटफ़िट']],'ch'));
  if((ptab.char||'ch')==='out'){w.append(pOut());return w}
  const cur=CHL[prof.ch]||CH[0],sp=h('div',{class:'split'});
  sp.append(h('div',{class:'bigpv',style:'--rc:#ffb347;flex:0 0 220px;width:220px'},pv(charLook(cur.id),180,230),h('b',null,cur.em+' '+cur.n),h('small',null,cur.ab+' · कूलडाउन '+cur.cd+'s'),h('small',{class:'dim'},cur.desc)));
  sp.append(h('div',null,h('p',{class:'dim'},'अपना किरदार चुनो — हर किरदार की अलग एबिलिटी है। मैच में E दबाओ या एबिलिटी बटन। (अगर कोई आउटफ़िट लगा है तो लुक वही दिखेगा, एबिलिटी इसी किरदार की रहेगी)'),
    h('div',{class:'grid'},CH.map(c=>{const sel=prof.ch===c.id;
      return h('div',{class:'it'+(sel?' eq':''),style:'--rc:#ffb347'},pv(charLook(c.id),96,110),h('b',null,c.em+' '+c.n),h('small',null,c.ab),h('small',{class:'dim'},c.desc),
        h('button',{class:'sm'+(sel?' on':''),onclick:()=>{prof.ch=c.id;save();snd('click');render()}},sel?'चुना हुआ':'चुनो'))}))));
  w.append(sp);return w;
}

/* ---------- init ---------- */
(function(){
  $('bEmo').innerHTML='<b class="em">😀</b>';
  const wh=$('emoW');EMO.forEach((e,i)=>{const b=document.createElement('button');b.innerHTML='<b>'+e.e+'</b><small>'+e.t+'</small>';b.addEventListener('pointerdown',ev=>{ev.preventDefault();if(state==='play'&&player.alive)doEmote(player,i);wh.hidden=true});wh.append(b)});
  const lm=$('lemo');EMO.forEach((e,i)=>{const b=document.createElement('button');b.innerHTML='<b>'+e.e+'</b><small>'+e.t+'</small>';b.onclick=()=>playLobbyEmo(i);lm.append(b)});
  $('lchar').onclick=()=>{lm.hidden=!lm.hidden};
  $('bPick').addEventListener('pointerdown',e=>{e.preventDefault();doPick()});
  addEventListener('keydown',e=>{if(state!=='play'||!player.alive)return;const k=e.key.toLowerCase();if(k==='e')useAbility(player);else if(k==='f')doPick();else if(k==='v')toggleEmo()});
})();
