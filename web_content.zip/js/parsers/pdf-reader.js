// ============================================================
// PURE JS PDF PARSER — no external library, no network calls.
// Uses native browser DecompressionStream for FlateDecode inflate.
// ============================================================

function bytesToLatin1(bytes){ return new TextDecoder('latin1').decode(bytes); }

function findDictEnd(text, start){
  let depth = 0, i = start;
  while (i < text.length) {
    if (text[i] === '<' && text[i+1] === '<') { depth++; i += 2; continue; }
    if (text[i] === '>' && text[i+1] === '>') { depth--; i += 2; if (depth === 0) return i; continue; }
    i++;
  }
  return i;
}

function parsePdfStructure(text){
  const sxIdx = text.lastIndexOf('startxref');
  if (sxIdx === -1) throw new Error('no startxref');
  const m = /startxref\s+(\d+)/.exec(text.slice(sxIdx, sxIdx+40));
  if (!m) throw new Error('bad startxref');
  const offsets = new Map();
  const visited = new Set();
  function parseXrefAt(offset){
    if (visited.has(offset)) return null;
    visited.add(offset);
    if (!/^\s*xref/.test(text.slice(offset, offset+40))) return null;
    let i = text.indexOf('xref', offset) + 4;
    while (true) {
      while (/\s/.test(text[i])) i++;
      if (text.startsWith('trailer', i)) { i += 7; break; }
      const subM = /^(\d+)\s+(\d+)/.exec(text.slice(i, i+40));
      if (!subM) break;
      const start = parseInt(subM[1],10), count = parseInt(subM[2],10);
      i += subM[0].length;
      while (/\s/.test(text[i])) i++;
      for (let k = 0; k < count; k++) {
        const entry = text.slice(i, i+20);
        const em = /^(\d{10})\s(\d{5})\s([nf])/.exec(entry);
        if (em && em[3] === 'n') { const objNum = start+k; if (!offsets.has(objNum)) offsets.set(objNum, parseInt(em[1],10)); }
        i += 20;
      }
    }
    while (/\s/.test(text[i])) i++;
    if (text[i] === '<' && text[i+1] === '<') {
      const dictEnd = findDictEnd(text, i);
      const dictStr = text.slice(i, dictEnd);
      const prevM = /\/Prev\s+(\d+)/.exec(dictStr);
      const rootM = /\/Root\s+(\d+)\s+\d+\s+R/.exec(dictStr);
      if (prevM) parseXrefAt(parseInt(prevM[1],10));
      return rootM ? parseInt(rootM[1],10) : null;
    }
    return null;
  }
  const rootRef = parseXrefAt(parseInt(m[1],10));
  return { offsets, rootRef };
}

function getObjectRaw(text, offsets, objNum){
  const off = offsets.get(objNum);
  if (off === undefined) return null;
  const hdrM = /(\d+)\s+(\d+)\s+obj/.exec(text.slice(off, off+40));
  if (!hdrM) return null;
  let i = off + hdrM[0].length;
  while (/\s/.test(text[i])) i++;
  let dictStr = null, dictEnd = i;
  if (text[i] === '<' && text[i+1] === '<') { dictEnd = findDictEnd(text, i); dictStr = text.slice(i, dictEnd); }
  let j = dictEnd;
  while (/\s/.test(text[j])) j++;
  let streamStart = -1;
  if (text.startsWith('stream', j)) {
    let s = j + 6;
    if (text[s] === '\r' && text[s+1] === '\n') s += 2; else if (text[s] === '\n') s += 1;
    streamStart = s;
  }
  return { dictStr, streamStart, off };
}

function resolveLength(text, offsets, dictStr){
  const lm = /\/Length\s+(\d+)\s+0\s+R/.exec(dictStr);
  if (lm) {
    const off = offsets.get(parseInt(lm[1],10));
    const seg = text.slice(off, off+60);
    const numM = /obj\s*(\d+)/.exec(seg);
    return numM ? parseInt(numM[1],10) : null;
  }
  const dm = /\/Length\s+(\d+)/.exec(dictStr);
  return dm ? parseInt(dm[1],10) : null;
}

function getStreamBytes(bytes, text, offsets, objNum){
  const obj = getObjectRaw(text, offsets, objNum);
  if (!obj || obj.streamStart === -1) return null;
  const len = resolveLength(text, offsets, obj.dictStr);
  const endIdx = len != null ? obj.streamStart + len : text.indexOf('endstream', obj.streamStart);
  const raw = bytes.slice(obj.streamStart, endIdx);
  const isFlate = /\/Filter\s*\/FlateDecode/.test(obj.dictStr) || /\/Filter\s*\[\s*\/FlateDecode/.test(obj.dictStr);
  return { raw, isFlate };
}

async function inflate(bytes){
  const ds = new DecompressionStream('deflate');
  const stream = new Blob([bytes]).stream().pipeThrough(ds);
  const buf = await new Response(stream).arrayBuffer();
  return new Uint8Array(buf);
}

function decodePdfString(raw){
  let out = '';
  for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (c === '\\') {
      const n = raw[i+1];
      if (n === 'n') { out += '\n'; i++; }
      else if (n === 'r') { out += '\r'; i++; }
      else if (n === 't') { out += '\t'; i++; }
      else if (n === '(' || n === ')' || n === '\\') { out += n; i++; }
      else if (n === '\n') { i++; }
      else if (n === '\r') { i++; if (raw[i+1] === '\n') i++; }
      else if (/[0-7]/.test(n)) {
        let oct = n; i++;
        for (let k = 0; k < 2 && /[0-7]/.test(raw[i+1]); k++) { oct += raw[i+1]; i++; }
        out += String.fromCharCode(parseInt(oct,8) & 0xFF);
      } else { out += n; i++; }
    } else out += c;
  }
  return out;
}

function extractParenString(s, startIdx){
  let depth = 0, i = startIdx;
  for (; i < s.length; i++) {
    if (s[i] === '\\') { i++; continue; }
    if (s[i] === '(') depth++;
    else if (s[i] === ')') { depth--; if (depth === 0) return { content: s.slice(startIdx+1, i), end: i+1 }; }
  }
  return { content: s.slice(startIdx+1), end: s.length };
}

function extractTextRuns(content){
  const tmRe = /(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+Tm/g;
  const tms = [];
  let m;
  while ((m = tmRe.exec(content)) !== null) tms.push({ end: tmRe.lastIndex, x: parseFloat(m[5]), y: parseFloat(m[6]) });
  const runs = [];
  let ti = 0, i = 0, curX = 0, curY = 0;
  const len = content.length;
  while (i < len) {
    while (ti < tms.length && tms[ti].end <= i) { curX = tms[ti].x; curY = tms[ti].y; ti++; }
    // A TJ array — [(Hello) -120 (World)] TJ — is just as common as a plain
    // Tj and was previously skipped entirely, so any PDF exported that way
    // produced zero records. Collect every string piece in the array and join
    // them into one run at the array's text position.
    if (content[i] === '[') {
      const pieces = [];
      let j = i + 1, closed = false;
      while (j < content.length) {
        if (content[j] === ']') { closed = true; j++; break; }
        if (content[j] === '(') {
          const got = extractParenString(content, j);
          pieces.push(decodePdfString(got.content));
          j = got.end;
          continue;
        }
        j++;
      }
      let k = j;
      while (content[k] === ' ' || content[k] === '\n' || content[k] === '\r') k++;
      if (closed && content.startsWith('TJ', k) && pieces.length) {
        runs.push({ x: curX, y: curY, str: pieces.join('') });
        i = k + 2;
        continue;
      }
      i = closed ? j : i + 1;
      continue;
    }
    if (content[i] === '(') {
      const { content: str, end } = extractParenString(content, i);
      let j = end;
      while (content[j] === ' ') j++;
      if (content.startsWith('Tj', j)) {
        runs.push({ x: curX, y: curY, str: decodePdfString(str) });
      }
      i = end;
      continue;
    }
    i++;
  }
  return runs;
}

async function getAllPageTextRuns(bytes, text){
  const { offsets, rootRef } = parsePdfStructure(text);
  const catalog = getObjectRaw(text, offsets, rootRef);
  const pagesRefM = /\/Pages\s+(\d+)\s+0\s+R/.exec(catalog.dictStr);

  // The page tree is not always flat — a /Pages node's Kids can themselves
  // be /Pages nodes (each with their own Kids), nested several levels deep,
  // instead of every Kid being a leaf /Page directly. Different PDF export
  // tools (or larger reports, like this one with 298 rows / 34 pages) build
  // this tree with intermediate nodes. Flatten it recursively so every real
  // page is found regardless of how deep the tree goes — otherwise pages
  // silently go missing and every record on them is lost.
  function collectPageNums(objNum, seen){
    if (seen.has(objNum)) return [];
    seen.add(objNum);
    const obj = getObjectRaw(text, offsets, objNum);
    if (!obj || !obj.dictStr) return [];
    const kidsM = /\/Kids\s*\[(.*?)\]/s.exec(obj.dictStr);
    if (!kidsM) return [objNum];
    const kidNums = [...kidsM[1].matchAll(/(\d+)\s+0\s+R/g)].map(m => parseInt(m[1],10));
    let out = [];
    for (const k of kidNums) out = out.concat(collectPageNums(k, seen));
    return out;
  }
  const kidNums = collectPageNums(parseInt(pagesRefM[1],10), new Set());
  const allRuns = [];
  for (const pageNum of kidNums) {
    const pageObj = getObjectRaw(text, offsets, pageNum);
    // /Contents can be a single reference OR an array of several streams that
    // together make up one page. Reading only the first element of the array
    // silently lost every record printed by the later streams, so collect all
    // of them and join their decoded content before extracting text runs.
    const contentNums = [];
    const arrM = /\/Contents\s*\[([^\]]*)\]/.exec(pageObj.dictStr);
    if (arrM) {
      for (const m of arrM[1].matchAll(/(\d+)\s+\d+\s+R/g)) contentNums.push(parseInt(m[1],10));
    } else {
      const singleM = /\/Contents\s+(\d+)\s+\d+\s+R/.exec(pageObj.dictStr);
      if (singleM) contentNums.push(parseInt(singleM[1],10));
    }
    if (!contentNums.length) continue;

    const parts = [];
    for (const cNum of contentNums) {
      const streamInfo = getStreamBytes(bytes, text, offsets, cNum);
      if (!streamInfo) continue;
      let raw = streamInfo.raw;
      if (streamInfo.isFlate) {
        try { raw = await inflate(raw); } catch(e) { continue; }
      }
      parts.push(bytesToLatin1(raw));
    }
    if (!parts.length) continue;
    allRuns.push(extractTextRuns(parts.join('\n')));
  }
  return allRuns;
}
