// ---------- row/column reconstruction & EPI classification ----------

const VACCINE_COLUMNS = ['BCG','HepB','OPV','ROTA','IPV','Penta','PCV','Measles','TCV','TT','Paracetamol'];

function buildColumnBounds(runs){
  const headerX = {};
  for (const col of VACCINE_COLUMNS) { const hit = runs.find(r => r.str === col); if (hit) headerX[col] = hit.x; }
  const found = VACCINE_COLUMNS.filter(c => headerX[c] !== undefined).sort((a,b) => headerX[a]-headerX[b]);
  const bounds = [];
  for (let k = 0; k < found.length; k++) {
    const col = found[k];
    const lo = k === 0 ? headerX[col]-30 : (headerX[found[k-1]]+headerX[col])/2;
    const hi = k === found.length-1 ? headerX[col]+40 : (headerX[col]+headerX[found[k+1]])/2;
    bounds.push({ col, lo, hi });
  }
  return bounds;
}

function classifyColumn(x, bounds){ for (const b of bounds) if (x >= b.lo && x < b.hi) return b.col; return null; }

function buildAddressBounds(runs){
  const genderHit = runs.find(r => r.str.startsWith('Gende'));
  const vaccHit = runs.find(r => r.str === 'Vaccination');
  if (!genderHit || !vaccHit) return null;
  // The "Contact / Address" column header wraps onto two lines. The lower of
  // those two header lines (the literal word "Address") sits just above the
  // first data row. Without this, the first record's address band has no
  // "previous row" to bound it above and ends up swallowing the header text
  // itself (e.g. "Contact / Address Uchi Darhi ..."). Cap every row's upper
  // bound at just below this header line so the header can never be picked up.
  const addressHeaderHit = runs.find(r => r.str === 'Address');
  const headerBottomY = addressHeaderHit ? addressHeaderHit.y - 1 : genderHit.y - 5;
  return { lo: genderHit.x + 15, hi: vaccHit.x - 8, headerBottomY };
}

// The "Gender" column sits between DOB and Contact/Address and prints
// "Son" or "Daughter" (occasionally "Male"/"Female") as its value. Used only
// to pick a boy/girl icon for the "Card Style" PDF export — never required,
// so a report without this column simply leaves gender unknown.
function buildGenderBounds(runs){
  const genderHit = runs.find(r => r.str.startsWith('Gende'));
  if (!genderHit) return null;
  const dobHit = runs.find(r => /^DOB$/.test(r.str));
  const lo = dobHit ? (dobHit.x + genderHit.x) / 2 : genderHit.x - 30;
  const hi = genderHit.x + 15;
  return { lo, hi };
}

function genderFromText(text){
  const t = (text || '').trim().toLowerCase();
  if (!t) return null;
  if (/^son$|^male$|^m$/.test(t)) return 'M';
  if (/^daughter$|^female$|^f$/.test(t)) return 'F';
  return null;
}

// The PDF's Identifier cell may contain a status such as "Out of Uc" or
// "Out From Taluka" in addition to the 14-digit identifier.  Classification
// must come from this Identifier column, not from the address/tehsil text.
function buildIdentifierBounds(runs){
  const idHit = runs.find(r => /^Identifier$/.test(r.str));
  const nameHit = runs.find(r => /^Name$/.test(r.str));
  if (!idHit || !nameHit) return null;
  return { lo: idHit.x - 35, hi: (idHit.x + nameHit.x) / 2 };
}

function identifierStatus(slice, idBounds){
  if (!idBounds) return 'in_uc';
  // Search the whole Identifier cell belonging to this record.  We allow
  // several vertical positions because the PDF can print status text above
  // or below the 14-digit identifier inside the same cell.
  const cell = slice.filter(r => r.x >= idBounds.lo && r.x < idBounds.hi);
  const text = cell.map(r => r.str).join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  if (/out\s*(from|of)\s*(taluka|tehsil)|out\s*from\s*taluka/.test(text)) return 'out_taluka';
  if (/out\s*of\s*uc|out\s*of\s*union\s*council/.test(text)) return 'out_uc';
  return 'in_uc';
}

// "Identifier | Name | Father/Husband | DOB or | Gender | Contact / Address | Vaccination Date | ..."
function buildNameFatherBounds(runs){
  // PDF table order: Identifier | Name | Father/Husband | DOB | Gender | Contact/Address | ...
  // Use header positions, but keep the bounds tight so Gender/Address text cannot
  // accidentally become the person's name.
  const nameHit = runs.find(r => /^Name$/.test(r.str));
  const fatherHit = runs.find(r => /^Father\/Husband$/.test(r.str));
  const dobHit = runs.find(r => /^DOB$/.test(r.str));
  const idHit = runs.find(r => /^Identifier$/.test(r.str));
  if (!nameHit || !fatherHit) return null;

  const left = idHit ? (idHit.x + nameHit.x) / 2 : nameHit.x - 45;
  const nameRight = (nameHit.x + fatherHit.x) / 2;
  const fatherRight = dobHit ? (fatherHit.x + dobHit.x) / 2 : fatherHit.x + 55;
  return {
    name: { lo: left, hi: nameRight },
    father: { lo: nameRight, hi: fatherRight },
    headerY: nameHit.y
  };
}

function getFacilityName(runs){
  const candidates = runs.filter(r => r.x < 50 && r.x > 10 && r.str.trim().length > 2 && !/^\d/.test(r.str));
  candidates.sort((a,b) => b.y - a.y);
  return candidates.length ? candidates[0].str.trim() : 'Unknown Name';
}

// The PDF header prints a line like "Vaccinator Name: Basheer ahmed" below the
// facility name. Text can be split across several runs on the same line, so
// rebuild the whole line by y-position before matching the label. A "Total
// Rows: N" (or page number) summary sometimes sits on that same line, further
// to the right — strip that trailing junk off so it isn't captured as part of
// the vaccinator's name.
function getVaccinatorName(runs){
  const hit = runs.find(r => /vaccinator/i.test(r.str));
  if (!hit) return null;
  const lineRuns = runs.filter(r => Math.abs(r.y - hit.y) <= 4).sort((a,b) => a.x - b.x);
  const lineText = lineRuns.map(r => r.str).join(' ').replace(/\s+/g, ' ').trim();
  const m = /vaccinator\s*name\s*:?\s*(.+)/i.exec(lineText);
  if (!m || !m[1].trim()) return null;
  const name = m[1].trim().replace(/\s*(total\s*rows?\s*:?\s*\d*|page\s*\d+\s*(of\s*\d+)?)\s*$/i, '').trim();
  return name || null;
}

// ---------- UC / Tehsil / District detection from the address text ----------
// The report's Identifier column tells us "Out of UC" / "Out From Taluka",
// but nothing in the report says which UC a record's address actually is,
// nor whether an "Out From Taluka" address is really a different Tehsil of
// the SAME District or a completely different District. That has to come
// from the address text itself, matched against the District > Tehsil > UC
// the vaccinator selected at login (js/core/location-context.js, built from
// js/data/sindh-locations.js). This makes the detection work for whichever
// District/Tehsil/UC the person logged in with, not just one hard-coded
// tehsil.
//
// When no login selection is available (e.g. this file opened directly
// without going through login.html) we fall back to the original Ghotki >
// Mirpur Mathelo word list so the app keeps working exactly as before.
const FALLBACK_TEHSIL_UCS = [
  'Dhangro','Wahi Ghoto','Garhi Chakar','Jarwar',
  'Mirpur Mathelo- Mirpur Mathelo 1','Mirpur Mathelo 2',
  'Sono Pitafi','Yaro Lund'
];

function normalizeAddressForFilter(address){
  // Keep the COMPLETE Address value for display/storage. This normalized copy
  // is used only for UC detection. Commas are just separators between
  // Address / UC / Tehsil in the report (e.g. "..., Jarwar, Mirpur Mathelo")
  // so they're treated the same as whitespace here.
  return (address || '')
    .replace(/[–—]/g, '-')
    .replace(/,/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/\s*-\s*/g, '- ')
    .trim();
}

function detectUcFromAddressFallback(address){
  const raw = normalizeAddressForFilter(address);
  if (!raw) return null;
  const compact = raw.replace(/[-,]/g, ' ').replace(/\s+/g, ' ').trim();
  if (/mirpur\s+mathelo\s*-\s*mirpur\s+mathelo\s*(?:0?1)\s*(?:mirpur)?$/i.test(raw) ||
      /mirpur\s+mathelo\s+0?1\s+mirpur$/i.test(compact)) {
    return 'Mirpur Mathelo- Mirpur Mathelo 1';
  }
  if (/mirpur\s+mathelo\s*2\s*(?:mirpur)?$/i.test(raw)) {
    return 'Mirpur Mathelo 2';
  }
  for (const uc of ['Dhangro','Wahi Ghoto','Garhi Chakar','Jarwar','Sono Pitafi','Yaro Lund']) {
    const escaped = uc.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('(?:^|[\\s,/-])' + escaped + '\\s+(?:Mirpur\\s+Mathelo|Mirpur)$', 'i');
    if (re.test(raw)) return uc;
  }
  return null;
}

// Detect UC from the COMPLETE Address field only. Do not use Identifier or
// the PDF page/facility heading for UC classification. Returns the matched
// UC name (from the logged-in Tehsil), or null when the address doesn't
// belong to that Tehsil (Out From Taluka / Out From District).
function addressFilterName(address){
  const ctx = (typeof window !== 'undefined') ? window.EPI_LOCATION_CONTEXT : null;
  if (ctx) return ctx.classifyAddress(address).uc;
  return detectUcFromAddressFallback(address);
}

// Location-only status of the address: 'in_uc' (inside the selected Tehsil,
// at some UC), 'out_taluka' (a different Tehsil of the same District), or
// 'out_district' (address doesn't match anything in the selected District).
// This is combined with the Identifier column's own status further below.
function addressLocationStatus(address){
  const ctx = (typeof window !== 'undefined') ? window.EPI_LOCATION_CONTEXT : null;
  if (ctx) return ctx.classifyAddress(address).status;
  return detectUcFromAddressFallback(address) ? 'in_uc' : 'out_taluka';
}

// EPI No lives in the same "Identifier" cell as the 14-digit QR code (8-digit
// EPI No + 14-digit QR = the 22-digit EPI Identifier). PDFs split that cell in
// different ways — EPI No on the line above, on the same line, or even printed
// after the QR — so work from the DIGITS of the whole cell instead of hoping
// for one clean run. Returns the 8-digit EPI No, or null when it isn't there.
function readEpiNoFromIdentifierCell(cellRuns, id){
  const order = cellRuns.slice().sort((a, b) => (b.y - a.y) || (a.x - b.x));
  const digits = order.map(r => r.str).join('').replace(/\D/g, '');
  const at = digits.indexOf(id);
  if (at >= 8) return digits.slice(at - 8, at);                     // EPI No first, then QR
  if (at === 0 && digits.length === 22) return digits.slice(14);   // QR first, then EPI No
  const eight = order.find(r => /^\d{8}$/.test(r.str));            // last resort: a lone 8-digit run
  return eight ? eight.str : null;
}

// PRIMARY way to read the EPI No: in the Identifier cell the 8-digit EPI No is
// printed ABOVE the 14-digit QR code. So take the nearest all-digit text that sits
// just above the QR code (same column area) and below the previous row's QR code.
// Anchored on the QR code itself, so it does not depend on the column bounds or on
// how tall the row happens to be. Returns null when nothing 8-digit is found.
function readEpiNoAboveQr(runs, anchor, topLimit){
  const near = runs.filter(r => r !== anchor && /^\d+$/.test(r.str) &&
    r.y >= anchor.y - 1 && r.y <= topLimit && Math.abs(r.x - anchor.x) <= 60);
  if (!near.length) return null;
  near.sort((a, b) => (a.y - b.y) || (a.x - b.x));                 // nearest line above the QR first
  const eight = near.find(r => r.str.length === 8);
  if (eight) return eight.str;
  // EPI No split into pieces on one line (e.g. "1234" + "5678")
  const line = near.filter(r => Math.abs(r.y - near[0].y) <= 2).sort((a, b) => a.x - b.x);
  const joined = line.map(r => r.str).join('');
  return joined.length === 8 ? joined : null;
}

function extractRecordsFromRuns(runs){
  const facility = getFacilityName(runs);
  const vaccinatorName = getVaccinatorName(runs);
  const bounds = buildColumnBounds(runs);
  const addrBounds = buildAddressBounds(runs);
  const genderBounds = buildGenderBounds(runs);
  const nfBounds = buildNameFatherBounds(runs);
  const idBounds = buildIdentifierBounds(runs);
  const anchorIdxs = [];
  // A row is anchored by its identifier: normally the 14-digit QR code, but some
  // exports print the WHOLE 22-digit EPI Identifier (8-digit EPI No + 14-digit QR).
  runs.forEach((r, idx) => { if (/^\d{14}$/.test(r.str) || /^\d{22}$/.test(r.str)) anchorIdxs.push(idx); });
  // Built ONCE here. It used to be re-created and re-sorted inside the loop
  // below for every single record, which made a big report O(n^2 log n).
  const orderedAnchors = anchorIdxs.map(i => runs[i]).sort((a,b) => b.y - a.y);
  const anchorPos = new Map();
  orderedAnchors.forEach((r, i) => anchorPos.set(r, i));
  const records = [];
  for (let a = 0; a < anchorIdxs.length; a++) {
    const start = anchorIdxs[a];
    const end = a+1 < anchorIdxs.length ? anchorIdxs[a+1] : runs.length;
    const slice = runs.slice(start, end);
    const anchorStr = runs[start].str;
    const id = anchorStr.slice(-14);                                  // QR code
    let epiNo = anchorStr.length === 22 ? anchorStr.slice(0, 8) : null;   // EPI No

    let dob = null;
    for (let k = 0; k < slice.length; k++) {
      const dm = /^(\d{2})\/(\d{2})\/$/.exec(slice[k].str);
      if (dm) {
        for (let k2 = k+1; k2 < Math.min(k+3, slice.length); k2++) {
          const ym = /^(\d{4})$/.exec(slice[k2].str);
          if (ym) { dob = { day:+dm[1], month:+dm[2], year:+ym[1] }; break; }
        }
        if (dob) break;
      }
    }
    if (!dob) continue;

    let vaccDate = null;
    for (const r of slice) {
      const vm = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(r.str);
      if (vm) { vaccDate = { day:+vm[1], month:+vm[2], year:+vm[3] }; break; }
    }
    if (!vaccDate) continue;

    const colVals = {};
    for (const r of slice) {
      if (!/^(Y|[0-5])$/.test(r.str)) continue;
      const col = classifyColumn(r.x, bounds);
      if (!col) continue;
      if (!colVals[col] || r.y > colVals[col].y) colVals[col] = { value: r.str, y: r.y };
    }
    const doses = {};
    for (const col of Object.keys(colVals)) doses[col] = colVals[col].value;

    // Vertical band that belongs to THIS row: bounded by the midpoints to the
    // neighbouring identifier rows and never reaching up into the column header.
    const bandRowY = runs[start].y;
    const bandPos = anchorPos.has(runs[start]) ? anchorPos.get(runs[start]) : -1;
    const bandPrevY = bandPos > 0 ? orderedAnchors[bandPos - 1].y : bandRowY + 100;
    const bandNextY = bandPos >= 0 && bandPos < orderedAnchors.length - 1 ? orderedAnchors[bandPos + 1].y : bandRowY - 100;
    const bandUpper = Math.min((bandPrevY + bandRowY) / 2, addrBounds ? addrBounds.headerBottomY : Infinity);
    const bandLower = (bandRowY + bandNextY) / 2;

    // EPI No: printed above the QR code in the Identifier cell of this row
    if (!epiNo) {
      const prevAnchor = bandPos > 0 ? orderedAnchors[bandPos - 1] : null;
      const topLimit = prevAnchor ? prevAnchor.y - 3 : (addrBounds ? addrBounds.headerBottomY : bandRowY + 60);
      epiNo = readEpiNoAboveQr(runs, runs[start], topLimit);
    }
    // ...otherwise fall back to reading the digits of the whole Identifier cell
    if (!epiNo && idBounds) {
      const cellRuns = runs.filter(r => r.x >= idBounds.lo && r.x < idBounds.hi && r.y <= bandUpper && r.y >= bandLower);
      epiNo = readEpiNoFromIdentifierCell(cellRuns, id);
    }

    let address = '';
    if (addrBounds) {
      // Read the complete Address cell from the PDF row, not only the text
      // that happens to appear after the identifier in the PDF content stream.
      // Some PDFs place wrapped address text before the 14-digit identifier,
      // so using only `slice` can silently drop part of the address.
      const rowY = runs[start].y;
      // Use the full vertical band belonging to this identifier row.  Address
      // values in the PDF can wrap onto multiple lines, so a fixed-height
      // window can cut off the beginning or end of the Address.  The band is
      // bounded by the midpoints between this row and the neighbouring
      // 14-digit identifier rows, which keeps the complete wrapped Address
      // while avoiding the next record.
      const rowPos = anchorPos.has(runs[start]) ? anchorPos.get(runs[start]) : -1;
      const prevY = rowPos > 0 ? orderedAnchors[rowPos - 1].y : rowY + 100;
      const nextY = rowPos >= 0 && rowPos < orderedAnchors.length - 1 ? orderedAnchors[rowPos + 1].y : rowY - 100;
      // Never let the address band reach above the column header, even for
      // the first row in the table (see buildAddressBounds).
      const upper = Math.min((prevY + rowY) / 2, addrBounds.headerBottomY);
      const lower = (rowY + nextY) / 2;
      const addrTokens = runs.filter(r =>
        r.x >= addrBounds.lo && r.x < addrBounds.hi &&
        r.y <= upper && r.y >= lower &&
        !/^\d{2}\/\d{2}\/\d{4}$/.test(r.str) &&
        !/^Page \d+$/.test(r.str)
      );
      // Rebuild wrapped address lines in normal reading order.
      addrTokens.sort((a,b) => (b.y - a.y) || (a.x - b.x));
      address = addrTokens.map(r => r.str).join(' ').replace(/\s+/g, ' ').trim();
    }

    // Status (In UC / Out From UC / Out From Taluka / Out From District) is
    // decided ENTIRELY by comparing this record's Address to the
    // District/Tehsil/UC selected at login — not from the report's own
    // Identifier column (that column marks facility-level "Out of UC" the
    // same way for every record on a page, so it can't tell one UC's
    // children apart from another's).
    //   - Address's UC matches the logged-in UC              -> In UC
    //   - Address is a different UC of the SAME Tehsil        -> Out From UC
    //   - Address is a different Tehsil of the SAME District  -> Out From Taluka
    //   - Address doesn't match the logged-in District at all -> Out From District
    const ucFromAddress = addressFilterName(address);
    const status = addressLocationStatus(address); // 'in_uc' | 'out_uc' | 'out_taluka' | 'out_district'
    const outOfUc = status === 'out_uc';
    const outOfTaluka = status === 'out_taluka';
    const outOfDistrict = status === 'out_district';
    const derivedFacility = ucFromAddress || facility || (outOfDistrict ? 'Out From District' : 'Out From Taluka');

    let name = '', fatherName = '';
    const rowY = runs[start].y;
    const sameRow = r => Math.abs(r.y - rowY) <= 8;
    if (nfBounds) {
      const isJunk = s => /^\d+$/.test(s) || /^Page \d+$/.test(s) || /^\d{2}\/\d{2}\/\d{4}$/.test(s);
      // The 14-digit identifier is the row anchor. Read Name and Father/Husband
      // only from text on the same table row. This prevents the Gender column
      // (e.g. Son/Daughter) or the next row from being picked as the name.
      // Longer Name/Father values wrap onto a second line within the same
      // cell. Sort in normal reading order (top line before bottom line,
      // left to right within a line) — sorting by x alone scrambles wrapped
      // two-line values (e.g. "Talib Hussain" / "Bozdar" becoming
      // "Bozdar Talib Hussain").
      const nameTokens = slice.filter(r => sameRow(r) && r.x >= nfBounds.name.lo && r.x < nfBounds.name.hi && !isJunk(r.str));
      nameTokens.sort((a,b) => (b.y - a.y) || (a.x - b.x));
      name = nameTokens.map(r => r.str).join(' ').replace(/\s+/g, ' ').trim();

      const fatherTokens = slice.filter(r => sameRow(r) && r.x >= nfBounds.father.lo && r.x < nfBounds.father.hi && !isJunk(r.str));
      fatherTokens.sort((a,b) => (b.y - a.y) || (a.x - b.x));
      fatherName = fatherTokens.map(r => r.str).join(' ').replace(/\s+/g, ' ').trim();
    }

    let gender = null;
    if (genderBounds) {
      const genderTokens = slice.filter(r => sameRow(r) && r.x >= genderBounds.lo && r.x < genderBounds.hi);
      gender = genderFromText(genderTokens.map(r => r.str).join(' '));
    }

    records.push({ id, epiNo: epiNo || null, dob, vaccDate, outOfUc, outOfTaluka, outOfDistrict, status, doses, address, name: name || null, fatherName: fatherName || null, gender, facility: derivedFacility, vaccinatorName: vaccinatorName || null, centerName: (facility && facility !== 'Unknown Name') ? facility : null });
  }
  return records;
}

// ---------- File-level validation & de-duplication for Daily Immunization
// Report uploads ----------

// A genuine Daily Registry page always carries these column headers. A PDF
// that merely happens to be NAMED like a Daily Immunization Report but has
// different content (e.g. a Defaulters List uploaded into the wrong button,
// or an unrelated PDF) will not have them, so pages without this structure
// are rejected rather than silently read as if they were valid data.
function isValidDailyRegistryRuns(runs){
  const hasId = runs.some(r => /^Identifier$/.test(r.str));
  const hasName = runs.some(r => /^Name$/.test(r.str));
  const hasFather = runs.some(r => /^Father\/Husband$/.test(r.str));
  const hasVaccCols = VACCINE_COLUMNS.some(c => runs.some(r => r.str === c));
  return hasId && hasName && hasFather && hasVaccCols;
}

// Identifies which "same day's work" a Daily Immunization Report file
// belongs to: the vaccination date it covers, plus — whenever a vaccinator
// name is printed — that vaccinator, or, when no vaccinator name is
// printed, the facility/center name instead. Two files that land on the
// same key are duplicate copies of the same day's work; only the one with
// the most children is kept.
function dailyFileMeta(recs, facility, vaccinatorName){
  if (!recs.length) return null;
  const dateCounts = {};
  for (const r of recs) {
    if (!r.vaccDate) continue;
    const k = `${r.vaccDate.year}-${r.vaccDate.month}-${r.vaccDate.day}`;
    dateCounts[k] = (dateCounts[k] || 0) + 1;
  }
  const keys = Object.keys(dateCounts).sort((a, b) => dateCounts[b] - dateCounts[a]);
  const dateKey = keys.length ? keys[0] : null;
  const vac = (vaccinatorName || '').trim().toLowerCase();
  const cen = (facility || '').trim().toLowerCase();
  const groupKey = vac ? `V|${vac}` : (cen ? `C|${cen}` : null);
  return { dateKey, groupKey, count: recs.length };
}
