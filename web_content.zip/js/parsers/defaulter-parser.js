// ============================================================
// DEFAULTERS LIST parsing — a second, differently-shaped PDF report
// ("Children Defaulters Report") listing children/women overdue for a
// specific vaccine. Column positions are detected dynamically from the
// header text (same approach as the Daily Registry parser above) so small
// layout shifts between exports don't break extraction.
// ============================================================
// The Defaulters List report's PDF pages are authored in portrait with
// /Rotate 90 applied for display (confirmed against a real export from this
// report). That swaps the raw text-matrix axes: the raw "y" coordinate
// carries the visual left-right position and raw "x" carries the visual
// top-bottom position. Detect this from the header labels (pure text match,
// orientation-independent) and remap so the rest of this parser — which
// assumes the standard PDF "y increases upward, first line has larger y"
// convention — works unchanged for both rotated and unrotated exports.
function normalizeDefaulterRunsOrientation(runs){
  const labelTexts = new Set(['Identifier', 'Name', "Father's", 'DOB', 'PhoneNumber', 'Vaccine', 'Due', 'Status', 'Defaulted', 'Last']);
  const hits = runs.filter(r => labelTexts.has(r.str));
  if (hits.length < 4) return runs;
  const xs = hits.map(r => r.x), ys = hits.map(r => r.y);
  const xSpread = Math.max(...xs) - Math.min(...xs);
  const ySpread = Math.max(...ys) - Math.min(...ys);
  if (ySpread <= xSpread) return runs;
  return runs.map(r => ({ ...r, x: r.y, y: -r.x }));
}

function buildDefaulterColumnBounds(runs){
  const find = pred => runs.filter(pred);
  const idHit = runs.find(r => r.str === 'Identifier');
  const nameHits = find(r => r.str === 'Name').sort((a,b) => a.x - b.x);
  const fatherHit = runs.find(r => /^Father'?s/.test(r.str));
  const dobHit = runs.find(r => r.str === 'DOB');
  const phoneHit = runs.find(r => /^PhoneNumber/.test(r.str));
  const vaccineHit = runs.find(r => r.str === 'Vaccine');
  const dueHit = runs.find(r => /^Due/.test(r.str));
  const defaultedHits = find(r => r.str === 'Defaulted').sort((a,b) => a.x - b.x);
  const dateColHit = defaultedHits[2];
  const statusHit = runs.find(r => r.str === 'Status');
  const vaccinatedHit = runs.find(r => /^Vaccina/.test(r.str));
  const enrollHits = find(r => r.str === 'Enrollment').sort((a,b) => a.x - b.x);
  const enrollHit = enrollHits[0];
  const lastHit = runs.find(r => /^Last/.test(r.str));
  // Not every Children Defaulter Report export includes a Gender column —
  // when present it sits between DOB and the Address/Phone column.
  const genderHit = runs.find(r => r.str.startsWith('Gende'));

  if (!idHit || !nameHits.length || !fatherHit || !dobHit || !phoneHit || !vaccineHit) return null;
  const nameHit = nameHits[0];

  const vaccinatorLabelHit = runs.find(r => r.str === 'Vaccinator');
  const visitedHit = runs.find(r => r.str === 'Visited');
  const centerLabelHit = runs.find(r => r.str === 'Center');
  const headerTokens = [idHit, nameHit, fatherHit, dobHit, genderHit, phoneHit, vaccineHit, dueHit, dateColHit, statusHit, vaccinatedHit, enrollHit, lastHit, vaccinatorLabelHit, visitedHit, centerLabelHit].filter(Boolean);
  const headerBottomY = Math.min(...headerTokens.map(h => h.y));

  const anchors = [
    { col: 'id', x: idHit.x },
    { col: 'name', x: nameHit.x },
    { col: 'father', x: fatherHit.x },
    { col: 'dob', x: dobHit.x },
    { col: 'address', x: phoneHit.x },
    { col: 'vaccine', x: vaccineHit.x },
  ];
  if (genderHit) anchors.push({ col: 'gender', x: genderHit.x });
  if (dueHit) anchors.push({ col: 'dueDate', x: dueHit.x });
  if (dateColHit) anchors.push({ col: 'defDate', x: dateColHit.x });
  if (statusHit) anchors.push({ col: 'status', x: statusHit.x });
  if (vaccinatedHit) anchors.push({ col: 'vaccinatedOn', x: vaccinatedHit.x });
  if (enrollHit) anchors.push({ col: 'enrollment', x: enrollHit.x });
  if (lastHit) anchors.push({ col: 'lastVisited', x: lastHit.x });

  anchors.sort((a,b) => a.x - b.x);
  const bounds = [];
  for (let k = 0; k < anchors.length; k++) {
    let lo = k === 0 ? anchors[k].x - 35 : (anchors[k-1].x + anchors[k].x) / 2;
    let hi = k === anchors.length - 1 ? anchors[k].x + 200 : (anchors[k].x + anchors[k+1].x) / 2;
    // Address values (place names) commonly run right up near the Vaccine
    // column's header x, well past the plain midpoint of the two headers —
    // give Address the benefit of the gap and start Vaccine only just before
    // its own values actually begin.
    if (anchors[k].col === 'address' && vaccineHit) hi = vaccineHit.x - 15;
    if (anchors[k].col === 'vaccine') lo = vaccineHit.x - 15;
    bounds.push({ col: anchors[k].col, lo, hi });
  }
  return { bounds, headerBottomY, enrollLo: enrollHit ? (anchors.find(a=>a.col==='enrollment')) : null, lastHitX: lastHit ? lastHit.x : null };
}

function mapDefaultedVaccineToken(tok){
  const map = { BCG:'BCG', HEPB:'HepB', OPV0:'OPV0', PENTA1:'Penta1', PENTA2:'Penta2', PENTA3:'Penta3', MEASLES1:'Measles1', MEASLES2:'Measles2', TT1:'TT1', TT2:'TT2', TT3:'TT3', TT4:'TT4', TT5:'TT5' };
  return map[tok] || null;
}

function extractDefaultersFromRuns(runs){
  runs = normalizeDefaulterRunsOrientation(runs);
  const built = buildDefaulterColumnBounds(runs);
  if (!built) return [];
  const { bounds, headerBottomY, lastHitX } = built;

  const anchorIdxs = [];
  // A row is anchored by its identifier. That is normally the 14-digit QR code,
  // but some exports print the WHOLE 22-digit EPI Identifier as one run
  // (8-digit EPI No followed by the 14-digit QR). Accept both shapes.
  runs.forEach((r, idx) => { if (/^\d{14}$/.test(r.str) || /^\d{22}$/.test(r.str)) anchorIdxs.push(idx); });
  if (!anchorIdxs.length) return [];

  const orderedAnchors = anchorIdxs.map(i => runs[i]).sort((a,b) => b.y - a.y);
  const cols = ['id','name','father','dob','gender','address','vaccine','dueDate','defDate','status','vaccinatedOn','enrollment','lastVisited'];

  const results = [];
  for (let i = 0; i < orderedAnchors.length; i++) {
    const anchor = orderedAnchors[i];
    const prevY = i > 0 ? orderedAnchors[i-1].y : anchor.y + 100;
    const nextY = i < orderedAnchors.length - 1 ? orderedAnchors[i+1].y : anchor.y - 100;
    let upper = (prevY + anchor.y) / 2;
    if (headerBottomY) upper = Math.min(upper, headerBottomY - 2);
    const lower = (anchor.y + nextY) / 2;

    const rowRuns = runs.filter(r => r.y <= upper && r.y >= lower);
    const byCol = {};
    for (const col of cols) byCol[col] = [];
    for (const r of rowRuns) { const col = classifyColumn(r.x, bounds); if (col) byCol[col].push(r); }
    const readingOrder = arr => arr.slice().sort((a,b) => (b.y - a.y) || (a.x - b.x));

    // Enrollment (Center/Vaccinator) and Last Visited Center columns sit close
    // together and a long vaccinator name can extend past the midpoint x
    // boundary. Re-split using the row's line structure instead: the
    // Enrollment cell always wraps "Center/" onto the row's TOP line and the
    // vaccinator's name onto the row's SECOND line (same line as the 14-digit
    // identifier); Last Visited Center is always a single line, on the TOP
    // line. So: second-line tokens in this x-region belong to the
    // vaccinator's name; top-line tokens split by the Last-Visited header x.
    const mergedRight = byCol.enrollment.concat(byCol.lastVisited);
    byCol.enrollment = []; byCol.lastVisited = [];
    for (const r of mergedRight) {
      if (lastHitX && r.x >= lastHitX - 25) byCol.lastVisited.push(r);
      else byCol.enrollment.push(r);
    }

    // The EPI Identifier is 22 digits: the first 8 are the EPI No, the next 14
    // are the QR code. PDFs break that cell up in all sorts of ways, so work
    // from the DIGITS of the whole cell rather than hoping for a clean 8-digit
    // run — a split like "203040" + "5012345678901234" still resolves.
    let id = anchor.str, epiNo = null;
    if (id.length === 22) { epiNo = id.slice(0, 8); id = id.slice(8); }

    if (!epiNo) {
      const cellDigits = readingOrder(byCol.id).map(r => r.str).join('').replace(/\D/g, '');
      const at = cellDigits.indexOf(id);
      if (at >= 8) epiNo = cellDigits.slice(at - 8, at);
    }
    if (!epiNo) {
      // Widen to every run on this row that sits left of the Name column.
      const nameLo = (bounds.find(b => b.col === 'name') || {}).lo;
      const leftDigits = readingOrder(rowRuns)
        .filter(r => nameLo === undefined || r.x < nameLo)
        .map(r => r.str).join('').replace(/\D/g, '');
      const at = leftDigits.indexOf(id);
      if (at >= 8) epiNo = leftDigits.slice(at - 8, at);
    }
    if (!epiNo) {
      // Last resort: a standalone 8-digit run next to the QR code.
      const eight = r => /^\d{8}$/.test(r.str);
      const hit = readingOrder(byCol.id).find(eight) || readingOrder(rowRuns).find(eight);
      if (hit) epiNo = hit.str;
    }

    const nameText = readingOrder(byCol.name).map(r => r.str).join(' ').replace(/\s+/g,' ').trim();
    const fatherText = readingOrder(byCol.father).map(r => r.str).join(' ').replace(/\s+/g,' ').trim();

    let dob = null;
    for (const r of byCol.dob) { const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(r.str); if (m) { dob = { day:+m[1], month:+m[2], year:+m[3] }; break; } }

    const gender = genderFromText(readingOrder(byCol.gender).map(r => r.str).join(' '));

    // Mobile numbers (11 digits, starting 03 — e.g. 03013862248) sometimes
    // appear inside the Address cell. They must never be shown as part of
    // the address text. A phone token can appear anywhere in the cell (not
    // only as the first token), so scan every token in the cell rather than
    // only checking the first one.
    const addrTokens = readingOrder(byCol.address);
    const mobileTokenRe = /^03\d{9}$/;
    let phone = null;
    const addrKeepTokens = [];
    for (const r of addrTokens) {
      if (mobileTokenRe.test(r.str)) { if (!phone) phone = r.str; continue; }
      addrKeepTokens.push(r);
    }
    let address = addrKeepTokens.map(r => r.str).join(' ').replace(/\s+/g,' ').trim();
    // Safety net: a mobile number that ended up merged into a single run with
    // other address text (no separate token) is still stripped out here.
    const mobileInlineRe = /03\d{9}/;
    const inlineMatch = address.match(mobileInlineRe);
    if (inlineMatch) {
      if (!phone) phone = inlineMatch[0];
      address = address.replace(mobileInlineRe, '').replace(/\s+/g,' ').trim();
    }

    const vaccineRaw = readingOrder(byCol.vaccine).map(r => r.str).join('').toUpperCase();
    const vaccineTags = [];
    const vaccRe = /BCG|HEPB|OPV0|PENTA[1-3]|MEASLES[1-2]|TT[1-5]/g;
    let vm;
    while ((vm = vaccRe.exec(vaccineRaw))) {
      const mapped = mapDefaultedVaccineToken(vm[0]);
      if (mapped && !vaccineTags.includes(mapped)) vaccineTags.push(mapped);
    }

    let dueDate = null;
    for (const r of byCol.dueDate) { const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(r.str); if (m) { dueDate = { day:+m[1], month:+m[2], year:+m[3] }; break; } }
    let defDate = null;
    for (const r of byCol.defDate) { const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(r.str); if (m) { defDate = { day:+m[1], month:+m[2], year:+m[3] }; break; } }

    const statusText = readingOrder(byCol.status).map(r => r.str).join(' ').trim() || 'DEFAULTED';

    const enrollText = readingOrder(byCol.enrollment).map(r => r.str).join(' ').replace(/\s+/g,' ').trim();
    let enrollmentCenter = null, enrollmentVaccinator = null;
    if (enrollText.includes('/')) {
      const parts = enrollText.split('/');
      enrollmentCenter = parts[0].trim() || null;
      enrollmentVaccinator = parts.slice(1).join('/').trim() || null;
    } else if (enrollText) {
      enrollmentCenter = enrollText;
    }

    const lastVisitedCenter = readingOrder(byCol.lastVisited).map(r => r.str).join(' ').replace(/\s+/g,' ').trim() || null;

    if (!dob && !nameText && !vaccineTags.length) continue;

    results.push({
      id, epiNo: epiNo || null, name: nameText || null, fatherName: fatherText || null, dob, phone, address: address || null,
      defaultedVaccines: vaccineTags, dueDate, defaultedDate: defDate, status: statusText, gender,
      enrollmentCenter: enrollmentCenter || null, enrollmentVaccinator: enrollmentVaccinator || null,
      lastVisitedCenter
    });
  }
  return results;
}

// ---------- File-level validation & de-duplication for Children Defaulters
// Report uploads ----------

// A genuine Defaulters List page always has this column structure. A PDF
// that merely happens to be NAMED like a Children Defaulters Report but has
// different content is rejected rather than silently read as if it were
// valid data.
function isValidDefaulterRuns(runs){
  return !!buildDefaulterColumnBounds(normalizeDefaulterRunsOrientation(runs));
}

// The header of this report prints its own report period as a
// "DD/MM/YYYY - DD/MM/YYYY" pair near the top of the page (same layout as
// the Daily Registry export's date range). Used only to notice when the
// exact same report (same period, same center) has been uploaded twice —
// if the pair can't be found, this returns null and the file is simply
// treated as unique (never wrongly skipped).
function extractReportDateRange(runs){
  const dateRe = /^\d{2}\/\d{2}\/\d{4}$/;
  const dateRuns = runs.filter(r => dateRe.test(r.str));
  if (dateRuns.length < 2) return null;
  const maxY = Math.max(...runs.map(r => r.y));
  const topDates = dateRuns.filter(r => r.y >= maxY - 60).sort((a, b) => a.x - b.x);
  if (topDates.length < 2) return null;
  return `${topDates[0].str}-${topDates[topDates.length - 1].str}`;
}

// Canonical order used whenever a defaulted-vaccine list is rebuilt after
// merging, so the display order stays consistent regardless of which file
// contributed which vaccine.
const DEFAULTER_VACCINE_ORDER = ['BCG','HepB','OPV0','Penta1','Penta2','Penta3','Measles1','Measles2','TT1','TT2','TT3','TT4','TT5'];

// Point 8: the same child/woman (same QR code / id) can appear as a
// defaulter in more than one uploaded file. They are counted once, and if
// different files show them defaulting on different vaccines, every one of
// those vaccines is combined onto their single record (in EPI schedule
// order) instead of the newest file's list silently replacing the
// earlier one.
function mergeDefaulterRec(existing, incoming){
  const merged = { ...existing, ...incoming };
  const vaccineSet = new Set([...(existing.defaultedVaccines || []), ...(incoming.defaultedVaccines || [])]);
  merged.defaultedVaccines = DEFAULTER_VACCINE_ORDER.filter(v => vaccineSet.has(v));
  // Gender may only be readable from some report exports — don't let a
  // newer import without a Gender column blank out a value we already had.
  merged.gender = incoming.gender || existing.gender || null;
  const sources = (existing.sources || []).slice();
  for (const s of (incoming.sources || [])) {
    if (!sources.some(x => sourceEntryMatches(x, s.name, s.size))) sources.push(s);
  }
  merged.sources = sources;
  return merged;
}
