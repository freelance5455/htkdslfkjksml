"use strict";

const Roles = (() => {
  const TEAMS = {
    mafia: "المافيا",
    town: "المواطنون",
    neutral: "مستقل",
  };

  const LIST = [
    {
      id: "mafia", name: "المافيا", team: "mafia", tier: "core", icon: "🔪", color: "#c1121f",
      description: "عضو في العصابة السرية التي تحكم الليل.",
      ability: "تختار مع بقية المافيا ضحية كل ليلة لتصفيتها.",
      win: "تفوز عندما يتساوى عدد المافيا مع بقية الأحياء أو يزيد عليهم.",
      secret: "أنت من المافيا. اعرف شركاءك، اختر ضحية كل ليلة، وابدُ بريئًا في النهار.",
    },
    {
      id: "citizen", name: "المواطن", team: "town", tier: "core", icon: "🏠", color: "#8d99ae",
      description: "مواطن عادي لا يملك قدرة خاصة، سلاحه الوحيد ذكاؤه.",
      ability: "لا توجد قدرة ليلية. يشارك في النقاش والتصويت نهارًا.",
      win: "يفوز مع المواطنين عند التخلص من كل المافيا.",
      secret: "أنت مواطن. راقب الجميع، وناقش بذكاء، وصوّت ضد من تشك فيه.",
    },
    {
      id: "detective", name: "المحقق", team: "town", tier: "basic", icon: "🔍", color: "#3a86ff",
      description: "رجل التحقيقات الذي يتتبع أثر المافيا.",
      ability: "يفحص لاعبًا كل ليلة ويعرف إن كان من المافيا أم لا.",
      win: "يفوز مع المواطنين عند التخلص من كل المافيا.",
      secret: "أنت المحقق. كل ليلة افحص لاعبًا، واستخدم المعلومة بحذر حتى لا تُكشف.",
    },
    {
      id: "doctor", name: "الطبيب", team: "town", tier: "basic", icon: "🩺", color: "#2ec4b6",
      description: "المنقذ الذي يقف بين الضحية والموت.",
      ability: "يحمي لاعبًا كل ليلة من القتل، ويحمي نفسه مرة واحدة فقط في اللعبة.",
      win: "يفوز مع المواطنين عند التخلص من كل المافيا.",
      secret: "أنت الطبيب. اختر كل ليلة من تحميه، ولا تحمِ نفسك إلا عند الخطر.",
    },
    {
      id: "guard", name: "الحارس", team: "town", tier: "medium", icon: "🛡️", color: "#f4a261",
      description: "درع المدينة الذي يفدي غيره بحياته.",
      ability: "يحرس لاعبًا كل ليلة، فإن هاجمته المافيا يموت الحارس فداءً له. لا يحرس الشخص نفسه ليلتين متتاليتين.",
      win: "يفوز مع المواطنين عند التخلص من كل المافيا.",
      secret: "أنت الحارس. احرس من تظنه هدفًا للمافيا، وتذكر أنك قد تموت بدلًا منه.",
    },
    {
      id: "mayor", name: "العمدة", team: "town", tier: "medium", icon: "🎖️", color: "#ffd166",
      description: "صاحب الكلمة المسموعة في المدينة.",
      ability: "صوته يُحسب بصوتين في تصويت النهار.",
      win: "يفوز مع المواطنين عند التخلص من كل المافيا.",
      secret: "أنت العمدة. صوتك بصوتين، فاستخدمه بحكمة، وإن عرفت المافيا دورك ستستهدفك.",
    },
    {
      id: "informant", name: "المخبر", team: "town", tier: "medium", icon: "🕵️", color: "#9b5de5",
      description: "عميل سري يصل إلى المعلومة الدقيقة.",
      ability: "مرة واحدة في اللعبة يختار لاعبًا ويعرف دوره بالضبط.",
      win: "يفوز مع المواطنين عند التخلص من كل المافيا.",
      secret: "أنت المخبر. معك فرصة واحدة لمعرفة الدور الحقيقي للاعب، فاختر هدفك جيدًا.",
    },
    {
      id: "witch", name: "الساحر", team: "town", tier: "advanced", icon: "🔮", color: "#7b2cbf",
      description: "يتحكم في خيوط اللعبة بتعويذة واحدة.",
      ability: "مرة واحدة في اللعبة يختار لاعبًا فتُعطَّل قدرته ويُمنع من التصويت في الجولة التالية.",
      win: "يفوز مع المواطنين عند التخلص من كل المافيا.",
      secret: "أنت الساحر. معك تعويذة واحدة لتعطيل لاعب، فاستخدمها في اللحظة المناسبة.",
    },
    {
      id: "lone_killer", name: "القاتل المنفرد", team: "neutral", tier: "advanced", icon: "🗡️", color: "#ff6b35",
      description: "قاتل يعمل وحده ولا يثق بأحد.",
      ability: "يقتل لاعبًا كل ليلة بمعزل عن المافيا.",
      win: "يفوز إذا بقي آخر الأحياء أو بقي مع لاعب واحد فقط.",
      secret: "أنت القاتل المنفرد. لا أحد معك: لا المافيا ولا المواطنين. اقتل بصمت وانجُ بنفسك.",
    },
    {
      id: "clown", name: "المهرج", team: "neutral", tier: "advanced", icon: "🤡", color: "#ff4fa3",
      description: "يريد أن يُستبعد بأي ثمن.",
      ability: "لا قدرة ليلية. هدفه أن يقنع الجميع بالتصويت ضده.",
      win: "يفوز فورًا إذا تم استبعاده بالتصويت نهارًا.",
      secret: "أنت المهرج. تصرّف بغرابة ذكية لتجعلهم يصوتون ضدك، لكن لا تكن مفضوحًا أكثر من اللازم.",
    },
    {
      id: "lawyer", name: "المحامي", team: "mafia", tier: "advanced", icon: "⚖️", color: "#d4af37",
      description: "يدافع عن المافيا في العلن والظلام.",
      ability: "يظهر بريئًا أمام المحقق، ويحمي عضوًا من المافيا من الاستبعاد بالتصويت مرة واحدة.",
      win: "يفوز مع المافيا.",
      secret: "أنت المحامي من فريق المافيا. أنت تظهر بريئًا للمحقق، ومعك حماية واحدة لشريك من التصويت.",
    },
  ].map((role) => Object.freeze(role));

  const BY_ID = new Map(LIST.map((role) => [role.id, role]));

  const PRESETS = {
    basic: ["mafia", "citizen", "detective", "doctor"],
    medium: ["mafia", "citizen", "detective", "doctor", "guard", "mayor", "informant"],
    advanced: ["mafia", "citizen", "detective", "doctor", "guard", "mayor", "informant", "lawyer", "lone_killer"],
  };

  function get(id) {
    return BY_ID.get(id);
  }

  function all() {
    return LIST.slice();
  }

  function optionalRoles() {
    return LIST.filter((role) => role.tier !== "core");
  }

  function presetFor(complexity) {
    return (PRESETS[complexity] || PRESETS.basic).slice();
  }

  return { TEAMS, get, all, optionalRoles, presetFor };
})();