class Bot {
  constructor(scene, index, difficulty = 'normal') {
    this.scene = scene;
    this.index = index;
    this.difficulty = difficulty;

    this.health = 100;
    this.armor = Utils.randomInt(0, 40);
    this.alive = true;
    this.kills = 0;

    this.position = new THREE.Vector3(
      Utils.randomRange(-70, 70),
      1.0,
      Utils.randomRange(-70, 70)
    );
    this.velocity = new THREE.Vector3();
    this.rotationY = Math.random() * Math.PI * 2;
    this.pitch = 0;

    this.speed = 5.2 + Math.random() * 1.5;
    this.state = 'wander'; // wander, seekLoot, chase, attack, fleeZone
    this.targetPos = null;
    this.targetEnemy = null;
    this.stateTimer = 0;
    this.fireCooldown = 0;

    this.weapon = createWeaponInstance(
      ['pistol', 'smg', 'assault', 'shotgun'][Utils.randomInt(0, 3)]
    );

    this.mesh = this.createMesh();
    scene.add(this.mesh);

    // Difficulty modifiers
    this.accuracy = difficulty === 'easy' ? 0.3 : difficulty === 'hard' ? 0.75 : 0.5;
    this.reaction = difficulty === 'easy' ? 0.8 : difficulty === 'hard' ? 0.3 : 0.55;
    this.aggression = difficulty === 'easy' ? 0.3 : difficulty === 'hard' ? 0.7 : 0.5;
    this._frame = Math.floor(Math.random() * 3);
  }

  createMesh() {
    const group = new THREE.Group();
    const colors = [0xe74c3c, 0x2ecc71, 0xf39c12, 0x9b59b6, 0x1abc9c, 0xe67e22];
    const color = colors[this.index % colors.length];

    const bodyGeo = new THREE.CylinderGeometry(0.28, 0.32, 0.95, 8);
    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.75 });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 0.95;
    body.castShadow = true;
    group.add(body);

    const headGeo = new THREE.SphereGeometry(0.25, 8, 6);
    const headMat = new THREE.MeshStandardMaterial({ color: 0xf5d0a9 });
    const head = new THREE.Mesh(headGeo, headMat);
    head.position.y = 1.6;
    head.castShadow = true;
    group.add(head);

    group.position.copy(this.position);
    return group;
  }

  update(dt, player, bots, zone, lootSpots) {
    if (!this.alive) return;

    // Skip frames for performance (update AI every 2-3 frames)
    this._frame++;
    if (this._frame % 2 !== 0) {
      // Still move a bit
      if (this._lastDirX !== undefined) {
        this.position.x += this._lastDirX * this.speed * dt;
        this.position.z += this._lastDirZ * this.speed * dt;
        this.position.x = Math.max(-95, Math.min(95, this.position.x));
        this.position.z = Math.max(-95, Math.min(95, this.position.z));
        this.mesh.position.copy(this.position);
      }
      return;
    }

    this.stateTimer -= dt * 2;
    this.fireCooldown -= dt * 2;

    const distToPlayer = Utils.dist(this.position, player.position);
    const inDangerZone = zone && !zone.isInside(this.position);

    // Decision making
    if (inDangerZone) {
      this.state = 'fleeZone';
      this.targetPos = zone.center.clone();
    } else if (player.alive && distToPlayer < 45 && Math.random() < this.aggression) {
      this.state = distToPlayer < 28 ? 'attack' : 'chase';
      this.targetEnemy = player;
    } else if (this.stateTimer <= 0) {
      // Choose new state
      const r = Math.random();
      if (r < 0.35 && lootSpots && lootSpots.length) {
        this.state = 'seekLoot';
        this.targetPos = lootSpots[Utils.randomInt(0, lootSpots.length - 1)].clone();
      } else {
        this.state = 'wander';
        this.targetPos = new THREE.Vector3(
          Utils.randomRange(-80, 80),
          0,
          Utils.randomRange(-80, 80)
        );
      }
      this.stateTimer = Utils.randomRange(3, 8);
    }

    // Movement
    let moveTarget = null;
    if (this.state === 'fleeZone' || this.state === 'wander' || this.state === 'seekLoot') {
      moveTarget = this.targetPos;
    } else if (this.state === 'chase' || this.state === 'attack') {
      moveTarget = this.targetEnemy ? this.targetEnemy.position : null;
    }

    if (moveTarget) {
      const dx = moveTarget.x - this.position.x;
      const dz = moveTarget.z - this.position.z;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist > 1.5) {
        const dirX = dx / dist;
        const dirZ = dz / dist;
        this._lastDirX = dirX;
        this._lastDirZ = dirZ;
        this.position.x += dirX * this.speed * dt * 2;
        this.position.z += dirZ * this.speed * dt * 2;
        this.rotationY = Math.atan2(-dirX, -dirZ);
      } else {
        this._lastDirX = 0;
        this._lastDirZ = 0;
      }
    } else {
      this._lastDirX = 0;
      this._lastDirZ = 0;
    }

    // Bounds
    this.position.x = Utils.clamp(this.position.x, -95, 95);
    this.position.z = Utils.clamp(this.position.z, -95, 95);
    this.position.y = 1.0;

    // Attack
    if ((this.state === 'attack' || this.state === 'chase') && this.targetEnemy && this.targetEnemy.alive) {
      const d = Utils.dist(this.position, this.targetEnemy.position);
      if (d < this.weapon.range && this.fireCooldown <= 0) {
        // Face target
        const dx = this.targetEnemy.position.x - this.position.x;
        const dz = this.targetEnemy.position.z - this.position.z;
        this.rotationY = Math.atan2(-dx, -dz);

        // Chance to hit based on accuracy and distance
        const hitChance = this.accuracy * (1 - d / this.weapon.range * 0.5);
        if (Math.random() < hitChance) {
          const dmg = this.weapon.damage * (0.7 + Math.random() * 0.5);
          this.targetEnemy.takeDamage(dmg);
          AudioManager.hit();
        }
        this.fireCooldown = this.weapon.fireRate * (0.8 + Math.random() * 0.4);
        AudioManager.shoot(this.weapon.type);
      }
    }

    // Mesh update
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.rotationY;
  }

  takeDamage(amount) {
    if (!this.alive) return false;
    let rem = amount;
    if (this.armor > 0) {
      const abs = Math.min(this.armor, rem * 0.55);
      this.armor -= abs;
      rem -= abs;
    }
    this.health -= rem;
    if (this.health <= 0) {
      this.health = 0;
      this.alive = false;
      this.mesh.visible = false;
      return true; // killed
    }
    // Aggro
    this.state = 'attack';
    this.stateTimer = 5;
    return false;
  }
}
