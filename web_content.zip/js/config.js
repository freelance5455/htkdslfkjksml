"use strict";
const KEY="contractor_pro_global_v17";

const LEGACY_KEYS_V7=["contractor_pro_global_v17","contractor_pro_global_v14","contractor_pro_global_v12","contractor_pro_global_v9","contractor_pro_global_v8","contractor_pro_global_v7","contractor_pro_final_v1","contractor_pro_v3"];

const APP_VERSION="22.0.0";

const LANGS=["fa","en","ar","tr","ru","fr","de","hi","ta","te","kn","mr","gu","bn","es","pt","ur","id"];

const LOC={fa:"fa-IR",en:"en-US",ar:"ar-SA",tr:"tr-TR",ru:"ru-RU",fr:"fr-FR",de:"de-DE",hi:"hi-IN",ta:"ta-IN",te:"te-IN",kn:"kn-IN",mr:"mr-IN",gu:"gu-IN",bn:"bn-IN",es:"es-ES",pt:"pt-BR",ur:"ur-PK",id:"id-ID"};

const LNAME={fa:"فارسی",en:"English",ar:"العربية",tr:"Türkçe",ru:"Русский",fr:"Français",de:"Deutsch",hi:"हिन्दी",ta:"தமிழ்",te:"తెలుగు",kn:"ಕನ್ನಡ",mr:"मराठी",gu:"ગુજરાતી",bn:"বাংলা",es:"Español",pt:"Português",ur:"اردو",id:"Bahasa Indonesia"};

const DEFCAL={fa:"persian",ar:"islamic"};

const DEFTZ={fa:"Asia/Tehran",en:"America/New_York",ar:"Asia/Riyadh",tr:"Europe/Istanbul",ru:"Europe/Moscow",fr:"Europe/Paris",de:"Europe/Berlin",hi:"Asia/Kolkata",ta:"Asia/Kolkata",te:"Asia/Kolkata",kn:"Asia/Kolkata",mr:"Asia/Kolkata",gu:"Asia/Kolkata",bn:"Asia/Kolkata",es:"Europe/Madrid",pt:"America/Sao_Paulo",ur:"Asia/Karachi",id:"Asia/Jakarta"};

const TIME24={fa:true,en:false,ar:false,tr:true,ru:true,fr:true,de:true,hi:false,ta:false,te:false,kn:false,mr:false,gu:false,bn:false};

const TZNAME={"Asia/Tehran":"tzTehran","America/New_York":"tzNewYork","Europe/London":"tzLondon","Asia/Riyadh":"tzRiyadh","Asia/Dubai":"tzDubai","Europe/Istanbul":"tzIstanbul","Europe/Moscow":"tzMoscow","Europe/Paris":"tzParis","Europe/Berlin":"tzBerlin","Asia/Kolkata":"tzKolkata"};

const CURS=["IRR","USD","EUR","AED","QAR","TRY","RUB","GBP","SAR","AZN","INR","EGP","PKR","CAD","AUD","MXN","BRL","IDR"];

const COUNTRIES={IR:{name:{fa:"ایران",en:"Iran",ar:"إيران",tr:"İran",ru:"Иран",fr:"Iran",de:"Iran"},currency:"IRR",tz:"Asia/Tehran",calendar:"persian",unit:"metric",tax:"VAT"},US:{name:{fa:"ایالات متحده",en:"United States",ar:"الولايات المتحدة",tr:"Amerika Birleşik Devletleri",ru:"США",fr:"États-Unis",de:"Vereinigte Staaten"},currency:"USD",tz:"America/New_York",calendar:"gregory",unit:"imperial",tax:"Sales Tax"},GB:{name:{fa:"بریتانیا",en:"United Kingdom",ar:"المملكة المتحدة",tr:"Birleşik Krallık",ru:"Великобритания",fr:"Royaume-Uni",de:"Vereinigtes Königreich"},currency:"GBP",tz:"Europe/London",calendar:"gregory",unit:"metric",tax:"VAT"},SA:{name:{fa:"عربستان سعودی",en:"Saudi Arabia",ar:"السعودية",tr:"Suudi Arabistan",ru:"Саудовская Аравия",fr:"Arabie saoudite",de:"Saudi-Arabien"},currency:"SAR",tz:"Asia/Riyadh",calendar:"islamic",unit:"metric",tax:"VAT"},AE:{name:{fa:"امارات متحده عربی",en:"United Arab Emirates",ar:"الإمارات",tr:"Birleşik Arap Emirlikleri",ru:"ОАЭ",fr:"Émirats arabes unis",de:"Vereinigte Arabische Emirate"},currency:"AED",tz:"Asia/Dubai",calendar:"gregory",unit:"metric",tax:"VAT"},TR:{name:{fa:"ترکیه",en:"Türkiye",ar:"تركيا",tr:"Türkiye",ru:"Турция",fr:"Turquie",de:"Türkei"},currency:"TRY",tz:"Europe/Istanbul",calendar:"gregory",unit:"metric",tax:"VAT"},RU:{name:{fa:"روسیه",en:"Russia",ar:"روسيا",tr:"Rusya",ru:"Россия",fr:"Russie",de:"Russland"},currency:"RUB",tz:"Europe/Moscow",calendar:"gregory",unit:"metric",tax:"VAT"},FR:{name:{fa:"فرانسه",en:"France",ar:"فرنسا",tr:"Fransa",ru:"Франция",fr:"France",de:"Frankreich"},currency:"EUR",tz:"Europe/Paris",calendar:"gregory",unit:"metric",tax:"VAT"},DE:{name:{fa:"آلمان",en:"Germany",ar:"ألمانيا",tr:"Almanya",ru:"Германия",fr:"Allemagne",de:"Deutschland"},currency:"EUR",tz:"Europe/Berlin",calendar:"gregory",unit:"metric",tax:"VAT"},QA:{name:{fa:"قطر",en:"Qatar",ar:"قطر",tr:"Katar",ru:"Катар",fr:"Qatar",de:"Katar"},currency:"QAR",tz:"Asia/Qatar",calendar:"gregory",unit:"metric",tax:"VAT"},AZ:{name:{fa:"آذربایجان",en:"Azerbaijan",ar:"أذربيجان",tr:"Azerbaycan",ru:"Азербайджан",fr:"Azerbaïdjan",de:"Aserbaidschan"},currency:"AZN",tz:"Asia/Baku",calendar:"gregory",unit:"metric",tax:"VAT"}};

COUNTRIES.IN={name:{fa:"هند",en:"India",ar:"الهند",tr:"Hindistan",ru:"Индия",fr:"Inde",de:"Indien",hi:"भारत",ta:"இந்தியா",te:"భారతదేశం",kn:"ಭಾರತ",mr:"भारत",gu:"ભારત",bn:"ভারত"},currency:"INR",tz:"Asia/Kolkata",calendar:"gregory",unit:"metric",tax:"GST"};

const TAX_RULES={IR:{label:"VAT",rate:10},US:{label:"Sales Tax",rate:0},GB:{label:"VAT",rate:20},SA:{label:"VAT",rate:15},AE:{label:"VAT",rate:5},TR:{label:"VAT",rate:20},RU:{label:"VAT",rate:22},FR:{label:"VAT",rate:20},DE:{label:"VAT",rate:19},QA:{label:"VAT",rate:0},AZ:{label:"VAT",rate:18},IN:{label:"GST",rate:18},ES:{label:"VAT",rate:21},MX:{label:"VAT",rate:16},BR:{label:"Tax",rate:0},PK:{label:"Sales Tax",rate:18},ID:{label:"VAT",rate:11},EG:{label:"VAT",rate:14},CA:{label:"GST",rate:5},AU:{label:"GST",rate:10}};

Object.assign(COUNTRIES,{
 ES:{name:{en:"Spain",fa:"اسپانیا",es:"España",ar:"إسبانيا",fr:"Espagne",de:"Spanien"},currency:"EUR",tz:"Europe/Madrid",calendar:"gregory",unit:"metric",tax:"VAT"},
 MX:{name:{en:"Mexico",fa:"مکزیک",es:"México",ar:"المكسيك",fr:"Mexique",de:"Mexiko"},currency:"MXN",tz:"America/Mexico_City",calendar:"gregory",unit:"metric",tax:"VAT"},
 BR:{name:{en:"Brazil",fa:"برزیل",pt:"Brasil",es:"Brasil",ar:"البرازيل",fr:"Brésil",de:"Brasilien"},currency:"BRL",tz:"America/Sao_Paulo",calendar:"gregory",unit:"metric",tax:"Tax"},
 PK:{name:{en:"Pakistan",fa:"پاکستان",ur:"پاکستان",ar:"باكستان",fr:"Pakistan",de:"Pakistan"},currency:"PKR",tz:"Asia/Karachi",calendar:"gregory",unit:"metric",tax:"Sales Tax"},
 ID:{name:{en:"Indonesia",fa:"اندونزی",id:"Indonesia",ar:"إندونيسيا",fr:"Indonésie",de:"Indonesien"},currency:"IDR",tz:"Asia/Jakarta",calendar:"gregory",unit:"metric",tax:"VAT"},
 EG:{name:{en:"Egypt",fa:"مصر",ar:"مصر",fr:"Égypte",de:"Ägypten"},currency:"EGP",tz:"Africa/Cairo",calendar:"gregory",unit:"metric",tax:"VAT"},
 CA:{name:{en:"Canada",fa:"کانادا",fr:"Canada",es:"Canadá",ar:"كندا",de:"Kanada"},currency:"CAD",tz:"America/Toronto",calendar:"gregory",unit:"metric",tax:"GST"},
 AU:{name:{en:"Australia",fa:"استرالیا",ar:"أستراليا",fr:"Australie",de:"Australien",es:"Australia"},currency:"AUD",tz:"Australia/Sydney",calendar:"gregory",unit:"metric",tax:"GST"}
});

function localizedCountryName(code){const c=COUNTRIES[code];if(!c)return code;try{const dn=new Intl.DisplayNames([LOC[d.lang]||d.lang||"en"],{type:"region"});const n=dn.of(code);if(n&&n!==code)return n}catch(e){}return (c.name&& (c.name[d.lang]||c.name.en))||code}

const RTL_LANGS=["fa","ar","ur"],isRTL=l=>RTL_LANGS.includes(l);

const TZLIST=["auto","Asia/Tehran","America/New_York","Europe/London","Asia/Riyadh","Asia/Dubai","Europe/Istanbul","Europe/Moscow","Europe/Paris","Europe/Berlin","Asia/Baku","Asia/Qatar","Asia/Kolkata","Europe/Madrid","America/Mexico_City","America/Sao_Paulo","Asia/Karachi","Asia/Jakarta","Africa/Cairo","America/Toronto","Australia/Sydney"];

const clampPct=v=>{v=Number(v);return isFinite(v)?Math.min(100,Math.max(0,v)):0};

const round2=n=>Math.round((Number(n)+Number.EPSILON)*100)/100;

const LANG_COUNTRY={fa:"IR",en:"US",ar:"SA",tr:"TR",ru:"RU",fr:"FR",de:"DE",hi:"IN",ta:"IN",te:"IN",kn:"IN",mr:"IN",gu:"IN",bn:"IN",es:"ES",pt:"BR",ur:"PK",id:"ID"};

const IDS=["projects","clients","leads","estimates","contracts","changeOrders","invoices","team","timeEntries","finance","materials","inventory","equipment","schedule","dailyLogs","rfis","submittals","punchList","safetyForms","tenders","drawings","documents","accounts","suppliers","notifications"];

const MODS=[["projects","🏗️"],["clients","👥"],["leads","🎯"],["estimates","🧾"],["contracts","📄"],["changeOrders","🔁"],["invoices","💳"],["team","👷"],["timeEntries","⏱️"],["finance","💰"],["materials","🧱"],["inventory","📦"],["equipment","🛠️"],["schedule","📅"],["dailyLogs","📋"],["rfis","❓"],["submittals","📑"],["punchList","✅"],["safetyForms","🦺"],["tenders","📑"],["drawings","🗺️"],["documents","🗂️"],["accounts","🏦"],["suppliers","🚚"],["notifications","🔔"],["reports","📊"],["smartEstimate","📐"],["settings","⚙️"]];
