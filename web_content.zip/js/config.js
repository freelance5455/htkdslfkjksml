/*
  PHONE/ONLINE SETUP:
  1. Create a Supabase project.
  2. Create a bookings table using schema.sql.
  3. Paste your Supabase project URL and ANON/PUBLISHABLE key below.
  4. Do NOT put a service_role/secret key in this file.
*/
window.DARRELL_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE"
};