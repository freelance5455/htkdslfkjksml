// Where the multiplayer server lives.
// - Leave empty ('') when the Node server also serves this client (local dev).
// - For Netlify/Vercel, set to your deployed backend, e.g. 'https://battle-zone-server.onrender.com'
window.BZ_CONFIG = {
  SERVER_URL: '',
  SHOW_DEBUG: true,
};
