// انسخ الملف باسم config.js وضع بيانات مشروعك.
// استخدم فقط Publishable key (أو anon القديم). لا تضع secret/service_role هنا.
window.FADL_CONFIG = {
  supabaseUrl: "https://wzsbsbceoudhmndrmose.supabase.co",
  supabaseAnonKey: "sb_publishable_wERUL8VaiFfGnN1fnQDGVA_O-_Nf1C5",
  // اختياري: رقم واتساب المطبعة بصيغة دولية بدون + (مثال: 201001234567) لظهور زر تأكيد الطلب
  whatsapp: ""
};