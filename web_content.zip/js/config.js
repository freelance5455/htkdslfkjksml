/* EuroPath Pro — publisher configuration. Edit this file before publishing. */
(function (EP) {
  EP.config = {
    appName: 'EuroPath Pro',
    version: '2.1.0',
    buildDate: '2026-10-12',
    companyName: '[Publisher legal name]',      // shown in Privacy Policy / Terms
    companyAddress: '[Publisher postal address]',
    supportEmail: '',                            // e.g. 'support@yourdomain.com' (enables contact + waitlist buttons)
    privacyUrl: '',                              // optional public URL of privacy.html (needed by app stores)
    // Payment links (e.g. Stripe Payment Links). Leave '' until checkout is live: buttons then stay disabled.
    checkout: { PRO: '', TRAVEL_PLUS: '' },
    // Optional license server: POST {code, device} -> {plan:'PRO'|'TRAVEL_PLUS'}. Leave '' to hide activation.
    licenseEndpoint: '',
    // Optional bundled photos per section (e.g. 'img/home.jpg'). Empty = built-in illustrations. Use images you have the rights to.
    photos: { home: '', trips: '', wx: '', tools: '', more: '', sights: '', food: '', stay: '', go: '', cal: '', opts: '', budget: '', docs: '', pack: '', exp: '' },
    prices: { PRO: '€7.99', TRAVEL_PLUS: '€14.99' },
    free: { trips: 1, saved: 20 },
    // Third-party services used ONLY after the user switches on "Online features".
    services: {
      rates: 'https://api.frankfurter.app/latest?from=EUR',
      weather: 'https://api.open-meteo.com/v1/forecast',
      geocode: 'https://geocoding-api.open-meteo.com/v1/search',
      overpass: ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter']
    }
  };
})(window.EP = window.EP || {});
