/* UrbaAlerte — configuration (à adapter avant de générer l'APK) */
window.URBA_CONFIG={
  /* URL de l'API REST du mémoire (ex. "https://api.votredomaine.cd"). Vide = mode démo 100 % local sur l'appareil. */
  API_BASE:'',
  /* Numéro de la passerelle SMS de la plateforme (format international, ex. "+243XXXXXXXXX"). Vide = l'utilisateur choisit/saisit le numéro. */
  SMS_GATEWAY:'',
  /* Rayon par défaut des notifications de proximité (km) */
  RADIUS_KM:5,
  /* Fond de carte. OpenStreetMap = usage de développement ; en production, utilisez un fournisseur de tuiles adapté (MapTiler, Stadia, serveur propre…). */
  TILE_URL:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  TILE_ATTRIB:'© OpenStreetMap',
  /* Quota métier (mémoire RG03) et longueur minimale de la description (RG02) */
  MAX_PER_DAY:5,MIN_DESC:20,
  VERSION:'1.0.0'
};
