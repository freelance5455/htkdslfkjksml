window.WorkspaceConfig={
  screens:['homePage','libraryPage','placeholderPage','worldPage','gamePage','gameModsPage','gameKnowledgePage','gameResearchPage','gameQuestsPage','gameArchivePage','gameProfilesPage','gameToolsPage','gameSettingsPage','modDetailPage','compatibilityPage','advancedPage'],
  placeholders:{profiles:['♙','Profiles','Keep different mod setups separate without touching the actual installations.'],orders:['☷','Load orders','Plan and document load order arrangements safely.'],notes:['□','Notes','A dedicated place for general modding notes and research.'],favorites:['☆','Favorites','Pin the records you return to most often.']},
  gamePlaceholders:{loadorder:['☷','Load Order','Plan the order here without taking control away from MO2.'],profiles:['♙','Profiles','Profile management will live here when it is deliberately connected.'],knowledge:['□','Knowledge Database','A future home for structured game notes and research.'],tools:['⌘','Tools','Game-specific utilities will live here when they are deliberately connected.'],settings:['⚙','Settings','Future presentation and workspace preferences for this game.']},
  gameNavigation:[['overview','Dashboard'],['mods','Mod Library'],['knowledge','Knowledge Database'],['compatibility','Compatibility'],['archive','Archive'],['profiles','Profiles'],['tools','Tools'],['settings','Settings']],
  statusCards:[['mods','▦','Mods','Open library'],['loadorder','☷','Load order','Planning space'],['compatibility','◇','Compatibility','Review center'],['knowledge','□','Knowledge','Notes and research']],
  worldOrder:['fallout','elder-scrolls'],
  homeWorldCards:[
    {key:'fallout',title:'Fallout',subtitle:'Current world',status:'CURRENT',enabled:true},
    {key:'elder-scrolls',title:'The Elder Scrolls',subtitle:'Franchise world',enabled:true},
    {key:'cyberpunk',title:'Cyberpunk 2077',subtitle:'Franchise world',enabled:false},
    {key:'witcher',title:'The Witcher',subtitle:'Franchise world',enabled:false},
    {key:'red-dead',title:'Red Dead Redemption II',subtitle:'Franchise world',enabled:false},
    {key:'baldurs-gate',title:"Baldur's Gate",subtitle:'Franchise world',enabled:false},
    {key:'starfield',title:'Starfield',subtitle:'Franchise world',enabled:false},
    {key:'all-worlds',title:'ALL WORLDS',subtitle:'View and manage all franchise worlds',allWorlds:true}
  ],
  worlds:{
    fallout:{key:'fallout',title:'Fallout',glyph:'F',theme:'fallout',heroLabel:'WELCOME BACK TO',motto:'WAR NEVER CHANGES',description:'Pick a wasteland and get back to making terrible decisions with excellent load orders.',homeDescription:'Four wastelands. One very questionable survival instinct.',defaultGame:'fallout-4',games:[
      {key:'fallout-3',short:'3',title:'Fallout 3',region:'CAPITAL WASTELAND',dbNames:['Fallout 3'],previewStats:{mods:245,saves:42,hours:278}},
      {key:'fallout-new-vegas',short:'NV',title:'Fallout: New Vegas',homeTitle:'New Vegas',region:'MOJAVE WASTELAND',dbNames:['Fallout: New Vegas','Fallout New Vegas'],previewStats:{mods:312,saves:58,hours:312}},
      {key:'fallout-4',short:'4',title:'Fallout 4',region:'THE COMMONWEALTH',dbNames:['Fallout 4'],previewStats:{mods:356,saves:73,hours:287}},
      {key:'fallout-76',short:'76',title:'Fallout 76',region:'APPALACHIA',dbNames:['Fallout 76'],previewStats:{mods:156,saves:31,hours:123}}
    ]},
    'elder-scrolls':{key:'elder-scrolls',title:'The Elder Scrolls',glyph:'✦',theme:'elder-scrolls',heroLabel:'RETURN TO',motto:'ANOTHER AGE AWAITS',description:'Choose an era, gather your notes, and try not to become distracted by every suspicious cave entrance.',homeDescription:'Three eras of scrolls, dragons, daedra, and aggressively optional side quests.',defaultGame:'skyrim',games:[
      {key:'oblivion',short:'IV',title:'The Elder Scrolls IV: Oblivion',homeTitle:'Oblivion',region:'CYRODIIL',dbNames:['The Elder Scrolls IV: Oblivion','Oblivion']},
      {key:'elder-scrolls-online',short:'ESO',title:'The Elder Scrolls Online',homeTitle:'Elder Scrolls Online',region:'TAMRIEL',dbNames:['The Elder Scrolls Online','Elder Scrolls Online']},
      {key:'skyrim',short:'V',title:'The Elder Scrolls V: Skyrim',homeTitle:'Skyrim',region:'SKYRIM',dbNames:['The Elder Scrolls V: Skyrim','Skyrim Special Edition','Skyrim','The Elder Scrolls V: Skyrim Special Edition']}
    ]}
  }
};
