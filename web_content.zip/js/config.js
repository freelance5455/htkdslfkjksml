/**
 * config.js
 * Configuração central do ambiente.
 *
 * IMPORTANTE (leia antes de mudar ENV para 'prod'):
 * Este projeto ainda não possui um backend real. Trocar ENV para 'prod' apenas
 * separa o namespace de dados no localStorage — NÃO cria um servidor, NÃO cria
 * um banco de dados real e NÃO torna as regras de permissão seguras. Enquanto
 * db.js estiver implementado sobre localStorage, qualquer pessoa com acesso ao
 * navegador pode ler/editar os dados. Use 'prod' apenas para não misturar dados
 * de teste com dados "reais" de demonstração — não para produção de verdade.
 */
window.APP_CONFIG = {
  ENV: 'dev', // 'dev' | 'prod' — troque aqui quando ligar a um backend real
  STORAGE_PREFIX: 'anjodaguarda_',
  APP_NAME: 'Anjo da Guarda',
  APP_SLOGAN: 'A solução que você precisa.',
  TAXA_CONVENIENCIA: 0.05, // 5% pago pelo cliente/anfitrião
  CIDADE_PILOTO: 'Praia Grande',
  ESTADO_PILOTO: 'SP',
  TOLERANCIA_CHEGADA_KM: 0.35, // raio aceito entre o GPS do profissional e o imóvel ao registrar chegada
  MAX_SERVICOS_SIMULTANEOS: 3,
  // Limites de tamanho de arquivo (ambiente DEV, sem backend/storage externo:
  // tudo vira base64 no localStorage, que tem cota pequena no navegador).
  LIMITES_ARQUIVO: {
    VIDEO_MAX_MB: 8,       // vídeo contínuo da vistoria (não é compactado no cliente)
    DOCUMENTO_MAX_MB: 5,   // documentos em PDF (não são compactados, ao contrário de fotos)
    FOTO_MAX_DIMENSAO_PX: 1280, // lado maior após compressão de fotos (selfie/documentos-foto)
    FOTO_QUALIDADE: 0.72,
  },
  // Área geográfica do piloto — usada só para restringir a exibição do Mapa
  // de Oportunidades à cidade de Praia Grande/SP (limite cartográfico, não é
  // dado de negócio). Bounding box cobrindo toda a extensão urbana da orla,
  // do Canto do Forte (extremo nordeste, divisa com São Vicente) até
  // Solemar (extremo sudoeste, divisa com Mongaguá), com folga para não
  // cortar nenhum bairro nas bordas. Valores conferidos com as coordenadas
  // reais dos bairros (ex.: Canto do Forte ≈ -24.012,-46.404; Solemar ≈
  // -24.080,-46.593) — nunca reduzir esta área sem checar todos os bairros
  // cadastrados em geo.js.
  PRAIA_GRANDE_CENTRO: { lat: -24.0088, lng: -46.4127 },
  PRAIA_GRANDE_BOUNDS: {
    sw: { lat: -24.095, lng: -46.610 },
    ne: { lat: -23.985, lng: -46.385 },
  },
  // Provedor de base do mapa (visual). Histórico desta decisão:
  // 1) OpenStreetMap padrão (tile.openstreetmap.org) — sem chave, mas é uma
  //    imagem fixa por estilo (amarelo/verde), sem como recolorir para
  //    combinar com a marca.
  // 2) CARTO Positron (basemaps.cartocdn.com) — tentado para ter uma base
  //    neutra clara combinando com azul/dourado da marca, mas a CARTO
  //    passou a exigir API key (mudança de política deles, ago/2026):
  //    sem chave, os tiles vêm com marca d'água "API KEY REQUIRED" cobrindo
  //    o mapa (visto em testes reais no celular) — não dá para usar sem
  //    cadastro/token, o que é uma decisão de credencial externa fora do
  //    escopo deste ambiente DEV (não é código, é uma conta/chave a gerir).
  // 3) Revertido para OpenStreetMap padrão (opção 1): sem chave, sem
  //    dependência de credencial externa, ruas/bairros/rótulos preservados
  //    e legíveis. Personalização visual da marca fica concentrada nos
  //    marcadores/pills/filtros/cards (já com as cores oficiais) em vez da
  //    imagem de fundo. Se no futuro quiser uma base mais estilizada, dá
  //    para usar CARTO de novo com uma API key gratuita seguindo os passos
  //    em carto.com/basemaps/apikey — só precisa decidir usar e informar a
  //    chave (não deve entrar direto no código sem essa decisão).
  MAPA_TILES: {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '© OpenStreetMap',
    subdomains: 'abc',
    maxZoom: 19,
  },
};

function storageKey(tabela){
  return window.APP_CONFIG.STORAGE_PREFIX + window.APP_CONFIG.ENV + '_' + tabela;
}
