// Configuración global de RigWorld 3D (Fases 1–5: importación, esqueleto automático, animación y mundo abierto).
// Three.js se carga desde jsDelivr mediante el importmap de index.html (la versión sin internet lo lleva dentro: tools/make-offline.mjs).
// Si cambias THREE_VERSION, cámbiala también en el importmap.

export const APP = Object.freeze({ name: 'RigWorld 3D', version: '0.9.5', fase: 5 });

export const THREE_VERSION = '0.186.1';
export const THREE_CDN = `https://cdn.jsdelivr.net/npm/three@${THREE_VERSION}`;
export const DRACO_DECODER_PATH = `${THREE_CDN}/examples/jsm/libs/draco/gltf/`;

export const LIMITS = Object.freeze({
  maxFileBytes: 200 * 1024 * 1024, // límite por archivo
  chunkBytes: 10 * 1024 * 1024, // fragmentos de IndexedDB
  maxPending: 25, // archivos en cola a la vez
  workerReadyTimeoutMs: 12000,
  thumbSize: 256,
  previewTextureMax: 512,
  hugeFileBytes: 80 * 1024 * 1024, // por encima de esto se omiten texturas en la vista previa
});

// Versión del dibujo de las miniaturas: 1 = sin textura (modelos simplificados salían grises), 2 = con textura.
export const THUMB_VERSION = 2;

export const DB_INFO = Object.freeze({ name: 'rigworld3d', version: 2 });
