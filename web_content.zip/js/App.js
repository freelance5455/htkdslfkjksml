import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './lib/AuthContext.js';
import { configured } from './lib/supabase.js';
import { Blocked, ConfigMissing, Splash } from './components/Bits.js';
import Shell from './components/Shell.js';
import Welcome from './pages/Welcome.js';
import Signup from './pages/Signup.js';
import Login from './pages/Login.js';
import ResetPassword from './pages/ResetPassword.js';
import Onboarding from './pages/Onboarding.js';
import Home from './pages/Home.js';
import ServiceSellers from './pages/ServiceSellers.js';
import MyDeals from './pages/MyDeals.js';
import ServiceMap from './pages/ServiceMap.js';
import SellerProfile from './pages/SellerProfile.js';
import DealChat from './pages/DealChat.js';
import SellerDashboard from './pages/SellerDashboard.js';
import Profile from './pages/Profile.js';
import AdminLayout from './pages/admin/AdminLayout.js';
import AdminDeals from './pages/admin/AdminDeals.js';
import AdminUsers from './pages/admin/AdminUsers.js';
import AdminUserDetail from './pages/admin/AdminUserDetail.js';
import AdminServices from './pages/admin/AdminServices.js';
import AdminActivity from './pages/admin/AdminActivity.js';
import AdminMap from './pages/admin/AdminMap.js';
function Guard({ children, onboarding = false }) {
    const { session, profile, loading, signOut } = useAuth();
    if (loading)
        return _jsx(Splash, {});
    if (!session)
        return _jsx(Navigate, { to: "/login", replace: true });
    if (!profile) {
        return (_jsxs("div", { className: "splash", children: [_jsx("h2", { children: "Profile load nahi hui" }), _jsx("p", { children: "Schema SQL Supabase mein run hui hai? Dobara login karke dekhein." }), _jsx("button", { className: "btn", onClick: signOut, children: "Logout" })] }));
    }
    if (profile.is_blocked)
        return _jsx(Blocked, {});
    if (!onboarding && !profile.onboarded)
        return _jsx(Navigate, { to: "/onboarding", replace: true });
    return _jsx(_Fragment, { children: children });
}
function Root() {
    const { session, profile, loading } = useAuth();
    if (loading)
        return _jsx(Splash, {});
    if (!session)
        return _jsx(Welcome, {});
    if (profile && !profile.onboarded)
        return _jsx(Navigate, { to: "/onboarding", replace: true });
    return _jsx(Navigate, { to: profile?.role === 'seller' ? '/seller' : '/home', replace: true });
}
function AdminGuard() {
    const { profile } = useAuth();
    if (!profile?.is_admin)
        return _jsx(Navigate, { to: "/", replace: true });
    return _jsx(AdminLayout, {});
}
export default function App() {
    if (!configured)
        return _jsx(ConfigMissing, {});
    return (_jsxs(Routes, { children: [_jsx(Route, { path: "/", element: _jsx(Root, {}) }), _jsx(Route, { path: "/signup", element: _jsx(Signup, {}) }), _jsx(Route, { path: "/login", element: _jsx(Login, {}) }), _jsx(Route, { path: "/reset", element: _jsx(ResetPassword, {}) }), _jsx(Route, { path: "/onboarding", element: _jsx(Guard, { onboarding: true, children: _jsx(Onboarding, {}) }) }), _jsxs(Route, { element: _jsx(Guard, { children: _jsx(Shell, {}) }), children: [_jsx(Route, { path: "/home", element: _jsx(Home, {}) }), _jsx(Route, { path: "/service/:slug", element: _jsx(ServiceSellers, {}) }), _jsx(Route, { path: "/service/:slug/map", element: _jsx(ServiceMap, {}) }), _jsx(Route, { path: "/seller-profile/:id", element: _jsx(SellerProfile, {}) }), _jsx(Route, { path: "/deals", element: _jsx(MyDeals, {}) }), _jsx(Route, { path: "/deal/:id", element: _jsx(DealChat, {}) }), _jsx(Route, { path: "/seller", element: _jsx(SellerDashboard, {}) }), _jsx(Route, { path: "/profile", element: _jsx(Profile, {}) }), _jsxs(Route, { path: "/admin", element: _jsx(AdminGuard, {}), children: [_jsx(Route, { index: true, element: _jsx(AdminDeals, {}) }), _jsx(Route, { path: "users", element: _jsx(AdminUsers, {}) }), _jsx(Route, { path: "users/:id", element: _jsx(AdminUserDetail, {}) }), _jsx(Route, { path: "map", element: _jsx(AdminMap, {}) }), _jsx(Route, { path: "services", element: _jsx(AdminServices, {}) }), _jsx(Route, { path: "activity", element: _jsx(AdminActivity, {}) })] })] }), _jsx(Route, { path: "*", element: _jsx(Navigate, { to: "/", replace: true }) })] }));
}
