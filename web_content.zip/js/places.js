/* Network + geometry layer. Everything here is keyless and used only when the user switched on Online features. */
(function (EP) {
  const CFG = EP.config;
  const rad = d => d * Math.PI / 180;
  const clean = (s, n) => (typeof s === 'string' ? s.replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n) : '');
  const httpUrl = v => { try { const u = new URL(/^https?:\/\//i.test(v) ? v : 'https://' + v); return /^https?:$/.test(u.protocol) ? u.href.slice(0, 300) : ''; } catch (e) { return ''; } };

  function haversine(a, b) {
    const dLat = rad(b.lat - a.lat), dLon = rad(b.lon - a.lon);
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
    return 6371.0088 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  }

  async function getJson(url, opts, ms) {
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), ms || 20000);
    try { const r = await fetch(url, Object.assign({ signal: ctl.signal }, opts)); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.json(); }
    finally { clearTimeout(to); }
  }

  // ---------- place search (geocoding) ----------
  const normPlace = r => ({ id: 'g' + r.id, name: clean(r.name, 80), region: clean(r.admin1 || '', 80), cc: String(r.country_code || '').toUpperCase().slice(0, 2), lat: Number(r.latitude), lon: Number(r.longitude), tz: clean(r.timezone || '', 40), pop: Number(r.population) || 0 });
  function offlineSearch(q) {
    const n = EP.norm(q);
    return EP.cities.filter(c => Object.values(c.n).some(x => EP.norm(x).includes(n))).slice(0, 8).map(c => ({ id: 'b:' + c.id, name: c.n.en, region: '', cc: c.cc, lat: c.lat, lon: c.lon, tz: c.tz, pop: 0 }));
  }
  async function search(q, online) {
    q = q.trim();
    if (q.length < 2) return { places: [], offline: false };
    if (!online) return { places: offlineSearch(q), offline: true, needOnline: true };
    try {
      const u = `${CFG.services.geocode}?name=${encodeURIComponent(q)}&count=8&language=${EP.lang}&format=json`;
      const j = await getJson(u, {}, 10000);
      const out = (j.results || []).map(normPlace).filter(p => p.name && isFinite(p.lat) && isFinite(p.lon) && p.tz);
      return { places: out, offline: false };
    } catch (e) { return { places: offlineSearch(q), offline: true, failed: true }; }
  }

  // ---------- places of interest (OpenStreetMap via Overpass) ----------
  const SEL = {
    sights: ['[tourism~"^(attraction|museum|gallery|viewpoint|zoo|theme_park|aquarium)$"]', '[historic~"^(castle|monument|memorial|archaeological_site|ruins|fort|city_gate|manor|palace)$"]'],
    food: ['[amenity~"^(restaurant|cafe|fast_food|bar|pub)$"]'],
    stay: ['[tourism~"^(hotel|hostel|guest_house|apartment|motel)$"]']
  };
  const cache = {};
  async function overpass(query) {
    let last;
    for (const url of CFG.services.overpass) {
      try {
        const j = await getJson(url, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'data=' + encodeURIComponent(query) }, 30000);
        return j.elements || [];
      } catch (e) { last = e; }
    }
    throw last || new Error('overpass');
  }
  function normPoi(e, kind, c) {
    const t = e.tags || {}, lat = e.lat !== undefined ? e.lat : e.center && e.center.lat, lon = e.lon !== undefined ? e.lon : e.center && e.center.lon;
    if (!t.name || !isFinite(lat) || !isFinite(lon)) return null;
    const k = t.tourism || t.amenity || (t.historic ? 'historic' : '');
    const st = parseFloat(String(t.stars || '').replace(',', '.'));
    return {
      id: e.type + e.id, kind: k, name: clean(t.name, 100), lat, lon, dist: haversine(c, { lat, lon }),
      stars: st >= 1 && st <= 5 ? st : null, cuisine: clean(t.cuisine || '', 60),
      fee: t.fee === 'no' ? 'no' : t.fee === 'yes' ? 'yes' : '', wheelchair: t.wheelchair === 'yes' || t.wheelchair === 'designated',
      site: httpUrl(t.website || t['contact:website'] || ''), phone: clean(t.phone || t['contact:phone'] || '', 30), hours: clean(t.opening_hours || '', 120),
      veg: t['diet:vegetarian'] === 'yes' || t['diet:vegetarian'] === 'only' || t['diet:vegan'] === 'yes' || t['diet:vegan'] === 'only',
      vegan: t['diet:vegan'] === 'yes' || t['diet:vegan'] === 'only',
      notable: !!(t.wikidata || t.wikipedia), wiki: /^[a-z]{2,3}:.+/.test(t.wikipedia || '') ? { lang: t.wikipedia.split(':')[0], title: clean(t.wikipedia.slice(t.wikipedia.indexOf(':') + 1), 120) } : null, addr: clean([t['addr:street'], t['addr:housenumber']].filter(Boolean).join(' '), 80)
    };
  }
  async function poi(kind, place, radius) {
    const key = [kind, place.id, radius].join('|');
    const hit = cache[key];
    if (hit && Date.now() - hit.at < 10 * 60e3) return hit.items;
    const q = `[out:json][timeout:25];(${SEL[kind].map(s => `nwr(around:${radius},${place.lat},${place.lon})${s}[name];`).join('')});out center tags 400;`;
    const els = await overpass(q);
    const seen = new Set(), items = [];
    for (const e of els) { const p = normPoi(e, kind, place); if (p && !seen.has(p.name + p.kind + Math.round(p.lat * 1e4))) { seen.add(p.name + p.kind + Math.round(p.lat * 1e4)); items.push(p); } }
    cache[key] = { at: Date.now(), items };
    return items;
  }
  async function airports(place) {
    const key = 'air|' + place.id; if (cache[key] && Date.now() - cache[key].at < 3600e3) return cache[key].items;
    const els = await overpass(`[out:json][timeout:25];nwr(around:100000,${place.lat},${place.lon})[aeroway=aerodrome][iata];out center tags 30;`);
    const items = els.map(e => { const t = e.tags || {}, lat = e.lat !== undefined ? e.lat : e.center && e.center.lat, lon = e.lon !== undefined ? e.lon : e.center && e.center.lon; return isFinite(lat) && /^[A-Z]{3}$/.test(t.iata || '') ? { name: clean(t.name || t.iata, 80), iata: t.iata, dist: haversine(place, { lat, lon }) } : null; }).filter(Boolean).sort((a, b) => a.dist - b.dist).slice(0, 6);
    cache[key] = { at: Date.now(), items }; return items;
  }
  async function stations(place) {
    const key = 'sta|' + place.id; if (cache[key] && Date.now() - cache[key].at < 3600e3) return cache[key].items;
    const els = await overpass(`[out:json][timeout:25];(nwr(around:8000,${place.lat},${place.lon})[railway=station][name];nwr(around:8000,${place.lat},${place.lon})[amenity=bus_station][name];);out center tags 60;`);
    const seen = new Set();
    const items = els.map(e => { const t = e.tags || {}, lat = e.lat !== undefined ? e.lat : e.center && e.center.lat, lon = e.lon !== undefined ? e.lon : e.center && e.center.lon; if (!isFinite(lat)) return null; return { type: t.railway === 'station' ? 'train' : 'bus', name: clean(t.name, 80), lat, lon, dist: haversine(place, { lat, lon }) }; }).filter(x => { if (!x || seen.has(x.type + x.name)) return false; seen.add(x.type + x.name); return true; }).sort((a, b) => a.dist - b.dist);
    cache[key] = { at: Date.now(), items }; return items;
  }


  // ---------- photos (Wikipedia / Wikimedia Commons, online only, always credited) ----------
  const photoCache = {};
  async function wikiSummary(lang, title) {
    const key = lang + '|' + title;
    if (key in photoCache) return photoCache[key];
    photoCache[key] = null;
    if (!/^[a-z]{2,3}$/.test(lang)) return null;
    try {
      const j = await getJson(`https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, '_'))}?redirect=true`, { headers: { accept: 'application/json' } }, 10000);
      if (j.type !== 'standard' || !j.thumbnail || !/^https:\/\/upload\.wikimedia\.org\//.test(j.thumbnail.source)) return null;
      const r = { src: j.thumbnail.source, page: j.content_urls && j.content_urls.desktop ? j.content_urls.desktop.page : '', coords: j.coordinates || null };
      photoCache[key] = r; return r;
    } catch (e) { delete photoCache[key]; return null; }
  }
  const bigger = (src, w) => src.replace(/\/\d+px-/, '/' + w + 'px-');
  async function cityPhoto(place) {
    const langs = Array.from(new Set([EP.lang, 'en'])), titles = Array.from(new Set([place.name, place.region ? place.name + ', ' + place.region : '']));
    for (const l of langs) for (const ti of titles) {
      if (!ti) continue;
      const r = await wikiSummary(l, ti);
      if (r && (!r.coords || haversine(place, { lat: r.coords.lat, lon: r.coords.lon }) < 60)) return { src: bigger(r.src, 960), page: r.page };
    }
    return null;
  }
  async function poiPhoto(wiki) { const r = await wikiSummary(wiki.lang, wiki.title); return r ? { src: bigger(r.src, 400), page: r.page } : null; }

  // ---------- planning helpers ----------
  const SPEED = { flight: { kmh: 780, extra: 2.5, factor: 1 }, train: { kmh: 120, extra: 0.25, factor: 1.2 }, bus: { kmh: 70, extra: 0.25, factor: 1.25 }, car: { kmh: 85, extra: 0, factor: 1.2 } };
  function estimate(mode, km) { const s = SPEED[mode]; return Math.round(((km * s.factor) / s.kmh + s.extra) * 12) / 12; } // hours, rounded to 5 min
  function orderByProximity(items) {
    const left = items.slice(), out = [left.shift()];
    while (left.length) { const last = out[out.length - 1]; let bi = 0, bd = Infinity; left.forEach((x, i) => { const d = haversine(last, x); if (d < bd) { bd = d; bi = i; } }); out.push(left.splice(bi, 1)[0]); }
    return out;
  }
  const enc = encodeURIComponent;
  const links = {
    rome2rio: (a, b) => `https://www.rome2rio.com/map/${enc(a)}/${enc(b)}`,
    flights: (a, b, d) => `https://www.google.com/travel/flights?q=${enc(`Flights from ${a} to ${b}${d ? ' on ' + d : ''}`)}`,
    trains: () => 'https://www.thetrainline.com/', buses: () => 'https://www.flixbus.com/',
    hotels: (c, i, o, n, cur) => `https://www.booking.com/searchresults.html?ss=${enc(c)}${i ? '&checkin=' + enc(i) : ''}${o ? '&checkout=' + enc(o) : ''}&group_adults=${n || 2}&no_rooms=1${cur ? '&selected_currency=' + enc(cur) : ''}`,
    tours: c => `https://www.getyourguide.com/s/?q=${enc(c)}`,
    tables: c => `https://www.google.com/maps/search/?api=1&query=${enc('restaurants in ' + c)}`,
    dir: p => `https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lon}`,
    osm: p => `https://www.openstreetmap.org/?mlat=${p.lat}&mlon=${p.lon}#map=15/${p.lat}/${p.lon}`
  };
  EP.norm = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  EP.api = { search, poi, airports, stations, haversine, estimate, orderByProximity, links, normPlace, cityPhoto, poiPhoto };
})(window.EP = window.EP || {});
