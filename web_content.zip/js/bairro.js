/* ============================================================
   bairro.js — Fase 2: fofocas, quadro de pedidos, tampinhas,
   álbum de figurinhas e festas do calendário.
   Carregar DEPOIS de life.js e ANTES de world.js.
   ============================================================ */

/* ---------- Fofocas do bairro ---------- */
const GOSSIP = [
  { id: 'g1', who: 'zeca', dayMin: 1,
    text: { pt: 'Dizem que o Bigode esconde um baralho marcado atrás do balcão. Ninguém nunca achou.', en: 'They say Bigode hides a marked deck behind the counter. Nobody ever found it.', es: 'Dicen que Bigode esconde un mazo marcado detrás de la barra. Nadie lo encontró.' },
    reward: { rep: 1 } },
  { id: 'g2', who: 'dona', dayMin: 1,
    text: { pt: 'A Dona Ivete perdeu o neto no fliperama por três horas. Ele zerou tudo e ela nem briga mais.', en: 'Dona Ivete lost her grandson at the arcade for three hours. He beat every machine and she does not even scold him anymore.', es: 'Doña Ivete perdió al nieto en el fliper por tres horas. Se pasó todo y ya ni le retan.' },
    reward: { money: 5 } },
  { id: 'g3', who: 'bereba', dayMin: 2,
    text: { pt: 'O Bereba deve pro Bigode desde 2019. Toda mão que ele ganha, uma cerveja some da conta.', en: 'Bereba has owed Bigode since 2019. Every hand he wins, one beer disappears from the tab.', es: 'Bereba le debe a Bigode desde 2019. Cada mano que gana, una cerveza desaparece de la cuenta.' },
    reward: { rep: 1 } },
  { id: 'g4', who: 'padre', dayMin: 2,
    text: { pt: 'O Padre Anselmo joga mineiro na sacristia com os coroinhas. Diz que é “estudo bíblico”.', en: 'Father Anselmo plays Mineiro in the sacristy with the altar boys. He calls it “Bible study”.', es: 'El Padre Anselmo juega Mineiro en la sacristía con los monaguillos. Dice que es “estudio bíblico”.' },
    reward: { money: 8 } },
  { id: 'g5', who: 'dudu', dayMin: 3,
    text: { pt: 'O Dudu botou o recorde do fliperama e depois apagou o nome. Não quer concorrência.', en: 'Dudu set the arcade record and then erased the name. He wants no competition.', es: 'Dudu puso el récord del fliper y después borró el nombre. No quiere competencia.' },
    reward: { rep: 2 } },
  { id: 'g6', who: 'taxi', dayMin: 4,
    text: { pt: 'O Pilantra do Ponto já perdeu a kombi numa mão de truco em 2008. Até hoje dirige a do primo.', en: 'The Point Hustler lost his van in a truco hand in 2008. To this day he drives his cousin’s.', es: 'El Pilantra del Punto perdió la combi en una mano de truco en 2008. Hasta hoy maneja la del primo.' },
    reward: { money: 10 } },
  { id: 'g7', who: 'cotinha', dayMin: 5,
    text: { pt: 'A Vó Cotinha nunca perdeu em casa. O segredo? O chá que ela serve deixa o adversário lerdo.', en: 'Grandma Cotinha never lost at home. The secret? The tea she serves makes the opponent slow.', es: 'La Abuela Cotinha nunca perdió en casa. ¿El secreto? El té que sirve deja lento al rival.' },
    reward: { rep: 2 } },
  { id: 'g8', who: 'dj', dayMin: 6,
    text: { pt: 'No baile do DJ Naipe, quem pede truco no grave alto ganha +1 de pressão. É lenda urbana.', en: 'At DJ Naipe’s party, whoever calls truco on a loud bass drop gets +1 pressure. Urban legend.', es: 'En el baile de DJ Naipe, quien pide truco en el grave fuerte gana +1 de presión. Leyenda urbana.' },
    reward: { money: 12 } },
  { id: 'g9', who: 'nogueira', dayMin: 7,
    text: { pt: 'O Doutor Nogueira tem três troféus e zero amigos no clube. Só joga pra manter a estante cheia.', en: 'Doctor Nogueira has three trophies and zero friends at the club. He only plays to keep the shelf full.', es: 'El Doctor Nogueira tiene tres trofeos y cero amigos en el club. Solo juega para llenar el estante.' },
    reward: { rep: 3 } },
  { id: 'g10', who: 'lenda', dayMin: 8,
    text: { pt: 'A Lenda do Norte sumiu por dois anos. Voltou com um baralho novo e uma cicatriz na mão esquerda.', en: 'The Northern Legend vanished for two years. Came back with a new deck and a scar on the left hand.', es: 'La Leyenda del Norte desapareció dos años. Volvió con un mazo nuevo y una cicatriz en la mano izquierda.' },
    reward: { money: 15, rep: 2 } },
];

/* ---------- Quadro de pedidos ---------- */
const BOARD_POOL = [
  { id: 'p1', kind: 'win', target: 'zeca', label: { pt: 'Ganhe do Zeca da Esquina', en: 'Beat Zeca da Esquina', es: 'Ganá a Zeca da Esquina' }, reward: { money: 15, rep: 1 }, days: 2 },
  { id: 'p2', kind: 'win', target: 'bereba', label: { pt: 'Derrube o Bereba no balcão', en: 'Take down Bereba at the bar', es: 'Tumbar a Bereba en la barra' }, reward: { money: 20, rep: 1 }, days: 2 },
  { id: 'p3', kind: 'win', target: 'dudu', label: { pt: 'Zere o Dudu no fliperama', en: 'Beat Dudu at the arcade', es: 'Ganá a Dudu en el fliper' }, reward: { money: 25, rep: 2 }, days: 2 },
  { id: 'p4', kind: 'talk', target: 'padre', label: { pt: 'Converse com o Padre Anselmo', en: 'Talk to Father Anselmo', es: 'Hablá con el Padre Anselmo' }, reward: { money: 10 }, days: 2 },
  { id: 'p5', kind: 'talk', target: 'dona', label: { pt: 'Cumprimente a Dona Ivete', en: 'Greet Dona Ivete', es: 'Saludá a Doña Ivete' }, reward: { money: 8 }, days: 2 },
  { id: 'p6', kind: 'caps', need: 3, label: { pt: 'Ache 3 tampinhas na cidade', en: 'Find 3 bottle caps in town', es: 'Encontrá 3 tapitas en el pueblo' }, reward: { money: 20 }, days: 3 },
  { id: 'p7', kind: 'win', target: 'kombi', label: { pt: 'Ganhe do Tião da Kombi', en: 'Beat Tião da Kombi', es: 'Ganá a Tião da Kombi' }, reward: { money: 30, rep: 2 }, days: 2 },
  { id: 'p8', kind: 'streak', need: 2, label: { pt: 'Vença 2 partidas seguidas', en: 'Win 2 matches in a row', es: 'Ganá 2 partidas seguidas' }, reward: { money: 25, rep: 2 }, days: 3 },
  { id: 'p9', kind: 'win', target: 'dete', label: { pt: 'Quebre a banca da Dete', en: 'Break Dete’s bank', es: 'Romé la banca de Dete' }, reward: { money: 35, rep: 2 }, days: 2 },
  { id: 'p10', kind: 'caps', need: 5, label: { pt: 'Colete 5 tampinhas', en: 'Collect 5 bottle caps', es: 'Juntá 5 tapitas' }, reward: { money: 40, rep: 1 }, days: 3 },
  { id: 'p11', kind: 'talk', target: 'cotinha', label: { pt: 'Visite a Vó Cotinha', en: 'Visit Grandma Cotinha', es: 'Visitá a la Abuela Cotinha' }, reward: { money: 15, rep: 1 }, days: 2 },
  { id: 'p12', kind: 'win', target: 'taxi', label: { pt: 'Ganhe do Pilantra do Ponto', en: 'Beat the Point Hustler', es: 'Ganá al Pilantra del Punto' }, reward: { money: 50, rep: 3 }, days: 2 },
];

/* ---------- Tampinhas (30 posições pela cidade) ---------- */
const CAP_SPOTS = [
  { x: 8, y: 12 }, { x: 18, y: 15 }, { x: 32, y: 11 }, { x: 40, y: 20 }, { x: 55, y: 14 },
  { x: 6, y: 24 }, { x: 22, y: 26 }, { x: 38, y: 28 }, { x: 50, y: 22 }, { x: 60, y: 18 },
  { x: 12, y: 40 }, { x: 28, y: 38 }, { x: 42, y: 45 }, { x: 55, y: 42 }, { x: 65, y: 36 },
  { x: 10, y: 55 }, { x: 20, y: 52 }, { x: 35, y: 58 }, { x: 48, y: 54 }, { x: 58, y: 50 },
  { x: 8, y: 72 }, { x: 24, y: 70 }, { x: 38, y: 76 }, { x: 50, y: 68 }, { x: 62, y: 74 },
  { x: 15, y: 86 }, { x: 30, y: 88 }, { x: 45, y: 84 }, { x: 55, y: 90 }, { x: 66, y: 82 },
];

/* ---------- Álbum de figurinhas (36) ---------- */
const STICKERS = [
  // página 1 — Vila
  { id: 's_zeca', page: 0, name: { pt: 'Zeca da Esquina', en: 'Zeca da Esquina', es: 'Zeca da Esquina' }, rare: false },
  { id: 's_dona', page: 0, name: { pt: 'Dona Ivete', en: 'Dona Ivete', es: 'Doña Ivete' }, rare: false },
  { id: 's_bereba', page: 0, name: { pt: 'Nego Bereba', en: 'Nego Bereba', es: 'Nego Bereba' }, rare: false },
  { id: 's_dudu', page: 0, name: { pt: 'Dudu do Fliperama', en: 'Dudu', es: 'Dudu' }, rare: false },
  { id: 's_bigode', page: 0, name: { pt: 'Bigode, o Dono', en: 'Bigode', es: 'Bigode' }, rare: true },
  { id: 's_boteco', page: 0, name: { pt: 'Boteco do Bereba', en: 'Bereba’s Bar', es: 'Bar de Bereba' }, rare: false },
  // página 2 — Centro
  { id: 's_padre', page: 1, name: { pt: 'Padre Anselmo', en: 'Father Anselmo', es: 'Padre Anselmo' }, rare: false },
  { id: 's_kombi', page: 1, name: { pt: 'Tião da Kombi', en: 'Tião da Kombi', es: 'Tião da Kombi' }, rare: false },
  { id: 's_dete', page: 1, name: { pt: 'Dete da Lotérica', en: 'Dete', es: 'Dete' }, rare: false },
  { id: 's_sindico', page: 1, name: { pt: 'Seu Valdir', en: 'Seu Valdir', es: 'Seu Valdir' }, rare: false },
  { id: 's_feira', page: 1, name: { pt: 'Feirante', en: 'Market Vendor', es: 'Feriante' }, rare: false },
  { id: 's_nogueira', page: 1, name: { pt: 'Doutor Nogueira', en: 'Doctor Nogueira', es: 'Doctor Nogueira' }, rare: true },
  // página 3 — Morro
  { id: 's_taxi', page: 2, name: { pt: 'Pilantra do Ponto', en: 'Point Hustler', es: 'Pilantra del Punto' }, rare: false },
  { id: 's_dj', page: 2, name: { pt: 'DJ Naipe', en: 'DJ Naipe', es: 'DJ Naipe' }, rare: false },
  { id: 's_cotinha', page: 2, name: { pt: 'Vó Cotinha', en: 'Grandma Cotinha', es: 'Abuela Cotinha' }, rare: false },
  { id: 's_lenda', page: 2, name: { pt: 'A Lenda do Norte', en: 'Northern Legend', es: 'Leyenda del Norte' }, rare: true },
  { id: 's_baile', page: 2, name: { pt: 'Baile do Morro', en: 'Hill Party', es: 'Baile del Cerro' }, rare: false },
  { id: 's_arena', page: 2, name: { pt: 'Arena do Ás', en: 'Ace Arena', es: 'Arena del As' }, rare: false },
  // página 4 — Jogadas
  { id: 's_truco', page: 3, name: { pt: 'Pedido de Truco', en: 'Truco Call', es: 'Pedido de Truco' }, rare: false },
  { id: 's_seis', page: 3, name: { pt: 'Seis!', en: 'Six!', es: '¡Seis!' }, rare: false },
  { id: 's_doze', page: 3, name: { pt: 'Doze na mesa', en: 'Twelve on the table', es: 'Doce en la mesa' }, rare: true },
  { id: 's_ferro', page: 3, name: { pt: 'Mão de Ferro', en: 'Iron Hand', es: 'Mano de Hierro' }, rare: true },
  { id: 's_blefe', page: 3, name: { pt: 'Blefe pesado', en: 'Heavy bluff', es: 'Farol pesado' }, rare: false },
  { id: 's_zap', page: 3, name: { pt: 'Zap na mesa', en: 'Zap on the table', es: 'Zap en la mesa' }, rare: false },
  // página 5 — Cidade
  { id: 's_hotel', page: 4, name: { pt: 'Hotel Cornélio', en: 'Cornélio Hotel', es: 'Hotel Cornelio' }, rare: false },
  { id: 's_praca', page: 4, name: { pt: 'Praça da Fonte', en: 'Fountain Square', es: 'Plaza de la Fuente' }, rare: false },
  { id: 's_igreja', page: 4, name: { pt: 'Igreja do Centro', en: 'Downtown Church', es: 'Iglesia del Centro' }, rare: false },
  { id: 's_noite', page: 4, name: { pt: 'Noite no boteco', en: 'Night at the bar', es: 'Noche en el bar' }, rare: false },
  { id: 's_chuva', page: 4, name: { pt: 'Truco na chuva', en: 'Truco in the rain', es: 'Truco bajo la lluvia' }, rare: true },
  { id: 's_radio', page: 4, name: { pt: 'Rádio do Bairro', en: 'Neighborhood Radio', es: 'Radio del Barrio' }, rare: false },
  // página 6 — Lendas
  { id: 's_forasteiro', page: 5, name: { pt: 'O Forasteiro', en: 'The Stranger', es: 'El Forastero' }, rare: true },
  { id: 's_rei', page: 5, name: { pt: 'Rei do Truco', en: 'Truco King', es: 'Rey del Truco' }, rare: true },
  { id: 's_parceiro', page: 5, name: { pt: 'Parceiro de Ferro', en: 'Iron Partner', es: 'Compañero de Hierro' }, rare: false },
  { id: 's_tampinha', page: 5, name: { pt: 'Caçador de Tampinhas', en: 'Cap Hunter', es: 'Cazador de Tapitas' }, rare: false },
  { id: 's_fofoca', page: 5, name: { pt: 'Ouvidoria do Bairro', en: 'Town Gossip', es: 'Chismógrafo' }, rare: false },
  { id: 's_festa', page: 5, name: { pt: 'Festa na Rua', en: 'Street Party', es: 'Fiesta en la Calle' }, rare: true },
];

/* ---------- Festas do calendário (data real do aparelho) ---------- */
const FESTIVALS = [
  { id: 'carnaval', months: [2, 3], ico: '🎭', name: { pt: 'Carnaval', en: 'Carnival', es: 'Carnaval' },
    mods: { turn: 3, coins: 4, repMult: 1.3 }, eventForce: 'festa' },
  { id: 'junina', months: [6, 7], ico: '🌽', name: { pt: 'Festa Junina', en: 'June Festival', es: 'Fiesta Junina' },
    mods: { turn: 2, coins: 3, payMult: 1.25 }, eventForce: 'feira' },
  { id: 'copa', months: [6, 7, 11, 12], ico: '⚽', name: { pt: 'Clima de Copa', en: 'World Cup Fever', es: 'Clima de Copa' },
    mods: { repMult: 1.4, edge: 0.05 }, eventForce: 'quente' },
  { id: 'natal', months: [12, 1], ico: '🎄', name: { pt: 'Natal', en: 'Christmas', es: 'Navidad' },
    mods: { cash: 15, coins: 5, payMult: 1.5 }, eventForce: 'pago' },
];

const Bairro = {
  /* estado */
  gossipSeen: {},       // id -> true
  gossipDay: 0,         // último dia que gerou fofoca
  todayGossip: null,    // id da fofoca do dia
  board: [],            // [{...pedido, expires, progress, done}]
  boardDay: 0,
  caps: {},             // "x,y" -> true (coletada)
  capCount: 0,
  stickers: {},         // id -> count (0 = não tem, 1+ = tem, extras = troca)
  packPending: 0,       // pacotinhos a abrir
  winStreak: 0,
  talksToday: {},       // id npc -> true (para pedidos de talk)

  /* ---------- Fofocas ---------- */
  lang() { return (typeof T !== 'undefined' && T.lang) || 'pt'; },

  rollGossip(day) {
    if (this.gossipDay === day && this.todayGossip) return this.todayGossip;
    const pool = GOSSIP.filter((g) => day >= g.dayMin && !this.gossipSeen[g.id]);
    const pick = pool.length ? pool[Math.floor(Math.random() * pool.length)] : GOSSIP[Math.floor(Math.random() * GOSSIP.length)];
    this.todayGossip = pick.id;
    this.gossipDay = day;
    return pick.id;
  },

  gossipOfDay(day) {
    const id = this.rollGossip(day);
    return GOSSIP.find((g) => g.id === id) || GOSSIP[0];
  },

  hearGossip(day) {
    const g = this.gossipOfDay(day);
    if (this.gossipSeen[g.id]) return { g, fresh: false };
    this.gossipSeen[g.id] = true;
    return { g, fresh: true };
  },

  gossipText(g) {
    return (g.text && (g.text[this.lang()] || g.text.pt)) || '';
  },

  /* ---------- Quadro de pedidos ---------- */
  refreshBoard(day) {
    if (this.boardDay === day && this.board.length) return;
    // remove expirados
    this.board = this.board.filter((p) => p.expires >= day && !p.done);
    if (this.board.length >= 3) { this.boardDay = day; return; }
    const used = new Set(this.board.map((p) => p.id));
    const pool = BOARD_POOL.filter((p) => !used.has(p.id));
    while (this.board.length < 3 && pool.length) {
      const i = Math.floor(Math.random() * pool.length);
      const base = pool.splice(i, 1)[0];
      this.board.push({
        ...base,
        expires: day + (base.days || 2),
        progress: 0,
        done: false,
        claimed: false,
      });
    }
    this.boardDay = day;
  },

  boardLabel(p) {
    return (p.label && (p.label[this.lang()] || p.label.pt)) || p.id;
  },

  onWinNpc(npcId, day) {
    this.winStreak = (this.winStreak || 0) + 1;
    for (const p of this.board) {
      if (p.done || p.expires < day) continue;
      if (p.kind === 'win' && p.target === npcId) { p.progress = 1; p.done = true; }
      if (p.kind === 'streak' && this.winStreak >= (p.need || 2)) { p.progress = p.need; p.done = true; }
    }
  },

  onLoseMatch() {
    this.winStreak = 0;
  },

  onTalkNpc(npcId, day) {
    this.talksToday[npcId] = true;
    for (const p of this.board) {
      if (p.done || p.expires < day) continue;
      if (p.kind === 'talk' && p.target === npcId) { p.progress = 1; p.done = true; }
    }
  },

  onCapCollect(day) {
    for (const p of this.board) {
      if (p.done || p.expires < day) continue;
      if (p.kind === 'caps') {
        p.progress = this.capCount;
        if (this.capCount >= (p.need || 3)) p.done = true;
      }
    }
  },

  claimBoard(idx, world) {
    const p = this.board[idx];
    if (!p || !p.done || p.claimed) return null;
    p.claimed = true;
    const r = p.reward || {};
    if (r.money && world) world.money += r.money;
    if (r.rep && world) world.rep += r.rep;
    return r;
  },

  /* ---------- Tampinhas ---------- */
  capKey(x, y) { return x + ',' + y; },

  isCapTaken(x, y) { return !!this.caps[this.capKey(x, y)]; },

  takeCap(x, y, day) {
    const k = this.capKey(x, y);
    if (this.caps[k]) return false;
    this.caps[k] = true;
    this.capCount++;
    this.onCapCollect(day);
    // figurinha de caçador
    if (this.capCount >= 5) this.giveSticker('s_tampinha');
    if (this.capCount >= 15) this.giveSticker('s_tampinha');
    return true;
  },

  remainingCaps() {
    return CAP_SPOTS.filter((c) => !this.isCapTaken(c.x, c.y));
  },

  /* ---------- Álbum ---------- */
  giveSticker(id, n) {
    n = n || 1;
    this.stickers[id] = (this.stickers[id] || 0) + n;
  },

  hasSticker(id) { return (this.stickers[id] || 0) > 0; },

  openPack() {
    if (this.packPending <= 0) return [];
    this.packPending--;
    const got = [];
    for (let i = 0; i < 3; i++) {
      // 12% rare
      const pool = Math.random() < 0.12 ? STICKERS.filter((s) => s.rare) : STICKERS;
      const s = pool[Math.floor(Math.random() * pool.length)];
      this.giveSticker(s.id);
      got.push(s);
    }
    // check album milestones
    const owned = STICKERS.filter((s) => this.hasSticker(s.id)).length;
    if (owned >= 12) this.giveSticker('s_fofoca');
    if (owned >= 24) this.giveSticker('s_radio');
    if (owned >= 36) this.giveSticker('s_rei');
    return got;
  },

  onMatchWin(npcId) {
    this.packPending++;
    // chance de figurinha do personagem
    const map = {
      zeca: 's_zeca', dona: 's_dona', bereba: 's_bereba', dudu: 's_dudu', bigode: 's_bigode',
      padre: 's_padre', kombi: 's_kombi', dete: 's_dete', sindico: 's_sindico', feira: 's_feira',
      nogueira: 's_nogueira', taxi: 's_taxi', dj: 's_dj', cotinha: 's_cotinha', lenda: 's_lenda',
    };
    if (map[npcId] && Math.random() < 0.45) this.giveSticker(map[npcId]);
    if (npcId === 'bigode' || npcId === 'nogueira' || npcId === 'lenda') this.giveSticker('s_forasteiro');
  },

  albumProgress() {
    const owned = STICKERS.filter((s) => this.hasSticker(s.id)).length;
    return { owned, total: STICKERS.length };
  },

  /* ---------- Festas ---------- */
  currentFestival(date) {
    date = date || new Date();
    const m = date.getMonth() + 1; // 1-12
    // prioridade: natal > carnaval > junina > copa
    for (const f of FESTIVALS) {
      if (f.months.includes(m)) return f;
    }
    return null;
  },

  festivalMods() {
    const f = this.currentFestival();
    return f ? (f.mods || {}) : {};
  },

  festivalName() {
    const f = this.currentFestival();
    if (!f) return null;
    return (f.name[this.lang()] || f.name.pt) + ' ' + f.ico;
  },

  /* ---------- serialização ---------- */
  data() {
    return {
      gossipSeen: this.gossipSeen,
      gossipDay: this.gossipDay,
      todayGossip: this.todayGossip,
      board: this.board,
      boardDay: this.boardDay,
      caps: this.caps,
      capCount: this.capCount,
      stickers: this.stickers,
      packPending: this.packPending,
      winStreak: this.winStreak,
    };
  },

  load(d) {
    if (!d) return;
    this.gossipSeen = d.gossipSeen || {};
    this.gossipDay = d.gossipDay || 0;
    this.todayGossip = d.todayGossip || null;
    this.board = d.board || [];
    this.boardDay = d.boardDay || 0;
    this.caps = d.caps || {};
    this.capCount = d.capCount || 0;
    this.stickers = d.stickers || {};
    this.packPending = d.packPending || 0;
    this.winStreak = d.winStreak || 0;
  },

  reset() {
    this.gossipSeen = {};
    this.gossipDay = 0;
    this.todayGossip = null;
    this.board = [];
    this.boardDay = 0;
    this.caps = {};
    this.capCount = 0;
    this.stickers = {};
    this.packPending = 0;
    this.winStreak = 0;
    this.talksToday = {};
  },
};

window.Bairro = Bairro;
window.GOSSIP = GOSSIP;
window.BOARD_POOL = BOARD_POOL;
window.CAP_SPOTS = CAP_SPOTS;
window.STICKERS = STICKERS;
window.FESTIVALS = FESTIVALS;
