/* =========================================================================
   Aethervale — Bestiary, Bos, Senjata, Zirah, Skill
   Semua dibangkitkan deterministik agar 64 bioma punya 15 mob + 1 bos sendiri.
   ========================================================================= */

/* ---------- tier kesulitan per bioma ---------- */
const BIOME_TIER = (() => {
  const T = {};
  const table = {
    // overworld ringan
    meadow: 1, plains: 1, sunflower_plains: 1, beach: 1, river: 1, flower_forest: 2, cherry_grove: 2,
    forest: 2, birch_forest: 2, sparse_jungle: 3, taiga: 3, windswept_hills: 3, windswept_forest: 3,
    old_growth_birch_forest: 3, mushroom_fields: 3, stony_shore: 3, lukewarm_ocean: 3, warm_ocean: 3, ocean: 3,
    swamp: 4, mangrove_swamp: 4, jungle: 4, bamboo_jungle: 4, dark_forest: 5, pale_garden: 5,
    old_growth_pine_taiga: 4, old_growth_spruce_taiga: 5, windswept_gravelly_hills: 4,
    savanna: 4, savanna_plateau: 4, windswept_savanna: 5, desert: 4, badlands: 5, wooded_badlands: 5, eroded_badlands: 6,
    snowy_plains: 4, snowy_beach: 4, snowy_taiga: 5, grove: 5, snowy_slopes: 6, ice_spikes: 6,
    stony_peaks: 6, frozen_peaks: 7, jagged_peaks: 7, frozen_river: 5,
    deep_ocean: 6, deep_lukewarm_ocean: 6, cold_ocean: 5, deep_cold_ocean: 6, frozen_ocean: 6, deep_frozen_ocean: 7,
    dripstone_caves: 6, lush_caves: 6, deep_dark: 9,
    nether_wastes: 8, crimson_forest: 8, warped_forest: 8, soul_sand_valley: 9, basalt_deltas: 9,
    the_end: 9, small_end_islands: 9, end_midlands: 10, end_highlands: 10, end_barrens: 10,
  };
  for (const id in BIOMES) T[id] = table[id] || 4;
  return T;
})();

/* ---------- 15 arketipe mob (setiap bioma memakai ke-15 dengan rasa lokal) ---------- */
const MOB_ARCHETYPES = [
  { noun: 'Slime',      art: 'slime',    hp: 0.7,  atk: 0.7, def: 0.6, spd: 30, r: 7,  drop: 'm_dust' },
  { noun: 'Kelelawar',  art: 'wisp',     hp: 0.55, atk: 0.8, def: 0.4, spd: 74, r: 6,  drop: 'm_dust' },
  { noun: 'Laba-laba',  art: 'lurker',   hp: 0.8,  atk: 0.9, def: 0.7, spd: 62, r: 8,  drop: 'm_pelt' },
  { noun: 'Babi Liar',  art: 'boar',     hp: 1.1,  atk: 0.9, def: 0.9, spd: 48, r: 8,  drop: 'm_pelt' },
  { noun: 'Serigala',   art: 'wolf',     hp: 0.95, atk: 1.1, def: 0.8, spd: 70, r: 9,  drop: 'm_pelt' },
  { noun: 'Pengintai',  art: 'lurker',   hp: 1.25, atk: 1.0, def: 1.1, spd: 50, r: 10, drop: 'm_relic' },
  { noun: 'Perampok',   art: 'bandit',   hp: 1.15, atk: 1.2, def: 1.0, spd: 66, r: 9,  drop: 'm_stone' },
  { noun: 'Wisp',       art: 'wisp',     hp: 0.75, atk: 1.3, def: 0.5, spd: 58, r: 7,  drop: 'm_enchant', ranged: true },
  { noun: 'Kalajengking',art: 'lurker',  hp: 1.0,  atk: 1.35,def: 1.2, spd: 56, r: 8,  drop: 'm_stone' },
  { noun: 'Arwah',       art: 'revenant',hp: 1.2,  atk: 1.4, def: 0.9, spd: 60, r: 9,  drop: 'm_essence', ranged: true },
  { noun: 'Iblis',       art: 'fiend',   hp: 1.4,  atk: 1.5, def: 1.2, spd: 62, r: 10, drop: 'm_ashcore' },
  { noun: 'Penjaga Batu',art: 'golem',   hp: 2.0,  atk: 1.3, def: 2.0, spd: 34, r: 13, drop: 'm_stone_hi' },
  { noun: 'Pemburu',     art: 'bandit',  hp: 1.35, atk: 1.6, def: 1.3, spd: 72, r: 9,  drop: 'm_protect' },
  { noun: 'Momok',       art: 'rift',    hp: 1.5,  atk: 1.7, def: 1.3, spd: 64, r: 10, drop: 'm_riftshard', ranged: true },
  { noun: 'Bangkit Purba',art: 'revenant',hp: 1.9, atk: 1.9, def: 1.6, spd: 58, r: 11, drop: 'm_essence' },
];

/* pewarnaan mob mengikuti palet bioma */
function mobColor(b, i) {
  const pool = [b.accent, b.tree, b.water, b.rock, b.ground[0], b.flower[0] || b.accent];
  return pool[i % pool.length];
}

/* ---------- daftar mob: 15 per bioma ---------- */
const MOBS_BY_BIOME = {};
(function buildMobs() {
  for (const id in BIOMES) {
    const b = BIOMES[id], tier = BIOME_TIER[id];
    const list = [];
    MOB_ARCHETYPES.forEach((a, i) => {
      const mid = `m_${id}_${i}`;
      const t = tier + i * 0.22;                        // mob makin ke atas makin berat
      const hp = Math.round(26 * a.hp * Math.pow(1.42, t));
      const atk = Math.round(5 * a.atk * Math.pow(1.3, t));
      const def = Math.round(1.6 * a.def * Math.pow(1.26, t));
      const xp = Math.round(10 * Math.pow(1.34, t) * (a.hp + a.atk) / 2);
      const g0 = Math.round(5 * Math.pow(1.32, t));
      ENEMIES[mid] = {
        name: `${a.noun} ${b.name}`, art: a.art, hp, atk, def, xp,
        gold: [g0, Math.round(g0 * 2.1)], spd: a.spd, r: a.r,
        color: mobColor(b, i), biome: id, ranged: !!a.ranged, tier: t,
        drops: [
          [a.drop, 0.42, 1, 2],
          ['m_dust', 0.5, 1, 3],
          [tier >= 7 ? 'p_potion_hi' : 'p_potion', 0.11, 1, 1],
          [tier >= 8 ? 'm_riftshard' : tier >= 5 ? 'm_frost' : 'm_stone', 0.09, 1, 1],
        ],
      };
      list.push(mid);
    });
    MOBS_BY_BIOME[id] = list;
    b.enemies = list.slice();                            // spawner memakai daftar ini
  }
})();

/* ---------- 17 pedang (16 dari bos + 1 rahasia) ---------- */
/* fx: efek unik; snd: karakter suara (dipakai AudioEngine) */
const SWORDS = [
  { id:'sw_ember',   name:'Nyala Serambi',        fx:'burn',    tier:3, stats:{atk:34, crit:5},              snd:{w:'sawtooth', f:210, s:0.45, n:0.30, ring:760,  d:0.20}, desc:'Membakar target: 6 kerusakan/detik selama 3 detik.' },
  { id:'sw_storm',   name:'Bilah Badai Pesisir',  fx:'chain',   tier:4, stats:{atk:42, haste:8},             snd:{w:'square',   f:520, s:2.2,  n:0.22, ring:1600, d:0.16}, desc:'Petir menyambar 3 musuh terdekat (45% kerusakan).' },
  { id:'sw_frost',   name:'Taring Beku Puncak',   fx:'freeze',  tier:4, stats:{atk:46, critdmg:18},          snd:{w:'triangle', f:320, s:0.6,  n:0.34, ring:2100, d:0.26}, desc:'Memperlambat musuh 45% selama 2,5 detik.' },
  { id:'sw_venom',   name:'Sengat Bakau',         fx:'poison',  tier:4, stats:{atk:40, life:4},              snd:{w:'sine',     f:180, s:0.7,  n:0.26, ring:540,  d:0.24}, desc:'Racun menumpuk hingga 5 tingkat (4/detik per tingkat).' },
  { id:'sw_shadow',  name:'Bilah Bayang Kelam',   fx:'shadow',  tier:5, stats:{atk:52, crit:10},             snd:{w:'sawtooth', f:140, s:0.35, n:0.40, ring:420,  d:0.22}, desc:'+60% kerusakan bila menyerang dari belakang.' },
  { id:'sw_gale',    name:'Pedang Gelombang',     fx:'wind',    tier:5, stats:{atk:50, spd:8},               snd:{w:'sine',     f:640, s:0.3,  n:0.45, ring:1200, d:0.18}, desc:'Melepas sabetan angin jarak jauh setiap tebasan.' },
  { id:'sw_blood',   name:'Bilah Darah Rawa',     fx:'vampiric',tier:5, stats:{atk:56, life:8},              snd:{w:'square',   f:160, s:0.5,  n:0.34, ring:600,  d:0.24}, desc:'Menyerap 10% kerusakan menjadi HP.' },
  { id:'sw_quake',   name:'Godam Gempa Batu',     fx:'quake',   tier:6, stats:{atk:66, def:10},              snd:{w:'sawtooth', f:96,  s:0.4,  n:0.55, ring:260,  d:0.34}, desc:'Gelombang kejut area setiap pukulan.' },
  { id:'sw_holy',    name:'Pedang Fajar Suci',    fx:'holy',    tier:6, stats:{atk:64, hp:80},               snd:{w:'triangle', f:760, s:1.6,  n:0.18, ring:2400, d:0.28}, desc:'Cahaya menghukum: +80% kerusakan ke arwah & iblis.' },
  { id:'sw_bleed',   name:'Sabit Rimba Purba',    fx:'bleed',   tier:6, stats:{atk:70, crit:9},              snd:{w:'sawtooth', f:300, s:0.55, n:0.38, ring:900,  d:0.20}, desc:'Pendarahan 8% kerusakan/detik selama 4 detik.' },
  { id:'sw_break',   name:'Pemecah Puncak',       fx:'stun',    tier:7, stats:{atk:82, critdmg:26},          snd:{w:'square',   f:120, s:0.42, n:0.5,  ring:340,  d:0.32}, desc:'25% peluang memingsankan musuh 1,2 detik.' },
  { id:'sw_sand',    name:'Bilah Badai Pasir',    fx:'sandstorm',tier:7,stats:{atk:78, haste:12},            snd:{w:'sine',     f:420, s:0.28, n:0.6,  ring:1500, d:0.22}, desc:'Pusaran pasir mengikis semua musuh di sekitar.' },
  { id:'sw_magma',   name:'Pedang Inti Magma',    fx:'magma',   tier:8, stats:{atk:96, hp:120},              snd:{w:'sawtooth', f:150, s:0.6,  n:0.42, ring:520,  d:0.30}, desc:'Meninggalkan genangan magma yang membakar.' },
  { id:'sw_soul',    name:'Pedang Panen Jiwa',    fx:'soul',    tier:8, stats:{atk:104, crit:12},            snd:{w:'triangle', f:240, s:1.9,  n:0.30, ring:1800, d:0.26}, desc:'Setiap bunuh menambah +6 Serangan (maks 60) sesi ini.' },
  { id:'sw_void',    name:'Bilah Robekan Void',   fx:'void',    tier:9, stats:{atk:118, critdmg:34},         snd:{w:'sawtooth', f:90,  s:2.6,  n:0.36, ring:180,  d:0.36}, desc:'Membuka celah kecil yang menarik & merobek musuh.' },
  { id:'sw_star',    name:'Pedang Hujan Bintang', fx:'meteor',  tier:10,stats:{atk:132, crit:14, life:6},    snd:{w:'square',   f:880, s:2.4,  n:0.28, ring:2600, d:0.30}, desc:'Kritis memanggil meteor kecil di titik hantaman.' },
  { id:'sw_flower',  name:'Flowers Flame',        fx:'flower',  tier:12,stats:{atk:175, crit:20, critdmg:60, life:12, haste:15}, secret:true,
    snd:{w:'triangle', f:560, s:1.8, n:0.24, ring:3000, d:0.34}, desc:'PEDANG RAHASIA — kelopak api pemandu, membakar, menyembuhkan, dan meledak saat kritis.' },
];
SWORDS.forEach((s, i) => {
  defItem({
    id: s.id, name: s.name, type: 'weapon', tier: s.tier, icon: 'sword',
    rarity: s.secret ? 'legendary' : s.tier >= 9 ? 'legendary' : s.tier >= 6 ? 'epic' : 'rare',
    sockets: Math.min(3, 1 + Math.floor(s.tier / 3)), stats: s.stats,
    price: Math.round(900 * Math.pow(1.55, s.tier)), fx: s.fx, snd: s.snd,
    desc: s.desc, bossDrop: !s.secret,
  });
});
const SWORD_BY_FX = {}; SWORDS.forEach(s => SWORD_BY_FX[s.fx] = s.id);

/* ---------- 16 zirah bos ---------- */
const BOSS_ARMORS = [
  { id:'ar_bloom',   name:'Zirah Kelopak Fajar',   tier:3, stats:{def:22, hp:90},            perk:'Regenerasi 2 HP/detik.' },
  { id:'ar_tide',    name:'Zirah Arus Pesisir',    tier:4, stats:{def:28, hp:120, spd:6},    perk:'Kecepatan penuh di air.' },
  { id:'ar_bark',    name:'Zirah Kulit Purba',     tier:4, stats:{def:34, hp:150},           perk:'Meredam 6% kerusakan.' },
  { id:'ar_mire',    name:'Zirah Lumpur Bakau',    tier:5, stats:{def:38, hp:170, life:4},   perk:'Racun berkurang separuh.' },
  { id:'ar_glacier2',name:'Zirah Inti Gletser',    tier:5, stats:{def:44, hp:190},           perk:'Musuh penyerang ikut melambat.' },
  { id:'ar_stone',   name:'Zirah Cadas Puncak',    tier:6, stats:{def:54, hp:230},           perk:'Tak terpental saat dipukul.' },
  { id:'ar_dune',    name:'Zirah Bisik Gurun',     tier:6, stats:{def:50, hp:200, haste:8},  perk:'Serangan lebih cepat di darat kering.' },
  { id:'ar_fungal',  name:'Zirah Spora Jamur',     tier:6, stats:{def:56, hp:240, life:5},   perk:'Menyembuhkan 3% HP tiap membunuh.' },
  { id:'ar_cave',    name:'Zirah Getar Gua',       tier:7, stats:{def:64, hp:270},           perk:'Melihat lebih jauh dalam gelap.' },
  { id:'ar_echo',    name:'Zirah Gaung Kelam',     tier:8, stats:{def:74, hp:320, def2:0},   perk:'Menyerap 10% kerusakan sihir.' },
  { id:'ar_ember2',  name:'Zirah Bara Nether',     tier:8, stats:{def:80, hp:340},           perk:'Imun bakar lingkungan.' },
  { id:'ar_soul2',   name:'Zirah Jiwa Terpanggil',  tier:9, stats:{def:88, hp:380, life:6},  perk:'Mengembalikan 8% kerusakan ke penyerang.' },
  { id:'ar_basalt',  name:'Zirah Delta Basalt',    tier:9, stats:{def:96, hp:420},           perk:'Tahan ledakan.' },
  { id:'ar_void2',   name:'Zirah Hampa End',       tier:10,stats:{def:108, hp:470, spd:8},   perk:'Sekali kematian dihindari per pertarungan bos.' },
  { id:'ar_star2',   name:'Zirah Rasi Bintang',    tier:10,stats:{def:120, hp:520, crit:8},  perk:'Skill terisi 15% lebih cepat.' },
  { id:'ar_aether2', name:'Zirah Nadi Aethervale', tier:11,stats:{def:140, hp:600, life:8},  perk:'Semua status bertahan 25% lebih singkat.' },
];
BOSS_ARMORS.forEach(a => {
  defItem({
    id: a.id, name: a.name, type: 'armor', tier: a.tier, icon: 'armor',
    rarity: a.tier >= 10 ? 'legendary' : a.tier >= 7 ? 'epic' : 'rare',
    sockets: Math.min(3, 1 + Math.floor(a.tier / 4)), stats: a.stats,
    price: Math.round(800 * Math.pow(1.52, a.tier)), desc: a.perk, bossDrop: true, perk: a.perk,
  });
});

/* ---------- material inti bos (untuk crafting) ---------- */
defMat('m_bosscore', 'Inti Bos', 'core', 3200, 'Jantung bos yang masih berdenyut — bahan utama menempa peralatan bos.', 'legendary');
defMat('m_petal',    'Kelopak Api', 'essence', 5200, 'Kelopak yang menyala tanpa habis. Hanya dari Boss Clash.', 'legendary');

/* ---------- 25 skill (3 dasar per kelas + 16 dari bos) ---------- */
const SKILLS = {};
function defSkill(o) { SKILLS[o.id] = o; return o; }
// dasar — Penjaga
defSkill({ id:'sk_shield', name:'Hantaman Perisai', kind:'nova', cd:7,  dmg:2.3, radius:58, color:'#9ec7ff', desc:'Hantaman area kecil, memingsankan.', stun:0.6 });
defSkill({ id:'sk_taunt',  name:'Raungan Serambi', kind:'shield', cd:14, dur:5, color:'#ffd24d', desc:'Menyerap 45% kerusakan selama 5 detik.' });
defSkill({ id:'sk_slam',   name:'Godam Bumi',      kind:'quake', cd:10, dmg:2.8, radius:76, color:'#c9a36a', desc:'Gelombang tanah beruntun ke segala arah.' });
// dasar — Pengelana
defSkill({ id:'sk_double', name:'Tebasan Ganda',   kind:'dash', cd:6,  dmg:1.3, hits:3, color:'#6fe08a', desc:'Menerjang menembus musuh dengan tiga tebasan.' });
defSkill({ id:'sk_volley', name:'Tembakan Beruntun',kind:'fan', cd:8,  dmg:1.1, count:5, color:'#a8f0a0', desc:'Lima bilah angin menyebar ke depan.' });
defSkill({ id:'sk_veil',   name:'Selubung Rimba',  kind:'haste', cd:16, dur:6, color:'#8fe8c0', desc:'+60% kecepatan gerak & serang selama 6 detik.' });
// dasar — Pawang
defSkill({ id:'sk_wave',   name:'Gelombang Aether',kind:'fan', cd:7,  dmg:1.5, count:5, color:'#c07bff', desc:'Gelombang sihir menembus banyak musuh.' });
defSkill({ id:'sk_bolt',   name:'Panah Arcana',    kind:'beam', cd:9,  dmg:3.2, color:'#e0b3ff', desc:'Sinar lurus menembus segala yang dilewati.' });
defSkill({ id:'sk_bloom',  name:'Kuncup Penyembuh',kind:'heal', cd:18, heal:0.35, color:'#8fffc0', desc:'Memulihkan 35% HP maks dan menumbuhkan bunga aether.' });
// unlock dari bos
defSkill({ id:'sk_meteor', name:'Hujan Meteor',    kind:'meteor', cd:20, dmg:2.6, count:9, color:'#ff8a4f', desc:'Sembilan meteor jatuh di sekitar sasaran.', boss:true });
defSkill({ id:'sk_icenova',name:'Nova Beku',       kind:'nova', cd:14, dmg:2.2, radius:92, freeze:3, color:'#9fe8ff', desc:'Ledakan es membekukan seluruh area.', boss:true });
defSkill({ id:'sk_chain',  name:'Rantai Guntur',   kind:'chain', cd:12, dmg:1.9, jumps:6, color:'#ffe066', desc:'Petir melompat antar enam musuh.', boss:true });
defSkill({ id:'sk_vortex', name:'Pusaran Void',    kind:'vortex', cd:18, dmg:0.9, dur:3, color:'#b07bff', desc:'Pusaran menarik musuh dan merobeknya terus-menerus.', boss:true });
defSkill({ id:'sk_blades', name:'Badai Bilah',     kind:'bladestorm', cd:16, dmg:0.8, dur:3.2, color:'#e6e6f0', desc:'Berputar dengan bilah melayang selama 3 detik.', boss:true });
defSkill({ id:'sk_poison', name:'Kabut Racun',     kind:'cloud', cd:15, dmg:0.7, dur:5, color:'#9ae66e', desc:'Kabut racun menetap dan mengikis musuh.', boss:true });
defSkill({ id:'sk_pillar', name:'Pilar Fajar',     kind:'pillars', cd:17, dmg:2.4, count:6, color:'#ffe9a8', desc:'Enam pilar cahaya menghukum area.', boss:true });
defSkill({ id:'sk_clone',  name:'Bayangan Kembar', kind:'clones', cd:22, dur:7, color:'#8f7bff', desc:'Dua bayangan menyerang bersamamu.', boss:true });
defSkill({ id:'sk_dragon', name:'Napas Naga Bara', kind:'breath', cd:14, dmg:1.5, dur:1.6, color:'#ff6a2f', desc:'Semburan api kerucut yang membakar.', boss:true });
defSkill({ id:'sk_hole',   name:'Lubang Hitam',    kind:'blackhole', cd:26, dmg:1.4, dur:2.6, color:'#7a5bd8', desc:'Menghisap dan meremukkan semua di sekitarnya.', boss:true });
defSkill({ id:'sk_slow',   name:'Gema Waktu',      kind:'timeslow', cd:24, dur:4, color:'#7dd3fc', desc:'Melambatkan seluruh musuh 65% selama 4 detik.', boss:true });
defSkill({ id:'sk_petal',  name:'Badai Kelopak',   kind:'petals', cd:15, dmg:1.2, count:14, color:'#ff9ec4', desc:'Kelopak pemandu mengejar musuh terdekat.', boss:true });
defSkill({ id:'sk_quakeX', name:'Retak Dunia',     kind:'quake', cd:19, dmg:3.4, radius:120, color:'#d8a05f', desc:'Retakan tanah melebar ke seluruh arena.', boss:true });
defSkill({ id:'sk_soulrip',name:'Rampas Jiwa',     kind:'drain', cd:16, dmg:2.0, color:'#6fe8f0', desc:'Menyedot HP musuh di sekitar menjadi milikmu.', boss:true });
defSkill({ id:'sk_judge',  name:'Vonis Aether',    kind:'beam', cd:21, dmg:5.2, color:'#ffffff', desc:'Sinar raksasa menghanguskan satu garis penuh.', boss:true });
defSkill({ id:'sk_bulwark',name:'Benteng Cadas',   kind:'shield', cd:20, dur:8, color:'#c9c2a8', desc:'Menyerap 65% kerusakan selama 8 detik.', boss:true });

const CLASS_SKILLS = {
  guardian: ['sk_shield', 'sk_taunt', 'sk_slam'],
  ranger:   ['sk_double', 'sk_volley', 'sk_veil'],
  arcanist: ['sk_wave', 'sk_bolt', 'sk_bloom'],
};
const BOSS_SKILL_IDS = Object.keys(SKILLS).filter(k => SKILLS[k].boss);

/* ---------- 64 bos: satu per bioma, masing-masing sarangnya sendiri ---------- */
const BOSS_NAMES = [
  'Thalorix','Murgath','Selvarine','Kaldrun','Ombrath','Vessaline','Drakhorn','Ysmeril','Torvun','Nalethra',
  'Grimhollow','Aurvane','Zephyrak','Mordwyn','Illyrath','Sablemaw','Verithan','Kaelstrom','Nyxara','Ferrovax',
  'Umbriel','Tharnok','Lysavine','Obsidrek','Ashvara','Pyrrhon','Glacivor','Maratheon','Solvane','Duskmire',
  'Ravenscar','Tidemourn','Coralux','Abyssaron','Brumalis','Frostwake','Rimeclaw','Stonevigil','Craghelm','Skyrend',
  'Verdanth','Bloomspire','Birchveil','Palewatch','Sporelord','Thornvayne','Bambuhl','Cantharis','Mirelord','Rootfen',
  'Streamsong','Glacierun','Sunmarrow','Dunestride','Savanox','Plateaur','Rustmaw','Clayvern','Erodrix','Dripfang',
  'Lumivine','Silentgaze','Cinderhowl','Voidbloom',
];
const BOSS_TITLES = {
  overworld: ['Penjaga', 'Raja', 'Wali', 'Pemangsa', 'Penguasa'],
  cave: ['Penggali', 'Pengintai', 'Penunggu'],
  nether: ['Tiran Bara', 'Panglima Jelaga', 'Pembakar'],
  end: ['Hampa', 'Pemecah Langit', 'Penjaga Void'],
};
const BOSS_PATTERNS = ['slam', 'charge', 'ring', 'spiral', 'summon', 'sweep', 'meteor', 'blink', 'cloud', 'shock'];

const BOSSES = {};                 // key: biomeId
const BOSS_LIST = [];
(function buildBosses() {
  const ids = Object.keys(BIOMES);
  ids.forEach((id, idx) => {
    const b = BIOMES[id], tier = BIOME_TIER[id];
    const nm = BOSS_NAMES[idx % BOSS_NAMES.length];
    const titles = BOSS_TITLES[b.realm] || BOSS_TITLES.overworld;
    const title = titles[idx % titles.length];
    const bid = `boss_${id}`;
    const hp = Math.round(520 * Math.pow(1.5, tier));
    const atk = Math.round(11 * Math.pow(1.3, tier));
    const def = Math.round(5 * Math.pow(1.28, tier));
    const pattern = BOSS_PATTERNS[idx % BOSS_PATTERNS.length];
    const art = ['golem', 'fiend', 'rift', 'revenant', 'lurker', 'wolf'][idx % 6];
    // hadiah: pedang, zirah, atau skill (dibagi rata menurut indeks)
    const slot = idx % 4;
    const reward = {};
    if (slot === 0) reward.weapon = SWORDS[Math.floor(idx / 4) % 16].id;
    else if (slot === 1) reward.armor = BOSS_ARMORS[Math.floor(idx / 4) % 16].id;
    else if (slot === 2) reward.skill = BOSS_SKILL_IDS[Math.floor(idx / 4) % BOSS_SKILL_IDS.length];
    else reward.gold = Math.round(1200 * Math.pow(1.4, tier));
    const def_ = {
      name: `${nm}, ${title} ${b.name}`, short: nm, art, hp, atk, def,
      xp: Math.round(420 * Math.pow(1.4, tier)), gold: [Math.round(600 * Math.pow(1.36, tier)), Math.round(1100 * Math.pow(1.36, tier))],
      spd: 42 + (idx % 5) * 6, r: 16 + (tier > 6 ? 4 : 0), color: b.accent, biome: id, boss: true,
      tier, pattern, reward,
      drops: [['m_bosscore', 1, 1, 1], ['m_stone_hi', 1, 2, 4], ['m_protect', 0.7, 1, 2], ['m_essence', 0.5, 1, 1], ['p_potion_hi', 0.8, 1, 3]],
    };
    if (reward.weapon) def_.drops.push([reward.weapon, 1, 1, 1]);
    if (reward.armor) def_.drops.push([reward.armor, 1, 1, 1]);
    ENEMIES[bid] = def_;
    BOSSES[id] = Object.assign({ id: bid, biome: id }, def_);
    BOSS_LIST.push(BOSSES[id]);
  });
  BOSS_LIST.sort((a, b) => a.tier - b.tier || a.name.localeCompare(b.name));
})();

/* ---------- Boss Clash: 16 bos berurut dari terlemah ke terkuat ---------- */
const CLASH_LADDER = (() => {
  const byTier = {};
  BOSS_LIST.forEach(b => { (byTier[b.tier] = byTier[b.tier] || []).push(b); });
  const tiers = Object.keys(byTier).map(Number).sort((a, b) => a - b);
  const out = [];
  // ambil merata dari tiap tier sampai 16 lawan
  let i = 0;
  while (out.length < 16 && i < 40) {
    for (const t of tiers) {
      const pool = byTier[t];
      if (pool[i] && out.length < 16) out.push(pool[i]);
    }
    i++;
  }
  return out.sort((a, b) => a.tier - b.tier).slice(0, 16).map(b => b.id);
})();

/* ---------- resep tempa peralatan bos ---------- */
const CRAFT_RECIPES = (() => {
  const out = [];
  SWORDS.filter(s => !s.secret).forEach(s => out.push({
    out: s.id, cost: [['m_bosscore', Math.max(1, Math.round(s.tier / 3))], ['m_stone_hi', s.tier], ['m_essence', 1]],
    gold: Math.round(600 * Math.pow(1.4, s.tier)),
  }));
  BOSS_ARMORS.forEach(a => out.push({
    out: a.id, cost: [['m_bosscore', Math.max(1, Math.round(a.tier / 4))], ['m_stone_hi', a.tier], ['m_protect', 1]],
    gold: Math.round(520 * Math.pow(1.4, a.tier)),
  }));
  return out;
})();
