'use strict';
/* ---------- touch control layout: position / size / opacity ---------- */
const LCTL=[
 {id:'bFire',n:'फायर',sz:96,off:4,b:24,ic:'fire'},
 {id:'bRel',n:'रीलोड',sz:52,off:118,b:30,ic:'reload'},
 {id:'bSwap',n:'हथियार',sz:50,off:8,b:132,ic:'swap'},
 {id:'bGren',n:'ग्रेनेड',sz:50,off:74,b:120,ic:'gren'},
 {id:'bGloo',n:'ग्लू वॉल',sz:50,off:134,b:98,ic:'gloo'},
 {id:'bBand',n:'बैंडेज',sz:48,off:8,b:192,ic:'band'},
 {id:'bMed',n:'मेडकिट',sz:48,off:66,b:184,ic:'med'},
 {id:'bSmk',n:'स्मोक',sz:44,off:124,b:158,ic:'smoke'},
 {id:'bSkill',n:'एबिलिटी',sz:58,off:206,b:28,em:'✨'},
 {id:'bEmo',n:'इमोट',sz:40,off:8,b:250,em:'😀'},
 {id:'bAuto',n:'ऑटो फायर',sz:44,off:66,b:240,em:'🎯'},
 {id:'bPause',n:'पॉज़',sz:34,pause:1,ic:'pause'},
 {id:'joy',n:'जॉयस्टिक',joy:1}
];
const lay=id=>(set.layout&&set.layout[id])||null;
function joyBase(){const e=lay('joy');return e?[e.x*VW,e.y*VH]:[VW*.17,VH-Math.min(130,VH*.22)]}
function joyK(){const e=lay('joy');return set.joy*(e?e.s:1)}
function joyOp(){const e=lay('joy');return e?e.o:1}
const lsize=(c,w)=>c.joy?SR*2*set.joy*w.s:(c.pause?c.sz:c.sz*set.btn)*w.s;
function ldef(c){
  const bs=set.btn;
  if(c.joy)return[.17,(VH-Math.min(130,VH*.22))/VH];
  if(c.pause)return[(VW-16-c.sz/2)/VW,(178+c.sz/2)/VH];
  const sz=c.sz*bs;return[(VW-16-c.off*bs-sz/2)/VW,(VH-c.b*bs-sz/2)/VH];
}
function applyLayout(){
  for(const c of LCTL){
    if(c.joy)continue;
    const el=$(c.id),e=lay(c.id);if(!el)continue;
    if(!e){el.style.cssText='';continue}
    const sz=lsize(c,e);
    el.style.cssText=`right:auto;bottom:auto;margin-top:0;left:calc(${e.x*100}% - ${sz/2}px);top:calc(${e.y*100}% - ${sz/2}px);width:${sz}px;height:${sz}px;--op:${e.o}`;
  }
}
function relEl(el,e){
  const r=el.getBoundingClientRect();
  return document.documentElement.classList.contains('rot')?[e.clientY-r.top,r.right-e.clientX]:[e.clientX-r.left,e.clientY-r.top];
}
function openLayoutEditor(){
  if($('ledit'))return;
  closePanel();
  const ov=document.createElement('div');ov.id='ledit';ov.className='ov';ov.style.zIndex=80;
  const work={},mod=new Set(Object.keys(set.layout||{})),nodes={};let sel='bFire';
  for(const c of LCTL){const e=lay(c.id),d=ldef(c);work[c.id]=e?{...e}:{x:d[0],y:d[1],s:1,o:1}}
  const clamp01=v=>Math.max(.03,Math.min(.97,v));
  const place=c=>{
    const w=work[c.id],n=nodes[c.id],sz=lsize(c,w);
    n.style.width=n.style.height=sz+'px';n.style.left=`calc(${w.x*100}% - ${sz/2}px)`;n.style.top=`calc(${w.y*100}% - ${sz/2}px)`;
    n.style.opacity=w.o;n.classList.toggle('sel',sel===c.id);
  };
  for(const c of LCTL){
    const n=document.createElement('div');n.className='lb'+(c.joy?' joyc':'');
    n.innerHTML=(c.ic?ICONS[c.ic]:c.em?'<b style="font-size:20px">'+c.em+'</b>':'')+'<span>'+c.n+'</span>';nodes[c.id]=n;ov.append(n);
    let dx=0,dy=0,drag=false;
    n.addEventListener('pointerdown',e=>{e.preventDefault();sel=c.id;drag=true;const[px,py]=relEl(ov,e),w=work[c.id];dx=px-w.x*ov.clientWidth;dy=py-w.y*ov.clientHeight;try{n.setPointerCapture(e.pointerId)}catch(_){}LCTL.forEach(place);sync()});
    n.addEventListener('pointermove',e=>{if(!drag)return;const[px,py]=relEl(ov,e),w=work[c.id];w.x=clamp01((px-dx)/ov.clientWidth);w.y=clamp01((py-dy)/ov.clientHeight);mod.add(c.id);place(c)});
    const up=()=>{drag=false};n.addEventListener('pointerup',up);n.addEventListener('pointercancel',up);
  }
  // floating (movable) panel
  const pn=document.createElement('div');pn.id='lpanel';pn.style.left='12px';pn.style.top='12px';
  pn.innerHTML=`<div class="lh"><span>⠿ कंट्रोल सेटिंग</span></div><div class="lbd"><div class="lsel"></div>
    <div class="lr"><label>साइज़</label><input type="range" id="lsS" min=".5" max="2.2" step=".05"><b id="lsSv"></b></div>
    <div class="lr"><label>पारदर्शिता</label><input type="range" id="lsO" min=".15" max="1" step=".05"><b id="lsOv"></b></div>
    <div class="lbt"><button id="lRs">ये रीसेट</button><button id="lRa">सब रीसेट</button><button class="pri" id="lSv">सेव करो</button><button id="lCn">रद्द</button></div></div>`;
  ov.append(pn);
  const hint=document.createElement('div');hint.className='hint';hint.textContent='बटन को पकड़कर खींचो · पैनल को ऊपर की पट्टी से खिसका सकते हो';ov.append(hint);
  const q=s=>pn.querySelector(s);
  function sync(){
    const c=LCTL.find(x=>x.id===sel),w=work[sel];
    q('.lsel').textContent='चुना हुआ: '+c.n;
    q('#lsS').value=w.s;q('#lsSv').textContent=Math.round(w.s*100)+'%';
    q('#lsO').value=w.o;q('#lsOv').textContent=Math.round(w.o*100)+'%';
  }
  q('#lsS').oninput=e=>{const c=LCTL.find(x=>x.id===sel);work[sel].s=+e.target.value;mod.add(sel);place(c);sync()};
  q('#lsO').oninput=e=>{const c=LCTL.find(x=>x.id===sel);work[sel].o=+e.target.value;mod.add(sel);place(c);sync()};
  const reset=c=>{const d=ldef(c);work[c.id]={x:d[0],y:d[1],s:1,o:1};mod.delete(c.id);place(c)};
  q('#lRs').onclick=()=>{reset(LCTL.find(x=>x.id===sel));sync()};
  q('#lRa').onclick=()=>{LCTL.forEach(reset);sync()};
  const close=()=>{ov.remove();openPanel('set')};
  q('#lCn').onclick=close;
  q('#lSv').onclick=()=>{const o={};for(const id of mod)o[id]={...work[id]};set.layout=o;save();applyLayout();toast('लेआउट सेव हो गया');close()};
  // drag the panel by its header
  const hd=q('.lh');let pd=null;
  hd.addEventListener('pointerdown',e=>{e.preventDefault();const[px,py]=relEl(ov,e);pd=[px-pn.offsetLeft,py-pn.offsetTop];try{hd.setPointerCapture(e.pointerId)}catch(_){}});
  hd.addEventListener('pointermove',e=>{if(!pd)return;const[px,py]=relEl(ov,e);
    pn.style.left=Math.max(0,Math.min(ov.clientWidth-pn.offsetWidth,px-pd[0]))+'px';pn.style.top=Math.max(0,Math.min(ov.clientHeight-pn.offsetHeight,py-pd[1]))+'px'});
  const pu=()=>{pd=null};hd.addEventListener('pointerup',pu);hd.addEventListener('pointercancel',pu);
  document.body.append(ov);LCTL.forEach(place);sync();
}
