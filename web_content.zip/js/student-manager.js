// ======================================
// CIVIL 3 - STUDENT MANAGER
// ======================================

document.addEventListener("DOMContentLoaded", function () {
    const list = document.getElementById("studentsList");
    const total = document.getElementById("totalStudents");
    const search = document.getElementById("studentSearch");

    const formContainer = document.getElementById("studentFormContainer");
    const form = document.getElementById("studentForm");
    const nameInput = document.getElementById("studentName");
    const formTitle = document.getElementById("formTitle");

    const addButton = document.getElementById("addStudentBtn");
    const cancelButton = document.getElementById("cancelStudentBtn");
    const message = document.getElementById("studentMessage");

    let editingId = null;

    function showMessage(text, type = "success") {
        message.textContent = text;
        message.className = "student-message " + type;
    }

    function escapeHTML(value) {
        return String(value).replace(/[&<>"']/g, function (character) {
            const entities = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };

            return entities[character];
        });
    }

    function renderStudents() {
        const query = search.value.trim().toLowerCase();

        const filtered = STUDENTS.filter(function (student) {
            return student.name.toLowerCase().includes(query);
        });

        total.textContent = STUDENTS.length;

        if (filtered.length === 0) {
            list.innerHTML = `
                <div class="empty-state">
                    <i class="fa-solid fa-user-slash"></i>
                    <p>No students found.</p>
                </div>
            `;
            return;
        }

        list.innerHTML = filtered.map(function (student) {
            const safeName = escapeHTML(student.name);

            return `
                <article class="student-row">
                    <div class="student-avatar">
                        <i class="fa-solid fa-user-graduate"></i>
                    </div>

                    <div class="student-info">
                        <h3>${safeName}</h3>
                        <p>Student ID: ${student.id}</p>
                    </div>

                    <div class="student-actions">
                        <button
                            type="button"
                            class="icon-button edit-student"
                            data-id="${student.id}"
                            aria-label="Edit ${safeName}"
                            title="Edit student"
                        >
                            <i class="fa-solid fa-pen"></i>
                        </button>

                        <button
                            type="button"
                            class="icon-button delete-student"
                            data-id="${student.id}"
                            aria-label="Delete ${safeName}"
                            title="Delete student"
                        >
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </article>
            `;
        }).join("");
    }

    function openForm(student = null) {
        form.reset();
        message.textContent = "";
        message.className = "";

        editingId = student ? student.id : null;

        formTitle.textContent = student
            ? "Edit Student"
            : "Add New Student";

        nameInput.value = student ? student.name : "";

        formContainer.hidden = false;
        nameInput.focus();
    }

    function closeForm() {
        form.reset();
        formContainer.hidden = true;
        editingId = null;
    }

    addButton.addEventListener("click", function () {
        if (window.CIVIL3_AUTH && !window.CIVIL3_AUTH.requireAdmin()) return;
        openForm();
    });

    cancelButton.addEventListener("click", function () {
        closeForm();
    });

    search.addEventListener("input", renderStudents);

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        if (window.CIVIL3_AUTH && !window.CIVIL3_AUTH.requireAdmin()) return;

        const name = nameInput.value.trim();

        if (!name) {
            showMessage("Please enter a student name.", "error");
            return;
        }

        try {
            if (editingId !== null) {
                updateStudent(editingId, name);
                showMessage("Student name updated successfully.");
            } else {
                addStudent(name);
                showMessage("Student added successfully.");
            }

            closeForm();
            renderStudents();
        } catch (error) {
            showMessage(error.message || "Unable to save student.", "error");
        }
    });

    list.addEventListener("click", function (event) {
        const editButton = event.target.closest(".edit-student");
        const deleteButton = event.target.closest(".delete-student");

        if (editButton) {
            if (window.CIVIL3_AUTH && !window.CIVIL3_AUTH.requireAdmin()) return;
            const id = Number(editButton.dataset.id);

            const student = STUDENTS.find(function (item) {
                return item.id === id;
            });

            if (student) {
                openForm(student);
            }

            return;
        }

        if (deleteButton) {
            if (window.CIVIL3_AUTH && !window.CIVIL3_AUTH.requireAdmin()) return;
            const id = Number(deleteButton.dataset.id);

            const student = STUDENTS.find(function (item) {
                return item.id === id;
            });

            if (!student) {
                return;
            }

            const confirmed = confirm(
                "Delete " + student.name + " from the current student list?\n\n" +
                "Their previously saved attendance records may still exist, " +
                "but this student will no longer appear in the roster."
            );

            if (!confirmed) {
                return;
            }

            try {
                deleteStudent(id);
                closeForm();
                renderStudents();
                showMessage("Student removed from the current roster.");
            } catch (error) {
                showMessage(error.message || "Unable to delete student.", "error");
            }
        }
    });

    renderStudents();
});