document.addEventListener("DOMContentLoaded", () => {
  const key = "msl_sessions";
  let sessions = JSON.parse(localStorage.getItem(key) || "[]");
  const list = document.getElementById("sessionList");
  const render = () => {
    document.getElementById("sessionCount").textContent = sessions.length;
    list.innerHTML = sessions.length ? sessions.map((s,i)=>`
      <div class="session-item"><span>◷</span><b>${escapeHtml(s.subject)}</b><small>${s.time || "--:--"}</small><button class="icon-btn delete-session" data-i="${i}">×</button></div>
    `).join("") : '<div class="document-item"><span>📅</span><div><b>Aucune séance</b><small>Ajoute ta première séance d’étude.</small></div></div>';
  };
  const escapeHtml = s => String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  render();

  document.getElementById("addSessionBtn").onclick = () => {
    const subject = document.getElementById("sessionSubject").value.trim();
    const time = document.getElementById("sessionTime").value;
    if(!subject){ showToast("Indique une matière"); return; }
    sessions.push({subject,time});
    localStorage.setItem(key, JSON.stringify(sessions));
    document.getElementById("sessionSubject").value = "";
    render(); showToast("Séance ajoutée");
  };
  list.onclick = e => {
    const b=e.target.closest(".delete-session"); if(!b) return;
    sessions.splice(+b.dataset.i,1); localStorage.setItem(key,JSON.stringify(sessions)); render();
  };
});
