// ---------- Defaulters Covered — its own simpler PDF layout (A4 landscape) ----------
async function buildDefaultersPdf(title, results){
  const PT_W = 841.89, PT_H = 595.28;
  const MG = 28, FS = 7.5, LH = FS * 1.8, PAD = 3.5;
  // The Identifier holds two numbers, so the PDF gets two columns: the 8-digit
  // EPI No and the 14-digit QR code. The other widths were trimmed to make room
  // while keeping the table inside the A4 print area.
  const COLS = [
    { t:'#',  w:22 }, { t:'EPI No', w:58 }, { t:'QR Code', w:75 }, { t:'Name', w:78 },
    { t:'Father/Husb.', w:70 }, { t:'Vaccine', w:75 }, { t:'Due Date', w:55 }, { t:'Status', w:70 },
    { t:'Our Record', w:125 }, { t:'Enrollment', w:85 }, { t:'Last Visited', w:70 }
  ];
  const TABLE_W = COLS.reduce((s, c) => s + c.w, 0);

  function wrapText(text, maxW, size, bold){
    const raw = String(text == null ? '' : text);
    if (!raw.trim()) return ['—'];
    const paragraphs = raw.split('\n');
    const lines = [];
    for (const para of paragraphs) {
      const words = para.split(/\s+/).filter(Boolean);
      if (!words.length) continue;
      let cur = '';
      for (const word of words) {
        const test = cur ? cur + ' ' + word : word;
        if (measureText(test, size, bold) <= maxW) { cur = test; continue; }
        if (cur) lines.push(cur);
        if (measureText(word, size, bold) <= maxW) { cur = word; continue; }
        let piece = '';
        for (const ch of word) {
          if (piece && measureText(piece + ch, size, bold) > maxW) { lines.push(piece); piece = ch; }
          else piece += ch;
        }
        cur = piece;
      }
      if (cur) lines.push(cur);
    }
    return lines.length ? lines : ['—'];
  }

  const pages = [];
  let page = null, y = 0, pageNo = 0;
  const BOTTOM = PT_H - MG - 14;

  function tableHeader(){
    const headerLines = COLS.map(c => wrapText(c.t, c.w - PAD * 2, FS, true));
    const h = Math.max(...headerLines.map(l => l.length)) * LH + PAD * 2;
    page.fillColor('#e6e6e6'); page.rect(MG, y, TABLE_W, h, 'f');
    page.strokeColor('#555'); page.lineWidth(0.5); page.rect(MG, y, TABLE_W, h, 'S');
    let x = MG;
    COLS.forEach((c, ci) => {
      headerLines[ci].forEach((ln, li) => page.text(x + PAD, y + PAD + FS * 0.9 + li * LH, ln, FS, true));
      x += c.w;
      if (x < MG + TABLE_W - 1) page.line(x, y, x, y + h);
    });
    y += h;
  }

  function startPage(first){
    pageNo++;
    page = new PdfPage(PT_W, PT_H);
    const LOGO_SIZE = 24;
    page.image('Logo', PT_W - MG - LOGO_SIZE, 3, LOGO_SIZE, LOGO_SIZE);
    y = MG;
    page.text(MG, y + 13, 'SIER — EPI Calculator', 13, true);
    y += 18;
    page.text(MG, y + 9.5, title, 9.5, false);
    y += 14;
    page.text(MG, y + 8, 'Printed: ' + printableDate(), 8, false, '#444');
    const rc = `${results.length} defaulter(s)`;
    page.text(PT_W - MG - measureText(rc, 8, false), y + 8, rc, 8, false, '#444');
    y += 11;
    page.strokeColor('#000'); page.lineWidth(1);
    page.line(MG, y, MG + TABLE_W, y);
    y += 9;

    if (first) {
      const covered = results.filter(r => r.status === 'covered').length;

      const still = results.filter(r => r.status === 'still').length;
      const sum = `Total: ${results.length}  |  Covered: ${covered}  |  Still Defaulting: ${still}`;
      const sLines = wrapText(sum, TABLE_W - PAD * 2, 8.5, false);
      const sh = sLines.length * LH + PAD * 2;
      page.strokeColor('#888'); page.lineWidth(0.5); page.rect(MG, y, TABLE_W, sh, 'S');
      sLines.forEach((ln, i) => page.text(MG + PAD, y + PAD + FS * 0.9 + i * LH, ln, 8.5, false));
      y += sh + 9;
    }
    tableHeader();
  }

  function endPage(){
    page.text(MG, PT_H - MG + 8, `SIER EPI Calculator — generated offline on this device`, 7.5, false, '#444');
    const pg = 'Page ' + pageNo;
    page.text(PT_W - MG - measureText(pg, 7.5, false), PT_H - MG + 8, pg, 7.5, false, '#444');
    pages.push(page);
  }

  startPage(true);

  for (let i = 0; i < results.length; i++) {
    const { def, cov, status } = results[i];
    const badgeLabel = status === 'covered' ? 'Covered' : 'Still Defaulting';
    const vaccineText = def.defaultedVaccines.map(t => EPI_SHORT[t] || t).join(', ') || '—';
    const enrollText = [def.enrollmentCenter, def.enrollmentVaccinator].filter(Boolean).join(' / ') || '—';
    const ourRecordText = cov.coverageDetail
      ? `${cov.coverageDetail.dateText}\n${cov.coverageDetail.vaccinatorText}`
      : (cov.found ? 'Not yet given' : 'Not found in records');

    const values = [
      String(i + 1), def.epiNo || '—', def.id || '—', def.name || '—', def.fatherName || '—',
      vaccineText, dmy(def.dueDate) || '—', badgeLabel, ourRecordText, enrollText, def.lastVisitedCenter || '—'
    ];

    const cells = values.map((v, ci) => wrapText(v, COLS[ci].w - PAD * 2, FS, ci === 3));
    const rowH = Math.max(...cells.map(l => l.length)) * LH + PAD * 2;

    if (y + rowH > BOTTOM) { endPage(); startPage(false); }

    page.strokeColor('#888'); page.lineWidth(0.4); page.rect(MG, y, TABLE_W, rowH, 'S');
    let x = MG;
    cells.forEach((lines, ci) => {
      lines.forEach((ln, li) => page.text(x + PAD, y + PAD + FS * 0.9 + li * LH, ln, FS, ci === 3));
      x += COLS[ci].w;
      if (ci < COLS.length - 1) page.line(x, y, x, y + rowH);
    });
    y += rowH;

    if (i % 200 === 199) await new Promise(res => setTimeout(res, 0));
  }
  endPage();

  return assemblePdf(pages, PT_W, PT_H);
}

// ---------- "Card Style" export for Defaulters — one card per child,
// mirroring the exact on-screen defaulter card fields. Each defaulter gets
// its own phone-proportioned page, sized just tall enough for that one card,
// so it opens already readable on a phone with no zoom or side scroll. ----------
async function buildDefaultersCardsPdf(title, results){
  const PG_W = 420;
  const MG = 18;
  const AW = PG_W - MG * 2;
  const PADX = 14;
  const CARD_W = AW;
  const LABEL_W = 130;
  const VAL_W = CARD_W - 2 * PADX - LABEL_W;
  const VAL_SIZE = 12.5;
  const LABEL_SIZE = 9.5;
  const LABEL_COLOR = '#5f665d', VAL_COLOR = '#1f2420';
  const AV = 56, AV_GAP = 10;                 // gender avatar badge
  const BLOCK_LABEL_W = 108;
  const BLOCK_VAL_W = CARD_W - 2 * PADX - AV - AV_GAP - BLOCK_LABEL_W;

  function wrapText(text, maxW, size){
    const raw = String(text == null ? '' : text);
    if (!raw.trim()) return ['—'];
    const words = raw.split(/\s+/).filter(Boolean);
    const lines = [];
    let cur = '';
    for (const w of words) {
      const test = cur ? cur + ' ' + w : w;
      if (measureText(test, size, false) <= maxW) { cur = test; continue; }
      if (cur) lines.push(cur);
      if (measureText(w, size, false) <= maxW) { cur = w; continue; }
      let piece = '';
      for (const ch of w) {
        if (piece && measureText(piece + ch, size, false) > maxW) { lines.push(piece); piece = ch; }
        else piece += ch;
      }
      cur = piece;
    }
    if (cur) lines.push(cur);
    return lines.length ? lines : ['—'];
  }

  // Baseline offset that visually centers text of a given size inside a box
  // of height boxH starting at boxTop (Helvetica's cap-height/descender split
  // is close enough to 0.72/0.28 of the em for this to look centered).
  function vcenter(boxTop, boxH, size){ return boxTop + boxH / 2 + size * 0.22; }

  function fieldsFor(item){
    const def = item.def, status = item.status;
    const dobText = def.dob ? `${String(def.dob.day).padStart(2,'0')}/${String(def.dob.month).padStart(2,'0')}/${def.dob.year}` : '—';
    const vaccineText = (def.defaultedVaccines || []).map(defVaccineLabel).join(', ') || '—';
    const enrollText = [def.enrollmentCenter, def.enrollmentVaccinator].filter(Boolean).join(' / ') || '—';
    return {
      idVal: `${def.epiNo || '—'}  /  ${def.id || '—'}`,
      badgeColor: status === 'covered' ? '#2f6b4f' : '#b3452f',
      badgeLabel: status === 'covered' ? '✅ Covered' : '⚠ Still Defaulting',
      gender: def.gender || null,
      name: def.name || 'Name not recorded',
      fatherName: def.fatherName || '—',
      dobText,
      rest: [
        ['Defaulted Vaccine', vaccineText],
        ['Due / Defaulted', `${dmy(def.dueDate) || '—'} / ${dmy(def.defaultedDate) || '—'}`],
        ['Address', def.address || '—'],
        ['Enrollment', enrollText],
        ['Last Visited', def.lastVisitedCenter || '—'],
      ],
    };
  }

  // Draws the card body when `pg` is a real page, or silently walks through
  // the exact same layout math when `pg` is null — used first to measure the
  // content height needed, then again to actually draw it, so measurement
  // and drawing can never drift out of sync with each other.
  function renderCardBody(pg, xCard, y0, f, idx){
    let cy = y0 + 12;

    // EPI No / QR Code header bar
    if (pg) { pg.fillColor('#e7eef6'); pg.rect(xCard + PADX, cy, CARD_W - 2 * PADX, 26, 'f'); }
    if (pg) {
      pg.text(xCard + PADX + 7, vcenter(cy, 26, LABEL_SIZE), 'EPI No / QR Code', LABEL_SIZE, true, '#2f5f8f');
      pg.text(xCard + CARD_W - PADX - 7 - measureText(f.idVal, VAL_SIZE, true), vcenter(cy, 26, VAL_SIZE), f.idVal, VAL_SIZE, true, VAL_COLOR);
    }
    cy += 36;

    if (pg) {
      pg.text(xCard + PADX, cy + 12, 'Status', LABEL_SIZE, false, LABEL_COLOR);
      pg.text(xCard + PADX + LABEL_W, cy + 12, f.badgeLabel, VAL_SIZE, true, f.badgeColor);
    }
    cy += 20;

    // Avatar badge + Name / Father-Husband / DOB, laid out beside it
    const avatarName = f.gender === 'M' ? 'Boy' : (f.gender === 'F' ? 'Girl' : null);
    const blockTop = cy;
    if (pg && avatarName) pg.image(avatarName, xCard + PADX, blockTop, AV, AV);
    const blockX = xCard + PADX + AV + AV_GAP;

    function blockRow(label, value){
      let lines = wrapText(String(value == null || value === '' ? '—' : value), BLOCK_VAL_W, VAL_SIZE);
      if (lines.length > 2) lines = [lines[0], lines[1].replace(/.{0,3}$/, '') + '…'];
      if (pg) {
        pg.text(blockX, cy + 11, label, LABEL_SIZE, false, LABEL_COLOR);
        pg.text(blockX + BLOCK_LABEL_W, cy + 11, lines[0], VAL_SIZE, false, VAL_COLOR);
      }
      cy += 18;
      for (let k = 1; k < lines.length; k++) {
        if (pg) pg.text(blockX + BLOCK_LABEL_W, cy + 11, lines[k], VAL_SIZE, false, VAL_COLOR);
        cy += 17;
      }
    }
    blockRow('Name', f.name);
    blockRow('Father/Husband', f.fatherName);
    blockRow('Date of Birth', f.dobText);
    cy = Math.max(cy, blockTop + AV + 8);

    // Remaining full-width fields
    function line(label, value){
      let lines = wrapText(String(value == null || value === '' ? '—' : value), VAL_W, VAL_SIZE);
      if (lines.length > 2) lines = [lines[0], lines[1].replace(/.{0,3}$/, '') + '…'];
      if (pg) {
        pg.text(xCard + PADX, cy + 11, label, LABEL_SIZE, false, LABEL_COLOR);
        pg.text(xCard + PADX + LABEL_W, cy + 11, lines[0], VAL_SIZE, false, VAL_COLOR);
      }
      cy += 18;
      for (let k = 1; k < lines.length; k++) {
        if (pg) pg.text(xCard + PADX + LABEL_W, cy + 11, lines[k], VAL_SIZE, false, VAL_COLOR);
        cy += 17;
      }
    }
    f.rest.forEach(([label, value]) => line(label, value));

    if (pg) pg.text(xCard + PADX, cy + 12, 'No. ' + (idx + 1), LABEL_SIZE, false, LABEL_COLOR);
    return cy; // absolute y of the content's bottom edge (before the 24pt pad)
  }

  const HEAD_H = 46, HEAD_GAP = 10, FOOT_H = 24;
  const pages = [];

  for (let idx = 0; idx < results.length; idx++) {
    const item = results[idx];
    const f = fieldsFor(item);
    const dryCy = renderCardBody(null, 0, 0, f, idx);
    const cardH = dryCy + 24;
    const pgH = MG + HEAD_H + HEAD_GAP + cardH + HEAD_GAP + FOOT_H + MG;

    const page = new PdfPage(PG_W, pgH);
    const LOGO_SIZE = 22;
    page.image('Logo', PG_W - MG - LOGO_SIZE, 3, LOGO_SIZE, LOGO_SIZE);

    let y = MG;
    page.text(MG, y + 13, 'SIER — EPI Calculator', 13, true);
    y += 16;
    page.text(MG, y + 9, title, 9, false, '#444');
    y += 12;
    const rc = `No. ${idx + 1} of ${results.length}`;
    page.text(MG, y + 8, 'Printed: ' + printableDate(), 8, false, '#888');
    page.text(PG_W - MG - measureText(rc, 8, false), y + 8, rc, 8, false, '#888');
    y += 10;
    page.strokeColor('#000'); page.lineWidth(1);
    page.line(MG, y, MG + AW, y);
    y += HEAD_GAP;

    const y0 = y;
    page.strokeColor('#e2ddd5'); page.lineWidth(1);
    page.rect(MG, y0, CARD_W, cardH, 'S');
    renderCardBody(page, MG, y0, f, idx);

    const footY = y0 + cardH + HEAD_GAP;
    page.text(MG, footY + 8, 'SIER EPI Calculator — generated offline on this device', 7, false, '#888');
    const pg = 'Page ' + (idx + 1);
    page.text(PG_W - MG - measureText(pg, 7, false), footY + 8, pg, 7, false, '#888');

    pages.push(page);
    if (idx % 150 === 149) await new Promise(res => setTimeout(res, 0));
  }

  return assemblePdf(pages, PG_W, pages.length ? pages[0].h : 600);
}
