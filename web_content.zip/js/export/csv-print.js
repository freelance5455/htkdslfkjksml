// ============================================================
// BACKUP
// Records live in localStorage only, so a browser data-clear wipes them.
// (Export buttons were removed from the Results Menu; this file now only holds the toast helper and print fallback.)
// ============================================================
const backupStatus  = document.getElementById('backupStatus');

let toastTimer = null;
function backupMsg(html, isError){
  const markup = isError ? `<span class="err">${html}</span>` : `<span class="ok">${html}</span>`;
  backupStatus.innerHTML = markup;
  // Also show it floating, because backupStatus is inside the hub page and is
  // hidden whenever the user is on a results/defaulters page.
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.innerHTML = markup;
  toast.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), isError ? 7000 : 4500);
}

function fileStamp(){
  const d = new Date(), p = n => String(n).padStart(2,'0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
}

// (downloadText lives in js/platform/downloads.js)

function dmy(d){ return d ? `${String(d.day).padStart(2,'0')}/${String(d.month).padStart(2,'0')}/${d.year}` : ''; }

function statusLabel(r){
  if (r.outOfDistrict || r.status === 'out_district') return 'Out From District';
  if (r.outOfTaluka || r.status === 'out_taluka') return 'Out From Taluka';
  if (r.outOfUc || r.status === 'out_uc') return 'Out of UC';
  return 'In UC';
}

function vaccineLabel(r){
  const isTt = isTtRecord(r.doses);
  const tags = isTt ? classifyTT(r.doses) : classifyEpi(r.doses);
  if (!tags.length) return isTt ? 'No TT dose recorded' : 'No vaccine recorded';
  return tags.map(t => isTt ? (TT_LABELS[t] || t) : (EPI_SHORT[t] || t)).join(', ');
}

// (The "Export Records (.csv)" button was removed from the Results Menu.)

// ---- PDF export ----
// window.print() is a no-op inside Android WebView (APK) builds, so a real PDF
// file is generated here instead: text is written as real PDF text objects
// (standard Helvetica font, WinAnsi-encoded) so the file is fully searchable
// and selectable in any PDF reader — not a picture of the page.
// No library, no network — everything stays offline.
const printArea    = document.getElementById('printArea');

function printableDate(){
  const d = new Date(), p = n => String(n).padStart(2,'0');
  return `${p(d.getDate())}/${p(d.getMonth()+1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function countsOf(records){
  const c = { inUc:0, outUc:0, outTal:0, outDist:0, women:0, b0:0, b1:0, b2:0 };
  records.forEach(r => {
    const s = statusLabel(r);
    if (s === 'In UC') c.inUc++;
    else if (s === 'Out of UC') c.outUc++;
    else if (s === 'Out From District') c.outDist++;
    else c.outTal++;
    if (isTtRecord(r.doses)) { c.women++; return; }
    const k = ageBracketKey(ageMonths(r.dob, r.vaccDate));
    if (k === 'b0') c.b0++; else if (k === 'b1') c.b1++; else c.b2++;
  });
  return c;
}

function summaryLine(records){
  const c = countsOf(records);
  return `<div class="p-summary">
    <span><b>Total:</b> ${records.length}</span>
    <span><b>In UC:</b> ${c.inUc}</span>
    <span><b>Out of UC:</b> ${c.outUc}</span>
    <span><b>Out From Taluka:</b> ${c.outTal}</span>
    <span><b>Out From District:</b> ${c.outDist}</span>
    <span><b>0–11 m:</b> ${c.b0}</span>
    <span><b>12–23 m:</b> ${c.b1}</span>
    <span><b>24+ m:</b> ${c.b2}</span>
    <span><b>Women (TT):</b> ${c.women}</span>
  </div>`;
}

// Fallback only: the on-screen paper layout used if canvas/PDF building fails.
function buildPrintDoc(title, records){
  if (!records || !records.length) return false;
  const rows = records.map((r, i) => {
    const isTt = isTtRecord(r.doses);
    const ageGroup = isTt ? 'Woman (TT)' : (AGE_LABELS[ageBracketKey(ageMonths(r.dob, r.vaccDate))] || '');
    const dv = dateAndVaccinatorText(r);
    return `<tr>
      <td class="p-num">${i + 1}</td>
      <td class="p-qr">${r.id ? escapeHtml(r.id) : '—'}</td>
      <td class="p-name">${r.name ? escapeHtml(r.name) : '—'}</td>
      <td>${r.fatherName ? escapeHtml(r.fatherName) : '—'}</td>
      <td>${dmy(r.dob) || '—'}</td>
      <td>${escapeHtmlMultiline(dv.dateText)}</td>
      <td>${escapeHtml(vaccineLabel(r))}</td>
      <td>${r.address ? escapeHtml(r.address) : '—'}</td>
      <td>${escapeHtmlMultiline(dv.vaccinatorText)}</td>
      <td>${escapeHtml(statusLabel(r))}<br>${escapeHtml(ageGroup)}</td>
    </tr>`;
  }).join('');
  printArea.innerHTML = `
    <div class="p-head">
      <div class="p-title">SIER — EPI Calculator</div>
      <div class="p-sub">${escapeHtml(title)}</div>
      <div class="p-meta"><span>Printed: ${printableDate()}</span><span>${records.length} record(s)</span></div>
    </div>
    ${summaryLine(records)}
    <table class="p-table">
      <thead><tr>
        <th>#</th><th>QR Code</th><th>Name</th><th>Father / Husband</th>
        <th>D.O.B</th><th>Vacc. Date</th><th>Vaccine</th><th>Address</th><th>Vaccinator</th><th>Status / Age</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="p-foot">Generated offline on this device — SIER EPI Calculator</div>`;
  return true;
}
