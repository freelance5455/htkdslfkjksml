// ---------- lay the report out as real PDF text on A4 landscape pages ----------
async function buildRecordsPdf(title, records){
  const PT_W = 841.89, PT_H = 595.28;                     // A4 landscape in points

  const MG = 28, FS = 7.5, LH = FS * 1.8, PAD = 3.5;
  const COLS = [
    { t:'#',                w:22 }, { t:'QR Code', w:70 }, { t:'Name',    w:95 },
    { t:'Father / Husband', w:85 }, { t:'D.O.B',   w:55 }, { t:'Vacc. Date', w:55 },
    { t:'Vaccine',          w:80 }, { t:'Address', w:110 }, { t:'Vaccinator', w:95 },
    { t:'Status / Age',     w:70 }
  ];
  const TABLE_W = COLS.reduce((s, c) => s + c.w, 0);

  function wrapText(text, maxW, size, bold){
    const raw = String(text == null ? '' : text);
    if (!raw.trim()) return ['—'];
    const paragraphs = raw.split('\n');
    const lines = [];
    for (const para of paragraphs) {
      const words = para.split(/\s+/).filter(Boolean);
      if (!words.length) continue;
      let cur = '';
      for (const word of words) {
        const test = cur ? cur + ' ' + word : word;
        if (measureText(test, size, bold) <= maxW) { cur = test; continue; }
        if (cur) lines.push(cur);
        if (measureText(word, size, bold) <= maxW) { cur = word; continue; }
        let piece = '';                                  // a single very long word
        for (const ch of word) {
          if (piece && measureText(piece + ch, size, bold) > maxW) { lines.push(piece); piece = ch; }
          else piece += ch;
        }
        cur = piece;
      }
      if (cur) lines.push(cur);
    }
    return lines.length ? lines : ['—'];
  }

  const pages = [];
  let page = null, y = 0, pageNo = 0;
  const BOTTOM = PT_H - MG - 14;

  function tableHeader(){
    const h = LH + PAD * 2;
    page.fillColor('#e6e6e6'); page.rect(MG, y, TABLE_W, h, 'f');
    page.strokeColor('#555'); page.lineWidth(0.5); page.rect(MG, y, TABLE_W, h, 'S');
    let x = MG;
    COLS.forEach(c => {
      page.text(x + PAD, y + PAD + FS * 0.9, c.t, FS, true);
      x += c.w;
      if (x < MG + TABLE_W - 1) page.line(x, y, x, y + h);
    });
    y += h;
  }

  function startPage(first){
    pageNo++;
    page = new PdfPage(PT_W, PT_H);
    const LOGO_SIZE = 24;
    page.image('Logo', PT_W - MG - LOGO_SIZE, 3, LOGO_SIZE, LOGO_SIZE);
    y = MG;
    page.text(MG, y + 13, 'SIER — EPI Calculator', 13, true);
    y += 18;
    page.text(MG, y + 9.5, title, 9.5, false);
    y += 14;
    page.text(MG, y + 8, 'Printed: ' + printableDate(), 8, false, '#444');
    const rc = `${records.length} record(s)`;
    page.text(PT_W - MG - measureText(rc, 8, false), y + 8, rc, 8, false, '#444');
    y += 11;
    page.strokeColor('#000'); page.lineWidth(1);
    page.line(MG, y, MG + TABLE_W, y);
    y += 9;

    if (first) {
      const c = countsOf(records);
      const sum = [
        `Total: ${records.length}`, `In UC: ${c.inUc}`, `Out of UC: ${c.outUc}`,
        `Out From Taluka: ${c.outTal}`, `Out From District: ${c.outDist}`, `0-11 m: ${c.b0}`, `12-23 m: ${c.b1}`,
        `24+ m: ${c.b2}`, `Women (TT): ${c.women}`
      ].join('  |  ');
      const sLines = wrapText(sum, TABLE_W - PAD * 2, 8.5, false);
      const sh = sLines.length * LH + PAD * 2;
      page.strokeColor('#888'); page.lineWidth(0.5); page.rect(MG, y, TABLE_W, sh, 'S');
      sLines.forEach((ln, i) => page.text(MG + PAD, y + PAD + FS * 0.9 + i * LH, ln, 8.5, false));
      y += sh + 9;
    }
    tableHeader();
  }

  function endPage(){
    page.text(MG, PT_H - MG + 8, `SIER EPI Calculator — generated offline on this device`, 7.5, false, '#444');
    const pg = 'Page ' + pageNo;
    page.text(PT_W - MG - measureText(pg, 7.5, false), PT_H - MG + 8, pg, 7.5, false, '#444');
    pages.push(page);
  }

  startPage(true);

  for (let i = 0; i < records.length; i++) {
    const r = records[i];
    const isTt = isTtRecord(r.doses);
    const ageGroup = isTt ? 'Woman (TT)' : (AGE_LABELS[ageBracketKey(ageMonths(r.dob, r.vaccDate))] || '');
    const dv = dateAndVaccinatorText(r);
    const values = [
      String(i + 1), r.id || '—', r.name || '—', r.fatherName || '—',
      dmy(r.dob) || '—', dv.dateText, vaccineLabel(r),
      r.address || '—', dv.vaccinatorText, statusLabel(r) + ' / ' + ageGroup
    ];

    const cells = values.map((v, ci) => wrapText(v, COLS[ci].w - PAD * 2, FS, ci === 2));
    const rowH = Math.max(...cells.map(l => l.length)) * LH + PAD * 2;

    if (y + rowH > BOTTOM) { endPage(); startPage(false); }

    page.strokeColor('#888'); page.lineWidth(0.4); page.rect(MG, y, TABLE_W, rowH, 'S');
    let x = MG;
    cells.forEach((lines, ci) => {
      lines.forEach((ln, li) => page.text(x + PAD, y + PAD + FS * 0.9 + li * LH, ln, FS, ci === 2));
      x += COLS[ci].w;
      if (ci < COLS.length - 1) page.line(x, y, x, y + rowH);
    });
    y += rowH;

    if (i % 200 === 199) await new Promise(res => setTimeout(res, 0)); // keep the UI alive
  }
  endPage();

  return assemblePdf(pages, PT_W, PT_H);
}

// ---------- "Card Style" export — one card per child, mirroring the exact
// on-screen record card (QR Code, Name, Father/Husband, DOB, Vaccination
// Date, Address, Vaccine, Vaccinator) instead of a compact table row.
// Each record gets its OWN page, sized to a phone screen's proportions and
// just tall enough for that one card — so opening it on a phone shows the
// whole card edge to edge, already legible, with no pinch-zoom or side
// scroll needed. ----------
async function buildRecordCardsPdf(title, records){
  const PG_W = 420;                 // ~phone-width page, in points
  const MG = 18;
  const AW = PG_W - MG * 2;
  const PADX = 14;
  const CARD_W = AW;
  const LABEL_W = 112;
  const VAL_W = CARD_W - 2 * PADX - LABEL_W;
  const VAL_SIZE = 12.5;
  const LABEL_SIZE = 9.5;
  const LABEL_COLOR = '#5f665d', VAL_COLOR = '#1f2420';
  const AV = 56, AV_GAP = 10;                 // gender avatar badge
  const BLOCK_LABEL_W = 92;
  const BLOCK_VAL_W = CARD_W - 2 * PADX - AV - AV_GAP - BLOCK_LABEL_W;

  function wrapText(text, maxW, size){
    const raw = String(text == null ? '' : text);
    if (!raw.trim()) return ['—'];
    const words = raw.split(/\s+/).filter(Boolean);
    const lines = [];
    let cur = '';
    for (const w of words) {
      const test = cur ? cur + ' ' + w : w;
      if (measureText(test, size, false) <= maxW) { cur = test; continue; }
      if (cur) lines.push(cur);
      if (measureText(w, size, false) <= maxW) { cur = w; continue; }
      let piece = '';
      for (const ch of w) {
        if (piece && measureText(piece + ch, size, false) > maxW) { lines.push(piece); piece = ch; }
        else piece += ch;
      }
      cur = piece;
    }
    if (cur) lines.push(cur);
    return lines.length ? lines : ['—'];
  }

  // Baseline offset that visually centers text of a given size inside a box
  // of height boxH starting at boxTop (Helvetica's cap-height/descender split
  // is close enough to 0.72/0.28 of the em for this to look centered).
  function vcenter(boxTop, boxH, size){ return boxTop + boxH / 2 + size * 0.22; }

  function fieldsFor(r){
    const isTt = isTtRecord(r.doses);
    const dv = dateAndVaccinatorText(r);
    const dobText = r.dob ? `${String(r.dob.day).padStart(2,'0')}/${String(r.dob.month).padStart(2,'0')}/${r.dob.year}` : '—';
    const tags = isTt ? classifyTT(r.doses) : classifyEpi(r.doses);
    const vaccineText = tags.length
      ? tags.map(t => isTt ? (TT_LABELS[t] || t) : (EPI_SHORT[t] || t)).join(', ')
      : (isTt ? 'No TT dose recorded' : 'No vaccine recorded');
    const personLabel = isTt ? 'Husband Name' : 'Father Name';
    const statusText = r.outOfDistrict ? 'Out From District' : (r.outOfTaluka ? 'Out From Taluka' : (r.outOfUc ? 'Out of UC' : (isTt ? 'Woman' : (AGE_LABELS[ageBracketKey(ageMonths(r.dob, r.vaccDate))] || ''))));
    return {
      // Same header as the Defaulter Children cards: EPI No / QR Code
      idVal: `${r.epiNo || '—'}  /  ${r.id || '—'}`,
      statusText,
      gender: r.gender || null,
      isTt,                                    // TT record = a woman → woman picture
      name: r.name || 'Name not recorded',
      personLabel,
      fatherName: r.fatherName || '—',
      dobText,
      rest: [
        ['Vaccination Date', dv.dateText],
        ['Address', r.address || '—'],
        ['Vaccine', vaccineText],
        ['Vaccinator', dv.vaccinatorText],
      ],
    };
  }

  // Draws the card body when `pg` is a real page, or silently walks through
  // the exact same layout math when `pg` is null — used first to measure the
  // content height needed, then again to actually draw it, so measurement
  // and drawing can never drift out of sync with each other.
  function renderCardBody(pg, xCard, y0, f, idx){
    let cy = y0 + 12;

    // EPI No / QR Code header bar
    if (pg) { pg.fillColor('#e7eef6'); pg.rect(xCard + PADX, cy, CARD_W - 2 * PADX, 26, 'f'); }
    if (pg) {
      pg.text(xCard + PADX + 7, vcenter(cy, 26, LABEL_SIZE), 'EPI No / QR Code', LABEL_SIZE, true, '#2f5f8f');
      pg.text(xCard + CARD_W - PADX - 7 - measureText(f.idVal, VAL_SIZE, true), vcenter(cy, 26, VAL_SIZE), f.idVal, VAL_SIZE, true, VAL_COLOR);
    }
    cy += 36;

    // Avatar badge + Name / Father-Husband / DOB, laid out beside it
    // TT (tetanus) records are women → always the woman picture; children use the boy/girl badge.
    const avatarName = f.isTt ? 'Woman' : (f.gender === 'M' ? 'Boy' : (f.gender === 'F' ? 'Girl' : null));
    const blockTop = cy;
    if (pg && avatarName) pg.image(avatarName, xCard + PADX, blockTop, AV, AV);
    const blockX = xCard + PADX + AV + AV_GAP;

    function blockRow(label, value){
      let lines = wrapText(String(value == null || value === '' ? '—' : value), BLOCK_VAL_W, VAL_SIZE);
      if (lines.length > 2) lines = [lines[0], lines[1].replace(/.{0,3}$/, '') + '…'];
      if (pg) {
        pg.text(blockX, cy + 11, label, LABEL_SIZE, false, LABEL_COLOR);
        pg.text(blockX + BLOCK_LABEL_W, cy + 11, lines[0], VAL_SIZE, false, VAL_COLOR);
      }
      cy += 18;
      for (let k = 1; k < lines.length; k++) {
        if (pg) pg.text(blockX + BLOCK_LABEL_W, cy + 11, lines[k], VAL_SIZE, false, VAL_COLOR);
        cy += 17;
      }
    }
    blockRow('Name', f.name);
    blockRow(f.personLabel, f.fatherName);
    blockRow('Date of Birth', f.dobText);
    cy = Math.max(cy, blockTop + AV + 8);

    // Remaining full-width fields
    function line(label, value){
      let lines = wrapText(String(value == null || value === '' ? '—' : value), VAL_W, VAL_SIZE);
      if (lines.length > 2) lines = [lines[0], lines[1].replace(/.{0,3}$/, '') + '…'];
      if (pg) {
        pg.text(xCard + PADX, cy + 11, label, LABEL_SIZE, false, LABEL_COLOR);
        pg.text(xCard + PADX + LABEL_W, cy + 11, lines[0], VAL_SIZE, false, VAL_COLOR);
      }
      cy += 18;
      for (let k = 1; k < lines.length; k++) {
        if (pg) pg.text(xCard + PADX + LABEL_W, cy + 11, lines[k], VAL_SIZE, false, VAL_COLOR);
        cy += 17;
      }
    }
    f.rest.forEach(([label, value]) => line(label, value));

    if (pg) {
      pg.text(xCard + PADX, cy + 12, 'No. ' + (idx + 1), LABEL_SIZE, false, LABEL_COLOR);
      pg.text(xCard + CARD_W - PADX - measureText(f.statusText, LABEL_SIZE, false), cy + 12, f.statusText, LABEL_SIZE, false, LABEL_COLOR);
    }
    return cy; // absolute y of the content's bottom edge (before the 24pt pad)
  }

  const HEAD_H = 46, HEAD_GAP = 10, FOOT_H = 24;
  const pages = [];

  for (let idx = 0; idx < records.length; idx++) {
    const r = records[idx];
    const f = fieldsFor(r);
    const dryCy = renderCardBody(null, 0, 0, f, idx);
    const cardH = dryCy + 24;
    const pgH = MG + HEAD_H + HEAD_GAP + cardH + HEAD_GAP + FOOT_H + MG;

    const page = new PdfPage(PG_W, pgH);
    const LOGO_SIZE = 22;
    page.image('Logo', PG_W - MG - LOGO_SIZE, 3, LOGO_SIZE, LOGO_SIZE);

    let y = MG;
    page.text(MG, y + 13, 'SIER — EPI Calculator', 13, true);
    y += 16;
    page.text(MG, y + 9, title, 9, false, '#444');
    y += 12;
    const rc = `No. ${idx + 1} of ${records.length}`;
    page.text(MG, y + 8, 'Printed: ' + printableDate(), 8, false, '#888');
    page.text(PG_W - MG - measureText(rc, 8, false), y + 8, rc, 8, false, '#888');
    y += 10;
    page.strokeColor('#000'); page.lineWidth(1);
    page.line(MG, y, MG + AW, y);
    y += HEAD_GAP;

    const y0 = y;
    page.strokeColor('#e2ddd5'); page.lineWidth(1);
    page.rect(MG, y0, CARD_W, cardH, 'S');
    renderCardBody(page, MG, y0, f, idx);

    const footY = y0 + cardH + HEAD_GAP;
    page.text(MG, footY + 8, 'SIER EPI Calculator — generated offline on this device', 7, false, '#888');
    const pg = 'Page ' + (idx + 1);
    page.text(PG_W - MG - measureText(pg, 7, false), footY + 8, pg, 7, false, '#888');

    pages.push(page);
    if (idx % 150 === 149) await new Promise(res => setTimeout(res, 0));
  }

  return assemblePdf(pages, PG_W, pages.length ? pages[0].h : 600);
}
