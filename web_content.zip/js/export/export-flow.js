function visibleTitle(id, fallback){
  const el = document.getElementById(id);
  const t = el ? el.textContent.trim() : '';
  return t || fallback;

}

// (downloadBlobFile lives in js/platform/downloads.js)

async function exportRecordsPdf(title, records, slug){
  if (!records || !records.length) { backupMsg('There is nothing to save as PDF in this list.', true); return; }
  if (records.length > 1500 && !await confirmDialog(`This list has ${records.length} records. The PDF will be large and may take a minute.`, 'Create PDF')) return;
  backupMsg('Creating PDF… please wait.');
  await new Promise(res => setTimeout(res, 30));
  try {
    const blob = await buildRecordsPdf(title, records);
    downloadBlobFile(`EPI-${slug}-${fileStamp()}.pdf`, blob);
    backupMsg(`✔ PDF saved — ${records.length} record(s). Check your Downloads folder.`);
  } catch (e) {
    console.error('pdf failed', e);
    if (buildPrintDoc(title, records) && typeof window.print === 'function') {
      backupMsg('PDF file could not be built here — opening the print dialog instead.', true);
      setTimeout(() => window.print(), 80);
    } else {
      backupMsg('PDF could not be created on this device.', true);
    }
  }
}

// Same PDF, but handed to the device's native Share sheet instead of the
// Downloads folder — falls back to a normal download if sharing files isn't
// supported here (older WebViews / desktop browsers).
async function shareRecordsPdf(title, records, slug){
  if (!records || !records.length) { backupMsg('There is nothing to share in this list.', true); return; }
  if (records.length > 1500 && !await confirmDialog(`This list has ${records.length} records. The PDF will be large and may take a minute.`, 'Create PDF')) return;
  backupMsg('Creating PDF to share… please wait.');
  await new Promise(res => setTimeout(res, 30));
  try {
    const blob = await buildRecordsPdf(title, records);
    const filename = `EPI-${slug}-${fileStamp()}.pdf`;
    const file = new File([blob], filename, { type: 'application/pdf' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title });
      backupMsg('✔ Share sheet opened.');
    } else {
      downloadBlobFile(filename, blob);
      backupMsg('Direct sharing isn\'t supported here — the PDF was saved instead. Check your Downloads folder.');
    }
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('share failed', e);
    backupMsg('Could not share the PDF on this device.', true);
  }
}

// ---------- Unified export flow: choose Share/Download, then Card/Print
// style, then build and hand off the right PDF. Used everywhere a person
// can export a list of child records. ----------

// Hands a finished PDF to the person: saved to Downloads (+ notification-bar
// entry, see downloads.js) or given to the phone's Share sheet.
async function deliverPdf(action, blob, filename, title, countLabel){
  if (action === 'download') {
    downloadBlobFile(filename, blob);
    backupMsg(`✔ PDF saved — ${countLabel}. Check your Downloads folder.`);
    return;
  }
  const file = new File([blob], filename, { type: 'application/pdf' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    await navigator.share({ files: [file], title });
    backupMsg('✔ Share sheet opened.');
  } else {
    downloadBlobFile(filename, blob);
    backupMsg('Direct sharing isn\'t supported here — the PDF was saved instead. Check your Downloads folder.');
  }
}

async function runRecordsExportFlow(title, records, slug){
  if (!records || !records.length) { backupMsg('There is nothing to share or download in this list.', true); return; }
  const action = await chooseAction();
  if (!action) return;
  const style = await chooseExportStyle();
  if (!style) return;
  if (records.length > 1500 && !await confirmDialog(`This list has ${records.length} records. The PDF will be large and may take a minute.`, 'Continue')) return;

  backupMsg(`Creating PDF${action === 'share' ? ' to share' : ''}… please wait.`);
  await new Promise(res => setTimeout(res, 30));
  const slugFull = slug + (style === 'card' ? '-cards' : '');
  try {
    const blob = style === 'card' ? await buildRecordCardsPdf(title, records) : await buildRecordsPdf(title, records);
    const filename = `EPI-${slugFull}-${fileStamp()}.pdf`;
    await deliverPdf(action, blob, filename, title, `${records.length} record(s)`);
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('export failed', e);
    if (style === 'print' && buildPrintDoc(title, records) && typeof window.print === 'function') {
      backupMsg('PDF file could not be built here — opening the print dialog instead.', true);
      setTimeout(() => window.print(), 80);
    } else {
      backupMsg('PDF could not be created on this device.', true);
    }
  }
}

// Search Records: share/download ONE child's details. Card Style only — so
// there is no style question, just Share or Download.
async function runSingleCardExportFlow(record){
  if (!record) { backupMsg('Nothing to share for this card.', true); return; }
  const action = await chooseAction();
  if (!action) return;
  backupMsg(`Creating card${action === 'share' ? ' to share' : ''}… please wait.`);
  await new Promise(res => setTimeout(res, 30));
  try {
    const title = record.name ? `Child Record — ${record.name}` : 'Child Record';
    const blob = await buildRecordCardsPdf(title, [record]);
    const filename = `EPI-card-${record.id || 'record'}-${fileStamp()}.pdf`;
    await deliverPdf(action, blob, filename, title, '1 card');
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('single card export failed', e);
    backupMsg('The card could not be created on this device.', true);
  }
}

// Same flow for Defaulters lists (address-wise / vaccine-wise / covered).
async function runDefaultersExportFlow(title, results, slug){
  if (!results || !results.length) { backupMsg('There is nothing to share or download in this list.', true); return; }
  const action = await chooseAction();
  if (!action) return;
  const style = await chooseExportStyle();
  if (!style) return;

  backupMsg(`Creating PDF${action === 'share' ? ' to share' : ''}… please wait.`);
  await new Promise(res => setTimeout(res, 30));
  const slugFull = slug + (style === 'card' ? '-cards' : '');
  try {
    const blob = style === 'card' ? await buildDefaultersCardsPdf(title, results) : await buildDefaultersPdf(title, results);
    const filename = `EPI-${slugFull}-${fileStamp()}.pdf`;
    await deliverPdf(action, blob, filename, title, `${results.length} record(s)`);
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('defaulters export failed', e);
    backupMsg('PDF could not be created on this device.', true);
  }
}

// (The "Save All Records as PDF" button was removed from the Results Menu; exportRecordsPdf() above is kept in case it is needed again.)
document.getElementById('btnPdfDrill').addEventListener('click', () =>
  runRecordsExportFlow(visibleTitle('drillTitle', 'Vaccine List'), lastRendered['drillDetailTable'], 'vaccine'));
