// ---------- minimal PDF writer (real text objects, /FlateDecode) ----------
// Standard-14 Helvetica / Helvetica-Bold metrics (AFM widths, 1/1000 em) for
// WinAnsiEncoding. These fonts are built into every PDF reader, so no font
// file needs to be embedded — and because real text objects are written
// (not an image of the page), the PDF is searchable and text can be copied.
const HELV_WIDTHS = {32:278,33:278,34:355,35:556,36:556,37:889,38:667,39:191,40:333,41:333,42:389,43:584,44:278,45:333,46:278,47:278,48:556,49:556,50:556,51:556,52:556,53:556,54:556,55:556,56:556,57:556,58:278,59:278,60:584,61:584,62:584,63:556,64:1015,65:667,66:667,67:722,68:722,69:667,70:611,71:778,72:722,73:278,74:500,75:667,76:556,77:833,78:722,79:778,80:667,81:778,82:722,83:667,84:611,85:722,86:667,87:944,88:667,89:667,90:611,91:278,92:278,93:278,94:469,95:556,96:333,97:556,98:556,99:500,100:556,101:556,102:278,103:556,104:556,105:222,106:222,107:500,108:222,109:833,110:556,111:556,112:556,113:556,114:333,115:500,116:278,117:556,118:500,119:722,120:500,121:500,122:500,123:334,124:260,125:334,126:584,150:556,151:1000};
const HELVB_WIDTHS = {32:278,33:333,34:474,35:556,36:556,37:889,38:722,39:238,40:333,41:333,42:389,43:584,44:278,45:333,46:278,47:278,48:556,49:556,50:556,51:556,52:556,53:556,54:556,55:556,56:556,57:556,58:333,59:333,60:584,61:584,62:584,63:611,64:975,65:722,66:722,67:722,68:722,69:667,70:611,71:778,72:722,73:278,74:556,75:722,76:611,77:833,78:722,79:778,80:667,81:778,82:722,83:667,84:611,85:722,86:667,87:944,88:667,89:667,90:611,91:333,92:278,93:333,94:584,95:556,96:333,97:556,98:611,99:556,100:611,101:556,102:333,103:611,104:611,105:278,106:278,107:556,108:278,109:889,110:611,111:611,112:611,113:611,114:389,115:556,116:333,117:611,118:556,119:778,120:556,121:556,122:500,123:389,124:280,125:389,126:584,150:556,151:1000};

// Map a Unicode character to its WinAnsiEncoding byte (0-255). Anything with
// no safe mapping falls back to '?' so the PDF never gets a corrupt string.
function charToWinAnsi(ch){
  const cp = ch.codePointAt(0);
  if (cp >= 32 && cp <= 126) return cp;
  const special = { 0x2013:150, 0x2014:151, 0x2018:145, 0x2019:146, 0x201C:147, 0x201D:148, 0x2022:149, 0x2026:133, 0x00A0:32 };
  if (special[cp] !== undefined) return special[cp];
  if (cp >= 160 && cp <= 255) return cp;
  return 63; // '?'
}

function glyphWidth(code, bold){
  const t = bold ? HELVB_WIDTHS : HELV_WIDTHS;
  return t[code] !== undefined ? t[code] : 556;
}

function measureText(str, size, bold){
  let w = 0;
  for (const ch of String(str == null ? '' : str)) w += glyphWidth(charToWinAnsi(ch), bold);
  return w / 1000 * size;
}

// Bytes for a PDF literal string's contents (no surrounding parens), with
// '(', ')' and '\' escaped and every character mapped to WinAnsi.
function pdfStringBytes(str){
  const out = [];
  for (const ch of String(str == null ? '' : str)) {
    const code = charToWinAnsi(ch);
    if (code === 40 || code === 41 || code === 92) out.push(92);
    out.push(code);
  }
  return out;
}

function fx(n){ return (Math.round(n * 100) / 100).toString(); }

function hexToRgb01(hex){
  let h = hex.replace('#', '');
  if (h.length === 3) h = h.split('').map(c => c + c).join('');
  const n = parseInt(h, 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

// One PDF page's content stream, built as a list of ASCII operator chunks
// and raw WinAnsi byte chunks (for text), concatenated at the end.
class PdfPage {
  constructor(w, h){ this.w = w; this.h = h; this.ops = []; }
  ascii(s){ this.ops.push({ bytes: false, v: s }); }
  raw(bytes){ this.ops.push({ bytes: true, v: bytes }); }
  fillColor(hex){ const [r,g,b] = hexToRgb01(hex); this.ascii(`${fx(r)} ${fx(g)} ${fx(b)} rg\n`); }
  strokeColor(hex){ const [r,g,b] = hexToRgb01(hex); this.ascii(`${fx(r)} ${fx(g)} ${fx(b)} RG\n`); }
  lineWidth(w){ this.ascii(`${fx(w)} w\n`); }
  rect(x, yTop, w, h, mode){ // mode: 'f' fill, 'S' stroke, 'B' both
    const y = this.h - yTop - h;
    this.ascii(`${fx(x)} ${fx(y)} ${fx(w)} ${fx(h)} re ${mode}\n`);
  }
  line(x1, yTop1, x2, yTop2){
    this.ascii(`${fx(x1)} ${fx(this.h - yTop1)} m ${fx(x2)} ${fx(this.h - yTop2)} l S\n`);
  }
  image(name, x, yTop, w, h){
    const y = this.h - yTop - h;
    this.ascii(`q ${fx(w)} 0 0 ${fx(h)} ${fx(x)} ${fx(y)} cm /${name} Do Q\n`);
  }
  text(x, yTop, str, size, bold, colorHex){
    const [r,g,b] = hexToRgb01(colorHex || '#000');
    const y = this.h - yTop;
    this.ascii(`BT ${fx(r)} ${fx(g)} ${fx(b)} rg /${bold ? 'F2' : 'F1'} ${fx(size)} Tf ${fx(x)} ${fx(y)} Td (`);
    this.raw(pdfStringBytes(str));
    this.ascii(`) Tj ET\n`);
  }
  toBytes(){
    const enc = new TextEncoder();
    const parts = this.ops.map(op => op.bytes ? Uint8Array.from(op.v) : enc.encode(op.v));
    const total = parts.reduce((s, p) => s + p.length, 0);
    const out = new Uint8Array(total);
    let off = 0;
    parts.forEach(p => { out.set(p, off); off += p.length; });
    return out;
  }
}

async function deflateBytes(bytes){
  try {
    if (typeof CompressionStream === 'undefined') throw new Error('no CompressionStream');
    const cs = new CompressionStream('deflate');
    const writer = cs.writable.getWriter();
    writer.write(bytes);
    writer.close();
    return { data: new Uint8Array(await new Response(cs.readable).arrayBuffer()), filter: 'FlateDecode' };
  } catch (e) {
    return { data: bytes, filter: null }; // older WebViews: store uncompressed
  }
}


function base64ToBytes(b64){
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function assemblePdf(pages, ptW, ptH){
  const enc = new TextEncoder();
  const chunks = [];
  let len = 0;
  const push = d => { const b = (typeof d === 'string') ? enc.encode(d) : d; chunks.push(b); len += b.length; };

  const n = pages.length;
  const objs = [];
  const kids = [];
  for (let i = 0; i < n; i++) kids.push(`${9 + i * 2} 0 R`);
  objs[0] = { head: '<< /Type /Catalog /Pages 2 0 R >>' };
  objs[1] = { head: `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${n} >>` };
  objs[2] = { head: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>' };
  objs[3] = { head: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>' };
  const logoBytes = base64ToBytes(LOGO_JPEG_B64);
  objs[4] = { head: `<< /Type /XObject /Subtype /Image /Width ${LOGO_W} /Height ${LOGO_H} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${logoBytes.length} >>`, stream: logoBytes };
  const boyBytes = base64ToBytes(BOY_AVATAR_B64);
  objs[5] = { head: `<< /Type /XObject /Subtype /Image /Width ${AVATAR_W} /Height ${AVATAR_H} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${boyBytes.length} >>`, stream: boyBytes };
  const girlBytes = base64ToBytes(GIRL_AVATAR_B64);
  objs[6] = { head: `<< /Type /XObject /Subtype /Image /Width ${AVATAR_W} /Height ${AVATAR_H} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${girlBytes.length} >>`, stream: girlBytes };
  const womanBytes = base64ToBytes(WOMAN_AVATAR_B64);
  objs[7] = { head: `<< /Type /XObject /Subtype /Image /Width ${AVATAR_W} /Height ${AVATAR_H} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${womanBytes.length} >>`, stream: womanBytes };

  for (let i = 0; i < n; i++) {
    const pid = 9 + i * 2, cid = pid + 1;
    // Each page carries its own w/h (set when it was created) so a document
    // can mix page sizes — e.g. one mobile-sized page per record card.
    const pw = pages[i].w || ptW, ph = pages[i].h || ptH;
    objs[pid - 1] = { head: `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << /Logo 5 0 R /Boy 6 0 R /Girl 7 0 R /Woman 8 0 R >> >> /Contents ${cid} 0 R >>` };
    const enc2 = await deflateBytes(pages[i].toBytes());
    const filterStr = enc2.filter ? ` /Filter /${enc2.filter}` : '';
    objs[cid - 1] = { head: `<< /Length ${enc2.data.length}${filterStr} >>`, stream: enc2.data };
  }

  push('%PDF-1.4\n');
  push(new Uint8Array([0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A])); // binary marker
  const xref = [];
  for (let i = 0; i < objs.length; i++) {
    xref.push(len);
    push(`${i + 1} 0 obj\n${objs[i].head}\n`);
    if (objs[i].stream) { push('stream\n'); push(objs[i].stream); push('\nendstream\n'); }
    push('endobj\n');
  }
  const startxref = len;
  let tail = `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  xref.forEach(o => { tail += String(o).padStart(10, '0') + ' 00000 n \n'; });
  tail += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${startxref}\n%%EOF\n`;
  push(tail);

  return new Blob(chunks, { type: 'application/pdf' });
}
