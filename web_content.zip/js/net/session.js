// Sesión de varios jugadores en la misma red Wi‑Fi. Topología en estrella: el anfitrión se conecta con cada invitado (una conexión
// por invitado, cada una con su par de códigos) y reenvía a los demás lo que le llega. Hasta MAX_PLAYERS jugadores en total.
//
// Mensajes (JSON): hi {id,name,hue,w} · roster {players} · join {player} · bye {id} · p {id,w,x,y,z,h,s,f}.
// La sesión no sabe nada de WebRTC: trabaja con «enlaces» (PeerLink o falsos en las pruebas) con send / onmessage / onstate / close.
import { PeerLink } from './peer.js';

export const MAX_PLAYERS = 4;
const SEND_EVERY_MS = 100; // 10 posiciones por segundo
const STALE_MS = 15000; // sin ningún mensaje de un enlace durante este tiempo → se le da por perdido
const TICK_MS = 2000; // latido y vigilancia de enlaces muertos

const newId = () => Math.random().toString(36).slice(2, 8);
const pickHue = () => Math.floor(Math.random() * 360);

export class NetSession {
  constructor({ name = 'Jugador', now = () => performance.now(), makeLink = () => new PeerLink() } = {}) {
    this.id = newId();
    this.name = String(name).slice(0, 16) || 'Jugador';
    this.hue = pickHue();
    this.world = ''; // 'eden' | 'shen' | '' (en el menú, sin mundo abierto)
    this.mode = 'idle'; // idle | host | guest
    this.players = new Map(); // id → {id,name,hue,w,x,y,z,h,s,f,got}
    this.links = new Map(); // id del jugador → enlace
    this.pending = new Set(); // enlaces aún sin saludo
    this.heard = new Map(); // id → última vez que llegó algo por su enlace
    this._subs = new Set(); // oyentes: (tipo: 'change' | 'end', motivo)
    this._now = now;
    this._makeLink = makeLink;
    this._lastSend = 0;
    this._iv = 0;
  }

  get active() {
    return this.mode !== 'idle';
  }
  get count() {
    return this.players.size + 1;
  }
  me() {
    return { id: this.id, name: this.name, hue: this.hue, w: this.world };
  }
  setWorld(w) {
    if (this.world === w) return;
    this.world = w;
    this._broadcast({ t: 'hi', ...this.me() }, true);
  }
  list() {
    return [...this.players.values()];
  }

  // Suscripción a cambios (jugadores, estado) y al fin de la sesión. Devuelve la función para darse de baja.
  on(fn) {
    this._subs.add(fn);
    return () => this._subs.delete(fn);
  }
  _emit(kind = 'change', arg = '') {
    for (const f of [...this._subs]) {
      try {
        f(kind, arg);
      } catch (err) {
        console.warn('[red] oyente con error', err);
      }
    }
  }

  // ── Anfitrión ─────────────────────────────────────────────────────────────────────────────────
  // Crea una invitación: devuelve { code, finish(codigoDeRespuesta), cancel() }. «finish» resuelve cuando el invitado entra.
  async invite() {
    if (this.mode === 'guest') throw new Error('Ya estás unido a la partida de otra persona.');
    if (this.count + this.pending.size >= MAX_PLAYERS) throw new Error(`La partida está llena (${MAX_PLAYERS} jugadores).`);
    const link = this._makeLink();
    this.pending.add(link);
    const code = await link.createOffer().catch((e) => {
      this.pending.delete(link);
      link.close();
      throw e;
    });
    this.mode = 'host';
    this._startTick();
    const opened = new Promise((resolve, reject) => this._wire(link, resolve, reject));
    opened.catch(() => {}); // si nadie la espera, el rechazo no debe quedar sin atender
    return {
      code,
      opened,
      finish: async (answerCode) => {
        await link.acceptAnswer(answerCode);
        return opened;
      },
      cancel: () => {
        this.pending.delete(link);
        link.close();
        if (!this.links.size && !this.pending.size) this.mode = 'idle';
      },
    };
  }

  // ── Invitado ──────────────────────────────────────────────────────────────────────────────────
  // Lee el código del anfitrión: devuelve { code (la respuesta que hay que enseñarle), opened }.
  async join(hostCode) {
    if (this.active) throw new Error('Ya estás en una partida. Sal de ella antes de unirte a otra.');
    const link = this._makeLink();
    this.pending.add(link);
    let code;
    try {
      code = await link.acceptOffer(hostCode);
    } catch (e) {
      this.pending.delete(link);
      link.close();
      throw e;
    }
    this.mode = 'guest';
    this._startTick();
    const opened = new Promise((resolve, reject) => this._wire(link, resolve, reject));
    opened.catch(() => {});
    return { code, opened, cancel: () => this.leave() };
  }

  // ── Enlaces ───────────────────────────────────────────────────────────────────────────────────
  _wire(link, resolve, reject) {
    let peerId = null;
    let settled = false;
    link.onstate = (s) => {
      if (s === 'open') link.send({ t: 'hi', ...this.me() });
      else if (s === 'failed' || s === 'closed') {
        this.pending.delete(link);
        if (!settled) {
          settled = true;
          reject(new Error(link.error || 'La conexión se cerró antes de terminar.'));
        }
        if (peerId) this._drop(peerId, link);
        else if (!this.links.size && !this.pending.size && this.mode === 'host') this.mode = 'idle';
        if (this.mode === 'guest' && !this.links.size && !this.pending.size) this._end(link.error || 'El anfitrión cerró la partida o se perdió la conexión.');
      }
    };
    link.onmessage = (m) => {
      if (m.t === 'hi' && !peerId) {
        peerId = String(m.id);
        this.pending.delete(link);
        this.links.set(peerId, link);
        this.heard.set(peerId, this._now());
        this._setPlayer(m);
        if (this.mode === 'host') {
          // El nuevo conoce a todos; los demás conocen al nuevo.
          link.send({ t: 'roster', players: this.list().filter((p) => p.id !== peerId).map(pub) });
          this._broadcast({ t: 'join', player: pub(this.players.get(peerId)) }, true, peerId);
        }
        if (!settled) {
          settled = true;
          resolve(this.players.get(peerId));
        }
        return;
      }
      if (!peerId) return;
      this.heard.set(peerId, this._now());
      this._receive(m, peerId);
    };
  }

  _receive(m, from) {
    if (m.t === 'k') return; // latido: ya se anotó al llegar
    if (m.t === 'hi') {
      this._setPlayer(m);
      if (this.mode === 'host') this._broadcast({ t: 'hi', ...pub(this.players.get(String(m.id))) }, true, from);
    } else if (m.t === 'roster' && this.mode === 'guest') {
      for (const p of m.players || []) this._setPlayer(p);
    } else if (m.t === 'join' && this.mode === 'guest') {
      this._setPlayer(m.player);
    } else if (m.t === 'bye') {
      if (this.mode === 'guest' && String(m.id) !== this.id) this._removePlayer(String(m.id));
    } else if (m.t === 'p') {
      const id = this.mode === 'host' ? from : String(m.id);
      const p = this.players.get(id);
      if (!p || id === this.id) return;
      Object.assign(p, { w: m.w, x: +m.x, y: +m.y, z: +m.z, h: +m.h || 0, s: +m.s || 0, f: m.f ? 1 : 0, got: true });
      if (this.mode === 'host') this._broadcast({ t: 'p', id, w: m.w, x: m.x, y: m.y, z: m.z, h: m.h, s: m.s, f: m.f }, false, from);
    }
  }

  _setPlayer(m) {
    const id = String(m.id);
    if (!id || id === this.id) return;
    const old = this.players.get(id);
    const p = {
      id,
      name: String(m.name || 'Jugador').slice(0, 16),
      hue: ((+m.hue || 0) % 360 + 360) % 360,
      w: m.w === 'shen' || m.w === 'eden' ? m.w : '',
      x: old?.x ?? 0, y: old?.y ?? 0, z: old?.z ?? 0, h: old?.h ?? 0, s: old?.s ?? 0, f: old?.f ?? 0,
      got: old?.got ?? false, // ¿ya llegó alguna posición?
    };
    this.players.set(id, p);
    this._emit();
  }

  _removePlayer(id) {
    if (this.players.delete(id)) this._emit();
  }

  _drop(id, link) {
    if (this.links.get(id) === link) {
      this.links.delete(id);
      this.heard.delete(id);
    }
    this._removePlayer(id);
    if (this.mode === 'host') {
      this._broadcast({ t: 'bye', id }, true);
      if (!this.links.size && !this.pending.size) this.mode = 'idle';
      this._emit();
    }
  }

  _broadcast(msg, reliable, exceptId = null) {
    for (const [id, link] of this.links) if (id !== exceptId) link.send(msg, reliable);
  }

  // Posición propia (se llama en cada fotograma; envía a ~10 Hz).
  sendState(s) {
    if (!this.links.size) return;
    const t = this._now();
    if (t - this._lastSend < SEND_EVERY_MS) return;
    this._lastSend = t;
    const r = (v, k) => Math.round(v * k) / k;
    const msg = { t: 'p', id: this.id, w: this.world, x: r(s.x, 100), y: r(s.y, 100), z: r(s.z, 100), h: r(s.h || 0, 100), s: r(s.s || 0, 10), f: s.f ? 1 : 0 };
    this._broadcast(msg, false);
  }

  _startTick() {
    if (this._iv) return;
    this._iv = setInterval(() => this.tick(), TICK_MS);
    this._iv.unref?.();
  }

  // Latido a los enlaces y cierre de los que llevan mucho sin dar señales (conexión muerta sin cierre limpio).
  tick() {
    this._broadcast({ t: 'k' }, true);
    const t = this._now();
    for (const [id, link] of this.links) if (t - (this.heard.get(id) ?? t) > STALE_MS) link.close();
  }

  _end(reason) {
    const all = [...this.links.values(), ...this.pending];
    this.links.clear();
    this.pending.clear();
    this.heard.clear();
    this.players.clear();
    this.mode = 'idle';
    clearInterval(this._iv);
    this._iv = 0;
    for (const l of all) {
      l.onstate = null;
      l.close();
    }
    this._emit('change');
    this._emit('end', reason);
  }

  // El usuario sale de la partida.
  leave() {
    if (this.mode === 'host') this._broadcast({ t: 'bye', id: this.id }, true);
    this._end('');
  }
}

const pub = (p) => ({ id: p.id, name: p.name, hue: p.hue, w: p.w });
