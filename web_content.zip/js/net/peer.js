// Conexión directa entre dos teléfonos de la misma red Wi‑Fi con WebRTC (canal de datos), sin servidor: la señalización se hace a
// mano intercambiando el código corto de js/net/code.js (leído como QR o pegado como texto). Sin STUN ni TURN: solo direcciones
// locales, así que no sale nada a internet.
//
// Dos canales ya negociados (mismo id en ambos lados, no hace falta esperar a «ondatachannel»):
//   · «rel» (id 0): fiable y ordenado → saludos, lista de jugadores, avisos.
//   · «fast» (id 1): sin orden y sin reenvíos → posiciones a ~10 Hz (si un paquete se pierde, llega el siguiente).
import { sdpToCode, codeToSdp } from './code.js';

const GATHER_MS = 3000; // sin STUN el reparto de candidatos es casi inmediato; este tope evita esperar de más
const CONNECT_MS = 25000;

export class PeerLink {
  // rtc: constructor de RTCPeerConnection (inyectable para pruebas).
  constructor({ RTC = globalThis.RTCPeerConnection } = {}) {
    if (!RTC) throw new Error('Este navegador no permite conexiones directas (WebRTC).');
    this.pc = new RTC({ iceServers: [], iceCandidatePoolSize: 0 });
    this.role = null;
    this.state = 'new'; // new → pairing → connecting → open → closed | failed
    this.error = '';
    this.onmessage = null;
    this.onstate = null;
    this._timer = 0;
    this.rel = this.pc.createDataChannel('rel', { negotiated: true, id: 0 });
    this.fast = this.pc.createDataChannel('fast', { negotiated: true, id: 1, ordered: false, maxRetransmits: 0 });
    for (const ch of [this.rel, this.fast]) {
      ch.onmessage = (e) => {
        let msg = null;
        try {
          msg = JSON.parse(e.data);
        } catch {
          return;
        }
        this.onmessage?.(msg);
      };
      ch.onclose = () => {
        if (this.state === 'open') this._set('closed');
      };
    }
    this.rel.onopen = () => {
      clearTimeout(this._timer);
      this._set('open');
    };
    this.pc.onconnectionstatechange = () => {
      const s = this.pc.connectionState;
      if (s === 'failed') this._fail('No se pudo conectar. Comprueba que los dos estén en la misma red Wi‑Fi (algunas redes de invitados lo impiden).');
      else if ((s === 'disconnected' || s === 'closed') && this.state === 'open') this._set('closed');
    };
  }

  _set(state) {
    if (this.state === state || this.state === 'closed') return;
    this.state = state;
    this.onstate?.(state);
  }

  _fail(msg) {
    if (this.state === 'closed' || this.state === 'failed') return;
    this.error = msg;
    this._set('failed');
  }

  async _gathered() {
    if (this.pc.iceGatheringState === 'complete') return;
    await new Promise((resolve) => {
      const done = () => {
        clearTimeout(t);
        this.pc.removeEventListener('icegatheringstatechange', check);
        resolve();
      };
      const check = () => this.pc.iceGatheringState === 'complete' && done();
      const t = setTimeout(done, GATHER_MS);
      this.pc.addEventListener('icegatheringstatechange', check);
    });
  }

  _armTimeout() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this._fail('Se acabó el tiempo sin conectar. Prueba de nuevo y comprueba que los dos usan la misma red Wi‑Fi.'), CONNECT_MS);
  }

  // Anfitrión: crea el código de invitación.
  async createOffer() {
    this.role = 'host';
    await this.pc.setLocalDescription(await this.pc.createOffer());
    await this._gathered();
    this._set('pairing');
    return sdpToCode(this.pc.localDescription.sdp, 'offer');
  }

  // Invitado: lee el código del anfitrión y devuelve el código de respuesta.
  async acceptOffer(code) {
    const { role, sdp } = codeToSdp(code);
    if (role !== 'offer') throw new Error('Ese es un código de respuesta. Aquí hace falta el de invitación del otro teléfono.');
    this.role = 'guest';
    await this.pc.setRemoteDescription({ type: 'offer', sdp });
    await this.pc.setLocalDescription(await this.pc.createAnswer());
    await this._gathered();
    this._set('connecting');
    this._armTimeout();
    return sdpToCode(this.pc.localDescription.sdp, 'answer');
  }

  // Anfitrión: lee la respuesta del invitado y la conexión se abre sola.
  async acceptAnswer(code) {
    if (this.role !== 'host') throw new Error('Primero hay que crear la invitación.');
    const { role, sdp } = codeToSdp(code);
    if (role !== 'answer') throw new Error('Ese es un código de invitación. Aquí hace falta la respuesta del otro teléfono.');
    await this.pc.setRemoteDescription({ type: 'answer', sdp });
    this._set('connecting');
    this._armTimeout();
  }

  get isOpen() {
    return this.state === 'open' && this.rel.readyState === 'open';
  }

  send(msg, reliable = true) {
    const ch = reliable ? this.rel : this.fast;
    if (ch.readyState !== 'open') return false;
    try {
      ch.send(JSON.stringify(msg));
      return true;
    } catch {
      return false;
    }
  }

  close() {
    clearTimeout(this._timer);
    const was = this.state;
    this.state = 'closed';
    try {
      this.rel.close();
      this.fast.close();
      this.pc.close();
    } catch {
      /* ya estaba cerrada */
    }
    if (was !== 'closed') this.onstate?.('closed');
  }
}
