// La sesión de red es única y sobrevive a entrar y salir de los mundos (EDEN ↔ SHENLONG): solo se cierra al salir de la partida.
import { NetSession } from './session.js';

let session = null;
export const getNet = () => session;
export function ensureNet(name) {
  if (!session) session = new NetSession({ name });
  return session;
}
export const netSupported = () => typeof RTCPeerConnection === 'function';
