// Jugadores remotos en el mundo: figuras sencillas (cuerpo, cabeza y piernas que se balancean) con el color y el nombre de cada
// jugador. No se envía el modelo del otro: pesaría mucho para una conexión manual y un móvil justo; así cada uno solo carga el suyo.
// Las posiciones llegan a ~10 Hz y aquí se suavizan para que el movimiento sea fluido a 60 fotogramas.
const TAU = Math.PI * 2;
const angleLerp = (a, b, k) => a + (((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI) * k;

function nameTexture(THREE, text, hue) {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(8,12,18,0.62)';
  g.beginPath();
  g.roundRect(4, 8, 248, 48, 24);
  g.fill();
  g.fillStyle = `hsl(${hue} 80% 70%)`;
  g.beginPath();
  g.arc(30, 32, 9, 0, TAU);
  g.fill();
  g.fillStyle = '#fff';
  g.font = '600 26px system-ui, sans-serif';
  g.textBaseline = 'middle';
  g.fillText(text, 50, 33, 190);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export class Remotes {
  // adapt(group): aplica niebla y sombras del mundo a las mallas (render.adaptCreature).
  constructor({ THREE, scene, adapt = () => {} }) {
    this.THREE = THREE;
    this.scene = scene;
    this.adapt = adapt;
    this.items = new Map();
    const legGeo = new THREE.BoxGeometry(0.17, 0.82, 0.17);
    legGeo.translate(0, -0.41, 0); // el giro se hace desde la cadera
    this.geo = {
      torso: new THREE.CapsuleGeometry(0.26, 0.5, 4, 10),
      head: new THREE.SphereGeometry(0.19, 14, 10),
      leg: legGeo,
    };
  }

  _make(p) {
    const T = this.THREE;
    const body = new T.MeshStandardMaterial({ color: new T.Color().setHSL(p.hue / 360, 0.62, 0.52), roughness: 0.85 });
    const skin = new T.MeshStandardMaterial({ color: new T.Color().setHSL(p.hue / 360, 0.35, 0.82), roughness: 0.8 });
    const root = new T.Group();
    root.rotation.order = 'YXZ';
    const inner = new T.Group();
    root.add(inner);
    const torso = new T.Mesh(this.geo.torso, body);
    torso.position.y = 1.18;
    const head = new T.Mesh(this.geo.head, skin);
    head.position.y = 1.6;
    const legL = new T.Mesh(this.geo.leg, body);
    const legR = new T.Mesh(this.geo.leg, body);
    legL.position.set(-0.11, 0.84, 0);
    legR.position.set(0.11, 0.84, 0);
    inner.add(torso, head, legL, legR);
    const tex = nameTexture(T, p.name, p.hue);
    const tag = new T.Sprite(new T.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
    tag.scale.set(2.2, 0.55, 1);
    tag.position.y = 2.25;
    tag.renderOrder = 20;
    root.add(tag);
    try {
      this.adapt(inner);
    } catch (err) {
      console.warn('[red] jugador sin niebla', err);
    }
    root.visible = false;
    this.scene.add(root);
    return { id: p.id, name: p.name, hue: p.hue, root, inner, legL, legR, mats: [body, skin, tag.material], tex, phase: 0, tilt: 0, placed: false, cur: { x: 0, y: 0, z: 0, h: 0 } };
  }

  _free(it) {
    this.scene.remove(it.root);
    for (const m of it.mats) m.dispose();
    it.tex.dispose();
  }

  // Altas, bajas y cambios de nombre o color según la lista de la sesión.
  sync(players) {
    const ids = new Set(players.map((p) => p.id));
    for (const [id, it] of this.items) if (!ids.has(id)) {
      this._free(it);
      this.items.delete(id);
    }
    for (const p of players) {
      const old = this.items.get(p.id);
      if (old && (old.name !== p.name || old.hue !== p.hue)) {
        this._free(old);
        this.items.delete(p.id);
      }
      if (!this.items.has(p.id)) this.items.set(p.id, this._make(p));
    }
  }

  // world: 'eden' | 'shen'. Solo se ven los jugadores que están en el mismo mundo y ya mandaron su posición.
  update(dt, players, world) {
    const k = 1 - Math.exp(-Math.min(dt, 0.1) * 12);
    for (const p of players) {
      const it = this.items.get(p.id);
      if (!it) continue;
      const show = p.got && p.w === world;
      it.root.visible = show;
      if (!show) {
        it.placed = false;
        continue;
      }
      const c = it.cur;
      if (!it.placed || Math.hypot(p.x - c.x, p.z - c.z) > 30) {
        Object.assign(c, { x: p.x, y: p.y, z: p.z, h: p.h });
        it.placed = true;
      } else {
        c.x += (p.x - c.x) * k;
        c.y += (p.y - c.y) * k;
        c.z += (p.z - c.z) * k;
        c.h = angleLerp(c.h, p.h, k);
      }
      it.root.position.set(c.x, c.y, c.z);
      it.root.rotation.y = c.h;
      it.tilt += ((p.f ? 0.9 : 0) - it.tilt) * k;
      it.root.rotation.x = it.tilt;
      const moving = p.s > 0.3 && !p.f;
      it.phase += dt * (3 + p.s * 1.5);
      const amp = moving ? Math.min(0.9, 0.25 + p.s * 0.12) : 0;
      it.legL.rotation.x += (Math.sin(it.phase) * amp - it.legL.rotation.x) * k;
      it.legR.rotation.x += (-Math.sin(it.phase) * amp - it.legR.rotation.x) * k;
    }
  }

  dispose() {
    for (const it of this.items.values()) this._free(it);
    this.items.clear();
    for (const g of Object.values(this.geo)) g.dispose();
  }
}
