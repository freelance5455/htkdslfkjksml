// Generador de códigos QR propio (modo byte, versiones 1–10, corrección L o M). Funciona sin internet y sin librerías: sirve para
// mostrar el código de emparejamiento y que el otro teléfono lo lea con la cámara. Se comprueba contra un lector externo (OpenCV).
const TOTAL = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346]; // palabras de código por versión
const EC = {
  // [palabras de corrección por bloque, nº de bloques]
  L: [null, [7, 1], [10, 1], [15, 1], [20, 1], [26, 1], [18, 2], [20, 2], [24, 2], [30, 2], [18, 4]],
  M: [null, [10, 1], [16, 1], [26, 1], [18, 2], [24, 2], [16, 4], [18, 4], [22, 4], [22, 5], [26, 5]],
};
const ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];
const FMT = { L: 1, M: 0 };
export const QR_MAX_VERSION = 10;

// Aritmética de Galois GF(256) con polinomio 0x11D.
const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);
{
  let x = 1;
  for (let i = 0; i < 255; i++) {
    EXP[i] = x;
    LOG[x] = i;
    x <<= 1;
    if (x & 256) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
}
const mul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);

function rsRemainder(data, degree) {
  let g = [1];
  for (let i = 0; i < degree; i++) {
    const n = new Array(g.length + 1).fill(0);
    for (let j = 0; j < g.length; j++) {
      n[j] ^= g[j];
      n[j + 1] ^= mul(g[j], EXP[i]);
    }
    g = n;
  }
  const r = new Array(degree).fill(0);
  for (const b of data) {
    const f = b ^ r.shift();
    r.push(0);
    for (let i = 0; i < degree; i++) r[i] ^= mul(g[i + 1], f);
  }
  return r;
}

const dataCapacity = (v, lvl) => TOTAL[v] - EC[lvl][v][0] * EC[lvl][v][1];

// Palabras de código finales (datos + corrección, intercaladas).
function buildCodewords(bytes, v, lvl) {
  const dataCw = dataCapacity(v, lvl);
  const bits = [];
  const push = (val, len) => {
    for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1);
  };
  push(4, 4);
  push(bytes.length, v >= 10 ? 16 : 8);
  for (const b of bytes) push(b, 8);
  push(0, Math.min(4, dataCw * 8 - bits.length));
  while (bits.length % 8) bits.push(0);
  const data = [];
  for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  for (let pad = 0xec; data.length < dataCw; pad ^= 0xec ^ 0x11) data.push(pad);

  const [ecLen, nBlocks] = EC[lvl][v];
  const shortLen = Math.floor(dataCw / nBlocks);
  const nShort = nBlocks - (dataCw % nBlocks);
  const blocks = [];
  let k = 0;
  for (let i = 0; i < nBlocks; i++) {
    const len = shortLen + (i < nShort ? 0 : 1);
    const d = data.slice(k, k + len);
    k += len;
    blocks.push({ d, e: rsRemainder(d, ecLen) });
  }
  const out = [];
  for (let i = 0; i <= shortLen; i++) for (const b of blocks) if (i < b.d.length) out.push(b.d[i]);
  for (let i = 0; i < ecLen; i++) for (const b of blocks) out.push(b.e[i]);
  return out;
}

const MASKS = [
  (x, y) => (x + y) % 2 === 0,
  (x, y) => y % 2 === 0,
  (x, y) => x % 3 === 0,
  (x, y) => (x + y) % 3 === 0,
  (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
  (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
  (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0,
  (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0,
];

function penalty(m) {
  const n = m.length;
  let p = 0;
  const lines = [];
  for (let y = 0; y < n; y++) lines.push(m[y].map((c) => (c ? '1' : '0')).join(''));
  for (let x = 0; x < n; x++) lines.push(m.map((r) => (r[x] ? '1' : '0')).join(''));
  for (const s of lines) {
    for (const run of s.match(/0+|1+/g)) if (run.length >= 5) p += 3 + run.length - 5; // tiras largas
    p += 40 * (s.match(/(?=10111010000|00001011101)/g) || []).length; // parecido a un localizador
  }
  for (let y = 0; y < n - 1; y++)
    for (let x = 0; x < n - 1; x++) if (m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
  let dark = 0;
  for (const r of m) for (const c of r) if (c) dark++;
  p += 10 * (Math.ceil(Math.abs(dark * 20 - n * n * 10) / (n * n)) - 1);
  return p;
}

function makeMatrix(codewords, v, lvl) {
  const n = 17 + 4 * v;
  const mods = Array.from({ length: n }, () => new Array(n).fill(false));
  const fn = Array.from({ length: n }, () => new Array(n).fill(false));
  const set = (x, y, dark) => {
    mods[y][x] = dark;
    fn[y][x] = true;
  };
  for (let i = 0; i < n; i++) {
    set(6, i, i % 2 === 0);
    set(i, 6, i % 2 === 0);
  }
  const finder = (cx, cy) => {
    for (let dy = -4; dy <= 4; dy++)
      for (let dx = -4; dx <= 4; dx++) {
        const x = cx + dx, y = cy + dy, d = Math.max(Math.abs(dx), Math.abs(dy));
        if (x >= 0 && x < n && y >= 0 && y < n) set(x, y, d !== 2 && d !== 4);
      }
  };
  finder(3, 3);
  finder(n - 4, 3);
  finder(3, n - 4);
  const al = ALIGN[v];
  const last = al[al.length - 1];
  for (const cy of al)
    for (const cx of al) {
      if ((cx === 6 && cy === 6) || (cx === 6 && cy === last) || (cx === last && cy === 6)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
  const drawFormat = (mask) => {
    const data = (FMT[lvl] << 3) | mask;
    let rem = data;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    const bits = ((data << 10) | rem) ^ 0x5412;
    const bit = (i) => ((bits >>> i) & 1) === 1;
    for (let i = 0; i <= 5; i++) set(8, i, bit(i));
    set(8, 7, bit(6));
    set(8, 8, bit(7));
    set(7, 8, bit(8));
    for (let i = 9; i < 15; i++) set(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i++) set(n - 1 - i, 8, bit(i));
    for (let i = 8; i < 15; i++) set(8, n - 15 + i, bit(i));
    set(8, n - 8, true);
  };
  drawFormat(0); // reserva el sitio; se reescribe con la máscara elegida
  if (v >= 7) {
    let rem = v;
    for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1f25);
    const bits = (v << 12) | rem;
    for (let i = 0; i < 18; i++) {
      const c = ((bits >>> i) & 1) === 1, a = n - 11 + (i % 3), b = Math.floor(i / 3);
      set(a, b, c);
      set(b, a, c);
    }
  }
  // Colocación de los datos en zigzag.
  let i = 0;
  for (let right = n - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < n; vert++)
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const y = ((right + 1) & 2) === 0 ? n - 1 - vert : vert;
        if (!fn[y][x] && i < codewords.length * 8) {
          mods[y][x] = ((codewords[i >> 3] >>> (7 - (i & 7))) & 1) === 1;
          i++;
        }
      }
  }
  let best = null, bestScore = Infinity, bestMask = 0;
  for (let mask = 0; mask < 8; mask++) {
    const m = mods.map((r, y) => r.map((c, x) => (fn[y][x] ? c : c !== MASKS[mask](x, y))));
    const s = penalty(m);
    if (s < bestScore) [best, bestScore, bestMask] = [m, s, mask];
  }
  // Copia la mejor máscara y reescribe los bits de formato con ella.
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) mods[y][x] = best[y][x];
  drawFormat(bestMask);
  return mods;
}

// Texto → matriz de módulos (true = oscuro). Elige la versión más pequeña con nivel M y, si no cabe, con L.
export function qrMatrix(text) {
  const bytes = new TextEncoder().encode(text);
  for (const lvl of ['M', 'L']) {
    for (let v = 1; v <= QR_MAX_VERSION; v++) {
      const cap = Math.floor((dataCapacity(v, lvl) * 8 - 4 - (v >= 10 ? 16 : 8)) / 8);
      if (bytes.length <= cap) return makeMatrix(buildCodewords(bytes, v, lvl), v, lvl);
    }
  }
  throw new Error('El texto es demasiado largo para un QR.');
}

// Dibuja el QR en un canvas (con margen blanco de 4 módulos). Devuelve el canvas.
export function drawQr(canvas, text, px = 280) {
  const m = qrMatrix(text);
  const quiet = 4;
  const cells = m.length + quiet * 2;
  const scale = Math.max(2, Math.floor(px / cells));
  canvas.width = canvas.height = cells * scale;
  const g = canvas.getContext('2d');
  g.fillStyle = '#fff';
  g.fillRect(0, 0, canvas.width, canvas.height);
  g.fillStyle = '#000';
  for (let y = 0; y < m.length; y++) for (let x = 0; x < m.length; x++) if (m[y][x]) g.fillRect((x + quiet) * scale, (y + quiet) * scale, scale, scale);
  return canvas;
}
