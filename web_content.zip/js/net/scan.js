// Lector de QR con la cámara (BarcodeDetector de Chrome). Es opcional: si el navegador o el permiso no lo permiten, se pega el
// código como texto. Devuelve { done: Promise<string|null>, stop() }; el vídeo se enseña en «video».
export const canScan = () => typeof BarcodeDetector === 'function' && !!navigator.mediaDevices?.getUserMedia;

export function scanQr(video) {
  let stopped = false;
  let stream = null;
  let timer = 0;
  const stop = () => {
    stopped = true;
    clearTimeout(timer);
    stream?.getTracks().forEach((t) => t.stop());
    stream = null;
    video.srcObject = null;
  };
  const done = (async () => {
    const detector = new BarcodeDetector({ formats: ['qr_code'] });
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
    if (stopped) return stop(), null;
    video.srcObject = stream;
    video.setAttribute('playsinline', '');
    await video.play().catch(() => {});
    return new Promise((resolve) => {
      const tick = async () => {
        if (stopped) return resolve(null);
        try {
          const found = await detector.detect(video);
          const hit = found.find((f) => /^RW1\./.test(f.rawValue || ''));
          if (hit) {
            stop();
            return resolve(hit.rawValue);
          }
        } catch {
          /* fotograma sin imagen todavía */
        }
        timer = setTimeout(tick, 220);
      };
      tick();
    });
  })().catch((err) => {
    stop();
    throw err;
  });
  return { done, stop };
}
