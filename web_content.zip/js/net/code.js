// Código de emparejamiento: la información mínima de una conexión WebRTC de datos (usuario y clave ICE, huella DTLS y direcciones
// locales) en unos 100–250 bytes, para mostrarla como QR o como texto corto que se copia y se pega. Sin servidor: dos teléfonos en
// la misma red Wi‑Fi se intercambian estos códigos (uno «de oferta» y otro «de respuesta») y se conectan directamente.
//
// Formato binario (todo en base64url, precedido de «RW1.»):
//   [ver<<4 | rol] [len ufrag][ufrag] [len pwd][pwd] [32 bytes huella SHA-256] [n] n × ([tipo][dirección][puerto u16]) [suma u16]
//   tipo 0 = IPv4 (4 bytes) · tipo 1 = texto (nombre mDNS «xxxx.local» o IPv6): [len][ascii]
export const CODE_PREFIX = 'RW1.';
const VERSION = 1;

const enc = new TextEncoder();
const dec = new TextDecoder();

export function toB64Url(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function fromB64Url(text) {
  const s = text.replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(s + '='.repeat((4 - (s.length % 4)) % 4));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

const sum16 = (bytes, end) => {
  let a = 1, b = 0;
  for (let i = 0; i < end; i++) {
    a = (a + bytes[i]) % 251;
    b = (b + a) % 251;
  }
  return (b << 8) | a;
};

const isIPv4 = (s) => /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.test(s) && s.split('.').every((p) => Number(p) <= 255);

// Extrae del SDP local lo imprescindible. Solo candidatos UDP «host» (sin STUN ni TURN: es una red local).
export function parseSdp(sdp) {
  const get = (re) => (sdp.match(re) || [])[1];
  const ufrag = get(/^a=ice-ufrag:(\S+)/m);
  const pwd = get(/^a=ice-pwd:(\S+)/m);
  const fpHex = get(/^a=fingerprint:sha-256 ([0-9A-Fa-f:]+)/m);
  if (!ufrag || !pwd || !fpHex) throw new Error('El SDP no trae usuario, clave o huella.');
  const fp = Uint8Array.from(fpHex.split(':').map((h) => parseInt(h, 16)));
  if (fp.length !== 32) throw new Error('La huella DTLS no es SHA-256.');
  const cands = [];
  const seen = new Set();
  for (const m of sdp.matchAll(/^a=candidate:\S+ \d+ udp \d+ (\S+) (\d+) typ host\b/gm)) {
    const key = `${m[1]}:${m[2]}`;
    if (seen.has(key)) continue;
    seen.add(key);
    cands.push({ addr: m[1], port: Number(m[2]) });
  }
  const setup = get(/^a=setup:(\S+)/m);
  return { ufrag, pwd, fp, cands, setup };
}

// Reconstruye un SDP de solo canal de datos que Chrome acepta. rol: 'offer' | 'answer'.
export function buildSdp({ role, ufrag, pwd, fp, cands }) {
  const fpHex = Array.from(fp, (b) => b.toString(16).toUpperCase().padStart(2, '0')).join(':');
  const lines = [
    'v=0',
    'o=- 4611731400430051336 2 IN IP4 127.0.0.1',
    's=-',
    't=0 0',
    'a=group:BUNDLE 0',
    'a=msid-semantic: WMS',
    'm=application 9 UDP/DTLS/SCTP webrtc-datachannel',
    'c=IN IP4 0.0.0.0',
    `a=ice-ufrag:${ufrag}`,
    `a=ice-pwd:${pwd}`,
    `a=fingerprint:sha-256 ${fpHex}`,
    `a=setup:${role === 'offer' ? 'actpass' : 'active'}`,
    'a=mid:0',
    'a=sctp-port:5000',
    'a=max-message-size:262144',
  ];
  cands.forEach((c, i) => lines.push(`a=candidate:${1000 + i} 1 udp ${2113937151 - i} ${c.addr} ${c.port} typ host generation 0`));
  lines.push('a=end-of-candidates');
  return `${lines.join('\r\n')}\r\n`;
}

// SDP → código de texto. rol: 'offer' | 'answer'.
export function sdpToCode(sdp, role) {
  const { ufrag, pwd, fp, cands } = parseSdp(sdp);
  if (!cands.length) throw new Error('No hay direcciones de red locales: ¿está el Wi‑Fi encendido y conectado?');
  const out = [];
  const u = enc.encode(ufrag), p = enc.encode(pwd);
  out.push((VERSION << 4) | (role === 'answer' ? 1 : 0), u.length, ...u, p.length, ...p, ...fp);
  const list = cands.slice(0, 6);
  out.push(list.length);
  for (const c of list) {
    if (isIPv4(c.addr)) out.push(0, ...c.addr.split('.').map(Number));
    else {
      const t = enc.encode(c.addr);
      out.push(1, t.length, ...t);
    }
    out.push((c.port >> 8) & 255, c.port & 255);
  }
  const bytes = Uint8Array.from(out);
  const sum = sum16(bytes, bytes.length);
  const full = new Uint8Array(bytes.length + 2);
  full.set(bytes);
  full[bytes.length] = sum >> 8;
  full[bytes.length + 1] = sum & 255;
  return CODE_PREFIX + toB64Url(full);
}

// Código de texto → { role: 'offer'|'answer', sdp }. Tolera espacios, saltos de línea y comillas de lo que se pegue.
export function codeToSdp(text) {
  let s = String(text || '').trim().replace(/\s+/g, '').replace(/^["'«]+|["'»]+$/g, '');
  const at = s.indexOf(CODE_PREFIX);
  if (at >= 0) s = s.slice(at + CODE_PREFIX.length);
  if (!/^[A-Za-z0-9_-]+$/.test(s) || s.length < 40) throw new Error('El código no es válido o está incompleto.');
  let b;
  try {
    b = fromB64Url(s);
  } catch {
    throw new Error('El código tiene caracteres que no son válidos.');
  }
  if (b.length < 40) throw new Error('El código está incompleto.');
  if (sum16(b, b.length - 2) !== ((b[b.length - 2] << 8) | b[b.length - 1])) throw new Error('El código está cortado o tiene un error: cópialo otra vez completo.');
  if (b[0] >> 4 !== VERSION) throw new Error('El código es de otra versión de RigWorld.');
  const role = b[0] & 1 ? 'answer' : 'offer';
  let i = 1;
  const take = (n) => {
    if (i + n > b.length - 2) throw new Error('El código está incompleto.');
    const r = b.subarray(i, i + n);
    i += n;
    return r;
  };
  const ufrag = dec.decode(take(take(1)[0]));
  const pwd = dec.decode(take(take(1)[0]));
  const fp = take(32).slice();
  const n = take(1)[0];
  const cands = [];
  for (let k = 0; k < n; k++) {
    const type = take(1)[0];
    let addr;
    if (type === 0) addr = Array.from(take(4)).join('.');
    else addr = dec.decode(take(take(1)[0]));
    const pr = take(2);
    cands.push({ addr, port: (pr[0] << 8) | pr[1] });
  }
  return { role, sdp: buildSdp({ role, ufrag, pwd, fp, cands }), info: { ufrag, cands } };
}
