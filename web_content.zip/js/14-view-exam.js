/* تب آزمون: ساخت آزمون، ثبت نتیجه (کل/درس/سؤال‌به‌سؤال)، تاریخچه، تحلیل پیشرفته، و آزمون تستی (حالت آزمون با تصحیح خودکار). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var ex = App.exam;
  var ch = App.chart;
  var S = function () { return App.S; };
  var TYPES = [['full', 'کنکور کامل'], ['subject', 'آزمون مبحثی'], ['quick', 'تمرین سریع']];

  App.views.exam = function () {
    if (App.ui.quizRun) return App.views.quizRunner();
    var h = App.upgradeNotice();
    h += createCard() + upcomingCard() + resultCard() + historyCard() + analyticsCard() + quizzesCard();
    return h;
  };

  // ---- ساخت آزمون (برنامه) ----
  function createCard() {
    var f = App.form('exc', { n: '', d: u.todayISO(), typ: 'full', g: S().mg || 12, s: '', cnt: 20, tl: '', neg: 0 });
    if (!u.isISO(f.d)) f.d = u.todayISO();
    var defs = ex.defaults(f.typ, f.s);
    var rows = f.typ === 'full' ? defs.sub : [{ s: f.s || D.subjects(f.g)[0].name, t: u.int(f.cnt, 1, 200, 20) }];
    if (f.typ === 'full') rows = defs.sub;
    var subjectOpts = D.subjects(+f.g).map(function (x) { return [x.name, x.name]; });
    return App.card('➕ ساخت آزمون', '<div class="grid2">' + App.field('نام آزمون', App.input('exc', 'n', { ph: 'مثلاً آزمون قلمچی', maxlength: 60 })) +
      App.field('نوع', App.select('exc', 'typ', TYPES, { rr: true })) + '</div>' +
      App.field('تاریخ', App.dateField('exc', 'd', { label: 'تاریخ آزمون' })) +
      (f.typ === 'full' ? '<div class="konkur-box mini-box">' + rows.map(function (r) { return '<div class="row0 space"><span>' + u.esc(r.s) + '</span><span class="row0"><span class="mu">سؤال</span> <b>' + u.fa(r.t) + '</b></span></div>'; }).join('') +
        '<div class="mu">پیش‌فرض کنکور نظام جدید؛ می‌توانی در «ثبت نتیجه» تعداد را تغییر دهی.</div></div>'
        : '<div class="grid2">' + App.field('پایه', App.select('exc', 'g', App.gradeOpts(), { rr: true })) + App.field('درس', App.select('exc', 's', subjectOpts, { rr: true })) + '</div>' +
        App.field('تعداد سؤال', App.input('exc', 'cnt', { t: 'int', inputmode: 'numeric', ph: f.typ === 'quick' ? '۱۰' : '۲۰' }))) +
      '<div class="grid2">' + App.field('محدودیت زمان (دقیقه، اختیاری)', App.input('exc', 'tl', { t: 'int', inputmode: 'numeric', ph: f.typ === 'full' ? '۱۴۵' : 'بدون' })) +
      '<div>' + App.check('exc', 'neg', 'نمره‌ی منفی (هر ۳ غلط = ۱ درست)') + '</div></div>' +
      App.btn('ساخت آزمون', 'exc-save', {}, 'mt'), { key: 'exam|➕ ساخت آزمون', open: true });
  }
  App.act['exc-save'] = function () {
    var f = App.form('exc', {});
    var name = String(f.n || '').trim().slice(0, 60);
    if (!name) { App.alert('نام آزمون را بنویس'); return; }
    if (!u.isISO(f.d)) { App.alert('تاریخ آزمون را انتخاب کن'); return; }
    var sub;
    if (f.typ === 'full') sub = ex.defaults('full').sub;
    else {
      var cnt = u.int(f.cnt, 1, 200, 0);
      if (!cnt) { App.alert('تعداد سؤال را وارد کن'); return; }
      sub = [{ s: f.s || D.subjects(+f.g)[0].name, t: cnt }];
    }
    var tl = u.int(f.tl, 1, 1440, 0) || (f.typ === 'full' ? D.KONKUR.riazi.minutes : 0);
    var p = ex.addPlan({ n: name, d: f.d, typ: f.typ, neg: f.neg ? 1 : 0, tl: tl, sub: sub, r: [] });
    if (!p) { App.alert('ساخت آزمون انجام نشد'); return; }
    App.resetForm('exc', { typ: f.typ, g: f.g, s: f.s, cnt: f.cnt, d: u.todayISO(), n: '', tl: '', neg: 0 });
    App.save(); App.render(); App.toast('✅ آزمون ساخته شد');
  };

  // ---- آزمون‌های پیش‌رو و پوشش محدوده ----
  function upcomingCard() {
    var U = ex.upcoming();
    var body = U.map(function (e) {
      var R = e.r || [], cv = R.map(st.covOf), T = u.sum(cv, function (x) { return x.tot; }), Dn = u.sum(cv, function (x) { return x.done; });
      var p = T ? Math.round(Dn / T * 100) : 0;
      var days = ex.days(e);
      var rangeHtml = R.map(function (r, i) {
        var c2 = cv[i];
        return '<div class="mu">' + u.esc(r.s) + ' (' + u.esc(D.GN[r.g] || '') + ') فصل ' + u.pd(r.a) + (r.b > r.a ? ' تا ' + u.pd(r.b) : '') + ' — ' + u.fa(c2.done) + '/' + u.fa(c2.tot) + ' فصل مطالعه‌شده ' + App.sm('✕', 'range-del', { key: e.id, i: i }) + '</div>';
      }).join('');
      var subs = (e.sub || []).map(function (x) { return u.esc(x.s) + ' ' + u.fa(x.t); }).join(' · ');
      return '<div class="plan-item"><div class="row0 space"><b>' + u.esc(e.n) + '</b><span class="mu">' + u.fa(days) + ' روز مانده · ' + u.esc(u.jd(e.d, true)) + '</span></div>' +
        '<div class="mu">' + (ex.TYPES[e.typ] || '') + (subs ? ' · ' + subs : '') + (e.tl ? ' · ' + u.fa(e.tl) + ' دقیقه' : '') + (e.neg ? ' · نمره‌ی منفی' : '') + (e.done ? ' · نتیجه ثبت شده ✅' : '') + '</div>' +
        rangeHtml + (T ? App.bar(p) + '<div class="mu">پوشش محدوده: ' + u.pct(p) + (p < 100 && days <= 7 ? ' ⚠️ نزدیک است' : '') + '</div>' : '<div class="mu">هنوز محدوده‌ای ثبت نشده.</div>') +
        '<div class="q-row">' + App.sm('📝 ثبت نتیجه', 'exr-prefill', { key: e.id }) + App.sm('🤖 برنامه‌ی آمادگی', 'ai-ask', { q: 'examprep', tab: 'exam', key: e.id }) + App.sm('🗑 حذف', 'plan-del', { key: e.id }) + '</div>' +
        '<details class="inner"><summary>➕ افزودن محدوده (فصل‌ها)</summary>' + rangeForm(e.id) + '</details></div>';
    }).join('');
    return App.card('📆 آزمون‌های پیش‌رو', (body || '<p class="mu">آزمونی برنامه‌ریزی نشده. از بخش «ساخت آزمون» یکی بساز.</p>'), { open: true });
  }
  function rangeForm(id) {
    var f = App.form('rg-' + id, { g: S().mg || 12, s: '', a: 1, b: 1 });
    var list = D.subjects(+f.g).map(function (x) { return [x.name, x.name]; });
    if (!f.s) f.s = list[0] ? list[0][0] : '';
    return '<div class="grid2">' + App.field('پایه', App.select('rg-' + id, 'g', App.gradeOpts(), { rr: true })) + App.field('درس', App.select('rg-' + id, 's', list)) + '</div>' +
      '<div class="grid2">' + App.field('از فصل', App.input('rg-' + id, 'a', { t: 'int', inputmode: 'numeric' })) + App.field('تا فصل', App.input('rg-' + id, 'b', { t: 'int', inputmode: 'numeric' })) + '</div>' +
      App.sm('افزودن محدوده', 'range-add', { key: id }, 'mt');
  }
  App.act['range-add'] = function (el) {
    var id = el.getAttribute('data-key');
    var f = App.form('rg-' + id, {});
    if (!ex.addRange(id, { g: f.g, s: f.s, a: u.int(f.a, 1, 30, 1), b: u.int(f.b, 1, 30, 1) })) { App.alert('درس و فصل‌ها را درست وارد کن'); return; }
    App.save(); App.render();
  };
  App.act['range-del'] = function (el) { ex.delRange(el.getAttribute('data-key'), +el.getAttribute('data-i')); App.save(); App.render(); };
  App.act['plan-del'] = function (el) {
    if (!App.confirm('این آزمون از برنامه حذف شود؟ (نتیجه‌های ثبت‌شده حذف نمی‌شوند)')) return;
    ex.delPlan(el.getAttribute('data-key')); App.save(); App.render();
  };

  // ---- ثبت نتیجه ----
  function defaultRows(typ, subj, cnt, planned) {
    if (planned && planned.sub && planned.sub.length) return planned.sub.map(function (x) { return { s: x.s, t: x.t, c: '', w: '' }; });
    if (typ === 'full') return ex.defaults('full').sub.map(function (x) { return { s: x.s, t: x.t, c: '', w: '' }; });
    return [{ s: subj, t: cnt, c: '', w: '' }];
  }
  function resultCard() {
    var f = App.form('exr', { planId: '', n: '', d: u.todayISO(), typ: 'full', neg: 0, tl: '', tu: '', z: '', grid: 0, rows: null, qg: {} });
    if (!u.isISO(f.d)) f.d = u.todayISO();
    var planned = f.planId ? S().ex2.find(function (x) { return String(x.id) === String(f.planId); }) : null;
    if (!f.rows) f.rows = defaultRows(f.typ, D.subjects(S().mg)[0] ? D.subjects(S().mg)[0].name : '', 20, planned);
    var plans = [['', 'بدون برنامه قبلی']].concat(S().ex2.map(function (x) { return [String(x.id), x.n + ' (' + u.jd(x.d) + ')']; }));
    var rowsHtml = f.rows.map(function (r, i) {
      return '<div class="row-entry"><b>' + u.esc(r.s) + '</b><div class="grid3">' +
        '<label class="mini-lbl">کل<input type="text" inputmode="numeric" data-row="' + i + '" data-k="t" value="' + u.esc(r.t) + '" aria-label="کل سؤال ' + u.esc(r.s) + '"></label>' +
        '<label class="mini-lbl">درست<input type="text" inputmode="numeric" data-row="' + i + '" data-k="c" value="' + u.esc(r.c) + '" aria-label="درست ' + u.esc(r.s) + '"></label>' +
        '<label class="mini-lbl">غلط<input type="text" inputmode="numeric" data-row="' + i + '" data-k="w" value="' + u.esc(r.w) + '" aria-label="غلط ' + u.esc(r.s) + '"></label></div></div>';
    }).join('');
    var grid = f.grid ? gridHtml(f.rows, f.qg) : '';
    return App.card('📝 ثبت نتیجه‌ی آزمون', App.field('برنامه‌ی آزمون', App.select('exr', 'planId', plans, { rr: true })) +
      App.field('نام آزمون', App.input('exr', 'n', { ph: 'مثلاً آزمون ۱۵ آبان', maxlength: 60 })) +
      '<div class="grid2">' + App.field('نوع', App.select('exr', 'typ', TYPES, { rr: true })) + App.field('زمان استفاده‌شده (دقیقه)', App.input('exr', 'tu', { t: 'int', inputmode: 'numeric', ph: 'اختیاری' })) + '</div>' +
      App.field('تاریخ', App.dateField('exr', 'd', { label: 'تاریخ آزمون' })) +
      '<div class="grid2">' + App.field('تراز (اختیاری)', App.input('exr', 'z', { t: 'int', inputmode: 'numeric', ph: 'مثلاً ۶۲۰۰' })) + App.field('محدودیت زمان', App.input('exr', 'tl', { t: 'int', inputmode: 'numeric', ph: 'اختیاری' })) + '</div>' +
      App.check('exr', 'neg', 'نمره‌ی منفی (هر ۳ غلط = ۱ درست)', { rr: true }) +
      '<div class="mt">' + rowsHtml + '</div>' +
      App.check('exr', 'grid', 'ثبت سؤال‌به‌سؤال (برای تحلیل خطا و فصل‌ها)', { rr: true }) + grid +
      '<div class="live" id="exr-live" aria-live="polite">' + liveText(f) + '</div>' +
      App.btn('ذخیره‌ی نتیجه', 'exr-save', {}, 'mt') + App.sm('پاک‌کردن فرم', 'exr-reset', {}, 'mt'), { key: 'exam|📝 ثبت نتیجه', open: true });
  }
  function gridRows(rows, qg) {
    var out = [];
    rows.forEach(function (r) {
      var t = u.int(r.t, 1, 200, 0);
      for (var i = 1; i <= t; i++) {
        var key = r.s + '|' + i;
        out.push({ s: r.s, i: i, key: key, q: qg[key] || { r: 'b', tag: '', ch: 0 } });
      }
    });
    return out;
  }
  function gridHtml(rows, qg) {
    var list = gridRows(rows, qg);
    var bySub = {};
    list.forEach(function (x) { (bySub[x.s] = bySub[x.s] || []).push(x); });
    var chOpts = function (s, cur) {
      var g = S().mg || 12, n = st.chCount(g, s), o = ['<option value="0">فصل؟</option>'];
      for (var i = 1; i <= n; i++) o.push('<option value="' + i + '"' + (+cur === i ? ' selected' : '') + '>' + u.pd(i) + '. ' + u.esc(st.chName(g, s, i)) + '</option>');
      return o.join('');
    };
    return '<div class="qgrid-wrap">' + Object.keys(bySub).map(function (s) {
      return '<details class="inner" open><summary>' + u.esc(s) + ' — ' + u.pd(bySub[s].length) + ' سؤال</summary><div class="qgrid">' + bySub[s].map(function (x) {
        var q = x.q, sym = { c: '✔', w: '✘', b: '⬜' }[q.r];
        return '<div class="qcell ' + q.r + '"><button type="button" class="qbtn" data-act="exq-cycle" data-key="' + u.esc(x.key) + '" aria-label="سؤال ' + u.pd(x.i) + ' ' + u.esc(s) + ': ' + { c: 'درست', w: 'غلط', b: 'نزده' }[q.r] + '">' + u.pd(x.i) + ' ' + sym + '</button>' +
          (q.r === 'w' ? '<select class="qsel" data-qkey="' + u.esc(x.key) + '" data-qf="tag" aria-label="علت غلط"><option value="">علت؟</option>' + Object.keys(ex.TAGS).map(function (k) { return '<option value="' + k + '"' + (q.tag === k ? ' selected' : '') + '>' + ex.TAGS[k] + '</option>'; }).join('') + '</select>' : '') +
          (q.r === 'w' ? '<select class="qsel" data-qkey="' + u.esc(x.key) + '" data-qf="ch" aria-label="فصل">' + chOpts(s, q.ch) + '</select>' : '') + '</div>';
      }).join('') + '</div></details>';
    }).join('') + '</div>';
  }
  function gradeFromInputs(f) {
    var rows = f.rows || [];
    if (f.grid) {
      var list = gridRows(rows, f.qg || {});
      var per = {};
      rows.forEach(function (r) { per[r.s] = { s: r.s, t: u.int(r.t, 1, 200, 0), c: 0, w: 0 }; });
      list.forEach(function (x) { if (x.q.r === 'c') per[x.s].c++; if (x.q.r === 'w') per[x.s].w++; });
      return Object.keys(per).map(function (k) { return per[k]; });
    }
    return rows.map(function (r) { return { s: r.s, t: u.int(r.t, 1, 200, 0), c: u.int(r.c, 0, 1000, 0), w: u.int(r.w, 0, 1000, 0) }; });
  }
  function liveText(f) {
    var rows = gradeFromInputs(f), bad = null, T = 0, C = 0, W = 0;
    rows.forEach(function (r) {
      if (!r.t) { bad = 'تعداد سؤال ' + r.s + ' را وارد کن'; return; }
      if (r.c + r.w > r.t) bad = 'درست + غلط در ' + r.s + ' بیشتر از کل سؤال‌هاست';
      T += r.t; C += r.c; W += r.w;
    });
    if (bad) return '<span class="bad">' + u.esc(bad) + '</span>';
    if (!T) return 'نتیجه را وارد کن.';
    var p = Math.round(store().pctOf(C, W, T, !!f.neg) * 10) / 10;
    return 'درصد: <b>' + u.pct(p) + '</b> · درست ' + u.fa(C) + ' · غلط ' + u.fa(W) + ' · نزده ' + u.fa(T - C - W);
  }
  function store() { return App.store; }
  App.liveExam = function () {
    var f = App.form('exr', {});
    var el = document.getElementById('exr-live');
    if (el) el.innerHTML = liveText(f);
  };
  // ورودی‌های ردیف‌ها (بدون رندر)
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (!el || !el.hasAttribute || !el.hasAttribute('data-row')) return;
    var f = App.form('exr', {});
    var i = +el.getAttribute('data-row'), k = el.getAttribute('data-k');
    if (f.rows && f.rows[i]) f.rows[i][k] = el.value;
    App.liveExam();
  }, false);
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (!el || !el.hasAttribute || !el.hasAttribute('data-qf')) return;
    var f = App.form('exr', {});
    var key = el.getAttribute('data-qkey'), field = el.getAttribute('data-qf');
    f.qg = f.qg || {};
    f.qg[key] = Object.assign({ r: 'w', tag: '', ch: 0 }, f.qg[key] || {});
    f.qg[key][field === 'ch' ? 'ch' : 'tag'] = field === 'ch' ? +el.value : el.value;
    App.liveExam();
  }, false);
  App.act['exq-cycle'] = function (el) {
    var f = App.form('exr', {});
    var key = el.getAttribute('data-key');
    f.qg = f.qg || {};
    var cur = f.qg[key] || { r: 'b', tag: '', ch: 0 };
    var next = { b: 'c', c: 'w', w: 'b' }[cur.r];
    f.qg[key] = Object.assign({}, cur, { r: next });
    if (next !== 'w') { f.qg[key].tag = ''; f.qg[key].ch = 0; }
    App.render();
  };
  App.act['exr-prefill'] = function (el) {
    var id = el.getAttribute('data-key');
    var p = S().ex2.find(function (x) { return String(x.id) === String(id); });
    if (!p) return;
    App.resetForm('exr', { planId: String(p.id), n: p.n, d: u.todayISO(), typ: p.typ || 'subject', neg: p.neg ? 1 : 0, tl: p.tl || '', tu: '', z: '', grid: 0, rows: defaultRows(p.typ, '', 0, p), qg: {} });
    App.ui.focusAct = '';
    App.render();
    var anchor = document.getElementById('exr-live');
    if (anchor && anchor.scrollIntoView) anchor.scrollIntoView({ block: 'center' });
  };
  App.act['exr-reset'] = function () { App.resetForm('exr', { planId: '', n: '', d: u.todayISO(), typ: 'full', neg: 0, tl: '', tu: '', z: '', grid: 0, rows: null, qg: {} }); App.render(); };
  App.act['exr-save'] = function () {
    var f = App.form('exr', {});
    var rows = gradeFromInputs(f);
    var T = 0;
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (!r.t) { App.alert('تعداد سؤال ' + r.s + ' را وارد کن'); return; }
      if (r.c + r.w > r.t) { App.alert('درست + غلط در ' + r.s + ' بیشتر از کل سؤال‌هاست'); return; }
      T += r.t;
    }
    if (!T) { App.alert('نتیجه را وارد کن'); return; }
    var qg = null;
    if (f.grid) {
      qg = gridRows(f.rows, f.qg || {}).map(function (x) {
        var g0 = S().mg || 12;
        return { s: x.s, i: x.i, r: x.q.r, tag: x.q.r === 'w' ? (x.q.tag || '') : '', ch: x.q.r === 'w' ? (+x.q.ch || 0) : 0, g: g0 };
      });
    }
    var rec = ex.addResult({
      n: f.n || 'آزمون', date: f.d, typ: f.typ, neg: f.neg ? 1 : 0, tl: f.tl, tu: f.tu, z: f.z,
      sub: rows, qg: qg, planId: f.planId ? +f.planId : undefined
    });
    if (!rec) { App.alert('نتیجه ذخیره نشد؛ مقادیر را بررسی کن'); return; }
    App.save();
    App.resetForm('exr', { planId: '', n: '', d: u.todayISO(), typ: 'full', neg: 0, tl: '', tu: '', z: '', grid: 0, rows: null, qg: {} });
    App.render();
    App.toast('✅ نتیجه ثبت شد: ' + u.pct(rec.p), { action: { label: '🤖 تحلیل با مشاور', fn: function () { App.ai.askExam(rec.id); } } });
  };

  // ---- تاریخچه ----
  function historyCard() {
    var list = S().exams.slice().reverse();
    if (!list.length) return App.card('📜 تاریخچه‌ی آزمون‌ها', '<p class="mu">هنوز آزمونی ثبت نشده.</p>', { open: false });
    return App.card('📜 تاریخچه‌ی آزمون‌ها', list.map(function (e) {
      var subs = ex.subPercent(e);
      var cmp = ex.compareWithPrevious(e);
      return '<div class="li exam-row"><div><b>' + u.esc(e.n || 'آزمون') + '</b> ' + (e.typ ? '<span class="pill">' + u.esc(ex.TYPES[e.typ] || '') + '</span>' : '') + '<br><span class="mu">' + u.esc(u.jd(e.d, true)) + (e.z ? ' · تراز ' + u.fa(e.z) : '') + ' · ✔' + u.fa(e.c) + ' ✘' + u.fa(e.w) + ' ⬜' + u.fa(e.t - e.c - e.w) + (e.tu ? ' · ' + u.fa(e.tu) + ' دقیقه' : '') + '</span>' +
        (subs.length > 1 ? '<div class="mu">' + subs.map(function (x) { return u.esc(x.s) + ': ' + u.pct(x.p); }).join(' · ') + '</div>' : '') +
        (cmp ? '<div class="mu">نسبت به آزمون قبلی: ' + (cmp.diff >= 0 ? '▲ ' : '▼ ') + u.fa(Math.abs(cmp.diff)) + ' واحد</div>' : '') + '</div>' +
        '<div class="row0"><b class="pct-s' + (e.p < 0 ? ' bad' : '') + '">' + u.pct(e.p) + '</b></div>' +
        '<div class="q-row">' + App.sm('🤖 تحلیل با مشاور', 'exam-ai', { key: e.id }) + App.sm('🗑 حذف', 'exam-del', { key: e.id }) + '</div></div>';
    }).join(''), { open: false });
  }
  App.act['exam-del'] = function (el) {
    if (!App.confirm('این نتیجه‌ی آزمون حذف شود؟')) return;
    var rec = ex.delResult(el.getAttribute('data-key'));
    if (rec && rec.id) { var p = S().ex2.find(function (x) { return x.done === rec.id; }); if (p) delete p.done; }
    App.save(); App.render();
    if (rec) App.toast('نتیجه حذف شد', { action: { label: '↩️ برگردان', fn: function () { S().exams.push(rec); App.save(); App.render(); } }, ms: 6000 });
  };
  App.act['exam-ai'] = function (el) { App.ai.askExam(el.getAttribute('data-key')); };

  // ---- تحلیل پیشرفته ----
  function analyticsCard() {
    if (S().exams.length < 1) return App.card('📈 تحلیل آزمون‌ها', '<p class="mu">بعد از ثبت اولین آزمون، تحلیل‌ها اینجا می‌آید.</p>', { open: false });
    var tr = ex.trend().slice(-10);
    var line = ch.line(tr.map(function (p) { return { label: u.jd(p.d) + ' ' + p.n, y: p.p }; }));
    var hm = ex.heatmap(8);
    var er = ex.errors();
    var tagKeys = Object.keys(ex.TAGS);
    var maxTag = Math.max.apply(null, [1].concat(tagKeys.map(function (k) { return er.tags[k]; })));
    var errBars = tagKeys.map(function (k) {
      return '<div class="li tagbar"><span>' + ex.TAGS[k] + '</span><div class="bar"><i style="width:' + (er.tags[k] / maxTag * 100) + '%"></i></div><b>' + u.fa(er.tags[k]) + '</b></div>';
    }).join('') + (er.tags.untagged ? '<div class="mu">' + u.fa(er.tags.untagged) + ' غلط بدون علت ثبت‌شده</div>' : '') + (er.wrongTotal ? '' : '<p class="mu">برای این بخش، ثبت سؤال‌به‌سؤال لازم است.</p>');
    var avgs = ex.subjectAverages();
    var best = avgs.slice(0, 2), worst = avgs.slice(-2).reverse();
    var wc = ex.weakChapters();
    var auto = st.autoWeak().slice(0, 3);
    var pr = ex.predict();
    var cmp = S().exams.length > 1 ? ex.compareWithPrevious(S().exams[S().exams.length - 1]) : null;
    var tm = ex.timeStats();
    return App.card('📈 تحلیل آزمون‌ها', '<div class="predict"><div class="mu">برآورد تقریبی درصد کنکور</div><div class="big accent">' + (pr.value != null ? u.pct(pr.value) : '—') + '</div><div class="mu">' + u.esc(pr.note) + ' (برآورد است، قطعی نیست)</div></div>' +
      (cmp ? '<div class="notice-inline"><b>مقایسه با آزمون قبلی</b><div>' + (cmp.diff >= 0 ? '▲ ' : '▼ ') + u.fa(Math.abs(cmp.diff)) + ' واحد نسبت به «' + u.esc(cmp.prev.n || 'آزمون قبلی') + '»</div>' + cmp.subs.map(function (x) { return '<div class="mu">' + u.esc(x.s) + ': ' + (x.diff >= 0 ? '▲ ' : '▼ ') + u.fa(Math.abs(x.diff)) + '</div>'; }).join('') + '</div>' : '') +
      '<h3 class="sub-h">روند درصد</h3>' + line +
      '<h3 class="sub-h">نقشه‌ی حرارتی درس‌ها</h3>' + ch.heat(hm.rows, hm.cols) +
      '<h3 class="sub-h">بهترین و ضعیف‌ترین درس‌ها</h3>' + (avgs.length ? '<div class="mu">بهترین: ' + best.map(function (x) { return u.esc(x.s) + ' (' + u.pct(x.p) + ')'; }).join('، ') + '</div><div class="mu">ضعیف‌ترین: ' + worst.map(function (x) { return u.esc(x.s) + ' (' + u.pct(x.p) + ')'; }).join('، ') + '</div>' : '<div class="mu">برای این بخش، نتیجه‌ی تفکیکی درس لازم است.</div>') +
      '<h3 class="sub-h">فصل‌های پرخطا</h3>' + (wc.length ? wc.map(function (x) { return '<div class="mu">' + u.esc(x.s) + ' — ' + u.esc(st.chName(S().mg, x.s, x.c)) + ': ' + u.fa(x.wrong) + ' غلط</div>'; }).join('') : '<div class="mu">فصل پرخطا از سؤال‌به‌سؤال هنوز نیست.</div>') +
      (auto.length ? '<div class="mu">از تست‌های روزانه: ' + auto.map(function (o) { return u.esc(o.s) + ' ' + u.esc(st.chName(o.g, o.s, o.c)) + ' (' + u.pct(o.p) + ')'; }).join('، ') + '</div>' : '') +
      '<h3 class="sub-h">علت خطاها</h3>' + errBars +
      '<h3 class="sub-h">زمان</h3><div class="mu">' + (tm.count ? 'میانگین ' + u.fa(tm.perQuestion) + ' دقیقه برای هر سؤال · ' + u.fa(tm.overLimit) + ' آزمون از زمان مجاز گذشت' : 'برای تحلیل زمان، زمان استفاده‌شده را در ثبت نتیجه وارد کن.') + '</div>' +
      '<div class="q-row mt">' + App.sm('🤖 تحلیل کلی آزمون‌ها با مشاور', 'ai-ask', { q: 'examsall', tab: 'exam' }) + '</div>', { open: false });
  }

  // ---- آزمون‌های تستی (کلید پاسخ یا ساخته‌شده با مشاور) ----
  function quizzesCard() {
    var Q = S().quizzes.slice().reverse();
    var f = App.form('qz', { title: '', g: S().mg || 12, s: '', ch: 0, key: '', tl: '' });
    var subs = D.subjects(+f.g).map(function (x) { return [x.name, x.name]; });
    if (!f.s && subs[0]) f.s = subs[0][0];
    return App.card('🧪 آزمون تستی (تصحیح خودکار)', (Q.length ? Q.map(function (q) {
      var last = q.attempts && q.attempts.length ? q.attempts[q.attempts.length - 1] : null;
      return '<div class="li"><div><b>' + u.esc(q.title) + '</b><br><span class="mu">' + u.fa(q.questions.length) + ' سؤال · ' + (q.src === 'ai' ? 'ساخته‌شده با مشاور' : 'کلید دستی') + (last ? ' · آخرین نتیجه ' + u.pct(last.p) : '') + '</span></div>' +
        '<div class="row0">' + App.sm('▶ شروع', 'quiz-start', { key: q.id }) + App.sm('🗑', 'quiz-del', { key: q.id }) + '</div></div>';
    }).join('') : '<p class="mu">هنوز آزمون تستی نداری. کلید پاسخ یک آزمون کاغذی را وارد کن، یا از مشاور بخواه سؤال تستی بسازد.</p>') +
      '<details class="inner" open><summary>➕ کلید پاسخ دستی</summary>' + App.field('عنوان', App.input('qz', 'title', { ph: 'مثلاً تست گسسته فصل ۲', maxlength: 80 })) +
      '<div class="grid2">' + App.field('پایه', App.select('qz', 'g', App.gradeOpts(), { rr: true })) + App.field('درس', App.select('qz', 's', subs)) + '</div>' +
      App.field('فصل (اختیاری)', App.chapSelect('qz', 'g', 's', 'ch')) +
      App.field('کلید پاسخ (مثلاً ABCDBA…)', App.input('qz', 'key', { ph: 'ABCD…', maxlength: 200 })) +
      App.field('محدودیت زمان (دقیقه، اختیاری)', App.input('qz', 'tl', { t: 'int', inputmode: 'numeric' })) +
      App.btn('ساخت آزمون تستی', 'quiz-create', {}, 'mt') + '</details>' +
      App.sm('🤖 از مشاور سؤال تستی بساز', 'ai-ask', { q: 'quiz', tab: 'exam' }, 'mt'), { open: false });
  }
  App.act['quiz-create'] = function () {
    var f = App.form('qz', {});
    var key = String(f.key || '').toUpperCase().replace(/[^ABCD]/g, '');
    if (!key.length) { App.alert('کلید پاسخ را با حروف A تا D وارد کن'); return; }
    if (key.length > 60) { App.alert('حداکثر ۶۰ سؤال'); return; }
    var q = ex.quizAdd({ title: String(f.title || 'آزمون تستی').trim() || 'آزمون تستی', g: +f.g, s: f.s, ch: +f.ch || 0, src: 'manual', tl: u.int(f.tl, 0, 1440, 0), questions: key.split('').map(function (a) { return { a: a }; }) });
    if (!q) { App.alert('ساخت آزمون انجام نشد'); return; }
    App.resetForm('qz', { title: '', g: f.g, s: f.s, ch: 0, key: '', tl: '' });
    App.save(); App.render(); App.toast('✅ آزمون تستی ساخته شد');
  };
  App.act['quiz-del'] = function (el) {
    if (!App.confirm('این آزمون تستی و نتیجه‌هایش حذف شود؟')) return;
    ex.quizDel(el.getAttribute('data-key')); App.save(); App.render();
  };
  App.act['quiz-start'] = function (el) {
    var q = S().quizzes.find(function (x) { return String(x.id) === String(el.getAttribute('data-key')); });
    if (!q) return;
    App.quiz.start(q.id);
  };

  // ---- اجرای آزمون تستی ----
  App.quiz = {
    timer: null,
    start: function (id) {
      var q = S().quizzes.find(function (x) { return String(x.id) === String(id); });
      if (!q) return;
      App.ui.quizRun = { id: q.id, answers: q.questions.map(function () { return ''; }), flags: {}, idx: 0, started: Date.now(), limit: q.tl ? q.tl * 60 : 0, result: null, reviewIdx: 0 };
      App.ui.tab = 'exam';
      App.render();
      App.quiz.arm();
      window.scrollTo(0, 0);
    },
    arm: function () {
      clearInterval(App.quiz.timer);
      App.quiz.timer = setInterval(function () {
        var r = App.ui.quizRun;
        if (!r || r.result) { clearInterval(App.quiz.timer); return; }
        var left = App.quiz.left();
        var el = document.getElementById('qtime');
        if (el) el.textContent = App.quiz.clock(left);
        if (r.limit && left <= 0) App.quiz.finish(true);
      }, 1000);
    },
    left: function () {
      var r = App.ui.quizRun;
      if (!r) return 0;
      var used = Math.floor((Date.now() - r.started) / 1000);
      return r.limit ? Math.max(0, r.limit - used) : used;
    },
    clock: function (s) {
      var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
      return u.pd([h, m, x].map(function (n) { return u.p2(n); }).join(':'));
    },
    finish: function (auto) {
      var r = App.ui.quizRun;
      if (!r || r.result) return;
      var sec = Math.floor((Date.now() - r.started) / 1000);
      var out = ex.quizAttempt(r.id, r.answers, sec);
      r.result = out ? out.grade : { c: 0, w: 0, b: r.answers.length, p: 0, detail: [] };
      if (out) App.save();
      clearInterval(App.quiz.timer);
      App.render();
      if (auto) App.toast('⏰ زمان تمام شد؛ آزمون تصحیح شد');
    },
    exit: function () {
      clearInterval(App.quiz.timer);
      App.ui.quizRun = null;
      App.render();
    }
  };
  App.act['quiz-exit'] = function () { App.quiz.exit(); };
  App.act['quiz-pick'] = function (el) {
    var r = App.ui.quizRun;
    if (!r || r.result) return;
    r.answers[r.idx] = el.getAttribute('data-v');
    App.render();
  };
  App.act['quiz-go'] = function (el) {
    var r = App.ui.quizRun;
    if (!r) return;
    var v = el.getAttribute('data-v');
    if (v === 'prev') r.idx = Math.max(0, r.idx - 1);
    else if (v === 'next') r.idx = Math.min(r.answers.length - 1, r.idx + 1);
    else r.idx = Math.max(0, Math.min(r.answers.length - 1, +v));
    App.render();
  };
  App.act['quiz-flag'] = function () { var r = App.ui.quizRun; if (!r) return; r.flags[r.idx] = !r.flags[r.idx]; App.render(); };
  App.act['quiz-clear'] = function () { var r = App.ui.quizRun; if (!r || r.result) return; r.answers[r.idx] = ''; App.render(); };
  App.act['quiz-submit'] = function () {
    var r = App.ui.quizRun;
    if (!r) return;
    var left = r.answers.filter(function (a) { return !a; }).length;
    if (left && !App.confirm('هنوز ' + u.fa(left) + ' سؤال بی‌پاسخ است. تصحیح شود؟')) return;
    App.quiz.finish(false);
  };
  App.act['quiz-review'] = function (el) { var r = App.ui.quizRun; if (r) { r.reviewIdx = +el.getAttribute('data-v') || 0; App.render(); } };
  App.act['quiz-explain'] = function (el) {
    var r = App.ui.quizRun, i = +el.getAttribute('data-v');
    if (!r) return;
    if (App.ai && App.ai.explainQuestion) App.ai.explainQuestion(r.id, i);
  };
  App.act['quiz-save-result'] = function () {
    var r = App.ui.quizRun;
    if (!r || !r.result) return;
    var q = S().quizzes.find(function (x) { return String(x.id) === String(r.id); });
    if (!q) return;
    var rec = ex.addResult({ n: q.title + ' (تستی)', s: q.s, date: u.todayISO(), t: q.questions.length, c: r.result.c, w: r.result.w, tu: Math.round(Math.floor((Date.now() - r.started) / 60000)) || undefined, typ: 'quick' });
    if (rec) { App.save(); App.toast('✅ نتیجه در آزمون‌ها ثبت شد'); }
    else App.alert('ثبت انجام نشد');
  };

  App.views.quizRunner = function () {
    var r = App.ui.quizRun;
    var q = r && S().quizzes.find(function (x) { return String(x.id) === String(r.id); });
    if (!q) { App.ui.quizRun = null; return App.views.exam(); }
    var n = q.questions.length;
    if (r.result) return resultView(q, r);
    var cur = q.questions[r.idx];
    var ans = r.answers[r.idx];
    var navi = q.questions.map(function (x, i) {
      var cls = (i === r.idx ? 'cur ' : '') + (r.answers[i] ? 'ans ' : '') + (r.flags[i] ? 'flag' : '');
      return '<button type="button" class="qnav ' + cls + '" data-act="quiz-go" data-v="' + i + '" aria-label="سؤال ' + u.pd(i + 1) + (r.flags[i] ? ' (پرچم‌دار)' : '') + (r.answers[i] ? ' (پاسخ داده)' : '') + '" ' + (i === r.idx ? 'aria-current="step"' : '') + '>' + u.pd(i + 1) + (r.flags[i] ? ' ⚑' : '') + '</button>';
    }).join('');
    var opts = ['A', 'B', 'C', 'D'].map(function (L, k) {
      var txt = cur.o ? cur.o[k] : '';
      return '<button type="button" class="opt' + (ans === L ? ' on' : '') + '" data-act="quiz-pick" data-v="' + L + '" aria-pressed="' + (ans === L) + '"><b>' + L + '</b>' + (txt ? ' ' + u.esc(txt) : '') + '</button>';
    }).join('');
    var answered = r.answers.filter(function (a) { return a; }).length;
    return '<div class="quiz-head card"><div class="row0 space"><b>' + u.esc(q.title) + '</b><span id="qtime" class="qclock" aria-live="off">' + App.quiz.clock(App.quiz.left()) + '</span></div>' +
      '<div class="mu">' + u.fa(answered) + ' از ' + u.fa(n) + ' پاسخ داده شده' + (r.limit ? ' · زمان مجاز ' + u.fa(q.tl) + ' دقیقه' : ' · بدون محدودیت زمان') + '</div>' + App.bar(answered / n * 100) +
      '<div class="qnav-grid" role="group" aria-label="ناوبری سؤال‌ها">' + navi + '</div></div>' +
      '<div class="card qcard"><h2>سؤال ' + u.pd(r.idx + 1) + ' از ' + u.pd(n) + '</h2>' + (cur.q ? '<p class="qtext">' + u.esc(cur.q) + '</p>' : '<p class="mu">پاسخ را از روی برگه‌ی خودت انتخاب کن.</p>') +
      '<div class="opts">' + opts + '</div><div class="q-row mt">' + App.sm('⚑ پرچم', 'quiz-flag') + App.sm('پاک‌کردن پاسخ', 'quiz-clear') + '</div>' +
      '<div class="grid2 mt"><button type="button" class="btn muted" data-act="quiz-go" data-v="prev"' + (r.idx === 0 ? ' disabled' : '') + '>◀ قبلی</button><button type="button" class="btn" data-act="quiz-go" data-v="next"' + (r.idx === n - 1 ? ' disabled' : '') + '>بعدی ▶</button></div>' +
      '<div class="grid2 mt"><button type="button" class="btn accent" data-act="quiz-submit">✔ پایان و تصحیح</button><button type="button" class="btn muted" data-act="quiz-exit">خروج بدون تصحیح</button></div></div>';
  };
  function resultView(q, r) {
    var g = r.result, n = q.questions.length;
    var rev = q.questions.map(function (x, i) {
      var a = r.answers[i] || '—', d = g.detail[i];
      var mark = d === 'c' ? '✅' : d === 'w' ? '❌' : '⬜';
      return '<div class="li rev-row"><span>' + mark + ' سؤال ' + u.pd(i + 1) + ' — شما: <b>' + a + '</b> · درست: <b>' + x.a + '</b>' + (x.exp ? '<div class="mu">' + u.esc(x.exp) + '</div>' : '') + '</span>' +
        (App.ai ? App.sm('💡 توضیح', 'quiz-explain', { v: i }) : '') + '</div>';
    }).join('');
    var idx = r.reviewIdx || 0;
    return '<div class="card"><h2>نتیجه‌ی ' + u.esc(q.title) + '</h2><div class="big accent">' + u.pct(g.p) + '</div><div class="mu">درست ' + u.fa(g.c) + ' · غلط ' + u.fa(g.w) + ' · نزده ' + u.fa(g.b) + ' از ' + u.fa(n) + '</div>' +
      '<div class="q-row mt">' + App.sm('ثبت در آزمون‌ها', 'quiz-save-result') + App.sm('شروع دوباره', 'quiz-start', { key: q.id }) + App.sm('بستن', 'quiz-exit') + '</div></div>' +
      '<div class="card"><h2>مرور پاسخ‌ها</h2>' + rev + '</div>' + (idx ? '' : '');
  }
})();
