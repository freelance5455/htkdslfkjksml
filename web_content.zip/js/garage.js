/* ============================================================
   garage.js — 3D showroom with rotating car preview
   ============================================================ */
'use strict';

class Garage {
  constructor(envMap) {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x04060b);
    this.scene.fog = new THREE.Fog(0x04060b, 20, 55);
    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 120);
    this.camera.position.set(0, 1.9, 7.6);
    this.camera.lookAt(0, 0.8, 0);
    this.angle = 0.6;
    this._t = 0;
    this._buildRoom(envMap);
    this.car = new PlayerCar(this.scene, envMap);
    this.car.group.position.set(0, 0, 0);
    this.car.group.rotation.y = this.angle;
    this.car.setSpec(CARS[0]);
    this.car.setPaint(0);
  }

  _buildRoom(envMap) {
    // floor
    const grid = AD.canvasTexture(128, 128, (g) => {
      g.fillStyle = '#0a0d14'; g.fillRect(0, 0, 128, 128);
      g.strokeStyle = 'rgba(70,160,220,0.20)'; g.lineWidth = 1;
      for (let i = 0; i <= 128; i += 16) {
        g.beginPath(); g.moveTo(i, 0); g.lineTo(i, 128); g.stroke();
        g.beginPath(); g.moveTo(0, i); g.lineTo(128, i); g.stroke();
      }
    }, 14, 14);
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(60, 60),
      new THREE.MeshStandardMaterial({
        map: grid, color: 0x1a2230, roughness: 0.28, metalness: 0.85,
        envMap, envMapIntensity: 0.9,
      })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.02;
    this.scene.add(floor);

    // platform
    const plat = new THREE.Mesh(
      new THREE.CylinderGeometry(4.4, 4.6, 0.18, 64),
      new THREE.MeshStandardMaterial({
        color: 0x10151f, metalness: 0.9, roughness: 0.18,
        envMap, envMapIntensity: 1.1,
      })
    );
    plat.position.y = -0.07;
    this.scene.add(plat);

    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(4.42, 0.035, 8, 96),
      new THREE.MeshBasicMaterial({ color: 0x2ee6ff, toneMapped: false })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.03;
    this.scene.add(ring);
    this.ring = ring;

    // backdrop cylinder
    const wall = new THREE.Mesh(
      new THREE.CylinderGeometry(26, 26, 16, 48, 1, true),
      new THREE.MeshStandardMaterial({
        color: 0x070b12, roughness: 0.9, metalness: 0.2, side: THREE.BackSide,
      })
    );
    wall.position.y = 8;
    this.scene.add(wall);

    // neon pillars
    const neonCols = [0x2ee6ff, 0xff2e88, 0xffc400, 0x8a3cff];
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2;
      const col = neonCols[i % neonCols.length];
      const bar = new THREE.Mesh(
        new THREE.BoxGeometry(0.08, 6 + (i % 3) * 2.4, 0.08),
        new THREE.MeshBasicMaterial({ color: col, toneMapped: false })
      );
      bar.position.set(Math.cos(a) * 16, 4, Math.sin(a) * 16);
      this.scene.add(bar);
    }

    // lights
    this.scene.add(new THREE.HemisphereLight(0x5f7fff, 0x101018, 0.55));
    this.scene.add(new THREE.AmbientLight(0x8090c0, 0.25));
    const key = new THREE.SpotLight(0xffffff, 2.4, 30, 0.65, 0.4, 1.4);
    key.position.set(3, 9, 5);
    key.target.position.set(0, 0.7, 0);
    this.scene.add(key, key.target);
    const rim = new THREE.SpotLight(0x2ee6ff, 2.6, 30, 0.7, 0.5, 1.3);
    rim.position.set(-6, 5, -4);
    rim.target.position.set(0, 0.8, 0);
    this.scene.add(rim, rim.target);
    const warm = new THREE.PointLight(0xff7a1a, 1.4, 22, 2);
    warm.position.set(4, 2.2, -3);
    this.scene.add(warm);
    this._key = key;
    this._rim = rim;
  }

  showCar(spec, paintIndex) {
    this.car.setSpec(spec);
    this.car.setPaint(paintIndex);
    this.car.group.position.set(0, 0, 0);
    this.angle = 0.65;
    this.car.group.rotation.y = this.angle;
    this.car.chassis.rotation.set(0, 0, 0);
    this.car.chassis.position.y = 0;
    this.car.damage = 0;
    this.car.fuel = 1;
  }

  setPaint(index) { this.car.setPaint(index); }

  update(dt) {
    this._t += dt;
    this.angle += dt * 0.22;
    this.car.group.rotation.y = this.angle;
    // slow wheel roll
    for (const w of this.car.wheels) {
      w.userData.spin.rotation.x -= dt * 0.9;
    }
    // gentle camera bob + light pulse
    this.camera.position.y = 1.9 + Math.sin(this._t * 0.8) * 0.035;
    this.camera.lookAt(0, 0.78, 0);
    this._key.intensity = 2.2 + Math.sin(this._t * 1.6) * 0.25;
    this._rim.intensity = 2.4 + Math.cos(this._t * 1.2) * 0.35;
    this.ring.material.color.setHSL((this._t * 0.04) % 1, 0.9, 0.6);
  }

  resize(w, h) {
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
}
