/* =============================================================
   LAMPION POS · js/pages/category.js  (pengganti category.php)
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  var rows = [];

  function load() {
    return LP.api('api/categories.php', { method: 'GET' }).then(function (res) {
      rows = res.categories || [];
      render();
    }).catch(function (e) {
      LP.toast('Gagal memuat kategori: ' + e.message, 'err', 5000);
    });
  }

  function render() {
    var tb = $('tb-cat');
    if (!tb) { return; }
    if (rows.length === 0) {
      tb.innerHTML = LPUI.emptyRow(5, 'Belum ada kategori', 'Tambahkan kategori pertama.');
      return;
    }
    tb.innerHTML = rows.map(function (c) {
      return '<tr>' +
        '<td><b>' + esc(c.name) + '</b></td>' +
        '<td class="num">' + Number(c.sort_order || 0) + '</td>' +
        '<td class="num">' + Number(c.item_count || 0) + '</td>' +
        '<td>' + LPUI.useBadge(Number(c.is_active) === 1) + '</td>' +
        '<td class="nowrap">' +
        '<button class="btn btn-sm" data-edit="' + Number(c.id) + '">Ubah</button> ' +
        '<button class="btn btn-sm btn-danger" data-del="' + Number(c.id) + '">Hapus</button>' +
        '</td></tr>';
    }).join('');
  }

  function openForm(cat) {
    var isEdit = !!cat;
    var c = cat || { id: 0, name: '', sort_order: 0, is_active: 1 };

    var md = LPUI.modal({
      title: isEdit ? 'Ubah Kategori' : 'Kategori Baru',
      body: '<div class="field"><label>Nama kategori *</label>' +
        '<input type="text" id="c-name" value="' + esc(c.name) + '"></div>' +
        '<div class="grid2">' +
        '<div class="field"><label>Urutan</label>' +
        '<input type="number" id="c-sort" value="' + Number(c.sort_order || 0) + '"></div>' +
        '<div class="field"><label>Status</label>' +
        '<div class="check"><input type="checkbox" id="c-active"' +
        (Number(c.is_active) === 1 ? ' checked' : '') + '> <span>Aktif</span></div></div>' +
        '</div>',
      foot: '<button class="btn" type="button" data-x>Batal</button>' +
        '<button class="btn btn-primary" type="button" id="c-save">Simpan</button>'
    });

    md.el.querySelector('#c-save').addEventListener('click', function () {
      var name = md.el.querySelector('#c-name').value.trim();
      if (name === '') { return LP.toast('Nama kategori wajib.', 'warn'); }
      return LP.api('api/categories.php', {
        method: 'POST',
        body: JSON.stringify({
          action: 'save',
          id: Number(c.id) || 0,
          name: name,
          sort_order: md.el.querySelector('#c-sort').value,
          is_active: md.el.querySelector('#c-active').checked ? 1 : 0
        })
      }).then(function () {
        md.close();
        LP.toast('Kategori disimpan.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 5000); });
    });
  }

  function remove(id) {
    LP.confirm('Hapus kategori ini?').then(function (ok) {
      if (!ok) { return null; }
      return LP.api('api/categories.php', {
        method: 'POST', body: JSON.stringify({ action: 'delete', id: Number(id) })
      }).then(function () {
        LP.toast('Kategori dihapus.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 6000); });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('category.view', function () {
      LPUI.mountChrome('category.html');

      $('btn-new').addEventListener('click', function () { openForm(null); });
      $('tb-cat').addEventListener('click', function (e) {
        var ed = e.target.closest('[data-edit]');
        var dl = e.target.closest('[data-del]');
        if (ed) {
          var id = Number(ed.dataset.edit);
          var c = rows.filter(function (x) { return Number(x.id) === id; })[0];
          if (c) { openForm(c); }
        } else if (dl) {
          remove(Number(dl.dataset.del));
        }
      });

      load();
    });
  });
})();
