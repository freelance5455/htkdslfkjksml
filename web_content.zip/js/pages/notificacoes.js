(function(){
  const sessao = Auth.exigirLogin();
  if(!sessao) return;

  const ICONES = {
    interesse_recebido: 'user-plus', interesse_aceito: 'check-circle', interesse_recusado: 'x-circle',
    alteracao: 'pencil', conclusao: 'flag', default: 'bell',
  };

  function render(){
    const lista = NotificationsService.listarDoUsuario(sessao.id);
    const cont = document.getElementById('listaNotificacoes');
    if(lista.length === 0){
      cont.innerHTML = `<div class="empty-state card-soft"><i data-lucide="bell-off"></i><p>Nenhuma notificação por aqui ainda.</p></div>`;
      refreshIcons();
      return;
    }
    cont.innerHTML = lista.map(n => `
      <div class="card-soft p-4 flex gap-3 ${n.lida ? 'opacity-60' : ''}" data-id="${n.id}">
        <div class="icon-circle" style="width:36px;height:36px;min-width:36px;background:#EAF1FD;color:var(--azul)">
          <i data-lucide="${ICONES[n.tipo] || ICONES.default}" style="width:17px;height:17px"></i>
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-semibold text-[13px]">${n.titulo}</p>
          <p class="text-[12px] text-muted">${n.mensagem}</p>
          <p class="text-[10.5px] text-muted mt-1">${new Date(n.created_at).toLocaleString('pt-BR')}</p>
        </div>
        ${!n.lida ? '<span style="width:8px;height:8px;border-radius:50%;background:var(--azul);flex-shrink:0;margin-top:4px"></span>' : ''}
      </div>
    `).join('');

    cont.querySelectorAll('[data-id]').forEach(el => {
      el.addEventListener('click', () => {
        NotificationsService.marcarLida(Number(el.dataset.id));
        render();
      });
    });
    refreshIcons();
  }

  render();
})();
