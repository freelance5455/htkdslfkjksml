/* =============================================================
   LAMPION POS · js/pages/display.js
   Pengganti custdisplay.php + api/display.php (sisi polling)
   -------------------------------------------------------------
   Versi PHP melakukan polling HTTP tiap ~1,2 detik ke server.
   Karena sekarang semuanya di satu perangkat tanpa server, layar
   pelanggan cukup mendengarkan pesan lewat BroadcastChannel dari
   halaman Kasir. Payload juga disimpan ke tabel customer_display
   supaya isi terakhir tetap tampil setelah aplikasi dibuka ulang.
   ============================================================= */
(function () {
  'use strict';

  var DB = window.LPDB;
  var PHP = window.LPHP;
  function $(id) { return document.getElementById(id); }
  function esc(s) { return PHP.esc(s); }
  function money(n) { return PHP.money(n); }

  var KEY = '';
  var STORE = { name: 'Lampion Resto', footer: '' };

  function setStatus(t) { if ($('cd-status')) { $('cd-status').textContent = t; } }
  function setFoot(t) { if ($('cd-foot')) { $('cd-foot').textContent = t || ''; } }

  /* ---------- render ---------- */
  function renderIdle() {
    setStatus('Menunggu pesanan…');
    $('cd-body').innerHTML =
      '<div class="cd-idle">' +
      '<div class="big">Selamat Datang</div>' +
      '<div class="sub">Silakan lihat menu dan pesan di kasir</div>' +
      '</div>';
    setFoot(STORE.footer);
  }

  function renderOrder(p) {
    setStatus('Pesanan sedang diproses');

    var items = (p.items || []).map(function (it) {
      return '<div class="cd-item">' +
        '<span class="nm">' + esc(it.name) + '</span>' +
        '<span class="qt">' + it.qty + ' × ' + money(it.price) + '</span>' +
        '<span class="tt">' + money(it.total) + '</span>' +
        '</div>';
    }).join('');

    if (items === '') {
      items = '<div class="cd-item"><span class="nm text-muted">Belum ada item</span></div>';
    }

    $('cd-body').innerHTML =
      '<div class="cd-order">' +
      '<div class="cd-meta">' +
      (p.type_label ? '<span class="cd-chip">' + esc(p.type_label) + '</span>' : '') +
      (p.customer ? '<span class="cd-chip">' + esc(p.customer) + '</span>' : '') +
      '</div>' +
      '<div class="cd-items">' + items + '</div>' +
      '<div class="cd-totals">' +
      '<div class="cd-trow"><span>Subtotal</span><span>' + money(p.subtotal) + '</span></div>' +
      (Number(p.discount) > 0
        ? '<div class="cd-trow"><span>Diskon</span><span>-' + money(p.discount) + '</span></div>'
        : '') +
      '<div class="cd-trow"><span>Pajak</span><span>' + money(p.tax) + '</span></div>' +
      '<div class="cd-trow grand"><span>TOTAL</span><span>' + money(p.total) + '</span></div>' +
      '</div></div>';
    setFoot(STORE.footer);
  }

  function renderPaid(p) {
    setStatus('Pembayaran berhasil — terima kasih!');
    $('cd-body').innerHTML =
      '<div class="cd-paid">' +
      '<div class="ok">&#10003;</div>' +
      '<div class="t1">Terima Kasih</div>' +
      (p.order_number ? '<div class="t2">Nota ' + esc(p.order_number) + '</div>' : '') +
      (Number(p.paid_total) > 0
        ? '<div class="amt">' + money(p.paid_total) + '</div>' : '') +
      '<div class="t2">Pesanan Anda sedang disiapkan</div>' +
      '</div>';
    setFoot(STORE.footer);
  }

  function renderError(msg) {
    setStatus('Layar belum terhubung');
    $('cd-body').innerHTML =
      '<div class="cd-err"><div style="font-size:34px;font-weight:800">' + esc(msg) + '</div>' +
      '<div>Buka halaman Kasir lalu pilih <b>Layar Pelanggan</b> untuk menautkan layar ini.</div>' +
      '</div>';
    setFoot('');
  }

  /* ---------- terapkan pesan dari Kasir ---------- */
  function apply(msg) {
    if (!msg || msg.key !== KEY) { return; }

    if (msg.action === 'reset') { return renderIdle(); }
    if (msg.action === 'paid') {
      return renderPaid({ order_number: msg.order_number, paid_total: msg.total });
    }
    if (msg.action === 'set' && msg.payload) { return renderOrder(msg.payload); }
  }

  /* ---------- jam ---------- */
  function tick() {
    var el = $('cd-clock');
    if (el) {
      el.textContent = new Date().toLocaleTimeString('id-ID', {
        hour: '2-digit', minute: '2-digit'
      });
    }
  }

  /* ---------- pemulihan isi terakhir dari database ---------- */
  function restoreFromDb() {
    return DB.db.customer_display.where('dkey').equals(KEY).first().then(function (row) {
      if (!row) { return renderError('Key layar tidak valid'); }
      if (row.payload === null || row.payload === undefined || row.payload === '') {
        return renderIdle();
      }
      var p = null;
      try { p = JSON.parse(String(row.payload)); } catch (e) { p = null; }
      if (!p) { return renderIdle(); }
      if (String(row.status) === 'paid') { return renderPaid(p); }
      renderOrder(p);
    }).catch(function () { renderIdle(); });
  }

  /* ---------- init ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    var params = new URLSearchParams(location.search);
    KEY = String(params.get('k') || '').trim();

    $('cd-store').textContent = STORE.name;
    tick();
    setInterval(tick, 1000);

    DB.getSetting('store_name', 'Lampion Resto').then(function (n) {
      STORE.name = String(n || 'Lampion Resto');
      $('cd-store').textContent = STORE.name;
    });
    DB.getSetting('store_footer', '').then(function (f) { STORE.footer = String(f || ''); });

    if (KEY === '') {
      return renderError('Key layar belum diisi');
    }

    /* dengarkan siaran dari halaman Kasir */
    if (window.BroadcastChannel) {
      var ch = new BroadcastChannel('lamp_display');
      ch.onmessage = function (e) { apply(e.data); };
    }

    restoreFromDb();
  });
})();
