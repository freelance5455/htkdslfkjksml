(function(){
  const sessao = Auth.exigirPerfil('anfitriao', 'morador');
  if(!sessao) return;
  document.getElementById('linkVoltar').href = homeDoPerfil(sessao.tipo_usuario);

  const params = new URLSearchParams(window.location.search);
  const imovelId = params.get('id') ? Number(params.get('id')) : null;
  let fotosBase64 = [];

  // ---------- Selects de geolocalização ----------
  const selEstado = document.getElementById('imEstado');
  const selCidade = document.getElementById('imCidade');
  const selBairro = document.getElementById('imBairro');

  function preencherEstados(selecionado){
    selEstado.innerHTML = '<option value="">Selecione</option>' +
      GEO_BRASIL.listarEstados().map(e => `<option value="${e.sigla}">${e.nome}</option>`).join('');
    if(selecionado) selEstado.value = selecionado;
  }
  function preencherCidades(sigla, selecionada){
    const cidades = sigla ? GEO_BRASIL.listarCidades(sigla) : [];
    selCidade.innerHTML = '<option value="">Selecione</option>' + cidades.map(c => `<option value="${c}">${c}</option>`).join('');
    if(selecionada) selCidade.value = selecionada;
  }
  function preencherBairros(sigla, cidade, selecionado){
    const bairros = (sigla && cidade) ? GEO_BRASIL.listarBairros(sigla, cidade) : [];
    if(bairros.length){
      selBairro.disabled = false;
      selBairro.innerHTML = '<option value="">Selecione</option>' + bairros.map(b => `<option value="${b}">${b}</option>`).join('');
    } else {
      selBairro.disabled = false;
      selBairro.innerHTML = '<option value="">Digite/selecione a cidade primeiro</option>';
    }
    if(selecionado) selBairro.value = selecionado;
  }

  selEstado.addEventListener('change', () => { preencherCidades(selEstado.value); preencherBairros(null,null); });
  selCidade.addEventListener('change', () => preencherBairros(selEstado.value, selCidade.value));

  preencherEstados(window.APP_CONFIG.ESTADO_PILOTO);
  preencherCidades(window.APP_CONFIG.ESTADO_PILOTO, window.APP_CONFIG.CIDADE_PILOTO);
  preencherBairros(window.APP_CONFIG.ESTADO_PILOTO, window.APP_CONFIG.CIDADE_PILOTO);

  // ---------- CEP <-> Endereço (ViaCEP) + geocodificação (Nominatim/OSM) ----------
  const statusCep = document.getElementById('statusCep');

  function selecionarOpcao(select, valorDesejado){
    const valores = Array.from(select.options).map(o => o.value.toLowerCase());
    const idx = valores.indexOf((valorDesejado || '').toLowerCase());
    if(idx >= 0){ select.value = select.options[idx].value; return true; }
    return false;
  }

  async function geocodificarEndereco(){
    const endereco = document.getElementById('imEndereco').value.trim();
    const cidade = selCidade.value, estado = selEstado.value;
    if(!endereco || !cidade || !estado) return;
    try{
      const q = encodeURIComponent(`${endereco}, ${cidade}, ${estado}, Brasil`);
      const resp = await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=${q}`);
      const dados = await resp.json();
      if(dados && dados[0]){
        document.getElementById('imLat').value = dados[0].lat;
        document.getElementById('imLng').value = dados[0].lon;
      }
    }catch(err){ /* geocodificação é auxiliar; falha silenciosa não bloqueia o cadastro */ }
  }

  async function buscarPorCep(){
    const cep = document.getElementById('imCep').value.replace(/\D/g,'');
    if(cep.length !== 8){ mostrarToast('Informe um CEP válido (8 dígitos).'); return; }
    statusCep.innerText = 'Buscando endereço...';
    try{
      const resp = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const dados = await resp.json();
      if(dados.erro){ statusCep.innerText = 'CEP não encontrado.'; return; }
      if(dados.logradouro) document.getElementById('imEndereco').value = dados.logradouro;
      preencherEstados(dados.uf);
      preencherCidades(dados.uf, dados.localidade);
      preencherBairros(dados.uf, dados.localidade, dados.bairro);
      selecionarOpcao(selBairro, dados.bairro);
      statusCep.innerText = 'Endereço preenchido a partir do CEP.';
      geocodificarEndereco();
    }catch(err){ statusCep.innerText = 'Não foi possível consultar o CEP agora.'; }
  }

  async function buscarPorEndereco(){
    const endereco = document.getElementById('imEndereco').value.trim();
    const uf = selEstado.value, cidade = selCidade.value;
    if(!endereco || !uf || !cidade){ mostrarToast('Preencha endereço, estado e cidade para buscar o CEP.'); return; }
    statusCep.innerText = 'Buscando CEP...';
    try{
      const resp = await fetch(`https://viacep.com.br/ws/${uf}/${encodeURIComponent(cidade)}/${encodeURIComponent(endereco)}/json/`);
      const dados = await resp.json();
      if(!Array.isArray(dados) || dados.length === 0){ statusCep.innerText = 'CEP não encontrado para este endereço.'; return; }
      const primeiro = dados[0];
      document.getElementById('imCep').value = primeiro.cep;
      preencherBairros(uf, cidade, primeiro.bairro);
      selecionarOpcao(selBairro, primeiro.bairro);
      statusCep.innerText = dados.length > 1 ? `CEP preenchido (1ª opção de ${dados.length} encontradas).` : 'CEP preenchido.';
      geocodificarEndereco();
    }catch(err){ statusCep.innerText = 'Não foi possível consultar o endereço agora.'; }
  }

  document.getElementById('btnBuscarPorCep').addEventListener('click', buscarPorCep);
  document.getElementById('imCep').addEventListener('blur', () => { if(document.getElementById('imCep').value.replace(/\D/g,'').length === 8) buscarPorCep(); });
  document.getElementById('btnBuscarPorEndereco').addEventListener('click', buscarPorEndereco);

  // ---------- Fotos (preview + base64) ----------
  document.getElementById('imFotos').addEventListener('change', function(e){
    Array.from(e.target.files).slice(0, 8).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { fotosBase64.push(ev.target.result); renderPreview(); };
      reader.readAsDataURL(file);
    });
  });
  function renderPreview(){
    document.getElementById('previewFotos').innerHTML = fotosBase64.map(src => `<img src="${src}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join('');
  }

  // ---------- Preenche formulário se for edição ----------
  if(imovelId){
    const imovel = PropertiesService.obterSeDono(sessao.id, imovelId);
    if(!imovel){ mostrarToast('Imóvel não encontrado.'); window.location.href = homeDoPerfil(sessao.tipo_usuario); return; }
    document.getElementById('tituloForm').innerText = 'Editar imóvel';
    document.getElementById('imNome').value = imovel.nome;
    document.getElementById('imEndereco').value = imovel.endereco;
    document.getElementById('imCep').value = imovel.cep || '';
    document.getElementById('imTipo').value = imovel.tipo || 'Apartamento';
    preencherEstados(imovel.estado);
    preencherCidades(imovel.estado, imovel.cidade);
    preencherBairros(imovel.estado, imovel.cidade, imovel.bairro);
    document.getElementById('imLat').value = imovel.latitude ?? '';
    document.getElementById('imLng').value = imovel.longitude ?? '';
    document.getElementById('imQuartos').value = imovel.quartos;
    document.getElementById('imBanheiros').value = imovel.banheiros;
    document.getElementById('imCamas').value = imovel.camas;
    document.getElementById('imCapacidade').value = imovel.capacidade;
    document.getElementById('carCozinha').checked = !!imovel.caracteristicas.cozinha;
    document.getElementById('carSala').checked = !!imovel.caracteristicas.sala;
    document.getElementById('carVaranda').checked = !!imovel.caracteristicas.varanda;
    document.getElementById('carGaragem').checked = !!imovel.caracteristicas.garagem;
    document.getElementById('imMetragem').value = imovel.metragem_m2 ?? '';
    document.getElementById('imAcesso').value = imovel.acesso || '';
    document.getElementById('imCondominio').value = imovel.condominio || '';
    document.getElementById('imObs').value = imovel.observacoes || '';
    fotosBase64 = imovel.fotos || [];
    renderPreview();

    document.getElementById('areaAmbientesInventario').classList.remove('hidden');
    renderAmbientes();
    renderInventario();
  }

  function coletarDadosForm(){
    return {
      nome: document.getElementById('imNome').value.trim(),
      endereco: document.getElementById('imEndereco').value.trim(),
      cep: document.getElementById('imCep').value.trim(),
      tipo: document.getElementById('imTipo').value,
      estado: selEstado.value,
      cidade: selCidade.value,
      bairro: selBairro.value,
      latitude: document.getElementById('imLat').value ? Number(document.getElementById('imLat').value) : null,
      longitude: document.getElementById('imLng').value ? Number(document.getElementById('imLng').value) : null,
      quartos: Number(document.getElementById('imQuartos').value),
      banheiros: Number(document.getElementById('imBanheiros').value),
      camas: Number(document.getElementById('imCamas').value),
      capacidade: Number(document.getElementById('imCapacidade').value),
      metragem_m2: document.getElementById('imMetragem').value ? Number(document.getElementById('imMetragem').value) : null,
      acesso: document.getElementById('imAcesso').value.trim(),
      condominio: document.getElementById('imCondominio').value.trim(),
      caracteristicas: {
        cozinha: document.getElementById('carCozinha').checked,
        sala: document.getElementById('carSala').checked,
        varanda: document.getElementById('carVaranda').checked,
        garagem: document.getElementById('carGaragem').checked,
      },
      observacoes: document.getElementById('imObs').value.trim(),
      fotos: fotosBase64,
    };
  }

  function salvarImovel(){
    const dadosForm = coletarDadosForm();
    const erros = Models.validarImovel(dadosForm);
    if(Object.keys(erros).length){
      Object.entries(erros).forEach(([campo,msg]) => {
        const el = document.getElementById('erro' + campo.charAt(0).toUpperCase() + campo.slice(1));
        if(el){ el.innerText = msg; el.classList.add('show'); }
      });
      mostrarToast('Verifique os campos destacados.');
      return;
    }
    try{
      if(imovelId){
        PropertiesService.atualizar(sessao.id, imovelId, dadosForm);
        mostrarToast('Imóvel atualizado com sucesso!');
        setTimeout(()=> window.location.reload(), 500);
      } else {
        const criado = PropertiesService.criar(sessao.id, dadosForm);
        mostrarToast('Imóvel cadastrado! Agora adicione ambientes e inventário.');
        setTimeout(()=> window.location.href = 'imovel-form.html?id=' + criado.id, 600);
      }
    }catch(err){
      mostrarToast(err.message);
    }
  }

  // ---------- Termo de Intermediação (aceite versionado, uma vez por usuário) ----------
  document.getElementById('formImovel').addEventListener('submit', function(e){
    e.preventDefault();
    document.querySelectorAll('.form-error').forEach(el => { el.classList.remove('show'); el.innerText=''; });

    if(!TermsService.jaAceitou(sessao.id, 'intermediacao_responsabilidades', TERMO_INTERMEDIACAO.versao)){
      document.getElementById('conteudoTermo').innerHTML = TERMO_INTERMEDIACAO.html;
      document.getElementById('termoNome').value = sessao.nome || '';
      const campoCpf = document.getElementById('termoCpf');
      campoCpf.value = sessao.cpf || '';
      campoCpf.readOnly = !!sessao.cpf;
      document.getElementById('obsCpfTermo').innerText = sessao.cpf
        ? 'Dados preenchidos automaticamente a partir do seu cadastro.'
        : 'CPF não informado no cadastro — preencha para assinar o termo.';
      document.getElementById('modalTermo').classList.add('show');
      return;
    }
    salvarImovel();
  });

  document.getElementById('btnAceitarTermo').addEventListener('click', () => {
    const nome = document.getElementById('termoNome').value.trim();
    const cpf = document.getElementById('termoCpf').value.trim();
    if(!document.getElementById('termoAceite').checked){ mostrarToast('Marque que você leu e aceita o termo.'); return; }
    try{
      TermsService.registrarAceite(sessao.id, 'intermediacao_responsabilidades', { nome, cpf, versao: TERMO_INTERMEDIACAO.versao });
      document.getElementById('modalTermo').classList.remove('show');
      salvarImovel();
    }catch(err){ mostrarToast(err.message); }
  });

  // ---------- Ambientes ----------
  let fotosAmbientePendentes = [];
  let videoAmbientePendente = null;

  function renderAmbientes(){
    const ambientes = RoomsService.listarPorImovel(imovelId);
    const cont = document.getElementById('listaAmbientes');
    if(ambientes.length === 0){
      cont.innerHTML = '<p class="text-[12px] text-muted text-center py-3">Nenhum ambiente cadastrado ainda.</p>';
      return;
    }
    cont.innerHTML = ambientes.map(a => `
      <div class="card-soft p-3">
        <div class="flex items-center justify-between mb-1">
          <p class="text-[13px] font-semibold">${a.nome}</p>
          <button class="text-[11px] font-semibold" style="color:#C0392B" data-remover-ambiente="${a.id}">Remover</button>
        </div>
        <p class="text-[11px] text-muted">${(a.fotos||[]).length} foto(s)${a.video ? ' · vídeo anexado' : ''}</p>
        ${a.observacoes ? `<p class="text-[11.5px] text-muted mt-1">"${a.observacoes}"</p>` : ''}
      </div>`).join('');
    cont.querySelectorAll('[data-remover-ambiente]').forEach(btn => {
      btn.onclick = () => { RoomsService.remover(sessao.id, Number(btn.dataset.removerAmbiente)); renderAmbientes(); renderSelectAmbientesInventario(); };
    });
  }

  document.getElementById('btnNovoAmbiente').addEventListener('click', () => {
    fotosAmbientePendentes = []; videoAmbientePendente = null;
    document.getElementById('ambNome').value = '';
    document.getElementById('ambObs').value = '';
    document.getElementById('previewFotosAmbiente').innerHTML = '';
    document.getElementById('modalAmbiente').classList.add('show');
  });
  document.getElementById('fecharModalAmbiente').onclick = () => document.getElementById('modalAmbiente').classList.remove('show');
  document.getElementById('ambFotos').addEventListener('change', function(e){
    Array.from(e.target.files).slice(0,6).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { fotosAmbientePendentes.push(ev.target.result); document.getElementById('previewFotosAmbiente').innerHTML = fotosAmbientePendentes.map(f=>`<img src="${f}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join(''); };
      reader.readAsDataURL(file);
    });
  });
  document.getElementById('ambVideo').addEventListener('change', function(e){
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = ev => { videoAmbientePendente = ev.target.result; mostrarToast('Vídeo anexado.'); };
    reader.readAsDataURL(file);
  });
  document.getElementById('btnSalvarAmbiente').addEventListener('click', () => {
    const nome = document.getElementById('ambNome').value.trim();
    if(!nome){ mostrarToast('Dê um nome para o ambiente.'); return; }
    RoomsService.criar(sessao.id, imovelId, { nome, observacoes: document.getElementById('ambObs').value.trim(), fotos: fotosAmbientePendentes, video: videoAmbientePendente });
    mostrarToast('Ambiente adicionado!');
    document.getElementById('modalAmbiente').classList.remove('show');
    renderAmbientes();
    renderSelectAmbientesInventario();
  });

  // ---------- Inventário ----------
  let fotosInventarioPendentes = [];

  function renderSelectAmbientesInventario(){
    if(!imovelId) return;
    const ambientes = RoomsService.listarPorImovel(imovelId);
    document.getElementById('invAmbiente').innerHTML = '<option value="">Nenhum específico</option>' +
      ambientes.map(a => `<option value="${a.id}">${a.nome}</option>`).join('');
  }

  const rotuloEstado = { NOVO:'Novo', BOM:'Bom', REGULAR:'Regular', DANIFICADO:'Danificado', NAO_FUNCIONA:'Não funciona', NAO_TESTADO:'Não testado', NAO_APLICAVEL:'Não aplicável' };
  const classeEstado = { NOVO:'ativo', BOM:'ativo', REGULAR:'pendente', DANIFICADO:'inativo', NAO_FUNCIONA:'inativo', NAO_TESTADO:'pendente', NAO_APLICAVEL:'inativo' };

  function renderInventario(){
    const itens = InventoryService.listarPorImovel(imovelId);
    const cont = document.getElementById('listaInventario');
    if(itens.length === 0){
      cont.innerHTML = '<p class="text-[12px] text-muted text-center py-3">Nenhum item cadastrado ainda.</p>';
      return;
    }
    cont.innerHTML = itens.map(i => `
      <div class="list-row">
        <div class="flex-1 min-w-0">
          <p class="text-[12.5px] font-semibold truncate">${i.item} <span class="text-muted font-normal">(qtd. ${i.quantidade})</span></p>
          ${i.observacao ? `<p class="text-[11px] text-muted truncate">${i.observacao}</p>` : ''}
        </div>
        <span class="badge-status ${classeEstado[i.estado]}">${rotuloEstado[i.estado]}</span>
        <button class="text-[11px] font-semibold ml-2" style="color:#C0392B" data-remover-item="${i.id}">Remover</button>
      </div>`).join('');
    cont.querySelectorAll('[data-remover-item]').forEach(btn => {
      btn.onclick = () => { InventoryService.remover(sessao.id, Number(btn.dataset.removerItem)); renderInventario(); };
    });
  }

  document.getElementById('btnNovoItemInventario').addEventListener('click', () => {
    fotosInventarioPendentes = [];
    document.getElementById('invItem').value = '';
    document.getElementById('invQuantidade').value = 1;
    document.getElementById('invEstado').value = 'NAO_TESTADO';
    document.getElementById('invObs').value = '';
    document.getElementById('previewFotosInventario').innerHTML = '';
    renderSelectAmbientesInventario();
    document.getElementById('modalInventario').classList.add('show');
  });
  document.getElementById('fecharModalInventario').onclick = () => document.getElementById('modalInventario').classList.remove('show');
  document.getElementById('invFotos').addEventListener('change', function(e){
    Array.from(e.target.files).slice(0,4).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { fotosInventarioPendentes.push(ev.target.result); document.getElementById('previewFotosInventario').innerHTML = fotosInventarioPendentes.map(f=>`<img src="${f}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join(''); };
      reader.readAsDataURL(file);
    });
  });
  document.getElementById('btnSalvarInventario').addEventListener('click', () => {
    const item = document.getElementById('invItem').value.trim();
    if(!item){ mostrarToast('Informe o nome do item.'); return; }
    InventoryService.criarItem(sessao.id, imovelId, {
      room_id: document.getElementById('invAmbiente').value ? Number(document.getElementById('invAmbiente').value) : null,
      item, quantidade: Number(document.getElementById('invQuantidade').value),
      estado: document.getElementById('invEstado').value,
      observacao: document.getElementById('invObs').value.trim(),
      evidencias: fotosInventarioPendentes,
    });
    mostrarToast('Item adicionado ao inventário!');
    document.getElementById('modalInventario').classList.remove('show');
    renderInventario();
  });
})();
