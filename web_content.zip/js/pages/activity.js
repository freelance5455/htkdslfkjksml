/* =============================================================
   LAMPION POS · js/pages/activity.js  (pengganti activity.php)
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  var filledActions = false;

  function load() {
    var action = ($('f-action') || {}).value || '';
    var limit = ($('f-limit') || {}).value || '300';

    return LP.api('api/users.php?action=list_activity&limit=' + encodeURIComponent(limit) +
      '&filter=' + encodeURIComponent(action), { method: 'GET' })
      .then(function (res) {
        /* isi dropdown jenis tindakan sekali saja */
        if (!filledActions && res.actions) {
          var f = $('f-action');
          f.innerHTML = '<option value="">Semua tindakan</option>' +
            res.actions.map(function (a) {
              return '<option value="' + esc(a) + '">' + esc(a) + '</option>';
            }).join('');
          filledActions = true;
        }
        $('act-sub').textContent = (res.total || 0) + ' catatan tersimpan';
        render(res.rows || []);
      })
      .catch(function (e) {
        LP.toast('Gagal memuat log: ' + e.message, 'err', 5000);
      });
  }

  function render(rows) {
    var tb = $('tb-act');
    if (!tb) { return; }
    if (rows.length === 0) {
      tb.innerHTML = LPUI.emptyRow(5, 'Tidak ada catatan', 'Belum ada aktivitas terekam.');
      return;
    }
    tb.innerHTML = rows.map(function (r) {
      var det = r.detail ? String(r.detail) : '';
      if (det.length > 120) { det = det.slice(0, 120) + '…'; }
      return '<tr>' +
        '<td class="nowrap">' + esc(String(r.created_at).slice(0, 16)) + '</td>' +
        '<td class="nowrap">' + esc(r.user_name) + '</td>' +
        '<td><span class="badge info">' + esc(r.action) + '</span></td>' +
        '<td>' + esc(r.target || '-') + '</td>' +
        '<td><span class="text-muted" style="font-size:11.5px">' + esc(det) + '</span></td>' +
        '</tr>';
    }).join('');
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('activity.view', function () {
      LPUI.mountChrome('activity.html');

      $('f-action').addEventListener('change', load);
      $('f-limit').addEventListener('change', load);
      $('btn-refresh').addEventListener('click', load);

      load();
    });
  });
})();
