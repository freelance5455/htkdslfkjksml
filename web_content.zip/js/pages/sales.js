/* =============================================================
   LAMPION POS · js/pages/sales.js  (pengganti sales.php, sales_items.php)
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function money(n) { return PHP.money(n); }
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  var LAST = null;

  function load() {
    var from = $('f-from').value || LPDB.today();
    var to = $('f-to').value || LPDB.today();

    return LP.api('api/sales.php?from=' + encodeURIComponent(from) +
      '&to=' + encodeURIComponent(to), { method: 'GET' })
      .then(function (res) { LAST = res; render(res); })
      .catch(function (e) {
        LP.toast('Gagal memuat laporan: ' + e.message, 'err', 6000);
      });
  }

  function render(res) {
    var s = res.summary || {};
    $('r-sales').textContent = money(s.sales);
    $('r-tx').textContent = Number(s.tx) || 0;
    $('r-items').textContent = Number(s.items) || 0;
    var avg = (Number(s.tx) > 0) ? (Number(s.sales) / Number(s.tx)) : 0;
    $('r-avg').textContent = money(avg);
    $('range-label').textContent = 'Periode ' + res.from + ' s/d ' + res.to;

    /* per hari */
    var days = res.per_day || [];
    $('tb-day').innerHTML = days.length === 0
      ? LPUI.emptyRow(3, 'Tidak ada penjualan', 'Tidak ada transaksi lunas pada periode ini.')
      : days.map(function (d) {
        return '<tr><td>' + esc(d.d) + '</td><td class="num">' + Number(d.tx) +
          '</td><td class="num">' + money(d.total) + '</td></tr>';
      }).join('');

    /* per metode bayar */
    var pms = res.payments || [];
    $('tb-pm').innerHTML = pms.length === 0
      ? LPUI.emptyRow(3, 'Tidak ada data', '')
      : pms.map(function (p) {
        return '<tr><td>' + esc(p.label) + '</td><td class="num">' + Number(p.cnt) +
          '</td><td class="num">' + money(p.total) + '</td></tr>';
      }).join('');

    /* detail transaksi */
    var orders = res.orders || [];
    $('detail-count').textContent = orders.length + ' nota';
    $('tb-orders').innerHTML = orders.length === 0
      ? LPUI.emptyRow(9, 'Tidak ada transaksi', 'Ubah rentang tanggal.')
      : orders.map(function (o) {
        return '<tr>' +
          '<td class="nowrap"><b>' + esc(o.order_number) + '</b></td>' +
          '<td class="nowrap">' + esc(String(o.created_at).slice(0, 16)) + '</td>' +
          '<td>' + esc(LPDB.ORDER_TYPE_LABEL[o.order_type] || o.order_type) + '</td>' +
          '<td>' + esc(o.customer_name || '-') + '</td>' +
          '<td>' + esc(o.cashier || '-') + '</td>' +
          '<td>' + esc(LPDB.PAYMENT_LABEL[o.payment_method] || o.payment_method) + '</td>' +
          '<td>' + LPUI.statusBadge(o.status) + '</td>' +
          '<td class="num"><b>' + money(o.total) + '</b></td>' +
          '<td><button class="btn btn-sm" data-detail="' + Number(o.id) +
          '">Detail</button></td>' +
          '</tr>';
      }).join('');
  }

  /* ---------- cetak ulang struk ---------- */

  /**
   * Bentuk data api/sales.php berbeda dari api/orders.php:
   *   sales: cashier, created_at, payment_method, order_type (mentah)
   *   struk: cashier_name, created_label, payment_label, order_type_label
   * Di sini dipetakan agar receiptLines() bisa dipakai ulang apa adanya.
   * Field `received`/`change_due` tidak tersedia dari laporan -> dikosongkan
   * supaya struk menampilkan "Bayar = TOTAL" dan "Kembali" nol.
   */
  function toReceiptOrder(o) {
    return {
      order_number: o.order_number,
      order_type: o.order_type,
      order_type_label: LPDB.ORDER_TYPE_LABEL[o.order_type] || o.order_type,
      customer_name: o.customer_name || '',
      cashier_name: o.cashier || '',
      created_label: LPDB.dmyHi(o.created_at),
      payment_method: o.payment_method,
      payment_label: LPDB.PAYMENT_LABEL[o.payment_method] || o.payment_method,
      subtotal: Number(o.subtotal) || 0,
      discount: Number(o.discount) || 0,
      tax: Number(o.tax) || 0,
      total: Number(o.total) || 0,
      received: null,
      change_due: 0,
      items: o.items || []
    };
  }

  /** Cetak ulang struk satu nota lewat intent (mode printer dari Pengaturan) */
  function reprint(orderId) {
    var orders = (LAST && LAST.orders) || [];
    var o = orders.filter(function (x) { return Number(x.id) === Number(orderId); })[0];
    if (!o) { return; }

    if (!window.LPESCPOS) {
      return LP.toast('Modul printer tidak dimuat.', 'err');
    }

    LPDB.getSettings(['store_name', 'store_address', 'store_phone',
      'store_footer', 'printer_width', 'printer_mode', 'printer_font_px'])
      .then(function (store) {
        /* banner REPRINT ditandai di sisi escpos.js lewat opts.reprint */
        return LPESCPOS.printReceipt(toReceiptOrder(o), store, { reprint: true });
      })
      .then(function (res) {
        if (res.handoff) {
          LP.toast('Struk cetak ulang dikirim ke printer.', 'ok');
          return;
        }
        LP.toast('Aplikasi Open ESC/POS tidak merespons. Cetak ulang butuh ' +
          'mode printer "Intent Open ESC/POS" dan aplikasinya terpasang.',
          'warn', 7000);
      })
      .catch(function (e) {
        LP.toast('Cetak ulang gagal: ' + e.message, 'err', 6000);
      });
  }

  /* ---------- detail satu nota ---------- */
  function showDetail(orderId) {
    var orders = (LAST && LAST.orders) || [];
    var o = orders.filter(function (x) { return Number(x.id) === Number(orderId); })[0];
    if (!o) { return; }

    var rowsHtml = (o.items || []).map(function (it) {
      return '<tr><td>' + esc(it.item_name) + '</td>' +
        '<td class="num">' + it.qty + '</td>' +
        '<td class="num">' + money(it.price) + '</td>' +
        '<td class="num">' + money(it.subtotal) + '</td></tr>';
    }).join('');
    if (rowsHtml === '') { rowsHtml = LPUI.emptyRow(4, 'Tidak ada rincian', ''); }

    var modal = LPUI.modal({
      title: 'Nota ' + o.order_number,
      width: 560,
      body: '<div class="table-wrap"><table class="tbl">' +
        '<thead><tr><th>Item</th><th class="num">Qty</th>' +
        '<th class="num">Harga</th><th class="num">Subtotal</th></tr></thead>' +
        '<tbody>' + rowsHtml + '</tbody></table></div>' +
        '<dl class="kv mt-12">' +
        '<div class="kv-row"><dt>Subtotal</dt><dd>' + money(o.subtotal) + '</dd></div>' +
        '<div class="kv-row"><dt>Diskon</dt><dd>-' + money(o.discount) + '</dd></div>' +
        '<div class="kv-row"><dt>Pajak</dt><dd>' + money(o.tax) + '</dd></div>' +
        '<div class="kv-row"><dt><b>Total</b></dt><dd><b>' + money(o.total) + '</b></dd></div>' +
        '<div class="kv-row"><dt>Bayar</dt><dd>' +
        esc(LPDB.PAYMENT_LABEL[o.payment_method] || o.payment_method) + '</dd></div>' +
        '<div class="kv-row"><dt>Status</dt><dd>' + LPUI.statusBadge(o.status) + '</dd></div>' +
        '</dl>',
      foot: '<button class="btn" data-x type="button">Tutup</button>' +
        '<button class="btn btn-primary" data-reprint="' + Number(o.id) +
        '" type="button">Cetak Struk</button>'
    });

    /* tombol cetak struk ulang (banner REPRINT ditambahkan di struk) */
    var rp = modal.el.querySelector('[data-reprint]');
    if (rp) {
      rp.addEventListener('click', function () { reprint(Number(rp.dataset.reprint)); });
    }
  }


  /* ---------- ekspor CSV ---------- */
  function exportCsv() {
    if (!LAST || !LAST.orders) { return LP.toast('Belum ada data.', 'warn'); }
    var head = ['Nota', 'Waktu', 'Tipe', 'Pelanggan', 'Kasir', 'Bayar',
      'Status', 'Subtotal', 'Diskon', 'Pajak', 'Total', 'Item'];
    var lines = [head.join(';')];

    LAST.orders.forEach(function (o) {
      var items = (o.items || []).map(function (it) {
        return it.item_name + ' x' + it.qty;
      }).join(', ');
      lines.push([
        o.order_number, o.created_at, o.order_type, o.customer_name || '',
        o.cashier || '', o.payment_method, o.status,
        o.subtotal, o.discount, o.tax, o.total,
        '"' + items.replace(/"/g, '""') + '"'
      ].join(';'));
    });

    /* BOM supaya Excel Indonesia membaca UTF-8 dengan benar */
    var blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'penjualan_' + (LAST.from || '') + '_' + (LAST.to || '') + '.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    LP.toast('CSV diunduh.', 'ok');
  }

  /* ---------- rentang cepat ---------- */
  function setRange(daysBack) {
    $('f-from').value = LPDB.shiftDays(-daysBack);
    $('f-to').value = LPDB.today();
    load();
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('sales.view', function () {
      LPUI.mountChrome('sales.html');

      /* default: hari ini */
      $('f-from').value = LPDB.today();
      $('f-to').value = LPDB.today();

      $('btn-apply').addEventListener('click', load);
      $('btn-today').addEventListener('click', function () { setRange(0); });
      $('btn-week').addEventListener('click', function () { setRange(6); });
      $('btn-month').addEventListener('click', function () { setRange(29); });
      $('btn-export').addEventListener('click', exportCsv);

      $('tb-orders').addEventListener('click', function (e) {
        var b = e.target.closest('[data-detail]');
        if (b) { showDetail(Number(b.dataset.detail)); }
      });

      load();
    });
  });
})();
