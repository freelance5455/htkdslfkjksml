/* =============================================================
   LAMPION POS · js/pages/roles.js  (pengganti roles.php)
   -------------------------------------------------------------
   Daftar peran + matriks permission.
   Role "Admin" selalu punya semua permission (padanan '*').
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  var ROLES = [];
  var PERMS = [];

  function load() {
    return LP.api('api/users.php?action=list_roles', { method: 'GET' }).then(function (res) {
      ROLES = res.roles || [];
      PERMS = res.permissions || [];
      render();
    }).catch(function (e) {
      LP.toast('Gagal memuat peran: ' + e.message, 'err', 5000);
    });
  }

  /** Kelompokkan permission berdasarkan group_label */
  function groupPerms() {
    var groups = {};
    PERMS.forEach(function (p) {
      var g = p.group_label || 'Lainnya';
      if (!groups[g]) { groups[g] = []; }
      groups[g].push(p);
    });
    return groups;
  }

  function render() {
    var host = $('role-list');
    if (!host) { return; }
    if (ROLES.length === 0) {
      host.innerHTML = '<div class="card"><div class="empty-state">' +
        '<b>Belum ada peran</b></div></div>';
      return;
    }

    host.innerHTML = ROLES.map(function (r) {
      var isAdmin = (r.perms.indexOf('*') !== -1);
      var count = isAdmin ? PERMS.length : r.perms.length;
      var groups = groupPerms();

      var permHtml = Object.keys(groups).map(function (g) {
        return '<div style="margin-bottom:10px">' +
          '<div style="font-size:11px;font-weight:800;color:#9ca3af;' +
          'text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px">' +
          esc(g) + '</div>' +
          '<div class="flex">' +
          groups[g].map(function (p) {
            var on = isAdmin || r.perms.indexOf(p.pkey) !== -1;
            return '<span class="badge ' + (on ? 'ok' : 'mute') + '">' +
              esc(p.name) + '</span>';
          }).join('') +
          '</div></div>';
      }).join('');

      return '<div class="card">' +
        '<div class="card-header">' +
        '<h3>' + esc(r.name) +
        (Number(r.is_system) === 1 ? ' <span class="badge info">Sistem</span>' : '') +
        '</h3>' +
        '<div class="flex">' +
        '<span class="text-muted" style="font-size:12px">' + r.user_count +
        ' pengguna &middot; ' + count + ' akses</span>' +
        '<button class="btn btn-sm" data-edit="' + Number(r.id) + '">Ubah Akses</button>' +
        (Number(r.is_system) === 1 ? '' :
          ' <button class="btn btn-sm btn-danger" data-del="' + Number(r.id) +
          '">Hapus</button>') +
        '</div></div>' +
        '<div class="card-body">' + permHtml + '</div>' +
        '</div>';
    }).join('');
  }

  function openForm(role) {
    var isEdit = !!role;
    var r = role || { id: 0, name: '', perms: [] };
    var isAdmin = (r.perms.indexOf('*') !== -1);
    var groups = groupPerms();

    var body = '<div class="field"><label>Nama peran *</label>' +
      '<input type="text" id="r-name" value="' + esc(r.name) + '"' +
      (isAdmin ? ' disabled' : '') + '></div>' +
      (isAdmin ? '<div class="hint text-muted" style="margin-bottom:12px">' +
        'Peran Admin otomatis memiliki semua akses.</div>' : '') +
      '<div class="field"><label>Hak akses</label>';

    Object.keys(groups).forEach(function (g) {
      body += '<div style="margin-bottom:12px">' +
        '<div style="font-size:11px;font-weight:800;color:#9ca3af;' +
        'text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px">' +
        esc(g) + '</div>';
      groups[g].forEach(function (p) {
        var on = isAdmin || r.perms.indexOf(p.pkey) !== -1;
        body += '<div class="check" style="margin-bottom:5px">' +
          '<input type="checkbox" class="r-perm" value="' + esc(p.pkey) + '"' +
          (on ? ' checked' : '') + (isAdmin ? ' disabled' : '') + '>' +
          '<span>' + esc(p.name) + ' <small class="text-muted">(' +
          esc(p.pkey) + ')</small></span></div>';
      });
      body += '</div>';
    });
    body += '</div>';

    var md = LPUI.modal({
      title: isEdit ? 'Ubah Peran' : 'Peran Baru',
      body: body,
      foot: '<button class="btn" type="button" data-x>Batal</button>' +
        '<button class="btn btn-primary" type="button" id="r-save">Simpan</button>',
      width: 560
    });

    md.el.querySelector('#r-save').addEventListener('click', function () {
      var nameEl = md.el.querySelector('#r-name');
      var name = nameEl ? String(nameEl.value).trim() : String(r.name);
      if (name === '') { return LP.toast('Nama peran wajib.', 'warn'); }

      var perms = [];
      md.el.querySelectorAll('.r-perm').forEach(function (c) {
        if (c.checked) { perms.push(c.value); }
      });

      return LP.api('api/users.php', {
        method: 'POST',
        body: JSON.stringify({
          action: 'save_role', id: Number(r.id) || 0, name: name, perms: perms
        })
      }).then(function () {
        md.close();
        LP.toast('Peran disimpan.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 6000); });
    });
  }

  function remove(id) {
    LP.confirm('Hapus peran ini?').then(function (ok) {
      if (!ok) { return null; }
      return LP.api('api/users.php', {
        method: 'POST', body: JSON.stringify({ action: 'delete_role', id: Number(id) })
      }).then(function () {
        LP.toast('Peran dihapus.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 6000); });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('roles.manage', function () {
      LPUI.mountChrome('roles.html');

      $('btn-new').addEventListener('click', function () { openForm(null); });
      $('role-list').addEventListener('click', function (e) {
        var ed = e.target.closest('[data-edit]');
        var dl = e.target.closest('[data-del]');
        if (ed) {
          var id = Number(ed.dataset.edit);
          var r = ROLES.filter(function (x) { return Number(x.id) === id; })[0];
          if (r) { openForm(r); }
        } else if (dl) {
          remove(Number(dl.dataset.del));
        }
      });

      load();
    });
  });
})();

