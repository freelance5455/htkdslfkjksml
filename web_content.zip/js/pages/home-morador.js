/**
 * home-morador.js — painel do perfil "Morador / Residente" (🏡).
 *
 * Reaproveita integralmente PropertiesService e ServiceRequestsService (a
 * autorização já é feita por owner_id na camada de serviço, independente do
 * tipo de usuário) — só a apresentação muda para o contexto de "contratar
 * serviços para a própria residência", em vez de gestão de imóvel para
 * hospedagem. Anfitrião e Profissional permanecem intocados.
 */
(function(){
  const sessao = Auth.exigirPerfil('morador');
  if(!sessao) return;
  aplicarSessaoNoCabecalho();

  document.getElementById('btnNovaResidencia').onclick = () => window.location.href = 'imovel-form.html';
  document.getElementById('btnSolicitarServico').onclick = () => window.location.href = 'solicitar-servico.html';
  document.getElementById('btnQrCode').onclick = () => mostrarToast('QR Code em breve — recurso ainda não disponível nesta fase de testes.');
  atualizarBadgeNotificacoes(sessao.id);

  (function atualizarTabDot(){
    const dot = document.getElementById('tabDotMsg');
    if(dot && window.NotificationsService) dot.classList.toggle('hidden', NotificationsService.naoLidas(sessao.id) === 0);
  })();

  (function atualizarLocalPrincipal(){
    const imoveis = PropertiesService.listarDoAnfitriao(sessao.id);
    if(imoveis.length === 0) return;
    const im = imoveis[0];
    const texto = `${im.bairro ? im.bairro+' - ' : ''}${im.cidade}/${im.estado}`;
    document.getElementById('localPrincipalTexto').innerText = texto;
    document.getElementById('localPrincipal').classList.remove('hidden');
  })();

  function badgeStatus(status){
    return status === 'ativo'
      ? '<span class="badge-status ativo">Ativa</span>'
      : '<span class="badge-status inativo">Inativa</span>';
  }

  function render(){
    const imoveis = PropertiesService.listarDoAnfitriao(sessao.id);
    const cont = document.getElementById('listaImoveis');
    cont.innerHTML = '';

    if(imoveis.length === 0){
      cont.innerHTML = `
        <div class="empty-state card-soft">
          <i data-lucide="home"></i>
          <p>Você ainda não cadastrou nenhuma residência.</p>
        </div>`;
      refreshIcons();
      return;
    }

    imoveis.forEach(im => {
      const div = document.createElement('div');
      div.className = 'card-soft p-4 flex items-center gap-3 home-imovel-card';
      const caract = im.caracteristicas || {};
      div.innerHTML = `
        ${im.fotos && im.fotos.length ? `<img src="${im.fotos[0]}" class="foto" alt="${im.nome}">` : `<div class="icon-circle" style="background:#EAF1FD; color:var(--azul)"><i data-lucide="home"></i></div>`}
        <div class="flex-1 min-w-0">
          <p class="font-semibold text-[13.5px] truncate">${im.nome}</p>
          <p class="text-[11.5px] text-muted truncate flex items-center gap-1"><i data-lucide="map-pin" style="width:11px;height:11px"></i>${im.bairro ? im.bairro+' - ' : ''}${im.cidade}/${im.estado}</p>
          <div class="mt-1">${badgeStatus(im.status)}</div>
          <div class="icones-resumo">
            <span><i data-lucide="bed-double"></i>${im.quartos} quarto${im.quartos===1?'':'s'}</span>
            <span><i data-lucide="bath"></i>${im.banheiros} banheiro${im.banheiros===1?'':'s'}</span>
            ${caract.sala ? '<span><i data-lucide="sofa"></i>Sala</span>' : ''}
            ${caract.varanda ? '<span><i data-lucide="trees"></i>Sacada</span>' : ''}
          </div>
        </div>
        <div class="flex flex-col items-end gap-2">
          <button class="toggle-switch ${im.status==='ativo'?'on':''}" data-id="${im.id}" title="Ativar/Desativar"></button>
          <a href="imovel-form.html?id=${im.id}" class="text-[11.5px] font-semibold underline" style="color:var(--azul-escuro)">Editar</a>
        </div>
      `;
      cont.appendChild(div);
    });

    cont.querySelectorAll('.toggle-switch').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = Number(btn.dataset.id);
        const imovel = PropertiesService.obterSeDono(sessao.id, id);
        const novoStatus = imovel.status === 'ativo' ? 'inativo' : 'ativo';
        PropertiesService.definirStatus(sessao.id, id, novoStatus);
        mostrarToast(novoStatus === 'ativo' ? 'Residência ativada.' : 'Residência desativada.');
        render();
      });
    });

    refreshIcons();
  }

  function badgeSolicitacao(status){
    const map = {
      DRAFT: ['Rascunho','pendente'], PUBLISHED: ['Publicada','ativo'], ACCEPTED: ['Aceita','verificado'],
      IN_PROGRESS: ['Em andamento','verificado'], COMPLETED: ['Concluída','ativo'], CANCELLED: ['Cancelada','inativo'],
    };
    const [txt, classe] = map[status] || [status, 'inativo'];
    return `<span class="badge-status ${classe}">${txt}</span>`;
  }

  function renderSolicitacoes(){
    const solicitacoes = ServiceRequestsService.listarDoAnfitriao(sessao.id).filter(s => s.status !== 'DRAFT');
    const cont = document.getElementById('listaSolicitacoes');
    if(!cont) return;

    if(solicitacoes.length === 0){
      cont.innerHTML = `<div class="empty-state card-soft"><i data-lucide="inbox"></i><p>Nenhum serviço contratado ainda.</p></div>`;
      refreshIcons();
      return;
    }

    cont.innerHTML = solicitacoes.map(s => {
      const imovel = DB.find('properties', s.property_id);
      const qtdInteresses = InterestsService.listarPorSolicitacao(s.id).filter(i => i.status === 'interessado').length;
      return `
        <a href="solicitacao-detalhe.html?id=${s.id}" class="card-soft p-4 block mb-3">
          <div class="flex items-center justify-between mb-1">
            <p class="font-semibold text-[13.5px]">${s.categoria}</p>
            ${badgeSolicitacao(s.status)}
          </div>
          <p class="text-[11.5px] text-muted">${imovel ? imovel.nome : ''} · ${formatarData(s.data)} às ${s.horario}</p>
          ${s.status === 'PUBLISHED' && qtdInteresses > 0 ? `<p class="text-[11.5px] font-semibold mt-1" style="color:var(--azul-escuro)">${qtdInteresses} profissional(is) interessado(s)</p>` : ''}
        </a>
      `;
    }).join('');
    refreshIcons();
  }

  render();
  renderSolicitacoes();
})();
