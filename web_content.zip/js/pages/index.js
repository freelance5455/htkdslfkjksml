(function(){
  const sessao = Auth.getSessao();

  // ---- Sessão: cabeçalho, hero e área entrar/cadastrar ----
  if(sessao){
    document.getElementById('areaSessao').classList.remove('hidden');
    document.getElementById('areaVisitante').classList.add('hidden');
    document.getElementById('linkNotifTopo').classList.remove('hidden');
    document.getElementById('linkPerfilTopo').classList.remove('hidden');
    aplicarSessaoNoCabecalho();
    document.getElementById('btnContinuar').onclick = () => window.location.href = homeDoPerfil(sessao.tipo_usuario);
  }

  // ---- Menu lateral (mobile: off-canvas / desktop: fixo via CSS) ----
  const sidebar = document.getElementById('sidebarDesktop');
  const overlay = document.getElementById('sidebarOverlay');
  const abrirMenu = () => { sidebar.classList.add('open'); overlay.classList.add('show'); };
  const fecharMenu = () => { sidebar.classList.remove('open'); overlay.classList.remove('show'); };
  document.getElementById('btnAbrirMenu').onclick = abrirMenu;
  document.getElementById('btnFecharMenu').onclick = fecharMenu;
  overlay.onclick = fecharMenu;

  // ---- Navegação da sidebar, respeitando o perfil logado ----
  const rotasPorPerfil = {
    acomodacoes: { anfitriao:'home-anfitriao.html', morador:'home-morador.html' },
    servicos: { anfitriao:'solicitar-servico.html', morador:'solicitar-servico.html', profissional:'oportunidades.html' },
    perfil: { anfitriao:'perfil.html', morador:'perfil.html', profissional:'perfil.html', administrador:'perfil.html' },
  };
  document.querySelectorAll('.sidebar-nav a[data-nav]').forEach(link => {
    link.addEventListener('click', (ev) => {
      ev.preventDefault();
      const nav = link.getAttribute('data-nav');
      if(!sessao){ window.location.href = 'login.html'; return; }
      if(nav === 'financeiro' || nav === 'avaliacoes'){
        mostrarToast(nav === 'financeiro' ? 'Módulo Financeiro em desenvolvimento (Etapa 5).' : 'Histórico de avaliações em breve.');
        return;
      }
      const destino = (rotasPorPerfil[nav] || {})[sessao.tipo_usuario];
      window.location.href = destino || homeDoPerfil(sessao.tipo_usuario);
    });
  });

})();
