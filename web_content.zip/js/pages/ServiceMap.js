import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { CITY_COORDS, geoErrorText, inFrame, money, openInNewTab } from '../lib/util.js';
import { Empty, Notice } from '../components/Bits.js';
import Icon, { ServiceIcon } from '../components/Icon.js';
import LiveMap, { insidePK } from '../components/LiveMap.js';
export default function ServiceMap() {
    const { slug } = useParams();
    const nav = useNavigate();
    const [service, setService] = useState(null);
    const [pos, setPos] = useState(null);
    const [gate, setGate] = useState(true);
    const [asking, setAsking] = useState(false);
    const [err, setErr] = useState('');
    const [km, setKm] = useState(5);
    const [list, setList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [acc, setAcc] = useState(null);
    const [perm, setPerm] = useState('?');
    const [stats, setStats] = useState(null);
    useEffect(() => {
        supabase.from('services').select('*').eq('slug', slug).maybeSingle().then(({ data }) => {
            const s = data;
            setService(s);
            if (s) {
                supabase.from('listings').select('id, lat').eq('service_id', s.id).eq('active', true).then(({ data: rows }) => {
                    const r = rows || [];
                    setStats({ total: r.length, withLoc: r.filter((x) => x.lat !== null).length });
                });
            }
        });
    }, [slug]);
    const ask = useCallback(() => {
        setErr('');
        if (!navigator.geolocation)
            return setErr('Aap ka browser location support nahi karta. Neeche se shehar chunein.');
        setAsking(true);
        navigator.geolocation.getCurrentPosition((p) => {
            setAsking(false);
            const { latitude: lat, longitude: lng } = p.coords;
            if (!insidePK(lat, lng))
                return setErr('Aap Pakistan ke andar nahi lag rahe. Neeche se shehar chunein ya map par tap karein.');
            setAcc(p.coords.accuracy);
            setPos({ lat, lng });
            setGate(false);
        }, (e) => { setAsking(false); setErr(geoErrorText(e.code)); }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 30000 });
    }, []);
    // Agar pehle se ijazat hai to popup ke baghair seedha location le lo
    useEffect(() => {
        const perms = navigator.permissions;
        perms?.query({ name: 'geolocation' }).then((r) => { setPerm(r.state); if (r.state === 'granted')
            ask(); }).catch(() => undefined);
    }, [ask]);
    useEffect(() => {
        if (!pos || !service)
            return;
        setLoading(true);
        supabase.rpc('nearby_listings', { p_service: service.id, p_lat: pos.lat, p_lng: pos.lng, p_radius_km: km })
            .then(({ data }) => { setList(data || []); setLoading(false); });
    }, [pos, service, km]);
    const markers = useMemo(() => {
        const m = list.map((s) => ({
            id: s.id, lat: s.lat, lng: s.lng, color: '#F5A524', clickable: true,
            label: s.seller_name, sub: `${s.title} · ${money(s.price)} ${s.price_unit} · ${s.distance_km.toFixed(1)} km`,
        }));
        if (pos)
            m.push({ id: 'me', lat: pos.lat, lng: pos.lng, color: '#0A3D52', label: 'Aap yahan hain' });
        return m;
    }, [list, pos]);
    if (!service)
        return _jsx("p", { className: "muted center", children: "Load ho raha hai..." });
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "page-head", children: [_jsx(Link, { to: `/service/${service.slug}`, className: "back", "aria-label": "Wapas", children: _jsx(Icon, { name: "chevL", size: 20 }) }), _jsx("div", { className: "ic-box sm", style: { '--c': service.color }, children: _jsx(ServiceIcon, { slug: service.slug, emoji: service.emoji, size: 20 }) }), _jsxs("div", { className: "grow", children: [_jsxs("h2", { style: { margin: 0 }, children: [service.name, " map"] }), _jsxs("span", { className: "small muted", children: ["Aap ke ", km, " km ke andar"] })] })] }), _jsxs("div", { className: "tabs", children: [[2, 5, 10].map((k) => _jsxs("button", { className: km === k ? 'active' : '', onClick: () => setKm(k), children: [k, " km"] }, k)), _jsxs("button", { onClick: () => { setGate(true); ask(); }, children: [_jsx(Icon, { name: "pin", size: 14 }), " Meri location"] })] }), !pos && !gate && _jsx(Notice, { kind: "warn", children: "Map par apni jagah tap karein, ya \"Meri location\" dabayein." }), pos && (_jsxs(Notice, { kind: list.length > 0 ? 'ok' : 'info', children: [_jsxs("b", { children: ["Aap ki location mil gayi", acc ? ` (±${Math.round(acc)} meter)` : '', "."] }), ' ', stats && (stats.total === 0
                        ? 'Abhi is service mein koi seller nahi.'
                        : `Is service ke ${stats.total} seller${stats.total > 1 ? 's' : ''} mein se ${stats.withLoc} ne map par location lagayi hai`), stats && stats.total > 0 && (list.length > 0
                        ? `, aur ${list.length} aap ke ${km} km ke andar hain.`
                        : stats.withLoc > 0
                            ? `, lekin koi aap ke ${km} km ke andar nahi.`
                            : '. Jab tak seller apni service mein "GPS se lagayein" nahi dabata, wo map par nazar nahi aata.')] })), _jsx(LiveMap, { markers: markers, height: 420, circle: pos ? { lat: pos.lat, lng: pos.lng, km } : null, onMarkerClick: (id) => { const s = list.find((x) => x.id === id); if (s)
                    nav(`/seller-profile/${s.seller_id}`); }, onMapClick: (lat, lng) => { if (!pos)
                    setPos({ lat, lng }); } }), _jsx("p", { className: "small muted", style: { margin: '.5rem 0' }, children: "Sellers ki location approximate hoti hai. Kisi seller par tap karein to us ka profile khulega." }), pos && !loading && list.length === 0 && (_jsx(Empty, { icon: "pin", title: `${km} km mein koi seller nahi`, text: "Doori barha kar dekhein (10 km) ya sellers ki list dekhein." })), _jsx("div", { className: "list", children: list.map((s) => (_jsx(Link, { to: `/seller-profile/${s.seller_id}`, className: "card link", children: _jsxs("div", { className: "row", children: [_jsx("div", { className: "seller-ic", children: s.seller_name.charAt(0).toUpperCase() }), _jsxs("div", { className: "grow", children: [_jsxs("div", { className: "row between", children: [_jsx("b", { children: s.seller_name }), _jsxs("span", { className: "chip green", children: [s.distance_km.toFixed(1), " km"] })] }), _jsx("div", { className: "small", style: { color: 'var(--ink2)' }, children: s.title }), _jsxs("div", { className: "small muted", children: [money(s.price), " ", s.price_unit, s.experience_years > 0 ? ` · ${s.experience_years} saal tajurba` : ''] })] })] }) }, s.id))) }), gate && (_jsx("div", { className: "modal-bg", onClick: () => !asking && setGate(false), children: _jsxs("div", { className: "modal", onClick: (e) => e.stopPropagation(), children: [_jsx("div", { className: "ic-box", style: { width: 56, height: 56, borderRadius: 18, marginBottom: '.7rem' }, children: _jsx(Icon, { name: "pin", size: 28 }) }), _jsx("h2", { children: "Apni location allow karein" }), _jsxs("p", { className: "muted", children: ["Taake aap ke 5 km ke andar ke ", service.name, " sellers map par dikhaye ja sakein. Aap ki location kisi seller ko nahi dikhai jati."] }), err && _jsx(Notice, { kind: "error", children: err }), (perm === 'denied' || err.includes('mana kar di')) && (_jsxs("div", { className: "notice warn", style: { display: 'block' }, children: [_jsx("b", { children: "Chrome ne is site ke liye \"Block\" yaad rakha hua hai." }), " Ab wo dobara nahi poochega. Aise theek karein:", _jsxs("ol", { style: { margin: '.4rem 0 0', paddingLeft: '1.2rem' }, children: [_jsxs("li", { children: ["Address bar mein site ke naam ke saath ", _jsx("b", { children: "lock" }), " (ya ", _jsx("b", { children: "\u2699" }), ") icon par tap karein."] }), _jsxs("li", { children: [_jsx("b", { children: "Permissions" }), " (Ijazatein) > ", _jsx("b", { children: "Location" }), " > ", _jsx("b", { children: "Allow" }), " chunein (ya ", _jsx("b", { children: "Reset permission" }), " dabayein)."] }), _jsx("li", { children: "Page ko dobara kholein (refresh) aur \"Location allow karein\" dabayein." }), _jsxs("li", { children: ["Phir bhi na chale: Phone ", _jsx("b", { children: "Settings > Apps > Chrome > Permissions > Location > Allow" }), "."] })] })] })), _jsxs("div", { className: "stack", style: { marginTop: '.8rem' }, children: [_jsxs("button", { className: "btn primary block xl", onClick: ask, disabled: asking, children: [_jsx(Icon, { name: "pin", size: 20 }), " ", asking ? 'Browser se pooch rahe hain...' : 'Location allow karein'] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Ya apna shehar chunein" }), _jsxs("select", { className: "input", defaultValue: "", onChange: (e) => { const c = CITY_COORDS[e.target.value]; if (c) {
                                                setPos({ lat: c[0], lng: c[1] });
                                                setGate(false);
                                            } }, children: [_jsx("option", { value: "", disabled: true, children: "Shehar chunein..." }), Object.keys(CITY_COORDS).map((c) => _jsx("option", { value: c, children: c }, c))] })] }), (err || inFrame()) && _jsx("button", { className: "btn block", onClick: openInNewTab, children: "Alag tab mein kholein (location ke liye)" }), _jsx("button", { className: "btn ghost block", onClick: () => setGate(false), disabled: asking, children: "Map par khud tap karoonga" }), _jsxs("p", { className: "small muted", style: { margin: 0 }, children: ["Jaanch: HTTPS ", window.isSecureContext ? 'haan' : 'nahi', " \u00B7 Frame ", inFrame() ? 'haan' : 'nahi', " \u00B7 Ijazat ", perm] })] })] }) }))] }));
}
