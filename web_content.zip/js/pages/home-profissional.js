(function(){
  const sessao = Auth.exigirPerfil('profissional');
  if(!sessao) return;
  aplicarSessaoNoCabecalho();

  let provider = ProvidersService.obterPorUsuario(sessao.id);

  const ICONE_CATEGORIA = {
    [CATEGORIAS_SERVICO.LIMPEZA]: 'sparkles',
    [CATEGORIAS_SERVICO.REPAROS]: 'wrench',
    [CATEGORIAS_SERVICO.ENXOVAL]: 'bed',
  };

  const mapaStatusAprovacao = {
    PENDENTE: ['Pendente', 'pendente'],
    ENVIADO: ['Pendente', 'pendente'],
    EM_ANALISE: ['Em análise', 'pendente'],
    APROVADO: ['Aprovado', 'ativo'],
    REJEITADO: ['Não aprovado', 'inativo'],
  };

  function renderCabecalho(){
    provider = ProvidersService.obterPorUsuario(sessao.id);
    const r = ProvidersService.resumoPublico(provider.id);

    document.getElementById('perfilAvatarFoto').src = provider.selfie || '';
    document.getElementById('perfilNome').innerText = r.nome;
    document.getElementById('perfilId').innerText = String(provider.id).padStart(5,'0');

    const [txtAprov, classeAprov] = mapaStatusAprovacao[provider.status_aprovacao] || mapaStatusAprovacao.PENDENTE;
    const badge = document.getElementById('perfilBadgeAprovacao');
    badge.innerText = txtAprov;
    badge.className = 'badge-status ' + classeAprov;

    const categoriaPrincipal = (provider.categorias || [])[0];
    document.getElementById('perfilCategoria').innerText = (provider.categorias || []).join(', ') || 'Categoria não definida';
    document.getElementById('perfilIconeCategoria').setAttribute('data-lucide', ICONE_CATEGORIA[categoriaPrincipal] || 'wrench');

    const linhaCidade = document.getElementById('perfilCidadeLinha');
    if(provider.cidade){
      linhaCidade.classList.remove('hidden');
      document.getElementById('perfilCidade').innerText = provider.cidade;
    } else {
      linhaCidade.classList.add('hidden');
    }

    document.getElementById('perfilCpf').innerText = formatarCpf(provider.cpf);

    const elClass = document.getElementById('perfilClassificacao');
    elClass.innerHTML = r.temHistorico
      ? `★ ${r.reputacao.toFixed(1)} <span class="text-muted font-normal">(${r.qtdAvaliacoes} avaliações)</span>`
      : `<span class="text-muted font-normal" style="color:var(--muted)">Novo profissional</span>`;

    refreshIcons();
  }
  renderCabecalho();

  document.getElementById('btnQrCode').addEventListener('click', () => {
    mostrarToast('QR Code em breve — recurso ainda não disponível nesta fase de testes.');
  });

  // ---------- Resumo de serviços (disponíveis/aceitos/em execução/concluídos) ----------
  function renderResumoServicos(){
    const disponiveis = DB.list('service_requests', s => s.status === STATUS_SOLICITACAO.PUBLISHED && provider.categorias.includes(s.categoria)).length;
    const aceitos = DB.list('service_requests', s => s.accepted_provider_id === provider.id && [STATUS_SOLICITACAO.ACCEPTED, STATUS_SOLICITACAO.TRAVELING, STATUS_SOLICITACAO.ARRIVED].includes(s.status)).length;
    const emExecucao = DB.list('service_requests', s => s.accepted_provider_id === provider.id && [STATUS_SOLICITACAO.CHECKING, STATUS_SOLICITACAO.IN_PROGRESS, STATUS_SOLICITACAO.UNDER_REVIEW, STATUS_SOLICITACAO.DISPUTED].includes(s.status)).length;
    const concluidos = ProvidersService.contarServicosConcluidos(provider.id);
    document.getElementById('resDisponiveis').innerText = disponiveis;
    document.getElementById('resAceitos').innerText = aceitos;
    document.getElementById('resExecucao').innerText = emExecucao;
    document.getElementById('resConcluidos').innerText = concluidos;
  }
  renderResumoServicos();

  // ---------- Serviço atual + demais serviços aceitos ----------
  const ROTULO_STATUS_SERVICO = {
    ACCEPTED:['Aceito — iniciar deslocamento','verificado'], TRAVELING:['A caminho','verificado'], ARRIVED:['Chegou','verificado'],
    CHECKING:['Em conferência','pendente'], IN_PROGRESS:['Em andamento','pendente'], UNDER_REVIEW:['Aguardando anfitrião','pendente'],
    DISPUTED:['Em disputa','inativo'], COMPLETED:['Concluído','ativo'],
  };

  function cartaoServico(s, destaque){
    const imovel = DB.find('properties', s.property_id);
    const [txt, classe] = ROTULO_STATUS_SERVICO[s.status] || [s.status,'inativo'];
    const acao = s.status !== 'COMPLETED'
      ? `<a href="execucao.html?id=${s.id}" class="btn-primary w-full py-2.5 rounded-lg text-[12.5px] mt-2 block text-center">Abrir execução</a>`
      : `<a href="chat.html?id=${s.id}" class="w-full py-2.5 rounded-lg text-[12.5px] mt-2 block text-center border" style="border-color:var(--linha)">Ver chat</a>`;
    const icone = ICONE_CATEGORIA[s.categoria] || 'wrench';
    return `
      <div class="card-soft p-4">
        <div class="flex justify-between items-center mb-3">
          <p class="font-semibold text-[13px] flex items-center gap-1.5"><i data-lucide="${destaque ? 'wrench' : 'briefcase'}" style="width:15px;height:15px;color:var(--azul)"></i> ${destaque ? 'Serviço atual' : s.categoria}</p>
          <span class="badge-status ${classe}">${txt}</span>
        </div>
        <div class="flex items-center gap-3">
          <div class="stat-icon-square" style="background:var(--azul-escuro); margin:0"><i data-lucide="${icone}"></i></div>
          <div class="flex-1 min-w-0">
            ${destaque ? `<p class="font-bold text-[14px]">${s.categoria}</p>` : ''}
            <p class="text-[11.5px] text-muted flex items-center gap-1"><i data-lucide="map-pin" class="icon-inline"></i>${imovel ? imovel.nome+' — '+imovel.bairro : 'Imóvel não encontrado'}</p>
            <p class="text-[11.5px] text-muted flex items-center gap-1"><i data-lucide="calendar" class="icon-inline"></i>${formatarData(s.data)} · ${s.horario}</p>
          </div>
        </div>
        ${acao}
      </div>`;
  }

  function renderServicos(){
    const meus = DB.list('service_requests', s => s.accepted_provider_id === provider.id && !['DRAFT','PUBLISHED','CANCELLED'].includes(s.status))
      .sort((a,b)=> new Date(b.accepted_at||b.created_at) - new Date(a.accepted_at||a.created_at));

    const atual = document.getElementById('servicoAtualWrap');
    const outros = document.getElementById('outrosServicosWrap');

    if(meus.length === 0){
      atual.innerHTML = `<div class="empty-state card-soft"><i data-lucide="briefcase"></i><p>Nenhum serviço aceito ainda.</p></div>`;
      outros.innerHTML = '';
      refreshIcons();
      return;
    }

    const emAndamento = meus.find(s => s.status !== 'COMPLETED');
    const destaque = emAndamento || meus[0];
    atual.innerHTML = cartaoServico(destaque, true);

    const restantes = meus.filter(s => s.id !== destaque.id);
    outros.innerHTML = restantes.length
      ? `<p class="text-[12px] font-semibold text-muted mb-1">Outros serviços</p>` + restantes.map(s => cartaoServico(s, false)).join('')
      : '';

    refreshIcons();
  }
  renderServicos();

  // ---------- Sobre mim / experiência (expansível, edição só da descrição) ----------
  document.getElementById('provDescricao').value = provider.descricao || '';
  if(provider.descricao) document.getElementById('sobreMimPreview').innerText = provider.descricao;

  const formSobreMim = document.getElementById('formProvider');
  const btnToggle = document.getElementById('btnToggleSobreMim');
  btnToggle.addEventListener('click', () => {
    const aberto = !formSobreMim.classList.contains('hidden');
    formSobreMim.classList.toggle('hidden', aberto);
    document.getElementById('chevSobreMim').setAttribute('data-lucide', aberto ? 'chevron-right' : 'chevron-down');
    refreshIcons();
  });

  formSobreMim.addEventListener('submit', function(e){
    e.preventDefault();
    const descricao = document.getElementById('provDescricao').value.trim();
    ProvidersService.atualizarPerfil(sessao.id, { descricao });
    mostrarToast('Perfil profissional atualizado!');
    provider = ProvidersService.obterPorUsuario(sessao.id);
    document.getElementById('sobreMimPreview').innerText = descricao || 'Foto e categoria de atuação são definidas apenas no cadastro e não podem ser alteradas aqui.';
    formSobreMim.classList.add('hidden');
    document.getElementById('chevSobreMim').setAttribute('data-lucide', 'chevron-right');
    refreshIcons();
  });

  // ---------- Prévia da seção Documentos (visualização fica em documentos-profissional.html) ----------
  const qtdEnviados = ProvidersService.TIPOS_DOCUMENTO.filter(t => provider.documentos[t] && provider.documentos[t].status !== 'pendente').length;
  document.getElementById('docsPreview').innerText = qtdEnviados > 0
    ? `${qtdEnviados} documento${qtdEnviados === 1 ? '' : 's'} enviado${qtdEnviados === 1 ? '' : 's'} no cadastro.`
    : 'Nenhum documento enviado no cadastro.';

  // ---------- Indicador de notificações não lidas na aba Mensagens ----------
  const qtdNaoLidas = NotificationsService.naoLidas(sessao.id);
  document.getElementById('tabDotMsg').classList.toggle('hidden', qtdNaoLidas === 0);

  refreshIcons();
})();
