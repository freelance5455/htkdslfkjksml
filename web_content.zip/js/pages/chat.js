(function(){
  const sessao = Auth.exigirLogin();
  if(!sessao) return;

  const params = new URLSearchParams(window.location.search);
  const requestId = Number(params.get('id'));
  const solicitacao = DB.find('service_requests', requestId);

  if(!solicitacao){
    mostrarToast('Solicitação não encontrada.');
    setTimeout(()=> window.history.back(), 800);
    return;
  }

  const imovel = DB.find('properties', solicitacao.property_id);
  document.getElementById('chatTitulo').innerText = solicitacao.categoria;
  document.getElementById('chatSubtitulo').innerText = imovel ? `${imovel.nome} — ${imovel.bairro}, ${imovel.cidade}` : '';

  let anexoPendente = null; // { tipo, nome, dataUrl }

  function tipoAnexo(file){
    if(file.type.startsWith('image/')) return 'foto';
    if(file.type.startsWith('video/')) return 'video';
    return 'documento';
  }

  document.getElementById('btnAnexar').addEventListener('click', () => document.getElementById('inputAnexo').click());
  document.getElementById('inputAnexo').addEventListener('change', function(e){
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      anexoPendente = { tipo: tipoAnexo(file), nome: file.name, dataUrl: ev.target.result };
      mostrarToast('Anexo pronto — escreva uma legenda (opcional) e envie.');
    };
    reader.readAsDataURL(file);
  });

  function bolha(msg){
    const ehSistema = msg.tipo === 'sistema';
    const ehMinha = msg.remetente_id === sessao.id;
    const classe = ehSistema ? 'system' : (ehMinha ? 'mine' : 'theirs');
    let mediaHtml = '';
    (msg.anexos || []).forEach(a => {
      if(a.tipo === 'foto') mediaHtml += `<img src="${a.dataUrl}">`;
      else if(a.tipo === 'video') mediaHtml += `<video src="${a.dataUrl}" controls style="max-width:100%;border-radius:10px;margin-top:6px"></video>`;
      else mediaHtml += `<div class="flex items-center gap-1 mt-1 text-[11.5px]"><i data-lucide="file-text" class="icon-inline"></i>${a.nome}</div>`;
    });
    return `<div class="chat-bubble ${classe}">${msg.texto ? msg.texto : ''}${mediaHtml}</div>`;
  }

  function render(){
    const mensagens = ChatService.listarPorSolicitacao(requestId);
    const cont = document.getElementById('chatMensagens');
    cont.innerHTML = mensagens.map(bolha).join('');
    cont.scrollTop = cont.scrollHeight;
    refreshIcons();
  }

  function enviar(){
    const texto = document.getElementById('chatTexto').value.trim();
    if(!texto && !anexoPendente) return;

    try{
      ChatService.enviarMensagem(sessao.id, requestId, {
        tipo: anexoPendente ? anexoPendente.tipo : 'texto',
        texto,
        anexos: anexoPendente ? [anexoPendente] : [],
      });
      document.getElementById('chatTexto').value = '';
      anexoPendente = null;
      render();
    }catch(err){
      if(err.bloqueado){
        mostrarToast(err.message);
      } else {
        mostrarToast(err.message || 'Não foi possível enviar a mensagem.');
      }
    }
  }

  document.getElementById('btnEnviar').addEventListener('click', enviar);
  document.getElementById('chatTexto').addEventListener('keydown', (e) => { if(e.key === 'Enter') enviar(); });

  try{
    ChatService._garantirParticipante(sessao.id, solicitacao);
    render();
  }catch(err){
    document.getElementById('chatMensagens').innerHTML = `<p class="text-center text-[13px] text-muted py-10">${err.message}</p>`;
    document.querySelector('.chat-input-bar').classList.add('hidden');
  }
})();
