/* =============================================================
   LAMPION POS · js/pages/dashboard.js  (pengganti index.php)
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function money(n) { return PHP.money(n); }
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  function renderBarChart(days) {
    var max = 1;
    days.forEach(function (d) { max = Math.max(max, Number(d.total) || 0); });
    $('bar-chart').innerHTML = days.map(function (d) {
      var t = Number(d.total) || 0;
      var h = Math.max(3, Math.round((t / max) * 150));
      return '<div class="bar-col">' +
        '<div class="bar' + (t <= 0 ? ' bar-empty' : '') + '" style="height:' + h + 'px">' +
        '<span class="tip">' + money(t) + '</span></div>' +
        '<span class="bar-label">' + esc(d.label) + '</span></div>';
    }).join('');
  }

  function renderTop(list) {
    var host = $('top-menus');
    if (!list || list.length === 0) {
      host.innerHTML = '<div class="empty-state"><b>Belum ada data</b>' +
        'Proses order pertama di Kasir.</div>';
      return;
    }
    var max = 1;
    list.forEach(function (t) { max = Math.max(max, Number(t.qty) || 0); });
    host.innerHTML = '<ol class="top-menu">' + list.map(function (t, i) {
      var pct = Math.round(((Number(t.qty) || 0) / max) * 100);
      return '<li>' +
        '<span class="rank' + (i === 0 ? ' r1' : '') + '">' + (i + 1) + '</span>' +
        '<span style="flex:none;min-width:110px;font-weight:650">' + esc(t.item_name) + '</span>' +
        '<span class="bar-bg"><span class="bar-fill" style="width:' + pct + '%"></span></span>' +
        '<b class="m-right">&times;' + (Number(t.qty) || 0) + '</b>' +
        '</li>';
    }).join('') + '</ol>';
  }

  function renderPayments(list) {
    var host = $('payments');
    if (!list || list.length === 0) {
      host.innerHTML = '<div class="empty-state"><b>Belum ada pembayaran</b></div>';
      return;
    }
    host.innerHTML = '<dl class="kv">' + list.map(function (p) {
      return '<div class="kv-row"><dt>' + esc(p.label) + '</dt>' +
        '<dd>' + money(p.total) + ' <small class="text-muted">(' +
        (Number(p.cnt) || 0) + ')</small></dd></div>';
    }).join('') + '</dl>';
  }

  function renderRecent(list) {
    var host = $('recent');
    if (!list || list.length === 0) {
      host.innerHTML = '<div class="empty-state"><b>Belum ada transaksi</b>' +
        'Proses order pertama di Kasir.</div>';
      return;
    }
    var tl = LPDB.ORDER_TYPE_LABEL;
    host.innerHTML = '<ul class="mini-list">' + list.map(function (o) {
      return '<li>' +
        '<span class="m-main"><b>' + esc(o.order_number) + ' &middot; ' +
        esc(tl[o.order_type] || o.order_type) + '</b>' +
        '<small>' + esc(o.cashier) + ' &middot; ' +
        esc(String(o.created_at).slice(11, 16)) + '</small></span>' +
        '<span class="m-right">' + money(o.total) + '</span>' +
        '</li>';
    }).join('') + '</ul>';
  }

  function load() {
    return LP.api('api/dashboard.php', { method: 'GET' }).then(function (res) {
      $('s-sales').textContent = money(res.today.sales);
      $('s-tx').textContent = res.today.tx;
      $('s-avg').textContent = money(res.today.avg_tx);
      $('s-items').textContent = res.today.items;
      renderBarChart(res.days || []);
      renderTop(res.top_menus || []);
      renderPayments(res.payments || []);
      renderRecent(res.recent || []);
    }).catch(function (e) {
      LP.toast('Gagal memuat ringkasan: ' + e.message, 'err', 6000);
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('dashboard.view', function () {
      LPUI.mountChrome('index.html');
      $('dash-date').textContent = LPDB.longDate();
      $('btn-refresh').addEventListener('click', load);

      /* padanan auto-refresh 90s di index.php lama */
      setInterval(load, 90000);
      load();
    });
  });
})();
