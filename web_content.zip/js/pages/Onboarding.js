import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { CITIES, validPhone } from '../lib/util.js';
import { Notice } from '../components/Bits.js';
import Icon from '../components/Icon.js';
export default function Onboarding() {
    const { profile, contact, session, refresh, signOut } = useAuth();
    const nav = useNavigate();
    const [role, setRole] = useState(profile?.role ?? null);
    const [name, setName] = useState(profile?.full_name || session?.user.user_metadata?.full_name || '');
    const [phone, setPhone] = useState(contact?.phone || '');
    const [city, setCity] = useState(contact?.city || '');
    const [address, setAddress] = useState(contact?.address || '');
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);
    if (profile?.onboarded)
        return _jsx(Navigate, { to: "/", replace: true });
    const ok = !!role && name.trim().length >= 2 && validPhone(phone) && city.trim() && address.trim().length >= 5;
    async function submit(e) {
        e.preventDefault();
        if (!ok || !profile)
            return;
        setBusy(true);
        setErr('');
        const c = await supabase.from('private_contacts').upsert({
            user_id: profile.id, email: session?.user.email ?? null,
            phone: phone.trim(), city: city.trim(), address: address.trim(), updated_at: new Date().toISOString(),
        });
        if (c.error) {
            setBusy(false);
            return setErr(c.error.message);
        }
        const p = await supabase.from('profiles').update({
            full_name: name.trim(), ...(profile.role ? {} : { role }), onboarded: true,
        }).eq('id', profile.id);
        if (p.error) {
            setBusy(false);
            return setErr(p.error.message);
        }
        localStorage.removeItem('udaan_role');
        await refresh();
        setBusy(false);
        nav('/', { replace: true });
    }
    return (_jsxs("div", { className: "auth-wrap", children: [_jsx("h2", { children: "Profile mukammal karein" }), _jsxs(Notice, { kind: "info", children: ["Aap ka phone number aur address ", _jsx("b", { children: "dusre users ko kabhi nahi dikhaye jate" }), ". Sirf Udaan admin dekh sakta hai, taake deal approve hone par aap se rabta kar sake."] }), _jsxs("form", { className: "stack", onSubmit: submit, children: [!profile?.role && (_jsxs("div", { className: "roles", children: [_jsxs("button", { type: "button", className: `role ${role === 'buyer' ? 'on' : ''}`, onClick: () => setRole('buyer'), children: [_jsx("span", { className: "e", children: _jsx(Icon, { name: "cart", size: 22 }) }), _jsx("b", { children: "Buyer" })] }), _jsxs("button", { type: "button", className: `role ${role === 'seller' ? 'on' : ''}`, onClick: () => setRole('seller'), children: [_jsx("span", { className: "e", children: _jsx(Icon, { name: "briefcase", size: 22 }) }), _jsx("b", { children: "Seller" })] })] })), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Poora naam" }), _jsx("input", { className: "input", value: name, onChange: (e) => setName(e.target.value) })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Phone number" }), _jsx("input", { className: "input", inputMode: "tel", placeholder: "03XX XXXXXXX", value: phone, onChange: (e) => setPhone(e.target.value) })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Shehar" }), _jsx("input", { className: "input", list: "cities", value: city, onChange: (e) => setCity(e.target.value) }), _jsx("datalist", { id: "cities", children: CITIES.map((c) => _jsx("option", { value: c }, c)) })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Poora address / location" }), _jsx("textarea", { className: "input", value: address, onChange: (e) => setAddress(e.target.value), placeholder: "Ghar / dukan number, mohalla, area" })] }), err && _jsx(Notice, { kind: "error", children: err }), _jsx("button", { className: "btn primary block", disabled: !ok || busy, children: busy ? 'Save ho raha hai...' : 'Aage barhein' }), _jsx("button", { type: "button", className: "btn ghost block", onClick: signOut, children: "Logout" })] })] }));
}
