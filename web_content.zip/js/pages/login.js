(function(){
  document.getElementById('formLogin').addEventListener('submit', async function(e){
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const senha = document.getElementById('loginSenha').value;
    const erroEl = document.getElementById('erroLogin');
    erroEl.classList.remove('show'); erroEl.innerText='';

    const btn = document.getElementById('btnLogin');
    btn.disabled = true; btn.innerText = 'Entrando...';
    try{
      const usuario = await Auth.login(email, senha);
      window.location.href = homeDoPerfil(usuario.tipo_usuario);
    }catch(err){
      erroEl.innerText = err.message; erroEl.classList.add('show');
      btn.disabled = false; btn.innerText = 'Entrar';
    }
  });
})();
