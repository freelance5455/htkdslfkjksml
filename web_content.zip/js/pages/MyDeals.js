import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { fmtDate, money } from '../lib/util.js';
import { Avatar, Empty, ListSkeleton, StatusChip } from '../components/Bits.js';
export default function MyDeals() {
    const { profile } = useAuth();
    const [deals, setDeals] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        if (!profile)
            return;
        supabase.from('deals')
            .select('*, buyer:profiles!deals_buyer_id_fkey(full_name), seller:profiles!deals_seller_id_fkey(full_name)')
            .or(`buyer_id.eq.${profile.id},seller_id.eq.${profile.id}`)
            .order('updated_at', { ascending: false })
            .then(({ data }) => { setDeals(data || []); setLoading(false); });
    }, [profile]);
    return (_jsxs(_Fragment, { children: [_jsx("h2", { style: { marginBottom: '.9rem' }, children: "Meri deals" }), loading ? _jsx(ListSkeleton, { n: 3, h: 88 }) : deals.length === 0 ? (_jsx(Empty, { icon: "chat", title: "Abhi koi baat-cheet nahi", text: profile?.role === 'seller' ? 'Jab koi buyer aap se baat shuru karega yahan nazar aayega.' : 'Kisi service mein seller chun kar baat shuru karein.' })) : (_jsx("div", { className: "list", children: deals.map((d) => {
                    const other = d.buyer_id === profile?.id ? d.seller?.full_name : d.buyer?.full_name;
                    return (_jsx(Link, { to: `/deal/${d.id}`, className: "card link", children: _jsxs("div", { className: "row", children: [_jsx(Avatar, { name: other, size: "lg" }), _jsxs("div", { className: "grow", children: [_jsxs("div", { className: "row between", children: [_jsx("b", { children: other || 'User' }), _jsx(StatusChip, { status: d.status })] }), _jsx("div", { className: "clamp small", style: { color: 'var(--ink2)' }, children: d.listing_title }), _jsxs("div", { className: "small muted", children: [d.agreed_price ? `Tay shuda ${money(d.agreed_price)}` : `Listed ${money(d.listing_price)}`, " \u00B7 ", fmtDate(d.updated_at)] })] })] }) }, d.id));
                }) }))] }));
}
