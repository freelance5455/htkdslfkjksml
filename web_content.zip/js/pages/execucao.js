(function(){
  const sessao = Auth.exigirPerfil('profissional');
  if(!sessao) return;

  const params = new URLSearchParams(window.location.search);
  const requestId = Number(params.get('id'));
  const provider = ProvidersService.obterPorUsuario(sessao.id);
  let fotosDivergencia = [];
  let fotosFinalizar = [];
  let motivoSelecionado = null;

  function obterSolicitacao(){
    const s = DB.find('service_requests', requestId);
    if(!s || s.accepted_provider_id !== provider.id){ return null; }
    return s;
  }

  if(!obterSolicitacao()){
    mostrarToast('Você não tem acesso a esta solicitação.');
    setTimeout(()=> window.location.href = 'home-profissional.html', 800);
    return;
  }

  document.getElementById('linkChat').href = 'chat.html?id=' + requestId;

  const ETAPAS = [
    { status:'ACCEPTED', label:'Aceito' },
    { status:'TRAVELING', label:'A caminho' },
    { status:'ARRIVED', label:'Chegou' },
    { status:'CHECKING', label:'Conferência' },
    { status:'IN_PROGRESS', label:'Em execução' },
    { status:'UNDER_REVIEW', label:'Aguardando confirmação' },
    { status:'COMPLETED', label:'Concluído' },
  ];

  function renderCabecalho(s){
    const imovel = DB.find('properties', s.property_id);
    const pagamento = PaymentsService.obterPorSolicitacao(requestId);
    const rotuloStatus = {
      ACCEPTED:'Aceito', TRAVELING:'A caminho', ARRIVED:'Chegou ao imóvel', CHECKING:'Em conferência',
      IN_PROGRESS:'Em execução', UNDER_REVIEW:'Aguardando confirmação', DISPUTED:'Em disputa',
      COMPLETED:'Concluído', CANCELLED:'Cancelado',
    };
    document.getElementById('cabecalhoExecucao').innerHTML = `
      <div class="flex items-center justify-between mb-2">
        <p class="font-bold text-[15px]">${s.categoria}</p>
        <span class="badge-status ${s.status==='DISPUTED'?'inativo':'verificado'}">${rotuloStatus[s.status]||s.status}</span>
      </div>
      <p class="text-[12.5px] text-muted mb-1">${imovel ? imovel.nome+' — '+imovel.endereco+', '+imovel.bairro : ''}</p>
      <p class="text-[12.5px] text-muted mb-2">${formatarData(s.data)} às ${s.horario} · ${s.urgencia}</p>
      ${pagamento ? `<p class="text-[13px] font-bold" style="color:var(--verde-escuro)">Você recebe: R$ ${(pagamento.valor_profissional - (pagamento.taxa_deslocamento_disponibilidade||0)).toFixed(2)}</p>` : `<p class="text-[12px]" style="color:var(--dourado-escuro)">Valor a definir (necessita avaliação)</p>`}
    `;
  }

  function renderTimeline(s){
    const idxAtual = ETAPAS.findIndex(e => e.status === s.status);
    const cont = document.getElementById('timeline');
    if(s.status === 'DISPUTED'){
      cont.innerHTML = `<div class="geo-banner"><i data-lucide="alert-triangle"></i><span>Serviço em disputa. O pagamento permanece protegido até a decisão. Acompanhe pelo chat.</span></div>`;
      refreshIcons();
      return;
    }
    cont.innerHTML = ETAPAS.map((e,i) => {
      const done = idxAtual > i || s.status === 'COMPLETED';
      const current = idxAtual === i;
      return `
        <div class="timeline-step">
          <div>
            <div class="timeline-dot ${done?'done':(current?'current':'')}">${done ? '<i data-lucide=\"check\" style=\"width:14px;height:14px\"></i>' : (i+1)}</div>
            ${i < ETAPAS.length-1 ? '<div class="timeline-line"></div>' : ''}
          </div>
          <p class="text-[12.5px] ${current?'font-bold':''} ${done||current?'':'text-muted'}" style="padding-top:4px">${e.label}</p>
        </div>`;
    }).join('');
    refreshIcons();
  }

  function pegarPosicao(){
    return GeoLocation.obterPosicaoAtual().catch(err => { mostrarToast(err.message); return null; });
  }

  /**
   * EMULADOR DE LOCALIZAÇÃO — exclusivo do Ambiente DEV.
   * Permite ao profissional alternar entre GPS real e uma posição simulada
   * (lat/lng manuais ou "colocar no imóvel") para testar o fluxo de
   * deslocamento/chegada sem depender de GPS físico. A MESMA função de
   * distância/raio (distanciaKm + TOLERANCIA_CHEGADA_KM) é usada tanto para
   * GPS real quanto para a simulação — nenhuma regra de negócio é
   * flexibilizada, só a origem da coordenada. Em produção (ENV=prod) este
   * emulador fica completamente desativado: só GPS real é aceito.
   */
  const DEV = window.APP_CONFIG.ENV === 'dev';
  let modoSimulado = false;
  let posSimulada = { lat: null, lng: null };

  /**
   * ---------- Mapa de deslocamento/chegada (ETAPA 4) ----------
   * Integra o mapa (Leaflet, mesmo padrão do Mapa de Oportunidades) ao fluxo
   * ACCEPTED → TRAVELING → ARRIVED: mostra a acomodação e a posição do
   * profissional (GPS real via watchPosition, ou a posição simulada do
   * emulador DEV) em tempo real, com distância atual e um botão de navegação
   * externa. Não substitui nem flexibiliza a validação real do raio de
   * chegada (registrarChegada, em serviceRequestsService.js) — é só a
   * camada visual.
   */
  const mapaExecIndisponivel = typeof L === 'undefined';
  let mapaExec = null;
  let marcadorEuExec = null;
  let marcadorImovelExec = null;
  let circuloRaioExec = null;
  let watchIdExec = null;

  function blocoMapaExecucao(){
    if(mapaExecIndisponivel){
      return `<div class="empty-state card-soft mb-3"><i data-lucide="map-off"></i><p>Não foi possível carregar o mapa (conexão instável). As informações de distância abaixo continuam funcionando.</p></div>
        <div id="distanciaExecBanner" class="distancia-exec-banner"><span>Distância até a acomodação</span><span>—</span></div>`;
    }
    return `
      <div class="map-wrap-exec"><div id="mapaExecucao"></div></div>
      <div id="distanciaExecBanner" class="distancia-exec-banner"><span>Distância até a acomodação</span><span>—</span></div>
      <button type="button" id="btnIniciarNavegacao" class="btn-navegacao"><i data-lucide="navigation"></i> Iniciar navegação</button>`;
  }

  function pararRastreioExec(){
    if(watchIdExec != null){ GeoLocation.pararObservacao(watchIdExec); watchIdExec = null; }
  }

  function limparMapaExec(){
    pararRastreioExec();
    if(mapaExec){ mapaExec.remove(); mapaExec = null; marcadorEuExec = null; marcadorImovelExec = null; circuloRaioExec = null; }
  }
  window.addEventListener('beforeunload', pararRastreioExec);

  function iniciarMapaExecucao(imovel){
    if(mapaExecIndisponivel) return;
    if(!imovel || imovel.latitude == null || imovel.longitude == null){
      const wrap = document.querySelector('.map-wrap-exec');
      if(wrap) wrap.outerHTML = `<div class="empty-state card-soft mb-3"><i data-lucide="map-off"></i><p>Este imóvel ainda não tem coordenadas cadastradas — mapa indisponível.</p></div>`;
      refreshIcons();
      return;
    }
    mapaExec = L.map('mapaExecucao', { zoomControl:false }).setView([imovel.latitude, imovel.longitude], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution:'© OpenStreetMap', maxZoom:18 }).addTo(mapaExec);
    const iconImovel = L.divIcon({ className:'', html:`<div class="marker-pin-imovel"><i data-lucide="home"></i></div>`, iconSize:[30,30], iconAnchor:[15,30] });
    marcadorImovelExec = L.marker([imovel.latitude, imovel.longitude], { icon: iconImovel }).addTo(mapaExec).bindTooltip('Acomodação');
    circuloRaioExec = L.circle([imovel.latitude, imovel.longitude], {
      radius: window.APP_CONFIG.TOLERANCIA_CHEGADA_KM * 1000,
      color: '#1856D6', weight: 1, fillColor: '#1856D6', fillOpacity: 0.08,
    }).addTo(mapaExec);
    refreshIcons();
  }

  function atualizarBannerDistanciaExec(pos, imovel, simulado){
    const el = document.getElementById('distanciaExecBanner');
    if(!el) return;
    if(!imovel || imovel.latitude == null || imovel.longitude == null){
      el.innerHTML = `<span>Distância até a acomodação</span><span>indisponível (imóvel sem coordenadas)</span>`;
      return;
    }
    if(!pos){
      el.innerHTML = `<span>Distância até a acomodação</span><span>aguardando localização…</span>`;
      return;
    }
    const d = distanciaKm(pos.lat, pos.lng, imovel.latitude, imovel.longitude);
    const dentro = d != null && d <= window.APP_CONFIG.TOLERANCIA_CHEGADA_KM;
    el.innerHTML = `<span>Distância até a acomodação${simulado ? ' (simulada — DEV)' : ''}</span><b style="color:${dentro ? '#0E8F52' : 'var(--tinta)'}">${d != null ? d + ' km' : '—'}${dentro ? ' ✓ dentro do raio de 350 m' : ''}</b>`;
  }

  function atualizarPosicaoExec(pos, simulado, imovel){
    atualizarBannerDistanciaExec(pos, imovel, simulado);
    if(!mapaExec || !pos) return;
    const icon = L.divIcon({ className:'', html:`<div class="marker-pin-eu ${simulado ? 'simulado' : ''}"></div>`, iconSize:[20,20], iconAnchor:[10,10] });
    if(marcadorEuExec) mapaExec.removeLayer(marcadorEuExec);
    marcadorEuExec = L.marker([pos.lat, pos.lng], { icon, zIndexOffset: 1000 }).addTo(mapaExec)
      .bindTooltip(simulado ? 'Você (simulado — DEV)' : 'Você está aqui');
    if(imovel && imovel.latitude != null && imovel.longitude != null){
      mapaExec.fitBounds(L.latLngBounds([pos.lat, pos.lng], [imovel.latitude, imovel.longitude]), { padding: [36,36], maxZoom: 16 });
    }
  }

  function iniciarRastreioExec(imovel){
    pararRastreioExec();
    if(DEV && modoSimulado){
      // No modo simulado (DEV), a posição vem dos campos manuais do
      // emulador — não observamos o GPS real. Se já houver uma posição
      // simulada informada, refletimos ela no mapa imediatamente.
      if(posSimulada.lat != null && posSimulada.lng != null){
        atualizarPosicaoExec({ lat: posSimulada.lat, lng: posSimulada.lng, precisao: null }, true, imovel);
      } else {
        atualizarBannerDistanciaExec(null, imovel, true);
      }
      return;
    }
    if(!GeoLocation.SUPORTADO()){ atualizarBannerDistanciaExec(null, imovel, false); return; }
    watchIdExec = GeoLocation.observarPosicao({
      aoAtualizar: (pos) => atualizarPosicaoExec(pos, false, imovel),
      aoErro: () => atualizarBannerDistanciaExec(null, imovel, false),
    });
  }

  function ligarBotaoNavegacao(imovel){
    const btn = document.getElementById('btnIniciarNavegacao');
    if(!btn) return;
    if(!imovel || imovel.latitude == null || imovel.longitude == null){
      btn.disabled = true;
      return;
    }
    // Serviço externo de mapas (Google Maps) apenas com as coordenadas do
    // imóvel como destino — nenhum dado de contato (telefone/e-mail/nome)
    // do anfitrião ou morador é incluído na URL.
    btn.onclick = () => {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${imovel.latitude},${imovel.longitude}&travelmode=driving`;
      window.open(url, '_blank', 'noopener');
    };
  }

  function renderPainelLocalizacaoDev(imovel){
    if(!DEV) return '';
    return `
      <div class="card-soft mb-3" style="border:1px dashed var(--linha)">
        <div class="flex items-center justify-between mb-2">
          <p class="font-bold text-[12.5px]">🧪 Localização (somente ambiente DEV)</p>
          <label class="flex items-center gap-1 text-[12px]">
            <input type="checkbox" id="chkModoSimulado" ${modoSimulado?'checked':''}> Simular localização
          </label>
        </div>
        <div id="camposPosSimulada" style="${modoSimulado?'':'display:none'}">
          <div class="flex gap-2 mb-2">
            <input id="simLat" type="number" step="any" placeholder="Latitude" class="field-input" value="${posSimulada.lat ?? ''}">
            <input id="simLng" type="number" step="any" placeholder="Longitude" class="field-input" value="${posSimulada.lng ?? ''}">
          </div>
          <button type="button" id="btnColocarNoImovel" class="text-[12px] font-semibold underline">Colocar no imóvel</button>
        </div>
        <p class="text-[12px] mt-2" id="infoDistanciaDev"></p>
      </div>`;
  }

  function atualizarInfoDistanciaDev(imovel){
    const info = document.getElementById('infoDistanciaDev');
    if(!info) return;
    if(!(modoSimulado && posSimulada.lat != null && posSimulada.lng != null)){ info.innerText = ''; return; }
    if(!imovel || imovel.latitude == null || imovel.longitude == null){ info.innerText = 'Imóvel sem coordenadas cadastradas — distância indisponível.'; return; }
    const d = distanciaKm(posSimulada.lat, posSimulada.lng, imovel.latitude, imovel.longitude);
    const dentro = d <= window.APP_CONFIG.TOLERANCIA_CHEGADA_KM;
    info.innerHTML = `Distância até a acomodação: <b>${d} km</b> — ${dentro ? '<span style="color:#0E8F52">dentro do raio de 350 m ✓</span>' : '<span style="color:#C0392B">fora do raio de 350 m ✗</span>'}`;
  }

  function ligarPainelLocalizacaoDev(imovel){
    if(!DEV) return;
    const chk = document.getElementById('chkModoSimulado');
    if(!chk) return;
    chk.onchange = () => {
      modoSimulado = chk.checked;
      document.getElementById('camposPosSimulada').style.display = modoSimulado ? '' : 'none';
      atualizarInfoDistanciaDev(imovel);
      iniciarRastreioExec(imovel); // alterna entre GPS real e posição simulada no mapa/banner
    };
    const simLat = document.getElementById('simLat'), simLng = document.getElementById('simLng');
    const lerCampos = () => {
      posSimulada = { lat: simLat.value ? Number(simLat.value) : null, lng: simLng.value ? Number(simLng.value) : null };
      atualizarInfoDistanciaDev(imovel);
      if(modoSimulado && posSimulada.lat != null && posSimulada.lng != null){
        atualizarPosicaoExec({ lat: posSimulada.lat, lng: posSimulada.lng, precisao: null }, true, imovel);
      }
    };
    simLat.oninput = lerCampos;
    simLng.oninput = lerCampos;
    document.getElementById('btnColocarNoImovel').onclick = () => {
      if(!imovel || imovel.latitude == null || imovel.longitude == null){ mostrarToast('Este imóvel ainda não tem coordenadas cadastradas.'); return; }
      simLat.value = imovel.latitude;
      simLng.value = imovel.longitude;
      lerCampos();
    };
    atualizarInfoDistanciaDev(imovel);
  }

  /**
   * Retorna a posição atual a ser usada no fluxo — GPS real do navegador,
   * ou (somente DEV, quando o profissional ativou o modo simulado) a
   * posição simulada informada manualmente. Em produção, ignora qualquer
   * estado simulado remanescente e usa sempre GPS real.
   */
  async function obterPosicaoParaFluxo(){
    if(DEV && modoSimulado){
      if(posSimulada.lat == null || posSimulada.lng == null){
        mostrarToast('Informe latitude e longitude simuladas (ou use "Colocar no imóvel").');
        return { pos: null, simulado: true };
      }
      return { pos: { lat: posSimulada.lat, lng: posSimulada.lng, precisao: null }, simulado: true };
    }
    const pos = await pegarPosicao();
    return { pos, simulado: false };
  }

  async function renderAcao(s){
    const cont = document.getElementById('areaAcao');
    if(s.status !== 'ACCEPTED' && s.status !== 'TRAVELING') limparMapaExec();

    if(s.alteracao_pendente){
      cont.innerHTML = `
        <div class="geo-banner" style="background:#EAF1FD;color:var(--azul-escuro)">
          <i data-lucide="clock"></i>
          <span>Você propôs uma alteração ("${s.alteracao_pendente.motivo}") e está aguardando aprovação do anfitrião. Novo valor: R$ ${s.alteracao_pendente.precificacao_proposta.valorAnfitriao.toFixed(2)}.</span>
        </div>`;
      refreshIcons();
      return;
    }

    if(s.status === 'ACCEPTED'){
      const imovel = DB.find('properties', s.property_id);
      cont.innerHTML = blocoMapaExecucao() + renderPainelLocalizacaoDev(imovel) + `<button id="btnIniciarDeslocamento" class="btn-primary w-full py-4 rounded-2xl text-base flex items-center justify-center gap-2"><i data-lucide="car"></i> Iniciar deslocamento</button>`;
      refreshIcons();
      iniciarMapaExecucao(imovel);
      ligarBotaoNavegacao(imovel);
      ligarPainelLocalizacaoDev(imovel);
      iniciarRastreioExec(imovel);
      document.getElementById('btnIniciarDeslocamento').onclick = async () => {
        const { pos } = await obterPosicaoParaFluxo();
        ServiceRequestsService.iniciarDeslocamento(provider.id, requestId, pos);
        mostrarToast('Deslocamento iniciado!');
        montarTela();
      };
    }

    else if(s.status === 'TRAVELING'){
      const imovel = DB.find('properties', s.property_id);
      cont.innerHTML = blocoMapaExecucao() + renderPainelLocalizacaoDev(imovel) + `<button id="btnRegistrarChegada" class="btn-primary w-full py-4 rounded-2xl text-base flex items-center justify-center gap-2"><i data-lucide="map-pin"></i> Registrar chegada</button>`;
      refreshIcons();
      iniciarMapaExecucao(imovel);
      ligarBotaoNavegacao(imovel);
      ligarPainelLocalizacaoDev(imovel);
      iniciarRastreioExec(imovel);
      document.getElementById('btnRegistrarChegada').onclick = async () => {
        const { pos, simulado } = await obterPosicaoParaFluxo();
        if(!pos){ mostrarToast('Não foi possível confirmar sua localização. Tente novamente.'); return; }
        try{
          const r = ServiceRequestsService.registrarChegada(provider.id, requestId, pos, { simulado });
          pararRastreioExec();
          mostrarToast(simulado ? 'Chegada registrada (posição simulada — ambiente de testes).' : 'Chegada registrada!');
          montarTela();
        }catch(err){
          mostrarToast(err.message);
        }
      };
    }

    else if(s.status === 'ARRIVED' || s.status === 'CHECKING'){
      const run = ChecklistService.iniciarExecucao(provider.id, requestId, s.property_id);
      const pendentes = run.itens.filter(i => i.ok === null).length;
      const checklistPendente = !run.concluido;
      const termoEntradaAceito = TermsService.jaAceitou(sessao.id, 'vistoria_entrada', TERMO_VISTORIA_ENTRADA.versao, requestId);
      const podeIniciarFaxina = !checklistPendente && termoEntradaAceito;
      cont.innerHTML = `
        <button id="btnAbrirChecklist" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-3" style="border-color:var(--linha); color:var(--tinta)">
          Vistoria de entrada ${run.itens.length ? `(${run.itens.length - pendentes}/${run.itens.length})` : '(sem itens cadastrados no imóvel)'}${run.concluido ? ' ✓' : ''}
        </button>
        <button id="btnAbrirTermoEntrada" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-3" style="border-color:var(--linha); color:var(--tinta)" ${checklistPendente ? 'disabled style="opacity:.5;pointer-events:none"' : ''}>
          Termo de responsabilidade da vistoria${termoEntradaAceito ? ' ✓' : ''}
        </button>
        ${checklistPendente ? `<p class="text-[12px] text-center mb-3" style="color:var(--dourado-escuro)">Conclua a vistoria de entrada (com vídeo e observações) para liberar o termo.</p>` : (!termoEntradaAceito ? `<p class="text-[12px] text-center mb-3" style="color:var(--dourado-escuro)">Aceite o termo de responsabilidade para liberar o início da faxina.</p>` : '')}
        <p class="text-[14px] font-bold mb-3 text-center">A solicitação corresponde ao que você encontrou?</p>
        <div class="flex gap-2">
          <button id="btnSim" class="flex-1 btn-primary py-3.5 rounded-2xl text-[14px]" ${podeIniciarFaxina ? '' : 'disabled style="opacity:.5;pointer-events:none"'}>Sim, corresponde</button>
          <button id="btnNao" class="flex-1 py-3.5 rounded-2xl text-[14px] font-semibold border" style="border-color:#F0C6C6;color:#C0392B${checklistPendente ? ';opacity:.5;pointer-events:none' : ''}" ${checklistPendente ? 'disabled' : ''}>Não, encontrei divergência</button>
        </div>`;
      document.getElementById('btnAbrirChecklist').onclick = () => abrirModalChecklist(run.id);
      document.getElementById('btnAbrirTermoEntrada').onclick = () => abrirModalTermoEntrada();
      document.getElementById('btnSim').onclick = () => {
        try{
          ServiceRequestsService.responderConferencia(provider.id, requestId, true);
          mostrarToast('Confirmado! Serviço iniciado.');
        }catch(err){ mostrarToast(err.message); }
        montarTela();
      };
      document.getElementById('btnNao').onclick = () => {
        try{
          ServiceRequestsService.responderConferencia(provider.id, requestId, false);
          abrirModalDivergencia();
        }catch(err){ mostrarToast(err.message); }
      };
    }

    else if(s.status === 'IN_PROGRESS'){
      const botoesExtra = (s.categoria === 'Pequenos Reparos' || s.categoria === 'Roupa de cama / Enxoval')
        ? `<button id="btnProporAlteracao" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-2" style="border-color:var(--linha);color:var(--tinta)">Propor alteração formal</button>`
        : '';
      const podeReclassificar = s.categoria === 'Limpeza' && s.detalhes && s.detalhes.tipo === 'padrão';
      const botaoReclassificar = s.reclassificacao_pendente
        ? `<div class="geo-banner mb-2" style="background:#FDF2E1;color:var(--dourado-escuro)"><i data-lucide="clock"></i><span>Reclassificação para "${s.reclassificacao_pendente.modalidade_proposta}" enviada — aguardando análise do administrador.</span></div>`
        : (podeReclassificar ? `<button id="btnReclassificarLimpeza" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-2" style="border-color:var(--linha);color:var(--tinta)">Esta faxina é Pesada/Pós-obra, não Padrão</button>` : '');
      const posRun = ChecklistService.obterPorSolicitacao(requestId, 'pos');
      const posVistoriaOk = !BLOQUEIOS_CONFIG.posVistoriaObrigatoria || (posRun && posRun.concluido);
      const termoSaidaAceito = TermsService.jaAceitou(sessao.id, 'vistoria_saida', TERMO_VISTORIA_SAIDA.versao, requestId);
      const podeFinalizarServico = posVistoriaOk && termoSaidaAceito;
      cont.innerHTML = `
        ${botoesExtra}
        ${botaoReclassificar}
        <button id="btnAcompanhamento" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-2" style="border-color:var(--linha);color:var(--tinta)">Registrar acompanhamento (foto)</button>
        <input id="fotoAcompanhamento" type="file" accept="image/*" capture="environment" class="hidden">
        <button id="btnAbrirDivergenciaTardia" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-2" style="border-color:#F0C6C6;color:#C0392B">Relatar divergência</button>
        <button id="btnAbrirPosVistoria" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-2" style="border-color:var(--linha);color:var(--tinta)">Vistoria de saída (antes/depois)${posRun && posRun.concluido ? ' ✓' : ''}</button>
        <button id="btnAbrirTermoSaida" class="w-full py-3 rounded-2xl text-[13px] font-semibold border mb-2" style="border-color:var(--linha);color:var(--tinta)" ${posVistoriaOk ? '' : 'disabled style="opacity:.5;pointer-events:none"'}>Termo de finalização da vistoria${termoSaidaAceito ? ' ✓' : ''}</button>
        <button id="btnFinalizar" class="btn-primary w-full py-4 rounded-2xl text-base" ${podeFinalizarServico ? '' : 'disabled style="opacity:.5;pointer-events:none"'}>Finalizar serviço</button>
        ${podeFinalizarServico ? '' : `<p class="text-[12px] text-center mt-2" style="color:var(--dourado-escuro)">${!posVistoriaOk ? 'Conclua a vistoria de saída (com vídeo) para liberar o termo.' : 'Aceite o termo de finalização para liberar o botão "Finalizar serviço".'}</p>`}
      `;
      document.getElementById('btnFinalizar').onclick = () => {
        montarChecklistFinalizacao(s.categoria);
        document.getElementById('modalFinalizar').classList.add('show');
      };
      document.getElementById('btnAbrirDivergenciaTardia').onclick = () => abrirModalDivergencia();
      document.getElementById('btnAbrirPosVistoria').onclick = () => abrirModalPosVistoria();
      document.getElementById('btnAbrirTermoSaida').onclick = () => abrirModalTermoSaida();
      document.getElementById('btnAcompanhamento').onclick = () => document.getElementById('fotoAcompanhamento').click();
      document.getElementById('fotoAcompanhamento').addEventListener('change', async function(e){
        const file = e.target.files[0];
        if(!file) return;
        const pos = await pegarPosicao();
        const reader = new FileReader();
        reader.onload = ev => {
          EvidencesService.registrar({ service_request_id: requestId, user_id: sessao.id, tipo:'acompanhamento_execucao', texto:'Registro de acompanhamento durante a execução.', fotos:[ev.target.result], gps: pos ? { lat:pos.lat, lng:pos.lng, precisao:pos.precisao } : null });
          AuditLogService.registrar({ user_id: sessao.id, acao:'registrar_acompanhamento', entidade:'service_requests', entidade_id:requestId });
          mostrarToast('Acompanhamento registrado!');
        };
        reader.readAsDataURL(file);
      });
      const btnProp = document.getElementById('btnProporAlteracao');
      if(btnProp) btnProp.onclick = () => proporAlteracaoPrompt(s);
      const btnReclass = document.getElementById('btnReclassificarLimpeza');
      if(btnReclass) btnReclass.onclick = () => abrirModalReclassificacao();
    }

    else if(s.status === 'UNDER_REVIEW'){
      cont.innerHTML = `<div class="geo-banner" style="background:#EAF1FD;color:var(--azul-escuro)"><i data-lucide="clock"></i><span>Finalização enviada. Aguardando o anfitrião confirmar a conclusão.</span></div>`;
      refreshIcons();
    }

    else if(s.status === 'COMPLETED'){
      cont.innerHTML = `<div class="geo-banner" style="background:#E7F6EE;color:#0E8F52"><i data-lucide="check-circle"></i><span>Serviço concluído. Pagamento em processo de liberação.</span></div>`;
      refreshIcons();
    }

    renderAvaliacaoAnfitriao(s);
  }

  let notaAnfitriao = 0;
  function renderAvaliacaoAnfitriao(s){
    const cont = document.getElementById('areaAvaliacaoAnfitriao');
    if(s.status !== 'COMPLETED'){ cont.innerHTML = ''; return; }
    const jaAvaliou = DB.findOne('reviews', r => r.service_request_id === requestId && r.avaliador_id === sessao.id);
    if(jaAvaliou){
      cont.innerHTML = `<div class="card-soft p-4"><p class="text-[13px] font-semibold">Você avaliou este anfitrião com ${jaAvaliou.nota}★</p>${jaAvaliou.comentario ? `<p class="text-[12px] text-muted mt-1">"${jaAvaliou.comentario}"</p>` : ''}</div>`;
      return;
    }
    cont.innerHTML = `<button id="btnAbrirAvaliacaoAnfitriao" class="btn-gold w-full py-3.5 rounded-2xl text-[14px]">Avaliar anfitrião</button>`;
    document.getElementById('btnAbrirAvaliacaoAnfitriao').onclick = () => {
      notaAnfitriao = 0;
      document.querySelectorAll('#estrelasAvaliacaoAnfitriao .star').forEach(el=>el.classList.remove('filled'));
      document.getElementById('comentarioAvaliacaoAnfitriao').value = '';
      document.getElementById('modalAvaliacaoAnfitriao').classList.add('show');
    };
  }
  document.getElementById('estrelasAvaliacaoAnfitriao').addEventListener('click', (e) => {
    if(!e.target.classList.contains('star')) return;
    notaAnfitriao = Number(e.target.dataset.v);
    document.querySelectorAll('#estrelasAvaliacaoAnfitriao .star').forEach(el => el.classList.toggle('filled', Number(el.dataset.v) <= notaAnfitriao));
  });
  document.getElementById('fecharModalAvaliacaoAnfitriao').onclick = () => document.getElementById('modalAvaliacaoAnfitriao').classList.remove('show');
  document.getElementById('btnEnviarAvaliacaoAnfitriao').onclick = () => {
    if(notaAnfitriao === 0){ mostrarToast('Selecione uma nota de 1 a 5 estrelas.'); return; }
    const s = obterSolicitacao();
    ReviewsService.criar({ service_request_id: requestId, avaliador_id: sessao.id, avaliado_id: s.owner_id, nota: notaAnfitriao, comentario: document.getElementById('comentarioAvaliacaoAnfitriao').value.trim() });
    mostrarToast('Avaliação enviada!');
    document.getElementById('modalAvaliacaoAnfitriao').classList.remove('show');
    renderAvaliacaoAnfitriao(s);
  };

  function proporAlteracaoPrompt(s){
    if(s.categoria === 'Pequenos Reparos'){
      const descricao = window.prompt('Descreva o problema real encontrado (novo orçamento):', s.detalhes.descricao || '');
      if(!descricao) return;
      ServiceRequestsService.proporAlteracao(provider.id, requestId, {
        novosDetalhes: { tipo: s.detalhes.tipo, descricao, necessitaAvaliacao: false },
        motivo: 'Novo orçamento após avaliação: ' + descricao,
      });
    } else {
      const qtd = Number(window.prompt('Quantidade de kits de enxoval encontrada/necessária:', s.detalhes.quantidade || 1));
      if(!qtd || qtd < 1) return;
      ServiceRequestsService.proporAlteracao(provider.id, requestId, {
        novosDetalhes: Object.assign({}, s.detalhes, { quantidade: qtd }),
        motivo: `Quantidade de enxoval diferente: ${s.detalhes.quantidade || 1} → ${qtd}`,
      });
    }
    mostrarToast('Proposta enviada ao anfitrião.');
    montarTela();
  }

  // ---------- Modal de checklist (vistoria de entrada) ----------
  let videoChecklistBase64 = null;
  function abrirModalChecklist(runId){
    const run = DB.find('property_checklist_runs', runId);
    const cont = document.getElementById('itensChecklist');
    if(!run.itens.length){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-4">Este imóvel ainda não tem ambientes/inventário cadastrados pelo anfitrião.</p>';
    } else {
      cont.innerHTML = run.itens.map((it, idx) => `
        <div class="card-soft p-3">
          <p class="text-[12.5px] font-semibold mb-2">${it.descricao}</p>
          <div class="flex gap-2">
            <button class="flex-1 py-2 rounded-lg text-[11.5px] font-semibold itemChecklistBtn" data-idx="${idx}" data-ok="true" style="background:${it.ok===true?'#E7F6EE':'#F1F3F8'};color:${it.ok===true?'#0E8F52':'var(--tinta)'}">OK</button>
            <button class="flex-1 py-2 rounded-lg text-[11.5px] font-semibold itemChecklistBtn" data-idx="${idx}" data-ok="false" style="background:${it.ok===false?'#FCE8E8':'#F1F3F8'};color:${it.ok===false?'#C0392B':'var(--tinta)'}">Divergente</button>
          </div>
        </div>`).join('');
      cont.querySelectorAll('.itemChecklistBtn').forEach(btn => {
        btn.onclick = () => {
          ChecklistService.responderItem(provider.id, runId, Number(btn.dataset.idx), { ok: btn.dataset.ok === 'true' });
          abrirModalChecklist(runId);
        };
      });
    }
    videoChecklistBase64 = run.video || null;
    document.getElementById('previewVideoChecklist').innerHTML = run.video
      ? `<p class="text-[12px]" style="color:#0E8F52">✓ Vídeo anexado ${run.video_registrado_em ? 'em '+new Date(run.video_registrado_em).toLocaleString('pt-BR') : ''}</p>`
      : '<p class="text-[12px] text-muted">Nenhum vídeo anexado ainda</p>';
    document.getElementById('checklistVideo').value = '';
    document.getElementById('checklistObservacoes').value = run.observacao_geral || '';
    document.getElementById('modalChecklist').classList.add('show');
  }
  document.getElementById('fecharModalChecklist').onclick = () => document.getElementById('modalChecklist').classList.remove('show');
  document.getElementById('checklistVideo').addEventListener('change', function(e){
    const file = e.target.files[0];
    if(!file) return;
    const erroTamanho = validarTamanhoArquivo(file, window.APP_CONFIG.LIMITES_ARQUIVO.VIDEO_MAX_MB);
    if(erroTamanho){ mostrarToast(erroTamanho + ' Grave um vídeo mais curto.'); e.target.value = ''; return; }
    const runAtual = ChecklistService.obterPorSolicitacao(requestId);
    const reader = new FileReader();
    reader.onload = ev => {
      try{
        ChecklistService.registrarVideo(provider.id, runAtual.id, ev.target.result);
        videoChecklistBase64 = ev.target.result;
        document.getElementById('previewVideoChecklist').innerHTML = `<p class="text-[12px]" style="color:#0E8F52">✓ Vídeo anexado em ${new Date().toLocaleString('pt-BR')}</p>`;
        mostrarToast('Vídeo da vistoria de entrada anexado.');
      }catch(err){ mostrarToast(err.message); }
    };
    reader.readAsDataURL(file);
  });
  document.getElementById('btnConcluirChecklist').onclick = () => {
    const checklistRun = ChecklistService.obterPorSolicitacao(requestId);
    if(!checklistRun){ mostrarToast('Checklist não encontrado.'); return; }
    const observacoes = document.getElementById('checklistObservacoes').value;
    ChecklistService.registrarObservacaoGeral(provider.id, checklistRun.id, observacoes);
    try{
      ChecklistService.concluir(provider.id, checklistRun.id);
      mostrarToast('Vistoria de entrada concluída.');
      document.getElementById('modalChecklist').classList.remove('show');
    }catch(err){ mostrarToast(err.message); return; }
    montarTela();
  };

  // ---------- Modal do termo de responsabilidade da vistoria de entrada ----------
  function abrirModalTermoEntrada(){
    const checklistRun = ChecklistService.obterPorSolicitacao(requestId);
    if(!checklistRun || !checklistRun.concluido){ mostrarToast('Conclua a vistoria de entrada antes de aceitar o termo.'); return; }
    document.getElementById('tituloTermoEntrada').innerText = TERMO_VISTORIA_ENTRADA.titulo;
    document.getElementById('conteudoTermoEntrada').innerHTML = TERMO_VISTORIA_ENTRADA.html;
    const jaAceito = TermsService.jaAceitou(sessao.id, 'vistoria_entrada', TERMO_VISTORIA_ENTRADA.versao, requestId);
    document.getElementById('checkTermoEntrada').checked = jaAceito;
    document.getElementById('modalTermoEntrada').classList.add('show');
  }
  document.getElementById('fecharModalTermoEntrada').onclick = () => document.getElementById('modalTermoEntrada').classList.remove('show');
  document.getElementById('btnAceitarTermoEntrada').onclick = () => {
    if(!document.getElementById('checkTermoEntrada').checked){ mostrarToast('Marque a confirmação para aceitar o termo.'); return; }
    try{
      TermsService.registrarAceite(sessao.id, 'vistoria_entrada', {
        nome: sessao.nome, cpf: provider.cpf, versao: TERMO_VISTORIA_ENTRADA.versao, service_request_id: requestId,
      });
      mostrarToast('Termo aceito! Vistoria de entrada confirmada.');
      document.getElementById('modalTermoEntrada').classList.remove('show');
      montarTela();
    }catch(err){ mostrarToast(err.message); }
  };

  // ---------- Modal de divergência ----------
  const ROTULOS_SEVERIDADE = { baixa:'Baixa', media:'Média', alta:'Alta', critica:'Crítica' };
  let severidadeSelecionada = null;
  function abrirModalDivergencia(){
    document.getElementById('motivosDivergencia').innerHTML = MOTIVOS_DIVERGENCIA.map(m =>
      `<button type="button" class="motivo-chip motivo-opt" data-m="${m}">${m}</button>`).join('');
    document.querySelectorAll('.motivo-opt').forEach(btn => {
      btn.onclick = () => {
        document.querySelectorAll('.motivo-opt').forEach(b=>b.classList.remove('selected'));
        btn.classList.add('selected');
        motivoSelecionado = btn.dataset.m;
      };
    });
    severidadeSelecionada = null;
    document.getElementById('severidadeDivergencia').innerHTML = SEVERIDADES_DIVERGENCIA.map(s =>
      `<button type="button" class="motivo-chip severidade-opt" data-s="${s}">${ROTULOS_SEVERIDADE[s]}</button>`).join('');
    document.querySelectorAll('.severidade-opt').forEach(btn => {
      btn.onclick = () => {
        document.querySelectorAll('.severidade-opt').forEach(b=>b.classList.remove('selected'));
        btn.classList.add('selected');
        severidadeSelecionada = btn.dataset.s;
        document.getElementById('rotuloFotosObrigatorias').textContent = BLOQUEIOS_CONFIG.severidadesExigemFoto.includes(severidadeSelecionada) ? '(obrigatório para esta severidade)' : '(recomendado)';
      };
    });
    document.getElementById('rotuloFotosObrigatorias').textContent = '(recomendado)';
    fotosDivergencia = [];
    document.getElementById('previewFotosDivergencia').innerHTML = '';
    document.getElementById('divergenciaDescricao').value = '';
    document.getElementById('modalDivergencia').classList.add('show');
    refreshIcons();
  }
  document.getElementById('fecharModalDivergencia').onclick = () => document.getElementById('modalDivergencia').classList.remove('show');
  document.getElementById('divergenciaFotos').addEventListener('change', function(e){
    Array.from(e.target.files).slice(0,4).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { fotosDivergencia.push(ev.target.result); document.getElementById('previewFotosDivergencia').innerHTML = fotosDivergencia.map(f=>`<img src="${f}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join(''); };
      reader.readAsDataURL(file);
    });
  });
  document.getElementById('btnEnviarDivergencia').onclick = async () => {
    if(!motivoSelecionado){ mostrarToast('Selecione o motivo da divergência.'); return; }
    if(!severidadeSelecionada){ mostrarToast('Selecione a severidade da divergência.'); return; }
    if(BLOQUEIOS_CONFIG.severidadesExigemFoto.includes(severidadeSelecionada) && fotosDivergencia.length === 0){
      mostrarToast('Esta severidade exige ao menos uma foto como evidência.'); return;
    }
    const descricao = document.getElementById('divergenciaDescricao').value.trim();
    const pos = await pegarPosicao();
    try{
      DisputesService.abrirDivergencia(provider.id, requestId, { motivo: motivoSelecionado, severidade: severidadeSelecionada, descricao, fotos: fotosDivergencia, gps: pos });
      mostrarToast('Divergência registrada. O anfitrião foi notificado.');
      document.getElementById('modalDivergencia').classList.remove('show');
      montarTela();
    }catch(err){ mostrarToast(err.message); }
  };

  // ---------- Modal de pós-vistoria (vistoria de saída — comparativo antes/depois) ----------
  function abrirModalPosVistoria(){
    let run;
    try{ run = ChecklistService.iniciarPosVistoria(provider.id, requestId); }
    catch(err){ mostrarToast(err.message); return; }
    renderItensPosVistoria(run.id);
    document.getElementById('previewVideoPosVistoria').innerHTML = run.video
      ? `<p class="text-[12px]" style="color:#0E8F52">✓ Vídeo anexado ${run.video_registrado_em ? 'em '+new Date(run.video_registrado_em).toLocaleString('pt-BR') : ''}</p>`
      : '<p class="text-[12px] text-muted">Nenhum vídeo anexado ainda</p>';
    document.getElementById('posVistoriaVideo').value = '';
    document.getElementById('modalPosVistoria').classList.add('show');
  }
  function renderItensPosVistoria(runId){
    const run = DB.find('property_checklist_runs', runId);
    const cont = document.getElementById('itensPosVistoria');
    if(!run.itens.length){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-4">Sem itens de checklist para comparar.</p>';
    } else {
      cont.innerHTML = run.itens.map((it, idx) => `
        <div class="card-soft p-3">
          <p class="text-[12.5px] font-semibold mb-1">${it.descricao}</p>
          <p class="text-[11px] text-muted mb-2">Registro na pré-vistoria: ${(it.fotos_antes||[]).length} foto(s)${it.observacao_antes ? ' · '+it.observacao_antes : ''}</p>
          <div class="flex gap-2 mb-2">
            <button class="flex-1 py-2 rounded-lg text-[11.5px] font-semibold posItemBtn" data-idx="${idx}" data-ok="true" style="background:${it.ok===true?'#E7F6EE':'#F1F3F8'};color:${it.ok===true?'#0E8F52':'var(--tinta)'}">OK</button>
            <button class="flex-1 py-2 rounded-lg text-[11.5px] font-semibold posItemBtn" data-idx="${idx}" data-ok="false" style="background:${it.ok===false?'#FCE8E8':'#F1F3F8'};color:${it.ok===false?'#C0392B':'var(--tinta)'}">Divergente</button>
          </div>
          <input type="file" accept="image/*" class="posItemFoto text-[11px]" data-idx="${idx}">
          <p class="text-[11px] text-muted mt-1">${(it.fotos||[]).length} foto(s) "depois" anexada(s)</p>
        </div>`).join('');
      cont.querySelectorAll('.posItemBtn').forEach(btn => {
        btn.onclick = () => {
          const idx = Number(btn.dataset.idx);
          const item = run.itens[idx];
          ChecklistService.responderItem(provider.id, runId, idx, { ok: btn.dataset.ok === 'true', observacao: item.observacao, fotos: item.fotos });
          renderItensPosVistoria(runId);
        };
      });
      cont.querySelectorAll('.posItemFoto').forEach(input => {
        input.onchange = (e) => {
          const idx = Number(input.dataset.idx);
          const file = e.target.files[0];
          if(!file) return;
          const item = run.itens[idx];
          const reader = new FileReader();
          reader.onload = ev => {
            ChecklistService.responderItem(provider.id, runId, idx, { ok: item.ok, observacao: item.observacao, fotos: (item.fotos||[]).concat([ev.target.result]) });
            renderItensPosVistoria(runId);
          };
          reader.readAsDataURL(file);
        };
      });
    }
  }
  document.getElementById('fecharModalPosVistoria').onclick = () => document.getElementById('modalPosVistoria').classList.remove('show');
  document.getElementById('posVistoriaVideo').addEventListener('change', function(e){
    const file = e.target.files[0];
    if(!file) return;
    const erroTamanho = validarTamanhoArquivo(file, window.APP_CONFIG.LIMITES_ARQUIVO.VIDEO_MAX_MB);
    if(erroTamanho){ mostrarToast(erroTamanho + ' Grave um vídeo mais curto.'); e.target.value = ''; return; }
    const runAtual = ChecklistService.obterPorSolicitacao(requestId, 'pos');
    if(!runAtual) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try{
        ChecklistService.registrarVideo(provider.id, runAtual.id, ev.target.result);
        document.getElementById('previewVideoPosVistoria').innerHTML = `<p class="text-[12px]" style="color:#0E8F52">✓ Vídeo anexado em ${new Date().toLocaleString('pt-BR')}</p>`;
        mostrarToast('Vídeo da vistoria de saída anexado.');
      }catch(err){ mostrarToast(err.message); }
    };
    reader.readAsDataURL(file);
  });
  document.getElementById('btnConcluirPosVistoria').onclick = () => {
    const run = ChecklistService.obterPorSolicitacao(requestId, 'pos');
    if(!run){ mostrarToast('Vistoria de saída não encontrada.'); return; }
    try{
      ChecklistService.concluir(provider.id, run.id);
      mostrarToast('Vistoria de saída concluída!');
      document.getElementById('modalPosVistoria').classList.remove('show');
      montarTela();
    }catch(err){ mostrarToast(err.message); }
  };

  // ---------- Modal do termo de finalização da vistoria de saída ----------
  function abrirModalTermoSaida(){
    const run = ChecklistService.obterPorSolicitacao(requestId, 'pos');
    if(!run || !run.concluido){ mostrarToast('Conclua a vistoria de saída antes de aceitar o termo.'); return; }
    document.getElementById('tituloTermoSaida').innerText = TERMO_VISTORIA_SAIDA.titulo;
    document.getElementById('conteudoTermoSaida').innerHTML = TERMO_VISTORIA_SAIDA.html;
    const jaAceito = TermsService.jaAceitou(sessao.id, 'vistoria_saida', TERMO_VISTORIA_SAIDA.versao, requestId);
    document.getElementById('checkTermoSaida').checked = jaAceito;
    document.getElementById('modalTermoSaida').classList.add('show');
  }
  document.getElementById('fecharModalTermoSaida').onclick = () => document.getElementById('modalTermoSaida').classList.remove('show');
  document.getElementById('btnAceitarTermoSaida').onclick = () => {
    if(!document.getElementById('checkTermoSaida').checked){ mostrarToast('Marque a confirmação para aceitar o termo.'); return; }
    try{
      TermsService.registrarAceite(sessao.id, 'vistoria_saida', {
        nome: sessao.nome, cpf: provider.cpf, versao: TERMO_VISTORIA_SAIDA.versao, service_request_id: requestId,
      });
      mostrarToast('Termo aceito! Vistoria de saída confirmada.');
      document.getElementById('modalTermoSaida').classList.remove('show');
      montarTela();
    }catch(err){ mostrarToast(err.message); }
  };

  // ---------- Modal de reclassificação de modalidade de Limpeza ----------
  let reclassArquivos = { fotos: [], videos: [] };
  function abrirModalReclassificacao(){
    reclassArquivos = { fotos: [], videos: [] };
    document.getElementById('previewReclassificacao').innerHTML = '';
    document.getElementById('reclassModalidade').value = 'pesada';
    document.getElementById('reclassMotivo').value = '';
    document.getElementById('modalReclassificacao').classList.add('show');
  }
  document.getElementById('fecharModalReclassificacao').onclick = () => document.getElementById('modalReclassificacao').classList.remove('show');
  document.getElementById('reclassArquivos').addEventListener('change', function(e){
    Array.from(e.target.files).slice(0,6).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => {
        if(file.type.startsWith('video')) reclassArquivos.videos.push(ev.target.result);
        else reclassArquivos.fotos.push(ev.target.result);
        document.getElementById('previewReclassificacao').innerHTML =
          reclassArquivos.fotos.map(f => `<img src="${f}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join('') +
          reclassArquivos.videos.map(() => `<div class="card-soft flex items-center justify-center text-[11px]" style="aspect-ratio:1"><i data-lucide="video"></i></div>`).join('');
        refreshIcons();
      };
      reader.readAsDataURL(file);
    });
  });
  document.getElementById('btnEnviarReclassificacao').onclick = async () => {
    const modalidadeProposta = document.getElementById('reclassModalidade').value;
    const motivo = document.getElementById('reclassMotivo').value.trim();
    if(!motivo){ mostrarToast('Descreva por que a modalidade deveria mudar.'); return; }
    const pos = await pegarPosicao();
    try{
      ServiceRequestsService.proporReclassificacaoLimpeza(provider.id, requestId, {
        modalidadeProposta, motivo, fotos: reclassArquivos.fotos, videos: reclassArquivos.videos,
        gps: pos ? { lat:pos.lat, lng:pos.lng, precisao:pos.precisao } : null,
      });
      mostrarToast('Reclassificação enviada para análise do administrador.');
      document.getElementById('modalReclassificacao').classList.remove('show');
      montarTela();
    }catch(err){ mostrarToast(err.message); }
  };

  // ---------- Modal de finalização ----------
  const ITENS_FINALIZACAO_POR_CATEGORIA = {
    'Limpeza': ['Pisos limpos', 'Banheiros limpos', 'Lixo removido', 'Camas arrumadas'],
    'Pequenos Reparos': ['Reparo realizado conforme solicitado', 'Área de trabalho limpa após o reparo', 'Peça/material testado e funcionando'],
    'Roupa de cama / Enxoval': ['Enxoval entregue conforme quantidade acordada', 'Itens conferidos e sem avarias', 'Camas montadas com o enxoval'],
  };
  function montarChecklistFinalizacao(categoria){
    const itens = ITENS_FINALIZACAO_POR_CATEGORIA[categoria] || ITENS_FINALIZACAO_POR_CATEGORIA['Limpeza'];
    document.getElementById('itensFinalizarChecklist').innerHTML = itens.map(i =>
      `<label class="checkbox-pill"><input type="checkbox" class="chkFinal" value="${i}"> ${i}</label>`
    ).join('');
  }
  document.getElementById('fecharModalFinalizar').onclick = () => document.getElementById('modalFinalizar').classList.remove('show');
  document.getElementById('finalizarFotos').addEventListener('change', function(e){
    Array.from(e.target.files).slice(0,6).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { fotosFinalizar.push(ev.target.result); document.getElementById('previewFotosFinalizar').innerHTML = fotosFinalizar.map(f=>`<img src="${f}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join(''); };
      reader.readAsDataURL(file);
    });
  });
  document.getElementById('btnConfirmarFinalizar').onclick = () => {
    const checklist = Array.from(document.querySelectorAll('.chkFinal:checked')).map(c=>c.value);
    const observacoes = document.getElementById('finalizarObs').value.trim();
    const horario_termino = document.getElementById('finalizarHorario').value || new Date().toTimeString().slice(0,5);
    ServiceRequestsService.finalizarExecucao(provider.id, requestId, { fotos: fotosFinalizar, checklist, observacoes, horario_termino });
    mostrarToast('Finalização enviada ao anfitrião!');
    document.getElementById('modalFinalizar').classList.remove('show');
    montarTela();
  };

  function montarTela(){
    const s = obterSolicitacao();
    if(!s) return;
    renderCabecalho(s);
    renderTimeline(s);
    renderAcao(s);
  }

  montarTela();
})();
