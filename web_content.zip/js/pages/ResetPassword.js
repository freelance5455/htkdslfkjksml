import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { isStrong } from '../lib/util.js';
import PasswordInput, { PasswordRules } from '../components/PasswordInput.js';
import { Notice } from '../components/Bits.js';
export default function ResetPassword() {
    const nav = useNavigate();
    const [pw, setPw] = useState('');
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);
    async function submit(e) {
        e.preventDefault();
        setBusy(true);
        setErr('');
        const { error } = await supabase.auth.updateUser({ password: pw });
        setBusy(false);
        if (error)
            setErr(error.message);
        else
            nav('/', { replace: true });
    }
    return (_jsxs("div", { className: "auth-wrap", children: [_jsx("h2", { children: "Naya password" }), _jsxs("form", { className: "stack", onSubmit: submit, children: [_jsx(PasswordInput, { value: pw, onChange: setPw, placeholder: "Naya password", autoComplete: "new-password" }), _jsx(PasswordRules, { value: pw }), err && _jsx(Notice, { kind: "error", children: err }), _jsx("button", { className: "btn primary block", disabled: !isStrong(pw) || busy, children: "Password badlein" })] })] }));
}
