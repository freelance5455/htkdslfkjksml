import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase.js';
import { slugify } from '../../lib/util.js';
import { Notice } from '../../components/Bits.js';
export default function AdminServices() {
    const [items, setItems] = useState([]);
    const [name, setName] = useState('');
    const [emoji, setEmoji] = useState('🛠️');
    const [color, setColor] = useState('#F2A014');
    const [err, setErr] = useState('');
    const load = useCallback(async () => {
        const { data } = await supabase.from('services').select('*').order('sort');
        setItems(data || []);
    }, []);
    useEffect(() => { load(); }, [load]);
    async function add(e) {
        e.preventDefault();
        setErr('');
        const { error } = await supabase.from('services').insert({
            name: name.trim(), slug: slugify(name), emoji, color, sort: (items[items.length - 1]?.sort || 0) + 1,
        });
        if (error)
            return setErr(error.message);
        setName('');
        load();
    }
    async function patch(s, p) {
        await supabase.from('services').update(p).eq('id', s.id);
        load();
    }
    return (_jsxs(_Fragment, { children: [_jsxs("form", { className: "card stack", onSubmit: add, children: [_jsx("h3", { children: "Nayi service" }), _jsxs("div", { className: "row", children: [_jsx("input", { className: "input", style: { width: 70, textAlign: 'center' }, value: emoji, onChange: (e) => setEmoji(e.target.value), "aria-label": "Emoji" }), _jsx("input", { className: "input", placeholder: "Service ka naam", value: name, onChange: (e) => setName(e.target.value) }), _jsx("input", { type: "color", value: color, onChange: (e) => setColor(e.target.value), "aria-label": "Rang", style: { width: 48, height: 44, border: 0, background: 'none' } })] }), err && _jsx(Notice, { kind: "error", children: err }), _jsx("button", { className: "btn primary sm", disabled: name.trim().length < 2, children: "Add karein" })] }), _jsx("div", { className: "list", style: { marginTop: '.8rem' }, children: items.map((s) => (_jsxs("div", { className: "card row between", children: [_jsxs("span", { children: [_jsx("span", { style: { fontSize: '1.5rem' }, children: s.emoji }), " ", _jsx("b", { children: s.name })] }), _jsx("button", { className: `btn sm ${s.active ? 'ghost' : 'ok'}`, onClick: () => patch(s, { active: !s.active }), children: s.active ? 'Band karein' : 'Live karein' })] }, s.id))) })] }));
}
