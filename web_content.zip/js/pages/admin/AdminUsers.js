import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase.js';
import { Empty, Notice } from '../../components/Bits.js';
export default function AdminUsers() {
    const [rows, setRows] = useState([]);
    const [q, setQ] = useState('');
    const [filter, setFilter] = useState('all');
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        supabase.rpc('admin_user_overview').then(({ data, error }) => {
            if (error)
                setErr(error.message);
            setRows((data || []).map((r) => ({ ...r, violations: Number(r.violations), deals: Number(r.deals) })));
            setLoading(false);
        });
    }, []);
    const t = q.toLowerCase().trim();
    const shown = rows.filter((r) => {
        if (filter === 'buyer' && r.role !== 'buyer')
            return false;
        if (filter === 'seller' && r.role !== 'seller')
            return false;
        if (filter === 'admin' && !r.is_admin)
            return false;
        if (filter === 'flagged' && r.violations === 0 && !r.is_blocked)
            return false;
        if (!t)
            return true;
        return [r.full_name, r.email, r.phone, r.city].some((v) => (v || '').toLowerCase().includes(t));
    });
    return (_jsxs(_Fragment, { children: [_jsx("input", { className: "input", placeholder: "Naam, email, phone ya shehar dhoondein", value: q, onChange: (e) => setQ(e.target.value) }), _jsx("div", { className: "tabs", style: { marginTop: '.6rem' }, children: ['all', 'buyer', 'seller', 'admin', 'flagged'].map((f) => (_jsx("button", { className: filter === f ? 'active' : '', onClick: () => setFilter(f), children: { all: 'Sab', buyer: 'Buyers', seller: 'Sellers', admin: 'Admins', flagged: 'Flagged' }[f] }, f))) }), err && _jsx(Notice, { kind: "error", children: err }), loading ? _jsx("p", { className: "muted center", children: "Load ho raha hai..." }) : shown.length === 0 ? _jsx(Empty, { icon: "users", title: "Koi user nahi mila" }) : (_jsx("div", { className: "list", children: shown.map((r) => (_jsxs(Link, { to: `/admin/users/${r.id}`, className: "card link", children: [_jsxs("div", { className: "row between", children: [_jsx("b", { children: r.full_name || '(naam nahi)' }), _jsxs("span", { className: "row", children: [r.is_super && _jsx("span", { className: "chip gold", children: "Main admin" }), r.is_admin && !r.is_super && _jsx("span", { className: "chip gold", children: "Admin" }), r.is_blocked && _jsx("span", { className: "chip red", children: "Blocked" })] })] }), _jsxs("div", { className: "small muted", children: [r.role === 'seller' ? 'Seller' : r.role === 'buyer' ? 'Buyer' : 'Role nahi', " \u00B7 ", r.city || 'shehar nahi', " \u00B7 ", r.deals, " deals", r.violations > 0 && _jsxs(_Fragment, { children: [" \u00B7 ", _jsxs("span", { style: { color: 'var(--coral)', fontWeight: 700 }, children: ["\u26A0 ", r.violations, " number/location koshish"] })] })] })] }, r.id))) }))] }));
}
