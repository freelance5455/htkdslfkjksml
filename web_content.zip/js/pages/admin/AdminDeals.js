import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase.js';
import { useAuth } from '../../lib/AuthContext.js';
import { fmtDate, money, phoneDigits } from '../../lib/util.js';
import { Empty, Notice, StatusChip } from '../../components/Bits.js';
const FILTERS = ['requested', 'approved', 'chatting', 'completed', 'rejected', 'cancelled'];
const LABEL = { requested: 'Pending', approved: 'Approved', chatting: 'Chat', completed: 'Mukammal', rejected: 'Reject', cancelled: 'Cancel' };
function ContactBox({ title, c }) {
    if (!c)
        return _jsxs("div", { className: "card", children: [_jsx("b", { children: title }), _jsx("p", { className: "muted small", children: "Details nahi mili." })] });
    return (_jsxs("div", { className: "card", children: [_jsx("b", { children: title }), _jsxs("p", { className: "small", style: { margin: '.3rem 0' }, children: ["\uD83D\uDCDE ", c.phone || '-', _jsx("br", {}), "\uD83C\uDFD9\uFE0F ", c.city || '-', _jsx("br", {}), "\uD83D\uDCCD ", c.address || '-', _jsx("br", {}), "\u2709\uFE0F ", c.email || '-'] }), c.phone && (_jsxs("div", { className: "row", children: [_jsx("a", { className: "btn sm", href: `tel:${c.phone}`, children: "Call" }), _jsx("a", { className: "btn ok sm", target: "_blank", rel: "noreferrer", href: `https://wa.me/${phoneDigits(c.phone)}`, children: "WhatsApp" })] }))] }));
}
export default function AdminDeals() {
    const { can } = useAuth();
    const [deals, setDeals] = useState([]);
    const [filter, setFilter] = useState('requested');
    const [open, setOpen] = useState('');
    const [contacts, setContacts] = useState({});
    const [notes, setNotes] = useState({});
    const [err, setErr] = useState('');
    const load = useCallback(async () => {
        const { data } = await supabase.from('deals')
            .select('*, buyer:profiles!deals_buyer_id_fkey(full_name), seller:profiles!deals_seller_id_fkey(full_name)')
            .order('updated_at', { ascending: false }).limit(300);
        setDeals(data || []);
    }, []);
    useEffect(() => { load(); }, [load]);
    async function toggle(d) {
        if (open === d.id)
            return setOpen('');
        setOpen(d.id);
        if (can('view_contacts')) {
            const { data } = await supabase.from('private_contacts').select('*').in('user_id', [d.buyer_id, d.seller_id]);
            const m = {};
            (data || []).forEach((c) => { m[c.user_id] = c; });
            setContacts((prev) => ({ ...prev, ...m }));
        }
    }
    async function decide(d, status) {
        setErr('');
        const { error } = await supabase.rpc('admin_decide_deal', { p_deal: d.id, p_status: status, p_note: notes[d.id] || '' });
        if (error)
            return setErr(error.message);
        load();
    }
    const shown = deals.filter((d) => d.status === filter);
    const count = (st) => deals.filter((d) => d.status === st).length;
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "stats", children: [_jsxs("div", { className: "stat", children: [_jsx("b", { children: count('requested') }), _jsx("span", { children: "Approval pending" })] }), _jsxs("div", { className: "stat", children: [_jsx("b", { children: count('approved') }), _jsx("span", { children: "Approved" })] }), _jsxs("div", { className: "stat", children: [_jsx("b", { children: deals.length }), _jsx("span", { children: "Kul deals" })] })] }), _jsx("div", { className: "tabs", children: FILTERS.map((f) => (_jsxs("button", { className: filter === f ? 'active' : '', onClick: () => setFilter(f), children: [LABEL[f], " (", deals.filter((d) => d.status === f).length, ")"] }, f))) }), err && _jsx(Notice, { kind: "error", children: err }), shown.length === 0 ? _jsx(Empty, { icon: "chat", title: "Is status mein koi deal nahi" }) : (_jsx("div", { className: "list", children: shown.map((d) => (_jsxs("div", { className: "card", children: [_jsxs("div", { className: "row between", children: [_jsxs("b", { children: [d.buyer?.full_name, " \u2194 ", d.seller?.full_name] }), _jsx(StatusChip, { status: d.status })] }), _jsx("div", { children: d.listing_title }), _jsxs("div", { className: "small muted", children: ["Listed ", money(d.listing_price), " \u00B7 Tay shuda ", money(d.agreed_price), " \u00B7 ", fmtDate(d.updated_at)] }), d.request_note && _jsxs("p", { className: "small", children: ["\uD83D\uDCDD ", d.request_note] }), _jsxs("div", { className: "row wrap", style: { marginTop: '.5rem' }, children: [can('view_contacts') && _jsx("button", { className: "btn ghost sm", onClick: () => toggle(d), children: open === d.id ? 'Contacts chhupayein' : 'Contacts dekhein' }), can('view_chats') && _jsx(Link, { className: "btn ghost sm", to: `/deal/${d.id}`, children: "Chat dekhein" })] }), open === d.id && (_jsxs("div", { className: "stack", style: { marginTop: '.6rem' }, children: [_jsx(ContactBox, { title: `Buyer: ${d.buyer?.full_name}`, c: contacts[d.buyer_id] }), _jsx(ContactBox, { title: `Seller: ${d.seller?.full_name}`, c: contacts[d.seller_id] })] })), can('approve_deals') && ['requested', 'approved'].includes(d.status) && (_jsxs("div", { className: "stack", style: { marginTop: '.6rem' }, children: [_jsx("input", { className: "input", placeholder: "Admin note (optional)", value: notes[d.id] || '', onChange: (e) => setNotes({ ...notes, [d.id]: e.target.value }) }), _jsxs("div", { className: "row", children: [d.status === 'requested' && _jsxs(_Fragment, { children: [_jsx("button", { className: "btn ok grow", onClick: () => decide(d, 'approved'), children: "Approve" }), _jsx("button", { className: "btn danger grow", onClick: () => decide(d, 'rejected'), children: "Reject" })] }), d.status === 'approved' && _jsx("button", { className: "btn grow", onClick: () => decide(d, 'completed'), children: "Kaam mukammal mark karein" })] })] }))] }, d.id))) }))] }));
}
