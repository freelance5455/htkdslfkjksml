import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import { Notice } from '../../components/Bits.js';
export default function AdminLayout() {
    const { can } = useAuth();
    const anything = ['approve_deals', 'view_chats', 'manage_users', 'manage_services', 'view_contacts'].some((p) => can(p));
    return (_jsxs(_Fragment, { children: [_jsx("h2", { children: "Admin panel" }), _jsxs("div", { className: "tabs", children: [(can('approve_deals') || can('view_chats')) && _jsx(NavLink, { end: true, to: "/admin", className: ({ isActive }) => (isActive ? 'active' : ''), children: "Deals" }), can('manage_users') && _jsx(NavLink, { to: "/admin/users", className: ({ isActive }) => (isActive ? 'active' : ''), children: "Users" }), can('manage_users') && _jsx(NavLink, { to: "/admin/activity", className: ({ isActive }) => (isActive ? 'active' : ''), children: "Activity" }), can('view_contacts') && _jsx(NavLink, { to: "/admin/map", className: ({ isActive }) => (isActive ? 'active' : ''), children: "Live map" }), can('manage_services') && _jsx(NavLink, { to: "/admin/services", className: ({ isActive }) => (isActive ? 'active' : ''), children: "Services" })] }), anything ? _jsx(Outlet, {}) : _jsx(Notice, { kind: "warn", children: "Aap ko abhi koi permission nahi mili. Main admin se kahein." })] }));
}
