import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase.js';
import { fmtDate } from '../../lib/util.js';
import { Empty } from '../../components/Bits.js';
export default function AdminActivity() {
    const [rows, setRows] = useState([]);
    const [onlyFlags, setOnlyFlags] = useState(true);
    useEffect(() => {
        const base = supabase.from('behavior_logs').select('*, user:profiles(full_name)');
        const filtered = onlyFlags ? base.in('event', ['contact_attempt', 'blocked']) : base;
        filtered.order('created_at', { ascending: false }).limit(200).then(({ data }) => setRows(data || []));
    }, [onlyFlags]);
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "tabs", children: [_jsx("button", { className: onlyFlags ? 'active' : '', onClick: () => setOnlyFlags(true), children: "Sirf shak wali" }), _jsx("button", { className: !onlyFlags ? 'active' : '', onClick: () => setOnlyFlags(false), children: "Saari activity" })] }), rows.length === 0 ? _jsx(Empty, { icon: "shieldCheck", title: "Kuch nahi mila" }) : (_jsx("div", { className: "list", children: rows.map((r) => (_jsxs(Link, { to: `/admin/users/${r.user_id}`, className: "card link", children: [_jsxs("div", { className: "row between", children: [_jsx("b", { children: r.user?.full_name || 'User' }), _jsx("span", { className: "small muted", children: fmtDate(r.created_at) })] }), _jsx("div", { className: "small", children: r.event === 'contact_attempt' ? '⚠️ Number/location share karne ki koshish' : r.event }), r.detail && _jsx("div", { className: "small muted clamp", children: r.detail })] }, r.id))) }))] }));
}
