import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase.js';
import { ago } from '../../lib/util.js';
import LiveMap from '../../components/LiveMap.js';
import { Empty, Avatar } from '../../components/Bits.js';
export default function AdminMap() {
    const [rows, setRows] = useState([]);
    const [loaded, setLoaded] = useState(false);
    const [, tick] = useState(0);
    useEffect(() => {
        let alive = true;
        const load = async () => {
            const { data } = await supabase.from('live_locations')
                .select('*, user:profiles(full_name, role), deal:deals(listing_title, seller_id, buyer_id)')
                .order('updated_at', { ascending: false });
            if (alive) {
                setRows(data || []);
                setLoaded(true);
                tick((n) => n + 1);
            }
        };
        load();
        const t = setInterval(load, 5000);
        return () => { alive = false; clearInterval(t); };
    }, []);
    const stale = (r) => Date.now() - new Date(r.updated_at).getTime() > 300000;
    const isSeller = (r) => r.deal?.seller_id === r.user_id;
    const markers = rows.map((r) => ({
        id: r.deal_id + r.user_id, lat: r.lat, lng: r.lng, stale: stale(r),
        color: isSeller(r) ? '#F5A524' : '#0A3D52',
        label: `${isSeller(r) ? 'Seller' : 'Buyer'}: ${r.user?.full_name || ''}`,
    }));
    const live = rows.filter((r) => !stale(r)).length;
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "stats", children: [_jsxs("div", { className: "stat", children: [_jsx("b", { children: live }), _jsx("span", { children: "Abhi live" })] }), _jsxs("div", { className: "stat", children: [_jsx("b", { children: rows.filter((r) => isSeller(r)).length }), _jsx("span", { children: "Sellers" })] }), _jsxs("div", { className: "stat", children: [_jsx("b", { children: rows.filter((r) => !isSeller(r)).length }), _jsx("span", { children: "Buyers" })] })] }), _jsxs("div", { className: "row small muted", style: { marginBottom: '.5rem' }, children: [_jsxs("span", { children: [_jsx("span", { className: "dotkey", style: { background: '#F5A524' } }), " Seller"] }), _jsxs("span", { children: [_jsx("span", { className: "dotkey", style: { background: '#0A3D52' } }), " Buyer"] }), _jsxs("span", { children: [_jsx("span", { className: "dotkey", style: { background: '#98A2B3' } }), " Purani (5 min+)"] })] }), _jsx(LiveMap, { markers: markers, height: 420 }), loaded && rows.length === 0 && _jsx(Empty, { icon: "pin", title: "Abhi koi live location nahi", text: "Jab approved deal ka seller ya buyer location share karega, wo yahan map par nazar aayega." }), _jsx("div", { className: "list", style: { marginTop: '.9rem' }, children: rows.map((r) => (_jsx(Link, { to: `/deal/${r.deal_id}`, className: "card link", children: _jsxs("div", { className: "row", children: [_jsx(Avatar, { name: r.user?.full_name, gold: isSeller(r) }), _jsxs("div", { className: "grow", children: [_jsx("b", { children: r.user?.full_name }), " ", _jsx("span", { className: `chip ${isSeller(r) ? 'gold' : ''}`, children: isSeller(r) ? 'Seller' : 'Buyer' }), _jsx("div", { className: "small muted", children: r.deal?.listing_title })] }), _jsx("span", { className: `chip ${stale(r) ? 'red' : 'green'}`, children: ago(r.updated_at) })] }) }, r.deal_id + r.user_id))) })] }));
}
