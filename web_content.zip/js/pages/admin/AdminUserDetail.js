import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../../lib/supabase.js';
import { useAuth } from '../../lib/AuthContext.js';
import { fmtDate, phoneDigits } from '../../lib/util.js';
import { Notice } from '../../components/Bits.js';
import { PERMISSIONS } from '../../lib/types.js';
const EVENT = {
    signup: '🆕 Signup', login: '🔑 Login', deal_started: '💬 Deal shuru', approval_requested: '📩 Approval request', booking_requested: '✅ Seedhi booking',
    contact_attempt: '⚠️ Number/location share karne ki koshish', location_shared: '📍 Live location share ki', blocked: '⛔ Block hua', unblocked: '✅ Unblock hua', admin_changed: '🛡️ Admin access badla',
};
export default function AdminUserDetail() {
    const { id } = useParams();
    const nav = useNavigate();
    const { can, profile: me } = useAuth();
    const [u, setU] = useState(null);
    const [prof, setProf] = useState(null);
    const [contact, setContact] = useState(null);
    const [notes, setNotes] = useState([]);
    const [logs, setLogs] = useState([]);
    const [noteKind, setNoteKind] = useState('note');
    const [noteText, setNoteText] = useState('');
    const [isAdm, setIsAdm] = useState(false);
    const [perms, setPerms] = useState([]);
    const [err, setErr] = useState('');
    const [msg, setMsg] = useState('');
    const load = useCallback(async () => {
        const [ov, p, n, l] = await Promise.all([
            supabase.rpc('admin_user_overview'),
            supabase.from('profiles').select('*').eq('id', id).maybeSingle(),
            supabase.from('user_notes').select('*, admin:profiles!user_notes_admin_id_fkey(full_name)').eq('user_id', id).order('created_at', { ascending: false }),
            supabase.from('behavior_logs').select('*').eq('user_id', id).order('created_at', { ascending: false }).limit(100),
        ]);
        const row = (ov.data || []).find((r) => r.id === id) || null;
        setU(row ? { ...row, violations: Number(row.violations), deals: Number(row.deals) } : null);
        const pr = p.data;
        setProf(pr);
        if (pr) {
            setIsAdm(pr.is_admin);
            setPerms(pr.permissions || []);
        }
        setNotes(n.data || []);
        setLogs(l.data || []);
        if (can('view_contacts')) {
            const { data } = await supabase.from('private_contacts').select('*').eq('user_id', id).maybeSingle();
            setContact(data);
        }
    }, [id, can]);
    useEffect(() => { load(); }, [load]);
    async function run(fn, ok = '') {
        setErr('');
        setMsg('');
        const { error } = await fn();
        if (error)
            return setErr(error.message);
        if (ok)
            setMsg(ok);
        load();
    }
    async function addNote(e) {
        e.preventDefault();
        if (!noteText.trim() || !me)
            return;
        await run(() => supabase.from('user_notes').insert({ user_id: id, admin_id: me.id, kind: noteKind, body: noteText.trim() }));
        setNoteText('');
    }
    async function del() {
        if (!confirm(`${u?.full_name} ko hamesha ke liye delete karein? Is ki saari deals aur chats bhi ud jayengi.`))
            return;
        setErr('');
        const { error } = await supabase.rpc('admin_delete_user', { p_user: id });
        if (error)
            return setErr(error.message);
        nav('/admin/users', { replace: true });
    }
    if (!u || !prof)
        return _jsx("p", { className: "muted center", children: "Load ho raha hai..." });
    const self = me?.id === prof.id;
    return (_jsxs(_Fragment, { children: [_jsx(Link, { to: "/admin/users", className: "small", children: "\u2190 Users" }), _jsxs("div", { className: "card", style: { marginTop: '.4rem' }, children: [_jsxs("div", { className: "row between", children: [_jsx("h2", { style: { margin: 0 }, children: u.full_name || '(naam nahi)' }), _jsxs("span", { className: "row", children: [prof.is_super && _jsx("span", { className: "chip gold", children: "Main admin" }), prof.is_admin && !prof.is_super && _jsx("span", { className: "chip gold", children: "Admin" }), prof.is_blocked && _jsx("span", { className: "chip red", children: "Blocked" })] })] }), _jsxs("p", { className: "small muted", children: [prof.role === 'seller' ? 'Seller' : prof.role === 'buyer' ? 'Buyer' : 'Role nahi', " \u00B7 Join: ", fmtDate(prof.created_at), " \u00B7 ", u.deals, " deals \u00B7 ", u.violations, " number/location koshish"] }), contact ? (_jsxs("p", { className: "small", children: ["\uD83D\uDCDE ", contact.phone || '-', _jsx("br", {}), "\u2709\uFE0F ", contact.email || '-', _jsx("br", {}), "\uD83C\uDFD9\uFE0F ", contact.city || '-', _jsx("br", {}), "\uD83D\uDCCD ", contact.address || '-'] })) : (!can('view_contacts') && _jsx("p", { className: "small muted", children: "Contact dekhne ki permission nahi." })), contact?.phone && (_jsxs("div", { className: "row", children: [_jsx("a", { className: "btn sm", href: `tel:${contact.phone}`, children: "Call" }), _jsx("a", { className: "btn ok sm", target: "_blank", rel: "noreferrer", href: `https://wa.me/${phoneDigits(contact.phone)}`, children: "WhatsApp" })] }))] }), err && _jsx(Notice, { kind: "error", children: err }), msg && _jsx(Notice, { kind: "ok", children: msg }), !prof.is_super && !self && (_jsxs("div", { className: "row wrap", style: { margin: '.8rem 0' }, children: [_jsx("button", { className: `btn sm ${prof.is_blocked ? 'ok' : 'ghost'}`, onClick: () => run(() => supabase.rpc('admin_set_blocked', { p_user: id, p_blocked: !prof.is_blocked })), children: prof.is_blocked ? 'Unblock karein' : 'Block karein' }), _jsx("button", { className: "btn danger sm", onClick: del, children: "Delete user" })] })), can('manage_admins') && !prof.is_super && !self && (_jsxs("div", { className: "card", style: { margin: '.8rem 0' }, children: [_jsx("h3", { children: "Admin access" }), _jsxs("label", { className: "perm", children: [_jsx("input", { type: "checkbox", checked: isAdm, onChange: (e) => setIsAdm(e.target.checked) }), _jsx("b", { children: "Is user ko admin banayein" })] }), isAdm && PERMISSIONS.map((p) => (_jsxs("label", { className: "perm", children: [_jsx("input", { type: "checkbox", checked: perms.includes(p.key), onChange: (e) => setPerms(e.target.checked ? [...perms, p.key] : perms.filter((x) => x !== p.key)) }), _jsx("span", { children: p.label })] }, p.key))), _jsx("button", { className: "btn primary sm", style: { marginTop: '.5rem' }, onClick: () => run(() => supabase.rpc('admin_set_admin', { p_user: id, p_is_admin: isAdm, p_perms: perms }), 'Admin access save ho gaya.'), children: "Save karein" })] })), _jsxs("div", { className: "card", style: { margin: '.8rem 0' }, children: [_jsx("h3", { children: "Admin notes (behavior)" }), _jsxs("form", { className: "stack", onSubmit: addNote, children: [_jsxs("div", { className: "row", children: [_jsxs("select", { className: "input", style: { width: 'auto' }, value: noteKind, onChange: (e) => setNoteKind(e.target.value), children: [_jsx("option", { value: "note", children: "\uD83D\uDCDD Note" }), _jsx("option", { value: "warning", children: "\u26A0\uFE0F Warning" }), _jsx("option", { value: "praise", children: "\uD83D\uDC4D Acha behavior" })] }), _jsx("input", { className: "input", placeholder: "User ke baare mein likhein...", value: noteText, onChange: (e) => setNoteText(e.target.value) })] }), _jsx("button", { className: "btn sm", disabled: !noteText.trim(), children: "Note save karein" })] }), _jsxs("div", { className: "list", style: { marginTop: '.7rem' }, children: [notes.length === 0 && _jsx("p", { className: "muted small", children: "Abhi koi note nahi." }), notes.map((n) => (_jsxs("div", { className: "notice", style: { background: n.kind === 'warning' ? '#FFF1CC' : n.kind === 'praise' ? '#D8F3E6' : 'var(--sky)' }, children: [_jsxs("div", { children: [n.kind === 'warning' ? '⚠️' : n.kind === 'praise' ? '👍' : '📝', " ", n.body] }), _jsxs("div", { className: "small muted", children: [n.admin?.full_name || 'Admin', " \u00B7 ", fmtDate(n.created_at), _jsx("button", { className: "btn ghost sm", style: { marginLeft: '.5rem' }, onClick: () => run(() => supabase.from('user_notes').delete().eq('id', n.id)), children: "Hatayein" })] })] }, n.id)))] })] }), _jsxs("div", { className: "card", children: [_jsx("h3", { children: "Activity" }), logs.length === 0 ? _jsx("p", { className: "muted small", children: "Koi activity nahi." }) : (_jsx("table", { className: "t", children: _jsx("tbody", { children: logs.map((l) => (_jsxs("tr", { children: [_jsxs("td", { children: [EVENT[l.event] || l.event, l.detail && _jsx("div", { className: "small muted", children: l.detail })] }), _jsx("td", { className: "small muted", style: { whiteSpace: 'nowrap' }, children: fmtDate(l.created_at) })] }, l.id))) }) }))] })] }));
}
