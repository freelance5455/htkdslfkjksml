import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useCallback, useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { geoErrorText, money } from '../lib/util.js';
import { Empty, Notice } from '../components/Bits.js';
import Icon, { ServiceIcon } from '../components/Icon.js';
import LiveMap from '../components/LiveMap.js';
import { PRICE_UNITS } from '../lib/types.js';
const UNIT_LABEL = {
    'per kaam': 'Ek kaam ka', 'per din': 'Roz (din) ka', 'per ghanta': 'Ghante ka', 'per visit': 'Ek visit ka', 'per sq ft': 'Per sq ft',
};
const QUICK_PRICES = [300, 500, 1000, 1500, 2000, 3000, 5000];
export default function SellerDashboard() {
    const { profile, contact } = useAuth();
    const [services, setServices] = useState([]);
    const [items, setItems] = useState([]);
    const [form, setForm] = useState(null);
    const [step, setStep] = useState(1);
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);
    const [listening, setListening] = useState(false);
    const load = useCallback(async () => {
        if (!profile)
            return;
        const [s, l] = await Promise.all([
            supabase.from('services').select('*').eq('active', true).order('sort'),
            supabase.from('listings').select('*').eq('seller_id', profile.id).order('created_at', { ascending: false }),
        ]);
        setServices(s.data || []);
        setItems(l.data || []);
    }, [profile]);
    useEffect(() => { load(); }, [load]);
    if (profile?.role === 'buyer')
        return _jsx(Navigate, { to: "/home", replace: true });
    const svc = (id) => services.find((s) => s.id === id);
    const blank = () => ({ service_id: '', title: '', details: '', price: '', price_unit: 'per din', city: contact?.city || '', experience: 0, lat: null, lng: null });
    const set = (p) => setForm((f) => (f ? { ...f, ...p } : f));
    const open = (f) => { setErr(''); setStep(1); setForm(f); };
    function useGps() {
        setErr('');
        if (!navigator.geolocation)
            return setErr('Browser location support nahi karta. Map par tap karein.');
        navigator.geolocation.getCurrentPosition((p) => set({ lat: p.coords.latitude, lng: p.coords.longitude }), (e) => setErr(geoErrorText(e.code) + ' Ya neeche map par apni jagah tap karein.'), { enableHighAccuracy: true, timeout: 15000 });
    }
    function speak() {
        const SR = window; // eslint-disable-line @typescript-eslint/no-explicit-any
        const Rec = SR.SpeechRecognition || SR.webkitSpeechRecognition;
        if (!Rec)
            return setErr('Is browser mein bol kar likhna nahi chalta. Chrome istemal karein.');
        const r = new Rec();
        r.lang = 'ur-PK';
        r.onresult = (e) => set({ details: ((form?.details || '') + ' ' + e.results[0][0].transcript).trim() }); // eslint-disable-line @typescript-eslint/no-explicit-any
        r.onend = () => setListening(false);
        r.onerror = () => setListening(false);
        setListening(true);
        r.start();
    }
    async function save() {
        if (!form || !profile)
            return;
        setBusy(true);
        setErr('');
        const name = svc(form.service_id)?.name || 'Service';
        const row = {
            service_id: form.service_id, title: form.title.trim() || name, details: form.details.trim(),
            price: Number(form.price), price_unit: form.price_unit, city: form.city.trim(),
            experience_years: form.experience, lat: form.lat, lng: form.lng,
        };
        const res = form.id
            ? await supabase.from('listings').update(row).eq('id', form.id)
            : await supabase.from('listings').insert({ ...row, seller_id: profile.id });
        setBusy(false);
        if (res.error)
            return setErr(res.error.message);
        setForm(null);
        load();
    }
    async function toggle(l) { await supabase.from('listings').update({ active: !l.active }).eq('id', l.id); load(); }
    async function remove(l) {
        if (!confirm('Ye service hamesha ke liye hata dein?'))
            return;
        await supabase.from('listings').delete().eq('id', l.id);
        load();
    }
    const canNext = step === 1 ? !!form?.service_id : step === 2 ? Number(form?.price) > 0 : !!form?.city.trim();
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "hero", children: [_jsx("h1", { children: "Meri services" }), _jsx("p", { children: "Apna kaam add karein, buyers aap ko dhoond kar baat karenge. Aap ka number kisi ko nahi dikhta." }), _jsxs("button", { className: "btn primary xl", onClick: () => open(blank()), children: [_jsx(Icon, { name: "plus", size: 22 }), " Naya kaam add karein"] })] }), items.length === 0 ? (_jsx(Empty, { icon: "briefcase", title: "Abhi koi kaam add nahi", text: "Upar wala bara button dabayein. Sirf 3 qadam hain." })) : (_jsx("div", { className: "list", children: items.map((l) => (_jsxs("div", { className: "card", children: [_jsxs("div", { className: "row between", children: [_jsx("span", { className: "chip", children: svc(l.service_id)?.name }), _jsxs("span", { className: "row", children: [_jsx("span", { className: `chip ${l.active ? 'green' : 'red'}`, children: l.active ? 'Live' : 'Band' }), l.lat == null && _jsx("span", { className: "chip gold", children: "Map par location nahi" })] })] }), _jsx("h3", { style: { marginTop: '.5rem' }, children: l.title }), _jsxs("div", { className: "price", children: [money(l.price), " ", _jsxs("span", { className: "small muted", children: [UNIT_LABEL[l.price_unit] || l.price_unit, " \u00B7 ", l.city] })] }), _jsxs("div", { className: "row wrap", style: { marginTop: '.6rem' }, children: [_jsxs("button", { className: "btn sm", onClick: () => open({ id: l.id, service_id: l.service_id, title: l.title, details: l.details, price: String(l.price), price_unit: l.price_unit, city: l.city, experience: l.experience_years, lat: l.lat ?? null, lng: l.lng ?? null }), children: [_jsx(Icon, { name: "edit", size: 15 }), " Badlein"] }), _jsx("button", { className: "btn ghost sm", onClick: () => toggle(l), children: l.active ? 'Band karein' : 'Live karein' }), _jsx("button", { className: "btn danger sm", onClick: () => remove(l), children: _jsx(Icon, { name: "trash", size: 15 }) })] })] }, l.id))) })), form && (_jsx("div", { className: "modal-bg", onClick: () => setForm(null), children: _jsxs("div", { className: "modal", onClick: (e) => e.stopPropagation(), children: [_jsxs("div", { className: "row between", style: { marginBottom: '.6rem' }, children: [_jsxs("span", { className: "small muted", children: ["Qadam ", step, " / 3"] }), _jsx("div", { className: "dots", children: [1, 2, 3].map((n) => _jsx("i", { className: n <= step ? 'on' : '' }, n)) })] }), step === 1 && (_jsxs(_Fragment, { children: [_jsx("h2", { children: "Aap kaun sa kaam karte hain?" }), _jsx("div", { className: "tiles pick-grid", children: services.map((s) => (_jsxs("button", { type: "button", className: `tile pick ${form.service_id === s.id ? 'on' : ''}`, style: { '--c': s.color }, onClick: () => set({ service_id: s.id }), children: [_jsx("div", { className: "ic-box", children: _jsx(ServiceIcon, { slug: s.slug, emoji: s.emoji, size: 24 }) }), _jsx("b", { children: s.name })] }, s.id))) })] })), step === 2 && (_jsxs(_Fragment, { children: [_jsx("h2", { children: "Aap kitne paise lete hain?" }), _jsxs("div", { className: "price-box", children: [_jsx("span", { children: "Rs" }), _jsx("input", { inputMode: "numeric", autoFocus: true, placeholder: "0", value: form.price, onChange: (e) => set({ price: e.target.value.replace(/\D/g, '').slice(0, 7) }) })] }), _jsx("div", { className: "chips", children: QUICK_PRICES.map((p) => _jsx("button", { type: "button", className: `chipbtn ${form.price === String(p) ? 'on' : ''}`, onClick: () => set({ price: String(p) }), children: p }, p)) }), _jsx("p", { className: "eyebrow", style: { marginTop: '1rem' }, children: "Ye price kis ki hai?" }), _jsx("div", { className: "units", children: PRICE_UNITS.map((u) => _jsx("button", { type: "button", className: `unit ${form.price_unit === u ? 'on' : ''}`, onClick: () => set({ price_unit: u }), children: UNIT_LABEL[u] || u }, u)) }), _jsx("p", { className: "eyebrow", style: { marginTop: '1rem' }, children: "Kitne saal ka tajurba?" }), _jsxs("div", { className: "stepper-num", children: [_jsx("button", { type: "button", onClick: () => set({ experience: Math.max(0, form.experience - 1) }), "aria-label": "Kam", children: "\u2212" }), _jsx("b", { children: form.experience }), _jsx("button", { type: "button", onClick: () => set({ experience: Math.min(60, form.experience + 1) }), "aria-label": "Zyada", children: "+" }), _jsx("span", { className: "muted", children: "saal" })] })] })), step === 3 && (_jsxs(_Fragment, { children: [_jsx("h2", { children: "Aap kahan kaam karte hain?" }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Shehar" }), _jsx("input", { className: "input", value: form.city, onChange: (e) => set({ city: e.target.value }) })] }), _jsxs("button", { type: "button", className: "btn ok block xl", style: { marginTop: '.8rem' }, onClick: useGps, children: [_jsx(Icon, { name: "pin", size: 22 }), " ", form.lat !== null ? 'Location lag gayi (dobara lein)' : 'Meri jagah lagayein'] }), _jsx("div", { style: { marginTop: '.7rem' }, children: _jsx(LiveMap, { height: 200, markers: form.lat !== null && form.lng !== null ? [{ id: 'loc', lat: form.lat, lng: form.lng, color: '#F5A524', label: 'Meri service' }] : [], onMapClick: (lat, lng) => set({ lat, lng }) }) }), _jsx("p", { className: "small muted", style: { margin: '.4rem 0 0' }, children: form.lat !== null ? 'Theek hai. Galat ho to map par sahi jagah tap karein.' : 'Location ke baghair aap buyers ke map par nazar nahi aayenge. Map par tap bhi kar sakte hain.' }), _jsxs("details", { style: { marginTop: '.9rem' }, children: [_jsx("summary", { style: { cursor: 'pointer', fontWeight: 700 }, children: "Zyada detail likhein (zaroori nahi)" }), _jsxs("div", { className: "stack", style: { marginTop: '.6rem' }, children: [_jsx("input", { className: "input", maxLength: 80, placeholder: `Title (jaise: ${svc(form.service_id)?.name || 'Plumber'}, 10 saal tajurba)`, value: form.title, onChange: (e) => set({ title: e.target.value }) }), _jsx("textarea", { className: "input", placeholder: "Aap kya kaam karte hain...", value: form.details, onChange: (e) => set({ details: e.target.value }) }), _jsx("button", { type: "button", className: "btn ghost sm", onClick: speak, disabled: listening, children: listening ? 'Sun raha hoon... boliye' : 'Bol kar likhein' })] })] }), _jsx(Notice, { kind: "warn", children: "Phone number, link ya address likhna mana hai." })] })), err && _jsx(Notice, { kind: "error", children: err }), _jsxs("div", { className: "row", style: { marginTop: '1rem' }, children: [step > 1
                                    ? _jsx("button", { type: "button", className: "btn ghost xl grow", onClick: () => setStep(step - 1), children: "Wapas" })
                                    : _jsx("button", { type: "button", className: "btn ghost xl grow", onClick: () => setForm(null), children: "Band karein" }), step < 3
                                    ? _jsx("button", { type: "button", className: "btn primary xl grow", disabled: !canNext, onClick: () => setStep(step + 1), children: "Aage" })
                                    : _jsxs("button", { type: "button", className: "btn primary xl grow", disabled: !canNext || busy, onClick: save, children: [_jsx(Icon, { name: "check", size: 20 }), " ", busy ? '...' : 'Save'] })] })] }) }))] }));
}
