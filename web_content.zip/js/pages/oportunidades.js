(function(){
  const sessao = Auth.exigirPerfil('profissional');
  if(!sessao) return;
  aplicarSessaoNoCabecalho();
  atualizarBadgeNotificacoes(sessao.id);

  const provider = ProvidersService.obterPorUsuario(sessao.id);
  const DEV = window.APP_CONFIG.ENV === 'dev';
  const CENTRO_PG = window.APP_CONFIG.PRAIA_GRANDE_CENTRO;
  const BOUNDS_PG = window.APP_CONFIG.PRAIA_GRANDE_BOUNDS;

  let posicaoAtual = null;
  let posicaoSimulada = false;
  let mapa = null;
  let marcadores = [];
  let marcadorEu = null;
  let selecionadaId = null;   // id da oportunidade destacada (selecionada na lista/mapa)
  let ultimaFiltradas = [];   // cache da última lista renderizada (evita recalcular tudo ao só destacar)

  // ---------- Perfil ainda não aprovado ----------
  if(provider.status !== 'aprovado'){
    document.querySelector('.map-wrap').outerHTML = `
      <div class="empty-state card-soft mx-5 mt-4">
        <i data-lucide="clock"></i>
        <p>${provider.status === 'pendente'
            ? 'Seu perfil ainda está pendente de aprovação pelo administrador. Assim que aprovado, as oportunidades aparecerão aqui.'
            : 'Seu perfil está suspenso. Fale com o suporte para mais detalhes.'}</p>
      </div>`;
    document.querySelector('.bottom-sheet').classList.add('hidden');
    return;
  }

  if(provider.categorias.length === 0){
    document.getElementById('geoBanner').innerHTML = `
      <div class="geo-banner">
        <i data-lucide="alert-triangle"></i>
        <span>Você ainda não escolheu categorias de atuação. <a href="home-profissional.html" class="underline font-semibold">Configure seu perfil</a> para ver oportunidades.</span>
      </div>`;
  }

  // ---------- Aparência por categoria (cor + ícone do marcador) ----------
  const CATEGORIA_VISUAL = {
    [CATEGORIAS_SERVICO.LIMPEZA]:  { cor: '#1856D6', icone: 'sparkles',    rotulo: 'Faxina' },
    [CATEGORIAS_SERVICO.REPAROS]:  { cor: '#E8A93A', icone: 'wrench',      rotulo: 'Manutenção' },
    [CATEGORIAS_SERVICO.ENXOVAL]:  { cor: '#10A7C9', icone: 'bed-double',  rotulo: 'Roupa de cama' },
  };
  function visualDaCategoria(categoria){
    return CATEGORIA_VISUAL[categoria] || { cor: '#64708A', icone: 'circle-dot', rotulo: categoria };
  }

  // ---------- Etapa 3: valor, valor/km e indicação de proximidade ----------
  // Nunca altera o valor do serviço — apenas calcula/exibe métricas derivadas
  // a partir do mesmo valor e da mesma distância (Haversine) já usados no
  // restante da tela (PricingService.aplicarDeslocamento + distanciaKm).
  function valorEstimadoOp(op){
    const preco = op.precificacao;
    if(!preco || preco.necessitaAvaliacao) return null;
    if(posicaoAtual && op._distanciaKm != null){
      return PricingService.aplicarDeslocamento(preco.valorProfissional, op._distanciaKm).valorLiquido;
    }
    return preco.valorProfissional;
  }
  function valorPorKmOp(op){
    const valor = valorEstimadoOp(op);
    if(valor == null || op._distanciaKm == null || op._distanciaKm <= 0) return null;
    return valor / op._distanciaKm;
  }
  /** Faixas de proximidade — só para indicação visual, nunca mudam preço. */
  function classeProximidade(distKm){
    if(distKm == null) return null;
    if(distKm <= 2) return { classe:'perto', rotulo:'Próxima' };
    if(distKm <= 5) return { classe:'medio', rotulo:'Intermediária' };
    return { classe:'longe', rotulo:'Distante' };
  }
  function tagProximidadeHtml(distKm){
    const p = classeProximidade(distKm);
    return p ? `<span class="proximidade-tag ${p.classe}">${p.rotulo}</span>` : '';
  }

  // ---------- Distância em linha de rota (quando disponível) ----------
  // Serviço público de roteamento (mesmo padrão já usado no projeto para
  // CEP/geocodificação: ViaCEP e Nominatim em imovel-form.js) — usado apenas
  // para exibir a distância real de deslocamento por via, além da distância
  // em linha reta (Haversine). Se indisponível (sem internet, serviço fora
  // do ar, sem coordenadas), simplesmente não mostramos a informação —
  // nunca inventamos um valor.
  async function buscarDistanciaRotaKm(origem, destino){
    if(typeof fetch === 'undefined') return null;
    try{
      const url = `https://router.project-osrm.org/route/v1/driving/${origem.lng},${origem.lat};${destino.lng},${destino.lat}?overview=false`;
      const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      const timeoutId = controller ? setTimeout(() => controller.abort(), 6000) : null;
      const resp = await fetch(url, controller ? { signal: controller.signal } : undefined);
      if(timeoutId) clearTimeout(timeoutId);
      if(!resp.ok) return null;
      const data = await resp.json();
      if(data.code !== 'Ok' || !data.routes || !data.routes[0]) return null;
      return Math.round((data.routes[0].distance / 1000) * 10) / 10;
    }catch(e){
      return null; // sem conexão/serviço indisponível — não bloqueia a tela
    }
  }

  // ---------- Mapa (Leaflet) — restrito à área de Praia Grande/SP ----------
  // Em conexões móveis instáveis o CDN do Leaflet pode falhar; sem essa
  // proteção a página quebrava com "L is not defined" e a lista de
  // oportunidades (que não depende do mapa) ficava inacessível também.
  const mapaIndisponivel = typeof L === 'undefined';
  if(mapaIndisponivel){
    document.getElementById('mapaOportunidades').innerHTML = `
      <div class="empty-state card-soft" style="height:100%; margin:0; display:flex; flex-direction:column; align-items:center; justify-content:center;">
        <i data-lucide="map-off"></i>
        <p>Não foi possível carregar o mapa (conexão instável). A lista de oportunidades abaixo continua funcionando normalmente.</p>
      </div>`;
    if(window.lucide) lucide.createIcons();
  }

  function limitesPraiaGrande(){
    return L.latLngBounds([BOUNDS_PG.sw.lat, BOUNDS_PG.sw.lng], [BOUNDS_PG.ne.lat, BOUNDS_PG.ne.lng]);
  }

  /** Um imóvel só entra no Mapa de Oportunidades de Praia Grande se a cidade
   * cadastrada (campo exato, escolhido a partir de GEO_BRASIL no formulário
   * do imóvel) for Praia Grande. Não usamos a bounding box para decidir isso:
   * cidades vizinhas (Santos, São Vicente, Mongaguá) ficam geograficamente
   * muito próximas e uma bounding box aproximada poderia incluí-las por
   * engano — o campo "cidade" já é um dado exato e confiável. */
  function estaEmPraiaGrande(imovel){
    if(!imovel) return false;
    return imovel.cidade === window.APP_CONFIG.CIDADE_PILOTO;
  }

  function initMapa(){
    if(mapaIndisponivel) return;
    const b = limitesPraiaGrande();
    mapa = L.map('mapaOportunidades', { zoomControl:false, maxBoundsViscosity:1.0 });
    const T = window.APP_CONFIG.MAPA_TILES;
    L.tileLayer(T.url, {
      attribution: T.attribution,
      subdomains: T.subdomains,
      maxZoom: T.maxZoom,
    }).addTo(mapa);
    // Zoom mínimo calculado em tempo de execução como o menor zoom em que a
    // extensão INTEIRA do piloto (do Canto do Forte a Solemar) cabe no
    // contêiner do mapa — um valor fixo (ex.: 12) tanto pode cortar bairros
    // em telas menores/estreitas quanto travar o zoom-out em telas maiores.
    // Sempre recalculado a partir de `limitesPraiaGrande()`, então nunca
    // fica preso a uma região específica: abre mostrando a cidade inteira e
    // nunca deixa dar zoom-out além disso nem entrar em área fora dela.
    const zoomMinCidade = mapa.getBoundsZoom(b, false);
    mapa.setMinZoom(zoomMinCidade);
    mapa.setMaxBounds(b);
    mapa.fitBounds(b);
  }

  function desenharMarcadorEu(pos){
    if(!mapa) return;
    if(marcadorEu) mapa.removeLayer(marcadorEu);
    const icon = L.divIcon({
      className: '',
      html: `<div class="marker-pin-eu ${posicaoSimulada ? 'simulado' : ''}"></div>`,
      iconSize: [20,20], iconAnchor: [10,10],
    });
    marcadorEu = L.marker([pos.lat, pos.lng], { icon, zIndexOffset: 1000 }).addTo(mapa)
      .bindTooltip(posicaoSimulada ? 'Você está aqui (simulado — DEV)' : 'Você está aqui');
  }

  function limparMarcadores(){ marcadores.forEach(m => mapa.removeLayer(m)); marcadores = []; }

  function iconeOportunidade(op, selecionada){
    const v = visualDaCategoria(op.categoria);
    const urgente = op.urgencia === 'Urgente (poucas horas)';
    const classes = ['marker-pin'];
    if(urgente) classes.push('urgente');
    if(selecionada) classes.push('selecionado');
    return L.divIcon({
      className: '',
      html: `<div class="${classes.join(' ')}" style="background:${v.cor}"><i data-lucide="${v.icone}"></i></div>`,
      iconSize: selecionada ? [40,40] : [34,34],
      iconAnchor: selecionada ? [20,40] : [17,34],
      popupAnchor: [0,-30],
    });
  }

  function desenharMarcadores(oportunidades){
    if(!mapa) return;
    limparMarcadores();
    oportunidades.forEach(op => {
      if(!op._imovel || op._imovel.latitude == null || op._imovel.longitude == null) return;
      const selecionada = op.id === selecionadaId;
      const marker = L.marker([op._imovel.latitude, op._imovel.longitude], { icon: iconeOportunidade(op, selecionada) }).addTo(mapa);
      marker.bindPopup(popupOportunidade(op), { closeButton:true, className:'popup-op-wrap' });
      // Mostra no mapa a distância entre o profissional e cada oportunidade
      // (etiqueta permanente sobre o marcador — mais legível no celular do
      // que múltiplas linhas ligando os pontos).
      if(posicaoAtual && op._distanciaKm != null){
        marker.bindTooltip(`${op._distanciaKm} km`, { permanent:true, direction:'top', offset:[0,-30], className:'marker-dist-label' });
      }
      marker.on('popupopen', () => {
        refreshIcons();
        const btn = document.querySelector(`[data-popup-detalhe="${op.id}"]`);
        if(btn) btn.onclick = () => abrirDetalhe(op);
        // Sincroniza o destaque na lista sem redesenhar os marcadores
        // (redesenhar fecharia o popup que acabou de abrir).
        selecionadaId = op.id;
        renderLista(ultimaFiltradas);
      });
      marker._opId = op.id;
      marcadores.push(marker);
    });
    refreshIcons();
  }

  function popupOportunidade(op){
    const v = visualDaCategoria(op.categoria);
    const distTxt = op._distanciaKm != null ? `${op._distanciaKm} km` : 'distância indisponível';
    const valorNum = valorEstimadoOp(op);
    const valorTxt = valorNum != null ? 'R$ ' + valorNum.toFixed(2) : 'A combinar';
    const valorPorKmNum = valorPorKmOp(op);
    return `
      <div class="popup-op">
        <p class="popup-op-cat" style="color:${v.cor}"><i data-lucide="${v.icone}" style="width:14px;height:14px"></i> ${op.categoria} ${tagProximidadeHtml(op._distanciaKm)}</p>
        <p class="popup-op-linha"><i data-lucide="map-pin" class="icon-inline"></i> ${distTxt}</p>
        <p class="popup-op-linha"><i data-lucide="clock-3" class="icon-inline"></i> ${formatarData(op.data)} · ${op.horario}</p>
        ${valorPorKmNum != null ? `<p class="popup-op-linha">R$ ${valorPorKmNum.toFixed(2)}/km</p>` : ''}
        <p class="popup-op-valor">${valorTxt}</p>
        <button type="button" data-popup-detalhe="${op.id}">Ver detalhes</button>
      </div>`;
  }

  // ---------- Geolocalização real ----------
  function mostrarBannerGeo(mensagem){
    document.getElementById('geoBanner').innerHTML = `
      <div class="geo-banner">
        <i data-lucide="map-pin-off"></i>
        <span>${mensagem} As oportunidades abaixo continuam disponíveis, mas sem ordenação por distância.</span>
      </div>`;
    refreshIcons();
  }

  function aplicarPosicao(pos, simulado){
    posicaoAtual = pos;
    posicaoSimulada = simulado;
    if(!mapa) return;
    desenharMarcadorEu(pos);
    render();
  }

  function carregarComPosicao(pos){
    document.getElementById('geoBanner').innerHTML = '';
    if(pos.precisao > 500){
      mostrarBannerGeo(`Sua localização foi obtida com baixa precisão (~${Math.round(pos.precisao)}m).`);
    }
    aplicarPosicao(pos, false);
  }

  function tentarGeolocalizar(){
    GeoLocation.obterPosicaoAtual().then(carregarComPosicao).catch(err => {
      mostrarBannerGeo(err.message);
      render();
    });
  }

  if(!mapaIndisponivel) initMapa();
  document.getElementById('btnLocalizar').addEventListener('click', () => {
    if(DEV && modoSimulado){ mostrarToast('Localização simulada ativa (ambiente DEV). Desative para usar o GPS real.'); return; }
    tentarGeolocalizar();
  });
  document.getElementById('btnCentralizarEu').addEventListener('click', () => {
    if(!posicaoAtual){ mostrarToast('Ative sua localização (ou simule, em DEV) para centralizar.'); return; }
    if(mapa) mapa.setView([posicaoAtual.lat, posicaoAtual.lng], Math.max(mapa.getZoom ? mapa.getZoom() : 15, 15));
  });
  tentarGeolocalizar();

  // ---------- EMULADOR DE LOCALIZAÇÃO — exclusivo do Ambiente DEV ----------
  // Mesmo padrão usado em execucao.js: permite testar marcadores e distância
  // sem depender de GPS físico. Nunca ativo em produção (ENV=prod).
  let modoSimulado = false;
  let posSimulada = { lat: null, lng: null };

  function renderPainelDevLocal(){
    if(!DEV) return;
    document.getElementById('painelDevLocal').innerHTML = `
      <div class="dev-painel-local">
        <div class="flex items-center justify-between mb-2">
          <span class="dev-titulo">🧪 Localização (somente ambiente DEV)</span>
          <label class="flex items-center gap-1 text-[12px]">
            <input type="checkbox" id="chkModoSimuladoOp" ${modoSimulado?'checked':''}> Simular
          </label>
        </div>
        <div id="camposPosSimuladaOp" style="${modoSimulado?'':'display:none'}">
          <div class="flex gap-2 mb-2">
            <input id="simLatOp" type="number" step="any" placeholder="Latitude" class="field-input" value="${posSimulada.lat ?? ''}">
            <input id="simLngOp" type="number" step="any" placeholder="Longitude" class="field-input" value="${posSimulada.lng ?? ''}">
          </div>
          <button type="button" id="btnCentroPG" class="text-[12px] font-semibold underline">Usar centro de Praia Grande</button>
        </div>
      </div>`;
    refreshIcons();

    const chk = document.getElementById('chkModoSimuladoOp');
    chk.onchange = () => {
      modoSimulado = chk.checked;
      document.getElementById('camposPosSimuladaOp').style.display = modoSimulado ? '' : 'none';
      if(modoSimulado && posSimulada.lat != null && posSimulada.lng != null){
        aplicarPosicao({ lat: posSimulada.lat, lng: posSimulada.lng, precisao: null }, true);
      } else if(!modoSimulado){
        tentarGeolocalizar();
      }
    };
    const simLat = document.getElementById('simLatOp'), simLng = document.getElementById('simLngOp');
    const lerCampos = () => {
      posSimulada = { lat: simLat.value ? Number(simLat.value) : null, lng: simLng.value ? Number(simLng.value) : null };
      if(modoSimulado && posSimulada.lat != null && posSimulada.lng != null){
        aplicarPosicao({ lat: posSimulada.lat, lng: posSimulada.lng, precisao: null }, true);
      }
    };
    simLat.oninput = lerCampos;
    simLng.oninput = lerCampos;
    document.getElementById('btnCentroPG').onclick = () => {
      simLat.value = CENTRO_PG.lat;
      simLng.value = CENTRO_PG.lng;
      lerCampos();
    };
  }
  renderPainelDevLocal();

  // ---------- Categoria ----------
  // Removido o filtro de categoria (chips "Todos/Faxina/Manutenção/Roupa de
  // cama"): o profissional só recebe oportunidades da própria categoria
  // cadastrada (Matching.oportunidadesPara já restringe por categoria antes
  // de qualquer outra coisa), então mostrar chips de outras categorias era
  // enganoso — sugeria que ele poderia enxergar/filtrar oportunidades de
  // outras categorias, quando na prática a lista já vem só com a dele.

  // ---------- Filtro de distância ----------
  let filtroDistanciaKm = null; // null = toda Praia Grande
  const CHIPS_DISTANCIA = [
    { valor: 1, rotulo: '1 km' },
    { valor: 3, rotulo: '3 km' },
    { valor: 5, rotulo: '5 km' },
    { valor: null, rotulo: 'Toda Praia Grande' },
  ];
  function renderChipsDistancia(){
    document.getElementById('filtrosDistancia').innerHTML = CHIPS_DISTANCIA.map(c => `
      <button type="button" class="filtro-distancia-chip ${filtroDistanciaKm===c.valor?'active':''}" data-dist="${c.valor ?? ''}">${c.rotulo}</button>
    `).join('');
    document.querySelectorAll('#filtrosDistancia [data-dist]').forEach(btn => {
      btn.onclick = () => {
        filtroDistanciaKm = btn.dataset.dist ? Number(btn.dataset.dist) : null;
        if(filtroDistanciaKm && !posicaoAtual){
          mostrarToast('Ative sua localização (ou simule, em DEV) para filtrar por distância.');
        }
        renderChipsDistancia();
        render();
      };
    });
  }

  renderChipsDistancia();

  // ---------- Ordenação ----------
  let ordenarPor = 'distancia'; // 'distancia' | 'valor' | 'valorPorKm'
  function aplicarOrdenacao(lista){
    const copia = lista.slice();
    if(ordenarPor === 'valor'){
      copia.sort((a,b) => {
        const va = valorEstimadoOp(a), vb = valorEstimadoOp(b);
        if(va == null && vb == null) return 0;
        if(va == null) return 1;   // "A combinar" vai para o final
        if(vb == null) return -1;
        return vb - va; // maior valor primeiro
      });
    } else if(ordenarPor === 'valorPorKm'){
      copia.sort((a,b) => {
        const va = valorPorKmOp(a), vb = valorPorKmOp(b);
        if(va == null && vb == null) return 0;
        if(va == null) return 1;
        if(vb == null) return -1;
        return vb - va; // maior valor por km primeiro
      });
    } else {
      // 'distancia': já vem ordenado por Matching.oportunidadesPara, mas
      // reordenamos explicitamente para garantir mesmo após os filtros.
      copia.sort((a,b) => {
        if(a._distanciaKm == null && b._distanciaKm == null) return 0;
        if(a._distanciaKm == null) return 1;
        if(b._distanciaKm == null) return -1;
        return a._distanciaKm - b._distanciaKm;
      });
    }
    return copia;
  }
  const selOrdenacao = document.getElementById('selOrdenacao');
  if(selOrdenacao){
    selOrdenacao.value = ordenarPor;
    selOrdenacao.onchange = () => {
      ordenarPor = selOrdenacao.value;
      if(ordenarPor !== 'distancia' && !posicaoAtual){
        // valor não depende de posição, mas valorPorKm sim
        if(ordenarPor === 'valorPorKm'){
          mostrarToast('Ative sua localização (ou simule, em DEV) para ordenar por valor/km.');
        }
      }
      render();
    };
  }

  // ---------- Render lista + mapa ----------
  function urgenciaClasse(u){
    if(u === 'Urgente (poucas horas)') return 'urgente';
    if(u === 'Hoje') return 'hoje';
    return 'programado';
  }

  /** Centraliza o mapa em uma oportunidade, destaca-a (lista + marcador) e
   * abre seus detalhes. Usado ao tocar em um item da lista "Oportunidades
   * próximas". Não interfere no fluxo de "Tenho interesse" (abrirDetalhe
   * continua sendo o único ponto que dispara esse fluxo). */
  function selecionarOportunidade(op){
    selecionadaId = op.id;
    if(mapa && op._imovel && op._imovel.latitude != null && op._imovel.longitude != null){
      mapa.setView([op._imovel.latitude, op._imovel.longitude], Math.max(mapa.getZoom ? mapa.getZoom() : 15, 15));
    }
    desenharMarcadores(ultimaFiltradas);
    renderLista(ultimaFiltradas);
    abrirDetalhe(op);
  }

  function renderLista(filtradas){
    const cont = document.getElementById('listaOportunidades');
    if(filtradas.length === 0){
      cont.innerHTML = `<div class="empty-state"><i data-lucide="search-x"></i><p>Nenhuma oportunidade disponível para os filtros atuais.</p></div>`;
      refreshIcons();
      return;
    }

    cont.innerHTML = filtradas.map(op => {
      const v = visualDaCategoria(op.categoria);
      const distTxt = op._distanciaKm != null ? `${op._distanciaKm} km` : '—';
      const valorNum = valorEstimadoOp(op);
      const valorTxt = valorNum != null ? 'R$ ' + valorNum.toFixed(2) : 'A combinar';
      return `
        <div class="opportunity-card ${op.id===selecionadaId?'selecionada':''}" data-id="${op.id}">
          <div class="flex justify-between items-start mb-1">
            <p class="font-semibold text-[13.5px] flex items-center gap-1"><i data-lucide="${v.icone}" style="width:14px;height:14px;color:${v.cor}"></i> ${op.categoria}</p>
            <div class="flex items-center gap-1">
              ${tagProximidadeHtml(op._distanciaKm)}
              <span class="urgencia-tag ${urgenciaClasse(op.urgencia)}">${op.urgencia}</span>
            </div>
          </div>
          <p class="text-[11.5px] text-muted mb-2">${op._imovel ? op._imovel.bairro+', '+op._imovel.cidade : ''} · ${distTxt} · ${formatarData(op.data)} ${op.horario}</p>
          <div class="flex items-center justify-between">
            <span class="valor-profissional">${valorTxt}</span>
            ${op._jaInteressado
              ? '<span class="badge-status pendente">Interesse enviado</span>'
              : `<button class="btn-primary px-4 py-2 rounded-lg text-[12.5px]" data-ver="${op.id}">Ver detalhes</button>`}
          </div>
        </div>
      `;
    }).join('');

    // Um único listener por card: tocar em qualquer parte do card (inclusive
    // no botão "Ver detalhes", que não tem handler próprio) centraliza no
    // mapa, destaca e abre os detalhes — sem duplicar a ação.
    cont.querySelectorAll('.opportunity-card').forEach(card => {
      card.addEventListener('click', () => {
        const op = filtradas.find(o => o.id === Number(card.dataset.id));
        if(op) selecionarOportunidade(op);
      });
    });

    refreshIcons();
  }

  function render(){
    const publicadas = ServiceRequestsService.listarPublicadas();
    const { oportunidades, bloqueadoPorCapacidade } = Matching.oportunidadesPara(provider, publicadas, posicaoAtual);

    const naAreaPiloto = oportunidades.filter(op => estaEmPraiaGrande(op._imovel));
    const foraDaArea = oportunidades.length - naAreaPiloto.length;

    let filtradas = naAreaPiloto;
    if(filtroDistanciaKm && posicaoAtual){
      filtradas = filtradas.filter(op => op._distanciaKm != null && op._distanciaKm <= filtroDistanciaKm);
    }
    // A ordenação por distância (mais próximas primeiro) já vem de
    // Matching.oportunidadesPara; o seletor "Ordenar por" permite trocar
    // para maior valor ou maior valor/km sem afetar os filtros aplicados.
    filtradas = aplicarOrdenacao(filtradas);
    ultimaFiltradas = filtradas;

    // Se a oportunidade selecionada saiu da lista atual (filtro/expiração), desfaz o destaque.
    if(selecionadaId != null && !filtradas.some(op => op.id === selecionadaId)){
      selecionadaId = null;
    }

    document.getElementById('pillContagem').innerHTML = `<i data-lucide="map-pin" class="icon-inline"></i> ${filtradas.length} oportunidade${filtradas.length===1?'':'s'}`;

    const avisoCap = document.getElementById('avisoCapacidade');
    if(bloqueadoPorCapacidade){
      avisoCap.classList.remove('hidden');
      avisoCap.innerHTML = `<div class="geo-banner" style="margin:0 0 12px 0"><i data-lucide="alert-triangle"></i><span>Você já está com o número máximo de serviços simultâneos aceitos. Conclua um serviço para ver novas oportunidades.</span></div>`;
    } else if(foraDaArea > 0){
      avisoCap.classList.remove('hidden');
      avisoCap.innerHTML = `<div class="geo-banner" style="margin:0 0 12px 0"><i data-lucide="info"></i><span>${foraDaArea} oportunidade${foraDaArea===1?'':'s'} fora da área piloto de Praia Grande não ${foraDaArea===1?'é exibida':'são exibidas'} neste mapa.</span></div>`;
    } else {
      avisoCap.classList.add('hidden');
    }

    desenharMarcadores(filtradas);
    renderLista(filtradas);
  }

  // ---------- Modal de detalhe + "Tenho interesse" ----------
  function abrirDetalhe(op){
    document.getElementById('modalOportunidade').classList.remove('show');
    document.querySelectorAll('.leaflet-popup-close-button').forEach(b => b.click());
    const valorNum = valorEstimadoOp(op);
    const valorTxt = valorNum != null ? 'R$ ' + valorNum.toFixed(2) : 'A combinar após avaliação';
    const distTxt = op._distanciaKm != null ? `${op._distanciaKm} km em linha reta` : 'distância indisponível';
    const valorPorKmNum = valorPorKmOp(op);
    const valorPorKmTxt = valorPorKmNum != null ? 'R$ ' + valorPorKmNum.toFixed(2) + '/km' : '—';
    const detalhesTxt = JSON.stringify(op.detalhes || {}, null, 0)
      .replace(/[{}"]/g,'').replace(/,/g, ' · ').replace(/:/g, ': ');
    const proximidade = classeProximidade(op._distanciaKm);

    // Resumo em destaque — valor do serviço, distância, valor/km, data e
    // horário e tipo de serviço, todos claramente legíveis no celular.
    const resumoHtml = `
      <div class="resumo-oportunidade">
        <div class="resumo-item full">
          <p class="resumo-label">Tipo de serviço</p>
          <p class="resumo-valor" style="color:${visualDaCategoria(op.categoria).cor}">${op.categoria}${proximidade ? ` · <span class="proximidade-tag ${proximidade.classe}">${proximidade.rotulo}</span>` : ''}</p>
        </div>
        <div class="resumo-item">
          <p class="resumo-label">Valor do serviço</p>
          <p class="resumo-valor destaque">${valorTxt}</p>
        </div>
        <div class="resumo-item">
          <p class="resumo-label">Valor por km</p>
          <p class="resumo-valor">${valorPorKmTxt}</p>
        </div>
        <div class="resumo-item">
          <p class="resumo-label">Distância até a acomodação</p>
          <p class="resumo-valor">${distTxt}</p>
        </div>
        <div class="resumo-item">
          <p class="resumo-label">Distância em linha de rota</p>
          <p class="resumo-valor" id="distRotaValor">${(posicaoAtual && op._imovel && op._imovel.latitude!=null) ? 'Calculando…' : 'Indisponível'}</p>
        </div>
        <div class="resumo-item full">
          <p class="resumo-label">Data e horário</p>
          <p class="resumo-valor">${formatarData(op.data)} às ${op.horario} · ${op.urgencia}</p>
        </div>
      </div>`;

    document.getElementById('conteudoModalOportunidade').innerHTML = `
      <div class="flex justify-between items-center mb-3">
        <h3 class="text-[17px] font-bold">${op.categoria}</h3>
        <button id="fecharDetalheOp" class="text-xl" style="color:var(--muted)">✕</button>
      </div>
      <p class="text-[13px] text-muted mb-3">${op._imovel ? op._imovel.nome+' — '+op._imovel.bairro+', '+op._imovel.cidade : ''}</p>
      ${resumoHtml}
      <div class="card-soft p-3 mb-3">
        <p class="text-[12px] text-muted">${detalhesTxt || 'Sem detalhes adicionais'}</p>
        ${op.observacoes ? `<p class="text-[12px] text-muted mt-2">"${op.observacoes}"</p>` : ''}
      </div>
      ${op._jaInteressado
        ? `<p class="text-center text-[13px] font-semibold" style="color:var(--azul-escuro)">Você já demonstrou interesse nesta oportunidade.</p>`
        : `<button id="btnTenhoInteresse" class="btn-gold w-full py-4 rounded-2xl text-base">Tenho interesse</button>`}
    `;
    document.getElementById('modalOportunidade').classList.add('show');
    document.getElementById('fecharDetalheOp').onclick = () => document.getElementById('modalOportunidade').classList.remove('show');

    // Distância em linha de rota — busca assíncrona, quando disponível
    // (posição do profissional + coordenadas do imóvel). Não bloqueia a
    // abertura do modal; se indisponível, deixa claro em vez de inventar.
    if(posicaoAtual && op._imovel && op._imovel.latitude != null && op._imovel.longitude != null){
      buscarDistanciaRotaKm(posicaoAtual, { lat: op._imovel.latitude, lng: op._imovel.longitude }).then(km => {
        const el = document.getElementById('distRotaValor');
        if(!el) return; // modal já foi fechado/trocado
        el.innerText = km != null ? `${km} km por via` : 'Indisponível no momento';
      });
    }

    const btnInteresse = document.getElementById('btnTenhoInteresse');
    if(btnInteresse){
      btnInteresse.onclick = () => {
        try{
          InterestsService.demonstrarInteresse(provider.id, op.id);
          mostrarToast('Interesse enviado! O anfitrião foi notificado.');
          document.getElementById('modalOportunidade').classList.remove('show');
          render();
        }catch(err){ mostrarToast(err.message); }
      };
    }
  }

  document.getElementById('modalOportunidade').addEventListener('click', (e) => {
    if(e.target.id === 'modalOportunidade') e.currentTarget.classList.remove('show');
  });

  render();
})();
