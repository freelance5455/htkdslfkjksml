import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { appUrl } from '../lib/util.js';
import { useAuth } from '../lib/AuthContext.js';
import PasswordInput from '../components/PasswordInput.js';
import { Logo, Notice } from '../components/Bits.js';
export default function Login() {
    const { session } = useAuth();
    const nav = useNavigate();
    const [email, setEmail] = useState('');
    const [pw, setPw] = useState('');
    const [err, setErr] = useState('');
    const [info, setInfo] = useState('');
    const [busy, setBusy] = useState(false);
    if (session)
        return _jsx(Navigate, { to: "/", replace: true });
    async function submit(e) {
        e.preventDefault();
        setBusy(true);
        setErr('');
        setInfo('');
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw });
        setBusy(false);
        if (error)
            setErr(error.message === 'Invalid login credentials' ? 'Email ya password ghalat hai.' : error.message);
        else
            nav('/', { replace: true });
    }
    async function forgot() {
        if (!/\S+@\S+\.\S+/.test(email))
            return setErr('Pehle upar apni email likhein.');
        setErr('');
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: appUrl() + '#/reset' });
        if (error)
            setErr(error.message);
        else
            setInfo('Password reset ka link email par bhej diya gaya hai.');
    }
    return (_jsxs("div", { className: "auth-wrap", children: [_jsxs(Link, { to: "/", className: "row", style: { textDecoration: 'none', color: 'inherit', marginBottom: '1rem' }, children: [_jsx(Logo, {}), _jsx("b", { style: { fontFamily: 'var(--head)', fontSize: '1.5rem' }, children: "Udaan" })] }), _jsx("h2", { children: "Wapas khush amdeed" }), _jsx("p", { className: "muted", children: "Login karein. Dobara signup ki zaroorat nahi." }), _jsxs("form", { className: "stack", onSubmit: submit, children: [_jsxs("label", { className: "field", children: [_jsx("span", { children: "Email" }), _jsx("input", { className: "input", type: "email", value: email, onChange: (e) => setEmail(e.target.value), autoComplete: "email" })] }), _jsxs("div", { className: "field", children: [_jsx("span", { style: { fontWeight: 700, fontSize: '.9rem' }, children: "Password" }), _jsx(PasswordInput, { value: pw, onChange: setPw })] }), err && _jsx(Notice, { kind: "error", children: err }), info && _jsx(Notice, { kind: "ok", children: info }), _jsx("button", { className: "btn primary block", disabled: busy || !email || !pw, children: busy ? 'Ho raha hai...' : 'Login' }), _jsx("button", { type: "button", className: "btn ghost block", onClick: forgot, children: "Password bhool gaye?" })] }), _jsxs("p", { className: "center small", style: { marginTop: '1rem' }, children: ["Naye hain? ", _jsx(Link, { to: "/signup", children: "Signup karein" })] })] }));
}
