(function(){
  const sessao = Auth.exigirPerfil('anfitriao', 'morador');
  if(!sessao) return;
  document.getElementById('linkVoltar').href = homeDoPerfil(sessao.tipo_usuario);

  const params = new URLSearchParams(window.location.search);
  const requestId = Number(params.get('id'));
  const solicitacao = ServiceRequestsService.obterSeDono(sessao.id, requestId);

  if(!solicitacao){
    mostrarToast('Solicitação não encontrada.');
    setTimeout(()=> window.location.href = homeDoPerfil(sessao.tipo_usuario), 800);
    return;
  }

  function badgeStatus(status){
    const map = {
      DRAFT: ['Rascunho','pendente'], PUBLISHED: ['Publicada','ativo'], ACCEPTED: ['Aceita','verificado'],
      TRAVELING: ['Profissional a caminho','verificado'], ARRIVED: ['Profissional chegou','verificado'],
      CHECKING: ['Em conferência','pendente'], IN_PROGRESS: ['Em andamento','verificado'],
      UNDER_REVIEW: ['Aguardando sua confirmação','pendente'], DISPUTED: ['Em disputa','inativo'],
      COMPLETED: ['Concluída','ativo'], CANCELLED: ['Cancelada','inativo'],
    };
    const [txt, classe] = map[status] || [status, 'inativo'];
    return `<span class="badge-status ${classe}">${txt}</span>`;
  }

  function badgePagamento(status){
    const map = {
      PENDING:['Pendente','pendente'], AUTHORIZED:['Autorizado','pendente'], HELD:['Retido (protegido)','verificado'],
      RELEASE_PENDING:['Liberação em processo','pendente'], RELEASED:['Liberado','ativo'],
      REFUNDED:['Reembolsado','inativo'], PARTIALLY_REFUNDED:['Reembolso parcial','inativo'], DISPUTED:['Retido — em disputa','inativo'],
    };
    const [txt, classe] = map[status] || [status,'inativo'];
    return `<span class="badge-status ${classe}">${txt}</span>`;
  }

  function renderCabecalho(){
    const s = ServiceRequestsService.obter(requestId);
    const imovel = DB.find('properties', s.property_id);
    const precificacao = s.precificacao;
    const pagamento = PaymentsService.obterPorSolicitacao(requestId);

    let precoHtml = '';
    if(precificacao){
      precoHtml = precificacao.necessitaAvaliacao
        ? `<p class="text-[12.5px]" style="color:var(--dourado-escuro)">Necessita avaliação do profissional</p>`
        : `<div class="pricing-breakdown mt-2">
             <div class="linha total"><span>Você paga</span><span>R$ ${precificacao.valorAnfitriao.toFixed(2)}</span></div>
             <div class="linha"><span>Profissional recebe (estimado)</span><span>R$ ${precificacao.valorProfissional.toFixed(2)}</span></div>
           </div>`;
    }

    document.getElementById('cabecalhoSolicitacao').innerHTML = `
      <div class="flex items-center justify-between mb-2">
        <p class="font-bold text-[15px]">${s.categoria}</p>
        ${badgeStatus(s.status)}
      </div>
      <p class="text-[12.5px] text-muted mb-1">${imovel ? imovel.nome + ' — ' + imovel.bairro + ', ' + imovel.cidade : ''}</p>
      <p class="text-[12.5px] text-muted mb-1">${formatarData(s.data)} às ${s.horario} · ${s.urgencia}</p>
      ${s.observacoes ? `<p class="text-[12px] text-muted mt-2">"${s.observacoes}"</p>` : ''}
      ${precoHtml}
      ${pagamento ? `<div class="flex items-center justify-between mt-2"><span class="text-[11.5px] text-muted">Pagamento</span>${badgePagamento(pagamento.status)}</div>` : ''}
      ${s.historico_alteracoes && s.historico_alteracoes.length ? `<p class="text-[11px] mt-2" style="color:var(--dourado-escuro)">${s.historico_alteracoes.length} alteração(ões) formal(is) registrada(s)</p>` : ''}
      ${s.accepted_provider_id ? `<a href="chat.html?id=${requestId}" class="mt-3 flex items-center gap-2 text-[12.5px] font-semibold" style="color:var(--azul-escuro)"><i data-lucide="message-circle" class="icon-inline"></i> Abrir chat oficial</a>` : ''}
    `;

    renderCartaoProfissionalAceito(s);
    renderAcaoPrincipal(s);
    refreshIcons();
  }

  function renderCartaoProfissionalAceito(s){
    const cont = document.getElementById('cartaoProfissionalWrap');
    if(!s.accepted_provider_id){ cont.innerHTML = ''; return; }
    cont.innerHTML = `
      <p class="text-[13px] font-bold mb-2" style="color:var(--tinta)">Profissional designado</p>
      ${renderCartaoProfissional(s.accepted_provider_id)}
      <button id="btnVerIdentificacao" class="mt-2 w-full py-2.5 rounded-lg text-[12px] font-semibold border" style="border-color:var(--linha); color:var(--tinta)">
        Ver identificação (uso restrito — necessidade operacional)
      </button>
      <div id="areaRevelacaoDoc"></div>
    `;
    document.getElementById('btnVerIdentificacao').onclick = () => {
      try{
        const info = ProvidersService.visualizarDocumentoSensivel(sessao.id, s.accepted_provider_id, 'rg_cpf');
        document.getElementById('areaRevelacaoDoc').innerHTML = `
          <div class="sensitive-reveal mt-2">
            <p><b>RG:</b> ${info.rg || 'não informado'}</p>
            <p><b>CPF:</b> ${info.cpf || 'não informado'}</p>
            <p class="text-[10.5px] text-muted mt-1">Esta visualização foi registrada na auditoria.</p>
          </div>`;
      }catch(err){ mostrarToast(err.message); }
    };
  }

  function renderAcaoPrincipal(s){
    const areaCancelar = document.getElementById('areaCancelar');

    if(s.alteracao_pendente){
      const p = s.alteracao_pendente;
      areaCancelar.innerHTML = `
        <div class="card-soft p-4 mb-3">
          <p class="font-semibold text-[13px] mb-1">📋 Proposta de alteração do profissional</p>
          <p class="text-[12px] text-muted mb-2">${p.motivo}</p>
          <p class="text-[13px] font-bold mb-3" style="color:var(--azul-escuro)">Novo valor: R$ ${p.precificacao_proposta.valorAnfitriao.toFixed(2)}</p>
          <div class="flex gap-2">
            <button id="btnAprovarProposta" class="flex-1 btn-primary py-2.5 rounded-lg text-[12.5px]">Aprovar</button>
            <button id="btnRejeitarProposta" class="flex-1 py-2.5 rounded-lg text-[12.5px] border" style="border-color:#F0C6C6;color:#C0392B">Rejeitar</button>
          </div>
        </div>`;
      document.getElementById('btnAprovarProposta').onclick = () => { ServiceRequestsService.responderPropostaAlteracao(sessao.id, requestId, true); mostrarToast('Alteração aprovada.'); renderCabecalho(); };
      document.getElementById('btnRejeitarProposta').onclick = () => { ServiceRequestsService.responderPropostaAlteracao(sessao.id, requestId, false); mostrarToast('Alteração rejeitada.'); renderCabecalho(); };
      return;
    }

    if(s.status === 'DISPUTED'){
      const divergencias = DisputesService.listarPorSolicitacao(requestId);
      const aberta = divergencias.find(d => d.status === 'aberta');
      if(aberta){
        areaCancelar.innerHTML = `
          <div class="card-soft p-4 mb-3">
            <p class="font-semibold text-[13px] mb-1">⚠️ Divergência aberta pelo profissional</p>
            <p class="text-[12px] text-muted mb-1"><b>Motivo:</b> ${aberta.motivo} · <b>Severidade:</b> ${aberta.severidade||'—'}</p>
            <p class="text-[12px] text-muted mb-3">${aberta.descricao || ''}</p>
            <textarea id="respostaDivergencia" rows="3" class="field-input mb-2" placeholder="Sua versão dos fatos"></textarea>
            <button id="btnResponderDivergencia" class="btn-primary w-full py-3 rounded-2xl text-[13.5px]">Enviar resposta</button>
          </div>`;
        document.getElementById('btnResponderDivergencia').onclick = () => {
          const texto = document.getElementById('respostaDivergencia').value.trim();
          if(!texto){ mostrarToast('Escreva sua resposta.'); return; }
          DisputesService.responderAnfitriao(sessao.id, aberta.id, { texto, fotos:[] });
          mostrarToast('Resposta enviada. Aguarde a decisão.');
          renderCabecalho();
        };
      } else {
        areaCancelar.innerHTML = `<div class="geo-banner"><i data-lucide="clock"></i><span>Divergência respondida. Aguardando decisão da administração.</span></div>`;
      }
      return;
    }

    if(s.status === 'UNDER_REVIEW'){
      const fin = s.finalizacao;
      areaCancelar.innerHTML = `
        <div class="card-soft p-4 mb-3">
          <p class="font-semibold text-[13px] mb-2">Profissional finalizou o serviço</p>
          ${fin && fin.checklist && fin.checklist.length ? `<p class="text-[12px] text-muted mb-1">Checklist: ${fin.checklist.join(', ')}</p>` : ''}
          ${fin && fin.observacoes ? `<p class="text-[12px] text-muted mb-2">"${fin.observacoes}"</p>` : ''}
          ${fin && fin.fotos && fin.fotos.length ? `<div class="grid grid-cols-4 gap-2 mb-3">${fin.fotos.map(f=>`<img src="${f}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join('')}</div>` : ''}
          <button id="btnConfirmarConclusao" class="btn-primary w-full py-3 rounded-2xl text-[13.5px]">Confirmar conclusão</button>
        </div>`;
      document.getElementById('btnConfirmarConclusao').onclick = () => {
        ServiceRequestsService.confirmarConclusao(sessao.id, requestId);
        mostrarToast('Conclusão confirmada! Pagamento em processo de liberação.');
        renderCabecalho();
      };
      return;
    }

    if(['PUBLISHED','DRAFT'].includes(s.status)){
      areaCancelar.innerHTML = `<button id="btnCancelar" class="w-full py-3 rounded-2xl text-[13.5px] font-semibold border" style="border-color:#F0C6C6;color:#C0392B">Cancelar solicitação</button>`;
      document.getElementById('btnCancelar').onclick = () => {
        ServiceRequestsService.cancelar(sessao.id, requestId, sessao.tipo_usuario === 'morador' ? 'Cancelado pelo morador/residente' : 'Cancelado pelo anfitrião');
        mostrarToast('Solicitação cancelada.');
        renderCabecalho(); renderInteresses();
      };
      return;
    }

    areaCancelar.innerHTML = '';
  }

  function estrelasTxt(nota){
    return '★'.repeat(Math.round(nota)) + '☆'.repeat(5-Math.round(nota));
  }

  function renderInteresses(){
    const s = ServiceRequestsService.obter(requestId);
    const interesses = InterestsService.listarPorSolicitacao(requestId);
    const cont = document.getElementById('listaInteresses');

    if(interesses.length === 0){
      cont.innerHTML = `<div class="empty-state card-soft"><i data-lucide="users"></i><p>Nenhum profissional demonstrou interesse ainda.</p></div>`;
      refreshIcons();
      return;
    }

    cont.innerHTML = interesses.map(i => {
      const reviews = i._provider ? ReviewsService.listarRecebidas(i._provider.user_id) : [];
      const nomeExibicao = i._usuario ? i._usuario.nome : 'Profissional';
      const statusTxt = { interessado:'Aguardando resposta', aceito:'Aceito ✓', recusado:'Não seguiu' }[i.status] || i.status;
      const corStatus = i.status === 'aceito' ? 'ativo' : (i.status === 'recusado' ? 'inativo' : 'pendente');
      const nota = i._provider ? Number(i._provider.reputacao || 0) : 0;

      return `
        <div class="card-soft p-4">
          <div class="flex items-center gap-3 mb-2">
            <div class="avatar-circle">${iniciais(nomeExibicao)}</div>
            <div class="flex-1 min-w-0">
              <p class="font-semibold text-[13.5px] truncate">${nomeExibicao}</p>
              <p class="text-[11.5px] text-muted">${i._provider ? estrelasTxt(nota) + ' ' + nota.toFixed(1) + ' (' + reviews.length + ' avaliações)' : ''}</p>
            </div>
            <span class="badge-status ${corStatus}">${statusTxt}</span>
          </div>
          ${i._provider ? `<p class="text-[11.5px] text-muted mb-1">${i._provider.categorias.join(', ')}</p>` : ''}
          ${i._provider && i._provider.descricao ? `<p class="text-[12px] text-muted mb-2">"${i._provider.descricao}"</p>` : ''}
          ${ i.status === 'interessado' && s.status === 'PUBLISHED' ? `
            <div class="flex gap-2 mt-2">
              <button class="flex-1 btn-primary py-2 rounded-lg text-[12.5px]" data-acao="aceitar" data-id="${i.id}">Aceitar</button>
              <button class="flex-1 py-2 rounded-lg text-[12.5px] border" style="border-color:#F0C6C6;color:#C0392B" data-acao="rejeitar" data-id="${i.id}">Rejeitar</button>
            </div>` : ''}
        </div>
      `;
    }).join('');

    cont.querySelectorAll('button[data-acao]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = Number(btn.dataset.id);
        btn.disabled = true;
        try{
          if(btn.dataset.acao === 'aceitar'){
            await InterestsService.aceitar(sessao.id, requestId, id);
            mostrarToast('Profissional aceito! A oportunidade foi bloqueada para os demais.');
          } else {
            InterestsService.rejeitar(sessao.id, requestId, id);
            mostrarToast('Interesse rejeitado.');
          }
          renderCabecalho(); renderInteresses();
        }catch(err){ mostrarToast(err.message); btn.disabled = false; }
      });
    });

    refreshIcons();
  }

  renderCabecalho();
  renderInteresses();
  renderAvaliacao();

  // ---------- Avaliação (anfitrião → profissional) ----------
  function renderAvaliacao(){
    const s = ServiceRequestsService.obter(requestId);
    const cont = document.getElementById('areaAvaliacao');
    if(s.status !== 'COMPLETED' || !s.accepted_provider_id){ cont.innerHTML = ''; return; }

    const provider = DB.find('providers', s.accepted_provider_id);
    const jaAvaliou = DB.findOne('reviews', r => r.service_request_id === requestId && r.avaliador_id === sessao.id);

    if(jaAvaliou){
      cont.innerHTML = `<div class="card-soft p-4"><p class="text-[13px] font-semibold">Você avaliou este serviço com ${jaAvaliou.nota}★</p>${jaAvaliou.comentario ? `<p class="text-[12px] text-muted mt-1">"${jaAvaliou.comentario}"</p>` : ''}</div>`;
      return;
    }
    cont.innerHTML = `<button id="btnAbrirAvaliacao" class="btn-gold w-full py-3.5 rounded-2xl text-[14px]">Avaliar profissional</button>`;
    document.getElementById('btnAbrirAvaliacao').onclick = () => {
      notaSelecionada = 0;
      document.querySelectorAll('#estrelasAvaliacao .star').forEach(s=>s.classList.remove('filled'));
      document.getElementById('comentarioAvaliacao').value = '';
      document.getElementById('modalAvaliacao').classList.add('show');
    };
  }

  let notaSelecionada = 0;
  document.getElementById('estrelasAvaliacao').addEventListener('click', (e) => {
    if(!e.target.classList.contains('star')) return;
    notaSelecionada = Number(e.target.dataset.v);
    document.querySelectorAll('#estrelasAvaliacao .star').forEach(s => s.classList.toggle('filled', Number(s.dataset.v) <= notaSelecionada));
  });
  document.getElementById('fecharModalAvaliacao').onclick = () => document.getElementById('modalAvaliacao').classList.remove('show');
  document.getElementById('btnEnviarAvaliacao').onclick = () => {
    if(notaSelecionada === 0){ mostrarToast('Selecione uma nota de 1 a 5 estrelas.'); return; }
    const s = ServiceRequestsService.obter(requestId);
    const provider = DB.find('providers', s.accepted_provider_id);
    ReviewsService.criar({ service_request_id: requestId, avaliador_id: sessao.id, avaliado_id: provider.user_id, nota: notaSelecionada, comentario: document.getElementById('comentarioAvaliacao').value.trim() });
    mostrarToast('Avaliação enviada!');
    document.getElementById('modalAvaliacao').classList.remove('show');
    renderAvaliacao();
  };
})();
