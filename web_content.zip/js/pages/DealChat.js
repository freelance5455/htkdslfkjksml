import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { fmtTime, money } from '../lib/util.js';
import { Avatar, Empty, Notice } from '../components/Bits.js';
import Icon from '../components/Icon.js';
import TrackingPanel from '../components/TrackingPanel.js';
function stepState(i, status) {
    const order = { chatting: 0, requested: 1, approved: 2, completed: 3 };
    const bad = status === 'rejected' ? 1 : status === 'cancelled' ? 0 : -1;
    const at = status in order ? order[status] : bad;
    if (bad >= 0 && i === bad)
        return 'bad';
    if (i < at)
        return 'done';
    if (i === at)
        return status === 'approved' || status === 'completed' ? 'done' : 'now';
    return '';
}
const WARN = {
    contact: 'Number, link ya location share karna allowed nahi. Deal approve hone ke baad admin khud dono se rabta karega. Ye koshish admin ko nazar aati hai.',
    blocked: 'Aap ka account block hai.',
    closed: 'Ye deal band ho chuki hai.',
    empty: 'Khali ya bohat lamba message nahi bhej sakte.',
    denied: 'Is deal mein aap shamil nahi.',
};
export default function DealChat() {
    const { id } = useParams();
    const { profile } = useAuth();
    const nav = useNavigate();
    const [deal, setDeal] = useState(null);
    const [loaded, setLoaded] = useState(false);
    const [msgs, setMsgs] = useState([]);
    const [text, setText] = useState('');
    const [warn, setWarn] = useState('');
    const [sending, setSending] = useState(false);
    const [showReq, setShowReq] = useState(false);
    const [price, setPrice] = useState('');
    const [note, setNote] = useState('');
    const [reqErr, setReqErr] = useState('');
    const endRef = useRef(null);
    const loadDeal = useCallback(async () => {
        const { data } = await supabase.from('deals')
            .select('*, buyer:profiles!deals_buyer_id_fkey(full_name), seller:profiles!deals_seller_id_fkey(full_name)')
            .eq('id', id).maybeSingle();
        setDeal(data);
        setLoaded(true);
    }, [id]);
    const loadMsgs = useCallback(async () => {
        const { data } = await supabase.from('messages').select('*').eq('deal_id', id).order('created_at', { ascending: true });
        setMsgs(data || []);
    }, [id]);
    useEffect(() => {
        loadDeal();
        loadMsgs();
        const ch = supabase.channel('deal-' + id)
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `deal_id=eq.${id}` }, () => loadMsgs())
            .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'deals', filter: `id=eq.${id}` }, () => loadDeal())
            .subscribe();
        const t = setInterval(() => { loadMsgs(); loadDeal(); }, 6000);
        return () => { clearInterval(t); supabase.removeChannel(ch); };
    }, [id, loadDeal, loadMsgs]);
    useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs.length]);
    if (!loaded)
        return _jsx("p", { className: "muted center", children: "Load ho raha hai..." });
    if (!deal)
        return _jsx(Empty, { icon: "search", title: "Deal nahi mili" });
    const mine = !!profile && (deal.buyer_id === profile.id || deal.seller_id === profile.id);
    const open = ['chatting', 'requested', 'approved'].includes(deal.status);
    const other = profile?.id === deal.buyer_id ? deal.seller?.full_name : deal.buyer?.full_name;
    async function send(e) {
        e.preventDefault();
        const body = text.trim();
        if (!body || sending)
            return;
        setSending(true);
        setWarn('');
        const { data, error } = await supabase.rpc('send_message', { p_deal: id, p_body: body });
        setSending(false);
        if (error)
            return setWarn(error.message);
        const r = data;
        if (!r.ok)
            return setWarn(WARN[r.reason || ''] || 'Message nahi bheja ja saka.');
        setText('');
        loadMsgs();
    }
    async function requestApproval() {
        setReqErr('');
        const { error } = await supabase.rpc('request_approval', { p_deal: id, p_price: Number(price), p_note: note });
        if (error)
            return setReqErr(error.message);
        setShowReq(false);
        loadDeal();
        loadMsgs();
    }
    async function cancel() {
        if (!confirm('Kya aap ye deal cancel karna chahte hain?'))
            return;
        const { error } = await supabase.rpc('cancel_deal', { p_deal: id });
        if (error)
            setWarn(error.message);
        else {
            loadDeal();
            loadMsgs();
        }
    }
    return (_jsxs("div", { className: "chat-page", children: [_jsxs("div", { className: "page-head", style: { marginBottom: '.4rem' }, children: [_jsx(Link, { to: mine ? '/deals' : '/admin', className: "back", "aria-label": "Wapas", children: _jsx(Icon, { name: "chevL", size: 20 }) }), _jsx(Avatar, { name: mine ? other : deal.buyer?.full_name, size: "lg" }), _jsxs("div", { className: "grow", children: [_jsx("b", { className: "ellipsis", children: mine ? other : `${deal.buyer?.full_name} ↔ ${deal.seller?.full_name}` }), _jsxs("span", { className: "small muted ellipsis", children: [deal.listing_title, " \u00B7 ", money(deal.listing_price)] })] })] }), _jsx("div", { className: "card", style: { padding: '.7rem .9rem .5rem' }, children: _jsx("div", { className: "stepper", children: ['Baat-cheet', 'Approval', 'Approved'].map((label, i) => {
                        const st = stepState(i, deal.status);
                        return (_jsxs("div", { className: `step ${st}`, children: [_jsx("span", { className: "dot", children: st === 'done' ? _jsx(Icon, { name: "check", size: 14 }) : st === 'bad' ? _jsx(Icon, { name: "alert", size: 13 }) : i + 1 }), label] }, label));
                    }) }) }), deal.status === 'approved' && _jsx(TrackingPanel, { deal: deal }), deal.status === 'requested' && _jsxs(Notice, { kind: "warn", children: ["Admin approval ka intezar hai. Tay shuda price: ", _jsx("b", { children: money(deal.agreed_price) })] }), deal.status === 'approved' && _jsx(Notice, { kind: "ok", children: "Admin ne approve kar diya. Admin aap dono se rabta karega, number ya location dene ki zaroorat nahi." }), deal.status === 'rejected' && _jsxs(Notice, { kind: "error", children: ["Admin ne reject kar di.", deal.admin_note ? ` Wajah: ${deal.admin_note}` : ''] }), !mine && _jsx(Notice, { kind: "info", children: "Aap admin ke taur par ye chat dekh rahe hain." }), _jsxs("div", { className: "chat", children: [msgs.map((m) => (_jsxs("div", { className: `bubble ${m.kind === 'system' ? 'system' : m.sender_id === profile?.id ? 'me' : ''}`, children: [m.body, _jsx("small", { children: fmtTime(m.created_at) })] }, m.id))), _jsx("div", { ref: endRef })] }), mine && open && (_jsxs(_Fragment, { children: [deal.status === 'chatting' && (_jsxs("div", { className: "row wrap", style: { marginBottom: '.5rem' }, children: [_jsx("button", { className: "btn ok sm", onClick: () => { setPrice(String(deal.listing_price ?? '')); setShowReq(true); }, children: "Price tay ho gayi? Admin se approval maangein" }), _jsx("button", { className: "btn ghost sm", onClick: cancel, children: "Cancel" })] })), warn && _jsx(Notice, { kind: "error", children: warn }), _jsxs("form", { className: "chatbar", onSubmit: send, children: [_jsx("input", { className: "input", placeholder: "Price ya kaam ki baat likhein...", value: text, onChange: (e) => setText(e.target.value), maxLength: 1000 }), _jsx("button", { className: "btn primary", disabled: sending || !text.trim(), "aria-label": "Bhejein", children: _jsx(Icon, { name: "send", size: 19 }) })] })] })), showReq && (_jsx("div", { className: "modal-bg", onClick: () => setShowReq(false), children: _jsxs("div", { className: "modal", onClick: (e) => e.stopPropagation(), children: [_jsx("h2", { children: "Admin se approval" }), _jsx("p", { className: "muted small", children: "Jo price dono ne tay ki wo likhein. Admin approve kare to wo aap dono se rabta karega." }), _jsxs("div", { className: "stack", children: [_jsxs("label", { className: "field", children: [_jsx("span", { children: "Tay shuda price (Rs)" }), _jsx("input", { className: "input", inputMode: "numeric", value: price, onChange: (e) => setPrice(e.target.value.replace(/\D/g, '')) })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Admin ke liye note (optional)" }), _jsx("textarea", { className: "input", value: note, onChange: (e) => setNote(e.target.value), placeholder: "Kaam kab karwana hai, kitna waqt lagega..." })] }), reqErr && _jsx(Notice, { kind: "error", children: reqErr }), _jsxs("div", { className: "row", children: [_jsx("button", { className: "btn ghost grow", onClick: () => setShowReq(false), children: "Wapas" }), _jsx("button", { className: "btn primary grow", disabled: !Number(price), onClick: requestApproval, children: "Request bhejein" })] })] })] }) }))] }));
}
