import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { CITIES, validPhone } from '../lib/util.js';
import { Notice } from '../components/Bits.js';
export default function Profile() {
    const { profile, contact, session, refresh, signOut } = useAuth();
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [city, setCity] = useState('');
    const [address, setAddress] = useState('');
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');
    useEffect(() => {
        setName(profile?.full_name || '');
        setPhone(contact?.phone || '');
        setCity(contact?.city || '');
        setAddress(contact?.address || '');
    }, [profile, contact]);
    async function save(e) {
        e.preventDefault();
        if (!profile)
            return;
        setErr('');
        setMsg('');
        if (!validPhone(phone) || !city.trim() || address.trim().length < 5 || name.trim().length < 2)
            return setErr('Saari details sahi likhein.');
        const a = await supabase.from('private_contacts').upsert({ user_id: profile.id, email: session?.user.email ?? null, phone: phone.trim(), city: city.trim(), address: address.trim(), updated_at: new Date().toISOString() });
        const b = await supabase.from('profiles').update({ full_name: name.trim() }).eq('id', profile.id);
        if (a.error || b.error)
            return setErr((a.error || b.error).message);
        await refresh();
        setMsg('Save ho gaya.');
    }
    return (_jsxs(_Fragment, { children: [_jsx("h2", { children: "Mera profile" }), _jsxs("div", { className: "row", style: { marginBottom: '.6rem' }, children: [_jsx("span", { className: "chip", children: profile?.role === 'seller' ? 'Seller' : 'Buyer' }), profile?.is_admin && _jsx("span", { className: "chip gold", children: "\uD83D\uDEE1\uFE0F Admin" }), _jsx("span", { className: "small muted", children: session?.user.email })] }), _jsx(Notice, { kind: "info", children: "Phone aur address sirf Udaan admin ko dikhte hain, kisi aur user ko nahi." }), _jsxs("form", { className: "stack", onSubmit: save, children: [_jsxs("label", { className: "field", children: [_jsx("span", { children: "Naam" }), _jsx("input", { className: "input", value: name, onChange: (e) => setName(e.target.value) })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Phone number" }), _jsx("input", { className: "input", inputMode: "tel", value: phone, onChange: (e) => setPhone(e.target.value) })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Shehar" }), _jsx("input", { className: "input", list: "cities2", value: city, onChange: (e) => setCity(e.target.value) }), _jsx("datalist", { id: "cities2", children: CITIES.map((c) => _jsx("option", { value: c }, c)) })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Address / location" }), _jsx("textarea", { className: "input", value: address, onChange: (e) => setAddress(e.target.value) })] }), err && _jsx(Notice, { kind: "error", children: err }), msg && _jsx(Notice, { kind: "ok", children: msg }), _jsx("button", { className: "btn primary block", children: "Save karein" }), _jsx("button", { type: "button", className: "btn ghost block", onClick: signOut, children: "Logout" })] })] }));
}
