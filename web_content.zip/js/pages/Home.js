import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { Empty, Logo, Skel } from '../components/Bits.js';
import Icon, { ServiceIcon } from '../components/Icon.js';
export default function Home() {
    const { profile } = useAuth();
    const [services, setServices] = useState([]);
    const [counts, setCounts] = useState({});
    const [q, setQ] = useState('');
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        (async () => {
            const [s, l] = await Promise.all([
                supabase.from('services').select('*').eq('active', true).order('sort'),
                supabase.from('listings').select('service_id').eq('active', true),
            ]);
            setServices(s.data || []);
            const c = {};
            (l.data || []).forEach((r) => { c[r.service_id] = (c[r.service_id] || 0) + 1; });
            setCounts(c);
            setLoading(false);
        })();
    }, []);
    if (profile?.role === 'seller')
        return _jsx(Navigate, { to: "/seller", replace: true });
    const list = services.filter((s) => s.name.toLowerCase().includes(q.toLowerCase().trim()));
    const first = (profile?.full_name || '').split(' ')[0];
    return (_jsxs(_Fragment, { children: [_jsxs("section", { className: "hero", children: [_jsx("span", { className: "kite", children: _jsx(Logo, { size: 54 }) }), _jsxs("p", { className: "small", style: { marginBottom: '.2rem' }, children: ["Assalam o Alaikum", first ? `, ${first}` : ''] }), _jsxs("h1", { children: ["Aap ko kaunsa", _jsx("br", {}), "kaam karwana hai?"] }), _jsxs("div", { className: "search-wrap", children: [_jsx(Icon, { name: "search", size: 19 }), _jsx("input", { className: "search", placeholder: "Plumber, AC repair, mazdoor...", value: q, onChange: (e) => setQ(e.target.value), "aria-label": "Service dhoondein" })] })] }), _jsxs("div", { className: "sec-head", children: [_jsx("h2", { children: "Saari services" }), _jsxs("span", { className: "small muted", children: [list.length, " available"] })] }), loading ? (_jsx("div", { className: "tiles", children: Array.from({ length: 8 }).map((_, i) => _jsx(Skel, { h: 112, r: 16 }, i)) })) : list.length === 0 ? (_jsx(Empty, { icon: "search", title: "Koi service nahi mili", text: "Koi aur naam try karein." })) : (_jsx("div", { className: "tiles", children: list.map((s) => (_jsxs(Link, { to: `/service/${s.slug}`, className: "tile", style: { '--c': s.color }, children: [_jsx("div", { className: "ic-box", children: _jsx(ServiceIcon, { slug: s.slug, emoji: s.emoji, size: 24 }) }), _jsx("b", { children: s.name }), _jsx("small", { children: counts[s.id] ? `${counts[s.id]} seller${counts[s.id] > 1 ? 's' : ''}` : 'Jald aa rahe hain' })] }, s.id))) })), _jsxs("div", { className: "trust", children: [_jsxs("div", { className: "item", children: [_jsx("div", { className: "ic-box sm", children: _jsx(Icon, { name: "search", size: 18 }) }), _jsxs("div", { children: [_jsx("b", { children: "1. Seller chunein" }), _jsx("span", { children: "Price aur detail dekh kar" })] })] }), _jsxs("div", { className: "item", children: [_jsx("div", { className: "ic-box sm", children: _jsx(Icon, { name: "chat", size: 18 }) }), _jsxs("div", { children: [_jsx("b", { children: "2. Price par baat" }), _jsx("span", { children: "App ke andar, number ke baghair" })] })] }), _jsxs("div", { className: "item", children: [_jsx("div", { className: "ic-box sm", children: _jsx(Icon, { name: "shieldCheck", size: 18 }) }), _jsxs("div", { children: [_jsx("b", { children: "3. Admin approval" }), _jsx("span", { children: "Phir admin dono se rabta karta hai" })] })] })] })] }));
}
