/* =============================================================
   LAMPION POS · js/pages/menu.js  (pengganti menu.php)
   -------------------------------------------------------------
   CRUD menu + pengaturan bahan (pivot menu_inventory).
   Semua data lewat LPAPI.menus / categories / inventory.
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function money(n) { return PHP.money(n); }
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  var S = { items: [], cats: [], inv: [], };

  /* ---------- data ---------- */
  function loadAll() {
    return Promise.all([
      LP.api('api/menus.php?all=1', { method: 'GET' }),
      LP.api('api/categories.php', { method: 'GET' }),
      LP.api('api/inventory.php', { method: 'GET' })
    ]).then(function (res) {
      S.items = res[0].items || [];
      S.cats = res[1].categories || [];
      S.inv = res[2].inventory || [];
      fillCatSelects();
      render();
    });
  }

  function fillCatSelects() {
    var f = $('f-cat');
    var current = f ? f.value : '';
    if (f) {
      f.innerHTML = '<option value="">Semua kategori</option>' +
        S.cats.map(function (c) {
          return '<option value="' + Number(c.id) + '">' + esc(c.name) + '</option>';
        }).join('');
      f.value = current;
    }
  }

  /* ---------- render tabel ---------- */
  function render() {
    var tb = $('tb-menu');
    if (!tb) { return; }

    var q = String(($('f-search') || {}).value || '').toLowerCase().trim();
    var cat = ($('f-cat') || {}).value || '';
    var all = (($('f-active') || {}).value || '1') === '0';

    var catName = {};
    S.cats.forEach(function (c) { catName[Number(c.id)] = String(c.name); });

    var rows = S.items.filter(function (it) {
      if (!all && Number(it.is_active) !== 1) { return false; }
      if (cat !== '' && Number(it.category_id) !== Number(cat)) { return false; }
      if (q !== '' && String(it.name).toLowerCase().indexOf(q) === -1) { return false; }
      return true;
    });

    if (rows.length === 0) {
      tb.innerHTML = LPUI.emptyRow(8, 'Tidak ada menu', 'Tambahkan menu baru atau ubah filter.');
      return;
    }

    tb.innerHTML = rows.map(function (it) {
      return '<tr>' +
        '<td><b>' + esc(it.name) + '</b>' +
        (it.description ? '<div class="text-muted" style="font-size:11.5px">' +
          esc(it.description) + '</div>' : '') + '</td>' +
        '<td>' + esc(catName[Number(it.category_id)] || '-') + '</td>' +
        '<td class="num">' + money(it.price_dine_in) + '</td>' +
        '<td class="num">' + money(it.price_takeaway) + '</td>' +
        '<td class="num">' + money(it.price_online) + '</td>' +
        '<td>' + (Number(it.usage_cnt) > 0
          ? '<span class="badge info">' + Number(it.usage_cnt) + ' bahan</span>'
          : '<span class="text-muted">-</span>') + '</td>' +
        '<td>' + LPUI.useBadge(Number(it.is_active) === 1) + '</td>' +
        '<td class="nowrap">' +
        '<button class="btn btn-sm" data-edit="' + Number(it.id) + '">Ubah</button> ' +
        '<button class="btn btn-sm btn-danger" data-del="' + Number(it.id) + '">Hapus</button>' +
        '</td></tr>';
    }).join('');
  }


  /* ---------- form modal ---------- */
  function invOptions(selectedId) {
    return S.inv.map(function (i) {
      return '<option value="' + Number(i.id) + '"' +
        (Number(selectedId) === Number(i.id) ? ' selected' : '') + '>' +
        esc(i.name) + ' (' + esc(i.unit) + ')</option>';
    }).join('');
  }

  function invRowHTML(selId, qty) {
    return '<div class="inv-row row-inline" style="margin-bottom:7px">' +
      '<select class="inv-sel grow">' +
      '<option value="">&mdash; pilih bahan &mdash;</option>' + invOptions(selId) + '</select>' +
      '<input type="number" class="inv-qty" step="0.01" min="0" value="' +
      (qty === undefined ? 1 : qty) + '" style="width:96px">' +
      '<button type="button" class="btn btn-sm btn-danger" data-inv-del>&times;</button>' +
      '</div>';
  }

  function openForm(item) {
    var isEdit = !!item;
    var it = item || {
      id: 0, category_id: (S.cats[0] || {}).id || 0, name: '', description: '',
      price_dine_in: 0, price_takeaway: 0, price_online: 0,
      is_active: 1, sort_order: 0
    };

    /* ambil relasi bahan yang ada untuk mode ubah */
    var pre = isEdit
      ? LPDB.db.menu_inventory.where('menu_id').equals(Number(it.id)).toArray()
      : Promise.resolve([]);

    pre.then(function (pivots) {
      var body = '' +
        '<div class="field"><label>Nama menu *</label>' +
        '<input type="text" id="m-name" value="' + esc(it.name) + '"></div>' +
        '<div class="field"><label>Kategori *</label>' +
        '<select id="m-cat">' + S.cats.map(function (c) {
          return '<option value="' + Number(c.id) + '"' +
            (Number(it.category_id) === Number(c.id) ? ' selected' : '') + '>' +
            esc(c.name) + '</option>';
        }).join('') + '</select></div>' +
        '<div class="field"><label>Deskripsi</label>' +
        '<textarea id="m-desc" rows="2">' + esc(it.description) + '</textarea></div>' +
        '<div class="grid3">' +
        '<div class="field"><label>Harga Dine-in</label>' +
        '<input type="number" id="m-pd" min="0" step="500" value="' + Number(it.price_dine_in) + '"></div>' +
        '<div class="field"><label>Harga Take-away</label>' +
        '<input type="number" id="m-pt" min="0" step="500" value="' + Number(it.price_takeaway) + '"></div>' +
        '<div class="field"><label>Harga Online</label>' +
        '<input type="number" id="m-po" min="0" step="500" value="' + Number(it.price_online) + '"></div>' +
        '</div>' +
        '<div class="grid2">' +
        '<div class="field"><label>Urutan</label>' +
        '<input type="number" id="m-sort" value="' + Number(it.sort_order || 0) + '"></div>' +
        '<div class="field"><label>Status</label>' +
        '<div class="check"><input type="checkbox" id="m-active"' +
        (Number(it.is_active) === 1 ? ' checked' : '') +
        '> <span>Aktif (tampil di kasir)</span></div></div>' +
        '</div>' +
        '<div class="field"><label>Bahan terpakai (stok ikut terpotong)</label>' +
        '<div id="m-inv">' +
        (pivots.length ? pivots.map(function (p) {
          return invRowHTML(p.inventory_id, p.qty_used);
        }).join('') : invRowHTML('', 1)) +
        '</div>' +
        '<button class="btn btn-sm mt-12" type="button" id="m-inv-add">+ Tambah bahan</button>' +
        '<div class="hint">Contoh: 1 porsi memakai 0,5 ekor ayam.</div></div>';

      var md = LPUI.modal({
        title: isEdit ? 'Ubah Menu' : 'Menu Baru',
        body: body,
        foot: '<button class="btn" type="button" data-x>Batal</button>' +
          '<button class="btn btn-primary" type="button" id="m-save">Simpan</button>',
        width: 560
      });

      md.el.querySelector('#m-inv-add').addEventListener('click', function () {
        md.el.querySelector('#m-inv').insertAdjacentHTML('beforeend', invRowHTML('', 1));
      });
      md.el.addEventListener('click', function (e) {
        if (e.target.closest('[data-inv-del]')) {
          var row = e.target.closest('.inv-row');
          if (row && row.parentNode) { row.parentNode.removeChild(row); }
        }
      });

      md.el.querySelector('#m-save').addEventListener('click', function () {
        var payload = {
          action: 'save',
          id: Number(it.id) || 0,
          name: md.el.querySelector('#m-name').value.trim(),
          category_id: Number(md.el.querySelector('#m-cat').value),
          description: md.el.querySelector('#m-desc').value,
          price_dine_in: md.el.querySelector('#m-pd').value,
          price_takeaway: md.el.querySelector('#m-pt').value,
          price_online: md.el.querySelector('#m-po').value,
          sort_order: md.el.querySelector('#m-sort').value,
          is_active: md.el.querySelector('#m-active').checked ? 1 : 0,
          inventory: []
        };
        md.el.querySelectorAll('.inv-row').forEach(function (r) {
          var iid = Number(r.querySelector('.inv-sel').value);
          var q = Number(r.querySelector('.inv-qty').value);
          if (iid > 0 && q > 0) {
            payload.inventory.push({ inventory_id: iid, qty_used: q });
          }
        });

        if (payload.name === '') { return LP.toast('Nama menu wajib diisi.', 'warn'); }
        if (!(payload.category_id > 0)) { return LP.toast('Pilih kategori.', 'warn'); }

        return LP.api('api/menus.php', { method: 'POST', body: JSON.stringify(payload) })
          .then(function () {
            md.close();
            LP.toast('Menu disimpan.', 'ok');
            return loadAll();
          })
          .catch(function (e) { LP.toast(e.message, 'err'); });
      });
    });
  }

  /* ---------- hapus menu ---------- */
  function removeItem(id) {
    LP.confirm('Hapus menu ini? Menu yang pernah dipesan tidak dapat dihapus — ' +
      'gunakan status non-aktif sebagai gantinya.').then(function (ok) {
        if (!ok) { return null; }
        return LP.api('api/menus.php', {
          method: 'POST', body: JSON.stringify({ action: 'delete', id: Number(id) })
        }).then(function () {
          LP.toast('Menu dihapus.', 'ok');
          return loadAll();
        }).catch(function (e) { LP.toast(e.message, 'err', 5000); });
      });
  }

  /* ---------- kategori cepat ---------- */
  function newCategory() {
    var md = LPUI.modal({
      title: 'Kategori Baru',
      body: '<div class="field"><label>Nama kategori *</label>' +
        '<input type="text" id="c-name" placeholder="Contoh: Minuman"></div>' +
        '<div class="field"><label>Urutan</label>' +
        '<input type="number" id="c-sort" value="0"></div>',
      foot: '<button class="btn" type="button" data-x>Batal</button>' +
        '<button class="btn btn-primary" type="button" id="c-save">Simpan</button>'
    });

    md.el.querySelector('#c-save').addEventListener('click', function () {
      var name = md.el.querySelector('#c-name').value.trim();
      if (name === '') { return LP.toast('Nama kategori wajib.', 'warn'); }
      return LP.api('api/categories.php', {
        method: 'POST',
        body: JSON.stringify({
          action: 'save', name: name,
          sort_order: md.el.querySelector('#c-sort').value, is_active: 1
        })
      }).then(function () {
        md.close();
        LP.toast('Kategori disimpan.', 'ok');
        return loadAll();
      }).catch(function (e) { LP.toast(e.message, 'err'); });
    });
  }

  /* ---------- bind & init ---------- */
  function bind() {
    ['f-search', 'f-cat', 'f-active'].forEach(function (id) {
      var el = $(id);
      if (el) {
        el.addEventListener('input', render);
        el.addEventListener('change', render);
      }
    });

    $('btn-new').addEventListener('click', function () { openForm(null); });
    $('btn-new-cat').addEventListener('click', newCategory);

    $('tb-menu').addEventListener('click', function (e) {
      var ed = e.target.closest('[data-edit]');
      var dl = e.target.closest('[data-del]');
      if (ed) {
        var id = Number(ed.dataset.edit);
        var item = S.items.filter(function (x) { return Number(x.id) === id; })[0];
        if (item) { openForm(item); }
      } else if (dl) {
        removeItem(Number(dl.dataset.del));
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('menu.view', function () {
      LPUI.mountChrome('menu.html');
      bind();
      loadAll().catch(function (e) {
        LP.toast('Gagal memuat data: ' + e.message, 'err', 6000);
      });
    });
  });
})();

