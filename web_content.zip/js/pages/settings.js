/* =============================================================
   LAMPION POS · js/pages/settings.js  (pengganti settings.php)
   -------------------------------------------------------------
   Menyimpan pengaturan + fitur cadangan/pemulihan database lokal
   (pengganti peran file .sqlite + phpMyAdmin pada versi PHP).
   ============================================================= */
(function () {
  'use strict';

  var DB = window.LPDB;
  var PHP = window.LPHP;
  function $(id) { return document.getElementById(id); }

  var FIELDS = ['store_name', 'store_address', 'store_phone', 'store_footer', 'tax_rate',
    'pos_item_style', 'kiosk_fullscreen', 'print_kitchen', 'printer_mode', 'printer_width',
    'printer_service', 'printer_char', 'printer_font_px'];

  /* ---------- panel tambahan mode ESC/POS ---------- */
  function syncPrinterPanel() {
    var mode = ($('s-printer_mode') || {}).value || 'browser';
    var extra = (mode !== 'browser');
    if ($('escpos-extra')) { $('escpos-extra').style.display = extra ? '' : 'none'; }
    if ($('escpos-browser-hint')) { $('escpos-browser-hint').style.display = extra ? 'none' : ''; }
  }

  /** Uji cetak: buktikan aplikasi printer menerima intent sebelum dipakai di kasir */
  function testPrint() {
    if (!window.LPESCPOS) { return LP.toast('Modul printer tidak dimuat.', 'err'); }
    if (!LPESCPOS.available()) {
      return LP.toast('Uji cetak hanya berjalan di perangkat Android.', 'warn', 5000);
    }
    var store = {
      store_name: ($('s-store_name') || {}).value || 'Lampion Resto',
      printer_width: ($('s-printer_width') || {}).value || '58',
      printer_font_px: ($('s-printer_font_px') || {}).value || ''
    };
    return LPESCPOS.printTest(store).then(function (res) {
      if (res.handoff) {
        LP.toast('Perintah uji dikirim ke aplikasi printer.', 'ok');
      } else {
        LP.toast('Aplikasi Open ESC/POS tidak merespons. ' +
          'Pastikan aplikasinya terpasang di perangkat ini.', 'warn', 6000);
      }
    }).catch(function (e) {
      LP.toast('Uji cetak gagal: ' + e.message, 'err', 6000);
    });
  }

  /**
   * Kalibrasi ukuran font: cetak beberapa ukuran sekaligus supaya
   * pengguna bisa memilih yang paling pas selebar kertas.
   */
  function calibrate() {
    if (!window.LPESCPOS) { return LP.toast('Modul printer tidak dimuat.', 'err'); }
    if (!LPESCPOS.available()) {
      return LP.toast('Kalibrasi hanya berjalan di perangkat Android.', 'warn', 5000);
    }
    var store = {
      store_name: ($('s-store_name') || {}).value || 'Lampion Resto',
      printer_width: ($('s-printer_width') || {}).value || '58',
      printer_font_px: ($('s-printer_font_px') || {}).value || ''
    };
    return LPESCPOS.printCalibrate(store).then(function (res) {
      if (res.handoff) {
        LP.toast('Halaman kalibrasi dikirim. Pilih baris yang paling pas.', 'ok', 6000);
      } else {
        LP.toast('Aplikasi Open ESC/POS tidak merespons.', 'warn', 6000);
      }
    }).catch(function (e) {
      LP.toast('Kalibrasi gagal: ' + e.message, 'err', 6000);
    });
  }

  function load() {
    return LP.api('api/settings.php', { method: 'GET' }).then(function (res) {
      var s = res.settings || {};
      FIELDS.forEach(function (k) {
        var el = $('s-' + k);
        if (el) { el.value = (s[k] === undefined || s[k] === null) ? '' : String(s[k]); }
      });
    }).catch(function (e) {
      LP.toast('Gagal memuat pengaturan: ' + e.message, 'err', 5000);
    });
  }

  function save() {
    var payload = {};
    FIELDS.forEach(function (k) {
      var el = $('s-' + k);
      if (el) { payload[k] = el.value; }
    });

    var tax = PHP.parseMoney(payload.tax_rate);
    if (!(tax >= 0)) { return LP.toast('Pajak tidak valid.', 'warn'); }
    payload.tax_rate = String(tax);

    return LP.api('api/settings.php', { method: 'POST', body: JSON.stringify(payload) })
      .then(function () {
        LP.toast('Pengaturan disimpan.', 'ok');
      })
      .catch(function (e) { LP.toast(e.message, 'err'); });
  }

  /* ---------- cadangan / pemulihan ---------- */
  var TABLES = ['roles', 'permissions', 'role_permissions', 'users', 'settings',
    'categories', 'menu_items', 'inventory_items', 'menu_inventory',
    'orders', 'order_items', 'activity_log', 'customer_display',
    'auth_tokens', 'inventory_movements'];

  function backup() {
    var out = { app: 'lampion-pos', version: 1, created_at: DB.now(), tables: {} };
    var chain = Promise.resolve();

    TABLES.forEach(function (t) {
      chain = chain.then(function () {
        return DB.db.table(t).toArray().then(function (rows) { out.tables[t] = rows; });
      });
    });

    return chain.then(function () {
      var blob = new Blob([JSON.stringify(out)], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'lampion_pos_backup_' + DB.today() + '.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
      LP.toast('Cadangan diunduh.', 'ok');
    });
  }

  function restore(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var data;
      try { data = JSON.parse(String(reader.result)); } catch (e) {
        return LP.toast('File cadangan tidak valid.', 'err');
      }
      if (!data || !data.tables) { return LP.toast('Struktur cadangan tidak dikenali.', 'err'); }

      LP.confirm('Pulihkan cadangan? SEMUA data saat ini akan diganti.').then(function (ok) {
        if (!ok) { return null; }
        return DB.db.transaction('rw', DB.db.tables, function () {
          var jobs = [];
          TABLES.forEach(function (t) {
            if (!data.tables[t]) { return; }
            var tbl = DB.db.table(t);
            jobs.push(tbl.clear().then(function () {
              return data.tables[t].length ? tbl.bulkAdd(data.tables[t]) : 0;
            }));
          });
          return Promise.all(jobs);
        }).then(function () {
          LP.toast('Cadangan dipulihkan. Memuat ulang…', 'ok');
          setTimeout(function () { location.reload(); }, 900);
        }).catch(function (e) {
          LP.toast('Gagal memulihkan: ' + e.message, 'err', 6000);
        });
      });
    };
    reader.readAsText(file);
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('settings.manage', function () {
      LPUI.mountChrome('settings.html');

      $('btn-save').addEventListener('click', save);
      $('btn-backup').addEventListener('click', backup);

      if ($('s-printer_mode')) {
        $('s-printer_mode').addEventListener('change', syncPrinterPanel);
      }
      if ($('btn-test-print')) {
        $('btn-test-print').addEventListener('click', testPrint);
      }
      if ($('btn-calibrate')) {
        $('btn-calibrate').addEventListener('click', calibrate);
      }

      $('btn-restore').addEventListener('click', function () { $('f-restore').click(); });
      $('f-restore').addEventListener('change', function (e) {
        var f = e.target.files && e.target.files[0];
        if (f) { restore(f); }
        e.target.value = '';
      });

      load().then(syncPrinterPanel);
    });
  });
})();
