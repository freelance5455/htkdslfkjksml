(function(){
  const sessao = Auth.exigirPerfil('anfitriao', 'morador');
  if(!sessao) return;
  document.getElementById('linkVoltar').href = homeDoPerfil(sessao.tipo_usuario);
  if(sessao.tipo_usuario === 'morador'){
    // Campo de hóspedes (turnover de hospedagem) não faz sentido para quem
    // está contratando serviço para a própria residência.
    const campoHospedes = document.getElementById('campoHospedes');
    if(campoHospedes) campoHospedes.classList.add('hidden');
  }

  let categoriaEscolhida = null;
  let urgenciaEscolhida = 'Programado';
  let fotosBase64 = [];
  let requestId = null; // rascunho criado ao avançar da etapa 1

  // ---------- Etapa 1: imóveis ----------
  const imoveis = PropertiesService.listarDoAnfitriao(sessao.id).filter(im => im.status === 'ativo');
  const selImovel = document.getElementById('selImovel');
  if(imoveis.length === 0){
    selImovel.innerHTML = '<option value="">Nenhum imóvel ativo — cadastre um primeiro</option>';
  } else {
    selImovel.innerHTML = imoveis.map(im => `<option value="${im.id}">${im.nome} (${im.bairro}, ${im.cidade})</option>`).join('');
  }

  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      categoriaEscolhida = btn.dataset.cat;
    });
  });

  document.querySelectorAll('.urg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.urg-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      urgenciaEscolhida = btn.dataset.urg;
    });
  });
  document.querySelector('.urg-btn[data-urg="Programado"]').classList.add('selected');

  function irEtapa(n){
    [1,2,3].forEach(i => {
      document.getElementById('etapa'+i).classList.toggle('hidden', i !== n);
      document.getElementById('dot'+i).classList.toggle('active', i === n);
    });
    window.scrollTo(0,0);
  }

  /**
   * Deriva ambientes extras (cozinha/sala/varanda) a partir dos AMBIENTES já
   * cadastrados no imóvel (RoomsService), por nome — não pedimos essa
   * informação de novo na solicitação. Sem inventar dado: se nada estiver
   * cadastrado, simplesmente não há acréscimo por ambiente extra.
   */
  function detectarAmbientesExtra(propertyId){
    const nomes = RoomsService.listarPorImovel(propertyId).map(a => (a.nome||'').toLowerCase());
    const tem = (palavra) => nomes.some(n => n.includes(palavra));
    return { cozinha: tem('cozinha'), sala: tem('sala'), varanda: tem('varanda') || tem('sacada') };
  }

  function renderResumoImovelLimpeza(){
    const imovel = DB.find('properties', Number(selImovel.value));
    const box = document.getElementById('resumoImovelLimpeza');
    if(!imovel || !box) return;
    const ambientes = detectarAmbientesExtra(imovel.id);
    const extras = ['cozinha','sala','varanda'].filter(k => ambientes[k]);
    box.innerHTML = `
      <span>${imovel.quartos} quarto(s) · ${imovel.banheiros} banheiro(s) · ${imovel.camas} cama(s)</span>
      ${extras.length ? `<br><span class="text-muted">Ambientes extra cadastrados: ${extras.join(', ')}</span>` : ''}
    `;
  }

  document.getElementById('btnIrEtapa2').addEventListener('click', () => {
    document.getElementById('erroImovel').classList.remove('show');
    document.getElementById('erroCategoria').classList.remove('show');
    let ok = true;
    if(!selImovel.value){ document.getElementById('erroImovel').innerText='Selecione um imóvel.'; document.getElementById('erroImovel').classList.add('show'); ok=false; }
    if(!categoriaEscolhida){ document.getElementById('erroCategoria').innerText='Selecione uma categoria.'; document.getElementById('erroCategoria').classList.add('show'); ok=false; }
    if(!ok) return;

    if(!requestId){
      const rascunho = ServiceRequestsService.criarRascunho(sessao.id, { property_id: Number(selImovel.value), categoria: categoriaEscolhida });
      requestId = rascunho.id;
    }

    document.getElementById('camposLimpeza').classList.toggle('hidden', categoriaEscolhida !== 'Limpeza');
    document.getElementById('camposReparo').classList.toggle('hidden', categoriaEscolhida !== 'Pequenos Reparos');
    document.getElementById('camposEnxoval').classList.toggle('hidden', categoriaEscolhida !== 'Roupa de cama / Enxoval');
    if(categoriaEscolhida === 'Limpeza') renderResumoImovelLimpeza();
    irEtapa(2);
  });

  document.getElementById('btnVoltarEtapa1').addEventListener('click', () => irEtapa(1));
  document.getElementById('btnVoltarEtapa2').addEventListener('click', () => irEtapa(2));

  // ---------- Fotos ----------
  document.getElementById('reqFotos').addEventListener('change', function(e){
    Array.from(e.target.files).slice(0,6).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { fotosBase64.push(ev.target.result); renderFotos(); };
      reader.readAsDataURL(file);
    });
  });
  function renderFotos(){
    document.getElementById('previewFotosReq').innerHTML = fotosBase64.map(src =>
      `<img src="${src}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join('');
  }

  function coletarDetalhes(){
    if(categoriaEscolhida === 'Limpeza'){
      const imovel = DB.find('properties', Number(selImovel.value));
      const ambientes = detectarAmbientesExtra(imovel.id);
      return {
        tipo: document.getElementById('limpezaTipo').value,
        // Reaproveitados automaticamente do imóvel já cadastrado — não pedimos de novo.
        quartos: imovel.quartos, banheiros: imovel.banheiros, camas: imovel.camas, capacidade: imovel.capacidade,
        cozinha: ambientes.cozinha, sala: ambientes.sala, varanda: ambientes.varanda,
        hospedes: sessao.tipo_usuario === 'morador' ? 0 : Number(document.getElementById('limpezaHospedes').value),
      };
    }
    if(categoriaEscolhida === 'Pequenos Reparos'){
      return {
        tipo: document.getElementById('reparoTipo').value.trim(),
        descricao: document.getElementById('reparoDescricao').value.trim(),
        necessitaAvaliacao: document.getElementById('reparoAvaliacao').checked,
      };
    }
    return {
      quantidade: Number(document.getElementById('enxovalQtd').value),
      tamanho: document.getElementById('enxovalTamanho').value,
      tipo: document.getElementById('enxovalTipo').value,
      retirada: document.getElementById('enxovalRetirada').value.trim(),
      entrega: document.getElementById('enxovalEntrega').value.trim(),
    };
  }

  let ultimoCalculo = null;

  document.getElementById('btnIrEtapa3').addEventListener('click', () => {
    document.getElementById('erroData').classList.remove('show');
    document.getElementById('erroDescricao').classList.remove('show');

    const data = document.getElementById('reqData').value;
    const horario = document.getElementById('reqHorario').value;
    const detalhes = coletarDetalhes();

    const erros = Models.validarSolicitacao({ property_id: selImovel.value, categoria: categoriaEscolhida, data, horario, detalhes });
    if(Object.keys(erros).length){
      if(erros.data || erros.horario){ document.getElementById('erroData').innerText = erros.data || erros.horario; document.getElementById('erroData').classList.add('show'); }
      if(erros.descricao){ document.getElementById('erroDescricao').innerText = erros.descricao; document.getElementById('erroDescricao').classList.add('show'); }
      mostrarToast('Verifique os campos destacados.');
      return;
    }

    ultimoCalculo = PricingService.calcular({
      categoria: categoriaEscolhida, data, horario, urgencia: urgenciaEscolhida,
      limpeza: categoriaEscolhida === 'Limpeza' ? detalhes : undefined,
      reparo: categoriaEscolhida === 'Pequenos Reparos' ? detalhes : undefined,
      enxoval: categoriaEscolhida === 'Roupa de cama / Enxoval' ? detalhes : undefined,
    });

    renderResumo(ultimoCalculo, detalhes, data, horario);
    irEtapa(3);
  });

  function renderResumo(calc, detalhes, data, horario){
    const cont = document.getElementById('resumoPreco');
    if(calc.necessitaAvaliacao){
      cont.innerHTML = `<p class="text-[13px]" style="color:var(--dourado-escuro)">Este serviço será avaliado pelo profissional antes de um valor ser definido. Nenhum valor é cobrado na publicação.</p>`;
    } else {
      cont.innerHTML = calc.componentes.map(c => `
        <div class="linha"><span>${c.descricao}</span><span>R$ ${c.valor.toFixed(2)}</span></div>
      `).join('') + `
        <div class="linha"><span>Subtotal do serviço</span><span>R$ ${calc.valorServico.toFixed(2)}</span></div>
        <div class="linha"><span>Taxa de conveniência (5%)</span><span>R$ ${calc.taxaConveniencia.toFixed(2)}</span></div>
        <div class="linha total"><span>Você paga</span><span>R$ ${calc.valorAnfitriao.toFixed(2)}</span></div>
        <div class="linha"><span>Comissão da plataforma</span><span>- R$ ${calc.comissaoPlataforma.toFixed(2)}</span></div>
        <div class="linha"><span>Profissional recebe (estimado)</span><span>R$ ${calc.valorProfissional.toFixed(2)}</span></div>
      `;
    }

    const imovel = DB.find('properties', Number(selImovel.value));
    document.getElementById('resumoDetalhes').innerHTML = `
      <p class="text-[13px] font-bold mb-2">${categoriaEscolhida}</p>
      <p class="text-[12px] text-muted mb-1">${imovel.nome} — ${imovel.bairro}, ${imovel.cidade}</p>
      <p class="text-[12px] text-muted mb-1">${formatarData(data)} às ${horario} · ${urgenciaEscolhida}</p>
      ${fotosBase64.length ? `<p class="text-[12px] text-muted">${fotosBase64.length} foto(s) anexada(s)</p>` : ''}
    `;
  }

  document.getElementById('btnPublicar').addEventListener('click', () => {
    const data = document.getElementById('reqData').value;
    const horario = document.getElementById('reqHorario').value;
    const detalhes = coletarDetalhes();
    const observacoes = document.getElementById('reqObs').value.trim();

    try{
      ServiceRequestsService.publicar(sessao.id, requestId, {
        data, horario, urgencia: urgenciaEscolhida, detalhes, observacoes, fotos: fotosBase64,
      });
      mostrarToast('Solicitação publicada! Profissionais já podem visualizar.');
      setTimeout(()=> window.location.href = homeDoPerfil(sessao.tipo_usuario), 700);
    }catch(err){
      mostrarToast(err.message);
    }
  });

  refreshIcons();
})();
