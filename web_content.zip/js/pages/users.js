/* =============================================================
   LAMPION POS · js/pages/users.js  (pengganti users.php)
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  var users = [];
  var roles = [];

  function load() {
    return Promise.all([
      LP.api('api/users.php?action=list_users', { method: 'GET' }),
      LP.api('api/users.php?action=list_roles', { method: 'GET' })
    ]).then(function (res) {
      users = res[0].users || [];
      roles = res[1].roles || [];
      render();
    }).catch(function (e) {
      LP.toast('Gagal memuat pengguna: ' + e.message, 'err', 5000);
    });
  }

  function render() {
    var tb = $('tb-user');
    if (!tb) { return; }
    if (users.length === 0) {
      tb.innerHTML = LPUI.emptyRow(6, 'Belum ada pengguna', 'Tambahkan pengguna pertama.');
      return;
    }
    tb.innerHTML = users.map(function (u) {
      return '<tr>' +
        '<td><b>' + esc(u.name) + '</b></td>' +
        '<td>' + esc(u.username) + '</td>' +
        '<td><span class="badge info">' + esc(u.role_name) + '</span></td>' +
        '<td class="nowrap">' + esc(String(u.created_at).slice(0, 10)) + '</td>' +
        '<td>' + LPUI.useBadge(Number(u.is_active) === 1) + '</td>' +
        '<td class="nowrap">' +
        '<button class="btn btn-sm" data-edit="' + Number(u.id) + '">Ubah</button> ' +
        '<button class="btn btn-sm btn-danger" data-del="' + Number(u.id) + '">Hapus</button>' +
        '</td></tr>';
    }).join('');
  }

  function openForm(user) {
    var isEdit = !!user;
    var u = user || { id: 0, username: '', name: '', role_id: 0, is_active: 1 };

    var md = LPUI.modal({
      title: isEdit ? 'Ubah Pengguna' : 'Pengguna Baru',
      body: '<div class="field"><label>Nama lengkap *</label>' +
        '<input type="text" id="u-name" value="' + esc(u.name) + '"></div>' +
        '<div class="field"><label>Username *</label>' +
        '<input type="text" id="u-user" value="' + esc(u.username) + '" autocomplete="off"></div>' +
        '<div class="field"><label>' + (isEdit ? 'Password baru (kosongkan bila tidak diubah)' : 'Password *') +
        '</label><input type="password" id="u-pass" autocomplete="new-password" placeholder="minimal 4 karakter"></div>' +
        '<div class="field"><label>Peran *</label>' +
        '<select id="u-role">' + roles.map(function (r) {
          return '<option value="' + Number(r.id) + '"' +
            (Number(u.role_id) === Number(r.id) ? ' selected' : '') + '>' +
            esc(r.name) + '</option>';
        }).join('') + '</select></div>' +
        '<div class="field"><label>Status</label>' +
        '<div class="check"><input type="checkbox" id="u-active"' +
        (Number(u.is_active) === 1 ? ' checked' : '') + '> <span>Aktif (bisa masuk)</span></div></div>',
      foot: '<button class="btn" type="button" data-x>Batal</button>' +
        '<button class="btn btn-primary" type="button" id="u-save">Simpan</button>'
    });

    md.el.querySelector('#u-save').addEventListener('click', function () {
      var pass = md.el.querySelector('#u-pass').value;
      if (!isEdit && pass.length < 4) {
        return LP.toast('Password minimal 4 karakter.', 'warn');
      }
      if (isEdit && pass !== '' && pass.length < 4) {
        return LP.toast('Password minimal 4 karakter.', 'warn');
      }
      return LP.api('api/users.php', {
        method: 'POST',
        body: JSON.stringify({
          action: 'save_user',
          id: Number(u.id) || 0,
          name: md.el.querySelector('#u-name').value.trim(),
          username: md.el.querySelector('#u-user').value.trim(),
          password: pass,
          role_id: Number(md.el.querySelector('#u-role').value),
          is_active: md.el.querySelector('#u-active').checked ? 1 : 0
        })
      }).then(function () {
        md.close();
        LP.toast('Pengguna disimpan.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 6000); });
    });
  }

  function remove(id) {
    LP.confirm('Hapus pengguna ini?').then(function (ok) {
      if (!ok) { return null; }
      return LP.api('api/users.php', {
        method: 'POST', body: JSON.stringify({ action: 'delete_user', id: Number(id) })
      }).then(function () {
        LP.toast('Pengguna dihapus.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 6000); });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('users.manage', function () {
      LPUI.mountChrome('users.html');

      $('btn-new').addEventListener('click', function () { openForm(null); });
      $('tb-user').addEventListener('click', function (e) {
        var ed = e.target.closest('[data-edit]');
        var dl = e.target.closest('[data-del]');
        if (ed) {
          var id = Number(ed.dataset.edit);
          var u = users.filter(function (x) { return Number(x.id) === id; })[0];
          if (u) { openForm(u); }
        } else if (dl) {
          remove(Number(dl.dataset.del));
        }
      });

      load();
    });
  });
})();
