(function(){
  const sessao = Auth.exigirLogin();
  if(!sessao) return;
  aplicarSessaoNoCabecalho();

  const usuario = UsersService.obter(sessao.id);
  document.getElementById('perfilNome').value = usuario.nome;
  document.getElementById('perfilEmail').value = usuario.email;
  document.getElementById('perfilTelefone').value = usuario.telefone;

  const rotulos = { anfitriao:'Anfitrião / Proprietário', profissional:'Profissional de serviço', morador:'Morador / Residente', administrador:'Administrador' };
  document.getElementById('perfilTipoBadge').innerText = rotulos[usuario.tipo_usuario] || '—';

  // Para o profissional, "Perfil" (tab-bar) é home-profissional.html — não
  // oportunidades.html (que é o destino genérico de homeDoPerfil para esse
  // tipo, usado noutros fluxos). Aqui o link deve voltar ao painel/perfil.
  const destinoRetorno = usuario.tipo_usuario === 'profissional' ? 'home-profissional.html' : homeDoPerfil(usuario.tipo_usuario);
  document.getElementById('areaAtalho').innerHTML = `
    <a href="${destinoRetorno}" class="service-row">
      <div class="icon-circle" style="background:#EAF1FD; color:var(--azul)"><i data-lucide="layout-dashboard"></i></div>
      <div class="flex-1"><h3>Retornar ao Perfil</h3><p>Voltar para a área principal do meu perfil</p></div>
      <i data-lucide="chevron-right" class="chev"></i>
    </a>
  `;
  refreshIcons();

  document.getElementById('formPerfil').addEventListener('submit', function(e){
    e.preventDefault();
    UsersService.atualizarPerfil(sessao.id, {
      nome: document.getElementById('perfilNome').value.trim(),
      telefone: document.getElementById('perfilTelefone').value.trim(),
    });
    const novaSessao = Object.assign({}, sessao, { nome: document.getElementById('perfilNome').value.trim() });
    localStorage.setItem(storageKey('session'), JSON.stringify(novaSessao));
    mostrarToast('Dados atualizados!');
    aplicarSessaoNoCabecalho();
  });

  document.getElementById('btnSair').addEventListener('click', function(){
    Auth.logout();
    window.location.href = 'index.html';
  });

  // ---------- Excluir cadastro (exclusivo do ambiente de teste — DEV) ----------
  // Exclusão sempre LÓGICA (nunca remove dados), reaproveitando os serviços de
  // exclusão já existentes (ProvidersService.excluir / UsersService.excluir),
  // que já bloqueiam o login via UsersService.definirStatus/setStatus.
  if(window.APP_CONFIG.ENV === 'dev' && usuario.tipo_usuario !== 'administrador'){
    document.getElementById('zonaExclusaoDev').classList.remove('hidden');
  }

  const modalExcluir = document.getElementById('modalExcluirCadastro');
  document.getElementById('btnExcluirCadastro')?.addEventListener('click', () => modalExcluir.classList.add('show'));
  document.getElementById('fecharModalExcluirCadastro')?.addEventListener('click', () => modalExcluir.classList.remove('show'));
  document.getElementById('btnCancelarExclusaoCadastro')?.addEventListener('click', () => modalExcluir.classList.remove('show'));
  document.getElementById('btnConfirmarExclusaoCadastro')?.addEventListener('click', () => {
    if(usuario.tipo_usuario === 'profissional'){
      const provider = ProvidersService.obterPorUsuario(sessao.id);
      if(provider) ProvidersService.excluir(provider.id, sessao.id);
      else UsersService.excluir(sessao.id, sessao.id);
    } else {
      UsersService.excluir(sessao.id, sessao.id);
    }
    Auth.logout();
    window.location.href = 'index.html';
  });
})();
