/* =============================================================
   LAMPION POS · js/pages/inventory.js  (pengganti inventory.php)
   -------------------------------------------------------------
   CRUD bahan + pergerakan stok masuk/keluar (tabel
   inventory_movements sebagai catatan audit).
   ============================================================= */
(function () {
  'use strict';

  var PHP = window.LPHP;
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }

  var rows = [];

  function load() {
    return LP.api('api/inventory.php', { method: 'GET' }).then(function (res) {
      rows = res.inventory || [];
      render();
    }).catch(function (e) {
      LP.toast('Gagal memuat inventory: ' + e.message, 'err', 5000);
    });
  }

  function render() {
    var tb = $('tb-inv');
    if (!tb) { return; }

    var q = String(($('f-search') || {}).value || '').toLowerCase().trim();
    var lowOnly = ($('f-low') || {}).checked;

    var list = rows.filter(function (i) {
      if (q !== '' && String(i.name).toLowerCase().indexOf(q) === -1) { return false; }
      if (lowOnly && !(Number(i.stock_qty) <= Number(i.min_stock))) { return false; }
      return true;
    });

    if (list.length === 0) {
      tb.innerHTML = LPUI.emptyRow(6, 'Tidak ada bahan', 'Tambahkan bahan baru.');
      return;
    }

    tb.innerHTML = list.map(function (i) {
      var low = Number(i.stock_qty) <= Number(i.min_stock);
      return '<tr>' +
        '<td><b>' + esc(i.name) + '</b>' +
        (i.note ? '<div class="text-muted" style="font-size:11.5px">' + esc(i.note) + '</div>' : '') +
        '</td>' +
        '<td class="num"><b style="color:' + (low ? '#b91c1c' : '#166534') + '">' +
        Number(i.stock_qty) + '</b></td>' +
        '<td class="num">' + Number(i.min_stock) + '</td>' +
        '<td>' + esc(i.unit) + '</td>' +
        '<td>' + (i.menus_used
          ? '<span class="text-muted" style="font-size:11.5px">' + esc(i.menus_used) + '</span>'
          : '<span class="text-muted">-</span>') + '</td>' +
        '<td class="nowrap">' +
        '<button class="btn btn-sm" data-move="' + Number(i.id) + '">Stok</button> ' +
        '<button class="btn btn-sm" data-edit="' + Number(i.id) + '">Ubah</button> ' +
        '<button class="btn btn-sm btn-danger" data-del="' + Number(i.id) + '">Hapus</button>' +
        '</td></tr>';
    }).join('');
  }

  /* ---------- form bahan ---------- */
  function openForm(item) {
    var isEdit = !!item;
    var i = item || {
      id: 0, name: '', unit: 'pcs', stock_qty: 0, min_stock: 0, note: '', is_active: 1
    };

    var md = LPUI.modal({
      title: isEdit ? 'Ubah Bahan' : 'Bahan Baru',
      body: '<div class="field"><label>Nama bahan *</label>' +
        '<input type="text" id="i-name" value="' + esc(i.name) + '"></div>' +
        '<div class="grid3">' +
        '<div class="field"><label>Satuan</label>' +
        '<input type="text" id="i-unit" value="' + esc(i.unit) + '"></div>' +
        '<div class="field"><label>Stok awal</label>' +
        '<input type="number" id="i-stock" step="0.01" value="' + Number(i.stock_qty) + '"></div>' +
        '<div class="field"><label>Stok minimum</label>' +
        '<input type="number" id="i-min" step="0.01" value="' + Number(i.min_stock) + '"></div>' +
        '</div>' +
        '<div class="field"><label>Catatan</label>' +
        '<input type="text" id="i-note" value="' + esc(i.note) + '"></div>' +
        '<div class="field"><label>Status</label>' +
        '<div class="check"><input type="checkbox" id="i-active"' +
        (Number(i.is_active) === 1 ? ' checked' : '') + '> <span>Aktif</span></div></div>',
      foot: '<button class="btn" type="button" data-x>Batal</button>' +
        '<button class="btn btn-primary" type="button" id="i-save">Simpan</button>'
    });

    md.el.querySelector('#i-save').addEventListener('click', function () {
      var name = md.el.querySelector('#i-name').value.trim();
      if (name === '') { return LP.toast('Nama bahan wajib.', 'warn'); }
      return LP.api('api/inventory.php', {
        method: 'POST',
        body: JSON.stringify({
          action: 'save',
          id: Number(i.id) || 0,
          name: name,
          unit: md.el.querySelector('#i-unit').value.trim() || 'pcs',
          stock_qty: md.el.querySelector('#i-stock').value,
          min_stock: md.el.querySelector('#i-min').value,
          note: md.el.querySelector('#i-note').value,
          is_active: md.el.querySelector('#i-active').checked ? 1 : 0
        })
      }).then(function () {
        md.close();
        LP.toast('Bahan disimpan.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err'); });
    });
  }


  /* ---------- pergerakan stok ---------- */
  function openMove(item) {
    var md = LPUI.modal({
      title: 'Stok: ' + item.name,
      body: '<div class="field"><label>Stok saat ini</label>' +
        '<div style="font-size:20px;font-weight:800">' + Number(item.stock_qty) + ' ' +
        esc(item.unit) + '</div></div>' +
        '<div class="field"><label>Jenis</label>' +
        '<select id="v-type">' +
        '<option value="in">Masuk (tambah stok)</option>' +
        '<option value="out">Keluar (kurangi stok)</option>' +
        '</select></div>' +
        '<div class="field"><label>Jumlah *</label>' +
        '<input type="number" id="v-qty" step="0.01" min="0" value="1"></div>' +
        '<div class="field"><label>Catatan</label>' +
        '<input type="text" id="v-note" placeholder="Contoh: belanja pasar"></div>',
      foot: '<button class="btn" type="button" data-x>Batal</button>' +
        '<button class="btn btn-primary" type="button" id="v-save">Simpan</button>'
    });

    md.el.querySelector('#v-save').addEventListener('click', function () {
      var qty = Number(md.el.querySelector('#v-qty').value);
      if (!(qty > 0)) { return LP.toast('Jumlah harus lebih dari 0.', 'warn'); }
      return LP.api('api/inventory.php', {
        method: 'POST',
        body: JSON.stringify({
          action: 'move',
          id: Number(item.id),
          type: md.el.querySelector('#v-type').value,
          qty: qty,
          note: md.el.querySelector('#v-note').value
        })
      }).then(function () {
        md.close();
        LP.toast('Stok diperbarui.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 6000); });
    });
  }

  function remove(id) {
    LP.confirm('Hapus bahan ini?').then(function (ok) {
      if (!ok) { return null; }
      return LP.api('api/inventory.php', {
        method: 'POST', body: JSON.stringify({ action: 'delete', id: Number(id) })
      }).then(function () {
        LP.toast('Bahan dihapus.', 'ok');
        return load();
      }).catch(function (e) { LP.toast(e.message, 'err', 6000); });
    });
  }

  function findBy(id) {
    return rows.filter(function (x) { return Number(x.id) === Number(id); })[0];
  }

  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('inventory.view', function () {
      LPUI.mountChrome('inventory.html');

      if ($('f-search')) { $('f-search').addEventListener('input', render); }
      if ($('f-low')) { $('f-low').addEventListener('change', render); }
      $('btn-new').addEventListener('click', function () { openForm(null); });

      $('tb-inv').addEventListener('click', function (e) {
        var mv = e.target.closest('[data-move]');
        var ed = e.target.closest('[data-edit]');
        var dl = e.target.closest('[data-del]');

        var id = 0;
        if (mv) { id = Number(mv.dataset.move); }
        else if (ed) { id = Number(ed.dataset.edit); }
        else if (dl) { id = Number(dl.dataset.del); }
        else { return; }

        var row = findBy(id);
        if (!row) { return; }
        if (mv) { openMove(row); }
        else if (ed) { openForm(row); }
        else { remove(id); }
      });

      load();
    });
  });
})();
