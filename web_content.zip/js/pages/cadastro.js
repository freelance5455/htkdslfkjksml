(function(){
  let tipoEscolhido = null;
  let selfieBase64 = null;

  function marcarTipo(tipo){
    tipoEscolhido = tipo;
    document.getElementById('optAnfitriao').classList.toggle('selected', tipo === 'anfitriao');
    document.getElementById('optProfissional').classList.toggle('selected', tipo === 'profissional');
    document.getElementById('optMorador').classList.toggle('selected', tipo === 'morador');
    document.getElementById('camposProfissional').classList.toggle('hidden', tipo !== 'profissional');
    document.getElementById('campoCpfGeral').classList.toggle('hidden', tipo === 'profissional');
    if(tipo === 'profissional' && !document.getElementById('cadCategorias').dataset.montado){
      // Categoria exclusiva: cada profissional atua em UM papel só
      // (Faxineira / Marido de aluguel / Roupa de cama), nunca em vários ao
      // mesmo tempo — por isso são rádios (seleção única), não checkboxes.
      const rotulos = {
        [CATEGORIAS_SERVICO.LIMPEZA]: 'Faxineira — atende somente oportunidades de faxina',
        [CATEGORIAS_SERVICO.REPAROS]: 'Marido de aluguel — atende somente pequenos reparos',
        [CATEGORIAS_SERVICO.ENXOVAL]: 'Roupa de cama — atende somente locação de enxoval',
      };
      const categorias = CategoriesService.listarAtivas();
      document.getElementById('cadCategorias').innerHTML = categorias.map(c => `
        <label class="checkbox-pill"><input type="radio" name="categoriaCadastro" value="${c.nome}" class="chkCategoriaCadastro"> ${rotulos[c.nome] || c.nome}</label>
      `).join('');
      document.getElementById('cadCategorias').dataset.montado = '1';
    }
  }
  document.getElementById('optAnfitriao').onclick = () => marcarTipo('anfitriao');
  document.getElementById('optProfissional').onclick = () => marcarTipo('profissional');
  document.getElementById('optMorador').onclick = () => marcarTipo('morador');

  document.getElementById('cadSelfie').addEventListener('change', async function(e){
    const file = e.target.files[0];
    if(!file) return;
    try{
      // Compacta a selfie (fotos de câmera em alta resolução estouram a cota
      // do localStorage neste ambiente DEV sem backend/storage externo).
      selfieBase64 = await comprimirImagem(file);
      document.getElementById('previewSelfie').innerHTML = `<img src="${selfieBase64}" style="width:84px;height:84px;border-radius:50%;object-fit:cover">`;
    }catch(err){
      mostrarToast(err.message);
      e.target.value = '';
    }
  });

  const documentosBase64 = { rg_cpf: null, comprovante_residencia: null, certidao_antecedentes: null };
  function ligarUploadDocumento(inputId, tipo){
    document.getElementById(inputId).addEventListener('change', async function(e){
      const file = e.target.files[0];
      if(!file) return;
      const ehPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
      if(ehPdf){
        const erroTamanho = validarTamanhoArquivo(file, window.APP_CONFIG.LIMITES_ARQUIVO.DOCUMENTO_MAX_MB);
        if(erroTamanho){ mostrarToast(erroTamanho); e.target.value = ''; return; }
      }
      try{
        // Fotos são compactadas automaticamente; PDFs são aceitos como estão
        // (não é possível recomprimir PDF no navegador sem bibliotecas extras).
        documentosBase64[tipo] = await comprimirImagem(file);
      }catch(err){
        mostrarToast(err.message);
        e.target.value = '';
      }
    });
  }
  ligarUploadDocumento('cadDocRgCpf', 'rg_cpf');
  ligarUploadDocumento('cadDocComprovante', 'comprovante_residencia');
  ligarUploadDocumento('cadDocCertidao', 'certidao_antecedentes');

  function limparErros(){
    document.querySelectorAll('.form-error').forEach(e => { e.classList.remove('show'); e.innerText=''; });
  }
  function mostrarErro(campo, msg){
    const el = document.getElementById('erro' + campo.charAt(0).toUpperCase() + campo.slice(1));
    if(el){ el.innerText = msg; el.classList.add('show'); }
  }

  document.getElementById('formCadastro').addEventListener('submit', async function(e){
    e.preventDefault();
    limparErros();

    const dados = {
      nome: document.getElementById('cadNome').value.trim(),
      email: document.getElementById('cadEmail').value.trim(),
      telefone: document.getElementById('cadTelefone').value.trim(),
      senha: document.getElementById('cadSenha').value,
      tipo_usuario: tipoEscolhido,
      cpf: document.getElementById('cadCpfGeral').value.trim(),
    };

    const erros = Models.validarUsuario(dados);
    if(!document.getElementById('cadTermos').checked){
      mostrarToast('Você precisa aceitar os Termos de Uso.');
      return;
    }
    const categoriasEscolhidas = Array.from(document.querySelectorAll('.chkCategoriaCadastro:checked')).map(c => c.value);
    if(tipoEscolhido === 'profissional'){
      Object.assign(erros, Models.validarCadastroProfissional({ selfie: selfieBase64, categorias: categoriasEscolhidas }));
    }
    if(Object.keys(erros).length){
      Object.entries(erros).forEach(([campo,msg]) => mostrarErro(campo, msg));
      if(erros.tipo_usuario) mostrarToast('Escolha "Anfitrião", "Profissional" ou "Morador/Residente" acima.');
      if(erros.selfie) mostrarToast(erros.selfie);
      if(erros.categorias) mostrarToast(erros.categorias);
      return;
    }

    if(tipoEscolhido === 'profissional'){
      dados.dadosProfissional = {
        cpf: document.getElementById('cadCpf').value.trim(),
        rg: document.getElementById('cadRg').value.trim(),
        data_nascimento: document.getElementById('cadNascimento').value,
        endereco: document.getElementById('cadEnderecoProf').value.trim(),
        cidade: document.getElementById('cadCidadeProf').value.trim(),
        categorias: categoriasEscolhidas,
        selfie: selfieBase64,
        documentos: documentosBase64,
      };
    }

    const btn = document.getElementById('btnConcluirCadastro');
    btn.disabled = true; btn.innerText = 'Criando conta...';
    try{
      const usuario = await Auth.signUp(dados);
      mostrarToast((usuario._avisos && usuario._avisos.length) ? usuario._avisos[0] : 'Cadastro concluído com sucesso!');
      const destinos = { anfitriao:'home-anfitriao.html', profissional:'home-profissional.html', morador:'home-morador.html' };
      setTimeout(()=> window.location.href = destinos[usuario.tipo_usuario], (usuario._avisos && usuario._avisos.length) ? 1800 : 600);
    }catch(err){
      mostrarToast(err.message);
      btn.disabled = false; btn.innerText = 'Concluir cadastro';
    }
  });
})();
