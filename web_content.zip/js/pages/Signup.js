import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { appUrl, isStrong } from '../lib/util.js';
import PasswordInput, { PasswordRules } from '../components/PasswordInput.js';
import { Logo, Notice } from '../components/Bits.js';
import Icon from '../components/Icon.js';
export default function Signup() {
    const [params] = useSearchParams();
    const nav = useNavigate();
    const initial = params.get('role');
    const [role, setRole] = useState(initial === 'seller' ? 'seller' : initial === 'buyer' ? 'buyer' : null);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [pw, setPw] = useState('');
    const [pw2, setPw2] = useState('');
    const [err, setErr] = useState('');
    const [info, setInfo] = useState('');
    const [busy, setBusy] = useState(false);
    const canSubmit = !!role && name.trim().length >= 2 && /\S+@\S+\.\S+/.test(email) && isStrong(pw) && pw === pw2;
    async function manual(e) {
        e.preventDefault();
        if (!canSubmit || !role)
            return;
        setBusy(true);
        setErr('');
        setInfo('');
        localStorage.setItem('udaan_role', role);
        const { data, error } = await supabase.auth.signUp({
            email: email.trim(), password: pw,
            options: { data: { full_name: name.trim(), role }, emailRedirectTo: appUrl() },
        });
        setBusy(false);
        if (error)
            return setErr(error.message);
        if (data.session)
            nav('/onboarding', { replace: true });
        else
            setInfo('Aap ki email par verification link bheja gaya hai. Link khol kar login karein.');
    }
    return (_jsxs("div", { className: "auth-wrap", children: [_jsxs(Link, { to: "/", className: "row", style: { textDecoration: 'none', color: 'inherit', marginBottom: '1rem' }, children: [_jsx(Logo, {}), _jsx("b", { style: { fontFamily: 'var(--head)', fontSize: '1.5rem' }, children: "Udaan" })] }), _jsx("h2", { children: "Naya account banayein" }), _jsx("p", { className: "muted", children: "Pehle batayein aap kya hain:" }), _jsxs("div", { className: "roles", children: [_jsxs("button", { type: "button", className: `role ${role === 'buyer' ? 'on' : ''}`, onClick: () => setRole('buyer'), children: [_jsx("span", { className: "e", children: _jsx(Icon, { name: "cart", size: 22 }) }), _jsx("b", { children: "Buyer" }), _jsx("span", { className: "small muted", children: "Kaam karwana hai" })] }), _jsxs("button", { type: "button", className: `role ${role === 'seller' ? 'on' : ''}`, onClick: () => setRole('seller'), children: [_jsx("span", { className: "e", children: _jsx(Icon, { name: "briefcase", size: 22 }) }), _jsx("b", { children: "Seller" }), _jsx("span", { className: "small muted", children: "Kaam chahiye" })] })] }), _jsxs("form", { className: "stack", onSubmit: manual, children: [_jsxs("label", { className: "field", children: [_jsx("span", { children: "Poora naam" }), _jsx("input", { className: "input", value: name, onChange: (e) => setName(e.target.value), autoComplete: "name" })] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Email" }), _jsx("input", { className: "input", type: "email", value: email, onChange: (e) => setEmail(e.target.value), autoComplete: "email" })] }), _jsxs("div", { className: "field", children: [_jsx("span", { style: { fontWeight: 700, fontSize: '.9rem' }, children: "Strong password" }), _jsx(PasswordInput, { value: pw, onChange: setPw, autoComplete: "new-password" }), _jsx(PasswordRules, { value: pw })] }), _jsxs("div", { className: "field", children: [_jsx("span", { style: { fontWeight: 700, fontSize: '.9rem' }, children: "Password dobara likhein" }), _jsx(PasswordInput, { value: pw2, onChange: setPw2, placeholder: "Confirm password", autoComplete: "new-password" }), pw2 && pw !== pw2 && _jsx("p", { className: "small", style: { color: 'var(--coral)' }, children: "Dono password match nahi karte." })] }), err && _jsx(Notice, { kind: "error", children: err }), info && _jsx(Notice, { kind: "ok", children: info }), _jsx("button", { className: "btn primary block", disabled: !canSubmit || busy, children: busy ? 'Ho raha hai...' : 'Account banayein' })] }), _jsxs("p", { className: "center small", style: { marginTop: '1rem' }, children: ["Pehle se account hai? ", _jsx(Link, { to: "/login", children: "Login" })] })] }));
}
