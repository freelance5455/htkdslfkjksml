import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { fmtDate, money } from '../lib/util.js';
import { Avatar, Empty, ListSkeleton, Notice } from '../components/Bits.js';
import Icon, { ServiceIcon } from '../components/Icon.js';
import BookModal from '../components/BookModal.js';
export default function SellerProfile() {
    const { id } = useParams();
    const { profile } = useAuth();
    const nav = useNavigate();
    const [seller, setSeller] = useState(null);
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState('');
    const [booking, setBooking] = useState(null);
    useEffect(() => {
        (async () => {
            const [p, l] = await Promise.all([
                supabase.from('profiles').select('full_name, created_at').eq('id', id).maybeSingle(),
                supabase.from('listings').select('*, service:services(*)').eq('seller_id', id).eq('active', true).order('created_at', { ascending: false }),
            ]);
            setSeller(p.data);
            setItems(l.data || []);
            setLoading(false);
        })();
    }, [id]);
    async function start(l) {
        setBusy(l.id);
        setErr('');
        const { data, error } = await supabase.rpc('start_deal', { p_listing: l.id });
        setBusy('');
        if (error)
            return setErr(error.message);
        nav(`/deal/${data}`);
    }
    if (loading)
        return _jsx(ListSkeleton, { n: 2, h: 140 });
    if (!seller)
        return _jsx(Empty, { icon: "user", title: "Seller nahi mila" });
    const years = Math.max(...items.map((i) => i.experience_years), 0);
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "page-head", children: [_jsx("button", { className: "back", onClick: () => nav(-1), "aria-label": "Wapas", children: _jsx(Icon, { name: "chevL", size: 20 }) }), _jsx("h2", { style: { margin: 0 }, children: "Seller profile" })] }), _jsxs("div", { className: "card", style: { textAlign: 'center' }, children: [_jsx("div", { style: { display: 'grid', placeItems: 'center' }, children: _jsx(Avatar, { name: seller.full_name, size: "lg", gold: true }) }), _jsx("h2", { style: { marginTop: '.6rem' }, children: seller.full_name }), _jsxs("div", { className: "meta", style: { justifyContent: 'center' }, children: [_jsxs("span", { children: [_jsx(Icon, { name: "briefcase", size: 13 }), items.length, " service", items.length === 1 ? '' : 's'] }), years > 0 && _jsxs("span", { children: [_jsx(Icon, { name: "clock", size: 13 }), years, " saal tajurba"] }), _jsxs("span", { children: [_jsx(Icon, { name: "user", size: 13 }), "Member: ", fmtDate(seller.created_at).split(',')[0]] })] }), _jsxs("p", { className: "small muted", style: { margin: '.7rem 0 0' }, children: [_jsx(Icon, { name: "lock", size: 13 }), " Number aur address private hain. Baat app ke andar hoti hai."] })] }), err && _jsx(Notice, { kind: "error", children: err }), _jsx("div", { className: "sec-head", children: _jsx("h2", { children: "Sellers ki services" }) }), items.length === 0 ? _jsx(Empty, { icon: "briefcase", title: "Abhi koi service live nahi" }) : (_jsx("div", { className: "list", children: items.map((l) => (_jsxs("article", { className: "card", children: [_jsxs("div", { className: "row", children: [l.service && _jsx("div", { className: "ic-box sm", style: { '--c': l.service.color }, children: _jsx(ServiceIcon, { slug: l.service.slug, emoji: l.service.emoji, size: 20 }) }), _jsxs("div", { className: "grow", children: [_jsx("span", { className: "small muted", children: l.service?.name }), _jsx("h3", { style: { margin: 0 }, children: l.title })] })] }), l.details && _jsx("p", { className: "muted small", style: { margin: '.6rem 0 0' }, children: l.details }), _jsxs("div", { className: "meta", style: { marginTop: '.5rem' }, children: [_jsxs("span", { children: [_jsx(Icon, { name: "pin", size: 13 }), l.city || 'Shehar nahi likha'] }), l.experience_years > 0 && _jsxs("span", { children: [_jsx(Icon, { name: "clock", size: 13 }), l.experience_years, " saal"] })] }), _jsx("div", { style: { marginTop: '.8rem' }, children: _jsxs("div", { className: "price", children: [money(l.price), " ", _jsx("span", { className: "small muted", style: { fontWeight: 600 }, children: l.price_unit })] }) }), profile?.role === 'buyer' && (_jsxs("div", { className: "row", style: { marginTop: '.7rem' }, children: [_jsxs("button", { className: "btn ghost grow", disabled: busy === l.id, onClick: () => start(l), children: [_jsx(Icon, { name: "chat", size: 17 }), busy === l.id ? '...' : 'Baat karein'] }), _jsxs("button", { className: "btn primary grow", onClick: () => setBooking({ id: l.id, title: l.title, price: l.price, price_unit: l.price_unit, seller_name: seller.full_name }), children: [_jsx(Icon, { name: "check", size: 17 }), "Book karein"] })] }))] }, l.id))) })), _jsx(Link, { to: "/home", className: "small", style: { display: 'block', textAlign: 'center', marginTop: '1rem' }, children: "\u2190 Saari services" }), booking && _jsx(BookModal, { target: booking, onClose: () => setBooking(null), onDone: (did) => nav(`/deal/${did}`) })] }));
}
