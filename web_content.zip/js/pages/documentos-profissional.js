(function(){
  const sessao = Auth.exigirPerfil('profissional');
  if(!sessao) return;

  const provider = ProvidersService.obterPorUsuario(sessao.id);
  const r = ProvidersService.resumoPublico(provider.id);

  const ICONE_CATEGORIA = {
    [CATEGORIAS_SERVICO.LIMPEZA]: 'sparkles',
    [CATEGORIAS_SERVICO.REPAROS]: 'wrench',
    [CATEGORIAS_SERVICO.ENXOVAL]: 'bed',
  };
  const mapaStatusAprovacao = {
    PENDENTE: ['Pendente', 'pendente'], ENVIADO: ['Pendente', 'pendente'], EM_ANALISE: ['Em análise', 'pendente'],
    APROVADO: ['Aprovado', 'ativo'], REJEITADO: ['Não aprovado', 'inativo'],
  };

  document.getElementById('perfilAvatarFoto').src = provider.selfie || '';
  document.getElementById('perfilNome').innerText = r.nome;
  document.getElementById('perfilId').innerText = String(provider.id).padStart(5,'0');
  document.getElementById('perfilCategoria').innerText = (provider.categorias || []).join(', ') || 'Categoria não definida';
  document.getElementById('perfilIconeCategoria').setAttribute('data-lucide', ICONE_CATEGORIA[(provider.categorias||[])[0]] || 'wrench');
  const [txtAprov, classeAprov] = mapaStatusAprovacao[provider.status_aprovacao] || mapaStatusAprovacao.PENDENTE;
  const badge = document.getElementById('perfilBadgeAprovacao');
  badge.innerText = txtAprov;
  badge.className = 'badge-status ' + classeAprov;

  const ICONE_DOC = { rg_cpf:'id-card', comprovante_residencia:'home', certidao_antecedentes:'shield-check' };
  const COR_DOC = { rg_cpf:'var(--azul)', comprovante_residencia:'#7C5CE0', certidao_antecedentes:'#0E8FB0' };
  const ROTULOS_DOC = {
    rg_cpf: ['RG / CPF', 'Documento de identidade e CPF.'],
    comprovante_residencia: ['Comprovante de residência', 'Comprovante de endereço atualizado.'],
    certidao_antecedentes: ['Certidão de antecedentes', 'Certidão negativa de antecedentes criminais.'],
  };
  const BADGE_STATUS_DOC = {
    pendente:['Não enviado','inativo'], enviado:['Enviado','ativo'], em_analise:['Em análise','pendente'],
    aprovado:['Aprovado','ativo'], rejeitado:['Rejeitado','inativo'],
  };

  document.getElementById('listaDocumentos').innerHTML = ProvidersService.TIPOS_DOCUMENTO.map(tipo => {
    const doc = provider.documentos[tipo];
    const [titulo, desc] = ROTULOS_DOC[tipo];
    const [txt, classe] = BADGE_STATUS_DOC[doc.status] || BADGE_STATUS_DOC.pendente;
    const conteudo = `
      <div class="doc-page-icon" style="background:${COR_DOC[tipo]}"><i data-lucide="${ICONE_DOC[tipo]}"></i></div>
      <div class="flex-1 min-w-0">
        <div class="flex items-center gap-2 flex-wrap">
          <p class="font-semibold text-[13.5px]">${titulo}</p>
          <span class="badge-status ${classe}">${txt}</span>
        </div>
        <p class="text-[11.5px] text-muted mt-0.5">${desc}</p>
        ${doc.status === 'rejeitado' && doc.motivo_rejeicao ? `<p class="text-[10.5px] mt-1" style="color:#C0392B">${doc.motivo_rejeicao}</p>` : ''}
      </div>
      ${doc.arquivo ? `<i data-lucide="chevron-right" style="color:var(--muted);flex-shrink:0;margin-top:10px"></i>` : ''}
    `;
    return doc.arquivo
      ? `<a href="${doc.arquivo}" target="_blank" rel="noopener" class="doc-page-row" style="text-decoration:none;color:inherit">${conteudo}</a>`
      : `<div class="doc-page-row">${conteudo}</div>`;
  }).join('');

  refreshIcons();
})();
