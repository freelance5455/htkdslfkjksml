import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { money } from '../lib/util.js';
import { Empty, ListSkeleton, Notice } from '../components/Bits.js';
import Icon, { ServiceIcon } from '../components/Icon.js';
import BookModal from '../components/BookModal.js';
export default function ServiceSellers() {
    const { slug } = useParams();
    const { profile, contact } = useAuth();
    const nav = useNavigate();
    const [service, setService] = useState(null);
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [onlyMyCity, setOnlyMyCity] = useState(false);
    const [err, setErr] = useState('');
    const [busyId, setBusyId] = useState('');
    const [booking, setBooking] = useState(null);
    useEffect(() => {
        (async () => {
            const { data: s } = await supabase.from('services').select('*').eq('slug', slug).maybeSingle();
            setService(s);
            if (s) {
                const { data } = await supabase.from('listings').select('*, seller:profiles(full_name)')
                    .eq('service_id', s.id).eq('active', true).order('created_at', { ascending: false });
                setItems(data || []);
            }
            setLoading(false);
        })();
    }, [slug]);
    const myCity = (contact?.city || '').trim().toLowerCase();
    const sameCity = (l) => !!myCity && l.city.trim().toLowerCase() === myCity;
    const shown = useMemo(() => {
        const arr = items.filter((l) => !onlyMyCity || sameCity(l));
        return [...arr].sort((a, b) => Number(sameCity(b)) - Number(sameCity(a)));
    }, [items, onlyMyCity, myCity]);
    async function start(l) {
        setBusyId(l.id);
        setErr('');
        const { data, error } = await supabase.rpc('start_deal', { p_listing: l.id });
        setBusyId('');
        if (error)
            return setErr(error.message);
        nav(`/deal/${data}`);
    }
    if (loading)
        return _jsx(ListSkeleton, {});
    if (!service)
        return _jsx(Empty, { icon: "search", title: "Service nahi mili" });
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "page-head", children: [_jsx(Link, { to: "/home", className: "back", "aria-label": "Wapas", children: _jsx(Icon, { name: "chevL", size: 20 }) }), _jsx("div", { className: "ic-box sm", style: { '--c': service.color }, children: _jsx(ServiceIcon, { slug: service.slug, emoji: service.emoji, size: 20 }) }), _jsxs("div", { className: "grow", children: [_jsx("h2", { style: { margin: 0 }, children: service.name }), _jsxs("span", { className: "small muted", children: [items.length, " seller", items.length === 1 ? '' : 's'] })] })] }), _jsxs(Link, { to: `/service/${service.slug}/map`, className: "btn block", style: { margin: '.2rem 0 .8rem' }, children: [_jsx(Icon, { name: "pin", size: 18 }), " Map par nazdeek sellers dekhein (5 km)"] }), myCity && (_jsxs("div", { className: "tabs", children: [_jsx("button", { className: !onlyMyCity ? 'active' : '', onClick: () => setOnlyMyCity(false), children: "Sab sellers" }), _jsx("button", { className: onlyMyCity ? 'active' : '', onClick: () => setOnlyMyCity(true), children: "Mere shehar ke" })] })), _jsx(Notice, { kind: "info", children: "Seller ka number yahan nahi dikhta. Baat-cheet app ke andar hoti hai aur deal admin approve karta hai." }), err && _jsx(Notice, { kind: "error", children: err }), shown.length === 0 ? (_jsx(Empty, { icon: "briefcase", title: "Abhi koi seller nahi", text: onlyMyCity ? 'Aap ke shehar mein koi seller nahi. "Sab sellers" dekhein.' : 'Jald hi sellers judenge.' })) : (_jsx("div", { className: "list", children: shown.map((l) => (_jsxs("article", { className: "card", children: [_jsxs("div", { className: "row", children: [_jsx("div", { className: "seller-ic", children: (l.seller?.full_name || '?').charAt(0).toUpperCase() }), _jsxs("div", { className: "grow", children: [_jsx(Link, { to: `/seller-profile/${l.seller_id}`, style: { color: 'inherit', fontWeight: 700, textDecoration: 'none' }, children: l.seller?.full_name || 'Seller' }), _jsxs("div", { className: "meta", children: [_jsxs("span", { children: [_jsx(Icon, { name: "pin", size: 13 }), l.city || 'Shehar nahi likha'] }), l.experience_years > 0 && _jsxs("span", { children: [_jsx(Icon, { name: "clock", size: 13 }), l.experience_years, " saal tajurba"] })] })] }), sameCity(l) && _jsx("span", { className: "chip green", children: "Aap ke shehar mein" })] }), _jsx("div", { className: "divider-line" }), _jsx("h3", { children: l.title }), l.details && _jsx("p", { className: "clamp muted small", style: { margin: 0 }, children: l.details }), _jsx("div", { style: { marginTop: '.8rem' }, children: _jsxs("div", { className: "price", children: [money(l.price), " ", _jsx("span", { className: "small muted", style: { fontWeight: 600 }, children: l.price_unit })] }) }), profile?.role === 'buyer' && (_jsxs("div", { className: "row", style: { marginTop: '.7rem' }, children: [_jsxs("button", { className: "btn ghost grow", disabled: busyId === l.id, onClick: () => start(l), children: [_jsx(Icon, { name: "chat", size: 17 }), busyId === l.id ? '...' : 'Baat karein'] }), _jsxs("button", { className: "btn primary grow", onClick: () => setBooking({ id: l.id, title: l.title, price: l.price, price_unit: l.price_unit, seller_name: l.seller?.full_name || 'Seller' }), children: [_jsx(Icon, { name: "check", size: 17 }), "Book karein"] })] }))] }, l.id))) })), booking && _jsx(BookModal, { target: booking, onClose: () => setBooking(null), onDone: (id) => nav(`/deal/${id}`) })] }));
}
