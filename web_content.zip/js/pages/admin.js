(function(){
  const sessao = Auth.exigirPerfil('administrador');
  if(!sessao) return;
  aplicarSessaoNoCabecalho();

  const rotuloDoc = { pendente:'Não enviado', enviado:'Enviado', em_analise:'Em análise', aprovado:'Aprovado', rejeitado:'Rejeitado' };
  const nomeDoc = { rg_cpf:'RG/CPF', comprovante_residencia:'Comprovante residência', certidao_antecedentes:'Antecedentes' };

  /** Estado (aba ativa + busca) de cada módulo, mantido em memória durante a sessão da página. */
  const estadoModulo = {
    anfitrioes: { sub:'todos', busca:'' },
    prestadores: { sub:'todos', busca:'' },
    acomodacoes: { sub:'todas', busca:'' },
  };

  function categoriaAnfitriao(u){
    if(u.excluido) return 'excluidos';
    if(u.status !== 'ativo') return 'desativados';
    return PropertiesService.listarDoAnfitriao(u.id).length > 0 ? 'ativos' : 'pendentes';
  }
  function categoriaPrestador(p){
    if(p.excluido) return 'excluidos';
    if(p.status === 'suspenso') return 'desativados';
    if(['PENDENTE','ENVIADO','EM_ANALISE','REJEITADO'].includes(p.status_aprovacao || 'PENDENTE')) return 'pendentes';
    return 'ativos';
  }
  function categoriaImovel(im){
    if(im.excluido) return 'excluidas';
    return im.status === 'ativo' ? 'ativas' : 'inativas';
  }

  function renderContadores(contId, contagens, mapaClasse){
    const cont = document.getElementById(contId);
    cont.innerHTML = Object.entries(contagens).map(([label,qtd]) =>
      `<span class="badge-status ${mapaClasse[label]||'verificado'}">${label}: ${qtd}</span>`
    ).join('');
  }

  function ligarAbas(tabsId, estadoKey, campo, rerender){
    document.querySelectorAll(`#${tabsId} .filter-chip`).forEach(chip => {
      chip.onclick = () => {
        document.querySelectorAll(`#${tabsId} .filter-chip`).forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        estadoModulo[estadoKey][campo] = chip.dataset.sub !== undefined ? chip.dataset.sub : chip.dataset.modulo;
        rerender();
      };
    });
  }

  /** ========================= MÓDULO 1 — ANFITRIÕES ========================= */
  function renderModuloAnfitrioes(){
    const todos = UsersService.listarAnfitrioes();
    const { sub, busca } = estadoModulo.anfitrioes;
    renderContadores('contadoresAnfitrioes', {
      Todos: todos.length,
      Pendentes: todos.filter(u=>categoriaAnfitriao(u)==='pendentes').length,
      Ativos: todos.filter(u=>categoriaAnfitriao(u)==='ativos').length,
      Desativados: todos.filter(u=>categoriaAnfitriao(u)==='desativados').length,
      Excluídos: todos.filter(u=>categoriaAnfitriao(u)==='excluidos').length,
    }, { Pendentes:'pendente', Ativos:'ativo', Desativados:'inativo', Excluídos:'inativo' });

    const termo = busca.trim().toLowerCase();
    const filtrados = todos.filter(u => {
      if(sub !== 'todos' && categoriaAnfitriao(u) !== sub) return false;
      if(termo && !(u.nome.toLowerCase().includes(termo) || u.email.toLowerCase().includes(termo))) return false;
      return true;
    });

    const cont = document.getElementById('listaAnfitrioes');
    if(filtrados.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Nenhum anfitrião encontrado.</p>';
      return;
    }
    cont.innerHTML = filtrados.map(u => {
      const cat = categoriaAnfitriao(u);
      const qtdImoveis = PropertiesService.listarDoAnfitriao(u.id).length;
      const rotulo = { pendentes:'Pendente', ativos:'Ativo', desativados:'Desativado', excluidos:'Excluído' };
      const classe = { pendentes:'pendente', ativos:'ativo', desativados:'inativo', excluidos:'inativo' };
      const acoes = cat === 'excluidos'
        ? `<button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:#E7F6EE;color:#0E8F52" data-id="${u.id}" data-acao="reativar-excluido">Reativar</button>`
        : `<button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:${cat==='desativados'?'#E7F6EE':'#FCE8E8'};color:${cat==='desativados'?'#0E8F52':'#C0392B'}" data-id="${u.id}" data-acao="${cat==='desativados'?'reativar':'desativar'}">${cat==='desativados'?'Reativar':'Desativar'}</button>
           <button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:#F3F4F6;color:#6B7280" data-id="${u.id}" data-acao="excluir">Excluir</button>`;
      return `
        <div class="list-row flex-wrap">
          <div class="avatar-circle">${iniciais(u.nome)}</div>
          <div class="flex-1 min-w-0">
            <p class="text-[12.5px] font-semibold truncate">${u.nome}</p>
            <p class="text-[10.5px] text-muted truncate">${u.email} · ${qtdImoveis} imóve${qtdImoveis===1?'l':'is'} · cadastro: ${formatarData(u.created_at)}</p>
          </div>
          <span class="badge-status ${classe[cat]}">${rotulo[cat]}</span>
          <div class="flex items-center gap-1 ml-2">${acoes}</div>
        </div>`;
    }).join('');

    cont.querySelectorAll('[data-acao]').forEach(btn => {
      btn.onclick = () => {
        const id = Number(btn.dataset.id);
        if(id === sessao.id){ mostrarToast('Você não pode alterar a própria conta.'); return; }
        const acao = btn.dataset.acao;
        try{
          if(acao === 'desativar') UsersService.desativar(id, sessao.id);
          else if(acao === 'reativar') UsersService.reativar(id, sessao.id);
          else if(acao === 'excluir'){
            if(!window.confirm('Excluir este anfitrião? O cadastro, imóveis e histórico serão preservados, mas o acesso será bloqueado até uma futura reativação.')) return;
            UsersService.excluir(id, sessao.id);
          } else if(acao === 'reativar-excluido') UsersService.reativarExcluido(id, sessao.id);
          mostrarToast('Atualizado!');
          renderModuloAnfitrioes();
        }catch(err){ mostrarToast(err.message); }
      };
    });
  }

  /** ========================= MÓDULO 2 — PRESTADORES DE SERVIÇO ========================= */
  function cardPrestadorPendente(p, u){
    const fotoHtml = p.selfie
      ? `<img src="${p.selfie}" style="width:48px;height:48px;border-radius:50%;object-fit:cover">`
      : `<div class="avatar-circle">${u ? iniciais(u.nome) : '?'}</div>`;
    const docsHtml = ProvidersService.TIPOS_DOCUMENTO.map(t => {
      const arquivo = p.documentos[t].arquivo;
      const ehPdf = arquivo && arquivo.startsWith('data:application/pdf');
      const linkVer = arquivo ? `
        <a href="${arquivo}" target="_blank" rel="noopener" class="flex items-center gap-1 text-[10.5px] font-semibold" style="color:var(--azul)">
          ${ehPdf ? '<i data-lucide="file-text" style="width:13px;height:13px"></i> Ver PDF' : '<i data-lucide="image" style="width:13px;height:13px"></i> Ver foto'}
        </a>` : '';
      return `
      <div class="flex items-center justify-between py-1 gap-2">
        <span class="text-[11px] text-muted flex-1 min-w-0">${nomeDoc[t]}: ${rotuloDoc[p.documentos[t].status]}</span>
        ${linkVer}
        ${p.documentos[t].status === 'enviado' ? `
          <span class="flex gap-1">
            <button class="text-[10.5px] font-semibold px-2 py-1 rounded" style="background:#E7F6EE;color:#0E8F52" data-doc-ok="${t}" data-id="${p.id}">Aprovar</button>
            <button class="text-[10.5px] font-semibold px-2 py-1 rounded" style="background:#FCE8E8;color:#C0392B" data-doc-no="${t}" data-id="${p.id}">Rejeitar</button>
          </span>` : ''}
      </div>`;
    }).join('');
    return `
      <div class="card-soft p-4">
        <div class="flex items-center gap-3 mb-2">
          ${fotoHtml}
          <div class="flex-1 min-w-0">
            <p class="font-semibold text-[13.5px] truncate">${u ? u.nome : 'Usuário #' + p.user_id}</p>
            <p class="text-[11px] text-muted truncate">${u ? u.email : ''} · cadastro: ${formatarData(p.created_at)}</p>
          </div>
          <span class="badge-status ${p.status_aprovacao === 'REJEITADO' ? 'inativo' : 'pendente'}">${p.status_aprovacao || 'PENDENTE'}</span>
        </div>
        <p class="text-[11.5px] text-muted mb-2">categorias: ${p.categorias.join(', ') || 'nenhuma ainda'}</p>
        <div class="mb-3 pt-2" style="border-top:1px solid var(--linha)">${docsHtml}</div>
        <div class="flex gap-2">
          <button class="flex-1 btn-primary py-2 rounded-lg text-[12.5px]" data-acao-prov="aprovar" data-id="${p.id}">Aprovar</button>
          <button class="flex-1 py-2 rounded-lg text-[12.5px] border" style="border-color:#F0C6C6;color:#C0392B" data-acao-prov="rejeitar" data-id="${p.id}">Rejeitar</button>
        </div>
      </div>`;
  }
  function linhaPrestadorGeral(p, u, cat){
    const rotulo = { ativos:'Ativo', desativados:'Desativado', excluidos:'Excluído' };
    const classe = { ativos:'ativo', desativados:'inativo', excluidos:'inativo' };
    const acoes = cat === 'excluidos'
      ? `<button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:#E7F6EE;color:#0E8F52" data-provider-id="${p.id}" data-acao-susp="reativar-excluido">Reativar</button>`
      : `<button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:${cat==='desativados'?'#E7F6EE':'#FCE8E8'};color:${cat==='desativados'?'#0E8F52':'#C0392B'}" data-provider-id="${p.id}" data-acao-susp="${cat==='desativados'?'reativar':'suspender'}">${cat==='desativados'?'Reativar':'Desativar'}</button>
         <button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:#F3F4F6;color:#6B7280" data-provider-id="${p.id}" data-acao-susp="excluir">Excluir</button>`;
    return `
      <div class="list-row flex-wrap">
        <div class="avatar-circle">${u ? iniciais(u.nome) : '?'}</div>
        <div class="flex-1 min-w-0">
          <p class="text-[12.5px] font-semibold truncate">${u ? u.nome : '#'+p.user_id}</p>
          <p class="text-[10.5px] text-muted truncate">${p.categorias.join(', ') || 'sem categoria'} · ${(p.reputacao||0).toFixed(1)}★</p>
        </div>
        <span class="badge-status ${classe[cat]}">${rotulo[cat]}</span>
        <div class="flex items-center gap-1 ml-2">${acoes}</div>
      </div>`;
  }

  function renderModuloPrestadores(){
    const todos = DB.list('providers');
    const { sub, busca } = estadoModulo.prestadores;
    renderContadores('contadoresPrestadores', {
      Todos: todos.length,
      Pendentes: todos.filter(p=>categoriaPrestador(p)==='pendentes').length,
      Ativos: todos.filter(p=>categoriaPrestador(p)==='ativos').length,
      Desativados: todos.filter(p=>categoriaPrestador(p)==='desativados').length,
      Excluídos: todos.filter(p=>categoriaPrestador(p)==='excluidos').length,
    }, { Pendentes:'pendente', Ativos:'ativo', Desativados:'inativo', Excluídos:'inativo' });

    const termo = busca.trim().toLowerCase();
    const filtrados = todos.filter(p => {
      if(sub !== 'todos' && categoriaPrestador(p) !== sub) return false;
      if(termo){
        const u = UsersService.obter(p.user_id);
        const alvo = ((u ? u.nome : '') + ' ' + (u ? u.email : '')).toLowerCase();
        if(!alvo.includes(termo)) return false;
      }
      return true;
    });

    const cont = document.getElementById('listaPrestadores');
    if(filtrados.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Nenhum prestador encontrado.</p>';
      return;
    }
    cont.innerHTML = filtrados.map(p => {
      const u = UsersService.obter(p.user_id);
      const cat = categoriaPrestador(p);
      return cat === 'pendentes' ? cardPrestadorPendente(p, u) : linhaPrestadorGeral(p, u, cat);
    }).join('');

    cont.querySelectorAll('[data-acao-prov]').forEach(btn => {
      btn.onclick = () => {
        const id = Number(btn.dataset.id);
        try{
          if(btn.dataset.acaoProv === 'aprovar'){
            ProvidersService.aprovar(id, sessao.id);
            mostrarToast('Profissional aprovado!');
          } else {
            const motivo = window.prompt('Motivo da rejeição (obrigatório):');
            if(!motivo || !motivo.trim()) return;
            ProvidersService.rejeitar(id, sessao.id, motivo.trim());
            mostrarToast('Cadastro rejeitado.');
          }
          renderModuloPrestadores();
        }catch(err){ mostrarToast(err.message); }
      };
    });
    cont.querySelectorAll('[data-doc-ok]').forEach(btn => {
      btn.onclick = () => { ProvidersService.analisarDocumento(sessao.id, Number(btn.dataset.id), btn.dataset.docOk, true); mostrarToast('Documento aprovado.'); renderModuloPrestadores(); };
    });
    cont.querySelectorAll('[data-doc-no]').forEach(btn => {
      btn.onclick = () => {
        const motivo = window.prompt('Motivo da rejeição do documento:');
        if(!motivo || !motivo.trim()) return;
        ProvidersService.analisarDocumento(sessao.id, Number(btn.dataset.id), btn.dataset.docNo, false, motivo.trim());
        mostrarToast('Documento rejeitado.');
        renderModuloPrestadores();
      };
    });
    cont.querySelectorAll('[data-acao-susp]').forEach(btn => {
      btn.onclick = () => {
        const id = Number(btn.dataset.providerId);
        const acao = btn.dataset.acaoSusp;
        try{
          if(acao === 'suspender') ProvidersService.suspender(id, sessao.id);
          else if(acao === 'reativar') ProvidersService.aprovar(id, sessao.id);
          else if(acao === 'excluir'){
            if(!window.confirm('Excluir este profissional? O cadastro, histórico e avaliações serão preservados, mas o acesso será bloqueado até uma futura reativação.')) return;
            ProvidersService.excluir(id, sessao.id);
          } else if(acao === 'reativar-excluido') ProvidersService.reativarExcluido(id, sessao.id);
          mostrarToast('Atualizado!');
          renderModuloPrestadores();
        }catch(err){ mostrarToast(err.message); }
      };
    });
    refreshIcons();
  }

  /** ========================= MÓDULO 3 — ACOMODAÇÕES ========================= */
  function renderModuloAcomodacoes(){
    const todas = PropertiesService.listarTodos();
    const { sub, busca } = estadoModulo.acomodacoes;
    renderContadores('contadoresAcomodacoes', {
      Todas: todas.length,
      Ativas: todas.filter(im=>categoriaImovel(im)==='ativas').length,
      Inativas: todas.filter(im=>categoriaImovel(im)==='inativas').length,
      'Excluídas/arquivadas': todas.filter(im=>categoriaImovel(im)==='excluidas').length,
    }, { Ativas:'ativo', Inativas:'inativo', 'Excluídas/arquivadas':'inativo' });

    const termo = busca.trim().toLowerCase();
    const filtrados = todas.filter(im => {
      const subKey = sub === 'todas' ? null : sub;
      if(subKey && categoriaImovel(im) !== subKey) return false;
      if(termo){
        const dono = DB.find('users', im.owner_id);
        const alvo = (im.nome + ' ' + im.cidade + ' ' + (dono?dono.nome:'')).toLowerCase();
        if(!alvo.includes(termo)) return false;
      }
      return true;
    });

    const cont = document.getElementById('listaAcomodacoes');
    if(filtrados.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Nenhuma acomodação encontrada.</p>';
      return;
    }
    cont.innerHTML = filtrados.map(im => {
      const dono = DB.find('users', im.owner_id);
      const cat = categoriaImovel(im);
      const rotulo = { ativas:'Ativa', inativas:'Inativa', excluidas:'Excluída' };
      const classe = { ativas:'ativo', inativas:'inativo', excluidas:'inativo' };
      const acoes = cat === 'excluidas'
        ? `<button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:#E7F6EE;color:#0E8F52" data-id="${im.id}" data-acao="reativar-excluido">Restaurar</button>`
        : `<button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:${cat==='inativas'?'#E7F6EE':'#FCE8E8'};color:${cat==='inativas'?'#0E8F52':'#C0392B'}" data-id="${im.id}" data-acao="${cat==='inativas'?'ativar':'inativar'}">${cat==='inativas'?'Ativar':'Inativar'}</button>
           <button class="text-[11px] font-semibold px-2 py-1.5 rounded" style="background:#F3F4F6;color:#6B7280" data-id="${im.id}" data-acao="excluir">Excluir</button>`;
      return `
        <div class="list-row flex-wrap">
          <div class="icon-circle" style="background:#EAF1FD;color:var(--azul)"><i data-lucide="home"></i></div>
          <div class="flex-1 min-w-0">
            <p class="text-[12.5px] font-semibold truncate">${im.nome || 'Sem nome'}</p>
            <p class="text-[10.5px] text-muted truncate">${im.cidade || '—'}/${im.estado || '—'} · anfitrião: ${dono ? dono.nome : '#'+im.owner_id}</p>
          </div>
          <span class="badge-status ${classe[cat]}">${rotulo[cat]}</span>
          <div class="flex items-center gap-1 ml-2">${acoes}</div>
        </div>`;
    }).join('');
    refreshIcons();

    cont.querySelectorAll('[data-acao]').forEach(btn => {
      btn.onclick = () => {
        const id = Number(btn.dataset.id);
        const acao = btn.dataset.acao;
        try{
          if(acao === 'ativar') PropertiesService.adminDefinirStatus(sessao.id, id, 'ativo');
          else if(acao === 'inativar') PropertiesService.adminDefinirStatus(sessao.id, id, 'inativo');
          else if(acao === 'excluir'){
            if(!window.confirm('Excluir/arquivar esta acomodação? O histórico de serviços, ambientes e inventário serão preservados.')) return;
            PropertiesService.excluir(sessao.id, id);
          } else if(acao === 'reativar-excluido') PropertiesService.reativarExcluido(sessao.id, id);
          mostrarToast('Atualizado!');
          renderModuloAcomodacoes();
        }catch(err){ mostrarToast(err.message); }
      };
    });
  }

  /** ========================= Navegação entre módulos + busca ========================= */
  function trocarModulo(nome){
    ['anfitrioes','prestadores','acomodacoes'].forEach(m => {
      document.getElementById('modulo' + m.charAt(0).toUpperCase() + m.slice(1)).classList.toggle('hidden', m !== nome);
    });
  }
  document.querySelectorAll('#adminModuleTabs .filter-chip').forEach(chip => {
    chip.onclick = () => {
      document.querySelectorAll('#adminModuleTabs .filter-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      trocarModulo(chip.dataset.modulo);
    };
  });
  ligarAbas('subtabsAnfitrioes', 'anfitrioes', 'sub', renderModuloAnfitrioes);
  ligarAbas('subtabsPrestadores', 'prestadores', 'sub', renderModuloPrestadores);
  ligarAbas('subtabsAcomodacoes', 'acomodacoes', 'sub', renderModuloAcomodacoes);
  document.getElementById('buscaAnfitrioes').addEventListener('input', e => { estadoModulo.anfitrioes.busca = e.target.value; renderModuloAnfitrioes(); });
  document.getElementById('buscaPrestadores').addEventListener('input', e => { estadoModulo.prestadores.busca = e.target.value; renderModuloPrestadores(); });
  document.getElementById('buscaAcomodacoes').addEventListener('input', e => { estadoModulo.acomodacoes.busca = e.target.value; renderModuloAcomodacoes(); });

  function renderAuditoria(){
    const logs = AuditLogService.listarRecentes(30);
    const cont = document.getElementById('listaAuditoria');
    if(logs.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Sem eventos registrados ainda.</p>';
      return;
    }
    cont.innerHTML = logs.map(l => `
      <div class="list-row">
        <div class="flex-1 min-w-0">
          <p class="text-[12px] font-semibold">${l.acao} <span class="text-muted font-normal">· ${l.entidade}#${l.entidade_id ?? ''}</span></p>
          <p class="text-[10.5px] text-muted">usuário #${l.user_id} · ${new Date(l.created_at).toLocaleString('pt-BR')}</p>
        </div>
      </div>
    `).join('');
  }

  function renderDivergencias(){
    const divergencias = DisputesService.listarAbertas();
    const cont = document.getElementById('listaDivergencias');
    if(divergencias.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Nenhuma divergência em aberto.</p>';
      return;
    }
    cont.innerHTML = divergencias.map(d => {
      const s = DB.find('service_requests', d.service_request_id);
      const anfitriao = s ? DB.find('users', s.owner_id) : null;
      const provider = DB.find('providers', s ? s.accepted_provider_id : null);
      const profUser = provider ? DB.find('users', provider.user_id) : null;
      const podeDecidir = d.status === 'respondida';
      return `
        <div class="card-soft p-4">
          <div class="flex items-center justify-between mb-2">
            <p class="font-semibold text-[13px]">${d.motivo}</p>
            <span class="badge-status ${d.status==='aberta'?'pendente':'verificado'}">${d.status === 'aberta' ? 'Aguardando anfitrião' : 'Pronta para decisão'}</span>
          </div>
          <p class="text-[11px] mb-1"><span class="badge-status ${['alta','critica'].includes(d.severidade)?'inativo':'pendente'}">Severidade: ${d.severidade||'—'}</span></p>
          ${BLOQUEIOS_CONFIG.severidadesBloqueiamRetomadaAutomatica.includes(d.severidade) ? '<p class="text-[11px] mb-1" style="color:#C0392B">⚠ Severidade bloqueia retomada automática do serviço.</p>' : ''}
          <p class="text-[11.5px] text-muted mb-1">Solicitação #${d.service_request_id} · ${s ? s.categoria : ''}</p>
          <p class="text-[11.5px] text-muted mb-1">Profissional: ${profUser ? profUser.nome : '—'} · Anfitrião: ${anfitriao ? anfitriao.nome : '—'}</p>
          <p class="text-[12px] text-muted mb-2">"${d.descricao}"</p>
          ${d.resposta_anfitriao ? `<p class="text-[12px] mb-2" style="color:var(--azul-escuro)">Resposta do anfitrião: "${d.resposta_anfitriao.texto}"</p>` : '<p class="text-[11.5px] text-muted mb-2 italic">Anfitrião ainda não respondeu.</p>'}
          ${podeDecidir ? `
            <div class="space-y-2 mt-2 pt-2 border-t" style="border-color:var(--linha)">
              <select class="field-input decisaoDe" data-id="${d.id}">
                <option value="anfitriao">Responsabilidade do anfitrião</option>
                <option value="profissional">Responsabilidade do profissional</option>
                <option value="parcial">Responsabilidade parcial</option>
              </select>
              <input type="text" class="field-input decisaoTexto" data-id="${d.id}" placeholder="Justificativa da decisão">
              <label class="checkbox-pill"><input type="checkbox" class="decisaoAplicarTaxa" data-id="${d.id}"> Aplicar taxa de deslocamento/disponibilidade</label>
              <input type="number" class="field-input decisaoValorTaxa" data-id="${d.id}" placeholder="Valor da taxa (R$)">
              <label class="checkbox-pill"><input type="checkbox" class="decisaoRetomar" data-id="${d.id}" checked> Retomar o serviço após decisão</label>
              <button class="btn-primary w-full py-2.5 rounded-lg text-[12.5px] btnDecidir" data-id="${d.id}">Registrar decisão</button>
            </div>` : ''}
        </div>`;
    }).join('');

    cont.querySelectorAll('.btnDecidir').forEach(btn => {
      btn.onclick = () => {
        const id = Number(btn.dataset.id);
        const decisaoDe = cont.querySelector(`.decisaoDe[data-id="${id}"]`).value;
        const texto = cont.querySelector(`.decisaoTexto[data-id="${id}"]`).value.trim() || 'Decisão registrada pela administração.';
        const aplicarTaxa = cont.querySelector(`.decisaoAplicarTaxa[data-id="${id}"]`).checked;
        const valorTaxa = Number(cont.querySelector(`.decisaoValorTaxa[data-id="${id}"]`).value) || 0;
        const retomarServico = cont.querySelector(`.decisaoRetomar[data-id="${id}"]`).checked;
        DisputesService.decidir(sessao.id, id, { decisaoDe, texto, aplicarTaxa, valorTaxa, retomarServico });
        mostrarToast('Decisão registrada!');
        renderDivergencias(); renderPagamentos(); renderSolicitacoes();
      };
    });
  }

  function renderReclassificacoesLimpeza(){
    const pendentes = ServiceRequestsService.listarReclassificacoesPendentes();
    const cont = document.getElementById('listaReclassificacoes');
    if(!cont) return;
    if(pendentes.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Nenhuma reclassificação de faxina pendente.</p>';
      return;
    }
    cont.innerHTML = pendentes.map(s => {
      const r = s.reclassificacao_pendente;
      const evidencia = r.evidencia_id ? DB.find('evidences', r.evidencia_id) : null;
      const provider = s.accepted_provider_id ? DB.find('providers', s.accepted_provider_id) : null;
      const profUser = provider ? DB.find('users', provider.user_id) : null;
      const dono = DB.find('users', s.owner_id);
      const fotos = (evidencia && evidencia.fotos) || [];
      const qtdVideos = (evidencia && evidencia.videos && evidencia.videos.length) || 0;
      return `
        <div class="card-soft p-4">
          <div class="flex items-center justify-between mb-2">
            <p class="font-semibold text-[13px]">Faxina: "${r.modalidade_atual}" → "${r.modalidade_proposta}"</p>
            <span class="badge-status pendente">Aguardando decisão</span>
          </div>
          <p class="text-[11.5px] text-muted mb-1">Solicitação #${s.id} · Profissional: ${profUser ? profUser.nome : '—'} · Anfitrião/Morador: ${dono ? dono.nome : '—'}</p>
          <p class="text-[12px] text-muted mb-2">"${r.motivo}"</p>
          ${fotos.length ? `<div class="grid grid-cols-4 gap-2 mb-2">${fotos.map(f=>`<img src="${f}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">`).join('')}</div>` : ''}
          ${qtdVideos ? `<p class="text-[11px] text-muted mb-2">+ ${qtdVideos} vídeo(s) anexado(s) como evidência.</p>` : ''}
          <div class="flex gap-2 mt-2 pt-2 border-t" style="border-color:var(--linha)">
            <button class="flex-1 py-2.5 rounded-lg text-[12.5px] font-semibold border btnRejeitarReclass" data-id="${s.id}" style="border-color:var(--linha);color:var(--tinta)">Manter modalidade original</button>
            <button class="flex-1 btn-primary py-2.5 rounded-lg text-[12.5px] btnAprovarReclass" data-id="${s.id}">Aprovar e cobrar diferença</button>
          </div>
        </div>`;
    }).join('');

    cont.querySelectorAll('.btnAprovarReclass').forEach(btn => {
      btn.onclick = () => {
        try{
          ServiceRequestsService.decidirReclassificacaoLimpeza(sessao.id, Number(btn.dataset.id), true);
          mostrarToast('Reclassificação aprovada — diferença cobrada automaticamente.');
          renderReclassificacoesLimpeza(); renderPagamentos(); renderSolicitacoes();
        }catch(err){ mostrarToast(err.message); }
      };
    });
    cont.querySelectorAll('.btnRejeitarReclass').forEach(btn => {
      btn.onclick = () => {
        try{
          ServiceRequestsService.decidirReclassificacaoLimpeza(sessao.id, Number(btn.dataset.id), false);
          mostrarToast('Modalidade original mantida.');
          renderReclassificacoesLimpeza();
        }catch(err){ mostrarToast(err.message); }
      };
    });
  }

  function renderPagamentos(){
    const pagamentos = DB.list('payments').sort((a,b)=> new Date(b.created_at)-new Date(a.created_at));
    const cont = document.getElementById('listaPagamentos');
    if(pagamentos.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Nenhum pagamento registrado ainda.</p>';
      return;
    }
    const rotulo = { PENDING:'Pendente', AUTHORIZED:'Autorizado', HELD:'Retido', RELEASE_PENDING:'Liberando', RELEASED:'Liberado', REFUNDED:'Reembolsado', PARTIALLY_REFUNDED:'Reemb. parcial', DISPUTED:'Em disputa' };
    cont.innerHTML = pagamentos.map(p => `
      <div class="list-row">
        <div class="flex-1 min-w-0">
          <p class="text-[12.5px] font-semibold">Solicitação #${p.service_request_id} · R$ ${p.valor_anfitriao.toFixed(2)}</p>
          <p class="text-[10.5px] text-muted">profissional: R$ ${(p.valor_profissional - (p.taxa_deslocamento_disponibilidade||0)).toFixed(2)} · comissão: R$ ${p.comissao_plataforma.toFixed(2)} ${p.taxa_deslocamento_disponibilidade ? '· taxa aplicada: R$ '+p.taxa_deslocamento_disponibilidade.toFixed(2) : ''}</p>
        </div>
        <span class="badge-status ${p.status==='RELEASED'?'ativo':(p.status==='DISPUTED'?'inativo':'pendente')}">${rotulo[p.status]||p.status}</span>
      </div>
    `).join('');
  }

  function renderSolicitacoes(){
    const todas = DB.list('service_requests').sort((a,b)=> new Date(b.created_at)-new Date(a.created_at));
    const cont = document.getElementById('listaSolicitacoesAdmin');
    if(todas.length === 0){
      cont.innerHTML = '<p class="text-[12.5px] text-muted text-center py-3">Nenhuma solicitação registrada ainda.</p>';
      return;
    }
    const rotulo = { DRAFT:['Rascunho','pendente'], PUBLISHED:['Publicada','ativo'], ACCEPTED:['Aceita','verificado'], IN_PROGRESS:['Em andamento','verificado'], COMPLETED:['Concluída','ativo'], CANCELLED:['Cancelada','inativo'] };
    cont.innerHTML = todas.map(s => {
      const dono = DB.find('users', s.owner_id);
      const imovel = DB.find('properties', s.property_id);
      const [txt,classe] = rotulo[s.status] || [s.status,'inativo'];
      return `
        <div class="list-row">
          <div class="flex-1 min-w-0">
            <p class="text-[12.5px] font-semibold truncate">${s.categoria} · ${imovel ? imovel.nome : '—'}</p>
            <p class="text-[10.5px] text-muted truncate">anfitrião: ${dono ? dono.nome : '#'+s.owner_id} · ${formatarData(s.data)}</p>
          </div>
          <span class="badge-status ${classe}">${txt}</span>
        </div>`;
    }).join('');
  }

  function ligarDevTools(){
    if(!DevToolsService.disponivelNesteAmbiente()) return; // nunca aparece em prod
    const bloco = document.getElementById('blocoDevTools');
    bloco.classList.remove('hidden');

    document.getElementById('btnLimparDadosTeste').addEventListener('click', () => {
      const passo1 = window.confirm(
        'ATENÇÃO: isto vai apagar DEFINITIVAMENTE todos os dados de teste ' +
        '(usuários, acomodações, solicitações/oportunidades, mensagens, avaliações, ' +
        'pagamentos simulados, documentos e execuções). A conta administrativa será preservada.\n\n' +
        'Esta ação NÃO PODE SER DESFEITA. Deseja continuar?'
      );
      if(!passo1) return;

      const passo2 = window.prompt(
        'Confirmação final: esta ação é irreversível e não pode ser desfeita.\n' +
        'Digite EXCLUIR (em maiúsculas) para apagar todos os dados de teste agora.'
      );
      if(passo2 !== 'EXCLUIR'){
        mostrarToast('Limpeza cancelada.');
        return;
      }

      DevToolsService.limparDadosDeTeste({ admin_id: sessao.id });
      window.alert('Dados de teste apagados com sucesso. Você será redirecionado para o login.');
      window.location.href = 'login.html';
    });
  }

  renderModuloAnfitrioes();
  renderModuloPrestadores();
  renderModuloAcomodacoes();
  renderDivergencias();
  renderReclassificacoesLimpeza();
  renderPagamentos();
  renderSolicitacoes();
  renderAuditoria();
  ligarDevTools();
  refreshIcons();
})();
