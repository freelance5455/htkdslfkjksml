/* Weather module: fetch (Open-Meteo, keyless), cache, and the UI cards/charts. Loaded after store.js. */
(function (EP) {
  const { t, fmt, store: S, config: CFG } = EP;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const inflight = {};

  const unitF = () => S.get().tempUnit === 'f';
  const conv = c => (unitF() ? c * 9 / 5 + 32 : c);
  const temp = c => (c === null || c === undefined ? '–' : fmt.num(Math.round(conv(c))) + '°');
  const hhmm = iso => (typeof iso === 'string' && iso.length >= 16 ? iso.slice(11, 16) : '–');
  const fresh = (w, minutes) => w && Date.now() - w.at < minutes * 60e3;

  async function load(place, force) {
    const st = S.get(); if (!st.online) return null;
    const cur = st.wx[place.id];
    if (!force && fresh(cur, 30)) return cur;
    if (inflight[place.id]) return inflight[place.id];
    inflight[place.id] = (async () => {
      try {
        const u = `${CFG.services.weather}?latitude=${place.lat}&longitude=${place.lon}&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day&hourly=temperature_2m,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max&forecast_days=16&timezone=auto`;
        const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 15000);
        const r = await fetch(u, { signal: ctl.signal }); clearTimeout(to);
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const j = await r.json(), c = j.current || {}, d = j.daily || {}, h = j.hourly || {};
        let i0 = (h.time || []).indexOf(String(c.time || '').slice(0, 13) + ':00'); if (i0 < 0) i0 = 0;
        const w = {
          at: Date.now(),
          cur: { t: c.temperature_2m, fl: c.apparent_temperature, h: c.relative_humidity_2m, code: c.weather_code, w: c.wind_speed_10m, day: c.is_day === 0 ? 0 : 1 },
          daily: (d.time || []).map((x, i) => ({ d: x, max: d.temperature_2m_max[i], min: d.temperature_2m_min[i], p: d.precipitation_probability_max ? d.precipitation_probability_max[i] : null, code: d.weather_code[i], sr: d.sunrise ? d.sunrise[i] : '', ss: d.sunset ? d.sunset[i] : '', uv: d.uv_index_max ? d.uv_index_max[i] : null })),
          hr: (h.time || []).slice(i0, i0 + 24).map((x, i) => ({ h: hhmm(x), t: h.temperature_2m[i0 + i], p: h.precipitation_probability ? h.precipitation_probability[i0 + i] : null }))
        };
        const norm = S.normalize({ wx: { [place.id]: w } }).wx[place.id];
        if (!norm) throw new Error('bad data');
        st.wx[place.id] = norm; S.save();
        return norm;
      } catch (e) { return st.wx[place.id] || null; }
      finally { delete inflight[place.id]; }
    })();
    return inflight[place.id];
  }

  // ---- UI pieces ----
  function card(place, w, opts) {
    opts = opts || {};
    const href = `#/place/${encodeURIComponent(place.id)}/wx`;
    if (!w) {
      return `<article class="wxcard wxg-cloud" id="wxc-${esc(place.id)}"><div class="wxtop"><div><h3>${esc(place.name)}</h3><small>${esc(place.cc ? fmt.country(place.cc) : '')}</small></div></div><p class="wxmsg" role="status">${esc(S.get().online ? t('wxLoading') : t('wxNeed'))}</p></article>`;
    }
    const c = w.cur, today = w.daily[0] || {};
    const grad = EP.wxGrad(c.code, c.day);
    const lbl = t(EP.wxLabelKey(c.code));
    return `<article class="wxcard ${grad}${opts.big ? ' big' : ''}" id="wxc-${esc(place.id)}">
      <div class="wxtop"><div><h3>${opts.link === false ? esc(place.name) : `<a href="${href}">${esc(place.name)}</a>`}</h3><small>${esc(place.cc ? fmt.country(place.cc) : '')} · <span data-clock="${esc(place.tz)}">${esc(fmt.time(place.tz))}</span></small></div>${EP.wxIcon(c.code, c.day, 'wxi lg')}</div>
      <div class="wxmain"><span class="wxtemp">${esc(temp(c.t))}</span><span class="wxdesc">${esc(lbl)}<small>${esc(t('wxFeels', { n: temp(c.fl) }))}</small></span></div>
      <div class="wxmeta"><span>▲ ${esc(temp(today.max))}</span><span>▼ ${esc(temp(today.min))}</span>${today.p !== null && today.p !== undefined ? `<span>☂ ${esc(fmt.num(today.p))}%</span>` : ''}<span>≋ ${esc(fmt.num(Math.round(c.w || 0)))} km/h</span></div></article>`;
  }

  function hourly(w) {
    const H = w.hr; if (!H.length) return '';
    const ts = H.map(x => x.t).filter(x => x !== null), lo = Math.min(...ts), hi = Math.max(...ts), span = Math.max(1, hi - lo);
    const W = 480, Hh = 130, pad = 22, step = (W - pad * 2) / Math.max(1, H.length - 1);
    const y = v => 20 + (1 - (v - lo) / span) * 60;
    const pts = H.map((x, i) => (x.t === null ? null : [pad + i * step, y(x.t)])).filter(Boolean);
    const bars = H.map((x, i) => x.p ? `<rect class="hb" x="${(pad + i * step - 4).toFixed(1)}" y="${(Hh - 22 - x.p * 0.3).toFixed(1)}" width="8" height="${(x.p * 0.3).toFixed(1)}" rx="2"/>` : '').join('');
    const lab = H.map((x, i) => (i % 6 === 0 ? `<text class="hl" x="${(pad + i * step).toFixed(1)}" y="${Hh - 6}" text-anchor="middle">${esc(x.h)}</text>` : '')).join('');
    const dots = H.map((x, i) => (i % 3 === 0 && x.t !== null ? `<circle class="hd" cx="${(pad + i * step).toFixed(1)}" cy="${y(x.t).toFixed(1)}" r="3"/><text class="ht" x="${(pad + i * step).toFixed(1)}" y="${(y(x.t) - 8).toFixed(1)}" text-anchor="middle">${esc(temp(x.t))}</text>` : '')).join('');
    return `<svg viewBox="0 0 ${W} ${Hh}" class="hchart" role="img" aria-label="${esc(t('wxHourly'))}">${bars}<polyline class="hline" fill="none" points="${pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ')}"/>${dots}${lab}</svg>`;
  }

  function range(day, lo, hi) {
    const span = Math.max(1, hi - lo), a = ((day.min - lo) / span) * 100, b = ((day.max - lo) / span) * 100;
    return `<svg viewBox="0 0 100 8" class="rbar" preserveAspectRatio="none" aria-hidden="true"><rect class="rt" x="0" y="2" width="100" height="4" rx="2"/><rect class="rf" x="${a.toFixed(1)}" y="1" width="${Math.max(4, b - a).toFixed(1)}" height="6" rx="3"/></svg>`;
  }
  function daily(w, n, placeId) {
    const rows = w.daily.slice(0, n), lo = Math.min(...w.daily.map(d => d.min)), hi = Math.max(...w.daily.map(d => d.max));
    const trips = S.get().trips.filter(x => x.status === 'active' && x.place && x.place.id === placeId);
    return `<ul class="wxdaily">${rows.map((d, i) => {
      const inTrip = trips.some(x => d.d >= x.startDate && d.d <= x.endDate);
      return `<li class="${inTrip ? 'intrip' : ''}"><span class="wxday">${esc(i === 0 ? t('wxToday') : fmt.weekday(d.d))}${inTrip ? ` <i class="chip ok">${esc(t('wxTrip'))}</i>` : ''}</span>${EP.wxIcon(d.code, true, 'wxi sm')}<span class="wxrain">${d.p ? '☂ ' + esc(fmt.num(d.p)) + '%' : ''}</span><span class="wxlo">${esc(temp(d.min))}</span>${range(d, lo, hi)}<span class="wxhi">${esc(temp(d.max))}</span></li>`;
    }).join('')}</ul>`;
  }
  function tiles(w) {
    const c = w.cur, d0 = w.daily[0] || {};
    const T = (ico, label, val) => `<div class="wxtile"><span aria-hidden="true">${ico}</span><small>${esc(label)}</small><strong>${esc(val)}</strong></div>`;
    return `<div class="wxtiles">${T('💧', t('wxHumidity'), c.h === null ? '–' : fmt.num(Math.round(c.h)) + '%')}${T('≋', t('wxWind'), fmt.num(Math.round(c.w || 0)) + ' km/h')}${T('☀', t('wxUv'), d0.uv === null || d0.uv === undefined ? '–' : fmt.num(Math.round(d0.uv)))}${T('☂', t('wxRain'), d0.p === null || d0.p === undefined ? '–' : fmt.num(d0.p) + '%')}${T('↑', t('wxSunrise'), hhmm(d0.sr))}${T('↓', t('wxSunset'), hhmm(d0.ss))}</div>`;
  }
  const badge = (place, day) => {
    const w = place && S.get().wx[place.id]; if (!w) return '';
    const d = w.daily.find(x => x.d === day); if (!d) return '';
    return `<span class="wxbadge" title="${esc(t(EP.wxLabelKey(d.code)))}">${EP.wxIcon(d.code, true, 'wxi xs')}${esc(temp(d.max))} / ${esc(temp(d.min))}</span>`;
  };
  EP.wx = { load, card, hourly, daily, tiles, badge, temp, fresh };
})(window.EP = window.EP || {});
