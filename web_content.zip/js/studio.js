/* يمكن هدف؟ — "روبو يشرح": the robot explains the match on a live tactics board */
(function () {
  const { ai, viz, api } = YH; const esc = viz.esc; const AR = ai.AR;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const pc = v => Math.round(v * 100);
  let cur = null; // active studio instance

  /* ---------- helpers ---------- */
  function photoFor(pp, ath) { const r = api.personFor(pp, ath); return r && r.img; }
  function arFor(pp, ath) { const r = api.personFor(pp, ath); return ((r && r.ar && /[\u0600-\u06FF]/.test(r.ar)) ? r.ar : (ath.displayName || ath.fullName || '')).replace(/_/g, ' '); }
  const shortN = n => { const p = (n || '').split(' '); return p.length > 1 ? p.slice(-1)[0] : n; };
  const TAG_FROM_LABEL = [[/تيكي|بناء/, 'possession'], [/مرتد/, 'counter'], [/كتلة/, 'lowblock'], [/طويلة/, 'direct'], [/أطراف/, 'wide'], [/ضغط/, 'press']];
  function coachProfile(pp, lm) {
    const c = pp && pp.coach; const prof = c && YH.COACHES[c.en];
    let tags = prof ? prof.tags.slice() : [], style = prof ? prof.style : '';
    if (!tags.length && lm) {
      const ts = ai.teamStats(lm.sum); const me = ts[lm.side], op = ts[lm.side === 'home' ? 'away' : 'home'];
      const lab = ai.styleLabel(me || {}, op || {});
      lab.forEach(l => { const m = TAG_FROM_LABEL.find(([re]) => re.test(l.t)); if (m && !tags.includes(m[1])) tags.push(m[1]); });
      style = lab.map(l => l.d).join('، ');
    }
    if (!tags.length) tags = ['balanced'];
    return { name: c ? c.ar : '', en: c ? c.en : '', img: c && c.img, tags, style: style || 'أسلوب متوازن بين الدفاع والهجوم.' };
  }

  /* expected XI as tokens on a horizontal board (x,y in %) — home on the right attacking left */
  function xi(rosterEntry, side, pp, color) {
    if (!rosterEntry || !(rosterEntry.roster || []).some(p => p.starter)) return [];
    const L = viz.lines(rosterEntry.roster, rosterEntry.formation);
    const n = L.length, out = [];
    L.forEach((row, li) => {
      const d = n > 1 ? li / (n - 1) : 0;
      row.forEach((it, k) => {
        const yy = (k + 1) / (row.length + 1) * 100;
        const x = side === 'home' ? 95 - d * 41 : 5 + d * 41;
        const y = side === 'home' ? 100 - yy : yy;
        const a = it.p.athlete || {};
        out.push({ key: side[0] + li + '_' + k, side, row: li, rows: n, x, y, x0: x, y0: y, en: a.displayName, ar: arFor(pp, a), img: photoFor(pp, a), num: it.p.jersey, pos: it.p.position && it.p.position.abbreviation, color, id: a.id });
      });
    });
    return out;
  }
  function tokenHTML(t) {
    return `<div class="tk ${t.side}" id="tk_${t.key}" style="left:${t.x}%;top:${t.y}%;--tc:${t.color}"><span class="tk-face">${t.img ? `<img src="${esc(t.img)}" alt="" loading="lazy" onerror="this.remove()">` : ''}<i>${esc(t.num || '')}</i></span><b class="tk-n">${esc(shortN(t.ar))}</b></div>`;
  }
  function boardHTML(tokens, { label } = {}) {
    return `<div class="tb"><svg class="tb-pitch" viewBox="0 0 105 68" preserveAspectRatio="none" aria-hidden="true">${viz.pitchLines(105, 68, false)}</svg>
      <svg class="tb-arrows" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"></svg>
      <div class="tb-layer">${tokens.map(tokenHTML).join('')}<div class="tb-ball" style="left:50%;top:50%"></div></div>${label ? `<span class="tb-label">${label}</span>` : ''}</div>`;
  }

  /* ---------- board choreography ---------- */
  function Board(root, tokens) {
    const el = t => root.querySelector('#tk_' + t.key);
    const fwd = t => t.side === 'home' ? -1 : 1;
    const set = (t, x, y) => { t.x = Math.max(3, Math.min(97, x)); t.y = Math.max(6, Math.min(94, y)); const e = el(t); if (e) { e.style.left = t.x + '%'; e.style.top = t.y + '%'; } };
    const ball = root.querySelector('.tb-ball');
    const ballTo = t => { if (!ball) return; ball.classList.add('on'); ball.style.left = t.x + '%'; ball.style.top = t.y + '%'; };
    const arrows = root.querySelector('.tb-arrows');
    const arrow = (x1, y1, x2, y2, c) => { if (!arrows) return; arrows.insertAdjacentHTML('beforeend', `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${c}" class="tb-arrow"/>`); };
    const clearArrows = () => { if (arrows) arrows.innerHTML = ''; };
    const team = s => tokens.filter(t => t.side === s);
    const rowOf = (s, r) => team(s).filter(t => t.row === r);
    const last = s => { const t = team(s); return t.length ? Math.max(...t.map(x => x.row)) : 0; };
    const out = s => team(s).filter(t => t.row > 0);
    const wides = s => out(s).filter(t => t.y < 30 || t.y > 70);
    const fws = s => rowOf(s, last(s));
    const reset = s => { clearArrows(); (s ? team(s) : tokens).forEach(t => set(t, t.x0, t.y0)); if (ball) ball.classList.remove('on'); };
    const shift = (list, dx, dy = 0, arrowsOn = true) => list.forEach(t => { const nx = t.x0 + fwd(t) * dx; if (arrowsOn) arrow(t.x0, t.y0, nx, t.y0 + dy, t.color); set(t, nx, t.y0 + dy); });
    const el1 = list => list[0] ? el(list[0]) : null;
    const moves = {
      press: s => { reset(s); shift(out(s), 14); return el1(fws(s)); },
      highline: s => { reset(s); shift(rowOf(s, 1), 13); return el1(rowOf(s, 1)); },
      wide: s => { reset(s); wides(s).forEach(t => { const ny = t.y0 < 50 ? 8 : 92; arrow(t.x0, t.y0, t.x0 + fwd(t) * 18, ny, t.color); set(t, t.x0 + fwd(t) * 18, ny); }); return el1(wides(s)); },
      back3: s => { reset(s); wides(s).forEach(t => { arrow(t.x0, t.y0, t.x0 + fwd(t) * 20, t.y0, t.color); set(t, t.x0 + fwd(t) * 20, t.y0 < 50 ? 8 : 92); }); return el1(rowOf(s, 1)); },
      lowblock: s => { reset(s); team(s).forEach(t => { if (t.row) set(t, t.x0 - fwd(t) * 10, 50 + (t.y0 - 50) * 0.7); }); return el1(rowOf(s, 1)); },
      counter: async s => { reset(s); team(s).forEach(t => { if (t.row) set(t, t.x0 - fwd(t) * 9, 50 + (t.y0 - 50) * 0.75); }); await sleep(1200); const d = rowOf(s, 2)[0] || rowOf(s, 1)[0]; if (d) ballTo(d); await sleep(700); fws(s).forEach(t => { arrow(t.x, t.y, t.x0 + fwd(t) * 30, t.y0, t.color); set(t, t.x0 + fwd(t) * 30, t.y0); }); const f = fws(s)[0]; if (f) { await sleep(500); ballTo(f); } },
      possession: async s => { reset(s); const chain = [rowOf(s, 0)[0], rowOf(s, 1)[1] || rowOf(s, 1)[0], rowOf(s, 2)[0], rowOf(s, Math.max(2, last(s) - 1))[1] || rowOf(s, last(s) - 1)[0], fws(s)[0]].filter(Boolean); for (const t of chain) { ballTo(t); await sleep(750); } },
      inverted: s => { reset(s); const fb = rowOf(s, 1).filter(t => t.y0 < 30 || t.y0 > 70); fb.forEach(t => { arrow(t.x0, t.y0, t.x0 + fwd(t) * 12, t.y0 < 50 ? 36 : 64, t.color); set(t, t.x0 + fwd(t) * 12, t.y0 < 50 ? 36 : 64); }); return el1(fb); },
      direct: async s => { reset(s); const cb = rowOf(s, 1)[Math.floor(rowOf(s, 1).length / 2)]; const f = fws(s)[0]; if (cb) ballTo(cb); await sleep(600); if (f) { arrow(cb ? cb.x : 50, cb ? cb.y : 50, f.x0 + fwd(f) * 10, f.y0, f.color); set(f, f.x0 + fwd(f) * 10, f.y0); await sleep(300); ballTo(f); } },
      attack: s => { reset(s); shift(out(s), 18); return el1(fws(s)); },
      setpiece: s => { reset(s); const box = s === 'home' ? 9 : 91; out(s).slice(-5).forEach((t, i) => set(t, box + (s === 'home' ? 3 : -3) * (i % 2), 38 + i * 6)); if (ball) { ball.classList.add('on'); ball.style.left = (s === 'home' ? 3 : 97) + '%'; ball.style.top = '7%'; } return el1(fws(s)); },
      balanced: s => { reset(s); shift(out(s), 5, 0, false); return el1(rowOf(s, 2)); },
    };
    return { reset, moves, team, fws, el, ballTo, set, rowOf, last, arrow, clearArrows, ball };
  }

  const TAG_LINE = {
    press: T => `${T} يضغط عالي على حامل الكرة. شوف شلون الفريق كله يتقدم لقدّام حتى يخنق الخصم بنصّه.`,
    highline: T => `خط دفاع ${T} متقدم كلش. المدافعين يطلعون لنص الملعب ويلعبون مصيدة التسلل.`,
    wide: T => `هجوم ${T} يبدأ من الأطراف. الأظهرة والأجنحة تنطلق وتفتح الملعب بالعرض.`,
    back3: T => `${T} يلعب بثلاثة مدافعين، والأجنحة الظهيرة تصعد حتى يصير الهجوم بخمسة لاعبين.`,
    lowblock: T => `${T} يدافع بكتلة منخفضة: اللاعبين قريبين من بعض ويسدّون العمق.`,
    counter: T => `${T} يرجع لورا ويترك الكرة، وأول ما يقطعها ينطلق بمرتدة سريعة، هيچ.`,
    possession: T => `${T} يحب الاستحواذ: تمريرات قصيرة من الحارس للدفاع للوسط لحد ما يلگى الفراغ.`,
    inverted: T => `الظهير عند ${T} يدخل لنص الملعب ويصير لاعب وسط إضافي.`,
    direct: T => `لعب مباشر: كرة طويلة من دفاع ${T} للمهاجم بدون تعقيد.`,
    attack: T => `${T} يهاجم بكل الخطوط، حتى المدافعين يتقدمون.`,
    setpiece: T => `انتبه للكرات الثابتة، ${T} خطير جداً بالركنيات والضربات الحرة.`,
    balanced: T => `${T} متوازن: يدافع بتنظيم ويهاجم بحذر.`,
  };

  /* ---------- scene builders ---------- */
  function buildScenes(ctx) {
    const { ev, sum, c, P, ppH, ppA, lmH, lmA, mode } = ctx;
    const H = AR(ev.home.name), Aw = AR(ev.away.name);
    const T = s => s === 'home' ? H : Aw;
    const pp = s => s === 'home' ? ppH : ppA;
    const coach = { home: coachProfile(ppH, lmH), away: coachProfile(ppA, lmA) };
    const rs = sum.rosters || [];
    const liveXI = s => { const r = rs.find(x => x.homeAway === s); return r && (r.roster || []).some(p => p.starter) ? r : null; };
    const xiEntry = s => liveXI(s) || (s === 'home' ? lmH : lmA) && (s === 'home' ? lmH : lmA).roster;
    const tokensFor = sides => sides.flatMap(s => xi(xiEntry(s), s, pp(s), c[s]));
    const fm = s => (xiEntry(s) || {}).formation || '';
    const scorer = s => { const l = (ev[s].leaders || []).find(x => /goals/i.test(x.name)); return l && l.leaders && l.leaders[0]; };
    const findTok = (toks, en) => toks.find(t => t.en === en) || toks.find(t => en && shortN(t.en) === shortN(en));
    const coachCard = s => `<div class="cc" style="--tc:${c[s]}" id="cc_${s}">${coach[s].img ? `<img src="${esc(coach[s].img)}" alt="${esc(coach[s].name)}" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'cc-fb',textContent:'م'}))">` : '<span class="cc-fb">م</span>'}<div><small>مدرب ${esc(T(s))}</small><b>${esc(coach[s].name || 'غير معروف')}</b><span class="cc-tags">${coach[s].tags.map(t => `<i>${esc(YH.COACH_TAG_AR[t] || t)}</i>`).join('')}</span></div></div>`;
    const crest = s => ev[s].logo ? `<img class="crest crest-xl" src="${esc(ev[s].logo)}" alt="" id="cr_${s}">` : `<span class="crest crest-xl crest-fb" id="cr_${s}">${esc(T(s)[0])}</span>`;
    const scenes = [];
    const q = sel => () => document.querySelector(sel);

    /* intro */
    const kick = new Date(ev.date).toLocaleTimeString('ar-IQ-u-nu-latn', { hour: '2-digit', minute: '2-digit', hour12: false });
    const intro = mode === 'pre' ? `هلا بيك! اليوم عدنا ${H} ضد ${Aw}، والمباراة تبدأ الساعة ${kick}.` : mode === 'in' ? `هسه المباراة شغالة: ${H} ${ev.home.score} و${Aw} ${ev.away.score}.` : `خلصت المباراة: ${H} ${ev.home.score} و${Aw} ${ev.away.score}. خلّي أشرحلك شنو صار.`;
    scenes.push({
      t: mode === 'post' ? 'قصة المباراة' : 'قبل الصافرة', html: `<div class="sc-intro"><div class="si-teams"><div>${crest('home')}<b>${esc(H)}</b></div><span class="si-vs">${mode === 'pre' ? 'ضد' : `<b class="sc2"><span>${ev.home.score}</span><i>-</i><span>${ev.away.score}</span></b>`}</span><div>${crest('away')}<b>${esc(Aw)}</b></div></div><div class="si-coaches">${coachCard('home')}${coachCard('away')}</div></div>`,
      lines: [
        { t: intro, at: q('#cr_home') },
        { t: coach.home.name ? `${H} يقوده المدرب ${coach.home.name}. ${coach.home.style}` : `${H}: ${coach.home.style}`, at: q('#cc_home') },
        { t: coach.away.name ? `و${Aw} يقوده ${coach.away.name}. ${coach.away.style}` : `${Aw}: ${coach.away.style}`, at: q('#cc_away') },
      ],
    });

    /* live state */
    if (mode === 'in' && P) {
      const min = ai.minuteOf ? parseInt(ev.clock) || 45 : 45;
      const lp = ai.livePredict(P.lh, P.la, min, ev.home.score, ev.away.score);
      const mom = ai.momentum(sum); const A = ai.analyze(sum);
      const lead = lp.home > lp.away ? 'home' : 'away';
      scenes.push({ t: 'هسه بالملعب', html: `<div class="sc-live"><p class="eyebrow">الاحتمالات المباشرة · الدقيقة ${esc(ev.clock || '')}</p>${viz.probBar(lp, c, [H, 'تعادل', Aw])}<div class="sc-mom" id="liveMom">${viz.momentumChart(mom, c, A.goals)}</div></div>`,
        lines: [
          { t: `حسب النتيجة والوقت الباقي، ${T(lead)} فرصته بالفوز ${pc(lp[lead])} بالمية، والتعادل ${pc(lp.draw)} بالمية.`, at: q('.sc-live .pbar') },
          { t: (A.story.find(s => s.k === 'control') || {}).text || 'المباراة متكافئة لحد الآن.', at: q('#liveMom') },
        ] });
    }

    /* how each team plays */
    ['home', 'away'].forEach(s => {
      const toks = tokensFor([s]);
      if (!toks.length) return;
      const ref = { b: null };
      const tags = coach[s].tags.filter(t => TAG_LINE[t]).slice(0, 2);
      const sc = scorer(s); const stT = sc && findTok(toks, sc.athlete.displayName);
      const lm = s === 'home' ? lmH : lmA;
      const lines = [{ t: `شلون يلعب ${T(s)}؟ ${liveXI(s) ? 'هذي التشكيلة الرسمية' : 'هذي التشكيلة المتوقعة حسب آخر مباراة'}${fm(s) ? `، بخطة ${fm(s).split('-').join(' ')}` : ''}.`, at: q('.tb'), act: () => ref.b && ref.b.reset(s) }];
      tags.forEach(tag => lines.push({ t: TAG_LINE[tag](T(s)), at: () => { const t = ref.b && (tag === 'possession' || tag === 'direct' ? document.querySelector('.tb-ball') : null); return t || (ref.b && ref.b.el(ref.b.fws(s)[0] || toks[0])); }, act: () => ref.b && ref.b.moves[tag](s) }));
      if (stT) lines.push({ t: `أخطر لاعب عند ${T(s)}: ${stT.ar}، سجّل ${sc.value} ${sc.value > 10 || sc.value < 3 ? 'أهداف' : 'أهداف'} هذا الموسم. راقبوه زين.`, at: () => ref.b && ref.b.el(stT), act: () => { ref.b.reset(s); ref.b.set(stT, stT.x0 + (s === 'home' ? -10 : 10), stT.y0); ref.b.ballTo(stT); } });
      if (lm && mode === 'pre') lines.push({ t: `بآخر مباراة، ${T(s)} ${lm.gf > lm.ga ? 'فاز' : lm.gf < lm.ga ? 'خسر' : 'تعادل'} ${Math.max(lm.gf, lm.ga)} ${lm.gf === lm.ga ? 'مقابل' : 'ل'} ${Math.min(lm.gf, lm.ga)} ${lm.home ? 'ضد' : 'عند'} ${AR(lm.opp)}.`, at: q('.tb'), act: () => ref.b && ref.b.reset(s) });
      scenes.push({ t: `شلون يلعب ${T(s)}`, html: boardHTML(toks, { label: `${esc(T(s))} ${fm(s) ? `<b dir="ltr">${esc(fm(s))}</b>` : ''}` }), mount: root => { ref.b = Board(root, toks); }, lines });
    });

    /* duel: both teams */
    const both = tokensFor(['home', 'away']);
    if (both.length > 12) {
      const ref = { b: null };
      const sH = scorer('home'), sA = scorer('away');
      const tH = sH && findTok(both.filter(t => t.side === 'home'), sH.athlete.displayName), tA = sA && findTok(both.filter(t => t.side === 'away'), sA.athlete.displayName);
      const lines = [{ t: `هسه نحط الفريقين وجهاً لوجه. ${H} يهاجم لليسار و${Aw} لليمين.`, at: q('.tb'), act: () => ref.b && ref.b.reset() }];
      if (tH) lines.push({ t: `من ${H}، الخطر الأول ${tH.ar}.`, at: () => ref.b && ref.b.el(tH), act: () => ref.b.set(tH, tH.x0 - 8, tH.y0) });
      if (tA) lines.push({ t: `ومن ${Aw}، الخطر الأول ${tA.ar}.`, at: () => ref.b && ref.b.el(tA), act: () => ref.b.set(tA, tA.x0 + 8, tA.y0) });
      const kh = coach.home.tags[0], ka = coach.away.tags[0];
      const clash = (kh === 'press' && (ka === 'possession' || ka === 'inverted')) ? `ضغط ${H} العالي راح يصطدم ببناء ${Aw} من الخلف، ومن يفوز بنص الملعب يفوز بالمباراة.`
        : (ka === 'press' && (kh === 'possession' || kh === 'inverted')) ? `${H} يحب البناء من الخلف، بس ${Aw} راح يضغط عالي. الأخطاء بنص الملعب ممكن تحسمها.`
        : (kh === 'highline' || ka === 'highline') ? `الدفاع المتقدم يعني مساحات ورا المدافعين. الكرات الطويلة والسرعة راح تكون سلاح خطير.`
        : (kh === 'counter' || ka === 'counter' || kh === 'lowblock' || ka === 'lowblock') ? `فريق يستحوذ وفريق ينتظر المرتدة. الصبر والتركيز راح يحسمون المواجهة.`
        : `مواجهة تكتيكية متقاربة، والتفاصيل الصغيرة مثل الكرات الثابتة ممكن تحسمها.`;
      lines.push({ t: clash, at: q('.tb'), act: () => { if (!ref.b) return; ref.b.reset(); ref.b.moves[kh] && ref.b.moves[kh]('home'); } });
      scenes.push({ t: 'المواجهة التكتيكية', html: boardHTML(both), mount: root => { ref.b = Board(root, both); }, lines });
    }

    /* post-match analysis */
    if (mode !== 'pre') {
      const A = ai.analyze(sum);
      if (A.sh.length || A.ts.home.totalShots) {
        const st = Object.fromEntries(A.story.map(s => [s.k, s]));
        scenes.push({ t: 'الأهداف المتوقعة xG', html: `<div class="sc-verdict"><div class="xg-duel"><div style="--tc:${c.home}" id="xgh"><small>${esc(H)}</small><b>${A.xg.home.toFixed(2)}</b><i>xG</i></div><span class="xg-vs">جودة الفرص</span><div style="--tc:${c.away}" id="xga"><small>${esc(Aw)}</small><b>${A.xg.away.toFixed(2)}</b><i>xG</i></div></div></div>`,
          lines: [{ t: st.verdict.text, at: q(A.xg.home >= A.xg.away ? '#xgh' : '#xga') }, { t: st.eff.text, at: q(A.xg.home >= A.xg.away ? '#xga' : '#xgh') }] });
        scenes.push({ t: 'من سيطر؟', html: `<div class="sc-mom" id="momBox">${viz.momentumChart(A.mom, c, A.goals)}</div>`, lines: [{ t: st.control.text, at: q('#momBox') }, { t: st.phases.text, at: q('#momBox .mm-goal') || q('#momBox') }] });
        scenes.push({ t: 'خريطة الفرص', html: `<div class="sc-shots">${viz.shotMap(A.sh, c)}</div>`, lines: [{ t: `كل دائرة تسديدة، وكلما كبرت الدائرة كانت الفرصة أخطر. ${H} سدد ${A.sh.filter(s => s.side === 'home').length} مرات و${Aw} ${A.sh.filter(s => s.side === 'away').length} مرات.`, at: () => document.querySelector('.sc-shots .is-goal') || document.querySelector('.sc-shots svg') }] });
        const star = A.rt[0];
        if (star) {
          const ppS = pp(star.side); const rec = api.personFor(ppS, { displayName: star.name }); const nm = rec && rec.ar ? rec.ar : star.name;
          scenes.push({ t: 'نجم المباراة', html: `<div class="sc-star"><div class="star-card" id="starC" style="--tc:${c[star.side]}">${rec && rec.img ? `<img src="${esc(rec.img)}" alt="" class="star-img">` : `<span class="num">${esc(star.jersey)}</span>`}<b>${esc(nm)}</b><small>${esc(T(star.side))}</small><em class="rt huge">${star.rating.toFixed(1)}</em></div></div>`,
            lines: [{ t: `نجم المباراة عندي: ${nm} من ${T(star.side)}، بتقييم ${star.rating.toFixed(1)}${star.st.totalGoals ? ` وسجّل ${star.st.totalGoals}` : ''}.`, at: q('#starC') }] });
        }
        const nmAr = (n, sd) => { if (!n) return n; const r = api.personFor(pp(sd), { displayName: n }); return r && r.ar && /[\u0600-\u06FF]/.test(r.ar) ? r.ar : n; };
        A.tps.forEach(t => { if (t.who) t.txt = t.txt.replace(t.who, nmAr(t.who, t.side)); });
        if (A.tps.length) scenes.push({ t: 'نقاط التحوّل', html: `<ol class="tp">${A.tps.slice(0, 6).map((t, i) => `<li id="tp${i}" style="--tc:${c[t.side] || 'var(--accent)'}" class="${t.red ? 'red' : ''}">${esc(t.txt)}</li>`).join('')}</ol>`,
          lines: A.tps.slice(0, 3).map((t, i) => ({ t: t.txt.replace(/'/, ' دقيقة').replace(/—/, '،'), at: q('#tp' + i) })) });
      }
    }

    /* prediction */
    if (P) {
      const pick = P.pick; const pickTxt = pick === 'draw' ? 'التعادل' : `فوز ${T(pick)}`;
      const best = P.sources.slice().sort((a, b) => b.w - a.w)[0];
      const actual = mode === 'post' ? (ev.home.score > ev.away.score ? 'home' : ev.away.score > ev.home.score ? 'away' : 'draw') : null;
      scenes.push({ t: mode === 'post' ? 'توقعي قبل المباراة' : 'توقعي للمباراة', html: `<div class="sc-pred"><div class="ph-score" id="phs"><span style="--tc:${c.home}">${P.score.h}</span><i>-</i><span style="--tc:${c.away}">${P.score.a}</span></div><p class="ph-pick">${esc(pickTxt)} · ثقة ${P.confidence}%</p><div id="pbr">${viz.probBar(P.fin, c, [H, 'تعادل', Aw])}</div><ul class="reasons" id="rsn">${P.reasons.slice(0, 3).map(r => `<li>${esc(r)}</li>`).join('')}</ul></div>`,
        lines: [
          { t: `جمعت الترتيب، الفورمة، الهدّافين، المراهنات وأسواق التوقعات. ${T('home')} ${pc(P.fin.home)} بالمية، التعادل ${pc(P.fin.draw)}، و${T('away')} ${pc(P.fin.away)} بالمية.`, at: q('#pbr') },
          ...(P.reasons[0] ? [{ t: 'ليش؟ ' + P.reasons[0], at: q('#rsn li') }] : []),
          { t: `توقعي: ${pickTxt}، والنتيجة ${P.score.h} ل ${P.score.a}${best ? `، وأقوى مؤشر عندي هو ${best.ar.split(' (')[0]}` : ''}.${actual ? (actual === pick ? ' والحمد لله التوقع طلع صح!' : ' بس الكرة ما بيها مضمون، والنتيجة خالفت التوقع.') : ' يمكن هدف؟ نشوف!'}`, at: q('#phs') },
        ] });
    }
    return { scenes, coach };
  }

  /* ---------- quick questions ---------- */
  function answers(ctx, coach) {
    const { ev, P } = ctx; const H = AR(ev.home.name), Aw = AR(ev.away.name); const T = s => s === 'home' ? H : Aw;
    const sc = s => { const l = (ev[s].leaders || []).find(x => /goals/i.test(x.name)); return l && l.leaders && l.leaders[0]; };
    const out = [];
    if (P) {
      out.push(['منو راح يفوز؟', P.pick === 'draw' ? `أتوقع تعادل، بس ${P.fin.home > P.fin.away ? H : Aw} أقرب شوية.` : `${T(P.pick)} أقرب للفوز بنسبة ${pc(P.fin[P.pick])} بالمية. ${P.reasons[0] || ''}`]);
      out.push(['شكد النتيجة؟', `أرجح نتيجة ${P.score.h} ل ${P.score.a}. وبعدها ${P.topScores.slice(1, 3).map(s => `${s.h} ل ${s.a}`).join(' أو ')}.`]);
      out.push(['راح تصير أهداف هواية؟', `احتمال أكثر من هدفين ونص ${pc(P.pOver)} بالمية، واحتمال الفريقين يسجلون ${pc(P.pBtts)} بالمية.`]);
    }
    const a = sc('home'), b = sc('away');
    if (a || b) out.push(['منو أخطر لاعب؟', [a && `${a.athlete.displayName} عند ${H} بـ${a.value} أهداف`, b && `${b.athlete.displayName} عند ${Aw} بـ${b.value} أهداف`].filter(Boolean).join('، و') + '.']);
    out.push(['أسلوب المدربين؟', `${coach.home.name || 'مدرب ' + H}: ${coach.home.style} أما ${coach.away.name || 'مدرب ' + Aw}: ${coach.away.style}`]);
    return out;
  }

  /* ---------- mount ---------- */
  function mount(host, ctx) {
    stop();
    const { scenes, coach } = buildScenes(ctx);
    const qa = answers(ctx, coach);
    host.innerHTML = `<div class="studio card">
      <div class="st-side"><div class="st-robot"></div><div class="bubble st-bubble" aria-live="polite"><span class="bt"></span></div></div>
      <div class="st-main"><div class="st-head"><span class="st-badge">روبو يشرح</span><h3 class="st-title"></h3><span class="st-step"></span></div>
        <div class="st-dots">${scenes.map((s, i) => `<button class="st-dot" data-i="${i}" aria-label="${esc(s.t)}"><i></i></button>`).join('')}</div>
        <div class="st-stage"></div>
        <div class="st-ctrl"><button class="btn btn-ghost" data-c="prev" aria-label="المشهد السابق">السابق</button><button class="btn" data-c="play">إيقاف مؤقت</button><button class="btn btn-ghost" data-c="next" aria-label="المشهد التالي">التالي</button><button class="btn btn-ghost st-voice" data-c="voice"></button></div></div>
      <svg class="st-beam" aria-hidden="true"><line/><circle class="ring" r="10"/><circle class="tip" r="4"/></svg></div>
      <div class="card ask"><div class="card-h"><h3>اسأل روبو</h3><span class="muted">جواب فوري بالصوت</span></div><div class="ask-chips">${qa.map((x, i) => `<button class="chip" data-q="${i}">${esc(x[0])}</button>`).join('')}</div></div>`;
    const root = host.querySelector('.studio');
    const R = YH.robot.create(root.querySelector('.st-robot'), { size: innerWidth < 700 ? 118 : 210 });
    R.attachBeam(root.querySelector('.st-beam'));
    const bubble = root.querySelector('.st-bubble'), stage = root.querySelector('.st-stage');
    const st = { si: 0, li: 0, tok: 0, paused: false };
    const voiceBtn = root.querySelector('[data-c=voice]');
    const drawVoice = () => { voiceBtn.textContent = YH.robot.voice.enabled ? 'الصوت: شغّال' : 'الصوت: مطفي'; voiceBtn.setAttribute('aria-pressed', YH.robot.voice.enabled); };
    drawVoice();
    function show(i) {
      st.si = (i + scenes.length) % scenes.length; st.li = 0;
      const s = scenes[st.si];
      root.querySelector('.st-title').textContent = s.t;
      root.querySelector('.st-step').textContent = `${st.si + 1}/${scenes.length}`;
      stage.classList.remove('in'); stage.innerHTML = s.html; void stage.offsetWidth; stage.classList.add('in');
      s.mount && s.mount(stage);
      root.querySelectorAll('.st-dot').forEach((d, k) => { d.classList.toggle('done', k < st.si); d.classList.toggle('cur', k === st.si); });
    }
    async function play() {
      const my = ++st.tok; st.paused = false; root.querySelector('[data-c=play]').textContent = 'إيقاف مؤقت';
      while (st.si < scenes.length) {
        const s = scenes[st.si];
        for (; st.li < s.lines.length; st.li++) {
          if (my !== st.tok) return;
          const L = s.lines[st.li];
          let tgt = null; try { tgt = L.at && L.at(); } catch (e) {}
          R.point(tgt || stage);
          await sleep(500); if (my !== st.tok) return;
          if (L.act) { try { const r = L.act(); if (r && r.then) r.catch(() => {}); } catch (e) {} }
          await sleep(250);
          try { const t2 = L.at && L.at(); if (t2 && t2 !== tgt) R.point(t2); } catch (e) {}
          const ok = await R.say(L.t, bubble); if (!ok || my !== st.tok) return;
        }
        if (st.si >= scenes.length - 1) break;
        await sleep(700); if (my !== st.tok) return;
        show(st.si + 1);
      }
      R.point(null); R.wave(true);
      R.say('خلصت الشرح! تگدر تسألني أي سؤال من تحت، أو ترجع المشاهد.', bubble);
      root.querySelector('[data-c=play]').textContent = 'أعد الشرح'; st.paused = true; st.done = true;
    }
    function pause() { st.tok++; R.stop(); st.paused = true; root.querySelector('[data-c=play]').textContent = 'كمّل الشرح'; }
    root.querySelector('.st-ctrl').onclick = e => {
      const b = e.target.closest('[data-c]'); if (!b) return; const k = b.dataset.c;
      if (k === 'voice') { YH.robot.voice.enabled = !YH.robot.voice.enabled; if (YH.robot.voice.enabled) YH.robot.voice.pick(); else YH.robot.voice.cancel(); drawVoice(); document.dispatchEvent(new CustomEvent('yh-voice')); return; }
      if (k === 'play') { if (st.done) { st.done = false; show(0); play(); } else if (st.paused) play(); else pause(); return; }
      st.tok++; R.stop(); st.done = false; show(st.si + (k === 'next' ? 1 : -1)); play();
    };
    root.querySelector('.st-dots').onclick = e => { const d = e.target.closest('[data-i]'); if (!d) return; st.tok++; R.stop(); st.done = false; show(+d.dataset.i); play(); };
    host.querySelector('.ask-chips').onclick = async e => {
      const b = e.target.closest('[data-q]'); if (!b) return;
      pause(); root.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      R.point(null); R.wave(true); setTimeout(() => R.wave(false), 1400);
      await R.say(qa[+b.dataset.q][1], bubble);
    };
    show(0);
    cur = { stop: () => { st.tok++; R.stop(); }, root };
    setTimeout(play, 350);
    return cur;
  }
  function stop() { if (cur) { cur.stop(); cur = null; } }

  YH.studio = { mount, stop, coachProfile, xi, buildScenes, answers, tokenHTML, arFor, photoFor, Board, boardHTML, TAG_LINE };
})();
