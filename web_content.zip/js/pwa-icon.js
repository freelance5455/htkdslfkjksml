"use strict";
(function(){try{
 var base=new URL('img/',location.href).href;
 if(location.protocol==='http:'||location.protocol==='https:'){
  if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(function(){})}
 var ic=document.createElement('link');ic.rel='icon';ic.type='image/png';ic.href=base+'icon-192.png';document.head.appendChild(ic)}catch(e){}})();
