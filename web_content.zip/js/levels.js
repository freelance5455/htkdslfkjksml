/**
 * Snake Escape — 60 Handcrafted Puzzle Levels & Daily Challenge Generator
 * Worlds:
 * 1. Jungle Basics (1-10)     - Navigation, turns, corridors
 * 2. Ancient Ruins (11-20)    - Multi-snake coordination, switches & gates
 * 3. Mystic Jungle (21-30)    - Keys, locked gates, portals & bridges
 * 4. Danger Zone (31-40)      - Movable blocks, spikes & hazards
 * 5. Snake Temple (41-50)     - Multi-snake master integration
 * 6. Master Escape (51-60)    - Glide / sliding puzzle mechanics
 */
(function() {
  'use strict';

  const LEVELS = [
    // =========================================================================
    // WORLD 1: JUNGLE BASICS (Levels 1–10)
    // 8x8 Grid, Single Snake, Stone Walls & Navigation
    // =========================================================================
    {
      id: 1,
      world: 1,
      name: "First Slither",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 7,
      parTime: 25,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 2, y: 5}, {x: 2, y: 6}, {x: 2, y: 7}], exit: {x: 6, y: 2} }
      ],
      walls: [{x: 4, y: 3}, {x: 4, y: 4}, {x: 4, y: 5}],
      collectibles: [{ id: "c1", type: "star", x: 2, y: 2, points: 100 }]
    },
    {
      id: 2,
      world: 1,
      name: "Mossy Turn",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 9,
      parTime: 30,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 6}, {x: 1, y: 7}, {x: 2, y: 7}], exit: {x: 6, y: 1} }
      ],
      walls: [{x: 3, y: 1}, {x: 3, y: 2}, {x: 3, y: 3}, {x: 3, y: 4}, {x: 3, y: 5}],
      collectibles: [{ id: "c1", type: "coin", x: 5, y: 5, points: 150 }]
    },
    {
      id: 3,
      world: 1,
      name: "Jungle Alley",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 10,
      parTime: 35,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 1, y: 3}], exit: {x: 6, y: 6} }
      ],
      walls: [
        {x: 2, y: 2}, {x: 3, y: 2}, {x: 4, y: 2}, {x: 5, y: 2},
        {x: 2, y: 5}, {x: 3, y: 5}, {x: 4, y: 5}, {x: 5, y: 5}
      ],
      collectibles: [{ id: "c1", type: "gem", x: 3, y: 3, points: 200 }]
    },
    {
      id: 4,
      world: 1,
      name: "Bramble Bend",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 12,
      parTime: 35,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 6, y: 6}, {x: 6, y: 5}, {x: 6, y: 4}], exit: {x: 1, y: 1} }
      ],
      walls: [
        {x: 5, y: 2}, {x: 4, y: 2}, {x: 3, y: 2}, {x: 2, y: 2},
        {x: 2, y: 3}, {x: 2, y: 4}, {x: 2, y: 5}
      ],
      collectibles: [{ id: "c1", type: "star", x: 6, y: 1, points: 100 }]
    },
    {
      id: 5,
      world: 1,
      name: "Ancient Pillars",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 10,
      parTime: 30,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 4}, {x: 1, y: 5}, {x: 1, y: 6}], exit: {x: 6, y: 4} }
      ],
      walls: [
        {x: 3, y: 1}, {x: 3, y: 2}, {x: 3, y: 3},
        {x: 5, y: 5}, {x: 5, y: 6}, {x: 5, y: 7}
      ],
      collectibles: [{ id: "c1", type: "gem", x: 4, y: 4, points: 200 }]
    },
    {
      id: 6,
      world: 1,
      name: "Emerald Corridor",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 11,
      parTime: 35,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 6}, {x: 2, y: 6}, {x: 3, y: 6}], exit: {x: 6, y: 1} }
      ],
      walls: [
        {x: 1, y: 4}, {x: 2, y: 4}, {x: 3, y: 4}, {x: 4, y: 4},
        {x: 5, y: 4}, {x: 5, y: 3}, {x: 5, y: 2}
      ],
      collectibles: [{ id: "c1", type: "star", x: 1, y: 1, points: 100 }]
    },
    {
      id: 7,
      world: 1,
      name: "S-Curve Trail",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 13,
      parTime: 40,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 6}, {x: 1, y: 5}, {x: 1, y: 4}], exit: {x: 6, y: 1} }
      ],
      walls: [
        {x: 2, y: 1}, {x: 2, y: 2}, {x: 2, y: 3},
        {x: 4, y: 4}, {x: 4, y: 5}, {x: 4, y: 6},
        {x: 6, y: 3}, {x: 6, y: 4}
      ],
      collectibles: [{ id: "c1", type: "coin", x: 3, y: 6, points: 150 }]
    },
    {
      id: 8,
      world: 1,
      name: "Canyon Weave",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 14,
      parTime: 40,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 6, y: 6} }
      ],
      walls: [
        {x: 3, y: 0}, {x: 3, y: 1}, {x: 3, y: 2}, {x: 3, y: 3},
        {x: 5, y: 4}, {x: 5, y: 5}, {x: 5, y: 6}, {x: 5, y: 7}
      ],
      collectibles: [{ id: "c1", type: "gem", x: 4, y: 2, points: 200 }]
    },
    {
      id: 9,
      world: 1,
      name: "Vine Maze",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 15,
      parTime: 45,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 6, y: 1}, {x: 6, y: 2}, {x: 6, y: 3}], exit: {x: 1, y: 6} }
      ],
      walls: [
        {x: 2, y: 2}, {x: 3, y: 2}, {x: 4, y: 2},
        {x: 2, y: 4}, {x: 3, y: 4}, {x: 4, y: 4}, {x: 5, y: 4},
        {x: 4, y: 5}, {x: 4, y: 6}
      ],
      collectibles: [{ id: "c1", type: "star", x: 1, y: 1, points: 100 }]
    },
    {
      id: 10,
      world: 1,
      name: "Jungle Sanctuary",
      difficulty: "easy",
      grid: { cols: 8, rows: 8 },
      movementMode: "step",
      parMoves: 16,
      parTime: 45,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 7}, {x: 1, y: 6}, {x: 2, y: 6}], exit: {x: 6, y: 1} }
      ],
      walls: [
        {x: 2, y: 1}, {x: 2, y: 2}, {x: 2, y: 3},
        {x: 5, y: 3}, {x: 5, y: 4}, {x: 5, y: 5},
        {x: 3, y: 5}, {x: 4, y: 5}
      ],
      collectibles: [
        { id: "c1", type: "star", x: 4, y: 2, points: 100 },
        { id: "c2", type: "gem", x: 6, y: 6, points: 200 }
      ]
    },

    // =========================================================================
    // WORLD 2: ANCIENT RUINS (Levels 11–20)
    // Multi-Snake Coordination, Pressure Switches & Toggled Gates
    // =========================================================================
    {
      id: 11,
      world: 2,
      name: "Twin Slither",
      difficulty: "normal",
      grid: { cols: 9, rows: 9 },
      movementMode: "step",
      parMoves: 14,
      parTime: 45,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 7, y: 2} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 6}, {x: 1, y: 7}, {x: 2, y: 7}], exit: {x: 7, y: 6} }
      ],
      walls: [
        {x: 4, y: 0}, {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 3},
        {x: 4, y: 5}, {x: 4, y: 6}, {x: 4, y: 7}, {x: 4, y: 8}
      ],
      collectibles: [{ id: "c1", type: "coin", x: 4, y: 4, points: 150 }]
    },
    {
      id: 12,
      world: 2,
      name: "Stone Switch",
      difficulty: "normal",
      grid: { cols: 9, rows: 9 },
      movementMode: "step",
      parMoves: 12,
      parTime: 40,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 4}, {x: 1, y: 5}, {x: 1, y: 6}], exit: {x: 7, y: 4} }
      ],
      walls: [
        {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 3},
        {x: 4, y: 5}, {x: 4, y: 6}, {x: 4, y: 7}
      ],
      gates: [
        { id: "gate-1", color: "gold", x: 4, y: 4, isOpen: false }
      ],
      switches: [
        { id: "sw-1", x: 2, y: 2, targetType: "gate", targetId: "gate-1", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 6, y: 2, points: 200 }]
    },
    {
      id: 13,
      world: 2,
      name: "Crossroads Order",
      difficulty: "normal",
      grid: { cols: 9, rows: 9 },
      movementMode: "step",
      parMoves: 16,
      parTime: 50,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 4, y: 2}, {x: 4, y: 1}, {x: 4, y: 0}], exit: {x: 4, y: 7} },
        { id: "snake-blue", color: "blue", segments: [{x: 2, y: 4}, {x: 1, y: 4}, {x: 0, y: 4}], exit: {x: 7, y: 4} }
      ],
      walls: [
        {x: 2, y: 2}, {x: 3, y: 2}, {x: 5, y: 2}, {x: 6, y: 2},
        {x: 2, y: 6}, {x: 3, y: 6}, {x: 5, y: 6}, {x: 6, y: 6}
      ],
      collectibles: [{ id: "c1", type: "star", x: 1, y: 1, points: 100 }]
    },
    {
      id: 14,
      world: 2,
      name: "Dual Gate Relay",
      difficulty: "normal",
      grid: { cols: 9, rows: 9 },
      movementMode: "step",
      parMoves: 18,
      parTime: 55,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 7, y: 2} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 6}, {x: 1, y: 7}, {x: 2, y: 7}], exit: {x: 7, y: 6} }
      ],
      walls: [
        {x: 4, y: 0}, {x: 4, y: 1}, {x: 4, y: 3}, {x: 4, y: 4}, {x: 4, y: 5}, {x: 4, y: 7}, {x: 4, y: 8}
      ],
      gates: [
        { id: "gate-green", color: "green", x: 4, y: 2, isOpen: false },
        { id: "gate-blue", color: "blue", x: 4, y: 6, isOpen: false }
      ],
      switches: [
        { id: "sw-1", x: 2, y: 6, targetType: "gate", targetId: "gate-green", pressed: false },
        { id: "sw-2", x: 2, y: 2, targetType: "gate", targetId: "gate-blue", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 6, y: 4, points: 200 }]
    },
    {
      id: 15,
      world: 2,
      name: "T-Junction Blockade",
      difficulty: "normal",
      grid: { cols: 9, rows: 9 },
      movementMode: "step",
      parMoves: 17,
      parTime: 50,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 4, y: 6}, {x: 4, y: 7}, {x: 4, y: 8}], exit: {x: 1, y: 1} },
        { id: "snake-blue", color: "blue", segments: [{x: 7, y: 4}, {x: 8, y: 4}, {x: 8, y: 5}], exit: {x: 7, y: 1} }
      ],
      walls: [
        {x: 2, y: 2}, {x: 3, y: 2}, {x: 5, y: 2}, {x: 6, y: 2},
        {x: 2, y: 4}, {x: 3, y: 4}, {x: 5, y: 4}, {x: 6, y: 4}
      ],
      collectibles: [{ id: "c1", type: "coin", x: 4, y: 1, points: 150 }]
    },
    {
      id: 16,
      world: 2,
      name: "Chamber of Buttons",
      difficulty: "normal",
      grid: { cols: 9, rows: 9 },
      movementMode: "step",
      parMoves: 19,
      parTime: 55,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 7}, {x: 1, y: 6}, {x: 2, y: 6}], exit: {x: 7, y: 1} }
      ],
      walls: [
        {x: 3, y: 1}, {x: 3, y: 2}, {x: 3, y: 4}, {x: 3, y: 5},
        {x: 6, y: 3}, {x: 6, y: 4}, {x: 6, y: 6}, {x: 6, y: 7}
      ],
      gates: [
        { id: "g1", color: "gold", x: 3, y: 3, isOpen: false },
        { id: "g2", color: "gold", x: 6, y: 5, isOpen: false }
      ],
      switches: [
        { id: "s1", x: 1, y: 1, targetType: "gate", targetId: "g1", pressed: false },
        { id: "s2", x: 4, y: 4, targetType: "gate", targetId: "g2", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 4, y: 7, points: 100 }]
    },
    {
      id: 17,
      world: 2,
      name: "Tri-Color Slither",
      difficulty: "normal",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 22,
      parTime: 65,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 8, y: 2} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 5}, {x: 1, y: 4}, {x: 2, y: 4}], exit: {x: 8, y: 5} },
        { id: "snake-orange", color: "orange", segments: [{x: 1, y: 8}, {x: 1, y: 7}, {x: 2, y: 7}], exit: {x: 8, y: 8} }
      ],
      walls: [
        {x: 4, y: 0}, {x: 4, y: 1}, {x: 4, y: 3}, {x: 4, y: 4}, {x: 4, y: 6}, {x: 4, y: 7}, {x: 4, y: 9}
      ],
      collectibles: [{ id: "c1", type: "gem", x: 6, y: 1, points: 200 }]
    },
    {
      id: 18,
      world: 2,
      name: "The Pass-Through",
      difficulty: "normal",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 20,
      parTime: 60,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 2, y: 4}, {x: 1, y: 4}, {x: 0, y: 4}], exit: {x: 9, y: 4} },
        { id: "snake-blue", color: "blue", segments: [{x: 4, y: 7}, {x: 4, y: 8}, {x: 4, y: 9}], exit: {x: 4, y: 0} }
      ],
      walls: [
        {x: 3, y: 2}, {x: 3, y: 3}, {x: 5, y: 2}, {x: 5, y: 3},
        {x: 3, y: 5}, {x: 3, y: 6}, {x: 5, y: 5}, {x: 5, y: 6}
      ],
      collectibles: [{ id: "c1", type: "star", x: 7, y: 2, points: 100 }]
    },
    {
      id: 19,
      world: 2,
      name: "Sequential Gates",
      difficulty: "normal",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 21,
      parTime: 65,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 8, y: 8} },
        { id: "snake-blue", color: "blue", segments: [{x: 8, y: 2}, {x: 8, y: 1}, {x: 7, y: 1}], exit: {x: 1, y: 8} }
      ],
      walls: [
        {x: 4, y: 2}, {x: 5, y: 2}, {x: 4, y: 6}, {x: 5, y: 6}
      ],
      gates: [
        { id: "gate-g", color: "green", x: 4, y: 4, isOpen: false },
        { id: "gate-b", color: "blue", x: 5, y: 4, isOpen: false }
      ],
      switches: [
        { id: "sw-1", x: 1, y: 5, targetType: "gate", targetId: "gate-g", pressed: false },
        { id: "sw-2", x: 8, y: 5, targetType: "gate", targetId: "gate-b", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "coin", x: 4, y: 8, points: 150 }]
    },
    {
      id: 20,
      world: 2,
      name: "Ruins Citadel",
      difficulty: "normal",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 24,
      parTime: 70,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 8}, {x: 1, y: 7}, {x: 2, y: 7}], exit: {x: 8, y: 1} },
        { id: "snake-blue", color: "blue", segments: [{x: 8, y: 8}, {x: 8, y: 7}, {x: 7, y: 7}], exit: {x: 1, y: 1} }
      ],
      walls: [
        {x: 4, y: 1}, {x: 5, y: 1}, {x: 4, y: 8}, {x: 5, y: 8},
        {x: 3, y: 4}, {x: 3, y: 5}, {x: 6, y: 4}, {x: 6, y: 5}
      ],
      gates: [
        { id: "gate-center", color: "gold", x: 4, y: 5, isOpen: false }
      ],
      switches: [
        { id: "sw-citadel", x: 5, y: 4, targetType: "gate", targetId: "gate-center", pressed: false }
      ],
      collectibles: [
        { id: "c1", type: "gem", x: 4, y: 2, points: 200 },
        { id: "c2", type: "star", x: 5, y: 7, points: 100 }
      ]
    },

    // =========================================================================
    // WORLD 3: MYSTIC JUNGLE (Levels 21–30)
    // Keys, Locked Gates, Teleport Portals & Bridges
    // =========================================================================
    {
      id: 21,
      world: 3,
      name: "The Golden Key",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 16,
      parTime: 50,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 8, y: 5} }
      ],
      walls: [
        {x: 5, y: 1}, {x: 5, y: 2}, {x: 5, y: 3}, {x: 5, y: 4},
        {x: 5, y: 6}, {x: 5, y: 7}, {x: 5, y: 8}
      ],
      keys: [
        { id: "k-gold", color: "gold", x: 1, y: 1, collected: false }
      ],
      gates: [
        { id: "g-gold", color: "gold", requiresKey: "gold", x: 5, y: 5, isOpen: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 7, y: 2, points: 200 }]
    },
    {
      id: 22,
      world: 3,
      name: "Twin Portal Vortex",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 14,
      parTime: 45,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 8, y: 8} }
      ],
      walls: [
        {x: 4, y: 0}, {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 3}, {x: 4, y: 4},
        {x: 4, y: 5}, {x: 4, y: 6}, {x: 4, y: 7}, {x: 4, y: 8}, {x: 4, y: 9}
      ],
      portals: [
        { id: "p1", pairId: "portal-green", color: "green", x: 2, y: 7 },
        { id: "p2", pairId: "portal-green", color: "green", x: 7, y: 2 }
      ],
      collectibles: [{ id: "c1", type: "star", x: 8, y: 1, points: 100 }]
    },
    {
      id: 23,
      world: 3,
      name: "Abyss Crossing",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 18,
      parTime: 55,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 4}, {x: 1, y: 5}, {x: 1, y: 6}], exit: {x: 8, y: 4} }
      ],
      walls: [
        {x: 5, y: 0}, {x: 5, y: 1}, {x: 5, y: 2}, {x: 5, y: 3},
        {x: 5, y: 5}, {x: 5, y: 6}, {x: 5, y: 7}, {x: 5, y: 8}, {x: 5, y: 9}
      ],
      bridges: [
        { id: "br-1", x: 5, y: 4, active: false }
      ],
      switches: [
        { id: "sw-br", x: 2, y: 2, targetType: "bridge", targetId: "br-1", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "coin", x: 7, y: 2, points: 150 }]
    },
    {
      id: 24,
      world: 3,
      name: "Key & Portal Sync",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 20,
      parTime: 60,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 1, y: 3}], exit: {x: 8, y: 8} }
      ],
      walls: [
        {x: 5, y: 0}, {x: 5, y: 1}, {x: 5, y: 2}, {x: 5, y: 3}, {x: 5, y: 4},
        {x: 5, y: 6}, {x: 5, y: 7}, {x: 5, y: 8}, {x: 5, y: 9}
      ],
      gates: [
        { id: "g-blue", color: "blue", requiresKey: "blue", x: 5, y: 5, isOpen: false }
      ],
      portals: [
        { id: "pa", pairId: "portal-blue", color: "blue", x: 2, y: 7 },
        { id: "pb", pairId: "portal-blue", color: "blue", x: 7, y: 2 }
      ],
      keys: [
        { id: "k-blue", color: "blue", x: 8, y: 1, collected: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 2, y: 5, points: 200 }]
    },
    {
      id: 25,
      world: 3,
      name: "Dual Keys, Dual Gates",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 24,
      parTime: 70,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 9, y: 9} },
        { id: "snake-blue", color: "blue", segments: [{x: 9, y: 2}, {x: 9, y: 1}, {x: 8, y: 1}], exit: {x: 1, y: 9} }
      ],
      walls: [
        {x: 5, y: 0}, {x: 5, y: 1}, {x: 5, y: 3}, {x: 5, y: 4}, {x: 5, y: 6}, {x: 5, y: 7}, {x: 5, y: 9}, {x: 5, y: 10}
      ],
      gates: [
        { id: "g1", color: "green", requiresKey: "green", x: 5, y: 2, isOpen: false },
        { id: "g2", color: "blue", requiresKey: "blue", x: 5, y: 8, isOpen: false }
      ],
      keys: [
        { id: "k1", color: "green", x: 8, y: 5, collected: false },
        { id: "k2", color: "blue", x: 2, y: 5, collected: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 5, y: 5, points: 100 }]
    },
    {
      id: 26,
      world: 3,
      name: "Warp Labyrinth",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 22,
      parTime: 65,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 1, y: 3}], exit: {x: 9, y: 5} }
      ],
      walls: [
        {x: 3, y: 0}, {x: 3, y: 1}, {x: 3, y: 2}, {x: 3, y: 3}, {x: 3, y: 4},
        {x: 7, y: 6}, {x: 7, y: 7}, {x: 7, y: 8}, {x: 7, y: 9}, {x: 7, y: 10}
      ],
      portals: [
        { id: "p-g1", pairId: "pair-green", color: "green", x: 2, y: 8 },
        { id: "p-g2", pairId: "pair-green", color: "green", x: 5, y: 2 },
        { id: "p-p1", pairId: "pair-purple", color: "purple", x: 5, y: 8 },
        { id: "p-p2", pairId: "pair-purple", color: "purple", x: 8, y: 2 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 5, y: 5, points: 200 }]
    },
    {
      id: 27,
      world: 3,
      name: "Chasm Bridge Relay",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 26,
      parTime: 75,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 9, y: 5} },
        { id: "snake-blue", color: "blue", segments: [{x: 9, y: 1}, {x: 9, y: 2}, {x: 8, y: 2}], exit: {x: 1, y: 9} }
      ],
      walls: [
        {x: 5, y: 0}, {x: 5, y: 1}, {x: 5, y: 2}, {x: 5, y: 3},
        {x: 5, y: 7}, {x: 5, y: 8}, {x: 5, y: 9}, {x: 5, y: 10}
      ],
      bridges: [
        { id: "br-a", x: 5, y: 5, active: false }
      ],
      switches: [
        { id: "sw-chasm", x: 7, y: 3, targetType: "bridge", targetId: "br-a", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 2, y: 2, points: 100 }]
    },
    {
      id: 28,
      world: 3,
      name: "Triple Portal Nexus",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 25,
      parTime: 75,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 2, y: 1}, {x: 3, y: 1}], exit: {x: 9, y: 9} }
      ],
      walls: [
        {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 3}, {x: 4, y: 4},
        {x: 6, y: 6}, {x: 6, y: 7}, {x: 6, y: 8}, {x: 6, y: 9}
      ],
      portals: [
        { id: "pa1", pairId: "portal-1", color: "green", x: 2, y: 4 },
        { id: "pa2", pairId: "portal-1", color: "green", x: 8, y: 2 },
        { id: "pb1", pairId: "portal-2", color: "blue", x: 8, y: 6 },
        { id: "pb2", pairId: "portal-2", color: "blue", x: 2, y: 8 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 5, y: 5, points: 200 }]
    },
    {
      id: 29,
      world: 3,
      name: "The Mystic Sanctum",
      difficulty: "hard",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 28,
      parTime: 85,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 10}, {x: 1, y: 9}, {x: 2, y: 9}], exit: {x: 10, y: 1} },
        { id: "snake-blue", color: "blue", segments: [{x: 10, y: 10}, {x: 10, y: 9}, {x: 9, y: 9}], exit: {x: 1, y: 1} }
      ],
      walls: [
        {x: 6, y: 1}, {x: 6, y: 2}, {x: 6, y: 4}, {x: 6, y: 5}, {x: 6, y: 7}, {x: 6, y: 8}, {x: 6, y: 10}
      ],
      gates: [
        { id: "sanctum-gate", color: "gold", requiresKey: "gold", x: 6, y: 6, isOpen: false }
      ],
      keys: [
        { id: "k-sanctum", color: "gold", x: 3, y: 3, collected: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 8, y: 8, points: 100 }]
    },
    {
      id: 30,
      world: 3,
      name: "Mystic Temple Apex",
      difficulty: "hard",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 30,
      parTime: 90,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 10, y: 10} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 9}, {x: 1, y: 10}, {x: 2, y: 10}], exit: {x: 10, y: 2} }
      ],
      walls: [
        {x: 5, y: 2}, {x: 5, y: 3}, {x: 5, y: 4}, {x: 5, y: 7}, {x: 5, y: 8}, {x: 5, y: 9}
      ],
      portals: [
        { id: "p1", pairId: "portal-m1", color: "purple", x: 3, y: 5 },
        { id: "p2", pairId: "portal-m1", color: "purple", x: 8, y: 8 }
      ],
      gates: [
        { id: "g-apex", color: "green", requiresKey: "green", x: 5, y: 5, isOpen: false }
      ],
      keys: [
        { id: "k-apex", color: "green", x: 9, y: 5, collected: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 7, y: 2, points: 200 }]
    },

    // =========================================================================
    // WORLD 4: DANGER ZONE (Levels 31–40)
    // Movable Blocks (Sokoban), Spike Traps & Timed Hazards
    // =========================================================================
    {
      id: 31,
      world: 4,
      name: "The Pushing Stone",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 15,
      parTime: 45,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 8, y: 5} }
      ],
      walls: [
        {x: 4, y: 3}, {x: 4, y: 4}, {x: 4, y: 6}, {x: 4, y: 7}
      ],
      blocks: [
        { id: "block-1", x: 4, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "coin", x: 6, y: 2, points: 150 }]
    },
    {
      id: 32,
      world: 4,
      name: "Spike Corridor",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 14,
      parTime: 40,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 8, y: 8} }
      ],
      walls: [
        {x: 3, y: 3}, {x: 4, y: 3}, {x: 5, y: 3}, {x: 6, y: 3}
      ],
      traps: [
        { id: "trap-1", type: "spikes", state: "active", x: 4, y: 5 },
        { id: "trap-2", type: "spikes", state: "active", x: 5, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "star", x: 7, y: 2, points: 100 }]
    },
    {
      id: 33,
      world: 4,
      name: "Boulder Alley",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 18,
      parTime: 55,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 2, y: 7}, {x: 1, y: 7}, {x: 1, y: 8}], exit: {x: 8, y: 2} }
      ],
      walls: [
        {x: 4, y: 4}, {x: 5, y: 4}, {x: 6, y: 4},
        {x: 4, y: 6}, {x: 5, y: 6}, {x: 6, y: 6}
      ],
      blocks: [
        { id: "b1", x: 4, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 7, y: 5, points: 200 }]
    },
    {
      id: 34,
      world: 4,
      name: "Trap Disarm Switch",
      difficulty: "hard",
      grid: { cols: 10, rows: 10 },
      movementMode: "step",
      parMoves: 19,
      parTime: 55,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 8, y: 5} }
      ],
      walls: [
        {x: 5, y: 2}, {x: 5, y: 3}, {x: 5, y: 4}, {x: 5, y: 6}, {x: 5, y: 7}, {x: 5, y: 8}
      ],
      traps: [
        { id: "deadly-spikes", type: "spikes", state: "active", x: 5, y: 5 }
      ],
      switches: [
        { id: "sw-disarm", x: 2, y: 2, targetType: "trap", targetId: "deadly-spikes", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 8, y: 2, points: 100 }]
    },
    {
      id: 35,
      world: 4,
      name: "Double Block Squeeze",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 22,
      parTime: 65,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 9, y: 5} }
      ],
      walls: [
        {x: 4, y: 3}, {x: 4, y: 4}, {x: 4, y: 6}, {x: 4, y: 7},
        {x: 7, y: 3}, {x: 7, y: 4}, {x: 7, y: 6}, {x: 7, y: 7}
      ],
      blocks: [
        { id: "blk-1", x: 4, y: 5 },
        { id: "blk-2", x: 7, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 5, y: 2, points: 200 }]
    },
    {
      id: 36,
      world: 4,
      name: "Poison Garden",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 24,
      parTime: 70,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 1, y: 3}], exit: {x: 9, y: 9} }
      ],
      walls: [
        {x: 3, y: 3}, {x: 4, y: 3}, {x: 6, y: 7}, {x: 7, y: 7}
      ],
      traps: [
        { id: "t1", type: "poison", state: "active", x: 3, y: 5 },
        { id: "t2", type: "poison", state: "active", x: 5, y: 5 },
        { id: "t3", type: "poison", state: "active", x: 7, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "coin", x: 9, y: 1, points: 150 }]
    },
    {
      id: 37,
      world: 4,
      name: "Dual Pushers",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 26,
      parTime: 75,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 3}, {x: 1, y: 2}, {x: 2, y: 2}], exit: {x: 9, y: 3} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 7}, {x: 1, y: 8}, {x: 2, y: 8}], exit: {x: 9, y: 7} }
      ],
      walls: [
        {x: 5, y: 1}, {x: 5, y: 2}, {x: 5, y: 4}, {x: 5, y: 5}, {x: 5, y: 6}, {x: 5, y: 8}, {x: 5, y: 9}
      ],
      blocks: [
        { id: "b-green", x: 5, y: 3 },
        { id: "b-blue", x: 5, y: 7 }
      ],
      collectibles: [{ id: "c1", type: "star", x: 7, y: 5, points: 100 }]
    },
    {
      id: 38,
      world: 4,
      name: "Spike Grid Gauntlet",
      difficulty: "hard",
      grid: { cols: 11, rows: 11 },
      movementMode: "step",
      parMoves: 25,
      parTime: 75,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 9}, {x: 1, y: 8}, {x: 2, y: 8}], exit: {x: 9, y: 1} }
      ],
      walls: [
        {x: 3, y: 2}, {x: 7, y: 8}
      ],
      traps: [
        { id: "spk1", type: "spikes", state: "active", x: 3, y: 5 },
        { id: "spk2", type: "spikes", state: "active", x: 5, y: 3 },
        { id: "spk3", type: "spikes", state: "active", x: 5, y: 7 },
        { id: "spk4", type: "spikes", state: "active", x: 7, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 5, y: 5, points: 200 }]
    },
    {
      id: 39,
      world: 4,
      name: "The Block & Trap Lock",
      difficulty: "hard",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 28,
      parTime: 85,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 6}, {x: 1, y: 7}, {x: 2, y: 7}], exit: {x: 10, y: 6} }
      ],
      walls: [
        {x: 5, y: 3}, {x: 5, y: 4}, {x: 5, y: 5}, {x: 5, y: 7}, {x: 5, y: 8}
      ],
      blocks: [
        { id: "lock-block", x: 5, y: 6 }
      ],
      traps: [
        { id: "spk-side", type: "spikes", state: "active", x: 7, y: 6 }
      ],
      switches: [
        { id: "sw-trap-disarm", x: 2, y: 2, targetType: "trap", targetId: "spk-side", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 9, y: 2, points: 100 }]
    },
    {
      id: 40,
      world: 4,
      name: "Danger Zone Citadel",
      difficulty: "hard",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 32,
      parTime: 95,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 2, y: 1}, {x: 3, y: 1}], exit: {x: 10, y: 10} },
        { id: "snake-blue", color: "blue", segments: [{x: 10, y: 1}, {x: 9, y: 1}, {x: 8, y: 1}], exit: {x: 1, y: 10} }
      ],
      walls: [
        {x: 6, y: 2}, {x: 6, y: 3}, {x: 6, y: 8}, {x: 6, y: 9}
      ],
      blocks: [
        { id: "citadel-b1", x: 4, y: 5 },
        { id: "citadel-b2", x: 7, y: 6 }
      ],
      traps: [
        { id: "spk-mid", type: "spikes", state: "active", x: 6, y: 5 }
      ],
      switches: [
        { id: "sw-citadel-trap", x: 2, y: 6, targetType: "trap", targetId: "spk-mid", pressed: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 6, y: 1, points: 200 }]
    },

    // =========================================================================
    // WORLD 5: SNAKE TEMPLE (Levels 41–50)
    // Master Integration: 2-3 Snakes, Keys, Switches, Gates, Portals, Blocks & Traps
    // =========================================================================
    {
      id: 41,
      world: 5,
      name: "Temple Gates",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 26,
      parTime: 80,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 3}, {x: 1, y: 2}, {x: 2, y: 2}], exit: {x: 10, y: 3} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 8}, {x: 1, y: 9}, {x: 2, y: 9}], exit: {x: 10, y: 8} }
      ],
      walls: [
        {x: 6, y: 1}, {x: 6, y: 2}, {x: 6, y: 4}, {x: 6, y: 5}, {x: 6, y: 7}, {x: 6, y: 9}, {x: 6, y: 10}
      ],
      gates: [
        { id: "tg-1", color: "green", requiresKey: "green", x: 6, y: 3, isOpen: false },
        { id: "tg-2", color: "blue", requiresKey: "blue", x: 6, y: 8, isOpen: false }
      ],
      keys: [
        { id: "tk-green", color: "green", x: 3, y: 8, collected: false },
        { id: "tk-blue", color: "blue", x: 3, y: 3, collected: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 8, y: 5, points: 200 }]
    },
    {
      id: 42,
      world: 5,
      name: "Portal to Portal",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 28,
      parTime: 85,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 2, y: 2}], exit: {x: 10, y: 10} },
        { id: "snake-blue", color: "blue", segments: [{x: 10, y: 1}, {x: 10, y: 2}, {x: 9, y: 2}], exit: {x: 1, y: 10} }
      ],
      walls: [
        {x: 5, y: 0}, {x: 5, y: 1}, {x: 5, y: 2}, {x: 5, y: 3}, {x: 5, y: 4},
        {x: 6, y: 7}, {x: 6, y: 8}, {x: 6, y: 9}, {x: 6, y: 10}, {x: 6, y: 11}
      ],
      portals: [
        { id: "pt-1", pairId: "warp-1", color: "green", x: 2, y: 8 },
        { id: "pt-2", pairId: "warp-1", color: "green", x: 8, y: 2 }
      ],
      collectibles: [{ id: "c1", type: "star", x: 5, y: 6, points: 100 }]
    },
    {
      id: 43,
      world: 5,
      name: "Block & Key Synergy",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 30,
      parTime: 90,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 10, y: 5} }
      ],
      walls: [
        {x: 5, y: 3}, {x: 5, y: 4}, {x: 5, y: 6}, {x: 5, y: 7},
        {x: 8, y: 3}, {x: 8, y: 4}, {x: 8, y: 6}, {x: 8, y: 7}
      ],
      blocks: [
        { id: "syn-b", x: 5, y: 5 }
      ],
      keys: [
        { id: "syn-k", color: "gold", x: 6, y: 2, collected: false }
      ],
      gates: [
        { id: "syn-g", color: "gold", requiresKey: "gold", x: 8, y: 5, isOpen: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 10, y: 2, points: 200 }]
    },
    {
      id: 44,
      world: 5,
      name: "The Grand Crossing",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 32,
      parTime: 95,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 2, y: 1}, {x: 2, y: 2}, {x: 2, y: 3}], exit: {x: 2, y: 10} },
        { id: "snake-blue", color: "blue", segments: [{x: 9, y: 10}, {x: 9, y: 9}, {x: 9, y: 8}], exit: {x: 9, y: 1} },
        { id: "snake-orange", color: "orange", segments: [{x: 1, y: 6}, {x: 2, y: 6}, {x: 3, y: 6}], exit: {x: 10, y: 6} }
      ],
      walls: [
        {x: 5, y: 2}, {x: 6, y: 2}, {x: 5, y: 9}, {x: 6, y: 9}
      ],
      collectibles: [{ id: "c1", type: "star", x: 6, y: 5, points: 100 }]
    },
    {
      id: 45,
      world: 5,
      name: "Spike Pit Bridge",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 30,
      parTime: 90,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 2, y: 6}], exit: {x: 10, y: 5} }
      ],
      walls: [
        {x: 6, y: 0}, {x: 6, y: 1}, {x: 6, y: 2}, {x: 6, y: 3},
        {x: 6, y: 7}, {x: 6, y: 8}, {x: 6, y: 9}, {x: 6, y: 10}, {x: 6, y: 11}
      ],
      bridges: [
        { id: "bridge-chasm", x: 6, y: 5, active: false }
      ],
      switches: [
        { id: "sw-chasm-extend", x: 3, y: 2, targetType: "bridge", targetId: "bridge-chasm", pressed: false }
      ],
      traps: [
        { id: "t-side1", type: "spikes", state: "active", x: 8, y: 4 },
        { id: "t-side2", type: "spikes", state: "active", x: 8, y: 6 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 8, y: 2, points: 200 }]
    },
    {
      id: 46,
      world: 5,
      name: "The Triad Conundrum",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 34,
      parTime: 100,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 2}, {x: 1, y: 1}, {x: 2, y: 1}], exit: {x: 10, y: 2} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 6}, {x: 1, y: 5}, {x: 2, y: 5}], exit: {x: 10, y: 6} },
        { id: "snake-orange", color: "orange", segments: [{x: 1, y: 10}, {x: 1, y: 9}, {x: 2, y: 9}], exit: {x: 10, y: 10} }
      ],
      walls: [
        {x: 5, y: 1}, {x: 5, y: 3}, {x: 5, y: 5}, {x: 5, y: 7}, {x: 5, y: 9}, {x: 5, y: 11}
      ],
      gates: [
        { id: "tri-g1", color: "green", requiresKey: "green", x: 5, y: 2, isOpen: false },
        { id: "tri-g2", color: "blue", requiresKey: "blue", x: 5, y: 6, isOpen: false },
        { id: "tri-g3", color: "orange", requiresKey: "orange", x: 5, y: 10, isOpen: false }
      ],
      keys: [
        { id: "k-tri-1", color: "green", x: 3, y: 6, collected: false },
        { id: "k-tri-2", color: "blue", x: 3, y: 10, collected: false },
        { id: "k-tri-3", color: "orange", x: 3, y: 2, collected: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 8, y: 6, points: 100 }]
    },
    {
      id: 47,
      world: 5,
      name: "The Serpent Clock",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 32,
      parTime: 95,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 5, y: 2}, {x: 5, y: 1}, {x: 4, y: 1}], exit: {x: 5, y: 9} },
        { id: "snake-blue", color: "blue", segments: [{x: 9, y: 5}, {x: 10, y: 5}, {x: 10, y: 4}], exit: {x: 2, y: 5} }
      ],
      walls: [
        {x: 4, y: 4}, {x: 6, y: 4}, {x: 4, y: 6}, {x: 6, y: 6}
      ],
      blocks: [
        { id: "clock-b", x: 5, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 2, y: 2, points: 200 }]
    },
    {
      id: 48,
      world: 5,
      name: "Portal Maze Matrix",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 35,
      parTime: 105,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 2, y: 1}, {x: 3, y: 1}], exit: {x: 10, y: 10} }
      ],
      walls: [
        {x: 3, y: 3}, {x: 4, y: 3}, {x: 5, y: 3},
        {x: 7, y: 8}, {x: 8, y: 8}, {x: 9, y: 8}
      ],
      portals: [
        { id: "mtx-p1", pairId: "m1", color: "green", x: 2, y: 5 },
        { id: "mtx-p2", pairId: "m1", color: "green", x: 9, y: 2 },
        { id: "mtx-p3", pairId: "m2", color: "blue", x: 9, y: 5 },
        { id: "mtx-p4", pairId: "m2", color: "blue", x: 2, y: 9 }
      ],
      collectibles: [{ id: "c1", type: "star", x: 6, y: 6, points: 100 }]
    },
    {
      id: 49,
      world: 5,
      name: "The Poison Gauntlet",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 36,
      parTime: 110,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 10}, {x: 1, y: 9}, {x: 2, y: 9}], exit: {x: 10, y: 1} },
        { id: "snake-blue", color: "blue", segments: [{x: 10, y: 10}, {x: 10, y: 9}, {x: 9, y: 9}], exit: {x: 1, y: 1} }
      ],
      walls: [
        {x: 5, y: 3}, {x: 5, y: 4}, {x: 6, y: 7}, {x: 6, y: 8}
      ],
      traps: [
        { id: "t-gaunt-1", type: "poison", state: "active", x: 3, y: 5 },
        { id: "t-gaunt-2", type: "poison", state: "active", x: 8, y: 5 }
      ],
      keys: [
        { id: "k-gaunt", color: "gold", x: 5, y: 5, collected: false }
      ],
      gates: [
        { id: "g-gaunt-1", color: "gold", requiresKey: "gold", x: 3, y: 2, isOpen: false },
        { id: "g-gaunt-2", color: "gold", requiresKey: "gold", x: 8, y: 2, isOpen: false }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 6, y: 2, points: 200 }]
    },
    {
      id: 50,
      world: 5,
      name: "The Serpent Throne",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "step",
      parMoves: 38,
      parTime: 120,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 2, y: 1}, {x: 3, y: 1}], exit: {x: 10, y: 10} },
        { id: "snake-blue", color: "blue", segments: [{x: 1, y: 10}, {x: 2, y: 10}, {x: 3, y: 10}], exit: {x: 10, y: 1} },
        { id: "snake-orange", color: "orange", segments: [{x: 5, y: 5}, {x: 5, y: 6}, {x: 5, y: 7}], exit: {x: 1, y: 5} }
      ],
      walls: [
        {x: 4, y: 3}, {x: 7, y: 3}, {x: 4, y: 8}, {x: 7, y: 8}
      ],
      gates: [
        { id: "throne-g", color: "gold", requiresKey: "gold", x: 8, y: 5, isOpen: false }
      ],
      keys: [
        { id: "throne-k", color: "gold", x: 3, y: 5, collected: false }
      ],
      collectibles: [
        { id: "c1", type: "star", x: 10, y: 5, points: 100 },
        { id: "c2", type: "gem", x: 5, y: 2, points: 200 }
      ]
    },

    // =========================================================================
    // WORLD 6: MASTER ESCAPE (Levels 51–60)
    // Glide / Slide Puzzle Mode ("glide") + Multi-Snake Coordination
    // Snakes slide continuously until hitting obstacles, walls, gates, switches, or blocks!
    // =========================================================================
    {
      id: 51,
      world: 6,
      name: "The Frozen Moss",
      difficulty: "expert",
      grid: { cols: 10, rows: 10 },
      movementMode: "glide",
      parMoves: 6,
      parTime: 30,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 1, y: 3}], exit: {x: 8, y: 8} }
      ],
      walls: [
        {x: 8, y: 1}, {x: 1, y: 8}, {x: 4, y: 4}, {x: 5, y: 5}
      ],
      collectibles: [{ id: "c1", type: "gem", x: 8, y: 4, points: 200 }]
    },
    {
      id: 52,
      world: 6,
      name: "Glide & Stopper",
      difficulty: "expert",
      grid: { cols: 10, rows: 10 },
      movementMode: "glide",
      parMoves: 8,
      parTime: 35,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 8}, {x: 1, y: 7}, {x: 2, y: 7}], exit: {x: 8, y: 1} }
      ],
      walls: [
        {x: 1, y: 3}, {x: 5, y: 8}, {x: 5, y: 1}, {x: 8, y: 5}
      ],
      collectibles: [{ id: "c1", type: "star", x: 5, y: 3, points: 100 }]
    },
    {
      id: 53,
      world: 6,
      name: "Sliding Twins",
      difficulty: "expert",
      grid: { cols: 10, rows: 10 },
      movementMode: "glide",
      parMoves: 10,
      parTime: 40,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 2, y: 2}], exit: {x: 8, y: 1} },
        { id: "snake-blue", color: "blue", segments: [{x: 8, y: 8}, {x: 8, y: 7}, {x: 7, y: 7}], exit: {x: 1, y: 8} }
      ],
      walls: [
        {x: 4, y: 1}, {x: 5, y: 8}, {x: 4, y: 5}, {x: 5, y: 4}
      ],
      collectibles: [{ id: "c1", type: "coin", x: 4, y: 8, points: 150 }]
    },
    {
      id: 54,
      world: 6,
      name: "Glide into Key",
      difficulty: "expert",
      grid: { cols: 10, rows: 10 },
      movementMode: "glide",
      parMoves: 12,
      parTime: 45,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 8, y: 8} }
      ],
      walls: [
        {x: 5, y: 1}, {x: 5, y: 2}, {x: 5, y: 3}, {x: 5, y: 4}, {x: 8, y: 5}
      ],
      keys: [
        { id: "glide-k", color: "gold", x: 5, y: 8, collected: false }
      ],
      gates: [
        { id: "glide-g", color: "gold", requiresKey: "gold", x: 6, y: 8, isOpen: false }
      ],
      collectibles: [{ id: "c1", type: "star", x: 2, y: 2, points: 100 }]
    },
    {
      id: 55,
      world: 6,
      name: "The Portal Slide",
      difficulty: "expert",
      grid: { cols: 11, rows: 11 },
      movementMode: "glide",
      parMoves: 12,
      parTime: 50,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 1, y: 3}], exit: {x: 9, y: 9} }
      ],
      walls: [
        {x: 5, y: 1}, {x: 9, y: 5}, {x: 1, y: 9}
      ],
      portals: [
        { id: "gp1", pairId: "glide-p", color: "green", x: 5, y: 5 },
        { id: "gp2", pairId: "glide-p", color: "green", x: 9, y: 1 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 5, y: 9, points: 200 }]
    },
    {
      id: 56,
      world: 6,
      name: "Ricochet Corridor",
      difficulty: "expert",
      grid: { cols: 11, rows: 11 },
      movementMode: "glide",
      parMoves: 14,
      parTime: 55,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 9}, {x: 1, y: 8}, {x: 2, y: 8}], exit: {x: 9, y: 1} }
      ],
      walls: [
        {x: 1, y: 4}, {x: 6, y: 9}, {x: 6, y: 4}, {x: 9, y: 6}
      ],
      collectibles: [{ id: "c1", type: "star", x: 6, y: 1, points: 100 }]
    },
    {
      id: 57,
      world: 6,
      name: "Block Stop Glide",
      difficulty: "expert",
      grid: { cols: 11, rows: 11 },
      movementMode: "glide",
      parMoves: 15,
      parTime: 60,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 1, y: 7}], exit: {x: 9, y: 1} }
      ],
      walls: [
        {x: 9, y: 5}, {x: 5, y: 9}
      ],
      blocks: [
        { id: "glide-b1", x: 5, y: 5 }
      ],
      collectibles: [{ id: "c1", type: "gem", x: 5, y: 1, points: 200 }]
    },
    {
      id: 58,
      world: 6,
      name: "Twin Sliding Cross",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "glide",
      parMoves: 16,
      parTime: 65,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 5}, {x: 1, y: 6}, {x: 2, y: 6}], exit: {x: 10, y: 5} },
        { id: "snake-blue", color: "blue", segments: [{x: 5, y: 1}, {x: 6, y: 1}, {x: 6, y: 2}], exit: {x: 5, y: 10} }
      ],
      walls: [
        {x: 10, y: 1}, {x: 1, y: 10}, {x: 7, y: 7}
      ],
      collectibles: [{ id: "c1", type: "star", x: 10, y: 10, points: 100 }]
    },
    {
      id: 59,
      world: 6,
      name: "Triple Slide Matrix",
      difficulty: "expert",
      grid: { cols: 12, rows: 12 },
      movementMode: "glide",
      parMoves: 20,
      parTime: 75,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 1, y: 2}, {x: 2, y: 2}], exit: {x: 10, y: 10} },
        { id: "snake-blue", color: "blue", segments: [{x: 10, y: 1}, {x: 10, y: 2}, {x: 9, y: 2}], exit: {x: 1, y: 10} },
        { id: "snake-orange", color: "orange", segments: [{x: 5, y: 10}, {x: 6, y: 10}, {x: 6, y: 9}], exit: {x: 5, y: 1} }
      ],
      walls: [
        {x: 3, y: 5}, {x: 8, y: 5}, {x: 5, y: 3}, {x: 5, y: 8}
      ],
      collectibles: [{ id: "c1", type: "gem", x: 1, y: 5, points: 200 }]
    },
    {
      id: 60,
      world: 6,
      name: "Master of the Jungle",
      difficulty: "expert",
      grid: { cols: 14, rows: 14 },
      movementMode: "glide",
      parMoves: 24,
      parTime: 90,
      snakes: [
        { id: "snake-green", color: "green", segments: [{x: 1, y: 1}, {x: 2, y: 1}, {x: 3, y: 1}], exit: {x: 12, y: 12} },
        { id: "snake-blue", color: "blue", segments: [{x: 12, y: 1}, {x: 11, y: 1}, {x: 10, y: 1}], exit: {x: 1, y: 12} },
        { id: "snake-purple", color: "purple", segments: [{x: 6, y: 12}, {x: 7, y: 12}, {x: 8, y: 12}], exit: {x: 6, y: 1} }
      ],
      walls: [
        {x: 6, y: 4}, {x: 8, y: 4}, {x: 6, y: 9}, {x: 8, y: 9},
        {x: 4, y: 6}, {x: 9, y: 6}
      ],
      portals: [
        { id: "mp1", pairId: "master-p", color: "purple", x: 4, y: 4 },
        { id: "mp2", pairId: "master-p", color: "purple", x: 9, y: 9 }
      ],
      collectibles: [
        { id: "c1", type: "star", x: 6, y: 6, points: 100 },
        { id: "c2", type: "gem", x: 8, y: 7, points: 200 }
      ]
    }
  ];


  // ===========================================================================
  // EXPANSION PACK — 40 additional handcrafted-style challenge levels (61–100)
  // Built from fixed puzzle recipes so every level has a guaranteed primary route.
  // ===========================================================================
  function addExpansionLevels() {
    const worldNames = {
      7: 'Canopy Trials',
      8: 'Temple Machines',
      9: 'Primal Labyrinth',
      10: 'Grand Escape',
      11: 'Volcanic Roots',
      12: 'Eternal Canopy'
    };

    const recipes = [
      { type: 'zigzag', mode: 'step' },
      { type: 'keygate', mode: 'step' },
      { type: 'switchbridge', mode: 'step' },
      { type: 'portal', mode: 'step' },
      { type: 'push', mode: 'step' },
      { type: 'trap', mode: 'step' },
      { type: 'multisnake', mode: 'step' },
      { type: 'hybrid', mode: 'step' },
      { type: 'glide', mode: 'glide' },
      { type: 'master', mode: 'glide' }
    ];

    const inBounds = (x, y, cols, rows) => x >= 0 && y >= 0 && x < cols && y < rows;
    const key = (x, y) => `${x},${y}`;

    function makeRoute(cols, rows, seed) {
      // Deterministic L + dog-leg route; no random generation at runtime.
      const left = 2;
      const top = 2;
      const right = cols - 2 - ((seed >> 1) % 2);
      const bottom = rows - 2 - ((seed >> 2) % 2);
      const bendX = Math.max(left + 2, Math.min(right - 2, Math.floor((left + right) / 2) + ((seed % 3) - 1)));
      const route = [];
      const pushLine = (x1, y1, x2, y2) => {
        const dx = Math.sign(x2 - x1), dy = Math.sign(y2 - y1);
        let x = x1, y = y1;
        route.push({x, y});
        while (x !== x2 || y !== y2) {
          if (x !== x2) x += dx; else y += dy;
          route.push({x, y});
        }
      };
      pushLine(left, top, bendX, top);
      pushLine(bendX, top, bendX, bottom);
      pushLine(bendX, bottom, right, bottom);
      return route;
    }

    function makeWalls(cols, rows, route, seed) {
      const routeSet = new Set(route.map(p => key(p.x, p.y)));
      const walls = [];
      for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
          if (routeSet.has(key(x, y))) continue;
          if (x === 0 || y === 0 || x === cols - 1 || y === rows - 1) continue;
          if (((x * 17 + y * 31 + seed * 13) % 19) === 0) walls.push({x, y});
        }
      }
      return walls;
    }

    function baseLevel(id, world, recipeIndex) {
      const cols = world >= 9 ? 12 : 11;
      const rows = world >= 9 ? 12 : 11;
      const seed = id * 7 + world * 11;
      const route = makeRoute(cols, rows, seed);
      const start = route[0];
      const exit = route[route.length - 1];
      // Body is placed behind the route start so the first move is always legal.
      const body1 = {x: Math.max(0, start.x - 1), y: start.y};
      const body2 = {x: Math.max(0, start.x - 2), y: start.y};
      const lvl = {
        id, world,
        name: `${worldNames[world]} ${String(id).padStart(2, '0')}`,
        difficulty: world === 7 ? 'normal' : world === 8 ? 'hard' : 'expert',
        grid: {cols, rows},
        movementMode: recipes[recipeIndex].mode,
        parMoves: Math.max(10, route.length + 2),
        parTime: 55 + world * 5,
        snakes: [{id: 'snake-green', color: 'green', segments: [start, body1, body2], exit}],
        walls: makeWalls(cols, rows, route, seed),
        collectibles: [{id: `c${id}`, type: recipeIndex % 3 === 0 ? 'star' : 'gem', x: route[Math.floor(route.length * 0.35)].x, y: route[Math.floor(route.length * 0.35)].y, points: recipeIndex % 3 === 0 ? 100 : 200}]
      };
      return {lvl, route, seed};
    }

    for (let id = 61; id <= 120; id++) {
      const world = Math.ceil((id - 60) / 10) + 6;
      const recipeIndex = (id - 61) % 10;
      const {lvl, route, seed} = baseLevel(id, world, recipeIndex);
      const mid = route[Math.max(2, Math.floor(route.length * 0.55))];
      const beforeMid = route[Math.max(1, Math.floor(route.length * 0.45))];

      if (recipeIndex === 1) {
        lvl.keys = [{id: `key-${id}`, color: 'gold', x: beforeMid.x, y: beforeMid.y, collected: false}];
        lvl.gates = [{id: `gate-${id}`, color: 'gold', requiresKey: 'gold', x: mid.x, y: mid.y, isOpen: false}];
      } else if (recipeIndex === 2) {
        const b = route[Math.min(route.length - 2, Math.floor(route.length * 0.65))];
        lvl.switches = [{id: `switch-${id}`, x: beforeMid.x, y: beforeMid.y, targetType: 'bridge', targetId: `bridge-${id}`, pressed: false}];
        lvl.bridges = [{id: `bridge-${id}`, x: b.x, y: b.y, active: false}];
      } else if (recipeIndex === 3) {
        const p1 = route[Math.max(2, Math.floor(route.length * 0.3))];
        const p2 = route[Math.min(route.length - 2, Math.floor(route.length * 0.72))];
        lvl.portals = [
          {id: `p1-${id}`, pairId: `pair-${id}`, color: 'blue', x: p1.x, y: p1.y},
          {id: `p2-${id}`, pairId: `pair-${id}`, color: 'blue', x: p2.x, y: p2.y}
        ];
      } else if (recipeIndex === 4) {
        // Push a block one cell along the guaranteed route.
        const idx = Math.max(2, Math.floor(route.length * 0.48));
        const cell = route[idx];
        const next = route[idx + 1];
        if (next) {
          lvl.blocks = [{id: `block-${id}`, x: cell.x, y: cell.y}];
          lvl.pushPuzzle = {requiredPushes: 1, note: 'Push the stone block forward to continue.'};
        }
      } else if (recipeIndex === 5) {
        const trapCell = route[Math.min(route.length - 2, Math.floor(route.length * 0.66))];
        const safeSwitch = route[Math.max(1, Math.floor(route.length * 0.48))];
        lvl.traps = [{id: `trap-${id}`, type: 'spikes', x: trapCell.x, y: trapCell.y, state: 'active', isTimed: false}];
        lvl.switches = [{id: `switch-${id}`, x: safeSwitch.x, y: safeSwitch.y, targetType: 'trap', targetId: `trap-${id}`, pressed: false}];
      } else if (recipeIndex === 6) {
        // Two independent lanes: each snake has a clear, non-overlapping start/exit zone.
        const a = route[0], e = route[route.length - 1];
        const blueStart = {x: lvl.grid.cols - 3, y: 2};
        const blueExit = {x: 2, y: lvl.grid.rows - 3};
        lvl.snakes = [
          {id: 'snake-green', color: 'green', segments: [a, {x: a.x - 1, y: a.y}, {x: a.x - 2, y: a.y}], exit: e},
          {id: 'snake-blue', color: 'blue', segments: [blueStart, {x: blueStart.x, y: blueStart.y + 1}, {x: blueStart.x, y: blueStart.y + 2}], exit: blueExit}
        ];
        // A small vertical lane keeps the second snake independent from the main route.
        lvl.walls = lvl.walls.filter(w => !(w.x >= lvl.grid.cols - 4 && w.y <= 4));
        lvl.walls.push({x: lvl.grid.cols - 3, y: Math.floor(lvl.grid.rows / 2)});
      } else if (recipeIndex === 7) {
        const p1 = route[Math.max(2, Math.floor(route.length * 0.25))];
        const p2 = route[Math.min(route.length - 2, Math.floor(route.length * 0.68))];
        lvl.keys = [{id: `key-${id}`, color: 'gold', x: p1.x, y: p1.y, collected: false}];
        lvl.gates = [{id: `gate-${id}`, color: 'gold', requiresKey: 'gold', x: p2.x, y: p2.y, isOpen: false}];
        lvl.portals = [
          {id: `p1-${id}`, pairId: `pair-${id}`, color: 'green', x: route[Math.max(2, Math.floor(route.length * 0.18))].x, y: route[Math.max(2, Math.floor(route.length * 0.18))].y},
          {id: `p2-${id}`, pairId: `pair-${id}`, color: 'green', x: route[Math.min(route.length - 2, Math.floor(route.length * 0.82))].x, y: route[Math.min(route.length - 2, Math.floor(route.length * 0.82))].y}
        ];
      } else if (recipeIndex === 8) {
        lvl.collectibles.push({id: `c2-${id}`, type: 'coin', x: route[Math.floor(route.length * 0.75)].x, y: route[Math.floor(route.length * 0.75)].y, points: 150});
        lvl.traps = [{id: `trap-${id}`, type: 'spikes', x: mid.x, y: mid.y, state: 'active', isTimed: true}];
      } else if (recipeIndex === 9) {
        const p1 = route[Math.max(2, Math.floor(route.length * 0.22))];
        const p2 = route[Math.min(route.length - 2, Math.floor(route.length * 0.74))];
        lvl.keys = [{id: `key-${id}`, color: 'gold', x: p1.x, y: p1.y, collected: false}];
        lvl.gates = [{id: `gate-${id}`, color: 'gold', requiresKey: 'gold', x: p2.x, y: p2.y, isOpen: false}];
        lvl.portals = [
          {id: `p1-${id}`, pairId: `pair-${id}`, color: 'purple', x: route[Math.max(2, Math.floor(route.length * 0.34))].x, y: route[Math.max(2, Math.floor(route.length * 0.34))].y},
          {id: `p2-${id}`, pairId: `pair-${id}`, color: 'purple', x: route[Math.min(route.length - 2, Math.floor(route.length * 0.60))].x, y: route[Math.min(route.length - 2, Math.floor(route.length * 0.60))].y}
        ];
        lvl.bridges = [{id: `bridge-${id}`, x: route[Math.floor(route.length * 0.5)].x, y: route[Math.floor(route.length * 0.5)].y, active: true}];
        lvl.switches = [{id: `switch-${id}`, x: route[Math.floor(route.length * 0.4)].x, y: route[Math.floor(route.length * 0.4)].y, targetType: 'gate', targetId: `gate-${id}`, pressed: false}];
      }

      // Keep the expansion pack deterministic and easy to inspect in devtools.
      lvl.tags = ['expansion', worldNames[world].toLowerCase().replace(/\s+/g, '-'), recipes[recipeIndex].type];
      LEVELS.push(lvl);
    }
  }

  addExpansionLevels();

  /**
   * Deterministic Daily Challenge generator based on YYYY-MM-DD date string
   */
  function getDailyLevel(dateStr) {
    let hash = 0;
    for (let i = 0; i < dateStr.length; i++) {
      hash = ((hash << 5) - hash) + dateStr.charCodeAt(i);
      hash |= 0;
    }
    const seed = Math.abs(hash);

    // Pick a base level from worlds 2-5
    const baseIndex = 10 + (seed % Math.max(1, LEVELS.length - 10));
    const base = JSON.parse(JSON.stringify(LEVELS[baseIndex]));

    base.id = 999;
    base.isDaily = true;
    base.name = `Daily: ${dateStr}`;
    base.difficulty = "normal";

    return base;
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.LEVELS = LEVELS;
  window.SnakeEscape.getDailyLevel = getDailyLevel;
})();
