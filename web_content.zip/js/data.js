// ===== Configuração ajustável (seção 9.5 do GDD) =====
const CONFIG = {
  taxa_fome: 1 / 18,        // pontos por segundo (≈30 min até zerar)
  taxa_sede: 1 / 9,         // ≈15 min até zerar
  energia_passiva: 0.5 / 60,
  chance_indisposicao: 0.3,
  duracao_dia: 1200,        // 20 min reais (14 dia + 6 noite)
  periodo_mare: 600,        // 10 min
  mare_baixa: 240,          // primeiros 4 min do ciclo
  carga_maxima: 20,
  carga_limite: 28,
  velocidade: 120,
  velocidade_corrida: 190,
};

// ===== Itens =====
// st = pilha máxima, w = peso (kg), ic = [forma do ícone, cor]
const ITEMS = {
  graveto: { n: 'Graveto', st: 20, w: 0.1, ic: ['stick', '#9a6b3f'], d: 'Base de quase tudo no começo.' },
  fibra: { n: 'Fibra', st: 20, w: 0.1, ic: ['fiber', '#b4bf5e'], d: 'Trançada vira corda.' },
  folha: { n: 'Folha grande', st: 20, w: 0.1, ic: ['leaf', '#4f9a46'], d: 'Camas, telhados e coletores.' },
  cipo: { n: 'Cipó', st: 20, w: 0.1, ic: ['vine', '#5c8a3a'], d: 'Corda resistente.' },
  resina: { n: 'Resina', st: 10, w: 0.2, ic: ['resin', '#e0a030'], d: 'Tochas mais longas e cola.' },
  tora: { n: 'Tora', st: 5, w: 2.0, ic: ['log', '#8a5a32'], d: 'Pesada, mas essencial para construir.' },
  pedrinha: { n: 'Pedra pequena', st: 15, w: 0.3, ic: ['pebble', '#a4a29a'], d: 'Abre cocos e afia ferramentas.' },
  pedra: { n: 'Pedra', st: 10, w: 1.0, ic: ['stone', '#8d8b84'], d: 'Material de construção.' },
  silex: { n: 'Sílex', st: 10, w: 0.5, ic: ['flint', '#6a7a8a'], d: 'Corta como faca. Chave do tier 2.' },
  obsidiana: { n: 'Obsidiana', st: 10, w: 0.5, ic: ['obsidian', '#2a2338'], d: 'Vidro vulcânico. Chave do tier 3.' },
  enxofre: { n: 'Enxofre', st: 10, w: 0.3, ic: ['sulfur', '#e8d23a'], d: 'Queima forte. Usado no sinalizador.' },
  argila: { n: 'Argila', st: 10, w: 0.6, ic: ['clay', '#b06a45'], d: 'Vira pote e forno no fogo.' },
  pano: { n: 'Pano', st: 10, w: 0.2, ic: ['cloth', '#d9cdb4'], d: 'Bandagens, bolsas, máscara.' },
  corda: { n: 'Corda do navio', st: 10, w: 0.3, ic: ['rope', '#c9a46a'], d: 'Pode substituir a corda de fibra.' },
  metal: { n: 'Metal enferrujado', st: 5, w: 0.8, ic: ['metal', '#9a6a4a'], d: 'Raro. Cantil e sinalizador.' },
  concha: { n: 'Concha', st: 15, w: 0.1, ic: ['shell', '#f0d8c8'], d: 'Decoração e troca... por enquanto.' },
  carvao: { n: 'Carvão', st: 10, w: 0.3, ic: ['coal', '#333'], d: 'Filtra o ar na máscara.' },
  corda_fibra: { n: 'Corda de fibra', st: 10, w: 0.1, ic: ['rope', '#b7b860'], d: 'Amarração básica.' },
  corda_cipo: { n: 'Corda de cipó', st: 10, w: 0.2, ic: ['rope', '#6e9a40'], d: 'Amarração resistente.' },
  casca_coco: { n: 'Casca de coco', st: 5, w: 0.1, ic: ['shellhalf', '#7a5230'], d: 'Vira um copo com uma pedra.' },
  erva: { n: 'Erva medicinal', st: 10, w: 0.05, ic: ['herb', '#7fb069'], d: 'Melhora bandagens.' },
  lamina: { n: 'Lâmina de obsidiana', st: 5, w: 0.3, ic: ['blade', '#2a2533'], d: 'Componente de ferramenta.' },
  estragado: { n: 'Comida estragada', st: 10, w: 0.2, ic: ['meat', '#6b6b3a'], d: 'Já era. Serve só de isca.' },

  coco: { n: 'Coco', st: 5, w: 0.5, ic: ['coconut', '#6b4a2a'], food: { f: 10, s: 10, open: true }, d: 'Mata a fome e a sede. Precisa de uma pedra para abrir.' },
  fruta: { n: 'Frutas silvestres', st: 5, w: 0.2, ic: ['berry', '#c0304a'], food: { f: 5, tox: 0.15 }, spoil: 1200, d: 'Algumas são tóxicas.' },
  carne_crab: { n: 'Caranguejo cru', st: 5, w: 0.3, ic: ['meat', '#d8705a'], food: { f: 8, raw: 0.2 }, spoil: 1200, d: 'Cozinhe na fogueira.' },
  crab_cozido: { n: 'Caranguejo cozido', st: 5, w: 0.3, ic: ['meatc', '#c0452e'], food: { f: 20, e: 5 }, spoil: 2400 },
  peixe: { n: 'Peixe cru', st: 5, w: 0.4, ic: ['fish', '#7aa6b8'], food: { f: 10, raw: 0.25 }, spoil: 1200, d: 'Cozinhe na fogueira.' },
  peixe_assado: { n: 'Peixe assado', st: 5, w: 0.4, ic: ['fishc', '#c08a4a'], food: { f: 30, e: 5 }, spoil: 2400 },
  ovo: { n: 'Ovo', st: 5, w: 0.2, ic: ['egg', '#efe6d2'], food: { f: 5, raw: 0.1 }, spoil: 1200 },
  ovo_cozido: { n: 'Ovo cozido', st: 5, w: 0.2, ic: ['egg', '#f4d27a'], food: { f: 18, e: 3 }, spoil: 2400 },
  raiz: { n: 'Raiz', st: 5, w: 0.2, ic: ['root', '#a0784a'], food: { f: 6 }, spoil: 1800 },
  raiz_assada: { n: 'Raiz assada', st: 5, w: 0.2, ic: ['root', '#7a4a20'], food: { f: 15, e: 3 }, spoil: 2400 },

  machado_pedra: { n: 'Machado de pedra', st: 1, w: 1.5, ic: ['axe', '#8d8b84'], tool: { c: 'machado', t: 1, dur: 40, dmg: 1.5 } },
  picareta_pedra: { n: 'Picareta de pedra', st: 1, w: 1.5, ic: ['pick', '#8d8b84'], tool: { c: 'picareta', t: 1, dur: 40, dmg: 1.5 } },
  lanca: { n: 'Lança afiada', st: 1, w: 1.0, ic: ['spear', '#a4a29a'], tool: { c: 'lanca', t: 1, dur: 30, dmg: 2 } },
  faca_silex: { n: 'Faca de sílex', st: 1, w: 0.4, ic: ['knife', '#6a7a8a'], tool: { c: 'faca', t: 2, dur: 60, dmg: 1.5 } },
  machado_silex: { n: 'Machado de sílex', st: 1, w: 1.4, ic: ['axe', '#6a7a8a'], tool: { c: 'machado', t: 2, dur: 90, dmg: 2 } },
  picareta_silex: { n: 'Picareta de sílex', st: 1, w: 1.4, ic: ['pick', '#6a7a8a'], tool: { c: 'picareta', t: 2, dur: 90, dmg: 2 } },
  lanca_pesca: { n: 'Lança de pesca', st: 1, w: 1.0, ic: ['spear', '#6a7a8a'], tool: { c: 'lanca', t: 2, dur: 60, dmg: 2.5 } },
  machado_obsidiana: { n: 'Machado de obsidiana', st: 1, w: 1.2, ic: ['axe', '#3a3048'], tool: { c: 'machado', t: 3, dur: 150, dmg: 3 } },

  tocha: { n: 'Tocha', st: 5, w: 0.3, ic: ['torch', '#e0a030'], light: 180, d: 'Luz por 3 minutos. Afasta caranguejos.' },
  tocha_resina: { n: 'Tocha de resina', st: 5, w: 0.3, ic: ['torch', '#f0c040'], light: 360, d: 'Luz por 6 minutos.' },
  bandagem: { n: 'Bandagem', st: 5, w: 0.1, ic: ['bandage', '#e8e0d0'], heal: 20 },
  bandagem_erva: { n: 'Bandagem com erva', st: 5, w: 0.1, ic: ['bandage', '#9cc58a'], heal: 35 },
  mascara: { n: 'Máscara de gás', st: 1, w: 0.2, ic: ['mask', '#d9cdb4'], d: 'Protege das zonas de gás (basta carregar).' },
  sinalizador: { n: 'Sinalizador', st: 1, w: 1.0, ic: ['flare', '#e04a2a'], d: 'Use na praia para chamar o resgate.' },
  cantil_quebrado: { n: 'Cantil quebrado', st: 1, w: 0.5, ic: ['canteen_broken', '#8a7a5a'], d: 'Com resina e pano dá para consertar.' },
  copo_coco: { n: 'Copo de coco', st: 1, w: 0.2, ic: ['cup', '#7a5230'], cont: 1, d: 'Guarda 1 dose de água.' },
  pote: { n: 'Pote de argila', st: 1, w: 1.5, ic: ['pot', '#b06a45'], cont: 5, boil: true, noRun: true, d: 'Guarda 5 doses e ferve água. Cheio, impede correr.' },
  cantil: { n: 'Cantil', st: 1, w: 0.5, ic: ['canteen', '#7a8a6a'], cont: 4, boil: true, d: 'Guarda 4 doses sem atrapalhar a corrida.' },
};

// ===== Fontes de recursos (nós do mundo) =====
// tool = classe exigida, times = tempo por tier da ferramenta
const NODES = {
  graveto: { name: 'Gravetos', verb: 'Pegar', time: 1, give: () => [['graveto', rint(1, 2)]], respawn: 180, r: 8 },
  arbusto: { name: 'Arbusto seco', verb: 'Arrancar', time: 3, give: () => [['graveto', 2], ['fibra', 1]], respawn: 300, r: 10 },
  coqueiro: { name: 'Coqueiro', special: true, respawn: 1200, solid: true, r: 10 },
  arvore: { name: 'Árvore tropical', verb: 'Cortar', tool: 'machado', times: { 1: 10, 2: 6, 3: 4 }, give: (t) => [['tora', [0, 4, 6, 7][t]], ['resina', 1]], respawn: 2400, solid: true, r: 13, deplete: 'toco' },
  arvore_mangue: { name: 'Árvore do mangue', verb: 'Cortar', tool: 'machado', times: { 1: 8, 2: 5, 3: 3 }, give: (t) => [['tora', [0, 3, 4, 5][t]], ['cipo', 1]], respawn: 2400, solid: true, r: 11, deplete: 'toco' },
  samambaia: { name: 'Folhagem larga', verb: 'Colher', time: 2, give: () => [['folha', rint(2, 3)]], respawn: 240, r: 10 },
  cipoal: { name: 'Cipoal', verb: 'Puxar', time: 3, give: () => [['cipo', 2]], respawn: 400, r: 10 },
  frutas: { name: 'Arbusto de frutas', verb: 'Colher', time: 2, give: () => [['fruta', rint(2, 3)]], respawn: 600, r: 10 },
  pedra_solta: { name: 'Pedra solta', verb: 'Pegar', time: 1, give: () => [['pedrinha', 1]], respawn: 300, r: 7 },
  rocha: { name: 'Rocha', verb: 'Quebrar', tool: 'picareta', times: { 1: 7, 2: 5, 3: 4 }, give: () => [['pedra', 3], ['pedrinha', 1]], respawn: 1200, solid: true, r: 13 },
  silex: { name: 'Veio de sílex', verb: 'Minerar', tool: 'picareta', times: { 1: 10, 2: 7, 3: 5 }, give: () => [['silex', rint(1, 2)]], respawn: 3600, solid: true, r: 12 },
  rocha_vulc: { name: 'Rocha vulcânica', verb: 'Quebrar', tool: 'picareta', minTier: 2, times: { 2: 9, 3: 6 }, give: () => (chance(0.35) ? [['pedra', 4], ['enxofre', 1]] : [['pedra', 4]]), respawn: 2400, solid: true, r: 13 },
  enxofre: { name: 'Depósito de enxofre', verb: 'Minerar', tool: 'picareta', minTier: 2, times: { 2: 8, 3: 6 }, give: () => [['enxofre', rint(1, 2)]], respawn: 3000, r: 10 },
  obsidiana: { name: 'Veio de obsidiana', verb: 'Minerar', tool: 'picareta', minTier: 2, times: { 2: 14, 3: 10 }, give: () => [['obsidiana', 1]], respawn: 6000, solid: true, r: 12 },
  argila: { name: 'Lama de argila', verb: 'Coletar', time: 4, give: () => [['argila', 2]], respawn: 900, r: 10 },
  raizes: { name: 'Raízes', verb: 'Cortar', tool: 'faca', times: { 2: 4, 3: 3 }, give: () => [['raiz', 2]], respawn: 600, r: 10 },
  erva: { name: 'Erva medicinal', verb: 'Colher', time: 2, give: () => [['erva', 1]], respawn: 500, r: 8 },
  ninho: { name: 'Ninho de ave', verb: 'Pegar ovos', time: 3, give: () => [['ovo', rint(1, 2)]], respawn: 1200, r: 10, bird: true },
  toca: { name: 'Toca de caranguejo', verb: 'Pegar caranguejo', time: 4, spearTime: 2, give: () => [['carne_crab', 1]], respawn: 600, r: 9 },
  poca: { name: 'Poça de maré', verb: 'Pescar', tool: 'lanca', times: { 1: 6, 2: 3, 3: 3 }, give: () => [['peixe', 1]], respawn: 400, r: 12, lowTide: true },
  madeira_flut: { name: 'Madeira flutuante', verb: 'Pegar', time: 2, give: () => [['tora', 1]], respawn: 0, r: 12, lowTide: true, once: true },
  conchas: { name: 'Conchas', verb: 'Pegar', time: 1, give: () => [['concha', rint(1, 2)]], respawn: 400, r: 7 },
  caixa: { name: 'Caixa de destroços', verb: 'Abrir', time: 3, give: () => crateLoot(), respawn: 0, r: 12, once: true },
  bau_navio: { name: 'Baú do navio', verb: 'Abrir', time: 2, give: () => [['pano', 1], ['corda', 1], ['cantil_quebrado', 1]], respawn: 0, r: 13, once: true },
  pagina: { name: 'Página de diário', verb: 'Ler', time: 0.5, r: 9, once: true },
  mirante: { name: 'Mirante', verb: 'Escalar', time: 2, r: 14, solid: true },
  fonte_termal: { name: 'Fonte termal', verb: 'Banhar-se', time: 4, r: 18 },
  naufragio: { name: 'Casco do navio', r: 34, solid: true, deco: true },
  // estruturas
  fogueira: { name: 'Fogueira', struct: true, r: 12, solid: true, light: 230 },
  cama: { name: 'Cama de folhas', struct: true, r: 12 },
  abrigo: { name: 'Abrigo de galhos', struct: true, r: 22 },
  bancada: { name: 'Bancada de trabalho', struct: true, r: 15, solid: true },
  coletor: { name: 'Coletor de chuva', struct: true, r: 12, solid: true },
  secador: { name: 'Secador de comida', struct: true, r: 13, solid: true },
  forno: { name: 'Forno de argila', struct: true, r: 15, solid: true, light: 120 },
  bau: { name: 'Baú de madeira', struct: true, r: 12, solid: true },
  pilha: { name: 'Itens no chão', verb: 'Recolher', time: 0.6, r: 9 },
};

function crateLoot() {
  const out = [];
  if (chance(0.75)) out.push(['pano', rint(1, 2)]);
  if (chance(0.4)) out.push(['corda', 1]);
  if (chance(0.4)) out.push(['metal', 1]);
  if (chance(0.3)) out.push(['concha', rint(1, 3)]);
  if (chance(0.25)) out.push(['coco', 1]);
  if (!out.length) out.push(['pano', 1]);
  return out;
}

// ===== Receitas =====
// st: estação necessária (null = mãos, 'fogueira', 'bancada', 'forno')
const RECIPES = [
  // Tier 1 — Primitivo
  { id: 'corda_fibra', tier: 1, st: null, ing: { fibra: 3 }, out: 'corda_fibra', n: 1, t: 2 },
  { id: 'lanca', tier: 1, st: null, ing: { graveto: 2, pedrinha: 1 }, out: 'lanca', n: 1, t: 3 },
  { id: 'machado_pedra', tier: 1, st: null, ing: { graveto: 3, pedrinha: 1, corda_fibra: 1 }, out: 'machado_pedra', n: 1, t: 5 },
  { id: 'picareta_pedra', tier: 1, st: null, ing: { graveto: 3, pedrinha: 2, corda_fibra: 1 }, out: 'picareta_pedra', n: 1, t: 5 },
  { id: 'fogueira', tier: 1, st: null, ing: { graveto: 5, pedrinha: 5 }, place: 'fogueira', t: 6 },
  { id: 'tocha', tier: 1, st: null, ing: { graveto: 1, fibra: 1 }, out: 'tocha', n: 1, t: 2 },
  { id: 'tocha_resina', tier: 1, st: null, ing: { graveto: 1, fibra: 1, resina: 1 }, out: 'tocha_resina', n: 1, t: 2 },
  { id: 'cama', tier: 1, st: null, ing: { folha: 8 }, place: 'cama', t: 5 },
  { id: 'abrigo', tier: 1, st: null, ing: { tora: 6, folha: 10, corda_fibra: 4 }, place: 'abrigo', t: 20 },
  { id: 'copo_coco', tier: 1, st: null, ing: { casca_coco: 1, pedrinha: 1 }, out: 'copo_coco', n: 1, t: 3 },
  { id: 'conserto_cantil', tier: 1, st: null, ing: { cantil_quebrado: 1, resina: 1, pano: 1 }, out: 'cantil', n: 1, t: 8, name: 'Consertar cantil' },
  // Fogueira
  { id: 'pote', tier: 2, st: 'fogueira', ing: { argila: 4 }, out: 'pote', n: 1, t: 30 },
  { id: 'cozinhar_peixe', tier: 1, st: 'fogueira', ing: { peixe: 1 }, out: 'peixe_assado', n: 1, t: 10 },
  { id: 'cozinhar_crab', tier: 1, st: 'fogueira', ing: { carne_crab: 1 }, out: 'crab_cozido', n: 1, t: 8 },
  { id: 'cozinhar_ovo', tier: 1, st: 'fogueira', ing: { ovo: 1 }, out: 'ovo_cozido', n: 1, t: 6 },
  { id: 'cozinhar_raiz', tier: 1, st: 'fogueira', ing: { raiz: 1 }, out: 'raiz_assada', n: 1, t: 8 },
  { id: 'carvao', tier: 1, st: 'fogueira', ing: { tora: 1 }, out: 'carvao', n: 2, t: 20 },
  { id: 'ferver', tier: 1, st: 'fogueira', ing: {}, special: 'ferver', t: 15, name: 'Ferver água' },
  // Tier 2 — Básico
  { id: 'corda_cipo', tier: 2, st: null, ing: { cipo: 2 }, out: 'corda_cipo', n: 1, t: 3 },
  { id: 'bancada', tier: 2, st: null, ing: { tora: 6, pedra: 4, corda_cipo: 2 }, place: 'bancada', t: 25 },
  { id: 'machado_silex', tier: 2, st: 'bancada', ing: { tora: 1, silex: 2, corda_cipo: 1 }, out: 'machado_silex', n: 1, t: 8 },
  { id: 'picareta_silex', tier: 2, st: 'bancada', ing: { tora: 1, silex: 3, corda_cipo: 1 }, out: 'picareta_silex', n: 1, t: 8 },
  { id: 'faca_silex', tier: 2, st: 'bancada', ing: { graveto: 1, silex: 1 }, out: 'faca_silex', n: 1, t: 5 },
  { id: 'lanca_pesca', tier: 2, st: 'bancada', ing: { graveto: 2, silex: 1, corda_cipo: 1 }, out: 'lanca_pesca', n: 1, t: 6 },
  { id: 'coletor', tier: 2, st: 'bancada', ing: { tora: 4, folha: 6, pote: 1 }, place: 'coletor', t: 20 },
  { id: 'secador', tier: 2, st: 'bancada', ing: { tora: 4, corda_cipo: 4 }, place: 'secador', t: 15 },
  { id: 'bolsa_pano', tier: 2, st: 'bancada', ing: { pano: 3, corda_fibra: 2 }, up: 'bolsa', t: 10, name: 'Bolsa de pano' },
  { id: 'cinto', tier: 2, st: 'bancada', ing: { fibra: 4, corda_cipo: 1 }, up: 'cinto', t: 6, name: 'Cinto de fibra' },
  { id: 'bandagem', tier: 2, st: 'bancada', ing: { pano: 1 }, out: 'bandagem', n: 1, t: 3 },
  { id: 'bandagem_erva', tier: 2, st: 'bancada', ing: { pano: 1, erva: 1 }, out: 'bandagem_erva', n: 1, t: 3 },
  { id: 'forno', tier: 3, st: 'bancada', ing: { argila: 10, pedra: 8 }, place: 'forno', t: 40 },
  // Tier 3 — Intermediário
  { id: 'lamina', tier: 3, st: 'forno', ing: { obsidiana: 1 }, out: 'lamina', n: 1, t: 10 },
  { id: 'machado_obsidiana', tier: 3, st: 'forno', ing: { tora: 1, lamina: 1, corda_cipo: 1 }, out: 'machado_obsidiana', n: 1, t: 10 },
  { id: 'cantil', tier: 3, st: 'forno', ing: { metal: 1, pano: 2, resina: 1 }, out: 'cantil', n: 1, t: 12 },
  { id: 'mochila', tier: 3, st: 'forno', ing: { pano: 2, corda_cipo: 4, tora: 2 }, up: 'mochila', t: 15, name: 'Mochila' },
  { id: 'bau', tier: 3, st: 'forno', ing: { tora: 10, corda_cipo: 2 }, place: 'bau', t: 20 },
  { id: 'mascara', tier: 3, st: 'forno', ing: { pano: 2, carvao: 1 }, out: 'mascara', n: 1, t: 6 },
  { id: 'sinalizador', tier: 3, st: 'forno', ing: { enxofre: 3, resina: 2, pano: 1, metal: 1 }, out: 'sinalizador', n: 1, t: 20 },
];
const UPGRADES = {
  cinto: { n: 'Cinto de fibra', d: 'Barra rápida 4 → 6' },
  bolsa: { n: 'Bolsa de pano', d: 'Bolsos 8 → 16' },
  mochila: { n: 'Mochila', d: 'Bolsos → 24 e +5 kg de carga' },
};
const STATION_NAME = { fogueira: 'Fogueira', bancada: 'Bancada', forno: 'Forno' };
const TIER_NAME = { 1: 'Tier 1 · Primitivo', 2: 'Tier 2 · Básico', 3: 'Tier 3 · Intermediário' };

// ===== Páginas do diário =====
const PAGES = [
  'Dia 1. Se você está lendo isto, também naufragou. Água primeiro: os cocos da praia matam a sede. Uma pedra abre a casca.',
  'A água do rio é traiçoeira. Fervi num pote de barro e parei de passar mal. O barro? Na lama do leste, no manguezal.',
  'Segui o rio até onde ele nasce. Ali a água brota limpa da pedra. Dá para beber sem ferver.',
  'A lama do mangue prende os pés e as sanguessugas grudam. O calor do fogo as faz soltar. Mas a argila daqui vale o sofrimento.',
  'Na caverna do planalto encontrei uma pedra que corta como faca: sílex. Com cipó trançado montei uma bancada e minhas ferramentas renasceram.',
  'Daqui de cima vi a ilha inteira. Ao norte, a montanha fumega. Lá a rocha é dura demais para pedra comum.',
  'O ar perto do cume queima a garganta. Um pano com carvão no rosto me deixou passar. Precisei de um forno de argila para fazer direito.',
  'Enxofre, resina, pano e metal. Se eu acender isso na praia, alguém verá. Não deu tempo para mim. Que dê para você.',
];
const BIOME_NAME = ['Mar', 'Praia e Recife', 'Floresta Tropical', 'Manguezal', 'Planalto Rochoso', 'Encosta Vulcânica'];
