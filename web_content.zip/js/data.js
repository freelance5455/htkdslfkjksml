/* يمكن هدف؟ — static reference data */
window.YH = window.YH || {};

YH.LEAGUES = [
  { id: 'uefa.champions', ar: 'دوري أبطال أوروبا', short: 'الأبطال', tier: 1 },
  { id: 'eng.1', ar: 'الدوري الإنكليزي الممتاز', short: 'إنكلترا', tier: 1 },
  { id: 'esp.1', ar: 'الدوري الإسباني', short: 'إسبانيا', tier: 1 },
  { id: 'ita.1', ar: 'الدوري الإيطالي', short: 'إيطاليا', tier: 1 },
  { id: 'ger.1', ar: 'الدوري الألماني', short: 'ألمانيا', tier: 1 },
  { id: 'fra.1', ar: 'الدوري الفرنسي', short: 'فرنسا', tier: 1 },
  { id: 'ksa.1', ar: 'دوري روشن السعودي', short: 'السعودية', tier: 2 },
  { id: 'afc.champions', ar: 'دوري أبطال آسيا للنخبة', short: 'آسيا', tier: 2 },
  { id: 'fifa.worldq.afc', ar: 'تصفيات كأس العالم — آسيا', short: 'تصفيات آسيا', tier: 1 },
  { id: 'uefa.europa', ar: 'الدوري الأوروبي', short: 'يوروبا', tier: 2 },
  { id: 'uefa.europa.conf', ar: 'دوري المؤتمر الأوروبي', short: 'المؤتمر', tier: 3 },
  { id: 'uefa.nations', ar: 'دوري الأمم الأوروبية', short: 'الأمم', tier: 2 },
  { id: 'fifa.friendly', ar: 'مباريات دولية ودية', short: 'ودية دولية', tier: 3 },
  { id: 'por.1', ar: 'الدوري البرتغالي', short: 'البرتغال', tier: 3 },
  { id: 'ned.1', ar: 'الدوري الهولندي', short: 'هولندا', tier: 3 },
  { id: 'eng.fa', ar: 'كأس الاتحاد الإنكليزي', short: 'كأس إنكلترا', tier: 3 },
  { id: 'esp.copa_del_rey', ar: 'كأس ملك إسبانيا', short: 'كأس الملك', tier: 3 },
];
YH.LEAGUE_BY_ID = Object.fromEntries(YH.LEAGUES.map(l => [l.id, l]));
YH.TABLE_LEAGUES = ['eng.1', 'esp.1', 'ita.1', 'ger.1', 'fra.1', 'ksa.1', 'por.1', 'ned.1'];

/* Arabic names for well-known teams (fallback: original name) */
YH.TEAM_AR = {
  'Arsenal': 'آرسنال', 'Chelsea': 'تشيلسي', 'Liverpool': 'ليفربول', 'Manchester City': 'مانشستر سيتي',
  'Manchester United': 'مانشستر يونايتد', 'Tottenham Hotspur': 'توتنهام', 'Newcastle United': 'نيوكاسل',
  'Aston Villa': 'أستون فيلا', 'Brighton & Hove Albion': 'برايتون', 'West Ham United': 'وست هام',
  'Crystal Palace': 'كريستال بالاس', 'Everton': 'إيفرتون', 'Fulham': 'فولهام', 'Brentford': 'برينتفورد',
  'Wolverhampton Wanderers': 'وولفرهامبتون', 'AFC Bournemouth': 'بورنموث', 'Nottingham Forest': 'نوتنغهام فورست',
  'Sunderland': 'سندرلاند', 'Leeds United': 'ليدز يونايتد', 'Burnley': 'بيرنلي', 'Ipswich Town': 'إيبسويتش',
  'Leicester City': 'ليستر سيتي', 'Southampton': 'ساوثهامبتون',
  'Real Madrid': 'ريال مدريد', 'Barcelona': 'برشلونة', 'Atlético Madrid': 'أتلتيكو مدريد', 'Sevilla': 'إشبيلية',
  'Real Sociedad': 'ريال سوسيداد', 'Villarreal': 'فياريال', 'Real Betis': 'ريال بيتيس', 'Athletic Club': 'أتلتيك بلباو',
  'Valencia': 'فالنسيا', 'Girona': 'جيرونا', 'Celta Vigo': 'سيلتا فيغو', 'Osasuna': 'أوساسونا', 'Getafe': 'خيتافي',
  'Mallorca': 'مايوركا', 'Rayo Vallecano': 'رايو فاييكانو', 'Espanyol': 'إسبانيول', 'Alavés': 'ألافيس',
  'Juventus': 'يوفنتوس', 'Internazionale': 'إنتر ميلان', 'AC Milan': 'ميلان', 'Napoli': 'نابولي', 'AS Roma': 'روما',
  'Lazio': 'لاتسيو', 'Atalanta': 'أتالانتا', 'Fiorentina': 'فيورنتينا', 'Bologna': 'بولونيا', 'Torino': 'تورينو', 'Como': 'كومو',
  'Bayern Munich': 'بايرن ميونخ', 'Borussia Dortmund': 'بوروسيا دورتموند', 'Bayer Leverkusen': 'باير ليفركوزن',
  'RB Leipzig': 'لايبزيغ', 'Eintracht Frankfurt': 'آينتراخت فرانكفورت', 'VfB Stuttgart': 'شتوتغارت',
  'Borussia Mönchengladbach': 'مونشنغلادباخ', 'VfL Wolfsburg': 'فولفسبورغ', 'SC Freiburg': 'فرايبورغ',
  'Paris Saint-Germain': 'باريس سان جيرمان', 'Marseille': 'مرسيليا', 'Lyon': 'ليون', 'AS Monaco': 'موناكو',
  'Lille': 'ليل', 'Nice': 'نيس', 'Lens': 'لانس', 'Rennes': 'رين', 'Stade Rennais': 'رين',
  'Al Hilal': 'الهلال', 'Al-Hilal': 'الهلال', 'Al Nassr': 'النصر', 'Al-Nassr': 'النصر', 'Al Ittihad': 'الاتحاد', 'Al-Ittihad': 'الاتحاد',
  'Al Ahli': 'الأهلي', 'Al-Ahli': 'الأهلي', 'Al Qadsiah': 'القادسية', 'Al Shabab': 'الشباب', 'Al Ettifaq': 'الاتفاق',
  'Al Taawoun': 'التعاون', 'Al Fateh': 'الفتح', 'Al Khaleej': 'الخليج', 'Al Fayha': 'الفيحاء',
  'Al Sadd': 'السد', 'Al Duhail': 'الدحيل', 'Al Ain': 'العين', 'Al Wahda': 'الوحدة', 'Shabab Al Ahli': 'شباب الأهلي',
  'Al Shorta': 'الشرطة', 'Al-Shorta': 'الشرطة', 'Al Zawraa': 'الزوراء', 'Al Quwa Al Jawiya': 'القوة الجوية',
  'Benfica': 'بنفيكا', 'Porto': 'بورتو', 'FC Porto': 'بورتو', 'Sporting CP': 'سبورتينغ لشبونة',
  'Ajax': 'أياكس', 'PSV Eindhoven': 'آيندهوفن', 'Feyenoord': 'فينورد', 'Celtic': 'سلتيك', 'Galatasaray': 'غلطة سراي',
  'Fenerbahce': 'فنربخشة', 'Club Brugge': 'كلوب بروج',
  'Iraq': 'العراق', 'Saudi Arabia': 'السعودية', 'Jordan': 'الأردن', 'Qatar': 'قطر', 'United Arab Emirates': 'الإمارات',
  'Oman': 'عُمان', 'Kuwait': 'الكويت', 'Bahrain': 'البحرين', 'Syria': 'سوريا', 'Lebanon': 'لبنان', 'Palestine': 'فلسطين',
  'Egypt': 'مصر', 'Morocco': 'المغرب', 'Algeria': 'الجزائر', 'Tunisia': 'تونس', 'Iran': 'إيران', 'Japan': 'اليابان',
  'South Korea': 'كوريا الجنوبية', 'Australia': 'أستراليا', 'Uzbekistan': 'أوزبكستان', 'China PR': 'الصين',
  'Argentina': 'الأرجنتين', 'Brazil': 'البرازيل', 'France': 'فرنسا', 'Spain': 'إسبانيا', 'England': 'إنكلترا',
  'Germany': 'ألمانيا', 'Portugal': 'البرتغال', 'Italy': 'إيطاليا', 'Netherlands': 'هولندا', 'Belgium': 'بلجيكا',
  'Croatia': 'كرواتيا', 'United States': 'الولايات المتحدة', 'Mexico': 'المكسيك', 'Uruguay': 'الأوروغواي', 'Colombia': 'كولومبيا',
};

YH.STAT_AR = {
  possessionPct: 'الاستحواذ %', totalShots: 'التسديدات', shotsOnTarget: 'على المرمى', wonCorners: 'الركنيات',
  foulsCommitted: 'الأخطاء', yellowCards: 'بطاقات صفراء', redCards: 'بطاقات حمراء', offsides: 'تسلل', saves: 'تصديات',
  accuratePasses: 'تمريرات صحيحة', totalPasses: 'التمريرات', passPct: 'دقة التمرير', totalCrosses: 'العرضيات',
  totalLongBalls: 'الكرات الطويلة', blockedShots: 'تسديدات محجوبة', totalTackles: 'الافتكاك', interceptions: 'اعتراضات',
  totalClearance: 'إبعادات', effectiveTackles: 'افتكاك ناجح',
};
YH.STAT_ORDER = ['possessionPct', 'totalShots', 'shotsOnTarget', 'wonCorners', 'accuratePasses', 'passPct', 'totalCrosses',
  'totalLongBalls', 'totalTackles', 'interceptions', 'saves', 'foulsCommitted', 'offsides', 'yellowCards', 'redCards'];

YH.POS_AR = { G: 'حارس', D: 'مدافع', M: 'وسط', F: 'مهاجم', SUB: 'بديل' };

YH.BROADCAST_MENA = [
  { name: 'beIN SPORTS', note: 'الناقل الرسمي لمعظم الدوريات الأوروبية ودوري الأبطال في الشرق الأوسط وشمال أفريقيا', url: 'https://www.beinsports.com/ar-mena/' },
  { name: 'TOD', note: 'منصة البث الرسمية التابعة لـ beIN — مشاهدة قانونية على الهاتف والتلفاز', url: 'https://www.tod.tv/' },
  { name: 'Shahid / SSC', note: 'الناقل الرسمي لدوري روشن السعودي وبطولات سعودية', url: 'https://shahid.mbc.net/' },
  { name: 'الرابعة الرياضية (IMN)', note: 'القناة العراقية الرسمية — مباريات المنتخب ودوري نجوم العراق حسب الحقوق', url: 'https://www.imn.iq/' },
];
