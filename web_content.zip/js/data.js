'use strict';
const $=id=>document.getElementById(id);
const rnd=(a,b)=>a+Math.random()*(b-a),clamp=(v,a,b)=>v<a?a:v>b?b:v,lerp=(a,b,t)=>a+(b-a)*t,TAU=Math.PI*2;
const pick=a=>a[Math.floor(Math.random()*a.length)];
const h=(tag,props,...kids)=>{const e=document.createElement(tag);if(props)for(const k in props){if(k==='class')e.className=props[k];else if(k==='style')e.style.cssText=props[k];else if(k.startsWith('on'))e[k]=props[k];else e.setAttribute(k,props[k])}for(const c of kids.flat()){if(c==null||c===false)continue;e.append(c.nodeType?c:document.createTextNode(c))}return e};
const isTouch=matchMedia('(pointer:coarse)').matches||'ontouchstart' in window;

const RAR=[['कॉमन','#cfd6c8'],['अनकॉमन','#7bd88f'],['रेयर','#6fb7ff'],['एपिक','#d98cff'],['लेजेंडरी','#ffb347']];

/* ---- outfits ---- */
function O(id,n,r,c,p,o){return Object.assign({id,n,r,c,p,cat:'o'},o)}
const OUT=[
O('o0','सिटी रनर',0,'g',0,{skin:'#e3b08a',top:'#3d73b5',top2:'#e9eef2',pants:'#2c3140',shoes:'#eeeeee',hair:'#1b1b1b',hat:'cap',hatc:'#c24a3a'}),
O('o1','स्ट्रीट नाइट',1,'g',300,{skin:'#c68b63',top:'#1f1f27',top2:'#ff5d6c',pants:'#2a2a33',shoes:'#ff5d6c',hair:'#111',hat:'hood',hatc:'#1f1f27',mask:'plain'}),
O('o2','डेज़र्ट नोमैड',1,'g',350,{skin:'#b97c50',top:'#d6b27a',top2:'#8a5a2b',pants:'#6d4c2a',shoes:'#4b3320',hair:'#2a1a10',hat:'wrap',hatc:'#e9dcc0'}),
O('o3','आइस वॉकर',1,'g',350,{skin:'#f0c9a8',top:'#8fc7e8',top2:'#ffffff',pants:'#3b5a7a',shoes:'#dfe9f2',hair:'#caa86a',hat:'beanie',hatc:'#ffffff'}),
O('o4','जंगल स्काउट',0,'g',250,{skin:'#d19a70',top:'#4d7a3e',top2:'#2f4f27',pants:'#5a4a30',shoes:'#3a2e20',hair:'#3a2415',hat:'cap',hatc:'#2f4f27'}),
O('o5','नियॉन घोस्ट',3,'d',120,{skin:'#e0b79a',top:'#1a1230',top2:'#2dffd0',pants:'#1a1230',shoes:'#2dffd0',hair:'#2dffd0',hat:'hood',hatc:'#1a1230',mask:'visor',glow:'#2dffd0'}),
O('o6','गोल्डन किंग',4,'d',300,{skin:'#d8a37a',top:'#f0b429',top2:'#7a4a00',pants:'#2a1a05',shoes:'#f0b429',hair:'#1a1a1a',hat:'crown',hatc:'#ffd35c',glass:true,glow:'#ffd35c'}),
O('o7','रेड बैंडिट',2,'g',600,{skin:'#c68b63',top:'#b3262f',top2:'#2a2a2a',pants:'#2a2a2a',shoes:'#111111',hair:'#111111',hat:'bandana',hatc:'#b3262f',mask:'bandit'}),
O('o8','ओशन डाइवर',2,'g',650,{skin:'#e3b08a',top:'#1e6fa3',top2:'#f5c518',pants:'#134766',shoes:'#f5c518',hair:'#1b1b1b',hat:'helmet',hatc:'#f5c518',glass:true}),
O('o9','कैमो सोल्जर',1,'g',400,{skin:'#c68b63',top:'#6b7d4a',top2:'#4a5a33',pants:'#566339',shoes:'#2f2a22',hair:'#222222',hat:'helmet',hatc:'#5a6b3c'}),
O('o10','स्पेस पायलट',3,'d',140,{skin:'#e3b08a',top:'#e8eef5',top2:'#ff7a3d',pants:'#c8d2de',shoes:'#ff7a3d',hair:'#1b1b1b',hat:'helmet',hatc:'#e8eef5',glass:true}),
O('o11','समुराई सन',3,'d',150,{skin:'#dba982',top:'#7a1f2b',top2:'#e6c26a',pants:'#1c1c24',shoes:'#1c1c24',hair:'#0f0f0f',hat:'topknot',hatc:'#0f0f0f'}),
O('o12','देसी स्टार',2,'g',700,{skin:'#c88f65',top:'#f2a900',top2:'#d1342f',pants:'#f2ede0',shoes:'#c23a2a',hair:'#171717',hat:'wrap',hatc:'#d1342f'}),
O('o13','शैडो निंजा',3,'d',130,{skin:'#d9a67e',top:'#15151b',top2:'#6a2bd6',pants:'#15151b',shoes:'#15151b',hair:'#111111',hat:'wrap',hatc:'#15151b',mask:'ninja'}),
O('o14','फ्लेम चैंपियन',4,'d',280,{skin:'#e0ad86',top:'#2a1410',top2:'#ff6a1a',pants:'#2a1410',shoes:'#ff6a1a',hair:'#ff6a1a',hat:'none',glow:'#ff6a1a',mask:'plain'}),
O('o15','क्रिस्टल क्वीन',4,'d',300,{skin:'#f1cfb2',top:'#c9a7ff',top2:'#ffffff',pants:'#5a3fa0',shoes:'#ffffff',hair:'#f4d6ff',hat:'crown',hatc:'#e6d4ff',glow:'#c9a7ff'})
];
const mk=(cat,a)=>({id:a[0],n:a[1],r:a[2],c:a[3],p:a[4],col:a[5],extra:a[6]||'',cat});
const WSK=[['w0','स्टैंडर्ड',0,'g',0,null],['w1','नियॉन ग्रीन',1,'g',200,'#39ff88'],['w2','रूबी रेड',1,'g',250,'#ff3b57'],['w3','आर्कटिक',2,'g',500,'#9fe7ff'],['w4','कैमो',1,'g',300,'#7d8f55'],['w5','वॉइड पर्पल',3,'d',90,'#a66bff'],['w6','फ्लेम',3,'d',110,'#ff7a1a'],['w7','क्रोम',2,'g',600,'#e8eef5'],['w8','कैंडी',2,'g',550,'#ff8fd1'],['w9','गोल्ड',4,'d',250,'#ffd35c']].map(a=>mk('w',a));
const GSK=[['g0','आइस',0,'g',0,'#8fd8ff'],['g1','लावा',2,'g',400,'#ff7a3d'],['g2','नियॉन',2,'g',450,'#39ffb0'],['g3','गोल्ड',4,'d',200,'#ffd35c'],['g4','स्लाइम',1,'g',300,'#9be85a'],['g5','वॉइड',3,'d',100,'#a66bff'],['g6','कैंडी',2,'g',500,'#ff9bd8'],['g7','मैट्रिक्स',3,'d',110,'#2dff7a']].map(a=>mk('g',a));
const PETS=[['p0','फॉक्सी',1,'g',500,'fox','+8% स्पीड','spd'],['p1','उल्लू',2,'g',800,'owl','रडार: पास के दुश्मन मिनी-मैप पर दिखते हैं','radar'],['p2','पांडा',2,'g',700,'panda','मैच की शुरुआत में +40 आर्मर','arm'],['p3','रोबो',3,'d',100,'robo','धीरे-धीरे हेल्थ वापस आती है','regen'],['p4','फाल्को',3,'d',110,'falcon','+60 एक्स्ट्रा गोलियाँ','ammo'],['p5','किटी',1,'g',450,'kitty','बैंडेज और मेडकिट 20% ज़्यादा हील करते हैं','heal']].map(a=>({id:a[0],n:a[1],r:a[2],c:a[3],p:a[4],kind:a[5],extra:a[6],perk:a[7],cat:'p'}));
const ITEMS={};[...OUT,...WSK,...GSK,...PETS].forEach(i=>ITEMS[i.id]=i);
const CATN={o:'आउटफ़िट',w:'हथियार स्किन',g:'ग्लू वॉल',p:'पेट'};

/* ---- weapons ---- */
function WPN(n,cls,tier,dmg,rate,sp,spr,range,pel,mag,rl,col,len,pref,snd){return{n,cls,tier,dmg,rate,sp,spr,range,pel,mag,rl,col,len,pref,snd}}
const WP={
pistol:WPN('P-9 पिस्तौल','pistol',0,16,.3,780,.04,480,1,12,1.1,'#d4dacb',13,200,'pistol'),
revolver:WPN('डेज़र्ट रिवॉल्वर','pistol',1,40,.62,860,.025,560,1,6,1.8,'#e0c27a',15,260,'pistol'),
hornet:WPN('हॉर्नेट SMG','smg',1,9,.075,820,.14,420,1,30,1.5,'#7bd88f',19,190,'smg'),
swift:WPN('स्विफ्ट SMG','smg',2,11,.09,840,.11,450,1,35,1.6,'#5fe0a8',20,210,'smg'),
ranger:WPN('रेंजर AR','ar',2,16,.12,950,.06,640,1,30,1.9,'#6fb7ff',25,290,'ar'),
falcon:WPN('फाल्कन AR','ar',3,19,.14,1000,.05,700,1,30,2.0,'#8fa8ff',26,320,'ar'),
titan:WPN('टाइटन AR','ar',4,25,.17,1050,.045,740,1,25,2.3,'#d98cff',27,330,'ar'),
hammer:WPN('हैमर LMG','lmg',3,15,.09,930,.1,600,1,80,3.6,'#ffb347',29,280,'ar'),
pump:WPN('बूमर पंप','sg',2,12,.85,760,.26,320,7,5,2.2,'#ffb347',22,110,'sg'),
auto12:WPN('ऑटो-12 शॉटगन','sg',3,9,.28,780,.24,340,6,8,2.4,'#ff8a5c',23,130,'sg'),
hawk:WPN('हॉक बोल्ट स्नाइपर','sn',4,92,1.4,1800,.006,1200,1,5,2.6,'#d98cff',32,520,'sn'),
dmr:WPN('मार्कस्मैन DMR','sn',3,42,.45,1400,.015,900,1,10,2.2,'#6fb7ff',29,420,'ar'),
xbow:WPN('साइलेंट क्रॉसबो','xb',2,60,1.0,900,.01,600,1,1,1.6,'#c8b07a',20,300,'xb')
};
const WKEYS=Object.keys(WP);

/* ---- maps ---- */
function M(n,loc,size,o){return Object.assign({n,loc,size,det:'grass',wat:'#4a8ea8',sh:'#bda878',fl:'#b79868',wl:['#a58562','#7d6448'],rf:'#b5502e',tr:'oak',td:1,lk:3,lkr:1,wx:'clear',hd:1,urb:0,night:0,tint:'',path:'rgba(150,128,86,.5)',g:['#5a7d3f','#6b8f45','#47693a']},o)}
const MAPS=[
M('भारत के मैदान','उत्तर प्रदेश, भारत',4800,{g:['#5f8442','#74964a','#4a6d3a'],lk:4}),
M('थार रेगिस्तान','राजस्थान, भारत',5600,{det:'sand',g:['#d2b074','#e0c488','#bf9a5c'],wat:'#4a9bb0',sh:'#f0e0b0',fl:'#a88a5c',wl:['#b89a6a','#947850'],rf:'#c9a46a',tr:'cactus',td:.45,lk:1,wx:'sand',hd:.9,path:'rgba(160,120,70,.45)'}),
M('हिमालय','नेपाल-तिब्बत',5200,{det:'snow',g:['#e4ebf1','#cfdbe5','#f3f7fa'],wat:'#6fa8c4',sh:'#dbe6ee',fl:'#a38c6c',wl:['#8a7a68','#6b5d4e'],rf:'#4f5f70',tr:'pine',td:.9,wx:'snow',hd:.8,path:'rgba(120,130,140,.4)'}),
M('केरल बैकवॉटर','केरल, भारत',4400,{g:['#3f7f4b','#4f9558','#2f6a3d'],wat:'#3f8f8a',sh:'#c9bd8a',tr:'palm',td:1.3,lk:9,lkr:1.3,wx:'rain',rf:'#a63e2c',fl:'#b09a70'}),
M('अमेज़न जंगल','ब्राज़ील',6200,{g:['#2f5c35','#3d7342','#244a2b'],td:2.4,lk:5,wx:'mist',hd:.5,wat:'#4a7a5a',rf:'#6b4a2e',wl:['#7a5a3a','#5a4028'],fl:'#8a7050',tint:'rgba(20,60,30,.12)'}),
M('सहारा','उत्तरी अफ्रीका',6400,{det:'sand',g:['#dcbc7e','#ead09a','#c8a468'],tr:'dead',td:.25,lk:1,wx:'sand',hd:.7,sh:'#f2e4b8',fl:'#b09468',wl:['#c4a878','#9a8058'],rf:'#b89a68',tint:'rgba(255,170,60,.1)'}),
M('साइबेरिया टुंड्रा','रूस',6000,{det:'snow',g:['#cfd9e1','#bccad6','#e1e9ef'],tr:'pine',td:1.2,lk:4,wx:'blizzard',hd:.7,wat:'#8fb7cf',sh:'#e2ebf2',fl:'#8f7a60',wl:['#7a6a58','#5c5044'],rf:'#455564'}),
M('आल्प्स घाटी','स्विट्ज़रलैंड',4600,{g:['#6f9d56','#82b062','#5a8745'],tr:'pine',td:1.3,wx:'clear',rf:'#6a3f2a',wl:['#c9b08a','#a38a68'],wat:'#4a97b8'}),
M('सुंदरबन','भारत-बांग्लादेश',4800,{g:['#4b6b3a','#5c7d45','#3b5a2f'],wat:'#4f7a62',lk:10,lkr:1.2,td:1.5,wx:'mist',rf:'#7a5a3a',fl:'#8a7550'}),
M('टोक्यो नाइट','जापान',4200,{det:'asph',urb:1,night:1,g:['#2b3042','#343a50','#232838'],wat:'#2a4a6a',sh:'#444a5e',fl:'#4a4f66',wl:['#3b4262','#2b3150'],rf:'#222638',td:.2,lk:2,wx:'rain',hd:1.3,path:'rgba(70,80,110,.7)',tint:'rgba(80,60,200,.1)'}),
M('न्यूयॉर्क ब्लॉक्स','अमेरिका',4600,{det:'asph',urb:1,g:['#5d6168','#6b7078','#505459'],wat:'#4f7f9c',sh:'#8a8f96',fl:'#7a7f86',wl:['#8d9299','#6a6f76'],rf:'#4a4e55',td:.25,lk:2,hd:1.4,path:'rgba(40,44,50,.75)'}),
M('दुबई','संयुक्त अरब अमीरात',5400,{det:'sand',urb:1,g:['#d6bb84','#e4cb98','#c4a56c'],wat:'#3fa0b8',sh:'#f0e2b8',fl:'#cfc0a0',wl:['#e6dcc6','#bdb094'],rf:'#a8c4d4',tr:'palm',td:.4,wx:'sand',path:'rgba(120,110,90,.5)'}),
M('आइसलैंड लावा','आइसलैंड',5000,{det:'lava',g:['#2d2b30','#3a373d','#222025'],wat:'#2f6b86',sh:'#45424a',fl:'#4a4549',wl:['#4e4a52','#38353c'],rf:'#2b292e',tr:'dead',td:.35,wx:'ash',hd:.7,path:'rgba(90,70,60,.5)'}),
M('ऑस्ट्रेलियन आउटबैक','ऑस्ट्रेलिया',5800,{det:'sand',g:['#b4592f','#c46a3c','#9d4a26'],tr:'dead',td:.5,lk:1,sh:'#d8a070',wat:'#5aa0a8',fl:'#a07050',wl:['#a86a48','#845038'],rf:'#7a3a28',hd:.8}),
M('बोर्नियो वर्षावन','इंडोनेशिया',5200,{g:['#2b6b3a','#38804a','#215a30'],tr:'palm',td:2,lk:4,wx:'rain',hd:.6,wat:'#3f8a7a',rf:'#6a4a2e',fl:'#8a7050'}),
M('अफ्रीकन सवाना','केन्या',6000,{g:['#a99a4a','#bcad5a','#948638'],tr:'acacia',td:.6,hd:.7,rf:'#8a5a30',wl:['#b89868','#8f7448'],fl:'#a88a58',tint:'rgba(255,190,80,.08)'}),
M('आर्कटिक स्टेशन','आर्कटिक',4600,{det:'snow',urb:1,g:['#e8eff5','#d4e0ea','#f5f9fc'],wat:'#8fd0e6',sh:'#f1f6fa',fl:'#9aa8b4',wl:['#c9d4de','#9ba8b4'],rf:'#d44a3a',tr:'pine',td:.4,lk:4,wx:'snow',hd:.6}),
M('भूमध्य तट','ग्रीस',4600,{g:['#8ca35c','#9db46a','#7a914c'],wat:'#2f80b8',sh:'#efe3c0',lk:8,lkr:1.6,td:.8,rf:'#2f6fb3',wl:['#f1ede4','#cfc9bc'],fl:'#d8cdb8',hd:1.1}),
M('रॉकी कैन्यन','अमेरिका',5600,{det:'rock',g:['#8a6a55','#9c7a62','#755840'],tr:'pine',td:.8,lk:2,sh:'#c0a078',fl:'#a08060',wl:['#8a7058','#6a5440'],rf:'#5a4030',hd:.8}),
M('मालदीव द्वीप','मालदीव',4000,{det:'sand',g:['#ead9a8','#f2e6bc','#dcc890'],wat:'#2fb0c8',sh:'#f7edc8',lk:15,lkr:1.5,tr:'palm',td:1.1,rf:'#d8c8a0',wl:['#efe6d0','#cfc4aa'],fl:'#e0d4b0',hd:.9})
];
const MODES=[{id:'solo',n:'सोलो क्लासिक',d:'50 खिलाड़ी · हर कोई अकेला',cnt:50,team:1,k:1},{id:'squad',n:'स्क्वाड',d:'12 टीमें · 3 बॉट टीममेट साथ',cnt:48,team:4,k:1},{id:'fast',n:'फ़ास्ट',d:'20 खिलाड़ी · तेज़ ज़ोन',cnt:20,team:1,k:.5}];
const NAMES=['Raju','Vicky','Shadow','Aarav','Ninja_X','Kabir','Rocky','Zoya','Veer','Tiger','Maya','Dev','Ghost','Rudra','Simran','Bholu','Neel','Sher','Pihu','Kala','Jinx','Omkar','Tara','Bunty','Rehan','Ishu','Mintu','Pappu','Sonu','Dabbu','Aryan','Kiara','Lucky','Nitro','Hawk','Rani','Zed','Monu','Pankaj','Gudiya','Titan','Blaze','Chintu','Sultan','Anaya','Bittu','Rafa','Yash','Viper','Cobra'];
const PHT=[{w:50,s:35,dmg:1.5,f:.30},{w:40,s:30,dmg:3,f:.19},{w:35,s:26,dmg:6,f:.11},{w:30,s:22,dmg:10,f:.06},{w:25,s:18,dmg:16,f:.025}];

/* ---- royale pass ---- */
const PASS=[];for(let i=1;i<=30;i++){
  const free=i%10===0?{t:'item',v:['g1','w1','o1'][i/10-1]}:(i%5===0?{t:'gems',v:10}:{t:'gold',v:60+i*8});
  const prem=i%6===0?{t:'item',v:['o3','w3','p2','g2','o8'][i/6-1]}:(i%3===0?{t:'gems',v:15}:{t:'gold',v:120+i*10});
  PASS.push({l:i,free,prem});
}

/* ---- profile & settings ---- */
const KEY='lastring_v2';
const DEF={prof:{gold:600,gems:60,owned:{o0:1,w0:1,g0:1},eq:{o:'o0',w:'w0',g:'g0',p:''},xp:0,pass:{prem:false,cl:{}},daily:'',name:'Player',crates:{},st:{m:0,w:0,k:0},map:0,mode:'solo',spin:'',col:{},ch:'alok'},
  set:{autopick:false,gfx:'',aim:1,fsens:1,joy:1,btn:1,assist:true,autoFire:false,aimRadius:400,dragFire:'release',contFire:false,show:'auto',vol:.7,zoom:1,float:true}};
let prof,set;
function load(){
  let d=null;try{d=JSON.parse(localStorage.getItem(KEY))}catch(e){}
  prof=Object.assign({},DEF.prof,d&&d.prof);
  for(const k of ['owned','eq','pass','st','crates','col'])prof[k]=Object.assign({},DEF.prof[k],prof[k]);
  set=Object.assign({},DEF.set,d&&d.set);
  if(!set.gfx)set.gfx=isTouch?'med':'high';
}
function save(){try{localStorage.setItem(KEY,JSON.stringify({prof,set}))}catch(e){}}
load();
const GFX={low:{tex:1000,dpr:1,shadow:0,wx:.35,fx:0,night:0,tuft:0,glow:0},med:{tex:1400,dpr:1,shadow:1,wx:.6,fx:0,night:1,tuft:.6,glow:0},high:{tex:2000,dpr:2,shadow:1,wx:1,fx:1,night:2,tuft:1,glow:1},ultra:{tex:2600,dpr:2,shadow:2,wx:1.4,fx:2,night:2,tuft:1.6,glow:2}};
const QL=()=>GFX[set.gfx]||GFX.med;
const level=()=>1+Math.floor(prof.xp/100);
