/* Static, language-neutral reference data bundled with the app (no network needed).
   Emergency numbers and coordinates are reference data: verify before travel. */
(function (EP) {
  const C = (cur, langs, em) => ({ cur, langs, em });
  EP.countries = {
    FR: C('EUR', ['fr'], { general: '112', police: '17', ambulance: '15', fire: '18' }),
    IT: C('EUR', ['it'], { general: '112', police: '113', ambulance: '118', fire: '115' }),
    ES: C('EUR', ['es'], { general: '112' }),
    DE: C('EUR', ['de'], { general: '112', police: '110', ambulance: '112', fire: '112' }),
    AT: C('EUR', ['de'], { general: '112', police: '133', ambulance: '144', fire: '122' }),
    CH: C('CHF', ['de', 'fr', 'it'], { general: '112', police: '117', ambulance: '144', fire: '118' }),
    NL: C('EUR', ['nl'], { general: '112' }),
    BE: C('EUR', ['nl', 'fr', 'de'], { general: '112', police: '101', ambulance: '100', fire: '100' }),
    PT: C('EUR', ['pt'], { general: '112' }),
    GB: C('GBP', ['en'], { general: '999', police: '999', ambulance: '999', fire: '999' }),
    IE: C('EUR', ['en', 'ga'], { general: '112', police: '999', ambulance: '999', fire: '999' }),
    CZ: C('CZK', ['cs'], { general: '112', police: '158', ambulance: '155', fire: '150' }),
    HU: C('HUF', ['hu'], { general: '112', police: '107', ambulance: '104', fire: '105' }),
    PL: C('PLN', ['pl'], { general: '112', police: '997', ambulance: '999', fire: '998' }),
    GR: C('EUR', ['el'], { general: '112', police: '100', ambulance: '166', fire: '199' }),
    DK: C('DKK', ['da'], { general: '112' }),
    SE: C('SEK', ['sv'], { general: '112' }),
    NO: C('NOK', ['nb'], { general: '112', police: '112', ambulance: '113', fire: '110' })
  };

  // n: names per UI language (en is the fallback). hl: landmark proper nouns (not translated).
  const city = (id, cc, lat, lon, tz, n, hl) => ({ id, cc, lat, lon, tz, n, hl });
  EP.cities = [
    city('paris', 'FR', 48.8566, 2.3522, 'Europe/Paris', { en: 'Paris', es: 'París', it: 'Parigi', fa: 'پاریس', ar: 'باريس' }, ['Eiffel Tower', 'Louvre Museum', 'Montmartre', 'Notre-Dame']),
    city('lyon', 'FR', 45.7640, 4.8357, 'Europe/Paris', { en: 'Lyon', fa: 'لیون', ar: 'ليون' }, ['Vieux Lyon', 'Fourvière Basilica', 'Les Halles de Lyon – Paul Bocuse']),
    city('nice', 'FR', 43.7102, 7.2620, 'Europe/Paris', { en: 'Nice', fa: 'نیس', ar: 'نيس' }, ['Promenade des Anglais', 'Old Town (Vieux-Nice)', 'Castle Hill']),
    city('rome', 'IT', 41.9028, 12.4964, 'Europe/Rome', { en: 'Rome', fr: 'Rome', de: 'Rom', es: 'Roma', it: 'Roma', fa: 'رم', ar: 'روما' }, ['Colosseum', 'Roman Forum', 'Vatican Museums', 'Trevi Fountain']),
    city('florence', 'IT', 43.7696, 11.2558, 'Europe/Rome', { en: 'Florence', fr: 'Florence', de: 'Florenz', es: 'Florencia', it: 'Firenze', fa: 'فلورانس', ar: 'فلورنسا' }, ['Uffizi Gallery', 'Duomo (Santa Maria del Fiore)', 'Ponte Vecchio']),
    city('venice', 'IT', 45.4408, 12.3155, 'Europe/Rome', { en: 'Venice', fr: 'Venise', de: 'Venedig', es: 'Venecia', it: 'Venezia', fa: 'ونیز', ar: 'البندقية' }, ["St Mark's Square", 'Grand Canal', 'Rialto Bridge']),
    city('milan', 'IT', 45.4642, 9.1900, 'Europe/Rome', { en: 'Milan', de: 'Mailand', es: 'Milán', it: 'Milano', fa: 'میلان', ar: 'ميلانو' }, ['Duomo di Milano', 'Galleria Vittorio Emanuele II', 'Sforza Castle']),
    city('barcelona', 'ES', 41.3874, 2.1686, 'Europe/Madrid', { en: 'Barcelona', fr: 'Barcelone', it: 'Barcellona', fa: 'بارسلون', ar: 'برشلونة' }, ['Sagrada Família', 'Park Güell', 'Gothic Quarter']),
    city('madrid', 'ES', 40.4168, -3.7038, 'Europe/Madrid', { en: 'Madrid', fa: 'مادرید', ar: 'مدريد' }, ['Prado Museum', 'Retiro Park', 'Royal Palace']),
    city('seville', 'ES', 37.3891, -5.9845, 'Europe/Madrid', { en: 'Seville', fr: 'Séville', de: 'Sevilla', es: 'Sevilla', it: 'Siviglia', fa: 'سویل', ar: 'إشبيلية' }, ['Alcázar of Seville', 'Seville Cathedral', 'Plaza de España']),
    city('berlin', 'DE', 52.5200, 13.4050, 'Europe/Berlin', { en: 'Berlin', fa: 'برلین', ar: 'برلين' }, ['Brandenburg Gate', 'Museum Island', 'Reichstag Building']),
    city('munich', 'DE', 48.1351, 11.5820, 'Europe/Berlin', { en: 'Munich', de: 'München', es: 'Múnich', it: 'Monaco di Baviera', fa: 'مونیخ', ar: 'ميونخ' }, ['Marienplatz', 'English Garden', 'Nymphenburg Palace']),
    city('vienna', 'AT', 48.2082, 16.3738, 'Europe/Vienna', { en: 'Vienna', fr: 'Vienne', de: 'Wien', es: 'Viena', it: 'Vienna', fa: 'وین', ar: 'فيينا' }, ['Schönbrunn Palace', "St. Stephen's Cathedral", 'Belvedere']),
    city('zurich', 'CH', 47.3769, 8.5417, 'Europe/Zurich', { en: 'Zurich', fr: 'Zurich', de: 'Zürich', es: 'Zúrich', it: 'Zurigo', fa: 'زوریخ', ar: 'زيورخ' }, ['Old Town (Altstadt)', 'Lake Zurich', 'Grossmünster']),
    city('amsterdam', 'NL', 52.3676, 4.9041, 'Europe/Amsterdam', { en: 'Amsterdam', fa: 'آمستردام', ar: 'أمستردام' }, ['Rijksmuseum', 'Van Gogh Museum', 'Canal Ring']),
    city('brussels', 'BE', 50.8503, 4.3517, 'Europe/Brussels', { en: 'Brussels', fr: 'Bruxelles', de: 'Brüssel', es: 'Bruselas', it: 'Bruxelles', fa: 'بروکسل', ar: 'بروكسل' }, ['Grand-Place', 'Atomium', 'Manneken Pis']),
    city('lisbon', 'PT', 38.7223, -9.1393, 'Europe/Lisbon', { en: 'Lisbon', fr: 'Lisbonne', de: 'Lissabon', es: 'Lisboa', it: 'Lisbona', fa: 'لیسبون', ar: 'لشبونة' }, ['Belém Tower', 'Alfama', 'Jerónimos Monastery']),
    city('porto', 'PT', 41.1579, -8.6291, 'Europe/Lisbon', { en: 'Porto', es: 'Oporto', it: 'Oporto', fa: 'پورتو', ar: 'بورتو' }, ['Ribeira', 'Livraria Lello', 'Dom Luís I Bridge']),
    city('london', 'GB', 51.5074, -0.1278, 'Europe/London', { en: 'London', fr: 'Londres', es: 'Londres', it: 'Londra', fa: 'لندن', ar: 'لندن' }, ['Tower of London', 'British Museum', 'Westminster']),
    city('edinburgh', 'GB', 55.9533, -3.1883, 'Europe/London', { en: 'Edinburgh', fr: 'Édimbourg', es: 'Edimburgo', it: 'Edimburgo', fa: 'ادینبورو', ar: 'إدنبرة' }, ['Edinburgh Castle', 'Royal Mile', "Arthur's Seat"]),
    city('dublin', 'IE', 53.3498, -6.2603, 'Europe/Dublin', { en: 'Dublin', es: 'Dublín', it: 'Dublino', fa: 'دوبلین', ar: 'دبلن' }, ['Trinity College (Book of Kells)', 'Guinness Storehouse', 'Temple Bar']),
    city('prague', 'CZ', 50.0755, 14.4378, 'Europe/Prague', { en: 'Prague', fr: 'Prague', de: 'Prag', es: 'Praga', it: 'Praga', fa: 'پراگ', ar: 'براغ' }, ['Prague Castle', 'Charles Bridge', 'Old Town Square']),
    city('budapest', 'HU', 47.4979, 19.0402, 'Europe/Budapest', { en: 'Budapest', fa: 'بوداپست', ar: 'بودابست' }, ['Hungarian Parliament Building', 'Buda Castle', 'Széchenyi Thermal Bath']),
    city('krakow', 'PL', 50.0647, 19.9450, 'Europe/Warsaw', { en: 'Kraków', fr: 'Cracovie', de: 'Krakau', es: 'Cracovia', it: 'Cracovia', fa: 'کراکوف', ar: 'كراكوف' }, ['Wawel Castle', 'Main Market Square', 'Kazimierz']),
    city('athens', 'GR', 37.9838, 23.7275, 'Europe/Athens', { en: 'Athens', fr: 'Athènes', de: 'Athen', es: 'Atenas', it: 'Atene', fa: 'آتن', ar: 'أثينا' }, ['Acropolis', 'Acropolis Museum', 'Plaka']),
    city('copenhagen', 'DK', 55.6761, 12.5683, 'Europe/Copenhagen', { en: 'Copenhagen', fr: 'Copenhague', de: 'Kopenhagen', es: 'Copenhague', it: 'Copenaghen', fa: 'کپنهاگ', ar: 'كوبنهاغن' }, ['Nyhavn', 'Tivoli Gardens', 'Rosenborg Castle']),
    city('stockholm', 'SE', 59.3293, 18.0686, 'Europe/Stockholm', { en: 'Stockholm', es: 'Estocolmo', it: 'Stoccolma', fa: 'استکهلم', ar: 'ستوكهولم' }, ['Gamla Stan', 'Vasa Museum', 'Djurgården']),
    city('oslo', 'NO', 59.9139, 10.7522, 'Europe/Oslo', { en: 'Oslo', fa: 'اسلو', ar: 'أوسلو' }, ['Vigeland Park', 'Akershus Fortress', 'Oslo Opera House'])
  ];

  EP.currencies = ['EUR', 'USD', 'GBP', 'CHF', 'CZK', 'HUF', 'PLN', 'DKK', 'SEK', 'NOK', 'RON', 'BGN', 'TRY', 'CAD', 'AUD', 'JPY', 'CNY', 'INR'];

  // Phrasebook: phrase text per language. The label shown to the user is the phrase in THEIR language.
  EP.speechLang = { en: 'en-GB', fr: 'fr-FR', de: 'de-DE', es: 'es-ES', it: 'it-IT', fa: 'fa-IR', ar: 'ar-SA' };
  const P = (en, fr, de, es, it, fa, ar) => ({ en, fr, de, es, it, fa, ar });
  EP.phrases = [
    P('Hello', 'Bonjour', 'Hallo', 'Hola', 'Buongiorno', 'سلام', 'مرحباً'),
    P('Thank you', 'Merci', 'Danke', 'Gracias', 'Grazie', 'ممنون', 'شكراً'),
    P('Please', "S'il vous plaît", 'Bitte', 'Por favor', 'Per favore', 'لطفاً', 'من فضلك'),
    P('Excuse me', 'Excusez-moi', 'Entschuldigung', 'Disculpe', 'Mi scusi', 'ببخشید', 'عفواً'),
    P('Yes', 'Oui', 'Ja', 'Sí', 'Sì', 'بله', 'نعم'),
    P('No', 'Non', 'Nein', 'No', 'No', 'نه', 'لا'),
    P('How much is it?', 'Combien ça coûte ?', 'Wie viel kostet das?', '¿Cuánto cuesta?', 'Quanto costa?', 'قیمتش چقدر است؟', 'كم السعر؟'),
    P('Where is…?', 'Où est… ?', 'Wo ist …?', '¿Dónde está…?', "Dov'è…?", '… کجاست؟', 'أين …؟'),
    P('Help!', 'Au secours !', 'Hilfe!', '¡Ayuda!', 'Aiuto!', 'کمک!', 'النجدة!'),
    P('I need a doctor', "J'ai besoin d'un médecin", 'Ich brauche einen Arzt', 'Necesito un médico', 'Ho bisogno di un medico', 'به پزشک نیاز دارم', 'أحتاج إلى طبيب'),
    P('Water, please', "De l'eau, s'il vous plaît", 'Wasser, bitte', 'Agua, por favor', 'Acqua, per favore', 'لطفاً یک آب', 'ماء من فضلك'),
    P('The bill, please', "L'addition, s'il vous plaît", 'Die Rechnung, bitte', 'La cuenta, por favor', 'Il conto, per favore', 'لطفاً صورتحساب', 'الحساب من فضلك'),
    P('Do you speak English?', 'Parlez-vous anglais ?', 'Sprechen Sie Englisch?', '¿Habla inglés?', 'Parla inglese?', 'انگلیسی صحبت می‌کنید؟', 'هل تتحدث الإنجليزية؟'),
    P('Where is the toilet?', 'Où sont les toilettes ?', 'Wo ist die Toilette?', '¿Dónde está el baño?', "Dov'è il bagno?", 'دستشویی کجاست؟', 'أين الحمّام؟'),
    P('One ticket, please', "Un billet, s'il vous plaît", 'Eine Fahrkarte, bitte', 'Un billete, por favor', 'Un biglietto, per favore', 'یک بلیت لطفاً', 'تذكرة واحدة من فضلك')
  ];
})(window.EP = window.EP || {});
