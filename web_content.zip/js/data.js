window.MSL = {
  version: "1.0.0",
  subjects: [
    {id:"maths", name:"Mathématiques", icon:"∑", className:"purple", description:"Algèbre, analyse, géométrie"},
    {id:"physics", name:"Physique-Chimie", icon:"⚛", className:"blue", description:"Mécanique, électricité, chimie"},
    {id:"svt", name:"SVT", icon:"🧬", className:"green", description:"Sciences de la vie et de la Terre"},
    {id:"french", name:"Français", icon:"A", className:"pink", description:"Langue, littérature, expression"},
    {id:"english", name:"Anglais", icon:"EN", className:"cyan", description:"Vocabulary, grammar, speaking"},
    {id:"philo", name:"Philosophie", icon:"☯", className:"purple", description:"Notions, auteurs, dissertation"},
    {id:"efs", name:"EFS", icon:"⚖", className:"orange", description:"Économie, famille et société"},
    {id:"history", name:"Histoire-Géo", icon:"🌍", className:"blue", description:"Repères, cartes et événements"},
    {id:"other", name:"Autres", icon:"＋", className:"green", description:"Crée ta propre matière"}
  ]
};
