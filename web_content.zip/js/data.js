/* ============================================================
   data.js — cars, paint, modes, weather, missions
   BADAL 3D EXTREME RACING
   ============================================================ */
'use strict';

const PAINTS = [
  { name: 'Inferno Red',   hex: 0xd4180f },
  { name: 'Sunset Orange', hex: 0xff6a00 },
  { name: 'Solar Yellow',  hex: 0xffc400 },
  { name: 'Lime Surge',    hex: 0x9dff1a },
  { name: 'Emerald',       hex: 0x00c46a },
  { name: 'Ice Blue',      hex: 0x2ee6ff },
  { name: 'Sapphire',      hex: 0x1a5cff },
  { name: 'Violet',        hex: 0x8a3cff },
  { name: 'Magenta',       hex: 0xff2e88 },
  { name: 'Pearl White',   hex: 0xe9eef5 },
  { name: 'Gunmetal',      hex: 0x4a505c },
  { name: 'Obsidian',      hex: 0x111318 },
  { name: 'Rose Gold',     hex: 0xc98a6a },
  { name: 'Chrome Silver', hex: 0xb9c1cc },
];

/*
  Each car: performance + procedural body parameters.
  kind: coupe | sedan | suv | super | muscle | hatch | offroad | hyper | ev
*/
const CARS = [
  {
    id: 'falcon', name: 'FALCON GT', brand: 'BADAL MOTORS', cls: 'SPORTS COUPE',
    price: 0, paint: 0, top: 255, accel: 5.8, handling: 7.6, grip: 8.0,
    mass: 1380, nitro: 1.15, gears: 6, cyl: 6, desc: 'The balanced street fighter. Fast, forgiving and endlessly tunable.',
    kind: 'coupe', L: 4.55, W: 1.94, H: 1.24, wheelR: 0.34, clearance: 0.12,
    cabinLen: 1.95, cabinH: 0.5, cabinZ: 0.16, roofTaper: 0.74, spoiler: 1, grille: 'sport',
  },
  {
    id: 'urban', name: 'URBAN COMPACT', brand: 'BADAL MOTORS', cls: 'CITY HATCH',
    price: 0, paint: 5, top: 190, accel: 9.5, handling: 6.8, grip: 6.6,
    mass: 1120, nitro: 1.0, gears: 5, cyl: 4, desc: 'Light, nimble and cheap to run. The perfect first car.',
    kind: 'hatch', L: 3.9, W: 1.76, H: 1.5, wheelR: 0.31, clearance: 0.16,
    cabinLen: 2.15, cabinH: 0.64, cabinZ: 0.1, roofTaper: 0.8, spoiler: 0, grille: 'wide',
  },
  {
    id: 'vortex', name: 'VORTEX RS', brand: 'VORTEX', cls: 'SPORTS COUPE',
    price: 900, paint: 1, top: 285, accel: 4.9, handling: 8.3, grip: 8.6,
    mass: 1320, nitro: 1.25, gears: 6, cyl: 6, desc: 'A razor-sharp track weapon with a screaming V6 and huge grip.',
    kind: 'coupe', L: 4.6, W: 1.98, H: 1.2, wheelR: 0.35, clearance: 0.1,
    cabinLen: 1.85, cabinH: 0.48, cabinZ: 0.22, roofTaper: 0.7, spoiler: 2, grille: 'sport', widebody: true,
  },
  {
    id: 'titan', name: 'TITAN SUV', brand: 'TITAN', cls: 'LUXURY SUV',
    price: 1400, paint: 10, top: 220, accel: 7.2, handling: 6.2, grip: 6.4,
    mass: 2100, nitro: 1.05, gears: 6, cyl: 8, desc: 'Commanding V8 SUV. Heavy, but it shrugs off contact.',
    kind: 'suv', L: 4.95, W: 2.0, H: 1.86, wheelR: 0.42, clearance: 0.28,
    cabinLen: 2.65, cabinH: 0.78, cabinZ: 0.12, roofTaper: 0.92, spoiler: 0, grille: 'wide', rails: true,
  },
  {
    id: 'ranger', name: 'RANGER 4X4', brand: 'RANGER', cls: 'OFF-ROAD SUV',
    price: 1800, paint: 4, top: 200, accel: 7.8, handling: 6.0, grip: 7.2,
    mass: 2250, nitro: 1.0, gears: 6, cyl: 6, desc: 'Rugged all-terrain machine built to survive anything.',
    kind: 'offroad', L: 5.05, W: 2.06, H: 1.95, wheelR: 0.46, clearance: 0.36,
    cabinLen: 2.4, cabinH: 0.82, cabinZ: 0.05, roofTaper: 0.9, spoiler: 0, grille: 'wide',
    rails: true, bullbar: true, snorkel: true,
  },
  {
    id: 'munich3', name: 'MUNICH M3', brand: 'MUNICH', cls: 'SPORT SEDAN',
    price: 1200, paint: 5, top: 250, accel: 6.0, handling: 8.0, grip: 8.2,
    mass: 1520, nitro: 1.1, gears: 6, cyl: 6, desc: 'The everyday icon. Perfect balance of comfort and aggression.',
    kind: 'sedan', L: 4.7, W: 1.85, H: 1.44, wheelR: 0.34, clearance: 0.14,
    cabinLen: 2.35, cabinH: 0.58, cabinZ: 0.08, roofTaper: 0.8, spoiler: 1, grille: 'kidney',
  },
  {
    id: 'munich5', name: 'MUNICH M5', brand: 'MUNICH', cls: 'SUPER SEDAN',
    price: 2600, paint: 7, top: 290, accel: 4.7, handling: 8.4, grip: 8.7,
    mass: 1680, nitro: 1.2, gears: 7, cyl: 8, desc: 'A four-door missile. Autobahn royalty with race-car pace.',
    kind: 'sedan', L: 4.98, W: 1.9, H: 1.45, wheelR: 0.35, clearance: 0.13,
    cabinLen: 2.4, cabinH: 0.56, cabinZ: 0.1, roofTaper: 0.78, spoiler: 1, grille: 'kidney', widebody: true,
  },
  {
    id: 'apex', name: 'APEX R', brand: 'APEX', cls: 'TRACK COUPE',
    price: 4200, paint: 2, top: 305, accel: 3.9, handling: 9.4, grip: 9.6,
    mass: 1260, nitro: 1.35, gears: 6, cyl: 8, desc: 'A road-legal race car. Sticks to the road like it is on rails.',
    kind: 'super', L: 4.7, W: 2.02, H: 1.15, wheelR: 0.35, clearance: 0.09,
    cabinLen: 1.75, cabinH: 0.46, cabinZ: -0.15, roofTaper: 0.66, spoiler: 2, grille: 'sport', widebody: true,
  },
  {
    id: 'phantom', name: 'PHANTOM S', brand: 'PHANTOM', cls: 'HYPERCAR',
    price: 6500, paint: 11, top: 340, accel: 3.2, handling: 9.0, grip: 9.3,
    mass: 1420, nitro: 1.5, gears: 7, cyl: 8, desc: 'Mid-engined hypercar with savage acceleration and active aero.',
    kind: 'hyper', L: 4.85, W: 2.05, H: 1.08, wheelR: 0.36, clearance: 0.08,
    cabinLen: 1.7, cabinH: 0.44, cabinZ: -0.15, roofTaper: 0.62, spoiler: 2, grille: 'sport',
  },
  {
    id: 'thunder', name: 'THUNDER V8', brand: 'THUNDER', cls: 'MUSCLE CAR',
    price: 1600, paint: 0, top: 265, accel: 5.2, handling: 6.9, grip: 7.1,
    mass: 1720, nitro: 1.3, gears: 6, cyl: 8, desc: 'Old-school American thunder. Straight-line brutality.',
    kind: 'muscle', L: 4.9, W: 1.98, H: 1.32, wheelR: 0.36, clearance: 0.14,
    cabinLen: 1.9, cabinH: 0.52, cabinZ: 0.3, roofTaper: 0.76, spoiler: 1, grille: 'wide',
    hoodScoop: true, widebody: true,
  },
  {
    id: 'storm', name: 'STORM EV', brand: 'STORM', cls: 'ELECTRIC GT',
    price: 2400, paint: 5, top: 270, accel: 3.6, handling: 8.2, grip: 8.4,
    mass: 1850, nitro: 1.4, gears: 1, cyl: 0, desc: 'Silent, instant torque. A lightning-fast electric grand tourer.',
    kind: 'ev', L: 4.9, W: 1.96, H: 1.38, wheelR: 0.36, clearance: 0.13,
    cabinLen: 2.55, cabinH: 0.6, cabinZ: 0.05, roofTaper: 0.76, spoiler: 1, grille: 'none', lightBar: true,
  },
  {
    id: 'raider', name: 'DESERT RAIDER', brand: 'RAIDER', cls: 'OFF-ROAD TRUCK',
    price: 2200, paint: 1, top: 210, accel: 7.0, handling: 6.4, grip: 7.6,
    mass: 2350, nitro: 1.05, gears: 6, cyl: 8, desc: 'A trophy truck with a bed, a bull bar and zero fear.',
    kind: 'offroad', L: 5.3, W: 2.08, H: 1.9, wheelR: 0.47, clearance: 0.38,
    cabinLen: 2.2, cabinH: 0.8, cabinZ: -0.35, roofTaper: 0.9, spoiler: 0, grille: 'wide',
    rails: true, bullbar: true, snorkel: true, bed: true,
  },
  {
    id: 'velvet', name: 'VELVET GT', brand: 'VELVET', cls: 'LUXURY COUPE',
    price: 3800, paint: 9, top: 280, accel: 4.6, handling: 8.0, grip: 8.3,
    mass: 1780, nitro: 1.15, gears: 7, cyl: 8, desc: 'Hand-stitched luxury with a twin-turbo V8 under the long hood.',
    kind: 'coupe', L: 5.0, W: 1.96, H: 1.38, wheelR: 0.36, clearance: 0.14,
    cabinLen: 2.3, cabinH: 0.58, cabinZ: 0.12, roofTaper: 0.78, spoiler: 1, grille: 'chrome',
  },
  {
    id: 'nebula', name: 'NEBULA X', brand: 'NEBULA', cls: 'SUPERCAR',
    price: 3200, paint: 8, top: 315, accel: 3.5, handling: 8.9, grip: 9.1,
    mass: 1390, nitro: 1.45, gears: 7, cyl: 10, desc: 'A screaming V10 supercar with theatrical looks and sound.',
    kind: 'super', L: 4.75, W: 2.03, H: 1.12, wheelR: 0.35, clearance: 0.09,
    cabinLen: 1.8, cabinH: 0.45, cabinZ: -0.15, roofTaper: 0.64, spoiler: 2, grille: 'sport', widebody: true,
  },
  {
    id: 'lightning', name: 'LIGHTNING Z', brand: 'LIGHTNING', cls: 'HYPERCAR',
    price: 9000, paint: 3, top: 370, accel: 2.8, handling: 9.2, grip: 9.5,
    mass: 1380, nitro: 1.6, gears: 7, cyl: 12, desc: 'The final boss. 370 km/h of carbon fibre and pure insanity.',
    kind: 'hyper', L: 4.95, W: 2.1, H: 1.05, wheelR: 0.37, clearance: 0.07,
    cabinLen: 1.65, cabinH: 0.42, cabinZ: -0.18, roofTaper: 0.6, spoiler: 2, grille: 'sport', widebody: true,
  },
];

const CAR_BY_ID = {};
for (const c of CARS) CAR_BY_ID[c.id] = c;

/* ------------------------------------------------------------------ */
const MODES = [
  {
    id: 'free', name: 'FREE DRIVE', icon: '🌆', accent: '#2ee6ff',
    desc: 'Explore the endless city and highway. No timer. No pressure.',
    goal: 'Drive as far as you can', time: 0, distance: 0,
  },
  {
    id: 'race', name: 'HIGHWAY RACING', icon: '🏁', accent: '#ffc400',
    desc: 'Take on 5 rivals over 3 km of open highway. Finish first.',
    goal: 'Win the 3 km race', time: 0, distance: 3000,
  },
  {
    id: 'traffic', name: 'TRAFFIC CHALLENGE', icon: '🚗', accent: '#ff6a00',
    desc: '90 seconds of dense traffic. Overtake as many cars as possible.',
    goal: 'Score as many overtakes as you can', time: 90, distance: 0,
  },
  {
    id: 'drift', name: 'DRIFT CHALLENGE', icon: '💨', accent: '#9dff1a',
    desc: '90 seconds. Slide the car sideways and rack up drift points.',
    goal: 'Earn 12,000 drift points', time: 90, distance: 0,
  },
  {
    id: 'police', name: 'POLICE CHASE', icon: '🚨', accent: '#ff2e88',
    desc: 'The city police are on you. Survive 120 seconds of heat.',
    goal: 'Survive the chase for 2 minutes', time: 120, distance: 0,
  },
  {
    id: 'time', name: 'TIME TRIAL', icon: '⏱', accent: '#8a3cff',
    desc: 'Sprint 2.5 km against the clock. Every second counts.',
    goal: 'Reach 2,500 m before time runs out', time: 120, distance: 2500,
  },
  {
    id: 'extreme', name: 'EXTREME SPEED', icon: '⚡', accent: '#ff3b3b',
    desc: '2 minutes of nitro-fueled chaos at insane speeds.',
    goal: 'Survive and cover maximum distance', time: 120, distance: 0,
  },
];

const MODE_BY_ID = {};
for (const m of MODES) MODE_BY_ID[m.id] = m;

/* ------------------------------------------------------------------ */
const WEATHER = {
  clear: { name: 'Clear', fogNear: 70, fogFar: 900, rain: 0, wet: 0.05, dim: 1.0 },
  rain:  { name: 'Rain',  fogNear: 28, fogFar: 340, rain: 1.0, wet: 0.85, dim: 0.72 },
  fog:   { name: 'Fog',   fogNear: 8,  fogFar: 150, rain: 0, wet: 0.25, dim: 0.82 },
  storm: { name: 'Storm', fogNear: 18, fogFar: 240, rain: 1.5, wet: 1.0, dim: 0.6 },
};

/* ------------------------------------------------------------------ */
const MISSION_POOL = [
  { type: 'distance',  label: 'Drive {t} m in any mode',           min: 1200, max: 3000, step: 200, reward: 220 },
  { type: 'overtakes', label: 'Overtake {t} traffic cars',          min: 12, max: 30, step: 2, reward: 260 },
  { type: 'drift',     label: 'Score {t} drift points',             min: 2500, max: 8000, step: 500, reward: 300 },
  { type: 'topSpeed',  label: 'Reach {t} km/h in one run',          min: 180, max: 280, step: 10, reward: 240 },
  { type: 'nearMiss',  label: 'Pull off {t} near misses',           min: 8, max: 20, step: 2, reward: 280 },
  { type: 'nitro',     label: 'Use nitro for {t} seconds',          min: 15, max: 45, step: 5, reward: 200 },
  { type: 'races',     label: 'Complete {t} runs in any mode',      min: 3, max: 6, step: 1, reward: 250 },
  { type: 'policeTime',label: 'Survive {t} seconds in Police Chase', min: 30, max: 75, step: 5, reward: 350 },
];

const CAMERA_MODES = ['chase', 'far', 'first'];
const CAMERA_LABELS = { chase: 'CHASE', far: 'FAR CHASE', first: 'FIRST PERSON' };
