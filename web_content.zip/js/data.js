export const DATA_VERSION=2;
export const EXERCISES=[
{id:"wall-pushup",name:"Wall Push-up",category:"push",difficulty:"beginner",equipment:["none"],muscles:["peito","ombros","tríceps"],instructions:["Fica de frente para uma parede.","Coloca as mãos à altura do peito.","Dobra os cotovelos mantendo o corpo alinhado e empurra de volta."],mistakes:["Arquear excessivamente as costas","Deixar os cotovelos completamente abertos"],regressions:[],progressions:["incline-pushup"]},
{id:"incline-pushup",name:"Incline Push-up",category:"push",difficulty:"beginner",equipment:["none"],muscles:["peito","ombros","tríceps"],instructions:["Usa uma superfície estável e resistente.","Mantém o corpo alinhado.","Desce com controlo e empurra."],mistakes:["Superfície instável","Perder o alinhamento do tronco"],regressions:["wall-pushup"],progressions:["knee-pushup","pushup"]},
{id:"knee-pushup",name:"Knee Push-up",category:"push",difficulty:"basic",equipment:["none"],muscles:["peito","ombros","tríceps"],instructions:["Apoia os joelhos e mãos.","Mantém tronco e cabeça alinhados.","Desce e sobe com controlo."],mistakes:["Deixar a anca cair","Executar demasiado rápido"],regressions:["incline-pushup"],progressions:["pushup"]},
{id:"pushup",name:"Push-up",category:"push",difficulty:"basic",equipment:["none"],muscles:["peito","ombros","tríceps"],instructions:["Mãos ligeiramente mais largas que os ombros.","Corpo alinhado da cabeça aos pés.","Desce com controlo e volta à posição inicial."],mistakes:["Anca demasiado alta ou baixa","Amplitude sem controlo"],regressions:["knee-pushup"],progressions:["diamond-pushup"]},
{id:"diamond-pushup",name:"Diamond Push-up",category:"push",difficulty:"advanced",equipment:["none"],muscles:["tríceps","peito"],instructions:["Aproxima as mãos numa posição confortável.","Mantém os cotovelos sob controlo.","Usa amplitude que consigas dominar."],mistakes:["Forçar amplitude","Perder controlo dos ombros"],regressions:["pushup"],progressions:[]},
{id:"pike-pushup",name:"Pike Push-up",category:"push",difficulty:"intermediate",equipment:["none"],muscles:["ombros","tríceps"],instructions:["Forma uma posição de pike confortável.","Dobra os cotovelos e aproxima a cabeça do chão.","Empurra mantendo o controlo."],mistakes:["Colocar carga excessiva sem preparação"],regressions:["incline-pushup"],progressions:[]},
{id:"body-row",name:"Body Row",category:"pull",difficulty:"basic",equipment:["bar"],muscles:["costas","bíceps"],instructions:["Usa uma barra fixa e resistente à altura apropriada.","Mantém o corpo alinhado.","Puxa o peito em direção à barra com controlo."],mistakes:["Equipamento instável","Movimento brusco"],regressions:[],progressions:["australian-pullup"]},
{id:"australian-pullup",name:"Australian Pull-up",category:"pull",difficulty:"basic",equipment:["bar"],muscles:["costas","bíceps"],instructions:["Posiciona-te sob uma barra resistente.","Mantém o corpo alinhado.","Puxa o peito para a barra e desce lentamente."],mistakes:["Perder alinhamento","Usar impulso"],regressions:["body-row"],progressions:["pullup-progression"]},
{id:"pullup-progression",name:"Pull-up Progression",category:"pull",difficulty:"intermediate",equipment:["bar"],muscles:["costas","bíceps"],instructions:["Usa uma progressão compatível com o teu nível.","Mantém o movimento controlado.","Prioriza técnica sobre quantidade."],mistakes:["Forçar repetições","Perder controlo"],regressions:["australian-pullup"],progressions:[]},
{id:"squat",name:"Squat",category:"legs",difficulty:"beginner",equipment:["none"],muscles:["quadríceps","glúteos"],instructions:["Pés numa posição confortável.","Desce mantendo os joelhos controlados.","Volta a subir com controlo."],mistakes:["Perder equilíbrio","Forçar amplitude desconfortável"],regressions:[],progressions:["split-squat"]},
{id:"split-squat",name:"Split Squat",category:"legs",difficulty:"basic",equipment:["none"],muscles:["pernas","glúteos"],instructions:["Adota uma base em passada.","Desce mantendo o tronco estável.","Empurra pelo pé da frente."],mistakes:["Perder estabilidade","Descer sem controlo"],regressions:["squat"],progressions:["bulgarian-split-squat"]},
{id:"reverse-lunge",name:"Reverse Lunge",category:"legs",difficulty:"basic",equipment:["none"],muscles:["pernas","glúteos"],instructions:["Dá um passo para trás.","Desce com controlo.","Volta à posição inicial."],mistakes:["Passo instável","Colapsar o joelho para dentro"],regressions:["squat"],progressions:[]},
{id:"bulgarian-split-squat",name:"Bulgarian Split Squat",category:"legs",difficulty:"intermediate",equipment:["none"],muscles:["pernas","glúteos"],instructions:["Usa um apoio estável para o pé traseiro.","Desce de forma controlada.","Mantém o equilíbrio e sobe."],mistakes:["Apoio instável","Forçar amplitude"],regressions:["split-squat"],progressions:[]},
{id:"plank",name:"Plank",category:"core",difficulty:"beginner",equipment:["none"],muscles:["core"],instructions:["Apoia antebraços ou mãos conforme a variante.","Mantém o corpo alinhado.","Respira normalmente."],mistakes:["Prender a respiração","Deixar a lombar ceder"],regressions:["dead-bug"],progressions:["side-plank"]},
{id:"side-plank",name:"Side Plank",category:"core",difficulty:"basic",equipment:["none"],muscles:["core","oblíquos"],instructions:["Apoia o antebraço.","Mantém o corpo alinhado lateralmente.","Mantém respiração confortável."],mistakes:["Rodar o tronco","Forçar tempo excessivo"],regressions:["plank"],progressions:[]},
{id:"hollow-hold",name:"Hollow Hold",category:"core",difficulty:"intermediate",equipment:["none"],muscles:["core"],instructions:["Adota uma posição hollow adaptada ao teu nível.","Mantém a lombar controlada.","Interrompe se perderes a técnica."],mistakes:["Forçar posição","Perder controlo lombar"],regressions:["dead-bug"],progressions:["l-sit-progression"]},
{id:"dead-bug",name:"Dead Bug",category:"core",difficulty:"beginner",equipment:["none"],muscles:["core"],instructions:["Deita-te de costas.","Move braços e pernas alternadamente.","Mantém o tronco controlado."],mistakes:["Acelerar","Perder controlo do tronco"],regressions:[],progressions:["plank"]},
{id:"l-sit-progression",name:"L-sit Progression",category:"core",difficulty:"advanced",equipment:["parallettes","bar"],muscles:["core","flexores da anca"],instructions:["Usa apoio firme.","Escolhe uma progressão adequada.","Mantém controlo e respiração."],mistakes:["Forçar uma variante avançada","Ignorar fadiga técnica"],regressions:["hollow-hold"],progressions:[]}
];
export const WORKOUTS=[
{id:"foundation-push-core",name:"Foundation Push + Core",description:"Fundamentos de empurrar e controlo do core.",duration:20,focus:"Push + Core",level:["beginner","basic"],equipment:["none"],sections:[
{name:"Aquecimento",items:[{exerciseId:"dead-bug",sets:1,reps:6,duration:0,rest:20,notes:"Movimento lento."}]},
{name:"Principal",items:[{exerciseId:"wall-pushup",sets:2,reps:6,duration:0,rest:35},{exerciseId:"incline-pushup",sets:2,reps:5,duration:0,rest:35}]},
{name:"Core",items:[{exerciseId:"plank",sets:2,reps:0,duration:20,rest:35}]}
]},
{id:"full-foundation",name:"Full Body Foundation",description:"Sessão equilibrada para aprender padrões básicos.",duration:25,focus:"Full body",level:["beginner","basic"],equipment:["none"],sections:[
{name:"Aquecimento",items:[{exerciseId:"dead-bug",sets:1,reps:6,duration:0,rest:20}]},
{name:"Principal",items:[{exerciseId:"squat",sets:2,reps:8,duration:0,rest:35},{exerciseId:"incline-pushup",sets:2,reps:5,duration:0,rest:35},{exerciseId:"plank",sets:2,reps:0,duration:20,rest:35}]}
]},
{id:"lower-core",name:"Legs + Core",description:"Sessão simples para pernas e estabilidade.",duration:20,focus:"Legs + Core",level:["beginner","basic"],equipment:["none"],sections:[
{name:"Principal",items:[{exerciseId:"squat",sets:3,reps:8,duration:0,rest:35},{exerciseId:"reverse-lunge",sets:2,reps:5,duration:0,rest:35},{exerciseId:"dead-bug",sets:2,reps:6,duration:0,rest:25}]}
]},
{id:"pull-foundation",name:"Pull Foundation",description:"Fundamentos de puxar para quem tem barra resistente.",duration:20,focus:"Pull",level:["basic","intermediate"],equipment:["bar"],sections:[
{name:"Principal",items:[{exerciseId:"body-row",sets:3,reps:5,duration:0,rest:45},{exerciseId:"australian-pullup",sets:2,reps:4,duration:0,rest:45}]}
]}
];
export const ACHIEVEMENTS=[
{id:"first-workout",name:"Primeiro treino",description:"Concluir a primeira sessão."},
{id:"five-sessions",name:"5 sessões",description:"Concluir 5 sessões."},
{id:"ten-sessions",name:"10 sessões",description:"Concluir 10 sessões."},
{id:"first-skill",name:"Primeira skill",description:"Dominar a primeira skill."},
{id:"first-progression",name:"Primeira progressão",description:"Desbloquear a primeira progressão."},
{id:"four-weeks",name:"4 semanas de consistência",description:"Treinar em 4 semanas diferentes."}
];
export const SKILLS=[
{id:"push-foundation",name:"Push Foundation",category:"push",exerciseId:"pushup",requires:["wall-pushup","incline-pushup","knee-pushup"],threshold:2},
{id:"diamond",name:"Diamond Push-up",category:"push",exerciseId:"diamond-pushup",requires:["pushup"],threshold:3},
{id:"pull-foundation",name:"Pull Foundation",category:"pull",exerciseId:"australian-pullup",requires:["body-row"],threshold:3},
{id:"legs-foundation",name:"Legs Foundation",category:"legs",exerciseId:"split-squat",requires:["squat"],threshold:3},
{id:"core-foundation",name:"Core Foundation",category:"core",exerciseId:"plank",requires:["plank"],threshold:3},
{id:"l-sit",name:"L-sit Progression",category:"core",exerciseId:"l-sit-progression",requires:["hollow-hold"],threshold:3}
];