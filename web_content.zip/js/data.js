/* ============================================================
   AETHERVALE — Data definitions (items, enemies, world, story)
   ============================================================ */
const G = { TILE: 16, VW: 480, VH: 270 };

const RARITY = {
  common:    { name: 'Biasa',    color: '#cfd3e0', mult: 1.00 },
  uncommon:  { name: 'Langka',   color: '#6fe08a', mult: 1.18 },
  rare:      { name: 'Pusaka',   color: '#61b7ff', mult: 1.42 },
  epic:      { name: 'Mistis',   color: '#c07bff', mult: 1.75 },
  legendary: { name: 'Legenda',  color: '#f5b53c', mult: 2.2 },
};

const SLOTS = {
  weapon: 'Senjata', armor: 'Baju', helm: 'Helm', boots: 'Sepatu', ring: 'Cincin',
};

/* ---------- Item templates ---------- */
// stats: atk, def, hp, crit (%), critdmg (%), life (% lifesteal), haste (%), spd
const ITEMS = {};
function defItem(o) { ITEMS[o.id] = o; return o; }

// WEAPONS
defItem({ id:'w_stick',   name:'Tongkat Kayu',        type:'weapon', tier:1, rarity:'common',    icon:'sword', sockets:0, stats:{atk:4},                 price:40 });
defItem({ id:'w_short',   name:'Pedang Pendek',       type:'weapon', tier:2, rarity:'common',    icon:'sword', sockets:1, stats:{atk:9},                 price:180 });
defItem({ id:'w_hunter',  name:'Bilah Pemburu',       type:'weapon', tier:3, rarity:'uncommon',  icon:'sword', sockets:1, stats:{atk:16, crit:4},        price:520 });
defItem({ id:'w_marsh',   name:'Trisula Rawa',        type:'weapon', tier:4, rarity:'rare',      icon:'spear', sockets:2, stats:{atk:26, life:3},        price:1400 });
defItem({ id:'w_ember',   name:'Pedang Bara',         type:'weapon', tier:5, rarity:'rare',      icon:'sword', sockets:2, stats:{atk:38, crit:6},        price:3200 });
defItem({ id:'w_frost',   name:'Kapak Beku',          type:'weapon', tier:6, rarity:'epic',      icon:'axe',   sockets:3, stats:{atk:54, critdmg:20},    price:7400 });
defItem({ id:'w_rift',    name:'Bilah Celah Aether',  type:'weapon', tier:7, rarity:'legendary', icon:'sword', sockets:3, stats:{atk:78, crit:8, life:5},price:19000 });
// ARMOR
defItem({ id:'a_cloth',   name:'Jubah Lusuh',         type:'armor', tier:1, rarity:'common',   icon:'armor', sockets:0, stats:{def:3, hp:10},     price:35 });
defItem({ id:'a_leather', name:'Zirah Kulit',         type:'armor', tier:2, rarity:'common',   icon:'armor', sockets:1, stats:{def:7, hp:24},     price:170 });
defItem({ id:'a_scout',   name:'Rompi Pengintai',     type:'armor', tier:3, rarity:'uncommon', icon:'armor', sockets:1, stats:{def:12, hp:44, spd:4}, price:500 });
defItem({ id:'a_mire',    name:'Zirah Lumpur Suci',   type:'armor', tier:4, rarity:'rare',     icon:'armor', sockets:2, stats:{def:19, hp:70},    price:1350 });
defItem({ id:'a_ash',     name:'Pelindung Abu',       type:'armor', tier:5, rarity:'rare',     icon:'armor', sockets:2, stats:{def:27, hp:105},   price:3100 });
defItem({ id:'a_glacier', name:'Zirah Gletser',       type:'armor', tier:6, rarity:'epic',     icon:'armor', sockets:3, stats:{def:38, hp:150},   price:7100 });
defItem({ id:'a_aether',  name:'Zirah Penjaga Aether',type:'armor', tier:7, rarity:'legendary',icon:'armor', sockets:3, stats:{def:52, hp:220, life:3}, price:18000 });
// HELM
defItem({ id:'h_hood',    name:'Tudung Kain',         type:'helm', tier:1, rarity:'common',   icon:'helm', sockets:0, stats:{def:2, hp:6},   price:30 });
defItem({ id:'h_iron',    name:'Helm Besi',           type:'helm', tier:2, rarity:'common',   icon:'helm', sockets:1, stats:{def:5, hp:16},  price:150 });
defItem({ id:'h_fang',    name:'Mahkota Taring',      type:'helm', tier:3, rarity:'uncommon', icon:'helm', sockets:1, stats:{def:8, crit:3}, price:460 });
defItem({ id:'h_bog',     name:'Topeng Kabut',        type:'helm', tier:4, rarity:'rare',     icon:'helm', sockets:2, stats:{def:13, hp:40, haste:4}, price:1200 });
defItem({ id:'h_cinder',  name:'Helm Jelaga',         type:'helm', tier:5, rarity:'rare',     icon:'helm', sockets:2, stats:{def:19, hp:60},  price:2900 });
defItem({ id:'h_rime',    name:'Diadem Embun Beku',   type:'helm', tier:6, rarity:'epic',     icon:'helm', sockets:3, stats:{def:26, hp:90, crit:5}, price:6800 });
// BOOTS
defItem({ id:'b_sandal',  name:'Sandal Jerami',       type:'boots', tier:1, rarity:'common',   icon:'boots', sockets:0, stats:{spd:6},           price:28 });
defItem({ id:'b_travel',  name:'Sepatu Pengembara',   type:'boots', tier:2, rarity:'common',   icon:'boots', sockets:1, stats:{spd:12, def:3},   price:140 });
defItem({ id:'b_swift',   name:'Sepatu Angin',        type:'boots', tier:3, rarity:'uncommon', icon:'boots', sockets:1, stats:{spd:20, haste:5}, price:440 });
defItem({ id:'b_marsh',   name:'Bot Penapak Rawa',    type:'boots', tier:4, rarity:'rare',     icon:'boots', sockets:2, stats:{spd:26, def:8, hp:30}, price:1150 });
defItem({ id:'b_magma',   name:'Bot Inti Magma',      type:'boots', tier:5, rarity:'rare',     icon:'boots', sockets:2, stats:{spd:32, def:13},  price:2800 });
defItem({ id:'b_gale',    name:'Bot Badai Salju',     type:'boots', tier:6, rarity:'epic',     icon:'boots', sockets:3, stats:{spd:42, haste:9, def:18}, price:6600 });
// RING
defItem({ id:'r_copper',  name:'Cincin Tembaga',      type:'ring', tier:1, rarity:'common',   icon:'ring', sockets:0, stats:{atk:2, hp:8},        price:45 });
defItem({ id:'r_silver',  name:'Cincin Perak',        type:'ring', tier:2, rarity:'uncommon', icon:'ring', sockets:1, stats:{atk:5, crit:3},      price:210 });
defItem({ id:'r_vital',   name:'Cincin Nadi',         type:'ring', tier:3, rarity:'uncommon', icon:'ring', sockets:1, stats:{hp:55, life:3},      price:600 });
defItem({ id:'r_ember',   name:'Cincin Bara Kecil',   type:'ring', tier:4, rarity:'rare',     icon:'ring', sockets:2, stats:{atk:14, critdmg:15}, price:1500 });
defItem({ id:'r_aether',  name:'Cincin Mata Aether',  type:'ring', tier:6, rarity:'epic',     icon:'ring', sockets:2, stats:{atk:24, crit:7, haste:6}, price:7000 });

// MATERIALS / CONSUMABLES (stackable)
function defMat(id, name, icon, price, desc, rarity) {
  return defItem({ id, name, type:'mat', icon, price, desc, rarity: rarity||'common', stack:true });
}
defMat('m_stone',    'Batu Tempa',            'stone',  120,  'Bahan dasar penempaan senjata & zirah.');
defMat('m_stone_hi', 'Batu Tempa Agung',      'stone2', 620,  'Batu tempa murni untuk tempaan tinggi (+7 ke atas).', 'rare');
defMat('m_protect',  'Gulungan Perlindungan',  'scroll', 900,  'Mencegah item hancur/turun level saat tempaan gagal.', 'rare');
defMat('m_enchant',  'Gulungan Sihir',         'scroll2',700,  'Merapal efek pasif acak pada peralatan.', 'uncommon');
defMat('m_essence',  'Esensi Warisan',         'essence',1500, 'Memindahkan tempaan, permata, dan sihir ke item baru.', 'epic');
defMat('m_dust',     'Debu Monster',           'dust',   18,   'Bahan sepele, laku di pasar.');
defMat('m_pelt',     'Bulu Serigala',          'pelt',   55,   'Bahan kerajinan dari Hutan Bisik.');
defMat('m_relic',    'Pusaka Terbenam',        'relic',  240,  'Artefak berlumpur dari Rawa Kelam.', 'uncommon');
defMat('m_ashcore',  'Inti Abu',               'core',   380,  'Bara yang tak pernah padam.', 'uncommon');
defMat('m_frost',    'Serpih Beku',            'frost',  520,  'Pecahan es purba dari Puncak Beku.', 'rare');
defMat('m_riftshard','Pecahan Celah',          'rift',   2400, 'Getaran dari retakan dunia.', 'legendary');
defItem({ id:'p_potion',  name:'Ramuan Merah',   type:'potion', icon:'potion',  price:80,  stack:true, heal:70,  rarity:'common',   desc:'Memulihkan 70 HP.' });
defItem({ id:'p_potion_hi',name:'Ramuan Agung',  type:'potion', icon:'potion2', price:260, stack:true, heal:240, rarity:'uncommon', desc:'Memulihkan 240 HP.' });

// GEMS
const GEMS = {
  g_ruby:     { id:'g_ruby',     name:'Rubi',         icon:'gem', color:'#ff4d6a', stat:'crit',    val:4,  desc:'+4% Peluang Kritis' },
  g_sapphire: { id:'g_sapphire', name:'Safir',        icon:'gem', color:'#4d9cff', stat:'life',    val:3,  desc:'+3% Serap Darah' },
  g_topaz:    { id:'g_topaz',    name:'Topas',        icon:'gem', color:'#ffd24d', stat:'haste',   val:5,  desc:'+5% Kecepatan Serang' },
  g_emerald:  { id:'g_emerald',  name:'Zamrud',       icon:'gem', color:'#4dffa3', stat:'hp',      val:45, desc:'+45 HP Maks' },
  g_onyx:     { id:'g_onyx',     name:'Oniks',        icon:'gem', color:'#9b8bff', stat:'def',     val:8,  desc:'+8 Pertahanan' },
  g_garnet:   { id:'g_garnet',   name:'Garnet',       icon:'gem', color:'#ff8a3d', stat:'atk',     val:9,  desc:'+9 Serangan' },
  g_ruby_hi:  { id:'g_ruby_hi',  name:'Rubi Murni',   icon:'gem2',color:'#ff2e55', stat:'critdmg',val:28, desc:'+28% Kerusakan Kritis' },
  g_star:     { id:'g_star',     name:'Permata Bintang', icon:'gem2', color:'#ffe9a8', stat:'atk', val:20, desc:'+20 Serangan' },
};
Object.values(GEMS).forEach(g => defItem({
  id:g.id, name:g.name, type:'gem', icon:g.icon, gemColor:g.color, stack:true,
  price: g.id.endsWith('_hi')||g.id==='g_star' ? 2100 : 480,
  rarity: (g.id.endsWith('_hi')||g.id==='g_star') ? 'epic' : 'uncommon',
  desc: g.desc, stats:{ [g.stat]: g.val },
}));

/* ---------- Enhancement table ---------- */
// index = current plus; result = going to plus+1
const ENHANCE = [
  { rate:1.00, down:0.00, brk:0.00, stone:'m_stone', qty:1, gold:60 },   // 0 -> 1
  { rate:0.95, down:0.00, brk:0.00, stone:'m_stone', qty:1, gold:110 },
  { rate:0.88, down:0.00, brk:0.00, stone:'m_stone', qty:2, gold:180 },
  { rate:0.76, down:0.20, brk:0.00, stone:'m_stone', qty:2, gold:280 },
  { rate:0.64, down:0.30, brk:0.00, stone:'m_stone', qty:3, gold:420 },
  { rate:0.52, down:0.40, brk:0.03, stone:'m_stone', qty:4, gold:640 },
  { rate:0.42, down:0.45, brk:0.06, stone:'m_stone_hi', qty:1, gold:900 }, // 6 -> 7
  { rate:0.32, down:0.48, brk:0.10, stone:'m_stone_hi', qty:2, gold:1400 },
  { rate:0.24, down:0.50, brk:0.14, stone:'m_stone_hi', qty:3, gold:2100 },
  { rate:0.16, down:0.52, brk:0.18, stone:'m_stone_hi', qty:4, gold:3200 }, // 9 -> 10
];
const MAX_PLUS = 10;
// Each + adds this fraction of base stats (cumulative, mild curve)
function plusMult(p) { return 1 + p * 0.14 + Math.max(0, p - 6) * 0.06; }

/* ---------- Enchantment pool ---------- */
const ENCHANTS = [
  { id:'e_sharp',  name:'Ketajaman',      stat:'atk',     rolls:[6,26],  w:20 },
  { id:'e_guard',  name:'Benteng',        stat:'def',     rolls:[5,22],  w:20 },
  { id:'e_vigor',  name:'Vitalitas',      stat:'hp',      rolls:[30,140],w:20 },
  { id:'e_focus',  name:'Fokus',          stat:'crit',    rolls:[2,9],   w:12 },
  { id:'e_fury',   name:'Amarah',         stat:'critdmg', rolls:[10,40], w:10 },
  { id:'e_leech',  name:'Lintah Darah',   stat:'life',    rolls:[2,7],   w:8 },
  { id:'e_swift',  name:'Kilat',          stat:'haste',   rolls:[3,11],  w:8 },
  { id:'e_wind',   name:'Langkah Angin',  stat:'spd',     rolls:[6,24],  w:8 },
];
const ENCHANT_GRADE = [
  { name:'I',   t:[0.00,0.35], color:'#cfd3e0' },
  { name:'II',  t:[0.35,0.70], color:'#6fe08a' },
  { name:'III', t:[0.70,0.90], color:'#61b7ff' },
  { name:'IV',  t:[0.90,0.99], color:'#c07bff' },
  { name:'V',   t:[0.99,1.01], color:'#f5b53c' },
];

/* ---------- Stat labels ---------- */
const STAT_LABEL = {
  atk:'Serangan', def:'Pertahanan', hp:'HP Maks', crit:'Peluang Kritis',
  critdmg:'Kerusakan Kritis', life:'Serap Darah', haste:'Kec. Serang', spd:'Kec. Gerak',
};
const STAT_SUFFIX = { crit:'%', critdmg:'%', life:'%', haste:'%' };

/* ---------- Classes ---------- */
const CLASSES = [
  { id:'guardian', name:'Penjaga Serambi', blurb:'Bertahan, memukul keras, lambat.',
    hp:240, atk:12, def:10, crit:5, critdmg:150, haste:0, spd:78, tint:'#6fa8ff',
    skill:'Hantaman Perisai — area kecil, kerusakan besar' },
  { id:'ranger', name:'Pengelana Rimba', blurb:'Cepat, kritis tinggi, rapuh.',
    hp:180, atk:15, def:6, crit:14, critdmg:170, haste:12, spd:96, tint:'#6fe08a',
    skill:'Tebasan Ganda — dua serangan cepat' },
  { id:'arcanist', name:'Pawang Arcana', blurb:'Kerusakan sihir melengkung luas.',
    hp:165, atk:17, def:5, crit:9, critdmg:185, haste:6, spd:86, tint:'#c07bff',
    skill:'Gelombang Aether — menembus banyak musuh' },
];

/* ---------- Enemies ---------- */
const ENEMIES = {
  slime:   { name:'Slime Fajar',    art:'slime',  hp:34,  atk:6,  def:1,  xp:12,  gold:[6,14],   spd:26, r:7,  color:'#7fe0a0', biome:'meadow',
             drops:[['m_dust',0.7,1,2],['p_potion',0.12,1,1],['m_stone',0.10,1,1]] },
  boar:    { name:'Babi Rawa Muda', art:'boar',   hp:58,  atk:9,  def:3,  xp:20,  gold:[10,22],  spd:40, r:8,  color:'#c98a5a', biome:'meadow',
             drops:[['m_dust',0.6,1,3],['m_pelt',0.25,1,1],['m_stone',0.14,1,1]] },
  wolf:    { name:'Serigala Bisik', art:'wolf',   hp:92,  atk:15, def:5,  xp:38,  gold:[18,36],  spd:56, r:9,  color:'#8f93a8', biome:'forest',
             drops:[['m_pelt',0.55,1,2],['m_stone',0.22,1,2],['g_ruby',0.05,1,1],['p_potion',0.15,1,1]] },
  wisp:    { name:'Wisp Rimba',     art:'wisp',   hp:70,  atk:18, def:2,  xp:40,  gold:[22,40],  spd:48, r:7,  color:'#9ef7ff', biome:'forest',
             drops:[['m_enchant',0.14,1,1],['m_dust',0.5,2,4],['g_topaz',0.06,1,1]] },
  lurker:  { name:'Pengintai Rawa', art:'lurker', hp:150, atk:24, def:9,  xp:66,  gold:[30,58],  spd:42, r:10, color:'#5f8c6a', biome:'swamp',
             drops:[['m_relic',0.45,1,1],['m_stone',0.3,1,2],['g_sapphire',0.07,1,1],['m_protect',0.05,1,1]] },
  bandit:  { name:'Perampok Kelam', art:'bandit', hp:170, atk:28, def:11, xp:78,  gold:[45,90],  spd:62, r:9,  color:'#b25b5b', biome:'swamp',
             drops:[['m_stone',0.4,1,3],['m_enchant',0.12,1,1],['p_potion_hi',0.12,1,1],['g_onyx',0.06,1,1]] },
  fiend:   { name:'Iblis Abu',      art:'fiend',  hp:230, atk:38, def:15, xp:110, gold:[60,120], spd:58, r:10, color:'#ff7a45', biome:'ash',
             drops:[['m_ashcore',0.5,1,1],['m_stone_hi',0.18,1,1],['m_enchant',0.15,1,1],['g_garnet',0.07,1,1]] },
  revenant:{ name:'Arwah Beku',     art:'revenant',hp:320,atk:52, def:22, xp:170, gold:[90,175], spd:54, r:10, color:'#8fd8ff', biome:'snow',
             drops:[['m_frost',0.5,1,1],['m_stone_hi',0.25,1,2],['m_essence',0.10,1,1],['g_ruby_hi',0.05,1,1]] },
  drowned: { name:'Tenggelam Pasang', art:'lurker', hp:120, atk:20, def:7, xp:52, gold:[24,48], spd:44, r:9, color:'#4f9fa8',
             drops:[['m_dust',0.55,2,4],['m_relic',0.2,1,1],['g_sapphire',0.06,1,1]] },
  husk:    { name:'Bangkai Gurun',  art:'bandit', hp:140, atk:26, def:10, xp:70, gold:[34,70],  spd:50, r:9,  color:'#c9a36a',
             drops:[['m_stone',0.35,1,2],['m_dust',0.5,2,4],['g_topaz',0.07,1,1]] },
  crawler: { name:'Perayap Gua',    art:'slime',  hp:190, atk:30, def:12, xp:96,  gold:[46,92],  spd:46, r:8,  color:'#a88fd8',
             drops:[['m_stone',0.4,1,3],['m_stone_hi',0.12,1,1],['g_garnet',0.06,1,1]] },
  deepstalker:{ name:'Pengintai Kelam', art:'lurker', hp:520, atk:66, def:28, xp:280, gold:[150,300], spd:58, r:11, color:'#2fd0d8',
             drops:[['m_essence',0.2,1,1],['m_stone_hi',0.35,1,2],['g_star',0.04,1,1],['m_protect',0.1,1,1]] },
  emberfiend:{ name:'Iblis Bara',   art:'fiend',  hp:400, atk:58, def:24, xp:220, gold:[120,240], spd:60, r:10, color:'#ff6a2f',
             drops:[['m_ashcore',0.55,1,2],['m_stone_hi',0.28,1,2],['g_garnet',0.09,1,1]] },
  soulwisp:{ name:'Wisp Jiwa',      art:'wisp',   hp:300, atk:64, def:14, xp:240, gold:[130,260], spd:62, r:8,  color:'#6fe8f0',
             drops:[['m_enchant',0.3,1,2],['m_essence',0.12,1,1],['g_ruby_hi',0.06,1,1]] },
  voidshade:{ name:'Bayang Hampa',  art:'rift',   hp:620, atk:78, def:30, xp:420, gold:[220,440], spd:56, r:11, color:'#c07bff',
             drops:[['m_riftshard',0.18,1,1],['m_essence',0.22,1,1],['m_stone_hi',0.4,1,2],['g_star',0.06,1,1]] },
  rift_spawn:{ name:'Anak Celah',   art:'rift',   hp:480, atk:70, def:26, xp:330, gold:[180,340], spd:66, r:9,  color:'#9a7bff',
             drops:[['m_riftshard',0.1,1,1],['m_stone_hi',0.35,1,2],['m_enchant',0.2,1,1]] },
  // Bosses
  alpha:   { name:'Taring Alfa',    art:'wolf',   hp:620, atk:30, def:12, xp:320, gold:[260,340], spd:64, r:14, color:'#e0d6c0', boss:true,
             drops:[['m_stone',1,3,5],['g_ruby',1,1,1],['m_protect',1,1,1],['w_hunter',1,1,1]] },
  magmaris:{ name:'Magmaris, Golem Abu', art:'golem', hp:1500, atk:62, def:26, xp:900, gold:[700,900], spd:40, r:18, color:'#ff8c3a', boss:true,
             drops:[['m_stone_hi',1,3,4],['m_ashcore',1,3,3],['g_ruby_hi',1,1,1],['a_ash',1,1,1]] },
  vaelor:  { name:'Vaelor, Sang Celah', art:'rift', hp:3200, atk:88, def:34, xp:2600, gold:[2000,2600], spd:52, r:20, color:'#c07bff', boss:true,
             drops:[['m_riftshard',1,2,3],['w_rift',1,1,1],['m_essence',1,2,2]] },
};

/* ---------- Biomes (64 bioma, 4 alam) ----------
   realm: overworld | cave | nether | end
   treeStyle: broad pine birch dark cherry palm jungle bamboo mangrove dead
              crystal fungus_red fungus_blue coral snowpine mushroom none
   fluid: true  -> bioma perairan penuh (laut / sungai)
*/
const BIOMES = {};
function defB(id, o) { o.id = id; BIOMES[id] = o; return o; }

/* --- Lautan & pesisir --- */
defB('ocean',            { name:'Samudra', realm:'overworld', ground:['#3f6b52','#456f57','#3a6049'], water:'#2f6fa8', rock:'#6f7a86', tree:'#2f5a4a', treeStyle:'coral', dens:0.01, accent:'#5fa8d8', flower:['#7dd3fc'], music:'meadow', fluid:true, waterLvl:0.86, enemies:['drowned','slime'] });
defB('deep_ocean',       { name:'Samudra Dalam', realm:'overworld', ground:['#27465c','#2b4d64','#223e52'], water:'#1d4f80', rock:'#5c6672', tree:'#23483c', treeStyle:'coral', dens:0.006, accent:'#3f88bf', flower:['#7dd3fc'], music:'rift', fluid:true, waterLvl:0.95, enemies:['drowned','lurker'] });
defB('warm_ocean',       { name:'Samudra Hangat', realm:'overworld', ground:['#5f8f7a','#68997f','#578771'], water:'#2a97b8', rock:'#8a8f79', tree:'#e06a8a', treeStyle:'coral', dens:0.03, accent:'#6fe0d0', flower:['#ff8fb1','#ffd88a'], music:'meadow', fluid:true, waterLvl:0.84, enemies:['drowned','slime'] });
defB('lukewarm_ocean',   { name:'Samudra Sedang', realm:'overworld', ground:['#4c7d66','#55866d','#44725e'], water:'#2b7fae', rock:'#767f86', tree:'#3f7a68', treeStyle:'coral', dens:0.018, accent:'#5fc2d8', flower:['#8fe8e0'], music:'meadow', fluid:true, waterLvl:0.86, enemies:['drowned'] });
defB('deep_lukewarm_ocean',{ name:'Samudra Sedang Dalam', realm:'overworld', ground:['#2d5566','#345e6e','#284c5c'], water:'#20648f', rock:'#5f6a75', tree:'#2f6156', treeStyle:'coral', dens:0.01, accent:'#46a0c4', flower:['#8fe8e0'], music:'rift', fluid:true, waterLvl:0.94, enemies:['drowned','lurker'] });
defB('cold_ocean',       { name:'Samudra Dingin', realm:'overworld', ground:['#3b5f6b','#436873','#345662'], water:'#2f6a94', rock:'#78828c', tree:'#37606a', treeStyle:'coral', dens:0.01, accent:'#9fd8e8', flower:['#cfe8ff'], music:'snow', fluid:true, waterLvl:0.88, enemies:['drowned','revenant'] });
defB('deep_cold_ocean',  { name:'Samudra Dingin Dalam', realm:'overworld', ground:['#2b4a57','#325260','#26424e'], water:'#245a80', rock:'#69737d', tree:'#2b5460', treeStyle:'coral', dens:0.008, accent:'#86c6dd', flower:['#cfe8ff'], music:'snow', fluid:true, waterLvl:0.95, enemies:['drowned','revenant'] });
defB('frozen_ocean',     { name:'Samudra Beku', realm:'overworld', ground:['#c3d6e2','#cfdfe9','#b3c8d6'], water:'#7fb6d9', rock:'#94a3af', tree:'#5d7a88', treeStyle:'snowpine', dens:0.006, accent:'#eef7ff', flower:['#ffffff'], music:'snow', fluid:true, waterLvl:0.88, enemies:['revenant'] });
defB('deep_frozen_ocean',{ name:'Samudra Beku Dalam', realm:'overworld', ground:['#a9c2d2','#b6ccd9','#9ab3c4'], water:'#5f9cc4', rock:'#8795a1', tree:'#51707e', treeStyle:'snowpine', dens:0.004, accent:'#e6f2ff', flower:['#ffffff'], music:'snow', fluid:true, waterLvl:0.95, enemies:['revenant'] });
defB('beach',            { name:'Pantai', realm:'overworld', ground:['#e8d9a8','#e0cf9a','#d6c48d'], water:'#2f8fc0', rock:'#b6ab8e', tree:'#3f7a4a', treeStyle:'palm', dens:0.016, accent:'#fff0c0', flower:['#ffe08a'], music:'meadow', sandy:true, waterLvl:0.3, enemies:['slime','boar'] });
defB('snowy_beach',      { name:'Pantai Bersalju', realm:'overworld', ground:['#dfe6ec','#e8eef3','#cfd8e0'], water:'#6fa8cf', rock:'#9aa6b1', tree:'#527282', treeStyle:'snowpine', dens:0.01, accent:'#ffffff', flower:['#e9f4ff'], music:'snow', sandy:true, waterLvl:0.3, enemies:['revenant','slime'] });
defB('stony_shore',      { name:'Pesisir Batu', realm:'overworld', ground:['#8b8f96','#94989f','#7e8289'], water:'#35759e', rock:'#6b7078', tree:'#4c6b52', treeStyle:'pine', dens:0.008, accent:'#b8bec6', flower:['#cfd6de'], music:'snow', rocky:true, waterLvl:0.3, enemies:['boar','wolf'] });
defB('mushroom_fields',  { name:'Padang Jamur', realm:'overworld', ground:['#8f9bbd','#98a4c4','#8592b2'], water:'#4f6fa8', rock:'#7d84a0', tree:'#c04f6a', treeStyle:'mushroom', dens:0.075, accent:'#e9c7ff', flower:['#ffd1f0','#d0b0ff'], music:'rift', enemies:['slime','wisp'] });

/* --- Dataran tinggi & gunung --- */
defB('meadow',           { name:'Lembah Fajar', realm:'overworld', ground:['#4b7d3f','#548a45','#436f39'], water:'#2f6fa8', rock:'#7c8390', tree:'#2f5a2c', treeStyle:'broad', dens:0.028, accent:'#7ec35f', flower:['#f6e05e','#f687b3','#ffffff'], music:'meadow', enemies:['slime','boar'] });
defB('cherry_grove',     { name:'Rumpun Sakura', realm:'overworld', ground:['#6f9a58','#78a35f','#658d50'], water:'#3f86bd', rock:'#9a8f96', tree:'#ef9ec4', treeStyle:'cherry', dens:0.07, accent:'#ffc8e2', flower:['#ffd3e8','#ffffff'], music:'meadow', enemies:['slime','boar'] });
defB('grove',            { name:'Rimbun Bersalju', realm:'overworld', ground:['#d3dde6','#dde6ee','#c3cfda'], water:'#6fa8cf', rock:'#8d9aa6', tree:'#3d6b57', treeStyle:'snowpine', dens:0.08, accent:'#ffffff', flower:['#ffffff','#cfe8ff'], music:'snow', enemies:['revenant','wolf'] });
defB('snowy_slopes',     { name:'Lereng Salju', realm:'overworld', ground:['#e2eaf1','#edf3f8','#d3dde6'], water:'#7fb6d9', rock:'#96a3af', tree:'#46708a', treeStyle:'snowpine', dens:0.012, accent:'#ffffff', flower:['#ffffff'], music:'snow', enemies:['revenant'] });
defB('jagged_peaks',     { name:'Puncak Bergerigi', realm:'overworld', ground:['#eef5fb','#e2ecf4','#d7e3ed'], water:'#86bcdc', rock:'#aab6c2', tree:'#54788c', treeStyle:'none', dens:0, accent:'#ffffff', flower:['#ffffff'], music:'snow', rocky:true, enemies:['revenant'] });
defB('frozen_peaks',     { name:'Puncak Beku', realm:'overworld', ground:['#cfdbe6','#dce6ef','#bcc9d6'], water:'#7fb6d9', rock:'#8d9aa6', tree:'#4a6b7a', treeStyle:'snowpine', dens:0.006, accent:'#eef5fb', flower:['#ffffff','#cfe8ff'], music:'snow', rocky:true, enemies:['revenant'] });
defB('stony_peaks',      { name:'Puncak Batu', realm:'overworld', ground:['#9aa0a8','#a3a9b1','#8d939b'], water:'#4f7fa8', rock:'#767c85', tree:'#4f6b56', treeStyle:'pine', dens:0.006, accent:'#c3c9d1', flower:['#d6dce4'], music:'snow', rocky:true, enemies:['wolf','revenant'] });
defB('windswept_hills',  { name:'Bukit Terpaan Angin', realm:'overworld', ground:['#5f8a5a','#688f61','#567f52'], water:'#35759e', rock:'#7a8088', tree:'#2f5a3a', treeStyle:'pine', dens:0.03, accent:'#93c47d', flower:['#e9f0a0'], music:'forest', rocky:true, enemies:['wolf','boar'] });
defB('windswept_gravelly_hills',{ name:'Bukit Kerikil', realm:'overworld', ground:['#8a8880','#938f87','#7d7b74'], water:'#35759e', rock:'#6f6c66', tree:'#3d6b46', treeStyle:'pine', dens:0.02, accent:'#adaba2', flower:['#d6d2c6'], music:'forest', rocky:true, enemies:['wolf','bandit'] });
defB('windswept_forest', { name:'Hutan Terpaan Angin', realm:'overworld', ground:['#4f7a4a','#568150','#476f44'], water:'#35759e', rock:'#787e86', tree:'#28522f', treeStyle:'pine', dens:0.085, accent:'#7fb463', flower:['#d9e9a0'], music:'forest', enemies:['wolf','wisp'] });

/* --- Hutan --- */
defB('forest',           { name:'Hutan Bisik', realm:'overworld', ground:['#2f5a38','#36663f','#284d31'], water:'#245f8f', rock:'#6b7280', tree:'#1d4024', treeStyle:'broad', dens:0.1, accent:'#4d8a52', flower:['#a7f3d0','#93c5fd'], music:'forest', enemies:['wolf','wisp'] });
defB('flower_forest',    { name:'Hutan Bunga', realm:'overworld', ground:['#4f8447','#588d4e','#487c41'], water:'#2f7fae', rock:'#8a8f96', tree:'#2a5c33', treeStyle:'broad', dens:0.07, accent:'#ffd1e8', flower:['#ff8fb1','#ffe07a','#c9a0ff','#ffffff'], music:'meadow', enemies:['slime','wisp'] });
defB('birch_forest',     { name:'Hutan Birch', realm:'overworld', ground:['#4f7f4c','#578853','#477646'], water:'#2f7fae', rock:'#9aa0a8', tree:'#79a05c', treeStyle:'birch', dens:0.095, accent:'#d9e8b0', flower:['#f0f4c0'], music:'forest', enemies:['wolf','wisp'] });
defB('old_growth_birch_forest',{ name:'Hutan Birch Purba', realm:'overworld', ground:['#456f44','#4d784a','#3d663e'], water:'#2a749f', rock:'#8f959d', tree:'#6c9750', treeStyle:'birch', dens:0.12, accent:'#cfe0a0', flower:['#eaf0b8'], music:'forest', enemies:['wolf','wisp'] });
defB('dark_forest',      { name:'Hutan Kelam', realm:'overworld', ground:['#26402a','#2c4830','#203725'], water:'#1f4f70', rock:'#5c6168', tree:'#152b18', treeStyle:'dark', dens:0.16, accent:'#38603c', flower:['#8fbf8f'], music:'swamp', dark:0.2, enemies:['wolf','bandit'] });
defB('pale_garden',      { name:'Taman Pucat', realm:'overworld', ground:['#5f6b62','#68746a','#57635b'], water:'#4a6b78', rock:'#7d857f', tree:'#93a08f', treeStyle:'dark', dens:0.13, accent:'#c6cfc0', flower:['#e0e6d8','#b8c0ae'], music:'rift', dark:0.16, enemies:['wisp','bandit'] });
defB('taiga',            { name:'Taiga', realm:'overworld', ground:['#3a5f46','#41684d','#335540'], water:'#2a6b8f', rock:'#767c85', tree:'#22452f', treeStyle:'pine', dens:0.11, accent:'#4f7f5a', flower:['#b0d8c0'], music:'forest', enemies:['wolf','boar'] });
defB('old_growth_pine_taiga',{ name:'Taiga Pinus Purba', realm:'overworld', ground:['#35563f','#3c5f46','#2e4c38'], water:'#265f80', rock:'#6f757d', tree:'#1d3c28', treeStyle:'pine', dens:0.14, accent:'#48744f', flower:['#a0c8b0'], music:'forest', enemies:['wolf','lurker'] });
defB('old_growth_spruce_taiga',{ name:'Taiga Spruce Purba', realm:'overworld', ground:['#2f4f3c','#365842','#294636'], water:'#245874', rock:'#6b7178', tree:'#193425', treeStyle:'pine', dens:0.15, accent:'#3f6b48', flower:['#98c0a8'], music:'forest', enemies:['wolf','lurker'] });
defB('snowy_taiga',      { name:'Taiga Bersalju', realm:'overworld', ground:['#c9d6df','#d4e0e8','#bac8d2'], water:'#6fa8cf', rock:'#8d9aa6', tree:'#2f5545', treeStyle:'snowpine', dens:0.1, accent:'#ffffff', flower:['#ffffff'], music:'snow', enemies:['revenant','wolf'] });
defB('jungle',           { name:'Rimba Tropis', realm:'overworld', ground:['#2f6b34','#36743a','#285d2e'], water:'#1f8f8f', rock:'#6f7a68', tree:'#164d20', treeStyle:'jungle', dens:0.17, accent:'#5fbf4f', flower:['#ffca3a','#ff7ab8'], music:'forest', enemies:['wisp','lurker'] });
defB('sparse_jungle',    { name:'Rimba Renggang', realm:'overworld', ground:['#3a7a3f','#428345','#346e39'], water:'#26989a', rock:'#78836f', tree:'#1d5a26', treeStyle:'jungle', dens:0.075, accent:'#6fd05a', flower:['#ffd24d'], music:'forest', enemies:['wisp','boar'] });
defB('bamboo_jungle',    { name:'Rimba Bambu', realm:'overworld', ground:['#4f8a45','#58934c','#457f3e'], water:'#26989a', rock:'#7f886f', tree:'#8fbf4a', treeStyle:'bamboo', dens:0.19, accent:'#b8e06a', flower:['#e0f08a'], music:'forest', enemies:['wisp','lurker'] });

/* --- Rawa & lahan basah --- */
defB('swamp',            { name:'Rawa Kelam', realm:'overworld', ground:['#3d4a35','#46543c','#35402f'], water:'#3c4a35', rock:'#5b5f52', tree:'#2b3526', treeStyle:'dark', dens:0.07, accent:'#5d6b45', flower:['#9ae6b4','#68d391'], music:'swamp', waterLvl:0.45, enemies:['lurker','bandit'] });
defB('mangrove_swamp',   { name:'Rawa Bakau', realm:'overworld', ground:['#3a5540','#415e47','#334c39'], water:'#33513f', rock:'#5f6656', tree:'#24402b', treeStyle:'mangrove', dens:0.12, accent:'#6f8f55', flower:['#8fd6a0'], music:'swamp', waterLvl:0.5, enemies:['lurker','drowned'] });
defB('river',            { name:'Sungai', realm:'overworld', ground:['#5f8a55','#68935c','#567f4e'], water:'#2f7fbe', rock:'#7c8390', tree:'#2f5a2c', treeStyle:'broad', dens:0.02, accent:'#8fd0ff', flower:['#cfe8ff'], music:'meadow', fluid:true, waterLvl:0.7, enemies:['drowned','slime'] });
defB('frozen_river',     { name:'Sungai Beku', realm:'overworld', ground:['#d3dde6','#dde6ee','#c3cfda'], water:'#8fc4e0', rock:'#96a3af', tree:'#4a6b7a', treeStyle:'snowpine', dens:0.01, accent:'#ffffff', flower:['#ffffff'], music:'snow', fluid:true, waterLvl:0.7, enemies:['revenant'] });

/* --- Dataran rendah & kering --- */
defB('plains',           { name:'Dataran Luas', realm:'overworld', ground:['#5f9a4f','#68a356','#568f48'], water:'#2f7fbe', rock:'#8a9096', tree:'#33663a', treeStyle:'broad', dens:0.012, accent:'#8fc46a', flower:['#ffe07a','#ffffff'], music:'meadow', enemies:['slime','boar'] });
defB('sunflower_plains', { name:'Dataran Bunga Matahari', realm:'overworld', ground:['#6ba455','#74ad5c','#619a4e'], water:'#2f7fbe', rock:'#8f9599', tree:'#38703f', treeStyle:'broad', dens:0.01, accent:'#ffd24d', flower:['#ffd24d','#ffb02e'], music:'meadow', enemies:['slime','boar'] });
defB('snowy_plains',     { name:'Dataran Bersalju', realm:'overworld', ground:['#dfe8ef','#e9f1f6','#d0dae3'], water:'#7fb6d9', rock:'#9aa6b1', tree:'#4f7080', treeStyle:'snowpine', dens:0.008, accent:'#ffffff', flower:['#ffffff'], music:'snow', enemies:['revenant'] });
defB('ice_spikes',       { name:'Taring Es', realm:'overworld', ground:['#e6eef5','#f0f6fa','#d8e2ea'], water:'#86bcdc', rock:'#b6d0e0', tree:'#8fc8e6', treeStyle:'crystal', dens:0.05, accent:'#ffffff', flower:['#cfe8ff'], music:'snow', enemies:['revenant'] });
defB('desert',           { name:'Gurun', realm:'overworld', ground:['#e2c98a','#eacf92','#d7bd7e'], water:'#2f9fbe', rock:'#c0a878', tree:'#7f8f4a', treeStyle:'palm', dens:0.012, accent:'#fff0b0', flower:['#ffd88a'], music:'ash', sandy:true, enemies:['husk','bandit'] });
defB('savanna',          { name:'Sabana', realm:'overworld', ground:['#a8a055','#b1a95c','#9a924e'], water:'#3f8fae', rock:'#9f9670', tree:'#6f7f3a', treeStyle:'broad', dens:0.02, accent:'#d0c46a', flower:['#e8d88a'], music:'ash', enemies:['husk','boar'] });
defB('savanna_plateau',  { name:'Plato Sabana', realm:'overworld', ground:['#9c9450','#a59d57','#8e8749'], water:'#3f8fae', rock:'#968d68', tree:'#66763a', treeStyle:'broad', dens:0.014, accent:'#c6ba62', flower:['#e0d080'], music:'ash', rocky:true, enemies:['husk','bandit'] });
defB('windswept_savanna', { name:'Sabana Terpaan Angin', realm:'overworld', ground:['#8f8a4f','#989356','#827d48'], water:'#3f8fae', rock:'#8d8560', tree:'#5f6f35', treeStyle:'broad', dens:0.01, accent:'#b8ae5c', flower:['#d8c878'], music:'ash', rocky:true, enemies:['husk','bandit'] });
defB('badlands',         { name:'Tanah Gersang', realm:'overworld', ground:['#b4663f','#bd6f46','#a65c39'], water:'#a03c1e', rock:'#8f5236', tree:'#6f5a30', treeStyle:'dead', dens:0.01, accent:'#e08a4f', flower:['#f0a860'], music:'ash', sandy:true, enemies:['husk','fiend'] });
defB('wooded_badlands',  { name:'Gersang Berhutan', realm:'overworld', ground:['#a8724a','#b17b51','#9a6843'], water:'#a03c1e', rock:'#8a5638', tree:'#5f7a3a', treeStyle:'broad', dens:0.05, accent:'#d89a5f', flower:['#e8b070'], music:'ash', enemies:['husk','fiend'] });
defB('eroded_badlands',  { name:'Gersang Terkikis', realm:'overworld', ground:['#c07248','#c97b50','#b26841'], water:'#a03c1e', rock:'#96583a', tree:'#75603a', treeStyle:'dead', dens:0.008, accent:'#f09a58', flower:['#ffb070'], music:'ash', rocky:true, enemies:['fiend','husk'] });

/* --- Gua & bawah tanah --- */
defB('dripstone_caves',  { name:'Gua Tetes Batu', realm:'cave', ground:['#7a6a5c','#836f61','#6e5f52'], water:'#3f5f7a', rock:'#5f5248', tree:'#8a7a68', treeStyle:'crystal', dens:0.05, accent:'#a89078', flower:['#c0a890'], music:'ash', dark:0.45, enemies:['crawler','lurker'] });
defB('lush_caves',       { name:'Gua Subur', realm:'cave', ground:['#3f6b45','#47744c','#37603e'], water:'#2f8f9f', rock:'#55604f', tree:'#2a5a34', treeStyle:'jungle', dens:0.12, accent:'#8fd06a', flower:['#ffd24d','#a0f0c0'], music:'forest', dark:0.32, enemies:['crawler','wisp'] });
defB('deep_dark',        { name:'Kelam Dalam', realm:'cave', ground:['#232a30','#28313a','#1e252b'], water:'#1f3a4a', rock:'#333d46', tree:'#2f4a55', treeStyle:'crystal', dens:0.03, accent:'#3fa0a8', flower:['#2fd0d8'], music:'rift', dark:0.62, enemies:['deepstalker','crawler'] });

/* --- The Nether --- */
defB('nether_wastes',    { name:'Nether Wastes', realm:'nether', ground:['#6b2b26','#75322c','#5f2521'], water:'#ff6a1e', rock:'#8a3c2f', tree:'#8f4a2a', treeStyle:'dead', dens:0.012, accent:'#ff8a4f', flower:['#ffb070'], music:'ash', dark:0.18, enemies:['emberfiend','fiend'] });
defB('crimson_forest',   { name:'Hutan Crimson', realm:'nether', ground:['#7a1f2a','#85242f','#6d1b25'], water:'#ff6a1e', rock:'#8f2f36', tree:'#c0303f', treeStyle:'fungus_red', dens:0.13, accent:'#ff5f6f', flower:['#ff7a8a'], music:'ash', dark:0.2, enemies:['emberfiend','soulwisp'] });
defB('warped_forest',    { name:'Hutan Warped', realm:'nether', ground:['#1f5a5f','#246368','#1a5055'], water:'#ff6a1e', rock:'#2a6f6f', tree:'#2fa0a8', treeStyle:'fungus_blue', dens:0.13, accent:'#3fd8d0', flower:['#5ff0e0'], music:'rift', dark:0.22, enemies:['soulwisp','emberfiend'] });
defB('soul_sand_valley', { name:'Lembah Soul Sand', realm:'nether', ground:['#4f4438','#584c3f','#453b31'], water:'#ff6a1e', rock:'#5f5244', tree:'#7f7060', treeStyle:'dead', dens:0.03, accent:'#5fd8e8', flower:['#7fe8f0'], music:'rift', sandy:true, dark:0.3, enemies:['soulwisp','emberfiend'] });
defB('basalt_deltas',    { name:'Delta Basalt', realm:'nether', ground:['#3a3438','#423b40','#332e32'], water:'#ff5a10', rock:'#2c2629', tree:'#5f4f52', treeStyle:'dead', dens:0.02, accent:'#ff7a3f', flower:['#ff9a5f'], music:'ash', rocky:true, dark:0.28, enemies:['emberfiend','fiend'] });

/* --- The End --- */
defB('the_end',          { name:'The End', realm:'end', ground:['#d8d0a8','#e0d8b0','#cfc79f'], water:'#0a0812', rock:'#3a3350', tree:'#4a3f6b', treeStyle:'crystal', dens:0.01, accent:'#c9b8ff', flower:['#c07bff'], music:'rift', dark:0.34, enemies:['voidshade'] });
defB('small_end_islands',{ name:'Pulau Kecil End', realm:'end', ground:['#cfc79f','#d8d0a8','#c6be96'], water:'#0a0812', rock:'#342e48', tree:'#443a63', treeStyle:'crystal', dens:0.02, accent:'#b8a8f0', flower:['#a07bff'], music:'rift', dark:0.4, enemies:['voidshade'] });
defB('end_midlands',     { name:'End Midlands', realm:'end', ground:['#ded6ae','#e6deb6','#d4cca4'], water:'#0a0812', rock:'#3f3757', tree:'#50446f', treeStyle:'crystal', dens:0.03, accent:'#d0c0ff', flower:['#c07bff','#7dd3fc'], music:'rift', dark:0.3, enemies:['voidshade','rift_spawn'] });
defB('end_highlands',    { name:'End Highlands', realm:'end', ground:['#e6deb6','#eee6be','#dcd4ac'], water:'#0a0812', rock:'#463c60', treeStyle:'crystal', tree:'#5c4e7f', dens:0.05, accent:'#e0d0ff', flower:['#c07bff','#ffe9a8'], music:'rift', dark:0.26, enemies:['voidshade','rift_spawn'] });
defB('end_barrens',      { name:'End Barrens', realm:'end', ground:['#c6be96','#cec69e','#bcb48e'], water:'#0a0812', rock:'#312b45', tree:'#3f3760', treeStyle:'none', dens:0, accent:'#a898e0', flower:['#9a7bff'], music:'rift', dark:0.42, enemies:['voidshade'] });

const REALM_LABEL = { overworld:'Overworld', cave:'Gua & Bawah Tanah', nether:'The Nether', end:'The End' };
const BIOME_GROUPS = [
  { label:'Lautan & Pesisir', ids:['ocean','deep_ocean','warm_ocean','lukewarm_ocean','deep_lukewarm_ocean','cold_ocean','deep_cold_ocean','frozen_ocean','deep_frozen_ocean','beach','snowy_beach','stony_shore','mushroom_fields'] },
  { label:'Dataran Tinggi & Gunung', ids:['meadow','cherry_grove','grove','snowy_slopes','jagged_peaks','frozen_peaks','stony_peaks','windswept_hills','windswept_gravelly_hills','windswept_forest'] },
  { label:'Hutan & Pepohonan', ids:['forest','flower_forest','birch_forest','old_growth_birch_forest','dark_forest','pale_garden','taiga','old_growth_pine_taiga','old_growth_spruce_taiga','snowy_taiga','jungle','sparse_jungle','bamboo_jungle'] },
  { label:'Rawa & Lahan Basah', ids:['swamp','mangrove_swamp','river','frozen_river'] },
  { label:'Dataran Rendah & Kering', ids:['plains','sunflower_plains','snowy_plains','ice_spikes','desert','savanna','savanna_plateau','windswept_savanna','badlands','wooded_badlands','eroded_badlands'] },
  { label:'Gua & Bawah Tanah', ids:['dripstone_caves','lush_caves','deep_dark'] },
  { label:'The Nether', ids:['nether_wastes','crimson_forest','warped_forest','soul_sand_valley','basalt_deltas'] },
  { label:'The End', ids:['the_end','small_end_islands','end_midlands','end_highlands','end_barrens'] },
];

/* ---------- Kisah tunggal (tanpa bab) ---------- */
const STORY = {
  title: 'Lonceng Yang Pecah',
  est: 27,
  opening: 'Lonceng Serambi pecah semalam dan kabut Aether mulai merangkak turun. Tetua Rangga menunggumu di balai kota.',
  steps: [
    { type:'talk', npc:'rangga', text:'Bicara dengan Tetua Rangga di Kota Serambi',
      story:'Kabut Aether menebal di luar pagar. Rangga memanggilmu sebelum semuanya terlambat.', reward:{ gold:150, items:[['p_potion',2]] } },
    { type:'kill', target:['slime','boar','husk','crawler','drowned','wolf'], count:6, text:'Bersihkan 6 makhluk di sekitar kota',
      story:'Petani tak berani keluar. Buka jalan bagi mereka.', reward:{ gold:250, items:[['m_stone',3]] } },
    { type:'talk', npc:'rangga', text:'Lapor kembali ke Tetua Rangga',
      story:'"Retakan ini bukan besi yang lelah," kata Rangga. "Ini Aether yang bocor."', reward:{ gold:200 } },
    { type:'talk', npc:'mira', text:'Temui Mira, Juru Lelang',
      story:'Untuk melawan kabut kau butuh besi yang lebih baik — dan besi yang baik lewat Balai Lelang.', reward:{ gold:150 } },
    { type:'buy', count:1, text:'Beli 1 barang apa pun di Balai Lelang',
      story:'"Beli saat orang panik, jual saat orang serakah," kata Mira.', reward:{ gold:300, items:[['m_stone',2]] } },
    { type:'plus', min:3, text:'Tempa senjata hingga +3 di Pandai Besi Borin',
      story:'Borin menyalakan tungku. Tiga tingkat pertama aman — sisanya urusan nyali.', reward:{ gold:400, items:[['m_protect',1],['m_stone',3]] } },
    { type:'explore', biomes:['forest','dark_forest','taiga','birch_forest','old_growth_pine_taiga','jungle','windswept_forest','flower_forest','old_growth_birch_forest','sparse_jungle','bamboo_jungle','old_growth_spruce_taiga','snowy_taiga','pale_garden'], text:'Jelajah keluar kota sampai menemukan kawasan hutan',
      story:'Peta lama Rangga menunjuk hutan di balik bukit. Dunia di luar terus tersusun sendiri saat kau berjalan.', reward:{ gold:350, items:[['p_potion',3]] } },
    { type:'kill', target:['wolf','wisp','lurker','bandit'], count:10, text:'Kalahkan 10 makhluk liar di luar kota',
      story:'Sesuatu membuat makhluk hutan gelisah — mereka menjauh dari arah rawa.', reward:{ gold:600, items:[['m_stone',4]] } },
    { type:'kill', target:['alpha'], count:1, text:'Tumbangkan Taring Alfa (bos)', boss:'alpha',
      story:'Sang alfa berjaga di bekas menara pengintai. Ia tidak akan menyerang lebih dulu — tapi ia tidak akan minggir.', reward:{ gold:1200, items:[['g_ruby',1],['m_stone',5]] } },
    { type:'collect', item:'m_relic', count:4, text:'Kumpulkan 4 Pusaka Terbenam dari penghuni rawa',
      story:'Pusaka-pusaka berlumpur itu menyusun satu lambang: mata terbuka di atas celah.', reward:{ gold:1400, items:[['g_onyx',1],['m_enchant',2]] } },
    { type:'socket', count:1, text:'Pasang 1 permata pada peralatanmu (Tukang Permata Wen)',
      story:'"Slot kosong itu janji yang belum ditepati," kata Wen.', reward:{ gold:900, items:[['g_sapphire',1]] } },
    { type:'enchant', count:1, text:'Rapal 1 sihir pada peralatan (Perapal Ilya)',
      story:'Ilya menuang tinta Aether. "Sihir acak. Itu sebabnya ia jujur."', reward:{ gold:1100, items:[['m_enchant',2]] } },
    { type:'kill', target:['magmaris'], count:1, text:'Kalahkan Magmaris, Golem Abu (bos)', boss:'magmaris',
      story:'Kultus Celah membakar Aether di tanah gersang. Penjaganya golem abu yang tidur berdiri.', reward:{ gold:2600, items:[['m_stone_hi',4],['g_ruby_hi',1],['m_essence',1]] } },
    { type:'inherit', count:1, text:'Wariskan tempaan ke item baru (Balai Warisan Nadia)',
      story:'"Besi mati, tempaan hidup," kata Nadia. "Bawa yang lama, aku pindahkan jiwanya."', reward:{ gold:1800, items:[['m_stone_hi',3],['g_star',1]] } },
    { type:'realm', realm:'nether', text:'Temukan gerbang panas di luar batas dunia (The Nether)',
      story:'Kabut mengalir dari retakan jauh di luar peta. Terus berjalan — dunia akan terus tumbuh di depanmu.', reward:{ gold:2400, items:[['p_potion_hi',4],['m_protect',2]] } },
    { type:'kill', target:['vaelor'], count:1, text:'Kalahkan Vaelor, Sang Celah (bos terakhir)', boss:'vaelor',
      story:'Di tepi celah, Vaelor menunggu dengan sabar. Habiskan persiapanmu.', reward:{ gold:9000, items:[['m_riftshard',2],['w_rift',1]] } },
  ],
  ending: 'Kabut surut. Serambi berdentang lagi — kali ini dari perunggu yang kau bawa turun dari celah.',
};

/* ---------- Pengaturan grafis ---------- */
const SETTINGS = {
  fpsCap: 60,            // 30 | 60 | 120 | 0 (tanpa batas)
  dlss: 'off',           // off | quality | balanced | performance | ultra
  showFps: true,
  pixelZoom: 3,          // piksel layar per piksel game
  touchControls: 'auto', // auto | always | off
  music: true, sfx: true,
};
const DLSS_MODES = {
  off:        { label:'Mati (native)',        scale:1.00, sharp:0 },
  quality:    { label:'DLSS 4 · Kualitas',    scale:0.83, sharp:0.35 },
  balanced:   { label:'DLSS 4 · Seimbang',    scale:0.70, sharp:0.5 },
  performance:{ label:'DLSS 4 · Performa',    scale:0.58, sharp:0.65 },
  ultra:      { label:'DLSS 4 · Ultra Performa', scale:0.45, sharp:0.8 },
};

/* ---------- NPC dialogue ---------- */
const NPC_LINES = {
  rangga: {
    name:'Tetua Rangga', role:'Tetua Kota', tint:'#e9d5a1',
    idle:['"Jaga dirimu. Kabut membuat besi berbisik."'],
  },
  mira:   { name:'Mira', role:'Juru Lelang', tint:'#f6a5c0', panel:'auction',
    idle:['"Grafik tidak pernah bohong, pembeli yang bohong pada diri sendiri."'] },
  borin:  { name:'Borin', role:'Pandai Besi', tint:'#d98c4a', panel:'enhance',
    idle:['"Mau +10? Siapkan gulungan perlindungan, atau siapkan hatimu."'] },
  wen:    { name:'Wen', role:'Tukang Permata', tint:'#7dd3fc', panel:'socket',
    idle:['"Slot kosong itu janji yang belum ditepati."'] },
  ilya:   { name:'Ilya', role:'Perapal Sihir', tint:'#c07bff', panel:'enchant',
    idle:['"Sihir acak. Itu sebabnya ia jujur."'] },
  nadia:  { name:'Nadia', role:'Juru Warisan', tint:'#f5b53c', panel:'inherit',
    idle:['"Besi mati, tempaan hidup. Bawa yang lama, aku pindahkan jiwanya."'] },
  tama:   { name:'Tama', role:'Pedagang Keliling', tint:'#9ae6b4', panel:'shop',
    idle:['"Ramuan, batu, gulungan. Harga tetap, tanpa drama pasar."'] },
  sela:   { name:'Pengintai Sela', role:'Pengintai', tint:'#6fe08a',
    idle:['"Aku hampir jadi makan malam serigala itu."'] },
};
