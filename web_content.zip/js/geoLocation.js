/**
 * geoLocation.js
 * Wrapper sobre a Geolocation API REAL do navegador (navigator.geolocation).
 * Nunca inventa coordenadas — se o navegador não conseguir localizar o
 * usuário, retorna um erro tipado para a tela tratar (permissão negada,
 * indisponível, timeout/baixa precisão), em vez de simular uma posição.
 */
const GeoLocation = {

  SUPORTADO(){ return 'geolocation' in navigator; },

  /**
   * @returns {Promise<{lat:number,lng:number,precisao:number}>}
   * @throws {Error} com `.tipo` em: 'sem_suporte' | 'permissao_negada' | 'indisponivel' | 'timeout'
   */
  obterPosicaoAtual({ altaPrecisao = true, timeoutMs = 10000 } = {}){
    return new Promise((resolve, reject) => {
      if(!this.SUPORTADO()){
        const err = new Error('Seu navegador não tem suporte a geolocalização.');
        err.tipo = 'sem_suporte';
        reject(err);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          resolve({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            precisao: pos.coords.accuracy, // metros — quanto maior, pior a precisão
          });
        },
        (erro) => {
          const err = new Error(_mensagemErro(erro));
          err.tipo = _tipoErro(erro);
          reject(err);
        },
        { enableHighAccuracy: altaPrecisao, timeout: timeoutMs, maximumAge: 60000 }
      );
    });
  },

  /**
   * Observa a posição do navegador continuamente (GPS real), para telas de
   * deslocamento em tempo real. Nunca inventa posição: se não houver suporte,
   * chama `aoErro` uma vez com erro tipado 'sem_suporte' e retorna null; erros
   * de permissão/indisponibilidade/timeout do navegador também são propagados
   * tipados via `aoErro`, sem interromper a observação (o navegador pode se
   * recuperar sozinho, ex.: sinal de GPS voltando).
   * @returns {number|null} watchId a ser usado em `pararObservacao`, ou null.
   */
  observarPosicao({ aoAtualizar, aoErro, altaPrecisao = true, timeoutMs = 15000 } = {}){
    if(!this.SUPORTADO()){
      if(aoErro){
        const err = new Error('Seu navegador não tem suporte a geolocalização.');
        err.tipo = 'sem_suporte';
        aoErro(err);
      }
      return null;
    }
    return navigator.geolocation.watchPosition(
      (pos) => {
        if(aoAtualizar){
          aoAtualizar({ lat: pos.coords.latitude, lng: pos.coords.longitude, precisao: pos.coords.accuracy });
        }
      },
      (erro) => {
        if(aoErro){
          const err = new Error(_mensagemErro(erro));
          err.tipo = _tipoErro(erro);
          aoErro(err);
        }
      },
      { enableHighAccuracy: altaPrecisao, timeout: timeoutMs, maximumAge: 20000 }
    );
  },

  /** Encerra uma observação contínua iniciada por `observarPosicao`. */
  pararObservacao(watchId){
    if(watchId != null && this.SUPORTADO()) navigator.geolocation.clearWatch(watchId);
  },
};

function _tipoErro(erro){
  switch(erro.code){
    case erro.PERMISSION_DENIED: return 'permissao_negada';
    case erro.POSITION_UNAVAILABLE: return 'indisponivel';
    case erro.TIMEOUT: return 'timeout';
    default: return 'desconhecido';
  }
}
function _mensagemErro(erro){
  switch(erro.code){
    case erro.PERMISSION_DENIED:
      return 'Você negou o acesso à localização. Ative a permissão de localização do navegador para ver oportunidades por distância.';
    case erro.POSITION_UNAVAILABLE:
      return 'Não foi possível obter sua localização agora (GPS desligado ou sinal indisponível).';
    case erro.TIMEOUT:
      return 'Tempo esgotado tentando obter sua localização. Tente novamente.';
    default:
      return 'Não foi possível obter sua localização.';
  }
}

/** Distância em km entre duas coordenadas (fórmula de Haversine). */
function distanciaKm(lat1, lng1, lat2, lng2){
  if([lat1,lng1,lat2,lng2].some(v => v == null || isNaN(v))) return null;
  const R = 6371;
  const dLat = (lat2-lat1) * Math.PI/180;
  const dLng = (lng2-lng1) * Math.PI/180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2;
  const c = 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return Math.round(R * c * 10) / 10;
}
