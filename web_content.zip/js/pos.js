/* =============================================================
   LAMPION POS · js/pos.js  (logika layar kasir)
   -------------------------------------------------------------
   Ditulis ulang dari assets/js/pos.js versi PHP.
   Perubahan utama:
     - Data menu tidak lagi dicetak server PHP, tapi dimuat lewat
       LPAPI.menus() (IndexedDB).
     - LP.api('api/orders.php', ...) tetap dipakai, namun ditangani
       router lokal (js/lp-core.js) — tidak ada HTTP/PHP sama sekali.
     - Layar pelanggan memakai BroadcastChannel (satu perangkat)
       bukan polling ke api/display.php seperti versi PHP.
   ============================================================= */
(function () {
  'use strict';

  var DB = window.LPDB;
  var PHP = window.LPHP;

  var TYPE_LABEL = { dine_in: 'Dine-in', takeaway: 'Take-away', online: 'Online' };

  var state = {
    type: 'dine_in',
    cat: 0,
    pay: 'cash',
    cart: [],        // [{id, qty}]
    heldId: 0,
    heldNo: '',
    items: [],
    cats: [],
    store: {},
    taxRate: 0
  };

  /* ---------- helper ---------- */
  function money(n) { return PHP.money(n); }
  function esc(s) { return PHP.esc(s); }
  function $(id) { return document.getElementById(id); }
  function priceFor(it) { return Number(it['price_' + state.type] || 0); }
  function itemById(id) {
    return state.items.filter(function (i) { return Number(i.id) === Number(id); })[0];
  }
  function cartCount(id) {
    var l = state.cart.filter(function (c) { return Number(c.id) === Number(id); })[0];
    return l ? l.qty : 0;
  }

  /* ---------- hitung total (padanan _totals() sisi server) ---------- */
  function cartTotals() {
    var subtotal = 0;
    state.cart.forEach(function (l) {
      var it = itemById(l.id);
      if (it) { subtotal += priceFor(it) * l.qty; }
    });
    var dEl = $('inp-discount');
    var discount = dEl ? PHP.parseMoney(dEl.value) : 0;
    return PHP.computeTotals(subtotal, discount, state.taxRate);
  }

  /* ---------- kanal layar pelanggan (pengganti polling PHP) ---------- */
  var Display = (function () {
    var ch = null;
    var key = '';
    try { key = localStorage.getItem('lamp_display_key') || ''; } catch (e) { key = ''; }
    try {
      if (window.BroadcastChannel) { ch = new BroadcastChannel('lamp_display'); }
    } catch (e2) { ch = null; }

    function on() { return !!key && !!ch; }
    function send(msg) {
      if (!on()) { return; }
      try {
        ch.postMessage(Object.assign({ key: key, at: Date.now() }, msg));
      } catch (e) { /* layar pelanggan opsional */ }
    }
    function snapshot() {
      var t = cartTotals();
      var cu = $('inp-customer');
      return {
        status: state.cart.length === 0 ? 'idle' : 'order',
        items: state.cart.map(function (l) {
          var it = itemById(l.id);
          return { name: it ? String(it.name) : '', qty: l.qty, price: priceFor(it || {}) };
        }),
        type_label: TYPE_LABEL[state.type] || state.type,
        customer: cu ? String(cu.value || '').trim() : '',
        subtotal: t.subtotal, discount: t.discount, tax: t.tax, total: t.total
      };
    }
    function push() {
      if (!on()) { return; }
      send({ action: state.cart.length === 0 ? 'reset' : 'set', payload: snapshot() });
    }
    var timer = null;
    function schedule() {
      if (!on()) { return; }
      clearTimeout(timer);
      timer = setTimeout(push, 200);
    }
    function paid(total, orderNo) {
      send({ action: 'paid', total: total, order_number: orderNo });
    }
    return { on: on, schedule: schedule, paid: paid, push: push };
  })();

  /* ---------- render katalog ---------- */
  function renderChips() {
    var host = $('cat-chips');
    if (!host) { return; }
    var html = '<span class="chip' + (Number(state.cat) === 0 ? ' active' : '') +
      '" data-cat="0">Semua</span>';
    state.cats.forEach(function (c) {
      html += '<span class="chip' + (Number(state.cat) === Number(c.id) ? ' active' : '') +
        '" data-cat="' + Number(c.id) + '">' + esc(c.name) + '</span>';
    });
    host.innerHTML = html;
  }

  function renderGrid() {
    var host = $('prod-grid');
    if (!host) { return; }
    var q = '';
    var s = $('pos-search');
    if (s) { q = String(s.value || '').toLowerCase().trim(); }

    var list = state.items.filter(function (it) {
      if (Number(state.cat) !== 0 && Number(it.category_id) !== Number(state.cat)) { return false; }
      if (q !== '' && String(it.name).toLowerCase().indexOf(q) === -1) { return false; }
      return true;
    });

    if (list.length === 0) {
      host.innerHTML = '<div class="empty-state"><b>Tidak ada menu</b>' +
        (q !== '' ? 'Coba kata kunci lain.' : 'Tambahkan menu lewat halaman Menu.') + '</div>';
      return;
    }

    var catName = {};
    state.cats.forEach(function (c) { catName[Number(c.id)] = String(c.name); });

    host.innerHTML = list.map(function (it) {
      var n = cartCount(it.id);
      var cat = catName[Number(it.category_id)] || '';
      return '<div class="prod-card" data-id="' + Number(it.id) + '">' +
        (n > 0 ? '<span class="qty-tag">' + n + '</span>' : '') +
        '<div class="name">' + esc(it.name) + '</div>' +
        '<div class="cat">' + esc(cat) + '</div>' +
        '<div class="price">' + money(priceFor(it)) + '</div>' +
        '</div>';
    }).join('');
  }

  /* ---------- render keranjang ---------- */
  function renderCart() {
    var host = $('cart-lines');
    if (!host) { return; }

    if (state.cart.length === 0) {
      host.innerHTML = '<div class="empty-state"><b>Keranjang kosong</b>' +
        'Pilih menu di sebelah kiri.</div>';
    } else {
      host.innerHTML = state.cart.map(function (l, idx) {
        var it = itemById(l.id);
        if (!it) { return ''; }
        var price = priceFor(it);
        return '<div class="cart-line">' +
          '<div class="cl-main">' +
          '<div class="cl-name">' + esc(it.name) + '</div>' +
          '<div class="cl-price">' + money(price) + ' x ' + l.qty + '</div>' +
          '</div>' +
          '<div class="stepper">' +
          '<button type="button" data-dec="' + idx + '">&minus;</button>' +
          '<span class="q">' + l.qty + '</span>' +
          '<button type="button" data-inc="' + idx + '">+</button>' +
          '</div>' +
          '<div class="cl-sub">' + money(price * l.qty) + '</div>' +
          '<button type="button" class="cl-del" data-del="' + idx + '">&times;</button>' +
          '</div>';
      }).join('');
    }

    var t = cartTotals();
    if ($('t-subtotal')) { $('t-subtotal').textContent = money(t.subtotal); }
    if ($('t-tax')) { $('t-tax').textContent = money(t.tax); }
    /* Pajak 0 -> baris pajak disembunyikan supaya tidak mengganggu */
    if ($('row-tax')) { $('row-tax').style.display = (Number(t.tax) > 0) ? '' : 'none'; }
    if ($('t-total')) { $('t-total').textContent = money(t.total); }
    if ($('charge-btn')) { $('charge-btn').disabled = state.cart.length === 0; }

    if ($('cart-title')) {
      $('cart-title').textContent = state.heldId > 0
        ? 'Edit Hold ' + state.heldNo
        : 'Pesanan Baru';
    }
    var hb = $('hold-badge');
    if (hb) {
      if (state.heldId > 0) { hb.style.display = ''; hb.textContent = 'Hold ' + state.heldNo; }
      else { hb.style.display = 'none'; }
    }
  }

  /* ---------- operasi keranjang ---------- */
  function addItem(id) {
    id = Number(id);
    var it = itemById(id);
    if (!it) { return; }
    var line = state.cart.filter(function (c) { return Number(c.id) === id; })[0];
    if (line) { line.qty += 1; } else { state.cart.push({ id: id, qty: 1 }); }
    renderGrid();
    renderCart();
    Display.schedule();
  }

  function changeQty(idx, delta) {
    var line = state.cart[idx];
    if (!line) { return; }
    line.qty += delta;
    if (line.qty <= 0) { state.cart.splice(idx, 1); }
    renderGrid();
    renderCart();
    Display.schedule();
  }

  function removeLine(idx) {
    state.cart.splice(idx, 1);
    renderGrid();
    renderCart();
    Display.schedule();
  }

  function clearCart() {
    state.cart = [];
    state.heldId = 0;
    state.heldNo = '';
    if ($('inp-discount')) { $('inp-discount').value = '0'; }
    renderGrid();
    renderCart();
    Display.schedule();
  }

  /* ---------- daftar hold ---------- */
  function renderHolds(holds) {
    var host = $('holds-list');
    if (!host) { return; }
    if (!holds || holds.length === 0) {
      host.innerHTML = '<div class="text-muted" style="font-size:12px">Tidak ada hold.</div>';
      return;
    }
    host.innerHTML = holds.map(function (h) {
      return '<div class="hold-item">' +
        '<div class="hi-main"><b>' + esc(h.order_number) + '</b>' +
        '<small>' + esc(h.customer_name || h.type_label) + ' &middot; ' +
        esc(h.created_label) + '</small></div>' +
        '<span class="hi-total">' + money(h.total) + '</span>' +
        '<button class="btn btn-sm" type="button" data-hold-load="' + Number(h.id) + '">Buka</button>' +
        '<button class="btn btn-sm btn-danger" type="button" data-hold-del="' +
        Number(h.id) + '">&times;</button>' +
        '</div>';
    }).join('');
  }

  function refreshHeld() {
    return LP.api('api/orders.php', { method: 'GET' })
      .then(function (res) { renderHolds(res.holds || []); })
      .catch(function () { renderHolds([]); });
  }

  /* ---------- simpan / buka / batalkan hold ---------- */
  function doHold() {
    if (state.cart.length === 0) {
      LP.toast('Keranjang masih kosong.', 'warn');
      return Promise.resolve();
    }
    var body = {
      order_type: state.type,
      customer_name: ($('inp-customer') || {}).value || '',
      discount: ($('inp-discount') || {}).value || 0,
      items: state.cart.map(function (l) { return { menu_id: l.id, qty: l.qty }; })
    };
    var isEdit = state.heldId > 0;
    body.action = isEdit ? 'update_hold' : 'hold';
    if (isEdit) { body.order_id = state.heldId; }

    return LP.api('api/orders.php', { method: 'POST', body: JSON.stringify(body) })
      .then(function () {
        LP.toast(isEdit ? 'Hold diperbarui.' : 'Pesanan ditahan.', 'ok');
        clearCart();
        return refreshHeld();
      })
      .catch(function (e) { LP.toast(e.message, 'err'); });
  }

  function loadHold(orderId) {
    return LP.api('api/orders.php?id=' + Number(orderId), { method: 'GET' })
      .then(function (res) {
        var o = res.order;
        if (!o) { throw new Error('Order tidak ditemukan.'); }
        state.heldId = Number(o.id);
        state.heldNo = String(o.order_number);
        state.type = String(o.order_type);
        state.cart = (o.items || []).map(function (it) {
          return { id: Number(it.menu_id), qty: Number(it.qty) || 1 };
        });
        if ($('inp-customer')) { $('inp-customer').value = o.customer_name || ''; }
        if ($('inp-discount')) { $('inp-discount').value = String(o.discount || 0); }

        document.querySelectorAll('.type-tab').forEach(function (b) {
          b.classList.toggle('active', b.dataset.type === state.type);
        });
        renderGrid();
        renderCart();
        LP.toast('Hold ' + state.heldNo + ' dibuka.', 'ok');
      })
      .catch(function (e) { LP.toast(e.message, 'err'); });
  }

  function cancelHold(orderId) {
    LP.confirm('Batalkan pesanan ditahan ini?').then(function (ok) {
      if (!ok) { return null; }
      return LP.api('api/orders.php', {
        method: 'POST', body: JSON.stringify({ action: 'cancel', order_id: Number(orderId) })
      }).then(function () {
        LP.toast('Hold dibatalkan.', 'ok');
        if (Number(orderId) === Number(state.heldId)) { clearCart(); }
        return refreshHeld();
      }).catch(function (e) { LP.toast(e.message, 'err'); });
    });
  }

  /* ---------- modal pembayaran ---------- */
  function openPay() {
    if (state.cart.length === 0) {
      LP.toast('Keranjang masih kosong.', 'warn');
      return;
    }
    var t = cartTotals();
    if ($('pay-total')) { $('pay-total').textContent = money(t.total); }
    if ($('inp-received')) { $('inp-received').value = String(Math.ceil(t.total)); }
    state.pay = 'cash';
    document.querySelectorAll('.pay-btn').forEach(function (b) {
      b.classList.toggle('active', b.dataset.pm === 'cash');
    });
    updateCashUI();
    LP.openModal('modal-pay');
  }

  function updateCashUI() {
    var t = cartTotals();
    var isCash = (state.pay === 'cash');
    if ($('cash-field')) { $('cash-field').style.display = isCash ? '' : 'none'; }

    var recEl = $('inp-received');
    var rec = recEl ? PHP.parseMoney(recEl.value) : 0;
    var change = (rec > t.total) ? rec - t.total : 0;
    if ($('change-hint')) {
      $('change-hint').textContent = isCash
        ? 'Kembalian: ' + money(change)
        : 'Pembayaran non-tunai — tidak perlu uang diterima.';
    }

    /* chip nominal cepat (uang pas + nominal umum) */
    var qa = $('quick-amounts');
    if (qa && isCash) {
      var exact = Math.round(t.total);
      var html = '<span class="chip" data-quick="' + exact + '">Uang Pas</span>';
      [20000, 50000, 100000, 150000, 200000].forEach(function (v) {
        html += '<span class="chip" data-quick="' + v + '">' + money(v) + '</span>';
      });
      qa.innerHTML = html;
    }
  }

  /* ---------- proses bayar ---------- */
  function doPay() {
    if (state.cart.length === 0) {
      return LP.toast('Keranjang masih kosong.', 'warn');
    }
    var t = cartTotals();
    var btn = $('pay-ok');
    var body = {
      action: 'create',
      order_type: state.type,
      customer_name: ($('inp-customer') || {}).value || '',
      discount: ($('inp-discount') || {}).value || 0,
      payment_method: state.pay,
      items: state.cart.map(function (l) { return { menu_id: l.id, qty: l.qty }; })
    };
    if (state.heldId > 0) { body.order_id = state.heldId; }

    if (state.pay === 'cash') {
      var rec = $('inp-received') ? PHP.parseMoney($('inp-received').value) : 0;
      if (rec < t.total) {
        return LP.toast('Uang diterima kurang dari total tagihan.', 'warn');
      }
      body.received = rec;
    }

    if (btn) { btn.disabled = true; btn.textContent = 'Memproses…'; }

    return LP.api('api/orders.php', { method: 'POST', body: JSON.stringify(body) })
      .then(function (res) {
        LP.closeModal('modal-pay');
        showReceipt(res.order, res.store || state.store);
        refreshHeld();
        sendKitchenTicket(res.order, res.store || state.store);
      })
      .catch(function (e) {
        LP.toast(e.message, 'err', 5000);
      })
      .then(function () {
        if (btn) { btn.disabled = false; btn.textContent = 'Proses Bayar'; }
      });
  }

  /* ---------- struk ---------- */
  /** Susun teks struk (58mm/80mm) — padanan print.js versi PHP */
  function receiptText(o, store, width) {
    var COLS = (String(width) === '80') ? 48 : 32;
    var L = [];
    function line(ch) {
      var s = ''; while (s.length < COLS) { s += (ch || '-'); } L.push(s);
    }
    function center(t) {
      t = String(t);
      if (t.length >= COLS) { L.push(t); return; }
      var pad = Math.floor((COLS - t.length) / 2);
      L.push(new Array(pad + 1).join(' ') + t);
    }
    function lr(left, right) {
      left = String(left); right = String(right);
      var space = COLS - left.length - right.length;
      if (space < 1) { L.push(left + ' ' + right); return; }
      L.push(left + new Array(space + 1).join(' ') + right);
    }

    center(String(store.store_name || 'Lampion Resto'));
    if (store.store_address) { center(String(store.store_address)); }
    if (store.store_phone) { center(String(store.store_phone)); }
    line('=');
    lr('No', String(o.order_number));
    lr('Tipe', String(o.order_type_label || o.order_type || ''));
    if (o.customer_name) { lr('Pelanggan', String(o.customer_name)); }
    lr('Kasir', String(o.cashier_name || ''));
    lr('Waktu', String(o.created_label || ''));
    line('-');

    (o.items || []).forEach(function (it) {
      L.push(String(it.item_name));
      lr('  ' + it.qty + ' x ' + money(it.price), money(it.subtotal));
    });

    line('-');
    lr('Subtotal', money(o.subtotal));
    if (Number(o.discount) > 0) { lr('Diskon', '-' + money(o.discount)); }
    /* Pajak 0 -> baris pajak dihilangkan dari struk */
    if (Number(o.tax) > 0) { lr('Pajak', money(o.tax)); }
    lr('TOTAL', money(o.total));
    line('-');
    lr('Bayar (' + String(o.payment_label || '') + ')',
      money(o.received === null ? o.total : o.received));
    lr('Kembali', money(o.change_due));
    line('=');
    center(String(store.store_footer || 'Terima kasih!'));
    return L.join('\n');
  }

  function showReceipt(order, store) {
    state.lastOrder = order;
    if ($('rc-number')) { $('rc-number').textContent = String(order.order_number); }
    var txt = receiptText(order, store || state.store, state.store.printer_width || '58');
    if ($('receipt-preview')) { $('receipt-preview').textContent = txt; }

    Display.paid(Number(order.total), String(order.order_number));

    clearCart();          /* keranjang direset setelah sukses */
    refreshHeld();
    LP.openModal('modal-receipt');
  }

  /**
   * Cetak struk. Bila mode printer diarahkan ke open-escpos-print-service
   * (escpos-intent), kirim lewat intent Android supaya TIDAK muncul layar
   * pemilihan printer. Mode 'browser' memakai dialog cetak seperti dulu.
   */
  function printReceipt() {
    var order = state.lastOrder;
    if (!order) { return; }
    var store = state.store || {};
    var mode = String(store.printer_mode || 'browser');

    if (mode !== 'browser' && LPESCPOS.available()) {
      return LPESCPOS.printReceipt(order, store).then(function (res) {
        if (res.handoff) {
          LP.toast('Struk dikirim ke printer.', 'ok');
          return;
        }
        /* app printer tidak mengambil alih -> beri tahu, jangan diam */
        LP.toast('Aplikasi Open ESC/POS tidak merespons. ' +
          'Pastikan aplikasi terpasang & printer default sudah diatur.', 'warn', 6000);
      }).catch(function (e) {
        LP.toast('Cetak via printer gagal: ' + e.message + ' — memakai dialog cetak.', 'warn', 6000);
        browserPrint();
      });
    }

    if (mode !== 'browser' && !LPESCPOS.available()) {
      LP.toast('Mode printer belum didukung di perangkat ini — memakai dialog cetak.', 'warn', 5000);
    }
    return browserPrint();
  }

  /**
   * Cetak lewat dialog print browser.
   * Mengutamakan iframe tersembunyi supaya tidak diblokir popup blocker
   * (window.open sering ditolak di WebView Android).
   */
  function browserPrint() {
    var txt = $('receipt-preview') ? $('receipt-preview').textContent : '';
    if (txt === '') { return; }

    var html = '<!doctype html><html><head><meta charset="utf-8">' +
      '<style>@page{margin:0mm 0mm 0mm 0mm}' +
      'html,body{margin:0;padding:0}' +
      'pre{font-family:"Courier New",monospace;font-size:12px;margin:0;padding:8px}</style>' +
      '</head><body><pre>' + esc(txt) + '</pre></body></html>';

    var frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    frame.style.position = 'fixed';
    frame.style.right = '0';
    frame.style.bottom = '0';
    frame.style.width = '0';
    frame.style.height = '0';
    frame.style.border = '0';
    document.body.appendChild(frame);

    var doc = frame.contentWindow.document;
    doc.open();
    doc.write(html);
    doc.close();

    /* beri waktu render sebelum dialog cetak dibuka */
    setTimeout(function () {
      try {
        frame.contentWindow.focus();
        frame.contentWindow.print();
      } catch (e) {
        LP.toast('Printer belum siap: ' + e.message, 'warn', 5000);
      }
      /* bersihkan setelah dialog ditutup */
      setTimeout(function () {
        if (frame.parentNode) { frame.parentNode.removeChild(frame); }
      }, 60000);
    }, 260);
  }
/**
   * Kirim tiket dapur otomatis setelah pembayaran sukses.
   * Hanya berjalan bila print_kitchen aktif DAN mode printer sudah
   * diarahkan ke open-escpos-print-service — tidak pernah mengganggu
   * alur pembayaran (error ditelan).
   */
  function sendKitchenTicket(order, store) {
    if (!order || !store) { return; }
    if (String(store.print_kitchen || '0') !== '1') { return; }
    if (String(store.printer_mode || 'browser') === 'browser') { return; }
    if (!LPESCPOS.available()) { return; }

    LPESCPOS.printKitchen(order, store).catch(function (e) {
      console.warn('[kitchen print]', e);
    });
  }

  /* ---------- jam ---------- */
  function tick() {
    var el = $('pos-clock');
    if (el) {
      el.textContent = new Date().toLocaleTimeString('id-ID', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    }
  }

  /* ---------- muat data awal ---------- */
  function loadAll() {
    return Promise.all([
      LP.api('api/menus.php', { method: 'GET' }),
      LPDB.getSettings(['store_name', 'store_address', 'store_phone',
        'store_footer', 'tax_rate', 'printer_width',
        'printer_mode', 'printer_service', 'printer_char', 'print_kitchen',
        'printer_font_px'])
    ]).then(function (res) {
      state.cats = res[0].categories || [];
      state.items = res[0].items || [];
      state.store = res[1];
      state.taxRate = Number(res[1].tax_rate) || 0;

      renderChips();
      renderGrid();
      renderCart();
      return refreshHeld();
    });
  }



  /* ---------- bind event ---------- */
  function bind() {
    /* tipe pesanan (dine_in / takeaway / online) */
    if ($('type-tabs')) {
      $('type-tabs').addEventListener('click', function (e) {
        var b = e.target.closest('.type-tab');
        if (!b) { return; }
        state.type = String(b.dataset.type);
        document.querySelectorAll('.type-tab').forEach(function (x) {
          x.classList.toggle('active', x === b);
        });
        renderGrid();
        renderCart();
        Display.schedule();
      });
    }

    /* pencarian menu */
    if ($('pos-search')) { $('pos-search').addEventListener('input', renderGrid); }

    /* pilih kategori */
    if ($('cat-chips')) {
      $('cat-chips').addEventListener('click', function (e) {
        var c = e.target.closest('.chip');
        if (!c) { return; }
        state.cat = Number(c.dataset.cat);
        renderChips();
        renderGrid();
      });
    }

    /* klik produk -> tambah ke keranjang */
    if ($('prod-grid')) {
      $('prod-grid').addEventListener('click', function (e) {
        var card = e.target.closest('.prod-card');
        if (card) { addItem(card.dataset.id); }
      });
    }

    /* keranjang: tambah / kurang / hapus */
    if ($('cart-lines')) {
      $('cart-lines').addEventListener('click', function (e) {
        var inc = e.target.closest('[data-inc]');
        var dec = e.target.closest('[data-dec]');
        var del = e.target.closest('[data-del]');
        if (inc) { changeQty(Number(inc.dataset.inc), 1); }
        else if (dec) { changeQty(Number(dec.dataset.dec), -1); }
        else if (del) { removeLine(Number(del.dataset.del)); }
      });
    }

    /* daftar hold */
    if ($('holds-list')) {
      $('holds-list').addEventListener('click', function (e) {
        var ld = e.target.closest('[data-hold-load]');
        var dl = e.target.closest('[data-hold-del]');
        if (ld) { loadHold(Number(ld.dataset.holdLoad)); }
        else if (dl) { cancelHold(Number(dl.dataset.holdDel)); }
      });
    }

    /* diskon mengubah total */
    if ($('inp-discount')) {
      $('inp-discount').addEventListener('input', function () {
        renderCart();
        Display.schedule();
      });
    }

    /* nama pelanggan -> layar pelanggan */
    if ($('inp-customer')) { $('inp-customer').addEventListener('change', Display.schedule); }

    /* tombol aksi */
    if ($('hold-btn')) { $('hold-btn').addEventListener('click', doHold); }
    if ($('charge-btn')) { $('charge-btn').addEventListener('click', openPay); }
    if ($('pay-ok')) { $('pay-ok').addEventListener('click', doPay); }
    if ($('btn-print')) { $('btn-print').addEventListener('click', printReceipt); }

    /* metode bayar */
    if ($('pay-methods')) {
      $('pay-methods').addEventListener('click', function (e) {
        var b = e.target.closest('.pay-btn');
        if (!b) { return; }
        state.pay = String(b.dataset.pm);
        document.querySelectorAll('.pay-btn').forEach(function (x) {
          x.classList.toggle('active', x === b);
        });
        updateCashUI();
      });
    }

    /* uang diterima + nominal cepat */
    if ($('inp-received')) { $('inp-received').addEventListener('input', updateCashUI); }
    if ($('quick-amounts')) {
      $('quick-amounts').addEventListener('click', function (e) {
        var c = e.target.closest('[data-quick]');
        if (!c) { return; }
        if ($('inp-received')) { $('inp-received').value = String(c.dataset.quick); }
        updateCashUI();
      });
    }
  }

  /* ---------- init halaman ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    LPBOOT.start('pos.order', function () {
      /* mode kasir: tanpa sidebar (layar penuh untuk pesanan) */
      LPUI.mountChrome('pos.html', { noSidebar: true });

      /* kiosk: minta layar penuh bila diaktifkan di Pengaturan */
      LPDB.getSetting('kiosk_fullscreen', '1').then(function (v) {
        if (String(v) === '1') { LPUI.enableFullscreen(); }
      });

      bind();
      tick();
      setInterval(tick, 1000);

      loadAll().catch(function (e) {
        LP.toast('Gagal memuat menu: ' + e.message, 'err', 6000);
      });

      /* auto-refresh daftar hold tiap 30 detik */
      setInterval(refreshHeld, 30000);
    });
  });
})();
