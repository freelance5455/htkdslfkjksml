window.WorkspaceRouter={
  show(screen,crumb,patch={},pageId=''){const state=window.WorkspaceState;Object.assign(state.route,patch,{screen});window.WorkspaceConfig.screens.forEach(id=>document.getElementById(id).classList.add('hidden'));const target=document.getElementById(pageId||`${screen}Page`);if(!target)throw new Error(`Workspace screen target not found: ${pageId||`${screen}Page`}`);target.classList.remove('hidden');document.getElementById('crumb').textContent=crumb;document.body.dataset.screen=screen;document.body.classList.remove('sidebar-open');scrollTo({top:0,behavior:'smooth'})},
  showElement(screen,pageId,crumb,patch={}){return this.show(screen,crumb,patch,pageId)},
  showPlaceholder(icon,title,description){document.getElementById('placeholderIcon').textContent=icon;document.getElementById('placeholderTitle').textContent=title;document.getElementById('placeholderDescription').textContent=description;this.show('placeholder',title)}
};
