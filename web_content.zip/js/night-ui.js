"use strict";

const NightUI = (() => {
  const LOCK_MS = 1500;
  let lockTimer = null;
  let selectedTarget = null;
  let currentKind = null;
  let acted = false;
  let resultOpen = false;

  const $ = (id) => document.getElementById(id);

  function setNightTheme(on) {
    document.body.classList.toggle("is-night", on);
  }

  /* ---------- بداية الليل ---------- */
  function start() {
    const res = Game.startNight();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    clearTimeout(lockTimer);
    setNightTheme(true);
    $("night-title").textContent = `🌙 الليلة ${res.number}`;
    $("night-sub").textContent = `الأحياء: ${res.aliveCount} لاعبين`;
    UI.showScreen("night-intro");
  }

  /* ---------- تسليم الهاتف ---------- */
  function showHandover() {
    const turn = Game.getNightTurn();
    if (!turn) return;
    if (turn.done) {
      showDawn();
      return;
    }
    $("night-progress").textContent = `الدور ${turn.index + 1} من ${turn.total}`;
    $("night-handover-name").textContent = turn.player.name;
    $("btn-night-ready").textContent = `👁️ أنا ${turn.player.name} — جاهز`;
    UI.showScreen("night-handover");
  }

  /* ---------- شاشة القدرة ---------- */
  function clearActionDom() {
    $("night-targets").innerHTML = "";
    $("night-role").textContent = "";
    $("night-action-title").textContent = "";
    $("night-prompt").textContent = "";
  }

  function renderAction(res) {
    currentKind = res.turn.kind;
    acted = false;
    selectedTarget = null;

    const roleBox = $("night-role");
    roleBox.textContent = `${res.role.icon} ${res.role.name}`;
    roleBox.style.color = res.role.color;
    $("night-action-title").textContent = res.turn.title;
    $("night-prompt").textContent = res.turn.prompt;

    const list = $("night-targets");
    list.innerHTML = "";
    res.turn.targets.forEach((target) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "target-btn";
      btn.dataset.target = String(target.id);
      btn.textContent = target.name;
      list.appendChild(btn);
    });

    const confirm = $("btn-night-confirm");
    if (currentKind === "jammed") {
      confirm.disabled = false;
      confirm.textContent = "➡️ متابعة";
    } else {
      confirm.disabled = true;
      confirm.textContent = "✅ تأكيد";
    }

    const skip = $("btn-night-skip");
    skip.hidden = !res.turn.allowSkip;
    skip.textContent = res.turn.skipLabel || "⏭️ تخطي";
  }

  function onReady() {
    const res = Game.beginNightTurn();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    renderAction(res);
    UI.showScreen("night-action");
  }

  function onTargetClick(event) {
    const btn = event.target.closest("[data-target]");
    if (!btn || acted) return;
    selectedTarget = Number(btn.dataset.target);
    document.querySelectorAll("#night-targets .target-btn").forEach((b) => {
      b.classList.toggle("on", b === btn);
    });
    $("btn-night-confirm").disabled = false;
  }

  function submit(target) {
    if (acted) return;
    const res = Game.submitNightAction(target);
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    acted = true;
    clearActionDom();
    if (res.info) {
      $("night-result-title").textContent = res.info.title;
      $("night-result-text").textContent = res.info.text;
      resultOpen = true;
      UI.showScreen("night-result");
    } else {
      showTransition();
    }
  }

  function onConfirm() {
    submit(currentKind === "jammed" ? null : selectedTarget);
  }

  function onSkip() {
    submit(null);
  }

  /* ---------- نتيجة سرية (المحقق / المخبر) ---------- */
  function onHideResult() {
    if (!resultOpen) return;
    resultOpen = false;
    $("night-result-title").textContent = "";
    $("night-result-text").textContent = "";
    const res = Game.finishNightResult();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    showTransition();
  }

  /* ---------- شاشة القفل ---------- */
  function showTransition() {
    const res = Game.advanceNightTurn();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    const btn = $("btn-night-next");
    clearTimeout(lockTimer);
    btn.disabled = true;
    btn.textContent = "⏳ انتظر…";
    UI.showScreen("night-transition");
    lockTimer = setTimeout(() => {
      btn.disabled = false;
      btn.textContent = res.finished ? "🌅 انتظار الفجر" : "👤 اللاعب التالي";
    }, LOCK_MS);
  }

  function onNext() {
    const btn = $("btn-night-next");
    if (btn.disabled) return;
    btn.disabled = true;
    showHandover();
  }

  /* ---------- الفجر ---------- */
  function showDawn() {
    const res = Game.resolveNight();
    if (!res.ok) {
      UI.toast(res.error);
      return;
    }
    setNightTheme(false);

    const settings = Game.getSettings();
    const reveal = settings && settings.revealRoleOnElimination === "reveal";

    $("dawn-title").textContent = `☀️ فجر اليوم ${res.number}`;
    const list = $("dawn-list");
    list.innerHTML = "";

    if (res.deaths.length === 0) {
      const line = document.createElement("p");
      line.className = "dawn-line";
      line.textContent = "🌅 مرّت الليلة بسلام… لم يمت أحد.";
      list.appendChild(line);
    } else {
      res.deaths.forEach((death) => {
        const role = Roles.get(death.roleId);
        const line = document.createElement("p");
        line.className = "dawn-line";
        line.textContent = reveal
          ? `💀 مات ${death.name} — كان ${role.icon} ${role.name}`
          : `💀 مات ${death.name}`;
        list.appendChild(line);
      });
    }

    const aliveCount = Game.getPublicPlayers().filter((p) => p.alive).length;
    $("dawn-alive").textContent = `الأحياء الآن: ${aliveCount}`;
    $("btn-night-day").textContent = Game.getResult() ? "🏆 عرض النتيجة" : "☀️ متابعة إلى النهار";
    
    UI.showScreen("night-dawn");
  }

  /* ---------- التهيئة ---------- */
  function init() {
    $("btn-night-start").addEventListener("click", showHandover);
    $("btn-night-ready").addEventListener("click", onReady);
    $("night-targets").addEventListener("click", onTargetClick);
    $("btn-night-confirm").addEventListener("click", onConfirm);
    $("btn-night-skip").addEventListener("click", onSkip);
    $("btn-night-hide-result").addEventListener("click", onHideResult);
    $("btn-night-next").addEventListener("click", onNext);
    $("btn-night-day").addEventListener("click", () => {
      if (Game.getResult()) WinUI.show();
      else DayUI.start();
    });
  
  }

  return { init, start };
})();