/* Studio – vývojářský editor nepřátel a věží (zapíná se jen příkazem „dev“ v terminálu).
   Co je tu: schémata polí (co se dá nastavit), uložené úpravy v postupu (profile.studio), přepis herních dat za běhu (apply),
   export / import úprav jako JSON. Samotné mechaniky (rozpad, útok na věže, regenerace…) jsou v systems/enemies.js a systems/towers.js.
   Úpravy: items.<druh>[id] = { patch: { 'cesta': hodnota } }   (úprava vestavěné položky)
                              { custom: true, def: { … } }        (nová položka)
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var ET = BD.systems.enemies.TYPES, TT = BD.data.towers, AM = BD.data.ammo;
  var TP = {};                                                           // šablony vzhledů (jen vlastní; dají se vložit do vzhledu věže / nepřítele tvarem „Šablona“)
  var KINDS = { enemies: ET, towers: TT, ammo: AM, templates: TP };
  var KIND_LIST = ['enemies', 'towers', 'ammo', 'templates'];
  function emptyItems() { return { enemies: {}, towers: {}, ammo: {}, templates: {} }; }
  var ID_RE = /^[a-z][a-z0-9_]{1,19}$/;
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  var ORIG = { enemies: clone(ET), towers: clone(TT), ammo: clone(AM), templates: {} };                 // výchozí data, ze kterých se vždy vychází

  /* ---------- schémata polí ---------- */
  var COL = '#7fe3cf';
  function F(k, label, type, o) { var f = { k: k, label: label, type: type }; for (var i in o) f[i] = o[i]; return f; }
  var ENEMY = [
    { g: 'Základ', fields: [
      F('name', 'Název', 'text', { max: 24 }), F('color', 'Barva', 'color'),
      F('hp', 'Zdraví', 'num', { min: 1, max: 100000, step: 1, help: 'Základní zdraví v 1. vlně; s každou vlnou roste.' }),
      F('speed', 'Rychlost', 'num', { min: 0.1, max: 5, step: 0.05, help: 'Věží za sekundu.' }),
      F('reward', 'Odměna (zlato)', 'num', { min: 0, max: 1000, step: 1 }),
      F('r', 'Velikost', 'num', { min: 0.08, max: 0.8, step: 0.01, help: 'Poloměr v buňkách. Ulička je široká 1 buňku.' }),
      F('life', 'Životy, které vezme', 'num', { min: 1, max: 50, step: 1, int: true }) ] },
    { g: 'Mechaniky', fields: [
      F('ghost', 'Duch (letí skrz skály a věže, zdi obletí)', 'bool'),
      F('resist', 'Odolnost vůči poškození', 'num', { min: 0, max: 0.9, step: 0.05, help: '0,5 = každá rána dá poloviční poškození.' }),
      F('regen', 'Regenerace (zdraví/s)', 'num', { min: 0, max: 500, step: 0.5 }),
      F('slowImmune', 'Imunní proti zpomalení', 'bool'),
      F('splitCount', 'Po smrti se rozpadne na (počet)', 'num', { min: 0, max: 8, step: 1, int: true, help: '0 = nerozpadá se.' }),
      F('splitInto', 'Rozpadne se na (druh)', 'enemy', { help: 'Potomci pokračují od místa smrti. Tři generace maximum.' }) ] },
    { g: 'Vlny', wave: true, fields: [
      F('waveMode', 'Zařazení do vln', 'select', { options: [['builtin', 'Podle původního předpisu hry'], ['rules', 'Vlastní pravidla (níže)'], ['none', 'Ve vlnách není (jen rozpad / zkouška)']], help: 'Nepřítel, který se objevuje jen rozpadem jiného, patří do „Ve vlnách není“.' }),
      F('waveFrom', 'Od vlny', 'num', { min: 1, max: 200, step: 1, int: true, when: 'rules' }),
      F('waveTo', 'Do vlny (0 = bez konce)', 'num', { min: 0, max: 200, step: 1, int: true, when: 'rules' }),
      F('waveEvery', 'Každou N-tou vlnu', 'num', { min: 1, max: 50, step: 1, int: true, when: 'rules', help: '1 = každou vlnu, 5 = každou pátou od první vlny z „Od vlny“.' }),
      F('waveCount', 'Počet na začátku', 'num', { min: 1, max: 200, step: 1, int: true, when: 'rules' }),
      F('wavePer', 'Přírůstek počtu za vlnu', 'num', { min: 0, max: 10, step: 0.1, when: 'rules', help: 'Počet = základ + přírůstek × (vlna − od vlny).' }),
      F('waveGap', 'Odstup mezi kusy (s)', 'num', { min: 0.05, max: 5, step: 0.05, when: 'rules' }),
      F('levelFrom', 'Až od kolikátého levelu (0 = od začátku)', 'num', { min: 0, max: 99, step: 1, int: true, when: 'rules', help: 'Ve story: kolikátý level hraješ (počet dokončených + 1). Ve free módu a v editoru se nehlídá.' }) ] },
    { g: 'Útok na věže', fields: [
      F('atkDmg', 'Poškození věže', 'num', { min: 0, max: 10000, step: 1, help: '0 = na věže neútočí.' }),
      F('atkRange', 'Dosah (věží)', 'num', { min: 0, max: 6, step: 0.1 }),
      F('atkCd', 'Prodleva (s)', 'num', { min: 0.1, max: 10, step: 0.1 }),
      F('atkStop', 'Při útoku stojí', 'bool') ] },
  ];
  var TOWER = [
    { g: 'Základ', fields: [
      F('name', 'Název', 'text', { max: 24 }), F('color', 'Barva', 'color'), F('desc', 'Popis', 'text', { max: 140 }),
      F('cost', 'Cena', 'num', { min: 1, max: 100000, step: 1, int: true }),
      F('order', 'Pořadí v nabídce', 'num', { min: 0, max: 99, step: 1, int: true }),
      F('role', 'Druh', 'select', { options: [['shot', 'Střílí (střela)'], ['burst', 'Rázová vlna (zasáhne vše v dosahu)'], ['boost', 'Zesilovač (nestřílí)']] }),
      F('parent', 'Vylepšení z věže', 'tower', { help: 'Věž, ze které se tahle vylepšuje. Stejně jde věž přetáhnout ve stromu vlevo.' }),
      F('hp', 'Životy věže', 'num', { min: 1, max: 100000, step: 1, int: true, help: 'Nepřátelé s útokem je snižují. Roste se sloučením.' }),
      F('ammo', 'Střelivo', 'ammo', { role: 'shot', help: 'Jak střela vypadá a letí (záložka Střelivo). Prázdné = výchozí střela.' }),
      F('target', 'Zaměřování', 'select', { options: [['first', 'Nejdál na cestě'], ['close', 'Nejbližší'], ['strong', 'Nejsilnější (nejvíc zdraví)'], ['weak', 'Nejslabší']] }) ] },
    { g: 'Koho zasáhne', fields: [
      F('hitsGhost', 'Zasáhne duchy', 'bool'), F('onlyGhost', 'Střílí jen na duchy', 'bool') ] },
    { g: 'Statistiky', fields: [
      F('base.dmg', 'Poškození', 'num', { min: 0, max: 100000, step: 1, role: 'shot,burst' }),
      F('base.range', 'Dosah (věží)', 'num', { min: 0.5, max: 12, step: 0.1, role: 'shot,burst' }),
      F('base.cd', 'Prodleva (s)', 'num', { min: 0.05, max: 10, step: 0.05, role: 'shot,burst' }),
      F('base.speed', 'Rychlost střely', 'num', { min: 1, max: 40, step: 0.5, role: 'shot' }),
      F('base.splash', 'Plošnost střely (věží)', 'num', { min: 0, max: 4, step: 0.1, role: 'shot', help: '0 = zasáhne jeden cíl.' }),
      F('base.slow', 'Zpomalení zasaženého', 'num', { min: 0, max: 0.9, step: 0.05, role: 'shot', help: '0,4 = o 40 % pomalejší na 1,5 s.' }),
      F('base.boost', 'Zesílení sousedů', 'num', { min: 1, max: 5, step: 0.05, role: 'boost', help: '1,25 = +25 % poškození dotýkajícím se věžím.' }) ] },
  ];
  var PH = function (p, lab) { return [
    F(p + '.dur', 'Délka (s)', 'num', { min: 0.05, max: 2, step: 0.05, phase: p }),
    F(p + '.size', 'Velikost (buňky)', 'num', { min: 0.05, max: 6, step: 0.05, phase: p }),
    F(p + '.s0', 'Velikost na začátku (×)', 'num', { min: 0, max: 4, step: 0.05, phase: p }), F(p + '.s1', 'Velikost na konci (×)', 'num', { min: 0, max: 4, step: 0.05, phase: p }),
    F(p + '.a0', 'Průhlednost na začátku', 'num', { min: 0, max: 1, step: 0.05, phase: p }), F(p + '.a1', 'Průhlednost na konci', 'num', { min: 0, max: 1, step: 0.05, phase: p }),
    F(p + '.r0', 'Natočení na začátku (°)', 'num', { min: -720, max: 720, step: 5, phase: p }), F(p + '.r1', 'Natočení na konci (°)', 'num', { min: -720, max: 720, step: 5, phase: p })]; };
  var AMMO = [
    { g: 'Základ', fields: [
      F('name', 'Název', 'text', { max: 24 }), F('color', 'Barva (označení v seznamu)', 'color'),
      F('dmgMul', 'Násobek poškození věže', 'num', { min: 0.1, max: 10, step: 0.05, help: 'Poškození, dosah a prodleva zůstávají na věži; střelivo je jen násobí.' }),
      F('flight', 'Let', 'select', { options: [['homing', 'Naváděná (sleduje cíl)'], ['straight', 'Rovná (letí na místo výstřelu, může minout)'], ['arc', 'Oblouk (naváděná, jen vizuálně vysoko)']] }),
      F('speedMul', 'Násobek rychlosti', 'num', { min: 0.2, max: 4, step: 0.05 }) ] },
    { g: 'Výstřel', phase: 'muzzle', fields: PH('muzzle').concat([F('muzzle.dist', 'Odsazení od středu věže (buňky)', 'num', { min: 0, max: 3, step: 0.05, phase: 'muzzle' })]) },
    { g: 'Let', phase: 'shot', fields: [
      F('shot.size', 'Velikost (buňky)', 'num', { min: 0.05, max: 3, step: 0.05, phase: 'shot' }),
      F('shot.spin', 'Rotace (otáček/s)', 'num', { min: -10, max: 10, step: 0.25, phase: 'shot' }),
      F('shot.trail', 'Stopa (0 = žádná)', 'num', { min: 0, max: 1, step: 0.05, phase: 'shot' }) ] },
    { g: 'Dopad', phase: 'impact', fields: PH('impact') },
  ];
  var TPL = [{ g: 'Základ', fields: [F('name', 'Název', 'text', { max: 24 })] }];
  var SCHEMA = { enemies: ENEMY, towers: TOWER, ammo: AMMO, templates: TPL };
  function fieldOf(kind, path) { if (path === 'sprite' || (kind === 'ammo' && /^(muzzle|shot|impact)\.sprite$/.test(path))) return { k: path, type: 'sprite' }; var r = null; SCHEMA[kind].forEach(function (g) { g.fields.forEach(function (f) { if (f.k === path) r = f; }); }); return r; }

  /* ---------- cesty v objektech ---------- */
  function getPath(o, path) { var p = path.split('.'); for (var i = 0; i < p.length; i++) { if (o == null) return undefined; o = o[p[i]]; } return o; }
  function setPath(o, path, v) {
    var p = path.split('.'), k;
    for (var i = 0; i < p.length - 1; i++) { k = p[i]; if (o[k] == null || typeof o[k] !== 'object') o[k] = /^\d+$/.test(p[i + 1]) ? [] : {}; o = o[k]; }
    if (v === undefined) delete o[p[p.length - 1]]; else o[p[p.length - 1]] = v;
  }
  function same(a, b) { return JSON.stringify(a) === JSON.stringify(b); }

  /* ---------- šablony nových položek ---------- */
  var TEMPLATE = {
    templates: function () { var SP = BD.render.sprite; return { name: 'Nová šablona', sprite: { v: 1, nodes: [SP.node('circle', { name: 'Tělo', w: 1.6 })] } }; },
    ammo: function () {
      var d = clone(AM.default); d.name = 'Nové střelivo'; d.color = COL; return d;
    },
    enemies: function () { return { name: 'Nový nepřítel', color: COL, hp: 30, speed: 1, reward: 3, r: 0.27, life: 1, waveMode: 'none' }; },
    towers: function () {
      return { parent: 'base', order: 50, name: 'Nová věž', color: COL, cost: 30, role: 'shot', desc: 'Popis nové věže.', hp: 100, hitsGhost: true,
        base: { dmg: 10, range: 2.5, cd: 0.6, speed: 10 } };
    },
  };

  /* ---------- čištění hodnoty podle schématu ---------- */
  function cleanValue(kind, path, v) {
    var f = fieldOf(kind, path); if (!f) return undefined;
    if (f.type === 'sprite') { var sp = BD.render.sprite.sanitize(v); return sp || undefined; }
    if (f.type === 'num') {
      if (v === '' || v === null || v === undefined) return f.empty ? undefined : (f.min || 0);
      v = Number(v); if (!isFinite(v)) return undefined;
      v = Math.min(f.max, Math.max(f.min, v)); return f.int ? Math.round(v) : Math.round(v * 1000) / 1000;
    }
    if (f.type === 'bool') return !!v;
    if (f.type === 'color') return /^#[0-9a-fA-F]{6}$/.test(String(v)) ? String(v).toLowerCase() : undefined;
    if (f.type === 'select') return f.options.some(function (o) { return o[0] === v; }) ? v : undefined;
    if (f.type === 'tower') return v === '' || v == null ? '' : (/^[a-z][a-z0-9_]{1,19}$/.test(String(v)) ? String(v) : undefined);
    if (f.type === 'ammo') return v === '' || v == null ? '' : (/^[a-z][a-z0-9_]{1,19}$/.test(String(v)) ? String(v) : undefined);
    if (f.type === 'enemy') return v === '' || v == null ? '' : (/^[a-z][a-z0-9_]{1,19}$/.test(String(v)) ? String(v) : undefined);
    return String(v == null ? '' : v).slice(0, f.max || 60);
  }

  /* ---------- stav ---------- */
  var studio = BD.studio = Vue.reactive({ enabled: false, rev: 0, ui: { tab: 'enemies', sel: '' } });
  studio.KIND_LIST = KIND_LIST;
  /* šablona může obsahovat jiné šablony, ale ne sebe sama (ani oklikou): tplReaches(a, b) = dostane se kreslení šablony a až k šabloně b? */
  function refsOf(sp) { var out = []; if (sp && sp.nodes) BD.render.sprite.walk(sp.nodes, function (n) { if (n.type === 'ref' && n.ref) out.push(n.ref); }); return out; }
  studio.tplReaches = function (from, target, over) {
    var seen = {}, st = [from];
    while (st.length) { var id = st.pop(); if (id === target) return true; if (seen[id]) continue; seen[id] = 1; var sp = over && over[id] ? over[id] : (TP[id] && TP[id].sprite); refsOf(sp).forEach(function (r) { st.push(r); }); }
    return false;
  };
  function stripCycles(id, sp) {                                  // z vzhledu šablony id vyhodí odkazy, které by udělaly smyčku
    if (!sp || !sp.nodes) return sp;
    (function cut(list) { for (var i = list.length - 1; i >= 0; i--) { var n = list[i]; if (n.type === 'ref' && n.ref && studio.tplReaches(n.ref, id)) list.splice(i, 1); else if (n.children) cut(n.children); } })(sp.nodes);
    return sp;
  }
  studio.tplSprite = function (id) { var t = TP[id]; return t && t.sprite && t.sprite.nodes ? t.sprite : null; };         // bez reaktivity (volá se při každém překreslení)
  studio.schema = SCHEMA; studio.fieldOf = fieldOf; studio.get = getPath; studio.KINDS = KINDS;
  function items() {
    var p = BD.store && BD.store.profile; if (!p) return emptyItems();
    if (!p.studio || !p.studio.items) p.studio = { items: emptyItems() };
    if (!p.studio.items.templates) p.studio.items.templates = {};
    if (!p.studio.items.ammo) p.studio.items.ammo = {};
    return p.studio.items;
  }
  studio.items = items;
  function save() { studio.rev++; if (BD.store && BD.store.flush) BD.store.flush(); }

  studio.isBuiltin = function (kind, id) { return !!ORIG[kind][id]; };
  studio.original = function (kind, id) { return ORIG[kind][id] ? clone(ORIG[kind][id]) : null; };
  studio.ids = function (kind) {
    var ids = Object.keys(KINDS[kind]);
    if (kind === 'towers') ids.sort(function (a, b) { return (TT[a].order || 0) - (TT[b].order || 0); });
    return ids;
  };
  studio.touched = function (kind, id) { studio.rev; var it = items()[kind][id]; return !!it && (it.custom || it.deleted || Object.keys(it.patch || {}).length > 0); };
  studio.isChanged = function (kind, id, path) { studio.rev; var it = items()[kind][id]; return !!(it && it.patch && path in it.patch); };

  /* přepíše herní data podle uložených úprav; bez zapnutého Studia vrátí vše do výchozího stavu */
  function resetObj(target, src) { Object.keys(target).forEach(function (k) { delete target[k]; }); Object.keys(src).forEach(function (k) { target[k] = clone(src[k]); }); }
  studio.apply = function () {
    var it = items();
    if (studio.enabled) KIND_LIST.forEach(function (kind) {                           // úklid osiřelých záznamů (smazané / neznámé položky, prázdné úpravy)
      Object.keys(it[kind]).forEach(function (id) { var e = it[kind][id]; if (!e || typeof e !== 'object' || (!e.custom && !(e.deleted && kind === 'towers' && id !== 'base' && ORIG[kind][id]) && (!ORIG[kind][id] || !e.patch || !Object.keys(e.patch).length)) || (e.custom && (ORIG[kind][id] || !e.def))) delete it[kind][id]; });
    });
    KIND_LIST.forEach(function (kind) {
      var T = KINDS[kind];
      Object.keys(T).forEach(function (id) { if (!ORIG[kind][id]) delete T[id]; });                  // vlastní položky pryč
      Object.keys(ORIG[kind]).forEach(function (id) { if (!T[id]) T[id] = clone(ORIG[kind][id]); else resetObj(T[id], ORIG[kind][id]); });         // vestavěné na výchozí (i smazané se vrátí)
      if (!studio.enabled) return;
      Object.keys(it[kind]).forEach(function (id) {
        var e = it[kind][id];
        if (e.custom) { var d = clone(e.def); if (kind === 'towers') d.id = id; T[id] = d; }
        else if (e.deleted && kind === 'towers' && id !== 'base') delete T[id];
        else if (T[id] && e.patch) Object.keys(e.patch).forEach(function (p) { setPath(T[id], p, clone(e.patch[p])); });
      });
    });
    if (studio.enabled) { Object.keys(TP).forEach(function (id) { if (TP[id].sprite) stripCycles(id, TP[id].sprite); }); normalizeTree(); }
    studio.rev++;
  };

  /* strom věží musí být v pořádku: základna je kořen, ostatní mají existujícího rodiče a nevzniká cyklus (jinak jdou pod základnu) */
  function normalizeTree() {
    Object.keys(TT).forEach(function (id) {
      var d = TT[id]; if (id === 'base') { d.parent = ''; return; }
      var p = d.parent, seen = {}, ok = !!TT[p] && p !== id; seen[id] = 1;
      while (ok && p && p !== 'base') { if (seen[p]) { ok = false; break; } seen[p] = 1; p = TT[p] && TT[p].parent; if (!TT[p] && p !== 'base' && p !== '') ok = false; }
      if (!ok || !d.parent) d.parent = 'base';
    });
  }
  /* potomci věže (id) podle parent, v pořadí */
  studio.childrenOf = function (id) { studio.rev; return Object.keys(TT).filter(function (k) { return TT[k].parent === id && k !== id; }).sort(function (a, b) { return (TT[a].order || 0) - (TT[b].order || 0); }); };
  studio.isUnder = function (id, anc) { var n = 0, p = TT[id] && TT[id].parent; while (p && n++ < 30) { if (p === anc) return true; p = TT[p] && TT[p].parent; } return false; };
  /* přesun věže pod jinou (rodiče nelze přesunout pod vlastního potomka); order = nová pozice mezi sourozenci */
  studio.moveTower = function (id, parent, order) {
    if (id === 'base' || !TT[id] || !TT[parent] || id === parent || studio.isUnder(parent, id)) return false;
    studio.set('towers', id, 'parent', parent);
    if (order !== undefined) studio.set('towers', id, 'order', order);
    return true;
  };
  studio.set = function (kind, id, path, value) {
    var v = cleanValue(kind, path, value), e = items()[kind][id];
    if (kind === 'templates' && path === 'sprite' && v) v = stripCycles(id, v);
    if (!e) { if (!ORIG[kind][id]) return false; e = items()[kind][id] = { patch: {} }; }
    if (e.custom) { setPath(e.def, path, v); }
    else {
      if (!e.patch) e.patch = {};
      if (v === undefined || same(v, getPath(ORIG[kind][id], path))) delete e.patch[path]; else e.patch[path] = v;
      if (!Object.keys(e.patch).length) delete items()[kind][id];
    }
    studio.apply(); save(); return true;
  };
  studio.setSprite = function (kind, id, sp) { return studio.set(kind, id, 'sprite', sp); };
  studio.resetField = function (kind, id, path) { var e = items()[kind][id]; if (e && e.patch) { delete e.patch[path]; if (!Object.keys(e.patch).length) delete items()[kind][id]; studio.apply(); save(); } };
  studio.resetItem = function (kind, id) { delete items()[kind][id]; studio.apply(); save(); };
  /* text z pole = NÁZEV položky; identifikátor se z něj odvodí (bez diakritiky, malá písmena, _), při shodě se přidá číslo */
  function slug(text) {
    var t = String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    if (!t) t = 'item'; if (!/^[a-z]/.test(t)) t = 'x' + t; if (t.length < 2) t += 'x';
    return t.slice(0, 18);
  }
  studio.create = function (kind, text) {
    text = String(text || '').trim().slice(0, 24);
    if (!text) return 'Napiš název.';
    var base = slug(text), id = base, n = 2;
    while (KINDS[kind][id] || items()[kind][id]) id = base.slice(0, 17) + n++;
    var d = TEMPLATE[kind](); d.name = text;
    items()[kind][id] = { custom: true, def: d };
    studio.lastId = id; studio.apply(); save(); return '';
  };
  studio.remove = function (kind, id) {
    var e = items()[kind][id], builtin = !!ORIG[kind][id];
    if (kind === 'towers' && id === 'base') return false;
    if (!e && builtin && kind === 'towers') e = {}; else if (!e) return false;
    if (!e.custom && !(builtin && kind === 'towers')) return false;
    if (kind === 'towers') {                                      // děti smazané věže se přesunou o patro výš
      var par = (TT[id] && TT[id].parent) || 'base';
      studio.childrenOf(id).forEach(function (c) { studio.set('towers', c, 'parent', par); });
    }
    if (e.custom) { delete items()[kind][id]; if (BD.store && BD.store.profile && BD.store.profile.studio && BD.store.profile.studio.items) delete BD.store.profile.studio.items[kind][id]; }
    else items()[kind][id] = { deleted: true };
    ['enemies', 'towers'].forEach(function (k) {                                               // odkazy na smazaného nepřítele z rozpadu
      Object.keys(items()[k]).forEach(function (o) { var q = items()[k][o]; if (kind === 'enemies' && k === 'enemies') { if (q.custom && q.def.splitInto === id) { q.def.splitInto = ''; q.def.splitCount = 0; } else if (q.patch && q.patch.splitInto === id) { delete q.patch.splitInto; delete q.patch.splitCount; } } });
    });
    studio.apply(); save(); return true;
  };
  /* smazané vestavěné věže (jdou obnovit) */
  studio.deleted = function (kind) { studio.rev; var it = items()[kind]; return Object.keys(it).filter(function (id) { return it[id].deleted; }); };
  studio.restore = function (kind, id) { var it = items()[kind]; if (it[id] && it[id].deleted) { delete it[id]; studio.apply(); save(); return true; } return false; };
  /* v kolika vzhledech (věží a nepřátel) je vložená šablona */
  studio.templateUsage = function (id) {
    studio.rev; var n = 0, SP = BD.render.sprite;
    ['towers', 'enemies'].forEach(function (k) { Object.keys(KINDS[k]).forEach(function (i) { var sp = KINDS[k][i].sprite; if (!sp || !sp.nodes) return; if (refsOf(sp).some(function (r) { return studio.tplReaches(r, id); })) n++; }); });    // i oklikou přes jiné šablony
    return n;
  };
  /* výchozí/aktuální hodnota pole pro formulář */
  studio.value = function (kind, id, path) { studio.rev; var o = KINDS[kind][id]; return o ? getPath(o, path) : undefined; };

  /* ---------- export / import ---------- */
  /* exportText()            = všechny úpravy;   exportText(druh, id) = jen jedna položka (stejný formát, jde načíst zpátky i do jiné hry) */
  studio.exportText = function (onlyKind, onlyId) {
    var it = items(), out = { game: 'BubbleDefence', type: 'studio', v: 1, items: emptyItems(), result: emptyItems() };
    KIND_LIST.forEach(function (kind) {
      Object.keys(it[kind]).forEach(function (id) { if (onlyId && (kind !== onlyKind || id !== onlyId)) return; if (!KINDS[kind][id] && !it[kind][id].deleted) return; out.items[kind][id] = clone(it[kind][id]); });   // jen to, co v seznamu opravdu je
      Object.keys(KINDS[kind]).forEach(function (id) {
        if (onlyId ? (kind === onlyKind && id === onlyId) : !!it[kind][id]) out.result[kind][id] = clone(KINDS[kind][id]);
      });
    });
    return JSON.stringify(out, null, 1);
  };
  /* čistí i data z postupu a z importu: jen známé cesty a hodnoty v mezích */
  studio.sanitize = function (src) {
    var out = { items: emptyItems() };
    if (!src || typeof src !== 'object' || !src.items) return out;
    KIND_LIST.forEach(function (kind) {
      var s = src.items[kind]; if (!s || typeof s !== 'object') return;
      Object.keys(s).slice(0, 150).forEach(function (id) {
        if (!ID_RE.test(id)) return; var e = s[id]; if (!e || typeof e !== 'object') return;
        if (e.custom && e.def && typeof e.def === 'object') {
          if (ORIG[kind][id]) return;
          var d = TEMPLATE[kind]();
          SCHEMA[kind].forEach(function (g) { g.fields.forEach(function (f) { var v = cleanValue(kind, f.k, getPath(e.def, f.k)); if (v !== undefined) setPath(d, f.k, v); }); });
          var spr = e.def.sprite ? BD.render.sprite.sanitize(e.def.sprite) : null; if (spr) d.sprite = spr;
          if (kind === 'ammo') ['muzzle', 'shot', 'impact'].forEach(function (ph) { var q = e.def[ph] && e.def[ph].sprite ? BD.render.sprite.sanitize(e.def[ph].sprite) : null; if (q) d[ph].sprite = q; });
          out.items[kind][id] = { custom: true, def: d };
        } else if (e.deleted && kind === 'towers' && id !== 'base' && ORIG[kind][id]) { out.items[kind][id] = { deleted: true };
        } else if (e.patch && typeof e.patch === 'object' && ORIG[kind][id]) {
          var p = {}; Object.keys(e.patch).forEach(function (path) { if (!fieldOf(kind, path)) return; var v = cleanValue(kind, path, e.patch[path]); if (v !== undefined && !same(v, getPath(ORIG[kind][id], path))) p[path] = v; });
          if (Object.keys(p).length) out.items[kind][id] = { patch: p };
        }
      });
    });
    return out;
  };
  studio.importText = function (text) {
    var o; try { o = JSON.parse(String(text).trim()); } catch (e) { return { ok: false, error: 'Text se nepodařilo přečíst (není to platný JSON).' }; }
    if (!o || o.game !== 'BubbleDefence' || o.type !== 'studio') return { ok: false, error: 'Tohle není export ze Studia.' };
    var c = studio.sanitize(o), n = 0, it = items();
    KIND_LIST.forEach(function (kind) { Object.keys(c.items[kind]).forEach(function (id) { it[kind][id] = c.items[kind][id]; n++; }); });
    if (!n) return { ok: false, error: 'V textu nejsou žádné použitelné úpravy.' };
    studio.apply(); save(); return { ok: true, count: n };
  };

  /* zapnutí / vypnutí (příkaz „dev“) */
  studio.enable = function (on) { studio.enabled = !!on; if (!on) BD.systems.waves.testEnemy = null; studio.apply(); };
})(window.BD);
