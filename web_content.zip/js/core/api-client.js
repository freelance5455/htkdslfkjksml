window.WorkspaceApi=(()=>{
  let mo2SnapshotBridge=false;
  async function decode(response,module){let payload={};try{payload=await response.json()}catch{}if(!response.ok){const error=new Error(payload.error||`Request failed (${response.status})`);error.status=response.status;window.WorkspaceErrors?.report(module||'api',error,{status:response.status,url:response.url});throw error}return payload}
  async function request(url,opt){
    const options={headers:{'Content-Type':'application/json'},...opt},path=String(url||''),bridgeable=path.startsWith('/api/mo2/')||path.startsWith('/api/private/'),module=`api:${path.split('?')[0]}`;
    if(bridgeable&&mo2SnapshotBridge){const port=Number(location.port||32145)+2;return decode(await fetch(`http://127.0.0.1:${port}${url}`,options),module)}
    const response=await fetch(url,options);
    if(bridgeable&&response.status===404){const port=Number(location.port||32145)+2;try{const retry=await fetch(`http://127.0.0.1:${port}${url}`,options);if(retry.ok)mo2SnapshotBridge=true;return decode(retry,module)}catch(error){window.WorkspaceErrors?.report('api:linux-bridge',error,{url})}}
    return decode(response,module)
  }
  return{request,isUsingMo2Bridge:()=>mo2SnapshotBridge};
})();
