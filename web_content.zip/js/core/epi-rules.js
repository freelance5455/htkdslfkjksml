function ageMonths(dob, vd){ let mo = (vd.year-dob.year)*12 + (vd.month-dob.month); if (vd.day < dob.day) mo -= 1; return mo; }

function classifyEpi(doses){
  const tags = [];
  if (doses.BCG === 'Y') tags.push('BCG');
  if (doses.HepB === 'Y') tags.push('HepB');
  if (doses.OPV === '0') tags.push('OPV0');
  // The dose LEVEL (1st / 2nd / 3rd) is decided ONLY by the vaccine-specific
  // columns (OPV/Penta/ROTA/PCV, and Measles/TCV below) — never by the IPV
  // column. IPV is given alongside different Penta/Measles visits depending
  // on the schedule variant in use (sometimes with Penta1, sometimes Penta2,
  // sometimes Penta3, sometimes with Measles1 or Measles2), so an IPV value
  // on its own does not reliably identify which visit it belongs to. Using it
  // as a trigger (as before) wrongly promoted plain Penta1/Penta2 visits that
  // happened to include IPV1 straight to "Penta3", and Penta3 visits that
  // happened to include IPV2 straight to "Measles1".
  if (doses.OPV==='1'||doses.Penta==='1'||doses.ROTA==='1'||doses.PCV==='1') tags.push('Penta1');
  if (doses.OPV==='2'||doses.Penta==='2'||doses.ROTA==='2'||doses.PCV==='2') tags.push('Penta2');
  if (doses.OPV==='3'||doses.Penta==='3'||doses.PCV==='3') tags.push('Penta3');
  if (doses.Measles==='1'||doses.TCV==='Y') tags.push('Measles1');
  if (doses.Measles==='2') tags.push('Measles2');
  return tags;
}

const EPI_LABELS = {
  BCG: 'BCG', HepB: 'Hepatitis B', OPV0: 'OPV-0 (Birth)', Penta1: 'Penta/OPV 1', Penta2: 'Penta/OPV 2',
  Penta3: 'Penta/OPV 3', Measles1: 'Measles 1', Measles2: 'Measles 2 / Booster'
};

// ---------- TT (Tetanus Toxoid — women's tetanus toxoid) ----------
// TT rows belong to women, not children — so a TT record must never be
// counted toward Measles2 or the 24+ months child age-bracket.
function isTtRecord(doses){ return ['1','2','3','4','5'].includes(doses.TT); }

function classifyTT(doses){
  const tags = [];
  if (doses.TT === '1') tags.push('TT1');
  if (doses.TT === '2') tags.push('TT2');
  if (doses.TT === '3') tags.push('TT3');
  if (doses.TT === '4') tags.push('TT4');
  if (doses.TT === '5') tags.push('TT5');
  return tags;
}

const TT_ORDER = ['TT1','TT2','TT3','TT4','TT5'];
const TT_LABELS = { TT1:'TT1', TT2:'TT2', TT3:'TT3', TT4:'TT4', TT5:'TT5' };

// ---------- merging multiple visits for the same child/woman (same QR code) ----------
// The same person can appear in several different Daily Registry PDFs — e.g.
// one vaccinator/center gives OPV-0 on one date, and a different
// vaccinator/center gives BCG on another date. Each such appearance is kept
// as its own "visit" (own date + vaccinator + center + the doses given that
// day) so the detail view can show exactly who gave what and when, while the
// record's overall `doses` stays merged (highest dose level reached) so
// counting/classification elsewhere in the app keeps working unchanged.
function compareDateObjs(a, b){
  if (!a && !b) return 0;
  if (!a) return -1;
  if (!b) return 1;
  return (a.year - b.year) || (a.month - b.month) || (a.day - b.day);
}

function mergeDoseValue(oldVal, newVal, colKey){
  if (oldVal == null || oldVal === '') return newVal;
  if (newVal == null || newVal === '') return oldVal;
  if (colKey === 'BCG' || colKey === 'HepB' || colKey === 'TCV') {
    return (oldVal === 'Y' || newVal === 'Y') ? 'Y' : newVal;
  }
  // Level-progression columns: OPV/Penta/ROTA/PCV (0-3), Measles/IPV (1-2), TT (1-5).
  const oldN = Number(oldVal), newN = Number(newVal);
  if (!isNaN(oldN) && !isNaN(newN)) return newN > oldN ? newVal : oldVal;
  return newVal;
}

function mergeDoses(oldDoses, newDoses){
  const merged = { ...(oldDoses || {}) };
  for (const k of Object.keys(newDoses || {})) merged[k] = mergeDoseValue(merged[k], newDoses[k], k);
  return merged;
}

// A visit's identity = its date + who gave it + exactly which doses it recorded.
// Visits used to be deduped by SOURCE FILE instead, which meant that when the
// same child appeared on two rows of one PDF (two doses recorded separately),
// the second row was silently thrown away. Comparing the visit itself keeps
// both rows while still ignoring a genuinely repeated import.
function visitKey(v){
  const d = v && v.vaccDate ? `${v.vaccDate.year}-${v.vaccDate.month}-${v.vaccDate.day}` : '';
  const doses = Object.keys(v && v.doses ? v.doses : {}).sort().map(k => `${k}=${v.doses[k]}`).join(',');
  return `${d}|${(v && v.vaccinatorName) || ''}|${(v && v.centerName) || ''}|${doses}`;
}
