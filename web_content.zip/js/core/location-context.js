// ============================================================
// location-context.js
// Reads the login selection (Name, Center, District, Tehsil, Union
// Council) that was saved to localStorage by login.html and
// location-select-test-1.html, and turns it into a ready-to-use
// classifier that decides, for any address printed on a Daily
// Immunization Report, whether that record belongs to:
//   - the selected Union Council                       -> "In UC"
//   - a different UC of the SAME Tehsil                -> "Out From UC"
//   - a different Tehsil of the SAME District           -> "Out From Taluka"
//   - a different District altogether                   -> "Out From District"
// This is decided purely from the Address column vs. the login
// selection — the report's own Identifier column ("Out of UC" text) is
// not used for this, since it marks a whole page the same way and
// cannot tell one UC's records apart from another's.
//
// This file must load AFTER js/data/sindh-locations.js and BEFORE
// js/parsers/registry-parser.js.
// ============================================================

const EPI_LOGIN_KEYS = {
  name: 'epi_login_name',
  center: 'epi_login_center',
  district: 'epi_login_district',
  tehsil: 'epi_login_tehsil',
  uc: 'epi_login_uc'
};

function epiReadLogin(){
  try {
    return {
      name: localStorage.getItem(EPI_LOGIN_KEYS.name) || '',
      center: localStorage.getItem(EPI_LOGIN_KEYS.center) || '',
      district: localStorage.getItem(EPI_LOGIN_KEYS.district) || '',
      tehsil: localStorage.getItem(EPI_LOGIN_KEYS.tehsil) || '',
      uc: localStorage.getItem(EPI_LOGIN_KEYS.uc) || ''
    };
  } catch (e) {
    return { name: '', center: '', district: '', tehsil: '', uc: '' };
  }
}

function epiSaveLogin(info){
  try {
    localStorage.setItem(EPI_LOGIN_KEYS.name, info.name || '');
    localStorage.setItem(EPI_LOGIN_KEYS.center, info.center || '');
    localStorage.setItem(EPI_LOGIN_KEYS.district, info.district || '');
    localStorage.setItem(EPI_LOGIN_KEYS.tehsil, info.tehsil || '');
    localStorage.setItem(EPI_LOGIN_KEYS.uc, info.uc || '');
    return true;
  } catch (e) { return false; }
}

function epiClearLogin(){
  try { Object.keys(EPI_LOGIN_KEYS).forEach(k => localStorage.removeItem(EPI_LOGIN_KEYS[k])); } catch (e) { /* ignore */ }
}

function epiHasLogin(){
  const l = epiReadLogin();
  return !!(l.name && l.center && l.district && l.tehsil && l.uc);
}

function epiRe(s){ return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function epiNormalizeAddress(address){
  return (address || '')
    .replace(/[–—]/g, '-')
    // Commas are just separators between Address / UC / Tehsil in the
    // report (e.g. "..., Jarwar, Mirpur Mathelo") — treat them the same as
    // whitespace so the UC/Tehsil regexes below match either way.
    .replace(/,/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/\s*-\s*/g, '- ')
    .trim();
}

// A Tehsil name is often shortened in the printed address to its first
// word (e.g. "Mirpur Mathelo" -> "Mirpur", "Tando Allahyar" -> "Tando").
// Accept both the full name and that short form.
function epiTehsilSpellings(tehsil){
  const spellings = [tehsil];
  const firstWord = (tehsil || '').split(' ')[0];
  if (firstWord && firstWord.length > 2 && firstWord !== tehsil) spellings.push(firstWord);
  return spellings;
}

// Build the regexes that match one UC name at the end of an address, for
// every accepted spelling of its Tehsil. UC names for the town-centre UC
// carry a trailing " 01"/" 02" — accept "1"/"01" interchangeably and an
// optional dash before the number (mirrors how these are actually printed).
function epiUcRegexes(ucName, tehsilSpellings){
  const m = /^(.*?)[\s-]*0?(\d)$/.exec(ucName.trim());
  const base = (m ? m[1] : ucName).trim().replace(/-$/, '').trim();
  const num = m ? m[2] : null;
  const baseEsc = epiRe(base);
  const list = [];
  for (const t of tehsilSpellings) {
    const tEsc = epiRe(t);
    if (num) {
      list.push(new RegExp('(?:^|[\\s,/-])' + baseEsc + '\\s*-?\\s*0?' + num + '\\s+(?:' + tEsc + ')$', 'i'));
    } else {
      list.push(new RegExp('(?:^|[\\s,/-])' + baseEsc + '\\s+(?:' + tEsc + ')$', 'i'));
    }
  }
  return list;
}

// Build the full classifier for the selected District/Tehsil/UC using the
// Sindh location dataset (window.SINDH_LOCATIONS). Returns null when the
// dataset or a saved selection isn't available — callers fall back
// gracefully in that case.
function epiBuildLocationContext(){
  const login = epiReadLogin();
  const data = (typeof window !== 'undefined' && window.SINDH_LOCATIONS) || null;
  if (!data || !login.district || !login.tehsil) return null;

  const tehsilsInDistrict = Object.keys(data[login.district] || {});
  const ucsInTehsil = (data[login.district] && data[login.district][login.tehsil]) || [];
  const tehsilSpellings = epiTehsilSpellings(login.tehsil);

  const ucMatchers = ucsInTehsil.map(uc => ({ uc, regexes: epiUcRegexes(uc, tehsilSpellings) }));

  const otherTehsilRegexes = tehsilsInDistrict
    .filter(t => t !== login.tehsil)
    .map(epiTehsilSpellings)
    .reduce((a, b) => a.concat(b), [])
    .map(s => new RegExp('(?:^|[\\s,/-])' + epiRe(s) + '$', 'i'));

  return {
    name: login.name,
    center: login.center,
    district: login.district,
    tehsil: login.tehsil,
    uc: login.uc,
    ucsInTehsil,
    tehsilsInDistrict,

    // Classify one address:
    //  { uc: <matched UC name from the selected Tehsil, or null>,
    //    status: 'in_uc' | 'out_taluka' | 'out_district' }
    // 'in_uc' here means "this address is inside the selected Tehsil, at
    // this UC" — whether the record itself is In UC or Out of UC still
    // comes from the report's Identifier column (see registry-parser.js).
    // Classify one address:
    //  { uc: <matched UC name from the selected Tehsil, or null>,
    //    status: 'in_uc' | 'out_uc' | 'out_taluka' | 'out_district' }
    //   - Address matches the LOGGED-IN UC                    -> in_uc
    //   - Address matches a DIFFERENT UC of the same Tehsil   -> out_uc  ("Out From UC")
    //   - Address matches a different Tehsil of the same District -> out_taluka ("Out From Taluka")
    //   - Address doesn't match the selected District at all  -> out_district ("Out From District")
    classifyAddress(address){
      const raw = epiNormalizeAddress(address);
      if (!raw) return { uc: null, status: 'out_district' };
      for (const m of ucMatchers) {
        if (m.regexes.some(re => re.test(raw))) {
          return { uc: m.uc, status: (m.uc === login.uc) ? 'in_uc' : 'out_uc' };
        }
      }
      if (otherTehsilRegexes.some(re => re.test(raw))) return { uc: null, status: 'out_taluka' };
      return { uc: null, status: 'out_district' };
    }
  };
}

window.EPI_LOCATION_CONTEXT = epiBuildLocationContext();
window.epiRebuildLocationContext = function(){ window.EPI_LOCATION_CONTEXT = epiBuildLocationContext(); return window.EPI_LOCATION_CONTEXT; };
window.epiReadLogin = epiReadLogin;
window.epiSaveLogin = epiSaveLogin;
window.epiClearLogin = epiClearLogin;
window.epiHasLogin = epiHasLogin;
