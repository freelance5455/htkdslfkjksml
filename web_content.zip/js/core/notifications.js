window.WorkspaceNotifications=(()=>{
  let timer=null;
  function show(message,{duration=1800,kind='info'}={}){const host=document.getElementById('toast');if(!host)return;host.textContent=String(message||'');host.dataset.kind=kind;host.classList.add('show');if(timer)clearTimeout(timer);timer=setTimeout(()=>host.classList.remove('show'),duration)}
  function error(message){show(message,{duration:2600,kind:'error'})}
  function clear(){const host=document.getElementById('toast');if(host)host.classList.remove('show');if(timer)clearTimeout(timer);timer=null}
  return{show,error,clear};
})();
