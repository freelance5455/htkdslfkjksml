window.WorkspaceGamePackLoader=(()=>{
  const LIST_URL='/api/game-packs';
  const states=new Map();
  const keyOf=value=>String(value||'').trim().toLowerCase();
  const cleanText=value=>String(value??'').trim();
  const versionParts=value=>cleanText(value).replace(/^v/i,'').split('.').map(part=>Number.parseInt(part,10)||0).slice(0,3).concat([0,0,0]).slice(0,3);
  function compareVersions(a,b){const A=versionParts(a),B=versionParts(b);for(let i=0;i<3;i++){if(A[i]!==B[i])return A[i]>B[i]?1:-1}return 0}
  function assert(condition,message){if(!condition)throw new Error(message)}
  async function fetchJson(url,fetcher=fetch){const response=await fetcher(url,{cache:'no-store'});if(!response?.ok)throw new Error(`HTTP ${response?.status||'error'} loading ${url}`);return response.json()}
  const titleOf=key=>key.split(/[._-]+/).filter(Boolean).map(part=>part.charAt(0).toUpperCase()+part.slice(1)).join(' ');
  function domainDescription(key){
    if(key==='quests')return'Base-game and official DLC quest knowledge supplied by the installed Game Pack.';
    return`${titleOf(key)} knowledge supplied by the installed Game Pack.`;
  }
  function validatePack(pack){
    assert(pack&&typeof pack==='object','Game Pack list entry must be an object');
    const gameId=keyOf(pack.game_id);assert(gameId,'Game Pack requires game_id');
    assert(/^[a-z0-9_-]+$/.test(gameId),`Unsafe Game Pack game_id: ${gameId}`);
    return{...pack,game_id:gameId,package_id:cleanText(pack.package_id),display_name:cleanText(pack.display_name)||gameId,version:cleanText(pack.version)||'unversioned',build:cleanText(pack.build)};
  }
  function validateKnowledgeIndex(index,gameId){
    assert(index&&typeof index==='object',`Game Pack ${gameId} knowledge index must be an object`);
    assert(keyOf(index.game_id)===gameId,`Game Pack ${gameId} knowledge index game_id mismatch`);
    assert(index.domains&&typeof index.domains==='object'&&!Array.isArray(index.domains),`Game Pack ${gameId} knowledge index requires domains`);
    return index;
  }
  function providerFromRuntime(pack,index){
    const categories=Object.entries(index.domains)
      .filter(([key,domain])=>key!=='mods'&&domain&&typeof domain==='object'&&!String(domain.status||'').startsWith('reserved'))
      .map(([key,domain])=>({
        key,
        title:titleOf(key),
        eyebrow:'GAME KNOWLEDGE',
        description:domainDescription(key),
        status:String(domain.status||'available'),
        adapter:`modular-${key}-v1`,
        dataUrl:`/api/game-pack/${pack.game_id}/knowledge/${encodeURIComponent(key)}`,
        count:()=>Number.isFinite(Number(domain.record_count))?Number(domain.record_count):null,
        metadata:{recordCount:Number(domain.record_count)||0,gameId:pack.game_id,packageId:pack.package_id,knowledgeStatus:index.status||''}
      }));
    return{
      id:pack.package_id||`game-pack-${pack.game_id}`,
      kind:'game_pack',
      label:pack.display_name,
      version:pack.version,
      state:'available',
      note:`Installed modular Game Pack ${pack.version}${pack.knowledge_current_through?` • knowledge current through ${pack.knowledge_current_through}`:''}.`,
      source:`/api/game-pack/${pack.game_id}/manifest`,
      manifest:{gameId:pack.game_id,packageId:pack.package_id,packVersion:pack.version,build:pack.build,knowledgeSchema:Number(index.schema_version)||1},
      capabilities:['modular_knowledge','runtime_discovery','independent_game_pack_versioning'],
      categories
    };
  }
  async function discover({registry,workspaceVersion='',fetcher=fetch,listUrl=LIST_URL}={}){
    assert(registry&&typeof registry.register==='function','Game Pack loader requires the Game Data Registry');
    let list;
    try{list=await fetchJson(listUrl,fetcher)}catch(error){states.set('*',{state:'runtime_error',error:error.message,loaded:0,rejected:0});return{ok:false,loaded:[],rejected:[{stage:'list',error:error.message}]}}
    const packs=Array.isArray(list?.packs)?list.packs:[],loaded=[],rejected=[],claimed=new Set();
    for(const raw of packs){
      let pack;
      try{
        pack=validatePack(raw);assert(!claimed.has(pack.game_id),`Multiple installed Game Packs claim ${pack.game_id}`);
        const index=validateKnowledgeIndex(await fetchJson(`/api/game-pack/${pack.game_id}/knowledge/index`,fetcher),pack.game_id);
        claimed.add(pack.game_id);registry.unregister(pack.game_id);
        const provider=registry.register(pack.game_id,providerFromRuntime(pack,index));
        const status={state:'loaded',gameId:pack.game_id,packId:pack.package_id,version:pack.version,build:pack.build,knowledgeStatus:index.status||'',workspaceVersion,provider};states.set(pack.game_id,status);loaded.push(status);
      }catch(error){const gameId=pack?.game_id||keyOf(raw?.game_id)||'unknown';registry.unregister(gameId);const status={state:'rejected',gameId,error:error.message};states.set(gameId,status);rejected.push(status)}
    }
    states.set('*',{state:'ready',loaded:loaded.length,rejected:rejected.length,listUrl});return{ok:true,loaded,rejected};
  }
  function status(gameKey='*'){return states.get(keyOf(gameKey)||'*')||null}
  return{discover,status,compareVersions,validatePack,validateKnowledgeIndex,providerFromRuntime,constants:{LIST_URL}};
})();
