// ============================================================
// DIALOGS + SMALL TEXT HELPERS — confirmDialog, chooseAction (Share/Download),
// chooseExportStyle (Card/Print), escapeHtml and label helpers.
// ============================================================

// ---------- Modal stack ----------
// Every on-screen dialog below (confirmDialog / chooseExportStyle / chooseAction)
// registers its own "cancel" here while it is open. This lets the phone's
// hardware/gesture BACK button close just the dialog on top instead of falling
// through to the page navigation underneath — which, before this existed, could
// land on the main menu with nothing "open" (as far as navigation.js could see)
// and pop the "Do you want to exit the app?" confirmation on top of whatever
// dialog the person was actually trying to dismiss. See js/platform/navigation.js.
const openModalStack = [];

// Called by navigation.js before it does anything else with a back press.
// Returns true (and closes the top-most dialog as a cancel) if one was open.
function closeTopModal(){
  if (!openModalStack.length) return false;
  openModalStack[openModalStack.length - 1]();
  return true;
}

// Replacement for window.confirm(). Inside a sandboxed iframe (and in some
// Android WebView builds) confirm() never opens and returns undefined, so
// `if (!confirm(...)) return;` bailed out every time and buttons like
// "Clear All Saved Data" and the 🗑 delete buttons appeared completely dead.
// This draws the question in the page itself, so it works everywhere.
function confirmDialog(message, okLabel){
  return new Promise(resolve => {
    const back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.innerHTML = `<div class="modal-box" role="dialog" aria-modal="true">
      <div class="modal-msg"></div>
      <div class="modal-actions">
        <button type="button" class="go secondary" data-answer="no">Cancel</button>
        <button type="button" class="go danger" data-answer="yes"></button>
      </div>
    </div>`;
    back.querySelector('.modal-msg').textContent = message;
    back.querySelector('[data-answer="yes"]').textContent = okLabel || 'Yes, continue';
    let settled = false;
    const cancelFromBack = () => finish(false);
    const finish = value => {
      if (settled) return;
      settled = true;
      back.remove();
      document.removeEventListener('keydown', onKey);
      const idx = openModalStack.indexOf(cancelFromBack);
      if (idx !== -1) openModalStack.splice(idx, 1);
      resolve(value);
    };
    const onKey = e => { if (e.key === 'Escape') finish(false); };
    back.addEventListener('click', e => {
      if (e.target === back) return finish(false);           // tap outside = cancel
      const btn = e.target.closest('[data-answer]');
      if (btn) finish(btn.dataset.answer === 'yes');
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    openModalStack.push(cancelFromBack);
    const yes = back.querySelector('[data-answer="yes"]');
    if (yes && yes.focus) yes.focus();
  });
}

// Lets the person pick between a full data table ("Print Style") and a
// one-card-per-record layout ("Card Style", matching the on-screen record
// cards) before a PDF is built. Resolves to 'print', 'card', or null if the
// person cancelled.
function chooseExportStyle(){
  return new Promise(resolve => {
    const back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.innerHTML = `<div class="modal-box" role="dialog" aria-modal="true">
      <div class="modal-msg">Choose a style for this PDF:</div>
      <div class="modal-actions" style="flex-direction:column;gap:8px;">
        <button type="button" class="go secondary" data-answer="card">🗂 Card Style (one card per child, like on screen)</button>
        <button type="button" class="go" data-answer="print">📋 Print Style (compact table)</button>
        <button type="button" class="go secondary" data-answer="cancel" style="background:transparent;border:none;color:var(--muted);margin-top:0;">Cancel</button>
      </div>
    </div>`;
    let settled = false;
    const cancelFromBack = () => finish(null);
    const finish = value => {
      if (settled) return;
      settled = true;
      back.remove();
      document.removeEventListener('keydown', onKey);
      const idx = openModalStack.indexOf(cancelFromBack);
      if (idx !== -1) openModalStack.splice(idx, 1);
      resolve(value);
    };
    const onKey = e => { if (e.key === 'Escape') finish(null); };
    back.addEventListener('click', e => {
      if (e.target === back) return finish(null);            // tap outside = cancel
      const btn = e.target.closest('[data-answer]');
      if (btn) finish(btn.dataset.answer === 'cancel' ? null : btn.dataset.answer);
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    openModalStack.push(cancelFromBack);
  });
}

// First step of the export flow: Share (native share sheet) or Download
// (save to the device). Resolves to 'share', 'download', or null if
// the person cancelled.
function chooseAction(){
  return new Promise(resolve => {
    const back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.innerHTML = `<div class="modal-box" role="dialog" aria-modal="true">
      <div class="modal-msg">Share or download this result?</div>
      <div class="modal-actions" style="flex-direction:column;gap:8px;">
        <button type="button" class="go" data-answer="share">📤 Share</button>
        <button type="button" class="go secondary" data-answer="download">⬇ Download</button>
        <button type="button" class="go secondary" data-answer="cancel" style="background:transparent;border:none;color:var(--muted);margin-top:0;">Cancel</button>
      </div>
    </div>`;
    let settled = false;
    const cancelFromBack = () => finish(null);
    const finish = value => {
      if (settled) return;
      settled = true;
      back.remove();
      document.removeEventListener('keydown', onKey);
      const idx = openModalStack.indexOf(cancelFromBack);
      if (idx !== -1) openModalStack.splice(idx, 1);
      resolve(value);
    };
    const onKey = e => { if (e.key === 'Escape') finish(null); };
    back.addEventListener('click', e => {
      if (e.target === back) return finish(null);            // tap outside = cancel
      const btn = e.target.closest('[data-answer]');
      if (btn) {
        // A tap is the only moment a phone lets the app ask for notification
        // permission, so it is asked here (used for the download notification).
        if (btn.dataset.answer === 'download') NativeBridge.primeNotifications();
        finish(btn.dataset.answer === 'cancel' ? null : btn.dataset.answer);
      }
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    openModalStack.push(cancelFromBack);
  });
}

// Escapes for BOTH text content and attribute values. The old version used
// textContent -> innerHTML, which leaves " and ' untouched — and this output is
// placed inside attributes such as data-key="..." and title="...", so a
// filename or address containing a quote could break the markup.
function escapeHtml(str){
  return String(str == null ? '' : str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Combine the vaccinator's name with the health center/facility name printed
// on the source PDF (e.g. "Sakhawat — GD Khalidabad"), so the Vaccinator
// field always shows both pieces of information together when known.
function vaccinatorCenterLabel(r){
  const v = (r.vaccinatorName || '').trim();
  const c = (r.centerName || '').trim();
  if (v && c) return `${v} — ${c}`;
  if (v) return v;
  if (c) return c;
  return null;
}

// Escape each line separately and join with <br> so a multi-visit breakdown
// (one line per visit) renders as separate lines instead of running together.
function escapeHtmlMultiline(text){
  return String(text == null ? '' : text).split('\n').map(escapeHtml).join('<br>');
}

// The vaccine(s) actually given during one specific visit (own doses snapshot).
function visitTagLabel(v){
  const isTt = isTtRecord(v.doses);
  const tags = isTt ? classifyTT(v.doses) : classifyEpi(v.doses);
  if (!tags.length) return isTt ? 'No TT dose recorded' : 'No vaccine recorded';
  return tags.map(t => isTt ? (TT_LABELS[t] || t) : (EPI_SHORT[t] || t)).join(', ');
}

// When a child/woman has more than one recorded visit (different date and/or
// different vaccinator/center), build a per-visit breakdown so "Vaccination
// Date" and "Vaccinator" each show every visit's date and who gave it,
// lined up against exactly which vaccine that visit was for. With only one
// visit (or on older records saved before visit-tracking existed), this
// falls back to the plain single-value text as before.
function dateAndVaccinatorText(r){
  const singleDate = dmy(r.vaccDate) || '—';
  const singleWho = vaccinatorCenterLabel(r) || '—';
  if (!r.visits || r.visits.length <= 1) return { dateText: singleDate, vaccinatorText: singleWho };
  const sorted = r.visits.slice().sort((a, b) => compareDateObjs(a.vaccDate, b.vaccDate));
  const dateText = sorted.map(v => `${visitTagLabel(v)}: ${dmy(v.vaccDate) || '—'}`).join('\n');
  const vaccinatorText = sorted.map(v => `${visitTagLabel(v)}: ${vaccinatorCenterLabel(v) || '—'}`).join('\n');
  return { dateText, vaccinatorText };
}
