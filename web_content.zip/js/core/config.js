/* Konfigurasi & utilitas dasar. Semua modul memakai namespace global SU (aman untuk file:// di WebView). */
(function (g) {
  'use strict';
  const SU = (g.SU = g.SU || {});
  SU.config = {
    CELL: 16, GRID0: 25, GRID_MAX: 50, SPEED0: 8, SPEED_MAX: 30, SPEED_MIN: 4,
    SPEED_EVERY: 5, GRID_EVERY: 8,
    FURY_SCORE: 30, FURY_DUR: 10, MIRROR_EVERY: 20,
    DASH_DUR: 0.2, DASH_CD: 3, SLOW_ZONE_DUR: 5, SLIDE_DUR: 1.5,
    COMBO_THRESHOLD: 3, COMBO_BONUS: 5, COMBO_WINDOW: 4, SHADOW_SCORE: 50,
    MAX_DT: 0.1, MAX_STEPS: 4, SWIPE_MIN: 30, MAX_PARTICLES: 120,
    SCHEMA: 1, PREFIX: 'ular_super:'
  };
  SU.util = {
    $: function (id) { return g.document ? g.document.getElementById(id) : null; },
    clamp: function (v, a, b) { return Math.min(b, Math.max(a, v)); },
    isNum: function (v, a, b) { return typeof v === 'number' && isFinite(v) && v >= a && v <= b; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
