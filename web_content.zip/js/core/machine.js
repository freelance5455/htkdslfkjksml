/* State machine eksplisit: satu sumber kebenaran untuk state aplikasi. */
(function (g) {
  'use strict';
  const SU = g.SU;
  const T = {
    boot: ['menu'],
    menu: ['playing', 'settings'],
    playing: ['paused', 'lifeLost', 'extraLife', 'gameOver'],
    paused: ['playing', 'settings', 'menu', 'confirm'],
    lifeLost: ['playing', 'settings'],
    extraLife: ['lifeLost', 'gameOver'],
    gameOver: ['menu', 'playing', 'settings'],
    settings: ['menu', 'paused', 'lifeLost', 'gameOver', 'confirm'],
    confirm: ['settings', 'paused']
  };
  const OVERLAY = { settings: 1, confirm: 1 };
  const M = (SU.machine = {
    state: 'boot', prev: null, stack: [], table: T, listeners: [],
    can: function (to) { return (T[M.state] || []).indexOf(to) >= 0; },
    _set: function (to) { M.prev = M.state; M.state = to; M.listeners.forEach(function (f) { f(to, M.prev); }); },
    go: function (to) {
      if (!M.can(to)) return false;
      if (OVERLAY[to]) M.stack.push(M.state); else M.stack = [];
      M._set(to); return true;
    },
    /* Kembali dari overlay (settings/confirm) ke state sebelumnya, berlapis. */
    back: function () {
      if (!M.stack.length) return false;
      const t = M.stack[M.stack.length - 1];
      if (!M.can(t)) return false;
      M.stack.pop(); M._set(t); return true;
    },
    on: function (f) { M.listeners.push(f); },
    reset: function () { M.state = 'boot'; M.prev = null; M.stack = []; }
  });
})(typeof window !== 'undefined' ? window : globalThis);
