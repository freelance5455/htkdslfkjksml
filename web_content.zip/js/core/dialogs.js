window.WorkspaceDialogs=(()=>{
  function node(id){return document.getElementById(id)}
  function open(id){const dialog=node(id);if(!dialog)throw new Error(`Dialog not found: ${id}`);if(typeof dialog.showModal==='function'&&!dialog.open)dialog.showModal();return dialog}
  function close(id){const dialog=node(id);if(dialog?.open&&typeof dialog.close==='function')dialog.close();return dialog}
  function isOpen(id){return Boolean(node(id)?.open)}
  return{open,close,isOpen};
})();
