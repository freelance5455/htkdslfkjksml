/* Bootstrap & orkestrasi: state machine, satu game loop (requestAnimationFrame), aksi New/Resume/Restart terpisah. */
(function (g) {
  'use strict';
  const SU = g.SU, C = SU.config, E = SU.engine, M = SU.machine, UI = SU.ui, AU = SU.audio, $ = SU.util.$, doc = g.document;
  const SPECIAL_PW = 'asrifqi hebat'; /* easter egg lokal, bukan keamanan */

  function safeLS() {
    try { const t = '__ular_test'; g.localStorage.setItem(t, '1'); g.localStorage.removeItem(t); return { ls: g.localStorage, persistent: true }; }
    catch (e) { const m = {}; return { persistent: false, ls: { getItem: function (k) { return k in m ? m[k] : null; }, setItem: function (k, v) { m[k] = String(v); }, removeItem: function (k) { delete m[k]; } } }; }
  }
  const lsInfo = safeLS(), store = SU.createStore(lsInfo.ls);
  store.migrate();
  const settings = store.getSettings();
  let unlocks = store.getUnlocks(), high = store.getHigh(), hadHigh = high;
  let s = null, raf = 0, last = null, fpsN = 0, fpsT = 0;
  const ctx = $('gameCanvas').getContext('2d');
  const IN = function (a) { return a.indexOf(M.state) >= 0; };

  function applySettings() {
    AU.set({ fx: settings.fxSound, fxVol: settings.fxVolume, bg: settings.bgSound, bgVol: settings.bgVolume, theme: settings.theme });
    SU.fx.reduced = settings.reducedMotion; doc.body.classList.toggle('reduced', settings.reducedMotion);
    $('dpad').hidden = settings.control !== 'dpad'; $('fpsDisplay').hidden = !settings.showFps;
    if (!settings.bgSound) AU.musicStop();
  }
  function render(now) { SU.render.draw(ctx, s, settings.theme, { now: now || 0 }); }
  function hud() {
    const P = E.POWERS, t = s ? s.t : 0, v = { score: s ? s.score : 0, lives: s ? s.lives : 3, high: Math.max(high, s ? s.score : 0), badges: [], chips: [], dashLabel: 'DASH', dashEnabled: false };
    if (s) {
      if (s.fury > 0) v.badges.push({ cls: 'fury', text: 'FURY ' + Math.ceil(s.fury) + ' dtk' });
      if (s.combo >= C.COMBO_THRESHOLD) v.badges.push({ cls: 'combo', text: 'COMBO ×' + s.combo });
      if (s.mirror) v.badges.push({ cls: 'mirror', text: 'MIRROR' });
      if (E.sliding(s)) v.badges.push({ cls: 'ice', text: 'LICIN' });
      Object.keys(s.active).forEach(function (k) { if (s.active[k] > t) v.chips.push({ tag: P[k].tag, name: P[k].name, color: P[k].color, left: Math.ceil(s.active[k] - t) }); });
      v.dashLabel = s.dash > 0 ? 'DASH…' : s.dashCd > 0 ? 'DASH ' + Math.ceil(s.dashCd) + ' dtk' : 'DASH';
      v.dashEnabled = M.state === 'playing' && s.dash <= 0 && s.dashCd <= 0;
    }
    UI.hud(v);
  }
  function buttons() {
    const st = M.state, p = $('pauseButton');
    p.disabled = !IN(['playing', 'paused']); p.textContent = st === 'paused' ? 'Lanjutkan' : 'Jeda';
    $('restartButton').disabled = !IN(['playing', 'paused']);
    $('saveButton').disabled = !s || !IN(['playing', 'paused', 'lifeLost']);
    $('loadButton').disabled = !store.hasSave() || !IN(['menu', 'paused', 'lifeLost', 'gameOver']);
    $('settingsButton').disabled = !IN(['menu', 'playing', 'paused', 'lifeLost', 'gameOver']);
    if (st !== 'playing') $('dashButton').disabled = true;
  }
  M.on(buttons);
  function commitHigh() { if (s && s.score > high) { high = s.score; store.setHigh(high); } }

  /* ---- Loop tunggal ---- */
  function startLoop() { if (raf) return; last = null; raf = g.requestAnimationFrame(frame); }
  function stopLoop() { if (raf) g.cancelAnimationFrame(raf); raf = 0; last = null; }
  function frame(ts) {
    raf = g.requestAnimationFrame(frame);
    if (last === null) last = ts;
    const dt = Math.min(C.MAX_DT, Math.max(0, (ts - last) / 1000)); last = ts;
    if (M.state === 'playing' && s) {
      const r = E.tick(s, dt); drain(); SU.fx.update(dt); render(ts); hud(); fps(ts);
      if (r === 'life') onLife(); else if (r === 'dead') onDead();
    } else if (SU.fx.list.length) { SU.fx.update(dt); render(ts); } /* hanya sisa efek (mis. kembang api) */
    else stopLoop();
  }
  function fps(ts) {
    fpsN++; if (ts - fpsT < 1000) return;
    if (settings.showFps) { const v = Math.round(fpsN * 1000 / (ts - fpsT)); $('fpsValue').textContent = v; $('fpsValue').style.color = v < 30 ? '#e74c3c' : v < 50 ? '#f1c40f' : '#2ecc71'; }
    fpsN = 0; fpsT = ts;
  }
  function drain() {
    const ev = s.events.splice(0, s.events.length), head = s.snake[0];
    ev.forEach(function (e) {
      if (e.type === 'eat') { SU.fx.text(e.x, e.y, '+' + e.points); SU.fx.burst(e.x, e.y, e.rare ? '#f1c40f' : '#fff', 6); AU.sfx('eat'); commitHigh(); }
      else if (e.type === 'coin') { SU.fx.text(e.x, e.y, '+10', '#ffcc00'); AU.sfx('powerup'); commitHigh(); }
      else if (e.type === 'powerup' || e.type === 'box') { SU.fx.text(head.x, head.y, e.power ? E.POWERS[e.power].name : '?', '#fff'); AU.sfx('powerup'); }
      else if (e.type === 'combo') { SU.fx.text(head.x, head.y - 1, 'COMBO +' + e.bonus, '#2ecc71'); }
      else if (e.type === 'hit' || e.type === 'shieldBreak') AU.sfx('hit');
      else if (e.type === 'explode') SU.fx.burst(e.x, e.y, '#c0392b', 12);
      else if (e.type === 'portal') SU.fx.burst(head.x, head.y, '#9b59b6', 8);
      else if (e.type === 'dash') SU.fx.burst(head.x, head.y, '#f39c12', 6);
      else if (e.type === 'grow') UI.toast('Papan membesar');
      else if (e.type === 'fury') UI.toast('FURY aktif: skor ×2');
      else if (e.type === 'mirror') UI.toast(e.on ? 'Mode cermin AKTIF: arah terbalik' : 'Mode cermin selesai');
      else if (e.type === 'boardFull') finish('Papan penuh, kamu menang!');
    });
  }

  /* ---- Aksi (intent eksplisit: NEW vs RESUME) ---- */
  function newGame() {
    AU.ensure(); s = E.create(); hadHigh = high; SU.fx.clear();
    if (!M.go('playing')) return;
    UI.overlay.hide(); UI.hudReset(); AU.musicStop(); AU.musicStart(); startLoop(); render(); hud(); buttons();
  }
  function resume() {
    if (!IN(['paused', 'lifeLost']) || !s || !M.go('playing')) return;
    AU.ensure(); UI.overlay.hide(); AU.musicStart(); startLoop(); hud();
  }
  function pause() {
    if (M.state === 'paused') return resume();
    if (M.state !== 'playing' || !M.go('paused')) return;
    AU.musicStop();
    UI.overlay.show({ title: 'Dijeda', msg: 'Permainan berhenti. Skor, nyawa, dan power-up tetap.', buttons: [{ label: 'Lanjutkan', cls: 'primary', onClick: resume }] });
  }
  function toMenu() {
    s = null; SU.fx.clear(); UI.hudReset(); AU.musicStop();
    if (M.state !== 'menu') M.go('menu');
    const btn = [{ label: 'Mulai Permainan', cls: 'primary', onClick: newGame }];
    if (store.hasSave()) btn.push({ label: 'Lanjutkan Simpanan', cls: '', onClick: loadSaved });
    UI.overlay.show({ title: 'Game Ular Super', msg: 'Geser di area permainan (atau pakai D-pad) untuk mengarahkan ular. Kumpulkan makanan, hindari rintangan.', buttons: btn });
    render(); hud(); buttons();
  }
  function onLife() {
    stopLoop(); AU.musicStop(); M.go('lifeLost'); render();
    UI.overlay.show({ title: 'Kehilangan nyawa', msg: 'Nyawa tersisa: ' + s.lives + '. Ular kembali ke tengah; skor dan progres tetap.', buttons: [{ label: 'Lanjutkan', cls: 'primary', onClick: resume }] });
  }
  function onDead() {
    stopLoop(); AU.musicStop(); commitHigh(); render();
    if (!s.extraUsed && M.go('extraLife')) {
      UI.overlay.show({ title: 'Nyawa habis', msg: 'Skor ' + s.score + ' (skor tertinggi sudah tersimpan). Kesempatan terakhir: ambil 1 nyawa tambahan, skor dimulai lagi dari 0.',
        buttons: [{ label: 'Ambil nyawa tambahan', cls: 'primary', onClick: takeExtra }, { label: 'Akhiri permainan', cls: 'danger', onClick: function () { finish(); } }] });
    } else finish();
  }
  function takeExtra() {
    E.grantExtraLife(s); M.go('lifeLost'); UI.hudReset(); render(); hud();
    UI.overlay.show({ title: 'Nyawa tambahan', msg: 'Nyawa: 1. Skor dimulai dari 0.', buttons: [{ label: 'Lanjutkan', cls: 'primary', onClick: resume }] });
  }
  function finish(note) {
    stopLoop(); AU.musicStop(); commitHigh();
    if (!IN(['gameOver']) && !M.go('gameOver')) return;
    AU.sfx('gameOver'); const rec = high > hadHigh;
    if (rec) { SU.fx.fireworks(s.grid); startLoop(); }
    render(); hud();
    UI.overlay.show({ title: 'Game Over', msg: (note ? note + ' ' : '') + 'Skor: ' + s.score + '. Tertinggi: ' + high + '.' + (rec ? ' Rekor baru!' : ''),
      buttons: [{ label: 'Main Lagi', cls: 'primary', onClick: newGame }, { label: 'Menu Utama', cls: '', onClick: toMenu }] });
  }
  function restart() {
    if (!IN(['playing', 'paused'])) return;
    pause(); if (!M.go('confirm')) return;
    const back = function () { UI.modal.close(); M.back(); };
    UI.confirm({ title: 'Ulangi permainan?', text: 'Sesi saat ini (skor ' + s.score + ') berakhir dan sesi baru dimulai. Skor tertinggi tetap aman.', confirmLabel: 'Ulangi', delay: 0,
      onConfirm: function () { UI.modal.close(); M.back(); commitHigh(); newGame(); }, onCancel: back });
  }
  function save() {
    if (!s || !IN(['playing', 'paused', 'lifeLost'])) return;
    const r = store.saveSession(E.snapshot(s));
    UI.toast(r.ok ? 'Permainan disimpan' : r.error === 'quota' ? 'Gagal menyimpan: penyimpanan perangkat penuh' : 'Gagal menyimpan permainan'); buttons();
  }
  function loadSaved() {
    if (!IN(['menu', 'paused', 'lifeLost', 'gameOver'])) return;
    const r = store.loadSave();
    if (r.status === 'none') { UI.toast('Belum ada simpanan'); return buttons(); }
    if (r.status === 'corrupt') { UI.toast('Simpanan rusak/tidak valid dan tidak dimuat. Hapus lewat Pengaturan.'); return; }
    AU.ensure(); s = r.session; hadHigh = high; SU.fx.clear();
    if (!M.go('playing')) return; M.go('paused'); AU.musicStop(); UI.hudReset(); render(); hud();
    UI.overlay.show({ title: 'Simpanan dimuat', msg: 'Skor ' + s.score + ', nyawa ' + s.lives + '.' + (r.legacy ? ' (Format lama dimigrasikan; power-up yang sedang aktif tidak ikut dipulihkan.)' : ''), buttons: [{ label: 'Lanjutkan', cls: 'primary', onClick: resume }] });
  }

  /* ---- Pengaturan, backup, reset ---- */
  const RESET_TEXT = {
    settings: ['Reset pengaturan?', 'Suara, tema, kontrol, dan opsi lain kembali ke bawaan. Skor tertinggi dan simpanan tidak terpengaruh.', 0],
    save: ['Hapus simpanan game?', 'Simpanan game akan dihapus permanen (termasuk simpanan format lama). Skor tertinggi tidak terpengaruh.', 0],
    progress: ['Reset progres?', 'Skor tertinggi, unlock tema Special, dan simpanan game dihapus permanen. Pengaturan tetap. Disarankan ekspor backup dulu. Game akan dimuat ulang.', 3],
    all: ['Reset semua data game?', 'Seluruh data Game Ular Super (pengaturan, skor tertinggi, unlock, simpanan) dihapus permanen. Data aplikasi lain di perangkat tidak terpengaruh. Game akan dimuat ulang.', 3]
  };
  function openSettings() {
    if (M.state === 'playing') pause();
    if (!M.go('settings')) return;
    showSettings();
  }
  function showSettings() {
    UI.settings({
      settings: settings, unlocks: unlocks,
      change: function (p) { store.setSettings(p); Object.assign(settings, store.getSettings()); applySettings(); },
      theme: function (id) {
        if (id === 'special' && !unlocks.special) {
          UI.password({ check: function (v) { return v.trim().toLowerCase() === SPECIAL_PW; },
            onOk: function () { store.setUnlock('special'); unlocks = store.getUnlocks(); store.setSettings({ theme: 'special' }); Object.assign(settings, store.getSettings()); applySettings(); render(); UI.toast('Tema Special dibuka'); showSettings(); },
            onCancel: showSettings });
          return false;
        }
        store.setSettings({ theme: id }); Object.assign(settings, store.getSettings()); applySettings(); render(); return true;
      },
      exportBackup: exportBackup, importFile: importFile,
      reset: function (scope) {
        if (!M.go('confirm')) return; const t = RESET_TEXT[scope];
        const back = function () { UI.modal.close(); M.back(); showSettings(); };
        UI.confirm({ title: t[0], text: t[1], confirmLabel: 'Hapus', delay: t[2], onCancel: back,
          onConfirm: function () {
            store.reset(scope);
            if (scope === 'progress' || scope === 'all') { g.location.reload(); return; }
            Object.assign(settings, store.getSettings()); applySettings(); render(); buttons(); back(); UI.toast('Selesai');
          } });
      },
      close: function () { UI.modal.close(); M.back(); if (M.state === 'menu') toMenu(); buttons(); }
    });
  }
  function exportBackup() {
    try {
      const blob = new g.Blob([store.exportBackup()], { type: 'application/json' }), a = doc.createElement('a');
      a.href = g.URL.createObjectURL(blob); a.download = 'game-ular-super-backup.json'; doc.body.appendChild(a); a.click(); a.remove();
      g.setTimeout(function () { g.URL.revokeObjectURL(a.href); }, 4000);
      UI.toast('Backup dibuat. Jika berkas tidak muncul, wrapper WebView belum mengizinkan unduhan.');
    } catch (e) { UI.toast('Gagal membuat backup di perangkat ini'); }
  }
  function importFile(file) {
    const fr = new g.FileReader();
    fr.onerror = function () { UI.toast('Berkas tidak dapat dibaca'); };
    fr.onload = function () {
      const p = store.parseBackup(String(fr.result));
      if (!p.ok) { UI.toast('Impor ditolak: ' + p.errors[0]); return; }
      const apply = function (mode) {
        store.applyBackup(p.data, mode); Object.assign(settings, store.getSettings()); unlocks = store.getUnlocks(); high = store.getHigh();
        applySettings(); render(); UI.hudReset(); buttons(); UI.toast('Backup dipulihkan (' + (mode === 'merge' ? 'digabung' : 'menimpa') + ')'); showSettings();
      };
      const b = function (label, cls, fn) { return UI.h('button', { type: 'button', class: 'btn ' + cls, text: label, onclick: fn }); };
      UI.modal.open('Impor backup', UI.h('div', {}, [
        UI.h('p', { class: 'note', text: 'Backup valid (skor tertinggi ' + p.data.highScore + '). Pilih cara memulihkan:' }),
        UI.h('p', { class: 'note', text: 'Timpa: pengaturan, skor, unlock, dan simpanan diganti isi backup. Gabung: ambil skor tertinggi & unlock terbaik; pengaturan dan simpanan saat ini dipertahankan.' }),
        UI.h('div', { class: 'actions col' }, [b('Timpa data saat ini', 'danger', function () { apply('overwrite'); }), b('Gabungkan', 'primary', function () { apply('merge'); }), b('Batal', '', showSettings)])]), showSettings);
    };
    fr.readAsText(file);
  }

  /* ---- Start ---- */
  SU.input.init({
    control: function () { return settings.control; }, active: function () { return M.state === 'playing'; },
    canPause: function () { return IN(['playing', 'paused']); }, pause: pause,
    dir: function (x, y) { if (M.state === 'playing' && s) E.setDir(s, x, y); },
    dash: function () { if (M.state === 'playing' && s) E.startDash(s); }
  });
  $('pauseButton').addEventListener('click', pause);
  $('restartButton').addEventListener('click', restart);
  $('settingsButton').addEventListener('click', openSettings);
  $('saveButton').addEventListener('click', save);
  $('loadButton').addEventListener('click', loadSaved);
  doc.addEventListener('visibilitychange', function () { if (doc.hidden && M.state === 'playing') pause(); });
  g.addEventListener('pagehide', function () { if (M.state === 'playing') pause(); });

  applySettings(); M.go('menu'); toMenu();
  if (!lsInfo.persistent) UI.toast('Penyimpanan permanen tidak tersedia; data hanya bertahan selama sesi ini.');
  SU.app = { state: function () { return M.state; }, session: function () { return s; }, store: store }; /* hook diagnostik/tes */
})(window);
