/* Dev – vývojářský terminál: stav, příkazy a živý log.
   Odemkne se napsáním slova „terminal“ kdekoli ve hře (pamatuje se v tomto prohlížeči), otevírá se klávesou ` / ~ (klávesa nad Tabem).
   Nový příkaz = jeden řádek: BD.dev.command('jmeno', 'nápověda', function (args, out) { out('text'); });
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var KEY = 'bd.dev.v1';
  function load() { try { var o = JSON.parse(localStorage.getItem(KEY) || '{}'); return { unlocked: !!o.unlocked, studio: !!o.studio && !!o.unlocked }; } catch (e) { return { unlocked: false, studio: false }; } }
  function save() { try { localStorage.setItem(KEY, JSON.stringify({ unlocked: dev.unlocked, studio: dev.studio })); } catch (e) {} }

  var init = load();
  var dev = BD.dev = Vue.reactive({
    unlocked: init.unlocked, studio: init.studio, open: false,
    god: false, allLevels: false, liveLog: false,
    log: [], notice: '', game: null,
  });
  var cmds = {}, order = [], t0 = Date.now(), noticeT = 0;

  dev.unlock = function () {
    if (dev.unlocked) { dev.say('Terminál už je odemčený: otevři ho klávesou ` nebo ~.'); return; }
    dev.unlocked = true; save();
    dev.say('Terminál odemčen. Otevřeš ho klávesou ` nebo ~ (nad Tabem).');
  };
  dev.lock = function () { dev.unlocked = false; dev.open = false; dev.studio = false; BD.studio.enable(false); save(); };
  /* obnova stavu z exportu postupu: { unlocked, studio } (bez údaje se nic nemění) */
  dev.restore = function (st) {
    if (!st || typeof st !== 'object') return;
    dev.unlocked = !!st.unlocked; dev.studio = dev.unlocked && !!st.studio; if (!dev.unlocked) dev.open = false;
    save(); BD.studio.enable(dev.studio);
  };
  dev.say = function (text) { dev.notice = text; clearTimeout(noticeT); noticeT = setTimeout(function () { dev.notice = ''; }, 4500); };
  dev.toggle = function (force) { if (!dev.unlocked) return; dev.open = force === undefined ? !dev.open : !!force; };

  /* živý log */
  dev.write = function (text) {
    if (!dev.liveLog) return;
    var s = Math.round((Date.now() - t0) / 100) / 10;
    dev.log.push({ t: s, text: text }); if (dev.log.length > 200) dev.log.splice(0, dev.log.length - 200);
  };
  dev.snapshot = function () {
    var g = dev.game; if (!g) return 'mimo hru';
    return 'vlna ' + g.wave + '/' + (g.maxWaves || '∞') + ' · nepřátel ' + g.enemies.filter(function (e) { return e.alive; }).length + ' · zlato ' + Math.floor(g.gold) + ' · životy ' + g.lives + ' · věží ' + g.towers.length;
  };

  /* hra se tu zaregistruje při otevření: obalí se její akce, aby šly zapsat do logu */
  dev.attach = function (g) {
    dev.game = g;
    function wrap(name, fn) { var o = g[name]; g[name] = function () { var r = o.apply(this, arguments); fn.call(this, r, arguments); return r; }; }
    wrap('place', function (r, a) { if (r) dev.write('postavena ' + a[0] + ' [' + a[1] + ',' + a[2] + ']'); });
    wrap('sell', function (r, a) { dev.write('prodána ' + (a[0] && a[0].type)); });
    wrap('upgrade', function (r, a) { if (r) dev.write('vylepšena ' + (a[0] && a[0].type) + (typeof a[1] === 'string' ? ' → ' + a[1] : '')); });
    wrap('merge', function (r) { if (r) dev.write('sloučeno → ' + r.type + ' tier ' + r.tier); });
    wrap('launchWave', function (r) { if (r) dev.write('vyslána vlna ' + g.wave); });
    wrap('callWaves', function (r, a) { if (r) dev.write('přivoláno ' + a[0] + ' vln'); });
    wrap('emit', function (_, a) { if (a[0] !== 'spawn') dev.write('událost ' + a[0] + (a[1] !== undefined ? ' (' + a[1] + ')' : '')); });
  };
  dev.detach = function (g) { if (dev.game === g) dev.game = null; };

  /* příkazy */
  dev.command = function (name, help, run, alias) { cmds[name] = { name: name, help: help, run: run, alias: !!alias }; if (!alias) order.push(name); };
  dev.commands = function () { return order.map(function (n) { return cmds[n]; }); };
  dev.names = function () { return Object.keys(cmds); };
  dev.run = function (line, out) {
    var parts = String(line).trim().split(/\s+/).filter(Boolean); if (!parts.length) return;
    var name = parts[0].toLowerCase(), c = cmds[name];
    if (!c) { out('Neznámý příkaz „' + parts[0] + '“. Napiš help.', 'err'); return; }
    try { c.run(parts.slice(1), out); } catch (e) { out('Chyba příkazu: ' + e.message, 'err'); }
  };

  function flag(args, cur) { var a = (args[0] || '').toLowerCase(); return a === 'on' || a === '1' || a === 'ano' ? true : a === 'off' || a === '0' || a === 'ne' ? false : !cur; }
  function onOff(v) { return v ? 'ZAPNUTO' : 'vypnuto'; }

  dev.command('help', 'seznam příkazů', function (a, out) {
    out('Příkazy (klávesy: ↑↓ historie, Tab doplní, Esc nebo ` zavře):');
    dev.commands().forEach(function (c) { out('  ' + (c.name + '          ').slice(0, 11) + c.help); });
  });
  dev.command('clear', 'smaže obrazovku terminálu', function (a, out) { out('\f'); });
  dev.command('close', 'zavře terminál', function () { dev.open = false; });
  dev.command('exit', 'zavře terminál', function () { dev.open = false; }, true);
  dev.command('version', 'verze hry', function (a, out) { out('BubbleDefence ' + BD.VERSION); });
  dev.command('status', 'stav příznaků a hry', function (a, out) {
    out('godmod ' + onOff(dev.god) + ' · alllevels ' + onOff(dev.allLevels) + ' · livelog ' + onOff(dev.liveLog) + ' · studio ' + onOff(dev.studio)); out(dev.snapshot());
  });
  dev.command('godmod', 'nekonečné životy a zlato  [on|off]', function (a, out) {
    dev.god = flag(a, dev.god); out('GodMod ' + onOff(dev.god) + (dev.game ? '' : ' (projeví se ve hře)'));
  });
  dev.command('livelog', 'živý výpis dění ve hře  [on|off]', function (a, out) {
    dev.liveLog = flag(a, dev.liveLog); if (dev.liveLog) dev.write('LiveLog zapnut · ' + dev.snapshot()); out('LiveLog ' + onOff(dev.liveLog));
  });
  dev.command('alllevels', 'odemkne všechny levely ve story módu  [on|off]', function (a, out) {
    dev.allLevels = flag(a, dev.allLevels); out('Všechny levely ' + (dev.allLevels ? 'odemčeny (postup se nemění, po obnovení stránky se vrátí)' : 'zase podle postupu'));
  });
  dev.command('studio', 'Studio: úpravy vzhledu, vlastností a vln nepřátel a věží  [on|off]', function (a, out) {
    var m = (a[0] || '').toLowerCase(), on = m === 'off' || m === '0' || m === 'ne' ? false : m === 'on' || m === '1' || m === 'ano' ? true : !dev.studio;
    dev.studio = on; save(); BD.studio.enable(on);
    out(on ? 'Studio zapnuto: najdeš ho v menu mezi Story, Editor a Free. Úpravy se hned projeví ve hře.' : 'Studio vypnuto, hra používá původní data (tvoje úpravy zůstávají uložené).');
  });
  dev.command('gold', 'gold <číslo> – nastaví zlato ve hře', function (a, out) {
    var n = parseInt(a[0], 10); if (!dev.game) return out('Nejsi ve hře.', 'err'); if (!(n >= 0)) return out('Použití: gold 500', 'err');
    dev.game.gold = n; out('Zlato: ' + n);
  });
  dev.command('lives', 'lives <číslo> – nastaví životy ve hře', function (a, out) {
    var n = parseInt(a[0], 10); if (!dev.game) return out('Nejsi ve hře.', 'err'); if (!(n > 0)) return out('Použití: lives 20', 'err');
    dev.game.lives = n; out('Životy: ' + n);
  });
  dev.command('bestiary', 'bestiary all|reset – odkryje celý bestiář / smaže odkrytí', function (a, out) {
    var m = (a[0] || '').toLowerCase();
    if (m === 'all') { BD.bestiary.revealAll(); out('Bestiář odkryt celý.'); } else if (m === 'reset') { BD.bestiary.reset(); out('Bestiář vymazán.'); } else out('Použití: bestiary all | bestiary reset', 'err');
  });
  dev.command('card', 'card <id> – dá kartu (atomic, meteor)', function (a, out) {
    if (!dev.game) return out('Nejsi ve hře.', 'err');
    if (!dev.game.giveCard((a[0] || '').toLowerCase())) return out('Neznámá karta. Dostupné: ' + BD.data.cards.order.join(', '), 'err');
    out('Karta ' + a[0] + ' přidána.');
  });
  dev.command('lock', 'terminál zamkne zpátky (odemkneš ho slovem terminal)', function (a, out) { dev.lock(); });

  BD.keys.sequence('terminal', function () { dev.unlock(); });
})(window.BD);
