window.WorkspaceErrors=(()=>{
  const KEY='mwCoreErrorsV1',LIMIT=40;
  function safe(value){if(value==null)return'';if(typeof value==='string')return value.slice(0,500);try{return JSON.stringify(value).slice(0,1000)}catch{return String(value).slice(0,500)}}
  function load(){try{const rows=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(rows)?rows:[]}catch{return[]}}
  function report(module,error,context={}){const entry={at:new Date().toISOString(),module:String(module||'unknown'),message:safe(error?.message||error||'Unknown error'),context:safe(context)};try{localStorage.setItem(KEY,JSON.stringify([...load(),entry].slice(-LIMIT)))}catch{};console.error(`[${entry.module}]`,error,context);try{window.dispatchEvent(new CustomEvent('workspace:error',{detail:entry}))}catch{};return entry}
  function recent(){return load()}
  function clear(){try{localStorage.removeItem(KEY)}catch{}}
  window.addEventListener('error',event=>report('window',event.error||event.message,{source:event.filename,line:event.lineno,column:event.colno}));
  window.addEventListener('unhandledrejection',event=>report('promise',event.reason||'Unhandled promise rejection'));
  return{report,recent,clear};
})();
