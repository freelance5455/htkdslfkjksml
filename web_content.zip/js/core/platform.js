window.WorkspacePlatform=(()=>{
  let state={platform:'unknown',storage:'unknown',ready:false};
  async function init(){try{const response=await fetch('/api/health',{cache:'no-store'});if(!response.ok)throw new Error(`Health check returned ${response.status}`);const data=await response.json();state={...state,...data,platform:data.platform||'windows',ready:true}}catch(error){state={...state,ready:true,error:String(error?.message||error)};window.WorkspaceErrors?.report('platform',error)}try{window.dispatchEvent(new CustomEvent('workspace:platform',{detail:{...state}}))}catch{}return state}
  function current(){return{...state}}
  function is(name){return state.platform===name}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
  return{init,current,is,isWindows:()=>is('windows'),isLinux:()=>is('linux'),isAndroid:()=>is('android')};
})();
