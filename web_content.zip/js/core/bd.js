/* BubbleDefence – jmenný prostor a drobné pomocné funkce
   Každý soubor se připojí do jednoho objektu BD (bez ES modulů, aby šlo hru
   otevřít přímo ze souboru bez serveru).
   Copyright (c) 2026 vancode.io – MIT License */
window.BD = window.BD || {};
(function (BD) {
  'use strict';
  BD.VERSION = '0.21.0';
  BD.SUB = 2;                 // jemná mřížka: 1 věž (1×1) = SUB×SUB buněk; hra počítá v buňkách, level a ceny věží v „věžových“ jednotkách
  BD.systems = {};            // herní logika (bez DOMu)
  BD.data = { towers: {} };             // data: levely, story mapa, tutoriál
  BD.render = {};             // kreslení na canvas
  BD.ui = { components: {} }; // Vue komponenty
  BD.util = {
    clamp: function (v, a, b) { return Math.max(a, Math.min(b, v)); },
    sleep: function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); },
    clone: function (o) { return JSON.parse(JSON.stringify(o)); },
    fmt: function (n) { return n >= 100 ? String(Math.round(n)) : (Math.round(n * 10) / 10).toString(); },
    uid: function () { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); },
    date: function (ts) { try { return new Date(ts).toLocaleString('cs-CZ'); } catch (e) { return ''; } },
  };
})(window.BD);
