// Diagnóstico: registro de avisos y errores desde que arranca la app, e informe de texto para copiar o descargar.
// El informe no incluye nada personal: ni nombres de archivos ni contenido de los modelos, solo cifras del dispositivo,
// los ajustes y el estado del mundo.
import { APP } from '../config.js';
import { PRO_DEFAULTS, pro } from './pro.js';

const MAX = 300;
const entries = [];
let t0 = 0;
let installed = false;

const fmt = (a) => {
  if (a instanceof Error) return `${a.name}: ${a.message}`;
  if (typeof a === 'string') return a;
  try {
    return JSON.stringify(a)?.slice(0, 300) ?? String(a);
  } catch {
    return String(a);
  }
};

export function diagNote(level, message) {
  entries.push({ t: Math.round((performance.now() - t0) / 100) / 10, level, message: String(message).slice(0, 400) });
  if (entries.length > MAX) entries.shift();
}

// Engancha console.warn / console.error y los errores globales. Se llama una vez al arrancar.
export function installDiag() {
  if (installed || typeof window === 'undefined') return;
  installed = true;
  t0 = performance.now();
  for (const level of ['warn', 'error']) {
    const orig = console[level].bind(console);
    console[level] = (...args) => {
      diagNote(level, args.map(fmt).join(' '));
      orig(...args);
    };
  }
  window.addEventListener('error', (e) => diagNote('error', `${e.message} (${String(e.filename || '').split('/').pop()}:${e.lineno})`));
  window.addEventListener('unhandledrejection', (e) => diagNote('error', `promesa rechazada: ${fmt(e.reason)}`));
}

export const diagEntries = () => entries.slice();

// Datos de WebGL: se leen del contexto del mundo si está abierto o de uno temporal.
export function glInfo(gl0 = null) {
  let gl = gl0;
  let temp = null;
  try {
    if (!gl) {
      temp = document.createElement('canvas');
      gl = temp.getContext('webgl2');
    }
    if (!gl) return { ok: false };
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const info = {
      ok: true,
      version: gl.getParameter(gl.VERSION),
      renderer: dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER),
      vendor: dbg ? gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR),
      maxTexture: gl.getParameter(gl.MAX_TEXTURE_SIZE),
      maxSamples: gl.getParameter(gl.MAX_SAMPLES),
      maxTextureUnits: gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS),
      maxVaryings: gl.getParameter(gl.MAX_VARYING_VECTORS),
      maxAniso: gl.getExtension('EXT_texture_filter_anisotropic') ? gl.getParameter(gl.getExtension('EXT_texture_filter_anisotropic').MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 1,
      floatRT: !!(gl.getExtension('EXT_color_buffer_float') || gl.getExtension('EXT_color_buffer_half_float')),
      depthTexture: true,
    };
    return info;
  } catch (err) {
    return { ok: false, error: fmt(err) };
  } finally {
    if (temp && gl) gl.getExtension('WEBGL_lose_context')?.loseContext();
  }
}

// Memoria de vídeo aproximada de lo que hay en la escena: texturas (con mipmaps) y buffers de geometría. Es una estimación.
export function estimateVram(scene) {
  const seenT = new Set();
  const seenG = new Set();
  let tex = 0;
  let geo = 0;
  let ntex = 0;
  const addTex = (t) => {
    if (!t || !t.isTexture || seenT.has(t.uuid)) return;
    seenT.add(t.uuid);
    const img = t.image;
    const w = img?.width || t.source?.data?.width || 0;
    const h = img?.height || t.source?.data?.height || 0;
    if (!w || !h) return;
    const bpp = t.type === 1016 || t.type === 1015 ? 8 : 4; // media precisión / flotante ≈ 8 o más bytes
    tex += w * h * bpp * (t.generateMipmaps || t.minFilter >= 1004 ? 1.333 : 1) * (t.isCubeTexture ? 6 : 1);
    ntex++;
  };
  scene.traverse((o) => {
    const g = o.geometry;
    if (g && !seenG.has(g.uuid)) {
      seenG.add(g.uuid);
      for (const a of Object.values(g.attributes || {})) geo += a.array?.byteLength || 0;
      geo += g.index?.array?.byteLength || 0;
    }
    for (const m of Array.isArray(o.material) ? o.material : o.material ? [o.material] : []) {
      for (const v of Object.values(m)) if (v && v.isTexture) addTex(v);
      for (const u of Object.values(m.uniforms || {})) if (u?.value?.isTexture) addTex(u.value);
    }
  });
  return { texMB: tex / 1048576, geoMB: geo / 1048576, textures: ntex, geometries: seenG.size };
}

const mb = (v) => `${v.toFixed(1)} MB`;
const row = (k, v) => `  ${k.padEnd(24)} ${v}`;

// world: lo que devuelve window.rigworld.world.report() (o null si no hay mundo abierto).
export function buildReport({ profile = null, world = null, worldCfg = null } = {}) {
  const L = [];
  const nav = navigator;
  L.push(`RigWorld 3D · informe de diagnóstico`);
  L.push(`Versión ${APP.version} · ${new Date().toISOString()}`);
  L.push('');
  L.push('── Dispositivo');
  L.push(row('Navegador', nav.userAgent));
  L.push(row('Idioma', nav.language));
  L.push(row('Pantalla', `${screen.width}×${screen.height} · ventana ${innerWidth}×${innerHeight} · dpr ${window.devicePixelRatio}`));
  L.push(row('Núcleos / RAM', `${nav.hardwareConcurrency ?? '?'} / ${nav.deviceMemory ?? '?'} GB`));
  L.push(row('Red', nav.connection ? `${nav.connection.effectiveType || '?'}${nav.onLine === false ? ' (sin conexión)' : ''}` : nav.onLine === false ? 'sin conexión' : 'en línea'));
  L.push(row('Modo de pantalla', matchMedia('(display-mode: standalone)').matches ? 'aplicación instalada' : matchMedia('(display-mode: fullscreen)').matches ? 'pantalla completa' : 'navegador'));
  if (profile) L.push(row('Gama detectada', `${profile.tier} · tope ${profile.maxFps} fps · WebGL ${profile.webgl?.ok ? profile.webgl.version : 'no'}`));
  const gl = glInfo(world?.gl || null);
  L.push('');
  L.push('── WebGL');
  if (!gl.ok) L.push(row('Estado', `no disponible ${gl.error || ''}`));
  else {
    L.push(row('Versión', gl.version));
    L.push(row('GPU', `${gl.renderer} (${gl.vendor})`));
    L.push(row('Textura máxima', `${gl.maxTexture} px`));
    L.push(row('MSAA máximo', `${gl.maxSamples}×`));
    L.push(row('Anisotrópico máx.', `${gl.maxAniso}×`));
    L.push(row('Buffers de media precisión', gl.floatRT ? 'sí (efectos de imagen disponibles)' : 'no (los efectos de imagen se desactivan)'));
  }

  const p = pro.all();
  const diff = Object.entries(p).filter(([k, v]) => v !== PRO_DEFAULTS[k]);
  L.push('');
  L.push('── Ajustes avanzados (solo los que difieren de los de fábrica)');
  L.push(row('Tipo de calidad', p.mode === 'b' ? `B · EDEN nivel ${p.level}` : 'A · RigWorld'));
  if (!diff.length) L.push('  (todos de fábrica)');
  for (const [k, v] of diff) if (k !== 'mode') L.push(row(k, String(v)));
  if (worldCfg) L.push(row('Mundo (ajustes)', JSON.stringify(worldCfg).slice(0, 380)));

  L.push('');
  L.push('── Mundo');
  if (!world) L.push('  (no hay un mundo abierto; abre el informe desde dentro del mundo para ver fotogramas y memoria)');
  else {
    L.push(row('Mundo', world.worldId));
    L.push(row('Fotogramas', `${world.fps} fps · mediana ${world.p50} ms · p95 ${world.p95} ms · máx ${world.max} ms`));
    L.push(row('Calidad vigente', `${world.quality.label} · escala ${world.scale} · nivel efectivo ${world.level || '—'}${world.capped ? ' (reducido)' : ''}`));
    L.push(row('Reducciones', `térmica −${world.thermalDrop} · batería −${world.batteryDrop}`));
    L.push(row('Dibujo', `${world.info.calls} llamadas · ${world.info.triangles} triángulos`));
    L.push(row('Memoria de vídeo (aprox.)', `texturas ${mb(world.vram.texMB)} (${world.vram.textures}) · geometría ${mb(world.vram.geoMB)} (${world.vram.geometries})`));
    L.push(row('Programas de sombreado', String(world.info.programs)));
    L.push(row('Efectos de imagen', world.post));
    L.push(row('Sombreadores fallidos', String(world.failedPatches)));
    L.push(row('Posición / hora', `${world.pos.map((n) => Math.round(n)).join(', ')} · ${world.hours}`));
    if (world.extra) L.push(row('Detalles', world.extra));
  }

  L.push('');
  L.push(`── Registro de avisos y errores (${Math.min(entries.length, 60)} de ${entries.length})`);
  if (!entries.length) L.push('  (sin avisos ni errores)');
  for (const e of entries.slice(-60)) L.push(`  [${String(e.t).padStart(7)} s] ${e.level === 'error' ? 'ERROR' : 'aviso '} ${e.message}`);
  return L.join('\n');
}

// Copia al portapapeles; si no se puede (algunos WebView), devuelve false para que la pantalla ofrezca descargarlo.
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
      document.body.append(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

export function downloadText(text, name = 'rigworld-informe.txt') {
  const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
