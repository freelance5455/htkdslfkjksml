/* Keys – sekvence kláves (kódy jako „terminal“), globálně pro celou hru.
   - píše se po sobě, mezi klávesami smí být nejvýše KEY_TIMEOUT ms, jinak se záznam smaže
   - písmena a číslice se berou podle fyzické klávesy (ev.code), takže to funguje i na české klávesnici
   - rozepsaný kód (aspoň 2 znaky) označí událost jako ev.bdSeq, aby ji herní zkratky (T, S, M …) nebraly jako povel
   - při psaní do políčka, s Ctrl/Alt/Cmd a při držení klávesy se nic nezaznamenává
   Použití: BD.keys.sequence('terminal', function () { … });
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var KEY_TIMEOUT = 1500, MAXLEN = 32;
  var seqs = [], buf = '', last = 0;
  var MODS = { shift: 1, capslock: 1, control: 1, alt: 1, meta: 1, altgraph: 1, os: 1 };

  function charOf(ev) {
    var m = /^(?:Key([A-Z])|Digit([0-9])|Numpad([0-9]))$/.exec(ev.code || '');
    if (m) return (m[1] || m[2] || m[3]).toLowerCase();
    return ev.key && ev.key.length === 1 ? ev.key.toLowerCase() : '';
  }
  function isPrefix(s) {                                     // některá přípona záznamu (od 2 znaků) je začátkem kódu, ale ještě ne celý kód
    for (var i = 0; i <= s.length - 2; i++) {
      var suf = s.slice(i);
      for (var j = 0; j < seqs.length; j++) if (seqs[j].code.length > suf.length && seqs[j].code.indexOf(suf) === 0) return true;
    }
    return false;
  }

  function onKey(ev) {
    var tg = ev.target && ev.target.tagName;
    if (tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT') { buf = ''; return; }
    if (ev.ctrlKey || ev.metaKey || ev.altKey || ev.repeat) return;
    var k = String(ev.key || '').toLowerCase();
    if (MODS[k]) return;
    var c = charOf(ev);
    if (!c) { buf = ''; return; }
    var now = Date.now(); if (now - last > KEY_TIMEOUT) buf = '';
    last = now; buf = (buf + c).slice(-MAXLEN);
    for (var i = 0; i < seqs.length; i++) {
      var q = seqs[i];
      if (buf.length >= q.code.length && buf.slice(-q.code.length) === q.code && (!q.when || q.when())) {
        buf = ''; ev.bdSeq = true; q.fn(); return;
      }
    }
    if (isPrefix(buf)) ev.bdSeq = true;
  }
  window.addEventListener('keydown', onKey, true);          // zachytávací fáze: poběží dřív než zkratky ve hře

  BD.keys = {
    sequence: function (code, fn, when) { seqs.push({ code: String(code).toLowerCase(), fn: fn, when: when || null }); },
    reset: function () { buf = ''; },
    buffer: function () { return buf; },
  };
})(window.BD);
