window.WorkspaceGameDataRegistry=(()=>{
  const providers=new Map();
  const keyOf=value=>String(value||'').trim().toLowerCase();
  const cleanCategory=(category,index)=>({
    key:keyOf(category?.key||`category-${index+1}`),
    title:String(category?.title||category?.key||`Category ${index+1}`),
    eyebrow:String(category?.eyebrow||'GAME KNOWLEDGE'),
    description:String(category?.description||''),
    status:String(category?.status||'available'),
    count:typeof category?.count==='function'?category.count:(()=>category?.count??null),
    adapter:String(category?.adapter||''),
    dataUrl:String(category?.dataUrl||''),
    metadata:category?.metadata&&typeof category.metadata==='object'?{...category.metadata}:{}
  });
  function register(gameKey,provider={}){
    const key=keyOf(gameKey);if(!key)throw new Error('Game data provider requires a game key');
    const id=String(provider.id||'').trim();if(!id)throw new Error(`Game data provider for ${key} requires an id`);
    const normalized={
      gameKey:key,
      id,
      kind:String(provider.kind||'unknown'),
      label:String(provider.label||id),
      version:String(provider.version||'unversioned'),
      state:String(provider.state||'available'),
      note:String(provider.note||''),
      source:String(provider.source||''),
      manifest:provider.manifest&&typeof provider.manifest==='object'?{...provider.manifest}:null,
      capabilities:Array.isArray(provider.capabilities)?provider.capabilities.map(value=>String(value)):[],
      categories:(Array.isArray(provider.categories)?provider.categories:[]).map(cleanCategory)
    };
    providers.set(key,normalized);return normalized;
  }
  function unregister(gameKey){return providers.delete(keyOf(gameKey))}
  function get(gameKey){return providers.get(keyOf(gameKey))||null}
  function categories(gameKey){return get(gameKey)?.categories||[]}
  function describe(gameKey){
    const provider=get(gameKey);
    if(provider)return{installed:true,...provider,categoryCount:provider.categories.length};
    return{installed:false,gameKey:keyOf(gameKey),id:'',kind:'none',label:'No shared game data installed',version:'—',state:'not_installed',note:'The Workspace UI is available, but no public/shared data provider is registered for this game.',source:'',manifest:null,capabilities:[],categories:[],categoryCount:0};
  }
  return{register,unregister,get,categories,describe};
})();
