window.WorkspaceIcons=(()=>{
  const fallback={menu:'☰',search:'⌕',add:'＋',home:'⌂',library:'▦',archive:'▣',profiles:'♙','load-order':'☷',notes:'□',favorite:'☆'};let icons={...fallback};
  function apply(root=document){root.querySelectorAll('[data-ui-icon]').forEach(node=>{const value=icons[node.dataset.uiIcon];if(value)node.textContent=value})}
  async function load(){try{const response=await fetch('/ui-icons.json',{cache:'no-store'});if(response.ok){const data=await response.json();if(data?.icons)icons={...icons,...data.icons}}}catch(error){window.WorkspaceErrors?.report('icons',error)}apply();return icons}
  function get(name){return icons[name]||''}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load,{once:true});else load();
  return{load,apply,get,all:()=>({...icons})};
})();
