/* Store – postup, uložené hry, uložené levely editoru a nastavení.
   Ukládá do localStorage (jen v tomto prohlížeči); export/import přes JSON soubor.
   Načítá se až po Vue (používá reactive).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var KEY = 'bd.profile.v2';
  var clamp = BD.util.clamp;

  var DEFAULT_SETTINGS = {
    master: 70, music: 50, sfx: 80,            // zvuk (zatím jen uloženo, zvuky přibudou)
    gameSpeed: 1,                              // výchozí rychlost hry 1–3
    shake: 1,                                  // třesení obrazovky 0 vypnuto, 1 jemné, 2 silné
    showRange: true, showPath: false, showPathLen: false, showGrid: true,     // trasa bublin a délka cesty jsou ve výchozím stavu skryté
    ui5: true,                                 // značka verze nastavení (0.6: trasa a délka cesty se jednorázově vypnou)
    hints: true,                               // nápovědy v tutoriálu
    menuAnimation: true,                       // animace pozadí v menu
    lang: 'cs',
  };

  function defaults() {
    return {
      v: 2, created: Date.now(),
      story: { completed: [], save: null, cards: [] },    // save = { nodeId, snapshot, savedAt }; cards = karty, které si hráč nese do dalšího levelu
      free: { save: null, best: 0 },           // save = { level, title, snapshot, savedAt }
      editor: { levels: [] },                  // { id, name, w, h, spawns, exit, rocks, updated }
      studio: { items: { enemies: {}, towers: {}, templates: {}, ammo: {} } },   // úpravy nepřátel a věží ze Studia (vývojářské)
      bestiary: { seen: {}, read: {}, merged: {} },   // odkrytí v bestiáři: 'druh:id' → 1 viděno, 2 poznáno
      settings: BD.util.clone(DEFAULT_SETTINGS),
    };
  }

  function readRaw() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function writeRaw(s) { try { localStorage.setItem(KEY, s); return true; } catch (e) { return false; } }

  /* ---------- čištění dat (z uložiště i z importu) ---------- */
  function num(v, a, b, d) { return typeof v === 'number' && isFinite(v) ? clamp(v, a, b) : d; }
  function bool(v, d) { return typeof v === 'boolean' ? v : d; }
  function snapOk(s) { return !!s && typeof s === 'object' && Array.isArray(s.towers) && s.v !== 1; }   // v1 = stará hrubá mřížka

  /* partial: rozdělaný level z editoru může být zatím neprůchodný – nesmí se při načtení zahodit */
  function cleanLevel(l, partial) {
    if (!l || typeof l !== 'object') return null;
    l = BD.systems.levels.normalize(l);        // starý formát (v1) se převede na bránu + jemnou mřížku
    var o = { name: String(l.name || 'Level').slice(0, 40), w: l.w, h: l.h, spawns: l.spawns, exit: l.exit, rocks: l.rocks, walls: l.walls };
    var LM = BD.systems.levels.LIMITS;
    ['waves', 'lives', 'gold', 'gap'].forEach(function (f) { if (Number.isInteger(l[f]) && l[f] >= LM[f][0] && l[f] <= LM[f][1]) o[f] = l[f]; });
    if (typeof l.hp === 'number' && isFinite(l.hp) && l.hp >= LM.hp[0] && l.hp <= LM.hp[1]) o.hp = l.hp;
    if (Array.isArray(l.allowed)) o.allowed = l.allowed.filter(function (a) { return typeof a === 'string' && a.length < 20; }).slice(0, 12);
    if (Array.isArray(l.towers)) o.towers = l.towers.filter(function (t) { return t && typeof t.type === 'string' && Number.isInteger(t.x) && Number.isInteger(t.y); })
      .slice(0, 300).map(function (t) { return { type: t.type, x: t.x, y: t.y }; });
    return (partial ? BD.systems.levels.validateShape(o) : BD.systems.levels.validate(o)).ok ? o : null;
  }

  function sanitize(src) {
    var d = defaults();
    if (!src || typeof src !== 'object') return d;
    d.created = num(src.created, 0, 4e12, d.created);

    if (src.story && typeof src.story === 'object') {
      if (Array.isArray(src.story.completed)) {
        var seen = {};
        d.story.completed = src.story.completed.filter(function (x) { if (typeof x !== 'string' || seen[x]) return false; seen[x] = 1; return true; });
      }
      if (Array.isArray(src.story.cards)) d.story.cards = src.story.cards.filter(function (c) { return typeof c === 'string' && c.length < 20 && BD.data.cards.list[c]; }).slice(0, 100);
      var ss = src.story.save;
      if (ss && typeof ss.nodeId === 'string' && snapOk(ss.snapshot))
        d.story.save = { nodeId: ss.nodeId, snapshot: ss.snapshot, savedAt: num(ss.savedAt, 0, 4e12, Date.now()) };
    }
    if (src.free && typeof src.free === 'object') {
      d.free.best = num(src.free.best, 0, 1e6, 0) | 0;
      var fs = src.free.save, lv = fs && cleanLevel(fs.level);
      if (fs && lv && snapOk(fs.snapshot))
        d.free.save = { level: lv, title: String(fs.title || lv.name).slice(0, 60), snapshot: fs.snapshot, savedAt: num(fs.savedAt, 0, 4e12, Date.now()) };
    }
    if (src.editor && Array.isArray(src.editor.levels)) {
      src.editor.levels.slice(0, 200).forEach(function (l) {
        var c = cleanLevel(l, true); if (!c) return;
        c.id = typeof l.id === 'string' && l.id ? l.id.slice(0, 40) : BD.util.uid();
        c.updated = num(l.updated, 0, 4e12, Date.now());
        d.editor.levels.push(c);
      });
    }
    if (src.bestiary && typeof src.bestiary === 'object') {
      ['seen', 'read'].forEach(function (f) {
        var m = src.bestiary[f]; if (!m || typeof m !== 'object') return;
        Object.keys(m).slice(0, 200).forEach(function (k) { var n = m[k]; if (/^[a-z]{3,10}:[A-Za-z0-9_-]{1,30}$/.test(k) && (n === 1 || n === 2)) d.bestiary[f][k] = n; });
      });
      var mg = src.bestiary.merged;
      if (mg && typeof mg === 'object') Object.keys(mg).slice(0, 50).forEach(function (k) { if (/^[A-Za-z0-9_-]{1,30}$/.test(k) && (mg[k] === 1 || mg[k] === 2)) d.bestiary.merged[k] = mg[k]; });
    }
    if (src.studio && BD.studio) d.studio = BD.studio.sanitize(src.studio);
    if (src.settings && typeof src.settings === 'object') {
      var s = src.settings, o = d.settings;
      o.master = num(s.master, 0, 100, o.master); o.music = num(s.music, 0, 100, o.music); o.sfx = num(s.sfx, 0, 100, o.sfx);
      o.gameSpeed = Math.round(num(s.gameSpeed, 1, 3, 1)); o.shake = Math.round(num(s.shake, 0, 2, 1));
      o.showRange = bool(s.showRange, true); o.showPath = s.ui5 ? bool(s.showPath, false) : false; o.showPathLen = bool(s.showPathLen, false); o.ui5 = true; o.showGrid = bool(s.showGrid, true);
      o.hints = bool(s.hints, true); o.menuAnimation = bool(s.menuAnimation, true);
    }
    return d;
  }

  /* ---------- store ---------- */
  var store = { profile: null, existed: false };
  var timer = 0;

  store.init = function () {
    var raw = readRaw(), parsed = null;
    store.existed = false;
    if (raw) { try { parsed = JSON.parse(raw); store.existed = true; } catch (e) { parsed = null; } }
    store.profile = Vue.reactive(sanitize(parsed));
    Vue.watch(store.profile, function () { clearTimeout(timer); timer = setTimeout(store.flush, 300); }, { deep: true });
    window.addEventListener('beforeunload', store.flush);
    window.addEventListener('pagehide', store.flush);
  };

  store.flush = function () { clearTimeout(timer); return writeRaw(JSON.stringify(store.profile)); };
  store.hasSaved = function () { return !!readRaw(); };

  function replace(p) { Object.keys(p).forEach(function (k) { store.profile[k] = p[k]; }); }

  store.newProfile = function () { replace(defaults()); store.existed = true; store.flush(); };
  store.resetStory = function () { store.profile.story = { completed: [], save: null, cards: [] }; };
  store.completeNode = function (id) {
    var c = store.profile.story.completed;
    if (c.indexOf(id) < 0) c.push(id);
    var sv = store.profile.story.save;
    if (sv && sv.nodeId === id) store.profile.story.save = null;
  };

  store.addEditorLevel = function () {
    var n = store.profile.editor.levels.length + 1;
    var L = BD.systems.levels.blank('Nový level ' + n);
    L.id = BD.util.uid(); L.updated = Date.now();
    store.profile.editor.levels.push(L);
    return L;
  };
  store.removeEditorLevel = function (id) {
    store.profile.editor.levels = store.profile.editor.levels.filter(function (l) { return l.id !== id; });
  };

  /* export / import levelů z editoru (jeden nebo víc) – malý JSON { game, type:'levels', levels:[…] } */
  store.exportLevels = function (list) {
    var levels = list.map(function (l) { var c = cleanLevel(l, true); return c; }).filter(Boolean);
    return JSON.stringify({ game: 'BubbleDefence', type: 'levels', v: 1, levels: levels });
  };
  store.importLevels = function (text) {
    var o;
    try { o = JSON.parse(String(text).trim()); } catch (e) { return { ok: false, error: 'Text se nepodařilo přečíst (není to platný JSON).' }; }
    if (o && o.game === 'BubbleDefence' && o.type === 'level' && o.level) o = { levels: [o.level] };
    if (!o || o.game !== 'BubbleDefence' && !Array.isArray(o.levels) || !Array.isArray(o.levels)) return { ok: false, error: 'Tohle není level z BubbleDefence.' };
    var ids = [];
    o.levels.slice(0, 50).forEach(function (l) {
      var c = cleanLevel(l, true); if (!c) return;
      if (store.profile.editor.levels.length >= 200) return;
      c.id = BD.util.uid(); c.updated = Date.now();
      store.profile.editor.levels.push(c); ids.push(c.id);
    });
    if (!ids.length) return { ok: false, error: 'V textu není žádný použitelný level.' };
    store.flush();
    return { ok: true, count: ids.length, ids: ids };
  };

  store.exportJSON = function () {
    var o = { game: 'BubbleDefence', format: 2, exported: new Date().toISOString(), profile: BD.util.clone(store.profile) };
    if (BD.dev) o.dev = { unlocked: !!BD.dev.unlocked, studio: !!BD.dev.studio };            // vývojářský režim (terminál, Studio) – aby šlo po importu pokračovat v práci
    return JSON.stringify(o, null, 2);
  };
  store.importJSON = function (text) {
    var o;
    try { o = JSON.parse(text); } catch (e) { return { ok: false, error: 'Soubor se nepodařilo přečíst (není to platný JSON).' }; }
    if (!o || o.game !== 'BubbleDefence' || !o.profile) return { ok: false, error: 'Tohle není postup z BubbleDefence.' };
    replace(sanitize(o.profile));
    if (BD.dev && BD.dev.restore) BD.dev.restore(o.dev);                                      // zapne / vypne terminál a Studio podle exportu
    if (BD.studio) BD.studio.apply();                                                          // úpravy ze Studia se hned projeví ve hře
    store.existed = true; store.flush();
    return { ok: true };
  };

  BD.store = store;
  BD.storeInternals = { sanitize: sanitize, defaults: defaults, KEY: KEY };
})(window.BD);
