// ---- Persistent storage (localStorage — works fully offline in any browser,
// including when this HTML file is saved/reopened directly, not just inside Claude) ----
const LS_KEY = 'epi_tracker_children_v1';

function loadStore(){
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch(e) { return {}; }
}
function saveStore(obj){
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(obj));
    updateStorageNote();
    return true;
  } catch(e) {
    console.error('save failed', e);
    // Never fail silently: a full storage quota used to lose records with no warning.
    statusEl.innerHTML = '<span class="err">⚠ Data could NOT be saved — browser storage is full. Delete some old saved files, then try again.</span>';
    const bs = document.getElementById('backupStatus');
    if (bs) bs.innerHTML = '<span class="err">⚠ Storage full — save failed.</span>';
    return false;
  }
}

// Shows how much of the browser's storage budget the saved data is using.
function updateStorageNote(){
  const el = document.getElementById('storageNote');
  if (!el) return;
  try {
    // Both stores share the same browser quota, so both must be measured —
    // reporting only the children store made the app look far emptier than it
    // was and gave no warning before the quota ran out.
    const raw = localStorage.getItem(LS_KEY) || '';
    const defRaw = localStorage.getItem(DEF_LS_KEY) || '';
    const bytes = new Blob([raw]).size + new Blob([defRaw]).size;
    const kb = bytes/1024;
    const size = kb < 10 ? kb.toFixed(1) + ' KB' : (kb < 1024 ? kb.toFixed(0) + ' KB' : (kb/1024).toFixed(2) + ' MB');
    const n = Object.keys(loadStore()).length;
    const dn = Object.keys(loadDefaultersStore()).length;
    if (!n && !dn) { el.textContent = 'No records saved yet.'; return; }
    const parts = [];
    if (n) parts.push(`${n} record(s)`);
    if (dn) parts.push(`${dn} defaulter(s)`);
    el.textContent = `${parts.join(' + ')} saved • about ${size} used (most browsers allow around 5 MB).`;
  } catch(e) { el.textContent = ''; }
}

// A "source" entry identifies one imported file. Older saved data stores it as
// a plain filename string; newer data stores {name, size} so that two
// different files sharing the same name (e.g. two vaccinators' same-named
// "Daily Immunization Registry" PDFs) are told apart.
function sourceEntryName(s){ return typeof s === 'string' ? s : ((s && s.name) || ''); }
function sourceEntrySize(s){ return typeof s === 'string' ? null : ((s && typeof s.size === 'number') ? s.size : null); }
function sourceEntryMatches(s, name, size){
  if (typeof s === 'string') return s === name; // legacy entries: name-only match
  return s && s.name === name && s.size === size;
}
function sourceKey(name, size){ return name + '::' + (size == null ? '' : size); }
function splitSourceKey(key){
  const idx = key.lastIndexOf('::');
  if (idx < 0) return [key, null];
  const sizePart = key.slice(idx + 2);
  return [key.slice(0, idx), sizePart === '' ? null : Number(sizePart)];
}

// ---- Defaulters List storage (separate from the children/women records above) ----
const DEF_LS_KEY = 'epi_tracker_defaulters_v1';

function loadDefaultersStore(){
  try {
    const raw = localStorage.getItem(DEF_LS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch(e) { return {}; }
}
function saveDefaultersStore(obj){
  try {
    localStorage.setItem(DEF_LS_KEY, JSON.stringify(obj));
    return true;
  } catch(e) {
    console.error('save failed', e);
    // There is no #defaultersStatus element in this page — the warning used to
    // be written into it and was therefore silently lost. Use the real status
    // line instead, the same one the children store writes to.
    statusEl.innerHTML = '<span class="err">⚠ Defaulters List could NOT be saved — browser storage is full. Delete some old saved files, then try again.</span>';
    const bs = document.getElementById('backupStatus');
    if (bs) bs.innerHTML = '<span class="err">⚠ Storage full — save failed.</span>';
    return false;
  }
}

// ---- EPI No lookup ----
// The Daily Immunization Report only prints the 14-digit QR code. The 8-digit
// EPI No is printed in the Children Defaulters Report (Identifier column), so
// it is looked up from the saved defaulters by QR code. A child who is not in
// any saved Defaulters Report simply shows "—".
function buildEpiMap(){
  const map = {};
  const def = loadDefaultersStore();
  for (const id in def) { if (def[id] && def[id].epiNo) map[id] = def[id].epiNo; }
  return map;
}

// ---- QR Code inventory (separate from the children/women & defaulters stores
// above) — a list of the 14-digit QR codes the user has in hand, each stored
// as { code, date, used } (date is optional — whatever was set on the Insert
// QR Code page when that code was added; used starts false). Whenever a
// Daily Immunization Report is processed, any code in this list that matches
// a QR code found in that report is marked used — it stays in the list (in
// the "Used" section, stamped) rather than being deleted, so nothing is lost. ----
const QR_LS_KEY = 'epi_tracker_qr_inventory_v1';
const QR_CODE_MAX_LEN = 14;

function loadQrStore(){
  try {
    const raw = localStorage.getItem(QR_LS_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    // Transparently migrate the old plain-string format (no date/used) saved
    // by earlier versions of this page.
    return arr.map(e => (typeof e === 'string') ? { code: e, date: null, used: false } : { used: false, ...e });
  } catch(e) { return []; }
}
function saveQrStore(arr){
  try {
    localStorage.setItem(QR_LS_KEY, JSON.stringify(arr));
    return true;
  } catch(e) {
    console.error('save failed', e);
    const qs = document.getElementById('qrStatus');
    if (qs) qs.innerHTML = '<span class="err">⚠ QR codes could NOT be saved — browser storage is full.</span>';
    return false;
  }
}
function updateQrTotalCount(){
  const n = loadQrStore().length;
  const el = document.getElementById('qrTotalCount');
  if (el) el.textContent = n;
  const el2 = document.getElementById('qrDeleteTotalCount');
  if (el2) el2.textContent = n;
}

// One row for the Saved QR Codes result page: the code itself and a small
// Copy button; used codes additionally get a rotated "USED" stamp.
function qrRowHtml(code, used){
  const stamp = used ? '<span class="qr-stamp">Used</span>' : '';
  return `<div class="qr-row${used ? ' qr-used-row' : ''}">
    <span class="qr-code-text">${escapeHtml(code)}${stamp}</span>
    <button type="button" class="qr-copy-btn" data-qr-copy="${escapeHtml(code)}">📋 Copy</button>
  </div>`;
}

// Shows the "next page" result after codes are added: unused codes in their
// own box and used codes (stamped) in a separate box, each code with its own
// Copy button.
function renderQrList(){
  const all = loadQrStore().slice().sort((a, b) => a.code.localeCompare(b.code));
  const unused = all.filter(e => !e.used);
  const used = all.filter(e => e.used);

  const totalEl = document.getElementById('qrListTotal');
  if (totalEl) totalEl.textContent = all.length;
  const unusedCountEl = document.getElementById('qrUnusedCount');
  if (unusedCountEl) unusedCountEl.textContent = unused.length;
  const usedCountEl = document.getElementById('qrUsedCount');
  if (usedCountEl) usedCountEl.textContent = used.length;

  const unusedListEl = document.getElementById('qrUnusedList');
  if (unusedListEl) unusedListEl.innerHTML = unused.length ? unused.map(e => qrRowHtml(e.code, false)).join('') : '<div class="note" style="margin:0;">None.</div>';
  const usedListEl = document.getElementById('qrUsedList');
  if (usedListEl) usedListEl.innerHTML = used.length ? used.map(e => qrRowHtml(e.code, true)).join('') : '<div class="note" style="margin:0;">None yet.</div>';
}

// Copy-to-clipboard for the small button next to every QR code, on either
// the Saved QR Codes result page or anywhere else a ".qr-copy-btn" appears.
// Three fallbacks are tried in order because the modern Clipboard API is
// often blocked entirely on pages opened via a "content://" link (no secure
// origin) or inside restricted in-app browsers — when both programmatic
// methods fail, a prompt() box is used as a last resort so the code is at
// least selectable/copyable by hand rather than the button just failing.
function legacyCopyToClipboard(text){
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '0';
    ta.style.left = '0';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (e) {
    return false;
  }
}

function copyQrCode(code, btn){
  const showResult = (ok) => {
    const original = btn.textContent;
    btn.textContent = ok ? '✔ Copied' : '✖ Failed';
    setTimeout(() => { if (document.body.contains(btn)) btn.textContent = original; }, 1400);
  };
  const useLegacyThenPrompt = () => {
    if (legacyCopyToClipboard(code)) { showResult(true); return; }
    // Guaranteed-to-work fallback: the code sits in a prompt box the user
    // can select and copy manually even when every automated method is
    // blocked by the browser.
    try { window.prompt('Copy this QR Code (already selected):', code); } catch (e) { /* ignore */ }
    showResult(false);
  };
  if (window.isSecureContext && navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(code).then(() => showResult(true)).catch(useLegacyThenPrompt);
  } else {
    useLegacyThenPrompt();
  }
}

document.addEventListener('click', (ev) => {
  const btn = ev.target.closest('.qr-copy-btn');
  if (!btn) return;
  copyQrCode(btn.getAttribute('data-qr-copy') || '', btn);
});

// Safety-net backup: writes the full saved QR list to a plain .txt file the
// phone can keep outside this page's own (possibly unreliable) storage.
document.getElementById('qrExportTxtBtn').addEventListener('click', () => {
  const all = loadQrStore().slice().sort((a, b) => a.code.localeCompare(b.code));
  const unused = all.filter(e => !e.used).map(e => e.code);
  const used = all.filter(e => e.used).map(e => e.code);
  const lines = [
    `QR Code Backup — ${new Date().toLocaleString()}`,
    `Total: ${all.length}  |  Unused: ${unused.length}  |  Used: ${used.length}`,
    '',
    `Unused QR Codes (${unused.length})`,
    ...unused,
    '',
    `Used QR Codes (${used.length})`,
    ...used
  ];
  NativeBridge.primeNotifications();
  downloadText(`qr-codes-backup-${new Date().toISOString().slice(0, 10)}.txt`, 'text/plain', lines.join('\n'));
  backupMsg('✔ QR code backup saved. Check your Downloads folder.');
});

// derive the list of processed files + per-file record counts from the store itself,
// keyed by name+size so same-named files with different content are kept distinct.
function deriveFileList(store){
  const counts = {};
  for (const id in store) {
    const rec = store[id];
    (rec.sources || []).forEach(s => {
      const name = sourceEntryName(s);
      const size = sourceEntrySize(s);
      const key = sourceKey(name, size);
      if (!counts[key]) counts[key] = { name, size, count: 0 };
      counts[key].count++;
    });
  }
  return counts;
}

// Same idea for the Defaulters List store. Without this, a processed
// Defaulters PDF never appeared in "Saved Files" and there was NO way at all
// to remove one — only "Clear All" could touch it.
function deriveDefaulterFileList(defStore){
  const counts = {};
  for (const id in defStore) {
    const rec = defStore[id];
    (rec.sources || []).forEach(s => {
      const name = sourceEntryName(s);
      const size = sourceEntrySize(s);
      const key = sourceKey(name, size);
      if (!counts[key]) counts[key] = { name, size, count: 0 };
      counts[key].count++;
    });
  }
  return counts;
}

function fileRowsHtml(counts, icon, kind){
  const keys = Object.keys(counts).sort((a, b) => {
    const A = counts[a], B = counts[b];
    return A.name.localeCompare(B.name) || (A.size||0) - (B.size||0);
  });
  return keys.map(key => {
    const info = counts[key];
    const sizeLabel = info.size != null ? ` • ${(info.size/1024).toFixed(1)} KB` : '';
    return `
      <div class="frow">
        <span class="fname">${icon} ${escapeHtml(info.name)} <span style="color:var(--muted);">(${info.count} records${sizeLabel})</span></span>
        <button class="rmbtn" data-key="${escapeHtml(key)}" data-kind="${kind}" title="Delete" aria-label="Delete file ${escapeHtml(info.name)} and its data">🗑</button>
      </div>`;
  }).join('');
}
