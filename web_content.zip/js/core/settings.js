window.WorkspaceSettings=(()=>{
  const PREFIX='mw.setting.';
  function key(name){return PREFIX+String(name||'')}
  function get(name,fallback=null){try{const raw=localStorage.getItem(key(name));return raw===null?fallback:JSON.parse(raw)}catch{return fallback}}
  function set(name,value){try{localStorage.setItem(key(name),JSON.stringify(value));return true}catch(error){window.WorkspaceErrors?.report('settings',error,{name});return false}}
  function remove(name){try{localStorage.removeItem(key(name));return true}catch{return false}}
  function migrateLegacy(name,legacyKey,fallback=null){try{const current=localStorage.getItem(key(name));if(current!==null)return JSON.parse(current)}catch{}try{const raw=localStorage.getItem(legacyKey);if(raw!==null){const value=JSON.parse(raw);set(name,value);return value}}catch{}return fallback}
  return{get,set,remove,migrateLegacy};
})();
