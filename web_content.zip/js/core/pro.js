// Ajustes avanzados unificados (tabla «Ajustes» con pestañas). Aquí viven: los dos tipos de calidad, los efectos de imagen,
// texturas, mundo y rendimiento. Es un módulo sin dependencias de Three.js: devuelve números y el resto de capas los aplican.
//
// Dos tipos de calidad que se pueden alternar con un botón:
//  · Tipo A «RigWorld»: Baja / Media / Alta (+ Auto con gobernador de fotogramas). Es el de siempre y el que viene por defecto.
//  · Tipo B «EDEN»: niveles 1 a 20 del otro proyecto (1-10 básicos, 11-20 con efectos). Cada nivel fija resolución, sombras,
//    distancia de visión, vegetación y efectos; el gobernador térmico y el ahorro de batería pueden bajarlo.
// Cualquier ajuste suelto («Gráficos», «Texturas»…) manda sobre el nivel; «auto» deja decidir al nivel.
import { bus } from './bus.js';
import { QUALITY } from '../world/quality.js';

const KEY = 'pro';

export const PRO_DEFAULTS = Object.freeze({
  mode: 'a', // 'a' = RigWorld · 'b' = EDEN 1-20
  level: 7, // nivel del tipo B (1-20)
  tierForce: 'auto', // gama que limita el nivel máximo del tipo B: auto | low | mid | high
  // Imagen
  pixelRatio: 'auto', // auto | 0.75 | 1 | 1.25 | 1.5 | 2
  shadows: 'auto', // auto | off | low | medium | high
  shadowMap: 'auto', // auto | 512 | 1024 | 2048 | 4096
  toneMapping: 'ACESFilmic', // ACESFilmic | AgX | Neutral | Reinhard | Linear
  aa: 'auto', // auto | off | msaa | fxaa | taa
  leaves: 'auto', // follaje con hojas recortadas: auto (niveles 13+ del tipo B) | on | off
  bloom: 'auto', bloomStrength: 0.6, // auto | on | off
  ssao: 'auto', ssaoRadius: 4,
  rays: 'auto', raysAmt: 0.5,
  sharpen: 'auto', sharpenAmt: 0.4,
  grain: false, grainAmt: 0.25,
  ca: false, caAmt: 0.6,
  grade: 'auto', lift: 0, gamma: 1, gain: 1, temp: 0, contrast: 1, sat: 1, vignette: 0,
  // Texturas
  texChar: 'auto', // auto | low | medium | high | max (máximo de la textura del personaje: 512 / 1024 / 2048 / 4096)
  texWorld: 'auto',
  aniso: 'auto', // auto | 1 | 2 | 4 | 8 | 16
  // Mundo
  dayMinutes: 'auto', // auto (usa «Paso del tiempo») | 5 | 10 | 15 | 30 | 60 | 180 | 360 | 720 | 1440
  vegetation: 'auto', // auto | none | low | medium | high
  chunkRadius: 'auto', // auto | 2..9 (trozos de 64 m en EDEN)
  // Rendimiento
  fpsTarget: 'auto', // auto | 30 | 45 | 60
  thermal: true, // baja un nivel si los fotogramas se alargan mucho
  battery: true, // baja dos niveles con batería <20 % y sin cargar
  visibilityPause: true, // suspende el mundo y el audio al ocultar la app
  warmup: true, // precompila los sombreadores al entrar al mundo
  // Audio (se usa en la pestaña Audio)
  master: 0.7, musicOn: true, music: 0.5, sfxOn: true, sfx: 0.6,
  ambient: true, // interruptor general del ambiente
  windOn: true, stepsOn: true, birdsOn: true, splashOn: true, // viento · pasos · pájaros · chapoteo
  chinese: false, chineseVol: 0.6, guzheng: true, pipa: true, harp: true,
});

const ENUMS = {
  tierForce: ['auto', 'low', 'mid', 'high'],
  pixelRatio: ['auto', '0.75', '1', '1.25', '1.5', '2'],
  shadows: ['auto', 'off', 'low', 'medium', 'high'],
  shadowMap: ['auto', '512', '1024', '2048', '4096'],
  toneMapping: ['ACESFilmic', 'AgX', 'Neutral', 'Reinhard', 'Linear'],
  aa: ['auto', 'off', 'msaa', 'fxaa', 'taa'],
  leaves: ['auto', 'on', 'off'], bloom: ['auto', 'on', 'off'], ssao: ['auto', 'on', 'off'], rays: ['auto', 'on', 'off'], sharpen: ['auto', 'on', 'off'], grade: ['auto', 'on', 'off'],
  texChar: ['auto', 'low', 'medium', 'high', 'max'], texWorld: ['auto', 'low', 'medium', 'high', 'max'],
  aniso: ['auto', '1', '2', '4', '8', '16'],
  dayMinutes: ['auto', '5', '10', '15', '30', '60', '180', '360', '720', '1440'],
  vegetation: ['auto', 'none', 'low', 'medium', 'high'],
  fpsTarget: ['auto', '30', '45', '60'],
};
const RANGES = {
  level: [1, 20, 1], bloomStrength: [0, 1.5], ssaoRadius: [1, 16], raysAmt: [0, 1.5], sharpenAmt: [0, 1.5], grainAmt: [0, 1], caAmt: [0, 2],
  lift: [-0.1, 0.1], gamma: [0.6, 1.6], gain: [0.6, 1.6], temp: [-1, 1], contrast: [0.5, 2], sat: [0, 2], vignette: [0, 1],
  master: [0, 1], music: [0, 1], sfx: [0, 1], chineseVol: [0, 1],
};
const BOOLS = ['grain', 'ca', 'thermal', 'battery', 'visibilityPause', 'warmup', 'musicOn', 'sfxOn', 'ambient', 'windOn', 'stepsOn', 'birdsOn', 'splashOn', 'chinese', 'guzheng', 'pipa', 'harp'];

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

// Lo guardado → ajustes válidos. Lo que no tenga sentido se ignora y queda el valor por defecto.
export function sanitizePro(raw) {
  const out = { ...PRO_DEFAULTS };
  if (!raw || typeof raw !== 'object') return out;
  if (raw.mode === 'a' || raw.mode === 'b') out.mode = raw.mode;
  for (const [k, list] of Object.entries(ENUMS)) if (list.includes(String(raw[k]))) out[k] = String(raw[k]);
  for (const [k, [lo, hi, step]] of Object.entries(RANGES)) {
    if (!Number.isFinite(raw[k])) continue;
    const v = clamp(raw[k], lo, hi);
    out[k] = step ? Math.round(v / step) * step : v;
  }
  for (const k of BOOLS) if (typeof raw[k] === 'boolean') out[k] = raw[k];
  const r = raw.chunkRadius;
  if (Number.isFinite(r)) out.chunkRadius = clamp(Math.round(r), 2, 9);
  return out;
}

let values = { ...PRO_DEFAULTS };
let storage = null;
let saveTimer = 0;

export const pro = {
  get: (k) => values[k],
  all: () => ({ ...values }),
  async load(store) {
    storage = store;
    values = sanitizePro(await store.getSetting(KEY, null).catch(() => null));
    return this.all();
  },
  // Cambia uno o varios ajustes, avisa a quien escucha («pro:changed») y guarda con un pequeño retraso.
  update(patch) {
    values = sanitizePro({ ...values, ...patch });
    bus.emit('pro:changed', { ...values });
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      saveTimer = 0;
      storage?.setSetting(KEY, values).catch((err) => console.warn('[ajustes] no se pudo guardar', err));
    }, 400);
    return this.all();
  },
  // Guarda ya lo que esté pendiente (al ocultar la app, para no perder el último cambio si el sistema la cierra).
  flush() {
    if (!saveTimer) return;
    clearTimeout(saveTimer);
    saveTimer = 0;
    storage?.setSetting(KEY, values).catch(() => {});
  },
  reset() {
    values = { ...PRO_DEFAULTS };
    bus.emit('pro:changed', { ...values });
    storage?.setSetting(KEY, values).catch(() => {});
    return this.all();
  },
};

// ── Tipo B: niveles 1-20 ───────────────────────────────────────────────────────────────────────────
// Los 10 primeros salen de la tabla del otro proyecto (escala de dibujo, resolución, sombras, radio de trozos, detalle); del 11 al 20
// cada nivel suma un efecto al anterior, como allí. chunk: 1 → 3 trozos de 64 m, 2 → 5, 3 → 8 (en el otro proyecto los trozos eran de otro tamaño).
const BASE = [
  // nivel, nombre, escala, pixelRatio, sombras, chunk, detalle de geometría (segments), partículas
  [1, 'Mínimo', 0.4, 0.75, 0, 1, 8, 0],
  [2, 'Muy bajo', 0.5, 0.85, 0, 1, 12, 50],
  [3, 'Bajo', 0.6, 1, 0, 1, 16, 100],
  [4, 'Medio-bajo', 0.7, 1, 0, 1, 20, 150],
  [5, 'Medio', 0.8, 1.25, 0, 1, 24, 200],
  [6, 'Medio-alto', 0.9, 1.5, 0, 2, 24, 300],
  [7, 'Alto', 1, 1.5, 0, 2, 32, 400],
  [8, 'Muy alto', 1, 1.5, 1024, 2, 32, 500],
  [9, 'Ultra', 1, 2, 1024, 2, 40, 600],
  [10, 'Máximo', 1, 2, 1024, 2, 48, 800],
];
const EXTRA = [
  [11, 'Alto+', {}],
  [12, 'Muy alto+', { shadow: 2048 }],
  [13, 'Ultra-', { bloom: 0.4 }],
  [14, 'Ultra', { reflections: 1 }],
  [15, 'Ultra+', { rays: 0.5 }],
  [16, 'Extremo-', { shadow: 2048, chunk: 3, segments: 64 }],
  [17, 'Extremo', { ssao: 4 }],
  [18, 'Extremo+', { bloom: 0.6, grade: 1 }],
  [19, 'Máximo-', { particles: 1200 }],
  [20, 'Máximo', { aa: 'taa', sharpen: 0.25, aniso: 16, shadow: 2048 }],
];

export const LEVELS_B = (() => {
  const out = BASE.map(([level, name, scale, pr, shadow, chunk, segments, particles]) => ({
    level, name, scale, pr, shadow, chunk, segments, particles, aa: 'msaa', bloom: 0, ssao: 0, rays: 0, sharpen: 0, grade: 0, reflections: 0, aniso: 0,
  }));
  let acc = { ...out[out.length - 1], aa: 'fxaa', shadow: 1024 };
  for (const [level, name, extra] of EXTRA) {
    acc = { ...acc, ...extra };
    out.push({ ...acc, level, name });
  }
  return Object.freeze(out.map((l) => Object.freeze(l)));
})();
export const levelB = (n) => LEVELS_B[clamp(Math.round(n) || 1, 1, 20) - 1];

// Nivel máximo según la gama del dispositivo (como en el otro proyecto: básica 10, media 16, alta 20).
export const tierCap = (tier) => (tier === 'low' ? 10 : tier === 'mid' ? 16 : 20);

// Nivel efectivo: el elegido menos lo que bajen el gobernador térmico y el ahorro de batería, limitado por la gama.
export function effectiveLevel(p, tier, { thermal = 0, battery = 0 } = {}) {
  const t = p.tierForce === 'auto' ? tier : p.tierForce;
  return clamp(Math.min(p.level - (p.thermal ? thermal : 0) - (p.battery ? battery : 0), tierCap(t)), 1, 20);
}

const SHADOW_SIZE = { off: 0, low: 512, medium: 1024, high: 2048 };
const DENSITY = { none: 0, low: 0.45, medium: 0.85, high: 1.1 };

// Objeto de calidad «de mundo» (misma forma que QUALITY.low/mid/high) correspondiente a un nivel del tipo B.
export function worldQualityFromLevel(L) {
  const base = L.level <= 3 ? QUALITY.low : L.level <= 7 ? QUALITY.mid : QUALITY.high;
  const radius = L.chunk === 1 ? 3 : L.chunk === 2 ? 5 : 8;
  return {
    ...base,
    id: `b${L.level}`,
    label: `EDEN ${L.level} · ${L.name}`,
    radius,
    propsFull: radius >= 5 ? 1 : 0,
    propsLow: Math.max(2, radius - 1),
    density: clamp(L.segments / 40, 0.4, 1.2),
    creatures: clamp(Math.round(L.particles / 150), 1, 8),
    shadow: L.shadow,
    shadowSpan: L.shadow >= 2048 ? 50 : 42,
    pixelRatio: L.pr,
    antialias: L.aa !== 'off' && L.level >= 3,
    detail: L.level >= 5 ? 1 : 0,
    cloudShadow: L.level >= 5 ? 1 : 0,
    grassRange: L.level <= 3 ? 46 : L.level <= 6 ? 56 : L.level <= 10 ? 64 : 72,
    grassNear: L.level <= 3 ? 1 : L.level <= 6 ? 0.7 : 0.55,
    grassFar: L.level <= 3 ? 1.4 : L.level <= 6 ? 1.05 : 0.85,
  };
}

// Escalón de calidad de SHENLONG (0 bajo … 3 ultra) para un nivel del tipo B.
export const shenTierFromLevel = (n) => (n <= 3 ? 0 : n <= 6 ? 1 : n <= 12 ? 2 : 3);

// Todo lo que hay que aplicar para los ajustes y la calidad actuales. baseQ: calidad del tipo A que toca (QUALITY[...]).
// Devuelve { q, scale, level, post, toneMapping, aniso, shenTier, capped }. No toca nada: lo aplica quien llama.
export function resolveQuality(p, { baseQ, tier = 'mid', thermal = 0, battery = 0 } = {}) {
  const isB = p.mode === 'b';
  const eff = isB ? effectiveLevel(p, tier, { thermal, battery }) : 0;
  const L = isB ? levelB(eff) : null;
  const q = { ...(isB ? worldQualityFromLevel(L) : baseQ || QUALITY.mid) };

  if (p.pixelRatio !== 'auto') q.pixelRatio = Number(p.pixelRatio);
  if (p.shadows !== 'auto') q.shadow = SHADOW_SIZE[p.shadows];
  if (p.shadowMap !== 'auto') q.shadow = q.shadow > 0 ? Number(p.shadowMap) : q.shadow;
  if (p.shadows === 'off') q.shadow = 0;
  if (p.vegetation !== 'auto') q.density = DENSITY[p.vegetation];
  if (p.chunkRadius !== 'auto') {
    q.radius = p.chunkRadius;
    q.propsLow = Math.max(q.propsLow, p.chunkRadius - 1);
  }

  // Follaje realista: tarjetas de hojas en árboles/arbustos de los trozos completos (cuesta polígonos: solo con ajuste «Sí» o auto en nivel 13+ del tipo B).
  const leaves = p.leaves === 'on' || (p.leaves === 'auto' && isB && eff >= 13);
  q.leafCards = leaves && q.propsFull > 0;

  const pick = (mode, fromLevel, manual) => (mode === 'off' ? 0 : mode === 'on' ? manual : fromLevel || 0);
  const aaMode = p.aa !== 'auto' ? p.aa : isB ? L.aa : q.antialias ? 'canvas' : 'off';
  const post = {
    aa: aaMode, // canvas = el suavizado del propio lienzo (sin tuberías de imagen); off = sin suavizado
    bloom: pick(p.bloom, L?.bloom, p.bloomStrength),
    ssao: pick(p.ssao, L?.ssao, p.ssaoRadius),
    rays: pick(p.rays, L?.rays, p.raysAmt),
    sharpen: pick(p.sharpen, L?.sharpen, p.sharpenAmt),
    grain: p.grain ? p.grainAmt : 0,
    ca: p.ca ? p.caAmt : 0,
    grade: p.grade === 'on' || (p.grade === 'auto' && !!L?.grade) || p.contrast !== 1 || p.sat !== 1 || p.vignette > 0 || p.temp !== 0 || p.lift !== 0 || p.gamma !== 1 || p.gain !== 1,
    lift: p.lift, gamma: p.gamma, gain: p.gain, temp: p.temp, contrast: p.contrast, sat: p.sat, vignette: p.vignette,
  };
  // Gradación «auto» (nivel 18 en adelante): los mismos valores suaves que usaba el otro proyecto.
  if (post.grade && p.grade === 'auto' && p.lift === 0 && p.gamma === 1 && p.gain === 1) Object.assign(post, { lift: 0.006, gamma: 1.05, gain: 1.05 });
  // La tubería de imagen (dibujar en un buffer y componer después) solo hace falta si algo la pide; el mapeo de tonos lo hace el renderer.
  post.active = ['msaa', 'fxaa', 'taa'].includes(post.aa) || post.bloom > 0 || post.ssao > 0 || post.rays > 0 || post.sharpen > 0 || post.grain > 0 || post.ca > 0 || post.grade;

  const aniso = p.aniso !== 'auto' ? Number(p.aniso) : L?.aniso || 0;
  return {
    q,
    scale: isB ? L.scale : 1,
    level: eff,
    post,
    toneMapping: p.toneMapping,
    aniso,
    leaves,
    shenTier: isB ? shenTierFromLevel(eff) : null,
    capped: isB && eff < p.level,
  };
}

// Tamaño máximo de las texturas según el ajuste (personaje y mundo). tier: gama del dispositivo.
export const TEX_SIZES = { low: 512, medium: 1024, high: 2048, max: 4096 };
export function texMax(setting, tier) {
  if (setting && setting !== 'auto') return TEX_SIZES[setting] || 2048;
  return tier === 'low' ? 1024 : 2048;
}
