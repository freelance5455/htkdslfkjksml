/* Bestiář – stav odkrytí (ukládá se do postupu hráče: BD.store.profile.bestiary).
   Klíč záznamu = 'druh:id' (např. 'enemies:ghost'). Stav: 0 neznámé, 1 viděno, 2 poznáno.
   enemies: viděno = nepřítel se objevil v boji, poznáno = hráč dokončil level, ve kterém se objevil
   cards:   viděno = karta ti poprvé padla, poznáno = použil jsi ji; záložka Karty se v knize ukáže až po první kartě
   towers:  viděno = věž se nabídla ke stavbě/vylepšení, poznáno = hráč ji postavil
   read[klíč] = stupeň, který už hráč v knize otevřel (nepřečtené = stav > read)
   Načítá se po store.js.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var ui = Vue.reactive({ open: false, tab: 'enemies', toast: '' }), toastT = 0;
  function P() { return BD.store.profile.bestiary; }
  function key(kind, id) { return kind + ':' + id; }

  function nameOf(kind, id) {
    if (kind === 'enemies') return BD.systems.enemies.TYPES[id] ? BD.systems.enemies.TYPES[id].name : id;
    if (kind === 'towers') return BD.data.towers[id] ? BD.data.towers[id].name : id;
    if (kind === 'cards') return BD.data.cards.list[id] ? BD.data.cards.list[id].name : id;
    return id;
  }
  function raise(kind, id, to) {
    var k = key(kind, id), cur = P().seen[k] || 0;
    if (cur >= to) return false;
    P().seen[k] = to;
    ui.toast = (to === 1 ? 'Nový záznam v bestiáři: ' : 'Bestiář: poznáno – ') + nameOf(kind, id) + '  (klávesa B)';
    clearTimeout(toastT); toastT = setTimeout(function () { ui.toast = ''; }, 3500);
    return true;
  }
  function entries() {
    var out = [];
    ['enemies', 'towers', 'cards'].forEach(function (kind) { (BD.data.bestiary[kind] || []).forEach(function (e) { out.push({ kind: kind, id: e.id }); }); });
    return out;
  }

  BD.bestiary = {
    ui: ui,
    state: function (kind, id) { return P().seen[key(kind, id)] || 0; },
    see: function (kind, id) { return raise(kind, id, 1); },
    know: function (kind, id) { return raise(kind, id, 2); },
    read: function (kind, id) { var s = this.state(kind, id); if (s) P().read[key(kind, id)] = s; },
    unread: function (kind, id) { var s = this.state(kind, id); return s > 0 && (P().read[key(kind, id)] || 0) < s; },
    unreadCount: function (kind) {
      var self = this; return entries().filter(function (e) { return (!kind || e.kind === kind) && self.unread(e.kind, e.id); }).length;
    },
    anyCard: function () { return entries().some(function (e) { return e.kind === 'cards' && P().seen[key('cards', e.id)] > 0; }); },
    merged: function (type, tier) { if ((P().merged[type] || 0) < tier) P().merged[type] = tier; },
    mergedTier: function (type) { return P().merged[type] || 0; },
    revealAll: function () { entries().forEach(function (e) { P().seen[key(e.kind, e.id)] = 2; }); P().merged.normal = 2; },
    reset: function () { BD.store.profile.bestiary = { seen: {}, read: {}, merged: {} }; },
    open: function (tab) { if (tab) ui.tab = tab; ui.open = true; },
    close: function () { ui.open = false; },
    toggle: function () { ui.open = !ui.open; },
  };
})(window.BD);
