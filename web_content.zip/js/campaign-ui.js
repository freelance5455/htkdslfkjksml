/* campaign-ui.js — Phase 10 interface: Goals screen (🎯), event popups, end-of-campaign screen, credits. */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const pct = x => Math.round(x * 100) + '%';
  const fmt = n => Math.round(n).toLocaleString('en-US');
  const bar = f => '<div class="bar g"><i style="width:' + Math.max(0, Math.min(100, f * 100)).toFixed(0) + '%"></i></div>';
  const me = () => G.state.player;
  let resumeAfter = false;

  /* =============== Goals screen =============== */
  G.showGoals = function () {
    const st = G.state, c = st.camp, pid = me(); if (!c) return;
    const s = G.campaignSummary();
    let h = '<h3>🎯 Goals — ' + G.COUNTRIES[pid].name + '</h3>';
    if (c.mode === 'campaign') {
      h += '<div class="eqline">Campaign · ends ' + 'Jan ' + c.endY + ' · you hold <b>' + pct(s.share) + '</b> of the land (win at ' + pct(s.dom) + ') · with allies <b>' + pct(s.allied) + '</b> (win at ' + pct(s.ally) + ') · rank <b>#' + s.rank + '</b> of ' + s.total + ' · score ' + fmt(s.score) + '</div>';
    } else h += '<div class="eqline">Sandbox — no victory or defeat conditions. Goals still pay rewards. Rank #' + s.rank + ' of ' + s.total + ' · score ' + fmt(s.score) + '</div>';
    h += '<h3 style="font-size:15px">National goals</h3>';
    if (!c.goals.length) h += '<p class="dim">No goals right now. New ones appear at the start of each month.</p>';
    c.goals.forEach(g => {
      const cur = G.goalProgress(pid, g), f = Math.max(0, (cur - g.start) / Math.max(1, g.target - g.start)), left = Math.max(0, g.due - st.day);
      h += '<div class="slot"><div class="info"><b>' + g.text + '</b><br><small>' + fmt(cur) + ' / ' + fmt(g.target) + ' · ' + left + ' days left · reward 💰 ' + g.reward.gold + ' 👥 ' + g.reward.manpower + '</small>' + bar(f) + '</div></div>';
    });
    const top = G.ranking().slice(0, 8);
    h += '<h3 style="font-size:15px">Ranking</h3><div class="rtable"><div class="rh" style="grid-template-columns:.4fr 2fr 1fr"><span>#</span><span>Nation</span><span>Score</span></div>' +
      top.map((r, i) => '<div class="rw" style="grid-template-columns:.4fr 2fr 1fr"><span>' + (i + 1) + '</span><span>' + (r.id === pid ? '★ ' : '') + G.COUNTRIES[r.id].name + '</span><span>' + fmt(r.score) + '</span></div>').join('') + '</div>';
    const ev = st.ev && st.ev.log || [];
    h += '<h3 style="font-size:15px">Recent events</h3>' + (ev.length ? '<div class="help" style="max-height:140px;overflow:auto">' + ev.slice(0, 8).map(x => '• ' + x).join('<br>') + '</div>' : '<p class="dim">Nothing yet.</p>');
    h += '<div class="row"><button id="gl-close">Close</button></div>';
    $('modal-box').innerHTML = h; $('modal').classList.remove('hidden');
    $('gl-close').onclick = G.closeModal;
  };

  /* =============== event popup =============== */
  G.showEventPopup = function () {
    const spec = G.nextEventSpec(); if (!spec) return;
    const st = G.state;
    if (!$('modal').classList.contains('hidden') && $('modal-box').dataset.ev === '1') return;   // already showing one
    resumeAfter = resumeAfter || !st.paused;
    G.setPaused(true); G.updateTopBar();
    let h = '<h3>' + (spec.hist ? '📰 ' : '✉ ') + spec.title + '</h3><p style="margin:6px 0 10px">' + spec.text + '</p>';
    spec.opts.forEach((o, i) => { h += '<div class="slot"><div class="info"><b>' + o.label + '</b><br><small>' + o.desc + '</small></div><button class="primary" data-o="' + i + '">Choose</button></div>'; });
    $('modal-box').innerHTML = h; $('modal-box').dataset.ev = '1'; $('modal').classList.remove('hidden');
    document.querySelectorAll('#modal-box button[data-o]').forEach(b => b.onclick = () => {
      const out = G.chooseEvent(+b.dataset.o);
      G.toast(out.length ? out.join(' · ') : 'Decision made');
      $('modal-box').dataset.ev = '';
      if (G.state.ev.pending.length) { G.showEventPopup(); return; }
      G.closeModal(); G.updateTopBar(); G.requestDraw();
      if (resumeAfter && !(G.state.camp && G.state.camp.ended)) G.setPaused(false);
      resumeAfter = false; G.updateTopBar();
    });
  };
  G.onEventPending = function () { G.showEventPopup(); };
  G.onHeadline = function (h) { G.toast('📰 ' + h.title); };
  G.onGoalDone = function (g) { G.toast('🎯 Goal achieved: ' + g.text); };
  G.onGoalFailed = function (g) { G.toast('Goal expired: ' + g.text); };

  /* =============== end screen =============== */
  const END = {
    domination: ['DOMINATION VICTORY', 'Your nation dominates the world map.'],
    alliance: ['ALLIANCE VICTORY', 'You and your allies command the world.'],
    supreme: ['SUPREME POWER', 'The end date arrives and no nation is stronger than yours.'],
    great: ['GREAT POWER', 'You end the campaign among the three strongest nations.'],
    survivor: ['SURVIVOR', 'Your nation endured and finishes in the upper half.'],
    minor: ['MINOR POWER', 'Your nation survived, but others pulled far ahead.'],
    defeat: ['DEFEAT', 'Your nation has been eliminated.']
  };
  G.onCampaignEnd = function (r) {
    const st = G.state, pid = me(), e = END[r.kind] || END.survivor, won = r.kind !== 'defeat';
    let h = '<h1>' + e[0] + '</h1><div class="tagline">' + G.COUNTRIES[pid].name + ' · ' + r.date + '</div><p style="text-align:center;margin:6px 0">' + e[1] + (r.by ? ' Eliminated by ' + G.COUNTRIES[r.by].name + '.' : '') + '</p>' +
      '<div class="grid">' + [['Score', fmt(r.score)], ['Rank', '#' + r.rank], ['Land share', pct(r.share)], ['Provinces', r.provs], ['Goals done', r.goals], ['Days played', r.day]]
        .map(x => '<div class="cell"><span>' + x[0] + '</span>' + x[1] + '</div>').join('') + '</div>' +
      '<div class="row">' + (won ? '<button class="primary" id="en-cont">Keep playing (sandbox)</button>' : '') + '<button id="en-menu">Back to nation select</button></div>';
    $('modal-box').innerHTML = h; $('modal-box').dataset.ev = ''; $('modal').classList.remove('hidden');
    const cont = $('en-cont'); if (cont) cont.onclick = () => { st.camp.mode = 'sandbox'; G.closeModal(); G.toast('Sandbox mode — no further victory conditions'); };
    $('en-menu').onclick = () => { st.player = null; G.showStart(); };
  };
  const prevDefeat = G.onPlayerDefeated;
  G.onPlayerDefeated = function (by) {
    const c = G.state.camp;
    if (c && c.mode === 'campaign' && !c.ended) G.campaignDefeat(by); else if (prevDefeat) prevDefeat(by);
  };

  /* =============== credits =============== */
  G.showCredits = function () {
    $('modal-box').innerHTML = '<h3>Credits</h3><div class="help">' +
      '<b>Empires — World at War</b> · version ' + G.VERSION + '<br>Offline HTML5 / Canvas grand strategy game. No servers, no tracking, no external assets.<br><br>' +
      '• Coastlines: <b>Natural Earth</b> 1:50m land data (public domain), simplified.<br>' +
      '• Flags, icons, maps and all code are drawn in code by this project; flags show designs of c. 1936 (some emblems omitted).<br>' +
      '• Names of nations and cities are historical; the fictional Empires scenario is original.<br>' +
      '• Game rules are an original design inspired by classic grand strategy games.</div>' +
      '<div class="row"><button id="cr-back">Back</button></div>';
    $('modal').classList.remove('hidden'); $('cr-back').onclick = () => G.showMenu();
  };

  G.bindCampaignUI = function () {
    const b = $('btn-goals'); if (b) b.onclick = () => G.showGoals();
  };
  // After loading a save or starting: show any waiting event.
  G.resumeEvents = function () { if (G.state && G.state.ev && G.state.ev.pending.length) G.showEventPopup(); };
})(window.EMP = window.EMP || {});
