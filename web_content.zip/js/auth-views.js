/**
 * BD BLOOD DONATION - Authentication Views
 * Login, Registration with Bangladesh Location Selectors, Google Sign-in, and Forgot Password
 */

import { 
  loginWithEmail, 
  registerWithEmail, 
  loginWithGoogle, 
  sendPasswordReset 
} from './auth.js';
import { setupLocationDropdowns } from './location.js';
import { showToast, getLanguage } from './utils.js';

export function renderLoginPage(container) {
  const isBn = getLanguage() === 'bn';

  container.innerHTML = `
    <div class="auth-page animate-slide-in">
      <div class="auth-header">
        <div class="auth-logo-large">🩸</div>
        <h1 class="auth-title">${isBn ? 'স্বাগতম' : 'Welcome'}</h1>
        <p class="auth-subtitle">${isBn ? 'রক্তের প্রয়োজনে, পাশে আছি আমরা।' : 'Standing together when blood is needed.'}</p>
      </div>

      <div class="auth-card">
        <!-- Google Sign-in Button -->
        <button id="google-login-btn" class="btn btn-google btn-block" type="button">
          <svg class="google-icon" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
          </svg>
          <span>${isBn ? 'গুগল দিয়ে প্রবেশ করুন' : 'Continue with Google'}</span>
        </button>

        <div class="auth-divider">
          <span>${isBn ? 'অথবা ইমেইল দিয়ে' : 'or with email'}</span>
        </div>

        <form id="login-form">
          <div class="form-group">
            <label class="form-label">${isBn ? 'ইমেইল ঠিকানা' : 'Email Address'}</label>
            <div class="input-icon-wrap">
              <span class="input-icon">✉️</span>
              <input type="email" id="login-email" class="form-control" placeholder="user@example.com" required />
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">${isBn ? 'পাসওয়ার্ড' : 'Password'}</label>
            <div class="input-icon-wrap">
              <span class="input-icon">🔒</span>
              <input type="password" id="login-password" class="form-control" placeholder="••••••••" required />
            </div>
          </div>

          <div class="auth-helper-row">
            <label style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
              <input type="checkbox" checked />
              <span>${isBn ? 'মনে রাখুন' : 'Remember me'}</span>
            </label>
            <a href="#/forgot-password" class="auth-link">${isBn ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}</a>
          </div>

          <button type="submit" id="login-submit-btn" class="btn btn-primary btn-block">
            ${isBn ? 'লগইন করুন' : 'Login'}
          </button>
        </form>
      </div>

      <div class="auth-footer">
        ${isBn ? 'এখনো কোনো একাউন্ট নেই?' : "Don't have an account?"}
        <a href="#/register" class="auth-link">${isBn ? 'নতুন রক্তদাতা নিবন্ধন' : 'Register as Donor'}</a>
      </div>
    </div>
  `;

  // Attach Google Sign-In
  document.getElementById('google-login-btn').addEventListener('click', async () => {
    try {
      await loginWithGoogle();
      window.location.hash = '#/home';
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Attach Email Login
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('login-submit-btn');
    btn.disabled = true;
    btn.textContent = isBn ? 'লগইন হচ্ছে...' : 'Signing in...';

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
      await loginWithEmail(email, password);
      window.location.hash = '#/home';
    } catch (err) {
      showToast(err.message, 'error');
      btn.disabled = false;
      btn.textContent = isBn ? 'লগইন করুন' : 'Login';
    }
  });
}

export function renderRegisterPage(container) {
  const isBn = getLanguage() === 'bn';

  container.innerHTML = `
    <div class="auth-page animate-slide-in" style="min-height: auto; padding-top: 16px;">
      <div class="auth-header">
        <h1 class="auth-title">${isBn ? 'রক্তদাতা নিবন্ধন' : 'Donor Registration'}</h1>
        <p class="auth-subtitle">${isBn ? 'একজন স্বেচ্ছাসেবী রক্তদাতা হিসেবে যুক্ত হোন' : 'Join as a volunteer blood donor'}</p>
      </div>

      <div class="auth-card">
        <form id="register-form">
          <!-- Full Name -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'সম্পূর্ণ নাম' : 'Full Name'} <span class="required-star">*</span></label>
            <input type="text" id="reg-name" class="form-control" placeholder="${isBn ? 'আপনার পুরো নাম' : 'Your full name'}" required />
          </div>

          <!-- Phone Number -->
          <div class="form-group">
            <label class="form-label">${isBn ? '১১ ডিজিটের মোবাইল নম্বর' : 'Phone Number (11 Digits)'} <span class="required-star">*</span></label>
            <input type="tel" id="reg-phone" class="form-control" placeholder="01XXXXXXXXX" required />
          </div>

          <!-- Email -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'ইমেইল ঠিকানা' : 'Email Address'} <span class="required-star">*</span></label>
            <input type="email" id="reg-email" class="form-control" placeholder="yourname@gmail.com" required />
          </div>

          <!-- Blood Group -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'আপনার রক্তের গ্রুপ' : 'Your Blood Group'} <span class="required-star">*</span></label>
            <div class="blood-grid" id="reg-blood-grid">
              ${['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => `
                <div class="blood-radio-btn" data-group="${bg}">${bg}</div>
              `).join('')}
            </div>
            <input type="hidden" id="reg-blood-group" required />
          </div>

          <!-- Location Hierarchy: Division -> District -> Upazila -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
            <div class="form-group">
              <label class="form-label">${isBn ? 'বিভাগ' : 'Division'} <span class="required-star">*</span></label>
              <select id="reg-division" class="form-select" required></select>
            </div>
            <div class="form-group">
              <label class="form-label">${isBn ? 'জেলা' : 'District'} <span class="required-star">*</span></label>
              <select id="reg-district" class="form-select" required></select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">${isBn ? 'উপজেলা / থানা' : 'Upazila / Area'}</label>
            <select id="reg-upazila" class="form-select"></select>
          </div>

          <!-- Password & Confirm Password -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)' : 'Password (min 6 characters)'} <span class="required-star">*</span></label>
            <input type="password" id="reg-password" class="form-control" placeholder="••••••••" required />
          </div>

          <div class="form-group">
            <label class="form-label">${isBn ? 'কনফার্ম পাসওয়ার্ড' : 'Confirm Password'} <span class="required-star">*</span></label>
            <input type="password" id="reg-confirm-password" class="form-control" placeholder="••••••••" required />
          </div>

          <button type="submit" id="reg-submit-btn" class="btn btn-primary btn-block" style="margin-top: 14px;">
            ${isBn ? 'রেজিস্ট্রেশন সম্পন্ন করুন' : 'Complete Registration'}
          </button>
        </form>
      </div>

      <div class="auth-footer">
        ${isBn ? 'ইতোমধ্যে একাউন্ট আছে?' : 'Already have an account?'}
        <a href="#/login" class="auth-link">${isBn ? 'লগইন করুন' : 'Login'}</a>
      </div>
    </div>
  `;

  // Setup location dropdowns
  setupLocationDropdowns({
    divisionSelectEl: document.getElementById('reg-division'),
    districtSelectEl: document.getElementById('reg-district'),
    upazilaSelectEl: document.getElementById('reg-upazila'),
    selectedDivision: 'dhaka',
    selectedDistrict: 'dhaka',
    lang: isBn ? 'bn' : 'en'
  });

  // Handle blood chips
  const bloodButtons = container.querySelectorAll('#reg-blood-grid .blood-radio-btn');
  const bloodHiddenInput = document.getElementById('reg-blood-group');
  bloodButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      bloodButtons.forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      bloodHiddenInput.value = btn.dataset.group;
    });
  });

  // Handle register submit
  document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!bloodHiddenInput.value) {
      showToast(isBn ? 'আপনার রক্তের গ্রুপ নির্বাচন করুন।' : 'Please select your blood group.', 'error');
      return;
    }

    const btn = document.getElementById('reg-submit-btn');
    btn.disabled = true;
    btn.textContent = isBn ? 'নিবন্ধন করা হচ্ছে...' : 'Registering...';

    try {
      await registerWithEmail({
        fullName: document.getElementById('reg-name').value,
        phone: document.getElementById('reg-phone').value,
        email: document.getElementById('reg-email').value,
        password: document.getElementById('reg-password').value,
        confirmPassword: document.getElementById('reg-confirm-password').value,
        bloodGroup: bloodHiddenInput.value,
        division: document.getElementById('reg-division').value,
        district: document.getElementById('reg-district').value,
        upazila: document.getElementById('reg-upazila').value
      });

      window.location.hash = '#/home';
    } catch (err) {
      showToast(err.message, 'error', 4500);
      btn.disabled = false;
      btn.textContent = isBn ? 'রেজিস্ট্রেশন সম্পন্ন করুন' : 'Complete Registration';
    }
  });
}

export function renderForgotPasswordPage(container) {
  const isBn = getLanguage() === 'bn';

  container.innerHTML = `
    <div class="auth-page animate-slide-in">
      <div class="auth-header">
        <h1 class="auth-title">${isBn ? 'পাসওয়ার্ড রিসেট' : 'Reset Password'}</h1>
        <p class="auth-subtitle">${isBn ? 'আপনার নিবন্ধিত ইমেইল ঠিকানায় রিসেট লিংক পাঠানো হবে' : 'Enter your registered email'}</p>
      </div>

      <div class="auth-card">
        <form id="forgot-form">
          <div class="form-group">
            <label class="form-label">${isBn ? 'ইমেইল ঠিকানা' : 'Email Address'}</label>
            <input type="email" id="forgot-email" class="form-control" placeholder="user@example.com" required />
          </div>

          <button type="submit" id="forgot-submit-btn" class="btn btn-primary btn-block" style="margin-top: 10px;">
            ${isBn ? 'রিসেট লিংক পাঠান' : 'Send Reset Link'}
          </button>
        </form>
      </div>

      <div class="auth-footer">
        <a href="#/login" class="auth-link">&larr; ${isBn ? 'লগইন পেজে ফিরুন' : 'Back to Login'}</a>
      </div>
    </div>
  `;

  document.getElementById('forgot-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('forgot-submit-btn');
    btn.disabled = true;

    try {
      await sendPasswordReset(document.getElementById('forgot-email').value);
      window.location.hash = '#/login';
    } catch (err) {
      showToast(err.message, 'error');
      btn.disabled = false;
    }
  });
}
