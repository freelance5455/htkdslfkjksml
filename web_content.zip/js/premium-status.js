import { normalizeStatus } from "./shared-utils.js";
// =====================================================
// NetEarn Pro
// PREMIUM STATUS PAGE
// FINAL — STATUS AWARE + USER SAFE
//
// AUTHORITATIVE USER FIELD:
// users/{uid}.verified
//
// REQUEST:
// subscriptionRequests/{uid}.status
//
// STATUS FLOW:
//
// No Request
//     ↓
// Verification Required
//
// Pending
//     ↓
// Verification Pending
//
// Rejected
//     ↓
// Verification Rejected
//
// Approved OR users/{uid}.verified === true
//     ↓
// Premium Active
// =====================================================


import { auth, db } from "./firebase.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// CONFIG
// =====================================================

const PREMIUM_DETAILS_PAGE =
    "verification-details.html";

const LOGIN_PAGE =
    "index.html";

const REQUEST_COLLECTION =
    "subscriptionRequests";

const USER_COLLECTION =
    "users";


// =====================================================
// DOM ELEMENTS
// =====================================================

const currentStatusCard =
    document.getElementById(
        "premiumCurrentStatus"
    );


const statusIcon =
    document.getElementById(
        "premiumStatusIcon"
    );


const statusIconText =
    document.getElementById(
        "premiumStatusIconText"
    );


const statusLabel =
    document.getElementById(
        "premiumStatusLabel"
    );


const statusTitle =
    document.getElementById(
        "premiumStatusTitle"
    );


const statusMessage =
    document.getElementById(
        "premiumStatusMessage"
    );


const statusAction =
    document.getElementById(
        "premiumStatusAction"
    );


const statusActionText =
    document.getElementById(
        "premiumStatusActionText"
    );


const summaryStatus =
    document.getElementById(
        "summaryStatus"
    );


const summaryPlan =
    document.getElementById(
        "summaryPlan"
    );


const summaryRequest =
    document.getElementById(
        "summaryRequest"
    );


const summaryUpdated =
    document.getElementById(
        "summaryUpdated"
    );


const statusExtraMessage =
    document.getElementById(
        "premiumStatusExtraMessage"
    );


const requestCard =
    document.getElementById(
        "premiumRequestCard"
    );


const requestPaymentMethod =
    document.getElementById(
        "requestPaymentMethod"
    );


const requestAmount =
    document.getElementById(
        "requestAmount"
    );


const requestTransactionId =
    document.getElementById(
        "requestTransactionId"
    );


const requestSubmitted =
    document.getElementById(
        "requestSubmitted"
    );


const rejectionCard =
    document.getElementById(
        "premiumRejectionCard"
    );


const rejectionReason =
    document.getElementById(
        "premiumRejectionReason"
    );


const activeCard =
    document.getElementById(
        "premiumActiveCard"
    );


// =====================================================
// APP STATE
// =====================================================

let currentUser = null;

let currentRequest = null;

let currentStatus = "loading";


// =====================================================
// NORMALIZE STATUS
// =====================================================
// =====================================================
// SAFE TEXT
// =====================================================

function safeText(value, fallback = "—") {

    if (
        value === null ||
        value === undefined
    ) {

        return fallback;

    }


    const text =
        String(value).trim();


    return text || fallback;

}


// =====================================================
// FORMAT DATE
// =====================================================

function formatDate(value) {

    if (!value) {

        return "—";

    }


    try {

        // Firestore Timestamp
        if (
            typeof value?.toDate ===
            "function"
        ) {

            const date =
                value.toDate();


            return date.toLocaleString(
                "en-BD",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                }
            );

        }


        // JavaScript Date
        if (
            value instanceof Date
        ) {

            return value.toLocaleString(
                "en-BD",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                }
            );

        }


        // String / number date
        const date =
            new Date(value);


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return "—";

        }


        return date.toLocaleString(
            "en-BD",
            {
                day: "2-digit",
                month: "short",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            }
        );

    }

    catch (error) {

        console.warn(
            "⚠️ Date formatting failed:",
            error
        );


        return "—";

    }

}


// =====================================================
// FORMAT AMOUNT
// =====================================================

function formatAmount(amount) {

    const value =
        Number(amount);


    if (
        !Number.isFinite(value)
    ) {

        return "—";

    }


    return (
        "৳" +
        value.toLocaleString(
            "en-US"
        )
    );

}


// =====================================================
// HIDE OPTIONAL CARDS
// =====================================================

function hideOptionalCards() {

    if (requestCard) {

        requestCard.hidden = true;

    }


    if (rejectionCard) {

        rejectionCard.hidden = true;

    }


    if (activeCard) {

        activeCard.hidden = true;

    }

}


// =====================================================
// SHOW LOADING STATE
// =====================================================

function showLoadingState() {

    currentStatus =
        "loading";


    if (currentStatusCard) {

        currentStatusCard.className =
            "premium-current-status loading";

    }


    if (statusIconText) {

        statusIconText.textContent =
            "⏳";

    }


    if (statusLabel) {

        statusLabel.textContent =
            "CHECKING STATUS";

    }


    if (statusTitle) {

        statusTitle.textContent =
            "Checking Premium Status...";

    }


    if (statusMessage) {

        statusMessage.textContent =
            "আপনার Account-এর বর্তমান Premium Status যাচাই করা হচ্ছে।";

    }


    if (statusAction) {

        statusAction.disabled =
            true;

    }


    if (statusActionText) {

        statusActionText.textContent =
            "Please Wait";

    }


    if (summaryStatus) {

        summaryStatus.textContent =
            "Checking...";

    }


    if (summaryRequest) {

        summaryRequest.textContent =
            "Checking...";

    }


    if (summaryUpdated) {

        summaryUpdated.textContent =
            "—";

    }


    if (statusExtraMessage) {

        statusExtraMessage.textContent =
            "আপনার Account-এর Premium Status Firestore থেকে যাচাই করা হচ্ছে।";

    }


    hideOptionalCards();

}


// =====================================================
// APPLY COMMON STATUS UI
// =====================================================

function applyStatusClass(className) {

    if (!currentStatusCard) {

        return;

    }


    currentStatusCard.className =
        "premium-current-status " +
        className;

}


// =====================================================
// SET ACTION BUTTON
// =====================================================

function setActionButton(
    text,
    disabled = false
) {

    if (!statusAction) {

        return;

    }


    statusAction.disabled =
        disabled;


    if (statusActionText) {

        statusActionText.textContent =
            text;

    }

}


// =====================================================
// VERIFICATION REQUIRED
// =====================================================

function showVerificationRequired() {

    currentStatus =
        "required";


    applyStatusClass(
        "not-verified"
    );


    if (statusIconText) {

        statusIconText.textContent =
            "🔵";

    }


    if (statusLabel) {

        statusLabel.textContent =
            "ACCOUNT STATUS";

    }


    if (statusTitle) {

        statusTitle.textContent =
            "Verification Required";

    }


    if (statusMessage) {

        statusMessage.textContent =
            "আপনার Premium Verification এখনো সম্পন্ন হয়নি। Premium সুবিধা পেতে Account Verify করুন।";

    }


    setActionButton(
        "Verify Now",
        false
    );


    if (summaryStatus) {

        summaryStatus.textContent =
            "Verification Required";

    }


    if (summaryPlan) {

        summaryPlan.textContent =
            "Lifetime Premium";

    }


    if (summaryRequest) {

        summaryRequest.textContent =
            "Not Submitted";

    }


    if (summaryUpdated) {

        summaryUpdated.textContent =
            "—";

    }


    if (statusExtraMessage) {

        statusExtraMessage.textContent =
            "আপনার Premium Verification এখনো শুরু হয়নি। Verify Now button ব্যবহার করে Verification শুরু করতে পারবেন।";

    }


    hideOptionalCards();

}


// =====================================================
// PENDING
// =====================================================

function showPending(request) {

    currentStatus =
        "pending";


    applyStatusClass(
        "pending"
    );


    if (statusIconText) {

        statusIconText.textContent =
            "🟡";

    }


    if (statusLabel) {

        statusLabel.textContent =
            "VERIFICATION PENDING";

    }


    if (statusTitle) {

        statusTitle.textContent =
            "Verification Pending";

    }


    if (statusMessage) {

        statusMessage.textContent =
            "আপনার Verification Request Admin Review-এ রয়েছে। Review সম্পন্ন হওয়া পর্যন্ত অপেক্ষা করুন।";

    }


    setActionButton(
        "Under Review",
        true
    );


    if (summaryStatus) {

        summaryStatus.textContent =
            "Verification Pending";

    }


    if (summaryPlan) {

        summaryPlan.textContent =
            "Lifetime Premium";

    }


    if (summaryRequest) {

        summaryRequest.textContent =
            "Pending";

    }


    if (summaryUpdated) {

        summaryUpdated.textContent =
            formatDate(
                request?.createdAt
            );

    }


    if (statusExtraMessage) {

        statusExtraMessage.textContent =
            "আপনার Request সফলভাবে Submit হয়েছে। Admin Payment এবং তথ্য যাচাই করার পর Premium Status update করা হবে।";

    }


    hideOptionalCards();


    showRequestCard(
        request
    );

}


// =====================================================
// REJECTED
// =====================================================

function showRejected(request) {

    currentStatus =
        "rejected";


    applyStatusClass(
        "rejected"
    );


    if (statusIconText) {

        statusIconText.textContent =
            "🔴";

    }


    if (statusLabel) {

        statusLabel.textContent =
            "VERIFICATION REJECTED";

    }


    if (statusTitle) {

        statusTitle.textContent =
            "Verification Rejected";

    }


    if (statusMessage) {

        statusMessage.textContent =
            "আপনার Verification Request অনুমোদিত হয়নি। নিচে দেওয়া কারণটি দেখুন।";

    }


    setActionButton(
        "Try Again",
        false
    );


    if (summaryStatus) {

        summaryStatus.textContent =
            "Verification Rejected";

    }


    if (summaryPlan) {

        summaryPlan.textContent =
            "Lifetime Premium";

    }


    if (summaryRequest) {

        summaryRequest.textContent =
            "Rejected";

    }


    if (summaryUpdated) {

        summaryUpdated.textContent =
            formatDate(
                request?.rejectedAt ||
                request?.updatedAt ||
                request?.createdAt
            );

    }


    if (statusExtraMessage) {

        statusExtraMessage.textContent =
            "আপনি কারণটি দেখে তথ্য ঠিক করে আবার নতুন Verification Request Submit করতে পারবেন।";

    }


    hideOptionalCards();


    showRequestCard(
        request
    );


    showRejectionCard(
        request
    );

}


// =====================================================
// ACTIVE
// =====================================================

function showActive(request) {

    currentStatus =
        "active";


    applyStatusClass(
        "active"
    );


    if (statusIconText) {

        statusIconText.textContent =
            "🟢";

    }


    if (statusLabel) {

        statusLabel.textContent =
            "PREMIUM ACTIVE";

    }


    if (statusTitle) {

        statusTitle.textContent =
            "Premium Active";

    }


    if (statusMessage) {

        statusMessage.textContent =
            "আপনার Premium Account সফলভাবে Verified এবং Active রয়েছে।";

    }


    setActionButton(
        "Premium Active",
        true
    );


    if (summaryStatus) {

        summaryStatus.textContent =
            "Premium Active";

    }


    if (summaryPlan) {

        summaryPlan.textContent =
            "Lifetime Premium";

    }


    if (summaryRequest) {

        summaryRequest.textContent =
            request
                ? "Approved"
                : "Verified";

    }


    if (summaryUpdated) {

        summaryUpdated.textContent =
            formatDate(
                request?.approvedAt ||
                request?.updatedAt ||
                request?.createdAt
            );

    }


    if (statusExtraMessage) {

        statusExtraMessage.textContent =
            "আপনার Premium সুবিধা বর্তমানে Active রয়েছে। Premium-enabled Work ও Features আপনার Account-এর নিয়ম অনুযায়ী ব্যবহার করতে পারবেন।";

    }


    hideOptionalCards();


    if (request) {

        showRequestCard(
            request
        );

    }


    if (activeCard) {

        activeCard.hidden =
            false;

    }

}


// =====================================================
// SHOW REQUEST DETAILS
// =====================================================

function showRequestCard(request) {

    if (!requestCard) {

        return;

    }


    requestCard.hidden =
        false;


    if (requestPaymentMethod) {

        requestPaymentMethod.textContent =
            safeText(
                request?.paymentMethod
            );

    }


    if (requestAmount) {

        requestAmount.textContent =
            formatAmount(
                request?.amount
            );

    }


    if (requestTransactionId) {

        requestTransactionId.textContent =
            safeText(
                request?.transactionId
            );

    }


    if (requestSubmitted) {

        requestSubmitted.textContent =
            formatDate(
                request?.createdAt
            );

    }

}


// =====================================================
// SHOW REJECTION CARD
// =====================================================

function showRejectionCard(request) {

    if (!rejectionCard) {

        return;

    }


    rejectionCard.hidden =
        false;


    const reason =
        request?.rejectionReason ||
        request?.reason ||
        request?.rejectReason ||
        request?.rejectedReason;


    if (rejectionReason) {

        rejectionReason.textContent =
            safeText(
                reason,
                "আপনার Verification Request অনুমোদিত হয়নি। পুনরায় সঠিক তথ্য দিয়ে Verification Request Submit করুন।"
            );

    }

}


// =====================================================
// GET USER DOCUMENT
// =====================================================

async function getUserDocument(uid) {

    if (!uid) {

        return null;

    }


    const userRef =
        doc(
            db,
            USER_COLLECTION,
            uid
        );


    const userSnap =
        await getDoc(
            userRef
        );


    if (!userSnap.exists()) {

        return null;

    }


    return userSnap.data();

}


// =====================================================
// GET REQUEST DOCUMENT
// =====================================================

async function getRequestDocument(uid) {

    if (!uid) {

        return null;

    }


    const requestRef =
        doc(
            db,
            REQUEST_COLLECTION,
            uid
        );


    const requestSnap =
        await getDoc(
            requestRef
        );


    if (!requestSnap.exists()) {

        return null;

    }


    return requestSnap.data();

}


// =====================================================
// LOAD PREMIUM STATUS
// =====================================================

async function loadPremiumStatus() {

    if (!currentUser) {

        return;

    }


    showLoadingState();


    try {

        // =================================================
        // LOAD USER + REQUEST IN PARALLEL
        // Both documents are independent reads.
        // =================================================

        const [userData, request] =
            await Promise.all([
                getUserDocument(
                    currentUser.uid
                ),
                getRequestDocument(
                    currentUser.uid
                )
            ]);


        if (!userData) {

            throw new Error(
                "User account data পাওয়া যায়নি।"
            );

        }


        currentRequest =
            request;


        // =================================================
        // AUTHORITATIVE PREMIUM CHECK
        //
        // users/{uid}.verified === true
        // ALWAYS wins for ACTIVE state.
        // =================================================

        const verified =
            userData.verified === true;


        if (verified) {

            showActive(
                request
            );


            console.log(
                "🟢 Premium Status: ACTIVE — users.verified === true"
            );


            return;

        }


        // =================================================
        // NO REQUEST
        // =================================================

        if (!request) {

            showVerificationRequired();


            console.log(
                "🔵 Premium Status: VERIFICATION REQUIRED"
            );


            return;

        }


        // =================================================
        // REQUEST STATUS
        // =================================================

        const status =
            normalizeStatus(
                request.status
            );


        // =================================================
        // PENDING
        // =================================================

        if (
            status === "pending"
        ) {

            showPending(
                request
            );


            console.log(
                "🟡 Premium Status: PENDING"
            );


            return;

        }


        // =================================================
        // APPROVED
        //
        // IMPORTANT:
        // If approved request exists but verified
        // is still false, we do NOT independently
        // make the account active.
        //
        // users/{uid}.verified remains authoritative.
        // =================================================

        if (
            status === "approved"
        ) {

            showVerificationRequired();


            if (statusExtraMessage) {

                statusExtraMessage.textContent =
                    "আপনার Verification Request Approved দেখাচ্ছে, কিন্তু Account verification field এখনো Active হয়নি। Admin verification sync সম্পন্ন হওয়ার পর Premium Active দেখাবে।";

            }


            console.warn(
                "⚠️ Request Approved but users.verified is false."
            );


            return;

        }


        // =================================================
        // REJECTED
        // =================================================

        if (
            status === "rejected"
        ) {

            showRejected(
                request
            );


            console.log(
                "🔴 Premium Status: REJECTED"
            );


            return;

        }


        // =================================================
        // UNKNOWN / EMPTY STATUS
        // =================================================

        showVerificationRequired();


        console.warn(
            "⚠️ Unknown Premium Request Status:",
            request.status
        );

    }

    catch (error) {

        console.error(
            "❌ Premium Status Load Error:",
            error
        );


        currentStatus =
            "error";


        applyStatusClass(
            "not-verified"
        );


        if (statusIconText) {

            statusIconText.textContent =
                "⚠️";

        }


        if (statusLabel) {

            statusLabel.textContent =
                "STATUS CHECK";

        }


        if (statusTitle) {

            statusTitle.textContent =
                "Status Check Failed";

        }


        if (statusMessage) {

            statusMessage.textContent =
                "আপনার Premium Status এই মুহূর্তে যাচাই করা যাচ্ছে না। Internet connection অথবা Firebase access check করুন।";

        }


        setActionButton(
            "Refresh",
            false
        );


        if (summaryStatus) {

            summaryStatus.textContent =
                "Unable to Check";

        }


        if (summaryRequest) {

            summaryRequest.textContent =
                "—";

        }


        if (summaryUpdated) {

            summaryUpdated.textContent =
                "—";

        }


        if (statusExtraMessage) {

            statusExtraMessage.textContent =
                "কিছুক্ষণ পর Refresh করুন। কোনো status না জেনে Verification Request Submit করা হবে না।";

        }


        hideOptionalCards();

    }

}


// =====================================================
// ACTION BUTTON
// =====================================================

if (statusAction) {

    statusAction.addEventListener(
        "click",
        async () => {

            // =============================================
            // VERIFICATION REQUIRED
            // =============================================

            if (
                currentStatus ===
                "required"
            ) {

                window.location.href =
                    PREMIUM_DETAILS_PAGE;

                return;

            }


            // =============================================
            // REJECTED
            // =============================================

            if (
                currentStatus ===
                "rejected"
            ) {

                window.location.href =
                    PREMIUM_DETAILS_PAGE;

                return;

            }


            // =============================================
            // ERROR
            // =============================================

            if (
                currentStatus ===
                "error"
            ) {

                await loadPremiumStatus();

                return;

            }


            // =============================================
            // PENDING
            // =============================================

            if (
                currentStatus ===
                "pending"
            ) {

                alert(
                    "⏳ আপনার Verification Request বর্তমানে Admin Review-এ রয়েছে।"
                );

                return;

            }


            // =============================================
            // ACTIVE
            // =============================================

            if (
                currentStatus ===
                "active"
            ) {

                alert(
                    "👑 আপনার Premium Account ইতিমধ্যে Active রয়েছে।"
                );

                return;

            }

        }
    );

}

// =====================================================
// AUTH STATE
// =====================================================

onAuthStateChanged(

    auth,

    async (user) => {

        // =============================================
        // NOT LOGGED IN
        // =============================================

        if (!user) {

            currentUser =
                null;


            window.location.href =
                LOGIN_PAGE;


            return;

        }


        // =============================================
        // LOGGED IN
        // =============================================

        currentUser =
            user;


        console.log(
            "👤 Premium Status User:",
            currentUser.uid
        );


        // =============================================
        // LOAD STATUS
        // =============================================

        await loadPremiumStatus();

    }

);


// =====================================================
// PAGE VISIBILITY REFRESH
//
// User payment page থেকে Back করলে status আবার check হবে.
// =====================================================

document.addEventListener(
    "visibilitychange",
    async () => {

        if (
            document.visibilityState ===
            "visible"
        ) {

            if (currentUser) {

                await loadPremiumStatus();

            }

        }

    }
);


// =====================================================
// BROWSER BACK / FORWARD
// =====================================================

window.addEventListener(
    "pageshow",
    async () => {

        if (currentUser) {

            await loadPremiumStatus();

        }

    }
);


// =====================================================
// FINAL LOG
// =====================================================

console.log(
    "✅ NetEarn Pro Premium Status — FINAL STATUS AWARE VERSION"
);