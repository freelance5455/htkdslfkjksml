// =======================================
// NetEarn Pro
// Photo Editing Task System V3
// Admin Controlled Task
// Firebase Auth + Task Validation
// =======================================

import { auth, db } from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    getDoc,
    collection,
    query,
    where,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// ELEMENTS
// =======================================

const statusBox =
    document.getElementById("taskStatus");

const startBtn =
    document.getElementById("startEditingBtn");

const taskTitle =
    document.getElementById("editingTaskTitle");


const taskReward =
    document.getElementById("editingTaskReward");

const taskTime =
    document.getElementById("editingTaskTime");


// =======================================
// APP STATE
// =======================================

let currentTask = null;
let currentTaskId = null;


// =======================================
// HELPERS
// =======================================

function setLocked(message) {

    if (statusBox) {

        statusBox.textContent =
            message;

        statusBox.className =
            "status locked";

    }

    if (startBtn) {

        startBtn.style.display =
            "none";

    }

}


function setReady() {

    if (statusBox) {

        statusBox.textContent =
            "✅ Photo Editing Task Ready";

        statusBox.className =
            "status available";

    }

    if (startBtn) {

        startBtn.style.display =
            "flex";

    }

}


// =======================================
// LOAD ADMIN PHOTO EDITING TASK
// =======================================

async function loadEditingTask() {

    const tasksRef =
        collection(db, "tasks");


    const taskQuery =
        query(
            tasksRef,
            where("category", "==", "Photo Editing"),
            where("status", "==", "Active")
        );


    // ⚡ Start the settings read in parallel with the task query.
    const settingsPromise =
        getBusinessSettings({ force: true });

    const [snapshot, businessSettings] =
        await Promise.all([
            getDocs(taskQuery),
            settingsPromise
        ]);


    if (snapshot.empty) {

        throw new Error(
            "NO_EDITING_TASK"
        );

    }


    // প্রথম Active Photo Editing Task
    const taskDoc =
        snapshot.docs[0];


    currentTaskId =
        taskDoc.id;


    currentTask =
        taskDoc.data();


    // =================================
    // SHOW TASK TITLE
    // =================================

    if (taskTitle) {

        taskTitle.textContent =
            currentTask.title ||
            currentTask.name ||
            "Photo Editing Task";

    }


    // =================================
    // SHOW REWARD
    // =================================

    const reward = getConfiguredTaskReward(currentTask, businessSettings);
    currentTask.reward = reward;


    if (taskReward) {

        taskReward.textContent =
            "৳" + reward;

    }


    // =================================
    // SHOW TIME
    // =================================

    const time =
        Number(
            currentTask.time || 30
        );


    if (taskTime) {

        taskTime.textContent =
            time + " Min";

    }


    console.log(
        "✅ Admin Editing Task Loaded:",
        currentTaskId,
        currentTask
    );

}


// =======================================
// AUTH CHECK
// =======================================

onAuthStateChanged(
    auth,
    async (user) => {

        // =================================
        // NOT LOGGED IN
        // =================================

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        try {

            // =================================
            // LOAD ADMIN TASK FIRST
            // =================================

            // ⚡ Task + user document load in parallel.
            const userRef =
                doc(
                    db,
                    "users",
                    user.uid
                );

            const [taskResult, snap] =
                await Promise.all([
                    loadEditingTask(),
                    getDoc(userRef)
                ]);


            if (!snap.exists()) {

                setLocked(
                    "⚠️ User Data Not Found"
                );

                return;

            }


            const userData =
                snap.data();


            // =================================
            // VERIFY CHECK
            // =================================

            const verified =
                userData.verified === true ||
                userData.verified === "true";


            if (!verified) {

                setLocked(
                    "🔒 Please Verify Your Account First"
                );

                return;

            }


            // =================================
            // TASK CHANCE CHECK
            // =================================

            const taskChance =
                Number(
                    userData.taskChance || 0
                );


            if (taskChance < 1) {

                setLocked(
                    "👥 Need 1 Referral = 1 Task Chance"
                );

                return;

            }


            // =================================
            // SELECTED TASK CHECK
            // =================================

            const selectedTask =
                userData.selectedTask || "";


            if (
                selectedTask &&
                selectedTask !== "editing"
            ) {

                setLocked(
                    "🔒 আগে আপনার বর্তমান Task Complete করুন"
                );

                return;

            }


            // =================================
            // TASK READY
            // =================================

            setReady();


            // =================================
            // START BUTTON
            // =================================

            if (startBtn) {

                startBtn.onclick =
                    async () => {

                        startBtn.disabled =
                            true;

                        startBtn.innerHTML =
                            "<span>⏳</span> Checking...";


                        try {

                            // =========================
                            // FRESH USER CHECK
                            // =========================

                            const freshSnap =
                                await getDoc(
                                    userRef
                                );


                            if (!freshSnap.exists()) {

                                throw new Error(
                                    "USER_NOT_FOUND"
                                );

                            }


                            const freshData =
                                freshSnap.data();


                            // =========================
                            // VERIFY AGAIN
                            // =========================

                            const freshVerified =
                                freshData.verified === true ||
                                freshData.verified === "true";


                            if (!freshVerified) {

                                throw new Error(
                                    "NOT_VERIFIED"
                                );

                            }


                            // =========================
                            // CHANCE AGAIN
                            // =========================

                            const freshChance =
                                Number(
                                    freshData.taskChance || 0
                                );


                            if (freshChance < 1) {

                                throw new Error(
                                    "NO_CHANCE"
                                );

                            }


                            // =========================
                            // SELECTED TASK AGAIN
                            // =========================

                            const freshSelected =
                                freshData.selectedTask || "";


                            if (
                                freshSelected &&
                                freshSelected !== "editing"
                            ) {

                                throw new Error(
                                    "OTHER_TASK"
                                );

                            }


                            // =========================
                            // OPEN WORK PAGE
                            // =========================

                            window.location.href =
                                "editing-work.html";

                        }

                        catch (error) {

                            console.error(
                                "Editing Start Error:",
                                error
                            );


                            startBtn.disabled =
                                false;

                            startBtn.innerHTML =
                                "<span>▶</span> Start Editing Task <span>→</span>";


                            if (
                                error.message ===
                                "NOT_VERIFIED"
                            ) {

                                setLocked(
                                    "🔒 Please Verify Your Account First"
                                );

                                return;

                            }


                            if (
                                error.message ===
                                "NO_CHANCE"
                            ) {

                                setLocked(
                                    "👥 আপনার কোনো Task Chance নেই"
                                );

                                return;

                            }


                            if (
                                error.message ===
                                "OTHER_TASK"
                            ) {

                                setLocked(
                                    "🔒 আগে আপনার বর্তমান Task Complete করুন"
                                );

                                return;

                            }


                            setLocked(
                                "⚠️ Task Load করা যায়নি। আবার চেষ্টা করুন।"
                            );

                        }

                    };

            }

        }

        catch (error) {

            console.error(
                "Editing Task Error:",
                error
            );


            if (
                error.message ===
                "NO_EDITING_TASK"
            ) {

                setLocked(
                    "📭 বর্তমানে কোনো Active Photo Editing Task নেই"
                );

                return;

            }


            setLocked(
                "⚠️ Task Load করা যায়নি। আবার চেষ্টা করুন।"
            );

        }

    }
);


console.log(
    "✅ NetEarn Pro Photo Editing V3 Loaded"
);