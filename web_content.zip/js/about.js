/**
 * BD BLOOD DONATION - About & Developer Information
 * Developer: Ibna Mahmud Robin
 * Email: robinokh@gmail.com
 * Includes full project ZIP downloader, Privacy Policy and Terms of Service.
 */

import { exportProjectZip } from './export-zip.js';
import { getLanguage, t } from './utils.js';

export function renderAboutPage(container) {
  const isBn = getLanguage() === 'bn';

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>ℹ️ ${isBn ? 'অ্যাপ পরিচিতি ও ডেভেলপার' : 'About & Developer'}</span>
      </div>

      <!-- App Branding Banner -->
      <div class="card" style="text-align: center; padding: 24px 16px;">
        <div style="width: 68px; height: 68px; margin: 0 auto 12px; background: var(--primary-gradient); border-radius: var(--radius-lg); display: flex; align-items: center; justify-content: center; font-size: 36px; color: #fff; box-shadow: var(--shadow-primary);">
          🩸
        </div>
        <h2 style="font-size: 19px; font-weight: 800; color: var(--primary-color);">BD BLOOD DONATION</h2>
        <p style="font-size: 13px; font-weight: 600; color: var(--text-main); margin-top: 4px;">
          "রক্তের প্রয়োজনে, পাশে আছি আমরা।"
        </p>
        <span class="badge badge-secondary" style="margin-top: 8px;">Version 1.0.0 (Production Release)</span>
      </div>

      <!-- Full Project ZIP Download Section -->
      <div class="card" style="background: #FFFBEB; border: 1.5px solid #FCD34D;">
        <div style="display: flex; gap: 12px; align-items: center;">
          <div style="font-size: 32px;">📦</div>
          <div>
            <div style="font-size: 14px; font-weight: 800; color: #92400E;">
              ${isBn ? 'সম্পূর্ণ সোর্স কোড জিপ (ZIP) ডাউনলোড' : 'Download Complete Project ZIP'}
            </div>
            <div style="font-size: 11px; color: #B45309; line-height: 1.35; margin-top: 2px;">
              ${isBn 
                ? 'Web + Android APK + iOS + Capacitor + Firebase Rules + Cloud Functions এর সম্পূর্ণ রেডি প্রজেক্ট জিপ ফাইল ডাউনলোড করুন।' 
                : 'Download ready-to-run ZIP archive with Web, Android, iOS and Firebase.'}
            </div>
          </div>
        </div>
        <a href="/bd-blood-donation.zip" download="bd-blood-donation.zip" id="btn-download-full-zip" class="btn btn-primary btn-block btn-sm" style="margin-top: 12px; background: #D97706; border-color: #D97706; text-decoration: none;">
          📥 ${isBn ? 'সম্পূর্ণ প্রজেক্ট জিপ ফাইল ডাউনলোড করুন' : 'Download bd-blood-donation.zip'}
        </a>
      </div>

      <!-- Developer Profile Card -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">👨‍💻 ${isBn ? 'ডেভেলপার তথ্য' : 'Developer Information'}</span>
        </div>
        <div style="display: flex; flex-direction: column; gap: 10px; font-size: 13px;">
          <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
            <span style="color: var(--text-muted);">${isBn ? 'ডেভেলপার' : 'Developer'}:</span>
            <span style="font-weight: 700; color: var(--text-main);">Ibna Mahmud Robin</span>
          </div>
          <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
            <span style="color: var(--text-muted);">${isBn ? 'ইমেইল যোগাযোগ' : 'Email'}:</span>
            <a href="mailto:robinokh@gmail.com" style="color: var(--primary-color); font-weight: 600; text-decoration: none;">robinokh@gmail.com</a>
          </div>
          <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
            <span style="color: var(--text-muted);">${isBn ? 'প্যাকেজ নাম' : 'Android Package'}:</span>
            <span style="font-family: monospace; font-size: 11px;">com.ibnamahmudrobin.bdblooddonation</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span style="color: var(--text-muted);">${isBn ? 'ফায়ারবেস প্রজেক্ট' : 'Firebase Project'}:</span>
            <span style="font-family: monospace; font-size: 11px;">bd-blood-dontion</span>
          </div>
        </div>
      </div>

      <!-- Privacy Policy & Terms -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">🛡️ ${isBn ? 'গোপনীয়তা ও ব্যবহারের শর্তাবলী' : 'Privacy & Terms'}</span>
        </div>
        <div style="font-size: 12px; color: var(--text-muted); line-height: 1.5; display: flex; flex-direction: column; gap: 8px;">
          <p>
            <strong>১. স্বেচ্ছাসেবী মানবিক উদ্যোগ:</strong> BD BLOOD DONATION একটি অলাভজনক ও মানবিক প্ল্যাটফর্ম। রক্তদানের জন্য কোনো আর্থিক লেনদেন সম্পূর্ণরূপে নিষিদ্ধ।
          </p>
          <p>
            <strong>২. তথ্য সুরক্ষা:</strong> নিবন্ধিত রক্তদাতাদের মোবাইল নম্বর শুধুমাত্র জরুরি রক্তদানের প্রয়োজনে যোগাযোগ করতে ব্যবহৃত হবে।
          </p>
          <p>
            <strong>৩. নিরাপত্তা ও জবাবদিহিতা:</strong> ভুয়া বা প্রতারণামূলক আবেদন করলে একাউন্ট স্থায়ীভাবে নিষিদ্ধ করা হবে।
          </p>
        </div>
      </div>
    </div>
  `;

  // Attach ZIP download button
  document.getElementById('btn-download-full-zip').addEventListener('click', async () => {
    await exportProjectZip();
  });
}
