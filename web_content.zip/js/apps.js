                                               
                                                                             
                                                                        
                                                                           
                                                                             

(function (S) {

    'use strict';

    var layer = null;

                                                
    var live = {};

                                                                                 
    var order = [];

    S.apps = {

        init: function () {
            layer = S.$('#appLayer');
        },

        has: function (appId) {
            return !!live[appId];
        },

        get: function (appId) {
            return live[appId] || null;
        },

                                                            
        recentIds: function () {
            return order.slice().reverse();
        },

                                                                      
        ensure: function (appId) {
            if (live[appId]) return live[appId];

            var app = S.APP[appId];
            if (!app) return null;

            var win = S.el('section', {
                className: 'app-window',
                dataset: { app: appId },
                style: '--app-accent:' + app.accent
            });

            var boot = S.el('div', { className: 'app-boot' }, [
                S.el('div', { className: 'app-boot__bar' }),
                S.el('div', { className: 'app-boot__ring' }),
                S.el('span', { text: 'abrindo ' + app.name })
            ]);

            var frame = S.el('iframe', {
                className: 'app-frame',
                title: app.name,
                attrs: { scrolling: 'no', allow: 'autoplay' }
            });

            win.appendChild(boot);
            win.appendChild(frame);
            layer.appendChild(win);

                                                                            
                                                                           
                                                   
            S.bridge.register(appId, frame.contentWindow);

            frame.addEventListener('load', function () {
                win.classList.add('is-ready');
            });

            frame.src = app.url;

            live[appId] = { app: app, window: win, frame: frame, ready: false };
            return live[appId];
        },

                                                                           
                                                        
        setState: function (appId, state) {
            return S.bridge.setState(appId, state);
        },

                                                                            
                                                                             
                                                             
        freeze: function (appId) {
            var entry = live[appId];
            if (!entry) return;
            entry.window.classList.add('is-frozen');
            S.bridge.setState(appId, 'paused');
        },

        unfreeze: function (appId) {
            var entry = live[appId];
            if (!entry) return;
            entry.window.classList.remove('is-frozen');
        },

                                                         
        touch: function (appId) {
            order = order.filter(function (id) { return id !== appId; });
            order.push(appId);
        },

                                                                           
                                                                    
        destroy: function (appId) {
            var entry = live[appId];
            if (!entry) return;

            S.bridge.unregister(appId);
            if (entry.frame.parentNode) entry.frame.parentNode.removeChild(entry.frame);
            if (entry.window.parentNode) entry.window.parentNode.removeChild(entry.window);
            delete live[appId];

            order = order.filter(function (id) { return id !== appId; });
        }

    };

})(window.Celular = window.Celular || {});
