/* يمكن هدف؟ — tactical engine: full tactical breakdown, goal replays, minute-by-minute state, prediction/xG explanations.
   Everything is computed locally from the match data (no external models). */
(function () {
  const { ai, viz, api } = YH; const esc = viz.esc; const AR = ai.AR;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const R = Math.round, pc = v => R(v * 100);
  const OPP = s => s === 'home' ? 'away' : 'home';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const f2 = v => (v || 0).toFixed(2);
  const shortN = n => { const p = (n || '').split(' ').filter(Boolean); return p.length > 1 ? p.slice(-1)[0] : (n || ''); };
  const q = sel => () => document.querySelector(sel);

  /* ---------- events (deduplicated plays) ---------- */
  const W8 = tt => /^goal|scored/.test(tt) ? 6 : /woodwork/.test(tt) ? 2.6 : /on-target/.test(tt) ? 2.4 : /penalty---(saved|missed)/.test(tt) ? 2.2 : /off-target/.test(tt) ? 1.1 : /blocked/.test(tt) ? 0.9 : /corner/.test(tt) ? 0.8 : /offside/.test(tt) ? 0.3 : 0;
  const evCache = new WeakMap();
  function events(sum) {
    if (evCache.has(sum)) return evCache.get(sum);
    const seen = new Set(), out = [];
    ai.plays(sum).forEach(p => {
      const tt = (p.type && p.type.type) || ''; const m = ai.minuteOf(p);
      const who = (p.participants || []).map(x => x.athlete && x.athlete.displayName).filter(Boolean);
      const key = tt + '|' + m + '|' + who.join(',');
      if (seen.has(key)) return; seen.add(key);
      out.push({ tt, side: ai.playTeamSide(sum, p), m, who, x: p.fieldPositionX, y: p.fieldPositionY, x2: p.fieldPosition2X, y2: p.fieldPosition2Y, text: p.text || p.raw || '' });
    });
    out.sort((a, b) => a.m - b.m); evCache.set(sum, out); return out;
  }
  function shotsOf(sum) {
    const ev = events(sum);
    return ai.shots(sum).map(s => {
      const e = ev.find(x => x.m === s.min && x.who[0] === s.who && /goal|shot|penalty/.test(x.tt));
      const dx = s.x != null ? (100 - s.x) * 1.05 : null, dy = s.y != null ? (s.y - 50) * 0.68 : null;
      const dist = dx != null ? Math.hypot(dx, dy) : null;
      const ang = dx != null ? Math.abs(Math.atan2(3.66 - dy, dx) - Math.atan2(-3.66 - dy, dx)) * 180 / Math.PI : null;
      return { ...s, ast: e && e.who[1] && !/penalty|foul/.test(e.tt) ? e.who[1] : null, header: /header/.test(s.type) || /header/i.test(s.text || ''), pen: /penalty/.test(s.type) || /penalty/i.test(s.text || ''), own: /own/.test(s.type), dist, ang };
    });
  }
  function share(ev, a, b) {
    let h = 0, w = 0;
    ev.forEach(e => { const k = W8(e.tt); if (!k || !e.side || e.m < a || e.m >= b) return; if (e.side === 'home') h += k; else w += k; });
    const t = h + w; return t ? { home: h / t, away: w / t, tot: t } : { home: 0.5, away: 0.5, tot: 0 };
  }
  const maxMinute = sum => Math.max(90, ...events(sum).map(e => Math.floor(e.m)));

  /* ---------- per-team tactical profile ---------- */
  function profile(sum, side) {
    const ts = ai.teamStats(sum); const me = ts[side] || {}, op = ts[OPP(side)] || {};
    const ev = events(sum); const sh = shotsOf(sum).filter(s => s.side === side && !s.own);
    const fouls = ev.filter(e => e.tt === 'foul' && e.side === side && e.x != null);
    const corners = ev.filter(e => /corner/.test(e.tt) && e.side === side);
    const sp = sh.filter(s => corners.some(c => s.min >= c.m && s.min - c.m <= 1.6));
    const xy = sh.filter(s => s.x != null);
    const inBox = xy.filter(s => s.x >= 84 && s.y >= 20 && s.y <= 80).length;
    const central = xy.filter(s => Math.abs(s.y - 50) <= 16).length;
    const P = (a, b) => b ? R(a / b * 100) : null;
    const xg = sh.reduce((a, s) => a + s.xg, 0);
    const half = h => { const l = sh.filter(s => h === 1 ? s.min < 46 : s.min >= 46); return { n: l.length, xg: l.reduce((a, s) => a + s.xg, 0) }; };
    return {
      side, ok: !!(me.totalPasses || sh.length), poss: me.possessionPct != null ? R(me.possessionPct) : null,
      passes: me.totalPasses || 0, passPct: P(me.accuratePasses || 0, me.totalPasses), long: me.totalLongBalls || 0, longAcc: P(me.accurateLongBalls || 0, me.totalLongBalls), longShare: P(me.totalLongBalls || 0, me.totalPasses),
      crosses: me.totalCrosses || 0, accCross: me.accurateCrosses || 0, crossPct: P(me.accurateCrosses || 0, me.totalCrosses),
      tackles: me.totalTackles || 0, effT: me.effectiveTackles || 0, inter: me.interceptions || 0, clear: me.totalClearance || 0, fouls: me.foulsCommitted != null ? me.foulsCommitted : fouls.length,
      foulX: fouls.length >= 2 ? fouls.reduce((a, e) => a + e.x, 0) / fouls.length : null,
      offs: me.offsides || 0, oppOffs: op.offsides || 0, corners: me.wonCorners != null ? me.wonCorners : corners.length,
      shots: me.totalShots != null ? me.totalShots : sh.length, onT: me.shotsOnTarget != null ? me.shotsOnTarget : sh.filter(s => s.onTarget).length,
      n: sh.length, xyN: xy.length, inBox, out: xy.length - inBox, central, dist: xy.length ? xy.reduce((a, s) => a + s.dist, 0) / xy.length : null,
      xg, xgps: sh.length ? xg / sh.length : 0, spShots: sp.length, spGoals: sp.filter(s => s.goal).length, pens: me.penaltyKickShots || 0,
      goals: sh.filter(s => s.goal).length, h1: half(1), h2: half(2), yc: me.yellowCards || 0, rc: me.redCards || 0, saves: me.saves || 0, sh,
    };
  }
  const buildStyle = p => p.poss != null && p.poss >= 58 ? { k: 'possession', t: 'استحواذ وبناء صبور من الخلف' } : p.longShare >= 20 ? { k: 'direct', t: 'لعب مباشر بالكرات الطويلة' } : p.poss != null && p.poss <= 42 ? { k: 'counter', t: 'ترك الكرة للخصم واعتمد على التحولات' } : { k: 'balanced', t: 'مزيج بين التمرير القصير والكرات الطويلة' };
  const pressStyle = p => p.foulX == null ? { k: 'balanced', t: 'دفاع متوازن' } : p.foulX >= 56 ? { k: 'press', t: 'ضغط عالي بنص ملعب الخصم' } : p.foulX >= 42 ? { k: 'balanced', t: 'ضغط متوسط من نص الملعب' } : { k: 'lowblock', t: 'دفاع منخفض قريب من مرماه' };
  const quality = x => x >= 0.14 ? 'فرص خطيرة وقريبة' : x >= 0.09 ? 'فرص متوسطة الخطورة' : 'تسديدات صعبة وأغلبها من بعيد';

  /* ---------- shared visuals ---------- */
  const fmtV = v => v == null ? '—' : (typeof v === 'number' && !Number.isInteger(v) ? v.toFixed(v < 10 ? 2 : 0) : v);
  function rowsHTML(rows, c, id) {
    return `<div class="tx-m">${rows.map((r, i) => { const h = r.h || 0, a = r.a || 0, tot = (h + a) || 1;
      return `<div class="tx-r" id="${id}_${i}"><b>${fmtV(r.h)}${r.h != null && r.u ? r.u : ''}</b><span>${esc(r.l)}</span><b>${fmtV(r.a)}${r.a != null && r.u ? r.u : ''}</b><div class="tx-bar"><i style="width:${(h / tot * 100).toFixed(1)}%;background:${c.home}"></i><i style="width:${(a / tot * 100).toFixed(1)}%;background:${c.away}"></i></div></div>`; }).join('')}</div>`;
  }
  const teamsHead = (ctx, note) => `<div class="tx-teams"><span style="--tc:${ctx.c.home}">${esc(AR(ctx.ev.home.name))}</span>${note ? `<small>${esc(note)}</small>` : ''}<span style="--tc:${ctx.c.away}">${esc(AR(ctx.ev.away.name))}</span></div>`;

  function rosterFor(ctx, s) {
    const rs = (ctx.sum.rosters || []).find(x => x.homeAway === s);
    if (rs && (rs.roster || []).some(p => p.starter)) return rs;
    const lm = s === 'home' ? ctx.lmH : ctx.lmA; return lm && lm.roster;
  }
  const tokensBoth = ctx => ['home', 'away'].flatMap(s => YH.studio.xi(rosterFor(ctx, s), s, s === 'home' ? ctx.ppH : ctx.ppA, ctx.c[s]));
  const nmAr = (ctx, n, s) => { if (!n) return ''; const r = api.personFor(s === 'away' ? ctx.ppA : ctx.ppH, { displayName: n }) || api.personFor(s === 'away' ? ctx.ppH : ctx.ppA, { displayName: n }); return (r && r.ar && /[\u0600-\u06FF]/.test(r.ar) ? r.ar : n).replace(/_/g, ' '); };

  /* a scene = metrics panel + tactics board (or another visual) */
  let sid = 0;
  function boardScene(ctx, { t, rows, note, vis, lines }) {
    const id = 'tx' + (++sid); const toks = vis ? [] : tokensBoth(ctx); const ref = { b: null };
    const visual = vis ? `<div class="tx-v">${vis}</div>` : toks.length > 12 ? `<div class="tx-b">${YH.studio.boardHTML(toks)}</div>` : '';
    const html = `<div class="tx ${visual ? '' : 'solo'}">${teamsHead(ctx, note)}${rowsHTML(rows, ctx.c, id)}${visual}</div>`;
    const L = lines({ row: i => () => document.getElementById(`${id}_${i}`), b: () => ref.b, has: () => !!ref.b });
    return { t, html, mount: root => { if (toks.length > 12) ref.b = YH.studio.Board(root, toks); }, lines: L };
  }
  const mv = (H, k, s) => () => { const b = H.b(); if (b && b.moves[k]) { const r = b.moves[k](s); return r; } };
  const both = (H, k1, s1, k2, s2) => async () => { const b = H.b(); if (!b) return; b.reset(); if (b.moves[k2]) await b.moves[k2](s2); if (b.moves[k1]) b.moves[k1](s1); };

  /* ---------- full tactical breakdown ---------- */
  function deepScenes(ctx) {
    const { ev, sum, mode, lmH, lmA } = ctx;
    const T = s => AR(ev[s].name);
    const pre = mode === 'pre';
    let pH, pA, note = '';
    if (pre) {
      if (!lmH || !lmA) return [];
      pH = profile(lmH.sum, lmH.side); pA = profile(lmA.sum, lmA.side); note = 'آخر مباراة لكل فريق'; pH.side = 'home'; pA.side = 'away';
    } else { pH = profile(sum, 'home'); pA = profile(sum, 'away'); }
    if (!pH.ok || !pA.ok) return [];
    const p = s => s === 'home' ? pH : pA;
    const lead = s => pre ? `بآخر مباراة، ${T(s)}` : T(s);
    const out = [];
    const res = pre ? null : (ev.home.score > ev.away.score ? 'home' : ev.away.score > ev.home.score ? 'away' : 'draw');

    /* 1. build-up */
    out.push(boardScene(ctx, { t: 'البناء والاستحواذ', note, rows: [{ l: 'الاستحواذ', h: pH.poss, a: pA.poss, u: '%' }, { l: 'التمريرات', h: pH.passes, a: pA.passes }, { l: 'دقة التمرير', h: pH.passPct, a: pA.passPct, u: '%' }, { l: 'الكرات الطويلة', h: pH.long, a: pA.long }],
      lines: H => {
        const L = ['home', 'away'].map((s, i) => { const x = p(s), st = buildStyle(x);
          return { t: `${i ? 'أما ' : 'نبدأ بالبناء. '}${lead(s)} ${x.poss != null ? `استحوذ ${x.poss} بالمية و` : ''}لعب ${x.passes} تمريرة بدقة ${x.passPct || 0} بالمية، و${x.longShare || 0} بالمية منها كرات طويلة. يعني ${st.t}.`, at: H.row(i ? 1 : 0), act: mv(H, st.k, s) }; });
        const big = (pH.poss || 50) >= (pA.poss || 50) ? 'home' : 'away', sm = OPP(big), d = Math.abs((pH.poss || 50) - (pA.poss || 50));
        let c = d >= 15 ? `الفارق كبير: ${T(big)} لعب على الكرة، و${T(sm)} ${p(sm).longShare >= 20 ? 'رمى كرات طويلة يتجاوز بيها الضغط' : 'دافع ينتظر فرصته'}.` : `الاستحواذ متقارب، والمعركة كانت بنص الملعب.`;
        if (res) c += res === big ? ' والاستحواذ ترجم لسيطرة ونتيجة.' : ' بس الاستحواذ ما ترجم لفوز، والكرة بدون خطورة ما تكفي.';
        L.push({ t: c, at: q('.tx-b .tb'), act: mv(H, buildStyle(p(big)).k, big) });
        return L;
      } }));

    /* 2. pressing & defence */
    out.push(boardScene(ctx, { t: 'الضغط والدفاع', note, rows: [{ l: 'التدخلات', h: pH.tackles, a: pA.tackles }, { l: 'الكرات المقطوعة', h: pH.inter, a: pA.inter }, { l: 'الأخطاء', h: pH.fouls, a: pA.fouls }, { l: 'التشتيت', h: pH.clear, a: pA.clear }],
      lines: H => {
        const L = ['home', 'away'].map((s, i) => { const x = p(s), st = pressStyle(x);
          return { t: `${lead(s)} لعب ${st.t}: ${x.tackles} تدخل و${x.inter} كرة مقطوعة${x.foulX != null ? `، ومعدل مكان أخطائه على بعد ${R(x.foulX * 1.05)} متر من مرماه` : ''}.`, at: H.row(i ? 1 : 0), act: mv(H, st.k, s) }; });
        const hi = (pH.foulX || 0) >= (pA.foulX || 0) ? 'home' : 'away';
        const cl = pH.clear >= pA.clear ? 'home' : 'away';
        let c = `${T(hi)} ضغط أعلى من ${T(OPP(hi))}.`;
        if (p(cl).clear >= 20 && p(cl).clear >= p(OPP(cl)).clear * 1.5) c += ` و${T(cl)} شتّت ${p(cl).clear} كرة، رقم يبيّن قد إيش انضغط بمنطقته.`;
        const ho = pH.oppOffs >= pA.oppOffs ? 'home' : 'away';
        if (p(ho).oppOffs >= 3) c += ` وخط دفاع ${T(ho)} كان متقدم، وأوقع الخصم بالتسلل ${p(ho).oppOffs} مرات.`;
        L.push({ t: c, at: H.row(3), act: mv(H, p(ho).oppOffs >= 3 ? 'highline' : 'press', p(ho).oppOffs >= 3 ? ho : hi) });
        return L;
      } }));

    /* 3. wide play vs central */
    out.push(boardScene(ctx, { t: 'الأطراف أو العمق', note, rows: [{ l: 'العرضيات', h: pH.crosses, a: pA.crosses }, { l: 'عرضيات ناجحة', h: pH.accCross, a: pA.accCross }, { l: 'تسديد من العمق', h: pH.central, a: pA.central }],
      lines: H => {
        const L = ['home', 'away'].map((s, i) => { const x = p(s); const wide = x.crosses >= 15 || (x.xyN && x.central < x.xyN / 2);
          return { t: `${lead(s)} لعب ${x.crosses} عرضية، وصل منها ${x.accCross}${x.crossPct != null ? `، يعني ${x.crossPct} بالمية` : ''}. ${x.xyN ? (x.central >= x.xyN / 2 ? `وأغلب تسديداته، ${x.central} من ${x.xyN}، جت من العمق.` : `ومحاولاته كانت أكثر من الأطراف.`) : ''}`, at: H.row(i ? 2 : 0), act: mv(H, wide ? 'wide' : 'attack', s) }; });
        const w = pH.crosses >= pA.crosses ? 'home' : 'away';
        L.push({ t: `${T(w)} اعتمد على الأطراف أكثر، ${p(w).crossPct != null && p(w).crossPct < 30 ? 'بس العرضيات ما كانت دقيقة، والمدافعين ربحوا أغلب الكرات العالية' : 'والعرضيات كانت مصدر خطر حقيقي'}.`, at: H.row(1), act: mv(H, 'wide', w) });
        return L;
      } }));

    /* 4. long balls & transitions */
    out.push(boardScene(ctx, { t: 'الكرات الطويلة والتحولات', note, rows: [{ l: 'الكرات الطويلة', h: pH.long, a: pA.long }, { l: 'دقة الطويلة', h: pH.longAcc, a: pA.longAcc, u: '%' }, { l: 'التسلل', h: pH.offs, a: pA.offs }],
      lines: H => {
        const L = ['home', 'away'].map((s, i) => { const x = p(s);
          return { t: `${lead(s)} لعب ${x.long} كرة طويلة، نجح منها ${x.longAcc || 0} بالمية.${x.offs >= 3 ? ` ووقع بالتسلل ${x.offs} مرات، يعني مهاجميه يحاولون يهربون ورا الدفاع.` : x.offs ? ` ووقع بالتسلل ${x.offs} ${x.offs === 1 ? 'مرة' : 'مرات'}.` : ''}`, at: H.row(i ? 1 : 0), act: mv(H, x.longShare >= 20 || x.offs >= 3 ? 'counter' : 'direct', s) }; });
        const d = (pH.longShare || 0) >= (pA.longShare || 0) ? 'home' : 'away';
        L.push({ t: `اللي يلعب طويل يتجاوز الضغط بسرعة، بس يخسر الكرة أكثر. ${T(d)} ضيّع ${100 - (p(d).longAcc || 0)} بالمية من كراته الطويلة.`, at: H.row(1), act: mv(H, 'counter', d) });
        return L;
      } }));

    /* 5. shot zones & chance quality */
    const shMap = side => p(side).sh.map(s => ({ ...s, side }));
    out.push(boardScene(ctx, { t: 'مناطق التسديد وجودة الفرص', note, vis: `<div class="tx-shots">${viz.shotMap([...shMap('home'), ...shMap('away')], ctx.c)}</div>`,
      rows: [{ l: 'التسديدات', h: pH.n, a: pA.n }, { l: 'من داخل الصندوق', h: pH.inBox, a: pA.inBox }, { l: 'xG', h: +f2(pH.xg), a: +f2(pA.xg) }],
      lines: H => {
        const L = ['home', 'away'].map((s, i) => { const x = p(s);
          return { t: `${lead(s)} سدد ${x.n} ${x.n === 1 ? 'مرة' : 'مرات'}: ${x.inBox} من داخل الصندوق و${x.out} من بعيد${x.dist ? `، ومعدل المسافة ${R(x.dist)} متر` : ''}. قيمة الفرصة الوحدة ${f2(x.xgps)} إكس جي، يعني ${quality(x.xgps)}.`, at: H.row(i ? 1 : 0) }; });
        const b = pH.xg >= pA.xg ? 'home' : 'away';
        L.push({ t: `بالمجموع ${T(b)} صنع فرص قيمتها ${f2(p(b).xg)} مقابل ${f2(p(OPP(b)).xg)}. ${p(b).inBox > p(OPP(b)).inBox ? 'الفرق جاي من الوصول لداخل الصندوق، مو من عدد التسديدات بس.' : 'الفرق بالجودة مو بالعدد.'}`, at: q('.tx-shots .is-goal') });
        return L;
      } }));

    /* 6. set pieces */
    out.push(boardScene(ctx, { t: 'الكرات الثابتة', note, rows: [{ l: 'الركنيات', h: pH.corners, a: pA.corners }, { l: 'تسديد بعد ركنية', h: pH.spShots, a: pA.spShots }, { l: 'ضربات الجزاء', h: pH.pens, a: pA.pens }],
      lines: H => ['home', 'away'].map((s, i) => { const x = p(s);
        return { t: `${lead(s)} حصل ${x.corners} ${x.corners === 1 ? 'ركنية' : 'ركنيات'}، وطلع منها ${x.spShots} ${x.spShots === 1 ? 'تسديدة' : 'تسديدات'} خلال دقيقتين${x.spGoals ? ` وهدف` : ''}.${x.pens ? ` وحصل ${x.pens === 1 ? 'ضربة جزاء' : x.pens + ' ضربات جزاء'}.` : ''} ${x.corners >= 6 ? 'الركنيات سلاح مهم عنده.' : ''}`, at: H.row(i ? 1 : 0), act: mv(H, 'setpiece', s) }; }) }));

    if (!pre) {
      const evs = events(sum); const mx = maxMinute(sum);
      /* 7. halves */
      const s1 = share(evs, 0, 46), s2 = share(evs, 46, 200);
      if (ev.state === 'post' || mx >= 55) {
        const dom = s => s.home > 0.58 ? 'home' : s.away > 0.58 ? 'away' : null;
        const htSubs = evs.filter(e => e.tt === 'substitution' && e.m >= 45 && e.m < 47);
        const red = evs.find(e => /red-card/.test(e.tt));
        const goalsBy = (a, b) => shotsOf(sum).filter(s => s.goal && s.min >= a && s.min < b);
        out.push(boardScene(ctx, { t: 'الشوط الأول والثاني', vis: `<div class="tx-mom">${viz.momentumChart(ai.momentum(sum), ctx.c, ai.analyze(sum).goals, { W: 640, Hh: 150 })}</div>`,
          rows: [{ l: 'تسديد ش1', h: pH.h1.n, a: pA.h1.n }, { l: 'تسديد ش2', h: pH.h2.n, a: pA.h2.n }, { l: 'أفضلية ش1', h: pc(s1.home), a: pc(s1.away), u: '%' }, { l: 'أفضلية ش2', h: pc(s2.home), a: pc(s2.away), u: '%' }],
          lines: H => {
            const d1 = dom(s1), d2 = dom(s2), g1 = goalsBy(0, 46), g2 = goalsBy(46, 200);
            const L = [{ t: `بالشوط الأول ${d1 ? `الأفضلية كانت لـ${T(d1)} بنسبة ${pc(s1[d1])} بالمية من الضغط الهجومي` : 'كان متوازن'}. ${T('home')} سدد ${pH.h1.n} و${T('away')} ${pA.h1.n}${g1.length ? `، وانسجل ${g1.length === 1 ? 'هدف' : g1.length + ' أهداف'}` : ''}.`, at: H.row(0) }];
            let why = '';
            if (red && red.m < 46 && d1 === OPP(red.side)) why = ` الطرد بالدقيقة ${Math.floor(red.m)} سهّل المهمة.`;
            L.push({ t: `بعد الاستراحة ${d2 ? (d2 === d1 ? `${T(d2)} كمّل سيطرته بنسبة ${pc(s2[d2])} بالمية` : `انقلبت الصورة و${T(d2)} صار الأفضل بنسبة ${pc(s2[d2])} بالمية`) : (d1 ? `${T(OPP(d1))} رجع للمباراة وصار الشوط متوازن` : 'بقى الشوط متوازن')}. ${T('home')} سدد ${pH.h2.n} و${T('away')} ${pA.h2.n}${g2.length ? `، وانسجل ${g2.length === 1 ? 'هدف' : g2.length + ' أهداف'}` : ''}.${why}`, at: H.row(1) });
            if (htSubs.length) { const bySide = s => htSubs.filter(e => e.side === s); const s0 = bySide('home').length >= bySide('away').length ? 'home' : 'away';
              L.push({ t: `وبالاستراحة ${T(s0)} سوّى ${bySide(s0).length === 1 ? 'تبديل' : bySide(s0).length + ' تبديلات'}: دخل ${bySide(s0).map(e => nmAr(ctx, e.who[0], s0)).join(' و')}، ${d2 === s0 && d1 !== s0 ? 'والتغيير نفع واضح' : 'حتى يغيّر شكل الفريق'}.`, at: H.row(3) }); }
            return L;
          } }));
      }
      /* 8. substitutions */
      const subs = evs.filter(e => e.tt === 'substitution' && e.side && e.who.length);
      if (subs.length) {
        const groups = []; subs.forEach(e => { const g = groups.find(x => x.side === e.side && Math.abs(x.m - e.m) <= 3); if (g) g.l.push(e); else groups.push({ side: e.side, m: e.m, l: [e] }); });
        const eff = groups.map(g => { const b = share(evs, Math.max(0, g.m - 12), g.m), a = share(evs, g.m + 0.01, Math.min(mx + 1, g.m + 14)); return { ...g, before: b[g.side], after: a[g.side], tot: a.tot }; });
        const best = eff.slice().sort((x, y) => (y.after - y.before) - (x.after - x.before));
        const pick = [...new Set([best[0], ...eff.filter(g => g.side === 'home').slice(0, 1), ...eff.filter(g => g.side === 'away').slice(0, 1)])].filter(Boolean).slice(0, 3);
        const list = `<ul class="tx-subs">${eff.slice(0, 6).map((g, i) => `<li id="txs${i}" style="--tc:${ctx.c[g.side]}"><b dir="ltr">${Math.floor(g.m)}'</b><span>${esc(g.l.map(e => shortN(nmAr(ctx, e.who[0], g.side))).join('، '))}</span><small>قبل ${pc(g.before)}% · بعد ${pc(g.after)}%</small></li>`).join('')}</ul>`;
        out.push(boardScene(ctx, { t: 'التبديلات وتأثيرها', vis: list, rows: [{ l: 'التبديلات', h: subs.filter(e => e.side === 'home').length, a: subs.filter(e => e.side === 'away').length }],
          lines: () => {
            const L = [{ t: `التبديلات تكشف تفكير المدرب. أقارن الضغط الهجومي للفريق ربع ساعة قبل التبديل وربع ساعة بعده.`, at: q('.tx-subs') }];
            pick.forEach(g => { const i = eff.indexOf(g); const d = g.after - g.before;
              L.push({ t: `بالدقيقة ${Math.floor(g.m)} ${T(g.side)} دخّل ${g.l.map(e => nmAr(ctx, e.who[0], g.side)).join(' و')}${g.l[0].who[1] ? ` بدال ${g.l.map(e => nmAr(ctx, e.who[1], g.side)).join(' و')}` : ''}. قبلها كان عنده ${pc(g.before)} بالمية، وبعدها ${pc(g.after)} بالمية، ${d > 0.12 ? 'يعني التبديل نفع وقلب الضغط' : d < -0.12 ? 'بس الفريق تراجع بعده' : 'وما غيّر كثير'}.`, at: q('#txs' + i) }); });
            return L;
          } }));
      }
      /* 9. red card impact */
      const red = evs.find(e => /red-card/.test(e.tt) && e.side);
      if (red) {
        const b = share(evs, 0, red.m), a = share(evs, red.m + 0.01, mx + 1); const o = OPP(red.side);
        const shA = shotsOf(sum).filter(s => s.min > red.m);
        out.push(boardScene(ctx, { t: 'تأثير الطرد', rows: [{ l: 'الأفضلية قبل الطرد', h: pc(b.home), a: pc(b.away), u: '%' }, { l: 'الأفضلية بعد الطرد', h: pc(a.home), a: pc(a.away), u: '%' }, { l: 'تسديد بعد الطرد', h: shA.filter(s => s.side === 'home').length, a: shA.filter(s => s.side === 'away').length }],
          lines: H => [
            { t: `بالدقيقة ${Math.floor(red.m)} طرد ${nmAr(ctx, red.who[0], red.side)} من ${T(red.side)}، وهذا غيّر الخطة كلها.`, at: H.row(0), act: mv(H, 'lowblock', red.side) },
            { t: `قبل الطرد ${T(o)} كان عنده ${pc(b[o])} بالمية من الضغط، وبعده صار ${pc(a[o])} بالمية. ${T(red.side)} نزل لكتلة منخفضة يدافع بعشرة.`, at: H.row(1), act: both(H, 'attack', o, 'lowblock', red.side) },
            { t: `${T(o)} سدد ${shA.filter(s => s.side === o).length} مرات بعد الطرد، مقابل ${shA.filter(s => s.side === red.side).length} لـ${T(red.side)}.`, at: H.row(2), act: mv(H, 'possession', o) },
          ] }));
      }
    }

    /* 10. tactical summary / key of the match-up */
    const keys = pre ? clashKeys(ctx, pH, pA) : summaryKeys(ctx, pH, pA);
    out.push({ t: pre ? 'مفتاح المواجهة' : 'الخلاصة التكتيكية', html: `<ol class="tx-keys">${keys.map((k, i) => `<li id="txk${i}" style="--tc:${k.s ? ctx.c[k.s] : 'var(--gold)'}">${esc(k.t)}</li>`).join('')}</ol>`, lines: keys.map((k, i) => ({ t: k.t, at: q('#txk' + i) })) });
    return out;
  }

  function summaryKeys(ctx, pH, pA) {
    const { ev, sum } = ctx; const T = s => AR(ev[s].name); const p = s => s === 'home' ? pH : pA; const keys = [];
    const evs = events(sum); const red = evs.find(e => /red-card/.test(e.tt) && e.side);
    if (red) keys.push({ s: OPP(red.side), t: `الطرد بالدقيقة ${Math.floor(red.m)} خلّى ${T(red.side)} يلعب ناقص، و${T(OPP(red.side))} استغل التفوق العددي.` });
    const pb = (pH.poss || 50) >= (pA.poss || 50) ? 'home' : 'away';
    keys.push({ s: pb, t: `${T(pb)} سيطر على الكرة بـ${p(pb).poss || '—'} بالمية ودقة تمرير ${p(pb).passPct || 0} بالمية، و${T(OPP(pb))} لعب ${buildStyle(p(OPP(pb))).t}.` });
    const xb = pH.xg >= pA.xg ? 'home' : 'away';
    keys.push({ s: xb, t: `جودة الفرص لـ${T(xb)}: ${f2(p(xb).xg)} إكس جي مقابل ${f2(p(OPP(xb)).xg)}، و${p(xb).inBox} تسديدات من داخل الصندوق.` });
    const sp = ['home', 'away'].find(s => p(s).spGoals || (p(s).pens && p(s).goals));
    if (sp) keys.push({ s: sp, t: `الكرات الثابتة فرقت: ${T(sp)} سجّل من ${p(sp).spGoals ? 'ركنية' : 'ضربة جزاء'}.` });
    const hi = (pH.foulX || 0) >= (pA.foulX || 0) ? 'home' : 'away';
    keys.push({ s: hi, t: `${T(hi)} ضغط أعلى، و${T(OPP(hi))} ${p(OPP(hi)).clear >= 20 ? `اضطر يشتت ${p(OPP(hi)).clear} كرة` : 'ما گدر يبني بهدوء'}.` });
    return keys.slice(0, 5);
  }
  function clashKeys(ctx, pH, pA) {
    const T = s => AR(ctx.ev[s].name); const p = s => s === 'home' ? pH : pA; const keys = [];
    const bh = buildStyle(pH), ba = buildStyle(pA), ph = pressStyle(pH), pa = pressStyle(pA);
    if (bh.k === 'possession' && (ba.k === 'counter' || ba.k === 'direct')) keys.push({ s: 'away', t: `${T('home')} يحب الكرة و${T('away')} يلعب ${ba.t}: المساحات ورا دفاع ${T('home')} راح تكون المفتاح.` });
    else if (ba.k === 'possession' && (bh.k === 'counter' || bh.k === 'direct')) keys.push({ s: 'home', t: `${T('away')} يحب الكرة و${T('home')} يلعب ${bh.t}: المرتدات راح تكون سلاح ${T('home')}.` });
    else keys.push({ s: null, t: `أسلوب ${T('home')}: ${bh.t}. وأسلوب ${T('away')}: ${ba.t}.` });
    if (ph.k === 'press' && pA.passes > 400) keys.push({ s: 'home', t: `ضغط ${T('home')} العالي ضد بناء ${T('away')} من الخلف: أي خطأ بنص الملعب ممكن يصير هدف.` });
    else if (pa.k === 'press' && pH.passes > 400) keys.push({ s: 'away', t: `ضغط ${T('away')} العالي ضد بناء ${T('home')}: الهروب من الضغط الأول راح يحدد مين يسيطر.` });
    else keys.push({ s: null, t: `بالدفاع: ${T('home')} ${ph.t}، و${T('away')} ${pa.t}.` });
    const cr = pH.crosses >= pA.crosses ? 'home' : 'away';
    if (p(cr).crosses >= 15) keys.push({ s: cr, t: `${T(cr)} يعتمد على العرضيات (${p(cr).crosses} بآخر مباراة)، والكرات العالية راح تختبر دفاع ${T(OPP(cr))}.` });
    const co = pH.corners >= pA.corners ? 'home' : 'away';
    if (p(co).corners >= 5) keys.push({ s: co, t: `انتبهوا للركنيات: ${T(co)} حصل ${p(co).corners} بآخر مباراة.` });
    const xb = pH.xgps >= pA.xgps ? 'home' : 'away';
    keys.push({ s: xb, t: `${T(xb)} يصنع فرص أخطر بالتسديدة الوحدة (${f2(p(xb).xgps)} إكس جي مقابل ${f2(p(OPP(xb)).xgps)}).` });
    return keys.slice(0, 5);
  }

  /* ---------- tactical goal replay (approximate reconstruction) ---------- */
  function replayScenes(ctx, only) {
    const { ev, sum, c } = ctx; if (ctx.mode === 'pre') return [];
    const T = s => AR(ev[s].name);
    const goals = shotsOf(sum).filter(s => s.goal && !s.own).sort((a, b) => a.min - b.min);
    let gh = 0, ga = 0;
    const list = goals.map(g => { if (g.side === 'home') gh++; else ga++; return { g, sc: [gh, ga] }; });
    const pick = only != null ? list.filter((x, i) => i === only) : list.slice(0, 3);
    return pick.map(({ g, sc }) => {
      const toks = tokensBoth(ctx); const s = g.side, o = OPP(s); const ref = { b: null, root: null };
      const idx = list.findIndex(x => x.g === g);
      const ordinal = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس'][idx] || '';
      const shAr = nmAr(ctx, g.who, s), asAr = g.ast ? nmAr(ctx, g.ast, s) : '';
      // board coordinates: home attacks to the left (x -> 100 - X, y -> 100 - Y)
      const bx = X => s === 'home' ? 100 - X : X, by = Y => s === 'home' ? 100 - Y : Y;
      const X = g.pen ? 88.5 : g.x != null ? g.x : 86, Y = g.pen ? 50 : g.y != null ? g.y : 50;
      const wideAst = g.header;
      const aX = wideAst ? 90 : clamp(X - 17, 52, 84), aY = wideAst ? (Y < 50 ? 88 : 12) : clamp(50 + (Y - 50) * 0.4 + (Y < 50 ? 14 : -14), 15, 85);
      const gY = clamp(g.gy != null ? g.gy : 50, 45, 55);
      const find = (en, pool) => en && (pool.find(t => t.en === en) || pool.find(t => shortN(t.en) === shortN(en)));
      const html = `<div class="rp2"><div class="rp2-h"><span style="--tc:${c[s]}">${esc(T(s))}</span><b dir="ltr">${sc[0]} - ${sc[1]}</b><small>الدقيقة ${Math.floor(g.min)} · إعادة تقريبية من مكان التسديدة وصانع اللعب</small></div><div class="tx-b">${YH.studio.boardHTML(toks)}</div></div>`;
      let shooter, assister;
      const prep = () => {
        const B = ref.b; if (!B) return;
        const mine = B.team(s), fw = B.fws(s);
        const dist = t => Math.hypot(t.x0 - bx(X), t.y0 - by(Y));
        shooter = find(g.who, mine) || fw.slice().sort((a, b) => dist(a) - dist(b))[0] || mine[mine.length - 1];
        assister = g.ast ? (find(g.ast, mine.filter(t => t !== shooter)) || B.rowOf(s, Math.max(1, B.last(s) - 1)).find(t => t !== shooter)) : null;
        const relabel = (t, en, ar) => { if (!t || t.en === en) return; const e = B.el(t); if (!e) return; const n = e.querySelector('.tk-n'); if (n) n.textContent = shortN(ar); const im = e.querySelector('img'); const rec = api.personFor(s === 'home' ? ctx.ppH : ctx.ppA, { displayName: en }); if (im) { if (rec && rec.img) im.src = rec.img; else im.remove(); } const i = e.querySelector('.tk-face i'); if (i) i.textContent = ''; };
        relabel(shooter, g.who, shAr); if (assister) relabel(assister, g.ast, asAr);
      };
      const putBall = (x, y) => { const b = ref.b && ref.b.ball; if (!b) return; b.classList.add('on'); b.style.left = x + '%'; b.style.top = y + '%'; };
      const lines = [
        { t: `خلّونا نعيد الهدف ${ordinal} خطوة بخطوة. الدقيقة ${Math.floor(g.min)}، ${T(s)} ${g.pen ? 'حصل ضربة جزاء' : 'يبني الهجمة'}، و${T(o)} يرجع يدافع.`, at: q('.rp2 .tb'),
          act: async () => { const B = ref.b; if (!B) return; ref.root.querySelector('.tb').classList.remove('goal'); B.reset(); prep(); B.moves.lowblock(o); B.team(s).forEach(t => { if (t.row) B.set(t, t.x0 + (s === 'home' ? -16 : 16), t.y0); }); const mid = B.rowOf(s, 2)[0] || B.rowOf(s, 1)[0]; await sleep(500); if (mid) B.ballTo(mid); } },
        g.pen ? { t: `${shAr} وقف على نقطة الجزاء. الخطأ صار داخل المنطقة، وهاي أخطر هدية تقدمها لخصمك.`, at: () => ref.b && shooter && ref.b.el(shooter), act: () => { const B = ref.b; if (!B || !shooter) return; B.set(shooter, bx(88.5) + (s === 'home' ? 2 : -2), 50); putBall(bx(88.5), 50); } }
          : assister ? { t: `الكرة وصلت لـ${asAr}، ${wideAst ? 'وراح للطرف قريب من خط النهاية ورفع عرضية' : 'ومرّر كرة بين الخطوط'} لـ${shAr}.`, at: () => ref.b && assister && ref.b.el(assister),
            act: async () => { const B = ref.b; if (!B || !assister) return; B.set(assister, bx(aX), by(aY)); await sleep(900); B.ballTo(assister); await sleep(700); B.arrow(assister.x, assister.y, bx(X), by(Y), c[s]); } }
          : { t: `${shAr} استلم الكرة ودخل بيها بنفسه، بدون صانع لعب.`, at: () => ref.b && shooter && ref.b.el(shooter), act: async () => { const B = ref.b; if (!B || !shooter) return; B.set(shooter, bx(clamp(X - 12, 50, 90)), by(Y)); await sleep(700); B.ballTo(shooter); } },
        { t: `${shAr} ${g.pen ? 'سدد ضربة الجزاء' : `سدد ${g.header ? 'بضربة رأس ' : ''}من ${R(g.dist || 11)} متر`}، والفرصة قيمتها ${f2(g.xg)} إكس جي. و… گووول.`, at: () => ref.b && shooter && ref.b.el(shooter),
          act: async () => { const B = ref.b; if (!B || !shooter) return; B.set(shooter, bx(X), by(Y)); await sleep(1000); B.ballTo(shooter); await sleep(500); B.arrow(shooter.x, shooter.y, s === 'home' ? 1.5 : 98.5, by(gY), '#c6ff3d'); YH.sfx && YH.sfx.arrow(); await sleep(450); putBall(s === 'home' ? 1.2 : 98.8, by(gY)); await sleep(500); YH.sfx && YH.sfx.goal(); const tb = ref.root.querySelector('.tb'); if (tb) tb.classList.add('goal'); } },
        { t: g.pen ? `الدرس: التدخل داخل الصندوق لازم يكون محسوب، لأن ضربة الجزاء تدخل ثلاث مرات من كل أربعة.`
          : g.header ? `الخطأ الدفاعي: ما كو رقابة على ${shAr} بالكرة العالية، والمدافع ما گدر يوصلها قبله.`
          : (g.x != null && g.x >= 84) ? `الخطأ الدفاعي: ${T(o)} ترك مساحة بقلب الصندوق، و${shAr} لگى نفسه بدون ضغط.`
          : `الخطأ الدفاعي: ما كو ضغط على المسدد من بعيد، و${T(o)} وقف يتفرج على التسديدة.`, at: q('.rp2 .tb') },
      ];
      return { t: `إعادة الهدف ${ordinal}`, goal: { who: g.who, ar: shAr, side: s, min: g.min }, art: 'goal', html, mount: root => { ref.root = root; if (toks.length > 12) ref.b = YH.studio.Board(root, toks); }, lines };
    }).filter(sc => sc.html.includes('tk_'));
  }

  /* ---------- match state at a given minute ---------- */
  function stateAt(ctx, m) {
    const { sum, ev } = ctx; const evs = events(sum); const T = s => AR(ev[s].name);
    const sh = shotsOf(sum).filter(s => s.min <= m);
    const goals = sh.filter(s => s.goal); const g = { home: 0, away: 0 };
    goals.forEach(x => { if (x.own) g[OPP(x.side)]++; else g[x.side]++; });
    const cnt = (s, re) => evs.filter(e => e.side === s && e.m <= m && re.test(e.tt)).length;
    const st = s => ({ shots: sh.filter(x => x.side === s).length, onT: sh.filter(x => x.side === s && x.onTarget).length, xg: sh.filter(x => x.side === s).reduce((a, x) => a + x.xg, 0), corners: cnt(s, /corner/), fouls: cnt(s, /^foul$/), yc: cnt(s, /yellow/), rc: cnt(s, /red-card/) });
    const H = st('home'), A = st('away'); const last = share(evs, Math.max(0, m - 10), m + 0.01);
    const key = evs.filter(e => e.m <= m && e.m >= m - 15 && (/^goal|scored|red-card|substitution|penalty---|woodwork/.test(e.tt)) && e.side).slice(-3);
    const desc = e => /^goal|scored/.test(e.tt) ? `هدف ${T(e.side)} عن طريق ${nmAr(ctx, e.who[0], e.side)} بالدقيقة ${Math.floor(e.m)}` : /red/.test(e.tt) ? `طرد ${nmAr(ctx, e.who[0], e.side)} من ${T(e.side)} بالدقيقة ${Math.floor(e.m)}` : /substitution/.test(e.tt) ? `تبديل ${T(e.side)}: دخل ${nmAr(ctx, e.who[0], e.side)}` : /woodwork/.test(e.tt) ? `كرة بالقائم لـ${T(e.side)}` : `ضربة جزاء ضايعة لـ${T(e.side)}`;
    const dom = last.tot ? (last.home > 0.6 ? 'home' : last.away > 0.6 ? 'away' : null) : null;
    const lead = g.home > g.away ? 'home' : g.away > g.home ? 'away' : null;
    const redS = ['home', 'away'].find(s => (s === 'home' ? H : A).rc);
    let read = '';
    if (redS) read = `${T(redS)} يلعب ناقص، و${T(OPP(redS))} لازم يستغل التفوق العددي بتدوير الكرة.`;
    else if (lead && dom && dom !== lead) read = `${T(lead)} متقدم بس ${T(dom)} هو اللي يضغط هسه، والهدف ممكن يجي بأي لحظة.`;
    else if (lead) read = `${T(lead)} متقدم ومسيطر، و${T(OPP(lead))} لازم يخاطر ويتقدم.`;
    else if (dom) read = `النتيجة متعادلة بس ${T(dom)} الأقرب للتسجيل حسب آخر دقائق.`;
    else read = 'المباراة مقفولة تكتيكياً، والفريقين حذرين.';
    const text = `بالدقيقة ${Math.floor(m)}، النتيجة ${T('home')} ${g.home} و${T('away')} ${g.away}. لحد هاي اللحظة ${T('home')} سدد ${H.shots}، منها ${H.onT} على المرمى، و${T('away')} سدد ${A.shots}، منها ${A.onT}. ${last.tot ? (dom ? `بآخر عشر دقائق الأفضلية لـ${T(dom)} بنسبة ${pc(last[dom])} بالمية.` : 'آخر عشر دقائق كانت متوازنة.') : 'آخر عشر دقائق كانت هادئة بدون فرص.'}`;
    return { m, g, H, A, last, key, keyTxt: key.map(desc), read, text };
  }
  function minuteScene(ctx, m) {
    const S = stateAt(ctx, m); const { c } = ctx; const mom = ai.momentum(ctx.sum); const n = mom.length;
    const pos = clamp((1 - (m / 5) / Math.max(1, n - 1)) * 100, 0, 100);
    const rows = [{ l: 'التسديدات', h: S.H.shots, a: S.A.shots }, { l: 'على المرمى', h: S.H.onT, a: S.A.onT }, { l: 'xG', h: +f2(S.H.xg), a: +f2(S.A.xg) }, { l: 'الركنيات', h: S.H.corners, a: S.A.corners }];
    const id = 'mn' + (++sid);
    const html = `<div class="mn"><div class="mn-h"><b class="mn-m" dir="ltr">${Math.floor(m)}'</b><b class="mn-s" dir="ltr">${S.g.home} - ${S.g.away}</b>${S.keyTxt.length ? `<small>${esc(S.keyTxt[S.keyTxt.length - 1])}</small>` : ''}</div>${teamsHead(ctx)}${rowsHTML(rows, c, id)}<div class="mn-mom">${viz.momentumChart(mom, c, ai.analyze(ctx.sum).goals, { W: 640, Hh: 110 })}<i class="mn-mark" style="left:${pos.toFixed(1)}%"></i></div></div>`;
    const lines = [{ t: S.text, at: () => document.getElementById(id + '_0') }];
    if (S.keyTxt.length) lines.push({ t: `وأهم شي صار قبلها: ${S.keyTxt.join('، و')}.`, at: q('.mn-h small') });
    lines.push({ t: S.read, at: q('.mn-mark') });
    return { t: `الدقيقة ${Math.floor(m)}`, html, lines };
  }

  /* ---------- how the prediction & xG were computed ---------- */
  function poisson(k, l) { let p = Math.exp(-l); for (let i = 1; i <= k; i++) p *= l / i; return p; }
  function predScenes(ctx) {
    const { P, ev, c, mode } = ctx; if (!P || !P.sources || !P.sources.length) return [];
    const T = s => AR(ev[s].name); const Wt = P.sources.reduce((a, s) => a + s.w, 0);
    const nm = s => s.ar.replace(/روبو/g, 'المحلل');
    const out = [];
    const tbl = `<table class="pe-t"><thead><tr><th>المصدر</th><th>الوزن</th><th style="color:${c.home}">${esc(T('home'))}</th><th>تعادل</th><th style="color:${c.away}">${esc(T('away'))}</th></tr></thead><tbody>${P.sources.map((s, i) => `<tr id="pe${i}"><td>${esc(nm(s))}</td><td dir="ltr">${pc(s.w / Wt)}%</td><td dir="ltr">${pc(s.home)}%</td><td dir="ltr">${pc(s.draw)}%</td><td dir="ltr">${pc(s.away)}%</td></tr>`).join('')}<tr class="pe-fin" id="peF"><td>النتيجة النهائية</td><td>—</td><td dir="ltr">${pc(P.fin.home)}%</td><td dir="ltr">${pc(P.fin.draw)}%</td><td dir="ltr">${pc(P.fin.away)}%</td></tr></tbody></table>`;
    const spread = Math.max(...P.sources.map(s => s[P.pick])) - Math.min(...P.sources.map(s => s[P.pick]));
    const sl = [{ t: `شلون وصلت لنسبة الفوز؟ ما أعتمد على رقم واحد، أجمع ${P.sources.length === 1 ? 'مصدر واحد' : P.sources.length + ' مصادر'} وكل مصدر إله وزن.`, at: q('.pe-t') }];
    P.sources.forEach((s, i) => sl.push({ t: `${nm(s).split(' (')[0]}: ${T('home')} ${pc(s.home)} بالمية، التعادل ${pc(s.draw)}، و${T('away')} ${pc(s.away)}. وزنه ${pc(s.w / Wt)} بالمية من القرار${s.k === 'odds' ? '، لأن السوق يعكس معلومات هواية' : s.k === 'form' ? '، لأن الفورمة تتغير بسرعة' : ''}.`, at: q('#pe' + i) }));
    sl.push({ t: `أضرب كل احتمال بوزنه وأجمعهم: ${T('home')} ${pc(P.fin.home)} بالمية، التعادل ${pc(P.fin.draw)}، و${T('away')} ${pc(P.fin.away)}. والثقة ${P.confidence} بالمية، لأن المصادر ${spread < 0.12 ? 'متفقة تقريباً' : `مختلفة بفرق ${pc(spread)} نقطة`}.`, at: q('#peF') });
    out.push({ t: 'كيف حسبت نسبة الفوز؟', html: `<div class="pe">${tbl}</div>`, lines: sl });

    // score grid
    const N = 5; const cells = []; let best = [];
    for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) { const p = poisson(i, P.lh) * poisson(j, P.la); cells.push({ i, j, p }); }
    const mx = Math.max(...cells.map(x => x.p)); best = cells.slice().sort((a, b) => b.p - a.p).slice(0, 3);
    const gridH = `<div class="pg"><div class="pg-ax"><span>الصفوف: أهداف <b style="color:${c.home}">${esc(T('home'))}</b></span><span>الأعمدة: أهداف <b style="color:${c.away}">${esc(T('away'))}</b></span></div><div class="pg-g" dir="ltr"><i></i>${[0, 1, 2, 3, 4].map(j => `<i class="pg-l">${j}</i>`).join('')}${[0, 1, 2, 3, 4].map(i => `<i class="pg-l">${i}</i>${[0, 1, 2, 3, 4].map(j => { const x = cells.find(k => k.i === i && k.j === j); return `<span id="pg${i}${j}" style="--a:${(x.p / mx).toFixed(2)}">${pc(x.p)}%</span>`; }).join('')}`).join('')}</div>
      <div class="pg-lam"><div style="--tc:${c.home}"><small>معدل أهداف ${esc(T('home'))}</small><b dir="ltr">${P.lh.toFixed(2)}</b></div><div style="--tc:${c.away}"><small>معدل أهداف ${esc(T('away'))}</small><b dir="ltr">${P.la.toFixed(2)}</b></div></div></div>`;
    const hasTable = P.sources.some(s => s.k === 'model' && s.w > 0.2);
    out.push({ t: 'كيف طلعت النتيجة المتوقعة؟', html: gridH, lines: [
      { t: `أول شي أحسب معدل الأهداف المتوقع: ${T('home')} ${P.lh.toFixed(2)} و${T('away')} ${P.la.toFixed(2)}. ${hasTable ? 'من قوة هجوم كل فريق ودفاع خصمه بالدوري، مع أفضلية الأرض' : 'من أفضلية الأرض ومعدل الدوري'}، وبعدين أعدّلها حسب الفورمة وخط الأهداف بالمراهنات والهدّافين.`, at: q('.pg-lam') },
      { t: `بعدها أستخدم توزيع بواسون: يعطيني احتمال كل نتيجة. أرجحها ${best[0].i} ل ${best[0].j} بنسبة ${pc(best[0].p)} بالمية، وبعدها ${best[1].i} ل ${best[1].j} و${best[2].i} ل ${best[2].j}.`, at: q('#pg' + best[0].i + best[0].j) },
      { t: `ومن نفس الجدول: احتمال أكثر من هدفين ونص ${pc(P.pOver)} بالمية، والفريقين يسجلون ${pc(P.pBtts)} بالمية. وأختار النتيجة ${P.score.h} ل ${P.score.a} لأنها الأرجح وتتفق مع الفائز المتوقع.`, at: q('#pg' + Math.min(4, P.score.h) + Math.min(4, P.score.a)) },
    ] });

    if (mode !== 'pre') {
      const sh = shotsOf(ctx.sum).filter(s => !s.own).sort((a, b) => b.xg - a.xg).slice(0, 5);
      if (sh.length) {
        const xgT = { home: 0, away: 0 }; shotsOf(ctx.sum).forEach(s => { xgT[s.side] += s.xg; });
        const why = s => s.pen ? 'ضربة جزاء' : [s.dist != null ? `${R(s.dist)} متر` : null, s.ang != null ? `زاوية ${R(s.ang)}°` : null, s.header ? 'رأسية' : null].filter(Boolean).join(' · ');
        const html = `<div class="xe"><p class="xe-f">xG = احتمال التسديدة تصير هدف · المسافة + زاوية المرمى + نوع التسديدة</p><ol>${sh.map((s, i) => `<li id="xe${i}" style="--tc:${c[s.side]}"><b dir="ltr">${Math.floor(s.min)}'</b><span>${esc(shortN(nmAr(ctx, s.who, s.side)))}${s.goal ? ' ⚽' : ''}<small>${esc(why(s))}</small></span><i class="xe-bar"><em style="width:${Math.min(100, s.xg * 100).toFixed(0)}%"></em></i><b dir="ltr">${f2(s.xg)}</b></li>`).join('')}</ol></div>`;
        const t0 = sh[0];
        const lines = [{ t: `شنو يعني إكس جي؟ هو احتمال إن التسديدة تصير هدف. أحسبه من ثلاث أشياء: بُعد التسديدة، زاوية المرمى المفتوحة، ونوعها؛ الرأسية أصعب، وضربة الجزاء قيمتها ثابتة 0.76.`, at: q('.xe-f') },
          { t: `أخطر فرصة: ${nmAr(ctx, t0.who, t0.side)} بالدقيقة ${Math.floor(t0.min)}${t0.pen ? '، ضربة جزاء' : `، من ${R(t0.dist || 0)} متر وزاوية ${R(t0.ang || 0)} درجة${t0.header ? '، وبالرأس' : ''}`}. قيمتها ${f2(t0.xg)}، يعني من كل 100 فرصة مثلها تدخل ${R(t0.xg * 100)}.`, at: q('#xe0') }];
        const far = sh.find(s => !s.pen && s.dist > 18);
        if (far) lines.push({ t: `وقارنها بتسديدة ${nmAr(ctx, far.who, far.side)} من ${R(far.dist)} متر: قيمتها بس ${f2(far.xg)}، لأن البعد يقلل الاحتمال بسرعة.`, at: q('#xe' + sh.indexOf(far)) });
        lines.push({ t: `أجمع كل الفرص: ${T('home')} ${f2(xgT.home)} إكس جي و${T('away')} ${f2(xgT.away)}. ${Math.abs(xgT.home - xgT.away) < 0.35 ? 'يعني الفرص كانت متقاربة.' : `يعني ${T(xgT.home > xgT.away ? 'home' : 'away')} كان يستحق يسجل أكثر.`}`, at: q('.xe ol') });
        out.push({ t: 'كيف أحسب xG؟', html, lines });
      }
    }
    return out;
  }

  /* timeline markers */
  function marks(ctx) {
    if (ctx.mode === 'pre') return null;
    const evs = events(ctx.sum); const mx = ctx.mode === 'in' ? Math.max(1, Math.min(maxMinute(ctx.sum), parseInt(ctx.ev.clock) || maxMinute(ctx.sum))) : maxMinute(ctx.sum);
    const k = evs.filter(e => e.side && /^goal|scored|red-card|yellow-card|substitution/.test(e.tt)).map(e => ({ m: e.m, side: e.side, k: /^goal|scored/.test(e.tt) ? 'g' : /red/.test(e.tt) ? 'r' : /yellow/.test(e.tt) ? 'y' : 's' }));
    return { max: Math.max(mx, ...evs.map(e => Math.ceil(e.m)), ctx.mode === 'in' ? 1 : 90), list: k };
  }

  YH.tactics = { events, shotsOf, share, profile, deepScenes, replayScenes, stateAt, minuteScene, predScenes, marks, buildStyle, pressStyle, maxMinute, nmAr, boardScene, OPP };
})();
