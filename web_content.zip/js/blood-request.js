/**
 * BD BLOOD DONATION - Blood Request Management & Form View
 * Handles creating blood requests, emergency requests, matching donors, and status workflows.
 */

import { 
  db, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  serverTimestamp 
} from './firebase-config.js';
import { getCurrentUser, getCurrentUserProfile } from './auth.js';
import { showToast, isValidBdPhone, canDonateTo, getLanguage, toBengaliDigits, escapeHtml } from './utils.js';
import { getDistrictName, setupLocationDropdowns } from './location.js';

export async function checkPendingRatingRequired(userId) {
  if (!userId) return false;
  try {
    const q = query(
      collection(db, 'blood_requests'),
      where('requesterId', '==', userId),
      where('status', '==', 'Completed'),
      where('isRated', '==', false),
      limit(1)
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return { id: snap.docs[0].id, ...snap.docs[0].data() };
    }
    return false;
  } catch (err) {
    console.warn('[Check Pending Rating]', err.message);
    return false;
  }
}

export async function createBloodRequest(requestData) {
  const user = getCurrentUser();
  if (!user) {
    throw new Error('অনুরোধ তৈরি করতে প্রথমে লগইন করুন।');
  }

  const pendingRating = await checkPendingRatingRequired(user.uid);
  if (pendingRating) {
    throw new Error(
      `আপনার পূর্ববর্তী রক্তদানের জন্য রিভিউ ও রেটিং দেওয়া বাকি রয়েছে (রোগী: ${pendingRating.patientName})। অনুগ্রহ করে রেটিং সম্পন্ন করে নতুন আবেদন করুন।`
    );
  }

  const {
    patientName,
    bloodGroup,
    bagsCount,
    hospitalName,
    hospitalAddress,
    division,
    district,
    upazila,
    requiredDate,
    requiredTime,
    contactPhone,
    additionalInfo,
    isEmergency
  } = requestData;

  if (!patientName || patientName.trim().length < 2) {
    throw new Error('রোগীর নাম সঠিকভাবে প্রদান করুন।');
  }
  if (!bloodGroup) {
    throw new Error('রক্তের গ্রুপ নির্বাচন করুন।');
  }
  if (!bagsCount || Number(bagsCount) <= 0) {
    throw new Error('রক্তের ব্যাগের সংখ্যা উল্লেখ করুন।');
  }
  if (!hospitalName || hospitalName.trim().length < 3) {
    throw new Error('হাসপাতালের নাম প্রদান করুন।');
  }
  if (!division || !district) {
    throw new Error('হাসপাতালের বিভাগ ও জেলা নির্বাচন করুন।');
  }
  if (!requiredDate) {
    throw new Error('রক্তের প্রয়োজনের তারিখ প্রদান করুন।');
  }
  if (!isValidBdPhone(contactPhone)) {
    throw new Error('সঠিক ১১ ডিজিটের যোগাযোগ মোবাইল নম্বর প্রদান করুন।');
  }

  const userProfile = getCurrentUserProfile() || {};

  const requestPayload = {
    requesterId: user.uid,
    requesterName: userProfile.fullName || user.displayName || 'সম্মানিত সেবাগ্রহীতা',
    requesterPhone: userProfile.phone || contactPhone,
    patientName: patientName.trim(),
    bloodGroup,
    bagsCount: Number(bagsCount),
    hospitalName: hospitalName.trim(),
    hospitalAddress: (hospitalAddress || '').trim(),
    division,
    district,
    upazila: upazila || '',
    requiredDate,
    requiredTime: requiredTime || 'জরুরি / যত দ্রুত সম্ভব',
    contactPhone: contactPhone.trim(),
    additionalInfo: (additionalInfo || '').trim(),
    isEmergency: Boolean(isEmergency),
    status: 'Pending',
    acceptedDonorId: null,
    acceptedDonorName: null,
    acceptedDonorPhone: null,
    isRated: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };

  const docRef = await addDoc(collection(db, 'blood_requests'), requestPayload);
  const requestId = docRef.id;

  matchAndNotifyDonors({
    requestId,
    ...requestPayload
  }).catch((err) => {
    console.warn('[Matching Donors Notice]:', err.message);
  });

  showToast(
    isEmergency 
      ? 'জরুরি রক্তদানের আবেদন সফলভাবে প্রকাশিত হয়েছে এবং উপযুক্ত রক্তদাতাদের নোটিফিকেশন পাঠানো হয়েছে!' 
      : 'রক্তের আবেদন সফলভাবে তৈরি হয়েছে!',
    'success',
    5000
  );

  return { id: requestId, ...requestPayload };
}

export async function matchAndNotifyDonors(request) {
  try {
    const { requestId, bloodGroup, district, upazila, hospitalName, isEmergency, requesterId } = request;
    
    const donorsQuery = query(
      collection(db, 'users'),
      where('district', '==', district),
      where('isAvailable', '==', true),
      limit(40)
    );

    const snapshot = await getDocs(donorsQuery);
    if (snapshot.empty) return;

    const matchedDonors = [];
    const districtNameBn = getDistrictName(request.division, district, 'bn');

    snapshot.forEach((docSnap) => {
      const donor = docSnap.data();
      const donorUid = docSnap.id;
      if (donorUid === requesterId) return;

      if (canDonateTo(donor.bloodGroup, bloodGroup)) {
        matchedDonors.push({ id: donorUid, ...donor });
      }
    });

    const notifPromises = matchedDonors.map(async (donor) => {
      return addDoc(collection(db, 'notifications'), {
        recipientId: donor.id,
        requesterId,
        requestId,
        type: isEmergency ? 'emergency_request' : 'matching_request',
        title: isEmergency ? '🚨 জরুরি রক্তের প্রয়োজন!' : '🩸 রক্তদানের অনুরোধ',
        message: `${bloodGroup} গ্রুপের রক্তের জরুরি প্রয়োজন। হাসপাতাল: ${hospitalName}, এলাকা: ${districtNameBn}।`,
        bloodGroup,
        hospitalName,
        district,
        upazila,
        isEmergency: Boolean(isEmergency),
        read: false,
        createdAt: serverTimestamp()
      });
    });

    await Promise.all(notifPromises);
  } catch (error) {
    console.warn('[Match & Notify Error]', error.message);
  }
}

export async function acceptBloodRequest(requestId) {
  const user = getCurrentUser();
  const profile = getCurrentUserProfile();
  if (!user || !profile) {
    throw new Error('অনুগ্রহ করে প্রথমে আপনার একাউন্টে লগইন করুন।');
  }

  const reqRef = doc(db, 'blood_requests', requestId);
  const snap = await getDoc(reqRef);
  if (!snap.exists()) {
    throw new Error('অনুরোধটি পাওয়া যায়নি।');
  }

  const reqData = snap.data();
  if (reqData.requesterId === user.uid) {
    throw new Error('আপনি নিজের অনুরোধ গ্রহণ করতে পারবেন না।');
  }
  if (reqData.status === 'Completed' || reqData.status === 'Cancelled') {
    throw new Error('এই অনুরোধটি আর সক্রিয় নেই।');
  }

  await updateDoc(reqRef, {
    status: 'Accepted',
    acceptedDonorId: user.uid,
    acceptedDonorName: profile.fullName || user.displayName || 'স্বেচ্ছাসেবী রক্তদাতা',
    acceptedDonorPhone: profile.phone || '',
    updatedAt: serverTimestamp()
  });

  await addDoc(collection(db, 'notifications'), {
    recipientId: reqData.requesterId,
    requestId,
    donorId: user.uid,
    type: 'request_accepted',
    title: '🎉 রক্তদাতা পাওয়া গেছে!',
    message: `${profile.fullName || 'একজন রক্তদাতা'} আপনার ${reqData.bloodGroup} রক্তের অনুরোধ গ্রহণ করেছেন।`,
    read: false,
    createdAt: serverTimestamp()
  });

  showToast('ধন্যবাদ! আপনি রক্তদানের সম্মতি প্রদান করেছেন।', 'success');
}

export async function completeBloodRequest(requestId) {
  const user = getCurrentUser();
  if (!user) throw new Error('লগইন করুন।');

  const reqRef = doc(db, 'blood_requests', requestId);
  const snap = await getDoc(reqRef);
  if (!snap.exists()) throw new Error('অনুরোধটি পাওয়া যায়নি।');

  const data = snap.data();
  if (data.requesterId !== user.uid) {
    throw new Error('শুধুমাত্র অনুরোধকারী এই আবেদনটি সম্পন্ন করতে পারেন।');
  }

  await updateDoc(reqRef, {
    status: 'Completed',
    completedAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });

  if (data.acceptedDonorId) {
    const donorRef = doc(db, 'users', data.acceptedDonorId);
    const donorSnap = await getDoc(donorRef);
    if (donorSnap.exists()) {
      const currentCount = donorSnap.data().donationCount || 0;
      await updateDoc(donorRef, {
        donationCount: currentCount + 1,
        lastDonationDate: serverTimestamp()
      });
    }

    await addDoc(collection(db, 'donation_history'), {
      donorId: data.acceptedDonorId,
      requesterId: user.uid,
      requestId,
      patientName: data.patientName,
      bloodGroup: data.bloodGroup,
      hospitalName: data.hospitalName,
      donatedAt: serverTimestamp()
    });

    await addDoc(collection(db, 'notifications'), {
      recipientId: data.acceptedDonorId,
      requestId,
      type: 'donation_completed',
      title: '❤️ রক্তদান সফল হয়েছে!',
      message: `${data.patientName}-কে রক্তদান সফলভাবে সম্পন্ন হয়েছে। আপনার অবদানে একটি জীবন বাঁচল!`,
      read: false,
      createdAt: serverTimestamp()
    });
  }

  showToast('রক্তদান সফলভাবে সম্পন্ন হয়েছে। অনুগ্রহ করে রক্তদাতাকে রেটিং দিন।', 'success');
}

export async function cancelBloodRequest(requestId, reason = '') {
  const user = getCurrentUser();
  if (!user) throw new Error('লগইন করুন।');

  const reqRef = doc(db, 'blood_requests', requestId);
  const snap = await getDoc(reqRef);
  if (!snap.exists()) throw new Error('অনুরোধটি পাওয়া যায়নি।');

  const data = snap.data();
  if (data.requesterId !== user.uid) {
    throw new Error('শুধুমাত্র অনুরোধকারী এটি বাতিল করতে পারেন।');
  }

  await updateDoc(reqRef, {
    status: 'Cancelled',
    cancelReason: reason,
    updatedAt: serverTimestamp()
  });

  showToast('অনুরোধটি বাতিল করা হয়েছে।', 'info');
}

/**
 * Render the Blood Request Form View
 */
export async function renderBloodRequestPage(container, params = {}) {
  const isBn = getLanguage() === 'bn';
  const user = getCurrentUser();
  const profile = getCurrentUserProfile();
  const isEmergencyInitial = params.emergency === '1' || params.emergency === 'true';

  // Check pending rating enforcement
  if (user) {
    const pending = await checkPendingRatingRequired(user.uid);
    if (pending) {
      container.innerHTML = `
        <div class="page-container animate-slide-in">
          <div class="card" style="border-left: 5px solid var(--warning-color); padding: 24px; text-align: center;">
            <div style="font-size: 36px; margin-bottom: 8px;">⭐</div>
            <h3 style="font-size: 16px; font-weight: 800; color: var(--text-main); margin-bottom: 6px;">
              ${isBn ? 'রেটিং ও রিভিউ বাকি রয়েছে' : 'Donor Rating Required'}
            </h3>
            <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px;">
              ${isBn 
                ? `আপনার পূর্ববর্তী সফল রক্তদানের জন্য রক্তদাতাকে এখনো রেটিং দেওয়া হয়নি (রোগী: <strong>${escapeHtml(pending.patientName)}</strong>)। রক্তদাতাদের উৎসাহিত করতে অনুগ্রহ করে রেটিং দিন।` 
                : `You must submit a review for the completed donation of patient: ${escapeHtml(pending.patientName)} before creating another request.`}
            </p>
            <a href="#/my-requests" class="btn btn-primary btn-block">
              ${isBn ? 'রেটিং প্রদান করতে যান' : 'Go to Rate Donor'}
            </a>
          </div>
        </div>
      `;
      return;
    }
  }

  const todayStr = new Date().toISOString().split('T')[0];

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>🩸 ${isBn ? 'রক্তের আবেদন ফরম' : 'Blood Request Form'}</span>
        <a href="#/my-requests" class="section-link">${isBn ? 'আমার আবেদনসমূহ' : 'My Requests'} &rarr;</a>
      </div>

      <div class="card">
        <!-- Emergency Toggle Switch -->
        <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px; background: #FFF5F5; border: 1.5px solid #FECDD3; border-radius: var(--radius-md); margin-bottom: 16px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 20px;">🚨</span>
            <div>
              <div style="font-size: 13px; font-weight: 700; color: var(--emergency-color);">
                ${isBn ? 'জরুরি রক্তের আবেদন (Emergency)' : 'Urgent Emergency Request'}
              </div>
              <div style="font-size: 11px; color: var(--text-muted);">
                ${isBn ? 'উচ্চ অগ্রাধিকার ও দ্রুত নোটিফিকেশন প্রদান' : 'High priority broadcast notification'}
              </div>
            </div>
          </div>
          <input type="checkbox" id="req-is-emergency" ${isEmergencyInitial ? 'checked' : ''} style="width: 22px; height: 22px; cursor: pointer; accent-color: var(--emergency-color);" />
        </div>

        <form id="blood-request-form">
          <!-- Patient Name -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'রোগীর নাম' : 'Patient Name'} <span class="required-star">*</span></label>
            <input type="text" id="req-patient-name" class="form-control" placeholder="${isBn ? 'রোগীর পুরো নাম লিখুন' : 'Full Name of Patient'}" required />
          </div>

          <!-- Blood Group -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'প্রয়োজনীয় রক্তের গ্রুপ' : 'Blood Group Needed'} <span class="required-star">*</span></label>
            <div class="blood-grid" id="req-blood-grid">
              ${['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => `
                <div class="blood-radio-btn" data-group="${bg}">${bg}</div>
              `).join('')}
            </div>
            <input type="hidden" id="req-blood-group" required />
          </div>

          <!-- Bags Count -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'কত ব্যাগ রক্ত প্রয়োজন?' : 'Number of Bags Needed'} <span class="required-star">*</span></label>
            <input type="number" id="req-bags-count" class="form-control" min="1" max="20" value="1" required />
          </div>

          <!-- Hospital Name & Address -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'হাসপাতালের নাম' : 'Hospital Name'} <span class="required-star">*</span></label>
            <input type="text" id="req-hospital-name" class="form-control" placeholder="${isBn ? 'হাসপাতালের নাম ও বিভাগ' : 'e.g. Dhaka Medical College Hospital'}" required />
          </div>

          <div class="form-group">
            <label class="form-label">${isBn ? 'হাসপাতালের ঠিকানা' : 'Hospital Address / Ward'}</label>
            <input type="text" id="req-hospital-address" class="form-control" placeholder="${isBn ? 'কেবিন/ওয়ার্ড/ঠিকানা' : 'Ward / Bed / Specific address'}" />
          </div>

          <!-- Location Dropdowns -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
            <div class="form-group">
              <label class="form-label">${isBn ? 'বিভাগ' : 'Division'} <span class="required-star">*</span></label>
              <select id="req-division" class="form-select" required></select>
            </div>
            <div class="form-group">
              <label class="form-label">${isBn ? 'জেলা' : 'District'} <span class="required-star">*</span></label>
              <select id="req-district" class="form-select" required></select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">${isBn ? 'উপজেলা / এলাকা' : 'Upazila / Area'}</label>
            <select id="req-upazila" class="form-select"></select>
          </div>

          <!-- Date & Time -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
            <div class="form-group">
              <label class="form-label">${isBn ? 'রক্তের তারিখ' : 'Required Date'} <span class="required-star">*</span></label>
              <input type="date" id="req-date" class="form-control" value="${todayStr}" required />
            </div>
            <div class="form-group">
              <label class="form-label">${isBn ? 'প্রয়োজনের সময়' : 'Required Time'}</label>
              <input type="time" id="req-time" class="form-control" value="14:00" />
            </div>
          </div>

          <!-- Contact Phone -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'যোগাযোগের মোবাইল নম্বর' : 'Contact Phone Number'} <span class="required-star">*</span></label>
            <input type="tel" id="req-phone" class="form-control" placeholder="01XXXXXXXXX" value="${profile?.phone || ''}" required />
          </div>

          <!-- Additional Notes -->
          <div class="form-group">
            <label class="form-label">${isBn ? 'অতিরিক্ত তথ্য (ঐচ্ছিক)' : 'Additional Notes (Optional)'}</label>
            <textarea id="req-notes" class="form-control" rows="2" placeholder="${isBn ? 'রোগীর অবস্থা বা বিশেষ কোনো নির্দেশনা থাকলে লিখুন...' : 'Details about patient condition...'}" style="resize: none;"></textarea>
          </div>

          <button type="submit" id="req-submit-btn" class="btn btn-primary btn-block" style="margin-top: 10px;">
            <span>🩸</span>
            <span>${isBn ? 'রক্তের আবেদন সাবমিট করুন' : 'Submit Blood Request'}</span>
          </button>
        </form>
      </div>
    </div>
  `;

  // Setup location dropdowns
  setupLocationDropdowns({
    divisionSelectEl: document.getElementById('req-division'),
    districtSelectEl: document.getElementById('req-district'),
    upazilaSelectEl: document.getElementById('req-upazila'),
    selectedDivision: profile?.division || 'dhaka',
    selectedDistrict: profile?.district || 'dhaka',
    selectedUpazila: profile?.upazila || '',
    lang: isBn ? 'bn' : 'en'
  });

  // Handle blood group chips
  const bloodButtons = container.querySelectorAll('#req-blood-grid .blood-radio-btn');
  const bloodHiddenInput = document.getElementById('req-blood-group');
  bloodButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      bloodButtons.forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      bloodHiddenInput.value = btn.dataset.group;
    });
  });

  // Handle submit
  const form = document.getElementById('blood-request-form');
  const submitBtn = document.getElementById('req-submit-btn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!user) {
      showToast(isBn ? 'রক্তের আবেদন করতে অনুগ্রহ করে প্রথমে লগইন করুন।' : 'Please login to post a blood request.', 'warning');
      window.location.hash = '#/login';
      return;
    }

    if (!bloodHiddenInput.value) {
      showToast(isBn ? 'দয়া করে প্রয়োজনীয় রক্তের গ্রুপ নির্বাচন করুন।' : 'Please select blood group needed.', 'error');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = `<span class="spinner" style="width: 18px; height: 18px; margin: 0; border-width: 2px;"></span> <span>${isBn ? 'আবেদন প্রস্তুত হচ্ছে...' : 'Submitting...'}</span>`;

    try {
      await createBloodRequest({
        patientName: document.getElementById('req-patient-name').value,
        bloodGroup: bloodHiddenInput.value,
        bagsCount: document.getElementById('req-bags-count').value,
        hospitalName: document.getElementById('req-hospital-name').value,
        hospitalAddress: document.getElementById('req-hospital-address').value,
        division: document.getElementById('req-division').value,
        district: document.getElementById('req-district').value,
        upazila: document.getElementById('req-upazila').value,
        requiredDate: document.getElementById('req-date').value,
        requiredTime: document.getElementById('req-time').value,
        contactPhone: document.getElementById('req-phone').value,
        additionalInfo: document.getElementById('req-notes').value,
        isEmergency: document.getElementById('req-is-emergency').checked
      });

      window.location.hash = '#/my-requests';
    } catch (err) {
      showToast(err.message, 'error', 4500);
      submitBtn.disabled = false;
      submitBtn.innerHTML = `<span>🩸</span> <span>${isBn ? 'রক্তের আবেদন সাবমিট করুন' : 'Submit Blood Request'}</span>`;
    }
  });
}
