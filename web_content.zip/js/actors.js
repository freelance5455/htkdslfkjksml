'use strict';
/* ===== Actors: people, police, cars, plane, grid movement ===== */
const walkers = [], cars = [];
const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];

/* ---------- models ---------- */
/* hair: 'short' cap, 'long' cap with back panel, 'bald', or 'cap' for police */
function makeHuman(shirt, pants, skin, cop, opt) {
  opt = opt || {};
  const g = new THREE.Group(), L = {};
  const shoe = opt.shoe || 0x1a1a1a, hairC = opt.hair || 0x2b1b10, style = opt.style || 'short';
  // torso with a collar and a belt
  const torso = bx(.5, .62, .3, shirt); torso.position.y = 1.12; torso.castShadow = true; g.add(torso);
  const collar = bx(.3, .06, .05, 0xf1f5f9); collar.position.set(0, 1.42, .16); g.add(collar);
  const belt = bx(.52, .08, .31, 0x2a2016); belt.position.set(0, .84, 0); g.add(belt);
  const buckle = bx(.08, .07, .02, 0xd4af37); buckle.position.set(0, .84, .17); g.add(buckle);
  // neck and head
  const neck = bx(.14, .12, .14, skin); neck.position.y = 1.47; g.add(neck);
  const headG = new THREE.Group(); headG.position.y = 1.66; g.add(headG);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.18, 14, 10), mat(skin)); head.scale.set(1, 1.08, .95); head.castShadow = true; headG.add(head);
  for (const s of [-1, 1]) {
    const eyeW = new THREE.Mesh(new THREE.SphereGeometry(.035, 6, 5), mat(0xf8fafc)); eyeW.position.set(s * .065, .02, .155); headG.add(eyeW);
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(.018, 6, 5), mat(0x111111)); pupil.position.set(s * .065, .02, .182); headG.add(pupil);
    const brow = bx(.06, .014, .02, hairC); brow.position.set(s * .065, .06, .165); headG.add(brow);
    const ear = bx(.03, .06, .05, skin); ear.position.set(s * .18, 0, 0); headG.add(ear);
  }
  const nose = bx(.035, .05, .04, skin); nose.position.set(0, -.005, .18); headG.add(nose);
  const mouth = bx(.07, .014, .02, 0x7a2e2e); mouth.position.set(0, -.07, .165); headG.add(mouth);
  if (!cop && style !== 'bald') {
    const hair = new THREE.Mesh(new THREE.SphereGeometry(.19, 14, 8, 0, Math.PI * 2, 0, Math.PI * .55), mat(hairC));
    hair.position.y = .02; hair.scale.set(1.04, 1, 1); headG.add(hair);
    if (style === 'long') { const back = bx(.36, .26, .08, hairC); back.position.set(0, -.08, -.14); headG.add(back); }
  }
  if (cop) {
    const cap = bx(.42, .1, .42, 0x0f172a); cap.position.y = .16; headG.add(cap);
    const brim = bx(.4, .03, .16, 0x0f172a); brim.position.set(0, .13, .24); headG.add(brim);
    const badge = bx(.1, .1, .02, 0xfacc15); badge.position.set(.12, 1.28, .15); g.add(badge);
    const star = bx(.03, .03, .02, 0xfacc15); star.position.set(-.12, 1.36, .15); g.add(star);
  }
  const limb = (w, h, d, c, x, y) => { const p = new THREE.Group(); p.position.set(x, y, 0); const m = bx(w, h, d, c); m.position.y = -h / 2; m.castShadow = true; p.add(m); g.add(p); return p; };
  L.legL = limb(.2, .8, .22, pants, -.12, .8); L.legR = limb(.2, .8, .22, pants, .12, .8);
  L.armL = limb(.15, .62, .18, shirt, -.34, 1.42); L.armR = limb(.15, .62, .18, shirt, .34, 1.42);
  // hands
  for (const arm of [L.armL, L.armR]) { const hand = bx(.14, .14, .14, skin); hand.position.y = -.7; arm.add(hand); }
  // shoes
  for (const leg of [L.legL, L.legR]) { const s = bx(.22, .12, .28, shoe); s.position.set(0, -.84, .03); leg.add(s); }
  // pistol in the right hand, shown while armed
  const gun = new THREE.Group();
  const slide = bx(.06, .08, .26, 0x1f2328); slide.position.set(0, -.02, .12); gun.add(slide);
  const grip = bx(.05, .14, .06, 0x111111); grip.position.set(0, -.1, .06); gun.add(grip);
  gun.position.set(0, -.72, .08); gun.visible = false; L.armR.add(gun); L.gun = gun;
  g.userData.limbs = L;
  return g;
}
function swing(g, amt, t) {
  const L = g.userData.limbs, s = Math.sin(t) * amt;
  L.legL.rotation.x = s; L.legR.rotation.x = -s; L.armL.rotation.x = -s * .8; L.armR.rotation.x = s * .8;
}

const wheelG = new THREE.CylinderGeometry(.38, .38, .3, 10).rotateZ(Math.PI / 2);
function makeCar(color, kind) {
  const g = new THREE.Group(), police = kind === 'police';
  const body = bx(2, .7, 4.3, color); body.position.y = .65; body.castShadow = true; g.add(body);
  const cab = bx(1.7, .62, 2.3, police ? 0xf5f5f5 : color); cab.position.set(0, 1.3, -.25); cab.castShadow = true; g.add(cab);
  const gl = bx(1.74, .38, 2.34, 0x1a2430); gl.position.set(0, 1.33, -.25); g.add(gl);
  const wheels = [];
  for (const [x, z, f] of [[-1.02, 1.4, 1], [1.02, 1.4, 1], [-1.02, -1.4, 0], [1.02, -1.4, 0]]) {
    const p = new THREE.Group(); p.position.set(x, .38, z);
    const w = new THREE.Mesh(wheelG, mat(0x15171a)); p.add(w); g.add(p); wheels.push({ p, w, f });
  }
  for (const s of [-1, 1]) {
    const h = bx(.4, .2, .1, 0xfff2b0); h.position.set(s * .7, .75, 2.16); g.add(h);
    const t = bx(.4, .2, .1, 0xc62828); t.position.set(s * .7, .8, -2.16); g.add(t);
  }
  g.userData.wheels = wheels;
  if (police) {
    const r = new THREE.Mesh(UB, new THREE.MeshBasicMaterial({ color: 0xff2222 })); r.scale.set(.6, .2, .4); r.position.set(-.4, 1.72, -.25);
    const b = new THREE.Mesh(UB, new THREE.MeshBasicMaterial({ color: 0x2255ff })); b.scale.set(.6, .2, .4); b.position.set(.4, 1.72, -.25);
    g.add(r, b); g.userData.bar = [r, b];
  }
  return g;
}

function makePlane() {
  const g = new THREE.Group();
  const fus = new THREE.Mesh(new THREE.CylinderGeometry(.85, .4, 9, 12).rotateX(Math.PI / 2), mat(0xf4f4f4)); fus.position.set(0, 1.4, 0); fus.castShadow = true; g.add(fus);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(.85, 10, 8), mat(0xf4f4f4)); nose.position.set(0, 1.4, 4.5); g.add(nose);
  const wing = bx(13, .22, 2.3, 0xe5e7eb); wing.position.set(0, 1.5, .6); wing.castShadow = true; g.add(wing);
  const stripe = bx(13.02, .24, .5, 0xdc2626); stripe.position.set(0, 1.5, 1.4); g.add(stripe);
  const tail = bx(4.6, .2, 1.4, 0xe5e7eb); tail.position.set(0, 1.5, -4); g.add(tail);
  const fin = bx(.2, 1.9, 1.7, 0xdc2626); fin.position.set(0, 2.5, -3.9); g.add(fin);
  const prop = bx(.14, 2.8, .1, 0x222222); prop.position.set(0, 1.4, 5.4); g.add(prop);
  for (const [x, z] of [[-1.2, 1.4], [1.2, 1.4], [0, -3.2]]) { const w = new THREE.Mesh(wheelG, mat(0x15171a)); w.scale.setScalar(.8); w.position.set(x, .35, z); g.add(w); }
  g.userData.prop = prop;
  return g;
}

/* ---------- grid movement (traffic and pedestrians) ---------- */
function gridPick(o) {
  const opts = DIRS.filter(d => {
    const a = o.ni + d[0], b = o.nj + d[1];
    return a >= -NR && a <= NR && b >= -NR && b <= NR && !(o.pi === a && o.pj === b);
  });
  const d = opts.length ? pick(opts) : DIRS[0];
  o.ti = o.ni + d[0]; o.tj = o.nj + d[1]; o.dx = d[0]; o.dz = d[1]; o.t = 0;
}
function gridArrive(o) { o.pi = o.ni; o.pj = o.nj; o.ni = o.ti; o.nj = o.tj; gridPick(o); }
function gridPos(o) {
  const px = o.ni * PITCH + o.dx * PITCH * o.t, pz = o.nj * PITCH + o.dz * PITCH * o.t;
  return [px - o.dz * o.off, pz + o.dx * o.off];
}
function gridAdvance(o, dist) { o.t += dist / PITCH; if (o.t >= 1) gridArrive(o); }
function gridInit(o, off) {
  o.ni = rint(-NR, NR); o.nj = rint(-NR, NR); o.pi = null; o.pj = null; o.off = off; gridPick(o);
  const p = gridPos(o); o.x = p[0]; o.z = p[1];
}
function gridSnap(o) {   // rejoin the grid from a free position
  o.ni = clamp(Math.round(o.x / PITCH), -NR, NR); o.nj = clamp(Math.round(o.z / PITCH), -NR, NR);
  o.pi = null; o.pj = null; gridPick(o);
}
function turnTo(cur, target, rate) {
  let d = target - cur; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
  return cur + clamp(d, -rate, rate);
}

/* ---------- walkers: civilians and police on foot ---------- */
function newWalker(kind, x, z) {
  const cop = kind === 'cop';
  const mesh = cop ? makeHuman(0x1e3a8a, 0x111827, 0xe0ac69, true, { shoe: 0x0b0b0b })
    : makeHuman(pick([0xe11d48, 0x2563eb, 0xf59e0b, 0x10b981, 0x8b5cf6, 0xf3f4f6, 0x64748b, 0x1f2937]), pick([0x1f2937, 0x374151, 0x1e3a5f, 0x7c5a3a, 0x3b4252]), pick([0xf1c27d, 0xc68642, 0x8d5524, 0xe0ac69, 0xffdbac]),
      false, { hair: pick([0x2b1b10, 0x0b0b0b, 0x6b4423, 0xb07d3a, 0x9ca3af]), style: pick(['short', 'short', 'long', 'bald']), shoe: pick([0x1a1a1a, 0x5b3a1e, 0xf5f5f5]) });
  mesh.traverse(o => { if (o.isMesh) o.castShadow = false; });   // people do not cast shadows: saves draw calls
  const w = { kind, mesh, hp: cop ? 100 : 50, state: cop ? 'patrol' : 'walk', speed: cop ? 1.8 : rnd(1.3, 2.2), anim: rnd(0, 6), timer: 0, cd: 0, x: 0, z: 0, h: 0 };
  gridInit(w, 6 * (Math.random() < .5 ? 1 : 1));
  if (x !== undefined) { w.x = x; w.z = z; gridSnap(w); }
  mesh.position.set(w.x, 0.2, w.z);
  scene.add(mesh); walkers.push(w);
  return w;
}
function removeWalker(w) { scene.remove(w.mesh); const i = walkers.indexOf(w); if (i >= 0) walkers.splice(i, 1); }

function hurtWalker(w, dmg, byPlayer) {
  if (w.state === 'dead') return;
  w.hp -= dmg;
  if (w.hp <= 0) {
    w.state = 'dead'; w.timer = 8;
    if (byPlayer) { onKill(w); }
    return;
  }
  if (w.kind === 'civ') { w.state = 'flee'; w.timer = 7; if (byPlayer) onCrime(1, w.x, w.z); }
  else if (byPlayer) { w.state = 'chase'; onCrime(2, w.x, w.z); }
}

function updateWalker(w, dt, P) {
  const m = w.mesh;
  if (w.state === 'dead') {
    m.rotation.x = Math.max(-Math.PI / 2, m.rotation.x - dt * 4); m.position.y = .2;
    w.timer -= dt; if (w.timer < 0) removeWalker(w);
    return;
  }
  const dxp = P.x - w.x, dzp = P.z - w.z, dp = Math.hypot(dxp, dzp);
  let moving = true, spd = w.speed;
  if (w.state === 'walk' || w.state === 'patrol') {
    if (w.kind === 'cop' && P.wanted > 0 && dp < 70) w.state = 'chase';
    gridAdvance(w, spd * dt);
    const g = gridPos(w), k = Math.min(1, dt * 5);
    const ox = w.x, oz = w.z; w.x += (g[0] - w.x) * k; w.z += (g[1] - w.z) * k;
    if (Math.hypot(w.x - ox, w.z - oz) > .001) w.h = turnTo(w.h, Math.atan2(w.x - ox, w.z - oz), dt * 8);
  } else {
    let tx = 0, tz = 0;
    if (w.state === 'flee') { tx = -dxp; tz = -dzp; spd = 6.2; w.timer -= dt; if (w.timer <= 0) { w.state = 'walk'; gridSnap(w); } }
    else if (w.state === 'leave') { tx = -dxp; tz = -dzp; spd = 3.5; w.timer -= dt; if (dp > 80 || w.timer < 0) { removeWalker(w); return; } }
    else if (w.state === 'chase') {
      if (P.wanted <= 0) { w.state = 'leave'; w.timer = 14; }
      spd = P.wanted >= 3 ? 7.2 : 6;
      tx = dxp; tz = dzp; w.cd -= dt;
      if (dp < 13 && los(w.x, w.z, P.x, P.z)) {
        moving = false;
        if (w.cd <= 0) { w.cd = rnd(.8, 1.3); if (Math.random() < .55) hurtPlayer(rnd(4, 8)); fireTracer(w.x, 1.3, w.z, P.x, 1.2, P.z, 0xffcf6b); }
      }
      if (dp < 1.8) { moving = false; if (w.cd <= 0) { w.cd = .8; hurtPlayer(7); } }
    }
    const l = Math.hypot(tx, tz) || 1;
    if (moving) {
      const ox = w.x, oz = w.z; w.x += tx / l * spd * dt; w.z += tz / l * spd * dt;
      pushOut(w, .45); clampWorld(w);
      w.h = turnTo(w.h, Math.atan2(tx, tz), dt * 9);
    } else w.h = turnTo(w.h, Math.atan2(dxp, dzp), dt * 9);
  }
  m.position.set(w.x, .2, w.z); m.rotation.y = w.h; m.visible = dp < 150;   // skip drawing people far away
  if (moving) { w.anim += dt * (spd > 4 ? 12 : 7); swing(m, spd > 4 ? .9 : .55, w.anim); } else swing(m, 0, 0);
}

/* ---------- cars ---------- */
function newCar(x, z, h, color, kind, mode) {
  const mesh = makeCar(color, kind);
  const c = { mesh, kind, mode, x, z, h, speed: 0, hp: kind === 'police' ? 160 : 120, wheelSpin: 0, steer: 0, stun: 0, r: 2.1, dropped: false };
  mesh.position.set(x, 0, z); mesh.rotation.y = h;
  scene.add(mesh); cars.push(c);
  return c;
}
function newTrafficCar() {
  const c = newCar(0, 0, 0, pick([0xdc2626, 0x2563eb, 0xf59e0b, 0xe5e7eb, 0x111827, 0x16a34a, 0x7c3aed, 0xf97316, 0x0ea5e9, 0x9ca3af]), 'civ', 'ai');
  gridInit(c, 2.6); c.cruise = rnd(9, 14);
  c.x = gridPos(c)[0]; c.z = gridPos(c)[1]; c.h = Math.atan2(c.dx, c.dz);
  return c;
}
function removeCar(c) { scene.remove(c.mesh); const i = cars.indexOf(c); if (i >= 0) cars.splice(i, 1); }

function updateCarVisual(c, dt) {
  c.mesh.position.set(c.x, 0, c.z); c.mesh.rotation.y = c.h;
  c.wheelSpin += c.speed * dt / .38;
  for (const w of c.mesh.userData.wheels) { w.w.rotation.x = c.wheelSpin; if (w.f) w.p.rotation.y = c.steer * .45; }
  const bar = c.mesh.userData.bar;
  if (bar && (c.mode === 'chase' || c.mode === 'parkedcop')) {
    const on = Math.floor(performance.now() / 180) % 2;
    bar[0].material.color.setHex(on ? 0xff2222 : 0x330808); bar[1].material.color.setHex(on ? 0x081133 : 0x2d6bff);
  }
}

function updateCar(c, dt, P) {
  if (c.mode === 'ai') {
    let blocked = false;
    const fx = Math.sin(c.h), fz = Math.cos(c.h);
    const check = (ox, oz, rad) => {
      const rx = ox - c.x, rz = oz - c.z, f = rx * fx + rz * fz, lat = Math.abs(rx * -fz + rz * fx);
      if (f > 0 && f < rad && lat < 2.4) blocked = true;
    };
    if (c.stun > 0) { c.stun -= dt; blocked = true; }
    check(P.x, P.z, 9);
    for (const o of cars) if (o !== c && (o.mode === 'ai' || o.mode === 'player')) check(o.x, o.z, 7);
    for (const w of walkers) if (w.state === 'flee' || w.state === 'walk') { if (Math.hypot(w.x - c.x, w.z - c.z) < 10) check(w.x, w.z, 7); }
    const target = blocked ? 0 : c.cruise;
    c.speed += clamp(target - c.speed, -26 * dt, 8 * dt);
    gridAdvance(c, c.speed * dt);
    const g = gridPos(c), ox = c.x, oz = c.z, k = Math.min(1, dt * 7);
    c.x += (g[0] - c.x) * k; c.z += (g[1] - c.z) * k;
    if (Math.hypot(c.x - ox, c.z - oz) > .005) { const nh = Math.atan2(c.x - ox, c.z - oz); c.steer = clamp(-(turnTo(c.h, nh, 1) - c.h) * 3, -1, 1); c.h = turnTo(c.h, nh, dt * 5); }
  } else if (c.mode === 'chase') {
    const dx = P.x - c.x, dz = P.z - c.z, dist = Math.hypot(dx, dz);
    const want = Math.atan2(dx, dz);
    c.steer = clamp((turnTo(c.h, want, 1) - c.h) * 2, -1, 1);
    c.h = turnTo(c.h, want, dt * 2.2);
    if (dist < 16 && !c.dropped) {
      c.dropped = true; c.mode = 'parkedcop';
      for (let i = 0; i < 2; i++) { const w = newWalker('cop', c.x + (i ? 3 : -3), c.z); w.state = 'chase'; w.x = c.x + (i ? 3 : -3); w.z = c.z; }
    }
    const tgt = P.wanted > 0 ? 24 + P.wanted * 2 : 0;
    c.speed += clamp(tgt - c.speed, -30 * dt, 14 * dt);
    c.x += Math.sin(c.h) * c.speed * dt; c.z += Math.cos(c.h) * c.speed * dt;
    if (pushOut(c, 2.2)) { c.speed *= .85; c.h += dt * 1.2; }
    if (Math.hypot(P.x - c.x, P.z - c.z) < 2.6 && c.speed > 5 && P.mode === 'foot') hurtPlayer(14 * dt * 4);
    if (P.wanted <= 0) c.mode = 'parkedcop';
  } else {   // parked / parkedcop / wreck
    c.speed *= Math.max(0, 1 - 3 * dt);
    c.x += Math.sin(c.h) * c.speed * dt; c.z += Math.cos(c.h) * c.speed * dt;
    pushOut(c, 2.0);
  }
  clampWorld(c);
  if (c.mode !== 'player') updateCarVisual(c, dt);
}

/* ---------- plane ---------- */
let plane = null;
function initPlane() {
  const mesh = makePlane();
  plane = { mesh, x: 232, y: .02, z: -110, h: Math.PI / 2, speed: 0, pitch: 0, roll: 0, pilot: false, crashed: false };
  scene.add(mesh); syncPlane();
  const dec = makePlane(); dec.position.set(262, 0, -28); dec.rotation.y = -Math.PI / 2 + .35; scene.add(dec);
  const dec2 = makePlane(); dec2.position.set(285, 0, -42); dec2.rotation.y = -Math.PI / 2 - .2; scene.add(dec2);
  addCollider(262, -28, 11, 11, 4); addCollider(285, -42, 11, 11, 4);
}
function syncPlane() {
  plane.mesh.position.set(plane.x, plane.y, plane.z);
  plane.mesh.rotation.set(-plane.pitch, plane.h, plane.roll, 'YXZ');
}
function updatePlane(dt, jx, jy, on) {
  const p = plane;
  p.mesh.userData.prop.rotation.z += dt * (on ? 40 : 6);
  if (!on) { p.speed *= Math.max(0, 1 - 1.2 * dt); if (p.y <= .05) { p.x += Math.sin(p.h) * p.speed * dt; p.z += Math.cos(p.h) * p.speed * dt; } syncPlane(); return; }
  const ground = p.y <= .06;
  if (ground) {
    p.speed = clamp(p.speed + (jy > 0 ? jy * 22 : jy * 40) * dt, 0, 80);
    p.speed *= 1 - .08 * dt;
    p.h -= jx * clamp(p.speed / 14, 0, 1) * .8 * dt;
    p.pitch += ((p.speed > 33 && jy > .4 ? .3 : 0) - p.pitch) * Math.min(1, dt * 3);
    if (p.speed > 33 && jy > .4) p.y = .1;
    p.roll *= .9;
  } else {
    p.speed += (58 - p.speed) * .5 * dt - p.pitch * 14 * dt;
    p.pitch += (jy * .55 - p.pitch) * Math.min(1, dt * 1.8);
    p.roll += (jx * .7 - p.roll) * Math.min(1, dt * 2.5);
    p.h -= p.roll * .95 * dt;
    let climb = Math.sin(p.pitch) * p.speed;
    if (p.speed < 28) climb -= (28 - p.speed) * 1.2;
    p.y = clamp(p.y + climb * dt, 0, 260);
    if (p.y <= .06) {
      if (p.pitch < -.3 || Math.abs(p.roll) > .5) { p.crashed = true; }
      p.y = 0.02; p.pitch = 0; p.roll = 0;
    }
  }
  p.x += Math.sin(p.h) * p.speed * dt; p.z += Math.cos(p.h) * p.speed * dt;
  p.x = clamp(p.x, -900, 1100); p.z = clamp(p.z, -900, 900);
  if (p.y < 80) for (const c of colliders) if (p.x > c.x0 - 3 && p.x < c.x1 + 3 && p.z > c.z0 - 3 && p.z < c.z1 + 3 && p.y < c.h + 1) { p.crashed = true; break; }
  syncPlane();
}

/* ---------- tracers ---------- */
const tracers = [];
function fireTracer(x0, y0, z0, x1, y1, z1, color) {
  const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(x0, y0, z0), new THREE.Vector3(x1, y1, z1)]);
  const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: color || 0xfff3a0, transparent: true }));
  scene.add(l); tracers.push({ l, life: .12 });
}
function updateTracers(dt) {
  for (let i = tracers.length - 1; i >= 0; i--) {
    const t = tracers[i]; t.life -= dt; t.l.material.opacity = Math.max(0, t.life / .12);
    if (t.life <= 0) { scene.remove(t.l); t.l.geometry.dispose(); t.l.material.dispose(); tracers.splice(i, 1); }
  }
}
const blasts = [];
function explode(x, y, z) {
  audioBoom();
  const m = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 8), new THREE.MeshBasicMaterial({ color: 0xff8a1f, transparent: true, opacity: .9 }));
  m.position.set(x, y, z); scene.add(m); blasts.push({ m, life: .8 });
}
function updateBlasts(dt) {
  for (let i = blasts.length - 1; i >= 0; i--) {
    const b = blasts[i]; b.life -= dt; const s = 1 + (0.8 - b.life) * 9; b.m.scale.setScalar(s); b.m.material.opacity = Math.max(0, b.life);
    if (b.life <= 0) { scene.remove(b.m); blasts.splice(i, 1); }
  }
}

/* ---------- population ---------- */
function populate() {
  const many = Math.min(innerWidth, innerHeight) >= 700;
  for (let i = 0; i < (many ? 120 : 80); i++) newWalker('civ');
  for (let i = 0; i < 8; i++) newWalker('cop');
  for (let i = 0; i < (many ? 34 : 22); i++) newTrafficCar();
  const park = [[-4, 22, 0, 0xf59e0b], [5, -20, Math.PI, 0x2563eb], [-46, 8, Math.PI / 2, 0xdc2626], [96, 4, -Math.PI / 2, 0x16a34a],
    [180, -4, 0, 0x7c3aed], [-4, 60, 0, 0xe5e7eb], [-96, -22, Math.PI / 2, 0x111827], [46, 96, 0, 0xf97316], [-150, 46, 0, 0x0ea5e9], [146, 96, Math.PI, 0x9ca3af]];
  for (const p of park) newCar(p[0], p[1], p[2], p[3], 'civ', 'parked');
  initPlane();
}
