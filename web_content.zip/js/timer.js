export class RealTimer{
constructor(onTick,onDone){this.onTick=onTick;this.onDone=onDone;this.running=false;this.start=0;this.elapsed=0;this.duration=0;this.raf=0}
startFor(seconds){this.stop();this.duration=seconds;this.elapsed=0;this.start=performance.now();this.running=true;this.loop()}
loop=()=>{if(!this.running)return;this.elapsed=(performance.now()-this.start)/1000;const left=Math.max(0,this.duration-this.elapsed);this.onTick(left);if(left<=0){this.running=false;this.onDone?.();return}this.raf=requestAnimationFrame(this.loop)}
pause(){if(!this.running)return;this.elapsed=(performance.now()-this.start)/1000;this.running=false;cancelAnimationFrame(this.raf)}
resume(){if(this.running)return;this.start=performance.now()-this.elapsed*1000;this.running=true;this.loop()}
stop(){this.running=false;cancelAnimationFrame(this.raf)}
}