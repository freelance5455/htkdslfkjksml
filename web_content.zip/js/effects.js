(function($){
 const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;let cur='',iv=null;
 const R=['A','K','Q','J','10','9','8','7','6','5','4','3','2'],SU=[['♠',0],['♥',1],['♦',1],['♣',0]];
 $.easing.drop=p=>p<.82?Math.pow(p/.82,2.2):1-Math.sin((p-.82)/.18*Math.PI)*.035;
 function drop(land){
  const a=Math.random()*6.283,r=Math.sqrt(Math.random())*.8,x=50+Math.cos(a)*r*46,y=50+Math.sin(a)*r*46,rz=Math.random()*360,tm=(Math.random()<.5?-1:1)*(360+Math.random()*360),s=SU[Math.random()*4|0],rk=R[Math.random()*13|0];
  const $w=$('<div class="wr"><div class="sh"></div><div class="fc sv0">'+(window.cardSVG?cardSVG(rk,['S','H','D','C'][SU.indexOf(s)],1,0,0):'')+'</div></div>').css({left:x+'%',top:y+'%'}).appendTo('#plane'),$c=$w.find('.fc'),$s=$w.find('.sh');
  const set=e=>{$c.css('transform','translateZ('+70*(1-e)+'em) rotateZ('+(rz+(1-e)*160)+'deg) rotateX('+(1-e)*tm+'deg)');$s.css({transform:'rotateZ('+rz+'deg) scale('+(1+(1-e)*.6)+')',opacity:e*.55})};
  if(land){set(1);return}
  $({t:0}).animate({t:1},{duration:1300+Math.random()*600,easing:'drop',step:set});
  const all=$('#plane .wr');if(all.length>16)all.first().fadeOut(700,function(){$(this).remove()});
 }
 window.fxRoute=function(p){
  if(p===cur)return;cur=p;$('.bgfx,.gbg').remove();clearInterval(iv);iv=null;
  if(p==='login'){
   if(!$('#plane .wr').length){if(RM){for(let i=0;i<10;i++)drop(true)}else for(let i=0;i<8;i++)setTimeout(drop,300+i*330)}
   if(!RM)iv=setInterval(()=>{if(!document.hidden)drop()},900);
  }else if(p==='game'){
   $('body').prepend('<div class="gbg"><div class="city"></div><div class="lamp a"></div><div class="lamp b"></div><div class="carpet"></div><div class="vg"></div><div class="beam"></div><div class="dust"></div><div class="neon"></div><div class="smoke"></div></div>');
   for(let i=0;i<28;i++)$('<span>').css({left:Math.random()*100+'%',animationDuration:(10+Math.random()*18)+'s',animationDelay:(-Math.random()*24)+'s',opacity:.25+Math.random()*.55}).appendTo('.gbg .dust');
   for(let i=0;i<6;i++)$('<i>').css({left:(8+i*16)+'%',animationDelay:(i*.7)+'s'}).appendTo('.gbg .smoke');
  }else{
   $('body').prepend('<div class="bgfx"><div class="bgimg"></div><div class="veil"></div><div class="fl"></div></div>');const G='♠♥♦♣';
   for(let i=0;i<16;i++)$('<span>').text(G[i%4]).css({left:Math.random()*100+'%',fontSize:(14+Math.random()*34)+'px',animationDuration:(16+Math.random()*20)+'s',animationDelay:(-Math.random()*30)+'s',opacity:.1+Math.random()*.16,color:i%4==1||i%4==2?'#ff7d8e':'#e8d7a8'}).appendTo('.bgfx .fl');
  }
 };
 $(document).on('mousemove',e=>{const x=e.clientX/innerWidth-.5,y=e.clientY/innerHeight-.5;if(cur==='login')$('#scn').css('translate',(-x*26)+'px '+(-y*16)+'px');else $('.bgimg').css('translate',(-x*34)+'px '+(-y*22)+'px')});
})(jQuery);

