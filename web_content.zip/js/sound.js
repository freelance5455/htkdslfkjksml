/* الأصوات والموسيقى تُصنع بالكود (لحن أصلي)، بدون أي ملفات صوتية */
window.Sound = (function () {
  var ctx, master, timer, step = 0, nextAt = 0, muted = false;

  function init() {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    if (!ctx) {
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 1;
      master.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return true;
  }

  function note(midi, at, len, vol, type) {
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'triangle';
    o.frequency.value = 440 * Math.pow(2, (midi - 69) / 12);
    g.gain.setValueAtTime(0.0001, at);
    g.gain.exponentialRampToValueAtTime(vol, at + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, at + len);
    o.connect(g); g.connect(master);
    o.start(at); o.stop(at + len + 0.02);
  }

  /* 4 مقاطع × 8 أنصاف نبضات : C - A - D - G */
  var melody = [76,0,79,76, 72,74,76,0,  73,0,76,73, 69,71,73,0,
                74,0,77,74, 69,72,74,77,  79,77,74,71, 67,0,71,0];
  var bass   = [48,43, 45,40, 50,45, 43,38];
  var chords = [[60,64,67],[61,64,69],[60,65,69],[59,62,67]];
  var EIGHTH = 0.2;

  function schedule() {
    while (nextAt < ctx.currentTime + 0.4) {
      var i = step % 32, bar = Math.floor(i / 8), beat = i % 8;
      if (melody[i]) note(melody[i], nextAt, 0.24, 0.11, 'triangle');
      if (beat === 0 || beat === 4) note(bass[bar * 2 + beat / 4], nextAt, 0.3, 0.16, 'sine');
      if (beat === 2 || beat === 6) chords[bar].forEach(function (m) { note(m, nextAt, 0.16, 0.035, 'square'); });
      nextAt += EIGHTH; step++;
    }
  }

  return {
    music: function () {
      if (!init() || timer) return;
      nextAt = ctx.currentTime + 0.05;
      timer = setInterval(schedule, 100);
      schedule();
    },
    stopMusic: function () { clearInterval(timer); timer = null; },
    restart: function () { step = 0; },
    beep: function (midi) { if (init()) note(midi || 72, ctx.currentTime, 0.18, 0.15); },
    win: function () {
      if (init()) [72, 76, 79, 84].forEach(function (m, i) { note(m, ctx.currentTime + i * 0.12, 0.35, 0.16); });
    },
    toggleMute: function () {
      muted = !muted;
      if (master) master.gain.value = muted ? 0 : 1;
      return muted;
    }
  };
})();
