/**
 * Panchal Business Manager - Complete Double-Entry Accounting, Bank Reconciliation & Reports Suite
 * Chart of Accounts (Opening Balances), Multi-line Journal Entries, General Ledger,
 * Cash/Bank Book & Reconciliation, Trial Balance, P&L, Balance Sheet, Cash Flow & GST/Business Reports.
 */
(function (global) {
  "use strict";

  const I18N = {
    en: {
      tabReports: "Reports Hub",
      tabLedger: "General Ledger",
      tabCashBank: "Cash, Bank & Reconcile",
      tabJournal: "Journal Entries",
      tabCoa: "Chart of Accounts",
      newJournalBtn: "+ Journal Entry",
      newAccountBtn: "+ Add Account",
      exportCsvBtn: "Export CSV",
      printReportBtn: "Print / PDF",
      fromDate: "From",
      toDate: "To",
      reportTypeLabel: "Select Report",
      pnlTitle: "Profit & Loss Statement",
      incomeLabel: "Total Income",
      expenseLabel: "Total Expenses",
      netProfitLabel: "Net Profit / (Loss)",
      bsTitle: "Balance Sheet Summary",
      assetsLabel: "Total Assets",
      liabLabel: "Total Liabilities",
      equityLabel: "Capital + Net Profit",
      gstTitle: "GST Summary",
      gstOutLabel: "Output GST (Sales)",
      gstInLabel: "Input GST Credit (Purchases/Exp)",
      gstNetLabel: "Net GST Payable / (Credit)",
      tbTitle: "Trial Balance",
      cashInLabel: "Cash & Bank Inflow",
      cashOutLabel: "Cash & Bank Outflow",
      netCashLabel: "Net Cash/Bank Balance",
      noJournalMsg: "No journal entries yet. Create invoices or add manual journal entries.",
      noCashMsg: "No cash or bank transactions recorded yet.",
      modalJournalTitle: "New Balanced Journal Entry",
      fieldDate: "Date *",
      fieldNarration: "Narration *",
      errUnbalanced: "Total Debit must equal Total Credit and be greater than 0.",
      toastJournalSaved: "Journal entry posted.",
      modalAccountTitle: "Account Details",
      fieldAccCode: "Account Code",
      fieldAccName: "Account Name *",
      fieldAccGroup: "Account Group",
      fieldOpenBal: "Opening Balance (₹)",
      toastAccSaved: "Account saved.",
      saveBtn: "Save",
      cancelBtn: "Cancel",
      deleteBtn: "Delete"
    },
    hi: {
      tabReports: "रिपोर्ट्स हब",
      tabLedger: "जनरल लेजर",
      tabCashBank: "कैश, बैंक व रिकंसिलिएशन",
      tabJournal: "जर्नल एंट्री",
      tabCoa: "चार्ट ऑफ़ अकाउंट्स",
      newJournalBtn: "+ नई जर्नल एंट्री",
      newAccountBtn: "+ नया खाता",
      exportCsvBtn: "CSV डाउनलोड",
      printReportBtn: "प्रिंट / PDF",
      fromDate: "तारीख़ से",
      toDate: "तारीख़ तक",
      reportTypeLabel: "रिपोर्ट चुनें",
      pnlTitle: "लाभ और हानि (Profit & Loss)",
      incomeLabel: "कुल आय (Income)",
      expenseLabel: "कुल खर्च (Expenses)",
      netProfitLabel: "शुद्ध लाभ / (हानि)",
      bsTitle: "बैलेंस शीट सारांश (Balance Sheet)",
      assetsLabel: "कुल संपत्ति (Assets)",
      liabLabel: "कुल देनदारियाँ (Liabilities)",
      equityLabel: "पूंजी + शुद्ध लाभ",
      gstTitle: "GST सारांश (Summary)",
      gstOutLabel: "बिक्री पर GST (Output)",
      gstInLabel: "खरीद पर ITC (Input)",
      gstNetLabel: "शुद्ध देय GST",
      tbTitle: "ट्रायल बैलेंस (Trial Balance)",
      cashInLabel: "कैश / बैंक में आया",
      cashOutLabel: "कैश / बैंक से गया",
      netCashLabel: "बचा हुआ कैश/बैंक बैलेंस",
      noJournalMsg: "अभी कोई जर्नल एंट्री नहीं है। बिल बनाएँ या मैन्युअल एंट्री करें।",
      noCashMsg: "अभी कैश या बैंक का कोई लेन-देन नहीं है।",
      modalJournalTitle: "नई डबल-एंट्री जर्नल",
      fieldDate: "तारीख़ *",
      fieldNarration: "विवरण (Narration) *",
      errUnbalanced: "कुल डेबिट और कुल क्रेडिट बराबर (0 से ज़्यादा) होने चाहिए।",
      toastJournalSaved: "जर्नल एंट्री सेव हो गई।",
      modalAccountTitle: "खाता विवरण",
      fieldAccCode: "खाता कोड",
      fieldAccName: "खाते का नाम *",
      fieldAccGroup: "खाते का समूह",
      fieldOpenBal: "शुरुआती बकाया (₹)",
      toastAccSaved: "खाता सेव हो गया।",
      saveBtn: "सेव करें",
      cancelBtn: "रद्द करें",
      deleteBtn: "हटाएँ"
    }
  };

  const REPORT_TYPES = [
    { id: "overview", label: "Overview (P&L / Balance Sheet / GST / Trial Balance)" },
    { id: "sales", label: "Sales Summary" },
    { id: "purchase", label: "Purchase Summary" },
    { id: "gst", label: "GST Summary (CGST/SGST/IGST/Cess/RCM)" },
    { id: "expense", label: "Expense Summary" },
    { id: "cashflow", label: "Cash Flow Statement" },
    { id: "outstanding", label: "Outstanding & Overdue Invoices" },
    { id: "customer_sales", label: "Customer-wise Sales" },
    { id: "item_sales", label: "Item-wise Sales" },
    { id: "stock", label: "Stock Valuation Summary" },
    { id: "staff_project", label: "Staff Payroll & Project Profit Report" }
  ];

  const viewState = {
    tab: "reports",
    ledgerMode: "account",
    ledgerSearch: "",
    reportType: "overview",
    fromDate: "",
    toDate: "",
    selectedLedgerAccId: "",
    selectedPartyLedgerId: "",
    bankStmtBalance: "",
    accounts: [],
    journals: [],
    vouchers: [],
    items: [],
    projects: [],
    projectEntries: [],
    payroll: [],
    parties: []
  };

  function tr(key) {
    const lang = global.PBM_APP.getLang();
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function inDateRange(dateStr) {
    const d = dateStr || "";
    if (viewState.fromDate && d < viewState.fromDate) return false;
    if (viewState.toDate && d > viewState.toDate) return false;
    return true;
  }

  function computeAccountBalances(upToDateOnly) {
    const mapById = {};
    const mapBySysKey = {};
    viewState.accounts.forEach(function (acc) {
      const ob = Number(acc.openingBalance) || 0;
      const isCreditNormal = acc.group === "LIABILITY" || acc.group === "EQUITY" || acc.group === "INCOME";
      const rec = {
        account: acc,
        debit: ob > 0 && !isCreditNormal ? ob : 0,
        credit: ob > 0 && isCreditNormal ? ob : 0
      };
      mapById[acc.id] = rec;
      if (acc.systemKey) mapBySysKey[acc.systemKey] = rec;
    });

    viewState.journals.forEach(function (j) {
      if (upToDateOnly ? viewState.toDate && (j.date || "") > viewState.toDate : !inDateRange(j.date)) {
        return;
      }
      (j.lines || []).forEach(function (line) {
        const target = mapById[line.accountId] || mapBySysKey[line.accountKey];
        if (!target) return;
        target.debit += Number(line.debit) || 0;
        target.credit += Number(line.credit) || 0;
      });
    });

    return Object.keys(mapById).map(function (id) {
      const item = mapById[id];
      const net = Math.round((item.debit - item.credit) * 100) / 100;
      return {
        account: item.account,
        debit: Math.round(item.debit * 100) / 100,
        credit: Math.round(item.credit * 100) / 100,
        netDrMinusCr: net
      };
    });
  }

  function downloadCsv(filename, rows) {
    const csv = rows
      .map(function (r) {
        return r
          .map(function (cell) {
            const s = String(cell == null ? "" : cell);
            return s.indexOf(",") !== -1 || s.indexOf('"') !== -1 ? '"' + s.replace(/"/g, '""') + '"' : s;
          })
          .join(",");
      })
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function openJournalModal() {
    const app = global.PBM_APP;
    const today = new Date().toISOString().slice(0, 10);
    const jLines = [
      { accountId: viewState.accounts[0] ? viewState.accounts[0].id : "", debit: 0, credit: 0 },
      { accountId: viewState.accounts[1] ? viewState.accounts[1].id : "", debit: 0, credit: 0 }
    ];

    const accOptsHtml = function (selectedId) {
      return viewState.accounts
        .map(function (a) {
          return `<option value="${app.escapeHtml(a.id)}" ${a.id === selectedId ? "selected" : ""}>${app.escapeHtml(a.code + " · " + a.name)} (${app.escapeHtml(a.group)})</option>`;
        })
        .join("");
    };

    const html = `
      <form id="jrnForm" class="form-grid" novalidate>
        <div id="jrnErr" class="form-error hidden"></div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="jrnDate">${tr("fieldDate")}</label>
            <input id="jrnDate" class="form-input" type="date" value="${today}" required />
          </div>
          <div class="form-group">
            <label class="form-label" for="jrnNarr">${tr("fieldNarration")}</label>
            <input id="jrnNarr" class="form-input" type="text" required />
          </div>
        </div>
        <div class="card-header-row" style="margin:0;">
          <strong>Journal Lines</strong>
          <button id="jrnAddLineBtn" class="secondary-btn" type="button">+ Line</button>
        </div>
        <div id="jrnLinesWrap" class="list-stack"></div>
        <div id="jrnTotalsBox" class="ledger-summary-box"></div>
        <div class="modal-actions">
          <button id="jrnCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(tr("modalJournalTitle"), html);
    document.getElementById("jrnCancelBtn").addEventListener("click", app.closeModal);

    function updateTotals() {
      const dr = jLines.reduce(function (s, l) { return s + (Number(l.debit) || 0); }, 0);
      const cr = jLines.reduce(function (s, l) { return s + (Number(l.credit) || 0); }, 0);
      const ok = dr > 0 && Math.abs(dr - cr) < 0.01;
      document.getElementById("jrnTotalsBox").innerHTML = `
        <span>Dr: <strong>${app.formatCurrency(dr)}</strong></span>
        <span>Cr: <strong>${app.formatCurrency(cr)}</strong></span>
        <span class="${ok ? "text-receivable" : "text-payable"}">${ok ? "Balanced ✓" : "Diff: " + app.formatCurrency(Math.abs(dr - cr))}</span>
      `;
    }

    function renderJLines() {
      const wrap = document.getElementById("jrnLinesWrap");
      wrap.innerHTML = jLines
        .map(function (l, idx) {
          return `
            <div class="list-item-card" style="padding:10px;background:var(--bg-canvas);">
              <div class="form-group">
                <select class="form-select" data-jl-acc="${idx}">${accOptsHtml(l.accountId)}</select>
              </div>
              <div class="form-row-2">
                <div class="form-group">
                  <label class="form-label">Debit (₹)</label>
                  <input class="form-input" type="number" min="0" step="0.01" data-jl-dr="${idx}" value="${l.debit}" />
                </div>
                <div class="form-group">
                  <label class="form-label">Credit (₹)</label>
                  <input class="form-input" type="number" min="0" step="0.01" data-jl-cr="${idx}" value="${l.credit}" />
                </div>
              </div>
              ${jLines.length > 2 ? `<button class="mini-danger-btn" type="button" data-jl-rem="${idx}">Remove</button>` : ""}
            </div>
          `;
        })
        .join("");

      jLines.forEach(function (l, idx) {
        wrap.querySelector('[data-jl-acc="' + idx + '"]').addEventListener("change", function (e) { l.accountId = e.target.value; });
        wrap.querySelector('[data-jl-dr="' + idx + '"]').addEventListener("input", function (e) { l.debit = parseFloat(e.target.value) || 0; updateTotals(); });
        wrap.querySelector('[data-jl-cr="' + idx + '"]').addEventListener("input", function (e) { l.credit = parseFloat(e.target.value) || 0; updateTotals(); });
        const rb = wrap.querySelector('[data-jl-rem="' + idx + '"]');
        if (rb) {
          rb.addEventListener("click", function () { jLines.splice(idx, 1); renderJLines(); });
        }
      });
      updateTotals();
    }

    renderJLines();
    document.getElementById("jrnAddLineBtn").addEventListener("click", function () {
      jLines.push({ accountId: viewState.accounts[0] ? viewState.accounts[0].id : "", debit: 0, credit: 0 });
      renderJLines();
    });

    document.getElementById("jrnForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const err = document.getElementById("jrnErr");
      const dr = jLines.reduce(function (s, l) { return s + (Number(l.debit) || 0); }, 0);
      const cr = jLines.reduce(function (s, l) { return s + (Number(l.credit) || 0); }, 0);
      const cleanLines = jLines.filter(function (l) { return (Number(l.debit) || 0) > 0 || (Number(l.credit) || 0) > 0; });

      if (dr <= 0 || Math.abs(dr - cr) >= 0.01 || cleanLines.length < 2) {
        err.textContent = tr("errUnbalanced");
        err.classList.remove("hidden");
        return;
      }

      const businessId = app.getActiveBusinessId();
      const now = new Date().toISOString();
      global.PBM_DB.put("journalEntries", {
        id: global.PBM_DB.generateId("jrn"),
        businessId: businessId,
        date: document.getElementById("jrnDate").value || today,
        narration: document.getElementById("jrnNarr").value.trim() || "Manual Journal",
        lines: cleanLines,
        isAuto: false,
        createdAt: now,
        updatedAt: now
      }).then(function () {
        app.closeModal();
        app.showToast(tr("toastJournalSaved"), false);
        app.renderCurrentRoute();
      });
    });
  }

  function openAccountModal(existingAcc) {
    const app = global.PBM_APP;
    const isEdit = Boolean(existingAcc);
    const acc = existingAcc || { code: "5900", name: "", group: "EXPENSE", openingBalance: 0 };

    const html = `
      <form id="accForm" class="form-grid" novalidate>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="accCode">${tr("fieldAccCode")}</label>
            <input id="accCode" class="form-input" type="text" value="${app.escapeHtml(acc.code)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="accGroup">${tr("fieldAccGroup")}</label>
            <select id="accGroup" class="form-select" ${isEdit && acc.systemKey ? "disabled" : ""}>
              <option value="ASSET" ${acc.group === "ASSET" ? "selected" : ""}>ASSET</option>
              <option value="LIABILITY" ${acc.group === "LIABILITY" ? "selected" : ""}>LIABILITY</option>
              <option value="EQUITY" ${acc.group === "EQUITY" ? "selected" : ""}>EQUITY</option>
              <option value="INCOME" ${acc.group === "INCOME" ? "selected" : ""}>INCOME</option>
              <option value="EXPENSE" ${acc.group === "EXPENSE" ? "selected" : ""}>EXPENSE</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="accName">${tr("fieldAccName")}</label>
          <input id="accName" class="form-input" type="text" required value="${app.escapeHtml(acc.name)}" />
        </div>
        <div class="form-group">
          <label class="form-label" for="accOpenBal">${tr("fieldOpenBal")}</label>
          <input id="accOpenBal" class="form-input" type="number" min="0" step="0.01" value="${Number(acc.openingBalance || 0)}" />
        </div>
        <div class="modal-actions">
          <button id="accCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;
    app.openModal(tr("modalAccountTitle"), html);
    document.getElementById("accCancelBtn").addEventListener("click", app.closeModal);
    document.getElementById("accForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("accName").value.trim();
      if (name.length < 2) return;
      const now = new Date().toISOString();
      const rec = Object.assign({}, acc, {
        id: isEdit ? acc.id : global.PBM_DB.generateId("acc"),
        businessId: app.getActiveBusinessId(),
        code: document.getElementById("accCode").value.trim() || "9999",
        name: name,
        group: document.getElementById("accGroup").value,
        openingBalance: Math.max(0, parseFloat(document.getElementById("accOpenBal").value) || 0),
        createdAt: isEdit ? acc.createdAt : now,
        updatedAt: now
      });
      global.PBM_DB.put("accounts", rec).then(function () {
        app.closeModal();
        app.showToast(tr("toastAccSaved"), false);
        app.renderCurrentRoute();
      });
    });
  }

  function buildActiveReportData() {
    const app = global.PBM_APP;
    const vouchersInRange = viewState.vouchers.filter(function (v) {
      return v.status !== "VOID" && inDateRange(v.date);
    });
    const today = new Date().toISOString().slice(0, 10);

    const balances = computeAccountBalances(false);
    let totalIncome = 0;
    let totalExpense = 0;
    let totalAssets = 0;
    let totalLiab = 0;
    let totalEquity = 0;
    let gstOut = 0;
    let gstIn = 0;

    balances.forEach(function (b) {
      const grp = b.account.group;
      if (grp === "INCOME") totalIncome += b.credit - b.debit;
      if (grp === "EXPENSE") totalExpense += b.debit - b.credit;
      if (grp === "ASSET") totalAssets += b.debit - b.credit;
      if (grp === "LIABILITY") totalLiab += b.credit - b.debit;
      if (grp === "EQUITY") totalEquity += b.credit - b.debit;
      if (b.account.systemKey === "GST_OUTPUT") gstOut = b.credit - b.debit;
      if (b.account.systemKey === "GST_INPUT") gstIn = b.debit - b.credit;
    });

    const siteExpenseSum = viewState.projectEntries
      .filter(function (pe) { return (pe.entryType === "EXPENSE" || pe.entryType === "CONTRACTOR_MATERIAL") && inDateRange(pe.date); })
      .reduce(function (s, pe) { return s + (Number(pe.amount) || 0); }, 0);
    const paidPayrollSum = viewState.payroll
      .filter(function (pr) { return pr.status === "PAID" && inDateRange(pr.paidDate || pr.month); })
      .reduce(function (s, pr) { return s + (Number(pr.netPayable) || 0); }, 0);

    totalExpense += siteExpenseSum + paidPayrollSum;
    const netProfit = Math.round((totalIncome - totalExpense) * 100) / 100;
    const netGst = Math.round((gstOut - gstIn) * 100) / 100;

    const rType = viewState.reportType;
    if (rType === "sales") {
      const rows = vouchersInRange.filter(function (v) {
        return v.voucherType === "SALE_INVOICE" || v.voucherType === "BILL_OF_SUPPLY" || v.voucherType === "CREDIT_NOTE";
      });
      const csv = [["Date", "Doc No", "Type", "Party", "Taxable", "Tax", "Total"]];
      rows.forEach(function (v) {
        csv.push([v.date, v.voucherNo, v.voucherType, v.partyName, Number(v.subtotal || 0).toFixed(2), Number(v.taxTotal || 0).toFixed(2), Number(v.grandTotal || 0).toFixed(2)]);
      });
      return {
        title: "Sales Summary",
        csvName: "sales-summary.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Sales Summary (${rows.length} docs)</h3>
            <div class="ledger-list">
              ${rows.map(function (v) {
                return `<div class="ledger-row"><div class="ledger-row-main"><div class="ledger-row-title">${app.escapeHtml(v.voucherNo)} · ${app.escapeHtml(v.partyName)}</div><div class="list-item-meta">${app.escapeHtml(v.date)} · ${v.voucherType}</div></div><div class="ledger-row-right tabular-nums">${app.formatCurrency(v.grandTotal)}</div></div>`;
              }).join("") || `<div class="info-note">No sales in selected period.</div>`}
            </div>
          </div>
        `
      };
    }

    if (rType === "purchase") {
      const rows = vouchersInRange.filter(function (v) {
        return v.voucherType === "PURCHASE_BILL" || v.voucherType === "DEBIT_NOTE";
      });
      const csv = [["Date", "Doc No", "Type", "Supplier", "Taxable", "Tax", "Total"]];
      rows.forEach(function (v) {
        csv.push([v.date, v.voucherNo, v.voucherType, v.partyName, Number(v.subtotal || 0).toFixed(2), Number(v.taxTotal || 0).toFixed(2), Number(v.grandTotal || 0).toFixed(2)]);
      });
      return {
        title: "Purchase Summary",
        csvName: "purchase-summary.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Purchase Summary (${rows.length} bills)</h3>
            <div class="ledger-list">
              ${rows.map(function (v) {
                return `<div class="ledger-row"><div class="ledger-row-main"><div class="ledger-row-title">${app.escapeHtml(v.voucherNo)} · ${app.escapeHtml(v.partyName)}</div><div class="list-item-meta">${app.escapeHtml(v.date)} · ${v.voucherType}</div></div><div class="ledger-row-right tabular-nums">${app.formatCurrency(v.grandTotal)}</div></div>`;
              }).join("") || `<div class="info-note">No purchases in selected period.</div>`}
            </div>
          </div>
        `
      };
    }

    if (rType === "gst") {
      let cgstOut = 0, sgstOut = 0, igstOut = 0, cessOut = 0, rcmTotal = 0;
      const posMap = {};
      vouchersInRange.forEach(function (v) {
        if (v.gstMode === "NON_GST") return;
        const tax = Number(v.taxTotal || 0);
        const cess = Number(v.cessTotal || 0);
        if (v.voucherType === "SALE_INVOICE") {
          if (v.supplyType === "INTER") igstOut += tax;
          else { cgstOut += tax / 2; sgstOut += tax / 2; }
          cessOut += cess;
          const pos = v.placeOfSupply || "Local";
          posMap[pos] = (posMap[pos] || 0) + (Number(v.subtotal) || 0);
        }
        if (v.reverseCharge) rcmTotal += Number(v.grandTotal) || 0;
      });
      const csv = [["Metric", "Amount"], ["CGST Output", cgstOut.toFixed(2)], ["SGST Output", sgstOut.toFixed(2)], ["IGST Output", igstOut.toFixed(2)], ["Cess Output", cessOut.toFixed(2)], ["Input Tax Credit", gstIn.toFixed(2)], ["Net GST Payable", netGst.toFixed(2)]];
      return {
        title: "GST Summary",
        csvName: "gst-summary.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">${tr("gstTitle")} (Configurable Local Computation)</h3>
            <div class="ledger-list" style="margin-top:8px;">
              <div class="ledger-row"><span>Output CGST</span><strong class="tabular-nums">${app.formatCurrency(cgstOut)}</strong></div>
              <div class="ledger-row"><span>Output SGST</span><strong class="tabular-nums">${app.formatCurrency(sgstOut)}</strong></div>
              <div class="ledger-row"><span>Output IGST</span><strong class="tabular-nums">${app.formatCurrency(igstOut)}</strong></div>
              <div class="ledger-row"><span>Output Cess</span><strong class="tabular-nums">${app.formatCurrency(cessOut)}</strong></div>
              <div class="ledger-row"><span>${tr("gstInLabel")}</span><strong class="tabular-nums">${app.formatCurrency(gstIn)}</strong></div>
              <div class="ledger-row"><span>Reverse Charge (RCM) Turnover</span><strong class="tabular-nums">${app.formatCurrency(rcmTotal)}</strong></div>
              <div class="ledger-row"><strong>${tr("gstNetLabel")}</strong><strong class="tabular-nums">${app.formatCurrency(netGst)}</strong></div>
            </div>
            <div class="info-note">Place of Supply Taxable Turnover: ${Object.keys(posMap).map(function (k) { return app.escapeHtml(k) + ": " + app.formatCurrency(posMap[k]); }).join(" · ") || "None"}</div>
          </div>
        `
      };
    }

    if (rType === "expense") {
      const expVouchers = vouchersInRange.filter(function (v) { return v.voucherType === "EXPENSE_VOUCHER"; });
      const expTotal = expVouchers.reduce(function (s, v) { return s + (Number(v.grandTotal) || 0); }, 0);
      const csv = [["Category", "Amount"], ["Expense Vouchers", expTotal.toFixed(2)], ["Site & Contractor Expenses", siteExpenseSum.toFixed(2)], ["Paid Payroll", paidPayrollSum.toFixed(2)]];
      return {
        title: "Expense Summary",
        csvName: "expense-summary.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Expense Summary</h3>
            <div class="ledger-list">
              <div class="ledger-row"><span>Expense Vouchers (${expVouchers.length})</span><strong class="tabular-nums text-payable">${app.formatCurrency(expTotal)}</strong></div>
              <div class="ledger-row"><span>Site &amp; Contractor Material</span><strong class="tabular-nums text-payable">${app.formatCurrency(siteExpenseSum)}</strong></div>
              <div class="ledger-row"><span>Paid Staff Salaries</span><strong class="tabular-nums text-payable">${app.formatCurrency(paidPayrollSum)}</strong></div>
              <div class="ledger-row"><strong>Total Direct + Operating Expenses</strong><strong class="tabular-nums text-payable">${app.formatCurrency(expTotal + siteExpenseSum + paidPayrollSum)}</strong></div>
            </div>
          </div>
        `
      };
    }

    if (rType === "cashflow") {
      let inflow = 0, outflow = 0;
      vouchersInRange.forEach(function (v) {
        if (v.voucherType === "RECEIPT") inflow += Number(v.amount || 0);
        if (v.voucherType === "PAYMENT" || v.voucherType === "EXPENSE_VOUCHER") outflow += Number(v.paidAmount != null ? v.paidAmount : v.amount || 0);
      });
      outflow += siteExpenseSum + paidPayrollSum;
      const csv = [["Cash Flow Metric", "Amount"], ["Cash & Bank Inflow", inflow.toFixed(2)], ["Cash & Bank Outflow", outflow.toFixed(2)], ["Net Cash Flow", (inflow - outflow).toFixed(2)]];
      return {
        title: "Cash Flow Statement",
        csvName: "cash-flow.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Cash Flow Statement</h3>
            <div class="ledger-list">
              <div class="ledger-row"><span>Operating Receipts (Inflow)</span><strong class="tabular-nums text-receivable">${app.formatCurrency(inflow)}</strong></div>
              <div class="ledger-row"><span>Payments, Expenses, Site &amp; Payroll (Outflow)</span><strong class="tabular-nums text-payable">${app.formatCurrency(outflow)}</strong></div>
              <div class="ledger-row"><strong>Net Cash Flow</strong><strong class="tabular-nums">${app.formatCurrency(inflow - outflow)}</strong></div>
            </div>
          </div>
        `
      };
    }

    if (rType === "outstanding") {
      const pending = viewState.vouchers.filter(function (v) {
        if (v.status === "VOID") return false;
        if (v.voucherType !== "SALE_INVOICE" && v.voucherType !== "BILL_OF_SUPPLY" && v.voucherType !== "PURCHASE_BILL") return false;
        const due = (Number(v.grandTotal) || 0) - (Number(v.paidAmount) || 0);
        return due > 0.01;
      });
      const csv = [["Doc No", "Type", "Party", "Date", "Due Date", "Balance Due", "Overdue?"]];
      pending.forEach(function (v) {
        const bal = (Number(v.grandTotal) || 0) - (Number(v.paidAmount) || 0);
        const over = v.dueDate && v.dueDate < today ? "OVERDUE" : "OPEN";
        csv.push([v.voucherNo, v.voucherType, v.partyName, v.date, v.dueDate || "-", bal.toFixed(2), over]);
      });
      return {
        title: "Outstanding & Overdue Invoices",
        csvName: "outstanding-invoices.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Outstanding &amp; Overdue (${pending.length})</h3>
            <div class="ledger-list">
              ${pending.map(function (v) {
                const bal = (Number(v.grandTotal) || 0) - (Number(v.paidAmount) || 0);
                const over = v.dueDate && v.dueDate < today;
                return `<div class="ledger-row"><div class="ledger-row-main"><div class="ledger-row-title">${app.escapeHtml(v.voucherNo)} · ${app.escapeHtml(v.partyName)}</div><div class="list-item-meta">${v.voucherType} · Due: ${app.escapeHtml(v.dueDate || "-")} ${over ? "<strong class='text-payable'>(OVERDUE)</strong>" : ""}</div></div><div class="ledger-row-right tabular-nums text-payable">${app.formatCurrency(bal)}</div></div>`;
              }).join("") || `<div class="info-note">No outstanding invoices or bills.</div>`}
            </div>
          </div>
        `
      };
    }

    if (rType === "customer_sales") {
      const map = {};
      vouchersInRange.forEach(function (v) {
        if (v.voucherType !== "SALE_INVOICE" && v.voucherType !== "BILL_OF_SUPPLY") return;
        const k = v.partyName || "Walk-in";
        if (!map[k]) map[k] = { count: 0, total: 0 };
        map[k].count += 1;
        map[k].total += Number(v.grandTotal) || 0;
      });
      const list = Object.keys(map).map(function (k) { return { name: k, count: map[k].count, total: map[k].total }; }).sort(function (a, b) { return b.total - a.total; });
      const csv = [["Customer", "Invoices", "Total Sales"]];
      list.forEach(function (r) { csv.push([r.name, r.count, r.total.toFixed(2)]); });
      return {
        title: "Customer-wise Sales",
        csvName: "customer-sales.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Customer-wise Sales</h3>
            <div class="ledger-list">
              ${list.map(function (r) {
                return `<div class="ledger-row"><div class="ledger-row-main"><div class="ledger-row-title">${app.escapeHtml(r.name)}</div><div class="list-item-meta">${r.count} invoices</div></div><div class="ledger-row-right tabular-nums text-receivable">${app.formatCurrency(r.total)}</div></div>`;
              }).join("") || `<div class="info-note">No customer sales yet.</div>`}
            </div>
          </div>
        `
      };
    }

    if (rType === "item_sales") {
      const map = {};
      vouchersInRange.forEach(function (v) {
        if (v.voucherType !== "SALE_INVOICE" && v.voucherType !== "BILL_OF_SUPPLY") return;
        (v.items || []).forEach(function (l) {
          const k = l.name || "Item";
          if (!map[k]) map[k] = { qty: 0, total: 0 };
          map[k].qty += Number(l.qty) || 0;
          map[k].total += Number(l.lineTotal) || 0;
        });
      });
      const list = Object.keys(map).map(function (k) { return { name: k, qty: map[k].qty, total: map[k].total }; }).sort(function (a, b) { return b.total - a.total; });
      const csv = [["Item", "Qty Sold", "Sales Value"]];
      list.forEach(function (r) { csv.push([r.name, r.qty, r.total.toFixed(2)]); });
      return {
        title: "Item-wise Sales",
        csvName: "item-sales.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Item-wise Sales</h3>
            <div class="ledger-list">
              ${list.map(function (r) {
                return `<div class="ledger-row"><div class="ledger-row-main"><div class="ledger-row-title">${app.escapeHtml(r.name)}</div><div class="list-item-meta">Qty: ${r.qty}</div></div><div class="ledger-row-right tabular-nums text-receivable">${app.formatCurrency(r.total)}</div></div>`;
              }).join("") || `<div class="info-note">No item sales yet.</div>`}
            </div>
          </div>
        `
      };
    }

    if (rType === "stock") {
      const rows = viewState.items.filter(function (i) { return i.type !== "SERVICE"; }).map(function (i) {
        const qty = global.PBM_INVENTORY ? global.PBM_INVENTORY.getTotalStock(i) : 0;
        const rate = Number(i.purchasePrice) || Number(i.salePrice) || 0;
        return { name: i.name, qty: qty, unit: i.unit || "Pcs", val: Math.round(Math.max(0, qty) * rate * 100) / 100 };
      });
      const csv = [["Item", "Stock", "Unit", "Valuation"]];
      rows.forEach(function (r) { csv.push([r.name, r.qty, r.unit, r.val.toFixed(2)]); });
      return {
        title: "Stock Valuation Summary",
        csvName: "stock-valuation.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Stock Valuation Summary</h3>
            <div class="ledger-list">
              ${rows.map(function (r) {
                return `<div class="ledger-row"><div class="ledger-row-main"><div class="ledger-row-title">${app.escapeHtml(r.name)}</div><div class="list-item-meta">${r.qty} ${app.escapeHtml(r.unit)}</div></div><div class="ledger-row-right tabular-nums">${app.formatCurrency(r.val)}</div></div>`;
              }).join("") || `<div class="info-note">No products in inventory.</div>`}
            </div>
          </div>
        `
      };
    }

    if (rType === "staff_project") {
      const projHtml = viewState.projects.map(function (p) {
        const entries = viewState.projectEntries.filter(function (e) { return e.projectId === p.id; });
        const cost = entries.filter(function (e) { return e.entryType === "EXPENSE" || e.entryType === "CONTRACTOR_MATERIAL"; }).reduce(function (s, e) { return s + (Number(e.amount) || 0); }, 0);
        const rec = entries.filter(function (e) { return e.entryType === "CLIENT_PAYMENT"; }).reduce(function (s, e) { return s + (Number(e.amount) || 0); }, 0);
        const profit = (Number(p.contractValue) || 0) - cost;
        return { name: p.name, contract: Number(p.contractValue) || 0, cost: cost, rec: rec, profit: profit };
      });
      const csv = [["Project", "Contract Value", "Site Cost", "Client Received", "Est Profit"]];
      projHtml.forEach(function (r) { csv.push([r.name, r.contract.toFixed(2), r.cost.toFixed(2), r.rec.toFixed(2), r.profit.toFixed(2)]); });
      return {
        title: "Staff & Project Report",
        csvName: "staff-project-report.csv",
        csvRows: csv,
        html: `
          <div class="card">
            <h3 class="card-title">Project Profit &amp; Staff Payroll Summary</h3>
            <div class="ledger-list">
              <div class="ledger-row"><span>Total Paid Payroll (Period)</span><strong class="tabular-nums text-payable">${app.formatCurrency(paidPayrollSum)}</strong></div>
              ${projHtml.map(function (r) {
                return `<div class="ledger-row"><div class="ledger-row-main"><div class="ledger-row-title">${app.escapeHtml(r.name)}</div><div class="list-item-meta">Contract: ${app.formatCurrency(r.contract)} · Cost: ${app.formatCurrency(r.cost)}</div></div><div class="ledger-row-right tabular-nums ${r.profit >= 0 ? "text-receivable" : "text-payable"}">${app.formatCurrency(r.profit)}</div></div>`;
              }).join("") || `<div class="info-note">No site projects found.</div>`}
            </div>
          </div>
        `
      };
    }

    // Default: overview
    const tbCsv = [["Code", "Account Name", "Group", "Debit", "Credit"]];
    balances.forEach(function (b) {
      tbCsv.push([b.account.code, b.account.name, b.account.group, b.debit.toFixed(2), b.credit.toFixed(2)]);
    });

    const tbRows = balances
      .map(function (b) {
        return `
          <div class="ledger-row">
            <div class="ledger-row-main">
              <div class="ledger-row-title">${app.escapeHtml(b.account.code + " · " + b.account.name)}</div>
              <div class="list-item-meta">${app.escapeHtml(b.account.group)}</div>
            </div>
            <div class="ledger-row-right tabular-nums">
              <span>Dr: ${app.formatCurrency(b.debit)}</span>
              <span>Cr: ${app.formatCurrency(b.credit)}</span>
            </div>
          </div>
        `;
      })
      .join("");

    return {
      title: "Financial Overview (P&L / Balance Sheet / Trial Balance)",
      csvName: "trial-balance.csv",
      csvRows: tbCsv,
      html: `
        <div class="card">
          <h3 class="card-title">${tr("pnlTitle")}</h3>
          <div class="ledger-list">
            <div class="ledger-row"><span>${tr("incomeLabel")}</span><strong class="tabular-nums text-receivable">${app.formatCurrency(totalIncome)}</strong></div>
            <div class="ledger-row"><span>${tr("expenseLabel")}</span><strong class="tabular-nums text-payable">${app.formatCurrency(totalExpense)}</strong></div>
            <div class="ledger-row"><strong>${tr("netProfitLabel")}</strong><strong class="tabular-nums ${netProfit >= 0 ? "text-receivable" : "text-payable"}">${app.formatCurrency(netProfit)}</strong></div>
          </div>
        </div>
        <div class="card">
          <h3 class="card-title">${tr("gstTitle")}</h3>
          <div class="ledger-list">
            <div class="ledger-row"><span>${tr("gstOutLabel")}</span><strong class="tabular-nums">${app.formatCurrency(gstOut)}</strong></div>
            <div class="ledger-row"><span>${tr("gstInLabel")}</span><strong class="tabular-nums">${app.formatCurrency(gstIn)}</strong></div>
            <div class="ledger-row"><strong>${tr("gstNetLabel")}</strong><strong class="tabular-nums">${app.formatCurrency(netGst)}</strong></div>
          </div>
        </div>
        <div class="card">
          <h3 class="card-title">${tr("bsTitle")}</h3>
          <div class="ledger-list">
            <div class="ledger-row"><span>${tr("assetsLabel")}</span><strong class="tabular-nums">${app.formatCurrency(totalAssets)}</strong></div>
            <div class="ledger-row"><span>${tr("liabLabel")}</span><strong class="tabular-nums">${app.formatCurrency(totalLiab)}</strong></div>
            <div class="ledger-row"><span>${tr("equityLabel")}</span><strong class="tabular-nums">${app.formatCurrency(totalEquity + netProfit)}</strong></div>
          </div>
        </div>
        <div class="card">
          <h3 class="card-title">${tr("tbTitle")}</h3>
          <div class="ledger-list">${tbRows}</div>
        </div>
      `
    };
  }

  function render(viewContainer, contextStripHtml) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    return global.PBM_DB.ensureBusinessMasters(businessId)
      .then(function () {
        return Promise.all([
          global.PBM_DB.getByBusiness("accounts", businessId),
          global.PBM_DB.getByBusiness("journalEntries", businessId),
          global.PBM_DB.getByBusiness("vouchers", businessId),
          global.PBM_DB.getByBusiness("items", businessId),
          global.PBM_DB.getByBusiness("projects", businessId),
          global.PBM_DB.getByBusiness("projectEntries", businessId),
          global.PBM_DB.getByBusiness("payroll", businessId),
          global.PBM_DB.getByBusiness("parties", businessId)
        ]);
      })
      .then(function (results) {
        viewState.accounts = results[0].sort(function (a, b) { return (a.code || "").localeCompare(b.code || ""); });
        viewState.journals = results[1].sort(function (a, b) { return (b.date || "").localeCompare(a.date || ""); });
        viewState.vouchers = results[2];
        viewState.items = results[3];
        viewState.projects = results[4];
        viewState.projectEntries = results[5];
        viewState.payroll = results[6];
        viewState.parties = (results[7] || []).sort(function (a, b) { return (a.name || "").localeCompare(b.name || ""); });

        if (!viewState.selectedLedgerAccId && viewState.accounts[0]) {
          viewState.selectedLedgerAccId = viewState.accounts[0].id;
        }
        if (!viewState.selectedPartyLedgerId && viewState.parties[0]) {
          viewState.selectedPartyLedgerId = viewState.parties[0].id;
        }

        const balances = computeAccountBalances(false);
        let bodyHtml = "";
        let activeReport = null;
        let activeGlData = null;

        if (viewState.tab === "reports") {
          activeReport = buildActiveReportData();
          const rptOpts = REPORT_TYPES.map(function (r) {
            return `<option value="${r.id}" ${viewState.reportType === r.id ? "selected" : ""}>${app.escapeHtml(r.label)}</option>`;
          }).join("");

          bodyHtml = `
            <div class="card">
              <div class="form-grid">
                <div class="form-group">
                  <label class="form-label" for="accRptType">${tr("reportTypeLabel")}</label>
                  <select id="accRptType" class="form-select">${rptOpts}</select>
                </div>
                <div class="form-row-2">
                  <div class="form-group">
                    <label class="form-label" for="accFromDate">${tr("fromDate")}</label>
                    <input id="accFromDate" class="form-input" type="date" value="${app.escapeHtml(viewState.fromDate)}" />
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="accToDate">${tr("toDate")}</label>
                    <input id="accToDate" class="form-input" type="date" value="${app.escapeHtml(viewState.toDate)}" />
                  </div>
                </div>
                <div class="btn-row">
                  <button id="accPrintBtn" class="primary-btn" type="button">${tr("printReportBtn")}</button>
                  <button id="accCsvBtn" class="secondary-btn" type="button">${tr("exportCsvBtn")}</button>
                </div>
              </div>
            </div>
            ${activeReport.html}
          `;
        } else if (viewState.tab === "ledger") {
          const isHi = app.getLang() === "hi";
          const isPartyMode = viewState.ledgerMode === "party";
          const searchQ = (viewState.ledgerSearch || "").trim().toLowerCase();

          let subjectTitle = "";
          let subjectSubtitle = "";
          let openingBal = 0;
          let totalDr = 0;
          let totalCr = 0;
          let running = 0;
          const rawLines = [];

          if (!isPartyMode) {
            const selAcc = viewState.accounts.find(function (a) { return a.id === viewState.selectedLedgerAccId; }) || viewState.accounts[0];
            subjectTitle = selAcc ? selAcc.code + " · " + selAcc.name : "Account Ledger";
            subjectSubtitle = selAcc ? selAcc.group : "";
            const rawOpen = selAcc ? Number(selAcc.openingBalance || 0) : 0;
            const isCrNormal = selAcc && (selAcc.group === "LIABILITY" || selAcc.group === "EQUITY" || selAcc.group === "INCOME");
            openingBal = isCrNormal ? -rawOpen : rawOpen;

            const sortedJrn = viewState.journals.slice().sort(function (a, b) {
              return (a.date || "").localeCompare(b.date || "") || (a.createdAt || "").localeCompare(b.createdAt || "");
            });
            sortedJrn.forEach(function (j) {
              if (!selAcc) return;
              const jDate = j.date || "";
              (j.lines || []).forEach(function (l) {
                if (l.accountId === selAcc.id || (selAcc.systemKey && l.accountKey === selAcc.systemKey)) {
                  const dr = Number(l.debit) || 0;
                  const cr = Number(l.credit) || 0;
                  if (viewState.fromDate && jDate < viewState.fromDate) {
                    openingBal = Math.round((openingBal + dr - cr) * 100) / 100;
                  } else if (inDateRange(jDate)) {
                    rawLines.push({
                      date: jDate || "-",
                      narration: j.narration || (j.isAuto ? "Auto Voucher Entry" : "Manual Journal"),
                      tag: j.isAuto ? "Auto" : "Manual",
                      dr: dr,
                      cr: cr
                    });
                  }
                }
              });
            });

            running = openingBal;
            rawLines.forEach(function (r) {
              totalDr = Math.round((totalDr + r.dr) * 100) / 100;
              totalCr = Math.round((totalCr + r.cr) * 100) / 100;
              running = Math.round((running + r.dr - r.cr) * 100) / 100;
              r.bal = running;
            });
          } else {
            const selParty = viewState.parties.find(function (p) { return p.id === viewState.selectedPartyLedgerId; }) || viewState.parties[0];
            subjectTitle = selParty ? selParty.name : "Party Ledger";
            subjectSubtitle = selParty ? ((selParty.type || "CUSTOMER") + (selParty.phone ? " · " + selParty.phone : "")) : "";
            if (selParty) {
              const pOpen = Number(selParty.openingBalance) || 0;
              openingBal = selParty.openingType === "PAYABLE" ? -pOpen : pOpen;
              const partyVouchers = viewState.vouchers
                .filter(function (v) { return v.partyId === selParty.id && v.status !== "VOID"; })
                .sort(function (a, b) {
                  return (a.date || "").localeCompare(b.date || "") || (a.createdAt || "").localeCompare(b.createdAt || "");
                });

              partyVouchers.forEach(function (v) {
                const delta = global.PBM_PARTIES
                  ? global.PBM_PARTIES.getSignedVoucherDelta(v)
                  : (Number(v.grandTotal != null ? v.grandTotal : v.amount) || 0);
                if (Math.abs(delta) < 0.005) return;
                const vDate = v.date || "";
                const dr = delta > 0 ? Math.round(delta * 100) / 100 : 0;
                const cr = delta < 0 ? Math.round(Math.abs(delta) * 100) / 100 : 0;
                if (viewState.fromDate && vDate < viewState.fromDate) {
                  openingBal = Math.round((openingBal + dr - cr) * 100) / 100;
                } else if (inDateRange(vDate)) {
                  rawLines.push({
                    date: vDate || "-",
                    narration: (v.voucherNo || v.voucherType) + (v.notes ? " · " + v.notes.split("\n")[0] : ""),
                    tag: (v.voucherType || "").replace(/_/g, " "),
                    dr: dr,
                    cr: cr
                  });
                }
              });
            }

            running = openingBal;
            rawLines.forEach(function (r) {
              totalDr = Math.round((totalDr + r.dr) * 100) / 100;
              totalCr = Math.round((totalCr + r.cr) * 100) / 100;
              running = Math.round((running + r.dr - r.cr) * 100) / 100;
              r.bal = running;
            });
          }

          const ledgerLines = searchQ
            ? rawLines.filter(function (r) {
                return (r.narration + " " + r.tag + " " + r.date).toLowerCase().indexOf(searchQ) !== -1;
              })
            : rawLines;

          activeGlData = {
            mode: isPartyMode ? "party" : "account",
            title: subjectTitle,
            subtitle: subjectSubtitle,
            openingBal: openingBal,
            totalDr: totalDr,
            totalCr: totalCr,
            closingBal: running,
            lines: ledgerLines
          };

          const selectorOpts = !isPartyMode
            ? viewState.accounts.map(function (a) {
                return `<option value="${app.escapeHtml(a.id)}" ${a.id === (viewState.selectedLedgerAccId || (viewState.accounts[0] && viewState.accounts[0].id)) ? "selected" : ""}>${app.escapeHtml(a.code + " · " + a.name)} (${app.escapeHtml(a.group)})</option>`;
              }).join("")
            : (viewState.parties.length
                ? viewState.parties.map(function (p) {
                    return `<option value="${app.escapeHtml(p.id)}" ${p.id === (viewState.selectedPartyLedgerId || (viewState.parties[0] && viewState.parties[0].id)) ? "selected" : ""}>${app.escapeHtml(p.name)} (${app.escapeHtml(p.type || "CUSTOMER")})</option>`;
                  }).join("")
                : `<option value="">-- No Parties Created Yet --</option>`);

          const openTag = openingBal >= 0 ? "Dr" : "Cr";
          const closeTag = running >= 0 ? "Dr" : "Cr";

          const desktopRowsHtml = ledgerLines.map(function (r) {
            return `
              <tr>
                <td style="white-space:nowrap;">${app.escapeHtml(r.date)}</td>
                <td>
                  <div style="font-weight:500;">${app.escapeHtml(r.narration)}</div>
                  ${r.tag ? `<div class="list-item-meta">${app.escapeHtml(r.tag)}</div>` : ""}
                </td>
                <td class="num text-receivable">${r.dr > 0 ? app.formatCurrency(r.dr) : "-"}</td>
                <td class="num text-payable">${r.cr > 0 ? app.formatCurrency(r.cr) : "-"}</td>
                <td class="num"><strong>${app.formatCurrency(Math.abs(r.bal))}</strong> ${r.bal >= 0 ? "Dr" : "Cr"}</td>
              </tr>
            `;
          }).join("");

          const mobileRowsHtml = ledgerLines.map(function (r) {
            return `
              <div class="ledger-row">
                <div class="ledger-row-main">
                  <div class="ledger-row-title">${app.escapeHtml(r.narration)}</div>
                  <div class="list-item-meta">${app.escapeHtml(r.date)}${r.tag ? " · " + app.escapeHtml(r.tag) : ""} · Bal: ${app.formatCurrency(Math.abs(r.bal))} ${r.bal >= 0 ? "Dr" : "Cr"}</div>
                </div>
                <div class="ledger-row-right tabular-nums">
                  ${r.dr > 0 ? `<span class="text-receivable">Dr ${app.formatCurrency(r.dr)}</span>` : `<span class="text-payable">Cr ${app.formatCurrency(r.cr)}</span>`}
                </div>
              </div>
            `;
          }).join("");

          bodyHtml = `
            <div class="card">
              <div class="card-header-row">
                <div>
                  <h3 class="card-title">${isPartyMode ? (isHi ? "पार्टी खाता बही (Party Ledger)" : "Party Ledger (Customer / Supplier)") : (isHi ? "जनरल लेजर (Account Ledger)" : "General Ledger (Account Statement)")}</h3>
                  <p class="card-subtitle">${app.escapeHtml(subjectTitle)}${subjectSubtitle ? " · " + app.escapeHtml(subjectSubtitle) : ""}</p>
                </div>
                <button id="glQuickActionBtn" class="primary-btn" type="button">
                  ${isPartyMode ? (isHi ? "+ रसीद / बिल बनाएँ" : "+ New Receipt / Bill") : tr("newJournalBtn")}
                </button>
              </div>

              <div class="segmented-bar" style="margin:6px 0 12px;">
                <button type="button" class="seg-btn ${!isPartyMode ? "active" : ""}" data-gl-mode="account">${isHi ? "खाता लेजर (Account)" : "Account Ledger"}</button>
                <button type="button" class="seg-btn ${isPartyMode ? "active" : ""}" data-gl-mode="party">${isHi ? "पार्टी लेजर (Party)" : "Party Ledger"} (${viewState.parties.length})</button>
              </div>

              <div class="form-grid">
                <div class="form-row-2">
                  <div class="form-group">
                    <label class="form-label" for="glAccSelect">${isPartyMode ? (isHi ? "पार्टी चुनें" : "Select Party") : (isHi ? "खाता चुनें" : "Select Account")}</label>
                    <select id="glAccSelect" class="form-select">${selectorOpts}</select>
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="glSearchInput">${isHi ? "खोजें (विवरण / वाउचर)" : "Search Narration / Ref"}</label>
                    <input id="glSearchInput" class="form-input" type="search" placeholder="${isHi ? "वाउचर नं या विवरण..." : "Filter entries..."}" value="${app.escapeHtml(viewState.ledgerSearch)}" />
                  </div>
                </div>

                <div class="form-row-2">
                  <div class="form-group">
                    <label class="form-label" for="glFromDate">${tr("fromDate")}</label>
                    <input id="glFromDate" class="form-input" type="date" value="${app.escapeHtml(viewState.fromDate)}" />
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="glToDate">${tr("toDate")}</label>
                    <input id="glToDate" class="form-input" type="date" value="${app.escapeHtml(viewState.toDate)}" />
                  </div>
                </div>

                <div class="btn-row">
                  <button id="glPrintBtn" class="primary-btn" type="button">${tr("printReportBtn")}</button>
                  <button id="glCsvBtn" class="secondary-btn" type="button">${tr("exportCsvBtn")}</button>
                  ${viewState.fromDate || viewState.toDate || viewState.ledgerSearch ? `<button id="glResetBtn" class="secondary-btn" type="button">${isHi ? "फ़िल्टर रीसेट" : "Reset Filters"}</button>` : ""}
                </div>
              </div>

              <div class="ledger-kpi-grid">
                <div class="ledger-kpi-tile">
                  <div class="ledger-kpi-lbl">${viewState.fromDate ? (isHi ? "पिछला बकाया (B/F)" : "Brought Forward") : (isHi ? "शुरुआती बैलेंस" : "Opening Balance")}</div>
                  <div class="ledger-kpi-val tabular-nums">${app.formatCurrency(Math.abs(openingBal))} <span class="list-item-meta">${openTag}</span></div>
                </div>
                <div class="ledger-kpi-tile">
                  <div class="ledger-kpi-lbl">${isHi ? "कुल डेबिट (Dr)" : "Total Debit (Dr)"}</div>
                  <div class="ledger-kpi-val tabular-nums text-receivable">${app.formatCurrency(totalDr)}</div>
                </div>
                <div class="ledger-kpi-tile">
                  <div class="ledger-kpi-lbl">${isHi ? "कुल क्रेडिट (Cr)" : "Total Credit (Cr)"}</div>
                  <div class="ledger-kpi-val tabular-nums text-payable">${app.formatCurrency(totalCr)}</div>
                </div>
                <div class="ledger-kpi-tile">
                  <div class="ledger-kpi-lbl">${isHi ? "अंतिम बैलेंस" : "Closing Balance"}</div>
                  <div class="ledger-kpi-val tabular-nums">${app.formatCurrency(Math.abs(running))} <span class="list-item-meta">${closeTag}</span></div>
                </div>
              </div>

              <div class="table-scroll-wrap ledger-desktop-table">
                <table class="ledger-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Particulars</th>
                      <th class="num">Debit (Dr)</th>
                      <th class="num">Credit (Cr)</th>
                      <th class="num">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style="white-space:nowrap;">${app.escapeHtml(viewState.fromDate || "-")}</td>
                      <td><strong>${viewState.fromDate ? "Opening / Brought Forward Balance" : "Opening Balance"}</strong></td>
                      <td class="num">${openingBal > 0 ? app.formatCurrency(openingBal) : "-"}</td>
                      <td class="num">${openingBal < 0 ? app.formatCurrency(Math.abs(openingBal)) : "-"}</td>
                      <td class="num"><strong>${app.formatCurrency(Math.abs(openingBal))}</strong> ${openTag}</td>
                    </tr>
                    ${desktopRowsHtml || `<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:16px;">${isHi ? "चुनी हुई तारीख़ में कोई एंट्री नहीं है।" : "No entries for this selection in the chosen date range."}</td></tr>`}
                  </tbody>
                </table>
              </div>

              <div class="ledger-list ledger-mobile-list" style="margin-top:12px;">
                <div class="ledger-row">
                  <div class="ledger-row-main">
                    <div class="ledger-row-title">${viewState.fromDate ? "Opening / Brought Forward" : "Opening Balance"}</div>
                    <div class="list-item-meta">${app.escapeHtml(viewState.fromDate || "Start of Books")}</div>
                  </div>
                  <div class="ledger-row-right tabular-nums">
                    <span>${app.formatCurrency(Math.abs(openingBal))} ${openTag}</span>
                  </div>
                </div>
                ${mobileRowsHtml || `<div class="info-note">${isHi ? "चुनी हुई तारीख़ में कोई एंट्री नहीं है।" : "No entries for this selection in the chosen date range."}</div>`}
              </div>
            </div>
          `;
        } else if (viewState.tab === "cashbank") {
          const cashRows = [];
          viewState.vouchers.forEach(function (v) {
            if (v.status === "VOID") return;
            if (v.voucherType === "RECEIPT") {
              cashRows.push({ id: v.id, store: "vouchers", reconciled: Boolean(v.reconciled), date: v.date, title: v.voucherNo + " · " + (v.partyName || ""), mode: v.mode || "Cash", inAmt: Number(v.amount) || 0, outAmt: 0 });
            } else if (v.voucherType === "PAYMENT") {
              cashRows.push({ id: v.id, store: "vouchers", reconciled: Boolean(v.reconciled), date: v.date, title: v.voucherNo + " · " + (v.partyName || ""), mode: v.mode || "Cash", inAmt: 0, outAmt: Number(v.amount) || 0 });
            } else if (v.voucherType === "EXPENSE_VOUCHER" && Number(v.paidAmount) > 0) {
              cashRows.push({ id: v.id, store: "vouchers", reconciled: Boolean(v.reconciled), date: v.date, title: v.voucherNo + " · Expense", mode: v.mode || "Cash", inAmt: 0, outAmt: Number(v.paidAmount) || 0 });
            }
          });
          viewState.projectEntries.forEach(function (pe) {
            if (pe.entryType === "EXPENSE" || pe.entryType === "CONTRACTOR_MATERIAL") {
              cashRows.push({ id: pe.id, store: "projectEntries", reconciled: Boolean(pe.reconciled), date: pe.date, title: "Site Expense: " + pe.title, mode: pe.mode || "Cash", inAmt: 0, outAmt: Number(pe.amount) || 0 });
            }
          });
          viewState.payroll.forEach(function (pr) {
            if (pr.status === "PAID") {
              cashRows.push({ id: pr.id, store: "payroll", reconciled: Boolean(pr.reconciled), date: pr.paidDate || pr.month, title: "Salary: " + pr.staffName, mode: "Bank", inAmt: 0, outAmt: Number(pr.netPayable) || 0 });
            }
          });
          cashRows.sort(function (a, b) { return (b.date || "").localeCompare(a.date || ""); });

          const cashIn = cashRows.reduce(function (s, r) { return s + r.inAmt; }, 0);
          const cashOut = cashRows.reduce(function (s, r) { return s + r.outAmt; }, 0);
          const reconciledNet = cashRows.filter(function (r) { return r.reconciled; }).reduce(function (s, r) { return s + r.inAmt - r.outAmt; }, 0);
          const stmtBal = parseFloat(viewState.bankStmtBalance);
          const diffText = !isNaN(stmtBal) ? app.formatCurrency(stmtBal - reconciledNet) : "-";

          bodyHtml = `
            <div class="kpi-grid">
              <div class="kpi-card"><div class="kpi-label">${tr("cashInLabel")}</div><div class="kpi-value tabular-nums text-receivable">${app.formatCurrency(cashIn)}</div></div>
              <div class="kpi-card"><div class="kpi-label">${tr("cashOutLabel")}</div><div class="kpi-value tabular-nums text-payable">${app.formatCurrency(cashOut)}</div></div>
              <div class="kpi-card"><div class="kpi-label">${tr("netCashLabel")}</div><div class="kpi-value tabular-nums">${app.formatCurrency(cashIn - cashOut)}</div></div>
              <div class="kpi-card"><div class="kpi-label">Reconciled Balance</div><div class="kpi-value tabular-nums">${app.formatCurrency(reconciledNet)}</div></div>
            </div>
            <div class="card">
              <h3 class="card-title">Bank Reconciliation</h3>
              <div class="form-row-2" style="margin-top:8px;">
                <div class="form-group">
                  <label class="form-label" for="bankStmtInput">Bank Statement Balance (₹)</label>
                  <input id="bankStmtInput" class="form-input" type="number" step="0.01" value="${app.escapeHtml(viewState.bankStmtBalance)}" />
                </div>
                <div class="form-group">
                  <label class="form-label">Difference (Statement - Reconciled)</label>
                  <div class="form-input tabular-nums" style="display:flex;align-items:center;font-weight:700;">${diffText}</div>
                </div>
              </div>
              <div class="ledger-list" style="margin-top:10px;">
                ${cashRows.map(function (r) {
                  return `
                    <div class="ledger-row">
                      <div class="ledger-row-main">
                        <div class="ledger-row-title">${app.escapeHtml(r.title)}</div>
                        <div class="list-item-meta">${app.escapeHtml(r.date)} · ${app.escapeHtml(r.mode)}</div>
                      </div>
                      <div class="ledger-row-right tabular-nums">
                        ${r.inAmt > 0 ? `<span class="text-receivable">+ ${app.formatCurrency(r.inAmt)}</span>` : `<span class="text-payable">- ${app.formatCurrency(r.outAmt)}</span>`}
                        <label class="check-chip"><input type="checkbox" data-rec-id="${app.escapeHtml(r.id)}" data-rec-store="${r.store}" ${r.reconciled ? "checked" : ""}/> Reconciled</label>
                      </div>
                    </div>
                  `;
                }).join("") || `<div class="info-note">${tr("noCashMsg")}</div>`}
              </div>
            </div>
          `;
        } else if (viewState.tab === "journal") {
          const jHtml =
            viewState.journals.length === 0
              ? `<div class="info-note">${tr("noJournalMsg")}</div>`
              : viewState.journals
                  .map(function (j) {
                    const totalDr = (j.lines || []).reduce(function (s, l) { return s + (Number(l.debit) || 0); }, 0);
                    return `
                      <div class="ledger-row">
                        <div class="ledger-row-main">
                          <div class="ledger-row-title">${app.escapeHtml(j.narration)}</div>
                          <div class="list-item-meta">${app.escapeHtml(j.date)}${j.isAuto ? " · Auto" : " · Manual"} (${(j.lines || []).length} lines)</div>
                        </div>
                        <div class="ledger-row-right tabular-nums">
                          <span>${app.formatCurrency(totalDr)}</span>
                          ${!j.isAuto ? `<button class="mini-danger-btn" type="button" data-del-jrn="${app.escapeHtml(j.id)}">${tr("deleteBtn")}</button>` : ""}
                        </div>
                      </div>
                    `;
                  })
                  .join("");
          bodyHtml = `
            <div class="card">
              <div class="card-header-row">
                <h3 class="card-title">${tr("tabJournal")}</h3>
                <button id="addJournalBtn" class="primary-btn" type="button">${tr("newJournalBtn")}</button>
              </div>
              <div class="ledger-list">${jHtml}</div>
            </div>
          `;
        } else {
          const coaHtml = balances
            .map(function (b) {
              return `
                <div class="ledger-row">
                  <div class="ledger-row-main">
                    <div class="ledger-row-title">${app.escapeHtml(b.account.code + " · " + b.account.name)}</div>
                    <div class="list-item-meta">${app.escapeHtml(b.account.group)}${Number(b.account.openingBalance) > 0 ? " · Opening: " + app.formatCurrency(b.account.openingBalance) : ""}</div>
                  </div>
                  <div class="ledger-row-right tabular-nums">
                    <span>${app.formatCurrency(Math.abs(b.netDrMinusCr))}</span>
                    <button class="secondary-btn" style="min-height:32px;padding:4px 8px;font-size:0.75rem;" type="button" data-edit-acc="${app.escapeHtml(b.account.id)}">Opening / Edit</button>
                  </div>
                </div>
              `;
            })
            .join("");
          bodyHtml = `
            <div class="card">
              <div class="card-header-row">
                <h3 class="card-title">${tr("tabCoa")}</h3>
                <button id="addAccountBtn" class="primary-btn" type="button">${tr("newAccountBtn")}</button>
              </div>
              <div class="ledger-list">${coaHtml}</div>
            </div>
          `;
        }

        viewContainer.innerHTML = `
          ${contextStripHtml}
          <div class="card">
            <div class="segmented-bar" style="margin-top:0;">
              <button class="seg-btn ${viewState.tab === "reports" ? "active" : ""}" data-acc-tab="reports" type="button">${tr("tabReports")}</button>
              <button class="seg-btn ${viewState.tab === "ledger" ? "active" : ""}" data-acc-tab="ledger" type="button">${tr("tabLedger")}</button>
              <button class="seg-btn ${viewState.tab === "cashbank" ? "active" : ""}" data-acc-tab="cashbank" type="button">${tr("tabCashBank")}</button>
              <button class="seg-btn ${viewState.tab === "journal" ? "active" : ""}" data-acc-tab="journal" type="button">${tr("tabJournal")}</button>
              <button class="seg-btn ${viewState.tab === "coa" ? "active" : ""}" data-acc-tab="coa" type="button">${tr("tabCoa")}</button>
            </div>
          </div>
          ${bodyHtml}
        `;

        viewContainer.querySelectorAll("[data-acc-tab]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            viewState.tab = btn.getAttribute("data-acc-tab");
            render(viewContainer, contextStripHtml);
          });
        });

        const rptTypeEl = document.getElementById("accRptType");
        if (rptTypeEl) {
          rptTypeEl.addEventListener("change", function (e) {
            viewState.reportType = e.target.value;
            render(viewContainer, contextStripHtml);
          });
        }
        const fromEl = document.getElementById("accFromDate");
        if (fromEl) fromEl.addEventListener("change", function (e) { viewState.fromDate = e.target.value; render(viewContainer, contextStripHtml); });
        const toEl = document.getElementById("accToDate");
        if (toEl) toEl.addEventListener("change", function (e) { viewState.toDate = e.target.value; render(viewContainer, contextStripHtml); });

        const csvBtn = document.getElementById("accCsvBtn");
        if (csvBtn && activeReport) {
          csvBtn.addEventListener("click", function () { downloadCsv(activeReport.csvName, activeReport.csvRows); });
        }

        const printBtn = document.getElementById("accPrintBtn");
        if (printBtn && activeReport) {
          printBtn.addEventListener("click", function () {
            const biz = app.getActiveBusiness();
            global.PBM_PRINT.printHtmlDocument(`
              <div class="print-sheet">
                <h2>${app.escapeHtml(biz ? biz.name : "Business")} — ${app.escapeHtml(activeReport.title)}</h2>
                <p>Period: ${viewState.fromDate || "All"} to ${viewState.toDate || new Date().toISOString().slice(0, 10)}</p>
                ${activeReport.html}
              </div>
            `);
          });
        }

        viewContainer.querySelectorAll("[data-gl-mode]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            viewState.ledgerMode = btn.getAttribute("data-gl-mode") || "account";
            render(viewContainer, contextStripHtml);
          });
        });

        const glSel = document.getElementById("glAccSelect");
        if (glSel) {
          glSel.addEventListener("change", function (e) {
            if (viewState.ledgerMode === "party") viewState.selectedPartyLedgerId = e.target.value;
            else viewState.selectedLedgerAccId = e.target.value;
            render(viewContainer, contextStripHtml);
          });
        }

        const glSearchEl = document.getElementById("glSearchInput");
        if (glSearchEl) {
          glSearchEl.addEventListener("input", function (e) {
            viewState.ledgerSearch = e.target.value;
            render(viewContainer, contextStripHtml);
          });
        }

        const glFromEl = document.getElementById("glFromDate");
        if (glFromEl) glFromEl.addEventListener("change", function (e) { viewState.fromDate = e.target.value; render(viewContainer, contextStripHtml); });
        const glToEl = document.getElementById("glToDate");
        if (glToEl) glToEl.addEventListener("change", function (e) { viewState.toDate = e.target.value; render(viewContainer, contextStripHtml); });

        const glResetBtn = document.getElementById("glResetBtn");
        if (glResetBtn) {
          glResetBtn.addEventListener("click", function () {
            viewState.fromDate = "";
            viewState.toDate = "";
            viewState.ledgerSearch = "";
            render(viewContainer, contextStripHtml);
          });
        }

        const glQuickActionBtn = document.getElementById("glQuickActionBtn");
        if (glQuickActionBtn) {
          glQuickActionBtn.addEventListener("click", function () {
            if (viewState.ledgerMode === "party") {
              if (global.PBM_BILLING && typeof global.PBM_BILLING.openDocumentModal === "function") {
                global.PBM_BILLING.openDocumentModal(null, "RECEIPT");
              } else {
                app.navigateTo("billing");
              }
            } else {
              openJournalModal();
            }
          });
        }

        const glPrintBtn = document.getElementById("glPrintBtn");
        if (glPrintBtn && activeGlData) {
          glPrintBtn.addEventListener("click", function () {
            const biz = app.getActiveBusiness();
            const openTag = activeGlData.openingBal >= 0 ? "Dr" : "Cr";
            const closeTag = activeGlData.closingBal >= 0 ? "Dr" : "Cr";
            const tableRows = activeGlData.lines.map(function (r) {
              return `
                <tr>
                  <td>${app.escapeHtml(r.date)}</td>
                  <td>${app.escapeHtml(r.narration)}${r.tag ? " (" + app.escapeHtml(r.tag) + ")" : ""}</td>
                  <td style="text-align:right;">${r.dr > 0 ? app.formatCurrency(r.dr) : "-"}</td>
                  <td style="text-align:right;">${r.cr > 0 ? app.formatCurrency(r.cr) : "-"}</td>
                  <td style="text-align:right;">${app.formatCurrency(Math.abs(r.bal))} ${r.bal >= 0 ? "Dr" : "Cr"}</td>
                </tr>
              `;
            }).join("");

            global.PBM_PRINT.printHtmlDocument(`
              <div class="print-sheet">
                <h2>${app.escapeHtml(biz ? biz.name : "Business")} — ${activeGlData.mode === "party" ? "Party Ledger Statement" : "General Ledger Statement"}</h2>
                <p><strong>${app.escapeHtml(activeGlData.title)}</strong>${activeGlData.subtitle ? " · " + app.escapeHtml(activeGlData.subtitle) : ""}</p>
                <p>Period: ${app.escapeHtml(viewState.fromDate || "Beginning")} to ${app.escapeHtml(viewState.toDate || new Date().toISOString().slice(0, 10))}</p>
                <table style="width:100%;border-collapse:collapse;margin-top:12px;font-size:12px;" border="1" cellpadding="6">
                  <thead>
                    <tr style="background:#f1f5f9;">
                      <th>Date</th>
                      <th>Particulars</th>
                      <th style="text-align:right;">Debit (Dr)</th>
                      <th style="text-align:right;">Credit (Cr)</th>
                      <th style="text-align:right;">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>${app.escapeHtml(viewState.fromDate || "-")}</td>
                      <td><strong>Opening / Brought Forward Balance</strong></td>
                      <td style="text-align:right;">${activeGlData.openingBal > 0 ? app.formatCurrency(activeGlData.openingBal) : "-"}</td>
                      <td style="text-align:right;">${activeGlData.openingBal < 0 ? app.formatCurrency(Math.abs(activeGlData.openingBal)) : "-"}</td>
                      <td style="text-align:right;"><strong>${app.formatCurrency(Math.abs(activeGlData.openingBal))} ${openTag}</strong></td>
                    </tr>
                    ${tableRows}
                    <tr style="background:#f8fafc;font-weight:bold;">
                      <td colspan="2">Totals &amp; Closing Balance</td>
                      <td style="text-align:right;">${app.formatCurrency(activeGlData.totalDr)}</td>
                      <td style="text-align:right;">${app.formatCurrency(activeGlData.totalCr)}</td>
                      <td style="text-align:right;">${app.formatCurrency(Math.abs(activeGlData.closingBal))} ${closeTag}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            `);
          });
        }
        const glCsvBtn = document.getElementById("glCsvBtn");
        if (glCsvBtn && activeGlData) {
          glCsvBtn.addEventListener("click", function () {
            const rows = [["Date", "Particulars", "Type", "Debit", "Credit", "Running Balance", "Dr/Cr"]];
            rows.push([
              viewState.fromDate || "",
              "Opening / Brought Forward Balance",
              "OPENING",
              activeGlData.openingBal > 0 ? activeGlData.openingBal.toFixed(2) : "0.00",
              activeGlData.openingBal < 0 ? Math.abs(activeGlData.openingBal).toFixed(2) : "0.00",
              Math.abs(activeGlData.openingBal).toFixed(2),
              activeGlData.openingBal >= 0 ? "Dr" : "Cr"
            ]);
            activeGlData.lines.forEach(function (r) {
              rows.push([r.date, r.narration, r.tag || "", r.dr.toFixed(2), r.cr.toFixed(2), Math.abs(r.bal).toFixed(2), r.bal >= 0 ? "Dr" : "Cr"]);
            });
            const slug = (activeGlData.title || "ledger").toLowerCase().replace(/[^a-z0-9]+/g, "-");
            downloadCsv((activeGlData.mode === "party" ? "party-ledger-" : "general-ledger-") + slug + ".csv", rows);
          });
        }

        const bankStmtInput = document.getElementById("bankStmtInput");
        if (bankStmtInput) {
          bankStmtInput.addEventListener("change", function (e) {
            viewState.bankStmtBalance = e.target.value;
            render(viewContainer, contextStripHtml);
          });
        }
        viewContainer.querySelectorAll("[data-rec-id]").forEach(function (chk) {
          chk.addEventListener("change", function () {
            const id = chk.getAttribute("data-rec-id");
            const store = chk.getAttribute("data-rec-store");
            global.PBM_DB.getOne(store, id).then(function (rec) {
              if (!rec) return;
              rec.reconciled = chk.checked;
              rec.updatedAt = new Date().toISOString();
              global.PBM_DB.put(store, rec).then(function () {
                render(viewContainer, contextStripHtml);
              });
            });
          });
        });

        const addJrnBtn = document.getElementById("addJournalBtn");
        if (addJrnBtn) addJrnBtn.addEventListener("click", openJournalModal);

        viewContainer.querySelectorAll("[data-del-jrn]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            global.PBM_DB.remove("journalEntries", btn.getAttribute("data-del-jrn")).then(function () {
              render(viewContainer, contextStripHtml);
            });
          });
        });

        const addAccBtn = document.getElementById("addAccountBtn");
        if (addAccBtn) addAccBtn.addEventListener("click", function () { openAccountModal(null); });

        viewContainer.querySelectorAll("[data-edit-acc]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            const acc = viewState.accounts.find(function (a) { return a.id === btn.getAttribute("data-edit-acc"); });
            if (acc) openAccountModal(acc);
          });
        });
      });
  }

  global.PBM_ACCOUNTING = {
    render: render,
    setTab: function (tabKey, reportType) {
      if (tabKey === "party_ledger") {
        viewState.tab = "ledger";
        viewState.ledgerMode = "party";
      } else if (tabKey === "ledger") {
        viewState.tab = "ledger";
        viewState.ledgerMode = "account";
      } else if (tabKey) {
        viewState.tab = tabKey;
      }
      if (reportType) viewState.reportType = reportType;
    }
  };
})(window);
