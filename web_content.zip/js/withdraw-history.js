// =====================================================
// NetEarn Pro
// Withdraw History
// FINAL PREMIUM VERSION
// =====================================================


import {
    auth,
    db
} from "./firebase.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    collection,
    query,
    where,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// ELEMENTS
// =====================================================

const historyList =
    document.getElementById(
        "historyList"
    );


const historyCount =
    document.getElementById(
        "historyCount"
    );


const refreshHistoryBtn =
    document.getElementById(
        "refreshHistoryBtn"
    );


// =====================================================
// WITHDRAW HISTORY CACHE
// =====================================================
function restoreWithdrawHistoryCache(uid) {
    try {
        const raw = localStorage.getItem(`netearnWithdrawHistoryCache_${uid}`);
        if (!raw) return false;

        const cached = JSON.parse(raw);
        if (!cached || !cached.html) return false;

        historyList.innerHTML = cached.html;

        if (historyCount) {
            historyCount.innerText = cached.historyCount ?? "0 Requests";
        }

        return true;
    } catch (_) {
        return false;
    }
}

function saveWithdrawHistoryCache(uid) {
    try {
        localStorage.setItem(
            `netearnWithdrawHistoryCache_${uid}`,
            JSON.stringify({
                html: historyList?.innerHTML || "",
                historyCount: historyCount?.innerText || "0 Requests",
                cachedAt: Date.now()
            })
        );
    } catch (_) {}
}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(value) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


// =====================================================
// FORMAT MONEY
// =====================================================

function money(value) {

    const amount =
        Number(
            value || 0
        );


    return (
        "৳" +
        amount.toLocaleString(
            "en-BD"
        )
    );

}


// =====================================================
// FORMAT DATE
// =====================================================

function formatDate(timestamp) {

    try {

        if (
            timestamp &&
            typeof timestamp.toDate ===
            "function"
        ) {

            return timestamp
                .toDate()
                .toLocaleString(
                    "en-GB",
                    {
                        day:
                            "2-digit",

                        month:
                            "short",

                        year:
                            "numeric",

                        hour:
                            "2-digit",

                        minute:
                            "2-digit"
                    }
                );

        }


        return "Date unavailable";

    }

    catch {

        return "Date unavailable";

    }

}


// =====================================================
// STATUS CLASS
// =====================================================

function getStatusClass(status) {

    const value =
        String(
            status ||
            "Pending"
        )
        .trim()
        .toLowerCase();


    if (
        value ===
        "approved"
    ) {

        return "approved";

    }


    if (
        value ===
        "rejected"
    ) {

        return "rejected";

    }


    if (
        value ===
        "cancelled"
    ) {

        return "cancelled";

    }


    return "pending";

}


// =====================================================
// STATUS TEXT
// =====================================================

function getStatusText(status) {

    const value =
        String(
            status ||
            "Pending"
        )
        .trim();


    if (!value) {

        return "Pending";

    }


    return value;

}


// =====================================================
// EMPTY STATE
// =====================================================

function showEmptyHistory() {

    historyList.innerHTML = `

        <div class="empty-history">

            <div class="empty-icon">

                <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                >

                    <rect
                        x="3"
                        y="5"
                        width="18"
                        height="14"
                        rx="3"
                    />

                    <path
                        d="M7 12h4"
                    />

                    <path
                        d="M14 12h3"
                    />

                </svg>

            </div>


            <h3>
                No Withdraw History
            </h3>


            <p>
                Your withdrawal records will appear here.
            </p>

        </div>

    `;


    if (historyCount) {

        historyCount.innerText =
            "0 Requests";

    }

}


// =====================================================
// LOAD HISTORY
// =====================================================

async function loadWithdrawHistory(
    uid
) {

    if (!uid) {

        return;

    }


    try {

        // Show the last successful result immediately; refresh from Firebase below.
        const hasCachedHistory = restoreWithdrawHistoryCache(uid);

        // =============================================
        // LOADING
        // =============================================

        if (!hasCachedHistory) historyList.innerHTML = `

            <div class="history-loading">

                <div class="loading-spinner"></div>

                <p>
                    Loading Withdraw History...
                </p>

            </div>

        `;


        // =============================================
        // QUERY
        // =============================================

        const q =
            query(

                collection(
                    db,
                    "withdrawRequests"
                ),

                where(
                    "uid",
                    "==",
                    uid
                )

            );


        const snapshot =
            await getDocs(q);


        // =============================================
        // EMPTY
        // =============================================

        if (
            snapshot.empty
        ) {

            showEmptyHistory();

            return;

        }


        // =============================================
        // COLLECT DATA
        // =============================================

        const records = [];


        snapshot.forEach(
            item => {

                const data =
                    item.data();


                records.push({

                    id:
                        item.id,

                    amount:
                        Number(
                            data.amount ||
                            0
                        ),

                    method:
                        data.method ||
                        "Payment Method",

                    number:
                        data.number ||
                        "Not provided",

                    username:
                        data.username ||
                        data.name ||
                        "User",

                    status:
                        data.status ||
                        "Pending",

                    createdAt:
                        data.createdAt ||
                        null

                });

            }
        );


        // =============================================
        // NEWEST FIRST
        // =============================================

        records.sort(
            (
                a,
                b
            ) => {

                const aTime =
                    a.createdAt &&
                    typeof a.createdAt.toDate ===
                    "function"

                        ? a.createdAt
                            .toDate()
                            .getTime()

                        : 0;


                const bTime =
                    b.createdAt &&
                    typeof b.createdAt.toDate ===
                    "function"

                        ? b.createdAt
                            .toDate()
                            .getTime()

                        : 0;


                return bTime - aTime;

            }
        );


        // =============================================
        // UPDATE COUNT
        // =============================================

        if (historyCount) {

            historyCount.innerText =
                records.length +
                (
                    records.length === 1
                        ? " Request"
                        : " Requests"
                );

        }

        // =============================================
        // CLEAR LIST
        // =============================================

        historyList.innerHTML = "";


        // =============================================
        // RENDER
        // =============================================

        records.forEach(
            (
                record,
                index
            ) => {

                const statusClass =
                    getStatusClass(
                        record.status
                    );


                const statusText =
                    getStatusText(
                        record.status
                    );


                const dateText =
                    formatDate(
                        record.createdAt
                    );


                const safeMethod =
                    escapeHTML(
                        record.method
                    );


                const safeNumber =
                    escapeHTML(
                        record.number
                    );


                const safeUsername =
                    escapeHTML(
                        record.username
                    );


                historyList.innerHTML += `

                    <article
                        class="withdraw-history-card"
                        style="animation-delay:${index * 0.04}s"
                    >


                        <!-- CARD TOP -->

                        <div class="withdraw-top">


                            <h3 class="withdraw-amount">

                                ${money(
                                    record.amount
                                )}

                            </h3>


                            <span
                                class="withdraw-status ${statusClass}"
                            >

                                ${escapeHTML(
                                    statusText
                                )}

                            </span>


                        </div>



                        <!-- CARD INFO -->

                        <div class="withdraw-info">


                            <!-- METHOD -->

                            <div
                                class="withdraw-info-row"
                            >

                                <span
                                    class="withdraw-info-label"
                                >
                                    Payment Method
                                </span>


                                <span
                                    class="method-badge"
                                >
                                    ${safeMethod}
                                </span>

                            </div>



                            <!-- NUMBER -->

                            <div
                                class="withdraw-info-row"
                            >

                                <span
                                    class="withdraw-info-label"
                                >
                                    Account Number
                                </span>


                                <span
                                    class="withdraw-info-value"
                                >
                                    ${safeNumber}
                                </span>

                            </div>



                            <!-- USER -->

                            <div
                                class="withdraw-info-row"
                            >

                                <span
                                    class="withdraw-info-label"
                                >
                                    Account
                                </span>


                                <span
                                    class="withdraw-info-value"
                                >
                                    ${safeUsername}
                                </span>

                            </div>



                            <!-- DATE -->

                            <div
                                class="withdraw-info-row"
                            >

                                <span
                                    class="withdraw-info-label"
                                >
                                    Request Date
                                </span>


                                <span
                                    class="withdraw-info-value"
                                >
                                    ${escapeHTML(
                                        dateText
                                    )}
                                </span>

                            </div>


                        </div>


                    </article>

                `;

            }
        );


        // Cache only the successfully rendered current result.
        saveWithdrawHistoryCache(uid);

        console.log(
            "✅ Withdraw History Loaded:",
            records.length
        );

    }

    catch (error) {

        console.error(
            "❌ Withdraw History Error:",
            error
        );


        if (historyCount) {

            historyCount.innerText =
                "Unable to load";

        }


        historyList.innerHTML = `

            <div class="history-error">

                <h3>
                    Unable to Load History
                </h3>

                <p>
                    Please refresh the page and try again.
                </p>

            </div>

        `;

    }

}


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(

    auth,

    async user => {

        console.log(
            "🔥 Withdraw History Auth:",
            user?.uid ||
            "SIGNED OUT"
        );


        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        await loadWithdrawHistory(
            user.uid
        );


        // =============================================
        // REFRESH BUTTON
        // =============================================

        if (
            refreshHistoryBtn
        ) {

            refreshHistoryBtn.onclick =
                async () => {

                    refreshHistoryBtn
                        .classList
                        .add(
                            "refreshing"
                        );


                    try {

                        await loadWithdrawHistory(
                            user.uid
                        );

                    }

                    finally {

                        setTimeout(
                            () => {

                                refreshHistoryBtn
                                    .classList
                                    .remove(
                                        "refreshing"
                                    );

                            },
                            500
                        );

                    }

                };

        }

    }

);


// =====================================================
// FINAL READY
// =====================================================

console.log(
    "======================================="
);

console.log(
    "✅ NetEarn Pro Withdraw History"
);

console.log(
    "💸 Withdrawal Tracking Ready"
);

console.log(
    "⏳ Pending / Approved / Rejected Ready"
);

console.log(
    "🔄 Premium Refresh Ready"
);

console.log(
    "======================================="
);