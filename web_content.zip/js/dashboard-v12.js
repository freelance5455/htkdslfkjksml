// =====================================================
// NetEarn Pro Dashboard v11
// CLEAN FINAL VERSION
// Firebase + Auth + User Controller
//
// VERIFICATION SOURCE OF TRUTH:
// users/{uid}.verified
//
// true  → Verified
// false → Not Verified
//
// verificationStatus / verificationRequested
// are used ONLY for Pending UI.
// =====================================================


import { auth, db } from "./firebase.js";


import {
    onAuthStateChanged,
    signOut,
} from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc,
    collection,
    query,
    where,
    getDocs,
    updateDoc,
} from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// APP STATE
// =====================================================

const App = {

    authUser: null,

    data: null,

    ready: false

};


// =====================================================
// CONFIG
// =====================================================

const CONFIG = {

    login: "login.html",

    verify: "verification-details.html"

};


// =====================================================
// AUTH SESSION CONTROL
// =====================================================

let authSessionToken = 0;


// =====================================================
// LOAD SIDEBAR CACHE
// =====================================================

function loadSidebarCache() {

    const cached =
        sessionStorage.getItem(
            "netearnProfileCache"
        );

    if (!cached) {
        return;
    }


    try {

        const cache =
            JSON.parse(cached);

        const data =
            cache.data || {};


        const name =
            document.getElementById(
                "menuUserName"
            );

        const id =
            document.getElementById(
                "menuUserId"
            );

        const photo =
            document.getElementById(
                "profileImage"
            );

        const verify =
            document.getElementById(
                "verifyStatus"
            );


        // USERNAME
        if (name) {

            name.textContent =
                data.username ||
                data.name ||
                "User";

        }


        // NETEARN ID
        if (id) {

            id.textContent =
                "ID " + (data.userId || "NE00000");

        }


        // PROFILE PHOTO
        if (photo) {

            photo.src =
                cache.photo ||
                data.photoURL ||
                data.photo ||
                "images/default-user.png";

        }


        // VERIFICATION STATUS
        if (verify) {

            const verified =
                data.verified === true;


            const status =
                String(
                    data.verificationStatus || ""
                )
                .toLowerCase()
                .trim();


            const requested =
                data.verificationRequested === true ||
                data.verificationRequested === "true";


            // VERIFIED
            if (verified) {

                verify.className = "drawer-verify is-verified";
                verify.innerHTML =
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="m8 12 2.5 2.5L16 9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                verify.setAttribute("aria-label", "Verified");

            }

            // PENDING
            else if (
                status === "pending" ||
                requested
            ) {

                verify.className = "drawer-verify is-pending";
                verify.innerHTML =
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
                verify.setAttribute("aria-label", "Verification pending");

            }

            // NOT VERIFIED
            else {

                verify.className = "drawer-verify is-not-verified";
                verify.innerHTML =
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="m9 9 6 6M15 9l-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
                verify.setAttribute("aria-label", "Not verified");

            }



        }

    }

    catch (error) {

        console.warn(
            "⚠️ Sidebar cache error:",
            error
        );

    }

}


// =====================================================
// LOAD USER FROM FIRESTORE
// =====================================================

async function loadUser(uid) {

    try {

        const snap =
            await getDoc(
                doc(
                    db,
                    "users",
                    uid
                )
            );


        if (!snap.exists()) {

            console.error(
                "❌ User document not found."
            );

            return null;

        }


        return snap.data();

    }

    catch (error) {

        console.error(
            "❌ Firestore User Load Error:",
            error
        );

        return null;

    }

}


// =====================================================
// INITIAL SIDEBAR CACHE
// =====================================================

loadSidebarCache();


// =====================================================
// AUTH CONTROLLER
// =====================================================

onAuthStateChanged(
    auth,
    async (user) => {

        const sessionToken =
            ++authSessionToken;


        // ---------------------------------------------
        // LOGGED OUT
        // ---------------------------------------------

        if (!user) {

            App.authUser = null;
            App.data = null;
            App.ready = false;


            sessionStorage.removeItem(
                "dashboardLoaded"
            );


            location.replace(
                CONFIG.login
            );

            return;

        }


        // ---------------------------------------------
        // CURRENT USER
        // ---------------------------------------------

        App.authUser =
            user;

        App.data =
            null;

        App.ready =
            false;


        const uid =
            user.uid;


        console.log(
            "🔐 Current Firebase UID:",
            uid
        );


        // ---------------------------------------------
        // LOAD FIRESTORE USER
        // ---------------------------------------------

        const userData =
            await loadUser(uid);


        // ---------------------------------------------
        // OLD REQUEST CHECK
        // ---------------------------------------------

        if (
            sessionToken !==
            authSessionToken
        ) {

            console.warn(
                "⚠️ Old auth request ignored."
            );

            return;

        }


        // ---------------------------------------------
        // CURRENT USER SAFETY
        // ---------------------------------------------

        if (
            !auth.currentUser ||
            auth.currentUser.uid !== uid
        ) {

            console.warn(
                "⚠️ Current Firebase user changed."
            );

            return;

        }


        // ---------------------------------------------
        // USER DATA NOT FOUND
        // ---------------------------------------------

        if (!userData) {

            App.authUser = null;
            App.data = null;
            App.ready = false;

            return;

        }


        // ---------------------------------------------
        // FINAL SAFETY CHECK
        // ---------------------------------------------

        if (
            !auth.currentUser ||
            auth.currentUser.uid !== uid ||
            sessionToken !== authSessionToken
        ) {

            console.warn(
                "⚠️ Stale user data blocked."
            );

            return;

        }


        // ---------------------------------------------
        // SAVE CURRENT USER DATA
        // ---------------------------------------------

        App.authUser =
            auth.currentUser;

        App.data =
            userData;

        App.ready =
            true;


        // Share the single Firestore user read with lightweight
        // dashboard controllers. This avoids duplicate requests.
        window.dispatchEvent(
            new CustomEvent(
                "netearn:user-data-ready",
                {
                    detail: {
                        user: App.authUser,
                        data: App.data
                    }
                }
            )
        );


        // ---------------------------------------------
        // INITIALIZE DASHBOARD
        // ---------------------------------------------

        initDashboard();


        console.log(
            "✅ Dashboard v11 loaded:",
            uid
        );

    }
);


// =====================================================
// PROFILE
// =====================================================

function loadProfile() {

    const user =
        App.data;

    if (!user) {
        return;
    }


    const name =
        document.getElementById(
            "menuUserName"
        );

    const id =
        document.getElementById(
            "menuUserId"
        );

    const image =
        document.getElementById(
            "profileImage"
        );


    // USERNAME
    if (name) {

        name.textContent =
            user.username ||
            user.name ||
            "User";

    }


    // NETEARN ID
    if (id) {

        id.textContent =
            "ID " + (user.userId || "NE00000");

    }


    // PROFILE PHOTO
    if (image) {

        const uid =
            App.authUser?.uid;

        const savedPhoto =
            uid
            ? localStorage.getItem(
                `profilePhoto_${uid}`
            )
            : null;


        image.src =
            savedPhoto ||
            user.photoURL ||
            user.photo ||
            "images/default-user.png";

    }

}


// =====================================================
// VERIFICATION STATUS
// =====================================================

function updateVerify() {

    const box =
        document.getElementById(
            "verifyStatus"
        );

    if (!box) {
        return;
    }


    const data =
        App.data || {};


    // ONLY verified=true means VERIFIED
    const verified =
        data.verified === true;


    const status =
        String(
            data.verificationStatus || ""
        )
        .toLowerCase()
        .trim();


    const requested =
        data.verificationRequested === true ||
        data.verificationRequested === "true";


    // VERIFIED
    if (verified) {

        box.className = "drawer-verify is-verified";
        box.innerHTML =
            '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="m8 12 2.5 2.5L16 9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        box.setAttribute("aria-label", "Verified");

        return;

    }


    // PENDING
    if (
        status === "pending" ||
        requested
    ) {

        box.className = "drawer-verify is-pending";
        box.innerHTML =
            '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
        box.setAttribute("aria-label", "Verification pending");

        return;

    }


    // NOT VERIFIED
    box.className = "drawer-verify is-not-verified";
    box.innerHTML =
        '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="m9 9 6 6M15 9l-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    box.setAttribute("aria-label", "Not verified");

}


// =====================================================
// USER VERIFIED CHECK
// =====================================================
//
// IMPORTANT:
// verified is the ONLY Premium verification flag.
// =====================================================

function userVerified() {

    const data =
        App.data || {};

    return data.verified === true;

}


// =====================================================
// LOADING SCREEN
// =====================================================

function hideLoader() {

    const loader =
        document.getElementById(
            "loadingScreen"
        );

    if (!loader) {
        return;
    }

    // Do not artificially hold the dashboard for a fixed delay.
    // The UI should become available as soon as the required data path is ready.
    const reveal = () => {

        loader.style.opacity =
            "0";

        loader.style.pointerEvents =
            "none";

        try {
            sessionStorage.setItem(
                "dashboardLoaded",
                "true"
            );
        } catch (_) {}

        setTimeout(() => {

            loader.style.display =
                "none";

        }, 150);

    };

    reveal();

}


// =====================================================
// GLOBAL VERIFY
// =====================================================

window.goVerify =
function () {

    location.href =
        CONFIG.verify;

};


// =====================================================
// CLOSE TASK LOCK
// =====================================================

window.closeTaskLock =
function () {

    document
        .getElementById(
            "taskLockPopup"
        )
        ?.classList.remove(
            "show"
        );

};


// =====================================================
// SIDEBAR
// =====================================================

const sideMenu =
    document.getElementById(
        "sideMenu"
    );

const overlay =
    document.getElementById(
        "overlay"
    );

const menuBtn =
    document.getElementById(
        "menuBtn"
    );


function openSidebar() {

    sideMenu?.classList.add(
        "active"
    );

    overlay?.classList.add(
        "active"
    );

    // Lock the dashboard/page scroll while the sidebar is open.
    // The sidebar itself remains independently scrollable on touch devices.
    document.body.classList.add(
        "sidebar-open"
    );

    // Keep keyboard focus/scrolling inside the sidebar when it opens.
    // The actual scroll container is the fixed sidebar, not the dashboard.
    sideMenu?.setAttribute("aria-modal", "true");

}


function closeSidebar() {

    sideMenu?.classList.remove(
        "active"
    );

    overlay?.classList.remove(
        "active"
    );

    document.body.classList.remove(
        "sidebar-open"
    );

}


menuBtn?.addEventListener(
    "click",
    () => {

        if (
            sideMenu?.classList.contains(
                "active"
            )
        ) {

            closeSidebar();

        }

        else {

            openSidebar();

        }

    }
);


overlay?.addEventListener(
    "click",
    closeSidebar
);


// =====================================================
// ADD BALANCE
// =====================================================

const addBalanceMenuBtn =
    document.getElementById(
        "addBalanceMenuBtn"
    );


addBalanceMenuBtn?.addEventListener(
    "click",
    () => {

        document
            .getElementById(
                "addBalanceComingSoonToast"
            )
            ?.remove();


        const toast =
            document.createElement(
                "div"
            );


        toast.id =
            "addBalanceComingSoonToast";


        toast.innerHTML = `
            <div class="coming-soon-icon">
                💳
            </div>

            <div class="coming-soon-text">
                <strong>Add Balance</strong>
                <span>Coming Soon</span>
            </div>
        `;


        Object.assign(
            toast.style,
            {
                position: "fixed",
                left: "50%",
                bottom: "95px",
                transform:
                    "translateX(-50%) translateY(15px)",
                display: "flex",
                alignItems: "center",
                gap: "11px",
                minWidth: "220px",
                padding: "13px 17px",
                background:
                    "rgba(20,28,45,.96)",
                color: "#fff",
                borderRadius: "16px",
                boxShadow:
                    "0 10px 30px rgba(0,0,0,.22)",
                zIndex: "99999",
                opacity: "0",
                transition:
                    "opacity .25s ease, transform .25s ease",
                fontFamily: "inherit",
                pointerEvents: "none"
            }
        );


        document.body.appendChild(
            toast
        );


        requestAnimationFrame(
            () => {

                toast.style.opacity =
                    "1";

                toast.style.transform =
                    "translateX(-50%) translateY(0)";

            }
        );


        setTimeout(
            () => {

                toast.style.opacity =
                    "0";

                toast.style.transform =
                    "translateX(-50%) translateY(15px)";


                setTimeout(
                    () => {
                        toast.remove();
                    },
                    250
                );

            },
            2200
        );

    }
);


// =====================================================
// DOT MENU
// =====================================================

const dotBtn =
    document.getElementById(
        "dotMenuBtn"
    );

const dotMenu =
    document.getElementById(
        "dotMenu"
    );


dotBtn?.addEventListener(
    "click",
    (e) => {

        e.stopPropagation();

        dotMenu?.classList.toggle(
            "show"
        );

    }
);


document.addEventListener(
    "click",
    () => {

        dotMenu?.classList.remove(
            "show"
        );

    }
);


// =====================================================
// TASK PAGE MAP
// =====================================================

const TASK_PAGE = {

    typing: "typing.html",

    editing: "editing.html",

    formfill: "formfill.html",

    microjob: "microjob.html",

    dataentry: "dataentry.html",

    social: "social.html"

};


// =====================================================
// DASHBOARD ICON SOURCE
// Reuse the exact icons already shown on the dashboard.
// This changes only popup icon rendering.
// =====================================================

function getDashboardIcon(selector) {

    const card = document.querySelector(selector);
    const svg = card?.querySelector(".icon-box svg, .reward-icon-new svg");

    return svg ? svg.outerHTML : "";
}

function getDashboardTaskIcon(task) {

    const service =
        task === "editing" ? "photo" :
        task === "formfill" ? "form" :
        task === "microjob" ? "micro" :
        task;

    return getDashboardIcon(`[data-service="${service}"]`);
}

function getDashboardRewardIcon(reward) {

    return getDashboardIcon(`[data-reward="${reward}"]`);
}

// =====================================================
// TASK SELECT MODAL
// =====================================================

function openTaskSelectModal(task) {

    const modal =
        document.getElementById(
            "taskSelectModal"
        );

    const icon =
        document.getElementById(
            "taskModalIcon"
        );

    const title =
        document.getElementById(
            "taskModalTitle"
        );

    const message =
        document.getElementById(
            "taskModalMessage"
        );

    const confirmBtn =
        document.getElementById(
            "taskModalConfirm"
        );


    if (!modal) {
        return;
    }


    const taskInfo = {

        typing: {
            icon: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect class="s-blue" x="7" y="13" width="50" height="38" rx="7"/><path class="s-white" d="M15 22h5v5h-5zm8 0h5v5h-5zm8 0h5v5h-5zm8 0h5v5h-5zM15 30h5v5h-5zm8 0h5v5h-5zm8 0h5v5h-5zm8 0h5v5h-5zM15 38h30v5H15z"/></svg>`,
            title: "Select Typing Task",
            message:
                "আপনি কি English Typing Task নির্বাচন করতে চান?",
            button:
                "Start Typing"
        },

        editing: {
            icon: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect class="s-green" x="8" y="12" width="48" height="40" rx="7"/><circle class="s-white" cx="24" cy="27" r="5"/><path class="s-white" d="M14 46l13-13 8 8 6-6 9 11z"/></svg>`,
            title: "Select Photo Editing",
            message:
                "আপনি কি Photo Editing Task নির্বাচন করতে চান?",
            button:
                "Start Editing"
        },

        formfill: {
            icon: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect class="s-blue" x="12" y="7" width="40" height="50" rx="7"/><path class="s-white" d="M22 19h20v4H22zm0 10h20v4H22zm0 10h13v4H22z"/><path class="s-cyan" d="M40 43l3 3 6-7 3 3-9 10-6-6z"/></svg>`,
            title: "Select Form Fill",
            message:
                "আপনি কি Form Fill Task নির্বাচন করতে চান?",
            button:
                "Start Form Fill"
        }

    };


    const info =
        taskInfo[task];


    if (!info) {
        return;
    }


    if (icon) {
        const dashboardIcon = getDashboardTaskIcon(task);
        icon.innerHTML = dashboardIcon || info.icon;
    }

    if (title) {
        title.textContent =
            info.title;
    }

    if (message) {
        message.textContent =
            info.message;
    }

    if (confirmBtn) {

        confirmBtn.textContent =
            info.button;


        confirmBtn.disabled =
            false;


        confirmBtn.onclick =
            async () => {

                if (
                    !App.authUser ||
                    !App.data
                ) {
                    return;
                }


                confirmBtn.disabled =
                    true;

                confirmBtn.textContent =
                    "⏳ Starting...";


                try {

                    await updateDoc(

                        doc(
                            db,
                            "users",
                            App.authUser.uid
                        ),

                        {
                            selectedTask:
                                task
                        }

                    );


                    App.data.selectedTask =
                        task;


                    modal.classList.remove(
                        "show"
                    );


                    window.location.href =
                        TASK_PAGE[task];

                }

                catch (error) {

                    console.error(
                        "❌ Task Selection Error:",
                        error
                    );


                    alert(
                        "Task নির্বাচন করা যায়নি। আবার চেষ্টা করুন।"
                    );


                    confirmBtn.disabled =
                        false;

                    confirmBtn.textContent =
                        info.button;

                }

            };

    }


    modal.classList.add(
        "show"
    );

}


// =====================================================
// CLOSE TASK SELECT MODAL
// =====================================================

document
    .getElementById(
        "taskModalCancel"
    )
    ?.addEventListener(
        "click",
        () => {

            document
                .getElementById(
                    "taskSelectModal"
                )
                ?.classList.remove(
                    "show"
                );

        }
    );


document
    .getElementById(
        "taskSelectModal"
    )
    ?.addEventListener(
        "click",
        (e) => {

            if (
                e.target.id ===
                "taskSelectModal"
            ) {

                e.currentTarget.classList.remove(
                    "show"
                );

            }

        }
    );


// =====================================================
// TASK LOCK
// =====================================================

function showTaskLock() {

    document
        .getElementById(
            "taskLockPopup"
        )
        ?.classList.add(
            "show"
        );

}


// =====================================================
// SELECTED TASK MODAL
// =====================================================

const selectedTaskModal =
    document.getElementById(
        "selectedTaskModal"
    );

const selectedTaskMessage =
    document.getElementById(
        "selectedTaskMessage"
    );

const selectedTaskOk =
    document.getElementById(
        "selectedTaskOk"
    );


function showSelectedTaskModal(task) {

    if (!selectedTaskModal) {
        return;
    }


    const taskNames = {

        typing: "Typing",

        editing: "Photo Editing",

        formfill: "Form Fill"

    };


    const taskName =
        taskNames[task] ||
        task;


    if (selectedTaskMessage) {

        selectedTaskMessage.textContent =
            `আপনি ইতিমধ্যে ${taskName} Task নির্বাচন করেছেন। আগে সেটি Complete করুন।`;

    }


    selectedTaskModal.classList.add(
        "show"
    );

}


selectedTaskOk?.addEventListener(
    "click",
    () => {

        selectedTaskModal
            ?.classList.remove(
                "show"
            );

    }
);


selectedTaskModal?.addEventListener(
    "click",
    (e) => {

        if (
            e.target ===
            selectedTaskModal
        ) {

            selectedTaskModal.classList.remove(
                "show"
            );

        }

    }
);


// =====================================================
// TASK CREDIT MODAL
// =====================================================

const taskCreditModal =
    document.getElementById(
        "taskCreditModal"
    );

const taskCreditCancel =
    document.getElementById(
        "taskCreditCancel"
    );

const taskCreditReferBtn =
    document.getElementById(
        "taskCreditReferBtn"
    );


function showTaskCreditModal() {

    taskCreditModal
        ?.classList.add(
            "show"
        );

}


function closeTaskCreditModal() {

    taskCreditModal
        ?.classList.remove(
            "show"
        );

}


taskCreditCancel?.addEventListener(
    "click",
    closeTaskCreditModal
);


taskCreditReferBtn?.addEventListener(
    "click",
    () => {

        closeTaskCreditModal();

        window.location.href =
            "referral.html";

    }
);


taskCreditModal?.addEventListener(
    "click",
    (e) => {

        if (
            e.target ===
            taskCreditModal
        ) {

            closeTaskCreditModal();

        }

    }
);


// =====================================================
// COMING SOON TASK SYSTEM
// =====================================================

const comingSoonModal =
    document.getElementById(
        "comingSoonModal"
    );

const comingSoonIcon =
    document.getElementById(
        "comingSoonIcon"
    );

const comingSoonTitle =
    document.getElementById(
        "comingSoonTitle"
    );

const comingSoonMessage =
    document.getElementById(
        "comingSoonMessage"
    );

const comingSoonClose =
    document.getElementById(
        "comingSoonClose"
    );


function showComingSoon(task) {

    if (!comingSoonModal) {
        return;
    }

    const comingMap = {
        microjob: {
            name: "Micro Job",
            message: "Micro Job Serviceটি খুব শীঘ্রই চালু হবে।",
            icon: '<svg viewBox="0 0 64 64" aria-hidden="true"><rect class="s-blue" x="8" y="12" width="48" height="40" rx="8"/><path class="s-white" d="M17 24h30v5H17zm0 10h21v5H17z"/><circle class="s-cyan" cx="45" cy="41" r="5"/></svg>'
        },
        dataentry: {
            name: "Data Entry",
            message: "Data Entry Serviceটি খুব শীঘ্রই চালু হবে।",
            icon: '<svg viewBox="0 0 64 64" aria-hidden="true"><rect class="s-cyan" x="8" y="10" width="48" height="44" rx="7"/><path class="s-white" d="M17 20h30v5H17zm0 10h30v5H17zm0 10h19v5H17z"/><path class="s-blue-dark" d="M44 38h7v13h-7z"/></svg>'
        },
        social: {
            name: "Social Task",
            message: "Social Task Serviceটি খুব শীঘ্রই চালু হবে।",
            icon: '<svg viewBox="0 0 64 64" aria-hidden="true"><circle class="s-purple" cx="32" cy="22" r="11"/><path class="s-blue" d="M12 52c1-11 8-17 20-17s19 6 20 17z"/><circle class="s-white" cx="32" cy="22" r="4"/></svg>'
        }
    };

    const item = comingMap[task] || {
        name: "This Service",
        message: "এই Serviceটি খুব শীঘ্রই চালু হবে।",
        icon: '<svg viewBox="0 0 64 64" aria-hidden="true"><path class="s-blue" d="M36 7c10 0 18 8 18 18 0 11-8 22-22 29l-9-9C30 31 41 23 36 7z"/><circle class="s-white" cx="41" cy="23" r="4"/></svg>'
    };

    if (comingSoonIcon) {
        const dashboardIcon = getDashboardTaskIcon(task);
        comingSoonIcon.innerHTML = dashboardIcon || item.icon;
    }
    if (comingSoonTitle) {
        comingSoonTitle.textContent = item.name;
    }
    if (comingSoonMessage) {
        comingSoonMessage.textContent = item.message;
    }

    comingSoonModal.classList.add("show");
}


comingSoonClose?.addEventListener(
    "click",
    () => {

        comingSoonModal
            ?.classList.remove(
                "show"
            );

    }
);


comingSoonModal?.addEventListener(
    "click",
    (e) => {

        if (
            e.target ===
            comingSoonModal
        ) {

            comingSoonModal.classList.remove(
                "show"
            );

        }

    }
);


// =====================================================
// REWARD PREMIUM MODAL
// =====================================================

const rewardPremiumModal =
    document.getElementById(
        "rewardPremiumModal"
    );

const rewardPremiumIcon =
    document.getElementById(
        "rewardPremiumIcon"
    );

const rewardPremiumBadge =
    document.getElementById(
        "rewardPremiumBadge"
    );

const rewardPremiumTitle =
    document.getElementById(
        "rewardPremiumTitle"
    );

const rewardPremiumMessage =
    document.getElementById(
        "rewardPremiumMessage"
    );

const rewardPremiumName =
    document.getElementById(
        "rewardPremiumName"
    );

const rewardPremiumInfo =
    document.getElementById(
        "rewardPremiumInfo"
    );

const rewardPremiumVerify =
    document.getElementById(
        "rewardPremiumVerify"
    );

const rewardPremiumClose =
    document.getElementById(
        "rewardPremiumClose"
    );


const rewardNames = {
    daily: "Daily Bonus",
    target: "Target Bonus",
    monthly: "Monthly Bonus",
    leadership: "Leadership Rewards",
    spin: "Lucky Spin"
};

const rewardModalIcons = {
    lock: '<svg viewBox="0 0 64 64" aria-hidden="true"><rect class="s-blue" x="13" y="27" width="38" height="29" rx="7"/><path class="s-cyan" d="M20 28V20c0-9 5-14 12-14s12 5 12 14v8h-7v-8c0-5-2-7-5-7s-5 2-5 7v8z"/><rect class="s-white" x="29" y="36" width="6" height="10" rx="3"/></svg>',
    rocket: '<svg viewBox="0 0 64 64" aria-hidden="true"><path class="s-blue" d="M36 7c10 0 18 8 18 18 0 11-8 22-22 29l-9-9C30 31 41 23 36 7z"/><path class="s-cyan" d="M31 33c-4-4-8-5-12-5l-5 9 11 2z"/><circle class="s-white" cx="41" cy="23" r="4"/><path class="s-orange" d="M24 45l-3 12 10-8z"/></svg>'
};


// =====================================================
// REWARD MODAL
// =====================================================

function openRewardPremiumModal(reward) {

    if (!rewardPremiumModal) {
        return;
    }

    const rewardName = rewardNames[reward] || "Reward";

    if (rewardPremiumName) {
        rewardPremiumName.textContent = rewardName;
    }

    if (!userVerified()) {
        rewardPremiumModal.classList.remove("coming-reward-modal");
        if (rewardPremiumIcon) {
            const dashboardIcon = getDashboardRewardIcon(reward);
            rewardPremiumIcon.innerHTML = dashboardIcon || rewardModalIcons.lock;
            rewardPremiumIcon.classList.remove("rocket-orb");
        }
        if (rewardPremiumBadge) {
            rewardPremiumBadge.textContent = "PREMIUM VERIFICATION";
        }
        if (rewardPremiumTitle) {
            rewardPremiumTitle.textContent = "Verify Your Account";
        }
        if (rewardPremiumMessage) {
            rewardPremiumMessage.textContent = "এই Reward ব্যবহার করতে আগে আপনার Account Verification সম্পন্ন করুন।";
        }
        if (rewardPremiumInfo) {
            rewardPremiumInfo.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 10v6M12 7h.01" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><\/svg><span>Verification সম্পন্ন হলে এই Reward Feature unlock হবে।</span>';
        }
        rewardPremiumVerify?.style.setProperty("display", "flex", "important");
        rewardPremiumClose?.style.setProperty("display", "flex", "important");
        if (rewardPremiumClose) {
            rewardPremiumClose.textContent = "Later";
        }
    } else {
        rewardPremiumModal.classList.add("coming-reward-modal");
        if (rewardPremiumIcon) {
            const dashboardIcon = getDashboardRewardIcon(reward);
            rewardPremiumIcon.innerHTML = dashboardIcon || rewardModalIcons.rocket;
            rewardPremiumIcon.classList.remove("rocket-orb");
        }
        if (rewardPremiumBadge) {
            rewardPremiumBadge.textContent = "COMING SOON";
        }
        if (rewardPremiumTitle) {
            rewardPremiumTitle.textContent = "Coming Soon";
        }
        if (rewardPremiumMessage) {
            rewardPremiumMessage.textContent = rewardName + " Featureটি খুব শীঘ্রই চালু হবে।";
        }
        if (rewardPremiumInfo) {
            rewardPremiumInfo.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8 13l3 3 5-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><\/svg><span>আমরা আপনার জন্য আরও ভালো earning opportunity তৈরি করছি।</span>';
        }
        rewardPremiumVerify?.style.setProperty("display", "none", "important");
        rewardPremiumClose?.style.setProperty("display", "flex", "important");
        if (rewardPremiumClose) {
            rewardPremiumClose.textContent = "Got It";
        }
    }

    rewardPremiumModal.classList.add("show");
}


// =====================================================
// REWARD CARD EVENTS
// =====================================================

document
    .querySelectorAll(
        ".reward-feature"
    )
    .forEach(
        card => {

            card.addEventListener(
                "click",
                (e) => {

                    e.preventDefault();
                    e.stopPropagation();


                    openRewardPremiumModal(
                        card.dataset.reward
                    );

                }
            );

        }
    );


// VERIFY
rewardPremiumVerify?.addEventListener(
    "click",
    () => {

        rewardPremiumModal
            ?.classList.remove(
                "show"
            );

        window.goVerify();

    }
);


// CLOSE
rewardPremiumClose?.addEventListener(
    "click",
    () => {

        rewardPremiumModal
            ?.classList.remove(
                "show"
            );

    }
);


// OUTSIDE
rewardPremiumModal?.addEventListener(
    "click",
    (e) => {

        if (
            e.target ===
            rewardPremiumModal
        ) {

            rewardPremiumModal.classList.remove(
                "show"
            );

        }

    }
);


// =====================================================
// COMING SOON CARDS
// =====================================================

document
    .querySelectorAll(
        ".coming-soon-task"
    )
    .forEach(
        card => {

            card.addEventListener(
                "click",
                (e) => {

                    e.preventDefault();
                    e.stopPropagation();


                    const task =
                        card.dataset.coming;


                    if (!userVerified()) {

                        showTaskLock();

                        return;

                    }


                    showComingSoon(
                        task
                    );

                }
            );

        }
    );


// =====================================================
// LIVE CENTRAL TASK + VERIFICATION SETTINGS
// =====================================================

async function loadCentralTaskRewards() {

    try {

        const settingsSnap =
            await getDoc(doc(db, "settings", "main"));

        const settings = settingsSnap.exists()
            ? settingsSnap.data()
            : {};

        const welcomeBonusElement =
            document.getElementById("dashboardWelcomeBonusAmount");

        if (welcomeBonusElement) {
            const parsedWelcomeBonus = Number(settings.welcomeBonus);
            const welcomeBonus = Number.isFinite(parsedWelcomeBonus) && parsedWelcomeBonus >= 0
                ? parsedWelcomeBonus
                : 5;
            welcomeBonusElement.textContent = `৳${welcomeBonus.toLocaleString("en-BD")}`;
        }

        const verificationFeeElement =
            document.getElementById("dashboardVerificationFee");

        if (verificationFeeElement) {
            const fee = Number(settings.premiumFee || 0);
            verificationFeeElement.textContent =
                `৳${fee.toLocaleString("en-BD")}`;
        }


    } catch (error) {
        console.warn('⚠️ Central business settings could not be loaded:', error);
    }
}


// =====================================================
// START TASKS
// =====================================================

function startTasks() {

    const cards =
        document.querySelectorAll(
            ".task-link"
        );


    cards.forEach(
        card => {

            card.onclick =
                function (e) {

                    e.preventDefault();
                    e.stopPropagation();


                    const task =
                        card.dataset.task;


                    // VERIFY FIRST
                    if (!userVerified()) {

                        showTaskLock();

                        return;

                    }


                    // TASK CREDIT
                    if (
                        Number(
                            App.data.taskChance ||
                            0
                        ) < 1
                    ) {

                        showTaskCreditModal();

                        return;

                    }


                    // SELECTED TASK
                    if (
                        App.data.selectedTask
                    ) {

                        if (
                            App.data.selectedTask !==
                            task
                        ) {

                            showSelectedTaskModal(
                                App.data.selectedTask
                            );

                            return;

                        }


                        window.location.href =
                            TASK_PAGE[task];

                        return;

                    }


                    // OPEN SELECT MODAL
                    openTaskSelectModal(
                        task
                    );

                };

        }
    );

}


// =====================================================
// REFERRAL SYSTEM
// =====================================================

async function loadReferral() {

    const user =
        App.data;

    if (
        !user ||
        !App.authUser
    ) {
        return;
    }


    const set =
        (id, value) => {

            const el =
                document.getElementById(
                    id
                );

            if (el) {
                el.textContent =
                    value;
            }

        };


    // USER ID
    set(
        "userId",
        user.userId ||
        "NE00000"
    );


    // REFERRAL CODE
    const myReferralCode =
        String(
            user.referralCode ||
            ""
        ).trim();


    set(
        "referralCode",
        myReferralCode ||
        "NET00000"
    );


    // FIND DIRECT REFERRALS
    // Use the atomically maintained totalReferrals field first.
    // The referral system increments this field in a Firestore transaction,
    // so normal dashboard loads do not need another collection-wide query.
    let totalReferral =
        0;

    const storedReferralCount =
        user?.totalReferrals ??
        user?.referralCount;

    const parsedStoredReferralCount =
        Number(storedReferralCount);

    try {

        if (
            storedReferralCount !== undefined &&
            storedReferralCount !== null &&
            Number.isFinite(parsedStoredReferralCount)
        ) {

            totalReferral =
                Math.max(0, parsedStoredReferralCount);

        }

        else if (myReferralCode) {

            // Legacy/missing-count fallback only.
            const usersRef =
                collection(
                    db,
                    "users"
                );

            const q =
                query(
                    usersRef,
                    where(
                        "referrerCode",
                        "==",
                        myReferralCode
                    )
                );

            const snap =
                await getDocs(q);

            totalReferral =
                snap.size;

        }

    }

    catch (error) {

        console.error(
            "❌ Referral Count Error:",
            error
        );


        totalReferral =
            Number.isFinite(parsedStoredReferralCount)
                ? Math.max(0, parsedStoredReferralCount)
                : 0;

    }


    set(
        "totalReferral",
        totalReferral
    );


    // REFERRAL COMMISSION
    const commission =
        Number(
            user.referralCommission ||
            0
        );


    set(
        "refIncome",
        "৳" +
        commission
    );

}


// =====================================================
// COPY REFERRAL CODE
// =====================================================

document
    .getElementById(
        "copyBtn"
    )
    ?.addEventListener(
        "click",
        async () => {

            const code =
                String(
                    App.data?.referralCode ||
                    ""
                ).trim();


            if (!code) {

                alert(
                    "❌ Referral Code পাওয়া যায়নি।"
                );

                return;

            }


            try {

                if (
                    navigator.clipboard &&
                    window.isSecureContext
                ) {

                    await navigator.clipboard
                        .writeText(
                            code
                        );


                    alert(
                        "✅ Referral Code Copied"
                    );

                    return;

                }

            }

            catch (error) {

                console.warn(
                    "Clipboard API failed:",
                    error
                );

            }


            try {

                const textarea =
                    document.createElement(
                        "textarea"
                    );


                textarea.value =
                    code;

                textarea.style.position =
                    "fixed";

                textarea.style.opacity =
                    "0";


                document.body.appendChild(
                    textarea
                );


                textarea.focus();

                textarea.select();


                const success =
                    document.execCommand(
                        "copy"
                    );


                textarea.remove();


                alert(
                    success
                    ? "✅ Referral Code Copied"
                    : "❌ Copy করা যায়নি।"
                );

            }

            catch (error) {

                console.error(
                    "❌ Copy Error:",
                    error
                );

                alert(
                    "❌ Copy করা যায়নি।"
                );

            }

        }
    );


// =====================================================
// SHARE REFERRAL
// =====================================================

document
    .getElementById(
        "shareBtn"
    )
    ?.addEventListener(
        "click",
        async () => {

            const code =
                String(
                    App.data?.referralCode ||
                    ""
                ).trim();


            if (!code) {

                alert(
                    "❌ Referral Code পাওয়া যায়নি।"
                );

                return;

            }


            const text =
`Join NetEarn Pro 🚀

আমার Referral Code:
${code}

NetEarn Pro-তে join করে আমার referral code ব্যবহার করুন.`;


            if (navigator.share) {

                try {

                    await navigator.share({

                        title:
                            "Join NetEarn Pro",

                        text:
                            text

                    });

                    return;

                }

                catch (error) {

                    if (
                        error?.name ===
                        "AbortError"
                    ) {

                        return;

                    }

                    console.warn(
                        "Share failed:",
                        error
                    );

                }

            }


            try {

                if (
                    navigator.clipboard &&
                    window.isSecureContext
                ) {

                    await navigator.clipboard
                        .writeText(
                            text
                        );


                    alert(
                        "✅ Invite message copied"
                    );

                    return;

                }

            }

            catch (error) {

                console.warn(
                    "Share clipboard failed:",
                    error
                );

            }


            alert(
                text
            );

        }
    );


// =====================================================
// NOTIFICATION
// =====================================================

async function loadNotification() {

    const box =
        document.getElementById(
            "notificationCount"
        );


    if (
        !box ||
        !App.authUser
    ) {
        return;
    }


    try {

        const q =
            query(

                collection(
                    db,
                    "notifications"
                ),

                where(
                    "userUid",
                    "==",
                    App.authUser.uid
                ),

                where(
                    "read",
                    "==",
                    false
                )

            );


        const snap =
            await getDocs(q);


        box.textContent =
            snap.size;


        box.style.display =
            snap.size
            ? "flex"
            : "none";

    }

    catch (error) {

        console.error(
            "❌ Notification Error:",
            error
        );

    }

}


// =====================================================
// EARLY CENTRAL SETTINGS LOAD
// Do not depend on the auth/UI initialization path.
// This prevents the dashboard from remaining on the initial — placeholder
// when the user document/cache path is slow or another controller delays init.
// =====================================================
const centralTaskRewardsLoad = loadCentralTaskRewards();


// =====================================================
// LOADING / INIT
// =====================================================

async function initDashboard() {

    if (
        !App.ready ||
        !App.data
    ) {
        return;
    }


    // PROFILE
    loadProfile();


    // VERIFICATION
    updateVerify();


    // REFERRAL
    loadReferral();


    // NOTIFICATION
    loadNotification();


    // TASK SYSTEM
    startTasks();

    // LIVE Admin-controlled task rewards + verification fee
    // The request is already running in the background.
    // Do not block the dashboard loader while these secondary values load.
    centralTaskRewardsLoad.catch(() => {});


    // HIDE LOADER LAST
    hideLoader();


    console.log(
        "🚀 NetEarn Pro Dashboard v11 Ready"
    );

}


// =====================================================
// NOTIFICATION BUTTON
// =====================================================

const notificationBtn =
    document.getElementById(
        "notificationBtn"
    );


notificationBtn?.addEventListener(
    "click",
    () => {

        window.location.href =
            "notifications.html";

    }
);


// =====================================================
// LOGOUT
// =====================================================

document.addEventListener(
    "click",
    async (e) => {

        const logoutButton =
            e.target.closest(
                "#logoutBtn, #logoutMenuBtn"
            );


        if (!logoutButton) {
            return;
        }


        e.preventDefault();
        e.stopPropagation();


        const ok =
            await NetEarnDialog.confirm(
                "Logout from NetEarn Pro?"
            );


        if (!ok) {
            return;
        }


        try {

            authSessionToken++;


            App.ready =
                false;

            App.authUser =
                null;

            App.data =
                null;


            await signOut(
                auth
            );


            sessionStorage.clear();


            window.location.replace(
                CONFIG.login
            );

        }

        catch (error) {

            console.error(
                "❌ Logout Error:",
                error
            );


            alert(
                "❌ Logout করা যায়নি। আবার চেষ্টা করুন।"
            );

        }

    }
);


// =====================================================
// PROFILE FAST CACHE
// =====================================================

document.addEventListener(
    "click",
    (e) => {

        const profileLink =
            e.target.closest(
                'a[href="profile.html"]'
            );


        if (!profileLink) {
            return;
        }


        if (
            App.ready &&
            App.data &&
            App.authUser
        ) {

            try {

                const cache = {

                    uid:
                        App.authUser.uid,

                    data:
                        App.data,

                    photo:
                        localStorage.getItem(
                            `profilePhoto_${App.authUser.uid}`
                        ),

                    cachedAt:
                        Date.now()

                };


                sessionStorage.setItem(
                    "netearnProfileCache",
                    JSON.stringify(
                        cache
                    )
                );


                console.log(
                    "⚡ Profile data cached"
                );

            }

            catch (error) {

                console.warn(
                    "⚠️ Profile cache failed:",
                    error
                );

            }

        }

    },
    true
);


// =====================================================
// FINAL DEBUG
// =====================================================

console.log(
    "✅ dashboard-v11.js CLEAN FINAL LOADED"
);