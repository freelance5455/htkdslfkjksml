import { normalizeStatus } from "./shared-utils.js";
// =====================================================
// NetEarn Pro
// Lifetime Premium Payment
// FINAL CLEAN + STABLE VERSION
//
// Firebase Storage:
// ❌ NOT USED
//
// Screenshot:
// Browser-side compressed JPEG Base64
// → Firestore subscriptionRequests/{uid}
//
// AUTHORITATIVE PREMIUM FIELD:
// users/{uid}.verified === true
//
// REQUEST:
// subscriptionRequests/{uid}
//
// STATUS:
// Pending  → Verification Pending
// Approved → Premium Active
// Rejected → Activate Lifetime Premium
// None     → Activate Lifetime Premium
// =====================================================


import { auth, db } from "./firebase.js";
import { getBusinessSettings } from "./business-settings.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc,
    setDoc,
    updateDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// CONFIG
// =====================================================

const CONFIG = {

    premiumFeeDefault: null,

    paymentSettingsCollection:
        "paymentSettings",

    paymentSettingsDoc:
        "main",

    settingsCollection:
        "settings",

    settingsDoc:
        "main",

    requestCollection:
        "subscriptionRequests",

    // Firestore document size safe রাখার জন্য
    // screenshot Base64 খুব ছোট রাখা হচ্ছে।
    screenshotMaxBytes:
        250 * 1024,

    screenshotMaxWidth:
        1000,

    screenshotMaxHeight:
        1000,

    screenshotInitialQuality:
        0.78,

    screenshotMinimumQuality:
        0.35,

    screenshotQualityStep:
        0.08

};


let PREMIUM_FEE = null;


// =====================================================
// ELEMENTS
// =====================================================

const paymentMethod =
    document.getElementById(
        "paymentMethod"
    );


const senderNumber =
    document.getElementById(
        "senderNumber"
    );


const trxId =
    document.getElementById(
        "trxId"
    );


const subscribeBtn =
    document.getElementById(
        "subscribeBtn"
    );


const activePaymentNumber =
    document.getElementById(
        "activePaymentNumber"
    );


const copyActiveNumberBtn =
    document.getElementById(
        "copyActiveNumberBtn"
    );


const premiumFeeDisplay =
    document.getElementById(
        "premiumFeeDisplay"
    );


const confirmationAmount =
    document.getElementById(
        "confirmationAmount"
    );


const stepAmount =
    document.getElementById(
        "stepAmount"
    );


const stepMethodName =
    document.getElementById(
        "stepMethodName"
    );


const paymentTerms =
    document.getElementById(
        "paymentTerms"
    );


const paymentScreenshot =
    document.getElementById(
        "paymentScreenshot"
    );


const fileName =
    document.getElementById(
        "fileName"
    );


const screenshotPreview =
    document.getElementById(
        "screenshotPreview"
    );


const screenshotPreviewImage =
    document.getElementById(
        "screenshotPreviewImage"
    );


const paymentStatusTitle =
    document.getElementById(
        "paymentStatusTitle"
    );


const paymentStatusMessage =
    document.getElementById(
        "paymentStatusMessage"
    );


const paymentStatusIcon =
    document.getElementById(
        "paymentStatusIcon"
    );


const methodButtons =
    document.querySelectorAll(
        ".method-btn"
    );


// =====================================================
// APP STATE
// =====================================================

const App = {

    currentUser:
        null,

    requestStatus:
        "",

    submitting:
        false,

    initialized:
        false,

    paymentNumbers: {

        bKash:
            "",

        Nagad:
            ""

    }

};


// =====================================================
// SMALL HELPERS
// =====================================================
function getPaymentMethod() {

    return (
        paymentMethod?.value ||
        "bKash"
    ).trim();

}


function isValidImage(
    file
) {

    return (
        file &&
        typeof file.type === "string" &&
        file.type.startsWith("image/")
    );

}


// =====================================================
// BUTTON STATE
// =====================================================

function setButtonState(
    state = "ready"
) {

    if (!subscribeBtn) {
        return;
    }


    subscribeBtn.disabled =
        false;


    subscribeBtn.classList.remove(
        "pending",
        "active",
        "rejected",
        "loading"
    );


    // =================================================
    // READY
    // =================================================

    if (state === "ready") {

        subscribeBtn.disabled =
            false;

        subscribeBtn.innerHTML = `

            <span>

                <strong class="activate-main">
                    Activate Lifetime Premium
                </strong>

                <small class="activate-sub">
                    Premium Verification Submit করুন
                </small>

            </span>

            <span class="activate-arrow">
                →
            </span>

        `;

        return;
    }


    // =================================================
    // PENDING
    // =================================================

    if (state === "pending") {

        subscribeBtn.disabled =
            true;

        subscribeBtn.classList.add(
            "pending"
        );

        subscribeBtn.innerHTML = `

            <span>

                <strong class="activate-main">
                    ⏳ Verification Pending
                </strong>

                <small class="activate-sub">
                    Admin Review চলছে
                </small>

            </span>

            <span class="activate-arrow">
                ⏳
            </span>

        `;

        return;
    }


    // =================================================
    // ACTIVE
    // =================================================

    if (state === "active") {

        subscribeBtn.disabled =
            true;

        subscribeBtn.classList.add(
            "active"
        );

        subscribeBtn.innerHTML = `

            <span>

                <strong class="activate-main">
                    👑 Premium Active
                </strong>

                <small class="activate-sub">
                    আপনার Premium Account Verified
                </small>

            </span>

            <span class="activate-arrow">
                ✓
            </span>

        `;

        return;
    }


    // =================================================
    // REJECTED
    //
    // Rejected হলে আবার নতুন request
    // submit করা যাবে।
    // =================================================

    if (state === "rejected") {

        subscribeBtn.disabled =
            false;

        subscribeBtn.innerHTML = `

            <span>

                <strong class="activate-main">
                    Activate Lifetime Premium
                </strong>

                <small class="activate-sub">
                    নতুন Verification Request Submit করুন
                </small>

            </span>

            <span class="activate-arrow">
                →
            </span>

        `;

        return;
    }


    // =================================================
    // LOADING
    // =================================================

    if (state === "loading") {

        subscribeBtn.disabled =
            true;

        subscribeBtn.classList.add(
            "loading"
        );

        subscribeBtn.innerHTML = `

            <span>

                <strong class="activate-main">
                    Submitting Request...
                </strong>

                <small class="activate-sub">
                    অনুগ্রহ করে অপেক্ষা করুন
                </small>

            </span>

            <span class="activate-arrow">
                …
            </span>

        `;

    }

}


// =====================================================
// STATUS CARD
// =====================================================

function updateStatusCard(
    status
) {

    if (
        !paymentStatusTitle ||
        !paymentStatusMessage ||
        !paymentStatusIcon
    ) {

        return;
    }


    const normalized =
        normalizeStatus(
            status
        );


    // =================================================
    // PENDING
    // =================================================

    if (
        normalized === "pending"
    ) {

        paymentStatusIcon.textContent =
            "⏳";

        paymentStatusTitle.textContent =
            "Verification Pending";

        paymentStatusMessage.textContent =
            "আপনার Premium Verification Request Admin Review করছেন।";

        return;
    }


    // =================================================
    // APPROVED
    // =================================================

    if (
        normalized === "approved"
    ) {

        paymentStatusIcon.textContent =
            "👑";

        paymentStatusTitle.textContent =
            "Premium Active";

        paymentStatusMessage.textContent =
            "আপনার Lifetime Premium সফলভাবে Active হয়েছে।";

        return;
    }


    // =================================================
    // REJECTED
    // =================================================

    if (
        normalized === "rejected"
    ) {

        paymentStatusIcon.textContent =
            "⚠️";

        paymentStatusTitle.textContent =
            "Verification Request Rejected";

        paymentStatusMessage.textContent =
            "আগের Requestটি Approved হয়নি। সঠিক Payment তথ্য দিয়ে নতুন Request Submit করতে পারেন।";

        return;
    }


    // =================================================
    // DEFAULT
    // =================================================

    paymentStatusIcon.textContent =
        "🔐";

    paymentStatusTitle.textContent =
        "Premium Verification";

    paymentStatusMessage.textContent =
        "Payment করার পর Verification Request Admin Review করবেন।";

}


// =====================================================
// PAYMENT METHOD UI
// =====================================================

function updatePaymentMethod(
    method
) {

    const selectedMethod =
        method === "Nagad"
            ? "Nagad"
            : "bKash";


    if (paymentMethod) {

        paymentMethod.value =
            selectedMethod;

    }


    methodButtons.forEach(
        button => {

            button.classList.toggle(
                "active",
                button.dataset.method ===
                    selectedMethod
            );

        }
    );


    if (stepMethodName) {

        stepMethodName.textContent =
            selectedMethod;

    }


    updateActivePaymentNumber();

}


// =====================================================
// ACTIVE PAYMENT NUMBER
// =====================================================

function updateActivePaymentNumber() {

    if (!activePaymentNumber) {
        return;
    }


    const method =
        getPaymentMethod();


    const number =
        App.paymentNumbers[method];


    if (
        number &&
        String(number).trim()
    ) {

        activePaymentNumber.textContent =
            String(number).trim();

    }

    else {

        activePaymentNumber.textContent =
            "Not Available";

    }

}


// =====================================================
// LOAD PAYMENT NUMBERS
// =====================================================

async function loadPaymentNumbers() {

    try {

        const settingsRef =
            doc(
                db,
                CONFIG.paymentSettingsCollection,
                CONFIG.paymentSettingsDoc
            );


        const snapshot =
            await getDoc(
                settingsRef
            );


        if (!snapshot.exists()) {

            App.paymentNumbers.bKash =
                "";

            App.paymentNumbers.Nagad =
                "";

            updateActivePaymentNumber();

            console.warn(
                "⚠️ paymentSettings/main পাওয়া যায়নি।"
            );

            return;
        }


        const data =
            snapshot.data() || {};


        App.paymentNumbers.bKash =
            String(
                data.bkashNumber ??
                data.bKashNumber ??
                ""
            ).trim();


        App.paymentNumbers.Nagad =
            String(
                data.nagadNumber ??
                data.NagadNumber ??
                ""
            ).trim();


        updateActivePaymentNumber();


        console.log(
            "✅ Payment Numbers Loaded"
        );

    }

    catch (error) {

        console.error(
            "❌ Payment Number Load Error:",
            error
        );


        App.paymentNumbers.bKash =
            "";

        App.paymentNumbers.Nagad =
            "";

        updateActivePaymentNumber();

    }

}


// =====================================================
// LOAD PREMIUM FEE
// =====================================================

async function loadPremiumFee() {

    try {

        const settings =
            await getBusinessSettings({ force: true });

        const fee = Number(settings.premiumFee);

        PREMIUM_FEE =
            Number.isFinite(fee) && fee >= 0
                ? fee
                : CONFIG.premiumFeeDefault;

    } catch (error) {

        console.error(
            "❌ Premium Fee Load Error:",
            error
        );

        PREMIUM_FEE = null;

    }

    const formattedFee =
        Number.isFinite(PREMIUM_FEE) && PREMIUM_FEE >= 0
            ? "৳" + PREMIUM_FEE.toLocaleString("en-US")
            : "—";

    if (premiumFeeDisplay) {
        premiumFeeDisplay.textContent = formattedFee;
    }

    if (confirmationAmount) {
        confirmationAmount.textContent = formattedFee;
    }

    if (stepAmount) {
        stepAmount.textContent = formattedFee;
    }

}

// =====================================================
// GET USER DOCUMENT
// =====================================================

async function getUserData(
    uid
) {

    if (!uid) {
        return null;
    }


    const userRef =
        doc(
            db,
            "users",
            uid
        );


    const snapshot =
        await getDoc(
            userRef
        );


    if (!snapshot.exists()) {

        return null;

    }


    return snapshot.data() || {};

}


// =====================================================
// GET EXISTING SUBSCRIPTION REQUEST
// =====================================================

async function getExistingRequest(
    uid
) {

    if (!uid) {
        return null;
    }


    const requestRef =
        doc(
            db,
            CONFIG.requestCollection,
            uid
        );


    const snapshot =
        await getDoc(
            requestRef
        );


    if (!snapshot.exists()) {

        return null;

    }


    return snapshot.data() || {};

}


// =====================================================
// GET VERIFIED STATE
// =====================================================

async function getUserVerifiedState(
    uid
) {

    try {

        const userData =
            await getUserData(
                uid
            );


        return (
            userData?.verified === true
        );

    }

    catch (error) {

        console.error(
            "❌ User Verification Check Error:",
            error
        );

        throw error;

    }

}


// =====================================================
// REFRESH PREMIUM STATUS
// =====================================================

async function refreshPremiumStatus() {

    if (!App.currentUser) {
        return;
    }


    try {

        // =================================================
        // FIRST AUTHORITY:
        // users/{uid}.verified
        // =================================================

        // ⚡ User verification state + existing request are independent reads.
        // Start both together so the premium status page does not wait
        // for one Firebase read before starting the other.
        const [verified, request] =
            await Promise.all([
                getUserVerifiedState(
                    App.currentUser.uid
                ),
                getExistingRequest(
                    App.currentUser.uid
                )
            ]);


        if (verified === true) {

            App.requestStatus =
                "approved";


            updateStatusCard(
                "approved"
            );


            setButtonState(
                "active"
            );


            return;
        }


        // =================================================
        // SECOND:
        // subscriptionRequests/{uid}
        // (already loaded in parallel above)
        // =================================================


        if (!request) {

            App.requestStatus =
                "";


            updateStatusCard(
                ""
            );


            setButtonState(
                "ready"
            );


            return;
        }


        const status =
            normalizeStatus(
                request.status
            );


        App.requestStatus =
            status;


        updateStatusCard(
            status
        );


        switch (status) {

            case "pending":

                setButtonState(
                    "pending"
                );

                break;


            case "approved":

                setButtonState(
                    "active"
                );

                break;


            case "rejected":

                setButtonState(
                    "rejected"
                );

                break;


            default:

                App.requestStatus =
                    "";

                setButtonState(
                    "ready"
                );

                break;

        }

    }

    catch (error) {

        console.error(
            "❌ Premium Status Refresh Error:",
            error
        );


        // Permission error হলে
        // false state দেখিয়ে নতুন request
        // submit করতে দেব না।
        if (
            error?.code ===
            "permission-denied"
        ) {

            App.requestStatus =
                "permission-error";


            updateStatusCard(
                ""
            );


            setButtonState(
                "ready"
            );

            return;
        }


        setButtonState(
            "ready"
        );

    }

}


// =====================================================
// VALIDATE FORM
// =====================================================

function validateForm() {

    const method =
        paymentMethod?.value?.trim() ||
        "";


    const sender =
        senderNumber?.value?.trim() ||
        "";


    const trx =
        trxId?.value?.trim() ||
        "";


    // =================================================
    // PAYMENT METHOD
    // =================================================

    if (!method) {

        alert(
            "অনুগ্রহ করে Payment Method নির্বাচন করুন।"
        );

        return false;
    }


    // =================================================
    // SENDER NUMBER
    // =================================================

    if (!sender) {

        alert(
            "অনুগ্রহ করে Sender Number দিন।"
        );

        senderNumber?.focus();

        return false;
    }


    if (
        !/^01\d{9}$/.test(
            sender
        )
    ) {

        alert(
            "❌ সঠিক ১১ সংখ্যার Bangladesh Mobile Number দিন।"
        );

        senderNumber?.focus();

        return false;
    }


    // =================================================
    // TRANSACTION ID
    // =================================================

    if (!trx) {

        alert(
            "অনুগ্রহ করে Transaction ID দিন।"
        );

        trxId?.focus();

        return false;
    }


    // =================================================
    // PAYMENT CONFIRMATION
    // =================================================

    if (
        paymentTerms &&
        paymentTerms.checked !== true
    ) {

        alert(
            "অনুগ্রহ করে Payment Confirmation-এ টিক দিন।"
        );

        return false;
    }


    return true;

}


// =====================================================
// COMPRESS SCREENSHOT
//
// Storage ছাড়াই Firestore-এ রাখার জন্য
// ছোট JPEG Base64 তৈরি করা হচ্ছে।
//
// NOTE:
// Firestore document size safe রাখার জন্য
// screenshot target 250 KB রাখা হয়েছে।
// =====================================================

function compressScreenshot(
    file
) {

    return new Promise(
        (resolve, reject) => {

            if (!file) {

                resolve(null);

                return;
            }


            if (!isValidImage(file)) {

                reject(
                    new Error(
                        "শুধু image file upload করা যাবে।"
                    )
                );

                return;
            }


            const reader =
                new FileReader();


            reader.onload = (
                event
            ) => {

                const image =
                    new Image();


                image.onload =
                    () => {

                        try {

                            let width =
                                image.naturalWidth ||
                                image.width;


                            let height =
                                image.naturalHeight ||
                                image.height;


                            if (
                                !width ||
                                !height
                            ) {

                                reject(
                                    new Error(
                                        "Screenshot-এর size পড়া যায়নি।"
                                    )
                                );

                                return;
                            }


                            const maxWidth =
                                CONFIG.screenshotMaxWidth;


                            const maxHeight =
                                CONFIG.screenshotMaxHeight;


                            // ---------------------------------
                            // SCALE DOWN
                            // ---------------------------------

                            const scale =
                                Math.min(
                                    1,
                                    maxWidth /
                                        width,
                                    maxHeight /
                                        height
                                );


                            width =
                                Math.max(
                                    1,
                                    Math.round(
                                        width *
                                        scale
                                    )
                                );


                            height =
                                Math.max(
                                    1,
                                    Math.round(
                                        height *
                                        scale
                                    )
                                );


                            const canvas =
                                document.createElement(
                                    "canvas"
                                );


                            canvas.width =
                                width;

                            canvas.height =
                                height;


                            const context =
                                canvas.getContext(
                                    "2d"
                                );


                            if (!context) {

                                reject(
                                    new Error(
                                        "Image processing শুরু করা যায়নি।"
                                    )
                                );

                                return;
                            }


                            context.drawImage(
                                image,
                                0,
                                0,
                                width,
                                height
                            );


                            let quality =
                                CONFIG.screenshotInitialQuality;


                            let result =
                                canvas.toDataURL(
                                    "image/jpeg",
                                    quality
                                );


                            // ---------------------------------
                            // REDUCE QUALITY
                            // ---------------------------------

                            while (
                                result.length >
                                CONFIG.screenshotMaxBytes &&
                                quality >
                                CONFIG.screenshotMinimumQuality
                            ) {

                                quality =
                                    Math.max(
                                        CONFIG.screenshotMinimumQuality,
                                        quality -
                                        CONFIG.screenshotQualityStep
                                    );


                                result =
                                    canvas.toDataURL(
                                        "image/jpeg",
                                        quality
                                    );

                            }


                            if (
                                result.length >
                                CONFIG.screenshotMaxBytes
                            ) {

                                reject(
                                    new Error(
                                        "SCREENSHOT_TOO_LARGE"
                                    )
                                );

                                return;
                            }


                            resolve({
                                data: result,
                                type: "image/jpeg",
                                width,
                                height,
                                quality
                            });

                        }

                        catch (error) {

                            reject(
                                error
                            );

                        }

                    };


                image.onerror =
                    () => {

                        reject(
                            new Error(
                                "Screenshot read করা যায়নি।"
                            )
                        );

                    };


                image.src =
                    event.target.result;

            };


            reader.onerror =
                () => {

                    reject(
                        new Error(
                            "Screenshot load করা যায়নি।"
                        )
                    );

            };


            reader.readAsDataURL(
                file
            );

        }
    );

}


// =====================================================
// SCREENSHOT PREVIEW
// =====================================================

function clearScreenshotPreview() {

    if (fileName) {

        fileName.textContent =
            "";

    }


    if (screenshotPreview) {

        screenshotPreview.style.display =
            "none";

    }


    if (screenshotPreviewImage) {

        screenshotPreviewImage.src =
            "";

    }

}


if (paymentScreenshot) {

    paymentScreenshot.addEventListener(
        "change",
        () => {

            const file =
                paymentScreenshot.files?.[0];


            if (!file) {

                clearScreenshotPreview();

                return;

            }


            if (!isValidImage(file)) {

                alert(
                    "❌ শুধু JPG, PNG অথবা WEBP ছবি দিন।"
                );

                paymentScreenshot.value =
                    "";

                clearScreenshotPreview();

                return;

            }


            if (fileName) {

                fileName.textContent =
                    "📎 " +
                    file.name;

            }


            try {

                const previewUrl =
                    URL.createObjectURL(
                        file
                    );


                if (
                    screenshotPreviewImage &&
                    screenshotPreview
                ) {

                    screenshotPreviewImage.src =
                        previewUrl;

                    screenshotPreview.style.display =
                        "block";

                }

            }

            catch (error) {

                console.error(
                    "❌ Screenshot Preview Error:",
                    error
                );

            }

        }
    );

}


// =====================================================
// PAYMENT METHOD BUTTONS
// =====================================================

methodButtons.forEach(
    button => {

        button.addEventListener(
            "click",
            () => {

                const method =
                    button.dataset.method;


                updatePaymentMethod(
                    method
                );

            }
        );

    }
);


// =====================================================
// COPY PAYMENT NUMBER
// =====================================================

async function copyPaymentNumber() {

    const number =
        activePaymentNumber
            ?.textContent
            ?.trim() ||
        "";


    if (
        !number ||
        number === "Loading..." ||
        number === "Not Available"
    ) {

        alert(
            "Payment Number বর্তমানে available নয়।"
        );

        return;
    }


    try {

        await navigator.clipboard.writeText(
            number
        );


        if (copyActiveNumberBtn) {

            const oldText =
                copyActiveNumberBtn.textContent;


            copyActiveNumberBtn.textContent =
                "✓ Copied";


            setTimeout(
                () => {

                    copyActiveNumberBtn.textContent =
                        oldText;

                },
                1500
            );

        }

    }

    catch (error) {

        console.error(
            "❌ Copy Error:",
            error
        );


        alert(
            "Number Copy করা যায়নি।"
        );

    }

}


if (copyActiveNumberBtn) {

    copyActiveNumberBtn.addEventListener(
        "click",
        copyPaymentNumber
    );

}


// =====================================================
// SUBMIT PREMIUM REQUEST
// =====================================================

async function submitPremiumRequest() {

    // =================================================
    // LOGIN
    // =================================================

    if (!App.currentUser) {

        alert(
            "❌ Login Required"
        );

        return;
    }


    // =================================================
    // DUPLICATE CLICK
    // =================================================

    if (App.submitting) {

        return;
    }


    try {

        // =============================================
        // CHECK VERIFIED
        // =============================================

        // ⚡ User verification state + existing request are independent
        // reads. Load the fresh user document once and reuse it below
        // instead of reading users/{uid} again before creating the request.
        const [userData, existingRequest] =
            await Promise.all([
                getUserData(
                    App.currentUser.uid
                ),
                getExistingRequest(
                    App.currentUser.uid
                )
            ]);


        if (
            userData?.verified === true
        ) {

            setButtonState(
                "active"
            );


            updateStatusCard(
                "approved"
            );


            alert(
                "👑 আপনার Premium Account ইতিমধ্যে Active হয়েছে।"
            );

            return;
        }


        // =============================================
        // CHECK EXISTING REQUEST
        // =============================================
        // The request was already loaded in parallel with the fresh user
        // document above, so no second Firestore read is needed here.

        if (existingRequest) {

            const existingStatus =
                normalizeStatus(
                    existingRequest.status
                );


            // -----------------------------------------
            // PENDING
            // -----------------------------------------

            if (
                existingStatus ===
                "pending"
            ) {

                App.requestStatus =
                    "pending";


                setButtonState(
                    "pending"
                );


                updateStatusCard(
                    "pending"
                );


                alert(
                    "⏳ আপনার Premium Verification Request ইতিমধ্যে Pending রয়েছে।"
                );

                return;
            }


            // -----------------------------------------
            // APPROVED
            // -----------------------------------------

            if (
                existingStatus ===
                "approved"
            ) {

                App.requestStatus =
                    "approved";


                setButtonState(
                    "active"
                );


                updateStatusCard(
                    "approved"
                );


                alert(
                    "👑 আপনার Premium Verification ইতিমধ্যে Approved হয়েছে।"
                );

                return;
            }


            // -----------------------------------------
            // REJECTED
            //
            // এখানে block করা হবে না।
            // নতুন request replace হবে।
            // -----------------------------------------

        }


        // =============================================
        // VALIDATE
        // =============================================

        if (!validateForm()) {

            return;
        }


        // =============================================
        // LOCK BUTTON
        // =============================================

        App.submitting =
            true;


        setButtonState(
            "loading"
        );


        // =============================================
        // USER DATA
        // =============================================
        // Reuse the fresh user document loaded during the submit checks.

        if (!userData) {

            throw new Error(
                "USER_DATA_NOT_FOUND"
            );

        }


        // =============================================
        // FORM DATA
        // =============================================

        const method =
            paymentMethod?.value?.trim() ||
            "";


        const sender =
            senderNumber?.value?.trim() ||
            "";


        const trx =
            trxId?.value?.trim() ||
            "";


        // =============================================
        // SCREENSHOT
        // =============================================

        let screenshot =
            null;


        if (
            paymentScreenshot?.files?.length
        ) {

            screenshot =
                await compressScreenshot(
                    paymentScreenshot.files[0]
                );

        }


        // =============================================
        // REQUEST DATA
        // =============================================

        const requestData = {

            uid:
                App.currentUser.uid,

            name:
                userData.name ||
                "",

            username:
                userData.username ||
                "",

            email:
                userData.email ||
                App.currentUser.email ||
                "",

            paymentMethod:
                method,

            senderNumber:
                sender,

            transactionId:
                trx,

            amount:
                PREMIUM_FEE,

            plan:
                "Lifetime Premium",

            status:
                "Pending",

            createdAt:
                serverTimestamp(),

            rejectedAt:
                null,

            approvedAt:
                null

        };


        // =============================================
        // SCREENSHOT OPTIONAL
        // =============================================

        if (screenshot?.data) {

            requestData.paymentScreenshot =
                screenshot.data;

            requestData.screenshotType =
                screenshot.type;

            requestData.screenshotSize =
                screenshot.data.length;

        }


        // =============================================
        // FIRESTORE WRITE
        // =============================================

        await setDoc(

            doc(
                db,
                CONFIG.requestCollection,
                App.currentUser.uid
            ),

            requestData

        );
        
        // =================================================
// SAVE USER VERIFICATION PENDING STATE
// =================================================

await updateDoc(

    doc(
        db,
        "users",
        App.currentUser.uid
    ),

    {
        verificationStatus: "pending",
        verificationRequested: true
    }

);


        // =============================================
        // SUCCESS STATE
        // =============================================

        App.requestStatus =
            "pending";


        updateStatusCard(
            "pending"
        );


        setButtonState(
            "pending"
        );


        // =============================================
        // CLEAR FORM
        // =============================================

        if (senderNumber) {

            senderNumber.value =
                "";

        }


        if (trxId) {

            trxId.value =
                "";

        }


        if (paymentTerms) {

            paymentTerms.checked =
                false;

        }


        if (paymentScreenshot) {

            paymentScreenshot.value =
                "";

        }


        clearScreenshotPreview();


        // =============================================
        // SUCCESS MESSAGE
        // =============================================

        alert(
            "✅ Premium Verification Request সফলভাবে Submit হয়েছে।\n\n⏳ এখন আপনার Request Admin Review-এ রয়েছে।"
        );


        console.log(
            "✅ Premium Request Submitted Successfully"
        );

    }

    catch (error) {

        console.error(
            "❌ Premium Submission Error:",
            error
        );


        console.error(
            "❌ Error Code:",
            error?.code
        );


        console.error(
            "❌ Error Message:",
            error?.message
        );


        // =============================================
        // SCREENSHOT TOO LARGE
        // =============================================

        if (
            error?.message ===
            "SCREENSHOT_TOO_LARGE"
        ) {

            alert(
                "📸 Screenshot অনেক বড়।\n\nআরেকটি কম Resolution-এর Screenshot দিন।"
            );


            setButtonState(
                "ready"
            );


            return;
        }


        // =============================================
        // USER DATA NOT FOUND
        // =============================================

        if (
            error?.message ===
            "USER_DATA_NOT_FOUND"
        ) {

            alert(
                "❌ আপনার User Account Data পাওয়া যায়নি।"
            );


            setButtonState(
                "ready"
            );


            return;
        }


        // =============================================
        // FIRESTORE PERMISSION
        // =============================================

        if (
            error?.code ===
            "permission-denied"
        ) {

            alert(
                "❌ Firebase Permission Denied.\n\nFirestore Rules-এ subscriptionRequests-এর CREATE permission check করুন।"
            );


            setButtonState(
                "ready"
            );


            return;
        }


        // =============================================
        // NETWORK / FIREBASE
        // =============================================

        if (
            error?.code ===
            "unavailable"
        ) {

            alert(
                "⚠️ Firebase অথবা Internet connection সমস্যা হয়েছে। আবার চেষ্টা করুন।"
            );


            setButtonState(
                "ready"
            );


            return;
        }


        // =============================================
        // ABORT ERROR
        // =============================================

        if (
            error?.name ===
            "AbortError"
        ) {

            console.warn(
                "⚠️ Browser request aborted."
            );


            alert(
                "⚠️ Request মাঝপথে বন্ধ হয়েছে। আবার চেষ্টা করুন।"
            );


            setButtonState(
                "ready"
            );


            return;
        }


        // =============================================
        // GENERAL ERROR
        // =============================================

        alert(
            "❌ Request Submit করা যায়নি।\n\n" +
            (
                error?.message ||
                "Unknown error"
            )
        );


        // Status আবার check
        try {

            await refreshPremiumStatus();

        }

        catch (
            refreshError
        ) {

            console.error(
                "❌ Status Refresh After Error:",
                refreshError
            );

        }

    }

    finally {

        App.submitting =
            false;

    }

}


// =====================================================
// SUBMIT BUTTON
// =====================================================
//
// একবারই listener যোগ করা হচ্ছে।
// =====================================================

if (subscribeBtn) {

    subscribeBtn.addEventListener(
        "click",
        submitPremiumRequest
    );

}


// =====================================================
// AUTH STATE
// =====================================================

onAuthStateChanged(

    auth,

    async user => {

        // =============================================
        // LOGGED OUT
        // =============================================

        if (!user) {

            App.currentUser =
                null;

            window.location.href =
                "index.html";

            return;

        }


        // =============================================
        // SET USER
        // =============================================

        App.currentUser =
            user;


        console.log(
            "✅ Premium Page User:",
            user.uid
        );


        // =============================================
        // LOAD INITIAL DATA
        // =============================================

        try {

            await Promise.all([
                loadPremiumFee(),
                loadPaymentNumbers()
            ]);

        }

        catch (error) {

            console.error(
                "❌ Initial Data Load Error:",
                error
            );

        }


        // =============================================
        // DEFAULT PAYMENT METHOD
        //
        // bKash = LEFT + DEFAULT
        // =============================================

        updatePaymentMethod(
            "bKash"
        );


        // =============================================
        // PREMIUM STATUS
        // =============================================

        await refreshPremiumStatus();


        App.initialized =
            true;


        console.log(
            "✅ NetEarn Pro Premium Payment — READY"
        );

    }

);


// =====================================================
// OLD COMPATIBILITY COPY FUNCTION
// =====================================================
//
// অন্য HTML থেকে যদি:
// copyNumber('someId', this)
// ব্যবহার করা থাকে, সেটাও কাজ করবে।
// =====================================================

window.copyNumber =
async function (
    id,
    btn
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {
        return;
    }


    const number =
        element.textContent.trim();


    if (
        !number ||
        number === "Loading..." ||
        number === "Not Available"
    ) {

        alert(
            "Payment Number বর্তমানে available নয়।"
        );

        return;
    }


    try {

        await navigator.clipboard.writeText(
            number
        );


        if (btn) {

            const oldText =
                btn.textContent;


            btn.textContent =
                "✓ Copied";


            setTimeout(
                () => {

                    btn.textContent =
                        oldText;

                },
                1800
            );

        }

    }

    catch (error) {

        console.error(
            "❌ Copy Error:",
            error
        );


        alert(
            "Number Copy করা যায়নি।"
        );

    }

};


// =====================================================
// FINAL LOG
// =====================================================

console.log(
    "✅ NetEarn Pro Premium Payment — FINAL CLEAN VERSION"
);

console.log(
    "✅ Firebase Storage: NOT USED"
);

console.log(
    "✅ Screenshot: Firestore Base64"
);

console.log(
    "✅ bKash Left / Nagad Right"
);

console.log(
    "✅ Rejected → Activate Lifetime Premium"
);

console.log(
    "✅ Pending → Duplicate Submit Blocked"
);

console.log(
    "✅ Verified → Premium Active"
);