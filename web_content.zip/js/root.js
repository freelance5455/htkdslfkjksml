(function(){
  'use strict';
  if(/[?&]choose\b/.test(location.search))return;
  var ok=['de','en','fr','fa'],s=null;
  try{s=localStorage.getItem('z-lang')}catch(e){}
  if(ok.indexOf(s)<0){
    s=null;
    var l=navigator.languages&&navigator.languages.length?navigator.languages:[navigator.language||'de'];
    for(var i=0;i<l.length&&!s;i++){var p=String(l[i]).toLowerCase().slice(0,2);if(ok.indexOf(p)>=0)s=p}
  }
  location.replace((s||'de')+'/index.html');
})();
