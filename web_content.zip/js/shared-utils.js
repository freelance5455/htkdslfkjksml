// NetEarn Pro — Shared pure utility helpers
// Only stateless helpers are centralized here.

export function normalizeStatus(status) {
    return String(status || "")
        .trim()
        .toLowerCase();
}

export function formatMoney(amount) {
    const number = Number(amount) || 0;
    return number.toLocaleString("en-US", {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
}

export function money(value) {
    const amount = Number(value || 0);
    return "৳" + amount.toLocaleString("en-BD");
}

export function getDateValue(timestamp) {
    if (!timestamp) return null;

    try {
        if (typeof timestamp.toDate === "function") {
            return timestamp.toDate();
        }

        const date = new Date(timestamp);
        if (Number.isNaN(date.getTime())) return null;
        return date;
    } catch {
        return null;
    }
}

export function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
