window.WorkspaceUI={
  escape(value=''){return String(value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]))},
  worldCard(world,selectedGame){return `<button class="world-card current" data-world="${this.escape(world.key)}"><span class="world-glyph ${this.escape(world.theme)}">${this.escape(world.glyph)}</span><span><b>${this.escape(world.title)}</b><small>${this.escape(selectedGame.homeTitle||selectedGame.title)} selected</small></span><em>→</em></button>`},
  recentGameCard(game,world){return `<button class="world-card" data-world="${this.escape(world.key)}" data-game-key="${this.escape(game.key)}"><span class="world-glyph small ${this.escape(world.theme)}">${this.escape(game.short)}</span><span><b>${this.escape(game.homeTitle||game.title)}</b><small>${this.escape(world.title)} world</small></span></button>`},
  gameCard(game,index,selected){return WorkspaceGameCards.markup(game,index,selected,this.escape.bind(this))},
  gameNavigation(items){return '<p class="tree-label">WORKSPACE</p>'+items.map(item=>item[0]==='divider'?'<div class="tree-divider"></div>':`<button class="${item[0]==='overview'?'active':''}" data-game-section="${item[0]}">${this.escape(item[1])}</button>`).join('')},
  statusCards(items,modCount){return items.map(item=>`<button data-game-section="${item[0]}"><span>${item[1]}</span><b${item[0]==='mods'?' id="gameModCount"':''}>${item[0]==='mods'?`${modCount} mods`:this.escape(item[2])}</b><small>${this.escape(item[3])}</small></button>`).join('')},
  renderGameChrome(config,modCount){const nav=document.getElementById('gameNav');if(nav)nav.innerHTML=this.gameNavigation(config.gameNavigation)}
};
