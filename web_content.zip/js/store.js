/* Local-only data store with validation, migration and plan entitlements. */
(function (EP) {
  const KEY = 'europath.v2';
  const LIMITS = {
    FREE: { trips: EP.config.free.trips, saved: EP.config.free.saved },
    PRO: { trips: Infinity, saved: Infinity },
    TRAVEL_PLUS: { trips: Infinity, saved: Infinity }
  };
  const mem = {};
  let storage = null;
  try { localStorage.setItem('__ep', '1'); localStorage.removeItem('__ep'); storage = localStorage; } catch (e) { storage = null; }
  const read = () => { try { return storage ? storage.getItem(KEY) : mem[KEY] || null; } catch (e) { return null; } };
  const write = v => { try { if (storage) storage.setItem(KEY, v); else mem[KEY] = v; return true; } catch (e) { return false; } };

  // ---- validation helpers (used for load AND for imports: never trust input) ----
  const str = (v, max, d) => (typeof v === 'string' ? v.slice(0, max) : d === undefined ? '' : d);
  const num = (v, d) => { const n = Number(v); return isFinite(n) && n >= 0 && n < 1e9 ? n : d; };
  const sn = (v, d) => { const n = Number(v); return v !== null && v !== '' && isFinite(n) && Math.abs(n) < 300 ? n : d; };
  const coord = (v, lim) => { const n = Number(v); return isFinite(n) && Math.abs(n) <= lim ? n : null; };
  const isoDate = v => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !isNaN(Date.parse(v)) ? v : null);
  const id = v => (typeof v === 'string' && /^[\w-]{3,40}$/.test(v) ? v : uid());
  const cur = v => (typeof v === 'string' && /^[A-Za-z]{3}$/.test(v) ? v.toUpperCase() : 'EUR');
  const arr = (v, max) => (Array.isArray(v) ? v.slice(0, max) : []);
  const KINDS = ['activity', 'transport', 'stay', 'meal'];
  const DOCS = ['flight', 'train', 'hotel', 'restaurant', 'ticket', 'insurance', 'other'];
  const OPTS = ['flight', 'train', 'hotel', 'restaurant', 'attraction', 'other'];
  const safeUrl = v => { try { const u = new URL(String(v)); return /^https?:$/.test(u.protocol) ? u.href.slice(0, 500) : ''; } catch (e) { return ''; } };
  const tzOk = v => { if (typeof v !== 'string' || !/^[A-Za-z_+\-\/0-9]{1,40}$/.test(v)) return ''; try { new Intl.DateTimeFormat('en', { timeZone: v }); return v; } catch (e) { return ''; } };

  function uid() { return (Date.now().toString(36) + Math.random().toString(36).slice(2, 8)); }

  // A "place" is a searched city/town: { id, name, region, cc, lat, lon, tz, pop }
  function normPlace(p) {
    if (typeof p === 'string') { const c = EP.cities.find(x => x.id === p); return c ? { id: 'b:' + c.id, name: c.n.en, region: '', cc: c.cc, lat: c.lat, lon: c.lon, tz: c.tz, pop: 0 } : null; }
    if (!p || typeof p !== 'object') return null;
    const lat = coord(p.lat, 90), lon = coord(p.lon, 180), tz = tzOk(p.tz);
    if (lat === null || lon === null || !tz || typeof p.name !== 'string' || !p.name) return null;
    const pid = typeof p.id === 'string' && /^[\w:-]{2,40}$/.test(p.id) ? p.id : 'x' + Math.round(lat * 1e3) + '_' + Math.round(lon * 1e3);
    return { id: pid, name: str(p.name, 80), region: str(p.region, 80), cc: /^[A-Za-z]{2}$/.test(p.cc || '') ? p.cc.toUpperCase() : '', lat, lon, tz, pop: num(p.pop, 0) };
  }

  function normTrip(t) {
    if (!t || typeof t !== 'object') return null;
    const s = isoDate(t.startDate), e = isoDate(t.endDate);
    if (!s || !e || e < s) return null;
    return {
      id: id(t.id), title: str(t.title, 120, 'Trip') || 'Trip', destination: str(t.destination, 120), place: normPlace(t.place || t.cityId || null),
      startDate: s, endDate: e, currency: cur(t.currency), travelers: Math.min(50, Math.max(1, Math.round(num(t.travelers, 1)))),
      budget: t.budget === null || t.budget === undefined || t.budget === '' ? null : num(t.budget, null),
      status: t.status === 'archived' ? 'archived' : 'active', createdAt: num(t.createdAt, Date.now()),
      items: arr(t.items, 500).map(i => i && isoDate(i.day) ? { id: id(i.id), day: i.day, time: /^([01]\d|2[0-3]):[0-5]\d$/.test(i.time || '') ? i.time : '', title: str(i.title, 160, 'Stop') || 'Stop', kind: KINDS.includes(i.kind) ? i.kind : 'activity', cost: i.cost === null || i.cost === undefined || i.cost === '' ? null : num(i.cost, null), confirmed: !!i.confirmed, lat: coord(i.lat, 90), lon: coord(i.lon, 180), note: str(i.note, 200) } : null).filter(Boolean),
      expenses: arr(t.expenses, 1000).map(x => x && isoDate(x.date) && num(x.amount, null) !== null ? { id: id(x.id), amount: num(x.amount, 0), currency: cur(x.currency), category: str(x.category, 40), note: str(x.note, 200), date: x.date } : null).filter(Boolean),
      docs: arr(t.docs, 200).map(d => d ? { id: id(d.id), type: DOCS.includes(d.type) ? d.type : 'other', title: str(d.title, 120, 'Booking') || 'Booking', ref: str(d.ref, 60), link: safeUrl(d.link) } : null).filter(Boolean),
      packing: arr(t.packing, 300).map(p => p && typeof p.text === 'string' ? { id: id(p.id), text: str(p.text, 120), done: !!p.done } : null).filter(Boolean),
      options: arr(t.options, 300).map(o => o && typeof o.name === 'string' && o.name ? { id: id(o.id), type: OPTS.includes(o.type) ? o.type : 'other', name: str(o.name, 120), price: o.price === null || o.price === undefined || o.price === '' ? null : num(o.price, null), currency: cur(o.currency), date: isoDate(o.date) || '', link: safeUrl(o.link), note: str(o.note, 200), at: num(o.at, Date.now()) } : null).filter(Boolean)
    };
  }

  function defaults() {
    return { v: 3, lang: null, consentAt: null, online: false, currency: 'EUR', plan: 'FREE', test: false, digits: 'auto', tempUnit: 'c', weekStart: 1, trips: [], saved: [], recent: [], rates: { date: null, map: { EUR: 1 }, manual: {} }, wx: {} };
  }

  function normalize(s) {
    const d = defaults();
    if (!s || typeof s !== 'object') return d;
    d.lang = ['en', 'fr', 'de', 'es', 'it', 'fa', 'ar'].includes(s.lang) ? s.lang : null;
    d.consentAt = typeof s.consentAt === 'number' ? s.consentAt : null;
    d.online = !!s.online;
    d.currency = cur(s.currency);
    d.plan = ['FREE', 'PRO', 'TRAVEL_PLUS'].includes(s.plan) ? s.plan : 'FREE';
    d.test = !!s.test;
    d.digits = s.digits === 'latn' ? 'latn' : 'auto';
    d.tempUnit = s.tempUnit === 'f' ? 'f' : 'c';
    d.weekStart = [0, 1, 6].includes(Number(s.weekStart)) ? Number(s.weekStart) : 1;
    d.trips = arr(s.trips, 200).map(normTrip).filter(Boolean);
    const dedupe = list => { const seen = new Set(); return list.filter(p => p && !seen.has(p.id) && seen.add(p.id)); };
    d.saved = dedupe(arr(s.saved, 300).map(normPlace));
    d.recent = dedupe(arr(s.recent, 12).map(normPlace)).slice(0, 12);
    if (s.rates && typeof s.rates === 'object') {
      const m = { EUR: 1 }, man = {};
      for (const k in (s.rates.map || {})) if (/^[A-Z]{3}$/.test(k) && num(s.rates.map[k], 0) > 0) m[k] = Number(s.rates.map[k]);
      for (const k in (s.rates.manual || {})) if (/^[A-Z]{3}$/.test(k) && m[k]) man[k] = true;
      d.rates = { date: str(s.rates.date, 20, null), map: m, manual: man };
    }
    if (s.wx && typeof s.wx === 'object') {
      for (const k in s.wx) {
        const w = s.wx[k];
        if (!/^[\w:-]{2,40}$/.test(k) || !w || typeof w.at !== 'number' || !w.cur || !Array.isArray(w.daily)) continue;
        const code = n => { const v = Number(n); return Number.isInteger(v) && v >= 0 && v <= 99 ? v : 3; };
        d.wx[k] = {
          at: w.at,
          cur: { t: sn(w.cur.t, null), fl: sn(w.cur.fl, null), h: sn(w.cur.h, null), code: code(w.cur.code), w: sn(w.cur.w, 0), day: w.cur.day === 0 ? 0 : 1 },
          daily: w.daily.slice(0, 16).map(x => ({ d: isoDate(x.d) || '', max: sn(x.max, null), min: sn(x.min, null), p: sn(x.p, null), code: code(x.code), sr: str(x.sr, 20), ss: str(x.ss, 20), uv: sn(x.uv, null) })).filter(x => x.d && x.max !== null && x.min !== null),
          hr: arr(w.hr, 24).map(x => ({ h: str(x.h, 5), t: sn(x.t, null), p: sn(x.p, null) }))
        };
        if (!d.wx[k].daily.length) delete d.wx[k];
      }
    }
    return d;
  }

  let state = (function () { try { const r = read(); return normalize(r ? JSON.parse(r) : null); } catch (e) { return defaults(); } })();
  const persist = () => write(JSON.stringify(state));

  const S = {
    uid, get: () => state, save: persist, normalize, normTrip, normPlace,
    replace(obj) { state = normalize(obj); persist(); },
    reset() { state = defaults(); persist(); },
    exportJson() { return JSON.stringify(Object.assign({ app: 'europath-pro', exportedAt: new Date().toISOString() }, state, { wx: undefined }), null, 2); },
    limits: () => LIMITS[state.plan],
    isPro: () => state.plan !== 'FREE',
    activeTrips: () => state.trips.filter(t => t.status === 'active').length,
    canAddTrip: () => S.activeTrips() < LIMITS[state.plan].trips,
    canSavePlace: () => state.saved.length < LIMITS[state.plan].saved,
    trip: tid => state.trips.find(t => t.id === tid),
    isSaved: pid => state.saved.some(p => p.id === pid),
    remember(p) { state.recent = [p].concat(state.recent.filter(x => x.id !== p.id)).slice(0, 12); persist(); },
    findPlace(pid) {
      const all = state.saved.concat(state.recent, state.trips.map(t => t.place).filter(Boolean));
      const hit = all.find(p => p.id === pid);
      if (hit) return hit;
      if (pid.startsWith('b:')) return normPlace(pid.slice(2));
      return null;
    },
    convert(amount, from, to) {
      if (from === to) return amount;
      const m = state.rates.map;
      return m[from] && m[to] ? amount / m[from] * m[to] : null;
    }
  };
  EP.store = S;
})(window.EP = window.EP || {});
