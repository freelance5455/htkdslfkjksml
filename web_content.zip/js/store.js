(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const S = (P.store = {});
  const DB = 'pith';
  const STORES = ['chats', 'media'];
  let db = null;
  let fallback = false;

  function open() {
    return new Promise((res, rej) => {
      if (!window.indexedDB) return rej(new Error('IndexedDB unavailable'));
      const r = indexedDB.open(DB, 1);
      r.onupgradeneeded = () => {
        STORES.forEach((n) => { if (!r.result.objectStoreNames.contains(n)) r.result.createObjectStore(n, { keyPath: 'id' }); });
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.onblocked = () => rej(new Error('blocked'));
    });
  }

  S.init = async function () {
    try { db = await open(); } catch (e) { fallback = true; }
    return !fallback;
  };
  S.usingFallback = () => fallback;

  function tx(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = db.transaction(store, mode);
      const req = fn(t.objectStore(store));
      t.oncomplete = () => res(req ? req.result : undefined);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  }

  // localStorage fallback keeps everything as JSON; blobs become data URLs.
  const lsKey = (store, id) => `pith.${store}.${id}`;
  function lsAll(store) {
    const out = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(`pith.${store}.`)) { try { out.push(JSON.parse(localStorage.getItem(k))); } catch (e) { /* skip */ } }
    }
    return out;
  }
  async function toStored(store, obj) {
    if (store === 'media' && obj.blob) return Object.assign({}, obj, { blob: undefined, dataUrl: await U.blobToDataURL(obj.blob) });
    return obj;
  }
  async function fromStored(store, obj) {
    if (store === 'media' && obj && obj.dataUrl) {
      const blob = await (await fetch(obj.dataUrl)).blob();
      return Object.assign({}, obj, { blob, dataUrl: undefined });
    }
    return obj;
  }

  S.all = async function (store) {
    if (fallback) return Promise.all(lsAll(store).map((o) => fromStored(store, o)));
    return tx(store, 'readonly', (s) => s.getAll());
  };
  S.get = async function (store, id) {
    if (fallback) { const raw = localStorage.getItem(lsKey(store, id)); return raw ? fromStored(store, JSON.parse(raw)) : undefined; }
    return tx(store, 'readonly', (s) => s.get(id));
  };
  S.put = async function (store, obj) {
    if (fallback) { localStorage.setItem(lsKey(store, obj.id), JSON.stringify(await toStored(store, obj))); return; }
    await tx(store, 'readwrite', (s) => s.put(obj));
  };
  S.del = async function (store, id) {
    if (fallback) { localStorage.removeItem(lsKey(store, id)); return; }
    await tx(store, 'readwrite', (s) => s.delete(id));
  };
  S.clear = async function (store) {
    if (fallback) { lsAll(store).forEach((o) => localStorage.removeItem(lsKey(store, o.id))); return; }
    await tx(store, 'readwrite', (s) => s.clear());
  };

  // Small key/value helpers for settings, profile and themes.
  S.getJSON = function (key, dflt) {
    try { const raw = localStorage.getItem('pith.' + key); return raw ? JSON.parse(raw) : dflt; } catch (e) { return dflt; }
  };
  S.setJSON = function (key, value) {
    try { localStorage.setItem('pith.' + key, JSON.stringify(value)); return true; } catch (e) { return false; }
  };

  // ---------------------------------------------------------------- media
  const urls = new Map();
  const M = (P.media = {});
  M.put = async function (blob, meta) {
    const id = U.uid();
    await S.put('media', { id, blob, mime: blob.type || (meta && meta.mime) || 'application/octet-stream', name: (meta && meta.name) || '', size: blob.size });
    return id;
  };
  M.blob = async function (id) { const rec = await S.get('media', id); return rec ? rec.blob : null; };
  M.url = async function (id) {
    if (urls.has(id)) return urls.get(id);
    const blob = await M.blob(id);
    if (!blob) return null;
    const url = URL.createObjectURL(blob);
    urls.set(id, url);
    return url;
  };
  M.remove = async function (id) {
    if (urls.has(id)) { URL.revokeObjectURL(urls.get(id)); urls.delete(id); }
    try { await S.del('media', id); } catch (e) { /* ignore */ }
  };
})();
