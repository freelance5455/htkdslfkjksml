/* ที่เก็บข้อมูลในเครื่อง: ใช้ IndexedDB ถ้าไม่ได้จะสลับไปใช้ localStorage อัตโนมัติ */
var Store = (function () {
  var db = null;
  function open() {
    return new Promise(function (res) {
      if (!window.indexedDB) { res(); return; }
      try {
        var r = indexedDB.open('snaply_db', 1);
        r.onupgradeneeded = function () { r.result.createObjectStore('kv'); };
        r.onsuccess = function () { db = r.result; res(); };
        r.onerror = function () { res(); };
        r.onblocked = function () { res(); };
      } catch (e) { res(); }
    });
  }
  function get(k) {
    return new Promise(function (res) {
      if (!db) {
        try { var v = localStorage.getItem('snaply_' + k); res(v ? JSON.parse(v) : undefined); }
        catch (e) { res(undefined); }
        return;
      }
      try {
        var q = db.transaction('kv', 'readonly').objectStore('kv').get(k);
        q.onsuccess = function () { res(q.result); };
        q.onerror = function () { res(undefined); };
      } catch (e) { res(undefined); }
    });
  }
  function set(k, v) {
    return new Promise(function (res, rej) {
      if (!db) {
        try { localStorage.setItem('snaply_' + k, JSON.stringify(v)); res(); }
        catch (e) { rej(e); }
        return;
      }
      try {
        var t = db.transaction('kv', 'readwrite');
        t.objectStore('kv').put(v, k);
        t.oncomplete = function () { res(); };
        t.onerror = function () { rej(t.error); };
        t.onabort = function () { rej(t.error); };
      } catch (e) { rej(e); }
    });
  }
  return { open: open, get: get, set: set };
})();
