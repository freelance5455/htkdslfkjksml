Inpts | دخلي — مشروع Android WebView

المحتويات:
- app/src/main/assets/index.html: نسخة البرنامج المضمنة داخل التطبيق.
- أيقونة التطبيق موجودة في مجلدات mipmap.
- التطبيق لا يطلب صلاحية الإنترنت، ويحمّل واجهته من ملفات داخلية.
- حفظ البيانات يعتمد على localStorage في WebView.

لبناء APK:
1) ثبّت Android Studio على الكمبيوتر.
2) افتح مجلد InptsDakhli-Android من Android Studio.
3) انتظر Gradle Sync. قد يحتاج Android Studio تنزيل Android Gradle Plugin وAndroid SDK 35.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد APK غالباً داخل app/build/outputs/apk/debug/app-debug.apk

ملاحظات النسخة الحالية:
- حفظ مصادر الدخل والأرقام والملاحظات محلي على نفس الجهاز.
- لا يوجد اتصال أو مزامنة سحابية.
- صور التحويل كانت تعتمد على خدمة سحابية غير مضمنة في ملف HTML الأصلي؛ لذلك تم توضيح أنها غير مفعلة في هذه النسخة.
- الخطوط الخارجية أزيلت حتى لا يحتاج التطبيق للإنترنت؛ يستخدم خطوط النظام العربية.
