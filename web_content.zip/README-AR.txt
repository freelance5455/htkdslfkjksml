TRUST WAY - Courier APK Builder
================================
هذا ZIP مجهز للرفع مباشرة إلى HTML to APK Builder.

مهم:
- index.html موجود في جذر الملف.
- manifest.json و service-worker.js موجودان أيضًا في الجذر.
- التطبيق تجريبي حاليًا ببيانات شحنات داخلية.
- بعد نجاح بناء APK يمكن ربط التطبيق بقاعدة بيانات ولوحة تحكم TRUST WAY.
