AnimeMind AI — تطبيق أندرويد
==============================

ده مشروع Android Studio يحوّل واجهة AnimeMind إلى تطبيق Android بسيط باستخدام WebView.
الملفات الأساسية للموقع موجودة داخل app/src/main/assets/index.html.

طريقة إنشاء APK:
1) نزّل وثبّت Android Studio من الموقع الرسمي:
   https://developer.android.com/studio
2) فك ضغط ملف AnimeMind_Android_Project.zip.
3) افتح Android Studio ثم اختَر Open وافتح مجلد AnimeMind_Android.
4) انتظر Gradle Sync. لو طلب تثبيت Android SDK، وافق.
5) من القائمة Build اختَر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد انتهاء البناء، اضغط locate في إشعار Android Studio للوصول إلى ملف APK.
7) انقل APK إلى هاتف Android وثبّته. قد يطلب الهاتف السماح بالتثبيت من مصدر الملف.

مهم:
- هذا مشروع المصدر، وليس ملف APK جاهزًا للتثبيت.
- بيانات الأنمي تتطلب اتصال إنترنت.
- ميزة AI الحقيقية تتطلب خادم API ومفتاحًا محفوظًا على الخادم. لا تضع مفتاح API داخل HTML أو التطبيق.
- لو صفحة AI مضبوطة على عنوان خادم محلي مثل localhost، فلن يعمل ذلك على هاتفك تلقائيًا؛ يجب نشر الخادم أو ضبط عنوانه إلى عنوان يمكن للهاتف الوصول إليه.
- رابط شرح WebView الرسمي:
  https://developer.android.com/develop/ui/views/layout/webapps/webview
