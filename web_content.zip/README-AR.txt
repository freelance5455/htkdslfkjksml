مربعات الحروف - مشروع Android لتحويل اللعبة إلى APK

المشروع يضم ملفات اللعبة محليًا داخل التطبيق؛ لذلك لا يحتاج التطبيق إلى الإنترنت للعب.

طريقة استخراج APK:
1) نزّل Android Studio على كمبيوتر.
2) فك ضغط هذا الملف.
3) افتح مجلد MorabaatHorouf في Android Studio.
4) انتظر مزامنة Gradle وتنزيل مكونات Android المطلوبة.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) ستجد APK التجريبي عادةً في:
   app/build/outputs/apk/debug/app-debug.apk

بديل باستخدام GitHub:
- ارفع محتويات المجلد إلى مستودع GitHub.
- ملف .github/workflows/build-apk.yml سيبني APK تلقائيًا.
- من تبويب Actions افتح آخر تشغيل ناجح ثم نزّل artifact باسم morabaat-horouf-apk.

ملاحظة:
هذا ملف مشروع Android جاهز للبناء، وليس ملف APK مبنيًا بالفعل. يلزم Android SDK/Gradle أو تشغيل GitHub Actions لبناء APK.
