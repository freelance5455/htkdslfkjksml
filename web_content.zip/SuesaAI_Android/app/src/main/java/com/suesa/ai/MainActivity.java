package com.suesa.ai;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.ViewGroup;
import android.webkit.*;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final int REQ_PHOTO=10, REQ_CAMERA=11, REQ_FILES=12, REQ_OVERLAY=13, REQ_CAPTURE=14;
    WebView web; String pendingAction="";
    @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); setup();}
    void setup(){
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient()); web.setBackgroundColor(0x00111111); web.addJavascriptInterface(new Bridge(this),"SuesaNative");
        web.loadUrl("file:///android_asset/index.html");
    }
    void runJs(String js){runOnUiThread(()->web.evaluateJavascript(js,null));}
    void photo(){ pendingAction="photo"; if(Build.VERSION.SDK_INT>=33){ if(checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES},REQ_PHOTO); else openPhoto(); } else { if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},REQ_PHOTO); else openPhoto(); } }
    void openPhoto(){ Intent i; if(Build.VERSION.SDK_INT>=33){i=new Intent("android.provider.action.PICK_IMAGES");i.setType("image/*");}else{i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);} startActivityForResult(i,REQ_PHOTO); }
    void camera(){ pendingAction="camera"; if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA); else openCamera(); }
    void openCamera(){ Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); startActivityForResult(i,REQ_CAMERA); }
    void files(){ pendingAction="files"; if(Build.VERSION.SDK_INT<=32 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},REQ_FILES);return;} if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES,Manifest.permission.READ_MEDIA_VIDEO,Manifest.permission.READ_MEDIA_AUDIO},REQ_FILES);return;} openFiles(); }
    void openFiles(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_FILES);}
    void overlay(){ if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())),REQ_OVERLAY);return;} requestCapture(); }
    void requestCapture(){MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),REQ_CAPTURE);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data); if(req==REQ_OVERLAY){if(Build.VERSION.SDK_INT<23||Settings.canDrawOverlays(this))requestCapture();return;} if(req==REQ_CAPTURE){if(res==RESULT_OK&&data!=null){Intent si=new Intent(this,OverlayService.class);si.putExtra("resultCode",res);si.putExtra("data",data);if(Build.VERSION.SDK_INT>=26)startForegroundService(si);else startService(si);}else Toast.makeText(this,"Ekran izni verilmedi.",Toast.LENGTH_SHORT).show();return;} if(res!=RESULT_OK||data==null)return; if(req==REQ_CAMERA){Bitmap b=data.getParcelableExtra("data");if(b!=null)sendBitmap(b,"Kamera.jpg");return;} if(req==REQ_PHOTO||req==REQ_FILES){ClipData c=data.getClipData(); if(c!=null){for(int j=0;j<c.getItemCount();j++)sendUri(c.getItemAt(j).getUri());}else if(data.getData()!=null)sendUri(data.getData());}}
    void sendUri(Uri u){try{String type=getContentResolver().getType(u);String name="Dosya";CursorWrap cw=new CursorWrap(this,u);name=cw.name;InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();String b64=android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP);runJs("nativeFileSelected("+JSONObject.quote(name)+","+JSONObject.quote(type==null?"application/octet-stream":type)+","+JSONObject.quote("data:"+(type==null?"application/octet-stream":type)+";base64,"+b64)+")");}catch(Exception e){Toast.makeText(this,"Dosya okunamadı: "+e.getMessage(),Toast.LENGTH_SHORT).show();}}
    void sendBitmap(Bitmap b,String name){ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,90,out);String b64=android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP);runJs("nativeFileSelected("+JSONObject.quote(name)+",\"image/jpeg\",\"data:image/jpeg;base64,"+b64+"\")");}
    static class CursorWrap{String name="Dosya";CursorWrap(Context c,Uri u){try(android.database.Cursor x=c.getContentResolver().query(u,null,null,null,null)){if(x!=null&&x.moveToFirst()){int k=x.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(k>=0)name=x.getString(k);}}catch(Exception ignored){}}}
    static class Bridge{
        final MainActivity a; Bridge(MainActivity x){a=x;}
        @JavascriptInterface public void pickPhoto(){a.photo();}
        @JavascriptInterface public void openCamera(){a.camera();}
        @JavascriptInterface public void pickFiles(){a.files();}
        @JavascriptInterface public void openOverlay(){a.overlay();}
        @JavascriptInterface public void setApiKey(String k){a.getSharedPreferences("suesa",0).edit().putString("api",k==null?"":k).apply();}
    }
}
