# Suesa AI Android

Bu proje Suesa AI HTML arayüzünü Android WebView içinde çalıştırır ve istenen Android özelliklerini ekler:

- Fotoğraf: ilk kullanımda fotoğraf erişim izni, ardından galeriden seçim
- Kamera: ilk kullanımda kamera izni, ardından kamera açılır
- Dosyalar: Android dosya seçicisi ile tüm dosya türleri; eski Android sürümlerinde depolama izni istenir
- Paneli Aç: overlay izni + ekran paylaşımı izni ister, küçük yüzen Suesa panelini açar
- Ekranı Gör: ekran görüntüsünü Gemini ile analiz edip panel içinde kısa Türkçe açıklama gösterir

## Açma
Android Studio ile klasörü açıp Gradle Sync ve Run yapabilirsin. Android Studio gerekli Gradle/SDK bileşenlerini indirir.

Not: Overlay ve ekran görüntüsü özellikleri yalnızca Android uygulaması olarak çalışır; düz HTML dosyasında sistem üzerinde gerçek yüzen pencere oluşturulamaz.
