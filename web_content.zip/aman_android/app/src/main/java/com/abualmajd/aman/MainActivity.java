package com.abualmajd.aman;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.view.View;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(15, 23, 42));
    getWindow().setNavigationBarColor(Color.rgb(15, 23, 42));
    WebView web = new WebView(this);
    web.setBackgroundColor(Color.rgb(244, 247, 251));
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(false);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(false);
    settings.setSupportZoom(false);
    web.setOverScrollMode(View.OVER_SCROLL_NEVER);
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
}
