FAMILY GAME 3D — Android APK project

Как получить APK только с телефона:
1. Откройте github.com в Chrome и войдите/создайте аккаунт.
2. Создайте новый репозиторий (New repository), например FamilyGame3D. Можно выбрать Private.
3. Загрузите содержимое этой папки в репозиторий (Add file -> Upload files). Важно загрузить папки app и .github, а также файлы build.gradle, settings.gradle и gradle.properties.
4. Нажмите Commit changes.
5. Откройте вкладку Actions. Если появится запрос Enable workflows — подтвердите.
6. Откройте workflow “Build Family Game 3D APK” и дождитесь зелёной галочки.
7. Откройте завершённый запуск и внизу раздел Artifacts. Скачайте Family-Game-3D-APK.zip.
8. Распакуйте ZIP на телефоне. Внутри будет app-debug.apk. Откройте его и разрешите установку из этого источника, если Android спросит.

Примечания:
- Игра открывается на весь экран в альбомной ориентации.
- Для загрузки Three.js и Google Fonts нужен интернет.
- Сохранения игры хранятся локально в данных приложения WebView. Не очищайте данные приложения, если хотите сохранить миры.
- Это debug APK для личной установки, не подписанный релиз для Google Play.
