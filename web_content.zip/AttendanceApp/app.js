let selectedMonth = new Date().toISOString().slice(0, 7);

let attendanceData =
    JSON.parse(localStorage.getItem("attendanceData")) || {};

let pmData =
    JSON.parse(localStorage.getItem("pmData")) || {};


/* =========================
   MONTH SELECTOR
========================= */

function createMonthSelector() {

    const selector = document.getElementById("monthSelector");

    selector.innerHTML = "";

    const year = new Date().getFullYear();

    for (let month = 0; month < 12; month++) {

        const value =
            year + "-" + String(month + 1).padStart(2, "0");

        const option = document.createElement("option");

        option.value = value;

        option.textContent =
            new Date(year, month, 1).toLocaleString(
                "en-US",
                { month: "long" }
            ) + " " + year;

        if (value === selectedMonth) {
            option.selected = true;
        }

        selector.appendChild(option);
    }
}


/* =========================
   CHANGE MONTH
========================= */

function changeMonth() {

    selectedMonth =
        document.getElementById("monthSelector").value;

    updateSummary();
}


/* =========================
   MONTH NAME
========================= */

function getMonthName(monthValue) {

    const parts = monthValue.split("-");

    const date =
        new Date(
            Number(parts[0]),
            Number(parts[1]) - 1,
            1
        );

    return date.toLocaleString(
        "en-US",
        { month: "long" }
    );
}


/* =========================
   SCREEN CONTROL
========================= */

function openAttendance() {

    document.getElementById("homeScreen")
        .classList.add("hidden");

    document.getElementById("pmScreen")
        .classList.add("hidden");

    document.getElementById("attendanceScreen")
        .classList.remove("hidden");

    history.pushState(
        { screen: "attendance" },
        "",
        "#attendance"
    );

    loadAttendance();
}


function openPM() {

    document.getElementById("homeScreen")
        .classList.add("hidden");

    document.getElementById("attendanceScreen")
        .classList.add("hidden");

    document.getElementById("pmScreen")
        .classList.remove("hidden");

    history.pushState(
        { screen: "pm" },
        "",
        "#pm"
    );

    loadPM();
}


function goHome() {

    document.getElementById("attendanceScreen")
        .classList.add("hidden");

    document.getElementById("pmScreen")
        .classList.add("hidden");

    document.getElementById("homeScreen")
        .classList.remove("hidden");

    updateSummary();
}


/* =========================
   PHONE BACK BUTTON
========================= */

window.addEventListener("popstate", function () {

    const attendanceScreen =
        document.getElementById("attendanceScreen");

    const pmScreen =
        document.getElementById("pmScreen");

    const homeScreen =
        document.getElementById("homeScreen");


    if (!attendanceScreen.classList.contains("hidden")) {

        goHome();

        return;
    }


    if (!pmScreen.classList.contains("hidden")) {

        goHome();

        return;
    }

});


/* =========================
   DATE KEY
========================= */

function makeDateKey(day) {

    return selectedMonth +
        "-" +
        String(day).padStart(2, "0");
}


/* =========================
   LOAD ATTENDANCE
========================= */

function loadAttendance() {

    const list =
        document.getElementById("attendanceList");

    list.innerHTML = "";

    const [year, month] =
        selectedMonth.split("-").map(Number);

    const daysInMonth =
        new Date(year, month, 0).getDate();


    for (let day = 1; day <= daysInMonth; day++) {

        const dateKey = makeDateKey(day);

        if (!attendanceData[dateKey]) {

            attendanceData[dateKey] = {
                status: null,
                ot: false
            };
        }

        const data =
            attendanceData[dateKey];

        const dateObject =
            new Date(year, month - 1, day);

        const dayName =
            dateObject.toLocaleString(
                "en-US",
                { weekday: "short" }
            );


        const card =
            document.createElement("div");

        card.className = "day-card";


        let statusText = "";

        if (!data.status) {

            statusText =
                `<div class="pending">⏳ Pending</div>`;
        }


        card.innerHTML = `

            <div class="day-header">

                <div class="day-number">
                    Day ${day}
                </div>

                <div class="day-date">
                    ${dayName}, ${day}
                    ${getMonthName(selectedMonth)}
                </div>

            </div>


            <div class="status-buttons">

                <button
                    class="${data.status === "Present"
                        ? "active-present" : ""}"
                    onclick="setStatus('${dateKey}', 'Present')">

                    Present

                </button>


                <button
                    class="${data.status === "Absent"
                        ? "active-absent" : ""}"
                    onclick="setStatus('${dateKey}', 'Absent')">

                    Absent

                </button>


                <button
                    class="${data.status === "Leave"
                        ? "active-leave" : ""}"
                    onclick="setStatus('${dateKey}', 'Leave')">

                    Leave

                </button>

            </div>


            ${statusText}


            <div class="ot-row">

                <span class="ot-label">
                    🟡 OT
                </span>


                <label class="switch">

                    <input
                        type="checkbox"
                        ${data.ot ? "checked" : ""}
                        onchange="changeOT('${dateKey}', this.checked)"
                    >

                    <span class="slider"></span>

                </label>

            </div>
        `;


        list.appendChild(card);
    }
}


/* =========================
   SET STATUS
========================= */

function setStatus(dateKey, status) {

    if (!attendanceData[dateKey]) {

        attendanceData[dateKey] = {
            status: null,
            ot: false
        };
    }

    attendanceData[dateKey].status = status;

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    loadAttendance();

    updateSummary();
}


/* =========================
   OT
========================= */

function changeOT(dateKey, value) {

    if (!attendanceData[dateKey]) {

        attendanceData[dateKey] = {
            status: null,
            ot: false
        };
    }

    attendanceData[dateKey].ot = value;

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    updateSummary();
}


/* =========================
   SAVE ATTENDANCE
========================= */

function saveAttendance() {

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    alert("Attendance saved successfully! ✅");
}


/* =========================
   SUMMARY
========================= */

function updateSummary() {

    let present = 0;
    let absent = 0;
    let otDays = 0;


    Object.keys(attendanceData).forEach(key => {

        if (!key.startsWith(selectedMonth)) {
            return;
        }

        const data = attendanceData[key];


        if (data.status === "Present") {
            present++;
        }


        if (data.status === "Absent") {
            absent++;
        }


        if (data.ot === true) {
            otDays++;
        }

    });


    document.getElementById("presentCount")
        .textContent = present;

    document.getElementById("absentCount")
        .textContent = absent;

    document.getElementById("otDays")
        .textContent = otDays;
}


/* =========================
   PM TRACKER
========================= */

function loadPM() {

    const data =
        pmData[selectedMonth] || {};

    document.getElementById("pm1").value =
        data.pm1 || "";

    document.getElementById("pm2").value =
        data.pm2 || "";

    document.getElementById("pm3").value =
        data.pm3 || "";

    document.getElementById("pm4").value =
        data.pm4 || "";

    document.getElementById("pm5").value =
        data.pm5 || "";

    document.getElementById("monthlyPM").value =
        data.monthlyPM || "";
}


/* =========================
   SAVE PM
========================= */

function savePM() {

    pmData[selectedMonth] = {

        pm1: document.getElementById("pm1").value,

        pm2: document.getElementById("pm2").value,

        pm3: document.getElementById("pm3").value,

        pm4: document.getElementById("pm4").value,

        pm5: document.getElementById("pm5").value,

        monthlyPM:
            document.getElementById("monthlyPM").value
    };


    localStorage.setItem(
        "pmData",
        JSON.stringify(pmData)
    );


    alert("PM details saved successfully! ✅");
}


/* =========================
   START APP
========================= */

createMonthSelector();

updateSummary();