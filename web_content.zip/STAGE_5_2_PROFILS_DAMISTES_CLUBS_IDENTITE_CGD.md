# Étape 5.2 — Identité CGD et profils consultables

## Identité du jeu
- Nom public officiel : **CGD – Championnat Galactique de Dames**.
- Suppression de l’ancienne mention de version dans l’écran d’accueil, l’en-tête, le titre de page et le manifeste installable.
- Conservation de la clé de sauvegarde historique pour ne pas perdre les carrières existantes.

## Profils
- Les cartes des damistes du tableau de bord sont désormais interactives.
- Chaque fiche affiche les données réellement présentes dans la sauvegarde : club, division, niveau, forme et autres attributs disponibles.
- Les clubs listés dans les divisions ouvrent une fiche avec division, points, bilan sportif, effectif et manager.
- Les fiches s’ouvrent dans une fenêtre accessible et se ferment par le bouton dédié ou un clic sur le fond.

## Limite des portraits
Les pastilles avec initiales sont des avatars provisoires, pas des photographies. Les portraits photographiques doivent être ajoutés à partir d’images fournies ou dont les droits d’utilisation sont établis ; aucune photo réelle n’a été inventée ou attribuée à un damiste.

## Vérification
- `npm test` : 258 tests réussis.
- `node --check src/app.js` : syntaxe vérifiée.
- Le test visuel complet sur navigateur et mobile reste à effectuer.
