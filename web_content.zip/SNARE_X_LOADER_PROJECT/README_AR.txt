SNARE X LOADER — مشروع بداية كامل (Android + PHP/MySQL)

المحتويات:
- android/: مشروع Android Studio بلغة Java، شاشة تفعيل وفحص مفتاح عبر API.
- server/: ملفات PHP وSQL لواجهة التحقق وإنشاء مفاتيح تفعيل.

مهم قبل الاستخدام:
1) ارفع مجلد server إلى استضافة تدعم PHP وMySQL عبر HTTPS.
2) أنشئ قاعدة بيانات MySQL واستورد server/sql/schema.sql.
3) عدّل بيانات الاتصال في server/api/config.php.
4) غيّر ADMIN_TOKEN في config.php إلى قيمة سرية قوية.
5) في Android، تم ضبط API_URL على https://jssjshbw.kesug.com/api/verify.php. تأكد أن الملف موجود فعلاً في public_html/api/verify.php وأن config.php يحتوي بيانات MySQL الصحيحة، وأن قاعدة البيانات متوافقة مع schema.sql.
6) افتح مجلد android في Android Studio واعمل Sync ثم Build APK.

هذا مشروع أساسي قابل للتعديل وليس APK مبنياً مسبقاً. لا يحتوي وظائف غش أو تجاوز حماية ألعاب، ولا توجد مفاتيح حقيقية مضمّنة. يجب اختبار API على استضافتك قبل إصدار التطبيق.
