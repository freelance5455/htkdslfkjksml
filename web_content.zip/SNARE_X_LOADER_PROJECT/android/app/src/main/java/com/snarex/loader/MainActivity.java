package com.snarex.loader;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    // غيّر هذا الرابط إلى رابط verify.php على استضافتك، ويجب أن يكون HTTPS.
    private static final String API_URL = "https://excerpt.gt.tc/verify.php";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText keyInput;
    private TextView status;
    private Button activate;
    private ProgressBar progress;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(13,13,13));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(38), dp(24), dp(24));
        setContentView(root);

        TextView brand = new TextView(this);
        brand.setText("SNARE X LOADER"); brand.setTextColor(Color.WHITE);
        brand.setTextSize(28); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER); root.addView(brand, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("ENTER YOUR ACTIVATION KEY"); subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13); subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = matchWrap(); subLp.topMargin = dp(12); subLp.bottomMargin = dp(26);
        root.addView(subtitle, subLp);

        keyInput = new EditText(this); keyInput.setSingleLine(true);
        keyInput.setHint("Activation code"); keyInput.setHintTextColor(Color.GRAY);
        keyInput.setTextColor(Color.WHITE); keyInput.setPadding(dp(16), dp(14), dp(16), dp(14));
        keyInput.setBackground(round(Color.rgb(31,31,31), dp(12), Color.rgb(65,65,65)));
        root.addView(keyInput, matchWrap());

        activate = new Button(this); activate.setText("ACTIVATE"); activate.setTextColor(Color.WHITE);
        activate.setBackground(round(Color.rgb(211,35,39), dp(12), Color.TRANSPARENT));
        LinearLayout.LayoutParams btnLp = matchWrap(); btnLp.topMargin = dp(16);
        root.addView(activate, btnLp);

        progress = new ProgressBar(this); progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(dp(42), dp(42)); pLp.topMargin = dp(18);
        root.addView(progress, pLp);

        status = new TextView(this); status.setTextColor(Color.LTGRAY); status.setTextSize(14);
        status.setGravity(Gravity.CENTER); LinearLayout.LayoutParams stLp = matchWrap(); stLp.topMargin = dp(18);
        root.addView(status, stLp);
        activate.setOnClickListener(v -> verifyKey());
    }

    private void verifyKey() {
        String key = keyInput.getText().toString().trim();
        if (key.isEmpty()) { status.setText("Please enter an activation key."); return; }
        if (API_URL.contains("YOUR-DOMAIN.example")) { status.setText("Set your server API URL in MainActivity.java first."); return; }
        activate.setEnabled(false); progress.setVisibility(View.VISIBLE); status.setText("Checking key...");
        executor.execute(() -> {
            String message;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(API_URL).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(20000);
                c.setReadTimeout(20000);
                c.setDoOutput(true);
                c.setUseCaches(false);
                c.setInstanceFollowRedirects(false);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("Accept-Encoding", "identity");
                c.setRequestProperty("User-Agent", "SNARE-X-LOADER/1.0");
                JSONObject body = new JSONObject();
                body.put("key", key);
                body.put("code", key);
                byte[] requestBytes = body.toString().getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(requestBytes.length);
                try (OutputStream os = c.getOutputStream()) { os.write(requestBytes); }

                int responseCode = c.getResponseCode();
                if (responseCode >= 300 && responseCode < 400) {
                    String location = c.getHeaderField("Location");
                    message = "Server redirect HTTP " + responseCode + (location == null ? "" : " to " + location);
                } else {
                    InputStream stream = (responseCode >= 200 && responseCode < 400) ? c.getInputStream() : c.getErrorStream();
                    if (stream == null) {
                        message = "Server HTTP " + responseCode + " (empty response).";
                    } else {
                        StringBuilder result = new StringBuilder();
                        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                            String line; while ((line = br.readLine()) != null) result.append(line);
                        }
                        String responseText = result.toString().trim();
                        try {
                            JSONObject json = new JSONObject(responseText);
                            boolean valid = responseCode == 200 && json.optBoolean("valid", false);
                            if (valid) {
                                message = "Activation successful!";
                            } else {
                                String serverMessage = json.optString("message", "No message");
                                message = "Server HTTP " + responseCode + ": " + serverMessage;
                            }
                        } catch (org.json.JSONException badJson) {
                            if (responseText.length() > 160) responseText = responseText.substring(0, 160);
                            message = "Server HTTP " + responseCode + ": non-JSON response: " + responseText;
                        }
                    }
                }
            } catch (Exception e) {
                // Show the exception type so the connection issue can be diagnosed without guessing.
                String detail = e.getMessage();
                if (detail == null || detail.trim().isEmpty()) detail = "No details";
                if (detail.length() > 140) detail = detail.substring(0, 140);
                message = "Connection error: " + e.getClass().getSimpleName() + " - " + detail;
            } finally {
                if (c != null) c.disconnect();
            }
            final String out = message;
            runOnUiThread(() -> { status.setText(out); progress.setVisibility(View.GONE); activate.setEnabled(true); });
        });
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
    private GradientDrawable round(int color, int radius, int stroke) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke); return d; }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }
}
