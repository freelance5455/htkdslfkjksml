# Keep Android entry points and JSON model APIs needed by platform/reflection.
-keep public class com.snarex.loader.MainActivity { public *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn org.json.**
