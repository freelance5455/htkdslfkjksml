<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function api_reply(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    api_reply(['valid' => false, 'message' => 'POST required'], 405);
}

$raw = file_get_contents('php://input') ?: '';
$payload = json_decode($raw, true);
if (!is_array($payload)) $payload = $_POST;
$key = trim((string)($payload['key'] ?? $payload['code'] ?? ''));
if ($key === '' || strlen($key) > 128) {
    api_reply(['valid' => false, 'message' => 'Enter a valid key.'], 400);
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    $stmt = $pdo->prepare('SELECT code, expires_at FROM activation_codes WHERE code = ? LIMIT 1');
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    if (!$row) api_reply(['valid' => false, 'message' => 'Invalid key.']);
    if (!empty($row['expires_at']) && strtotime((string)$row['expires_at']) < time()) {
        api_reply(['valid' => false, 'message' => 'Key expired.']);
    }
    api_reply(['valid' => true, 'message' => 'Activation successful.']);
} catch (Throwable $e) {
    error_log('verify API error: ' . $e->getMessage());
    api_reply(['valid' => false, 'message' => 'Server configuration/database error.'], 500);
}
