<?php
require __DIR__.'/config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['valid'=>false,'message'=>'POST required'], 405);
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
$key = trim((string)($data['key'] ?? ''));
if ($key === '' || strlen($key) > 128) respond(['valid'=>false,'message'=>'Enter a valid key.'], 400);
try {
    $stmt = db()->prepare('SELECT id, expires_at, is_active FROM activation_keys WHERE key_hash = ? LIMIT 1');
    $stmt->execute([hash('sha256', $key)]);
    $row = $stmt->fetch();
    if (!$row || (int)$row['is_active'] !== 1) respond(['valid'=>false,'message'=>'Invalid or disabled key.']);
    if ($row['expires_at'] !== null && strtotime($row['expires_at'].' UTC') < time()) respond(['valid'=>false,'message'=>'Key expired.']);
    respond(['valid'=>true,'message'=>'Activation successful.']);
} catch (Throwable $e) {
    error_log('verify API error: '.$e->getMessage());
    respond(['valid'=>false,'message'=>'Server configuration error.'], 500);
}
