<?php
// Endpoint إداري لإنشاء مفتاح. استخدمه مؤقتاً عبر HTTPS، ثم احذفه أو عطّله بعد الاستخدام.
require __DIR__.'/config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['ok'=>false,'message'=>'POST required'], 405);
$provided = $_SERVER['HTTP_X_ADMIN_TOKEN'] ?? '';
if (!hash_equals(ADMIN_TOKEN, $provided)) respond(['ok'=>false,'message'=>'Unauthorized'], 401);
$data = json_decode(file_get_contents('php://input'), true) ?: [];
$days = (int)($data['days'] ?? 30);
if ($days < 1 || $days > 3650) respond(['ok'=>false,'message'=>'days must be 1..3650'], 400);
try {
    $key = 'SNX-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(4)));
    $expires = gmdate('Y-m-d H:i:s', time() + $days * 86400);
    $stmt = db()->prepare('INSERT INTO activation_keys (key_hash, expires_at, is_active, created_at) VALUES (?, ?, 1, UTC_TIMESTAMP())');
    $stmt->execute([hash('sha256', $key), $expires]);
    respond(['ok'=>true,'key'=>$key,'expires_at_utc'=>$expires]);
} catch (Throwable $e) {
    error_log('create key error: '.$e->getMessage());
    respond(['ok'=>false,'message'=>'Could not create key.'], 500);
}
