-- Reference schema for verify.php. Do not run if this table already exists.
CREATE TABLE IF NOT EXISTS activation_codes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(128) NOT NULL UNIQUE,
  plan VARCHAR(80) NULL,
  duration_days INT NULL,
  max_devices INT NOT NULL DEFAULT 1,
  used_by VARCHAR(255) NULL,
  used_at DATETIME NULL,
  expires_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
