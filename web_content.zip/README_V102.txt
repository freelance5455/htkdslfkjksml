CryptoPulse V102 - LBank Candle History Fix
- Historical K-line time anchors are minute-aligned.
- REST K-line responses are strictly validated.
- Explicit WebSocket one-time 1-minute K-line history request is used when REST history is short.
- More wrapped LBank history response formats are parsed.
- History is merged by candle timestamp.
- Asset chart waits for meaningful history before falling back to live-only candles.
- A small candle-count diagnostic is shown.
