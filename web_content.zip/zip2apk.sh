#!/usr/bin/env bash
# zip2apk.sh - يحوّل ملف zip لمشروع أندرويد (Gradle) إلى APK
# الاستخدام:  ./zip2apk.sh project.zip [debug|release]
# المتطلبات: Docker + unzip  |  المساحة الموصى بها: 3x حجم الملف

set -euo pipefail

ZIP="${1:?الاستخدام: ./zip2apk.sh project.zip [debug|release]}"
MODE="${2:-debug}"
OUT="$(pwd)/output"
WORK="$(mktemp -d ./.zip2apk-XXXXXX)"   # داخل المجلد الحالي لتفادي امتلاء /tmp
WORK="$(cd "$WORK" && pwd)"
trap 'rm -rf "$WORK"' EXIT

case "$MODE" in
  debug)   TASK="assembleDebug" ;;
  release) TASK="assembleRelease" ;;
  *) echo "الوضع يجب أن يكون debug أو release"; exit 1 ;;
esac

command -v docker >/dev/null || { echo "Docker غير مثبت"; exit 1; }
command -v unzip  >/dev/null || { echo "unzip غير مثبت"; exit 1; }
mkdir -p "$OUT"

echo "[1/3] فك الضغط..."
unzip -q "$ZIP" -d "$WORK"

# إيجاد جذر المشروع (المجلد الذي فيه settings.gradle أو gradlew)
MARK="$(find "$WORK" -maxdepth 4 \( -name gradlew -o -name settings.gradle -o -name settings.gradle.kts \) | head -n1)"
[ -n "$MARK" ] || { echo "لم أجد مشروع Gradle داخل الملف"; exit 1; }
ROOT="$(dirname "$MARK")"

echo "[2/3] البناء ($TASK) - أول مرة تستغرق وقتاً لتنزيل الأدوات..."
docker run --rm \
  -v "$ROOT":/project \
  -v zip2apk-gradle-cache:/root/.gradle \
  -w /project \
  mingc/android-build-box:latest \
  bash -c 'if [ -f gradlew ]; then chmod +x gradlew && ./gradlew '"$TASK"' --no-daemon; else gradle '"$TASK"' --no-daemon; fi'

echo "[3/3] نسخ ملفات APK..."
find "$ROOT" -path "*build/outputs/apk*" -name "*.apk" -exec cp -v {} "$OUT"/ \;

echo "تم. الملفات في: $OUT"
[ "$MODE" = "release" ] && echo "ملاحظة: نسخة release غير موقّعة ما لم يكن التوقيع مضبوطاً في المشروع."
