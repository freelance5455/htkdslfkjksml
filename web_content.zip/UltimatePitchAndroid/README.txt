ULTIMATE PITCH — Android app project

This is an Android Studio project that wraps the playable Ultimate Pitch HTML game in an Android WebView. It is not a compiled APK yet.

BUILD AN APK
1. Open this folder in Android Studio on a computer.
2. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the generated APK location, usually app/build/outputs/apk/debug/app-debug.apk.
5. Transfer that APK to your Android phone and open it to install. You may need to allow installation from that file manager/browser in Android settings.

ANDROID PHONE ONLY
If you don't have a computer, use a reputable Android IDE/build environment that supports Gradle Android projects. Import this project, allow it to sync/build, then install the generated APK. Availability and steps vary by app.

FEATURES
- Runs the current Ultimate Pitch playable prototype inside an Android app.
- Offline HTML asset; no internet permission is requested.
- Built-in cheat codes: RICHCLUB, SUPERKICK, WINMATCH, SCOUTTEAM.

NOTE
This packages the current 2D prototype, not a finished high-graphics 3D football game. It does not include online multiplayer. The app project needs Android build tools to compile and sign an APK.
