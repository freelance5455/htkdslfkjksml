package com.sahand.icdl

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec

class MainActivity : Activity() {
    private val alias = "SAHAND_ICDL_DEVICE_KEY_V1"
    private val appId = "SAHAND-ICDL-PRO-1"
    private val adminPublicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEaWn/42I90yXuq4eQMVAEOXx+/V5m8UmXiMCrRetE7ILMAYTCLJxMoHAQscBjmFp9712dZsetUybytWWPM0VwqA=="
    private lateinit var devicePublicKeyB64: String
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20,33,61)
        window.navigationBarColor = Color.rgb(20,33,61)
        devicePublicKeyB64 = ensureDeviceKey()
        val token = getSharedPreferences("license", MODE_PRIVATE).getString("token", null)
        if (token != null && validateToken(token)) showApp() else showActivation()
    }

    private fun ensureDeviceKey(): String {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(alias)) {
            val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                .setDigests(KeyProperties.DIGEST_SHA256)
                .setUserAuthenticationRequired(false)
                .build()
            gen.initialize(spec); gen.generateKeyPair()
        }
        val cert = ks.getCertificate(alias)
        return Base64.encodeToString(cert.publicKey.encoded, Base64.NO_WRAP)
    }

    private fun showActivation() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(24,28,24,28); setBackgroundColor(Color.rgb(243,246,251)) }
        val title = TextView(this).apply { text="فعال‌سازی آزمون ICDL"; textSize=25f; setTextColor(Color.rgb(20,33,61)); gravity=Gravity.CENTER; setTypeface(null,1) }
        val info = TextView(this).apply { text="این نسخه به‌صورت آفلاین و با مجوز اختصاصی هر گوشی فعال می‌شود. شناسه زیر را برای صادرکننده مجوز ارسال کنید."; textSize=15f; setTextColor(Color.DKGRAY); gravity=Gravity.CENTER; setPadding(0,16,0,16) }
        val keyLabel = TextView(this).apply { text="شناسه امن این دستگاه"; textSize=16f; setTextColor(Color.BLACK); gravity=Gravity.CENTER }
        val keyView = TextView(this).apply { text=devicePublicKeyB64; textSize=10f; setTextColor(Color.rgb(36,87,166)); setTextIsSelectable(true); gravity=Gravity.CENTER; setPadding(8,12,8,12); setBackgroundColor(Color.WHITE) }
        val copy = Button(this).apply { text="کپی شناسه دستگاه"; setOnClickListener { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Device Key",devicePublicKeyB64)); Toast.makeText(this@MainActivity,"شناسه کپی شد",Toast.LENGTH_SHORT).show() } }
        val tokenLabel=TextView(this).apply { text="کد مجوز دریافتی را وارد کنید"; textSize=15f; setTextColor(Color.BLACK); setPadding(0,18,0,6) }
        val tokenInput=EditText(this).apply { hint="کد مجوز"; minLines=3; gravity=Gravity.TOP; setTextIsSelectable(true); setBackgroundColor(Color.WHITE) }
        val activate=Button(this).apply { text="فعال‌سازی برنامه"; setOnClickListener { val t=tokenInput.text.toString().trim(); if(validateToken(t)) { getSharedPreferences("license",MODE_PRIVATE).edit().putString("token",t).apply(); showApp() } else Toast.makeText(this@MainActivity,"کد مجوز معتبر نیست یا برای این گوشی صادر نشده است.",Toast.LENGTH_LONG).show() } }
        val footer=TextView(this).apply { text="صاحب امتیاز: آموزشگاه سهند
طراح و سازنده: علیرضا آیتی"; textSize=12f; gravity=Gravity.CENTER; setTextColor(Color.GRAY); setPadding(0,20,0,0) }
        listOf<View>(title,info,keyLabel,keyView,copy,tokenLabel,tokenInput,activate,footer).forEach { v -> root.addView(v, LinearLayout.LayoutParams(-1, if(v===keyView) 110 else -2).apply { bottomMargin=8 }) }
        setContentView(root)
    }

    private fun validateToken(token: String): Boolean {
        return try {
            val parts=token.split("."); if(parts.size!=2) return false
            val payloadBytes=Base64.decode(pad(parts[0]),Base64.URL_SAFE or Base64.NO_WRAP)
            val sigRaw=Base64.decode(pad(parts[1]),Base64.URL_SAFE or Base64.NO_WRAP)
            val obj=JSONObject(String(payloadBytes, Charsets.UTF_8))
            if(obj.optString("appId")!=appId || obj.optString("licenseType")!="perpetual" || obj.optString("devicePublicKey")!=devicePublicKeyB64) return false
            val pub=KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(adminPublicKey,Base64.DEFAULT)))
            val verifier=Signature.getInstance("SHA256withECDSA")
            verifier.initVerify(pub); verifier.update(payloadBytes); verifier.verify(rawEcdsaToDer(sigRaw))
        } catch(e:Exception) { false }
    }
    private fun pad(s:String)=s + "=".repeat((4-s.length%4)%4)
    private fun rawEcdsaToDer(raw:ByteArray):ByteArray {
        require(raw.size==64)
        fun integer(bytes:ByteArray):ByteArray {
            var b=bytes.dropWhile { it==0.toByte() }.toByteArray()
            if(b.isEmpty()) b=byteArrayOf(0)
            if((b[0].toInt() and 0x80)!=0) b=byteArrayOf(0)+b
            return byteArrayOf(0x02,b.size.toByte())+b
        }
        val r=integer(raw.copyOfRange(0,32)); val s=integer(raw.copyOfRange(32,64)); val body=r+s
        return byteArrayOf(0x30,body.size.toByte())+body
    }

    private fun showApp() {
        val web=WebView(this)
        web.settings.javaScriptEnabled=true
        web.settings.domStorageEnabled=true
        web.settings.allowFileAccess=true
        web.settings.allowContentAccess=false
        web.settings.setSupportZoom(false)
        web.webViewClient=object:WebViewClient() { override fun shouldOverrideUrlLoading(view:WebView?, url:String?):Boolean = true }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
}
