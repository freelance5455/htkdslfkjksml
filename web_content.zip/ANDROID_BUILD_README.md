# Arhan's Magical Class — Android AAB

This project is prepared for Capacitor Android packaging.

- App name: Arhan's Magical Class
- Application ID: `com.arhan.magicalclass`
- Web build: Vite
- Android packaging: Capacitor

## Build AAB locally

1. Install Node.js 22+, Java 21+, Android Studio/SDK and Android SDK build tools.
2. Run `npm install`.
3. Run `npm run android:build`.
4. The release bundle will be under `android/app/build/outputs/bundle/release/`.

## Build AAB without installing Android tools locally

Upload this project to a GitHub repository, then open **Actions → Build Android AAB → Run workflow**. The workflow builds the web app, creates/syncs the Android project, and uploads `app-release.aab` as a workflow artifact.

## Important

The app contains server-side Gemini/Veo endpoints in `server.ts`. A production Android build that needs those AI endpoints must have the backend deployed and configured with its required server-side credentials. Do not put a Gemini API key directly in the Android client.

The project does not currently include the previously requested custom launcher icon because that image file was not present in the source archive available here.
