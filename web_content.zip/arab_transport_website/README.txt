ARAB TRANSPORT WEBSITE

1. Extract the ZIP file.
2. Open index.html in a browser to preview the website.
3. Upload the complete folder contents to your hosting public_html folder.

Edit company details in index.html. The banner image is in assets/.
This is a responsive static website; no database or backend is required.
