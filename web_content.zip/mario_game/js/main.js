// Entry point
window.addEventListener('load', () => {
  const canvas = document.getElementById('gameCanvas');
  const game = new Game(canvas);

  // Prevent unwanted mobile behaviors
  document.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('dblclick', e => e.preventDefault());

  // Try to lock orientation to landscape when possible
  const tryLockOrientation = () => {
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock('landscape').catch(() => {});
    }
  };

  // Show loading
  const startBtn = document.getElementById('btn-start');
  startBtn.textContent = 'LOADING...';
  startBtn.disabled = true;

  Assets.loadAll(
    (loaded, total) => {
      startBtn.textContent = `LOADING ${loaded}/${total}`;
    },
    () => {
      startBtn.textContent = 'START';
      startBtn.disabled = false;
      game.loop();
    }
  );

  // Unlock audio + orientation on first interaction
  const unlock = () => {
    SFX.unlock();
    tryLockOrientation();
    document.removeEventListener('touchstart', unlock);
    document.removeEventListener('click', unlock);
  };
  document.addEventListener('touchstart', unlock, { once: true });
  document.addEventListener('click', unlock, { once: true });
});
