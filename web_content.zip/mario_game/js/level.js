class Level {
  constructor(id = 1) {
    this.id = id;
    this.platforms = [];
    this.enemies = [];
    this.coins = [];
    this.blocks = [];
    this.pipes = [];       // visual + collision pipes
    this.decor = [];       // decorative elements
    this.worldWidth = 3000;
    this.bgKey = 'bg_overworld';
    this.groundY = 520;
    this.flagX = 0;
    this.time = 0;         // for animations

    this.build(id);
  }

  build(id) {
    this.platforms = [];
    this.enemies = [];
    this.coins = [];
    this.blocks = [];
    this.pipes = [];
    this.decor = [];

    if (id === 1) {
      // === OVERWORLD ===
      this.bgKey = 'bg_overworld';
      this.worldWidth = 3400;
      this.groundY = 520;
      this.flagX = 3250;

      // Ground segments
      this.addGround(0, 950);
      this.addGround(1050, 550);
      this.addGround(1750, 450);
      this.addGround(2350, 1050);

      // Floating platforms
      this.addPlatform(380, 390, 180);
      this.addPlatform(680, 310, 140);
      this.addPlatform(1080, 370, 200);
      this.addPlatform(1480, 290, 160);
      this.addPlatform(1980, 350, 220);
      this.addPlatform(2580, 310, 180);

      // Question blocks
      this.blocks.push({ x: 440, y: 290, width: 40, height: 40, hit: false });
      this.blocks.push({ x: 1140, y: 270, width: 40, height: 40, hit: false });
      this.blocks.push({ x: 2040, y: 250, width: 40, height: 40, hit: false });
      this.blocks.push({ x: 2620, y: 210, width: 40, height: 40, hit: false });

      // Coins
      this.addCoinRow(400, 350, 6);
      this.addCoinRow(1100, 330, 5);
      this.addCoinRow(2000, 310, 7);
      this.addCoinRow(2600, 270, 4);

      // Enemies
      this.enemies.push(new Enemy(520, 470, 'goomba'));
      this.enemies.push(new Enemy(780, 470, 'goomba'));
      this.enemies.push(new Enemy(1280, 470, 'koopa'));
      this.enemies.push(new Enemy(1880, 470, 'goomba'));
      this.enemies.push(new Enemy(2150, 470, 'koopa'));
      this.enemies.push(new Enemy(2750, 470, 'goomba'));
      this.enemies.push(new Enemy(3000, 470, 'goomba'));

      // Pipes
      this.addPipe(1600, 420, 100);
      this.addPipe(2900, 400, 120);

    } else if (id === 2) {
      // === UNDERGROUND ===
      this.bgKey = 'bg_underground';
      this.worldWidth = 3000;
      this.groundY = 540;
      this.flagX = 2850;

      this.addGround(0, 750);
      this.addGround(900, 500);
      this.addGround(1550, 550);
      this.addGround(2300, 700);

      this.addPlatform(280, 410, 160);
      this.addPlatform(580, 330, 120);
      this.addPlatform(980, 390, 180);
      this.addPlatform(1380, 310, 140);
      this.addPlatform(1780, 370, 200);
      this.addPlatform(2400, 340, 160);

      this.blocks.push({ x: 330, y: 310, width: 40, height: 40, hit: false });
      this.blocks.push({ x: 1030, y: 290, width: 40, height: 40, hit: false });
      this.blocks.push({ x: 1830, y: 270, width: 40, height: 40, hit: false });

      this.addCoinRow(260, 370, 8);
      this.addCoinRow(1360, 270, 5);
      this.addCoinRow(2380, 300, 5);

      this.enemies.push(new Enemy(400, 490, 'goomba'));
      this.enemies.push(new Enemy(680, 490, 'goomba'));
      this.enemies.push(new Enemy(1150, 490, 'boo'));
      this.enemies.push(new Enemy(1600, 490, 'koopa'));
      this.enemies.push(new Enemy(2000, 490, 'goomba'));
      this.enemies.push(new Enemy(2500, 490, 'boo'));

      this.addPipe(2100, 440, 100);

    } else if (id === 3) {
      // === CASTLE ===
      this.bgKey = 'bg_castle';
      this.worldWidth = 2800;
      this.groundY = 540;
      this.flagX = 2650;

      this.addGround(0, 650);
      this.addGround(800, 400);
      this.addGround(1350, 500);
      this.addGround(2050, 750);

      this.addPlatform(230, 410, 140);
      this.addPlatform(480, 330, 120);
      this.addPlatform(880, 390, 160);
      this.addPlatform(1480, 350, 180);
      this.addPlatform(1880, 310, 140);
      this.addPlatform(2300, 380, 160);

      this.blocks.push({ x: 520, y: 230, width: 40, height: 40, hit: false });
      this.blocks.push({ x: 1530, y: 250, width: 40, height: 40, hit: false });
      this.blocks.push({ x: 1920, y: 210, width: 40, height: 40, hit: false });

      this.addCoinRow(860, 350, 6);
      this.addCoinRow(1460, 310, 5);
      this.addCoinRow(2280, 340, 5);

      this.enemies.push(new Enemy(350, 490, 'goomba'));
      this.enemies.push(new Enemy(580, 490, 'koopa'));
      this.enemies.push(new Enemy(1050, 490, 'goomba'));
      this.enemies.push(new Enemy(1650, 490, 'boo'));
      this.enemies.push(new Enemy(2100, 490, 'koopa'));
      this.enemies.push(new Enemy(2450, 490, 'goomba'));

      this.addPipe(1200, 440, 100);
    }
  }

  addGround(startX, width) {
    this.platforms.push({
      x: startX,
      y: this.groundY,
      width: width,
      height: 220,
      type: 'ground'
    });
  }

  addPlatform(x, y, width) {
    this.platforms.push({
      x: x,
      y: y,
      width: width,
      height: 22,
      type: 'platform'
    });
  }

  addPipe(x, y, height) {
    // Collision body
    this.platforms.push({
      x: x,
      y: y,
      width: 64,
      height: height,
      type: 'pipe'
    });
    // Visual
    this.pipes.push({ x: x, y: y, width: 64, height: height });
  }

  addCoinRow(x, y, count) {
    for (let i = 0; i < count; i++) {
      this.coins.push({
        x: x + i * 34,
        y: y,
        width: 28,
        height: 28,
        collected: false
      });
    }
  }

  update(player) {
    this.time++;
    for (const e of this.enemies) {
      e.update(this.platforms, player);
    }

    const hitbox = player.getHitbox();

    // Coins
    for (const c of this.coins) {
      if (!c.collected && this.rectCollide(hitbox, c)) {
        c.collected = true;
        return 'coin';
      }
    }

    // Question blocks (hit from below)
    for (const b of this.blocks) {
      if (!b.hit && player.vy < 0 && this.rectCollide(hitbox, b)) {
        // only if player's head is roughly under the block
        if (player.y > b.y) {
          b.hit = true;
          player.vy = 3;
          this.coins.push({
            x: b.x + 6,
            y: b.y - 36,
            width: 28,
            height: 28,
            collected: false
          });
          return 'block';
        }
      }
    }

    // Enemies
    for (const e of this.enemies) {
      if (!e.alive || e.squished) continue;
      if (this.rectCollide(hitbox, e)) {
        if (player.vy > 0 && (player.y + player.height - e.y) < 28) {
          e.stomp();
          player.vy = -9;
          return 'stomp';
        } else {
          player.die();
          return 'hurt';
        }
      }
    }

    return null;
  }

  rectCollide(a, b) {
    return a.x < b.x + b.width &&
           a.x + a.width > b.x &&
           a.y < b.y + b.height &&
           a.y + a.height > b.y;
  }

  draw(ctx, cameraX, canvasWidth, canvasHeight) {
    // ===== Background (parallax) =====
    const bg = Assets.get(this.bgKey);
    if (bg) {
      const scale = canvasHeight / bg.height;
      const scaledW = bg.width * scale;
      let offset = (cameraX * 0.22) % scaledW;
      if (offset < 0) offset += scaledW;
      ctx.drawImage(bg, -offset, 0, scaledW, canvasHeight);
      if (-offset + scaledW < canvasWidth) {
        ctx.drawImage(bg, -offset + scaledW, 0, scaledW, canvasHeight);
      }
      if (-offset + scaledW * 2 < canvasWidth) {
        ctx.drawImage(bg, -offset + scaledW * 2, 0, scaledW, canvasHeight);
      }
    } else {
      ctx.fillStyle = '#5c94fc';
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    }

    // ===== Platforms & Ground =====
    const brickImg = Assets.get('brick_wall');

    for (const p of this.platforms) {
      const drawX = Math.round(p.x - cameraX);
      if (drawX + p.width < -60 || drawX > canvasWidth + 60) continue;

      if (p.type === 'ground') {
        // Dirt body
        ctx.fillStyle = '#8b4513';
        ctx.fillRect(drawX, p.y + 18, p.width, p.height - 18);

        // Top brick / grass strip
        ctx.fillStyle = '#c84c0c';
        ctx.fillRect(drawX, p.y, p.width, 18);

        // Green grass line
        ctx.fillStyle = '#00a800';
        ctx.fillRect(drawX, p.y, p.width, 5);

        // Brick texture on top
        if (brickImg) {
          ctx.save();
          ctx.beginPath();
          ctx.rect(drawX, p.y, p.width, 18);
          ctx.clip();
          for (let tx = 0; tx < p.width + 64; tx += 64) {
            ctx.drawImage(brickImg, drawX + tx, p.y, 64, 18);
          }
          ctx.restore();
        }

        // Small stones detail
        ctx.fillStyle = 'rgba(0,0,0,0.15)';
        for (let i = 0; i < p.width; i += 40) {
          ctx.fillRect(drawX + i + 8, p.y + 28, 6, 4);
          ctx.fillRect(drawX + i + 22, p.y + 36, 8, 3);
        }
      } else if (p.type === 'platform') {
        // Floating platform with better look
        ctx.fillStyle = '#a03c08';
        ctx.fillRect(drawX, p.y, p.width, p.height);
        // Top green
        ctx.fillStyle = '#00b000';
        ctx.fillRect(drawX, p.y, p.width, 6);
        // Highlight
        ctx.fillStyle = '#e07030';
        ctx.fillRect(drawX + 2, p.y + 6, p.width - 4, 2);
        // Left edge
        ctx.fillStyle = '#703010';
        ctx.fillRect(drawX, p.y + 6, 3, p.height - 6);
      }
    }

    // ===== Pipes =====
    const pipeImg = Assets.get('pipe');
    for (const pipe of this.pipes) {
      const drawX = Math.round(pipe.x - cameraX);
      if (drawX + pipe.width < -30 || drawX > canvasWidth + 30) continue;

      if (pipeImg) {
        ctx.drawImage(pipeImg, drawX - 6, pipe.y - 10, pipe.width + 12, pipe.height + 18);
      } else {
        ctx.fillStyle = '#00a800';
        ctx.fillRect(drawX, pipe.y, pipe.width, pipe.height);
        ctx.fillStyle = '#00d000';
        ctx.fillRect(drawX + 4, pipe.y, 10, pipe.height);
        ctx.fillStyle = '#00c000';
        ctx.fillRect(drawX - 8, pipe.y - 14, pipe.width + 16, 18);
      }
    }

    // ===== Question blocks =====
    const qImg = Assets.get('question_block');
    for (const b of this.blocks) {
      const drawX = Math.round(b.x - cameraX);
      if (drawX + 40 < 0 || drawX > canvasWidth) continue;

      if (qImg && !b.hit) {
        // slight bob for unhit blocks
        const bob = Math.sin(this.time * 0.08 + b.x * 0.01) * 1.5;
        ctx.drawImage(qImg, drawX, b.y + bob, 40, 40);
      } else {
        ctx.fillStyle = '#6b4a2b';
        ctx.fillRect(drawX, b.y, 40, 40);
        ctx.strokeStyle = '#3a2a1a';
        ctx.lineWidth = 2;
        ctx.strokeRect(drawX, b.y, 40, 40);
      }
    }

    // ===== Coins (animated bob + slight scale) =====
    const coinImg = Assets.get('coin');
    for (const c of this.coins) {
      if (c.collected) continue;
      const drawX = Math.round(c.x - cameraX);
      if (drawX + 30 < 0 || drawX > canvasWidth) continue;

      const bob = Math.sin(this.time * 0.12 + c.x * 0.05) * 4;
      const scale = 1 + Math.sin(this.time * 0.15 + c.x * 0.03) * 0.06;
      const size = 28 * scale;
      const ox = (28 - size) / 2;

      if (coinImg) {
        ctx.drawImage(coinImg, drawX + ox, c.y + bob, size, size);
      } else {
        ctx.fillStyle = '#ffcc00';
        ctx.beginPath();
        ctx.arc(drawX + 14, c.y + 14 + bob, 12 * scale, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // ===== Enemies =====
    for (const e of this.enemies) {
      e.draw(ctx, cameraX);
    }

    // ===== Finish Flag =====
    const flagX = Math.round(this.flagX - cameraX);
    if (flagX > -60 && flagX < canvasWidth + 60) {
      // Pole
      ctx.fillStyle = '#e0e0e0';
      ctx.fillRect(flagX, this.groundY - 230, 6, 230);
      // Shadow
      ctx.fillStyle = '#aaaaaa';
      ctx.fillRect(flagX + 6, this.groundY - 230, 2, 230);
      // Flag (waving a bit)
      const wave = Math.sin(this.time * 0.1) * 4;
      ctx.fillStyle = '#e52521';
      ctx.beginPath();
      ctx.moveTo(flagX + 8, this.groundY - 230);
      ctx.lineTo(flagX + 58 + wave, this.groundY - 200);
      ctx.lineTo(flagX + 8, this.groundY - 170);
      ctx.closePath();
      ctx.fill();
      // Ball
      ctx.fillStyle = '#ffcc00';
      ctx.beginPath();
      ctx.arc(flagX + 4, this.groundY - 230, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#cc9900';
      ctx.beginPath();
      ctx.arc(flagX + 4, this.groundY - 230, 5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  isComplete(player) {
    return player.x > this.flagX - 30;
  }
}
