class Enemy {
  constructor(x, y, type = 'goomba') {
    this.x = x;
    this.y = y;
    this.type = type;
    this.width = 48;
    this.height = 48;
    this.vx = -1.5;
    this.vy = 0;
    this.gravity = 0.5;
    this.onGround = false;
    this.alive = true;
    this.squished = false;
    this.squishTimer = 0;

    if (type === 'koopa') {
      this.width = 48;
      this.height = 56;
      this.vx = -1.2;
    } else if (type === 'boo') {
      this.width = 48;
      this.height = 48;
      this.vx = 0;
      this.gravity = 0;
    } else if (type === 'piranha') {
      this.width = 48;
      this.height = 72;
      this.vx = 0;
      this.gravity = 0;
      this.baseY = y;
      this.timer = 0;
    }
  }

  update(platforms, player) {
    if (!this.alive) return;

    if (this.squished) {
      this.squishTimer++;
      if (this.squishTimer > 30) this.alive = false;
      return;
    }

    if (this.type === 'boo') {
      // Boo follows slowly when player is looking away
      const dx = player.x - this.x;
      if ((dx > 0 && !player.facingRight) || (dx < 0 && player.facingRight)) {
        this.vx = Math.sign(dx) * 1.2;
      } else {
        this.vx = 0;
      }
      this.x += this.vx;
      return;
    }

    if (this.type === 'piranha') {
      this.timer++;
      // Simple up-down motion
      this.y = this.baseY + Math.sin(this.timer * 0.05) * 40;
      return;
    }

    // Gravity
    this.vy += this.gravity;
    if (this.vy > 12) this.vy = 12;

    // Move X
    this.x += this.vx;

    // Platform collision X
    for (const p of platforms) {
      if (this.collides(p)) {
        if (this.vx > 0) this.x = p.x - this.width;
        if (this.vx < 0) this.x = p.x + p.width;
        this.vx *= -1; // turn around
      }
    }

    // Move Y
    this.y += this.vy;
    this.onGround = false;

    for (const p of platforms) {
      if (this.collides(p)) {
        if (this.vy > 0) {
          this.y = p.y - this.height;
          this.vy = 0;
          this.onGround = true;
        }
      }
    }

    // Turn at edges (simple check)
    if (this.onGround) {
      const lookAheadX = this.x + (this.vx > 0 ? this.width + 5 : -5);
      let hasGround = false;
      for (const p of platforms) {
        if (lookAheadX > p.x && lookAheadX < p.x + p.width &&
            Math.abs((this.y + this.height) - p.y) < 10) {
          hasGround = true;
          break;
        }
      }
      if (!hasGround) this.vx *= -1;
    }
  }

  collides(rect) {
    return this.x < rect.x + rect.width &&
           this.x + this.width > rect.x &&
           this.y < rect.y + rect.height &&
           this.y + this.height > rect.y;
  }

  stomp() {
    if (this.type === 'goomba' || this.type === 'koopa') {
      this.squished = true;
      this.vx = 0;
      this.height = 20;
    }
  }

  draw(ctx, cameraX) {
    if (!this.alive) return;

    let imgName = this.type;
    if (this.squished && this.type === 'goomba') {
      // just draw smaller
    }
    if (this.type === 'koopa' && this.squished) {
      imgName = 'shell';
    }

    const img = Assets.get(imgName);
    if (!img) return;

    const drawX = this.x - cameraX;
    ctx.save();
    if (this.vx > 0 && this.type !== 'piranha' && this.type !== 'boo') {
      ctx.translate(drawX + this.width, this.y);
      ctx.scale(-1, 1);
      ctx.drawImage(img, 0, 0, this.width, this.height);
    } else {
      ctx.drawImage(img, drawX, this.y, this.width, this.height);
    }
    ctx.restore();
  }
}
