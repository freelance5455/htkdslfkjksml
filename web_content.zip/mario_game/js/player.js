class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 42;
    this.height = 56;
    this.vx = 0;
    this.vy = 0;
    this.speed = 4.2;
    this.jumpPower = -12.5;
    this.gravity = 0.52;
    this.onGround = false;
    this.facingRight = true;
    this.state = 'stand';
    this.animTimer = 0;
    this.lives = 3;
    this.invincible = 0;
    this.dead = false;
  }

  update(keys, platforms, worldWidth) {
    if (this.dead) return;

    // Horizontal
    this.vx = 0;
    if (keys.left) {
      this.vx = -this.speed;
      this.facingRight = false;
    }
    if (keys.right) {
      this.vx = this.speed;
      this.facingRight = true;
    }

    // Jump (only when on ground)
    if (keys.jump && this.onGround) {
      this.vy = this.jumpPower;
      this.onGround = false;
    }

    // Gravity
    this.vy += this.gravity;
    if (this.vy > 14) this.vy = 14;

    // --- X movement + collision ---
    this.x += this.vx;
    for (const p of platforms) {
      if (this.collides(p)) {
        if (this.vx > 0) this.x = p.x - this.width;
        else if (this.vx < 0) this.x = p.x + p.width;
      }
    }

    // --- Y movement + collision ---
    this.y += this.vy;
    this.onGround = false;

    for (const p of platforms) {
      if (this.collides(p)) {
        if (this.vy > 0) {          // falling → land on top
          this.y = p.y - this.height;
          this.vy = 0;
          this.onGround = true;
        } else if (this.vy < 0) {   // jumping up → hit ceiling
          this.y = p.y + p.height;
          this.vy = 0;
        }
      }
    }

    // World bounds
    if (this.x < 0) this.x = 0;
    if (this.x > worldWidth - this.width) this.x = worldWidth - this.width;

    // Fell into pit
    if (this.y > 780) {
      this.die();
    }

    // Animation
    if (!this.onGround) {
      this.state = 'jump';
    } else if (Math.abs(this.vx) > 0.3) {
      this.state = 'walk';
      this.animTimer = (this.animTimer + 1) % 20;
    } else {
      this.state = 'stand';
    }

    if (this.invincible > 0) this.invincible--;
  }

  collides(rect) {
    return this.x < rect.x + rect.width &&
           this.x + this.width > rect.x &&
           this.y < rect.y + rect.height &&
           this.y + this.height > rect.y;
  }

  getHitbox() {
    return {
      x: this.x + 6,
      y: this.y + 6,
      width: this.width - 12,
      height: this.height - 6
    };
  }

  die() {
    if (this.invincible > 0 || this.dead) return;
    this.lives--;
    if (this.lives <= 0) {
      this.dead = true;
    } else {
      this.invincible = 90;
      this.vy = -9;
      this.x = 80;
      this.y = 280;
    }
  }

  draw(ctx, cameraX) {
    if (this.dead) return;
    // Blink when invincible
    if (this.invincible > 0 && Math.floor(this.invincible / 5) % 2 === 0) return;

    let img;
    if (this.state === 'jump') {
      img = Assets.get('mario_jump');
    } else if (this.state === 'walk') {
      // Simple 2-frame walk using walk + stand
      img = (this.animTimer < 10) ? Assets.get('mario_walk') : Assets.get('mario_stand');
    } else {
      img = Assets.get('mario_stand');
    }

    if (!img) return;

    const drawX = Math.round(this.x - cameraX);
    const drawY = Math.round(this.y);

    ctx.save();
    if (!this.facingRight) {
      ctx.translate(drawX + this.width, drawY);
      ctx.scale(-1, 1);
      ctx.drawImage(img, 0, 0, this.width, this.height);
    } else {
      ctx.drawImage(img, drawX, drawY, this.width, this.height);
    }
    ctx.restore();
  }
}
