// Asset loader
const Assets = {
  images: {},
  loaded: 0,
  total: 0,

  // List of all assets to load
  list: {
    // Player
    'mario_stand': 'assets/player/mario_stand.png',
    'mario_walk':  'assets/player/mario_walk.png',
    'mario_jump':  'assets/player/mario_jump.png',
    'mario_side':  'assets/player/mario_side.png',

    // Enemies
    'goomba':   'assets/enemies/goomba.png',
    'koopa':    'assets/enemies/koopa.png',
    'shell':    'assets/enemies/shell.png',
    'piranha':  'assets/enemies/piranha.png',
    'boo':      'assets/enemies/boo.png',

    // Items
    'coin':            'assets/items/coin.png',
    'question_block':  'assets/items/question_block.png',

    // Tiles
    'pipe':       'assets/tiles/pipe.png',
    'lava':       'assets/tiles/lava.png',
    'brick_wall': 'assets/tiles/brick_wall.jpg',
    'water':      'assets/tiles/water.jpg',

    // Backgrounds
    'bg_overworld':    'assets/backgrounds/overworld.jpg',
    'bg_underground':  'assets/backgrounds/underground.jpg',
    'bg_castle':       'assets/backgrounds/castle.jpg',
    'bg_underwater':   'assets/backgrounds/underwater.jpg',
    'bg_sky':          'assets/backgrounds/sky_clouds.jpg',
    'bg_hills':        'assets/backgrounds/hills.jpg',
  },

  loadAll(onProgress, onComplete) {
    const keys = Object.keys(this.list);
    this.total = keys.length;
    this.loaded = 0;

    if (this.total === 0) {
      onComplete();
      return;
    }

    keys.forEach(key => {
      const img = new Image();
      img.onload = () => {
        this.loaded++;
        if (onProgress) onProgress(this.loaded, this.total);
        if (this.loaded === this.total) {
          onComplete();
        }
      };
      img.onerror = () => {
        console.warn('Failed to load:', this.list[key]);
        this.loaded++;
        if (this.loaded === this.total) {
          onComplete();
        }
      };
      img.src = this.list[key];
      this.images[key] = img;
    });
  },

  get(name) {
    return this.images[name] || null;
  }
};
