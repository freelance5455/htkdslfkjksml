class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.width = 1280;
    this.height = 720;
    this.canvas.width = this.width;
    this.canvas.height = this.height;

    this.state = 'start'; // start, playing, paused, gameover, victory
    this.keys = { left: false, right: false, jump: false };
    this.player = null;
    this.level = null;
    this.levelId = 1;
    this.cameraX = 0;
    this.score = 0;
    this.coins = 0;
    this.wasJumping = false; // to play jump sound only once per press

    this.setupControls();
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    const aspect = this.width / this.height;
    let w = window.innerWidth;
    let h = window.innerHeight;

    if (w / h > aspect) {
      w = h * aspect;
    } else {
      h = w / aspect;
    }

    this.canvas.style.width = w + 'px';
    this.canvas.style.height = h + 'px';
  }

  setupControls() {
    window.addEventListener('keydown', e => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') this.keys.left = true;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') this.keys.right = true;
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW' || e.code === 'KeyZ') {
        this.keys.jump = true;
        e.preventDefault();
      }
      if (e.code === 'Escape' || e.code === 'KeyP') this.togglePause();
    });

    window.addEventListener('keyup', e => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') this.keys.left = false;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') this.keys.right = false;
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW' || e.code === 'KeyZ') {
        this.keys.jump = false;
      }
    });

    const bindBtn = (id, key) => {
      const btn = document.getElementById(id);
      if (!btn) return;
      const start = e => {
        e.preventDefault();
        this.keys[key] = true;
        btn.classList.add('active');
        SFX.unlock();
      };
      const end = e => {
        e.preventDefault();
        this.keys[key] = false;
        btn.classList.remove('active');
      };
      btn.addEventListener('touchstart', start, { passive: false });
      btn.addEventListener('touchend', end, { passive: false });
      btn.addEventListener('touchcancel', end, { passive: false });
      btn.addEventListener('mousedown', start);
      btn.addEventListener('mouseup', end);
      btn.addEventListener('mouseleave', end);
    };

    bindBtn('btn-left', 'left');
    bindBtn('btn-right', 'right');
    bindBtn('btn-jump', 'jump');

    document.getElementById('btn-pause')?.addEventListener('click', () => this.togglePause());
    document.getElementById('btn-start')?.addEventListener('click', () => {
      SFX.unlock();
      this.start();
    });
    document.getElementById('btn-resume')?.addEventListener('click', () => this.togglePause());
    document.getElementById('btn-restart')?.addEventListener('click', () => this.start());
    document.getElementById('btn-play-again')?.addEventListener('click', () => this.start());
  }

  start() {
    this.levelId = 1;
    this.score = 0;
    this.coins = 0;
    this.level = new Level(this.levelId);
    this.player = new Player(100, 300);
    this.player.lives = 3;
    this.cameraX = 0;
    this.state = 'playing';
    this.wasJumping = false;

    document.getElementById('start-screen').classList.add('hidden');
    document.getElementById('pause-screen').classList.add('hidden');
    document.getElementById('game-over-screen').classList.add('hidden');
    document.getElementById('victory-screen').classList.add('hidden');
    this.updateHUD();
  }

  togglePause() {
    if (this.state === 'playing') {
      this.state = 'paused';
      document.getElementById('pause-screen').classList.remove('hidden');
      SFX.play('pause');
    } else if (this.state === 'paused') {
      this.state = 'playing';
      document.getElementById('pause-screen').classList.add('hidden');
    }
  }

  updateHUD() {
    document.getElementById('score').textContent = `COINS: ${this.coins}`;
    document.getElementById('lives').textContent = `LIVES: ${this.player ? this.player.lives : 3}`;
  }

  update() {
    if (this.state !== 'playing') return;

    // Jump sound (once per press when leaving ground)
    if (this.keys.jump && this.player.onGround && !this.wasJumping) {
      SFX.play('jump');
      this.wasJumping = true;
    }
    if (!this.keys.jump) this.wasJumping = false;

    this.player.update(this.keys, this.level.platforms, this.level.worldWidth);

    const event = this.level.update(this.player);
    if (event === 'coin') {
      this.coins++;
      this.score += 100;
      this.updateHUD();
      SFX.play('coin');
    } else if (event === 'stomp') {
      this.score += 200;
      SFX.play('stomp');
    } else if (event === 'hurt') {
      this.updateHUD();
      SFX.play('hurt');
    } else if (event === 'block') {
      SFX.play('block');
    }

    // Camera follow (smoother + look-ahead)
    const lookAhead = this.player.facingRight ? 80 : -40;
    const targetCam = this.player.x - this.width * 0.38 + lookAhead;
    this.cameraX += (targetCam - this.cameraX) * 0.08;
    if (this.cameraX < 0) this.cameraX = 0;
    const maxCam = Math.max(0, this.level.worldWidth - this.width);
    if (this.cameraX > maxCam) this.cameraX = maxCam;

    // Level complete
    if (this.level.isComplete(this.player)) {
      SFX.play('level');
      this.levelId++;
      if (this.levelId > 3) {
        // Victory!
        this.state = 'victory';
        document.getElementById('final-score').textContent = `COINS: ${this.coins}`;
        document.getElementById('victory-screen').classList.remove('hidden');
        SFX.play('win');
        return;
      }
      this.level = new Level(this.levelId);
      this.player.x = 100;
      this.player.y = 300;
      this.player.vy = 0;
      this.cameraX = 0;
    }

    // Game over
    if (this.player.dead) {
      this.state = 'gameover';
      document.getElementById('game-over-screen').classList.remove('hidden');
      SFX.play('hurt');
    }
  }

  draw() {
    this.ctx.clearRect(0, 0, this.width, this.height);

    if (this.state === 'start' || this.state === 'victory') {
      this.ctx.fillStyle = '#5c94fc';
      this.ctx.fillRect(0, 0, this.width, this.height);
      return;
    }

    this.level.draw(this.ctx, this.cameraX, this.width, this.height);
    this.player.draw(this.ctx, this.cameraX);

    // Level indicator
    this.ctx.fillStyle = '#fff';
    this.ctx.font = '16px monospace';
    this.ctx.textAlign = 'right';
    this.ctx.fillText(`WORLD 1-${this.levelId}`, this.width - 20, 30);
    this.ctx.textAlign = 'left';
  }

  loop() {
    this.update();
    this.draw();
    requestAnimationFrame(() => this.loop());
  }
}
