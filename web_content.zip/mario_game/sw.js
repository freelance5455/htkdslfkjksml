// Service Worker for offline support
const CACHE_NAME = 'mario-v1';
const ASSETS = [
  './',
  './index.html',
  './css/style.css',
  './js/sounds.js',
  './js/assets.js',
  './js/player.js',
  './js/enemy.js',
  './js/level.js',
  './js/game.js',
  './js/main.js',
  './manifest.json',
  './assets/player/mario_stand.png',
  './assets/player/mario_walk.png',
  './assets/player/mario_jump.png',
  './assets/player/mario_side.png',
  './assets/enemies/goomba.png',
  './assets/enemies/koopa.png',
  './assets/enemies/shell.png',
  './assets/enemies/piranha.png',
  './assets/enemies/boo.png',
  './assets/items/coin.png',
  './assets/items/question_block.png',
  './assets/tiles/pipe.png',
  './assets/tiles/lava.png',
  './assets/tiles/brick_wall.jpg',
  './assets/tiles/water.jpg',
  './assets/backgrounds/overworld.jpg',
  './assets/backgrounds/underground.jpg',
  './assets/backgrounds/castle.jpg',
  './assets/backgrounds/underwater.jpg',
  './assets/backgrounds/sky_clouds.jpg',
  './assets/backgrounds/hills.jpg',
  './assets/ui/a_btn.png',
  './assets/ui/pause_btn.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(cached => {
      return cached || fetch(event.request).then(response => {
        // Optionally cache new requests
        return response;
      }).catch(() => cached);
    })
  );
});
