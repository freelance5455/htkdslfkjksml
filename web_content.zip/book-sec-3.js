/* JOSTECH — MANUEL 04 : CYBERSÉCURITÉ NIVEAU 3 */
registerLessonDetail(4, 3, "sec-3-1-1", {
  title: "Leçon 1 : Sécurité Applicative OWASP, Audit & Investigation",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Diagnostiquer et corriger les failles majeures OWASP Top 10 (SQLi, Broken Access Control, XSS).",
    "Comprendre les principes de l'investigation numérique (Forensics & Chaîne de preuves).",
    "Respecter strictement le cadre éthique et légal des tests d'intrusion."
  ],
  prerequisites: ["Niveaux 1 et 2 Cybersécurité + bases Web et SQL."],
  sections: [
    {
      type: "theory",
      title: "1. OWASP Top 10 : les vulnérabilités critiques des applications",
      text: "L'OWASP (Open Web Application Security Project) publie le classement mondial des failles Web les plus critiques :\n• A01 — Broken Access Control : un utilisateur accède aux données d'un autre ou à l'espace Admin simplement en changeant un ID dans l'URL (faille IDOR).\n• A03 — Injections (SQLi, Command Injection) : des données utilisateur sont interprétées comme du code exécutable par la base de données ou le système.\n• A07 — Identification & Authentication Failures : mots de passe faibles, absence de limite anti-Brute-Force ou jetons JWT non vérifiés."
    },
    {
      type: "code",
      lang: "Audit : Injection SQL (Vulnérable vs Requête Préparée)",
      code: [
        "// CODE VULNÉRABLE (Concaténation directe de la saisie) :",
        "sql = \"SELECT * FROM comptes WHERE email = '\" + saisie + \"' AND pass = '\" + mdp + \"'\";",
        "// Si un pirate saisit :  admin@jostech.edu' -- ",
        "// La requête devient : SELECT * FROM comptes WHERE email = 'admin@jostech.edu' -- ...",
        "// '--' met la suite en commentaire SQL : le pirate entre SANS mot de passe !",
        "",
        "// CODE SÉCURISÉ (Requête Préparée / Paramétrée) :",
        "stmt = db.prepare(\"SELECT * FROM comptes WHERE email = ? AND pass = ?\");",
        "stmt.execute([saisie, mdp]); // Le SGBD traite l'entrée comme texte pur, jamais comme ordre SQL !"
      ].join("\n")
    },
    {
      type: "definition",
      term: "Investigation Numérique (Forensics) et Chaîne de Garde",
      text: "Après un incident de sécurité, l'analyste Forensics collecte les journaux (logs), captures réseau et images disque sans jamais altérer l'original : on travaille toujours sur une copie bit-à-bit dont on calcule l'empreinte SHA-256 (Chaîne de garde / Chain of Custody) afin que la preuve reste recevable devant un tribunal."
    },
    {
      type: "warning",
      title: "Éthique, Loi et Tests en Environnement Autorisé",
      text: "Tester des failles sur un site, une université ou un réseau sans autorisation écrite explicite (Lettre de mission / Programme Bug Bounty) est strictement illégal et passible de poursuites pénales. La pratique se fait uniquement sur vos propres environnements isolés (machines virtuelles locales ou plateformes légales d'entraînement)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Faille IDOR (Broken Access Control)",
      question: "Sur un portail étudiant, l'URL https://univ.edu/notes?etudiant_id=104 affiche le bulletin de l'étudiant 104. En changeant 104 en 105 dans Chrome, vous voyez les notes d'un camarade ! Quelle faille est-ce et comment la corriger côté serveur ?",
      solution: "C'est une faille IDOR (Broken Access Control, OWASP A01). Correction : le serveur ne doit JAMAIS faire confiance à l'ID envoyé dans l'URL seul ; il doit vérifier que le user_id du jeton JWT authentifié correspond bien à l'étudiant demandé (ou possède le rôle admin)."
    },
    {
      title: "Exercice 2 — Préserver une preuve numérique",
      question: "Un serveur compromis vient d'être découvert. Pourquoi ne faut-il pas simplement redémarrer la machine ou ouvrir ses fichiers directement sur le disque original ?",
      solution: "Redémarrer efface les preuves volatiles en mémoire RAM (processus pirates, clés en mémoire), et ouvrir des fichiers sur l'original modifie les dates d'accès (métadonnées), invalidant la chaîne de preuve."
    }
  ],
  summary: "Sécuriser une application exige requêtes préparées contre SQLi, contrôle d'accès strict côté serveur (anti-IDOR), protection des sessions et pratique éthique sous autorisation.",
  references: ["OWASP Top 10 (owasp.org).", "Carrier, B. — File System Forensic Analysis."]
});