/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : IG-1-1-1 */
registerLessonDetail(1, 1, "ig-1-1-1", {
  title: "Leçon 1 : La science informatique et le Modèle de Von Neumann",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Distinguer rigoureusement la science informatique (données, algorithmes, systèmes) de la simple bureautique.",
    "Retracer la rupture scientifique entre les calculateurs câblés (ENIAC) et la machine universelle à programme enregistré.",
    "Maîtriser l'architecture interne de Von Neumann : UAL, Unité de Contrôle, RAM, E/S et les 3 bus.",
    "Tracer à la main l'évolution des registres (PC, IR, ACC) durant le cycle Fetch-Decode-Execute.",
    "Comparer l'architecture de Von Neumann pure et l'architecture Harvard modifiée utilisée dans les processeurs actuels."
  ],
  prerequisites: [
    "Aucun prérequis technique. Notions de raisonnement logique et de puissances de 2 (2^n) utiles pour l'exercice 1."
  ],
  sections: [
    {
      type: "definition",
      term: "Informatique, Donnée et Information",
      text: "Le mot « informatique » est un néologisme créé en 1962 par l'ingénieur Philippe Dreyfus (contraction d'« information » et d'« automatique ») et officialisé par l'Académie française en 1966 comme « la science du traitement rationnel, notamment par machines automatiques, de l'information considérée comme le support des connaissances humaines et des communications ».\n\nSur le plan scientifique, il faut distinguer trois notions souvent confondues :\n• La donnée (data) : une valeur brute sans contexte (ex. le nombre 38,5).\n• L'information : une donnée interprétée dans un contexte précis (ex. « température corporelle du patient = 38,5 °C, indiquant une fièvre »).\n• L'informatique (Computer Science) : la science qui conçoit les modèles mathématiques (algorithmes), les structures de données et les architectures matérielles et logicielles capables de transformer automatiquement des données en informations utiles."
    },
    {
      type: "theory",
      title: "1. Genèse historique : de la machine spécialisée à l'ordinateur universel",
      text: "Pendant des siècles, l'humanité a construit des machines à calculer mécaniques dédiées à une seule tâche. En 1642, Blaise Pascal invente la Pascaline (additions et soustractions par roues dentées). En 1837, le mathématicien anglais Charles Babbage conçoit les plans de la « Machine analytique », la première à séparer théoriquement une mémoire (« magasin ») et une unité de calcul (« moulin »), tandis qu'Ada Lovelace publie en 1843 le premier véritable algorithme destiné à une machine.\n\nLe véritable basculement théorique survient en 1936 : le mathématicien Alan Turing publie un article fondateur démontrant le concept de « Machine de Turing Universelle ». Son idée est géniale : au lieu de fabriquer une machine différente pour chaque calcul, on peut construire UNE seule machine capable d'exécuter n'importe quel algorithme, à condition d'inscrire les instructions de cet algorithme sous forme symbolique dans sa mémoire !\n\nPourtant, en 1945, le premier grand ordinateur électronique, l'ENIAC (30 tonnes, 17 468 tubes à vide), fonctionnait encore à l'ancienne : pour passer d'un calcul de trajectoire à un autre, des opératrices devaient débrancher et rebrancher des centaines de câbles pendant plusieurs jours. Le programme était prisonnier du câblage matériel.",
      bullets: [
        "Avant 1945 (Architecture figée) : changer de tâche exigeait de modifier physiquement les circuits électriques.",
        "Juin 1945 (John von Neumann — First Draft of a Report on the EDVAC) : naissance de l'architecture à programme enregistré (Stored-Program Computer). Désormais, les instructions sont codées en binaire exactement comme des nombres et rangées dans la même mémoire que les données."
      ]
    },
    {
      type: "theory",
      title: "2. Les quatre organes fondamentaux du modèle de Von Neumann",
      text: "Qu'il s'agisse d'un supercalculateur de recherche, d'un serveur Web ou de votre téléphone Android, tout ordinateur moderne repose sur l'interaction de quatre sous-systèmes principaux."
    },
    {
      type: "table",
      title: "Anatomie détaillée des organes et registres internes",
      headers: ["Organe", "Fonction détaillée", "Composants internes clés"],
      rows: [
        ["Unité Arithmétique et Logique (UAL / ALU)", "Exécute les calculs arithmétiques (+, -, ×, ÷), les opérations bit-à-bit et les comparaisons logiques (=, <, >, ET, OU).", "Additionneurs binaires, décaleurs, registres d'état (drapeaux Zéro, Retenue, Négatif)."],
        ["Unité de Contrôle (UC / CU)", "Chef d'orchestre du processeur. Lit les instructions en RAM, les décode et génère les signaux de commande cadencés par l'horloge.", "Compteur Ordinal (PC : adresse suivante), Registre d'Instruction (IR : ordre en cours), Décodeur."],
        ["Mémoire Centrale (RAM)", "Vaste tableau linéaire de cases numérotées (octets). Chaque case possède une adresse unique et contient soit une donnée, soit une instruction.", "Registres d'interface MAR (adresse lue) et MDR (donnée lue/écrite), cellules DRAM volatiles."],
        ["Unités d'Entrée / Sortie (E/S)", "Assurent le dialogue avec l'extérieur (humain, réseau) et les mémoires de masse permanentes.", "Contrôleurs USB, écran tactile, carte Wi-Fi/4G, disque SSD ou mémoire Flash UFS."]
      ]
    },
    {
      type: "theory",
      title: "3. Les trois Bus de communication : les autoroutes de l'ordinateur",
      text: "Pour que le processeur (UC + UAL) échange avec la mémoire RAM et les périphériques d'E/S, les organes sont reliés par des faisceaux de pistes électriques parallèles appelés « bus ». On distingue strictement trois bus complémentaires :",
      bullets: [
        "Le Bus de Données (bidirectionnel) : transporte la valeur effective des données ou les instructions entre la RAM et le CPU. Sa largeur (32 bits ou 64 bits) indique combien de bits voyagent simultanément en un seul trajet.",
        "Le Bus d'Adresses (unidirectionnel, du CPU vers la RAM) : transporte le numéro exact de la case mémoire à lire ou à écrire. C'est sa largeur n qui fixe la mémoire RAM maximale adressable : avec n fils d'adresse, l'ordinateur peut numéroter 2^n cases différentes !",
        "Le Bus de Contrôle (bidirectionnel) : transporte les ordres de synchronisation — par exemple le signal READ (je veux lire), WRITE (je veux écrire), le tic d'horloge (Clock) et les interruptions matérielles (IRQ) envoyées par un périphérique."
      ]
    },
    {
      type: "code",
      lang: "Trace complète : Exécution pas à pas d'un programme en RAM",
      code: [
        "État initial de la Mémoire RAM (Adresses et Contenu) :",
        "  [100] LOAD 200    --> Charger le contenu de la case 200 dans l'Accumulateur (ACC)",
        "  [101] ADD  201    --> Additionner le contenu de la case 201 à l'ACC",
        "  [102] STORE 202   --> Enregistrer l'ACC dans la case 202",
        "  [103] HALT        --> Arrêter le programme",
        "  ...",
        "  [200] 15          (Donnée X = 15)",
        "  [201] 27          (Donnée Y = 27)",
        "  [202] 0           (Résultat Z initialement 0)",
        "",
        "Démarrage avec PC = 100 (Prochaine instruction) :",
        "",
        "--- CYCLE 1 (Instruction à l'adresse 100) ---",
        "1. FETCH   : L'UC met 100 sur le bus d'adresses, lit 'LOAD 200' → IR = 'LOAD 200'. PC passe à 101.",
        "2. DECODE  : L'UC comprend : « lire case 200 et mettre dans ACC ».",
        "3. EXECUTE : L'UC lit l'adresse 200 (valeur 15) → ACC = 15.",
        "",
        "--- CYCLE 2 (Instruction à l'adresse 101) ---",
        "1. FETCH   : PC=101 → IR = 'ADD 201'. PC passe à 102.",
        "2. DECODE  : L'UC prépare l'UAL pour une addition avec la case 201.",
        "3. EXECUTE : Lecture de [201] (valeur 27). L'UAL calcule 15 + 27 = 42 → ACC = 42.",
        "",
        "--- CYCLE 3 (Instruction à l'adresse 102) ---",
        "1. FETCH   : PC=102 → IR = 'STORE 202'. PC passe à 103.",
        "2. DECODE  : L'UC active le signal WRITE sur le bus de contrôle vers l'adresse 202.",
        "3. EXECUTE : La valeur de ACC (42) est écrite dans la case RAM [202].",
        "",
        "--- CYCLE 4 (Adresse 103) : HALT détecté → Fin d'exécution. RAM[202] vaut désormais 42 !"
      ].join("\n")
    },
    {
      type: "theory",
      title: "4. Goulot d'étranglement et Architecture Harvard Modifiée",
      text: "Le modèle pur de Von Neumann possède une faiblesse célèbre identifiée par John Backus en 1977 : le « goulot d'étranglement de Von Neumann ». Comme les instructions et les données partagent la même mémoire et le même bus de données, le processeur ne peut pas aller chercher l'instruction suivante pendant qu'il est en train de lire ou d'écrire une donnée.\n\nPour contourner cette limite, il existe une architecture concurrente appelée Architecture Harvard : elle sépare physiquement la mémoire des instructions et la mémoire des données, chacune disposant de son propre bus indépendant. Le CPU peut ainsi lire une instruction ET une donnée simultanément !\n\nComment font les processeurs modernes (PC, smartphones ARM) ? Ils utilisent une « Architecture Harvard Modifiée » : la grande RAM externe reste unifiée façon Von Neumann (pratique pour charger n'importe quelle application), mais tout près du cœur du processeur, le cache rapide de niveau 1 (L1) est coupé en deux zones séparées : L1i (pour les instructions) et L1d (pour les données)."
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter en examen universitaire",
      text: "1) Confondre RAM et Stockage (SSD/Flash) : Si vous avez 128 Go de stockage sur votre téléphone et 4 Go de RAM, le processeur n'exécute JAMAIS directement un programme depuis les 128 Go de stockage ! Le système d'exploitation doit d'abord copier le programme en RAM (mémoire centrale volatile).\n2) Croire que « plus de GHz = processeur forcément plus rapide » : Un processeur à 2,4 GHz avec une architecture moderne (pipeline, large mémoire cache, plusieurs cœurs, jeu d'instructions optimisé) peut battre un ancien processeur à 3,5 GHz exécutant moins d'instructions par cycle (IPC)."
    },
    {
      type: "example",
      title: "Étude de cas : Lancement de JOSTECH sur votre téléphone Android",
      text: "Quand vous touchez l'icône d'Acode ou de JOSTECH sur l'écran capacitif (Entrée), le contrôleur tactile génère une interruption matérielle (IRQ) sur le bus de contrôle. Le noyau Linux d'Android suspend sa tâche en cours, charge les fichiers de l'application depuis la mémoire flash UFS vers la RAM LPDDR. Le processeur ARM (Architecture Harvard modifiée) lit les instructions dans son cache L1i, exécute des milliards de cycles Fetch-Decode-Execute dans ses cœurs et son GPU, puis met à jour les pixels de la dalle OLED/LCD (Sortie) 60 fois par seconde."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Dimensionnement du Bus d'Adresses",
      question: "On considère un microprocesseur dont chaque case mémoire RAM contient 1 octet.\n1) Si son bus d'adresses comporte 16 fils (16 bits), combien de cases mémoire (en octets et en Ko) peut-il adresser au maximum ?\n2) Même question pour un processeur 32 bits (sachant que 2^10 = 1024 octets = 1 Kio, 2^20 = 1 Mio, 2^30 = 1 Gio).\n3) Pourquoi les ordinateurs modernes sont-ils passés à l'architecture 64 bits alors que le 32 bits a suffi pendant 20 ans ?",
      solution: "1) Avec 16 bits d'adresse : 2^16 = 65 536 octets. Comme 1 Kio = 1024 octets, 65 536 / 1024 = 64 Kio de RAM maximum.\n2) Avec 32 bits d'adresse : 2^32 = 2^2 × 2^30 = 4 × 1 Gio = 4 Gio (environ 4 Go) de RAM maximum.\n3) Dès que les logiciels, bases de données et systèmes modernes ont exigé plus de 4 Go de RAM (8 Go, 16 Go, 64 Go sur PC et serveurs), le bus d'adresses 32 bits était physiquement bloqué à 4 Go. L'architecture 64 bits permet théoriquement d'adresser 2^64 octets (16 exaoctets), levant définitivement cette barrière."
    },
    {
      title: "Exercice 2 — Traçage manuel des registres CPU",
      question: "Reprenez le modèle de machine de la leçon.\nMémoire initiale : [100] LOAD 300 ; [101] SUB 301 ; [102] STORE 302 ; [103] HALT.\nDonnées : [300] = 50 ; [301] = 18 ; [302] = 99.\nDonnez l'état exact des registres PC, IR, ACC et de la case [302] après la fin complète du Cycle 2, puis après la fin du Cycle 3.",
      solution: "Au départ : PC = 100.\n• Fin Cycle 1 (LOAD 300) : IR = 'LOAD 300', PC = 101, ACC = 50, RAM[302] = 99.\n• Fin Cycle 2 (SUB 301) : IR = 'SUB 301', PC = 102, ACC = 50 - 18 = 32, RAM[302] = 99.\n• Fin Cycle 3 (STORE 302) : IR = 'STORE 302', PC = 103, ACC = 32, et RAM[302] est écrasée par 32."
    },
    {
      title: "Exercice 3 — Réflexion d'architecture",
      question: "Dans un microcontrôleur embarqué Arduino (utilisé en Robotique), les concepteurs utilisent une architecture Harvard pure (mémoire programme Flash séparée de la mémoire données SRAM). Expliquez en 3 lignes quel avantage temps réel cela procure par rapport à un Von Neumann pur.",
      solution: "En architecture Harvard pure, le microcontrôleur possède deux bus distincts : il peut lire simultanément la prochaine instruction du robot (dans la Flash) tout en lisant ou écrivant la valeur d'un capteur (dans la SRAM). Cela supprime le goulot d'étranglement du bus unique et rend le temps de réaction déterministe et prévisible."
    }
  ],
  summary: "L'informatique est une science rigoureuse qui distingue la donnée brute de l'information interprétée. Depuis 1945, le modèle de Von Neumann (programme et données unifiés en RAM, orchestrés par l'UC, l'UAL et les E/S via les bus de données, d'adresses et de contrôle) gouverne nos ordinateurs selon le cycle Fetch-Decode-Execute. Pour contourner le goulot d'étranglement du bus unique, les processeurs modernes combinent la souplesse de Von Neumann en RAM externe avec une architecture Harvard modifiée au niveau de leurs caches internes L1i/L1d.",
  references: [
    "Tanenbaum, A. S. & Austin, T. — Architecture de l'ordinateur (6e éd.), Pearson Education.",
    "Patterson, D. A. & Hennessy, J. L. — Computer Organization and Design, Morgan Kaufmann.",
    "Von Neumann, J. (1945) — First Draft of a Report on the EDVAC, University of Pennsylvania.",
    "Turing, A. M. (1936) — On Computable Numbers, with an Application to the Entscheidungsproblem."
  ]
});