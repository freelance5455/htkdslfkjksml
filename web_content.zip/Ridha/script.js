﻿/* ==========================================================================
   نظام إدارة ورشات الخياطة والإنتاج v54.0 - البرمجة النهائية المباشرة
   تمت إزالة شاشة التحميل والدخول الفوري
   المطور: Ridha say26 | صاحب الورشة: Otmani Mohamed | 2026
   ========================================================================== */

let appData = JSON.parse(localStorage.getItem('workshop_db_2026')) || {
  auth: { username: "admin", password: "123", phone: "0660000000", role: "admin", isLoggedIn: false },
  currentWorkshop: "ورشة سيدي نعمان",
  workshopsList: ["ورشة سيدي نعمان", "ورشة بني سليمان", "ورشة السواڨي", "ورشة مسك الليل - المقر"],
  managerAttendance: {},
  expenses: [],
  inventory: [
    { id: 1, name: "قماش مازيراتي أريور", qty: 15, minQty: 20, unit: "متر" },
    { id: 2, name: "خيوط خياطة ممتازة", qty: 50, minQty: 10, unit: "بكرة" }
  ],
  workers: [
    { id: 101, name: "عمر بن عيسى", role: "خياط سروال القميص", salary30: 65000, joinDate: "2026-09-01", workshop: "ورشة سيدي نعمان" },
    { id: 102, name: "ياسين القاسمي", role: "تفصيل قماش مازيراتي", salary30: 52000, joinDate: "2026-10-23", workshop: "ورشة سيدي نعمان" }
  ],
  users: [
    { id: 1, name: "عثماني محمد", username: "admin", role: "المدير العام", phone: "0660000000", salary: 0, pass: "123", workshop: "جميع الورشات" },
    { id: 2, name: "مسؤول ورشة السواڨي", username: "souagui", role: "مسؤول ورشة", phone: "0661111111", salary: 70000, pass: "123", workshop: "ورشة السواڨي" }
  ],
  attendanceRecords: {},
  exports: [], imports: [], recommendations: []
};

const todayDateStr = new Date().toISOString().split('T')[0];
let productionChartInstance = null;
let qrCodeInstance = null;

document.addEventListener('DOMContentLoaded', () => {
  startLiveClock();
  detectUserLocation();
  setupNetworkListener();
  
  const dateDisplay = document.getElementById('current-date-display');
  if (dateDisplay) dateDisplay.textContent = new Date().toLocaleDateString('ar-DZ');
  
  checkAuthStatus();
  checkSmartAlerts();
});

function setupNetworkListener() {
  const badge = document.getElementById('network-status-badge');
  if (!badge) return;

  const updateStatus = () => {
    if (navigator.onLine) {
      badge.textContent = "🌐 أونلاين";
      badge.className = "network-badge online";
    } else {
      badge.textContent = "📡 أوفلاين (محلي)";
      badge.className = "network-badge offline";
    }
  };

  window.addEventListener('online', updateStatus);
  window.addEventListener('offline', updateStatus);
  updateStatus();
}

function startLiveClock() {
  const clockElem = document.getElementById('live-clock-display');
  if (!clockElem) return;
  const updateClock = () => {
    const now = new Date();
    clockElem.textContent = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  };
  updateClock();
  setInterval(updateClock, 1000);
}

function detectUserLocation() {
  const locElem = document.getElementById('user-location-text');
  if (locElem) locElem.textContent = "بوسكن، الجزائر";
}

function exportTableToExcel(tableID, filename = 'تقرير_الورشة') {
  const table = document.getElementById(tableID);
  if (!table) return;
  const wb = XLSX.utils.table_to_book(table, { sheet: "التقرير" });
  XLSX.writeFile(wb, `${filename}_${todayDateStr}.xlsx`);
}

function updateReceiptTotal() {
  const qty = Number(document.getElementById('rec-qty').value) || 0;
  const unitPrice = Number(document.getElementById('rec-unit-price').value) || 0;
  const total = qty * unitPrice;
  document.getElementById('rec-total-display').textContent = `${total.toLocaleString()} دج`;
}

function generateReceiptQR() {
  const qrBox = document.getElementById('qrcode-box');
  if (!qrBox || typeof QRCode === 'undefined') return;

  qrBox.innerHTML = '';
  const client = document.getElementById('rec-client').value.trim();
  const item = document.getElementById('rec-item').value.trim();
  const qty = document.getElementById('rec-qty').value;
  const price = document.getElementById('rec-unit-price').value;
  const total = (Number(qty) || 0) * (Number(price) || 0);

  const qrText = `ورشة مسك الليل\nسند تسليم\nالعميل: ${client}\nالمنتج: ${item}\nالكمية: ${qty} قطعة\nالإجمالي: ${total} دج\nالتاريخ: ${todayDateStr}`;

  qrCodeInstance = new QRCode(qrBox, {
    text: qrText,
    width: 110,
    height: 110,
    colorDark: "#000000",
    colorLight: "#ffffff",
    correctLevel: QRCode.CorrectLevel.M
  });
}

function openReceiptGeneratorModal() {
  const printDateElem = document.getElementById('rec-print-date');
  if (printDateElem) printDateElem.textContent = new Date().toLocaleDateString('ar-DZ');
  updateReceiptTotal();
  generateReceiptQR();
  openModal('receipt-modal');
}

function checkSmartAlerts() {
  const banner = document.getElementById('smart-alert-banner');
  const alertText = document.getElementById('smart-alert-text');
  if (!banner || !alertText) return;

  const lowStockItem = (appData.inventory || []).find(i => i.qty <= i.minQty);

  if (lowStockItem) {
    alertText.textContent = `⚠️ تنبيه مخزون: القماش (${lowStockItem.name}) وصل إلى (${lowStockItem.qty} ${lowStockItem.unit}) وهو أقل من الحد الأدنى!`;
    banner.style.display = 'block';
  } else {
    banner.style.display = 'none';
  }
}

function dismissAlert() {
  const banner = document.getElementById('smart-alert-banner');
  if (banner) banner.style.display = 'none';
}

function checkAuthStatus() {
  const authScreen = document.getElementById('auth-screen');
  const appContainer = document.getElementById('app-container');

  if (appData.auth && appData.auth.isLoggedIn === true) {
    if (authScreen) authScreen.style.display = 'none';
    if (appContainer) appContainer.style.display = 'flex';
    
    document.getElementById('header-user-name').textContent = appData.auth.username || "عثماني محمد";
    renderWorkshopDropdowns();
    applyRolePermissions();
    renderSidebarMenu();
    renderMobileBottomNav();
    renderAllData();
  } else {
    if (authScreen) authScreen.style.display = 'flex';
    if (appContainer) appContainer.style.display = 'none';
  }
}

function applyRolePermissions() {
  const isOwner = (appData.auth.role === 'admin' || appData.auth.username === 'admin' || appData.auth.username.includes('عثماني') || appData.auth.role === 'المدير العام');
  const ownerElems = document.querySelectorAll('.owner-only');

  ownerElems.forEach(el => {
    if (isOwner) {
      el.style.display = '';
    } else {
      el.style.display = 'none';
    }
  });
}

function handleLogin(e) {
  e.preventDefault();
  const userInput = document.getElementById('login-username').value.trim();
  const passInput = document.getElementById('login-password').value.trim();

  const matchedUser = (appData.users || []).find(u => (u.username === userInput || u.phone === userInput) && u.pass === passInput);

  if ((userInput === 'admin' && passInput === '123') || matchedUser) {
    appData.auth.isLoggedIn = true;
    appData.auth.username = matchedUser ? matchedUser.name : (userInput === 'admin' ? 'عثماني محمد' : userInput);
    appData.auth.role = matchedUser ? matchedUser.role : 'admin';
    saveData();
    checkAuthStatus();
    alert('✅ تم تسجيل الدخول بنجاح!');
  } else {
    alert('❌ اسم المستخدم أو كلمة المرور غير صحيحة!');
  }
}

function handleLogout() {
  appData.auth.isLoggedIn = false;
  saveData();
  closeModal('profile-modal');
  checkAuthStatus();
}

function openProfileModal() {
  document.getElementById('profile-current-user').textContent = appData.auth.username;
  document.getElementById('profile-current-role').textContent = appData.auth.role || 'المدير العام';
  document.getElementById('profile-username').value = appData.auth.username;
  openModal('profile-modal');
}

function handleProfileUpdate(e) {
  e.preventDefault();
  const newUsername = document.getElementById('profile-username').value.trim();
  const newPass = document.getElementById('profile-password').value.trim();
  if (newUsername && newPass) {
    appData.auth.username = newUsername;
    appData.auth.password = newPass;
    saveData();
    document.getElementById('header-user-name').textContent = newUsername;
    alert('✅ تم تحديث بيانات الحساب بنجاح!');
    closeModal('profile-modal');
  }
}

function exportDataBackup() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(appData));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `misk_al_lail_backup_${todayDateStr}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

function openExpensesModal() { openModal('expenses-modal'); }

function handleAddExpenseSubmit(e) {
  e.preventDefault();
  const title = document.getElementById('exp-title').value.trim();
  const amount = Number(document.getElementById('exp-amount').value) || 0;

  if (title && amount > 0) {
    if (!appData.expenses) appData.expenses = [];
    appData.expenses.push({ id: Date.now(), title, amount, date: todayDateStr, workshop: appData.currentWorkshop });
    saveData();
    closeModal('expenses-modal');
    alert('✅ تم تسجيل المصروف اليومي بنجاح!');
    e.target.reset();
  }
}

function renderWorkshopDropdowns() {
  const selectHeader = document.getElementById('workshop-select');
  if (selectHeader) {
    selectHeader.innerHTML = '';
    appData.workshopsList.forEach(ws => {
      const opt = new Option(ws, ws);
      if (ws === appData.currentWorkshop) opt.selected = true;
      selectHeader.appendChild(opt);
    });
  }
}

function handleWorkshopChange(val) {
  appData.currentWorkshop = val;
  saveData();
  renderAllData();
  checkSmartAlerts();
}

function openAddWorkshopModal() {
  openModal('add-workshop-modal');
}

function handleAddWorkshopSubmit(e) {
  e.preventDefault();
  const newWsName = document.getElementById('new-workshop-name').value.trim();

  if (newWsName) {
    if (!appData.workshopsList.includes(newWsName)) {
      appData.workshopsList.push(newWsName);
      appData.currentWorkshop = newWsName;
      saveData();
      renderWorkshopDropdowns();
      renderAllData();
      closeModal('add-workshop-modal');
      alert(`✅ تم إضافة الورشة الجديدة (${newWsName}) بنجاح!`);
      e.target.reset();
    } else {
      alert('⚠️ هذه الورشة موجودة مسبقاً!');
    }
  }
}

function openAddFabricModal() { openModal('add-fabric-modal'); }

function handleAddFabricSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('fabric-name').value.trim();
  const qty = Number(document.getElementById('fabric-qty').value) || 0;
  const minQty = Number(document.getElementById('fabric-min').value) || 10;

  if (name) {
    if (!appData.inventory) appData.inventory = [];
    appData.inventory.push({ id: Date.now(), name, qty, minQty, unit: "متر" });
    saveData();
    renderInventoryTable();
    checkSmartAlerts();
    closeModal('add-fabric-modal');
    alert('✅ تم إضافة القماش للمخزون بنجاح!');
    e.target.reset();
  }
}

function renderInventoryTable() {
  const tbody = document.getElementById('inventory-table-body');
  if (!tbody) return;
  tbody.innerHTML = '';

  (appData.inventory || []).forEach(item => {
    const isLow = item.qty <= item.minQty;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${item.name}</strong></td>
      <td><strong>${item.qty} ${item.unit}</strong></td>
      <td>${item.minQty} ${item.unit}</td>
      <td><span class="save-badge" style="background:${isLow ? 'rgba(185,28,28,0.15)' : 'rgba(21,128,61,0.15)'}; color:${isLow ? 'var(--accent-danger)' : 'var(--accent-success)'};">${isLow ? '⚠️ منخفض' : '✅ متوفر'}</span></td>
      <td><button onclick="deleteInventoryItem(${item.id})" class="btn btn-danger" style="padding:4px 8px; font-size:0.75rem;">حذف 🗑️</button></td>
    `;
    tbody.appendChild(tr);
  });
}

function deleteInventoryItem(id) {
  if (confirm('هل أنت متأكد من مسح هذا القماش من المخزون؟')) {
    appData.inventory = (appData.inventory || []).filter(i => i.id !== id);
    saveData();
    renderInventoryTable();
    checkSmartAlerts();
  }
}

function renderSidebarMenu() {
  const menuList = document.getElementById('sidebar-menu-list');
  if (!menuList) return;
  menuList.innerHTML = '';
  const isOwner = (appData.auth.role === 'admin' || appData.auth.username === 'admin' || appData.auth.username.includes('عثماني') || appData.auth.role === 'المدير العام');

  const items = [
    { id: 'dashboard', label: 'الرئيسية', icon: '🌤️', show: true },
    { id: 'daily-attendance', label: 'الغياب والدوام', icon: '📋', show: true },
    { id: 'inventory', label: 'مخزون الأقماش', icon: '🧵', show: true },
    { id: 'exports', label: 'الصادرات', icon: '📤', show: true },
    { id: 'imports', label: 'الواردات', icon: '📥', show: true },
    { id: 'recommendations', label: 'التوصيات', icon: '💡', show: true },
    { id: 'workers', label: 'الأجور (للصاحب)', icon: '👷', show: isOwner },
    { id: 'invoices', label: 'الفواتير', icon: '🧾', show: isOwner },
    { id: 'archive', label: 'الأرشيف', icon: '📚', show: isOwner },
    { id: 'users-management', label: 'إدارة المستخدمين', icon: '👥', show: isOwner }
  ];

  items.filter(i => i.show).forEach((item, index) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <a href="#${item.id}" class="nav-item ${index === 0 ? 'active' : ''}" onclick="showSection('${item.id}'); return false;">
        <span class="icon">${item.icon}</span>
        <span class="label">${item.label}</span>
      </a>
    `;
    menuList.appendChild(li);
  });
}

function renderMobileBottomNav() {
  const navContainer = document.getElementById('mobile-bottom-nav');
  if (!navContainer) return;
  const isOwner = (appData.auth.role === 'admin' || appData.auth.username === 'admin' || appData.auth.username.includes('عثماني') || appData.auth.role === 'المدير العام');

  navContainer.innerHTML = `
    <a href="#dashboard" class="mobile-nav-btn active" onclick="showSection('dashboard'); return false;"><span class="nav-icon">🌤️</span><span class="nav-label">الرئيسية</span></a>
    <a href="#daily-attendance" class="mobile-nav-btn" onclick="showSection('daily-attendance'); return false;"><span class="nav-icon">📋</span><span class="nav-label">الحضور</span></a>
    <a href="#inventory" class="mobile-nav-btn" onclick="showSection('inventory'); return false;"><span class="nav-icon">🧵</span><span class="nav-label">المخزون</span></a>
    ${isOwner ? `<a href="#workers" class="mobile-nav-btn" onclick="showSection('workers'); return false;"><span class="nav-icon">👷</span><span class="nav-label">الأجور</span></a>` : ''}
  `;
}

function showSection(sectionId) {
  document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-btn').forEach(m => m.classList.remove('active'));

  const activeSec = document.getElementById(`section-${sectionId}`);
  const activeNav = document.querySelector(`.nav-item[onclick*="${sectionId}"]`);
  const activeMobileNav = document.querySelector(`.mobile-nav-btn[onclick*="${sectionId}"]`);

  if (activeSec) activeSec.classList.add('active');
  if (activeNav) activeNav.classList.add('active');
  if (activeMobileNav) activeMobileNav.classList.add('active');

  toggleSidebar(false);
}

function openCalcModal() {
  document.getElementById('calc-qty').value = '';
  document.getElementById('calc-price').value = '';
  document.getElementById('calc-result-total').textContent = '0';
  openModal('calc-modal');
}

function calculateProductionTotal() {
  const qty = Number(document.getElementById('calc-qty').value) || 0;
  const price = Number(document.getElementById('calc-price').value) || 0;
  const total = qty * price;
  document.getElementById('calc-result-total').textContent = total.toLocaleString();
}

function renderAttendanceTable() {
  const tbody = document.getElementById('attendance-table-body');
  if (!tbody) return;
  tbody.innerHTML = '';

  const currentWorkers = appData.workers.filter(w => w.workshop === appData.currentWorkshop);
  const dayRecords = (appData.attendanceRecords || {})[todayDateStr] || {};

  currentWorkers.forEach(w => {
    const status = dayRecords[w.id] || 'absent';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><a href="#" onclick="openWorkerDetailsCard(${w.id}); return false;" style="color:var(--primary-accent); text-decoration:none; font-weight:800;">👤 ${w.name}</a></td>
      <td>${w.role}</td>
      <td>
        <div class="attendance-btn-group">
          <button onclick="setWorkerAttendance(${w.id}, 'full')" class="att-btn ${status === 'full' ? 'active-full' : ''}">☀️ يوم كامل</button>
          <button onclick="setWorkerAttendance(${w.id}, 'half')" class="att-btn ${status === 'half' ? 'active-half' : ''}">🌤️ نصف يوم</button>
          <button onclick="setWorkerAttendance(${w.id}, 'absent')" class="att-btn ${status === 'absent' ? 'active-absent' : ''}">❌ غائب</button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
  
  renderWorkersPayrollTable();
}

function renderWorkersPayrollTable() {
  const tbody = document.getElementById('workers-table-body');
  if (!tbody) return;
  tbody.innerHTML = '';

  const currentWorkers = appData.workers.filter(w => w.workshop === appData.currentWorkshop);
  const titleElem = document.getElementById('current-payroll-workshop-title');
  if (titleElem) titleElem.textContent = appData.currentWorkshop;

  currentWorkers.forEach(w => {
    const dailyRate = Math.round((w.salary30 || 60000) / 26);
    let workedDaysCount = 0;
    
    Object.keys(appData.attendanceRecords || {}).forEach(date => {
      const status = appData.attendanceRecords[date][w.id];
      if (status === 'full') workedDaysCount += 1;
      else if (status === 'half') workedDaysCount += 0.5;
    });

    const netSalary = Math.round(workedDaysCount * dailyRate);

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><a href="#" onclick="openWorkerDetailsCard(${w.id}); return false;" style="color:var(--primary-accent); text-decoration:none; font-weight:800;">👤 ${w.name}</a></td>
      <td>${w.role}</td>
      <td>${w.joinDate || '2026-01-01'}</td>
      <td>${(w.salary30 || 60000).toLocaleString()} دج</td>
      <td>${workedDaysCount} يوم</td>
      <td><strong style="color:var(--accent-success);">${netSalary.toLocaleString()} دج</strong></td>
    `;
    tbody.appendChild(tr);
  });
}

function openWorkerDetailsCard(workerId) {
  const worker = appData.workers.find(w => w.id === workerId);
  if (!worker) return;

  document.getElementById('card-worker-id').value = worker.id;
  document.getElementById('card-worker-name').value = worker.name;
  document.getElementById('card-worker-role').value = worker.role;
  document.getElementById('card-worker-joindate').value = worker.joinDate || todayDateStr;
  document.getElementById('card-worker-salary').value = worker.salary30 || 60000;

  const wsSelect = document.getElementById('card-worker-workshop');
  if (wsSelect) {
    wsSelect.innerHTML = '';
    appData.workshopsList.forEach(ws => {
      const opt = new Option(ws, ws);
      if (ws === worker.workshop) opt.selected = true;
      wsSelect.appendChild(opt);
    });
  }

  const dailyRate = Math.round((worker.salary30 || 60000) / 26);
  let workedDaysCount = 0;
  
  Object.keys(appData.attendanceRecords || {}).forEach(date => {
    const status = appData.attendanceRecords[date][worker.id];
    if (status === 'full') workedDaysCount += 1;
    else if (status === 'half') workedDaysCount += 0.5;
  });

  const netSalary = Math.round(workedDaysCount * dailyRate);

  document.getElementById('card-daily-rate').textContent = dailyRate.toLocaleString();
  document.getElementById('card-worked-days').textContent = workedDaysCount;
  document.getElementById('card-net-salary').textContent = netSalary.toLocaleString();

  applyRolePermissions();
  openModal('worker-details-modal');
}

function handleSaveWorkerDetails(e) {
  e.preventDefault();
  const id = Number(document.getElementById('card-worker-id').value);
  const worker = appData.workers.find(w => w.id === id);

  if (worker) {
    worker.name = document.getElementById('card-worker-name').value.trim();
    worker.role = document.getElementById('card-worker-role').value.trim();
    worker.workshop = document.getElementById('card-worker-workshop').value;
    worker.joinDate = document.getElementById('card-worker-joindate').value;
    worker.salary30 = Number(document.getElementById('card-worker-salary').value) || 60000;

    saveData();
    renderAllData();
    closeModal('worker-details-modal');
    alert('✅ تم حفظ التعديلات على بيانات العامل بنجاح!');
  }
}

function deleteWorkerFromCard() {
  const id = Number(document.getElementById('card-worker-id').value);
  if (confirm('هل أنت تأكد من إزالة هذا العامل نهائياً من سجلات الورشة؟')) {
    appData.workers = appData.workers.filter(w => w.id !== id);
    saveData();
    renderAllData();
    closeModal('worker-details-modal');
    alert('🗑️ تم حذف العامل بنجاح.');
  }
}

function setWorkerAttendance(workerId, statusValue) {
  if (!appData.attendanceRecords[todayDateStr]) {
    appData.attendanceRecords[todayDateStr] = {};
  }
  appData.attendanceRecords[todayDateStr][workerId] = statusValue;
  saveData();
  renderAttendanceTable();
  updateChart();
  checkSmartAlerts();
}

function setManagerAttendance(statusVal) {
  if (!appData.managerAttendance) appData.managerAttendance = {};
  if (!appData.managerAttendance[appData.currentWorkshop]) appData.managerAttendance[appData.currentWorkshop] = {};
  
  appData.managerAttendance[appData.currentWorkshop][todayDateStr] = statusVal;
  saveData();
  renderManagerAttendanceUI();
  alert('✅ تم تسجيل حضور مسؤول الورشة بنجاح!');
}

function renderManagerAttendanceUI() {
  const currentSt = ((appData.managerAttendance || {})[appData.currentWorkshop] || {})[todayDateStr] || 'absent';
  const bFull = document.getElementById('mgr-btn-full');
  const bHalf = document.getElementById('mgr-btn-half');
  const bAbsent = document.getElementById('mgr-btn-absent');

  if (bFull) bFull.className = `att-btn ${currentSt === 'full' ? 'active-full' : ''}`;
  if (bHalf) bHalf.className = `att-btn ${currentSt === 'half' ? 'active-half' : ''}`;
  if (bAbsent) bAbsent.className = `att-btn ${currentSt === 'absent' ? 'active-absent' : ''}`;
}

function openAddWorkerModal() { openModal('add-worker-modal'); }

function handleAddWorkerSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('new-worker-fullname').value.trim();
  const role = document.getElementById('new-worker-role').value.trim();
  const joinDate = document.getElementById('new-worker-join-date').value || todayDateStr;
  const salary = Number(document.getElementById('new-worker-salary').value) || 60000;

  if (name) {
    appData.workers.push({ id: Date.now(), name, role, salary30: salary, joinDate, workshop: appData.currentWorkshop });
    saveData();
    renderAllData();
    closeModal('add-worker-modal');
    alert('✅ تم تسجيل العامل الجديد بنجاح!');
    e.target.reset();
  }
}

function openAddRecommendationModal() {
  const select = document.getElementById('rec-workshop-select');
  if (select) {
    select.innerHTML = '';
    appData.workshopsList.forEach(ws => select.appendChild(new Option(ws, ws)));
  }
  openModal('add-rec-modal');
}

function handleAddRecSubmit(e) {
  e.preventDefault();
  const text = document.getElementById('rec-text').value.trim();
  const ws = document.getElementById('rec-workshop-select').value;
  if (text) {
    if (!appData.recommendations) appData.recommendations = [];
    appData.recommendations.push({ id: Date.now(), text, workshop: ws, sender: appData.auth.username, date: todayDateStr });
    saveData();
    renderRecommendationsTable();
    closeModal('add-rec-modal');
    alert('✅ تم إرسال التوصية بنجاح!');
    e.target.reset();
  }
}

function renderRecommendationsTable() {
  const tbody = document.getElementById('recommendations-table-body');
  if (!tbody) return;
  tbody.innerHTML = '';
  (appData.recommendations || []).forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${r.text}</td><td>${r.workshop}</td><td>${r.sender}</td><td>${r.date}</td><td><button onclick="deleteRec(${r.id})" class="btn btn-danger" style="padding:4px 8px; font-size:0.75rem;">مسح</button></td>`;
    tbody.appendChild(tr);
  });
}

function deleteRec(id) {
  appData.recommendations = (appData.recommendations || []).filter(r => r.id !== id);
  saveData();
  renderRecommendationsTable();
}

function openAddUserModal() { openModal('add-user-modal'); }

function handleAddUserSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('new-user-name').value.trim();
  const role = document.getElementById('new-user-role-select').value;
  const username = document.getElementById('new-user-username').value.trim();
  const phone = document.getElementById('new-user-phone').value.trim();
  const salary = Number(document.getElementById('new-user-salary').value) || 0;
  const pass = document.getElementById('new-user-pass').value.trim();

  if (name && username && pass) {
    if (!appData.users) appData.users = [];
    appData.users.push({ id: Date.now(), name, role, username, phone, salary, pass, workshop: appData.currentWorkshop });
    saveData();
    renderUsersTable();
    closeModal('add-user-modal');
    alert('✅ تم إضافة المستخدم بنجاح!');
    e.target.reset();
  }
}

function renderUsersTable() {
  const tbody = document.getElementById('users-table-body');
  if (!tbody) return;
  tbody.innerHTML = '';
  (appData.users || []).forEach(u => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${u.name}</strong></td>
      <td><span class="save-badge">${u.role}</span></td>
      <td>${u.phone}</td>
      <td>${(u.salary || 0).toLocaleString()} دج</td>
      <td><code>${u.pass}</code></td>
      <td>${u.workshop}</td>
      <td><button onclick="deleteUser(${u.id})" class="btn btn-danger" style="padding:4px 8px; font-size:0.75rem;">حذف 🗑️</button></td>
    `;
    tbody.appendChild(tr);
  });
}

function deleteUser(id) {
  if (confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
    appData.users = (appData.users || []).filter(u => u.id !== id);
    saveData();
    renderUsersTable();
  }
}

function updateChart() {
  const ctx = document.getElementById('productionChart');
  if (!ctx || typeof Chart === 'undefined') return;

  const todayExports = (appData.exports || []).filter(e => e.date === todayDateStr).reduce((sum, e) => sum + (Number(e.qty) || 0), 0);
  document.getElementById('dash-today-exports').textContent = `${todayExports} قطعة`;

  const todayImportsCount = (appData.imports || []).filter(i => i.date === todayDateStr).length;
  document.getElementById('dash-today-imports').textContent = `${todayImportsCount} شحنة`;

  const workersSalaries = (appData.workers || []).reduce((sum, w) => sum + (Number(w.salary30) || 60000), 0);
  const managersSalaries = (appData.users || []).reduce((sum, u) => sum + (Number(u.salary) || 0), 0);
  const grandAllSalaries = workersSalaries + managersSalaries;

  const totalSalElem = document.getElementById('dash-total-all-salaries');
  if (totalSalElem) totalSalElem.textContent = `${grandAllSalaries.toLocaleString()} دج`;

  const currentWorkers = appData.workers.filter(w => w.workshop === appData.currentWorkshop);
  const dayRecords = (appData.attendanceRecords || {})[todayDateStr] || {};
  let fullCount = 0; let halfCount = 0; let absentCount = 0;

  currentWorkers.forEach(w => {
    const st = dayRecords[w.id];
    if (st === 'full') fullCount++;
    else if (st === 'half') halfCount++;
    else absentCount++;
  });

  if (productionChartInstance) productionChartInstance.destroy();

  productionChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['يوم كامل', 'نصف يوم', 'غائب'],
      datasets: [{ data: [fullCount, halfCount, absentCount], backgroundColor: ['#15803d', '#d97706', '#b91c1c'] }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
  });
}

function renderAllData() {
  renderAttendanceTable();
  renderWorkersPayrollTable();
  renderInventoryTable();
  renderManagerAttendanceUI();
  renderRecommendationsTable();
  renderUsersTable();
  applyRolePermissions();
  updateChart();
}

function saveData() { localStorage.setItem('workshop_db_2026', JSON.stringify(appData)); }
function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
function toggleTheme() {
  const html = document.documentElement;
  const current = html.getAttribute('data-theme');
  html.setAttribute('data-theme', current === 'dark' ? 'light' : 'dark');
}
function toggleSidebar(force) {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (!sidebar || !overlay) return;
  if (typeof force === 'boolean') {
    sidebar.classList.toggle('active', force);
    overlay.classList.toggle('active', force);
  } else {
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
  }
}
function filterAttendanceTable(query) {
  const rows = document.querySelectorAll('#attendance-table-body tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(query.toLowerCase()) ? '' : 'none';
  });
}