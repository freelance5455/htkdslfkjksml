Stage 1188 — WebView Bridge Attach Final

Root cause path: the settings page is rendered by the persistent single WebView router, but the native interface was being attached only around page lifecycle callbacks. This version keeps one MarketBridge instance and attaches it before first load, on page start/finish, and once after setContentView. It also records a JS visibility probe.
