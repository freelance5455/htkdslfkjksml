'use strict';
/* Catálogo de exercícios e modelos (dados neutros; nomes vêm do i18n: ex.<id>, tpl.<id>.*) */
const CATALOG = {
  bench_press:['chest','barbell'], incline_db_press:['chest','dumbbell'], chest_fly:['chest','machine'], pushup:['chest','bodyweight'],
  overhead_press:['shoulders','dumbbell'], lateral_raise:['shoulders','dumbbell'], rear_delt:['shoulders','machine'],
  triceps_pushdown:['triceps','cable'], triceps_overhead:['triceps','dumbbell'],
  lat_pulldown:['back','cable'], seated_row:['back','machine'], one_arm_row:['back','dumbbell'], pullup:['back','bodyweight'],
  biceps_curl:['biceps','dumbbell'], hammer_curl:['biceps','dumbbell'],
  squat:['legs','barbell'], leg_press:['legs','machine'], leg_extension:['legs','machine'], leg_curl:['legs','machine'],
  lunges:['legs','dumbbell'], rdl:['legs','barbell'], goblet_squat:['legs','kettlebell'],
  hip_thrust:['glutes','barbell'], kb_swing:['glutes','kettlebell'], calf_raise:['calves','machine'],
  plank:['abs','bodyweight'], crunch:['abs','bodyweight'],
  treadmill:['cardio','other'], bike:['cardio','bike'], jump_rope:['cardio','other'], brisk_walk:['cardio','other'],
  stretch_full:['mobility','bodyweight'], hip_mobility:['mobility','bodyweight'], shoulder_mobility:['mobility','band'], cat_cow:['mobility','bodyweight']
};
/* [idExercício, séries, reps por série (ou minutos), descanso(s)] */
const TEMPLATES = {
  abc: { days:3, list:[
    { title:'tpl.abc.a', ex:[['bench_press',4,'10,10,8,8',120],['incline_db_press',3,'10,10,10',90],['chest_fly',3,'12,12,12',60],['lateral_raise',3,'12,12,12',60],['triceps_pushdown',3,'12,12,12',60]] },
    { title:'tpl.abc.b', ex:[['lat_pulldown',4,'10,10,8,8',90],['seated_row',3,'10,10,10',90],['one_arm_row',3,'10,10,10',90],['biceps_curl',3,'12,12,10',60],['hammer_curl',3,'12,12,10',60]] },
    { title:'tpl.abc.c', ex:[['squat',4,'10,8,8,8',120],['leg_press',3,'12,12,12',90],['rdl',3,'10,10,10',90],['leg_curl',3,'12,12,12',60],['calf_raise',4,'15,15,15,15',45]] } ] },
  abcd: { days:4, list:[
    { title:'tpl.abcd.a', ex:[['bench_press',4,'10,10,8,8',120],['incline_db_press',3,'10,10,10',90],['chest_fly',3,'12,12,12',60],['triceps_pushdown',3,'12,12,12',60],['triceps_overhead',3,'12,12,12',60]] },
    { title:'tpl.abcd.b', ex:[['lat_pulldown',4,'10,10,8,8',90],['seated_row',3,'10,10,10',90],['one_arm_row',3,'10,10,10',90],['biceps_curl',3,'12,12,10',60],['hammer_curl',3,'12,12,10',60]] },
    { title:'tpl.abcd.c', ex:[['squat',4,'10,8,8,8',120],['leg_press',3,'12,12,12',90],['rdl',3,'10,10,10',90],['leg_extension',3,'12,12,12',60],['calf_raise',4,'15,15,15,15',45]] },
    { title:'tpl.abcd.d', ex:[['overhead_press',4,'10,10,8,8',90],['lateral_raise',4,'12,12,12,12',60],['rear_delt',3,'12,12,12',60],['plank',3,'30,30,30',45],['crunch',3,'15,15,15',45]] } ] },
  fullbody: { days:3, list:[
    { title:'tpl.fullbody.a', ex:[['squat',3,'10,10,10',120],['bench_press',3,'10,10,10',90],['seated_row',3,'10,10,10',90],['overhead_press',3,'10,10,10',90],['plank',3,'30,30,30',45]] },
    { title:'tpl.fullbody.b', ex:[['rdl',3,'10,10,10',120],['incline_db_press',3,'10,10,10',90],['lat_pulldown',3,'10,10,10',90],['lateral_raise',3,'12,12,12',60],['crunch',3,'15,15,15',45]] },
    { title:'tpl.fullbody.c', ex:[['leg_press',3,'12,12,12',90],['pushup',3,'10,10,10',60],['one_arm_row',3,'10,10,10',90],['biceps_curl',2,'12,12',60],['triceps_pushdown',2,'12,12',60]] } ] },
  upperlower: { days:4, list:[
    { title:'tpl.upperlower.ua', ex:[['bench_press',4,'8,8,8,8',120],['seated_row',4,'10,10,10,10',90],['overhead_press',3,'10,10,10',90],['biceps_curl',3,'12,12,12',60],['triceps_pushdown',3,'12,12,12',60]] },
    { title:'tpl.upperlower.la', ex:[['squat',4,'8,8,8,8',120],['rdl',3,'10,10,10',90],['leg_curl',3,'12,12,12',60],['calf_raise',4,'15,15,15,15',45],['plank',3,'30,30,30',45]] },
    { title:'tpl.upperlower.ub', ex:[['incline_db_press',4,'10,10,10,10',90],['lat_pulldown',4,'10,10,10,10',90],['lateral_raise',3,'12,12,12',60],['hammer_curl',3,'12,12,12',60],['triceps_overhead',3,'12,12,12',60]] },
    { title:'tpl.upperlower.lb', ex:[['leg_press',4,'12,12,12,12',90],['hip_thrust',3,'10,10,10',90],['leg_extension',3,'12,12,12',60],['lunges',3,'10,10,10',60],['crunch',3,'15,15,15',45]] } ] },
  cardio: { days:3, list:[
    { title:'tpl.cardio.a', ex:[['treadmill',1,'30',0],['stretch_full',1,'8',0]] },
    { title:'tpl.cardio.b', ex:[['bike',1,'35',0],['hip_mobility',1,'8',0]] },
    { title:'tpl.cardio.c', ex:[['brisk_walk',1,'40',0],['jump_rope',1,'10',0],['shoulder_mobility',1,'8',0],['cat_cow',1,'5',0]] } ] },
  scratch: { days:0, list:[] }
};
const TEMPLATE_ORDER = ['abc','abcd','fullbody','upperlower','cardio','scratch'];
