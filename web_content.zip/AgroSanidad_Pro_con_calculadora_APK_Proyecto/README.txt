AGROSANIDAD PRO — PROYECTO ANDROID BASADO EN EL ARCHIVO CORRECTO

Este proyecto utiliza AgroSanidad_Pro_con_calculadora.html, el archivo que incluye la calculadora y el resto de la aplicación. Se conserva su interfaz y sus funciones principales.

FUNCIONES DE COPIA DE SEGURIDAD EN ANDROID
- Exportar copia: abre el selector nativo de Android para guardar el archivo JSON.
- Importar copia JSON: abre el selector de archivos de Android para restaurar una copia.
- Los registros normales siguen guardándose localmente en el almacenamiento del WebView del dispositivo.

PARA GENERAR LA APK
1. Descomprime esta carpeta en un computador.
2. Instala Android Studio y Android SDK (API 35) si no los tienes.
3. Abre Android Studio y selecciona Open; elige la carpeta android de este proyecto.
4. Permite que Android Studio sincronice Gradle y descargue los componentes necesarios (se requiere Internet).
5. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).

IMPORTANTE
Este ZIP contiene el código fuente del proyecto Android, no un APK ya compilado. Este entorno no tiene Android SDK ni acceso al registro de paquetes para compilar y probar la APK aquí. Si Android Studio solicita crear/actualizar el Gradle Wrapper, permite que lo configure para Gradle 8.9.

El archivo web original adaptado también está en www/index.html.
