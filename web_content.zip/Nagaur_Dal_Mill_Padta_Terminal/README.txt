NAGAUR DAL MILL — PURE BHAAV TERMINAL

Files:
- index.html: complete standalone web app.

How to use:
1. Extract this ZIP.
2. Open index.html in a modern browser (Chrome recommended).
3. Internet is only needed to load the optional Google Fonts; the calculator itself works offline.
4. Use “WhatsApp Bhaav Report Copy” to copy the report, then paste it into WhatsApp.

Note: Tax percentage and floor-rate formulas are included as provided in the source.
