NeonOS Launcher
1) Cu PC: deschide folderul in Android Studio, apoi Build > Build APK(s).
2) Doar cu telefonul: urca proiectul intr-un repo GitHub; la Actions ruleaza "Build APK" si descarca artefactul NeonOS-apk.
3) Instaleaza APK-ul (permite surse necunoscute), apoi: Setari Android > Aplicatii implicite > Aplicatie Home > NeonOS.
Interfata se afla in app/src/main/assets/index.html (acelasi fisier ca neonos.html).
