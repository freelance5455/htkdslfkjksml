NeonOS Launcher
1) Cu PC: deschide folderul in Android Studio, apoi Build > Build APK(s).
2) Doar cu telefonul: urca proiectul intr-un repo GitHub; la Actions ruleaza "Build APK" si descarca artefactul NeonOS-apk.
3) Instaleaza APK-ul (permite surse necunoscute), apoi: Setari Android > Aplicatii implicite > Aplicatie Home > NeonOS.
Interfata se afla in app/src/main/assets/index.html (acelasi fisier ca neonos.html).


Modificari in aceasta versiune:
- Corectat argumentul boolean pentru selectorul de cont Google.
- Adaugata permisiunea CAMERA si gestionarea permisiunii WebView pentru captura video.
- Versiunea Gradle din GitHub Actions este aliniata cu Android Gradle Plugin 8.5.2.

Limitari Android:
NeonOS este un launcher, nu un sistem de operare separat. Android nu permite unei aplicatii obisnuite sa controleze complet alte aplicatii, permisiunile, datele private sau toate functiile hardware. Camera solicita permisiune la prima folosire.
