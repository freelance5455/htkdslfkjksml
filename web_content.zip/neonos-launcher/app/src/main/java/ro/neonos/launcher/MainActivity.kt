package ro.neonos.launcher

import android.annotation.SuppressLint
import android.accounts.AccountManager
import android.app.ActivityManager
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.SystemClock
import android.telephony.TelephonyManager
import java.io.File
import android.app.role.RoleManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.Manifest
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingWebPermission: PermissionRequest? = null
    private val cameraRequestCode = 9

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsCamera = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    if (wantsCamera && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else if (wantsCamera) {
                        pendingWebPermission = request
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), cameraRequestCode)
                    } else {
                        request.deny()
                    }
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        immersive()
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = if (!isHome()) View.SYSTEM_UI_FLAG_VISIBLE else View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    private fun isHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == packageName
    }

    override fun onResume() {
        super.onResume()
        immersive()
        web.evaluateJavascript("if(window.onHome)onHome()", null)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    // Butonul Home: revii pe ecranul principal NeonOS și reîmprospătezi lista de aplicații
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        web.evaluateJavascript("if(window.refresh)refresh();home()", null)
    }

    // Butonul Înapoi al telefonului apasă Înapoi din bara NeonOS
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("document.querySelector('[data-n=b]').click()", null)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 8) web.evaluateJavascript("if(window.onHome)onHome()", null)
        if (req == 7 && res == RESULT_OK) {
            val n = data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME) ?: return
            web.evaluateJavascript("gotAcc(" + JSONObject.quote(n) + ")", null)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == cameraRequestCode) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                } else {
                    request.deny()
                }
            }
        }
    }

    private fun memInfo(key: String): Long = try {
        File("/proc/meminfo").readLines().first { it.startsWith("$key:") }.split(Regex("\\s+"))[1].toLong() / 1024
    } catch (e: Exception) {
        -1
    }

    inner class Bridge {
        @JavascriptInterface
        fun apps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            val arr = JSONArray()
            for (r in list) {
                arr.put(JSONObject().put("n", r.loadLabel(pm).toString()).put("p", r.activityInfo.packageName))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun icon(pkg: String): String = try {
            png(packageManager.getApplicationIcon(pkg))
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            runOnUiThread {
                packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
            }
        }

        @JavascriptInterface
        fun open(url: String) {
            if (url.startsWith("https://") || url.startsWith("http://"))
                runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }

        @JavascriptInterface
        fun sys(a: String) {
            val act = when (a) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "data" -> Settings.ACTION_WIRELESS_SETTINGS
                "sec" -> Settings.ACTION_SECURITY_SETTINGS
                "net" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
                "bt" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "plane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                "home" -> Settings.ACTION_HOME_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                "privacy" -> if (Build.VERSION.SDK_INT >= 29) Settings.ACTION_PRIVACY_SETTINGS else Settings.ACTION_SECURITY_SETTINGS
                "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            runOnUiThread {
                try {
                    val intent = Intent(act)
                    if (a == "notifications") intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    startActivity(intent)
                } catch (_: Exception) {
                    try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { }
                }
            }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun pickAccount() {
            runOnUiThread {
                startActivityForResult(
                    AccountManager.newChooseAccountIntent(null, null, arrayOf("com.google"), false, null, null, null), 7
                )
            }
        }

        @JavascriptInterface
        fun requestHome() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 29) {
                    val rm = getSystemService(RoleManager::class.java)
                    if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME))
                        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 8)
                } else {
                    startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                }
            }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun info(): String = try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val me = am.getProcessMemoryInfo(intArrayOf(android.os.Process.myPid()))[0].totalPss / 1024
            val sf = StatFs(Environment.getDataDirectory().path)
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val c = cm.getNetworkCapabilities(cm.activeNetwork)
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val bt = try { BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (e: Exception) { false }
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = bi?.getIntExtra("level", -1) ?: -1
            val sc = bi?.getIntExtra("scale", 100) ?: 100
            JSONObject()
                .put("rt", mi.totalMem / 1048576).put("rf", mi.availMem / 1048576).put("me", me)
                .put("st", sf.totalBytes / 1048576).put("sf", sf.availableBytes / 1048576)
                .put("wifi", if (wm.isWifiEnabled) 1 else 0).put("bt", if (bt) 1 else 0)
                .put("cell", if (c?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) 1 else 0)
                .put("down", (c?.linkDownstreamBandwidthKbps ?: 0) / 1000.0)
                .put("bat", if (lv >= 0) lv * 100 / sc else -1)
                .put("home", if (isHome()) 1 else 0).toString()
        } catch (e: Exception) {
            ""
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun scan(): String = try {
            val o = JSONObject()
            val dm = resources.displayMetrics
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val sf = StatFs(Environment.getDataDirectory().path)
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val c = cm.getNetworkCapabilities(cm.activeNetwork)
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val kg = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            val dp = getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val sm = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val wi = try { wm.connectionInfo } catch (e: Exception) { null }
            val enc = dp?.storageEncryptionStatus ?: 0
            val lv = bi?.getIntExtra("level", -1) ?: -1
            val sc = bi?.getIntExtra("scale", 100) ?: 100
            val nt = when {
                c == null -> "none"
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
                c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "eth"
                else -> "other"
            }
            o.put("man", Build.MANUFACTURER).put("model", Build.MODEL).put("hw", Build.HARDWARE)
            o.put("soc", if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else "")
            o.put("and", Build.VERSION.RELEASE).put("sdk", Build.VERSION.SDK_INT)
            o.put("patch", Build.VERSION.SECURITY_PATCH).put("abi", Build.SUPPORTED_ABIS[0])
            o.put("cores", Runtime.getRuntime().availableProcessors())
            o.put("sens", sm?.getSensorList(Sensor.TYPE_ALL)?.size ?: 0)
            o.put("up", SystemClock.elapsedRealtime() / 60000)
            o.put("apps", packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).size - 1)
            o.put("w", dm.widthPixels).put("h", dm.heightPixels).put("dpi", dm.densityDpi)
            o.put("hz", windowManager.defaultDisplay.refreshRate.toDouble())
            o.put("rt", mi.totalMem / 1048576).put("rf", mi.availMem / 1048576).put("thr", mi.threshold / 1048576)
            o.put("low", mi.lowMemory).put("swt", memInfo("SwapTotal")).put("swf", memInfo("SwapFree"))
            o.put("me", am.getProcessMemoryInfo(intArrayOf(android.os.Process.myPid()))[0].totalPss / 1024)
            o.put("st", sf.totalBytes / 1048576).put("sf", sf.availableBytes / 1048576)
            o.put("lv", if (lv >= 0) lv * 100 / sc else -1)
            o.put("chg", (bi?.getIntExtra("status", -1) ?: -1).let { it == 2 || it == 5 })
            o.put("tmp", (bi?.getIntExtra("temperature", 0) ?: 0) / 10.0)
            o.put("vol", bi?.getIntExtra("voltage", 0) ?: 0)
            o.put("nt", nt).put("car", tm?.networkOperatorName ?: "")
            o.put("sim", tm?.simState == TelephonyManager.SIM_STATE_READY).put("roam", tm?.isNetworkRoaming == true)
            o.put("wifi", wm.isWifiEnabled).put("rssi", wi?.rssi ?: -127).put("link", wi?.linkSpeed ?: -1)
            o.put("dn", c?.linkDownstreamBandwidthKbps ?: 0).put("upl", c?.linkUpstreamBandwidthKbps ?: 0)
            o.put("met", cm.isActiveNetworkMetered).put("vpn", c?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true)
            o.put("lock", kg?.isDeviceSecure == true).put("enc", enc == 3 || enc == 4 || enc == 5)
            o.put("adb", Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0) == 1)
            o.put("dev", Settings.Global.getInt(contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1)
            o.put("root", listOf("/system/bin/su", "/system/xbin/su", "/sbin/su").any { File(it).exists() })
            o.put("home", isHome())
            o.toString()
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun settings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
    }

    private fun png(d: Drawable): String {
        val s = 96
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s)
        d.draw(Canvas(bmp))
        val o = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
        return "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }
}
