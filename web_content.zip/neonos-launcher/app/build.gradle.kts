plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ro.neonos.launcher"
    compileSdk = 34
    defaultConfig {
        applicationId = "ro.neonos.launcher"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "3.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
