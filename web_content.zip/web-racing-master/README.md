# Racez.io

![Racez.io](frontend/public/favicon.png)

A real-time multiplayer 3D racing game built with JavaScript and modern web technologies. Race with friends through various tracks, compete for the best time, and enjoy physics-based driving mechanics.

## Play Now

[Play Racez.io Online](https://racez.io)

## Features

- **Multiplayer Racing**: Race against friends in real-time using WebRTC peer-to-peer connections
- **Physics-Based Driving**: Realistic car physics with speed-dependent steering, suspension, and collision detection
- **Multiple Tracks**: Different race tracks with unique layouts and obstacles
- **Checkpoint System**: Race through gates to progress and track your lap time
- **Leaderboard**: Compete for the best times and see rankings
- **Party System**: Create or join racing parties with simple code sharing
- **Mobile Support**: Optimized for desktop and mobile with touch controls
- **Car Customization**: Choose from various car colors

## How to Play

### Creating a Game

1. Visit the Racez.io website
2. Enter your name
3. Choose your car color
4. Click "Create Party"
5. Share the generated party code with friends
6. Select a track from the dropdown menu
7. Click "Start Race" when everyone is ready

### Joining a Game

1. Visit the Racez.io website
2. Enter your name
3. Choose your car color
4. Enter the party code provided by the host
5. Click "Join Party"
6. Wait for the host to start the race

## Controls

### Desktop
- **W**: Accelerate
- **S**: Brake/Reverse
- **A**: Turn left
- **D**: Turn right
- **R**: Reset car to last checkpoint

### Mobile
- **Virtual Joystick**: Steer the car (left side of screen)
- **Joystick Up**: Accelerate
- **Joystick Down**: Brake/Reverse
- **Joystick Left/Right**: Turn

## 🧰 Technologies Used

- **Three.js**: 3D rendering engine
- **Ammo.js**: Physics engine (WebAssembly port of Bullet Physics)
- **PeerJS**: WebRTC peer-to-peer connections
- **JavaScript**: Core programming language
- **HTML5/CSS3**: Frontend structure and styling
- **Python/Django**: Backend server for matchmaking and party code management

## ⚙️ Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Required environment variables (the server will refuse to start without them):

| Variable | Description |
|---|---|
| `SECRET_KEY` | Django secret key. Generate with `python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"` |
| `DEBUG` | Set to `True` only for local development |
| `ALLOWED_HOSTS` | Comma-separated list of allowed hostnames |
| `CORS_ALLOWED_ORIGINS` | Comma-separated list of frontend origins |

The SQLite database (`db.sqlite3`) and the virtualenv are not tracked in git - they are created locally / by `build.sh`.
