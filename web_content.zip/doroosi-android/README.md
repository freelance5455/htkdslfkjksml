# دروسي PRO — مشروع Android (Capacitor)

معرّف الحزمة: `com.doroosi.pro` — الاسم: «دروسي PRO». **لا تغيّر المعرّف بعد النشر.**
الملف الأصلي محفوظ في `docs/`، والنسخة المعدّلة في `www/index.html`.

## ملاحظة صريحة
مجلد `android/` غير موجود في هذا التسليم لأن إنشاءه يحتاج `npm install` (إنترنت) وكان معطّلًا. لم يُبنَ APK ولم يُختبر على هاتف.

## المتطلبات
Node 20+ (جُرّب 22)، JDK 21، Android Studio حديث مع Android SDK.

## البناء (مرة واحدة)
```
npm install
npx cap add android
npx cap sync android
npx cap open android      # أو:
cd android && ./gradlew assembleDebug
```
الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`

بعد أي تعديل على `www/`: `npx cap sync android` ثم أعد البناء.

## نسخة Release والتوقيع
1. أنشئ مفتاحًا (احتفظ به وبكلمة مروره خارج المشروع، وبنسخة احتياطية):
   `keytool -genkey -v -keystore doroosi.jks -alias doroosi -keyalg RSA -keysize 2048 -validity 10000`
2. في Android Studio: Build > Generate Signed Bundle / APK، واختر APK.
3. استخدم **نفس المفتاح ونفس المعرّف** في كل تحديث، وزد `versionCode` في `android/app/build.gradle`.
لا تضع ملف `.jks` أو كلمة المرور داخل المشروع المُسلَّم.

## نقل بياناتك القديمة (مهم)
بيانات المتصفح أو ملف HTML **لا تنتقل تلقائيًا** (أصل تخزين مختلف).
1. في النسخة القديمة: النسخ الاحتياطي > «تصدير نسخة JSON».
2. انقل الملف للهاتف.
3. في التطبيق: النسخ الاحتياطي > «استيراد نسخة احتياطية». التطبيق يأخذ لقطة قبل الاستيراد.

## تحديث التطبيق دون فقد البيانات
- ثبّت `server.androidScheme` على `https` ولا تغيّره (تغييره يغيّر أصل التخزين).
- ثبّت `appId` ومفتاح التوقيع، وثبّت فوق النسخة القديمة (لا تحذفها).
- قبل كل تحديث: صدّر نسخة JSON.
- لا تستخدم «مسح بيانات التطبيق» من إعدادات أندرويد؛ يمسح كل شيء.
