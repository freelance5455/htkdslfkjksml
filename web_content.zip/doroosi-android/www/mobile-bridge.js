/* Doroosi PRO — Android bridge (classic script, no bundler needed).
   Uses Capacitor plugins through window.Capacitor.Plugins. Does nothing in a normal browser. */
(function(){
 var C=window.Capacitor;
 if(!C||typeof C.isNativePlatform!=='function'||!C.isNativePlatform())return;
 var P=C.Plugins||{};

 function blobToBase64(blob){return new Promise(function(res,rej){
  var r=new FileReader();
  r.onload=function(){var s=String(r.result||'');res(s.slice(s.indexOf(',')+1))};
  r.onerror=function(){rej(new Error('تعذرت قراءة الملف'))};
  r.readAsDataURL(blob)})}

 /* Used by download(name,blob) in the app. Saves into app Documents, then opens the share sheet
    so the user can save to Downloads / Drive / WhatsApp. */
 window.doroosiNativeIO={
  saveBlob:async function(name,blob){
   if(!P.Filesystem)throw new Error('إضافة الملفات غير متاحة');
   var data=await blobToBase64(blob);
   var safe=String(name||'file').replace(/[\\\/:*?"<>|]/g,'_');
   var w=await P.Filesystem.writeFile({path:safe,data:data,directory:'CACHE'});
   if(P.Share){
    try{await P.Share.share({title:safe,url:w.uri,dialogTitle:'حفظ / مشاركة الملف'})}
    catch(e){if(!/cancel/i.test(String(e&&e.message)))throw e}
   }
   return true;
  }
 };

 /* window.print() does nothing inside Android WebView: say so instead of failing silently. */
 window.print=function(){
  alert('الطباعة المباشرة غير مدعومة داخل تطبيق Android.\nاستخدم «تصدير CSV» أو تنزيل التقرير ثم اطبعه من تطبيق آخر.');
 };

 /* Hardware back button: close top dialog -> close modal -> go to dashboard -> exit. */
 if(P.App&&P.App.addListener){
  P.App.addListener('backButton',function(){
   var dl=document.querySelectorAll('.dlg-back');
   if(dl.length){var b=dl[dl.length-1].querySelector('.dlg-act button');if(b){b.click();return}}
   var mr=document.getElementById('modalRoot');
   if(mr&&mr.querySelector('.scrim')){
    var f=document.getElementById('modalForm');
    if(f&&f.dataset.dirty==='1'&&!window.confirm('توجد تعديلات غير محفوظة. إغلاق النافذة؟'))return;
    if(typeof window.closeModal==='function')window.closeModal();else mr.innerHTML='';
    return;
   }
   var cur=document.querySelector('.page.active');
   if(cur&&cur.id!=='page-dashboard'&&typeof window.showPage==='function'){window.showPage('dashboard');return}
   if(P.App.exitApp)P.App.exitApp();
  });
 }
})();
