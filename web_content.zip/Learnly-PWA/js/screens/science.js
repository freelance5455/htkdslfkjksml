import { el, card, topicTile } from "../ui/widgets.js";
import { allScienceTopics, loadScienceTopic, loadTips, generateDefinitionsQuiz } from "../engines/contentLoader.js";
import { drawScienceDiagram } from "../ui/render.js";

function section(title, body) {
  const kids = [el("div", { class: "role-heading wrap" }, title)];
  if (Array.isArray(body)) body.forEach((item) => kids.push(el("div", { class: "wrap" }, "•  " + item)));
  else if (body) kids.push(el("div", { class: "wrap" }, String(body)));
  return el("div", { class: "card" }, kids);
}

// ==================== SCIENCE TOPIC LIST ====================
export async function Science(app) {
  const topics = await allScienceTopics();
  return {
    title: "🔬 Natural Sciences", bottomNavKey: "learn",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Grade 8 CAPS Natural Sciences — the four core strands, with code-generated diagrams."),
      ...topics.map((t) => topicTile(t.icon || "🔬", t.name, "Tap to open notes, key facts and a diagram.",
        () => app.showScienceTopic(t.id), () => app.showQuiz("science")))
    ]
  };
}

// ==================== SCIENCE TOPIC DETAIL ====================
export async function ScienceTopic(app, { topicId }) {
  const data = await loadScienceTopic(topicId);
  const name = data ? data.name : topicId;
  if (!data) return { title: `🔬 ${name}`, body: [el("div", { class: "wrap" }, "Content not found for this topic.")] };

  const body = [
    card("Quiz yourself", "Test your recall of key terms and facts from this strand.",
      [{ label: "DEFINITIONS QUIZ", onClick: () => app.showQuiz("science", topicId) }])
  ];
  if (data.diagram) {
    const c = el("canvas", { style: "display:block;margin:0 auto;" });
    body.push(el("div", { class: "card" }, c));
    requestAnimationFrame(() => drawScienceDiagram(c, data.diagram.type || data.diagram, 320, 220));
  }
  body.push(
    section("1️⃣ What is it?", data.what_is_it),
    section("2️⃣ Why it matters", data.why_it_matters),
    section("3️⃣ Key vocabulary", data.key_vocabulary),
    section("4️⃣ Core concept", data.core_concept),
    section("5️⃣ Key facts", data.key_facts),
    section("⚠️ Common misconceptions", data.common_misconceptions),
    section("✅ Quick test", data.quick_test)
  );

  return { title: `🔬 ${name}`, body };
}

// ==================== DEFINITIONS QUIZ ====================
export async function Quiz(app, { subject = "math", topicId = null } = {}) {
  const state = { subject, score: 0, asked: 0, current: null };
  const subjectSelect = el("select", {}, ["Mathematics", "Natural Sciences"].map((s) => el("option", { value: s }, s)));
  subjectSelect.value = subject === "science" ? "Natural Sciences" : "Mathematics";

  const scoreLabel = el("div", {});
  const questionLabel = el("div", { class: "wrap", style: "font-size:1.05rem;font-weight:700;" });
  const optionsWrap = el("div", { class: "btn-row", style: "flex-direction:column;" });
  const feedback = el("div", { class: "wrap" });

  function updateScore() { scoreLabel.textContent = `Score: ${state.score}/${state.asked}`; }

  async function nextQuestion() {
    optionsWrap.innerHTML = "";
    feedback.textContent = "";
    const q = await generateDefinitionsQuiz(state.subject);
    if (!q) { questionLabel.textContent = "Not enough vocabulary loaded for a quiz yet."; state.current = null; return; }
    state.current = q;
    questionLabel.textContent = `[${q.topic}]\n\n${q.question}`;
    q.options.forEach((opt) => {
      const b = el("button", { class: "btn-secondary", onClick: () => answer(opt, b) }, opt);
      optionsWrap.appendChild(b);
    });
    updateScore();
  }
  function answer(selected, btnEl) {
    if (!state.current) return;
    state.asked += 1;
    const correct = selected === state.current.answer;
    if (correct) { state.score += 1; feedback.textContent = `✓ Correct! ${selected}`; app.student.xp = (app.student.xp || 0) + 5; }
    else feedback.textContent = `✗ Not quite. Correct answer: ${state.current.answer}`;
    app.saveStudent();
    [...optionsWrap.children].forEach((b) => (b.disabled = true));
    updateScore();
  }
  subjectSelect.addEventListener("change", () => {
    state.subject = subjectSelect.value === "Natural Sciences" ? "science" : "math";
    state.score = 0; state.asked = 0;
    nextQuestion();
  });

  await nextQuestion();
  return {
    title: "🧠 Definitions Quiz",
    body: [
      el("label", { class: "field-label" }, "Subject"), subjectSelect,
      scoreLabel, questionLabel, optionsWrap, feedback,
      el("button", { class: "btn-secondary", onClick: () => nextQuestion() }, "NEXT QUESTION →")
    ]
  };
}

// ==================== TIPS & TRICKS LIBRARY ====================
export async function TipsTricks(app) {
  const data = await loadTips();
  const categories = data.categories || [];
  const listWrap = el("div", {});

  function renderCategories(onlyIndex) {
    listWrap.innerHTML = "";
    const shown = onlyIndex < 0 ? categories : [categories[onlyIndex]];
    shown.forEach((cat) => {
      listWrap.appendChild(el("div", { class: "section-eyebrow" }, `${cat.icon || "💡"} ${(cat.name || "").toUpperCase()}`));
      (cat.tricks || []).forEach((trick) => {
        listWrap.appendChild(el("div", { class: "card" }, [
          el("div", { class: "role-heading wrap" }, `⚡ ${trick.title}`),
          el("div", { class: "role-subtitle wrap" }, `When to use it: ${trick.when}`),
          el("div", { class: "wrap" }, `Example: ${trick.example}`),
          el("div", { class: "wrap" }, `Method: ${trick.method}`),
          el("div", { class: "role-subtitle wrap" }, `Why it works: ${trick.why}`)
        ]));
      });
    });
  }

  const selector = el("select", {}, [el("option", { value: "-1" }, "Show all"), ...categories.map((c, i) => el("option", { value: String(i) }, `${c.icon || "💡"} ${c.name}`))]);
  selector.addEventListener("change", () => renderCategories(parseInt(selector.value, 10)));
  renderCategories(-1);

  return {
    title: "💡 Tips & Tricks",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Fast methods for every core maths skill — each with WHY it works, not just the shortcut, so it actually sticks."),
      el("label", { class: "field-label" }, "Jump to category"), selector,
      listWrap
    ]
  };
}
