import { el, card, progressBar, showAlert } from "../ui/widgets.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { EconomyEngine } from "../engines/economyEngine.js";

export async function Achievements(app) {
  const ge = new GamificationEngine(app.student);
  const econ = new EconomyEngine(app.student);
  const [unlocked, total] = ge.progressSummary();

  const body = [
    card("Your Progress", `${unlocked} / ${total} achievements unlocked\n🪙 ${econ.balance()} credits • ⭐ ${app.student.xp ?? 0} XP • 🔥 ${app.student.streak ?? 0} day streak`),
    progressBar(unlocked, total, `${unlocked}/${total}`)
  ];
  ge.allWithStatus().forEach((a) => {
    const state = a.unlocked ? "" : " 🔒";
    body.push(el("div", { class: "card" }, [
      el("div", { class: "role-heading wrap", style: a.unlocked ? "" : "color:gray;" }, `${a.icon} ${a.name}${state}`),
      el("div", { class: "role-subtitle wrap" }, a.desc)
    ]));
  });

  return { title: "🏆 Achievements", bottomNavKey: "profile", body };
}

export async function Economy(app) {
  const econ = new EconomyEngine(app.student);
  const history = econ.history(25);

  const body = [
    card("Balance", `🪙 ${econ.balance()} credits`),
    el("div", { class: "section-eyebrow" }, "RECENT ACTIVITY")
  ];
  if (!history.length) body.push(card("No activity yet", "Complete a practice session to start earning credits."));
  history.forEach((tx) => {
    const sign = tx.amount >= 0 ? "+" : "";
    body.push(el("div", { class: "card" }, [
      el("div", { class: "wrap" }, `${sign}${tx.amount} 🪙  —  ${tx.reason}`),
      el("div", { class: "role-muted" }, `${(tx.timestamp || "").slice(0, 16).replace("T", " ")} • balance: ${tx.balance_after}`)
    ]));
  });
  body.push(el("button", { class: "btn-secondary", onClick: () => app.showDevModeGate() }, "🔧 DEV MODE (credit simulator)"));

  return { title: "🪙 Credits", bottomNavKey: "profile", body };
}

export async function DevMode(app) {
  const econ = new EconomyEngine(app.student);
  const balanceLabel = el("div", { class: "role-heading" }, `Current balance: 🪙 ${econ.balance()}`);
  function afterChange() { balanceLabel.textContent = `Current balance: 🪙 ${econ.balance()}`; app.saveStudent(); }

  const amountInput = el("input", { type: "number", min: "1", max: "100000", value: "50" });
  const setInput = el("input", { type: "number", min: "0", max: "1000000", value: String(econ.balance()) });
  const itemInput = el("input", { type: "text", placeholder: "Item name (e.g. 'Theme Unlock')" });
  const costInput = el("input", { type: "number", min: "1", max: "100000", value: "20" });

  return {
    title: "🔧 Dev Mode — Credit Simulator",
    body: [
      el("div", { class: "role-subtitle wrap" }, "⚠️ Development tool. Every action here is logged as a 'dev_adjustment' transaction, never a silent balance edit."),
      balanceLabel,
      el("label", { class: "field-label" }, "Amount"), amountInput,
      el("button", { class: "btn", onClick: () => { econ.devAdd(parseInt(amountInput.value, 10) || 0); afterChange(); } }, "➕ ADD CREDITS"),
      el("button", { class: "btn-secondary", onClick: () => { econ.devRemove(parseInt(amountInput.value, 10) || 0); afterChange(); } }, "➖ REMOVE CREDITS"),
      el("label", { class: "field-label" }, "Set exact balance"), setInput,
      el("button", { class: "btn", onClick: () => { econ.devSetBalance(parseInt(setInput.value, 10) || 0); afterChange(); } }, "🎯 SET BALANCE"),
      el("label", { class: "field-label" }, "Simulate purchase"), itemInput, costInput,
      el("button", { class: "btn", onClick: async () => {
        const ok = econ.devSimulatePurchase(itemInput.value.trim() || "Unnamed item", parseInt(costInput.value, 10) || 0);
        afterChange();
        if (!ok) await showAlert("Purchase Failed", "Insufficient balance for this simulated purchase.");
      } }, "🛒 SIMULATE PURCHASE"),
      el("button", { class: "btn-secondary", onClick: () => { econ.devReset(); afterChange(); } }, "🗑 RESET ECONOMY")
    ]
  };
}
