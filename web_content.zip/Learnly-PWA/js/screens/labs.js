import { el, card } from "../ui/widgets.js";
import { GeometryLabCanvas, MODES } from "../ui/geometryLabCanvas.js";
import { DataEngine } from "../engines/dataEngine.js";
import { ProbabilityEngine } from "../engines/probabilityEngine.js";
import { drawChart } from "../ui/render.js";
import { Stopwatch } from "../engines/timerEngine.js";
import { answersMatch } from "../engines/answerCheck.js";

// ==================== HUB ====================
export async function Labs(app) {
  return {
    title: "📐 Maths Labs", bottomNavKey: "learn",
    body: [
      card("📐 Geometry Drawer", "Draw triangles, rectangles, circles, angles and coordinate points — no images needed.", [{ label: "OPEN", onClick: () => app.showGeometryLab() }]),
      card("📊 Data Handling Lab", "Enter data, calculate mean/median/mode/range, and generate bar, pie, line and box charts.", [{ label: "OPEN", onClick: () => app.showDataLab() }]),
      card("🎲 Probability Lab", "Simulate dice, coins, spinners and cards — compare experimental vs theoretical probability.", [{ label: "OPEN", onClick: () => app.showProbabilityLab() }]),
      card("🧮 Mental Maths", "Fast calculation tricks with a timer, streaks and personal bests.", [{ label: "OPEN", onClick: () => app.showMental() }]),
      card("🧠 Definitions Quiz", "Multiple-choice quiz on key terms from Maths or Natural Sciences.", [{ label: "OPEN", onClick: () => app.showQuiz() }])
    ]
  };
}

// ==================== GEOMETRY DRAWER ====================
export async function GeometryLab(app) {
  const canvasEl = el("canvas");
  const wrap = el("div", { style: "width:100%;display:flex;justify-content:center;" }, canvasEl);
  const lab = new GeometryLabCanvas(canvasEl);

  const selector = el("select", {}, MODES.map((m) => el("option", { value: m }, m)));
  selector.value = "Triangle";
  selector.addEventListener("change", () => { lab.mode = selector.value; lab.clear(); });

  const measureBox = el("input", { type: "checkbox" }); measureBox.checked = true;
  measureBox.addEventListener("change", () => { lab.showMeasurements = measureBox.checked; lab.redraw(); });

  requestAnimationFrame(() => lab.redraw());

  return {
    title: "📐 Geometry Drawer",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Tap points on the grid to build a shape. No manual images needed — every diagram is drawn live."),
      selector, wrap,
      el("label", { class: "checkline" }, [measureBox, "📏 Show measurements"]),
      el("button", { class: "btn-secondary", onClick: () => lab.clear() }, "🗑 CLEAR"),
      el("div", { class: "role-muted wrap" }, "TIP: Triangle needs 3 taps, Rectangle & Circle need 2 taps (opposite corners / centre + edge), Angle needs 3 taps (vertex first), Coordinate Plane plots every tap.")
    ]
  };
}

// ==================== DATA HANDLING LAB ====================
export async function DataLab(app) {
  const de = new DataEngine();
  let rowCount = 10;
  const rowsInput = el("input", { type: "number", min: "3", max: "30", value: "10" });
  const rowsWrap = el("div", { class: "grid-2" });
  const statsLabel = el("div", { class: "wrap" });
  const outlierLabel = el("div", { class: "wrap" });
  const freqTable = el("div", {});
  const chartTypeSelect = el("select", {}, ["bar", "pie", "line", "box", "histogram"].map((t) => el("option", { value: t }, t)));
  const chartCanvas = el("canvas", { style: "display:block;margin:0 auto;" });

  function buildRows(n, preserve = []) {
    rowsWrap.innerHTML = "";
    for (let i = 0; i < n; i++) {
      const inp = el("input", { type: "number", placeholder: `#${i + 1}` });
      if (preserve[i] !== undefined) inp.value = preserve[i];
      rowsWrap.appendChild(inp);
    }
  }
  buildRows(rowCount);
  rowsInput.addEventListener("change", () => {
    const n = Math.max(3, Math.min(30, parseInt(rowsInput.value, 10) || 10));
    const preserve = [...rowsWrap.children].map((i) => i.value);
    rowCount = n;
    buildRows(n, preserve);
  });

  function getValues() { return [...rowsWrap.children].map((i) => parseFloat(i.value)).filter((v) => !Number.isNaN(v)); }

  function calculate() {
    const values = getValues();
    if (!values.length) {
      statsLabel.textContent = "Enter numbers in the table (or tap RANDOM DATA).";
      outlierLabel.textContent = "";
      freqTable.innerHTML = "";
      return;
    }
    const s = de.summary(values);
    const g = (n) => (Number.isInteger(n) ? n : Math.round(n * 100) / 100);
    statsLabel.textContent =
      `Count: ${s.count}   Sum: ${g(s.sum)}\nMean: ${g(s.mean)}   Median: ${g(s.median)}\n` +
      `Mode: ${s.mode.map(g).join(", ")}\nRange: ${g(s.range)}   Min: ${g(s.minimum)}   Max: ${g(s.maximum)}\n` +
      `Q1: ${g(s.q1)}   Q3: ${g(s.q3)}   IQR: ${g(s.iqr)}\n` +
      `Five-number summary: (${s.five_number_summary.map(g).join(", ")})`;
    outlierLabel.textContent = s.outliers.length ? `⚠️ Possible outliers (beyond 1.5×IQR): ${s.outliers.join(", ")}` : "No outliers detected (within 1.5×IQR of the quartiles).";

    const grouped = de.groupedFrequency(values, 5);
    freqTable.innerHTML = "";
    const t = el("table", { class: "datatable" }, [
      el("tr", {}, [el("th", {}, "Class Interval"), el("th", {}, "Frequency"), el("th", {}, "Cumulative Freq.")]),
      ...grouped.map((row) => el("tr", {}, [el("td", {}, row.class), el("td", {}, String(row.frequency)), el("td", {}, String(row.cumulative_frequency))]))
    ]);
    freqTable.appendChild(t);

    const labels = values.map((v) => (Number.isInteger(v) ? String(v) : String(v)));
    drawChart(chartCanvas, values, labels, chartTypeSelect.value, 320, 260);
  }
  chartTypeSelect.addEventListener("change", calculate);

  function randomFill() {
    const vals = de.randomDataset(rowCount, 1, 60);
    [...rowsWrap.children].forEach((inp, i) => (inp.value = vals[i]));
    calculate();
  }

  return {
    title: "📊 Data Handling Lab",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Enter values, calculate real statistics (mean/median/mode/range/quartiles/outliers), build a grouped frequency table, and generate graphs."),
      el("div", { class: "btn-row" }, [
        el("div", { style: "flex:1;" }, [el("label", { class: "field-label" }, "Rows"), rowsInput]),
        el("div", { style: "flex:1;display:flex;align-items:flex-end;" }, [el("button", { class: "btn-secondary", onClick: randomFill }, "🎲 RANDOM DATA")])
      ]),
      rowsWrap,
      el("button", { class: "btn", onClick: calculate }, "🧮 CALCULATE STATISTICS"),
      statsLabel, outlierLabel,
      el("div", { class: "section-eyebrow" }, "GROUPED FREQUENCY TABLE (class intervals)"),
      freqTable,
      el("label", { class: "field-label" }, "Graph type"), chartTypeSelect,
      chartCanvas
    ]
  };
}

// ==================== PROBABILITY LAB ====================
export async function ProbabilityLab(app) {
  const pe = new ProbabilityEngine();
  const simSelect = el("select", {}, ["Dice (1 die)", "Coin toss", "Spinner (8 sectors)", "Cards"].map((s) => el("option", { value: s }, s)));
  const trialsInput = el("input", { type: "number", min: "1", max: "500", value: "20" });
  const resultLabel = el("div", { class: "wrap" });
  const compareLabel = el("div", { class: "role-heading wrap" });
  const chartCanvas = el("canvas", { style: "display:block;margin:0 auto;" });

  function run() {
    const n = Math.max(1, Math.min(500, parseInt(trialsInput.value, 10) || 20));
    const sim = simSelect.value;
    let outcomes, labels, values, theoretical, favLabel, experimental;

    if (sim.startsWith("Dice")) {
      outcomes = pe.rollDie(6, n);
      const freq = {}; for (let i = 1; i <= 6; i++) freq[i] = outcomes.filter((x) => x === i).length;
      labels = ["1", "2", "3", "4", "5", "6"]; values = [1, 2, 3, 4, 5, 6].map((i) => freq[i]);
      theoretical = 1 / 6; favLabel = "rolling a 6"; experimental = freq[6] / n;
    } else if (sim.startsWith("Coin")) {
      outcomes = pe.flipCoin(n);
      const heads = outcomes.filter((x) => x === "Heads").length;
      labels = ["Heads", "Tails"]; values = [heads, n - heads];
      theoretical = 0.5; favLabel = "Heads"; experimental = heads / n;
    } else if (sim.startsWith("Spinner")) {
      outcomes = pe.spinSpinner(8, n);
      const freq = {}; for (let i = 1; i <= 8; i++) freq[i] = outcomes.filter((x) => x === i).length;
      labels = Array.from({ length: 8 }, (_, i) => String(i + 1)); values = labels.map((l) => freq[+l]);
      theoretical = 1 / 8; favLabel = "landing on 8"; experimental = freq[8] / n;
    } else {
      outcomes = []; let reds = 0;
      for (let i = 0; i < n; i++) { const c = pe.drawCard(1)[0]; outcomes.push(c); if (c.includes("♥") || c.includes("♦")) reds++; }
      labels = ["Red", "Black"]; values = [reds, n - reds];
      theoretical = 0.5; favLabel = "a red card"; experimental = reds / n;
    }

    resultLabel.textContent = `Outcomes (${n} trials): ${outcomes.slice(0, 30).join(", ")}${n > 30 ? " ..." : ""}`;
    compareLabel.textContent =
      `THEORETICAL P(${favLabel}) = ${theoretical.toFixed(3)}\nEXPERIMENTAL P(${favLabel}) = ${experimental.toFixed(3)}  (${n} trials)\nDifference: ${Math.abs(theoretical - experimental).toFixed(3)}`;
    drawChart(chartCanvas, values, labels, "bar", 320, 260);
  }

  return {
    title: "🎲 Probability Lab",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Run simulations and watch experimental probability approach theoretical probability."),
      el("label", { class: "field-label" }, "Simulation"), simSelect,
      el("label", { class: "field-label" }, "Trials"), trialsInput,
      el("button", { class: "btn", onClick: run }, "▶ RUN SIMULATION"),
      resultLabel, compareLabel, chartCanvas
    ]
  };
}

// ==================== MENTAL MATHS ====================
const TRICKS = [
  { skill: "×25 shortcut", gen: () => { const a = ri(4, 80); return [`${a} × 25`, a * 25, "×25 = ×100 ÷ 4"]; } },
  { skill: "×9 shortcut", gen: () => { const a = ri(2, 90); return [`${a} × 9`, a * 9, "×9 = ×10 − the original number"]; } },
  { skill: "×5 shortcut", gen: () => { const a = ri(2, 200); return [`${a} × 5`, a * 5, "×5 = ×10 ÷ 2"]; } },
  { skill: "10% of a number", gen: () => { const a = ri(10, 900); return [`10% of ${a}`, Math.round(a * 0.1 * 100) / 100, "10% = divide by 10"]; } },
  { skill: "Same-base exponents", gen: () => { const a = ri(2, 5), x = ri(1, 4), y = ri(1, 4); return [`${a}^${x} × ${a}^${y}`, `${a}^${x + y}`, "Add the exponents"]; } },
  { skill: "Doubling & halving", gen: () => { const a = ri(2, 60); return [`${a} × 50`, a * 50, "×50 = ×100 ÷ 2"]; } },
  { skill: "Percentages", gen: () => { const a = ri(8, 400); return [`25% of ${a}`, Math.round(a * 0.25 * 100) / 100, "25% = ÷4"]; } }
];
function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }

export async function Mental(app) {
  let streak = 0, best = app.student.mental_best_streak || 0, current = null;
  const sw = new Stopwatch();

  const streakLabel = el("div", {});
  const skillLabel = el("div", { class: "role-muted" });
  const questionEl = el("div", { style: "font-size:1.5rem;font-weight:800;" });
  const answerInput = el("input", { type: "text", placeholder: "Fast answer" });
  const resultEl = el("div", { class: "wrap" });
  const timeLabel = el("div", { class: "role-muted" });

  sw.onTick = (sec) => { timeLabel.textContent = `⏱ ${sec}s`; };
  function updateStreakLabel() { streakLabel.textContent = `🔥 Streak: ${streak}   🏆 Best: ${best}`; }

  function nextQ() {
    const trick = TRICKS[Math.floor(Math.random() * TRICKS.length)];
    const [q, a, tip] = trick.gen();
    current = { q, expected: String(a), tip, skill: trick.skill };
    skillLabel.textContent = `Skill: ${trick.skill}`;
    questionEl.textContent = q + " = ?";
    answerInput.value = "";
    resultEl.textContent = "";
    updateStreakLabel();
    setTimeout(() => answerInput.focus(), 30);
  }
  function check() {
    if (!current) return;
    const correct = answersMatch(answerInput.value.trim(), current.expected);
    if (correct) {
      streak += 1; best = Math.max(best, streak);
      app.student.mental_best_streak = best;
      app.student.xp = (app.student.xp || 0) + 5;
      resultEl.textContent = `✓ Correct! Fast method: ${current.tip}`;
    } else {
      streak = 0;
      resultEl.textContent = `✗ Answer: ${current.expected}\nFast method: ${current.tip}`;
    }
    app.saveStudent();
    updateStreakLabel();
    nextQ();
  }
  answerInput.addEventListener("keydown", (e) => { if (e.key === "Enter") check(); });

  nextQ();
  sw.start();

  return {
    title: "🧮 Mental Maths",
    body: [
      streakLabel, skillLabel, questionEl, answerInput,
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn", onClick: check }, "CHECK"),
        el("button", { class: "btn-secondary", onClick: () => nextQ() }, "SKIP")
      ]),
      resultEl, timeLabel
    ],
    onUnmount: () => sw.stop()
  };
}
