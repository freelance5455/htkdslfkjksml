import { el, card, showAlert } from "../ui/widgets.js";
import { PaperEngine, PAPER_TYPES, DIFFICULTY_MAP } from "../engines/paperEngine.js";
import { drawDiagram, exportPaperImage } from "../ui/render.js";

const pe = new PaperEngine();

export async function Papers(app) {
  const typeSelect = el("select", {}, PAPER_TYPES.map((t) => el("option", { value: t }, t)));
  const termSelect = el("select", {}, [1, 2, 3, 4].map((t) => el("option", { value: t }, `Term ${t}`)));
  termSelect.value = String(app.student.term || 1);
  const diffSelect = el("select", {}, Object.keys(DIFFICULTY_MAP).map((d) => el("option", { value: d }, d)));
  diffSelect.value = "Standard";
  const countInput = el("input", { type: "number", min: "5", max: "40", value: "15" });
  const timeInput = el("input", { type: "number", min: "10", max: "180", value: "45" });

  async function generate() {
    let paper;
    try {
      paper = pe.generate(app.student, {
        paperType: typeSelect.value, term: parseInt(termSelect.value, 10), difficulty: diffSelect.value,
        count: parseInt(countInput.value, 10) || 15, timeMinutes: parseInt(timeInput.value, 10) || 45
      });
    } catch (e) { return showAlert("Generation Error", String(e.message || e)); }
    app.saveStudent();
    await showAlert("Paper Generated",
      `✓ ${paper.type} — Term ${paper.term}\n\nID: ${paper.paper_id}\nMarks: ${paper.marks}\nQuestions: ${paper.questions.length}\n\nSaved to this device.`);
    app.showPaperViewer(paper.paper_id);
  }

  const library = pe.listPapers(app.student.code);
  const libraryCards = library.length
    ? library.slice(0, 10).map((p) => card(`${p.type} — Term ${p.term}`,
        `${p.marks} marks • ${p.questions.length} questions • ${(p.created_at || "").slice(0, 16).replace("T", " ")}`,
        [{ label: "VIEW PAPER", onClick: () => app.showPaperViewer(p.paper_id) }]))
    : [card("No papers yet", "Generate your first paper above.")];

  return {
    title: "📝 Question Papers", bottomNavKey: "papers",
    body: [
      el("label", { class: "field-label" }, "Paper type"), typeSelect,
      el("label", { class: "field-label" }, "Term"), termSelect,
      el("label", { class: "field-label" }, "Difficulty"), diffSelect,
      el("label", { class: "field-label" }, "Questions"), countInput,
      el("label", { class: "field-label" }, "Time limit (minutes)"), timeInput,
      el("button", { class: "btn", onClick: generate }, "📝 GENERATE PAPER"),
      el("div", { class: "section-eyebrow" }, "📂 PAPER LIBRARY"),
      ...libraryCards
    ]
  };
}

export async function PaperViewer(app, { paperId }) {
  const paper = pe.load(paperId);
  if (!paper) return { title: "📝 Paper Viewer", body: [el("div", { class: "wrap" }, "Paper not found.")] };

  let showingMemo = false;
  const questionsWrap = el("div", {});
  const memoBtn = el("button", { class: "btn", onClick: toggleMemo }, "VIEW MEMO");

  function renderQuestions() {
    questionsWrap.innerHTML = "";
    paper.questions.forEach((q) => {
      const kids = [
        el("div", { class: "role-heading wrap" }, `Q${q.number}. (${q.marks} marks) — ${q.topic_name}`),
        el("div", { class: "wrap" }, q.question)
      ];
      if (q.diagram) {
        const c = el("canvas", { style: "display:block;margin:0.4rem auto;" });
        kids.push(c);
        requestAnimationFrame(() => drawDiagram(c, q.diagram, 260, 180));
      }
      if (showingMemo) {
        kids.push(el("div", { class: "wrap" }, `✅ Answer: ${q.answer}`));
        kids.push(el("div", { class: "wrap" }, `Working: ${q.explanation}`));
        kids.push(el("div", { class: "wrap" }, `Technique: ${q.hint}`));
      }
      questionsWrap.appendChild(el("div", { class: "card" }, kids));
    });
  }
  function toggleMemo() { showingMemo = !showingMemo; memoBtn.textContent = showingMemo ? "HIDE MEMO" : "VIEW MEMO"; renderQuestions(); }
  renderQuestions();

  return {
    title: "📝 Paper Viewer",
    body: [
      card(`${paper.grade_label || "Grade 8"} Mathematics — ${paper.type}`,
        `Term ${paper.term} • ${paper.difficulty} • ${paper.marks} marks • ${paper.time_minutes || 45} min\n` +
        `Student: ${paper.student_code || ""} • Created: ${(paper.created_at || "").slice(0, 16).replace("T", " ")}`),
      el("div", { class: "btn-row" }, [memoBtn, el("button", { class: "btn-secondary", onClick: () => exportPaperImage(paper, showingMemo) }, "EXPORT AS IMAGE")]),
      questionsWrap
    ]
  };
}
