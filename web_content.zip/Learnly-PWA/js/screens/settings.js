import { el, card, showAlert, showConfirm } from "../ui/widgets.js";
import { GradeManager } from "../engines/gradeManager.js";
import { THEMES, FONT_SCALES } from "../theme.js";
import { exportStudent, importStudentText } from "../db.js";

export async function Settings(app) {
  const settings = app.student.settings = app.student.settings || {};
  const gm = app.gradeManager();

  const gradeList = GradeManager.allGrades();
  const gradeSelect = el("select", {}, gradeList.map(([num, name, phase]) => el("option", { value: num }, `${name}  (${phase})`)));
  gradeSelect.value = String(gm.grade);
  async function applyGrade() {
    const newGrade = parseInt(gradeSelect.value, 10);
    if (newGrade === (app.student.grade ?? 8)) return showAlert("No Change", "You're already on that grade.");
    const oldLabel = app.gradeManager().label();
    await app.changeGrade(newGrade);
    const newLabel = app.gradeManager().label();
    await showAlert("Grade Updated", `Switched from ${oldLabel} to ${newLabel}.\n\nLearn, Practice, and Question Papers now show only ${newLabel} topics and grade-appropriate numbers.`);
    app.showSettings();
  }

  const themeSelect = el("select", {}, THEMES.map((t) => el("option", { value: t }, t)));
  themeSelect.value = settings.theme || "Classic Elite";
  themeSelect.addEventListener("change", () => { settings.theme = themeSelect.value; app.applyThemeAndFont(); app.saveStudent(); });

  const fontSelect = el("select", {}, Object.keys(FONT_SCALES).map((f) => el("option", { value: f }, f)));
  fontSelect.value = settings.font_scale || "Normal";
  fontSelect.addEventListener("change", () => { settings.font_scale = fontSelect.value; app.applyThemeAndFont(); app.saveStudent(); });

  const hintsBox = check(settings.hints !== false);
  const soundBox = check(settings.sound !== false);
  const animBox = check(settings.animations !== false);
  const autoExplainBox = check(settings.show_solutions !== false);
  const confirmResetBox = check(settings.confirm_reset !== false);
  function check(v) { const c = el("input", { type: "checkbox" }); c.checked = v; c.addEventListener("change", savePrefs); return c; }
  function savePrefs() {
    settings.hints = hintsBox.checked; settings.sound = soundBox.checked; settings.animations = animBox.checked;
    settings.show_solutions = autoExplainBox.checked; settings.confirm_reset = confirmResetBox.checked;
    settings.difficulty_pref = diffSelect.value;
    app.saveStudent();
  }
  const diffSelect = el("select", {}, ["Foundation", "Standard", "Advanced", "Elite"].map((d) => el("option", { value: d }, d)));
  diffSelect.value = settings.difficulty_pref || "Standard";
  diffSelect.addEventListener("change", savePrefs);

  const goalInput = el("input", { type: "number", min: "5", max: "100", value: String(app.student.daily_goal ?? 20) });
  function saveGoal() { app.student.daily_goal = parseInt(goalInput.value, 10) || 20; app.saveStudent(); showAlert("Saved", "Daily goal updated."); }

  function exportData() { exportStudent(app.student); showAlert("Export complete", "Your Learnly backup has been downloaded."); }

  const fileInput = el("input", { type: "file", accept: "application/json", style: "display:none" });
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0]; if (!file) return;
    const text = await file.text();
    const result = importStudentText(text, app.student);
    if (!result.imported && result.reason === "older_or_same") {
      await showAlert("Import Skipped", "The imported profile is older than or the same age as your current data. Nothing was overwritten to protect your newer progress.");
    } else if (!result.imported) {
      await showAlert("Import Error", result.error || "Could not read that file.");
    } else {
      await showAlert("Import Complete", "Newer student data imported successfully.");
      app.showSettings();
    }
    fileInput.value = "";
  });
  function importData() { fileInput.click(); }

  async function resetData() {
    if (confirmResetBox.checked) {
      const ok = await showConfirm("Confirm Reset", "This will reset today's progress and streak. Mastery history is kept. Continue?");
      if (!ok) return;
    }
    app.student.today_done = 0;
    app.student.streak = 0;
    app.saveStudent();
    showAlert("Reset Complete", "Today's progress has been reset.");
  }

  return {
    title: "⚙ Settings",
    body: [
      el("div", { class: "section-eyebrow" }, "MY GRADE"), gradeSelect,
      el("div", { class: "role-subtitle wrap" }, "Changing your grade updates every topic and question you see everywhere in Learnly, so you're never shown content above or below your level."),
      el("button", { class: "btn", onClick: applyGrade }, "✅ APPLY GRADE CHANGE"),

      el("div", { class: "section-eyebrow" }, "DISPLAY — THEME"), themeSelect,
      el("div", { class: "section-eyebrow" }, "DISPLAY — FONT SIZE"), fontSelect,

      el("div", { class: "section-eyebrow" }, "LEARNING PREFERENCES"),
      el("label", { class: "checkline" }, [hintsBox, "💡 Smart hints during practice"]),
      el("label", { class: "checkline" }, [soundBox, "🔊 Sound effects"]),
      el("label", { class: "checkline" }, [animBox, "✨ Animations"]),
      el("label", { class: "checkline" }, [autoExplainBox, "📖 Auto-show explanations after answering"]),
      el("label", { class: "checkline" }, [confirmResetBox, "⚠️ Confirm before resetting data"]),

      el("div", { class: "section-eyebrow" }, "DIFFICULTY PREFERENCE"), diffSelect,

      el("div", { class: "section-eyebrow" }, "DAILY GOAL (problems)"), goalInput,
      el("button", { class: "btn", onClick: saveGoal }, "💾 SAVE DAILY GOAL"),

      el("div", { class: "section-eyebrow" }, "DATA"),
      card("📤 Export Student Data", "Save a portable JSON backup of your profile.", [{ label: "EXPORT", onClick: exportData }]),
      card("📥 Import Student Data", "Load a profile export (newer data always wins).", [{ label: "IMPORT", onClick: importData }]),
      fileInput,
      card("🗑 Reset Local Data", "Clear today's progress and history for this profile.", [{ label: "RESET", onClick: resetData }]),

      el("div", { class: "section-eyebrow" }, "ABOUT"),
      card("Learnly — " + gm.label() + " Mathematics",
        "CAPS-aligned. Adaptive local logic, no online AI required.\nCurriculum content should be verified against the current DBE ATP before formal school use."),

      el("button", { class: "btn-secondary", onClick: () => app.showTutorGate() }, "🔐 TUTOR MODE")
    ]
  };
}
