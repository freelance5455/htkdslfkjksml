import { el, card, masteryBar, showAlert } from "../ui/widgets.js";
import { GradeManager } from "../engines/gradeManager.js";
import { PaperEngine, DIFFICULTY_MAP } from "../engines/paperEngine.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";

const pe = new PaperEngine();
function titleCase(s) { return s.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()); }

// ==================== TUTOR DASHBOARD ====================
export async function Tutor(app) {
  const s = app.student;
  const mastery = s.mastery || {};
  const vals = Object.values(mastery);
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;

  const searchInput = el("input", { type: "text", placeholder: "Enter student code, e.g. S01" });
  function search() {
    const code = searchInput.value.trim().toUpperCase();
    if (!code) return showAlert("Enter a code", "Please enter a student code to search.");
    const found = app.loadStudentByCode(code);
    if (!found) return showAlert("Not found", `No student found with code '${code}'.`);
    app.showTutorStudentProfile(code);
  }
  searchInput.addEventListener("keydown", (e) => { if (e.key === "Enter") search(); });

  function quickPaper(paperType) {
    const paper = pe.generate(app.student, { paperType, count: 15 });
    app.saveStudent();
    app.showPaperViewer(paper.paper_id);
  }

  return {
    title: "🔐 Tutor Mode",
    body: [
      card("👨‍🏫 Tutor Dashboard", `Current student: ${s.code || ""} • Term ${s.term ?? 1}`),
      card("📊 Student Analytics",
        `Overall mastery: ${Math.round(avg * 100)}%\nWeaknesses: ${(s.weaknesses || []).join(", ") || "None"}\n` +
        `Strengths: ${(s.strengths || []).join(", ") || "None"}\nXP: ${s.xp ?? 0} • Streak: ${s.streak ?? 0} days`),
      el("div", { class: "section-eyebrow" }, "🔍 STUDENT MANAGEMENT — search by code"),
      el("div", { class: "btn-row" }, [searchInput, el("button", { class: "btn", style: "width:auto;flex:none;padding:0 1rem;", onClick: search }, "SEARCH")]),
      card("📝 Generate Weakness Paper", "Create a targeted recovery paper for the current student.", [{ label: "GENERATE", onClick: () => quickPaper("Weakness Recovery") }]),
      card("🔥 Generate Strength Paper", "Push the current student's strongest topics.", [{ label: "GENERATE", onClick: () => quickPaper("Strength Challenge") }]),
      card("📚 Mock Exam", "Full term-aligned mock exam for the current student.", [{ label: "GENERATE", onClick: () => quickPaper("Mock Exam") }]),
      card("🔄 Import / Export", "Timestamp-safe student data transfer.", [{ label: "OPEN SETTINGS", onClick: () => app.showSettings() }]),
      card("🏢 Programme Mode", "Manage tutors, groups, schedules and programme-wide analytics.", [{ label: "OPEN PROGRAMME MODE", onClick: () => app.showProgrammeGate() }])
    ]
  };
}

// ==================== READ-ONLY STUDENT LOOKUP ====================
export async function TutorStudentProfile(app, { code }) {
  const student = app.loadStudentByCode(code);
  if (!student) return { title: `👤 Student: ${code}`, body: [el("div", { class: "wrap" }, `No student found with code '${code}'.`)] };

  const gm = new GradeManager(student.grade ?? 8);
  const mastery = student.mastery || {};
  const vals = Object.values(mastery);
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  const econ = new EconomyEngine(student);
  const gam = new GamificationEngine(student);
  const [unlocked, total] = gam.progressSummary();
  const history = student.history || [];
  const correctQ = history.filter((h) => h.correct).length;
  const accuracy = history.length ? (correctQ / history.length) * 100 : 0;

  return {
    title: `👤 Student: ${code}`,
    body: [
      card(student.name || code, `Code: ${student.code || code} • ${gm.label()} • ${gm.phase()}`),
      card("📊 Overview",
        `Overall mastery: ${Math.round(avg * 100)}%\nXP: ${student.xp ?? 0} • Level: ${student.level ?? 1} • 🔥 ${student.streak ?? 0} day streak\n` +
        `🪙 ${econ.balance()} credits • 🏆 ${unlocked}/${total} achievements\nDaily goal: ${student.today_done ?? 0}/${student.daily_goal ?? 20}`),
      card("🔴 Weaknesses", (student.weaknesses || []).map(titleCase).join(", ") || "None recorded"),
      card("🟢 Strengths", (student.strengths || []).map(titleCase).join(", ") || "None recorded"),
      el("div", { class: "section-eyebrow" }, "MASTERY BY TOPIC"),
      ...Object.entries(mastery).sort((a, b) => b[1] - a[1]).map(([t, v]) => masteryBar(titleCase(t), v)),
      card("📈 Question History", `${history.length} questions attempted • ${correctQ} correct • ${Math.round(accuracy)}% accuracy`),
      el("button", { class: "btn", onClick: () => app.showTutorTestCenter(code) }, "📝 GENERATE TEST FOR THIS STUDENT"),
      el("button", { class: "btn-secondary", onClick: () => app.showTutor() }, "← BACK TO TUTOR MODE")
    ]
  };
}

// ==================== SINGLE-STUDENT TEST CENTER ====================
export async function TutorTestCenter(app, { code }) {
  const student = app.loadStudentByCode(code);
  if (!student) return { title: `📝 Test Center — ${code}`, body: [el("div", { class: "wrap" }, `No student found with code '${code}'.`)] };

  const gm = new GradeManager(student.grade ?? 8);
  const selectedTopics = new Set();
  const topicList = el("div", { class: "topic-list" }, gm.topics().map((t) => {
    const cb = el("input", { type: "checkbox" });
    cb.addEventListener("change", () => { cb.checked ? selectedTopics.add(t.id) : selectedTopics.delete(t.id); });
    return el("label", { class: "topic-check" }, [cb, `${t.icon || "📘"} ${t.name}`]);
  }));
  const diffSelect = el("select", {}, Object.keys(DIFFICULTY_MAP).map((d) => el("option", { value: d }, d)));
  diffSelect.value = "Standard";
  const countInput = el("input", { type: "number", min: "5", max: "40", value: "15" });
  const timeInput = el("input", { type: "number", min: "10", max: "180", value: "45" });

  async function generate() {
    const topics = [...selectedTopics];
    let paper;
    try {
      paper = pe.generate(student, {
        paperType: topics.length ? "Custom Topic Paper" : "Diagnostic", topics: topics.length ? topics : null,
        difficulty: diffSelect.value, count: parseInt(countInput.value, 10) || 15, timeMinutes: parseInt(timeInput.value, 10) || 45
      });
    } catch (e) { return showAlert("Generation Error", String(e.message || e)); }
    app.saveStudentByCode(student);
    await showAlert("Test Generated", `✓ Test created for ${student.name || code}\n\nMarks: ${paper.marks} • Questions: ${paper.questions.length}`);
    app.showPaperViewer(paper.paper_id);
  }

  return {
    title: `📝 Test Center — ${code}`,
    body: [
      el("div", { class: "role-subtitle wrap" }, `Building a test for ${student.name || code} — ${gm.label()}. Topics and numbers are matched to their grade.`),
      el("label", { class: "field-label" }, "Topics (leave none selected to use all)"), topicList,
      el("label", { class: "field-label" }, "Difficulty"), diffSelect,
      el("label", { class: "field-label" }, "Questions"), countInput,
      el("label", { class: "field-label" }, "Time limit (minutes)"), timeInput,
      el("button", { class: "btn", onClick: generate }, "📝 GENERATE TEST")
    ]
  };
}
