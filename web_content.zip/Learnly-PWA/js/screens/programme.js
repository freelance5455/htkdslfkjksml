import { el, card, showConfirm } from "../ui/widgets.js";
import { ProgrammeEngine } from "../engines/programmeEngine.js";
import { GradeManager } from "../engines/gradeManager.js";

const pe = new ProgrammeEngine();
const WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

// ==================== DASHBOARD ====================
export async function ProgrammeHome(app) {
  const stats = pe.dashboardStats();
  const body = [
    card(stats.programme_name,
      `👨‍🏫 ${stats.tutor_count} Tutors  •  🎓 ${stats.student_count} Students  •  👥 ${stats.group_count} Groups\n` +
      `📊 ${Math.round(stats.avg_mastery * 100)}% average mastery across the programme`),
    card("👨‍🏫 Tutors", "Add tutors, assign subjects & grades, view workload.", [{ label: "MANAGE TUTORS", onClick: () => app.showProgrammeTutors() }]),
    card("👥 Groups", "Create groups, set a schedule, enrol students.", [{ label: "MANAGE GROUPS", onClick: () => app.showProgrammeGroups() }]),
    el("div", { class: "section-eyebrow" }, "📅 TODAY'S SESSIONS")
  ];
  if (!stats.sessions_today.length) body.push(card("No sessions scheduled today", ""));
  stats.sessions_today.forEach((s) => body.push(card(`${s.time} — ${s.group}`, `Grade ${s.grade} ${s.subject}`)));

  body.push(el("div", { class: "section-eyebrow" }, "⚠️ NEEDS ATTENTION"));
  if (!stats.attention.length) body.push(card("No students currently flagged", "Everyone enrolled is at or above 50% average mastery."));
  stats.attention.slice(0, 8).forEach((a) => body.push(card(`${a.name} (${a.code})`,
    `Grade ${a.grade} • ${Math.round(a.avg_mastery * 100)}% average mastery`,
    [{ label: "VIEW PROFILE", onClick: () => app.showTutorStudentProfile(a.code) }])));

  return { title: "🏢 Programme Mode", body };
}

// ==================== TUTORS ====================
export async function ProgrammeTutors(app) {
  const nameInput = el("input", { type: "text", placeholder: "Tutor's name" });
  const selectedGrades = new Set();
  const gradeList = el("div", { class: "topic-list", style: "max-height:11rem;" }, GradeManager.allGrades().map(([num, name, phase]) => {
    const cb = el("input", { type: "checkbox" });
    cb.addEventListener("change", () => { cb.checked ? selectedGrades.add(num) : selectedGrades.delete(num); });
    return el("label", { class: "topic-check" }, [cb, `${name} (${phase})`]);
  }));
  function addTutor() {
    const name = nameInput.value.trim();
    if (!name) return;
    pe.addTutor(name, ["Mathematics"], [...selectedGrades]);
    app.showProgrammeTutors();
  }

  const body = [
    el("div", { class: "section-eyebrow" }, "ADD A TUTOR"), nameInput,
    el("label", { class: "field-label" }, "Grades they teach"), gradeList,
    el("button", { class: "btn", onClick: addTutor }, "➕ ADD TUTOR"),
    el("div", { class: "section-eyebrow" }, "ALL TUTORS")
  ];
  pe.listTutors().forEach((t) => {
    const workload = pe.tutorWorkload(t.id);
    const status = t.active === false ? " (inactive)" : "";
    const gradesStr = (t.grades || []).join(", ") || "any";
    body.push(card(`${t.name}${status}`, `Grades: ${gradesStr}  •  ${workload.groups} groups, ${workload.students} students`, [
      { label: "VIEW GROUPS", onClick: () => app.showProgrammeGroups(t.id), secondary: true },
      { label: t.active === false ? "REACTIVATE" : "DEACTIVATE", onClick: () => { t.active === false ? pe.reactivateTutor(t.id) : pe.deactivateTutor(t.id); app.showProgrammeTutors(); } }
    ]));
  });

  return { title: "👨‍🏫 Tutors", body };
}

// ==================== GROUPS ====================
export async function ProgrammeGroups(app, { tutorId = null } = {}) {
  const tutors = pe.listTutors(true);
  if (!tutors.length) {
    return { title: "👥 Groups", body: [card("No tutors yet", "Add a tutor first before creating a group.", [{ label: "ADD A TUTOR", onClick: () => app.showProgrammeTutors() }])] };
  }

  const sub = tutorId ? `Showing groups for ${(pe.getTutor(tutorId) || {}).name || tutorId}` : "All groups across the programme.";

  const nameInput = el("input", { type: "text", placeholder: "Group name, e.g. Grade 8 Maths A" });
  const gradeSelect = el("select", {}, GradeManager.allGrades().map(([num, name, phase]) => el("option", { value: num }, `${name} (${phase})`)));
  gradeSelect.selectedIndex = Math.min(8, gradeSelect.options.length - 1);
  const tutorSelect = el("select", {}, tutors.map((t) => el("option", { value: t.id }, t.name)));
  if (tutorId) tutorSelect.value = tutorId;
  const daySelect = el("select", {}, WEEKDAYS.map((d) => el("option", { value: d }, d)));
  const timeInput = el("input", { type: "text", placeholder: "17:00", value: "17:00" });

  function createGroup() {
    const name = nameInput.value.trim();
    if (!name) return;
    pe.addGroup(name, parseInt(gradeSelect.value, 10), "Mathematics", tutorSelect.value, [{ day: daySelect.value, time: timeInput.value.trim() || "17:00" }]);
    app.showProgrammeGroups(tutorId);
  }

  const body = [
    el("div", { class: "role-subtitle wrap" }, sub),
    el("div", { class: "section-eyebrow" }, "CREATE A GROUP"), nameInput, gradeSelect, tutorSelect,
    el("div", { class: "btn-row" }, [daySelect, timeInput]),
    el("button", { class: "btn", onClick: createGroup }, "➕ CREATE GROUP"),
    el("div", { class: "section-eyebrow" }, "GROUPS")
  ];
  const groups = pe.listGroups(tutorId);
  if (!groups.length) body.push(card("No groups yet", "Create one above."));
  groups.forEach((g) => {
    const tutor = pe.getTutor(g.tutor_id);
    const scheduleStr = (g.schedule || []).map((s) => `${s.day} ${s.time}`).join(", ") || "No schedule set";
    body.push(card(g.name, `Grade ${g.grade} ${g.subject} • Tutor: ${tutor ? tutor.name : "Unassigned"}\n${g.students.length} students • ${scheduleStr}`,
      [{ label: "OPEN GROUP", onClick: () => app.showProgrammeGroupDetail(g.id) }]));
  });

  return { title: "👥 Groups", body };
}

// ==================== GROUP DETAIL ====================
export async function ProgrammeGroupDetail(app, { groupId }) {
  const group = pe.getGroup(groupId);
  if (!group) return { title: "👥 Group", body: [el("div", { class: "wrap" }, "This group no longer exists.")] };

  const tutor = pe.getTutor(group.tutor_id);
  const scheduleStr = (group.schedule || []).map((s) => `${s.day} ${s.time}`).join(", ") || "No schedule set";
  const codeInput = el("input", { type: "text", placeholder: "Student code, e.g. S01" });
  function enrol() { const code = codeInput.value.trim(); if (!code) return; pe.enrolStudent(groupId, code); app.showProgrammeGroupDetail(groupId); }
  codeInput.addEventListener("keydown", (e) => { if (e.key === "Enter") enrol(); });
  function remove(code) { pe.removeStudent(groupId, code); app.showProgrammeGroupDetail(groupId); }
  async function deleteGroup() {
    const ok = await showConfirm("Delete Group", "This removes the group and its schedule. Student profiles themselves are not affected. Continue?");
    if (ok) { pe.deleteGroup(groupId); app.showProgrammeGroups(); }
  }

  const body = [
    card(`Grade ${group.grade} ${group.subject}`, `Tutor: ${tutor ? tutor.name : "Unassigned"}\nSchedule: ${scheduleStr}`),
    el("div", { class: "section-eyebrow" }, "ENROL A STUDENT"),
    el("div", { class: "btn-row" }, [codeInput, el("button", { class: "btn", style: "width:auto;flex:none;padding:0 1rem;", onClick: enrol }, "ENROL")]),
    el("div", { class: "section-eyebrow" }, `ROSTER (${group.students.length} students)`)
  ];
  const roster = pe.groupRoster(groupId);
  if (!roster.length) body.push(card("No students enrolled yet", ""));
  roster.forEach((r) => {
    if (!r.found) { body.push(card(`${r.code} — profile not found`, "This student code hasn't logged into Learnly yet.", [{ label: "REMOVE", onClick: () => remove(r.code) }])); return; }
    body.push(card(`${r.name} (${r.code})`, `Grade ${r.grade} • ${Math.round(r.avg_mastery * 100)}% mastery • ⭐ ${r.xp} XP • 🔥 ${r.streak} day streak`, [
      { label: "VIEW PROFILE", onClick: () => app.showTutorStudentProfile(r.code), secondary: true },
      { label: "REMOVE", onClick: () => remove(r.code) }
    ]));
  });
  body.push(el("button", { class: "btn-secondary", onClick: deleteGroup }, "🗑 DELETE THIS GROUP"));

  return { title: `👥 ${group.name}`, body };
}
