import { el, card, topicTile } from "../ui/widgets.js";
import { allTopics, loadTopicNotes, loadTips } from "../engines/contentLoader.js";

function section(title, body) {
  const kids = [el("div", { class: "role-heading wrap" }, title)];
  if (Array.isArray(body)) body.forEach((item) => kids.push(el("div", { class: "wrap" }, "•  " + item)));
  else if (body) kids.push(el("div", { class: "wrap" }, String(body)));
  return el("div", { class: "card" }, kids);
}

// ---------------- Learn (topic list) ----------------
export async function Learn(app) {
  const gm = app.gradeManager();
  const body = [el("div", { class: "role-subtitle wrap" },
    `${gm.phase()} • Deep notes, guides and worked examples, matched to ${gm.label()} only.`)];

  if (gm.grade === 8) {
    const topics = await allTopics();
    const byTerm = { 1: [], 2: [], 3: [], 4: [] };
    topics.forEach((t) => (byTerm[t.term || 1] = byTerm[t.term || 1] || []).push(t));
    [1, 2, 3, 4].forEach((term) => {
      if (!byTerm[term] || !byTerm[term].length) return;
      body.push(el("div", { class: "section-eyebrow" }, `TERM ${term}`));
      byTerm[term].forEach((t) => body.push(topicTile(t.icon || "📘", t.name, "Tap to open the full learning module.",
        () => app.showTopicDetail(t.id), () => app.showPractice("choose", [t.id]))));
    });
  } else {
    gm.topics().forEach((t) => body.push(topicTile(t.icon || "📘", t.name, "Tap to open notes and relevant tips.",
      () => app.showTopicDetail(t.id), () => app.showPractice("choose", [t.id]))));
  }

  return { title: `📚 Learn — ${gm.label()}`, bottomNavKey: "learn", body };
}

// ---------------- Topic Detail: Grade 8 full 19-part notes ----------------
export async function TopicDetail(app, { topicId }) {
  const topics = await allTopics();
  const meta = topics.find((t) => t.id === topicId) || { name: topicId, icon: "📘" };
  const notes = await loadTopicNotes(topicId);

  if (!notes) {
    return { title: `${meta.icon} ${meta.name}`, body: [card("Content not found",
      "This topic's notes file could not be loaded. Check that the content/grade8/topics/ folder is present alongside the app.")] };
  }

  const mastery = app.student.mastery?.[topicId] ?? 0.5;
  const body = [
    card("Your Mastery", `${Math.round(mastery * 100)}% on ${meta.name}`, [
      { label: "PRACTICE THIS TOPIC", onClick: () => app.showPractice("choose", [topicId]) },
      { label: "QUIZ DEFINITIONS", onClick: () => app.showQuiz("math", topicId), secondary: true }
    ]),
    section("1️⃣ What is it?", notes.what_is_it),
    section("2️⃣ Why it matters", notes.why_it_matters),
    section("3️⃣ Key vocabulary", notes.key_vocabulary),
    section("4️⃣ Core concept", notes.core_concept),
    section("5️⃣ Rules", notes.rules),
    section("6️⃣ Formulae", notes.formulae),
    section("7️⃣ Step-by-step method", notes.step_by_step_method)
  ];
  if (notes.worked_example_1) body.push(section("8️⃣ Worked example 1", `Q: ${notes.worked_example_1.question || ""}\n\n${notes.worked_example_1.solution || ""}`));
  if (notes.worked_example_2) body.push(section("9️⃣ Worked example 2", `Q: ${notes.worked_example_2.question || ""}\n\n${notes.worked_example_2.solution || ""}`));
  body.push(
    section("⚡ Fast method", notes.fast_method),
    section("🧠 Why the fast method works", notes.why_fast_method_works),
    section("⚠️ Common mistakes", notes.common_mistakes),
    section("💡 Memory trick", notes.memory_trick),
    section("👁 Visual explanation", notes.visual_explanation),
    section("🧭 Guided example", notes.guided_example),
    section("✏️ Practice questions", notes.practice_questions),
    section("🏆 Challenge question", notes.challenge_question),
    section("✅ Quick test", notes.quick_test),
    section("🎓 Mastery check", notes.mastery_check),
    el("button", { class: "btn", onClick: () => app.showPractice("choose", [topicId]) }, "✏️ PRACTICE THIS TOPIC NOW")
  );

  return { title: `${meta.icon} ${meta.name}`, body };
}

// ---------------- Topic Detail Lite: Grade R-7 and Grade 9 ----------------
const TOPIC_TO_TIPS_CATEGORY = {
  add_sub_20: "addition", add_sub_99: "addition", add_sub_999: "addition",
  numbers_20: "addition", numbers_99: "subtraction", numbers_999: "addition",
  whole_numbers_4: "addition", whole_numbers_5: "addition", whole_numbers_6: "addition",
  repeated_add: "multiplication", mult_tables: "multiplication", mult_div_4: "multiplication",
  division_intro: "division",
  fractions_intro: "fractions", common_fractions_4: "fractions",
  common_fractions_5: "fractions", decimal_fractions_5: "fractions", fractions_6: "fractions",
  percentages_6: "percentages", ratio_6: "fractions",
  shapes_r: "geometry", shapes_1: "geometry", shapes_2: "geometry",
  geometry_4: "geometry", geometry_5: "geometry", geometry_6: "geometry",
  data_5: "addition", data_6: "addition"
};

export async function TopicDetailLite(app, { topicId }) {
  const gm = app.gradeManager();
  gm.verifyTopic(topicId);
  const meta = gm.topics().find((t) => t.id === topicId) || { id: topicId, name: topicId.replaceAll("_", " "), icon: "📘" };
  const mastery = app.student.mastery?.[topicId] ?? 0.5;
  const [lo, hi] = gm.numberRange();

  const body = [
    card(`${gm.label()} • Your Mastery`, `${Math.round(mastery * 100)}% on ${meta.name}`,
      [{ label: "PRACTICE THIS TOPIC", onClick: () => app.showPractice("choose", [topicId]) }]),
    card("About this topic",
      `This is a ${gm.phase()} topic for ${gm.label()}. Questions here stay within the CAPS-appropriate number range for ${gm.label()} (${lo} to ${hi}), so you'll never see numbers too easy or too hard for your grade.`)
  ];

  const categoryId = TOPIC_TO_TIPS_CATEGORY[topicId];
  if (categoryId) {
    const tipsData = await loadTips();
    const category = (tipsData.categories || []).find((c) => c.id === categoryId);
    if (category) {
      body.push(el("div", { class: "role-heading wrap" }, `${category.icon || "💡"} RELEVANT TIPS & TRICKS`));
      (category.tricks || []).slice(0, 3).forEach((trick) => {
        body.push(card(`⚡ ${trick.title}`, `Example: ${trick.example}\nMethod: ${trick.method}`));
      });
    }
  }

  body.push(el("button", { class: "btn", onClick: () => app.showPractice("choose", [topicId]) }, "✏️ PRACTICE THIS TOPIC NOW"));
  body.push(el("button", { class: "btn-secondary", onClick: () => app.showTipsTricks() }, "💡 OPEN FULL TIPS & TRICKS LIBRARY"));

  return { title: `${meta.icon || "📘"} ${meta.name}`, body };
}
