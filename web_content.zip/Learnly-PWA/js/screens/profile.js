import { el, card, masteryBar } from "../ui/widgets.js";

function titleCase(s) { return s.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()); }

export async function Profile(app) {
  const s = app.student;
  const gm = app.gradeManager();
  const mastery = s.mastery || {};
  const vals = Object.values(mastery);
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;

  const body = [
    card(s.name || "Student", `Student code: ${s.code || ""}\n${gm.label()} Mathematics • Term ${s.term ?? 1}`),
    card("🏆 Elite Level", `Level ${s.level ?? 1} • ${s.xp ?? 0} XP`),
    card("📊 Overall Mastery", `${Math.round(avg * 100)}%`),
    card("🎯 Daily Goal", `${s.today_done ?? 0} / ${s.daily_goal ?? 20} • 🔥 ${s.streak ?? 0} day streak`),
    el("div", { class: "section-eyebrow" }, "MASTERY BY TOPIC"),
    ...Object.entries(mastery).sort((a, b) => b[1] - a[1]).map(([topic, val]) => masteryBar(titleCase(topic), val)),
    card("🔴 Weaknesses", (s.weaknesses || []).map(titleCase).join(", ") || "None yet"),
    card("🟢 Strengths", (s.strengths || []).map(titleCase).join(", ") || "None yet"),
    card("⚙ Settings", "Theme, display size and preferences.", [{ label: "OPEN SETTINGS", onClick: () => app.showSettings() }]),
    card("🔐 Tutor Mode", "Access code required.", [{ label: "ENTER TUTOR MODE", onClick: () => app.showTutorGate() }])
  ];

  return { title: "👤 Profile", bottomNavKey: "profile", body };
}
