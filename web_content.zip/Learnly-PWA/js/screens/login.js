import { GradeManager } from "../engines/gradeManager.js";
import { el, showAlert } from "../ui/widgets.js";

export async function Login(app) {
  const codeInput = el("input", { type: "text", placeholder: "Example: S01" });
  const gradeSelect = el("select", {}, GradeManager.allGrades().map(([num, name, phase]) =>
    el("option", { value: num }, `${name}  (${phase})`)
  ));
  gradeSelect.selectedIndex = Math.min(8, gradeSelect.options.length - 1); // default Grade 8

  async function doLogin() {
    const code = codeInput.value.trim().toUpperCase();
    if (!code) return showAlert("Student Code Required", "Please enter your student code.");
    if (code.length < 2) return showAlert("Invalid Student Code", "Please enter a valid student code.");
    const grade = parseInt(gradeSelect.value, 10);
    await app.login(code, grade);
  }
  codeInput.addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });

  return {
    title: "", showBack: false,
    body: [
      el("div", { style: "flex:1;display:flex;flex-direction:column;justify-content:center;gap:0.9rem;padding:1.5rem 0;" }, [
        el("div", { class: "center", style: "font-size:2.3rem;font-weight:800;" }, "Learnly"),
        el("div", { class: "center role-subtitle" }, "Grade R–9 Mathematics • The Elites Academy"),
        el("div", { style: "height:0.6rem" }),
        el("label", { class: "field-label" }, "Student code"),
        codeInput,
        el("label", { class: "field-label" }, "My grade (only used the first time you log in)"),
        gradeSelect,
        el("button", { class: "btn", onClick: doLogin }, "ENTER LEARNLY"),
        el("div", { class: "role-muted wrap" },
          "Enter your student code to continue. If this is your first time, Learnly creates your profile at the grade you picked above — you can change it anytime later in Settings, and every topic and question is always checked to match your current grade.")
      ])
    ]
  };
}
