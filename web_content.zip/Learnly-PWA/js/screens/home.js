import { el, card } from "../ui/widgets.js";
import { AdaptiveEngine } from "../engines/adaptive.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";

export async function Home(app) {
  const s = app.student;
  const gm = app.gradeManager();
  const goal = s.daily_goal ?? 20, done = s.today_done ?? 0;
  const rec = new AdaptiveEngine(s).recommendationText();
  const econ = new EconomyEngine(s);
  const gam = new GamificationEngine(s);
  const [unlocked, total] = gam.progressSummary();

  const cards = [
    card(`Welcome, ${s.name || "Student"} 👋`, `${gm.label()} Mathematics • ${gm.phase()} • CAPS`),
    card("🎯 Today's Goal", `${done} / ${goal} problems • ${Math.max(goal - done, 0)} remaining • 🔥 ${s.streak ?? 0} day streak`),
    card("🏆 Achievements & Credits", `🪙 ${econ.balance()} credits • ${unlocked}/${total} achievements unlocked`, [
      { label: "VIEW ACHIEVEMENTS", onClick: () => app.showAchievements(), secondary: true },
      { label: "VIEW CREDITS", onClick: () => app.showEconomy() }
    ]),
    card("🤖 Learnly Guide", rec, [{ label: "START RECOMMENDED PRACTICE", onClick: () => app.showPractice("recommended") }]),
    card("🎯 Pick a Topic", `See every ${gm.label()} topic and choose exactly what to practise.`, [{ label: "PICK A TOPIC", onClick: () => app.showTopicPicker() }]),
    card("📚 Learn", `Notes, worked examples and tips for every ${gm.label()} topic.`, [{ label: "OPEN LEARN", onClick: () => app.showLearn() }]),
    card("💡 Tips & Tricks", "Fast methods for addition, multiplication, fractions, percentages and more — with WHY they work.", [{ label: "OPEN LIBRARY", onClick: () => app.showTipsTricks() }])
  ];

  if (gm.grade === 8) {
    cards.push(card("🔬 Natural Sciences", "Matter & Materials, Life & Living, Energy & Change, Planet Earth & Beyond.", [{ label: "OPEN NATURAL SCIENCES", onClick: () => app.showScience() }]));
    cards.push(card("🧠 Definitions Quiz", "Multiple-choice quiz on key terms from Maths or Natural Sciences.", [{ label: "START QUIZ", onClick: () => app.showQuiz() }]));
  }

  cards.push(card("✏️ Practice", "Choose a topic, difficulty and question count — or let Learnly recommend one.", [{ label: "PRACTICE", onClick: () => app.showPractice() }]));
  cards.push(card("📝 Question Papers", `Generate ${gm.label()} papers with a memo — viewable and exportable as an image.`, [{ label: "OPEN PAPERS", onClick: () => app.showPapers() }]));
  cards.push(card("📐 Maths Labs", "Geometry drawer, Data Handling lab and Probability simulator.", [{ label: "OPEN LABS", onClick: () => app.showLabs() }]));
  cards.push(card("🧮 Mental Maths", "Fast calculation tricks with a timer and streak tracking.", [{ label: "START", onClick: () => app.showMental() }]));

  return { title: "Learnly", showBack: false, bottomNavKey: "home", body: cards };
}
