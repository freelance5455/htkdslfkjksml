import { preload as preloadGrades, GradeManager } from "./engines/gradeManager.js";
import { UnifiedQuestionEngine } from "./engines/unifiedEngine.js";
import * as db from "./db.js";
import { applyTheme } from "./theme.js";
import { el, bottomNav, showAlert, showPrompt } from "./ui/widgets.js";

import { Login } from "./screens/login.js";
import { Home } from "./screens/home.js";
import { Learn, TopicDetail, TopicDetailLite } from "./screens/learn.js";
import { PracticeSetup, PracticeSession } from "./screens/practice.js";
import { Papers, PaperViewer } from "./screens/papers.js";
import { Profile } from "./screens/profile.js";
import { Settings } from "./screens/settings.js";
import { Labs, GeometryLab, DataLab, ProbabilityLab, Mental } from "./screens/labs.js";
import { Tutor, TutorStudentProfile, TutorTestCenter } from "./screens/tutor.js";
import { ProgrammeHome, ProgrammeTutors, ProgrammeGroups, ProgrammeGroupDetail } from "./screens/programme.js";
import { Achievements, Economy, DevMode } from "./screens/gamification.js";
import { Science, ScienceTopic, Quiz, TipsTricks } from "./screens/science.js";

export const ACCESS_CODE = "children of the sun";

const SCREENS = {
  login: Login, home: Home, learn: Learn, topicDetail: TopicDetail, topicDetailLite: TopicDetailLite,
  practiceSetup: PracticeSetup, practiceSession: PracticeSession, papers: Papers, paperViewer: PaperViewer,
  profile: Profile, settings: Settings, labs: Labs, geometryLab: GeometryLab, dataLab: DataLab,
  probabilityLab: ProbabilityLab, mental: Mental, tutor: Tutor, tutorStudentProfile: TutorStudentProfile,
  tutorTestCenter: TutorTestCenter, programmeHome: ProgrammeHome, programmeTutors: ProgrammeTutors,
  programmeGroups: ProgrammeGroups, programmeGroupDetail: ProgrammeGroupDetail,
  achievements: Achievements, economy: Economy, devMode: DevMode,
  science: Science, scienceTopic: ScienceTopic, quiz: Quiz, tipsTricks: TipsTricks
};

export const app = {
  student: null,
  history: [],
  _current: null,

  // -------- engines helpers (mirrors app.py's grade_manager()/question_engine()) --------
  gradeManager() { return new GradeManager(this.student?.grade ?? 8); },
  questionEngine() { return new UnifiedQuestionEngine(this.student?.grade ?? 8); },

  saveStudent() { if (this.student) db.writeStudentRaw(this.student); },
  loadStudentByCode(code) { return db.readStudentRaw(code); },
  saveStudentByCode(student) { db.writeStudentRaw(student); },

  applyThemeAndFont() {
    const s = this.student?.settings || {};
    applyTheme(s.theme || "Classic Elite", s.font_scale || "Normal");
  },

  // -------- navigation --------
  async navigate(name, params = {}) {
    if (this._current) this.history.push(this._current);
    await this._render(name, params);
  },
  async replace(name, params = {}) {
    await this._render(name, params);
  },
  async resetTo(name, params = {}) {
    this.history = [];
    await this._render(name, params);
  },
  async goBack() {
    const prev = this.history.pop();
    if (prev) await this._render(prev.name, prev.params);
    else await this._render("home", {});
  },
  async refreshCurrentScreen() {
    if (this._current) await this._render(this._current.name, this._current.params, true);
  },

  async _render(name, params, isRefresh = false) {
    const fn = SCREENS[name];
    if (!fn) { console.error("Unknown screen:", name); return; }
    if (this._cleanup) { try { this._cleanup(); } catch { /* ignore */ } this._cleanup = null; }
    if (this.student && name !== "login") this.saveStudent();
    const root = document.getElementById("app");
    root.innerHTML = "";
    root.className = "";
    let def;
    try {
      def = await fn(this, params);
    } catch (err) {
      console.error(err);
      def = { title: "Something went wrong", showBack: true, body: [el("div", { class: "card" }, [el("div", { class: "role-heading" }, "Screen error"), el("div", { class: "role-subtitle wrap" }, String(err && err.message || err))])] };
    }
    if (!isRefresh) this._current = { name, params };
    this._cleanup = def.onUnmount || null;
    this._mount(def);
  },

  _mount(def) {
    const root = document.getElementById("app");
    const showBack = def.showBack !== false && def.showBack !== undefined ? true : (def.showBack === false ? false : true);
    const top = def.showBack === false
      ? el("div", { class: "screen-top" }, [el("div", { class: "screen-title" }, def.title)])
      : el("div", { class: "screen-top" }, [
          el("button", { class: "btn-secondary btn-sm", style: "width:2.6rem;flex:none;", onClick: () => this.goBack() }, "←"),
          el("div", { class: "screen-title" }, def.title)
        ]);
    const screen = el("div", { class: "screen" }, [top, el("div", { class: "screen-body" }, def.body || [])]);
    if (def.bottomNavKey) root.className = "has-bottomnav";
    root.appendChild(screen);
    if (def.bottomNavKey) root.appendChild(bottomNav(this, def.bottomNavKey));
    window.scrollTo(0, 0);
  },

  // -------- shortcuts (mirrors app.py's show_xxx methods) --------
  showHome() { return this.resetTo("home"); },
  showLearn() { return this.navigate("learn"); },
  showTopicDetail(topicId) {
    // Grade 8 has full 19-part deep notes; every other grade uses the lighter,
    // still-real notes screen built from the curriculum file + tips library.
    return this.navigate((this.student?.grade ?? 8) === 8 ? "topicDetail" : "topicDetailLite", { topicId });
  },
  showTopicPicker() { return this.navigate("practiceSetup", { mode: "choose" }); },
  showPractice(mode, topics) { return this.navigate("practiceSetup", { mode, topics }); },
  launchPracticeSession(opts) { return this.navigate("practiceSession", opts); },
  showPapers() { return this.navigate("papers"); },
  showPaperViewer(paperId) { return this.navigate("paperViewer", { paperId }); },
  showProfile() { return this.navigate("profile"); },
  showSettings() { return this.navigate("settings"); },
  showLabs() { return this.navigate("labs"); },
  showGeometryLab() { return this.navigate("geometryLab"); },
  showDataLab() { return this.navigate("dataLab"); },
  showProbabilityLab() { return this.navigate("probabilityLab"); },
  showMental() { return this.navigate("mental"); },
  showScience() { return this.navigate("science"); },
  showScienceTopic(topicId) { return this.navigate("scienceTopic", { topicId }); },
  showQuiz(subject = "math", topicId = null) { return this.navigate("quiz", { subject, topicId }); },
  showTipsTricks() { return this.navigate("tipsTricks"); },
  showAchievements() { return this.navigate("achievements"); },
  showEconomy() { return this.navigate("economy"); },
  showTutor() { return this.navigate("tutor"); },
  showTutorStudentProfile(code) { return this.navigate("tutorStudentProfile", { code }); },
  showTutorTestCenter(code) { return this.navigate("tutorTestCenter", { code }); },
  showProgrammeHome() { return this.navigate("programmeHome"); },
  showProgrammeTutors() { return this.navigate("programmeTutors"); },
  showProgrammeGroups(tutorId = null) { return this.navigate("programmeGroups", { tutorId }); },
  showProgrammeGroupDetail(groupId) { return this.navigate("programmeGroupDetail", { groupId }); },

  async showDevModeGate() {
    const code = await showPrompt("Dev Mode Access", "Access code:", "", true);
    if (code === null) return;
    if (code.trim().toLowerCase() === ACCESS_CODE) this.navigate("devMode");
    else showAlert("Access denied", "Incorrect access code.");
  },
  async showTutorGate() {
    const code = await showPrompt("Tutor Access", "Access code:", "", true);
    if (code === null) return;
    if (code.trim().toLowerCase() === ACCESS_CODE) this.resetTo("tutor");
    else showAlert("Access denied", "Incorrect access code.");
  },
  async showProgrammeGate() {
    const code = await showPrompt("Programme Access", "Access code:", "", true);
    if (code === null) return;
    if (code.trim().toLowerCase() === ACCESS_CODE) this.navigate("programmeHome");
    else showAlert("Access denied", "Incorrect access code.");
  },

  // -------- auth --------
  async login(code, grade = 8) {
    this.student = db.login(code, grade);
    this.applyThemeAndFont();
    await this.resetTo("home");
  },
  async logout() {
    this.saveStudent();
    this.student = null;
    this.history = [];
    await this.resetTo("login");
  },
  async changeGrade(newGrade) {
    db.changeGrade(this.student, newGrade);
  }
};

export async function boot() {
  try {
    await preloadGrades();
  } catch (err) {
    document.getElementById("app").innerHTML =
      `<div class="screen"><div class="card"><div class="role-heading">Could not load Learnly</div><div class="role-subtitle wrap">${String(err.message || err)}</div></div></div>`;
    return;
  }
  applyTheme("Classic Elite", "Normal");
  await app.resetTo("login");
}
