// Port of ui/theme_manager.py — same 5 themes, same colours, same font scale steps.
export const THEMES = [
  "Classic Elite", "Midnight", "Academic", "Neon", "Glass"
];

export const FONT_SCALES = { "Small": 0.85, "Normal": 1.0, "Large": 1.15, "Extra Large": 1.3 };

export function applyTheme(themeName, fontScaleName) {
  const theme = THEMES.includes(themeName) ? themeName : "Classic Elite";
  const scale = FONT_SCALES[fontScaleName] ?? 1.0;
  document.documentElement.setAttribute("data-theme", theme);
  document.documentElement.style.fontSize = Math.max(10, Math.round(16 * scale)) + "px";
}
