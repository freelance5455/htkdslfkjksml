// Port of engine/data_engine.py
function mean(v) { return v.reduce((a, b) => a + b, 0) / v.length; }
function median(v) { const s = [...v].sort((a, b) => a - b); const n = s.length; return n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2; }
function multimode(v) { const counts = {}; v.forEach((x) => (counts[x] = (counts[x] || 0) + 1)); const max = Math.max(...Object.values(counts)); return Object.keys(counts).filter((k) => counts[k] === max).map(Number); }
function pstdev(v) { const m = mean(v); return Math.sqrt(v.reduce((s, x) => s + (x - m) ** 2, 0) / v.length); }

export class DataEngine {
  summary(values) {
    const v = values.map(Number).sort((a, b) => a - b);
    const n = v.length;
    if (!n) return { count: 0 };
    const q1 = v[Math.floor(n / 4)];
    const q3 = v[Math.floor((3 * n) / 4)];
    const iqr = q3 - q1;
    const lowerFence = q1 - 1.5 * iqr, upperFence = q3 + 1.5 * iqr;
    const outliers = v.filter((x) => x < lowerFence || x > upperFence);
    return {
      count: n, sum: v.reduce((a, b) => a + b, 0), mean: Math.round(mean(v) * 1000) / 1000,
      median: median(v), mode: multimode(v), minimum: v[0], maximum: v[n - 1], range: v[n - 1] - v[0],
      q1, q3, iqr, stdev: n > 1 ? Math.round(pstdev(v) * 1000) / 1000 : 0,
      sorted: v, outliers, five_number_summary: [v[0], q1, median(v), q3, v[n - 1]]
    };
  }
  frequencyTable(values) {
    const table = {};
    values.forEach((v) => (table[v] = (table[v] || 0) + 1));
    return Object.fromEntries(Object.entries(table).sort((a, b) => a[0] - b[0]));
  }
  groupedFrequency(values, nClasses = 5) {
    if (!values.length) return [];
    const lo = Math.min(...values), hi = Math.max(...values);
    const span = (hi - lo) || 1;
    const width = Math.max(1, Math.round(span / nClasses));
    const classes = [];
    for (let start = lo; start <= hi; start += width) classes.push([start, start + width, 0]);
    values.forEach((v) => {
      for (const c of classes) {
        if ((c[0] <= v && v < c[1]) || (v === hi && c[1] === classes[classes.length - 1][1])) { c[2]++; break; }
      }
    });
    let cumulative = 0;
    return classes.map(([loC, hiC, freq]) => { cumulative += freq; return { class: `${loC}–${hiC}`, frequency: freq, cumulative_frequency: cumulative }; });
  }
  randomDataset(n = 8, low = 1, high = 50) { return Array.from({ length: n }, () => Math.floor(Math.random() * (high - low + 1)) + low); }
}
