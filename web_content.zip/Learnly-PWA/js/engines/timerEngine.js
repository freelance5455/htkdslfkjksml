// Port of engine/timer_engine.py using setInterval in place of QTimer/Signal.
export class CountdownTimer {
  constructor() { this._id = null; this.remaining = 0; this.onTick = null; this.onFinished = null; }
  start(seconds) {
    this.stop();
    this.remaining = Math.max(0, Math.trunc(seconds));
    this.onTick?.(this.remaining);
    this._id = setInterval(() => this._step(), 1000);
  }
  pause() { if (this._id) { clearInterval(this._id); this._id = null; } }
  resume() { if (!this._id) this._id = setInterval(() => this._step(), 1000); }
  reset(seconds = 0) { this.stop(); this.remaining = seconds; this.onTick?.(this.remaining); }
  stop() { if (this._id) { clearInterval(this._id); this._id = null; } }
  _step() {
    this.remaining -= 1;
    this.onTick?.(Math.max(0, this.remaining));
    if (this.remaining <= 0) { this.stop(); this.onFinished?.(); }
  }
}

export class Stopwatch {
  constructor() { this._id = null; this.elapsed = 0; this.onTick = null; }
  start() { this.stop(); this.elapsed = 0; this._id = setInterval(() => this._step(), 1000); }
  pause() { if (this._id) { clearInterval(this._id); this._id = null; } }
  resume() { if (!this._id) this._id = setInterval(() => this._step(), 1000); }
  reset() { this.stop(); this.elapsed = 0; this.onTick?.(0); }
  stop() { if (this._id) { clearInterval(this._id); this._id = null; } }
  _step() { this.elapsed += 1; this.onTick?.(this.elapsed); }
}
