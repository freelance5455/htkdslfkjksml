// Port of engine/economy_engine.py — credits flow through transactions, never direct
// balance edits, so there's always an auditable history and balance can't go negative.
export const REWARD_TABLE = {
  correct_answer: 1, session_complete: 5, daily_goal_met: 10,
  streak_day: 3, mastery_milestone: 15, achievement_unlocked: 20
};

export class EconomyEngine {
  constructor(student) {
    this.student = student;
    if (student.credits === undefined) student.credits = 0;
    if (!student.transactions) student.transactions = [];
  }
  balance() { return this.student.credits; }

  _record(amount, kind, reason) {
    const entry = { amount, kind, reason, balance_after: this.student.credits, timestamp: new Date().toISOString() };
    this.student.transactions.push(entry);
    if (this.student.transactions.length > 300) this.student.transactions = this.student.transactions.slice(-300);
    return entry;
  }

  reward(eventKey, note = "") {
    const amount = REWARD_TABLE[eventKey] || 0;
    if (amount <= 0) return null;
    this.student.credits += amount;
    return this._record(amount, "reward", note || eventKey);
  }

  spend(amount, reason) {
    amount = Math.abs(Math.trunc(amount));
    if (amount > this.student.credits) return false;
    this.student.credits -= amount;
    this._record(-amount, "spend", reason);
    return true;
  }

  history(limit = 20) { return [...this.student.transactions].reverse().slice(0, limit); }

  // ---------- Dev Mode only — never exposed in a normal student flow ----------
  devAdd(amount, reason = "Dev Mode: add credits") { amount = Math.abs(Math.trunc(amount)); this.student.credits += amount; return this._record(amount, "dev_adjustment", reason); }
  devRemove(amount, reason = "Dev Mode: remove credits") { amount = Math.min(Math.abs(Math.trunc(amount)), this.student.credits); this.student.credits -= amount; return this._record(-amount, "dev_adjustment", reason); }
  devSetBalance(newBalance, reason = "Dev Mode: set balance") { newBalance = Math.max(0, Math.trunc(newBalance)); const delta = newBalance - this.student.credits; this.student.credits = newBalance; return this._record(delta, "dev_adjustment", reason); }
  devSimulatePurchase(itemName, cost) { return this.spend(cost, `Dev Mode: simulated purchase — ${itemName}`); }
  devReset() { this.student.credits = 0; this.student.transactions = []; return this._record(0, "dev_adjustment", "Dev Mode: economy reset"); }
}
