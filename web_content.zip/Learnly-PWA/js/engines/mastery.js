// Port of engine/mastery.py
export class MasteryEngine {
  constructor(student) {
    this.student = student;
    this.mastery = student.mastery = student.mastery || {};
    this.seenLow = student.mastery_seen_low = student.mastery_seen_low || {};
  }
  score(topic, correct, difficulty = 1) {
    const old = parseFloat(this.mastery[topic] ?? 0.5);
    const step = 0.04 + Math.min(0.04, difficulty * 0.01);
    let val = old + (correct ? step : -step * 1.25);
    val = Math.max(0, Math.min(1, Math.round(val * 10000) / 10000));
    this.mastery[topic] = val;
    if (val <= 0.4) this.seenLow[topic] = true; // remembered even after mastery later improves
    this.refresh();
    return val;
  }
  refresh() {
    const items = Object.entries(this.mastery).sort((a, b) => a[1] - b[1]);
    this.student.weaknesses = items.filter(([, v]) => v < 0.55).map(([k]) => k).slice(0, 5);
    this.student.strengths = [...items].reverse().filter(([, v]) => v >= 0.75).map(([k]) => k).slice(0, 5);
  }
  overall() {
    const vals = Object.values(this.mastery);
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0.5;
  }
}
