// Port of engine/grade_manager.py — the single authority every screen goes through
// before showing a topic, question, or number range to a student.
const DATA_PATH = "./content/curriculum_all_grades.json";
export const SENIOR_PHASE_GRADES = [7, 8, 9];

let _cache = null;
async function load() {
  if (_cache) return _cache;
  const res = await fetch(DATA_PATH);
  if (!res.ok) throw new Error("Grade verification file missing: " + DATA_PATH);
  _cache = await res.json();
  return _cache;
}
// Synchronous accessor for code that has already awaited preload() once at boot.
function loadSync() {
  if (!_cache) throw new Error("GradeManager used before preload(). Call GradeManager.preload() at boot.");
  return _cache;
}
export async function preload() { await load(); }

export class GradeManager {
  constructor(grade = 8) {
    this.setGrade(grade);
  }
  setGrade(grade) {
    grade = parseInt(grade, 10);
    const data = loadSync();
    if (!data.grades[String(grade)]) {
      throw new Error(`Unknown grade '${grade}'. Learnly supports Grade R (0) through Grade 9.`);
    }
    this.grade = grade;
    this._data = data.grades[String(grade)];
  }
  label() { return this._data.label; }
  phase() { return this._data.phase; }
  topics() { return this._data.topics; }
  topicIds() { return this._data.topics.map(t => t.id); }
  hasTopic(id) { return this.topicIds().includes(id); }
  numberRange() { return this._data.number_range; }
  operations() { return this._data.operations; }
  difficultyScale() { return this._data.difficulty_scale ?? 1.0; }
  isSeniorPhase() { return SENIOR_PHASE_GRADES.includes(this.grade); }

  verifyTopic(topicId) {
    if (!this.hasTopic(topicId)) {
      throw new Error(`'${topicId}' is not a ${this.label()} topic. Valid topics: ${this.topicIds().join(", ")}`);
    }
    return true;
  }
  verifyNumber(value) {
    const [lo, hi] = this.numberRange();
    const v = parseFloat(value);
    if (Number.isNaN(v)) return true; // non-numeric answers (fractions, coords) skip this check
    return lo <= v && v <= hi;
  }
  verifyQuestion(q) {
    if (q.topic && !this.hasTopic(q.topic)) {
      return { ok: false, reason: `Topic '${q.topic}' does not belong to ${this.label()}` };
    }
    const nums = String(q.question || "").match(/-?\d+\.?\d*/g) || [];
    const [lo, hi] = this.numberRange();
    for (const n of nums) {
      const v = parseFloat(n);
      if (Number.isNaN(v)) continue;
      if (!(lo - 1 <= v && v <= hi + 1)) {
        return { ok: false, reason: `Number ${n} is outside ${this.label()}'s expected range (${lo} to ${hi})` };
      }
    }
    return { ok: true, reason: null };
  }
  clampCount(reqMin, reqMax) {
    const [lo, hi] = this.numberRange();
    return [Math.max(lo, reqMin), Math.min(hi, reqMax)];
  }
  static allGrades() {
    const data = loadSync().grades;
    return Object.keys(data).sort((a, b) => +a - +b).map(g => [+g, data[g].label, data[g].phase]);
  }
}
