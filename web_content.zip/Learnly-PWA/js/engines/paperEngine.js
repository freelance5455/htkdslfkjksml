// Port of engine/paper_engine.py. Papers are stored under localStorage key
// "learnly:paper:<id>" in place of data/papers/<id>.json — same shape, same rules.
import { AdaptiveEngine } from "./adaptive.js";
import { UnifiedQuestionEngine } from "./unifiedEngine.js";
import { GradeManager } from "./gradeManager.js";

// Term mapping only exists (and only matters) for Grade 8's fully-built term structure.
const GRADE8_TOPIC_TERM = {
  whole_numbers: 1, integers: 1, exponents: 1, patterns: 1, number_sense: 1,
  algebraic_expressions: 2, algebraic_equations: 2, geometry_lines: 2,
  pythagoras: 3, area_perimeter: 3, financial_maths: 3, transformations: 3,
  data_handling: 4, probability: 4
};

export const PAPER_TYPES = ["Term / ATP Aligned", "Weakness Recovery", "Strength Challenge", "Diagnostic", "Mock Exam", "Custom Topic Paper"];
export const DIFFICULTY_MAP = { Foundation: 1, Standard: 2, Advanced: 3, Elite: 4 };

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function newPaperId() {
  const d = new Date();
  const p2 = (n) => String(n).padStart(2, "0");
  return "P" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()) + ri(10, 99);
}

export class PaperEngine {
  generate(student, { paperType = "Term / ATP Aligned", term = null, topics = null, difficulty = "Standard", count = 15, timeMinutes = 45 } = {}) {
    const grade = student.grade ?? 8;
    const gm = new GradeManager(grade);
    const qe = new UnifiedQuestionEngine(grade);
    const ad = new AdaptiveEngine(student);
    term = term ?? student.term ?? 1;
    const diff = DIFFICULTY_MAP[difficulty] ?? 2;
    const allGradeTopics = gm.topicIds();

    if (!topics || !topics.length) {
      if (paperType === "Weakness Recovery") {
        topics = (student.weaknesses || []).filter((t) => allGradeTopics.includes(t));
        if (!topics.length) topics = [ad.chooseTopic("weakness")];
      } else if (paperType === "Strength Challenge") {
        topics = (student.strengths || []).filter((t) => allGradeTopics.includes(t));
        if (!topics.length) topics = [ad.chooseTopic("strength")];
      } else if (paperType === "Term / ATP Aligned" && grade === 8) {
        topics = Object.entries(GRADE8_TOPIC_TERM).filter(([, tm]) => tm === +term).map(([t]) => t);
      } else {
        topics = allGradeTopics;
      }
    }
    // Safety net: strip anything that doesn't belong to this grade (e.g. a stale
    // weakness recorded before a grade change).
    topics = topics.filter((t) => allGradeTopics.includes(t));
    if (!topics.length) topics = allGradeTopics;

    const questions = [];
    const sections = {};
    for (let i = 0; i < count; i++) {
      const topic = topics[i % topics.length];
      const qdiff = paperType === "Diagnostic" ? ri(1, 4) : diff;
      const q = qe.generate(topic, qdiff);
      q.number = i + 1;
      questions.push(q);
      (sections[topic] = sections[topic] || []).push(q.number);
    }

    const totalMarks = questions.reduce((s, q) => s + q.marks, 0);
    const paperId = newPaperId();
    const paper = {
      paper_id: paperId, grade: gm.grade, grade_label: gm.label(), subject: "Mathematics",
      term, type: paperType, difficulty, topics, marks: totalMarks, time_minutes: timeMinutes,
      created_at: new Date().toISOString(), student_code: student.code || "",
      questions, sections
    };

    localStorage.setItem("learnly:paper:" + paperId, JSON.stringify(paper));
    student.papers = student.papers || [];
    student.papers.push({ id: paperId, type: paperType, term, marks: totalMarks, created_at: paper.created_at });

    return paper;
  }

  load(paperId) {
    const raw = localStorage.getItem("learnly:paper:" + paperId);
    return raw ? JSON.parse(raw) : null;
  }

  listPapers(studentCode = null) {
    const out = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !key.startsWith("learnly:paper:")) continue;
      try {
        const d = JSON.parse(localStorage.getItem(key));
        if (studentCode == null || d.student_code === studentCode) out.push(d);
      } catch { /* skip corrupt entries */ }
    }
    out.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    return out;
  }
}
