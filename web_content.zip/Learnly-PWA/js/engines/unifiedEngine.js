// Port of engine/unified_engine.py — single entry point the UI calls for questions,
// regardless of grade. Routes to the right generator and re-verifies every question
// against GradeManager before it's allowed to reach a screen.
import { GradeManager } from "./gradeManager.js";
import { QuestionEngine } from "./questionEngine.js";
import { FoundationQuestionEngine } from "./foundationEngine.js";

function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

export class UnifiedQuestionEngine {
  constructor(grade) {
    this.gm = new GradeManager(grade);
    this.grade = this.gm.grade;
    this._senior = this.gm.isSeniorPhase() ? new QuestionEngine() : null;
    this._foundation = this.gm.isSeniorPhase() ? null : new FoundationQuestionEngine(this.grade);
  }
  topics() { return this.gm.topics(); }
  topicIds() { return this.gm.topicIds(); }

  generate(topicId = null, difficulty = 1) {
    if (!topicId || !this.gm.hasTopic(topicId)) topicId = choice(this.gm.topicIds());
    this.gm.verifyTopic(topicId);

    let q;
    if (this.gm.isSeniorPhase()) {
      const scaled = Math.max(1, Math.min(4, Math.round(difficulty * this.gm.difficultyScale())));
      q = this._senior.generate(topicId, scaled);
    } else {
      q = this._foundation.generate(topicId, difficulty);
    }

    const { ok } = this.gm.verifyQuestion(q);
    if (!ok) {
      // Never show a question that fails verification — fall back to a
      // guaranteed-safe generator for this grade rather than risk wrong-level content.
      q = this._foundation ? this._foundation._genericArithmetic(topicId, difficulty) : this._senior.generate(topicId, 1);
    }
    return q;
  }
}
