// Port of engine/probability_engine.py
function comb(n, r) { if (r < 0 || r > n) return 0; r = Math.min(r, n - r); let res = 1; for (let i = 0; i < r; i++) res = (res * (n - i)) / (i + 1); return Math.round(res); }

export class ProbabilityEngine {
  simple(favourable, total) { if (total <= 0) throw new Error("Total outcomes must be positive."); return favourable / total; }
  combinations(n, r) { return comb(n, r); }
  rollDie(sides = 6, times = 1) { return Array.from({ length: times }, () => Math.floor(Math.random() * sides) + 1); }
  flipCoin(times = 1) { return Array.from({ length: times }, () => (Math.random() < 0.5 ? "Heads" : "Tails")); }
  spinSpinner(sectors = 8, times = 1) { return Array.from({ length: times }, () => Math.floor(Math.random() * sectors) + 1); }
  drawCard(times = 1) {
    const suits = ["♠", "♥", "♦", "♣"], ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    const deck = []; suits.forEach((s) => ranks.forEach((r) => deck.push(r + s)));
    const shuffled = [...deck].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, Math.min(times, deck.length));
  }
}
