// Port of engine/gamification_engine.py — purely rule-based (no AI), matches Learnly's
// deterministic adaptive philosophy.
export const ACHIEVEMENTS = [
  { id: "first_spark", name: "First Spark", icon: "✨", desc: "Answer your very first question.",
    check: (s) => (s.history || []).length >= 1 },
  { id: "pattern_hunter", name: "Pattern Hunter", icon: "🔁", desc: "Get 10 correct answers in Numeric Patterns.",
    check: (s) => (s.history || []).filter((h) => h.topic === "patterns" && h.correct).length >= 10 },
  { id: "mental_mathematician", name: "Mental Mathematician", icon: "🧮", desc: "Reach a Mental Maths streak of 10.",
    check: (s) => (s.mental_best_streak || 0) >= 10 },
  { id: "zero_to_hero", name: "Zero to Hero", icon: "🚀", desc: "Take any topic's mastery from below 40% to above 80%.",
    check: (s) => Object.keys(s.mastery_seen_low || {}).some((t) => (s.mastery?.[t] || 0) >= 0.8) },
  { id: "number_sense_elite", name: "Number Sense Elite", icon: "🔢", desc: "Reach 90% mastery in Number Sense.",
    check: (s) => (s.mastery?.number_sense || 0) >= 0.9 },
  { id: "numerical_virtuoso", name: "Numerical Virtuoso", icon: "🏆", desc: "Reach 80% average mastery across every topic you've attempted.",
    check: (s) => { const v = Object.values(s.mastery || {}); return v.length > 0 && v.reduce((a, b) => a + b, 0) / v.length >= 0.8; } },
  { id: "streak_starter", name: "Streak Starter", icon: "🔥", desc: "Reach a 3-day practice streak.",
    check: (s) => (s.streak || 0) >= 3 },
  { id: "consistency_champion", name: "Consistency Champion", icon: "📅", desc: "Reach a 7-day practice streak.",
    check: (s) => (s.streak || 0) >= 7 },
  { id: "paper_pioneer", name: "Paper Pioneer", icon: "📝", desc: "Generate your first question paper.",
    check: (s) => (s.papers || []).length >= 1 },
  { id: "hundred_club", name: "Hundred Club", icon: "💯", desc: "Answer 100 questions in total.",
    check: (s) => (s.history || []).length >= 100 }
];

export class GamificationEngine {
  constructor(student) {
    this.student = student;
    if (!student.achievements) student.achievements = [];
  }
  checkNewUnlocks() {
    const unlocked = new Set(this.student.achievements);
    const newly = [];
    for (const ach of ACHIEVEMENTS) {
      if (unlocked.has(ach.id)) continue;
      try {
        if (ach.check(this.student)) { this.student.achievements.push(ach.id); newly.push(ach); }
      } catch { /* a malformed stat should never crash the app */ }
    }
    return newly;
  }
  allWithStatus() {
    const unlocked = new Set(this.student.achievements || []);
    return ACHIEVEMENTS.map((a) => ({ id: a.id, name: a.name, icon: a.icon, desc: a.desc, unlocked: unlocked.has(a.id) }));
  }
  progressSummary() { return [((this.student.achievements || []).length), ACHIEVEMENTS.length]; }
}
