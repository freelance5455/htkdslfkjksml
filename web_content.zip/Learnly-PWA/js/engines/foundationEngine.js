// Port of engine/foundation_engine.py — Grade R-6 question templates, each bounded by
// GradeManager's verified number_range so a Grade 2 learner is never shown Grade 8 numbers.
import { GradeManager } from "./gradeManager.js";

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a || 1; }
function roundTo(n, place) { const f = Math.pow(10, -place); return Math.round(n * f) / f; } // place: -1=nearest10 etc (Python round(n,-1) style)

const TOPIC_NAMES = {
  counting: "Counting & Number Recognition", shapes_r: "Shapes & Patterns",
  sorting: "Sorting & Comparing", time_r: "Time & Sequence",
  numbers_20: "Numbers to 20", add_sub_20: "Addition & Subtraction to 20",
  shapes_1: "2D & 3D Shapes", measurement_1: "Length, Mass & Time",
  numbers_99: "Numbers to 99", add_sub_99: "Addition & Subtraction to 99",
  repeated_add: "Repeated Addition", shapes_2: "Shapes, Symmetry & Patterns",
  numbers_999: "Numbers to 999", add_sub_999: "Addition & Subtraction to 999",
  mult_tables: "Multiplication Tables", division_intro: "Sharing & Grouping",
  fractions_intro: "Fractions (halves, quarters)",
  whole_numbers_4: "Whole Numbers to 9999", mult_div_4: "Multiplication & Division",
  common_fractions_4: "Common Fractions", geometry_4: "2D Shapes & 3D Objects",
  measurement_4: "Length, Mass, Capacity, Time",
  whole_numbers_5: "Whole Numbers to 999 999", common_fractions_5: "Common Fractions",
  decimal_fractions_5: "Decimal Fractions", geometry_5: "Properties of Shapes", data_5: "Data Handling",
  whole_numbers_6: "Whole Numbers (millions)", fractions_6: "Common & Decimal Fractions",
  percentages_6: "Percentages", ratio_6: "Ratio & Rate", geometry_6: "Geometry & Transformations", data_6: "Data Handling"
};
const SHAPES = ["triangle", "rectangle", "circle", "square"];

function base(topic, q, a, d, hint, exp, diagram = null) {
  return {
    id: `${topic}_${ri(100000, 999999)}`, topic,
    topic_name: TOPIC_NAMES[topic] || topic.replaceAll("_", " "),
    question: q, answer: String(a), difficulty: d, hint, explanation: exp, marks: d, diagram
  };
}

export class FoundationQuestionEngine {
  constructor(grade) {
    this.gm = new GradeManager(grade);
    this.grade = this.gm.grade;
  }

  generate(topicId, difficulty = 1) {
    this.gm.verifyTopic(topicId);
    const method = this["_" + topicId];
    let q = method ? method.call(this, difficulty) : this._genericArithmetic(topicId, difficulty);
    const { ok } = this.gm.verifyQuestion(q);
    if (!ok) q = this._genericArithmetic(topicId, difficulty);
    return q;
  }

  _range(capLo = null, capHi = null) {
    let [lo, hi] = this.gm.numberRange();
    if (capLo !== null) lo = Math.max(lo, capLo);
    if (capHi !== null) hi = Math.min(hi, capHi);
    return [lo, Math.max(lo + 1, hi)];
  }

  _genericArithmetic(topicId, d) {
    const [lo, hi] = this._range(0, null);
    let a = ri(lo, hi), b = ri(lo, hi), op = choice(["+", "-"]);
    if (op === "-" && b > a) [a, b] = [b, a];
    const ans = op === "+" ? a + b : a - b;
    return base(topicId, `Calculate: ${a} ${op} ${b}`, ans, d, `Work it out step by step: ${a} ${op} ${b}.`, `${a} ${op} ${b} = ${ans}.`);
  }

  _shapeQuestion(topicId, d) {
    const shape = choice(SHAPES);
    let diagram = null;
    if (shape === "triangle") diagram = { type: "triangle_bh", b: 10, h: 8 };
    else if (shape === "rectangle") diagram = { type: "rectangle", l: 10, w: 6 };
    else if (shape === "circle") diagram = { type: "circle", r: 6 };
    else if (shape === "square") diagram = { type: "rectangle", l: 8, w: 8 };
    return base(topicId, "What is the name of this shape?", shape, d, "Look at the number of sides and corners.", `This shape is a ${shape}.`, diagram);
  }

  // ---------- Grade R ----------
  _counting(d) { const n = ri(1, 10); return base("counting", `Count the dots: ${"●".repeat(n)}\nHow many are there?`, n, d, "Point at each dot and count out loud, one at a time.", `There are ${n} dots.`); }
  _shapes_r(d) { return this._shapeQuestion("shapes_r", d); }
  _sorting(d) { const nums = new Set(); while (nums.size < 2) nums.add(ri(1, 9)); const [x, y] = [...nums]; const bigger = Math.max(x, y); return base("sorting", `Which number is bigger: ${x} or ${y}?`, bigger, d, "Count up from 1 - the number you reach later is bigger.", `${bigger} is bigger than ${Math.min(x, y)}.`); }
  _time_r(d) { const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]; const i = ri(0, 5); return base("time_r", `What day comes after ${days[i]}?`, days[i + 1], d, "Think about the order of the days of the week.", `The day after ${days[i]} is ${days[i + 1]}.`); }

  // ---------- Grade 1 ----------
  _numbers_20(d) { const n = ri(1, 19); return base("numbers_20", `What number comes after ${n}?`, n + 1, d, "Count one more.", `One more than ${n} is ${n + 1}.`); }
  _add_sub_20(d) { const [lo, hi] = this._range(0, 20); let a = ri(lo, hi), b = ri(lo, hi), op = choice(["+", "-"]); if (op === "-" && b > a) [a, b] = [b, a]; const ans = op === "+" ? a + b : a - b; return base("add_sub_20", `Calculate: ${a} ${op} ${b}`, ans, d, "Use your fingers or count on a number line.", `${a} ${op} ${b} = ${ans}.`); }
  _shapes_1(d) { return this._shapeQuestion("shapes_1", d); }
  _measurement_1(d) { const [a, b] = choice([["an elephant", "a mouse"], ["a bus", "a bicycle"], ["a tree", "a flower"]]); return base("measurement_1", `Which is heavier: ${a} or ${b}?`, a, d, "Think about the size and weight of each thing.", `${a} is heavier than ${b}.`); }

  // ---------- Grade 2 ----------
  _numbers_99(d) { const n = ri(10, 98); return base("numbers_99", `What number comes before ${n}?`, n - 1, d, "Count one less.", `One less than ${n} is ${n - 1}.`); }
  _add_sub_99(d) { const [lo, hi] = this._range(0, 99); let a = ri(lo, hi), b = ri(lo, hi), op = choice(["+", "-"]); if (op === "-" && b > a) [a, b] = [b, a]; const ans = op === "+" ? a + b : a - b; return base("add_sub_99", `Calculate: ${a} ${op} ${b}`, ans, d, "Break the numbers into tens and ones.", `${a} ${op} ${b} = ${ans}.`); }
  _repeated_add(d) { const n = ri(2, 5), times = ri(2, 5); const terms = Array(times).fill(n).join(" + "); return base("repeated_add", `Calculate using repeated addition: ${terms}`, n * times, d, `Adding ${n} a total of ${times} times is the same as ${n} × ${times}.`, `${terms} = ${n} × ${times} = ${n * times}.`); }
  _shapes_2(d) { return this._shapeQuestion("shapes_2", d); }

  // ---------- Grade 3 ----------
  _numbers_999(d) { const [lo, hi] = this._range(100, 999); const n = ri(lo, hi); const r = Math.round(n / 10) * 10; return base("numbers_999", `Round ${n} to the nearest 10.`, r, d, "Look at the ones digit: 5 or more rounds up.", `${n} rounds to ${r}.`); }
  _add_sub_999(d) { const [lo, hi] = this._range(0, 999); let a = ri(lo, hi), b = ri(lo, hi), op = choice(["+", "-"]); if (op === "-" && b > a) [a, b] = [b, a]; const ans = op === "+" ? a + b : a - b; return base("add_sub_999", `Calculate: ${a} ${op} ${b}`, ans, d, "Line up the hundreds, tens and ones.", `${a} ${op} ${b} = ${ans}.`); }
  _mult_tables(d) { const a = ri(1, 10), b = ri(1, 10); return base("mult_tables", `Calculate: ${a} × ${b}`, a * b, d, `Think of the ${a} times table.`, `${a} × ${b} = ${a * b}.`); }
  _division_intro(d) { const b = ri(2, 10), q = ri(2, 10), a = b * q; return base("division_intro", `Share ${a} sweets equally between ${b} friends. How many does each get?`, q, d, `Think: ${b} × ? = ${a}.`, `${a} ÷ ${b} = ${q}.`); }
  _fractions_intro(d) { const whole = choice([4, 8, 12, 16]); const [label, denom] = choice([["half", 2], ["quarter", 4]]); return base("fractions_intro", `What is one ${label} of ${whole}?`, Math.floor(whole / denom), d, `Divide ${whole} into ${denom} equal parts.`, `${whole} ÷ ${denom} = ${Math.floor(whole / denom)}.`); }

  // ---------- Grade 4 ----------
  _whole_numbers_4(d) { const [lo, hi] = this._range(1000, 9999); const n = ri(lo, hi); const r = Math.round(n / 100) * 100; return base("whole_numbers_4", `Round ${n} to the nearest 100.`, r, d, "Look at the tens digit to decide whether to round up or down.", `${n} rounds to ${r}.`); }
  _mult_div_4(d) { const a = ri(2, 12), b = ri(2, 12); if (Math.random() < 0.5) return base("mult_div_4", `Calculate: ${a} × ${b}`, a * b, d, "Use known times tables or break the number apart.", `${a} × ${b} = ${a * b}.`); const product = a * b; return base("mult_div_4", `Calculate: ${product} ÷ ${a}`, b, d, `Think: ${a} × ? = ${product}.`, `${product} ÷ ${a} = ${b}.`); }
  _common_fractions_4(d) { const den = choice([4, 5, 8, 10]); let n1 = ri(1, den - 1), n2 = ri(1, den - 1); let total = n1 + n2; if (total > den) { n1 = Math.floor(n1 / 2) || 1; n2 = Math.floor(n2 / 2) || 1; total = n1 + n2; } return base("common_fractions_4", `Calculate: ${n1}/${den} + ${n2}/${den}`, `${total}/${den}`, d, "Same denominator: just add the numerators.", `${n1}/${den} + ${n2}/${den} = ${total}/${den}.`); }
  _geometry_4(d) { return this._shapeQuestion("geometry_4", d); }
  _measurement_4(d) { const cm = ri(100, 500); return base("measurement_4", `Convert ${cm} cm to metres.`, cm / 100, d, "100 cm = 1 m, so divide by 100.", `${cm} ÷ 100 = ${cm / 100} m.`); }

  // ---------- Grade 5 ----------
  _whole_numbers_5(d) { const [lo, hi] = this._range(10000, 999999); const n = ri(lo, hi); const r = Math.round(n / 1000) * 1000; return base("whole_numbers_5", `Round ${n} to the nearest 1000.`, r, d, "Look at the hundreds digit.", `${n} rounds to ${r}.`); }
  _common_fractions_5(d) { const den = choice([2, 3, 4, 5, 6, 8]); const n = ri(1, den - 1); const whole = den * ri(2, 6); return base("common_fractions_5", `Calculate ${n}/${den} of ${whole}.`, Math.floor(whole * n / den), d, `Divide ${whole} by ${den}, then multiply by ${n}.`, `(${whole} ÷ ${den}) × ${n} = ${Math.floor(whole * n / den)}.`); }
  _decimal_fractions_5(d) { const a = Math.round((Math.random() * 49 + 1) * 10) / 10, b = Math.round((Math.random() * 49 + 1) * 10) / 10; return base("decimal_fractions_5", `Calculate: ${a} + ${b}`, Math.round((a + b) * 10) / 10, d, "Line up the decimal points before adding.", `${a} + ${b} = ${Math.round((a + b) * 10) / 10}.`); }
  _geometry_5(d) { return this._shapeQuestion("geometry_5", d); }
  _data_5(d) { const vals = Array.from({ length: 5 }, () => ri(1, 20)); const mean = vals.reduce((s, v) => s + v, 0) / vals.length; const ans = Number.isInteger(mean) ? mean : Math.round(mean * 10) / 10; return base("data_5", `Find the mean of: ${vals.join(", ")}`, ans, d, "Add them all up, then divide by how many there are.", `Sum = ${vals.reduce((s, v) => s + v, 0)}, ÷ 5 = ${ans}.`); }

  // ---------- Grade 6 ----------
  _whole_numbers_6(d) { const [lo, hi] = this._range(1000000, 9999999); const n = ri(lo, hi); const r = Math.round(n / 10000) * 10000; return base("whole_numbers_6", `Round ${n} to the nearest 10 000.`, r, d, "Look at the thousands digit.", `${n} rounds to ${r}.`); }
  _fractions_6(d) { const den = choice([4, 5, 8, 10, 20]); const n1 = ri(1, den - 1); const dec = Math.round((n1 / den) * 100) / 100; return base("fractions_6", `Convert ${n1}/${den} to a decimal.`, dec, d, `Divide ${n1} by ${den}.`, `${n1} ÷ ${den} = ${dec}.`); }
  _percentages_6(d) { const whole = choice([50, 80, 100, 200, 400]), pct = choice([10, 20, 25, 50]); return base("percentages_6", `Calculate ${pct}% of ${whole}.`, Math.floor(whole * pct / 100), d, `${pct}% means ${pct} out of 100.`, `(${whole} ÷ 100) × ${pct} = ${Math.floor(whole * pct / 100)}.`); }
  _ratio_6(d) { const a = ri(2, 12), b = ri(2, 12), g = gcd(a, b); return base("ratio_6", `Simplify the ratio ${a}:${b}`, `${a / g}:${b / g}`, d, "Divide both sides by their highest common factor.", `HCF of ${a} and ${b} is ${g}. ${a}:${b} simplifies to ${a / g}:${b / g}.`); }
  _geometry_6(d) { return this._shapeQuestion("geometry_6", d); }
  _data_6(d) { const vals = Array.from({ length: 6 }, () => ri(1, 50)); return base("data_6", `Find the range of: ${vals.join(", ")}`, Math.max(...vals) - Math.min(...vals), d, "Range = biggest value − smallest value.", `${Math.max(...vals)} − ${Math.min(...vals)} = ${Math.max(...vals) - Math.min(...vals)}.`); }
}
