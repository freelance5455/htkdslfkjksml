// Port of engine/programme_engine.py — manages Programme -> Tutors -> Groups ->
// Students -> Sessions -> Performance. Local storage key "learnly:programme" in
// place of data/programme/programme.json. Never duplicates student performance —
// every mastery/streak/XP figure is read live from the student's own record.
import { readStudentRaw } from "../db.js";

const WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const KEY = "learnly:programme";
const DEFAULT_PROGRAMME = { name: "The Elites Academy", tutors: [], groups: [] };
function newId(prefix) { return prefix + Math.floor(10000 + Math.random() * 90000); }

export class ProgrammeEngine {
  constructor() { this.data = this._load(); }
  _load() {
    try { const raw = localStorage.getItem(KEY); if (raw) return JSON.parse(raw); } catch { /* fall through */ }
    return structuredClone(DEFAULT_PROGRAMME);
  }
  save() { localStorage.setItem(KEY, JSON.stringify(this.data)); }

  // ---------------- TUTORS ----------------
  addTutor(name, subjects = null, grades = null) {
    const tutor = { id: newId("T"), name, subjects: subjects || ["Mathematics"], grades: grades || [], active: true, created_at: new Date().toISOString() };
    this.data.tutors.push(tutor);
    this.save();
    return tutor;
  }
  listTutors(activeOnly = false) { return activeOnly ? this.data.tutors.filter((t) => t.active !== false) : this.data.tutors; }
  getTutor(id) { return this.data.tutors.find((t) => t.id === id) || null; }
  deactivateTutor(id) { const t = this.getTutor(id); if (t) { t.active = false; this.save(); } return t; }
  reactivateTutor(id) { const t = this.getTutor(id); if (t) { t.active = true; this.save(); } return t; }
  tutorWorkload(id) {
    const groups = this.data.groups.filter((g) => g.tutor_id === id);
    const students = new Set();
    groups.forEach((g) => g.students.forEach((s) => students.add(s)));
    return { groups: groups.length, students: students.size };
  }

  // ---------------- GROUPS ----------------
  addGroup(name, grade, subject, tutorId, schedule = null) {
    const group = { id: newId("G"), name, grade, subject, tutor_id: tutorId, schedule: schedule || [], students: [], created_at: new Date().toISOString() };
    this.data.groups.push(group);
    this.save();
    return group;
  }
  listGroups(tutorId = null) { return tutorId ? this.data.groups.filter((g) => g.tutor_id === tutorId) : this.data.groups; }
  getGroup(id) { return this.data.groups.find((g) => g.id === id) || null; }
  deleteGroup(id) { this.data.groups = this.data.groups.filter((g) => g.id !== id); this.save(); }
  enrolStudent(groupId, code) {
    const g = this.getGroup(groupId); if (!g) return false;
    code = code.trim().toUpperCase();
    if (!g.students.includes(code)) g.students.push(code);
    this.save();
    return true;
  }
  removeStudent(groupId, code) {
    const g = this.getGroup(groupId); if (!g) return false;
    code = code.trim().toUpperCase();
    g.students = g.students.filter((c) => c !== code);
    this.save();
    return true;
  }
  addSessionSlot(groupId, day, time) {
    const g = this.getGroup(groupId); if (!g) return false;
    if (!WEEKDAYS.includes(day)) throw new Error(`'${day}' is not a valid weekday`);
    g.schedule.push({ day, time });
    this.save();
    return true;
  }

  // ---------------- STUDENT DATA (read-only, always live) ----------------
  studentSnapshot(code) {
    const s = readStudentRaw(code);
    if (!s) return { code, found: false };
    const mastery = s.mastery || {};
    const vals = Object.values(mastery);
    const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
    return { code, found: true, name: s.name || code, grade: s.grade ?? 8, avg_mastery: avg, streak: s.streak || 0, xp: s.xp || 0 };
  }
  groupRoster(groupId) {
    const g = this.getGroup(groupId);
    return g ? g.students.map((c) => this.studentSnapshot(c)) : [];
  }

  // ---------------- DASHBOARD / REPORTS ----------------
  allEnrolledCodes() {
    const codes = new Set();
    this.data.groups.forEach((g) => g.students.forEach((c) => codes.add(c)));
    return codes;
  }
  sessionsToday() {
    const today = WEEKDAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1]; // JS Sunday=0 -> align to Python Monday=0 week
    const result = [];
    this.data.groups.forEach((g) => (g.schedule || []).forEach((slot) => {
      if (slot.day === today) result.push({ group: g.name, time: slot.time, grade: g.grade, subject: g.subject });
    }));
    return result.sort((a, b) => (a.time < b.time ? -1 : 1));
  }
  studentsNeedingAttention(threshold = 0.5) {
    const attention = [];
    this.allEnrolledCodes().forEach((code) => {
      const snap = this.studentSnapshot(code);
      if (snap.found && snap.avg_mastery < threshold) attention.push(snap);
    });
    return attention.sort((a, b) => a.avg_mastery - b.avg_mastery);
  }
  dashboardStats() {
    const codes = this.allEnrolledCodes();
    const masteryValues = [];
    codes.forEach((code) => { const snap = this.studentSnapshot(code); if (snap.found && snap.avg_mastery > 0) masteryValues.push(snap.avg_mastery); });
    const avgMastery = masteryValues.length ? masteryValues.reduce((a, b) => a + b, 0) / masteryValues.length : 0;
    return {
      programme_name: this.data.name, tutor_count: this.listTutors(true).length,
      group_count: this.data.groups.length, student_count: codes.size, avg_mastery: avgMastery,
      sessions_today: this.sessionsToday(), attention: this.studentsNeedingAttention()
    };
  }
}
