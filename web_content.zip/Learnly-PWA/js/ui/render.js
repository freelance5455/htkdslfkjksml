// Port of ui/render.py — every question "diagram" and lab "chart" is drawn live on a
// <canvas>, never a static image file, so questions can be regenerated infinitely.
export const PALETTE = ["#3157D5", "#159A68", "#D64545", "#F5A623", "#8B5CF6", "#06B6D4", "#EC4899"];

function setupCanvas(canvas, w, h, bg = "#ffffff") {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + "px";
  canvas.style.height = h + "px";
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  ctx.lineCap = "round";
  return ctx;
}
function ln(ctx, x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
function dot(ctx, cx, cy, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill(); }
function circ(ctx, cx, cy, r) { ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke(); }
function txt(ctx, s, x, y, color = "#222", align = "left") { ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = "alphabetic"; ctx.fillText(s, x, y); }
function ctxt(ctx, s, x, y, color = "#222") { ctx.fillStyle = color; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(s, x, y); }

function drawGrid(ctx, w, h, span = 34) {
  const step = Math.min(w, h) / span;
  const cx = w / 2, cy = h / 2;
  ctx.strokeStyle = "#e0e0e0"; ctx.lineWidth = 1;
  for (let x = cx; x < w; x += step) ln(ctx, x, 0, x, h);
  for (let x = cx; x > 0; x -= step) ln(ctx, x, 0, x, h);
  for (let y = cy; y < h; y += step) ln(ctx, 0, y, w, y);
  for (let y = cy; y > 0; y -= step) ln(ctx, 0, y, w, y);
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, 0, cy, w, cy);
  ln(ctx, cx, 0, cx, h);
}

// ================= QUESTION / GEOMETRY DIAGRAMS =================
export function drawDiagram(canvas, diagram, w = 320, h = 240) {
  const ctx = setupCanvas(canvas, w, h);
  if (!diagram) return;
  const d = diagram, kind = d.type;
  ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 3;
  ctx.font = "bold 14px sans-serif";

  if (kind === "right_triangle") {
    const margin = 40, base = Math.min(w, h) - 2 * margin, x0 = margin, y0 = h - margin;
    ln(ctx, x0, y0, x0 + base, y0);
    ln(ctx, x0, y0, x0, y0 - base * 0.75);
    ln(ctx, x0 + base, y0, x0, y0 - base * 0.75);
    ctx.strokeRect(x0, y0 - 14, 14, 14);
    const { a, b, c, find } = d;
    if ("a" in d) txt(ctx, `${find !== "a" ? a : "?"} cm`, x0 + base / 2 - 10, y0 + 22);
    if ("b" in d) txt(ctx, `${find !== "b" ? b : "?"} cm`, x0 - 34, y0 - base * 0.35);
    if ("c" in d) txt(ctx, `${find !== "c" ? c : "?"} cm`, x0 + base / 2 - 10, y0 - base * 0.45);
  } else if (kind === "triangle_bh") {
    const margin = 40, base = Math.min(w, h) - 2 * margin, x0 = margin, y0 = h - margin;
    const apex = { x: x0 + base * 0.4, y: y0 - base * 0.7 };
    ln(ctx, x0, y0, x0 + base, y0);
    ln(ctx, x0, y0, apex.x, apex.y);
    ln(ctx, x0 + base, y0, apex.x, apex.y);
    ctx.save(); ctx.strokeStyle = "#999"; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
    ln(ctx, apex.x, apex.y, apex.x, y0);
    ctx.restore();
    ctx.strokeStyle = "#3157D5";
    txt(ctx, `base = ${d.b ?? "?"} cm`, x0 + base / 2 - 20, y0 + 22);
    txt(ctx, `h = ${d.h ?? "?"} cm`, apex.x + 6, (apex.y + y0) / 2);
  } else if (kind === "rectangle") {
    const margin = 40, rw = Math.min(w - 2 * margin, 220), rh = Math.min(h - 2 * margin, 140);
    const x0 = (w - rw) / 2, y0 = (h - rh) / 2;
    ctx.strokeRect(x0, y0, rw, rh);
    txt(ctx, `l = ${d.l ?? "?"} cm`, x0 + rw / 2 - 20, y0 - 10);
    txt(ctx, `w = ${d.w ?? "?"}`, x0 - 34, y0 + rh / 2);
  } else if (kind === "circle") {
    const rPx = Math.min(w, h) / 2 - 40, cx = w / 2, cy = h / 2;
    circ(ctx, cx, cy, rPx);
    ln(ctx, cx, cy, cx + rPx, cy);
    txt(ctx, `r = ${d.r ?? "?"} cm`, cx + rPx / 2 - 10, cy - 6);
  } else if (kind === "straight_line_angles") {
    const y = h / 2;
    ln(ctx, 30, y, w - 30, y);
    const vx = w * 0.55;
    ln(ctx, vx, y, vx - 60, y - 70);
    txt(ctx, `${d.known ?? "?"}°`, vx - 55, y - 40);
    txt(ctx, "x", vx + 10, y - 20);
  } else if (kind === "angles_at_point") {
    const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 30;
    [0, 100, 220].forEach((ang) => { const rad = (ang * Math.PI) / 180; ln(ctx, cx, cy, cx + r * Math.cos(rad), cy - r * Math.sin(rad)); });
    txt(ctx, `${d.a ?? "?"}°`, cx + 20, cy - 30);
    txt(ctx, `${d.b ?? "?"}°`, cx - 60, cy - 30);
    txt(ctx, "y", cx - 20, cy + 45);
  } else if (kind === "vertical_angles") {
    const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 30;
    ln(ctx, cx - r, cy - r * 0.4, cx + r, cy + r * 0.4);
    ln(ctx, cx - r, cy + r * 0.4, cx + r, cy - r * 0.4);
    txt(ctx, `${d.known ?? "?"}°`, cx + 12, cy - 30);
    txt(ctx, "?", cx - 40, cy + 40);
  } else if (kind === "translation" || kind === "reflect_x" || kind === "reflect_y") {
    drawGrid(ctx, w, h);
    const scale = Math.min(w, h) / 34, cx = w / 2, cy = h / 2;
    const x = d.x ?? 0, y = d.y ?? 0;
    const p1 = { x: cx + x * scale, y: cy - y * scale };
    ctx.strokeStyle = "#3157D5";
    dot(ctx, p1.x, p1.y, 6, "#3157D5");
    txt(ctx, `(${x},${y})`, p1.x + 8, p1.y - 8);
    let p2;
    if (kind === "translation") { const a = d.a ?? 0, b = d.b ?? 0; p2 = { x: cx + (x + a) * scale, y: cy - (y + b) * scale }; }
    else if (kind === "reflect_x") p2 = { x: cx + x * scale, y: cy + y * scale };
    else p2 = { x: cx - x * scale, y: cy - y * scale };
    dot(ctx, p2.x, p2.y, 6, "#D64545");
    ctx.save(); ctx.strokeStyle = "#999"; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
    ln(ctx, p1.x, p1.y, p2.x, p2.y);
    ctx.restore();
  }
}

// ================= CHARTS (Data Lab / Probability Lab) =================
export function drawChart(canvas, values, labels, mode = "bar", w = 320, h = 260) {
  const ctx = setupCanvas(canvas, w, h);
  if (!values || !values.length) { txt(ctx, "No data yet", w / 2 - 30, h / 2, "#888"); return; }
  labels = labels || values.map((_, i) => String(i + 1));
  if (mode === "bar") drawBar(ctx, values, labels, w, h);
  else if (mode === "pie") drawPie(ctx, values, labels, w, h);
  else if (mode === "line") drawLine(ctx, values, labels, w, h);
  else if (mode === "box") drawBox(ctx, values, w, h);
  else if (mode === "histogram") drawHistogram(ctx, values, w, h);
}

function drawBar(ctx, values, labels, w, h) {
  const margin = 36, top = 20, chartH = h - margin - top;
  const vmax = Math.max(...values) || 1, n = values.length, bw = (w - 2 * margin) / n;
  ctx.font = "10px sans-serif";
  values.forEach((v, i) => {
    const barH = (v / vmax) * chartH, x = margin + i * bw + bw * 0.15, y = h - margin - barH;
    ctx.fillStyle = PALETTE[i % PALETTE.length];
    ctx.fillRect(x, y, bw * 0.7, barH);
    txt(ctx, String(labels[i]), x + bw * 0.35, h - margin + 16, "#333", "center");
    txt(ctx, String(v), x + bw * 0.35, y - 6, "#333", "center");
  });
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, margin, h - margin, w - margin, h - margin);
}

function drawPie(ctx, values, labels, w, h) {
  const size = Math.min(w, h) - 70, cx = w / 2, cy = h / 2 - 5, r = size / 2;
  const total = values.reduce((a, b) => a + b, 0) || 1;
  ctx.font = "bold 11px sans-serif";
  let start = -Math.PI / 2;
  values.forEach((v, i) => {
    const span = (2 * Math.PI * v) / total;
    ctx.fillStyle = PALETTE[i % PALETTE.length];
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, start, start + span); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.stroke();
    const mid = start + span / 2;
    const lx = cx + (r + 20) * Math.cos(mid), ly = cy + (r + 20) * Math.sin(mid);
    const pct = Math.round((100 * v) / total);
    ctxt(ctx, `${labels[i]} (${pct}%)`, lx, ly, "#333");
    start += span;
  });
}

function drawLine(ctx, values, labels, w, h) {
  const margin = 36, top = 20, chartH = h - margin - top;
  const vmax = Math.max(...values) || 1, vmin = Math.min(...values), n = values.length;
  const stepX = (w - 2 * margin) / Math.max(1, n - 1);
  const pts = values.map((v, i) => ({ x: margin + i * stepX, y: h - margin - ((v - vmin) / (vmax - vmin + 1e-9)) * chartH }));
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, margin, h - margin, w - margin, h - margin);
  ctx.strokeStyle = PALETTE[0]; ctx.lineWidth = 3;
  ctx.beginPath(); pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y))); ctx.stroke();
  ctx.font = "9px sans-serif";
  pts.forEach((p, i) => {
    dot(ctx, p.x, p.y, 4, PALETTE[0]);
    txt(ctx, String(values[i]), p.x - 8, p.y - 10, "#333");
    txt(ctx, String(labels[i]), p.x - 8, h - margin + 14, "#333");
  });
}

function drawBox(ctx, values, w, h) {
  const sv = [...values].sort((a, b) => a - b), n = sv.length;
  const lo = sv[0], hi = sv[n - 1];
  const q1 = sv[Math.floor(n / 4)];
  const med = n % 2 ? sv[(n - 1) / 2] : (sv[n / 2 - 1] + sv[n / 2]) / 2;
  const q3 = sv[Math.floor((3 * n) / 4)];
  const margin = 40, span = (hi - lo) || 1;
  const X = (val) => margin + ((val - lo) / span) * (w - 2 * margin);
  const midY = h / 2;
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, X(lo), midY, X(q1), midY);
  ln(ctx, X(q3), midY, X(hi), midY);
  ctx.fillStyle = "#a9bdf3"; ctx.fillRect(X(q1), midY - 30, X(q3) - X(q1), 60);
  ctx.strokeRect(X(q1), midY - 30, X(q3) - X(q1), 60);
  ctx.strokeStyle = PALETTE[2]; ctx.lineWidth = 3;
  ln(ctx, X(med), midY - 30, X(med), midY + 30);
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2; ctx.font = "10px sans-serif";
  [[lo, "min"], [q1, "Q1"], [med, "median"], [q3, "Q3"], [hi, "max"]].forEach(([val, label]) => {
    ln(ctx, X(val), midY - 36, X(val), midY + 36);
    txt(ctx, `${label} ${Math.round(val * 100) / 100}`, X(val) - 16, midY + 52, "#333");
  });
}

function drawHistogram(ctx, values, w, h) {
  const lo = Math.min(...values), hi = Math.max(...values), span = (hi - lo) || 1;
  const nBins = Math.min(8, Math.max(4, Math.floor(values.length / 2)));
  const binW = span / nBins;
  const bins = new Array(nBins).fill(0);
  values.forEach((v) => { const idx = binW ? Math.min(nBins - 1, Math.floor((v - lo) / binW)) : 0; bins[idx]++; });
  const labels = Array.from({ length: nBins }, (_, i) => `${Math.round(lo + i * binW)}-${Math.round(lo + (i + 1) * binW)}`);
  drawBar(ctx, bins, labels, w, h);
}

// ================= NATURAL SCIENCES DIAGRAMS =================
export function drawScienceDiagram(canvas, kind, w = 320, h = 240) {
  const ctx = setupCanvas(canvas, w, h);
  ctx.font = "bold 12px sans-serif";

  if (kind === "states_of_matter") {
    const labels = ["Solid", "Liquid", "Gas"];
    labels.forEach((label, i) => {
      const cx = w / 6 + (i * w) / 3;
      const box = { left: cx - w / 8, top: 20, w: w / 4, h: h - 60 };
      ctx.strokeStyle = "#333"; ctx.lineWidth = 1; ctx.strokeRect(box.left, box.top, box.w, box.h);
      ctx.fillStyle = "#3157D5";
      if (label === "Solid") {
        for (let row = 0; row < 4; row++) for (let col = 0; col < 3; col++) {
          const px = box.left + 10 + (col * (box.w - 20)) / 2, py = box.top + 15 + (row * (box.h - 30)) / 3;
          dot(ctx, px, py, 5, "#3157D5");
        }
      } else if (label === "Liquid") {
        for (let i2 = 0; i2 < 12; i2++) {
          const px = box.left + 8 + Math.random() * (box.w - 16), py = box.top + box.h * 0.4 + Math.random() * (box.h * 0.55);
          dot(ctx, px, py, 5, "#3157D5");
        }
      } else {
        for (let i2 = 0; i2 < 10; i2++) {
          const px = box.left + 8 + Math.random() * (box.w - 16), py = box.top + 8 + Math.random() * (box.h - 16);
          dot(ctx, px, py, 4, "#3157D5");
        }
      }
      txt(ctx, label, box.left + box.w / 2, box.top + box.h + 20, "#333", "center");
    });
  } else if (kind === "water_cycle") {
    dot(ctx, w * 0.8, h * 0.18, 20, "#F5A623");
    ctx.fillStyle = "#89CFF0"; ctx.fillRect(0, h * 0.75, w, h * 0.25);
    ctx.fillStyle = "#e0e0e0";
    ctx.beginPath(); ctx.ellipse(w * 0.35, h * 0.22, 30, 18, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(w * 0.48, h * 0.2, 24, 16, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
    ln(ctx, w * 0.25, h * 0.75, w * 0.32, h * 0.3);
    ln(ctx, w * 0.45, h * 0.32, w * 0.4, h * 0.7);
    ctx.font = "9px sans-serif";
    txt(ctx, "Evaporation", w * 0.05, h * 0.55, "#333");
    txt(ctx, "Precipitation", w * 0.5, h * 0.55, "#333");
    txt(ctx, "Condensation", w * 0.25, h * 0.12, "#333");
  } else if (kind === "food_chain") {
    const items = ["Sun", "Grass", "Grasshopper", "Frog", "Snake"];
    const seg = w / items.length;
    ctx.font = "bold 9px sans-serif";
    items.forEach((item, i) => {
      const cx = seg * i + seg / 2, cy = h / 2;
      dot(ctx, cx, cy, 28, PALETTE[i % PALETTE.length]);
      ctxt(ctx, item, cx, cy, "#fff");
      if (i < items.length - 1) { ctx.strokeStyle = "#333"; ctx.lineWidth = 2; ln(ctx, cx + 28, cy, cx + seg - 28, cy); }
    });
  } else if (kind === "simple_circuit") {
    ctx.strokeStyle = "#333"; ctx.lineWidth = 3;
    const rect = { left: 40, top: 40, w: w - 80, h: h - 100 };
    ctx.strokeRect(rect.left, rect.top, rect.w, rect.h);
    ln(ctx, rect.left, rect.top + rect.h / 2 - 10, rect.left, rect.top + rect.h / 2 + 10);
    ctx.font = "10px sans-serif";
    txt(ctx, "Battery", rect.left - 30, rect.top + rect.h / 2 + 30, "#333");
    ctx.fillStyle = "#F5A623";
    dot(ctx, rect.left + rect.w, rect.top + rect.h / 2, 14, "#F5A623");
    txt(ctx, "Bulb", rect.left + rect.w - 15, rect.top + rect.h / 2 + 32, "#333");
  }
}

// ================= PAPER -> PNG EXPORT (in place of ui/pillow_paper.py) =================
function wrapText(ctx, text, maxWidth) {
  const words = String(text).split(/\s+/);
  const lines = [];
  let line = "";
  words.forEach((word) => {
    const test = line ? line + " " + word : word;
    if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = word; }
    else line = test;
  });
  if (line) lines.push(line);
  return lines;
}

export function exportPaperImage(paper, showMemo = true) {
  const W = 800, PAD = 36, LINE = 22, DIAG_W = 260, DIAG_H = 170;
  const measure = document.createElement("canvas").getContext("2d");
  measure.font = "15px sans-serif";

  let estHeight = 210;
  const layout = paper.questions.map((q) => {
    measure.font = "15px sans-serif";
    const qLines = wrapText(measure, q.question, W - 2 * PAD);
    let h = 34 + qLines.length * LINE + 14;
    if (q.diagram) h += DIAG_H + 12;
    let memoLines = [];
    if (showMemo) {
      measure.font = "13px sans-serif";
      memoLines = [
        ...wrapText(measure, `Answer: ${q.answer}`, W - 2 * PAD),
        ...wrapText(measure, `Working: ${q.explanation}`, W - 2 * PAD),
        ...wrapText(measure, `Technique: ${q.hint}`, W - 2 * PAD)
      ];
      h += memoLines.length * 18 + 10;
    }
    estHeight += h + 18;
    return { q, qLines, memoLines, h };
  });

  const canvas = document.createElement("canvas");
  const ctx = setupCanvas(canvas, W, estHeight, "#ffffff");
  let y = PAD;

  ctx.fillStyle = "#111"; ctx.textAlign = "left";
  ctx.font = "bold 22px sans-serif";
  ctx.fillText(`${paper.grade_label || "Grade 8"} Mathematics — ${paper.type}`, PAD, y + 22); y += 34;
  ctx.font = "13px sans-serif"; ctx.fillStyle = "#555";
  ctx.fillText(`Term ${paper.term} • ${paper.difficulty} • ${paper.marks} marks • ${paper.time_minutes || 45} min`, PAD, y + 16); y += 18;
  ctx.fillText(`Student: ${paper.student_code || ""} • Created: ${(paper.created_at || "").slice(0, 16).replace("T", " ")}`, PAD, y + 16); y += 30;
  ctx.strokeStyle = "#ccc"; ctx.beginPath(); ctx.moveTo(PAD, y); ctx.lineTo(W - PAD, y); ctx.stroke(); y += 22;

  layout.forEach(({ q, qLines, memoLines }) => {
    ctx.font = "bold 15px sans-serif"; ctx.fillStyle = "#111";
    ctx.fillText(`Q${q.number}. (${q.marks} marks) — ${q.topic_name}`, PAD, y + 15); y += 26;
    ctx.font = "15px sans-serif";
    qLines.forEach((l) => { ctx.fillText(l, PAD, y + 15); y += LINE; });
    y += 6;
    if (q.diagram) {
      const dc = document.createElement("canvas");
      drawDiagram(dc, q.diagram, DIAG_W, DIAG_H);
      ctx.drawImage(dc, PAD, y, DIAG_W, DIAG_H);
      y += DIAG_H + 12;
    }
    if (showMemo) {
      ctx.font = "13px sans-serif"; ctx.fillStyle = "#1a6b3c";
      memoLines.forEach((l) => { ctx.fillText(l, PAD, y + 13); y += 18; });
      ctx.fillStyle = "#111";
      y += 8;
    }
    ctx.strokeStyle = "#eee"; ctx.beginPath(); ctx.moveTo(PAD, y); ctx.lineTo(W - PAD, y); ctx.stroke();
    y += 18;
  });

  canvas.toBlob((blob) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${paper.paper_id}.png`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }, "image/png");
}
