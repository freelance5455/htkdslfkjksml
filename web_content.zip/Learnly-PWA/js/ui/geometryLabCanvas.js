// Port of ui/geometry_canvas.py's GeometryLabCanvas — tap points on a grid to build a
// shape; measurements are computed live, matching the Qt mouse-press canvas 1:1.
const STEP = 24;
export const MODES = ["Point", "Line Segment", "Triangle", "Rectangle", "Circle", "Angle", "Coordinate Plane"];
const LIMITS = { Point: 1, "Line Segment": 2, Triangle: 3, Rectangle: 2, Circle: 2, Angle: 3, "Coordinate Plane": 999 };

function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }

export class GeometryLabCanvas {
  constructor(canvas) {
    this.canvas = canvas;
    this.mode = "Triangle";
    this.points = [];
    this.showMeasurements = true;
    canvas.addEventListener("pointerdown", (e) => this._onTap(e));
    this._resize();
    window.addEventListener("resize", () => { this._resize(); this.redraw(); });
  }
  _resize() {
    const w = this.canvas.parentElement ? this.canvas.parentElement.clientWidth : 320;
    this.w = Math.max(260, Math.min(w, 520));
    this.h = 340;
  }
  clear() { this.points = []; this.redraw(); }
  _onTap(e) {
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    this.points.push({ x, y });
    const limit = LIMITS[this.mode] ?? 3;
    if (this.points.length > limit) this.points.shift();
    this.redraw();
  }

  redraw() {
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = this.w * dpr;
    this.canvas.height = this.h * dpr;
    this.canvas.style.width = this.w + "px";
    this.canvas.style.height = this.h + "px";
    const ctx = this.canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, this.w, this.h);

    ctx.strokeStyle = "#eee"; ctx.lineWidth = 1;
    for (let gx = 0; gx < this.w; gx += STEP) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, this.h); ctx.stroke(); }
    for (let gy = 0; gy < this.h; gy += STEP) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(this.w, gy); ctx.stroke(); }

    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 3; ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#3157D5";
    const pts = this.points;

    if (this.mode === "Point" && pts.length >= 1) {
      const p = pts[pts.length - 1];
      ctx.beginPath(); ctx.arc(p.x, p.y, 5, 0, Math.PI * 2); ctx.fill();
    } else if (this.mode === "Line Segment" && pts.length >= 2) {
      const [a, b] = pts.slice(-2);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      if (this.showMeasurements) ctx.fillText(`${(dist(a, b) / STEP).toFixed(1)} u`, (a.x + b.x) / 2, (a.y + b.y) / 2);
    } else if (this.mode === "Triangle" && pts.length >= 3) {
      const [a, b, c] = pts.slice(-3);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.closePath(); ctx.stroke();
      if (this.showMeasurements) {
        [[a, b], [b, c], [c, a]].forEach(([s1, s2]) => ctx.fillText(`${(dist(s1, s2) / STEP).toFixed(1)}u`, (s1.x + s2.x) / 2, (s1.y + s2.y) / 2));
      }
    } else if (this.mode === "Rectangle" && pts.length >= 2) {
      const [a, b] = pts.slice(-2);
      const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y), rw = Math.abs(a.x - b.x), rh = Math.abs(a.y - b.y);
      ctx.strokeRect(x, y, rw, rh);
      if (this.showMeasurements) {
        ctx.fillText(`w=${(rw / STEP).toFixed(1)}u`, x + rw / 2, y - 6);
        ctx.fillText(`h=${(rh / STEP).toFixed(1)}u`, x - 30, y + rh / 2);
      }
    } else if (this.mode === "Circle" && pts.length >= 2) {
      const [a, b] = pts.slice(-2);
      const r = dist(a, b);
      ctx.beginPath(); ctx.arc(a.x, a.y, r, 0, Math.PI * 2); ctx.stroke();
      if (this.showMeasurements) ctx.fillText(`r=${(r / STEP).toFixed(1)}u`, a.x + 6, a.y - 6);
    } else if (this.mode === "Angle" && pts.length >= 3) {
      const [vertex, p1, p2] = pts.slice(-3);
      ctx.beginPath(); ctx.moveTo(vertex.x, vertex.y); ctx.lineTo(p1.x, p1.y); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(vertex.x, vertex.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();
      const v1 = Math.atan2(p1.y - vertex.y, p1.x - vertex.x);
      const v2 = Math.atan2(p2.y - vertex.y, p2.x - vertex.x);
      let deg = Math.abs((v2 - v1) * 180 / Math.PI);
      if (deg > 180) deg = 360 - deg;
      ctx.fillText(`${deg.toFixed(0)}°`, vertex.x + 10, vertex.y + 10);
    } else if (this.mode === "Coordinate Plane") {
      const cx = this.w / 2, cy = this.h / 2;
      ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(this.w, cy); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, this.h); ctx.stroke();
      ctx.fillStyle = "#3157D5";
      pts.forEach((p) => {
        ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill();
        const gx = Math.round((p.x - cx) / STEP), gy = Math.round((cy - p.y) / STEP);
        ctx.fillText(`(${gx},${gy})`, p.x + 6, p.y - 6);
      });
    }
  }
}
