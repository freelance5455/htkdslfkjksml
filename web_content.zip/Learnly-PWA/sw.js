// Learnly service worker — cache-first, fully offline after first load.
// Bump CACHE_NAME to force an update when files change.
const CACHE_NAME = "learnly-v1";

const CORE_ASSETS = [
  "./", "./index.html", "./manifest.json",
  "./css/style.css",
  "./icons/icon-192.png", "./icons/icon-512.png",
  "./content/curriculum_all_grades.json",
  "./content/tips_and_tricks.json",
  "./content/grade8/curriculum.json",
  "./content/grade8/science/curriculum.json",
  "./js/app.js", "./js/db.js", "./js/theme.js",
  "./js/engines/gradeManager.js", "./js/engines/foundationEngine.js",
  "./js/engines/questionEngine.js", "./js/engines/unifiedEngine.js",
  "./js/engines/answerCheck.js", "./js/engines/adaptive.js",
  "./js/engines/mastery.js", "./js/engines/economyEngine.js",
  "./js/engines/gamificationEngine.js", "./js/engines/paperEngine.js",
  "./js/engines/programmeEngine.js", "./js/engines/dataEngine.js",
  "./js/engines/probabilityEngine.js", "./js/engines/contentLoader.js",
  "./js/engines/timerEngine.js",
  "./js/ui/render.js", "./js/ui/geometryLabCanvas.js", "./js/ui/widgets.js",
  "./js/screens/login.js", "./js/screens/home.js", "./js/screens/learn.js",
  "./js/screens/practice.js", "./js/screens/papers.js", "./js/screens/profile.js",
  "./js/screens/settings.js", "./js/screens/labs.js", "./js/screens/tutor.js",
  "./js/screens/programme.js", "./js/screens/gamification.js", "./js/screens/science.js"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Cache-first for everything same-origin; anything new gets cached as it's fetched
// (covers the per-topic JSON files not in CORE_ASSETS) so the app keeps working offline.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          if (response && response.status === 200) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return response;
        })
        .catch(() => cached);
    })
  );
});
