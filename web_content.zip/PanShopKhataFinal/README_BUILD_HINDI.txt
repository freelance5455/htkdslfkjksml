PAN SHOP KHATA - FINAL ANDROID PROJECT

Features kept:
- User-defined fixed rate for every item.
- Udhari: enter only quantity; amount = quantity x saved item rate.
- History: delete any transaction; customer balance is recalculated from remaining transactions.
- INTERNET permission and WebView DOM storage enabled.
- Release build uses Android's debug signing config so the generated release APK is signed and installable.

BUILD:
Open this folder in Android Studio, let Gradle sync, then Build > Generate APKs, or run: gradlew assembleRelease
Output: app/build/outputs/apk/release/app-release.apk

NOTE: The release APK is debug-signed. If Android refuses to update an older APK signed with another key, uninstall the old app once and install the new APK.
