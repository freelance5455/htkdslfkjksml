# Word Sum Calculator — Android project

A=1, B=2, ... Z=26 word-sum calculator.
The app works offline because the calculator HTML is bundled inside the APK.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated APK will be under:
app/build/outputs/apk/debug/app-debug.apk
