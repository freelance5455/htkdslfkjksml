--[[
    Vortex Script Sample File (24 Categories Edition)
    Ready to use with Vortex Transcript Studio
]]

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

print("Vortex 24-Categories Studio Script loaded for: " .. LocalPlayer.Name)
