/**
 * THE MORNING HUB – update API for the mobile app (v7)
 * Lets the app change Payment, Status, Menu and Settings in your Google Sheet.
 * Paste this whole file into your Apps Script project (Extensions > Apps Script),
 * set your own PIN below, then Deploy > Manage deployments > pencil > New version.
 */
const MH_SHEET_ID = '1w4KIunEDDUuZs-RkvDAY0gbH6SPu3lTEarGQsTSPGa0';
const MH_PIN = 'CHANGE-ME-1234';           // <-- choose a PIN; type the same in the app

const MH_STATUS = ['New', 'Preparing', 'Out for delivery', 'Delivered', 'Cancelled'];
const MH_PAY = ['Pending', 'Paid'];

function doPost(e) { return mhHandle_(e); }   // if you already have doPost, call mhHandle_(e) from it when the body has "pin"

// Writes Status / Payment for a list of {id,status,pay}, then re-reads the sheet to confirm it really saved.
function mhApplyOrders_(ss, list) {
  const sh = ss.getSheetByName('Orders');
  const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h).trim().toLowerCase());
  const cId = head.indexOf('order id'), cSt = head.indexOf('status'), cPay = head.indexOf('payment');
  if (cId < 0 || cSt < 0 || cPay < 0) throw new Error('Orders columns not found (need Order ID, Status, Payment)');
  const last = sh.getLastRow();
  const ids = last > 1 ? sh.getRange(2, cId + 1, last - 1, 1).getValues() : [];
  const rowOf = {};
  ids.forEach((r, i) => { rowOf[String(r[0]).trim()] = i + 2; });
  const missing = [], want = [];
  let changed = 0;
  (list || []).forEach(o => {
    const row = rowOf[String(o.id).trim()];
    if (!row) { missing.push(o.id); return; }
    const stCell = sh.getRange(row, cSt + 1), payCell = sh.getRange(row, cPay + 1);
    if (MH_STATUS.indexOf(o.status) >= 0) { if (String(stCell.getValue()).trim() !== o.status) { stCell.setValue(o.status); changed++; } }
    if (MH_PAY.indexOf(o.pay) >= 0) { if (String(payCell.getValue()).trim() !== o.pay) { payCell.setValue(o.pay); changed++; } }
    want.push({ id: o.id, row: row, status: o.status, pay: o.pay });
  });
  SpreadsheetApp.flush();
  const bad = [];
  want.forEach(w => {
    const st = String(sh.getRange(w.row, cSt + 1).getValue()).trim();
    const pay = String(sh.getRange(w.row, cPay + 1).getValue()).trim();
    if ((MH_STATUS.indexOf(w.status) >= 0 && st !== w.status) || (MH_PAY.indexOf(w.pay) >= 0 && pay !== w.pay)) bad.push(w.id);
  });
  if (bad.length) throw new Error('Sheet did not keep Status/Payment for: ' + bad.join(', ') + ' (is the column a formula?)');
  return { changed: changed, missing: missing };
}

// Marks the Thank-you card status on the Flats sheet for the flat of the given Orders row (best effort).
function mhSetFlatCard_(ss, ordersSh, row, ohead, value) {
  try {
    const fl = ss.getSheetByName('Flats');
    if (!fl) return;
    const cW = ohead.indexOf('wing'), cF = ohead.indexOf('flat');
    if (cW < 0 || cF < 0) return;
    const wing = String(ordersSh.getRange(row, cW + 1).getDisplayValue()).trim();
    const flat = String(ordersSh.getRange(row, cF + 1).getDisplayValue()).trim();
    const parts = wing.split(' - ');
    const soc = parts.length > 1 ? parts[0].trim() : '';
    const wn = parts.length > 1 ? parts.slice(1).join(' - ').trim() : wing;
    const data = fl.getDataRange().getDisplayValues();
    const h = data[0].map(x => String(x).trim().toLowerCase());
    const cS = h.indexOf('society'), cWg = h.indexOf('wing'), cFl = h.indexOf('flat'), cC = h.indexOf('thank-you card');
    if (cWg < 0 || cFl < 0 || cC < 0) return;
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][cFl]).trim() === flat && String(data[i][cWg]).trim() === wn && (!soc || cS < 0 || String(data[i][cS]).trim() === soc)) {
        fl.getRange(i + 1, cC + 1).setValue(value);
        return;
      }
    }
  } catch (err) { /* Flats sheet is optional */ }
}

// 'yyyy-mm-dd' -> Date for the Menu tab's "Menu date" column; blank stays blank.
function mhMenuDate_(v) {
  const m = String(v || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : '';
}

function mhOrderCount_(ss) {
  const sh = ss.getSheetByName('Orders');
  const last = sh.getLastRow();
  if (last < 2) return 0;
  return sh.getRange(2, 2, last - 1, 1).getValues().filter(r => String(r[0]).trim() !== '').length;
}


/* ===================== v7: DAILY SUMMARY E-MAIL =====================
 * E-mail address is read from Settings!B28 and the send time from Settings!B29.
 * Auto mail: a timer (installed from the app) runs mhTick() every 5 minutes and sends
 * today's summary once a day at/after the time in B29.
 * FIRST TIME ONLY: in the editor pick  mhAuthorizeOnce  > Run > Allow (needs "send email" + "triggers").
 */
const MH_SUMMARY_EMAIL_CELL = 'B28';
const MH_SUMMARY_TIME_CELL = 'B29';

function mhAuthorizeOnce() {                      // run once from the editor to grant permissions
  MailApp.getRemainingDailyQuota();
  ScriptApp.getProjectTriggers();
  SpreadsheetApp.openById(MH_SHEET_ID).getName();
}

function mhEsc_(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

function mhInr_(n) {                              // Indian digit grouping: 1234567 -> ₹12,34,567
  n = Math.round((Number(n) || 0) * 100) / 100;
  const neg = n < 0; n = Math.abs(n);
  const parts = n.toFixed(n % 1 ? 2 : 0).split('.');
  let i = parts[0], last3 = i.slice(-3);
  const rest = i.slice(0, -3);
  if (rest) last3 = ',' + last3;
  i = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + last3;
  return (neg ? '-' : '') + '₹' + i + (parts[1] ? '.' + parts[1] : '');
}

function mhNormDate_(s) {
  s = String(s || '').trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return m[1] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[3]).slice(-2);
  m = s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/);
  if (m) return m[3] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2);
  return s;
}

function mhFindCol_(head, names) {
  for (let a = 0; a < names.length; a++) { const i = head.indexOf(names[a]); if (i >= 0) return i; }
  for (let a = 0; a < names.length; a++) { const i = head.findIndex(h => h.indexOf(names[a]) >= 0); if (i >= 0) return i; }
  return -1;
}

function mhPretty_(dateStr, tz) {
  const m = String(dateStr).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m ? Utilities.formatDate(new Date(+m[1], +m[2] - 1, +m[3], 12, 0, 0), tz, 'EEE, d MMM yyyy') : String(dateStr);
}

function mhValidEmails_(s) {
  const list = String(s || '').split(/[,;]/).map(x => x.trim()).filter(Boolean);
  if (!list.length) return [];
  return list.every(x => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)) ? list : [];
}

// "21:00", "9:30 PM", "21.30", "9 pm", "21:00:00" -> minutes after midnight (or null)
function mhParseTime_(s) {
  s = String(s || '').trim();
  let m = s.match(/^(\d{1,2})[:.](\d{2})(?::\d{2})?\s*([ap]\.?m\.?)?$/i);
  let h, mi;
  if (m) { h = +m[1]; mi = +m[2]; if (m[3]) { const pm = /^p/i.test(m[3]); if (h === 12) h = pm ? 12 : 0; else if (pm) h += 12; } }
  else {
    m = s.match(/^(\d{1,2})\s*([ap]\.?m\.?)$/i);
    if (!m) return null;
    h = +m[1]; mi = 0; const pm = /^p/i.test(m[2]); if (h === 12) h = pm ? 12 : 0; else if (pm) h += 12;
  }
  return (h > 23 || mi > 59) ? null : h * 60 + mi;
}

// Reads the e-mail (B28) and time (B29) from the Settings sheet; if those cells hold something else, looks for the labelled rows.
function mhSummaryCfg_(ss) {
  const sh = ss.getSheetByName('Settings');
  const rows = sh.getRange(1, 1, Math.max(sh.getLastRow(), 30), 2).getDisplayValues();
  const cellRow = a1 => +String(a1).replace(/\D/g, '');
  let eRow = cellRow(MH_SUMMARY_EMAIL_CELL), tRow = cellRow(MH_SUMMARY_TIME_CELL);
  const val = r => String((rows[r - 1] || [])[1] || '').trim();
  const key = r => String((rows[r - 1] || [])[0] || '').trim();
  if (!mhValidEmails_(val(eRow)).length) {
    for (let r = 1; r <= rows.length; r++) if (/e-?mail/i.test(key(r)) && mhValidEmails_(val(r)).length) { eRow = r; break; }
  }
  if (mhParseTime_(val(tRow)) === null) {
    for (let r = 1; r <= rows.length; r++) if (/time/i.test(key(r)) && /(mail|summary|report)/i.test(key(r)) && mhParseTime_(val(r)) !== null) { tRow = r; break; }
  }
  return { email: val(eRow), emails: mhValidEmails_(val(eRow)), emailKey: key(eRow), emailCell: 'B' + eRow,
           time: val(tRow), minutes: mhParseTime_(val(tRow)), timeKey: key(tRow), timeCell: 'B' + tRow };
}

function mhSettingsMap_(ss) {
  const sh = ss.getSheetByName('Settings'), m = {};
  sh.getRange(1, 1, sh.getLastRow(), 2).getDisplayValues().forEach(r => { const k = String(r[0]).trim(); if (k) m[k] = String(r[1]).trim(); });
  return m;
}

// All orders whose Delivery (menu) date is dateStr 'yyyy-MM-dd'.
function mhOrdersForDate_(ss, dateStr) {
  const sh = ss.getSheetByName('Orders'), tz = ss.getSpreadsheetTimeZone();
  const last = sh.getLastRow(), lc = sh.getLastColumn();
  if (last < 2) return [];
  const rg = sh.getRange(1, 1, last, lc), vals = rg.getValues(), disp = rg.getDisplayValues();
  const head = disp[0].map(h => String(h).trim().toLowerCase());
  const c = {
    id: mhFindCol_(head, ['order id', 'order no']), date: mhFindCol_(head, ['delivery date', 'delivery']), name: mhFindCol_(head, ['name']),
    phone: mhFindCol_(head, ['phone', 'whatsapp']), wing: mhFindCol_(head, ['wing']), flat: mhFindCol_(head, ['flat']),
    items: mhFindCol_(head, ['items', 'item']), plates: mhFindCol_(head, ['plates']), amount: mhFindCol_(head, ['amount']),
    mode: mhFindCol_(head, ['payment mode']), pay: mhFindCol_(head, ['payment']), status: mhFindCol_(head, ['status']),
    note: mhFindCol_(head, ['note']), newc: mhFindCol_(head, ['new customer']), card: mhFindCol_(head, ['thank-you card']),
    txn: mhFindCol_(head, ['payment txn id']), chk: mhFindCol_(head, ['payment id check'])
  };
  if (c.id < 0 || c.date < 0) throw new Error('Orders columns "Order ID" / "Delivery date" not found');
  const d = (i, k) => c[k] < 0 ? '' : String(disp[i][c[k]]).trim();
  const out = [];
  for (let i = 1; i < vals.length; i++) {
    if (!d(i, 'id')) continue;
    const dv = vals[i][c.date];
    const ds = dv instanceof Date ? Utilities.formatDate(dv, tz, 'yyyy-MM-dd') : mhNormDate_(disp[i][c.date]);
    if (ds !== dateStr) continue;
    out.push({ id: d(i, 'id'), name: d(i, 'name'), phone: d(i, 'phone'), wing: d(i, 'wing'), flat: d(i, 'flat'), items: d(i, 'items'),
               plates: c.plates < 0 ? 0 : Number(vals[i][c.plates]) || 0, amount: c.amount < 0 ? 0 : Number(vals[i][c.amount]) || 0,
               mode: d(i, 'mode'), pay: d(i, 'pay') || 'Pending', status: d(i, 'status') || 'New', note: d(i, 'note'),
               newc: !!d(i, 'newc'), card: d(i, 'card'), txn: d(i, 'txn'), chk: d(i, 'chk') });
  }
  return out;
}

function mhTable_(heads, rows, right) {
  const th = heads.map((h, i) => '<th style="padding:6px 8px;background:#e6f3ec;text-align:' + (right.indexOf(i) >= 0 ? 'right' : 'left') + ';border-bottom:1px solid #cfd9d3;font-size:12px">' + mhEsc_(h) + '</th>').join('');
  const tr = rows.map(r => '<tr>' + r.map((v, i) => '<td style="padding:6px 8px;border-bottom:1px solid #eef1ef;font-size:13px;text-align:' + (right.indexOf(i) >= 0 ? 'right' : 'left') + ';vertical-align:top">' + v + '</td>').join('') + '</tr>').join('');
  return '<table style="border-collapse:collapse;width:100%;margin:6px 0 14px"><tr>' + th + '</tr>' + (tr || '<tr><td colspan="' + heads.length + '" style="padding:8px;color:#66736b">None</td></tr>') + '</table>';
}

function mhBuildSummary_(ss, dateStr) {
  const tz = ss.getSpreadsheetTimeZone(), set = mhSettingsMap_(ss);
  const biz = set['Business name'] || 'The Morning Hub';
  const all = mhOrdersForDate_(ss, dateStr);
  const live = all.filter(o => o.status !== 'Cancelled');
  const cancelled = all.length - live.length;
  const sum = (arr, f) => arr.reduce((a, o) => a + f(o), 0);
  const plates = sum(live, o => o.plates), amount = sum(live, o => o.amount);
  const paidList = live.filter(o => o.pay === 'Paid');
  const received = sum(paidList, o => o.amount), pending = amount - received;
  const st = s => live.filter(o => o.status === s).length;
  const max = Number(set['Max plates per day']) || 0;

  const modes = {};
  live.forEach(o => { const k = o.mode || '-'; const m = modes[k] = modes[k] || { n: 0, amt: 0, paid: 0 }; m.n++; m.amt += o.amount; if (o.pay === 'Paid') m.paid += o.amount; });
  const items = {};
  live.forEach(o => String(o.items).split(/,\s*(?=\d+\s*x\s)/).forEach(p => { const r = p.match(/^(\d+)\s*x\s*(.+)$/); if (r) items[r[2].trim()] = (items[r[2].trim()] || 0) + Number(r[1]); }));
  const wings = {};
  live.forEach(o => { const k = o.wing || '-'; const w = wings[k] = wings[k] || { n: 0, pl: 0, amt: 0, paid: 0 }; w.n++; w.pl += o.plates; w.amt += o.amount; if (o.pay === 'Paid') w.paid += o.amount; });
  const newcs = live.filter(o => o.newc);
  const pretty = mhPretty_(dateStr, tz);

  const stat = (label, v, color) => '<td style="padding:10px 6px;text-align:center;border:1px solid #dde4e0;background:#fff"><div style="font-size:20px;font-weight:bold;color:' + (color || '#17201b') + '">' + v + '</div><div style="font-size:11px;color:#66736b">' + label + '</div></td>';
  let html = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:760px;margin:auto;color:#17201b">' +
    '<div style="background:#1d5a36;color:#f3d77a;padding:14px 16px;font-size:18px;font-weight:bold">' + mhEsc_(biz) + ' – Daily summary</div>' +
    '<div style="background:#f4f6f5;padding:10px 16px;font-size:14px">Menu / delivery date: <b>' + mhEsc_(pretty) + '</b></div>' +
    '<table style="border-collapse:collapse;width:100%;margin:10px 0"><tr>' + stat('Orders', live.length) + stat('Plates', plates + (max ? ' / ' + max : '')) + stat('Total', mhInr_(amount)) + stat('Received', mhInr_(received), '#1d5a36') + stat('Pending', mhInr_(pending), pending ? '#c0392b' : '#1d5a36') + '</tr></table>' +
    '<table style="border-collapse:collapse;width:100%;margin:0 0 10px"><tr>' + stat('New', st('New')) + stat('Preparing', st('Preparing')) + stat('Out for delivery', st('Out for delivery')) + stat('Delivered', st('Delivered'), '#1d5a36') + stat('Cancelled', cancelled) + '</tr></table>' +
    '<h3 style="margin:14px 0 2px;font-size:15px">Payment</h3>' +
    mhTable_(['Mode', 'Orders', 'Amount', 'Received', 'Pending'], Object.keys(modes).map(k => [mhEsc_(k), modes[k].n, mhInr_(modes[k].amt), mhInr_(modes[k].paid), mhInr_(modes[k].amt - modes[k].paid)]), [1, 2, 3, 4]) +
    '<h3 style="margin:14px 0 2px;font-size:15px">What to cook</h3>' +
    mhTable_(['Item', 'Quantity'], Object.keys(items).sort().map(k => [mhEsc_(k), items[k]]), [1]) +
    '<h3 style="margin:14px 0 2px;font-size:15px">Wing-wise</h3>' +
    mhTable_(['Wing', 'Orders', 'Plates', 'Amount', 'Received', 'Pending'], Object.keys(wings).sort().map(k => [mhEsc_(k), wings[k].n, wings[k].pl, mhInr_(wings[k].amt), mhInr_(wings[k].paid), mhInr_(wings[k].amt - wings[k].paid)]), [1, 2, 3, 4, 5]) +
    (newcs.length ? '<h3 style="margin:14px 0 2px;font-size:15px">⭐ New customers – thank-you cards</h3>' + mhTable_(['Flat', 'Wing', 'Name', 'Card'], newcs.map(o => [mhEsc_(o.flat), mhEsc_(o.wing), mhEsc_(o.name), o.card === 'Sent' ? 'Given ✓' : '<b>Needed</b>']), []) : '') +
    '<h3 style="margin:14px 0 2px;font-size:15px">All orders (' + all.length + ')</h3>' +
    mhTable_(['Order', 'Flat / Wing', 'Name', 'Items', 'Plates', 'Amount', 'Payment', 'Status'],
      all.map(o => [mhEsc_(o.id) + (o.newc ? ' ⭐' : ''), '<b>' + mhEsc_(o.flat) + '</b><br><span style="color:#66736b;font-size:11px">' + mhEsc_(o.wing) + '</span>', mhEsc_(o.name) + '<br><span style="color:#66736b;font-size:11px">' + mhEsc_(o.phone) + '</span>',
        mhEsc_(o.items) + (o.note ? '<br><i style="color:#b7791f;font-size:11px">' + mhEsc_(o.note) + '</i>' : ''), o.plates, mhInr_(o.amount),
        mhEsc_(o.mode) + '<br><b style="color:' + (o.pay === 'Paid' ? '#1d5a36' : '#c0392b') + '">' + mhEsc_(o.pay) + '</b>' + (o.txn ? '<br><span style="color:#66736b;font-size:11px">' + mhEsc_(o.txn) + '</span>' : ''), mhEsc_(o.status)]), [4, 5]) +
    '<div style="color:#66736b;font-size:11px;margin-top:10px">Sent automatically by the Morning Hub app. Full order list is attached as a CSV file.</div></div>';

  const lines = [biz + ' - Daily summary', 'Menu / delivery date: ' + pretty, '',
    'Orders: ' + live.length + '   Plates: ' + plates + (max ? ' / ' + max : ''), 'Total: ' + mhInr_(amount) + '   Received: ' + mhInr_(received) + '   Pending: ' + mhInr_(pending),
    'New: ' + st('New') + '  Preparing: ' + st('Preparing') + '  Out for delivery: ' + st('Out for delivery') + '  Delivered: ' + st('Delivered') + '  Cancelled: ' + cancelled, '', 'What to cook:']
    .concat(Object.keys(items).sort().map(k => '  ' + k + ' x ' + items[k])).concat(['', 'Orders:'])
    .concat(all.map(o => '  ' + o.id + ' | ' + o.wing + ' ' + o.flat + ' | ' + o.name + ' | ' + o.items + ' | ' + mhInr_(o.amount) + ' | ' + o.mode + ' ' + o.pay + ' | ' + o.status + (o.newc ? ' | NEW CUSTOMER' : '')));

  const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  const csv = [['Order ID', 'Delivery date', 'Name', 'Phone', 'Wing', 'Flat', 'Items', 'Plates', 'Amount', 'Payment mode', 'Payment', 'Payment txn id', 'Status', 'Note', 'New customer'].map(q).join(',')]
    .concat(all.map(o => [o.id, dateStr, o.name, o.phone, o.wing, o.flat, o.items, o.plates, o.amount, o.mode, o.pay, o.txn, o.status, o.note, o.newc ? 'Yes' : ''].map(q).join(','))).join('\n');

  return { biz: biz, date: dateStr, pretty: pretty, orders: live.length, plates: plates, amount: amount, received: received, pending: pending, cancelled: cancelled,
           subject: biz + ' – ' + pretty + ' summary · ' + live.length + ' orders · ' + mhInr_(amount),
           html: html, text: lines.join('\n'), csv: csv };
}

function mhSendSummary_(ss, dateStr, to, kind) {
  const s = mhBuildSummary_(ss, dateStr);
  MailApp.sendEmail({ to: to, subject: s.subject, body: s.text, htmlBody: s.html, name: s.biz,
                      attachments: [Utilities.newBlob('﻿' + s.csv, 'text/csv', 'orders-' + dateStr + '.csv')] });
  const info = { ok: true, kind: kind, date: dateStr, to: to, orders: s.orders, plates: s.plates, amount: s.amount, received: s.received, pending: s.pending,
                 at: Utilities.formatDate(new Date(), ss.getSpreadsheetTimeZone(), 'yyyy-MM-dd HH:mm') };
  PropertiesService.getScriptProperties().setProperty('mh_last', JSON.stringify(info));
  return info;
}

function mhHasAutoTrigger_() { return ScriptApp.getProjectTriggers().some(t => t.getHandlerFunction() === 'mhTick'); }

function mhSetAuto_(on) {
  ScriptApp.getProjectTriggers().forEach(t => { if (t.getHandlerFunction() === 'mhTick') ScriptApp.deleteTrigger(t); });
  if (on) ScriptApp.newTrigger('mhTick').timeBased().everyMinutes(5).create();
  return mhHasAutoTrigger_();
}

// Timer target: sends today's summary once a day at/after the time in Settings!B29 (within 3 hours).
function mhTick() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(15000)) return;
  const props = PropertiesService.getScriptProperties();
  let ss, today;
  try {
    ss = SpreadsheetApp.openById(MH_SHEET_ID);
    const cfg = mhSummaryCfg_(ss);
    if (!cfg.emails.length || cfg.minutes === null) return;
    const tz = ss.getSpreadsheetTimeZone(), now = new Date();
    today = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
    const mins = Number(Utilities.formatDate(now, tz, 'H')) * 60 + Number(Utilities.formatDate(now, tz, 'm'));
    if (props.getProperty('mh_auto_date') === today) return;
    if (mins < cfg.minutes || mins > cfg.minutes + 180) return;
    mhSendSummary_(ss, today, cfg.emails.join(','), 'auto');
    props.setProperty('mh_auto_date', today);
  } catch (err) {
    const when = ss ? Utilities.formatDate(new Date(), ss.getSpreadsheetTimeZone(), 'yyyy-MM-dd HH:mm') : '';
    props.setProperty('mh_last', JSON.stringify({ ok: false, kind: 'auto', date: today || '', error: String(err.message || err), at: when }));
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

function mhSummaryStatus_(ss) {
  const cfg = mhSummaryCfg_(ss), tz = ss.getSpreadsheetTimeZone();
  let last = null; try { last = JSON.parse(PropertiesService.getScriptProperties().getProperty('mh_last') || 'null'); } catch (x) {}
  let auto = false, authorized = true, quota = null;
  try { auto = mhHasAutoTrigger_(); } catch (x) { authorized = false; }
  try { quota = MailApp.getRemainingDailyQuota(); } catch (x) { authorized = false; }
  return { ok: true, version: 7, email: cfg.email, emailValid: cfg.emails.length > 0, emailKey: cfg.emailKey, emailCell: cfg.emailCell,
           time: cfg.time, timeValid: cfg.minutes !== null, timeKey: cfg.timeKey, timeCell: cfg.timeCell,
           auto: auto, authorized: authorized, quota: quota, tz: tz, today: Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd'), last: last };
}

function mhHandle_(e) {
  const lock = LockService.getScriptLock();
  let out;
  try {
    lock.waitLock(20000);
    const req = JSON.parse(e.postData.contents);
    if (String(req.pin) !== String(MH_PIN)) throw new Error('Wrong PIN');
    const ss = SpreadsheetApp.openById(MH_SHEET_ID);

    if (req.a === 'ping') {
      const mrows = ss.getSheetByName('Menu').getRange(2, 1, Math.max(ss.getSheetByName('Menu').getLastRow() - 1, 1), 1).getValues();
      out = { ok: true, version: 7,
              orders: mhOrderCount_(ss),
              menu: mrows.filter(r => String(r[0]).trim() !== '').length };

    } else if (req.a === 'orders') {            // batch: [{id, status, pay}, ...]
      const r = mhApplyOrders_(ss, req.list);
      out = { ok: true, changed: r.changed, missing: r.missing };

    } else if (req.a === 'summary_status') {
      out = mhSummaryStatus_(ss);

    } else if (req.a === 'summary_send') {      // manual: e-mail the summary for one menu/delivery date
      const cfg = mhSummaryCfg_(ss);
      const to = String(req.to || '').trim() || cfg.emails.join(',');
      if (!mhValidEmails_(to).length) throw new Error('No valid e-mail address. Put it in Settings ' + cfg.emailCell + ' (or type one in the app).');
      const day = mhNormDate_(req.date) || Utilities.formatDate(new Date(), ss.getSpreadsheetTimeZone(), 'yyyy-MM-dd');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) throw new Error('Bad date');
      out = { ok: true, sent: mhSendSummary_(ss, day, to, 'manual') };

    } else if (req.a === 'summary_auto') {      // turn the daily auto e-mail timer on/off
      const on = mhSetAuto_(!!req.on);
      out = { ok: true, auto: on };

    } else if (req.a === 'read') {              // raw display values (exact text, no type guessing)
      const sh = ss.getSheetByName(req.sheet || 'Orders');
      out = { ok: true, values: sh.getDataRange().getDisplayValues() };

    } else if (req.a === 'orderedit') {         // edit any fields of one order
      const sh = ss.getSheetByName('Orders');
      const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h).trim().toLowerCase());
      const find = function () {
        for (let a = 0; a < arguments.length; a++) { const i = head.indexOf(arguments[a]); if (i >= 0) return i; }
        for (let a = 0; a < arguments.length; a++) { const i = head.findIndex(h => h.indexOf(arguments[a]) >= 0); if (i >= 0) return i; }
        return -1;
      };
      const cId = find('order id');
      if (cId < 0) throw new Error('Orders column "Order ID" not found');
      const last = sh.getLastRow();
      const ids = last > 1 ? sh.getRange(2, cId + 1, last - 1, 1).getValues() : [];
      let row = -1;
      ids.forEach((r, i) => { if (String(r[0]).trim() === String(req.id).trim()) row = i + 2; });
      if (row < 0) throw new Error('Order ' + req.id + ' not found in sheet');
      const col = { name: find('name'), phone: find('phone', 'whatsapp'), wing: find('wing'), flat: find('flat'),
                    items: find('items', 'item'), plates: find('plates'), amount: find('amount'),
                    mode: find('payment mode'), note: find('note'), date: find('delivery date'),
                    card: find('thank-you card', 'thank you card') };
      const f = req.fields || {};
      Object.keys(col).forEach(k => {
        if (col[k] < 0 || f[k] === undefined || f[k] === null) return;
        const cell = sh.getRange(row, col[k] + 1);
        const v = String(f[k]).trim();
        if (k === 'plates' || k === 'amount') cell.setValue(Number(v) || 0);
        else if (k === 'date') { const m = v.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) cell.setValue(new Date(+m[1], +m[2] - 1, +m[3])); }
        else if ((k === 'flat' || k === 'phone') && /^[1-9]\d*$/.test(v)) cell.setValue(Number(v));   // keep numbers numeric like the form does
        else cell.setValue(v);
      });
      SpreadsheetApp.flush();
      if (f.card === 'Sent' || f.card === 'Needed') mhSetFlatCard_(ss, sh, row, head, f.card);
      const r = mhApplyOrders_(ss, [{ id: req.id, status: f.status, pay: f.pay }]);
      out = { ok: true, changed: r.changed };

    } else if (req.a === 'order') {
      const r = mhApplyOrders_(ss, [req]);
      if (r.missing.length) throw new Error('Order ' + req.id + ' not found in sheet');
      out = { ok: true, changed: r.changed };

    } else if (req.a === 'menu') {
      const sh = ss.getSheetByName('Menu');
      const last = Math.max(sh.getLastRow(), 2);
      sh.getRange(2, 1, last - 1, 7).clearContent();
      const rows = (req.menu || []).map(m => [m.item, Number(m.price) || 0, m.avail === 'No' ? 'No' : 'Yes', m.desc || '', m.photo || '', m.prep || '', mhMenuDate_(m.mdate)]);
      if (rows.length) {
        const rg = sh.getRange(2, 1, rows.length, 7);
        sh.getRange(2, 6, rows.length, 1).setNumberFormat('@');   // keep "07:00" as text
        sh.getRange(2, 7, rows.length, 1).setNumberFormat('yyyy-mm-dd');   // Menu date
        rg.setValues(rows);
      }
      out = { ok: true, rows: rows.length };

    } else if (req.a === 'setting') {
      const sh = ss.getSheetByName('Settings');
      const keys = sh.getRange(1, 1, sh.getLastRow(), 1).getValues();
      let row = -1;
      for (let i = 0; i < keys.length; i++) if (String(keys[i][0]).trim() === String(req.key).trim()) { row = i + 1; break; }
      if (row < 0) throw new Error('Setting not found: ' + req.key);
      const cell = sh.getRange(row, 2);
      const sval = String(req.value);
      if (/^[\d:]+$/.test(sval)) cell.setNumberFormat('@');   // keep 07:00 / 5814 / 1000 as text, like the sheet's own values
      if (cell.getDisplayValue() !== sval) cell.setValue(sval);
      out = { ok: true };

    } else {
      throw new Error('Unknown action');
    }
  } catch (err) {
    out = { ok: false, error: String(err.message || err) };
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
