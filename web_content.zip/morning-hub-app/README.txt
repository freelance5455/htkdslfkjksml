MORNING HUB APP
================
Install on Android (no Play Store needed):
1. Upload this folder to any free host (Netlify Drop: app.netlify.com/drop, or GitHub Pages).
2. Open the link in Chrome on your phone -> menu (3 dots) -> "Install app" / "Add to Home screen".
3. It then opens full-screen like a normal app and works offline.

Real APK file (optional):
- Go to pwabuilder.com, paste your hosted link, choose Android -> Download. You get a signed .apk to install directly.

Daily use:
- Google Sheet -> File -> Download -> Microsoft Excel (.xlsx)
- App -> Settings -> "Import Excel (new orders)" adds only new orders and keeps your delivered/paid marks.
- Settings -> Backup (JSON) saves everything; Export CSV opens in Excel/Sheets.

AUTO-SYNC FROM GOOGLE SHEET
- In Google Sheets: Share -> General access -> "Anyone with the link" -> Viewer.
- In the app: Settings -> paste the sheet link -> "Save & sync now".
- After that it syncs on every app open, every 5 minutes, and with the refresh button on the Today tab.
- The file must be a real Google Sheet (if it is an .xlsx in Drive: open it -> File -> Save as Google Sheets).

UPDATE PAID / DELIVERY / MENU FROM THE APP (one-time setup, 3 minutes)
1. Open your Google Sheet -> Extensions -> Apps Script.
2. Click "+" next to Files -> Script -> name it MorningHubAPI -> paste everything from MorningHubAPI.gs.
   (If your project already has a doPost function, tell me / rename it: only one doPost can exist.)
3. Change MH_PIN to your own PIN and save.
4. Deploy -> Manage deployments -> pencil icon -> Version: "New version" -> Deploy.
   (Execute as: Me, Who has access: Anyone. Keeping the same deployment keeps your /exec link unchanged.)
5. In the app: Settings -> Update PIN -> type the same PIN -> "Test updates" should say "Updates connected".
After that, Out for delivery / Delivered / Paid and Menu changes in the app are written to the sheet.
If the phone is offline, changes wait (shown as "to upload") and are sent when you are back online.

UPDATED SCRIPT (v2 – faster, 1 call for many orders)
If you pasted MorningHubAPI.gs earlier, replace it with the new file (or use Settings -> "Copy script code" in the app),
keep your PIN, then Deploy -> Manage deployments -> pencil -> New version -> Deploy. The app also works with the old script.
Red box at the top of Today/Orders/Menu = changes are NOT in the sheet yet; it shows the exact reason.
Settings -> "Upload all Paid/Status to sheet" sends every order's status to the sheet in one go (catch-up).

PULL DOWN TO REFRESH: on any screen, scroll to the top and pull down, then release to load the latest orders from the sheet.

v6: Edit-form buttons (Save / Cancel / Delete) fixed. New "Delivered + Paid" button. Logo is now built in.
Script v3 re-reads the sheet after every Paid/Status write and shows an error if the sheet did not keep it.
Update the script again (paste MorningHubAPI.gs, keep your PIN, Deploy -> New version).
Note: Delete in the app removes the order from the phone only; it comes back on the next sync because the sheet still has it.

v7: Today tab now opens on TOMORROW's list after 10 AM (orders are for the next morning) and on TODAY's list before 10 AM.
Today / Tomorrow buttons show how many orders each day has. A yellow "Latest order is for <date> – View" card appears when your newest order is on another day.
Flat numbers: leading zeros kept, "Flat 203" -> 203, and renamed sheet columns are found automatically. Settings shows the columns it read.

v8 (latest – please install this one):
- Flat no is read from the sheet even if the column mixes numbers and text (e.g. 776 and B-1204). Orders without a flat show "+ add flat no".
- Every order card (Today and Orders tabs) has a green "✏️ Edit" button. In the edit form, Save / Cancel / Delete stay visible at the bottom and there is an ✕ at the top.
- Saving an edit (flat, name, phone, items, amount, date, payment, status) is written to the sheet.
  This needs script v4: paste the newest MorningHubAPI.gs, keep your PIN, Deploy -> Manage deployments -> pencil -> New version.
- If the old design still shows after you upload: close the app completely and open it again (or clear its site data once).

v9 (latest - install this one, and also paste the new MorningHubAPI.gs)
- ⭐ NEW CUSTOMERS: every order from a new customer (column "New customer" in your sheet) has a ⭐, a gold border and a "give thank-you card" label.
  Today tab shows "⭐ n Thank-you cards to give"; the "⭐ New" filter lists them; the Customers tab lists every flat that still needs a card.
  "🎁 Card given" writes Sent to the Thank-you card column (and the Flats sheet) so the sheet's alert disappears.
- WhatsApp button: choose Order confirmation (your sheet's own link), Payment received, Out for delivery or Pay & track link.
  Confirmation for UPI orders is blocked until the order is Paid ("confirm after payment").
- Statuses now include Preparing and Cancelled (same as your sheet's dropdown). Menu has Preparation time. Settings show your notes, Yes/No dropdowns and a Stop/Start orders button.
- Script v5: after pasting it, Deploy -> Manage deployments -> pencil -> New version. Without it, "Card given", Cancelled/Preparing and menu preparation time will not reach the sheet.

v10 (latest - install this one, and also paste the new MorningHubAPI.gs = script v6)
- Settings tab now matches your sheet's Settings tab exactly, including the newest fields: tracking link, delivery-status steps, payment transaction ID (UTR), UPI link style, merchant code, preparation start, privacy consent and text. Dropdown fields (Yes/No, Enable/Disable, Phone/Flat, Simple/Full/Full+mode) show as dropdowns, and every change is written back to the same row in the sheet.
- Blank settings (e.g. an empty Merchant code) now sync as blank instead of disappearing. Times such as 07:00 and numbers such as 5814 are saved as text so the sheet does not convert them.
- Menu now has "Menu date (optional)" (sheet column G). It is read from the sheet and written back, so saving the menu from the app no longer misaligns or wipes dates.
- Orders show the payment transaction ID and the sheet's "Payment ID check" result (invalid ones in red). The Pay & track WhatsApp option is hidden while "Order tracking link" is Disable.
- Existing installs keep their data; any new setting fields are added automatically on next open. Script v6: Deploy -> Manage deployments -> pencil -> New version.


=== v11 – menu-date sorting + daily summary e-mail ===
* Orders and Today tabs are sorted by MENU (delivery) date, newest first; inside a date, newest order first.
* Settings > "Daily summary email": e-mail is read from Settings!B28, auto time from Settings!B29 (HH:MM, sheet time zone).
  Auto mail goes once a day at/after that time (3-hour catch-up window). "Send summary now" works for any menu date and
  shows a confirmation in the app. The mail has totals, payments, items to cook, wing-wise list and every order (+CSV).
ONE-TIME SETUP
1. Paste the new MorningHubAPI.gs into Apps Script (keep your PIN).
2. Choose function mhAuthorizeOnce > Run > Review permissions > Allow.
3. Deploy > Manage deployments > pencil > New version > Deploy.
4. In the app: Settings > Daily summary email > Turn on.

=== v12 ===
* Sync fix: if the browser cannot reach the Google Sheet directly ("Failed to fetch"), the app now reads Orders, Menu and Settings through your update script instead (needs script link + PIN). Status shows "read via your script".
