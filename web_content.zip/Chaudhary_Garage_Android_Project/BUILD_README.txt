# Chaudhary Garage v1.0 – Android Studio project

This is a standalone Android WebView application project. It does not need a website, hosting account, domain, or API key.

## Build an APK on Windows

1. Install Android Studio (stable version) on your PC.
2. Extract this ZIP to a normal folder, e.g. `C:\Projects\ChaudharyGarage`.
3. In Android Studio choose **Open** and select the extracted `Chaudhary_Garage_Android_Project` folder.
4. Allow Gradle sync to finish. The first sync needs an internet connection to download Android Gradle Plugin / SDK components.
5. If Android Studio asks for an SDK, install Android SDK Platform 35 and Build Tools using SDK Manager.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. When the build completes, click **locate** in the notification. The debug APK is normally at:
   `app\build\outputs\apk\debug\app-debug.apk`
8. Copy that APK to your Android phone and install it. If prompted, allow installation from that file manager.

## What is included

- Standalone Android wrapper (Java WebView).
- Offline HTML/CSS/JavaScript app assets bundled inside the APK.
- Local data storage using WebView DOM storage (`localStorage`).
- Add/edit/delete vehicle profiles.
- Fuel, maintenance, expenses and document records.
- Garage dashboard and built-in basic guidance assistant.
- First-launch welcome screen and Chaudhary Garage branding.

## Important limitations of this first build

- The AI assistant is a built-in basic helper, not connected to an AI API. You can add your own API integration later. Do not put a private API key directly in a public client-side app; use a secure backend/proxy for production.
- The three-car artwork is currently an illustrative placeholder. The exact reference cars and number plates you previously supplied are not embedded in this package because that original image is not attached in this build session. Re-upload it to replace the placeholder accurately.
- This ZIP is the complete Android Studio source project, not a compiled APK. The APK is created on your PC using the steps above.
- Data is stored locally on this device. Clearing app storage or uninstalling may remove it; export/backup functionality is not included yet.

Copyright: © Ch. NASIR
