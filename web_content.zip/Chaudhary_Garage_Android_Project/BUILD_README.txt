CHAUDHARY GARAGE v1.1 – AI EDITION (ANDROID SOURCE PACKAGE)

IMPORTANT: This ZIP is an Android Studio source project, not a precompiled APK.

BUILD ON WINDOWS / MAC
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. Android Studio > Open > select the Chaudhary_Garage_Android_Project folder.
4. Allow Gradle sync and install any requested build tools.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK output: app/build/outputs/apk/debug/app-debug.apk

WHAT IS INCLUDED IN THIS SOURCE UPDATE
- Approved splash artwork is shown at every app launch; Get Started enters the dashboard.
- First-use profile setup asks for name, mobile number and email.
- Dark navy / blue / gold dashboard theme and vehicle-focused home page.
- Add, edit and delete vehicles. A car photo is required when creating a vehicle; the Android file picker opens to select an original image. The chosen photo is stored with the vehicle and displayed in its cards/profile.
- Fuel, maintenance, expenses and document records with PKR currency labels.
- Functional hamburger menu with profile, exports, backup/restore and analytics/reminder access.
- Per-car CSV export (opens in Excel) and all-records CSV export.
- Full JSON backup and restore. Backup includes vehicle photos because photos are stored as data in the vehicle records.
- Lightweight date-based reminder summary; no continuous AI processing.
- Native Android save dialog is used for exports so the user can choose where to save CSV/JSON files.

NOT INCLUDED / IMPORTANT LIMITATIONS
- Google account / Google Drive sync is NOT connected. It requires Google OAuth configuration, a cloud project and testing; do not assume sync is active.
- The AI assistant is basic offline guidance only. Live AI/API integration is not connected.
- CSV exports are Excel-compatible data files, not formatted .xlsx workbooks.
- Data is stored locally in this app's WebView storage. Keep regular backups. Uninstalling/clearing app data can remove local records.
- This project has not been compiled or tested on a physical Android device in this environment. Build and test it in Android Studio before distributing.

VERSION 1.2 ADDITIONS
- Added a Google Account / Drive Sync setup entry in the app menu. This is a configuration hand-off screen, NOT an active Google sign-in or sync implementation. To activate it, complete native Android Credential Manager Sign in with Google and Drive AuthorizationClient integration using your own Google Cloud OAuth Android client, package name and signing SHA-1. Google sign-in and Drive authorization are separate consent flows.
- Expanded the built-in offline Garage Assistant with local, rule-based answers using saved fuel, expense and reminder data. It works without an API key or internet, but it is not a generative AI model.

GOOGLE SETUP REFERENCES
- Credential Manager: https://developers.google.com/identity/android-credential-manager
- Google Drive authorization: https://developer.android.com/identity/authorization
- Google recommends Credential Manager for Android sign-in; Drive data access uses a separate authorization flow. Do not collect Google passwords inside this app.
