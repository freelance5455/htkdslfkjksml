CHAUDHARY GARAGE v1.0 – AI EDITION

This is an Android Studio source project, not a precompiled APK.

BUILD ON WINDOWS / MAC
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. Android Studio > Open > select the Chaudhary_Garage_Android_Project folder.
4. Allow Gradle sync and install any requested Android build tools.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK output: app/build/outputs/apk/debug/app-debug.apk

FEATURES IN THIS BUILD
- Approved splash artwork and dark/gold dashboard theme.
- Add, edit and delete vehicles.
- Original vehicle photo is mandatory when adding a car; image is resized and stored locally for its car card/profile.
- Fuel, maintenance, expense and document records; local reports.
- Local/offline browser storage within the app.
- Basic offline helper only. Live AI is NOT connected; add your own API integration securely in a later build.

NOTES
- Data is stored on this device. Back up your data before uninstalling or clearing app data.
- This source project has not been compiled into an APK in this environment.
- The splash image is approved illustrative artwork; vehicle-specific photos are requested during Add Car.
