package com.chaudharygarage.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.view.Window;
import android.view.WindowManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadMessage;
    private static final int FILE_CHOOSER_RESULT = 1001;
    private static final int SAVE_FILE_RESULT = 1002;
    private static final int VEHICLE_PHOTO_RESULT = 1003;
    private byte[] pendingBytes;
    private String pendingMime = "application/octet-stream";
    private String pendingName = "garage-export";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this); setContentView(webView);
        WebSettings settings=webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setSupportZoom(false);
        webView.addJavascriptInterface(new DownloadBridge(this), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(uploadMessage!=null) uploadMessage.onReceiveValue(null);
                uploadMessage=callback;
                String[] accepted=params.getAcceptTypes();
                String mime="*/*";
                if(accepted!=null){ for(String a:accepted){ if(a!=null&&!a.isEmpty()){mime=a.split(",")[0].trim();break;} } }
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(intent,FILE_CHOOSER_RESULT); }
                catch(Exception e){
                    try {
                        Intent fallback=new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType(mime);
                        startActivityForResult(Intent.createChooser(fallback,"Choose file"),FILE_CHOOSER_RESULT);
                    } catch(Exception ex){ uploadMessage.onReceiveValue(null);uploadMessage=null;return true; }
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class DownloadBridge {
        private Context context;
        DownloadBridge(Context c){context=c;}
        @JavascriptInterface public void pickVehiclePhoto(){
            runOnUiThread(()->{
                Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(Intent.createChooser(intent,"Select vehicle photo"),VEHICLE_PHOTO_RESULT); }
                catch(Exception ex){Toast.makeText(MainActivity.this,"No gallery/file picker found",Toast.LENGTH_LONG).show();}
            });
        }
        @JavascriptInterface public void saveText(String filename, String mime, String text){
            pendingBytes=text.getBytes(StandardCharsets.UTF_8);
            pendingMime=mime==null?"text/plain":mime;
            pendingName=filename==null?"garage-export.txt":filename;
            runOnUiThread(()->{
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime);
                intent.putExtra(Intent.EXTRA_TITLE,pendingName);
                startActivityForResult(intent,SAVE_FILE_RESULT);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==VEHICLE_PHOTO_RESULT){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
                Uri uri=data.getData();
                new Thread(()->{
                    try {
                        BitmapFactory.Options bounds=new BitmapFactory.Options();
                        bounds.inJustDecodeBounds=true;
                        try(InputStream input=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(input,null,bounds);}
                        int sample=1;
                        while(bounds.outWidth/sample>1600||bounds.outHeight/sample>1600)sample*=2;
                        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sample;
                        Bitmap bmp;
                        try(InputStream input=getContentResolver().openInputStream(uri)){bmp=BitmapFactory.decodeStream(input,null,opts);}
                        if(bmp==null)throw new Exception("Unsupported photo format");
                        int w=bmp.getWidth(),h=bmp.getHeight();
                        if(w>1200||h>1200){float scale=Math.min(1200f/w,1200f/h);Bitmap resized=Bitmap.createScaledBitmap(bmp,Math.max(1,Math.round(w*scale)),Math.max(1,Math.round(h*scale)),true);bmp.recycle();bmp=resized;}
                        ByteArrayOutputStream stream=new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.JPEG,75,stream);bmp.recycle();
                        String encoded=Base64.encodeToString(stream.toByteArray(),Base64.NO_WRAP);
                        runOnUiThread(()->webView.evaluateJavascript("receiveVehiclePhoto('data:image/jpeg;base64,"+encoded+"')",null));
                    } catch(Exception ex){runOnUiThread(()->Toast.makeText(MainActivity.this,"Photo selection failed: "+ex.getMessage(),Toast.LENGTH_LONG).show());}
                }).start();
            }
        } else if(requestCode==FILE_CHOOSER_RESULT&&uploadMessage!=null){
            Uri[] results=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;
            uploadMessage.onReceiveValue(results); uploadMessage=null;
        } else if(requestCode==SAVE_FILE_RESULT&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBytes!=null){
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(pendingBytes);Toast.makeText(this,"File saved",Toast.LENGTH_SHORT).show();}
            catch(Exception e){Toast.makeText(this,"Could not save file: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            pendingBytes=null;
        }
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
