package com.chaudharygarage.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.view.Window;
import android.view.WindowManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadMessage;
    private static final int FILE_CHOOSER_RESULT = 1001;
    private static final int SAVE_FILE_RESULT = 1002;
    private byte[] pendingBytes;
    private String pendingMime = "application/octet-stream";
    private String pendingName = "garage-export";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this); setContentView(webView);
        WebSettings settings=webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setSupportZoom(false);
        webView.addJavascriptInterface(new DownloadBridge(this), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(uploadMessage!=null) uploadMessage.onReceiveValue(null);
                uploadMessage=callback;
                String[] accepted=params.getAcceptTypes();
                String mime="*/*";
                if(accepted!=null){ for(String a:accepted){ if(a!=null&&!a.isEmpty()){mime=a.split(",")[0].trim();break;} } }
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(intent,FILE_CHOOSER_RESULT); }
                catch(Exception e){
                    try {
                        Intent fallback=new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType(mime);
                        startActivityForResult(Intent.createChooser(fallback,"Choose file"),FILE_CHOOSER_RESULT);
                    } catch(Exception ex){ uploadMessage.onReceiveValue(null);uploadMessage=null;return true; }
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class DownloadBridge {
        private Context context;
        DownloadBridge(Context c){context=c;}
        @JavascriptInterface public void saveText(String filename, String mime, String text){
            pendingBytes=text.getBytes(StandardCharsets.UTF_8);
            pendingMime=mime==null?"text/plain":mime;
            pendingName=filename==null?"garage-export.txt":filename;
            runOnUiThread(()->{
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime);
                intent.putExtra(Intent.EXTRA_TITLE,pendingName);
                startActivityForResult(intent,SAVE_FILE_RESULT);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER_RESULT&&uploadMessage!=null){
            Uri[] results=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;
            uploadMessage.onReceiveValue(results); uploadMessage=null;
        } else if(requestCode==SAVE_FILE_RESULT&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBytes!=null){
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(pendingBytes);Toast.makeText(this,"File saved",Toast.LENGTH_SHORT).show();}
            catch(Exception e){Toast.makeText(this,"Could not save file: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            pendingBytes=null;
        }
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
