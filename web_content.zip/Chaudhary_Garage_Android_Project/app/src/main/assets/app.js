const answer=document.getElementById('answer');
document.getElementById('ask').addEventListener('click',()=>{
 const q=document.getElementById('question').value.trim();
 if(!q){answer.hidden=false;answer.textContent='Please type a question first.';return;}
 answer.hidden=false;
 answer.textContent='Garage AI demo: For "'+q+'", check your Toyota owner manual and follow the recommended service schedule. Live AI answers will be enabled when a secure API endpoint is connected.';
});
document.getElementById('addCar').addEventListener('click',()=>alert('Vehicle profiles are coming in the next update.'));
document.getElementById('details').addEventListener('click',()=>alert('Toyota Yaris Ativ 2026 · 1.3 CVT · Automatic'));
document.querySelectorAll('.tile').forEach(x=>x.addEventListener('click',()=>alert(x.querySelector('b').textContent+' module is planned for the next update.')));
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
