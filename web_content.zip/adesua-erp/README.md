# ADESUA Academy + Campus ERP Prototype

## Run locally
Extract the ZIP and open index.html in your browser, or use VS Code Live Server.
No installation, build, API, or database is required.

## Source structure
- index.html: application entry point
- style.css: original ERP theme and components
- app.js: demo records, dashboard, enrollment, profiles, complaints, and other ERP screens
- refinements.css: form input states, wizard progress, responsive navigation, pagination, academy website, and login styling
- refinements.js: corresponding interactions and public routes
- records.css: payment, announcement, and complaint layouts
- records.js: corresponding filters, grid/list views, invoices, and notice workflows
- assets/: photographs cropped from the user-supplied reference screenshots

Keep script and stylesheet loading order as provided in index.html.

## Navigation
The default route opens the academy front page.
Public pages: #/home, #/about, #/programs, #/activities, #/contact
Login: #/login (sample credentials are prefilled)
Dashboard: #/overview
Use Academy home in the sidebar to return to the front page.

## Refinements
- Input icons gain blue gradient backgrounds when fields contain values; clearing values restores the neutral state.
- Five-step enrollment has a completed progress line, check marks, and active-step highlight.
- Mobile sidebar supports a close button, backdrop dismissal, Escape, focus management, and closes on navigation.
- Desktop sidebar collapses to an icon rail; the toggle indicates whether it is expanded.
- Student, complaint, teacher, guardian, class, course, announcement, and payment lists have pagination and page-size selection.
- Search and filters reset invalid page selections.
- Orange accents complement the blue and white palette.
- Academy pages and login are responsive and support the theme switch.

## Prototype limitations
All data changes and uploaded images stay in memory and reset on refresh.
Sign-in is a UI demonstration, not real authentication.
Enquiry forms do not send messages. Contact and campus information is illustrative.
Google Fonts is optional; system fonts are used if it is unavailable.
The supplied photographs are reference assets; replace them with your licensed school imagery before production.

## Validation
JavaScript syntax and asset paths checked.
DOM interaction checks cover public routes, login to dashboard, sidebar controls, filled/cleared inputs, pagination/search/page size, all enrollment steps, student creation, and complaint submission.

## Reference screen updates
- Fees & Payments includes 58 sample invoices, fee-type and status filters, collected/outstanding/overdue/paid summaries, grid/list views, invoice details, and a Create Invoice form.
- Announcements includes 8 sample notices, priority/category filters, compact list and card layouts, detailed notices, and a publishing form.
- Complaints includes status/urgency filtering, summary cards, complainant/reported-party panels, and grid/list views.
- Summaries are calculated from the demo collection; filtering changes the record list.
- All three screens retain search, pagination, and page-size controls.
- DOM checks cover combined filters, view changes, empty states, invoice creation, and announcement publishing.

## Unified record design
- unified-grid.js: shared row renderer and data adapters for Students, Teachers, Guardians, Classes, Courses, Payments, Complaints, and Announcements.
- unified-grid.css: consistent desktop and mobile list/card presentation.
- List view is the default on all eight screens; card view remains available.
- Only the current page is rendered. Page-size selection survives filter changes. Long page ranges use compact ellipses.
- Search, filters, record actions, creation forms, and summaries are preserved. Empty results include a reset action.
