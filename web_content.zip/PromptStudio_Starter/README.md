# PromptStudio Starter — Android-friendly prototype

This package contains a single-file HTML prototype of the four-screen app concept.

## Included
- Screen 1: loading/intro scene and progress bar
- Screen 2: prompt/script writing, character selection, reference-photo picker, storyboard preview
- Screen 3: character workshop with touch-drag rotation, body/clothes/tattoo/props tools, `.cr` character export
- Screen 4: video-editor-style preview, background/position/voice controls, project export

## Important limitations
This is a working UI prototype, not a finished AI video generator and not an APK. It does not call an AI service, generate actual 3D meshes, render AI video, remove backgrounds, or synthesize speech. Those features require integration with online AI APIs or native ML models, plus backend/API-key handling. The “3D” character is a stylized interactive mockup.

## Run it on Android
1. Extract the ZIP.
2. Open `index.html` in Chrome, or serve the folder from a local web server.
3. For an installable Android APK, wrap the web app with Capacitor or open an Android Studio WebView project and build/sign it. You need Android Studio/SDK and a signing key to produce a real APK.

Do not place private AI API keys directly in the HTML/JavaScript. Use a backend service.
