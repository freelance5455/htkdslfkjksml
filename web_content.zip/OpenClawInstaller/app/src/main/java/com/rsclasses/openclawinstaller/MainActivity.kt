package com.rsclasses.openclawinstaller

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val TERMUX_PKG = "com.termux"
        private const val PERM_RUN_COMMAND = "com.termux.permission.RUN_COMMAND"
        private const val TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash"
        private const val TERMUX_HOME = "/data/data/com.termux/files/home"
        private const val FDROID_TERMUX = "https://f-droid.org/packages/com.termux/"

        // Community installer (official project: github.com/openclaw/openclaw).
        // Ise padh kar check kar lein; chahein to apna URL yahan daal dein.
        private const val INSTALL_SCRIPT_URL =
            "https://raw.githubusercontent.com/iyeoh88-svg/openclaw-android/main/install.sh"

        // Termux mein ek baar chalane wali setup command
        private const val ALLOW_EXTERNAL_CMD =
            "mkdir -p ~/.termux && grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null " +
                "|| echo 'allow-external-apps=true' >> ~/.termux/termux.properties; " +
                "termux-reload-settings; echo DONE"

        private const val INSTALL_CMD =
            "termux-wake-lock; pkg update -y && pkg install -y curl && " +
                "curl -fsSL $INSTALL_SCRIPT_URL | bash; " +
                "echo; echo '=== Install khatam. Ab app mein Onboard dabayein ==='"
    }

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "OpenClaw Installer"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Android par OpenClaw ka setup, ek click mein (Termux ke through)."
            textSize = 14f
            setPadding(0, dp(6), 0, dp(16))
        })

        status = TextView(this).apply {
            textSize = 14f
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.parseColor("#EEEEEE"))
        }
        root.addView(status)

        root.addView(label("Step 1 (sirf pehli baar)"))
        root.addView(button("Termux install karein (F-Droid)") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(FDROID_TERMUX)))
        })
        root.addView(button("Setup command copy karein") { copyAllowCommand() })
        root.addView(button("Termux kholein (paste karke Enter dabayein)") { openTermux() })

        root.addView(label("Step 2 (ek click)"))
        root.addView(button("INSTALL OPENCLAW", primary = true) { runInTermux(INSTALL_CMD) })

        root.addView(label("Step 3"))
        root.addView(button("Onboard (API key / channel setup)") {
            runInTermux("openclaw onboard")
        })
        root.addView(button("Gateway start karein") {
            runInTermux("termux-wake-lock; openclaw gateway")
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val installed = isTermuxInstalled()
        val granted = checkSelfPermission(PERM_RUN_COMMAND) == PackageManager.PERMISSION_GRANTED
        status.text = buildString {
            append(if (installed) "✅ Termux installed" else "❌ Termux nahi mila (Step 1 karein)")
            append("\n")
            append(if (granted) "✅ Permission mil gayi" else "⚠️ Permission baaki hai (Install dabane par poochega)")
        }
    }

    private fun isTermuxInstalled(): Boolean = try {
        packageManager.getPackageInfo(TERMUX_PKG, 0); true
    } catch (e: PackageManager.NameNotFoundException) { false }

    private fun copyAllowCommand() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("termux-setup", ALLOW_EXTERNAL_CMD))
        toast("Copy ho gaya. Ab Termux kholkar paste karein aur Enter dabayein.")
    }

    private fun openTermux() {
        val i = packageManager.getLaunchIntentForPackage(TERMUX_PKG)
        if (i == null) toast("Termux install nahi hai") else startActivity(i)
    }

    private fun runInTermux(command: String) {
        if (!isTermuxInstalled()) {
            toast("Pehle Termux install karein (F-Droid se)")
            return
        }
        if (checkSelfPermission(PERM_RUN_COMMAND) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(PERM_RUN_COMMAND), 1)
            toast("Permission allow karke dobara button dabayein")
            return
        }
        val intent = Intent("com.termux.RUN_COMMAND").apply {
            setClassName(TERMUX_PKG, "com.termux.app.RunCommandService")
            putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BASH)
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", command))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME)
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
            putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
        } catch (e: Exception) {
            toast("Nahi chala. Step 1 ka setup command Termux mein chalaya? (${e.javaClass.simpleName})")
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refreshStatus()
    }

    // ---- UI helpers ----
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(20), 0, dp(6))
    }

    private fun button(t: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        gravity = Gravity.CENTER
        if (primary) {
            textSize = 18f
            setBackgroundColor(Color.parseColor("#1B7F3B"))
            setTextColor(Color.WHITE)
            minimumHeight = dp(64)
        }
        setOnClickListener(View.OnClickListener { onClick() })
    }
}
