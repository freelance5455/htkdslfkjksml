# OpenClaw Installer (one-click, Termux based)

## APK kaise banayein
1. Android Studio (Koala ya naya) install karein, JDK 17.
2. File > Open > is folder (OpenClawInstaller) ko select karein. Gradle sync hone dein.
3. Build > Build Bundle(s)/APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk -> phone par install karein.

## Phone par use
1. F-Droid se Termux install karein aur ek baar kholkar bootstrap poora hone dein.
2. App kholein > "Setup command copy karein" > Termux mein paste + Enter (sirf ek baar).
3. App mein "INSTALL OPENCLAW" dabayein. Termux khulega aur install chalega.
4. Install ke baad "Onboard", phir "Gateway start karein".

## Note
Install script community ki hai (MainActivity.kt mein INSTALL_SCRIPT_URL). Pehle padh lein.
