(function () {
'use strict';

/* ================= ثابت‌ها ================= */
const SECTIONS = [
  { id: 'tasks',  icon: '✅' },
  { id: 'notes',  icon: '📝' },
  { id: 'shop',   icon: '🛒' },
  { id: 'habits', icon: '🔥' },
  { id: 'timer',  icon: '⏱️' },
  { id: 'money',  icon: '💰' },
  { id: 'goals',  icon: '🎯' },
  { id: 'stats',  icon: '📊' }
];
const N = SECTIONS.length;
const STEP = 360 / N;
const ACCENTS = [
  ['#38bdf8', '#6366f1'], ['#34d399', '#059669'], ['#f472b6', '#db2777'],
  ['#fb923c', '#ea580c'], ['#a78bfa', '#7c3aed']
];
const CAT_ICONS = ['🍽️', '🚌', '🛍️', '🧾', '🎮', '📦'];
const PRI_ICON = ['🟢', '🟡', '🔴'];
const ICONS = ['🎯', '📚', '💪', '💰', '✈️', '🏠', '🎓', '❤️'];
const CLOUDY = ['tasks', 'notes', 'shop', 'goals'];
const HEAD = 170;
const SHAPES = ['cl-a', 'cl-b', 'cl-c'];

/* ================= زبان ================= */
let LANG = 'fa';
function NL() { return LANG === 'en' ? 'en-US' : 'fa-IR'; }
function t(k) {
  const a = arguments;
  let s = (D[LANG] && D[LANG][k] !== undefined) ? D[LANG][k] : (D.fa[k] !== undefined ? D.fa[k] : k);
  if (a.length > 1) s = s.replace(/\{(\d)\}/g, function (m, i) { const v = a[Number(i) + 1]; return v === undefined ? m : v; });
  return s;
}

/* ================= ابزارها ================= */
const $ = id => document.getElementById(id);
const view = $('view');
const wheel = $('wheel');
const ring = $('ring');

function pad(n) { return n < 10 ? '0' + n : '' + n; }
function dayKey(d) {
  d = d || new Date();
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}
function dayKeyAgo(n) { const d = new Date(); d.setDate(d.getDate() - n); return dayKey(d); }
function nf(n, g) {
  n = Number(n) || 0;
  try { return n.toLocaleString(NL(), { useGrouping: !!g, maximumFractionDigits: 0 }); }
  catch (e) { return String(Math.round(n)); }
}
function nd(n) {
  n = Number(n) || 0;
  try { return n.toLocaleString(NL(), { useGrouping: false, maximumFractionDigits: 2 }); }
  catch (e) { return String(n); }
}
function fp(n) { return (n < 10 ? (LANG === 'en' ? '0' : '۰') : '') + nf(n); }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function toEn(s) {
  return String(s == null ? '' : s)
    .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/٫/g, '.')
    .replace(/[٬,،\s]/g, '');
}
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function hash(s) { let h = 0; s = String(s); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
function hashFrac(s, salt) { return (hash(s + salt) % 1000) / 1000; }
function val(id) { const e = $(id); return e ? e.value : ''; }
function empty(msg) { return '<div class="empty">' + msg + '</div>'; }
function sum(a) { return a.reduce((p, c) => p + c, 0); }

function hm(ts) {
  const d = new Date(ts);
  try { return d.toLocaleTimeString(NL(), { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); }
  catch (e) { return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
}
function dayLabel(k) {
  if (k === dayKey()) return t('today');
  const p = String(k).split('-').map(Number);
  if (p.length < 3 || p.some(isNaN)) return String(k);
  try { return new Date(p[0], p[1] - 1, p[2]).toLocaleDateString(NL(), { month: 'long', day: 'numeric' }); }
  catch (e) { return String(k); }
}
function wd(d) {
  try { return d.toLocaleDateString(NL(), { weekday: 'short' }); }
  catch (e) { return String(d.getDate()); }
}
function fmtDay(ts) {
  const d = new Date(ts), tm = new Date();
  tm.setDate(tm.getDate() + 1);
  const k = dayKey(d);
  if (k === dayKey()) return t('today');
  if (k === dayKey(tm)) return t('tomorrow');
  return dayLabel(k);
}
function fmtDue(ts) { return fmtDay(ts) + ' ' + hm(ts); }
function remText(ms) {
  const late = ms < 0;
  const m = late ? Math.floor(-ms / 60000) : Math.ceil(ms / 60000);
  if (late && m < 1) return t('now');
  const h = Math.floor(m / 60), mm = m % 60;
  let s;
  if (h >= 24) s = nf(Math.floor(h / 24)) + ' ' + t('u_day');
  else if (h >= 1) s = nf(h) + ' ' + t('u_hour') + (mm ? t('and') + nf(mm) + ' ' + t('u_min') : '');
  else s = nf(m) + ' ' + t('u_min');
  return s + ' ' + t(late ? 'overdue' : 'left');
}
function mkTime(ds, ts) {
  const p = String(ds).split('-').map(Number), q = String(ts).split(':').map(Number);
  if (p.length < 3 || q.length < 2 || p.some(isNaN) || q.some(isNaN)) return null;
  const tt = new Date(p[0], p[1] - 1, p[2], q[0], q[1], 0, 0).getTime();
  return isNaN(tt) ? null : tt;
}
function copyText(s) {
  try { if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(s); return true; } } catch (e) {}
  try {
    const a = document.createElement('textarea');
    a.value = s;
    a.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
    document.body.appendChild(a);
    a.focus(); a.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(a);
    return ok;
  } catch (e) { return false; }
}
function endOfWeek() {
  const d = new Date();
  const add = LANG === 'en' ? (7 - d.getDay()) % 7 : (5 - d.getDay() + 7) % 7;
  d.setDate(d.getDate() + add);
  d.setHours(23, 59, 0, 0);
  return d.getTime();
}
function monthOptions() {
  let fmt = null;
  try { fmt = new Intl.DateTimeFormat(NL(), { month: 'long' }); } catch (e) {}
  const out = [];
  let last = null;
  for (let i = 0; i < 215 && out.length <= 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    d.setHours(23, 59, 0, 0);
    let lb;
    try { lb = fmt ? fmt.format(d) : String(d.getMonth() + 1); } catch (e) { lb = String(d.getMonth() + 1); }
    if (lb !== last) { out.push({ label: lb, end: d.getTime() }); last = lb; }
    else out[out.length - 1].end = d.getTime();
  }
  return out.slice(0, 7);
}
function monthName(ts) {
  try { return new Date(ts).toLocaleDateString(NL(), { month: 'long' }); } catch (e) { return ''; }
}
function whenLabel(x) {
  if (x.when === 'week') return t('thisWeek');
  if (x.when === 'funded') return t('whenFunded');
  if (x.when === 'month' && x.wd) return monthName(x.wd);
  if (x.when === 'date' && x.wd) return fmtDay(x.wd);
  return '';
}
const mkCache = {};
function monthInfo(d) {
  if (LANG === 'en') {
    return { key: d.getFullYear() + '-' + pad(d.getMonth() + 1), label: d.toLocaleDateString('en-US', { month: 'short' }) };
  }
  try {
    const ps = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(d);
    let y = '', m = '';
    ps.forEach(p => {
      if (p.type === 'year' || p.type === 'relatedYear') y = p.value;
      if (p.type === 'month') m = p.value;
    });
    if (y && m) return { key: y + '-' + pad(Number(m)), label: d.toLocaleDateString('fa-IR', { month: 'long' }) };
  } catch (e) {}
  return { key: d.getFullYear() + '-' + pad(d.getMonth() + 1), label: String(d.getMonth() + 1) };
}
function monthKeyOfDay(k) {
  if (mkCache[k]) return mkCache[k];
  const p = String(k).split('-').map(Number);
  const key = monthInfo(new Date(p[0], (p[1] || 1) - 1, p[2] || 1)).key;
  mkCache[k] = key;
  return key;
}

/* ================= ذخیره‌سازی ================= */
const KEY = 'daily_app_v1';
const ARR = ['tasks', 'notes', 'shop', 'habits', 'money', 'goals'];
function def() {
  return {
    tasks: [], notes: [], shop: [], habits: [], money: [], goals: [], log: [], slots: [0, 0, 0, 0],
    set: { theme: 'dark', accent: 0, sound: true, vib: true, budget: 0, wheel: true, lang: 'fa' }
  };
}
function subsNorm(a) {
  return Array.isArray(a)
    ? a.filter(x => x && x.id).map(x => ({ id: String(x.id), t: String(x.t == null ? '' : x.t), d: !!x.d }))
    : [];
}
function buildLog(d, pm) {
  const L = [];
  d.tasks.forEach(tk => { if (tk.done && tk.doneAt) L.push({ id: uid(), k: 't', d: dayKey(new Date(tk.doneAt)), n: tk.title, ref: tk.id }); });
  d.habits.forEach(h => { h.days.forEach(k => { if (/^\d{4}-\d\d-\d\d$/.test(k)) L.push({ id: uid(), k: 'h', d: k, n: h.name, ref: h.id }); }); });
  d.money.forEach(m => L.push({ id: uid(), k: 'm', d: m.d, n: m.t || '', a: m.a, c: Number.isInteger(m.c) ? m.c : 5, ref: m.id }));
  Object.keys(pm).forEach(k => {
    const c = Math.min(30, pm[k]);
    for (let i = 0; i < c; i++) L.push({ id: uid(), k: 'p', d: k, n: '' });
  });
  return L;
}
function norm(o) {
  const d = def();
  if (o && typeof o === 'object') {
    ARR.forEach(k => {
      if (Array.isArray(o[k])) d[k] = o[k].filter(x => x && typeof x === 'object' && x.id);
    });
    d.tasks.forEach(x => { x.subs = subsNorm(x.subs); x.title = String(x.title == null ? '' : x.title); });
    d.notes.forEach(x => { x.text = String(x.text == null ? '' : x.text); });
    d.habits.forEach(h => {
      h.subs = subsNorm(h.subs);
      h.name = String(h.name == null ? '' : h.name);
      h.days = Array.isArray(h.days) ? h.days.map(String) : [];
      if (!h.sd || typeof h.sd !== 'object' || Array.isArray(h.sd)) h.sd = {};
    });
    d.goals.forEach(g => {
      if (g.target == null) { g.target = 100; g.cur = Number(g.p) || 0; g.unit = '%'; }
      g.target = Number(g.target) > 0 ? Number(g.target) : 100;
      g.cur = Number(g.cur) || 0;
      g.unit = String(g.unit == null ? '' : g.unit);
      g.step = Number(g.step) > 0 ? Number(g.step) : Math.max(1, Math.round(g.target / 10));
      g.icon = g.icon || '🎯';
      g.title = String(g.title == null ? '' : g.title);
    });
    d.shop.forEach(x => {
      x.text = String(x.text == null ? '' : x.text);
      x.price = Number(x.price) || 0;
      x.saved = Number(x.saved) || 0;
      x.when = x.when || ''; x.wd = Number(x.wd) || 0;
    });
    d.money.forEach(m => { m.a = Number(m.a) || 0; m.d = /^\d{4}-\d\d-\d\d$/.test(String(m.d)) ? String(m.d) : dayKey(); });
    const pm = {};
    if (o.pomo && typeof o.pomo === 'object' && !Array.isArray(o.pomo)) {
      Object.keys(o.pomo).forEach(k => { const n = Number(o.pomo[k]); if (n > 0) pm[k] = n; });
    }
    if (Array.isArray(o.log)) {
      d.log = o.log
        .filter(e => e && e.id && ['t', 'h', 'm', 'p'].indexOf(e.k) > -1 && /^\d{4}-\d\d-\d\d$/.test(String(e.d)))
        .map(e => {
          const x = { id: String(e.id), k: e.k, d: String(e.d), n: String(e.n == null ? '' : e.n) };
          if (e.a != null) x.a = Number(e.a) || 0;
          if (Number.isInteger(e.c)) x.c = e.c;
          if (e.ref != null) x.ref = String(e.ref);
          return x;
        });
    } else d.log = buildLog(d, pm);
    if (Array.isArray(o.slots)) {
      for (let i = 0; i < 4; i++) { const n = Math.round(Number(o.slots[i])); d.slots[i] = (n >= 1 && n <= 600) ? n : 0; }
    }
    const s = o.set;
    if (s && typeof s === 'object') {
      d.set.theme = ['dark', 'light', 'auto'].indexOf(s.theme) > -1 ? s.theme : (s.light ? 'light' : 'dark');
      const ac = Number(s.accent);
      d.set.accent = (ac >= 0 && ac < ACCENTS.length) ? Math.floor(ac) : 0;
      d.set.sound = s.sound !== false;
      d.set.vib = s.vib !== false;
      d.set.budget = Number(s.budget) > 0 ? Number(s.budget) : 0;
      d.set.wheel = s.wheel !== false;
      d.set.lang = s.lang === 'en' ? 'en' : 'fa';
    }
  }
  return d;
}
function load() {
  try { const r = localStorage.getItem(KEY); if (r) return norm(JSON.parse(r)); } catch (e) {}
  return def();
}
let S = load();
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

/* ================= روز و شب، تم ================= */
function sunTimes(d) {
  const doy = Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 864e5);
  const L = 12 + 2.3 * Math.sin(2 * Math.PI * (doy - 80) / 365);
  const noon = 12.3;
  return { sr: (noon - L / 2) * 60, ss: (noon + L / 2) * 60 };
}
function isDay() {
  const d = new Date(), tt = d.getHours() * 60 + d.getMinutes(), s = sunTimes(d);
  return tt >= s.sr && tt <= s.ss;
}
function applyTheme() {
  let light = S.set.theme === 'light';
  if (S.set.theme === 'auto') light = isDay();
  document.body.classList.toggle('light', light);
  const a = ACCENTS[S.set.accent] || ACCENTS[0];
  const st = document.documentElement.style;
  st.setProperty('--acc', a[0]);
  st.setProperty('--acc2', a[1]);
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute('content', light ? '#e2e8f0' : '#111c33');
}
function titleOf(id) {
  if (id === 'home') return t('appTitle');
  if (id === 'settings') return '⚙️ ' + t('settings');
  const s = SECTIONS.find(x => x.id === id);
  return s ? s.icon + ' ' + t('sec_' + id) : t('appTitle');
}
function applyLang() {
  LANG = S.set.lang === 'en' ? 'en' : 'fa';
  const h = document.documentElement;
  h.lang = LANG;
  h.dir = LANG === 'en' ? 'ltr' : 'rtl';
  document.title = t('appTitle');
  Object.keys(mkCache).forEach(k => { delete mkCache[k]; });
  items.forEach((b, i) => { b.querySelector('.lb').textContent = t('sec_' + SECTIONS[i].id); });
  $('hub').setAttribute('aria-label', t('menu'));
  $('homeBtn').setAttribute('aria-label', t('home'));
  $('setBtn').setAttribute('aria-label', t('settings'));
  $('title').textContent = titleOf(current);
}

/* ================= پیام، صدا، لرزش ================= */
let toastT;
function toast(m) {
  const el = $('toast');
  el.textContent = m;
  el.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(() => el.classList.remove('show'), 2800);
}
let AC = null;
function audio() {
  try {
    if (!AC) { const C = window.AudioContext || window.webkitAudioContext; if (C) AC = new C(); }
    if (AC && AC.state === 'suspended') AC.resume();
  } catch (e) {}
  return AC;
}
document.addEventListener('pointerdown', () => { audio(); }, { once: true });
function beep() {
  if (!S.set.sound) return;
  const ac = audio();
  if (!ac) return;
  try {
    const now = ac.currentTime;
    [0, 0.28, 0.56].forEach(o => {
      const os = ac.createOscillator(), g = ac.createGain();
      os.frequency.value = 880;
      os.connect(g); g.connect(ac.destination);
      g.gain.setValueAtTime(0.0001, now + o);
      g.gain.exponentialRampToValueAtTime(0.25, now + o + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, now + o + 0.22);
      os.start(now + o); os.stop(now + o + 0.25);
    });
  } catch (e) {}
}
function buzz(p) {
  if (!S.set.vib) return;
  try { if (navigator.vibrate) navigator.vibrate(p || [250, 120, 250]); } catch (e) {}
}
function alarm() { buzz(); beep(); }

/* ================= سابقهٔ آمار (حذف از بخش‌ها، آمار را پاک نمی‌کند) ================= */
function logAdd(k, d, n, x) {
  const e = { id: uid(), k: k, d: d, n: String(n == null ? '' : n) };
  if (x) for (const p in x) e[p] = x[p];
  S.log.push(e);
  return e;
}
function logDelRef(k, ref, d) {
  S.log = S.log.filter(e => !(e.k === k && e.ref === ref && (d === undefined || e.d === d)));
}

/* ================= منطق کارها، عادت‌ها، خرید، هدف ================= */
function subPct(tk) {
  const s = tk.subs || [];
  if (!s.length) return tk.done ? 100 : 0;
  return Math.round(s.filter(x => x.d).length / s.length * 100);
}
function setTaskDone(tk) {
  tk.done = true; tk.notified = true; tk.doneAt = Date.now();
  tk.subs.forEach(s => { s.d = true; });
  logDelRef('t', tk.id);
  logAdd('t', dayKey(), tk.title, { ref: tk.id });
  if (tk.rep && !tk.cloned) {
    tk.cloned = true;
    const step = (tk.rep === 'w' ? 7 : 1) * 86400000;
    let nx = (tk.due || Date.now()) + step;
    while (nx <= Date.now()) nx += step;
    S.tasks.push({
      id: uid(), title: tk.title, due: nx, done: false, notified: false, created: Date.now(),
      pri: tk.pri, rep: tk.rep, subs: tk.subs.map(s => ({ id: uid(), t: s.t, d: false })), cloud: !!tk.cloud
    });
    toast(t('nextMade'));
  } else toast(t('cheer'));
}
function undoTask(tk) {
  tk.done = false; delete tk.doneAt;
  logDelRef('t', tk.id);
}
function toggleTask(tk) {
  if (tk.done) { undoTask(tk); tk.subs.forEach(s => { s.d = false; }); }
  else setTaskDone(tk);
}
function taskSync(tk) {
  const s = tk.subs;
  if (!s.length) return;
  const all = s.every(x => x.d);
  if (all && !tk.done) setTaskDone(tk);
  else if (!all && tk.done) undoTask(tk);
}
function habStreak(h) {
  const set = new Set(h.days);
  const d = new Date();
  if (!set.has(dayKey(d))) d.setDate(d.getDate() - 1);
  let c = 0;
  while (set.has(dayKey(d))) { c++; d.setDate(d.getDate() - 1); }
  return c;
}
function hSubDone(h, k) {
  const ids = (h.sd && h.sd[k]) || [];
  return h.subs.filter(s => ids.indexOf(s.id) > -1).length;
}
function hPct(h, k) {
  const n = h.subs.length;
  if (!n) return h.days.indexOf(k) > -1 ? 100 : 0;
  return Math.round(hSubDone(h, k) / n * 100);
}
function habSetDay(h, k, on) {
  const p = h.days.indexOf(k);
  if (on && p < 0) { h.days.push(k); logAdd('h', k, h.name, { ref: h.id }); }
  else if (!on && p > -1) { h.days.splice(p, 1); logDelRef('h', h.id, k); }
}
function hSync(h, k) {
  const n = h.subs.length;
  if (!n) return;
  habSetDay(h, k, hSubDone(h, k) === n);
}
function pctGoal(g) { return Math.max(0, Math.min(100, g.target ? g.cur / g.target * 100 : 0)); }
function goalStep(g, dir) {
  const was = pctGoal(g);
  g.cur = Math.max(0, Math.round((g.cur + dir * g.step) * 100) / 100);
  if (g.cur > g.target) g.cur = g.target;
  save();
  if (was < 100 && pctGoal(g) >= 100) { toast(t('goalReached')); alarm(); }
}
function checkFunded(x) {
  if (x.price > 0 && x.saved >= x.price) {
    if (!x.fn) { x.fn = true; toast(t('fundedToast', x.text)); alarm(); }
  } else x.fn = false;
}
function pomoToday() { const k = dayKey(); return S.log.filter(e => e.k === 'p' && e.d === k).length; }

/* ================= آسمان، ابرها و پرنده (صفحه اصلی) ================= */
let cloudN = 0;
function cloudItems() {
  const now = Date.now(), l = [];
  S.tasks.forEach(tk => {
    if (tk.cloud && !tk.done) {
      l.push({
        k: 'tasks', id: tk.id, ic: '✅', tx: tk.title,
        sub: tk.due ? remText(tk.due - now) : (tk.subs.length ? nf(subPct(tk)) + '%' : ''),
        due: tk.due || 0, o: tk.due || 9e15, late: !!(tk.due && tk.due < now)
      });
    }
  });
  S.notes.forEach(n => { if (n.cloud) l.push({ k: 'notes', id: n.id, ic: '📝', tx: n.text, sub: '', due: 0, o: 9e15 - 1 }); });
  S.shop.forEach(x => {
    if (x.cloud && !x.done) {
      l.push({ k: 'shop', id: x.id, ic: '🛒', tx: x.text, sub: x.price ? nf(Math.round(Math.min(100, x.saved / x.price * 100))) + '%' : '', due: 0, o: 9e15 - 2 });
    }
  });
  S.goals.forEach(g => {
    if (g.cloud && pctGoal(g) < 100) l.push({ k: 'goals', id: g.id, ic: g.icon || '🎯', tx: g.title, sub: nf(Math.round(pctGoal(g))) + '%', due: 0, o: 9e15 - 3 });
  });
  l.sort((a, b) => a.o - b.o);
  return l;
}
const mix = (a, b, k) => a.map((v, i) => Math.round(v + (b[i] - v) * k));
const rgb = a => 'rgb(' + a[0] + ',' + a[1] + ',' + a[2] + ')';
const sm = x => x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x);
function gray(a, k) { const l = Math.round(a[0] * .3 + a[1] * .59 + a[2] * .11); return mix(a, [l, l, l], k); }

function paintSky() {
  const sc = $('scene');
  if (!sc) return;
  const d = new Date(), tt = d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60;
  const st = sunTimes(d), sr = st.sr, ss = st.ss;
  const c = Math.min(1, cloudN * 0.17);
  const day = tt >= sr && tt <= ss;
  let e = 0, tw = 0, k = 0;
  if (day) { e = Math.sin(Math.PI * (tt - sr) / (ss - sr)); k = sm(e / 0.3); }
  else {
    const dist = tt < sr ? Math.min(sr - tt, tt + 1440 - ss) : Math.min(tt - ss, sr + 1440 - tt);
    tw = Math.max(0, 1 - dist / 70);
  }
  const NT = [8, 14, 40], NB = [26, 40, 86], WT = [84, 86, 160], WB = [246, 160, 106], DT = [47, 125, 225], DB = [143, 208, 247];
  let top, bot;
  if (day) { top = mix(WT, DT, k); bot = mix(WB, DB, k); }
  else { top = mix(NT, WT, tw); bot = mix(NB, WB, tw); }
  const dl = day ? (0.35 + 0.65 * k) : 0.35 * tw;
  top = gray(top, c * 0.85); bot = gray(bot, c * 0.8);
  const dk = 1 - 0.22 * c;
  top = top.map(v => Math.round(v * dk)); bot = bot.map(v => Math.round(v * dk));
  let cA = mix([190, 200, 228], [255, 255, 255], dl), cB = mix([96, 110, 156], [205, 219, 238], dl);
  const gA = mix([116, 124, 142], [212, 218, 228], dl), gB = mix([70, 80, 104], [148, 158, 176], dl);
  cA = mix(cA, gA, c * .75); cB = mix(cB, gB, c * .75);
  sc.style.setProperty('--st', rgb(top));
  sc.style.setProperty('--sb', rgb(bot));
  /* رنگ ابرها روی ریشه تنظیم می‌شود تا گرادیان‌های SVG هم آن را ببینند */
  const rs = document.documentElement.style;
  rs.setProperty('--cA', rgb(cA));
  rs.setProperty('--cB', rgb(cB));
  rs.setProperty('--gA', rgb(gA));
  rs.setProperty('--gB', rgb(gB));

  const vis = 1 - c * 0.97;
  const sun = $('sun'), moon = $('moon'), stars = $('stars'), cov = $('cover');
  if (sun) {
    if (day) {
      const k2 = sm(e / 0.45);
      sun.style.display = 'block';
      sun.style.transform = 'translateY(' + (HEAD - e * (HEAD - 24)) + 'px)';
      sun.style.opacity = vis;
      sun.style.setProperty('--s1', rgb(mix([255, 120, 50], [255, 232, 120], k2)));
      sun.style.setProperty('--s2', rgb(mix([255, 90, 30], [255, 190, 40], k2)));
    } else sun.style.display = 'none';
  }
  if (moon) {
    if (!day) {
      const span = 1440 - (ss - sr);
      const pm = Math.min(1, Math.max(0, (tt > ss ? tt - ss : tt + 1440 - ss) / span));
      const em = Math.sin(Math.PI * pm);
      moon.style.display = 'block';
      moon.style.transform = 'translateY(' + (HEAD - em * (HEAD - 24)) + 'px) rotate(-20deg)';
      moon.style.opacity = vis;
    } else moon.style.display = 'none';
  }
  if (stars) stars.style.opacity = day ? 0 : Math.max(0, 1 - tw) * (1 - c * 0.9);
  if (cov) cov.style.opacity = c;
}

/* چیدن ابرها: هر ابر جایی می‌گیرد که با ابرهای دیگر برخورد نکند */
function findSpot(fw, fh, key, x0, y0, x1, y1, placed) {
  const aw = x1 - x0 - fw, ah = y1 - y0 - fh;
  if (aw < 0 || ah < 0) return null;
  const free = (x, y) => {
    for (let i = 0; i < placed.length; i++) {
      const p = placed[i];
      if (x < p.x + p.w && x + fw > p.x && y < p.y + p.h && y + fh > p.y) return false;
    }
    return true;
  };
  for (let i = 0; i < 28; i++) {
    const x = x0 + hashFrac(key, 'x' + i) * aw, y = y0 + hashFrac(key, 'y' + i) * ah;
    if (free(x, y)) return { x: x, y: y };
  }
  for (let y = 0; y <= ah; y += 12) {
    for (let x = 0; x <= aw; x += 12) {
      if (free(x0 + x, y0 + y)) return { x: x0 + x, y: y0 + y };
    }
  }
  return null;
}
function layoutClouds() {
  const sc = $('scene'), box = $('clouds');
  if (!sc || !box) return;
  const W = sc.clientWidth, H = sc.clientHeight;
  if (!W || !H) return;
  const closed = document.body.classList.contains('wheel-closed');
  const reserve = closed ? 72 : (wheel.offsetHeight / 2 + 24 + 22 + 14);
  const mx = 28, my = 30;
  const x0 = 8, x1 = W - 8, y0 = 146, y1 = H - reserve;
  const maxW = Math.min(176, Math.max(110, W * 0.5));
  const placed = [];
  const cws = [].slice.call(box.querySelectorAll('.cw'));
  cws.forEach(el => {
    el.style.display = '';
    el.style.maxWidth = maxW + 'px';
    const fw = el.offsetWidth + mx * 2, fh = el.offsetHeight + my * 2;
    const spot = findSpot(fw, fh, el.getAttribute('data-k') || '', x0, y0, x1, y1, placed);
    if (!spot) { el.style.display = 'none'; return; }
    el.style.left = (spot.x + mx) + 'px';
    el.style.top = (spot.y + my) + 'px';
    el.style.opacity = '1';
    placed.push({ x: spot.x, y: spot.y, w: fw, h: fh });
  });
  const more = $('more');
  if (more) {
    const extra = Number(box.getAttribute('data-total') || 0) - placed.length;
    if (extra > 0) { more.style.display = ''; more.textContent = t('moreClouds', nf(extra)); }
    else more.style.display = 'none';
  }
}
function tickClouds() {
  const now = Date.now();
  view.querySelectorAll('.cloud[data-due]').forEach(el => {
    const due = Number(el.getAttribute('data-due'));
    const s = el.querySelector('.c-s');
    if (s) s.textContent = remText(due - now);
    el.classList.toggle('late', due < now);
  });
}
function habitsInner() {
  const today = dayKey(), C = 94.25;
  const rings = S.habits.slice(0, 6).map(h => {
    const p = hPct(h, today);
    const ch = Array.from(h.name || '?')[0] || '?';
    return '<button class="rh' + (p >= 100 ? ' full' : '') + '" type="button" data-act="h-toggle" data-id="' + esc(h.id) + '" data-lp="habits:' + esc(h.id) + '" aria-label="' + esc(h.name) + '">' +
      '<svg viewBox="0 0 36 36"><circle class="rb" cx="18" cy="18" r="15"/><circle class="rp" cx="18" cy="18" r="15" stroke-dasharray="' + C + '" stroke-dashoffset="' + (C * (1 - p / 100)).toFixed(2) + '"/></svg>' +
      '<span>' + (p >= 100 ? '✓' : esc(ch)) + '</span></button>';
  }).join('');
  const more = S.habits.length > 6 ? '<button class="rm" type="button" data-go="3">+' + nf(S.habits.length - 6) + '</button>' : '';
  return rings + more;
}
const BIRD_SVG = '<svg viewBox="0 0 72 52" aria-hidden="true">' +
  '<path d="M54 28 L71 22 L70 33 L55 35 Z" fill="currentColor"/>' +
  '<ellipse cx="36" cy="30" rx="20" ry="11" fill="currentColor"/>' +
  '<circle cx="17" cy="22" r="9" fill="currentColor"/>' +
  '<path d="M9 21 L0 24 L9 26 Z" fill="#f59e0b"/>' +
  '<circle cx="15" cy="20" r="2" fill="#fff"/><circle cx="14.5" cy="20" r="1" fill="#111"/>' +
  '<path d="M33 40 L33 48 M41 40 L41 48" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>' +
  '<path class="wing" d="M40 26 C48 8 62 4 70 8 C60 12 54 20 50 32 Z" fill="#2a3550"/></svg>';

/* ابر با بافت SVG: چند لکهٔ بیضی، لبهٔ ناصاف با نویز، نرم‌شده و سایه‌دار */
function cloudSvg(shape, flip) {
  const u = '<use href="#' + shape + '" xlink:href="#' + shape + '"';
  return '<svg class="puff' + (flip ? ' flip' : '') + '" viewBox="0 0 240 120" preserveAspectRatio="none" aria-hidden="true">' +
    '<g filter="url(#cl-soft)">' +
    u + ' style="fill:var(--cB)" transform="translate(0 9)"/>' +
    u + ' style="fill:url(#cl-g)"/>' +
    u + ' class="tint"/>' +
    '</g></svg>';
}
function coverSvg(shape) {
  const u = '<use href="#' + shape + '" xlink:href="#' + shape + '"';
  return '<svg viewBox="0 0 240 120" preserveAspectRatio="none" aria-hidden="true"><g filter="url(#cl-soft)">' +
    u + ' style="fill:var(--gB)" transform="translate(0 9)"/>' +
    u + ' style="fill:url(#cl-gg)"/>' +
    '</g></svg>';
}
function vHome() {
  const cl = cloudItems();
  cloudN = cl.length;
  const d = new Date();
  let ds;
  try { ds = d.toLocaleDateString(NL(), { weekday: 'long', day: 'numeric', month: 'long' }); }
  catch (e) { ds = dayKey(d); }
  const cells = cl.slice(0, 24).map((c, i) => {
    const hs = hash(c.k + c.id);
    return '<div class="cw" data-k="' + esc(c.k + c.id) + '" style="animation-duration:' + (12 + hs % 9) + 's;animation-delay:-' + (hs % 11) + 's">' +
      '<div class="cloud' + (c.late ? ' late' : '') + '" data-open="' + c.k + ':' + esc(c.id) + '"' + (c.due ? ' data-due="' + c.due + '"' : '') + ' style="animation-delay:-' + (i * 1.3) + 's">' +
      cloudSvg(SHAPES[hs % 3], (hs >> 2) % 2 === 1) +
      '<div class="c-t">' + c.ic + ' ' + esc(c.tx) + '</div>' +
      (c.sub ? '<div class="c-s">' + esc(c.sub) + '</div>' : '') +
      (c.k === 'tasks' ? '<button class="c-ok" type="button" data-act="t-toggle" data-id="' + esc(c.id) + '" aria-label="OK">✓</button>' : '') +
      '</div></div>';
  }).join('');
  return '<div class="scene" id="scene">' +
    '<div class="stars" id="stars"></div>' +
    '<div class="orb"><div class="sun" id="sun"></div><div class="moon" id="moon"></div></div>' +
    '<div class="cover" id="cover">' + coverSvg('cl-a') + coverSvg('cl-b') + coverSvg('cl-c') + '</div>' +
    '<div class="hud"><div class="clock" id="clock">' + hm(Date.now()) + '</div><div class="date">' + esc(ds) + '</div></div>' +
    '<div class="hb' + (S.habits.length ? '' : ' hide') + '" id="hbw">' + habitsInner() + '</div>' +
    '<div class="clouds" id="clouds" data-total="' + cl.length + '">' + cells + '</div>' +
    '<button class="pillmore" id="more" type="button" data-act="more-clouds" style="display:none"></button>' +
    (cl.length ? '' : '<div class="skyhint">' + t('skyEmpty') + '<small>' + t('skyEmptySub') + '</small></div>') +
    '<button class="bird" id="bird" type="button" data-act="quick" aria-label="' + esc(t('birdLabel')) + '">' + BIRD_SVG + '<i class="bp">+</i></button>' +
    '</div>';
}
function flyBird() {
  const b = $('bird');
  if (!b) return;
  b.classList.remove('back');
  b.classList.add('go');
  setTimeout(() => {
    const bb = $('bird');
    if (bb) {
      bb.classList.remove('go');
      bb.classList.add('back');
      setTimeout(() => { const b3 = $('bird'); if (b3) b3.classList.remove('back'); }, 900);
    }
  }, 1300);
}

/* ================= کارها ================= */
let tFilter = 'open';
function taskSort(a, b) {
  const ad = a.due || Infinity, bd = b.due || Infinity;
  if (ad !== bd) return ad < bd ? -1 : 1;
  const p = (b.pri == null ? 1 : b.pri) - (a.pri == null ? 1 : a.pri);
  if (p) return p;
  return (a.created || 0) - (b.created || 0);
}
function isTodayTask(tk, now, today) {
  return !tk.done && tk.due && (tk.due < now || dayKey(new Date(tk.due)) === today);
}
function subsHtml(subs, attrs, doneFn) {
  return '<div class="subs">' + subs.map(s => {
    const on = doneFn(s);
    return '<button class="sb' + (on ? ' on' : '') + '" type="button" ' + attrs + ' data-sid="' + esc(s.id) + '"><i>' + (on ? '✔' : '') + '</i>' + esc(s.t) + '</button>';
  }).join('') + '</div>';
}
function vTasks() {
  const now = Date.now(), today = dayKey();
  const openN = S.tasks.filter(x => !x.done).length;
  const todayN = S.tasks.filter(x => isTodayTask(x, now, today)).length;
  const doneN = S.tasks.filter(x => x.done).length;
  const list = S.tasks.filter(x =>
    tFilter === 'done' ? x.done : tFilter === 'today' ? isTodayTask(x, now, today) : !x.done);
  if (tFilter === 'done') list.sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0));
  else list.sort(taskSort);
  const tab = (id, label, n) =>
    '<button class="tab' + (tFilter === id ? ' on' : '') + '" type="button" data-act="tfilter" data-id="' + id + '">' + label + ' (' + nf(n) + ')</button>';
  let h = '<button class="btn addb" type="button" data-act="add" data-id="tasks">' + t('newTask') + '</button>' +
    '<div class="tabs">' + tab('open', t('tabOpen'), openN) + tab('today', t('today'), todayN) + tab('done', t('tabDone'), doneN) + '</div>';
  if (!list.length) return h + empty(t(tFilter === 'done' ? 'noDone' : 'noTasks'));
  h += list.map(x => {
    const late = !x.done && x.due && x.due < now;
    const pri = x.pri == null ? 1 : x.pri;
    const sub = (x.due ? fmtDue(x.due) + (x.done ? '' : ' · ' + remText(x.due - now)) : t('noSchedule')) + (x.rep ? ' · 🔁' : '') + (x.cloud ? ' · ☁️' : '');
    const hasSubs = x.subs.length > 0;
    return '<div class="item p' + pri + (x.done ? ' done' : '') + (late ? ' late' : '') + '" data-lp="tasks:' + esc(x.id) + '">' +
      '<button class="chk" type="button" data-act="t-toggle" data-id="' + esc(x.id) + '">' + (x.done ? '✔' : '') + '</button>' +
      '<div class="grow"><div class="ttl">' + esc(x.title) + '</div><div class="sub">' + sub + '</div>' +
      (hasSubs ? '<div class="bar"><i style="width:' + subPct(x) + '%"></i></div>' + subsHtml(x.subs, 'data-act="t-sub" data-id="' + esc(x.id) + '"', s => s.d) : '') +
      '</div><button class="mini" type="button" data-open="tasks:' + esc(x.id) + '" aria-label="⋮">⋮</button></div>';
  }).join('');
  if (tFilter === 'done' && doneN) h += '<button class="btn ghost" type="button" data-act="t-clear">' + t('clearDone') + '</button>';
  return h;
}

/* ================= یادداشت ================= */
function vNotes() {
  let h = '<button class="btn addb" type="button" data-act="add" data-id="notes">' + t('newNote') + '</button>';
  if (!S.notes.length) return h + empty(t('noNotes'));
  const l = S.notes.slice().sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || (b.t || 0) - (a.t || 0));
  h += '<input id="n-q" class="inp" type="search" placeholder="' + esc(t('searchNotes')) + '" autocomplete="off">';
  h += l.map(n =>
    '<div class="item" data-lp="notes:' + esc(n.id) + '" data-s="' + esc(String(n.text).toLowerCase()) + '">' +
    '<div class="grow"><div class="txt clamp" data-act="n-open">' + (n.pin ? '📌 ' : '') + esc(n.text) + '</div>' +
    '<div class="sub">' + fmtDue(n.t || Date.now()) + (n.cloud ? ' · ☁️' : '') + '</div></div>' +
    '<button class="mini" type="button" data-open="notes:' + esc(n.id) + '" aria-label="⋮">⋮</button></div>'
  ).join('');
  return h;
}
function filterNotes() {
  const q = $('n-q');
  if (!q) return;
  const s = q.value.trim().toLowerCase();
  view.querySelectorAll('.item[data-s]').forEach(el => {
    el.style.display = (!s || el.getAttribute('data-s').indexOf(s) > -1) ? '' : 'none';
  });
}

/* ================= خرید ================= */
function vShop() {
  let h = '<button class="btn addb" type="button" data-act="add" data-id="shop">' + t('newItem') + '</button>';
  if (!S.shop.length) return h + empty(t('noShop'));
  const l = S.shop.slice().sort((a, b) => (a.done ? 1 : 0) - (b.done ? 1 : 0));
  let tot = 0, sv = 0;
  S.shop.forEach(x => { if (!x.done) { tot += x.price; sv += Math.min(x.saved, x.price || x.saved); } });
  if (tot > 0) h += '<div class="muted center" style="margin-top:0">' + t('shopTotal', nf(tot, true), nf(sv, true)) + '</div>';
  h += l.map(x => {
    const fund = x.price > 0 && x.saved >= x.price;
    const pc = x.price > 0 ? Math.min(100, Math.round(x.saved / x.price * 100)) : 0;
    const wl = whenLabel(x);
    return '<div class="item v' + (x.done ? ' done' : '') + '" data-lp="shop:' + esc(x.id) + '">' +
      '<div class="row-top"><button class="chk" type="button" data-act="s-toggle" data-id="' + esc(x.id) + '">' + (x.done ? '✔' : '') + '</button>' +
      '<div class="grow"><div class="ttl">' + esc(x.text) + '</div><div class="sub">' + (x.price ? nf(x.price, true) + ' ' + t('cur') : t('noPrice')) +
      (wl ? ' · ⏳ ' + esc(wl) : '') + (x.cloud ? ' · ☁️' : '') + '</div></div>' +
      '<button class="mini" type="button" data-open="shop:' + esc(x.id) + '" aria-label="⋮">⋮</button></div>' +
      (x.price > 0
        ? '<div class="bar' + (fund ? ' ok' : '') + '"><i style="width:' + pc + '%"></i></div>' +
          '<div class="row-top"><div class="sub grow">' + (fund ? t('funded') + ' ' : '') + t('of', nf(x.saved, true), nf(x.price, true)) + ' (' + nf(pc) + '%)</div>' +
          '<button class="chip on" type="button" data-act="s-sav" data-id="' + esc(x.id) + '">' + t('savingsBtn') + '</button></div>'
        : '') + '</div>';
  }).join('');
  if (S.shop.some(x => x.done)) {
    h += '<div class="row gap"><button class="btn ghost" type="button" data-act="s-copy">' + t('copySel') + '</button>' +
      '<button class="btn ghost" type="button" data-act="s-clear">' + t('clearSel') + '</button></div>';
  }
  return h;
}

/* ================= عادت‌ها ================= */
function vHabits() {
  const today = dayKey();
  let h = '<button class="btn addb" type="button" data-act="add" data-id="habits">' + t('newHabit') + '</button>';
  if (!S.habits.length) return h + empty(t('noHabits'));
  h += S.habits.map(x => {
    const set = new Set(x.days);
    const on = set.has(today);
    const hasSubs = x.subs.length > 0;
    const ids = (x.sd && x.sd[today]) || [];
    let dots = '';
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      dots += '<span class="dot' + (set.has(dayKey(d)) ? ' on' : '') + (i === 0 ? ' today' : '') + '"></span>';
    }
    return '<div class="item" data-lp="habits:' + esc(x.id) + '">' +
      '<button class="chk' + (on ? ' on' : '') + '" type="button" data-act="h-toggle" data-id="' + esc(x.id) + '">' + (on ? '✔' : '') + '</button>' +
      '<div class="grow"><div class="ttl">' + esc(x.name) + '</div>' +
      '<div class="sub">' + t('streakDays', nf(habStreak(x))) + (hasSubs ? t('todayPct', nf(hPct(x, today))) : '') + '</div>' +
      (hasSubs ? '<div class="bar' + (on ? ' ok' : '') + '"><i style="width:' + hPct(x, today) + '%"></i></div>' +
        subsHtml(x.subs, 'data-act="h-sub" data-id="' + esc(x.id) + '"', s => ids.indexOf(s.id) > -1) : '') +
      '<div class="dots">' + dots + '</div></div>' +
      '<button class="mini" type="button" data-open="habits:' + esc(x.id) + '" aria-label="⋮">⋮</button></div>';
  }).join('');
  return h;
}

/* ================= تایمر ================= */
const C_ARC = 339.292;
const T = { total: 25 * 60, left: 25 * 60, end: 0, run: false };
function tmLeft() { return T.run ? Math.max(0, Math.ceil((T.end - Date.now()) / 1000)) : T.left; }
function mmss(s) { return pad(Math.floor(s / 60)) + ':' + pad(s % 60); }
function arcOff(s) { return T.total ? C_ARC * (1 - s / T.total) : 0; }
function setTimerMin(m) { T.run = false; T.total = m * 60; T.left = T.total; refresh(false); }
function slotBtn(i) {
  const m = S.slots[i];
  return '<button class="slotb' + (m && T.total === m * 60 ? ' on' : '') + '" type="button" data-act="slot" data-id="' + i + '"' + (m ? ' data-lp="slot:' + i + '"' : '') + '>' +
    (m ? '<b>' + nf(m) + '</b><small>' + t('minU') + '</small>' : '<b>＋</b><small>' + t('slotNew') + '</small>') + '</button>';
}
function vTimer() {
  const s = tmLeft();
  const m = T.total / 60;
  return '<div class="card center"><div class="chips c-center">' +
    '<button class="chip' + (m === 25 ? ' on' : '') + '" type="button" data-act="tm-set" data-min="25">' + t('focus25') + '</button>' +
    '<button class="chip' + (m === 5 ? ' on' : '') + '" type="button" data-act="tm-set" data-min="5">' + t('rest5') + '</button>' +
    '<button class="chip' + (m === 15 ? ' on' : '') + '" type="button" data-act="tm-set" data-min="15">' + t('rest15') + '</button></div>' +
    '<div class="trow"><div class="tside">' + slotBtn(0) + slotBtn(1) + '</div>' +
    '<div class="tring' + (T.run ? ' run' : '') + '" id="tring"><svg viewBox="0 0 120 120"><circle class="bgc" cx="60" cy="60" r="54"/>' +
    '<circle id="tm-arc" class="arc" cx="60" cy="60" r="54" stroke-dasharray="' + C_ARC + '" stroke-dashoffset="' + arcOff(s) + '"/></svg>' +
    '<div class="big" id="tm-disp">' + mmss(s) + '</div></div>' +
    '<div class="tside">' + slotBtn(2) + slotBtn(3) + '</div></div>' +
    '<div class="row"><button class="btn" type="button" data-act="tm-toggle">' + t(T.run ? 'pause' : 'start') + '</button>' +
    '<button class="btn ghost" type="button" data-act="tm-reset">' + t('restart') + '</button></div>' +
    '<div class="muted">' + t('timerHelp', nf(pomoToday())) + '</div></div>';
}
function tickTimer() {
  if (!T.run) return;
  const s = tmLeft();
  if (s <= 0) {
    T.run = false; T.left = 0;
    if (T.total >= 20 * 60) logAdd('p', dayKey(), '');
    save();
    toast(t('timerDone'));
    alarm();
    if (current === 'timer') refresh(true);
    return;
  }
  if (current === 'timer') {
    const d = $('tm-disp'), a = $('tm-arc');
    const tx = mmss(s);
    if (d && d.textContent !== tx) d.textContent = tx;
    if (a) a.style.strokeDashoffset = arcOff(s);
  }
}

/* ================= هزینه ================= */
function vMoney() {
  const today = dayKey(), month = today.slice(0, 7);
  let td = 0, mo = 0;
  S.money.forEach(m => {
    const a = Number(m.a) || 0;
    if (m.d === today) td += a;
    if (String(m.d).slice(0, 7) === month) mo += a;
  });
  const b = S.set.budget;
  let bud = '';
  if (b > 0) {
    const p = mo / b;
    bud = '<div class="card"><div class="row-top"><div class="ttl grow">' + t('budgetMonth') + '</div><span class="pct' + (p > 1 ? ' bad' : '') + '">' + nf(Math.round(p * 100)) + '%</span></div>' +
      '<div class="bar' + (p > 1 ? ' over' : '') + '"><i style="width:' + Math.min(100, Math.round(p * 100)) + '%"></i></div>' +
      '<div class="sub">' + t('of', nf(mo, true), nf(b, true)) + ' ' + t('cur') + (p > 1 ? t('overBudget') : '') + '</div></div>';
  }
  let h = '<div class="stats"><div class="stat"><b>' + nf(td, true) + '</b>' + t('moneyToday') + '</div>' +
    '<div class="stat"><b>' + nf(mo, true) + '</b>' + t('moneyMonth') + '</div></div>' + bud +
    '<button class="btn addb" type="button" data-act="add" data-id="money">' + t('newSpend') + '</button>';
  if (!S.money.length) return h + empty(t('noSpend'));
  h += S.money.slice().sort((a, b2) => String(b2.d).localeCompare(String(a.d))).slice(0, 80).map(m => {
    const ci = Number.isInteger(m.c) ? m.c : 5;
    return '<div class="item" data-lp="money:' + esc(m.id) + '"><div class="grow"><div class="ttl">' + CAT_ICONS[ci] + ' ' +
      esc(m.t || t('cat' + ci)) + '</div><div class="sub">' + dayLabel(m.d) + '</div></div>' +
      '<div class="amt">' + nf(m.a, true) + '</div>' +
      '<button class="mini" type="button" data-open="money:' + esc(m.id) + '" aria-label="⋮">⋮</button></div>';
  }).join('');
  return h;
}

/* ================= هدف‌ها ================= */
function goalStatus(g) {
  const p = pctGoal(g);
  if (p >= 100) return t('goalDone');
  if (!g.due) return '';
  const now = Date.now();
  if (g.due < now) return t('goalLate');
  const days = Math.ceil((g.due - now) / 86400000);
  const exp = Math.min(1, Math.max(0, (now - (g.created || now)) / Math.max(1, g.due - (g.created || now))));
  const ok = p / 100 >= exp - 0.05;
  return t('goalDays', nf(days), t(ok ? 'onTrack' : 'behind'));
}
function vGoals() {
  let h = '<button class="btn addb" type="button" data-act="add" data-id="goals">' + t('newGoal') + '</button>';
  if (!S.goals.length) return h + empty(t('noGoals'));
  h += S.goals.map(g => {
    const p = Math.round(pctGoal(g));
    const st = goalStatus(g);
    return '<div class="item v" data-lp="goals:' + esc(g.id) + '">' +
      '<div class="row-top"><span class="gi">' + esc(g.icon || '🎯') + '</span><div class="ttl grow">' + esc(g.title) + (g.cloud ? ' ☁️' : '') + '</div>' +
      '<span class="pct">' + nf(p) + '%</span>' +
      '<button class="mini" type="button" data-open="goals:' + esc(g.id) + '" aria-label="⋮">⋮</button></div>' +
      '<div class="bar' + (p >= 100 ? ' ok' : '') + '"><i style="width:' + p + '%"></i></div>' +
      '<div class="row-top"><div class="sub grow">' + t('of', nd(g.cur), nd(g.target)) + ' ' + esc(g.unit) + (st ? '<br>' + st : '') + '</div>' +
      '<button class="chip" type="button" data-act="g-dec" data-id="' + esc(g.id) + '">− ' + nd(g.step) + '</button>' +
      '<button class="chip on" type="button" data-act="g-inc" data-id="' + esc(g.id) + '">+ ' + nd(g.step) + '</button></div></div>';
  }).join('');
  return h;
}

/* ================= آمار ================= */
function yearBuckets() {
  const bs = [], seen = {};
  for (let i = 0; i < 400 && bs.length < 12; i++) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const mi = monthInfo(d);
    if (!seen[mi.key]) { seen[mi.key] = 1; bs.push(mi); }
  }
  return bs.reverse();
}
function series(kind, range) {
  const v = e => kind === 'm' ? (Number(e.a) || 0) : 1;
  const ents = S.log.filter(e => e.k === kind);
  if (range === 'y') {
    const bs = yearBuckets(), idx = {};
    bs.forEach((b, i) => { idx[b.key] = i; });
    const vals = bs.map(() => 0);
    ents.forEach(e => { const i = idx[monthKeyOfDay(e.d)]; if (i !== undefined) vals[i] += v(e); });
    return { vals: vals, labels: bs.map(b => b.label), cls: 'yr' };
  }
  const n = range === 'm' ? 30 : 7, days = [], idx = {};
  for (let i = n - 1; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); idx[dayKey(d)] = n - 1 - i; }
  const vals = days.map(() => 0);
  ents.forEach(e => { const i = idx[e.d]; if (i !== undefined) vals[i] += v(e); });
  const labels = days.map((d, i) => n === 7 ? wd(d) : ((n - 1 - i) % 5 === 0 ? nf(d.getDate()) : ''));
  return { vals: vals, labels: labels, cls: n > 7 ? 'dense' : '' };
}
function bars(vals, labels, fmt, cls) {
  const mx = Math.max.apply(null, vals.concat([1]));
  return '<div class="bars ' + (cls || '') + '">' + vals.map((x, i) =>
    '<div class="bcol"><span class="bv">' + fmt(x) + '</span><div class="bw"><div class="bb" style="height:' + Math.round(x / mx * 100) + '%"></div></div><span class="bl">' + esc(labels[i]) + '</span></div>'
  ).join('') + '</div>';
}
const nfmt = x => x ? nf(x) : '';
const kfmt = x => x ? nf(Math.round(x / 1000)) + 'k' : '';
function entriesFor(kind, range) {
  let ok;
  if (range === 'y') {
    const ks = {};
    yearBuckets().forEach(b => { ks[b.key] = 1; });
    ok = e => ks[monthKeyOfDay(e.d)] === 1;
  } else {
    const from = dayKeyAgo(range === 'm' ? 29 : 6), to = dayKey();
    ok = e => e.d >= from && e.d <= to;
  }
  return S.log.filter(e => e.k === kind && ok(e)).reverse().sort((a, b) => a.d < b.d ? 1 : a.d > b.d ? -1 : 0);
}
function vStats() {
  const today = dayKey();
  const sT = series('t', 'w'), sH = series('h', 'w'), sM = series('m', 'w'), sP = series('p', 'w');
  let best = 0;
  S.habits.forEach(h => { best = Math.max(best, habStreak(h)); });
  const month = today.slice(0, 7), cat = {};
  let top = -1, topV = 0;
  S.log.forEach(e => {
    if (e.k === 'm' && String(e.d).slice(0, 7) === month) {
      const c = Number.isInteger(e.c) ? e.c : 5;
      cat[c] = (cat[c] || 0) + (Number(e.a) || 0);
      if (cat[c] > topV) { topV = cat[c]; top = c; }
    }
  });
  const card = (k, s, fmt, extra) =>
    '<div class="card tap" data-act="stat-open" data-id="' + k + '"><div class="row-top"><div class="ttl grow">' + t('ch_' + k) + '</div><small class="sub">' + t('tapMore') + '</small></div>' +
    bars(s.vals, s.labels, fmt, s.cls) + (extra || '') + '</div>';
  return '<div class="stats">' +
    '<div class="stat"><b>' + nf(sT.vals[6]) + '</b>' + t('st_today') + '</div>' +
    '<div class="stat"><b>' + nf(sum(sT.vals)) + '</b>' + t('st_week') + '</div>' +
    '<div class="stat"><b>' + nf(best) + '</b>' + t('st_streak') + '</div>' +
    '<div class="stat"><b>' + nf(sP.vals[6]) + '</b>' + t('st_pomo') + '</div></div>' +
    card('t', sT, nfmt) + card('h', sH, nfmt) +
    card('m', sM, kfmt, '<div class="sub" style="margin-top:10px">' + t('weekTotal', nf(sum(sM.vals), true), t('cur')) +
      (top > -1 ? '<br>' + t('topCat', CAT_ICONS[top] + ' ' + t('cat' + top), nf(topV, true), t('cur')) : '') + '</div>') +
    card('p', sP, nfmt);
}
function statSheet(kind) {
  let range = 'w';
  const rowHtml = e => {
    let name;
    if (kind === 'm') { const ci = Number.isInteger(e.c) ? e.c : 5; name = CAT_ICONS[ci] + ' ' + (e.n || t('cat' + ci)); }
    else if (kind === 'p') name = '🍅 ' + t('focusSession');
    else name = e.n || '—';
    return '<div class="sub-row"><div class="grow"><div class="ttl">' + esc(name) + '</div><div class="sub">' + dayLabel(e.d) +
      (kind === 'm' ? ' · ' + nf(e.a, true) + ' ' + t('cur') : '') + '</div></div>' +
      '<button class="mini" type="button" data-sa="ldel" data-id="' + esc(e.id) + '" aria-label="' + esc(t('del')) + '">✕</button></div>';
  };
  return {
    render() {
      const sr = series(kind, range);
      const total = sum(sr.vals);
      const list = entriesFor(kind, range);
      let h = '<div class="grab"></div><div class="sh-t">' + t('ch_' + kind) + '</div>';
      h += '<div class="tabs">' + [['w', 'rWeek'], ['m', 'rMonth'], ['y', 'rYear']].map(r =>
        '<button class="tab' + (range === r[0] ? ' on' : '') + '" type="button" data-sa="sr" data-v="' + r[0] + '">' + t(r[1]) + '</button>').join('') + '</div>';
      h += bars(sr.vals, sr.labels, kind === 'm' ? kfmt : nfmt, sr.cls);
      h += '<div class="pk-prev">' + t('total') + ': ' + (kind === 'm' ? nf(total, true) + ' ' + t('cur') : nf(total)) + '</div>';
      h += '<div class="lbl">' + t('history') + '</div>';
      h += list.length ? list.slice(0, 150).map(rowHtml).join('') : '<div class="empty">' + t('noEntries') + '</div>';
      h += '<div class="sub gap">' + t('delNote') + '</div>';
      h += '<div class="row sh-b"><button class="btn ghost" type="button" data-sa="close">' + t('closeB') + '</button></div>';
      return h;
    },
    act(a, el) {
      if (a === 'sr') { range = el.dataset.v; repaint(); }
      else if (a === 'ldel') {
        const id = el.dataset.id;
        S.log = S.log.filter(e => e.id !== id);
        save(); toast(t('entryDeleted'));
        refresh(true); repaint();
      } else if (a === 'close') popSheet();
    }
  };
}

/* ================= تنظیمات ================= */
function vSettings() {
  const seg = (list, cur, action) => '<div class="seg">' + list.map(o =>
    '<button type="button" class="' + (cur === o[0] ? 'on' : '') + '" data-act="' + action + '" data-id="' + o[0] + '">' + o[1] + '</button>').join('') + '</div>';
  const sw = (on, id) => '<button class="switch' + (on ? ' on' : '') + '" type="button" data-act="tog" data-id="' + id + '" role="switch" aria-checked="' + (on ? 'true' : 'false') + '"></button>';
  const sws = ACCENTS.map((a, i) =>
    '<button class="swatch' + (S.set.accent === i ? ' on' : '') + '" type="button" data-act="accent" data-id="' + i + '" style="background:linear-gradient(135deg,' + a[0] + ',' + a[1] + ')" aria-label="' + (i + 1) + '"></button>').join('');
  const group = (title, rows) => '<div class="sg"><div class="sg-t">' + title + '</div><div class="sg-c">' + rows + '</div></div>';
  return group('🌐 ' + t('language'),
      '<div class="srow col">' + seg([['fa', 'فارسی'], ['en', 'English']], S.set.lang, 'lang') + '</div>') +
    group('🎨 ' + t('appearance'),
      '<div class="srow col"><div class="sl"><b>' + t('theme') + '</b><small>' + t('thAutoHint') + '</small></div>' +
      seg([['dark', t('thDark')], ['light', t('thLight')], ['auto', t('thAuto')]], S.set.theme, 'theme-set') + '</div>' +
      '<div class="srow col"><div class="sl"><b>' + t('accent') + '</b></div><div class="chips" style="margin:0">' + sws + '</div></div>') +
    group('🔔 ' + t('alerts'),
      '<div class="srow"><span class="si">🔊</span><div class="sl"><b>' + t('sound') + '</b><small>' + t('soundSub') + '</small></div>' + sw(S.set.sound, 'sound') + '</div>' +
      '<div class="srow"><span class="si">📳</span><div class="sl"><b>' + t('vib') + '</b><small>' + t('vibSub') + '</small></div>' + sw(S.set.vib, 'vib') + '</div>') +
    group('💰 ' + t('budget'),
      '<div class="srow col"><div class="sl"><b>' + t('budgetMonthly') + '</b><small>' + t('budgetSub') + '</small></div>' +
      '<div class="row"><input id="set-budget" class="inp" type="text" inputmode="numeric" value="' + (S.set.budget || '') + '" placeholder="5000000" autocomplete="off">' +
      '<button class="btn sm" type="button" data-act="budget-save">' + t('save') + '</button></div></div>') +
    group('💾 ' + t('data'),
      '<div class="srow col"><div class="sl"><b>' + t('backup') + '</b></div>' +
      '<textarea id="bk" class="inp" rows="4" style="margin:0" placeholder="' + esc(t('backupPh')) + '"></textarea>' +
      '<div class="row"><button class="btn" type="button" data-act="bk-make">' + t('bkMake') + '</button>' +
      '<button class="btn ghost" type="button" data-act="bk-load">' + t('bkLoad') + '</button></div></div>') +
    group('⚠️ ' + t('danger'),
      '<div class="srow col"><button class="btn danger" type="button" data-act="reset">' + t('eraseAll') + '</button></div>') +
    '<div class="muted center">' + t('localNote') + '</div>';
}

const V = { home: vHome, tasks: vTasks, notes: vNotes, shop: vShop, habits: vHabits, timer: vTimer, money: vMoney, goals: vGoals, stats: vStats, settings: vSettings };
let current = 'home';

/* ================= نمایش ================= */
let popId = null;
function render() {
  view.classList.toggle('home', current === 'home');
  const f = V[current] || vHome;
  try { view.innerHTML = f(); }
  catch (err) { view.innerHTML = '<div class="card">⚠️ ' + esc(err.message) + '</div>'; }
  if (current === 'home') {
    paintSky();
    layoutClouds();
    requestAnimationFrame(() => { const b = $('clouds'); if (b) b.classList.add('ready'); });
  }
  if (popId) {
    const el = view.querySelector('.chk[data-id="' + popId + '"]');
    if (el) el.classList.add('pop');
    popId = null;
  }
}
function keepInputs() {
  const o = {};
  view.querySelectorAll('input[id],textarea[id],select[id]').forEach(e => { o[e.id] = e.value; });
  return o;
}
function restoreInputs(o) { Object.keys(o).forEach(k => { const e = $(k); if (e) e.value = o[k]; }); }
function refresh(keep) {
  const st = view.scrollTop;
  const k = keep === false ? null : keepInputs();
  render();
  if (k) restoreInputs(k);
  if (current === 'notes') filterNotes();
  view.scrollTop = st;
}
function markActive() { items.forEach((b, i) => b.classList.toggle('act', SECTIONS[i].id === current)); }
let enterT;
function openSection(id, fromPop) {
  if (!V[id]) id = 'home';
  if (!fromPop && id !== current) { try { history.pushState({ s: id }, ''); } catch (e) {} }
  current = id;
  $('title').textContent = titleOf(id);
  $('homeBtn').classList.toggle('hide', id === 'home');
  $('setBtn').classList.toggle('hide', id === 'settings');
  markActive();
  view.classList.remove('enter');
  render();
  view.scrollTop = 0;
  void view.offsetWidth;
  view.classList.add('enter');
  clearTimeout(enterT);
  enterT = setTimeout(() => view.classList.remove('enter'), 1100);
}

/* ================= پنجره‌های پایین (شیت) ================= */
const ov = $('ov'), sheet = $('sheet');
const stack = [];
let shHist = false, ignorePop = 0;

function paintSheet(keep) {
  if (!stack.length) {
    ov.classList.remove('show');
    setTimeout(() => {
      if (!stack.length && shHist) { shHist = false; ignorePop++; try { history.back(); } catch (e) { ignorePop--; } }
    }, 60);
    setTimeout(() => { if (!stack.length) sheet.innerHTML = ''; }, 520);
    return;
  }
  if (!shHist) { shHist = true; try { history.pushState({ s: current, sh: 1 }, ''); } catch (e) { shHist = false; } }
  const top = stack[stack.length - 1];
  const st = keep ? sheet.scrollTop : 0;
  sheet.innerHTML = top.render();
  sheet.scrollTop = st;
  ov.classList.add('show');
  if (top.mount) top.mount();
}
function pushSheet(d) { stack.push(d); paintSheet(false); }
function popSheet() { stack.pop(); paintSheet(false); }
function swapSheet(d) { stack[stack.length - 1] = d; paintSheet(false); }
function repaint() { paintSheet(true); }

ov.addEventListener('click', e => {
  if (e.target === ov) { popSheet(); return; }
  const el = e.target.closest('[data-sa]');
  if (!el) return;
  const top = stack[stack.length - 1];
  if (top && top.act) top.act(el.dataset.sa, el);
});
ov.addEventListener('input', e => {
  const top = stack[stack.length - 1];
  if (top && top.input) top.input(e);
});
ov.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.dataset && e.target.dataset.senter) {
    e.preventDefault();
    const top = stack[stack.length - 1];
    if (top && top.act) top.act(e.target.dataset.senter, e.target);
  }
});

function optionsSheet(title, opts, cb) {
  return {
    render() {
      return '<div class="grab"></div><div class="sh-t">' + title + '</div><div class="opts">' +
        opts.map((o, i) => '<button class="btn ghost" type="button" data-sa="opt" data-i="' + i + '">' + esc(o[1]) + '</button>').join('') + '</div>';
    },
    act(a, el) { if (a === 'opt') { cb(opts[Number(el.dataset.i)][0]); popSheet(); } }
  };
}
function confirmSheet(o) {
  return {
    render() {
      return '<div class="grab"></div><div class="sh-t">' + o.title + '</div><div class="warn">' + o.msg + '</div>' +
        '<div class="row sh-b"><button class="btn ' + (o.danger ? 'danger' : '') + '" type="button" data-sa="ok">' + o.ok + '</button>' +
        '<button class="btn ghost" type="button" data-sa="no">' + t('cancel') + '</button></div>';
    },
    act(a) { if (a === 'ok') { popSheet(); o.cb(); } else if (a === 'no') popSheet(); }
  };
}

function pickerSheet(o) {
  const time = o.time !== false;
  const base = new Date(o.ts ? o.ts : (time ? Math.ceil((Date.now() + 3600000) / 300000) * 300000 : Date.now()));
  const st = { day: dayKey(base), h: base.getHours(), m: base.getMinutes() };
  const presets = [
    ['pre30', () => Date.now() + 30 * 60000],
    ['pre60', () => Date.now() + 60 * 60000],
    ['pre120', () => Date.now() + 120 * 60000],
    ['preTonight', () => { const d = new Date(); d.setHours(21, 0, 0, 0); if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1); return d.getTime(); }],
    ['preTom', () => { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d.getTime(); }]
  ];
  function days() {
    const a = [];
    for (let i = 0; i < 120; i++) { const d = new Date(); d.setDate(d.getDate() + i); a.push({ k: dayKey(d), d: d, i: i }); }
    if (!a.some(x => x.k === st.day)) {
      const p = st.day.split('-').map(Number);
      a.unshift({ k: st.day, d: new Date(p[0], p[1] - 1, p[2]), i: -1 });
    }
    return a;
  }
  function cur() { return mkTime(st.day, time ? pad(st.h) + ':' + pad(st.m) : '23:59'); }
  function ui() {
    sheet.querySelectorAll('[data-sa="pk-day"]').forEach(b => b.classList.toggle('on', b.dataset.v === st.day));
    sheet.querySelectorAll('[data-sa="pk-h"]').forEach(b => b.classList.toggle('on', Number(b.dataset.v) === st.h));
    sheet.querySelectorAll('[data-sa="pk-m"]').forEach(b => b.classList.toggle('on', Number(b.dataset.v) === st.m));
    const p = sheet.querySelector('#pk-prev');
    if (p) { const ts = cur(); p.textContent = ts ? (time ? fmtDue(ts) : fmtDay(ts)) : ''; }
    const mv = sheet.querySelector('#pk-mv');
    if (mv) mv.textContent = fp(st.m);
    ['pk-day', 'pk-h', 'pk-m'].forEach(n => {
      const el = sheet.querySelector('[data-sa="' + n + '"].on');
      if (el && el.scrollIntoView) { try { el.scrollIntoView({ inline: 'center', block: 'nearest' }); } catch (e) {} }
    });
  }
  function setTs(ts) { const d = new Date(ts); st.day = dayKey(d); st.h = d.getHours(); st.m = d.getMinutes(); }
  return {
    render() {
      let h = '<div class="grab"></div><div class="sh-t">' + t(time ? 'pkTitleDT' : 'pkTitleD') + '</div>';
      h += '<div class="strip">' + days().map(x => {
        const tp = x.i === 0 ? t('today') : x.i === 1 ? t('tomorrow') : wd(x.d);
        let bt;
        try { bt = x.d.toLocaleDateString(NL(), { day: 'numeric', month: 'short' }); } catch (e) { bt = x.k.slice(5); }
        return '<button class="pk" type="button" data-sa="pk-day" data-v="' + x.k + '"><small>' + esc(tp) + '</small>' + esc(bt) + '</button>';
      }).join('') + '</div>';
      if (time) {
        h += '<div class="lbl">' + t('hourL') + '</div><div class="strip">';
        for (let i = 0; i < 24; i++) h += '<button class="pk sm" type="button" data-sa="pk-h" data-v="' + i + '">' + fp(i) + '</button>';
        h += '</div><div class="lbl">' + t('minL') + '</div><div class="strip"><button class="pk sm" type="button" data-sa="pk-mi" data-v="-1">−1</button>';
        for (let i = 0; i < 60; i += 5) h += '<button class="pk sm" type="button" data-sa="pk-m" data-v="' + i + '">' + fp(i) + '</button>';
        h += '<button class="pk sm" type="button" data-sa="pk-mi" data-v="1">+1</button><span class="pkv" id="pk-mv"></span></div>';
        h += '<div class="chips">' + presets.map((p, i) => '<button class="chip" type="button" data-sa="pk-pre" data-i="' + i + '">' + t(p[0]) + '</button>').join('') + '</div>';
      }
      h += '<div class="pk-prev" id="pk-prev"></div>';
      h += '<div class="row sh-b"><button class="btn" type="button" data-sa="ok">' + t('confirm') + '</button>' +
        '<button class="btn ghost" type="button" data-sa="clr">' + t('noTime') + '</button>' +
        '<button class="btn ghost" type="button" data-sa="cancel">' + t('cancel') + '</button></div>';
      return h;
    },
    mount() { ui(); },
    act(a, el) {
      switch (a) {
        case 'pk-day': st.day = el.dataset.v; ui(); break;
        case 'pk-h': st.h = Number(el.dataset.v); ui(); break;
        case 'pk-m': st.m = Number(el.dataset.v); ui(); break;
        case 'pk-mi': st.m = (st.m + Number(el.dataset.v) + 60) % 60; ui(); break;
        case 'pk-pre': setTs(presets[Number(el.dataset.i)][1]()); ui(); break;
        case 'ok': { const ts = cur(); if (ts === null) { toast(t('badTime')); return; } o.cb(ts); popSheet(); break; }
        case 'clr': o.cb(null); popSheet(); break;
        case 'cancel': popSheet(); break;
      }
    }
  };
}

function fieldHtml(f, d) {
  const k = f.key, v = d[k];
  switch (f.kind) {
    case 'text':
      return '<label class="lbl">' + f.label + '<input class="inp" type="text" data-f="' + k + '" value="' + esc(v) + '" maxlength="' + (f.max || 120) + '" placeholder="' + esc(f.ph || '') + '" autocomplete="off"></label>';
    case 'area':
      return '<label class="lbl">' + f.label + '<textarea class="inp" rows="6" data-f="' + k + '" placeholder="' + esc(f.ph || '') + '">' + esc(v) + '</textarea></label>';
    case 'num':
      return '<label class="lbl">' + f.label + '<input class="inp" type="text" inputmode="decimal" data-f="' + k + '" value="' + esc(v) + '" placeholder="' + esc(f.ph || '') + '" autocomplete="off"></label>';
    case 'chips':
      return '<div class="lbl">' + f.label + '</div><div class="chips">' + f.opts.map((o, i) =>
        '<button class="chip' + (String(v) === String(o[0]) ? ' on' : '') + '" type="button" data-sa="chip" data-k="' + k + '" data-i="' + i + '">' + esc(o[1]) + '</button>').join('') + '</div>';
    case 'toggle':
      return '<div class="chips"><button class="chip' + (v ? ' on' : '') + '" type="button" data-sa="tog" data-k="' + k + '">' + f.label + ': ' + t(v ? 'yes' : 'no') + '</button></div>';
    case 'due':
      return '<div class="lbl">' + f.label + '</div><div class="chips"><button class="chip on" type="button" data-sa="due" data-k="' + k + '">' +
        (v ? (f.time === false ? fmtDay(v) : fmtDue(v)) : f.empty) + '</button>' +
        (v ? '<button class="chip" type="button" data-sa="due-clear" data-k="' + k + '">' + t('clearBtn') + '</button>' : '') + '</div>';
    case 'subs':
      return '<div class="lbl">' + f.label + '</div>' + (v || []).map(s =>
        '<div class="sub-row"><span>' + esc(s.t) + '</span><button class="mini" type="button" data-sa="sub-del" data-k="' + k + '" data-sid="' + esc(s.id) + '">✕</button></div>').join('') +
        '<div class="row gap"><input id="sn-' + k + '" class="inp" type="text" maxlength="80" placeholder="' + esc(t('subPh')) + '" data-senter="sub-add" data-k="' + k + '" autocomplete="off">' +
        '<button class="btn sm" type="button" data-sa="sub-add" data-k="' + k + '">➕</button></div>';
    case 'when': {
      const opts = [['', t('noTime')], ['week', t('thisWeek')], ['month', t('oneMonth')], ['funded', t('whenFunded')], ['date', t('pickDate')]];
      const wl = whenLabel(d);
      return '<div class="lbl">' + t('fWhen') + '</div><div class="chips">' + opts.map(o =>
        '<button class="chip' + (d.when === o[0] ? ' on' : '') + '" type="button" data-sa="when" data-v="' + o[0] + '">' + o[1] + '</button>').join('') + '</div>' +
        (wl ? '<div class="sub gap">' + t('whenSel', esc(wl)) + '</div>' : '');
    }
    case 'info':
      return '<div class="sub gap">' + f.html + '</div>';
  }
  return '';
}

function formSheet(o) {
  const d = o.draft;
  const bs = o.buttons || [{ label: t('saveBtn'), fn: o.onSave }, { label: t('cancel'), cls: 'ghost', fn: null }];
  function flush() {
    o.fields.forEach(f => {
      if (f.kind === 'subs') {
        const i = $('sn-' + f.key);
        if (i && i.value.trim()) { d[f.key].push({ id: uid(), t: i.value.trim(), d: false }); i.value = ''; }
      }
    });
  }
  return {
    render() {
      let h = '<div class="grab"></div><div class="sh-t">' + o.title + '</div>';
      o.fields.forEach(f => { if (f.show && !f.show(d)) return; h += fieldHtml(f, d); });
      h += '<div class="row sh-b">' + bs.map((b, i) =>
        '<button class="btn ' + (b.cls || '') + '" type="button" data-sa="btn" data-i="' + i + '">' + b.label + '</button>').join('') + '</div>';
      return h;
    },
    input(e) { const f = e.target.dataset.f; if (f) d[f] = e.target.value; },
    act(a, el) {
      const k = el.dataset.k;
      const fd = o.fields.find(x => x.key === k);
      switch (a) {
        case 'btn': {
          const b = bs[Number(el.dataset.i)];
          if (!b) return;
          flush();
          const r = b.fn ? b.fn(d) : undefined;
          if (r === false) return;
          popSheet();
          if (typeof r === 'function') r();
          break;
        }
        case 'chip': if (fd) { d[k] = fd.opts[Number(el.dataset.i)][0]; repaint(); } break;
        case 'tog': d[k] = !d[k]; repaint(); break;
        case 'due':
          if (fd) pushSheet(pickerSheet({ ts: d[k], time: fd.time !== false, cb: ts => { d[k] = ts; } }));
          break;
        case 'due-clear': d[k] = null; repaint(); break;
        case 'sub-add': {
          const inp = $('sn-' + k);
          const v = inp ? inp.value.trim() : '';
          if (v) d[k].push({ id: uid(), t: v, d: false });
          repaint();
          const i2 = $('sn-' + k);
          if (i2) i2.focus();
          break;
        }
        case 'sub-del': d[k] = d[k].filter(x => x.id !== el.dataset.sid); repaint(); break;
        case 'when': {
          const v = el.dataset.v;
          if (v === '') { d.when = ''; d.wd = 0; repaint(); }
          else if (v === 'week') { d.when = 'week'; d.wd = endOfWeek(); repaint(); }
          else if (v === 'funded') { d.when = 'funded'; d.wd = 0; repaint(); }
          else if (v === 'month') {
            const mo = monthOptions();
            pushSheet(optionsSheet(t('whichMonth'), mo.map((m, i) => [i, m.label]), i => { d.when = 'month'; d.wd = mo[i].end; }));
          } else if (v === 'date') {
            pushSheet(pickerSheet({ ts: d.wd || null, time: false, cb: ts => { if (ts) { d.when = 'date'; d.wd = ts; } } }));
          }
          break;
        }
      }
    }
  };
}

/* ---------- فرم‌های افزودن و ویرایش ---------- */
function findItem(kind, id) {
  if (kind === 'slot') { const i = Number(id); return S.slots[i] ? { id: i, min: S.slots[i] } : null; }
  return (S[kind] || []).find(x => x.id === id) || null;
}
function askCloud(kind, id) {
  pushSheet({
    render() {
      return '<div class="grab"></div><div class="sh-t">' + t('askCloudT') + '</div>' +
        '<div class="muted center" style="margin-top:0">' + t('askCloudMsg') + '</div>' +
        '<div class="row sh-b"><button class="btn" type="button" data-sa="y">' + t('cloudYes') + '</button>' +
        '<button class="btn ghost" type="button" data-sa="n">' + t('cloudNo') + '</button></div>';
    },
    act(a) {
      if (a === 'y') {
        const x = findItem(kind, id);
        if (x) { x.cloud = true; save(); refresh(true); }
        popSheet(); toast(t('cloudMade'));
      } else if (a === 'n') popSheet();
    }
  });
}
function taskForm(id) {
  const tk = id ? S.tasks.find(x => x.id === id) : null;
  if (id && !tk) return;
  const d = tk
    ? { title: tk.title, due: tk.due || null, pri: tk.pri == null ? 1 : tk.pri, rep: tk.rep || '', subs: JSON.parse(JSON.stringify(tk.subs)), cloud: !!tk.cloud }
    : { title: '', due: null, pri: 1, rep: '', subs: [], cloud: false };
  const fields = [
    { kind: 'text', key: 'title', label: t('fTitle') },
    { kind: 'due', key: 'due', label: t('fDue'), empty: t('dueEmpty') },
    { kind: 'chips', key: 'pri', label: t('fPri'), opts: [[0, PRI_ICON[0] + ' ' + t('pri0')], [1, PRI_ICON[1] + ' ' + t('pri1')], [2, PRI_ICON[2] + ' ' + t('pri2')]] },
    { kind: 'chips', key: 'rep', label: t('fRep'), opts: [['', t('repNone')], ['d', t('repD')], ['w', t('repW')]] },
    { kind: 'subs', key: 'subs', label: t('fSubs') }
  ];
  if (tk) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: tk ? t('editTask') : t('newTask'), draft: d, fields: fields,
    onSave(dd) {
      const title = dd.title.trim();
      if (!title) { toast(t('titleMissing')); return false; }
      let due = dd.due;
      if (dd.rep && !due) due = mkTime(dayKey(), '23:59');
      if (tk) {
        const od = tk.due;
        tk.title = title; tk.due = due; tk.pri = Number(dd.pri); tk.rep = dd.rep; tk.subs = dd.subs; tk.cloud = !!dd.cloud;
        if (od !== due) tk.notified = !!(due && due <= Date.now());
        taskSync(tk);
        save(); refresh(true); toast(t('saved'));
        return;
      }
      const nt = { id: uid(), title: title, due: due, done: false, notified: !!(due && due <= Date.now()), created: Date.now(), pri: Number(dd.pri), rep: dd.rep, subs: dd.subs, cloud: false };
      S.tasks.push(nt);
      save(); refresh(false);
      return () => askCloud('tasks', nt.id);
    }
  }));
}
function noteForm(id) {
  const n = id ? S.notes.find(x => x.id === id) : null;
  if (id && !n) return;
  const d = n ? { text: n.text, cloud: !!n.cloud } : { text: '', cloud: false };
  const fields = [{ kind: 'area', key: 'text', label: t('fNoteText') }];
  if (n) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: n ? t('editNote') : t('newNote'), draft: d, fields: fields,
    onSave(dd) {
      if (!dd.text.trim()) { toast(t('noteEmpty')); return false; }
      if (n) { n.text = dd.text; n.t = Date.now(); n.cloud = !!dd.cloud; save(); refresh(true); toast(t('saved')); return; }
      const nn = { id: uid(), text: dd.text, t: Date.now(), pin: false, cloud: false };
      S.notes.push(nn);
      save(); refresh(false);
      return () => askCloud('notes', nn.id);
    }
  }));
}
function shopForm(id) {
  const x = id ? S.shop.find(i => i.id === id) : null;
  if (id && !x) return;
  const d = x
    ? { text: x.text, price: x.price ? String(x.price) : '', saved: x.saved ? String(x.saved) : '', when: x.when || '', wd: x.wd || 0, cloud: !!x.cloud }
    : { text: '', price: '', saved: '', when: '', wd: 0, cloud: false };
  const fields = [
    { kind: 'text', key: 'text', label: t('fShopName'), max: 80 },
    { kind: 'num', key: 'price', label: t('fPrice') },
    { kind: 'num', key: 'saved', label: t('fSaved') },
    { kind: 'when', key: 'when' }
  ];
  if (x) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: x ? t('editItem') : t('newItem'), draft: d, fields: fields,
    onSave(dd) {
      const text = dd.text.trim();
      if (!text) { toast(t('needName')); return false; }
      const price = Math.max(0, Number(toEn(dd.price)) || 0), saved = Math.max(0, Number(toEn(dd.saved)) || 0);
      if (x) {
        if (x.when !== dd.when || x.wd !== dd.wd) x.wn = false;
        x.text = text; x.price = price; x.saved = saved; x.when = dd.when; x.wd = dd.wd; x.cloud = !!dd.cloud;
        checkFunded(x);
        save(); refresh(true); toast(t('saved'));
        return;
      }
      const nx = { id: uid(), text: text, price: price, saved: saved, when: dd.when, wd: dd.wd, done: false, cloud: false, created: Date.now(), fn: false, wn: false };
      checkFunded(nx);
      S.shop.push(nx);
      save(); refresh(false);
      return () => askCloud('shop', nx.id);
    }
  }));
}
function habitForm(id) {
  const h = id ? S.habits.find(x => x.id === id) : null;
  if (id && !h) return;
  const d = h ? { name: h.name, subs: JSON.parse(JSON.stringify(h.subs)) } : { name: '', subs: [] };
  pushSheet(formSheet({
    title: h ? t('editHabit') : t('newHabit'), draft: d,
    fields: [
      { kind: 'text', key: 'name', label: t('fHabitName'), max: 60 },
      { kind: 'subs', key: 'subs', label: t('fHabitSubs') }
    ],
    onSave(dd) {
      const name = dd.name.trim();
      if (!name) { toast(t('needHabit')); return false; }
      if (h) { h.name = name; h.subs = dd.subs; hSync(h, dayKey()); toast(t('saved')); }
      else S.habits.push({ id: uid(), name: name, days: [], subs: dd.subs, sd: {} });
      save(); refresh(!!h);
    }
  }));
}
function moneyForm(id) {
  const m = id ? S.money.find(x => x.id === id) : null;
  if (id && !m) return;
  const d = m
    ? { a: String(m.a), t: m.t || '', c: Number.isInteger(m.c) ? m.c : 5, ts: mkTime(m.d, '12:00') }
    : { a: '', t: '', c: 0, ts: null };
  pushSheet(formSheet({
    title: m ? t('editSpend') : t('newSpend'), draft: d,
    fields: [
      { kind: 'num', key: 'a', label: t('fAmount') },
      { kind: 'text', key: 't', label: t('fDesc'), max: 60 },
      { kind: 'chips', key: 'c', label: t('fCat'), opts: CAT_ICONS.map((ic, i) => [i, ic + ' ' + t('cat' + i)]) },
      { kind: 'due', key: 'ts', label: t('pickDate'), time: false, empty: t('today') }
    ],
    onSave(dd) {
      const a = Number(toEn(dd.a));
      if (!(a > 0)) { toast(t('badAmount')); return false; }
      const day = dd.ts ? dayKey(new Date(dd.ts)) : (m ? m.d : dayKey());
      const c = Number(dd.c), desc = dd.t.trim();
      if (m) {
        m.a = a; m.t = desc; m.c = c; m.d = day;
        const le = S.log.find(e => e.k === 'm' && e.ref === m.id);
        if (le) { le.a = a; le.n = desc; le.c = c; le.d = day; }
        else logAdd('m', day, desc, { a: a, c: c, ref: m.id });
        toast(t('saved'));
      } else {
        const nm = { id: uid(), a: a, t: desc, d: day, c: c };
        S.money.push(nm);
        logAdd('m', day, desc, { a: a, c: c, ref: nm.id });
        toast(t('spendSaved'));
      }
      save(); refresh(!!m);
    }
  }));
}
function goalForm(id) {
  const g = id ? S.goals.find(x => x.id === id) : null;
  if (id && !g) return;
  const d = g
    ? { title: g.title, icon: g.icon || '🎯', target: String(g.target), cur: String(g.cur), unit: g.unit, step: String(g.step), due: g.due || null, cloud: !!g.cloud }
    : { title: '', icon: '🎯', target: '', cur: '0', unit: '', step: '', due: null, cloud: false };
  const fields = [
    { kind: 'text', key: 'title', label: t('fGoalTitle'), max: 80 },
    { kind: 'chips', key: 'icon', label: t('fIcon'), opts: ICONS.map(i => [i, i]) },
    { kind: 'num', key: 'target', label: t('fTarget') },
    { kind: 'num', key: 'cur', label: t('fCur') },
    { kind: 'text', key: 'unit', label: t('fUnit'), max: 20 },
    { kind: 'num', key: 'step', label: t('fStep') },
    { kind: 'due', key: 'due', label: t('fDeadline'), time: false, empty: t('noDeadline') }
  ];
  if (g) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: g ? t('editGoal') : t('newGoal'), draft: d, fields: fields,
    onSave(dd) {
      const title = dd.title.trim();
      const target = Number(toEn(dd.target));
      if (!title) { toast(t('needGoal')); return false; }
      if (!(target > 0)) { toast(t('badTarget')); return false; }
      const cur = Math.max(0, Number(toEn(dd.cur)) || 0);
      const stp = Number(toEn(dd.step)) > 0 ? Number(toEn(dd.step)) : Math.max(1, Math.round(target / 10));
      if (g) {
        g.title = title; g.icon = dd.icon; g.target = target; g.cur = cur; g.unit = dd.unit.trim(); g.step = stp; g.due = dd.due || null; g.cloud = !!dd.cloud;
        save(); refresh(true); toast(t('saved'));
        return;
      }
      const ng = { id: uid(), title: title, icon: dd.icon, target: target, cur: cur, unit: dd.unit.trim(), step: stp, due: dd.due || null, created: Date.now(), cloud: false };
      S.goals.push(ng);
      save(); refresh(false);
      return () => askCloud('goals', ng.id);
    }
  }));
}
function slotForm(i) {
  const d = { min: S.slots[i] ? String(S.slots[i]) : '' };
  pushSheet(formSheet({
    title: S.slots[i] ? t('slotEdit') : t('slotAdd'), draft: d,
    fields: [{ kind: 'num', key: 'min', label: t('fSlotMin') }],
    onSave(dd) {
      const n = Math.round(Number(toEn(dd.min)));
      if (!(n >= 1 && n <= 600)) { toast(t('badMin')); return false; }
      S.slots[i] = n; save(); refresh(true); toast(t('saved'));
    }
  }));
}
function savingsSheet(id) {
  const x = S.shop.find(i => i.id === id);
  if (!x) return { render() { return '<div class="empty">' + t('notFound') + '</div>'; } };
  const d = { amt: '' };
  const apply = (sign, dd) => {
    const a = Number(toEn(dd.amt));
    if (!(a > 0)) { toast(t('badAmount')); return false; }
    x.saved = Math.max(0, x.saved + sign * a);
    checkFunded(x);
    save(); refresh(true);
  };
  return formSheet({
    title: t('savTitle', esc(x.text)), draft: d,
    fields: [
      { kind: 'info', html: t('savNow') + ': ' + nf(x.saved, true) + (x.price ? ' / ' + nf(x.price, true) : '') + ' ' + t('cur') },
      { kind: 'num', key: 'amt', label: t('fSavAmt') }
    ],
    buttons: [
      { label: t('savAdd'), fn: dd => apply(1, dd) },
      { label: t('savSub'), cls: 'ghost', fn: dd => apply(-1, dd) },
      { label: t('cancel'), cls: 'ghost', fn: null }
    ]
  });
}
function openQuick() {
  const d = { text: '', type: 't', due: null };
  pushSheet(formSheet({
    title: t('quickTitle'), draft: d,
    fields: [
      { kind: 'text', key: 'text', label: t('fQuickText'), ph: t('quickPh') },
      { kind: 'chips', key: 'type', label: t('fType'), opts: [['t', t('typeTask')], ['n', t('typeNote')]] },
      { kind: 'due', key: 'due', label: t('fQuickDue'), empty: t('dueEmpty'), show: dd => dd.type === 't' }
    ],
    buttons: [
      { label: t('sendCloud'), fn: dd => quickSend(dd, true) },
      { label: t('justSave'), cls: 'ghost', fn: dd => quickSend(dd, false) },
      { label: t('cancel'), cls: 'ghost', fn: null }
    ]
  }));
}
function quickSend(d, cloud) {
  const text = d.text.trim();
  if (!text) { toast(t('needText')); return false; }
  if (d.type === 'n') S.notes.push({ id: uid(), text: text, t: Date.now(), pin: false, cloud: cloud });
  else S.tasks.push({ id: uid(), title: text, due: d.due || null, done: false, notified: !!(d.due && d.due <= Date.now()), created: Date.now(), pri: 1, rep: '', subs: [], cloud: cloud });
  save(); refresh(false);
  return () => flyBird();
}
function openForm(kind, id) {
  if (kind === 'tasks') taskForm(id);
  else if (kind === 'notes') noteForm(id);
  else if (kind === 'shop') shopForm(id);
  else if (kind === 'habits') habitForm(id);
  else if (kind === 'money') moneyForm(id);
  else if (kind === 'goals') goalForm(id);
  else if (kind === 'slot') slotForm(Number(id));
}
function moreSheet() {
  return {
    render() {
      const l = cloudItems();
      return '<div class="grab"></div><div class="sh-t">☁️ ' + t('allClouds') + '</div>' + l.map(c =>
        '<button class="mrow" type="button" data-sa="mc" data-v="' + c.k + ':' + esc(c.id) + '"><span>' + c.ic + '</span><span class="grow">' + esc(c.tx) + '</span><small>' + esc(c.sub) + '</small></button>').join('') +
        '<div class="row sh-b"><button class="btn ghost" type="button" data-sa="close">' + t('closeB') + '</button></div>';
    },
    act(a, el) {
      if (a === 'close') popSheet();
      else if (a === 'mc') { const v = el.dataset.v; const i = v.indexOf(':'); swapSheet(itemSheet(v.slice(0, i), v.slice(i + 1))); }
    }
  };
}

/* ---------- شیت جزئیات و گزینه‌ها (نگه‌داشتن یا زدن روی مورد) ---------- */
function delItem(kind, id) {
  if (kind === 'slot') S.slots[Number(id)] = 0;
  else S[kind] = S[kind].filter(x => x.id !== id);
  save(); refresh(true); toast(t('deleted'));
}
function detail(kind, x) {
  const now = Date.now();
  const cl = CLOUDY.indexOf(kind) > -1 ? [['cloud', t(x.cloud ? 'removeCloud' : 'makeCloud')]] : [];
  const tail = [['edit', t('edit')], ['del', t('del'), 'danger'], ['close', t('closeB')]];
  let ti = '', body = '', btns = [];
  switch (kind) {
    case 'tasks':
      ti = '✅ ' + esc(x.title);
      body = '<div class="sub gap">' + (x.due ? fmtDue(x.due) + (x.done ? '' : ' · ' + remText(x.due - now)) : t('noSchedule')) +
        ' · ' + t('priLabel', t('pri' + (x.pri == null ? 1 : x.pri))) + (x.rep ? ' · 🔁' : '') + '</div>';
      if (x.subs.length) body += '<div class="bar"><i style="width:' + subPct(x) + '%"></i></div>' + subsHtml(x.subs, 'data-sa="subtick"', s => s.d);
      btns = [['done', t(x.done ? 'undo' : 'markDone')]].concat(cl, tail);
      break;
    case 'notes':
      ti = '📝 ' + t('sec_notes');
      body = '<div class="reader">' + esc(x.text) + '</div><div class="sub gap">' + fmtDue(x.t || now) + '</div>';
      btns = [['copy', t('copyText')], ['pin', t(x.pin ? 'unpin' : 'pin')]].concat(cl, tail);
      break;
    case 'shop': {
      const pc = x.price > 0 ? Math.min(100, Math.round(x.saved / x.price * 100)) : 0;
      const wl = whenLabel(x);
      ti = '🛒 ' + esc(x.text);
      body = '<div class="sub gap">' + (x.price ? nf(x.price, true) + ' ' + t('cur') : t('noPrice')) + (wl ? ' · ⏳ ' + esc(wl) : '') + '</div>';
      if (x.price > 0) body += '<div class="bar' + (pc >= 100 ? ' ok' : '') + '"><i style="width:' + pc + '%"></i></div><div class="sub gap">' + t('of', nf(x.saved, true), nf(x.price, true)) + ' (' + nf(pc) + '%)</div>';
      btns = [['sav', t('savingsBtn')], ['tick', t(x.done ? 'unpick' : 'pick')]].concat(cl, tail);
      break;
    }
    case 'habits':
      ti = '🔥 ' + esc(x.name);
      body = '<div class="sub gap">' + t('streakDays', nf(habStreak(x))) + ' · ' + t('subCount', nf(x.subs.length)) + '</div>';
      btns = tail;
      break;
    case 'money': {
      const ci = Number.isInteger(x.c) ? x.c : 5;
      ti = '💰 ' + nf(x.a, true) + ' ' + t('cur');
      body = '<div class="sub gap">' + CAT_ICONS[ci] + ' ' + t('cat' + ci) + (x.t ? ' · ' + esc(x.t) : '') + ' · ' + dayLabel(x.d) + '</div>';
      btns = tail;
      break;
    }
    case 'goals': {
      const p = Math.round(pctGoal(x));
      ti = esc(x.icon || '🎯') + ' ' + esc(x.title);
      body = '<div class="bar"><i style="width:' + p + '%"></i></div><div class="sub gap">' + t('of', nd(x.cur), nd(x.target)) + ' ' + esc(x.unit) + ' (' + nf(p) + '%)' + (goalStatus(x) ? '<br>' + goalStatus(x) : '') + '</div>';
      btns = [['inc', '＋ ' + nd(x.step)], ['dec', '－ ' + nd(x.step)]].concat(cl, tail);
      break;
    }
    case 'slot':
      ti = t('customTimer');
      body = '<div class="sub gap">' + nf(x.min) + ' ' + t('minU') + '</div>';
      btns = [['use', t('useTimer')]].concat(tail);
      break;
  }
  return { ti: ti, body: body, btns: btns };
}
function itemSheet(kind, id) {
  return {
    render() {
      const x = findItem(kind, id);
      if (!x) return '<div class="grab"></div><div class="empty">' + t('notFound') + '</div>';
      const dt = detail(kind, x);
      return '<div class="grab"></div><div class="sh-t">' + dt.ti + '</div>' + dt.body +
        '<div class="opts">' + dt.btns.map((b, i) =>
          '<button class="btn ' + (b[2] || (i === 0 ? '' : 'ghost')) + '" type="button" data-sa="' + b[0] + '">' + b[1] + '</button>').join('') + '</div>';
    },
    act(a, el) {
      const x = findItem(kind, id);
      if (!x) { popSheet(); return; }
      switch (a) {
        case 'close': popSheet(); return;
        case 'edit': popSheet(); openForm(kind, id); return;
        case 'del': delItem(kind, id); popSheet(); return;
        case 'cloud': x.cloud = !x.cloud; save(); refresh(true); repaint(); return;
        case 'done': toggleTask(x); save(); refresh(true); repaint(); return;
        case 'subtick': {
          const s = x.subs.find(i => i.id === el.dataset.sid);
          if (s) { s.d = !s.d; taskSync(x); save(); refresh(true); repaint(); }
          return;
        }
        case 'copy': toast(copyText(x.text) ? t('copied') : t('copyFail')); return;
        case 'pin': x.pin = !x.pin; save(); refresh(true); repaint(); return;
        case 'tick': x.done = !x.done; save(); refresh(true); repaint(); return;
        case 'sav': pushSheet(savingsSheet(id)); return;
        case 'inc': goalStep(x, 1); refresh(true); repaint(); return;
        case 'dec': goalStep(x, -1); refresh(true); repaint(); return;
        case 'use': popSheet(); setTimerMin(x.min); return;
      }
    }
  };
}

/* ================= عملیات‌ها ================= */
function act(a, id, el) {
  switch (a) {
    case 'add': openForm(id, null); break;
    case 'quick': openQuick(); break;
    case 'more-clouds': pushSheet(moreSheet()); break;
    case 'stat-open': pushSheet(statSheet(id)); break;

    /* کارها */
    case 'tfilter': tFilter = id; refresh(true); break;
    case 't-toggle': {
      popId = id;
      const run = () => { const tk = S.tasks.find(x => x.id === id); if (tk) { toggleTask(tk); save(); refresh(true); } };
      const cw = el.closest ? el.closest('.cw') : null;
      if (cw) { cw.classList.add('poof'); setTimeout(run, 330); } else run();
      break;
    }
    case 't-sub': {
      const tk = S.tasks.find(x => x.id === id);
      if (tk) {
        const s = tk.subs.find(i => i.id === el.dataset.sid);
        if (s) { s.d = !s.d; taskSync(tk); save(); refresh(true); }
      }
      break;
    }
    case 't-clear': S.tasks = S.tasks.filter(x => !x.done); save(); refresh(true); break;

    /* یادداشت */
    case 'n-open': { const it = el.closest('.item'); if (it) it.classList.toggle('open'); break; }

    /* خرید */
    case 's-toggle': { const x = S.shop.find(i => i.id === id); if (x) { popId = id; x.done = !x.done; save(); refresh(true); } break; }
    case 's-sav': if (S.shop.some(i => i.id === id)) pushSheet(savingsSheet(id)); break;
    case 's-copy': {
      const l = S.shop.filter(x => x.done).map(x => '• ' + x.text + (x.price ? ' — ' + nf(x.price, true) + ' ' + t('cur') : ''));
      if (!l.length) { toast(t('nothingSel')); return; }
      toast(copyText(l.join('\n')) ? t('copied') : t('copyFail'));
      break;
    }
    case 's-clear': S.shop = S.shop.filter(x => !x.done); save(); refresh(true); break;

    /* عادت‌ها */
    case 'h-toggle': {
      const h = S.habits.find(i => i.id === id);
      if (h) {
        popId = id;
        const k = dayKey();
        if (h.subs.length) {
          const full = hSubDone(h, k) === h.subs.length;
          h.sd[k] = full ? [] : h.subs.map(s => s.id);
          hSync(h, k);
        } else habSetDay(h, k, h.days.indexOf(k) < 0);
        if (h.days.length > 800) h.days = h.days.slice(-800);
        save();
        if (current === 'home') { const w = $('hbw'); if (w) w.innerHTML = habitsInner(); }
        else refresh(true);
      }
      break;
    }
    case 'h-sub': {
      const h = S.habits.find(i => i.id === id);
      if (h) {
        const k = dayKey();
        const ids = h.sd[k] || (h.sd[k] = []);
        const sid = el.dataset.sid;
        const p = ids.indexOf(sid);
        if (p > -1) ids.splice(p, 1); else ids.push(sid);
        hSync(h, k);
        const keys = Object.keys(h.sd).sort();
        while (keys.length > 60) delete h.sd[keys.shift()];
        save(); refresh(true);
      }
      break;
    }

    /* تایمر */
    case 'tm-set': setTimerMin(Number(el.dataset.min)); break;
    case 'tm-toggle':
      audio();
      if (T.run) { T.left = tmLeft(); T.run = false; }
      else { if (T.left <= 0) T.left = T.total; T.end = Date.now() + T.left * 1000; T.run = true; }
      refresh(true);
      break;
    case 'tm-reset': T.run = false; T.left = T.total; refresh(false); break;
    case 'slot': {
      const i = Number(id);
      if (S.slots[i]) setTimerMin(S.slots[i]); else slotForm(i);
      break;
    }

    /* هدف‌ها */
    case 'g-inc': case 'g-dec': {
      const g = S.goals.find(x => x.id === id);
      if (g) { goalStep(g, a === 'g-inc' ? 1 : -1); refresh(true); }
      break;
    }

    /* تنظیمات */
    case 'lang':
      S.set.lang = id === 'en' ? 'en' : 'fa';
      save(); applyLang(); refresh(false);
      break;
    case 'theme-set': S.set.theme = id; save(); applyTheme(); refresh(true); break;
    case 'accent': S.set.accent = Number(id); save(); applyTheme(); refresh(true); break;
    case 'tog':
      if (id === 'sound') { S.set.sound = !S.set.sound; if (S.set.sound) beep(); }
      else { S.set.vib = !S.set.vib; buzz(40); }
      save(); refresh(true);
      break;
    case 'budget-save': {
      const n = Number(toEn(val('set-budget'))) || 0;
      S.set.budget = n > 0 ? n : 0;
      save(); toast(t('budgetSaved'));
      break;
    }
    case 'bk-make': {
      const e = $('bk');
      e.value = JSON.stringify(S);
      const ok = copyText(e.value);
      e.focus(); e.select();
      toast(t(ok ? 'bkOk' : 'bkManual'));
      break;
    }
    case 'bk-load': {
      try {
        const o = JSON.parse(val('bk'));
        if (!o || typeof o !== 'object') throw new Error('bad');
        S = norm(o); save(); applyTheme(); applyLang(); refresh(false); toast(t('bkLoaded'));
      } catch (x) { toast(t('bkBad')); }
      break;
    }
    case 'reset':
      pushSheet(confirmSheet({
        title: t('resetTitle'), msg: t('resetMsg'), ok: t('resetYes'), danger: true,
        cb() {
          S = def(); save(); applyTheme(); applyLang(); refresh(false); toast(t('resetDone'));
        }
      }));
      break;
  }
}

/* ---------- رویدادهای صفحه ---------- */
let lp = null, lpFired = false;
function lpCancel() { if (lp) { clearTimeout(lp.t); lp = null; } }
view.addEventListener('pointerdown', e => {
  const el = e.target.closest('[data-lp]');
  if (!el || e.target.closest('input,textarea,select')) return;
  lpCancel();
  lp = {
    x: e.clientX, y: e.clientY,
    t: setTimeout(() => {
      const v = el.getAttribute('data-lp');
      lp = null; lpFired = true;
      setTimeout(() => { lpFired = false; }, 800);
      buzz(25);
      const i = v.indexOf(':');
      pushSheet(itemSheet(v.slice(0, i), v.slice(i + 1)));
    }, 520)
  };
});
view.addEventListener('pointermove', e => {
  if (lp && (Math.abs(e.clientX - lp.x) > 10 || Math.abs(e.clientY - lp.y) > 10)) lpCancel();
});
['pointerup', 'pointercancel', 'pointerleave'].forEach(n => view.addEventListener(n, lpCancel));
view.addEventListener('contextmenu', e => e.preventDefault());

view.addEventListener('click', e => {
  if (lpFired) { lpFired = false; return; }
  const el = e.target.closest('[data-act]');
  if (el) { act(el.dataset.act, el.dataset.id, el); return; }
  const g = e.target.closest('[data-go]');
  if (g) { pick(Number(g.dataset.go)); return; }
  const o = e.target.closest('[data-open]');
  if (o) {
    const v = o.getAttribute('data-open');
    const i = v.indexOf(':');
    pushSheet(itemSheet(v.slice(0, i), v.slice(i + 1)));
  }
});
view.addEventListener('input', e => { if (e.target.id === 'n-q') filterNotes(); });
$('homeBtn').addEventListener('click', () => openSection('home'));
$('setBtn').addEventListener('click', () => openSection('settings'));

/* ================= چرخ ================= */
const items = [];
SECTIONS.forEach((s, i) => {
  const slot = document.createElement('div');
  slot.className = 'slot';
  slot.style.setProperty('--i', i);
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'it';
  b.setAttribute('data-i', i);
  b.innerHTML = '<span class="ii"><span class="ic">' + s.icon + '</span><span class="lb"></span></span>';
  slot.appendChild(b);
  ring.appendChild(slot);
  items.push(b);
});

let rot = 0, raf = 0;
function setRot(r) {
  rot = r;
  ring.style.transform = 'rotate(' + r + 'deg)';
  for (let i = 0; i < N; i++) items[i].style.transform = 'rotate(' + (-(i * STEP + r)) + 'deg)';
}
function idxOf(tg) { return (((Math.round(-tg / STEP)) % N) + N) % N; }
function targetFor(i) {
  const k = Math.round((rot + i * STEP) / 360);
  return -i * STEP + 360 * k;
}
function stopAnim() { if (raf) { cancelAnimationFrame(raf); raf = 0; } }
function animateTo(target, dur) {
  stopAnim();
  const from = rot, delta = target - from;
  if (Math.abs(delta) < 0.01) { setRot(target); return; }
  const t0 = performance.now();
  function step(now) {
    const p = (now - t0) / dur;
    if (p >= 1) { setRot(target); raf = 0; return; }
    setRot(from + delta * (1 - Math.pow(1 - p, 3)));
    raf = requestAnimationFrame(step);
  }
  raf = requestAnimationFrame(step);
}
function pick(i) {
  animateTo(targetFor(i), 560);
  buzz(8);
  openSection(SECTIONS[i].id);
}

let drag = null, justDragged = false;
function ang(e, c) { return Math.atan2(e.clientY - c.y, e.clientX - c.x) * 180 / Math.PI; }

wheel.addEventListener('pointerdown', e => {
  if (drag || document.body.classList.contains('wheel-closed')) return;
  stopAnim();
  const r = wheel.getBoundingClientRect();
  const c = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  drag = { id: e.pointerId, c: c, last: ang(e, c), acc: 0, r0: rot, moved: false, s: [{ t: performance.now(), r: rot }] };
});
window.addEventListener('pointermove', e => {
  if (!drag || e.pointerId !== drag.id) return;
  const a = ang(e, drag.c);
  let d = a - drag.last;
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  drag.last = a;
  drag.acc += d;
  if (Math.abs(drag.acc) > 6) drag.moved = true;
  if (drag.moved) {
    setRot(drag.r0 + drag.acc);
    drag.s.push({ t: performance.now(), r: rot });
    if (drag.s.length > 6) drag.s.shift();
  }
  e.preventDefault();
}, { passive: false });
function endDrag(e) {
  if (!drag || (e && e.pointerId !== drag.id)) return;
  const dg = drag;
  drag = null;
  if (!dg.moved) return;
  justDragged = true;
  setTimeout(() => { justDragged = false; }, 350);
  const now = performance.now();
  let v = 0;
  for (let i = 0; i < dg.s.length; i++) {
    const dt = now - dg.s[i].t;
    if (dt <= 120) { v = (rot - dg.s[i].r) / Math.max(16, dt); break; }
  }
  v = Math.max(-1.2, Math.min(1.2, v));
  let target = rot + v * 160;
  target = Math.max(rot - 3 * STEP, Math.min(rot + 3 * STEP, target));
  target = Math.round(target / STEP) * STEP;
  animateTo(target, Math.min(900, 400 + Math.abs(target - rot) * 2.4));
  buzz(8);
  openSection(SECTIONS[idxOf(target)].id);
}
window.addEventListener('pointerup', endDrag);
window.addEventListener('pointercancel', endDrag);
wheel.addEventListener('contextmenu', e => e.preventDefault());

ring.addEventListener('click', e => {
  if (justDragged || document.body.classList.contains('wheel-closed')) return;
  const b = e.target.closest('.it');
  if (!b) return;
  pick(Number(b.getAttribute('data-i')));
});

function setWheel(open, persist) {
  document.body.classList.toggle('wheel-closed', !open);
  document.body.classList.toggle('wheel-open', open);
  if (persist) { S.set.wheel = open; save(); }
  if (current === 'home') layoutClouds();
}
$('hub').addEventListener('click', () => {
  setWheel(document.body.classList.contains('wheel-closed'), true);
});
window.addEventListener('resize', () => { if (current === 'home') layoutClouds(); });

window.addEventListener('popstate', e => {
  if (ignorePop > 0) { ignorePop--; return; }
  if (stack.length) { shHist = false; stack.length = 0; paintSheet(false); return; }
  const id = (e.state && e.state.s) || 'home';
  const i = SECTIONS.findIndex(s => s.id === id);
  if (i > -1) animateTo(targetFor(i), 560);
  openSection(id, true);
});

/* ================= یادآور و حلقهٔ زمان ================= */
function checkReminders() {
  const now = Date.now();
  let changed = false;
  const due = S.tasks.filter(x => !x.done && x.due && !x.notified && x.due <= now);
  if (due.length) {
    due.forEach(x => { x.notified = true; });
    changed = true;
    toast(due.length === 1 ? t('dueOne', due[0].title) : t('dueMany', nf(due.length)));
    alarm();
  }
  const sh = S.shop.filter(x => {
    if (x.done || x.wn || !(x.wd > 0) || ['week', 'month', 'date'].indexOf(x.when) < 0) return false;
    const r = new Date(x.wd); r.setHours(9, 0, 0, 0);
    return r.getTime() <= now;
  });
  if (sh.length) {
    sh.forEach(x => { x.wn = true; });
    changed = true;
    toast(t('buyTime', sh[0].text) + (sh.length > 1 ? t('andMore', nf(sh.length - 1)) : ''));
    alarm();
  }
  if (changed) {
    save();
    if (current === 'tasks' || current === 'home' || current === 'shop') refresh(true);
  }
}
let slowAt = Date.now();
setInterval(() => {
  const c = $('clock');
  if (c) { const tx = hm(Date.now()); if (c.textContent !== tx) c.textContent = tx; }
  tickTimer();
  const now = Date.now();
  if (now - slowAt >= 15000) {
    slowAt = now;
    checkReminders();
    if (S.set.theme === 'auto') applyTheme();
    if (current === 'home') { paintSky(); tickClouds(); }
  }
}, 500);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    checkReminders();
    tickTimer();
    if (S.set.theme === 'auto') applyTheme();
    if (current === 'home') { paintSky(); tickClouds(); layoutClouds(); }
  }
});

/* ================= متن‌ها ================= */
const D = {
fa: {
  appTitle: 'برنامه روزانه', home: 'صفحه اصلی', settings: 'تنظیمات', menu: 'منو',
  sec_tasks: 'کارها', sec_notes: 'یادداشت', sec_shop: 'خرید', sec_habits: 'عادت‌ها',
  sec_timer: 'تایمر', sec_money: 'هزینه', sec_goals: 'هدف‌ها', sec_stats: 'آمار',
  today: 'امروز', tomorrow: 'فردا', u_day: 'روز', u_hour: 'ساعت', u_min: 'دقیقه', and: ' و ',
  left: 'مانده', overdue: 'گذشته', now: 'همین الان', cur: 'تومان',
  skyEmpty: 'آسمان خالی است ☀️', skyEmptySub: 'با پرنده چیزی اضافه کن تا ابر بشود',
  moreClouds: '+{0} ابر دیگر', birdLabel: 'افزودن سریع', allClouds: 'همهٔ ابرها',
  newTask: '➕ کار جدید', tabOpen: 'باز', tabDone: 'انجام‌شده', noDone: 'هنوز کاری انجام نداده‌ای',
  noTasks: 'کاری اینجا نیست 🎉', noSchedule: 'بدون زمان‌بندی', clearDone: '🧹 پاک کردن انجام‌شده‌ها',
  newNote: '➕ یادداشت جدید', noNotes: 'هنوز یادداشتی نداری', searchNotes: '🔎 جستجو در یادداشت‌ها',
  newItem: '➕ مورد جدید', noShop: 'لیست خرید خالی است', shopTotal: 'جمع قیمت‌ها: {0} تومان · پس‌انداز: {1}',
  noPrice: 'بدون قیمت', funded: '✅ پولش جمع شد!', of: '{0} از {1}', savingsBtn: '💰 پس‌انداز',
  copySel: '📋 کپی انتخاب‌شده‌ها', clearSel: '🧹 پاک کردن انتخاب‌شده‌ها', nothingSel: 'چیزی انتخاب نشده',
  newHabit: '➕ عادت جدید', noHabits: 'هنوز عادتی اضافه نکرده‌ای', streakDays: '🔥 {0} روز پشت‌سرهم', todayPct: ' · امروز {0}٪',
  focus25: '🍅 تمرکز ۲۵', rest5: '☕ استراحت ۵', rest15: '🛋️ استراحت ۱۵', start: '▶️ شروع', pause: '⏸ توقف',
  restart: '↺ از اول', minU: 'دقیقه', slotNew: 'تایم', timerDone: '⏰ تایمر تمام شد!',
  timerHelp: '🍅 جلسه‌های تمرکز امروز: {0}<br>دکمه‌های کناری تایم‌های دلخواه تو هستند؛ ＋ را بزن تا بسازی، نگه‌دار تا ویرایش یا حذف کنی.',
  moneyToday: 'امروز (تومان)', moneyMonth: 'این ماه (تومان)', budgetMonth: '📅 بودجه این ماه',
  overBudget: ' — از بودجه رد شده‌ای!', newSpend: '➕ هزینه جدید', noSpend: 'هنوز هزینه‌ای ثبت نشده',
  newGoal: '➕ هدف جدید', noGoals: 'هنوز هدفی نداری', goalDone: '🎉 تمام شد', goalLate: '⌛ مهلت تمام شده',
  goalDays: '{0} روز مانده · {1}', onTrack: '✅ طبق برنامه', behind: '⚠️ عقب‌تر از برنامه',
  goalReached: '🎉 تبریک! به هدفت رسیدی',
  st_today: '✅ انجام‌شده امروز', st_week: '📆 انجام‌شده این هفته', st_streak: '🔥 بهترین رشتهٔ عادت', st_pomo: '🍅 تمرکز امروز',
  ch_t: '✅ کارهای انجام‌شده', ch_h: '🔥 عادت‌های انجام‌شده', ch_m: '💰 هزینه‌ها', ch_p: '🍅 جلسه‌های تمرکز',
  tapMore: 'ماه و سال ←', rWeek: 'هفته', rMonth: 'ماه', rYear: 'سال', total: 'جمع', history: 'سابقه',
  noEntries: 'چیزی ثبت نشده', delNote: 'حذف از اینجا فقط از آمار پاک می‌کند، نه از بخش‌های دیگر. حذف در بخش‌های دیگر هم آمار را پاک نمی‌کند.',
  entryDeleted: 'از آمار حذف شد', weekTotal: 'جمع هفته: {0} {1}', topCat: 'بیشترین هزینهٔ این ماه: {0} ({1} {2})',
  focusSession: 'جلسهٔ تمرکز',
  language: 'زبان', appearance: 'ظاهر', theme: 'پوسته', thDark: '🌙 تیره', thLight: '☀️ روشن', thAuto: '🌓 خودکار',
  thAutoHint: 'در حالت خودکار، تم با روز و شب عوض می‌شود', accent: 'رنگ اصلی',
  alerts: 'هشدارها', sound: 'صدا', soundSub: 'بوق یادآوری و تایمر', vib: 'لرزش', vibSub: 'لرزش هنگام هشدار',
  budget: 'بودجه', budgetMonthly: 'بودجهٔ ماهانه', budgetSub: 'صفر یعنی بدون بودجه', save: 'ذخیره', budgetSaved: 'بودجه ذخیره شد',
  data: 'اطلاعات', backup: 'پشتیبان‌گیری', backupPh: 'متن پشتیبان اینجا ساخته می‌شود. برای بازیابی، متن را اینجا بچسبان.',
  bkMake: '📤 ساخت و کپی', bkLoad: '📥 بازیابی', bkOk: 'پشتیبان ساخته و کپی شد ✅', bkManual: 'متن را کپی کن و جایی نگه دار',
  bkLoaded: 'اطلاعات بازیابی شد ✅', bkBad: 'متن پشتیبان درست نیست', danger: 'منطقهٔ خطر', eraseAll: '🗑 پاک کردن همه اطلاعات',
  resetTitle: '⚠️ همه‌چیز پاک می‌شود',
  resetMsg: 'همه‌چیز برای همیشه پاک می‌شود: کارها، یادداشت‌ها، لیست خرید، عادت‌ها، هزینه‌ها، هدف‌ها، تایم‌های دلخواه، آمار و تنظیمات.\nاین کار قابل برگشت نیست.\n\nاگر مطمئن نیستی، اول یک پشتیبان بگیر.',
  resetYes: 'بله، همه چیز پاک شود', resetDone: 'همه اطلاعات پاک شد', localNote: 'اطلاعات فقط روی همین دستگاه ذخیره می‌شود',
  cancel: 'انصراف', closeB: 'بستن', edit: '✏️ ویرایش', del: '🗑 حذف', deleted: 'حذف شد 🗑', saved: 'ذخیره شد', saveBtn: '💾 ذخیره',
  yes: 'بله', no: 'خیر', clearBtn: '✕ پاک', subPh: 'مورد جدید...', notFound: 'پیدا نشد',
  fTitle: 'عنوان', fDue: '⏰ زمان (اختیاری)', dueEmpty: 'بدون زمان — انتخاب کن', fPri: 'اولویت', pri0: 'کم', pri1: 'متوسط', pri2: 'زیاد',
  fRep: '🔁 تکرار', repNone: 'بدون تکرار', repD: 'هر روز', repW: 'هر هفته', fSubs: '☑️ مراحل داخل کار (اختیاری)',
  fCloud: '☁️ نمایش به شکل ابر', editTask: '✏️ ویرایش کار', titleMissing: 'عنوان را بنویس',
  fNoteText: 'متن یادداشت', editNote: '✏️ ویرایش یادداشت', noteEmpty: 'متن یادداشت خالی است',
  fShopName: 'چی می‌خوای بخری؟', fPrice: '💰 قیمت (تومان، اختیاری)', fSaved: '🐖 تا الان چقدر کنار گذاشته‌ای (اختیاری)',
  fWhen: '⏳ چه زمانی بخرم؟', thisWeek: 'این هفته', oneMonth: 'یک ماه', whenFunded: 'وقتی پولش جمع شد', pickDate: '📅 تاریخ',
  whenSel: 'انتخاب‌شده: {0}', whichMonth: '📆 کدام ماه؟', needName: 'نام کالا را بنویس', editItem: '✏️ ویرایش مورد خرید',
  fundedToast: '🎉 پولِ «{0}» جمع شد! می‌تونی بخری', buyTime: '🛒 زمان خرید رسید: {0}', andMore: ' و {0} مورد دیگر',
  fHabitName: 'نام عادت', fHabitSubs: '☑️ بخش‌های داخل عادت (اختیاری؛ با تیک زدن همه، عادت خودش تیک می‌خورد)',
  editHabit: '✏️ ویرایش عادت', needHabit: 'نام عادت را بنویس',
  fAmount: '💵 مبلغ (تومان)', fDesc: 'بابت چی؟ (اختیاری)', fCat: 'دسته', editSpend: '✏️ ویرایش هزینه',
  badAmount: 'مبلغ را درست وارد کن', spendSaved: 'ثبت شد 💰',
  cat0: 'غذا', cat1: 'رفت‌وآمد', cat2: 'خرید', cat3: 'قبض', cat4: 'تفریح', cat5: 'سایر',
  fGoalTitle: 'عنوان هدف', fIcon: 'آیکون', fTarget: '🎯 مقدار هدف (مثلاً ۱۰)', fCur: '📍 تا الان چقدر انجام شده',
  fUnit: 'واحد (مثلاً کتاب، کیلومتر، تومان)', fStep: '⚡ گام افزایش (خالی = خودکار)', fDeadline: '📅 مهلت (اختیاری)',
  noDeadline: 'بدون مهلت — انتخاب کن', editGoal: '✏️ ویرایش هدف', needGoal: 'عنوان هدف را بنویس', badTarget: 'مقدار هدف باید بیشتر از صفر باشد',
  slotAdd: '➕ تایم دلخواه', slotEdit: '✏️ ویرایش تایم دلخواه', fSlotMin: '⏲️ چند دقیقه؟ (۱ تا ۶۰۰)', badMin: 'عددی بین ۱ تا ۶۰۰ وارد کن',
  savTitle: '💰 پس‌انداز برای: {0}', savNow: 'تا الان', fSavAmt: 'چقدر اضافه یا کم کنیم؟ (تومان)', savAdd: '➕ اضافه کن', savSub: '➖ کم کن',
  quickTitle: '🐦 افزودن سریع', fQuickText: 'چی تو ذهنته؟', quickPh: 'مثلاً: زنگ زدن به مامان', fType: 'نوع',
  typeTask: '✅ کار', typeNote: '📝 یادداشت', fQuickDue: '⏰ یادآوری (فقط برای کار)', sendCloud: '☁️ ابر کن و بفرست',
  justSave: '📋 فقط ذخیره کن', needText: 'چیزی بنویس',
  askCloudT: '☁️ ابر بشه؟', askCloudMsg: 'می‌خوای این مورد روی صفحه اصلی به شکل ابر نشان داده بشه؟',
  cloudYes: '☁️ بله، ابر بشه', cloudNo: 'نه', cloudMade: 'ابر شد ☁️', removeCloud: '☁️ برداشتن از ابرها', makeCloud: '☁️ نمایش به شکل ابر',
  markDone: '✓ انجام شد', undo: '↺ برگرداندن', copyText: '📋 کپی متن', copied: 'کپی شد 📋', copyFail: 'کپی نشد',
  pin: '📌 سنجاق', unpin: '📌 برداشتن سنجاق', pick: '✔ انتخاب / خریدم', unpick: '↺ از انتخاب درآوردن',
  useTimer: '▶️ استفاده', customTimer: '⏱️ تایم دلخواه', priLabel: 'اولویت {0}', subCount: '{0} بخش داخلی',
  pkTitleDT: '📅 انتخاب تاریخ و ساعت', pkTitleD: '📅 انتخاب تاریخ', hourL: 'ساعت', minL: 'دقیقه',
  pre30: '۳۰ دقیقه دیگر', pre60: '۱ ساعت دیگر', pre120: '۲ ساعت دیگر', preTonight: 'امشب ۲۱:۰۰', preTom: 'فردا ۰۹:۰۰',
  confirm: '✔ تأیید', noTime: 'بدون زمان', badTime: 'زمان درست نیست',
  cheer: 'آفرین! 👏', nextMade: 'آفرین! نوبت بعدی ساخته شد 🔁',
  dueOne: '⏰ زمان کار رسید: {0}', dueMany: '⏰ {0} کار به موعدشان رسیدند'
},
en: {
  appTitle: 'Daily Planner', home: 'Home', settings: 'Settings', menu: 'Menu',
  sec_tasks: 'Tasks', sec_notes: 'Notes', sec_shop: 'Shopping', sec_habits: 'Habits',
  sec_timer: 'Timer', sec_money: 'Spending', sec_goals: 'Goals', sec_stats: 'Stats',
  today: 'Today', tomorrow: 'Tomorrow', u_day: 'd', u_hour: 'h', u_min: 'min', and: ' ',
  left: 'left', overdue: 'overdue', now: 'just now', cur: 'Toman',
  skyEmpty: 'The sky is empty ☀️', skyEmptySub: 'Add something with the bird to make a cloud',
  moreClouds: '+{0} more', birdLabel: 'Quick add', allClouds: 'All clouds',
  newTask: '➕ New task', tabOpen: 'Open', tabDone: 'Done', noDone: 'Nothing completed yet',
  noTasks: 'Nothing here 🎉', noSchedule: 'No schedule', clearDone: '🧹 Clear completed',
  newNote: '➕ New note', noNotes: 'No notes yet', searchNotes: '🔎 Search notes',
  newItem: '➕ New item', noShop: 'Your list is empty', shopTotal: 'Total: {0} Toman · Saved: {1}',
  noPrice: 'No price', funded: '✅ Fully funded!', of: '{0} of {1}', savingsBtn: '💰 Savings',
  copySel: '📋 Copy selected', clearSel: '🧹 Clear selected', nothingSel: 'Nothing selected',
  newHabit: '➕ New habit', noHabits: 'No habits yet', streakDays: '🔥 {0}-day streak', todayPct: ' · today {0}%',
  focus25: '🍅 Focus 25', rest5: '☕ Break 5', rest15: '🛋️ Break 15', start: '▶️ Start', pause: '⏸ Pause',
  restart: '↺ Restart', minU: 'min', slotNew: 'Timer', timerDone: '⏰ Timer finished!',
  timerHelp: '🍅 Focus sessions today: {0}<br>The side buttons are your own timers: tap ＋ to create one, press and hold to edit or delete.',
  moneyToday: 'Today (Toman)', moneyMonth: 'This month (Toman)', budgetMonth: '📅 Monthly budget',
  overBudget: ' — over budget!', newSpend: '➕ New expense', noSpend: 'No expenses yet',
  newGoal: '➕ New goal', noGoals: 'No goals yet', goalDone: '🎉 Completed', goalLate: '⌛ Deadline passed',
  goalDays: '{0} days left · {1}', onTrack: '✅ On track', behind: '⚠️ Behind schedule',
  goalReached: '🎉 Congrats! Goal reached',
  st_today: '✅ Done today', st_week: '📆 Done this week', st_streak: '🔥 Best habit streak', st_pomo: '🍅 Focus today',
  ch_t: '✅ Completed tasks', ch_h: '🔥 Completed habits', ch_m: '💰 Spending', ch_p: '🍅 Focus sessions',
  tapMore: 'Month & year →', rWeek: 'Week', rMonth: 'Month', rYear: 'Year', total: 'Total', history: 'History',
  noEntries: 'Nothing recorded', delNote: 'Deleting here only removes it from stats, not from the other sections. Deleting elsewhere never removes stats.',
  entryDeleted: 'Removed from stats', weekTotal: 'Week total: {0} {1}', topCat: 'Top spending this month: {0} ({1} {2})',
  focusSession: 'Focus session',
  language: 'Language', appearance: 'Appearance', theme: 'Theme', thDark: '🌙 Dark', thLight: '☀️ Light', thAuto: '🌓 Auto',
  thAutoHint: 'Auto switches with day and night', accent: 'Accent color',
  alerts: 'Alerts', sound: 'Sound', soundSub: 'Reminder and timer beep', vib: 'Vibration', vibSub: 'Vibrate on alerts',
  budget: 'Budget', budgetMonthly: 'Monthly budget', budgetSub: '0 means no budget', save: 'Save', budgetSaved: 'Budget saved',
  data: 'Data', backup: 'Backup', backupPh: 'Your backup text appears here. Paste a backup here to restore.',
  bkMake: '📤 Create & copy', bkLoad: '📥 Restore', bkOk: 'Backup created and copied ✅', bkManual: 'Copy the text and keep it safe',
  bkLoaded: 'Data restored ✅', bkBad: 'Invalid backup text', danger: 'Danger zone', eraseAll: '🗑 Erase all data',
  resetTitle: '⚠️ Everything will be erased',
  resetMsg: 'Everything will be permanently erased: tasks, notes, shopping list, habits, expenses, goals, custom timers, stats and settings.\nThis cannot be undone.\n\nIf you are not sure, create a backup first.',
  resetYes: 'Yes, erase everything', resetDone: 'All data erased', localNote: 'Data is stored only on this device',
  cancel: 'Cancel', closeB: 'Close', edit: '✏️ Edit', del: '🗑 Delete', deleted: 'Deleted 🗑', saved: 'Saved', saveBtn: '💾 Save',
  yes: 'Yes', no: 'No', clearBtn: '✕ Clear', subPh: 'New item...', notFound: 'Not found',
  fTitle: 'Title', fDue: '⏰ Time (optional)', dueEmpty: 'No time — tap to set', fPri: 'Priority', pri0: 'Low', pri1: 'Medium', pri2: 'High',
  fRep: '🔁 Repeat', repNone: 'No repeat', repD: 'Daily', repW: 'Weekly', fSubs: '☑️ Steps inside the task (optional)',
  fCloud: '☁️ Show as a cloud', editTask: '✏️ Edit task', titleMissing: 'Enter a title',
  fNoteText: 'Note text', editNote: '✏️ Edit note', noteEmpty: 'The note is empty',
  fShopName: 'What do you want to buy?', fPrice: '💰 Price (optional)', fSaved: '🐖 Saved so far (optional)',
  fWhen: '⏳ When to buy?', thisWeek: 'This week', oneMonth: 'A month', whenFunded: 'When funded', pickDate: '📅 Date',
  whenSel: 'Selected: {0}', whichMonth: '📆 Which month?', needName: 'Enter an item name', editItem: '✏️ Edit item',
  fundedToast: '🎉 You saved enough for “{0}”!', buyTime: '🛒 Time to buy: {0}', andMore: ' and {0} more',
  fHabitName: 'Habit name', fHabitSubs: '☑️ Parts of the habit (optional; completing all checks the habit)',
  editHabit: '✏️ Edit habit', needHabit: 'Enter a habit name',
  fAmount: '💵 Amount', fDesc: 'What for? (optional)', fCat: 'Category', editSpend: '✏️ Edit expense',
  badAmount: 'Enter a valid amount', spendSaved: 'Recorded 💰',
  cat0: 'Food', cat1: 'Transport', cat2: 'Shopping', cat3: 'Bills', cat4: 'Fun', cat5: 'Other',
  fGoalTitle: 'Goal title', fIcon: 'Icon', fTarget: '🎯 Target amount (e.g. 10)', fCur: '📍 Progress so far',
  fUnit: 'Unit (e.g. books, km, $)', fStep: '⚡ Step size (empty = auto)', fDeadline: '📅 Deadline (optional)',
  noDeadline: 'No deadline — tap to set', editGoal: '✏️ Edit goal', needGoal: 'Enter a goal title', badTarget: 'Target must be greater than zero',
  slotAdd: '➕ Custom timer', slotEdit: '✏️ Edit custom timer', fSlotMin: '⏲️ How many minutes? (1–600)', badMin: 'Enter a number from 1 to 600',
  savTitle: '💰 Savings for: {0}', savNow: 'So far', fSavAmt: 'Amount to add or remove', savAdd: '➕ Add', savSub: '➖ Remove',
  quickTitle: '🐦 Quick add', fQuickText: 'What is on your mind?', quickPh: 'e.g. Call mom', fType: 'Type',
  typeTask: '✅ Task', typeNote: '📝 Note', fQuickDue: '⏰ Reminder (tasks only)', sendCloud: '☁️ Make a cloud and send',
  justSave: '📋 Just save', needText: 'Write something',
  askCloudT: '☁️ Make it a cloud?', askCloudMsg: 'Do you want this to appear as a cloud on the home screen?',
  cloudYes: '☁️ Yes, make a cloud', cloudNo: 'No', cloudMade: 'Cloud created ☁️', removeCloud: '☁️ Remove from clouds', makeCloud: '☁️ Show as a cloud',
  markDone: '✓ Mark done', undo: '↺ Undo', copyText: '📋 Copy text', copied: 'Copied 📋', copyFail: 'Copy failed',
  pin: '📌 Pin', unpin: '📌 Unpin', pick: '✔ Select / bought', unpick: '↺ Unselect',
  useTimer: '▶️ Use', customTimer: '⏱️ Custom timer', priLabel: '{0} priority', subCount: '{0} parts',
  pkTitleDT: '📅 Pick date & time', pkTitleD: '📅 Pick a date', hourL: 'Hour', minL: 'Minute',
  pre30: 'In 30 min', pre60: 'In 1 hour', pre120: 'In 2 hours', preTonight: 'Tonight 21:00', preTom: 'Tomorrow 09:00',
  confirm: '✔ Confirm', noTime: 'No time', badTime: 'Invalid time',
  cheer: 'Well done! 👏', nextMade: 'Well done! Next one created 🔁',
  dueOne: '⏰ Task due: {0}', dueMany: '⏰ {0} tasks are due'
}
};

/* ================= شروع ================= */
applyTheme();
setWheel(S.set.wheel !== false, false);
setRot(0);
try { history.replaceState({ s: 'home' }, ''); } catch (e) {}
applyLang();
openSection('home', true);
checkReminders();

})();