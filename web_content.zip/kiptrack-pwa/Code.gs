/**
 * KipTrack – cloud sync backend (Google Apps Script, bound to the Google Sheet)
 *
 * WHAT IT DOES
 *  - Stores KipTrack's learners, attendance records and settings in this spreadsheet.
 *  - Every device running KipTrack talks to this script (web app), so an edit made on
 *    one phone/laptop appears on all the others within seconds.
 *  - Formats the sheet for you (run setup() once).
 *  - Lets you edit the "Learners" tab directly in Google Sheets and have the change
 *    flow out to every device.
 *
 * SETUP: see SYNC-SETUP.md (5 minutes).
 */

// ─── CHANGE THIS to any long random text, and put the SAME text in index.html (SYNC_KEY) ───
const SECRET = 'DmeZV3OhCeJyKSE-LPwAEHPT4na6oVtqjpzSmIH_CX8';

const TZ    = 'Africa/Nairobi';
const BRAND = '#0253A2';
const SPREADSHEET_ID = '10Gq2Ko_eyPnLTJRZPXQ324aLdxP1w97YfKTt4TaFog0';

const SETTING_LABELS = { institutionPhone: 'Institution WhatsApp number' };

const TABLES = {
  learners: {
    sheet: 'Learners',
    headers: ['ID', 'First Name', 'Last Name', 'Centre', 'Parent Name', 'Parent Phone',
              'Expected Check-in', 'Expected Check-out', 'Status', 'Last Updated',
              'Version', 'Changed', 'Data'],
    widths:  [120, 120, 120, 100, 170, 130, 125, 130, 90, 160, 80, 80, 80]
  },
  events: {
    sheet: 'Attendance',
    headers: ['ID', 'Date & Time', 'Centre', 'Learner', 'Type', 'Parent', 'Parent Phone',
              'Notification', 'Status', 'Last Updated', 'Version', 'Changed', 'Data'],
    widths:  [120, 175, 100, 170, 110, 170, 130, 190, 90, 160, 80, 80, 80]
  }
};
const NCOLS = 13;            // Learners / Attendance
const C_STATUS = 8, C_UPDATED = 9, C_VERSION = 10, C_CHANGED = 11, C_DATA = 12;   // 0-based
const SETTINGS_SHEET = 'Settings';
const DATE_FMT = 'ddd d mmm yyyy, HH:mm';

/* ───────────────────────────── web app entry points ───────────────────────────── */

function doGet(e) {
  return json_({ ok: true, service: 'KipTrack sync', time: Date.now() });
}

function doPost(e) {
  let out;
  try {
    const p = JSON.parse(e.postData.contents);
    if (p.key !== SECRET) throw new Error('Unauthorized');
    const lock = LockService.getScriptLock();
    lock.waitLock(25000);
    try { out = handleSync_(p); } finally { lock.releaseLock(); }
  } catch (err) {
    out = { ok: false, error: String(err && err.message || err) };
  }
  return json_(out);
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

/* ───────────────────────────── sync logic ───────────────────────────── */

function handleSync_(p) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureSheets_(ss);
  const now = Date.now();
  const since = Number(p.since) || 0;
  const tomb = p.tomb || {};

  const L = syncTable_('learners', ss.getSheetByName(TABLES.learners.sheet), p.learners, tomb.learners, now, since);
  const E = syncTable_('events',   ss.getSheetByName(TABLES.events.sheet),   p.events,   tomb.events,   now, since);
  const S = syncSettings_(ss.getSheetByName(SETTINGS_SHEET), p.settings, now);

  return {
    ok: true,
    serverTime: now,
    learners: L.live, events: E.live,
    tomb: { learners: L.tomb, events: E.tomb },
    settings: S
  };
}

function syncTable_(kind, sh, incoming, tombIn, now, since) {
  const n = NCOLS;
  const hasIncoming = (incoming && incoming.length) || (tombIn && Object.keys(tombIn).length);
  const last = sh.getLastRow();

  // Quick path: nothing to write and nothing changed since the client last looked.
  if (!hasIncoming) {
    if (last < 2) return { live: [], tomb: {} };
    const ch = sh.getRange(2, C_CHANGED + 1, last - 1, 1).getValues();
    let max = 0;
    for (let i = 0; i < ch.length; i++) { const v = Number(ch[i][0]) || 0; if (v > max) max = v; }
    if (max <= since) return { live: [], tomb: {} };
  }

  const rows = last > 1 ? sh.getRange(2, 1, last - 1, n).getValues() : [];
  const map = new Map();
  rows.forEach(function (row, i) {
    if (row[0] === '' || row[0] === null) return;
    const e = parseRow_(kind, row);
    e.row = i + 2;
    map.set(String(e.rec.id), e);
  });

  // Merge what the device sent: newest version wins; on a tie a deletion wins.
  (incoming || []).forEach(function (r) {
    if (!r || r.id === undefined || r.id === null) return;
    const id = String(r.id), v = Number(r.updatedAt) || 0, cur = map.get(id);
    if (!cur) {
      map.set(id, { rec: r, deleted: false, version: v, changed: now, row: 0, dirty: true });
    } else if (v > cur.version) {
      cur.rec = r; cur.deleted = false; cur.version = v; cur.changed = now; cur.dirty = true;
    }
  });
  Object.keys(tombIn || {}).forEach(function (id) {
    const ts = Number(tombIn[id]) || 0, cur = map.get(id);
    if (!cur) {
      map.set(id, { rec: { id: Number(id) }, deleted: true, version: ts, changed: now, row: 0, dirty: true });
    } else if (ts >= cur.version && !(cur.deleted && ts === cur.version)) {
      cur.deleted = true; cur.version = ts; cur.changed = now; cur.dirty = true;
    }
  });

  // Write only what changed.
  const dirty = [];
  map.forEach(function (e) { if (e.dirty) dirty.push(e); });
  dirty.filter(function (e) { return e.row; }).forEach(function (e) {
    sh.getRange(e.row, 1, 1, n).setValues([toRow_(kind, e)]);
  });
  const adds = dirty.filter(function (e) { return !e.row; })
                    .sort(function (a, b) { return Number(a.rec.id) - Number(b.rec.id); });
  if (adds.length) {
    const start = sh.getLastRow() + 1;
    const need = start + adds.length - 1 - sh.getMaxRows();
    if (need > 0) sh.insertRowsAfter(sh.getMaxRows(), need + 500);
    sh.getRange(start, 1, adds.length, n).setValues(adds.map(function (e) { return toRow_(kind, e); }));
  }

  // Reply with everything that changed since the device last synced.
  const live = [], tombOut = {};
  map.forEach(function (e, id) {
    if (e.changed <= since) return;
    if (e.deleted) tombOut[id] = e.version;
    else { e.rec.updatedAt = e.version; live.push(e.rec); }
  });
  return { live: live, tomb: tombOut };
}

function syncSettings_(sh, incoming, now) {
  const keys = Object.keys(SETTING_LABELS);
  const last = sh.getLastRow();
  const vals = last > 1 ? sh.getRange(2, 1, last - 1, 5).getValues() : [];
  const out = {};
  keys.forEach(function (key) {
    const label = SETTING_LABELS[key];
    let idx = -1;
    for (let i = 0; i < vals.length; i++) if (vals[i][0] === label) { idx = i; break; }
    let value = '', version = 0;
    if (idx >= 0) { value = String(vals[idx][1] === null ? '' : vals[idx][1]); version = Number(vals[idx][3]) || 0; }
    if (incoming && incoming[key] !== undefined && (Number(incoming.updatedAt) || 0) > version) {
      value = String(incoming[key]); version = Number(incoming.updatedAt);
      const row = [label, value, new Date(now), version, now];
      if (idx >= 0) sh.getRange(idx + 2, 1, 1, 5).setValues([row]);
      else sh.getRange(sh.getLastRow() + 1, 1, 1, 5).setValues([row]);
    }
    out[key] = value;
    out.updatedAt = Math.max(out.updatedAt || 0, version);
  });
  return out;
}

/* ───────────────────────────── row <-> record ───────────────────────────── */

function str_(v) { return v === null || v === undefined ? '' : String(v); }

function time_(v) {              // accepts "8:30", "08:30:00" or a real time value
  if (v instanceof Date) return Utilities.formatDate(v, TZ, 'HH:mm');
  const m = String(v || '').match(/^\s*(\d{1,2}):(\d{2})/);
  return m ? ('0' + m[1]).slice(-2) + ':' + m[2] : '';
}

function parseRow_(kind, row) {
  let rec = {};
  try { rec = JSON.parse(row[C_DATA] || '{}'); } catch (e) { rec = {}; }
  rec.id = Number(row[0]);
  if (kind === 'learners') {     // what is typed in the sheet wins over the stored copy
    rec.firstName = str_(row[1]);   rec.lastName = str_(row[2]);
    rec.centre = str_(row[3]);      rec.parentName = str_(row[4]);
    rec.parentPhone = str_(row[5]);
    rec.expectedCheckIn = time_(row[6]); rec.expectedCheckOut = time_(row[7]);
  }
  return {
    rec: rec,
    deleted: String(row[C_STATUS]) === 'Removed',
    version: Number(row[C_VERSION]) || 0,
    changed: Number(row[C_CHANGED]) || 0
  };
}

function toRow_(kind, e) {
  const r = e.rec;
  const visible = kind === 'learners'
    ? [r.id, r.firstName || '', r.lastName || '', r.centre || '', r.parentName || '',
       r.parentPhone || '', r.expectedCheckIn || '', r.expectedCheckOut || '']
    : [r.id, r.ts ? new Date(r.ts) : '', r.centre || '', r.learner || '', r.type || '',
       r.parentName || '', r.parentPhone || '', r.notification || ''];
  return visible.concat([e.deleted ? 'Removed' : 'Active', new Date(e.changed), e.version, e.changed, JSON.stringify(r)]);
}

/* ───────────────────────────── edits made directly in the sheet ───────────────────────────── */

/** Stamps rows you edit by hand so KipTrack devices pick the change up. */
function onEdit(e) {
  try {
    const sh = e.range.getSheet(), name = sh.getName();
    const r1 = Math.max(e.range.getRow(), 2), r2 = e.range.getRow() + e.range.getNumRows() - 1;
    const c1 = e.range.getColumn(), c2 = c1 + e.range.getNumColumns() - 1;
    if (r2 < 2) return;
    const now = Date.now();

    if (name === TABLES.learners.sheet) {
      if (c1 > 9 || c2 < 2) return;                       // only columns B–I matter
      for (let r = r1; r <= r2; r++) {
        const row = sh.getRange(r, 1, 1, 9).getValues()[0];
        if (row.slice(1, 8).join('') === '') continue;    // cleared row
        if (row[0] === '') sh.getRange(r, 1).setValue(now + (r - r1));   // new learner typed into the sheet
        if (row[8] === '') sh.getRange(r, 9).setValue('Active');
        sh.getRange(r, C_UPDATED + 1, 1, 3).setValues([[new Date(now), now, now]]);
      }
    } else if (name === SETTINGS_SHEET) {
      if (c1 > 2 || c2 < 2) return;                       // only the Value column
      for (let r = r1; r <= r2; r++) sh.getRange(r, 3, 1, 3).setValues([[new Date(now), now, now]]);
    }
  } catch (err) { /* never block an edit */ }
}

/* ───────────────────────────── one-time formatting ───────────────────────────── */

/** Run this ONCE from the Apps Script editor (select "setup" → Run). Safe to re-run. */
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  ss.setSpreadsheetTimeZone(TZ);
  formatTable_(ss, 'learners');
  formatTable_(ss, 'events');
  formatSettings_(ss);
  formatAbout_(ss);
  const blank = ss.getSheetByName('Sheet1');
  if (blank && blank.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(blank);
  ss.setActiveSheet(ss.getSheetByName(TABLES.learners.sheet));
}

function ensureSheets_(ss) {
  if (!ss.getSheetByName(TABLES.learners.sheet) || !ss.getSheetByName(TABLES.events.sheet) ||
      !ss.getSheetByName(SETTINGS_SHEET)) setup();
}

function getOrCreate_(ss, name) {
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function styleHeader_(sh, ncols) {
  sh.getRange(1, 1, 1, ncols)
    .setBackground(BRAND).setFontColor('#FFFFFF').setFontWeight('bold').setFontFamily('Arial')
    .setFontSize(10).setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(true);
  sh.setRowHeight(1, 34);
  sh.setFrozenRows(1);
  sh.setTabColor(BRAND);
}

function band_(sh, ncols) {
  if (sh.getBandings().length) return;
  const rng = sh.getRange(1, 1, sh.getMaxRows(), ncols);
  rng.applyRowBanding(SpreadsheetApp.BandingTheme.LIGHT_GREY, true, false)
     .setHeaderRowColor(BRAND).setFirstRowColor('#FFFFFF').setSecondRowColor('#EAF1F8');
}

function formatTable_(ss, kind) {
  const cfg = TABLES[kind];
  const sh = getOrCreate_(ss, cfg.sheet);
  const max = Math.max(sh.getMaxRows(), 1000);
  if (sh.getMaxRows() < max) sh.insertRowsAfter(sh.getMaxRows(), max - sh.getMaxRows());
  if (sh.getMaxColumns() < NCOLS) sh.insertColumnsAfter(sh.getMaxColumns(), NCOLS - sh.getMaxColumns());

  sh.getRange(1, 1, 1, NCOLS).setValues([cfg.headers]);
  styleHeader_(sh, NCOLS);
  cfg.widths.forEach(function (w, i) { sh.setColumnWidth(i + 1, w); });

  const body = sh.getRange(2, 1, max - 1, NCOLS);
  body.setFontFamily('Arial').setFontSize(10).setVerticalAlignment('middle');
  const fmt = function (col, f) { sh.getRange(2, col, max - 1, 1).setNumberFormat(f); };
  fmt(1, '0');                                  // ID
  fmt(C_UPDATED + 1, DATE_FMT);                 // Last Updated
  if (kind === 'learners') {
    fmt(4, '@'); fmt(5, '@'); fmt(6, '@'); fmt(7, '@'); fmt(8, '@');   // keep +254… and 08:30 exactly as typed
    sh.getRange(2, 7, max - 1, 2).setHorizontalAlignment('center');
  } else {
    fmt(2, 'ddd d mmm yyyy, HH:mm:ss'); fmt(7, '@');
    sh.getRange(2, 5, max - 1, 1).setHorizontalAlignment('center').setFontWeight('bold');
  }
  sh.getRange(2, 9, max - 1, 1).setHorizontalAlignment('center');
  sh.getRange(2, C_UPDATED + 1, max - 1, 1).setFontColor('#657384');

  sh.getRange(2, 9, max - 1, 1).setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(['Active', 'Removed'], true).setAllowInvalid(false).build());
  if (kind === 'learners') {
    sh.getRange(2, 4, max - 1, 1).setDataValidation(
      SpreadsheetApp.newDataValidation().requireValueInList(['South C', 'Riverside'], true).setAllowInvalid(false).build());
  }

  const rules = [];
  const A = sh.getRange(2, 1, max - 1, 9);
  rules.push(SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=$I2="Removed"').setFontColor('#9AA5B1').setStrikethrough(true).setRanges([A]).build());
  if (kind === 'events') {
    const T = sh.getRange(2, 5, max - 1, 1);
    rules.push(SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('CHECK IN')
      .setBackground('#E3F4EA').setFontColor('#16834A').setRanges([T]).build());
    rules.push(SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('CHECK OUT')
      .setBackground('#FDF1DC').setFontColor('#B26A00').setRanges([T]).build());
  }
  sh.setConditionalFormatRules(rules);

  band_(sh, NCOLS);
  sh.hideColumns(C_VERSION + 1, 3);             // Version, Changed, Data are for the sync engine
  if (kind === 'events' && !sh.getProtections(SpreadsheetApp.ProtectionType.SHEET).length) {
    sh.protect().setWarningOnly(true).setDescription('Attendance is written by KipTrack');
  }
}

function formatSettings_(ss) {
  const sh = getOrCreate_(ss, SETTINGS_SHEET);
  sh.getRange(1, 1, 1, 5).setValues([['Setting', 'Value', 'Last Updated', 'Version', 'Changed']]);
  styleHeader_(sh, 5);
  sh.setColumnWidth(1, 240); sh.setColumnWidth(2, 240); sh.setColumnWidth(3, 160);
  sh.getRange(2, 1, 50, 5).setFontFamily('Arial').setFontSize(10);
  sh.getRange(2, 2, 50, 1).setNumberFormat('@');
  sh.getRange(2, 3, 50, 1).setNumberFormat(DATE_FMT).setFontColor('#657384');
  Object.keys(SETTING_LABELS).forEach(function (key, i) {
    if (sh.getRange(2 + i, 1).getValue() === '') {
      sh.getRange(2 + i, 1, 1, 5).setValues([[SETTING_LABELS[key], '', new Date(), 0, Date.now()]]);
    }
  });
  sh.getRange(2, 1, 1, 2).setBackground('#EAF1F8');
  sh.hideColumns(4, 2);
}

function formatAbout_(ss) {
  const sh = getOrCreate_(ss, 'About');
  sh.clear();
  const lines = [
    ['KipTrack – cloud database'],
    ['This spreadsheet is the shared database for the KipTrack attendance app (Kip McGrath South C & Riverside).'],
    [''],
    ['Learners tab: you may edit or add learners here directly – devices pick the change up within a minute. Set Status to "Removed" to remove a learner.'],
    ['Attendance tab: written by the app (one row per check-in / check-out). It is protected with a warning – please do not edit by hand.'],
    ['Settings tab: the institution WhatsApp number used in parent messages.'],
    [''],
    ['Do not rename the tabs or move the header row. Hidden columns (Version, Changed, Data) are used by the sync engine.']
  ];
  sh.getRange(1, 1, lines.length, 1).setValues(lines).setFontFamily('Arial').setFontSize(10).setWrap(true).setVerticalAlignment('top');
  sh.getRange(1, 1).setFontSize(15).setFontWeight('bold').setFontColor(BRAND);
  sh.setColumnWidth(1, 640);
  sh.setTabColor('#657384');
  sh.setHiddenGridlines(true);
}
