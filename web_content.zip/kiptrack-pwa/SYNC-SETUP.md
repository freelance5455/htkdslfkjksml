# KipTrack ↔ Google Sheets sync

This project is prepared to use the Google Sheet supplied for Kip McGrath data:

`https://docs.google.com/spreadsheets/d/10Gq2Ko_eyPnLTJRZPXQ324aLdxP1w97YfKTt4TaFog0/edit`

The Google Apps Script in `Code.gs` is already configured for this spreadsheet and the same sync key is already embedded in `index.html`.

## One-time setup

### 1. Add the Apps Script to the Google Sheet

Sign in to the Google account that owns the sheet (the account you supplied for this project).

1. Open the sheet.
2. Go to **Extensions → Apps Script**.
3. Delete the starter code and paste the complete contents of `Code.gs`.
4. Save.
5. Select **`setup`** from the function dropdown and click **Run**.
6. Approve the requested permissions.

The script will create and format these tabs:

- **Learners** – shared learner/parent database
- **Attendance** – check-in/check-out records
- **Settings** – shared app settings
- **About** – database instructions

### 2. Deploy the script as a Web App

In Apps Script:

1. **Deploy → New deployment**
2. Select **Web app**.
3. **Execute as:** Me
4. **Who has access:** Anyone
5. Deploy and copy the URL ending in `/exec`.

### 3. Put the Web App URL into the app

Open `index.html` and change:

```js
const SYNC_URL="";
```

to:

```js
const SYNC_URL="https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec";
```

The `SYNC_KEY` is already configured and must remain the same in both `index.html` and `Code.gs`.

### 4. Rebuild/redeploy the HTML/PWA

Once the URL is entered, every device using the same hosted app will share the same cloud database.

## How synchronization works

- A learner added/edited on one device is uploaded to the Google Sheet.
- Other devices pull the change automatically while the app is open.
- The app also syncs when it comes back online.
- Attendance records are stored centrally in **Attendance**.
- Parent name and WhatsApp number are stored with each learner and attendance record.
- Direct edits in the **Learners** sheet are stamped and flow back to devices.
- The newest edit wins when two devices edit the same record.
- Deleted learners are retained as `Removed` so an old device does not accidentally recreate them.

## Important first-sync step

Because the sheet is blank, decide which device currently has the correct learner database before the first cloud sync. Open that device/app first after the Web App URL is configured. Its learner records will populate the sheet, and subsequent devices will synchronize from the sheet.

If you want the Google Sheet to be the initial source of truth instead, leave the app's local learner list empty before the first sync and enter the learners in the **Learners** tab.

## Testing

After deployment, the bottom-right status indicator should change from **Local only** to **Synced HH:MM**.

Test with two devices:

1. Add or edit a learner on Device A.
2. Wait for **Synced**.
3. Open/refresh Device B.
4. Confirm the learner appears.
5. Edit the parent name or phone in Google Sheets.
6. Confirm the change reaches both devices.
