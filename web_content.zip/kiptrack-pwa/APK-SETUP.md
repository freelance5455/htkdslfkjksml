# Turning KipTrack into an installable Android app (.apk)

This folder now contains a proper installable web app (PWA):

- `index.html` — the app
- `manifest.json` — tells Android it's an installable app (name, icon, colors)
- `service-worker.js` — lets it work offline / feel like a native app
- `icon-192.png`, `icon-512.png`, `icon-512-maskable.png` — app icons

You can't build a real `.apk` without hosting these files somewhere with a
real web address (Android's app-building tools need to fetch them over
HTTPS) and without the Android build toolchain, which needs an internet
connection I don't have in this chat. Here's the fastest free path to a
real, installable APK — about 10–15 minutes, no coding.

## Step 1: Host the files (free, ~2 minutes)

Pick one:
- **GitHub Pages** (recommended, free, simple): create a free GitHub
  account, create a new repository, upload all 6 files in this folder to
  it, then turn on Pages in the repo's Settings → Pages → deploy from the
  main branch. You'll get a URL like
  `https://yourname.github.io/kiptrack/`.
- **Netlify Drop**: go to app.netlify.com/drop and drag this whole folder
  in. It gives you a live URL immediately, no account required for a
  quick test link (an account keeps it permanent).

Whichever you use, make sure `index.html`, `manifest.json`,
`service-worker.js`, and the three `icon-*.png` files all end up in the
**same folder** at that URL.

## Step 2: Generate the Android package (free, no coding)

1. Go to **pwabuilder.com** (Microsoft's free tool for exactly this).
2. Paste your hosted URL from Step 1 and click "Start".
3. It will scan the site and confirm it found your manifest, service
   worker and icons (a green checklist).
4. Click **"Package for stores"** → choose **Android**.
5. It generates a signed Android package for you to download — either a
   `.apk` (for direct install / sideloading) or an `.aab` (for uploading
   to the Google Play Store).

## Step 3: Install it on your phone

- If you downloaded a `.apk`: transfer it to your Android phone and open
  it. You'll need to allow "Install from unknown sources" the first time
  Android asks — this is normal for apps installed outside the Play
  Store.
- If you want it properly on the Play Store instead of sideloaded, you'd
  use the `.aab` file and a (paid, one-time $25) Google Play Developer
  account.

## A simpler alternative, if you'd rather skip PWABuilder

No-code app wrapper services like **Median.co**, **GoNative.io**, or
**Appilix.com** do the same job: you give them your hosted URL (from
Step 1) and they hand you back a downloadable `.apk`. They don't
strictly need the manifest/service worker, just the live URL, and most
have a free tier for testing/sideloading before you'd pay for
Play Store publishing.

## Note on real WhatsApp notification sending

Once this is a real installed app with its own web address (not the
claude.ai preview), the "Save & Share on WhatsApp" button should behave
exactly like it does in any normal mobile browser — tapping it should
launch WhatsApp directly, since you're no longer inside an embedded
preview browser.


## WhatsApp link fix
The app now uses the HTTPS `https://wa.me/` click-to-chat format instead of `whatsapp://`. The message is pre-filled; the parent message is not sent automatically.
