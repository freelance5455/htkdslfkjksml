# KipTrack Android/PWA build notes

This version is prepared for rebuilding the Android app after the WhatsApp error.

## WhatsApp fix
- The app contains **no `whatsapp://` custom-scheme links**.
- WhatsApp sharing uses the standard HTTPS endpoint:
  `https://api.whatsapp.com/send?phone=...&text=...`
- This prevents a WebView wrapper from attempting to load `whatsapp://send` as a web page.
- The message remains pre-filled; the user still taps **Send** in WhatsApp.
- The parent/guardian name is taken from the learner database.
- Morning/afternoon/evening greeting is generated from the event time.

## Logo
The Kip McGrath logo is embedded directly in `index.html`, so it does not depend on a separate image path.

## Important for Android wrappers
If an Android wrapper still changes the HTTPS link into `whatsapp://send`, the wrapper itself is rewriting the URL. In that case, its external-link/deep-link setting must be changed so `https://api.whatsapp.com/` opens externally (or the wrapper must allow WhatsApp as an external app).
