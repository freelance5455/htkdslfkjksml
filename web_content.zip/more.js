/* Daybook add-ons: deen, health, sleep, food, reminders, files, PDF tools, mail, history, menu */
(function(){
"use strict";
KEYS.push('prayers','quran','dhikr','duas','fasts','sleep','sick','reminders','meals','goals','debts','files','contacts');
OBJ.push('prayers','quran','dhikr','fasts');
Object.assign(DEF_SET,{city:'Dhaka',lat:23.8103,lng:90.4125,asr:'Hanafi',qaza:0,qgoal:20,sleepBed:'23:30',sleepWake:'06:30',sleepStart:0,nPrayer:1,nMeds:1,nClass:1,nSleep:1,nWater:0,email:''});
normalize();
Object.assign(ui,{deen:'prayer',foodDay:today(),histDay:today(),ep:null,tz:{n:0,target:33,ph:0}});
TABS.push('deen');
NAV.splice(3,2,['deen','Deen'],['life','Life']);
IC.deen='<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>';
SUB.deen=[['prayer','Prayer'],['quran','Quran'],['duas','Duas'],['tasbih','Tasbih']];
SUB.plan=[['tasks','Tasks'],['cal','Calendar'],['routine','Class routine']];
SUB.study.push(['files','Files'],['tools','PDF tools']);
SUB.life.splice(0,SUB.life.length,['water','Water'],['food','Food'],['habits','Habits'],['sleep','Sleep'],['health','Health'],['acts','Activities'],['money','Money']);
SUB.more.splice(0,SUB.more.length,['reminders','Reminders'],['links','Links'],['notes','Notes'],['mail','Mail'],['history','History'],['settings','Settings']);

let AS=null,DL=null,SM=null;
(async()=>{try{if(window.claude&&window.claude.use){AS=await window.claude.use('assets');DL=await window.claude.use('downloads')}}catch(e){}})();

/* ---------- small helpers ---------- */
const toMin=t=>{const a=String(t||'0:0').split(':');return(+a[0]||0)*60+(+a[1]||0)};
const hm=m=>{m=((Math.round(m)%1440)+1440)%1440;return pad(Math.floor(m/60))+':'+pad(m%60)};
const nowMin=()=>{const d=new Date();return d.getHours()*60+d.getMinutes()};
const dur=m=>m<60?m+' min':Math.floor(m/60)+'h'+(m%60?' '+m%60+'m':'');
const chk=(on,a,attrs,label)=>`<button class="check${on?' on':''}" data-a="${a}" ${attrs} aria-pressed="${on?'true':'false'}" aria-label="${esc(label)}">${ic('check')}</button>`;
const stat=(v,l)=>`<div class="stat"><b>${v}</b><span>${l}</span></div>`;
const dayNav=(a,ds)=>`<div class="row between"><button class="btn sm" data-a="${a}" data-n="-1" aria-label="Previous day">${ic('back')}</button><h3>${ds===today()?'Today':fmt(ds)}</h3><button class="btn sm" data-a="${a}" data-n="1" aria-label="Next day">${ic('next')}</button></div>`;
const fsz=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
let note={};const say=(k,t)=>{note[k]=t;render()};const said=k=>note[k]?`<p class="muted" role="status">${esc(note[k])}</p>`:'';

/* ---------- prayer times (sun position maths, 18°/18°, Hanafi or Shafi Asr) ---------- */
const CITY={Dhaka:[23.8103,90.4125],Chattogram:[22.3569,91.7832],Sylhet:[24.8949,91.8687],Rajshahi:[24.3745,88.6042],Khulna:[22.8456,89.5403],Barishal:[22.701,90.3535],Rangpur:[25.7439,89.2752],Mymensingh:[24.7471,90.4203],Cumilla:[23.4607,91.1809]};
const PR=[['fajr','Fajr'],['dhuhr','Dhuhr'],['asr','Asr'],['maghrib','Maghrib'],['isha','Isha']];
const rad=d=>d*Math.PI/180,deg=r=>r*180/Math.PI,fix=(a,b)=>{a=a-b*Math.floor(a/b);return a<0?a+b:a};
function julian(y,m,d){if(m<=2){y-=1;m+=12}const A=Math.floor(y/100),B=2-A+Math.floor(A/4);return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+B-1524.5}
function sun(jd){const D=jd-2451545,g=fix(357.529+0.98560028*D,360),q=fix(280.459+0.98564736*D,360),L=fix(q+1.915*Math.sin(rad(g))+0.02*Math.sin(rad(2*g)),360),e=23.439-0.00000036*D,RA=deg(Math.atan2(Math.cos(rad(e))*Math.sin(rad(L)),Math.cos(rad(L))))/15;return{decl:deg(Math.asin(Math.sin(rad(e))*Math.sin(rad(L)))),eqt:q/15-fix(RA,24)}}
let ptc={};
function ptimes(ds){
  const s=S.settings,key=ds+'|'+s.lat+'|'+s.lng+'|'+s.asr;if(ptc.k===key)return ptc.v;
  const d=parse(ds),lat=num(s.lat),lng=num(s.lng),tz=-d.getTimezoneOffset()/60,jd=julian(d.getFullYear(),d.getMonth()+1,d.getDate())-lng/360;
  const mid=t=>fix(12-sun(jd+t).eqt,24);
  const ang=(a,t,ccw)=>{const dc=sun(jd+t).decl,x=(-Math.sin(rad(a))-Math.sin(rad(dc))*Math.sin(rad(lat)))/(Math.cos(rad(dc))*Math.cos(rad(lat))),v=deg(Math.acos(Math.max(-1,Math.min(1,x))))/15;return mid(t)+(ccw?-v:v)};
  const asr=(f,t)=>{const dc=sun(jd+t).decl;return ang(-deg(Math.atan(1/(f+Math.tan(rad(Math.abs(lat-dc)))))),t)};
  const raw={fajr:ang(18,5/24,true),sunrise:ang(0.833,6/24,true),dhuhr:mid(.5)+1/60,asr:asr(s.asr==='Shafi'?1:2,13/24),maghrib:ang(0.833,18/24),isha:ang(18,18/24)},v={};
  Object.keys(raw).forEach(k=>{v[k]=hm(fix(raw[k]+tz-lng/15,24)*60)});
  ptc={k:key,v:v};return v;
}
function nextPrayer(){
  const t=ptimes(today()),n=nowMin();
  for(const p of PR){const m=toMin(t[p[0]]);if(m>n)return{name:p[1],t:t[p[0]],mins:m-n}}
  const f=ptimes(addDays(today(),1)).fajr;return{name:'Fajr',t:f,mins:toMin(f)+1440-n};
}
function hijri(){try{return new Intl.DateTimeFormat('en-u-ca-islamic-umalqura',{day:'numeric',month:'long',year:'numeric'}).format(new Date())}catch(e){return''}}
function qibla(){const la=rad(num(S.settings.lat)),dl=rad(39.8262-num(S.settings.lng)),k=rad(21.4225);return Math.round(fix(deg(Math.atan2(Math.sin(dl),Math.cos(la)*Math.tan(k)-Math.sin(la)*Math.cos(dl))),360))}

/* ---------- health episodes ---------- */
const WHEN={'Morning':['08:00'],'Night':['21:00'],'Morning and night':['08:00','21:00'],'Morning, noon and night':['08:00','14:00','21:00'],'Every 6 hours':['06:00','12:00','18:00','23:30'],'Every 8 hours':['06:00','14:00','22:00'],'Custom times':null};
const fixEp=e=>{if(e){e.meds=e.meds||[];e.taken=e.taken||{};e.log=e.log||[];e.photos=e.photos||[]}return e};
const activeEp=()=>fixEp(S.sick.find(e=>e.active));
function doses(ep,ds){
  const a=[];
  ep.meds.forEach(m=>{const st=m.start||ep.start||ds;if(ds<st||(m.days&&diffDays(ds,st)>=m.days))return;
    (m.times||[]).forEach(t=>{const key=m.id+'@'+t;a.push({m:m,t:t,key:key,taken:!!(ep.taken[ds]||{})[key]})})});
  return a.sort((x,y)=>x.t<y.t?-1:1);
}
const doseList=(ep,ds)=>{const l=doses(ep,ds),n=nowMin();return l.length?'<div class="list">'+l.map(x=>`<div class="item${x.taken?' done':''}">${chk(x.taken,'doseTog',`data-id="${x.key}" data-d="${ds}"`,x.m.name)}<div class="grow"><span class="t">${esc(x.m.name)}</span><br><span class="muted">${esc([x.m.dose,x.m.meal].filter(Boolean).join(' · '))}</span></div><span class="pill ${!x.taken&&ds===today()&&toMin(x.t)<n?'bad':''}">${tfmt(x.t)}</span></div>`).join('')+'</div>':'<p class="muted">No doses on this day.</p>'};

/* ---------- agenda: everything that has a time today ---------- */
function agenda(ds){
  const s=S.settings,a=[],dow=parse(ds).getDay();
  S.reminders.forEach(r=>{if(r.on===0||!r.time)return;
    const ok=r.repeat==='Every day'||(r.repeat==='Once'&&r.date===ds)||(r.repeat==='Sun to Thu'&&dow<5)||(r.repeat==='Every week'&&+r.day===dow);
    if(ok)a.push({t:r.time,title:r.title,src:'Reminder',key:'r-'+r.id})});
  S.events.forEach(e=>{if(e.date===ds&&e.time)a.push({t:e.time,title:e.title,src:'Event',key:'e-'+e.id})});
  if(s.nPrayer&&!s.deenOff){const t=ptimes(ds);PR.forEach(p=>a.push({t:t[p[0]],title:p[1]+' prayer time',src:'Prayer',key:'p-'+p[0]}))}
  const ep=activeEp();
  if(ep&&s.nMeds)doses(ep,ds).forEach(x=>{if(!x.taken)a.push({t:x.t,title:'Take '+x.m.name+(x.m.dose?' ('+x.m.dose+')':''),src:'Medicine',key:'m-'+x.key})});
  if(s.nClass)S.routine.forEach(r=>{if(+r.day===dow&&r.start)a.push({t:hm(toMin(r.start)-10),title:rName(r)+' starts at '+tfmt(r.start)+(r.room?' in '+r.room:''),src:'Class',key:'c-'+r.id})});
  if(s.nSleep&&s.sleepBed)a.push({t:hm(toMin(s.sleepBed)-30),title:'Wind down. Bedtime is '+tfmt(s.sleepBed),src:'Sleep',key:'s-bed'});
  if(+s.nWater>0&&(S.water[ds]||0)<s.waterGoal)for(let m=480;m<=1320;m+=+s.nWater)a.push({t:hm(m),title:'Drink a glass of water',src:'Water',key:'w-'+m});
  return a.sort((x,y)=>x.t<y.t?-1:1);
}
let fired={};
try{const o=JSON.parse(localStorage.getItem('daybook.fired')||'{}');if(o.d===today())fired=o.k||{}}catch(e){}
let AC=null;
function beep(){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();[0,.28].forEach(o=>{const os=AC.createOscillator(),g=AC.createGain();os.frequency.value=o?1040:780;os.connect(g);g.connect(AC.destination);g.gain.setValueAtTime(.25,AC.currentTime+o);g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+o+.22);os.start(AC.currentTime+o);os.stop(AC.currentTime+o+.24)})}catch(e){}}
function toast(x){
  const box=$('#toasts');if(!box)return;
  const el=document.createElement('div');el.className='toast';
  el.innerHTML=`<div class="grow"><b>${esc(x.title)}</b><span>${esc(x.src)} · ${tfmt(x.t)}</span></div><button class="btn sm" data-a="toastOk">OK</button>`;
  box.appendChild(el);beep();
  try{if(window.Notification&&Notification.permission==='granted')new Notification(x.title,{body:x.src+' · '+tfmt(x.t)})}catch(e){}
}
function tick(){
  const n=nowMin();let hit=false;
  agenda(today()).forEach(x=>{const m=toMin(x.t);if(m<=n&&n-m<=15&&!fired[x.key]){fired[x.key]=1;hit=true;toast(x)}});
  if(hit)try{localStorage.setItem('daybook.fired',JSON.stringify({d:today(),k:fired}))}catch(e){}
}
setInterval(tick,20000);setTimeout(tick,3000);

/* ---------- day score + history ---------- */
function dayParts(ds){
  const pl=S.prayers[ds]||{},hl=S.habitLog[ds]||{},ep=S.sick.map(fixEp).find(e=>e.taken[ds]);
  return{pr:PR.filter(p=>pl[p[0]]).length,water:S.water[ds]||0,hab:S.habits.filter(h=>hl[h.id]).length,
    done:S.tasks.filter(t=>t.done&&t.doneAt===ds),open:ds===today()?S.tasks.filter(t=>!t.done&&t.due&&t.due<=ds).length:0,
    focus:S.focus.filter(f=>f.date===ds).reduce((a,f)=>a+f.min,0),spent:S.money.filter(m=>m.date===ds&&m.type!=='in').reduce((a,m)=>a+m.amount,0),
    meals:S.meals.filter(m=>m.date===ds),sleep:S.sleep.find(l=>l.date===ds),acts:S.acts.filter(a=>a.date===ds),
    quran:(S.quran.log||{})[ds]||0,meds:ep?Object.keys(ep.taken[ds]).length:0};
}
function dayScore(ds){
  const p=dayParts(ds),a=[p.pr/5,Math.min(1,p.water/S.settings.waterGoal)];
  if(S.habits.length)a.push(p.hab/S.habits.length);
  if(p.done.length+p.open)a.push(p.done.length/(p.done.length+p.open));
  return Math.round(a.reduce((x,y)=>x+y,0)/a.length*100);
}

/* ---------- TODAY additions ---------- */
EXT.todayTop=()=>{
  const t=today(),sc=dayScore(t),np=nextPrayer(),pl=S.prayers[t]||{},ep=activeEp(),n=nowMin();
  const up=agenda(t).filter(x=>toMin(x.t)>=n).slice(0,4);
  let o=`<div class="card"><div class="row"><div class="ring" style="--p:${sc}"><span>${sc}%</span></div><div class="grow"><h3>Today’s score</h3><p class="muted">Prayers, water, habits and tasks together. ${sc>=80?'A strong day.':sc>=40?'Keep going.':'Start with one small thing.'}</p></div></div></div>`;
  o+=`<div class="card c-leaf"><div class="row between"><h3>Next: ${np.name}</h3><span class="pill">${tfmt(np.t)} · in ${dur(np.mins)}</span></div><div class="prow">${PR.map(p=>`<div>${chk(pl[p[0]],'prTog',`data-id="${p[0]}" data-d="${t}"`,p[1])}<span>${p[1]}</span></div>`).join('')}</div></div>`;
  if(ep)o+=`<div class="card c-tomato">${head('Medicine today',`<button class="btn sm" data-a="go" data-tab="life" data-k="life" data-v="health">Open</button>`)}<p class="muted">${esc(ep.name)}</p>${doseList(ep,t)}</div>`;
  if(up.length)o+=`<div class="card">${head('Up next',`<button class="btn sm" data-a="go" data-tab="more" data-k="more" data-v="reminders">All</button>`)}<div class="list">${up.map(x=>`<div class="item"><span class="pill">${tfmt(x.t)}</span><span class="t grow">${esc(x.title)}</span></div>`).join('')}</div></div>`;
  return o;
};

/* ---------- DEEN ---------- */
const SUR="Al-Fatihah:7|Al-Baqarah:286|Ali 'Imran:200|An-Nisa:176|Al-Ma'idah:120|Al-An'am:165|Al-A'raf:206|Al-Anfal:75|At-Tawbah:129|Yunus:109|Hud:123|Yusuf:111|Ar-Ra'd:43|Ibrahim:52|Al-Hijr:99|An-Nahl:128|Al-Isra:111|Al-Kahf:110|Maryam:98|Ta-Ha:135|Al-Anbiya:112|Al-Hajj:78|Al-Mu'minun:118|An-Nur:64|Al-Furqan:77|Ash-Shu'ara:227|An-Naml:93|Al-Qasas:88|Al-'Ankabut:69|Ar-Rum:60|Luqman:34|As-Sajdah:30|Al-Ahzab:73|Saba:54|Fatir:45|Ya-Sin:83|As-Saffat:182|Sad:88|Az-Zumar:75|Ghafir:85|Fussilat:54|Ash-Shura:53|Az-Zukhruf:89|Ad-Dukhan:59|Al-Jathiyah:37|Al-Ahqaf:35|Muhammad:38|Al-Fath:29|Al-Hujurat:18|Qaf:45|Adh-Dhariyat:60|At-Tur:49|An-Najm:62|Al-Qamar:55|Ar-Rahman:78|Al-Waqi'ah:96|Al-Hadid:29|Al-Mujadila:22|Al-Hashr:24|Al-Mumtahanah:13|As-Saff:14|Al-Jumu'ah:11|Al-Munafiqun:11|At-Taghabun:18|At-Talaq:12|At-Tahrim:12|Al-Mulk:30|Al-Qalam:52|Al-Haqqah:52|Al-Ma'arij:44|Nuh:28|Al-Jinn:28|Al-Muzzammil:20|Al-Muddaththir:56|Al-Qiyamah:40|Al-Insan:31|Al-Mursalat:50|An-Naba:40|An-Nazi'at:46|'Abasa:42|At-Takwir:29|Al-Infitar:19|Al-Mutaffifin:36|Al-Inshiqaq:25|Al-Buruj:22|At-Tariq:17|Al-A'la:19|Al-Ghashiyah:26|Al-Fajr:30|Al-Balad:20|Ash-Shams:15|Al-Layl:21|Ad-Duha:11|Ash-Sharh:8|At-Tin:8|Al-'Alaq:19|Al-Qadr:5|Al-Bayyinah:8|Az-Zalzalah:8|Al-'Adiyat:11|Al-Qari'ah:11|At-Takathur:8|Al-'Asr:3|Al-Humazah:9|Al-Fil:5|Quraysh:4|Al-Ma'un:7|Al-Kawthar:3|Al-Kafirun:6|An-Nasr:3|Al-Masad:5|Al-Ikhlas:4|Al-Falaq:5|An-Nas:6".split('|').map(x=>{const a=x.split(':');return[a[0],+a[1]]});
const QN=()=>{const q=S.quran;q.done=q.done||{};q.log=q.log||{};return q};
const DUA=[
 {id:'kursi',g:'Morning and evening',t:'Ayatul Kursi',w:'Morning, evening, after each prayer and before sleep',n:1,ref:'Quran 2:255',q:'2/255'},
 {id:'3qul',g:'Morning and evening',t:'Surah Al-Ikhlas, Al-Falaq and An-Nas',w:'Three times each, morning and evening',n:3,ref:'Quran 112 to 114',q:'112'},
 {id:'sayyid',g:'Morning and evening',t:'Sayyidul Istighfar',w:'Once in the morning and once in the evening',n:1,ar:'اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت، أعوذ بك من شر ما صنعت، أبوء لك بنعمتك علي، وأبوء لك بذنبي فاغفر لي، فإنه لا يغفر الذنوب إلا أنت',m:'O Allah, You are my Lord. There is no god but You. You created me and I am Your servant, and I keep Your covenant and promise as best I can. I seek refuge in You from the evil I have done. I acknowledge Your favour upon me and I acknowledge my sin, so forgive me, for none forgives sins but You.',ref:'Bukhari 6306'},
 {id:'bism3',g:'Morning and evening',t:'Protection from every harm',w:'Three times, morning and evening',n:3,ar:'بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم',m:'In the name of Allah, with whose name nothing on earth or in the heavens can cause harm. He is the All-Hearing, the All-Knowing.',ref:'Abu Dawud 5088'},
 {id:'hasbi',g:'Morning and evening',t:'Hasbiyallah',w:'Seven times, morning and evening',n:7,ar:'حسبي الله لا إله إلا هو عليه توكلت وهو رب العرش العظيم',m:'Allah is enough for me. There is no god but Him. In Him I put my trust, and He is the Lord of the mighty Throne.',ref:'Quran 9:129, Abu Dawud 5081'},
 {id:'sbh',g:'Morning and evening',t:'SubhanAllahi wa bihamdihi',w:'100 times in the day',n:100,ar:'سبحان الله وبحمده',m:'Glory and praise be to Allah.',ref:'Bukhari 6405'},
 {id:'tahlil',g:'Morning and evening',t:'La ilaha illallahu wahdahu',w:'100 times in the day',n:100,ar:'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير',m:'There is no god but Allah alone, with no partner. His is the kingdom and His is the praise, and He has power over all things.',ref:'Bukhari 3293'},
 {id:'salawat',g:'Morning and evening',t:'Durood on the Prophet ﷺ',w:'Ten times, morning and evening',n:10,ar:'اللهم صل وسلم على نبينا محمد',m:'O Allah, send blessings and peace upon our Prophet Muhammad.',ref:'Send blessings often, above all on Friday'},
 {id:'istigh',g:'After each prayer',t:'Astaghfirullah',w:'Three times after every fard prayer',n:15,ar:'أستغفر الله',m:'I ask Allah for forgiveness.',ref:'Muslim 591'},
 {id:'tasbih',g:'After each prayer',t:'Tasbih after prayer',w:'33, 33 and 34 after every fard prayer. Tap once per prayer.',n:5,ar:'سبحان الله (33) · الحمد لله (33) · الله أكبر (34)',m:'Glory be to Allah. All praise is for Allah. Allah is the Greatest.',ref:'Muslim 596'},
 {id:'ainni',g:'After each prayer',t:'Help me remember You',w:'After every prayer',n:5,ar:'اللهم أعني على ذكرك وشكرك وحسن عبادتك',m:'O Allah, help me to remember You, to thank You, and to worship You well.',ref:'Abu Dawud 1522'},
 {id:'wake',g:'Through the day',t:'On waking up',w:'When you wake',n:1,ar:'الحمد لله الذي أحيانا بعد ما أماتنا وإليه النشور',m:'All praise is for Allah, who gave us life after He caused us to die, and to Him is the return.',ref:'Bukhari 6312'},
 {id:'leave',g:'Through the day',t:'Leaving home',w:'Each time you go out',n:1,ar:'بسم الله توكلت على الله ولا حول ولا قوة إلا بالله',m:'In the name of Allah. I trust in Allah. There is no might and no power except with Allah.',ref:'Abu Dawud 5095'},
 {id:'eat',g:'Through the day',t:'Before and after eating',w:'Say Bismillah before eating, and this after',n:3,ar:'الحمد لله الذي أطعمني هذا ورزقنيه من غير حول مني ولا قوة',m:'All praise is for Allah, who fed me this and provided it for me with no might or power of my own.',ref:'Tirmidhi 3458'},
 {id:'ilm',g:'Through the day',t:'Before studying',w:'Before class or study',n:1,ar:'رب زدني علما · رب اشرح لي صدري ويسر لي أمري',m:'My Lord, increase me in knowledge. My Lord, open my heart for me and make my task easy for me.',ref:'Quran 20:114 and 20:25-26',q:'20/114'},
 {id:'rabbana',g:'Through the day',t:'Good in this world and the next',w:'Any time, in every dua',n:1,ar:'ربنا آتنا في الدنيا حسنة وفي الآخرة حسنة وقنا عذاب النار',m:'Our Lord, give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.',ref:'Quran 2:201',q:'2/201'},
 {id:'parents',g:'Through the day',t:'For your parents',w:'Every day',n:1,ar:'رب ارحمهما كما ربياني صغيرا',m:'My Lord, have mercy on them as they raised me when I was small.',ref:'Quran 17:24',q:'17/24'},
 {id:'baqarah',g:'Before sleep',t:'Last two ayahs of Al-Baqarah',w:'At night',n:1,ref:'Quran 2:285-286',q:'2/285'},
 {id:'mulk',g:'Before sleep',t:'Surah Al-Mulk',w:'Every night before sleep',n:1,ref:'Quran 67, Tirmidhi 2891',q:'67'},
 {id:'sleep',g:'Before sleep',t:'Going to sleep',w:'When you lie down',n:1,ar:'باسمك اللهم أموت وأحيا',m:'In Your name, O Allah, I die and I live.',ref:'Bukhari 6324'}
];
const TZP=['SubhanAllah','Alhamdulillah','Allahu Akbar','La ilaha illallah','Astaghfirullah','Durood'];
const allDuas=()=>DUA.concat(S.duas.map(d=>({id:d.id,g:'My duas',t:d.title,w:d.when,n:Math.max(1,+d.n||1),ar:d.text,m:d.meaning,mine:true})));
function vDeen(){
  const t=today(),s=S.settings;
  let o=sub('deen',SUB.deen);
  if(ui.deen==='prayer'){
    const pt=ptimes(t),np=nextPrayer(),pl=S.prayers[t]||{},d7=last7(),hj=hijri();
    o+=`<div class="card c-leaf"><div class="row between"><div><h2>Prayer times</h2><p class="muted">${esc(s.city)} · ${s.asr} Asr${hj?' · '+hj:''}</p></div><button class="btn sm" data-a="setDeen">Change</button></div>
      <div class="ptime"><b>Sunrise</b><span>${tfmt(pt.sunrise)}</span><span style="width:28px"></span></div>
      ${PR.map(p=>`<div class="ptime${np.name===p[1]&&np.mins<1440&&toMin(pt[p[0]])>nowMin()?' next':''}"><b>${p[1]}</b><span>${tfmt(pt[p[0]])}</span>${chk(pl[p[0]],'prTog',`data-id="${p[0]}" data-d="${t}"`,p[1]+' prayed')}</div>`).join('')}
      <p class="muted">Next is ${np.name} in ${dur(np.mins)}. Times are calculated for your city and can differ from your mosque by a minute or two.</p></div>`;
    o+=`<div class="card">${head('This week',`<span class="pill">${d7.reduce((a,x)=>a+PR.filter(p=>(S.prayers[x]||{})[p[0]]).length,0)} / 35</span>`)}<div class="pgrid"><span></span>${d7.map(x=>`<span>${DAYS[parse(x).getDay()][0]}${parse(x).getDate()}</span>`).join('')}
      ${PR.map(p=>`<b>${p[1]}</b>`+d7.map(x=>`<button class="${(S.prayers[x]||{})[p[0]]?'on':''}" data-a="prTog" data-id="${p[0]}" data-d="${x}" aria-label="${p[1]} on ${fmt(x)}"></button>`).join('')).join('')}</div><p class="muted">Tap a box to mark a prayer you offered.</p></div>`;
    const fm=Object.keys(S.fasts).filter(k=>k.slice(0,7)===t.slice(0,7)).length;
    o+=`<div class="grid"><div class="card"><h3>Qaza prayers</h3><div class="big">${+s.qaza||0}</div><p class="muted">Missed prayers still to make up</p><div class="row"><button class="btn sm" data-a="qaza" data-n="-1" aria-label="One made up">−</button><button class="btn sm" data-a="qaza" data-n="1" aria-label="Add one missed">+</button></div></div>
      <div class="card"><h3>Fasting</h3><div class="big">${fm}<small> this month</small></div><div class="row">${chk(S.fasts[t],'fastTog','','Fasting today')}<span class="muted">I am fasting today</span></div></div></div>
      <div class="card"><h3>Qibla</h3><p>About <b>${qibla()}°</b> from north, measured clockwise. From Bangladesh that is almost due west, turned slightly to the north.</p></div>`;
  }
  if(ui.deen==='quran'){
    const q=QN(),read=SUR.reduce((a,x,i)=>a+(q.done[i+1]?x[1]:0),0),d7=last7(),td=q.log[t]||0,mk=q.mark;
    o+=`<div class="card c-leaf"><div class="row between"><h2>Quran</h2><span class="pill">${Object.keys(q.done).length} / 114 surahs</span></div><div class="big">${Math.round(read/6236*100)}%<small> of 6,236 ayahs</small></div><div class="bar"><i style="width:${read/6236*100}%"></i></div>
      ${mk?`<p>Bookmark: <b>${esc(SUR[mk.s-1][0])}</b>, ayah ${mk.a}</p><div class="row wrap"><a class="btn sm" href="https://quran.com/${mk.s}/${mk.a}" target="_blank" rel="noopener">Continue reading</a><button class="btn sm" data-a="qMark">Move bookmark</button></div>`:`<button class="btn sm" data-a="qMark" style="align-self:flex-start">Set a bookmark</button>`}
      <p class="muted">Reading opens Quran.com, which has the Arabic with vowels, Bangla and English, and audio. The full Quran text is not stored inside this app yet.</p></div>`;
    o+=`<div class="card">${head('Daily recitation',`<span class="pill">${td} / ${s.qgoal} ayahs</span>`)}<div class="bar"><i style="width:${Math.min(100,td/Math.max(1,s.qgoal)*100)}%"></i></div><div class="row wrap"><button class="btn sm" data-a="qLog" data-n="5">+5 ayahs</button><button class="btn sm" data-a="qLog" data-n="10">+10</button><button class="btn sm" data-a="qLog" data-n="-5">−5</button><button class="btn sm" data-a="qGoal">Daily goal</button></div>${bars(d7.map(x=>q.log[x]||0),d7.map(x=>DAYS[parse(x).getDay()][0]),'leaf',+s.qgoal)}</div>`;
    o+=`<div class="card"><h2>Surahs</h2><p class="muted">Tick a surah when you finish it.</p>${SUR.map((x,i)=>`<div class="sur">${chk(q.done[i+1],'qDone',`data-id="${i+1}"`,x[0]+' finished')}<em>${i+1}</em><span class="t grow">${x[0]}<br><span class="muted">${x[1]} ayahs</span></span><a class="btn sm" href="https://quran.com/${i+1}" target="_blank" rel="noopener">Read</a></div>`).join('')}</div>`;
  }
  if(ui.deen==='duas'){
    const all=allDuas(),log=S.dhikr[t]||{},dn=all.filter(d=>(log[d.id]||0)>=d.n).length,gs=[];
    all.forEach(d=>{if(!gs.includes(d.g))gs.push(d.g)});
    o+=`<div class="card c-leaf"><div class="row between"><h2>Daily duas</h2><span class="pill">${dn} / ${all.length} today</span></div><div class="bar"><i style="width:${dn/all.length*100}%"></i></div><div class="chips">${[['bn','অর্থ বাংলায়'],['en','Meaning in English']].map(x=>`<button class="chip${S.settings.dl===x[0]?' on':''}" data-a="duaLang" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">The Arabic, pronunciation and meanings were entered by hand and have not been checked against a printed book. Please confirm the wording with Hisnul Muslim or your teacher before memorising.</p></div>`;
    o+=gs.map(g=>`<div class="card"><h2>${g}</h2>${all.filter(d=>d.g===g).map(d=>{const c=log[d.id]||0,ok=c>=d.n;return`<div class="dua"><div class="row between"><h3>${esc(d.t)}</h3>${d.mine?`<button class="btn sm" data-a="duaEdit" data-id="${d.id}" aria-label="Edit dua">${ic('edit')}</button>`:''}</div>${d.w?`<p class="muted">${esc(d.w)}</p>`:''}${d.ar?`<p class="ar" lang="ar">${esc(d.ar)}</p>`:''}${d.bp?`<p><b>উচ্চারণ:</b> ${esc(d.bp)}</p>`:''}${S.settings.dl==='en'||!d.bm?(d.m?`<p>${esc(d.m)}</p>`:''):`<p><b>অর্থ:</b> ${esc(d.bm)}</p>`}${d.ref?`<p class="muted">${esc(d.ref)}${d.q?` · <a href="https://quran.com/${d.q}" target="_blank" rel="noopener">Read on Quran.com</a>`:''}</p>`:''}
      <div class="row wrap"><span class="pill ${ok?'col c-leaf':''}">${Math.min(c,d.n)} / ${d.n}</span>${d.n>1?`<button class="btn sm" data-a="duaInc" data-id="${d.id}" data-n="${d.n}">+1</button>`:''}<button class="btn sm" data-a="duaDone" data-id="${d.id}" data-n="${d.n}">${ok?'Undo':'Done'}</button></div></div>`}).join('')}</div>`).join('');
    o+=`<div class="card"><h3>Add your own dua</h3><p class="muted">Any dua your family or teacher gave you can sit in this list.</p>${addBtn('duaAdd','Add a dua')}</div>`;
  }
  if(ui.deen==='tasbih'){
    const z=ui.tz,tot=(S.dhikr[t]||{}).tasbih||0;
    o+=`<div class="card"><div class="chips">${TZP.map((p,i)=>`<button class="chip${z.ph===i?' on':''}" data-a="tzPh" data-n="${i}">${p}</button>`).join('')}</div><button class="tz" data-a="tzTap" id="tzn" aria-label="Count ${TZP[z.ph]}">${z.n}</button><p class="muted" style="text-align:center" id="tzs">${TZP[z.ph]} · target ${z.target} · ${tot} counted today</p><div class="row wrap" style="justify-content:center">${[33,99,100].map(n=>`<button class="chip${z.target===n?' on':''}" data-a="tzTarget" data-n="${n}">${n}</button>`).join('')}<button class="btn sm" data-a="tzReset">Reset</button></div></div>`;
  }
  if(EXT[ui.deen])o+=EXT[ui.deen]();
  return o;
}
VIEWS.deen=vDeen;

/* ---------- LIFE: food, sleep, health, habit and money extras ---------- */
const SLOT=['Breakfast','Lunch','Dinner','Snack'],FTAG=['Homemade','Hall or canteen','Restaurant','Junk food'];
EXT.food=()=>{
  const ds=ui.foodDay,l=S.meals.filter(m=>m.date===ds),d7=last7(),wk=S.meals.filter(m=>d7.includes(m.date));
  const bf=d7.filter(x=>S.meals.some(m=>m.date===x&&m.meal==='Breakfast')).length;
  let o=`<div class="card">${dayNav('foodDay',ds)}<div class="list">${SLOT.map(sl=>{const ms=l.filter(m=>m.meal===sl);return`<div class="item"><div class="grow"><span class="pill col c-${ms.length?'leaf':'sun'}">${sl}</span>${ms.map(m=>`<button class="tap" data-a="mealEdit" data-id="${m.id}"><span class="t">${esc(m.text)}</span><span class="muted">${esc([m.tag,m.cost?money(m.cost):''].filter(Boolean).join(' · '))}</span></button>`).join('')||'<p class="muted">Not logged</p>'}</div><button class="btn sm" data-a="mealAdd" data-meal="${sl}" aria-label="Add ${sl}">${ic('plus')}</button></div>`}).join('')}</div></div>`;
  o+=`<div class="card c-sun"><h3>Last 7 days</h3><div class="g3">${stat(bf+' / 7','breakfasts eaten')}${stat(wk.filter(m=>m.tag==='Junk food').length,'junk meals')}${stat(money(wk.reduce((a,m)=>a+(+m.cost||0),0)),'spent on food')}</div><p class="muted">${bf<5?'Breakfast is the meal you skip most. A small one still counts.':'Good breakfast routine this week.'}</p></div>`;
  return o;
};
const sleepMin=l=>(toMin(l.wake)-toMin(l.bed)+1440)%1440;
EXT.sleep=()=>{
  const s=S.settings,d7=last7(),logs=d7.map(x=>S.sleep.find(l=>l.date===x)),got=logs.filter(Boolean),target=(toMin(s.sleepWake)-toMin(s.sleepBed)+1440)%1440;
  const avg=got.length?got.reduce((a,l)=>a+sleepMin(l),0)/got.length:0,debt=got.reduce((a,l)=>a+(target-sleepMin(l)),0),last=S.sleep.find(l=>l.date===today());
  const asleep=s.sleepStart&&Date.now()-s.sleepStart<20*36e5,w=toMin(s.sleepWake),n=nowMin();
  let o=`<div class="card c-grape"><div class="row between"><h2>Sleep</h2><button class="btn sm" data-a="setSleep">Schedule</button></div><div class="g3">${stat(last?dur(sleepMin(last)):'–','last night')}${stat(got.length?dur(Math.round(avg)):'–','7-day average')}${stat(got.length?(debt>0?dur(Math.round(debt)):'None'):'–','sleep debt')}</div>
    <p class="muted">Schedule: bed ${tfmt(s.sleepBed)}, wake ${tfmt(s.sleepWake)} (${dur(target)}).</p>
    ${asleep?`<button class="btn pri" data-a="wakeNow">I am awake. Log my sleep</button><p class="muted">Went to bed at ${tfmt(hm(new Date(s.sleepStart).getHours()*60+new Date(s.sleepStart).getMinutes()))}.</p>`:`<div class="row wrap"><button class="btn pri" data-a="bedNow">Going to bed now</button><button class="btn" data-a="slAdd">Log by hand</button></div>`}</div>`;
  o+=`<div class="card"><h2>Sleep cycles</h2><p class="muted">A cycle is about 90 minutes. Waking at the end of one feels easier. This allows 15 minutes to fall asleep.</p><div class="list"><div class="item"><span class="grow">To wake at <b>${tfmt(s.sleepWake)}</b>, go to bed at</span></div>${[6,5,4].map(c=>`<div class="item"><span class="pill col c-grape">${c} cycles · ${dur(c*90)}</span><span class="t grow" style="text-align:right">${tfmt(hm(w-c*90-15))}</span></div>`).join('')}<div class="item"><span class="grow">If you sleep now, wake at</span></div>${[4,5,6].map(c=>`<div class="item"><span class="pill">${c} cycles</span><span class="t grow" style="text-align:right">${tfmt(hm(n+c*90+15))}</span></div>`).join('')}</div></div>`;
  o+=`<div class="card">${head('Last 7 nights','<span class="muted">hours</span>')}${bars(logs.map(l=>l?Math.round(sleepMin(l)/6)/10:0),d7.map(x=>DAYS[parse(x).getDay()][0]),'grape',Math.round(target/6)/10)}${got.length?'<div class="list">'+S.sleep.slice().sort((a,b)=>a.date<b.date?1:-1).slice(0,7).map(l=>`<div class="item"><button class="tap" data-a="slEdit" data-id="${l.id}"><span class="t">${fmt(l.date)} · ${dur(sleepMin(l))}</span><span class="muted">${tfmt(l.bed)} to ${tfmt(l.wake)}${l.q?' · '+esc(l.q):''}</span></button>${ic('edit')}</div>`).join('')+'</div>':'<p class="muted">Tap “Going to bed now” tonight and “I am awake” tomorrow. Your chart builds itself.</p>'}</div>`;
  return o;
};
function epCard(ep,live){
  const t=today(),dn=diffDays(ep.end||t,ep.start)+1;
  let o=`<div class="card c-tomato"><div class="row between"><span class="pill">${live?'Sick now · day '+dn:'Recovered · '+dn+' days'}</span><button class="btn sm" data-a="epEdit" data-id="${ep.id}">${ic('edit')}Edit</button></div><h1>${esc(ep.name)}</h1><p class="muted">${esc([ep.doctor?'Dr. '+ep.doctor:'','from '+fmt(ep.start),ep.end?'to '+fmt(ep.end):''].filter(Boolean).join(' · '))}</p>${ep.notes?`<p class="note-body">${esc(ep.notes)}</p>`:''}${live?`<button class="btn" data-a="sickEnd">I have recovered</button>`:''}</div>`;
  if(live)o+=`<div class="card">${head('Doses today',`<span class="pill">${doses(ep,t).filter(x=>x.taken).length} / ${doses(ep,t).length}</span>`)}${doseList(ep,t)}<p class="muted">The app alerts you at each time while it is open. Follow your doctor’s prescription. This is a record, not medical advice.</p></div>`;
  o+=`<div class="card">${head('Prescription',live?addBtn('medAdd','Medicine'):'')}${ep.meds.length?'<div class="list">'+ep.meds.map(m=>`<div class="item"><button class="tap" data-a="medEdit" data-id="${m.id}"><span class="t">${esc(m.name)}${m.dose?' · '+esc(m.dose):''}</span><span class="muted">${esc([(m.times||[]).map(tfmt).join(', '),m.meal,m.days?m.days+' days':''].filter(Boolean).join(' · '))}</span></button>${ic('edit')}</div>`).join('')+'</div>':'<p class="muted">Add each medicine from your prescription with its dose and times.</p>'}
    ${ep.photos.length?`<div class="row wrap">${ep.photos.map(p=>`<a href="/_blob/${p}" target="_blank" rel="noopener"><img class="thumb" src="/_blob/${p}" alt="Prescription photo" style="width:84px;height:84px"></a>`).join('')}</div>`:''}
    <label class="btn sm filebtn" style="align-self:flex-start">${ic('plus')}Photo of prescription<input type="file" id="rxup" accept="image/*,application/pdf"></label>${said('rx')}</div>`;
  o+=`<div class="card">${head('Symptoms and temperature',live?addBtn('symAdd','Log'):'')}${ep.log.length?'<div class="list">'+ep.log.slice().reverse().map(x=>`<div class="item"><div class="grow"><span class="t">${esc(x.text||'Temperature')}</span><br><span class="muted">${fmt(x.date)} ${tfmt(x.time)}</span></div>${x.temp?`<span class="pill ${x.temp>=100.4?'bad':''}">${x.temp}°F</span>`:''}</div>`).join('')+'</div>':'<p class="muted">Nothing logged.</p>'}</div>`;
  return o;
}
EXT.health=()=>{
  const live=activeEp(),past=S.sick.filter(e=>!e.active).map(fixEp).sort((a,b)=>a.start<b.start?1:-1);
  if(ui.ep){const e=fixEp(S.sick.find(x=>x.id===ui.ep));if(e&&!e.active)return`<button class="btn sm" data-a="epBack" style="align-self:flex-start">${ic('back')}Health</button>`+epCard(e,false)}
  let o=live?epCard(live,true):`<div class="card c-leaf"><h2>Feeling well</h2><p class="muted">This part stays quiet until you need it. When you fall sick, tell the app. It keeps your prescription, reminds you of each dose, and saves the record for next time.</p><button class="btn pri" data-a="sickStart">I am sick</button></div>`;
  o+=`<div class="card"><h2>Health history</h2>${past.length?'<div class="list">'+past.map(e=>`<div class="item"><button class="tap" data-a="epOpen" data-id="${e.id}"><span class="t">${esc(e.name)}</span><span class="muted">${fmt(e.start)}${e.end?' to '+fmt(e.end):''} · ${e.meds.length} medicine${e.meds.length===1?'':'s'}</span></button>${ic('next')}</div>`).join('')+'</div>':'<p class="muted">Past illnesses and their prescriptions will be listed here.</p>'}</div>`;
  return o;
};
EXT.habits=()=>{
  if(!S.habits.length)return'';
  const d30=[];for(let i=29;i>=0;i--)d30.push(addDays(today(),-i));
  return`<div class="card"><h2>Last 30 days</h2>${S.habits.map(h=>{const n=d30.filter(x=>(S.habitLog[x]||{})[h.id]).length;let best=0,run=0;for(let i=89;i>=0;i--){if((S.habitLog[addDays(today(),-i)]||{})[h.id]){run++;best=Math.max(best,run)}else run=0}
    const wk=last7().filter(x=>(S.habitLog[x]||{})[h.id]).length,g=+h.goal||7;
    return`<div><div class="row between"><span class="t">${esc(h.name)}${h.kind==='Quit'?' <span class="pill bad">Quit</span>':''}</span><span class="muted">${Math.round(n/30*100)}% · best ${best} days</span></div><div class="bar"><i style="width:${n/30*100}%"></i></div><p class="muted">This week ${wk} of ${g} days${wk>=g?'. Goal met.':''}</p></div>`}).join('')}<p class="muted">For a habit you want to quit, tick the days you stayed away from it.</p></div>`;
};
EXT.money=()=>{
  const t=today(),cur=ui.month===t.slice(0,7),l=S.money.filter(m=>m.date.slice(0,7)===ui.month&&m.type!=='in'),out=l.reduce((a,m)=>a+m.amount,0);
  const mo=ui.month.split('-').map(Number),dim=new Date(mo[0],mo[1],0).getDate(),day=cur?new Date().getDate():dim;
  const pm=ymd(new Date(mo[0],mo[1]-2,1)).slice(0,7),prev=S.money.filter(m=>m.date.slice(0,7)===pm&&m.type!=='in').reduce((a,m)=>a+m.amount,0);
  let o=`<div class="card c-sun"><h3>Insights</h3><div class="g3">${stat(money(out/Math.max(1,day)),'per day')}${stat(cur?money(out/Math.max(1,day)*dim):money(out),cur?'month forecast':'month total')}${stat(prev?(out>=prev?'+':'−')+Math.abs(Math.round((out-prev)/prev*100))+'%':'–','vs last month')}</div>${cur&&S.settings.budget?`<p class="muted">${out/Math.max(1,day)*dim>S.settings.budget?'At this pace you will pass your budget. Safe to spend '+money(Math.max(0,(S.settings.budget-out)/Math.max(1,dim-day+1)))+' a day from now.':'You are on pace to stay inside your budget.'}</p>`:''}</div>`;
  o+=`<div class="card">${head('Savings goals',addBtn('goalAdd','Goal'))}${S.goals.length?S.goals.map(g=>`<div><div class="row between"><button class="tap" data-a="goalEdit" data-id="${g.id}"><span class="t">${esc(g.name)}</span><span class="muted">${money(g.saved||0)} of ${money(g.target)}</span></button><button class="btn sm" data-a="goalPut" data-id="${g.id}">${ic('plus')}Save</button></div><div class="bar"><i style="width:${Math.min(100,(g.saved||0)/Math.max(1,g.target)*100)}%"></i></div></div>`).join(''):'<p class="muted">Saving for a laptop, a trip or the semester fee? Track it here.</p>'}</div>`;
  const open=S.debts.filter(d=>!d.settled),get=open.filter(d=>d.dir==='I lent').reduce((a,d)=>a+d.amount,0),owe=open.filter(d=>d.dir!=='I lent').reduce((a,d)=>a+d.amount,0);
  o+=`<div class="card">${head('Lent and borrowed',addBtn('debtAdd','Add'))}<div class="row"><span class="pill col c-leaf">To get back ${money(get)}</span><span class="pill col c-tomato">To pay ${money(owe)}</span></div>${S.debts.length?'<div class="list">'+S.debts.map(d=>`<div class="item${d.settled?' done':''}">${chk(d.settled,'debtTog',`data-id="${d.id}"`,'Settled')}<button class="tap" data-a="debtEdit" data-id="${d.id}"><span class="t">${esc(d.person)} · ${money(d.amount)}</span><span class="muted">${esc(d.dir)}${d.date?' · '+fmt(d.date):''}${d.note?' · '+esc(d.note):''}</span></button></div>`).join('')+'</div>':'<p class="muted">Note who owes you and whom you owe, so nothing is forgotten.</p>'}</div>`;
  return o;
};

/* ---------- STUDY: files and PDF tools ---------- */
const FT={pdf:'application/pdf',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',gif:'image/gif',webp:'image/webp',txt:'text/plain',md:'text/markdown',csv:'text/csv',mp4:'video/mp4'};
const ext=n=>(String(n).split('.').pop()||'').toLowerCase();
async function putFilesOld(list,msgKey,each){
  if(!AS){say(msgKey,'File storage is not available in this view. Open the app from your account.');return}
  const bad=[];
  for(const f of list){
    const type=FT[ext(f.name)];
    if(!type){bad.push(f.name+' (this type cannot be stored. Save it as PDF first)');continue}
    if(f.size>20*1048576){bad.push(f.name+' (over 20 MB)');continue}
    say(msgKey,'Uploading '+f.name+'…');
    try{const r=await AS.upload(f,{type:type});each(r,f)}
    catch(e){bad.push(f.name+' ('+(e&&e.code==='quota_or_state'?'storage is full':'upload failed')+')')}
  }
  say(msgKey,bad.length?'Not saved: '+bad.join('; '):'Saved.');
}
const fileRowsOld=l=>'<div class="list">'+l.map(f=>`<div class="item linkrow">${/^image\//.test(f.type)?`<img class="thumb" src="/_blob/${f.asset}" alt="">`:`<span class="thumb">${esc(ext(f.name))}</span>`}<div class="grow"><a href="/_blob/${f.asset}" target="_blank" rel="noopener">${esc(f.name)}</a><small>${fsz(f.size)} · ${fmt(f.added)}</small></div><button class="btn sm" data-a="fSave" data-id="${f.id}">Save</button><button class="btn sm" data-a="fEdit" data-id="${f.id}" aria-label="Edit file">${ic('edit')}</button></div>`).join('')+'</div>';
const upBtn=cid=>`<label class="btn sm pri filebtn">${ic('plus')}Upload<input type="file" id="fup" multiple data-course="${cid}" accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.txt,.md,.csv,.mp4"></label>`;
EXT.files=()=>{
  const g={};S.files.forEach(f=>{const k=cname(f.courseId)||'General';(g[k]=g[k]||[]).push(f)});
  let o=`<div class="card"><div class="row between"><h2>Study files</h2>${upBtn('')}</div><label>Put new uploads in<select id="fcourse">${courseOpts().map(x=>`<option value="${x[0]}">${esc(x[1]==='No course'?'General':x[1])}</option>`).join('')}</select></label>${said('files')}<p class="muted">PDF, JPG, PNG, GIF, WEBP, text and MP4, up to 20 MB each. Word and PowerPoint files cannot be stored as they are: export them as PDF first, or save their Drive link in Links. Files belong to this app, so anyone you share the app with could open them.</p></div>`;
  o+=Object.keys(g).sort().map(k=>`<div class="card"><h3>${esc(k)}</h3>${fileRows(g[k])}</div>`).join('')||`<div class="card">${empty('No files yet','Lecture slides as PDF, photos of the board, scanned notes. Each file can belong to a course.')}</div>`;
  return o;
};
EXT.courseFiles=cid=>{const l=S.files.filter(f=>f.courseId===cid);return`<div class="card"><div class="row between"><h2>Files</h2>${upBtn(cid)}</div>${said('files')}${l.length?fileRows(l):'<p class="muted">Slides, scans and photos for this course.</p>'}</div>`};
let toolOut=null;
function loadPdf(){return new Promise((res,rej)=>{if(window.PDFLib)return res(window.PDFLib);const s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js';s.onload=()=>res(window.PDFLib);s.onerror=()=>rej(new Error('offline'));document.head.appendChild(s)})}
function pageList(txt,max){
  const out=[];
  for(const part of String(txt).split(',')){const m=part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);if(!m)return null;const a=+m[1],b=m[2]?+m[2]:a;if(a<1||b>max||a>b)return null;for(let i=a;i<=b;i++)out.push(i-1)}
  return out.length?out:null;
}
async function runTool(kind){
  const inp=document.getElementById('t_'+kind),files=inp?[...inp.files]:[];
  if(!files.length){say('tool','Choose the file first.');return}
  say('tool','Working…');toolOut=null;
  try{
    const P=await loadPdf(),out=await P.PDFDocument.create();let name='daybook.pdf';
    if(kind==='merge'){
      if(files.length<2){say('tool','Choose two or more PDF files to merge.');return}
      for(const f of files){const src=await P.PDFDocument.load(await f.arrayBuffer());(await out.copyPages(src,src.getPageIndices())).forEach(p=>out.addPage(p))}
      name='merged.pdf';
    }else if(kind==='split'){
      const src=await P.PDFDocument.load(await files[0].arrayBuffer()),n=src.getPageCount(),idx=pageList(document.getElementById('t_pages').value,n);
      if(!idx){say('tool','This PDF has '+n+' pages. Write pages like 1-3, 5.');return}
      (await out.copyPages(src,idx)).forEach(p=>out.addPage(p));name=files[0].name.replace(/\.pdf$/i,'')+'-pages.pdf';
    }else{
      for(const f of files){
        const e=ext(f.name),buf=await f.arrayBuffer(),img=e==='png'?await out.embedPng(buf):(e==='jpg'||e==='jpeg')?await out.embedJpg(buf):null;
        if(!img){say('tool',f.name+' is not a JPG or PNG image.');return}
        const pg=out.addPage([595,842]),k=Math.min(547/img.width,794/img.height,1),w=img.width*k,h=img.height*k;
        pg.drawImage(img,{x:(595-w)/2,y:(842-h)/2,width:w,height:h});
      }
      name='images.pdf';
    }
    const bytes=await out.save();
    toolOut={name:name,blob:new Blob([bytes],{type:'application/pdf'}),pages:out.getPageCount()};
    say('tool','Ready: '+name+', '+toolOut.pages+' page'+(toolOut.pages===1?'':'s')+', '+fsz(bytes.length)+'.');
  }catch(e){say('tool',e&&e.message==='offline'?'The PDF engine could not load. Check your internet and try again.':'That file could not be read. It may be password protected or damaged.')}
}
EXT.tools=()=>`<div class="card"><h2>PDF tools</h2><p class="muted">Everything runs on your phone. Your files are not sent anywhere.</p>
  <div class="tool"><h3>Merge PDFs</h3><input type="file" id="t_merge" accept="application/pdf" multiple aria-label="PDF files to merge"><button class="btn sm" data-a="tool" data-k="merge" style="align-self:flex-start">Merge into one</button></div>
  <div class="tool"><h3>Split a PDF</h3><input type="file" id="t_split" accept="application/pdf" aria-label="PDF to split"><label>Pages to keep<input id="t_pages" placeholder="1-3, 5" inputmode="text"></label><button class="btn sm" data-a="tool" data-k="split" style="align-self:flex-start">Extract pages</button></div>
  <div class="tool"><h3>Photos to PDF</h3><input type="file" id="t_img" accept="image/jpeg,image/png" multiple aria-label="Images to turn into a PDF"><button class="btn sm" data-a="tool" data-k="img" style="align-self:flex-start">Make PDF</button></div>
  ${said('tool')}${toolOut?`<div class="row wrap"><button class="btn pri" data-a="toolSave">Save to phone</button><button class="btn" data-a="toolKeep">Keep in Files</button></div>`:''}</div>
  <div class="card"><h3>Word or PowerPoint to PDF</h3><p class="muted">A phone browser cannot convert these files reliably, so this app does not pretend to. Use “Save as PDF” in Word, Docs or PowerPoint.</p></div>
  <div class="card"><h3>Word counter</h3><textarea id="wc" data-c="wc" placeholder="Paste your assignment text" aria-label="Text to count"></textarea><p class="muted" id="wcout">0 words · 0 characters</p></div>`;

/* ---------- MORE: reminders, mail, history, storage ---------- */
const flag=(k,label)=>`<div class="item">${chk(+S.settings[k],'flag',`data-id="${k}"`,label)}<span class="t grow">${label}</span></div>`;
EXT.reminders=()=>{
  const t=today(),ag=agenda(t),n=nowMin(),s=S.settings;
  let o=`<div class="card c-sun"><h2>Alerts</h2><p class="muted">An alert pops up with a sound at the right time while this app is open on your screen. A web app cannot wake a closed phone, so for must-not-miss times also set a phone alarm.</p><div class="row wrap"><button class="btn sm" data-a="remTest">Test alert</button><button class="btn sm" data-a="nAsk">Try phone notifications</button></div>${said('notif')}</div>`;
  o+=`<div class="card">${head('Today',`<span class="pill">${ag.filter(x=>toMin(x.t)>=n).length} left</span>`)}${ag.length?'<div class="list">'+ag.map(x=>`<div class="item${toMin(x.t)<n?' past':''}"><span class="pill">${tfmt(x.t)}</span><span class="t grow">${esc(x.title)}</span><span class="muted">${x.src}</span></div>`).join('')+'</div>':'<p class="muted">Nothing timed today.</p>'}</div>`;
  o+=`<div class="card">${head('My reminders',addBtn('remAdd','Reminder'))}${S.reminders.length?'<div class="list">'+S.reminders.map(r=>`<div class="item">${chk(r.on!==0,'remTog',`data-id="${r.id}"`,'On')}<button class="tap" data-a="remEdit" data-id="${r.id}"><span class="t">${esc(r.title)}</span><span class="muted">${tfmt(r.time)} · ${esc(r.repeat)}${r.repeat==='Once'&&r.date?' · '+fmt(r.date):''}${r.repeat==='Every week'?' · '+DAYSL[+r.day||0]:''}</span></button></div>`).join('')+'</div>':'<p class="muted">Call home, take vitamins, submit attendance. Anything with a time.</p>'}</div>`;
  o+=`<div class="card"><h2>Automatic alerts</h2><div class="list">${flag('nPrayer','Prayer times')}${flag('nMeds','Medicine doses when I am sick')}${flag('nClass','10 minutes before each class')}${flag('nSleep','30 minutes before bedtime')}</div><p class="muted">Water nudges</p><div class="chips">${[[0,'Off'],[60,'Every hour'],[90,'Every 90 min'],[120,'Every 2 hours']].map(x=>`<button class="chip${+s.nWater===x[0]?' on':''}" data-a="nWater" data-n="${x[0]}">${x[1]}</button>`).join('')}</div></div>`;
  return o;
};
const gm=o=>'https://mail.google.com/mail/?view=cm&fs=1'+Object.keys(o).map(k=>'&'+k+'='+encodeURIComponent(o[k])).join('');
const TPL=[
 ['Leave application','Application for leave of absence','Dear Sir/Madam,\n\nI am [Name], a student of your course. I was unable to attend class on [date] because [reason]. I request you to kindly consider my absence.\n\nSincerely,\n[Name]'],
 ['Assignment submission','Submission of assignment','Dear Sir/Madam,\n\nPlease find my assignment attached for [course]. Kindly let me know if anything is missing.\n\nRegards,\n[Name]'],
 ['Ask for an appointment','Request for an appointment','Dear Sir/Madam,\n\nI would like to meet you to discuss [topic]. Could you please let me know a suitable time during your office hours?\n\nThank you,\n[Name]'],
 ['Ask for an extension','Request for deadline extension','Dear Sir/Madam,\n\nI am writing to request a short extension for [assignment], due on [date], because [reason]. I can submit it by [new date].\n\nThank you for considering this.\n[Name]']
];
EXT.mail=()=>{
  const s=S.settings,nm=s.name||'[Name]';
  let o=`<div class="card c-pink"><div class="row between"><h2>Mail</h2><button class="btn sm" data-a="setMail">${s.email?'Change':'Add my email'}</button></div><p>${s.email?esc(s.email):'No email linked yet.'}</p><div class="row wrap"><a class="btn sm" href="https://mail.google.com/mail/u/${s.email?'?authuser='+encodeURIComponent(s.email):''}" target="_blank" rel="noopener">Open inbox</a><a class="btn sm" href="${gm({})}" target="_blank" rel="noopener">Write a mail</a></div><p class="muted">These open Gmail. Reading your inbox inside this app needs Gmail connected to your account first.</p></div>`;
  o+=`<div class="card">${head('People I mail',addBtn('ctAdd','Contact'))}${S.contacts.length?'<div class="list">'+S.contacts.map(c=>`<div class="item linkrow"><div class="grow"><a href="${gm({to:c.email})}" target="_blank" rel="noopener">${esc(c.name)}</a><small>${esc([c.role,c.email].filter(Boolean).join(' · '))}</small></div><button class="btn sm" data-a="ctEdit" data-id="${c.id}" aria-label="Edit contact">${ic('edit')}</button></div>`).join('')+'</div>':'<p class="muted">Teachers, supervisor, department office, group members. One tap opens a mail to them.</p>'}</div>`;
  o+=`<div class="card"><h2>Ready-made mails</h2><p class="muted">Opens a draft with the subject and text filled in.</p><div class="list">${TPL.map(x=>`<div class="item linkrow"><div class="grow"><a href="${gm({su:x[1],body:x[2].replace(/\[Name\]/g,nm)})}" target="_blank" rel="noopener">${x[0]}</a><small>${x[1]}</small></div>${ic('next')}</div>`).join('')}</div></div>`;
  return o;
};
EXT.history=()=>{
  const ds=ui.histDay,p=dayParts(ds),d14=[];for(let i=13;i>=0;i--)d14.push(addDays(today(),-i));
  const rows=[['Prayers',p.pr+' of 5'],['Water',p.water+' of '+S.settings.waterGoal+' glasses'],['Habits',S.habits.length?p.hab+' of '+S.habits.length:''],['Tasks finished',p.done.map(t=>t.title).join(', ')],['Study time',p.focus?dur(p.focus):''],['Quran',p.quran?p.quran+' ayahs':''],['Sleep',p.sleep?dur(sleepMin(p.sleep))+' ('+tfmt(p.sleep.bed)+' to '+tfmt(p.sleep.wake)+')':''],['Meals',p.meals.map(m=>m.meal+': '+m.text).join(', ')],['Spent',p.spent?money(p.spent):''],['Activities',p.acts.map(a=>a.text).join(', ')],['Medicine doses taken',p.meds||'']].filter(r=>r[1]!=='');
  return`<div class="card"><h2>Last 14 days</h2><p class="muted">Your daily score. Tap a day to open it.</p><div class="bars" style="gap:4px">${d14.map(x=>{const v=dayScore(x);return`<div><i class="c-${x===ds?'tomato':'leaf'}" data-a="histPick" data-d="${x}" style="height:${Math.max(4,v*.75)}%;cursor:pointer" role="button" aria-label="${fmt(x)}: ${v}%"></i><span>${parse(x).getDate()}</span></div>`}).join('')}</div></div>
    <div class="card">${dayNav('histDay',ds)}<div class="row"><div class="ring" style="--p:${dayScore(ds)}"><span>${dayScore(ds)}%</span></div><p class="muted grow">Everything you recorded on this day, from every part of the app.</p></div><div class="list">${rows.map(r=>`<div class="item"><span class="muted" style="flex:none;width:112px">${r[0]}</span><span class="t grow">${esc(r[1])}</span></div>`).join('')}</div></div>`;
};
EXT.settings=()=>{
  const c=[['Tasks',S.tasks.length],['Notes',S.notes.length],['Files',S.files.length],['Courses',S.courses.length],['Money entries',S.money.length],['Days of prayer log',Object.keys(S.prayers).length],['Sleep logs',S.sleep.length],['Health records',S.sick.length]];
  return`<div class="card"><h2>Memory</h2><p class="muted">${cloud==='on'?'Every change is saved to your account within a second and comes back whenever you open the app, on any phone. A copy also stays on this phone for quick opening.':'Cloud saving is not reachable right now, so changes are kept on this phone and sent up when the connection returns.'} Nothing is deleted unless you delete it. Past days stay in History.</p><div class="g3">${c.map(x=>stat(x[1],x[0])).join('')}</div><button class="btn sm" data-a="bFile" style="align-self:flex-start">Download backup file</button>${said('backup')}</div>`;
};

/* ---------- actions ---------- */
const epNow=()=>activeEp()||fixEp(S.sick.find(e=>e.id===ui.ep));
const medFields=()=>[['name','Medicine','text',{req:true,ph:'Napa 500'}],['dose','Dose','text',{ph:'1 tablet, 2 spoons'}],['when','When','select',{opts:Object.keys(WHEN)}],['custom','Custom times','text',{ph:'09:00, 15:00, 22:00'}],['meal','With food','select',{opts:['After food','Before food','Any time']}],['days','For how many days','number'],['start','Starting','date',R]];
const medVal=v=>{v.times=WHEN[v.when]||(String(v.custom).match(/\d{1,2}:\d{2}/g)||[]).map(x=>hm(toMin(x)));if(!v.times.length)v.times=['08:00'];return v};
const remFields=()=>[['title','Remind me to','text',R],['time','Time','time',R],['repeat','Repeat','select',{opts:['Every day','Sun to Thu','Every week','Once']}],['day','Day (for every week)','select',{opts:WEEK.map(w=>[w,DAYSL[w]])}],['date','Date (for once)','date']];
const mealFields=[['text','What did you eat?','text',R],['meal','Meal','select',{opts:SLOT}],['tag','Where from','select',{opts:FTAG}],['cost','Cost','number'],['date','Date','date',R]];
const slFields=[['date','Morning of','date',R],['bed','Went to bed','time',R],['wake','Woke up','time',R],['q','How was it?','select',{opts:['Good','Okay','Poor']}]];
const debtFields=[['person','Person','text',R],['amount','Amount','number',R],['dir','Which way','select',{opts:['I lent','I borrowed']}],['date','Date','date'],['note','Note','text']];
const _tab=A.tab,_sub=A.sub,_go=A.go;
Object.assign(A,{
  tab(d){document.body.classList.remove('dopen');_tab(d)},
  go(d){if(d.k==='study'){ui.course=null;ui.proj=null}if(d.k==='life')ui.ep=null;ui[d.k]=d.v;A.tab(d)},
  sub(d){if(d.k==='life')ui.ep=null;_sub(d)},
  drawer(){document.body.classList.add('dopen');drawDrawer()},
  drawerClose(){document.body.classList.remove('dopen')},
  toastOk(d,el){const t=el.closest('.toast');if(t)t.remove()},
  tTog(d){const t=S.tasks.find(x=>x.id===d.id);t.done=!t.done;t.doneAt=t.done?today():'';save('tasks');render()},
  hAdd(){form('New habit',[['name','Habit','text',{req:true,ph:'Sleep by 12, exercise, no phone in class'}],['kind','Type','select',{opts:['Build','Quit']}],['goal','Days per week','number']],{kind:'Build',goal:7},v=>upsert('habits',null,v))},
  hEdit(d){const h=S.habits.find(x=>x.id===d.id);form('Edit habit',[['name','Habit','text',R],['kind','Type','select',{opts:['Build','Quit']}],['goal','Days per week','number']],Object.assign({kind:'Build',goal:7},h),v=>upsert('habits',h.id,v),()=>remove('habits',h.id))},
  // deen
  prTog(d){const l=S.prayers[d.d]=S.prayers[d.d]||{};if(l[d.id])delete l[d.id];else l[d.id]=1;save('prayers');render()},
  qaza(d){S.settings.qaza=Math.max(0,(+S.settings.qaza||0)+(+d.n));save('settings');render()},
  fastTog(){const t=today();if(S.fasts[t])delete S.fasts[t];else S.fasts[t]=1;save('fasts');render()},
  setDeen(){form('Prayer settings',[['city','City','select',{opts:Object.keys(CITY).concat('Custom')}],['asr','Asr time','select',{opts:['Hanafi','Shafi']}],['lat','Latitude (custom only)','number'],['lng','Longitude (custom only)','number']],S.settings,v=>{if(CITY[v.city]){v.lat=CITY[v.city][0];v.lng=CITY[v.city][1]}Object.assign(S.settings,v);save('settings')})},
  qDone(d){const q=QN();if(q.done[d.id])delete q.done[d.id];else q.done[d.id]=1;save('quran');render()},
  qLog(d){const q=QN(),t=today();q.log[t]=Math.max(0,(q.log[t]||0)+(+d.n));save('quran');render()},
  qGoal(){form('Daily Quran goal',[['qgoal','Ayahs per day','number',R]],S.settings,v=>{S.settings.qgoal=Math.max(1,Math.round(v.qgoal));save('settings')})},
  qMark(){const q=QN();form('Bookmark',[['s','Surah','select',{opts:SUR.map((x,i)=>[i+1,(i+1)+'. '+x[0]])}],['a','Ayah','number',R]],q.mark||{s:1,a:1},v=>{const s=+v.s;q.mark={s:s,a:Math.min(SUR[s-1][1],Math.max(1,Math.round(v.a)))};save('quran')})},
  duaInc(d){const l=S.dhikr[today()]=S.dhikr[today()]||{};l[d.id]=Math.min(+d.n,(l[d.id]||0)+1);save('dhikr');render()},
  duaDone(d){const l=S.dhikr[today()]=S.dhikr[today()]||{};l[d.id]=(l[d.id]||0)>=+d.n?0:+d.n;save('dhikr');render()},
  duaF:[['title','Name of the dua','text',R],['text','Arabic or Bangla text','textarea'],['meaning','Meaning','text'],['when','When to recite','text'],['n','Times per day','number']],
  duaAdd(){form('New dua',A.duaF,{n:1},v=>upsert('duas',null,v))},
  duaEdit(d){const x=S.duas.find(k=>k.id===d.id);form('Edit dua',A.duaF,x,v=>upsert('duas',x.id,v),()=>remove('duas',x.id))},
  tzTap(){const z=ui.tz,t=today(),l=S.dhikr[t]=S.dhikr[t]||{};z.n++;l.tasbih=(l.tasbih||0)+1;if(z.n===z.target)beep();save('dhikr');const a=$('#tzn'),b=$('#tzs');if(a)a.textContent=z.n;if(b)b.textContent=TZP[z.ph]+' · target '+z.target+(z.n>=z.target?' reached':'')+' · '+l.tasbih+' counted today'},
  tzPh(d){ui.tz.ph=+d.n;ui.tz.n=0;render()},tzTarget(d){ui.tz.target=+d.n;render()},tzReset(){ui.tz.n=0;render()},
  // food
  foodDay(d){ui.foodDay=addDays(ui.foodDay,+d.n);render()},
  mealAdd(d){form('Log a meal',mealFields,{meal:d.meal,date:ui.foodDay,tag:'Homemade'},v=>{upsert('meals',null,v);if(v.cost>0){S.money.push({id:uid(),date:v.date,amount:v.cost,type:'out',cat:'Food',note:v.text});save('money')}})},
  mealEdit(d){const m=S.meals.find(x=>x.id===d.id);form('Edit meal',mealFields,m,v=>upsert('meals',m.id,v),()=>remove('meals',m.id))},
  // sleep
  setSleep(){form('Sleep schedule',[['sleepBed','Bedtime','time',R],['sleepWake','Wake-up time','time',R]],S.settings,v=>{Object.assign(S.settings,v);save('settings')})},
  bedNow(){S.settings.sleepStart=Date.now();save('settings');render()},
  wakeNow(){const b=new Date(S.settings.sleepStart),n=new Date();S.sleep=S.sleep.filter(l=>l.date!==today());S.sleep.push({id:uid(),date:today(),bed:pad(b.getHours())+':'+pad(b.getMinutes()),wake:pad(n.getHours())+':'+pad(n.getMinutes()),q:''});S.settings.sleepStart=0;save('sleep','settings');render()},
  slAdd(){form('Log sleep',slFields,{date:today(),bed:S.settings.sleepBed,wake:S.settings.sleepWake,q:'Good'},v=>{S.sleep=S.sleep.filter(l=>l.date!==v.date);upsert('sleep',null,v)})},
  slEdit(d){const l=S.sleep.find(x=>x.id===d.id);form('Edit sleep',slFields,l,v=>upsert('sleep',l.id,v),()=>remove('sleep',l.id))},
  // health
  sickStart(){form('I am sick',[['name','What is wrong?','text',{req:true,ph:'Fever, cold, stomach'}],['doctor','Doctor','text'],['start','Since','date',R],['notes','Notes','textarea',{ph:'Advice from the doctor, tests, next visit'}]],{start:today()},v=>{S.sick.push(Object.assign({id:uid(),active:true,meds:[],taken:{},log:[],photos:[]},v));save('sick')})},
  sickEnd(){const e=activeEp();form('Glad you are better',[['end','Recovered on','date',R]],{end:today()},v=>{e.active=false;e.end=v.end;save('sick')})},
  epEdit(d){const e=S.sick.find(x=>x.id===d.id);form('Edit record',[['name','Illness','text',R],['doctor','Doctor','text'],['start','Since','date',R],['notes','Notes','textarea']],e,v=>{Object.assign(e,v);save('sick')},()=>{remove('sick',e.id);ui.ep=null})},
  epOpen(d){ui.ep=d.id;render();window.scrollTo(0,0)},epBack(){ui.ep=null;render()},
  medAdd(){const e=epNow();form('Add medicine',medFields(),{when:'Morning and night',meal:'After food',start:today(),days:5},v=>{e.meds.push(Object.assign({id:uid()},medVal(v)));save('sick')})},
  medEdit(d){const e=epNow(),m=e.meds.find(x=>x.id===d.id);form('Edit medicine',medFields(),Object.assign({},m,m.when==='Custom times'||!m.when?{custom:(m.times||[]).join(', ')}:{}),v=>{Object.assign(m,medVal(v));save('sick')},()=>{e.meds=e.meds.filter(x=>x.id!==m.id);save('sick')})},
  doseTog(d){const e=activeEp();if(!e)return;const l=e.taken[d.d]=e.taken[d.d]||{};if(l[d.id])delete l[d.id];else l[d.id]=1;save('sick');render()},
  symAdd(){const e=epNow(),n=new Date();form('Log how you feel',[['text','Symptoms','text',{ph:'Headache, cough, weak'}],['temp','Temperature in °F','number'],['date','Date','date',R],['time','Time','time',R]],{date:today(),time:pad(n.getHours())+':'+pad(n.getMinutes())},v=>{if(!v.temp)delete v.temp;if(v.text||v.temp){e.log.push(Object.assign({id:uid()},v));save('sick')}})},
  // money
  goalF:[['name','Saving for','text',R],['target','Target amount','number',R],['saved','Saved so far','number']],
  goalAdd(){form('New savings goal',A.goalF,{},v=>upsert('goals',null,v))},
  goalEdit(d){const g=S.goals.find(x=>x.id===d.id);form('Edit goal',A.goalF,g,v=>upsert('goals',g.id,v),()=>remove('goals',g.id))},
  goalPut(d){const g=S.goals.find(x=>x.id===d.id);form('Add to '+esc(g.name),[['amt','Amount to add','number',R]],{},v=>{g.saved=(+g.saved||0)+v.amt;save('goals')})},
  debtAdd(){form('Lent or borrowed',debtFields,{dir:'I lent',date:today()},v=>upsert('debts',null,v))},
  debtEdit(d){const x=S.debts.find(k=>k.id===d.id);form('Edit',debtFields,x,v=>upsert('debts',x.id,v),()=>remove('debts',x.id))},
  debtTog(d){const x=S.debts.find(k=>k.id===d.id);x.settled=!x.settled;save('debts');render()},
  // files + tools
  fEdit(d){const f=S.files.find(x=>x.id===d.id);form('File',[['name','Name','text',R],['courseId','Course','select',{opts:courseOpts()}]],f,v=>{if(ext(v.name)!==ext(f.name))v.name+='.'+ext(f.name);upsert('files',f.id,v)},()=>{remove('files',f.id);if(AS)AS.delete(f.asset).catch(()=>{})})},
  async fSave(d){const f=S.files.find(x=>x.id===d.id);if(!DL){say('files','Saving to the phone is not available here. Tap the file name to open it.');return}try{const b=await(await fetch('/_blob/'+f.asset)).blob();await DL.save({filename:f.name,data:b});say('files','Saved '+f.name+'.')}catch(e){say('files',e&&e.code==='declined'?'Cancelled.':'Could not save that file.')}},
  tool(d){runTool(d.k)},
  async toolSave(){if(!toolOut)return;if(!DL){say('tool','Saving to the phone is not available here. Use Keep in Files.');return}try{await DL.save({filename:toolOut.name,data:toolOut.blob});say('tool','Saved '+toolOut.name+'.')}catch(e){say('tool',e&&e.code==='declined'?'Cancelled.':'Could not save the file.')}},
  toolKeep(){if(!toolOut)return;const o=toolOut;putFiles([new File([o.blob],o.name,{type:'application/pdf'})],'tool',(r,f)=>{S.files.push({id:uid(),courseId:'',name:f.name,type:'application/pdf',size:r.sizeBytes,asset:r.id,local:r.local||'',added:today()});save('files')})},
  // reminders
  remAdd(){form('New reminder',remFields(),{repeat:'Every day',day:new Date().getDay(),date:today()},v=>upsert('reminders',null,v,{on:1}))},
  remEdit(d){const r=S.reminders.find(x=>x.id===d.id);form('Edit reminder',remFields(),r,v=>upsert('reminders',r.id,v),()=>remove('reminders',r.id))},
  remTog(d){const r=S.reminders.find(x=>x.id===d.id);r.on=r.on===0?1:0;save('reminders');render()},
  remTest(){toast({title:'This is how an alert looks',src:'Test',t:hm(nowMin())})},
  flag(d){S.settings[d.id]=+S.settings[d.id]?0:1;save('settings');render()},
  nWater(d){S.settings.nWater=+d.n;save('settings');render()},
  nAsk(){const no='Phone notifications are blocked for this kind of web app. Alerts will show while the app is open.';try{if(!window.Notification){say('notif',no);return}Notification.requestPermission().then(p=>say('notif',p==='granted'?'Allowed. You will also get a notification while this page stays open in the background.':no),()=>say('notif',no))}catch(e){say('notif',no)}},
  // mail + history + backup
  setMail(){form('My email',[['email','Email address','text',{ph:'you@gmail.com'}]],S.settings,v=>{S.settings.email=v.email;save('settings')})},
  ctF:[['name','Name','text',R],['email','Email','text',R],['role','Who is this?','text',{ph:'Course teacher, supervisor, office'}]],
  ctAdd(){form('New contact',A.ctF,{},v=>upsert('contacts',null,v))},
  ctEdit(d){const c=S.contacts.find(x=>x.id===d.id);form('Edit contact',A.ctF,c,v=>upsert('contacts',c.id,v),()=>remove('contacts',c.id))},
  histDay(d){const n=addDays(ui.histDay,+d.n);if(n<=today())ui.histDay=n;render()},
  histPick(d){ui.histDay=d.d;render()},
  async bFile(){if(!DL){say('backup','Downloading is not available here. Use Copy backup below.');return}try{await DL.save({filename:'daybook-backup-'+today()+'.json',data:JSON.stringify(S)});say('backup','Backup saved.')}catch(e){say('backup',e&&e.code==='declined'?'Cancelled.':'Could not save the backup.')}}
});
document.addEventListener('change',e=>{
  const t=e.target;
  if(t.id==='fup'&&t.files.length){const sel=document.getElementById('fcourse'),cid=t.dataset.course||(sel?sel.value:'');putFiles([...t.files],'files',(r,f)=>{S.files.push({id:uid(),courseId:cid,name:f.name,type:r.contentType,size:r.sizeBytes,asset:r.id,local:r.local||'',added:today()});save('files')})}
  if(t.id==='rxup'&&t.files.length){const ep=epNow();if(ep)putFiles([...t.files],'rx',r=>{ep.photos.push(r.id);save('sick')},true)}
});
document.addEventListener('input',e=>{if(e.target.dataset.c==='wc'){const v=e.target.value,w=(v.trim().match(/\S+/g)||[]).length,o=$('#wcout');if(o)o.textContent=w+' words · '+v.length+' characters · about '+Math.max(1,Math.round(w/200))+' min to read'}});

/* ---------- menu, top bar, motion ---------- */
const MENU=[
 ['My day',[['today','','','Today','sun'],['more','more','reminders','Reminders','pink',()=>{const n=nowMin(),c=agenda(today()).filter(x=>toMin(x.t)>=n).length;return c?c+' left':''}],['more','more','history','History','pink']]],
 ['Plan',[['plan','plan','tasks','Tasks','tomato',()=>{const c=S.tasks.filter(x=>!x.done&&x.due&&x.due<=today()).length;return c?c+' due':''}],['plan','plan','cal','Calendar','tomato'],['plan','plan','routine','Class routine','tomato']]],
 ['Study',[['study','study','courses','Courses','grape',()=>S.courses.length||''],['study','study','files','Files','grape',()=>S.files.length||''],['study','study','exams','Exams','grape',()=>{const e=S.exams.filter(x=>x.date>=today()).sort((a,b)=>a.date<b.date?-1:1)[0];return e?diffDays(e.date,today())+' d':''}],['study','study','timer','Focus timer','grape'],['study','study','cgpa','CGPA','grape'],['study','study','research','Research','grape'],['study','study','tools','PDF tools','grape']]],
 ['Deen',[['deen','deen','prayer','Prayer','leaf',()=>{const p=nextPrayer();return p.name+' '+tfmt(p.t)}],['deen','deen','quran','Quran','leaf'],['deen','deen','duas','Daily duas','leaf'],['deen','deen','tasbih','Tasbih','leaf'],['deen','deen','hadith','Hadith','leaf']]],
 ['Life',[['life','life','water','Water','sky',()=>(S.water[today()]||0)+'/'+S.settings.waterGoal],['life','life','food','Food','sky'],['life','life','habits','Habits','sky'],['life','life','sleep','Sleep','sky'],['life','life','health','Health','sky',()=>activeEp()?'Sick':''],['life','life','acts','Activities','sky'],['life','life','money','Money','sky']]],
 ['Keep',[['more','more','links','Links','pink'],['more','more','notes','Notes','pink'],['more','more','mail','Mail','pink'],['more','more','settings','Settings and backup','pink']]]
];
function drawDrawer(){
  const el=$('#drawer');if(!el)return;const s=S.settings;let i=0;
  el.innerHTML=`<div class="dhead">${avatar()}<div><b>${esc(s.name||'Catalyst')}</b><span>${fmt(today())}</span></div></div>`+
    MENU.filter(g=>!(s.deenOff&&g[0]==='Deen')).map(g=>`<div class="dgroup"><h4>${g[0]}</h4>${g[1].map(x=>{const on=ui.tab===x[0]&&(!x[1]||ui[x[1]]===x[2]),b=x[5]?x[5]():'';return`<button class="ditem${on?' on':''}" style="animation-delay:${Math.min(i++,14)*22}ms" data-a="${x[1]?'go':'tab'}" data-tab="${x[0]}" data-k="${x[1]}" data-v="${x[2]}"><i class="c-${x[4]}"></i>${x[3]}${b!==''?`<span class="pill">${esc(b)}</span>`:''}</button>`}).join('')}</div>`).join('')+
    `<p class="credit">${CREDIT}</p>`;
}
const TABL={today:'Today',plan:'Plan',study:'Study',deen:'Deen',life:'Life',more:'More'};
let lastKey='',tk=0;
function tickerItems(){
  const s=S.settings,t=today(),np=nextPrayer(),n=nowMin(),a=[fmt(t)];if(!s.deenOff)a.push(np.name+' at '+tfmt(np.t)+' · in '+dur(np.mins));
  const nx=agenda(t).find(x=>toMin(x.t)>=n&&x.src!=='Prayer');if(nx)a.push('Next: '+nx.title+' · '+tfmt(nx.t));
  const due=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t).length;if(due)a.push(due+' task'+(due>1?'s':'')+' due now');
  a.push('Water '+(S.water[t]||0)+' of '+s.waterGoal+' glasses');
  const ep=activeEp();if(ep){const l=doses(ep,t).filter(x=>!x.taken).length;if(l)a.push(l+' medicine dose'+(l>1?'s':'')+' left today')}
  return a;
}
function ticker(step){
  const el=$('#bsub');if(!el)return;const a=tickerItems();if(step)tk++;
  el.textContent=a[tk%a.length];
  if(step){el.classList.remove('flip');void el.offsetWidth;el.classList.add('flip')}
}
setInterval(()=>ticker(true),4500);
window.afterRender=function(){
  document.body.dataset.tab=ui.tab;
  const sl=(SUB[ui.tab]||[]).find(x=>x[0]===ui[ui.tab]),bt=$('#btitle'),v=$('#view');
  if(bt)bt.textContent=ui.tab==='today'?'Catalyst':TABL[ui.tab]+(sl?' · '+sl[1]:'');
  const key=ui.tab+'/'+(ui[ui.tab]||'')+'/'+(ui.course||ui.proj||ui.ep||'');
  if(v&&key!==lastKey){v.classList.remove('enter');void v.offsetWidth;v.classList.add('enter');lastKey=key}else if(v)v.classList.remove('enter');
  if(document.body.classList.contains('dopen'))drawDrawer();
  ticker(false);
};
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.body.classList.remove('dopen')});

/* ================= v3: illustrated home, first-run setup, NSU CGPA, Bangla duas, hadith, phone files, smart add ================= */
Object.assign(DEF_SET,{dob:'',setup:0,cgBase:0,cgCred:0,cgTarget:0,cgRemain:0,retake:'Latest grade',dl:'bn',fstore:'cloud'});
normalize();
delete EXT.todayTop;
SUB.deen.push(['hadith','Hadith']);
const ILL={
 mosque:'<path d="M8 40V26h32v14z" fill="var(--card)"/><path d="M14 26c0-8 10-9 10-15 0 6 10 7 10 15z" fill="var(--leaf)"/><path d="M24 7v4M20 40v-6a4 4 0 0 1 8 0v6" fill="var(--sun)"/><path d="M38 40V17l3-5 3 5v23z" fill="var(--sun)"/>',
 drop:'<path d="M24 6c8 10 12 16 12 22a12 12 0 0 1-24 0c0-6 4-12 12-22z" fill="var(--sky)"/><path d="M18 29a6 6 0 0 0 5 6"/>',
 wallet:'<rect x="6" y="13" width="36" height="25" rx="5" fill="var(--leaf)"/><path d="M6 20h36"/><circle cx="33" cy="29" r="3.5" fill="var(--sun)"/>',
 tasks:'<rect x="9" y="6" width="30" height="37" rx="5" fill="var(--tomato)"/><path d="m15 18 3 3 5-6M15 31l3 3 5-6M28 19h6M28 32h6"/>',
 book:'<path d="M6 12c6-3 12-3 18 1v26c-6-4-12-4-18-1z" fill="var(--grape)"/><path d="M42 12c-6-3-12-3-18 1v26c6-4 12-4 18-1z" fill="var(--pink)"/>',
 moon:'<path d="M38 28A15 15 0 1 1 20 10a12 12 0 0 0 18 18z" fill="var(--sun)"/><path d="M30 8h8l-8 8h8"/>',
 sprout:'<path d="M24 43V24"/><path d="M24 27c0-8-6-12-15-12 0 8 5 12 15 12z" fill="var(--leaf)"/><path d="M24 22c0-7 5-11 14-11 0 7-4 11-14 11z" fill="var(--sun)"/>',
 timer:'<circle cx="24" cy="28" r="14" fill="var(--pink)"/><path d="M24 28v-8M20 6h8M24 6v8"/>',
 exam:'<rect x="7" y="10" width="34" height="31" rx="5" fill="var(--sun)"/><path d="M7 19h34M16 6v8M32 6v8M18 30l4 4 8-8"/>',
 pill:'<g transform="rotate(-35 24 24)"><rect x="5" y="16" width="38" height="16" rx="8" fill="var(--tomato)"/><path d="M24 16v16"/></g>',
 quran:'<path d="M8 10h14c2 0 2 2 2 2s0-2 2-2h14v28H26c-2 0-2 2-2 2s0-2-2-2H8z" fill="var(--leaf)"/><path d="M24 12v28M13 18h6M13 24h6M29 18h6M29 24h6"/>',
 mail:'<rect x="6" y="11" width="36" height="26" rx="5" fill="var(--pink)"/><path d="m8 15 16 12 16-12"/>'
};
const ill=n=>`<svg class="ill" viewBox="0 0 48 48" aria-hidden="true">${ILL[n]}</svg>`;
const bday=()=>{const d=S.settings.dob;if(!/^\d{4}-\d{2}-\d{2}$/.test(d||''))return null;const t=today(),y=+t.slice(0,4);let nx=y+d.slice(4);if(nx<t)nx=(y+1)+d.slice(4);return diffDays(nx,t)};

/* ---------- home ---------- */
function skyHero(){
  const t=today(),pt=ptimes(t),n=nowMin(),fj=toMin(pt.fajr),sr=toMin(pt.sunrise),mg=toMin(pt.maghrib),is=toMin(pt.isha),s=S.settings,h=new Date().getHours();
  const ph=n<fj||n>=is?'night':n<sr?'dawn':n<mg-45?'day':'dusk',G={night:['#10143F','#2C2F7A'],dawn:['#6F62D0','#FFB48A'],day:['#4DB4FF','#D4F0FF'],dusk:['#5546BD','#FF9A62']}[ph];
  const up=n>=sr&&n<mg,fr=up?(n-sr)/(mg-sr):((n-mg+1440)%1440)/(sr+1440-mg),x=28+304*fr,y=110-78*Math.sin(Math.PI*fr);
  let arc='';for(let i=0;i<=24;i++)arc+=(i?'L':'M')+(28+304*i/24).toFixed(1)+' '+(110-78*Math.sin(Math.PI*i/24)).toFixed(1);
  const dark=ph!=='day',bd=bday(),np=nextPrayer(),K='stroke="#3B2F80" stroke-width="2" stroke-linejoin="round"';
  const stars=ph==='night'||ph==='dusk'?[[150,18],[205,40],[250,14],[322,52],[120,58],[285,70],[60,74]].map((p,i)=>`<circle class="star" style="animation-delay:${i*.35}s" cx="${p[0]}" cy="${p[1]}" r="1.8" fill="#fff"/>`).join(''):'';
  const clouds=ph==='day'||ph==='dawn'?`<g class="cloud" fill="#fff" opacity=".9"><ellipse cx="208" cy="62" rx="20" ry="8"/><ellipse cx="222" cy="56" rx="13" ry="8"/><ellipse cx="300" cy="80" rx="15" ry="6"/></g>`:'';
  const orb=up?`<g class="orb"><circle cx="${x}" cy="${y}" r="20" fill="#FFD23F" opacity=".35"/><circle cx="${x}" cy="${y}" r="13" fill="#FFD23F" ${K}/></g>`:`<g class="orb"><circle cx="${x}" cy="${y}" r="12" fill="#FFF3C4" ${K}/><circle cx="${x-4}" cy="${y-3}" r="2.2" fill="#E3D49A"/><circle cx="${x+4}" cy="${y+4}" r="1.6" fill="#E3D49A"/></g>`;
  const conf=bd===0?['#FF6B5E','#FFC83A','#3DCB82','#FF8CC3','#fff'].map((c,i)=>`<circle class="star" style="animation-delay:${i*.2}s" cx="${40+i*66}" cy="${30+(i%2)*26}" r="4" fill="${c}"/>`).join(''):'';
  const svg=`<svg viewBox="0 0 360 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="skg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${G[0]}"/><stop offset="1" stop-color="${G[1]}"/></linearGradient></defs><rect width="360" height="150" fill="url(#skg)"/>${stars}${clouds}<path d="${arc}" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2" stroke-dasharray="2 7" stroke-linecap="round"/>${orb}${conf}
    <path d="M0 150v-26c40-14 84-14 124-4s92 12 132-2 76-8 104 4v28z" fill="${dark?'#1F8A5B':'#3DCB82'}" ${K}/>
    <path d="M249 127h10M249 115h10M249 101h10M249 89h10" stroke="#3B2F80" stroke-width="2" stroke-linecap="round"/><g fill="none" stroke-linecap="round" stroke-width="4"><path d="M246 134c0-13 16-13 16-26s-16-13-16-26" stroke="#A58BFF"/><path d="M262 134c0-13-16-13-16-26s16-13 16-26" stroke="#FFC83A"/></g><g ${K}><path d="M298 78h22M302 78v18l-17 28a5 5 0 0 0 4 8h40a5 5 0 0 0 4-8l-17-28V78z" fill="${dark?'#CFC8F7':'#fff'}"/><path d="M291 112h36l6 12a5 5 0 0 1-4 8h-40a5 5 0 0 1-4-8z" fill="#FF8CC3"/></g><circle class="star" cx="304" cy="121" r="2.4" fill="#fff"/><circle class="star" style="animation-delay:.6s" cx="315" cy="125" r="1.7" fill="#fff"/><circle class="orb" cx="310" cy="68" r="3.2" fill="#FF8CC3" stroke="#1F1A3D" stroke-width="1.5"/></svg>`;
  const hi=bd===0?'Happy birthday':h<5?'Peaceful night':h<12?'Good morning':h<17?'Good afternoon':h<21?'Good evening':'Good night';
  return`<div class="sky ${ph}">${svg}<div class="skytext"><p>${hi}</p><h1>${esc(s.name||'Welcome')}</h1><p>${fmt(t)}${s.deenOff||!hijri()?'':' · '+hijri()}</p>${bd&&bd<=7?`<p>Your birthday is in ${bd} day${bd>1?'s':''}</p>`:''}</div>${s.deenOff?'':`<span class="pill skypill">${np.name} ${tfmt(np.t)} · ${dur(np.mins)}</span>`}${streakPill()}</div>`;
}
const tile=(col,icon,big,label,tab,k,v,extra)=>`<div class="tile t-${col}" role="button" tabindex="0" data-a="go" data-tab="${tab}" data-k="${k}" data-v="${v}">${ill(icon)}<b>${big}</b><span>${esc(label)}</span>${extra||''}</div>`;
const XK=['Quiz','Mid-term','Final','Assignment','Presentation','Lab report','Viva','Other'];
const HAD=[
 ['সকল কাজ নিয়তের উপর নির্ভরশীল, আর প্রত্যেক ব্যক্তি তা-ই পাবে যার সে নিয়ত করেছে।','Actions are judged by intentions, and everyone gets what they intended.','Bukhari 1'],
 ['তোমাদের মধ্যে সর্বোত্তম সেই ব্যক্তি, যে কুরআন শেখে এবং অন্যকে শেখায়।','The best of you are those who learn the Quran and teach it.','Bukhari 5027'],
 ['যে আল্লাহ ও শেষ দিনের প্রতি ঈমান রাখে, সে যেন ভালো কথা বলে অথবা চুপ থাকে।','Whoever believes in Allah and the Last Day should speak good or stay silent.','Bukhari 6018'],
 ['তোমাদের কেউ ততক্ষণ পূর্ণ মুমিন হতে পারবে না, যতক্ষণ না সে তার ভাইয়ের জন্য তা-ই পছন্দ করে যা নিজের জন্য পছন্দ করে।','None of you truly believes until he loves for his brother what he loves for himself.','Bukhari 13'],
 ['প্রকৃত শক্তিশালী সে নয় যে কুস্তিতে অন্যকে হারায়; বরং সে, যে রাগের সময় নিজেকে নিয়ন্ত্রণ করে।','The strong one is not the one who wrestles others down, but the one who controls himself when angry.','Bukhari 6114'],
 ['সহজ করো, কঠিন করো না; সুসংবাদ দাও, বিমুখ করো না।','Make things easy and do not make them hard. Give good news and do not drive people away.','Bukhari 69'],
 ['পবিত্রতা ঈমানের অর্ধেক।','Cleanliness is half of faith.','Muslim 223'],
 ['তোমার ভাইয়ের সামনে তোমার মুচকি হাসি সদকা।','Your smile for your brother is charity.','Tirmidhi 1956'],
 ['আল্লাহর কাছে সবচেয়ে প্রিয় আমল তা-ই, যা নিয়মিত করা হয়, যদিও তা অল্প হয়।','The deeds most loved by Allah are those done regularly, even if they are small.','Bukhari 6464'],
 ['প্রকৃত মুসলিম সে, যার জিহ্বা ও হাত থেকে অন্য মুসলিমরা নিরাপদ থাকে।','A Muslim is one from whose tongue and hand other Muslims are safe.','Bukhari 10'],
 ['যে ব্যক্তি জ্ঞান অর্জনের পথে চলে, আল্লাহ তার জন্য জান্নাতের পথ সহজ করে দেন।','Whoever walks a path in search of knowledge, Allah makes the path to Paradise easy for him.','Muslim 2699'],
 ['দুনিয়াতে এমনভাবে থাকো যেন তুমি একজন অপরিচিত অথবা পথিক।','Be in this world as though you were a stranger or a traveller.','Bukhari 6416'],
 ['দুটি নিয়ামতের ব্যাপারে অনেক মানুষ ধোঁকায় পড়ে আছে: সুস্থতা এবং অবসর।','Two blessings that many people waste: health and free time.','Bukhari 6412'],
 ['জ্ঞান অর্জন করা প্রত্যেক মুসলিমের উপর ফরজ।','Seeking knowledge is a duty on every Muslim.','Ibn Majah 224']
];
const hadRow=h=>`<div class="dua"><p style="font-size:17px">${h[0]}</p><p class="muted">${h[1]}</p><p class="muted">${h[2]}</p></div>`;
const hadToday=()=>HAD[Math.floor(parse(today()).getTime()/864e5)%HAD.length];
EXT.hadith=()=>`<div class="card c-leaf"><h2>আজকের হাদিস</h2>${hadRow(hadToday())}</div><div class="card"><h2>Short hadith to live by</h2><p class="muted">These are the meanings in Bangla and English, not the full narrations. A complete hadith collection is not stored in the app yet.</p>${HAD.map(hadRow).join('')}</div>`;
VIEWS.today=()=>{
  const t=today(),s=S.settings,d=new Date(),n=nowMin(),pl=S.prayers[t]||{},pt=ptimes(t),np=nextPrayer(),ep=activeEp();
  const due=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t),w=S.water[t]||0,out=m=>m.type!=='in';
  const spent=S.money.filter(m=>m.date===t&&out(m)).reduce((a,m)=>a+m.amount,0),mo=S.money.filter(m=>m.date.slice(0,7)===t.slice(0,7)&&out(m)).reduce((a,m)=>a+m.amount,0);
  const cls=S.routine.filter(r=>+r.day===d.getDay()).sort(byStart),nc=cls.find(r=>toMin(r.start)>=n);
  const sl=S.sleep.find(l=>l.date===t),hl=S.habitLog[t]||{},hd=S.habits.filter(x=>hl[x.id]).length;
  const fm=S.focus.filter(f=>f.date===t).reduce((a,f)=>a+f.min,0),q=QN().log[t]||0,nx=S.exams.filter(e=>e.date>=t).sort((a,b)=>a.date<b.date?-1:1)[0];
  const left=ep?doses(ep,t).filter(x=>!x.taken).length:0,up=agenda(t).filter(x=>toMin(x.t)>=n&&x.src!=='Prayer').slice(0,4),hd0=hadToday();
  let o=skyHero();
  if(!s.deenOff&&!s.noRow)o+=`<div class="hprow">${PR.map(p=>`<button class="hp${pl[p[0]]?' on':''}${np.name===p[1]&&toMin(pt[p[0]])>n?' next':''}" data-a="prTog" data-id="${p[0]}" data-d="${t}" aria-pressed="${pl[p[0]]?'true':'false'}" aria-label="${p[1]} prayed"><b>${p[1]}</b>${tfmt(pt[p[0]]).replace(/ [AP]M/,'')}</button>`).join('')}</div>`;
  o+=homeTiles();
  o+=streakCard();
  o+=`<div class="card">${head('Due now',`<button class="btn sm" data-a="go" data-tab="plan" data-k="plan" data-v="tasks">All tasks</button>`)}${due.length?'<div class="list">'+due.slice(0,5).map(taskRow).join('')+'</div>':'<p class="muted">Nothing is waiting. Add a task with a date and it shows here.</p>'}<form class="quick" data-f="task"><input id="q_task" placeholder="Add a task for today" aria-label="New task for today"><button class="btn pri" aria-label="Add task">${ic('plus')}</button></form></div>`;
  if(ep)o+=`<div class="card c-tomato">${head('Medicine today',`<button class="btn sm" data-a="go" data-tab="life" data-k="life" data-v="health">Open</button>`)}<p class="muted">${esc(ep.name)}</p>${doseList(ep,t)}</div>`;
  if(up.length)o+=`<div class="card">${head('Up next',`<button class="btn sm" data-a="go" data-tab="more" data-k="more" data-v="reminders">All</button>`)}<div class="list">${up.map(x=>`<div class="item"><span class="pill">${tfmt(x.t)}</span><span class="t grow">${esc(x.title)}</span></div>`).join('')}</div></div>`;
  o+=`<div class="card"><div class="row">${ill('dna')}<div class="grow"><h3>Biochem bite</h3><p>${esc(factToday())}</p></div></div></div>`;
  return o;
};
const BAN={plan:['tomato','tasks','Plan',()=>{const t=today(),c=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t).length,k=S.routine.filter(r=>+r.day===new Date().getDay()).length;return c+' task'+(c===1?'':'s')+' due · '+k+' class'+(k===1?'':'es')+' today'}],
 study:['grape','book','Study',()=>{const e=S.exams.filter(x=>x.date>=today()).sort((a,b)=>a.date<b.date?-1:1)[0];return e?e.title+' in '+diffDays(e.date,today())+' days':'CGPA '+cg().g.toFixed(2)+' · no exam set'}],
 deen:['leaf','mosque','Deen',()=>{const p=nextPrayer();return p.name+' at '+tfmt(p.t)+' · in '+dur(p.mins)}],
 life:['sky','drop','Life',()=>(S.water[today()]||0)+' of '+S.settings.waterGoal+' glasses · '+(activeEp()?'sick mode on':'feeling well')],
 more:['pink','mail','Keep',()=>S.links.length+' links · '+S.notes.length+' notes · '+S.files.length+' files']};
Object.keys(BAN).forEach(k=>{const v=VIEWS[k],b=BAN[k];VIEWS[k]=()=>(k==='study'&&((ui.study==='courses'&&ui.course)||(ui.study==='research'&&ui.proj)))||(k==='life'&&ui.life==='health'&&ui.ep)?v():`<div class="banner b-${b[0]}">${ill(b[1])}<div><b>${b[2]}</b><span>${esc(b[3]())}</span></div></div>`+v()});

/* ---------- smart add (asks Claude to read one sentence) ---------- */
const isD=x=>/^\d{4}-\d{2}-\d{2}$/.test(x||''),isT=x=>/^\d{2}:\d{2}$/.test(x||'');
function applyItems(items){
  const t=today(),out=[],keys=new Set();
  (Array.isArray(items)?items:[]).slice(0,12).forEach(i=>{
    if(!i||typeof i!=='object')return;
    const title=String(i.title||i.text||i.name||'').slice(0,200),amt=Math.abs(num(i.amount));
    if(i.type==='task'&&title){S.tasks.push({id:uid(),title:title,due:isD(i.due)?i.due:'',cat:'',pri:'Normal',done:false});keys.add('tasks');out.push('task “'+title+'”')}
    else if((i.type==='expense'||i.type==='income')&&amt){S.money.push({id:uid(),date:t,amount:amt,type:i.type==='income'?'in':'out',cat:MCAT.includes(i.cat)?i.cat:'Other',note:String(i.note||'').slice(0,100)});keys.add('money');out.push((i.type==='income'?'received ':'spent ')+money(amt))}
    else if(i.type==='water'){const g=Math.min(20,Math.max(0,Math.round(num(i.glasses))));if(g){S.water[t]=(S.water[t]||0)+g;keys.add('water');out.push(g+' glass'+(g>1?'es':'')+' of water')}}
    else if(i.type==='meal'&&title){const c=Math.abs(num(i.cost));S.meals.push({id:uid(),date:t,meal:SLOT.includes(i.meal)?i.meal:'Snack',text:title,tag:'',cost:c});keys.add('meals');if(c){S.money.push({id:uid(),date:t,amount:c,type:'out',cat:'Food',note:title});keys.add('money')}out.push('meal “'+title+'”')}
    else if(i.type==='reminder'&&title&&isT(i.time)){S.reminders.push({id:uid(),title:title,time:i.time,repeat:'Once',date:isD(i.date)?i.date:t,day:0,on:1});keys.add('reminders');out.push('reminder at '+tfmt(i.time))}
    else if(i.type==='event'&&title&&isD(i.date)){S.events.push({id:uid(),title:title,date:i.date,time:isT(i.time)?i.time:'',note:''});keys.add('events');out.push('event on '+fmt(i.date))}
    else if(i.type==='exam'&&title&&isD(i.date)){const k=String(i.course||'').toLowerCase().replace(/\s/g,''),c=S.courses.find(x=>k&&String(x.code||'').toLowerCase().replace(/\s/g,'')===k);S.exams.push({id:uid(),title:title,type:XK.includes(i.kind)?i.kind:'Other',courseId:c?c.id:'',date:i.date,time:isT(i.time)?i.time:''});keys.add('exams');out.push(title+' on '+fmt(i.date))}
    else if(i.type==='prayer'&&PR.some(p=>p[0]===i.name)){(S.prayers[t]=S.prayers[t]||{})[i.name]=1;keys.add('prayers');out.push(i.name+' prayer')}
    else if(i.type==='habit'){const h=S.habits.find(x=>x.name.toLowerCase()===title.toLowerCase());if(h){(S.habitLog[t]=S.habitLog[t]||{})[h.id]=1;keys.add('habitLog');out.push('habit “'+h.name+'”')}}
    else if(i.type==='activity'&&title){S.acts.push({id:uid(),date:t,time:hm(nowMin()),text:title,kind:'Other',min:Math.round(num(i.minutes))||''});keys.add('acts');out.push('activity “'+title+'”')}
    else if(i.type==='note'&&title){const nn={id:uid(),ref:'',title:title,body:String(i.body||'').slice(0,5000),updated:Date.now()};S.notes.push(nn);keys.add('n_'+nn.id);out.push('note “'+title+'”')}
  });
  if(keys.size)save.apply(null,[...keys]);
  return out;
}
const smErr=e=>e&&e.code==='rate_limited'?'Too many requests. Try again in a minute.':e&&e.code==='not_granted'?'This needs your permission.':'That did not work. Try shorter wording.';
async function capture(text){
  if(!SM){say('cap','Smart add is not available in this view. Use the + buttons instead.');return}
  say('cap','Reading…');
  const t=today(),p=`You turn a student's short message into JSON for their planner app. Today is ${t} (${DAYSL[new Date().getDay()]}), time ${hm(nowMin())}. Their course codes: ${S.courses.map(c=>c.code).filter(Boolean).join(', ')||'none'}. Their habits: ${S.habits.map(h=>h.name).join(', ')||'none'}.
Reply with ONLY JSON shaped {"items":[...]}. Each item is one of:
{"type":"task","title":"","due":"YYYY-MM-DD or empty"}
{"type":"expense","amount":0,"cat":"Food|Transport|Study|Mobile and internet|Shopping|Health|Fun|Other","note":""}
{"type":"income","amount":0,"note":""}
{"type":"water","glasses":0}
{"type":"meal","meal":"Breakfast|Lunch|Dinner|Snack","title":"what was eaten","cost":0}
{"type":"reminder","title":"","time":"HH:MM","date":"YYYY-MM-DD"}
{"type":"event","title":"","date":"YYYY-MM-DD","time":"HH:MM or empty"}
{"type":"exam","title":"","kind":"Quiz|Mid-term|Final|Assignment|Presentation|Lab report|Viva|Other","date":"YYYY-MM-DD","time":"HH:MM or empty","course":"course code or empty"}
{"type":"prayer","name":"fajr|dhuhr|asr|maghrib|isha"}
{"type":"habit","title":"exact habit name from the list"}
{"type":"activity","title":"","minutes":0}
{"type":"note","title":"","body":""}
Rules: the message may be Bangla, English or mixed; keep titles in the language used. Food that was bought is one meal item with its cost, not also an expense. Use only what the message says and invent nothing. If nothing fits, return {"items":[]}.
Message: """${text.slice(0,600)}"""`;
  try{const r=await SM(p,{modelTier:'quick',cache:false}),m=String(r&&r.text||'').match(/\{[\s\S]*\}/),done=applyItems(m?JSON.parse(m[0]).items:[]);say('cap',done.length?'Added: '+done.join(', ')+'.':'I could not find anything to add in that.')}
  catch(e){say('cap',smErr(e))}
}
async function planDay(){
  if(!SM){say('cap','Day planning is not available in this view.');return}
  say('cap','Planning your day…');
  const t=today(),pt=ptimes(t),dow=new Date().getDay();
  const p=`Write a short time-blocked plan for the rest of today for a Muslim university student in Bangladesh. The time now is ${hm(nowMin())}.
Fixed times: prayers ${PR.map(x=>x[1]+' '+pt[x[0]]).join(', ')}; classes ${S.routine.filter(r=>+r.day===dow).map(r=>rName(r)+' '+r.start+(r.end?'-'+r.end:'')).join(', ')||'none'}; events ${S.events.filter(e=>e.date===t).map(e=>e.title+' '+(e.time||'')).join(', ')||'none'}; bedtime ${S.settings.sleepBed}.
Open tasks: ${S.tasks.filter(x=>!x.done).slice(0,12).map(x=>x.title+(x.due?' (due '+x.due+')':'')).join('; ')||'none'}.
Coming exams and deadlines: ${S.exams.filter(e=>e.date>=t).slice(0,5).map(e=>e.title+' on '+e.date).join('; ')||'none'}.
Rules: 8 to 10 lines, each "HH:MM  what to do". Only times after now. Put the hardest or most urgent work first, in focus blocks of 25 to 50 minutes with short breaks. Keep prayers, meals and the bedtime. Do not invent tasks. Plain text only, no markdown, no intro and no closing line.`;
  try{const r=await SM(p,{cache:false});note.plan=String(r&&r.text||'').trim().slice(0,1500);say('cap','Here is a plan for the rest of today.')}
  catch(e){say('cap',smErr(e))}
}
Q.capture=()=>{const v=$('#q_cap').value.trim();if(v)capture(v)};

/* ---------- NSU CGPA ---------- */
const NSU=[['A',4,'93 and above'],['A-',3.7,'90 to 92'],['B+',3.3,'87 to 89'],['B',3,'83 to 86'],['B-',2.7,'80 to 82'],['C+',2.3,'77 to 79'],['C',2,'73 to 76'],['C-',1.7,'70 to 72'],['D+',1.3,'67 to 69'],['D',1,'60 to 66'],['F',0,'below 60']];
const ngp=g=>{const x=NSU.find(k=>k[0]===g);return x?x[1]:null};
function cg(){
  const s=S.settings;let cr=num(s.cgCred),pts=num(s.cgBase)*cr;
  S.sems.forEach(se=>(se.items||[]).forEach(i=>{const c=num(i.credits),g=ngp(i.grade);if(g==null||!c)return;const o=i.old?ngp(i.old):null;
    if(o!=null){if(s.retake==='Better grade'&&o>=g)return;pts+=c*(g-o)}else{pts+=c*g;cr+=c}}));
  return{cr:cr,pts:pts,g:cr?pts/cr:0};
}
const termGpa=items=>{let c=0,p=0;items.forEach(i=>{const g=ngp(i.grade),k=num(i.credits);if(g!=null){c+=k;p+=k*g}});return c?p/c:0};
EXT.cgpa=()=>{
  const s=S.settings,c=cg(),tg=num(s.cgTarget),rm=num(s.cgRemain),need=tg&&rm?(tg*(c.cr+rm)-c.pts)/rm:null;
  let o=`<div class="card c-sun"><div class="row between"><h3>CGPA</h3><span class="pill">North South University scale</span></div><div class="big">${c.g.toFixed(2)}</div><p class="muted">${Math.round(c.cr*10)/10} credits counted${c.cr&&c.g<2?'. Below 2.00 means academic probation at NSU.':''}</p></div>`;
  o+=`<div class="card">${head('Where I stand now',`<button class="btn sm" data-a="cgBase">${ic('edit')}Edit</button>`)}<p>${num(s.cgCred)?`Starting from CGPA <b>${num(s.cgBase).toFixed(2)}</b> with <b>${num(s.cgCred)}</b> credits.`:'Not set yet.'}</p><p class="muted">Type your current CGPA and completed credits from RDS once. After that, add only new semesters. Or leave this empty and enter every semester yourself.</p></div>`;
  o+=`<div class="card">${head('Target',`<button class="btn sm" data-a="cgTarget">${ic('edit')}Set</button>`)}${need==null?'<p class="muted">Set the CGPA you want and how many credits you still have to take. The app tells you the average you need.</p>':`<p>To finish with <b>${tg.toFixed(2)}</b> you need an average of <b>${need>4?'more than 4.00':need<=0?'0.00':need.toFixed(2)}</b> in your remaining ${rm} credits.</p><p class="muted">${need>4?'That target cannot be reached with these credits. Retaking low grades can help.':need>3.7?'That means nearly all A and A-.':need<=0?'You are already above it.':'That is within reach.'}</p>`}</div>`;
  o+=`<div class="card"><h3>When I retake a course, count</h3><div class="chips">${['Latest grade','Better grade'].map(x=>`<button class="chip${s.retake===x?' on':''}" data-a="cgRule" data-v="${x}">${x}</button>`).join('')}</div><p class="muted">Pick the rule your transcript follows. A retake replaces the old grade inside your total, so the first attempt must already be counted in your current CGPA or an earlier semester here.</p></div>`;
  o+=`<div class="row between"><p class="muted">${S.sems.length} semester${S.sems.length===1?'':'s'}</p>${addBtn('sAdd','Semester')}</div>`;
  o+=S.sems.map(se=>`<div class="card"><div class="row between"><button class="tap" data-a="sEdit" data-id="${se.id}"><h3>${esc(se.name)}</h3></button><span class="pill col c-sun">GPA ${termGpa(se.items||[]).toFixed(2)}</span></div>${(se.items||[]).length?'<div class="list">'+se.items.map(i=>`<div class="item"><button class="tap" data-a="giEdit" data-sem="${se.id}" data-id="${i.id}"><span class="t">${esc(i.name)}</span><span class="muted">${num(i.credits)} credits${i.old?' · retake, was '+esc(i.old):''}${ngp(i.grade)==null?' · not counted':''}</span></button><span class="big" style="font-size:22px">${esc(i.grade)}</span></div>`).join('')+'</div>':''}<button class="btn sm" data-a="giAdd" data-sem="${se.id}" style="align-self:flex-start">${ic('plus')}Course grade</button></div>`).join('');
  o+=`<div class="card"><h3>NSU grading scale</h3><div class="list">${NSU.map(g=>`<div class="item"><span class="t" style="width:34px">${g[0]}</span><span class="grow muted">${g[2]}</span><span class="t">${g[1].toFixed(1)}</span></div>`).join('')}</div><p class="muted">W (withdrawn) and I (incomplete) carry no grade points and are not counted.</p></div>`;
  return o;
};
A.giFields=[['name','Course','text',R],['credits','Credits','number',R],['grade','Grade','select',{opts:NSU.map(g=>[g[0],g[0]+'  ('+g[1].toFixed(1)+')']).concat([['W','W  (withdrawn)'],['I','I  (incomplete)']])}],['old','Is this a retake?','select',{opts:[['','No, first attempt']].concat(NSU.map(g=>[g[0],'Yes, old grade was '+g[0]]))}]];

/* ---------- duas: vowels, Bangla pronunciation and meaning ---------- */
const DX={
 sayyid:['اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ','আল্লাহুম্মা আনতা রাব্বী, লা ইলাহা ইল্লা আনতা, খালাক্বতানী ওয়া আনা আবদুকা, ওয়া আনা আলা আহদিকা ওয়া ওয়া‘দিকা মাসতাত্বা‘তু, আউযু বিকা মিন শাররি মা সানা‘তু, আবূউ লাকা বিনি‘মাতিকা আলাইয়া, ওয়া আবূউ লাকা বিযাম্বী, ফাগফিরলী, ফাইন্নাহু লা ইয়াগফিরুয যুনূবা ইল্লা আনতা।','হে আল্লাহ, তুমি আমার রব, তুমি ছাড়া কোনো ইলাহ নেই। তুমি আমাকে সৃষ্টি করেছ এবং আমি তোমার বান্দা। আমি সাধ্যমতো তোমার অঙ্গীকার ও প্রতিশ্রুতির উপর আছি। আমার কৃতকর্মের অনিষ্ট থেকে তোমার কাছে আশ্রয় চাই। আমার প্রতি তোমার নিয়ামত স্বীকার করছি এবং আমার গুনাহ স্বীকার করছি। অতএব আমাকে ক্ষমা করো, কারণ তুমি ছাড়া কেউ গুনাহ ক্ষমা করতে পারে না।'],
 bism3:['بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ','বিসমিল্লাহিল্লাযী লা ইয়াদুররু মা‘আসমিহী শাইউন ফিল আরদি ওয়ালা ফিস সামাই ওয়া হুয়াস সামীউল আলীম।','আল্লাহর নামে, যাঁর নামের সাথে আসমান ও জমিনের কোনো কিছুই ক্ষতি করতে পারে না। তিনি সর্বশ্রোতা, সর্বজ্ঞ।'],
 hasbi:['حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ','হাসবিয়াল্লাহু লা ইলাহা ইল্লা হুয়া, আলাইহি তাওয়াক্কালতু ওয়া হুয়া রাব্বুল আরশিল আযীম।','আল্লাহই আমার জন্য যথেষ্ট। তিনি ছাড়া কোনো ইলাহ নেই। তাঁর উপরই আমি ভরসা করি এবং তিনি মহান আরশের রব।'],
 sbh:['سُبْحَانَ اللَّهِ وَبِحَمْدِهِ','সুবহানাল্লাহি ওয়া বিহামদিহী।','আল্লাহ পবিত্র এবং সকল প্রশংসা তাঁরই।'],
 tahlil:['لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ','লা ইলাহা ইল্লাল্লাহু ওয়াহদাহু লা শারীকা লাহু, লাহুল মুলকু ওয়া লাহুল হামদু ওয়া হুয়া আলা কুল্লি শাইয়িন ক্বাদীর।','আল্লাহ ছাড়া কোনো ইলাহ নেই, তিনি একক, তাঁর কোনো শরিক নেই। রাজত্ব তাঁরই, প্রশংসাও তাঁরই এবং তিনি সব কিছুর উপর ক্ষমতাবান।'],
 salawat:['اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ','আল্লাহুম্মা সাল্লি ওয়া সাল্লিম আলা নাবিয়্যিনা মুহাম্মাদ।','হে আল্লাহ, আমাদের নবী মুহাম্মাদ (সা.)-এর উপর রহমত ও শান্তি বর্ষণ করো।'],
 istigh:['أَسْتَغْفِرُ اللَّهَ','আস্তাগফিরুল্লাহ।','আমি আল্লাহর কাছে ক্ষমা চাই।'],
 tasbih:['سُبْحَانَ اللَّهِ (33) · الْحَمْدُ لِلَّهِ (33) · اللَّهُ أَكْبَرُ (34)','সুবহানাল্লাহ, আলহামদুলিল্লাহ, আল্লাহু আকবার।','আল্লাহ পবিত্র। সকল প্রশংসা আল্লাহর। আল্লাহ সবচেয়ে মহান।'],
 ainni:['اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ','আল্লাহুম্মা আ‘ইন্নী আলা যিকরিকা ওয়া শুকরিকা ওয়া হুসনি ইবাদাতিকা।','হে আল্লাহ, তোমার যিকির, তোমার শুকরিয়া এবং সুন্দরভাবে তোমার ইবাদত করতে আমাকে সাহায্য করো।'],
 wake:['الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ','আলহামদু লিল্লাহিল্লাযী আহইয়ানা বা‘দা মা আমাতানা ওয়া ইলাইহিন নুশূর।','সকল প্রশংসা আল্লাহর, যিনি আমাদের মৃত্যুর (ঘুমের) পর আবার জীবিত করেছেন এবং তাঁর কাছেই ফিরে যেতে হবে।'],
 leave:['بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ','বিসমিল্লাহি তাওয়াক্কালতু আলাল্লাহি ওয়ালা হাওলা ওয়ালা কুওয়াতা ইল্লা বিল্লাহ।','আল্লাহর নামে বের হচ্ছি, আল্লাহর উপর ভরসা করলাম। আল্লাহ ছাড়া কোনো শক্তি ও সামর্থ্য নেই।'],
 eat:['الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ','আলহামদু লিল্লাহিল্লাযী আত্ব‘আমানী হাযা ওয়া রাযাক্বানীহি মিন গাইরি হাওলিম মিন্নী ওয়ালা কুওয়াহ।','সকল প্রশংসা আল্লাহর, যিনি আমাকে এটি খাইয়েছেন এবং আমার কোনো শক্তি-সামর্থ্য ছাড়াই এই রিযিক দিয়েছেন।'],
 ilm:['رَبِّ زِدْنِي عِلْمًا · رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي','রাব্বি যিদনী ইলমা। রাব্বিশরাহলী সাদরী, ওয়া ইয়াসসিরলী আমরী।','হে আমার রব, আমার জ্ঞান বাড়িয়ে দাও। হে আমার রব, আমার বক্ষ প্রশস্ত করে দাও এবং আমার কাজ সহজ করে দাও।'],
 rabbana:['رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ','রাব্বানা আতিনা ফিদ্দুনইয়া হাসানাতাও ওয়া ফিল আখিরাতি হাসানাতাও ওয়া ক্বিনা আযাবান নার।','হে আমাদের রব, আমাদের দুনিয়াতে কল্যাণ দাও, আখিরাতেও কল্যাণ দাও এবং আমাদের জাহান্নামের আযাব থেকে রক্ষা করো।'],
 parents:['رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا','রাব্বির হামহুমা কামা রাব্বাইয়ানী সাগীরা।','হে আমার রব, তাঁদের প্রতি রহম করো, যেমন তাঁরা শৈশবে আমাকে লালন-পালন করেছেন।'],
 sleep:['بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا','বিসমিকা আল্লাহুম্মা আমূতু ওয়া আহইয়া।','হে আল্লাহ, তোমার নামেই আমি মরি (ঘুমাই) এবং জীবিত হই (জাগি)।']
};
DUA.forEach(d=>{const x=DX[d.id];if(x){d.ar=x[0];d.bp=x[1];d.bm=x[2]}});

/* ---------- files kept on this phone (any type) ---------- */
let IDB=null;
function idb(){return new Promise((res,rej)=>{if(IDB)return res(IDB);try{const r=indexedDB.open('barakah-files',1);r.onupgradeneeded=()=>r.result.createObjectStore('f');r.onsuccess=()=>{IDB=r.result;res(IDB)};r.onerror=()=>rej(r.error)}catch(e){rej(e)}})}
const idbDo=(mode,fn)=>idb().then(d=>new Promise((res,rej)=>{const t=d.transaction('f',mode),q=fn(t.objectStore('f'));t.oncomplete=()=>res(q.result);t.onerror=()=>rej(t.error)}));
async function putFiles(list,msgKey,each,cloudOnly){
  const bad=[];let local=0;
  for(const f of list){
    const type=FT[ext(f.name)],phone=!cloudOnly&&(S.settings.fstore==='phone'||!type||!AS);
    if(!phone&&(!type||!AS)){bad.push(f.name+' (use a JPG, PNG or PDF)');continue}
    if(f.size>(phone?100:20)*1048576){bad.push(f.name+' (too large)');continue}
    say(msgKey,'Saving '+f.name+'…');
    try{
      if(phone){const k='L'+uid();await idbDo('readwrite',s=>s.put(f,k));each({id:'',local:k,sizeBytes:f.size,contentType:f.type||type||''},f);local++}
      else each(await AS.upload(f,{type:type}),f);
    }catch(e){bad.push(f.name+' ('+(e&&e.code==='quota_or_state'?'storage is full':'could not be saved')+')')}
  }
  say(msgKey,(bad.length?'Not saved: '+bad.join('; ')+'. ':'Saved. ')+(local?local+' file'+(local>1?'s are':' is')+' kept on this phone only.':''));
}
const fileRows=l=>'<div class="list">'+l.map(f=>`<div class="item linkrow">${f.asset&&/^image\//.test(f.type)?`<img class="thumb" src="/_blob/${f.asset}" alt="">`:`<span class="thumb">${esc(ext(f.name))}</span>`}<div class="grow">${f.asset?`<a href="/_blob/${f.asset}" target="_blank" rel="noopener">${esc(f.name)}</a>`:`<span class="t">${esc(f.name)}</span>`}<small>${fsz(f.size)} · ${fmt(f.added)} · ${f.asset?'cloud':'this phone'}</small></div><button class="btn sm" data-a="fSave" data-id="${f.id}">${f.asset?'Save':'Open'}</button><button class="btn sm" data-a="fEdit" data-id="${f.id}" aria-label="Edit file">${ic('edit')}</button></div>`).join('')+'</div>';
EXT.files=()=>{
  const g={},s=S.settings;S.files.forEach(f=>{const k=cname(f.courseId)||'General';(g[k]=g[k]||[]).push(f)});
  let o=`<div class="card"><div class="row between"><h2>Study files</h2><label class="btn sm pri filebtn">${ic('plus')}Upload<input type="file" id="fup" multiple data-course=""></label></div><label>Put new uploads in<select id="fcourse">${courseOpts().map(x=>`<option value="${x[0]}">${esc(x[1]==='No course'?'General':x[1])}</option>`).join('')}</select></label>
    <p class="muted">Keep new files</p><div class="chips">${[['cloud','In my account'],['phone','On this phone']].map(x=>`<button class="chip${s.fstore===x[0]?' on':''}" data-a="fStore" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>${said('files')}
    <p class="muted"><b>In my account</b> takes PDF, images, text and MP4 up to 20 MB and follows you to any phone. <b>On this phone</b> takes any file, including Word and PowerPoint, up to 100 MB, but it lives in this phone’s browser storage: it will not appear on another device and is lost if the app’s data is cleared. Word and PowerPoint always go to the phone.</p></div>`;
  o+=Object.keys(g).sort().map(k=>`<div class="card"><h3>${esc(k)}</h3>${fileRows(g[k])}</div>`).join('')||`<div class="card">${empty('No files yet','Lecture slides, photos of the board, scanned notes. Each file can belong to a course.')}</div>`;
  return o;
};
EXT.courseFiles=cid=>{const l=S.files.filter(f=>f.courseId===cid);return`<div class="card"><div class="row between"><h2>Files</h2><label class="btn sm pri filebtn">${ic('plus')}Upload<input type="file" id="fup" multiple data-course="${cid}"></label></div>${said('files')}${l.length?fileRows(l):'<p class="muted">Slides, scans and photos for this course.</p>'}</div>`};
async function fileBlob(f){if(f.asset)return(await fetch('/_blob/'+f.asset)).blob();const b=await idbDo('readonly',s=>s.get(f.local));if(!b)throw{code:'gone'};return b}

/* ---------- history without scores ---------- */
EXT.history=()=>{
  const ds=ui.histDay,p=dayParts(ds),d14=[];for(let i=0;i<14;i++)d14.push(addDays(today(),-i));
  const rows=[['Prayers',p.pr?p.pr+' of 5':''],['Water',p.water?p.water+' glasses':''],['Habits',p.hab?p.hab+' of '+S.habits.length:''],['Tasks finished',p.done.map(t=>t.title).join(', ')],['Study time',p.focus?dur(p.focus):''],['Quran',p.quran?p.quran+' ayahs':''],['Sleep',p.sleep?dur(sleepMin(p.sleep))+' ('+tfmt(p.sleep.bed)+' to '+tfmt(p.sleep.wake)+')':''],['Meals',p.meals.map(m=>m.meal+': '+m.text).join(', ')],['Spent',p.spent?money(p.spent):''],['Activities',p.acts.map(a=>a.text).join(', ')],['Medicine doses',p.meds||'']].filter(r=>r[1]!=='');
  return`<div class="card"><h2>History</h2><p class="muted">Every day you used the app is kept. Pick a day to see what you recorded.</p><div class="chips">${d14.map(x=>`<button class="chip${x===ds?' on':''}" data-a="histPick" data-d="${x}">${x===today()?'Today':DAYS[parse(x).getDay()]+' '+parse(x).getDate()}</button>`).join('')}</div></div>
    <div class="card">${dayNav('histDay',ds)}${rows.length?'<div class="list">'+rows.map(r=>`<div class="item"><span class="muted" style="flex:none;width:112px">${r[0]}</span><span class="t grow">${esc(r[1])}</span></div>`).join('')+'</div>':'<p class="muted">Nothing was recorded on this day.</p>'}</div>`;
};
const _set=EXT.settings;
EXT.settings=()=>{const b=bday(),s=S.settings;return`<div class="card">${head('About me',`<button class="btn sm" data-a="welcome">${ic('edit')}Edit</button>`)}<div class="list"><div class="item"><span class="grow muted">Birthday</span><span class="t">${s.dob?fmt(s.dob).replace(/^\w+, /,'')+(b===0?' · today':' · in '+b+' days'):'Not set'}</span></div><div class="item"><span class="grow muted">City for prayer times</span><span class="t">${esc(s.city)}</span></div></div></div>`+_set()+
  `<div class="card"><h2>Permissions</h2><div class="list"><div class="item"><span class="grow"><b>Photos and files</b><br><span class="muted">Your phone asks each time you tap Upload. Nothing is read without that.</span></span></div><div class="item"><span class="grow"><b>Location</b><br><span class="muted">This web app is not allowed to read GPS, so prayer times use the city you choose.</span></span></div><div class="item"><span class="grow"><b>Sound</b><br><span class="muted">Alert sounds play after your first tap in the app. For voice typing, use the microphone key on your keyboard.</span></span></div><div class="item"><span class="grow"><b>Live websites</b><br><span class="muted">The app cannot pull from other websites. Prayer times, Hijri date and the sky on Today are worked out on your phone and renew themselves every day.</span></span></div></div></div>`};

Object.assign(A,{
  welcome(){form(S.settings.setup?'About me':'Welcome to Catalyst',[['name','What should I call you?','text',R],['dob','Date of birth','date'],['city','Your city, for prayer times','select',{opts:Object.keys(CITY).concat('Custom')}],['asr','Asr time','select',{opts:['Hanafi','Shafi']}],['cgBase','Current CGPA (optional)','number'],['cgCred','Credits completed (optional)','number'],['waterGoal','Glasses of water a day','number',R],['sleepBed','Usual bedtime','time',R],['sleepWake','Usual wake-up time','time',R],['email','Email (optional)','text']],S.settings,v=>{
    if(CITY[v.city]){v.lat=CITY[v.city][0];v.lng=CITY[v.city][1]}v.waterGoal=Math.max(1,Math.round(v.waterGoal));v.cgBase=Math.min(4,v.cgBase);v.setup=1;Object.assign(S.settings,v);save('settings')})},
  planDay(){planDay()},
  cgBase(){form('Where I stand now',[['cgBase','Current CGPA','number'],['cgCred','Credits completed','number']],S.settings,v=>{v.cgBase=Math.min(4,v.cgBase);Object.assign(S.settings,v);save('settings')})},
  cgTarget(){form('My target',[['cgTarget','CGPA I want','number',R],['cgRemain','Credits still to take','number',R]],S.settings,v=>{v.cgTarget=Math.min(4,v.cgTarget);Object.assign(S.settings,v);save('settings')})},
  cgRule(d){S.settings.retake=d.v;save('settings');render()},
  giAdd(d){const s=S.sems.find(x=>x.id===d.sem);form('Add grade',A.giFields,{credits:3,grade:'A',old:''},v=>{s.items.push(Object.assign({id:uid()},v));save('sems')})},
  duaLang(d){S.settings.dl=d.v;save('settings');render()},
  fStore(d){S.settings.fstore=d.v;save('settings');render()},
  fEdit(d){const f=S.files.find(x=>x.id===d.id);form('File',[['name','Name','text',R],['courseId','Course','select',{opts:courseOpts()}]],f,v=>{if(ext(v.name)!==ext(f.name))v.name+='.'+ext(f.name);upsert('files',f.id,v)},()=>{remove('files',f.id);if(f.asset){if(AS)AS.delete(f.asset).catch(()=>{})}else idbDo('readwrite',s=>s.delete(f.local)).catch(()=>{})})},
  async fSave(d){const f=S.files.find(x=>x.id===d.id);if(!DL){say('files',f.asset?'Tap the file name to open it.':'Opening phone files is not available in this view.');return}try{await DL.save({filename:f.name,data:await fileBlob(f)});say('files','Saved '+f.name+' to your phone.')}catch(e){say('files',e&&e.code==='gone'?'This file was kept on a different phone, or the app’s storage was cleared.':e&&e.code==='declined'?'Cancelled.':e&&e.code==='rejected_extension'?'This file type cannot be handed to the phone from here.':'Could not open that file.')}}
});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.getAttribute&&e.target.getAttribute('role')==='button'){e.preventDefault();e.target.click()}});
const _ar=window.afterRender;let asked=false;
window.afterRender=function(){_ar();if(cloud!=='loading'&&!S.settings.setup&&!F&&!asked){asked=true;setTimeout(()=>{if(!F&&!S.settings.setup)A.welcome()},600)}};
window.__v3={cg:cg,applyItems:applyItems,bday:bday,HAD:HAD};


/* ================= v4: Catalyst. Biochemistry and biotechnology theme, Lab tab, feedback ================= */
const FB_MAIL='raihan.ndc22@gmail.com';
TABS.push('lab');NAV.splice(3,0,['lab','Lab']);TABL.lab='Lab';
IC.lab='<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3M8 15h8"/>';
SUB.lab=[['calc','Calculators'],['seq','Sequence'],['ref','Reference'],['timers','Timers'],['book','Notebook']];
SUB.more.splice(SUB.more.length-1,0,['feedback','Feedback']);
Object.assign(ui,{lab:'calc',cv:{},fb:{n:'',t:'New feature',m:''}});
ILL.flask='<path d="M18 6h12M20 6v12L9 37a4 4 0 0 0 4 6h22a4 4 0 0 0 4-6L28 18V6z" fill="var(--card)"/><path d="M14 29h20l5 8a4 4 0 0 1-4 6H13a4 4 0 0 1-4-6z" fill="var(--pink)"/><circle cx="21" cy="35" r="1.6"/><circle cx="28" cy="38" r="1.2"/>';
ILL.dna='<path d="M15 5c0 12 18 12 18 19S15 31 15 43" stroke="var(--grape)" stroke-width="3.5"/><path d="M33 5c0 12-18 12-18 19s18 7 18 19" stroke="var(--tomato)" stroke-width="3.5"/><path d="M18 11h12M18 37h12M20 24h8"/>';
MENU.splice(3,0,['Lab',[['lab','lab','calc','Lab calculators','sun'],['lab','lab','seq','Sequence tools','sun'],['lab','lab','ref','Quick reference','sun'],['lab','lab','timers','Lab timers','sun',()=>LT.length||''],['lab','lab','book','Lab notebook','sun',()=>S.notes.filter(n=>n.ref==='lab').length||'']]]);
MENU[MENU.length-1][1].push(['more','more','feedback','Feedback','pink']);
BAN.lab=['sun','flask','Lab bench',()=>LT.length?LT.length+' timer'+(LT.length>1?'s':'')+' running':'Calculators, sequences and quick reference'];
BAN.deen[2]='Assalamu alaikum';

const FACTS=['An adult turns over roughly their own body weight in ATP every day, recycling the same small pool again and again.','The DNA in one human cell is about 2 metres long, with around 3.2 billion base pairs.','Carbonic anhydrase can convert about a million CO₂ molecules every second. It is one of the fastest enzymes known.','Taq polymerase, the enzyme behind PCR, comes from Thermus aquaticus, a bacterium that lives in hot springs.','Insulin was the first protein to be fully sequenced, by Frederick Sanger, and the first medicine made with recombinant DNA.','One haemoglobin molecule carries four O₂ molecules. Binding one makes the next easier, which gives the S-shaped curve.','Mitochondria keep their own small circular DNA, and you inherit it from your mother.','In ideal conditions E. coli divides about every 20 minutes.','Rubisco, the enzyme that fixes CO₂ in plants, is thought to be the most abundant protein on Earth.','The genetic code has 64 codons: 61 code for amino acids and 3 are stop signals.','Glycolysis nets 2 ATP per glucose. Full oxidation in mitochondria yields about 30 to 32.','CRISPR-Cas9 began as a bacterial immune system that cuts the DNA of invading viruses.','Penicillin, noticed by Alexander Fleming in 1928, kills bacteria by blocking cell wall synthesis.','Humans cannot make vitamin C because the gene for the last enzyme in the pathway, L-gulonolactone oxidase, no longer works.'];
const factToday=()=>FACTS[Math.floor(parse(today()).getTime()/864e5)%FACTS.length];

/* ---------- lab calculators ---------- */
const SUP={'-':'⁻','0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'};
const sig=x=>String(Number(Number(x).toPrecision(4)));
const sci=x=>{if(!isFinite(x))return'–';if(x!==0&&(Math.abs(x)>=1e4||Math.abs(x)<1e-2)){const a=x.toExponential(2).split('e');return a[0]+' × 10'+String(+a[1]).split('').map(c=>SUP[c]).join('')}return sig(x)};
const CALC=[
 {id:'mol',t:'Molarity: how much to weigh',f:[['mw','Molecular weight (g/mol)'],['c','Concentration (M)'],['v','Final volume (mL)']],fn:v=>v.mw&&v.c&&v.v?'Weigh '+sig(v.mw*v.c*v.v/1000)+' g and make up to '+sig(v.v)+' mL.':'',n:'mass = M × volume in L × MW'},
 {id:'dil',t:'Dilution: C₁V₁ = C₂V₂',f:[['c1','Stock concentration'],['c2','Final concentration'],['v2','Final volume (mL)']],fn:v=>{if(!(v.c1&&v.c2&&v.v2))return'';if(v.c2>v.c1)return'The final concentration cannot be higher than the stock.';const a=v.c2*v.v2/v.c1;return'Take '+sig(a)+' mL of stock and add '+sig(v.v2-a)+' mL of diluent.'},n:'Use the same unit for both concentrations.'},
 {id:'pct',t:'Percent solution (w/v)',f:[['p','Percent (%)'],['v','Final volume (mL)']],fn:v=>v.p&&v.v?'Dissolve '+sig(v.p*v.v/100)+' g and make up to '+sig(v.v)+' mL.':'',n:'1% w/v is 1 g in 100 mL'},
 {id:'cfu',t:'CFU per mL from a plate count',f:[['n','Colonies counted'],['d','Dilution as a power of ten (4 means 10⁻⁴)'],['v','Volume plated (mL)']],fn:v=>v.n&&v.v?sci(v.n*Math.pow(10,v.d||0)/v.v)+' CFU/mL'+(v.n<30||v.n>300?'. This count is outside 30 to 300, so treat it as an estimate.':''):'',n:'CFU/mL = colonies ÷ (dilution × volume plated)'},
 {id:'na',t:'DNA or RNA concentration from A260',sel:['k','Sample',[['50','Double-stranded DNA'],['40','RNA'],['33','Single-stranded DNA']]],f:[['a','A260 reading'],['df','Dilution factor (1 if undiluted)'],['a280','A280 reading (optional)']],fn:v=>{if(!v.a)return'';const k=v.k||50,c=v.a*k*(v.df||1);let o=sig(c)+' µg/mL';if(v.a280){const r=v.a/v.a280;o+='. A260/A280 = '+r.toFixed(2)+(k===40?(r>=1.9?', clean RNA.':', below 2.0, so check for protein or phenol.'):(r>=1.7&&r<=2?', clean DNA.':r<1.7?', below 1.8, so protein may be present.':', above 2.0, so RNA may be present.'))}return o},n:'A260 of 1.0 is about 50 µg/mL dsDNA, 40 µg/mL RNA or 33 µg/mL ssDNA.'},
 {id:'rcf',t:'Centrifuge: RPM and × g',f:[['r','Rotor radius (cm)'],['rpm','Speed (RPM)'],['g','or the force you want (× g)']],fn:v=>{if(!v.r)return'';if(v.rpm)return sig(1.118e-5*v.r*v.rpm*v.rpm)+' × g';if(v.g)return'Set about '+Math.round(Math.sqrt(v.g/(1.118e-5*v.r)))+' RPM.';return''},n:'RCF = 1.118 × 10⁻⁵ × radius × RPM²'},
 {id:'hh',t:'Buffer pH (Henderson–Hasselbalch)',f:[['pka','pKa'],['a','Base form [A⁻]'],['ha','Acid form [HA]']],fn:v=>v.pka&&v.a&&v.ha?'pH = '+(v.pka+Math.log10(v.a/v.ha)).toFixed(2):'',n:'pH = pKa + log([A⁻] / [HA])'},
 {id:'bl',t:'Beer–Lambert law',f:[['A','Absorbance'],['e','ε (L mol⁻¹ cm⁻¹)'],['l','Path length in cm (1 if blank)']],fn:v=>v.A&&v.e?'c = '+sci(v.A/(v.e*(v.l||1)))+' mol/L':'',n:'A = ε × c × l'}
];
const AM={H:1.008,He:4.0026,Li:6.94,B:10.81,C:12.011,N:14.007,O:15.999,F:18.998,Na:22.99,Mg:24.305,Al:26.982,Si:28.085,P:30.974,S:32.06,Cl:35.45,K:39.098,Ca:40.078,Mn:54.938,Fe:55.845,Co:58.933,Ni:58.693,Cu:63.546,Zn:65.38,Se:78.971,Br:79.904,Mo:95.95,Ag:107.868,I:126.904,Ba:137.327};
function fwGroup(s,i){let m=0;while(i<s.length&&s[i]!==')'){let x;if(s[i]==='('){const r=fwGroup(s,i+1);if(!r||s[r.i]!==')')return null;x=r.m;i=r.i+1}else{const e=/^[A-Z][a-z]?/.exec(s.slice(i));if(!e||!(e[0] in AM))return null;x=AM[e[0]];i+=e[0].length}const n=/^\d+/.exec(s.slice(i));if(n){x*=+n[0];i+=n[0].length}m+=x}return{m:m,i:i}}
function fw(str){let tot=0;for(const part of String(str).replace(/\s/g,'').split(/[.·*+]/)){if(!part)continue;const m=part.match(/^(\d+)(.+)$/),k=m?+m[1]:1,b=m?m[2]:part,r=fwGroup(b,0);if(!r||r.i!==b.length)return null;tot+=k*r.m}return tot||null}
const fwOut=t=>{if(!String(t||'').trim())return'';const m=fw(t);return m?'Molecular weight = '+m.toFixed(2)+' g/mol':'I could not read that formula. Write it like C6H12O6, Ca(OH)2 or CuSO4.5H2O.'};
const cvals=id=>{const o={},c=ui.cv[id]||{};Object.keys(c).forEach(k=>o[k]=num(c[k]));return o};
const CODE='FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',B4='TCAG';
function seqInfo(raw){
  const s=String(raw||'').toUpperCase().replace(/[^A-Z]/g,'').replace(/U/g,'T');
  if(!s)return null;if(/[^ACGTN]/.test(s))return{err:true};
  const n=s.length,gc=(s.match(/[GC]/g)||[]).length,at=(s.match(/[AT]/g)||[]).length,cp={A:'T',T:'A',G:'C',C:'G',N:'N'};
  let p='';for(let i=0;i+2<n;i+=3){const a=B4.indexOf(s[i]),b=B4.indexOf(s[i+1]),c=B4.indexOf(s[i+2]);p+=a<0||b<0||c<0?'X':CODE[a*16+b*4+c]}
  return{n:n,gc:gc/n*100,tm:n<14?2*at+4*gc:64.9+41*(gc-16.4)/n,rc:s.split('').reverse().map(c=>cp[c]).join(''),rna:s.replace(/T/g,'U'),prot:p};
}
const seqOut=raw=>{const q=seqInfo(raw);if(!q)return'<p class="muted">Paste a DNA or RNA sequence above.</p>';if(q.err)return'<p class="muted">Only the letters A, C, G, T or U are allowed.</p>';
  return`<div class="g3">${stat(q.n,'bases')}${stat(q.gc.toFixed(1)+'%','GC content')}${stat(q.tm.toFixed(1)+'°C','Tm, estimate')}</div>`+[['Reverse complement (5′→3′)',q.rc],['mRNA',q.rna],['Protein, reading frame 1'+(q.prot?' · about '+sig(q.prot.replace(/\*/g,'').length*0.11)+' kDa':''),q.prot||'Needs at least 3 bases']].map(r=>`<p class="muted">${r[0]}</p><p class="seq">${r[1]}</p>`).join('')+`<p class="muted">Tm uses the Wallace rule under 14 bases and a GC-based formula above that. * marks a stop codon.</p>`};
const AA=[['Glycine','Gly','G',75.07,'n'],['Alanine','Ala','A',89.09,'n'],['Valine','Val','V',117.15,'n',1],['Leucine','Leu','L',131.17,'n',1],['Isoleucine','Ile','I',131.17,'n',1],['Proline','Pro','P',115.13,'n'],['Phenylalanine','Phe','F',165.19,'n',1],['Tryptophan','Trp','W',204.23,'n',1],['Methionine','Met','M',149.21,'n',1],['Serine','Ser','S',105.09,'p'],['Threonine','Thr','T',119.12,'p',1],['Cysteine','Cys','C',121.16,'p'],['Tyrosine','Tyr','Y',181.19,'p'],['Asparagine','Asn','N',132.12,'p'],['Glutamine','Gln','Q',146.15,'p'],['Aspartate','Asp','D',133.1,'a'],['Glutamate','Glu','E',147.13,'a'],['Lysine','Lys','K',146.19,'b',1],['Arginine','Arg','R',174.2,'b'],['Histidine','His','H',155.16,'b',1]];
const AAC={n:['Nonpolar','sun'],p:['Polar','sky'],a:['Acidic','tomato'],b:['Basic','grape']};
const BUF=[['Citrate','3.13, 4.76, 6.40'],['Acetate','4.76'],['MES','6.1'],['Bicarbonate','6.35'],['Phosphate (pKa₂)','7.21'],['HEPES','7.5'],['Tris','8.1'],['Glycine (amino group)','9.8']];
const NOTES=[['Autoclave','121 °C at 15 psi for 15 to 20 minutes.'],['Gram stain','Crystal violet 1 min, iodine 1 min, alcohol 10 to 20 s, safranin 30 to 60 s. Gram-positive stays purple, Gram-negative turns pink.'],['Countable plate','Use plates with 30 to 300 colonies.'],['PCR cycle','Denature at 94 to 95 °C, anneal at 50 to 65 °C, extend at 72 °C.'],['Disinfecting the bench','70% ethanol works better than 100%.'],['Glycerol stock','Mix culture with sterile glycerol to a final 15 to 25% and store at −80 °C.']];
let LT=[];try{LT=(JSON.parse(localStorage.getItem('catalyst.timers')||'[]')||[]).filter(x=>x&&x.end>Date.now())}catch(e){}
const ltSave=()=>{try{localStorage.setItem('catalyst.timers',JSON.stringify(LT))}catch(e){}};
const ltLeft=x=>{const s=Math.max(0,Math.round((x.end-Date.now())/1000));return(s>=3600?Math.floor(s/3600)+':':'')+pad(Math.floor(s%3600/60))+':'+pad(s%60)};
const LTP=[['Crystal violet',60],['Iodine',60],['Decolorise',15],['Safranin',45],['5 min',300],['10 min',600],['15 min',900],['30 min',1800],['1 hour',3600]];
setInterval(()=>{if(!LT.length)return;const now=Date.now(),doneL=LT.filter(x=>x.end<=now);
  if(doneL.length){LT=LT.filter(x=>x.end>now);ltSave();doneL.forEach(x=>toast({title:x.name+' is done',src:'Lab timer',t:hm(nowMin())}));if(ui.tab==='lab'||ui.tab==='today')render()}
  LT.forEach(x=>{const el=document.getElementById('lt_'+x.id);if(el)el.textContent=ltLeft(x)})},1000);
function vLab(){
  let o=sub('lab',SUB.lab);
  if(ui.lab==='calc'){
    o+=`<div class="card"><h3>Molecular weight from a formula</h3><label>Chemical formula<input data-calc="fw" data-k="f" value="${esc((ui.cv.fw||{}).f||'')}" placeholder="C6H12O6" autocapitalize="off" autocomplete="off" spellcheck="false"></label><p class="res" id="res_fw">${fwOut((ui.cv.fw||{}).f)}</p></div>`;
    o+=CALC.map(c=>{const cur=ui.cv[c.id]||{};return`<div class="card"><h3>${c.t}</h3>${c.sel?`<label>${c.sel[1]}<select data-calc="${c.id}" data-k="${c.sel[0]}">${c.sel[2].map(x=>`<option value="${x[0]}"${String(cur[c.sel[0]]||'')===x[0]?' selected':''}>${x[1]}</option>`).join('')}</select></label>`:''}${c.f.map(f=>`<label>${f[1]}<input inputmode="decimal" data-calc="${c.id}" data-k="${f[0]}" value="${esc(cur[f[0]]||'')}"></label>`).join('')}<p class="res" id="res_${c.id}">${esc(c.fn(cvals(c.id)))}</p><p class="muted">${c.n}</p></div>`}).join('');
  }
  if(ui.lab==='seq')o+=`<div class="card"><h2>Sequence tools</h2><label>DNA or RNA sequence<textarea data-calc="seq" data-k="s" placeholder="ATGGCCATTGTAATGGGCCGCTGA" autocapitalize="characters" autocomplete="off" spellcheck="false">${esc((ui.cv.seq||{}).s||'')}</textarea></label><div id="res_seq">${seqFull((ui.cv.seq||{}).s)}</div></div>
    <div class="card"><h3>Codon table</h3><p class="muted">Read first base down the left, second across the top. DNA letters; T is U in mRNA.</p><div class="codons"><span></span>${B4.split('').map(b=>`<b>${b}</b>`).join('')}${B4.split('').map((a,i)=>`<b>${a}</b>`+B4.split('').map((b,j)=>`<span>${B4.split('').map((c,k)=>a+b+c+' '+CODE[i*16+j*4+k]).join('<br>')}</span>`).join('')).join('')}</div></div>`;
  if(ui.lab==='ref')o+=`<div class="card"><h2>Amino acids</h2><p class="muted">Molecular weights are for the free amino acid. In a protein, count about 110 Da per residue. ★ marks the essential ones.</p><div class="list">${AA.map(a=>`<div class="item"><span class="pill col c-${AAC[a[4]][1]}" style="width:26px;text-align:center;padding:1px 0">${a[2]}</span><span class="t grow">${a[0]}${a[5]?' ★':''}<br><span class="muted">${a[1]} · ${AAC[a[4]][0]}</span></span><span class="muted">${a[3].toFixed(2)}</span></div>`).join('')}</div></div>
    <div class="card"><h2>Buffer pKa values</h2><p class="muted">Approximate, at 25 °C. A buffer works best within one pH unit of its pKa.</p><div class="list">${BUF.map(b=>`<div class="item"><span class="t grow">${b[0]}</span><span class="muted">${b[1]}</span></div>`).join('')}</div></div>
    <div class="card"><h2>Bench notes</h2><div class="list">${NOTES.map(n=>`<div class="item"><span class="grow"><b>${n[0]}</b><br><span class="muted">${n[1]}</span></span></div>`).join('')}</div><p class="muted">These are common textbook values. Your lab manual and instructor come first.</p></div>`;
  if(ui.lab==='timers')o+=`<div class="card">${head('Lab timers',addBtn('ltAdd','Custom'))}<p class="muted">Start several at once for staining, incubation or spinning. They ring while the app is open.</p><div class="chips" style="flex-wrap:wrap;overflow:visible">${LTP.map(p=>`<button class="chip" data-a="ltGo" data-n="${p[1]}" data-name="${p[0]}">${p[0]}${p[1]<300?' · '+p[1]+' s':''}</button>`).join('')}</div>${LT.length?'<div class="list">'+LT.map(x=>`<div class="item"><span class="t grow">${esc(x.name)}</span><span class="big" style="font-size:24px" id="lt_${x.id}">${ltLeft(x)}</span><button class="btn sm danger" data-a="ltStop" data-id="${x.id}" aria-label="Cancel timer">×</button></div>`).join('')+'</div>':'<p class="muted">No timer is running.</p>'}</div>`;
  if(ui.lab==='book')o+=`<div class="card">${head('Lab notebook',addBtn('nAdd','Entry',' data-ref="lab"'))}${noteList('lab')}<p class="muted">Write each practical as you do it: date, aim, samples, what you saw, result. Notes for a research project live inside that project in Study.</p></div>`;
  return o;
}
VIEWS.lab=()=>`<div class="banner b-sun">${ill(BAN.lab[1])}<div><b>${BAN.lab[2]}</b><span>${esc(BAN.lab[3]())}</span></div></div>`+vLab();
document.addEventListener('input',e=>{
  const t=e.target,id=t.dataset&&t.dataset.calc;
  if(id){(ui.cv[id]=ui.cv[id]||{})[t.dataset.k]=t.value;const r=document.getElementById('res_'+id);if(!r)return;if(id==='seq')r.innerHTML=seqFull(t.value);else if(id==='fw')r.textContent=fwOut(t.value);else{const c=CALC.find(c=>c.id===id);if(c)r.textContent=c.fn(cvals(id),ui.cv[id]||{})}}
  if(t.dataset&&t.dataset.fb){ui.fb[t.dataset.fb]=t.value;fbLinks()}
});
document.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.calc&&t.tagName==='SELECT'){(ui.cv[t.dataset.calc]=ui.cv[t.dataset.calc]||{})[t.dataset.k]=t.value;const r=document.getElementById('res_'+t.dataset.calc);const c=CALC.find(c=>c.id===t.dataset.calc);if(r&&c)r.textContent=c.fn(cvals(t.dataset.calc),ui.cv[t.dataset.calc]||{})}if(t.dataset&&t.dataset.fb){ui.fb[t.dataset.fb]=t.value;fbLinks()}});

/* ---------- deen extras ---------- */
const JUM=[['ghusl','Take a bath and wear clean clothes'],['kahf','Recite Surah Al-Kahf'],['durood','Send plenty of durood on the Prophet ﷺ'],['early','Go early for Jumu‘ah'],['dua','Make dua in the last hour before Maghrib']];
EXT.prayer=()=>{
  const t=today(),dow=new Date().getDay(),l=S.dhikr[t]||{},tips=[];let hd=0;
  hd=hijriDay();
  if(dow===1||dow===4)tips.push('Today is '+DAYSL[dow]+', a sunnah day to fast.');
  if(dow===0||dow===3)tips.push('Tomorrow is '+DAYSL[dow+1]+', a sunnah day to fast.');
  if(hd>=13&&hd<=15)tips.push('By the calendar this is one of the white days (13, 14, 15). Fasting them is sunnah. Confirm the date with your local moon sighting.');
  let o='';
  if(dow===5)o+=`<div class="card c-leaf star"><h2>Jumu‘ah Mubarak</h2><div class="list">${JUM.map(j=>`<div class="item">${chk(l['jum_'+j[0]],'jumTog',`data-id="${j[0]}"`,j[1])}<span class="t grow">${j[1]}</span></div>`).join('')}</div><p class="muted"><a href="https://quran.com/18" target="_blank" rel="noopener">Open Surah Al-Kahf</a></p></div>`;
  if(tips.length)o+=`<div class="card"><h3>Sunnah for today</h3>${tips.map(x=>`<p>${x}</p>`).join('')}</div>`;
  return o;
};
const _deen=VIEWS.deen;
VIEWS.deen=()=>`<p class="ar bism" lang="ar">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>`+_deen();

/* ---------- feedback ---------- */
const CREDIT=`App developed by <a href="https://www.facebook.com/share/1FQERoNhgz/" target="_blank" rel="noopener"><b>Md. Raihan Mehedi</b></a><span>Undergraduate Student, Department of Biochemistry &amp; Biotechnology, North South University</span>`;
const fbText=()=>'Feedback type: '+ui.fb.t+'\nFrom: '+(ui.fb.n||S.settings.name||'A user')+'\n\n'+ui.fb.m;
const fbSubject=()=>'Catalyst app feedback: '+ui.fb.t;
function fbLinks(){const a=document.getElementById('fbsend'),b=document.getElementById('fbmail');if(a)a.href=gm({to:FB_MAIL,su:fbSubject(),body:fbText()});if(b)b.href='mailto:'+FB_MAIL+'?subject='+encodeURIComponent(fbSubject())+'&body='+encodeURIComponent(fbText())}
EXT.feedback=()=>`<div class="card b-pink"><div class="row">${ill('mail')}<div class="grow"><h2>Help improve Catalyst</h2><p class="muted">Tell the developer what to add, change or fix.</p></div></div></div>
  <div class="card"><label>Your name<input data-fb="n" id="fb_n" value="${esc(ui.fb.n||S.settings.name||'')}" autocomplete="name"></label><label>What is it about?<select data-fb="t" id="fb_t">${['New feature','Change something','Something is broken','Other'].map(x=>`<option${ui.fb.t===x?' selected':''}>${x}</option>`).join('')}</select></label><label>Your feedback<textarea data-fb="m" id="fb_m" placeholder="What would make this app more useful for you?">${esc(ui.fb.m)}</textarea></label>
  <div class="row wrap"><a class="btn pri" id="fbsend" href="${gm({to:FB_MAIL,su:fbSubject(),body:fbText()})}" target="_blank" rel="noopener">Send with Gmail</a><a class="btn" id="fbmail" href="mailto:${FB_MAIL}?subject=${encodeURIComponent(fbSubject())}&body=${encodeURIComponent(fbText())}">Other mail app</a><button class="btn" data-a="fbCopy">Copy</button></div>${said('fb')}
  <p class="muted">Your mail app opens with the message written and addressed to <b>${FB_MAIL}</b>. Tap send there to deliver it. If nothing opens, copy the message and mail it to that address.</p></div>`;

Object.assign(A,{
  ltGo(d){LT.push({id:uid(),name:d.name,end:Date.now()+(+d.n)*1000});ltSave();render()},
  ltAdd(){form('Custom timer',[['name','What is it for?','text',{req:true,ph:'Incubation, centrifuge, water bath'}],['min','Minutes','number',R]],{},v=>{if(v.min>0){LT.push({id:uid(),name:v.name,end:Date.now()+v.min*60000});ltSave()}})},
  ltStop(d){LT=LT.filter(x=>x.id!==d.id);ltSave();render()},
  jumTog(d){const l=S.dhikr[today()]=S.dhikr[today()]||{},k='jum_'+d.id;if(l[k])delete l[k];else l[k]=1;save('dhikr');render()},
  fbCopy(){try{navigator.clipboard.writeText(fbText()).then(()=>say('fb','Copied. Paste it into a mail to '+FB_MAIL+'.'),()=>say('fb','Copying was blocked here.'))}catch(e){say('fb','Copying was blocked here.')}}
});
window.__v4={fw:fw,seqInfo:seqInfo,CALC:CALC,sci:sci};


/* ================= v5: personalisation, motion, celebration, richer lab ================= */
Object.assign(DEF_SET,{mode:'auto',motion:'full',big:0,intro:1,noRow:0,deenOff:0,tilesOff:{quran:1,food:1}});
normalize();
Object.assign(ui,{lcat:'All',cmode:'std',mt:{},rv:1000});
ILL.bowl='<path d="M6 24h36a18 18 0 0 1-36 0z" fill="var(--tomato)"/><path d="M18 17c0-4 4-4 4-8M27 17c0-4 4-4 4-8"/>';
ILL.scope='<path d="M19 8l8 4-9 18-8-4z" fill="var(--sky)"/><path d="M14 40h22M24 40V30M30 34a11 11 0 0 0 0-18"/><circle cx="14" cy="33" r="3" fill="var(--sun)"/>';
SUB.lab.splice(0,SUB.lab.length,['calc','Calculators'],['curve','Curves'],['microbe','Microbes'],['recipes','Recipes'],['seq','Sequence'],['ref','Reference'],['timers','Timers'],['book','Notebook']);
SUB.more.splice(SUB.more.length-1,0,['look','Personalise']);
MENU.find(g=>g[0]==='Lab')[1].splice(1,0,['lab','lab','curve','Standard curves','sun'],['lab','lab','microbe','Bacteria finder','sun'],['lab','lab','recipes','Media and buffers','sun']);
MENU[MENU.length-1][1].push(['more','more','look','Personalise','pink']);

/* ---------- look and feel ---------- */
function applyLook(){
  const s=S.settings,r=document.documentElement;let changed=false;
  if(s.mode==='light'||s.mode==='dark')r.dataset.mode=s.mode;else delete r.dataset.mode;
  r.dataset.motion=s.motion||'full';
  if(s.big)r.dataset.big='1';else delete r.dataset.big;
  try{localStorage.setItem('catalyst.intro',s.intro===0?'0':'1')}catch(e){}
  const i=NAV.findIndex(x=>x[0]==='deen');
  if(s.deenOff&&i>=0){NAV.splice(i,1);changed=true;if(ui.tab==='deen')ui.tab='today'}
  if(!s.deenOff&&i<0){NAV.splice(NAV.findIndex(x=>x[0]==='life'),0,['deen','Deen']);changed=true}
  return changed;
}
const _ar5=window.afterRender;
window.afterRender=function(){if(applyLook()){render();return}_ar5()};
const pick=(k,opts)=>`<div class="chips">${opts.map(x=>`<button class="chip${String(S.settings[k])===String(x[0])?' on':''}" data-a="setPick" data-k="${k}" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`;
const TILES=[['water','Water'],['money','Money'],['tasks','Tasks'],['class','Next class'],['sleep','Sleep'],['habits','Habits'],['focus','Study time'],['exam','Exam, or medicine when sick'],['lab','Lab'],['quran','Quran'],['food','Meals']];
function homeTiles(){
  const t=today(),s=S.settings,d=new Date(),n=nowMin(),off=s.tilesOff||{},out=m=>m.type!=='in',ep=activeEp();
  const M={
    water:()=>tile('sky wave" style="--fill:'+Math.min(100,(S.water[t]||0)/s.waterGoal*100)+'%','drop',(S.water[t]||0)+'/'+s.waterGoal,'Water','life','life','water',`<button class="tplus" data-a="water" data-n="1" aria-label="Add one glass">+</button>`),
    money:()=>{const sp=S.money.filter(m=>m.date===t&&out(m)).reduce((a,m)=>a+m.amount,0),mo=S.money.filter(m=>m.date.slice(0,7)===t.slice(0,7)&&out(m)).reduce((a,m)=>a+m.amount,0);return tile('leaf','wallet',money(sp),s.budget?money(Math.max(0,s.budget-mo))+' left':'Spent today','life','life','money',`<button class="tplus" data-a="mAdd" aria-label="Add money entry">+</button>`)},
    tasks:()=>{const c=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t).length;return tile('tomato','tasks',c,c?'Tasks due':'All clear','plan','plan','tasks')},
    class:()=>{const cls=S.routine.filter(r=>+r.day===d.getDay()).sort(byStart),nc=cls.find(r=>toMin(r.start)>=n);return tile('grape','book',nc?tfmt(nc.start).replace(/ ([AP])M/,'$1'):cls.length?'Done':'–',nc?rName(nc):cls.length?'Classes over':'No class today','plan','plan','routine')},
    sleep:()=>{const sl=S.sleep.find(l=>l.date===t);return tile('sun','moon',sl?dur(sleepMin(sl)).replace(' ',''):'–',sl?'Slept':'Sleep not logged','life','life','sleep')},
    habits:()=>{const hl=S.habitLog[t]||{};return tile('leaf','sprout',S.habits.filter(x=>hl[x.id]).length+'/'+S.habits.length,'Habits','life','life','habits')},
    focus:()=>tile('pink','timer',S.focus.filter(f=>f.date===t).reduce((a,f)=>a+f.min,0)+'m','Study time','study','study','timer'),
    exam:()=>{if(ep){const l=doses(ep,t).filter(x=>!x.taken).length;return tile('tomato','pill',l,l?'Doses left':'Medicine done','life','life','health')}const nx=S.exams.filter(e=>e.date>=t).sort((a,b)=>a.date<b.date?-1:1)[0];return tile('sun','exam',nx?diffDays(nx.date,t)+'d':'–',nx?nx.title:'No exam set','study','study','exams')},
    lab:()=>tile('grape','flask',LT.length||'Lab',LT.length?'Timers running':'Bench tools','lab','lab',LT.length?'timers':'calc'),
    quran:()=>tile('leaf','quran',(QN().log[t]||0)+'/'+s.qgoal,'Ayahs today','deen','deen','quran'),
    food:()=>tile('tomato','bowl',S.meals.filter(m=>m.date===t).length,'Meals logged','life','life','food')
  };
  return'<div class="tiles">'+TILES.filter(x=>!off[x[0]]&&!(x[0]==='quran'&&s.deenOff)).map(x=>M[x[0]]()).join('')+'</div>';
}
EXT.look=()=>{const s=S.settings,off=s.tilesOff||{};return`<div class="card"><h2>Appearance</h2><p class="muted">Light or dark</p>${pick('mode',[['auto','Match my phone'],['light','Light'],['dark','Dark']])}<p class="muted">Movement of icons and screens</p>${pick('motion',[['full','Lively'],['calm','Calm'],['off','Still']])}<p class="muted">Text size</p>${pick('big',[[0,'Normal'],[1,'Large']])}</div>
  <div class="card"><h2>Opening</h2><div class="list"><div class="item">${chk(s.intro!==0,'setFlag','data-id="intro" data-on="1"','Play the logo intro')}<span class="t grow">Play the logo intro when the app opens</span></div></div><button class="btn sm" data-a="welcome" style="align-self:flex-start">${ic('edit')}Change my name and details</button><button class="btn sm" data-a="obAgain" style="align-self:flex-start">Run the welcome setup again</button></div>
  <div class="card"><h2>Home screen</h2><p class="muted">Choose what appears on Today.</p><div class="list">${TILES.map(x=>`<div class="item">${chk(!off[x[0]],'tileTog',`data-id="${x[0]}"`,x[1])}<span class="t grow">${x[1]}</span></div>`).join('')}<div class="item">${chk(!s.noRow,'setFlag','data-id="noRow"','Prayer row')}<span class="t grow">Row of the five prayers</span></div></div></div>
  <div class="card"><h2>Sections</h2><div class="list"><div class="item">${chk(!s.deenOff,'setFlag','data-id="deenOff"','Deen section')}<span class="t grow">Show the Deen section<br><span class="muted">Turn off to hide prayers, Quran and duas everywhere.</span></span></div></div></div>`};
function celebrate(msg){
  toast({title:msg,src:'Well done',t:hm(nowMin())});
  if(S.settings.motion==='off')return;
  const box=document.createElement('div');box.className='confetti';
  box.innerHTML=Array.from({length:26},(x,i)=>`<i style="left:${(i*37)%100}%;background:var(--${COLORS[i%6]});animation-delay:${(i%9)*70}ms;animation-duration:${1400+(i%5)*220}ms"></i>`).join('');
  document.body.appendChild(box);setTimeout(()=>box.remove(),2800);
}
const _water=A.water,_prTog=A.prTog,_hDay=A.hDay;

/* ---------- more lab calculators ---------- */
const CAT={mol:'Solutions',dil:'Solutions',pct:'Solutions',hh:'Solutions',cfu:'Microbiology',na:'Molecular',rcf:'Molecular',bl:'Analysis'};
CALC.forEach(c=>{c.g=CAT[c.id]});
const UNIT={kg:['m',1e3],g:['m',1],mg:['m',1e-3],'µg':['m',1e-6],ng:['m',1e-9],L:['v',1],mL:['v',1e-3],'µL':['v',1e-6],M:['c',1],mM:['c',1e-3],'µM':['c',1e-6],nM:['c',1e-9]},UO=Object.keys(UNIT).map(u=>[u,u]);
CALC.push(
 {id:'conv',g:'Solutions',t:'Unit converter',sels:[['from','From',UO],['to','To',UO]],f:[['x','Value']],fn:(v,r)=>{const a=UNIT[r.from||'kg'],b=UNIT[r.to||'kg'];if(!r.x)return'';if(a[0]!==b[0])return'Pick two units of the same kind: mass, volume or concentration.';return sci(v.x*a[1]/b[1])+' '+(r.to||'kg')},n:'Mass kg to ng, volume L to µL, concentration M to nM.'},
 {id:'m2c',g:'Solutions',t:'mg/mL and molarity',f:[['mw','Molecular weight (g/mol)'],['mg','Concentration (mg/mL)'],['M','or concentration (M)']],fn:v=>!v.mw?'':v.mg?sci(v.mg/v.mw)+' M':v.M?sci(v.M*v.mw)+' mg/mL':'',n:'M = (mg/mL) ÷ MW'},
 {id:'ser',g:'Microbiology',t:'Serial dilution planner',f:[['f','Dilution each step (10 for ten-fold)'],['n','Number of tubes'],['v','Final volume in each tube (mL)']],fn:v=>{if(!(v.f>1&&v.n&&v.v))return'';const a=v.v/v.f,n=Math.min(12,Math.round(v.n));return'Put '+sig(v.v-a)+' mL of diluent in each of '+n+' tubes. Move '+sig(a)+' mL from the sample into tube 1, mix, then '+sig(a)+' mL from each tube to the next. Last tube is diluted '+sci(Math.pow(v.f,n))+' times.'},n:'Change tips between tubes and mix well each time.'},
 {id:'gen',g:'Microbiology',t:'Generation time',f:[['n0','Cells at the start (N₀)'],['n1','Cells at the end (N)'],['t','Time between them (minutes)']],fn:v=>{if(!(v.n0&&v.n1>v.n0&&v.t))return'';const n=Math.log2(v.n1/v.n0);return sig(n)+' generations. Generation time '+sig(v.t/n)+' min. Growth rate '+sig(n/(v.t/60))+' per hour.'},n:'n = log₂(N ÷ N₀), g = t ÷ n'},
 {id:'hemo',g:'Microbiology',t:'Haemocytometer cell count',f:[['c','Cells counted'],['q','Large squares counted'],['d','Dilution factor (1 if undiluted)']],fn:v=>v.c&&v.q?sci(v.c/v.q*(v.d||1)*1e4)+' cells/mL':'',n:'Each large square is 1 mm² × 0.1 mm deep, so × 10⁴ gives per mL.'},
 {id:'te',g:'Molecular',t:'Transformation efficiency',f:[['c','Colonies on the plate'],['ng','DNA used (ng)'],['fr','Fraction of the mix plated (0.1 for one tenth)']],fn:v=>v.c&&v.ng?sci(v.c/(v.ng*(v.fr||1))*1000)+' CFU per µg DNA':'',n:'colonies ÷ ng plated × 1000'},
 {id:'pcr',g:'Molecular',t:'PCR master mix',f:[['n','Number of reactions'],['v','Reaction volume (µL), usually 25'],['p','Each primer per reaction (µL)'],['t','Template per reaction (µL)']],fn:v=>{if(!(v.n&&v.v))return'';const k=v.n*1.1,p=v.p||1,t=v.t||1,w=v.v-v.v/2-2*p-t;if(w<0)return'Those volumes add up to more than the reaction volume.';return'For '+v.n+' reactions plus 10% spare: '+sig(v.v/2*k)+' µL 2× master mix, '+sig(p*k)+' µL forward primer, '+sig(p*k)+' µL reverse primer, '+sig(w*k)+' µL water. Put '+sig(v.v-t)+' µL in each tube, then add '+sig(t)+' µL template.'},n:'Assumes a ready 2× master mix. Follow your kit sheet if it differs.'},
 {id:'lig',g:'Molecular',t:'Ligation: how much insert',f:[['vn','Vector (ng)'],['vb','Vector size (bp)'],['ib','Insert size (bp)'],['r','Insert to vector ratio (3 for 3:1)']],fn:v=>v.vn&&v.vb&&v.ib?'Use '+sig(v.vn*v.ib/v.vb*(v.r||3))+' ng of insert.':'',n:'ng insert = ng vector × (insert bp ÷ vector bp) × ratio'}
);
const calcCard=c=>{const cur=ui.cv[c.id]||{},sels=c.sels||(c.sel?[c.sel]:[]);return`<details class="card calc" data-name="${esc((c.t+' '+c.g).toLowerCase())}"${Object.keys(cur).length?' open':''}><summary><span class="pill">${c.g}</span><h3>${c.t}</h3></summary>${sels.map(x=>`<label>${x[1]}<select data-calc="${c.id}" data-k="${x[0]}">${x[2].map(o=>`<option value="${o[0]}"${String(cur[x[0]]||'')===o[0]?' selected':''}>${o[1]}</option>`).join('')}</select></label>`).join('')}${c.f.map(f=>`<label>${f[1]}<input inputmode="decimal" data-calc="${c.id}" data-k="${f[0]}" value="${esc(cur[f[0]]||'')}"></label>`).join('')}<p class="res" id="res_${c.id}">${esc(c.fn(cvals(c.id),cur))}</p><p class="muted">${c.n}</p></details>`};

/* ---------- curves: standard curve and enzyme kinetics ---------- */
const parsePts=txt=>String(txt||'').split(/\n/).map(l=>(l.match(/-?\d*\.?\d+(?:e-?\d+)?/gi)||[]).map(Number)).filter(a=>a.length>=2).map(a=>[a[0],a[1]]);
function fit(pts){const n=pts.length;if(n<2)return null;let sx=0,sy=0,sxx=0,sxy=0,syy=0;pts.forEach(p=>{sx+=p[0];sy+=p[1];sxx+=p[0]*p[0];sxy+=p[0]*p[1];syy+=p[1]*p[1]});const d=n*sxx-sx*sx;if(!d)return null;const m=(n*sxy-sx*sy)/d,b=(sy-m*sx)/n,sst=syy-sy*sy/n,sse=pts.reduce((a,p)=>a+Math.pow(p[1]-(m*p[0]+b),2),0);return{m:m,b:b,r2:sst>0?1-sse/sst:1}}
function plot(pts,f,xl,yl){
  const xs=pts.map(p=>p[0]).concat(0),ys=pts.map(p=>p[1]).concat(0,f.b),x0=Math.min.apply(null,xs),x1=Math.max.apply(null,xs),y0=Math.min.apply(null,ys),y1=Math.max.apply(null,ys.concat(f.m*x1+f.b));
  const X=x=>34+(x-x0)/((x1-x0)||1)*250,Y=y=>150-(y-y0)/((y1-y0)||1)*132;
  return`<svg class="plot" viewBox="0 0 300 180" role="img" aria-label="Plot of the points and the fitted line"><path d="M34 12v138h256" fill="none" stroke="var(--muted)" stroke-width="1.5"/><path class="fitline" d="M${X(x0)} ${Y(f.m*x0+f.b)}L${X(x1)} ${Y(f.m*x1+f.b)}" fill="none" stroke="var(--grape)" stroke-width="3" stroke-linecap="round"/>${pts.map(p=>`<circle cx="${X(p[0]).toFixed(1)}" cy="${Y(p[1]).toFixed(1)}" r="4.5" fill="var(--tomato)" stroke="var(--ill)" stroke-width="1.5"/>`).join('')}<text x="162" y="174" text-anchor="middle" font-size="11" fill="var(--muted)">${xl}</text><text x="12" y="84" text-anchor="middle" font-size="11" fill="var(--muted)" transform="rotate(-90 12 84)">${yl}</text></svg>`;
}
function curveOut(){
  const c=ui.cv.curve||{},raw=parsePts(c.pts),lb=ui.cmode==='lb';
  if(raw.length<2)return`<p class="muted">Enter at least two points, one per line. Three or more gives a real check of the fit.</p>`;
  if(lb){const p=raw.filter(a=>a[0]>0&&a[1]>0).map(a=>[1/a[0],1/a[1]]),f=fit(p);if(!f||f.b<=0)return`<p class="muted">These points do not give a usable Lineweaver–Burk line. Check for zero or negative values.</p>`;
    return plot(p,f,'1 / [S]','1 / v')+`<div class="g3">${stat(sci(1/f.b),'Vmax')}${stat(sci(f.m/f.b),'Km')}${stat(f.r2.toFixed(4),'R²')}</div><p class="muted">Line: 1/v = ${sci(f.m)} × 1/[S] + ${sci(f.b)}. Vmax is in your v units, Km in your [S] units.</p>`}
  const f=fit(raw);if(!f)return`<p class="muted">All the x values are the same, so no line can be drawn.</p>`;
  const u=String(c.u||'').trim()===''?null:num(c.u);
  return plot(raw,f,'concentration (x)','reading (y)')+`<div class="g3">${stat(sci(f.m),'slope')}${stat(sci(f.b),'intercept')}${stat(f.r2.toFixed(4),'R²')}</div><p class="res">${u==null||!f.m?'':'Unknown concentration = '+sci((u-f.b)/f.m)}</p><p class="muted">y = ${sci(f.m)}x ${f.b<0?'−':'+'} ${sci(Math.abs(f.b))}${f.r2<0.98?'. R² is below 0.98, so re-check your standards.':''}</p>`;
}

/* ---------- bacteria finder ---------- */
const BT=[['gram','Gram'],['cat','Catalase'],['ox','Oxidase'],['ind','Indole'],['mr','Methyl red'],['vp','VP'],['cit','Citrate'],['ure','Urease'],['h2s','H₂S'],['lac','Lactose'],['mot','Motility']];
const ORG=[['Escherichia coli','Rod','-+-++----++'],['Klebsiella pneumoniae','Rod, capsule','-+---+++-+-'],['Enterobacter aerogenes','Rod','-+---++--++'],['Citrobacter freundii','Rod','-+--+-+v+v+'],['Salmonella enterica (non-typhoidal)','Rod','-+--+-+-+-+'],['Shigella species','Rod','-+-v+------'],['Proteus mirabilis','Rod, swarms on agar','-+--+vv++-+'],['Serratia marcescens','Rod, may be red','-+--v++v--+'],['Pseudomonas aeruginosa','Rod, green pigment','-++---+v--+'],['Staphylococcus aureus','Cocci in clusters','++--++v+-+-'],['Bacillus subtilis','Rod with spores','++v--++---+']];
function orgRank(){
  const picked=BT.map(t=>ui.mt[t[0]]||'');
  return ORG.map(o=>{let hit=0,miss=0;picked.forEach((p,i)=>{if(!p||o[2][i]==='v')return;if(p===o[2][i])hit++;else miss++});return{o:o,hit:hit,miss:miss}}).sort((a,b)=>(a.miss-b.miss)||(b.hit-a.hit));
}
/* ---------- recipes ---------- */
const REC=[['LB broth (Miller)','Autoclave. For LB agar add 15 g agar per litre.',[['Tryptone',10,'g'],['Yeast extract',5,'g'],['NaCl',10,'g']]],['Nutrient broth','For nutrient agar add 15 g agar per litre. pH about 7.',[['Peptone',5,'g'],['Beef extract',3,'g'],['NaCl',5,'g']]],['Peptone water','Autoclave before use.',[['Peptone',10,'g'],['NaCl',5,'g']]],['Normal saline, 0.85%','Used for dilutions of bacterial samples.',[['NaCl',8.5,'g']]],['PBS, 1×, pH 7.4','Adjust pH to 7.4 before making up the volume.',[['NaCl',8,'g'],['KCl',0.2,'g'],['Na₂HPO₄',1.44,'g'],['KH₂PO₄',0.24,'g']]],['TAE buffer, 50× stock','Dilute 1 in 50 to make 1× for gels.',[['Tris base',242,'g'],['Glacial acetic acid',57.1,'mL'],['0.5 M EDTA, pH 8.0',100,'mL']]],['TBE buffer, 10× stock','Dilute 1 in 10, or 1 in 20 for 0.5×.',[['Tris base',108,'g'],['Boric acid',55,'g'],['0.5 M EDTA, pH 8.0',40,'mL']]],['TE buffer','10 mM Tris, 1 mM EDTA, for storing DNA.',[['1 M Tris-HCl, pH 8.0',10,'mL'],['0.5 M EDTA, pH 8.0',2,'mL']]],['1 M Tris-HCl','Dissolve in less water, set the pH with HCl, then make up.',[['Tris base',121.1,'g']]],['0.5 M EDTA, pH 8.0','It dissolves only as the pH nears 8. Add NaOH slowly.',[['Na₂EDTA·2H₂O',186.1,'g']]],['Agarose gel, 1%','Dissolve in 1× TAE or TBE by heating. Use 0.8% for large DNA, 2% for small.',[['Agarose',10,'g']]],['70% ethanol from 95%','Make up to the final volume with distilled water.',[['95% ethanol',737,'mL']]]];
const LABT='Date: \nPractical: \n\nAim:\n\nPrinciple:\n\nMaterials:\n\nProcedure:\n\nObservation:\n\nResult:\n\nDiscussion:\n\nPrecautions:\n';
const _vLab4=vLab;
VIEWS.lab=()=>{
  const ban=`<div class="banner b-sun">${ill(ui.lab==='microbe'?'scope':ui.lab==='seq'?'dna':'flask')}<div><b>${BAN.lab[2]}</b><span>${esc(BAN.lab[3]())}</span></div></div>`;
  if(['seq','ref','timers'].includes(ui.lab))return ban+_vLab4()+(EXT['lab_'+ui.lab]?EXT['lab_'+ui.lab]():'');
  let o=ban+sub('lab',SUB.lab);
  if(ui.lab==='calc'){
    const cats=['All','Solutions','Microbiology','Molecular','Analysis'];
    o+=`<input data-c="labq" placeholder="Search calculators" aria-label="Search calculators"><div class="chips">${cats.map(x=>`<button class="chip${ui.lcat===x?' on':''}" data-a="lcat" data-v="${x}">${x}</button>`).join('')}</div>`;
    if(ui.lcat==='All'||ui.lcat==='Solutions')o+=`<details class="card calc" data-name="molecular weight formula solutions"${(ui.cv.fw||{}).f?' open':''}><summary><span class="pill">Solutions</span><h3>Molecular weight from a formula</h3></summary><label>Chemical formula<input data-calc="fw" data-k="f" value="${esc((ui.cv.fw||{}).f||'')}" placeholder="C6H12O6" autocapitalize="off" autocomplete="off" spellcheck="false"></label><p class="res" id="res_fw">${fwOut((ui.cv.fw||{}).f)}</p></details>`;
    o+=CALC.filter(c=>ui.lcat==='All'||c.g===ui.lcat).map(calcCard).join('')+`<p class="muted">Tap a calculator to open it. Results update as you type.</p>`;
  }
  if(ui.lab==='curve'){const c=ui.cv.curve||{};o+=`<div class="card"><h2>Fit a line to your data</h2><div class="chips">${[['std','Standard curve'],['lb','Enzyme kinetics'],['stats','Replicates']].map(x=>`<button class="chip${ui.cmode===x[0]?' on':''}" data-a="cmode" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">${ui.cmode==='stats'?'Paste your repeated readings to get the mean, standard deviation and more.':ui.cmode==='lb'?'Type substrate concentration and rate on each line. The app draws the Lineweaver–Burk plot and gives Km and Vmax.':'For Bradford, Lowry, DNS or any colour assay. Type concentration and absorbance on each line.'}</p><label>${ui.cmode==='lb'?'[S], v':ui.cmode==='stats'?'Your replicate readings':'Concentration, reading'}<textarea data-calc="curve" data-k="pts" inputmode="text" placeholder="${ui.cmode==='lb'?'1, 3.33\n2, 5.0\n4, 6.67\n8, 8.0':'0, 0.02\n0.2, 0.21\n0.4, 0.43\n0.8, 0.82'}" spellcheck="false">${esc(c.pts||'')}</textarea></label>${ui.cmode!=='std'?'':`<label>Reading of your unknown<input inputmode="decimal" data-calc="curve" data-k="u" value="${esc(c.u||'')}"></label>`}<div id="res_curve">${curveOut()}</div></div>`}
  if(ui.lab==='microbe'){const rk=orgRank(),any=BT.some(t=>ui.mt[t[0]]);o+=`<div class="card"><div class="row between"><h2>Bacteria finder</h2><button class="btn sm" data-a="mtReset">Clear</button></div><p class="muted">Tap each test you have done until it shows your result. The list below sorts itself by best match.</p><div class="mtests">${BT.map(t=>{const v=ui.mt[t[0]]||'';return`<button class="mt${v==='+'?' pos':v==='-'?' neg':''}" data-a="mtTog" data-id="${t[0]}" aria-label="${t[1]}: ${v==='+'?'positive':v==='-'?'negative':'not done'}"><b>${v||'?'}</b>${t[1]}</button>`}).join('')}</div></div>`+
    rk.map((r,i)=>`<div class="card${any&&i===0&&!r.miss&&r.hit?' c-leaf':''}"><div class="row between"><h3><i>${r.o[0]}</i></h3>${any?`<span class="pill">${r.hit} match${r.hit===1?'':'es'}${r.miss?', '+r.miss+' against':''}</span>`:''}</div><p class="muted">${r.o[1]}</p><div class="orow">${BT.map((t,j)=>`<span class="${r.o[2][j]==='+'?'pos':r.o[2][j]==='-'?'neg':''}${ui.mt[t[0]]&&r.o[2][j]!=='v'&&ui.mt[t[0]]!==r.o[2][j]?' no':''}">${t[1]} ${r.o[2][j]==='v'?'±':r.o[2][j]==='-'?'−':'+'}</span>`).join('')}</div></div>`).join('')+`<p class="muted">These are typical textbook reactions for common species. Strains vary (± means variable), and many bacteria are not listed. Confirm with Bergey’s Manual and your instructor before reporting an identification.</p>`}
  if(ui.lab==='recipes')o+=`<div class="card"><h2>Media and buffers</h2><label>Volume I want to make (mL)<input inputmode="decimal" data-c="rvol" value="${esc(ui.rv)}"></label><p class="muted">Amounts below change with the volume. Make up to the final volume with distilled water.</p></div>`+REC.map(r=>`<div class="card"><h3>${r[0]}</h3><div class="list">${r[2].map(x=>`<div class="item"><span class="t grow">${x[0]}</span><span class="t"><span data-amt="${x[1]}">${sig(x[1]*num(ui.rv)/1000)}</span> ${x[2]}</span></div>`).join('')}</div><p class="muted">${r[1]}</p></div>`).join('')+`<p class="muted">Standard recipes, entered by hand. Check against your lab manual before preparing.</p>`;
  if(ui.lab==='book')o+=`<div class="card">${head('Lab notebook',`<button class="btn sm pri" data-a="labNew">${ic('plus')}Practical</button>`)}${noteList('lab')}<p class="muted">Each new entry opens with the usual headings: aim, principle, materials, procedure, observation, result, discussion and precautions.</p></div>`;
  if(EXT['lab_'+ui.lab])o+=EXT['lab_'+ui.lab]();
  return o;
};
document.addEventListener('input',e=>{
  const t=e.target,d=t.dataset||{};
  if(d.calc==='curve'){const r=document.getElementById('res_curve');if(r)r.innerHTML=curveOut()}
  if(d.c==='labq'){const q=t.value.toLowerCase().trim();document.querySelectorAll('details.calc').forEach(x=>{x.style.display=!q||x.dataset.name.includes(q)?'':'none'})}
  if(d.c==='rvol'){ui.rv=t.value;const v=num(t.value);document.querySelectorAll('[data-amt]').forEach(x=>{x.textContent=sig(+x.dataset.amt*v/1000)})}
});
Object.assign(A,{
  setPick(d){S.settings[d.k]=d.k==='big'?+d.v:d.v;save('settings');render()},
  setFlag(d){const k=d.id;if(k==='intro')S.settings.intro=S.settings.intro===0?1:0;else S.settings[k]=S.settings[k]?0:1;save('settings');render()},
  tileTog(d){const o=Object.assign({},S.settings.tilesOff);if(o[d.id])delete o[d.id];else o[d.id]=1;S.settings.tilesOff=o;save('settings');render()},
  water(d){const t=today(),b=S.water[t]||0;_water(d);if(b<S.settings.waterGoal&&(S.water[t]||0)>=S.settings.waterGoal)celebrate('Water goal reached')},
  prTog(d){const b=PR.filter(p=>(S.prayers[d.d]||{})[p[0]]).length;_prTog(d);if(d.d===today()&&b<5&&PR.every(p=>(S.prayers[d.d]||{})[p[0]]))celebrate('All five prayers today')},
  hDay(d){_hDay(d);const l=S.habitLog[today()]||{};if(d.d===today()&&l[d.id]&&S.habits.length&&S.habits.every(h=>l[h.id]))celebrate('Every habit done today')},
  hTog(d){A.hDay({id:d.id,d:today()})},
  lcat(d){ui.lcat=d.v;render()},
  cmode(d){ui.cmode=d.v;render()},
  mtTog(d){const v=ui.mt[d.id]||'';ui.mt[d.id]=v===''?'+':v==='+'?'-':'';render()},
  mtReset(){ui.mt={};render()},
  labNew(){form('New practical',A.nFields,{title:'',body:LABT},v=>{const n=Object.assign({id:uid(),ref:'lab',updated:Date.now()},v);S.notes.push(n);save('n_'+n.id)})}
});
(function(){const sp=document.getElementById('splash');if(!sp||!sp.addEventListener)return;sp.addEventListener('click',()=>sp.remove());setTimeout(()=>{if(sp.parentNode)sp.remove()},3600)})();
window.__v5={fit:fit,parsePts:parsePts,orgRank:orgRank,ORG:ORG,BT:BT,REC:REC,applyLook:applyLook};


/* ================= v6: streak, photo, guidelines, money tools, bigger lab, offline sync, more motion ================= */
KEYS.push('streak','bills','billPaid','fv','protocols');OBJ.push('streak','billPaid','fv');
Object.assign(DEF_SET,{photo:'',income:0});
normalize();
Object.assign(ui,{pr:null,prDone:{}});
SUB.lab.splice(4,0,['tests','Test guide'],['protocols','Protocols']);
MENU.find(g=>g[0]==='Lab')[1].push(['lab','lab','tests','Test guide','sun'],['lab','lab','protocols','Protocols','sun']);
ILL.flame='<path d="M24 4c2 9 12 13 12 24a12 12 0 0 1-24 0c0-5 3-8 5-11 1 4 3 5 4 5 1-6 0-12 3-18z" fill="var(--tomato)"/><path d="M24 26c3 3 5 5 5 8a5 5 0 0 1-10 0c0-3 2-5 5-8z" fill="var(--sun)" stroke="none"/>';

/* ---------- sync when the phone comes back online ---------- */
const _ss=setStatus;
setStatus=function(){_ss();const el=$('#status');if(el&&typeof navigator!=='undefined'&&navigator.onLine===false){el.textContent='Offline · saved on phone';el.classList.add('warn')}};
const pushAll=()=>{if(col)[...dirty].forEach(k=>{tries[k]=0;flush(k)});setStatus()};
window.addEventListener('online',pushAll);window.addEventListener('offline',()=>setStatus());
setInterval(()=>{if(col&&dirty.size&&(typeof navigator==='undefined'||navigator.onLine!==false))pushAll()},60000);

/* ---------- profile photo ---------- */
const okPhoto=p=>typeof p==='string'&&p.indexOf('data:image/')===0;
const avatar=()=>`<label class="avatar avpick" title="Change my photo">${okPhoto(S.settings.photo)?`<img src="${esc(S.settings.photo)}" alt="">`:esc((S.settings.name||'C').trim().charAt(0).toUpperCase())}<input type="file" id="avup" accept="image/*" aria-label="Choose my photo"></label>`;
function readPhoto(file){return new Promise((res,rej)=>{const fr=new FileReader();fr.onerror=rej;fr.onload=()=>{const im=new Image();im.onerror=rej;im.onload=()=>{const c=document.createElement('canvas'),k=Math.max(160/im.width,160/im.height);c.width=c.height=160;c.getContext('2d').drawImage(im,(160-im.width*k)/2,(160-im.height*k)/2,im.width*k,im.height*k);res(c.toDataURL('image/jpeg',.82))};im.src=fr.result};fr.readAsDataURL(file)})}
document.addEventListener('change',e=>{const t=e.target;if(t.id==='avup'&&t.files.length)readPhoto(t.files[0]).then(u=>{S.settings.photo=u;save('settings');render()},()=>say('photo','That picture could not be read. Try a JPG or PNG.'))});

/* ---------- streak ---------- */
const ST=()=>{const s=S.streak;if(s.restores==null||s.restores>3)s.restores=3;s.count=s.count||0;s.best=s.best||0;return s};
function streakTick(){
  const s=ST(),t=today();if(s.paused||s.last===t)return;
  if(!s.last)s.count=1;else{const gap=diffDays(t,s.last);if(gap<1)return;if(gap===1)s.count++;else{s.lost={count:s.count,days:gap-1};s.count=1}}
  s.last=t;s.best=Math.max(s.best,s.count);save('streak');
  if([7,30,50,100,200,365].includes(s.count))setTimeout(()=>celebrate(s.count+'-day streak'),1500);
}
const flame=()=>`<svg class="ill flame" viewBox="0 0 48 48" aria-hidden="true">${ILL.flame}</svg>`;
const streakPill=()=>{const s=ST();return`<span class="pill stk">${flame()}${s.paused?'Paused':s.count+' day'+(s.count===1?'':'s')}</span>`};
function streakCard(){
  const s=ST();
  if(s.lost&&s.restores>0&&!s.paused)return`<div class="card c-sun"><div class="row">${flame()}<div class="grow"><h3>Your ${s.lost.count}-day streak slipped</h3><p class="muted">You missed ${s.lost.days} day${s.lost.days>1?'s':''}. You can bring it back ${s.restores} more time${s.restores>1?'s':''}.</p></div></div><div class="row wrap"><button class="btn pri" data-a="stRestore">Restore my streak</button><button class="btn" data-a="stFresh">Start fresh</button></div></div>`;
  return`<div class="card"><div class="row">${flame()}<div class="grow"><h3>${s.paused?'Streak paused at '+s.count+' day'+(s.count===1?'':'s'):s.count+'-day streak'}</h3><p class="muted">Best ${s.best} · ${s.restores} of 3 restores left. Open the app every day to keep it going.</p><p class="muted">Going on semester break? Tap Pause and your streak waits for you.</p></div><button class="btn sm" data-a="stPause">${s.paused?'Resume':'Pause'}</button></div>${s.paused?'<p class="muted">Paused for your break. Your streak is safe until you resume.</p>':''}</div>`;
}

/* ---------- guidelines for every Life section ---------- */
const GUIDE={
 water:['How much water?',['Adults need about 2.0 litres (women) to 2.5 litres (men) of water a day, counting all drinks and food. That is roughly 8 to 10 glasses.','Drink more in hot weather, when you exercise, and when you have fever or diarrhoea.','Pale yellow urine is a simple sign that you are drinking enough.'],'European Food Safety Authority (EFSA)'],
 food:['Eating well',['At least 400 g of fruit and vegetables a day, about 5 portions.','Less than 5 g of salt a day, about one teaspoon.','Free sugars under 10% of your energy, about 50 g or 12 teaspoons. Under 5% is better.','Fats under 30% of your energy. Prefer unsaturated fats.'],'World Health Organization (WHO), Healthy diet'],
 habits:['Building habits',['A new habit takes about 66 days on average to feel automatic. It ranged from 18 to 254 days in the study.','Missing one day does not undo your progress. Try not to miss two days in a row.','Start small and attach the habit to something you already do every day.'],'Lally and colleagues, European Journal of Social Psychology, 2010'],
 sleep:['How much sleep?',['Adults need 7 to 9 hours a night. Teenagers need 8 to 10.','Keep the same bedtime and wake time, even on weekends.','Avoid screens, heavy meals and caffeine close to bedtime.'],'American Academy of Sleep Medicine and National Sleep Foundation'],
 health:['When you are sick',['Take medicines exactly as prescribed. Follow your doctor on how long to take them.','Never take antibiotics without a prescription and never share them.','A temperature of 38 °C (100.4 °F) or more is a fever. See a doctor if it lasts more than three days, or sooner if you feel very unwell.','Rest and drink plenty of fluids.'],'WHO advice on antibiotics. Your doctor’s instructions always come first.'],
 acts:['How active should I be?',['Adults: 150 to 300 minutes of moderate activity a week, or 75 to 150 minutes of vigorous activity.','Add muscle-strengthening exercise on 2 or more days a week.','Sit less. Any movement is better than none.'],'World Health Organization (WHO), 2020 guidelines on physical activity'],
 money:['Managing money as a student',['A common rule is 50/30/20: about 50% on needs, 30% on wants and 20% saved.','Build an emergency fund that covers 3 to 6 months of basic costs.','Write down every expense for a month. Most people find one category they did not expect.'],'Widely used budgeting rules, not an official standard']
};
const guide=k=>{const g=GUIDE[k];return`<div class="card guide"><div class="row">${ill(k==='water'?'drop':k==='food'?'bowl':k==='sleep'?'moon':k==='habits'?'sprout':k==='health'?'pill':k==='money'?'wallet':'timer')}<div class="grow"><span class="pill">Guideline</span><h3>${g[0]}</h3></div></div><ul>${g[1].map(x=>`<li>${x}</li>`).join('')}</ul>${k==='water'?`<p>Your goal is ${S.settings.waterGoal} glasses of ${S.settings.glassMl} mL, which is <b>${(S.settings.waterGoal*S.settings.glassMl/1000).toFixed(1)} litres</b>.</p>`:''}<p class="muted">Source: ${g[2]}. General guidance for healthy adults, not personal medical advice.</p></div>`};
const NEEDS=['Food','Transport','Study','Mobile and internet','Health'];
const lifeExtra={
  acts:()=>{const d7=last7(),m=S.acts.filter(a=>d7.includes(a.date)).reduce((a,x)=>a+(+x.min||0),0);return`<div class="card c-pink"><div class="row between"><h3>Active minutes, last 7 days</h3><span class="pill">${m} / 150</span></div><div class="bar"><i style="width:${Math.min(100,m/150*100)}%"></i></div><p class="muted">${m>=150?'You have reached the weekly minimum.':'Add the minutes when you log an activity. '+(150-m)+' to go this week.'}</p></div>`},
  food:()=>{const n=S.fv[ui.foodDay]||0;return`<div class="card c-leaf"><div class="row between"><h3>Fruit and vegetables</h3><span class="pill">${n} / 5 portions</span></div><div class="bar"><i style="width:${Math.min(100,n/5*100)}%"></i></div><div class="row"><button class="btn sm" data-a="fvAdd" data-n="-1" aria-label="Remove one portion">−</button><button class="btn sm grow" data-a="fvAdd" data-n="1">${ic('plus')}I ate a portion</button></div><p class="muted">One portion is about a handful, or 80 g.</p></div>`},
  sleep:()=>{const got=last7().map(x=>S.sleep.find(l=>l.date===x)).filter(Boolean);if(!got.length)return'';const a=got.reduce((s,l)=>s+sleepMin(l),0)/got.length;return`<div class="card ${a>=420&&a<=540?'c-leaf':'c-sun'}"><h3>${a<420?'You are sleeping less than recommended':a>540?'You are sleeping more than the usual range':'Your sleep is in the healthy range'}</h3><p class="muted">Your 7-day average is ${dur(Math.round(a))}. The recommended range for adults is 7 to 9 hours.</p></div>`},
  money:()=>{
    const l=S.money.filter(m=>m.date.slice(0,7)===ui.month),inc=l.filter(m=>m.type==='in').reduce((a,m)=>a+m.amount,0)||num(S.settings.income),sp=l.filter(m=>m.type!=='in');
    const need=sp.filter(m=>NEEDS.includes(m.cat)).reduce((a,m)=>a+m.amount,0),want=sp.reduce((a,m)=>a+m.amount,0)-need,paid=S.billPaid[ui.month]||{},fixed=S.bills.reduce((a,b)=>a+(+b.amount||0),0);
    const row=(n,v,t)=>{const p=inc?v/inc*100:0;return`<div><div class="row between"><span class="t">${n}</span><span class="muted">${money(v)} · ${Math.round(p)}% of ${t}%</span></div><div class="bar"><i style="width:${Math.min(100,p/t*100)}%${p>t?';background:var(--bad)':''}"></i></div></div>`};
    let o=`<div class="card">${head('50 / 30 / 20 check',`<button class="btn sm" data-a="setIncome">${ic('edit')}Income</button>`)}${inc?row('Needs',need,50)+row('Wants',want,30)+row('Saved',Math.max(0,inc-need-want),20)+`<p class="muted">Based on ${money(inc)} received this month. Needs are food, transport, study, mobile and health. A full bar means you have reached that share.</p>`:'<p class="muted">Add what you receive each month, such as allowance or tuition income, to see how your spending splits into needs, wants and savings.</p>'}</div>`;
    o+=`<div class="card">${head('Monthly bills',addBtn('billAdd','Bill'))}${S.bills.length?`<div class="list">${S.bills.map(b=>`<div class="item${paid[b.id]?' done':''}">${chk(paid[b.id],'billTog',`data-id="${b.id}"`,'Paid')}<button class="tap" data-a="billEdit" data-id="${b.id}"><span class="t">${esc(b.name)}</span><span class="muted">${money(+b.amount||0)} · due on day ${+b.day||1}</span></button></div>`).join('')}</div><p class="muted">${money(fixed)} of fixed costs each month. Tick each one when you pay it and it is added to your spending. You get a reminder on the due day.</p>`:'<p class="muted">Rent, mess bill, internet, tuition instalment. Add them once and tick them off every month.</p>'}</div>`;
    o+=`<div class="card"><h3>Split a bill</h3><div class="row"><label class="grow">Total<input inputmode="decimal" data-c="split" id="sp_t"></label><label class="grow">People<input inputmode="numeric" data-c="split" id="sp_n"></label></div><p class="res" id="sp_r"></p></div>`;
    return o}
};
['water','food','habits','sleep','health','acts','money'].forEach(k=>{const f=EXT[k];EXT[k]=()=>(f?f():'')+(lifeExtra[k]?lifeExtra[k]():'')+guide(k)});
const _ag=agenda;
agenda=function(ds){const a=_ag(ds),paid=S.billPaid[ds.slice(0,7)]||{},dim=new Date(+ds.slice(0,4),+ds.slice(5,7),0).getDate();S.bills.forEach(b=>{if(Math.min(dim,+b.day||1)===+ds.slice(8)&&!paid[b.id])a.push({t:'09:00',title:'Pay '+b.name+' ('+money(+b.amount||0)+')',src:'Bill',key:'b-'+b.id})});return a.sort((x,y)=>x.t<y.t?-1:1)};

/* ---------- biochem bites: one for every day ---------- */
FACTS.push('Your body has about 30 trillion human cells and a similar number of bacteria living with them.','Red blood cells have no nucleus and live for about 120 days.','Catalase can break down millions of hydrogen peroxide molecules every second.','Proteins are built from 20 standard amino acids. Selenocysteine is often called the 21st.','Water makes up about 60% of an adult’s body weight.','Blood pH is held between 7.35 and 7.45, mainly by the bicarbonate buffer.','The DNA of any two people is about 99.9% identical.','Only about 1 to 2% of the human genome codes for proteins.','PCR was invented by Kary Mullis in 1983. It can copy one DNA molecule into billions within hours.','Green fluorescent protein (GFP) comes from the jellyfish Aequorea victoria.','Urease was the first enzyme to be crystallised, by James Sumner in 1926.','Watson and Crick described the double helix in 1953, using X-ray data from Rosalind Franklin.','One turn of B-DNA holds about 10.5 base pairs and is about 3.4 nm long.','A–T pairs have two hydrogen bonds and G–C pairs have three, so GC-rich DNA melts at a higher temperature.','The ribosome is a ribozyme: its peptide bonds are formed by RNA, not by protein.','Titin is the largest known human protein, with about 34,000 amino acids.','Collagen is the most abundant protein in the human body.','The Krebs cycle turns twice for every glucose molecule.','NADH absorbs light at 340 nm and NAD⁺ does not, which is how many enzyme assays are followed.','Lactose intolerance comes from low levels of the enzyme lactase.','Restriction enzymes are bacterial defences that cut foreign DNA at specific sequences.','EcoRI is named after Escherichia coli strain RY13.','Insulin has 51 amino acids in two chains joined by disulfide bonds.','The Human Genome Project was declared complete in 2003.','Dolly the sheep, born in 1996, was the first mammal cloned from an adult cell.','Golden Rice was engineered to make beta-carotene, which the body turns into vitamin A.','Bt crops carry a gene from Bacillus thuringiensis that makes a protein toxic to certain insects.','Agrobacterium tumefaciens naturally moves DNA into plant cells, and scientists use it to engineer plants.','Baker’s yeast was the first eukaryote to have its genome sequenced, in 1996.','An mRNA vaccine delivers instructions for a protein, and your own ribosomes make it.','Monoclonal antibodies were first made by Köhler and Milstein in 1975, using hybridoma cells.','Gram-positive bacteria hold the crystal violet stain because of their thick peptidoglycan wall.','Endospores of Bacillus and Clostridium survive boiling, which is why autoclaves run at 121 °C.','Your gut bacteria make vitamin K and some B vitamins.','Haemoglobin holds oxygen less tightly as pH falls. This is the Bohr effect.','Sickle cell disease comes from one amino acid change: glutamate to valine at position 6 of β-globin.','Phenylketonuria (PKU) results from a faulty phenylalanine hydroxylase enzyme.','Km is the substrate concentration at which an enzyme works at half its maximum speed.','A competitive inhibitor raises the apparent Km and leaves Vmax unchanged.','Alcohol is broken down mainly in the liver by alcohol dehydrogenase.','Brown fat makes heat using an uncoupling protein called thermogenin.','At rest the brain uses about 20% of the body’s energy, mostly from glucose.','Cholesterol is the starting material for steroid hormones, bile acids and vitamin D.','Insulin lowers blood glucose and glucagon raises it.','Luciferase, the enzyme that makes fireflies glow, is used in labs to measure ATP.','Thermus aquaticus was discovered in the hot springs of Yellowstone National Park.');

/* ---------- lab: more calculators ---------- */
CALC.push(
 {id:'stockm',g:'Solutions',t:'Molarity of a concentrated acid or base',f:[['p','Purity (% w/w)'],['d','Density (g/mL)'],['mw','Molecular weight (g/mol)']],fn:v=>v.p&&v.d&&v.mw?sig(v.p*v.d*10/v.mw)+' M':'',n:'M = % × density × 10 ÷ MW. HCl at 37% and 1.19 g/mL is about 12 M.'},
 {id:'norm',g:'Solutions',t:'Normality',f:[['m','Molarity (M)'],['n','H⁺ or OH⁻ per molecule (2 for H₂SO₄)']],fn:v=>v.m&&v.n?sig(v.m*v.n)+' N':'',n:'N = M × number of equivalents'},
 {id:'ppm',g:'Solutions',t:'Parts per million',f:[['mg','Solute (mg)'],['l','Solution volume (L)']],fn:v=>v.mg&&v.l?sig(v.mg/v.l)+' ppm (mg/L)':'',n:'For dilute water solutions, 1 ppm = 1 mg/L.'},
 {id:'dilf',g:'Solutions',t:'Dilution factor',f:[['s','Sample volume'],['d','Diluent volume']],fn:v=>v.s&&v.d?'1 in '+sig((v.s+v.d)/v.s)+' (dilution factor '+sig((v.s+v.d)/v.s)+')':'',n:'factor = (sample + diluent) ÷ sample'},
 {id:'od',g:'Microbiology',t:'OD600 to cell number (E. coli)',f:[['od','OD600 reading'],['df','Dilution factor (1 if undiluted)']],fn:v=>v.od?'About '+sci(v.od*(v.df||1)*8e8)+' cells/mL':'',n:'Rule of thumb: OD600 of 1.0 is about 8 × 10⁸ E. coli cells/mL. It differs between instruments and species.'},
 {id:'copies',g:'Molecular',t:'DNA copy number',f:[['ng','DNA amount (ng)'],['bp','Length (bp)']],fn:v=>v.ng&&v.bp?sci(v.ng*6.022e23/(v.bp*660*1e9))+' copies':'',n:'copies = ng × 6.022 × 10²³ ÷ (bp × 660 × 10⁹)'},
 {id:'oligo',g:'Molecular',t:'Dissolving a primer',f:[['n','Amount on the tube (nmol)'],['c','Stock you want (µM), usually 100']],fn:v=>v.n?'Add '+sig(v.n*1000/(v.c||100))+' µL of water or TE for a '+(v.c||100)+' µM stock.':'',n:'Dilute 1 in 10 for a 10 µM working stock.'},
 {id:'mm',g:'Analysis',t:'Michaelis–Menten rate',f:[['vm','Vmax'],['km','Km'],['s','Substrate [S]']],fn:v=>v.vm&&v.km&&v.s?'v = '+sig(v.vm*v.s/(v.km+v.s))+', which is '+Math.round(v.s/(v.km+v.s)*100)+'% of Vmax':'',n:'v = Vmax × [S] ÷ (Km + [S])'},
 {id:'ua',g:'Analysis',t:'Enzyme activity from an absorbance change',f:[['da','ΔA per minute'],['vt','Total assay volume (mL)'],['vs','Enzyme sample volume (mL)'],['e','ε (mM⁻¹ cm⁻¹), 6.22 for NADH'],['df','Dilution factor (1 if undiluted)']],fn:v=>v.da&&v.vt&&v.vs&&v.e?sig(v.da*v.vt*(v.df||1)/(v.e*v.vs))+' U/mL':'',n:'U/mL = ΔA/min × total volume × dilution ÷ (ε × path length 1 cm × sample volume)'},
 {id:'sa',g:'Analysis',t:'Specific activity and purification fold',f:[['u','Total activity (U)'],['p','Total protein (mg)'],['c','Specific activity of the crude extract (optional)']],fn:v=>v.u&&v.p?sig(v.u/v.p)+' U/mg'+(v.c?', purified '+sig(v.u/v.p/v.c)+'-fold':''):'',n:'specific activity = units ÷ mg protein'}
);
CALC.forEach(c=>{if(!c.g)c.g='Solutions'});

/* ---------- lab: sequence extras ---------- */
const RE=[['EcoRI','GAATTC'],['BamHI','GGATCC'],['HindIII','AAGCTT'],['XhoI','CTCGAG'],['NdeI','CATATG'],['NotI','GCGGCCGC'],['PstI','CTGCAG'],['SalI','GTCGAC'],['XbaI','TCTAGA'],['KpnI','GGTACC'],['SacI','GAGCTC'],['SmaI','CCCGGG'],['EcoRV','GATATC'],['NcoI','CCATGG'],['BglII','AGATCT']];
function seqMore(raw){
  const s=String(raw||'').toUpperCase().replace(/[^A-Z]/g,'').replace(/U/g,'T');if(!s||/[^ACGTN]/.test(s))return null;
  const sites=[];RE.forEach(r=>{const p=[];let i=s.indexOf(r[1]);while(i>=0){p.push(i+1);i=s.indexOf(r[1],i+1)}if(p.length)sites.push([r[0],r[1],p])});
  let best=null;for(let f=0;f<3;f++)for(let i=f;i+2<s.length;i+=3)if(s.substr(i,3)==='ATG')for(let j=i;j+2<s.length;j+=3){const c=s.substr(j,3);if(c==='TAA'||c==='TAG'||c==='TGA'){if(!best||j-i>best.len)best={start:i+1,end:j+3,len:j-i,frame:f+1};break}}
  return{sites:sites,orf:best};
}
function seqFull(raw){const q=seqMore(raw);if(!q)return seqOut(raw);
  return seqOut(raw)+`<p class="muted">Longest open reading frame</p><p class="seq">${q.orf?'Bases '+q.orf.start+' to '+q.orf.end+', frame '+q.orf.frame+', '+q.orf.len/3+' amino acids':'No ATG followed by a stop codon in the three forward frames'}</p><p class="muted">Restriction sites (15 common enzymes)</p>${q.sites.length?q.sites.map(x=>`<p class="seq">${x[0]} ${x[1]}: position ${x[2].join(', ')}</p>`).join(''):'<p class="seq">None of them cut this sequence</p>'}`}
const RM={G:57.05,A:71.08,S:87.08,P:97.12,V:99.13,T:101.1,C:103.14,L:113.16,I:113.16,N:114.1,D:115.09,Q:128.13,K:128.17,E:129.12,M:131.19,H:137.14,F:147.18,R:156.19,Y:163.18,W:186.21};
function protInfo(raw){const s=String(raw||'').toUpperCase().replace(/[^A-Z]/g,'');if(!s)return null;if([...s].some(c=>!RM[c]))return{err:true};let m=18.02;[...s].forEach(c=>m+=RM[c]);const n=c=>(s.match(new RegExp(c,'g'))||[]).length,e=5500*n('W')+1490*n('Y');return{n:s.length,mw:m,e:e,a:e/m}}
const protOut=raw=>{const p=protInfo(raw);if(!p)return'<p class="muted">Paste a protein sequence in one-letter code.</p>';if(p.err)return'<p class="muted">Use only the 20 standard one-letter amino acid codes.</p>';return`<div class="g3">${stat(p.n,'residues')}${stat((p.mw/1000).toFixed(2)+' kDa','molecular weight')}${stat(p.e||'–','ε at 280 nm')}</div><p class="muted">${p.e?'A 1 mg/mL solution should read about A280 = '+p.a.toFixed(2)+'. ':'No Trp or Tyr, so it barely absorbs at 280 nm. '}ε counts 5500 per Trp and 1490 per Tyr, in M⁻¹ cm⁻¹, with cysteines reduced.</p>`};
EXT.lab_seq=()=>`<div class="card"><h3>Protein from its sequence</h3><label>Protein sequence<textarea data-calc="prot" data-k="s" placeholder="MKWVTFISLLFLFSSAYS" autocapitalize="characters" autocomplete="off" spellcheck="false">${esc((ui.cv.prot||{}).s||'')}</textarea></label><div id="res_prot">${protOut((ui.cv.prot||{}).s)}</div></div>`;

/* ---------- lab: test guide, reference, protocols ---------- */
const TMIC=[['Catalase','Breaks down hydrogen peroxide','Bubbles at once with 3% H₂O₂'],['Oxidase','Cytochrome c oxidase','Purple within 10 to 30 seconds'],['Coagulase','Clots plasma','Clumping or a clot. Positive for Staphylococcus aureus'],['Indole','Tryptophan broken to indole','Red ring with Kovac’s reagent'],['Methyl red','Strong mixed-acid fermentation','Stays red after methyl red'],['Voges–Proskauer','Acetoin production','Pink to red with Barritt’s A and B'],['Citrate (Simmons)','Citrate as the only carbon source','Green slant turns blue'],['Urease','Urea split to ammonia','Yellow-orange turns bright pink'],['TSI or SIM, H₂S','Hydrogen sulfide production','Black precipitate'],['Nitrate reduction','Nitrate to nitrite','Red after reagents A and B'],['Starch hydrolysis','Amylase','Clear zone around growth after iodine'],['MacConkey agar','Lactose fermentation in Gram-negatives','Pink colonies ferment lactose, pale ones do not'],['Mannitol salt agar','Salt tolerance and mannitol use','Yellow zone for Staphylococcus aureus'],['Motility','Flagella','Growth spreads away from the stab line']];
const TBIO=[['Molisch','Any carbohydrate','Purple ring at the junction'],['Benedict','Reducing sugars','Green, yellow, then brick-red precipitate'],['Fehling','Reducing sugars','Red precipitate'],['Barfoed','Monosaccharides','Red precipitate within about 3 minutes'],['Seliwanoff','Ketoses such as fructose','Cherry red quickly'],['Bial','Pentoses','Blue-green'],['Iodine','Starch and glycogen','Blue-black for starch, red-brown for glycogen'],['Biuret','Peptide bonds (proteins)','Violet'],['Ninhydrin','Free amino acids','Purple. Proline gives yellow'],['Xanthoproteic','Aromatic amino acids','Yellow, turning orange with alkali'],['Millon','Tyrosine','Red'],['Sakaguchi','Arginine','Red'],['Hopkins–Cole','Tryptophan','Violet ring'],['Lead acetate','Sulfur amino acids','Black precipitate'],['Sudan III','Lipids','Red-stained droplets'],['Salkowski','Cholesterol','Red in the chloroform layer']];
const tlist=l=>`<div class="list">${l.map(x=>`<div class="item"><span class="grow"><b>${x[0]}</b><br><span class="muted">Detects: ${x[1]}</span><br>Positive: ${x[2]}</span></div>`).join('')}</div>`;
EXT.lab_tests=()=>`<input data-c="tq" placeholder="Search a test" aria-label="Search tests"><div class="card tg"><h2>Microbiology tests</h2>${tlist(TMIC)}</div><div class="card tg"><h2>Qualitative biochemistry tests</h2>${tlist(TBIO)}</div><p class="muted">Textbook colours and reactions. Reagents and timings differ between lab manuals, so follow yours.</p>`;
const RTAB=[['Wavelengths to read at',[['DNA and RNA','260 nm'],['Protein (direct)','280 nm'],['NADH and NADPH','340 nm'],['p-Nitrophenol','405 nm'],['DNS reducing sugar, Biuret','540 nm'],['BCA protein','562 nm'],['Bradford protein','595 nm'],['Bacterial culture density','600 nm'],['Lowry protein','750 nm']]],['Which micropipette',[['P10','0.5 to 10 µL'],['P20','2 to 20 µL'],['P200','20 to 200 µL'],['P1000','100 to 1000 µL']]],['Agarose gel strength',[['0.7%','0.8 to 12 kb'],['1.0%','0.5 to 10 kb'],['1.5%','0.2 to 3 kb'],['2.0%','0.1 to 2 kb']]],['SDS-PAGE gel strength',[['8%','about 25 to 200 kDa'],['10%','about 15 to 100 kDa'],['12%','about 10 to 70 kDa'],['15%','about 3 to 40 kDa']]]];
const SAFE=['Wear a lab coat, closed shoes and gloves. Tie back long hair.','No food, drink or phone on the bench.','Label every tube and plate with your name, date and contents.','Add acid to water, never water to acid.','Never pipette by mouth.','Flame loops before and after use, and work close to the flame.','Put used cultures and tips in the discard jar or biohazard bag for autoclaving.','If a chemical touches skin or eyes, rinse with running water for 15 minutes and tell your instructor.','Wash your hands before you leave the lab.'];
EXT.lab_ref=()=>RTAB.map(t=>`<div class="card"><h2>${t[0]}</h2><div class="list">${t[1].map(r=>`<div class="item"><span class="t grow">${r[0]}</span><span class="muted">${r[1]}</span></div>`).join('')}</div></div>`).join('')+`<div class="card c-tomato"><h2>Lab safety</h2><ul>${SAFE.map(x=>`<li>${x}</li>`).join('')}</ul></div><p class="muted">Ranges are approximate. Your lab’s own rules and manual come first.</p>`;
const PROTO=[{id:'p_gram',name:'Gram staining',steps:[['Prepare a thin smear and heat-fix it',0],['Flood with crystal violet',60],['Rinse gently with water',0],['Flood with Gram’s iodine',60],['Rinse with water',0],['Decolorise with 95% ethanol until the runoff is clear',15],['Rinse with water at once',0],['Counterstain with safranin',45],['Rinse, blot dry and view under oil immersion (100×)',0]]},{id:'p_spore',name:'Endospore staining',steps:[['Prepare a smear and heat-fix it',0],['Cover with malachite green and steam it, keeping it moist',300],['Cool, then rinse with water',0],['Counterstain with safranin',30],['Rinse, blot dry and view. Spores are green, cells are pink.',0]]},{id:'p_streak',name:'Streak plate for single colonies',steps:[['Label the base of the plate',0],['Flame the loop and let it cool',0],['Streak the sample over the first quadrant',0],['Flame, cool, then drag from quadrant 1 into quadrant 2',0],['Repeat for quadrants 3 and 4, flaming each time',0],['Incubate upside down at 37 °C for 18 to 24 hours',0]]},{id:'p_gel',name:'Agarose gel electrophoresis',steps:[['Dissolve agarose in 1× TAE or TBE by heating until clear',0],['Cool to about 55 °C and add the DNA stain',0],['Pour into the tray with the comb and let it set',1200],['Place in the tank and cover with running buffer',0],['Mix samples with loading dye. Load them beside a ladder',0],['Run at 80 to 120 V until the dye is two thirds down',2400],['View on the transilluminator with UV protection',0]]}];
const allProto=()=>PROTO.concat(S.protocols.map(p=>({id:p.id,name:p.name,mine:true,steps:String(p.steps||'').split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{const a=l.split('|');return[a[0].trim(),Math.max(0,Math.round(num(a[1])))]})})));
const secs=n=>n>=60?(n%60?Math.floor(n/60)+' min '+n%60+' s':n/60+' min'):n+' s';
EXT.lab_protocols=()=>{
  const all=allProto(),p=all.find(x=>x.id===ui.pr);
  if(p){const dn=p.steps.filter((s,i)=>ui.prDone[i]).length;return`<button class="btn sm" data-a="prBack" style="align-self:flex-start">${ic('back')}Protocols</button><div class="card"><div class="row between"><h2>${esc(p.name)}</h2><span class="pill">${dn} / ${p.steps.length}</span></div><div class="bar"><i style="width:${p.steps.length?dn/p.steps.length*100:0}%"></i></div><div class="list">${p.steps.map((s,i)=>`<div class="item${ui.prDone[i]?' done':''}">${chk(ui.prDone[i],'prStep',`data-id="${i}"`,'Step '+(i+1))}<span class="t grow">${i+1}. ${esc(s[0])}</span>${s[1]?`<button class="btn sm" data-a="ltGo" data-n="${s[1]}" data-name="${esc(s[0].slice(0,40))}">${secs(s[1])}</button>`:''}</div>`).join('')}</div>${LT.length?'<div class="list">'+LT.map(x=>`<div class="item"><span class="t grow">${esc(x.name)}</span><span class="big" style="font-size:22px" id="lt_${x.id}">${ltLeft(x)}</span></div>`).join('')+'</div>':''}<p class="muted">Tick each step as you go. Tap a time to start its timer.${p.mine?'':' Timings follow common manuals. Use your own manual’s times if they differ.'}</p>${p.mine?`<button class="btn sm" data-a="prEdit" data-id="${p.id}" style="align-self:flex-start">${ic('edit')}Edit this protocol</button>`:''}</div>`}
  return`<div class="card">${head('Step-by-step protocols',addBtn('prAdd','My own'))}<p class="muted">Open one at the bench. It keeps your place and runs the timers.</p><div class="list">${all.map(x=>`<div class="item"><button class="tap" data-a="prOpen" data-id="${x.id}"><span class="t">${esc(x.name)}</span><span class="muted">${x.steps.length} steps${x.mine?' · mine':''}</span></button>${ic('next')}</div>`).join('')}</div></div>`};
const prF=[['name','Protocol name','text',R],['steps','Steps, one per line. Add | and seconds for a timed step','textarea',{req:true,tall:true,ph:'Add 500 µL lysis buffer\nIncubate at 65 °C | 600\nCentrifuge at 12000 × g | 300'}]];

/* ---------- curve tab: replicate statistics ---------- */
const _curveOut=curveOut;
curveOut=function(){
  if(ui.cmode!=='stats')return _curveOut();
  const x=(String((ui.cv.curve||{}).pts||'').match(/-?\d*\.?\d+(?:e-?\d+)?/gi)||[]).map(Number),n=x.length;
  if(n<2)return'<p class="muted">Type at least two readings, separated by spaces, commas or new lines.</p>';
  const m=x.reduce((a,b)=>a+b,0)/n,sd=Math.sqrt(x.reduce((a,b)=>a+(b-m)*(b-m),0)/(n-1));
  return`<div class="g3">${stat(n,'readings')}${stat(sci(m),'mean')}${stat(sci(sd),'SD')}${stat(sci(sd/Math.sqrt(n)),'SEM')}${stat(m?(sd/Math.abs(m)*100).toFixed(1)+'%':'–','CV')}${stat(sci(Math.min.apply(null,x))+' to '+sci(Math.max.apply(null,x)),'range')}</div><p class="res">Report as ${sci(m)} ± ${sci(sd)} (mean ± SD, n = ${n})</p><p class="muted">SD uses n − 1. A CV above about 10% between replicates usually means a pipetting or mixing problem.</p>`;
};

Object.assign(A,{
  stRestore(){const s=ST();if(s.lost&&s.restores>0){s.count=s.lost.count+1;s.restores--;delete s.lost;s.best=Math.max(s.best,s.count);save('streak');celebrate('Streak restored: '+s.count+' days')}render()},
  stFresh(){delete ST().lost;save('streak');render()},
  stPause(){const s=ST();if(s.paused){s.paused=0;s.last=today();if(!s.count)s.count=1}else s.paused=1;save('streak');render()},
  photoOff(){S.settings.photo='';save('settings');render()},
  fvAdd(d){S.fv[ui.foodDay]=Math.max(0,(S.fv[ui.foodDay]||0)+(+d.n));save('fv');render()},
  setIncome(){form('Monthly income',[['income','What I receive each month','number']],S.settings,v=>{S.settings.income=v.income;save('settings')})},
  billF:[['name','Bill','text',{req:true,ph:'Rent, mess, internet'}],['amount','Amount','number',R],['day','Due on day of month','number',R]],
  billAdd(){form('New monthly bill',A.billF,{day:1},v=>{v.day=Math.min(31,Math.max(1,Math.round(v.day)));upsert('bills',null,v)})},
  billEdit(d){const b=S.bills.find(x=>x.id===d.id);form('Edit bill',A.billF,b,v=>{v.day=Math.min(31,Math.max(1,Math.round(v.day)));upsert('bills',b.id,v)},()=>remove('bills',b.id))},
  billTog(d){const p=S.billPaid[ui.month]=S.billPaid[ui.month]||{},b=S.bills.find(x=>x.id===d.id);if(p[d.id])delete p[d.id];else{p[d.id]=1;if(b&&ui.month===today().slice(0,7)){S.money.push({id:uid(),date:today(),amount:+b.amount||0,type:'out',cat:'Other',note:b.name});save('money')}}save('billPaid');render()},
  prOpen(d){ui.pr=d.id;ui.prDone={};render();window.scrollTo(0,0)},
  prBack(){ui.pr=null;render()},
  prStep(d){ui.prDone[d.id]=!ui.prDone[d.id];render();if(Object.keys(ui.prDone).length&&allProto().find(x=>x.id===ui.pr).steps.every((s,i)=>ui.prDone[i]))celebrate('Protocol finished')},
  prAdd(){form('My protocol',prF,{},v=>upsert('protocols',null,v))},
  prEdit(d){const p=S.protocols.find(x=>x.id===d.id);form('Edit protocol',prF,p,v=>upsert('protocols',p.id,v),()=>{remove('protocols',p.id);ui.pr=null})}
});
document.addEventListener('input',e=>{
  const t=e.target,d=t.dataset||{};
  if(d.calc==='prot'){const r=document.getElementById('res_prot');if(r)r.innerHTML=protOut(t.value)}
  if(d.c==='tq'){const q=t.value.toLowerCase().trim();document.querySelectorAll('.tg .item').forEach(x=>{x.style.display=!q||x.textContent.toLowerCase().includes(q)?'':'none'})}
  if(d.c==='split'){const a=num((document.getElementById('sp_t')||{}).value),n=Math.round(num((document.getElementById('sp_n')||{}).value)),r=document.getElementById('sp_r');if(r)r.textContent=a>0&&n>0?'Each person pays '+money(Math.ceil(a/n))+(Math.ceil(a/n)*n-a>0?' ('+money(Math.ceil(a/n)*n-a)+' extra in total)':''):''}
});

/* ---------- motion: slide between tabs, numbers that count up ---------- */
let lastTabI=0,stDay='';
function countUp(){
  if(S.settings.motion==='off'||typeof requestAnimationFrame!=='function')return;
  document.querySelectorAll('#view .tile b,#view .big').forEach(el=>{
    const node=el.firstChild;if(!node||node.nodeType!==3)return;const m=/^(\D*?)(\d+)(.*)$/.exec(node.nodeValue);if(!m)return;const n=+m[2];if(n<2||n>99999)return;
    const t0=performance.now();(function step(now){const k=Math.min(1,(now-t0)/650),v=Math.round(n*(1-Math.pow(1-k,3)));node.nodeValue=m[1]+v+m[3];if(k<1)requestAnimationFrame(step)})(t0);
  });
}
const _ar6=window.afterRender;
window.afterRender=function(){
  if(cloud!=='loading'&&stDay!==today()){stDay=today();const b=JSON.stringify(S.streak);streakTick();if(JSON.stringify(S.streak)!==b){render();return}}
  const v=$('#view'),prev=lastKey;
  _ar6();
  const n=NAV.findIndex(x=>x[0]===ui.tab),i=n<0?99:n;
  if(v&&lastKey!==prev){v.classList.toggle('sr',i>lastTabI);v.classList.toggle('sl',i<lastTabI);countUp()}
  lastTabI=i;
};
const _look=EXT.look;
EXT.look=()=>`<div class="card"><h2>My photo</h2><div class="row">${avatar()}<div class="grow"><p class="muted">Tap the circle to choose a picture from your gallery. It shows at the top of the menu.</p>${okPhoto(S.settings.photo)?`<button class="btn sm" data-a="photoOff">Remove photo</button>`:''}</div></div>${said('photo')}</div>`+_look()+streakCard();
window.__v6={streakTick:streakTick,ST:ST,seqMore:seqMore,protInfo:protInfo,allProto:allProto,FACTS:FACTS,GUIDE:GUIDE};


/* ================= v7: cleaner top, soft edges, illustrated first-run setup, tap effects ================= */
ILL.cake='<rect x="8" y="24" width="32" height="18" rx="4" fill="var(--pink)"/><path d="M8 33c4 3 7-3 11 0s7-3 11 0 7-3 10 0M24 24v-7"/><path d="M24 7c2 3 3 4 3 5.500a3 3 0 0 1-6 0c0-1.500 1-2.500 3-5.500z" fill="var(--sun)"/>';
ILL.face='<circle cx="24" cy="24" r="18" fill="var(--sun)"/><circle cx="18" cy="21" r="1.600" fill="var(--ill)"/><circle cx="30" cy="21" r="1.600" fill="var(--ill)"/><path d="M17 29c4 4 10 4 14 0"/>';
const HM=['Muharram','Safar','Rabi‘ I','Rabi‘ II','Jumada I','Jumada II','Rajab','Sha‘ban','Ramadan','Shawwal','Dhul Qa‘dah','Dhul Hijjah'];
function hijriParts(){try{const p={};new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn',{day:'numeric',month:'numeric',year:'numeric'}).formatToParts(new Date()).forEach(x=>{p[x.type]=x.value});const m=+p.month,d=+p.day,y=parseInt(p.year,10);return m>=1&&m<=12&&d>=1&&d<=30&&y>1300&&y<1600?{d:d,m:m,y:y}:null}catch(e){return null}}
hijri=function(){const p=hijriParts();return p?p.d+' '+HM[p.m-1]+' '+p.y+' AH':''};
const hijriDay=()=>{const p=hijriParts();return p?p.d:0};

skyHero=function(){
  const t=today(),pt=ptimes(t),n=nowMin(),fj=toMin(pt.fajr),sr=toMin(pt.sunrise),mg=toMin(pt.maghrib),is=toMin(pt.isha),s=S.settings,h=new Date().getHours();
  const ph=n<fj||n>=is?'night':n<sr?'dawn':n<mg-45?'day':'dusk',G={night:['#10143F','#2C2F7A'],dawn:['#6F62D0','#FFB48A'],day:['#4DB4FF','#D4F0FF'],dusk:['#5546BD','#FF9A62']}[ph];
  const up=n>=sr&&n<mg,fr=up?(n-sr)/(mg-sr):((n-mg+1440)%1440)/(sr+1440-mg),x=186+146*fr,y=98-74*Math.sin(Math.PI*fr),dark=ph!=='day',bd=bday();
  let arc='';for(let i=0;i<=20;i++)arc+=(i?'L':'M')+(186+146*i/20).toFixed(1)+' '+(98-74*Math.sin(Math.PI*i/20)).toFixed(1);
  const stars=ph==='night'||ph==='dusk'?[[176,20],[214,46],[250,16],[292,40],[336,22],[150,58],[322,66]].map((p,i)=>`<circle class="star" style="animation-delay:${i*.35}s" cx="${p[0]}" cy="${p[1]}" r="1.800" fill="#fff"/>`).join(''):'';
  const clouds=ph==='day'||ph==='dawn'?`<g class="cloud" fill="#fff" opacity=".9"><ellipse cx="226" cy="58" rx="19" ry="7.500"/><ellipse cx="240" cy="52" rx="12" ry="7.500"/><ellipse cx="318" cy="34" rx="13" ry="5.500"/></g>`:'';
  const orb=up?`<g class="orb"><circle cx="${x}" cy="${y}" r="19" fill="#FFD23F" opacity=".35"/><circle cx="${x}" cy="${y}" r="12" fill="#FFD23F"/></g>`:`<g class="orb"><circle cx="${x}" cy="${y}" r="11" fill="#FFF3C4"/><circle cx="${x-3.500}" cy="${y-3}" r="2.200" fill="#E3D49A"/><circle cx="${x+4}" cy="${y+3.500}" r="1.600" fill="#E3D49A"/></g>`;
  const conf=bd===0?['#FF6B5E','#FFC83A','#3DCB82','#FF8CC3','#fff'].map((c,i)=>`<circle class="star" style="animation-delay:${i*.2}s" cx="${170+i*38}" cy="${24+(i%2)*22}" r="4" fill="${c}"/>`).join(''):'';
  const svg=`<svg viewBox="0 0 360 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="skg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${G[0]}"/><stop offset="1" stop-color="${G[1]}"/></linearGradient></defs><rect width="360" height="150" fill="url(#skg)"/>${stars}${clouds}<path d="${arc}" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="2" stroke-dasharray="2 7" stroke-linecap="round"/>${orb}${conf}
    <path d="M0 150v-24c40-13 84-13 124-4s92 11 132-2 76-8 104 4v26z" fill="${dark?'#1F8A5B':'#3DCB82'}"/>
    <path d="M249 127h10M249 115h10M249 101h10M249 89h10" stroke="#fff" stroke-opacity=".8" stroke-width="2" stroke-linecap="round"/><g fill="none" stroke-linecap="round" stroke-width="4"><path d="M246 134c0-13 16-13 16-26s-16-13-16-26" stroke="#A58BFF"/><path d="M262 134c0-13-16-13-16-26s16-13 16-26" stroke="#FFC83A"/></g>
    <g stroke="#fff" stroke-width="2.200" stroke-linejoin="round" stroke-linecap="round"><path d="M298 78h22M302 78v18l-17 28a5 5 0 0 0 4 8h40a5 5 0 0 0 4-8l-17-28V78z" fill="${dark?'#CFC8F7':'#F4F1FF'}"/><path d="M291 112h36l6 12a5 5 0 0 1-4 8h-40a5 5 0 0 1-4-8z" fill="#FF8CC3"/></g>
    <circle class="bubble" cx="305" cy="122" r="2.400" fill="#fff"/><circle class="bubble" style="animation-delay:.9s" cx="314" cy="124" r="1.800" fill="#fff"/><circle class="bubble" style="animation-delay:1.700s" cx="309" cy="120" r="2" fill="#fff"/></svg>`;
  const hi=bd===0?'Happy birthday':h<5?'Peaceful night':h<12?'Good morning':h<17?'Good afternoon':h<21?'Good evening':'Good night';
  return`<div class="sky ${ph}">${svg}<div class="skytext"><p>${hi}</p><h1>${esc(s.name||'Welcome')}</h1><p class="skydate">${fmt(t)}${bd&&bd<=7?' · birthday in '+bd+' day'+(bd>1?'s':''):''}</p></div>${streakPill()}</div>`;
};

/* ---------- first-run setup, one friendly question at a time ---------- */
let ob=null;
const OB=[
 {ill:'logo',c:'sun',t:'Welcome to Catalyst',p:'Small steps, big reactions. Answer a few quick questions and the app sets itself up for you.'},
 {ill:'face',c:'pink',t:'What should we call you?',p:'Add a photo too if you like. Tap the circle.',f:[['name','Your name','text']],photo:1},
 {ill:'cake',c:'tomato',t:'When is your birthday?',p:'The app will greet you on the day. You can leave this empty.',f:[['dob','Date of birth','date']]},
 {ill:'book',c:'grape',t:'Your studies',p:'Optional. Type your current CGPA and completed credits and you will never need to enter old semesters.',f:[['cgBase','Current CGPA','number'],['cgCred','Credits completed','number']]},
 {ill:'mosque',c:'leaf',t:'Where do you live?',p:'Your city sets the prayer times and the sky on the home screen.',f:[['city','City','select',Object.keys(CITY)],['asr','Asr time','select',['Hanafi','Shafi']]],deen:1},
 {ill:'drop',c:'sky',t:'Your daily health goals',p:'Adults need about 2 to 2.5 litres of water and 7 to 9 hours of sleep.',f:[['waterGoal','Glasses of water a day','number'],['sleepBed','Usual bedtime','time'],['sleepWake','Usual wake-up time','time']]},
 {ill:'flask',c:'grape',t:'Make it yours',p:'Pick a look. You can change it any time in Personalise.',look:1}
];
function obStart(){
  const s=S.settings;
  ob={i:0,back:false,err:'',v:{name:s.name||'',dob:s.dob||'',cgBase:s.cgBase||'',cgCred:s.cgCred||'',city:CITY[s.city]?s.city:'Dhaka',asr:s.asr,waterGoal:s.waterGoal,sleepBed:s.sleepBed,sleepWake:s.sleepWake,mode:s.mode,motion:s.motion,deenOff:s.deenOff?1:0}};
  ob.el=document.createElement('div');ob.el.id='onb';document.body.appendChild(ob.el);obDraw();
}
function obDraw(){
  if(!ob)return;const st=OB[ob.i],v=ob.v,last=ob.i===OB.length-1;
  const fld=f=>`<label>${f[1]}${f[2]==='select'?`<select data-ob="${f[0]}">${f[3].map(o=>`<option${String(v[f[0]])===o?' selected':''}>${o}</option>`).join('')}</select>`:`<input data-ob="${f[0]}" type="${f[2]==='number'?'text':f[2]}"${f[2]==='number'?' inputmode="decimal"':''} value="${esc(v[f[0]])}"${f[0]==='name'?' autocomplete="given-name"':''}>`}</label>`;
  const opt=(k,l)=>`<div class="chips">${l.map(x=>`<button class="chip${v[k]===x[0]?' on':''}" data-a="obPick" data-k="${k}" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`;
  ob.el.innerHTML=`<div class="obc"><div class="obtop"><div class="obdots">${OB.map((x,i)=>`<i class="${i<=ob.i?'on':''}"></i>`).join('')}</div><button class="btn sm" data-a="obSkip">Skip</button></div>
    <div class="obstep ${ob.back?'bk':''}"><div class="obart b-${st.c}"><span class="obb1"></span><span class="obb2"></span><span class="obb3"></span>${st.ill==='logo'?'<img src="logo.png" alt="">':ill(st.ill)}</div>
    <h1>${st.t}</h1><p class="muted">${st.p}</p>
    ${st.photo?`<div class="row">${avatar()}<span class="muted">Tap to add your photo</span></div>`:''}
    ${(st.f||[]).map(fld).join('')}
    ${st.deen?`<div class="item">${chk(!v.deenOff,'obDeen','','Deen section')}<span class="t grow">Show prayers, Quran and duas</span></div>`:''}
    ${st.look?`<p class="muted">Light or dark</p>${opt('mode',[['auto','Match my phone'],['light','Light'],['dark','Dark']])}<p class="muted">Movement</p>${opt('motion',[['full','Lively'],['calm','Calm'],['off','Still']])}`:''}
    ${ob.err?`<p style="color:var(--bad)" role="alert">${ob.err}</p>`:''}</div>
    <div class="row obnav">${ob.i?`<button class="btn" data-a="obBack">${ic('back')}Back</button>`:''}<button class="btn pri grow" data-a="obNext">${last?'Start using Catalyst':ob.i?'Next':'Let’s begin'}</button></div></div>`;
}
function obDone(){
  const v=ob.v,s=S.settings;
  Object.assign(s,{name:String(v.name).trim(),dob:v.dob,cgBase:Math.min(4,num(v.cgBase)),cgCred:num(v.cgCred),city:v.city,asr:v.asr,waterGoal:Math.max(1,Math.round(num(v.waterGoal))||8),sleepBed:v.sleepBed||'23:30',sleepWake:v.sleepWake||'06:30',mode:v.mode,motion:v.motion,deenOff:v.deenOff?1:0,setup:1});
  if(CITY[v.city]){s.lat=CITY[v.city][0];s.lng=CITY[v.city][1]}
  save('settings');ob.el.remove();ob=null;render();celebrate('Welcome, '+s.name);
}
const _welcome=A.welcome;
Object.assign(A,{
  welcome(){if(S.settings.setup)_welcome();else if(!ob)obStart()},
  obNext(){if(OB[ob.i].photo&&!String(ob.v.name).trim()){ob.err='Please type your name.';obDraw();return}ob.err='';ob.back=false;if(ob.i===OB.length-1){obDone();return}ob.i++;obDraw()},
  obBack(){ob.err='';ob.back=true;ob.i=Math.max(0,ob.i-1);obDraw()},
  obSkip(){ob.el.remove();ob=null},
  obPick(d){ob.v[d.k]=d.v;const r=document.documentElement;if(d.k==='mode'){if(d.v==='auto')delete r.dataset.mode;else r.dataset.mode=d.v}if(d.k==='motion')r.dataset.motion=d.v;obDraw()},
  obDeen(){ob.v.deenOff=ob.v.deenOff?0:1;obDraw()},
  obAgain(){if(!ob)obStart()}
});
document.addEventListener('input',e=>{const k=e.target.dataset&&e.target.dataset.ob;if(k&&ob)ob.v[k]=e.target.value});
document.addEventListener('change',e=>{const t=e.target,k=t.dataset&&t.dataset.ob;if(k&&ob)ob.v[k]=t.value;if(t.id==='avup'&&ob){const b=S.settings.photo;let n=0;const w=setInterval(()=>{if(!ob||++n>20){clearInterval(w);return}if(S.settings.photo!==b){clearInterval(w);obDraw()}},200)}});

/* ---------- tap effects ---------- */
let tap=null,navTab='';
function burst(x,y){const b=document.createElement('div');b.className='burst';b.style.left=x+'px';b.style.top=y+'px';b.innerHTML=Array.from({length:8},(q,i)=>`<i style="--a:${i*45}deg;background:var(--${COLORS[i%6]})"></i>`).join('');document.body.appendChild(b);setTimeout(()=>b.remove(),700)}
document.addEventListener('click',e=>{const el=e.target.closest&&e.target.closest('[data-a]');if(!el)return;tap={a:el.dataset.a,id:el.dataset.id||'',d:el.dataset.d||''};if(S.settings.motion!=='off'&&el.matches('.check,.hp,.tplus,.mt')&&e.clientX)burst(e.clientX,e.clientY)},true);
const _ar7=window.afterRender;
window.afterRender=function(){
  _ar7();
  const nv=$('#nav');if(nv){nv.classList.toggle('navpop',navTab!==ui.tab);navTab=ui.tab}
  if(tap&&tap.id){try{const el=document.querySelector('#view [data-a="'+tap.a+'"][data-id="'+tap.id+'"]'+(tap.d?'[data-d="'+tap.d+'"]':''));if(el)el.classList.add('justnow')}catch(e){}}
  tap=null;
};
window.__v7={hijri:()=>hijri(),obState:()=>ob};

window.__daybook={ptimes:ptimes,SUR:SUR,agenda:agenda,dayScore:dayScore,pageList:pageList,qibla:qibla,doses:doses,activeEp:activeEp};
})();
