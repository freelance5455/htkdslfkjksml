All Crops Doctor - Starter HTML

1. Extract this ZIP.
2. Import/open index.html in your HTML-to-APK builder (such as ApkForge).
3. Enable camera/file input permission if the builder asks.

Important:
This is a bilingual Urdu/Sindhi starter interface with local image preview and crop selection.
It does NOT yet diagnose diseases. Real offline diagnosis requires a trained on-device AI model
(TFLite/ONNX or equivalent), a validated crop-disease dataset, and expert-reviewed treatment guidance.
Do not recommend or apply pesticides based only on an unverified image result.
