package com.eahost.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.lang.ref.WeakReference

/**
 * Hosts the EA HOST web app (app/src/main/assets/index.html) full screen.
 *
 * The page is served from https://appassets.androidplatform.net/ so that
 * localStorage, IndexedDB (avatars, background video), Web Audio and speech
 * synthesis all work and persist, exactly like in a browser.
 *
 * Settings > OVERLAY in the web app talks to this class through the JS
 * interface "EAHostNative" to show a small floating square over other apps.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        var instance: WeakReference<MainActivity>? = null
    }

    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var waitingForOverlayPermission = false
    private val prefs by lazy { getSharedPreferences("eahost", Context.MODE_PRIVATE) }

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    // Used by the avatar picker (ADD PICTURE) and MY VIDEO upload.
    private val pickFile =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = if (result.resultCode == Activity.RESULT_OK) {
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            } else null
            fileCallback?.onReceiveValue(uris)
            fileCallback = null
        }

    // Android 13+: the notice of the floating square needs this permission (the square works without it).
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            startOverlayService()
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = WeakReference(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        hideSystemBars()

        webView = findViewById(R.id.webView)
        webView.setBackgroundColor(0xFF000000.toInt())
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false   // synth music / voice after Start
            allowFileAccess = false
            allowContentAccess = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }

        webView.addJavascriptInterface(NativeBridge(), "EAHostNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Keep the app on its own page; open any outside link in the browser.
                if (request.url.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    pickFile.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            // The app needs no camera / microphone access.
            override fun onPermissionRequest(request: PermissionRequest) = request.deny()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Single-page app: Back sends it to the background instead of closing it.
                moveTaskToBack(true)
            }
        })

        if (savedInstanceState == null) {
            webView.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }

        // Bring the floating square back after a restart if it was switched on.
        if (prefs.getBoolean("overlay", false) && Settings.canDrawOverlays(this)) startOverlayService()
    }

    // ---------------------------------------------------------- overlay

    /** Called by the web app: switch the floating square on or off. */
    fun setOverlayEnabled(on: Boolean) {
        if (!on) {
            prefs.edit().putBoolean("overlay", false).apply()
            stopService(Intent(this, OverlayService::class.java))
            notifyWeb()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            // Ask once; the user returns here and onResume finishes the job.
            waitingForOverlayPermission = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        prefs.edit().putBoolean("overlay", true).apply()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startOverlayService()
        }
    }

    private fun startOverlayService() {
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        notifyWeb()
    }

    /** Called by the floating square: press the START / STOP button of the current layout. */
    fun toggleBot() {
        webView.post {
            webView.evaluateJavascript("window.dispatchEvent(new Event('bns-toggle'))", null)
        }
    }

    private fun notifyWeb() {
        webView.post {
            webView.evaluateJavascript("window.dispatchEvent(new Event('native-overlay'))", null)
        }
    }

    /** What the web page can call (window.EAHostNative). */
    inner class NativeBridge {
        @JavascriptInterface
        fun hasPermission(): Boolean = Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface
        fun isEnabled(): Boolean =
            prefs.getBoolean("overlay", false) && Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface
        fun setEnabled(on: Boolean) {
            runOnUiThread { setOverlayEnabled(on) }
        }

        @JavascriptInterface
        fun setState(running: Boolean, avatarBase64: String, accentHex: String) {
            OverlayService.update(running, avatarBase64, accentHex)
        }
    }

    // ---------------------------------------------------------- window

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onStart() {
        super.onStart()
        OverlayService.setForeground(true)      // hide the square while the app itself is on screen
    }

    override fun onStop() {
        OverlayService.setForeground(false)     // show it over other apps
        super.onStop()
    }

    override fun onPause() {
        // Keep the page alive in the background when the floating square is on, so a tap can start / stop the robot.
        if (!prefs.getBoolean("overlay", false)) webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        if (waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = false
            setOverlayEnabled(true)
        } else {
            waitingForOverlayPermission = false
            notifyWeb()
        }
    }

    override fun onDestroy() {
        if (instance?.get() === this) instance = null
        webView.destroy()
        super.onDestroy()
    }
}
