package com.eahost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

/**
 * A small square (robot picture + status dot) that floats over other apps.
 *  - tap            : start / stop the robot (EA HOST must still be alive, otherwise it opens)
 *  - drag           : move it
 *  - press and hold : open EA HOST
 * It is only visible while EA HOST is in the background.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.eahost.app.STOP_OVERLAY"
        private const val CHANNEL = "overlay"

        @Volatile var instance: OverlayService? = null
        @Volatile private var robotRunning = false
        @Volatile private var accentColor = Color.parseColor("#2B8CFF")
        @Volatile private var avatarBitmap: Bitmap? = null
        @Volatile private var appInForeground = true

        /** Called from the web app (through the JS bridge). */
        fun update(running: Boolean, avatarB64: String, accentHex: String) {
            robotRunning = running
            if (avatarB64.isNotEmpty()) {
                try {
                    val bytes = Base64.decode(avatarB64, Base64.DEFAULT)
                    avatarBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                } catch (_: Exception) { /* keep the previous picture */ }
            }
            try { accentColor = Color.parseColor(accentHex) } catch (_: Exception) { /* keep colour */ }
            Handler(Looper.getMainLooper()).post { instance?.render() }
        }

        fun setForeground(foreground: Boolean) {
            appInForeground = foreground
            Handler(Looper.getMainLooper()).post { instance?.render() }
        }
    }

    private var windowManager: WindowManager? = null
    private var root: View? = null
    private var image: ImageView? = null
    private var dot: View? = null
    private var params: WindowManager.LayoutParams? = null
    private val prefs by lazy { getSharedPreferences("eahost", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startAsForeground()
        try {
            addBubble()
        } catch (_: Exception) {          // permission revoked or window refused
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean("overlay", false).apply()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        removeBubble()
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- view

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun addBubble() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)
        root = view
        image = view.findViewById(R.id.overlayImage)
        dot = view.findViewById(R.id.overlayDot)

        image?.clipToOutline = true
        image?.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) {
                outline.setRoundRect(0, 0, v.width, v.height, dp(11).toFloat())
            }
        }

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("overlay_x", dp(12))
        lp.y = prefs.getInt("overlay_y", dp(160))
        params = lp

        attachTouch(view, wm, lp)
        wm.addView(view, lp)
        render()
    }

    private fun attachTouch(view: View, wm: WindowManager, lp: WindowManager.LayoutParams) {
        val handler = Handler(Looper.getMainLooper())
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var longPressed = false
        val longPress = Runnable {
            longPressed = true
            openApp()
        }
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false; longPressed = false
                    handler.postDelayed(longPress, 600)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (moved) {
                        prefs.edit().putInt("overlay_x", lp.x).putInt("overlay_y", lp.y).apply()
                    } else if (!longPressed) {
                        onTap()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    true
                }
                else -> false
            }
        }
    }

    private fun onTap() {
        val activity = MainActivity.instance?.get()
        if (activity != null) activity.toggleBot() else openApp()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(i)
    }

    private fun removeBubble() {
        try {
            val v = root
            if (v != null) windowManager?.removeView(v)
        } catch (_: Exception) { /* already gone */ }
        root = null
    }

    /** Applies picture, status colour, accent colour and visibility. */
    fun render() {
        val view = root ?: return
        view.visibility = if (appInForeground) View.GONE else View.VISIBLE
        avatarBitmap?.let { image?.setImageBitmap(it) }
        (view.background?.mutate() as? GradientDrawable)?.setStroke(dp(2), accentColor)
        (dot?.background?.mutate() as? GradientDrawable)?.setColor(
            if (robotRunning) Color.parseColor("#22C55E") else Color.parseColor("#6B7280")
        )
    }

    // ---------------------------------------------------- foreground notice

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating square", NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_overlay)
            .setContentTitle("EA HOST square is on")
            .setContentText("Tap to open. It shows over other apps.")
            .setContentIntent(open)
            .addAction(0, "Hide", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }
}
