# EA HOST — Android project (XML + Kotlin, WebView)

The full EA HOST app (all layouts, settings, MetaTrader and Scanner tabs) runs inside
a full-screen WebView. Layout/resources are XML; the host is `MainActivity.kt`.

## Build the APK
1. Install **Android Studio** (Koala or newer) and open this folder.
2. Let Gradle sync (needs internet once). It will create the Gradle wrapper for you.
3. Plug in a phone (USB debugging on) and press **Run ▶**, or
   **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)** and install `app-debug.apk`.

## Notes
- The app lives in `app/src/main/assets/index.html` (one self-contained file).
- Bot pictures are never bundled: Settings ▸ AVATAR ▸ ADD PICTURE opens the phone gallery.
- INTERNET is only used for Google Fonts; offline it falls back to system fonts.
- Icons: adaptive icon (API 26+) plus PNG fallbacks for older phones.
- Gradle wrapper jar is not included (cannot be generated offline); Android Studio creates it on first sync.
- Trading, MetaTrader and scanner results are simulated, as in the original app.

## Floating square over other apps
Settings (swipe left) > **OVERLAY** switches on a small square with your robot picture that floats over
other apps while EA HOST is in the background.
- Android asks once for **Display over other apps**; allow it and come back to EA HOST.
- Tap the square: start / stop the robot. Drag: move it. Press and hold: open EA HOST.
- A green dot means the robot is running. The square uses your selected colour and robot picture.
- It is hidden while EA HOST itself is open. Switch it off in Settings > OVERLAY or with **Hide** in its notification.
- Not tested on a device from this environment — please try it and report anything odd.
