MELALI Ventes - مشروع Android

هذا مشروع Android Studio جاهز للبناء، وليس ملف APK مبنياً بعد.

طريقة استخراج APK:
1) ثبّت Android Studio على حاسوب.
2) افتح المجلد MELALI_Ventes_Android بواسطة Android Studio.
3) وافق على تثبيت Android SDK / Build Tools إذا طلب البرنامج ذلك.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف غالباً في app/build/outputs/apk/debug/app-debug.apk.
6) انقل APK إلى هاتف Samsung وافتحه، واسمح بالتثبيت من هذا المصدر عند الطلب.

التطبيق يفتح نسخة HTML محلياً داخل WebView، مع تفعيل JavaScript وDOM Storage.
تم تعديل التخزين ليحفظ المبيعات والمخزون محلياً في الهاتف/التطبيق حتى بعد إغلاقه.
اللغة الافتراضية عربية ويمكن التبديل إلى الفرنسية.

ملاحظة: يلزم Android Studio/Android SDK لبناء APK. هذا المجلد وحده ليس APK قابلاً للتثبيت.
