const itemGrid = document.getElementById("itemGrid");
const statusBox = document.getElementById("statusBox");
const heroSection = document.getElementById("heroSection");
const itemCount = document.getElementById("itemCount");
const searchInput = document.getElementById("searchInput");
const categoryBar = document.getElementById("categoryBar");

const detailModal = document.getElementById("detailModal");
const closeModal = document.getElementById("closeModal");
const playerArea = document.getElementById("playerArea");
const modalCat = document.getElementById("modalCat");
const modalYear = document.getElementById("modalYear");
const modalRating = document.getElementById("modalRating");
const modalTitle = document.getElementById("modalTitle");
const modalDesc = document.getElementById("modalDesc");
const playNowBtn = document.getElementById("playNowBtn");
const externalLinkBtn = document.getElementById("externalLinkBtn");

let allItems = [];
let selectedCategory = "All";
let currentItem = null;

function getYouTubeEmbed(url) {
  if (!url) return null;
  const regExp = /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/;
  const match = url.match(regExp);
  return match ? `https://www.youtube.com/embed/${match[1]}?autoplay=1&rel=0` : null;
}

function openItem(item) {
  currentItem = item;
  modalTitle.textContent = item.title || "Untitled";
  modalCat.textContent = item.category || "Video";
  modalYear.textContent = item.year || "2026";
  modalRating.textContent = `★ ${item.rating || "8.0"}`;
  modalDesc.textContent = item.description || "No description available.";
  externalLinkBtn.href = item.videoUrl || "#";

  playerArea.innerHTML = `<img src="${item.posterUrl || ""}" alt="${item.title || ""}" onerror="this.style.display='none'" />`;
  detailModal.classList.remove("hidden");
}

playNowBtn.addEventListener("click", () => {
  if (!currentItem || !currentItem.videoUrl) {
    alert("Video link not available.");
    return;
  }
  const url = currentItem.videoUrl.trim();
  const ytEmbed = getYouTubeEmbed(url);

  if (ytEmbed) {
    playerArea.innerHTML = `<iframe src="${ytEmbed}" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
  } else if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)) {
    playerArea.innerHTML = `<video src="${url}" controls autoplay playsinline></video>`;
  } else {
    playerArea.innerHTML = `<iframe src="${url}" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
  }
});

closeModal.addEventListener("click", () => {
  playerArea.innerHTML = "";
  detailModal.classList.add("hidden");
});

detailModal.addEventListener("click", (e) => {
  if (e.target === detailModal) {
    playerArea.innerHTML = "";
    detailModal.classList.add("hidden");
  }
});

function renderItems() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = allItems.filter((m) => {
    const matchCat = selectedCategory === "All" || (m.category || "").toLowerCase() === selectedCategory.toLowerCase();
    const matchSearch =
      !query ||
      (m.title || "").toLowerCase().includes(query) ||
      (m.category || "").toLowerCase().includes(query);
    return matchCat && matchSearch;
  });

  itemCount.textContent = filtered.length;
  itemGrid.innerHTML = "";

  if (allItems.length > 0 && selectedCategory === "All" && !query) {
    const featured = allItems[0];
    heroSection.style.backgroundImage = `url('${featured.posterUrl || ""}')`;
    heroSection.innerHTML = `
      <div class="hero-info">
        <span class="hero-badge">FEATURED</span>
        <h1>${featured.title || "Untitled"}</h1>
        <p>${featured.description || ""}</p>
      </div>
    `;
    heroSection.onclick = () => openItem(featured);
    heroSection.classList.remove("hidden");
  } else {
    heroSection.classList.add("hidden");
  }

  if (filtered.length === 0) {
    statusBox.classList.remove("hidden");
    statusBox.textContent = allItems.length === 0
      ? "Abhi koi content add nahi hua hai. Admin Panel se pehla item add karo!"
      : "Is filter/search mein kuch nahi mila.";
    return;
  }

  statusBox.classList.add("hidden");

  filtered.forEach((item) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="poster-wrap">
        <img src="${item.posterUrl || ""}" alt="${item.title || ""}" loading="lazy" />
        <span class="rating-tag">★ ${item.rating || "8.0"}</span>
      </div>
      <div class="card-body">
        <div class="card-title">${item.title || "Untitled"}</div>
        <div class="card-sub">${item.category || "Video"} • ${item.year || "2026"}</div>
      </div>
    `;
    card.addEventListener("click", () => openItem(item));
    itemGrid.appendChild(card);
  });
}

categoryBar.addEventListener("click", (e) => {
  const btn = e.target.closest(".cat-btn");
  if (!btn) return;
  document.querySelectorAll(".cat-btn").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  selectedCategory = btn.dataset.cat;
  renderItems();
});

searchInput.addEventListener("input", renderItems);

db.collection("movies")
  .orderBy("createdAt", "desc")
  .onSnapshot(
    (snapshot) => {
      allItems = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      renderItems();
    },
    (error) => {
      console.error(error);
      statusBox.classList.remove("hidden");
      statusBox.textContent = "Firebase connect nahi ho paya. Firestore Rules check karo. Error: " + error.message;
    }
  );
