const firebaseConfig = {
  apiKey: "AIzaSyDjEpqKOtK7HiiR62Lf-He_n2HE7R0oe30",
  authDomain: "sahil-ott.firebaseapp.com",
  projectId: "sahil-ott",
  storageBucket: "sahil-ott.firebasestorage.app",
  messagingSenderId: "1035378123850",
  appId: "1:1035378123850:web:978a3884d03e7c9ffa32b3",
  measurementId: "G-MH865H2P6B"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
