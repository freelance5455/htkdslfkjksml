if (typeof COURSES !== "undefined") {
  COURSES.push({
    id: "prog-1",
    category: "Programmation",
    level: "Universitaire L1/L2",
    title: "Programmation : Algo, Python & Langage C",
    duration: "1h 30",
    description: "Manuel complet : logique algorithmique, structures de contrôle, fonctions, récursivité, pointeurs en C et complexité Big-O.",
    chapters: [
      {
        id: "prog-c1",
        title: "Chapitre 1 : Algorithmique & Types de données",
        html: `
          <h3>1.1 Qu'est-ce qu'un algorithme ?</h3>
          <p>Un <strong>algorithme</strong> est une suite finie et non ambiguë d'instructions permettant de résoudre un problème à partir de données d'entrée pour produire un résultat en un temps fini.</p>
          <p>Contrairement à un programme (écrit dans un langage précis comme Python ou C), l'algorithme est universel : il s'écrit d'abord en <strong>pseudo-code</strong>.</p>

          <h3>1.2 Variables et Types primitifs</h3>
          <p>Une <strong>variable</strong> est une case mémoire nommée qui contient une valeur pouvant changer au cours du programme. Son <strong>type</strong> indique à l'ordinateur quelle taille réserver en RAM et quelles opérations sont autorisées.</p>
          <table>
            <tr><th>Type</th><th>Signification</th><th>Python</th><th>Langage C</th></tr>
            <tr><td><strong>Entier</strong></td><td>Nombres sans virgule (-5, 0, 42)</td><td><code>int</code></td><td><code>int</code> (4 octets)</td></tr>
            <tr><td><strong>Réel</strong></td><td>Nombres à virgule (3.14)</td><td><code>float</code></td><td><code>float</code> / <code>double</code></td></tr>
            <tr><td><strong>Booléen</strong></td><td>Vrai ou Faux (1 bit logique)</td><td><code>bool</code> (True/False)</td><td><code>int</code> ou <code>bool</code> (&lt;stdbool.h&gt;)</td></tr>
            <tr><td><strong>Chaîne</strong></td><td>Texte ("JosTech")</td><td><code>str</code></td><td><code>char[]</code> (tableau de char)</td></tr>
          </table>

          <h3>1.3 Opérateurs essentiels</h3>
          <ul>
            <li><strong>Arithmétiques :</strong> <code>+</code>, <code>-</code>, <code>*</code>, <code>/</code> (division réelle), <code>//</code> (division entière en Python), <code>%</code> (<strong>modulo</strong> : reste de la division entière).</li>
            <li><strong>Comparaison :</strong> <code>==</code> (égal à), <code>!=</code> (différent), <code>&lt;</code>, <code>&gt;</code>, <code>&lt;=</code>, <code>&gt;=</code>.</li>
            <li><strong>Logiques :</strong> <code>ET</code> (<code>and</code> en Python / <code>&amp;&amp;</code> en C), <code>OU</code> (<code>or</code> / <code>||</code>), <code>NON</code> (<code>not</code> / <code>!</code>).</li>
          </ul>
          <div class="warn-box">
            <strong>⚠️ Piège classique :</strong> En programmation, <code>=</code> sert à <strong>affecter</strong> une valeur (<code>x = 5</code> met 5 dans x), tandis que <code>==</code> sert à <strong>comparer</strong> deux valeurs (<code>x == 5</code> vérifie si x vaut 5).
          </div>
        `
      },
      {
        id: "prog-c2",
        title: "Chapitre 2 : Conditions et Boucles",
        html: `
          <h3>2.1 Les Structures Conditionnelles</h3>
          <p>Elles permettent au programme de choisir différents chemins selon les données.</p>
          <div class="code-box">
            <div class="code-header"><span>Python — Mention universitaire (if / elif / else)</span><button class="copy-btn" onclick="copyCode(this)">Copier</button></div>
<pre>note = 14.5
<span class="kw">if</span> note &gt;= 16:
    <span class="fn">print</span>(<span class="str">"Très Bien"</span>)
<span class="kw">elif</span> note &gt;= 12:
    <span class="fn">print</span>(<span class="str">"Assez Bien / Bien"</span>)
<span class="kw">elif</span> note &gt;= 10:
    <span class="fn">print</span>(<span class="str">"Admis"</span>)
<span class="kw">else</span>:
    <span class="fn">print</span>(<span class="str">"Ajourné"</span>)</pre>
          </div>

          <h3>2.2 Les Structures Itératives (Boucles)</h3>
          <p>Une boucle répète un bloc d'instructions automatiquement. Le choix de la boucle dépend du problème :</p>
          <table>
            <tr><th>Boucle</th><th>Quand l'utiliser ?</th><th>Exemple C / Python</th></tr>
            <tr><td><strong>FOR (Pour)</strong></td><td>On connaît à l'avance le nombre d'itérations (ex: parcourir 10 notes).</td><td><code>for i in range(10):</code></td></tr>
            <tr><td><strong>WHILE (Tant que)</strong></td><td>Condition vérifiée <em>avant</em> : on ne connaît pas le nombre de tours.</td><td><code>while (x &gt; 0) { ... }</code></td></tr>
            <tr><td><strong>DO...WHILE (C)</strong></td><td>Condition vérifiée <em>après</em> : s'exécute au moins 1 fois (ex: saisie menu).</td><td><code>do { ... } while (choix != 0);</code></td></tr>
          </table>
          <div class="warn-box">
            <strong>⚠️ Attention à la boucle infinie !</strong> Dans une boucle <code>while</code>, si vous oubliez de modifier la variable testée à l'intérieur de la boucle, votre programme restera bloqué éternellement.
          </div>
        `
      },
      {
        id: "prog-c3",
        title: "Chapitre 3 : Tableaux, Fonctions & Récursivité",
        html: `
          <h3>3.1 Les Tableaux (Arrays / Listes)</h3>
          <p>Un <strong>tableau</strong> regroupe plusieurs valeurs du même type sous un seul nom dans des cases mémoire contiguës. En C et Python, <strong>le premier élément est toujours à l'index 0</strong>, et le dernier d'un tableau de taille <code>N</code> est à l'index <code>N - 1</code>.</p>

          <h3>3.2 Fonctions et Modularité</h3>
          <p>Une <strong>fonction</strong> découpe un grand problème en sous-programmes réutilisables. Elle reçoit des <strong>paramètres</strong> en entrée et renvoie un résultat avec <code>return</code>.</p>
          <p>Une variable créée dans une fonction est dite <strong>locale</strong> : elle n'existe pas à l'extérieur de cette fonction.</p>

          <h3>3.3 La Récursivité</h3>
          <p>Une fonction est <strong>récursive</strong> lorsqu'elle s'appelle elle-même pour résoudre un sous-problème plus petit. Toute fonction récursive doit obligatoirement posséder :</p>
          <ul>
            <li><strong>Un cas de base (condition d'arrêt) :</strong> Pour stopper les appels (sinon erreur <em>Stack Overflow</em>).</li>
            <li><strong>Un appel récursif :</strong> Qui se rapproche du cas de base.</li>
          </ul>
          <div class="code-box">
            <div class="code-header"><span>Python — Calcul récursif de la factorielle n!</span><button class="copy-btn" onclick="copyCode(this)">Copier</button></div>
<pre><span class="kw">def</span> <span class="fn">factorielle</span>(n):
    <span class="kw">if</span> n &lt;= 1:              <span class="cmt"># 1. Cas de base (arrêt)</span>
        <span class="kw">return</span> 1
    <span class="kw">return</span> n * <span class="fn">factorielle</span>(n - 1)  <span class="cmt"># 2. Appel récursif</span>

<span class="fn">print</span>(<span class="fn">factorielle</span>(4))  <span class="cmt"># 4 * 3 * 2 * 1 = 24</span></pre>
          </div>
        `
      },
      {
        id: "prog-c4",
        title: "Chapitre 4 : Pointeurs en C & Complexité Big-O",
        html: `
          <h3>4.1 Comprendre les Pointeurs en Langage C</h3>
          <p>En langage C, chaque variable est stockée à une <strong>adresse mémoire</strong> précise en RAM. Un <strong>pointeur</strong> est une variable spéciale qui ne stocke pas une valeur directe, mais <em>l'adresse mémoire d'une autre variable</em>.</p>
          <ul>
            <li><code>&amp;x</code> : Donne <strong>l'adresse</strong> de la variable <code>x</code>.</li>
            <li><code>int *p</code> : Déclare un pointeur <code>p</code> vers un entier.</li>
            <li><code>*p</code> : Accède à la <strong>valeur</strong> stockée à l'adresse contenue dans <code>p</code> (déréférencement).</li>
          </ul>
          <div class="code-box">
            <div class="code-header"><span>Langage C — Modifier une variable via son pointeur</span><button class="copy-btn" onclick="copyCode(this)">Copier</button></div>
<pre><span class="kw">#include</span> &lt;stdio.h&gt;

<span class="kw">void</span> <span class="fn">doubler</span>(<span class="kw">int</span> *ptr) {
    *ptr = (*ptr) * 2;  <span class="cmt">// Modifie directement la case en RAM</span>
}

<span class="kw">int</span> <span class="fn">main</span>() {
    <span class="kw">int</span> age = 20;
    <span class="fn">doubler</span>(&amp;age);      <span class="cmt">// On passe l'adresse de age</span>
    <span class="fn">printf</span>(<span class="str">"Nouvel age = %d\\n"</span>, age); <span class="cmt">// Affiche 40</span>
    <span class="kw">return</span> 0;
}</pre>
          </div>

          <h3>4.2 Complexité Algorithmique (Notation Big-O)</h3>
          <p>La notation <strong>Grand O</strong> mesure comment le temps d'exécution grandit lorsque la taille des données <code>n</code> augmente :</p>
          <table>
            <tr><th>Complexité</th><th>Nom</th><th>Opérations pour n = 1 000</th><th>Exemple typique</th></tr>
            <tr><td><strong>O(1)</strong></td><td>Constante</td><td>1</td><td>Lire <code>tab[5]</code></td></tr>
            <tr><td><strong>O(log n)</strong></td><td>Logarithmique</td><td>~10</td><td>Recherche dichotomique (tableau trié)</td></tr>
            <tr><td><strong>O(n)</strong></td><td>Linéaire</td><td>1 000</td><td>Une boucle simple sur un tableau</td></tr>
            <tr><td><strong>O(n²)</strong></td><td>Quadratique</td><td>1 000 000</td><td>Deux boucles imbriquées (Tri à bulles)</td></tr>
          </table>
          <div class="note-box">
            <strong>📌 Langage compilé vs interprété :</strong> Le <strong>C</strong> est <em>compilé</em> directement en code machine avant exécution (très rapide, proche du matériel). <strong>Python</strong> est <em>interprété</em> ligne par ligne à la volée (plus lent, mais très simple et rapide à coder).
          </div>
        `
      }
    ],
    exercises: [
      {
        title: "Maximum d'un tableau (Sans fonction toute faite)",
        prompt: "Écrivez une fonction Python <code>trouver_max(notes)</code> qui parcourt une liste de notes (ex: <code>[11, 16, 9, 18, 13]</code>) avec une boucle <code>for</code> et retourne la plus grande note.",
        solution: "<code>def trouver_max(notes):<br/>&nbsp;&nbsp;maxi = notes[0]  # On suppose que le 1er est le plus grand<br/>&nbsp;&nbsp;for n in notes:<br/>&nbsp;&nbsp;&nbsp;&nbsp;if n &gt; maxi:<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;maxi = n<br/>&nbsp;&nbsp;return maxi</code><br/><br/>Complexité : <strong>O(n)</strong> car on parcourt la liste une seule fois."
      },
      {
        title: "Échange de deux variables par pointeurs en C",
        prompt: "Pourquoi la fonction <code>void echanger(int a, int b)</code> ne modifie-t-elle pas les variables d'origine en C, et comment la corriger avec des pointeurs ?",
        solution: "En C, les arguments simples sont passés <strong>par valeur</strong> (copies locales). Pour modifier les variables originales, il faut passer leurs <strong>adresses</strong> :<br/><br/><code>void echanger(int *a, int *b) {<br/>&nbsp;&nbsp;int temp = *a;<br/>&nbsp;&nbsp;*a = *b;<br/>&nbsp;&nbsp;*b = temp;<br/>}</code><br/>Appel : <code>echanger(&amp;x, &amp;y);</code>"
      },
      {
        title: "Fonction récursive de puissance",
        prompt: "Écrivez une fonction récursive <code>puissance(x, n)</code> qui calcule xⁿ (pour n ≥ 0), sachant que x⁰ = 1 et xⁿ = x × xⁿ⁻¹.",
        solution: "<code>def puissance(x, n):<br/>&nbsp;&nbsp;if n == 0:<br/>&nbsp;&nbsp;&nbsp;&nbsp;return 1<br/>&nbsp;&nbsp;return x * puissance(x, n - 1)</code>"
      }
    ],
    quiz: [
      {
        q: "Dans un tableau de taille 8 en C ou Python, quel est l'index du dernier élément ?",
        options: ["8", "7", "1", "0"],
        answer: 1,
        explanation: "Les index commencent à 0. Pour 8 éléments, les index vont de 0 à 7 (N - 1)."
      },
      {
        q: "Que risque-t-il de se passer si une fonction récursive n'a pas de condition d'arrêt (cas de base) ?",
        options: [
          "Elle retourne 0 automatiquement",
          "Elle boucle jusqu'à saturer la pile mémoire (Stack Overflow)",
          "Le compilateur la transforme en boucle for",
          "Rien de particulier"
        ],
        answer: 1,
        explanation: "Chaque appel empile un cadre en mémoire. Sans condition d'arrêt, la pile sature (Stack Overflow / RecursionError)."
      },
      {
        q: "En langage C, que signifie l'opérateur '&' devant une variable (ex: &age) ?",
        options: [
          "La valeur doublée de age",
          "L'adresse mémoire de la variable age",
          "La suppression de la variable",
          "Un ET logique obligatoire"
        ],
        answer: 1,
        explanation: "L'opérateur unaire & (adresse de) renvoie l'adresse en RAM où est stockée la variable."
      },
      {
        q: "Quelle boucle s'exécute toujours AU MOINS UNE FOIS même si la condition est fausse dès le départ ?",
        options: ["for", "while", "do ... while", "if ... else"],
        answer: 2,
        explanation: "Dans une boucle do...while, le bloc s'exécute d'abord et la condition est testée à la fin."
      },
      {
        q: "Parmi ces complexités algorithmiques, laquelle est la plus rapide pour traiter 1 million d'éléments ?",
        options: ["O(n²)", "O(n)", "O(log n)", "O(n log n)"],
        answer: 2,
        explanation: "Pour n = 1 000 000, O(log n) ne nécessite qu'environ 20 opérations, contre 1 000 000 pour O(n) et mille milliards pour O(n²)."
      }
    ]
  });
}