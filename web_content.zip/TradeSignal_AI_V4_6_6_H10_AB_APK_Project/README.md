# TradeSignal AI — V4.6.6 + H10 A×B
Motor V4.6.6 preservado como referência.
Novo teste:
H10-A = janela 2 / 2 de 2 Forte / 1 de 2 Moderado
H10-B = janela 2 / 2 de 2 Forte / 0 de 2 Moderado
Executa 3k, 5k e 15k e calcula ΔS, ΔLiq, ΔAcum, ΔDD, PF Forte, PF Moderado e IC-E.
Este é um projeto para compilação Android; o APK binário requer Android SDK/Gradle.
