# ReelBatch on Android

The APK was **not** built here: that needs the Android SDK and internet access, which this environment doesn't have. ReelBatch is a web app, so there are two ways to put it on a phone. Both need the backend deployed on a public HTTPS address first (see README).

## Option 1: install from Chrome (no APK, 1 minute)
1. Open your ReelBatch address in Chrome on the phone and sign in.
2. Menu (three dots) > **Install app** (or **Add to Home screen**).
3. It opens full screen from your home screen like an app.

## Option 2: make an APK from the deployed site
1. Go to **pwabuilder.com** and enter your ReelBatch address.
2. Choose **Package for stores > Android** and generate the package.
3. Download the zip. It contains the APK (and an AAB for Play Store) plus a **signing key. Keep that key safe**: you need the same key for every update.
4. Copy the APK to the phone and open it. Allow "install unknown apps" for your file manager if asked.
5. For the app to open without a browser address bar, put the `assetlinks.json` file from the zip at `public/.well-known/assetlinks.json` and redeploy. Without it the app still works but shows a browser bar.

Menu names on those sites change over time, so follow their on-screen steps if they differ.

The APK is only a shell around your server. Videos, accounts and jobs live on the backend, so the server must stay online.
