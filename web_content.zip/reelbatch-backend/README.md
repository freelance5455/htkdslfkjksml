# ReelBatch backend

Node + TypeScript service that connects **two** Instagram accounts through Meta's official authorization, queues Reels for each account, and publishes them through the Instagram content publishing API.

**Status: written but not yet run against Meta.** It needs your Meta app credentials, a public HTTPS address, and a test with real accounts before you can rely on it. The web page you already have is not yet wired to this API.

## What it does
- Separate OAuth, encrypted token, expiry and refresh for Account 1 and Account 2. No passwords are requested or stored.
- Modes: `both` (15 videos make 30 jobs), `a1`, `a2`. Per-video, per-account captions through `items[].captions`.
- Durable queue in SQLite. Jobs survive restarts and an offline phone. Different accounts run in parallel, up to 3 jobs at once per account.
- Per-job states: pending, uploading, processing, publishing, published, failed.
- No duplicate posts: unique job key, one saved container per job, a check that the container is not already PUBLISHED before publishing, and no retry once an Instagram post id exists.
- Retrying a failed job touches only that job. Account 1's post is never repeated because Account 2 failed.
- Reads each account's live publishing quota before creating a container. When it is full, the job waits an hour and shows why.
- Temporary files are deleted `RETENTION_HOURS` after the last related job finishes.

## Run locally
```
npm install
cp .env.example .env     # fill in the values
npm run dev
```
Instagram must download your videos, so `PUBLIC_BASE_URL` has to be a public HTTPS address even in development (for example a tunnel).

## Meta app setup
1. Create an app at developers.facebook.com and add the **Instagram** product, using *API setup with Instagram login*.
2. Copy the **Instagram app ID and secret** into `META_APP_ID` and `META_APP_SECRET`.
3. Add `IG_REDIRECT_URI` as a valid OAuth redirect URI. It must match exactly.
4. Request the permissions `instagram_business_basic` and `instagram_business_content_publish`.
5. Both Instagram accounts must be **Professional** (Business or Creator). While the app is in development mode, add both as Instagram testers and accept the invitations. Public use needs app review.
6. Open `/auth/instagram/1` and `/auth/instagram/2` while signed in to connect each account.

## API
| Method and path | Purpose |
|---|---|
| POST `/api/login` | `{password}`, sets a session cookie |
| GET `/auth/instagram/:slot` | Start Meta authorization for slot 1 or 2 |
| POST `/api/accounts/:slot/verify` | Check eligibility and the live quota |
| DELETE `/api/accounts/:slot` | Disconnect and fail that account's unfinished jobs |
| POST `/api/media?kind=video\|cover` | Multipart upload, field `file` |
| POST `/api/batches` | `{mode, items:[{videoId, coverId?, caption, captions?:{1,2}}], gapMinutes, starts?:{1,2}}` |
| GET `/api/batches/:id` | Per-job status table |
| GET `/api/dashboard` | Accounts, counts, recent batches |
| POST `/api/jobs/:id/retry` | Retry one failed job |

All non-GET API calls need the header `x-requested-with: reelbatch`.

## Deploy
Run on any host with Node 20 or later and persistent disk (for the SQLite file and `STORAGE_DIR`), behind HTTPS. Run exactly **one** instance, because the worker lives in the server process. To scale out, move the database to Postgres and the queue to a shared worker.

## Retention
Videos and covers are removed `RETENTION_HOURS` (default 48) after their last job ends, or after that time if never used in a batch. A failed job whose files were already deleted must be re-uploaded.

## Troubleshooting
- **Error 190 or "authorization expired":** reconnect that account.
- **Container ERROR:** the video format, size or length is not accepted. Check Meta's current Reels specifications.
- **Cover rejected:** the job fails with Meta's reason. No other image is substituted.
- **Limit reached:** the job waits and retries hourly.

## Not covered yet
React/TypeScript front end wired to this API, PWA install, Postgres, per-user accounts, automated tests, and the Android install guide. Limits and endpoint details in the code should be confirmed against Meta's current documentation.
