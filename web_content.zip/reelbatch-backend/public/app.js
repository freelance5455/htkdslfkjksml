const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmtSize=b=>b>1e9?(b/1e9).toFixed(1)+' GB':(b/1e6).toFixed(1)+' MB';
const fmtDur=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
const fmtGap=m=>m<60?m+' min':m<1440?(m/60)+' h':(m/1440)+' day';
// Limits used for local checks. Confirm against Meta's current docs before relying on them.
const LIM={max:15,mb:300,minS:3,maxS:900,cap:2200,tags:30,ments:20};
const store={get(k,d){try{return localStorage.getItem(k)??d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
const tz=Intl.DateTimeFormat().resolvedOptions().timeZone;
let vids=[],mode='both',uid=0,cover=null;
const accts=[{n:'Account 1',on:false},{n:'Account 2',on:false}];

/* theme */
const root=document.documentElement;
root.dataset.theme=store.get('rb-theme',matchMedia('(prefers-color-scheme: light)').matches?'light':'dark');
$('#theme').onclick=()=>{root.dataset.theme=root.dataset.theme==='light'?'dark':'light';store.set('rb-theme',root.dataset.theme)};

function toast(t){const e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.display='none',3500)}
function open(html){const d=$('#dlg');d.innerHTML=html;d.showModal()}
function closeDlg(){$('#dlg').close()}

/* accounts */
function renderAccts(){
 $('#accts').innerHTML=accts.map((a,i)=>`<div class="acct"><b>${a.n}</b><span><i class="dot"></i>Not connected</span>
 <div class="btns"><button class="btn" data-c="${i}">Connect</button><button class="ghost" disabled>Reconnect</button><button class="ghost" disabled>Disconnect</button></div></div>`).join('')}
$('#accts').onclick=e=>{if(e.target.dataset.c===undefined)return;
 open(`<h2>Connect ${accts[e.target.dataset.c].n}</h2><p>This opens Meta’s sign-in page and returns a token to the backend. It needs the deployed backend, a Meta app, and the <b>instagram_business_basic</b> and <b>instagram_business_content_publish</b> permissions. Until that is set up, this button cannot connect anything.</p><button class="btn" style="width:100%" onclick="closeDlg()">Close</button>`)};

/* videos */
function snap(v){const c=document.createElement('canvas');c.height=240;c.width=Math.round(240*(v.videoWidth/v.videoHeight||.5625));c.getContext('2d').drawImage(v,0,0,c.width,c.height);return c.toDataURL('image/jpeg',.7)}
function probe(file){return new Promise(res=>{
 const url=URL.createObjectURL(file),v=document.createElement('video');
 v.muted=true;v.playsInline=true;v.preload='metadata';v.src=url;
 let fin=false;const done=ok=>{if(fin)return;fin=true;clearTimeout(t);res({url,ok,dur:v.duration||0,w:v.videoWidth,h:v.videoHeight,thumb:ok?snap(v):''})};
 const t=setTimeout(()=>done(false),8000);
 v.onloadedmetadata=()=>{v.currentTime=Math.min(1,(v.duration||2)/2)};
 v.onseeked=()=>done(true);v.onerror=()=>done(false)})}
function issues(v){const a=[],ext=v.file.name.split('.').pop().toLowerCase();
 if(!['mp4','mov'].includes(ext))a.push(['bad','Only MP4 and MOV work']);
 if(v.file.size>LIM.mb*1e6)a.push(['bad','Over '+LIM.mb+' MB']);
 if(!v.ok)a.push(['bad','Could not read this video']);
 else{if(v.dur<LIM.minS)a.push(['bad','Shorter than 3 seconds']);if(v.dur>LIM.maxS)a.push(['bad','Longer than 15 minutes']);if(Math.abs(v.w/v.h-9/16)>.03)a.push(['warn','Not 9:16, may be cropped'])}
 return a}
async function addFiles(list){const room=LIM.max-vids.length,files=[...list];
 if(files.length>room)toast(room?`Only ${room} more fit. The maximum is 15.`:'You already have 15 videos.');
 for(const f of files.slice(0,room)){vids.push({id:++uid,file:f,cap:'',...await probe(f)});renderAll()}}
$('#add').onclick=()=>$('#vin').click();
$('#vin').onchange=e=>{addFiles(e.target.files);e.target.value=''};
function renderVideos(){
 $('#count').textContent=vids.length+' of 15 selected';
 $('#empty').hidden=!!vids.length;
 $('#grid').innerHTML=vids.map((v,i)=>`<article class="vcard"><button class="th" data-a="prev" data-i="${i}" aria-label="Preview ${esc(v.file.name)}">${v.thumb?`<img src="${v.thumb}" alt="">`:''}<span class="dur">${v.ok?fmtDur(v.dur):'?'}</span></button>
 <div class="vb"><b title="${esc(v.file.name)}">${esc(v.file.name)}</b><small>${fmtSize(v.file.size)}${v.cap?', own caption':''}</small>${issues(v).map(x=>`<em class="${x[0]}">${x[1]}</em>`).join('')}
 <div class="row"><button data-a="up" data-i="${i}" aria-label="Move up">↑</button><button data-a="dn" data-i="${i}" aria-label="Move down">↓</button><button data-a="rm" data-i="${i}" aria-label="Remove">✕</button></div></div></article>`).join('')}
$('#grid').onclick=e=>{const b=e.target.closest('button');if(!b)return;const i=+b.dataset.i,a=b.dataset.a;
 if(a==='rm'){URL.revokeObjectURL(vids[i].url);vids.splice(i,1)}
 else if(a==='up'&&i>0)[vids[i-1],vids[i]]=[vids[i],vids[i-1]];
 else if(a==='dn'&&i<vids.length-1)[vids[i+1],vids[i]]=[vids[i],vids[i+1]];
 else if(a==='prev'){preview(i);return}
 renderAll()};
function preview(i){const v=vids[i];
 open(`<h2>${esc(v.file.name)}</h2><video src="${v.url}" controls playsinline></video><label class="f" style="margin-top:10px">Caption for this video only (leave empty to use the shared caption)<textarea id="ov" style="min-height:90px">${esc(v.cap)}</textarea></label>
 <div class="btns"><button class="btn" id="sv">Save caption</button><button class="ghost" onclick="closeDlg()">Close</button></div>`);
 $('#sv').onclick=()=>{v.cap=$('#ov').value.trim();closeDlg();renderAll()}}
$('#dlg').addEventListener('close',()=>{const m=$('#dlg video');if(m)m.pause()});

/* caption */
const capStats=t=>({n:t.length,tags:(t.match(/#[\p{L}\p{N}_]+/gu)||[]).length,ments:(t.match(/@[\w.]+/g)||[]).length});
function renderCap(){const s=capStats($('#cap').value),p=[];
 if(s.tags>LIM.tags)p.push(`${s.tags} hashtags (limit ${LIM.tags})`);
 if(s.ments>LIM.ments)p.push(`${s.ments} mentions (limit ${LIM.ments})`);
 $('#capinfo').innerHTML=p.length?`<span class="bad">${p.join(', ')}</span>`:`<span class="muted">${s.tags} hashtags, ${s.ments} mentions</span>`;
 $('#capcount').innerHTML=`<span class="${s.n>LIM.cap?'bad':'muted'}">${s.n} / ${LIM.cap}</span>`;
 store.set('rb-cap',$('#cap').value)}
$('#cap').value=store.get('rb-cap','');
$('#cap').oninput=()=>{renderCap();renderPlan()};

/* cover */
$('#cbtn').onclick=()=>$('#cin').click();
$('#cin').onchange=e=>{const f=e.target.files[0];if(!f)return;
 if(f.type!=='image/jpeg'){toast('Choose a JPEG image.');return}
 if(cover)URL.revokeObjectURL(cover);cover=URL.createObjectURL(f);renderCover();renderPlan()};
function renderCover(){const im=$('#cimg');im.src=cover||'';im.style.display=cover?'block':'none';
 im.style.objectPosition=`${$('#px').value}% ${$('#py').value}%`;im.style.transform=`scale(${$('#zoom').value})`;$('#cempty').hidden=!!cover}
['#zoom','#px','#py'].forEach(s=>$(s).oninput=renderCover);

/* mode + schedule */
const active=a=>mode==='both'||(mode==='a1'&&a===0)||(mode==='a2'&&a===1);
$('#seg').onclick=e=>{const b=e.target.closest('button');if(!b)return;mode=b.dataset.m;
 document.querySelectorAll('#seg button').forEach(x=>x.setAttribute('aria-pressed',x===b));renderSched();renderPlan()};
function renderSched(){const later=$('#when').value==='later',both=mode==='both',d=$('#diff').checked;
 $('#s1w').hidden=!later||mode==='a2';$('#s2w').hidden=!later||mode==='a1'||(both&&!d);
 $('#diffw').hidden=!later||!both;
 $('#s1w').firstChild.textContent=mode==='a2'?'':(both&&!d?'Start time (both accounts)':'Account 1 start');
 $('#s2w').firstChild.textContent=mode==='a2'?'Account 2 start':'Account 2 start'}
['#when','#gap','#diff','#start1','#start2'].forEach(s=>$(s).onchange=()=>{renderSched();renderPlan()});
$('#tz').textContent=tz;
function slot(a,i){const m=+$('#gap').value;
 if($('#when').value==='now')return i*m?'In '+fmtGap(i*m):'Immediately';
 const el=(a===1&&mode==='both'&&$('#diff').checked)||(a===1&&mode==='a2')?$('#start2'):$('#start1');
 if(!el.value)return 'Pick a start time';
 return new Date(new Date(el.value).getTime()+i*m*60000).toLocaleString([],{dateStyle:'medium',timeStyle:'short'})}

/* plan */
function renderPlan(){
 const shared=$('#cap').value.trim(),jobs=vids.length*(mode==='both'?2:1);
 $('#n1').textContent=vids.length;$('#n2').textContent=jobs;
 $('#go').textContent=mode==='both'?'PUBLISH TO BOTH ACCOUNTS':mode==='a1'?'PUBLISH TO ACCOUNT 1':'PUBLISH TO ACCOUNT 2';
 $('#plan tbody').innerHTML=vids.length?vids.map((v,i)=>`<tr><td>${v.thumb?`<img class="mini" src="${v.thumb}" alt="">`:''}</td><td class="fn" title="${esc(v.file.name)}">${esc(v.file.name)}</td>
 ${[0,1].map(a=>active(a)?`<td><span class="chip">Pending</span><small>${slot(a,i)}</small></td>`:'<td class="muted">Skipped</td>').join('')}
 <td>${v.cap?'Own caption':shared?'Shared caption':'<span class="warn">No caption</span>'}</td><td>${cover?'Shared cover':'Auto frame'}</td><td><button class="ghost" disabled style="min-height:36px">Retry</button></td></tr>`).join(''):'<tr><td colspan="7" class="muted">Choose videos to see the plan.</td></tr>'}
function renderAll(){renderVideos();renderPlan()}

/* publish checks */
function checks(){const c=[],s=capStats($('#cap').value),bad=vids.filter(v=>issues(v).some(x=>x[0]==='bad')).length;
 c.push([vids.length>0,vids.length?`${vids.length} videos selected`:'Choose at least one video']);
 c.push([!bad,bad?`${bad} video${bad>1?'s':''} failed local checks`:'All videos pass local checks']);
 c.push([s.n<=LIM.cap&&s.tags<=LIM.tags&&s.ments<=LIM.ments,'Caption is within limits']);
 accts.forEach((a,i)=>{if(active(i))c.push([a.on,`${a.n} ${a.on?'is connected':'is not connected'}`])});
 if($('#when').value==='later'){const need=[0,1].filter(a=>active(a)&&slot(a,0)==='Pick a start time');c.push([!need.length,need.length?'Pick a start time for every account':'Schedule is set'])}
 return c}
$('#go').onclick=()=>{const c=checks(),jobs=vids.length*(mode==='both'?2:1),ok=c.every(x=>x[0]);
 open(`<h2>Confirm publishing</h2><p><b>${vids.length} videos, ${jobs} publishing jobs.</b><br><small>${$('#when').value==='now'?'Starts as soon as the queue accepts them':'Scheduled'}, time zone ${esc(tz)}</small></p>
 <ul>${c.map(x=>`<li class="${x[0]?'ok':'bad'}">${x[0]?'✓':'✕'} ${x[1]}</li>`).join('')}</ul>
 <div class="note">${ok?'Checks pass, but this prototype has no queue.':'Fix the items marked ✕ first.'} A Reel is only reported as published after Instagram confirms it, and a failed job is retried on its own so nothing is posted twice.</div>
 <div class="btns"><button class="btn" disabled>Start ${jobs} jobs (needs backend)</button><button class="ghost" onclick="closeDlg()">Back</button></div>`)};

renderAccts();renderSched();renderCover();renderCap();renderAll();
