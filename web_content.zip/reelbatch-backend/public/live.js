// Connects the page to the ReelBatch backend. Loaded after app.js and overrides its local-only parts.
(() => {
const jfetch = async (p, o = {}) => {
  const h = { 'x-requested-with': 'reelbatch' };
  if (o.json) { o.body = JSON.stringify(o.json); h['content-type'] = 'application/json'; delete o.json; }
  const r = await fetch(p, { credentials: 'same-origin', ...o, headers: h });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || 'Request failed (' + r.status + ')'); e.status = r.status; throw e; }
  return j;
};
const LBL = { pending: 'Pending', uploading: 'Uploading', processing: 'Processing', publishing: 'Publishing', published: 'Published', failed: 'Failed' };
const TXT = { connected: 'Connected', expired: 'Authorization expired', ineligible: 'Not eligible', disconnected: 'Not connected' };
let L = { batchId: store.get('rb-batch', ''), jobs: [], reported: false }, coverFile = null, timer = null;

// the original helper calls showModal() again on an open dialog, which throws
window.open = html => { const d = $('#dlg'); d.innerHTML = html; if (!d.open) d.showModal(); };

function login(msg) {
  return new Promise(res => {
    open(`<h2>Sign in</h2><p class="muted">${msg || 'Enter your ReelBatch password.'}</p>
    <input id="pw" type="password" autocomplete="current-password" style="width:100%;min-height:44px;font:inherit;padding:0 10px;border-radius:10px;border:1px solid var(--line);background:var(--s2);color:inherit">
    <div class="btns"><button class="btn" id="lg">Sign in</button></div><p class="bad" id="le"></p>`);
    $('#dlg').oncancel = e => e.preventDefault();
    $('#pw').onkeydown = e => e.key === 'Enter' && $('#lg').click();
    $('#lg').onclick = async () => {
      try { await jfetch('/api/login', { method: 'POST', json: { password: $('#pw').value } }); $('#dlg').oncancel = null; closeDlg(); res(); }
      catch (e) { $('#le').textContent = e.message; }
    };
  });
}

async function loadDash() {
  let d;
  try { d = await jfetch('/api/dashboard'); }
  catch (e) {
    if (e.status === 401) { await login(); return loadDash(); }
    $('#livenote').innerHTML = `<b>Server not reachable.</b> ${esc(e.message)}`; return;
  }
  $('#livenote').innerHTML = '<b>Connected to your ReelBatch server.</b> Publishing works only for accounts shown as Connected.';
  [1, 2].forEach(s => {
    const a = d.accounts.find(x => x.slot === s) || {};
    accts[s - 1] = { n: 'Account ' + s, user: a.username, status: a.status || 'disconnected', err: a.last_error, on: a.status === 'connected' };
  });
  renderAccts();
}

window.renderAccts = function () {
  $('#accts').innerHTML = accts.map((a, i) => {
    const st = a.status || 'disconnected', has = st !== 'disconnected';
    return `<div class="acct"><b>${a.n}${a.user ? ' (@' + esc(a.user) + ')' : ''}</b>
    <span><i class="dot" style="background:${st === 'connected' ? 'var(--ok)' : has ? 'var(--bad)' : 'var(--mu)'}"></i>${TXT[st]}</span>
    ${a.err ? `<small class="bad" style="display:block">${esc(a.err)}</small>` : ''}
    <div class="btns"><button class="btn" data-x="go" data-s="${i + 1}" ${has ? 'disabled' : ''}>Connect</button>
    <button class="ghost" data-x="go" data-s="${i + 1}" ${has ? '' : 'disabled'}>Reconnect</button>
    <button class="ghost" data-x="rm" data-s="${i + 1}" ${has ? '' : 'disabled'}>Disconnect</button></div></div>`;
  }).join('');
};
$('#accts').addEventListener('click', async e => {
  const b = e.target.closest('button[data-x]');
  if (!b || b.disabled) return;
  if (b.dataset.x === 'go') { location.href = '/auth/instagram/' + b.dataset.s; return; }
  if (!confirm('Disconnect Account ' + b.dataset.s + '? Its unfinished jobs will be marked failed.')) return;
  try { await jfetch('/api/accounts/' + b.dataset.s, { method: 'DELETE' }); } catch (x) { toast(x.message); }
  loadDash(); poll();
});

$('#cin').addEventListener('change', e => { const f = e.target.files[0]; if (f && f.type === 'image/jpeg') coverFile = f; });

function up(file, kind, cb) {
  return new Promise((res, rej) => {
    const x = new XMLHttpRequest(), fd = new FormData();
    fd.append('file', file);
    x.open('POST', '/api/media?kind=' + kind);
    x.setRequestHeader('x-requested-with', 'reelbatch');
    x.upload.onprogress = e => e.lengthComputable && cb(e.loaded / e.total);
    x.onload = () => { let j = {}; try { j = JSON.parse(x.responseText); } catch {} x.status < 300 ? res(j.id) : rej(new Error(j.error || 'Upload failed')); };
    x.onerror = () => rej(new Error('Network error during upload'));
    x.send(fd);
  });
}

$('#go').onclick = async () => {
  const jobs = vids.length * (mode === 'both' ? 2 : 1);
  open('<h2>Checking</h2><p class="muted">Verifying your accounts with Instagram.</p>');
  const c = checks();
  for (const s of [1, 2]) {
    if (!active(s - 1) || !accts[s - 1].on) continue;
    try {
      const v = await jfetch(`/api/accounts/${s}/verify`, { method: 'POST' });
      c.push([v.eligible, `Account ${s} (@${esc(v.username)}) ${v.eligible ? 'can publish' : 'is not a Business or Creator account'}`]);
      if (v.eligible) {
        const left = v.quotaTotal - v.quotaUsed;
        c.push([true, `Account ${s}: ${left} of ${v.quotaTotal} posts left in this 24-hour window${left < vids.length ? '. Jobs beyond that wait for the limit to reset.' : ''}`]);
      }
    } catch (e) { c.push([false, `Account ${s}: ${esc(e.message)}`]); loadDash(); }
  }
  const ok = c.every(x => x[0]);
  open(`<h2>Confirm publishing</h2><p><b>${vids.length} videos, ${jobs} publishing jobs.</b><br><small>${$('#when').value === 'now' ? 'Starts as soon as the queue picks them up' : 'Scheduled'}, time zone ${esc(tz)}</small></p>
  <ul>${c.map(x => `<li class="${x[0] ? 'ok' : 'bad'}">${x[0] ? '✓' : '✕'} ${x[1]}</li>`).join('')}</ul>
  <div class="note">Keep this page open while videos upload. After that the server works on its own. A Reel shows as Published only after Instagram confirms it.</div>
  <div class="btns"><button class="btn" id="st" ${ok ? '' : 'disabled'}>Start ${jobs} jobs</button><button class="ghost" onclick="closeDlg()">Back</button></div>`);
  $('#st').onclick = start;
};

async function start() {
  const note = t => open(`<h2>Uploading</h2><p>${t}</p><div class="bar"><i id="pb" style="width:0"></i></div>`);
  try {
    let coverId = null; const items = [];
    if (coverFile) { note('Uploading cover'); coverId = await up(coverFile, 'cover', p => $('#pb').style.width = p * 100 + '%'); }
    for (let i = 0; i < vids.length; i++) {
      note(`Uploading video ${i + 1} of ${vids.length}`);
      const id = await up(vids[i].file, 'video', p => $('#pb').style.width = p * 100 + '%');
      items.push({ videoId: id, coverId, caption: vids[i].cap || $('#cap').value.trim() });
    }
    const starts = {}, iso = s => new Date($(s).value).toISOString();
    if ($('#when').value === 'later') {
      const diff = $('#diff').checked && mode === 'both';
      if (mode !== 'a2') starts[1] = iso('#start1');
      if (mode !== 'a1') starts[2] = iso(mode === 'a2' || diff ? '#start2' : '#start1');
    }
    const r = await jfetch('/api/batches', { method: 'POST', json: { mode, items, gapMinutes: +$('#gap').value, starts } });
    L = { batchId: r.batchId, jobs: [], reported: false }; store.set('rb-batch', r.batchId);
    closeDlg(); toast(`${r.jobs} jobs queued`); poll();
  } catch (e) {
    open(`<h2>Could not start</h2><p class="bad">${esc(e.message)}</p><button class="btn" style="width:100%" onclick="closeDlg()">Close</button>`);
  }
}

async function poll() {
  clearTimeout(timer);
  if (!L.batchId) return;
  try { L.jobs = (await jfetch('/api/batches/' + L.batchId)).jobs; renderPlan(); }
  catch (e) { if (e.status === 401) { await login(); } }
  if (L.jobs.some(j => !['published', 'failed'].includes(j.status))) timer = setTimeout(poll, 5000);
  else if (L.jobs.length && !L.reported) {
    L.reported = true;
    toast(`Finished: ${L.jobs.filter(j => j.status === 'published').length} published, ${L.jobs.filter(j => j.status === 'failed').length} failed`);
  }
}

const _rp = renderPlan;
window.renderPlan = function () {
  const live = L.jobs.length > 0;
  $('#clr').hidden = !live;
  $('#go').textContent = mode === 'both' ? 'PUBLISH TO BOTH ACCOUNTS' : mode === 'a1' ? 'PUBLISH TO ACCOUNT 1' : 'PUBLISH TO ACCOUNT 2';
  if (!live) { $('#n3').textContent = 0; $('#n4').textContent = 0; $('#pbar').style.width = 0; return _rp(); }
  const by = {}; L.jobs.forEach(j => ((by[j.position] = by[j.position] || {})[j.slot] = j));
  const n = k => L.jobs.filter(j => j.status === k).length, done = n('published') + n('failed');
  $('#n1').textContent = Object.keys(by).length; $('#n2').textContent = L.jobs.length;
  $('#n3').textContent = n('published'); $('#n4').textContent = n('failed');
  $('#pbar').style.width = (done / L.jobs.length * 100) + '%';
  const cell = j => j ? `<td><span class="chip ${j.status}">${LBL[j.status]}</span><small>${new Date(j.run_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</small>${j.error ? `<small class="${j.status === 'failed' ? 'bad' : 'warn'}">${esc(j.error)}</small>` : ''}</td>` : '<td class="muted">Skipped</td>';
  $('#plan tbody').innerHTML = Object.keys(by).sort((a, b) => a - b).map(p => {
    const r = by[p], any = r[1] || r[2], f = [r[1], r[2]].filter(j => j && j.status === 'failed'), v = vids[p];
    return `<tr><td>${v && v.thumb ? `<img class="mini" src="${v.thumb}" alt="">` : ''}</td><td class="fn" title="${esc(any.filename)}">${esc(any.filename)}</td>${cell(r[1])}${cell(r[2])}
    <td>${any.caption ? esc(any.caption.slice(0, 24)) + '…' : 'None'}</td><td>${any.has_cover ? 'Shared cover' : 'Auto frame'}</td>
    <td><button class="ghost" data-retry="${f.map(j => j.id).join(',')}" ${f.length ? '' : 'disabled'} style="min-height:36px">Retry</button></td></tr>`;
  }).join('');
};
$('#plan').parentElement.insertAdjacentHTML('afterend', '<button class="ghost" id="clr" hidden style="margin-top:10px">Clear report</button>');
$('#clr').onclick = () => { L = { batchId: '', jobs: [], reported: false }; store.set('rb-batch', ''); renderPlan(); };
$('#plan').addEventListener('click', async e => {
  const b = e.target.closest('[data-retry]');
  if (!b || b.disabled || !b.dataset.retry) return;
  for (const id of b.dataset.retry.split(',')) { try { await jfetch(`/api/jobs/${id}/retry`, { method: 'POST' }); } catch (x) { toast(x.message); } }
  poll();
});

const q = new URLSearchParams(location.search);
if (q.get('connected')) toast('Account ' + q.get('connected') + ' connected');
if (q.get('error')) toast(q.get('error'));
history.replaceState(null, '', '/');
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
renderPlan();
loadDash().then(poll);
})();
