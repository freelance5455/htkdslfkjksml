// Official "Instagram API with Instagram Login" calls. Verify endpoints, scopes and
// the Graph version against Meta's current docs before going live.
const V = process.env.IG_GRAPH_VERSION || 'v21.0';
const G = `https://graph.instagram.com/${V}`;
export const SCOPES = 'instagram_business_basic,instagram_business_content_publish';

export class IgError extends Error {
  constructor(public code: number | undefined, msg: string, public transient: boolean) { super(msg); }
}

// Error codes treated as temporary: generic/service errors, rate limits, "media not ready yet".
const TRANSIENT = [1, 2, 4, 17, 32, 341, 613, 9007, 2207027];

async function call(url: string, init?: RequestInit): Promise<any> {
  let r: Response;
  try { r = await fetch(url, init); } catch { throw new IgError(undefined, 'Could not reach Instagram.', true); }
  const j: any = await r.json().catch(() => ({}));
  if (!r.ok || j.error) {
    const e = j.error || {};
    throw new IgError(e.code, e.error_user_msg || e.message || `Instagram returned HTTP ${r.status}.`,
      r.status >= 500 || TRANSIENT.includes(e.code));
  }
  return j;
}
const form = (o: Record<string, string | undefined>) =>
  new URLSearchParams(Object.entries(o).filter(([, v]) => v !== undefined) as [string, string][]);

export const authUrl = (state: string) =>
  'https://www.instagram.com/oauth/authorize?' + form({
    client_id: process.env.META_APP_ID, redirect_uri: process.env.IG_REDIRECT_URI,
    response_type: 'code', scope: SCOPES, state });

export async function exchangeCode(code: string): Promise<string> {
  const j = await call('https://api.instagram.com/oauth/access_token', {
    method: 'POST',
    body: form({ client_id: process.env.META_APP_ID, client_secret: process.env.META_APP_SECRET,
      grant_type: 'authorization_code', redirect_uri: process.env.IG_REDIRECT_URI, code: code.replace(/#_$/, '') }) });
  return (j.data?.[0] ?? j).access_token;
}
export async function longLived(short: string) {
  const j = await call(`https://graph.instagram.com/access_token?` + form({
    grant_type: 'ig_exchange_token', client_secret: process.env.META_APP_SECRET, access_token: short }));
  return { token: j.access_token as string, expiresAt: Date.now() + j.expires_in * 1000 };
}
export async function refresh(token: string) {
  const j = await call(`https://graph.instagram.com/refresh_access_token?` + form({
    grant_type: 'ig_refresh_token', access_token: token }));
  return { token: j.access_token as string, expiresAt: Date.now() + j.expires_in * 1000 };
}
export async function me(token: string) {
  const j = await call(`${G}/me?` + form({ fields: 'user_id,username,account_type', access_token: token }));
  return { id: String(j.user_id ?? j.id), username: j.username as string, account_type: j.account_type as string };
}
// Reads the account's live publishing quota instead of hardcoding a limit.
export async function quota(token: string, id: string) {
  const j = await call(`${G}/${id}/content_publishing_limit?` + form({ fields: 'quota_usage,config', access_token: token }));
  const d = j.data?.[0] ?? {};
  return { used: Number(d.quota_usage ?? 0), total: Number(d.config?.quota_total ?? 100) };
}
export async function createReel(token: string, id: string,
  o: { videoUrl: string; coverUrl?: string; caption: string }): Promise<string> {
  const j = await call(`${G}/${id}/media`, { method: 'POST', body: form({
    media_type: 'REELS', video_url: o.videoUrl, cover_url: o.coverUrl, caption: o.caption,
    share_to_feed: 'true', access_token: token }) });
  return j.id;
}
export async function containerStatus(token: string, cid: string): Promise<string> {
  const j = await call(`${G}/${cid}?` + form({ fields: 'status_code', access_token: token }));
  return j.status_code; // IN_PROGRESS | FINISHED | PUBLISHED | ERROR | EXPIRED
}
export async function publish(token: string, id: string, cid: string): Promise<string> {
  const j = await call(`${G}/${id}/media_publish`, { method: 'POST', body: form({ creation_id: cid, access_token: token }) });
  return j.id;
}
