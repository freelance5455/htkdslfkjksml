import 'dotenv/config'; // must stay first so env vars exist before other modules load
import express, { NextFunction, Request, Response } from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import multer from 'multer';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { db, enc, newId, verifySig } from './store.js';
import * as ig from './instagram.js';
import { startWorker } from './worker.js';

for (const k of ['APP_URL', 'PUBLIC_BASE_URL', 'META_APP_ID', 'META_APP_SECRET', 'IG_REDIRECT_URI', 'ADMIN_PASSWORD', 'SESSION_SECRET', 'MEDIA_SIGNING_SECRET'])
  if (!process.env[k]) throw new Error(`Missing environment variable ${k}`);
const SECRET = process.env.SESSION_SECRET!, APP_URL = process.env.APP_URL!;
const STORAGE = path.resolve(process.env.STORAGE_DIR || './storage');
fs.mkdirSync(STORAGE, { recursive: true });
const LIM = { videos: 15, caption: 2200, tags: 30, ments: 20, mb: 300 };

const app = express();
app.set('trust proxy', 1);
const prod = process.env.NODE_ENV === 'production';
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], scriptSrcAttr: ["'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'],
  imgSrc: ["'self'", 'data:', 'blob:'], mediaSrc: ["'self'", 'blob:'], connectSrc: ["'self'"],
  upgradeInsecureRequests: prod ? [] : null } } }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

// Lightweight health check for the hosting platform. Does not expose account data.
app.get('/health', (_req, res) => res.status(200).json({ ok: true }));

// Instagram downloads videos here. Signed, expiring URLs only.
const MIME: Record<string, string> = { video: 'video/mp4', cover: 'image/jpeg' };
app.get('/media/:id', (req, res) => {
  const m: any = db.prepare('SELECT * FROM media WHERE id=? AND deleted_at IS NULL').get(req.params.id);
  if (!m || !verifySig(m.id, Number(req.query.e), String(req.query.s))) return res.sendStatus(404);
  res.type(m.mime || MIME[m.kind]).sendFile(m.path); // sendFile supports Range requests
});

// the web app itself (dotfiles allowed so /.well-known/assetlinks.json can be served)
app.use(express.static(path.resolve('public'), { dotfiles: 'allow' }));

// ---- sign-in (single owner) ----
const sha = (s: string) => crypto.createHash('sha256').update(s).digest();
const fails = new Map<string, { n: number; t: number }>();
const secure = process.env.NODE_ENV === 'production';
app.use('/api', (req, res, next) =>
  req.method !== 'GET' && req.get('x-requested-with') !== 'reelbatch' ? res.status(403).json({ error: 'Missing request header.' }) : next());
app.post('/api/login', (req, res) => {
  const f = fails.get(req.ip!) || { n: 0, t: 0 };
  if (f.n >= 5 && Date.now() - f.t < 15 * 60e3) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' });
  if (!crypto.timingSafeEqual(sha(String(req.body?.password ?? '')), sha(process.env.ADMIN_PASSWORD!))) {
    fails.set(req.ip!, { n: f.n + 1, t: Date.now() });
    return res.status(401).json({ error: 'Wrong password.' });
  }
  fails.delete(req.ip!);
  res.cookie('rb', jwt.sign({ u: 'owner' }, SECRET, { expiresIn: '7d' }), { httpOnly: true, secure, sameSite: 'lax', maxAge: 7 * 864e5 }).json({ ok: true });
});
const authed = (req: Request, res: Response, next: NextFunction) => {
  try { jwt.verify(req.cookies.rb, SECRET); next(); } catch { res.status(401).json({ error: 'Sign in required.' }); }
};

// ---- Instagram connection (slot 1 and slot 2 are fully independent) ----
const slotOf = (v: unknown) => (v === '1' || v === '2' ? Number(v) : 0);
app.get('/auth/instagram/:slot', authed, (req, res) => {
  const slot = slotOf(req.params.slot);
  if (!slot) return res.sendStatus(400);
  res.redirect(ig.authUrl(jwt.sign({ slot, n: newId() }, SECRET, { expiresIn: '10m' })));
});
app.get('/auth/instagram/callback', async (req, res) => {
  try {
    jwt.verify(req.cookies.rb, SECRET);
    const st: any = jwt.verify(String(req.query.state), SECRET);
    if (req.query.error || !req.query.code) throw new Error('Authorization was cancelled.');
    const long = await ig.longLived(await ig.exchangeCode(String(req.query.code)));
    const who = await ig.me(long.token);
    if (db.prepare('SELECT 1 FROM accounts WHERE ig_user_id=? AND slot!=?').get(who.id, st.slot))
      throw new Error(`@${who.username} is already connected as the other account.`);
    const ok = ['BUSINESS', 'MEDIA_CREATOR'].includes(who.account_type);
    db.prepare(`INSERT OR REPLACE INTO accounts(slot,ig_user_id,username,account_type,token_enc,token_expires_at,status,last_error)
      VALUES(?,?,?,?,?,?,?,?)`).run(st.slot, who.id, who.username, who.account_type, enc(long.token), long.expiresAt,
      ok ? 'connected' : 'ineligible', ok ? null : 'Only Business and Creator accounts can publish through the API.');
    res.redirect(`${APP_URL}/?connected=${st.slot}`);
  } catch (e: any) {
    res.redirect(`${APP_URL}/?error=${encodeURIComponent(e.message || 'Connection failed.')}`);
  }
});

app.use('/api', authed);

app.post('/api/accounts/:slot/verify', async (req, res) => {
  const a: any = db.prepare('SELECT * FROM accounts WHERE slot=?').get(slotOf(req.params.slot));
  if (!a?.token_enc) return res.status(404).json({ error: 'Account is not connected.' });
  try {
    const { dec } = await import('./store.js');
    const t = dec(a.token_enc), who = await ig.me(t), q = await ig.quota(t, a.ig_user_id);
    const ok = ['BUSINESS', 'MEDIA_CREATOR'].includes(who.account_type);
    db.prepare('UPDATE accounts SET status=?, last_error=? WHERE slot=?').run(ok ? 'connected' : 'ineligible', ok ? null : 'Not a Business or Creator account.', a.slot);
    res.json({ eligible: ok, username: who.username, quotaUsed: q.used, quotaTotal: q.total });
  } catch (e: any) {
    if (e.code === 190) db.prepare("UPDATE accounts SET status='expired', last_error=? WHERE slot=?").run(e.message, a.slot);
    res.status(502).json({ error: e.message });
  }
});
app.delete('/api/accounts/:slot', (req, res) => {
  const slot = slotOf(req.params.slot);
  db.prepare("UPDATE accounts SET token_enc=NULL, status='disconnected', last_error=NULL WHERE slot=?").run(slot);
  db.prepare("UPDATE jobs SET status='failed', error='Account was disconnected.', finished_at=? WHERE slot=? AND status IN ('pending','uploading','processing','publishing')").run(Date.now(), slot);
  res.json({ ok: true });
});

// ---- uploads ----
const upload = multer({
  storage: multer.diskStorage({ destination: STORAGE, filename: (_r, f, cb) => cb(null, newId() + path.extname(f.originalname).toLowerCase()) }),
  limits: { fileSize: LIM.mb * 1e6 },
  fileFilter: (req, f, cb) => cb(null, req.query.kind === 'cover' ? f.mimetype === 'image/jpeg' : ['video/mp4', 'video/quicktime'].includes(f.mimetype)),
});
app.post('/api/media', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Unsupported file. Use MP4 or MOV for videos and JPEG for covers.' });
  const id = newId(), kind = req.query.kind === 'cover' ? 'cover' : 'video';
  db.prepare('INSERT INTO media(id,kind,path,mime,original_name,bytes,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(id, kind, req.file.path, req.file.mimetype, req.file.originalname, req.file.size, Date.now());
  res.json({ id, kind });
});

// ---- batches: Both / Account 1 only / Account 2 only ----
const capProblem = (c: string) =>
  c.length > LIM.caption ? 'Caption is over 2,200 characters.'
  : (c.match(/#[\p{L}\p{N}_]+/gu) || []).length > LIM.tags ? 'Caption has more than 30 hashtags.'
  : (c.match(/@[\w.]+/g) || []).length > LIM.ments ? 'Caption has more than 20 mentions.' : '';

app.post('/api/batches', (req, res) => {
  const { mode, items, gapMinutes = 0, starts = {} } = req.body ?? {};
  const slots = mode === 'both' ? [1, 2] : mode === 'a1' ? [1] : mode === 'a2' ? [2] : null;
  if (!slots || !Array.isArray(items) || !items.length || items.length > LIM.videos)
    return res.status(400).json({ error: 'Choose a mode and 1 to 15 videos.' });
  for (const s of slots) {
    const a: any = db.prepare('SELECT * FROM accounts WHERE slot=?').get(s);
    if (a?.status !== 'connected') return res.status(409).json({ error: `Account ${s} is not ready (${a?.status ?? 'disconnected'}). Connect or reconnect it first.` });
  }
  const gap = Math.max(0, Math.min(Number(gapMinutes) || 0, 10080)) * 60000;
  const startFor = (s: number) => {
    const t = starts[s] ? Date.parse(starts[s]) : Date.now();
    return Number.isNaN(t) ? NaN : Math.max(t, Date.now());
  };
  const bid = newId();
  try {
    db.transaction(() => {
      db.prepare('INSERT INTO batches(id,mode,created_at) VALUES(?,?,?)').run(bid, mode, Date.now());
      items.forEach((it: any, i: number) => {
        const v: any = db.prepare("SELECT 1 FROM media WHERE id=? AND kind='video' AND deleted_at IS NULL").get(it.videoId);
        if (!v) throw new Error(`Video ${i + 1} is missing. Upload it again.`);
        if (it.coverId && !db.prepare("SELECT 1 FROM media WHERE id=? AND kind='cover' AND deleted_at IS NULL").get(it.coverId))
          throw new Error(`The cover for video ${i + 1} is missing. Upload it again.`);
        for (const s of slots) {
          const caption = String(it.captions?.[s] ?? it.caption ?? ''), bad = capProblem(caption);
          if (bad) throw new Error(`Video ${i + 1}: ${bad}`);
          const start = startFor(s);
          if (Number.isNaN(start)) throw new Error('A start time is not valid.');
          const run = start + i * gap;
          db.prepare(`INSERT INTO jobs(id,batch_id,slot,position,video_id,cover_id,caption,run_at,next_at) VALUES(?,?,?,?,?,?,?,?,?)`)
            .run(newId(), bid, s, i, it.videoId, it.coverId || null, caption, run, run);
        }
      });
    })();
  } catch (e: any) { return res.status(400).json({ error: e.message }); }
  res.json({ batchId: bid, jobs: items.length * slots.length });
});

app.get('/api/batches/:id', (req, res) => {
  const jobs = db.prepare(`SELECT j.id, j.slot, j.position, j.status, j.run_at, j.attempts, j.error, j.ig_media_id, j.caption, j.cover_id IS NOT NULL AS has_cover, m.original_name AS filename
    FROM jobs j JOIN media m ON m.id=j.video_id WHERE j.batch_id=? ORDER BY j.position, j.slot`).all(req.params.id);
  res.json({ jobs });
});
app.get('/api/dashboard', (_req, res) => {
  const accounts = db.prepare('SELECT slot, username, account_type, status, token_expires_at, last_error FROM accounts ORDER BY slot').all();
  const counts = db.prepare('SELECT status, COUNT(*) AS n FROM jobs GROUP BY status').all();
  const batches = db.prepare('SELECT * FROM batches ORDER BY created_at DESC LIMIT 20').all();
  res.json({ accounts, counts, batches });
});

// Retry one failed job. A job that already has an Instagram post id is never retried.
app.post('/api/jobs/:id/retry', (req, res) => {
  const j: any = db.prepare('SELECT * FROM jobs WHERE id=?').get(req.params.id);
  if (!j || j.status !== 'failed') return res.status(400).json({ error: 'Only failed jobs can be retried.' });
  if (j.ig_media_id) return res.status(409).json({ error: 'This Reel is already published.' });
  const gone = db.prepare('SELECT 1 FROM media WHERE id IN (?,?) AND deleted_at IS NOT NULL').get(j.video_id, j.cover_id);
  if (gone) return res.status(410).json({ error: 'The video was deleted under the retention policy. Upload it again.' });
  db.prepare("UPDATE jobs SET status=?, next_at=?, attempts=0, error=NULL, finished_at=NULL WHERE id=?")
    .run(j.container_id ? 'processing' : 'pending', Date.now(), j.id);
  res.json({ ok: true });
});

startWorker();
app.listen(Number(process.env.PORT || 8080), () => console.log('ReelBatch backend listening'));
