import Database from 'better-sqlite3';
import crypto from 'node:crypto';

export const db = new Database(process.env.DB_PATH || './reelbatch.db');
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Times are epoch milliseconds. One job = one video on one account.
// UNIQUE(batch_id, slot, video_id) makes duplicate jobs impossible, and a job
// that already has ig_media_id can never be published again.
db.exec(`
CREATE TABLE IF NOT EXISTS accounts(
  slot INTEGER PRIMARY KEY CHECK(slot IN (1,2)),
  ig_user_id TEXT, username TEXT, account_type TEXT,
  token_enc TEXT, token_expires_at INTEGER,
  status TEXT NOT NULL DEFAULT 'disconnected', -- connected | expired | ineligible | disconnected
  last_error TEXT);
CREATE TABLE IF NOT EXISTS media(
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, path TEXT NOT NULL, mime TEXT NOT NULL,
  original_name TEXT, bytes INTEGER, created_at INTEGER NOT NULL, deleted_at INTEGER);
CREATE TABLE IF NOT EXISTS batches(
  id TEXT PRIMARY KEY, mode TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(
  id TEXT PRIMARY KEY,
  batch_id TEXT NOT NULL REFERENCES batches(id),
  slot INTEGER NOT NULL, position INTEGER NOT NULL,
  video_id TEXT NOT NULL REFERENCES media(id),
  cover_id TEXT REFERENCES media(id),
  caption TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending', -- pending | uploading | processing | publishing | published | failed
  run_at INTEGER NOT NULL, next_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  container_id TEXT, ig_media_id TEXT, error TEXT, finished_at INTEGER,
  UNIQUE(batch_id, slot, video_id));
CREATE INDEX IF NOT EXISTS jobs_due ON jobs(status, next_at);
`);

const key = Buffer.from(process.env.TOKEN_KEY || '', 'hex');
if (key.length !== 32) throw new Error('TOKEN_KEY must be 64 hex characters (openssl rand -hex 32)');

// AES-256-GCM: tokens are stored only in encrypted form.
export const enc = (t: string) => {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const body = Buffer.concat([c.update(t, 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), body].map((b) => b.toString('base64')).join('.');
};
export const dec = (s: string) => {
  const [iv, tag, body] = s.split('.').map((x) => Buffer.from(x, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(body), d.final()]).toString('utf8');
};

export const newId = () => crypto.randomBytes(12).toString('hex');

// Instagram fetches videos from a short-lived signed URL; nothing else is public.
const sign = (id: string, e: number) =>
  crypto.createHmac('sha256', process.env.MEDIA_SIGNING_SECRET || '').update(`${id}.${e}`).digest('hex');
export const signedMediaUrl = (id: string, ttlMs = 6 * 3600e3) => {
  const e = Date.now() + ttlMs;
  return `${process.env.PUBLIC_BASE_URL}/media/${id}?e=${e}&s=${sign(id, e)}`;
};
export const verifySig = (id: string, e: number, s: string) => {
  const good = Buffer.from(sign(id, e)), got = Buffer.from(s || '');
  return e > Date.now() && good.length === got.length && crypto.timingSafeEqual(good, got);
};
