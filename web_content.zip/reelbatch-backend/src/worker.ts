import fs from 'node:fs';
import { db, dec, enc, signedMediaUrl } from './store.js';
import * as ig from './instagram.js';

// The queue lives in the jobs table, so scheduled jobs survive restarts and an offline phone.
// Each tick advances every due job by ONE step; different accounts run in parallel.
const POLL_MS = 15_000, MAX_RETRIES = 5, MAX_POLLS = 80, PER_ACCOUNT = 3;
const now = () => Date.now();
const running = new Set<string>();

const set = (id: string, f: Record<string, unknown>) =>
  db.prepare(`UPDATE jobs SET ${Object.keys(f).map((k) => `${k}=@${k}`).join(',')} WHERE id=@id`).run({ ...f, id });
const fail = (id: string, error: string, extra: Record<string, unknown> = {}) =>
  set(id, { status: 'failed', error, finished_at: now(), ...extra });

async function advance(j: any) {
  const a: any = db.prepare('SELECT * FROM accounts WHERE slot=?').get(j.slot);
  if (!a || a.status !== 'connected')
    return fail(j.id, 'This account is not connected. Reconnect it, then retry.');
  const token = dec(a.token_enc);
  try {
    if (j.status === 'pending' || j.status === 'uploading') {
      if (!j.container_id) {
        const q = await ig.quota(token, a.ig_user_id);
        if (q.used >= q.total)
          return set(j.id, { next_at: now() + 3600e3, error: `Publishing limit reached (${q.used}/${q.total} in 24 hours). Trying again in 1 hour.` });
        set(j.id, { status: 'uploading', error: null });
        const cid = await ig.createReel(token, a.ig_user_id, {
          videoUrl: signedMediaUrl(j.video_id),
          coverUrl: j.cover_id ? signedMediaUrl(j.cover_id) : undefined,
          caption: j.caption });
        set(j.id, { container_id: cid });
      }
      return set(j.id, { status: 'processing', next_at: now() + POLL_MS, attempts: 0, error: null });
    }
    if (j.status === 'processing') {
      const s = await ig.containerStatus(token, j.container_id);
      if (s === 'FINISHED') return set(j.id, { status: 'publishing', next_at: now(), attempts: 0 });
      if (s === 'PUBLISHED') return set(j.id, { status: 'published', finished_at: now(), error: null });
      if (s === 'EXPIRED') return set(j.id, { status: 'pending', container_id: null, next_at: now() });
      if (s === 'ERROR') return fail(j.id, 'Instagram could not process this video. Check its format and size, then retry.', { container_id: null });
      if (j.attempts >= MAX_POLLS) return fail(j.id, 'Instagram is taking too long to process this video. Retry later.');
      return set(j.id, { next_at: now() + POLL_MS, attempts: j.attempts + 1 });
    }
    if (j.status === 'publishing') {
      // If a crash happened after media_publish succeeded, the container reads PUBLISHED: never publish twice.
      if ((await ig.containerStatus(token, j.container_id)) === 'PUBLISHED')
        return set(j.id, { status: 'published', finished_at: now(), error: null });
      const mediaId = await ig.publish(token, a.ig_user_id, j.container_id);
      return set(j.id, { status: 'published', ig_media_id: mediaId, finished_at: now(), error: null });
    }
  } catch (e: any) {
    const err = e instanceof ig.IgError ? e : new ig.IgError(undefined, String(e?.message || e), true);
    if (err.code === 190) {
      db.prepare("UPDATE accounts SET status='expired', last_error=? WHERE slot=?").run(err.message, j.slot);
      return fail(j.id, 'Instagram authorization expired. Reconnect the account, then retry.');
    }
    if (err.transient && j.attempts < MAX_RETRIES)
      return set(j.id, { attempts: j.attempts + 1, next_at: now() + Math.min(30e3 * 2 ** j.attempts, 3600e3),
        error: `Temporary problem, retrying: ${err.message}` });
    return fail(j.id, err.message);
  }
}

async function tick() {
  const due: any[] = db.prepare(
    "SELECT * FROM jobs WHERE status IN ('pending','uploading','processing','publishing') AND next_at<=? ORDER BY run_at, position LIMIT 60"
  ).all(now());
  const perSlot: Record<number, number> = { 1: 0, 2: 0 };
  const batch = due.filter((j) => !running.has(j.id) && perSlot[j.slot]++ < PER_ACCOUNT);
  await Promise.all(batch.map(async (j) => {
    running.add(j.id);
    try { await advance(j); } finally { running.delete(j.id); }
  }));
}

async function housekeeping() {
  // Refresh long-lived tokens that expire within 10 days.
  for (const a of db.prepare("SELECT * FROM accounts WHERE status='connected' AND token_expires_at<?").all(now() + 10 * 864e5) as any[]) {
    try {
      const r = await ig.refresh(dec(a.token_enc));
      db.prepare('UPDATE accounts SET token_enc=?, token_expires_at=? WHERE slot=?').run(enc(r.token), r.expiresAt, a.slot);
    } catch (e: any) {
      if (e.code === 190) db.prepare("UPDATE accounts SET status='expired', last_error=? WHERE slot=?").run(e.message, a.slot);
    }
  }
  // Retention: delete files once no unfinished job needs them and the last one ended long enough ago.
  const hours = Number(process.env.RETENTION_HOURS || 48), cutoff = now() - hours * 3600e3;
  const old = db.prepare(`SELECT * FROM media m WHERE deleted_at IS NULL AND created_at<? AND NOT EXISTS (
    SELECT 1 FROM jobs j WHERE (j.video_id=m.id OR j.cover_id=m.id) AND (j.finished_at IS NULL OR j.finished_at>?))`).all(cutoff, cutoff) as any[];
  for (const m of old) {
    try { fs.rmSync(m.path, { force: true }); } catch {}
    db.prepare('UPDATE media SET deleted_at=? WHERE id=?').run(now(), m.id);
  }
}

export function startWorker() {
  setInterval(() => tick().catch((e) => console.error('tick', e)), 5000);
  setInterval(() => housekeeping().catch((e) => console.error('housekeeping', e)), 3600e3);
  housekeeping().catch(() => {});
}
