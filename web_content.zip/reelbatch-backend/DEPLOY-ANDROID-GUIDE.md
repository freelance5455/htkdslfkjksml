# ReelBatch: prepare and deploy from Android

## Important status
This project is a single-owner Node.js/TypeScript backend with a browser UI. It has not yet been tested against a live Meta app or real Instagram accounts. Do not rely on it for unattended publishing until a test batch succeeds.

## Deploy on Render
1. Upload this project folder to a **private** GitHub repository. Do not upload `.env`, real credentials, access tokens, or the SQLite database. `.gitignore` is included.
2. In Render, choose **New > Blueprint** and connect the private repository containing `render.yaml`.
3. When prompted, set the following values in the Render service environment:
   - `APP_URL`: your final Render HTTPS service URL, e.g. `https://YOUR-SERVICE.onrender.com`
   - `PUBLIC_BASE_URL`: the same final HTTPS service URL
   - `IG_REDIRECT_URI`: `https://YOUR-SERVICE.onrender.com/auth/instagram/callback`
   - `META_APP_ID`: Instagram app ID from Meta's Instagram API setup
   - `META_APP_SECRET`: matching Instagram app secret
   - `ADMIN_PASSWORD`: a strong, unique password
   - `TOKEN_KEY`: exactly 64 hexadecimal characters (32 random bytes)
4. Wait for deployment. Test `https://YOUR-SERVICE.onrender.com/health`; expected response is `{"ok":true}`.
5. Open the service URL, sign in with `ADMIN_PASSWORD`, then connect Account 1 and Account 2.

### Generate TOKEN_KEY safely
Generate 32 random bytes with a trusted password manager or secure random generator and encode as 64 hexadecimal characters. Do not reuse `SESSION_SECRET` or `MEDIA_SIGNING_SECRET` for this key. Keep all secrets private.

## Meta configuration
- Configure the exact redirect URI above in the Meta developer dashboard.
- Use the permissions and Instagram Login setup documented in `README.md` and verify against Meta's current documentation.
- In development mode, both accounts may need to be added as testers and accept the invitations. Public use may require app review and business verification.
- Use only eligible Instagram Professional (Business or Creator) accounts. Never enter Instagram passwords into ReelBatch.

## Storage and operating constraints
- A persistent disk is configured at `/var/data` for the SQLite database and media files. This hosting configuration may incur charges; check current Render pricing before deploying.
- Run exactly one service instance because the publishing worker runs inside the web process.
- Keep the service online while scheduled jobs need to run. Test with one non-sensitive Reel before using batches.
- The app is single-owner, not a multi-user service. Do not share the URL and admin password publicly.
