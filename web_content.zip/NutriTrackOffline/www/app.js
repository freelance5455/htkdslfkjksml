const $ = id => document.getElementById(id);
let foods = [], selected = null, photoData = null;
const MEAL_TYPES = ["الإفطار","الغداء","العشاء","وجبة خفيفة"];
const STORE = {entries:"nutritrack.entries.v1", goals:"nutritrack.goals.v1"};
function read(key, fallback){try{return JSON.parse(localStorage.getItem(key)) ?? fallback}catch{return fallback}}
function write(key,val){localStorage.setItem(key,JSON.stringify(val))}
function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function todayEntries(){return read(STORE.entries,[]).filter(x=>x.date===today())}
function goals(){return read(STORE.goals,{kcal:2200,protein:150})}
function n(v){return Math.round((Number(v)||0)*10)/10}
function nutrients(food, grams){const f=grams/100;return {kcal:n(food.kcal*f),protein:n(food.protein*f),carbs:n(food.carbs*f),fat:n(food.fat*f),fiber:n(food.fiber*f),sugar:n(food.sugar*f)}}
function totals(entries){return entries.reduce((t,e)=>{for(const k of ["kcal","protein","carbs","fat","fiber","sugar"])t[k]+=Number(e[k])||0;return t},{kcal:0,protein:0,carbs:0,fat:0,fiber:0,sugar:0})}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2100)}
function render(){
 const entries=todayEntries(), t=totals(entries), g=goals();
 $("todayLabel").textContent=new Date().toLocaleDateString("ar-EG",{weekday:"short",day:"numeric",month:"short"});
 $("totalKcal").textContent=Math.round(t.kcal);$("goalKcal").textContent=g.kcal;$("remaining").textContent=Math.max(0,Math.round(g.kcal-t.kcal));
 $("totalProtein").textContent=n(t.protein);$("goalProtein").textContent=g.protein;
 $("calProgress").style.width=Math.min(100,t.kcal/g.kcal*100)+"%";$("proteinProgress").style.width=Math.min(100,t.protein/g.protein*100)+"%";
 for(const [id,key] of [["totalCarbs","carbs"],["totalFat","fat"],["totalFiber","fiber"],["totalSugar","sugar"]])$(id).textContent=n(t[key])+" g";
 $("dailyGoal").value=g.kcal;$("proteinGoalInput").value=g.protein;
 $("meals").innerHTML=MEAL_TYPES.map(type=>{
   const group=entries.filter(e=>e.meal===type), sum=totals(group);
   return `<section class="meal-card"><div class="meal-title"><span>${type}</span><span class="meal-total">${Math.round(sum.kcal)} kcal</span></div>${group.length?group.map(e=>`<div class="food-row"><div class="food-emoji">${e.emoji||"🥗"}</div><div class="food-info"><b>${esc(e.nameAr||e.name)}</b><small>${e.grams} جم · بروتين ${n(e.protein)} g · كربوهيدرات ${n(e.carbs)} g · دهون ${n(e.fat)} g</small></div><div class="food-kcal">${Math.round(e.kcal)}<small> kcal</small></div><button class="remove" data-remove="${e.id}" aria-label="حذف">×</button></div>`).join(""):`<div class="empty">لم تُضف أطعمة بعد</div>`}</section>`;
 }).join("");
 document.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{const id=b.dataset.remove;write(STORE.entries,read(STORE.entries,[]).filter(e=>e.id!==id));render();toast("تم حذف الطعام")}));
}
function renderFoods(){
 const q=$("foodSearch").value.trim().toLocaleLowerCase();
 const found=foods.filter(f=>!q||`${f.name} ${f.ar} ${f.category}`.toLocaleLowerCase().includes(q)).slice(0,35);
 $("foodResults").innerHTML=found.map(f=>`<button class="food-option" data-food="${f.id}"><span><b>${esc(f.ar)}</b><small>${esc(f.name)}</small></span><em>${f.kcal} kcal / 100g</em></button>`).join("")||'<div class="empty">لا توجد نتيجة. جرّب كلمة أخرى.</div>';
 document.querySelectorAll("[data-food]").forEach(b=>b.addEventListener("click",()=>chooseFood(b.dataset.food)));
}
function chooseFood(id){selected=foods.find(f=>f.id===id);if(!selected)return;$("selectedFood").classList.remove("hidden");$("selectedName").textContent=selected.ar+" · "+selected.name;$("selectedPer100").textContent=`لكل 100 جم: ${selected.kcal} سعرة، بروتين ${selected.protein} جم`;updatePreview();$("selectedFood").scrollIntoView({behavior:"smooth",block:"nearest"})}
function updatePreview(){if(!selected)return;const x=nutrients(selected,Math.max(0,Number($("foodWeight").value)||0));$("nutritionPreview").innerHTML=`<span><b>${x.kcal}</b>سعرة</span><span><b>${x.protein} g</b>بروتين</span><span><b>${x.carbs} g</b>كربوهيدرات</span><span><b>${x.fat} g</b>دهون</span><span><b>${x.fiber} g</b>ألياف</span><span><b>${x.sugar} g</b>سكريات</span>`}
function addSelected(){if(!selected){toast("اختر طعامًا أولًا");return}const grams=Number($("foodWeight").value);if(!Number.isFinite(grams)||grams<=0||grams>5000){toast("أدخل وزنًا بين 1 و5000 جرام");return}const v=nutrients(selected,grams);const all=read(STORE.entries,[]);all.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random()),date:today(),meal:$("mealType").value,foodId:selected.id,name:selected.name,nameAr:selected.ar,grams,emoji:emoji(selected.category),...v});write(STORE.entries,all);$("foodSearch").value="";$("selectedFood").classList.add("hidden");selected=null;renderFoods();render();toast("تمت إضافة الطعام بنجاح")}
function emoji(cat){return ({Protein:"🍗",Grains:"🍚",Vegetables:"🥦",Fruit:"🍎",Dairy:"🥛",Legumes:"🫘",Nuts:"🥜",Fats:"🫒",Prepared:"🍽️"})[cat]||"🥗"}
function openPanel(){ $("addPanel").scrollIntoView({behavior:"smooth",block:"start"});$("foodSearch").focus({preventScroll:true})}
$("addFoodTop").addEventListener("click",openPanel);$("navAdd").addEventListener("click",e=>{e.preventDefault();openPanel()});$("closePanel").addEventListener("click",()=>$("addPanel").classList.toggle("collapsed"));
$("foodSearch").addEventListener("input",renderFoods);$("foodWeight").addEventListener("input",updatePreview);$("saveFood").addEventListener("click",addSelected);
$("saveGoals").addEventListener("click",()=>{const kcal=Number($("dailyGoal").value),protein=Number($("proteinGoalInput").value);if(kcal<500||kcal>10000||protein<10||protein>500){toast("تحقق من الأهداف المدخلة");return}write(STORE.goals,{kcal,protein});render();toast("تم حفظ الأهداف")});
$("settingsBtn").addEventListener("click",()=>document.querySelector(".settings-grid").scrollIntoView({behavior:"smooth",block:"center"}));
$("foodPhoto").addEventListener("change",e=>{const file=e.target.files&&e.target.files[0];if(!file)return;if(file.size>12*1024*1024){toast("اختر صورة أصغر من 12 ميجابايت");e.target.value="";return}const r=new FileReader();r.onload=()=>{photoData=r.result;$("photoPreview").src=photoData;$("photoPreviewWrap").classList.remove("hidden");};r.readAsDataURL(file)});
$("clearPhoto").addEventListener("click",()=>{photoData=null;$("foodPhoto").value="";$("photoPreview").removeAttribute("src");$("photoPreviewWrap").classList.add("hidden")});
$("photoAddFood").addEventListener("click",()=>{openPanel();toast("ابحث عن كل صنف ظاهر في الصورة وأدخل وزنه؛ التعرف التلقائي يحتاج إلى نموذج رؤية إضافي.")});
$("navHistory").addEventListener("click",e=>{e.preventDefault();const all=read(STORE.entries,[]);const days=[...new Set(all.map(x=>x.date))].sort().reverse();alert(days.length?"سجل الأيام:\n"+days.map(d=>{const t=totals(all.filter(x=>x.date===d));return `${d}: ${Math.round(t.kcal)} kcal · بروتين ${n(t.protein)} g`}).join("\n"):"لا يوجد سجل سابق بعد.")});
async function init(){try{const res=await fetch("foods.json");foods=await res.json()}catch(e){foods=[];toast("تعذر تحميل قاعدة الطعام. افتح التطبيق عبر الخادم المحلي أو APK.")}renderFoods();render()}
init();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
