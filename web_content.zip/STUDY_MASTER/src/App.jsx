import { useMemo, useRef, useState } from 'react'
import { createWorker } from 'tesseract.js'
import * as pdfjsLib from 'pdfjs-dist'
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url'
import mammoth from 'mammoth/mammoth.browser'
import {
  BookOpen, FileText, ImagePlus, ClipboardCheck, MessageSquareText,
  Library, Settings, Zap, ShieldCheck, ChevronLeft, Menu, X,
  FileUp, Search, Sparkles, GraduationCap, Clock3, Plus, CheckCircle2,
  Trash2, Download, Copy, RefreshCw, ArrowRight, AlertCircle, Home,
  PanelLeftClose, FileSearch, CircleHelp
} from 'lucide-react'

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl

const MODES = [
  { id: 'explain', title: 'شرح تفصيلي', desc: 'قسّم المحتوى إلى عناوين ونقاط مرتبة.', icon: BookOpen, tone: 'blue' },
  { id: 'qa', title: 'أسئلة وأجوبة', desc: 'أنشئ أسئلة مراجعة من النص المستخرج.', icon: MessageSquareText, tone: 'green' },
  { id: 'quiz', title: 'اختبار', desc: 'اختبر معلوماتك وصحّح إجاباتك.', icon: ClipboardCheck, tone: 'orange' }
]
const STORAGE_KEY = 'study-master-library-v1'
const store = {
  get(k, d = '') { try { return localStorage.getItem(k) ?? d } catch { return d } },
  set(k, v) { try { localStorage.setItem(k, v); return true } catch { return false } }
}
function shuffle(arr) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]] }
  return a
}
const cleanWord = w => w.replace(/^[\s"'«»()\[\]{}،,.:;!؟?؛\-–—]+|[\s"'«»()\[\]{}،,.:;!؟?؛\-–—]+$/g, '')

function splitSentences(text) {
  return text.replace(/\s+/g, ' ').split(/(?<=[.!؟?؛])\s+|[\n\r]+/).map(s => s.trim()).filter(s => s.length > 25)
}
function makeExplanation(text) {
  const paragraphs = text.split(/\n{2,}/).map(x => x.trim()).filter(x => x.length > 35)
  const chunks = paragraphs.length > 1 ? paragraphs : splitSentences(text).reduce((a, s, i) => {
    const k = Math.floor(i / 4); (a[k] ||= []).push(s); return a
  }, []).map(x => x.join(' '))
  return chunks.slice(0, 80).map((content, i) => ({
    title: `الجزء ${i + 1}`,
    content: content.length > 900 ? content.slice(0, 900) + '…' : content
  }))
}
function makeQA(text) {
  const sentences = splitSentences(text).filter(s => s.length > 45)
  return sentences.slice(0, 30).map(s => {
    const words = s.split(/\s+/)
    const head = words.slice(0, 6).join(' ')
    return { question: `اشرح باختصار ما يقوله النص عن: «${head}${words.length > 6 ? '…' : ''}»`, answer: s }
  })
}
function makeQuiz(text) {
  const sentences = splitSentences(text).filter(s => s.length > 55)
  const pool = [...new Set(sentences.flatMap(s => s.split(/\s+/).map(cleanWord)).filter(w => w.length > 3))]
  return sentences.slice(0, 20).map(s => {
    const words = s.split(/\s+/)
    const candidates = words.map((w, i) => [cleanWord(w), i]).filter(([w]) => w.length > 4)
    if (!candidates.length) return null
    const [answer, idx] = candidates[Math.floor(candidates.length / 2)]
    const blanked = words.map((w, i) => i === idx ? w.replace(answer, '________') : w).join(' ')
    const near = pool.filter(w => w !== answer && Math.abs(w.length - answer.length) <= 3)
    const wrong = shuffle(near.length >= 3 ? near : pool.filter(w => w !== answer)).slice(0, 3)
    const fillers = ['المفهوم', 'النتيجة', 'المثال']
    while (wrong.length < 3) wrong.push(fillers[wrong.length])
    return {
      question: `اختر الكلمة المناسبة لإكمال العبارة:\n${blanked}`,
      answer,
      choices: shuffle([answer, ...wrong])
    }
  }).filter(Boolean)
}
function downloadText(filename, text) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  URL.revokeObjectURL(url)
}
function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsArrayBuffer(file)
  })
}

export default function App() {
  const [page, setPage] = useState('الرئيسية')
  const [file, setFile] = useState(null)
  const [text, setText] = useState('')
  const [mode, setMode] = useState('explain')
  const [result, setResult] = useState(null)
  const [busy, setBusy] = useState(false)
  const [progress, setProgress] = useState('')
  const [notice, setNotice] = useState('')
  const [library, setLibrary] = useState(() => {
    try { return JSON.parse(store.get(STORAGE_KEY, '[]')) } catch { return [] }
  })
  const [answers, setAnswers] = useState({})
  const [showAnswers, setShowAnswers] = useState(false)
  const [license, setLicense] = useState(store.get('sm-license'))
  const [turbo, setTurbo] = useState(store.get('sm-turbo') === 'true')
  const inputRef = useRef(null)

  const quizScore = useMemo(() => {
    if (!result || result.type !== 'quiz') return null
    return result.items.reduce((n, q, i) => n + (answers[i] === q.answer ? 1 : 0), 0)
  }, [result, answers])

  function saveLibrary(next) {
    setLibrary(next)
    if (!store.set(STORAGE_KEY, JSON.stringify(next))) setNotice('مساحة التخزين ممتلئة. احذف بعض الملفات المحفوظة.')
  }
  function chooseFile(e) {
    const f = e.target.files?.[0]
    if (!f) return
    const ext = f.name.split('.').pop().toLowerCase()
    if (!['pdf', 'docx', 'txt', 'png', 'jpg', 'jpeg', 'webp', 'bmp'].includes(ext)) {
      setNotice('نوع الملف غير مدعوم. استخدم PDF أو Word أو TXT أو صورة.')
      return
    }
    setFile(f); setText(''); setResult(null); setNotice(`تم اختيار ${f.name}`)
  }

  async function extractText() {
    if (!file) { setNotice('اختر ملفاً أولاً.'); return '' }
    const ext = file.name.split('.').pop().toLowerCase()
    if (!(file instanceof Blob)) return text
    setBusy(true); setProgress('جارٍ قراءة الملف…'); setNotice('')
    try {
      let extracted = ''
      if (ext === 'txt') {
        extracted = await file.text()
      } else if (ext === 'docx') {
        const buffer = await readFileAsArrayBuffer(file)
        const out = await mammoth.extractRawText({ arrayBuffer: buffer })
        extracted = out.value
      } else if (ext === 'pdf') {
        const buffer = await readFileAsArrayBuffer(file)
        const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise
        const pages = []
        for (let i = 1; i <= pdf.numPages; i++) {
          setProgress(`قراءة صفحة ${i} من ${pdf.numPages}…`)
          const page = await pdf.getPage(i)
          const content = await page.getTextContent()
          pages.push(content.items.map(x => x.str).join(' '))
        }
        extracted = pages.join('\n\n')
        if (!extracted.trim()) setNotice('الـ PDF يبدو ممسوحاً ضوئياً. حوّله إلى صور أو استخدم صور الصفحات لميزة OCR.')
      } else {
        setProgress('تهيئة قارئ الصور OCR…')
        const worker = await createWorker('ara+eng', 1, {
          logger: m => { if (m.status === 'recognizing text') setProgress(`قراءة الصورة ${Math.round(m.progress * 100)}%…`) }
        })
        try {
          const out = await worker.recognize(file)
          extracted = out.data.text
        } finally { await worker.terminate() }
      }
      setText(extracted.trim())
      if (extracted.trim()) setNotice(`تم استخراج ${extracted.trim().length.toLocaleString('ar-EG')} حرفاً.`)
      else if (ext !== 'pdf') setNotice('لم يتم العثور على نص واضح داخل الملف.')
      return extracted.trim()
    } catch (err) {
      console.error(err)
      setNotice(`تعذرت قراءة الملف: ${err.message || 'خطأ غير معروف'}`)
      return ''
    } finally { setBusy(false); setProgress('') }
  }

  async function generate() {
    const source = text.trim() || await extractText()
    if (!source) return
    setBusy(true); setProgress(turbo ? 'معالجة سريعة على دفعات…' : 'تنظيم المحتوى…')
    try {
      await new Promise(r => setTimeout(r, 80))
      const maker = { explain: makeExplanation, qa: makeQA, quiz: makeQuiz }[mode]
      const items = maker(source)
      if (!items.length) { setResult(null); setNotice('النص قصير أو غير كافٍ لإنشاء هذا النوع. جرّب ملفاً أطول أو طريقة أخرى.'); return }
      setResult({ type: mode, items }); setAnswers({}); setShowAnswers(false)
      const entry = { id: Date.now(), name: file?.name || 'محتوى مستورد', mode, text: source, date: new Date().toISOString() }
      saveLibrary([entry, ...library.filter(x => x.name !== entry.name)].slice(0, 30))
      setNotice(`تم إنشاء ${MODES.find(x => x.id === mode).title} اعتماداً على النص المستخرج.`)
    } catch (err) {
      console.error(err); setNotice(`حدث خطأ أثناء الإنشاء: ${err.message || 'غير معروف'}`)
    } finally { setBusy(false); setProgress('') }
  }

  function openSaved(doc) {
    setText(doc.text); setFile({ name: doc.name }); setMode(doc.mode || 'explain')
    setResult(null); setAnswers({}); setShowAnswers(false); setPage('الرئيسية')
    setNotice(`تم فتح ${doc.name}. اختر طريقة العرض ثم اضغط إنشاء.`)
  }
  function removeSaved(id) { saveLibrary(library.filter(x => x.id !== id)) }
  function exportResult() {
    if (!result) return
    let content = `STUDY MASTER\n${MODES.find(x => x.id === result.type).title}\n\n`
    if (result.type === 'explain') content += result.items.map(x => `${x.title}\n${x.content}`).join('\n\n')
    if (result.type === 'qa') content += result.items.map((x,i) => `${i+1}. ${x.question}\nالإجابة: ${x.answer}`).join('\n\n')
    if (result.type === 'quiz') content += result.items.map((x,i) => `${i+1}. ${x.question}\n${x.choices.join(' | ')}\nالإجابة: ${x.answer}`).join('\n\n')
    downloadText('study-master-result.txt', content)
  }

  const nav = [['الرئيسية', Home], ['مكتبتي', Library], ['اختباراتي', ClipboardCheck], ['الإعدادات', Settings]]
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><GraduationCap size={23}/></div><div><b>STUDY MASTER</b><small>ذاكر بطريقة أذكى</small></div></div>
      <div className="side-label">القائمة الرئيسية</div>
      <nav>{nav.map(([label, Icon]) => <button key={label} className={`nav-item ${page === label ? 'active' : ''}`} onClick={() => {setPage(label);setNotice('')}}><Icon size={19}/><span>{label}</span>{page === label && <ChevronLeft size={16} className="nav-arrow"/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="offline-card"><ShieldCheck size={18}/><div><b>خصوصيتك أولاً</b><small>لا يوجد اتصال بخدمات AI</small></div></div><small className="version">الإصدار 1.1.0</small></div>
    </aside>

    <main className="main">
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setPage(page === 'القائمة' ? 'الرئيسية' : 'القائمة')} aria-label="القائمة"><Menu size={22}/></button>
        <div><span className="eyebrow">مساحتك التعليمية</span><h1>{page === 'الرئيسية' ? 'أهلاً بك في STUDY MASTER' : page}</h1></div>
        <div className="top-actions"><span className="local-pill"><span/> معالجة على جهازك</span><div className="avatar">SM</div></div>
      </header>

      {page === 'الرئيسية' && <>
        <section className="hero"><div className="hero-copy"><span className="hero-tag"><Sparkles size={14}/> تعلّم بطريقتك</span><h2>حوّل ملفاتك إلى<br/><em>محتوى دراسي</em></h2><p>ارفع مذكرتك أو صور دروسك، واختر الطريقة التي تناسب مذاكرتك.</p><button className="primary-btn" onClick={() => inputRef.current?.click()}><FileUp size={18}/> ارفع ملفاً الآن</button></div><div className="hero-art"><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="book-illustration"><BookOpen size={78}/><span>STUDY</span></div><div className="float-chip chip-one"><CheckCircle2 size={16}/> تعلّم بسهولة</div><div className="float-chip chip-two"><Zap size={16}/> Turbo Mode</div></div></section>
        <section className="section-head"><div><span className="eyebrow">ابدأ من هنا</span><h3>ماذا تريد أن تفعل؟</h3></div><span className="muted">3 طرق للمذاكرة</span></section>
        <section className="options-grid">{MODES.map(({id,title,desc,icon:Icon,tone}) => <button key={id} className={`option-card ${mode === id ? 'selected' : ''}`} onClick={() => setMode(id)}><div className={`option-icon ${tone}`}><Icon size={23}/></div><h4>{title}</h4><p>{desc}</p><span className="card-link">اختيار <ChevronLeft size={16}/></span></button>)}</section>
        <section className="upload-panel"><div className="upload-icon"><ImagePlus size={24}/></div><div className="upload-text"><h3>أضف كتابك أو مذكرتك</h3><p>صور JPG وPNG وملفات PDF وWord وTXT.</p>{file && <div className="file-chip"><FileText size={15}/>{file.name}<button onClick={() => {setFile(null);setText('');setResult(null)}}><X size={14}/></button></div>}</div><button className="secondary-btn" onClick={() => inputRef.current?.click()}><Plus size={17}/> اختيار ملف</button><input ref={inputRef} type="file" hidden accept=".pdf,.docx,.txt,.png,.jpg,.jpeg,.webp,.bmp" onChange={chooseFile}/></section>
        {(file || text) && <section className="generate-panel"><div><b>الملف جاهز للمعالجة</b><p>اختر إحدى الطرق الثلاث ثم ابدأ.</p></div><button className="primary-btn" disabled={busy || !mode} onClick={generate}>{busy ? <RefreshCw className="spin" size={17}/> : <Sparkles size={17}/>} {busy ? 'جارٍ العمل…' : 'إنشاء المحتوى'}</button></section>}
        {progress && <div className="progress-line">{progress}</div>}
        {notice && <div className="notice"><CheckCircle2 size={17}/>{notice}</div>}
        {result && <ResultView result={result} answers={answers} setAnswers={setAnswers} showAnswers={showAnswers} setShowAnswers={setShowAnswers} score={quizScore} onExport={exportResult}/>}
      </>}

      {page === 'مكتبتي' && <section className="page-content"><div className="section-head"><div><span className="eyebrow">ملفاتك المحفوظة</span><h3>مكتبتي</h3></div><span className="muted">{library.length} ملف</span></div>{library.length ? <div className="library-list">{library.map(doc => <div className="library-item" key={doc.id}><div className="library-file"><FileText/></div><div className="library-meta"><b>{doc.name}</b><small>{new Date(doc.date).toLocaleDateString('ar-EG')} · {doc.text.length.toLocaleString('ar-EG')} حرف</small></div><button className="icon-btn" onClick={() => openSaved(doc)} title="فتح"><ChevronLeft/></button><button className="icon-btn danger" onClick={() => removeSaved(doc.id)} title="حذف"><Trash2/></button></div>)}</div> : <Empty title="مكتبتك فارغة حالياً" desc="عندما تنشئ شرحاً أو أسئلة، سيُحفظ النص المستخرج هنا."/>}</section>}

      {page === 'اختباراتي' && <section className="page-content"><span className="eyebrow">مراجعتك وتقدمك</span><h2>اختباراتي</h2><Empty title="لا توجد اختبارات محفوظة بعد" desc="أنشئ اختباراً من أي مذكرة، وستظهر هنا عند تطوير سجل الاختبارات."/><button className="secondary-btn" onClick={() => setPage('الرئيسية')}>إنشاء اختبار جديد</button></section>}

      {page === 'الإعدادات' && <section className="page-content settings-page"><span className="eyebrow">تخصيص التطبيق</span><h2>الإعدادات والترخيص</h2><div className="setting-card"><div className="setting-title"><ShieldCheck/><div><b>كود الترخيص</b><p>نموذج واجهة تفعيل محلي أولي.</p></div></div><div className="license-row"><input value={license} onChange={e=>setLicense(e.target.value)} placeholder="أدخل كود الترخيص"/><button onClick={()=>{if(license.trim().length < 6){setNotice('أدخل كوداً من 6 أحرف على الأقل.');return}store.set('sm-license',license.trim());setNotice('تم حفظ الكود محلياً كنموذج تجريبي، وليس تحققاً آمناً من الترخيص.')}}>حفظ</button></div></div><div className="setting-card"><div className="setting-title"><Zap/><div><b>Turbo Mode</b><p>تقسيم بعض المهام إلى دفعات لتقليل الضغط.</p></div></div><label className="switch"><input type="checkbox" checked={turbo} onChange={e=>{setTurbo(e.target.checked);store.set('sm-turbo',String(e.target.checked))}}/><span/></label></div><div className="setting-card"><div className="setting-title"><ShieldCheck/><div><b>الخصوصية والعمل المحلي</b><p>لا نرسل ملفاتك إلى خادم أو خدمة ذكاء اصطناعي. OCR قد يحتاج تنزيل بيانات اللغة أول مرة.</p></div></div><span className="local-pill"><span/> محلي</span></div></section>}

      {page === 'القائمة' && <div className="mobile-nav">{nav.map(([label,Icon])=><button key={label} onClick={()=>setPage(label)}><Icon/>{label}</button>)}</div>}
      <footer><span>© 2026 STUDY MASTER</span><span>تنظيم ومراجعة بدون ذكاء اصطناعي</span></footer>
    </main>
  </div>
}

function ResultView({result,answers,setAnswers,showAnswers,setShowAnswers,score,onExport}) {
  const title = MODES.find(x=>x.id===result.type)?.title
  return <section className="result-section"><div className="result-heading"><div><span className="eyebrow">المحتوى الناتج</span><h3>{title}</h3></div><button className="secondary-btn" onClick={onExport}><Download size={16}/> تصدير TXT</button></div>
    {result.type === 'explain' && result.items.map((x,i)=><article className="content-card" key={i}><h4>{x.title}</h4><p>{x.content}</p></article>)}
    {result.type === 'qa' && result.items.map((x,i)=><details className="qa-card" key={i}><summary>{i+1}. {x.question}</summary><p>{x.answer}</p></details>)}
    {result.type === 'quiz' && <><div className="quiz-tools"><span>عدد الأسئلة: {result.items.length}</span><button className="secondary-btn" onClick={()=>setShowAnswers(!showAnswers)}>{showAnswers ? 'إخفاء التصحيح' : 'إنهاء وتصحيح'}</button>{showAnswers && <b>النتيجة: {score} / {result.items.length}</b>}</div>{result.items.map((q,i)=><article className="quiz-card" key={i}><b>{i+1}. {q.question}</b><div className="choices">{q.choices.map(c=><label key={c} className={showAnswers && c===q.answer ? 'correct' : ''}><input type="radio" name={`q${i}`} checked={answers[i]===c} onChange={()=>setAnswers(a=>({...a,[i]:c}))}/>{c}</label>)}</div>{showAnswers && <small className={answers[i]===q.answer ? 'right-answer':'wrong-answer'}>{answers[i]===q.answer ? 'إجابة صحيحة' : `الإجابة الصحيحة: ${q.answer}`}</small>}</article>)}</>}
    <p className="disclaimer"><AlertCircle size={15}/> المحتوى مولّد بقواعد نصية بسيطة، وقد لا يصحّح المعنى أو يشرح المفاهيم بدقة مدرس متخصص. راجع المصدر الأصلي.</p>
  </section>
}
function Empty({title,desc}) { return <div className="empty-page"><div className="empty-icon"><Library size={30}/></div><h2>{title}</h2><p>{desc}</p></div> }
