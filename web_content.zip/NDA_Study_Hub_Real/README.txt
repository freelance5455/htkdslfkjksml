NDA STUDY HUB — VERSION 2.0
==========================

WHAT THIS IS
A mobile-first study web app (PWA-ready) with:
- 6 ordered NDA GK sections and 89 topics
- A concise PDF note sheet for every topic (89 PDFs)
- YouTube lesson search links on each topic
- Topic completion tracker saved on the device
- Subject progress dashboard, topic search and filters
- AI tutor handoff that opens ChatGPT with the selected topic prompt
- PWA manifest + service worker for install/offline app shell

IMPORTANT LIMITATIONS
1. This is a real working app project, but it is not yet hosted online.
   To install it like a normal app, it must be uploaded to an HTTPS static host.
2. The YouTube buttons open targeted searches, not a claim that a particular
   playlist/video has been individually verified.
3. The tutor button opens ChatGPT in a new tab with the topic context. It is
   not an embedded AI model; an embedded assistant requires a secure backend.
4. The topic PDFs are concise starter notes, not a substitute for a complete
   textbook or the latest current-affairs updates.
5. Current Affairs is a study framework. Update it regularly using reliable,
   dated sources and official releases.

HOW TO DEPLOY FREE
Use a static HTTPS host such as GitHub Pages, Netlify or Cloudflare Pages.
Upload the CONTENTS of this folder (index.html, app.js, style.css, etc.).
After deployment, open the HTTPS site in Chrome on Android:
Chrome menu (⋮) → Install app / Add to Home screen.
The exact menu wording may vary by Chrome version.

LOCAL TESTING
Opening index.html directly from a file manager may fail because the app
loads syllabus.json using fetch(). Use a local web server or host it over HTTPS.

STUDY CONTENT
The roadmap is structured for NDA GAT GK revision: Geography, History,
Polity, Economics, General Science (including Biology), and Current Affairs.
Always cross-check changing facts and the latest official NDA notification.
