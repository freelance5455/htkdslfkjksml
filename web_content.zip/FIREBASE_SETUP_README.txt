DAILY LUCKY — Cloudinary images + Firebase shared data

Product images are uploaded to Cloudinary using the configured unsigned upload preset; product metadata and customer logs remain in Firebase Firestore. Image size is limited to 10 MB in the browser, progress is shown during upload, and success/error messages report the outcome and record ID.

CLOUDINARY SETUP
1. Cloud name configured in the site: wqtv2txm.
2. Unsigned upload preset configured in the site: ml_default.
3. In Cloudinary Console, verify that this exact preset exists, is set to Unsigned, and has allowed image uploads. If upload fails with an unknown preset error, create or correct the preset and update CLOUDINARY_UPLOAD_PRESET in index.html.
4. Never add a Cloudinary API secret to public browser code. Unsigned presets can be abused if exposed, so configure allowed formats and other available upload restrictions in Cloudinary.

FIREBASE SETUP
1. Firestore continues to store product details and customer logs in project rohit-a3883. Cloudinary hosts product images, so Firebase Storage is no longer used for product uploads.
2. Firestore rules must permit authorized admin writes and must protect customer records (which may contain phone numbers and addresses). Do not use unrestricted allow read/write rules.
3. The current client-side admin login flag is not a secure authorization boundary. For production, use Firebase Authentication and enforce admin access with trusted security rules/custom claims or a trusted backend.
4. Test product upload and customer log save after deployment, then test from another device.

LIMITATIONS
- Uploading an image to Cloudinary and then failing to write its Firestore product record can leave an unused image in Cloudinary; delete unused images from the Cloudinary console when needed.
- The browser-side 10 MB check improves usability but is not a substitute for provider-side upload restrictions.
