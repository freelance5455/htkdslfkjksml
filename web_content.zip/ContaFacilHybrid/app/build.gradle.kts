plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.contafacil.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.contafacil.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // ============================================================
        // AdMob App ID
        // ------------------------------------------------------------
        // Durante desenvolvimento/teste use o App ID de TESTE do Google.
        // Quando for publicar, troque pelo seu App ID real.
        //
        // Teste (oficial Google):  ca-app-pub-3940256099942544~3347511713
        // Seu App ID real:         ca-app-pub-5380400145050331~2220510162
        // ============================================================
        manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
        // manifestPlaceholders["admobAppId"] = "ca-app-pub-5380400145050331~2220510162"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")

    // AdMob (SDK nativo - melhor prática)
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
