package com.contafacil.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var adView: AdView

    companion object {
        private const val TAG = "ContaFacilAds"

        // ====== SEUS IDs REAIS ======
        private const val REAL_BANNER_ID = "ca-app-pub-5380400145050331/9251541110"

        // ID de teste oficial do Google (sempre mostra anúncio)
        private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"

        // true = anúncio de TESTE | false = seu banner real
        private const val USE_TEST_ADS = true
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa AdMob
        MobileAds.initialize(this) { initializationStatus ->
            Log.d(TAG, "AdMob inicializado: $initializationStatus")
        }

        // Marca aparelhos de teste (evita invalidar conta enquanto testa)
        // Você pode adicionar o ID do seu aparelho aqui depois
        val requestConfiguration = RequestConfiguration.Builder()
            .setTestDeviceIds(listOf(AdRequest.DEVICE_ID_EMULATOR))
            .build()
        MobileAds.setRequestConfiguration(requestConfiguration)

        // Layout principal
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(0xFFF0FDFA.toInt())
        }

        // WebView (calculadora)
        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }

        // Banner AdMob
        adView = AdView(this).apply {
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            // Garante altura mínima visível (50dp ≈ tamanho do banner)
            val density = resources.displayMetrics.density
            params.height = (50 * density).toInt()
            layoutParams = params

            setBackgroundColor(0xFFE0F2F1.toInt()) // fundo claro para ver o espaço
            setAdSize(AdSize.BANNER)

            adUnitId = if (USE_TEST_ADS) TEST_BANNER_ID else REAL_BANNER_ID

            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d(TAG, "✅ Anúncio carregado com sucesso!")
                    Toast.makeText(this@MainActivity, "Anúncio carregado", Toast.LENGTH_SHORT).show()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "❌ Falha ao carregar anúncio: código=${error.code} | ${error.message}")
                    Toast.makeText(
                        this@MainActivity,
                        "Erro anúncio: ${error.code} - ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }

                override fun onAdOpened() {
                    Log.d(TAG, "Anúncio aberto")
                }

                override fun onAdClicked() {
                    Log.d(TAG, "Anúncio clicado")
                }

                override fun onAdClosed() {
                    Log.d(TAG, "Anúncio fechado")
                }
            }

            loadAd(AdRequest.Builder().build())
        }

        rootLayout.addView(webView)
        rootLayout.addView(adView)
        setContentView(rootLayout)
    }

    override fun onPause() {
        if (::adView.isInitialized) adView.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::adView.isInitialized) adView.resume()
    }

    override fun onDestroy() {
        if (::adView.isInitialized) adView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
