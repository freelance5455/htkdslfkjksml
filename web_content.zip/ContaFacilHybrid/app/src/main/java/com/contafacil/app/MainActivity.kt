package com.contafacil.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var adView: AdView

    companion object {
        private const val TAG = "ContaFacilAds"

        // ====== SEUS IDs REAIS ======
        private const val REAL_BANNER_ID = "ca-app-pub-5380400145050331/9251541110"

        // IDs de TESTE oficiais do Google (sempre mostram anúncio de teste)
        // Banner adaptativo / anchored
        private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741"
        // Banner tamanho fixo (alternativa)
        // private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"

        // true  = anúncio de TESTE (recomendado enquanto desenvolve)
        // false = seu banner real (só use em produção / release)
        private const val USE_TEST_ADS = true
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Layout principal (WebView em cima + banner nativo embaixo)
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(0xFFF0FDFA.toInt())
        }

        // WebView carrega o HTML da calculadora
        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }

        // Container do banner (sempre visível, mesmo se o anúncio falhar)
        val adContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(0xFFE0F2F1.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            minimumHeight = (60 * resources.displayMetrics.density).toInt()
        }

        val adStatus = android.widget.TextView(this).apply {
            text = if (USE_TEST_ADS) "Carregando anúncio de TESTE..." else "Carregando anúncio..."
            textSize = 11f
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF00695C.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        adContainer.addView(adStatus)

        val bannerId = if (USE_TEST_ADS) TEST_BANNER_ID else REAL_BANNER_ID

        adView = AdView(this).apply {
            adUnitId = bannerId
            val widthPx = resources.displayMetrics.widthPixels
            val widthDp = (widthPx / resources.displayMetrics.density).toInt()
            setAdSize(
                AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
                    this@MainActivity,
                    widthDp
                )
            )
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d(TAG, "AdMob carregado com sucesso (test=${USE_TEST_ADS})")
                    adStatus.text = if (USE_TEST_ADS) {
                        "✅ Anúncio de TESTE carregado"
                    } else {
                        "✅ Anúncio carregado"
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(
                        TAG,
                        "AdMob falhou: code=${error.code}, domain=${error.domain}, " +
                            "message=${error.message}, response=${error.responseInfo}"
                    )
                    adStatus.text = "ERRO AdMob: ${error.code} — ${error.message}"
                    Toast.makeText(
                        this@MainActivity,
                        "AdMob: ${error.code} — ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }

                override fun onAdOpened() {
                    Log.d(TAG, "Anúncio aberto")
                }

                override fun onAdClosed() {
                    Log.d(TAG, "Anúncio fechado")
                }
            }
        }

        adContainer.addView(adView)
        rootLayout.addView(webView)
        rootLayout.addView(adContainer)
        setContentView(rootLayout)

        // Configura dispositivos de teste (opcional, mas recomendado)
        // O SDK imprime o ID do dispositivo no Logcat na primeira execução.
        // Você pode colar o ID aqui se quiser forçar modo teste com IDs reais.
        val configuration = RequestConfiguration.Builder()
            // .setTestDeviceIds(listOf("SEU_DEVICE_ID_AQUI"))
            .build()
        MobileAds.setRequestConfiguration(configuration)

        // Inicializa o SDK e só então solicita o banner
        MobileAds.initialize(this) { initializationStatus ->
            Log.d(TAG, "AdMob inicializado: $initializationStatus")
            Log.d(TAG, "Usando banner ID: $bannerId (USE_TEST_ADS=$USE_TEST_ADS)")
            runOnUiThread {
                adStatus.text = if (USE_TEST_ADS) {
                    "Solicitando anúncio de TESTE..."
                } else {
                    "Solicitando anúncio..."
                }
                adView.loadAd(AdRequest.Builder().build())
            }
        }
    }

    override fun onPause() {
        if (::adView.isInitialized) adView.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::adView.isInitialized) adView.resume()
    }

    override fun onDestroy() {
        if (::adView.isInitialized) adView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
