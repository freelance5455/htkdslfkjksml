# Conta Fácil — Projeto Híbrido (HTML + AdMob Nativo)

**Versão:** 1.0.0  
**Package Name:** `com.contafacil.app`  
**Publisher ID:** `pub-5380400145050331`

## O que é este projeto?

- Interface do app em **HTML** (`index.html` dentro de `assets/`)
- Anúncio do **AdMob com SDK nativo** (melhor prática, funciona de verdade)
- O HTML é carregado em um WebView
- O banner fica **embaixo da tela**, controlado pelo código Android (não dentro do HTML)

> **Importante:** Anúncios AdMob **não funcionam** se colocados só no HTML dentro de um WebView.
> Por isso o banner é nativo (Android) e o conteúdo da calculadora fica no HTML.

## Configuração atual (MODO TESTE)

| Item              | Valor atual (TESTE)                              |
|-------------------|--------------------------------------------------|
| App ID            | `ca-app-pub-3940256099942544~3347511713`         |
| Banner Unit ID    | `ca-app-pub-3940256099942544/9214589741`         |
| Flag no código    | `USE_TEST_ADS = true` em `MainActivity.kt`       |

Com essa configuração o banner de teste do Google **sempre aparece**.

## Como abrir e gerar o APK

1. Abra o Android Studio
2. File → Open → selecione a pasta `ContaFacilHybrid`
3. Aguarde o Gradle sincronizar
4. Clique em **Run** ou Build → Build APK(s)

## Quando for usar seu anúncio real (produção)

1. No AdMob, crie o App com package `com.contafacil.app`
2. Crie um bloco de anúncio do tipo **Banner** (ou Adaptive Banner)
3. Altere **dois lugares**:

### 1) `app/build.gradle.kts`
```kotlin
manifestPlaceholders["admobAppId"] = "ca-app-pub-5380400145050331~2220510162"
```

### 2) `MainActivity.kt`
```kotlin
private const val USE_TEST_ADS = false   // muda para false
```
(O ID real do banner já está definido em `REAL_BANNER_ID`)

## Estrutura

```
ContaFacilHybrid/
├── app/
│   ├── src/main/
│   │   ├── assets/index.html          ← Interface do app (HTML)
│   │   ├── java/.../MainActivity.kt   ← WebView + AdMob nativo
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
└── README.md
```

## Dicas de diagnóstico

- Se o anúncio não aparecer, olhe o **Logcat** filtrando por `ContaFacilAds`
- Na primeira execução o SDK imprime o **Test Device ID** no Logcat
- Você pode colar esse ID em `RequestConfiguration.setTestDeviceIds(...)` se quiser testar com seus IDs reais sem risco de invalid traffic
