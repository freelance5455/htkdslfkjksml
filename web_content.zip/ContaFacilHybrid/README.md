# Conta Fácil — Projeto Híbrido (HTML + AdMob Nativo)

**Versão:** 1.0.0  
**Package Name:** `com.contafacil.app`  
**Publisher ID:** `pub-5380400145050331`

## O que é este projeto?

- Interface do app em **HTML** (`index.html` dentro de `assets/`)
- Anúncio do **AdMob com SDK nativo** (melhor prática, funciona de verdade)
- O HTML é carregado em um WebView
- O banner fica embaixo, controlado pelo código Android

## Como abrir e gerar o APK

1. Abra o Android Studio
2. File → Open → selecione a pasta `ContaFacilHybrid`
3. Aguarde o Gradle sincronizar
4. Clique em **Run** ou Build → Build APK(s)

## Configuração atual do AdMob

- Está usando **IDs de teste** do Google (o banner de teste aparece)
- Seu Publisher ID já está documentado no código: `pub-5380400145050331`

### Quando for usar seu anúncio real:

1. Crie o App no AdMob com package `com.contafacil.app`
2. Crie um bloco de anúncio do tipo **Banner**
3. Substitua nos arquivos:

**app/build.gradle.kts**
```kotlin
manifestPlaceholders["admobAppId"] = "ca-app-pub-5380400145050331~SEU_NUMERO"
```

**MainActivity.kt** (linha do adUnitId)
```kotlin
adUnitId = "ca-app-pub-5380400145050331/SEU_BANNER_ID"
```

## Estrutura

```
ContaFacilHybrid/
├── app/
│   ├── src/main/
│   │   ├── assets/index.html          ← Interface do app
│   │   ├── java/.../MainActivity.kt   ← WebView + AdMob nativo
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
└── README.md
```
