# Panduan Lengkap Deploy FirasX Rent ke Server, Domain, & Aktivasi Auto-OTP Moonton

## 1. Kenapa Kemarin OTP Tidak Muncul di Web?
Berdasarkan foto yang Anda lampirkan:
- Email OTP masuk ke `h.ara.panindubapam@gmail.com` dengan isi `Dear h.ara.panindubapam@gmail.com, Verification code: 327445`.
- Jika memakai metode pencarian standar (`SEARCH TO`), Gmail sering menyimpan alamat alias bertitik pada header `Delivered-To` atau di dalam teks `Dear ...@gmail.com`, sehingga filter biasa melewatkannya.
- Pada versi ini (`netlify/functions/api.js`), pembaca IMAP sudah diperbaiki agar **mengambil 25 email terbaru di Kotak Masuk lalu mencocokkan header `To`, `Delivered-To`, dan teks isi email (`Dear ...`)** sekaligus mengekstrak kode 6 digit secara langsung.

---

## 2. Langkah Wajib di Akun Google Induk (Agar Tidak Error IMAP / App Password)
1. Buka [myaccount.google.com/security](https://myaccount.google.com/security) menggunakan akun **Gmail Induk** (`harapanindubapam@gmail.com`).
2. Pastikan **Verifikasi 2 Langkah (2-Step Verification)** dalam keadaan **AKTIF**.
3. Di kolom pencarian atas Akun Google, ketik **App Passwords (Sandi Aplikasi)**.
4. Buat nama baru (misal: `FirasXRent`), klik **Buat**, lalu salin **16 huruf sandi aplikasi** (contoh: `abcd efgh ijkl mnop`).
5. Buka Gmail di browser -> klik ikon **Setelan (Gerigi)** -> **Lihat semua setelan** -> tab **Penerusan dan POP/IMAP** -> pastikan **Status IMAP: IMAP diaktifkan** -> klik **Simpan Perubahan**.

---

## 3. Cara Upload ke Netlify & Hubungkan ke Domain Sendiri
1. Ekstrak file ZIP ini ke dalam satu folder.
2. Buat repository baru di **GitHub** (gratis), lalu upload semua isi folder (`index.html`, `package.json`, `netlify.toml`, dan folder `netlify/functions/api.js`).
3. Buka [app.netlify.com](https://app.netlify.com) -> **Add new site** -> **Import an existing project** -> pilih repository GitHub Anda.
4. Netlify akan otomatis menginstal `imapflow`, `mailparser`, dan `@netlify/blobs` lalu men-deploy website beserta server backend-nya.
5. Untuk memasang domain sendiri (`.com` / `.id` / `.my.id`):
   - Di dashboard site Netlify, buka **Domain management** -> **Add a domain**.
   - Masukkan nama domain Anda, lalu arahkan **Nameserver** atau **CNAME / A Record** di tempat Anda membeli domain sesuai instruksi Netlify. HTTPS (SSL) akan aktif otomatis.

---

## 4. Akun Khusus yang Sudah Tertanam
- **Developer:** Username `FirasXDev` | Password `Cgh1yg6`
- **Co-Developer (Beli Gratis Rp 0):** Username `FirasXCo` | Password `Cgh1yg6`
- **Endpoint Webhook Pembayaran:** `https://domain-anda.com/.netlify/functions/api` (kirim payload JSON `{ "action": "payment_webhook", "order_id": "ORD-XXXXXX", "status": "PAID" }`).
