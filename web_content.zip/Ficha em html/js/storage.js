const STORAGE_KEY = "arquivo-personagens-v1";

export function getCharacters() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch { return []; }
}

export function saveCharacter(character) {
  const all = getCharacters();
  const index = all.findIndex((saved) => saved.id === character.id);
  const safeCharacter = structuredClone(character);
  if (index >= 0) all[index] = safeCharacter;
  else all.unshift(safeCharacter);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

export function deleteCharacter(id) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(getCharacters().filter((character) => character.id !== id)));
}

export function exportCharacter(character) {
  const file = new Blob([JSON.stringify(character, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(file);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${(character.identity.name || "personagem").replace(/[^a-z0-9]+/gi, "-").toLowerCase()}.ficha-rpg.json`;
  link.click();
  URL.revokeObjectURL(url);
}

export function readCharacterFile(file) {
  return file.text().then((text) => JSON.parse(text));
}
