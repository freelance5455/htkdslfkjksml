import { ATTRIBUTES, MARKS, SINAS, SKILLS, TRAINING } from "./data.js";

export function emptySkills() {
  return Object.fromEntries(SKILLS.map(({ name }) => [name, "inexperiente"]));
}

export function newCharacter(mode = "guided") {
  return {
    version: 1,
    id: crypto.randomUUID(),
    mode,
    status: "Em andamento",
    identity: { name: "", age: "", appearance: "", photo: "" },
    sina: mode === "free" ? null : "Profeta",
    mark: mode === "free" ? null : "Popular",
    choices: { sina: {}, mark: {} },
    baseAttributes: Object.fromEntries(ATTRIBUTES.map((attribute) => [attribute, 0])),
    attributes: Object.fromEntries(ATTRIBUTES.map((attribute) => [attribute, 0])),
    skills: emptySkills(),
    freeSkillsChosen: [],
    level: 1,
    xp: 0,
    abilityPoints: 0,
    attributePoints: 0,
    resources: { pvCurrent: 1, plCurrent: 0, freePvMax: 10, freePlMax: 10 },
    inventory: [],
    conditions: [],
    visionAbilities: [],
    death: { active: false, die: "d8", permanent: false },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

export function getChoiceBonuses(character) {
  const bonuses = Object.fromEntries(ATTRIBUTES.map((attribute) => [attribute, 0]));
  const add = (attribute) => { if (attribute in bonuses) bonuses[attribute] += 1; };
  const sina = character.sina && SINAS[character.sina];
  const mark = character.mark && MARKS[character.mark];
  sina?.choices.forEach((choice) => { if (choice.type === "attributeBonus") add(character.choices.sina[choice.id]); });
  mark?.choices.forEach((choice) => { if (choice.type === "attributeBonus") add(character.choices.mark[choice.id]); });
  return bonuses;
}

export function getBaseBonuses(character) {
  const result = Object.fromEntries(ATTRIBUTES.map((attribute) => [attribute, 0]));
  const addAll = (source) => Object.entries(source || {}).forEach(([attribute, value]) => { result[attribute] += value; });
  if (character.sina) addAll(SINAS[character.sina].bonuses);
  if (character.mark) addAll(MARKS[character.mark].bonuses);
  addAll(getChoiceBonuses(character));
  return result;
}

export function syncAttributes(character) {
  const bonuses = getBaseBonuses(character);
  ATTRIBUTES.forEach((attribute) => {
    character.attributes[attribute] = Number(character.baseAttributes[attribute] || 0) + bonuses[attribute];
  });
}

export function getFixedSkills(character) {
  const fixed = [];
  const sina = character.sina && SINAS[character.sina];
  const mark = character.mark && MARKS[character.mark];
  fixed.push(...(sina?.fixedSkills || []), ...(mark?.trainedSkills || []));
  sina?.choices.forEach((choice) => { if (choice.type === "trainedSkill" && character.choices.sina[choice.id]) fixed.push(character.choices.sina[choice.id]); });
  mark?.choices.forEach((choice) => { if (choice.type === "trainedSkill" && character.choices.mark[choice.id]) fixed.push(character.choices.mark[choice.id]); });
  return [...new Set(fixed)];
}

export function applyGrantedSkills(character) {
  getFixedSkills(character).forEach((skill) => {
    if (character.skills[skill] === "inexperiente") character.skills[skill] = "experiente";
  });
}

export function freeSkillLimit(character) {
  if (!character.sina) return 0;
  return Math.max(0, SINAS[character.sina].freeSkills(character.attributes["Razão"]));
}

export function getEffects(character) {
  return [...character.inventory.filter((item) => item.equipped), ...character.conditions.filter((condition) => condition.active)]
    .flatMap((entry) => entry.effects || []);
}

export function getAttributeValue(character, attribute) {
  const effects = getEffects(character).filter((effect) => effect.kind === "attribute" && effect.target === attribute);
  return character.attributes[attribute] + effects.reduce((total, effect) => total + Number(effect.value || 0), 0);
}

export function getMaxResources(character) {
  const effects = getEffects(character);
  let pv;
  let pl;
  if (!character.sina) {
    pv = Number(character.resources.freePvMax || 0);
    pl = Number(character.resources.freePlMax || 0);
  } else {
    const attributes = Object.fromEntries(ATTRIBUTES.map((attribute) => [attribute, getAttributeValue(character, attribute)]));
    ({ pv, pl } = SINAS[character.sina].calculate({ level: character.level, attributes }));
  }
  pv += effects.filter((effect) => effect.kind === "maxPv").reduce((total, effect) => total + Number(effect.value || 0), 0);
  pl += effects.filter((effect) => effect.kind === "maxPl").reduce((total, effect) => total + Number(effect.value || 0), 0);
  return { pv: Math.max(0, pv), pl: Math.max(0, pl) };
}

export function clampResources(character) {
  const { pv, pl } = getMaxResources(character);
  character.resources.pvCurrent = Math.min(Math.max(0, Number(character.resources.pvCurrent || 0)), pv);
  character.resources.plCurrent = Math.min(Math.max(0, Number(character.resources.plCurrent || 0)), pl);
  if (character.resources.pvCurrent === 0 && !character.death.permanent) character.death.active = true;
}

export function trainingBonus(level) { return TRAINING.find((training) => training.id === level)?.bonus || 0; }

export function isSkillBlocked(character, skill) {
  return getEffects(character).some((effect) => effect.kind === "blockSkill" && effect.target === skill);
}

export function getSkillModifier(character, skill) {
  const total = getEffects(character)
    .filter((effect) => effect.kind === "skill" && effect.target === skill)
    .reduce((sum, effect) => sum + Number(effect.value || 0), 0);
  return trainingBonus(character.skills[skill]) + total;
}

export function getTestModifiers(character, skill) {
  const effects = getEffects(character);
  return {
    dice: effects.filter((effect) => effect.kind === "dice" && (!effect.target || effect.target === skill || effect.target === "Todos"))
      .reduce((sum, effect) => sum + Number(effect.value || 0), 0),
    total: effects.filter((effect) => effect.kind === "testTotal" && (!effect.target || effect.target === skill || effect.target === "Todos"))
      .reduce((sum, effect) => sum + Number(effect.value || 0), 0)
  };
}

export function testFormula(character, skill, attribute) {
  const attributeValue = getAttributeValue(character, attribute);
  const modifiers = getTestModifiers(character, skill);
  if (attributeValue < 0) return { forbidden: true, text: `${attribute} está abaixo de 0: este teste não pode ser realizado.` };
  let dice = attributeValue > 0 ? attributeValue : 2;
  dice += modifiers.dice;
  dice = Math.max(1, dice);
  const pick = attributeValue > 0 ? "maior" : "menor";
  const technicalPenalty = SKILLS.find((entry) => entry.name === skill)?.technical && character.skills[skill] === "inexperiente" ? -5 : 0;
  const skillBonus = getSkillModifier(character, skill);
  const totalBonus = skillBonus + technicalPenalty + modifiers.total;
  return {
    forbidden: false, dice, pick, attributeValue, skillBonus, technicalPenalty, effectTotal: modifiers.total, totalBonus,
    text: `${dice}d20, use o ${pick} resultado + ${totalBonus >= 0 ? "+" : ""}${totalBonus}`
  };
}

export function xpToNextLevel(character) { return character.level * 200; }

export function levelUp(character) {
  const needed = xpToNextLevel(character);
  if (character.level >= 20) return { ok: false, message: "O personagem já está no nível máximo." };
  if (character.xp < needed) return { ok: false, message: `São necessários ${needed} XP para chegar ao próximo nível.` };
  character.xp -= needed;
  character.level += 1;
  character.abilityPoints += 1;
  if ([3, 5, 7, 10, 15, 18].includes(character.level)) character.attributePoints += 1;
  return { ok: true, message: `Nível ${character.level}! Você recebeu 1 Ponto de Habilidade${[3, 5, 7, 10, 15, 18].includes(character.level) ? " e 1 Ponto de Atributo" : ""}.` };
}

export function upgradeSkill(character, skill) {
  const current = character.skills[skill];
  const cost = current === "inexperiente" ? 1 : current === "experiente" ? 2 : null;
  if (!cost) return { ok: false, message: "Esta perícia já é Habilidosa." };
  if (character.abilityPoints < cost) return { ok: false, message: `Você precisa de ${cost} Ponto${cost > 1 ? "s" : ""} de Habilidade.` };
  character.abilityPoints -= cost;
  character.skills[skill] = current === "inexperiente" ? "experiente" : "habilidoso";
  return { ok: true, message: `${skill} evoluiu para ${character.skills[skill]}.` };
}
