import { ATTRIBUTES, ATTRIBUTE_INFO, MARKS, SINAS, SKILLS, TRAINING, getVisionCatalog } from "./data.js";
import { deleteCharacter, exportCharacter, getCharacters, readCharacterFile, saveCharacter } from "./storage.js";
import {
  applyGrantedSkills, clampResources, emptySkills, freeSkillLimit, getAttributeValue, getEffects,
  getFixedSkills, getMaxResources, getSkillModifier, isSkillBlocked, levelUp, newCharacter,
  syncAttributes, testFormula, trainingBonus, upgradeSkill, xpToNextLevel
} from "./rules.js";

const app = document.querySelector("#app");
const modalRoot = document.querySelector("#modal-root");
let current = null;
let activeTab = "resumo";
let wizard = null;

const esc = (value = "") => String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
const uid = () => crypto.randomUUID();
const byId = (entries, id) => entries.find((entry) => entry.id === id);
const number = (value) => Number(value || 0);

function normalizeCharacter(character) {
  const fresh = newCharacter(character.mode || "free");
  const normalized = { ...fresh, ...character };
  normalized.identity = { ...fresh.identity, ...(character.identity || {}) };
  normalized.choices = { sina: {}, mark: {}, ...(character.choices || {}) };
  normalized.baseAttributes = { ...fresh.baseAttributes, ...(character.baseAttributes || character.attributes || {}) };
  normalized.attributes = { ...fresh.attributes, ...(character.attributes || {}) };
  normalized.skills = { ...emptySkills(), ...(character.skills || {}) };
  normalized.resources = { ...fresh.resources, ...(character.resources || {}) };
  normalized.death = { ...fresh.death, ...(character.death || {}) };
  normalized.inventory = Array.isArray(character.inventory) ? character.inventory : [];
  normalized.conditions = Array.isArray(character.conditions) ? character.conditions : [];
  normalized.visionAbilities = Array.isArray(character.visionAbilities) ? character.visionAbilities : [];
  normalized.freeSkillsChosen = Array.isArray(character.freeSkillsChosen) ? character.freeSkillsChosen : [];
  return normalized;
}

function persist() {
  if (!current) return;
  current.updatedAt = new Date().toISOString();
  syncAttributes(current);
  clampResources(current);
  saveCharacter(current);
}

function toast(message, kind = "success") {
  document.querySelector(".toast")?.remove();
  const element = document.createElement("div");
  element.className = `toast ${kind}`;
  element.textContent = message;
  document.body.append(element);
  setTimeout(() => element.remove(), 3600);
}

function button(label, action, options = {}) {
  const { className = "", data = {}, disabled = false, type = "button" } = options;
  const attributes = Object.entries(data).map(([key, value]) => `data-${key}="${esc(value)}"`).join(" ");
  return `<button type="${type}" class="button ${className}" ${attributes} ${disabled ? "disabled" : ""}>${label}</button>`;
}

function renderWelcome() {
  current = null;
  wizard = null;
  app.innerHTML = `
    <section class="welcome">
      <p class="eyebrow">Seu sistema · arquivo local</p>
      <h1>Arquivo de Personagens</h1>
      <p class="welcome-intro">Uma ficha feita para acompanhar regras, escolhas e anotações de campanha — no computador ou no celular.</p>
      <div class="start-grid">
        <article class="start-card">
          <h2>Iniciar criação guiada</h2>
          <p>Monte um personagem passo a passo. A Sina e a Marca aplicam os bônus e as perícias que pertencem a elas.</p>
          ${button("Começar criação", "start-guided", { className: "primary", data: { action: "start-guided" } })}
        </article>
        <article class="start-card">
          <h2>Abrir ficha livre</h2>
          <p>Crie uma ficha sem Sina nem Marca, com PV e PL máximos definidos manualmente.</p>
          ${button("Abrir ficha livre", "start-free", { data: { action: "start-free" } })}
        </article>
        <article class="start-card">
          <h2>Carregar ficha existente</h2>
          <p>Retome um personagem salvo neste navegador ou importe uma ficha enviada por outra pessoa.</p>
          ${button("Ver personagens", "open-load", { data: { action: "open-load" } })}
        </article>
      </div>
    </section>`;
}

function renderHeader() {
  const max = getMaxResources(current);
  const isFree = !current.sina;
  return `
    <header class="character-header">
      <label class="portrait" aria-label="Foto do personagem">
        ${current.identity.photo ? `<img src="${esc(current.identity.photo)}" alt="Foto do personagem" />` : "Clique para adicionar uma foto"}
        <input type="file" data-photo accept="image/*" aria-label="Adicionar foto" />
      </label>
      <div class="identity">
        <label>Nome<input data-identity="name" value="${esc(current.identity.name)}" placeholder="Nome do personagem" /></label>
        <label>Idade<input data-identity="age" value="${esc(current.identity.age)}" placeholder="Idade" /></label>
        <label class="appearance">Aparência<textarea data-identity="appearance" placeholder="Descrição, detalhes visuais, anotações...">${esc(current.identity.appearance)}</textarea></label>
      </div>
      <div class="status-area">
        <div class="status-seal ${current.status === "Arquivado" ? "archived" : ""}">${esc(current.status)}</div>
        <select class="status-select" data-status aria-label="Status da ficha">
          <option ${current.status === "Em andamento" ? "selected" : ""}>Em andamento</option>
          <option ${current.status === "Arquivado" ? "selected" : ""}>Arquivado</option>
        </select>
      </div>
    </header>
    <section class="resource-strip" aria-label="Recursos do personagem">
      <div class="resource-card">
        <div class="resource-label">Pontos de Vida</div>
        <div class="resource-value"><input type="number" min="0" max="${max.pv}" data-resource="pvCurrent" value="${current.resources.pvCurrent}" /><span>/ ${max.pv} PV</span></div>
      </div>
      <div class="resource-card">
        <div class="resource-label">Pontos de Lucidez</div>
        <div class="resource-value"><input type="number" min="0" max="${max.pl}" data-resource="plCurrent" value="${current.resources.plCurrent}" /><span>/ ${max.pl} PL</span></div>
      </div>
      <div class="resource-card">
        <div class="resource-label">Nível e experiência</div>
        <div class="resource-value"><strong>${current.level}</strong><span>nível</span></div>
        <div class="compact">${current.level < 20 ? `<input type="number" min="0" data-resource="xp" value="${current.xp}" aria-label="Experiência atual" /> / ${xpToNextLevel(current)} XP` : "Nível máximo"}</div>
      </div>
      <div class="resource-card">
        <div class="resource-label">Pontos disponíveis</div>
        <div class="resource-value"><strong>${current.abilityPoints}</strong><span>habilidade</span></div>
        <div class="compact">${current.attributePoints} ponto(s) de atributo</div>
      </div>
    </section>
    ${isFree ? `<p class="warning">Ficha livre: PV e PL máximos podem ser alterados na aba Atributos.</p>` : ""}`;
}

function tabs() {
  const names = { resumo: "Resumo", atributos: "Atributos", pericias: "Perícias", inventory: "Inventário", conditions: "Condições", visao: "Visão", origem: "Sina e Marca" };
  return `<nav class="tabs" aria-label="Seções da ficha">${Object.entries(names).map(([id, name]) => `<button class="tab ${activeTab === id ? "active" : ""}" data-tab="${id}" aria-selected="${activeTab === id}">${name}</button>`).join("")}</nav>`;
}

function renderSummary() {
  const sina = current.sina ? SINAS[current.sina] : null;
  const mark = current.mark ? MARKS[current.mark] : null;
  const max = getMaxResources(current);
  return `
    <section class="panel ${activeTab === "resumo" ? "active" : ""}" data-title="Resumo">
      <p class="panel-intro">Uma visão rápida do personagem. As informações são salvas automaticamente neste navegador.</p>
      <div class="paper-grid">
        <article class="note">
          <h2>Origem</h2>
          <p><strong>Sina:</strong> ${sina ? esc(current.sina) : "Ficha livre"}</p>
          <p>${sina ? esc(sina.description) : "Sem regras automáticas de Sina."}</p>
          <p><strong>Marca:</strong> ${mark ? esc(current.mark) : "Nenhuma"}</p>
        </article>
        <article class="note">
          <h2>Recursos</h2>
          <p><strong>PV máximo:</strong> ${max.pv} &nbsp; <strong>PL máximo:</strong> ${max.pl}</p>
          <p><strong>Dado de Morte:</strong> ${current.death.die}</p>
          <p><strong>Próximo nível:</strong> ${current.level < 20 ? `${Math.max(0, xpToNextLevel(current) - current.xp)} XP restante(s)` : "Nível máximo"}</p>
          ${button("Subir nível", "level-up", { className: "primary", data: { action: "level-up" }, disabled: current.level >= 20 || current.xp < xpToNextLevel(current) })}
        </article>
        <article class="note wide">
          <h2>Lembretes para a mesa</h2>
          <ul class="rule-list">
            <li>Todo teste usa um atributo escolhido pelo Mestre e uma perícia.</li>
            <li>Atributo acima de 0: role esse número de d20 e use o maior. Em 0: 2d20 e use o menor.</li>
            <li>Perícias técnicas sem treino recebem −5. Condições e itens ativos entram nas rolagens automaticamente.</li>
          </ul>
        </article>
      </div>
    </section>`;
}

function renderAttributes() {
  const max = getMaxResources(current);
  const effects = getEffects(current);
  const effective = (attribute) => getAttributeValue(current, attribute);
  return `
    <section class="panel ${activeTab === "atributos" ? "active" : ""}" data-title="Atributos">
      <p class="panel-intro">Os valores abaixo já incluem bônus de Sina, Marca, condições e itens equipados.</p>
      <div class="point-box">
        <strong>${current.attributePoints}</strong><span>Ponto(s) de Atributo disponível(is). O limite é ${current.level === 1 ? 4 : 5} no valor final.</span>
        ${!current.sina ? `<label>PV máximo manual<input type="number" min="0" data-resource="freePvMax" value="${current.resources.freePvMax}" /></label><label>PL máximo manual<input type="number" min="0" data-resource="freePlMax" value="${current.resources.freePlMax}" /></label>` : ""}
      </div>
      <div class="attribute-grid">
        ${ATTRIBUTES.map((attribute) => {
          const adjustment = effective(attribute) - current.attributes[attribute];
          const atLimit = effective(attribute) >= (current.level === 1 ? 4 : 5);
          return `<article class="attribute-card">
            <h3>${attribute}</h3>
            <div class="attribute-circle">${effective(attribute)}</div>
            <p class="effect-hint">${adjustment ? `Efeitos ativos: ${adjustment > 0 ? "+" : ""}${adjustment}` : "Sem efeito temporário"}</p>
            <button class="button" data-action="add-attribute" data-attribute="${attribute}" ${current.attributePoints < 1 || atLimit ? "disabled" : ""}>+ ponto</button>
          </article>`;
        }).join("")}
      </div>
      <div class="paper-grid" style="margin-top: 1rem;">
        <article class="note wide"><h2>PV e PL</h2><p>PV máximo: <strong>${max.pv}</strong> · PL máximo: <strong>${max.pl}</strong>.</p><p>${current.sina ? "Eles são recalculados quando atributos, nível, itens equipados ou condições mudam." : "Na ficha livre, os máximos são definidos manualmente acima, mas itens e condições ainda podem modificá-los."}</p></article>
      </div>
    </section>`;
}

function renderSkills() {
  return `
    <section class="panel ${activeTab === "pericias" ? "active" : ""}" data-title="Perícias">
      <div class="list-toolbar"><p class="panel-intro">Use “Ver rolagem” para aplicar a regra de dados. Evoluir uma perícia consome Pontos de Habilidade.</p><span><strong>${current.abilityPoints}</strong> PH disponível(is)</span></div>
      <div class="table-scroll"><table class="skills-table"><thead><tr><th>Perícia</th><th class="hide-mobile">Tipo</th><th>Treinamento</th><th class="hide-mobile">Bônus</th><th>Ações</th></tr></thead>
      <tbody>${SKILLS.map(({ name, technical }) => {
        const blocked = isSkillBlocked(current, name);
        const training = TRAINING.find((level) => level.id === current.skills[name]);
        const cost = current.skills[name] === "inexperiente" ? 1 : current.skills[name] === "experiente" ? 2 : 0;
        return `<tr class="${blocked ? "blocked" : ""}"><td><strong>${name}</strong> ${blocked ? "<small>bloqueada</small>" : ""}</td><td class="hide-mobile">${technical ? '<span class="technical">Técnica</span>' : "—"}</td><td class="training">${training.label}</td><td class="hide-mobile">${getSkillModifier(current, name) >= 0 ? "+" : ""}${getSkillModifier(current, name)}</td><td><div class="button-row"><button class="button table-action" data-action="roll" data-skill="${name}" ${blocked ? "disabled" : ""}>Ver rolagem</button>${cost ? `<button class="button ghost table-action" data-action="upgrade-skill" data-skill="${name}" ${current.abilityPoints < cost ? "disabled" : ""}>Evoluir (${cost})</button>` : ""}</div></td></tr>`;
      }).join("")}</tbody></table></div>
    </section>`;
}

function formatEffects(effects = []) {
  if (!effects.length) return "";
  const labels = { attribute: "Atributo", dice: "Dados", skill: "Perícia", testTotal: "Teste", maxPv: "PV máximo", maxPl: "PL máximo", blockSkill: "Bloqueia" };
  return `<div class="effect-tags">${effects.map((effect) => `<span class="effect-tag">${labels[effect.kind] || effect.kind}${effect.target ? ` · ${esc(effect.target)}` : ""}${effect.kind === "blockSkill" ? "" : ` ${number(effect.value) >= 0 ? "+" : ""}${esc(effect.value)}`}</span>`).join("")}</div>`;
}

function renderEntries(kind, title) {
  const entries = current[kind];
  return `
    <section class="panel ${activeTab === kind ? "active" : ""}" data-title="${title}">
      <div class="list-toolbar"><p class="panel-intro">${kind === "inventory" ? "Itens só aplicam efeitos enquanto estiverem equipados." : "Condições ativas entram nos cálculos de recursos e testes."}</p>${button(kind === "inventory" ? "Adicionar item" : "Adicionar condição", "new-entry", { className: "primary", data: { action: "new-entry", kind } })}</div>
      <div class="entry-list">${entries.length ? entries.map((entry) => `<article class="entry ${kind === "conditions" && !entry.active ? "inactive" : ""}">
        <div><h3>${esc(entry.name || "Sem nome")} ${kind === "inventory" ? `<small>· ${number(entry.quantity || 1)} un. · ${number(entry.weight || 0)} peso</small>` : entry.duration ? `<small>· ${esc(entry.duration)}</small>` : ""}</h3><p>${esc(entry.description || "Sem descrição.")}</p>${formatEffects(entry.effects)}</div>
        <div class="entry-actions">${button(kind === "inventory" ? (entry.equipped ? "Desequipar" : "Equipar") : (entry.active ? "Desativar" : "Ativar"), "toggle-entry", { data: { action: "toggle-entry", kind, id: entry.id } })}${button("Editar", "edit-entry", { className: "ghost", data: { action: "edit-entry", kind, id: entry.id } })}${button("Remover", "delete-entry", { className: "danger", data: { action: "delete-entry", kind, id: entry.id } })}</div>
      </article>`).join("") : `<div class="empty-state">Ainda não há ${kind === "inventory" ? "itens" : "condições"}. Adicione um para registrar seus efeitos.</div>`}</div>
    </section>`;
}

function renderVision() {
  const catalog = getVisionCatalog();
  const learned = current.visionAbilities;
  return `
    <section class="panel ${activeTab === "visao" ? "active" : ""}" data-title="Habilidades de Visão">
      <p class="panel-intro">A progressão definitiva por Caminho e tier ainda está aberta; por isso, a ficha permite adicionar as habilidades manualmente.</p>
      <article class="note"><h2>Habilidades aprendidas</h2>${learned.length ? `<div class="entry-list">${learned.map((ability) => `<article class="entry"><div><h3>${esc(ability.name)} <small>· ${esc(ability.path)} · ${esc(ability.tier)}</small></h3><p>${esc(ability.description)}</p><span class="badge">${esc(ability.cost)} PL</span></div><div class="entry-actions">${button("Usar", "use-vision", { className: "primary", data: { action: "use-vision", id: ability.id } })}${button("Remover", "remove-vision", { className: "danger", data: { action: "remove-vision", id: ability.id } })}</div></article>`).join("")}</div>` : `<p class="empty-state">Nenhuma habilidade aprendida ainda.</p>`}</article>
      ${Object.keys({ Fome: 1, "Lascívia": 1, Primazia: 1, Paranoia: 1 }).map((path) => `<section class="catalog-group"><h3>${path}</h3><div class="catalog">${catalog.filter((ability) => ability.path === path).map((ability) => `<article class="catalog-card"><h3>${esc(ability.name)}</h3><p><span class="badge">${esc(ability.tier)}</span><span class="badge">${esc(ability.cost)} PL</span></p><p>${esc(ability.description)}</p>${button("Adicionar à ficha", "add-vision", { data: { action: "add-vision", name: ability.name } })}</article>`).join("")}</div></section>`).join("")}
    </section>`;
}

function renderOrigin() {
  const sina = current.sina && SINAS[current.sina];
  const mark = current.mark && MARKS[current.mark];
  const fixed = getFixedSkills(current);
  return `
    <section class="panel ${activeTab === "origem" ? "active" : ""}" data-title="Sina e Marca">
      <div class="paper-grid">
        <article class="note">
          <h2>${sina ? `Sina: ${esc(current.sina)}` : "Ficha livre"}</h2>
          ${sina ? `<p>${esc(sina.description)}</p><p><strong>Perícias livres concedidas:</strong> ${freeSkillLimit(current)}</p><p><strong>Habilidades de Visão:</strong> níveis ${sina.visionLevels.join(", ")}.</p>` : "<p>Esta ficha não possui Sina. Os recursos máximos são manuais.</p>"}
        </article>
        <article class="note">
          <h2>${mark ? `Marca: ${esc(current.mark)}` : "Sem Marca"}</h2>
          ${mark ? `<p><strong>Efeito narrativo:</strong> ${esc(mark.narrative)}</p><p><strong>Passiva:</strong> ${esc(mark.passive)}</p>${mark.active ? `${button(`Usar ${mark.active.name} · ${mark.active.cost} PL`, "use-mark", { className: "primary", data: { action: "use-mark" } })}` : ""}` : "<p>Esta ficha não possui Marca.</p>"}
        </article>
        <article class="note wide"><h2>Perícias concedidas</h2><p>${fixed.length ? fixed.map(esc).join(", ") : "Nenhuma perícia automática."}</p><p>As perícias automáticas são registradas como <strong>Experiente</strong>. A ficha não diminui uma perícia que já foi evoluída.</p></article>
      </div>
    </section>`;
}

function renderDeath() {
  const permanent = current.death.permanent;
  return `
    <div class="death-lock"><strong>A personagem está em estado de morte.</strong> A ficha foi bloqueada; apenas o Dado de Morte está disponível até estabilizar ou morrer permanentemente.</div>
    <section class="death-panel">
      <h2>${permanent ? "Morte permanente" : "Dado de Morte"}</h2>
      <p>${permanent ? "O d4 falhou. Registre este desfecho na história." : "Role o dado físico e informe o resultado abaixo."}</p>
      <div class="die">${current.death.die}</div>
      ${!permanent ? `<div class="form-grid"><label>Resultado do dado<input type="number" min="1" data-death-result placeholder="Ex.: 3" /></label><div class="button-row" style="align-self:end;">${button("Registrar resultado", "death-roll", { className: "primary", data: { action: "death-roll" } })}${button("Estabilizado: recuperar 1 PV", "stabilize", { data: { action: "stabilize" } })}</div></div><p>Falhar com 1 ou 2 degrada d8 → d6 → d4 → morte permanente. Com 3 ou mais, o dado se mantém.</p>` : ""}
    </section>`;
}

function renderSheet() {
  if (!current) return renderWelcome();
  syncAttributes(current);
  const dead = current.death.active || current.death.permanent;
  app.innerHTML = `
    <div class="sheet-shell">
      <div class="topbar no-print"><div class="brand">ARQUIVO DE PERSONAGENS</div><div class="top-actions">${button("Personagens", "open-load", { data: { action: "open-load" } })}${button("Exportar ficha", "export", { data: { action: "export" } })}${button("Gerar PDF", "print", { data: { action: "print" } })}${button("Novo personagem", "home", { className: "ghost", data: { action: "home" } })}</div></div>
      ${renderHeader()}
      ${dead ? renderDeath() : `${tabs()}<div class="sheet-page">${renderSummary()}${renderAttributes()}${renderSkills()}${renderEntries("inventory", "Inventário")}${renderEntries("conditions", "Condições")}${renderVision()}${renderOrigin()}</div>`}
    </div>`;
}

function modal(content) { modalRoot.innerHTML = `<div class="modal-backdrop" data-action="close-modal"><section class="modal" role="dialog" aria-modal="true">${content}</section></div>`; }
function closeModal() { modalRoot.innerHTML = ""; }

function openLoadModal() {
  const characters = getCharacters();
  modal(`
    <div class="modal-header"><h2>Personagens salvos</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div>
    <div class="modal-body"><p>Os personagens abaixo ficam salvos neste navegador. Você também pode importar uma ficha em formato <code>.ficha-rpg.json</code>.</p>
      <div class="entry-list">${characters.length ? characters.map((character) => `<article class="entry"><div><h3>${esc(character.identity?.name || "Sem nome")}</h3><p>Nível ${number(character.level || 1)} · ${esc(character.sina || "Ficha livre")} ${character.mark ? `· ${esc(character.mark)}` : ""}</p></div><div class="entry-actions">${button("Abrir", "load-character", { className: "primary", data: { action: "load-character", id: character.id } })}${button("Excluir", "delete-saved", { className: "danger", data: { action: "delete-saved", id: character.id } })}</div></article>`).join("") : `<p class="empty-state">Nenhum personagem salvo neste navegador.</p>`}</div>
      <label class="full" style="margin-top: 1rem;">Importar ficha<input type="file" data-import-file accept="application/json,.json,.ficha-rpg.json" /></label>
    </div>`);
}

function choiceFields(source, selected = {}) {
  return source.choices.map((choice) => `<label class="choice-field">${esc(choice.label)}<select data-choice="${choice.id}"><option value="">Escolha…</option>${choice.options.map((option) => `<option value="${esc(option)}" ${selected[choice.id] === option ? "selected" : ""}>${esc(option)}</option>`).join("")}</select></label>`).join("");
}

function wizardProgress(step) { return `<div class="stepper" aria-label="Progresso da criação">${[1,2,3,4,5,6,7].map((item) => `<span class="${item === step ? "current" : ""}">${item}</span>`).join("")}</div>`; }

function openWizard(character = newCharacter("guided"), step = 1) {
  wizard = { character: normalizeCharacter(character), step };
  renderWizard();
}

function wizardBody() {
  const character = wizard.character;
  syncAttributes(character);
  const fixed = getFixedSkills(character);
  const selectedFree = character.freeSkillsChosen;
  const maxAttributes = character.level === 1 ? 4 : 5;
  const baseSpent = Object.values(character.baseAttributes).reduce((sum, value) => sum + number(value), 0);
  if (wizard.step === 1) return `<h2>Quem é este personagem?</h2><p class="panel-intro">Esses dados sempre podem ser alterados depois.</p><div class="form-grid"><label>Nome<input data-wizard="name" value="${esc(character.identity.name)}" autofocus /></label><label>Idade<input data-wizard="age" value="${esc(character.identity.age)}" /></label><label class="full">Aparência<textarea data-wizard="appearance">${esc(character.identity.appearance)}</textarea></label></div>`;
  if (wizard.step === 2) return `<h2>Escolha a Sina</h2><p class="panel-intro">A Sina determina fórmulas de PV/PL, perícias livres e a progressão de Habilidades de Visão.</p><div class="selection-grid">${Object.entries(SINAS).map(([name, sina]) => `<button class="selection-option ${character.sina === name ? "selected" : ""}" data-action="wizard-sina" data-sina="${name}"><strong>${name}</strong><br><small>${esc(sina.description)}</small></button>`).join("")}</div>`;
  if (wizard.step === 3) { const sina = SINAS[character.sina]; return `<h2>Escolhas da Sina: ${esc(character.sina)}</h2>${sina.choices.length ? choiceFields(sina, character.choices.sina) : "<p class=\"empty-state\">Esta Sina não exige escolhas adicionais.</p>"}`; }
  if (wizard.step === 4) return `<h2>Escolha a Marca</h2><p class="panel-intro">A Marca concede bônus, perícias treinadas e uma habilidade ativa.</p><div class="selection-grid">${Object.entries(MARKS).map(([name, mark]) => `<button class="selection-option ${character.mark === name ? "selected" : ""}" data-action="wizard-mark" data-mark="${name}"><strong>${name}</strong><br><small>${esc(mark.passive)}</small></button>`).join("")}</div>`;
  if (wizard.step === 5) { const mark = MARKS[character.mark]; return `<h2>Escolhas da Marca: ${esc(character.mark)}</h2>${mark.choices.length ? choiceFields(mark, character.choices.mark) : "<p class=\"empty-state\">Esta Marca não exige escolhas adicionais.</p>"}`; }
  if (wizard.step === 6) return `<h2>Distribua os 5 pontos-base</h2><p class="panel-intro">Pontos-base distribuídos: <strong>${baseSpent}/5</strong>. O limite final no nível 1 é ${maxAttributes}; Sina e Marca entram na conta.</p><div class="attribute-grid">${ATTRIBUTES.map((attribute) => `<article class="attribute-card"><h3>${attribute}</h3><div class="attribute-circle">${character.baseAttributes[attribute]}</div><p class="effect-hint">Final: ${character.attributes[attribute]}</p><div class="button-row" style="justify-content:center;"><button class="button" data-action="wizard-attribute" data-attribute="${attribute}" data-change="-1" ${character.baseAttributes[attribute] <= 0 ? "disabled" : ""}>−</button><button class="button" data-action="wizard-attribute" data-attribute="${attribute}" data-change="1" ${baseSpent >= 5 || character.attributes[attribute] >= maxAttributes ? "disabled" : ""}>+</button></div></article>`).join("")}</div>`;
  const choices = SKILLS.filter(({ name }) => !fixed.includes(name));
  return `<h2>Escolha as perícias livres</h2><p class="panel-intro">${character.sina} concede <strong>${freeSkillLimit(character)}</strong> perícia(s) livre(s), usando a Razão final de <strong>${character.attributes["Razão"]}</strong>. Escolhidas: <strong>${selectedFree.length}/${freeSkillLimit(character)}</strong>.</p><div class="selection-grid">${choices.map(({ name, technical }) => `<button class="selection-option ${selectedFree.includes(name) ? "selected" : ""}" data-action="wizard-free-skill" data-skill="${name}"><strong>${name}</strong>${technical ? " <small>(T)</small>" : ""}</button>`).join("")}</div>`;
}

function renderWizard() {
  const atStart = wizard.step === 1;
  const atEnd = wizard.step === 7;
  modal(`<div class="modal-header"><h2>Criação guiada</h2><button class="close" data-action="cancel-wizard" aria-label="Cancelar criação">×</button></div><div class="modal-body">${wizardProgress(wizard.step)}${wizardBody()}</div><div class="modal-footer">${!atStart ? button("Voltar", "wizard-back", { className: "ghost", data: { action: "wizard-back" } }) : ""}${atEnd ? button("Criar personagem", "finish-wizard", { className: "primary", data: { action: "finish-wizard" } }) : button("Próximo", "wizard-next", { className: "primary", data: { action: "wizard-next" } })}</div>`);
}

function saveWizardText() {
  document.querySelectorAll("[data-wizard]").forEach((input) => { wizard.character.identity[input.dataset.wizard] = input.value; });
}

function saveWizardChoices() {
  const destination = wizard.step === 3 ? wizard.character.choices.sina : wizard.character.choices.mark;
  document.querySelectorAll("[data-choice]").forEach((select) => { destination[select.dataset.choice] = select.value; });
}

function validateWizardStep() {
  saveWizardText();
  if (wizard.step === 3 || wizard.step === 5) {
    saveWizardChoices();
    const source = wizard.step === 3 ? SINAS[wizard.character.sina] : MARKS[wizard.character.mark];
    if (source.choices.some((choice) => !wizard.character.choices[wizard.step === 3 ? "sina" : "mark"][choice.id])) return "Escolha todas as opções desta etapa.";
  }
  if (wizard.step === 6 && Object.values(wizard.character.baseAttributes).reduce((sum, value) => sum + number(value), 0) !== 5) return "Distribua exatamente os 5 pontos-base.";
  if (wizard.step === 7 && wizard.character.freeSkillsChosen.length !== freeSkillLimit(wizard.character)) return "Escolha a quantidade indicada de perícias livres.";
  return null;
}

function entryModal(kind, entry = null) {
  const isItem = kind === "inventory";
  const currentEntry = entry || { id: uid(), name: "", description: "", duration: "", quantity: 1, weight: 0, equipped: false, active: true, effects: [] };
  modal(`
    <div class="modal-header"><h2>${entry ? "Editar" : "Adicionar"} ${isItem ? "item" : "condição"}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div>
    <form data-entry-form data-kind="${kind}" data-id="${currentEntry.id}"><div class="modal-body"><div class="form-grid"><label>Nome<input name="name" required value="${esc(currentEntry.name)}" /></label>${isItem ? `<label>Quantidade<input name="quantity" type="number" min="1" value="${number(currentEntry.quantity || 1)}" /></label><label>Peso<input name="weight" type="number" min="0" step="0.1" value="${number(currentEntry.weight || 0)}" /></label>` : `<label>Duração<input name="duration" value="${esc(currentEntry.duration || "")}" placeholder="Ex.: 2 rodadas" /></label>`}<label class="full">Descrição<textarea name="description">${esc(currentEntry.description)}</textarea></label></div><h3 style="margin-top:1rem;">Efeitos automáticos</h3><p class="panel-intro">Os efeitos só funcionam se o item estiver equipado ou a condição estiver ativa. “Dados” adiciona ou remove d20; use “Todos” para qualquer perícia.</p><div data-effects>${(currentEntry.effects || []).map(effectFields).join("")}</div>${button("Adicionar efeito", "add-effect", { className: "ghost", data: { action: "add-effect" } })}</div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}<button class="button primary" type="submit">Salvar</button></div></form>`);
}

function effectFields(effect = {}) {
  const options = [
    ["attribute", "Atributo"], ["dice", "Dados (d20)"], ["skill", "Bônus de perícia"], ["testTotal", "Bônus no teste"], ["maxPv", "PV máximo"], ["maxPl", "PL máximo"], ["blockSkill", "Bloquear perícia"]
  ];
  return `<div class="effect-row"><select name="effectKind"><option value="">Tipo…</option>${options.map(([id, label]) => `<option value="${id}" ${effect.kind === id ? "selected" : ""}>${label}</option>`).join("")}</select><input name="effectTarget" placeholder="Alvo: Força, Luta, Todos…" value="${esc(effect.target || "")}" /><input name="effectValue" type="number" placeholder="Valor" value="${effect.value ?? ""}" /><button class="button danger" type="button" data-action="remove-effect">×</button></div>`;
}

function openRollModal(skill) {
  const blocked = isSkillBlocked(current, skill);
  modal(`<div class="modal-header"><h2>Teste de ${esc(skill)}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>O Mestre escolhe qual atributo é usado neste momento.</p><label>Atributo<select data-roll-attribute>${ATTRIBUTES.map((attribute) => `<option value="${attribute}">${attribute} (${getAttributeValue(current, attribute)})</option>`).join("")}</select></label><div id="roll-formula" class="roll-result">Escolha o atributo e calcule a fórmula.</div><label style="margin-top:1rem;">Resultado escolhido no dado físico<input data-roll-result type="number" min="1" max="20" placeholder="Maior ou menor d20 obtido" /></label><div class="button-row" style="margin-top:1rem;">${button("Atualizar fórmula", "calculate-roll", { data: { action: "calculate-roll", skill } })}${button("Calcular total", "roll-total", { className: "primary", data: { action: "roll-total", skill } })}</div>${blocked ? "<p class=\"warning\">Esta perícia está bloqueada por um efeito ativo.</p>" : ""}</div>`);
  updateRollFormula(skill);
}

function updateRollFormula(skill, total = null) {
  const attribute = document.querySelector("[data-roll-attribute]")?.value || ATTRIBUTES[0];
  const result = testFormula(current, skill, attribute);
  const target = document.querySelector("#roll-formula");
  if (!target) return;
  if (result.forbidden) { target.className = "roll-result error"; target.textContent = result.text; return; }
  target.className = "roll-result";
  target.innerHTML = `<strong>${esc(result.text)}</strong><br><small>Perícia: ${result.skillBonus >= 0 ? "+" : ""}${result.skillBonus} · técnica sem treino: ${result.technicalPenalty >= 0 ? "+" : ""}${result.technicalPenalty} · efeitos: ${result.effectTotal >= 0 ? "+" : ""}${result.effectTotal}</small>${total !== null ? `<p style="margin:.5rem 0 0;">Resultado final: <strong>${total}</strong></p>` : ""}`;
}

function useAbility(ability, onUse) {
  const cost = Number(ability.cost);
  const enough = current.resources.plCurrent >= cost;
  modal(`<div class="modal-header"><h2>${esc(ability.name)}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>${esc(ability.description)}</p><p><strong>Custo:</strong> ${esc(ability.cost)} PL · <strong>PL atual:</strong> ${current.resources.plCurrent}</p>${!enough ? "<p class=\"warning\">PL insuficiente para usar esta habilidade.</p>" : ""}</div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}${button("Confirmar uso", "confirm-ability", { className: "primary", data: { action: "confirm-ability", callback: onUse }, disabled: !enough })}</div>`);
}

function makeAbilityCallback(kind, id = "") { return `${kind}:${id}`; }

function handleAbilityCallback(callback) {
  const [kind, id] = callback.split(":");
  if (kind === "mark") {
    const ability = MARKS[current.mark].active;
    current.resources.plCurrent -= Number(ability.cost);
    toast(`${ability.name} usada. ${ability.cost} PL foram consumidos.`);
  }
  if (kind === "vision") {
    const ability = byId(current.visionAbilities, id);
    current.resources.plCurrent -= Number(ability.cost);
    toast(`${ability.name} usada. ${ability.cost} PL foram consumidos.`);
  }
  persist(); closeModal(); renderSheet();
}

function createFreeCharacter() {
  current = newCharacter("free");
  current.resources = { pvCurrent: 10, plCurrent: 10, freePvMax: 10, freePlMax: 10 };
  persist(); activeTab = "resumo"; renderSheet();
}

document.addEventListener("click", (event) => {
  const tab = event.target.closest("[data-tab]");
  if (tab && current && !current.death.active && !current.death.permanent) {
    activeTab = tab.dataset.tab;
    renderSheet();
    return;
  }
  const element = event.target.closest("[data-action]");
  if (!element) return;
  const { action } = element.dataset;
  if (action === "close-modal") { if (event.target === element || element.classList.contains("close") || element.classList.contains("button")) closeModal(); return; }
  if (action === "start-guided") { openWizard(); return; }
  if (action === "start-free") { createFreeCharacter(); return; }
  if (action === "open-load") { openLoadModal(); return; }
  if (action === "home") { renderWelcome(); return; }
  if (action === "cancel-wizard") { closeModal(); wizard = null; return; }
  if (action === "wizard-sina") { wizard.character.sina = element.dataset.sina; wizard.character.choices.sina = {}; renderWizard(); return; }
  if (action === "wizard-mark") { wizard.character.mark = element.dataset.mark; wizard.character.choices.mark = {}; renderWizard(); return; }
  if (action === "wizard-attribute") { const attribute = element.dataset.attribute; const change = number(element.dataset.change); const next = number(wizard.character.baseAttributes[attribute]) + change; if (next >= 0) wizard.character.baseAttributes[attribute] = next; syncAttributes(wizard.character); renderWizard(); return; }
  if (action === "wizard-free-skill") { const skill = element.dataset.skill; const list = wizard.character.freeSkillsChosen; const index = list.indexOf(skill); if (index >= 0) list.splice(index, 1); else if (list.length < freeSkillLimit(wizard.character)) list.push(skill); else toast("Você já escolheu todas as perícias livres.", "error"); renderWizard(); return; }
  if (action === "wizard-next") { const error = validateWizardStep(); if (error) { toast(error, "error"); return; } wizard.step += 1; renderWizard(); return; }
  if (action === "wizard-back") { saveWizardText(); if (wizard.step === 3 || wizard.step === 5) saveWizardChoices(); wizard.step -= 1; renderWizard(); return; }
  if (action === "finish-wizard") {
    const error = validateWizardStep(); if (error) { toast(error, "error"); return; }
    current = wizard.character; syncAttributes(current); applyGrantedSkills(current); current.freeSkillsChosen.forEach((skill) => { current.skills[skill] = "experiente"; });
    const max = getMaxResources(current); current.resources.pvCurrent = max.pv; current.resources.plCurrent = max.pl;
    persist(); wizard = null; closeModal(); activeTab = "resumo"; renderSheet(); toast("Personagem criado e salvo neste navegador."); return;
  }
  if (action === "load-character") { const character = getCharacters().find((item) => item.id === element.dataset.id); if (character) { current = normalizeCharacter(character); activeTab = "resumo"; closeModal(); renderSheet(); } return; }
  if (action === "delete-saved") { deleteCharacter(element.dataset.id); openLoadModal(); toast("Personagem removido deste navegador."); return; }
  if (!current) return;
  if (action === "export") { exportCharacter(current); return; }
  if (action === "print") { window.print(); return; }
  if (action === "level-up") { const result = levelUp(current); persist(); renderSheet(); toast(result.message, result.ok ? "success" : "error"); return; }
  if (action === "add-attribute") { const attribute = element.dataset.attribute; const max = current.level === 1 ? 4 : 5; if (current.attributePoints && getAttributeValue(current, attribute) < max) { current.baseAttributes[attribute] += 1; current.attributePoints -= 1; persist(); renderSheet(); } return; }
  if (action === "upgrade-skill") { const result = upgradeSkill(current, element.dataset.skill); persist(); renderSheet(); toast(result.message, result.ok ? "success" : "error"); return; }
  if (action === "roll") { openRollModal(element.dataset.skill); return; }
  if (action === "calculate-roll") { updateRollFormula(element.dataset.skill); return; }
  if (action === "roll-total") { const raw = document.querySelector("[data-roll-result]")?.value; const attribute = document.querySelector("[data-roll-attribute]")?.value; if (!raw) { toast("Informe o resultado escolhido no d20.", "error"); return; } const formula = testFormula(current, element.dataset.skill, attribute); if (formula.forbidden) { updateRollFormula(element.dataset.skill); return; } updateRollFormula(element.dataset.skill, number(raw) + formula.totalBonus); return; }
  if (action === "new-entry") { entryModal(element.dataset.kind); return; }
  if (action === "edit-entry") { entryModal(element.dataset.kind, byId(current[element.dataset.kind], element.dataset.id)); return; }
  if (action === "toggle-entry") { const entry = byId(current[element.dataset.kind], element.dataset.id); if (element.dataset.kind === "inventory") entry.equipped = !entry.equipped; else entry.active = !entry.active; persist(); renderSheet(); return; }
  if (action === "delete-entry") { current[element.dataset.kind] = current[element.dataset.kind].filter((entry) => entry.id !== element.dataset.id); persist(); renderSheet(); return; }
  if (action === "add-effect") { document.querySelector("[data-effects]").insertAdjacentHTML("beforeend", effectFields()); return; }
  if (action === "remove-effect") { element.closest(".effect-row").remove(); return; }
  if (action === "add-vision") { const ability = getVisionCatalog().find((item) => item.name === element.dataset.name); if (!current.visionAbilities.some((item) => item.name === ability.name)) { current.visionAbilities.push({ ...ability, id: uid() }); persist(); renderSheet(); toast(`${ability.name} foi adicionada à ficha.`); } else toast("Esta habilidade já está na ficha.", "error"); return; }
  if (action === "remove-vision") { current.visionAbilities = current.visionAbilities.filter((ability) => ability.id !== element.dataset.id); persist(); renderSheet(); return; }
  if (action === "use-mark") { const ability = MARKS[current.mark]?.active; if (ability) useAbility(ability, makeAbilityCallback("mark")); return; }
  if (action === "use-vision") { const ability = byId(current.visionAbilities, element.dataset.id); if (ability) useAbility(ability, makeAbilityCallback("vision", ability.id)); return; }
  if (action === "confirm-ability") { handleAbilityCallback(element.dataset.callback); return; }
  if (action === "death-roll") { const value = number(document.querySelector("[data-death-result]")?.value); if (value < 1) { toast("Informe o resultado do Dado de Morte.", "error"); return; } if (value <= 2) { if (current.death.die === "d8") current.death.die = "d6"; else if (current.death.die === "d6") current.death.die = "d4"; else { current.death.permanent = true; current.death.active = true; } toast(current.death.permanent ? "O d4 falhou: morte permanente." : `Falha registrada: o Dado de Morte agora é ${current.death.die}.`, current.death.permanent ? "error" : "success"); } else toast("Resultado 3 ou mais: o Dado de Morte se mantém."); persist(); renderSheet(); return; }
  if (action === "stabilize") { current.resources.pvCurrent = 1; current.death.active = false; current.death.die = "d8"; persist(); renderSheet(); toast("Personagem estabilizado com 1 PV."); return; }
  if (action === "delete-saved") return;
  if (action === "close-modal") return;
});

document.addEventListener("input", (event) => {
  if (!current) return;
  if (event.target.matches("[data-identity]")) { current.identity[event.target.dataset.identity] = event.target.value; persist(); return; }
  if (event.target.matches("[data-resource]")) { current.resources[event.target.dataset.resource] = Math.max(0, number(event.target.value)); persist(); if (event.target.dataset.resource === "pvCurrent" && current.resources.pvCurrent === 0) renderSheet(); return; }
});

document.addEventListener("change", async (event) => {
  if (event.target.matches("[data-status]") && current) { current.status = event.target.value; persist(); renderSheet(); return; }
  if (event.target.matches("[data-photo]") && current) { const file = event.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { current.identity.photo = reader.result; persist(); renderSheet(); }; reader.readAsDataURL(file); return; }
  if (event.target.matches("[data-import-file]")) { const file = event.target.files?.[0]; if (!file) return; try { current = normalizeCharacter(await readCharacterFile(file)); current.id = current.id || uid(); persist(); activeTab = "resumo"; closeModal(); renderSheet(); toast("Ficha importada e salva neste navegador."); } catch { toast("Não foi possível ler este arquivo de ficha.", "error"); } return; }
  if (event.target.matches("[data-roll-attribute]")) { const rollButton = document.querySelector("[data-action='calculate-roll']"); if (rollButton) updateRollFormula(rollButton.dataset.skill); }
});

document.addEventListener("submit", (event) => {
  if (!event.target.matches("[data-entry-form]")) return;
  event.preventDefault();
  const form = event.target;
  const kind = form.dataset.kind;
  const id = form.dataset.id;
  const data = new FormData(form);
  const effects = [...form.querySelectorAll(".effect-row")].map((row) => ({ kind: row.querySelector("[name='effectKind']").value, target: row.querySelector("[name='effectTarget']").value.trim(), value: number(row.querySelector("[name='effectValue']").value) })).filter((effect) => effect.kind);
  const entry = {
    id, name: data.get("name").trim(), description: data.get("description").trim(), effects,
    ...(kind === "inventory" ? { quantity: number(data.get("quantity")) || 1, weight: number(data.get("weight")), equipped: byId(current.inventory, id)?.equipped || false } : { duration: data.get("duration").trim(), active: byId(current.conditions, id)?.active ?? true })
  };
  const entries = current[kind];
  const index = entries.findIndex((item) => item.id === id);
  if (index >= 0) entries[index] = entry; else entries.push(entry);
  persist(); closeModal(); renderSheet(); toast(`${kind === "inventory" ? "Item" : "Condição"} salva.`);
});

if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
renderWelcome();
