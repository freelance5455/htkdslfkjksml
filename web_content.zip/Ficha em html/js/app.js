import { normalizeCharacter } from "./character.js";
import { applyTheme, themeButton } from "./theme.js";
import { attributeBreakdown, resourceBreakdown, effectSources, RESOURCE_FORMULAS } from "./explanations.js";
import { ATTRIBUTES, ATTRIBUTE_INFO, MARKS, SINAS, SKILLS, TRAINING, VISION_PATHS, getVisionCatalog } from "./data.js";
import { deleteCharacter, exportCharacter, getCharacters, readCharacterFile, saveCharacter } from "./storage.js";
import {
  applyGrantedSkills, clampResources, emptySkills, freeSkillLimit, getAttributeValue, getEffects,
  getFixedSkills, getMaxResources, getSkillModifier, isSkillBlocked, levelUp, newCharacter,
  syncAttributes, testFormula, trainingBonus, upgradeSkill
} from "./rules.js";

const app = document.querySelector("#app");
const modalRoot = document.querySelector("#modal-root");
let current = null;
let activeTab = "perfil";
let skillQuery = "";
let visionQuery = "";
const foldStates = new Map();
let wizard = null;
const dismissedBackupNotices = new Set();
let scrollRestoreFrame = null;

const esc = (value = "") => String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
const uid = () => crypto.randomUUID();
const byId = (entries, id) => entries.find((entry) => entry.id === id);
const number = (value) => Number(value || 0);

// A página, o modal e as abas têm rolagens independentes.
function updateView(render, { resetModalScroll = false, resetPageScroll = false } = {}) {
  cancelAnimationFrame(scrollRestoreFrame);
  const position = { x: window.scrollX, y: resetPageScroll ? 0 : window.scrollY, modal: document.querySelector(".modal")?.scrollTop || 0 };
  document.querySelectorAll("[data-fold]").forEach((element) => foldStates.set(`${current?.id}:${element.dataset.fold}`, element.open));
  render();
  document.querySelectorAll("[data-fold]").forEach((element) => {
    const saved = foldStates.get(`${current?.id}:${element.dataset.fold}`);
    if (saved !== undefined) element.open = saved;
  });
  const restore = () => {
    const sheet = document.querySelector(".sheet-page");
    const missingHeight = position.y + window.innerHeight - document.documentElement.scrollHeight;
    if (!resetPageScroll && sheet && missingHeight > 0) sheet.style.minHeight = `${sheet.offsetHeight + missingHeight}px`;
    const dialog = document.querySelector(".modal");
    if (dialog) dialog.scrollTop = resetModalScroll ? 0 : position.modal;
    window.scrollTo({ left: position.x, top: position.y, behavior: "instant" });
  };
  restore();
  scrollRestoreFrame = requestAnimationFrame(restore);
}

function persist() {
  if (!current) return;
  current.updatedAt = new Date().toISOString();
  syncAttributes(current);
  clampResources(current);
  saveCharacter(current);
}

function toast(message, kind = "success") {
  document.querySelector(".toast")?.remove();
  const element = document.createElement("div");
  element.className = `toast ${kind}`;
  element.textContent = message;
  document.body.append(element);
  setTimeout(() => element.remove(), 3600);
}

function button(label, action, options = {}) {
  const { className = "", data = {}, disabled = false, type = "button" } = options;
  const attributes = Object.entries(data).map(([key, value]) => `data-${key}="${esc(value)}"`).join(" ");
  return `<button type="${type}" class="button ${className}" ${attributes} ${disabled ? "disabled" : ""}>${label}</button>`;
}

function renderWelcome() {
  current = null;
  wizard = null;
  skillQuery = "";
  visionQuery = "";
  document.body.classList.remove("sheet-open");
  app.innerHTML = `<section class="welcome"><div class="welcome-theme">${themeButton()}</div><div class="brand"><img class="brand-logo logo-dark" src="icons/visionarios-color.png" alt="" /><img class="brand-logo logo-light" src="icons/visionarios-mono.png" alt="" /><h1>Visionários</h1></div><div class="start-grid">
    ${button("Iniciar criação guiada", "start-guided", { className: "primary", data: { action: "start-guided" } })}
    ${button("Abrir ficha livre", "start-free", { data: { action: "start-free" } })}
    ${button("Carregar ficha existente", "open-load", { data: { action: "open-load" } })}
    <label class="button file-button">Importar ficha<input type="file" data-import-file accept="application/json,.json,.ficha-rpg.json" aria-label="Importar ficha" /></label>
  </div></section>`;
}

function needsBackupReminder() {
  if (!current || dismissedBackupNotices.has(current.id)) return false;
  if (!current.identity.name.trim()) return false;
  return !current.meta?.lastExportAt;
}

function renderGallery() {
  const photos = current.identity.gallery;
  return `<div class="gallery">
    <div class="gallery-label">Galeria de fotos</div>
    <div class="gallery-strip">
      ${photos.map((src, index) => `<div class="gallery-thumb"><img src="${esc(src)}" alt="Foto adicional ${index + 1}" />${button("×", "remove-gallery-photo", { className: "gallery-remove", data: { action: "remove-gallery-photo", index } })}</div>`).join("")}
      <label class="gallery-add" aria-label="Adicionar foto à galeria">+<input type="file" data-gallery-photo accept="image/*" /></label>
    </div>
  </div>`;
}

function renderHeader() {
  return `<section class="character-header">
    <label class="portrait" aria-label="Foto do personagem">${current.identity.photo ? `<img src="${esc(current.identity.photo)}" alt="Foto do personagem" />` : `${icon("perfil")}<span>Adicionar foto</span>`}<input type="file" data-photo accept="image/*" aria-label="Adicionar foto" /></label>
    <div class="identity"><label>Nome<input data-identity="name" value="${esc(current.identity.name)}" placeholder="Nome do personagem" /></label><label>Idade<input data-identity="age" value="${esc(current.identity.age)}" placeholder="Idade" /></label><span class="identity-origin">${esc(current.sina || "Ficha livre")} · ${esc(current.mark || "Sem Marca")}</span></div>
  </section>
  <details class="fold" data-fold="appearance"><summary>Aparência e galeria</summary><div class="fold-body"><label>Aparência<textarea data-identity="appearance" placeholder="Descrição, detalhes visuais...">${esc(current.identity.appearance)}</textarea></label>${renderGallery()}</div></details>
  ${needsBackupReminder() ? `<div class="warning backup-warning"><span>Salve uma cópia da sua ficha.</span><div class="button-row">${button("Exportar", "export", { className: "primary", data: { action: "export" } })}${button("Agora não", "dismiss-backup", { className: "ghost", data: { action: "dismiss-backup" } })}</div></div>` : ""}`;
}

function icon(name) {
  const paths = {
    perfil: '<circle cx="12" cy="8" r="3"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/>',
    atributos: '<path d="M5 4v16M12 4v16M19 4v16M2 8h6M9 16h6M16 10h6"/>',
    combate: '<path d="m4 3 12 12-3 3L3 6V3h1Zm16 0-6 6M8 16l-5 5m13-5 5 5M3 15l6 6m6-18 6 6"/>',
    itens: '<path d="M5 7h14l1 14H4L5 7Zm3 0V6a4 4 0 0 1 8 0v1"/>',
    habilidades: '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
    menu: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>'
  };
  return `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.menu}</svg>`;
}

function resourceCards() {
  const max = getMaxResources(current);
  const dead = current.death.active || current.death.permanent;
  return `<section class="resource-cards" aria-label="Vida e Lucidez">${["pv", "pl"].map((resource) => `<button class="resource-touch" data-action="resource-modal" data-resource="${resource}" aria-label="${resource === "pv" ? "PV: dano ou cura" : "PL: gastar ou recuperar"}" ${dead ? "disabled" : ""}><span class="resource-caption">${resource === "pv" ? "Vida · PV" : "Lucidez · PL"}</span><span class="resource-reading"><strong>${current.resources[`${resource}Current`]}</strong><span>/ ${max[resource]}</span></span><small>${resource === "pv" ? "Dano / cura" : "Gastar / recuperar"}</small></button>`).join("")}</section>`;
}

function profileMark() {
  const mark = MARKS[current.mark];
  if (!mark) return current.mode === "free" ? '<p class="panel-intro">Escolha sua Sina e Marca em “Editar ficha livre”.</p>' : "";
  return `<section class="profile-mark"><div class="section-heading"><div><p class="eyebrow">Sua Marca</p><h2>${esc(current.mark)}</h2></div></div><p><strong>Passiva:</strong> ${esc(mark.passive)}</p><details class="fold nested"><summary>Efeito narrativo</summary><div class="fold-body"><p>${esc(mark.narrative)}</p></div></details>${mark.active ? `<div class="mark-active"><h3>${esc(mark.active.name)}</h3><p>${esc(mark.active.description)}</p>${button(`Usar · ${mark.active.cost} PL`, "use-mark", { className: "primary", data: { action: "use-mark" } })}</div>` : ""}</section>`;
}

function sheetMenu() {
  modal(`<div class="modal-header"><h2>Minha ficha</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body menu-actions">${themeButton()}${current.mode === "free" ? button("Editar ficha livre", "free-editor", { data: { action: "free-editor" } }) : ""}${button("Personagens salvos", "open-load", { data: { action: "open-load" } })}${button("Exportar ficha", "export", { data: { action: "export" } })}${button("Novo personagem", "home", { data: { action: "home" } })}</div>`);
}

function tabs() {
  const names = { perfil: ["Perfil", "Perfil"], atributos: ["Perícias", "Atributos e Perícias"], combate: ["Combate", "Combate"], itens: ["Itens", "Itens e Condições"], habilidades: ["Habilidades", "Habilidades"] };
  const dead = current.death.active || current.death.permanent;
  return `<nav class="bottom-nav" aria-label="Seções da ficha"><div class="bottom-nav-inner">${Object.entries(names).map(([id, [label, full]]) => `<button class="tab ${activeTab === id ? "active" : ""}" data-tab="${id}" aria-label="${full}" ${activeTab === id ? 'aria-current="page"' : ""} ${dead ? "disabled" : ""}>${icon(id)}<span>${label}</span></button>`).join("")}</div></nav>`;
}

function renderSummary() {
  const sina = current.sina ? SINAS[current.sina] : null;
  const mark = current.mark ? MARKS[current.mark] : null;
  const max = getMaxResources(current);
  return `
    <section class="panel" data-title="Resumo">
      <p class="panel-intro">Uma visão rápida do personagem. As informações são salvas automaticamente neste navegador.</p>
      <div class="paper-grid">
        <article class="note">
          <h2>Origem</h2>
          <p><strong>Sina:</strong> ${sina ? esc(current.sina) : "Ficha livre"}</p>
          <p>${sina ? esc(sina.description) : "Sem regras automáticas de Sina."}</p>
          <p><strong>Marca:</strong> ${mark ? esc(current.mark) : "Nenhuma"}</p>
        </article>
        <article class="note"><h2>Combate</h2><p><strong>Dado de Morte:</strong> ${current.death.die}</p><p><strong>PV máximo:</strong> ${max.pv} · <strong>PL máximo:</strong> ${max.pl}</p><p>Use a aba Combate para registrar rodadas, armaduras e armas.</p></article>
        <article class="note wide">
          <h2>Lembretes para a mesa</h2>
          <ul class="rule-list">
            <li>Todo teste usa um atributo escolhido pelo Mestre e uma perícia.</li>
            <li>Atributo acima de 0: role esse número de d20 e use o maior. Em 0: 2d20 e use o menor.</li>
            <li>Perícias técnicas sem treino recebem −5. Condições e itens ativos entram nas rolagens automaticamente.</li>
          </ul>
        </article>
      </div>
    </section>`;
}

function renderNotes() {
  const notes = [...current.notes].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return `
    <section class="panel" data-title="Anotações">
      <div class="list-toolbar"><p class="panel-intro">Registre acontecimentos, NPCs, pistas e lembretes de campanha. Fica salvo junto com a ficha.</p>${button("Nova anotação", "note-modal", { className: "primary", data: { action: "note-modal" } })}</div>
      <div class="entry-list">${notes.length ? notes.map((note) => `<article class="entry"><div><h3>${esc(note.title || "Sem título")}</h3><p>${esc(note.text).replace(/\n/g, "<br>")}</p><small>${new Date(note.createdAt).toLocaleString("pt-BR")}</small></div><div class="entry-actions">${button("Editar", "note-modal", { className: "ghost", data: { action: "note-modal", id: note.id } })}${button("Remover", "delete-note", { className: "danger", data: { action: "delete-note", id: note.id } })}</div></article>`).join("") : `<div class="empty-state">Ainda não há anotações. Use o botão acima para registrar a primeira.</div>`}</div>
    </section>`;
}

function noteModal(id) {
  const existing = id ? byId(current.notes, id) : null;
  const note = existing || { id: uid(), title: "", text: "", createdAt: new Date().toISOString() };
  modal(`
    <div class="modal-header"><h2>${existing ? "Editar" : "Nova"} anotação</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div>
    <form data-note-form data-id="${note.id}" data-created="${esc(note.createdAt)}">
      <div class="modal-body">
        <label>Título<input name="title" value="${esc(note.title)}" placeholder="Ex.: Pista do porão" /></label>
        <label class="full" style="margin-top:.8rem;">Texto<textarea name="text" style="min-height:8rem;" placeholder="O que aconteceu, quem estava envolvido, o que descobriram...">${esc(note.text)}</textarea></label>
      </div>
      <div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}${button("Salvar", "", { className: "primary", type: "submit" })}</div>
    </form>`);
}

function renderAttributes() {
  const max = getMaxResources(current);
  const effects = getEffects(current);
  const effective = (attribute) => getAttributeValue(current, attribute);
  return `
    <section class="panel" data-title="Atributos">
      <p class="panel-intro">Os valores abaixo já incluem bônus de Sina, Marca, condições e itens equipados.</p>
      <div class="point-box">
        <strong>${current.attributePoints}</strong><span>Ponto(s) de Atributo disponível(is). ${current.mode === "free" ? "Use Editar ficha livre para definir valores diretamente." : `O limite é ${current.level === 1 ? 4 : 5} no valor final.`}</span>
        ${(!current.sina || (current.mode === "free" && current.freeSettings.resourceMode === "manual")) ? `<label>PV máximo manual<input type="number" min="0" data-resource="freePvMax" value="${current.resources.freePvMax}" /></label><label>PL máximo manual<input type="number" min="0" data-resource="freePlMax" value="${current.resources.freePlMax}" /></label>` : ""}
      </div>
      <div class="attribute-grid">
        ${ATTRIBUTES.map((attribute) => {
          const adjustment = effective(attribute) - current.attributes[attribute];
          const atLimit = effective(attribute) >= (current.level === 1 ? 4 : 5);
          return `<article class="attribute-card">
            <h3>${attribute}</h3>
            <button class="attribute-circle" data-action="explain-attribute" data-attribute="${attribute}" aria-label="Entender cálculo de ${attribute}">${effective(attribute)}</button><small class="attribute-help">Ver cálculo</small>
            <p class="effect-hint">${adjustment ? `Efeitos ativos: ${adjustment > 0 ? "+" : ""}${adjustment}` : "Sem efeito temporário"}</p>
            <button class="button" data-action="add-attribute" data-attribute="${attribute}" ${current.attributePoints < 1 || atLimit ? "disabled" : ""}>+ ponto</button>
          </article>`;
        }).join("")}
      </div>
      <div class="paper-grid" style="margin-top: 1rem;">
        <article class="note wide"><h2>PV e PL</h2><div class="button-row">${button("Cálculo de PV", "explain-resource", { className: "ghost", data: { action: "explain-resource", resource: "pv" } })}${button("Cálculo de PL", "explain-resource", { className: "ghost", data: { action: "explain-resource", resource: "pl" } })}</div><p>PV máximo: <strong>${max.pv}</strong> · PL máximo: <strong>${max.pl}</strong>.</p><p>${current.sina && !(current.mode === "free" && current.freeSettings.resourceMode === "manual") ? "Eles são recalculados quando atributos, nível, itens equipados ou condições mudam." : "Na ficha livre, os máximos são definidos manualmente acima, mas itens e condições ainda podem modificá-los."}</p></article>
      </div>
    </section>`;
}

function renderSkills() {
  return `<section class="panel" data-title="Perícias"><div class="section-heading"><h2>Perícias</h2>${current.mode === "free" ? button("Editar ficha livre", "free-editor", { className: "ghost", data: { action: "free-editor" } }) : `<span class="badge">${current.abilityPoints} PH</span>`}</div>
    <label class="search-field">Buscar perícia<input type="search" data-skill-search value="${esc(skillQuery)}" placeholder="Nome, treinamento ou técnica..." autocomplete="off" /></label>
    <div class="skills-list">${SKILLS.map(({ name, technical }) => skillRow(name, { technical, evolve: true })).join("")}</div><p class="empty-state" data-skills-empty hidden>Nenhuma perícia encontrada.</p></section>`;
}

function skillRow(name, { technical = false, evolve = false, source = "" } = {}) {
  const blocked = isSkillBlocked(current, name);
  const training = TRAINING.find((entry) => entry.id === current.skills[name]) || TRAINING[0];
  const cost = current.skills[name] === "inexperiente" ? 1 : current.skills[name] === "experiente" ? 2 : 0;
  const bonus = getSkillModifier(current, name);
  return `<div class="skill-row ${blocked ? "blocked" : ""}" data-skill-search-text="${esc(searchText(`${name} ${training.label} ${technical ? "técnica" : ""}`))}"><div class="skill-info"><span class="skill-name">${esc(name)} <b class="skill-bonus">${signed(bonus)}</b></span><small>${training.label}${technical ? " · Técnica" : ""}${blocked ? " · Bloqueada" : ""}${source ? ` · ${esc(source)}` : ""}</small></div><button class="button skill-roll" data-action="roll" data-skill="${esc(name)}" ${blocked ? "disabled" : ""}>Ver rolagem</button>${evolve && cost ? `<button class="button ghost skill-upgrade" data-action="upgrade-skill" data-skill="${esc(name)}" aria-label="Evoluir ${esc(name)} por ${cost} PH" ${current.abilityPoints < cost ? "disabled" : ""}>Evoluir<span>${cost} PH</span></button>` : ""}</div>`;
}

function searchText(value) { return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim(); }
function signed(value) { return `${value >= 0 ? "+" : "−"}${Math.abs(value)}`; }
function filterSkills() {
  const rows = [...document.querySelectorAll('[data-title="Perícias"] .skill-row')];
  rows.forEach((row) => { row.hidden = !row.dataset.skillSearchText.includes(searchText(skillQuery)); });
  const empty = document.querySelector("[data-skills-empty]");
  if (empty) empty.hidden = rows.some((row) => !row.hidden);
}

function formatEffects(effects = []) {
  if (!effects.length) return "";
  const labels = { attribute: "Atributo", dice: "Dados", skill: "Perícia", testTotal: "Teste", maxPv: "PV máximo", maxPl: "PL máximo", blockSkill: "Bloqueia" };
  return `<div class="effect-tags">${effects.map((effect) => `<span class="effect-tag">${labels[effect.kind] || effect.kind}${effect.target ? ` · ${esc(effect.target)}` : ""}${effect.kind === "blockSkill" ? "" : ` ${number(effect.value) >= 0 ? "+" : ""}${esc(effect.value)}`}</span>`).join("")}</div>`;
}

function renderEntries(kind, title) {
  const entries = current[kind];
  return `
    <section class="panel" data-title="${title}">
      <div class="list-toolbar"><p class="panel-intro">${kind === "inventory" ? "Itens só aplicam efeitos enquanto estiverem equipados." : "Condições ativas entram nos cálculos de recursos e testes."}</p>${button(kind === "inventory" ? "Adicionar item" : "Adicionar condição", "new-entry", { className: "primary", data: { action: "new-entry", kind } })}</div>
      <div class="entry-list">${entries.length ? entries.map((entry) => `<article class="entry ${kind === "conditions" && !entry.active ? "inactive" : ""}">
        <div><h3>${esc(entry.name || "Sem nome")} ${kind === "inventory" ? `<small>· ${number(entry.quantity || 1)} un. · ${number(entry.weight || 0)} peso</small>` : entry.duration ? `<small>· ${esc(entry.duration)}</small>` : ""}</h3><p>${esc(entry.description || "Sem descrição.")}</p>${formatEffects(entry.effects)}</div>
        <div class="entry-actions">${button(kind === "inventory" ? (entry.equipped ? "Desequipar" : "Equipar") : (entry.active ? "Desativar" : "Ativar"), "toggle-entry", { data: { action: "toggle-entry", kind, id: entry.id } })}${button("Editar", "edit-entry", { className: "ghost", data: { action: "edit-entry", kind, id: entry.id } })}${button("Remover", "delete-entry", { className: "danger", data: { action: "delete-entry", kind, id: entry.id } })}</div>
      </article>`).join("") : `<div class="empty-state">Ainda não há ${kind === "inventory" ? "itens" : "condições"}. Adicione um para registrar seus efeitos.</div>`}</div>
    </section>`;
}

function abilityDetails(ability) {
  const rich = (value = "") => esc(value).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br>");
  if (!ability.rules) return "";
  return `<details class="fold nested ability-rules"><summary>Como usar</summary><div class="fold-body"><p>${rich(ability.rules)}</p><details class="fold nested"><summary>Ficha técnica</summary><div class="fold-body technical-rules">${rich(ability.technical)}</div></details>${ability.trainingCombinations ? `<details class="fold nested"><summary>Combinar treinamentos</summary><div class="fold-body"><div class="training-combinations">${ability.trainingCombinations.map(([own, stolen, result]) => `<p><span>${own} + ${stolen}</span><strong> → ${result}</strong></p>`).join("")}</div><p>${esc(ability.trainingNote)}</p></div></details>` : ""}</div></details>`;
}

function renderVision() {
  const catalog = getVisionCatalog();
  const learned = current.visionAbilities;
  const limit = visionAbilityLimit();
  const canAdd = limit === Infinity || learned.filter((ability) => !ability.legacy).length < limit;
  return `<section class="panel" data-title="Habilidades de Visão">
    <p class="panel-intro">${current.mode === "free" ? "Ficha livre: adicione ou remova habilidades sem limite de nível ou Sina." : `${esc(current.sina || "Sem Sina")}: ${learned.filter((ability) => !ability.legacy).length}/${limit} habilidade(s) liberada(s) até o nível ${current.level}.`}</p>
    <article class="note"><h2>Habilidades aprendidas</h2>${learned.length ? `<div class="entry-list">${learned.map((ability) => `<article class="entry"><div><h3>${esc(ability.name)} <small>· ${esc(ability.path)}</small></h3><p>${esc(ability.description)}</p><span class="badge">${esc(ability.cost)} PL</span>${ability.legacy ? '<p class="panel-intro">Edição anterior: preservada da sua ficha. Você pode removê-la e escolher uma habilidade do catálogo atual.</p>' : ""}${abilityDetails(ability)}</div><div class="entry-actions">${button("Usar", "use-vision", { className: "primary", data: { action: "use-vision", id: ability.id } })}${current.mode === "free" || ability.legacy ? button("Remover", "remove-vision", { className: "ghost", data: { action: "remove-vision", id: ability.id } }) : ""}</div></article>`).join("")}</div>` : '<p class="empty-state">Nenhuma habilidade aprendida ainda.</p>'}</article>
    <details class="fold" data-fold="vision-catalog"><summary>Catálogo de Habilidades de Visão <span class="badge">${catalog.length}</span></summary><div class="fold-body"><label class="full">Buscar no catálogo<input type="search" value="${esc(visionQuery)}" data-vision-search placeholder="Nome, Caminho ou palavra-chave..." /></label>
    <p class="empty-state" data-vision-empty hidden>Nenhuma habilidade encontrada para esta busca.</p>
    ${Object.keys(VISION_PATHS).map((path) => `<section class="catalog-group"><h3>${esc(path)}</h3><div class="catalog">${catalog.filter((ability) => ability.path === path).map((ability) => `<article class="catalog-card" data-search="${esc(`${path} ${ability.name} ${ability.description} ${ability.rules}`)}"><h3>${esc(ability.name)}</h3><p><span class="badge">${esc(ability.cost)} PL</span></p><p>${esc(ability.description)}</p>${abilityDetails(ability)}${button("Adicionar à ficha", "add-vision", { data: { action: "add-vision", name: ability.name }, disabled: !canAdd || learned.some((item) => item.name === ability.name) })}</article>`).join("")}</div></section>`).join("")}</div></details></section>`;
}

function visionAbilityLimit() {
  if (current.mode === "free" || !current.sina) return Infinity;
  return SINAS[current.sina].visionLevels.filter((level) => level <= current.level).length;
}

function equippedWeapon() { return current.combat.weapons.find((weapon) => weapon.equipped); }
function equippedArmor() { return current.combat.armors.find((armor) => armor.equipped); }

function damageFormula() {
  const weapon = equippedWeapon();
  if (!weapon) return `1d4 + ${getAttributeValue(current, "Força")} (Força)`;
  const attribute = weapon.type === "curta" ? "Força" : weapon.type === "longa" ? "Instinto" : null;
  return `${weapon.damage}${attribute ? ` + ${getAttributeValue(current, attribute)} (${attribute})` : ""}${weapon.type === "distancia" ? ` · munição: ${weapon.ammoDie || "esgotada"}` : ""}`;
}

function renderEquipment() {
  return `<article class="note"><div class="list-toolbar"><h2>Inventário de batalha</h2><div class="button-row">${button("Adicionar arma", "weapon-modal", { className: "primary", data: { action: "weapon-modal" } })}${button("Adicionar armadura", "armor-modal", { className: "primary", data: { action: "armor-modal" } })}</div></div>
        <div class="entry-list">${[...current.combat.weapons, ...current.combat.armors].length ? [...current.combat.weapons.map((entry) => ({...entry, kind:"weapon"})), ...current.combat.armors.map((entry) => ({...entry,kind:"armor"}))].map((entry) => `<article class="entry"><div><h3>${esc(entry.name)} <small>· ${entry.kind === "weapon" ? esc(entry.damage) : `PD ${entry.pdCurrent}/${entry.pdMax} · Defesa ${entry.defense}`}</small></h3><p>${esc(entry.description || "Sem descrição.")}</p>${formatEffects(entry.effects)}</div><div class="entry-actions">${button(entry.equipped ? "Desequipar" : "Equipar", "equip-combat", { data: { action: "equip-combat", kind: entry.kind, id: entry.id } })}${button("Editar", entry.kind === "weapon" ? "weapon-modal" : "armor-modal", { className: "ghost", data: { action: entry.kind === "weapon" ? "weapon-modal" : "armor-modal", id: entry.id } })}${button("Remover", "delete-combat", { className: "danger", data: { action: "delete-combat", kind: entry.kind, id: entry.id } })}</div></article>`).join("") : "<p class=\"empty-state\">Sem armas ou armaduras cadastradas.</p>"}</div>
      </article>`;
}

function renderCombat() {
  const weapon = equippedWeapon();
  const armor = equippedArmor();
  const max = getMaxResources(current);
  const activeConditions = current.conditions.filter((condition) => condition.active);
  const abilities = [...(MARKS[current.mark]?.active ? [{ ...MARKS[current.mark].active, source: "mark" }] : []), ...current.visionAbilities.map((ability) => ({ ...ability, source: "vision" }))];
  const abilityRow = (ability) => `<div class="quick-ability"><span><strong>${esc(ability.name)}</strong><small>${esc(ability.cost)} PL</small></span>${button("Usar", ability.source === "mark" ? "use-mark" : "use-vision", { data: ability.source === "mark" ? { action: "use-mark" } : { action: "use-vision", id: ability.id } })}</div>`;
  return `<section class="combat-dashboard">
    <div class="combat-round"><span>Rodada <strong>${current.combat.round}</strong></span>${button("Próxima rodada", "combat-round", { className: "ghost", data: { action: "combat-round", change: 1 } })}</div>
    <div class="combat-grid">
      <div class="wide">${resourceCards()}</div>
      <article class="combat-card"><h2>Arma equipada</h2><strong>${esc(weapon?.name || "Desarmado")}</strong><p class="damage-value">${esc(damageFormula().split(" · munição:")[0])}</p>${weapon?.type === "distancia" ? button(`Munição · ${weapon.ammoDie || "esgotada"}`, "ammo-modal", { className: "ghost", data: { action: "ammo-modal", id: weapon.id }, disabled: !weapon.ammoDie }) : ""}</article>
      <article class="combat-card"><h2>Armadura equipada</h2><strong>${esc(armor?.name || "Sem armadura")}</strong>${armor ? `<p>PD ${armor.pdCurrent}/${armor.pdMax}<br>Defesa ${armor.defense}</p>` : `<p>Sem proteção equipada.</p>`}</article>
      <article class="combat-card wide"><h2>Condições ativas</h2><div class="condition-chips">${activeConditions.length ? activeConditions.map((condition) => `<button class="condition-chip" data-action="edit-entry" data-kind="conditions" data-id="${esc(condition.id)}">${esc(condition.name)}${condition.endRound ? ` · R${condition.endRound}` : ""}</button>`).join("") : '<small>Nenhuma condição ativa.</small>'}</div></article>
      <article class="combat-card wide"><h2>Habilidades rápidas</h2>${abilities.length ? abilities.slice(0, 2).map(abilityRow).join("") : '<small>Nenhuma habilidade disponível.</small>'}${abilities.length > 2 ? `<details class="fold nested" data-fold="more-quick-abilities"><summary>Mais ${abilities.length - 2} habilidades</summary>${abilities.slice(2).map(abilityRow).join("")}</details>` : ""}</article>
    </div>
    <label class="combat-notes">Notas rápidas<textarea data-combat-notes placeholder="Alvos, ferimentos, lembretes...">${esc(current.combat.notes || "")}</textarea></label>
    <details class="fold" data-fold="equipment"><summary>Gerenciar equipamento</summary><div class="fold-body">${renderEquipment()}</div></details>
    <details class="fold" data-fold="combat-extra"><summary>Iniciativa e controle de rodadas</summary><div class="fold-body"><p>Iniciativa: Reflexo + Instinto (${getAttributeValue(current, "Instinto")}).</p><div class="button-row">${button("Ver rolagem de iniciativa", "roll", { data: { action: "roll", skill: "Reflexo" } })}${button("Resetar rodadas", "combat-reset-round", { className: "ghost", data: { action: "combat-reset-round" } })}</div></div></details>
  </section>`;
}

function renderOrigin() {
  const sina = SINAS[current.sina];
  const mark = MARKS[current.mark];
  const fixed = getFixedSkills(current);
  const trained = SKILLS.filter(({ name }) => current.skills[name] !== "inexperiente");
  return `<section class="panel" data-title="Sina e Marca"><h2>Sina e Marca</h2>
    <details class="fold" data-fold="sina"><summary>Sina · ${esc(current.sina || "Ficha livre")}</summary><div class="fold-body">${sina ? `<p>${esc(sina.description)}</p><p><strong>Perícias livres concedidas:</strong> ${freeSkillLimit(current)}</p><p><strong>Habilidades de Visão:</strong> níveis ${sina.visionLevels.join(", ")}.</p>` : '<p>Esta ficha não possui Sina. Os recursos máximos são manuais.</p>'}</div></details>
    <details class="fold" data-fold="mark"><summary>Marca · ${esc(current.mark || "Sem Marca")}</summary><div class="fold-body">${mark ? `<p><strong>Efeito narrativo:</strong> ${esc(mark.narrative)}</p><p><strong>Passiva:</strong> ${esc(mark.passive)}</p>${mark.active ? button(`Usar ${esc(mark.active.name)} · ${mark.active.cost} PL`, "use-mark", { className: "primary", data: { action: "use-mark" } }) : ""}` : '<p>Esta ficha não possui Marca.</p>'}</div></details>
    <details class="fold" data-fold="granted-skills" open><summary>Perícias concedidas e treinadas <span class="badge">${trained.length}</span></summary><div class="fold-body"><p class="panel-intro">Consulte suas perícias e abra o teste por aqui. O treinamento e os bônus são os mesmos da lista de Perícias.</p><div class="trained-skills">${trained.length ? trained.map(({ name, technical }) => skillRow(name, { technical, source: fixed.includes(name) ? "Sina/Marca" : current.freeSkillsChosen.includes(name) ? "Escolha livre" : "Evolução" })).join("") : '<p class="empty-state">Nenhuma perícia treinada.</p>'}</div></div></details>
  </section>`;
}

function renderDeath() {
  const permanent = current.death.permanent;
  return `
    <div class="death-lock"><strong>A personagem está em estado de morte.</strong> A ficha foi bloqueada até estabilizar. Sorte Forjada, se aprendida, ainda pode ser usada antes de resolver o dado.</div>
    <section class="death-panel">
      <h2>${permanent ? "Morte permanente" : "Dado de Morte"}</h2>
      <p>${permanent ? "O d4 falhou. Registre este desfecho na história." : "Role o dado físico e informe o resultado abaixo."}</p>
      <div class="die">${current.death.die}</div>
      ${!permanent ? `<div class="button-row">${button("Passou · 3 ou mais", "death-pass", { className: "primary", data: { action: "death-pass" } })}${button("Fracassou · 1 ou 2", "death-fail", { className: "danger", data: { action: "death-fail" } })}${button("Estabilizado · recuperar 1 PV", "stabilize", { data: { action: "stabilize" } })}</div><p>Fracassar degrada d8 → d6 → d4 → morte permanente. Passar mantém o dado atual.</p>` : ""}
      ${!permanent && current.visionAbilities.some((ability) => ability.name === "Sorte Forjada") ? button("Usar Sorte Forjada", "use-vision", { data: { action: "use-vision", id: current.visionAbilities.find((ability) => ability.name === "Sorte Forjada").id } }) : ""}
      ${permanent && current.deathSnapshot ? button("Desfazer morte", "undo-death", { data: { action: "undo-death" } }) : ""}
    </section>`;
}

function renderSheet({ resetPageScroll = false } = {}) {
  if (!current) return renderWelcome();
  document.body.classList.add("sheet-open");
  syncAttributes(current);
  const dead = current.death.active || current.death.permanent;
  const titles = { perfil: "Perfil", atributos: "Atributos e Perícias", combate: "Combate", itens: "Itens e Condições", habilidades: "Habilidades" };
  const content = () => {
    if (dead) return renderDeath();
    if (activeTab === "perfil") return `${resourceCards()}${renderHeader()}${current.mode === "free" ? button("Editar ficha livre", "free-editor", { className: "primary free-editor-trigger", data: { action: "free-editor" } }) : ""}${profileMark()}${renderProgression()}<h2 class="section-title">Anotações</h2>${renderNotes()}`;
    if (activeTab === "atributos") return `${renderProgression()}<details class="fold" data-fold="summary"><summary>Resumo e lembretes</summary><div class="fold-body">${renderSummary()}</div></details><details class="fold" data-fold="attributes"><summary>Atributos <span class="badge">${current.attributePoints} ponto(s)</span></summary><div class="fold-body">${renderAttributes()}</div></details>${renderSkills()}`;
    if (activeTab === "combate") return renderCombat();
    if (activeTab === "itens") return `<h2>Inventário</h2>${renderEntries("inventory", "Inventário")}<h2 class="section-title">Condições</h2>${renderEntries("conditions", "Condições")}`;
    return `${renderOrigin()}${renderVision()}`;
  };
  updateView(() => {
    app.innerHTML = `<div class="sheet-shell"><div class="page-heading"><div><p class="eyebrow">${esc(current.identity.name || "Seu personagem")}</p><h1>${dead ? "Dado de Morte" : titles[activeTab]}</h1></div><div class="page-tools"><span class="level-pill">Nível ${current.level}</span><button class="icon-button" data-action="sheet-menu" aria-label="Menu da ficha">${icon("menu")}</button></div></div><div class="sheet-page">${content()}</div></div>${tabs()}`;
    filterSkills(); filterVision();
  }, { resetPageScroll });
}

function renderProgression() {
  return `<div class="progression"><span><strong>${current.abilityPoints}</strong> PH · <strong>${current.attributePoints}</strong> ponto(s) de atributo</span>${current.level < 20 ? button("Subir nível", "confirm-level-up", { className: "ghost", data: { action: "confirm-level-up" } }) : '<span>Nível máximo</span>'}</div>`;
}

function modal(content, { resetModalScroll = true } = {}) { updateView(() => { modalRoot.innerHTML = `<div class="modal-backdrop" data-action="close-modal"><section class="modal" role="dialog" aria-modal="true">${content}</section></div>`; }, { resetModalScroll }); }
function closeModal() { updateView(() => { modalRoot.innerHTML = ""; }); }

function openLoadModal() {
  const characters = getCharacters();
  modal(`
    <div class="modal-header"><h2>Personagens salvos</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div>
    <div class="modal-body"><p>Os personagens abaixo ficam salvos neste navegador. Você também pode importar uma ficha em formato <code>.ficha-rpg.json</code>.</p>
      <div class="entry-list">${characters.length ? characters.map((character) => `<article class="entry"><div><h3>${esc(character.identity?.name || "Sem nome")}</h3><p>Nível ${number(character.level || 1)} · ${esc(character.sina || "Ficha livre")} ${character.mark ? `· ${esc(character.mark)}` : ""}</p></div><div class="entry-actions">${button("Abrir", "load-character", { className: "primary", data: { action: "load-character", id: character.id } })}${button("Excluir", "delete-saved", { className: "danger", data: { action: "delete-saved", id: character.id } })}</div></article>`).join("") : `<p class="empty-state">Nenhum personagem salvo neste navegador.</p>`}</div>
      <label class="full" style="margin-top: 1rem;">Importar ficha<input type="file" data-import-file accept="application/json,.json,.ficha-rpg.json" /></label>
    </div>`);
}

function confirmDeleteCharacter(character) {
  modal(`<div class="modal-header"><h2>Excluir "${esc(character.identity?.name || "Sem nome")}"?</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>Esta ação remove o personagem deste navegador e não pode ser desfeita. Se quiser manter uma cópia, exporte a ficha antes de excluir.</p></div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}${button("Excluir definitivamente", "confirm-delete-saved", { className: "danger", data: { action: "confirm-delete-saved", id: character.id } })}</div>`);
}

function choiceFields(source, selected = {}) {
  return source.choices.map((choice) => `<label class="choice-field">${esc(choice.label)}<select data-choice="${choice.id}"><option value="">Escolha…</option>${choice.options.map((option) => `<option value="${esc(option)}" ${selected[choice.id] === option ? "selected" : ""}>${esc(option)}</option>`).join("")}</select></label>`).join("");
}

function wizardProgress(step) { return `<div class="stepper" aria-label="Progresso da criação">${[1,2,3,4,5,6,7].map((item) => `<span class="${item === step ? "current" : ""}">${item}</span>`).join("")}</div>`; }

function openWizard(character = newCharacter("guided"), step = 1) {
  wizard = { character: normalizeCharacter(character), step };
  renderWizard({ resetScroll: true });
}

function wizardBody() {
  const character = wizard.character;
  syncAttributes(character);
  const fixed = getFixedSkills(character);
  const selectedFree = character.freeSkillsChosen;
  const maxAttributes = character.level === 1 ? 4 : 5;
  const baseSpent = Object.values(character.baseAttributes).reduce((sum, value) => sum + number(value), 0);
  if (wizard.step === 1) return `<h2>Quem é este personagem?</h2><p class="panel-intro">Esses dados sempre podem ser alterados depois.</p><div class="form-grid"><label>Nome<input data-wizard="name" value="${esc(character.identity.name)}" autofocus /></label><label>Idade<input data-wizard="age" value="${esc(character.identity.age)}" /></label><label class="full">Aparência<textarea data-wizard="appearance">${esc(character.identity.appearance)}</textarea></label></div>`;
  if (wizard.step === 2) return `<h2>Escolha a Sina</h2><p class="panel-intro">A Sina determina fórmulas de PV/PL, perícias livres e a progressão de Habilidades de Visão.</p><div class="selection-grid">${Object.entries(SINAS).map(([name, sina]) => `<button class="selection-option ${character.sina === name ? "selected" : ""}" data-action="wizard-sina" data-sina="${name}"><strong>${name}</strong><br><small>${esc(sina.description)}</small></button>`).join("")}</div>`;
  if (wizard.step === 3) { const sina = SINAS[character.sina]; return `<h2>Escolhas da Sina: ${esc(character.sina)}</h2>${sina.choices.length ? choiceFields(sina, character.choices.sina) : "<p class=\"empty-state\">Esta Sina não exige escolhas adicionais.</p>"}`; }
  if (wizard.step === 4) return `<h2>Escolha a Marca</h2><p class="panel-intro">A Marca concede bônus, perícias treinadas e uma habilidade ativa.</p><div class="selection-grid">${Object.entries(MARKS).map(([name, mark]) => `<button class="selection-option ${character.mark === name ? "selected" : ""}" data-action="wizard-mark" data-mark="${name}"><strong>${name}</strong><br><small>${esc(mark.passive)}</small><small class="mark-skills"><strong>Perícias treinadas:</strong> ${mark.trainedSkills.map(esc).join(", ")}${mark.choices.filter((choice) => choice.type === "trainedSkill").length ? ` + ${mark.choices.filter((choice) => choice.type === "trainedSkill").length} perícia à sua escolha` : ""}</small></button>`).join("")}</div>`;
  if (wizard.step === 5) { const mark = MARKS[character.mark]; return `<h2>Escolhas da Marca: ${esc(character.mark)}</h2>${mark.choices.length ? choiceFields(mark, character.choices.mark) : "<p class=\"empty-state\">Esta Marca não exige escolhas adicionais.</p>"}`; }
  if (wizard.step === 6) return `<h2>Distribua os 5 pontos-base</h2><p class="panel-intro">Pontos-base distribuídos: <strong>${baseSpent}/5</strong>. O limite final no nível 1 é ${maxAttributes}; Sina e Marca entram na conta.</p><div class="attribute-grid">${ATTRIBUTES.map((attribute) => `<article class="attribute-card"><h3>${attribute}</h3><div class="attribute-circle">${character.baseAttributes[attribute]}</div><p class="effect-hint">Final: ${character.attributes[attribute]}</p><div class="button-row" style="justify-content:center;"><button class="button" data-action="wizard-attribute" data-attribute="${attribute}" data-change="-1" ${character.baseAttributes[attribute] <= 0 ? "disabled" : ""}>−</button><button class="button" data-action="wizard-attribute" data-attribute="${attribute}" data-change="1" ${baseSpent >= 5 || character.attributes[attribute] >= maxAttributes ? "disabled" : ""}>+</button></div></article>`).join("")}</div>`;
  const choices = SKILLS.filter(({ name }) => !fixed.includes(name));
  return `<h2>Escolha as perícias livres</h2><p class="panel-intro">${character.sina} concede <strong>${freeSkillLimit(character)}</strong> perícia(s) livre(s), usando a Razão final de <strong>${character.attributes["Razão"]}</strong>. Escolhidas: <strong>${selectedFree.length}/${freeSkillLimit(character)}</strong>.</p><div class="selection-grid">${choices.map(({ name, technical }) => `<button class="selection-option ${selectedFree.includes(name) ? "selected" : ""}" data-action="wizard-free-skill" data-skill="${name}"><strong>${name}</strong>${technical ? " <small>(T)</small>" : ""}</button>`).join("")}</div>`;
}

function renderWizard({ resetScroll = false } = {}) {
  const atStart = wizard.step === 1;
  const atEnd = wizard.step === 7;
  modal(`<div class="modal-header"><h2>Criação guiada</h2><button class="close" data-action="cancel-wizard" aria-label="Cancelar criação">×</button></div><div class="modal-body">${wizardProgress(wizard.step)}${wizardBody()}</div><div class="modal-footer">${!atStart ? button("Voltar", "wizard-back", { className: "ghost", data: { action: "wizard-back" } }) : ""}${atEnd ? button("Criar personagem", "finish-wizard", { className: "primary", data: { action: "finish-wizard" } }) : button("Próximo", "wizard-next", { className: "primary", data: { action: "wizard-next" } })}</div>`, { resetModalScroll: resetScroll });
}

function saveWizardText() {
  document.querySelectorAll("[data-wizard]").forEach((input) => { wizard.character.identity[input.dataset.wizard] = input.value; });
}

function saveWizardChoices() {
  const destination = wizard.step === 3 ? wizard.character.choices.sina : wizard.character.choices.mark;
  document.querySelectorAll("[data-choice]").forEach((select) => { destination[select.dataset.choice] = select.value; });
}

function validateWizardStep() {
  saveWizardText();
  if (wizard.step === 3 || wizard.step === 5) {
    saveWizardChoices();
    const source = wizard.step === 3 ? SINAS[wizard.character.sina] : MARKS[wizard.character.mark];
    if (source.choices.some((choice) => !wizard.character.choices[wizard.step === 3 ? "sina" : "mark"][choice.id])) return "Escolha todas as opções desta etapa.";
  }
  if (wizard.step === 6 && Object.values(wizard.character.baseAttributes).reduce((sum, value) => sum + number(value), 0) !== 5) return "Distribua exatamente os 5 pontos-base.";
  if (wizard.step === 7 && wizard.character.freeSkillsChosen.length !== freeSkillLimit(wizard.character)) return "Escolha a quantidade indicada de perícias livres.";
  return null;
}

function entryModal(kind, entry = null) {
  const isItem = kind === "inventory";
  const currentEntry = entry || { id: uid(), name: "", description: "", duration: "", endRound: "", quantity: 1, weight: 0, equipped: false, active: true, effects: [] };
  modal(`
    <div class="modal-header"><h2>${entry ? "Editar" : "Adicionar"} ${isItem ? "item" : "condição"}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div>
    <form data-entry-form data-kind="${kind}" data-id="${currentEntry.id}"><div class="modal-body"><div class="form-grid"><label>Nome<input name="name" required value="${esc(currentEntry.name)}" /></label>${isItem ? `<label>Quantidade<input name="quantity" type="number" min="1" value="${number(currentEntry.quantity || 1)}" /></label><label>Peso<input name="weight" type="number" min="0" step="0.1" value="${number(currentEntry.weight || 0)}" /></label>` : `<label>Duração<input name="duration" value="${esc(currentEntry.duration || "")}" placeholder="Ex.: 2 rodadas" /></label><label>Deixa de afetar na rodada<input name="endRound" type="number" min="1" value="${esc(currentEntry.endRound || "")}" placeholder="Opcional" /></label>`}<label class="full">Descrição<textarea name="description">${esc(currentEntry.description)}</textarea></label></div><h3 style="margin-top:1rem;">Efeitos automáticos</h3><p class="panel-intro">Escolha o tipo e o alvo. “Dados” adiciona ou remove d20.</p><div data-effects>${(currentEntry.effects || []).map(effectFields).join("")}</div>${button("Adicionar efeito", "add-effect", { className: "ghost", data: { action: "add-effect" } })}</div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}<button class="button primary" type="submit">Salvar</button></div></form>`);
}

function effectFields(effect = {}) {
  const options = [
    ["attribute", "Atributo"], ["dice", "Dados (d20)"], ["skill", "Bônus de perícia"], ["testTotal", "Bônus no teste"], ["maxPv", "PV máximo"], ["maxPl", "PL máximo"], ["blockSkill", "Bloquear perícia"]
  ];
  return `<div class="effect-row"><select name="effectKind"><option value="">Tipo…</option>${options.map(([id, label]) => `<option value="${id}" ${effect.kind === id ? "selected" : ""}>${label}</option>`).join("")}</select><span class="effect-target-slot">${effectTargetField(effect.kind, effect.target)}</span><input name="effectValue" type="number" placeholder="Valor" value="${effect.value ?? ""}" /><button class="button danger" type="button" data-action="remove-effect">×</button></div>`;
}

function effectTargetField(kind, value = "") {
  if (kind === "attribute") return `<select name="effectTarget"><option value="">Atributo…</option>${ATTRIBUTES.map((attribute) => `<option value="${attribute}" ${value === attribute ? "selected" : ""}>${attribute}</option>`).join("")}</select>`;
  if (kind === "skill" || kind === "blockSkill") return `<select name="effectTarget"><option value="">Perícia…</option>${SKILLS.map((skill) => `<option value="${esc(skill.name)}" ${value === skill.name ? "selected" : ""}>${esc(skill.name)}</option>`).join("")}</select>`;
  return `<input name="effectTarget" type="hidden" value="" />`;
}

function combatItemModal(kind, item = null) {
  const isWeapon = kind === "weapon";
  const entry = item || (isWeapon ? { id: uid(), name: "", description: "", damage: "1d4", type: "curta", ammoDie: "d12", equipped: false, effects: [] } : { id: uid(), name: "", description: "", pdCurrent: 0, pdMax: 0, defense: 0, equipped: false, effects: [] });
  modal(`<div class="modal-header"><h2>${item ? "Editar" : "Adicionar"} ${isWeapon ? "arma" : "armadura"}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><form data-combat-form data-kind="${kind}" data-id="${entry.id}"><div class="modal-body"><div class="form-grid"><label>Nome<input name="name" required value="${esc(entry.name)}" /></label>${isWeapon ? `<label>Fórmula de dano<input name="damage" required value="${esc(entry.damage)}" placeholder="Ex.: 2d6" /></label><label>Tipo<select name="type"><option value="curta" ${entry.type === "curta" ? "selected" : ""}>Corpo a corpo · curta (Força)</option><option value="longa" ${entry.type === "longa" ? "selected" : ""}>Corpo a corpo · longa (Instinto)</option><option value="distancia" ${entry.type === "distancia" ? "selected" : ""}>Longo alcance (munição)</option></select></label><label class="ammo-field" ${entry.type === "distancia" ? "" : "hidden"}>Dado de munição<select name="ammoDie"><option value="d12" ${entry.ammoDie === "d12" ? "selected" : ""}>d12</option><option value="d10" ${entry.ammoDie === "d10" ? "selected" : ""}>d10</option><option value="d8" ${entry.ammoDie === "d8" ? "selected" : ""}>d8</option><option value="d6" ${entry.ammoDie === "d6" ? "selected" : ""}>d6</option><option value="d4" ${entry.ammoDie === "d4" ? "selected" : ""}>d4</option><option value="" ${!entry.ammoDie ? "selected" : ""}>Sem munição</option></select></label>` : `<label>PD máximo<input name="pdMax" type="number" min="1" required value="${number(entry.pdMax)}" /></label><label>PD atual<input name="pdCurrent" type="number" min="0" required value="${number(entry.pdCurrent)}" /></label><label>Defesa<input name="defense" type="number" min="0" value="${number(entry.defense)}" /></label>`}<label class="full">Descrição<textarea name="description">${esc(entry.description)}</textarea></label></div><h3 style="margin-top:1rem;">Efeitos automáticos</h3><div data-effects>${(entry.effects || []).map(effectFields).join("")}</div>${button("Adicionar efeito", "add-effect", { className: "ghost", data: { action: "add-effect" } })}</div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}<button class="button primary" type="submit">Salvar</button></div></form>`);
}

function ammoModal(weapon) {
  modal(`<div class="modal-header"><h2>Munição: ${esc(weapon.name)}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p><strong>Dado atual:</strong> ${weapon.ammoDie}</p><p>Após usar a arma, informe se a munição se manteve ou se foi degradada.</p></div><div class="modal-footer">${button(`Passou · mantém ${esc(weapon.ammoDie)}`, "ammo-pass", { className: "primary", data: { action: "ammo-pass", id: weapon.id } })}${button("Fracassou · reduz dado", "ammo-fail", { className: "danger", data: { action: "ammo-fail", id: weapon.id } })}</div>`);
}

function calculationRows(rows) {
  return `<div class="calculation-rows">${rows.map((row, index) => `<div class="calculation-row"><span>${esc(row.label)}</span><strong>${index === 0 ? row.value : signed(row.value)}</strong></div>`).join("")}</div>`;
}

function explainAttribute(attribute, backResource = "") {
  const result = attributeBreakdown(current, attribute);
  modal(`<div class="modal-header"><h2>Cálculo de ${esc(attribute)}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>${esc(ATTRIBUTE_INFO[attribute])}</p><p>Pontos-base + bônus de Sina e Marca + efeitos ativos.</p>${calculationRows(result.rows)}<div class="calculation-total"><span>Valor atual</span><strong>${result.total}</strong></div><p class="panel-intro" style="margin-top:1rem;">Itens desequipados e condições inativas não entram na conta.</p></div><div class="modal-footer">${backResource ? button("Voltar ao recurso", "explain-resource", { className: "ghost", data: { action: "explain-resource", resource: backResource } }) : ""}${button("Entendi", "close-modal", { className: "primary", data: { action: "close-modal" } })}</div>`);
}

function explainResource(resource) {
  const result = resourceBreakdown(current, resource);
  const formulas = current.mode === "free" && current.freeSettings?.resourceMode === "manual" ? null : RESOURCE_FORMULAS[current.sina]?.[resource];
  const attributes = resource === "pv" ? ["Força", "Instinto"] : ["Lucidez"];
  const substitute = (formula) => ATTRIBUTES.reduce((text, name) => text.replaceAll(name, `(${result.attributes[name]})`), formula);
  modal(`<div class="modal-header"><h2>Como calculamos ${resource.toUpperCase()}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body">${formulas ? `<p>Sina ${esc(current.sina)} · nível ${current.level}</p><div class="formula"><p><strong>No nível 1:</strong> ${esc(formulas[0])}</p><p>${esc(substitute(formulas[0]))} = ${result.rows[0].value}</p><p><strong>Ganho por nível:</strong> ${esc(formulas[1])}</p><p>São ${current.level - 1} nível(is) depois do primeiro.</p></div><div class="calculation-attributes">${attributes.map((name) => `<button class="button ghost" data-action="explain-attribute" data-attribute="${name}" data-back-resource="${resource}">${name}: ${result.attributes[name]}</button>`).join("")}</div>` : '<p>Na ficha livre, você define o máximo na seção de Atributos. Os efeitos ativos são somados a esse valor.</p>'}${calculationRows(result.rows)}<div class="calculation-total"><span>${resource.toUpperCase()} máximo</span><strong data-calculation-total>${result.total}</strong></div>${formulas ? '<p class="panel-intro" style="margin-top:1rem;">O cálculo usa os atributos atuais, incluindo seus efeitos ativos, para todos os níveis.</p>' : ""}<p class="panel-intro">Dano e gastos alteram o valor atual; esta conta explica o máximo.</p></div><div class="modal-footer">${button("Voltar a PV/PL", "resource-modal", { className: "ghost", data: { action: "resource-modal", resource } })}${button("Entendi", "close-modal", { className: "primary", data: { action: "close-modal" } })}</div>`);
}

function openRollModal(skill) {
  const blocked = isSkillBlocked(current, skill);
  modal(`<div class="modal-header"><h2>Teste de ${esc(skill)}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>O Mestre escolhe qual atributo é usado neste momento.</p><label>Atributo<select data-roll-attribute data-skill="${esc(skill)}">${ATTRIBUTES.map((attribute) => `<option value="${attribute}">${attribute} (${getAttributeValue(current, attribute)})</option>`).join("")}</select></label><div id="roll-formula" class="roll-result">A fórmula acompanha o atributo escolhido.</div><label style="margin-top:1rem;">Resultado escolhido no dado físico<input data-roll-result type="number" min="1" max="20" placeholder="Maior ou menor d20 obtido" /></label><div class="button-row" style="margin-top:1rem;">${button("Calcular total", "roll-total", { className: "primary", data: { action: "roll-total", skill } })}</div>${blocked ? "<p class=\"warning\">Esta perícia está bloqueada por um efeito ativo.</p>" : ""}</div>`);
  updateRollFormula(skill);
}

function updateRollFormula(skill, total = null) {
  const attribute = document.querySelector("[data-roll-attribute]")?.value || ATTRIBUTES[0];
  const result = testFormula(current, skill, attribute);
  const target = document.querySelector("#roll-formula");
  if (!target) return;
  if (result.forbidden) { target.className = "roll-result error"; target.textContent = result.text; return; }
  const expanded = target.querySelector("details")?.open || false;
  const effects = effectSources(current);
  const applies = (effect) => !effect.target || effect.target === skill || effect.target === "Todos";
  const diceEffects = effects.filter((effect) => effect.kind === "dice" && applies(effect));
  const rows = [{ label: `Treinamento: ${TRAINING.find((entry) => entry.id === current.skills[skill])?.label || "Inexperiente"}`, value: trainingBonus(current.skills[skill]) },
    ...effects.filter((effect) => (effect.kind === "skill" && effect.target === skill) || (effect.kind === "testTotal" && applies(effect))).map((effect) => ({ label: effect.source, value: number(effect.value) }))];
  if (result.technicalPenalty) rows.push({ label: "Perícia técnica sem treinamento", value: result.technicalPenalty });
  target.className = "roll-result";
  target.innerHTML = `<strong>${result.dice}d20 · use o ${result.pick} resultado</strong><p>Bônus final: <strong>${signed(result.totalBonus)}</strong></p><details class="fold nested" ${expanded ? "open" : ""}><summary>Entender este teste</summary><div class="fold-body"><p>${attribute}: ${result.attributeValue}. ${result.attributeValue > 0 ? "O atributo define a quantidade inicial de d20; use o maior." : "Com atributo 0, a base é 2d20; use o menor."}</p>${diceEffects.length ? `<p>Efeitos na quantidade de dados:</p>${calculationRows(diceEffects.map((effect) => ({ label: effect.source, value: number(effect.value) })))}` : ""}<p>Quantidade final: ${result.dice} d20 (mínimo de 1).</p>${calculationRows(rows)}<p><strong>Bônus somado ao dado físico: ${signed(result.totalBonus)}</strong></p></div></details>${total !== null ? `<div class="calculation-total"><span>Resultado final</span><strong>${total}</strong></div>` : ""}`;
}

function abilityOptions(ability) {
  return ability.costOptions || [{ label: "Uso padrão", cost: Number(ability.cost) }];
}

function useAbility(ability, onUse) {
  const options = abilityOptions(ability);
  const vision = onUse.startsWith("vision:");
  modal(`<div class="modal-header"><h2>${esc(ability.name)}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>${esc(ability.description)}</p>${abilityDetails(ability)}<div class="ability-payment">${options.length > 1 ? `<label>Modalidade<select data-ability-option>${options.map((option, index) => `<option value="${index}">${esc(option.label)} · ${option.cost} PL</option>`).join("")}</select></label>` : `<p><strong>Custo:</strong> ${esc(ability.cost)} PL</p>`}${vision && ability.name !== "Domínio Soberano" ? '<label class="check-line"><input type="checkbox" data-domain-discount /> Estou na área de Domínio Soberano (25% de desconto).</label>' : ""}${ability.name === "Oferenda" ? `<label>PV a sacrificar e curar no aliado<input type="number" data-offering min="1" max="${Math.min(20, current.resources.pvCurrent - 1)}" value="1" /></label><p class="panel-intro">Você conserva pelo menos 1 PV. O aliado aplica a cura na própria ficha.</p>` : ""}<p data-ability-payment aria-live="polite"></p><p class="warning" data-ability-warning hidden></p><p class="panel-intro">Este botão desconta os custos. Role os dados físicos e acompanhe alvos, resistência, duração e limites por rodada ou cena na mesa.</p></div></div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}${button("Confirmar uso", "confirm-ability", { className: "primary", data: { action: "confirm-ability", callback: onUse } })}</div>`);
  updateAbilityPayment();
}

function makeAbilityCallback(kind, id = "") { return `${kind}:${id}`; }

function abilityPayment() {
  const callback = document.querySelector('[data-action="confirm-ability"]')?.dataset.callback || "";
  const [kind, id] = callback.split(":");
  const ability = kind === "mark" ? MARKS[current.mark]?.active : byId(current.visionAbilities, id);
  if (!ability) return { error: "Habilidade indisponível." };
  const option = abilityOptions(ability)[number(document.querySelector("[data-ability-option]")?.value)];
  const baseCost = option?.cost;
  const discount = kind === "vision" && ability.name !== "Domínio Soberano" && document.querySelector("[data-domain-discount]")?.checked ? Math.floor(baseCost * .25) : 0;
  const cost = Math.max(1, baseCost - discount);
  const sacrifice = ability.name === "Oferenda" ? number(document.querySelector("[data-offering]")?.value) : 0;
  let error = "";
  if (current.death.permanent || (current.death.active && ability.name !== "Sorte Forjada")) error = "Esta habilidade não pode ser usada no estado de morte.";
  else if (!Number.isFinite(baseCost) || baseCost < 0) error = "Esta habilidade antiga precisa de um custo válido.";
  else if (current.resources.plCurrent < cost) error = "PL insuficiente para esta modalidade.";
  else if (ability.name === "Oferenda" && (!Number.isInteger(sacrifice) || sacrifice < 1 || sacrifice > 20 || sacrifice >= current.resources.pvCurrent)) error = "Sacrifique de 1 a 20 PV e conserve pelo menos 1 PV.";
  return { ability, cost, discount, sacrifice, error };
}

function updateAbilityPayment() {
  const result = abilityPayment();
  const button = document.querySelector('[data-action="confirm-ability"]');
  if (!button) return;
  button.disabled = Boolean(result.error);
  document.querySelector("[data-ability-payment]").textContent = Number.isFinite(result.cost) ? `Pagar ${result.cost} PL${result.discount ? ` (desconto de ${result.discount} PL)` : ""}${result.sacrifice ? ` + ${result.sacrifice} PV` : ""}. PL disponível: ${current.resources.plCurrent}.` : "";
  const warning = document.querySelector("[data-ability-warning]");
  warning.hidden = !result.error;
  warning.textContent = result.error;
}

function handleAbilityCallback() {
  const result = abilityPayment();
  if (result.error) { toast(result.error, "error"); return; }
  current.resources.plCurrent -= result.cost;
  current.resources.pvCurrent -= result.sacrifice;
  persist(); closeModal(); renderSheet();
  toast(`${result.ability.name}: ${result.cost} PL${result.sacrifice ? ` e ${result.sacrifice} PV` : ""} consumidos.`);
}

function resourceModal(resource) {
  const isPv = resource === "pv";
  modal(`<div class="modal-header"><h2>${isPv ? "PV: dano ou cura" : "PL: gastar ou recuperar"}</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><div class="explain-link">${button("Como o máximo é calculado?", "explain-resource", { className: "ghost", data: { action: "explain-resource", resource } })}</div><label>Valor<input data-resource-value type="number" min="1" value="1" /></label>${isPv && equippedArmor() ? `<label class="check-line"><input type="checkbox" data-ignore-armor /> Ignorar armadura (não reduz PD nem aplica Defesa)</label><p class="panel-intro">Armadura: ${esc(equippedArmor().name)} · ${equippedArmor().pdCurrent}/${equippedArmor().pdMax} PD · Defesa ${equippedArmor().defense}</p>` : ""}</div><div class="modal-footer">${button(isPv ? "Aplicar dano" : "Gastar PL", "apply-resource", { className: "danger bordered-action", data: { action: "apply-resource", resource, operation: "loss" } })}${button(isPv ? "Aplicar cura" : "Recuperar PL", "apply-resource", { className: "primary bordered-action", data: { action: "apply-resource", resource, operation: "gain" } })}</div>`);
}

function applyResource(resource, operation) {
  const value = Math.max(0, number(document.querySelector("[data-resource-value]")?.value));
  if (!value) { toast("Informe um valor maior que zero.", "error"); return; }
  const max = getMaxResources(current);
  if (resource === "pl") current.resources.plCurrent = operation === "gain" ? Math.min(max.pl, current.resources.plCurrent + value) : Math.max(0, current.resources.plCurrent - value);
  if (resource === "pv") {
    if (operation === "gain") current.resources.pvCurrent = Math.min(max.pv, current.resources.pvCurrent + value);
    else {
      const armor = document.querySelector("[data-ignore-armor]")?.checked ? null : equippedArmor();
      let hpDamage = value;
      if (armor) {
        armor.pdCurrent = Math.max(0, armor.pdCurrent - value);
        hpDamage = Math.max(0, value - number(armor.defense));
        if (armor.pdCurrent === 0) {
          current.combat.armors = current.combat.armors.filter((item) => item.id !== armor.id);
          toast(`${armor.name} quebrou e foi removida da ficha.`, "error");
        }
      }
      current.resources.pvCurrent = Math.max(0, current.resources.pvCurrent - hpDamage);
    }
  }
  persist(); closeModal(); renderSheet();
}

function confirmLevelUp() {
  const getsAttribute = [3, 5, 7, 10, 15, 18].includes(current.level + 1);
  modal(`<div class="modal-header"><h2>Subir para nível ${current.level + 1}?</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>O personagem receberá 1 Ponto de Habilidade${getsAttribute ? " e 1 Ponto de Atributo" : ""}. PV e PL máximos serão recalculados.</p></div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}${button("Confirmar", "level-up", { className: "primary", data: { action: "level-up" } })}</div>`);
}

function freeOriginChoices(kind, name, selected = {}) {
  const source = (kind === "sina" ? SINAS : MARKS)[name];
  if (!source) return "";
  return `<p class="panel-intro">${esc(source.description || source.passive)}</p>${source.choices.map((choice) => `<label class="choice-field">${esc(choice.label)}<select name="${kind}-${choice.id}" required><option value="">Escolha…</option>${choice.options.map((option) => `<option value="${esc(option)}" ${selected[choice.id] === option ? "selected" : ""}>${esc(option)}</option>`).join("")}</select></label>`).join("")}`;
}

function freeEditor() {
  if (current.mode !== "free") return;
  const fixed = getFixedSkills(current);
  const settings = current.freeSettings;
  modal(`<div class="modal-header"><h2>Editar ficha livre</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><form data-free-form><div class="modal-body"><p class="panel-intro">Edite diretamente, sem gastar pontos ou seguir etapas. Os bônus de Sina, Marca, itens e condições continuam entrando nos cálculos.</p>
    <div class="form-grid"><label>Sina<select name="sina" data-free-origin="sina"><option value="">Sem Sina</option>${Object.keys(SINAS).map((name) => `<option ${current.sina === name ? "selected" : ""}>${esc(name)}</option>`).join("")}</select></label><label>Marca<select name="mark" data-free-origin="mark"><option value="">Sem Marca</option>${Object.keys(MARKS).map((name) => `<option ${current.mark === name ? "selected" : ""}>${esc(name)}</option>`).join("")}</select></label><div data-free-choices="sina">${freeOriginChoices("sina", current.sina, current.choices.sina)}</div><div data-free-choices="mark">${freeOriginChoices("mark", current.mark, current.choices.mark)}</div></div>
    <details class="fold" open><summary>Nível e pontos</summary><div class="fold-body form-grid">${[["level", "Nível", 1, 20], ["abilityPoints", "Pontos de Habilidade", 0, ""], ["attributePoints", "Pontos de Atributo", 0, ""]].map(([key, label, min, max]) => `<label>${label}<input type="number" name="${key}" min="${min}" ${max ? `max="${max}"` : ""} step="1" required value="${current[key]}" /></label>`).join("")}</div></details>
    <details class="fold" open><summary>Atributos-base</summary><div class="fold-body"><p class="panel-intro">Sina e Marca são somadas a estes valores. Não há limite de distribuição na ficha livre.</p><div class="form-grid">${ATTRIBUTES.map((name) => `<label>${name}<input type="number" name="base-${name}" step="1" required value="${current.baseAttributes[name]}" /></label>`).join("")}</div></div></details>
    <details class="fold" open><summary>PV e PL</summary><div class="fold-body"><label>Como definir os máximos<select name="resourceMode"><option value="manual" ${settings.resourceMode === "manual" ? "selected" : ""}>Definir manualmente</option><option value="sina" ${settings.resourceMode === "sina" ? "selected" : ""}>Calcular pela Sina</option></select></label><p class="panel-intro">Sem Sina, os máximos manuais são usados. Efeitos ativos podem modificar os máximos. Salvar com 0 PV ativa o estado de morte.</p><div class="form-grid">${[["freePvMax", "PV máximo manual"], ["freePlMax", "PL máximo manual"], ["pvCurrent", "PV atual"], ["plCurrent", "PL atual"]].map(([key, label]) => `<label>${label}<input type="number" name="${key}" min="${key === "freePvMax" ? 1 : 0}" step="1" required value="${current.resources[key]}" /></label>`).join("")}</div></div></details>
    <details class="fold"><summary>Treinamentos de todas as perícias</summary><div class="fold-body"><p class="panel-intro">Automático usa os treinos da Sina e da Marca escolhidas. Escolha um grau para substituí-lo, inclusive Inexperiente.</p><div class="form-grid">${SKILLS.map(({ name }) => {
      const own = settings.skillOverrides[name] ?? ((!fixed.includes(name) || current.freeSkillsChosen.includes(name) || current.skills[name] === "habilidoso") && current.skills[name] !== "inexperiente" ? current.skills[name] : "auto");
      return `<label>${esc(name)}<select name="skill-${esc(name)}"><option value="auto" ${own === "auto" ? "selected" : ""}>Automático pela Sina/Marca</option>${TRAINING.map((training) => `<option value="${training.id}" ${own === training.id ? "selected" : ""}>${training.label} +${training.bonus}</option>`).join("")}</select></label>`;
    }).join("")}</div></div></details></div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}<button class="button primary" type="submit">Salvar alterações</button></div></form>`);
}

function saveFreeEditor(form) {
  if (current.mode !== "free") return;
  const data = new FormData(form);
  const next = structuredClone(current);
  next.sina = data.get("sina") || null;
  next.mark = data.get("mark") || null;
  next.choices = { sina: {}, mark: {} };
  for (const kind of ["sina", "mark"]) {
    const source = (kind === "sina" ? SINAS : MARKS)[next[kind]];
    source?.choices.forEach((choice) => { next.choices[kind][choice.id] = data.get(`${kind}-${choice.id}`); });
  }
  for (const key of ["level", "abilityPoints", "attributePoints"]) next[key] = number(data.get(key));
  ATTRIBUTES.forEach((name) => { next.baseAttributes[name] = number(data.get(`base-${name}`)); });
  for (const key of ["freePvMax", "freePlMax", "pvCurrent", "plCurrent"]) next.resources[key] = number(data.get(key));
  next.freeSettings = { resourceMode: data.get("resourceMode"), skillOverrides: {} };
  next.skills = emptySkills();
  applyGrantedSkills(next);
  SKILLS.forEach(({ name }) => {
    const value = data.get(`skill-${name}`);
    if (TRAINING.some((training) => training.id === value)) {
      next.freeSettings.skillOverrides[name] = value;
      next.skills[name] = value;
    }
  });
  next.freeSkillsChosen = next.freeSkillsChosen.filter((name) => next.skills[name] !== "inexperiente");
  current = next;
  persist(); closeModal(); renderSheet(); toast("Ficha livre atualizada.");
}

function createFreeCharacter() {
  current = newCharacter("free");
  current.resources = { pvCurrent: 10, plCurrent: 10, freePvMax: 10, freePlMax: 10 };
  persist(); activeTab = "perfil"; renderSheet({ resetPageScroll: true });
}

document.addEventListener("click", (event) => {
  const tab = event.target.closest("[data-tab]");
  if (tab && current && !current.death.active && !current.death.permanent) {
    activeTab = tab.dataset.tab;
    renderSheet({ resetPageScroll: true });
    return;
  }
  const element = event.target.closest("[data-action]");
  if (!element) return;
  const { action } = element.dataset;
  if (element.disabled) return;
  if (action === "toggle-theme") { applyTheme(document.documentElement.dataset.theme === "light" ? "dark" : "light"); return; }
  if (action === "close-modal") { if (event.target === element || element.classList.contains("close") || element.classList.contains("button")) closeModal(); return; }
  if (action === "start-guided") { openWizard(); return; }
  if (action === "start-free") { createFreeCharacter(); return; }
  if (action === "open-load") { openLoadModal(); return; }
  if (action === "home") { closeModal(); renderWelcome(); return; }
  if (action === "cancel-wizard") { closeModal(); wizard = null; return; }
  if (action === "wizard-sina") { wizard.character.sina = element.dataset.sina; wizard.character.choices.sina = {}; renderWizard(); return; }
  if (action === "wizard-mark") { wizard.character.mark = element.dataset.mark; wizard.character.choices.mark = {}; renderWizard(); return; }
  if (action === "wizard-attribute") { const attribute = element.dataset.attribute; const change = number(element.dataset.change); const next = number(wizard.character.baseAttributes[attribute]) + change; if (next >= 0) wizard.character.baseAttributes[attribute] = next; syncAttributes(wizard.character); renderWizard(); return; }
  if (action === "wizard-free-skill") { const skill = element.dataset.skill; const list = wizard.character.freeSkillsChosen; const index = list.indexOf(skill); if (index >= 0) list.splice(index, 1); else if (list.length < freeSkillLimit(wizard.character)) list.push(skill); else toast("Você já escolheu todas as perícias livres.", "error"); renderWizard(); return; }
  if (action === "wizard-next") { const error = validateWizardStep(); if (error) { toast(error, "error"); return; } wizard.step += 1; renderWizard({ resetScroll: true }); return; }
  if (action === "wizard-back") { saveWizardText(); if (wizard.step === 3 || wizard.step === 5) saveWizardChoices(); wizard.step -= 1; renderWizard({ resetScroll: true }); return; }
  if (action === "finish-wizard") {
    const error = validateWizardStep(); if (error) { toast(error, "error"); return; }
    current = wizard.character; syncAttributes(current); applyGrantedSkills(current); current.freeSkillsChosen.forEach((skill) => { current.skills[skill] = "experiente"; });
    const max = getMaxResources(current); current.resources.pvCurrent = max.pv; current.resources.plCurrent = max.pl;
    persist(); wizard = null; closeModal(); activeTab = "perfil"; renderSheet({ resetPageScroll: true }); toast("Personagem criado e salvo neste navegador."); return;
  }
  if (action === "load-character") { const character = getCharacters().find((item) => item.id === element.dataset.id); if (character) { current = normalizeCharacter(character); persist(); activeTab = "perfil"; closeModal(); renderSheet({ resetPageScroll: true }); } return; }
  if (action === "delete-saved") { const character = getCharacters().find((item) => item.id === element.dataset.id); if (character) confirmDeleteCharacter(character); return; }
  if (action === "confirm-delete-saved") { deleteCharacter(element.dataset.id); openLoadModal(); toast("Personagem removido deste navegador."); return; }
  if (!current) return;
  if (action === "free-editor" && !current.death.active && !current.death.permanent) { freeEditor(); return; }
  if (action === "sheet-menu") { sheetMenu(); return; }
  if (action === "explain-attribute") { explainAttribute(element.dataset.attribute, element.dataset.backResource); return; }
  if (action === "explain-resource") { explainResource(element.dataset.resource); return; }
  if (action === "export") { current.meta = { ...current.meta, lastExportAt: new Date().toISOString() }; persist(); exportCharacter(current); closeModal(); renderSheet(); return; }
  if (action === "dismiss-backup") { dismissedBackupNotices.add(current.id); renderSheet(); return; }
  if (action === "note-modal") { noteModal(element.dataset.id); return; }
  if (action === "delete-note") { current.notes = current.notes.filter((note) => note.id !== element.dataset.id); persist(); renderSheet(); toast("Anotação removida."); return; }
  if (action === "remove-gallery-photo") { current.identity.gallery.splice(Number(element.dataset.index), 1); persist(); renderSheet(); return; }
  if (action === "print") { window.print(); return; }
  if (action === "confirm-level-up") { confirmLevelUp(); return; }
  if (action === "level-up") { const before = getMaxResources(current); const result = levelUp(current); if (result.ok) { const after = getMaxResources(current); current.resources.pvCurrent += after.pv - before.pv; current.resources.plCurrent += after.pl - before.pl; } persist(); closeModal(); renderSheet(); toast(result.message, result.ok ? "success" : "error"); return; }
  if (action === "resource-modal" && !current.death.active && !current.death.permanent) { resourceModal(element.dataset.resource); return; }
  if (action === "apply-resource") { applyResource(element.dataset.resource, element.dataset.operation); return; }
  if (action === "add-attribute") { const attribute = element.dataset.attribute; const max = current.level === 1 ? 4 : 5; if (current.attributePoints && getAttributeValue(current, attribute) < max) { current.baseAttributes[attribute] += 1; current.attributePoints -= 1; persist(); renderSheet(); } return; }
  if (action === "upgrade-skill") { const result = upgradeSkill(current, element.dataset.skill); if (result.ok && current.mode === "free") current.freeSettings.skillOverrides[element.dataset.skill] = current.skills[element.dataset.skill]; persist(); renderSheet(); toast(result.message, result.ok ? "success" : "error"); return; }
  if (action === "roll") { openRollModal(element.dataset.skill); return; }
  if (action === "roll-total") { const raw = document.querySelector("[data-roll-result]")?.value; const attribute = document.querySelector("[data-roll-attribute]")?.value; if (!raw) { toast("Informe o resultado escolhido no d20.", "error"); return; } const formula = testFormula(current, element.dataset.skill, attribute); if (formula.forbidden) { updateRollFormula(element.dataset.skill); return; } updateRollFormula(element.dataset.skill, number(raw) + formula.totalBonus); return; }
  if (action === "new-entry") { entryModal(element.dataset.kind); return; }
  if (action === "edit-entry") { entryModal(element.dataset.kind, byId(current[element.dataset.kind], element.dataset.id)); return; }
  if (action === "toggle-entry") { const entry = byId(current[element.dataset.kind], element.dataset.id); if (element.dataset.kind === "inventory") entry.equipped = !entry.equipped; else entry.active = !entry.active; persist(); renderSheet(); return; }
  if (action === "delete-entry") { current[element.dataset.kind] = current[element.dataset.kind].filter((entry) => entry.id !== element.dataset.id); persist(); renderSheet(); return; }
  if (action === "add-effect") { document.querySelector("[data-effects]").insertAdjacentHTML("beforeend", effectFields()); return; }
  if (action === "remove-effect") { element.closest(".effect-row").remove(); return; }
  if (action === "add-vision") { const ability = getVisionCatalog().find((item) => item.name === element.dataset.name); if (current.visionAbilities.filter((ability) => !ability.legacy).length >= visionAbilityLimit()) { toast("Sua Sina ainda não liberou outra Habilidade de Visão neste nível.", "error"); return; } if (!current.visionAbilities.some((item) => item.name === ability.name)) { current.visionAbilities.push({ ...ability, id: uid() }); persist(); renderSheet(); toast(`${ability.name} foi adicionada à ficha.`); } else toast("Esta habilidade já está na ficha.", "error"); return; }
  if (action === "remove-vision" && (current.mode === "free" || byId(current.visionAbilities, element.dataset.id)?.legacy)) { current.visionAbilities = current.visionAbilities.filter((ability) => ability.id !== element.dataset.id); persist(); renderSheet(); return; }
  if (action === "use-mark") { const ability = MARKS[current.mark]?.active; if (ability) useAbility(ability, makeAbilityCallback("mark")); return; }
  if (action === "use-vision") { const ability = byId(current.visionAbilities, element.dataset.id); if (ability) useAbility(ability, makeAbilityCallback("vision", ability.id)); return; }
  if (action === "confirm-ability") { handleAbilityCallback(element.dataset.callback); return; }
  if (action === "combat-round") { current.combat.round = Math.max(0, current.combat.round + number(element.dataset.change)); current.conditions.forEach((condition) => { if (condition.active && condition.endRound !== "" && condition.endRound !== undefined && number(condition.endRound) <= current.combat.round) condition.active = false; }); persist(); renderSheet(); return; }
  if (action === "combat-reset-round") { current.combat.round = 0; persist(); renderSheet(); return; }
  if (action === "weapon-modal") { combatItemModal("weapon", element.dataset.id ? byId(current.combat.weapons, element.dataset.id) : null); return; }
  if (action === "armor-modal") { combatItemModal("armor", element.dataset.id ? byId(current.combat.armors, element.dataset.id) : null); return; }
  if (action === "equip-combat") { const items = element.dataset.kind === "weapon" ? current.combat.weapons : current.combat.armors; const entry = byId(items, element.dataset.id); const next = !entry.equipped; items.forEach((item) => { item.equipped = false; }); entry.equipped = next; persist(); renderSheet(); return; }
  if (action === "delete-combat") { const property = element.dataset.kind === "weapon" ? "weapons" : "armors"; current.combat[property] = current.combat[property].filter((item) => item.id !== element.dataset.id); persist(); renderSheet(); return; }
  if (action === "ammo-modal") { const weapon = byId(current.combat.weapons, element.dataset.id); if (weapon?.ammoDie) ammoModal(weapon); return; }
  if (action === "ammo-pass") { closeModal(); toast("Munição mantida."); return; }
  if (action === "ammo-fail") { const weapon = byId(current.combat.weapons, element.dataset.id); const next = { d12: "d10", d10: "d8", d8: "d6", d6: "d4", d4: null }; weapon.ammoDie = next[weapon.ammoDie]; persist(); closeModal(); renderSheet(); toast(weapon.ammoDie ? `Munição reduzida para ${weapon.ammoDie}.` : "A munição foi esgotada.", weapon.ammoDie ? "success" : "error"); return; }
  if (action === "death-pass") { toast(`Passou: o Dado de Morte permanece ${current.death.die}.`); persist(); renderSheet(); return; }
  if (action === "death-fail") { if (current.death.die === "d8") current.death.die = "d6"; else if (current.death.die === "d6") current.death.die = "d4"; else { current.deathSnapshot = structuredClone({ ...current, deathSnapshot: null }); current.death.permanent = true; } toast(current.death.permanent ? "O d4 falhou: morte permanente." : `Fracasso: o Dado de Morte agora é ${current.death.die}.`, current.death.permanent ? "error" : "success"); persist(); renderSheet(); return; }
  if (action === "undo-death" && current.death.permanent && current.deathSnapshot) {
    modal(`<div class="modal-header"><h2>Desfazer morte</h2><button class="close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body"><p>Isso restaura a ficha para antes do último fracasso. Continuar?</p></div><div class="modal-footer">${button("Cancelar", "close-modal", { className: "ghost", data: { action: "close-modal" } })}${button("Confirmar", "confirm-undo-death", { className: "primary", data: { action: "confirm-undo-death" } })}</div>`);
    return;
  }
  if (action === "confirm-undo-death" && current.death.permanent && current.deathSnapshot) {
    current = normalizeCharacter(current.deathSnapshot);
    current.deathSnapshot = null;
    persist(); closeModal(); renderSheet(); toast("Morte desfeita. Role novamente o d4 físico."); return;
  }
  if (action === "stabilize") { current.resources.pvCurrent = 1; current.death.active = false; current.death.die = "d8"; persist(); renderSheet(); toast("Personagem estabilizado com 1 PV."); return; }
});

document.addEventListener("input", (event) => {
  if (!current) return;
  if (event.target.matches("[data-offering]")) { updateAbilityPayment(); return; }
  if (event.target.matches("[data-skill-search]")) { skillQuery = event.target.value; filterSkills(); return; }
  if (event.target.matches("[data-identity]")) { current.identity[event.target.dataset.identity] = event.target.value; persist(); return; }
  if (event.target.matches("[data-resource]")) { current.resources[event.target.dataset.resource] = Math.max(0, number(event.target.value)); persist(); document.querySelectorAll(".resource-cards").forEach((cards) => { cards.outerHTML = resourceCards(); }); if (current.death.active || current.death.permanent) renderSheet(); return; }
  if (event.target.matches("[data-combat-notes]")) { current.combat.notes = event.target.value; persist(); return; }
});

function filterVision() {
  const cards = [...document.querySelectorAll(".catalog-card")];
  cards.forEach((card) => { card.hidden = !searchText(card.dataset.search).includes(searchText(visionQuery)); });
  document.querySelectorAll(".catalog-group").forEach((group) => { group.hidden = ![...group.querySelectorAll(".catalog-card")].some((card) => !card.hidden); });
  const empty = document.querySelector("[data-vision-empty]");
  if (empty) empty.hidden = cards.some((card) => !card.hidden);
}
document.addEventListener("input", (event) => {
  if (!event.target.matches("[data-vision-search]")) return;
  visionQuery = event.target.value; filterVision();
});

document.addEventListener("change", async (event) => {
  if (event.target.matches("[data-free-origin]")) { const kind = event.target.dataset.freeOrigin; document.querySelector(`[data-free-choices="${kind}"]`).innerHTML = freeOriginChoices(kind, event.target.value, current[kind] === event.target.value ? current.choices[kind] : {}); return; }
  if (event.target.matches("[data-ability-option], [data-domain-discount]")) { updateAbilityPayment(); return; }
  if (event.target.matches("[data-combat-form][data-kind='weapon'] [name='type']")) { event.target.closest("form").querySelector(".ammo-field").hidden = event.target.value !== "distancia"; return; }
  if (event.target.matches("[name='effectKind']")) { const row = event.target.closest(".effect-row"); row.querySelector(".effect-target-slot").innerHTML = effectTargetField(event.target.value); return; }
  if (event.target.matches("[data-gallery-photo]") && current) { const file = event.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { current.identity.gallery.push(reader.result); persist(); renderSheet(); }; reader.readAsDataURL(file); return; }
  if (event.target.matches("[data-photo]") && current) { const file = event.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { current.identity.photo = reader.result; persist(); renderSheet(); }; reader.readAsDataURL(file); return; }
  if (event.target.matches("[data-import-file]")) { const file = event.target.files?.[0]; if (!file) return; try { current = normalizeCharacter(await readCharacterFile(file)); current.id = current.id || uid(); persist(); activeTab = "perfil"; closeModal(); renderSheet({ resetPageScroll: true }); toast("Ficha importada e salva neste navegador."); } catch { toast("Não foi possível ler este arquivo de ficha.", "error"); } return; }
  if (event.target.matches("[data-roll-attribute]")) updateRollFormula(event.target.dataset.skill);
});

document.addEventListener("submit", (event) => {
  if (!event.target.matches("[data-entry-form]")) return;
  event.preventDefault();
  const form = event.target;
  const kind = form.dataset.kind;
  const id = form.dataset.id;
  const data = new FormData(form);
  const effects = [...form.querySelectorAll(".effect-row")].map((row) => ({ kind: row.querySelector("[name='effectKind']").value, target: row.querySelector("[name='effectTarget']").value.trim(), value: number(row.querySelector("[name='effectValue']").value) })).filter((effect) => effect.kind);
  const entry = {
    id, name: data.get("name").trim(), description: data.get("description").trim(), effects,
    ...(kind === "inventory" ? { quantity: number(data.get("quantity")) || 1, weight: number(data.get("weight")), equipped: byId(current.inventory, id)?.equipped || false } : { duration: data.get("duration").trim(), endRound: data.get("endRound") === "" ? "" : number(data.get("endRound")), active: byId(current.conditions, id)?.active ?? true })
  };
  const entries = current[kind];
  const index = entries.findIndex((item) => item.id === id);
  if (index >= 0) entries[index] = entry; else entries.push(entry);
  persist(); closeModal(); renderSheet(); toast(`${kind === "inventory" ? "Item" : "Condição"} salva.`);
});

document.addEventListener("submit", (event) => {
  if (!event.target.matches("[data-note-form]")) return;
  event.preventDefault();
  const form = event.target;
  const data = new FormData(form);
  const id = form.dataset.id;
  const entry = { id, title: data.get("title").trim(), text: data.get("text").trim(), createdAt: form.dataset.created };
  const index = current.notes.findIndex((note) => note.id === id);
  if (index >= 0) current.notes[index] = entry; else current.notes.push(entry);
  persist(); closeModal(); renderSheet(); toast("Anotação salva.");
});

document.addEventListener("submit", (event) => {
  if (!event.target.matches("[data-combat-form]")) return;
  event.preventDefault();
  const form = event.target;
  const kind = form.dataset.kind;
  const id = form.dataset.id;
  const data = new FormData(form);
  const effects = [...form.querySelectorAll(".effect-row")].map((row) => ({ kind: row.querySelector("[name='effectKind']").value, target: row.querySelector("[name='effectTarget']").value, value: number(row.querySelector("[name='effectValue']").value) })).filter((effect) => effect.kind);
  const entries = kind === "weapon" ? current.combat.weapons : current.combat.armors;
  const previous = byId(entries, id);
  const entry = kind === "weapon"
    ? { id, name: data.get("name").trim(), description: data.get("description").trim(), damage: data.get("damage").trim(), type: data.get("type"), ammoDie: data.get("type") === "distancia" ? data.get("ammoDie") : null, equipped: previous?.equipped || false, effects }
    : { id, name: data.get("name").trim(), description: data.get("description").trim(), pdMax: number(data.get("pdMax")), pdCurrent: Math.min(number(data.get("pdCurrent")), number(data.get("pdMax"))), defense: number(data.get("defense")), equipped: previous?.equipped || false, effects };
  const index = entries.findIndex((item) => item.id === id);
  if (index >= 0) entries[index] = entry; else entries.push(entry);
  persist(); closeModal(); renderSheet(); toast(`${kind === "weapon" ? "Arma" : "Armadura"} salva.`);
});

document.addEventListener("submit", (event) => {
  if (!event.target.matches("[data-free-form]")) return;
  event.preventDefault();
  saveFreeEditor(event.target);
});

if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
renderWelcome();
