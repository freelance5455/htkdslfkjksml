// Explicações de leitura: os resultados vêm das regras originais, sem alterar a ficha.
import { ATTRIBUTES, SINAS, MARKS } from "./data.js";
import { getAttributeValue, getMaxResources } from "./rules.js";

export function effectSources(character) {
  const groups = [
    [character.inventory.filter((entry) => entry.equipped), "Item"],
    [character.conditions.filter((entry) => entry.active), "Condição"],
    [(character.combat?.weapons || []).filter((entry) => entry.equipped), "Arma"],
    [(character.combat?.armors || []).filter((entry) => entry.equipped), "Armadura"]
  ];
  return groups.flatMap(([entries, type]) => entries.flatMap((entry) => (entry.effects || []).map((effect) => ({ ...effect, source: `${type}: ${entry.name || "Sem nome"}` }))));
}

export function attributeBreakdown(character, attribute) {
  const rows = [{ label: "Pontos-base (criação e evolução)", value: Number(character.baseAttributes[attribute] || 0) }];
  for (const [key, catalog, label] of [["sina", SINAS, "Sina"], ["mark", MARKS, "Marca"]]) {
    const source = catalog[character[key]];
    if (!source) continue;
    if (source.bonuses[attribute]) rows.push({ label: `${label}: ${character[key]}`, value: source.bonuses[attribute] });
    source.choices.filter((choice) => choice.type === "attributeBonus" && character.choices[key][choice.id] === attribute)
      .forEach(() => rows.push({ label: `Escolha da ${label}: ${character[key]}`, value: 1 }));
  }
  effectSources(character).filter((effect) => effect.kind === "attribute" && effect.target === attribute)
    .forEach((effect) => rows.push({ label: effect.source, value: Number(effect.value || 0) }));
  return { rows, total: getAttributeValue(character, attribute) };
}

export function resourceBreakdown(character, resource) {
  const attributes = Object.fromEntries(ATTRIBUTES.map((name) => [name, getAttributeValue(character, name)]));
  const rows = [];
  const sina = character.mode === "free" && character.freeSettings?.resourceMode === "manual" ? null : SINAS[character.sina];
  if (sina) {
    // Nível 1 e ganho por nível usam a própria função de cálculo da Sina.
    const initial = sina.calculate({ level: 1, attributes })[resource];
    const growth = sina.calculate({ level: 2, attributes })[resource] - initial;
    rows.push({ label: `Valor no nível 1 · ${character.sina}`, value: initial });
    rows.push({ label: `Evolução: (${character.level} − 1) × ${growth}`, value: (character.level - 1) * growth });
  } else {
    rows.push({ label: "Máximo definido manualmente", value: Number(character.resources[resource === "pv" ? "freePvMax" : "freePlMax"] || 0) });
  }
  effectSources(character).filter((effect) => effect.kind === (resource === "pv" ? "maxPv" : "maxPl"))
    .forEach((effect) => rows.push({ label: effect.source, value: Number(effect.value || 0) }));
  const subtotal = rows.reduce((sum, row) => sum + row.value, 0);
  if (subtotal < 0) rows.push({ label: "Ajuste: o máximo não fica abaixo de zero", value: -subtotal });
  return { rows, total: getMaxResources(character)[resource], attributes };
}

// Textos das fórmulas atuais; valores e totais continuam calculados em rules.js/data.js.
export const RESOURCE_FORMULAS = {
  Profeta: { pv: ["10 + (Força + Instinto) × 4", "Força + Instinto"], pl: ["25 + Lucidez × 15", "7"] },
  "Guardião": { pv: ["15 + (Força + Instinto) × 5", "3 + Força + Instinto"], pl: ["10 + Lucidez × 15", "3"] },
  Eremita: { pv: ["12 + (Força + Instinto) × 5", "1 + Força + Instinto"], pl: ["15 + Lucidez × 15", "5"] }
};
