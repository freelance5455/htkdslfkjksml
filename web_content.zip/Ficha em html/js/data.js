// Este arquivo é o "livro de regras" da ficha. Para incluir conteúdo novo,
// adicione ou altere objetos aqui, sem precisar mexer nas telas.

export const ATTRIBUTES = ["Força", "Instinto", "Razão", "Lucidez", "Influência"];

export const ATTRIBUTE_INFO = {
  "Força": "Testes físicos e parte do cálculo de PV.",
  "Instinto": "Reação, percepção, sobrevivência e parte do cálculo de PV.",
  "Razão": "Testes analíticos e quantidade de perícias livres na criação.",
  "Lucidez": "Testes mentais e grande parte do PL máximo.",
  "Influência": "Testes sociais, persuasão, comando e intimidação."
};

export const SKILLS = [
  ["Artes", true], ["Atletismo", false], ["Ciências Gerais", false], ["Condução", true],
  ["Constituição", false], ["Enganação", false], ["Furtividade", false], ["História", false],
  ["Intimidação", false], ["Intuição", false], ["Investigação", false], ["Luta", false],
  ["Mecânica", true], ["Mira", false], ["Ocultismo", true], ["Percepção", false],
  ["Persuasão", false], ["Primeiros Socorros", false], ["Reflexo", false], ["Charme", false],
  ["Sobrevivência", true], ["Tecnologia", true], ["Vontade", false]
].map(([name, technical]) => ({ name, technical }));

export const TRAINING = [
  { id: "inexperiente", label: "Inexperiente", bonus: 0 },
  { id: "experiente", label: "Experiente", bonus: 5 },
  { id: "habilidoso", label: "Habilidoso", bonus: 10 }
];

export const SINAS = {
  Profeta: {
    description: "A mente do Profeta toca o que existe além do visível.",
    bonuses: { "Lucidez": 1 },
    fixedSkills: ["Ocultismo", "Vontade"],
    freeSkills: (reason) => 3 + reason,
    choices: [],
    visionLevels: [2, 3, 5, 6, 8, 9, 10, 12, 13, 14, 15, 17, 18, 20],
    calculate: ({ level, attributes }) => ({
      pv: 10 + (attributes["Força"] + attributes["Instinto"]) * 4 + (level - 1) * (attributes["Força"] + attributes["Instinto"]),
      pl: 25 + attributes["Lucidez"] * 15 + (level - 1) * 7
    })
  },
  Guardião: {
    description: "O Guardião sobrevive para se colocar entre o perigo e os outros.",
    bonuses: {},
    fixedSkills: [],
    freeSkills: (reason) => 1 + reason,
    choices: [
      { id: "bonus", label: "Bônus de atributo", options: ["Força", "Instinto"], type: "attributeBonus" },
      { id: "combate", label: "Perícia de combate", options: ["Luta", "Mira"], type: "trainedSkill" },
      { id: "defesa", label: "Perícia de defesa", options: ["Reflexo", "Constituição"], type: "trainedSkill" }
    ],
    visionLevels: [2, 4, 5, 8, 10, 13, 15, 17],
    calculate: ({ level, attributes }) => ({
      pv: 15 + (attributes["Força"] + attributes["Instinto"]) * 5 + (level - 1) * (3 + attributes["Força"] + attributes["Instinto"]),
      pl: 10 + attributes["Lucidez"] * 15 + (level - 1) * 3
    })
  },
  Eremita: {
    description: "O Eremita observa, prepara-se e encontra caminhos que os outros não veem.",
    bonuses: { "Razão": 1 },
    fixedSkills: [],
    freeSkills: (reason) => 7 + reason,
    choices: [],
    visionLevels: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20],
    calculate: ({ level, attributes }) => ({
      pv: 12 + (attributes["Força"] + attributes["Instinto"]) * 5 + (level - 1) * (1 + attributes["Força"] + attributes["Instinto"]),
      pl: 15 + attributes["Lucidez"] * 15 + (level - 1) * 5
    })
  }
};

export const MARKS = {
  Popular: {
    bonuses: { "Influência": 1 }, trainedSkills: ["Persuasão", "Charme", "Percepção"], choices: [],
    narrative: "Sua presença molda o ambiente. Pessoas próximas tendem a ouvir você primeiro, mesmo quando discordam. O Mestre decide quando isso ajuda e quando torna você um alvo.",
    passive: "Magnetismo Social: uma vez por cena, repete Persuasão ou Charme e mantém o melhor resultado. Em cena pública ou em grupo, recebe +2.",
    active: { name: "Persona Pública", cost: 5, description: "Por uma cena, use Influência no lugar de outro atributo em testes sociais. Depois, teste Lucidez ND 10; se falhar, sofre −2 em Influência até o fim do dia." }
  },
  Repetente: {
    bonuses: {}, trainedSkills: ["Luta", "Enganação", "Vontade"],
    choices: [{ id: "bonus", label: "Bônus de atributo", options: ["Força", "Lucidez"], type: "attributeBonus" }],
    narrative: "Você é visto como mais maduro: jovens podem respeitar ou desconfiar; adultos e figuras de autoridade o tratam como caso problemático. Pode pedir vantagem em Persuasão ou Intimidação contra personagens mais jovens ou inexperientes.",
    passive: "Não é a Primeira Vez: ao cair a 0 PV, teste Vontade ND 15. Se passar, fica consciente com 1 PV até o fim da cena. Uma vez por sessão.",
    active: { name: "Já Passei por Pior", cost: 2, description: "Por uma cena, recebe +2 em Luta, Constituição e Vontade." }
  },
  Nerd: {
    bonuses: { "Razão": 1 }, trainedSkills: ["Investigação", "Ciências Gerais"],
    choices: [{ id: "extra", label: "Perícia adicional", options: ["Tecnologia", "Primeiros Socorros", "História", "Ocultismo", "Mecânica"], type: "trainedSkill" }],
    narrative: "Você percebe padrões, coincidências e repetições que os outros ignoram. O Mestre pode oferecer informações extras em investigação ou pesquisa, inclusive pistas enganosas, incompletas ou sobrenaturais.",
    passive: "Lógica Fria: após observar uma situação por um turno sem agir, pode usar Razão em qualquer teste ligado ao que analisou.",
    active: { name: "Preparação Meticulosa", cost: 3, description: "Escolha uma perícia e receba +3 em uma única rolagem justificável pela preparação." }
  },
  Atleta: {
    bonuses: {}, trainedSkills: ["Atletismo", "Luta", "Constituição"],
    choices: [{ id: "bonus", label: "Bônus de atributo", options: ["Força", "Instinto"], type: "attributeBonus" }],
    narrative: "Você reage antes da maioria. O Mestre pode permitir que aja primeiro em surpresa ou pânico; em troca, falhas em ações físicas tendem a ter consequências mais severas ou barulhentas.",
    passive: "Fôlego de Ferro: uma vez por cena, ignora efeito físico negativo por uma rodada adicional. Atletismo e Constituição sob estresse físico recebem +2.",
    active: { name: "Segundo Vento", cost: 3, description: "Abaixo de metade dos PV, recupere 5 PV. Na próxima cena, sofre −2 em Lucidez e Vontade." }
  },
  Artista: {
    bonuses: { "Lucidez": 1 }, trainedSkills: ["Intuição", "Percepção", "Mira"], choices: [],
    narrative: "Você é um artista incrível com talento nato. Com uma arte preparada (poema, foto, pintura etc.), em um teste de Influência, pode usar a obra para obter +1d6 no teste.",
    passive: "Beleza do Caos: aliados que observam o Artista ganham +1 em Lucidez diante de algo perturbador.",
    active: { name: "Obra Final", cost: 3, description: "Aliados próximos recebem +2 na próxima rolagem. O Artista sofre desvantagem em Instinto até o fim da cena." }
  },
  "Líder de Turma": {
    bonuses: { "Influência": 1 }, trainedSkills: ["Persuasão", "Intimidação", "Vontade"], choices: [],
    narrative: "Em tensão ou caos, as pessoas olham para você. Pode assumir a liderança de qualquer grupo. O Mestre pode conceder vantagem em comando, negociação ou coordenação; os erros do grupo recaem sobre você. NPCs que o conhecem têm desvantagem para resistir a testes de Influência seus.",
    passive: "Presença de Comando: aliados próximos recebem +1 em Lucidez enquanto o Líder estiver consciente e ativo.",
    active: { name: "Palavra de Ordem", cost: 3, description: "Até três aliados recebem +2 na próxima ação se seguirem uma instrução exata. Se alguém desobedecer, o Líder sofre −2 na próxima rolagem de Lucidez ou Influência." }
  },
  Invisível: {
    bonuses: { "Instinto": 1, "Influência": -1 }, trainedSkills: ["Furtividade", "Percepção", "Mecânica"], choices: [],
    narrative: "Você pode passar despercebido em multidões e escapar da atenção de NPCs distraídos sem rolar Furtividade, salvo perigo direto. Em interações sociais importantes, tendem a esquecer sua presença ou ignorar suas falas até que faça algo marcante.",
    passive: "Fora de Foco: vantagem em Furtividade e Percepção quando estiver sozinho ou fora do centro da cena. Ataques-surpresa contra você sofrem −2.",
    active: { name: "Testemunha Silenciosa", cost: 3, description: "Por uma cena, o Mestre revela detalhe, diálogo ou ação oculta nas proximidades." }
  },
  Delinquente: {
    bonuses: { "Força": 1 }, trainedSkills: ["Luta", "Furtividade", "Intimidação"], choices: [],
    narrative: "Autoridades o subestimam, colegas o temem e o caos parece seguir você. Pode intimidar NPCs sem teste em situações simples; ao tentar se passar por inocente ou confiável, testes sociais sofrem −2.",
    passive: "Fagulha de Rebeldia: ao sofrer condição que limite movimento ou ação, teste Vontade ND 12. Se passar, ignore-a por um turno; uma vez por condição.",
    active: { name: "A Primeira por Instinto", cost: 2, description: "Por dois turnos, todas as ações recebem +1, mas você não pode recuar nem evitar ataques." }
  }
};

export const VISION_PATHS = {
  Fome: [
    ["Alimentar/Restringir", "Média", 10, "Vantagem ou desvantagem em 3 testes do alvo; ao restringir, há resistência de Lucidez."],
    ["Ambrosia", "Média", "5–20", "Cura PV; não reverte morte nem substitui Primeiros Socorros."],
    ["Consumir", "Extrema", 12, "Drena por ataque, causa dano e cura o usuário na mesma proporção; 1d4 rodadas."],
    ["Vampirismo", "Extrema", 12, "Remove temporariamente uma perícia treinada do alvo por uma cena."],
    ["Definhar", "Média", 10, "Dano contínuo; resistência de Força reduz duração; 1d6 rodadas."],
    ["Olhar Faminto", "Leve", 5, "Enxerga alvo por obstáculos ou disfarces durante uma cena; 1d4 rodadas."],
    ["Comunhão da Fome", "Leve", 7, "Imbui uma Habilidade Aleatória do próprio Caminho em objeto ou arma até o fim da cena ou destruição do item. Não imbuí Habilidades Extremas."]
  ],
  "Lascívia": [
    ["Elo de Carne", "Média", 10, "Redireciona parte do dano a outro alvo; exige contato físico prévio; 1d6 rodadas."],
    ["Amarras", "Média", 15, "Imobiliza alvo por 1d3 rodadas; resistência de Força."],
    ["Masoquismo", "Leve", 5, "Efeito em desenvolvimento."],
    ["Obsessão", "Leve", 5, "Força próxima ação hostil contra o usuário; resistência de Lucidez; 1d3 rodadas."],
    ["Amarração Amorosa", "Extrema", 20, "Alvo luta ao lado do usuário por 1d4 rodadas; resistência de Lucidez com desvantagem."],
    ["Êxtase Cego", "Extrema", 15, "Perdas de PV ou Lucidez concedem vantagem no próximo teste; desvantagem em percepção e reação."],
    ["Comunhão da Lascívia", "Leve", 7, "Regra de Comunhão." ]
  ],
  Primazia: [
    ["Voz Soberana", "Extrema", 15, "Controla uma ação do alvo por uma rodada; resistência de Lucidez."],
    ["Sorte Forjada", "Média", 10, "Controla resultado de um dado próprio."],
    ["Sussurro Roubado", "Leve", 5, "Lê intenção ou pergunta superficial; resistência de Lucidez esconde informação."],
    ["Anular Vontade", "Média", 10, "Alvo perde a próxima ação; resistência de Instinto."],
    ["Palavra Absoluta", "Extrema", 20, "Resultado conta como sucesso, salvo crítico verdadeiro da oposição; uma vez por sessão."],
    ["Mão que Molda", "Extrema", 20, "Manipula matéria existente; exige concentração; alcance é linha de visão + Instinto em metros."],
    ["Comunhão da Primazia", "Leve", 5, "Regra de Comunhão." ]
  ],
  Paranoia: [
    ["Sussurros da Loucura", "Média", 10, "Ilusão que causa dano de Lucidez; resistência de Lucidez."],
    ["Falso Messias", "Leve", 5, "Ilusão sensorial simples; afeta percepção e investigação."],
    ["Bênção do Tempo", "Média", 10, "Reduz dano sofrido por você ou aliado por uma cena."],
    ["Sombra Solta", "Extrema", 20, "Usuário sai em forma espectral; corpo fica inconsciente e vulnerável."],
    ["Vislumbre de Instantes", "Média", 10, "Revela próxima ação de alvo antes que ele aja."],
    ["Encruzilhada", "Extrema", 20, "Revela múltiplas ramificações futuras possíveis."],
    ["Comunhão da Paranoia", "Leve", 5, "Regra de Comunhão." ]
  ]
};

export function getVisionCatalog() {
  return Object.entries(VISION_PATHS).flatMap(([path, abilities]) =>
    abilities.map(([name, tier, cost, description]) => ({ path, name, tier, cost, description }))
  );
}
