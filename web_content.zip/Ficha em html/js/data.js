// Este arquivo é o "livro de regras" da ficha. Para incluir conteúdo novo,
// adicione ou altere objetos aqui, sem precisar mexer nas telas.

export const ATTRIBUTES = ["Força", "Instinto", "Razão", "Lucidez", "Influência"];

export const ATTRIBUTE_INFO = {
  "Força": "Testes físicos e parte do cálculo de PV.",
  "Instinto": "Reação, percepção, sobrevivência e parte do cálculo de PV.",
  "Razão": "Testes analíticos e quantidade de perícias livres na criação.",
  "Lucidez": "Testes mentais e grande parte do PL máximo.",
  "Influência": "Testes sociais, charme, comando e intimidação."
};

export const SKILLS = [
  ["Artes", true], ["Atletismo", false], ["Ciências Gerais", false], ["Condução", true],
  ["Constituição", false], ["Enganação", false], ["Furtividade", false], ["História", false],
  ["Intimidação", false], ["Intuição", false], ["Investigação", false], ["Luta", false],
  ["Mecânica", true], ["Mira", false], ["Ocultismo", true], ["Percepção", false],
  ["Primeiros Socorros", false], ["Reflexo", false], ["Charme", false],
  ["Sobrevivência", true], ["Tecnologia", true], ["Vontade", false]
].map(([name, technical]) => ({ name, technical }));

export const TRAINING = [
  { id: "inexperiente", label: "Inexperiente", bonus: 0 },
  { id: "experiente", label: "Experiente", bonus: 5 },
  { id: "habilidoso", label: "Habilidoso", bonus: 10 }
];

export const SINAS = {
  Profeta: {
    description: "A mente do Profeta toca o que existe além do visível.",
    bonuses: { "Lucidez": 1 },
    fixedSkills: ["Ocultismo", "Vontade"],
    freeSkills: (reason) => 3 + reason,
    choices: [],
    visionLevels: [2, 3, 5, 6, 8, 9, 10, 12, 13, 14, 15, 17, 18, 20],
    calculate: ({ level, attributes }) => ({
      pv: 10 + (attributes["Força"] + attributes["Instinto"]) * 4 + (level - 1) * (attributes["Força"] + attributes["Instinto"]),
      pl: 25 + attributes["Lucidez"] * 15 + (level - 1) * 7
    })
  },
  Guardião: {
    description: "O Guardião sobrevive para se colocar entre o perigo e os outros.",
    bonuses: {},
    fixedSkills: [],
    freeSkills: (reason) => 1 + reason,
    choices: [
      { id: "bonus", label: "Bônus de atributo", options: ["Força", "Instinto"], type: "attributeBonus" },
      { id: "combate", label: "Perícia de combate", options: ["Luta", "Mira"], type: "trainedSkill" },
      { id: "defesa", label: "Perícia de defesa", options: ["Reflexo", "Constituição"], type: "trainedSkill" }
    ],
    visionLevels: [2, 4, 5, 8, 10, 13, 15, 17],
    calculate: ({ level, attributes }) => ({
      pv: 15 + (attributes["Força"] + attributes["Instinto"]) * 5 + (level - 1) * (3 + attributes["Força"] + attributes["Instinto"]),
      pl: 10 + attributes["Lucidez"] * 15 + (level - 1) * 3
    })
  },
  Eremita: {
    description: "O Eremita observa, prepara-se e encontra caminhos que os outros não veem.",
    bonuses: { "Razão": 1 },
    fixedSkills: [],
    freeSkills: (reason) => 7 + reason,
    choices: [],
    visionLevels: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20],
    calculate: ({ level, attributes }) => ({
      pv: 12 + (attributes["Força"] + attributes["Instinto"]) * 5 + (level - 1) * (1 + attributes["Força"] + attributes["Instinto"]),
      pl: 15 + attributes["Lucidez"] * 15 + (level - 1) * 5
    })
  }
};

export const MARKS = {
  Popular: {
    bonuses: { "Influência": 1 }, trainedSkills: ["Charme", "Vontade", "Intimidação"], choices: [],
    narrative: "Sua presença molda o ambiente. Pessoas próximas tendem a ouvir você primeiro, mesmo quando discordam. O Mestre decide quando isso ajuda e quando torna você um alvo.",
    passive: "Magnetismo Social: uma vez por cena, repete Charme e mantém o melhor resultado. Em cena pública ou em grupo, recebe +2.",
    active: { name: "Persona Pública", cost: 5, description: "Por uma cena, use Influência no lugar de outro atributo em testes sociais. Depois, teste Lucidez ND 10; se falhar, sofre −2 em Influência até o fim do dia." }
  },
  Repetente: {
    bonuses: {}, trainedSkills: ["História", "Constituição", "Vontade"],
    choices: [{ id: "bonus", label: "Bônus de atributo", options: ["Força", "Lucidez"], type: "attributeBonus" }],
    narrative: "Você é visto como mais maduro: jovens podem respeitar ou desconfiar; adultos e figuras de autoridade o tratam como caso problemático. Pode pedir vantagem em Charme ou Intimidação contra personagens mais jovens ou inexperientes.",
    passive: "Não é a Primeira Vez: ao cair a 0 PV, teste Vontade ND 15. Se passar, fica consciente com 1 PV até o fim da cena. Uma vez por sessão.",
    active: { name: "Já Passei por Pior", cost: 2, description: "Por uma cena, recebe +2 em Luta, Constituição e Vontade." }
  },
  Nerd: {
    bonuses: { "Razão": 1 }, trainedSkills: ["Investigação", "Ciências Gerais"],
    choices: [{ id: "extra", label: "Perícia adicional", options: ["Tecnologia", "Primeiros Socorros", "História", "Ocultismo", "Mecânica"], type: "trainedSkill" }],
    narrative: "Você percebe padrões, coincidências e repetições que os outros ignoram. O Mestre pode oferecer informações extras em investigação ou pesquisa, inclusive pistas enganosas, incompletas ou sobrenaturais.",
    passive: "Lógica Fria: após observar uma situação por um turno sem agir, pode usar Razão em qualquer teste ligado ao que analisou.",
    active: { name: "Preparação Meticulosa", cost: 3, description: "Escolha uma perícia e receba +3 em uma única rolagem justificável pela preparação." }
  },
  Atleta: {
    bonuses: {}, trainedSkills: ["Atletismo", "Constituição"],
    choices: [
      { id: "bonus", label: "Bônus de atributo", options: ["Força", "Instinto"], type: "attributeBonus" },
      { id: "combate", label: "Perícia de combate", options: ["Luta", "Mira", "Reflexo"], type: "trainedSkill" }
    ],
    narrative: "Você reage antes da maioria. O Mestre pode permitir que aja primeiro em surpresa ou pânico; em troca, falhas em ações físicas tendem a ter consequências mais severas ou barulhentas.",
    passive: "Fôlego de Ferro: uma vez por cena, ignora efeito físico negativo por uma rodada adicional. Atletismo e Constituição sob estresse físico recebem +2.",
    active: { name: "Segundo Vento", cost: 3, description: "Abaixo de metade dos PV, recupere 5 PV. Na próxima cena, sofre −2 em Lucidez e Vontade." }
  },
  Artista: {
    bonuses: { "Lucidez": 1 }, trainedSkills: ["Intuição", "Percepção", "Artes"], choices: [],
    narrative: "Você é um artista incrível com talento nato. Com uma arte preparada (poema, foto, pintura etc.), em um teste de Influência, pode usar a obra para obter +1d6 no teste.",
    passive: "Beleza do Caos: aliados que observam o Artista ganham +1 em Lucidez diante de algo perturbador.",
    active: { name: "Obra Final", cost: 3, description: "Aliados próximos recebem +2 na próxima rolagem. O Artista sofre desvantagem em Instinto até o fim da cena." }
  },
  "Líder de Turma": {
    bonuses: { "Influência": 1 }, trainedSkills: ["Charme", "Intuição", "Percepção"], choices: [],
    narrative: "Em tensão ou caos, as pessoas olham para você. Pode assumir a liderança de qualquer grupo. O Mestre pode conceder vantagem em comando, negociação ou coordenação; os erros do grupo recaem sobre você. NPCs que o conhecem têm desvantagem para resistir a testes de Influência seus.",
    passive: "Presença de Comando: aliados próximos recebem +1 em Lucidez enquanto o Líder estiver consciente e ativo.",
    active: { name: "Palavra de Ordem", cost: 3, description: "Até três aliados recebem +2 na próxima ação se seguirem uma instrução exata. Se alguém desobedecer, o Líder sofre −2 na próxima rolagem de Lucidez ou Influência." }
  },
  Invisível: {
    bonuses: { "Instinto": 1, "Influência": -1 }, trainedSkills: ["Furtividade", "Percepção", "Mecânica"], choices: [],
    narrative: "Você pode passar despercebido em multidões e escapar da atenção de NPCs distraídos sem rolar Furtividade, salvo perigo direto. Em interações sociais importantes, tendem a esquecer sua presença ou ignorar suas falas até que faça algo marcante.",
    passive: "Fora de Foco: vantagem em Furtividade e Percepção quando estiver sozinho ou fora do centro da cena. Ataques-surpresa contra você sofrem −2.",
    active: { name: "Testemunha Silenciosa", cost: 3, description: "Por uma cena, o Mestre revela detalhe, diálogo ou ação oculta nas proximidades." }
  },
  Delinquente: {
    bonuses: { "Força": 1 }, trainedSkills: ["Luta", "Furtividade", "Intimidação"], choices: [],
    narrative: "Autoridades o subestimam, colegas o temem e o caos parece seguir você. Pode intimidar NPCs sem teste em situações simples; ao tentar se passar por inocente ou confiável, testes sociais sofrem −2.",
    passive: "Fagulha de Rebeldia: ao sofrer condição que limite movimento ou ação, teste Vontade ND 12. Se passar, ignore-a por um turno; uma vez por condição.",
    active: { name: "A Primeira por Instinto", cost: 2, description: "Por dois turnos, todas as ações recebem +1, mas você não pode recuar nem evitar ataques." }
  }
};

// Habilidades revisadas: resumo no cartão; regras completas em “Como usar”.
// costOptions define os modos com custos diferentes, sem rolar dados virtuais.
export const VISION_PATHS = {
  "Fome": [
    {
      "name": "Alimentar/Restringir",
      "cost": 12,
      "description": "Fortalece ou enfraquece o desempenho de uma criatura em um tipo de teste escolhido, afetando suas próximas tentativas. Não funciona em testes feitos com Lucidez.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura percebida.\n**Duração:** até consumir 1d4+1 testes.\n**Resistência:** Restringir: Constituição com Força ou Instinto contra Ocultismo com Lucidez; apenas inicial.\n**Concentração:** não.",
      "rules": "Custa **12 PL** e usa uma ação principal em uma criatura a até 9 m. Escolha o tipo de teste e role 1d4+1 para saber quantas vezes o efeito será usado. Role também 4+1d6 uma única vez: some esse valor com Alimentar ou subtraia com Restringir. O alvo tenta resistir à restrição com Constituição com Força ou Instinto. Testes com Lucidez não podem ser afetados. As utilizações ficam disponíveis até serem gastas ou canceladas; aplicar a versão oposta encerra as duas."
    },
    {
      "name": "Ambrosia",
      "cost": "5 / 10 / 15 / 20",
      "description": "Transforma comida ou bebida em uma porção capaz de recuperar PV de quem a consumir. A potência da cura é escolhida na criação; ela não substitui os Primeiros Socorros de alguém que já caiu.",
      "technical": "**Ação:** principal para transformar; livre para consumir.\n**Alcance:** toque no alimento ou líquido.\n**Alvo:** uma porção, consumida por uma criatura.\n**Duração da porção:** 1 minuto ou até o consumo.\n**Resistência:** nenhuma.\n**Concentração:** não.",
      "rules": "Use uma ação principal para tocar uma porção de comida ou bebida existente e escolha a cura: **5 PL** para 1+1d6 PV, **10 PL** para 4+1d8, **15 PL** para 7+1d12 ou **20 PL** para 10+1d20. Quem consumir gasta uma ação livre e rola a cura naquele momento. A porção dura um minuto e não pode ser dividida. Cada aplicador mantém só uma porção pronta, e cada alvo consome uma por turno. O excedente de cura é perdido. Sorte Forjada e Palavra Absoluta não alteram essa rolagem.",
      "costOptions": [
        {
          "label": "1 + 1d6 PV",
          "cost": 5
        },
        {
          "label": "4 + 1d8 PV",
          "cost": 10
        },
        {
          "label": "7 + 1d12 PV",
          "cost": 15
        },
        {
          "label": "10 + 1d20 PV",
          "cost": 20
        }
      ]
    },
    {
      "name": "Consumir",
      "cost": 14,
      "description": "Permite recuperar PV ao causar dano com ataques não mágicos, incluindo contra-ataques. A cura depende do dano realmente causado e tem um limite por rodada.",
      "technical": "**Ação:** principal.\n**Alcance/alvo:** pessoal.\n**Duração:** 1+1d3 rodadas, a partir do início do próximo turno do usuário.\n**Cura:** 50% do dano elegível, arredondado para baixo; máximo de 4 PV por rodada de efeito.\n**Concentração:** não.",
      "rules": "Custa **14 PL**, usa uma ação principal e afeta o próprio aplicador. Começa no início do seu próximo turno e dura 1+1d3 rodadas. Cada ataque não mágico, inclusive contra-ataque, recupera metade dos PV realmente retirados do alvo, arredondando para baixo, até **4 PV no total por rodada**. O limite se renova no início do seu turno. Aliados e alvos incapazes de reagir contam se ainda tiverem PV; objetos não contam. Dano mágico, contínuo, de efeitos mantidos, causado por criaturas controladas ou transferido por Elo não cura. Ficar inconsciente encerra o efeito."
    },
    {
      "name": "Vampirismo",
      "cost": "18 — perícia / 34 — atributo",
      "description": "Rouba temporariamente o treinamento de uma perícia ou todos os pontos de um atributo de outra criatura. O aplicador recebe o que foi roubado, enquanto o alvo perde esse recurso até o efeito terminar.",
      "technical": "**Ação:** principal, incluindo a tentativa de toque.\n**Alcance:** toque concretizado.\n**Alvo:** uma criatura.\n**Duração:** uma cena fora de combate; 1+1d3 rodadas em combate.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez; apenas inicial.\n**Concentração:** não.",
      "rules": "Use uma ação principal para tocar uma criatura: custa **18 PL** roubar uma perícia ou **34 PL** roubar um atributo. Se o toque falhar, não paga PL; havendo contato, o alvo resiste com Vontade com Lucidez. Dura uma cena fora de combate ou 1+1d3 rodadas em combate. O atributo escolhido fica em zero no alvo e seus pontos passam ao aplicador, mesmo acima do limite normal. Recalcule os derivados, mantendo os PV atuais na mesma proporção e ao menos 1 PV para quem ainda estava de pé; O roubo nunca altera PL atuais ou máximos; quem já estava a 0 PV continua a 0. No roubo de perícia, o alvo perde o treinamento. O aplicador sem treinamento recebe o grau roubado; dois graus +5 viram +10, +5 com +10 vira +12, e dois +10 viram +15. Não copia ganhos de outro Vampirismo, Sina, Marca ou magias conhecidas. Cada aplicador e cada alvo só podem manter um Vampirismo ativo.",
      "costOptions": [
        {
          "label": "Roubar perícia",
          "cost": 18
        },
        {
          "label": "Roubar atributo",
          "cost": 34
        }
      ],
      "trainingCombinations": [
        [
          "Inexperiente +0",
          "Experiente +5",
          "Experiente +5"
        ],
        [
          "Inexperiente +0",
          "Habilidoso +10",
          "Habilidoso +10"
        ],
        [
          "Experiente +5",
          "Experiente +5",
          "Habilidoso +10"
        ],
        [
          "Experiente +5",
          "Habilidoso +10",
          "Expert +12"
        ],
        [
          "Habilidoso +10",
          "Experiente +5",
          "Expert +12"
        ],
        [
          "Habilidoso +10",
          "Habilidoso +10",
          "Mestre +15"
        ]
      ],
      "trainingNote": "Use apenas o treinamento próprio do alvo, sem ganhos de outro Vampirismo. O alvo fica Inexperiente durante o efeito; ao terminar, ambos recuperam seus graus próprios. Expert e Mestre são temporários. Conhecimentos, idiomas e técnicas vinculados à perícia podem ser usados se seus outros requisitos forem cumpridos. O roubo não cria equipamento, não transfere PL e não substitui Sina, Marca ou aprendizado próprio de Habilidades de Visão."
    },
    {
      "name": "Definhar",
      "cost": 11,
      "description": "Enfraquece o corpo do alvo, causando dano imediato e repetindo o sofrimento nas duas rodadas seguintes. Resistir reduz os danos posteriores, mas não evita o primeiro.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura.\n**Dano:** 1d4+2, rolado uma vez.\n**Duração:** três aplicações.\n**Resistência:** Constituição com Força contra Ocultismo com Lucidez; apenas inicial.\n**Concentração:** não.",
      "rules": "Custa **11 PL**, usa uma ação principal e alcança uma criatura a até 9 m. Role 1d4+2 uma vez e cause esse dano imediatamente. O alvo resiste com Constituição com Força: se falhar, recebe o mesmo valor no início de seus turnos nas duas rodadas seguintes; se vencer, recebe metade nessas duas vezes, arredondada para baixo. O primeiro dano continua integral. Ignora armadura comum, mas admite proteção mágica apropriada. Reaplicar pelo mesmo conjurador causa novo dano imediato e substitui a sequência anterior; conjuradores diferentes mantêm suas próprias aplicações."
    },
    {
      "name": "Olhar Faminto",
      "cost": 7,
      "description": "Permite acompanhar a silhueta de um alvo conhecido no escuro, sob invisibilidade ou através de paredes finas. Em combate, melhora a Mira contra ele e impede que ele surpreenda o aplicador.",
      "technical": "**Ação:** principal.\n**Alcance:** 18 m.\n**Alvo:** uma criatura previamente vista ou identificada.\n**Duração:** uma cena fora de combate; 1+1d3 rodadas em combate.\n**Bônus:** +5 fixos em todos os testes de Mira contra o alvo.\n**Concentração:** não.",
      "rules": "Custa **7 PL** e usa uma ação principal. Acompanha um alvo já visto ou identificado a até 18 m, mesmo no escuro, invisível ou atrás de até 1 m de parede. Dura uma cena fora de combate ou 1+1d3 rodadas em combate, sem resistência. Concede **+5 em todos os testes de Mira** contra esse alvo e impede que ele surpreenda o aplicador. Revela a silhueta real entre duplicatas, mas não detalhes nem pensamentos. A visão some enquanto o alvo estiver fora dos limites. Não permite conjurar através de paredes."
    },
    {
      "name": "Alergia",
      "cost": 14,
      "description": "Faz o corpo do alvo rejeitar a cura por um curto período. Em vez de recuperar PV, itens, magias e outras fontes de cura passam a causar dano de igual valor.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura.\n**Duração:** 1d3 rodadas.\n**Resistência:** Constituição com Força ou Instinto contra Ocultismo com Lucidez, na aplicação.\n**Conversão:** cura pretendida em PV → igual quantidade de dano em PV.\n**Concentração:** não.",
      "rules": "Custa **14 PL**, usa uma ação principal e afeta uma criatura a até 9 m por **1d3 rodadas**. O alvo resiste com Constituição com Força ou Instinto. Durante o efeito, calcule a cura normalmente e transforme esse valor em dano, mesmo se ele já estiver com os PV cheios. Uma cura de 10 PV vira 10 de dano antes das proteções. Armadura, bloqueio e esquiva não evitam a inversão; Bênção e Elo ainda funcionam. Se Masoquismo já proibir a cura, nada é convertido. Os limites de cura são gastos antes da inversão. Estabilização sem cura, recuperação de PL e ajustes de Vampirismo ficam de fora. A magia não obriga ninguém a aceitar cura."
    }
  ],
  "Lascívia": [
    {
      "name": "Elo de Carne",
      "cost": "14 por ligação",
      "description": "Liga criaturas por meio da mistura de seu sangue, dividindo entre elas o dano sofrido por qualquer integrante. Novas ligações podem ampliar a rede e repartir o sofrimento entre mais alvos.",
      "technical": "**Ação:** principal, depois de obter as amostras.\n**Alcance:** 9 m na ativação.\n**Alvos:** duas criaturas cujos sangues sejam misturados.\n**Duração de cada ligação:** 1+1d3 rodadas.\n**Resistência:** cada involuntário usa Constituição com Força ou Instinto contra a única rolagem de Ocultismo com Lucidez.\n**Concentração:** não.",
      "rules": "Cada ligação custa **14 PL**, usa uma ação principal e dura 1+1d3 rodadas. Misture sangue obtido das duas criaturas na cena, ambas a até 9 m na ativação. Cada alvo involuntário resiste com Constituição com Força ou Instinto; se um resistir, a nova ligação falha. Reduza primeiro o dano no atingido e depois divida igualmente seus PV de dano entre os integrantes da rede. As cotas transferidas não voltam a se dividir nem usam a armadura ou as imunidades de quem as recebe, mas Bênção ainda pode reduzi-las. Novas ligações ampliam a rede e conservam seus próprios prazos. Não divide cura, PL ou condições; morte desfaz as ligações, mas chegar a 0 PV sem morrer não desfaz.",
      "costOptions": [
        {
          "label": "Uma ligação",
          "cost": 14
        }
      ]
    },
    {
      "name": "Amarras",
      "cost": 16,
      "description": "Imobiliza o alvo, impedindo deslocamentos, ataques e conjurações. Exige concentração completa do aplicador, e a vítima pode tentar se libertar enquanto estiver presa.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura.\n**Duração:** 1d3 rodadas.\n**Resistência:** Luta com Força contra Ocultismo com Lucidez, inicial e no início de cada turno do alvo.\n**Concentração:** sim.",
      "rules": "Custa **16 PL**, usa uma ação principal e prende uma criatura a até 9 m por 1d3 rodadas. O alvo resiste com Luta com Força na aplicação e recebe uma nova tentativa gratuita no início de cada turno, inclusive o primeiro. Se conseguir, fica livre para agir. Enquanto preso, não anda, ataca, esquiva ou conjura, mas pode falar e bloquear sem se deslocar. O aplicador precisa manter concentração completa e não pode realizar outras ações. Não há cordas físicas para cortar; perder a concentração encerra a prisão. Segue a proteção compartilhada contra controle."
    },
    {
      "name": "Masoquismo",
      "cost": 10,
      "description": "Impede o alvo de esquivar e recuperar PV. Quando aceita voluntariamente ou usada em si mesmo, também permite ao próprio afetado recuperar PL conforme o dano que sofre, até o limite da magia.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m; pessoal na autoaplicação.\n**Alvo:** uma criatura.\n**Duração:** 1+1d3 rodadas.\n**Resistência hostil:** Vontade com Lucidez contra Ocultismo com Lucidez, apenas inicial.\n**Teto de recuperação:** 20 PL por beneficiário por cena.\n**Concentração:** não.",
      "rules": "Custa **10 PL**, usa uma ação principal e dura 1+1d3 rodadas em uma criatura a até 9 m, inclusive no próprio aplicador. Um alvo hostil resiste com Vontade com Lucidez. O afetado não pode esquivar nem recuperar PV, mas ainda pode bloquear, contra-atacar e receber estabilização sem cura. Na aplicação voluntária ou pessoal, cada PV realmente perdido recupera **1 PL**, até **20 PL por criatura na cena**, somando todas as conjurações. Contra um inimigo, não concede essa recuperação. Dano próprio, de aliados, do ambiente e de Elo pode contar; pagar habilidades não conta. Cancelar, esperar ou reconjurar não renova o teto."
    },
    {
      "name": "Obsessão",
      "cost": 9,
      "description": "Torna o aplicador o foco da hostilidade do alvo, que passa a priorizar aproximar-se dele e atacá-lo. A vítima ainda pode agir para preservar a própria vida.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura com vontade própria.\n**Duração:** 1d3 rodadas.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez; apenas inicial.\n**Concentração:** não.",
      "rules": "Custa **9 PL**, usa uma ação principal e dura 1d3 rodadas em uma criatura a até 9 m. O alvo resiste com Vontade com Lucidez na aplicação. Se falhar, deve dirigir suas ações hostis ao aplicador e aproximar-se por um caminho possível quando necessário. Ainda pode curar, defender, fugir de perigo imediato ou prestar auxílio necessário, mas não aproveitar isso para atacar outra pessoa. Não exige suicídio nem gasto de recursos raros. Receber dano comum não encerra o efeito. Não serve para manipulação social e segue a proteção compartilhada contra controle."
    },
    {
      "name": "Amarração Amorosa",
      "cost": 32,
      "description": "Induz o alvo a cooperar e seguir ordens compatíveis com sua índole, inclusive em combate. Fora de uma luta, facilita a influência sobre ele; ataques do aplicador ou de seus aliados quebram o controle.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura; sem limite geral de alvos distintos por aplicador.\n**Duração:** 1+1d3 rodadas em combate; uma cena em uso social.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez, inicial e antes dos turnos posteriores em combate.\n**Concentração:** não.",
      "rules": "Custa **32 PL** por conjuração, usa uma ação principal e alcança uma criatura a até 9 m. Dura uma cena no uso social ou 1+1d3 rodadas em combate. O alvo resiste com Vontade com Lucidez; se falhar, cumpre a primeira ação sem novo teste e tenta resistir novamente a partir do segundo turno. O aplicador dá uma ordem curta por turno como ação livre, respeitando a índole e a autopreservação da vítima. Uma tentativa de dano pelo seu grupo encerra o controle, mesmo errando; dano contínuo anterior do grupo também o quebra. No uso social, role 4+1d6 uma vez e some aos testes de Influência com o alvo. Não exige concentração e permite controlar alvos diferentes com conjurações separadas. Depois do controle em combate, a proteção contra novos controles dura cinco turnos próprios."
    },
    {
      "name": "Êxtase Cego",
      "cost": 12,
      "description": "Prejudica a Percepção e o Reflexo do alvo. Em compensação, danos em PV ou PL lhe concedem vantagem para outros testes seguintes; gastar PL para usar habilidades não gera esse benefício.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m; pessoal na autoaplicação.\n**Alvo:** uma criatura, inclusive involuntária.\n**Duração:** 1+1d3 rodadas.\n**Resistência:** nenhuma.\n**Penalidades:** desvantagem em Percepção e Reflexo.\n**Concentração:** não.",
      "rules": "Custa **12 PL**, usa uma ação principal e dura 1+1d3 rodadas em uma criatura a até 9 m, inclusive no aplicador. Não permite resistência. O alvo sofre desvantagem em Percepção e Reflexo. Cada ocorrência de dano em PV ou perda de PL que não seja custo de habilidade gera uma utilização de vantagem no próximo teste dele; perder os dois recursos no mesmo evento gera só uma. Eventos diferentes guardam utilizações separadas, sem aumentar uma mesma vantagem. Cada teste consome uma utilização, mas ela não afasta as penalidades de Percepção e Reflexo desta magia. As utilizações restantes somem ao terminar."
    },
    {
      "name": "Oferenda",
      "cost": 6,
      "description": "Transfere parte dos próprios PV para curar outra criatura em um valor exato. Pode ser usada com uma ação de movimento ou como reação antes de um golpe atingir o beneficiário, sem sacrificar o último PV do aplicador.",
      "technical": "**Ação:** movimento no próprio turno; ou reação imediatamente antes de outra criatura sofrer dano em PV.\n**Alcance:** 9 m, com percepção do beneficiário.\n**Alvo:** outra criatura voluntária; nunca o próprio aplicador.\n**Duração:** instantânea.\n**Sacrifício/cura:** de 1 a 20 PV, escolhidos; 1 PV sacrificado para 1 PV de cura.\n**Limites:** uma conjuração por aplicador e um recebimento por beneficiário por rodada.\n**Resistência/concentração:** nenhuma.",
      "rules": "Custa **6 PL** e sacrifica de **1 a 20 PV próprios** para curar exatamente essa quantidade em outra criatura voluntária a até 9 m. O aplicador precisa conservar pelo menos 1 PV. Usa uma ação de movimento no seu turno ou uma reação antes de o beneficiário sofrer dano: calcule o golpe, cure e só então retire os PV do golpe. Não cria PV além do máximo nem desfaz dano já recebido. Cada aplicador conjura uma vez por rodada, e cada beneficiário recebe uma vez, mesmo com vários conjuradores. O sacrifício é custo, não dano: não ativa Masoquismo, Êxtase, Consumir ou Eco e não se divide por Elo. Masoquismo bloqueia a cura e Alergia a inverte, sem devolver os custos."
    }
  ],
  "Primazia": [
    {
      "name": "Voz Soberana",
      "cost": 24,
      "description": "Impõe ao alvo uma única ação por meio de uma ordem falada. Pode exigir movimento, ataque ou outra ação possível, mas não suicídio ou perdas permanentes.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura com vontade própria.\n**Duração:** uma ordem, cumprida na próxima oportunidade pertinente.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez; apenas inicial.\n**Concentração:** não.",
      "rules": "Custa **24 PL**, usa uma ação principal e impõe uma ordem a uma criatura a até 9 m. O alvo resiste com Vontade com Lucidez. A ordem deve ser falada, mas é compreendida magicamente mesmo sem audição ou idioma comum. Ela substitui uma única ação que a vítima teria na próxima oportunidade adequada. Pode envolver movimento, ataque ou recursos recuperáveis, mas não suicídio, perda permanente ou gasto dos últimos PL. Se a ação ordenada for impossível, aquela ação é perdida. Não concede ações extras e segue a proteção compartilhada contra controle."
    },
    {
      "name": "Sorte Forjada",
      "cost": 22,
      "description": "Permite escolher um resultado possível para uma rolagem própria, inclusive corrigindo um resultado ruim antes de suas consequências. Não pode alcançar o máximo da rolagem nem produzir um sucesso crítico.",
      "technical": "**Ativação:** instantânea, sem consumir ação principal ou reação.\n**Alcance/alvo:** uma rolagem do próprio usuário.\n**Momento:** antes ou imediatamente depois do dado, antes de resolver consequências.\n**Limite:** uma utilização por rodada.\n**Resistência/concentração:** nenhuma.",
      "rules": "Custa **22 PL** e pode ser usada uma vez por rodada, sem gastar ação principal ou reação. Escolha um resultado possível para uma rolagem própria, sempre abaixo do máximo e sem produzir um 20 natural. Pode agir antes ou logo depois do dado, inclusive corrigindo falha crítica, mas antes das consequências. O número escolhido já inclui os modificadores. Funciona mesmo sob controle ou inconsciência, inclusive no Dado de Morte; não funciona após a perda definitiva do personagem. Não altera cura de Ambrosia, não combina com Palavra Absoluta e não pode ser usada durante Sombra Solta."
    },
    {
      "name": "Sussurro Roubado",
      "cost": 26,
      "description": "Lê um pensamento, emoção ou intenção imediata do alvo. Em combate, melhora Mira e Reflexo contra ele e permite um golpe corpo a corpo certeiro com dano básico máximo, podendo compartilhar essa oportunidade com um aliado.",
      "technical": "**Ação:** livre; uma conjuração por rodada.\n**Alcance:** 9 m, com alvo diretamente percebido.\n**Alvo:** uma criatura.\n**Duração de combate:** uma rodada de benefício, conforme a janela descrita.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez.\n**Concentração:** não.",
      "rules": "Custa **26 PL**, usa uma ação livre e pode ser conjurada uma vez por rodada em uma criatura percebida a até 9 m. O alvo resiste com Vontade com Lucidez, sem perceber a leitura. Se falhar, o aplicador recebe vantagem em Mira e Reflexo contra ele por uma rodada e um golpe corpo a corpo acerta sem esquiva, bloqueio ou contra-ataque, com dano básico máximo da arma; dados extras ainda são rolados e armadura ainda protege. Se usada antes da ação principal, o benefício começa agora e o golpe é do aplicador. Se usada depois, começa no próximo turno; nesse turno, uma ação livre pode comunicar a leitura para um aliado aproveitar o golpe. Só um golpe consome essa oportunidade e nenhum ataque extra é criado."
    },
    {
      "name": "Anular Vontade",
      "cost": 22,
      "description": "Faz o alvo perder seu turno inteiro ou interrompe o restante de um turno em andamento. Durante esse impedimento, ele também fica sem reações.",
      "technical": "**Ação:** principal preventiva ou reação especial de interrupção.\n**Alcance:** 9 m.\n**Alvo:** uma criatura.\n**Duração:** um turno do alvo, conforme o momento da aplicação.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez.\n**Limite:** uma conjuração por aplicador por rodada.\n**Concentração:** não.",
      "rules": "Custa **22 PL**, alcança uma criatura a até 9 m e pode ser conjurada uma vez por rodada. Use uma ação principal para retirar o próximo turno do alvo ou uma reação especial para interromper uma ação percebida antes de suas consequências. O alvo resiste com Vontade com Lucidez. Se a interrupção funcionar durante o turno dele, perde a ação e o restante daquele turno, sem perder também outro turno completo. Fica sem ação principal, movimento, ações livres, ataques extras e reações durante o impedimento; também não reage enquanto aguarda o turno perdido. Se resistir, a ação interrompida continua. Segue a proteção compartilhada contra controle."
    },
    {
      "name": "Palavra Absoluta",
      "cost": 36,
      "description": "Determina, antes de uma rolagem própria, um sucesso crítico ou o maior resultado que ela poderia alcançar. É uma intervenção decisiva, utilizável apenas uma vez por cena.",
      "technical": "**Ativação:** declaração verbal instantânea antes da rolagem, sem ação principal.\n**Alcance/alvo:** uma rolagem do próprio usuário.\n**Duração:** imediata.\n**Limite:** uma utilização por cena.\n**Resistência/concentração:** nenhuma.",
      "rules": "Custa **36 PL** e só pode ser usada uma vez por cena. Declare a palavra antes de uma rolagem própria, sem gastar ação principal: testes com regra de crítico viram sucessos críticos; dano e outras rolagens atingem o máximo legal. Não pode corrigir um dado já lançado, alterar Ambrosia ou combinar com Sorte Forjada. Exige que o aplicador consiga fazer a declaração, portanto não funciona inconsciente ou sob um controle que a impeça. Não cria dano extra nem dispensa requisitos ou muda o significado do resultado: obter o máximo no Dado de Morte, por exemplo, não estabiliza automaticamente."
    },
    {
      "name": "Mão que Molda",
      "cost": 24,
      "description": "Manipula e desloca objetos, materiais ou elementos já presentes no ambiente, permitindo usá-los para atacar, proteger ou abrir caminho. Exige concentração e não cria nem transforma matéria.",
      "technical": "**Ação:** principal para ativar e comandar a manipulação.\n**Alcance:** 9 m, com percepção do material.\n**Alvo:** um objeto ou uma porção de um único material/elemento existente.\n**Limites:** 20 × máximo(1, Lucidez) kg; volume de até 1 m³; deslocamento de até 9 m por turno.\n**Duração:** enquanto houver concentração.\n**Concentração:** especial; permite movimento e ações livres comuns.",
      "rules": "Custa **24 PL** uma única vez e exige uma ação principal para ativar e para cada comando. Move um objeto ou uma porção de um material existente a até 9 m, por no máximo 9 m a cada turno. O limite é **20 × Lucidez em kg**, usando Lucidez 1 se o atributo estiver em zero, e até **1 m³**. Enquanto concentra, pode mover-se e fazer ações livres comuns; reagir ou conjurar encerra o efeito. Cada comando permite no máximo um ataque ou manobra, usando Ocultismo com Lucidez contra a defesa cabível; armadura funciona. Para resistir a uma prisão ou empurrão, use Luta com Força ou Reflexo com Instinto, conforme a situação. Não age dentro de corpos, sobre equipamento vestido ou empunhado, nem sobre partes integradas de estruturas. Use o dano próprio do material; sem perfil, impactos de até 5 kg causam 1d6+Lucidez, até 20 kg causam 1d8+Lucidez e acima disso, 1d12+Lucidez. Material perigoso sem perfil causa 1d6 por contato em um alvo por comando."
    },
    {
      "name": "Domínio Soberano",
      "cost": 16,
      "description": "Cria uma área fixa em que conjurar magias custa 25% menos PL. Todos dentro dela recebem o benefício, incluindo o aplicador, seus aliados e seus inimigos.",
      "technical": "**Ação:** principal.\n**Alcance:** centro fixo a até 9 m.\n**Área:** esfera de 6 m de raio.\n**Beneficiários:** todos os conjuradores na área, inclusive inimigos e o aplicador.\n**Duração:** 1+1d3 rodadas.\n**Desconto:** 25% do custo de PL, arredondado para baixo; custo final mínimo de 1 PL.\n**Resistência/concentração:** nenhuma.",
      "rules": "Custa **16 PL**, usa uma ação principal e dura 1+1d3 rodadas. Escolha um centro fixo a até 9 m: a área é uma esfera de **6 m de raio**. Quem estiver nela ao pagar uma magia recebe 25% de desconto, inclusive inimigos. Arredonde o desconto para baixo e mantenha custo mínimo de 1 PL: uma magia de 20 custa 15, e uma de 6 custa 5. O efeito continua usando a intensidade original. Não reduz sacrifícios em PV nem o custo de abrir outro Domínio. Campos sobrepostos não somam descontos; cada aplicador mantém só um. Sair da área não desfaz magias já pagas."
    }
  ],
  "Paranoia": [
    {
      "name": "Sussurros da Loucura",
      "cost": 16,
      "description": "Invade a mente do alvo com imagens e sons perturbadores, causando dano diretamente em seus PL. Uma resistência bem-sucedida reduz a perda, mas não a evita por completo.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m.\n**Alvo:** uma criatura com mente e reserva de PL.\n**Dano:** 5+1d20 PL.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez; sucesso reduz à metade, para baixo.\n**Duração:** imediata.\n**Concentração:** não.",
      "rules": "Custa **16 PL**, usa uma ação principal e atinge uma criatura com mente a até 9 m. Causa **5+1d20 de dano em PL** imediatamente. O alvo resiste com Vontade com Lucidez: se vencer, recebe metade, arredondada para baixo. Armadura não protege e o aplicador não recebe os PL retirados. O efeito funciona mesmo sem visão ou audição da vítima. Se uma criatura consciente não tiver PL na ficha, use provisoriamente uma reserva separada igual aos PV máximos, definida antes do dano. Chegar a 0 PL segue a consequência geral do sistema."
    },
    {
      "name": "Falso Messias",
      "cost": "6 — ilusão ambiental / 18 — duplicatas",
      "description": "Cria imagens e sons ilusórios para enganar os sentidos. Também pode produzir duas cópias do aplicador, capazes de confundir atacantes e fazer seus golpes atingirem uma ilusão.",
      "technical": "**Ação:** principal.\n**Alcance:** 9 m; duplicatas ao redor do próprio aplicador.\n**Área ambiental:** até 3 m de lado.\n**Duração:** uma cena em exploração; 1+1d3 rodadas para duplicatas.\n**Defesa das duplicatas:** duas cópias.\n**Resistência:** Percepção com Lucidez contra Ocultismo com Lucidez.\n**Concentração:** apenas para atuação dirigida de uma imitação.",
      "rules": "Use uma ação principal. Por **6 PL**, cria imagens e sons em uma área de até 3 m de lado a até 9 m, durante uma cena de exploração; dirigir a fala ou os movimentos de uma imitação exige concentração. Quem examina testa Percepção com Lucidez e pode reconhecer a falsidade. Por **18 PL**, cria duas duplicatas pessoais por 1+1d3 rodadas, sem concentração. Antes de cada ataque físico direto, o atacante faz o mesmo teste: falhar desperdiça o ataque e destrói uma cópia; vencer permite atacar normalmente. Mesmo quem já percebeu a ilusão testa de novo. Áreas e efeitos mentais não são desviados. Um aviso concede +5 apenas na próxima Percepção, sem somar vários avisos.",
      "costOptions": [
        {
          "label": "Ilusão ambiental",
          "cost": 6
        },
        {
          "label": "Duas duplicatas",
          "cost": 18
        }
      ]
    },
    {
      "name": "Bênção do Tempo",
      "cost": "14 / 23 / 32",
      "description": "Protege o aplicador ou um aliado, reduzindo cada dano em PV que ele sofrer durante o efeito. A intensidade escolhida determina a força dessa proteção.",
      "technical": "**Ação:** principal, antes de sofrer o dano.\n**Alcance:** 9 m.\n**Alvo:** uma criatura; não pode ser trocado.\n**Duração:** 1+1d3 rodadas.\n**Redução:** 1+1d6 / 2+1d8 / 3+1d10, rolada uma vez.\n**Resistência:** nenhuma em alvo voluntário.\n**Concentração:** não.",
      "rules": "Use uma ação principal para proteger a si ou uma criatura a até 9 m por **1+1d3 rodadas**. Escolha a intensidade: **14 PL** reduz 1+1d6, **23 PL** reduz 2+1d8 e **32 PL** reduz 3+1d10. Role uma única vez e mantenha o valor: ele reduz cada ocorrência de dano em PV, antes de bloqueio e armadura. Também protege contra dano contínuo, quedas e cotas recebidas por Elo, mas não contra perdas de PL. No atingido original de uma rede, reduza antes da divisão, sem reduzir outra vez sua própria cota. Não cura, não guarda redução sobrando, não troca de beneficiário e não acumula.",
      "costOptions": [
        {
          "label": "Reduzir 1 + 1d6",
          "cost": 14
        },
        {
          "label": "Reduzir 2 + 1d8",
          "cost": 23
        },
        {
          "label": "Reduzir 3 + 1d10",
          "cost": 32
        }
      ]
    },
    {
      "name": "Sombra Solta",
      "cost": 24,
      "description": "Permite explorar como um espectro invisível, imune a dano e capaz de atravessar paredes. O corpo fica inconsciente e vulnerável; para encerrar a projeção, é necessário encontrá-lo e tocá-lo.",
      "technical": "**Ação:** principal.\n**Alcance/alvo:** pessoal.\n**Exploração:** uma cena, até 100 m do ponto de saída.\n**Deslocamento espectral:** o normal do personagem, inclusive atravessando matéria e mudando de altura.\n**Retorno:** contato do espectro com o próprio corpo.\n**Concentração:** não.\n**Outras conjurações:** proibidas.",
      "rules": "Custa **24 PL**, usa uma ação principal e permite uma cena de exploração a até **100 m do ponto de saída**. O espectro se move na velocidade normal, atravessa matéria e muda de altura, mas não toca objetos, ataca ou conjura. Vê e ouve normalmente, sem visão especial no escuro, e pode falar pelo corpo físico. O corpo permanece inconsciente e vulnerável. Só tocar o próprio corpo encerra a projeção: ferir ou mover o corpo não causa retorno automático. Ao acabar a exploração, só pode retornar ou procurar o corpo, ultrapassando a área se ele tiver sido transportado. A projeção não impede a morte do corpo e não cobra PL por rodada."
    },
    {
      "name": "Vislumbre de Instantes",
      "cost": 38,
      "description": "Antecipa os movimentos de outras criaturas. Após uma preparação que inclui um turno inteiro de transe vulnerável, melhora Mira e Reflexo e permite alguns golpes corpo a corpo certeiros com dano máximo.",
      "technical": "**Ação/preparo:** principal na declaração; no turno seguinte, transe integral e vulnerável; benefício começa no terceiro turno da sequência.\n**Alcance:** pessoal; previsão de múltiplos alvos.\n**Duração/utilizações:** uma rolagem de 1+1d3 define ambos.\n**Resistência/concentração:** nenhuma.",
      "rules": "Custa **38 PL** e afeta o próprio aplicador. No primeiro turno, gaste a ação principal para iniciar; no segundo, fique em transe, sem ações ou reações; no terceiro, receba os benefícios. Role **1+1d3 uma única vez**: o resultado define as rodadas de duração e a quantidade de próximas tentativas de golpes corpo a corpo favorecidas. Durante o efeito, ganha vantagem em Mira e Reflexo. Esses golpes acertam sem esquiva, bloqueio ou contra-ataque e causam o máximo de todo dano legal, incluindo adicionais válidos. Armadura, reduções, barreiras e identificação correta do alvo continuam valendo. Cada tentativa consome uma utilização, inclusive contra uma duplicata. Não dá ataques extras; cair inconsciente cancela."
    },
    {
      "name": "Memória Intrusa",
      "cost": 16,
      "description": "Implanta a lembrança falsa de um acontecimento recente, sem reescrever a identidade do alvo. Em combate, pode fazê-lo acreditar que já reagiu, impedindo sua reação à próxima ameaça.",
      "technical": "**Ação:** livre, no próprio turno.\n**Frequência:** uma conjuração por aplicador por rodada.\n**Alcance:** 9 m.\n**Alvo:** uma criatura com mente própria.\n**Modalidade narrativa:** uma cena.\n**Modalidade de combate:** uma rodada ou até consumir a perda de reação, o que vier primeiro.\n**Resistência:** Vontade com Lucidez contra Ocultismo com Lucidez, na aplicação.\n**Concentração:** não.",
      "rules": "Custa **16 PL**, usa uma ação livre no próprio turno e só pode ser conjurada uma vez por rodada, em uma criatura com mente a até 9 m. O alvo resiste com Vontade com Lucidez. No uso narrativo, a lembrança falsa trata de um evento breve da cena ou da última hora e dura uma cena; provas concretas permitem novas resistências, e o alvo reconhece a falsidade quando acaba. Não muda identidade nem impõe obediência. No combate, dura uma rodada ou até a próxima ameaça hostil real: a vítima não reage àquela ocorrência, mas pode reagir depois dela. Não garante acerto nem remove proteções passivas. O uso de combate segue a proteção compartilhada; resistir à implantação narrativa impede novas tentativas na cena, salvo mudança concreta."
    },
    {
      "name": "Último Eco",
      "cost": "8 — vestígio / 24 — combate",
      "description": "Revela um breve vestígio de imagem e som deixado em um objeto ou local. Em combate, marca uma criatura para que cada dano sofrido em PV provoque um segundo dano de metade do valor, sem gerar ecos sucessivos.",
      "technical": "**Ação:** principal.\n**Vestígio:** toque em objeto ou ponto do cenário; fragmento sensorial de até 10 segundos, ocorrido nas últimas 24 horas; efeito instantâneo.\n**Combate:** uma criatura a até 9 m, por 1d4 rodadas.\n**Resistência em combate:** Vontade com Lucidez contra Ocultismo com Lucidez, na aplicação.\n**Eco:** metade do dano efetivo em PV de cada ocorrência, arredondada para baixo.\n**Concentração:** não.",
      "rules": "Use uma ação principal e escolha o efeito. Por **8 PL**, toque um objeto ou ponto do cenário para ver e ouvir até 10 segundos da última interação relevante nas últimas 24 horas, numa área de até 3 m. Não lê pensamentos; repetir um vestígio inalterado devolve o mesmo fragmento. Por **24 PL**, marque uma criatura a até 9 m por **1d4 rodadas**; ela resiste com Vontade com Lucidez. Cada ocorrência de dano realmente perdido em PV gera um novo dano de metade do valor, arredondado para baixo. Calcule após proteções e Elo, sem contar excesso além dos PV restantes. O eco não admite esquiva, bloqueio ou armadura, mas admite proteções mágicas aplicáveis, como Bênção, e a divisão por Elo. Resolva primeiro o dano original e suas cotas; depois, os ecos. O eco e suas cotas nunca geram outro eco. Dano em PL, sacrifícios de Oferenda e ajustes de Vampirismo não contam.",
      "costOptions": [
        {
          "label": "Ler vestígio",
          "cost": 8
        },
        {
          "label": "Marcar em combate",
          "cost": 24
        }
      ]
    }
  ]
};

export function getVisionCatalog() {
  return Object.entries(VISION_PATHS).flatMap(([path, abilities]) =>
    abilities.map((ability) => ({ path, ...ability }))
  );
}
