// Compatibilidade dos arquivos salvos com o catálogo atual.
import { MARKS, SINAS, getVisionCatalog } from "./data.js";
import { applyGrantedSkills, emptySkills, newCharacter, trainingBonus } from "./rules.js";

export function normalizeCharacter(character) {
  const fresh = newCharacter(character.mode || "free");
  const normalized = { ...fresh, ...character };
  normalized.identity = { ...fresh.identity, ...(character.identity || {}) };
  normalized.identity.gallery = Array.isArray(normalized.identity.gallery) ? normalized.identity.gallery : [];
  normalized.sina = SINAS[normalized.sina] ? normalized.sina : null;
  normalized.mark = MARKS[normalized.mark] ? normalized.mark : null;
  normalized.choices = { sina: { ...character.choices?.sina }, mark: { ...character.choices?.mark } };
  normalized.baseAttributes = { ...fresh.baseAttributes, ...(character.baseAttributes || character.attributes || {}) };
  normalized.attributes = { ...fresh.attributes, ...(character.attributes || {}) };
  normalized.skills = { ...emptySkills(), ...(character.skills || {}) };
  normalized.resources = { ...fresh.resources, ...(character.resources || {}) };
  normalized.death = { ...fresh.death, ...(character.death || {}) };
  normalized.deathSnapshot = character.deathSnapshot?.resources && character.deathSnapshot?.death ? character.deathSnapshot : null;
  normalized.meta = { lastExportAt: null, ...(character.meta || {}) };
  normalized.inventory = Array.isArray(character.inventory) ? structuredClone(character.inventory) : [];
  normalized.conditions = Array.isArray(character.conditions) ? structuredClone(character.conditions) : [];
  normalized.notes = Array.isArray(character.notes) ? character.notes : [];
  normalized.combat = { round: 0, weapons: [], armors: [], notes: "", ...(character.combat || {}) };
  normalized.combat.weapons = Array.isArray(normalized.combat.weapons) ? normalized.combat.weapons.map((weapon) => ({ ...weapon, effects: structuredClone(weapon.effects || []), ammoDie: weapon.type === "distancia" ? (weapon.ammoDie === undefined ? "d12" : weapon.ammoDie) : null })) : [];
  normalized.combat.armors = Array.isArray(normalized.combat.armors) ? structuredClone(normalized.combat.armors) : [];
  normalized.freeSkillsChosen = Array.isArray(character.freeSkillsChosen) ? [...character.freeSkillsChosen] : [];
  normalized.freeSettings = { resourceMode: normalized.sina ? "sina" : "manual", ...character.freeSettings, skillOverrides: { ...character.freeSettings?.skillOverrides } };

  // A antiga perícia vira Charme. Preserva-se o maior grau, sem somar treinos.
  const previousSkill = "Persuasão";
  if (trainingBonus(normalized.skills[previousSkill]) > trainingBonus(normalized.skills.Charme)) normalized.skills.Charme = normalized.skills[previousSkill];
  delete normalized.skills[previousSkill];
  const overrides = normalized.freeSettings.skillOverrides;
  if (previousSkill in overrides) {
    if (!("Charme" in overrides) || trainingBonus(overrides[previousSkill]) > trainingBonus(overrides.Charme)) overrides.Charme = overrides[previousSkill];
    delete overrides[previousSkill];
  }
  normalized.freeSkillsChosen = [...new Set(normalized.freeSkillsChosen.map((skill) => skill === previousSkill ? "Charme" : skill))];
  for (const choices of Object.values(normalized.choices)) {
    Object.keys(choices).forEach((key) => { if (choices[key] === previousSkill) choices[key] = "Charme"; });
  }
  for (const entry of [...normalized.inventory, ...normalized.conditions, ...normalized.combat.weapons, ...normalized.combat.armors]) {
    (entry.effects || []).forEach((effect) => { if (effect.target === previousSkill) effect.target = "Charme"; });
  }
  const catalog = getVisionCatalog();
  normalized.visionAbilities = (Array.isArray(character.visionAbilities) ? character.visionAbilities : []).map((ability) => {
    const updated = catalog.find((entry) => entry.name === ability.name);
    return { ...ability, ...(updated || {}), id: ability.id || crypto.randomUUID(), legacy: !updated };
  });
  if (Number(character.rulesRevision || 0) < 8) {
    // Atletas antigos recebiam Luta; essa continua sendo sua escolha inicial.
    if (normalized.mark === "Atleta" && !normalized.choices.mark.combate) normalized.choices.mark.combate = "Luta";
    // Os arquivos antigos não registravam a origem de cada treino: não apagamos
    // progressos que podem ter sido comprados ou editados pelo jogador.
    applyGrantedSkills(normalized);
  }
  normalized.rulesRevision = 8;
  return normalized;
}
