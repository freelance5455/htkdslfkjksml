// A preferência de aparência pertence ao aparelho, não ao personagem.
const THEME_KEY = "visionarios-theme";

export function applyTheme(theme) {
  const light = theme === "light";
  document.documentElement.dataset.theme = light ? "light" : "dark";
  document.querySelector('meta[name="theme-color"]').content = light ? "#f8f1e7" : "#130f1c";
  document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
    button.textContent = light ? "Modo escuro" : "Modo claro";
    button.setAttribute("aria-pressed", String(light));
  });
  try { localStorage.setItem(THEME_KEY, light ? "light" : "dark"); } catch { /* A ficha também abre sem preferência salva. */ }
}

export function themeButton() {
  const light = document.documentElement.dataset.theme === "light";
  return `<button class="button ghost theme-toggle" data-action="toggle-theme" data-theme-toggle aria-pressed="${light}">${light ? "Modo escuro" : "Modo claro"}</button>`;
}

let saved = "dark";
try { saved = localStorage.getItem(THEME_KEY) || "dark"; } catch { /* Tema padrão. */ }
applyTheme(saved);
