const CACHE_NAME = "ficha-rpg-v8";
const APP_FILES = [
  "./",
  "./index.html",
  "./css/style.css",
  "./js/data.js",
  "./js/rules.js",
  "./js/explanations.js",
  "./js/storage.js",
  "./js/app.js",
  "./js/character.js",
  "./js/theme.js",
  "./icons/visionarios-color.png",
  "./icons/visionarios-mono.png",
  "./manifest.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_FILES)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request)));
});
