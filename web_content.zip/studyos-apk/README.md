# StudyOS APK (GitHub diye build)

GitHub shudhu APK **banay** (internet lage ekbar). APK install hoye gele app ar notification **internet chhara** kaj kore.

## Step by step (phone browser e hobe, "Desktop site" on kore nile shohoj)
1. github.com e account kholo. New repository -> naam `studyos` -> Private -> Create.
2. **Add file -> Upload files**. Ei 7 ta file upload koro (zip extract kore):
   `studyos.html`, `package.json`, `capacitor.config.json`, `icon-only.png`, `icon-foreground.png`, `icon-background.png`, `debug.keystore`
   -> Commit changes.
3. **Add file -> Create new file**. Naam e lekho: `.github/workflows/build-apk.yml`
   (slash gulo likhle folder nijei hoy). `build-apk.yml` file ta khule shob text copy kore ekhane paste koro -> Commit.
4. **Actions** tab -> "Build StudyOS APK" -> **Run workflow**. 5-10 minute lage.
5. Kaj shesh hole oi run e click koro -> niche **Artifacts** -> `StudyOS-apk` download -> extract -> `app-debug.apk` install koro
   (Android "unknown source" allow korte bolbe, Play Protect warning dile "Install anyway").

## Notification
- App prothom khule **Profile -> Notifications -> Allow** dao. Android 13+ e popup ashle **Allow**.
- Routine, revision, exam goal, roj Fuyu reminder: shob phone er bhitore schedule hoy. **Internet lage na.**
- Reminder deri hole: Settings -> Apps -> StudyOS -> Battery -> **Unrestricted**, ar "Alarms & reminders" allow koro.
  (Xiaomi/Oppo/Vivo/Realme e ta khub dorkar.)
- Phone restart dile o reminder fire ashe. Tobe ekbar app khule dekhao bhalo.

## Update korte chaile
`studyos.html` replace koro (GitHub e file e click -> edit/upload) -> Actions e abar Run workflow -> notun APK ager ta r upor install koro.
`debug.keystore` same thakle data mushe jay na.

## Joruri
- App **uninstall** korle data jay. Age Settings -> **Export backup** koro.
- Ei APK ta personal use er (debug). Google Play e dite hole pore release signing lagbe.
- Build fail korle: failed step khule error er screenshot pathao.
