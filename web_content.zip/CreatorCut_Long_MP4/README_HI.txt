CreatorCut PRO v3 — Enhanced All-in-One Video Editor
=====================================================

यह Node.js + FFmpeg पर आधारित self-hosted single-clip video editor है।

मुख्य सुविधाएँ
-------------
- MP4, MOV, MKV, WEBM, AVI आदि वीडियो इम्पोर्ट और ब्राउज़र प्रीव्यू
- वीडियो Trim Start / End
- Playback Speed 0.25x से 4x
- Rotate 90/180/270 डिग्री, Horizontal / Vertical Flip
- Original, 16:9, 9:16, 1:1 और 4:5 canvas formats
- 360p, 480p, 720p, 1080p output; 24/25/30/50/60 FPS
- Brightness, Contrast, Saturation और Original Audio Volume
- Optional background music track (मूल ऑडियो को replace करता है), Music Volume
- Fade In / Fade Out और Mute
- Video पर Text / Title overlay; Top / Center / Bottom और basic text colors
- MP4 H.264 + AAC export, faststart, progress status और download
- Project settings JSON में Save / Load
- Session के भीतर settings के लिए Undo / Redo

इंस्टॉल और रन
-------------
1. Node.js 20 या नया इंस्टॉल करें।
2. इस फ़ोल्डर में terminal खोलें।
3. npm install
4. npm start
5. http://localhost:3000 खोलें।

Environment variables
---------------------
- PORT: server port (default 3000)
- DATA_DIR: input/output storage directory (default OS temp directory)
- MAX_UPLOAD_BYTES: प्रति फ़ाइल upload limit bytes में (default 50 GiB)

ज़रूरी deployment जानकारी
-------------------------
- FFmpeg binary `ffmpeg-static` package से आता है।
- बड़ी वीडियो के लिए पर्याप्त RAM, CPU, disk space और तेज़ नेटवर्क चाहिए।
- Hosting provider की request-size और execution-time limits भी लागू होंगी।
- `DATA_DIR` को persistent disk पर रखें यदि output files को restart के बाद बचाना है।
- Public deployment से पहले HTTPS, authentication, per-user quotas, rate limiting,
  storage cleanup/retention policy, monitoring और access controls लगाएँ।
- ऐप में फिलहाल login/multi-user access control नहीं है। इसे बिना सुरक्षा के public internet पर expose न करें।
- Job status process memory में रखा जाता है; server restart होने पर active jobs की स्थिति खो सकती है।
- डाउनलोड फाइलें persistent output folder में रहेंगी; production में scheduled cleanup जोड़ें।

ईमानदार सीमाएँ
-------------
यह v3 बेहतर single-clip editor है, पूर्ण professional NLE नहीं। इसमें अभी:
- Multi-clip timeline / split-and-merge timeline नहीं
- Multiple video layers, transitions, keyframe animation और motion tracking नहीं
- Stickers, image overlays, chroma key / green screen नहीं
- Subtitle (SRT) editor और auto captions नहीं
- Multi-track audio mixing नहीं; चुना गया music मूल audio को replace करता है
- Cloud project sync / account login नहीं
- Undo/Redo केवल मौजूदा browser session के settings changes के लिए है
- Project JSON में media files नहीं, केवल settings सेव होती हैं
- Hindi title rendering server पर उपलब्ध fonts और FFmpeg build पर निर्भर है

इसलिए इसे “हर तरह की editing में कोई कमी नहीं” या unlimited editor नहीं कहा जा सकता।
यह एक उपयोगी, विस्तार योग्य self-hosted editor है; वास्तविक क्षमता आपके server/hosting पर निर्भर है।

Privacy
-------
वीडियो processing के लिए files आपके चलाए हुए server पर upload होती हैं। निजी वीडियो के लिए
अपना भरोसेमंद HTTPS server इस्तेमाल करें और public deployment से पहले authentication तथा
automatic file deletion लागू करें।


========================================
VERSION 4.0 - ADVANCED EXPORT + SOURCE CODE
========================================

नए Export विकल्प:
- 4K UHD: 3840 x 2160 (2160p)
- 2K QHD: 2560 x 1440 (1440p)
- Full HD: 1920 x 1080 (1080p)
- HD: 1280 x 720 (720p)
- SD: 854 x 480 (480p)
- 360p: 640 x 360
- Frame rate: 30 FPS या 60 FPS
- Container: MP4
- Video: H.264 / libx264, High Profile, yuv420p
- Audio: AAC, 192 kbps, 48 kHz (जब audio mute न हो)
- Encoding और processing: FFmpeg (ffmpeg-static)

ENGLISH PROGRAMMING SOURCE CODE:
- server.js: Node.js + Express backend, upload handling, FFmpeg arguments, export jobs, progress, status और download API.
- public/index.html: HTML, CSS और JavaScript frontend, controls, preview, settings, upload और export UI.
- package.json: Node.js dependencies और start script.

चलाने के लिए:
1. Node.js 20 या नया संस्करण इंस्टॉल करें।
2. इस फ़ोल्डर में Terminal / Command Prompt खोलें।
3. npm install चलाएँ।
4. npm start चलाएँ।
5. ब्राउज़र में http://localhost:3000 खोलें।

ध्यान दें: 4K/60 FPS के लिए तेज CPU, पर्याप्त RAM, खाली डिस्क स्पेस और अच्छी hosting की जरूरत पड़ सकती है। Export की वास्तविक गति डिवाइस और input video पर निर्भर करेगी। Source code में export controls और FFmpeg implementation English में लिखे गए हैं।
