const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(os.tmpdir(), 'creatorcut-data');
const INPUT_DIR = path.join(DATA_DIR, 'input');
const OUTPUT_DIR = path.join(DATA_DIR, 'output');
for (const dir of [INPUT_DIR, OUTPUT_DIR]) fs.mkdirSync(dir, { recursive: true });
const ffmpegPath = require('ffmpeg-static');
const MAX_UPLOAD = Number(process.env.MAX_UPLOAD_BYTES || 50 * 1024 * 1024 * 1024);
const upload = multer({ dest: INPUT_DIR, limits: { fileSize: MAX_UPLOAD, files: 2 }, fileFilter: (_req, file, cb) => {
  const allowed = file.fieldname === 'video' ? (/^video\//i.test(file.mimetype) || /\.(mp4|mov|mkv|webm|m4v|avi|mpeg|mpg)$/i.test(file.originalname)) : file.fieldname === 'music' ? (/^audio\//i.test(file.mimetype) || /\.(mp3|wav|m4a|aac|ogg|flac)$/i.test(file.originalname)) : false;
  cb(allowed ? null : new Error('कृपया समर्थित वीडियो या ऑडियो फ़ाइल चुनें।'), allowed);
}});
app.use(express.static(path.join(__dirname, 'public')));
const jobs = new Map();
const clamp = (v, min, max, fallback) => Number.isFinite(Number(v)) ? Math.max(min, Math.min(max, Number(v))) : fallback;
function atempoChain(speed) { const parts=[]; while(speed>2){parts.push('atempo=2');speed/=2;} while(speed<0.5){parts.push('atempo=0.5');speed/=0.5;} parts.push(`atempo=${speed}`); return parts.join(','); }
function runFFmpeg(args, id, duration) {
 return new Promise((resolve,reject)=>{
  const proc=spawn(ffmpegPath,args,{stdio:['ignore','ignore','pipe']}); let err='';
  proc.stderr.on('data',b=>{err+=b.toString(); if(err.length>16000)err=err.slice(-16000); const m=err.match(/time=(\d+):(\d+):(\d+(?:\.\d+)?)/g); if(m){const z=m[m.length-1].match(/time=(\d+):(\d+):(\d+(?:\.\d+)?)/); const sec=+z[1]*3600 + +z[2]*60 + +z[3]; jobs.set(id,{...jobs.get(id),status:'processing',progress:duration?Math.min(99,Math.round(sec/duration*100)):null,log:m[m.length-1]});}});
  proc.on('error',reject); proc.on('close',code=>code===0?resolve():reject(new Error(err.slice(-2200)||`FFmpeg exit ${code}`)));
 });
}
app.get('/api/health',(_req,res)=>res.json({ok:true,engine:'FFmpeg',maxUploadBytes:MAX_UPLOAD,features:['trim','crop','aspect ratio','rotate','flip','speed','volume','music replacement','text overlay','brightness','contrast','saturation','fade','resolution','fps','MP4 H.264/AAC']}));
app.post('/api/export',upload.fields([{name:'video',maxCount:1},{name:'music',maxCount:1}]),async(req,res)=>{
 const video=req.files?.video?.[0]; const music=req.files?.music?.[0];
 if(!video)return res.status(400).json({error:'वीडियो फ़ाइल नहीं मिली।'});
 const id=crypto.randomUUID(), outputName=`CreatorCut_${id}.mp4`, output=path.join(OUTPUT_DIR,outputName);
 const start=clamp(req.body.start,0,1e8,0), end=clamp(req.body.end,0,1e8,0), speed=clamp(req.body.speed,0.25,4,1);
 if(end && end<=start){fs.unlink(video.path,()=>{});if(music)fs.unlink(music.path,()=>{});return res.status(400).json({error:'End समय, Start समय से बड़ा होना चाहिए।'});}
 const width=[3840,2560,1920,1280,854,640].includes(+req.body.width)?+req.body.width:1920;
 const fps=[30,60].includes(+req.body.fps)?+req.body.fps:30;
 const crf=clamp(req.body.quality,18,28,23), ratio=['original','16:9','9:16','1:1','4:5'].includes(req.body.ratio)?req.body.ratio:'original';
 const musicVolume=clamp(req.body.musicVolume,0,2,0.8), brightness=clamp(req.body.brightness,-0.5,0.5,0), contrast=clamp(req.body.contrast,0.5,2,1), saturation=clamp(req.body.saturation,0,2,1), volume=clamp(req.body.volume,0,2,1);
 const rotate=['0','90','180','270'].includes(req.body.rotate)?req.body.rotate:'0';
 const textPosition=['top','center','bottom'].includes(req.body.textPosition)?req.body.textPosition:'bottom';
 const textColor=/^(white|yellow|black|red|blue|green)$/i.test(req.body.textColor||'')?req.body.textColor:'white';
 const text=(req.body.overlayText||'').toString().slice(0,120).replace(/\\/g,'\\\\').replace(/:/g,'\\:').replace(/'/g,"\\'").replace(/%/g,'\\%').replace(/,/g,'\\,').replace(/\[/g,'\\[').replace(/\]/g,'\\]');
 const args=['-y','-hide_banner','-i',video.path]; if(music)args.push('-stream_loop','-1','-i',music.path);
 if(start>0)args.push('-ss',String(start)); if(end>0)args.push('-t',String((end-start)/speed));
 const vf=[];
 if(rotate==='90')vf.push('transpose=1'); if(rotate==='270')vf.push('transpose=2'); if(rotate==='180')vf.push('hflip','vflip');
 if(req.body.flipH==='true')vf.push('hflip'); if(req.body.flipV==='true')vf.push('vflip');
 if(ratio==='original')vf.push(`scale=${width}:-2`);
 else {const dims={'16:9':[16,9],'9:16':[9,16],'1:1':[1,1],'4:5':[4,5]}[ratio]; vf.push(`scale=${width}:${Math.round(width*dims[1]/dims[0])}:force_original_aspect_ratio=increase,crop=${width}:${Math.round(width*dims[1]/dims[0])}`);}
 vf.push(`fps=${fps}`); if(brightness!==0||contrast!==1||saturation!==1)vf.push(`eq=brightness=${brightness}:contrast=${contrast}:saturation=${saturation}`);
 if(req.body.fadeIn==='true')vf.push('fade=t=in:st=0:d=1'); if(req.body.fadeOut==='true' && end>0)vf.push(`fade=t=out:st=${Math.max(0,(end-start)/speed-1)}:d=1`);
 if(text){const y=textPosition==='top'?'h*0.07':textPosition==='center'?'(h-text_h)/2':'h-text_h-h*0.07';vf.push(`drawtext=text='${text}':fontcolor=${textColor}:fontsize=h/18:borderw=3:bordercolor=black@0.75:x=(w-text_w)/2:y=${y}`);}
 if(speed!==1)vf.push(`setpts=${1/speed}*PTS`);
 args.push('-vf',vf.join(','),'-c:v','libx264','-profile:v','high','-preset','veryfast','-crf',String(crf),'-pix_fmt','yuv420p','-r',String(fps),'-fps_mode','cfr');
 if(music){args.push('-map','0:v:0','-map','1:a:0','-af',`volume=${musicVolume}`,'-c:a','aac','-b:a','192k','-shortest');}
 else if(req.body.mute==='true')args.push('-an'); else args.push('-c:a','aac','-b:a','192k','-af',`${speed!==1?atempoChain(speed)+',':''}volume=${volume}`,'-ar','48000');
 args.push('-movflags','+faststart','-max_muxing_queue_size','2048',output);
 jobs.set(id,{status:'queued',outputName,created:Date.now(),progress:0,log:''}); res.json({jobId:id,status:'queued'});
 try{jobs.set(id,{...jobs.get(id),status:'processing'}); await runFFmpeg(args,id, end>0?(end-start):0); jobs.set(id,{...jobs.get(id),status:'done',progress:100,download:`/api/download/${outputName}`});}
 catch(e){jobs.set(id,{...jobs.get(id),status:'error',error:String(e.message||e).slice(-2200)});fs.unlink(output,()=>{});}
 finally{fs.unlink(video.path,()=>{});if(music)fs.unlink(music.path,()=>{});}
});
app.get('/api/status/:id',(req,res)=>{const j=jobs.get(req.params.id);if(!j)return res.status(404).json({error:'Export job नहीं मिला।'});res.json(j);});
app.get('/api/download/:name',(req,res)=>{const name=path.basename(req.params.name);if(!/^CreatorCut_[a-f0-9-]+\.mp4$/i.test(name))return res.sendStatus(400);const file=path.join(OUTPUT_DIR,name);if(!fs.existsSync(file))return res.status(404).send('फ़ाइल उपलब्ध नहीं है।');res.download(file,name);});
app.use((err,_req,res,_next)=>{const msg=err.code==='LIMIT_FILE_SIZE'?'अपलोड सीमा पार हो गई। सर्वर की MAX_UPLOAD_BYTES सेटिंग बढ़ाएँ।':(err.message||'कुछ गड़बड़ हुई।');res.status(400).json({error:msg});});
app.listen(PORT,()=>console.log(`CreatorCut PRO running on port ${PORT}`));
