(() => {
  let selectedChannel = 'whatsapp';
  const phone = document.querySelector('#message2Phone');
  const text = document.querySelector('#message2Text');
  const send = document.querySelector('#message2Send');
  const status = document.querySelector('#message2Status');
  const note = document.querySelector('#message2Note');
  const imageViewer = document.querySelector('#message2ImageViewer');

  function chooseChannel(channel) {
    selectedChannel = channel === 'sms' ? 'sms' : 'whatsapp';
    const whatsapp = document.querySelector('#message2WhatsApp');
    const sms = document.querySelector('#message2Sms');
    whatsapp.classList.toggle('active', selectedChannel === 'whatsapp');
    sms.classList.toggle('active', selectedChannel === 'sms');
    whatsapp.setAttribute('aria-pressed', String(selectedChannel === 'whatsapp'));
    sms.setAttribute('aria-pressed', String(selectedChannel === 'sms'));
    send.textContent = selectedChannel === 'sms' ? 'Abrir SMS para revisar e enviar' : 'Continuar no WhatsApp';
    send.classList.toggle('sms', selectedChannel === 'sms');
    note.textContent = selectedChannel === 'sms'
      ? 'O app de SMS abre com número e texto prontos. Confira e toque em Enviar; podem valer cobranças da operadora.'
      : 'O WhatsApp abre a conversa com a mensagem pronta. Confira e toque em Enviar no WhatsApp.';
    status.textContent = '';
  }

  function sendMessage() {
    const number = phone.value.replace(/\D/g, '');
    const message = text.value.trim();
    if (number.length < 10 || !message) {
      status.textContent = 'Informe um número válido e escreva a mensagem.';
      return;
    }
    status.textContent = '';
    if (selectedChannel === 'sms') {
      if (window.AndroidApp && typeof window.AndroidApp.sendSmsMessage === 'function') {
        window.AndroidApp.sendSmsMessage(number, message);
      } else {
        window.location.href = 'sms:' + number + '?body=' + encodeURIComponent(message);
      }
      return;
    }
    if (window.AndroidApp && typeof window.AndroidApp.sendWhatsAppMessage === 'function') {
      window.AndroidApp.sendWhatsAppMessage(number, message);
    } else {
      window.location.href = 'https://wa.me/' + number + '?text=' + encodeURIComponent(message);
    }
  }

  document.querySelector('#message2WhatsApp').addEventListener('click', () => chooseChannel('whatsapp'));
  document.querySelector('#message2Sms').addEventListener('click', () => chooseChannel('sms'));
  send.addEventListener('click', sendMessage);
  document.querySelector('#message2Back').addEventListener('click', () => { if (typeof window.goHome === 'function') window.goHome(); });
  document.querySelector('#message2ChooseContact').addEventListener('click', () => {
    if (window.AndroidApp && typeof window.AndroidApp.pickWhatsAppContact === 'function') {
      window.AndroidApp.pickWhatsAppContact();
    } else {
      status.textContent = 'Digite o número manualmente no campo acima.';
    }
  });
  document.querySelectorAll('[data-message2-image]').forEach(button => button.addEventListener('click', () => {
    const image = document.querySelector('#message2ImageFull');
    image.src = button.dataset.message2Image;
    image.alt = button.dataset.message2Alt || 'Imagem de referência';
    imageViewer.hidden = false;
  }));
  document.querySelector('#message2ImageClose').addEventListener('click', () => { imageViewer.hidden = true; });
  imageViewer.addEventListener('click', event => { if (event.target === imageViewer) imageViewer.hidden = true; });
  window.addEventListener('keydown', event => { if (event.key === 'Escape' && !imageViewer.hidden) imageViewer.hidden = true; });

  window.setMessage2Contact = (name, number) => {
    document.querySelector('#message2ContactName').value = name || '';
    phone.value = number || '';
  };
  chooseChannel('whatsapp');
})();
