/* =========================================================
   مَلاذ — Malath 1.0.0
   Vanilla JavaScript application engine
   Navigation • History • Scroll • Search • Calculators
   Local storage • Records • Backup • Theme • Accessibility
   ========================================================= */
(() => {
  "use strict";

  const APP = Object.freeze({
    version: "1.0.0",
    storageKey: "malath.app.state.v1",
    defaultPage: "home",
    maxRecords: 500,
    maxBackupBytes: 2 * 1024 * 1024,
    inventoryTypes: Object.freeze({
      water: { unit: "لتر", label: "الماء" },
      food: { unit: "وحدة", label: "الغذاء" },
      energy: { unit: "وحدة", label: "الطاقة" }
    }),
    recordTypes: Object.freeze({
      water: "ماء",
      food: "غذاء",
      energy: "طاقة",
      hygiene: "نظافة",
      other: "أخرى"
    })
  });

  const body = document.body;

  const qs = (selector, scope = document) => scope.querySelector(selector);
  const qsa = (selector, scope = document) =>
    Array.from(scope.querySelectorAll(selector));

  const pages = new Map(
    qsa(".page[data-malath-view='page']")
      .map((page) => [page.id, page])
      .filter(([id]) => Boolean(id))
  );

  const navButtons = qsa("[data-target]");
  const state = createDefaultState();

  const runtime = {
    initialized: false,
    navigationLocked: false,
    navigationSequence: 0,
    currentPage: APP.defaultPage,
    toastTimer: null,
    clockTimer: null,
    confirmationAction: null,
    amountAction: null,
    modalReturnFocus: null,
    searchFrame: 0
  };

  let storageAvailable = canUseStorage();

  init().catch((error) => {
    reportError("فشل تهيئة التطبيق", error);
    setAppReady();
    showToast(
      "تعذر تهيئة جزء من البيانات المحلية. سيبقى المحتوى الأساسي متاحًا.",
      "warning"
    );
  });

  async function init() {
    if (runtime.initialized) return;
    runtime.initialized = true;

    loadState();
    applyTheme();
    applyFontSize();
    hydrateCalculatorInputs();
    hydrateFamilyNeeds();
    bindEvents();
    startClock();
    syncStorageStatus();
    renderInventory();
    renderRecords();
    restoreChecklistState();
    updateNavigationState();

    const requestedPage = getHashPage();
    prepareInitialHistory(requestedPage);

    await navigateTo(requestedPage || APP.defaultPage, {
      history: "none",
      source: "boot"
    });

    setAppReady();
  }

  function createDefaultState() {
    return {
      version: APP.version,
      theme: "dark",
      fontSize: "normal",
      inventory: {
        water: {
          value: 0,
          lastUpdated: 0,
          dailyRate: 0
        },
        food: {
          value: 0,
          lastUpdated: 0,
          dailyRate: 0
        },
        energy: {
          value: 0,
          lastUpdated: 0,
          dailyRate: 0,
          efficiency: 100
        }
      },
      calculators: {
        water: {
          people: 1,
          rate: 3,
          stock: 0,
          reserve: 10
        },
        food: {
          people: 1,
          rate: 0.5,
          stock: 0,
          reserve: 10
        },
        shelter: {
          length: 3,
          width: 3,
          height: 2.2,
          count: 1
        },
        energy: {
          daily: 0,
          stock: 0,
          efficiency: 90,
          reserve: 10
        }
      },
      checklists: {},
      records: [],
      meta: {
        updatedAt: Date.now()
      },
      family: {
        people: 1,
        children: 0,
        seniors: 0,
        disabilities: 0,
        healthNeeds: "",
        otherNeeds: "",
        updatedAt: 0
      }
    };
  }

  function loadState() {
    if (!storageAvailable) return;

    try {
      const raw = localStorage.getItem(APP.storageKey);
      if (!raw) return;

      const parsed = JSON.parse(raw);
      normalizeIntoState(parsed);
    } catch (error) {
      storageAvailable = false;
      reportError("تعذر قراءة البيانات المحلية", error);
    }
  }

  function normalizeIntoState(source) {
    if (!source || typeof source !== "object") return;

    state.theme = source.theme === "light" ? "light" : "dark";

    state.fontSize = ["normal", "large", "xlarge"].includes(
      source.fontSize
    )
      ? source.fontSize
      : "normal";

    const inventory =
      source.inventory && typeof source.inventory === "object"
        ? source.inventory
        : {};

    for (const type of Object.keys(APP.inventoryTypes)) {
      const item =
        inventory[type] && typeof inventory[type] === "object"
          ? inventory[type]
          : {};

      state.inventory[type].value = finitePositive(item.value, 0);
      state.inventory[type].lastUpdated = finiteNonNegative(
        item.lastUpdated,
        0
      );
      state.inventory[type].dailyRate = finitePositive(
        item.dailyRate,
        0
      );
      state.inventory[type].efficiency = clamp(
        finitePositive(item.efficiency, 100),
        1,
        100
      );
    }

    const calculators =
      source.calculators && typeof source.calculators === "object"
        ? source.calculators
        : {};

    for (const name of Object.keys(state.calculators)) {
      const saved =
        calculators[name] && typeof calculators[name] === "object"
          ? calculators[name]
          : {};

      for (const key of Object.keys(state.calculators[name])) {
        if (Object.prototype.hasOwnProperty.call(saved, key)) {
          state.calculators[name][key] = finiteNonNegative(
            saved[key],
            state.calculators[name][key]
          );
        }
      }
    }

    state.checklists =
      source.checklists && typeof source.checklists === "object"
        ? sanitizeChecklistMap(source.checklists)
        : {};

    state.records = Array.isArray(source.records)
      ? source.records
          .slice(0, APP.maxRecords)
          .map(normalizeRecord)
          .filter(Boolean)
      : [];

    const family =
      source.family && typeof source.family === "object"
        ? source.family
        : {};

    state.family.people = Math.max(
      1,
      Math.floor(
        finiteNonNegative(
          family.people,
          1
        )
      )
    );

    state.family.children = Math.max(
      0,
      Math.floor(
        finiteNonNegative(
          family.children,
          0
        )
      )
    );

    state.family.seniors = Math.max(
      0,
      Math.floor(
        finiteNonNegative(
          family.seniors,
          0
        )
      )
    );

    state.family.disabilities = Math.max(
      0,
      Math.floor(
        finiteNonNegative(
          family.disabilities,
          0
        )
      )
    );

    state.family.healthNeeds =
      String(
        family.healthNeeds || ""
      ).slice(0, 1000);

    state.family.otherNeeds =
      String(
        family.otherNeeds || ""
      ).slice(0, 1000);

    state.family.updatedAt =
      finiteNonNegative(
        family.updatedAt,
        0
      );

    state.meta.updatedAt = Date.now();
  }

  function saveState() {
    state.meta.updatedAt = Date.now();

    if (!storageAvailable) return false;

    try {
      localStorage.setItem(APP.storageKey, JSON.stringify(state));
      return true;
    } catch (error) {
      storageAvailable = false;
      reportError("تعذر حفظ البيانات المحلية", error);
      syncStorageStatus();
      return false;
    }
  }

  function bindEvents() {
    document.addEventListener(
      "click",
      handleDocumentClick,
      { passive: false }
    );

    document.addEventListener(
      "input",
      handleDocumentInput,
      { passive: true }
    );

    document.addEventListener(
      "change",
      handleDocumentChange,
      { passive: true }
    );

    document.addEventListener(
      "submit",
      handleDocumentSubmit,
      { passive: false }
    );

    document.addEventListener(
      "reset",
      handleDocumentReset,
      { passive: true }
    );

    window.addEventListener(
      "popstate",
      handleHistoryEvent
    );

    window.addEventListener(
      "hashchange",
      handleHistoryEvent
    );

    document.addEventListener(
      "keydown",
      handleKeyDown
    );

    window.addEventListener(
      "storage",
      handleExternalStorageUpdate
    );

    window.addEventListener(
      "resize",
      () => {
        if (!runtime.currentPage) return;

        if (isMobileWidth()) {
          closeSidebar();
        }
      },
      { passive: true }
    );
  }

  async function handleDocumentClick(event) {
    const target = event.target.closest(
      "button, a, [data-scroll-to]"
    );

    if (!target) return;

    const navTarget = target.closest("[data-target]");

    if (
      navTarget &&
      navTarget.tagName === "BUTTON"
    ) {
      event.preventDefault();

      const destination =
        navTarget.getAttribute("data-target");

      if (destination) {
        const focusId =
          navTarget.getAttribute(
            "data-focus-calculator"
          );

        await navigateTo(destination, {
          history:
            navigationHistoryMode(destination),
          source: "user",
          focusId
        });
      }

      return;
    }

    if (target.closest("#settings-btn")) {
      event.preventDefault();

      navigateTo("settings", {
        history:
          navigationHistoryMode("settings"),
        source: "user"
      });

      return;
    }

    if (target.closest("#menu-toggle-btn")) {
      event.preventDefault();
      openSidebar();
      return;
    }

    if (
      target.closest("#close-sidebar-btn") ||
      target.closest("#sidebar-overlay")
    ) {
      event.preventDefault();
      closeSidebar();
      return;
    }

    if (
      target.closest("#theme-toggle-btn") ||
      target.closest("#settings-theme-toggle")
    ) {
      event.preventDefault();
      toggleTheme();
      return;
    }

    if (target.closest("#clear-search-btn")) {
      event.preventDefault();
      clearSearch();
      return;
    }

    const keywordButton =
      target.closest(".keyword-btn");

    if (keywordButton) {
      event.preventDefault();

      const input = qs("#global-search");

      if (input) {
        input.value =
          keywordButton.textContent.trim();

        performSearch(input.value);

        input.focus({
          preventScroll: true
        });
      }

      return;
    }

    const scrollTarget =
      target.closest("[data-scroll-to]");

    if (scrollTarget) {
      event.preventDefault();

      scrollToElement(
        scrollTarget.getAttribute(
          "data-scroll-to"
        )
      );

      return;
    }

    const focusCalculator =
      target.closest(
        "[data-focus-calculator]"
      );

    if (focusCalculator) {
      event.preventDefault();

      const destination =
        focusCalculator.getAttribute(
          "data-focus-calculator"
        );

      focusCalculatorIntoView(destination);
      return;
    }

    const checklistReset =
      target.closest(
        "[data-checklist-reset]"
      );

    if (checklistReset) {
      event.preventDefault();
      resetChecklist(checklistReset);
      return;
    }

    const familyAction =
      target.closest(
        "[data-family-action]"
      );

    if (familyAction) {
      event.preventDefault();

      handleFamilyAction(
        familyAction
      );

      return;
    }

    const calcAction =
      target.closest(
        "[data-calculator-action][data-calc-action]"
      );

    if (calcAction) {
      event.preventDefault();
      handleCalculatorAction(calcAction);
      return;
    }

    const stockAction =
      target.closest(
        "[data-stock-action][data-stock-type]"
      );

    if (stockAction) {
      event.preventDefault();

      openAmountModal(
        stockAction.getAttribute(
          "data-stock-type"
        ),
        stockAction.getAttribute(
          "data-stock-action"
        )
      );

      return;
    }

    const copyButton =
      target.closest(
        "[data-copy-address]"
      );

    if (copyButton) {
      event.preventDefault();
      await copyAddress(copyButton);
      return;
    }

    const backupExport =
      target.closest(
        "[data-backup-export]"
      );

    if (backupExport) {
      event.preventDefault();
      exportBackup();
      return;
    }

    const backupImport =
      target.closest(
        "[data-backup-import]"
      );

    if (backupImport) {
      event.preventDefault();
      triggerBackupPicker(backupImport);
      return;
    }

    const clearData =
      target.closest(
        "[data-clear-local-data]"
      );

    if (clearData) {
      event.preventDefault();

      openConfirmModal(
        "حذف البيانات المحلية؟",
        "سيؤدي هذا إلى حذف السجلات والمخزونات والإعدادات المحفوظة على هذا الجهاز.",
        clearLocalData
      );

      return;
    }

    const resetApp =
      target.closest(
        "[data-reset-app]"
      );

    if (resetApp) {
      event.preventDefault();

      openConfirmModal(
        "إعادة ضبط مَلاذ؟",
        "ستعود الإعدادات والمخزونات والسجلات والقوائم إلى حالتها الافتراضية.",
        resetApplication
      );

      return;
    }

    const recordDelete =
      target.closest(
        "[data-record-delete]"
      );

    if (recordDelete) {
      event.preventDefault();

      const recordId =
        recordDelete.getAttribute(
          "data-record-delete"
        );

      openConfirmModal(
        "حذف السجل؟",
        "لن يؤثر حذف هذا السجل في خزان الموارد المحفوظ.",
        () => deleteRecord(recordId)
      );

      return;
    }

    const shareButton =
      target.closest(
        "[data-action='share']"
      );

    if (shareButton) {
      event.preventDefault();
      await shareApplication();
      return;
    }

    if (target.closest("[data-modal-cancel]")) {
      event.preventDefault();
      closeConfirmModal();
      return;
    }

    if (target.closest("[data-modal-confirm]")) {
      event.preventDefault();

      const action =
        runtime.confirmationAction;

      closeConfirmModal();

      if (typeof action === "function") {
        await safeAction(
          action,
          "تعذر تنفيذ العملية."
        );
      }

      return;
    }

    if (target.closest("[data-amount-cancel]")) {
      event.preventDefault();
      closeAmountModal();
      return;
    }

    if (target.closest("[data-amount-confirm]")) {
      event.preventDefault();
      await confirmAmountModal();
      return;
    }

    if (target.closest(".search-result-open")) {
      event.preventDefault();

      const result =
        target.closest(".search-result-open");

      const pageId =
        result.getAttribute(
          "data-result-page"
        );

      const selectorId =
        result.getAttribute(
          "data-result-node"
        );

      await navigateTo(pageId, {
        history:
          navigationHistoryMode(pageId),
        source: "search",
        focusId:
          selectorId || null
      });

      return;
    }
  }

  function handleDocumentInput(event) {
    const searchInput =
      event.target.closest(
        "#global-search"
      );

    if (searchInput) {
      window.cancelAnimationFrame(
        runtime.searchFrame
      );

      runtime.searchFrame =
        window.requestAnimationFrame(() => {
          performSearch(searchInput.value);
        });

      return;
    }

    const calcInput =
      event.target.closest(
        "[data-calculator] [data-calc-input]"
      );

    if (calcInput) {
      persistCalculatorInput(calcInput);
      return;
    }

    const familyField =
      event.target.closest(
        "#family-needs-calculator [data-family-input]"
      );

    if (familyField) {
      persistFamilyField(
        familyField
      );
    }
  }

  function handleDocumentChange(event) {
    const checkbox =
      event.target.closest(
        "[data-checklist-item]"
      );

    if (checkbox) {
      persistChecklist(checkbox);
      return;
    }

    const fontSelect =
      event.target.closest(
        "#font-size-setting"
      );

    if (fontSelect) {
      state.fontSize =
        [
          "normal",
          "large",
          "xlarge"
        ].includes(fontSelect.value)
          ? fontSelect.value
          : "normal";

      applyFontSize();
      saveState();

      showToast(
        "تم تحديث حجم النص.",
        "success"
      );

      return;
    }

    const backupFile =
      event.target.closest(
        "[data-backup-file]"
      );

    if (
      backupFile &&
      backupFile.files &&
      backupFile.files[0]
    ) {
      importBackupFile(
        backupFile.files[0],
        backupFile
      );
    }
  }

  function handleDocumentSubmit(event) {
    const form =
      event.target.closest(
        "#resource-record-form"
      );

    if (!form) return;

    event.preventDefault();
    saveRecordFromForm(form);
  }

  function handleDocumentReset(event) {
    const form =
      event.target.closest(
        "#resource-record-form"
      );

    if (!form) return;

    const result =
      qs("#record-action-result");

    if (result) {
      result.className =
        "action-result-card hidden";

      result.textContent = "";
    }

    requestAnimationFrame(() => {
      const name =
        qs("#record-name");

      const quantity =
        qs("#record-quantity");

      const unit =
        qs("#record-unit");

      const note =
        qs("#record-note");

      if (name) name.value = "";
      if (quantity) quantity.value = "";
      if (unit) unit.value = "";
      if (note) note.value = "";
    });
  }

  function handleHistoryEvent() {
    const destination =
      getHashPage() || APP.defaultPage;

    navigateTo(destination, {
      history: "none",
      source: "history"
    }).catch((error) => {
      reportError(
        "فشل التنقل التاريخي",
        error
      );

      navigateTo(
        APP.defaultPage,
        {
          history: "replace",
          source: "recovery"
        }
      ).catch(() => {});
    });
  }

  function handleKeyDown(event) {
    if (event.key === "Escape") {
      const amountModal =
        qs("#malath-amount-modal");

      if (
        amountModal &&
        !amountModal.classList.contains(
          "hidden"
        )
      ) {
        closeAmountModal();
        return;
      }

      const confirmModal =
        qs("#malath-confirm-modal");

      if (
        confirmModal &&
        !confirmModal.classList.contains(
          "hidden"
        )
      ) {
        closeConfirmModal();
        return;
      }

      const sidebar =
        qs("#sidebar-menu");

      if (
        sidebar &&
        sidebar.classList.contains(
          "is-open"
        )
      ) {
        closeSidebar();
      }
    }
  }

  function handleExternalStorageUpdate(event) {
    if (
      event.key !== APP.storageKey ||
      !storageAvailable
    ) {
      return;
    }

    try {
      if (event.newValue) {
        loadState();
        applyTheme();
        applyFontSize();
        hydrateCalculatorInputs();
        hydrateFamilyNeeds();
        renderInventory();
        renderRecords();
        restoreChecklistState();
        syncStorageStatus();
      }
    } catch (error) {
      reportError(
        "تعذر مزامنة التخزين المحلي",
        error
      );
    }
  }

  async function navigateTo(
    pageId,
    options = {}
  ) {
    const destination =
      pages.has(pageId)
        ? pageId
        : APP.defaultPage;

    const historyMode =
      options.history || "none";

    if (
      runtime.navigationLocked &&
      destination !== runtime.currentPage
    ) {
      return false;
    }

    const samePage =
      runtime.currentPage === destination;

    if (
      samePage &&
      !options.force
    ) {
      closeSidebar();

      if (options.focusId) {
        focusCalculatorIntoView(
          options.focusId
        );
      }

      return true;
    }

    runtime.navigationLocked = true;
    runtime.navigationSequence += 1;

    const token =
      runtime.navigationSequence;

    body.classList.add(
      "nav-locked"
    );

    const current =
      pages.get(
        runtime.currentPage
      );

    const next =
      pages.get(destination);

    try {
      if (current) {
        current.classList.remove(
          "active"
        );

        current.setAttribute(
          "aria-hidden",
          "true"
        );

        current.classList.add(
          "is-switching"
        );
      }

      closeSidebar();
      hideSearchResults();

      runtime.currentPage =
        destination;

      updateHistory(
        destination,
        historyMode
      );

      forceScrollTop();

      pages.forEach(
        (page, id) => {
          const active =
            id === destination;

          page.classList.toggle(
            "active",
            active
          );

          page.classList.toggle(
            "is-switching",
            !active
          );

          page.setAttribute(
            "aria-hidden",
            String(!active)
          );
        }
      );

      updateNavigationState();

      syncPageSpecificState(
        destination
      );

      await nextFrame();

      if (
        token !==
        runtime.navigationSequence
      ) {
        return false;
      }

      forceScrollTop();

      if (options.focusId) {
        await nextFrame();

        if (
          token !==
          runtime.navigationSequence
        ) {
          return false;
        }

        focusCalculatorIntoView(
          options.focusId
        );
      }

      await nextFrame();

      if (
        token !==
        runtime.navigationSequence
      ) {
        return false;
      }

      const activePage =
        pages.get(destination);

      if (activePage) {
        activePage.classList.remove(
          "is-switching"
        );

        activePage.focus({
          preventScroll: true
        });
      }

      return true;
    } catch (error) {
      reportError(
        `تعذر فتح القسم: ${destination}`,
        error
      );

      pages.forEach(
        (page, id) => {
          const active =
            id === APP.defaultPage;

          page.classList.toggle(
            "active",
            active
          );

          page.classList.remove(
            "is-switching"
          );

          page.setAttribute(
            "aria-hidden",
            String(!active)
          );
        }
      );

      runtime.currentPage =
        APP.defaultPage;

      updateHistory(
        APP.defaultPage,
        "replace"
      );

      forceScrollTop();
      updateNavigationState();

      return false;
    } finally {
      requestAnimationFrame(() => {
        if (
          token ===
          runtime.navigationSequence
        ) {
          runtime.navigationLocked =
            false;

          body.classList.remove(
            "nav-locked"
          );
        }
      });
    }
  }

  function navigationHistoryMode(
    destination
  ) {
    if (
      destination ===
      APP.defaultPage
    ) {
      return "replace";
    }

    return runtime.currentPage ===
      APP.defaultPage
      ? "push"
      : "replace";
  }

  function updateHistory(
    pageId,
    mode
  ) {
    if (mode === "none") return;

    const normalized =
      pageId === APP.defaultPage
        ? ""
        : `#${encodeURIComponent(
            pageId
          )}`;

    const url =
      `${window.location.pathname}` +
      `${window.location.search}` +
      normalized;

    if (mode === "push") {
      window.history.pushState(
        { malathPage: pageId },
        "",
        url
      );
    } else {
      window.history.replaceState(
        { malathPage: pageId },
        "",
        url
      );
    }
  }

  function prepareInitialHistory(
    pageId
  ) {
    const path =
      `${window.location.pathname}` +
      `${window.location.search}`;

    const destination =
      pages.has(pageId)
        ? pageId
        : APP.defaultPage;

    if (
      destination ===
      APP.defaultPage
    ) {
      window.history.replaceState(
        {
          malathPage:
            APP.defaultPage
        },
        "",
        path
      );

      return;
    }

    window.history.replaceState(
      {
        malathPage:
          APP.defaultPage
      },
      "",
      path
    );

    window.history.pushState(
      {
        malathPage:
          destination
      },
      "",
      `${path}#${encodeURIComponent(
        destination
      )}`
    );
  }

  function getHashPage() {
    const raw =
      window.location.hash.replace(
        /^#/,
        ""
      );

    if (!raw) {
      return APP.defaultPage;
    }

    let decoded = raw;

    try {
      decoded =
        decodeURIComponent(raw);
    } catch {
      decoded = raw;
    }

    return pages.has(decoded)
      ? decoded
      : APP.defaultPage;
  }

  function updateNavigationState() {
    navButtons.forEach(
      (button) => {
        const target =
          button.getAttribute(
            "data-target"
          );

        if (
          !target ||
          button.tagName !==
            "BUTTON"
        ) {
          return;
        }

        const active =
          target ===
          runtime.currentPage;

        button.classList.toggle(
          "active",
          active
        );

        button.setAttribute(
          "aria-current",
          String(active)
        );
      }
    );
  }

  function syncPageSpecificState(
    pageId
  ) {
    const page =
      pages.get(pageId);

    if (!page) return;

    page
      .querySelectorAll(
        "[data-inventory-status]"
      )
      .forEach((node) => {
        const type =
          node.getAttribute(
            "data-inventory-status"
          );

        updateInventoryStatusNode(
          node,
          type
        );
      });

    if (
      pageId ===
      "records-planning"
    ) {
      renderInventory();
      renderRecords();
    }

    if (
      [
        "water-management",
        "food-nutrition",
        "energy-power"
      ].includes(pageId)
    ) {
      syncCalculatorInventoryFields(
        page
      );
    }

    const checklist =
      qsa(
        "[data-checklist-item]",
        page
      );

    if (checklist.length) {
      restoreChecklistStateForPage(
        page,
        checklist
      );
    }
  }

  function forceScrollTop() {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "auto"
    });

    document.documentElement.scrollTop =
      0;

    document.body.scrollTop =
      0;
  }

  function scrollToElement(id) {
    if (!id) return;

    const element =
      document.getElementById(id);

    if (!element) return;

    requestAnimationFrame(() => {
      const reduced =
        window.matchMedia(
          "(prefers-reduced-motion: reduce)"
        ).matches;

      element.scrollIntoView({
        behavior: reduced
          ? "auto"
          : "smooth",
        block: "start",
        inline: "nearest"
      });
    });
  }

  function focusCalculatorIntoView(
    calculatorId
  ) {
    if (!calculatorId) return;

    const element =
      document.getElementById(
        calculatorId
      );

    if (!element) return;

    scrollToElement(
      calculatorId
    );
  }

  function openSidebar() {
    const sidebar =
      qs("#sidebar-menu");

    const overlay =
      qs("#sidebar-overlay");

    const toggle =
      qs("#menu-toggle-btn");

    if (
      !sidebar ||
      !overlay
    ) {
      return;
    }

    sidebar.classList.add(
      "is-open"
    );

    overlay.classList.add(
      "is-open"
    );

    sidebar.setAttribute(
      "aria-hidden",
      "false"
    );

    overlay.setAttribute(
      "aria-hidden",
      "false"
    );

    toggle?.setAttribute(
      "aria-expanded",
      "true"
    );

    body.classList.add(
      "sidebar-open"
    );
  }

  function closeSidebar() {
    const sidebar =
      qs("#sidebar-menu");

    const overlay =
      qs("#sidebar-overlay");

    const toggle =
      qs("#menu-toggle-btn");

    if (
      !sidebar ||
      !overlay
    ) {
      return;
    }

    sidebar.classList.remove(
      "is-open"
    );

    overlay.classList.remove(
      "is-open"
    );

    sidebar.setAttribute(
      "aria-hidden",
      "true"
    );

    overlay.setAttribute(
      "aria-hidden",
      "true"
    );

    toggle?.setAttribute(
      "aria-expanded",
      "false"
    );

    body.classList.remove(
      "sidebar-open"
    );
  }

  function toggleTheme() {
    state.theme =
      state.theme === "dark"
        ? "light"
        : "dark";

    applyTheme();
    saveState();

    showToast(
      state.theme === "dark"
        ? "تم تفعيل المظهر الداكن."
        : "تم تفعيل المظهر الفاتح.",
      "success"
    );
  }

  function applyTheme() {
    body.classList.toggle(
      "theme-dark",
      state.theme === "dark"
    );

    body.classList.toggle(
      "theme-light",
      state.theme === "light"
    );

    const button =
      qs("#theme-toggle-btn");

    if (button) {
      const dark =
        state.theme === "dark";

      button.textContent =
        dark
          ? "☀️"
          : "🌙";

      button.setAttribute(
        "aria-label",
        dark
          ? "تفعيل المظهر الفاتح"
          : "تفعيل المظهر الداكن"
      );

      button.setAttribute(
        "title",
        dark
          ? "تفعيل المظهر الفاتح"
          : "تفعيل المظهر الداكن"
      );
    }
  }

  function applyFontSize() {
    body.classList.remove(
      "font-large",
      "font-xlarge"
    );

    if (
      state.fontSize ===
      "large"
    ) {
      body.classList.add(
        "font-large"
      );
    }

    if (
      state.fontSize ===
      "xlarge"
    ) {
      body.classList.add(
        "font-xlarge"
      );
    }

    const select =
      qs("#font-size-setting");

    if (select) {
      select.value =
        state.fontSize;
    }
  }

  function startClock() {
    const update = () => {
      const now =
        new Date();

      const date =
        qs("#current-date");

      const time =
        qs("#current-time");

      if (date) {
        date.textContent =
          new Intl.DateTimeFormat(
            "ar",
            {
              year: "numeric",
              month: "2-digit",
              day: "2-digit"
            }
          ).format(now);
      }

      if (time) {
        time.textContent =
          new Intl.DateTimeFormat(
            "ar",
            {
              hour: "2-digit",
              minute: "2-digit"
            }
          ).format(now);
      }
    };

    update();

    runtime.clockTimer =
      window.setInterval(
        update,
        60_000
      );
  }

  function syncStorageStatus() {
    const node =
      qs("#storage-status");

    if (!node) return;

    node.textContent =
      storageAvailable
        ? "محلي"
        : "غير متاح";

    node.setAttribute(
      "title",
      storageAvailable
        ? "البيانات محفوظة محليًا على هذا الجهاز."
        : "تعذر الوصول إلى التخزين المحلي في الجلسة الحالية."
    );
  }

  function performSearch(query) {
    const normalized =
      normalizeSearch(query);

    if (!normalized) {
      hideSearchResults();
      return;
    }

    const matches = [];

    for (
      const [pageId, page]
      of pages
    ) {
      const title =
        normalizeSearch(
          page.getAttribute(
            "data-page-title"
          ) ||
            page.querySelector(
              "h2"
            )?.textContent ||
            pageId
        );

      if (
        title.includes(
          normalized
        )
      ) {
        matches.push({
          pageId,
          nodeId: "",
          title:
            page.getAttribute(
              "data-page-title"
            ) || pageId,
          snippet:
            compactSnippet(
              page.textContent ||
                ""
            )
        });
      }

      qsa(
        "[data-search]",
        page
      ).forEach(
        (node) => {
          const text =
            normalizeSearch(
              node.textContent ||
                ""
            );

          if (
            !text.includes(
              normalized
            )
          ) {
            return;
          }

          if (
            matches.some(
              (item) =>
                item.pageId ===
                  pageId &&
                item.nodeId ===
                  node.id &&
                item.snippet ===
                  compactSnippet(
                    node.textContent ||
                      ""
                  )
            )
          ) {
            return;
          }

          matches.push({
            pageId,
            nodeId: node.id || "",
            title:
              findSearchTitle(
                node,
                page
              ),
            snippet:
              compactSnippet(
                node.textContent ||
                  ""
              )
          });
        }
      );
    }

    renderSearchResults(
      matches.slice(0, 40)
    );
  }

  function normalizeSearch(value) {
    return String(value || "")
      .toLocaleLowerCase(
        "ar"
      )
      .normalize("NFKD")
      .replace(
        /[\u064B-\u065F\u0670\u06D6-\u06ED]/g,
        ""
      )
      .replace(
        /[إأآٱ]/g,
        "ا"
      )
      .replace(
        /ى/g,
        "ي"
      )
      .replace(
        /ة/g,
        "ه"
      )
      .replace(
        /ؤ/g,
        "و"
      )
      .replace(
        /ئ/g,
        "ي"
      )
      .replace(
        /[ـ]/g,
        ""
      )
      .replace(
        /\s+/g,
        " "
      )
      .trim();
  }

  function compactSnippet(text) {
    return String(text || "")
      .replace(
        /\s+/g,
        " "
      )
      .trim()
      .slice(0, 230);
  }

  function findSearchTitle(
    node,
    page
  ) {
    const heading =
      node.matches(
        "article,section"
      )
        ? node.querySelector(
            "h2,h3,h4"
          )
        : node.closest(
            "article,section"
          )?.querySelector(
            "h2,h3,h4"
          );

    return (
      heading?.textContent.trim() ||
      page.getAttribute(
        "data-page-title"
      ) ||
      "نتيجة"
    );
  }

  function renderSearchResults(
    matches
  ) {
    const section =
      qs("#search-results");

    const container =
      qs(
        "#search-results-container"
      );

    if (
      !section ||
      !container
    ) {
      return;
    }

    container.replaceChildren();

    const heading =
      section.querySelector(
        "h2"
      );

    if (heading) {
      heading.textContent =
        `نتائج البحث (${matches.length})`;
    }

    if (!matches.length) {
      const empty =
        document.createElement(
          "div"
        );

      empty.className =
        "empty-state";

      empty.innerHTML =
        "<strong>لا توجد نتائج</strong><p>جرّب كلمة مختلفة أو استخدم أحد الاختصارات.</p>";

      container.append(empty);
    } else {
      for (
        const match of matches
      ) {
        const card =
          document.createElement(
            "article"
          );

        card.className =
          "search-result-card";

        const title =
          document.createElement(
            "strong"
          );

        title.textContent =
          match.title;

        const snippet =
          document.createElement(
            "p"
          );

        snippet.textContent =
          match.snippet;

        const meta =
          document.createElement(
            "span"
          );

        meta.className =
          "result-meta";

        meta.textContent =
          pages
            .get(match.pageId)
            ?.getAttribute(
              "data-page-title"
            ) || "";

        const open =
          document.createElement(
            "button"
          );

        open.type =
          "button";

        open.className =
          "button button-secondary search-result-open";

        open.textContent =
          "فتح النتيجة";

        open.setAttribute(
          "data-result-page",
          match.pageId
        );

        if (match.nodeId) {
          open.setAttribute(
            "data-result-node",
            match.nodeId
          );
        }

        card.append(
          title,
          snippet,
          meta,
          open
        );

        container.append(card);
      }
    }

    section.classList.remove(
      "hidden"
    );

    section.setAttribute(
      "aria-hidden",
      "false"
    );
  }

  function hideSearchResults() {
    const section =
      qs("#search-results");

    if (!section) return;

    section.classList.add(
      "hidden"
    );

    section.setAttribute(
      "aria-hidden",
      "true"
    );
  }

  function clearSearch() {
    const input =
      qs("#global-search");

    if (input) {
      input.value = "";

      input.focus({
        preventScroll: true
      });
    }

    hideSearchResults();
  }

  function persistChecklist(
    input
  ) {
    const page =
      input.closest(
        ".page"
      );

    if (!page?.id) return;

    const values =
      qsa(
        "[data-checklist-item]",
        page
      ).map(
        (item) =>
          item.checked
      );

    state.checklists[
      page.id
    ] = values;

    saveState();
  }

  function restoreChecklistState() {
    qsa(".page").forEach(
      (page) => {
        restoreChecklistStateForPage(
          page,
          qsa(
            "[data-checklist-item]",
            page
          )
        );
      }
    );
  }

  function restoreChecklistStateForPage(
    page,
    checklist
  ) {
    const saved =
      Array.isArray(
        state.checklists[
          page.id
        ]
      )
        ? state.checklists[
            page.id
          ]
        : [];

    checklist.forEach(
      (item, index) => {
        item.checked =
          Boolean(
            saved[index]
          );
      }
    );
  }

  function resetChecklist(
    trigger
  ) {
    const page =
      trigger.closest(
        ".page"
      );

    if (!page) return;

    qsa(
      "[data-checklist-item]",
      page
    ).forEach(
      (item) => {
        item.checked =
          false;
      }
    );

    delete state.checklists[
      page.id
    ];

    saveState();

    showToast(
      "تمت إعادة ضبط القائمة.",
      "success"
    );
  }

  function hydrateCalculatorInputs() {
    qsa(
      "[data-calculator]"
    ).forEach(
      (calculator) => {
        const type =
          calculator.getAttribute(
            "data-calculator"
          );

        const saved =
          state.calculators[
            type
          ];

        if (!saved) return;

        qsa(
          "[data-calc-input]",
          calculator
        ).forEach(
          (input) => {
            const key =
              input.getAttribute(
                "data-calc-input"
              );

            if (
              Object.prototype.hasOwnProperty.call(
                saved,
                key
              )
            ) {
              input.value =
                String(
                  saved[key]
                );
            }
          }
        );

        syncCalculatorInventoryFields(
          calculator
        );

        calculateCalculator(
          type,
          calculator,
          false
        );
      }
    );
  }

  function persistCalculatorInput(
    input
  ) {
    const calculator =
      input.closest(
        "[data-calculator]"
      );

    if (!calculator) return;

    const type =
      calculator.getAttribute(
        "data-calculator"
      );

    const key =
      input.getAttribute(
        "data-calc-input"
      );

    if (
      !type ||
      !key ||
      !state.calculators[type] ||
      !(key in state.calculators[type])
    ) {
      return;
    }

    state.calculators[type][key] =
      finiteNonNegative(
        input.value,
        state.calculators[type][key]
      );

    saveState();

    const status =
      calculator.querySelector(
        `[data-calc-status="${CSS.escape(
          type
        )}"]`
      );

    if (status) {
      status.classList.add(
        "hidden"
      );

      status.textContent =
        "";
    }
  }

  function handleCalculatorAction(
    button
  ) {
    const calculatorType =
      button.getAttribute(
        "data-calculator-action"
      );

    const action =
      button.getAttribute(
        "data-calc-action"
      );

    const calculator =
      qs(
        `[data-calculator="${CSS.escape(
          calculatorType
        )}"]`
      );

    if (!calculator) {
      showToast(
        "تعذر العثور على الحاسبة.",
        "error"
      );

      return;
    }

    if (
      action ===
      "calculate"
    ) {
      calculateCalculator(
        calculatorType,
        calculator,
        true
      );

      return;
    }

    if (
      action ===
      "reset"
    ) {
      resetCalculator(
        calculatorType,
        calculator
      );
    }
  }

  function resetCalculator(
    type,
    calculator
  ) {
    const defaults =
      createDefaultState()
        .calculators[type];

    if (!defaults) return;

    state.calculators[type] =
      {
        ...defaults
      };

    qsa(
      "[data-calc-input]",
      calculator
    ).forEach(
      (input) => {
        const key =
          input.getAttribute(
            "data-calc-input"
          );

        input.value =
          String(
            defaults[key]
          );
      }
    );

    clearCalculatorResults(
      calculator
    );

    if (
      [
        "water",
        "food",
        "energy"
      ].includes(type)
    ) {
      syncCalculatorInventoryFields(
        calculator
      );
    }

    saveState();

    showToast(
      "تم مسح مدخلات الحاسبة.",
      "success"
    );
  }

  function clearCalculatorResults(
    calculator
  ) {
    qsa(
      "[data-calc-result]",
      calculator
    ).forEach(
      (node) => {
        node.textContent =
          "—";
      }
    );

    qsa(
      "[data-calc-status]",
      calculator
    ).forEach(
      (node) => {
        node.className =
          "smart-status hidden";

        node.textContent =
          "";
      }
    );
  }

  function calculateCalculator(
    type,
    calculator,
    announce
  ) {
    const values =
      readCalculatorValues(
        calculator
      );

    let result =
      null;

    if (
      type === "water" ||
      type === "food"
    ) {
      const people =
        Math.max(
          1,
          values.people
        );

      const rate =
        Math.max(
          0,
          values.rate
        );

      const stock =
        Math.max(
          0,
          values.stock
        );

      const reserve =
        clamp(
          values.reserve,
          0,
          100
        );

      const daily =
        people * rate;

      const required =
        daily *
        (1 + reserve / 100);

      updateResult(
        calculator,
        "daily",
        formatNumber(daily)
      );

      updateResult(
        calculator,
        "required",
        formatNumber(
          required
        )
      );

      updateResult(
        calculator,
        "current",
        formatNumber(stock)
      );

      updateResult(
        calculator,
        "days",
        daily > 0
          ? formatNumber(
              stock / daily
            )
          : "غير محسوب"
      );

      state.calculators[
        type
      ] = {
        people,
        rate,
        stock,
        reserve
      };

      state.inventory[
        type
      ] = {
        ...state.inventory[
          type
        ],
        value: stock,
        lastUpdated:
          Date.now(),
        dailyRate:
          daily,
        efficiency:
          100
      };

      result = {
        message:
          `الاحتياج اليومي: ${formatNumber(
            daily
          )} ${APP.inventoryTypes[
            type
          ].unit}.`,

        detail:
          `مع احتياطي ${formatNumber(
            reserve
          )}% يصبح الاحتياج التخطيطي ${formatNumber(
            required
          )} ${APP.inventoryTypes[
            type
          ].unit}.`
      };
    }

    else if (
      type === "shelter"
    ) {
      const length =
        Math.max(
          0,
          values.length
        );

      const width =
        Math.max(
          0,
          values.width
        );

      const height =
        Math.max(
          0,
          values.height
        );

      const count =
        Math.max(
          1,
          values.count
        );

      const area =
        length * width;

      const volume =
        area * height;

      const totalArea =
        area * count;

      const totalVolume =
        volume * count;

      updateResult(
        calculator,
        "area",
        `${formatNumber(
          area
        )} م²`
      );

      updateResult(
        calculator,
        "volume",
        `${formatNumber(
          volume
        )} م³`
      );

      updateResult(
        calculator,
        "totalArea",
        `${formatNumber(
          totalArea
        )} م²`
      );

      updateResult(
        calculator,
        "totalVolume",
        `${formatNumber(
          totalVolume
        )} م³`
      );

      state.calculators[
        type
      ] = {
        length,
        width,
        height,
        count
      };

      result = {
        message:
          `المساحة الإجمالية: ${formatNumber(
            totalArea
          )} م².`,

        detail:
          `الحجم الإجمالي المحسوب: ${formatNumber(
            totalVolume
          )} م³. هذه حسبة هندسية تخطيطية وليست اعتمادًا إنشائيًا.`
      };
    }

    else if (
      type === "energy"
    ) {
      const daily =
        Math.max(
          0,
          values.daily
        );

      const stock =
        Math.max(
          0,
          values.stock
        );

      const efficiency =
        clamp(
          values.efficiency,
          1,
          100
        );

      const reserve =
        clamp(
          values.reserve,
          0,
          100
        );

      const effectiveDaily =
        daily > 0
          ? daily /
            (efficiency / 100)
          : 0;

      const current =
        stock;

      const days =
        effectiveDaily > 0
          ? current /
            effectiveDaily
          : 0;

      const planningDaily =
        effectiveDaily > 0
          ? effectiveDaily *
            (1 + reserve / 100)
          : 0;

      const percent =
        planningDaily > 0
          ? clamp(
              (
                current /
                planningDaily
              ) * 100,
              0,
              100
            )
          : 0;

      updateResult(
        calculator,
        "daily",
        `${formatNumber(
          daily
        )} وحدة/يوم`
      );

      updateResult(
        calculator,
        "current",
        `${formatNumber(
          current
        )} وحدة`
      );

      updateResult(
        calculator,
        "days",
        effectiveDaily > 0
          ? `${formatNumber(
              days
            )} يوم`
          : "غير محسوب"
      );

      updateResult(
        calculator,
        "percent",
        `${formatNumber(
          percent
        )}%`
      );

      state.calculators[
        type
      ] = {
        daily,
        stock,
        efficiency,
        reserve
      };

      state.inventory[
        "energy"
      ] = {
        ...state.inventory.energy,
        value: stock,
        lastUpdated:
          Date.now(),
        dailyRate:
          effectiveDaily,
        efficiency
      };

      result = {
        message:
          `الاستهلاك الفعّال التقريبي: ${formatNumber(
            effectiveDaily
          )} وحدة/يوم.`,

        detail:
          `الكفاءة المدخلة ${formatNumber(
            efficiency
          )}% والاحتياطي التخطيطي ${formatNumber(
            reserve
          )}%.`
      };
    }

    if (!result) return;

    saveState();

    renderInventory();

    showCalculatorStatus(
      calculator,
      result.message,
      result.detail
    );

    if (announce) {
      showToast(
        "تم الحساب وتحديث المخزن.",
        "success"
      );
    }
  }

  function readCalculatorValues(
    calculator
  ) {
    const values = {};

    qsa(
      "[data-calc-input]",
      calculator
    ).forEach(
      (input) => {
        values[
          input.getAttribute(
            "data-calc-input"
          )
        ] = parseNumber(
          input.value
        );
      }
    );

    return values;
  }

  function syncCalculatorInventoryFields(
    scope
  ) {
    const calculators =
      scope.matches?.(
        "[data-calculator]"
      )
        ? [scope]
        : qsa(
            "[data-calculator]",
            scope
          );

    calculators.forEach(
      (calculator) => {
        const type =
          calculator.getAttribute(
            "data-calculator"
          );

        if (
          ![
            "water",
            "food",
            "energy"
          ].includes(type)
        ) {
          return;
        }

        const stockInput =
          calculator.querySelector(
            '[data-calc-input="stock"]'
          );

        if (!stockInput) return;

        const current =
          getCurrentInventory(type);

        stockInput.value =
          String(current);

        state.calculators[
          type
        ].stock = current;

        updateInventoryStatusNode(
          calculator.querySelector(
            `[data-inventory-status="${CSS.escape(
              type
            )}"]`
          ),
          type
        );
      }
    );

    saveState();
  }

  function updateResult(
    calculator,
    key,
    value
  ) {
    const node =
      calculator.querySelector(
        `[data-calc-result="${CSS.escape(
          key
        )}"]`
      );

    if (node) {
      node.textContent =
        value;
    }
  }

  function showCalculatorStatus(
    calculator,
    message,
    detail
  ) {
    const type =
      calculator.getAttribute(
        "data-calculator"
      );

    const node =
      calculator.querySelector(
        `[data-calc-status="${CSS.escape(
          type
        )}"]`
      );

    if (!node) return;

    node.className =
      "smart-status";

    node.textContent =
      `${message} ${
        detail || ""
      }`.trim();
  }

  function getCurrentInventory(
    type
  ) {
    const item =
      state.inventory[
        type
      ];

    if (!item) return 0;

    const elapsedDays =
      item.lastUpdated > 0
        ? Math.max(
            0,
            (Date.now() -
              item.lastUpdated) /
              86_400_000
          )
        : 0;

    const consumption =
      item.dailyRate *
      elapsedDays;

    return Math.max(
      0,
      item.value -
        consumption
    );
  }

  function renderInventory() {
    for (
      const type of Object.keys(
        APP.inventoryTypes
      )
    ) {
      const current =
        getCurrentInventory(
          type
        );

      const unit =
        APP.inventoryTypes[
          type
        ].unit;

      const stateName =
        inventoryStateFor(
          type,
          current
        );

      qsa(
        `[data-stock-card="${CSS.escape(
          type
        )}"]`
      ).forEach(
        (card) => {
          card.setAttribute(
            "data-stock-state",
            stateName
          );

          const value =
            card.querySelector(
              `[data-stock-value="${CSS.escape(
                type
              )}"]`
            );

          const unitNode =
            card.querySelector(
              `[data-stock-unit="${CSS.escape(
                type
              )}"]`
            );

          if (value) {
            value.textContent =
              formatNumber(
                current
              );
          }

          if (unitNode) {
            unitNode.textContent =
              unit;
          }

          const badge =
            card.querySelector(
              ".stock-state-badge"
            );

          if (badge) {
            badge.textContent =
              inventoryStateLabel(
                stateName
              );
          }
        }
      );

      qsa(
        `[data-inventory-status="${CSS.escape(
          type
        )}"]`
      ).forEach(
        (node) => {
          updateInventoryStatusNode(
            node,
            type
          );
        }
      );
    }

    qsa(
      "[data-stock-card]"
    ).forEach(
      (card) => {
        const type =
          card.getAttribute(
            "data-stock-card"
          );

        const note =
          card.querySelector(
            `[data-stock-note="${CSS.escape(
              type
            )}"]`
          );

        if (
          note &&
          !note.textContent.trim()
        ) {
          note.textContent =
            `الوحدة: ${
              APP.inventoryTypes[
                type
              ]?.unit ||
              "—"
            }.`;
        }
      }
    );
  }

  function updateInventoryStatusNode(
    node,
    type
  ) {
    if (
      !node ||
      !APP.inventoryTypes[
        type
      ]
    ) {
      return;
    }

    const current =
      getCurrentInventory(type);

    const status =
      inventoryStateFor(
        type,
        current
      );

    node.dataset.state =
      status;

    node.textContent =
      current > 0
        ? `${formatNumber(
            current
          )} ${
            APP.inventoryTypes[
              type
            ].unit
          } — ${inventoryStateLabel(
            status
          )}`
        : "0 — غير محدد";
  }

  function inventoryStateFor(
    type,
    current
  ) {
    const item =
      state.inventory[
        type
      ];

    if (
      !item ||
      !Number.isFinite(
        current
      )
    ) {
      return "unknown";
    }

    if (current <= 0) {
      return "critical";
    }

    const daily =
      item.dailyRate;

    if (daily <= 0) {
      return "unknown";
    }

    const days =
      current / daily;

    if (days >= 3) {
      return "good";
    }

    if (days > 1) {
      return "watch";
    }

    return "critical";
  }

  function inventoryStateLabel(
    value
  ) {
    return (
      {
        good: "جيد",
        watch: "يحتاج متابعة",
        critical: "حرج",
        unknown: "غير محدد"
      }[value] ||
      "غير محدد"
    );
  }

  function openAmountModal(
    type,
    action
  ) {
    if (
      !APP.inventoryTypes[
        type
      ] ||
      ![
        "add",
        "consume"
      ].includes(action)
    ) {
      return;
    }

    const modal =
      qs("#malath-amount-modal");

    const input =
      qs(
        "#inventory-amount-input"
      );

    const message =
      qs(
        "#amount-modal-message"
      );

    const label =
      qs(
        "#amount-modal-label"
      );

    const title =
      qs(
        "#amount-modal-title"
      );

    if (
      !modal ||
      !input
    ) {
      return;
    }

    runtime.amountAction = {
      type,
      action
    };

    runtime.modalReturnFocus =
      document.activeElement instanceof
      HTMLElement
        ? document.activeElement
        : null;

    const info =
      APP.inventoryTypes[
        type
      ];

    const verb =
      action === "add"
        ? "إضافة"
        : "استهلاك";

    title.textContent =
      `${verb} ${info.label}`;

    label.textContent =
      `الكمية (${info.unit})`;

    message.textContent =
      action === "add"
        ? `أدخل كمية ${info.label} التي تريد إضافتها إلى الخزان.`
        : `أدخل كمية ${info.label} التي تريد استهلاكها.`;

    input.value = "";

    input.max =
      action === "consume"
        ? String(
            getCurrentInventory(
              type
            )
          )
        : "";

    modal.classList.remove(
      "hidden"
    );

    modal.setAttribute(
      "aria-hidden",
      "false"
    );

    body.classList.add(
      "sidebar-open"
    );

    requestAnimationFrame(
      () => {
        input.focus({
          preventScroll: true
        });
      }
    );
  }

  async function confirmAmountModal() {
    const action =
      runtime.amountAction;

    const input =
      qs(
        "#inventory-amount-input"
      );

    if (
      !action ||
      !input
    ) {
      return;
    }

    const amount =
      parseNumber(
        input.value
      );

    if (
      !(amount > 0)
    ) {
      input.setAttribute(
        "aria-invalid",
        "true"
      );

      showToast(
        "أدخل كمية أكبر من صفر.",
        "warning"
      );

      return;
    }

    input.removeAttribute(
      "aria-invalid"
    );

    const before =
      getCurrentInventory(
        action.type
      );

    const after =
      action.action === "add"
        ? before + amount
        : Math.max(
            0,
            before - amount
          );

    if (
      action.action ===
        "consume" &&
      amount > before
    ) {
      showToast(
        `الكمية المتاحة حاليًا ${formatNumber(
          before
        )} ${
          APP.inventoryTypes[
            action.type
          ].unit
        }.`,
        "warning"
      );

      return;
    }

    state.inventory[
      action.type
    ] = {
      ...state.inventory[
        action.type
      ],
      value: after,
      lastUpdated:
        Date.now()
    };

    if (
      action.type ===
        "water" ||
      action.type ===
        "food"
    ) {
      state.calculators[
        action.type
      ].stock = after;
    } else if (
      action.type ===
      "energy"
    ) {
      state.calculators.energy.stock =
        after;
    }

    closeAmountModal();

    saveState();

    renderInventory();

    hydrateCalculatorInputs();

    showToast(
      action.action === "add"
        ? `تمت إضافة ${formatNumber(
            amount
          )} ${
            APP.inventoryTypes[
              action.type
            ].unit
          }.`
        : `تم استهلاك ${formatNumber(
            amount
          )} ${
            APP.inventoryTypes[
              action.type
            ].unit
          }.`,
      "success"
    );
  }

  function closeAmountModal() {
    const modal =
      qs("#malath-amount-modal");

    if (!modal) return;

    modal.classList.add(
      "hidden"
    );

    modal.setAttribute(
      "aria-hidden",
      "true"
    );

    body.classList.remove(
      "sidebar-open"
    );

    runtime.amountAction =
      null;

    const focusBack =
      runtime.modalReturnFocus;

    runtime.modalReturnFocus =
      null;

    if (
      focusBack instanceof
      HTMLElement
    ) {
      focusBack.focus({
        preventScroll: true
      });
    }
  }

  function openConfirmModal(
    title,
    message,
    action
  ) {
    const modal =
      qs(
        "#malath-confirm-modal"
      );

    const titleNode =
      qs(
        "#confirm-modal-title"
      );

    const messageNode =
      qs(
        "#confirm-modal-message"
      );

    if (
      !modal ||
      !titleNode ||
      !messageNode
    ) {
      return;
    }

    runtime.confirmationAction =
      action;

    runtime.modalReturnFocus =
      document.activeElement instanceof
      HTMLElement
        ? document.activeElement
        : null;

    titleNode.textContent =
      title;

    messageNode.textContent =
      message;

    modal.classList.remove(
      "hidden"
    );

    modal.setAttribute(
      "aria-hidden",
      "false"
    );

    body.classList.add(
      "sidebar-open"
    );

    requestAnimationFrame(
      () => {
        qs(
          "[data-modal-cancel]",
          modal
        )?.focus({
          preventScroll: true
        });
      }
    );
  }

  function closeConfirmModal() {
    const modal =
      qs(
        "#malath-confirm-modal"
      );

    if (!modal) return;

    modal.classList.add(
      "hidden"
    );

    modal.setAttribute(
      "aria-hidden",
      "true"
    );

    body.classList.remove(
      "sidebar-open"
    );

    const focusBack =
      runtime.modalReturnFocus;

    runtime.modalReturnFocus =
      null;

    runtime.confirmationAction =
      null;

    if (
      focusBack instanceof
      HTMLElement
    ) {
      focusBack.focus({
        preventScroll: true
      });
    }
  }

  async function saveRecordFromForm(
    form
  ) {
    const type =
      qs(
        "#record-type",
        form
      )?.value ||
      "other";

    const name =
      qs(
        "#record-name",
        form
      )?.value.trim() ||
      "";

    const quantity =
      parseNumber(
        qs(
          "#record-quantity",
          form
        )?.value
      );

    const unit =
      qs(
        "#record-unit",
        form
      )?.value.trim() ||
      "";

    const note =
      qs(
        "#record-note",
        form
      )?.value.trim() ||
      "";

    if (!name) {
      showFormResult(
        "اكتب اسم العنصر أولًا.",
        "error"
      );

      qs(
        "#record-name",
        form
      )?.focus();

      return;
    }

    if (
      !(quantity > 0)
    ) {
      showFormResult(
        "أدخل كمية أكبر من صفر.",
        "error"
      );

      qs(
        "#record-quantity",
        form
      )?.focus();

      return;
    }

    const record = {
      id: createId(),
      type:
        Object.prototype.hasOwnProperty.call(
          APP.recordTypes,
          type
        )
          ? type
          : "other",
      name:
        name.slice(
          0,
          160
        ),
      quantity:
        finitePositive(
          quantity,
          0
        ),
      unit:
        unit.slice(
          0,
          60
        ),
      note:
        note.slice(
          0,
          500
        ),
      createdAt:
        Date.now()
    };

    state.records.unshift(
      record
    );

    state.records =
      state.records.slice(
        0,
        APP.maxRecords
      );

    saveState();
    renderRecords();
    form.reset();

    showFormResult(
      "تم حفظ السجل محليًا.",
      "success"
    );

    showToast(
      "تم حفظ السجل.",
      "success"
    );
  }

  function renderRecords() {
    const list =
      qs("#records-list");

    const summary =
      qs("#records-summary");

    if (
      !list ||
      !summary
    ) {
      return;
    }

    summary.replaceChildren();

    const total =
      state.records.length;

    const byType =
      state.records.reduce(
        (map, record) => {
          map[record.type] =
            (map[record.type] ||
              0) + 1;

          return map;
        },
        {}
      );

    const summaryItems = [
      {
        label: "إجمالي السجلات",
        value: total
      },
      {
        label:
          "الماء / الغذاء / الطاقة",
        value:
          (byType.water ||
            0) +
          (byType.food ||
            0) +
          (byType.energy ||
            0)
      }
    ];

    for (
      const item of
        summaryItems
    ) {
      const box =
        document.createElement(
          "div"
        );

      const strong =
        document.createElement(
          "strong"
        );

      strong.textContent =
        formatNumber(
          item.value
        );

      const span =
        document.createElement(
          "span"
        );

      span.textContent =
        item.label;

      box.append(
        strong,
        span
      );

      summary.append(
        box
      );
    }

    list.replaceChildren();

    if (
      !state.records.length
    ) {
      const empty =
        document.createElement(
          "div"
        );

      empty.className =
        "empty-state";

      empty.innerHTML =
        "<strong>لا توجد سجلات بعد.</strong><p>أضف أول مورد أو ملاحظة متابعة من النموذج أعلاه.</p>";

      list.append(
        empty
      );

      return;
    }

    for (
      const record of
        state.records
    ) {
      const card =
        document.createElement(
          "article"
        );

      card.className =
        "record-card";

      card.dataset.recordId =
        record.id;

      const main =
        document.createElement(
          "div"
        );

      main.className =
        "record-main";

      const badge =
        document.createElement(
          "span"
        );

      badge.className =
        "record-type";

      badge.textContent =
        APP.recordTypes[
          record.type
        ] ||
        "أخرى";

      const title =
        document.createElement(
          "h4"
        );

      title.textContent =
        record.name;

      const quantity =
        document.createElement(
          "strong"
        );

      quantity.textContent =
        `${formatNumber(
          record.quantity
        )}${
          record.unit
            ? ` ${record.unit}`
            : ""
        }`;

      const note =
        document.createElement(
          "p"
        );

      note.textContent =
        record.note ||
        "بدون ملاحظة.";

      const date =
        document.createElement(
          "small"
        );

      date.textContent =
        new Intl.DateTimeFormat(
          "ar",
          {
            dateStyle:
              "medium",
            timeStyle:
              "short"
          }
        ).format(
          new Date(
            record.createdAt
          )
        );

      main.append(
        badge,
        title,
        quantity,
        note,
        date
      );

      const actions =
        document.createElement(
          "div"
        );

      actions.className =
        "record-actions";

      const del =
        document.createElement(
          "button"
        );

      del.type =
        "button";

      del.className =
        "button button-danger record-delete-button";

      del.dataset.recordDelete =
        record.id;

      del.textContent =
        "حذف";

      actions.append(
        del
      );

      card.append(
        main,
        actions
      );

      list.append(
        card
      );
    }
  }

  function deleteRecord(
    id
  ) {
    const before =
      state.records.length;

    state.records =
      state.records.filter(
        (record) =>
          record.id !== id
      );

    if (
      state.records.length ===
      before
    ) {
      showToast(
        "السجل المطلوب غير موجود.",
        "warning"
      );

      return;
    }

    saveState();
    renderRecords();

    showToast(
      "تم حذف السجل.",
      "success"
    );
  }

  function showFormResult(
    message,
    type
  ) {
    const node =
      qs(
        "#record-action-result"
      );

    if (!node) return;

    node.className =
      `action-result-card is-${type}`;

    node.textContent =
      message;
  }

  function triggerBackupPicker(
    button
  ) {
    const page =
      button.closest(
        ".page"
      ) || document;

    const input =
      qs(
        "[data-backup-file]",
        page
      ) ||
      qs(
        "[data-backup-file]"
      );

    input?.click();
  }

  function exportBackup() {
    const payload = {
      app: "Malath",
      version:
        APP.version,
      exportedAt:
        new Date().toISOString(),
      state
    };

    try {
      const blob =
        new Blob(
          [
            JSON.stringify(
              payload,
              null,
              2
            )
          ],
          {
            type:
              "application/json;charset=utf-8"
          }
        );

      const url =
        URL.createObjectURL(
          blob
        );

      const link =
        document.createElement(
          "a"
        );

      link.href =
        url;

      link.download =
        `malath-backup-${new Date()
          .toISOString()
          .slice(
            0,
            10
          )}.json`;

      document.body.append(
        link
      );

      link.click();
      link.remove();

      window.setTimeout(
        () =>
          URL.revokeObjectURL(
            url
          ),
        0
      );

      showToast(
        "تم تصدير النسخة الاحتياطية.",
        "success"
      );
    } catch (error) {
      reportError(
        "تعذر تصدير النسخة الاحتياطية",
        error
      );

      showToast(
        "تعذر إنشاء النسخة الاحتياطية.",
        "error"
      );
    }
  }

  function importBackupFile(
    file,
    input
  ) {
    if (
      !(
        file instanceof File
      )
    ) {
      return;
    }

    if (
      file.size >
      APP.maxBackupBytes
    ) {
      showToast(
        "ملف النسخة الاحتياطية كبير جدًا.",
        "error"
      );

      input.value =
        "";

      return;
    }

    const reader =
      new FileReader();

    reader.onerror = () => {
      reportError(
        "فشل قراءة ملف النسخة الاحتياطية",
        reader.error
      );

      showToast(
        "تعذر قراءة الملف.",
        "error"
      );

      input.value =
        "";
    };

    reader.onload = () => {
      try {
        const payload =
          JSON.parse(
            String(
              reader.result ||
                ""
            )
          );

        const incoming =
          payload?.state &&
          typeof payload.state ===
            "object"
            ? payload.state
            : payload;

        if (
          !isValidBackup(
            incoming
          )
        ) {
          throw new Error(
            "Invalid Malath backup format."
          );
        }

        normalizeIntoState(
          incoming
        );

        saveState();

        applyTheme();
        applyFontSize();
        hydrateCalculatorInputs();
        hydrateFamilyNeeds();
        renderInventory();
        renderRecords();
        restoreChecklistState();
        syncStorageStatus();

        showToast(
          "تم استيراد البيانات بنجاح.",
          "success"
        );
      } catch (error) {
        reportError(
          "رفض ملف النسخة الاحتياطية",
          error
        );

        showToast(
          "ملف النسخة الاحتياطية غير صالح.",
          "error"
        );
      } finally {
        input.value =
          "";
      }
    };

    reader.readAsText(
      file,
      "utf-8"
    );
  }

  function isValidBackup(
    value
  ) {
    if (
      !value ||
      typeof value !== "object"
    ) {
      return false;
    }

    if (
      value.records !==
        undefined &&
      !Array.isArray(
        value.records
      )
    ) {
      return false;
    }

    if (
      value.inventory !==
        undefined &&
      typeof value.inventory !==
        "object"
    ) {
      return false;
    }

    if (
      value.calculators !==
        undefined &&
      typeof value.calculators !==
        "object"
    ) {
      return false;
    }

    return true;
  }

  async function copyAddress(
    button
  ) {
    const address =
      button
        .getAttribute(
          "data-copy-address"
        )
        ?.trim();

    if (!address) {
      showToast(
        "لا يوجد عنوان للنسخ.",
        "warning"
      );

      return;
    }

    try {
      await navigator.clipboard.writeText(
        address
      );

      showToast(
        "تم نسخ العنوان.",
        "success"
      );
    } catch (error) {
      const helper =
        document.createElement(
          "textarea"
        );

      helper.value =
        address;

      helper.setAttribute(
        "readonly",
        ""
      );

      helper.style.position =
        "fixed";

      helper.style.opacity =
        "0";

      document.body.append(
        helper
      );

      helper.select();

      let copied =
        false;

      try {
        copied =
          document.execCommand(
            "copy"
          );
      } catch (
        fallbackError
      ) {
        reportError(
          "فشل نسخ العنوان بالطريقة الاحتياطية",
          fallbackError
        );
      }

      helper.remove();

      showToast(
        copied
          ? "تم نسخ العنوان."
          : "تعذر النسخ تلقائيًا؛ يمكنك تحديد العنوان ونسخه يدويًا.",
        copied
          ? "success"
          : "warning"
      );

      if (!copied) {
        reportError(
          "تعذر الوصول إلى Clipboard API",
          error
        );
      }
    }
  }

  async function shareApplication() {
    const shareData = {
      title:
        "مَلاذ — دليل الإغاثة العملي",
      text:
        "مَلاذ: دليل إغاثة عملي للمياه والغذاء والمأوى والطاقة والصحة والأسرة والطوارئ.",
      url:
        window.location.href
    };

    try {
      if (
        navigator.share
      ) {
        await navigator.share(
          shareData
        );

        showToast(
          "تم فتح مشاركة مَلاذ.",
          "success"
        );

        return;
      }

      await navigator.clipboard.writeText(
        window.location.href
      );

      showToast(
        "لا تتوفر مشاركة النظام؛ تم نسخ رابط مَلاذ.",
        "info"
      );
    } catch (error) {
      if (
        error?.name ===
        "AbortError"
      ) {
        return;
      }

      reportError(
        "فشل مشاركة مَلاذ",
        error
      );

      showToast(
        "تعذر تنفيذ المشاركة من الجهاز الحالي.",
        "warning"
      );
    }
  }

  function clearLocalData() {
    const fresh =
      createDefaultState();

    replaceState(
      fresh
    );

    if (
      storageAvailable
    ) {
      try {
        localStorage.removeItem(
          APP.storageKey
        );
      } catch (error) {
        reportError(
          "تعذر حذف التخزين المحلي",
          error
        );
      }
    }

    applyTheme();
    applyFontSize();
    hydrateCalculatorInputs();
    hydrateFamilyNeeds();
    renderInventory();
    renderRecords();
    restoreChecklistState();
    syncStorageStatus();

    showToast(
      "تم حذف البيانات المحلية.",
      "success"
    );
  }

  function resetApplication() {
    const fresh =
      createDefaultState();

    replaceState(
      fresh
    );

    saveState();

    applyTheme();
    applyFontSize();
    hydrateCalculatorInputs();
    hydrateFamilyNeeds();
    renderInventory();
    renderRecords();
    restoreChecklistState();
    syncStorageStatus();

    showToast(
      "تمت إعادة ضبط مَلاذ.",
      "success"
    );
  }

  function replaceState(
    fresh
  ) {
    state.version =
      fresh.version;

    state.theme =
      fresh.theme;

    state.fontSize =
      fresh.fontSize;

    state.inventory =
      structuredCloneSafe(
        fresh.inventory
      );

    state.calculators =
      structuredCloneSafe(
        fresh.calculators
      );

    state.family =
      structuredCloneSafe(
        fresh.family
      );

    state.checklists =
      {};

    state.records =
      [];

    state.meta = {
      updatedAt:
        Date.now()
    };
  }

  function structuredCloneSafe(
    value
  ) {
    if (
      typeof structuredClone ===
      "function"
    ) {
      return structuredClone(
        value
      );
    }

    return JSON.parse(
      JSON.stringify(
        value
      )
    );
  }

  function showToast(
    message,
    type = "info"
  ) {
    const toast =
      qs("#malath-toast");

    if (!toast) return;

    if (
      runtime.toastTimer
    ) {
      window.clearTimeout(
        runtime.toastTimer
      );

      runtime.toastTimer =
        null;
    }

    toast.className =
      `malath-toast is-${type}`;

    toast.textContent =
      message;

    runtime.toastTimer =
      window.setTimeout(
        () => {
          toast.classList.add(
            "hidden"
          );
        },
        3200
      );
  }

  function setAppReady() {
    const shell =
      qs("#app");

    if (!shell) return;

    shell.dataset.appReady =
      "true";

    body.dataset.appBooted =
      "true";
  }

  function normalizeRecord(
    value
  ) {
    if (
      !value ||
      typeof value !== "object"
    ) {
      return null;
    }

    const type =
      Object.prototype.hasOwnProperty.call(
        APP.recordTypes,
        value.type
      )
        ? value.type
        : "other";

    const quantity =
      finitePositive(
        value.quantity,
        0
      );

    const name =
      String(
        value.name || ""
      ).trim();

    if (
      !name ||
      !(quantity > 0)
    ) {
      return null;
    }

    return {
      id:
        String(
          value.id ||
            createId()
        ),

      type,

      name:
        name.slice(
          0,
          160
        ),

      quantity,

      unit:
        String(
          value.unit ||
            ""
        ).slice(
          0,
          60
        ),

      note:
        String(
          value.note ||
            ""
        ).slice(
          0,
          500
        ),

      createdAt:
        Number.isFinite(
          Number(
            value.createdAt
          )
        )
          ? Number(
              value.createdAt
            )
          : Date.now()
    };
  }

  function sanitizeChecklistMap(
    value
  ) {
    const safe = {};

    Object.entries(
      value
    ).forEach(
      ([pageId, list]) => {
        if (
          !pages.has(
            pageId
          ) ||
          !Array.isArray(
            list
          )
        ) {
          return;
        }

        safe[pageId] =
          list
            .slice(
              0,
              100
            )
            .map(Boolean);
      }
    );

    return safe;
  }

  function parseNumber(
    value
  ) {
    if (
      typeof value ===
      "number"
    ) {
      return Number.isFinite(
        value
      )
        ? value
        : 0;
    }

    const normalized =
      String(
        value ?? ""
      )
        .trim()
        .replace(
          /,/g,
          "."
        )
        .replace(
          /[٠-٩]/g,
          (digit) =>
            String(
              "٠١٢٣٤٥٦٧٨٩".indexOf(
                digit
              )
            )
        )
        .replace(
          /[۰-۹]/g,
          (digit) =>
            String(
              "۰۱۲۳۴۵۶۷۸۹".indexOf(
                digit
              )
            )
        );

    const number =
      Number(
        normalized
      );

    return Number.isFinite(
      number
    )
      ? number
      : 0;
  }

  function finiteNonNegative(
    value,
    fallback
  ) {
    const number =
      parseNumber(
        value
      );

    return Number.isFinite(
      number
    ) &&
      number >= 0
      ? number
      : fallback;
  }

  function finitePositive(
    value,
    fallback
  ) {
    const number =
      parseNumber(
        value
      );

    return Number.isFinite(
      number
    ) &&
      number > 0
      ? number
      : fallback;
  }

  function clamp(
    value,
    min,
    max
  ) {
    return Math.min(
      max,
      Math.max(
        min,
        value
      )
    );
  }

  function formatNumber(
    value
  ) {
    if (
      !Number.isFinite(
        value
      )
    ) {
      return "—";
    }

    return new Intl.NumberFormat(
      "ar",
      {
        maximumFractionDigits: 2
      }
    ).format(value);
  }

  function createId() {
    if (
      typeof crypto !==
        "undefined" &&
      typeof crypto.randomUUID ===
        "function"
    ) {
      return crypto.randomUUID();
    }

    return (
      `record-${Date.now()}-` +
      `${Math.random()
        .toString(36)
        .slice(
          2,
          10
        )}`
    );
  }

  function canUseStorage() {
    try {
      const key =
        "__malath_storage_test__";

      localStorage.setItem(
        key,
        "1"
      );

      localStorage.removeItem(
        key
      );

      return true;
    } catch {
      return false;
    }
  }

  function isMobileWidth() {
    return window.matchMedia(
      "(max-width: 899px)"
    ).matches;
  }

  function nextFrame() {
    return new Promise(
      (resolve) => {
        window.requestAnimationFrame(
          () => resolve()
        );
      }
    );
  }

  async function safeAction(
    action,
    fallbackMessage
  ) {
    try {
      await action();
    } catch (error) {
      reportError(
        "فشل تنفيذ العملية",
        error
      );

      showToast(
        fallbackMessage,
        "error"
      );
    }
  }

  function reportError(
    context,
    error
  ) {
    if (
      typeof console !==
        "undefined" &&
      typeof console.error ===
        "function"
    ) {
      console.error(
        `[Malath] ${context}`,
        error
      );
    }
  }

  /* =========================================================
     إضافة حاسبة الأسرة — Family Needs Calculator
     ========================================================= */

  function hydrateFamilyNeeds() {
    const calculator =
      qs(
        "#family-needs-calculator"
      );

    if (!calculator) return;

    const fields =
      qsa(
        "[data-family-input]",
        calculator
      );

    if (!fields.length) {
      enhanceFamilyCalculator(
        calculator
      );

      return hydrateFamilyNeeds();
    }

    fields.forEach(
      (input) => {
        const key =
          input.getAttribute(
            "data-family-input"
          );

        if (
          !key ||
          !(key in state.family)
        ) {
          return;
        }

        input.value =
          String(
            state.family[key] ?? ""
          );
      }
    );

    updateFamilySummary(
      calculator
    );
  }

  function enhanceFamilyCalculator(
    calculator
  ) {
    const inputs =
      qsa(
        "input",
        calculator
      );

    const textareas =
      qsa(
        "textarea",
        calculator
      );

    const numericKeys = [
      "people",
      "children",
      "seniors",
      "disabilities"
    ];

    inputs
      .slice(0, 4)
      .forEach(
        (
          input,
          index
        ) => {
          input.setAttribute(
            "data-family-input",
            numericKeys[index]
          );

          input.setAttribute(
            "inputmode",
            "numeric"
          );

          input.setAttribute(
            "min",
            index === 0
              ? "1"
              : "0"
          );

          input.setAttribute(
            "step",
            "1"
          );
        }
      );

    if (textareas[0]) {
      textareas[0].setAttribute(
        "data-family-input",
        "healthNeeds"
      );
    }

    if (textareas[1]) {
      textareas[1].setAttribute(
        "data-family-input",
        "otherNeeds"
      );
    }

    const actions =
      document.createElement(
        "div"
      );

    actions.className =
      "smart-actions";

    actions.innerHTML =
      '<button class="button button-primary" data-family-action="save" type="button">حفظ احتياجات الأسرة</button>' +
      '<button class="button button-secondary" data-family-action="reset" type="button">مسح بيانات الأسرة</button>';

    const status =
      document.createElement(
        "div"
      );

    status.className =
      "smart-status hidden";

    status.setAttribute(
      "data-family-status",
      ""
    );

    status.setAttribute(
      "aria-live",
      "polite"
    );

    status.setAttribute(
      "role",
      "status"
    );

    const results =
      document.createElement(
        "div"
      );

    results.className =
      "smart-results";

    results.setAttribute(
      "data-family-summary",
      ""
    );

    results.innerHTML =
      '<div class="smart-result"><span>إجمالي الفئات الخاصة المسجلة</span><strong data-family-result="special">—</strong></div>' +
      '<div class="smart-result"><span>النسبة من إجمالي الأسرة</span><strong data-family-result="specialPercent">—</strong></div>' +
      '<div class="smart-result"><span>حالة البيانات</span><strong data-family-result="status">—</strong></div>';

    calculator.append(
      actions,
      status,
      results
    );
  }

  function persistFamilyField(
    input
  ) {
    const key =
      input.getAttribute(
        "data-family-input"
      );

    if (
      !key ||
      !(key in state.family)
    ) {
      return;
    }

    if (
      [
        "people",
        "children",
        "seniors",
        "disabilities"
      ].includes(key)
    ) {
      const parsed =
        parseNumber(
          input.value
        );

      state.family[key] =
        Math.max(
          0,
          Math.floor(
            Number.isFinite(
              parsed
            )
              ? parsed
              : 0
          )
        );

      if (key === "people") {
        state.family.people =
          Math.max(
            1,
            state.family.people
          );
      }
    } else {
      state.family[key] =
        String(
          input.value || ""
        ).slice(
          0,
          1000
        );
    }

    state.family.updatedAt =
      Date.now();

    saveState();

    updateFamilySummary(
      input.closest(
        "#family-needs-calculator"
      )
    );
  }

  function handleFamilyAction(
    button
  ) {
    const calculator =
      button.closest(
        "#family-needs-calculator"
      );

    if (!calculator) return;

    const action =
      button.getAttribute(
        "data-family-action"
      );

    if (action === "save") {
      qsa(
        "[data-family-input]",
        calculator
      ).forEach(
        persistFamilyField
      );

      const status =
        qs(
          "[data-family-status]",
          calculator
        );

      if (status) {
        status.className =
          "smart-status";

        status.textContent =
          "تم حفظ بيانات الأسرة محليًا على هذا الجهاز.";
      }

      showToast(
        "تم حفظ بيانات الأسرة.",
        "success"
      );

      return;
    }

    if (action === "reset") {
      state.family = {
        people: 1,
        children: 0,
        seniors: 0,
        disabilities: 0,
        healthNeeds: "",
        otherNeeds: "",
        updatedAt: 0
      };

      saveState();

      hydrateFamilyNeeds();

      const status =
        qs(
          "[data-family-status]",
          calculator
        );

      if (status) {
        status.className =
          "smart-status";

        status.textContent =
          "تم مسح بيانات الأسرة وإعادتها للوضع الافتراضي.";
      }

      showToast(
        "تم مسح بيانات الأسرة.",
        "success"
      );
    }
  }

  function updateFamilySummary(
    calculator
  ) {
    if (!calculator) return;

    const special =
      state.family.children +
      state.family.seniors +
      state.family.disabilities;

    const percent =
      state.family.people > 0
        ? Math.min(
            100,
            (
              special /
              state.family.people
            ) * 100
          )
        : 0;

    const specialNode =
      qs(
        '[data-family-result="special"]',
        calculator
      );

    const percentNode =
      qs(
        '[data-family-result="specialPercent"]',
        calculator
      );

    const statusNode =
      qs(
        '[data-family-result="status"]',
        calculator
      );

    if (specialNode) {
      specialNode.textContent =
        formatNumber(
          special
        );
    }

    if (percentNode) {
      percentNode.textContent =
        `${formatNumber(
          percent
        )}%`;
    }

    if (statusNode) {
      const hasNotes =
        Boolean(
          state.family.healthNeeds.trim() ||
          state.family.otherNeeds.trim()
        );

      statusNode.textContent =
        hasNotes
          ? "بيانات + احتياجات"
          : "بيانات أساسية";
    }
  }

})();