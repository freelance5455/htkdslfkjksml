ChatGPT X starter web app

This is a starter interface, not a complete AI service and not an APK yet.
It has a dark chat-style interface, local chat history, no ads, and no subscription UI.
To create an APK, upload this ZIP to a trusted HTML/ZIP-to-APK builder such as APKForge.
For real AI replies, connect an AI provider through a secure backend. Do not put API keys in index.html.
Use original branding and do not imply this is the official ChatGPT app.
