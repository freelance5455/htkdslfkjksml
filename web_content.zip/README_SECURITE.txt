Syllabe V3.5 — protections de sécurité côté client

Ajouts :
- Content Security Policy restrictive : scripts/styles locaux uniquement, pas de connexion réseau depuis l'application.
- Validation/nettoyage des noms utilisateurs.
- Lecture JSON protégée contre les données LocalStorage corrompues.
- Gestion des erreurs de stockage LocalStorage.
- Blocage des schémas de liens javascript:, data: et vbscript:.
- Blocage des soumissions de formulaires vers l'extérieur.
- Les contenus utilisateur sont affichés comme texte et non comme HTML.

Limite importante : Syllabe est une application locale. LocalStorage n'est pas un coffre-fort : une personne ayant accès au téléphone ou aux fichiers de l'application peut potentiellement lire ou modifier la progression. Ces protections réduisent les risques côté application, mais ne fournissent pas un chiffrement fort ni une authentification serveur.
