# HONOR Photo Studio AI

A mobile-friendly Progressive Web App (PWA) with a secure Python backend. It sends a selected photo to OpenAI's image-editing API and returns an enhanced PNG.

## Important
- This is a source project, not a precompiled Android APK.
- The app needs an OpenAI API key and a running backend. API usage may incur charges.
- **Never put your OpenAI API key in `static/`, JavaScript, an APK, or any code shipped to the phone.** Keep it in the backend environment.
- AI editing is generative: it can alter small details even with identity-preservation instructions. Always compare the output with the original.
- AI image editing is not a guaranteed forensic restoration or guaranteed native 4K enhancement.

## Run on a computer

1. Install Python 3.10 or newer.
2. Unzip this project and open a terminal in the project folder.
3. Install packages:

   ```bash
   python -m venv .venv
   # Windows: .venv\\Scripts\\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   ```

4. Set your API key in the server environment:

   **Windows PowerShell**
   ```powershell
   $env:OPENAI_API_KEY="your_api_key"
   ```

   **macOS/Linux**
   ```bash
   export OPENAI_API_KEY="your_api_key"
   ```

5. Start the server:

   ```bash
   uvicorn server:app --host 0.0.0.0 --port 8000
   ```

6. On the HONOR 400 Pro, open Chrome and visit `http://COMPUTER-LAN-IP:8000` while both devices are on the same Wi-Fi. For a production installable PWA, deploy behind HTTPS.
7. In Chrome, use **⋮ → Add to Home screen** or **Install app** if offered.

## Deploy for use away from home
Deploy the project to a trusted Python host with HTTPS. Configure `OPENAI_API_KEY` as a server-side secret in the host's environment settings. Do not commit `.env` or your API key to a public repository.

## App features
- DSLR-style enhancement preset
- Face/detail restoration preset
- Natural portrait preset
- Lighting correction preset
- Optional additional instructions
- Before/after comparison
- PNG download
- Phone-friendly installable PWA shell

## Model
Default: `gpt-image-2.5-sunburst`. You can change `OPENAI_IMAGE_MODEL` on the server to another image-edit model available to your API account. Model availability and API access can depend on account verification and current API access.

## Privacy
The selected image is uploaded to the backend and sent to the configured image-editing provider. Do not upload sensitive images unless you are comfortable with that processing. The app does not intentionally save uploaded photos on the server.
