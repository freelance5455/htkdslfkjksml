import os
import base64
from io import BytesIO
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from openai import OpenAI

APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_DIR, "static")
app = FastAPI(title="HONOR Photo Studio AI")

@app.get("/")
def home():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))

@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(os.path.join(STATIC_DIR, "manifest.webmanifest"), media_type="application/manifest+json")

@app.get("/sw.js")
def service_worker():
    return FileResponse(os.path.join(STATIC_DIR, "sw.js"), media_type="application/javascript")

@app.post("/api/enhance")
async def enhance(
    image: UploadFile = File(...),
    preset: str = Form("dslr"),
    extra_instructions: str = Form("")
):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Server is missing OPENAI_API_KEY. Add it to the server environment; never put it in the phone app.")
    allowed = {"image/jpeg", "image/png", "image/webp"}
    if image.content_type not in allowed:
        raise HTTPException(status_code=415, detail="Please upload a JPG, PNG, or WebP image.")
    raw = await image.read()
    if not raw or len(raw) > 20 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image is empty or larger than 20 MB.")
    prompts = {
        "dslr": """Professionally enhance this exact photograph as if captured with a high-end DSLR camera and a premium portrait lens. Preserve the identity and facial geometry of every person, their natural age, expression, skin tone, hairstyle, clothing, accessories, body shape, pose, and all important objects. Do not replace, beautify into a different person, or invent facial details. Improve real detail, focus, exposure, dynamic range, white balance, natural color, and subtle noise. Keep skin texture realistic and avoid plastic smoothing, halos, oversharpening, or artificial HDR. Keep the original composition and scene. Apply only a gentle, optically plausible background separation if it suits the original photograph. Output a faithful photorealistic enhancement, not a new interpretation.""",
        "face": """Restore and enhance this photograph while faithfully preserving each person's exact identity, facial proportions, eyes, nose, mouth, expression, age, skin tone, hairstyle, and natural skin texture. Reduce image noise and compression artifacts; improve focus and fine detail conservatively. Do not reshape faces, change expressions, add makeup, or create a beauty-filter look. Preserve clothes, accessories, body, composition, and background. Photorealistic restoration only.""",
        "portrait": """Enhance this photograph into a professional natural portrait. Preserve the exact person, face, expression, body proportions, clothing, accessories, pose, and scene. Improve lighting, exposure, color balance, fine detail, and realistic skin texture. Add subtle lens-like background blur only where physically plausible, keeping hair edges and subject outline natural. Do not replace the background or alter identity. Photorealistic DSLR finish.""",
        "light": """Correct this photograph's lighting like a professional photographer. Preserve all people and objects exactly, especially facial identity and expression. Balance highlights and shadows, recover natural detail, correct white balance, improve local contrast gently, and keep colors realistic. Avoid overexposure, HDR halos, plastic skin, or changing the scene."""
    }
    prompt = prompts.get(preset, prompts["dslr"])
    if extra_instructions.strip():
        prompt += "\nAdditional user request (follow only if consistent with identity and scene preservation): " + extra_instructions.strip()[:1000]
    try:
        client = OpenAI(api_key=api_key)
        result = client.images.edit(
            model=os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-2.5-sunburst"),
            image=(image.filename or "upload.jpg", BytesIO(raw), image.content_type),
            prompt=prompt,
            quality="high",
            size="auto",
            output_format="png",
            n=1
        )
        b64 = result.data[0].b64_json
        if not b64:
            raise RuntimeError("The image service returned no image data.")
        return Response(
            content=base64.b64decode(b64),
            media_type="image/png",
            headers={"Content-Disposition": 'inline; filename="honor-ai-enhanced.png"', "Cache-Control": "no-store"}
        )
    except Exception as exc:
        # Avoid returning secrets or internal stack traces to the browser.
        raise HTTPException(status_code=502, detail=f"AI enhancement failed: {str(exc)[:400]}")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
