# إخراج APK من GitHub بضغطة واحدة

## 1) إنشاء المستودع
أنشئ Repository جديدًا على GitHub ثم ارفع **محتويات هذا المجلد** إلى جذر المستودع، بحيث يظهر:

- `settings.gradle`
- `build.gradle`
- `app/`
- `.github/workflows/build-apk.yml`

## 2) تشغيل البناء
من صفحة المستودع:

**Actions → Build Android APK → Run workflow**

ثم اختر:

- `debug` — مناسب للتثبيت والتجربة على الهاتف.
- `release` — يبني Release APK غير موقّع في النسخة الحالية.

بعد انتهاء البناء:

**Actions → افتح آخر تشغيل ناجح → Artifacts → equipment-db-gallery-pdf-apk**

نزّل ملف ZIP الخاص بالـArtifact، ثم استخرج APK وثبّته على الهاتف.

## ملاحظة مهمة
التطبيق نفسه Standalone ولا يعتمد على الإنترنت وقت التشغيل. الإنترنت الذي تستخدمه GitHub Actions هنا مخصص فقط لتنزيل أدوات Gradle/Android أثناء عملية البناء.
