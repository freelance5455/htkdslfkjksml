# PLAN AVG DOWN (Offline)

Aplikasi kalkulator average down saham yang berjalan offline. Folder `www` berisi prototipe web mandiri; folder `android` berisi proyek Android Studio pembungkus WebView yang memuat file lokal tanpa izin internet.

## Fitur
- Splash screen animasi 3,5 detik.
- Pilihan broker dan fee beli/jual dinamis.
- Input saldo RDN berformat Rupiah dan sinkron langsung ke ringkasan Pembelian Baru.
- Mode jumlah lot manual atau otomatis berdasarkan slider alokasi 0–100% saldo RDN.
- Tombol harga +/- mengikuti fraksi harga; tombol lot +/- mengubah satu lot (di mode otomatis menggeser slider 1%).
- Kalkulasi average baru, total modal, BEP, rincian transaksi, dan simulasi 5 TP + 5 CL.
- Seluruh aset berada lokal; tidak membutuhkan internet.

## Menjalankan prototipe
Buka `www/index.html` di browser modern. Untuk pemasangan Android, buka folder `android` menggunakan Android Studio lalu pilih **Build > Build APK(s)**.

## Catatan
APK belum disertakan karena perlu dibangun dan diuji dengan Android SDK/Gradle di Android Studio. Fee broker merupakan angka konfigurasi yang ditampilkan di aplikasi, mohon verifikasi kembali dengan tarif sekuritas terbaru. Kalkulator ini merupakan alat simulasi, bukan rekomendasi investasi.


## Tambahan fitur simpan rencana AVG
- Tekan ikon disket di bagian atas untuk menyimpan atau membuka rencana.
- Data kode saham, AVG Price, jumlah lot, dan target harga disimpan secara lokal pada perangkat melalui localStorage.
- Daftar menyediakan tindakan Buka, Edit, dan Hapus. Buka mengisi kembali AVG Price dan jumlah lot ke bagian Posisi Saat Ini.
- Agar penyimpanan lokal berfungsi di aplikasi Android WebView, DOM Storage diaktifkan. Fitur berjalan tanpa koneksi internet.


## Update simulasi 22 baris
Tabel simulasi menampilkan 1 baris CP, 10 baris CL, 1 baris PS, dan 10 baris TP (total 22 baris). Perubahan hanya pada jumlah tingkat CL/TP; perhitungan dan desain lainnya dipertahankan.


## v2.5: Simulasi dinamis
- Dropdown jumlah tabel: 12, 22, 32, atau 42 baris total.
- 12 = 1 CP + 5 CL + 1 PS + 5 TP.
- 22 = 1 CP + 10 CL + 1 PS + 10 TP.
- 32 = 1 CP + 15 CL + 1 PS + 15 TP.
- 42 = 1 CP + 20 CL + 1 PS + 20 TP.
- Dropdown mengikuti tema gelap/terang dan menggunakan sudut membulat.


## Update v2.5: Edit harga CP
- Baris CP memiliki ikon pensil untuk mengubah harga simulasi CP secara terpisah dari harga pembelian baru.
- Mode edit menyediakan tombol hapus (×), Batal, dan Oke.
- Setelah Oke, persentase CP dihitung terhadap AVG terbaru dan estimasi net memakai seluruh kepemilikan, total modal, serta fee jual broker terpilih.
- Mengubah harga Pembelian Baru mengembalikan CP ke mode mengikuti harga tersebut.
- File web dan aset Android WebView menggunakan HTML yang sama.


## Build APK release dengan obfuscation dasar
1. Instal Android Studio pada PC/laptop dan Android SDK Platform 35.
2. Buka folder `android` sebagai project Android Studio, lalu tunggu Gradle sync selesai.
3. Pilih **Build > Generate Signed Bundle / APK > APK** untuk membuat APK rilis bertanda tangan.
4. Untuk uji cepat tanpa signing khusus: **Build > Build APK(s)**, lalu cari APK di `android/app/build/outputs/apk/`.
5. Aktifkan minifikasi R8 pada build `release` (sudah dikonfigurasi). Simpan file keystore dan password signing dengan aman, karena dibutuhkan untuk memperbarui aplikasi yang sama.

## Batas perlindungan kode
Build release mengaktifkan R8 untuk mengoptimalkan dan menyamarkan kode Java/Kotlin pembungkus. Namun, kalkulasi dan UI saat ini masih berada dalam `assets/index.html`; siapa pun yang cukup mahir dapat mengekstrak HTML/JavaScript dari APK. Minifikasi HTML/JavaScript dapat membuatnya lebih sulit dibaca, tetapi bukan perlindungan kuat. Untuk perlindungan lebih baik, pindahkan logika perhitungan inti dari JavaScript ke kode native Android dan hindari menyimpan rahasia penting di aplikasi. Tidak ada APK klien yang dapat dijamin 100% tidak bisa dibongkar.

APK belum disertakan karena lingkungan pembuatan ini tidak memiliki Android SDK dan Gradle untuk mengompilasi serta menguji APK. Proyek sumber ini siap dibuka dan dibangun di Android Studio.
