# The app's Java wrapper is intentionally small. R8 may rename/optimize it.
# HTML/JavaScript stored in assets are not protected by Java obfuscation.
-keepattributes *Annotation*
