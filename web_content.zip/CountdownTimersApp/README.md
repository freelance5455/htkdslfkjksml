# Countdown Timers Android App

This project wraps the supplied `index.html` in a native Android WebView.

## Build with Android Studio or AndroidIDE

1. Extract this ZIP.
2. Open the extracted `CountdownTimers` folder as an Android/Gradle project.
3. Allow Gradle to sync/download the Android Gradle Plugin and required SDK components if prompted.
4. Build the debug APK.
5. Install the generated APK on your Android phone.

The HTML is stored at:
`app/src/main/assets/index.html`

To change the timers or page design, edit that file and rebuild.
