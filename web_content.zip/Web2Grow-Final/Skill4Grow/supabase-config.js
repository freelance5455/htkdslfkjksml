/* Fill these from Supabase -> Project Settings -> API.
   Do NOT put a Supabase service_role key here. Only the publishable/anon key belongs in the browser. */
window.S4G_SUPABASE = {
  url: '',
  anonKey: ''
};
