# Skill4Grow — Final Arolinks Click Flow

This build preserves the existing Skill4Grow catalog and UI while fixing the course-opening flow.

## Course click flow

`Open Course` -> `/open.html?url=<exact-course-url>` -> real destination anchor is created -> Arolinks full-page script loads after that anchor exists -> the anchor is clicked -> Arolinks processing can run before the course destination opens.

This deliberately follows the working Learn4Grow pattern: the Arolinks configuration is set before the full-page script and the destination is a real anchor present when the provider script loads.

The main course cards no longer point directly to Google Drive. They point to the local click-transition page first.

## Important

- Original course destination URLs are preserved in `data.json`.
- `open.html` accepts only `http:` and `https:` destinations.
- The Vercel rewrite excludes `open.html` and its required config files so the transition page is served directly.
- The Arolinks token is client-side because this is the provider's supplied browser-script integration. Rotate the token if you publish a token that should no longer be trusted.

## Deployment

Upload the ZIP to Vercel and deploy. No source-code patching is required.
