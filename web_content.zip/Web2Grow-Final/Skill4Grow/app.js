const CATEGORIES = [
  'AI & Automation','Programming & Development','Cybersecurity','Graphic Design','Video Editing',
  'Social Media','Digital Marketing','Freelancing','E-commerce','Finance & Trading',
  'Photography','Communication & English','Productivity','Business & Entrepreneurship',
  'Personal Development','Other Courses'
];
let courses = [], category = 'All', query = '';
let supabaseClient = null;

const icon = {
  'AI & Automation':'✦','Programming & Development':'⌘','Cybersecurity':'◈','Graphic Design':'✎',
  'Video Editing':'▶','Social Media':'◎','Digital Marketing':'↗','Freelancing':'◌','E-commerce':'◇',
  'Finance & Trading':'₹','Photography':'◉','Communication & English':'Aa','Productivity':'✓',
  'Business & Entrepreneurship':'↗','Personal Development':'✧','Other Courses':'◆'
};

function esc(v=''){return String(v).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));}
function slug(v=''){return v.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');}
function logo(){return `<img class="brandmark" src="assets/skill4grow-logo.jpg" alt="Skill4Grow">`}
function header(){return `<header><a class="brand" href="#home">${logo()}<span>Skill<span>4</span>Grow</span></a><nav><a href="#home">Home</a><a href="#categories">Categories</a><a href="#courses">Courses</a><a href="#saved">♥ Saved</a><a href="#contact">Contact</a><a href="#login" class="navLogin">Login</a><button class="themeSwitch" onclick="cycleTheme()" title="Change theme" aria-label="Change theme"><i class="fa-solid fa-wand-magic-sparkles"></i></button></nav><button class="menu" onclick="document.body.classList.toggle('navOpen')">☰</button></header>`}
function footer(){return `<footer><div>${logo()}<span>Skill4Grow</span></div><p>Find a skill. Open a course. Start learning.</p></footer>`}

function home(){
  return `${header()}<main>
    <section class="hero premiumHero"><div class="heroGlow glowA"></div><div class="heroGlow glowB"></div><div class="floatingOrb orb1"></div><div class="floatingOrb orb2"></div><div class="heroCopy reveal">
      <div class="heroLogo">${logo()}</div><div class="eyebrow pill">LEARN • BUILD • GROW</div><div class="welcomeNameLine" id="welcomeNameLine"></div>
      <h1>Turn curiosity into <span>real skills.</span></h1>
      <p>Discover courses that fit what you want to learn. Pick a category, open a course and start.</p>
      <div class="searchbox heroSearch"><input value="${esc(query)}" oninput="liveSearch(this.value)" placeholder="Search courses, skills or topics..."><button onclick="location.hash='courses'">⌕</button></div>
      <div class="heroChips"><button onclick="setCat('AI & Automation')">✦ AI</button><button onclick="setCat('Programming & Development')">&lt;/&gt; Code</button><button onclick="setCat('Graphic Design')">✎ Design</button><button onclick="setCat('Digital Marketing')">↗ Marketing</button></div>
    </div></section>
    <section class="section categorySection" id="categories"><div class="sectionhead reveal"><div><div class="miniLabel">EXPLORE BY SKILL</div><h2>All Categories</h2><p>Choose any category and jump directly to its complete course list.</p></div></div><div class="categoryGrid homeAllCategories">${CATEGORIES.map(categoryCard).join('')}</div></section>
  </main>${footer()}`;
}

function categoryCard(c){const count=courses.filter(x=>x.category===c).length;return `<a class="cat reveal" href="#courses/${encodeURIComponent(c)}"><div class="catIcon">${icon[c]||'◆'}</div><div><h3>${esc(c)}</h3><p>${count} courses</p></div><span class="catArrow">↗</span></a>`}

function coursesPage(){return `${header()}<main class="page coursesLibrary"><section class="pageHero libraryHero"><div><div class="eyebrow pill">COURSE LIBRARY</div><h1>${category==='All'?'All Courses':esc(category)}</h1><p>Browse this category and open any course directly.</p></div><div class="bigCount">${filtered().length}<small>courses</small></div></section><section class="catalog"><aside class="filters"><b>Categories</b><button class="filter ${category==='All'?'active':''}" onclick="setCat('All')">All Courses</button>${CATEGORIES.map(c=>`<button class="filter ${c===category?'active':''}" onclick="setCat('${esc(c)}')">${icon[c]||'•'} ${esc(c)}</button>`).join('')}</aside><div><div class="filterbar"><input id="catSearch" value="${esc(query)}" oninput="liveSearch(this.value)" placeholder="Search courses..."></div><div class="resultline"><span id="resultCount">${filtered().length} results</span></div><div class="courseGrid" id="libraryGrid">${filtered().map(courseCard).join('')}</div></div></section></main>${footer()}`}

function brandIcon(t){
  const rules=[
    [/facebook|fb\b/,'fa-brands fa-facebook-f','Facebook'],[/youtube|yt shorts|youtube automation/,'fa-brands fa-youtube','YouTube'],[/instagram|ig\b/,'fa-brands fa-instagram','Instagram'],[/tiktok/,'fa-brands fa-tiktok','TikTok'],[/linkedin/,'fa-brands fa-linkedin-in','LinkedIn'],[/whatsapp/,'fa-brands fa-whatsapp','WhatsApp'],[/telegram/,'fa-brands fa-telegram','Telegram'],[/twitter|x marketing/,'fa-brands fa-x-twitter','X'],[/google ads|google analytics|google business|google seo/,'fa-brands fa-google','Google'],[/amazon|amazon fba|amazon ads/,'fa-brands fa-amazon','Amazon'],[/shopify/,'fa-brands fa-shopify','Shopify'],[/wordpress/,'fa-brands fa-wordpress','WordPress'],[/github|gitlab/,'fa-brands fa-github','GitHub'],[/discord/,'fa-brands fa-discord','Discord'],[/reddit/,'fa-brands fa-reddit-alien','Reddit'],[/pinterest/,'fa-brands fa-pinterest','Pinterest'],[/snapchat/,'fa-brands fa-snapchat','Snapchat'],[/spotify/,'fa-brands fa-spotify','Spotify'],[/twitch/,'fa-brands fa-twitch','Twitch'],[/canva/,'fa-solid fa-palette','Canva'],[/photoshop|adobe/,'fa-solid fa-wand-magic-sparkles','Adobe'],[/figma/,'fa-brands fa-figma','Figma'],[/python/,'fa-brands fa-python','Python'],[/react/,'fa-brands fa-react','React'],[/node\.?js|node js/,'fa-brands fa-node-js','Node.js'],[/html|css/,'fa-brands fa-html5','HTML/CSS'],[/java/,'fa-brands fa-java','Java'],[/microsoft|ms office|excel|powerpoint|word/,'fa-brands fa-microsoft','Microsoft'],[/android/,'fa-brands fa-android','Android'],[/apple|ios|mac/,'fa-brands fa-apple','Apple'],[/linux|kali linux/,'fa-brands fa-linux','Linux'],[/paypal/,'fa-brands fa-paypal','PayPal'],[/stripe/,'fa-brands fa-stripe','Stripe'],[/bitcoin|crypto|blockchain/,'fa-brands fa-bitcoin','Crypto'],[/css|web design|web development|coding|programming|javascript|php|sql/,'fa-solid fa-code','Development'],[/ai|artificial intelligence|chatgpt|prompt|machine learning|deep learning|generative/,'fa-solid fa-brain','AI'],[/cyber|ethical hack|hacking|security|pentest|bug bounty|kali/,'fa-solid fa-shield-halved','Cybersecurity'],[/video|premiere|after effects|filmora|davinci|reel editing/,'fa-solid fa-film','Video'],[/marketing|seo|ads|affiliate|sales|branding/,'fa-solid fa-chart-line','Marketing'],[/design|ui ux|ux ui|illustrator|graphic/,'fa-solid fa-pen-nib','Design'],[/photography|photo|camera/,'fa-solid fa-camera-retro','Photography'],[/trading|stock|finance|forex|investment/,'fa-solid fa-chart-candlestick','Finance'],[/english|communication|spoken|grammar|language/,'fa-solid fa-language','English'],[/freelanc|upwork|fiverr/,'fa-solid fa-laptop-code','Freelancing'],[/ecommerce|e-commerce|dropshipping/,'fa-solid fa-cart-shopping','E-commerce']
  ];
  for(const [re,cls,label] of rules){if(re.test(t)) return {cls,label};}
  return {cls:'fa-solid fa-sparkles',label:'Skill'};
}
function courseLogo(x){
  const b=brandIcon(x.title.toLowerCase());
  return `<div class="courseLogo brandLogo" title="${esc(b.label)}"><span><i class="${b.cls}" aria-hidden="true"></i></span></div>`;
}
function courseCard(x){const u=x.destinationUrl||x.sourceUrl;const go='open.html?url='+encodeURIComponent(u);return `<article class="course"><div class="courseCover">${courseLogo(x)}<button onclick="event.preventDefault();event.stopPropagation();bookmark('${x.id}')" class="save" title="Save course" aria-label="Save course">${saved().includes(x.id)?'♥':'♡'}</button></div><div class="courseBody"><div class="courseType">${esc(x.category)}</div><h3>${esc(x.title)}</h3><a class="btn openCourse" href="${esc(go)}">Open Course <span>↗</span></a></div></article>`}

function savedPage(){const ids=saved();const list=courses.filter(x=>ids.includes(x.id));return `${header()}<main class="page"><section class="pageHero"><div><div class="eyebrow">YOUR LIST</div><h1>Saved Courses</h1><p>Your bookmarked courses.</p></div><div class="bigCount">${list.length}<small>saved</small></div></section><div class="courseGrid savedGrid">${list.length?list.map(courseCard).join(''):'<div class="empty"><h3>No saved courses yet</h3><p>Tap the heart on any course to save it here.</p></div>'}</div></main>${footer()}`}

function saved(){try{return JSON.parse(localStorage.getItem('s4g_saved')||'[]')}catch{return[]}}
function bookmark(id){let a=saved();a=a.includes(id)?a.filter(x=>x!==id):[...a,id];localStorage.setItem('s4g_saved',JSON.stringify(a));render()}
function filtered(){return courses.filter(x=>(category==='All'||x.category===category)&&(!query||x.title.toLowerCase().includes(query.toLowerCase())||x.category.toLowerCase().includes(query.toLowerCase())))}
function setCat(c){category=c;location.hash=c==='All'?'courses':`courses/${encodeURIComponent(c)}`;render()}
function liveSearch(v){query=v;render()}

function authReady(){return !!(window.supabase&&window.S4G_SUPABASE?.url&&window.S4G_SUPABASE?.anonKey)}
function sb(){if(!authReady())return null;if(!supabaseClient)supabaseClient=window.supabase.createClient(window.S4G_SUPABASE.url,window.S4G_SUPABASE.anonKey);return supabaseClient}
let authModeValue='login';
function loginPage(){return `${header()}<main class="auth"><div class="authBrand"><img src="assets/skill4grow-logo.jpg"><h2>Account</h2><p>Sign in to keep your saved courses available on this device.</p></div><div class="authForm"><div class="authTabs"><button id="tabLogin" class="active" onclick="authMode('login')">Login</button><button id="tabSignup" onclick="authMode('signup')">Sign Up</button></div><h2 id="authTitle">Login</h2><input id="authEmail" type="email" placeholder="Email address" autocomplete="email"><input id="authPassword" type="password" placeholder="Password" autocomplete="current-password"><button class="btn" onclick="submitAuth()" id="authSubmit">Login</button><div class="or">or</div><button class="outline full" onclick="googleAuth()">Continue with Google</button><p id="authMsg">Connect Supabase in <code>supabase-config.js</code> to enable accounts.</p></div></main>${footer()}`}
function authMode(m){authModeValue=m;document.getElementById('authTitle').textContent=m==='login'?'Login':'Create account';document.getElementById('authSubmit').textContent=m==='login'?'Login':'Sign Up';document.getElementById('tabLogin').classList.toggle('active',m==='login');document.getElementById('tabSignup').classList.toggle('active',m==='signup')}
async function submitAuth(){const email=document.getElementById('authEmail').value.trim(),password=document.getElementById('authPassword').value, msg=document.getElementById('authMsg');const client=sb();if(!client){msg.textContent='Supabase is not connected yet.';return}msg.textContent='Please wait…';let r=authModeValue==='login'?await client.auth.signInWithPassword({email,password}):await client.auth.signUp({email,password});msg.textContent=r.error?r.error.message:(authModeValue==='login'?'Logged in.':'Account created. Check your email if confirmation is enabled.');if(!r.error)setTimeout(()=>location.hash='home',700)}
async function googleAuth(){const client=sb();const msg=document.getElementById('authMsg');if(!client){msg.textContent='Supabase is not connected yet.';return}const {error}=await client.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin+location.pathname+'#login'}});if(error)msg.textContent=error.message}

function contactPage(){return `${header()}<main class="formPage"><section class="formHero"><div class="eyebrow pill">GET IN TOUCH</div><h1>Let's build a better learning experience.</h1><p>Found an issue, want to suggest a course, or need help? Send a message.</p></section><section class="formCard"><form onsubmit="submitContact(event)"><div class="formRow"><label>Name<input required id="contactName" placeholder="Your name"></label><label>Email<input required type="email" id="contactEmail" placeholder="you@example.com"></label></div><label>Reason<select id="contactReason"><option>Course suggestion</option><option>Broken course link</option><option>General feedback</option><option>Other</option></select></label><label>Message<textarea required id="contactMessage" rows="6" placeholder="Write your message..."></textarea></label><button class="btn full" type="submit">Send Message ↗</button><p id="contactMsg" class="formMsg"></p></form></section></main>${footer()}`}
function submitContact(e){e.preventDefault();const msg=document.getElementById('contactMsg');msg.textContent='Thanks! Your message is ready to be connected to your preferred form backend.';e.target.reset()}

function adminPage(){return `${header()}<main class="page"><section class="pageHero"><div><div class="eyebrow">ADMIN</div><h1>Dashboard</h1><p>Catalog overview.</p></div></section><div class="adminStats"><div><b>${courses.length}</b><small>Total Courses</small></div><div><b>${CATEGORIES.length}</b><small>Categories</small></div></div></main>${footer()}`}

const THEMES=['neon','aurora','violet'];
function applyTheme(){const t=localStorage.getItem('s4g_theme')||'neon';document.body.dataset.theme=t;}
function cycleTheme(){const cur=localStorage.getItem('s4g_theme')||'neon';const next=THEMES[(THEMES.indexOf(cur)+1)%THEMES.length];localStorage.setItem('s4g_theme',next);applyTheme();}

function render(){const raw=decodeURIComponent(location.hash.slice(1)||'home');let html;if(raw==='home')html=home();else if(raw==='courses')html=coursesPage();else if(raw.startsWith('courses/')){category=raw.slice(8)||'All';query='';html=coursesPage();}else if(raw==='saved')html=savedPage();else if(raw==='login')html=loginPage();else if(raw==='contact')html=contactPage();else if(raw==='admin')html=adminPage();else html=home();document.getElementById('app').innerHTML=html;applyTheme();const nm=localStorage.getItem('s4g_name');const line=document.getElementById('welcomeNameLine');if(line&&nm)line.textContent=`Welcome, ${nm} ✨`;window.scrollTo(0,0);requestAnimationFrame(()=>revealOnScroll());}

function showWelcome(){if(localStorage.getItem('s4g_name'))return;const el=document.createElement('div');el.className='welcomeOverlay';el.innerHTML=`<div class="welcomeCard"><button class="welcomeClose" onclick="this.closest('.welcomeOverlay').remove()" aria-label="Close">×</button><div class="welcomeLogo">${logo()}</div><div class="eyebrow pill">WELCOME TO SKILL4GROW</div><h2>What should we call you?</h2><p>Enter your name once and we'll keep your Skill4Grow experience personal.</p><form onsubmit="saveWelcome(event)"><input id="welcomeName" required maxlength=40 autocomplete="name" placeholder="Your name"><button class="btn full" type="submit">Continue to Skill4Grow ↗</button></form></div>`;document.body.appendChild(el);setTimeout(()=>document.getElementById('welcomeName')?.focus(),120)}
function saveWelcome(e){e.preventDefault();const n=document.getElementById('welcomeName').value.trim();if(!n)return;localStorage.setItem('s4g_name',n);e.target.closest('.welcomeOverlay').classList.add('closing');setTimeout(()=>e.target.closest('.welcomeOverlay')?.remove(),220)}
async function init(){try{const r=await fetch('data.json');const payload=await r.json();courses=Array.isArray(payload)?payload:(payload.courses||[])}catch(e){courses=[]}render();window.addEventListener('hashchange',render);showWelcome()}
init();

function revealOnScroll(){document.querySelectorAll('.reveal').forEach(el=>{el.classList.add('visible')})}
