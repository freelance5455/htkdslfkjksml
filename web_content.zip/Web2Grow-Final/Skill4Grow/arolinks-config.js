/* Skill4Grow Arolinks configuration.
   NOTE: The Arolinks browser script requires its token client-side.
   Rotate this token in Arolinks if it has been exposed publicly.
*/
window.S4G_AROLINKS = {
  app_url: 'https://arolinks.com/',
  app_api_token: '526100fb5f4f14e961066faf55c118875499058e',
  app_advert: 2,
  app_exclude_domains: ['skill4grow.vercel.app','https://skill4grow.vercel.app/']
};
