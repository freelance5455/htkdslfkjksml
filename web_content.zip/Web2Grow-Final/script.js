const nav=document.querySelector(".nav");addEventListener("scroll",()=>nav.classList.toggle("scrolled",scrollY>20),{passive:true});
const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add("visible")),{threshold:.12});document.querySelectorAll(".reveal").forEach(e=>io.observe(e));
const c=document.querySelector("#particles"),x=c.getContext("2d");let p=[];function resize(){c.width=innerWidth*devicePixelRatio;c.height=innerHeight*devicePixelRatio;x.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);p=Array.from({length:Math.min(70,Math.floor(innerWidth/18))},()=>({x:Math.random()*innerWidth,y:Math.random()*innerHeight,r:Math.random()*1.3+.3,v:(Math.random()-.5)*.15}))}function draw(){x.clearRect(0,0,innerWidth,innerHeight);p.forEach(a=>{a.y+=a.v;if(a.y>innerHeight+5)a.y=-5;if(a.y<-5)a.y=innerHeight+5;x.beginPath();x.arc(a.x,a.y,a.r,0,7);x.fillStyle="rgba(130,210,255,.32)";x.fill()});requestAnimationFrame(draw)}resize();addEventListener("resize",resize);draw();
/* Join popup: first visit only; "Already joined" remembers the choice. */
const joinOverlay=document.querySelector("#joinOverlay"),alreadyJoined=document.querySelector("#alreadyJoined"),joinClose=document.querySelector("#joinClose");
function closeJoin(){joinOverlay.classList.remove("show");joinOverlay.setAttribute("aria-hidden","true");document.body.style.overflow="";}
if(!localStorage.getItem("web2grow_join_seen")){setTimeout(()=>{joinOverlay.classList.add("show");joinOverlay.setAttribute("aria-hidden","false");document.body.style.overflow="hidden"},350)}
alreadyJoined?.addEventListener("click",()=>{localStorage.setItem("web2grow_join_seen","1");closeJoin()});
document.querySelectorAll(".join-btn").forEach(btn=>btn.addEventListener("click",()=>localStorage.setItem("web2grow_join_seen","1")));
joinClose?.addEventListener("click",closeJoin);
joinOverlay?.addEventListener("click",e=>{if(e.target===joinOverlay)closeJoin()});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&joinOverlay.classList.contains("show"))closeJoin()});
