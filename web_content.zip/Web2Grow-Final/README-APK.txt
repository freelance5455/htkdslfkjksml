WEB2GROW — MERGED ANDROID WEBVIEW PACKAGE

START FILE: index.html (inside Web2Grow-Final folder)

Included projects:
- Web2Grow home page
- Learn4Grow (Learn4Grow/index.html)
- Skill4Grow (Skill4Grow/index.html)

HTML-to-APK Builder setup:
1. Extract this ZIP.
2. Select Web2Grow-Final/index.html as the start/home HTML file (or upload the extracted Web2Grow-Final folder if the builder accepts folders).
3. Enable JavaScript and DOM storage/local storage.
4. Allow external HTTPS navigation / external links.
5. For Telegram links, the builder should allow opening https://t.me/... in the same WebView or hand it to the Telegram app. Do not force tg:// links to load as web pages.

Android WebView adjustments included:
- Web2Grow project cards point to the bundled local project folders, so Learn4Grow and Skill4Grow stay inside the same app.
- target=_blank removed to avoid popup-window behavior in WebView. External resource URLs remain intact.
- Skill4Grow course transition route is relative (Skill4Grow/open.html), so it no longer jumps to the app root.
- Learn4Grow service-worker registration is relative to its folder.

IMPORTANT:
- URL shorteners (ShrinkMe for Learn4Grow and Arolinks for Skill4Grow) require internet access and their provider services/tokens to remain valid. This ZIP preserves their existing integrations and does not guarantee the providers will accept redirects from a file:// WebView origin. For the most reliable production APK, use the hosted Vercel versions as remote pages or host the merged project on HTTPS with the existing configurations.
- Supabase-backed features also require internet and valid project configuration.
