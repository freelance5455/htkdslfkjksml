# Web2Grow

Mobile-first Web2Grow hub.

- Responsive layout for desktop, tablet and mobile.
- Skill4Grow and Learn4Grow cards are direct links.
- Telegram and WhatsApp are now attractive rounded buttons near the top of the homepage.
- Footer social buttons removed.
- First-visit join popup with Telegram, WhatsApp and Already joined.
- Optimized WebP logos for fast loading.

Channels:
- Telegram: https://t.me/web2grow
- WhatsApp: https://whatsapp.com/channel/0029VbDutcjEVccC3orL9j0k
