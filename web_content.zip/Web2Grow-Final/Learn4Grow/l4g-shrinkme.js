/*!
 * Learn4Grow — ShrinkMe.io bridge
 *
 * WHY THIS EXISTS
 * ShrinkMe's full-page-script.js scans document.getElementsByTagName('a') exactly once,
 * inside a DOMContentLoaded listener, and rewrites each matching href. It does not observe
 * the DOM and it never runs again. Learn4Grow builds its platform cards after that moment
 * (Supabase fetch -> innerHTML), so those links were never seen by it.
 *
 * WHAT THIS DOES
 * Instead of scanning once, it rewrites an <a> lazily, at the moment a user interacts with it
 * (pointerdown / touchstart / contextmenu / auxclick / click / focusin), using a single
 * delegated capture-phase listener on document. Because nothing is bound to individual
 * elements, it works for every link no matter when or how it was created: static HTML,
 * Supabase cards, re-renders, search results, the command palette, AI chips, and anchors
 * created and .click()-ed programmatically.
 *
 * The generated URL is byte-for-byte the format ShrinkMe's own script produces:
 *   app_url + 'full?api=' + encodeURIComponent(app_api_token)
 *           + '&url=' + base64(encodeURIComponent(href)) + '&type=' + app_advert
 *
 * Configuration is read from the same globals ShrinkMe documents
 * (app_url, app_api_token, app_advert, app_exclude_domains) — nothing is duplicated here.
 *
 * No MutationObserver, no polling, no re-initialisation: nothing to loop.
 */
(function (root, factory) {
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;   // for tests
  else { root.L4GShrink = api; api.install(); }
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';

  var MARK = 'l4gSm';        // dataset flag: this anchor already points at ShrinkMe
  var ORIG = 'l4gOrig';      // dataset: original destination, kept for reference/debugging

  // Hosts that must never be shortened, in addition to app_exclude_domains.
  var ALWAYS_DIRECT = [
    'learn4grow.vercel.app', 'localhost', '127.0.0.1', '[::1]', '::1',
    '*.supabase.co', '*.supabase.in'
  ];

  // Static assets are never resource destinations.
  var ASSET_EXT = /\.(?:png|jpe?g|gif|webp|avif|svg|ico|bmp|css|js|mjs|map|json|woff2?|ttf|otf|eot)$/i;
  // Admin / auth style paths are never resource destinations.
  var AUTH_PATH = /^\/(?:admin|auth|oauth2?|login|logout|signin|sign-in|signup|sign-up|callback)(?:\/|$)/i;

  function hostOf(value) {
    // Accepts "host", "*.host", "https://host/path" and returns a bare lower-case host.
    var s = String(value || '').trim().toLowerCase();
    if (!s) return '';
    s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//, '').split(/[\/?#]/)[0].replace(/:\d+$/, '').replace(/\.$/, '');
    return s;
  }

  function hostMatches(list, host) {
    var bare = host.replace(/^www\./, '');
    for (var i = 0; i < list.length; i++) {
      var e = list[i];
      if (e.charAt(0) === '*' && e.charAt(1) === '.') {           // wildcard: *.example.com
        var suffix = e.slice(2);
        if (host === suffix || host.slice(-(suffix.length + 1)) === '.' + suffix) return true;
      } else if (e === host || e.replace(/^www\./, '') === bare) {
        return true;
      }
    }
    return false;
  }

  function cfg() {
    var c = root;
    var base = String(c.app_url || '');
    var token = c.app_api_token;
    if (!base || !token) return null;
    if (base.charAt(base.length - 1) !== '/') base += '/';
    var type = 1;
    if (c.app_advert === 2) type = 2; else if (c.app_advert === 0) type = 0;   // same rule as ShrinkMe's script

    var excl = ALWAYS_DIRECT.slice();
    (c.app_exclude_domains || []).forEach(function (d) { var h = hostOf(d); if (h) excl.push(h); });
    if (root.location && root.location.hostname) excl.push(root.location.hostname.toLowerCase());   // current origin (incl. preview deploys)
    if (c.L4G_SUPABASE && c.L4G_SUPABASE.url) excl.push(hostOf(c.L4G_SUPABASE.url));
    excl.push(hostOf(base));                                                                         // never re-shorten a ShrinkMe URL
    return { base: base, token: token, type: type, exclude: excl };
  }

  // Identical to app_base64_encode in ShrinkMe's script.
  function b64(s) {
    return btoa(encodeURIComponent(s).replace(/%([0-9A-F]{2})/g, function (m, n) { return String.fromCharCode('0x' + n); }));
  }

  function eligible(url, c) {
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return false;
    var host = url.hostname.toLowerCase();
    if (!host || hostMatches(c.exclude, host)) return false;
    if (ASSET_EXT.test(url.pathname) || AUTH_PATH.test(url.pathname)) return false;
    return true;
  }

  // Public helper: returns the ShrinkMe URL for an absolute/relative URL, or the input unchanged.
  function wrap(href, baseHref) {
    var c = cfg(); if (!c) return href;
    var u;
    try { u = new URL(href, baseHref || (root.location && root.location.href)); } catch (e) { return href; }
    if (!eligible(u, c)) return href;
    return c.base + 'full?api=' + encodeURIComponent(c.token) + '&url=' + b64(u.href) + '&type=' + encodeURIComponent(c.type);
  }

  function process(a) {
    if (!a || !root.HTMLAnchorElement || !(a instanceof root.HTMLAnchorElement) || a.dataset[MARK] === '1') return;
    // IMPORTANT: ShrinkMe is limited to explicit study-resource links only.
    // Welcome forms, popups, tutorial video, navigation, social/contact links and other UI stay direct.
    if (a.getAttribute('data-shrink-resource') !== '1') return;
    if (a.hasAttribute('data-direct-telegram') || a.hasAttribute('data-no-shrink') || a.closest('[data-no-shrink]')) return;
    var directHref = a.href;
    var directList = [
      'https://t.me/learnfourgrow',
      'https://www.youtube.com/channel/UC0P1HRCjQ9vyNNzxl_FgpDw',
      'https://whatsapp.com/channel/0029Vb8f2DU0rGiJ9yCqZJ1l'
    ];
    if (directList.indexOf(directHref) !== -1) return;
    if (a.hasAttribute('download') && !a.getAttribute('href')) return;
    var raw = a.getAttribute('href');
    if (!raw || raw.charAt(0) === '#') return;
    var out = wrap(a.href);                 // a.href is already absolute
    if (out === a.href) return;             // not eligible -> untouched
    a.dataset[ORIG] = a.href;
    a.dataset[MARK] = '1';
    a.setAttribute('href', out);
  }

  function onEvent(ev) {
    var t = ev.target;
    if (!t || !t.closest) t = t && t.parentElement;
    if (!t || !t.closest) return;
    process(t.closest('a[href]'));
  }

  var installed = false;
  function install() {
    if (installed || !root.document) return;
    installed = true;
    ['pointerdown', 'touchstart', 'mousedown', 'contextmenu', 'auxclick', 'click', 'focusin'].forEach(function (name) {
      root.document.addEventListener(name, onEvent, { capture: true, passive: true });
    });
  }

  return { install: install, wrap: wrap, process: process, _cfg: cfg, _b64: b64 };
});
