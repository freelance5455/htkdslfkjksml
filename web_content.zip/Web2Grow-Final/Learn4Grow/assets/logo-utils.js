/* Learn4Grow v16 logo delivery helper.
 * Keeps the original source URL as the data source, but asks wsrv.nl to resize/cache
 * remote logos to a small WebP for faster delivery. If the optimizer fails, the
 * browser retries the original URL and finally Learn4Grow's local fallback.
 */
(function(){
  const FALLBACK='/assets/learn4grow-logo.svg';
  function isRemote(u){return typeof u==='string' && /^https?:\/\//i.test(u);}
  function optimized(u,size){
    if(!isRemote(u)) return u || FALLBACK;
    const s=Math.max(48,Math.min(160,Number(size)||96));
    return 'https://wsrv.nl/?url='+encodeURIComponent(u)+'&w='+s+'&h='+s+'&fit=contain&we&output=webp&q=72';
  }
  function set(img,original,size){
    if(!img)return;
    const u=String(original||'').trim();
    img.dataset.originalSrc=u;
    img.dataset.logoFallback='0';
    img.onerror=function(){
      if(this.dataset.logoFallback==='0' && u && this.src!==u){
        this.dataset.logoFallback='1'; this.src=u; return;
      }
      this.onerror=null; this.src=FALLBACK;
    };
    img.src=optimized(u,size||96);
  }
  window.L4GLogo={optimized,set,fallback:FALLBACK};
})();
