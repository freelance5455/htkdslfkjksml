// Learn4Grow — Supabase Free project
window.L4G_SUPABASE = {
  url: 'https://cnrfjslmmejswbszvjwi.supabase.co',
  anonKey: 'sb_publishable_u8NyLTXpQ4zYHHpiP1jvig_Kb9x4trh'
};
