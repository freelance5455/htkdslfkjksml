作业打卡表｜安卓安装版（PWA）

这是一个可安装到安卓手机主屏幕的网页应用包，不是直接双击安装的 APK。

重要说明
- 完全免费，无需数据库、付费服务器或注册账号。
- 班级、学生、作业记录保存在浏览器本机存储中。
- 首次打开需要联网；成功安装并缓存后，核心页面可离线打开。
- 重新安装、清除浏览器/网站数据、换手机等情况可能导致本地记录丢失。请定期使用应用内“导出备份”，并把 JSON 备份保存到手机文件或 Google Drive。
- 本包不保证 Android 系统自动备份一定会备份网页本地数据。

如何免费发布并安装
1. 在电脑上登录 GitHub，创建一个新的公开仓库，例如 homework-tracker。
2. 解压本压缩包，将里面的 index.html、manifest.webmanifest、sw.js、icons 文件夹和本说明上传到仓库根目录（不要把整个 homework_tracker_app 文件夹再套一层）。
3. 在仓库 Settings → Pages 中，将 Build and deployment 设为 Deploy from a branch；选择 main 分支和 /(root)，保存。
4. 等待 GitHub Pages 发布完成。打开 Settings → Pages 显示的网址，通常形如 https://用户名.github.io/homework-tracker/。
5. 用安卓手机 Chrome 打开这个网址，等待页面加载成功。
6. Chrome 右上角 ⋮ 菜单中选择“安装应用”或“添加到主屏幕”（具体文案因版本而异）。
7. 安装后，从手机桌面打开“作业打卡表”。首次使用先建测试班级，确认记录保存、离线打开和导出/恢复备份正常，再录入真实数据。

更新应用
- 更新文件后推送到 GitHub Pages。新版本可能需要重新打开应用或刷新页面；Service Worker 会在浏览器更新时替换缓存。

隐私提示
- 此版本没有把学生数据上传到 GitHub Pages；GitHub Pages 只托管静态应用文件。不要把含真实学生信息的备份文件上传到公开仓库。
