# APK Forge 1.0

Aplicação web local para montar APKs a partir de:
- Projetos HTML/CSS/JS em ZIP contendo `index.html`.
- Projetos Android Gradle confiáveis contendo `gradlew` e `gradle/wrapper`.

## Iniciar

Requisitos: Docker Desktop ou Docker Engine + Docker Compose.

```bash
docker compose up --build
```

Abra `http://localhost:3000` no navegador.

## Como funciona

1. Envie um ZIP do projeto.
2. Informe nome e identificador Android (ex.: `com.exemplo.meuapp`).
3. Opcionalmente envie ícone PNG/JPG.
4. Escolha a tela de carregamento e a preparação de anúncios.
5. O servidor compila e assina o APK, e devolve o arquivo.

## Limitações importantes da versão 1.0

- HTML: o ZIP deve conter `index.html`; os arquivos da mesma pasta são copiados para os assets do app. É um WebView Android básico.
- Android: o projeto deve ser confiável e incluir Gradle Wrapper. A versão atual compila `assembleDebug` e assina novamente o APK produzido. Projetos com configurações especiais, múltiplos módulos, flavors ou requisitos de SDK podem precisar de adaptação.
- O ícone enviado é recebido, mas a aplicação ainda não gera automaticamente todos os tamanhos de launcher icon nesta versão.
- A tela de carregamento é simples. A opção de anúncios apenas registra a intenção; não inclui SDK, anúncios reais ou rastreamento. Para publicar anúncios, integre um provedor oficial, configure consentimento e política de privacidade.
- O build Android pode demorar na primeira execução porque baixa componentes e dependências.

## Segurança e assinatura

**Use somente projetos seus ou para os quais você tenha autorização.** Projetos Gradle podem executar código durante a compilação. Não envie ZIPs desconhecidos ou não confiáveis. Para uso público, execute cada build em um ambiente isolado e descartável, com limites de CPU, memória, tempo e armazenamento.

A chave de assinatura é criada pelo servidor. A senha e o keystore devem ser guardados com segurança. Se perder a chave, talvez não consiga publicar atualizações como atualização do mesmo aplicativo. Não compartilhe o arquivo `CHAVE-DE-ASSINATURA.txt`.

## Não é um APK Android pronto

Este ZIP contém o código-fonte do APK Forge e sua infraestrutura de compilação. O próprio APK Forge ainda precisa ser executado em um computador/servidor com Docker. Ele não compila projetos Android diretamente no celular nesta versão.
