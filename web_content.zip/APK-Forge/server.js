const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn } = require("child_process");

const app = express();
const PORT = process.env.PORT || 3000;
const WORK = path.join(os.tmpdir(), "apk-forge-jobs");
fs.mkdirSync(WORK, { recursive: true });
app.use(express.static(path.join(__dirname, "public")));
const upload = multer({
  dest: path.join(WORK, "uploads"),
  limits: { fileSize: 100 * 1024 * 1024 }
});

const safeName = s => String(s || "").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 48);
const validPackage = s => /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,5}$/.test(s);

function run(command, args, cwd, log) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, shell: false, env: process.env });
    child.stdout.on("data", d => log(d.toString()));
    child.stderr.on("data", d => log(d.toString()));
    child.on("error", reject);
    child.on("close", code => code === 0 ? resolve() : reject(new Error(`${command} terminou com código ${code}`)));
  });
}
function safeExtract(zipPath, destination) {
  const zip = new AdmZip(zipPath);
  for (const entry of zip.getEntries()) {
    const name = entry.entryName.replace(/\\/g, "/");
    if (name.startsWith("/") || name.split("/").includes("..")) throw new Error("ZIP contém caminho inseguro.");
    const target = path.resolve(destination, name);
    if (!target.startsWith(path.resolve(destination) + path.sep) && target !== path.resolve(destination))
      throw new Error("Caminho inválido no ZIP.");
  }
  zip.extractAllTo(destination, true);
}
function findFile(dir, filename, depth = 0) {
  if (depth > 4) return null;
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    if (item.name === "node_modules" || item.name === ".git" || item.name === "build") continue;
    const full = path.join(dir, item.name);
    if (item.isFile() && item.name === filename) return full;
    if (item.isDirectory()) { const found = findFile(full, filename, depth + 1); if (found) return found; }
  }
  return null;
}
function javaSource(packageId, appName, splash) {
  const pkg = packageId;
  return `package ${pkg};
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.view.Gravity;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  if (${splash ? "true" : "false"}) {
   TextView loading = new TextView(this);
   loading.setText(${JSON.stringify(appName)} + "\\nCarregando...");
   loading.setTextColor(Color.WHITE); loading.setBackgroundColor(Color.rgb(18,22,35));
   loading.setGravity(Gravity.CENTER); loading.setTextSize(22);
   setContentView(loading);
  }
  WebView web = new WebView(this);
  web.setWebViewClient(new WebViewClient());
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.loadUrl("file:///android_asset/index.html");
  setContentView(web);
 }
}`;
}
function createHtmlAndroidProject(sourceDir, projectDir, opts) {
  const index = findFile(sourceDir, "index.html");
  if (!index) throw new Error("Não encontrei index.html dentro do ZIP.");
  const assets = path.join(projectDir, "app/src/main/assets");
  const javaDir = path.join(projectDir, "app/src/main/java", ...opts.packageId.split("."));
  fs.mkdirSync(assets, { recursive: true });
  fs.mkdirSync(javaDir, { recursive: true });
  fs.cpSync(path.dirname(index), assets, { recursive: true });
  const appGradle = `plugins { id 'com.android.application' }
android {
 namespace '${opts.packageId}'
 compileSdk 35
 defaultConfig { applicationId '${opts.packageId}'; minSdk 23; targetSdk 35; versionCode 1; versionName '1.0' }
}
`;
  fs.writeFileSync(path.join(projectDir, "settings.gradle"), "pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = 'ApkForgeBuild'\ninclude ':app'\n");
  fs.writeFileSync(path.join(projectDir, "build.gradle"), "plugins { id 'com.android.application' version '8.7.3' apply false }\n");
  fs.writeFileSync(path.join(projectDir, "gradle.properties"), "org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n");
  fs.mkdirSync(path.join(projectDir, "app"), { recursive: true });
  fs.writeFileSync(path.join(projectDir, "app/build.gradle"), appGradle);
  fs.writeFileSync(path.join(projectDir, "app/src/main/AndroidManifest.xml"),
    `<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="${opts.appName.replace(/[&<>"]/g, "")}" android:usesCleartextTraffic="true"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>`);
  fs.writeFileSync(path.join(javaDir, "MainActivity.java"), javaSource(opts.packageId, opts.appName, opts.splash));
  if (opts.iconPath && fs.existsSync(opts.iconPath)) {
    const mip = path.join(projectDir, "app/src/main/res/drawable");
    fs.mkdirSync(mip, { recursive: true });
    fs.copyFileSync(opts.iconPath, path.join(mip, "forge_icon.png"));
  }
  // Ad integration is deliberately a safe placeholder: no ad network SDK or tracking is bundled.
  if (opts.ads) fs.writeFileSync(path.join(assets, "APK_FORGE_ADS.txt"),
    "Anúncios ativados na configuração. Integre um SDK oficial de anúncios, com consentimento e política de privacidade, antes de publicar.");
}
async function signApk(apk, dir, log) {
  const ks = path.join(dir, "apk-forge-release.jks");
  const alias = "apkforge";
  const password = crypto.randomBytes(18).toString("hex");
  await run("keytool", ["-genkeypair", "-v", "-keystore", ks, "-storepass", password, "-keypass", password,
    "-alias", alias, "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
    "-dname", "CN=APK Forge, OU=Local Build, O=APK Forge, L=Unknown, ST=Unknown, C=BR"], dir, log);
  const out = path.join(dir, "APK-Forge-assinado.apk");
  const apksigner = process.env.APK_SIGNER || "apksigner";
  await run(apksigner, ["sign", "--ks", ks, "--ks-key-alias", alias, "--ks-pass", `pass:${password}`,
    "--key-pass", `pass:${password}`, "--out", out, apk], dir, log);
  await run(apksigner, ["verify", "--verbose", out], dir, log);
  fs.writeFileSync(path.join(dir, "CHAVE-DE-ASSINATURA.txt"),
    `Guarde esta chave e senha em local seguro. Sem elas, atualizações futuras podem não ser aceitas pela mesma identidade de assinatura.\nKeystore: apk-forge-release.jks\nAlias: ${alias}\nSenha: ${password}\n`);
  return out;
}
app.post("/api/build", upload.fields([{ name: "project", maxCount: 1 }, { name: "icon", maxCount: 1 }]), async (req, res) => {
  const projectFile = req.files?.project?.[0];
  if (!projectFile) return res.status(400).json({ error: "Envie um ZIP do projeto." });
  const jobId = crypto.randomUUID();
  const dir = path.join(WORK, jobId);
  const log = s => { try { fs.appendFileSync(path.join(dir, "build.log"), s); } catch {} };
  try {
    const appName = String(req.body.appName || "Meu Aplicativo").trim().slice(0, 40);
    const packageId = String(req.body.packageId || "com.example.meuapp").trim();
    if (!validPackage(packageId)) throw new Error("Identificador inválido. Exemplo: com.exemplo.meuapp");
    fs.mkdirSync(dir, { recursive: true });
    const source = path.join(dir, "source"), project = path.join(dir, "android");
    fs.mkdirSync(source); fs.mkdirSync(project);
    safeExtract(projectFile.path, source);
    const opts = { appName, packageId, splash: req.body.splash === "true", ads: req.body.ads === "true",
      iconPath: req.files?.icon?.[0]?.path };
    const gradleFile = findFile(source, "gradlew");
    let projectRoot;
    if (gradleFile) {
      projectRoot = path.dirname(gradleFile);
      log("Projeto Android detectado. Compilando variante debug para gerar APK instalável...\n");
      await run(process.platform === "win32" ? "gradlew.bat" : "./gradlew", ["assembleDebug"], projectRoot, log);
    } else {
      const buildGradle = findFile(source, "build.gradle");
      if (buildGradle) throw new Error("Projeto Android sem Gradle Wrapper. Inclua gradlew e a pasta gradle/wrapper no ZIP.");
      createHtmlAndroidProject(source, project, opts);
      projectRoot = project;
      log("Projeto HTML detectado. Criando aplicativo Android com WebView...\n");
      await run("gradle", ["assembleDebug"], projectRoot, log);
    }
    const apk = findFile(path.join(projectRoot, "app/build/outputs/apk"), "app-debug.apk") ||
      findFile(path.join(projectRoot, "app/build/outputs/apk"), "app-release-unsigned.apk");
    if (!apk) throw new Error("A compilação terminou, mas nenhum APK esperado foi encontrado. Consulte build.log.");
    const signed = await signApk(apk, dir, log);
    res.download(signed, `${safeName(appName)}-assinado.apk`, () => {
      fs.rmSync(dir, { recursive: true, force: true });
      fs.rmSync(projectFile.path, { force: true });
      if (opts.iconPath) fs.rmSync(opts.iconPath, { force: true });
    });
  } catch (e) {
    log(`\nERRO: ${e.message}\n`);
    const details = fs.existsSync(path.join(dir, "build.log")) ? fs.readFileSync(path.join(dir, "build.log"), "utf8").slice(-12000) : "";
    res.status(500).json({ error: e.message, log: details });
  }
});
app.get("/api/health", (_, res) => res.json({ ok: true, service: "APK Forge" }));
app.listen(PORT, () => console.log(`APK Forge em http://localhost:${PORT}`));
