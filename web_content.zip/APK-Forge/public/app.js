const form = document.querySelector("#builder");
const project = document.querySelector("#project");
const icon = document.querySelector("#icon");
const statusBox = document.querySelector("#status");
const logBox = document.querySelector("#log");
const button = document.querySelector("#build");
project.addEventListener("change", () => document.querySelector("#fileName").textContent = project.files[0]?.name || "Nenhum arquivo selecionado");
icon.addEventListener("change", () => document.querySelector("#iconName").textContent = icon.files[0]?.name || "Ícone padrão do Android se não escolher um");
form.addEventListener("submit", async event => {
  event.preventDefault();
  if (!project.files.length) return;
  const data = new FormData();
  data.append("project", project.files[0]);
  if (icon.files[0]) data.append("icon", icon.files[0]);
  data.append("appName", form.appName.value);
  data.append("packageId", form.packageId.value);
  data.append("splash", String(form.splash.checked));
  data.append("ads", String(form.ads.checked));
  button.disabled = true; statusBox.textContent = "Preparando compilação... isso pode levar alguns minutos.";
  logBox.hidden = true; logBox.textContent = "";
  try {
    const response = await fetch("/api/build", { method: "POST", body: data });
    const type = response.headers.get("content-type") || "";
    if (!response.ok) {
      const result = type.includes("json") ? await response.json() : { error: await response.text() };
      statusBox.textContent = "Falha na compilação: " + (result.error || "erro desconhecido");
      logBox.textContent = result.log || ""; logBox.hidden = !result.log;
      return;
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url;
    a.download = `${form.appName.value.trim().replace(/[^a-z0-9_-]/gi,"_")}-assinado.apk`;
    a.click(); URL.revokeObjectURL(url);
    statusBox.textContent = "APK assinado gerado! O download deve começar automaticamente. Confira também o arquivo CHAVE-DE-ASSINATURA no servidor e guarde-o com segurança.";
  } catch (error) { statusBox.textContent = "Não foi possível conectar ao servidor: " + error.message; }
  finally { button.disabled = false; }
});