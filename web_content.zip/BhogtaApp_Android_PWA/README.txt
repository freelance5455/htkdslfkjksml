BhogtaApp Android-installable PWA
1. Upload all files in this folder to an HTTPS website/hosting.
2. Open the hosted index.html in Chrome on Android.
3. Chrome menu (⋮) > Install app / Add to Home screen.
4. Test admin PIN: 1234.

IMPORTANT:
- This starter version stores donation/expense records only on the same phone/browser using localStorage.
- It is NOT a shared online ledger; public users on other phones will not see admin entries.
- PIN 1234 is demo-only and is not secure authentication.
- The supplied UPI number 9006024424 is shown as entered. Verify ownership before publishing.
- Replace the QR placeholder with the verified official UPI QR.
- For a real public app with shared records, secure admin login, cloud backup and audit trail, connect a Firebase project and implement Firestore Security Rules. Never put admin secrets in frontend code.
