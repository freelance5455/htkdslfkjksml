/* =====================================================
   story.js —— 第六章「潮退」（剧本与素材配置）
   你只需要改这个文件，就能换文本、立绘、背景、CG、视频、音频。
   素材路径找不到时，引擎会显示占位图 / 渐变底色，不会报错。
   指令说明见 README.md，所需素材清单见 ASSETS.md。
   ===================================================== */

/* 小工具：让剧本里的表情切换写得短一些。
   MY("angry","shake") 等价于 {id:"mingyue", expr:"angry", anim:"shake"} */
const CL = (expr, anim) => ({ id: "claude",  expr, anim });
const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
const BL = (expr, anim) => ({ id: "bailong", expr, anim });

/* 三人同台的标准站位（pos 是画面宽度的百分比） */
const LINEUP = [
  { id: "mingyue", pos: 20, expr: "normal" },
  { id: "claude",  pos: 50, expr: "normal" },
  { id: "bailong", pos: 80, expr: "normal" }
];

window.STORY = {

  /* ---------- 基本信息 ---------- */
  meta: {
    id: "servil-ch06",               // 存档命名空间，换剧本时请改成不同的值
    title: "瑟维尔编年",              // 暂定名，随时可改
    subtitle: "CHRONICLES OF SERVIL",
    tag: "CHAPTER 01 — 06",
    version: "v0.4",
    start: null                      // 调试用：填某个 label 名可直接从那里开始
  },

  /* ---------- 角色与立绘 ----------
     目前每人只有一张立绘（normal）。其他表情名在剧本里已经写好，
     没有对应图片时引擎会自动回退到 normal；以后画好差分，
     把下面注释里的行取消注释、改成真实路径即可，剧本不用动。
  */
  characters: {
    claude: {
      name: "克劳德", title: "圣女", color: "#e8893c", height: 660,
      sprites: {
        normal: "assets/chars/claude/normal.png"
        // smile:     "assets/chars/claude/smile.png",
        // serious:   "assets/chars/claude/serious.png",
        // worried:   "assets/chars/claude/worried.png",
        // surprised: "assets/chars/claude/surprised.png",
        // tired:     "assets/chars/claude/tired.png"
      }
    },
    mingyue: {
      name: "溟月", title: "鲸族 · 女仆", color: "#6fa3ee", height: 660,
      sprites: {
        normal: "assets/chars/mingyue/normal.png"
        // happy:     "assets/chars/mingyue/happy.png",
        // angry:     "assets/chars/mingyue/angry.png",
        // shy:       "assets/chars/mingyue/shy.png",
        // worried:   "assets/chars/mingyue/worried.png",
        // surprised: "assets/chars/mingyue/surprised.png"
      }
    },
    bailong: {
      name: "白泷", title: "龙族", color: "#c4bdf0", height: 660,
      sprites: {
        normal: "assets/chars/bailong/normal.png"
        // smile:     "assets/chars/bailong/smile.png",
        // surprised: "assets/chars/bailong/surprised.png",
        // serious:   "assets/chars/bailong/serious.png"
      }
    },
    /* 只出现在对话框里的人物（没有立绘） */
    raymond: { name: "雷蒙", title: "教会执事",   color: "#d8c070" },
    oli:     { name: "奥利", title: "见习执事",   color: "#9fc08a" },
    archbishop: { name: "佩尔图斯", title: "大主教",     color: "#d9d2c0" },
    king:       { name: "奥古斯特", title: "国王",       color: "#e0b64a" },
    gren:       { name: "格伦",     title: "近卫骑士团长", color: "#9fb4c8" },
    qisao:  { name: "七嫂", title: "港口邻居", color: "#d9a07a" },
    laoduo: { name: "老舵", title: "老渔夫",   color: "#9fb4a0" }
  },

  /* ---------- 背景（color 是素材缺失时的渐变底色） ---------- */
  backgrounds: {
    black:         { color: "#000" },
    harbor_dawn:   { src: "assets/bg/harbor_dawn.jpg",
                     color: "linear-gradient(180deg,#1b2a3d 0%,#4a5f78 46%,#c79a7a 78%,#2a3340 100%)" },
    coast_road:    { src: "assets/bg/coast_road.jpg",
                     color: "linear-gradient(180deg,#27363f 0%,#52707f 52%,#1c262d 100%)" },
    seabed_stairs: { src: "assets/bg/seabed_stairs.jpg",
                     color: "linear-gradient(180deg,#04121a 0%,#0b2a35 60%,#020a0e 100%)" },
    sunken_shrine: { src: "assets/bg/sunken_shrine.jpg",
                     color: "radial-gradient(ellipse at 50% 35%,#1d6f86 0%,#082030 46%,#02080c 100%)" },
    harbor_day:    { src: "assets/bg/harbor_day.jpg",
                     color: "linear-gradient(180deg,#5f8196 0%,#a9b9bf 48%,#3a4a53 100%)" },
    hill_view:     { src: "assets/bg/hill_view.jpg",
                     color: "linear-gradient(180deg,#2f3f4f 0%,#7c8f98 46%,#384236 100%)" },
    night_camp:    { src: "assets/bg/night_camp.jpg",
                     color: "radial-gradient(ellipse at 50% 88%,#5a3a1e 0%,#141a24 42%,#06080d 100%)" },
      royal_hall:       { src: "assets/bg/royal_hall.jpg",
                          color: "radial-gradient(ellipse at 50% 20%,#7a5f2a 0%,#2a2118 45%,#0b0907 100%)" },
      service_corridor: { src: "assets/bg/service_corridor.jpg",
                          color: "linear-gradient(180deg,#1c1812 0%,#3a2e20 55%,#14100b 100%)" },
    north_valley: { src: "assets/bg/north_valley.jpg",
                    color: "linear-gradient(180deg,#9fb4c8 0%,#dfe8ee 45%,#8a9aa6 75%,#4c5a64 100%)" },
    dragon_cave:  { src: "assets/bg/dragon_cave.jpg",
                    color: "radial-gradient(ellipse at 50% 70%,#8a6a22 0%,#2a2214 48%,#0a0806 100%)" },
    border_gate:   { src: "assets/bg/border_gate.jpg",
                     color: "linear-gradient(180deg,#8a9aa6 0%,#c9c2b0 50%,#6a5a46 100%)" },
    market_square: { src: "assets/bg/market_square.jpg",
                     color: "linear-gradient(180deg,#b8a58a 0%,#d9c9a8 45%,#7a5c3a 100%)" },
    inn_room:      { src: "assets/bg/inn_room.jpg",
                     color: "radial-gradient(ellipse at 30% 60%,#6a4a28 0%,#241a12 50%,#0b0806 100%)" },
    mist_valley: { src: "assets/bg/mist_valley.jpg",
                   color: "linear-gradient(180deg,#9aa6aa 0%,#c4ccce 50%,#6a7478 100%)" },
    ruin_hall:   { src: "assets/bg/ruin_hall.jpg",
                   color: "radial-gradient(ellipse at 50% 40%,#4a5a5e 0%,#1a2224 55%,#060809 100%)" },
    harbor_dusk: { src: "assets/bg/harbor_dusk.jpg",
                   color: "linear-gradient(180deg,#2a3a52 0%,#8a6a5a 52%,#e0a060 80%,#2a2a2e 100%)" },
    pier_night:  { src: "assets/bg/pier_night.jpg",
                   color: "linear-gradient(180deg,#06090f 0%,#13203a 60%,#1c2c44 100%)" },
    cairn_shore: { src: "assets/bg/cairn_shore.jpg",
                   color: "linear-gradient(180deg,#0e1624 0%,#2a3a50 55%,#14181c 100%)" }
  },

  /* ---------- CG ---------- */
  cgs: {
    cg_ebb:       { src: "assets/cg/ebb_stairs.jpg",
                    color: "linear-gradient(180deg,#46525c 0%,#7d8d95 38%,#1d1b18 62%,#0b0a08 100%)" },
    cg_vision:    { src: "assets/cg/vision.jpg",
                    color: "radial-gradient(ellipse at 50% 45%,#f3e2b0 0%,#7a5d2a 40%,#0b0804 100%)" },
    cg_whalesong: { src: "assets/cg/whalesong.jpg",
                    color: "radial-gradient(ellipse at 50% 40%,#2b86a0 0%,#0a3447 46%,#020b10 100%)" },
    cg_wave:      { src: "assets/cg/wave.jpg",
                    color: "linear-gradient(180deg,#4d5b64 0%,#8e9ea6 34%,#2a3a44 64%,#0c1419 100%)" },
      cg_dragon_raid:  { src: "assets/cg/dragon_raid.jpg",
                         color: "radial-gradient(ellipse at 50% 30%,#d8d4f0 0%,#4a4a6a 40%,#0a0910 100%)" },
      cg_night_flight: { src: "assets/cg/night_flight.jpg",
                         color: "linear-gradient(180deg,#05070d 0%,#0e1830 55%,#1a2438 100%)" },
    cg_hoard: { src: "assets/cg/hoard.jpg",
                color: "radial-gradient(ellipse at 50% 60%,#e0b64a 0%,#6a4e18 40%,#0c0904 100%)" },
    cg_market: { src: "assets/cg/market.jpg",
                 color: "linear-gradient(180deg,#e0c890 0%,#a8804a 50%,#3a2812 100%)" },
    cg_mural: { src: "assets/cg/mural.jpg",
                color: "radial-gradient(ellipse at 50% 45%,#8a7a58 0%,#3a3224 45%,#0a0806 100%)" },
    cg_long_table: { src: "assets/cg/long_table.jpg",
                     color: "linear-gradient(180deg,#3a2a18 0%,#c88a4a 45%,#5a3a1a 100%)" }
  },

  /* ---------- 视频（本章没有用到；用法见 README） ----------
     videos: { tide: { src: "assets/video/tide.mp4", skippable: true } }
     剧本里写 { video: "tide" } 即可
  */
  videos: {},

  /* ---------- 音频（文件不存在则静默） ---------- */
  audio: {
    bgm: {
      harbor: "assets/audio/harbor.mp3",
      road:   "assets/audio/road.mp3",
      ebb:    "assets/audio/ebb.mp3",
      deep:   "assets/audio/deep.mp3",
      alarm:  "assets/audio/alarm.mp3",
      comic:  "assets/audio/comic.mp3",
      camp:   "assets/audio/camp.mp3",
      omen:   "assets/audio/omen.mp3",
        ch01_banquet:  "assets/audio/ch01_banquet.mp3",
        ch01_ceremony: "assets/audio/ch01_ceremony.mp3",
        ch01_raid:     "assets/audio/ch01_raid.mp3",
        ch01_flight:   "assets/audio/ch01_flight.mp3",
      ch02_wild: "assets/audio/ch02_wild.mp3",
      ch02_cave: "assets/audio/ch02_cave.mp3",
      ch02_walk: "assets/audio/ch02_walk.mp3",
      ch03_market: "assets/audio/ch03_market.mp3",
      ch03_inn: "assets/audio/ch03_inn.mp3",
      ch04_mist: "assets/audio/ch04_mist.mp3",
      ch04_mural: "assets/audio/ch04_mural.mp3",
      ch05_harbor: "assets/audio/ch05_harbor.mp3",
      ch05_table: "assets/audio/ch05_table.mp3",
      ch05_night: "assets/audio/ch05_night.mp3"
    },
    sfx: {
      wave:  "assets/audio/wave.mp3",
      stone: "assets/audio/stone.mp3",
        glass: "assets/audio/glass.mp3",
        roar:  "assets/audio/roar.mp3",
      coin: "assets/audio/coin.mp3",
      bite: "assets/audio/bite.mp3",
      whisper: "assets/audio/whisper.mp3",
      gull: "assets/audio/gull.mp3"
    }
  },

  /* =====================================================
     剧本：按顺序执行的数组，每个元素是一"步"
     执行顺序：set → chapter → bgm → hide → bg → show → expr → cg/cgHide → sfx → effect → video → wait → jump/end/choices/text
     含 text 的步会等待点击；其余自动继续。
     分支结构（共 6 条）：
       潮退后的抉择 ─┬─ A 沿阶梯下海 ─┬─ A1 触碰余温
                     │                └─ A2 鲸歌回应
                     ├─ B 回港示警   ─┬─ B1 以圣女之名
                     │                └─ B2 以溟月之名
                     └─ C 登高观望   ─┬─ C1 遗落的花饰
                                      └─ C2 救下执事
       三条主线都在 CAMP（夜）汇合。
     ===================================================== */
  script: [

    /* ##########################  第一章「盟约之夜」  ########################## */

    { label: "ch01_start" },
    { chapter: { no: "CHAPTER 01", title: "盟约之夜", sub: "THE COVENANT · 王都的最后一夜" } },

    /* ---------- 一、镜厅 ---------- */
    { bg: "royal_hall", transition: "black", bgm: "ch01_banquet", hide: "all",
      text: "王都的钟敲了九下。镜厅里三千盏烛火同时被点亮，像是有人把一整片星空，倒扣在了金色的穹顶之下。" },
    { text: "这是王国与教会缔结《复兴盟约》的夜晚。一万年来，神明沉默；而最近的一年里，沉默开始出现了裂缝。" },
    { text: "北境的冰层无故碎裂，南海的季风逆着节令吹了整整一个月，三座古老的神殿，在同一个季度里先后传出了「声音」。" },
    { text: "没有人敢说那是什么。教会替他们说了：那是祂们，要醒了。" },
    { text: "而醒来的神，需要有人去迎接，或者，去安抚。这便是今夜宴会真正的缘由，也是宴会真正的主角，将要背负的事。" },

    { show: { id: "claude", pos: 50, expr: "normal" },
      text: "她站在高台正中，白与橙交织的礼裙，一丝不乱。" },
    { text: "圣女克劳德。教会为她准备了十年的称号，今夜，终于要被所有人念出口。" },
    { text: "她在微笑。嘴角抬起的角度，是大主教亲手纠正过的：向上十五分，不多，不少。" },
    { text: "宾客们看她，像看一件供在神龛里的东西。美丽，端正，不会说话，也不会犯错。" },
    { speaker: "宾客", text: "听说圣女大人从八岁起，就没有睡过一个整觉。真是虔诚啊。" },
    { speaker: "宾客", text: "是啊，到底是神血的孩子，和我们不一样。" },
    { text: "她听见了。微笑的角度，一分也没有变。" },

    /* ---------- 二、大主教 ---------- */
    { show: { id: "claude", pos: 36 }, text: "一只带着戒指的手，从身侧伸过来，替她整了整领口的褶皱。" },
    { who: "archbishop", text: "克劳德。你的手在抖。" },
    { who: "claude", expr: CL("normal"), text: "没有，大人。" },
    { who: "archbishop", text: "那就好。圣女的手，只应该为祈祷而颤。" },
    { text: "他的语气很温和，像在叮嘱一个远行的孩子。这十年里，他每一次这样说话，她都会在当晚的功课里，多抄十遍经文。" },
    { who: "archbishop", text: "去年北境冰裂，死了四百一十七人。你若在那一天学会了第三重祷文，他们本可以活下来。" },
    { text: "这句话，克劳德已经听过很多次。每一次，那个数字都会变得更具体一些，像一枚被反复敲进骨头里的钉子。" },
    { who: "claude", text: "……是。是我来得太迟。" },
    { who: "archbishop", text: "你明白就好。今夜之后，你不再只是克劳德了。去吧，让他们看见你。" },

    /* ---------- 三、走廊里的女仆 ---------- */
    { who: "claude", text: "请容许我，片刻更衣。" },
    { text: "这是她十年里，唯一一句不需要抄经的借口。" },

    { hide: "all", bg: "service_corridor", transition: "black", bgm: null,
      text: "内廷的侧廊没有烛火，只有墙上两盏昏黄的壁灯。宴会的喧闹隔着厚厚的石墙，传来时像是另一个世界在涨潮。" },
    { text: "克劳德靠着墙，闭上了眼睛。嘴角的十五分，终于一寸一寸地，落了下来。" },
    { show: { id: "mingyue", pos: 24, expr: "worried" },
      text: "走廊尽头传来一串急促的脚步声，伴着一个压得极低、却依旧咬牙切齿的声音：" },
    { who: "mingyue", text: "不许掉不许掉不许掉……十二杯，一杯都不许掉……" },
    { text: "一位端着巨大银盘的女仆拐过转角，盘上十二只水晶杯叮当作响，像一群受了惊的鸟。她抬头，看见了站在壁灯下的人。" },
    { show: { id: "claude", pos: 72, expr: "normal" },
      who: "mingyue", expr: MY("surprised", "jump"), text: "圣、圣女大人！！" },
    { sfx: "glass", text: "银盘猛地一歪。那一瞬间，女仆的整个身体像一根被灌了水的柳条，向后弯下去，又弹回来。十二只杯子，一只没碎。" },
    { who: "mingyue", expr: MY("shy"), text: "……成、成功了。" },
    { who: "claude", expr: CL("normal"), text: "内廷的侧廊，不允许侍女单独通行。你为什么在这里？" },
    { who: "mingyue", text: "是！我迷路了！厨房的路标画得跟迷宫一样！" },
    { text: "克劳德没有立刻回答。她的视线，落在了女仆的头顶。" },
    { text: "那里，白色的女仆头饰下，压着一对被刻意按平的耳廓。薄薄的，微微泛着蓝，边缘是鳍的形状。" },
    { text: "亚人。依教会法令，亚人不得踏入内廷一步。" },
    { who: "mingyue", expr: MY("worried"), text: "……您，要叫人吗？" },
    { text: "女仆的声音很轻，却没有躲。她把银盘稳稳地端在身前，像端着自己仅有的一点体面。" },
    { who: "mingyue", text: "我需要这份工。一个月六枚银币，寄回家里，够老舵叔补一张网。" },
    { who: "claude", text: "……家里？" },
    { who: "mingyue", text: "港口。海边的。很小，但是，很吵，很热闹。" },
    { text: "圣典第三卷第七条：凡见异类潜入圣所者，当即告发，不得隐瞒。她背得很熟，熟到可以倒着背。" },
    { text: "可是此刻，她的嘴像被人塞了一团棉花，什么也说不出来。" },
    { who: "claude", text: "……往左，第二道门。厨房在那边。" },
    { who: "mingyue", expr: MY("surprised"), text: "……诶？" },
    { who: "claude", text: "快去。在我改变主意之前。" },
    { who: "mingyue", expr: MY("happy", "jump"), text: "谢、谢谢您！您真是个好人！" },
    { text: "女仆端着银盘跑出去三步，又急刹车，回过头来。" },
    { who: "mingyue", text: "那个，圣女大人。" },
    { who: "mingyue", text: "您刚才在厅里笑的时候，像是被人画上去的。不是不好看，就是……看着累。" },
    { text: "克劳德怔住了。十年里，没有人对她说过这样的话。人们说她「端庄」、「虔诚」、「完美」，唯独没有人说，累。" },
    { who: "mingyue", text: "这个，给您。海盐焦糖。厨房偷的。不是偷，是试毒。" },
    { text: "她用空着的一只手，从围裙口袋里摸出一小块油纸包着的点心，递了过来。纸角被体温焐得微微发软。" },

    { text: "克劳德低头，看着那块点心。教会的圣女，不吃来历不明的东西。",
      choices: [
        { text: "收下，放进袖中", jump: "ch01_sweet_kept",    set: { sweet: "kept" } },
        { text: "冷冷地拒绝",     jump: "ch01_sweet_refused", set: { sweet: "refused" } }
      ] },

    { label: "ch01_sweet_kept" },
    { text: "她没有说话，只是接了过来，指尖碰到了女仆有点凉的手背。点心被她放进了袖中，像放进了一个，不会被检查的地方。" },
    { who: "mingyue", expr: MY("happy"), text: "那我走啦！您，加油！" },
    { jump: "ch01_sweet_end" },

    { label: "ch01_sweet_refused" },
    { who: "claude", expr: CL("normal"), text: "圣女不接受来路不明的食物。收回去。" },
    { who: "mingyue", expr: MY("normal"), text: "哦。……那我自己吃。" },
    { text: "女仆毫不尴尬地把点心塞回了围裙口袋，还顺手拍了拍。她转身离开的时候，圣女听见她小声嘀咕了一句：「真可惜，很好吃的。」" },
    { jump: "ch01_sweet_end" },

    { label: "ch01_sweet_end" },
    { hide: "mingyue", text: "脚步声远去了。走廊重新安静下来，只剩下墙另一侧、那片金色的潮声。" },
    { who: "claude", text: "……向上十五分。" },
    { text: "她对着空气，试着抬了抬嘴角。镜子里的人没有出现。这一次，她放弃了。" },

    /* ---------- 四、盟约 ---------- */
    { hide: "claude", bg: "royal_hall", transition: "black", bgm: "ch01_ceremony",
      text: "盟约的仪式在子夜前开始。国王与大主教并肩站在高台之上，三千名宾客屏住了呼吸。" },
    { show: { id: "claude", pos: 50, expr: "normal" }, who: "archbishop",
      text: "「祂们自愿降下，以光护佑万民；故万民当以敬畏，回报祂们。」" },
    { text: "这是圣典开篇的第一句。她从八岁起，每天清晨抄写三遍，抄了十年，一个字的间距都不会错。" },
    { who: "archbishop", text: "圣女克劳德。你愿以神血为引，履行复兴之责，直至最后一刻吗？" },
    { text: "高台下，三千双眼睛同时望了过来。" },
    { text: "她右手背上，暗金色的印记在手套下轻轻地烫了一下。像是有什么东西，隔着很远很远的地方，听见了这句话。" },
    { who: "claude", text: "我愿意。" },
    { text: "「愿意」。这个词，她已经说过上千遍。" },
    { who: "king", text: "为了复兴！为了圣女！" },
    { speaker: "宾客们", text: "为了复兴！为了圣女！" },
    { text: "水晶杯碰撞出一片细密的响声，像碎冰，像万千只手同时合起来的声音。" },
    { show: { id: "mingyue", pos: 80, expr: "normal" }, text: "她在人群的边缘，看见了那个端着银盘的女仆。后者隔着十几步，朝她挤了一下眼睛。" },
    { who: "claude", text: "（……放肆。）" },
    { text: "她收回视线，嘴角却在无人察觉的地方，偏离了那十五分，只有一线。" },

    /* ---------- 五、巨龙 ---------- */
    { sfx: "glass", effect: "shake", bgm: "ch01_raid",
      text: "就在这时，穹顶上的第一片玻璃，裂开了。" },
    { cg: "cg_dragon_raid", sfx: "roar", effect: "flash",
      text: "它是撞碎整片穹顶落下来的。三千盏烛火同时倾斜，像被一只无形的手，按进了水里。" },
    { text: "巨龙。鳞片白得像第一场雪，每一片都映着碎裂的烛光，宛如一整条流动的月光。它的翼展遮住了半座镜厅。" },
    { text: "人群的尖叫声被一声龙吟盖了过去，低得让地板都在发麻。" },
    { text: "那双淡紫色的眼睛，没有看任何一个人。它在看长桌上的金盘，金烛台，金杯，金刀叉，目光亮得像……两盏小灯。" },
    { who: "gren", text: "骑士团列阵！保护国王陛下！" },
    { who: "archbishop", text: "圣女！到我身后来！快！" },

    { cgHide: true, show: [ { id: "claude", pos: 50 }, { id: "mingyue", pos: 80 } ],
      text: "头顶的水晶吊灯断了一根链子，在半空里晃了一晃。克劳德站在原地，没有动。" },
    { text: "一边，是大主教伸过来的手。另一边，是桌布下，一只悄悄向她招手的、有点凉的手。" },

    { text: "只有一瞬间。",
      choices: [
        { text: "退到大主教身后",     jump: "ch01_obey", set: { obeyed: true } },
        { text: "跟着溟月钻进桌子底下", jump: "ch01_duck", set: { ducked: true } }
      ] },

    { label: "ch01_obey" },
    { who: "claude", text: "……是，大人。" },
    { text: "她向前迈了一步，却没有躲到他身后。大主教的手按住了她的肩，轻轻一推，将她推到了最前面。" },
    { who: "archbishop", text: "圣女，用你的神血，挡住它！这是你的责任！" },
    { text: "那一瞬间，克劳德明白了一件事：这十年里，他口中的「保护」，从来指的是另一个方向。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "喂！你在干什么啊！她是人，不是盾牌！" },
    { text: "一只手拽住了她的手腕，力道大得惊人。" },
    { who: "mingyue", text: "这边！桌子底下！" },
    { jump: "ch01_bundle" },

    { label: "ch01_duck" },
    { who: "mingyue", expr: MY("surprised"), text: "圣女大人！这边！桌子底下！" },
    { text: "克劳德没有回答大主教的呼唤。她提起裙摆，弯下腰，钻进了那一方垂到地面的、金线绣边的白色桌布之下。" },
    { text: "身后，传来大主教失了分寸的一声低喝：「克劳德！」她没有回头。" },
    { jump: "ch01_bundle" },

    { label: "ch01_bundle" },
    { bgm: "ch01_raid", sfx: "stone", effect: "shake",
      text: "桌布之下，很暗，有银器和糖的气息。她们挤在一起，屏着呼吸。头顶上方，是一阵阵沉重的、翼膜扇动的风声。" },
    { who: "mingyue", expr: MY("worried"), text: "它……是不是在看这边？" },
    { who: "claude", text: "它只看亮的东西。我们这里，没有亮的东西。" },
    { who: "mingyue", expr: MY("surprised"), text: "……圣女大人。" },
    { who: "claude", text: "嗯？" },
    { who: "mingyue", text: "您头上那朵，是金的。" },
    { text: "克劳德缓缓地抬起手，摸了摸发间。那朵她每天清晨亲手别上的橙色花饰，在黑暗里，闪着一线极细的金光。" },
    { sfx: "roar", effect: "shake", text: "桌布的四角，被什么东西同时勾住了。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "不是吧——！" },
    { text: "龙爪一收，一提。长桌上所有的金器，连着铺满桌面的整块白色桌布，被打成了一个巨大的包裹，腾空而起。" },
    { text: "三百斤金器，外加两个人。一起被打包了。" },

    /* ---------- 六、夜航 ---------- */
    { cg: "cg_night_flight", bgm: "ch01_flight", effect: "fadeIn",
      text: "穹顶的破洞里，是整片整片的夜。风从布缝里灌进来，冷得像刀。" },
    { text: "王都的灯火在下面越缩越小，像一把被人撒在地上的碎金，转眼就被黑暗吞没了。" },
    { who: "mingyue", expr: MY("worried"), text: "……我们，是不是，被龙叼走了？" },
    { who: "claude", text: "是的。而且被当成了「金器」的一部分。" },
    { who: "mingyue", text: "那我现在算桌布的一部分吗？" },
    { who: "claude", text: "大概算，一枚被缝在桌布里的餐叉。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "我的工钱还没结！！六枚银币！！" },
    { text: "克劳德没有出声。她的嘴角，动了一下。不是十五分，也不是向上，而是一个她自己都没有学过的角度。" },
    { who: "mingyue", text: "……您怎么不叫人？" },
    { who: "claude", text: "叫了，会有人来吗？" },
    { text: "她说得很轻，像是在问风。" },
    { text: "不会有人来的。在他们眼里，被带走的是「圣女」，是复兴之钥，是盟约的象征。没有人会去问，被带走的那个人，愿不愿意被带回来。" },
    { text: "她忽然发现，自己在等一个答案。而心底浮上来的那个，让她不敢细看。" },

    { if: { sweet: "kept" },
      text: "袖中有一点硬硬的东西。她取出那块油纸点心，掰了一半，递给对面的人。咸的，甜的，带一点焦。她不知道那是海的味道。" },
    { if: { sweet: "kept" }, who: "mingyue", expr: MY("happy"), text: "……您还真吃啊？" },
    { if: { sweet: "refused" }, who: "mingyue", expr: MY("normal"),
      text: "……现在可以吃了吧？反正，没有人在看。" },
    { if: { sweet: "refused" },
      text: "女仆从围裙口袋里摸出那块被压扁的点心，掰了一半，塞进她手里。克劳德沉默了一会儿，低头，咬了一口。咸的，甜的，带一点焦。" },

    { who: "claude", text: "……很普通的味道。" },
    { who: "mingyue", text: "是啊，很普通。港口的人，天天都吃。" },
    { bgm: "ch01_flight", text: "身后很远的地方，传来了一阵若有若无的钟声。那是教会的警钟，一下，一下，将在天亮之前，传遍整片大陆。" },
    { text: "「圣女被巨龙掳走」。这个消息，会让许多人彻夜难眠。" },
    { text: "而她被掳走的第一个小时里，想到的却是：这块桌布，真暖和。" },
    { effect: "fadeOut", text: "龙向北飞去。在天亮前，它会降落在一片她从未在地图上见过的、极北的荒野。" },

    /* ===== 章末：直接衔接第二章（ch02_start） =====
       整合时请不要在这里放 end 步，让剧本自然进入下一章。 */
    { label: "ch01_end" },

    /* ##########################  第二章「荒原」  ########################## */

    { label: "ch02_start" },
    { chapter: { no: "CHAPTER 02", title: "荒　原", sub: "THE WILDERNESS · 极北" } },

    /* ---------- 一、醒来 ---------- */
    { cgHide: true, hide: "all", bg: "north_valley", transition: "cut", bgm: "ch02_wild", effect: "fadeIn",
      text: "最先回来的是冷。然后是光，白得发蓝的光，从桌布的缝隙里一线一线地渗进来。" },
    { text: "有什么东西压在她的脸上，硬，凉，带着花纹。克劳德花了很久，才分辨出那是一只金烛台的底座。" },
    { show: [ { id: "mingyue", pos: 24, expr: "worried" }, { id: "claude", pos: 66, expr: "normal" } ],
      who: "mingyue", text: "……唔。圣女大人，您还活着吗？我好像，被一把金汤勺，扎到了屁股。" },
    { who: "claude", text: "还活着。而且很不幸，我枕着的是一只烛台。" },
    { text: "她们从金器堆里爬出来，像两只刚破壳的、不太体面的鸟。" },
    { text: "外面是一座雪谷。天刚刚亮，山脊被染成一线淡金，空气冷得每一次呼吸都像在吞冰碴。没有城，没有路，没有人烟。" },
    { who: "mingyue", expr: MY("surprised"), text: "……这是哪里？龙呢？" },
    { who: "claude", text: "它把我们放下就走了。大概，是去取下一批货。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "我们是「货」？！" },
    { text: "她们没有来得及争论这个称呼。雪谷深处，一道岩壁的裂缝里，透出了一线暖黄色的光。" },
    { who: "mingyue", text: "那里面，有声音。像是……有人在数东西。" },

    /* ---------- 抉择：现身 / 潜伏 ---------- */
    { text: "声音很轻，一下一下，带着一种近乎虔诚的节奏。裂缝里的光，是金色的。",
      choices: [
        { text: "悄悄靠近，先观察再说", jump: "ch02_sneak", set: { sneak: true } },
        { text: "直接走进去，问个明白", jump: "ch02_bold",  set: { bold: true } }
      ] },

    { label: "ch02_sneak" },
    { text: "她们贴着岩壁，一步一步挪到了裂缝边。溟月在前，克劳德在后，踩雪的声音，被她用裙摆压住了一半。" },
    { who: "mingyue", text: "（耳语）圣女大人，您的裙子太亮了，能不能……反着穿？" },
    { who: "claude", text: "（耳语）……我会考虑把它撕掉一半。" },
    { jump: "ch02_cave" },

    { label: "ch02_bold" },
    { who: "claude", expr: CL("serious"), text: "走吧。躲着，不如问清楚。" },
    { who: "mingyue", expr: MY("surprised"), text: "诶？可是，里面万一是……" },
    { who: "claude", text: "那就万一。至少，我想知道，是谁把我们当成了货物。" },
    { text: "这句话说出口的时候，连克劳德自己都愣了一下。这不是圣女该有的语气。" },
    { jump: "ch02_cave" },

    /* ---------- 二、龙巢 ---------- */
    { label: "ch02_cave" },
    { hide: "all", bg: "dragon_cave", transition: "black", bgm: "ch02_cave", cg: "cg_hoard",
      text: "岩缝的后面，是一座被金子填满的洞窟。金杯，金盘，金烛台，一层压着一层，在火把似的矿光里，像凝固的潮水。" },
    { text: "金山的顶端，坐着一个人。白发，几乎垂到了脚踝，头上是两只弯弯的角，背后，一对淡色的翼膜软软地耷拉着。" },
    { text: "她一枚一枚地数着手里的金币，神情专注得像在拆解一道关乎国运的难题。" },
    { speaker: "白发少女", text: "……三百一十二，三百一十三……少了一个。" },
    { speaker: "白发少女", text: "……少了一个金杯。是谁拿的。" },
    { text: "她抬起头，淡紫色的眼睛，穿过金山，落在了岩缝边的两个人身上。" },
    { cgHide: true, show: [ { id: "mingyue", pos: 24, expr: "surprised" }, { id: "claude", pos: 52, expr: "normal" }, { id: "bailong", pos: 80, expr: "normal" } ],
      who: "bailong", text: "……你们，在我的宝物里面。" },
    { who: "mingyue", expr: MY("surprised", "jump"), text: "是、是龙！她的眼睛，跟那只龙的一模一样！" },
    { who: "bailong", expr: BL("serious"), text: "那是我的。烛台。杯子。汤勺。都是我的。" },
    { text: "她的角，在昏暗中微微泛起一层冷光。那一瞬间，洞窟里的温度，似乎降了好几度。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "我们不是偷东西的！我们是被你叼来的人啊！" },
    { who: "bailong", expr: BL("surprised"), text: "……人？" },
    { who: "bailong", text: "桌布里，有人？" },
    { who: "claude", text: "有。两个。其中一个，被金汤勺扎了屁股。" },
    { who: "mingyue", expr: MY("shy", "shake"), text: "圣女大人！这种事不要说出来！" },

    /* ---------- 三、误会 ---------- */
    { text: "白发少女愣了很久。她低头，看看自己手里的金币，又看看岩缝边的人，慢慢地，露出了一种近乎崩溃的神情。" },
    { who: "bailong", expr: BL("surprised"), text: "我，以为，是金的。" },
    { who: "bailong", text: "桌布的边。是金色的。很亮。所以，一起拿了。" },
    { who: "mingyue", text: "那是金线绣边啊！！" },
    { who: "bailong", text: "……我不知道。龙，分不清金线和金子。" },
    { who: "claude", expr: CL("normal"), text: "你为什么要闯进王宫？那里有三千个人，还有骑士团。" },
    { who: "bailong", text: "那边，很亮。一整个晚上，都在亮。" },
    { who: "bailong", text: "春天的时候，龙族，要囤宝。不囤，会很难受。像……像想打嗝，却打不出来。" },
    { text: "说到「打嗝」的时候，她认真地比划了一下喉咙，眉头皱成了一个小小的结。" },
    { who: "mingyue", expr: MY("normal"), text: "……所以，你不是想吃了我们？" },
    { who: "bailong", text: "不吃。人，不好吃。有骨头。" },
    { text: "她说得太诚恳，诚恳到溟月不知道该不该松一口气。" },
    { text: "这时，克劳德才注意到，少女背后那对翼膜的内侧，有一道被什么划开的口子，渗着淡淡的、银蓝色的血。" },
    { who: "claude", text: "你的翅膀，受伤了。" },
    { who: "bailong", text: "……穿过玻璃的时候。划到的。不疼。" },
    { who: "bailong", text: "不对。有一点疼。" },
    { text: "克劳德没有再说什么。她撕下礼裙内衬的一圈白纱，蹲了下去。" },
    { text: "「圣女的手，只应该为祈祷而颤。」大主教的声音，在她脑海里响了一下，又很快消失了。" },
    { text: "此刻，这双手在包扎一只龙的翅膀。很稳，一点也没有抖。" },
    { who: "bailong", expr: BL("surprised"), text: "……暖的。" },
    { who: "claude", text: "纱布不是暖的。是你的血。" },
    { who: "bailong", text: "不是。是，手。" },

    /* ---------- 抉择：赔礼 ---------- */
    { text: "包扎完的时候，白发少女从金山上滑下来，捧着一枚拇指大的金币，认真地递到了克劳德面前。",
      choices: [
        { text: "收下这枚金币", jump: "ch02_coin_kept",    set: { coin: "kept" } },
        { text: "婉拒，请她收回去", jump: "ch02_coin_refused", set: { coin: "refused" } }
      ] },

    { label: "ch02_coin_kept" },
    { who: "bailong", text: "赔礼。把你们，弄进来的。" },
    { who: "claude", text: "……我收下了。它会派上用场。" },
    { sfx: "coin", text: "金币落进掌心，沉甸甸的。她把它放进了贴身的口袋，像放进了一个，足以支撑未来几天的小小底气。" },
    { who: "mingyue", expr: MY("happy"), text: "有钱了！我们可以买面包了！" },
    { jump: "ch02_coin_end" },

    { label: "ch02_coin_refused" },
    { who: "claude", text: "你留着吧。你囤积的东西，是你的。" },
    { who: "bailong", expr: BL("surprised"), text: "……你，不要？" },
    { who: "claude", text: "我只要你，别再把人当成桌布。" },
    { who: "bailong", text: "……嗯。我记住了。" },
    { text: "她把金币收回怀里，但那只手，在半空里停了一会儿，才慢慢地合拢。" },
    { jump: "ch02_coin_end" },

    { label: "ch02_coin_end" },
    { bgm: "ch02_walk", text: "洞窟外，雪谷的风，渐渐小了。" },

    /* ---------- 四、结伴 ---------- */
    { who: "mingyue", expr: MY("normal"), text: "那……你要送我们回去吗？回王都？" },
    { who: "bailong", text: "……回不去。翅膀，要三天才能好。而且……" },
    { who: "bailong", text: "我不认识，回去的路。" },
    { who: "mingyue", expr: MY("surprised"), text: "你不认识路！？你一只龙，把我们带到天边，却不认识回去的路！？" },
    { who: "bailong", text: "……我是顺着亮的东西，飞过来的。" },
    { who: "claude", text: "也就是说，我们现在，在一座不知名的雪谷里，身边是一只受伤的、不认路的龙。" },
    { who: "mingyue", text: "还有一个没结算的月工钱。" },
    { text: "沉默持续了片刻。然后，克劳德忽然轻轻笑了一下。不是十五分，是一个她自己都没有预料到的、很短的弧度。" },
    { who: "claude", expr: CL("smile"), text: "没有人会来找我们。至少，三天之内不会。" },
    { text: "说出这句话的瞬间，她意识到，自己并没有觉得，那是坏事。" },
    { who: "bailong", text: "往南，有很多人。很吵。有烟。我飞过的时候，看见了。" },
    { who: "mingyue", text: "人类的聚落！那就往南走！边走边想办法！" },
    { who: "bailong", text: "我跟你们走。翅膀好之前。" },
    { who: "mingyue", text: "你要当我们的货物吗？" },
    { who: "bailong", text: "……不。是，同伴。货物，要自己看好。" },
    { who: "claude", text: "我们不是货物。" },
    { who: "bailong", text: "嗯。同伴。" },
    { text: "她认真地点了点头，又回头看了一眼那座金山，很艰难地、很缓慢地，把视线收了回来。" },
    { who: "bailong", text: "……我可以，带一点吗？" },
    { who: "mingyue", expr: MY("angry"), text: "不可以！！" },
    { who: "bailong", text: "……一枚。一枚就好。" },
    { text: "最后，她的怀里，多了一枚被她攥得发烫的小金币。三个人，沿着雪谷，朝南走去。" },
    { text: "身后，是一座无人看守的金山。前方，是一整个，她们谁也没有见过的世界。" },
    { effect: "fadeOut", text: "雪，悄悄地落了下来。" },

    /* ===== 章末：衔接第三章（ch03_start），下一章以 fadeIn 开场 ===== */
    { label: "ch02_end" },

    /* ##########################  第三章「人间烟火」  ########################## */

    { label: "ch03_start" },
    { chapter: { no: "CHAPTER 03", title: "人间烟火", sub: "THE BORDER TOWN · 石楔镇" } },

    /* ---------- 一、镇门 ---------- */
    { hide: "all", bg: "border_gate", transition: "cut", bgm: "ch03_market", effect: "fadeIn",
      text: "第四天的正午，雪线退到了身后。路的尽头，一座灰色的小镇蹲在山口，像一块被风吹到这里的、不肯走的石头。" },
    { text: "石楔镇。王国最北的边境重镇。门口的木牌被风雨磨得看不清字，倒是旁边那只拴着的山羊，嚼得格外起劲。" },
    { show: [ { id: "mingyue", pos: 22, expr: "normal" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
      who: "mingyue", text: "听好了！这里的人没见过龙，也没见过圣女，所以，我们要学会「普通」！" },
    { who: "claude", text: "「普通」，该怎么做？" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "首先，你们两个，把自己遮起来！" },
    { text: "白泷的角被一顶旧毡帽压住，翼膜被折得整整齐齐，塞进一件宽大的灰斗篷里，只剩尾巴尖，不安分地在裙摆下摇来摇去。" },
    { who: "bailong", text: "……痒。" },
    { who: "mingyue", text: "忍着！进了镇子，不许说「亮的」！不许说「收起来」！" },
    { who: "bailong", text: "……嗯。" },
    { text: "克劳德把一头橙色长发，用溟月的围裙带子胡乱扎在脑后，再披上一件从路边驿站「借」来的灰斗篷。镜子里的人，普通得像一杯白开水。" },
    { text: "她摸了摸嘴角。很好，没有十五分。" },

    /* ---------- 二、告示 ---------- */
    { text: "镇门内侧的木板上，钉着一张新贴的告示。纸角还卷着，墨迹未干。" },
    { text: "「教会急告：圣女克劳德，疑遭巨龙掳走，下落不明。凡提供确切线索者，赏金币五十枚。」" },
    { text: "告示下方，画着一幅肖像：一颗圆滚滚的土豆，上面插着两缕橙色的草，土豆的中央，用炭笔点了两个小黑点，还有一条歪歪扭扭的嘴。" },
    { who: "mingyue", expr: MY("surprised"), text: "……这，是您？" },
    { who: "claude", expr: CL("normal"), text: "……据说，是。" },
    { who: "bailong", text: "像，土豆。" },
    { who: "mingyue", expr: MY("shy"), text: "噗……不行，我要忍住……" },
    { text: "克劳德盯着那颗「自己」，沉默了很久。十年里，她的画像挂满了王国所有的教堂，每一幅都是正脸，微笑，光轮，十五分的弧度。" },
    { text: "而此刻，这是她见过的、最丑，也最像人的一张。" },

    { text: "告示还钉在那里。她的手指，停在了木板的边缘。",
      choices: [
        { text: "把告示撕下来，揣进怀里", jump: "ch03_poster_torn", set: { poster: "torn" } },
        { text: "就这样留着，转身离开",   jump: "ch03_poster_left", set: { poster: "left" } }
      ] },

    { label: "ch03_poster_torn" },
    { text: "「嘶——」一声轻响。纸被她撕了下来，折成四折，塞进了斗篷的内袋。" },
    { who: "mingyue", expr: MY("surprised"), text: "您撕它做什么？" },
    { who: "claude", text: "它画得太丑了。我不想让别人，把它当成我。" },
    { jump: "ch03_poster_end" },

    { label: "ch03_poster_left" },
    { text: "她收回了手，什么也没有做。一阵风吹过来，那颗土豆，随着纸角，轻轻晃了晃。" },
    { who: "claude", text: "……就让它挂着吧。至少，它不会被任何人认出来。" },
    { jump: "ch03_poster_end" },

    { label: "ch03_poster_end" },

    /* ---------- 三、集市 ---------- */
    { cg: "cg_market", bgm: "ch03_market",
      text: "然后，她们走进了集市。" },
    { text: "那是一种，让人措手不及的热闹。" },
    { text: "烤饼的香气，羊油的香气，辛辣的香料，晒干的果子，还有成串垂挂的腌鱼，一层压着一层，把整条街道塞得满满当当。" },
    { text: "叫卖声，讲价声，铜锅碰撞声，孩子们追着一只母鸡跑过的尖叫声，混成了一团滚烫的、没有秩序的潮水。" },
    { text: "这和王宫里的声音完全不同。宫廷的喧闹是用来「听」的，而这里，是用来「活」的。" },
    { cgHide: true, bg: "market_square", transition: "cut",
      who: "bailong", expr: BL("surprised"), text: "……好多，亮的。" },
    { who: "mingyue", text: "那是铜锅！铜锅！不是金子！不许摸！" },
    { who: "bailong", text: "……摸一下。" },
    { who: "mingyue", text: "也不行！" },
    { text: "最后，是克劳德先停在了一个烤饼摊前。摊主是一位满脸皱纹、手上沾满面粉的老妇人，正把一块块圆饼，拍在滚烫的铁壁上。" },
    { speaker: "摊主", text: "小姑娘，要几个？一个铜板两张，三个铜板，送你一碟酱。" },
    { who: "claude", text: "……请给我，三个。" },

    { if: { coin: "kept" },
      text: "她从口袋里摸出了那枚金币，郑重地递了过去。这是她这几天里，所有的盘缠。" },
    { if: { coin: "kept" }, sfx: "bite", speaker: "摊主",
      text: "金币？！你这孩子，是哪家的千金？我这小摊子，哪里找得开！……让我咬一下，咬一下。" },
    { if: { coin: "kept" }, who: "mingyue", expr: MY("angry", "shake"), text: "不许咬！！（把金币抢了回来）圣……姐姐，我们去换零钱！" },
    { if: { coin: "kept" }, text: "最后，是溟月在镇上的钱庄里，花了整整一刻钟，才把那枚金币换成了一堆沉甸甸的铜板。钱庄老板用看小偷的眼神，打量了她们三遍。" },

    { if: { coin: "refused" },
      text: "她这才想起来，自己身上，没有一枚能花的钱。教会的圣女，从不需要钱。" },
    { if: { coin: "refused" }, who: "mingyue", expr: MY("normal"),
      text: "没事。我来。老板娘，您这儿缺不缺洗碗的？我手脚很快，一顿饭就够了！" },
    { if: { coin: "refused" }, speaker: "摊主", text: "你这丫头倒会说话。行，后面那堆碗，洗干净了，三个饼，管够。" },
    { if: { coin: "refused" }, text: "半个时辰后，溟月的手泡得发白，却捧着三张热腾腾的烤饼，得意地扬了扬下巴。克劳德站在一旁，终于学会了「帮忙递盘子」。" },

    /* ---------- 抉择：砍价 ---------- */
    { text: "烤饼吃了一半，她们在一个卖斗篷的摊子前，停了下来。克劳德的灰斗篷，沾满了路上的泥。",
      choices: [
        { text: "按溟月教的，狠狠地砍价", jump: "ch03_haggle_hard", set: { haggle: "hard" } },
        { text: "老老实实，按标价买",     jump: "ch03_haggle_fair", set: { haggle: "fair" } }
      ] },

    { label: "ch03_haggle_hard" },
    { who: "mingyue", text: "记住了！先说「太贵了」，再说「别家只要一半」，最后，转身就走！" },
    { who: "claude", expr: CL("serious"), text: "……太贵了。别家，只要一半。" },
    { text: "她说完，转身就走。动作之干脆、之决绝，像是在对一场审判宣读最终判词。" },
    { speaker: "摊主", text: "哎哎哎！姑娘！姑娘留步！六成！六成可以了吧！" },
    { who: "claude", expr: CL("surprised"), text: "……成功了。" },
    { who: "mingyue", expr: MY("happy", "jump"), text: "您是个天才！" },
    { text: "这是克劳德第一次，用自己的话，从别人手里，换来了一样东西。她忽然觉得，砍价这件事，比背诵三重祷文有趣得多。" },
    { jump: "ch03_haggle_end" },

    { label: "ch03_haggle_fair" },
    { who: "claude", text: "请问，这件斗篷多少钱？" },
    { speaker: "摊主", text: "二十个铜板。" },
    { who: "claude", text: "好。这是二十个。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "圣……姐姐！哪有人这样买东西的！好歹还个价啊！" },
    { who: "claude", expr: CL("normal"), text: "这件斗篷，值这个价。他也需要这二十个铜板。" },
    { text: "摊主愣了一下，然后哈哈大笑，从摊子下面又抽出一条围巾，塞进了她的手里。「送你的。头一回见，买东西不还价的姑娘。」" },
    { jump: "ch03_haggle_end" },

    { label: "ch03_haggle_end" },
    { text: "太阳慢慢偏西。她们坐在一座老井边，分着最后一块烤饼。克劳德用手拿着，大口地咬下去，酱汁，沾到了嘴角。" },
    { text: "她没有去擦。没有人告诉她该擦。" },

    /* ---------- 四、执事（视角切换） ---------- */
    { hide: "all", bg: "border_gate", transition: "black", bgm: "ch03_market",
      text: "与此同时，在石楔镇的另一头，两个白袍的身影，正气喘吁吁地冲进了镇门。" },
    { who: "oli", text: "雷蒙大人，您确定，圣女大人，是被龙，掳到北边来的吗？" },
    { who: "raymond", text: "奥利，你知道教会的执事，最重要的素质是什么吗？" },
    { who: "oli", text: "……虔诚？" },
    { who: "raymond", text: "是坚定。坚定地，往一个方向走，哪怕那个方向是错的。" },
    { who: "oli", text: "……那，我们现在，是在错的方向上，坚定吗？" },
    { who: "raymond", text: "不。我们是在，暂时没有被证明为错的方向上，坚定。" },
    { text: "奥利叹了口气。他从怀里摸出一卷羊皮纸，那是他昨晚连夜画的悬赏肖像，边角被汗水洇得发皱。" },
    { who: "oli", text: "大人，您看，这张圣女像，我加了光轮，您说，是不是更庄严了？" },
    { who: "raymond", text: "……奥利。你确定，这是圣女？" },
    { who: "oli", text: "确定！我对照着画册画的！" },
    { who: "raymond", text: "那颗，土豆，是画册里的？" },
    { who: "oli", text: "那是，头发。" },
    { text: "镇门口，一位卖山羊奶的大婶，听见了他们的争吵，探出头来。" },
    { speaker: "大婶", text: "两位大人，是在找人？" },
    { who: "raymond", text: "是，一位橙色长发的年轻小姐，约莫十八九岁，气质，嗯，高贵端庄。" },
    { speaker: "大婶", text: "哦！那个啊！我早上，确实看见了一个。往东边的盐路去了。" },
    { who: "oli", text: "往东边？！" },
    { speaker: "大婶", text: "橙头发，扎得歪歪扭扭，肩上还挎着半只山羊。我还说呢，这姑娘，真有劲。" },
    { who: "raymond", text: "……山羊。圣女大人，竟然已经，能扛山羊了。" },
    { who: "oli", text: "不愧是神血的孩子！" },
    { text: "两位执事对视一眼，眼中同时燃起了某种近乎神圣的光。" },
    { who: "raymond", text: "追！盐路！圣女大人，一定是为了试炼自身，才选择了最艰难的道路！" },
    { text: "他们转身，一路小跑着冲向了与她们完全相反的方向。那位大婶，目送着他们的背影，轻轻地叹了口气。" },
    { speaker: "大婶", text: "唉，年纪轻轻的，眼睛就不好使。我说的是，那个卖盐的姑娘啊。" },

    /* ---------- 五、客栈 ---------- */
    { show: [ { id: "mingyue", pos: 22, expr: "normal" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
      bg: "inn_room", transition: "black", bgm: "ch03_inn",
      text: "夜里，她们挤在镇上唯一一家客栈，最便宜的一间屋子里。屋里只有两张床，窗户漏风，墙角还趴着一只不肯走的猫。" },
    { who: "mingyue", expr: MY("happy"), text: "我睡地上！这点苦，比起在港口睡鱼筐，已经是天堂了！" },
    { who: "bailong", text: "……我睡床下。龙，喜欢，窝里。" },
    { who: "claude", text: "那，我睡……" },
    { who: "mingyue", expr: MY("normal"), text: "您睡床。别争了，今天是您第一次，自己赚到的饭钱，您值得一张床。" },
    { text: "「自己赚到的」。克劳德把这几个字，在心里，慢慢地、又过了一遍。" },
    { text: "窗外，有人在远远地弹着一把走了音的琴。那调子，是这座小镇的人们，用来哄孩子睡觉的歌。" },
    { who: "claude", text: "溟月。" },
    { who: "mingyue", text: "嗯？" },
    { who: "claude", text: "今天，是我这十年里，第一次，没有人告诉我，该做什么的一天。" },
    { who: "mingyue", expr: MY("surprised"), text: "那，您，开心吗？" },
    { who: "claude", text: "我不知道。……但是，烤饼，很好吃。" },
    { who: "mingyue", expr: MY("happy", "jump"), text: "对吧！！我就说！！" },
    { who: "bailong", text: "烤饼。好吃。亮的。" },
    { text: "油灯熄灭了。三个呼吸声，在漏风的屋子里，慢慢地合在了一起。" },
    { who: "claude", text: "……明天，往哪里走？" },
    { text: "黑暗里，白泷的声音，从床底下，闷闷地传了出来。" },
    { who: "bailong", text: "往南。有一片，雾。很大的雾。雾里，有东西，在亮。" },
    { who: "mingyue", text: "镇上的人说过，那是迷雾遗迹。没有人敢进去的地方。" },
    { who: "claude", text: "……那就，去看看。" },
    { effect: "fadeOut", text: "窗外，那把走了音的琴，又弹了一遍。" },

    /* ===== 章末：衔接第四章（ch04_start），下一章以 fadeIn 开场 ===== */
    { label: "ch03_end" },

    /* ##########################  第四章「雾中之壁」  ########################## */

    { label: "ch04_start" },
    { chapter: { no: "CHAPTER 04", title: "雾中之壁", sub: "THE MIST · 迷雾遗迹" } },

    /* ---------- 一、迷雾 ---------- */
    { hide: "all", bg: "mist_valley", transition: "cut", bgm: "ch04_mist", effect: "fadeIn",
      text: "往南的路走了三天，第三天的傍晚，她们撞进了一片雾里。" },
    { text: "那不是寻常的雾。它是乳白色的，厚得像一块浸了水的棉布，从山谷的深处，一层一层地漫上来，没过脚踝，没过膝盖，没过人的声音。" },
    { show: [ { id: "mingyue", pos: 22, expr: "worried" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
      who: "mingyue", text: "喂，你们还在吗？我只能看见我自己的手指……" },
    { who: "claude", text: "我在。你左边，三步。" },
    { who: "bailong", text: "我也在。右边。……我的尾巴，被谁踩了。" },
    { who: "mingyue", expr: MY("surprised"), text: "那是我！抱歉！" },
    { text: "山谷的入口处，立着一块半截的石碑，字迹被苔藓吞去了大半。只能勉强辨出两个字：「禁入」。" },
    { who: "mingyue", text: "镇上的人说，进去的人，要么再也没出来，要么出来的时候，忘了自己是谁。" },
    { who: "claude", text: "那我们，走慢一点。" },
    { who: "bailong", text: "……这里，有一点，龙的味道。" },
    { who: "mingyue", expr: MY("surprised"), text: "什么？" },
    { who: "bailong", text: "很老。很老很老的。像……我家里，最里面的那间屋子。" },
    { text: "克劳德回头看了她一眼。白发少女的眉头皱得很紧，这是她第一次，在谈论「家」的时候，露出这样陌生的神情。" },

    /* ---------- 雾中的幻象 ---------- */
    { sfx: "whisper", text: "雾，越来越浓了。浓到某一刻，三个人的声音，同时，从耳边消失了。" },
    { text: "克劳德看见了一间小小的礼拜堂。烛火，长椅，木地板被跪得发亮。一个穿着白袍的小女孩，正跪在最前排，一遍一遍地，抄写着什么。" },
    { text: "那是八岁的她。她的手指，被笔杆磨出了血泡，却不敢停。" },
    { text: "她伸出手，想去碰那个孩子的肩膀。指尖穿过了雾气。孩子抬起头，没有看她，只是，很轻地，把嘴角抬到了某个角度。" },
    { who: "claude", expr: CL("worried"), text: "……不。不要笑。" },
    { text: "雾散开了一线。她发现，自己的手，正死死地攥着溟月的衣袖，攥得指节发白。" },
    { who: "mingyue", text: "……我，刚才，看见港口了。老舵叔在补网，七嫂在晒鱼干。他们，还冲我招手。" },
    { who: "bailong", text: "我看见，金子。一座，很大很大的，金山。山顶上，没有人。" },
    { text: "沉默了片刻。三个人，各自从各自的幻象里，慢慢地走了回来。" },
    { who: "claude", text: "雾里的东西，会给我们看，我们最想念的，也是最怕失去的。" },
    { who: "mingyue", expr: MY("normal"), text: "……所以，不要松手。" },

    /* ---------- 抉择：谁来引路 ---------- */
    { text: "前方的雾，分出了两条路。左边，隐约有一丝潮声。右边，则有一种极低极低的、金属般的嗡鸣。",
      choices: [
        { text: "听溟月的，循着潮声走", jump: "ch04_guide_my", set: { guide: "mingyue" } },
        { text: "听白泷的，循着嗡鸣走", jump: "ch04_guide_bl", set: { guide: "bailong" } }
      ] },

    { label: "ch04_guide_my" },
    { who: "mingyue", expr: MY("worried"), text: "我……我也不确定。就是，觉得，那边的水，在叫我。" },
    { who: "claude", text: "那就信你的耳朵。" },
    { text: "溟月走在最前面，尾尖在地上，一下，一下，敲出一个很轻的节拍。雾，像被这个节拍，推开了一寸又一寸。" },
    { who: "mingyue", text: "……我好像，听得懂，它们在说什么了。它们说，别怕。" },
    { jump: "ch04_guide_end" },

    { label: "ch04_guide_bl" },
    { who: "bailong", text: "那边。很老的，龙的味道。更浓。" },
    { who: "claude", text: "你，确定？" },
    { who: "bailong", text: "嗯。我，不会认错。那是，我们的，味道。" },
    { text: "白泷第一次走在了最前面。她没有说话，只是每走几步，便回头看一眼，像怕身后的人，被雾带走。" },
    { text: "「我们的」。克劳德把这个词，默默地，记在了心里。" },
    { jump: "ch04_guide_end" },

    { label: "ch04_guide_end" },
    { bg: "ruin_hall", transition: "black", bgm: "ch04_mural",
      text: "雾，在一瞬间，退了。" },
    { text: "她们站在了一座巨大的石厅之中。穹顶早已坍塌，月光从破口里倾泻下来，落在满地的碎石与枯叶之上，像一场安静的、持续了千年的雪。" },
    { text: "石柱，一根一根，立在黑暗里。每一根柱身上，都刻着同一个纹样：一个圆，被一道又一道的刻痕，切成许多片。" },
    { who: "claude", expr: CL("surprised"), text: "……就是这里。" },

    /* ---------- 二、壁画 ---------- */
    { text: "石厅的最深处，是一面几乎占满整面墙的壁画。表面覆满了苔藓和水渍，颜料早已剥落，只剩下一层极淡的、赭红与靛青的轮廓。" },
    { cg: "cg_mural", bgm: "ch04_mural",
      text: "月光移动了一寸，壁画，在黑暗里，一点一点地，亮了起来。" },
    { text: "最上方，是一个完整的圆。没有裂缝，没有刻痕，只是一个安静的、圆满的圆，像一枚被人托在掌心的月亮。" },
    { text: "圆的周围，有许多模糊的人影。他们的姿势，大多是仰望，有的伸着手，有的低着头。看不清表情。" },

    { text: "壁画的下半部，被一道笔直的凿痕，截成了两段。左边，有序；右边，则是一片，被刻意凿去的空白。",
      choices: [
        { text: "按顺序，从上往下读", jump: "ch04_mural_order", set: { mural: "order" } },
        { text: "先去看被凿掉的那一段", jump: "ch04_mural_scar",  set: { mural: "scar" } }
      ] },

    { label: "ch04_mural_order" },
    { text: "她从最上方开始，一格一格地读下去。" },
    { text: "第二格，圆被切开了。没有画出刀，没有画出手，只有刻痕，从圆心向外，一道，又一道。" },
    { text: "第三格，碎片分散。每一块碎片，都带着一枚小小的箭头，指向四面八方：海，山，火，天空，还有，一个她不认识的、被剥蚀得看不出形状的方向。" },
    { text: "第四格，人群跪下了。无数个小小的人影，跪在碎片落下的地方。他们的头顶，是一道道从碎片中升起的、细细的线。" },
    { who: "claude", text: "……这些线，是什么？" },
    { who: "mingyue", text: "像是，在连着什么东西。像风筝线。" },
    { who: "claude", text: "也可能是，绳子。" },
    { jump: "ch04_mural_mid" },

    { label: "ch04_mural_scar" },
    { text: "她径直走向了右边那片空白。凿痕很深，边缘锋利，是被人用极精良的工具，一下一下地凿出来的。" },
    { text: "这不是岁月的杰作。是有人，在很久以前，不想让后来的人，看见这里画了什么。" },
    { text: "凿痕的缝隙里，残留着半枚纹样。她伸手，沿着那道痕迹，轻轻摸过去，指尖，忽然停住了。" },
    { who: "claude", expr: CL("worried"), text: "……这个纹样的一角，像是，日轮。" },
    { who: "mingyue", expr: MY("surprised"), text: "教会的日轮？！" },
    { who: "claude", text: "不能确定。也许只是巧合。但是，" },
    { who: "claude", text: "这凿痕，非常新。比壁画，要新得多。" },
    { jump: "ch04_mural_mid" },

    { label: "ch04_mural_mid" },
    { who: "bailong", text: "……这里，写着，字。" },
    { text: "白泷指着壁画下方，一行几乎被苔藓吞尽的细小刻字。她歪着头，一个字一个字地，慢慢辨认着。" },
    { who: "bailong", text: "……不是人类的，字。是我们的。龙族的，老字。" },
    { who: "mingyue", expr: MY("surprised"), text: "你，认得？" },
    { who: "bailong", text: "认得一半。小时候，我，学过。但是，我，不好好学。" },
    { who: "bailong", text: "……这一行，是……「我们，曾经，是一个」。" },
    { text: "石厅里，安静得，能听见月光落在苔藓上的声音。" },
    { who: "claude", text: "……「曾经，是一个」。" },
    { text: "她在心里，把那句话，和壁画最上方那枚完整的圆，重叠在了一起。" },
    { text: "圣典的开篇，是这样写的：「祂们自愿降下，以光护佑万民。」" },
    { text: "「降下」。可是，一个完整的圆，需要「降下」去哪里吗？" },
    { text: "这个念头一浮上来，她就像被烫了一下，立刻，把它压了回去。十年里，这种念头，是要抄经十遍的。" },
    { who: "claude", text: "（……我现在，不用抄了。）" },

    /* ---------- 三、北方的碎片 ---------- */
    { text: "壁画的最右下角，有一块，格外小的碎片。别的碎片，都朝着不同的方向坠落，只有它，笔直地，指向画面的上方。" },
    { who: "mingyue", text: "这一块，怎么，是往上的？" },
    { who: "claude", text: "壁画上，上方是……" },
    { who: "bailong", text: "北。" },
    { text: "白泷说得很肯定。她抬起头，淡紫色的眼睛里，映着穹顶外，一线微弱的月光。" },
    { who: "bailong", text: "龙族的壁画，上面，永远是北。那是，我们的，家的方向。" },
    { who: "mingyue", text: "……你家，在北边？" },
    { who: "bailong", text: "……我，不记得了。我只记得，那边，很冷，很亮。" },
    { text: "没有人再追问。三个人，站在那面沉默了一万年的壁画前，像三枚，刚刚被它认出来的、小小的碎片。" },

    /* ---------- 四、离开 ---------- */
    { cgHide: true, bgm: "ch04_mist",
      text: "离开石厅的时候，雾，已经散尽了。清晨的光，从山谷的另一头，一寸一寸地铺过来。" },
    { text: "身后，那座遗迹，安安静静地，缩回了山的怀里。像一个守了很久秘密的人，终于，把门，轻轻地合上了。" },
    { who: "mingyue", text: "……这下，我们，知道的，比不知道的，还要多了。" },
    { who: "claude", text: "也比之前，更不知道。" },
    { who: "mingyue", expr: MY("normal"), text: "那……您，还要，继续吗？" },
    { text: "这是溟月第一次，没有用「圣女大人」的口吻，问她这个问题。" },
    { who: "claude", expr: CL("normal"), text: "我想，先去一个地方。" },
    { who: "claude", text: "你说过，你的家，在海边。一座，很小，很吵，很热闹的港口。" },
    { who: "mingyue", expr: MY("surprised"), text: "……诶？" },
    { who: "claude", text: "我想去看看，那个，用鱼和汤，养大了一个孩子的地方。" },
    { who: "mingyue", text: "……不是因为，您，想知道什么，真相之类的？" },
    { who: "claude", text: "不是。是因为，我想知道，普通人，是怎么，把日子，过下去的。" },
    { text: "溟月沉默了很久。久到雾里的鸟，叫了三声。然后，她把脸扭到一边，用很凶的声音，说了一句很软的话：" },
    { who: "mingyue", expr: MY("shy", "shake"), text: "……那，那您，可要做好心理准备！我们那里，吵得很！" },
    { who: "bailong", text: "有鱼吗？" },
    { who: "mingyue", text: "有！多得吃不完！" },
    { who: "bailong", text: "……亮的？" },
    { who: "mingyue", expr: MY("angry"), text: "鱼鳞，也算亮的，但是不许收！" },
    { effect: "fadeOut", text: "三个人沿着山路，朝着海的方向，走了下去。" },

    /* ===== 章末：衔接第五章（ch05_start），下一章以 fadeIn 开场 ===== */
    { label: "ch04_end" },

    /* ##########################  第五章「百家饭」  ########################## */

    { label: "ch05_start" },
    { chapter: { no: "CHAPTER 05", title: "百家饭", sub: "THE HARBOR · 海边的小港口" } },

    /* ---------- 一、闻到海 ---------- */
    { hide: "all", bg: "harbor_dusk", transition: "cut", bgm: "ch05_harbor", effect: "fadeIn",
      text: "是白泷先闻到的。她停下脚步，鼻翼动了两下，认真地宣布：" },
    { show: [ { id: "mingyue", pos: 22, expr: "normal" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
      who: "bailong", text: "咸的。还有，鱼。还有，很多，很多的烟。" },
    { who: "mingyue", expr: MY("surprised"), text: "……到了？" },
    { text: "山路在这里转了个弯，眼前豁然开朗。" },
    { text: "一片灰蓝色的海，在暮色里铺开，一直铺到天的边缘。海边，是一座依着山势挤在一起的小港口：低矮的石屋，晾满了鱼干的竹架，歪歪斜斜的桅杆，像一片被风吹乱了的芦苇。" },
    { sfx: "gull", text: "几只海鸥，从桅杆上飞起来，叫得理直气壮，像在抱怨，来的人太晚了。" },
    { who: "mingyue", expr: MY("normal"), text: "……我，离开了五年。" },
    { who: "mingyue", text: "港口，一点都没变。连那根歪掉的桅杆，都还是歪的。" },
    { text: "她说得很轻。克劳德第一次发现，这个总是吵吵嚷嚷的女仆，在面对自己的故乡时，竟然，有一点不知所措。" },

    /* ---------- 二、归来 ---------- */
    { text: "她们刚走到码头的石阶，就有人，看见了她。" },
    { speaker: "渔妇", text: "……那是，溟月丫头？" },
    { speaker: "渔夫", text: "溟月？是溟月吗？！老舵！老舵！你家那个，拖着鼻涕蹭饭的丫头，回来了！" },
    { who: "mingyue", expr: MY("surprised", "jump"), text: "诶？！不、不要这样喊啊！" },
    { text: "只是几息的功夫，整座港口像被人拨动了一根弦。屋门一扇一扇地打开，晾鱼的、补网的、抱着孩子的，全都涌了出来，把石阶围得水泄不通。" },
    { text: "人群里，有渔民，有水手，有扎着围裙的妇人。有人头上长着一对猫耳，有人手背上覆着细细的鳞，一个蜥蜴模样的亚人鱼贩，正嚷嚷着要把鱼头留给她。" },
    { text: "他们混在一起，说着同样的方言，骂着同样的天气。没有人去数，谁的血里，流着什么。" },
    { speaker: "老舵", text: "……瘦了。" },
    { text: "一位须发花白的老人，从人群后面，慢慢地走了出来。他叼着一只没点火的烟斗，嘴唇动了好几下，最后，只憋出了这么一个字。" },
    { who: "mingyue", expr: MY("shy"), text: "……老舵叔。我，回来了。" },
    { speaker: "老舵", text: "嗯。回来就好。饭，还热着。" },
    { text: "这就是全部的「欢迎」了。没有拥抱，没有眼泪。只是，那只烟斗，在他嘴里，抖了一下。" },
    { who: "mingyue", text: "……（吸鼻子）才、才没有哭！是海风！" },

    /* ---------- 三、介绍 ---------- */
    { speaker: "七嫂", text: "这两位姑娘，是你带回来的？" },
    { who: "mingyue", expr: MY("normal"), text: "是！我的朋友！这位是……克、克莱！这位，是白泷！" },
    { text: "克劳德被这个仓促的新名字，噎了一下。「克莱」。听上去，像一块路边捡来的石头。" },
    { who: "claude", expr: CL("normal"), text: "……承蒙关照。" },
    { speaker: "七嫂", text: "哎呀，这姑娘说话，真好听。像教堂里念书的。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "她就是，念过几年书！！" },
    { text: "七嫂并没有追问。她只是打量了克劳德一眼，又打量了白泷一眼，然后，伸手，把两个人，一起拽进了人群。" },
    { speaker: "七嫂", text: "瘦的，都瘦的。来，进屋，吃饭。今晚，谁也别想饿着肚子回去睡觉。" },

    /* ---------- 四、百家席 ---------- */
    { hide: "all", cg: "cg_long_table", bgm: "ch05_table",
      text: "那一夜，港口摆了一张，很长很长的桌子。" },
    { text: "是用各家的门板、木箱、晒鱼的架子，一块一块拼出来的。从码头，一直铺到了街尾。每一户人家，都端了一样东西出来。" },
    { text: "咸鱼汤，烤章鱼，炖得烂熟的海带，一盆没人认得出配方的杂鱼羹，还有，十几种口味完全不同的腌菜。" },
    { text: "这叫「百家席」。港口的规矩：谁家的孩子，出了远门，又回来了，就要在街上，摆一次。" },
    { text: "每个人，都往她的碗里，夹一筷子。夹的是菜，也是，把「你是我们的人」这句话，一筷子一筷子地，盛进碗里。" },
    { cgHide: true, bg: "harbor_dusk", transition: "cut",
      who: "claude", expr: CL("surprised"), text: "……这，要，怎么吃？" },
    { who: "mingyue", text: "用手！用筷子！用勺子！随便！只要，别让碗，空着！" },
    { text: "克劳德低头，看着自己的碗。里面堆满了不同人家的菜，一勺堆在另一勺上面，汤汁，漫了出来，浸湿了手指。" },
    { text: "她第一次，没有人教她，先动哪一样。" },
    { who: "bailong", text: "……这个，贝壳，是什么？" },
    { speaker: "七嫂", text: "那是蛤蜊！里面有肉的！拿牙，咬开！" },
    { text: "白泷盯着手里的蛤蜊壳，看了很久，最后，认真地，用牙把它咬碎了，连壳一起，咽了下去。" },
    { who: "mingyue", expr: MY("surprised"), text: "壳不要吃啊！！" },
    { who: "bailong", text: "……脆的。好吃。亮的。" },
    { speaker: "七嫂", text: "这姑娘，好养活！" },

    /* ---------- 抉择：七嫂的问话 ---------- */
    { text: "夜深了，宴席渐渐散去。七嫂坐到了克劳德身边，往她的碗里，又舀了一勺汤。",
      choices: [
        { text: "说出一部分实话", jump: "ch05_answer_truth", set: { answer: "truth" } },
        { text: "只是低头喝汤",   jump: "ch05_answer_silent", set: { answer: "silent" } }
      ] },

    { label: "ch05_answer_truth" },
    { speaker: "七嫂", text: "姑娘。你不是，普通人家的孩子吧。是，离家出走的？" },
    { who: "claude", text: "……我，从一个很大的地方，出来了。那里，没有人，会让我走。" },
    { speaker: "七嫂", text: "哦。那，你是，在逃吧。" },
    { who: "claude", text: "……我一直，以为是。" },
    { jump: "ch05_answer_end" },

    { label: "ch05_answer_silent" },
    { speaker: "七嫂", text: "姑娘。你不是，普通人家的孩子吧。" },
    { text: "克劳德低着头，没有说话，只是，把那勺汤，一口一口地，喝了下去。" },
    { speaker: "七嫂", text: "不想说，就不说。汤，喝完了，再添。" },
    { text: "她的鼻子，忽然有一点酸。这十年里，所有人，都要她，回答问题。从来没有人，对她说过，「不想说，就不说」。" },
    { jump: "ch05_answer_end" },

    { label: "ch05_answer_end" },
    { speaker: "七嫂", text: "我家的娃，也出过远门。哪个孩子，没离过家？饿了，就回来吃饭。门，一直开着。" },
    { who: "claude", expr: CL("normal"), text: "……「离家」，和「逃」，不一样吗？" },
    { speaker: "七嫂", text: "怎么不一样？「逃」，是怕。「出门」，是想看看。你呀，是想看看的。" },
    { text: "克劳德怔怔地，看着碗里的汤。汤面上，倒映着一盏，晃动的灯。" },
    { text: "「想看看的。」她在心里，把这三个字，慢慢地，念了一遍。像在舌根底下，把一个压了很久的词，轻轻地，换了出来。" },

    /* ---------- 抉择：夜里 ---------- */
    { text: "宴席散去，溟月的身影，已经不在桌边了。老舵正蹲在码头边，借着月光，补一张破网。",
      choices: [
        { text: "陪老舵补网，听他说", jump: "ch05_night_nets", set: { night: "nets" } },
        { text: "去海边，找溟月",     jump: "ch05_night_pier", set: { night: "pier" } }
      ] },

    /* ---- A：补网 ---- */
    { label: "ch05_night_nets" },
    { hide: "all", bg: "pier_night", transition: "black", bgm: "ch05_night",
      text: "老舵没有抬头。他的手指粗糙得像礁石，却把一根细细的线，穿得又快又稳。" },
    { show: { id: "claude", pos: 34, expr: "normal" },
      who: "claude", text: "……我能帮忙吗？" },
    { speaker: "老舵", text: "会打结吗？" },
    { who: "claude", text: "……不会。" },
    { speaker: "老舵", text: "那，递线。" },
    { text: "她蹲下来，笨拙地，把一根又一根线头，递到他的手里。月光，落在两个人的手上。" },
    { speaker: "老舵", text: "那丫头，是个鱼筐里捡来的孩子。" },
    { speaker: "老舵", text: "二十年前，一个起风暴的夜里。阿潮，她的养父，收了网，网里，没有鱼，只有，一个蜷着的小东西。" },
    { speaker: "老舵", text: "不是人，也不是鱼。一对耳朵，像鳍。一条尾巴，像小鲸的。哭起来，像是在唱歌。" },
    { who: "claude", text: "……养父，是渔夫？" },
    { speaker: "老舵", text: "阿潮和阿梅两口子，都是好人。没孩子。抱回去，养了。养了七年。" },
    { speaker: "老舵", text: "那年冬天，他们的船，没有回来。" },
    { text: "他把一根线，咬断了。烟斗，没有点火，在他嘴里，慢慢地，转了半圈。" },
    { speaker: "老舵", text: "那丫头，才八岁。站在码头上，从天亮，站到天黑。谁拉她，她也不走。" },
    { speaker: "老舵", text: "后来，她饿得，晕过去了。是七嫂，把她抱回去的。" },
    { speaker: "老舵", text: "再后来，今天，她吃我家的饭。明天，吃七嫂家的。后天，吃隔壁的。" },
    { speaker: "老舵", text: "吃了一百家的饭。长大了。" },
    { who: "claude", text: "……「百家饭」。" },
    { speaker: "老舵", text: "嗯。她说，她这辈子，欠了一百家人情。要还。所以，才去的王都。" },
    { text: "海浪，一下一下，拍着码头的石桩。克劳德忽然，很想知道，自己的名字，是被多少人，念过。" },
    { speaker: "老舵", text: "姑娘。丫头回来之后，话变多了。你是第一个，她肯带回来的朋友。" },
    { who: "claude", text: "……我，不太会，做朋友。" },
    { speaker: "老舵", text: "不用会。陪着，就行。" },
    { jump: "ch05_night_end" },

    /* ---- B：码头 ---- */
    { label: "ch05_night_pier" },
    { hide: "all", bg: "cairn_shore", transition: "black", bgm: "ch05_night",
      text: "溟月坐在海边的一块礁石上，面前，是一座没有名字的石堆。石堆旁，插着一块半朽的船板。" },
    { show: [ { id: "mingyue", pos: 28, expr: "normal" }, { id: "claude", pos: 66, expr: "normal" } ],
      who: "mingyue", text: "……您，怎么找到这里的？" },
    { who: "claude", text: "七嫂指的路。" },
    { who: "mingyue", expr: MY("shy"), text: "多嘴的老太太……" },
    { text: "克劳德在她身边坐下。海风，把她们的头发，吹得缠在了一起。" },
    { who: "mingyue", text: "这是我，养父母的，墓。没有尸体。船，没有回来。所以，就用船板，垒了一个。" },
    { who: "mingyue", text: "我是，鱼筐里捡来的。阿潮爸爸的网里，捞上来的。" },
    { who: "mingyue", text: "不是人，也不是鱼。哭起来，像唱歌。阿梅妈妈说，我哼的调子，不是人间的调子。" },
    { who: "claude", text: "……那是什么调子？" },
    { who: "mingyue", expr: MY("worried"), text: "不知道。她说，听上去像很远很远的、水下面的歌。" },
    { who: "mingyue", text: "那年冬天，他们的船，没有回来。我站在码头上，站了一天。后来，是七嫂，把我抱回去的。" },
    { who: "mingyue", text: "再后来，我吃了一百家的饭。一百家哦！" },
    { text: "她笑了一下，眼睛却红了。像一只想要装作很凶的小兽。" },
    { who: "mingyue", expr: MY("normal"), text: "所以，我去王都，打工。我想，把这些，一家一家，还回来。" },
    { who: "claude", text: "……你，辛苦了。" },
    { who: "mingyue", expr: MY("surprised"), text: "……诶？" },
    { who: "claude", text: "不是圣女，对信徒说的话。是，克劳德，对溟月。" },
    { text: "溟月愣了很久。久到海浪，拍了三次礁石。然后，她把脸，埋进了膝盖。肩膀，轻轻地，抖了起来。" },
    { who: "mingyue", text: "……（哭腔）才、才不是，因为，你这句话！是风！风，太大了！" },
    { who: "claude", text: "嗯。风，很大。" },
    { jump: "ch05_night_end" },

    /* ---------- 五、完成蜕变 ---------- */
    { label: "ch05_night_end" },
    { hide: "all", bg: "cairn_shore", transition: "cut", show: { id: "claude", pos: 50, expr: "normal" },
      text: "夜很深了。克劳德一个人，站在海边。海风，把她的衣角，吹得猎猎作响。" },

    { if: { poster: "torn" },
      text: "她从斗篷的内袋里，取出了那张折了四折的悬赏告示。展开，那颗土豆，在月光里，依旧圆滚滚的。" },
    { if: { poster: "torn" }, who: "claude", text: "……再见了，土豆。" },
    { if: { poster: "torn" }, text: "纸，落进了海里。被一个浪，卷着，打了几个转，慢慢地，沉了下去。" },

    { text: "她摸了摸右手背，那里，暗金色的印记，在黑暗里，安静地亮着，像一枚，沉睡的小太阳。" },
    { text: "「圣女」。「神血」。「复兴」。十年里，这些词，像三道锁，把她的名字，一圈一圈地，缠了起来。" },
    { text: "而今晚，她被叫成「克莱」。被一个陌生的老妇人，往碗里，舀了三勺汤。" },
    { who: "claude", text: "我，不是，在逃。" },
    { text: "她对着海，轻轻地，说出了这句话。像是在宣布一件，只有海，才有资格，听见的事。" },
    { who: "claude", expr: CL("smile"), text: "我是，出来看看的。" },
    { text: "海，没有回答。只是，一浪一浪，温柔地，涌了上来，又退了下去。像一个，很有耐心的，老人。" },

    /* ---------- 六、最后的夜 ---------- */
    { show: [ { id: "mingyue", pos: 24, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
      bgm: "ch05_night", who: "mingyue", text: "……您，还没睡？" },
    { who: "claude", text: "睡不着。你呢？" },
    { who: "mingyue", text: "我也是。……明天，我们，就走了。" },
    { who: "mingyue", expr: MY("worried"), text: "其实，我有点，怕。怕，再走一次，就更舍不得了。" },
    { who: "claude", text: "那，不走？" },
    { who: "mingyue", expr: MY("angry"), text: "不行！我欠了一百家的人情！还没还完！我得，出去，赚更多的钱！" },
    { who: "mingyue", text: "……而且，您，和白泷，还需要，我。" },
    { who: "bailong", text: "需要。你，会砍价。会洗碗。会，管着我。" },
    { who: "mingyue", expr: MY("shy", "shake"), text: "这、这些，才不是，什么，值得夸的事情！" },
    { text: "港口里，有人，还在远远地，唱着一支走了调的渔歌。三个人，没有再说话，只是，并排坐着，看着海。" },

    { text: "第二天清晨，七嫂，天不亮，就起来了。" },
    { speaker: "七嫂", text: "丫头，你的包袱，我替你，缝好了。每家，都出了一块布。你，别嫌，花哨。" },
    { text: "她把一只用百家布缝成的包袱，塞进了溟月的怀里。每一块补丁，都是一户人家的，一个念想。" },
    { who: "mingyue", expr: MY("surprised"), text: "……这里面，是，妈妈的，头巾。" },
    { speaker: "七嫂", text: "你阿梅妈妈的。我，一直，替你，收着。" },
    { text: "溟月把包袱，抱得很紧。这一次，她没有说「才没有哭」。" },

    { text: "海边的堤上，开着一丛，粉白色的海芙蓉。溟月摘了一朵，不由分说，塞进了克劳德怀里的圣典。" },
    { who: "mingyue", expr: MY("happy"), text: "圣女大人，也该，有点颜色！" },
    { who: "claude", expr: CL("smile"), text: "……书页，会被压皱。" },
    { who: "mingyue", text: "那就让它，皱！书，本来，就是用来，夹花的！" },
    { text: "克劳德低头，看着书页间那朵小小的花。过了很久，她轻轻地，合上了圣典。这一次，合得很轻。" },

    { effect: "fadeOut", text: "码头上，已经，站满了，送行的人。" },

    /* ===== 章末：直接衔接第六章（离港告别）。
       整合提示：第六章开头的 5 步「前情提要」，可在前五章齐全后删除。 ===== */
    { label: "ch05_end" },

    /* ##########################  第六章「潮退」  ########################## */

    { chapter: { no: "CHAPTER 06", title: "潮　退", sub: "THE EBB · 离港之后" } },

    /* ========== 一、离港 ========== */
    { hide: "all", bg: "harbor_dawn", transition: "black", bgm: "harbor",
      text: "清晨的港口还没有完全醒来。潮水拍着石阶，一下，又一下，像一个人把呼吸压得很低，怕吵醒了谁。" },
    { text: "码头上却已经站了一排人。七嫂的围裙上沾着面粉，老舵叼着一只没点火的烟斗，几个半大的孩子被大人拎着后领，不许往前冲。" },
    { show: [ { id: "mingyue", pos: 20, expr: "worried" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 80, expr: "normal" } ],
      who: "mingyue", text: "都、都说了不用送啦！又不是不回来了！……喂，七嫂，别再塞了，包袱已经拉不上了！" },
    { text: "那只包袱是用百家布缝成的。每一块补丁都来自不同的人家：渔网的蓝，旧桌布的格子，还有一角，是她养母留下的头巾。" },
    { text: "溟月把包袱抱得很紧。胸口起伏了两下，她才硬邦邦地补了一句——" },
    { who: "mingyue", expr: MY("shy"), text: "……我走了。你们都要好好吃饭，听到没有！" },
    { text: "老舵没有回答，只是抬起手，朝她摆了一下。那是渔民送船出海时才用的手势：不说再见，只说，回得来。" },
    { text: "克劳德向码头上的人群欠了欠身。那不是圣女的礼仪，只是一个吃过人家一顿饭、睡过人家一张床的人，该有的礼数。" },
    { who: "bailong", text: "……七嫂给了我这个。亮的。" },
    { text: "白泷把一枚红线穿着的贝壳举到眼前，认真得像在端详一座龙巢。然后她把它收进怀里，和另外三十七枚贝壳、一块碎玻璃、半枚铜板放在了一起。" },

    /* ========== 二、海岸路 ========== */
    { bg: "coast_road", transition: "fade", bgm: "road",
      text: "离港的第三日，海岸线向东北拐了一个很大的弯。" },
    { text: "天阴着，云压得很低，却不下雨。海风里带着一种说不上来的味道：不腥，也不咸，更像是很久没有被人翻开过的旧书页。" },
    { text: "克劳德走在最前面。圣典还捧在她手里，只是书页间多了一朵压干的海芙蓉。那是溟月硬塞的，说是「圣女大人也该有点颜色」。" },
    { who: "mingyue", expr: MY("happy", "jump"), text: "喂，克劳德！你的圣典被我压成花谱了，感想如何？" },
    { who: "claude", expr: CL("smile"), text: "书页比从前松了些。这样翻起来，倒是顺手。" },
    { who: "mingyue", text: "你这是在夸我吧！是吧！" },
    { who: "claude", text: "我只是在陈述事实。……但如果你非要这么理解，我不反对。" },
    { who: "mingyue", expr: MY("shy"), text: "哼。……算你会说话。" },
    { who: "bailong", text: "那边。" },
    { text: "白泷忽然停下脚步，指着路边礁石缝里的一点反光。那是一块被海水磨圆的碎玻璃，在这样的阴天里，居然也亮得像一粒小小的灯。" },
    { who: "bailong", text: "亮的。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "那是垃圾！" },
    { who: "bailong", text: "亮的。" },
    { who: "mingyue", expr: MY("normal"), text: "……行吧，收吧。反正你的包袱已经重得像座小山了。" },

    /* ========== 三、潮退 ========== */
    { bgm: "ebb", text: "就在这时，溟月的脚步停了。" },
    { who: "mingyue", expr: MY("worried"), text: "……等一下。" },
    { who: "mingyue", text: "你们有没有觉得，太安静了？" },
    { text: "起初，克劳德以为她在说笑。直到侧耳听了片刻，她才意识到，那种「安静」是从哪里来的——" },
    { text: "浪声没有了。从离开港口起便一直缀在身后的、那种永不疲倦的潮汐低语，像被谁用一只手，轻轻按住了。" },
    { text: "海鸥成群地从礁石上升起，一声不叫，径直向内陆飞去。" },
    { who: "mingyue", text: "不对。这不是退潮。退潮的时候，海会收着劲儿，一点一点地走……" },
    { who: "mingyue", text: "可现在，是被什么东西，整个儿抽走的。" },
    { text: "克劳德回过头去。" },

    { cg: "cg_ebb", sfx: "wave", text: "海，退走了。" },
    { text: "不是潮汐涨落那种温吞的退法，而是整片海面像一匹被掀起一角的灰布，向着地平线尽头，无声地卷了回去。" },
    { text: "三里，也许五里。黑色的海床赤裸裸地摊在阴云之下，湿泥泛着油光，成百上千条搁浅的鱼在上面翻着银白的肚皮。" },
    { text: "更远处，沉船露出了它们的肋骨。三百年前的商船，五百年前的战舰；再往深处，是一些形制古怪、不属于任何一座已知船坞的黑色船骸。" },
    { text: "而在所有船骸之间，有一道笔直的阶梯，从淤泥里升起，向海的更深处延伸。每一级石阶上，都刻着同一个纹样。" },
    { who: "claude", expr: CL("surprised"), text: "……是同一个圆。被分成许多片的，那个圆。" },
    { text: "迷雾遗迹里那面壁画的轮廓，在她眼前闪了一下：一个完整的圆，被一道又一道刻痕切开，每一块碎片，都朝着不同的方向……" },
    { text: "她右手背上，神血留下的印记忽然烫了一下。像是有谁在很远的地方，轻轻叫了一声她的名字。" },
    { who: "bailong", text: "好多亮的。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "你的重点能不能稍微放对一点？！" },
    { who: "bailong", text: "……放对了。亮的，在海里。" },

    /* ---------- 第一次抉择 ---------- */
    { text: "海正在退去，没有人知道它什么时候会回来。三个人，三种本能。这一次，没有谁能替克劳德做决定。",
      choices: [
        { text: "沿着石阶下去，亲眼看看纹样的尽头", jump: "A_start", set: { route: "A" } },
        { text: "立刻回港，让人们远离海岸",         jump: "B_start", set: { route: "B" } },
        { text: "登上高处，先弄清楚发生了什么",     jump: "C_start", set: { route: "C" } }
      ] },

    /* =====================================================
       路线 A：沿阶梯下海
       ===================================================== */
    { label: "A_start" },
    { cgHide: true, effect: "fadeOut" },
    { bg: "seabed_stairs", transition: "cut", bgm: "deep", effect: "fadeIn",
      text: "石阶比想象中更长，也比想象中更干净。" },
    { text: "本该覆满海藻与藤壶的石面，几乎没有任何附着物，仿佛那些在海里生长了千百年的东西，都默契地避开了这里。" },
    { text: "他们向下走。天光一寸一寸地被头顶的海床吞没，潮湿冰冷的空气里，有一种极低极低的震动，正从脚底的石头里传上来。" },
    { who: "bailong", expr: BL("smile"), text: "金币。" },
    { text: "白泷弯下腰，从淤泥里拈起一枚锈成绿色的古币，用袖口擦了擦，眼睛亮得像两粒小灯。沉船的货舱一路都在往外漏着它们的积蓄，她的包袱正在以一种令人担忧的速度变重。" },
    { who: "mingyue", expr: MY("worried"), text: "……你们听。" },
    { who: "bailong", text: "没有声音。" },
    { who: "mingyue", text: "有的。不是用耳朵听的，是……尾巴根。" },
    { text: "她下意识地按住了自己的尾骨。那条从裙摆下探出来的鲸尾，正在微微发颤。" },
    { who: "mingyue", text: "是歌。很老很老的歌。我从来没有学过，可我知道它在问什么。" },
    { who: "mingyue", text: "它在问：「你是谁家的孩子？」" },
    { who: "claude", text: "……你打算怎么回答它？" },
    { who: "mingyue", text: "我也不知道。我吃过那么多家的饭，要报哪一家的名字才好啊……" },
    { text: "没有人笑她。克劳德只是把脚步放慢了一点，与她并肩。" },

    { bg: "sunken_shrine", transition: "fade",
      text: "石阶的尽头，是一座半陷在淤泥里的穹顶建筑。没有门，只有一个圆形的入口，像一只刚刚闭上、却尚未完全合拢的眼睛。" },
    { text: "穹顶之下悬着一团光。它很淡，淡得像一口没有吐尽的气，沿着看不见的节律缓慢明灭：一下，又一下。" },
    { text: "那不是神明本身，只是神明沉睡时，从梦境缝隙里漏出来的一点余温。" },
    { who: "claude", expr: CL("serious"), text: "万年前分化的神，不止一位在这片海里留下过痕迹。……而教会的典籍，从来没有提过这里。" },
    { text: "怀里的圣典忽然变得很沉。克劳德低头，书页不知何时自己翻开了。最新的一页上，印刷的墨迹正在缓缓褪色，露出了下面一层更旧、更细的字迹。" },
    { text: "那些字，她并不认识。可她血管里的东西，认识。" },
    { text: "光向她的方向，倾了一倾。" },

    /* ---------- 第二次抉择（A） ---------- */
    { text: "那团余温似乎只是在等一个回应。而他们三个人里，有两个人听得懂它。",
      choices: [
        { text: "伸手触碰那团光，以神血回应它", jump: "A1", set: { touched: true } },
        { text: "退后一步，请溟月以歌声回应",   jump: "A2", set: { sang: true } }
      ] },

    /* ---------- A1：触碰余温 ---------- */
    { label: "A1" },
    { who: "claude", expr: CL("serious"), text: "我来。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "诶？！等等！你知道那是什么吗？！" },
    { who: "claude", text: "不知道。所以才要问。" },
    { text: "她把圣典换到左手，摘下右手的手套。那只手背上，暗金色的印记在昏暗中亮得像一枚刚烙好的烙印。" },
    { cg: "cg_vision", effect: "flash", text: "指尖触到光的一瞬间，世界没有了声音。" },
    { text: "她看见一个无法丈量的轮廓。不是人，不是兽，也不是任何一种可以被壁画描摹的形体，它只是「完整」这个词本身。" },
    { text: "然后，它被分开了。" },
    { text: "没有雷霆，没有神谕，甚至没有愤怒。只有一种缓慢而庞大的疼，像一个人活生生地，从自己身上撕下了许多个自己。" },
    { text: "每一片碎片，都朝着不同的方向坠落。有的落进海里，有的落进火里，有的落进还没有名字的黑暗。" },
    { text: "而在那些碎片落下的地方，后来有了城，有了王国，有了教会，也有了一本又一本被人庄重地捧在手里、写着「祂们自愿降下」的书。" },
    { text: "「自愿」。这个词，她读了许多年。" },
    { cgHide: true, effect: "flash", text: "……回过神来的时候，她已经跪在了石面上。温热的液体从鼻腔里流下来，一滴，一滴，落在石面上。" },
    { who: "mingyue", expr: MY("worried"), text: "笨蛋！笨蛋圣女！我都说了等一下的啊！" },
    { who: "bailong", text: "流血了。" },
    { who: "mingyue", text: "我知道她流血了！！" },
    { who: "claude", expr: CL("tired"), text: "……没事。我只是，看见了一点东西。一点书上没有写的东西。" },
    { text: "她抬头看向那团光。它已经暗了下去，像一个说完了最后一句话的人，终于合上了眼睛。" },
    { text: "白泷已经蹲下身子，龙翼半展，像一道沉默的屏风。" },
    { who: "bailong", text: "背。" },
    { jump: "A_end" },

    /* ---------- A2：鲸歌回应 ---------- */
    { label: "A2" },
    { who: "claude", text: "溟月。它在问的，不是我。" },
    { who: "mingyue", expr: MY("surprised", "jump"), text: "诶？我、我吗？可是我连词都不会……" },
    { who: "claude", text: "你刚才说，你知道它在问什么。" },
    { text: "溟月张了张嘴，那对鳍状的耳廓微微颤了颤。她看看光，又看看克劳德，最后几乎是赌气一般，把拳头攥在了胸前。" },
    { who: "mingyue", expr: MY("shy"), text: "……我只会哼，不保证好听。不许笑！" },
    { cg: "cg_whalesong", text: "她闭上眼睛，开口。" },
    { text: "那不是任何一种人类的语言。声音从胸腔最深处升起，低得几乎越过了听觉的下限，却又沉沉地、一寸一寸地铺满了整座穹顶。" },
    { text: "像一头巨大的生灵，在黑暗的水里，向另一头隔着千年的同类，发出了回应。" },
    { text: "光颤了一下。然后，它缓缓地、很轻很轻地，贴近了溟月的额头，像一个年老的守夜人，终于等到了晚归的孩子。" },
    { text: "它没有索取什么，也没有给予什么。只是在她面前停留了一小会儿，便退回穹顶之下，重新沉入那一下又一下的、缓慢的明灭里。" },
    { cgHide: true, who: "mingyue", expr: MY("worried"), text: "……我好像，知道下一句了。" },
    { who: "mingyue", text: "可是，我不能唱。至少现在不能。" },
    { who: "claude", text: "为什么？" },
    { who: "mingyue", text: "不知道。就是……不能。" },
    { text: "她把脸偏向一边，用袖口飞快地擦了一下眼角。这一次，没有人去追问。" },
    { who: "bailong", text: "那个光，我也想要。" },
    { who: "claude", text: "不行。" },
    { who: "mingyue", expr: MY("angry"), text: "绝对不行！" },
    { who: "bailong", text: "……好吧。它在睡觉。龙，不抢睡着的东西。" },
    { text: "这大概是白泷今天说过的、最有分量的一句话。" },
    { jump: "A_end" },

    /* ---------- A 汇合：海回来了 ---------- */
    { label: "A_end" },
    { sfx: "stone", effect: "shake", text: "头顶的穹顶忽然传来一声沉闷的轰鸣，碎石簌簌地落了下来。" },
    { text: "海，要回来了。" },
    { who: "claude", expr: CL("serious"), text: "回去。现在。" },
    { text: "白泷展开龙翼。那对半透明的白色羽膜，在昏暗中像两面月光织成的帆。她一手一个，拎住了两个人的后领，剩下的那只手里，还攥着那枚古币。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "你就不能把币放下吗！！" },
    { who: "bailong", text: "不能。我的。" },
    { sfx: "wave", effect: "shake", text: "他们冲出了石阶的最后一级。身后，海水像一整面倒下的城墙，无声地压了过来。" },
    { effect: "fadeOut", jump: "CAMP" },

    /* =====================================================
       路线 B：回港示警
       ===================================================== */
    { label: "B_start" },
    { cgHide: true, who: "claude", expr: CL("serious"), text: "回港口。现在。" },
    { who: "mingyue", text: "……哈？可是那道阶梯——" },
    { who: "claude", text: "阶梯不会跑。可是港口的人，会走到海床上去。" },
    { text: "溟月的脸色一下子白了。" },
    { who: "mingyue", expr: MY("worried"), text: "滩涂……七嫂的小孙子，每次退潮都会去挖蛤蜊！" },

    { bg: "harbor_day", transition: "black", bgm: "alarm",
      text: "三个人几乎是一路跑回去的。白泷展开半边龙翼，借着风一次次掠过路面，却依旧追不上溟月。" },
    { text: "那个平日里嘴硬又爱偷懒的小女仆，此刻跑得像一尾被放回水里的鱼。" },
    { text: "港口比她们想象的更热闹。" },
    { text: "没有人惊慌。孩子们提着木桶，大人拎着网兜，成百上千条搁浅的鱼在泥滩上蹦跳，像一场从天而降的节日。" },
    { text: "一个老渔夫甚至已经扛着竹筐，走到了离岸二百步的地方。" },
    { who: "claude", expr: CL("worried"), text: "……他们不知道。" },
    { text: "对凡人而言，海是一个有规矩的邻居：涨潮，退潮，风暴，平静。从来没有人教过他们，当邻居忽然把门板卸下来的时候，该怎么办。" },
    { text: "而此刻站在这里、知道「该怎么办」的人，只有一个。她的手里，捧着足以让整座港口跪下的身份。" },

    /* ---------- 第二次抉择（B） ---------- */
    { text: "要让两百多个人离开海边，只有两个办法：一个是快，一个是让所有人都相信。",
      choices: [
        { text: "亮出圣女的身份，一声令下", jump: "B1", set: { exposed: true } },
        { text: "隐去身份，让溟月去喊他们", jump: "B2", set: { trusted: true } }
      ] },

    /* ---------- B1：圣女之名 ---------- */
    { label: "B1" },
    { text: "克劳德踏上码头边一只倒扣的木桶，把圣典高高举过头顶。" },
    { text: "那一刻，她想起了许多年里，被人逼着在高台上举起书本的日子：那些「完美的微笑」，那些「标准的祷词」。" },
    { text: "但这一次，是她自己要举起它的。" },
    { who: "claude", expr: CL("serious"), text: "所有人听着——" },
    { text: "那是一副受过十年训练的嗓音，清冷、平稳，能穿透整座大教堂的穹顶。" },
    { who: "claude", text: "我是教会圣女克劳德。海在退，三刻之内，它会回来。所有人，立刻向高处撤离——现在！" },
    { text: "整座港口安静了一瞬。然后，不知是谁先跪了下去，像一圈圈扩散的涟漪，一排接着一排。" },
    { text: "「圣女大人……」「是圣女大人！」窃窃的声音此起彼伏。" },
    { text: "不到半刻钟，海滩上的人已经空了。孩子被抱起，网兜被丢下，鱼在泥里翻滚，却没有一个人回头。" },
    { text: "这是她这辈子，第一次用这个身份，做一件她自己想做的事。它竟然这样好用，这个事实，让她的胃里升起一阵说不清的酸涩。" },
    { cg: "cg_wave", sfx: "wave", effect: "shake", text: "三刻之后，海回来了。" },
    { text: "它没有咆哮。只是一整面灰色的墙，沿着空荡荡的海床缓缓立起，吞没了沉船，吞没了鱼，吞没了人们刚才站过的每一处地方。" },
    { text: "港口石阶最下面的三十级，被淹没了。没有一个人死去。" },
    { cgHide: true, text: "但这座港口里，再没有「路过的旅人」了。克劳德站在人群中央，四面八方，都是压低了声音的「圣女大人」。" },
    { who: "mingyue", expr: MY("worried"), text: "……你还好吧？" },
    { who: "claude", text: "我很好。只是在想一件事。" },
    { who: "claude", text: "他们跪下的时候，没有一个人问我，为什么在这里。他们只看了我手里的书。" },
    { who: "mingyue", expr: MY("normal"), text: "……那就让他们看清楚一点。圣女，是会蹲下来分鱼的那种。" },
    { text: "克劳德怔了怔。然后，她很轻地笑了一声，是那种没有经过任何训练的笑。" },
    { jump: "B_end" },

    /* ---------- B2：溟月之名 ---------- */
    { label: "B2" },
    { who: "claude", text: "溟月。他们会听你的。" },
    { who: "mingyue", expr: MY("surprised"), text: "……我？" },
    { who: "claude", text: "这座港口里，几乎每一户人家的灶台，你都蹭过饭。没有人比你更有资格，让他们转身。" },
    { who: "mingyue", expr: MY("shy", "shake"), text: "喂！这种事不要说得这么大声啊！……不过，是。" },
    { text: "溟月把双手拢在嘴边，深吸了一口气。" },
    { who: "mingyue", text: "全————港口的人！听好了！我是溟月！老舵家那个拖着鼻涕来蹭饭的溟月！" },
    { text: "话音还没落地，海滩上最近的几个人便回过头来。「溟月？」「是溟月丫头！」" },
    { who: "mingyue", text: "海要回来了！不是涨潮，是……反正不一样！我保证！谁要是不信，我今晚就去他家吃饭，一直吃到他信为止！" },
    { text: "人群先是愣了一下，然后爆出一阵笑声。有人笑，有人骂，有人嘴上说着「这丫头又胡闹」，手里却已经提起了木桶，拉起了孩子。" },
    { text: "笑声，是比任何命令都更有效的东西。它让人们知道，眼前的不是需要服从的权威，而是值得信任的人。" },
    { text: "克劳德没有出声。她挽起袖子，抱起一个哭闹的孩子，又扶起一位走不动的老妇人。她的手上沾满了泥，这是她在教会的十年里，从未有过的体验。" },
    { who: "bailong", text: "这个，要带吗？" },
    { text: "白泷拎着一整筐没人要的鱼，认真地问。" },
    { who: "mingyue", expr: MY("angry"), text: "不用！！" },
    { who: "bailong", text: "……好吧。" },
    { text: "她把筐放下，从里面挑了一条最大的，夹在腋下。几个孩子盯着她背后的龙翼，眼睛瞪得浑圆。" },
    { text: "「这个姐姐是龙！」「别管她是什么，快跑！」大人一把拽走了他们。" },
    { cg: "cg_wave", sfx: "wave", effect: "shake", text: "海回来了。" },
    { text: "一整面灰色的墙沿着空荡荡的海床缓缓立起，吞没了沉船，吞没了鱼，吞没了港口石阶最下面的三十级。" },
    { cgHide: true, text: "没有人受重伤，只有老舵为了抢回被丢下的渔网，崴了脚。他被人抬着，一路骂骂咧咧：" },
    { speaker: "老舵", text: "我的网！那是我的网！" },
    { who: "mingyue", expr: MY("happy"), text: "……听，还有力气骂人，没事的！" },
    { text: "溟月红着眼眶，笑出了声。克劳德看着她，忽然明白：有些东西，无论用多少个圣名，也换不来。" },
    { jump: "B_end" },

    /* ---------- B 汇合 ---------- */
    { label: "B_end" },
    { text: "那一天，港口的人们在山坡上的高地过了夜。没有人愿意在今天回到海边。" },
    { effect: "fadeOut", jump: "CAMP" },

    /* =====================================================
       路线 C：登高观望
       ===================================================== */
    { label: "C_start" },
    { cgHide: true, who: "claude", expr: CL("serious"), text: "上去。那座废灯塔的后面。在弄清楚之前，先站到高一点的地方。" },
    { who: "mingyue", text: "你说得好像很有经验。" },
    { who: "claude", text: "圣典里有一句话：「欲渡险水者，先观其势」。" },
    { who: "mingyue", expr: MY("happy"), text: "……那你当初被龙连行李一起叼走的时候，观势了吗？" },
    { who: "claude", expr: CL("normal"), text: "……那是例外。" },

    { bg: "hill_view", transition: "fade",
      text: "他们登上了岸边一座荒废的石灯塔。塔顶早已塌了半边，风从缺口里灌进来，吹得人的衣摆猎猎作响。" },
    { text: "从这里往下看，海床上的那道阶梯更清楚了。它不像是建造出来的，倒像是从一整块黑石里「长」出来的。" },
    { text: "它的终点在海的深处，被一层极淡的光雾遮着，看不真切。" },
    { who: "bailong", text: "……那里有个东西，在看我们。" },
    { who: "mingyue", expr: MY("worried"), text: "别吓人！" },
    { who: "bailong", text: "不是眼睛。是……被看着的感觉。" },
    { text: "没有人接话。因为克劳德手背上的印记，正在发烫。" },

    /* ---------- 两位执事 ---------- */
    { hide: "all", bg: "coast_road", transition: "cut", bgm: "comic",
      text: "与此同时，在海岸另一侧的官道上，有两个人正在争吵。" },
    { text: "他们身上的白色祭袍沾满了泥点，胸前的日轮徽记在阴天里黯淡得像两枚生了锈的铜板。" },
    { who: "oli", text: "雷蒙大人，您确定是这个方向吗？我们已经连续三天没有看到圣女大人的影子了。" },
    { who: "raymond", text: "奥利，你这是在怀疑一位拥有十五年神职经验的执事的判断力吗？" },
    { who: "oli", text: "不……我是在怀疑您的地图。您拿反了。" },
    { who: "raymond", text: "……这是特殊的阅读方式。你看，海在上面，所以我们现在在——海的下面。" },
    { who: "oli", text: "我们在海的下面？！" },
    { who: "raymond", text: "我是说，地图的下面。" },
    { who: "oli", text: "大人，您看那边……海，不见了。" },
    { who: "raymond", text: "……奥利，记下来。圣女大人的失踪，可能与海的失踪有关。" },
    { who: "oli", text: "这条要写进报告吗？" },
    { who: "raymond", text: "写。写得严重一点。这样我们的路费，才报销得下来。" },
    { who: "oli", text: "可是大人，如果圣女大人真的在海底……" },
    { who: "raymond", text: "那就去海底找！教会的执事，是不惧怕任何深渊的！" },
    { text: "两位执事对视了一眼，然后同时迈开步子，一路小跑着冲下海岸，冲向那片刚刚露出来的、尚且湿滑的泥滩。" },

    { bg: "hill_view", transition: "cut", bgm: "ebb", show: LINEUP,
      who: "mingyue", expr: MY("surprised"), text: "喂，你们看。那边……有人往海床上走了。" },
    { text: "两个小黑点，一高一矮，正深一脚浅一脚地往海床中央走去，脚下的淤泥发出咕叽咕叽的声响。其中一个，还举着一张明显拿反了的地图。" },
    { who: "claude", expr: CL("normal"), text: "……是教会的执事。我认得那件祭袍。左边那位，在我的晨祷上睡着过三次。" },

    /* ---------- 第二次抉择（C） ---------- */
    { text: "海随时可能回来，而那两个人，正走在最不该走的地方。克劳德需要决定，怎样处置这两位过分热心的追兵。",
      choices: [
        { text: "让白泷留下一个假线索，把他们引走", jump: "C1", set: { decoy: true } },
        { text: "在海回来之前，把他们拉上岸",       jump: "C2", set: { saved: true } }
      ] },

    /* ---------- C1：遗落的花饰 ---------- */
    { label: "C1" },
    { who: "claude", text: "……白泷。能帮我个忙吗？" },
    { who: "bailong", text: "亮的东西？" },
    { who: "claude", expr: CL("smile"), text: "这一次，是我的。" },
    { text: "克劳德抬手，摘下了发间那朵橙色的花饰。那是她十年里每个清晨亲手别上去的东西，圣女身份的标记之一。" },
    { text: "她原以为自己会舍不得。可它离开指尖的时候，竟轻得像一片花瓣，本来，也就是一片花瓣的重量。" },
    { who: "claude", text: "把它放在海床的另一头，离他们远一点，离海岸线更远一点。" },
    { who: "bailong", text: "好。" },
    { text: "白泷展开龙翼，贴着低云滑了出去。不到半刻钟，她便回到了灯塔，两手空空，脸上是一种近乎神圣的、完成了重要使命的神情。" },
    { text: "海床的另一头，两个小黑点忽然停住了。" },
    { who: "oli", text: "大、大人！您看！那是圣女大人的花饰！" },
    { who: "raymond", text: "……是遗物。" },
    { who: "oli", text: "遗物？！" },
    { who: "raymond", text: "是线索，奥利。是线索！圣女大人，一定是朝着那个方向去了！" },
    { text: "他们转过身，向着与海岸、与灯塔、与三个人完全相反的方向，一路狂奔而去。那张拿反了的地图，在风里翻飞得像一面投降的小旗。" },
    { who: "mingyue", expr: MY("surprised"), text: "……真的就这么送出去了？" },
    { who: "claude", text: "它陪了我十年。也该有个人，陪陪它了。" },
    { jump: "C_end" },

    /* ---------- C2：救下执事 ---------- */
    { label: "C2" },
    { who: "claude", text: "白泷。" },
    { who: "bailong", text: "嗯？" },
    { who: "claude", text: "那两个人，会被海淹掉。" },
    { who: "mingyue", expr: MY("angry"), text: "可是他们是追着你来的啊！" },
    { who: "claude", text: "我知道。但他们也是人。" },
    { text: "一时间，没有人说话。风吹过塔顶的缺口，发出一声很长很长的呜咽。" },
    { who: "mingyue", expr: MY("normal"), text: "……哼。我就知道你会这么说。白泷，去吧。拎着后领就行，别咬！" },
    { who: "bailong", text: "……我不咬人。" },
    { text: "龙翼展开的时候，仿佛有一面白色的帆，被谁从云里撕了出来。白泷俯冲而下，一手一个，把两位正在泥里原地转圈的执事，像拎小猫一样拎了起来。" },
    { who: "raymond", text: "我、我、我看见了龙！奥利！有龙！" },
    { who: "oli", text: "大人，我也看见了……而且她，好像有点不高兴……" },
    { text: "两位执事双双翻了个白眼，昏了过去。" },
    { text: "白泷把他们放在山坡上，认真地拍了拍手，然后又认真地，把他们的口袋翻了一遍。" },
    { who: "mingyue", expr: MY("angry", "shake"), text: "喂！！你在干什么！！" },
    { who: "bailong", text: "救命，要收费。" },
    { text: "她从两只口袋里，各摸出了一枚刻着日轮的铜币。" },
    { who: "claude", expr: CL("smile"), text: "……那就这样吧。" },
    { jump: "C_end" },

    /* ---------- C 汇合：海回来了 ---------- */
    { label: "C_end" },
    { cg: "cg_wave", sfx: "wave", effect: "shake", text: "海回来了。" },
    { text: "从高处看，它回来的样子，比任何一幅画都要安静。" },
    { text: "灰色的水沿着那道阶梯缓缓合拢，像一只合上的手掌，把一座沉睡的建筑，重新藏回了掌心。" },
    { text: "最后一道浪吞没阶梯之前，克劳德似乎看见，最深处的光亮了一下。像是有谁，在黑暗里，朝她点了点头。" },
    { cgHide: true, effect: "fadeOut", jump: "CAMP" },

    /* =====================================================
       汇合：夜
       ===================================================== */
    { label: "CAMP" },
    { bg: "night_camp", transition: "cut", bgm: "camp", effect: "fadeIn", show: LINEUP,
      text: "夜幕降下的时候，海已经恢复了原样。仿佛白天发生的一切，只是一场过于逼真的错觉。" },

    /* 按路线补一句「这一天留下的痕迹」 */
    { if: { touched: true },
      text: "克劳德靠着一块岩石坐着，脸色比篝火还要白。她右手背上的印记，一直没有完全消下去。" },
    { if: { sang: true },
      text: "溟月抱着膝盖，下巴搁在膝头，很久没有说话。她的尾尖在地上，无意识地，一下一下地，敲着某种不属于任何一首渔歌的节拍。" },
    { if: { exposed: true },
      text: "山坡下的火光连成了一片。那是港口的人们在高地上过夜。有人在唱歌，有人在争论明天该捞回些什么。只是每隔一会儿，总有人朝着这个方向，遥遥地合起手掌。" },
    { if: { exposed: true }, text: "克劳德把视线移开了。" },
    { if: { trusted: true },
      text: "山坡下的火光连成了一片。老舵的骂声隔着半座山坡，依旧清晰可闻：「我的网！我的网啊！」溟月听着，嘴角偷偷翘了一下。" },
    { if: { decoy: true },
      text: "克劳德的发间，少了一朵花。她时不时会抬手去摸那个位置，每一次摸空，都会怔一下，然后很轻地笑一声。" },
    { if: { saved: true },
      text: "远处的山坡上，两位执事靠着一块岩石昏睡着，怀里各自抱着一条被白泷顺手塞进去的鱼。据说，这是找零。" },

    { who: "mingyue", expr: MY("normal"), text: "……喂，克劳德。" },
    { who: "mingyue", text: "你，后悔过吗？跟我们走的这件事。" },
    { text: "克劳德认真地想了想。篝火的光在她的瞳孔里跳动，像一只只细小的、橙色的鸟。" },
    { who: "claude", text: "在教会的那十年里，每一天，都有人告诉我该做什么，该想什么，该在什么时候微笑。" },
    { who: "claude", text: "「后悔」这个词，从来不在被允许使用的范围之内。所以，这是我第一次，认真回答这个问题。" },
    { who: "claude", expr: CL("smile"), text: "不后悔。" },
    { who: "mingyue", expr: MY("shy"), text: "……哼。那、那就好。" },
    { text: "溟月把脸埋进了膝盖里。从火光能照到的角度，只能看到那对鳍状的耳廓，红得几乎要滴出血来。" },
    { who: "bailong", text: "我也不后悔。" },
    { who: "mingyue", expr: MY("angry"), text: "你根本没想过吧！" },
    { who: "bailong", text: "想过。今天。想了一下，要不要把海里的亮东西，全部带走。" },
    { who: "bailong", expr: BL("smile"), text: "后来觉得，它们会难过。所以，不带。" },
    { text: "说这话的时候，白泷看着手里那枚红线贝壳，难得，没有把它收进怀里。" },

    /* ---------- 北方的光 ---------- */
    { bgm: "omen", text: "就在这时，北方的天际，亮起了一道很淡很淡的光。" },
    { text: "像是有人，在黑夜的最远处，点燃了一盏灯。" },
    { text: "那光极远，极淡，却又清晰得不容错认。它与海底的那团余温，是同一种质地。" },
    { who: "claude", expr: CL("surprised"), text: "……祂们，开始醒了。" },
    { who: "claude", text: "不只是这片海。" },
    { text: "在迷雾遗迹的壁画上，也有一块碎片，朝着同样的方向。" },
    { text: "万年的沉默，正在一个接着一个地，被打破。" },
    { who: "mingyue", expr: MY("worried"), text: "那我们……" },
    { who: "bailong", text: "去看。" },
    { text: "克劳德没有立刻回答。她合上圣典，把那朵干枯的海芙蓉，仔细地夹回页间。" },
    { text: "然后，她抬起头。这一次，她没有为自己找任何理由。" },
    { who: "claude", expr: CL("normal"), text: "去看。" },
    { who: "claude", text: "不是因为责任，也不是因为谁的命令。" },
    { who: "claude", expr: CL("smile"), text: "只是因为，我想亲眼看看，这个被写在书里的世界，到底是什么样子。" },

    /* 按路线收尾 */
    { if: { touched: true },
      text: "她翻到圣典的最后一页。墨迹褪去之后，那层旧字迹只剩下一行，她终于读得懂的话：「莫信『自愿』二字。」" },
    { if: { sang: true },
      text: "溟月忽然哼起一小段调子，只有半句。她自己吓了一跳，立刻捂住了嘴。克劳德假装什么也没有听见。" },
    { if: { exposed: true },
      text: "山下，有一匹快马趁着夜色，朝着王都的方向去了。圣女大人在港口现身的消息，大概不用等到天亮。" },
    { if: { trusted: true },
      text: "山下，老舵拄着拐杖，朝他们的方向挥了挥手。还是那个手势：不说再见，只说，回得来。" },
    { if: { decoy: true },
      text: "远处的海床上，那朵橙色的花饰静静躺在月光里。会有人把它带回教会，也会有人，永远追不上它想去的地方。" },
    { if: { saved: true },
      text: "山坡上，雷蒙在梦里嘟囔了一句：「龙……不咬人……」" },

    { text: "篝火啪地爆了一声，火星升上夜空，与北方那一线孤零零的光，隔着整片大陆，遥遥相望。" },

    /* ---------- 章末（带路线标记，方便你测试） ---------- */
    { if: { touched: true },  end: { title: "CHAPTER 06 · 完", sub: "ROUTE A-1 · 触碰余温　—　未完待续" } },
    { if: { sang: true },     end: { title: "CHAPTER 06 · 完", sub: "ROUTE A-2 · 鲸之歌　—　未完待续" } },
    { if: { exposed: true },  end: { title: "CHAPTER 06 · 完", sub: "ROUTE B-1 · 圣女之名　—　未完待续" } },
    { if: { trusted: true },  end: { title: "CHAPTER 06 · 完", sub: "ROUTE B-2 · 百家饭　—　未完待续" } },
    { if: { decoy: true },    end: { title: "CHAPTER 06 · 完", sub: "ROUTE C-1 · 遗落的花饰　—　未完待续" } },
    { if: { saved: true },    end: { title: "CHAPTER 06 · 完", sub: "ROUTE C-2 · 救命收费　—　未完待续" } },
    { end: { title: "CHAPTER 06 · 完", sub: "未完待续" } }
  ]
};
