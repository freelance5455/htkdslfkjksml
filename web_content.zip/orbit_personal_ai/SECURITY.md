# Security notes — Orbit Personal AI

- The assistant name is a display preference, not an identity or permission.
- The voice button activates recognition only after the user taps it and enables voice input.
- This HTML app does not implement always-on wake-word listening or cross-app overlays.
- Android system permissions are separate from checkboxes inside this web page.
- A real wake-word assistant needs native Android APIs and an explicit, visible microphone/foreground-service design; it should not secretly listen in the background.
- Never store API keys, passwords, or private credentials in HTML, JavaScript, ZIP files, or APKs.
- Keep actions allow-listed, ask before opening links or performing consequential tasks, and provide a clear off switch.
- This starter is not a formal security audit.
