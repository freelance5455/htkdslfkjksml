# Orbit Personal AI — named assistant prototype

## Included
- `index.html`: mobile-friendly HTML prototype with customizable assistant name.
- `README.md`: usage and limits.
- `SECURITY.md`: security notes.

## New in this version
- You can choose a name such as Orbit, Nova, or another short name.
- The chosen name is saved in the browser's local storage when supported.
- Voice input button label updates to use the selected name.
- Voice input still requires opening the app and tapping the button.

## Wake-word limitation
This HTML app cannot listen for “Hey Orbit” while another app is in front or while the app is closed. Android restricts always-on microphone use. A real cross-app wake-word feature requires a native Android app, an approved microphone/foreground-service design, persistent notification, battery/privacy considerations, and possibly Android assistant-role integration. Do not claim this prototype can act like Google Assistant yet.

## Safety
The prototype only prepares web searches and asks for approval before opening them. It does not control other apps or read private device data. Do not put API keys in client-side code or the APK.
