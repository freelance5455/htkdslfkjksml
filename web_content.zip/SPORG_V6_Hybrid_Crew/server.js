import express from "express";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import { z } from "zod";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ORIGIN = process.env.PUBLIC_ORIGIN;
const SECRET = process.env.SESSION_SECRET;
const DB_PATH = process.env.DATABASE_PATH || "./data/sporg.sqlite";

if (process.env.NODE_ENV === "production") {
  if (!ORIGIN?.startsWith("https://")) throw new Error("PUBLIC_ORIGIN must be HTTPS in production.");
  if (!SECRET || Buffer.byteLength(SECRET) < 32) throw new Error("SESSION_SECRET must be at least 32 bytes.");
}

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS members (
  id TEXT PRIMARY KEY, display_name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, member_id TEXT NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS groups (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, owner_id TEXT NOT NULL REFERENCES members(id),
  invite_hash TEXT NOT NULL UNIQUE, invite_expires_at INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS memberships (
  group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  member_id TEXT NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(group_id, member_id)
);
CREATE TABLE IF NOT EXISTS goals (
  id TEXT PRIMARY KEY, group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  title TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', local_date TEXT NOT NULL,
  rest_day INTEGER NOT NULL DEFAULT 0, created_by TEXT NOT NULL REFERENCES members(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS completions (
  goal_id TEXT NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
  member_id TEXT NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(goal_id, member_id)
);
`);
app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"], connectSrc: ["'self'"], objectSrc: ["'none'"],
      baseUri: ["'self'"], frameAncestors: ["'none'"], upgradeInsecureRequests: []
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(compression());
app.use(express.json({ limit: "16kb" }));
const allowed = new Set((process.env.ALLOWED_ORIGINS || ORIGIN || "").split(",").map(x => x.trim()).filter(Boolean));
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && !allowed.has(origin)) return res.status(403).json({ error: "Origin not allowed" });
  if (origin) { res.setHeader("Access-Control-Allow-Origin", origin); res.setHeader("Vary", "Origin"); }
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));
app.use(express.static("public", { etag: true, maxAge: "1h" }));

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString("base64url");
const hash = value => crypto.createHash("sha256").update(value).digest("hex");
const id = () => crypto.randomUUID();
const auth = (req, res, next) => {
  const raw = req.headers.authorization?.startsWith("Bearer ") ? req.headers.authorization.slice(7) : "";
  if (!raw) return res.status(401).json({ error: "Sign in required" });
  const session = db.prepare("SELECT member_id, expires_at FROM sessions WHERE token_hash=?").get(hash(raw));
  if (!session || session.expires_at < Date.now()) return res.status(401).json({ error: "Session expired" });
  req.memberId = session.member_id; next();
};
const memberOf = (groupId, memberId) =>
  !!db.prepare("SELECT 1 FROM memberships WHERE group_id=? AND member_id=?").get(groupId, memberId);

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "SPORG. Crew API" }));

// Minimal account bootstrap for this starter. In production, replace with verified email/passkey
// enrollment and account recovery; do not expose this anonymous bootstrap as a public identity system.
app.post("/api/account", rateLimit({ windowMs: 60 * 60 * 1000, limit: 10 }), (req, res) => {
  const parsed = z.object({ displayName: z.string().trim().min(1).max(32) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Name must be 1–32 characters." });
  const memberId = id(), token = randomToken(32);
  db.prepare("INSERT INTO members(id,display_name) VALUES(?,?)").run(memberId, parsed.data.displayName);
  db.prepare("INSERT INTO sessions(token_hash,member_id,expires_at) VALUES(?,?,?)")
    .run(hash(token), memberId, Date.now() + 1000 * 60 * 60 * 24 * 30);
  res.status(201).json({ token, member: { id: memberId, displayName: parsed.data.displayName }, expiresInDays: 30 });
});

app.get("/api/me", auth, (req, res) => {
  const member = db.prepare("SELECT id,display_name AS displayName FROM members WHERE id=?").get(req.memberId);
  res.json({ member });
});

app.post("/api/groups", auth, (req, res) => {
  const parsed = z.object({ name: z.string().trim().min(2).max(40) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Group name must be 2–40 characters." });
  const groupId = id(), invite = randomToken(24);
  const create = db.transaction(() => {
    db.prepare("INSERT INTO groups(id,name,owner_id,invite_hash,invite_expires_at) VALUES(?,?,?,?,?)")
      .run(groupId, parsed.data.name, req.memberId, hash(invite), Date.now() + 1000 * 60 * 60 * 24 * 7);
    db.prepare("INSERT INTO memberships(group_id,member_id) VALUES(?,?)").run(groupId, req.memberId);
  });
  create();
  res.status(201).json({ group: { id: groupId, name: parsed.data.name }, inviteCode: invite, inviteExpiresInDays: 7 });
});

app.post("/api/groups/join", auth, (req, res) => {
  const parsed = z.object({ inviteCode: z.string().min(20).max(100) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid invite." });
  const group = db.prepare("SELECT id,name,invite_expires_at FROM groups WHERE invite_hash=?").get(hash(parsed.data.inviteCode));
  if (!group || group.invite_expires_at < Date.now()) return res.status(404).json({ error: "Invite is invalid or expired." });
  const count = db.prepare("SELECT COUNT(*) AS n FROM memberships WHERE group_id=?").get(group.id).n;
  if (count >= 20) return res.status(409).json({ error: "This starter limits groups to 20 members." });
  db.prepare("INSERT OR IGNORE INTO memberships(group_id,member_id) VALUES(?,?)").run(group.id, req.memberId);
  res.json({ group: { id: group.id, name: group.name } });
});

app.get("/api/groups", auth, (req, res) => {
  const groups = db.prepare(`
    SELECT g.id,g.name,
      (SELECT COUNT(*) FROM memberships m WHERE m.group_id=g.id) AS memberCount
    FROM groups g JOIN memberships mine ON mine.group_id=g.id
    WHERE mine.member_id=? ORDER BY g.created_at DESC
  `).all(req.memberId);
  res.json({ groups });
});

app.get("/api/groups/:id", auth, (req, res) => {
  if (!memberOf(req.params.id, req.memberId)) return res.sendStatus(404);
  const group = db.prepare("SELECT id,name FROM groups WHERE id=?").get(req.params.id);
  const members = db.prepare(`SELECT m.id,m.display_name AS displayName
    FROM members m JOIN memberships x ON x.member_id=m.id WHERE x.group_id=? ORDER BY x.joined_at`).all(req.params.id);
  const goals = db.prepare(`SELECT g.id,g.title,g.details,g.local_date AS localDate,g.rest_day AS restDay,
    m.display_name AS createdBy,
    (SELECT COUNT(*) FROM memberships x WHERE x.group_id=g.group_id) AS memberCount,
    (SELECT COUNT(*) FROM completions c WHERE c.goal_id=g.id) AS completedCount,
    EXISTS(SELECT 1 FROM completions c WHERE c.goal_id=g.id AND c.member_id=?) AS mineCompleted
    FROM goals g JOIN members m ON m.id=g.created_by
    WHERE g.group_id=? ORDER BY g.local_date DESC,g.created_at DESC LIMIT 60`).all(req.memberId, req.params.id);
  res.json({ group, members, goals });
});

app.post("/api/groups/:id/goals", auth, (req, res) => {
  if (!memberOf(req.params.id, req.memberId)) return res.sendStatus(404);
  const parsed = z.object({
    title: z.string().trim().min(2).max(100),
    details: z.string().trim().max(240).optional().default(""),
    localDate: z.string().regex(/^\\d{4}-\\d{2}-\\d{2}$/),
    restDay: z.boolean().optional().default(false)
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid goal details." });
  const goalId = id();
  db.prepare("INSERT INTO goals(id,group_id,title,details,local_date,rest_day,created_by) VALUES(?,?,?,?,?,?,?)")
    .run(goalId, req.params.id, parsed.data.title, parsed.data.details, parsed.data.localDate, Number(parsed.data.restDay), req.memberId);
  res.status(201).json({ goalId });
});

app.post("/api/goals/:id/complete", auth, (req, res) => {
  const goal = db.prepare("SELECT id,group_id,local_date,rest_day FROM goals WHERE id=?").get(req.params.id);
  if (!goal || !memberOf(goal.group_id, req.memberId)) return res.sendStatus(404);
  if (goal.rest_day) return res.status(409).json({ error: "Rest days do not need completion." });
  db.prepare("INSERT OR IGNORE INTO completions(goal_id,member_id) VALUES(?,?)").run(goal.id, req.memberId);
  const total = db.prepare("SELECT COUNT(*) AS n FROM memberships WHERE group_id=?").get(goal.group_id).n;
  const done = db.prepare("SELECT COUNT(*) AS n FROM completions WHERE goal_id=?").get(goal.id).n;
  res.json({ completed: true, allMembersCompleted: total > 0 && total === done, completedCount: done, memberCount: total });
});

app.delete("/api/goals/:id/complete", auth, (req, res) => {
  const goal = db.prepare("SELECT id,group_id FROM goals WHERE id=?").get(req.params.id);
  if (!goal || !memberOf(goal.group_id, req.memberId)) return res.sendStatus(404);
  db.prepare("DELETE FROM completions WHERE goal_id=? AND member_id=?").run(goal.id, req.memberId);
  res.sendStatus(204);
});

// Streak is calculated in the user's group-local calendar using ISO date keys.
// A day counts only when every member completed every non-rest goal for that date.
app.get("/api/groups/:id/streak", auth, (req, res) => {
  if (!memberOf(req.params.id, req.memberId)) return res.sendStatus(404);
  const dates = db.prepare("SELECT DISTINCT local_date FROM goals WHERE group_id=? AND rest_day=0 ORDER BY local_date DESC")
    .all(req.params.id).map(x => x.local_date);
  const totalMembers = db.prepare("SELECT COUNT(*) AS n FROM memberships WHERE group_id=?").get(req.params.id).n;
  let streak = 0;
  const today = new Date().toISOString().slice(0,10);
  // Do not penalize a day before its goal has been created; start from today or latest scheduled day.
  let cursor = dates.includes(today) ? today : dates[0];
  while (cursor && dates.includes(cursor)) {
    const incomplete = db.prepare(`SELECT COUNT(*) AS n FROM goals g
      WHERE g.group_id=? AND g.local_date=? AND g.rest_day=0
      AND (SELECT COUNT(*) FROM completions c WHERE c.goal_id=g.id) < ?`).get(req.params.id, cursor, totalMembers).n;
    if (incomplete > 0) break;
    streak++;
    const d = new Date(cursor + "T12:00:00Z"); d.setUTCDate(d.getUTCDate()-1);
    cursor = d.toISOString().slice(0,10);
  }
  res.json({ streak, tier: streak >= 30 ? "LEGEND" : streak >= 14 ? "ELITE" : streak >= 7 ? "PRO" : streak >= 3 ? "RISING" : "STARTER" });
});

app.post("/api/groups/:id/invites/rotate", auth, (req, res) => {
  const group = db.prepare("SELECT owner_id FROM groups WHERE id=?").get(req.params.id);
  if (!group || group.owner_id !== req.memberId) return res.sendStatus(404);
  const invite = randomToken(24);
  db.prepare("UPDATE groups SET invite_hash=?,invite_expires_at=? WHERE id=?")
    .run(hash(invite), Date.now() + 1000 * 60 * 60 * 24 * 7, req.params.id);
  res.json({ inviteCode: invite, inviteExpiresInDays: 7 });
});

app.use((err, _req, res, _next) => {
  console.error("Request failed:", err.message);
  res.status(500).json({ error: "Something went wrong." });
});
app.listen(PORT, () => console.log(`SPORG. server listening on ${PORT}`));
