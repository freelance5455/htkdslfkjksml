SPORG. V6 – HYBRID CREW (ENTWICKLUNGSSTARTER)
================================================

ENTHALTEN
- Schwarze/weiße responsive App-Oberfläche
- Crew-Gruppen erstellen und per zeitlich begrenztem Code beitreten
- Gruppenmitglieder anzeigen
- Gemeinsame Tagesziele und Ruhetage erstellen
- Eigene Erledigt-Bestätigung je Mitglied
- Gruppenzielstatus und einfacher Streak-Endpunkt
- Express-API, SQLite, Eingabevalidierung, Rate-Limits, Helmet-Sicherheitsheader
- Gruppen-/Mitgliedschaftsprüfungen auf API-Ebene

WICHTIG: NOCH KEIN PRODUKTIONSREIFES SICHERHEITSSYSTEM
Diese Version ist ein Entwicklungsprototyp. Die Account-Erstellung erzeugt ein anonymes Demo-Konto ohne verifizierte Identität. Das Token liegt in sessionStorage und ist NICHT durch Android Keystore geschützt. Es gibt noch keine sichere Kontowiederherstellung, Passkeys, Mehrgeräteverwaltung, Ende-zu-Ende-Verschlüsselung oder unabhängigen Penetrationstest. Nicht mit echten persönlichen Daten verwenden und nicht öffentlich deployen, bevor diese Punkte umgesetzt sind.

DATENSCHUTZ-ARCHITEKTUR
- Der Beispielserver speichert nur Gruppenkonten, Gruppennamen, Mitgliedschaften, Ziele und Bestätigungen.
- Private Profil-/Kalender-/Zählerdaten werden in dieser V6-Oberfläche nicht zum Server hochgeladen.
- Für eine echte native Android-App: private Daten in verschlüsselter lokaler Datenbank speichern; Schlüssel über Android Keystore verwalten; Sitzungstoken ebenfalls im Keystore sichern.
- Der Server braucht für Gruppenfunktionen Internet. HTTPS ist zwingend.
- Die API protokolliert keine Request-Bodies; dennoch muss der Hoster seine Logs/Backups prüfen und minimieren.

LOKAL STARTEN (NUR TESTUMGEBUNG)
1. Node.js 20+ installieren.
2. Diesen Ordner entpacken.
3. Terminal im Ordner öffnen und `npm install` ausführen.
4. `.env.example` nach `.env` kopieren.
5. Für lokale Entwicklung eine zufällige SESSION_SECRET mit mindestens 32 Bytes eintragen.
6. `npm start`
7. Im Browser `http://localhost:3000` öffnen.

PRODUKTIONSDEPLOYMENT – VORHER ERFORDERLICH
- Server ausschließlich hinter HTTPS betreiben.
- PUBLIC_ORIGIN und ALLOWED_ORIGINS auf die exakte eigene HTTPS-Domain setzen.
- SESSION_SECRET sicher erzeugen und als Secret beim Hoster speichern, nie committen.
- Datenbankdatei/Backups mit restriktiven Dateirechten und Verschlüsselung auf Volume-/Host-Ebene schützen.
- Regelmäßige Updates, Backups und getestete Wiederherstellung einrichten.
- Konten auf verifizierte Anmeldung (bevorzugt Passkeys/WebAuthn) umstellen.
- Sitzungstoken in nativer App im Android Keystore speichern; kurze Laufzeit, Widerruf und Geräteverwaltung ergänzen.
- Einladungen nach Nutzung optional widerrufbar machen; Missbrauchsschutz/Moderation ergänzen.
- Serverseitige Zeitzonen- und Streak-Regeln festlegen. Aktuelle Streak-Berechnung ist ein einfacher Prototyp.
- Unabhängige Sicherheitsprüfung vor Veröffentlichung.

STREAK-REGEL IM PROTOTYP
Eine Tagesstreak steigt, wenn alle Gruppenmitglieder jedes nicht als Ruhetag markierte Gruppenziel dieses Datums bestätigt haben. Das ist absichtlich eine einfache Startregel. Für Produktion sollten Gruppe eine Zeitzone haben, Tagesabschluss erst nach Mitternacht erfolgen und Änderungen/Austritte/Aufnahmen klar geregelt sein.

KEINE KI- ODER GERÄTESTEUERUNGSFUNKTION
Das Projekt enthält keine KI-API und keine Funktion zum Steuern des Telefons. Eine App kann aber keine absolute Sicherheit garantieren; Schutz hängt auch von Android, Gerätesperre, Hosting und Updates ab.
