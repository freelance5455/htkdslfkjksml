const $ = id => document.getElementById(id);
let token = sessionStorage.getItem("sporg_demo_token") || "";
let activeGroupId = "";
const api = async (path, options={}) => {
  const res = await fetch("/api"+path, {
    ...options, headers: {"Content-Type":"application/json", ...(token?{Authorization:"Bearer "+token}:{}), ...(options.headers||{})}
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
};
function status(id,msg){$(id).textContent=msg}
function localDate(){const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)}
$("goalDate").value=localDate();
async function loadGroups(){
  const data=await api("/groups");
  $("groups").innerHTML="";
  data.groups.forEach(g=>{
    const b=document.createElement("button");b.className="group-choice";
    const name=document.createElement("span");name.textContent=g.name;
    const count=document.createElement("span");count.textContent=`${g.memberCount} Mitglieder`;
    b.append(name,count);b.addEventListener("click",()=>openGroup(g.id));$("groups").append(b);
  });
}
async function openGroup(id){
  activeGroupId=id;const data=await api(`/groups/${id}`);
  $("activeGroup").classList.remove("hidden");$("activeGroupName").textContent=data.group.name;
  $("memberCount").textContent=`${data.members.length} Mitglieder`;
  $("members").innerHTML="";
  data.members.forEach(m=>{const el=document.createElement("span");el.className="member";el.textContent=m.displayName;$("members").append(el)});
  $("goals").innerHTML="";
  data.goals.forEach(g=>{
    const el=document.createElement("article");el.className="goal";
    const top=document.createElement("div");top.className="goal-top";
    const h=document.createElement("h3");h.textContent=g.title;
    const progress=document.createElement("span");progress.className="progress";progress.textContent=`${g.completedCount}/${g.memberCount}`;
    top.append(h,progress);el.append(top);
    const p=document.createElement("p");p.textContent=`${g.localDate}${g.restDay?" · Ruhetag":g.details?" · "+g.details:""}`;el.append(p);
    if(!g.restDay){
      const btn=document.createElement("button");btn.textContent=g.mineCompleted?"Erledigt ✓":"Meine Aufgabe abhaken";
      btn.className=g.mineCompleted?"done":"";
      btn.disabled=!!g.mineCompleted;
      btn.addEventListener("click",async()=>{try{const result=await api(`/goals/${g.id}/complete`,{method:"POST",body:"{}"});status("crewStatus",result.allMembersCompleted?"Alle haben es geschafft – Tagesziel komplett!":"Bestätigung gespeichert.");await openGroup(id)}catch(e){status("crewStatus",e.message)}});
      el.append(btn);
    }else{const rest=document.createElement("p");rest.textContent="Heute ist gemeinsamer Ruhetag.";el.append(rest)}
    $("goals").append(el);
  });
  const s=await api(`/groups/${id}/streak`);$("streak").textContent=s.streak;
}
$("createAccount").addEventListener("click",async()=>{
  try{const data=await api("/account",{method:"POST",body:JSON.stringify({displayName:$("displayName").value})});
    token=data.token;sessionStorage.setItem("sporg_demo_token",token);$("account").classList.add("hidden");$("crew").classList.remove("hidden");
    status("accountStatus",`Willkommen, ${data.member.displayName}.`);await loadGroups();
  }catch(e){status("accountStatus",e.message)}
});
$("createGroup").addEventListener("click",async()=>{
  try{const d=await api("/groups",{method:"POST",body:JSON.stringify({name:$("groupName").value})});
    status("crewStatus",`Einladungscode (7 Tage gültig): ${d.inviteCode} — teile ihn privat.`);await loadGroups();await openGroup(d.group.id);
  }catch(e){status("crewStatus",e.message)}
});
$("joinGroup").addEventListener("click",async()=>{
  try{const d=await api("/groups/join",{method:"POST",body:JSON.stringify({inviteCode:$("inviteCode").value.trim()})});
    status("crewStatus",`Du bist ${d.group.name} beigetreten.`);await loadGroups();await openGroup(d.group.id);
  }catch(e){status("crewStatus",e.message)}
});
$("addGoal").addEventListener("click",async()=>{
  try{await api(`/groups/${activeGroupId}/goals`,{method:"POST",body:JSON.stringify({
    title:$("goalTitle").value,details:$("goalDetails").value,localDate:$("goalDate").value,restDay:$("restDay").checked
  })});$("goalTitle").value="";$("goalDetails").value="";await openGroup(activeGroupId);status("crewStatus","Gruppenziel erstellt.");
  }catch(e){status("crewStatus",e.message)}
});
if(token){
  api("/me").then(async d=>{$("account").classList.add("hidden");$("crew").classList.remove("hidden");status("accountStatus",`Angemeldet als ${d.member.displayName}`);await loadGroups()})
    .catch(()=>{token="";sessionStorage.removeItem("sporg_demo_token")});
}
