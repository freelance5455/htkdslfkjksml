THE MANAGEMENT — SUPABASE VERSION

1. Create a project at https://supabase.com/
2. Open SQL Editor and run setup.sql.
3. Open Project Settings > API.
4. Copy Project URL and anon/public key into supabase-config.js.
5. Upload these files to HTTPS hosting.
6. Open the site on two phones. Messages in GENERAL GROUP will sync in real time.

Do NOT put a service_role key in the browser.

This package currently implements the real-time GENERAL GROUP foundation. Private chats, groups, updates, media, and calls can be added on the same Supabase backend.
