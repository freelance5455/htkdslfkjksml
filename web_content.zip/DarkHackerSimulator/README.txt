DARK HACKER SIMULATOR - Prototype v1

How to try on Android:
1. Download and extract DarkHackerSimulator.zip.
2. Open index.html in Chrome or another modern browser.
3. Features work locally in the browser. No account or network access is required.

Important:
This is a working browser prototype, NOT an Android APK and NOT yet ready to upload to Myket.
It uses simulated scan results only and does not hack devices, accounts, Wi-Fi networks, or servers.
To publish on Myket, it must be packaged as an Android app, tested on devices, and reviewed against Myket's current submission requirements.
