#!/data/data/com.termux/files/usr/bin/bash
# Cài & chạy llama.cpp gốc trong Termux, mở API ở http://127.0.0.1:8081
# Dùng:  bash termux_setup.sh [0.5b|1.5b|3b] [spec]
#   spec = bật speculative decoding (model nháp 0.5B). Nếu báo lỗi tham số thì chạy lại không có "spec".
MODEL="${1:-1.5b}"; SPEC="${2:-}"
HF=https://huggingface.co/Qwen
case "$MODEL" in
  0.5b) R=Qwen2.5-0.5B-Instruct-GGUF; F=qwen2.5-0.5b-instruct-q4_k_m.gguf;;
  3b)   R=Qwen2.5-3B-Instruct-GGUF;   F=qwen2.5-3b-instruct-q4_k_m.gguf;;
  *)    R=Qwen2.5-1.5B-Instruct-GGUF; F=qwen2.5-1.5b-instruct-q4_k_m.gguf;;
esac
CORES=$(nproc); T=$(( CORES / 2 )); [ "$T" -lt 2 ] && T=2

pkg update -y && pkg install -y curl
command -v llama-server >/dev/null || pkg install -y llama-cpp
if command -v llama-server >/dev/null; then LS=$(command -v llama-server)
else
  echo ">> Không có gói llama-cpp, biên dịch từ mã nguồn (10–20 phút)..."
  pkg install -y git cmake clang
  [ -d ~/llama.cpp ] || git clone --depth 1 https://github.com/ggml-org/llama.cpp ~/llama.cpp
  cmake -S ~/llama.cpp -B ~/llama.cpp/build -DLLAMA_CURL=OFF -DGGML_NATIVE=ON
  cmake --build ~/llama.cpp/build -j"$T" --target llama-server
  LS=~/llama.cpp/build/bin/llama-server
fi

mkdir -p ~/models
[ -f ~/models/$F ] || curl -L -C - -o ~/models/$F "$HF/$R/resolve/main/$F"
ARGS=""
if [ "$SPEC" = "spec" ] && [ "$MODEL" != "0.5b" ]; then
  D=qwen2.5-0.5b-instruct-q4_k_m.gguf
  [ -f ~/models/$D ] || curl -L -C - -o ~/models/$D "$HF/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/$D"
  ARGS="-md $HOME/models/$D --spec-draft-n-max 5"
fi

termux-wake-lock 2>/dev/null
echo ">> Chạy server ($F, $T luồng). Giữ Termux mở, rồi vào trang web bấm Kết nối."
exec "$LS" -m ~/models/$F -c 2048 -t "$T" -b 512 --host 127.0.0.1 --port 8081 $ARGS
