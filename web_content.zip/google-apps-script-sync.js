/**
 * ترید یار - سرور همگام‌سازی Google Apps Script
 * 
 * این کد رو در https://script.google.com کپی کنید و به صورت Web App دیپلوی کنید
 * 
 * دستورالعمل:
 * 1. به https://script.google.com بروید
 * 2. "New Project" را کلیک کنید
 * 3. کل این کد را کپی و جایگزین کنید
 * 4. روی "Deploy" → "New Deployment" کلیک کنید
 * 5. نوع "Web app" را انتخاب کنید
 * 6. "Execute as": Me
 * 7. "Who has access": Anyone
 * 8. روی "Deploy" کلیک کنید
 * 9. URL که به شما می‌دهد را کپی کنید
 * 10. در پنل مدیریت ترید یار، این URL را در تنظیمات سرور وارد کنید
 */

function doGet(e) {
  var data = getData();
  if (!data) {
    return ContentService.createTextOutput(JSON.stringify({ok: false, reason: 'no_data'}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  return ContentService.createTextOutput(JSON.stringify({ok: true, doc: data}))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    var body = e.postData.contents;
    var data = JSON.parse(body);
    setData(data);
    return ContentService.createTextOutput(JSON.stringify({ok: true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ok: false, error: String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function getData() {
  try {
    var file = DriveApp.getFilesByName('tradyar_sync_data.json');
    if (file.hasNext()) {
      var f = file.next();
      var content = f.getBlob().getDataAsString();
      return JSON.parse(content);
    }
  } catch(e) {}
  return null;
}

function setData(data) {
  var fileName = 'tradyar_sync_data.json';
  var file = DriveApp.getFilesByName(fileName);
  if (file.hasNext()) {
    var f = file.next();
    f.setContent(JSON.stringify(data));
  } else {
    DriveApp.createFile(fileName, JSON.stringify(data));
  }
}
