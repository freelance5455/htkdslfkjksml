package ai.jarvis.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * JARVIS Assistant Service - Android Foreground Voice Service
 * 
 * Complies with Android 14 foreground service policies:
 * - Declares FOREGROUND_SERVICE_TYPE_MICROPHONE in manifest
 * - Shows an ongoing persistent user notification explaining active listening
 * - Captures audio streams for speech-to-text processing
 */
class JarvisAssistantService : Service() {

    private val CHANNEL_ID = "jarvis_assistant_channel"
    private val NOTIFICATION_ID = 2001

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification("JARVIS Listening for Commands...")
        startForeground(NOTIFICATION_ID, notification)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotification(statusText: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS Personal Assistant")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Assistant Foreground Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifies user when JARVIS is actively processing voice input."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
