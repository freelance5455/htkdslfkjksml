package ai.jarvis.companion

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * JARVIS Companion - Android Native Gateway
 * 
 * Provides:
 * - Default assistant invocation via hardware long-press or gesture
 * - Microphone permission lifecycle
 * - Foreground service binding for hands-free interaction
 * - Secure REST connection to the JARVIS OS backend
 */
class MainActivity : AppCompatActivity() {

    private val PERMISSION_REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Simple programmatic UI without XML dependencies
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 64, 48, 64)
            gravity = android.view.Gravity.CENTER_HORIZONTAL
        }

        val titleView = TextView(this).apply {
            text = "JARVIS Personal AI Operating System"
            textSize = 22f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
        }

        val statusView = TextView(this).apply {
            text = "Companion Status: Ready\nConnected to JARVIS Core"
            textSize = 15f
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(0, 32, 0, 48)
            gravity = android.view.Gravity.CENTER
        }

        val voiceButton = Button(this).apply {
            text = "Start Hands-Free Voice Mode"
            setBackgroundColor(android.graphics.Color.parseColor("#3B82F6"))
            setTextColor(android.graphics.Color.WHITE)
            setPadding(32, 24, 32, 24)
            setOnClickListener {
                checkPermissionsAndStartService()
            }
        }

        val noteView = TextView(this).apply {
            text = "Truthful Reality Notice:\nContinuous background hotword listening requires an active Android Foreground Service with a visible persistent notification as mandated by Android 14 security specifications."
            textSize = 12f
            setTextColor(android.graphics.Color.GRAY)
            setPadding(0, 48, 0, 0)
            gravity = android.view.Gravity.CENTER
        }

        layout.addView(titleView)
        layout.addView(statusView)
        layout.addView(voiceButton)
        layout.addView(noteView)

        setContentView(layout)
        layout.setBackgroundColor(android.graphics.Color.parseColor("#0F172A"))

        // Check if launched as an assistant action
        if (Intent.ACTION_ASSIST == intent.action || Intent.ACTION_VOICE_COMMAND == intent.action) {
            checkPermissionsAndStartService()
        }
    }

    private fun checkPermissionsAndStartService() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        } else {
            startAssistantService()
        }
    }

    private fun startAssistantService() {
        val serviceIntent = Intent(this, JarvisAssistantService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startAssistantService()
        }
    }
}
