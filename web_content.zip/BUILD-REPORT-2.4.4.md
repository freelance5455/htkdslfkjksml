# Build report — ANONYMOUX STUDIO 2.4.4

- Refreshed the authenticated Resources centre heading and responsive search/card layout while retaining the existing curated tools and tutorial catalogue.
- Expanded the admin Resources manager with content counts and a clear draft-to-published workflow explanation.
- Kept admin-only management for tool listings, tutorial lessons, categories, screenshots/GIFs, video references and related resources; publication remains database-driven.
- Added a dedicated `lip-sync.php` route and a first-class Lip Sync item in the workspace sidebar. The route opens the existing Magic Hour Lip Sync panel directly; Video Studio remains a separate sidebar item.
- Added sidebar icon artwork for Lip Sync and Resources and bumped asset cache versions.
- Preserved existing PHP backend/API, authentication, credit charging, provider polling and storage behavior.

## Static verification

- PHP syntax checks: all project PHP files passed.
- JavaScript syntax checks: all project JavaScript files passed.
- ZIP archive integrity: verified after packaging.
- Live database/provider execution was not available in this build container; deploy to the configured hosting/database and run an authenticated acceptance test.
