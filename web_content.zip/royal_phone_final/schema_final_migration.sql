-- Migration/verification for the FINAL Royal Phone app.
-- Run this only if the tables from the earlier setup already exist.
-- It aligns the schema with the final app and enables realtime.

alter table public.products add column if not exists category text;
alter table public.products add column if not exists purchase_price numeric(12,2) not null default 0;
alter table public.products add column if not exists retail_price numeric(12,2) not null default 0;
alter table public.products add column if not exists wholesale_price numeric(12,2) not null default 0;
alter table public.products add column if not exists quantity integer not null default 0;
alter table public.products add column if not exists minimum_quantity integer not null default 2;
alter table public.products add column if not exists is_active boolean not null default true;
alter table public.products add column if not exists updated_at timestamptz not null default now();

alter table public.sales add column if not exists invoice_number text;
alter table public.sales add column if not exists customer_id uuid;
alter table public.sales add column if not exists customer_name text;
alter table public.sales add column if not exists payment_type text default 'cash';

-- If your previous setup used invoice_number as NOT NULL, existing rows already have it.
-- Make sure new invoices have a unique number.
create unique index if not exists sales_invoice_number_unique_idx on public.sales(invoice_number);

create table if not exists public.sale_items (
 id uuid primary key default gen_random_uuid(),
 sale_id uuid not null references public.sales(id) on delete cascade,
 product_id uuid references public.products(id) on delete set null,
 product_name text not null,
 quantity integer not null check(quantity>0),
 unit_price numeric(12,2) not null default 0,
 purchase_price numeric(12,2) not null default 0,
 total numeric(12,2) not null default 0,
 profit numeric(12,2) not null default 0,
 created_at timestamptz not null default now()
);

alter table public.sale_items enable row level security;
drop policy if exists "authenticated_sale_items" on public.sale_items;
create policy "authenticated_sale_items" on public.sale_items for all to authenticated using (true) with check (true);
grant select,insert,update,delete on public.sale_items to authenticated;

grant select,insert,update,delete on public.products to authenticated;
grant select,insert,update,delete on public.sales to authenticated;
grant select,insert,update,delete on public.customers to authenticated;

alter publication supabase_realtime add table public.products;
alter publication supabase_realtime add table public.sales;
alter publication supabase_realtime add table public.customers;
alter publication supabase_realtime add table public.sale_items;

-- The final app uses real Supabase Auth with:
-- username: ali
-- email: ali@royalphone.local
-- password: 123123
-- Create/confirm that user from Authentication > Users.
