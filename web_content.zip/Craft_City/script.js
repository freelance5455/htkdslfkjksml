import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js";

const $ = id => document.getElementById(id);
const loading = $("loading"), loadingText = $("loadingText");
const game = $("game"), startScreen = $("startScreen"), startBtn = $("startBtn");
const gameUI = $("gameUI"), pauseScreen = $("pauseScreen");
const message = $("message"), coordinates = $("coordinates");

let scene, camera, renderer, ready = false, running = false, paused = false;
let lastTime = 0, messageTimer;
const player = {x:0,y:0,z:0,yaw:0,pitch:-0.12,vy:0,onGround:false};
const blocks = new Map(), meshes = [];
const materials = {};
const types = {grass:0x65b94d,dirt:0x875532,stone:0x92999d,wood:0x96602f,sand:0xe8d28a};
let selected = "grass", target = null, normal = null;
const keys = {}, held = {forward:false,backward:false,left:false,right:false,jump:false};
const ray = new THREE.Raycaster(); ray.far = 6;
const center = new THREE.Vector2(0,0);
let lookId = null, lastX = 0, lastY = 0;

function key(x,y,z){return `${x},${y},${z}`;}
function terrain(x,z){
  const d = Math.hypot(x,z);
  if(d < 4) return 4;
  return Math.max(2,Math.min(8,Math.floor(4+Math.sin(x*.23)*1.5+Math.cos(z*.19)*1.2+Math.sin((x+z)*.13)*1.1)));
}
function ground(x,z){return terrain(Math.round(x),Math.round(z))+0.5;}
function has(x,y,z){return blocks.has(key(Math.round(x),Math.round(y),Math.round(z)));}

function addBlock(x,y,z,type){
  x=Math.round(x); y=Math.round(y); z=Math.round(z);
  const k=key(x,y,z);
  if(blocks.has(k)) return false;
  const mesh=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),materials[type]||materials.grass);
  mesh.position.set(x,y,z); mesh.userData={x,y,z,type,k};
  scene.add(mesh); blocks.set(k,mesh); meshes.push(mesh); return true;
}
function removeBlock(mesh){
  if(!mesh) return;
  scene.remove(mesh); blocks.delete(mesh.userData.k);
  const i=meshes.indexOf(mesh); if(i>=0) meshes.splice(i,1);
  mesh.geometry.dispose();
}
function makeWorld(){
  for(let x=-22;x<=22;x++) for(let z=-22;z<=22;z++){
    const h=terrain(x,z);
    for(let y=0;y<=h;y++){
      let type="stone";
      if(y===h) type=h<=2?"sand":"grass";
      else if(y>=h-2) type="dirt";
      addBlock(x,y,z,type);
    }
  }
  // أشجار صغيرة
  for(let x=-20;x<=20;x+=5) for(let z=-20;z<=20;z+=6){
    if(Math.random()>.58 || (Math.abs(x)<5&&Math.abs(z)<5)) continue;
    const h=terrain(x,z); if(h<=2) continue;
    const trunk=3+Math.floor(Math.random()*2);
    for(let y=1;y<=trunk;y++) addBlock(x,h+y,z,"wood");
    for(let ox=-2;ox<=2;ox++) for(let oz=-2;oz<=2;oz++) for(let oy=trunk-1;oy<=trunk+1;oy++){
      if(Math.abs(ox)+Math.abs(oz)+Math.abs(oy-trunk)>4) continue;
      if(!has(x+ox,h+oy,z+oz)) addBlock(x+ox,h+oy,z+oz,"grass");
    }
  }
}
function init(){
  scene=new THREE.Scene();
  scene.background=new THREE.Color(0x87ceeb);
  scene.fog=new THREE.Fog(0x87ceeb,30,78);
  camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.1,120);
  camera.rotation.order="YXZ";
  renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:"high-performance"});
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5));
  renderer.setSize(innerWidth,innerHeight);
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  game.insertBefore(renderer.domElement,game.firstChild);
  scene.add(new THREE.HemisphereLight(0xffffff,0x59634a,2));
  const sun=new THREE.DirectionalLight(0xffffff,2); sun.position.set(20,35,15); scene.add(sun);
  for(const [name,color] of Object.entries(types)) materials[name]=new THREE.MeshLambertMaterial({color});
  makeWorld();
  const water=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshLambertMaterial({color:0x359fe0,transparent:true,opacity:.72}));
  water.rotation.x=-Math.PI/2; water.position.y=1.2; scene.add(water);
  player.x=0; player.z=0; player.y=ground(0,0)+1.7;
  updateCamera(); bindControls(); ready=true;
  $("worldInfo").classList.remove("hidden");
  loading.classList.add("hidden");
  updateHotbar(); updateCoordinates();
  requestAnimationFrame(animate);
}
function updateCamera(){
  camera.position.set(player.x,player.y,player.z);
  camera.rotation.order="YXZ"; camera.rotation.y=player.yaw; camera.rotation.x=player.pitch;
}
function findTarget(){
  ray.setFromCamera(center,camera);
  const hits=ray.intersectObjects(meshes,false);
  target=hits.length?hits[0].object:null;
  normal=hits.length&&hits[0].face?hits[0].face.normal.clone():null;
}
function say(text){
  message.textContent=text; message.classList.remove("hidden");
  clearTimeout(messageTimer); messageTimer=setTimeout(()=>message.classList.add("hidden"),1800);
}
function breakBlock(){
  if(!running||paused)return;
  findTarget();
  if(!target){say("وجّه علامة التصويب نحو مكعب");return;}
  removeBlock(target); target=null; say("تم تكسير المكعب");
}
function placeBlock(){
  if(!running||paused)return;
  findTarget();
  if(!target||!normal){say("وجّه التصويب نحو مكعب قريب");return;}
  const b=target.position, x=Math.round(b.x+normal.x), y=Math.round(b.y+normal.y), z=Math.round(b.z+normal.z);
  if(Math.abs(x-player.x)<.8&&Math.abs(z-player.z)<.8&&y>=player.y-1.7&&y<=player.y+.3){say("لا تضع مكعبًا داخل اللاعب");return;}
  say(addBlock(x,y,z,selected)?"تم وضع المكعب":"المكان مشغول");
}
function blocked(x,z,feet){
  // فحص جوانب اللاعب ضد المكعبات القريبة
  for(let bx=Math.floor(x)-1;bx<=Math.floor(x)+1;bx++)
    for(let bz=Math.floor(z)-1;bz<=Math.floor(z)+1;bz++)
      for(let by=Math.floor(feet);by<=Math.floor(feet+1.65);by++)
        if(has(bx,by,bz)&&Math.abs(bx-x)<.8&&Math.abs(bz-z)<.8&&feet+1.7>by-.5&&feet<by+.5)return true;
  return false;
}
function move(dt){
  let f=0,s=0;
  if(keys.KeyW||keys.ArrowUp||held.forward)f++;
  if(keys.KeyS||keys.ArrowDown||held.backward)f--;
  if(keys.KeyA||keys.ArrowLeft||held.left)s--;
  if(keys.KeyD||keys.ArrowRight||held.right)s++;
  const len=Math.hypot(f,s);
  if(len){f/=len;s/=len;const speed=5.2*dt;
    const dx=(-Math.sin(player.yaw)*f+Math.cos(player.yaw)*s)*speed;
    const dz=(-Math.cos(player.yaw)*f-Math.sin(player.yaw)*s)*speed;
    if(!blocked(player.x+dx,player.z,player.y-1.7))player.x+=dx;
    if(!blocked(player.x,player.z+dz,player.y-1.7))player.z+=dz;
  }
  if((keys.Space||held.jump)&&player.onGround){player.vy=7.3;player.onGround=false;}
  player.vy-=20*dt;
  const next=player.y+player.vy*dt;
  const floor=ground(player.x,player.z)+1.7;
  if(next<=floor){player.y=floor;player.vy=0;player.onGround=true;}
  else {player.y=next;player.onGround=false;}
  if(player.y< -8){player.x=0;player.z=0;player.y=ground(0,0)+1.7;player.vy=0;}
  updateCamera(); updateCoordinates();
}
function updateCoordinates(){coordinates.textContent=`X: ${Math.floor(player.x)} | Y: ${Math.floor(player.y)} | Z: ${Math.floor(player.z)}`;}
function updateHotbar(){document.querySelectorAll(".slot").forEach(b=>b.classList.toggle("selected",b.dataset.block===selected));}
function bindHold(id,prop){
  const el=$(id); if(!el)return;
  const down=e=>{e.preventDefault();held[prop]=true;};
  const up=e=>{e.preventDefault();held[prop]=false;};
  el.addEventListener("pointerdown",down); el.addEventListener("pointerup",up);
  el.addEventListener("pointercancel",up); el.addEventListener("pointerleave",up);
}
function bindControls(){
  bindHold("forward","forward");bindHold("backward","backward");bindHold("left","left");bindHold("right","right");bindHold("jumpBtn","jump");
  $("breakBtn").addEventListener("click",breakBlock);$("placeBtn").addEventListener("click",placeBlock);
  $("menuBtn").addEventListener("click",pauseGame);$("resumeBtn").addEventListener("click",resumeGame);$("homeBtn").addEventListener("click",home);
  document.querySelectorAll(".slot").forEach(b=>b.addEventListener("click",()=>{selected=b.dataset.block;updateHotbar();say("تم اختيار البلوك");}));
  addEventListener("keydown",e=>{keys[e.code]=true;if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code))e.preventDefault();if(e.code==="Escape")paused?resumeGame():pauseGame();if(e.code==="KeyQ")breakBlock();if(e.code==="KeyE")placeBlock();});
  addEventListener("keyup",e=>keys[e.code]=false);
  renderer.domElement.addEventListener("pointerdown",e=>{if(!running||paused)return;lookId=e.pointerId;lastX=e.clientX;lastY=e.clientY;renderer.domElement.setPointerCapture?.(e.pointerId);});
  renderer.domElement.addEventListener("pointermove",e=>{if(lookId!==e.pointerId||!running||paused)return;player.yaw-=(e.clientX-lastX)*.006;player.pitch-=(e.clientY-lastY)*.005;lastX=e.clientX;lastY=e.clientY;player.pitch=THREE.MathUtils.clamp(player.pitch,-1.5,1.5);updateCamera();});
  const end=e=>{if(lookId===e.pointerId)lookId=null;};
  renderer.domElement.addEventListener("pointerup",end);renderer.domElement.addEventListener("pointercancel",end);
  addEventListener("resize",()=>{if(!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
}
function startGame(){
  if(!ready){
    loading.classList.remove("hidden");loadingText.textContent="جاري إنشاء العالم...";
    // نترك المتصفح يرسم شاشة التحميل قبل توليد العالم
    setTimeout(()=>{
      try{init();enterGame();}
      catch(err){console.error(err);loading.classList.remove("hidden");loadingText.textContent="فشل تشغيل اللعبة. تأكد من الإنترنت وافتح Console إذا استمرت المشكلة.";}
    },50);
  }else enterGame();
}
function enterGame(){running=true;paused=false;startScreen.classList.add("hidden");pauseScreen.classList.add("hidden");gameUI.classList.remove("hidden");say("اسحب الشاشة للنظر واستخدم الأسهم للحركة");}
function pauseGame(){if(!running)return;paused=true;pauseScreen.classList.remove("hidden");}
function resumeGame(){paused=false;pauseScreen.classList.add("hidden");}
function home(){running=false;paused=false;pauseScreen.classList.add("hidden");gameUI.classList.add("hidden");startScreen.classList.remove("hidden");}
function animate(t){
  requestAnimationFrame(animate);
  const dt=Math.min((t-lastTime)/1000||0,.05);lastTime=t;
  if(running&&!paused){move(dt);findTarget();}
  if(renderer)renderer.render(scene,camera);
}
startBtn.addEventListener("click",startGame);
window.addEventListener("error",e=>{console.error(e.message);});
window.addEventListener("unhandledrejection",e=>{console.error(e.reason);loading.classList.remove("hidden");loadingText.textContent="مشكلة في تحميل محرك اللعبة. تأكد من اتصال الإنترنت وافتح الصفحة في Chrome.";});
