NOVA AI - UPDATED ANDROID PROJECT SOURCE

Package: com.nova.ai
Minimum SDK: 26
Compile SDK: 34
Android Gradle Plugin: 8.5.2
Kotlin: 1.9.24

CHANGES IN THIS REVISION
- Updated Gemini text model IDs to gemini-3.8-flash with gemini-3.6-flash fallback.
- Sends Gemini API key using x-goog-api-key header (not URL query string).
- Settings now tests the supplied API key against Gemini before saving it.
- Android WebView now grants only requested microphone/camera resources after Android runtime permission is present.
- Voice capture uses Android SpeechRecognizer; after NOVA answers with Android TextToSpeech, it resumes listening while Live mode remains on.
- TextToSpeech attempts to select a female-named Bengali/English voice when the device has one installed. Actual voice/gender depends on the phone's installed TTS voices.
- Added common app launch shortcuts (Chrome, Photos, Calculator, Clock, Contacts, Messages, Spotify, etc.).
- Call command opens the dialer for user confirmation; it does not place calls silently.

IMPORTANT LIMITATIONS
- This is Android source code, not a prebuilt APK. It still needs an Android Gradle build environment/service to compile and sign an APK.
- No build was run in this environment because Gradle/Android SDK are unavailable here. The project has not been device-tested.
- Continuous voice recognition depends on the phone's speech recognition service and microphone permission. Select Bengali or English in Settings before voice use; automatic language detection is not guaranteed.
- Female voice is best-effort and depends on a female Bengali/English voice being installed in Android Text-to-Speech settings.
- NOVA can open supported installed apps and use explicit Android intents. It cannot freely operate every app, bypass lock screens, send messages/calls without confirmation, or control the phone without Android permissions/user consent.
- Screen sharing via WebView getDisplayMedia may not be supported on all Android WebView versions; full screen capture needs a native MediaProjection flow.
- Camera preview requires camera permission and a compatible WebView implementation.

BUILD SETTINGS
Open the folder NOVA_Android_Project in an Android Gradle-compatible builder.
Use JDK 17 and Android SDK 34. Build the app module's debug APK for local testing.
