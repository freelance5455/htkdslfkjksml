package com.nova.aihub

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.pm.PackageManager
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import android.app.AlertDialog
import android.widget.FrameLayout
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import androidx.compose.ui.platform.LocalConfiguration

data class DeviceApp(val name: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

@Composable
fun NovaApp() {
    val context = LocalContext.current
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val bg = if (dark) Color(0xFF0B1220) else Color(0xFFF2F5FA)
    val surface = if (dark) Color(0xFF172235) else Color.White
    val ink = if (dark) Color(0xFFF3F6FC) else Color(0xFF172033)
    var showApps by remember { mutableStateOf(false) }
    var appQuery by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf(emptyList<DeviceApp>()) }
    var appError by remember { mutableStateOf<String?>(null) }
    val config = LocalConfiguration.current
    val wide = config.screenWidthDp >= 700

    fun loadApps() {
        try {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
            apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .mapNotNull { info ->
                    val pkg = info.activityInfo.packageName
                    if (pkg == context.packageName) null
                    else DeviceApp(info.loadLabel(pm).toString(), pkg, info.loadIcon(pm))
                }
                .distinctBy { it.packageName }
                .sortedBy { it.name.lowercase() }
            appError = if (apps.isEmpty()) "لم يعثر أندرويد على تطبيقات قابلة للتشغيل." else null
        } catch (e: Exception) {
            appError = "تعذر قراءة قائمة التطبيقات: ${e.localizedMessage ?: "خطأ غير معروف"}"
        }
    }

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = Color(0xFF79A7FF), background = bg, surface = surface, onSurface = ink
        ) else lightColorScheme(
            primary = Color(0xFF245EEA), background = bg, surface = surface, onSurface = ink
        )
    ) {
        Column(Modifier.fillMaxSize().background(bg)) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Color(0xFF101827))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text("NOVA AI HUB", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("مركزك الذكي للتطبيقات والبحث", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { loadApps(); showApps = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Apps, null)
                        Spacer(Modifier.width(6.dp))
                        Text("تطبيقاتي المثبتة")
                    }
                    OutlinedButton(
                        onClick = { showApps = false },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF64748B))
                    ) { Icon(Icons.Default.Home, null); Spacer(Modifier.width(5.dp)); Text("الرئيسية") }
                }
            }

            if (showApps) {
                Column(Modifier.weight(1f).padding(14.dp)) {
                    Text("التطبيقات القابلة للتشغيل", color = ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("تظهر التطبيقات التي يسمح أندرويد للتطبيق برؤيتها.", color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = appQuery, onValueChange = { appQuery = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("ابحث عن تطبيق") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }
                    )
                    Spacer(Modifier.height(8.dp))
                    appError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(apps.filter { it.name.contains(appQuery, true) || it.packageName.contains(appQuery, true) }) { app ->
                            Surface(color = surface, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    Modifier.fillMaxWidth().clickable {
                                        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
                                        if (launch != null) {
                                            AlertDialog.Builder(context)
                                                .setTitle("فتح ${app.name}؟")
                                                .setMessage("سيتم الانتقال إلى تطبيق آخر. هل توافق؟")
                                                .setNegativeButton("إلغاء", null)
                                                .setPositiveButton("موافق") { _, _ -> context.startActivity(launch) }
                                                .show()
                                        }
                                    }.padding(11.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AndroidAppIcon(app.icon)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(app.name, color = ink, fontWeight = FontWeight.SemiBold)
                                        Text(app.packageName, color = Color.Gray, fontSize = 10.sp)
                                    }
                                    Icon(Icons.Default.OpenInNew, null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            } else {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(10.dp)) {
                    Text(
                        if (wide) "مساحة العمل المزدوجة" else "مساحة العمل",
                        color = ink, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 5.dp)
                    )
                    Text(
                        "تستضيف واجهة NOVA الأصلية. يمكن أن تمنع بعض المواقع العرض داخل الإطار.",
                        color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 5.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    if (wide) {
                        Row(Modifier.fillMaxWidth().height(680.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NovaWebPane(Modifier.weight(1f).fillMaxHeight())
                            NovaWebPane(Modifier.weight(1f).fillMaxHeight())
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            NovaWebPane(Modifier.fillMaxWidth().height(560.dp))
                            NovaWebPane(Modifier.fillMaxWidth().height(560.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AndroidAppIcon(drawable: android.graphics.drawable.Drawable) {
    AndroidView(
        factory = { ctx -> android.widget.ImageView(ctx).apply { setImageDrawable(drawable); scaleType = android.widget.ImageView.ScaleType.FIT_CENTER } },
        modifier = Modifier.size(38.dp)
    )
}

@Composable
fun NovaWebPane(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val webView = remember {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            settings.mediaPlaybackRequiresUserGesture = true
            webChromeClient = object : WebChromeClient() {
                override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                    AlertDialog.Builder(context).setMessage(message ?: "")
                        .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                        .setOnCancelListener { result?.cancel() }.show()
                    return true
                }
                override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                    AlertDialog.Builder(context).setTitle("تأكيد الانتقال")
                        .setMessage(message ?: "هل تريد المتابعة؟")
                        .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }
                        .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                        .setOnCancelListener { result?.cancel() }.show()
                    return true
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (!request.isForMainFrame) return false
                    val uri = request.url
                    val host = uri.host.orEmpty()
                    val internalHosts = setOf("www.google.com", "google.com", "www.youtube.com", "youtube.com")
                    if (uri.scheme == "https" && host in internalHosts) return false
                    if (uri.scheme == "https" || uri.scheme == "http") {
                        AlertDialog.Builder(context).setTitle("فتح رابط خارجي؟")
                            .setMessage("هل توافق على فتح هذا الرابط خارج مساحة NOVA؟\n$uri")
                            .setNegativeButton("إلغاء", null)
                            .setPositiveButton("موافق") { _, _ ->
                                try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                            }.show()
                        return true
                    }
                    return true
                }
            }
            loadUrl("file:///android_asset/nova_ai_hub.html")
        }
    }
    DisposableEffect(webView) { onDispose { webView.stopLoading(); webView.destroy() } }
    AndroidView(factory = { webView }, modifier = modifier)
}
