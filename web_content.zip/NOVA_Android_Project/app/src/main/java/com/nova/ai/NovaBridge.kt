package com.nova.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.provider.Settings
import android.widget.Toast
import java.util.Locale

class NovaBridge(private val activity: Activity) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    @Volatile private var listening = false
    @Volatile private var recognitionLanguage = "bn-BD"

    init {
        tts = TextToSpeech(activity) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                val voices = tts?.voices.orEmpty()
                val bengali = voices.filter { it.locale.language.equals("bn", true) }
                val preferred = bengali.firstOrNull { it.name.contains("female", true) }
                    ?: bengali.firstOrNull()
                if (preferred != null) tts?.voice = preferred
                tts?.setLanguage(Locale("bn", "BD"))
                tts?.setPitch(1.08f)
                tts?.setSpeechRate(0.96f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = notifyJs("onSpeechStarted")
                    override fun onDone(utteranceId: String?) = notifyJs("onSpeechFinished")
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = notifyJs("onSpeechFinished")
                })
            }
        }
    }

    private fun notifyJs(function: String, value: String? = null) {
        activity.runOnUiThread {
            val w = activity.findViewById<WebView>(R.id.webView) ?: return@runOnUiThread
            val js = if (value == null) "window.$function && window.$function()" else
                "window.$function && window.$function(${org.json.JSONObject.quote(value)})"
            w.evaluateJavascript(js, null)
        }
    }

    @JavascriptInterface fun speakText(text: String) {
        activity.runOnUiThread {
            if (!ttsReady) {
                Toast.makeText(activity, "ফোনের Text-to-Speech প্রস্তুত হচ্ছে", Toast.LENGTH_SHORT).show()
                return@runOnUiThread
            }
            val englishText = text.count { it in 'A'..'Z' || it in 'a'..'z' } > text.count { it in '\u0980'..'\u09FF' }
            val desiredLang = if (englishText) Locale.US else Locale("bn", "BD")
            val voices = tts?.voices.orEmpty().filter { it.locale.language == desiredLang.language }
            val female = voices.firstOrNull { it.name.contains("female", true) }
            if (female != null) tts?.voice = female
            tts?.setLanguage(desiredLang)
            tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "nova-${System.currentTimeMillis()}")
        }
    }

    @JavascriptInterface fun stopSpeaking() { activity.runOnUiThread { tts?.stop() } }

    @JavascriptInterface fun openCamera() {
        runCatching { activity.startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)) }
            .onFailure { toast("ক্যামেরা খোলা যায়নি") }
    }

    @JavascriptInterface fun openSettings() { runCatching { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) } }

    @JavascriptInterface fun dial(number: String) {
        val safe = number.filter { it.isDigit() || it == '+' }
        if (safe.isNotBlank()) runCatching { activity.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$safe"))) }
    }

    @JavascriptInterface fun openUrl(url: String) {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return
        if (uri.scheme !in setOf("https", "http", "geo", "market")) return
        runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, uri)) }.onFailure { toast("লিংক খোলা যায়নি") }
    }

    @JavascriptInterface fun openApp(packageName: String) {
        if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return
        runCatching {
            val launch = activity.packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) activity.startActivity(launch) else toast("অ্যাপটি ইনস্টল করা নেই")
        }.onFailure { toast("অ্যাপ খোলা যায়নি") }
    }

    @JavascriptInterface fun setRecognitionLanguage(language: String) {
        recognitionLanguage = if (language == "en-US") "en-US" else "bn-BD"
    }

    @JavascriptInterface fun startListening() {
        activity.runOnUiThread {
            if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
                toast("ফোনে Speech Recognition সার্ভিস নেই")
                notifyJs("onVoiceError", "unavailable")
                return@runOnUiThread
            }
            listening = true
            startRecognizer()
        }
    }

    private fun startRecognizer() {
        if (!listening) return
        runCatching { recognizer?.destroy() }
        recognizer = SpeechRecognizer.createSpeechRecognizer(activity)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { notifyJs("onListeningReady") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (listening) activity.window.decorView.postDelayed({ if (listening) startRecognizer() }, 650)
                else notifyJs("onVoiceError", error.toString())
            }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (words.isNotBlank()) notifyJs("onVoiceResult", words)
                // The page pauses listening while NOVA answers, then explicitly starts it again.
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val words = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (words.isNotBlank()) notifyJs("onVoicePartial", words)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionLanguage)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, recognitionLanguage)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, activity.packageName)
        }
        recognizer?.startListening(intent)
    }

    @JavascriptInterface fun stopListening() {
        listening = false
        activity.runOnUiThread { recognizer?.stopListening(); recognizer?.cancel(); recognizer?.destroy(); recognizer = null }
    }

    @JavascriptInterface fun resumeListening() {
        activity.runOnUiThread { if (listening) startRecognizer() }
    }

    fun shutdown() {
        listening = false
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }

    private fun toast(message: String) = activity.runOnUiThread { Toast.makeText(activity, message, Toast.LENGTH_SHORT).show() }
}
