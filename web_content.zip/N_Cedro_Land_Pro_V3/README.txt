N-CEDRO LAND PRO V3 — prototype de test

Ceci est un prototype HTML, PAS un APK Android.

Sur un téléphone Android : extrayez le ZIP puis ouvrez index.html dans un navigateur. Pour que la géolocalisation fonctionne, le navigateur peut exiger une ouverture dans un contexte sécurisé; si le GPS ne fonctionne pas depuis un fichier local, il faudra intégrer ce formulaire dans une vraie application Android/WebView avec permission Location.

V3: catégories demandées, voisins par noms seulement, date d’inspection, capture GPS et conversion UTM Zone 35S, numérotation globale des points et option pour afficher/cacher les numéros. Les données sont enregistrées dans le stockage local du navigateur. Ce prototype ne constitue pas encore une application Android installable, ni une exportation GeoPackage/PDF/QGIS complète.
