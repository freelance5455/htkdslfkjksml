THE HOLLOW CROWN — CHAPTER I PLAYABLE PROTOTYPE

Files:
- index.html: complete self-contained game prototype. No external libraries or internet connection required.

Run on Android:
1. Extract THE_HOLLOW_CROWN_CH1.zip.
2. Open index.html in a modern browser (Chrome recommended).
3. Rotate phone to landscape.
4. Tap BEGIN JOURNEY.

Controls:
- Touch: left virtual joystick; ATTACK, HEAVY, DODGE, PARRY, HEAL buttons.
- Keyboard (desktop testing): A/D or arrows move, J attack, K heavy attack, Space dodge, L parry, H heal.

Prototype contents:
- 1920x1080 internal canvas, landscape responsive display
- Original dark medieval visual treatment drawn in Canvas
- Kael player character
- stamina, health, dodge invulnerability, parry, healing flasks
- three enemy encounters and a boss encounter
- checkpoint, boss health bar, victory/death states
- offline, self-contained HTML

Important:
This is the first playable vertical-slice prototype, not the full five-chapter game.
It uses procedural placeholder art drawn in code; polished hand-painted sprite sheets,
proper frame-by-frame animations, authored level art, sound, menus, save slots and
expanded story content are planned production tasks.
