/* تطبيقات مدمجة إضافية لمتجر m1li — كل تطبيق يشتغل فـ iframe معزول */
var EXTRA_APPS = (function () {
  var CSS = 'body{margin:0;font-family:Tahoma,Arial,sans-serif;background:#0f172a;color:#f1f5f9;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;gap:12px;text-align:center;padding:16px;box-sizing:border-box}' +
    'button{border:0;border-radius:14px;background:#6366f1;color:#fff;font-size:17px;padding:12px 22px;cursor:pointer;font-family:inherit}button:active{transform:scale(.96)}button.g{background:#334155}' +
    'input,select,textarea{padding:11px;border-radius:10px;border:1px solid #475569;background:#1e293b;color:#fff;font-size:16px;font-family:inherit;box-sizing:border-box;max-width:100%}' +
    'input[type=number],input[type=text]{width:200px;text-align:center}h1,h2,h3,p{margin:0}.row{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;align-items:center}.big{font-size:56px;font-weight:800}.mut{color:#94a3b8;font-size:14px}' +
    '.card{background:#1e293b;border:1px solid #334155;border-radius:14px;padding:12px 16px}';
  function mk(body, script) {
    return '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>' + CSS + '</style></head><body>' + body +
      '<scr' + 'ipt>function $(i){return document.getElementById(i)}function S(k,v){try{if(v===undefined){return JSON.parse(localStorage.getItem(k))}localStorage.setItem(k,JSON.stringify(v))}catch(e){return null}}' + script + '<\/scr' + 'ipt></body></html>';
  }
  function app(id, title, category, icon, desc, body, script) {
    return { id: 'b_' + id, builtin: true, title: title, category: category, icon: icon, desc: desc, type: 'code', code: mk(body, script) };
  }
  var A = [];

  /* ===== ألعاب ===== */
  A.push(app('memory', 'لعبة الذاكرة', 'games', '🧠', 'اقلب البطاقات ولقى الأزواج المتشابهة بأقل عدد من المحاولات.',
    `<h2>🧠 لعبة الذاكرة</h2><p class="mut">محاولات: <b id="m">0</b></p><div id="g" style="display:grid;grid-template-columns:repeat(4,64px);gap:8px"></div><button id="r">لعبة جديدة</button><p id="w" style="color:#34d399;font-weight:700"></p>`,
    `var E=['🍎','🚀','🎧','🐱','⚽','🌙','🍕','🔥'],f=[],lock=false,mv=0,done=0;
function init(){var a=E.concat(E).sort(function(){return Math.random()-.5});f=[];mv=0;done=0;lock=false;$('m').textContent=0;$('w').textContent='';var g=$('g');g.innerHTML='';
a.forEach(function(v){var b=document.createElement('button');b.style.cssText='height:64px;font-size:28px;padding:0;background:#334155';b.dataset.v=v;b.onclick=function(){flip(b)};g.appendChild(b)})}
function flip(b){if(lock||b.dataset.on||f.indexOf(b)>-1)return;b.textContent=b.dataset.v;b.style.background='#6366f1';f.push(b);
if(f.length==2){mv++;$('m').textContent=mv;if(f[0].dataset.v==f[1].dataset.v){f.forEach(function(x){x.dataset.on=1;x.style.background='#059669'});f=[];done++;if(done==8)$('w').textContent='🎉 ربحتي ف '+mv+' محاولة!'}
else{lock=true;setTimeout(function(){f.forEach(function(x){x.textContent='';x.style.background='#334155'});f=[];lock=false},700)}}}
$('r').onclick=init;init();`));

  A.push(app('snake', 'لعبة الأفعى', 'games', '🐍', 'الأفعى الكلاسيكية: كُل التفاح وكبّر ولا تضرب الحيط. تدعم اللمس والأسهم.',
    `<h2>🐍 الأفعى</h2><p class="mut">النتيجة: <b id="s">0</b></p><canvas id="c" width="300" height="300" style="background:#020617;border:2px solid #334155;border-radius:12px;max-width:92vw"></canvas>
<div class="row"><button class="g" onclick="d(0,-1)">⬆️</button></div><div class="row"><button class="g" onclick="d(-1,0)">⬅️</button><button class="g" onclick="d(0,1)">⬇️</button><button class="g" onclick="d(1,0)">➡️</button></div><button id="r">ابدأ</button>`,
    `var c=$('c'),x=c.getContext('2d'),N=15,Z=20,sn,dx,dy,ap,sc,iv;
function start(){sn=[{x:7,y:7}];dx=1;dy=0;sc=0;$('s').textContent=0;place();clearInterval(iv);iv=setInterval(tick,140)}
function place(){ap={x:Math.floor(Math.random()*N),y:Math.floor(Math.random()*N)}}
function d(a,b){if(a==-dx&&b==-dy&&sn.length>1)return;dx=a;dy=b}
function tick(){var h={x:sn[0].x+dx,y:sn[0].y+dy};if(h.x<0||h.y<0||h.x>=N||h.y>=N||sn.some(function(p){return p.x==h.x&&p.y==h.y})){clearInterval(iv);x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,300,300);x.fillStyle='#fff';x.font='24px Tahoma';x.textAlign='center';x.fillText('انتهت: '+sc,150,150);return}
sn.unshift(h);if(h.x==ap.x&&h.y==ap.y){sc++;$('s').textContent=sc;place()}else sn.pop();
x.fillStyle='#020617';x.fillRect(0,0,300,300);x.fillStyle='#ef4444';x.fillRect(ap.x*Z,ap.y*Z,Z-2,Z-2);sn.forEach(function(p,i){x.fillStyle=i?'#34d399':'#a7f3d0';x.fillRect(p.x*Z,p.y*Z,Z-2,Z-2)})}
document.onkeydown=function(e){var k={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0]}[e.key];if(k){d(k[0],k[1]);e.preventDefault()}};
$('r').onclick=start;start();`));

  A.push(app('guess', 'خمّن الرقم', 'games', '🔢', 'الكمبيوتر كيختار رقم بين 1 و100 وأنت كتخمّن بأقل محاولات.',
    `<h2>🔢 خمّن الرقم (1 - 100)</h2><input id="i" type="number" min="1" max="100" placeholder="؟"><button id="b">تأكيد</button><p id="m" style="font-size:20px;min-height:28px"></p><p class="mut">المحاولات: <b id="t">0</b></p><button class="g" id="r">من جديد</button>`,
    `var n,t;function init(){n=Math.floor(Math.random()*100)+1;t=0;$('t').textContent=0;$('m').textContent='';$('i').value=''}
$('b').onclick=function(){var v=+$('i').value;if(!v||v<1||v>100){$('m').textContent='دخّل رقم من 1 ل100';return}t++;$('t').textContent=t;
$('m').textContent=v==n?'🎉 برافو! الرقم هو '+n:(v<n?'⬆️ كبر شوية':'⬇️ نقص شوية')};$('r').onclick=init;init();`));

  A.push(app('rps', 'حجر ورقة مقص', 'games', '✊', 'العب ضد الكمبيوتر وشوف شكون كيربح أكثر.',
    `<h2>✊ حجر · ورقة · مقص</h2><div class="row" style="font-size:56px" id="v">🤖 ❓</div><div class="row"><button onclick="p(0)">✊</button><button onclick="p(1)">✋</button><button onclick="p(2)">✌️</button></div><p id="m" style="font-size:20px;min-height:28px"></p><p class="mut">أنا <b id="a">0</b> — الكمبيوتر <b id="b">0</b></p>`,
    `var E=['✊','✋','✌️'],a=0,b=0;function p(u){var c=Math.floor(Math.random()*3);$('v').textContent='🤖 '+E[c]+'  |  أنت '+E[u];
if(u==c)$('m').textContent='تعادل 🤝';else if((u+1)%3==c){b++;$('m').textContent='خسرتي 😅'}else{a++;$('m').textContent='ربحتي 🎉'}$('a').textContent=a;$('b').textContent=b}`));

  A.push(app('react', 'اختبار ردة الفعل', 'games', '⚡', 'شحال سرعتك؟ انقر ملي تولي الشاشة خضراء وشوف وقتك بالملي ثانية.',
    `<h2>⚡ اختبار ردة الفعل</h2><div id="z" style="width:min(90vw,320px);height:200px;border-radius:20px;background:#334155;display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer;user-select:none">اضغط للبدء</div><p class="mut">أحسن وقت: <b id="bt">—</b></p>`,
    `var st=0,t0,to,best=null;var z=$('z');z.onclick=function(){
if(st==0){st=1;z.style.background='#b91c1c';z.textContent='تسنى حتى تولي خضراء...';to=setTimeout(function(){st=2;t0=Date.now();z.style.background='#059669';z.textContent='دابا! انقر'},1000+Math.random()*2500)}
else if(st==1){clearTimeout(to);st=0;z.style.background='#334155';z.textContent='بكري! اضغط للمحاولة من جديد'}
else{var ms=Date.now()-t0;st=0;z.style.background='#4f46e5';z.textContent=ms+' ms — اضغط من جديد';if(best===null||ms<best){best=ms;$('bt').textContent=ms+' ms'}}}`));

  A.push(app('xo', 'إكس أو', 'games', '❌', 'لعبة إكس أو ضد الكمبيوتر (اللي كيحاول يغلبك!).',
    `<h2>❌⭕ إكس أو</h2><div id="g" style="display:grid;grid-template-columns:repeat(3,86px);gap:8px"></div><p id="m" style="font-size:20px;min-height:28px"></p><button id="r">من جديد</button>`,
    `var B,over,L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
function win(b,p){return L.some(function(l){return l.every(function(i){return b[i]==p})})}
function draw(){var g=$('g');g.innerHTML='';B.forEach(function(v,i){var b=document.createElement('button');b.style.cssText='height:86px;font-size:40px;background:#1e293b;border:1px solid #475569';b.textContent=v||'';b.onclick=function(){go(i)};g.appendChild(b)})}
function init(){B=Array(9).fill(null);over=false;$('m').textContent='';draw()}
function end(){if(win(B,'X')){$('m').textContent='🎉 ربحتي!';over=true}else if(win(B,'O')){$('m').textContent='🤖 الكمبيوتر ربح';over=true}else if(B.every(Boolean)){$('m').textContent='تعادل 🤝';over=true}}
function best(){var i,f=function(p){for(i=0;i<9;i++){if(!B[i]){B[i]=p;var w=win(B,p);B[i]=null;if(w)return i}}return -1};
var m=f('O');if(m<0)m=f('X');if(m<0&&!B[4])m=4;if(m<0){var e=[];B.forEach(function(v,k){if(!v)e.push(k)});m=e[Math.floor(Math.random()*e.length)]}return m}
function go(i){if(over||B[i])return;B[i]='X';end();if(!over){B[best()]='O';end()}draw()}
$('r').onclick=init;init();`));

  /* ===== أدوات ===== */
  A.push(app('conv', 'محوّل الوحدات', 'tools', '📏', 'حوّل بين الطول والوزن والحرارة بسهولة.',
    `<h2>📏 محوّل الوحدات</h2><select id="t"><option value="len">الطول</option><option value="w">الوزن</option><option value="tmp">الحرارة</option></select>
<div class="row"><input id="v" type="number" value="1"><select id="a"></select></div><div>⬇️</div><div class="row"><b id="o" style="font-size:26px;direction:ltr"></b><select id="b"></select></div>`,
    `var U={len:{'متر':1,'كيلومتر':1000,'سنتيمتر':.01,'ميل':1609.344,'قدم':.3048,'بوصة':.0254},w:{'كيلوغرام':1,'غرام':.001,'رطل':.45359237,'أوقية':.0283495},tmp:{'مئوية °C':1,'فهرنهايت °F':1,'كلفن K':1}};
function fill(){var k=$('t').value;['a','b'].forEach(function(id,j){var s=$(id);s.innerHTML='';Object.keys(U[k]).forEach(function(n,i){var o=document.createElement('option');o.textContent=n;if(i==j)o.selected=true;s.appendChild(o)})});calc()}
function calc(){var k=$('t').value,v=+$('v').value,a=$('a').value,b=$('b').value,r;
if(k=='tmp'){var c=a.indexOf('F')>-1?(v-32)*5/9:a.indexOf('K')>-1?v-273.15:v;r=b.indexOf('F')>-1?c*9/5+32:b.indexOf('K')>-1?c+273.15:c}else r=v*U[k][a]/U[k][b];
$('o').textContent=(Math.round(r*1e6)/1e6)}
['t'].forEach(function(i){$(i).onchange=fill});['v','a','b'].forEach(function(i){$(i).oninput=calc;$(i).onchange=calc});fill();`));

  A.push(app('disc', 'حاسبة الخصم والنسبة', 'tools', '🏷️', 'احسب الثمن بعد التخفيض وشحال وفرتي.',
    `<h2>🏷️ حاسبة الخصم</h2><input id="p" type="number" placeholder="الثمن الأصلي"><input id="d" type="number" placeholder="نسبة الخصم %"><div class="card"><p>الثمن بعد الخصم</p><p class="big" id="r" style="color:#34d399">0</p><p class="mut">وفّرتي: <b id="s">0</b></p></div>`,
    `function c(){var p=+$('p').value||0,d=+$('d').value||0,s=p*d/100;$('r').textContent=(p-s).toFixed(2);$('s').textContent=s.toFixed(2)}$('p').oninput=c;$('d').oninput=c;`));

  A.push(app('age', 'حاسبة العمر', 'tools', '🎂', 'دخّل تاريخ ازديادك وشوف عمرك بالسنين والشهور والأيام.',
    `<h2>🎂 حاسبة العمر</h2><input id="d" type="date" style="width:200px"><div class="card" id="o" style="min-width:220px">—</div>`,
    `$('d').onchange=function(){var b=new Date(this.value),n=new Date();if(isNaN(b)||b>n){$('o').textContent='تاريخ غير صحيح';return}
var y=n.getFullYear()-b.getFullYear(),m=n.getMonth()-b.getMonth(),d=n.getDate()-b.getDate();if(d<0){m--;d+=new Date(n.getFullYear(),n.getMonth(),0).getDate()}if(m<0){y--;m+=12}
var days=Math.floor((n-b)/864e5);$('o').innerHTML='<p class="big">'+y+'</p><p>سنة، '+m+' شهر، '+d+' يوم</p><p class="mut">= '+days.toLocaleString()+' يوم</p>'}`));

  A.push(app('pass', 'مولّد كلمات السر', 'tools', '🔐', 'كلمات سر قوية وعشوائية وآمنة بنقرة واحدة.',
    `<h2>🔐 مولّد كلمات السر</h2><div class="card" id="o" dir="ltr" style="font-size:20px;word-break:break-all;min-width:240px">—</div><div class="row"><span>الطول</span><input id="l" type="number" value="16" min="6" max="64" style="width:80px"></div>
<label><input type="checkbox" id="s" checked> رموز خاصة</label><div class="row"><button id="g">ولّد</button><button class="g" id="c">نسخ</button></div>`,
    `function gen(){var cs='abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'+($('s').checked?'!@#$%^&*-_?':''),n=Math.min(64,Math.max(6,+$('l').value||16)),a=new Uint32Array(n);crypto.getRandomValues(a);var r='';for(var i=0;i<n;i++)r+=cs[a[i]%cs.length];$('o').textContent=r}
$('g').onclick=gen;$('c').onclick=function(){try{navigator.clipboard.writeText($('o').textContent);$('c').textContent='تم ✓'}catch(e){$('c').textContent='حدّد وانسخ'}setTimeout(function(){$('c').textContent='نسخ'},1200)};gen();`));

  A.push(app('color', 'منتقي الألوان', 'tools', '🎨', 'اختار أي لون وخذ الكود HEX و RGB جاهز للنسخ.',
    `<h2>🎨 منتقي الألوان</h2><input id="c" type="color" value="#6366f1" style="width:140px;height:140px;padding:0;border:0;background:none"><div class="card" dir="ltr"><p id="h" style="font-size:22px;font-weight:800"></p><p id="r" class="mut"></p></div>`,
    `function u(){var v=$('c').value;$('h').textContent=v.toUpperCase();$('r').textContent='rgb('+parseInt(v.slice(1,3),16)+', '+parseInt(v.slice(3,5),16)+', '+parseInt(v.slice(5,7),16)+')';document.body.style.background=v}$('c').oninput=u;u();`));

  A.push(app('count', 'عدّاد الكلمات', 'tools', '📝', 'كتب أو لصق نص وشوف عدد الكلمات والحروف والأسطر.',
    `<h2>📝 عدّاد الكلمات</h2><textarea id="t" rows="7" style="width:min(92vw,420px)" placeholder="كتب هنا..."></textarea><div class="row"><div class="card">كلمات<br><b id="w">0</b></div><div class="card">حروف<br><b id="c">0</b></div><div class="card">أسطر<br><b id="l">0</b></div></div>`,
    `$('t').oninput=function(){var v=this.value;$('w').textContent=v.trim()?v.trim().split(/\\s+/).length:0;$('c').textContent=v.length;$('l').textContent=v?v.split('\\n').length:0}`));

  A.push(app('stopw', 'ساعة إيقاف', 'tools', '⏱️', 'ساعة إيقاف دقيقة مع تسجيل اللفات.',
    `<h1 class="big" id="t" dir="ltr">00:00.00</h1><div class="row"><button id="s">ابدأ</button><button class="g" id="l">لفة</button><button class="g" id="r">تصفير</button></div><div id="o" style="max-height:140px;overflow:auto" dir="ltr"></div>`,
    `var t0=0,el=0,iv=null,n=0;function f(ms){var m=Math.floor(ms/6e4),s=Math.floor(ms%6e4/1e3),c=Math.floor(ms%1e3/10);return(m<10?'0':'')+m+':'+(s<10?'0':'')+s+'.'+(c<10?'0':'')+c}
function tick(){$('t').textContent=f(el+Date.now()-t0)}
$('s').onclick=function(){if(iv){clearInterval(iv);iv=null;el+=Date.now()-t0;this.textContent='كمّل'}else{t0=Date.now();iv=setInterval(tick,30);this.textContent='وقّف'}};
$('l').onclick=function(){if(!iv&&!el)return;n++;var p=document.createElement('p');p.textContent=n+'  '+f(el+(iv?Date.now()-t0:0));$('o').prepend(p)};
$('r').onclick=function(){clearInterval(iv);iv=null;el=0;n=0;$('t').textContent='00:00.00';$('o').innerHTML='';$('s').textContent='ابدأ'};`));

  /* ===== إنتاجية ===== */
  A.push(app('todo', 'قائمة المهام', 'productivity', '✅', 'سجّل مهامك وعلّم اللي كملتي. كتتحفظ فهاد الجهاز.',
    `<h2>✅ مهامي</h2><div class="row"><input id="i" type="text" placeholder="مهمة جديدة" style="width:180px"><button id="a">+</button></div><div id="l" style="width:min(92vw,360px);text-align:right"></div><p class="mut" id="c"></p>`,
    `var T=S('todo')||[];function save(){S('todo',T)}
function draw(){var l=$('l');l.innerHTML='';T.forEach(function(t,i){var d=document.createElement('div');d.className='card';d.style.cssText='display:flex;gap:10px;align-items:center;margin-bottom:8px';
var c=document.createElement('input');c.type='checkbox';c.checked=t.d;c.onchange=function(){t.d=c.checked;save();draw()};var s=document.createElement('span');s.style.flex='1';s.textContent=t.t;if(t.d)s.style.cssText='flex:1;text-decoration:line-through;color:#64748b';
var x=document.createElement('button');x.textContent='✕';x.className='g';x.style.padding='4px 10px';x.onclick=function(){T.splice(i,1);save();draw()};d.appendChild(c);d.appendChild(s);d.appendChild(x);l.appendChild(d)});
$('c').textContent=T.length?T.filter(function(t){return t.d}).length+' / '+T.length+' مكتملة':'ما عندك حتى مهمة'}
function add(){var v=$('i').value.trim();if(!v)return;T.push({t:v,d:false});$('i').value='';save();draw()}$('a').onclick=add;$('i').onkeydown=function(e){if(e.key=='Enter')add()};draw();`));

  A.push(app('notes', 'ملاحظات سريعة', 'productivity', '🗒️', 'دفتر ملاحظات بسيط كيتحفظ تلقائياً فهاد الجهاز.',
    `<h2>🗒️ ملاحظاتي</h2><textarea id="t" rows="12" style="width:min(92vw,420px)" placeholder="كتب ما بغيتي..."></textarea><p class="mut" id="m">تحفظ تلقائياً</p><button class="g" id="c">مسح</button>`,
    `$('t').value=S('note')||'';$('t').oninput=function(){S('note',this.value);$('m').textContent='تحفظ ✓ '+new Date().toLocaleTimeString()};$('c').onclick=function(){if(confirm('مسح الملاحظة؟')){$('t').value='';S('note','')}};`));

  A.push(app('spend', 'مصاريفي', 'productivity', '💸', 'سجّل مصاريفك اليومية وشوف المجموع.',
    `<h2>💸 مصاريفي</h2><div class="row"><input id="n" type="text" placeholder="على شنو؟" style="width:130px"><input id="v" type="number" placeholder="المبلغ" style="width:100px"><button id="a">+</button></div><div class="card"><p class="mut">المجموع</p><p class="big" id="s" style="color:#fbbf24">0</p></div><div id="l" style="width:min(92vw,360px);text-align:right"></div><button class="g" id="c">مسح الكل</button>`,
    `var E=S('exp')||[];function draw(){var l=$('l');l.innerHTML='';var s=0;E.forEach(function(e,i){s+=e.v;var d=document.createElement('div');d.className='card';d.style.cssText='display:flex;justify-content:space-between;margin-bottom:6px';var a=document.createElement('span');a.textContent=e.n;var b=document.createElement('span');b.textContent=e.v.toFixed(2)+' ✕';b.style.cursor='pointer';b.onclick=function(){E.splice(i,1);S('exp',E);draw()};d.appendChild(a);d.appendChild(b);l.appendChild(d)});$('s').textContent=s.toFixed(2)}
$('a').onclick=function(){var v=+$('v').value;if(!v)return;E.push({n:$('n').value.trim()||'مصروف',v:v});$('n').value='';$('v').value='';S('exp',E);draw()};$('c').onclick=function(){if(confirm('مسح كلشي؟')){E=[];S('exp',E);draw()}};draw();`));

  A.push(app('timer', 'مؤقت تنازلي', 'productivity', '⏳', 'حدد الدقائق وخلّي المؤقت يعلمك ملي يسالي الوقت.',
    `<h1 class="big" id="t" dir="ltr">05:00</h1><div class="row"><input id="m" type="number" value="5" min="1" max="180" style="width:90px"><span>دقيقة</span></div><div class="row"><button id="s">ابدأ</button><button class="g" id="r">إيقاف</button></div>`,
    `var iv=null,left=0;function show(){var m=Math.floor(left/60),s=left%60;$('t').textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s}
$('s').onclick=function(){clearInterval(iv);left=Math.max(1,Math.min(180,+$('m').value||5))*60;show();iv=setInterval(function(){left--;show();if(left<=0){clearInterval(iv);$('t').textContent='⏰ سالا!';if(navigator.vibrate)navigator.vibrate([300,150,300])}},1000)};
$('r').onclick=function(){clearInterval(iv);left=(+$('m').value||5)*60;show()};left=300;`));

  /* ===== أسلوب حياة ===== */
  A.push(app('water', 'متتبع شرب الماء', 'lifestyle', '💧', 'سجّل الكاسات اللي شربتي فاليوم وبلغ هدفك.',
    `<h2>💧 شرب الماء</h2><div class="big" id="n">0 / 8</div><div id="g" style="font-size:30px;letter-spacing:4px;min-height:40px"></div><div class="row"><button id="a">+ كاس</button><button class="g" id="m">− كاس</button></div><p class="mut" id="p"></p>`,
    `var K='w'+new Date().toDateString(),G=8,n=S(K)||0;function draw(){$('n').textContent=n+' / '+G;$('g').textContent='💧'.repeat(Math.min(n,G))+'▫️'.repeat(Math.max(0,G-n));$('p').textContent=n>=G?'🎉 برافو، وصلتي الهدف!':'باقي ليك '+(G-n)+' كاسات'}
$('a').onclick=function(){n++;S(K,n);draw()};$('m').onclick=function(){if(n>0)n--;S(K,n);draw()};draw();`));

  A.push(app('pick', 'قرعة عشوائية', 'lifestyle', '🎲', 'دخّل أسماء أو خيارات وخلّي القرعة تختار ليك وحدة.',
    `<h2>🎲 القرعة</h2><textarea id="t" rows="5" style="width:min(92vw,320px)" placeholder="كتب كل خيار فسطر"></textarea><button id="b">اختار 🎯</button><div class="card" style="min-width:200px"><p class="big" id="r" style="font-size:30px">—</p></div>`,
    `$('b').onclick=function(){var a=$('t').value.split('\\n').map(function(x){return x.trim()}).filter(Boolean);if(a.length<2){$('r').textContent='زيد خيارين على الأقل';return}
var i=0,k=0,iv=setInterval(function(){$('r').textContent=a[Math.floor(Math.random()*a.length)];if(++k>14){clearInterval(iv);$('r').textContent='🏆 '+a[Math.floor(Math.random()*a.length)]}},80)};`));

  A.push(app('breath', 'تمرين التنفس', 'lifestyle', '🌬️', 'تنفس بهدوء مع الدائرة: شهيق 4 ثواني، حبس 4، زفير 6.',
    `<h2>🌬️ تنفّس بهدوء</h2><div id="c" style="width:120px;height:120px;border-radius:50%;background:radial-gradient(#22d3ee,#6366f1);transition:transform 4s ease-in-out;box-shadow:0 0 50px #6366f1aa"></div><p id="t" style="font-size:22px;min-height:30px">اضغط ابدأ</p><button id="b">ابدأ</button>`,
    `var on=false,to;function step(i){if(!on)return;var P=[['شهيق...','scale(1.9)',4000,'4s'],['حبس النفس','scale(1.9)',4000,'4s'],['زفير...','scale(1)',6000,'6s']][i];$('t').textContent=P[0];$('c').style.transitionDuration=P[3];$('c').style.transform=P[1];to=setTimeout(function(){step((i+1)%3)},P[2])}
$('b').onclick=function(){on=!on;this.textContent=on?'إيقاف':'ابدأ';clearTimeout(to);if(on)step(0);else{$('t').textContent='اضغط ابدأ';$('c').style.transform='scale(1)'}};`));

  return A;
})();
