// Construit le dossier www/ (application complète, JavaScript regroupé en un seul fichier avec les plugins Android).
// Utilisation : npm run build
import { build } from 'esbuild';
import fs from 'node:fs';

fs.rmSync('www', { recursive: true, force: true });
fs.mkdirSync('www/icons', { recursive: true });
await build({ entryPoints: ['web/js/app.js'], bundle: true, format: 'iife', minify: true, target: 'es2020', outfile: 'www/app.js', logLevel: 'info' });
fs.cpSync('web/css', 'www/css', { recursive: true });
fs.cpSync('web/icons', 'www/icons', { recursive: true });
fs.copyFileSync('web/index.html', 'www/index.html');
fs.copyFileSync('web/xlsx.mini.min.js', 'www/xlsx.mini.min.js');
console.log('www/ prêt');
