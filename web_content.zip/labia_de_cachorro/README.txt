# Lábia de Cachorro — primeira versão

## O que já funciona
- Interface responsiva com visual preto e vermelho.
- Gerador offline de respostas, cantadas, aberturas de conversa e mensagens românticas.
- Botões para copiar sugestões.
- Estrutura PWA com manifest e service worker para instalação pelo navegador.

## Como testar no celular
1. Publique os arquivos em uma hospedagem HTTPS (por exemplo, GitHub Pages ou Netlify).
2. Abra o endereço no Chrome do Android.
3. Use o menu do Chrome > "Instalar app" ou "Adicionar à tela inicial".

## Sobre o APK
Esta entrega é a primeira versão web instalável (PWA), não um APK compilado.
Para gerar um APK, o próximo passo é empacotar esta aplicação com Capacitor/Android Studio ou um serviço de build Android.

## Inteligência artificial
A tela de IA está preparada como ponto de integração, mas ainda não chama um modelo real.
A integração segura exige um backend (servidor) que guarde a chave da API. Não coloque chave secreta dentro do HTML ou do APK.
