भूगोल उत्तर पुस्तिका ऐप – APK बनाने के चरण (सूर्यकांत भारती)

1. कंप्यूटर में Android Studio इंस्टॉल करें (मुफ़्त, developer.android.com/studio)।
2. इस ज़िप को खोलें। Android Studio में File > Open से "GeoAnswersApp" फ़ोल्डर चुनें।
3. Gradle Sync पूरा होने दें (पहली बार इंटरनेट चाहिए, कुछ मिनट लगेंगे)।
4. मेन्यू: Build > Build Bundle(s) / APK(s) > Build APK(s)।
5. नीचे "locate" पर क्लिक करें – app-debug.apk मिल जाएगी।
   (app/build/outputs/apk/debug/app-debug.apk)
6. इसे व्हाट्सऐप से बच्चों को भेजें; फ़ोन में "अज्ञात स्रोत से इंस्टॉल" की अनुमति देनी होगी।

ऐप में बदलाव (प्रश्न/फोटो): app/src/main/assets/index.html फ़ाइल बदलें।
