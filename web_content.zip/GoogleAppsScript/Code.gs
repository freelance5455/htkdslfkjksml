/**
 * نظام إدارة وتوزيع الطحين — ملاحظة البناء
 * نسخة index.html تعمل كتطبيق مستقل وتخزن بياناتها محلياً على الجهاز.
 * لا يحتاج WebIntoApp إلى هذا الملف لتغليف HTML كتطبيق Android.
 * هذا الملف محفوظ داخل الحزمة للمحافظة على بنية المجلد التي طلبها المستخدم.
 */
function doGet() {
  return ContentService.createTextOutput('Flour Distribution Manager package');
}
