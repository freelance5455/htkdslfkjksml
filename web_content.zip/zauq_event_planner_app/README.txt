ZAUQ EVENT PLANNER APP
========================

This is a ready-to-use mobile-friendly app/web app.

Included:
- Zauq Event Planner branding
- Wedding, Mahfil-e-Milad, Birthday, Corporate, Stage/Sound/Lighting services
- Call button
- WhatsApp booking form
- Facebook and Instagram buttons
- Responsive Android/iPhone layout

Quick use:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. On Android Chrome, use menu > Add to Home screen to install it like an app.

For a real APK, this project can be wrapped into an Android APK using Android Studio or a WebView/PWA packaging service.
