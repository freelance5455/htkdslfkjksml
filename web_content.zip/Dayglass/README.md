# Dayglass — Android app

A native Android wrapper (WebView) around the Dayglass daily planner,
now including a Mood Tracker (check-in, journal, calendar, insights).

Tasks, goals, notes, moods and settings persist via localStorage, which is
enabled in the WebView (`domStorageEnabled`).

## Build the APK

1. Install [Android Studio](https://developer.android.com/studio) (it includes the SDK + Gradle).
2. Open this folder as a project and let Gradle sync (it downloads what it needs).
3. To get an installable APK right away:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)** — a debug APK lands in
   `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install.
4. For a release APK (recommended for sharing):
   **Build > Generate Signed Bundle / APK** and create a keystore when prompted.

## Update the app

Edit `app/src/main/assets/www/index.html` (it is the whole planner + mood tracker),
then rebuild. Nothing else needs to change.
