package com.dayglass.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true      // required by the planner
            domStorageEnabled = true      // localStorage persistence
            allowFileAccess = true        // load bundled assets
            allowContentAccess = true
            // ---- Fixed-scale interface: three independent layers ----
            // Layer 1 (engine): disable WebView zoom machinery. setSupportZoom(false)
            // stops pinch/double-tap zoom gestures; MUST be set after the zoom-control
            // calls because setBuiltInZoomControls(true) re-enables zoom support.
            builtInZoomControls = false    // no on-screen +/- zoom buttons
            displayZoomControls = false    // never show zoom UI
            setSupportZoom(false)          // engine-level: no zoom gestures
            // Layout always at device width per the viewport meta tag; never wider,
            // so there is no initial overscale or horizontal overflow.
            useWideViewPort = true
            loadWithOverviewMode = true
            // System font-size accessibility (settings.textZoom) is left untouched.
        }
        // Layer 2 (page): index.html viewport meta has maximum-scale=1 &
        // user-scalable=no, so Chromium's viewport code caps the page scale at 1.
        // Layer 3 (fallback): consume ONLY multi-pointer touch events. A pinch can
        // never form because the second finger's events never reach the WebView.
        // Single-pointer events are never consumed -> taps, scrolling, long-press,
        // text selection and all inputs behave exactly as before. DAY GLASS has no
        // legitimate two-finger interaction, so nothing real is blocked.
        webView.setOnTouchListener { _, event -> event.pointerCount > 1 }
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/www/index.html")
        setContentView(webView)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
