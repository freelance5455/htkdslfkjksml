export const ZULU_WORD_BUILDER_LIBRARY = {
  "version": 6,
  "grade": 5,
  "language": "isiZulu",
  "cards": [
    {
      "family": "VOWELS",
      "cards": [
        "A",
        "E",
        "I",
        "O",
        "U"
      ]
    },
    {
      "family": "B",
      "cards": [
        "BA",
        "BE",
        "BI",
        "BO",
        "BU"
      ]
    },
    {
      "family": "BH",
      "cards": [
        "BHA",
        "BHE",
        "BHI",
        "BHO",
        "BHU"
      ]
    },
    {
      "family": "C",
      "cards": [
        "CA",
        "CE",
        "CI",
        "CO",
        "CU"
      ]
    },
    {
      "family": "CH",
      "cards": [
        "CHA",
        "CHE",
        "CHI",
        "CHO",
        "CHU"
      ]
    },
    {
      "family": "D",
      "cards": [
        "DA",
        "DE",
        "DI",
        "DO",
        "DU"
      ]
    },
    {
      "family": "DL",
      "cards": [
        "DLA",
        "DLE",
        "DLI",
        "DLO",
        "DLU"
      ]
    },
    {
      "family": "F",
      "cards": [
        "FA",
        "FE",
        "FI",
        "FO",
        "FU"
      ]
    },
    {
      "family": "G",
      "cards": [
        "GA",
        "GE",
        "GI",
        "GO",
        "GU"
      ]
    },
    {
      "family": "GC",
      "cards": [
        "GCA",
        "GCE",
        "GCI",
        "GCO",
        "GCU"
      ]
    },
    {
      "family": "GQ",
      "cards": [
        "GQA",
        "GQE",
        "GQI",
        "GQO",
        "GQU"
      ]
    },
    {
      "family": "H",
      "cards": [
        "HA",
        "HE",
        "HI",
        "HO",
        "HU"
      ]
    },
    {
      "family": "HL",
      "cards": [
        "HLA",
        "HLE",
        "HLI",
        "HLO",
        "HLU"
      ]
    },
    {
      "family": "J",
      "cards": [
        "JA",
        "JE",
        "JI",
        "JO",
        "JU"
      ]
    },
    {
      "family": "K",
      "cards": [
        "KA",
        "KE",
        "KI",
        "KO",
        "KU"
      ]
    },
    {
      "family": "KH",
      "cards": [
        "KHA",
        "KHE",
        "KHI",
        "KHO",
        "KHU"
      ]
    },
    {
      "family": "L",
      "cards": [
        "LA",
        "LE",
        "LI",
        "LO",
        "LU"
      ]
    },
    {
      "family": "M",
      "cards": [
        "MA",
        "ME",
        "MI",
        "MO",
        "MU"
      ]
    },
    {
      "family": "MB",
      "cards": [
        "MBA",
        "MBE",
        "MBI",
        "MBO",
        "MBU"
      ]
    },
    {
      "family": "MF",
      "cards": [
        "MFA",
        "MFE",
        "MFI",
        "MFO",
        "MFU"
      ]
    },
    {
      "family": "MP",
      "cards": [
        "MPA",
        "MPE",
        "MPI",
        "MPO",
        "MPU"
      ]
    },
    {
      "family": "MV",
      "cards": [
        "MVA",
        "MVE",
        "MVI",
        "MVO",
        "MVU"
      ]
    },
    {
      "family": "N",
      "cards": [
        "NA",
        "NE",
        "NI",
        "NO",
        "NU"
      ]
    },
    {
      "family": "NC",
      "cards": [
        "NCA",
        "NCE",
        "NCI",
        "NCO",
        "NCU"
      ]
    },
    {
      "family": "ND",
      "cards": [
        "NDA",
        "NDE",
        "NDI",
        "NDO",
        "NDU"
      ]
    },
    {
      "family": "NDL",
      "cards": [
        "NDLA",
        "NDLE",
        "NDLI",
        "NDLO",
        "NDLU"
      ]
    },
    {
      "family": "NG",
      "cards": [
        "NGA",
        "NGE",
        "NGI",
        "NGO",
        "NGU"
      ]
    },
    {
      "family": "NHL",
      "cards": [
        "NHLA",
        "NHLE",
        "NHLI",
        "NHLO",
        "NHLU"
      ]
    },
    {
      "family": "NJ",
      "cards": [
        "NJA",
        "NJE",
        "NJI",
        "NJO",
        "NJU"
      ]
    },
    {
      "family": "NK",
      "cards": [
        "NKA",
        "NKE",
        "NKI",
        "NKO",
        "NKU"
      ]
    },
    {
      "family": "NQ",
      "cards": [
        "NQA",
        "NQE",
        "NQI",
        "NQO",
        "NQU"
      ]
    },
    {
      "family": "NT",
      "cards": [
        "NTA",
        "NTE",
        "NTI",
        "NTO",
        "NTU"
      ]
    },
    {
      "family": "NTS",
      "cards": [
        "NTSA",
        "NTSE",
        "NTSI",
        "NTSO",
        "NTSU"
      ]
    },
    {
      "family": "NTSH",
      "cards": [
        "NTSHA",
        "NTSHE",
        "NTSHI",
        "NTSHO",
        "NTSHU"
      ]
    },
    {
      "family": "P",
      "cards": [
        "PA",
        "PE",
        "PI",
        "PO",
        "PU"
      ]
    },
    {
      "family": "PH",
      "cards": [
        "PHA",
        "PHE",
        "PHI",
        "PHO",
        "PHU"
      ]
    },
    {
      "family": "Q",
      "cards": [
        "QA",
        "QE",
        "QI",
        "QO",
        "QU"
      ]
    },
    {
      "family": "QH",
      "cards": [
        "QHA",
        "QHE",
        "QHI",
        "QHO",
        "QHU"
      ]
    },
    {
      "family": "R",
      "cards": [
        "RA",
        "RE",
        "RI",
        "RO",
        "RU"
      ]
    },
    {
      "family": "S",
      "cards": [
        "SA",
        "SE",
        "SI",
        "SO",
        "SU"
      ]
    },
    {
      "family": "SH",
      "cards": [
        "SHA",
        "SHE",
        "SHI",
        "SHO",
        "SHU"
      ]
    },
    {
      "family": "T",
      "cards": [
        "TA",
        "TE",
        "TI",
        "TO",
        "TU"
      ]
    },
    {
      "family": "TH",
      "cards": [
        "THA",
        "THE",
        "THI",
        "THO",
        "THU"
      ]
    },
    {
      "family": "TS",
      "cards": [
        "TSA",
        "TSE",
        "TSI",
        "TSO",
        "TSU"
      ]
    },
    {
      "family": "TSH",
      "cards": [
        "TSHA",
        "TSHE",
        "TSHI",
        "TSHO",
        "TSHU"
      ]
    },
    {
      "family": "V",
      "cards": [
        "VA",
        "VE",
        "VI",
        "VO",
        "VU"
      ]
    },
    {
      "family": "W",
      "cards": [
        "WA",
        "WE",
        "WI",
        "WO",
        "WU"
      ]
    },
    {
      "family": "X",
      "cards": [
        "XA",
        "XE",
        "XI",
        "XO",
        "XU"
      ]
    },
    {
      "family": "XH",
      "cards": [
        "XHA",
        "XHE",
        "XHI",
        "XHO",
        "XHU"
      ]
    },
    {
      "family": "Y",
      "cards": [
        "YA",
        "YE",
        "YI",
        "YO",
        "YU"
      ]
    },
    {
      "family": "Z",
      "cards": [
        "ZA",
        "ZE",
        "ZI",
        "ZO",
        "ZU"
      ]
    },
    {
      "family": "NZ",
      "cards": [
        "NZA",
        "NZE",
        "NZI",
        "NZO",
        "NZU"
      ]
    },
    {
      "family": "NY",
      "cards": [
        "NYA",
        "NYE",
        "NYI",
        "NYO",
        "NYU"
      ]
    },
    {
      "family": "NS",
      "cards": [
        "NSA",
        "NSE",
        "NSI",
        "NSO",
        "NSU"
      ]
    },
    {
      "family": "NSH",
      "cards": [
        "NSHA",
        "NSHE",
        "NSHI",
        "NSHO",
        "NSHU"
      ]
    },
    {
      "family": "NCH",
      "cards": [
        "NCHA",
        "NCHE",
        "NCHI",
        "NCHO",
        "NCHU"
      ]
    },
    {
      "family": "NKH",
      "cards": [
        "NKHA",
        "NKHE",
        "NKHI",
        "NKHO",
        "NKHU"
      ]
    },
    {
      "family": "NPH",
      "cards": [
        "NPHA",
        "NPHE",
        "NPHI",
        "NPHO",
        "NPHU"
      ]
    },
    {
      "family": "MHL",
      "cards": [
        "MHLA",
        "MHLE",
        "MHLI",
        "MHLO",
        "MHLU"
      ]
    },
    {
      "family": "MKH",
      "cards": [
        "MKHA",
        "MKHE",
        "MKHI",
        "MKHO",
        "MKHU"
      ]
    },
    {
      "family": "MSH",
      "cards": [
        "MSHA",
        "MSHE",
        "MSHI",
        "MSHO",
        "MSHU"
      ]
    },
    {
      "family": "MTH",
      "cards": [
        "MTHA",
        "MTHE",
        "MTHI",
        "MTHO",
        "MTHU"
      ]
    },
    {
      "family": "MPH",
      "cards": [
        "MPHA",
        "MPHE",
        "MPHI",
        "MPHO",
        "MPHU"
      ]
    },
    {
      "family": "MNG",
      "cards": [
        "MNGA",
        "MNGE",
        "MNGI",
        "MNGO",
        "MNGU"
      ]
    },
    {
      "family": "MBL",
      "cards": [
        "MBLA",
        "MBLE",
        "MBLI",
        "MBLO",
        "MBLU"
      ]
    },
    {
      "family": "MBH",
      "cards": [
        "MBHA",
        "MBHE",
        "MBHI",
        "MBHO",
        "MBHU"
      ]
    },
    {
      "family": "NGQ",
      "cards": [
        "NGQA",
        "NGQE",
        "NGQI",
        "NGQO",
        "NGQU"
      ]
    },
    {
      "family": "NGX",
      "cards": [
        "NGXA",
        "NGXE",
        "NGXI",
        "NGXO",
        "NGXU"
      ]
    },
    {
      "family": "NXL",
      "cards": [
        "NXLA",
        "NXLE",
        "NXLI",
        "NXLO",
        "NXLU"
      ]
    }
  ],
  "words": [
    {
      "word": "umama",
      "parts": [
        "u",
        "ma",
        "ma"
      ]
    },
    {
      "word": "ubaba",
      "parts": [
        "u",
        "ba",
        "ba"
      ]
    },
    {
      "word": "indlu",
      "parts": [
        "i",
        "ndlu"
      ]
    },
    {
      "word": "indlela",
      "parts": [
        "i",
        "ndle",
        "la"
      ]
    },
    {
      "word": "indlala",
      "parts": [
        "i",
        "ndla",
        "la"
      ]
    },
    {
      "word": "indoda",
      "parts": [
        "i",
        "ndo",
        "da"
      ]
    },
    {
      "word": "ibhola",
      "parts": [
        "i",
        "bho",
        "la"
      ]
    },
    {
      "word": "isikole",
      "parts": [
        "i",
        "si",
        "ko",
        "le"
      ]
    },
    {
      "word": "umfana",
      "parts": [
        "u",
        "mfa",
        "na"
      ]
    },
    {
      "word": "umuntu",
      "parts": [
        "u",
        "mu",
        "ntu"
      ]
    },
    {
      "word": "ingane",
      "parts": [
        "i",
        "nga",
        "ne"
      ]
    },
    {
      "word": "inkomo",
      "parts": [
        "i",
        "nko",
        "mo"
      ]
    },
    {
      "word": "ikhaya",
      "parts": [
        "i",
        "kha",
        "ya"
      ]
    },
    {
      "word": "umfundi",
      "parts": [
        "u",
        "mfu",
        "ndi"
      ]
    },
    {
      "word": "imfundo",
      "parts": [
        "i",
        "mfu",
        "ndo"
      ]
    },
    {
      "word": "dlala",
      "parts": [
        "dla",
        "la"
      ]
    },
    {
      "word": "hlala",
      "parts": [
        "hla",
        "la"
      ]
    },
    {
      "word": "khala",
      "parts": [
        "kha",
        "la"
      ]
    },
    {
      "word": "khuluma",
      "parts": [
        "khu",
        "lu",
        "ma"
      ]
    },
    {
      "word": "phuza",
      "parts": [
        "phu",
        "za"
      ]
    },
    {
      "word": "bhala",
      "parts": [
        "bha",
        "la"
      ]
    },
    {
      "word": "thatha",
      "parts": [
        "tha",
        "tha"
      ]
    },
    {
      "word": "shisa",
      "parts": [
        "shi",
        "sa"
      ]
    },
    {
      "word": "tshala",
      "parts": [
        "tsha",
        "la"
      ]
    },
    {
      "word": "tshela",
      "parts": [
        "tshe",
        "la"
      ]
    },
    {
      "word": "qhuma",
      "parts": [
        "qhu",
        "ma"
      ]
    },
    {
      "word": "cula",
      "parts": [
        "cu",
        "la"
      ]
    },
    {
      "word": "cela",
      "parts": [
        "ce",
        "la"
      ]
    },
    {
      "word": "xoxa",
      "parts": [
        "xo",
        "xa"
      ]
    },
    {
      "word": "geza",
      "parts": [
        "ge",
        "za"
      ]
    },
    {
      "word": "vuka",
      "parts": [
        "vu",
        "ka"
      ]
    },
    {
      "word": "yima",
      "parts": [
        "yi",
        "ma"
      ]
    },
    {
      "word": "yenza",
      "parts": [
        "ye",
        "nza"
      ]
    },
    {
      "word": "zama",
      "parts": [
        "za",
        "ma"
      ]
    },
    {
      "word": "umoya",
      "parts": [
        "u",
        "mo",
        "ya"
      ]
    },
    {
      "word": "izinyo",
      "parts": [
        "i",
        "zi",
        "nyo"
      ]
    },
    {
      "word": "isitulo",
      "parts": [
        "i",
        "si",
        "tu",
        "lo"
      ]
    },
    {
      "word": "abazali",
      "parts": [
        "a",
        "ba",
        "za",
        "li"
      ]
    }
  ]
};
