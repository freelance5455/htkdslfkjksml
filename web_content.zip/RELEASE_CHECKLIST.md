# Release checklist — before Google Play

- [ ] Choose and review Swiss Ephemeris license (AGPL compliance or commercial license); verify redistribution rights for ephemeris files.
- [ ] Replace demo/test backend URL with HTTPS production API.
- [ ] Configure AI provider key only on backend; add authentication, quotas, rate limits, monitoring and abuse prevention.
- [ ] Implement production geocoding and timezone lookup; current app has manual coordinates/timezone to avoid silently choosing the wrong place.
- [ ] Test UTC conversion and daylight-saving transitions.
- [ ] Validate chart calculations against trusted reference charts (planets, houses, retrogrades, aspects, sign boundaries).
- [ ] Have a qualified traditional horary practitioner review the rule set and sample judgments.
- [ ] Expand question classification and derived houses with tests.
- [ ] Add local history, export/delete controls, consent, privacy policy and retention policy.
- [ ] Add app icon, screenshots, store listing, content rating, Data safety form.
- [ ] Build a signed Android App Bundle (.aab), test on multiple devices, and publish.
