# Smart Release Checklist

- [ ] Run a clean Gradle build on a machine with Android SDK 36 installed.
- [ ] Test on physical Android devices.
- [ ] Configure Smart Pro subscriptions in Google Play Console.
- [ ] Configure secure Google Play Developer API verification on the backend.
- [ ] Add production authentication and company roles.
- [ ] Deploy backend over HTTPS.
- [ ] Replace placeholder privacy/contact/business information.
- [ ] Complete Play Console Data Safety, content rating and app access declarations.
- [ ] Generate and securely store the release signing key.
- [ ] Build and test a signed AAB.
- [ ] Upload to Play Console internal testing first.
- [ ] Fix crashes/policy issues found during testing.
- [ ] Publish production release.
