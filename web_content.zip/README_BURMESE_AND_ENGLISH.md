# ⏳ ၁၆၈ နာရီ အချိန်စီမံခန့်ခွဲမှု အက်ပ် — 168 Hours Android Application (Burmese + English)

ဤပက်ကေ့ချ်တွင် မူရင်း `⏳ 168 Hours Template` Google Sheet မှ အစိတ်အပိုင်းအားလုံး (စာမျက်နှာ ၅ ခုလုံး၊ တွက်ချက်မှု ပုံသေနည်းများ၊ Pie/Bar ဇယားပုံ ၈ ခုနှင့် မူရင်းပုံ ၃ ပုံ) ကို တစ်ခုမကျန် မြန်မာဘာသာဖြင့် အပြည့်အစုံ ထည့်သွင်းပေးထားပါသည်။

## 📦 ပါဝင်သော ဖိုင်များ (Included Files — Nothing Left Out)

1. **`168_Hours_Android_App_Burmese.html`**
   - Android ဖုန်း၊ တက်ဘလက်နှင့် ကွန်ပျူတာ မည်သည့်ဘရောက်ဇာ (Chrome / Edge / Samsung Internet) တွင်မဆို တိုက်ရိုက်ဖွင့်၍ အသုံးပြုနိုင်သော Offline Web App / PWA ဖြစ်ပါသည်။
   - **Android ဖုန်းတွင် အက်ပ်အဖြစ် သွင်းယူနည်း**: ဖိုင်ကို Chrome ဖြင့်ဖွင့်ပါ ➔ ညာဘက်အပေါ်ထောင့်ရှိ `(⋮)` မီနူးကိုနှိပ်ပါ ➔ **"Add to Home screen"** ကိုနှိပ်ပါ။
2. **`spreadsheets/168_Hours_Template_Burmese.xlsx`**
   - မူရင်း စာမျက်နှာ (၅) ခုလုံး (`READ ME - Instructions`, `⏳ 168 Hours Template`, `👉 Current Week`, `🌈 Ideal Week`, `LifeOS - Save $50`)၊ တွက်ချက်မှု Formula များ၊ ဇယားပုံ (၈) ခုနှင့် ပုံ (၃) ပုံလုံးကို မြန်မာ + အင်္ဂလိပ် နှစ်ဘာသာဖြင့် ပြန်ဆိုထားသော Excel ဖိုင်။
3. **`spreadsheets/168_Hours_Template_Original.xlsx`**
   - မူရင်း Google Sheet မှ တိုက်ရိုက်ထုတ်ယူထားသော မူရင်း Excel ဖိုင်။
4. **`original_media/` (`image1.png`, `image2.png`, `image4.png`)**
   - မူရင်းဖိုင်အတွင်းပါရှိသော လမ်းညွှန်ပုံ (၂) ပုံနှင့် LifeOS လိုဂိုပုံ (၁) ပုံ။
5. **`AndroidStudioProject/`**
   - Android Studio ဖြင့် Native `.apk` ဖိုင် တိုက်ရိုက်ထုတ်ယူနိုင်သော Android WebView Project အပြည့်အစုံ (`./gradlew assembleDebug`)။
