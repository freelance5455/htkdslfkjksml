
/* نظام التراخيص التجريبي - CodePen */
(() => {
  const STORAGE_KEY = "smartSchool_demoLicense";
  const MACHINE_KEY = "smartSchool_hw_machineId";

  function getMachineId() {
    let id = localStorage.getItem(MACHINE_KEY);

    if (!id) {
      const randomPart = Math.random()
        .toString(36)
        .substring(2, 10)
        .toUpperCase();

      id = "SS-PC-" + randomPart;
      localStorage.setItem(MACHINE_KEY, id);
    }

    return id;
  }

  function showMessage(message, success = true) {
    if (typeof window.showLicenseMessage === "function") {
      window.showLicenseMessage(
        "licActivateMsgBox",
        message,
        success
      );
    } else {
      alert(message);
    }
  }

  window.activateDemoLicense = function () {
    const input = document.getElementById("licActivateInput");
    const schoolInput = document.getElementById(
      "licTargetSchoolNameInput"
    );

    const token = input?.value.trim();
    const schoolName = schoolInput?.value.trim();

    if (!token) {
      showMessage("أدخل رمز التفعيل أولاً.", false);
      return;
    }

    if (!schoolName) {
      showMessage("أدخل اسم المدرسة.", false);
      return;
    }

    // رمز تجريبي للاختبار فقط، وليس ترخيصاً آمناً.
    if (token !== "DEMO-2027") {
      showMessage("رمز التفعيل التجريبي غير صحيح.", false);
      return;
    }

    const license = {
      product: "SmartSchool",
      machineId: getMachineId(),
      schoolName,
      type: "DEMO",
      status: "ACTIVE",
      activatedAt: new Date().toISOString()
    };

    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(license)
    );

    if (typeof window.initLicenseManagementSection === "function") {
      window.initLicenseManagementSection();
    }

    showMessage("تم التفعيل التجريبي بنجاح.");
  };

  window.clearDemoLicense = function () {
    localStorage.removeItem(STORAGE_KEY);

    if (typeof window.initLicenseManagementSection === "function") {
      window.initLicenseManagementSection();
    }

    showMessage("تم إلغاء التفعيل التجريبي.");
  };

  window.getDemoLicense = function () {
    try {
      return JSON.parse(
        localStorage.getItem(STORAGE_KEY) || "null"
      );
    } catch {
      return null;
    }
  };

  // عرض رقم الجهاز التجريبي.
  const id = getMachineId();
  const machineField = document.getElementById(
    "licCurrentMachineId"
  );

  if (machineField) {
    machineField.textContent = id;
    if ("value" in machineField) machineField.value = id;
  }
})();
console.log("DEMO:", typeof window.activateDemoLicense);
console.log("INIT:", typeof window.initLicenseManagementSection);