# AI Agent Studio — current implementation status (2.6.0)

## Source archive
Rebuilt from `ANONYMOUX_STUDIO_2.5.9_EXPLORE_REMOVAL_REALTIME_PRICING_RECHECK.zip`.

## Implemented in 2.6.0
- Standalone AI Agent Studio route and grouped sidebar navigation.
- Searchable agent list with draft/published filters and session counts.
- Server-side Fish Audio Agent API client using the existing encrypted Fish Audio key vault.
- Provider-backed agent creation, draft configuration update, publishing, deletion and authenticated session creation.
- Agent voice selection from the public Fish Audio catalogue and the current user's own private cloned voices.
- Server-side voice ownership checks on create, update and session start.
- Provider-supported speaking language (52 codes), Drama 3/S2.1 Pro selection, speaking speed and expressive mode.
- Explicit `fish_tts` engine selection for the configured TTS voice settings.
- Browser chat/voice testing for published agents using the existing Fish Audio agent-client SDK.
- Local conversation message persistence and session usage reconciliation hooks.
- Knowledge source upload/attach flow for provider-supported UTF-8 `.txt` and `.md` files, maximum 1 MB.
- WhatsApp Business Calling setup guide with the documented Fish Audio console workflow and callback URL.
- Editing a published agent marks the local agent as Draft; republish is required for live changes.

## Provider constraints
- Fish Audio WhatsApp number import remains a console-only operation; this app provides setup guidance and does not claim connection status.
- This app's test-session flow requires a published agent. Draft preview calls remain available through Fish Audio's own Builder where the provider supports them; the app does not invent a draft-session endpoint.
- Fish Audio session costs and ANON credits are separate. Admin must configure a current provider USD/minute rate and ANON credits-per-USD conversion before wallet deductions are enabled. Defaults are zero.
- Knowledge upload is limited to the formats and size supported by the provider API; PDF/Office conversion is not included.

## Deployment
1. Back up the live database, `storage/` and private configuration before upload.
2. Upload the ZIP contents to the application root. Preserve private `config.local.php` and all credentials.
3. Use PHP 8.x with PDO SQLite or PDO MySQL, cURL, fileinfo and OpenSSL.
4. Configure a Fish Audio key in Admin → Voice AI and use the connection-test action.
5. Create an agent, configure voice/language/model, save draft and publish before in-app testing.
6. Enable HTTPS and grant microphone permission for voice sessions.
7. Apply migration 007 if migrations are managed manually; runtime schema creation is idempotent.

## Verification limits
Static PHP/JavaScript checks, regression tests and SQLite migration tests passed in the build environment. Live Fish Audio API calls, actual browser microphone/WebRTC sessions and InfinityFree deployment remain NOT TESTED because the build container does not have PHP cURL or PDO SQLite and no provider key/target host was supplied. See `BUILD_REPORT_2.6.0.md`.


## 2.6.4 workspace patch
- Browser session startup is serialized so rapid double-clicks do not create duplicate Fish Audio sessions.
- The API rejects incomplete provider session responses before writing a local session row.
- Agent credit conversion now defaults to 0 for new installs; measured provider usage is still recorded and can be enabled by Admin after configuring the USD/minute rate and credits-per-USD conversion. Existing Admin-set conversion values are preserved.
- Live Fish Audio sessions and measured provider settlement still require a real provider key and browser test; no live API test is claimed by this build.
