# PayTrack — Final Android & Web Package (v1.1)

## Included Files
1. `PayTrack_Standalone_App.html` — Open directly in any mobile or desktop browser.
2. `app/` — Complete Android Studio project with `WebView`, `localStorage` persistence, and native Android `PrintManager` PDF export.

## Build APK in Android Studio
1. Open this folder in Android Studio.
2. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
