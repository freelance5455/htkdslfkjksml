# PayTrack — Android APK Project

## Option 1: Instant Install on Android (No PC Required)
1. Copy `app/src/main/assets/index.html` to your phone or open the web app in **Chrome on Android**.
2. Tap the **Chrome Menu (⋮) → Install app / Add to Home screen**.

## Option 2: Compile `PayTrack.apk` in Android Studio
1. Unzip this folder and open it in **Android Studio**.
2. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Your installable `.apk` file will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
