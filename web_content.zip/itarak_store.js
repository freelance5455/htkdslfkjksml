(() => {
  const KEY = 'itarak_store_v3';
  const oldKey = 'itarak_data';
  const blank = { products: [], sales: [], orders: [], customers: [], employees: [] };
  const ADMIN = { id:'admin', name:'مدير النظام', role:'admin', code:'0000' };
  let currentUser = null;
  const $ = id => document.getElementById(id);
  const load = () => { try { const data = JSON.parse(localStorage.getItem(KEY)); return { ...blank, ...(data || {}), employees: (data && data.employees) || [] }; } catch { return { ...blank }; } };
  const save = data => localStorage.setItem(KEY, JSON.stringify(data));
  const money = value => `${(Number(value) || 0).toFixed(2)} د.ل`;
  const date = value => new Date(value).toLocaleDateString('ar-LY', { day:'2-digit', month:'short', year:'numeric' });
  const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const toast = text => { $('toast').textContent = text; $('toast').classList.add('show'); setTimeout(() => $('toast').classList.remove('show'), 2200); };
  const migrate = () => {
    const data = load();
    if (!data.products.length && !data.sales.length) {
      try {
        const legacy = JSON.parse(localStorage.getItem(oldKey));
        if (legacy) {
          data.products = (legacy.products || []).map((p, i) => ({ id:p.id || Date.now()+i, name:p.name || p.pn || 'منتج', qty:Number(p.qty ?? p.pq ?? 0), price:Number(p.price ?? p.ppr ?? 0) }));
          data.sales = (legacy.sales || []).map((s, i) => ({ id:s.id || Date.now()+i, product:s.product || s.sp || 'منتج', qty:Number(s.qty || s.sq || 0), unitPrice:Number(s.unitPrice || s.price || s.spr || 0), discount:Number(s.discount || s.sd || 0), total:Number(s.total || 0), date:s.date || s.created_at || new Date().toISOString() }));
          data.orders = legacy.orders || []; data.customers = legacy.customers || []; save(data);
        }
      } catch {}
    }
  };
  window.showPage = id => {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('active', b.dataset.page === id));
    $(`page-${id}`).classList.add('active');
    if ((id === 'employees' || id === 'settings') && (!currentUser || currentUser.role !== 'admin')) { toast('هذه الصفحة متاحة للمدير فقط'); return showPage('home'); }
    if (currentUser && currentUser.role === 'cashier' && !['home','inventory','sales'].includes(id)) { toast('صلاحية الكاشير تقتصر على البيع وإضافة المنتجات'); return showPage('home'); }
    $('pageTitle').textContent = ({home:'الرئيسية',inventory:'المخزون',invoices:'الفواتير',sales:'فاتورة بيع',orders:'الطلبات',customers:'العملاء',employees:'الموظفين',settings:'الإعدادات'})[id];
    history.replaceState(null, '', `#${id}`); $('sidebar').classList.remove('open'); render();
  };
  function status(q) { return q <= 0 ? '<span class="badge out">نفد المخزون</span>' : q <= 3 ? '<span class="badge low">كمية قليلة</span>' : '<span class="badge good">متوفر</span>'; }
  function renderProducts(data) {
    $('productsTable').innerHTML = data.products.length ? data.products.map(p => `<tr><td class="product-name">${esc(p.name)}</td><td>${p.qty}</td><td>${money(p.price)}</td><td>${status(p.qty)}</td><td><button class="btn btn-light btn-sm" onclick="editProduct('${p.id}')">تعديل</button> <button class="btn btn-danger btn-sm" onclick="deleteProduct('${p.id}')">حذف</button></td></tr>`).join('') : '<tr><td colspan="5" class="empty">لا توجد منتجات بعد. أضف أول منتج للمخزون.</td></tr>';
    $('inventoryCount').textContent = `${data.products.length} منتج`;
  }
  function renderInvoices(data) {
    $('invoicesTable').innerHTML = data.sales.length ? [...data.sales].reverse().map(s => `<tr><td class="product-name">#${String(s.id).slice(-6)}</td><td>${date(s.date)}</td><td>${esc(s.product)}</td><td>${s.qty}</td><td><b>${money(s.total)}</b></td><td><button class="btn btn-light btn-sm" onclick="viewInvoice('${s.id}')">عرض</button> <button class="btn btn-danger btn-sm" onclick="deleteInvoice('${s.id}')">حذف</button></td></tr>`).join('') : '<tr><td colspan="6" class="empty">لا توجد فواتير بعد.</td></tr>';
    $('invoiceCount').textContent = `${data.sales.length} فاتورة`;
  }
  function renderHome(data) {
    const total = data.sales.reduce((sum, s) => sum + Number(s.total || 0), 0);
    $('statInvoices').textContent = data.sales.length; $('statProducts').textContent = data.products.length; $('statRevenue').textContent = money(total); $('statOrders').textContent = data.orders.length;
    $('recentInvoices').innerHTML = data.sales.length ? [...data.sales].reverse().slice(0,4).map(s => `<div style="display:flex;justify-content:space-between;align-items:center;padding:11px 0;border-bottom:1px solid #f0ebe4"><div><b>${esc(s.product)}</b><div class="muted" style="font-size:11px">#${String(s.id).slice(-6)} · ${date(s.date)}</div></div><strong>${money(s.total)}</strong></div>`).join('') : '<div class="empty">ستظهر أحدث فواتيرك هنا</div>';
  }
  function renderEmployees(data) {
    const table = $('employeesTable'); if (!table) return;
    table.innerHTML = data.employees.length ? data.employees.map(e => `<tr><td class="product-name">${esc(e.name)}</td><td><span class="badge ${e.role==='manager'?'good':'low'}">${e.role==='manager'?'مدير':'كاشير'}</span></td><td><b>${esc(e.code)}</b></td><td><button class="btn btn-danger btn-sm" onclick="deleteEmployee('${e.id}')">حذف</button></td></tr>`).join('') : '<tr><td colspan="4" class="empty">لا يوجد موظفون بعد.</td></tr>';
    $('employeeCount').textContent = `${data.employees.length} موظف`;
  }
  function renderOther(data) {
    $('ordersTable').innerHTML = data.orders.length ? [...data.orders].reverse().map(o => `<tr><td>${esc(o.customer || o.oc)}</td><td>${esc(o.phone || o.op || '-')}</td><td>${esc(o.details || o.product || o.ot)}</td><td>${date(o.created_at || Date.now())}</td></tr>`).join('') : '<tr><td colspan="4" class="empty">لا توجد طلبات بعد.</td></tr>';
    $('customersTable').innerHTML = data.customers.length ? [...data.customers].reverse().map(c => `<tr><td class="product-name">${esc(c.name || c.cn)}</td><td>${esc(c.phone || c.cp || '-')}</td><td>${date(c.created_at || Date.now())}</td></tr>`).join('') : '<tr><td colspan="3" class="empty">لا يوجد عملاء بعد.</td></tr>';
    $('saleProduct').innerHTML = '<option value="">اختر المنتج</option>' + data.products.filter(p => p.qty > 0).map(p => `<option value="${p.id}">${esc(p.name)} — ${money(p.price)} (متبقي ${p.qty})</option>`).join('');
  }
  function render() { const data = load(); renderProducts(data); renderInvoices(data); renderHome(data); renderOther(data); renderEmployees(data); document.querySelectorAll('[data-admin-only]').forEach(el => el.style.display = currentUser && currentUser.role === 'admin' ? 'flex' : 'none'); document.querySelectorAll('.nav button').forEach(el => { const restricted=['invoices','orders','customers']; el.style.display = currentUser && currentUser.role === 'cashier' && restricted.includes(el.dataset.page) ? 'none' : 'flex'; }); if ($('currentUser')) $('currentUser').textContent = currentUser ? `الدخول: ${currentUser.name}` : ''; }
  window.editProduct = id => { const p = load().products.find(x => String(x.id) === String(id)); if (!p) return; $('editProductId').value=p.id; $('productName').value=p.name; $('productQty').value=p.qty; $('productPrice').value=p.price; $('productSubmit').textContent='حفظ التعديل'; $('cancelEdit').style.display='inline-block'; showPage('inventory'); window.scrollTo({top:0,behavior:'smooth'}); };
  window.deleteProduct = id => { if (currentUser && currentUser.role === 'cashier') return toast('لا تملك صلاحية حذف المنتجات'); if (!confirm('هل تريد حذف هذا المنتج من المخزون؟')) return; const d=load(); d.products=d.products.filter(p=>String(p.id)!==String(id)); save(d); render(); toast('تم حذف المنتج'); };
  window.deleteInvoice = id => { if (currentUser && currentUser.role === 'cashier') return toast('لا تملك صلاحية حذف الفواتير'); if (!confirm('هل تريد حذف هذه الفاتورة؟')) return; const d=load(); d.sales=d.sales.filter(s=>String(s.id)!==String(id)); save(d); render(); toast('تم حذف الفاتورة'); };
  window.deleteEmployee = id => { if (!currentUser || currentUser.role !== 'admin') return toast('هذه العملية للمدير فقط'); if (!confirm('هل تريد حذف هذا الموظف؟')) return; const d=load(); d.employees=d.employees.filter(e=>String(e.id)!==String(id)); save(d); render(); toast('تم حذف الموظف'); };
  window.viewInvoice = id => { const s=load().sales.find(x=>String(x.id)===String(id)); if(!s)return; $('invoiceDetails').innerHTML=`<p class="muted">رقم الفاتورة: #${String(s.id).slice(-6)}<br>التاريخ: ${date(s.date)}</p><div style="border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding:17px 0;margin:17px 0"><b>${esc(s.product)}</b><div class="muted">الكمية: ${s.qty} × ${money(s.unitPrice)}</div><div class="muted">الخصم: ${money(s.discount)}</div></div><div style="display:flex;justify-content:space-between;align-items:center"><span>الإجمالي</span><span class="invoice-total">${money(s.total)}</span></div><button class="btn btn-primary" style="margin-top:18px;width:100%" onclick="printInvoice('${s.id}')">طباعة الفاتورة</button>`; $('invoiceModal').classList.add('show'); };
  window.closeInvoice = () => $('invoiceModal').classList.remove('show');
  window.printInvoice = id => { const s=load().sales.find(x=>String(x.id)===String(id)); const w=window.open('','_blank'); if(!w)return; w.document.write(`<html dir="rtl"><head><meta charset="utf-8"><title>فاتورة إطارك</title><style>body{font-family:Arial;padding:35px;color:#18232f}h1{font-size:30px}table{width:100%;border-collapse:collapse;margin-top:25px}td,th{border:1px solid #ddd;padding:12px;text-align:right}.total{font-size:22px;font-weight:bold;margin-top:25px}</style></head><body><h1>إطارك</h1><p>محل اللوحات والهدايا</p><hr><p>رقم الفاتورة: #${String(s.id).slice(-6)}<br>التاريخ: ${date(s.date)}</p><table><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr><tr><td>${esc(s.product)}</td><td>${s.qty}</td><td>${money(s.unitPrice)}</td><td>${money(s.total)}</td></tr></table><div class="total">الإجمالي: ${money(s.total)}</div><script>window.print()<\/script></body></html>`); w.document.close(); };
  $('productForm').onsubmit = e => { e.preventDefault(); const d=load(), id=$('editProductId').value, name=$('productName').value.trim(), qty=Number($('productQty').value), price=Number($('productPrice').value); if(id){ const p=d.products.find(x=>String(x.id)===String(id)); Object.assign(p,{name,qty,price}); toast('تم تعديل المنتج'); } else { d.products.push({id:Date.now(),name,qty,price}); toast('تمت إضافة المنتج'); } save(d); e.target.reset(); $('editProductId').value=''; $('productSubmit').textContent='إضافة للمخزون'; $('cancelEdit').style.display='none'; render(); };
  $('cancelEdit').onclick=()=>{ $('productForm').reset(); $('editProductId').value=''; $('productSubmit').textContent='إضافة للمخزون'; $('cancelEdit').style.display='none'; };
  $('saleForm').onsubmit = e => { e.preventDefault(); const d=load(), p=d.products.find(x=>String(x.id)===String($('saleProduct').value)), qty=Number($('saleQty').value), discount=Number($('saleDiscount').value)||0; if(!p)return toast('اختر منتجاً أولاً'); if(qty<=0||p.qty<qty)return toast('الكمية المطلوبة غير متوفرة'); const total=Math.max(0,qty*p.price-discount); p.qty-=qty; d.sales.push({id:Date.now(),product:p.name,qty,unitPrice:p.price,discount,total,date:new Date().toISOString()}); save(d); e.target.reset(); $('saleQty').value=1; render(); toast('تم حفظ الفاتورة وتحديث المخزون'); showPage('invoices'); };
  $('orderForm').onsubmit=e=>{e.preventDefault();const d=load();d.orders.push({id:Date.now(),customer:$('orderCustomer').value,phone:$('orderPhone').value,details:$('orderDetails').value,created_at:new Date().toISOString()});save(d);e.target.reset();render();toast('تم حفظ الطلب');};
  $('employeeForm').onsubmit=e=>{e.preventDefault(); if (!currentUser || currentUser.role !== 'admin') return toast('هذه العملية للمدير فقط'); const d=load(), name=$('employeeName').value.trim(), role=$('employeeRole').value, code=$('employeeCode').value.trim(); if(code==='0000' || d.employees.some(e=>e.code===code)) return toast('رمز الدخول مستخدم مسبقاً أو محجوز'); d.employees.push({id:Date.now(),name,role,code}); save(d); e.target.reset(); render(); toast('تمت إضافة الموظف');};
  $('clearInvoices').onclick=()=>{ if (!currentUser || currentUser.role !== 'admin') return toast('هذه العملية للمدير فقط'); if (!confirm('تحذير: سيتم حذف جميع الفواتير نهائياً. هل أنت متأكد؟')) return; const d=load(); d.sales=[]; save(d); render(); toast('تم حذف جميع الفواتير'); };
  $('loginForm').onsubmit=e=>{e.preventDefault(); const code=$('loginCode').value.trim(); const d=load(); const found=code===ADMIN.code?ADMIN:d.employees.find(x=>x.code===code); if(!found){$('loginError').textContent='الرمز غير صحيح، حاول مرة أخرى.'; return;} currentUser=found; $('loginBack').classList.add('hidden'); $('loginError').textContent=''; $('loginCode').value=''; render(); toast(`مرحباً ${found.name}`);};
  $('customerForm').onsubmit=e=>{e.preventDefault();const d=load();d.customers.push({id:Date.now(),name:$('customerName').value,phone:$('customerPhone').value,created_at:new Date().toISOString()});save(d);e.target.reset();render();toast('تمت إضافة العميل');};
  document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>showPage(b.dataset.page)); $('mobileToggle').onclick=()=> $('sidebar').classList.toggle('open'); $('today').textContent=new Date().toLocaleDateString('ar-LY',{weekday:'long',day:'numeric',month:'long'}); migrate(); render(); const initial=location.hash.slice(1); if(initial && $(`page-${initial}`))showPage(initial);
})();
