CROCTAPE - install guide
Option A (any phone/computer): open index.html in Chrome/Safari. Works offline.
Option B (install like an app): upload this folder to free hosting (e.g. app.netlify.com/drop),
open the link on your phone, then Add to Home Screen / Install app.
Option C (real Android APK): put the hosted link into pwabuilder.com and download the Android package.
