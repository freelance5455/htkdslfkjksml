let toastTimeout;

        // Função global de notificação toast
        function showToast(message, isActive = true) {
            const toast = document.getElementById('toast');
            const toastText = document.getElementById('toastText');
            const toastDot = document.getElementById('toastDot');
            if (!toast) return;

            clearTimeout(toastTimeout);
            toastText.textContent = message;
            toastDot.style.backgroundColor = isActive ? 'var(--accent)' : '#78718f';

            toast.classList.remove('opacity-0', 'translate-y-2');
            toast.classList.add('opacity-100', 'translate-y-0');

            toastTimeout = setTimeout(() => {
                toast.classList.remove('opacity-100', 'translate-y-0');
                toast.classList.add('opacity-0', 'translate-y-2');
            }, 1600);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const checkboxes = document.querySelectorAll('#tab-funcoes .ios-switch input[type="checkbox"]');
            const menuBtn = document.getElementById('menuBtn');
            const closeSidebarBtn = document.getElementById('closeSidebarBtn');
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const sidebarMenuItems = document.querySelectorAll('.sidebar-menu-item');
            const tabViews = document.querySelectorAll('.tab-view');
            const logoutBtn = document.getElementById('logoutBtn');

            // =====================================================
            // 1. NAVEGAÇÃO DO MENU LATERAL (DRAWER)
            // =====================================================
            function openSidebar() {
                sidebar.classList.remove('-translate-x-full');
                sidebarOverlay.classList.remove('opacity-0', 'pointer-events-none');
                sidebarOverlay.classList.add('opacity-100');
            }

            function closeSidebar() {
                sidebar.classList.add('-translate-x-full');
                sidebarOverlay.classList.remove('opacity-100');
                sidebarOverlay.classList.add('opacity-0', 'pointer-events-none');
            }

            menuBtn.addEventListener('click', openSidebar);
            closeSidebarBtn.addEventListener('click', closeSidebar);
            sidebarOverlay.addEventListener('click', closeSidebar);

            sidebarMenuItems.forEach(item => {
                item.addEventListener('click', () => {
                    // Atualiza estilo do item ativo no drawer
                    sidebarMenuItems.forEach(el => {
                        el.classList.remove('bg-[#211d2e]', 'text-white');
                        el.classList.add('text-[#9e98b3]');
                        const iconBox = el.querySelector('.icon-box');
                        iconBox.classList.remove('bg-accent', 'text-white');
                        iconBox.classList.add('bg-[#1b1824]', 'text-[#9e98b3]');
                    });

                    item.classList.remove('text-[#9e98b3]');
                    item.classList.add('bg-[#211d2e]', 'text-white');
                    const activeIcon = item.querySelector('.icon-box');
                    activeIcon.classList.remove('bg-[#1b1824]', 'text-[#9e98b3]');
                    activeIcon.classList.add('bg-accent', 'text-white');

                    // Alterna a aba visível
                    const targetTabId = item.getAttribute('data-tab');
                    tabViews.forEach(view => view.classList.add('hidden'));
                    const targetView = document.getElementById(targetTabId);
                    if (targetView) targetView.classList.remove('hidden');

                    closeSidebar();
                });
            });

            logoutBtn.addEventListener('click', () => {
                closeSidebar();
                showToast('Sessão encerrada', false);
            });

            // Switches da aba Funções
            checkboxes.forEach((checkbox) => {
                checkbox.addEventListener('change', (e) => {
                    const label = e.target.getAttribute('data-label') || 'Função';
                    const isChecked = e.target.checked;
                    if (navigator.vibrate) navigator.vibrate(10);
                    showToast(`${label} ${isChecked ? 'ativado' : 'desativado'}`, isChecked);
                });
            });

            // Botões "Aplicar" da seção Hologramas
            document.querySelectorAll('.apply-btn').forEach((btn) => {
                btn.addEventListener('click', () => {
                    const holoName = btn.getAttribute('data-holo') || 'Holograma';
                    const isApplied = btn.getAttribute('data-applied') === 'true';
                    if (navigator.vibrate) navigator.vibrate(12);

                    if (!isApplied) {
                        btn.setAttribute('data-applied', 'true');
                        btn.textContent = 'Aplicado';
                        btn.classList.remove('bg-accent', 'text-white');
                        btn.classList.add('bg-[#24212e]', 'text-[#a39cb8]');
                        showToast(`${holoName} aplicado`, true);
                    } else {
                        btn.setAttribute('data-applied', 'false');
                        btn.textContent = 'Aplicar';
                        btn.classList.remove('bg-[#24212e]', 'text-[#a39cb8]');
                        btn.classList.add('bg-accent', 'text-white');
                        showToast(`${holoName} removido`, false);
                    }
                });
            });

            // =====================================================
            // 2. ABA TEXTURAS (Zueiras & Insta Player)
            // =====================================================
            const texturesData = [
                { id: 'ben10', name: 'Ben 10', char: 'Maro', cat: 'zueiras', bg: '#1e3a29', badge: 'B10', color: '#2ecc71', maint: false },
                { id: 'goku', name: 'Goku', char: 'Kamir', cat: 'zueiras', bg: '#3b2316', badge: 'GK', color: '#f39c12', maint: false },
                { id: 'jax', name: 'Jax', char: 'Maro', cat: 'zueiras', bg: '#2e1d3b', badge: 'JX', color: '#a855f7', maint: false },
                { id: 'spiderman', name: 'Spiderman', char: '', cat: 'zueiras', bg: '#38181c', badge: 'SP', color: '#ef4444', maint: true },
                { id: 'subway', name: 'Subway Surfers', char: 'Ignis', cat: 'zueiras', bg: '#19323c', badge: 'SB', color: '#38bdf8', maint: false },
                { id: 'sigma', name: 'Sigma', char: 'Maro', cat: 'zueiras', bg: '#363218', badge: 'SG', color: '#eab308', maint: false },
                { id: 'bolsonaro', name: 'Bolsonaro', char: 'Ray', cat: 'zueiras', bg: '#1c2433', badge: 'BR', color: '#60a5fa', maint: false },
                { id: 'toguro', name: 'Toguro', char: 'Maxim', cat: 'zueiras', bg: '#262b1c', badge: 'TG', color: '#84cc16', maint: false },
                // Categoria Insta Player
                { id: 'angelical', name: 'Calça Angelical Azul', char: 'Kelly', cat: 'instaplayer', bg: '#16283d', badge: 'AN', color: '#3b82f6', maint: false },
                { id: 'primeiro_passe', name: 'Primeiro Passe (Sakura)', char: 'Hayato', cat: 'instaplayer', bg: '#3b1d2e', badge: 'SK', color: '#ec4899', maint: false },
                { id: 'top_criminal', name: 'Top Criminal Verde', char: 'Alok', cat: 'instaplayer', bg: '#173624', badge: 'TC', color: '#10b981', maint: false },
                { id: 'barbinha', name: 'Barbinha do Velho', char: 'Maxim', cat: 'instaplayer', bg: '#2b2420', badge: 'BV', color: '#d6d3d1', maint: false }
            ];

            let currentTexCategory = 'zueiras';
            let selectedTexture = null;
            const texturesListEl = document.getElementById('texturesList');
            const selectedTextureLabel = document.getElementById('selectedTextureLabel');
            const injectTextureBtn = document.getElementById('injectTextureBtn');

            function renderTextures() {
                texturesListEl.innerHTML = '';
                const filtered = texturesData.filter(t => t.cat === currentTexCategory);

                filtered.forEach(item => {
                    const isSelected = selectedTexture && selectedTexture.id === item.id;
                    const card = document.createElement('div');
                    card.className = `p-3.5 rounded-2xl bg-[#14121b] border ${isSelected ? 'border-accent' : 'border-white/[0.05]'} flex items-center justify-between gap-3 transition-colors ${item.maint ? 'opacity-65 cursor-not-allowed' : 'cursor-pointer active:bg-[#191622]'}`;

                    card.innerHTML = `
                        <div class="flex items-center gap-3.5">
                            <div class="w-12 h-12 rounded-xl flex flex-col items-center justify-center shrink-0 border border-white/[0.06]" style="background-color: ${item.bg}; color: ${item.color};">
                                <svg class="w-5 h-5 mb-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                                <span class="text-[9px] font-extrabold tracking-wider">${item.badge}</span>
                            </div>
                            <div class="flex flex-col">
                                <span class="text-[15px] font-bold text-[#e6e6eb]">${item.name}</span>
                                ${item.maint
                                    ? `<span class="text-[12px] text-[#9e6b70] mt-0.5 flex items-center gap-1">🔧 Em manutenção</span>`
                                    : `<span class="text-[12.5px] text-[#78718f] mt-0.5">Personagem: ${item.char}</span>`
                                }
                            </div>
                        </div>
                        <div class="pr-1">
                            ${item.maint
                                ? `<span class="text-[#6b6480] text-sm">🔧</span>`
                                : `<span class="w-5 h-5 rounded-full border-2 ${isSelected ? 'border-accent bg-accent' : 'border-[#332e42] bg-[#1c1926]'} flex items-center justify-center transition-colors">
                                     ${isSelected ? '<span class="w-2 h-2 rounded-full bg-white"></span>' : ''}
                                   </span>`
                            }
                        </div>
                    `;

                    if (!item.maint) {
                        card.addEventListener('click', () => {
                            selectedTexture = item;
                            selectedTextureLabel.textContent = `${item.name} (${item.char})`;
                            injectTextureBtn.classList.remove('bg-[#24212e]', 'text-[#78718f]', 'cursor-not-allowed');
                            injectTextureBtn.classList.add('bg-accent', 'text-white', 'cursor-pointer', 'active:scale-95');
                            renderTextures();
                        });
                    }

                    texturesListEl.appendChild(card);
                });
            }

            document.querySelectorAll('.tex-cat-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    currentTexCategory = btn.getAttribute('data-tex-cat');
                    document.querySelectorAll('.tex-cat-btn').forEach(b => {
                        b.classList.remove('bg-accent', 'text-white');
                        b.classList.add('bg-[#181622]', 'text-[#9e98b3]');
                    });
                    btn.classList.remove('bg-[#181622]', 'text-[#9e98b3]');
                    btn.classList.add('bg-accent', 'text-white');
                    renderTextures();
                });
            });

            injectTextureBtn.addEventListener('click', () => {
                if (!selectedTexture) {
                    showToast('Selecione uma textura primeiro', false);
                    return;
                }
                injectTextureBtn.textContent = 'INJETANDO...';
                setTimeout(() => {
                    injectTextureBtn.textContent = 'INJETAR';
                    showToast(`Textura ${selectedTexture.name} injetada!`, true);
                }, 700);
            });

            renderTextures();

            // =====================================================
            // 3. ABA CONECTAR (Shizuku & ADB Wi-Fi)
            // =====================================================
            let shizukuConnected = true;
            const shizukuActionBtn = document.getElementById('shizukuActionBtn');
            const shizukuCard = document.getElementById('shizukuCard');
            const shizukuIndicator = document.getElementById('shizukuIndicator');
            const connectionStatusBanner = document.getElementById('connectionStatusBanner');
            const connectionStatusDot = document.getElementById('connectionStatusDot');
            const connectionStatusText = document.getElementById('connectionStatusText');
            const adbPairBtn = document.getElementById('adbPairBtn');

            shizukuActionBtn.addEventListener('click', () => {
                shizukuConnected = !shizukuConnected;
                if (shizukuConnected) {
                    shizukuActionBtn.textContent = 'DESCONECTAR';
                    shizukuActionBtn.className = 'w-full py-2.5 rounded-full bg-[#241317] hover:bg-[#2e171c] text-[#e74c3c] text-[13px] font-bold tracking-wider uppercase transition-colors cursor-pointer';
                    shizukuCard.classList.add('border-[#2ecc71]/40');
                    shizukuCard.classList.remove('border-white/[0.05]');
                    shizukuIndicator.classList.replace('bg-[#6b6480]', 'bg-[#2ecc71]');
                    connectionStatusBanner.className = 'mt-4 py-3 px-4 rounded-2xl bg-[#10261b] border border-[#2ecc71]/25 flex items-center justify-center gap-2';
                    connectionStatusDot.className = 'w-2 h-2 rounded-full bg-[#2ecc71]';
                    connectionStatusText.className = 'text-[13.5px] font-semibold text-[#2ecc71]';
                    connectionStatusText.textContent = 'Ativo: Shizuku';
                    showToast('Shizuku conectado', true);
                } else {
                    shizukuActionBtn.textContent = 'CONECTAR SHIZUKU';
                    shizukuActionBtn.className = 'w-full py-2.5 rounded-full bg-accent text-white text-[13px] font-bold tracking-wider uppercase transition-colors cursor-pointer';
                    shizukuCard.classList.remove('border-[#2ecc71]/40');
                    shizukuCard.classList.add('border-white/[0.05]');
                    shizukuIndicator.classList.replace('bg-[#2ecc71]', 'bg-[#6b6480]');
                    connectionStatusBanner.className = 'mt-4 py-3 px-4 rounded-2xl bg-[#1c1418] border border-[#e74c3c]/25 flex items-center justify-center gap-2';
                    connectionStatusDot.className = 'w-2 h-2 rounded-full bg-[#e74c3c]';
                    connectionStatusText.className = 'text-[13.5px] font-semibold text-[#e74c3c]';
                    connectionStatusText.textContent = 'Desconectado — escolha um método';
                    showToast('Shizuku desconectado', false);
                }
            });

            adbPairBtn.addEventListener('click', () => {
                showToast('Abrindo Opções do Desenvolvedor...', true);
                
                const devSettingsIntent = 'intent:#Intent;action=android.settings.APPLICATION_DEVELOPMENT_SETTINGS;end';
                const generalSettingsIntent = 'intent:#Intent;action=android.settings.SETTINGS;end';
                
                try {
                    window.location.href = devSettingsIntent;
                    setTimeout(() => {
                        if (document.hasFocus()) {
                            window.location.href = generalSettingsIntent;
                        }
                    }, 800);
                } catch (err) {
                    showToast('Abra manualmente: Config. > Opções do desenvolvedor', false);
                }
            });

            // =====================================================
            // 4. ABA CONFIGS (Cor, Modo RGB e Ícones Disfarce)
            // =====================================================
            let savedAccentColor = '#6549D6';
            let previewAccentColor = '#6549D6';
            let rgbInterval = null;

            const colorPreviewBox = document.getElementById('colorPreviewBox');
            const nativeColorPicker = document.getElementById('nativeColorPicker');
            const hexColorInput = document.getElementById('hexColorInput');
            const colorSpectrumBox = document.getElementById('colorSpectrumBox');
            const hueRangeSlider = document.getElementById('hueRangeSlider');
            const rgbModeToggle = document.getElementById('rgbModeToggle');
            const saveColorBtn = document.getElementById('saveColorBtn');
            const resetColorBtn = document.getElementById('resetColorBtn');

            function updateColorPreview(hex) {
                previewAccentColor = hex.toUpperCase();
                colorPreviewBox.style.backgroundColor = previewAccentColor;
                nativeColorPicker.value = previewAccentColor;
                hexColorInput.value = previewAccentColor;
                colorSpectrumBox.style.background = `linear-gradient(to bottom, transparent, #09080c), linear-gradient(to right, #ffffff, ${previewAccentColor})`;
            }

            function applyThemeColor(hex) {
                document.documentElement.style.setProperty('--accent', hex);
            }

            function hslToHex(h, s, l) {
                l /= 100;
                const a = s * Math.min(l, 1 - l) / 100;
                const f = n => {
                    const k = (n + h / 30) % 12;
                    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
                    return Math.round(255 * color).toString(16).padStart(2, '0');
                };
                return `#${f(0)}${f(8)}${f(4)}`.toUpperCase();
            }

            hueRangeSlider.addEventListener('input', (e) => {
                const hex = hslToHex(Number(e.target.value), 72, 58);
                updateColorPreview(hex);
            });

            nativeColorPicker.addEventListener('input', (e) => {
                updateColorPreview(e.target.value);
            });

            hexColorInput.addEventListener('input', (e) => {
                let val = e.target.value.trim();
                if (!val.startsWith('#')) val = '#' + val;
                if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
                    updateColorPreview(val);
                }
            });

            document.querySelectorAll('.preset-color-dot').forEach(dot => {
                dot.addEventListener('click', () => {
                    const color = dot.getAttribute('data-preset-color');
                    updateColorPreview(color);
                });
            });

            saveColorBtn.addEventListener('click', () => {
                if (rgbModeToggle.checked) {
                    rgbModeToggle.checked = false;
                    clearInterval(rgbInterval);
                }
                savedAccentColor = previewAccentColor;
                applyThemeColor(savedAccentColor);
                showToast(`Cor ${savedAccentColor} salva!`, true);
            });

            resetColorBtn.addEventListener('click', () => {
                if (rgbModeToggle.checked) {
                    rgbModeToggle.checked = false;
                    clearInterval(rgbInterval);
                }
                savedAccentColor = '#6549D6';
                updateColorPreview(savedAccentColor);
                applyThemeColor(savedAccentColor);
                hueRangeSlider.value = 252;
                showToast('Cor padrão restaurada', true);
            });

            rgbModeToggle.addEventListener('change', (e) => {
                if (e.target.checked) {
                    let hue = 0;
                    showToast('Modo RGB ativado 🌈', true);
                    rgbInterval = setInterval(() => {
                        hue = (hue + 4) % 360;
                        const rgbHex = hslToHex(hue, 72, 58);
                        applyThemeColor(rgbHex);
                        updateColorPreview(rgbHex);
                    }, 75);
                } else {
                    clearInterval(rgbInterval);
                    applyThemeColor(savedAccentColor);
                    updateColorPreview(savedAccentColor);
                    showToast('Modo RGB desativado', false);
                }
            });

            // Grade 3x5 de Apps Disfarce
            const disguiseApps = [
                { id: 'chatgpt', name: 'ChatGPT', bg: '#ffffff', fg: '#10a37f', symbol: '✳' },
                { id: 'nubank', name: 'Nubank', bg: '#820ad1', fg: '#ffffff', symbol: 'nu' },
                { id: 'infinitepay', name: 'InfinitePay', bg: '#f4f4f6', fg: '#111111', symbol: '◉' },
                { id: 'shopee', name: 'Shopee', bg: '#ee4d2d', fg: '#ffffff', symbol: 'S' },
                { id: 'uber', name: 'Uber', bg: '#09090b', fg: '#ffffff', symbol: 'Uber' },
                { id: 'duolingo', name: 'Duolingo', bg: '#58cc02', fg: '#ffffff', symbol: '🦉' },
                { id: 'kwai', name: 'Kwai', bg: '#ff4906', fg: '#ffffff', symbol: '🎥' },
                { id: 'mercadolivre', name: 'Mercado Livre', bg: '#ffe600', fg: '#2d3277', symbol: '🤝' },
                { id: 'mercadopago', name: 'Mercado Pago', bg: '#ffffff', fg: '#009ee3', symbol: 'MP' },
                { id: 'pagbank', name: 'PagBank', bg: '#00a859', fg: '#ffffff', symbol: 'PB' },
                { id: 'picpay', name: 'PicPay', bg: '#11c76f', fg: '#ffffff', symbol: 'P' },
                { id: 'ton', name: 'Ton', bg: '#00d700', fg: '#0a0a0a', symbol: 'ton' },
                { id: 'reelshort', name: 'ReelShort', bg: '#e11d48', fg: '#ffffff', symbol: 'R' },
                { id: 'c6bank', name: 'C6 Bank', bg: '#18181b', fg: '#ffffff', symbol: 'C6' },
                { id: 'dola', name: 'Dola', bg: '#f5f3ff', fg: '#7c3aed', symbol: '◈' }
            ];

            let selectedDisguiseId = 'infinitepay';
            const disguiseGridEl = document.getElementById('disguiseAppsGrid');

            function renderDisguiseApps() {
                disguiseGridEl.innerHTML = '';
                disguiseApps.forEach(app => {
                    const isSelected = app.id === selectedDisguiseId;
                    const card = document.createElement('button');
                    card.type = 'button';
                    card.className = `p-3 rounded-2xl bg-[#14121b] border ${isSelected ? 'border-accent bg-accent-soft' : 'border-white/[0.05]'} flex flex-col items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer`;

                    card.innerHTML = `
                        <div class="w-11 h-11 rounded-xl flex items-center justify-center font-extrabold text-[15px] shadow-sm" style="background-color: ${app.bg}; color: ${app.fg};">
                            ${app.symbol}
                        </div>
                        <span class="text-[11.5px] font-medium ${isSelected ? 'text-white' : 'text-[#9e98b3]'} truncate w-full text-center">${app.name}</span>
                    `;

                    card.addEventListener('click', () => {
                        selectedDisguiseId = app.id;
                        renderDisguiseApps();
                        showToast(`Ícone disfarce: ${app.name}`, true);
                    });

                    disguiseGridEl.appendChild(card);
                });
            }

            renderDisguiseApps();

            // =====================================================
            // 5. ABA BYPASS (Botão de Pânico & Limpeza Simulada)
            // =====================================================
            const activateBypassBtn = document.getElementById('activateBypassBtn');
            const bypassModal = document.getElementById('bypassModal');
            const cancelBypassBtn = document.getElementById('cancelBypassBtn');
            const confirmBypassBtn = document.getElementById('confirmBypassBtn');
            const bypassModalTitle = document.getElementById('bypassModalTitle');
            const bypassModalDesc = document.getElementById('bypassModalDesc');
            const bypassProgressWrap = document.getElementById('bypassProgressWrap');
            const bypassProgressBar = document.getElementById('bypassProgressBar');
            const bypassStepText = document.getElementById('bypassStepText');
            const bypassModalActions = document.getElementById('bypassModalActions');

            activateBypassBtn.addEventListener('click', () => {
                bypassModalTitle.textContent = 'Confirmar Bypass AP?';
                bypassModalDesc.textContent = 'Todas as funções serão desativadas e os rastros da proxy serão limpos imediatamente.';
                bypassProgressWrap.classList.add('hidden');
                bypassProgressBar.style.width = '0%';
                bypassModalActions.classList.remove('hidden');
                bypassModal.classList.remove('hidden');
            });

            cancelBypassBtn.addEventListener('click', () => {
                bypassModal.classList.add('hidden');
            });

            confirmBypassBtn.addEventListener('click', () => {
                bypassModalActions.classList.add('hidden');
                bypassProgressWrap.classList.remove('hidden');
                bypassModalTitle.textContent = 'Executando Bypass...';

                // Desmarca todos os switches ativos
                checkboxes.forEach(cb => cb.checked = false);

                setTimeout(() => {
                    bypassProgressBar.style.width = '40%';
                    bypassStepText.textContent = 'Removendo arquivos temporários da proxy...';
                }, 200);

                setTimeout(() => {
                    bypassProgressBar.style.width = '80%';
                    bypassStepText.textContent = 'Limpando logs de memória...';
                }, 750);

                setTimeout(() => {
                    bypassProgressBar.style.width = '100%';
                    bypassStepText.textContent = 'Limpeza concluída com sucesso!';
                    bypassModalTitle.textContent = 'Bypass Concluído';
                }, 1300);

                setTimeout(() => {
                    bypassModal.classList.add('hidden');
                    showToast('Todos os rastros foram limpos', true);
                }, 2000);
            });
        });