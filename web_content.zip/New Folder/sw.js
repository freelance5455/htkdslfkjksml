const CACHE_NAME = 'proxy-android-v6';
const ASSETS = ['./', './index.html', './css/style.css', './js/app.js', './manifest.json', './assets/icon.svg'];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => response || fetch(event.request))
  );
});
