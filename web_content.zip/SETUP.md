# Daily Progress Manager V3 — Supabase setup

The Android/Web app is already configured with the Supabase Project URL and publishable key supplied for this project.

## A. Run the database SQL

1. Open your Supabase project dashboard.
2. Open **SQL Editor** → **New query**.
3. Open `supabase-schema.sql` from this ZIP and paste the whole file.
4. Click **Run**.

## B. Create the first administrator

1. Open **Authentication → Users**.
2. Choose **Add user** / **Create user**.
3. Enter the administrator email and password and create the user.
4. Return to **SQL Editor** and run this, replacing the email:

```sql
update public.profiles
set role = 'admin'
where email = 'YOUR_ADMIN_EMAIL';
```

The profile row is created automatically by the trigger in `supabase-schema.sql`.

## C. Deploy the admin-create-user Edge Function

The app's administrator screen calls:

`/functions/v1/admin-create-user`

The source is in:

`supabase/functions/admin-create-user/index.ts`

Deploy that function from the Supabase dashboard's Edge Functions area, or with the Supabase CLI. The function uses the server-side `SUPABASE_SERVICE_ROLE_KEY` automatically supplied by Supabase. **Do not put that key in the Android app.**

### Dashboard deployment

1. Open **Edge Functions**.
2. Create a function named exactly `admin-create-user`.
3. Replace its generated code with the contents of `supabase/functions/admin-create-user/index.ts`.
4. Deploy it.

No service-role key needs to be copied into the app.

## D. Build the Android app

Open the `android` folder in Android Studio or AndroidIDE and build the APK.

The app includes the Android `INTERNET` permission and is already configured to use the supplied Supabase project.

## Security

The publishable key is intended for client-side use. Database security is enforced with Row Level Security. Never place a Supabase service-role/secret key in the APK, HTML, JavaScript, or any other client-side file.
