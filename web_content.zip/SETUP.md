# Build and ship Protwave

1. **Run it.** Install Rust and Node 20 (Linux also: webkit2gtk-4.1, libxdo). `npm install`, `npx tauri icon app-icon.png`, `npm run dev`. The window is hidden on purpose: press your hotkey. First launch shows a setup card.
2. **Installers.** Push to GitHub and run the `build` workflow (Mac, Windows, Linux). Publish the draft release and share that link. Counts of downloads are visible on the release page (GitHub tracks them).
3. **Signed price updates (recommended).** `node tools/keys.mjs` prints a PUBLIC key: paste it into `src-tauri/ledger_pubkey.txt`. Store `ledger_private.pem` as the GitHub secret `LEDGER_PRIVATE_KEY`, then delete the file. Edit `ledger/ledger.json` (bump `updated`, refresh `fx`), push, and the `sign-ledger` workflow writes `ledger.json.sig`. Set `ledgerUrl` in `src/config.js` to your repo's raw URL. With no public key the app ignores remote updates and uses the bundled ledger.
4. **Exact DeepSeek counts (optional).** Save DeepSeek's public `tokenizer.json` as `src-tauri/tokenizers/deepseek.json` before building.
5. **Feedback + anonymous usage (optional, no website needed).** Create a Supabase project, run `supabase/schema.sql` (replace YOU@EXAMPLE.COM), deploy `supabase/functions/submit-feedback`, set secrets `POW_SECRET` and `RL_SALT`, then put the Project URL and anon key in `src/config.js`. Read the data in Supabase's Table Editor or with the queries at the bottom of the schema. Leave `url` empty to disable all networking except price updates.

## Code signing (the warnings)
Code can't remove the macOS/Windows warnings; signing identities do. Verify current prices and rules.
- macOS: Apple Developer Program (about $99/year) to sign and notarize; the account holder generally must be an adult. Add the APPLE_* secrets in `.github/workflows/build.yml`.
- Windows: Azure Trusted Signing (monthly fee) or SignPath Foundation (free for qualifying open-source projects).
- Until then, first-run setup shows OS-specific "Open anyway" steps.

## Hotkey
Default is Alt+Shift+T. Users can change it in the card's settings, or pick Ctrl/Cmd+Shift+T during first-run setup.
