# GODEX Google Colab GPU Worker

This directory contains the authoritative configuration and worker scripts for running dedicated GPU-accelerated video generation in Google Colab connected to GODEX.

## Files
- `godex_colab_gpu_worker.ipynb`: Ready-to-use Jupyter Notebook for Google Colab.
- `godex_colab_worker.py`: Python CLI worker script for headless execution or automated evaluation.

## How to Run in Google Colab
1. Upload `godex_colab_gpu_worker.ipynb` to [Google Colab](https://colab.research.google.com).
2. Set Runtime Type to **GPU** (T4, L4, or A100).
3. Set your `GODEX_APP_URL`.
4. Run all cells in order.
5. The notebook will detect the GPU, load the diffusion pipeline, generate the video, and send the verified MP4 + SHA-256 directly to GODEX.
