Cyber Seekho Android Project

Yeh Android Studio project hai. App ke andar offline HTML learning experience bundled hai.

APK banane ke steps:
1) Android Studio install karein (computer par).
2) ZIP extract karein aur CyberSeekhoAndroid folder Android Studio mein Open karein.
3) Android Studio ke prompts se Gradle sync aur SDK install complete karein.
4) Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
5) APK location Android Studio ke Build output link mein milegi.

Note: Is workspace mein Android SDK/Gradle build tools maujood nahi, isliye APK compile yahan verify nahi ki gayi.
App offline WebView mein bundled course HTML kholta hai; progress/notes local browser storage mein save hotay hain.
