/* ============================================================
   ads.js — مدیریت تبلیغات PromptVerse
   ------------------------------------------------------------
   ساختار: «ارائه‌دهنده» (Provider) قابل تعویض.
   - تا وقتی شناسه‌های واقعی در CONFIG وارد نشوند، تبلیغی نمایش
     داده نمی‌شود و برنامه طبق سیاست onUnavailable رفتار می‌کند
     (پیش‌فرض: کپی مستقیم، تا کاربر هرگز از کپی محروم نشود).
   - هیچ شناسه یا SDK ساختگی در این فایل نیست.
   - ارائه‌دهنده‌ی «adivery» از SDK جاوااسکریپت رسمی Adivery
     (بسته adivery-js) استفاده می‌کند. API آن:
       Adivery.configure(appId)
       Adivery.requestInterstitialAd(placementId) → ad.show()
       Adivery.requestRewardedAd(placementId)     → ad.show() → true/false
     ⚠️ سازگاری این SDK وبی با WebView داخل APK و پذیرش آن توسط
     Adivery باید توسط خود شما آزمایش شود؛ من آن را آزمایش نکرده‌ام.
   ============================================================ */
(function (global) {
  "use strict";

  /* ---------- تنظیمات (فقط اینجا را ویرایش کنید) ---------- */
  var CONFIG = {
    provider: "adivery",       // "none" یا "adivery" یا نام ارائه‌دهنده‌ای که ثبت می‌کنید
    requestTimeoutMs: 8000,    // حداکثر انتظار برای آماده شدن تبلیغ
    onUnavailable: "copy",     // اگر تبلیغ نبود/آفلاین بود: "copy" (کپی مستقیم) یا "block"
    onEarlyClose: "block",     // اگر کاربر زود بست: "copy" یا "block" (block = بدون پاداش، کپی نمی‌شود)
    providers: {
      adivery: {
        appId: "4dbfd7f5-7778-4c57-96e4-6bad3c9ceb7a", // شناسه برنامه از پنل Adivery (خالی = غیرفعال)
        placementId: "f05ab4a7-8e2d-456b-b638-ce7bd79c1feb", // شناسه جایگاه تبلیغ از پنل Adivery
        sdkUrl: "",            // آدرس رسمی فایل adivery.global.js طبق مستندات Adivery
        adType: "rewarded"     // "interstitial" یا "rewarded"
      }
    }
  };

  var registry = {};   // ارائه‌دهنده‌های ثبت‌شده
  var busy = false;    // جلوگیری از اجرای هم‌زمان چند تبلیغ
  var initPromise = null;

  /* ---------- ابزارهای کمکی ---------- */
  function withTimeout(promise, ms, label) {
    return new Promise(function (resolve, reject) {
      var t = setTimeout(function () { reject(new Error(label || "timeout")); }, ms);
      promise.then(function (v) { clearTimeout(t); resolve(v); },
                   function (e) { clearTimeout(t); reject(e); });
    });
  }

  function loadScript(url) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = url;
      s.async = true;
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error("sdk-load-failed")); };
      document.head.appendChild(s);
    });
  }

  function isOnline() {
    return typeof navigator.onLine === "boolean" ? navigator.onLine : true;
  }

  /* ---------- ارائه‌دهنده Adivery (SDK وب رسمی) ---------- */
  registry.adivery = {
    ready: false,
    init: function (cfg) {
      var self = this;
      if (!cfg || !cfg.appId || !cfg.placementId || !cfg.sdkUrl) {
        return Promise.reject(new Error("not-configured"));
      }
      var ready = global.Adivery ? Promise.resolve() : loadScript(cfg.sdkUrl);
      return ready.then(function () {
        if (!global.Adivery || typeof global.Adivery.configure !== "function") {
          throw new Error("sdk-missing");
        }
        global.Adivery.configure(cfg.appId);
        self.ready = true;
      });
    },
    isReady: function () { return this.ready; },
    show: function (cfg) {
      var A = global.Adivery;
      if (cfg.adType === "rewarded") {
        return A.requestRewardedAd(cfg.placementId).then(function (ad) {
          return ad.show();
        }).then(function (watched) {
          return { completed: watched === true };
        });
      }
      return A.requestInterstitialAd(cfg.placementId).then(function (ad) {
        return ad.show();
      }).then(function () {
        // در حالت interstitial، SDK فقط «نمایش داده شد» را اعلام می‌کند
        return { completed: true };
      });
    }
  };

  /* ---------- API عمومی ---------- */
  var PromptAds = {
    /** ادغام تنظیمات جدید (اختیاری، قبل از init) */
    configure: function (partial) {
      if (!partial) return;
      Object.keys(partial).forEach(function (k) {
        if (k === "providers" && partial.providers) {
          Object.keys(partial.providers).forEach(function (p) {
            CONFIG.providers[p] = Object.assign({}, CONFIG.providers[p], partial.providers[p]);
          });
        } else {
          CONFIG[k] = partial[k];
        }
      });
    },

    /** ثبت شبکه تبلیغاتی جدید: { init(cfg), isReady(), show(cfg) → Promise<{completed}> } */
    registerProvider: function (name, impl) { registry[name] = impl; },

    /** آماده‌سازی ارائه‌دهنده انتخاب‌شده؛ هرگز خطا پرتاب نمی‌کند */
    init: function () {
      if (initPromise) return initPromise;
      var p = registry[CONFIG.provider];
      if (!p) { initPromise = Promise.resolve(false); return initPromise; }
      initPromise = withTimeout(
        Promise.resolve(p.init(CONFIG.providers[CONFIG.provider])),
        CONFIG.requestTimeoutMs, "init-timeout"
      ).then(function () { return true; }, function () {
        initPromise = null; // اجازه تلاش دوباره
        return false;
      });
      return initPromise;
    },

    isReady: function () {
      var p = registry[CONFIG.provider];
      return !!(p && p.isReady && p.isReady());
    },

    /**
     * نمایش تبلیغ. همیشه resolve می‌شود با:
     * { status: "completed" | "dismissed" | "unavailable" | "error" | "busy" }
     */
    showAd: function () {
      if (busy) return Promise.resolve({ status: "busy" });
      var p = registry[CONFIG.provider];
      if (!p || !isOnline()) return Promise.resolve({ status: "unavailable" });

      busy = true;
      return PromptAds.init().then(function (ok) {
        if (!ok || !p.isReady()) return { status: "unavailable" };
        return withTimeout(
          Promise.resolve(p.show(CONFIG.providers[CONFIG.provider])),
          CONFIG.requestTimeoutMs + 60000, "show-timeout"
        ).then(function (r) {
          return { status: r && r.completed ? "completed" : "dismissed" };
        });
      }).catch(function () {
        return { status: "error" };
      }).then(function (result) {
        busy = false;
        return result;
      });
    },

    /** سیاست: بعد از این نتیجه، پرامپت کپی شود؟ */
    shouldCopy: function (result) {
      var s = result && result.status;
      if (s === "completed") return true;
      if (s === "busy") return false;
      if (s === "dismissed") return CONFIG.onEarlyClose !== "block";
      return CONFIG.onUnavailable !== "block"; // unavailable | error
    }
  };

  global.PromptAds = PromptAds;
})(window);
