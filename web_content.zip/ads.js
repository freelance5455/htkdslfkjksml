// Unity Ads Integration for LOIE RUN 2.0 (Cordova / Android APK)
const UNITY_GAME_ID = '800413373';
const BANNER_PLACEMENT_ID = 'BP_Banner_Android';
const INTERSTITIAL_PLACEMENT_ID = 'BP_Interstitial_Android';
const REWARDED_PLACEMENT_ID = 'BP_Rewarded_Android';
const TEST_MODE = false;

let roundCounter = 0;
let isAdsInitialized = false;

// 1. Cordova Lifecycle Listener
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    console.log("Cordova Device Ready. Initializing Unity Ads...");
    initUnityAds();
}

// 2. Unity Ads SDK Initialization
function initUnityAds() {
    if (typeof unityAds !== 'undefined') {
        unityAds.initialize(UNITY_GAME_ID, TEST_MODE, function() {
            console.log("Unity Ads Initialized Successfully.");
            isAdsInitialized = true;
            preloadAds();
            showBannerAd();
        }, function(error) {
            console.error("Unity Ads Initialization Failed:", error);
        });
    } else if (typeof UnityAds !== 'undefined') {
        UnityAds.initialize(UNITY_GAME_ID, TEST_MODE, {
            onSuccess: function() {
                console.log("Unity Ads Web Initialized.");
                isAdsInitialized = true;
                showBannerAd();
            },
            onFailed: function(err) {
                console.error("Unity Ads Web Init Failed:", err);
            }
        });
    } else {
        console.warn("Unity Ads SDK not detected.");
    }
}

// 3. Preload Ads
function preloadAds() {
    if (typeof unityAds !== 'undefined' && isAdsInitialized) {
        unityAds.load(INTERSTITIAL_PLACEMENT_ID);
        unityAds.load(REWARDED_PLACEMENT_ID);
    }
}

// 4. Show Banner Ad
function showBannerAd() {
    if (typeof unityAds !== 'undefined' && isAdsInitialized) {
        unityAds.showBanner(BANNER_PLACEMENT_ID);
    } else if (typeof UnityAds !== 'undefined' && UnityAds.isReady(BANNER_PLACEMENT_ID)) {
        UnityAds.showBanner(BANNER_PLACEMENT_ID);
    }
}

// 5. Round Completion Counter
function onRoundComplete() {
    roundCounter++;
    console.log("Round Completed. Current Count: " + roundCounter);
    if (roundCounter >= 3) {
        showInterstitialAd();
        roundCounter = 0;
    }
}

// 6. Show Interstitial Ad
function showInterstitialAd() {
    if (typeof unityAds !== 'undefined' && isAdsInitialized) {
        unityAds.show(INTERSTITIAL_PLACEMENT_ID, function() {
            console.log("Interstitial Ad Closed. Reloading...");
            unityAds.load(INTERSTITIAL_PLACEMENT_ID);
        }, function(err) {
            console.error("Error showing Interstitial Ad:", err);
            unityAds.load(INTERSTITIAL_PLACEMENT_ID);
        });
    } else if (typeof UnityAds !== 'undefined' && UnityAds.isReady(INTERSTITIAL_PLACEMENT_ID)) {
        UnityAds.show(INTERSTITIAL_PLACEMENT_ID);
    } else {
        console.log("Interstitial Ad is not ready yet.");
    }
}

// 7. Show Rewarded Ad
function showRewardedAdButton() {
    if (typeof unityAds !== 'undefined' && isAdsInitialized) {
        unityAds.show(REWARDED_PLACEMENT_ID, function(result) {
            console.log("Rewarded Ad Completed:", result);
            grant100CoinsReward();
            unityAds.load(REWARDED_PLACEMENT_ID);
        }, function(err) {
            alert("تعذر تحميل الإعلان، يرجى المحاولة لاحقاً.");
            unityAds.load(REWARDED_PLACEMENT_ID);
        });
    } else if (typeof UnityAds !== 'undefined' && UnityAds.isReady(REWARDED_PLACEMENT_ID)) {
        UnityAds.show(REWARDED_PLACEMENT_ID, {
            onSuccess: function(placementId, state) {
                if (state === 'COMPLETED' || state === 1) {
                    grant100CoinsReward();
                }
            },
            onFailed: function(err) {
                alert("تعذر عرض الإعلان حالياً.");
            }
        });
    } else {
        grant100CoinsReward();
    }
}

// 8. Grant Reward
function grant100CoinsReward() {
    if (typeof state !== 'undefined' && state.coins !== undefined) {
        state.coins += 100;
        if (typeof saveState === 'function') saveState();
        if (typeof updateUI === 'function') updateUI();
    }
    alert("تهانينا! لقد حصلت على 100 كوين 🪙 بنجاح!");
}
