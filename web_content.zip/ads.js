/* Apkomini ads loader — Adcash interstitial + 300x250 display banner slots */
(function () {
  window.OmniAds = {
    // Fire the Adcash interstitial, then continue (used by download buttons)
    serveAd: function (done) {
      try { if (window.OmniPop) window.OmniPop.fire(); } catch (e) {}
      try {
        if (window.OmniAclib && window.OmniAclib.interstitial) window.OmniAclib.interstitial();
        else if (window.aclib) window.aclib.runInterstitial({ zoneId: "12067482" });
      } catch (e) {}
      setTimeout(function () { if (typeof done === "function") done(); }, 600);
    },

    rearm: function () { try { if (window.OmniPop) window.OmniPop.fire(); } catch (e) {} },

    // Insert a 300x250 display banner into `target` (optionally before a node)
    placeBanner: function (target, beforeNode) {
      if (!target) return;
      var el = document.createElement("div");
      el.className = "adslot";
      if (beforeNode) target.insertBefore(el, beforeNode);
      else target.appendChild(el);
      try { if (window.OmniPop) window.OmniPop.fire(); } catch (e) {}
      try {
        if (window.OmniAclib && window.OmniAclib.banner) window.OmniAclib.banner(el);
      } catch (e) {}
      return el;
    }
  };
})();
