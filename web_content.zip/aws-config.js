/**
 * Maa Annapurna Tiffin Service - AWS Cloud Configuration
 * Location: Kunwar Singh Nagar | Contact: +91 9311155593
 * 
 * Supports AWS Cognito User Pools, API Gateway & DynamoDB
 */

const AWS_CONFIG = {
  // 1. AWS Region (e.g. 'ap-south-1' for Asia Pacific - Mumbai)
  region: 'ap-south-1',

  // 2. AWS Cognito User Pool Details
  // Create in AWS Cognito Console -> User Pools
  userPoolId: '', // e.g. 'ap-south-1_aBcDeFg12'
  clientId: '',   // e.g. '3ab12cd34ef56gh78ij90klmn' (Public App Client - No Client Secret)

  // 3. AWS API Gateway HTTP/REST Endpoint
  // Deployed API Gateway pointing to the Lambda function
  apiGatewayUrl: '', // e.g. 'https://xxxxxx.execute-api.ap-south-1.amazonaws.com'

  // 4. DynamoDB Table Name
  tableName: 'TiffinTrackerData',

  // Verification helper
  isConfigured: function () {
    return Boolean(
      this.userPoolId && 
      this.userPoolId.trim() !== '' && 
      this.clientId && 
      this.clientId.trim() !== '' && 
      this.apiGatewayUrl && 
      this.apiGatewayUrl.trim() !== ''
    );
  }
};

// Load any runtime AWS overrides saved from the In-App Cloud Settings modal
(function initAwsSettings() {
  try {
    const saved = localStorage.getItem('annapurna_aws_settings');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.region) AWS_CONFIG.region = parsed.region.trim();
      if (parsed.userPoolId) AWS_CONFIG.userPoolId = parsed.userPoolId.trim();
      if (parsed.clientId) AWS_CONFIG.clientId = parsed.clientId.trim();
      if (parsed.apiGatewayUrl) AWS_CONFIG.apiGatewayUrl = parsed.apiGatewayUrl.trim().replace(/\/+$/, '');
      if (parsed.tableName) AWS_CONFIG.tableName = parsed.tableName.trim();
    }
  } catch (err) {
    console.error('Error loading AWS configuration:', err);
  }
})();

// Helper to save settings from GUI
function saveAwsConfigToStorage(config) {
  try {
    if (config.region) AWS_CONFIG.region = config.region.trim();
    if (config.userPoolId) AWS_CONFIG.userPoolId = config.userPoolId.trim();
    if (config.clientId) AWS_CONFIG.clientId = config.clientId.trim();
    if (config.apiGatewayUrl) AWS_CONFIG.apiGatewayUrl = config.apiGatewayUrl.trim().replace(/\/+$/, '');
    if (config.tableName) AWS_CONFIG.tableName = config.tableName.trim();

    localStorage.setItem('annapurna_aws_settings', JSON.stringify({
      region: AWS_CONFIG.region,
      userPoolId: AWS_CONFIG.userPoolId,
      clientId: AWS_CONFIG.clientId,
      apiGatewayUrl: AWS_CONFIG.apiGatewayUrl,
      tableName: AWS_CONFIG.tableName
    }));
    return true;
  } catch (err) {
    console.error('Failed to save AWS config:', err);
    return false;
  }
}

// Reset AWS settings
function resetAwsConfigStorage() {
  localStorage.removeItem('annapurna_aws_settings');
  AWS_CONFIG.userPoolId = '';
  AWS_CONFIG.clientId = '';
  AWS_CONFIG.apiGatewayUrl = '';
  AWS_CONFIG.region = 'ap-south-1';
  AWS_CONFIG.tableName = 'TiffinTrackerData';
}
