# Deep source audit and rebuild — 2.6.0

## Audited archive
`ANONYMOUX_STUDIO_2.5.9_EXPLORE_REMOVAL_REALTIME_PRICING_RECHECK.zip`

## Architecture preserved
- PHP 8.x application structure and existing routes.
- Existing session authentication and admin role checks.
- PDO database abstraction and SQLite/MySQL support.
- Existing credit wallet, ledger and idempotency services.
- Existing Fish Audio encrypted key vault.
- Existing Decart Image/Video/Realtime and Magic Hour integrations.
- Existing Flutterwave payment integration and resource centre.

## Findings and repairs

### User dashboard/sidebar
- Replaced flat, legacy green sidebar with grouped Dashboard, Creative Workspaces, AI Creation, Your Library, Account and Administration navigation on both the shared page shell and the separately-rendered Realtime Studio shell.
- Added correct active-state handling for agent conversations and WhatsApp setup anchor.
- Renamed destinations to Voice Cloning Studio and Video Edit Studio.
- Removed duplicate generic New Project and Upload Reference quick-create shortcuts.
- Added direct dashboard shortcuts for Voice Cloning Studio and AI Agent Studio.
- Applied the official black/red palette to sidebar, dashboard, voice and agent surfaces.

### Voice Cloning Studio
- Added a real Fish Audio persistent private voice model workflow.
- Requires ownership/permission consent and records consent version/time.
- Supports WAV, MP3, M4A and OPUS uploads; validates MIME, file signature, extension and size.
- Adds browser recording only when Ogg/Opus MediaRecorder is supported.
- Stores private provider voice IDs against the creating Anonymoux user.
- Prevents other users from listing or using those private voices.
- Adds optional per-clone ANON credit cost (admin default 0) and idempotent clone request tracking.
- Adds owner-only delete with a guard against deleting voices assigned to that user's agents.

### AI Agent Studio
- Kept the existing server-side Fish Audio Agent adapter and SDK-based conversation flow.
- Added searchable agent cards and draft/published filtering.
- Added provider-supported voice selection, speaking language, TTS model, speed and expressive mode.
- Includes private cloned voices in the selector and validates ownership server-side.
- Editing a published agent now returns it to Draft until republished.
- Added WhatsApp Business Calling deployment instructions; actual number import remains in Fish Audio console as documented.

### Administration
- Added a real Fish Audio provider connection test using the provider voice-list API.
- Added configurable private clone credit cost.
- Removed implicit default agent-minute billing rate; administrator must set the current provider rate and conversion.

## Test results
All source and regression checks passed at build time:
- 85/85 PHP syntax checks.
- 13/13 JavaScript syntax checks.
- All existing and newly added Python regression tests.
- SQLite migration 007 and existing Agent Studio migration 004.

## Remaining live checks
No live Fish Audio key or target hosting environment was available. The container lacks PHP cURL and PDO SQLite. Provider authentication, real clone/TTS operations, agent publish/session, microphone/WebRTC and InfinityFree deployment are therefore NOT TESTED, not PASS.


## 2.6.1 follow-up
The follow-up visual refresh is documented in `CHANGELOG_2.6.1.md` and `BUILD_REPORT_2.6.1.md`. The packaged 2.6.1 build retains PDO SQLite as its only database driver and applies the charcoal / white / neon-green identity.
