# CGD — Étape 6.11 : bouton « Simuler » (comme FM27)

- Deux accès : « Simuler » dans la préparation du match (écran 09, après le choix du titulaire) et « Simuler » dans le terrain (écran 10, pour la rencontre officielle en cours ; sans rencontre, un message l'indique).
- Le jeu joue la partie à la place du joueur avec le moteur existant (`simulateFixture` / `simulateUserMatch`, IA contre IA, parties légales) : le résultat est inscrit une seule fois au classement, les messages d'après-match sont générés, le titulaire choisi est conservé pour la Dame d'Or.
- Effet des consignes de tactique sur la force du club dirigé, borné à ±5 points (`getTacticBonus`, `src/tactics.js`) :
  - Attaque : +3 si le club est le plus fort, −3 sinon ; Prudent : −2 si le club est le plus fort, +3 sinon ; Équilibré : 0.
  - Rythme rapide : +2 si la forme du titulaire est ≥ 70, −2 si elle est < 55 ; Normal : 0.
  - La formation reste une aide visuelle, sans effet.
- Le bonus appliqué est enregistré avec le résultat (`tacticBonus`). Avec les consignes par défaut (Équilibré, Normal) les résultats sont identiques à avant.
- L'IA des autres clubs n'utilise pas de consignes.
