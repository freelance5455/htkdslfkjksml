# CGD — Étapes 6.3 et 6.4 : écrans 03 (configuration) et 04 (manager), nouvel ordre de création

- Nouvel ordre, comme FM27 : Configuration de carrière → Manager → Club. Chaque étape occupe un écran, sans défilement de la page en paysage (vérifié en 895 × 393 et 844 × 390).
- Écran 03 : mode de carrière (Club, Club & International, Sans emploi, avec sa description), niveau de l'IA (Débutant à Professionnel), réputation de départ (Inconnu à Mondiale), rappel de la sauvegarde automatique. Choix par puces ; mêmes valeurs et mêmes contrôles qu'avant.
- Écran 04 : avatar (6 choix), prénom, nom, origine galactique, profil, expérience et style de manager, bouton « Choisir un club ».
- L'écran « La compétition officielle » n'est plus une étape obligatoire : la configuration valide `competitionSeen` d'office. Il reste affiché pour les anciennes sauvegardes de création inachevée.
- Le bouton « Modifier » de l'écran 05 ramène à l'écran 03.
- Aucun changement de règle : `saveManagerDraft`, `createManagerProfile`, `validateCareerSelection` et la prise de fonction sont inchangés.
- Code : `src/app.js` (renderCareerProfile, une seule étape rendue à la fois), styles dans le bloc `fm27-terrain` de `index.html`.
