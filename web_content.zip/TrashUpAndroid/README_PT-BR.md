# Trash Up — projeto Android

Este projeto transforma a versão HTML do Trash Up em um app Android de tela cheia usando WebView.

## O que já está configurado
- Nome do app: Trash Up
- Orientação: paisagem (celular deitado)
- Tela cheia/imersiva
- HTML do jogo incluído dentro do APK, então o jogo não depende do Chrome.
- Ícone original simples do Trash Up
- Package: com.trashup.game

## Como gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Execute a variante debug ou use Build > Build APK(s).
4. O APK de debug será gerado na pasta app/build/outputs/apk/debug/.

Para publicar em uma loja, use uma build de release assinada.
