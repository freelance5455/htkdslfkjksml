# Trash Up — caminho para APK

Este projeto já está preparado para transformar a versão **Trash Up V5** em um aplicativo Android.

## O que está incluído
- A versão V5 do jogo dentro de `app/src/main/assets/index.html`.
- Nome do aplicativo: **Trash Up**.
- Tela horizontal (paisagem).
- Tela cheia/imersiva.
- O jogo roda localmente dentro do aplicativo, sem depender do Chrome ou do GitHub Pages.
- Fluxo do GitHub Actions em `.github/workflows/gerar-apk.yml` para gerar automaticamente um APK de teste.

## Para gerar o APK
O arquivo `app-debug.apk` é criado pelo fluxo **Gerar APK do Trash Up**.

Depois da execução, o APK fica disponível como artefato chamado **Trash-Up-APK**.

> Este é um APK de teste (debug), adequado para instalar no seu próprio celular. Para publicação em loja, é necessária uma versão de lançamento assinada.
