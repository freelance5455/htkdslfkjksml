/* 10 calm generated music tracks + 10 click sounds (original synth, no audio files). */
(function(){
'use strict';
const $=id=>document.getElementById(id);const A=()=>lang==='ar';
const N={C3:130.81,D3:146.83,E3:164.81,F3:174.61,G3:196,A3:220,B3:246.94,C4:261.63,D4:293.66,E4:329.63,F4:349.23,G4:392,A4:440,B4:493.88,C5:523.25,Bb3:233.08,Fs3:185,Fs4:369.99,Ab3:207.65,Eb4:311.13};
// name ar/en, chords (4 notes each, 4 chords), melody indexes, wave, note length, level, bass
const TR=[
['ريفت هادئ','Calm Rift',[[220,261.63,329.63,392],[196,246.94,293.66,369.99],[174.61,220,261.63,349.23],[196,246.94,293.66,392]],[0,2,1,3,2,1,0,2,1,3,2,0,1,2,3,2],'sine',1.75,.22],
['فجر أيونيا','Ionia Dawn',[[N.D4,N.Fs4,N.A4,N.B4],[N.B3,N.D4,N.Fs4,N.A4],[N.G3,N.B3,N.D4,N.Fs4],[N.A3,N.D4,N.Fs4,N.A4]],[3,2,1,0,1,2,3,1,2,3,2,1,0,2,1,3],'triangle',1.6,.16],
['سكون ديمَاشيا','Demacia Calm',[[N.C4,N.E4,N.G4,N.C5],[N.A3,N.C4,N.E4,N.A4],[N.F3,N.A3,N.C4,N.F4],[N.G3,N.B3,N.D4,N.G4]],[0,1,2,3,2,1,0,1,3,2,1,0,2,3,1,2],'sine',2.0,.2],
['ثلج فريلجورد','Freljord Snow',[[N.A3,N.C4,N.E4,N.A4],[N.G3,N.B3,N.D4,N.G4],[N.F3,N.A3,N.C4,N.E4],[N.E3,N.G3,N.B3,N.E4]],[0,3,1,3,2,0,3,1,2,3,0,2,1,3,2,1],'triangle',2.4,.14],
['كثبان شوريما','Shurima Dunes',[[N.D3*2,N.F4,N.A4,N.D4],[N.E3*2,N.G4,N.B3*2,N.E4],[N.D3*2,N.F4,N.A4,N.D4],[N.C4,N.E4,N.G4,N.B4]],[0,2,3,2,1,0,2,3,1,2,0,1,3,2,1,0],'sine',1.9,.2],
['ليل نوكساس','Noxus Night',[[N.A3,N.C4,N.E4,N.G4],[N.F3,N.A3,N.C4,N.E4],[N.D3*2,N.F4,N.A4,N.C5],[N.E3*2,N.G4,N.B4,N.D4]],[0,1,0,2,1,3,2,1,0,2,3,1,2,0,1,3],'sine',2.2,.18],
['مطر بيلتوفر','Piltover Rain',[[N.G4,N.B4,N.D4,N.E4],[N.E4,N.G4,N.B4,N.C4],[N.C4,N.E4,N.G4,N.B4],[N.D4,N.Fs4,N.A4,N.B4]],[0,1,2,3,0,2,1,3,2,1,3,0,1,2,0,3],'triangle',1.2,.15],
['مد بيلج ووتر','Bilgewater Tide',[[N.F3,N.A3,N.C4,N.E4],[N.G3,N.B3,N.D4,N.F4],[N.A3,N.C4,N.E4,N.G4],[N.G3,N.B3,N.D4,N.G4]],[0,1,2,1,3,2,1,0,2,1,3,2,0,1,2,3],'sine',2.6,.2],
['سماء تارغون','Targon Sky',[[N.C4,N.G4,N.C5,N.E4],[N.F4,N.A4,N.C5,N.A3],[N.G3,N.D4,N.G4,N.B4],[N.A3,N.E4,N.A4,N.C5]],[3,1,2,0,3,2,1,0,2,3,1,2,0,1,3,2],'sine',2.8,.17],
['ضباب الجزر المظللة','Shadow Isles Mist',[[N.A3,N.C4,N.Eb4,N.E4*0+N.G4],[N.F3,N.Ab3,N.C4,N.Eb4],[N.G3,N.Bb3,N.D4,N.F4],[N.A3,N.C4,N.E4,N.G4]],[0,2,1,0,3,1,2,0,1,3,0,2,1,0,2,3],'sine',3.0,.15]
];
const CK=[
['نقرة ناعمة','Soft pop','sine',880,620,.09,.045],
['زجاج','Glass tick','triangle',1760,1320,.07,.03],
['خشب','Wood block','square',520,300,.05,.022],
['فقاعة','Bubble','sine',400,900,.11,.05],
['جرس صغير','Mini chime','sine',1318,1318,.22,.035],
['بريق','Sparkle','sine',1046,2093,.12,.03],
['طبلة خفيفة','Soft drum','sine',160,70,.14,.09],
['نبضة','Blip','sawtooth',700,500,.06,.02],
['قطف وتر','Pluck','triangle',659,440,.16,.05],
['همسة','Whisper tap','sine',1200,900,.04,.03]
];
let tr=+mraStorage.getItem('mra_track')||0,ck=+mraStorage.getItem('mra_click')||0;
tr=Math.min(Math.max(tr,0),9);ck=Math.min(Math.max(ck,0),9);
window.musicTick=function(){
  const T=TR[tr],ch=T[2][Math.floor(ambient.step/8)%4],m=T[3];
  playAmbientNote(ch[m[ambient.step%m.length]],T[5],T[6]);
  if(ambient.step%4===0)playAmbientNote(ch[0]/2,T[5]*1.8,T[6]*.42);
  if(ambient.step%8===0)playAmbientNote(ch[1]/2,T[5]*2.2,T[6]*.2);
  ambient.step++;
};
// wave override (playAmbientNote uses sine); wrap to apply wave type
const _pn=window.playAmbientNote;
window.playAmbientNote=function(f,d,l){
  if(!ambient.ctx||!ambient.master||ambient.muted||ambient.volume===0)return;
  const ctx=ambient.ctx,o=ctx.createOscillator(),g=ctx.createGain(),n=ctx.currentTime;
  o.type=TR[tr][4];o.frequency.setValueAtTime(f,n);
  g.gain.setValueAtTime(.0001,n);g.gain.exponentialRampToValueAtTime(Math.max(.0002,l),n+.2);g.gain.setValueAtTime(Math.max(.0002,l),n+d*.65);g.gain.exponentialRampToValueAtTime(.0001,n+d);
  o.connect(g);g.connect(ambient.master);o.start(n);o.stop(n+d+.04);
};
function click(i){
  try{const c=CK[i==null?ck:i],ctx=audioContext(),o=ctx.createOscillator(),g=ctx.createGain(),t=ctx.currentTime;
    o.type=c[2];o.frequency.setValueAtTime(c[3],t);o.frequency.exponentialRampToValueAtTime(Math.max(20,c[4]),t+c[5]*.8);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(c[6],t+.008);g.gain.exponentialRampToValueAtTime(.0001,t+c[5]);
    o.connect(g);g.connect(ctx.destination);o.start(t);o.stop(t+c[5]+.02)}catch(e){}
}
window.playClick=function(){if(!sfxEnabled)return;click()};
// screen taps (anything not already handled by the button handler)
document.addEventListener('pointerdown',e=>{
  if(!sfxEnabled||mraStorage.getItem('mra_fx_screen')==='0')return;
  if(e.target.closest('button,a,select,[role=button],input,[data-sd-load],[data-sd-del]'))return;
  click();
},true);
function panel(){
  if($('audio10'))return;const a=$('fxPanel')||$('sfxToggle')?.closest('.sound-panel');if(!a)return;
  const p=document.createElement('div');p.className='sound-panel';p.id='audio10';
  p.innerHTML=`<div class="sound-head"><div><b id="a10t"></b><div class="muted small" id="a10s"></div></div></div>
  <div class="fxrow" style="display:flex;gap:8px;align-items:center;padding:8px 0"><b id="a10m"></b><select id="trackSel" style="flex:1"></select><button class="btn" id="trackGo" type="button">▶</button></div>
  <div class="fxrow" style="display:flex;gap:8px;align-items:center;padding:8px 0"><b id="a10c"></b><select id="clickSel" style="flex:1"></select><button class="btn" id="clickGo" type="button">▶</button></div>
  <div class="fxrow" style="display:flex;justify-content:space-between;align-items:center;padding:8px 0"><b id="a10x"></b><input type="checkbox" id="screenTap" style="width:20px"></div>`;
  a.parentElement.insertBefore(p,a.nextSibling);
  $('trackSel').onchange=e=>{tr=+e.target.value;mraStorage.setItem('mra_track',tr);ambient.step=0;if(!ambient.on&&$('musicPlayBtn'))$('musicPlayBtn').click()};
  $('trackGo').onclick=()=>{tr=+$('trackSel').value;mraStorage.setItem('mra_track',tr);ambient.step=0;if(!ambient.on)$('musicPlayBtn').click()};
  $('clickSel').onchange=e=>{ck=+e.target.value;mraStorage.setItem('mra_click',ck);click()};
  $('clickGo').onclick=()=>click(+$('clickSel').value);
  $('screenTap').checked=mraStorage.getItem('mra_fx_screen')!=='0';
  $('screenTap').onchange=e=>mraStorage.setItem('mra_fx_screen',e.target.checked?'1':'0');
  label();
}
function label(){
  if(!$('audio10'))return;
  $('a10t').textContent=A()?'10 موسيقى هادئة و10 أصوات نقر':'10 calm tracks & 10 click sounds';
  $('a10s').textContent=A()?'مولّدة داخل التطبيق، بدون ملفات صوت':'Generated inside the app, no audio files';
  $('a10m').textContent=A()?'الموسيقى':'Music';$('a10c').textContent=A()?'صوت النقر':'Click';$('a10x').textContent=A()?'صوت عند لمس الشاشة':'Sound on screen taps';
  $('trackSel').innerHTML=TR.map((t,i)=>`<option value="${i}">${i+1}. ${A()?t[0]:t[1]}</option>`).join('');$('trackSel').value=tr;
  $('clickSel').innerHTML=CK.map((t,i)=>`<option value="${i}">${i+1}. ${A()?t[0]:t[1]}</option>`).join('');$('clickSel').value=ck;
}
function init(){panel();const _t=window.translate;window.translate=function(){const r=_t.apply(this,arguments);try{label()}catch(e){}return r}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,40));else setTimeout(init,40);
})();
