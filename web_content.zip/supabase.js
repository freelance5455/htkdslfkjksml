const SUPABASE_URL='https://ykhsnxltdwysktpkmgpq.supabase.co';
const SUPABASE_KEY='sb_publishable_jFAKoIBYJi1OammGSC8n6Q_RuIG6gZS';
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
