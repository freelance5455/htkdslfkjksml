'use strict';
/* =====================================================================
   fx.js  —  event bus + hit feedback + banners + slow-motion + kill-streak combo
   ---------------------------------------------------------------------
   Bus     : chhota event system. Missions / modes isse sunte hain (kill, hit, headshot, combo, matchEnd...)
   FX      : hit marker (X), damage numbers, KILL marker/text, screen-shake values, banner, slow-mo + zoom
   Combo   : kill streak. 3 kill = "Triple Kill", 5 kill = "Rampage" + 3s speed boost. Meter 5s mein decay.
   Sab tuning ke liye FX.cfg / Combo.cfg.
   ===================================================================== */
let S0=1;                                     // base camera zoom (render.js resize() set karta hai)

const Bus={
  h:{},
  on(n,f){(this.h[n]||(this.h[n]=[])).push(f)},
  emit(n,...a){for(const f of this.h[n]||[]){try{f(...a)}catch(e){console.error('Bus',n,e)}}}
};

const FX={
  cfg:{
    shotShake:.1,      // har shot par halka shake (WeaponController weapon-class se multiply karta hai)
    hitShake:.3,       // player ko goli lage
    killShake:.5,      // player ka kill
    slowSec:.5,        // match-winning kill par slow-motion kitni der (real sec)
    slowScale:.25,     // slow-motion mein game-speed
    slowZoom:.25,      // camera zoom-in (0.25 = +25%)
    maxItems:70        // on-screen numbers / markers ki limit
  },
  texts:[],marks:[],slowT:0,zoomV:0,lowT:-99,_bt:0,

  reset(){this.texts.length=0;this.marks.length=0;this.slowT=0;this.zoomV=0;this.lowT=-99},

  text(x,y,txt,col,size,life){
    if(this.texts.length>this.cfg.maxItems)this.texts.shift();
    this.texts.push({x:x+rnd(-8,8),y,txt:String(txt),col,size:size||16,t:0,T:life||.8});
  },
  mark(x,y,kind){
    if(this.marks.length>40)this.marks.shift();
    this.marks.push({x,y,kind,t:0,T:kind==='kill'?.7:.28});
  },

  /* hurtP() se: victim v ko damage d mila, src ne diya, hs = headshot (precision hit) */
  onHit(v,d,src,hs){
    if(!player)return;
    if(src===player&&v!==player&&v.team!==player.team){
      this.mark(v.x,v.y-26,hs?'head':'hit');                         // hit marker (X)
      this.text(v.x,v.y-44,Math.round(d),hs?'#ffd36b':'#ffffff',hs?22:17);   // damage number
      if(hs)snd('headshot',.9);
      Bus.emit('hit',v,d,hs);if(hs)Bus.emit('headshot',v);
    }else if(v===player&&src!==player){
      this.text(v.x,v.y-48,'-'+Math.round(d),'#ff5d6c',16);
      shake=Math.max(shake,this.cfg.hitShake);snd('hurt',.8);
      if(v.hp<35*HPM&&time-this.lowT>20){this.lowT=time;Voice.say('hurt')}
    }
  },

  /* kill() se */
  onKill(v,src){
    if(player&&src===player&&v!==player&&v.team!==player.team){
      this.mark(v.x,v.y-26,'kill');                                  // red marker
      this.text(v.x,v.y-62,'KILL','#ff3b4d',28,1);                   // "Kill" text
      shake=Math.max(shake,this.cfg.killShake);snd('kill');
      Voice.say('kill');Combo.onKill();
    }
    if(v===player){Combo.breakStreak();Bus.emit('death',v,src)}
    Bus.emit('kill',v,src);
  },

  /* ---- slow-motion + zoom ---- */
  slowmo(sec){this.slowT=sec||this.cfg.slowSec},
  timeScale(){return this.slowT>0?this.cfg.slowScale:1},
  zoomMul(){return 1+this.cfg.slowZoom*this.zoomV},
  tick(dt){                                                           // dt = REAL seconds
    if(this.slowT>0)this.slowT-=dt;
    this.zoomV+=((this.slowT>0?1:0)-this.zoomV)*Math.min(1,dt*(this.slowT>0?10:5));
    if(this.zoomV<.001&&this.slowT<=0)this.zoomV=0;
    for(const a of [this.texts,this.marks])for(let i=a.length-1;i>=0;i--){a[i].t+=dt;if(a[i].t>=a[i].T)a.splice(i,1)}
  },

  /* ---- banner (Triple Kill / Rampage ...) ---- */
  banner(txt,sub,col){
    const e=$('banner');if(!e)return;
    e.innerHTML='<b style="color:'+(col||'')+'">'+txt+'</b>'+(sub?'<small>'+sub+'</small>':'');
    e.hidden=false;e.classList.remove('on');void e.offsetWidth;e.classList.add('on');
    clearTimeout(this._bt);this._bt=setTimeout(()=>{e.hidden=true},1900);
  },

  /* ---- world-space draw (render.js se, zone ke baad) ---- */
  drawWorld(c){
    if(!this.texts.length&&!this.marks.length)return;
    c.save();c.textAlign='center';c.lineJoin='round';
    for(const m of this.marks){
      const p=m.t/m.T,s=(m.kind==='kill'?11:m.kind==='head'?8:6)*(1+.5*p);
      c.globalAlpha=1-p*p;c.lineCap='round';
      c.translate(m.x,m.y);
      c.strokeStyle='rgba(0,0,0,.6)';c.lineWidth=(m.kind==='kill'?7:5);
      c.beginPath();c.moveTo(-s,-s);c.lineTo(s,s);c.moveTo(s,-s);c.lineTo(-s,s);c.stroke();
      c.strokeStyle=m.kind==='kill'?'#ff2d3d':m.kind==='head'?'#ffd36b':'#ffffff';c.lineWidth=m.kind==='kill'?4:2.6;
      c.beginPath();c.moveTo(-s,-s);c.lineTo(s,s);c.moveTo(s,-s);c.lineTo(-s,s);c.stroke();
      c.translate(-m.x,-m.y);
    }
    for(const t of this.texts){
      const p=t.t/t.T,sz=t.size*(1+.35*Math.max(0,1-p*6));
      c.globalAlpha=1-p*p*p;
      c.font='700 '+sz+'px Teko,Hind,'+I18N.fb+'system-ui,sans-serif';
      const y=t.y-p*30;
      c.lineWidth=4;c.strokeStyle='rgba(0,0,0,.75)';c.strokeText(t.txt,t.x,y);
      c.fillStyle=t.col;c.fillText(t.txt,t.x,y);
    }
    c.restore();
  }
};

/* =====================================================================
   Combo / kill streak
   ===================================================================== */
const Combo={
  cfg:{
    decay:5,          // itne sec mein agla kill nahi aaya to combo khatam (meter isi se utarta hai)
    tripleAt:3,
    rampageAt:5,
    boostSec:3        // Rampage par speed boost
  },
  n:0,t:0,best:0,
  reset(){this.n=0;this.t=0;this.best=0},
  breakStreak(){this.n=0;this.t=0},
  onKill(){
    const c=this.cfg;
    this.n++;this.t=c.decay;this.best=Math.max(this.best,this.n);
    const n=this.n;
    if(n>=c.rampageAt){
      FX.banner('Rampage',(n>c.rampageAt?'x'+n+' · ':'')+T('Speed boost {0}s',c.boostSec),'#ff5d6c');
      player.spdT=Math.max(player.spdT||0,c.boostSec);               // updAbilities: spdT>0 => स्पीड x1.3
      snd('rampage');Voice.say('rampage');
    }else if(n===4){FX.banner('Quadra Kill','x4 combo','#ff8a5c');snd('combo')}
    else if(n===c.tripleAt){FX.banner('Triple Kill','x3 combo','#ffb347');snd('combo');Voice.say('triple')}
    else if(n===2){FX.banner('Double Kill','x2 combo','#ffd36b');snd('combo')}
    Bus.emit('combo',n);
  },
  update(dt){if(this.n>0){this.t-=dt;if(this.t<=0){this.n=0;this.t=0}}},
  hud(){                                                              // har frame HUD meter
    const e=$('combo');if(!e)return;
    const on=this.n>0;if(e.hidden===on)e.hidden=!on;
    if(!on)return;
    setT('cmbN','x'+this.n);
    $('cmbB').style.width=clamp(this.t/this.cfg.decay*100,0,100)+'%';
  }
};
