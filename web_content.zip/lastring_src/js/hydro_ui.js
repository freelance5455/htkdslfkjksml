'use strict';
/* =====================================================================
   hydro_ui.js — "Water Worlds" guide panel: 80 variants (4 x 20), animated preview, kis map par milta hai
   ===================================================================== */
Object.assign(Hydro,{
  /* offscreen-style preview: asli draw functions ko ek chhote scene par chalata hai */
  preview(cat,v,cv,tm){
    const c=cv.getContext('2d'),W=300,H=192,DPR2=cv.width/W;
    const bk={r:this.rivers,p:this.ponds,f:this.falls,b:this.bridges,g:this.grass,P:this.P,i:this.idx,pv:this.pv,x0:this._x0,y0:this._y0,x1:this._x1,y1:this._y1,t:time,w:this.wind};
    try{
      this.rivers=[];this.ponds=[];this.falls=[];this.bridges=[];this.grass=[];this.P=[];this.idx=0;this.pv=true;this._x0=-1e4;this._y0=-1e4;this._x1=1e4;this._y1=1e4;time=tm||2.3;this.wind=Math.sin(time*.7)*.4;
      c.setTransform(DPR2,0,0,DPR2,0,0);
      const m=mp||MAPS[0];
      c.fillStyle=m.g[0];c.fillRect(0,0,W,H);c.globalAlpha=.4;for(let i=0;i<14;i++){c.fillStyle=m.g[1+i%2];c.beginPath();c.ellipse((i*83)%W,(i*47)%H,40,22,i,0,TAU);c.fill()}c.globalAlpha=1;
      c.save();
      const q={fx:2,tuft:1,shadow:1};
      const mkRiver=(rv,k)=>{
        const mk=(off,w)=>{const pts=[];for(let i=0;i<=12;i++)pts.push({x:150+off+Math.sin(i*.75+(rv.id.length))*34*(rv.amp>1.4?1.4:rv.amp>.7?1:.4),y:-24+i*19.4});return this.chan(pts,w,{})};
        const R={v:rv,chans:[],rocks:[],lv:[],fo:time*rv.fl*.9,seed:1,ox:null};const w=Math.max(22,Math.min(96,rv.w*.6));
        if(rv.braid){for(let j=-1;j<=1;j++)R.chans.push(mk(j*34,18))}else R.chans.push(mk(0,w));
        const ch=R.chans[0];ch.dry=!!rv.dry;if(rv.tunnel)ch.tun=[4,8];
        if(rv.rocks)for(let i=0;i<9;i++){const q2=ch.pts[1+i];R.rocks.push({x:q2.x+(i%3-1)*w*.25,y:q2.y,r:5+(i%3)*2,ph:i})}
        if(rv.gravel)for(let i=0;i<7;i++){const q2=ch.pts[2+i];R.rocks.push({x:q2.x+(i%3-1)*20,y:q2.y,r:5,ph:i})}
        if(rv.leaves)for(let i=0;i<6;i++)R.lv.push({c:ch,u:(i/6+time*.02)%1,off:(i%3-1)*.2,ph:i,r:3});
        if(rv.oxbow)R.ox={x:236,y:60,r:22,rot:.5};
        return R};
      if(cat==='river'){const R=mkRiver(v);this.rivers=[R];this.paintRivers(c);this.drawBase(c,0,0,W,H,q);this.drawTop(c,0,0,W,H,q)}
      else if(cat==='pond'){const p=this.mkPond(v,150,96,66);p.tr=[];this.ponds=[p];this.paintPond(c,p);this.drawBase(c,0,0,W,H,q);this.drawTop(c,0,0,W,H,q)}
      else if(cat==='fall'){
        const f=this.mkFall(v,150,150);this.falls=[f];c.translate(150,120);c.scale(.62,.62);c.translate(-150,-150);
        this.paintFall(c,f);this.drawBase(c,-1e4,-1e4,1e4,1e4,q);this.drawTop(c,-1e4,-1e4,1e4,1e4,q)}
      else{
        const R=mkRiver(HY_RIVER[0]);R.chans[0].pts.forEach(p=>{p.x=150+(p.x-150)*.15});R.chans=[this.chan(R.chans[0].pts,76,{})];R.v=Object.assign({},HY_RIVER[0],{w:76});
        this.rivers=[R];c.translate(150,96);c.scale(1.45,1.45);c.translate(-150,-96);this.paintRivers(c);
        const b=this.mkBridge(v,150,96,0,76+72,R,0);this.bridges=[b];this.paintBridgeAO(c,b);this.drawBase(c,-1e4,-1e4,1e4,1e4,q);this.drawTop(c,-1e4,-1e4,1e4,1e4,q)}
      c.restore();
    }catch(e){console.error('hydro preview',e)}
    finally{this.rivers=bk.r;this.ponds=bk.p;this.falls=bk.f;this.bridges=bk.b;this.grass=bk.g;this.P=bk.P;this.idx=bk.i;this.pv=bk.pv;this._x0=bk.x0;this._y0=bk.y0;this._x1=bk.x1;this._y1=bk.y1;time=bk.t;this.wind=bk.w}
  },
  anim(cat,v,cv){const t0=performance.now();const loop=()=>{if(!cv.isConnected)return;this.preview(cat,v,cv,2+(performance.now()-t0)/1000);requestAnimationFrame(loop)};loop()},
  mapsOf(cat,id){const k={river:'r',bridge:'b',fall:'f',pond:'p'}[cat],o=[];HY_MAP.forEach((m,i)=>{if(m[k]===id)o.push(i)});return o}
});

function pNature(){
  const w=h('div');
  const cats=[['river',T('Rivers')],['bridge',T('Bridges')],['fall',T('Waterfalls')],['pond',T('Ponds')]];
  w.append(tabs('nature',cats,'river'));
  const cat=ptab.nature||'river',list=HY_CAT[cat],sel=ptab['nat_'+cat]||list[0].id,sv=list.find(v=>v.id===sel)||list[0];
  w.append(h('p',{class:'dim'},T('20 kinds of each — every one is placed on a map. Tap a card to see it animated; “Play here” picks that map.')));
  const big=h('canvas',{width:600,height:384,style:'width:100%;max-width:420px;border-radius:12px;border:1px solid var(--line);display:block;margin:0 auto 8px'});
  const mp2=Hydro.mapsOf(cat,sv.id);
  w.append(big,h('div',{style:'text-align:center;margin-bottom:10px'},h('b',null,sv.n),h('div',{class:'dim'},T('Found on: {0}',mp2.map(i=>MAPS[i].n).join(', ')||'—')),
    mp2.length?h('button',{class:'sm pri',onclick:()=>{prof.map=mp2[0];save();snd('click');closePanel();if(typeof refreshLobby==='function')refreshLobby();const lm=$('lMap');if(lm)lm.textContent=MAPS[prof.map].n;toast(MAPS[prof.map].n)}},T('Play here')):null));
  const grid=h('div',{class:'grid'});
  for(const v of list){
    const cv=h('canvas',{width:300,height:192,style:'width:100%;border-radius:8px'});
    const card=h('div',{class:'it'+(v.id===sv.id?' eq':''),style:'cursor:pointer',onclick:()=>{ptab['nat_'+cat]=v.id;snd('click');render()}},cv,h('b',null,v.n),h('small',null,Hydro.mapsOf(cat,v.id).map(i=>MAPS[i].n).join(', ')));
    grid.append(card);
    setTimeout(()=>{if(cv.isConnected)Hydro.preview(cat,v,cv,2.3)},0);
  }
  w.append(grid);
  setTimeout(()=>{if(big.isConnected)Hydro.anim(cat,sv,big)},0);
  return w;
}
