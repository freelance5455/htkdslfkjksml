'use strict';
/* =====================================================================
   progress.js — daily login reward, daily missions, character unlock
   ---------------------------------------------------------------------
   Save: sab kuch `prof` mein hai, jo save() se localStorage mein jaata hai (Unity ka PlayerPrefs yahan ye hai).
   Missions Bus (fx.js) ke events sunte hain: kill / headshot / matchEnd.
   ===================================================================== */

/* ---------- daily login: 7 din ka streak ---------- */
const LOGIN=[
  {g:200,d:10},{g:250,d:10},{g:300,d:15},{g:350,d:15},{g:400,d:20,t:1},{g:450,d:25},{g:600,d:40,t:1}
];                                                   // din-1 = purana 200 gold + 10 diamond; t = skin token

/* ---------- daily missions ---------- */
const MISS=[
  {id:'k10',t:'kills',goal:10,n:T('Get 10 kills'),rw:{g:200}},
  {id:'w5',t:'wins',goal:5,n:T('Win 5 matches'),rw:{g:300,d:5,tok:1}},
  {id:'h3',t:'heads',goal:3,n:T('Get 3 headshots'),rw:{g:150,tok:1}}
];
const rwText=r=>[r.g&&T('{0} Gold',r.g),r.d&&r.d+' ◆',r.tok&&T('🎟 Skin token')].filter(Boolean).join(' + ');

const Prog={
  today(){return new Date().toDateString()},
  yesterday(){return new Date(Date.now()-864e5).toDateString()},

  rollover(){                                         // naya din = naye mission
    const d=this.today();
    if(prof.ms.date!==d){prof.ms={date:d,list:MISS.map(m=>({id:m.id,p:0,c:0}))};save()}
  },
  claimedToday(){return prof.daily===this.today()},
  nextDay(){return this.claimedToday()?0:((prof.daily===this.yesterday()?prof.streak:0)%7)+1},
  claimLogin(){
    if(this.claimedToday())return null;
    const day=this.nextDay(),r=LOGIN[day-1];
    prof.streak=(prof.daily===this.yesterday()?prof.streak:0)+1;prof.daily=this.today();
    prof.gold+=r.g;prof.gems+=r.d;if(r.t)prof.tok=(prof.tok|0)+r.t;
    save();return{day,...r};
  },

  add(type,n){
    this.rollover();
    for(const m of prof.ms.list){
      const def=MISS.find(x=>x.id===m.id);
      if(!def||def.t!==type||m.p>=def.goal)continue;
      m.p=Math.min(def.goal,m.p+(n||1));
      if(m.p>=def.goal){toast(T('✅ Mission complete: {0}',def.n));snd('heal')}
    }
    save();
  },
  claimMission(i){
    this.rollover();
    const m=prof.ms.list[i],def=m&&MISS.find(x=>x.id===m.id);
    if(!def||m.c||m.p<def.goal)return;
    m.c=1;const r=def.rw;
    prof.gold+=r.g||0;prof.gems+=r.d||0;if(r.tok)prof.tok=(prof.tok|0)+r.tok;
    save();snd('pick');toast(T('Reward: {0}',rwText(r)));refreshBars();render();
  },
  // lobby ke button par laal nishan
  badge(){
    this.rollover();
    const n=prof.ms.list.filter(m=>{const d=MISS.find(x=>x.id===m.id);return d&&!m.c&&m.p>=d.goal}).length;
    const b=$('dailyBtn'),m=$('missBtn');
    if(b)b.textContent=T('Daily bonus')+(this.claimedToday()?'':' ●');
    if(m)m.textContent=T('Missions')+(n?' ('+n+')':'');
  }
};

Bus.on('kill',(v,src)=>{if(player&&src===player&&v.team!==player.team)Prog.add('kills',1)});
Bus.on('headshot',()=>Prog.add('heads',1));
Bus.on('matchEnd',r=>{if(r&&r.win)Prog.add('wins',1)});

/* ---------- daily panel ---------- */
function pDaily(){
  Prog.rollover();
  const w=h('div'),claimed=Prog.claimedToday(),next=Prog.nextDay();
  const done=claimed?((prof.streak-1)%7)+1:((prof.daily===Prog.yesterday()?prof.streak:0)%7);   // ab tak kitne din ke claim ho chuke (is cycle mein)
  w.append(h('h3',null,T('Daily Login Reward')));
  w.append(h('div',{class:'days'},LOGIN.map((r,i)=>{
    const n=i+1,cls='dy'+(n<=done?' done':'')+(n===next?' go':'');
    return h('div',{class:cls},h('b',null,T('Day {0}',n)),h('small',null,T('{0} Gold',r.g)),h('small',null,r.d+' ◆'+(r.t?' +🎟':'')));
  })));
  w.append(h('div',{class:'row2',style:'margin-top:8px'},
    h('span',{class:'dim'},T('Streak: {0} days · log in daily and the rewards keep growing',prof.streak|0)),
    h('button',{class:'sm pri'+(claimed?' off':''),id:'claimLogin',onclick:()=>{claimDaily();render()}},claimed?T('Already claimed today'):T('Claim today\'s reward'))));
  w.append(h('h3',null,T('Daily Missions')));
  prof.ms.list.forEach((m,i)=>{
    const def=MISS.find(x=>x.id===m.id);if(!def)return;
    const ok=m.p>=def.goal;
    w.append(h('div',{class:'mrow'},
      h('div',null,h('b',null,def.n),h('small',{class:'dim'},T('Reward: {0}',rwText(def.rw))),
        h('div',{class:'bar',style:'margin-top:5px'},h('i',{style:'width:'+(m.p/def.goal*100)+'%;background:var(--accent)'}))),
      h('span',{class:'mp'},m.p+'/'+def.goal),
      h('button',{class:'sm'+(ok&&!m.c?' pri':' off'),id:'claimM'+i,onclick:()=>Prog.claimMission(i)},m.c?T('Claimed ✓'):T('Claim'))));
  });
  w.append(h('p',{class:'dim'},T('Missions reset daily. Unlock weapon skins with 🎟 skin tokens.')));
  return w;
}

/* ---------- character unlock (500 गोल्ड) ---------- */
const CH_PRICE=500;
const CH_FREE=['alok','agni','tara'];              // Alok = शुरुआती किरदार; Agni/Tara पहले से गेम में थे, फ्री रखे
const chOwned=id=>CH_FREE.includes(id)||!!prof.chOwn[id];
function buyChar(c){
  if(chOwned(c.id))return;
  if(prof.gold<CH_PRICE){toast(T('Not enough Gold — {0} needed',CH_PRICE));return}
  prof.gold-=CH_PRICE;prof.chOwn[c.id]=1;save();snd('pick');toast(T('{0} unlocked!',c.em+' '+c.n));refreshBars();render();
}
// purani save mein jo किरदार चुना हुआ था वो लॉक न हो जाए
if(prof.ch&&!CH_FREE.includes(prof.ch))prof.chOwn[prof.ch]=1;
