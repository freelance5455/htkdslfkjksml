'use strict';
/* ---------- audio ---------- */
let AC=null,NB=null,SOUT=null,SDEL=0;   // SOUT = spatial panner node, SDEL = start delay (sec)
function ac(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)()}catch(e){}}return AC}
function nb(){const a=ac();if(!NB&&a){NB=a.createBuffer(1,Math.floor(a.sampleRate*.7),a.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1}return NB}
function noise(dur,f,vol,ft){const a=ac();if(!a||set.vol<=0)return;const s=a.createBufferSource();s.buffer=nb();const fl=a.createBiquadFilter();fl.type=ft||'lowpass';fl.frequency.value=f;const g=a.createGain();const t=a.currentTime+SDEL;g.gain.setValueAtTime(vol*set.vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);s.connect(fl);fl.connect(g);g.connect(SOUT||a.destination);s.start(t);s.stop(t+dur)}
function tone(f,dur,vol,type,f2){const a=ac();if(!a||set.vol<=0)return;const o=a.createOscillator(),g=a.createGain(),t=a.currentTime+SDEL;o.type=type||'sine';o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+dur);g.gain.setValueAtTime(vol*set.vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(g);g.connect(SOUT||a.destination);o.start(t);o.stop(t+dur)}
function snd(k,v){v=v==null?1:v;if(v<=.02)return;const a=ac();if(a&&a.state==='suspended')a.resume();
  switch(k){
    case'hy_splash':noise(.32,1500,.34*v,'highpass');noise(.5,520,.26*v,'lowpass');tone(300,.18,.09*v,'sine',120);break;
    case'hy_wstep':noise(.12,1900,.16*v,'bandpass');break;
    case'hy_drip':tone(1400,.09,.12*v,'sine',700);tone(2100,.05,.04*v,'sine',900);break;
    case'hy_frog':{const s=SDEL;tone(190,.16,.16*v,'sawtooth',140);SDEL=s+.2;tone(170,.18,.14*v,'sawtooth',120);SDEL=s;break}
    case'hy_bird':{const s=SDEL;tone(2600,.07,.09*v,'sine',3400);SDEL=s+.11;tone(3000,.06,.07*v,'sine',2400);SDEL=s+.2;tone(3300,.05,.06*v,'sine',3700);SDEL=s;break}
    case'hy_bubble':tone(170,.12,.2*v,'sine',430);noise(.05,900,.05*v);break;
    case'hy_chime':tone(1318,.9,.1*v,'sine');tone(1976,.7,.05*v,'sine');tone(2637,.5,.035*v,'sine');break;
    case'hy_ice':noise(.1,3200,.18*v,'highpass');tone(2400,.12,.05*v,'triangle',1800);break;
    case'hy_tock':noise(.06,900,.26*v,'lowpass');tone(160,.07,.2*v,'triangle',90);break;
    case'hy_clang':tone(520,.35,.1*v,'triangle',500);tone(780,.3,.06*v,'square',770);noise(.04,3000,.12*v,'highpass');break;
    case'hy_thud':noise(.09,500,.3*v,'lowpass');tone(90,.1,.24*v,'sine',55);break;
    case'hy_creak':tone(150,.4,.08*v,'sawtooth',105);tone(310,.3,.025*v,'square',220);break;
    case'pistol':noise(.12,3000,.5*v);tone(180,.08,.25*v,'square',70);break;
    case'smg':noise(.07,3800,.4*v);break;
    case'ar':noise(.1,2600,.5*v);tone(120,.07,.2*v,'square',60);break;
    case'sg':noise(.28,1800,.8*v);tone(90,.2,.4*v,'sawtooth',40);break;
    case'sn':noise(.4,1400,.9*v);tone(70,.35,.5*v,'sawtooth',30);break;
    case'xb':tone(300,.12,.3*v,'triangle',120);break;
    case'boom':noise(.7,500,1.1*v);tone(60,.5,.6*v,'sawtooth',25);break;
    case'hit':tone(520,.06,.25*v,'square',300);break;
    case'heal':tone(520,.12,.2*v,'sine',780);setTimeout(()=>tone(780,.16,.2*v,'sine',1040),110);break;
    case'click':tone(640,.04,.18,'square');break;
    case'reload':noise(.05,6000,.25*v,'highpass');SDEL=.38;noise(.06,5000,.3*v,'highpass');SDEL=0;break;
    case'pick':tone(700,.07,.18*v,'triangle',1000);break;
    case'gloo':noise(.15,5000,.35*v,'highpass');tone(900,.12,.15*v,'triangle',500);break;
    case'throw':noise(.1,1200,.3*v);break;
    case'headshot':tone(1500,.07,.3*v,'square',2100);SDEL=.05;tone(2100,.1,.22*v,'triangle');SDEL=0;break;
    case'kill':tone(320,.1,.35*v,'sawtooth',160);SDEL=.09;tone(660,.16,.3*v,'triangle',990);SDEL=0;break;
    case'hurt':noise(.09,500,.5*v);tone(110,.14,.35*v,'sine',65);break;
    case'impact':noise(.06,2600,.2*v,'highpass');tone(240,.05,.1*v,'square',120);break;
    case'combo':tone(520,.09,.25,'triangle');SDEL=.08;tone(660,.09,.25,'triangle');SDEL=.16;tone(880,.18,.28,'triangle');SDEL=0;break;
    case'rampage':tone(180,.5,.4,'sawtooth',520);noise(.45,900,.35);SDEL=.3;tone(880,.3,.3,'square',1320);SDEL=0;break;
    case'respawn':tone(400,.2,.25,'sine',800);break;
    case'win':tone(520,.2,.3,'triangle');setTimeout(()=>tone(660,.2,.3,'triangle'),180);setTimeout(()=>tone(880,.4,.3,'triangle'),360);break;
  }}

/* ---------- shapes ---------- */
function rr(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()}

/* ---------- character (front-facing, slight 3/4) ---------- */
function drawChar(c,o,x,y,sc,ang,t,op){
  op=op||{};
  c.save();c.translate(x,y);c.scale(sc,sc);
  const mv=op.mv||0,sw=Math.sin(t*11)*4*mv,bob=Math.abs(Math.sin(t*11))*1.6*mv+(op.idle?Math.sin(t*2)*.8:0);
  const ca=Math.cos(ang),sa=Math.sin(ang),back=!op.front&&sa<-.35;
  if(!op.noShadow){c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.ellipse(2,1,12,5,0,0,TAU);c.fill()}
  if(op.glow&&o.glow){const g=c.createRadialGradient(0,-24,4,0,-24,44);g.addColorStop(0,o.glow+'55');g.addColorStop(1,o.glow+'00');c.fillStyle=g;c.beginPath();c.arc(0,-24,44,0,TAU);c.fill()}
  const P=[0,-26-bob],gw=op.gun?WP[op.gun]:null,L=gw?gw.len+8:0;
  const gun=()=>{if(!gw)return;c.lineCap='round';
    const art=typeof GunArt!=='undefined'&&GunArt.hand(c,op.gun,P[0],P[1],ang,L,op.gcol,op.gfx);   // real-gun texture sprite
    if(!art){
    const w=gw.cls==='sn'||gw.cls==='lmg'?5:gw.cls==='sg'?4.6:4;
    c.strokeStyle='#1e252b';c.lineWidth=w;c.beginPath();c.moveTo(P[0]-ca*5,P[1]-sa*5);c.lineTo(P[0]+ca*L,P[1]+sa*L);c.stroke();
    c.strokeStyle=op.gcol||gw.col;c.lineWidth=w-2;c.beginPath();c.moveTo(P[0]+ca*L*.25,P[1]+sa*L*.25);c.lineTo(P[0]+ca*L*.95,P[1]+sa*L*.95);c.stroke();
    if(op.gfx==='gold'){c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=1;c.beginPath();c.moveTo(P[0]+ca*L*.3,P[1]+sa*L*.3-.8);c.lineTo(P[0]+ca*L*.9,P[1]+sa*L*.9-.8);c.stroke()}
    else if(op.gfx==='neon'){c.save();c.shadowColor=op.gcol;c.shadowBlur=12;c.strokeStyle=op.gcol;c.lineWidth=1.6;c.beginPath();c.moveTo(P[0]+ca*L*.25,P[1]+sa*L*.25);c.lineTo(P[0]+ca*L*.95,P[1]+sa*L*.95);c.stroke();c.restore()}
    }
    if(op.flash>0){c.fillStyle='#fff3b0';c.beginPath();const mx=P[0]+ca*(L+2),my=P[1]+sa*(L+2);c.arc(mx,my,5+Math.random()*3,0,TAU);c.fill();c.fillStyle='rgba(255,170,60,.7)';c.beginPath();c.arc(mx,my,9,0,TAU);c.fill()}};
  if(back)gun();
  // legs
  c.fillStyle=o.pants;rr(c,-7,-18,6.2,15+sw*.4,2);c.fill();rr(c,.8,-18,6.2,15-sw*.4,2);c.fill();
  c.fillStyle=o.shoes;rr(c,-8.5,-4+sw*.4,8.4,4.4,2);c.fill();rr(c,.2,-4-sw*.4,8.4,4.4,2);c.fill();
  // torso
  if(back){c.fillStyle='#232a30';rr(c,-7,-33-bob,14,16,3);c.fill()}
  c.fillStyle=o.top;rr(c,-9,-35-bob,18,20,5);c.fill();
  c.fillStyle=o.top2;c.fillRect(-9,-19-bob,18,3);if(!back){c.fillRect(-2.4,-35-bob,4.8,11)}
  if(op.armor>0){c.fillStyle='rgba(111,183,255,.55)';rr(c,-8,-34-bob,16,15,4);c.fill()}
  // head
  const hy=-42-bob,fx=clamp(ca,-1,1)*2.4;
  if(o.hat==='hood'){c.fillStyle=o.hatc;c.beginPath();c.arc(0,hy,9.4,0,TAU);c.fill()}
  c.fillStyle=o.skin;c.beginPath();c.arc(back?0:fx*.5,hy+(o.hat==='hood'?.5:0),o.hat==='hood'?6.6:7.6,0,TAU);c.fill();
  if(o.hat!=='hood'&&o.hat!=='helmet'){c.fillStyle=o.hair;c.beginPath();if(back)c.arc(0,hy,7.9,0,TAU);else c.arc(fx*.5,hy,7.9,Math.PI,TAU);c.fill()}
  if(!back){
    c.fillStyle='#14181c';c.beginPath();c.arc(fx-2.7,hy+.6,1.1,0,TAU);c.arc(fx+2.7,hy+.6,1.1,0,TAU);c.fill();
    if(o.glass){c.fillStyle='rgba(10,14,20,.9)';rr(c,fx-5.4,hy-1.4,10.8,3.6,1.6);c.fill()}
    if(o.mask==='plain'){c.fillStyle=o.top2;rr(c,fx-6.4,hy+1.8,12.8,5.4,2.5);c.fill()}
    if(o.mask==='bandit'){c.fillStyle='#111';rr(c,fx-6.8,hy-2,13.6,4,2);c.fill();c.fillStyle='#fff';c.fillRect(fx-3.4,hy-.4,1.8,1.4);c.fillRect(fx+1.6,hy-.4,1.8,1.4)}
    if(o.mask==='visor'){c.fillStyle=o.glow||'#2dffd0';c.globalAlpha=.85;rr(c,fx-6.4,hy-2,12.8,4.4,2);c.fill();c.globalAlpha=1}
    if(o.mask==='ninja'){c.fillStyle=o.top;rr(c,fx-7,hy+1,14,6.6,2.4);c.fill();c.fillRect(fx-7,hy-5,14,2.2)}
  }
  // hats
  c.fillStyle=o.hatc||'#888';
  switch(o.hat){
    case'cap':c.beginPath();c.arc(fx*.5,hy-.5,8.4,Math.PI,TAU);c.fill();if(!back){c.fillRect(fx*.5+(ca>=0?0:-9),hy-1.4,9,2.4)}break;
    case'beanie':c.beginPath();c.arc(fx*.5,hy-1,8.6,Math.PI,TAU);c.fill();c.fillStyle=o.top2;c.fillRect(fx*.5-8.6,hy-3.4,17.2,3.2);c.fillStyle='#fff';c.beginPath();c.arc(fx*.5,hy-9.6,2.5,0,TAU);c.fill();break;
    case'wrap':c.beginPath();c.ellipse(fx*.5,hy-4,9.4,6.2,0,0,TAU);c.fill();c.strokeStyle='rgba(0,0,0,.25)';c.lineWidth=1;c.beginPath();c.moveTo(-8,hy-3);c.lineTo(8,hy-6);c.moveTo(-8,hy-6);c.lineTo(8,hy-2);c.stroke();break;
    case'helmet':c.beginPath();c.arc(0,hy-.5,9.4,Math.PI,TAU);c.fill();c.fillRect(-9.4,hy-.8,18.8,2.4);c.fillStyle='rgba(255,255,255,.35)';c.beginPath();c.arc(-3,hy-6,3,0,TAU);c.fill();break;
    case'crown':c.beginPath();c.moveTo(-6.4,hy-6);c.lineTo(-6.4,hy-13);c.lineTo(-3.2,hy-9);c.lineTo(0,hy-14);c.lineTo(3.2,hy-9);c.lineTo(6.4,hy-13);c.lineTo(6.4,hy-6);c.closePath();c.fill();break;
    case'bandana':c.fillRect(-8,hy-5.2,16,3.4);c.beginPath();c.arc(back?0:fx*.5,hy-1,8.3,Math.PI,TAU);c.fill();c.fillRect(8,hy-5,3,4);break;
    case'phones':c.strokeStyle=o.hatc;c.lineWidth=2.2;c.beginPath();c.arc(fx*.5,hy-1,8.8,Math.PI,TAU);c.stroke();c.fillStyle=o.hatc;c.beginPath();c.arc(-8.8,hy+.5,3.2,0,TAU);c.arc(8.8,hy+.5,3.2,0,TAU);c.fill();break;
    case'tophat':c.fillRect(-9,hy-6,18,2.4);c.fillRect(-5.4,hy-16,10.8,10.4);c.fillStyle='#c9a227';c.fillRect(-5.4,hy-9,10.8,2);break;
    case'topknot':c.beginPath();c.arc(0,hy-10,3.6,0,TAU);c.fill();c.fillRect(-1,hy-9,2,3);break;
  }
  if(!back)gun();
  // arms
  if(!back||!gw){
    c.lineCap='round';c.strokeStyle=o.top;c.lineWidth=4.6;
    let h1,h2;
    if(gw){h1=[P[0]+ca*8,P[1]+sa*8];h2=[P[0]+ca*L*.62,P[1]+sa*L*.62]}else{h1=[-11,-19-bob];h2=[11,-19-bob]}
    c.beginPath();c.moveTo(-8,-32-bob);c.lineTo(h1[0],h1[1]);c.moveTo(8,-32-bob);c.lineTo(h2[0],h2[1]);c.stroke();
    c.fillStyle=o.skin;c.beginPath();c.arc(h1[0],h1[1],2.7,0,TAU);c.arc(h2[0],h2[1],2.7,0,TAU);c.fill();
  }
  if(op.hit>0){c.fillStyle='rgba(255,255,255,.55)';rr(c,-9,-35-bob,18,20,5);c.fill();c.beginPath();c.arc(0,hy,8,0,TAU);c.fill()}
  c.restore();
}

/* ---------- pets ---------- */
function drawPet(c,kind,x,y,sc,t){
  c.save();c.translate(x,y);c.scale(sc,sc);const b=Math.abs(Math.sin(t*6))*1.5;
  c.fillStyle='rgba(0,0,0,.25)';c.beginPath();c.ellipse(0,1,8,3,0,0,TAU);c.fill();c.translate(0,-b);
  const eye=(ex,ey)=>{c.fillStyle='#111';c.beginPath();c.arc(ex,ey,1.2,0,TAU);c.fill()};
  switch(kind){
    case'fox':c.fillStyle='#e8762c';c.beginPath();c.ellipse(0,-6,7.5,6,0,0,TAU);c.fill();c.beginPath();c.moveTo(-6,-10);c.lineTo(-4,-17);c.lineTo(-1,-11);c.moveTo(6,-10);c.lineTo(4,-17);c.lineTo(1,-11);c.fill();c.fillStyle='#fff';c.beginPath();c.ellipse(0,-3,4,3,0,0,TAU);c.fill();c.fillStyle='#e8762c';c.beginPath();c.ellipse(9,-4,5,2.6,-.5,0,TAU);c.fill();eye(-2.6,-7);eye(2.6,-7);break;
    case'owl':c.fillStyle='#8a6a4a';c.beginPath();c.ellipse(0,-7,7,8,0,0,TAU);c.fill();c.fillStyle='#e8d8b0';c.beginPath();c.ellipse(0,-5,4.6,5.4,0,0,TAU);c.fill();c.fillStyle='#fff';c.beginPath();c.arc(-3,-10,3,0,TAU);c.arc(3,-10,3,0,TAU);c.fill();eye(-3,-10);eye(3,-10);c.fillStyle='#f2a900';c.beginPath();c.moveTo(-1.4,-8);c.lineTo(1.4,-8);c.lineTo(0,-5.4);c.fill();break;
    case'panda':c.fillStyle='#fff';c.beginPath();c.ellipse(0,-6,8,7,0,0,TAU);c.fill();c.fillStyle='#222';c.beginPath();c.arc(-6,-12,3,0,TAU);c.arc(6,-12,3,0,TAU);c.ellipse(-3.2,-7,2.4,3,.3,0,TAU);c.ellipse(3.2,-7,2.4,3,-.3,0,TAU);c.fill();eye(-3.2,-7);eye(3.2,-7);break;
    case'robo':c.fillStyle='#9aa8b6';rr(c,-7,-13,14,12,3);c.fill();c.fillStyle='#2dffd0';c.fillRect(-5,-9,3,3);c.fillRect(2,-9,3,3);c.fillStyle='#667380';c.fillRect(-1,-17,2,4);c.beginPath();c.arc(0,-18,1.8,0,TAU);c.fillStyle='#ff5d6c';c.fill();break;
    case'falcon':c.fillStyle='#7a5a3a';c.beginPath();c.ellipse(0,-6,6,7,0,0,TAU);c.fill();c.fillStyle='#4a3622';c.beginPath();c.moveTo(-5,-5);c.lineTo(-14,-10+Math.sin(t*14)*3);c.lineTo(-4,-9);c.moveTo(5,-5);c.lineTo(14,-10+Math.sin(t*14)*3);c.lineTo(4,-9);c.fill();c.fillStyle='#f2a900';c.beginPath();c.moveTo(-1.4,-9);c.lineTo(1.4,-9);c.lineTo(0,-6);c.fill();eye(-2.4,-10);eye(2.4,-10);break;
    default:c.fillStyle='#c9b8d8';c.beginPath();c.ellipse(0,-6,7.5,6,0,0,TAU);c.fill();c.beginPath();c.moveTo(-6,-10);c.lineTo(-5,-16);c.lineTo(-1.5,-11);c.moveTo(6,-10);c.lineTo(5,-16);c.lineTo(1.5,-11);c.fill();c.strokeStyle='#8a6aa8';c.lineWidth=1;c.beginPath();c.moveTo(-3,-4);c.lineTo(-8,-5);c.moveTo(3,-4);c.lineTo(8,-5);c.stroke();eye(-2.6,-7);eye(2.6,-7);
  }
  c.restore();
}

/* ---------- gun icon (menus) ---------- */
function drawGunIcon(c,id,cx,cy,s,col,gfx){
  if(typeof GunArt!=='undefined'&&GunArt.icon(c,id,cx,cy,s,col,gfx))return;
  const w=WP[id],body=col||w.col,dk='#20272d';
  c.save();c.translate(cx,cy);c.scale(s,s);c.lineCap='round';c.lineJoin='round';
  const R=(x,y,wd,ht,r,f)=>{c.fillStyle=f;rr(c,x,y,wd,ht,r);c.fill()};
  switch(w.cls){
    case'pistol':R(-18,-9,36,11,3,dk);R(-16,-8,32,5,2,body);R(-12,0,10,19,3,dk);break;
    case'smg':R(-32,-9,64,12,3,dk);R(-28,-8,52,5,2,body);R(-6,3,9,24,2,dk);R(-22,2,9,15,3,dk);R(-40,-6,10,10,2,dk);break;
    case'ar':R(-56,-8,92,13,3,dk);R(-50,-7,76,5,2,body);c.strokeStyle=dk;c.lineWidth=4;c.beginPath();c.moveTo(36,-3);c.lineTo(58,-3);c.stroke();R(-8,4,11,24,3,dk);R(-34,3,9,15,3,dk);R(-68,-7,14,16,3,dk);R(-28,-13,14,5,2,dk);break;
    case'lmg':R(-58,-8,96,14,3,dk);R(-52,-7,80,5,2,body);c.strokeStyle=dk;c.lineWidth=4;c.beginPath();c.moveTo(38,-2);c.lineTo(62,-2);c.moveTo(34,6);c.lineTo(46,22);c.moveTo(34,6);c.lineTo(24,22);c.stroke();R(-12,5,26,20,3,dk);R(-70,-7,14,16,3,dk);break;
    case'sg':R(-52,-7,98,10,3,dk);R(-46,-6,80,4,2,body);R(6,-2,24,10,3,dk);R(-66,-6,16,15,3,dk);break;
    case'sn':R(-56,-6,104,9,3,dk);R(-50,-5,86,3,1,body);R(-16,-18,34,9,4,dk);R(-70,-6,16,15,3,dk);R(-6,3,8,16,2,dk);break;
    default:c.strokeStyle=dk;c.lineWidth=4;c.beginPath();c.arc(14,0,26,-1.2,1.2);c.stroke();R(-40,-4,60,8,3,dk);R(-34,-3,46,3,1,body);c.strokeStyle='#ccc';c.lineWidth=1;c.beginPath();c.moveTo(18,-24);c.lineTo(18,24);c.stroke();
  }
  c.restore();
}

/* ---------- touch button icons ---------- */
const SV=(d)=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+d+'</svg>';
const ICONS={
  fire:SV('<circle cx="12" cy="12" r="6.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="1.8" fill="currentColor"/><path d="M12 1.5v5M12 17.5v5M1.5 12h5M17.5 12h5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),
  reload:SV('<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 3v5h-5"/></g>'),
  swap:SV('<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h13l-3-3M20 16H7l3 3"/></g>'),
  gren:SV('<ellipse cx="12" cy="14" rx="6.5" ry="7.5" fill="currentColor"/><rect x="9.5" y="3" width="5" height="4" rx="1" fill="currentColor"/><path d="M14.5 4.5l4-1.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),
  gloo:SV('<path d="M3 9l5-5h13v11l-5 5H3z" fill="currentColor" opacity=".9"/><path d="M3 9h13v11M16 9l5-5" stroke="#000" stroke-opacity=".35" stroke-width="1.5" fill="none"/>'),
  band:SV('<rect x="2" y="8.5" width="20" height="7" rx="3.5" transform="rotate(-35 12 12)" fill="currentColor"/><path d="M10 10l4 4M14 10l-4 4" stroke="#000" stroke-opacity=".4" stroke-width="1.6" stroke-linecap="round"/>'),
  med:SV('<rect x="3" y="6" width="18" height="14" rx="3" fill="currentColor"/><path d="M12 9.5v7M8.5 13h7" stroke="#000" stroke-opacity=".45" stroke-width="2.4" stroke-linecap="round"/><path d="M9 6V4.5h6V6" stroke="currentColor" stroke-width="2" fill="none"/>'),
  smoke:SV('<path d="M7 18a4 4 0 0 1-.6-7.9A5.5 5.5 0 0 1 17 8.8 4.5 4.5 0 0 1 17.5 18z" fill="currentColor"/>'),
  scope:SV('<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="7.5"/><path d="M12 1.5v6M12 16.5v6M1.5 12h6M16.5 12h6"/></g><circle cx="12" cy="12" r="1.6" fill="currentColor"/>'),
  pause:SV('<path d="M8 5v14M16 5v14" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>')
};
