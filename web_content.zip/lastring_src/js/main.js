'use strict';
let prevT=performance.now();
function frame(now){
  const dt=Math.min(.033,(now-prevT)/1000);prevT=now;rdt=dt;
  Music.update(dt);
  if(state==='lobby')lobbyDraw(dt);
  else{update(dt*FX.timeScale());FX.tick(dt);Scope.tick(dt);S=S0*FX.zoomMul()*Scope.mul();draw();Scope.draw();hudUpdate();Drop.hud()}
  requestAnimationFrame(frame);
}
function initUI(){
  $('bFire').innerHTML=ICONS.fire;$('bRel').innerHTML=ICONS.reload+'<i class="bd"></i>';$('bSwap').innerHTML=ICONS.swap;
  $('bGren').innerHTML=ICONS.gren+'<i class="bd"></i>';$('bGloo').innerHTML=ICONS.gloo+'<i class="bd"></i>';
  $('bBand').innerHTML=ICONS.band+'<i class="bd"></i>';$('bMed').innerHTML=ICONS.med+'<i class="bd"></i>';$('bSmk').innerHTML=ICONS.smoke+'<i class="bd"></i>';
  $('bScope').innerHTML=ICONS.scope;$('bPause').innerHTML=ICONS.pause;$('bShoot').innerHTML=ICONS.fire;$('bAP').innerHTML='<span class="at">PICK</span>';$('bRel').querySelector('.bd').remove();
  document.querySelectorAll('[data-p]').forEach(b=>b.addEventListener('click',()=>{snd('click');openPanel(b.dataset.p)}));
  $('pclose').onclick=()=>{snd('click');closePanel()};
  $('start').onclick=()=>{ac();snd('click');needFs=true;autoFs();if(Online.tryStart())return;startMatch()};
  $('lModeBtn').onclick=()=>{snd('click');openPanel('mode')};
  $('dailyBtn').onclick=claimDaily;
  $('again').onclick=()=>{startMatch()};
  $('toLobby').onclick=()=>{showLobby()};
  $('resume').onclick=resumeGame;
  $('pSet').onclick=()=>openPanel('set');
  $('leave').onclick=()=>{showLobby()};
}
I18N.dom();initUI();Online.init();bindInput();resize();addEventListener('resize',()=>{resize()});
showLobby();applyTouchUI();
requestAnimationFrame(frame);
window.__dbg={startMatch,startMatchNow,get state(){return state},get players(){return players},get player(){return player},prof,set,MAPS,genWorld,openPanel,closePanel,update,draw,endMatch,get aliveN(){return aliveN},setState:s=>{state=s}};
