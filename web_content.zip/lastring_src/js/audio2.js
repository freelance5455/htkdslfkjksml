'use strict';
/* =====================================================================
   audio2.js — sound design
   ---------------------------------------------------------------------
   Spat  : 3D spatial sound. Har aawaz WebAudio PannerNode se guzarti hai
           (listener = camera/player, screen ka upar = aage). Door = dheemi, left/right = pan.
   Voice : character voice lines ("Reloading!", "Enemy down!") — browser speech synthesis,
           har character ka alag pitch/rate. Saath mein sir ke upar subtitle text.
   Naye SFX (headshot, kill, hurt, impact, combo, rampage, respawn) draw.js ke snd() switch mein hain.
   ===================================================================== */
const Spat={
  cfg:{
    maxDist:800,       // isse door ki awaaz bilkul nahi (world px)
    refDist:120,       // isse paas full volume
    impactGap:.07      // bullet-impact sound ke beech minimum gap (sec) — SMG par spam na ho
  },
  lastImpact:0,
  // k = snd() key, (x,y) = awaaz ki world position
  play(k,x,y){
    const c=this.cfg,dx=x-cam.x,dy=y-cam.y,d=Math.hypot(dx,dy);
    if(d>c.maxDist)return;
    const a=ac();
    if(!a||!a.createPanner||set.vol<=0){snd(k,clamp(1-d/700,0,1));return}
    const pn=a.createPanner();
    pn.panningModel='equalpower';pn.distanceModel='linear';
    pn.refDistance=c.refDist/100;pn.maxDistance=c.maxDist/100;pn.rolloffFactor=1;
    const px=dx/100,pz=dy/100;                                        // screen right = +x, screen down (peeche) = +z
    if(pn.positionX){pn.positionX.value=px;pn.positionY.value=0;pn.positionZ.value=pz}else pn.setPosition(px,0,pz);
    pn.connect(a.destination);
    SOUT=pn;
    try{snd(k,1)}finally{SOUT=null}
  },
  impact(x,y){                                                        // goli deewar / glue-wall se takraayi
    const now=performance.now()/1000;
    if(now-this.lastImpact<this.cfg.impactGap)return;
    this.lastImpact=now;this.play('impact',x,y);
  }
};

const Voice={
  cfg:{gap:1.4},                                                      // do voice lines ke beech minimum sec
  last:0,
  lines:{
    reload:['Reloading!'],
    kill:['Enemy down!','Got him!','One down!'],
    triple:['Triple kill!'],
    rampage:['Rampage!'],
    respawn:['Back in action!'],
    hurt:['I need healing!'],
    win:['Victory!']
  },
  // character -> [pitch, rate]
  tone:{alok:[1,1.05],chrono:[.8,.95],wukong:[1.2,1.15],skyler:[1.4,1.05],tatsuya:[.9,1.2],oscar:[.6,.9],ryden:[1.05,1],santino:[.75,1],agni:[1.2,1.1],tara:[1.4,1.1]},
  say(key,p){
    p=p||player;
    const arr=this.lines[key];if(!p||!arr)return;
    const now=performance.now()/1000;
    if(now-this.last<this.cfg.gap)return;
    this.last=now;
    const txt=pick(arr);
    FX.text(p.x,p.y-72,txt,'#9fe8ff',15,1.2);                         // subtitle (voice band ho tab bhi dikhe)
    if(!set.voice||set.vol<=0)return;
    const ss=window.speechSynthesis;
    if(!ss||typeof SpeechSynthesisUtterance==='undefined')return;
    try{
      if(ss.speaking)return;
      const u=new SpeechSynthesisUtterance(txt),t=this.tone[p.ch]||[1,1];
      u.pitch=t[0];u.rate=t[1];u.volume=clamp(set.vol,0,1);u.lang='en-US';
      ss.speak(u);
    }catch(e){}
  }
};
