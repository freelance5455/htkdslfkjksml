'use strict';
/* =====================================================================
   hydro.js — Water Worlds core: layout (genWorld ke andar, seeded), collision, gameplay, static paint
   Har map: jharna (cliff + pool) -> nadi (1+ channels) -> pul (deck) -> talab.  Sab MAP-px me.
   Gameplay:  nadi = slow + dhaara (current) | pul = chalne layak (rails, tootte/khulte pul) | garam kund = heal
   ===================================================================== */
const hx=(c,a)=>{const n=parseInt(c.slice(1),16);return'rgba('+(n>>16&255)+','+(n>>8&255)+','+(n&255)+','+a+')'};
const Hydro={
  on:true,idx:-1,rivers:[],falls:[],ponds:[],bridges:[],pts:[],grass:[],rocks:[],P:[],wind:0,tide:0,_wp:0,_hl:0,
  reset(){this.rivers=[];this.falls=[];this.ponds=[];this.bridges=[];this.pts=[];this.grass=[];this.rocks=[];this.P=[];this.idx=-1},
  /* ---------- path helpers ---------- */
  mkPath(pts){
    const p=new Path2D();p.moveTo(pts[0].x,pts[0].y);
    for(let i=1;i<pts.length-1;i++){const mx=(pts[i].x+pts[i+1].x)/2,my=(pts[i].y+pts[i+1].y)/2;p.quadraticCurveTo(pts[i].x,pts[i].y,mx,my)}
    const l=pts[pts.length-1];p.lineTo(l.x,l.y);return p;
  },
  chan(pts,w,o){
    let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9,len=0;
    for(let i=0;i<pts.length;i++){const q=pts[i];if(q.x<x0)x0=q.x;if(q.x>x1)x1=q.x;if(q.y<y0)y0=q.y;if(q.y>y1)y1=q.y;if(i)len+=Math.hypot(q.x-pts[i-1].x,q.y-pts[i-1].y)}
    return Object.assign({pts,w,path:this.mkPath(pts),x0:x0-w,y0:y0-w,x1:x1+w,y1:y1+w,len},o||{});
  },
  /* ---------- generation (genWorld ke andar, seeded) ---------- */
  gen(mi){
    this.reset();const hm=HY_MAP[mi];if(!hm||set.hydro===false)return;this.idx=mi;
    const rv=hyFind('river',hm.r),bv=hyFind('bridge',hm.b),fv=hyFind('fall',hm.f),pv=hyFind('pond',hm.p),S=MAP;
    const nearLk=(x,y,m)=>lakes.some(l=>Math.hypot(l.x-x,l.y-y)<l.r+m);
    let best=null;
    for(let a=0;a<14&&!best;a++){
      const sx=rnd(.22,.78)*S,sy=rnd(.18,.3)*S,dir=Math.random()<.5?-1:1,ex=clamp(sx+dir*rnd(.1,.3)*S,.2*S,.8*S),ey=rnd(.66,.84)*S;
      let bad=false;for(let t=0;t<=1;t+=.05){const x=sx+(ex-sx)*t,y=sy+(ey-sy)*t;if(nearLk(x,y,rv.w*(rv.braid?2:1)+(rv.amp||1)*120)){bad=true;break}}
      if(!bad||a===13)best={sx,sy,ex,ey};
    }
    const {sx,sy,ex,ey}=best;
    /* --- waterfall: cliff face ka bottom-centre = (sx,sy) --- */
    const f=this.mkFall(fv,sx,sy),poolR=f.poolR;
    this.falls.push(f);addObs({k:0,x:f.rect.x,y:f.rect.y,w:f.rect.w,h:f.rect.h,fl:0},f.rect.x,f.rect.y,f.rect.x+f.rect.w,f.rect.y+f.rect.h);
    lakes.push({x:f.px,y:f.py,r:poolR,hv:{fall:f}});
    for(let i=-fv.w/2;i<=fv.w/2;i+=18)this.pts.push({x:sx+i,y:sy-fv.h*.5,r:fv.h*.5+34});
    /* --- pond (nadi ka ant) --- */
    const pr=rnd(pv.r[0],pv.r[1])*Math.max(.85,Math.min(1.3,mp.lkr));
    const pd=this.mkPond(pv,ex,ey,pr);this.ponds.push(pd);lakes.push({x:ex,y:ey,r:pr,hv:{pond:pd}});
    for(let a=0;a<TAU;a+=.45)this.pts.push({x:ex+Math.cos(a)*pr*.6,y:ey+Math.sin(a)*pr*.6,r:pr*.5+26});
    /* --- river path: pool se talab tak --- */
    const s0={x:sx,y:sy+poolR*1.15};
    const dist=Math.hypot(ex-s0.x,ey-s0.y),N=Math.max(8,Math.round(dist/48)),px=-(ey-s0.y)/dist,py=(ex-s0.x)/dist;
    const ph1=rnd(0,6),ph2=rnd(0,6),k1=rnd(1.4,2.4),k2=rnd(3,4.5),amp=(rv.amp||1)*rnd(42,70);
    const main=[];
    for(let i=0;i<=N;i++){
      const t=i/N,env=Math.pow(Math.sin(Math.PI*t),.6),o=(Math.sin(t*Math.PI*k1+ph1)*amp+Math.sin(t*Math.PI*k2+ph2)*amp*.35)*env;
      main.push({x:clamp(s0.x+(ex-s0.x)*t+px*o,160,S-160),y:clamp(s0.y+(ey-s0.y)*t+py*o,160,S-160),t});
    }
    const R={v:rv,chans:[],rocks:[],lv:[],fo:0,tide:0,main,ox:null,seed:Math.random()*100};
    if(rv.braid){
      for(let j=0;j<3;j++){const pts=main.map((q,i)=>{const t=q.t,off=(j-1)*rv.w*1.9*(.55+.45*Math.sin(t*9+j*2))*Math.sin(Math.PI*Math.min(1,t*1.2+.05));return{x:q.x+px*off,y:q.y+py*off}});R.chans.push(this.chan(pts,rv.w,{j}))}
    }else if(rv.delta){
      const k0=Math.round(N*.58);R.chans.push(this.chan(main.slice(0,k0+1).map(q=>({x:q.x,y:q.y})),rv.w,{}));
      for(let j=0;j<3;j++){const pts=[];for(let i=k0;i<=N;i++){const u=(i-k0)/(N-k0),off=(j-1)*rv.w*1.3*u;pts.push({x:main[i].x+px*off,y:main[i].y+py*off})}R.chans.push(this.chan(pts,rv.w*.62,{br:1}))}
    }else R.chans.push(this.chan(main.map(q=>({x:q.x,y:q.y})),rv.w,{}));
    if(rv.tunnel){const c=R.chans[0],n=c.pts.length;c.tun=[Math.floor(n*.3),Math.floor(n*.62)]}
    if(rv.oxbow){const i=Math.floor(N*.3),q=main[i],o=(Math.sin(i/N*Math.PI*k1+ph1)>0?1:-1);R.ox={x:q.x+px*o*rv.w*1.8,y:q.y+py*o*rv.w*1.8,r:rv.w*.7,rot:Math.atan2(py,px)}}
    for(const c of R.chans){
      c.dry=!!rv.dry;
      for(let i=0;i<c.pts.length;i+=1)this.pts.push({x:c.pts[i].x,y:c.pts[i].y,r:c.w*.5+8+(rv.braid?c.w*1.2:0)});
    }
    if(R.ox)this.pts.push({x:R.ox.x,y:R.ox.y,r:R.ox.r+20});
    if(rv.rocks||rv.gravel){const c=R.chans[0],n=rv.rocks||14;for(let i=0;i<n;i++){const q=c.pts[Math.floor(rnd(1,c.pts.length-1))],a=rnd(0,TAU),d=rnd(0,c.w*.38);R.rocks.push({x:q.x+Math.cos(a)*d,y:q.y+Math.sin(a)*d,r:rnd(5,rv.gravel?9:14),ph:rnd(0,6)})}}
    if(rv.leaves)for(const c of R.chans)for(let i=0;i<7;i++)R.lv.push({c,u:rnd(0,1),off:rnd(-.35,.35),ph:rnd(0,6),r:rnd(2.5,4.5)});
    this.rivers.push(R);
    /* --- grass / reeds: nadi ke kinaaron par (hawa me hilte) --- */
    const gcol=[mp.g[1],mp.g[2],mp.g[0]];let gn=0;
    for(const c of R.chans){
      for(let i=0;i<c.pts.length-1&&gn<620;i++){
        const a=c.pts[i],b=c.pts[i+1],dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy)||1;
        for(let k=0;k<3;k++){const side=Math.random()<.5?-1:1,u=Math.random(),off=side*(c.w*.5+rnd(8,34));
          const x=a.x+dx*u-dy/l*off,y=a.y+dy*u+dx/l*off;
          if(nearLk(x,y,-6))continue;
          this.grass.push({x,y,h:rnd(8,rv.reeds||rv.snow?26:17),ph:rnd(0,6),c:rv.snow?'#dfe7ea':rv.reeds?'#7a8a4a':gcol[k%3],n:1+Math.floor(Math.random()*3)});gn++}
      }
    }
    /* --- bridge: nadi par, beech me (perpendicular) --- */
    const mc=R.chans[0],bi=Math.floor(mc.pts.length*rnd(.4,.52)),bp=mc.pts[bi],q0=mc.pts[Math.max(0,bi-1)],q1=mc.pts[Math.min(mc.pts.length-1,bi+1)];
    const tx=q1.x-q0.x,ty=q1.y-q0.y,tl=Math.hypot(tx,ty)||1,nx=-ty/tl,ny=tx/tl;
    let smin=1e9,smax=-1e9;
    for(let s=-260;s<=260;s+=4){const x=bp.x+nx*s,y=bp.y+ny*s;if(this.rawIn(R,x,y)){smin=Math.min(smin,s);smax=Math.max(smax,s)}}
    if(smin>smax){smin=-rv.w/2;smax=rv.w/2}
    const mid=(smin+smax)/2,span=smax-smin,L=Math.round(span+72);
    const b=this.mkBridge(bv,bp.x+nx*mid,bp.y+ny*mid,Math.atan2(ny,nx),L,R,bi);
    this.bridges.push(b);
    const W2=(lx,ly)=>({x:b.cx+b.cs*lx-b.sn*ly,y:b.cy+b.sn*lx+b.cs*ly});
    if(bv.cables||bv.truss||bv.swing||bv.cables===2)for(const sg of[-1,1]){const p=W2(sg*(L/2-6),0);if(bv.cables===2||bv.swing)break;for(const sy2 of[-1,1]){const pp=W2(sg*(L/2-6),sy2*(bv.W/2+9));addObs({k:1,x:pp.x,y:pp.y,r:7,fl:0},pp.x-7,pp.y-7,pp.x+7,pp.y+7)}}
    if(bv.cables===2){const p=W2(0,0);for(const sy2 of[-1,1]){const pp=W2(0,sy2*(bv.W/2+10));addObs({k:1,x:pp.x,y:pp.y,r:8,fl:0},pp.x-8,pp.y-8,pp.x+8,pp.y+8)}}
    if(bv.swing){const p=W2(0,bv.W/2+14);addObs({k:1,x:p.x,y:p.y,r:12,fl:0},p.x-12,p.y-12,p.x+12,p.y+12)}
    this.pts.push({x:b.cx,y:b.cy,r:L*.5+20});
  },
  mkFall(fv,sx,sy){
    const D=46,fw=fv.w,fh=fv.h,poolR=Math.max(64,Math.min(fv.round?112:98,fw*.5+22));
    const f={v:fv,x:sx,y:sy,w:fw,h:fh,D,poolR,px:sx,py:sy+poolR*.5,moss:[],ice:[],seed:Math.random()*100,ph:Math.random()*6};
    f.rect={x:sx-fw/2-16,y:sy-fh-D,w:fw+32,h:fh+D};
    for(let i=0;i<14;i++)f.moss.push({x:rnd(-fw/2,fw/2),y:rnd(-fh,-4),r:rnd(5,16)});
    f.ice=Array.from({length:12},()=>({x:rnd(-fw/2,fw/2),l:rnd(8,26)}));
    return f;
  },
  mkPond(pv,ex,ey,pr){
    const pd={v:pv,x:ex,y:ey,r:pr,seed:Math.random()*100,sh:[],lily:[],koi:[],reeds:[],rocks:[],ice:[],fl:[],ph:Math.random()*6};
    for(let i=0;i<28;i++)pd.sh.push(1+rnd(-.06,.06)+(pv.quarry?(i%7<2?-.05:0):0));
    if(pv.lily)for(let i=0;i<14;i++){const a=rnd(0,TAU),d=rnd(.15,.85)*pr;pd.lily.push({x:Math.cos(a)*d,y:Math.sin(a)*d,r:rnd(7,13),ph:rnd(0,6),f:Math.random()<.35})}
    if(pv.koi)for(let i=0;i<5;i++)pd.koi.push({a:rnd(0,TAU),d:rnd(.25,.65)*pr,sp:rnd(.25,.5)*(i%2?1:-1),c:['#ff7a3a','#fff0e0','#ffb347','#ff5a4a','#ffd9a0'][i]});
    if(pv.reeds||pv.palms)for(let i=0;i<(pv.palms?5:46);i++){const a=pv.palms?i/5*TAU+rnd(-.3,.3):rnd(0,TAU);pd.reeds.push({a,d:pr*(pv.palms?1.12:rnd(.9,1.12)),h:rnd(24,46),ph:rnd(0,6)})}
    if(pv.rocks||pv.quarry||pv.ice)for(let i=0;i<(pv.ice?16:12);i++){const a=rnd(0,TAU);pd.rocks.push({a,d:pr*rnd(.96,1.14),r:rnd(7,17)})}
    if(pv.ice)for(let i=0;i<7;i++){const a=rnd(0,TAU),d=rnd(.1,.7)*pr;pd.ice.push({x:Math.cos(a)*d,y:Math.sin(a)*d,r:rnd(10,22),rot:rnd(0,3)})}
    if(pv.fairy)for(let i=0;i<9;i++)pd.fl.push({a:rnd(0,TAU),d:rnd(.2,1.1)*pr,sp:rnd(.2,.6),ph:rnd(0,6)});
    return pd;
  },
  mkBridge(bv,cx,cy,ang,L,R,bi){
    const b={v:bv,cx,cy,ang,L,W:bv.W,t0:Math.random()*10,ang01:0,sw:0,r:R,bi};
    b.cs=Math.cos(ang);b.sn=Math.sin(ang);b.rails=!['log','stone_slab','plank','pontoon','living_root'].includes(bv.id);
    if(bv.broken){b.g0=-L*.1;b.g1=L*.18}
    return b;
  },
  rawIn(R,x,y){
    for(const c of R.chans){if(x<c.x0||x>c.x1||y<c.y0||y>c.y1)continue;const hw=c.w*.5;
      for(let i=0;i<c.pts.length-1;i++){const a=c.pts[i],b=c.pts[i+1],dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy||1,u=clamp(((x-a.x)*dx+(y-a.y)*dy)/l2,0,1),ex=a.x+dx*u-x,ey=a.y+dy*u-y;if(ex*ex+ey*ey<hw*hw)return true}}
    return false;
  },
  /* houses / trees / loot paani se door rahein */
  near(x,y,w,h,m){
    const P=this.pts;for(let i=0;i<P.length;i++){const c=P[i],px=clamp(c.x,x,x+w),py=clamp(c.y,y,y+h);if((c.x-px)**2+(c.y-py)**2<(c.r+m)**2)return true}
    for(const f of this.falls){const r=f.rect;if(x<r.x+r.w+m&&x+w>r.x-m&&y<r.y+r.h+m&&y+h>r.y-m)return true}
    return false;
  },
  /* ---------- queries ---------- */
  wetInfo(x,y){
    for(const R of this.rivers){
      for(const c of R.chans){
        if(x<c.x0||x>c.x1||y<c.y0||y>c.y1)continue;
        const hw=c.w*.5*(c.dry?.22:1);let bd=1e9,bt=null;
        for(let i=0;i<c.pts.length-1;i++){const a=c.pts[i],b=c.pts[i+1],dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy||1,u=clamp(((x-a.x)*dx+(y-a.y)*dy)/l2,0,1),ex=a.x+dx*u-x,ey=a.y+dy*u-y,d=ex*ex+ey*ey;if(d<bd){bd=d;bt=i}}
        if(bd<hw*hw){const a=c.pts[bt],b=c.pts[bt+1],l=Math.hypot(b.x-a.x,b.y-a.y)||1;return{R,c,tx:(b.x-a.x)/l,ty:(b.y-a.y)/l}}
      }
    }
    return null;
  },
  deck(x,y){
    for(const b of this.bridges){
      const dx=x-b.cx,dy=y-b.cy;if(dx*dx+dy*dy>(b.L*.6)**2)continue;
      const lx=dx*b.cs+dy*b.sn,ly=-dx*b.sn+dy*b.cs;
      if(Math.abs(lx)>b.L/2||Math.abs(ly)>b.W/2)continue;
      if(b.ang01>.15)continue;
      if(b.g0!=null&&lx>b.g0&&lx<b.g1)continue;
      return b;
    }
    return null;
  },
  wet(x,y){const w=this.wetInfo(x,y);return !!w&&!this.deck(x,y)},
  /* rails (side railing) — fix() ke baad chalta hai; sirf chalne ko roke, goli ko nahi */
  fix(e){
    for(const b of this.bridges){
      if(!b.rails||b.ang01>.15)continue;
      const dx=e.x-b.cx,dy=e.y-b.cy;if(dx*dx+dy*dy>(b.L*.6)**2)continue;
      let lx=dx*b.cs+dy*b.sn,ly=-dx*b.sn+dy*b.cs;
      const hl=b.L/2-10,hw=b.W/2,r=(e.r||12)*.55;
      if(Math.abs(lx)>hl+r)continue;
      if(b.g0!=null&&lx>b.g0-r&&lx<b.g1+r)continue;
      const a=Math.abs(ly);
      if(a>hw-r&&a<hw+r){const s=ly<0?-1:1,ny=a>=hw?(hw+r)*s:(hw-r)*s;ly=ny;e.x=b.cx+b.cs*lx-b.sn*ly;e.y=b.cy+b.sn*lx+b.cs*ly}
    }
  },
  /* ---------- per-entity: dhaara, splash, heal ---------- */
  entity(p,dt){
    if(!p.alive||p.air)return;
    const wi=this.wetInfo(p.x,p.y),dk=wi&&this.deck(p.x,p.y),inR=wi&&!dk;
    if(inR){
      const v=wi.R.v,fac=v.tide?Math.sin(this.tide):1,push=v.fl*.42*fac;
      p.x+=wi.tx*push*dt;p.y+=wi.ty*push*dt;fix(p);
    }
    let lk=null;if(!inR)for(const l of lakes){if(!l.hv)continue;const dx=p.x-l.x,dy=p.y-l.y;if(dx*dx+dy*dy<l.r*l.r){lk=l;break}}
    const wetNow=inR||!!lk;
    if(wetNow!==!!p._hw){
      p._hw=wetNow;
      if(p===player){this.splash(p.x,p.y,1);Spat.play('hy_splash',p.x,p.y)}
      else if(Math.abs(p.x-cam.x)<700&&Math.abs(p.y-cam.y)<500){this.splash(p.x,p.y,.7);if(Math.random()<.5)Spat.play('hy_splash',p.x,p.y)}
    }
    if(wetNow&&(p.mv||0)>.2){
      p._ws=(p._ws||0)-dt;
      if(p._ws<=0){p._ws=.28;this.splash(p.x,p.y,.35);if(p===player)snd('hy_wstep',1)}
    }
    const hv=lk&&lk.hv.pond&&lk.hv.pond.v;
    if(hv&&hv.heal&&p.hp<MAXHP){p.hp=Math.min(MAXHP,p.hp+hv.heal*HPM*dt);if(p===player&&time-this._hl>2.5){this._hl=time;FX.text(p.x,p.y-80,'+HP','#7bffb0',14,.9);if(!this._ht){this._ht=1;toast(T('Hot spring: slowly healing'))}}}
  },
  /* ---------- per-frame ---------- */
  update(dt){
    if(this.idx<0)return;
    this.wind=Math.sin(time*.7)*.5+Math.sin(time*.23+1)*.5;this.tide+=dt*.22;
    for(const R of this.rivers){R.fo+=R.v.fl*dt*(R.v.tide?Math.sin(this.tide):1)*.9;for(const l of R.lv){l.u+=R.v.fl*dt*.0006*(R.v.tide?Math.sin(this.tide):1)/Math.max(.3,l.c.len/1000);if(l.u>1)l.u-=1;if(l.u<0)l.u+=1}}
    for(const b of this.bridges){
      const v=b.v;
      if(v.draw||v.swing){const ph=(time+b.t0)%(v.swing?26:22),a=v.swing?18:15;b.ang01=ph<a?0:ph<a+2.5?(ph-a)/2.5:ph<a+5?1:1-(ph-a-5)/2;b.ang01=clamp(b.ang01,0,1)}
      b.sw=Math.sin(time*1.3+b.t0)*(v.sway?1:.35);
    }
    this.fxUpdate(dt);
  },
  /* ---------- static paint (ground canvas, MAP units) ---------- */
  paint(g){
    if(this.idx<0)return;
    this.paintRivers(g);for(const p of this.ponds)this.paintPond(g,p);for(const f of this.falls)this.paintFall(g,f);for(const b of this.bridges)this.paintBridgeAO(g,b);
  },
  paintRivers(g){
    g.lineCap='round';g.lineJoin='round';
    for(const R of this.rivers){
      const v=R.v;
      for(const c of R.chans){
        const w=c.w;
        if(v.walls){g.strokeStyle='rgba(40,26,20,.55)';g.lineWidth=w*2.7;g.stroke(c.path);g.strokeStyle=hx(v.b,.85);g.lineWidth=w*2.05;g.stroke(c.path)}
        g.strokeStyle='rgba(0,0,0,.10)';g.lineWidth=w*2.15;g.stroke(c.path);                                  // ambient occlusion
        g.strokeStyle=hx(v.b,v.mud?.7:.55);g.lineWidth=w*1.72;g.stroke(c.path);                               // wet bank
        if(v.mud){g.strokeStyle='rgba(70,56,36,.55)';g.lineWidth=w*1.95;g.stroke(c.path)}
        g.strokeStyle='rgba(24,18,10,.22)';g.lineWidth=w*1.36;g.stroke(c.path);                              // wet edge
        if(v.snow){g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=w*1.9;g.stroke(c.path);g.strokeStyle=hx(v.b,.8);g.lineWidth=w*1.45;g.stroke(c.path)}
        if(v.lava){g.strokeStyle='rgba(255,100,30,.22)';g.lineWidth=w*2.4;g.stroke(c.path);g.strokeStyle='rgba(255,140,50,.34)';g.lineWidth=w*1.6;g.stroke(c.path)}
        if(v.dry){
          g.strokeStyle=hx(v.s,.95);g.lineWidth=w*1.18;g.stroke(c.path);
          g.strokeStyle='rgba(110,84,50,.35)';g.lineWidth=w*.8;g.stroke(c.path);
          g.strokeStyle=hx(v.d,.95);g.lineWidth=Math.max(5,w*.2);g.stroke(c.path);
          g.strokeStyle='rgba(255,255,255,.22)';g.lineWidth=2;g.stroke(c.path);
          if(v.cracks){g.strokeStyle='rgba(70,50,30,.35)';g.lineWidth=1.3;g.beginPath();for(let i=0;i<c.pts.length-1;i++){const q=c.pts[i];for(let k=0;k<5;k++){const ox=rnd(-w*.5,w*.5),oy=rnd(-w*.5,w*.5);g.moveTo(q.x+ox,q.y+oy);g.lineTo(q.x+ox+rnd(-14,14),q.y+oy+rnd(-14,14));g.lineTo(q.x+ox+rnd(-20,20),q.y+oy+rnd(-20,20))}}g.stroke()}
          continue;
        }
        g.strokeStyle=hx(v.s,.95);g.lineWidth=w*1.14;g.stroke(c.path);                                       // shallow
        g.strokeStyle=hx(v.d,.96);g.lineWidth=w*.72;g.stroke(c.path);                                        // deep
        g.strokeStyle='rgba(0,20,40,.22)';g.lineWidth=w*.38;g.stroke(c.path);                                // deep core
        if(v.milky){g.strokeStyle='rgba(220,255,255,.22)';g.lineWidth=w*.9;g.stroke(c.path)}
        if(v.algae){g.strokeStyle='rgba(120,160,60,.32)';g.lineWidth=w*.5;g.setLineDash([16,14]);g.stroke(c.path);g.setLineDash([])}
        if(v.ice){g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=w*1.12;g.setLineDash([3,26]);g.stroke(c.path);g.setLineDash([])}
        if(v.tunnel&&c.tun){g.strokeStyle='rgba(8,14,24,.5)';g.lineWidth=w*1.4}
        if(v.glow){g.strokeStyle=hx(v.glow,.1);g.lineWidth=w*1.25;g.stroke(c.path)}
      }
      /* rocks / gravel / silt bars */
      for(const k of R.rocks){
        g.fillStyle='rgba(0,0,0,.28)';g.beginPath();g.ellipse(k.x+3,k.y+4,k.r*1.1,k.r*.8,0,0,TAU);g.fill();
        g.fillStyle=v.gravel?'#a89c84':'#6c6a66';g.beginPath();g.ellipse(k.x,k.y,k.r,k.r*.78,k.ph,0,TAU);g.fill();
        g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.ellipse(k.x-k.r*.25,k.y-k.r*.25,k.r*.5,k.r*.3,k.ph,0,TAU);g.fill();
      }
      if(v.braid){g.fillStyle='rgba(170,160,130,.55)';g.beginPath();const a=R.chans[0],b=R.chans[2];for(let i=2;i<a.pts.length-2;i+=3){const x=(a.pts[i].x+b.pts[i].x)/2,y=(a.pts[i].y+b.pts[i].y)/2;g.moveTo(x+30,y);g.ellipse(x,y,30,13,Math.atan2(a.pts[i+1].y-a.pts[i].y,a.pts[i+1].x-a.pts[i].x),0,TAU)}g.fill()}
      if(R.ox){const o=R.ox;g.fillStyle=hx(v.b,.5);g.beginPath();g.ellipse(o.x,o.y,o.r*1.7,o.r*.9,o.rot,0,TAU);g.fill();g.fillStyle=hx(v.d,.95);g.beginPath();g.ellipse(o.x,o.y,o.r*1.45,o.r*.65,o.rot,0,TAU);g.fill();g.fillStyle=hx(v.s,.5);g.beginPath();g.ellipse(o.x-3,o.y-3,o.r*1.1,o.r*.4,o.rot,0,TAU);g.fill()}
    }
  },
  poly(g,p,k,rr){g.beginPath();const n=p.sh.length;for(let i=0;i<n;i++){const a=i/n*TAU,r=p.r*(p.sh[i])*k+(rr||0);i?g.lineTo(p.x+Math.cos(a)*r,p.y+Math.sin(a)*r):g.moveTo(p.x+Math.cos(a)*r,p.y+Math.sin(a)*r)}g.closePath()},
  paintPond(g,p){
    const v=p.v,r=p.r,c=v.c;
    this.poly(g,p,1,26);g.fillStyle=hx(v.rim,.55);g.fill();                                       // shore
    this.poly(g,p,1,12);g.fillStyle='rgba(20,14,6,.22)';g.fill();                                  // wet edge
    if(v.crust){this.poly(g,p,1,22);g.fillStyle='rgba(255,255,255,.75)';g.fill();this.poly(g,p,1,10);g.fillStyle='rgba(240,200,210,.8)';g.fill()}
    if(v.ice){this.poly(g,p,1,24);g.fillStyle='rgba(240,250,255,.85)';g.fill();g.strokeStyle='rgba(120,170,200,.6)';g.lineWidth=1.2;g.beginPath();for(let i=0;i<30;i++){const a=rnd(0,TAU),d=r*rnd(1,1.15);g.moveTo(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d);g.lineTo(p.x+Math.cos(a+.2)*(d+14),p.y+Math.sin(a+.2)*(d+14))}g.stroke()}
    if(v.quarry){for(let k=3;k>=1;k--){g.fillStyle=['#6a665c','#7e7a6e','#938e80'][3-k];g.beginPath();for(let i=0;i<4;i++){const a=i/4*TAU+.4;g.lineTo(p.x+Math.cos(a)*(r+10+k*9)*1.35,p.y+Math.sin(a)*(r+10+k*9)*1.35)}g.closePath();g.fill()}}
    if(v.glowRim){this.poly(g,p,1,16);g.fillStyle=hx(v.glowRim,.38);g.fill();this.poly(g,p,1,6);g.fillStyle='rgba(30,20,22,.7)';g.fill()}
    if(v.cave){this.poly(g,p,1,28);g.fillStyle='rgba(10,14,20,.6)';g.fill()}
    const gr=g.createRadialGradient(p.x-r*.15,p.y-r*.15,r*.05,p.x,p.y,r);gr.addColorStop(0,c[2]);gr.addColorStop(.55,c[1]);gr.addColorStop(1,c[0]);
    this.poly(g,p,1);g.fillStyle=gr;g.fill();
    this.poly(g,p,.86);g.strokeStyle='rgba(255,255,255,.10)';g.lineWidth=7;g.stroke();            // shallow rim glow
    this.poly(g,p,1);g.strokeStyle='rgba(255,255,255,.28)';g.lineWidth=2;g.stroke();               // wet-edge highlight
    if(v.clear){g.fillStyle='rgba(120,100,70,.35)';g.beginPath();for(let i=0;i<40;i++){const a=rnd(0,TAU),d=Math.sqrt(Math.random())*r*.9;g.moveTo(p.x+Math.cos(a)*d+4,p.y+Math.sin(a)*d);g.arc(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d,rnd(2,6),0,TAU)}g.fill();g.fillStyle='rgba(255,255,255,.12)';g.beginPath();g.ellipse(p.x,p.y,r*.6,r*.4,.4,0,TAU);g.fill()}
    if(v.algae||v.moss){g.fillStyle=v.algae?'rgba(110,150,50,.45)':'rgba(70,130,60,.35)';g.beginPath();for(let i=0;i<22;i++){const a=rnd(0,TAU),d=Math.sqrt(Math.random())*r*.85,rr=rnd(10,30);g.moveTo(p.x+Math.cos(a)*d+rr,p.y+Math.sin(a)*d);g.ellipse(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d,rr,rr*.6,rnd(0,3),0,TAU)}g.fill()}
    if(v.springs){const gg=g.createRadialGradient(p.x,p.y,2,p.x,p.y,r*.35);gg.addColorStop(0,'rgba(240,235,200,.7)');gg.addColorStop(1,'rgba(240,235,200,0)');g.fillStyle=gg;g.beginPath();g.arc(p.x,p.y,r*.35,0,TAU);g.fill()}
    if(v.glowRim||v.steam===2){const gg=g.createRadialGradient(p.x,p.y,r*.3,p.x,p.y,r);gg.addColorStop(0,'rgba(255,160,60,0)');gg.addColorStop(1,'rgba(255,120,40,.35)');g.fillStyle=gg;this.poly(g,p,1);g.fill()}
    if(v.bubbles||v.id==='bog'){g.fillStyle='rgba(18,16,10,.35)';g.beginPath();for(let i=0;i<24;i++){const a=rnd(0,TAU),d=Math.sqrt(Math.random())*r*.9;g.moveTo(p.x+Math.cos(a)*d+8,p.y+Math.sin(a)*d);g.ellipse(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d,rnd(8,20),rnd(5,12),rnd(0,3),0,TAU)}g.fill()}
    for(const k of p.rocks){const x=p.x+Math.cos(k.a)*k.d,y=p.y+Math.sin(k.a)*k.d;
      g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(x+3,y+4,k.r*1.1,k.r*.8,0,0,TAU);g.fill();
      g.fillStyle=v.ice?'#dbeaf2':'#76736c';g.beginPath();g.ellipse(x,y,k.r,k.r*.78,k.a,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.25)';g.beginPath();g.ellipse(x-k.r*.25,y-k.r*.28,k.r*.5,k.r*.3,0,0,TAU);g.fill()}
  },
  paintFall(g,f){
    const v=f.v,w=f.w,h=f.h,D=f.D,x0=f.x-w/2-16,y0=f.y-h-D,cw=w+32,ch=h+D,rk=v.rock;
    g.fillStyle='rgba(0,0,0,.22)';g.fillRect(x0+8,y0+10,cw+10,ch+14);                              // AO / cast shadow
    g.fillStyle=rk[2];g.fillRect(x0,y0,cw,ch);
    // plateau (top)
    let gr=g.createLinearGradient(0,y0,0,y0+D);gr.addColorStop(0,rk[0]);gr.addColorStop(1,rk[1]);g.fillStyle=gr;g.fillRect(x0,y0,cw,D);
    // face (front)
    gr=g.createLinearGradient(0,y0+D,0,y0+ch);gr.addColorStop(0,rk[1]);gr.addColorStop(1,rk[2]);g.fillStyle=gr;g.fillRect(x0,y0+D,cw,h);
    // strata + cracks
    g.strokeStyle='rgba(0,0,0,.22)';g.lineWidth=1.6;g.beginPath();for(let i=0;i<14;i++){const x=x0+rnd(4,cw-4),y=y0+D+rnd(4,h-10);g.moveTo(x,y);g.lineTo(x+rnd(-6,6),y+rnd(14,36))}g.stroke();
    g.strokeStyle='rgba(255,255,255,.14)';g.beginPath();for(let i=0;i<9;i++){const y=y0+D+8+i*(h-14)/9;g.moveTo(x0+3,y);g.lineTo(x0+cw-3,y+rnd(-2,2))}g.stroke();
    g.fillStyle='rgba(255,255,255,.12)';g.fillRect(x0,y0,cw,3);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(x0,y0+ch-4,cw,4);
    // plateau stones
    for(let i=0;i<12;i++){const x=x0+rnd(6,cw-6),y=y0+rnd(6,D-6),r=rnd(4,10);g.fillStyle='rgba(0,0,0,.2)';g.beginPath();g.ellipse(x+2,y+3,r,r*.7,0,0,TAU);g.fill();g.fillStyle=rk[0];g.beginPath();g.ellipse(x,y,r,r*.7,0,0,TAU);g.fill()}
    if(v.moss)for(const m of f.moss){g.fillStyle='rgba(70,130,50,.5)';g.beginPath();g.ellipse(f.x+m.x,f.y+m.y,m.r,m.r*.6,0,0,TAU);g.fill()}
    // pool
    const P={x:f.px,y:f.py,r:f.poolR,sh:Array.from({length:28},(_,i)=>1+Math.sin(i*2.3+f.seed)*.05)};
    this.poly(g,P,1,16);g.fillStyle=hx(mp.sh,.6);g.fill();this.poly(g,P,1,6);g.fillStyle='rgba(10,20,20,.25)';g.fill();
    const pc=v.glow?v.col:v.col;gr=g.createRadialGradient(P.x,P.y-P.r*.2,4,P.x,P.y,P.r);gr.addColorStop(0,hx(pc,.9));gr.addColorStop(.35,hx(mp.wat,1));gr.addColorStop(1,'rgba(20,70,90,1)');
    this.poly(g,P,1);g.fillStyle=gr;g.fill();
    if(v.glow){const g2=g.createRadialGradient(P.x,P.y,0,P.x,P.y,P.r);g2.addColorStop(0,hx(v.glow,.45));g2.addColorStop(1,hx(v.glow,0));g.fillStyle=g2;g.beginPath();g.arc(P.x,P.y,P.r*1.1,0,TAU);g.fill()}
    this.poly(g,P,1);g.strokeStyle='rgba(255,255,255,.3)';g.lineWidth=2;g.stroke();
    if(v.steam||v.glow&&v.id==='volcanic'){g.fillStyle='rgba(255,110,40,.22)';this.poly(g,P,1,10);g.fill()}
    if(v.ice){g.fillStyle='rgba(235,248,255,.7)';this.poly(g,P,.72);g.fill()}
    // wet rocks at pool
    for(let i=0;i<9;i++){const a=Math.PI*(.15+i/9*.7),x=P.x+Math.cos(a)*P.r*1.04,y=P.y+Math.sin(a)*P.r*.98,r=rnd(8,15);g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(x+3,y+4,r,r*.75,0,0,TAU);g.fill();g.fillStyle=rk[1];g.beginPath();g.ellipse(x,y,r,r*.75,0,0,TAU);g.fill();g.fillStyle='rgba(180,210,230,.28)';g.beginPath();g.ellipse(x-r*.2,y-r*.3,r*.55,r*.28,0,0,TAU);g.fill()}
  },
  paintBridgeAO(g,b){
    g.save();g.translate(b.cx,b.cy);g.rotate(b.ang);
    g.fillStyle='rgba(0,0,0,.18)';g.fillRect(-b.L/2-8,-b.W/2-6,b.L+16,b.W+14);
    g.fillStyle=hx(b.r.v.b,.6);g.fillRect(-b.L/2-6,-b.W/2-2,22,b.W+4);g.fillRect(b.L/2-16,-b.W/2-2,22,b.W+4);   // bank landings
    g.restore();
  }
};
