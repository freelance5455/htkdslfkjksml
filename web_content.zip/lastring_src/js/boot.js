'use strict';
/* ---------- landscape: fullscreen + lock, warna portrait me rotate ---------- */
const ROOT=document.documentElement;
function fit(){
  const w=innerWidth,h=innerHeight;
  ROOT.style.setProperty('--W',w+'px');ROOT.style.setProperty('--H',h+'px');
  ROOT.classList.toggle('rot',isTouch&&h>w);
}
const _resize=window.resize;
window.resize=function(){fit();_resize()};
addEventListener('orientationchange',()=>setTimeout(()=>window.resize(),250));
async function goLandscape(){
  try{
    if(!document.fullscreenElement&&ROOT.requestFullscreen)await ROOT.requestFullscreen({navigationUI:'hide'});
    if(screen.orientation&&screen.orientation.lock)await screen.orientation.lock('landscape');
  }catch(e){}
  window.resize();
}
/* Automatic immersive mode: hides the Android status + navigation bar (triangle / circle / square).
   Browsers only allow fullscreen from a tap, so: on START, on the first tap, and again after the user exits fullscreen. */
let needFs=true;
function autoFs(){if(set.autoFs===false||!needFs||document.fullscreenElement)return;needFs=false;goLandscape()}
addEventListener('pointerdown',autoFs,true);
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)needFs=true});
// pichhli baar start par crash hua tha? to graphics low kar do
try{const st=localStorage.getItem('lr_stage');if(st){localStorage.removeItem('lr_stage');set.gfx='low';save();
  const d=document.getElementById('err');d.hidden=false;d.textContent=T('The game crashed at startup last time ({0}) — graphics were set to "Low" automatically',st);setTimeout(()=>{d.hidden=true},9000)}}catch(e){}

/* ---------- Free Fire style loading screen ---------- */
const TIPS=[T('Stay inside the zone — outside it you lose health every second'),T('From an upper floor you can see the whole house — walk onto the stairs (the arrow pad)'),T('A medkit restores full health, a bandage heals slowly'),T('Block enemy bullets with a Gloo Wall'),T('Throw a grenade to force enemies out of the house'),T('A sniper on a high floor is the most dangerous')];
const Loader={
  el:document.getElementById('loading'),p:0,tgt:0,raf:0,last:0,
  show(sub){
    const L=this,g=id=>document.getElementById(id);
    L.p=0;L.tgt=8;L.el.hidden=false;L.el.classList.remove('out');
    g('ldSub').textContent=sub||T('Survival Battle Royale');
    g('ldTip').textContent=T('Tip: {0}',TIPS[Math.floor(Math.random()*TIPS.length)]);
    g('ldMsg').textContent=T('Loading…');
    L.last=performance.now();cancelAnimationFrame(L.raf);clearInterval(L.iv);L.iv=setInterval(()=>{if(L.el.hidden)clearInterval(L.iv);else L.tick(performance.now())},60);L.tick(L.last);   // rAF ruk jaye (fullscreen/rotate) tab bhi bar chalta rahe
  },
  set(t,m){this.tgt=t;if(m)document.getElementById('ldMsg').textContent=m},
  tick(now){
    const L=Loader,dt=Math.min(.05,(now-L.last)/1000);L.last=now;
    L.p+=(L.tgt-L.p)*Math.min(1,dt*3)+(L.tgt<100?dt*1.5:0);
    if(L.p>L.tgt)L.p=L.tgt;if(L.tgt>=100&&L.p>99.4)L.p=100;
    document.getElementById('ldFill').style.width=L.p+'%';
    document.getElementById('ldPct').textContent=Math.floor(L.p)+'%';
    if(!L.el.hidden)L.raf=requestAnimationFrame(L.tick);
  },
  hide(){
    const L=this;
    const go=()=>{if(L.p<99.5){setTimeout(go,60);return}L.el.classList.add('out');setTimeout(()=>{L.el.hidden=true;L.el.classList.remove('out')},480)};
    L.tgt=100;go();
  }
};
// game khulne se pehle: boot loading
Loader.show(T('Survival Battle Royale'));Loader.set(40,T('Preparing fonts and sounds…'));
window.resize();
Promise.race([document.fonts?document.fonts.ready:Promise.resolve(),new Promise(r=>setTimeout(r,2500))]).then(()=>{
  Loader.set(80,T('Preparing the world…'));
  setTimeout(()=>{Loader.set(100,T('Ready!'));setTimeout(()=>Loader.hide(),300)},1300);
});
