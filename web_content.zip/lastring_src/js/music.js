'use strict';
/* =====================================================================
   music.js — dynamic music (koi audio file nahi; sab WebAudio se bajta hai)
   ---------------------------------------------------------------------
   Do layer EK HI beat-grid par hamesha chalte hain, isliye crossfade bilkul sync mein rehta hai:
     calm   : soft pad chords + halka arpeggio
     combat : kick + bass + hi-hat + stab lead (tez, intense)
   Combat tab jab: koi dushman `combatRadius` (300px) ke andar ho YA player fire kar raha ho.
   Trigger hatne ke `holdSec` (3s) baad wapas calm. Dono taraf `fade` sec ka crossfade.
   Settings: set.music (on/off), set.musicVol, aur master set.vol.
   ===================================================================== */
const Music={
  cfg:{
    bpm:120,
    combatRadius:300,   // itne px ke andar dushman aaye to combat music
    holdSec:3,          // trigger band hone ke baad itni der combat music chalu rahe
    fade:1.5,           // crossfade ka time (sec)
    master:.5,          // music ka base volume
    pausedMul:.25       // pause menu mein
  },
  on:false,combat:false,combatT:0,
  step:0,nextT:0,timer:0,stats:{notes:0,steps:0},
  mg:null,calm:null,comb:null,

  /* ---------- lifecycle ---------- */
  start(){
    if(this.on)return;
    const a=ac();if(!a)return;
    clearTimeout(this._kill);
    this.on=true;this.combat=false;this.combatT=0;this.step=0;
    this.mg=a.createGain();this.mg.gain.value=0;this.mg.connect(a.destination);
    this.calm=a.createGain();this.calm.gain.value=1;this.calm.connect(this.mg);
    this.comb=a.createGain();this.comb.gain.value=0;this.comb.connect(this.mg);
    this.nextT=a.currentTime+.1;
    this.timer=setInterval(()=>this.schedule(),50);
  },
  stop(){
    if(!this.on)return;
    this.on=false;
    const a=AC,mg=this.mg;
    if(a&&mg)mg.gain.setTargetAtTime(0,a.currentTime,.15);
    clearInterval(this.timer);
    this._kill=setTimeout(()=>{try{mg.disconnect()}catch(e){}},1200);
  },

  /* ---------- har frame (REAL dt) ---------- */
  update(dt){
    const playing=!!player&&(state==='play'||state==='done'||state==='pause');
    const want=playing&&set.music!==false&&set.vol>0;
    if(want&&!this.on)this.start();
    else if(!want&&this.on)this.stop();
    if(!this.on)return;
    // combat trigger
    let c=false;
    if(state==='play'&&player.alive){
      if(player.flash>0)c=true;                                             // player fire kar raha hai
      else{
        const R=this.cfg.combatRadius;
        for(const p of players)if(p.alive&&!p.air&&!player.air&&p.team!==player.team&&(p.fl|0)===(player.fl|0)&&Math.hypot(p.x-player.x,p.y-player.y)<R){c=true;break}
      }
    }
    if(c)this.combatT=this.cfg.holdSec;else if(this.combatT>0)this.combatT-=dt;
    const want2=this.combatT>0;
    const a=AC;if(!a)return;
    if(want2!==this.combat){
      this.combat=want2;
      const k=this.cfg.fade/3,t=a.currentTime;
      this.calm.gain.setTargetAtTime(want2?0:1,t,k);
      this.comb.gain.setTargetAtTime(want2?1:0,t,k);
    }
    const mv=this.cfg.master*(set.musicVol==null?.5:set.musicVol)*set.vol*(state==='pause'?this.cfg.pausedMul:1);
    this.mg.gain.setTargetAtTime(mv,a.currentTime,.3);
  },

  /* ---------- sequencer ---------- */
  schedule(){
    const a=AC;if(!a||!this.on)return;
    const sd=60/this.cfg.bpm/4;                                            // 16th note
    while(this.nextT<a.currentTime+.25){
      this.playStep(this.step,this.nextT,sd);
      this.nextT+=sd;this.step++;this.stats.steps++;
    }
  },
  CH:[[57,60,64],[53,57,60],[55,60,64],[55,59,62]],                       // Am F C G (MIDI)
  BASS:[45,41,48,43],
  playStep(s,t,sd){
    const bar=Math.floor(s/16)%4,st=s%16,ch=this.CH[bar],root=this.BASS[bar];
    // --- calm ---
    if(st===0)for(const n of ch)this.osc('triangle',mtof(n),t,sd*16,.07,this.calm,.5,900);
    if(st%4===0)this.osc('sine',mtof(ch[(st/4)%3]+12),t,sd*3,.09,this.calm,.01,2400);
    // --- combat ---
    if(st%4===0)this.kick(t);
    if(st%2===1)this.hat(t,st%8===7?.12:.05);
    if(st%2===0)this.osc('sawtooth',mtof(root),t,sd*1.6,.16,this.comb,.01,420);
    if([0,3,6,10,12].includes(st))this.osc('square',mtof(ch[st%3]+24),t,sd*.9,.045,this.comb,.005,2800);
  },
  osc(type,f,t,dur,vol,bus,att,lp){
    const a=AC,o=a.createOscillator(),g=a.createGain(),fl=a.createBiquadFilter();
    o.type=type;o.frequency.setValueAtTime(f,t);fl.type='lowpass';fl.frequency.value=lp||2000;
    g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(vol,t+att);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
    o.connect(fl);fl.connect(g);g.connect(bus);o.start(t);o.stop(t+dur+.05);this.stats.notes++;
  },
  kick(t){
    const a=AC,o=a.createOscillator(),g=a.createGain();
    o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(45,t+.12);
    g.gain.setValueAtTime(.55,t);g.gain.exponentialRampToValueAtTime(.001,t+.16);
    o.connect(g);g.connect(this.comb);o.start(t);o.stop(t+.18);this.stats.notes++;
  },
  hat(t,vol){
    const a=AC,s=a.createBufferSource(),fl=a.createBiquadFilter(),g=a.createGain();
    s.buffer=nb();fl.type='highpass';fl.frequency.value=7000;
    g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+.04);
    s.connect(fl);fl.connect(g);g.connect(this.comb);s.start(t);s.stop(t+.05);this.stats.notes++;
  }
};
const mtof=m=>440*Math.pow(2,(m-69)/12);
