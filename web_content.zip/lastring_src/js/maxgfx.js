'use strict';
/* =====================================================================
   MaxGfx — "Max" graphics level (Settings > Quality > Max)
   ---------------------------------------------------------------------
   Sirf QL().max ON hone par chalta hai. Low/Medium/High/Ultra ko nahi chhoota.
     * ground par tiling detail texture (grass blades / sand ripples / snow sparkle / rock cracks / asphalt)
     * sooraj ki disha mein lambi soft shadows: ghar, ped, khiladi
     * sun light: warm soft-light glow, god-rays (light shafts), lens flare, floating dust / pollen
     * pani par chamak, goliyon ki glow, ped ke patton ki texture + highlight
     * punchy color grade (canvas CSS filter)
   Mausam (barish/snow/mist) ke hisaab se sooraj ki taakat ghatti hai; night map par moonlight tint.
   ===================================================================== */
const MaxGfx={
  tiles:{},
  SUN:{x:.82,y:.46},                                    // shadows isi disha mein girte hain (sooraj upar-left)
  grade:'contrast(1.06) saturate(1.1) brightness(1.02)',
  sunK(){const v={clear:1,sand:.65,ash:.3,mist:.4,rain:.25,snow:.75,blizzard:.2}[mp.wx];return v==null?1:v},
  rs(seed){let s=seed>>>0||1;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296}},

  /* ---------- tiling detail texture (512px tile = 256 world units) ---------- */
  tile(){
    const key=mp.det+'|'+mp.g[0];if(this.tiles[key])return this.tiles[key];
    const N=512,cv=document.createElement('canvas');cv.width=cv.height=N;const g=cv.getContext('2d'),r=this.rs(key.length*7919+mp.g[0].charCodeAt(1)*31);
    const R=(a,b)=>a+r()*(b-a);
    const wrap=(x,y,m,f)=>{for(const dx of[-N,0,N]){if(dx<0&&x>m||dx>0&&x<N-m)continue;for(const dy of[-N,0,N]){if(dy<0&&y>m||dy>0&&y<N-m)continue;f(x+dx,y+dy)}}};
    const blot=(col,n,a,r0,r1)=>{g.fillStyle=col;g.globalAlpha=a;for(let i=0;i<n;i++){const x=R(0,N),y=R(0,N),rx=R(r0,r1),ry=rx*R(.5,.9),an=R(0,3);wrap(x,y,rx,(X,Y)=>{g.beginPath();g.ellipse(X,Y,rx,ry,an,0,TAU);g.fill()})}g.globalAlpha=1};
    const det=mp.det;
    if(det==='grass'){
      blot('#cfe88a',26,.07,30,90);blot('#0e2a12',30,.08,24,80);
      g.lineCap='round';
      for(const [col,n,len] of [['rgba(214,244,150,.30)',1700,9],['rgba(18,52,22,.30)',1700,8],['rgba(120,170,70,.26)',900,12],['rgba(255,255,210,.2)',260,6]]){
        g.strokeStyle=col;g.lineWidth=1.3;g.beginPath();
        for(let i=0;i<n;i++){const x=R(0,N),y=R(0,N),l=R(len*.5,len),b=R(-3,3);wrap(x,y,14,(X,Y)=>{g.moveTo(X,Y);g.quadraticCurveTo(X+b*.5,Y-l*.5,X+b,Y-l)})}
        g.stroke()}
      g.fillStyle='rgba(255,236,120,.65)';g.beginPath();for(let i=0;i<10;i++){const x=R(0,N),y=R(0,N);g.moveTo(x+2,y);g.arc(x,y,1.8,0,TAU)}g.fill();
    }else if(det==='sand'){
      blot('#fff0c8',24,.07,40,110);blot('#5a3a18',22,.06,30,90);
      g.lineWidth=1.2;g.strokeStyle='rgba(255,244,210,.34)';g.beginPath();for(let i=0;i<90;i++){const x=R(0,N),y=R(0,N),rr=R(30,110),a=R(0,TAU);wrap(x,y,rr,(X,Y)=>{g.moveTo(X+Math.cos(a)*rr,Y+Math.sin(a)*rr);g.arc(X,Y,rr,a,a+R(.5,1.1))})}g.stroke();
      g.strokeStyle='rgba(90,60,28,.22)';g.beginPath();for(let i=0;i<70;i++){const x=R(0,N),y=R(0,N),rr=R(30,100),a=R(0,TAU);wrap(x,y,rr,(X,Y)=>{g.moveTo(X+Math.cos(a)*rr,Y+Math.sin(a)*rr+3);g.arc(X,Y+3,rr,a,a+R(.5,1.1))})}g.stroke();
      for(const [col,n] of [['rgba(255,250,225,.35)',2200],['rgba(70,45,20,.30)',2200]]){g.fillStyle=col;for(let i=0;i<n;i++)g.fillRect(R(0,N),R(0,N),1.2,1.2)}
    }else if(det==='snow'){
      blot('#ffffff',30,.10,30,100);blot('#8fb0cf',26,.08,26,90);
      for(const [col,n,s] of [['rgba(255,255,255,.55)',2400,1.4],['rgba(120,150,185,.30)',1800,1.2]]){g.fillStyle=col;for(let i=0;i<n;i++)g.fillRect(R(0,N),R(0,N),s,s)}
      g.fillStyle='rgba(255,255,255,.95)';for(let i=0;i<70;i++){const x=R(0,N),y=R(0,N);g.fillRect(x-1.5,y,4,1);g.fillRect(x,y-1.5,1,4)}
    }else{                                              // rock / lava / asph
      const asph=det==='asph',lava=det==='lava';
      blot(asph?'#9aa3b2':'#d2b49a',26,.06,30,90);blot('#05060a',28,.10,24,80);
      for(const [col,n] of [[asph?'rgba(190,198,215,.22)':'rgba(220,190,160,.22)',2200],['rgba(0,0,0,.30)',2400]]){g.fillStyle=col;for(let i=0;i<n;i++)g.fillRect(R(0,N),R(0,N),R(1,2.4),R(1,2.4))}
      g.strokeStyle='rgba(0,0,0,.42)';g.lineWidth=1.4;g.lineJoin='round';g.beginPath();
      for(let i=0;i<(asph?16:26);i++){let x=R(0,N),y=R(0,N);g.moveTo(x,y);for(let k=0;k<7;k++){x+=R(-22,22);y+=R(-22,22);g.lineTo(x,y)}}g.stroke();
      if(lava){g.strokeStyle='rgba(255,120,40,.55)';g.lineWidth=2.2;g.beginPath();for(let i=0;i<10;i++){let x=R(0,N),y=R(0,N);g.moveTo(x,y);for(let k=0;k<6;k++){x+=R(-26,26);y+=R(-26,26);g.lineTo(x,y)}}g.stroke()}
    }
    const pat=ctx.createPattern(cv,'repeat');
    try{pat.setTransform(new DOMMatrix().scale(.5))}catch(e){}
    return this.tiles[key]={pat};
  },

  /* ---------- world pass: ground detail + shadows (RQ draw se pehle) ---------- */
  ground(c,x0,y0,x1,y1){
    const T=this.tile(),sk=this.sunK(),night=!!mp.night,vis=(x,y,w,h)=>x<x1&&x+w>x0&&y<y1&&y+h>y0;
    // 1) detail texture: lakes + ghar ke farsh chhod kar
    c.save();c.beginPath();c.rect(x0,y0,x1-x0,y1-y0);
    for(const l of lakes)if(l.x+l.r>x0&&l.x-l.r<x1&&l.y+l.r>y0&&l.y-l.r<y1){c.moveTo(l.x+l.r+16,l.y);c.arc(l.x,l.y,l.r+16,0,TAU)}
    for(const hs of houses)if(vis(hs.x,hs.y,hs.w,hs.h))c.rect(hs.x,hs.y,hs.w,hs.h);
    c.clip('evenodd');c.globalAlpha=night?.55:.95;c.fillStyle=T.pat;c.fillRect(x0,y0,x1-x0,y1-y0);c.restore();
    // 2) pani par chamak
    c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
    for(const l of lakes){
      if(l.x+l.r<x0||l.x-l.r>x1||l.y+l.r<y0||l.y-l.r>y1)continue;
      for(let i=0;i<16;i++){
        const h=Math.sin(i*91.7+l.x*.013+l.y*.007)*43758.5453,fr=h-Math.floor(h),h2=Math.sin(i*37.1+l.x*.011)*12345.678,fr2=h2-Math.floor(h2);
        const a=fr*TAU,d=Math.sqrt(fr2)*l.r*.88,x=l.x+Math.cos(a)*d,y=l.y+Math.sin(a)*d*.9,tw=Math.sin(time*(1.2+fr)+i*2.3);
        if(tw<.1)continue;c.strokeStyle='rgba(255,255,255,'+(tw*.55*(night?.4:sk*.8+.2)).toFixed(2)+')';c.lineWidth=1.6;c.beginPath();c.moveTo(x-5,y);c.lineTo(x+5,y);c.stroke();
      }
    }
    c.restore();
    // 3) sooraj ki lambi soft shadows
    const sx=this.SUN.x,sy=this.SUN.y,A=night?.16:.12+.2*sk;
    c.save();c.fillStyle='rgba(8,12,22,'+A.toFixed(3)+')';c.strokeStyle='rgba(8,12,22,'+(A*.35).toFixed(3)+')';c.lineJoin='round';c.lineWidth=9;
    for(const hs of houses){
      if(!vis(hs.x-60,hs.y-60,hs.w+200,hs.h+200))continue;
      const L=Math.max(30,hs.H*(hs.nf||1)*.62),dx=sx*L,dy=sy*L,x=hs.x,y=hs.y,w=hs.w,h=hs.h;
      c.beginPath();c.moveTo(x,y);c.lineTo(x+w,y);c.lineTo(x+w+dx,y+dy);c.lineTo(x+w+dx,y+h+dy);c.lineTo(x+dx,y+h+dy);c.lineTo(x,y+h);c.closePath();c.fill();c.stroke();
    }
    for(const t of trees){
      if(t.x<x0-90||t.x>x1+90||t.y<y0-40||t.y>y1+120)continue;
      const cr=t.cr,tall=t.ty==='pine'?1.7:t.ty==='cactus'||t.ty==='dead'?1.3:t.ty==='acacia'?1.5:1.35;
      c.beginPath();c.ellipse(t.x+sx*cr*tall*.9,t.y+3+sy*cr*tall*.45,cr*(1.05+tall*.22),cr*.5,.3,0,TAU);c.fill();c.stroke();
    }
    for(const p of players){
      if(!p.alive||p.air||p.x<x0||p.x>x1||p.y<y0||p.y>y1)continue;
      c.beginPath();c.ellipse(p.x+sx*17,p.y+sy*9,19,5.5,.5,0,TAU);c.fill();
    }
    c.restore();
  },

  /* ---------- world pass: upar ki glow (goliyan) ---------- */
  top(c,x0,y0,x1,y1){
    c.save();c.globalCompositeOperation='lighter';
    for(const b of bullets){
      if(b.x<x0||b.x>x1||b.y<y0||b.y>y1)continue;
      c.fillStyle='rgba(255,190,80,.22)';c.beginPath();c.arc(b.x,b.y,8,0,TAU);c.fill();
      c.fillStyle='rgba(255,240,180,.55)';c.beginPath();c.arc(b.x,b.y,3,0,TAU);c.fill();
    }
    c.restore();
  },

  /* ---------- ped: patton ki texture + dhoop ka highlight ---------- */
  treeFx(c,t){
    const cr=t.cr,x=t.x,y=t.y;
    if(t.ty==='pine'){
      c.save();c.strokeStyle='rgba(190,240,170,.22)';c.lineWidth=1.4;c.beginPath();
      for(let i=0;i<3;i++){const w=cr*(1.05-i*.25),by=y-10-i*cr*.62;c.moveTo(x-w*.92,by-1);c.lineTo(x-cr*.04,by-cr*1.0)}c.stroke();
      c.fillStyle='rgba(0,0,0,.16)';c.beginPath();for(let i=0;i<3;i++){const w=cr*(1.05-i*.25),by=y-10-i*cr*.62;c.moveTo(x+w*.9,by);c.lineTo(x+cr*.05,by-cr*1.0);c.lineTo(x+w*.25,by)}c.fill();c.restore();return;
    }
    if(t.ty==='cactus'||t.ty==='dead'||t.ty==='palm')return;
    const acacia=t.ty==='acacia',top=y-(acacia?36:30),rx=acacia?cr*1.4:cr,ry=acacia?cr*.5:cr,r=this.rs(Math.floor(t.s*1e6)+1);
    c.save();c.beginPath();c.ellipse(x,top,rx,ry,0,0,TAU);c.clip();
    for(let i=0;i<26;i++){const a=r()*TAU,d=Math.sqrt(r())*.95,px=x+Math.cos(a)*rx*d,py=top+Math.sin(a)*ry*d,lit=(px-x)*-.6+(py-top)*-.8>0;
      c.fillStyle=lit?'rgba(190,240,120,.30)':'rgba(5,30,14,.30)';c.beginPath();c.ellipse(px,py,2.6+r()*2.2,1.8+r()*1.6,r()*3,0,TAU);c.fill()}
    const g=c.createRadialGradient(x-rx*.42,top-ry*.45,1,x-rx*.3,top-ry*.3,rx*.95);g.addColorStop(0,'rgba(255,240,170,.34)');g.addColorStop(1,'rgba(255,240,170,0)');c.fillStyle=g;c.fillRect(x-rx,top-ry,rx*2,ry*2);
    const d=c.createRadialGradient(x+rx*.3,top+ry*.4,2,x+rx*.2,top+ry*.3,rx*1.1);d.addColorStop(0,'rgba(0,10,30,.28)');d.addColorStop(1,'rgba(0,10,30,0)');c.fillStyle=d;c.fillRect(x-rx,top-ry,rx*2,ry*2);
    c.restore();
  },

  /* ---------- screen pass: sun light, god-rays, flare, dust ---------- */
  post(c){
    const W=VW,H=VH,sk=this.sunK(),night=!!mp.night,t=time,M=Math.max(W,H);
    c.save();
    if(!night){
      c.globalCompositeOperation='soft-light';
      let g=c.createRadialGradient(W*.06,-H*.06,0,W*.06,-H*.06,M*1.15);
      g.addColorStop(0,'rgba(255,214,140,'+(.55*sk+.08).toFixed(2)+')');g.addColorStop(.55,'rgba(255,196,120,'+(.2*sk).toFixed(2)+')');g.addColorStop(1,'rgba(255,190,110,0)');
      c.fillStyle=g;c.fillRect(0,0,W,H);
      g=c.createLinearGradient(0,H*.3,W*.8,H);g.addColorStop(0,'rgba(40,70,140,0)');g.addColorStop(1,'rgba(40,70,140,.2)');c.fillStyle=g;c.fillRect(0,0,W,H);   // door ke kone mein thandi chhaaya
      if(sk>.3){
        c.globalCompositeOperation='screen';
        for(let i=0;i<5;i++){
          const x0=W*(.02+i*.15)+Math.sin(t*.18+i*1.7)*W*.025,w=W*(.05+.02*Math.sin(i*2.3)),sh=W*.5,a=(.085*sk*(.7+.3*Math.sin(t*.5+i*1.3))).toFixed(3);
          const lg=c.createLinearGradient(x0,0,x0+sh,H);lg.addColorStop(0,'rgba(255,232,170,'+a+')');lg.addColorStop(1,'rgba(255,232,170,0)');
          c.fillStyle=lg;c.beginPath();c.moveTo(x0,-6);c.lineTo(x0+w,-6);c.lineTo(x0+w+sh,H+6);c.lineTo(x0+sh*1.0-w*.2,H+6);c.closePath();c.fill();
        }
        c.globalCompositeOperation='lighter';
        const sxp=W*.05,syp=H*.04;
        let f=c.createRadialGradient(sxp,syp,0,sxp,syp,H*.55);f.addColorStop(0,'rgba(255,244,205,'+(.34*sk).toFixed(2)+')');f.addColorStop(.25,'rgba(255,214,140,'+(.12*sk).toFixed(2)+')');f.addColorStop(1,'rgba(255,200,120,0)');c.fillStyle=f;c.fillRect(0,0,W,H);
        const cx=W/2,cy=H/2;
        for(const [k,rad,al,col] of [[.32,.05,.07,'255,220,160'],[.52,.085,.05,'160,220,255'],[.78,.04,.07,'255,170,120'],[1.05,.11,.045,'200,255,200']]){
          const px=sxp+(cx-sxp)*k,py=syp+(cy-syp)*k,rr=H*rad,fl=c.createRadialGradient(px,py,0,px,py,rr);fl.addColorStop(0,'rgba('+col+','+(al*sk*1.6).toFixed(3)+')');fl.addColorStop(1,'rgba('+col+',0)');c.fillStyle=fl;c.beginPath();c.arc(px,py,rr,0,TAU);c.fill();
        }
      }
    }else{
      c.globalCompositeOperation='soft-light';c.fillStyle='rgba(110,140,255,.14)';c.fillRect(0,0,W,H);
    }
    // dhool / pollen kan
    c.globalCompositeOperation='lighter';
    const n=night?0:34;
    for(let i=0;i<n;i++){
      const sx=(Math.sin(i*12.9898)*43758.5453)%1,sy=(Math.sin(i*78.233)*12345.678)%1,ax=Math.abs(sx),ay=Math.abs(sy);
      const x=((ax*W+t*(6+ax*10)+Math.sin(t*.6+i)*14)%W+W)%W,y=((ay*H+t*(2+ay*4)+Math.cos(t*.5+i*1.3)*10)%H+H)%H;
      const a=(.16+.2*Math.sin(t*1.3+i*2.1))*(.4+.6*sk);if(a<=0)continue;
      c.fillStyle='rgba(255,244,210,'+a.toFixed(2)+')';c.beginPath();c.arc(x,y,.9+ax*1.5,0,TAU);c.fill();
    }
    c.restore();
    // gehra kone (cinematic vignette)
    const vg=c.createRadialGradient(W/2,H/2,Math.min(W,H)*.42,W/2,H/2,M*.78);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.26)');c.fillStyle=vg;c.fillRect(0,0,W,H);
  }
};
