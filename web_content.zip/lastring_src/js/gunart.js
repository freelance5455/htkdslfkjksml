'use strict';
/* =====================================================================
   GunArt — real-gun look (metal / polymer / wood texture, magazine, scope, stock...)
   ---------------------------------------------------------------------
   Har gun ek offscreen canvas par ek baar draw hoti hai (cache), phir
   - hath mein:  GunArt.hand(c,id,px,py,ang,L,col)    (drawChar ka gun() isse bulata hai)
   - menu/loot:  GunArt.icon(c,id,cx,cy,s,col)        (drawGunIcon isse bulata hai)
   Sprite mein nali hamesha +x ki taraf, upar (scope) hamesha upar rehta hai.
   ===================================================================== */
const GunArt=(()=>{
  const cache={},Q=2;                       // Q = offscreen resolution multiplier
  const lg=(g,y0,y1,st)=>{const a=g.createLinearGradient(0,y0,0,y1);st.forEach((c,i)=>a.addColorStop(i/(st.length-1),c));return a};
  const rp=(g,x,y,w,h,r)=>{r=Math.min(r,w/2,h/2);g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()};
  const edge=(g,a)=>{g.strokeStyle='rgba(0,0,0,'+(a||.6)+')';g.lineWidth=.7;g.stroke()};
  /* ---- materials ---- */
  const K={
    metal(g,x,y,w,h,r=1.5){g.fillStyle=lg(g,y,y+h,['#9aa3ab','#5a626a','#262c32','#3a4148']);rp(g,x,y,w,h,r);g.fill();edge(g);g.fillStyle='rgba(255,255,255,.32)';g.fillRect(x+r,y+.7,Math.max(0,w-2*r),Math.max(.6,h*.1))},
    poly(g,x,y,w,h,r=2){g.fillStyle=lg(g,y,y+h,['#626b74','#323940','#1a1e23']);rp(g,x,y,w,h,r);g.fill();edge(g);g.fillStyle='rgba(255,255,255,.14)';g.fillRect(x+r,y+.7,Math.max(0,w-2*r),Math.max(.5,h*.08))},
    wood(g,x,y,w,h,r=2){g.fillStyle=lg(g,y,y+h,['#dba267','#a76e38','#6e4222']);rp(g,x,y,w,h,r);g.fill();
      g.save();rp(g,x,y,w,h,r);g.clip();g.strokeStyle='rgba(70,35,10,.32)';g.lineWidth=.6;
      for(let i=1;i<h/2.4;i++){const yy=y+i*2.4;g.beginPath();g.moveTo(x,yy);g.bezierCurveTo(x+w*.3,yy-1.4,x+w*.6,yy+1.6,x+w,yy-.4);g.stroke()}
      g.restore();rp(g,x,y,w,h,r);edge(g,.55)},
    poly2(g,pts,fill){g.fillStyle=fill;g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fill();edge(g)},
    acc(g,col,x,y,w,h){g.fillStyle=col;g.globalAlpha=.9;g.fillRect(x,y,w,h);g.globalAlpha=1}
  };
  const PG=['#4b535b','#262c32','#14181b'],WD=['#dba267','#a76e38','#6e4222'];
  const poly=(g,pts,st)=>K.poly2(g,pts,lg(g,Math.min(...pts.map(p=>p[1])),Math.max(...pts.map(p=>p[1])),st));
  const scope=(g,x,y,w,h,col)=>{                       // sniper scope: tube + bells + glass + rings
    K.metal(g,x,y+h*.18,w,h*.64,h*.3);
    K.metal(g,x-4,y,w*.22,h,h*.3);K.metal(g,x+w*.82,y+h*.06,w*.2+2,h*.88,h*.3);
    g.fillStyle=lg(g,y,y+h,['#bfe6ff',col||'#4aa3d6','#12384f']);g.beginPath();g.ellipse(x-4,y+h/2,1.6,h*.4,0,0,TAU);g.fill();
    K.metal(g,x+w*.3,y+h*.8,5,7,1);K.metal(g,x+w*.62,y+h*.8,5,7,1);
    g.fillStyle='rgba(255,255,255,.45)';g.fillRect(x+3,y+h*.26,w-6,1)};
  const dot=(g,x,y,col)=>{K.poly(g,x,y+6,22,5,1);K.metal(g,x+2,y,18,8,2);g.fillStyle='rgba(120,200,255,.55)';g.fillRect(x+16,y+1.5,2.6,5);g.fillStyle=col||'#ff4a4a';g.fillRect(x+9,y+3,1.6,1.6)};
  const rail=(g,x,y,w)=>{K.metal(g,x,y,w,3.2,.8);g.fillStyle='rgba(0,0,0,.55)';for(let i=x+2;i<x+w-1;i+=3)g.fillRect(i,y,1,3.2)};
  const sight=(g,x,y,h)=>{K.metal(g,x,y,3,h,.8);K.metal(g,x-3,y+h-3,9,3,.8)};
  const guard=(g,x,y,w,h)=>{g.strokeStyle='#15191d';g.lineWidth=2;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+w/2,y+h*1.5,x+w,y);g.stroke()};
  const vents=(g,x,y,w,h,n)=>{g.fillStyle='rgba(0,0,0,.6)';for(let i=0;i<n;i++)g.fillRect(x+(i+.5)*w/n-1,y+h*.3,2,h*.4)};
  const accent=(g,col,x,y,w,h)=>{g.save();g.shadowColor=col;g.shadowBlur=3;K.acc(g,col,x,y,w,h);g.restore()};

  /* ---- gun definitions: W,H = canvas, by = barrel y-centre ---- */
  const G={
    pistol:{W:150,H:100,by:34,d(g,c){
      K.poly2(g,[[26,44],[112,44],[112,52],[66,52],[56,98],[30,98]],lg(g,44,98,PG));
      K.metal(g,18,22,124,22,3);g.fillStyle='rgba(0,0,0,.5)';for(let i=0;i<5;i++)g.fillRect(24+i*3.5,24,1.4,18);
      K.metal(g,138,26,10,12,2);accent(g,c,60,30,56,3);sight(g,22,16,6);sight(g,128,16,6);guard(g,64,52,30,12)}},
    revolver:{W:170,H:104,by:36,d(g,c){
      K.wood(g,8,46,50,48,6);K.metal(g,40,34,62,16,3);K.metal(g,100,28,66,12,2);K.metal(g,96,38,60,5,1);
      K.metal(g,50,24,40,26,8);g.fillStyle='rgba(0,0,0,.55)';for(let i=0;i<5;i++)g.fillRect(56+i*6.5,26,1.6,22);
      K.metal(g,36,18,14,10,3);accent(g,c,104,31,52,2.4);sight(g,158,18,10);guard(g,62,50,26,12)}},
    smg:{W:200,H:100,by:34,d(g,c,id){
      const ext=id==='swift';
      for(let i=0;i<4;i++)K.metal(g,2+i*7,26+i*1.5,6,3,1);K.metal(g,0,24,4,24,1);
      K.poly(g,30,22,120,26,3);K.metal(g,150,26,46,14,2);vents(g,152,26,40,14,6);
      K.poly(g,86,48,16,ext?50:44,2);K.poly2(g,[[52,48],[70,48],[66,88],[50,88]],lg(g,48,88,PG));
      accent(g,c,36,28,100,3);sight(g,160,14,12);if(ext)dot(g,70,8);else rail(g,56,18,70);guard(g,70,48,18,10)}},
    ump:{W:200,H:100,by:34,d(g,c){
      K.poly(g,0,26,30,22,4);K.poly(g,4,22,26,6,2);
      K.poly(g,28,20,116,30,4);K.poly(g,140,24,36,24,3);vents(g,142,26,32,20,5);K.metal(g,174,28,24,12,2);
      K.poly(g,152,48,8,18,2);K.poly(g,90,50,16,50,2);K.poly2(g,[[52,50],[72,50],[68,88],[50,88]],lg(g,50,88,PG));
      rail(g,48,14,96);dot(g,88,0,'#3dff8a');accent(g,c,34,26,104,3);guard(g,72,50,18,10)}},
    ar:{W:240,H:100,by:36,d(g,c,id){
      const T=id==='titan',F=id==='falcon';
      K.poly2(g,[[0,28],[40,32],[40,54],[0,60]],lg(g,28,60,PG));K.poly(g,38,34,26,14,3);
      K.metal(g,58,26,76,20,2);K.poly(g,56,44,68,14,2);
      K.poly(g,134,28,54,20,3);vents(g,136,28,50,20,7);K.metal(g,188,33,34,8,2);K.metal(g,222,31,14,12,2);
      g.fillStyle='#0c0e10';for(let i=0;i<3;i++)g.fillRect(225+i*3.5,32,1.5,10);
      K.poly2(g,[[94,58],[114,58],[118,T?96:90],[98,T?96:90]],lg(g,58,92,PG));
      K.poly2(g,[[66,58],[82,58],[78,90],[64,90]],lg(g,58,90,PG));
      rail(g,64,19,68);if(F||T){scope(g,70,6,50,14,'#7be0ff')}else{dot(g,82,8)}
      sight(g,178,16,12);accent(g,c,62,29,72,3);guard(g,80,58,16,9)}},
    akm:{W:240,H:100,by:36,d(g,c){
      K.poly2(g,[[0,26],[46,32],[50,58],[0,64]],lg(g,26,64,WD));g.save();g.beginPath();g.moveTo(0,26);g.lineTo(46,32);g.lineTo(50,58);g.lineTo(0,64);g.closePath();g.clip();
      g.strokeStyle='rgba(70,35,10,.3)';g.lineWidth=.6;for(let i=0;i<14;i++){g.beginPath();g.moveTo(0,28+i*2.6);g.lineTo(50,34+i*2.4);g.stroke()}g.restore();
      K.metal(g,48,28,76,18,1.5);K.metal(g,52,26,64,4,1);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(70,32,30,6);
      K.wood(g,124,30,52,18,3);K.wood(g,124,25,46,7,2);K.metal(g,124,20,66,5,2.5);
      K.metal(g,176,34,42,7,2);K.poly2(g,[[216,31],[232,34],[232,42],[216,40]],lg(g,31,42,['#4a525a','#15191c']));
      K.wood(g,72,46,14,34,3);K.poly2(g,[[94,46],[116,46],[122,74],[116,94],[102,92],[100,74]],lg(g,46,94,['#3b434a','#1c2126','#101316']));
      g.strokeStyle='rgba(255,255,255,.18)';g.lineWidth=.7;for(let i=0;i<5;i++){g.beginPath();g.moveTo(103+i*.8,58+i*7);g.lineTo(115+i*1.5,58+i*7);g.stroke()}
      sight(g,200,12,20);sight(g,106,20,8);accent(g,c,56,38,62,2.4);guard(g,86,46,16,10)}},
    lmg:{W:240,H:116,by:38,d(g,c){
      K.poly2(g,[[0,30],[44,34],[44,60],[0,66]],lg(g,30,66,PG));
      K.metal(g,44,28,90,22,2);K.poly(g,44,48,80,12,2);K.poly(g,134,26,58,26,3);vents(g,136,28,54,22,8);
      K.metal(g,192,35,34,9,2);K.metal(g,224,32,14,14,2);
      K.poly(g,92,60,40,44,4);accent(g,c,96,76,32,3);g.fillStyle='rgba(0,0,0,.45)';for(let i=0;i<4;i++)g.fillRect(98,66+i*8,28,1);
      K.poly2(g,[[56,60],[72,60],[68,98],[54,98]],lg(g,60,98,PG));
      g.strokeStyle='#161a1d';g.lineWidth=3;g.beginPath();g.moveTo(172,50);g.lineTo(158,100);g.moveTo(172,50);g.lineTo(188,100);g.stroke();
      K.metal(g,62,17,70,6,3);sight(g,184,16,16);accent(g,c,50,30,84,3);guard(g,72,60,20,9)}},
    sg:{W:240,H:92,by:34,d(g,c,id){
      if(id==='auto12'){
        K.poly2(g,[[0,28],[56,32],[56,56],[0,62]],lg(g,28,62,PG));K.poly(g,54,26,64,24,3);K.poly(g,116,28,70,18,3);vents(g,118,30,66,14,8);K.metal(g,184,31,44,10,2);K.metal(g,226,29,10,14,2);
        K.metal(g,84,46,38,38,19);g.fillStyle='rgba(0,0,0,.5)';for(let i=0;i<8;i++){const a=i/8*TAU;g.fillRect(103+Math.cos(a)*11-1,65+Math.sin(a)*11-1,2,2)}
        K.poly2(g,[[60,50],[76,50],[72,82],[58,82]],lg(g,50,82,PG));accent(g,c,58,28,56,3);rail(g,60,19,52);sight(g,206,18,12)}
      else{
        K.wood(g,0,30,60,30,6);K.metal(g,58,26,56,22,2);K.metal(g,112,30,118,9,2.5);K.metal(g,112,42,92,6,2.5);
        K.wood(g,134,38,50,16,5);g.fillStyle='rgba(0,0,0,.4)';for(let i=0;i<6;i++)g.fillRect(140+i*7,40,1.5,12);
        K.metal(g,226,24,4,10,1);accent(g,c,64,30,44,2.6);guard(g,72,48,18,10);K.poly2(g,[[64,46],[78,46],[74,60],[62,60]],lg(g,46,60,PG))}}},
    sn:{W:260,H:96,by:38,d(g,c,id){
      if(id==='kar98'){
        K.poly2(g,[[0,34],[96,36],[134,42],[200,40],[200,50],[134,58],[92,60],[56,62],[22,76],[0,70]],lg(g,34,76,WD));
        g.save();g.beginPath();g.moveTo(0,34);g.lineTo(96,36);g.lineTo(134,42);g.lineTo(200,40);g.lineTo(200,50);g.lineTo(134,58);g.lineTo(92,60);g.lineTo(56,62);g.lineTo(22,76);g.lineTo(0,70);g.closePath();g.clip();
        g.strokeStyle='rgba(70,35,10,.3)';g.lineWidth=.6;for(let i=0;i<22;i++){g.beginPath();g.moveTo(0,36+i*1.7);g.bezierCurveTo(70,34+i*1.6,140,44+i*.5,200,41+i*.4);g.stroke()}g.restore();
        K.metal(g,96,28,44,13,2);K.metal(g,134,35,112,6,2.5);K.metal(g,176,33,6,10,1);K.metal(g,206,33,6,10,1);
        g.strokeStyle='#8f969c';g.lineWidth=2.4;g.beginPath();g.moveTo(112,36);g.lineTo(122,50);g.stroke();K.metal(g,118,48,7,7,3.5);
        sight(g,150,24,10);K.metal(g,238,26,10,12,2);K.metal(g,246,30,4,4,1);accent(g,c,100,31,36,2.2);guard(g,100,60,24,10)}
      else{
        const A=id==='awm',H=id==='hawk',D=id==='dmr';
        const olive=A?['#7c9560','#52663d','#2f3e24']:H?['#6a5a7a','#3c3148','#221a2c']:['#5a626a','#31373d','#1b1f23'];
        K.poly2(g,[[0,38],[70,40],[92,40],[96,52],[96,66],[74,64],[44,78],[8,86],[0,72]],lg(g,38,86,olive));
        if(A){g.fillStyle='rgba(0,0,0,.45)';for(let i=0;i<3;i++){g.beginPath();g.ellipse(34+i*14,60+i*0.5,4,3,0,0,TAU);g.fill()}K.poly(g,10,30,34,10,4)}
        K.metal(g,92,32,62,18,2);K.metal(g,150,36,A?88:H?80:62,9,2.5);K.metal(g,150,34,24,13,2);
        const mx=A?238:H?230:212;K.metal(g,mx,A?32:34,A?22:16,A?14:12,2);g.fillStyle='#0c0e10';for(let i=0;i<3;i++)g.fillRect(mx+4+i*5,A?33:35,2,A?12:10);
        K.poly(g,112,50,22,D?30:18,2);
        if(!D){g.strokeStyle='#a4abb2';g.lineWidth=2.6;g.beginPath();g.moveTo(118,34);g.lineTo(130,24);g.stroke();K.metal(g,128,19,7,7,3.5)}
        g.strokeStyle='#161a1d';g.lineWidth=3;g.beginPath();g.moveTo(176,48);g.lineTo(168,86);g.moveTo(176,48);g.lineTo(190,86);g.stroke();
        scope(g,98,A?4:8,A?78:H?64:50,A?22:18,A?'#8fe3ff':'#6fb7ff');rail(g,96,29,60);accent(g,c,96,40,50,2.4);guard(g,86,64,24,10)}}},

    hornet:{W:190,H:104,by:34,d(g,c){
      g.strokeStyle='#9aa3ab';g.lineWidth=2;g.beginPath();g.moveTo(26,27);g.lineTo(3,31);g.lineTo(3,43);g.lineTo(26,44);g.stroke();
      K.metal(g,24,20,112,26,3);g.fillStyle='rgba(0,0,0,.45)';for(let i=0;i<9;i++)g.fillRect(34+i*10,21,2,5);
      K.metal(g,136,27,46,12,2);K.metal(g,176,24,6,18,1.5);K.poly2(g,[[82,46],[104,46],[102,96],[80,96]],lg(g,46,96,PG));
      g.fillStyle='rgba(0,0,0,.4)';for(let i=0;i<5;i++)g.fillRect(84,56+i*7,16,1);
      accent(g,c,28,30,100,3);sight(g,34,12,8);guard(g,60,46,20,10)}},
    swift:{W:200,H:104,by:36,d(g,c){
      K.poly2(g,[[0,28],[20,26],[22,46],[0,50]],lg(g,26,50,PG));K.poly(g,18,22,128,28,5);
      K.metal(g,146,28,50,15,3);g.fillStyle='rgba(0,0,0,.55)';for(let i=0;i<5;i++)g.fillRect(150+i*9,28,1.6,15);
      K.poly2(g,[[104,50],[126,50],[140,98],[114,98]],lg(g,50,98,PG));accent(g,c,112,80,20,3);
      K.poly2(g,[[58,50],[76,50],[72,90],[56,90]],lg(g,50,90,PG));K.poly2(g,[[150,43],[162,43],[160,70],[148,70]],lg(g,43,70,PG));
      dot(g,64,8,'#ff9a3a');accent(g,c,24,28,118,3);guard(g,76,50,22,9)}},
    falcon:{W:230,H:100,by:40,d(g,c){
      K.poly2(g,[[0,34],[14,32],[150,34],[150,60],[40,64],[16,66],[0,58]],lg(g,32,66,PG));
      g.fillStyle='rgba(255,255,255,.12)';g.fillRect(40,36,100,2);vents(g,100,38,44,20,6);
      K.metal(g,150,38,26,14,2);K.poly(g,150,34,44,20,3);K.metal(g,192,40,26,8,2);K.metal(g,216,37,12,14,2);
      K.poly2(g,[[94,62],[110,62],[112,96],[92,96]],lg(g,62,96,PG));K.poly2(g,[[120,58],[136,58],[134,88],[120,88]],lg(g,58,88,PG));
      K.metal(g,46,24,8,12,1);K.metal(g,100,24,8,12,1);scope(g,44,12,70,14,'#ffb14a');rail(g,150,28,40);sight(g,196,26,12);
      accent(g,c,20,44,110,3);guard(g,122,60,14,8)}},
    titan:{W:250,H:112,by:40,d(g,c){
      K.poly2(g,[[0,30],[48,34],[52,64],[0,70]],lg(g,30,70,PG));
      K.metal(g,48,28,86,26,3);K.poly(g,48,52,76,12,2);K.metal(g,132,30,58,24,3);g.fillStyle='rgba(0,0,0,.6)';for(let i=0;i<7;i++){g.beginPath();g.arc(140+i*7,42,2.2,0,TAU);g.fill()}
      K.metal(g,190,36,36,10,2);K.metal(g,224,32,22,18,2);g.fillStyle='#0c0e10';for(let i=0;i<3;i++)g.fillRect(228+i*5,34,2,14);
      K.metal(g,136,56,52,12,3);K.metal(g,184,54,8,18,2);
      K.metal(g,82,58,40,40,20);g.fillStyle='rgba(0,0,0,.5)';for(let i=0;i<10;i++){const a=i/10*TAU;g.fillRect(102+Math.cos(a)*14-1,78+Math.sin(a)*14-1,2,2)}
      accent(g,c,94,72,16,12);K.poly2(g,[[58,64],[76,64],[72,94],[56,94]],lg(g,64,94,PG));
      scope(g,64,10,66,17,'#e28cff');rail(g,60,24,76);sight(g,206,20,14);accent(g,c,52,34,80,3);guard(g,72,64,14,8)}},
    hawk:{W:270,H:100,by:40,d(g,c){
      g.save();K.poly2(g,[[0,40],[84,42],[96,50],[96,68],[66,68],[58,88],[38,88],[32,62],[0,66]],lg(g,40,88,['#7a6a92','#43385a','#1f1830']));
      g.globalCompositeOperation='destination-out';g.beginPath();g.ellipse(50,58,9,6,-.3,0,TAU);g.fill();g.restore();
      g.fillStyle='rgba(255,255,255,.18)';g.fillRect(6,42,70,2);K.poly(g,0,34,30,9,3);
      K.metal(g,94,34,46,18,2);K.metal(g,140,39,100,8,2.5);g.fillStyle='rgba(0,0,0,.35)';for(let i=0;i<9;i++)g.fillRect(148+i*10,39,1.6,8);
      K.metal(g,238,33,30,20,2);g.fillStyle='#0c0e10';for(let i=0;i<4;i++)g.fillRect(244+i*6,35,2.4,16);
      g.strokeStyle='#a4abb2';g.lineWidth=2.6;g.beginPath();g.moveTo(112,36);g.lineTo(128,24);g.stroke();K.metal(g,126,18,8,8,4);
      K.metal(g,108,52,18,12,2);scope(g,98,4,86,24,'#c08bff');rail(g,96,30,66);accent(g,c,96,43,40,2.4);guard(g,70,68,22,9)}},
    dmr:{W:250,H:104,by:38,d(g,c){
      g.save();K.poly2(g,[[0,34],[58,38],[72,46],[128,48],[128,58],[72,60],[56,76],[28,82],[10,68],[0,66]],lg(g,34,82,WD));
      g.globalCompositeOperation='destination-out';g.beginPath();g.ellipse(34,58,10,7,-.2,0,TAU);g.fill();g.restore();
      K.metal(g,70,32,58,17,2);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(84,35,34,5);
      K.wood(g,126,40,50,12,3);K.wood(g,126,35,40,6,2);K.metal(g,176,38,48,7,2);K.metal(g,222,33,24,16,2);g.fillStyle='#0c0e10';for(let i=0;i<3;i++)g.fillRect(228+i*5,35,2,12);
      K.poly2(g,[[96,48],[114,48],[120,66],[118,86],[100,84],[98,66]],lg(g,48,86,['#3b434a','#1c2126','#101316']));
      scope(g,84,10,42,13,'#6fb7ff');rail(g,80,28,50);sight(g,200,20,18);accent(g,c,74,40,50,2.4);guard(g,56,76,24,8)}},
    xb:{W:170,H:110,by:46,d(g,c){
      K.wood(g,0,40,120,16,5);K.metal(g,100,38,64,8,2);K.metal(g,110,34,40,4,1);
      g.strokeStyle='#2b2118';g.lineWidth=4;g.beginPath();g.moveTo(138,6);g.quadraticCurveTo(160,46,138,88);g.stroke();
      g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1;g.beginPath();g.moveTo(138,6);g.lineTo(108,46);g.lineTo(138,88);g.stroke();
      accent(g,c,40,44,50,2.6);K.metal(g,60,34,16,6,2)}}
  };

  function get(id,col,gfx){
    const w=WP[id];if(!w)return null;
    const key=id+'|'+(col||'')+'|'+(gfx||''),hit=cache[key];if(hit)return hit;
    const def=G[id]||G[w.cls]||G.ar,cv=document.createElement('canvas');cv.width=def.W*Q;cv.height=def.H*Q;
    const g=cv.getContext('2d');g.scale(Q,Q);g.lineJoin='round';g.lineCap='round';
    const base=col||w.col;
    try{def.d(g,base,id)}catch(e){}
    if(col&&col!==w.col){g.save();g.globalCompositeOperation='source-atop';g.globalAlpha=.34;g.fillStyle=col;g.fillRect(0,0,def.W,def.H);g.restore()}   // weapon skin: poori gun par rang
    if(gfx==='neon'){g.save();g.globalCompositeOperation='source-atop';g.shadowColor=base;g.shadowBlur=8;g.fillStyle='rgba(255,255,255,.06)';g.fillRect(0,0,def.W,def.H);g.restore()}
    if(gfx==='gold'){g.save();g.globalCompositeOperation='source-atop';g.fillStyle='rgba(255,205,90,.42)';g.fillRect(0,0,def.W,def.H);g.restore()}
    return cache[key]={cv,W:def.W,H:def.H,by:def.by};
  }

  return{
    get,
    // hath mein: (px,py) = kandha, nali ang ki taraf, kul lambai L(px)
    hand(c,id,px,py,ang,L,col,gfx){
      const s=get(id,col,gfx);if(!s)return false;
      const k=(L+6)/s.W,flip=Math.cos(ang)<0;
      c.save();c.translate(px,py);c.rotate(ang);if(flip)c.scale(1,-1);
      c.scale(k,k*1.22);c.drawImage(s.cv,-6/k,-s.by,s.W,s.H);
      c.restore();return true;
    },
    // menu / loot icon: (cx,cy) centre, s = purane drawGunIcon jaisa scale
    icon(c,id,cx,cy,s,col,gfx){
      const w=WP[id],sp=get(id,col,gfx);if(!w||!sp)return false;
      const tw=({pistol:58,smg:108,ar:132,lmg:134,sg:120,sn:150,xb:100})[w.cls]*s,k=tw/sp.W;
      c.save();c.translate(cx,cy);c.scale(k,k);c.drawImage(sp.cv,-sp.W/2,-sp.by-(sp.H-sp.by*2)/2+0,sp.W,sp.H);c.restore();return true;
    }
  };
})();
