'use strict';
/* =====================================================================
   hydro_fx.js — particles (mist / splash / steam, hard cap) + ambient audio (river / fall loops, pond & bridge one-shots)
   Awaaz ka design: nadi = bandpass shor (variant-wise), jharna = chaudi hiss + gehri gunj, talab = chhote events (boondh, medhak, chidiya...)
   pul = kadam ki awaaz (lakdi tock / dhaatu clang / patthar thud / rassi creak).  Door = dheemi (distance falloff).
   ===================================================================== */
Object.assign(Hydro,{
  aud:null,_at:2,_bt:0,_pondT:0,
  mute(){if(this.aud){const t=this.aud.a.currentTime;for(const k of['rg','rg2','fg','fg2','wg'])this.aud[k].gain.setTargetAtTime(0,t,.1)}},
  cap(){const q=QL();return q.fx>=3?260:q.fx>=2?180:q.fx>=1?120:q.shadow?70:36},
  splash(x,y,k){
    const cap=this.cap();if(this.P.length>cap)return;
    const n=Math.round(7*k);
    for(let i=0;i<n;i++){const a=Math.random()*TAU,s=30+Math.random()*90*k;this.P.push({k:1,x,y,z:2,vx:Math.cos(a)*s*.5,vy:Math.sin(a)*s*.3,vz:60+Math.random()*90*k,l:.55,m:.55,r:1.4+Math.random()*1.4})}
    for(let i=0;i<Math.max(1,Math.round(2*k));i++)this.P.push({k:3,x:x+(Math.random()-.5)*10,y,z:0,vx:(Math.random()-.5)*14,vy:-4,vz:12,l:.7,m:.7,r:6+Math.random()*6});
    this.P.push({k:4,x,y,z:0,vx:0,vy:0,vz:0,l:.6,m:.6,r:4});                            // ring
  },
  fxUpdate(dt){
    const P=this.P,cap=this.cap(),q=QL();
    for(let i=P.length-1;i>=0;i--){const p=P[i];p.l-=dt;if(p.l<=0){P[i]=P[P.length-1];P.pop();continue}
      p.x+=p.vx*dt+(p.k===0?this.wind*6*dt:0);p.y+=p.vy*dt;
      if(p.k===1){p.vz-=240*dt;p.z+=p.vz*dt;if(p.z<0){p.z=0;p.l=Math.min(p.l,.08)}}
      else if(p.k===0||p.k===2){p.z+=p.vz*dt;p.r+=dt*(p.k===2?9:14)}
      else if(p.k===3){p.z+=p.vz*dt;p.r+=dt*8}
      else if(p.k===4)p.r+=dt*46;
    }
    /* jharne ke paas mist + chhinte (sirf camera ke aas-paas) */
    if(P.length<cap)for(const f of this.falls){
      const dx=f.x-cam.x,dy=f.y-cam.y;if(dx*dx+dy*dy>1100*1100)continue;
      const A=this.seasonA(f);if(A<.14)continue;
      const rate=(f.v.mist||.8)*A*(q.fx>=1?30:15)*dt;
      for(let n=rate;n>0;n--){if(n<1&&Math.random()>n)break;if(P.length>=cap)break;
        const x=f.x+(Math.random()-.5)*f.w*.7,y=f.y+Math.random()*10-4;
        P.push({k:Math.random()<.2?1:0,x,y,z:0,vx:(Math.random()-.5)*18,vy:-6-Math.random()*8,vz:(f.v.steam?24:12)+Math.random()*14,l:1.7+Math.random()*1,m:2.5,r:8+Math.random()*10,c:f.v.steam?1:0});
        if(P[P.length-1].k===1){const p=P[P.length-1];p.vz=70+Math.random()*60;p.l=.6;p.m=.6;p.r=1.5}
      }
    }
    this.audio(dt);
  },
  drawParts(c,fx){
    const P=this.P;if(!P.length)return;
    for(const p of P){
      if(p.x<this._x0-30||p.x>this._x1+30||p.y<this._y0-60||p.y>this._y1+30)continue;
      const u=p.l/p.m;
      if(p.k===0||p.k===2){c.globalAlpha=Math.min(.34,u*.42)*(p.k===2?.8:1);c.fillStyle=p.c?'rgba(255,214,170,1)':'#eef6fa';c.beginPath();c.arc(p.x,p.y-p.z,p.r,0,TAU);c.fill()}
      else if(p.k===1){c.globalAlpha=Math.min(1,u*1.6);c.fillStyle='#f4fbff';c.fillRect(p.x-p.r*.5,p.y-p.z-p.r*.5,p.r,p.r)}
      else if(p.k===3){c.globalAlpha=Math.min(.3,u*.4);c.fillStyle='#fff';c.beginPath();c.arc(p.x,p.y-p.z,p.r,0,TAU);c.fill()}
      else if(p.k===4){c.globalAlpha=Math.max(0,u*.5);c.strokeStyle='#fff';c.lineWidth=1.5;c.beginPath();c.ellipse(p.x,p.y,p.r,p.r*.6,0,0,TAU);c.stroke()}
    }
    c.globalAlpha=1;
  },
  /* ---------- audio ---------- */
  audInit(){
    const a=ac();if(!a||this.aud)return;
    const len=a.sampleRate*3,buf=a.createBuffer(1,len,a.sampleRate),d=buf.getChannelData(0);
    let b0=0,b1=0,b2=0;for(let i=0;i<len;i++){const w=Math.random()*2-1;b0=.99765*b0+w*.099;b1=.963*b1+w*.2965;b2=.57*b2+w*1.05;d[i]=(b0+b1+b2+w*.18)*.22}   // pink-ish
    const src=()=>{const s=a.createBufferSource();s.buffer=buf;s.loop=true;s.loopStart=Math.random()*1.5;s.start(0,Math.random()*2);return s};
    const mk=(type,f,q)=>{const x=a.createBiquadFilter();x.type=type;x.frequency.value=f;x.Q.value=q||.7;return x};
    const G=()=>{const g=a.createGain();g.gain.value=0;g.connect(a.destination);return g};
    const A={ok:true,a};
    A.rg=G();A.rf=mk('bandpass',600,.6);src().connect(A.rf);A.rf.connect(A.rg);                      // river body
    A.rg2=G();A.rf2=mk('highpass',2600,.7);src().connect(A.rf2);A.rf2.connect(A.rg2);                  // river babble
    A.rl=a.createOscillator();A.rl.frequency.value=.15;A.rlg=a.createGain();A.rlg.gain.value=120;A.rl.connect(A.rlg);A.rlg.connect(A.rf.frequency);A.rl.start();   // slow filter motion
    A.fg=G();A.ff=mk('lowpass',2200,.5);A.fh=mk('highpass',160,.5);src().connect(A.ff);A.ff.connect(A.fh);A.fh.connect(A.fg);   // waterfall hiss
    A.fg2=G();A.ff2=mk('lowpass',140,.5);src().connect(A.ff2);A.ff2.connect(A.fg2);                    // waterfall rumble
    A.wg=G();A.wf=mk('bandpass',520,.45);src().connect(A.wf);A.wf.connect(A.wg);                       // breeze
    A.wl=a.createOscillator();A.wl.frequency.value=.11;A.wlg=a.createGain();A.wlg.gain.value=220;A.wl.connect(A.wlg);A.wlg.connect(A.wf.frequency);A.wl.start();
    this.aud=A;
  },
  _near(list,fn){let bd=1e9,bo=null;for(const o of list){const d=fn(o);if(d<bd){bd=d;bo=o}}return[bd,bo]},
  audio(dt){
    const on=state==='play'&&set.vol>0&&this.idx>=0&&!(typeof MatchNet!=='undefined'&&0);
    if(!this.aud){if(on&&AC&&AC.state==='running')this.audInit();if(!this.aud)return}
    const A=this.aud,t=A.a.currentTime,V=set.vol;
    const sm=(g,v)=>g.gain.setTargetAtTime(on?v*V:0,t,.25);
    if(!on||!player){sm(A.rg,0);sm(A.rg2,0);sm(A.fg,0);sm(A.fg2,0);sm(A.wg,0);return}
    this._bt-=dt;
    const px=player.x,py=player.y,fo=(d,r)=>Math.pow(clamp(1-d/r,0,1),1.6);
    /* river: nearest channel sample */
    let bd=1e9,rv=null;for(const R of this.rivers)for(const ch of R.chans){const pts=ch.pts;for(let i=0;i<pts.length;i+=2){const d=Math.hypot(pts[i].x-px,pts[i].y-py)-ch.w*.4;if(d<bd){bd=d;rv=R}}}
    if(rv){const s=rv.v.snd;A.rf.frequency.setTargetAtTime(s[0],t,.4);A.rf.Q.value=s[1];A.rl.frequency.value=s[3];sm(A.rg,s[2]*.55*fo(bd,420));sm(A.rg2,s[2]*.16*fo(bd,360)*(rv.v.foam?2:1))}else{sm(A.rg,0);sm(A.rg2,0)}
    /* waterfall */
    let fd=1e9,fl=null;for(const f of this.falls){const d=Math.hypot(f.x-px,f.y-py)-f.w*.3;if(d<fd){fd=d;fl=f}}
    if(fl){const A2=this.seasonA(fl),s=fl.v.snd;A.ff.frequency.setTargetAtTime(s[0]*(fl.v.cave?.6:1),t,.4);sm(A.fg,s[1]*.65*A2*fo(fd,900)*(fl.v.ice?.3:1));sm(A.fg2,s[1]*.5*A2*fo(fd,520))}else{sm(A.fg,0);sm(A.fg2,0)}
    /* breeze near water */
    sm(A.wg,.05*fo(Math.min(bd,fd),700)*(1+Math.abs(this.wind)));
    /* pond ambient events */
    this._at-=dt;
    if(this._at<=0){
      this._at=1.4+Math.random()*3;
      const [pd,pp]=this._near(this.ponds,p=>Math.hypot(p.x-px,p.y-py)-p.r);
      if(pp&&pd<620){const a=Math.random()*TAU,k=pp.v.snd;if(!(k==='bird'&&mp.night))Spat.play('hy_'+(mp.night&&k==='bird'?'frog':k),pp.x+Math.cos(a)*pp.r*.6,pp.y+Math.sin(a)*pp.r*.6)}
    }
    /* bridge footsteps / creaks */
    const bd2=this.deck(px,py);
    if(bd2&&(player.mv||0)>.25){this._pondT-=dt;if(this._pondT<=0){this._pondT=.32;Spat.play('hy_'+bd2.v.snd,px,py);if(bd2.v.snd==='creak'||(bd2.v.sway&&Math.random()<.3))Spat.play('hy_creak',px,py)}}
    if(bd2&&bd2!==this._onB){this._onB=bd2;if(bd2.v.snd==='clang')Spat.play('hy_clang',px,py);if(bd2.v.snd==='creak')Spat.play('hy_creak',px,py)}
    if(!bd2)this._onB=null;
  }
});
