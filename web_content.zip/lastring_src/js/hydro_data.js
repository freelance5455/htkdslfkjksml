'use strict';
/* =====================================================================
   hydro_data.js — "Water Worlds": 4 categories x 20 variants (80 total)
   Har map par ek poora paani-tantra hota hai:  jharna -> nadi -> pul -> talab
   HY_MAP[i] = MAPS[i] par kaun-kaun se variant aate hain (80 variants, har ek kam se kam 1 baar).
   Naming (game-ready):  river_*, bridge_*, fall_*, pond_*
   ===================================================================== */

/* ---------- rivers & streams ---------- */
/* w width | fl flow px/s | wd = in-water slow (lower = slower) | d deep, s shallow, f foam, b wet bank | snd = [filterHz, Q, gain, lfoHz] */
const HY_RIVER=[
 {id:'meandering',   n:T('Meandering River'),   w:96, fl:70, wd:.62,d:'#2f6f8f',s:'#6fb0c4',f:'#e9f6fa',b:'#6a5a3c',amp:1.3,snd:[520,.6,.5,.15]},
 {id:'dry_riverbed', n:T('Dry Riverbed Trickle'),w:84, fl:25, wd:.9, d:'#6c8f94',s:'#b7a47a',f:'#efe6c8',b:'#8a6c46',amp:.8,dry:1,cracks:1,snd:[900,.8,.12,.1]},
 {id:'mountain_rapids',n:T('Mountain Rapids'), w:104,fl:170,wd:.5, d:'#3a7c97',s:'#9ed0de',f:'#ffffff',b:'#5d5a54',amp:.6,rocks:34,foam:1,snd:[1100,.5,.8,.4]},
 {id:'marsh_channel',n:T('Marsh Channel'),     w:84, fl:18, wd:.55,d:'#3f6a4d',s:'#6f8f5a',f:'#b9c98a',b:'#3a3a26',amp:1.5,reeds:1,algae:1,snd:[380,.7,.3,.08]},
 {id:'jungle_river', n:T('Jungle River'),       w:122,fl:55, wd:.6, d:'#3a6a50',s:'#6c8a5a',f:'#d6e3c4',b:'#4a3a24',amp:1.1,canopy:1,leaves:1,snd:[480,.6,.55,.12]},
 {id:'braided',      n:T('Braided River'),      w:40, fl:60, wd:.7, d:'#4a8aa2',s:'#8cc0cc',f:'#f4fafc',b:'#8a8472',amp:.5,braid:3,gravel:1,snd:[700,.6,.4,.2]},
 {id:'snowmelt',     n:T('Snowmelt Stream'),    w:70, fl:95, wd:.6, d:'#4a9cc0',s:'#bfe6f2',f:'#ffffff',b:'#cfd8de',amp:.9,ice:1,snow:1,snd:[800,.6,.45,.2]},
 {id:'forest_stream',n:T('Forest Stream'),      w:58, fl:55, wd:.7, d:'#3d7f86',s:'#7fb9b4',f:'#e8f5ee',b:'#5a4a30',amp:1.2,leaves:1,snd:[640,.7,.35,.12]},
 {id:'delta',        n:T('River Delta'),        w:100,fl:35, wd:.58,d:'#5a8a78',s:'#a8b890',f:'#e8ecd0',b:'#7a6a44',amp:.9,delta:1,silt:1,snd:[420,.6,.4,.1]},
 {id:'oxbow',        n:T('Oxbow River'),        w:92, fl:30, wd:.6, d:'#3e7a8a',s:'#78aab0',f:'#eaf3f2',b:'#6a5a3a',amp:2.2,oxbow:1,snd:[420,.6,.35,.08]},
 {id:'wide_slow',    n:T('Wide Slow River'),    w:176,fl:24, wd:.58,d:'#2e6683',s:'#5f9ab2',f:'#eaf4f8',b:'#6a5e44',amp:.7,sheen:1,snd:[340,.6,.35,.06]},
 {id:'underground',  n:T('Underground River'),  w:92, fl:45, wd:.58,d:'#1a3a52',s:'#2f5a74',f:'#8ac0d8',b:'#2a2a30',amp:.9,tunnel:1,glow:'#5ad0ff',snd:[300,.8,.5,.1]},
 {id:'lava_heated',  n:T('Lava-Heated Stream'), w:72, fl:50, wd:.6, d:'#27414c',s:'#4f6a6a',f:'#ffd9a0',b:'#2a2226',amp:1,lava:1,steam:1,glow:'#ff7a2a',snd:[520,.9,.4,.3]},
 {id:'canyon',       n:T('Canyon River'),       w:112,fl:105,wd:.52,d:'#2f7a86',s:'#8cb0a0',f:'#f2f6f0',b:'#8a4a2c',amp:.8,walls:1,snd:[620,.5,.65,.18]},
 {id:'rapid_chute',  n:T('Rapid Chute'),        w:54, fl:230,wd:.42,d:'#3a86a6',s:'#cfeaf4',f:'#ffffff',b:'#55524e',amp:.3,rocks:20,foam:2,snd:[1500,.4,.95,.6]},
 {id:'shallow_creek',n:T('Shallow Creek'),       w:50, fl:42, wd:.85,d:'#5fa6b0',s:'#a8d4d0',f:'#f2faf8',b:'#7a6a48',amp:1.4,pebbles:1,snd:[900,.7,.25,.1]},
 {id:'glacial',      n:T('Glacial Stream'),     w:74, fl:60, wd:.55,d:'#4fb4c8',s:'#a8e0e8',f:'#ffffff',b:'#c4d4dc',amp:.8,ice:1,milky:1,snd:[560,.6,.4,.1]},
 {id:'spring_brook', n:T('Spring Brook'),        w:40, fl:48, wd:.8, d:'#4aa0a8',s:'#90d0c8',f:'#f4fffc',b:'#5a6a3a',amp:1.5,cress:1,pebbles:1,snd:[1000,.8,.3,.12]},
 {id:'rocky_gorge',  n:T('Rocky Gorge Stream'), w:66, fl:125,wd:.5, d:'#2a5f74',s:'#7aaabc',f:'#ffffff',b:'#46433f',amp:.5,rocks:28,walls:1,foam:1,snd:[800,.5,.7,.3]},
 {id:'tidal',        n:T('Tidal River'),        w:136,fl:55, wd:.58,d:'#3a7a8c',s:'#8ab4a8',f:'#eef6f2',b:'#6a5c3c',amp:1,tide:1,mud:1,snd:[420,.6,.45,.07]}
];

/* ---------- waterfalls ---------- */
/* w width | h cliff face height | lay = stream layout | col water | rock palette [top,face,dark] | mist/spl amount | snd [Hz,gain] */
const HY_FALL=[
 {id:'seasonal',  n:T('Seasonal Ephemeral Waterfall'),w:130,h:78,lay:'one',  col:'#bcd9e0',rock:['#a08060','#7a5e44','#4a3828'],mist:.7,seas:1,snd:[1700,.5]},
 {id:'rain_fed',  n:T('Rain-Fed Waterfall'),          w:120,h:74,lay:'thin', col:'#c4b894',rock:['#a68a64','#806444','#4e3a26'],mist:.6,rainp:1,snd:[1500,.5]},
 {id:'frozen',    n:T('Frozen Waterfall'),            w:132,h:80,lay:'ice',  col:'#d6f2ff',rock:['#b8c8d4','#8aa0b4','#5a6c80'],mist:.1,ice:1,snd:[2400,.12]},
 {id:'horsetail', n:T('Horsetail Waterfall'),         w:70, h:96,lay:'horse',col:'#d8f0f6',rock:['#7a7a72','#5a5a56','#34342f'],mist:.9,snd:[1500,.65]},
 {id:'jungle',    n:T('Jungle Waterfall'),            w:150,h:84,lay:'two',  col:'#a8d0b8',rock:['#5a6a44','#445432','#2a3a20'],mist:1,vines:1,moss:1,snd:[1400,.7]},
 {id:'underground',n:T('Underground Waterfall'),      w:120,h:78,lay:'one',  col:'#7ad2ff',rock:['#3a3e4a','#262a34','#14161e'],mist:.8,cave:1,glow:'#58c8ff',snd:[1000,.8]},
 {id:'block',     n:T('Block Waterfall'),             w:170,h:76,lay:'block',col:'#e8f4f8',rock:['#b4b8bc','#8a9096','#5a6066'],mist:.8,snd:[1600,.65]},
 {id:'tiered',    n:T('Tiered Cascade Waterfall'),    w:120,h:104,lay:'tier',col:'#d4eef4',rock:['#8a8f84','#666c60','#3e4438'],mist:.9,snd:[1500,.7]},
 {id:'mossy',     n:T('Mossy Rock Waterfall'),        w:140,h:78,lay:'multi',col:'#c0e0d0',rock:['#6a8a52','#4e6e3c','#2e4426'],mist:.8,moss:1,snd:[1500,.6]},
 {id:'bioluminescent',n:T('Glowing Bioluminescent Waterfall'),w:130,h:84,lay:'two',col:'#58e8e0',rock:['#2a3a52','#1e2a40','#101824'],mist:.9,glow:'#37f0ff',glow2:'#c86bff',snd:[1300,.55]},
 {id:'plunge',    n:T('Plunge Waterfall'),            w:62, h:104,lay:'one',  col:'#e4f4f8',rock:['#7a766e','#58544e','#34312c'],mist:1.4,snd:[1100,.95]},
 {id:'fan',       n:T('Fan Waterfall'),               w:90, h:84,lay:'fan',  col:'#d8eef2',rock:['#9a9488','#72705e','#46443a'],mist:1,snd:[1500,.7]},
 {id:'volcanic',  n:T('Volcanic Steam Waterfall'),    w:120,h:80,lay:'one',  col:'#9ad0d0',rock:['#4a4046','#302a30','#1a161a'],mist:1.2,steam:1,glow:'#ff6a20',snd:[1300,.7]},
 {id:'punchbowl', n:T('Punchbowl Waterfall'),         w:64, h:92,lay:'punch',col:'#d0ecf0',rock:['#9a8468','#70583e','#42301e'],mist:1,round:1,snd:[1200,.8]},
 {id:'cascade',   n:T('Cascade Waterfall'),           w:110,h:116,lay:'steps',col:'#d4eef0',rock:['#9a9a8c','#6c6c60','#3c3c34'],mist:.8,snd:[1500,.7]},
 {id:'cliff',     n:T('Cliff Waterfall'),             w:150,h:96,lay:'one',  col:'#dcf0f4',rock:['#b08a62','#86643f','#52381f'],mist:1,snd:[1400,.8]},
 {id:'cave',      n:T('Cave Waterfall'),              w:130,h:82,lay:'one',  col:'#bfe4ee',rock:['#6a7280','#4a525e','#252a32'],mist:.9,cave:1,snd:[1100,.8]},
 {id:'curtain',   n:T('Curtain Waterfall'),           w:250,h:72,lay:'curtain',col:'#d6f0f4',rock:['#c4b494','#9a8a68','#5e5038'],mist:.9,snd:[1700,.75]},
 {id:'twin',      n:T('Twin Waterfall'),              w:170,h:88,lay:'twin', col:'#cfe9f0',rock:['#a4623e','#80472a','#4a2816'],mist:1,snd:[1400,.8]},
 {id:'segmented', n:T('Segmented Waterfall'),         w:120,h:112,lay:'seg', col:'#c8ece8',rock:['#88908e','#646c6a','#383e3c'],mist:.9,snd:[1500,.7]}
];

/* ---------- ponds & pools ---------- */
/* r radius range | c water [edge, mid, center] | rim shore colour | heal hp/s | slow extra | fx flags | snd = ambient event kind */
const HY_POND=[
 {id:'lily',      n:T('Lily Pond'),            r:[120,150],c:['#2f6a54','#3f8a6c','#58a884'],rim:'#6a8a48',lily:1,snd:'frog'},
 {id:'desert_oasis',n:T('Desert Oasis Pool'),  r:[110,140],c:['#1c7f92','#2fb0c0','#5cd8dc'],rim:'#d8c07a',palms:1,heal:0,snd:'bird'},
 {id:'hot_spring',n:T('Hot Spring Pool'),      r:[100,130],c:['#4aa0b0','#78d0d8','#a8f0f0'],rim:'#7a7468',steam:1,heal:4,snd:'bubble'},
 {id:'reed',      n:T('Reed Pond'),            r:[120,150],c:['#3a7062','#4f8a72','#6aa488'],rim:'#7a8a4a',reeds:1,snd:'frog'},
 {id:'swamp',     n:T('Swamp Pool'),           r:[130,160],c:['#2c4a2c','#3c5e36','#546e3c'],rim:'#4a4a2c',algae:1,logs:1,snd:'frog'},
 {id:'salt',      n:T('Salt Pond'),            r:[130,170],c:['#c88ea8','#e0aab8','#f4d0d4'],rim:'#f4f0ea',crust:1,snd:'bird'},
 {id:'bog',       n:T('Bog Pond'),             r:[110,140],c:['#2a2a22','#3a3626','#4a4430'],rim:'#4a4030',bubbles:1,snd:'bubble'},
 {id:'forest',    n:T('Forest Pond'),          r:[120,150],c:['#26546a','#34708a','#4f90a4'],rim:'#5a6a3c',refl:1,leaves:1,snd:'drip'},
 {id:'mossy',     n:T('Mossy Pond'),           r:[110,140],c:['#2a5a48','#3e7a58','#5a9a6a'],rim:'#4a6a34',moss:1,snd:'drip'},
 {id:'koi',       n:T('Koi Pond'),             r:[100,130],c:['#2a5a7a','#3a7898','#58a0b8'],rim:'#8a8478',koi:1,lily:1,refl:1,snd:'drip'},
 {id:'mirror',    n:T('Mirror Pond'),          r:[130,160],c:['#2a5878','#3a7090','#5090aa'],rim:'#7a8860',refl:2,snd:'bird'},
 {id:'rain',      n:T('Rain Pool'),            r:[100,130],c:['#4a7088','#5f8aa0','#7aa6b8'],rim:'#6a6a5a',rainfx:1,snd:'drip'},
 {id:'volcanic_hot',n:T('Volcanic Hot Pool'),  r:[100,130],c:['#2a6e78','#3a9a9a','#68c8b8'],rim:'#2a2428',steam:2,glowRim:'#ff6a20',heal:3,snd:'bubble'},
 {id:'quarry',    n:T('Abandoned Quarry Pool'),r:[130,170],c:['#14707c','#1c98a2','#3cc4c0'],rim:'#8a8478',quarry:1,snd:'drip'},
 {id:'fairy',     n:T('Fairy Pond'),           r:[100,130],c:['#2a4a7a','#3a68a0','#5a8ac8'],rim:'#5a7a48',fairy:1,glow:'#9affd8',snd:'chime'},
 {id:'spring_fed',n:T('Spring-Fed Pond'),       r:[100,130],c:['#2a8a9a','#3cb0b4','#6ad8c8'],rim:'#6a7a4a',springs:1,snd:'bubble'},
 {id:'glacier',   n:T('Glacier Pool'),         r:[120,150],c:['#3ca8c8','#68d0e0','#a8ecf4'],rim:'#e4f0f6',ice:1,snd:'ice'},
 {id:'cave_pool', n:T('Cave Pool'),            r:[100,130],c:['#12384a','#1a5a72','#2a8aa0'],rim:'#4a4e58',cave:1,glow:'#5ae0ff',snd:'drip'},
 {id:'rocky_plunge',n:T('Rocky Plunge Pool'),  r:[100,130],c:['#2a6a84','#3a8aa4','#5eaac0'],rim:'#6a6a64',rocks:1,snd:'drip'},
 {id:'crystal',   n:T('Crystal Clear Pool'),   r:[120,150],c:['#26b8c8','#58dcd8','#98f4ec'],rim:'#f0e4b8',clear:1,snd:'drip'}
];

/* ---------- bridges ---------- */
/* W = deck width | st = drawing style | hp = states: 'ok' | 'broken' | 'anim' */
const HY_BRIDGE=[
 {id:'stone_arch', n:T('Stone Arch Bridge'),      W:54,mat:'stone',snd:'thud'},
 {id:'stone_slab', n:T('Stone Slab Bridge'),      W:46,mat:'stone',snd:'thud'},
 {id:'rope',       n:T('Rope Bridge'),            W:34,mat:'rope', snd:'creak',sway:1,flag:1},
 {id:'bamboo',     n:T('Bamboo Bridge'),          W:40,mat:'wood', snd:'tock', flag:1},
 {id:'vine',       n:T('Vine Bridge'),            W:32,mat:'rope', snd:'creak',sway:1,vines:1},
 {id:'scrap',      n:T('Makeshift Scrap Bridge'), W:44,mat:'metal',snd:'clang'},
 {id:'log',        n:T('Log Bridge'),             W:36,mat:'wood', snd:'tock'},
 {id:'covered',    n:T('Covered Wooden Bridge'),  W:60,mat:'wood', snd:'tock', roof:1,flag:1},
 {id:'boardwalk',  n:T('Wooden Boardwalk'),       W:44,mat:'wood', snd:'tock'},
 {id:'railway',    n:T('Railway Bridge'),         W:52,mat:'metal',snd:'clang',rail:1},
 {id:'suspension', n:T('Suspension Bridge'),       W:50,mat:'metal',snd:'clang',cables:1,flag:1},
 {id:'cable_stayed',n:T('Cable-Stayed Bridge'),   W:56,mat:'metal',snd:'clang',cables:2,flag:1},
 {id:'broken',     n:T('Broken Bridge'),          W:46,mat:'wood', snd:'tock', broken:1},
 {id:'plank',      n:T('Plank Bridge'),           W:34,mat:'wood', snd:'tock'},
 {id:'living_root',n:T('Living Root Bridge'),      W:44,mat:'root', snd:'creak',vines:1},
 {id:'steel_truss',n:T('Steel Truss Bridge'),      W:56,mat:'metal',snd:'clang',truss:1},
 {id:'drawbridge', n:T('Drawbridge'),              W:56,mat:'wood', snd:'tock', draw:1,flag:1},
 {id:'aqueduct',   n:T('Stone Aqueduct Bridge'),   W:48,mat:'stone',snd:'thud', aque:1},
 {id:'swing',      n:T('Swing Bridge'),            W:46,mat:'metal',snd:'clang',swing:1},
 {id:'pontoon',    n:T('Floating Pontoon Bridge'), W:46,mat:'wood', snd:'tock', pontoon:1,flag:1}
];

/* ---------- map -> variants (har variant kam se kam ek map par) ---------- */
const HY_MAP=[
 {r:'meandering',   b:'stone_arch',  f:'seasonal',      p:'lily'},          // 0 Plains of India
 {r:'dry_riverbed', b:'stone_slab',  f:'rain_fed',      p:'desert_oasis'},  // 1 Thar Desert
 {r:'mountain_rapids',b:'rope',      f:'frozen',        p:'hot_spring'},    // 2 Himalayas
 {r:'marsh_channel',b:'bamboo',      f:'horsetail',     p:'reed'},          // 3 Kerala Backwaters
 {r:'jungle_river', b:'vine',        f:'jungle',        p:'swamp'},         // 4 Amazon Jungle
 {r:'braided',      b:'scrap',       f:'underground',   p:'salt'},          // 5 Sahara
 {r:'snowmelt',     b:'log',         f:'block',         p:'bog'},           // 6 Siberian Tundra
 {r:'forest_stream',b:'covered',     f:'tiered',        p:'forest'},        // 7 Alpine Valley
 {r:'delta',        b:'boardwalk',   f:'mossy',         p:'mossy'},         // 8 Sundarbans
 {r:'oxbow',        b:'railway',     f:'bioluminescent',p:'koi'},           // 9 Tokyo Night
 {r:'wide_slow',    b:'suspension',  f:'plunge',        p:'mirror'},        // 10 New York Blocks
 {r:'underground',  b:'cable_stayed',f:'fan',           p:'rain'},          // 11 Dubai
 {r:'lava_heated',  b:'broken',      f:'volcanic',      p:'volcanic_hot'},  // 12 Iceland Lava
 {r:'canyon',       b:'plank',       f:'punchbowl',     p:'quarry'},        // 13 Australian Outback
 {r:'rapid_chute',  b:'living_root', f:'cascade',       p:'fairy'},         // 14 Borneo Rainforest
 {r:'shallow_creek',b:'steel_truss', f:'cliff',         p:'spring_fed'},    // 15 African Savanna
 {r:'glacial',      b:'drawbridge',  f:'cave',          p:'glacier'},       // 16 Arctic Station
 {r:'spring_brook', b:'aqueduct',    f:'curtain',       p:'cave_pool'},     // 17 Mediterranean Coast
 {r:'rocky_gorge',  b:'swing',       f:'twin',          p:'rocky_plunge'},  // 18 Rocky Canyon
 {r:'tidal',        b:'pontoon',     f:'segmented',     p:'crystal'}        // 19 Maldives Island
];
const HY_CAT={river:HY_RIVER,bridge:HY_BRIDGE,fall:HY_FALL,pond:HY_POND};
const hyFind=(cat,id)=>HY_CAT[cat].find(v=>v.id===id);
