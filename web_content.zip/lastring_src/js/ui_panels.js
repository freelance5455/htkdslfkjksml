'use strict';
let pname='',ptab={};
const pb=()=>$('pbody');
function openPanel(n){pname=n;$('panel').hidden=false;render()}
function closePanel(){$('panel').hidden=true;pname='';refreshBars()}
function render(){
  const b=pb();b.innerHTML='';
  const PN={store:[T('Store'),pStore],luck:[T('Luck Royale'),pLuck],char:[T('Character'),pChar],vault:[T('Vault'),pVault],pet:[T('Pet'),pPet],col:[T('Collection'),pCol],weap:[T('Weapons'),pWeap],online:[T('Friends & Party'),pOnline],profile:[T('Profile'),pProfile],nature:[T('Water Worlds'),pNature],pass:[T('Royale Pass'),pPass],daily:[T('Daily Rewards & Missions'),pDaily],skin:[T('Weapon Skins'),pSkins],set:[T('Settings'),pSet],mode:[T('Mode & Map'),pMode]}[pname];
  if(!PN)return;$('ptitle').textContent=PN[0];b.append(PN[1]());
  const g=$('pCur');g.textContent=T('{0} Gold · {1} Diamonds',prof.gold,prof.gems);
}
function tabs(key,list,def){
  const cur=ptab[key]||def;
  return h('div',{class:'tabs'},list.map(([id,l])=>h('button',{class:'tab'+(id===cur?' on':''),onclick:()=>{ptab[key]=id;render()}},l)));
}
const SKIN_GUNS=['ranger','akm','awm','ump','falcon','kar98','titan','dmr','hornet','hammer'];   // skin card par alag-alag asli guns
function pv(it,w,hh){
  const c=document.createElement('canvas'),d=2;c.width=w*d;c.height=hh*d;c.style.width=w+'px';c.style.height=hh+'px';
  const g=c.getContext('2d');g.scale(d,d);
  if(it.cat==='o')drawChar(g,it,w/2,hh-10,(hh-22)/54,.6,0,{front:true,glow:true});
  else if(it.cat==='w'){const n=parseInt(String(it.id).slice(1))||0,gk=SKIN_GUNS[n%SKIN_GUNS.length];drawGunIcon(g,gk,w/2,hh/2,w/190,it.col||null,it.extra||'')}
  else if(it.cat==='g'){g.fillStyle='rgba(0,0,0,.25)';g.fillRect(w*.2+6,hh*.5+8,w*.6,16);for(let i=0;i<=30;i+=3){g.globalAlpha=.9;g.fillStyle=it.col;g.fillRect(w*.2,hh*.55-i+8,w*.6,16)}g.fillStyle='rgba(255,255,255,.5)';g.fillRect(w*.24,hh*.55-28,w*.3,3);g.globalAlpha=1}
  else if(it.cat==='p')drawPet(g,it.kind,w/2,hh-18,Math.min(w,hh)/20,0);
  return c;
}
const owned=id=>!!prof.owned[id];
function seededFeatured(){
  const d=new Date().toDateString();let s=0;for(const ch of d)s=(s*31+ch.charCodeAt(0))>>>0;
  const pool=Object.values(ITEMS).filter(i=>i.p>0&&!owned(i.id));const out=[];
  const r=()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296};
  while(out.length<6&&pool.length){out.push(pool.splice(Math.floor(r()*pool.length),1)[0].id)}
  return out;
}
function priceOf(it,feat){return feat?Math.floor(it.p*.7):it.p}
function buy(it,feat){
  if(owned(it.id))return;
  const p=priceOf(it,feat),k=it.c==='g'?'gold':'gems';
  if(prof[k]<p){toast(it.c==='g'?T('Not enough Gold'):T('Not enough Diamonds'));return}
  prof[k]-=p;prof.owned[it.id]=1;prof.eq[it.cat]=prof.eq[it.cat]||it.id;save();snd('pick');toast(T('{0} obtained',it.n));render();
}
function equip(it){prof.eq[it.cat]=it.id;save();snd('click');render()}
function card(it,feat){
  const ow=owned(it.id),eq=prof.eq[it.cat]===it.id;
  const price=priceOf(it,feat);
  return h('div',{class:'it'+(ow?'':' lock')+(eq?' eq':''),style:'--rc:'+RAR[it.r][1]},
    pv(it,112,128),h('b',null,it.n),h('small',null,RAR[it.r][0]+(it.extra?' · '+it.extra:'')),
    ow?h('button',{class:'sm'+(eq?' on':''),onclick:()=>equip(it)},eq?T('Equipped'):T('Equip'))
      :h('button',{class:'sm pri',onclick:()=>buy(it,feat)},(feat?'-30% ':'')+price+(it.c==='g'?T(' Gold'):T(' Diamonds'))));
}
function igrid(items,feat){return h('div',{class:'grid'},items.map(i=>card(i,feat)))}

/* ---- store ---- */
const CRATES={bronze:{n:T('Bronze Crate'),c:'g',p:150,w:[.65,.28,.07,0,0],col:'#c98a5a'},silver:{n:T('Silver Crate'),c:'g',p:400,w:[.3,.4,.22,.08,0],col:'#cfd6c8'},gold:{n:T('Gold Crate'),c:'d',p:30,w:[.05,.2,.35,.28,.12],col:'#ffb347'}};
function pStore(){
  const tab=ptab.store||'feat',w=h('div');
  w.append(h('div',{class:'row2'},h('span',{class:'dim'},T('Today\'s offers change daily')),h('button',{class:'sm pri',onclick:claimDaily},T('Claim daily bonus'))));
  w.append(tabs('store',[['feat',T('Featured')],['o',T('Outfit')],['w',T('Weapon Skin')],['g',T('Gloo Wall')],['p',T('Pet')],['crate',T('Crate')],['ex',T('Exchange')]],'feat'));
  if(tab==='feat'){const f=seededFeatured();w.append(f.length?igrid(f.map(i=>ITEMS[i]),true):h('p',{class:'dim'},T('You already have everything!')))}
  else if(tab==='crate')w.append(h('div',{class:'grid'},Object.entries(CRATES).map(([k,c])=>h('div',{class:'it',style:'--rc:'+c.col},h('div',{class:'crate',style:'--cc:'+c.col}),h('b',null,c.n),h('small',null,T('You have: {0}',prof.crates[k]||0)),h('button',{class:'sm pri',onclick:()=>{const kk=c.c==='g'?'gold':'gems';if(prof[kk]<c.p){toast(T('Balance too low'));return}prof[kk]-=c.p;prof.crates[k]=(prof.crates[k]||0)+1;save();snd('pick');toast(T('{0} obtained — open it in the Vault',c.n));render()}},c.p+(c.c==='g'?T(' Gold'):T(' Diamonds')))))));
  else if(tab==='ex')w.append(h('div',{class:'grid'},[[500,5],[1200,15],[3000,40]].map(([g,d])=>h('div',{class:'it',style:'--rc:#6fb7ff'},h('div',{class:'big'},d+' ◆'),h('small',null,T('for {0} Gold',g)),h('button',{class:'sm pri',onclick:()=>{if(prof.gold<g){toast(T('Not enough Gold'));return}prof.gold-=g;prof.gems+=d;save();snd('pick');render()}},T('Swap'))))));
  else w.append(igrid(Object.values(ITEMS).filter(i=>i.cat===tab)));
  return w;
}

/* ---- vault ---- */
function rollItem(rarW){
  let r=Math.random(),rar=0;for(let i=0;i<5;i++){r-=rarW[i];if(r<=0){rar=i;break}}
  let pool=Object.values(ITEMS).filter(i=>i.r===rar&&!owned(i.id));
  if(!pool.length)pool=Object.values(ITEMS).filter(i=>i.r<=rar&&!owned(i.id));
  return pool.length?pick(pool):null;
}
function grant(it){prof.owned[it.id]=1;save()}
function openCrate(k){
  if(!(prof.crates[k]>0))return;
  prof.crates[k]--;const it=rollItem(CRATES[k].w);
  const b=pb();b.innerHTML='';
  if(!it){prof.gold+=150;save();b.append(h('div',{class:'reveal'},h('div',{class:'big'},T('You got everything!')),h('p',null,T('+150 Gold received in exchange')),h('button',{class:'sm pri',onclick:render},T('OK'))));return}
  grant(it);snd('win');
  b.append(h('div',{class:'reveal',style:'--rc:'+RAR[it.r][1]},h('small',{class:'dim'},T('From {0}',CRATES[k].n)),pv(it,150,170),h('b',{class:'big'},it.n),h('small',null,RAR[it.r][0]+' · '+CATN[it.cat]),h('button',{class:'sm pri',onclick:()=>{equip(it)}},T('Equip now')),h('button',{class:'sm',onclick:render},T('Back'))));
}
function pVault(){
  const w=h('div');
  w.append(h('h3',null,T('My Crates')));
  w.append(h('div',{class:'grid'},Object.entries(CRATES).map(([k,c])=>h('div',{class:'it',style:'--rc:'+c.col},h('div',{class:'crate',style:'--cc:'+c.col}),h('b',null,c.n),h('small',null,'×'+(prof.crates[k]||0)),h('button',{class:'sm pri'+((prof.crates[k]||0)?'':' off'),onclick:()=>openCrate(k)},T('Open'))))));
  w.append(h('h3',null,T('My Items')));
  w.append(igrid(Object.values(ITEMS).filter(i=>owned(i.id))));
  return w;
}

/* ---- luck royale ---- */
const WHEEL=[{l:T('100 Gold'),t:'gold',v:100,w:30},{l:'5 ◆',t:'gems',v:5,w:20},{l:T('Bronze Crate'),t:'crate',v:'bronze',w:15},{l:T('500 Gold'),t:'gold',v:500,w:12},{l:T('Rare item'),t:'item',v:[0,0,1,0,0],w:8},{l:'20 ◆',t:'gems',v:20,w:6},{l:T('Silver Crate'),t:'crate',v:'silver',w:6},{l:T('Epic item'),t:'item',v:[0,0,0,1,0],w:3}];
let spinning=false,wheelDeg=0;
function pLuck(){
  const w=h('div',{class:'luck'});
  const cols=['#3a2f8f','#2a5fa0','#7a3fa0','#a06a1a','#1f7a6a','#a03a5a','#4a6a2a','#8a5a2a'];
  const wh=h('div',{class:'wheel',style:`transform:rotate(${wheelDeg}deg);background:conic-gradient(${WHEEL.map((_,i)=>cols[i]+' '+i*45+'deg '+(i+1)*45+'deg').join(',')})`},
    WHEEL.map((s,i)=>h('span',{style:`transform:rotate(${i*45+22.5}deg) translateY(-92px) rotate(-${i*45+22.5}deg)`},s.l)));
  const free=prof.spin!==new Date().toDateString();
  w.append(h('div',{class:'wheelbox'},h('div',{class:'ptr'}),wh));
  w.append(h('button',{class:'pri big2',onclick:()=>spin(wh,free)},free?T('Today\'s Free Spin'):T('Spin · 10 Diamonds')));
  w.append(h('p',{class:'dim'},T('One free spin every day. Rewards: Gold, Diamonds, crates and Rare/Epic items.')));
  return w;
}
function spin(wh,free){
  if(spinning)return;
  if(!free&&prof.gems<10){toast(T('Not enough Diamonds'));return}
  if(free)prof.spin=new Date().toDateString();else prof.gems-=10;
  let tw=WHEEL.reduce((a,s)=>a+s.w,0),r=Math.random()*tw,idx=0;for(let i=0;i<WHEEL.length;i++){r-=WHEEL[i].w;if(r<=0){idx=i;break}}
  spinning=true;wheelDeg=Math.ceil(wheelDeg/360)*360+360*5+(360-(idx*45+22.5));
  wh.style.transition='transform 4s cubic-bezier(.12,.7,.1,1)';wh.style.transform=`rotate(${wheelDeg}deg)`;
  for(let i=0;i<8;i++)setTimeout(()=>snd('click'),i*420);
  setTimeout(()=>{
    spinning=false;const s=WHEEL[idx];let msg='';
    if(s.t==='gold'){prof.gold+=s.v;msg=T('+{0} Gold',s.v)}
    else if(s.t==='gems'){prof.gems+=s.v;msg=T('+{0} Diamonds',s.v)}
    else if(s.t==='crate'){prof.crates[s.v]=(prof.crates[s.v]||0)+1;msg=T('{0} received',CRATES[s.v].n)}
    else{const it=rollItem(s.v);if(it){grant(it);msg=T('{0} received!',it.n)}else{prof.gold+=300;msg=T('+{0} Gold',300)}}
    save();snd('win');toast(msg);ptab.luckMsg=msg;render();
  },4200);
}

/* ---- character ---- */
function pOut(){
  const o=ITEMS[prof.eq.o]||OUT[0],w=h('div',{class:'split'});
  w.append(h('div',{class:'bigpv',style:'--rc:'+RAR[o.r][1]},pv(o,200,280),h('b',null,o.n),h('small',null,RAR[o.r][0])));
  w.append(h('div',null,h('p',{class:'dim'},T('Buy and equip any outfit. Your character will look like this in real matches.')),igrid(OUT)));
  return w;
}
/* ---- pets ---- */
function pPet(){
  const w=h('div');
  w.append(h('p',{class:'dim'},T('The pet walks with you in matches and gives a small benefit.')));
  w.append(h('div',{class:'grid'},[h('div',{class:'it'+(prof.eq.p?'':' eq'),style:'--rc:#888'},h('div',{class:'big'},'—'),h('b',null,T('No pet')),h('button',{class:'sm',onclick:()=>{prof.eq.p='';save();render()}},T('Select'))),...PETS.map(card)]));
  return w;
}
/* ---- weapons ---- */
function pWeap(){
  const w=h('div');
  w.append(h('div',{class:'row2'},h('span',{class:'dim'},T('3 skins for every weapon: Default / Gold / Neon')),h('button',{class:'sm pri',onclick:()=>openPanel('skin')},T('Choose Weapon Skin'))));
  w.append(h('h3',null,T('Skins')));w.append(igrid(WSK));
  w.append(h('h3',null,T('All weapons')));
  const bar=(v,m)=>h('i',{class:'sb'},h('u',{style:'width:'+clamp(v/m*100,4,100)+'%'}));
  w.append(h('div',{class:'wlist'},WKEYS.map(k=>{
    const x=WP[k],c=document.createElement('canvas');c.width=240;c.height=100;c.style.width='120px';c.style.height='50px';
    const g=c.getContext('2d');g.scale(2,2);const sk=ITEMS[prof.eq.w];drawGunIcon(g,k,60,25,.62,sk&&sk.col||null);
    return h('div',{class:'wi',style:'--rc:'+RAR[x.tier][1]},c,h('div',null,h('b',null,x.n),h('small',null,T('{0} · Magazine {1}',RAR[x.tier][0],x.mag)),
      h('div',{class:'stats'},h('span',null,T('Damage')),bar(x.dmg*x.pel,100),h('span',null,T('Rate')),bar(1/x.rate,12),h('span',null,T('Range')),bar(x.range,1200))));
  })));
  return w;
}
/* ---- collection ---- */
function pCol(){
  const all=Object.values(ITEMS),have=all.filter(i=>owned(i.id)).length,pct=Math.floor(have/all.length*100);
  const w=h('div');
  w.append(h('div',{class:'row2'},h('b',{class:'big2'},T('{0} / {1} items',have,all.length)),h('span',{class:'dim'},T('{0}% complete',pct))));
  w.append(h('div',{class:'bar'},h('i',{style:'width:'+pct+'%;background:var(--accent)'})));
  const ms=[[25,'g',500],[50,'d',20],[75,'d',40],[100,'d',100]];
  w.append(h('div',{class:'row2 wrap'},ms.map(([p,c,v])=>{const cl=prof.col[p],ok=pct>=p;return h('button',{class:'sm'+(ok&&!cl?' pri':'')+(!ok||cl?' off':''),onclick:()=>{if(!ok||cl)return;prof.col[p]=1;if(c==='g')prof.gold+=v;else prof.gems+=v;save();snd('heal');render()}},p+'%: '+v+(c==='g'?' '+T('Gold'):' ◆')+(cl?' ✓':''))})));
  for(const [cat,n] of Object.entries(CATN)){w.append(h('h3',null,n));w.append(igrid(all.filter(i=>i.cat===cat)))}
  return w;
}
/* ---- pass ---- */
function giveReward(r){
  if(r.t==='gold')prof.gold+=r.v;else if(r.t==='gems')prof.gems+=r.v;
  else{const it=ITEMS[r.v];if(owned(it.id))prof.gold+=50*(it.r+1);else prof.owned[it.id]=1}
}
const rtext=r=>r.t==='gold'?r.v+' '+T('Gold'):r.t==='gems'?r.v+' ◆':ITEMS[r.v].n;
function pPass(){
  const lv=Math.min(30,Math.floor(prof.xp/100)),w=h('div');
  w.append(h('div',{class:'row2'},h('b',{class:'big2'},T('Pass level {0} / 30',lv)),prof.pass.prem?h('span',{class:'tag'},T('Premium active')):h('button',{class:'sm pri',onclick:()=>{if(prof.gems<150){toast(T('150 Diamonds needed'));return}prof.gems-=150;prof.pass.prem=true;save();snd('win');render()}},T('Premium · 150 ◆'))));
  w.append(h('p',{class:'dim'},T('You earn XP from every match. One level for every 100 XP.')));
  w.append(h('div',{class:'plist'},PASS.map(r=>{
    const up=lv>=r.l;
    const cell=(k,rw,prem)=>{const key=k+r.l,cl=prof.pass.cl[key],lock=prem&&!prof.pass.prem;return h('button',{class:'pc'+(up&&!lock&&!cl?' go':'')+(cl?' done':'')+(!up||lock?' off':''),onclick:()=>{if(!up||lock||cl)return;prof.pass.cl[key]=1;giveReward(rw);save();snd('pick');render()}},rtext(rw),cl?' ✓':'')};
    return h('div',{class:'pr'},h('span',{class:'pl'},r.l),cell('f',r.free,false),cell('p',r.prem,true));
  })));
  return w;
}
/* ---- mode & map ---- */
function pMode(){
  const w=h('div');
  w.append(h('h3',null,T('Mode')));
  w.append(h('div',{class:'grid wide'},MODES.map(m=>h('button',{class:'mc'+(prof.mode===m.id?' on':''),onclick:()=>{prof.mode=m.id;save();render()}},h('b',null,m.n),h('small',null,m.d)))));
  w.append(h('h3',null,T('Maps ({0} real locations)',MAPS.length)));
  w.append(h('div',{class:'grid wide'},MAPS.map((m,i)=>h('button',{class:'mc map'+(prof.map===i?' on':''),style:`--a:${m.g[0]};--b:${m.g[1]};--w:${m.wat}`,onclick:()=>{prof.map=i;save();render()}},
    h('div',{class:'sw'}),h('b',null,m.n),h('small',null,m.loc+' · '+T('{0} km',(m.size/1000).toFixed(1))),h('small',null,({clear:T('Clear weather'),rain:T('Rain'),snow:T('Snowfall'),blizzard:T('Blizzard'),sand:T('Sandstorm'),ash:T('Ash'),mist:T('Mist')}[m.wx])+(m.night?' · '+T('Night'):'')+(m.urb?' · '+T('City'):''))))));
  return w;
}
/* ---- settings ---- */
function pSet(){
  const w=h('div',{class:'sets'});
  const row=(l,c)=>h('div',{class:'srow'},h('label',null,l),c);
  const sl=(k,min,max,step,after)=>{const v=h('b',null,String(set[k]));return h('div',{class:'sl'},h('input',{type:'range',min,max,step,value:set[k],oninput:e=>{set[k]=+e.target.value;v.textContent=set[k];save();if(after)after()}}),v)};
  const seg=(k,opts,after)=>h('div',{class:'seg'},opts.map(([id,l])=>h('button',{class:set[k]===id?'on':'',onclick:()=>{set[k]=id;save();if(after)after();render()}},l)));
  const tg=(k,after)=>h('div',{class:'seg'},[[true,T('On')],[false,T('Off')]].map(([id,l])=>h('button',{class:set[k]===id?'on':'',onclick:()=>{set[k]=id;save();if(after)after();render()}},l)));
  w.append(h('h3',null,T('Language')));
  for(const [g,lab] of [['in','Indian languages'],['world','World languages']])
    w.append(row(T(lab),h('div',{class:'seg'},I18N.langs.filter(l=>l.grp===g).map(l=>h('button',{class:I18N.lang===l.id?'on':'',title:l.en,lang:l.id,onclick:()=>{if(I18N.lang!==l.id)I18N.change(l.id)}},l.n)))));
  w.append(h('h3',null,T('Profile')));
  w.append(row(T('Name'),h('input',{type:'text',maxlength:'14',value:prof.name,class:'txt',oninput:e=>{prof.name=e.target.value||'Player';save();clearTimeout(window._nmT);window._nmT=setTimeout(()=>Net.send({t:'profile',name:prof.name}),700)}})));
  w.append(h('h3',null,T('Graphics')));
  w.append(row(T('Quality'),seg('gfx',[['low',T('Low')],['med',T('Medium')],['high',T('High')],['ultra',T('Ultra')],['max',T('Max')]],resize)));
  w.append(h('p',{class:'dim'},T('Map quality changes from the next match. Ultra has the most water waves, lighting and glow.')));
  w.append(row(T('Camera zoom'),sl('zoom',.7,1.4,.05,resize)));
  w.append(h('h3',null,T('Controls & Sensitivity')));
  w.append(row(T('Aim sensitivity (swipe)'),sl('aim',.3,2.5,.1)));
  w.append(row(T('Aim stick sensitivity'),sl('fsens',.3,2.5,.1)));
  w.append(row(T('Joystick size'),sl('joy',.7,1.5,.05)));
  w.append(row(T('Button size'),sl('btn',.7,1.4,.05,applyTouchUI)));
  w.append(row(T('Auto-aim assist (locks onto the nearest enemy when you press fire)'),tg('assist')));
  w.append(row(T('Auto-aim radius'),sl('aimRadius',200,700,25)));
  w.append(row(T('Aim assist while dragging'),tg('dragAssist')));
  w.append(row(T('Separate Fire button (right stick is for aiming only)'),tg('sepFire',applyTouchUI)));
  w.append(row(T('Show aim arrow'),tg('aimArrow')));
  w.append(row(T('Water Worlds (rivers, waterfalls, ponds, bridges)'),tg('hydro')));
  w.append(row(T('Jump from the plane (Battle Royale)'),tg('airDrop')));
  w.append(row(T('Aim stick drag (old mode only)'),seg('dragFire',[['release',T('Fire on release')],['hold',T('Fire while dragging')]])));
  w.append(row(T('Keep firing after releasing the drag'),tg('contFire')));
  w.append(h('p',{class:'dim'},T('Tap only = fire with auto-aim. Drag the aim stick to aim yourself — auto-aim stays on and gently pulls your aim onto nearby enemies.')));
  w.append(row(T('Floating joystick'),tg('float')));
  w.append(row(T('On-screen buttons'),seg('show',[['auto',T('Auto')],['on',T('Always')],['off',T('Off')]],applyTouchUI)));
  w.append(row(T('Touch controls layout'),h('button',{class:'sm',onclick:openLayoutEditor},T('Move / adjust buttons'))));
  w.append(row(T('Loot auto-pickup (off = ground items are not picked up automatically; press the "Pick up" button)'),tg('autopick',applyTouchUI)));
  w.append(row(T('Auto fullscreen (hides the phone navigation bar)'),tg('autoFs')));
  w.append(row(T('Fullscreen + landscape lock'),h('button',{class:'sm',onclick:goLandscape},T('Enable'))));
  w.append(h('h3',null,T('Sound')));
  w.append(row(T('Volume'),sl('vol',0,1,.05)));
  w.append(row(T('Character voice lines'),tg('voice')));
  w.append(row(T('Background music'),tg('music')));
  w.append(row(T('Music volume'),sl('musicVol',0,1,.05)));
  w.append(h('div',{class:'keys'},h('b',null,T('Keyboard: ')),T('WASD move · mouse aim/fire · R reload · Q swap weapon · G grenade · T smoke · C Gloo Wall · H bandage · J medkit · Esc pause')));
  w.append(h('div',{class:'row2'},h('button',{class:'sm',onclick:()=>{Object.assign(set,DEF.set,{gfx:set.gfx});set.layout={};save();render();applyTouchUI()}},T('Reset controls'))));
  return w;
}
