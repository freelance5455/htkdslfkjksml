'use strict';
/* =====================================================================
   drop.js — विमान से कूदना (airplane jump + parachute)
   ---------------------------------------------------------------------
   Match shuru: sab players ek vimaan mein, vimaan map ke upar se seedha udta hai.
   Player: T('JUMP') button / SPACE / J dabao (ya vimaan ka rasta khatam hote hi auto-jump).
   Kudne ke baad ~4s parachute: joystick se dishaa chuno, utarte hi normal game (1.5s protection).
   Bots: apni marzi se alag-alag jagah kudte hain; squad saathi tumhare kudne ke baad tumhare paas utarte hain.
   Sirf battle-royale modes mein (TDM/KOTH mein nahi). Settings: set.airDrop.
   Tuning: Drop.cfg
   ===================================================================== */
const Drop={
  cfg:{
    planeSpeed:340,      // px/s
    overshoot:.62,       // path length = MAP * overshoot * 2
    fallSec:4.2,         // parachute mein kitni der
    steer:240,           // parachute steer speed (px/s)
    steerLag:2.2,        // kitni jaldi velocity target tak aati hai
    landProtect:1.5,     // utarne ke baad bachav (sec)
    botLandMin:250,botLandMax:850,
    planeLen:150         // sprite lambai (world px) — player ~26px; "bada nahi"
  },
  plane:null,spr:null,shd:null,_hud:{},

  get hold(){return !!(typeof player!=='undefined'&&player&&player.air)},   // zone/time ruk jaye jab tak player utar na jaye
  reset(){this.plane=null},

  /* ---------- start ---------- */
  begin(){
    this.reset();
    if(set.airDrop===false||mode.rules||MatchNet.active)return;
    const c=this.cfg,a=rnd(0,TAU),dx=Math.cos(a),dy=Math.sin(a),half=MAP*c.overshoot;
    const cx=MAP/2+rnd(-.1,.1)*MAP,cy=MAP/2+rnd(-.1,.1)*MAP,len=half*2,flight=len/c.planeSpeed;
    const P=this.plane={x0:cx-dx*half,y0:cy-dy*half,dx,dy,spd:c.planeSpeed,flight,sec:0,ang:a,len};
    P.x=P.x0;P.y=P.y0;
    const lead={};
    for(const p of players){
      p.air='plane';p.at=0;p.vx=p.vy=0;p.fl=0;p.dprot=0;p.follow=false;p.jt=null;p.L=null;
      p.x=p.lx=P.x;p.y=p.ly=P.y;
      if(p===player)continue;
      if(p.team===player.team){p.follow=true;p.off=[rnd(-70,70),rnd(-70,70)];continue}   // saathi: player ke saath
      const l=lead[p.team];
      if(!l){lead[p.team]=p;p.jt=rnd(.08,.92)*flight;p.L=this.pickLand(p.jt)}
      else{const b=rnd(0,TAU);p.jt=Math.min(flight,l.jt+rnd(0,.6));p.L={x:l.L.x+Math.cos(b)*rnd(40,90),y:l.L.y+Math.sin(b)*rnd(40,90)}}
    }
    cam.x=P.x;cam.y=P.y-18;
    toast(T('The plane is flying — press "JUMP"!'));
  },
  pos(sec){const P=this.plane;return[P.x0+P.dx*P.spd*sec,P.y0+P.dy*P.spd*sec]},
  okLand(x,y){return x>200&&y>200&&x<MAP-200&&y<MAP-200&&!blocked(x,y)&&!lakes.some(l=>Math.hypot(x-l.x,y-l.y)<l.r+40)&&!Hydro.wet(x,y)},
  pickLand(jt){
    const c=this.cfg,[jx,jy]=this.pos(jt);
    for(let i=0;i<50;i++){
      const a=rnd(0,TAU),d=rnd(c.botLandMin,c.botLandMax),x=jx+Math.cos(a)*d,y=jy+Math.sin(a)*d;
      if(this.okLand(x,y))return{x,y};
    }
    return{x:clamp(jx,220,MAP-220),y:clamp(jy,220,MAP-220)};
  },

  /* ---------- actions ---------- */
  jump(p){
    const P=this.plane;if(!P||p.air!=='plane')return;
    p.air='fall';p.at=this.cfg.fallSec;
    p.vx=P.dx*P.spd*.8;p.vy=P.dy*P.spd*.8;               // vimaan ki gati se nikalte hain, phir slow hoti hai
    if(p===player){snd('pick');toast(T('Parachute — steer with the joystick'));
      for(const b of players)if(b.follow&&b.air==='plane')b.jt=P.sec+rnd(.15,.8)}   // saathi peeche-peeche kudte hain
  },
  jumpPlayer(){if(state==='play'&&player&&player.alive&&player.air==='plane')this.jump(player)},
  land(p){
    p.air=null;p.at=0;p.vx=p.vy=0;fix(p);p.lx=p.x;p.ly=p.y;p.dprot=this.cfg.landProtect;p.pk=0;
    for(let i=0;i<10;i++)parts.push({x:p.x,y:p.y,z:rnd(0,8),vx:rnd(-70,70),vy:rnd(-70,70),l:rnd(.3,.6),c:'#cfc3a0'});
    if(p===player){snd('pick');toast(T('Landed! Grab some loot'))}
  },

  /* ---------- per frame ---------- */
  update(dt){
    const P=this.plane;if(!P||state!=='play')return;
    P.sec+=dt;[P.x,P.y]=this.pos(P.sec);
    let any=false;
    for(const p of players){
      if(!p.alive||!p.air)continue;
      any=true;
      if(p.air==='plane'){
        p.x=p.lx=P.x;p.y=p.ly=P.y;
        if(P.sec>=P.flight+.1||(p!==player&&p.jt!=null&&P.sec>=p.jt))this.jump(p);   // rasta khatam = auto-jump
      }else this.fall(p,dt);
    }
    if(!any&&P.sec>P.flight+1.5)this.plane=null;
  },
  fall(p,dt){
    const c=this.cfg;let tx=0,ty=0;
    if(p===player){
      let mx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),my=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);
      mx+=stk.mv.x;my+=stk.mv.y;const m=Math.hypot(mx,my);if(m>1){mx/=m;my/=m}
      tx=mx*c.steer;ty=my*c.steer;
    }else{
      const L=p.follow?{x:player.x+p.off[0],y:player.y+p.off[1]}:p.L;
      if(L){const dx=L.x-p.x,dy=L.y-p.y,d=Math.hypot(dx,dy)||1,sp=Math.min(c.steer,d/Math.max(.4,p.at));tx=dx/d*sp;ty=dy/d*sp}
    }
    const k=Math.min(1,dt*c.steerLag);
    p.vx+=(tx-p.vx)*k;p.vy+=(ty-p.vy)*k;
    p.x=clamp(p.x+p.vx*dt,40,MAP-40);p.y=clamp(p.y+p.vy*dt,40,MAP-40);p.lx=p.x;p.ly=p.y;
    if(Math.hypot(p.vx,p.vy)>30)p.ang=Math.atan2(p.vy,p.vx);
    p.at-=dt;if(p.at<=0)this.land(p);
  },

  /* ---------- plane sprite (procedural texture) ---------- */
  buildSprite(){
    const SC=3,W=170,H=150,cv=document.createElement('canvas');cv.width=W*SC;cv.height=H*SC;
    const g=cv.getContext('2d');g.scale(SC,SC);g.translate(W/2,H/2);
    let sd=7;const rn=()=>(sd=(sd*16807)%2147483647)/2147483647;
    const lin=(x0,y0,x1,y1,st)=>{const l=g.createLinearGradient(x0,y0,x1,y1);st.forEach(([o,c])=>l.addColorStop(o,c));return l};
    g.lineJoin='round';g.lineCap='round';
    // --- tail planes + fin
    for(const s of[-1,1]){
      g.beginPath();g.moveTo(-58,s*5);g.lineTo(-68,s*27);g.lineTo(-77,s*27);g.lineTo(-73,s*5);g.closePath();
      g.fillStyle=lin(0,s*5,0,s*27,[[0,'#cfd6dc'],[1,'#98a3ae']]);g.fill();g.strokeStyle='#5d6873';g.lineWidth=.8;g.stroke();
    }
    // --- main wings
    for(const s of[-1,1]){
      g.beginPath();g.moveTo(16,s*8);g.lineTo(3,s*61);g.lineTo(-14,s*61);g.lineTo(-22,s*8);g.closePath();
      g.fillStyle=lin(0,s*8,0,s*61,[[0,'#e6ebef'],[.55,'#c4ccd3'],[1,'#9aa5b0']]);g.fill();g.strokeStyle='#5d6873';g.lineWidth=.9;g.stroke();
      g.fillStyle='#d6453d';g.beginPath();g.moveTo(4,s*50);g.lineTo(3,s*61);g.lineTo(-14,s*61);g.lineTo(-12,s*50);g.closePath();g.fill();     // tip stripe
      g.fillStyle='rgba(40,50,60,.35)';g.beginPath();g.moveTo(-12,s*10);g.lineTo(-14,s*60);g.lineTo(-22,s*8);g.closePath();g.fill();            // flaps (trailing edge)
      g.strokeStyle='rgba(60,70,80,.45)';g.lineWidth=.55;
      for(let i=1;i<6;i++){const y=s*(8+i*9);g.beginPath();g.moveTo(14-i*2.1,y);g.lineTo(-20+i*1.2,y);g.stroke()}       // panel lines
      g.beginPath();g.moveTo(10,s*8);g.lineTo(-1,s*60);g.stroke();
    }
    // --- engines (4)
    for(const [ex,ey] of this.engines()){
      g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.ellipse(ex-1.5,ey+1.5,12,4.6,0,0,TAU);g.fill();
      g.fillStyle=lin(0,ey-4.5,0,ey+4.5,[[0,'#8e99a4'],[.4,'#eef2f5'],[1,'#6f7b87']]);rr(g,ex-14,ey-4.5,24,9,4);g.fill();g.strokeStyle='#4f5a65';g.lineWidth=.7;g.stroke();
      g.fillStyle='#2a323a';g.beginPath();g.arc(ex+10.5,ey,2.4,0,TAU);g.fill();                                                        // spinner
      g.fillStyle='rgba(20,20,20,.35)';g.fillRect(ex-14,ey-1.2,8,2.4);                                                                  // exhaust
    }
    // --- fuselage
    g.beginPath();g.moveTo(76,0);g.bezierCurveTo(68,-8,58,-11,46,-11);g.lineTo(-46,-9.5);g.bezierCurveTo(-64,-8,-72,-4,-77,-2.5);g.lineTo(-77,2.5);
    g.bezierCurveTo(-72,4,-64,8,-46,9.5);g.lineTo(46,11);g.bezierCurveTo(58,11,68,8,76,0);g.closePath();
    g.fillStyle=lin(0,-11,0,11,[[0,'#8995a1'],[.28,'#f6f8fa'],[.6,'#d3dae0'],[1,'#7f8b97']]);g.fill();g.strokeStyle='#4f5a65';g.lineWidth=1;g.stroke();
    g.save();g.clip();
    g.fillStyle=lin(-60,0,50,0,[[0,'#1f5fe0'],[1,'#3d86ff']]);g.fillRect(-62,-3.2,112,6.4);                                           // blue livery band
    g.fillStyle='#ffb347';g.fillRect(-62,3.2,112,1.3);g.fillRect(-62,-4.5,112,1.3);                                                       // orange pin-stripes
    g.fillStyle='#d6453d';g.fillRect(-77,-3,22,6);g.fillStyle='#fff';g.fillRect(-77,-.9,22,1.8);                                          // tail paint
    g.strokeStyle='rgba(50,60,70,.35)';g.lineWidth=.6;for(let x=-40;x<=40;x+=20){g.beginPath();g.moveTo(x,-12);g.lineTo(x,12);g.stroke()}    // panel joins
    g.fillStyle='rgba(60,70,80,.55)';for(let x=-70;x<68;x+=6){g.fillRect(x,-9.2,1,1);g.fillRect(x,8.2,1,1)}                              // rivets
    g.restore();
    g.fillStyle='#fff';g.font='700 5.6px Arial,sans-serif';g.textAlign='center';g.fillText('LAST RING',-5,1.9);
    // cockpit
    g.beginPath();g.moveTo(54,-5.5);g.lineTo(66,-3.4);g.lineTo(69,0);g.lineTo(66,3.4);g.lineTo(54,5.5);g.lineTo(51,0);g.closePath();
    g.fillStyle=lin(51,-5,66,5,[[0,'#1b3a5a'],[.6,'#3f93d4'],[1,'#a9dcff']]);g.fill();g.strokeStyle='#14283b';g.lineWidth=.7;g.stroke();
    g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=.7;g.beginPath();g.moveTo(57,-3.6);g.lineTo(65,-2);g.stroke();
    g.beginPath();g.moveTo(58,-5);g.lineTo(58,5);g.stroke();
    // --- texture: speckle + grime, sirf plane ke pixels par
    g.globalCompositeOperation='source-atop';
    for(let i=0;i<1400;i++){g.fillStyle=rn()<.5?'rgba(0,0,0,'+(.03+rn()*.05)+')':'rgba(255,255,255,'+(.04+rn()*.06)+')';g.fillRect((rn()-.5)*W,(rn()-.5)*H,rn()*1.6+.3,rn()*1.6+.3)}
    for(const [ex,ey] of this.engines()){const gr=g.createLinearGradient(ex-6,0,ex-44,0);gr.addColorStop(0,'rgba(30,25,20,.28)');gr.addColorStop(1,'rgba(30,25,20,0)');g.fillStyle=gr;g.fillRect(ex-44,ey-4,38,8)}  // soot
    g.globalCompositeOperation='source-over';
    this.spr=cv;
    const sh=document.createElement('canvas');sh.width=cv.width;sh.height=cv.height;const s2=sh.getContext('2d');
    s2.drawImage(cv,0,0);s2.globalCompositeOperation='source-in';s2.fillStyle='#000';s2.fillRect(0,0,sh.width,sh.height);this.shd=sh;
  },
  engines(){return[[10,-27],[8,-45],[10,27],[8,45]]},

  drawPlane(c){
    const P=this.plane;if(!P||P.sec>P.flight+2)return;
    if(!this.spr)this.buildSprite();
    const k=this.cfg.planeLen/150,w=170*k,h=150*k,ALT=64;
    // vimaan ki parchhai zameen par
    c.save();c.globalAlpha=.26;c.translate(P.x+34,P.y+6);c.rotate(P.ang);c.drawImage(this.shd,-w/2*.86,-h/2*.86,w*.86,h*.86);c.restore();
    // contrail (engines ke peeche)
    c.save();c.translate(P.x,P.y-ALT);c.rotate(P.ang);
    for(const [ex,ey] of this.engines()){
      const gr=c.createLinearGradient(ex*k-8,0,ex*k-200,0);gr.addColorStop(0,'rgba(255,255,255,.34)');gr.addColorStop(1,'rgba(255,255,255,0)');
      c.fillStyle=gr;c.beginPath();c.moveTo(ex*k-8,ey*k-1.5);c.lineTo(ex*k-200,ey*k-6);c.lineTo(ex*k-200,ey*k+6);c.lineTo(ex*k-8,ey*k+1.5);c.fill();
    }
    c.drawImage(this.spr,-w/2,-h/2,w,h);
    // ghoomte propeller
    const ph=performance.now()/22;
    for(const [ex,ey] of this.engines()){
      const px=(ex+11)*k,py=ey*k,r=10.5*k;
      c.fillStyle='rgba(215,225,235,.22)';c.beginPath();c.ellipse(px,py,2.6*k,r,0,0,TAU);c.fill();
      c.strokeStyle='rgba(30,36,44,.75)';c.lineWidth=1.3*k;c.beginPath();const bl=r*Math.cos(ph+ey);c.moveTo(px,py-bl);c.lineTo(px,py+bl);c.stroke();
    }
    c.restore();
  },
  drawFall(c,p,f,q){
    const t=clamp(p.at/this.cfg.fallSec,0,1),lift=6+118*Math.pow(t,.8),sw=Math.sin(performance.now()/420+p.x)*3;
    // zameen par parchhai
    c.fillStyle='rgba(0,0,0,.28)';c.beginPath();c.ellipse(p.x,p.y+2,15-5*t,6-2*t,0,0,TAU);c.fill();
    c.save();c.translate(sw*t,-lift);
    // canopy
    const cy=p.y-72,R=36*(.55+.45*Math.min(1,t*3.5)),cols=p===player?['#ff9a2e','#fff2d6']:p.team===player.team?['#4a90e8','#dbeaff']:[['#e35d5d','#5db3e3','#7bd88f','#c78cff','#ffd36b'][(p.name||'').length%5],'#f2f2f2'];
    c.strokeStyle='rgba(30,30,30,.7)';c.lineWidth=1;
    for(let i=-2;i<=2;i++){c.beginPath();c.moveTo(p.x+i*R*.42,cy+5);c.lineTo(p.x,p.y-36);c.stroke()}
    const n=6;
    for(let i=0;i<n;i++){
      const a0=Math.PI+i/n*Math.PI,a1=Math.PI+(i+1)/n*Math.PI;
      c.beginPath();c.moveTo(p.x,cy+4);c.ellipse(p.x,cy+4,R,R*.62,0,a0,a1);c.closePath();
      c.fillStyle=i%2?cols[1]:cols[0];c.fill();c.strokeStyle='rgba(0,0,0,.35)';c.stroke();
    }
    c.fillStyle='rgba(0,0,0,.2)';c.beginPath();c.ellipse(p.x,cy+5,R,R*.12,0,0,Math.PI);c.fill();
    drawPlayer(p,f,q);
    c.restore();
  },
  drawMini(c,x,y,k){
    const P=this.plane;if(!P)return;
    c.save();c.strokeStyle='rgba(255,255,255,.55)';c.lineWidth=1;c.setLineDash([3,3]);
    c.beginPath();c.moveTo(x+P.x0*k,y+P.y0*k);c.lineTo(x+(P.x0+P.dx*P.len)*k,y+(P.y0+P.dy*P.len)*k);c.stroke();c.setLineDash([]);
    if(P.sec<=P.flight+1){c.translate(x+P.x*k,y+P.y*k);c.rotate(P.ang);c.fillStyle='#fff';c.strokeStyle='#000';c.lineWidth=.8;
      c.beginPath();c.moveTo(7,0);c.lineTo(-4,5);c.lineTo(-2,0);c.lineTo(-4,-5);c.closePath();c.fill();c.stroke()}
    c.restore();
  },

  /* ---------- HUD ---------- */
  hud(){
    const bj=$('bJump'),dm=$('dropMsg'),P=this.plane,on=state==='play'&&player&&player.alive&&!!player.air;
    const sj=on&&player.air==='plane',h=this._hud;
    if(h.j!==sj){h.j=sj;bj.hidden=!sj}
    let msg='';
    if(on){msg=player.air==='plane'?T('Jump from the plane! The route ends in {0} s',Math.max(0,Math.ceil(P?P.flight-P.sec:0))):T('Parachute · steer with the joystick · {0}s',Math.max(0,player.at).toFixed(1))}
    if(h.m!==msg){h.m=msg;dm.textContent=msg;dm.hidden=!msg}
  }
};
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k===' '||k==='j')Drop.jumpPlayer()});
