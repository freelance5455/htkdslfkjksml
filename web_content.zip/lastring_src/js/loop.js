'use strict';
/* ---------- match setup ---------- */
function startMatch(){
  Loader.show(MAPS[prof.map].n+' · '+MAPS[prof.map].loc);Loader.set(55,T('Building the map…'));
  // fullscreen / rotate ke resize settle hone do (usi dauran bada world banana phone par atak jata tha), max 3.5 s
  const t0=performance.now();
  const go=()=>{
    if(performance.now()-t0<1000||(performance.now()-lastResizeT<400&&performance.now()-t0<3500)){setTimeout(go,100);return}
    try{startMatchNow();if(typeof resize==='function')resize()}catch(e){showErr(e);state='lobby';$('lobby').hidden=false}
    Loader.set(100,T('Ready!'));setTimeout(()=>Loader.hide(),350);
  };
  setTimeout(go,1000);
}
let lastResizeT=0;addEventListener('resize',()=>{lastResizeT=performance.now()});
function showErr(e){const d=$('err');d.hidden=false;d.textContent=T('Error: {0} — set Graphics to "Low" in Settings and try again',e&&e.message||e)}
let stgOk=false;
function mark(s){try{s?localStorage.setItem('lr_stage',s):localStorage.removeItem('lr_stage')}catch(e){}}
function startMatchNow(){
  stgOk=false;mark('map');
  mode=MODES.find(m=>m.id===prof.mode)||MODES[0];
  MatchNet.seeded(()=>genWorld(prof.map));mark('players');
  players=[];bullets=[];parts=[];hurt=0;time=0;specT=null;shake=0;wxInit();
  FX.reset();Combo.reset();GameMode.reset();Scope.reset();set.autopick=true;if(typeof applyTouchUI==='function')applyTouchUI();   // game start par auto-pickup hamesha ON (khiladi baad mein band kar sakta hai)
  const nm=NAMES.slice().sort(()=>Math.random()-.5);
  const myOut=myLook();
  for(let i=0;i<mode.cnt;i++){
    const team=Math.floor(i/mode.team);
    const p=mkP(i===0?(prof.name||'Player'):nm[i%nm.length],i!==0,team,i===0?myOut:botLook());
    players.push(p);
  }
  player=players[0];resetAbil();
  AutoAimController.reset();FireButtonDrag.reset();FireHold.reset();WeaponController.reset();
  const sk=ITEMS[prof.eq.w];player.skin=sk&&sk.col||null;
  const gs=ITEMS[prof.eq.g];player.gskin=gs&&gs.col||'#8fd8ff';
  const pet=ITEMS[prof.eq.p];if(pet){player.pet=pet.kind;player.perk=pet.perk}
  if(player.perk==='arm')player.armor=40;
  if(player.perk==='ammo')player.res+=60;
  const leader={};
  for(const p of players){
    let x,y;
    if(leader[p.team]){const l=leader[p.team],a=rnd(0,TAU);x=l.x+Math.cos(a)*rnd(40,90);y=l.y+Math.sin(a)*rnd(40,90)}
    else{[x,y]=spawnPos();leader[p.team]=p}
    p.x=x;p.y=y;p.lx=x;p.ly=y;fix(p);
  }
  aliveN=players.length;
  z={cx:MAP/2+rnd(-.08,.08)*MAP,cy:MAP/2+rnd(-.08,.08)*MAP,r:MAP*.74,i:0,k:Math.pow(MAP/3000,.6)*mode.k};
  startWait();
  if(mode.rules)GameMode.setup();                      // TDM / KOTH
  if(MatchNet.host)MatchNet.hostSetup();               // online: dost real players ban jaate hain
  Drop.begin();                                        // vimaan se kudna (sirf battle royale)
  cam.x=player.x;cam.y=player.y-18;
  $('feed').innerHTML='';
  state='play';
  closePanel();$('lobby').hidden=true;$('end').hidden=true;$('pause').hidden=true;$('hud').hidden=false;
  applyTouchUI();
  toast(mp.n+' · '+mp.loc);mark('play');
}
function spawnPos(){
  for(let t=0;t<80;t++){
    const x=rnd(160,MAP-160),y=rnd(160,MAP-160);
    if(blocked(x,y)||lakes.some(l=>Math.hypot(x-l.x,y-l.y)<l.r+40)||Hydro.wet(x,y))continue;
    if(players.some(p=>p.x&&Math.hypot(p.x-x,p.y-y)<190))continue;
    return[x,y];
  }
  return[MAP/2,MAP/2];
}
function startWait(){
  const ph=PHT[z.i],R=ph.f*MAP;z.stage='wait';z.t=ph.w*z.k;
  const a=rnd(0,TAU),d=rnd(0,Math.max(0,z.r-R));
  z.tx=clamp(z.cx+Math.cos(a)*d,R,MAP-R);z.ty=clamp(z.cy+Math.sin(a)*d,R,MAP-R);z.tr=R;
}
function updZone(dt){
  if(z.stage==='done')return;
  z.t-=dt;
  if(z.stage==='wait'){
    if(z.t<=0){z.stage='shrink';z.t=PHT[z.i].s*z.k;z.s0={cx:z.cx,cy:z.cy,r:z.r}}
  }else{
    const f=1-Math.max(0,z.t/(PHT[z.i].s*z.k));
    z.cx=lerp(z.s0.cx,z.tx,f);z.cy=lerp(z.s0.cy,z.ty,f);z.r=lerp(z.s0.r,z.tr,f);
    if(z.t<=0){z.i++;if(z.i<PHT.length)startWait();else z.stage='done'}
  }
}
function endMatch(place){
  if(state!=='play')return;
  state='done';
  if(MatchNet.host){MatchNet.ended=true;Net.relay({k:'end',place})}
  const win=place===1,k=player.kills;
  if(win)FX.slowmo();                                  // winning kill: slow-mo + zoom
  Bus.emit('matchEnd',{win,mode:mode.id,kills:k,place});
  const gold=20+k*15+(win?150:place<=5?60:place<=10?30:0);
  const gems=win?5:0,xp=30+k*10+(win?60:0)+(place<=5?20:0);
  prof.gold+=gold;prof.gems+=gems;prof.xp+=xp;prof.st.m++;prof.st.k+=k;if(win)prof.st.w++;
  save();
  if(win)snd('win');
  setTimeout(()=>showEnd(place,{gold,gems,xp,k}),1300);
}

/* ---------- input ---------- */
const mouse={x:0,y:0,down:false,active:false};
const stk={mv:{id:null,ox:0,oy:0,x:0,y:0,px:0,py:0},aim:{id:null,lx:0,ly:0}};
let VW=0,VH=0,DPR=1,S=1;
const SR=56;
addEventListener('keydown',e=>{
  const k=e.key.toLowerCase();keys[k]=true;
  if(state==='play'&&player.alive){
    if(k==='r')startReload(player);else if(k==='q'||k==='tab')swapW(player);else if(k==='g')throwN(player,'grenade');
    else if(k==='z')Scope.toggle();else if(k==='t')throwN(player,'smoke');else if(k==='c')placeGloo(player);else if(k==='h')startHeal(player,'bandage');else if(k==='j')startHeal(player,'medkit');
    if(k==='tab'||k===' ')e.preventDefault();
  }
  if(k==='escape'||k==='p'){if(state==='play')pauseGame();else if(state==='pause')resumeGame()}
});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false});
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;mouse.down=false});
function rel(e){const r=$('c').getBoundingClientRect();if(document.documentElement.classList.contains('rot'))return[e.clientY-r.top,r.right-e.clientX];return[e.clientX-r.left,e.clientY-r.top]}
function turnBy(dx,dy,sens){const a=player.ang;player.ang+=(dx*-Math.sin(a)+dy*Math.cos(a))*.011*sens}
function bindInput(){
  const cv=$('c');
  cv.addEventListener('pointerdown',e=>{
    if(state!=='play')return;
    const[x,y]=rel(e);
    if(e.pointerType==='mouse'){if(e.button===2)Scope.toggle();if(e.button===0){mouse.down=true}mouse.active=true;mouse.x=x;mouse.y=y;return}
    const jb=joyBase();
    if(x<VW*.45||(!set.float&&Math.hypot(x-jb[0],y-jb[1])<SR*joyK()*1.8)){
      if(stk.mv.id!==null)return;
      const fx=set.float?x:jb[0],fy=set.float?y:jb[1];
      Object.assign(stk.mv,{id:e.pointerId,ox:fx,oy:fy,px:x,py:y,x:0,y:0});
      if(!set.float){const dx=x-fx,dy=y-fy,d=Math.hypot(dx,dy)||1,c=Math.min(d,SR*joyK());stk.mv.x=dx/d*c/(SR*joyK());stk.mv.y=dy/d*c/(SR*joyK());stk.mv.px=fx+dx/d*c;stk.mv.py=fy+dy/d*c}
    }else{
      if(stk.aim.id!==null)return;
      stk.aim.id=e.pointerId;stk.aim.lx=x;stk.aim.ly=y;
    }
    try{cv.setPointerCapture(e.pointerId)}catch(_){}
  });
  cv.addEventListener('pointermove',e=>{
    const[x,y]=rel(e);
    if(e.pointerType==='mouse'){mouse.x=x;mouse.y=y;mouse.active=true;return}
    const s=stk.mv;
    if(s.id===e.pointerId){
      const R=SR*joyK();let dx=x-s.ox,dy=y-s.oy;const d=Math.hypot(dx,dy);
      if(d>R){dx*=R/d;dy*=R/d}
      s.x=dx/R;s.y=dy/R;s.px=s.ox+dx;s.py=s.oy+dy;
    }
    if(stk.aim.id===e.pointerId&&state==='play'&&player.alive){turnBy(x-stk.aim.lx,y-stk.aim.ly,set.aim);stk.aim.lx=x;stk.aim.ly=y}
  });
  const up=e=>{
    if(e.pointerType==='mouse'){mouse.down=false;return}
    if(stk.mv.id===e.pointerId){stk.mv.id=null;stk.mv.x=0;stk.mv.y=0}
    if(stk.aim.id===e.pointerId)stk.aim.id=null;
  };
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  cv.addEventListener('contextmenu',e=>e.preventDefault());
  // touch buttons
  FireButtonDrag.init($('bFire'));            // firebtn.js: aim stick (drag = nishana)
  $('bJump').addEventListener('pointerdown',e=>{e.preventDefault();ac();Drop.jumpPlayer()});
  FireHold.init($('bShoot'));                 // firebtn.js: alag FIRE button (dabao = fire)
  $('bScope').addEventListener('pointerdown',e=>{e.preventDefault();ac();Scope.toggle()});
  $('bAP').addEventListener('pointerdown',e=>{e.preventDefault();ac();set.autopick=!set.autopick;save();toast(set.autopick?T('Auto-pickup ON'):T('Auto-pickup OFF — use the Pick up button'));applyTouchUI()});
  const act=(id,fn)=>{$(id).addEventListener('pointerdown',e=>{e.preventDefault();ac();if(state==='play'&&player.alive)fn(player)})};
  act('bRel',startReload);act('bSwap',swapW);act('bGren',p=>throwN(p,'grenade'));act('bGloo',placeGloo);
  act('bSkill',p=>useAbility(p));act('bEmo',()=>toggleEmo());act('bBand',p=>startHeal(p,'bandage'));act('bMed',p=>startHeal(p,'medkit'));act('bSmk',p=>throwN(p,'smoke'));
  $('bPause').addEventListener('click',()=>{if(state==='play')pauseGame()});
  // desktop chips
  for(const [id,fn] of [['cBand',p=>startHeal(p,'bandage')],['cMed',p=>startHeal(p,'medkit')],['cGren',p=>throwN(p,'grenade')],['cSmk',p=>throwN(p,'smoke')],['cGloo',placeGloo]])
    $(id).addEventListener('click',()=>{if(state==='play'&&player.alive)fn(player)});
}
function toggleAutoFire(){
  if(state!=='play')return;
  set.autoFire=!set.autoFire;save();toast(set.autoFire?T('Auto-fire ON'):T('Auto-fire OFF'));
}
// settings (set.*) -> controllers ki cfg. Advanced tuning seedha controllers ki cfg mein hai.
function applyAimSettings(){
  const A=AutoAimController.cfg,F=FireButtonDrag.cfg;
  A.assistWhileAiming=set.dragAssist!==false;A.enabled=!!set.assist;A.autoFire=false;A.radius=set.aimRadius||400;
  F.fires=set.sepFire===false;                          // alag fire button ON ho to aim stick fire nahi karta
  F.fireMode=set.dragFire==='hold'?'hold':'release';
  F.holdContinueSec=set.contFire?1:0;F.releaseFireSec=set.contFire?1:.35;
}
function pauseGame(){if(MatchNet.active){$('pause').hidden=false;return}state='pause';$('pause').hidden=false}   // online me game rukta nahi
function resumeGame(){if(state==='pause')state='play';$('pause').hidden=true;closePanel()}
function touchUIOn(){return set.show==='on'||(set.show==='auto'&&isTouch)}
function applyTouchUI(){
  const on=touchUIOn();
  $('tb').hidden=!on;$('chips').hidden=on;
  const sf=set.sepFire!==false;$('bShoot').hidden=!sf;$('bFire').classList.toggle('aimstick',sf);$('bAP').classList.toggle('on',!!set.autopick);
  document.documentElement.style.setProperty('--bs',set.btn);applyLayout();
}

/* ---------- update ---------- */
function update(dt){
  if(state!=='play')Hydro.mute();
  if(state!=='play'&&state!=='done')return;
  Drop.update(dt);                                      // vimaan / parachute (drop.js)
  if(state==='play')Hydro.update(dt);                   // paani: dhaara, mist, awaazein (hydro*.js)
  if(state==='play'&&!Drop.hold)time+=dt;
  if(!stgOk&&time>3){stgOk=true;mark('')}
  updZone(Drop.hold?0:dt);
  if(state==='play'){WeaponController.update(dt);Combo.update(dt);GameMode.update(dt)}   // recoil heat, combo meter, mode rules
  const dmgZ=PHT[Math.min(z.i,PHT.length-1)].dmg;
  if(player.alive&&state==='play'&&!player.air){
    let mx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),my=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);
    mx+=stk.mv.x;my+=stk.mv.y;
    const m=Math.hypot(mx,my);if(m>1){mx/=m;my/=m}
    /* ---- aim + fire: FireButtonDrag (input) -> AutoAimController (target/rotate) -> WeaponController (shot) ---- */
    applyAimSettings();
    let fire=false;
    const mouseAim=mouse.active&&!isTouch;
    if(mouseAim){
      const wx=cam.x+(mouse.x-VW/2)/S,wy=cam.y+(mouse.y-VH/2)/S+(player.fl|0)*FH;
      player.ang=Math.atan2(wy-(player.y-26),wx-player.x);fire=mouse.down||keys[' '];
    }
    FireButtonDrag.update(dt,player);                       // drag ho raha ho to gun yahin ghoomti hai
    const sepF=set.sepFire!==false;
    FireHold.update(dt);
    const it=sepF?(FireHold.on?((FireButtonDrag.manual||stk.aim.id!==null)?2:1):0)   // alag FIRE: stick se nishana, button se fire
                 :FireButtonDrag.intent();                  // 0 none | 1 tap/hold (assisted) | 2 manual
    const aiming=FireButtonDrag.manual?'stick':(stk.aim.id!==null?'swipe':false);
    const manual=mouseAim||(set.dragAssist===false&&aiming);   // dragAssist OFF = purana: drag par auto-aim band. Warna sirf mouse = poora manual; // sirf mouse = poora manual. Stick drag / swipe ke dauraan auto-aim soft assist banke chalta rehta hai
    const AA=AutoAimController,autoOn=AA.cfg.enabled&&AA.cfg.autoFire&&!manual;
    AA.update(dt,player,manual,it===1||autoOn,aiming);
    if(it===2)fire=true;                                    // manual: jis disha mein gun hai wahin
    else if(it===1)fire=AA.target?AA.aimed(player):true;    // lock mila to gun ghoom kar seedhi ho tab; warna facing dir mein
    else if(autoOn&&AA.target&&AA.aimed(player))fire=true;  // auto-fire: radius mein enemy aate hi
    if(m>.2&&!mouse.active&&stk.aim.id===null&&!FireButtonDrag.pressed&&!isTouch)player.ang=Math.atan2(my,mx);
    const sp=175*(player.perk==='spd'?1.08:1)*(inWater(player)?.55:1)*(player.heal?.55:1);
    moveE(player,mx*sp,my*sp,dt);player.mv=clamp(Math.hypot(player.vx,player.vy)/150,0,1);Hydro.entity(player,dt);
    if(fire&&WeaponController.fire(player))FireButtonDrag.consumeShot();
  }
  for(const p of players){
    if(MatchNet.client){MatchNet.cp(p,dt);continue}          // online guest: sirf visual / interpolation
    if(!p.alive||p.air)continue;
    if(p.dprot>0)p.dprot-=dt;
    p.cd-=dt;p.flash-=dt;p.hitT-=dt;p.throwCd-=dt;p.glCd-=dt;p.wt+=dt*(.3+p.mv);
    if(p.rl>0){p.rl-=dt;if(p.rl<=0){p.rl=0;finishReload(p)}}
    updHeal(p,dt);if(!p.remote)updStairs(p);
    if(p.perk==='regen'&&time-p.lastHit>5&&p.hp<MAXHP)p.hp=Math.min(MAXHP,p.hp+1.2*HPM*dt);
    if(p.bot&&state==='play')botAI(p,dt);
    if(p!==player&&!p.remote)Hydro.entity(p,dt);
    p.pk-=dt;if((p===player?set.autopick:(p.remote?p.autopick!==false:true))&&p.pk<=0){p.pk=.12;pickups(p)}
    if(Math.hypot(p.x-z.cx,p.y-z.cy)>z.r){p.hp-=dmgZ*dt;if(p===player)hurt=Math.max(hurt,.25);if(p.hp<=0)kill(p,null)}
  }
  if(!MatchNet.client)updAbilities(dt);
  if(MatchNet.client)MatchNet.moveBullets(dt);
  else for(let i=bullets.length-1;i>=0;i--){
    const b=bullets[i],step=b.sp*dt,n=Math.max(1,Math.ceil(step/7)),sx=b.vx*dt/n,sy=b.vy*dt/n,sl=step/n;
    let dead=false;
    for(let s=0;s<n&&!dead;s++){
      b.x+=sx;b.y+=sy;b.l-=sl;
      if(b.l<=0){dead=true;break}
      if(shieldHit(b)){dead=true;break}
      const gw=hitDyn(b.x,b.y,b.fl);
      if(gw){damageGloo(glooW.indexOf(gw),b.d);spark(b.x,b.y,gw.col,3);Spat.impact(b.x,b.y);dead=true;break}
      if(blocked(b.x,b.y,b.fl)){spark(b.x,b.y,'#d6d0b8',4);Spat.impact(b.x,b.y);dead=true;break}
      for(const p of players){
        if(!p.alive||p.air||p.team===b.o.team||(p.fl|0)!==(b.fl|0))continue;
        const dx=p.x-b.x,dy=p.y-b.y,rr2=p.r+2;
        if(dx*dx+dy*dy<rr2*rr2){
          const hs=Math.abs(dx*b.vy-dy*b.vx)/b.sp<p.r*.35;   // goli ki line centre ke kitni paas se guzri = headshot (precision hit)
          spark(b.x,b.y,'#ff5d6c',5);hurtP(p,b.d,b.o,hs);dead=true;break}
      }
    }
    if(dead){bullets[i]=bullets[bullets.length-1];bullets.pop()}
  }
  if(!MatchNet.client){updNades(dt);updGloo(dt)}
  for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.l<=0){parts[i]=parts[parts.length-1];parts.pop()}}
  hurt=Math.max(0,hurt-dt);shake=Math.max(0,shake-dt*2.5);
  let f=player;
  if(!player.alive){
    if(!specT||!specT.alive)specT=players.find(p=>p.alive&&p.team===player.team)||players.find(p=>p.alive)||player;
    f=specT;
  }
  if(MatchNet.host)MatchNet.hostTick(dt);else if(MatchNet.client)MatchNet.clientTick(dt);
  cam.x+=(f.x+Scope.peekX(f)-cam.x)*Math.min(1,dt*9);cam.y+=(f.y+Scope.peekY(f)-18-(f.fl|0)*FH-cam.y)*Math.min(1,dt*9);
}
