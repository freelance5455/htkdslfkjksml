'use strict';
/* =====================================================================
   modes.js — GameMode: Team Deathmatch (2v2 / 4v4, pehle 15 kill)
   (King of the Hill isi file mein phase 2 mein judega)
   ---------------------------------------------------------------------
   Battle-royale ke liye kuch nahi badla: mode.rules undefined = purana BR flow.
   mode.rules = 'tdm' | 'koth'  => zone band, loot band, sab ke paas loadout,
   maut par 3 sec baad respawn, kill/death/assist ginti, end par scoreboard.
   ===================================================================== */
const LOADOUT=['ranger','hornet','swift','falcon','pump','auto12','dmr','revolver'];

const GameMode={
  cfg:{respawnSec:3,spawnProtect:1.5,assistWindow:8},
  R:null,score:[0,0],over:false,bases:[],
  get on(){return !!(mode&&mode.rules)},

  reset(){this.R=null;this.over=false;this.score=[0,0];this.bases=[];const c=$('end').firstElementChild;if(c)c.style.width=''},

  // (x,y) ke aas-paas khuli jagah
  open(x,y,R){
    for(let t=0;t<60;t++){
      const a=rnd(0,TAU),d=rnd(0,R),px=clamp(x+Math.cos(a)*d,160,MAP-160),py=clamp(y+Math.sin(a)*d,160,MAP-160);
      if(blocked(px,py,0)||lakes.some(l=>Math.hypot(px-l.x,py-l.y)<l.r+40)||Hydro.wet(px,py))continue;
      return[px,py];
    }
    return[clamp(x,160,MAP-160),clamp(y,160,MAP-160)];
  },

  setup(){
    this.R=mode.rules;this.over=false;this.score=[0,0];
    z={cx:MAP/2,cy:MAP/2,r:MAP*3,tx:MAP/2,ty:MAP/2,tr:MAP*3,i:PHT.length-1,k:1,stage:'done',t:0,s0:{cx:MAP/2,cy:MAP/2,r:MAP*3}};
    loot.length=0;
    const cy=MAP*(.4+Math.random()*.2);
    const gap=mode.cnt<=4?.3:.18;                                     // 2v2 mein bases paas-paas
    this.bases=[this.open(MAP*gap,cy,350),this.open(MAP*(1-gap),cy,350)];
    for(const p of players){p.deaths=0;p.assists=0;p.kills=0;p.respT=0;p.prot=0;p.hitBy=new Map();this.equip(p);this.place(p,true)}
    aliveN=players.length;time=8;                                    // bots time>7 ke baad hi fire karte hain
    if(this.R==='koth'&&this.initHill)this.initHill();
  },

  equip(p){
    const g=p===player?'ranger':pick(LOADOUT);
    p.sl=[{id:g,mag:WP[g].mag},{id:'pistol',mag:12}];p.cur=0;p.res=240;
    p.inv={bandage:2,medkit:0,grenade:1,smoke:0,gloo:1};
    p.hp=MAXHP;p.armor=0;p.cd=0;p.rl=0;p.rls=null;p.heal=null;
  },

  // team-base ke paas jagah; respawn par dushman se sabse door wali chunte hain
  place(p,first){
    const b=this.bases[p.team%2];let best=null,bs=-1;
    for(let i=0,n=first?1:10;i<n;i++){
      const q=this.open(b[0],b[1],first?260:520);
      let m=1e9;if(!first)for(const e of players)if(e.alive&&e.team!==p.team)m=Math.min(m,Math.hypot(e.x-q[0],e.y-q[1]));
      if(m>bs){bs=m;best=q}
    }
    p.x=best[0];p.y=best[1];p.lx=p.x;p.ly=p.y;p.fl=0;p.vx=p.vy=0;fix(p);
  },

  respawn(p){
    p.alive=true;this.equip(p);this.place(p,false);aliveN++;
    p.prot=this.cfg.spawnProtect;p.camo=0;p.shield=null;p.dash=null;p.mq=null;p.slowT=0;p.bleedT=0;
    p.tgt=null;p.wp=null;p.lastHit=-9;
    if(p===player){specT=null;cam.x=p.x;cam.y=p.y-18;toast(T('Respawn!'));snd('respawn');Voice.say('respawn')}
    Bus.emit('respawn',p);
  },

  // TDM/KOTH mein bot ka agla target: KOTH mein hill, warna sabse nazdeek zinda dushman
  botGoal(b){
    if(this.R==='koth'&&this.hill&&Math.random()<.85){
      b.wp=[this.hill.x+rnd(-1,1)*this.hill.r*.6,this.hill.y+rnd(-1,1)*this.hill.r*.6];b.wpT=rnd(4,8);return;
    }
    let best=null,bd=1e9;
    for(const e of players)if(e.alive&&e.team!==b.team){const d=Math.hypot(e.x-b.x,e.y-b.y);if(d<bd){bd=d;best=e}}
    if(best){b.wp=[best.x+rnd(-90,90),best.y+rnd(-90,90)];b.wpT=rnd(3,6)}
  },

  update(dt){
    if(!this.on||this.over)return;
    for(const p of players){
      if(p.prot>0)p.prot-=dt;
      if(!p.alive&&p.respT>0){p.respT-=dt;if(p.respT<=0)this.respawn(p)}
    }
    if(this.R==='koth'&&this.updHill)this.updHill(dt);
  },

  // kill() se (rules mode mein loot-drop / BR end-check ki jagah)
  onDeath(v,src){
    if(this.over)return;
    v.deaths=(v.deaths|0)+1;v.respT=this.cfg.respawnSec;
    if(v.hitBy){                                                      // assists: killer ke alawa jisne haal hi mein damage kiya
      for(const [a,tm] of v.hitBy)if(a!==src&&a!==v&&a.team!==v.team&&time-tm<this.cfg.assistWindow)a.assists=(a.assists|0)+1;
      v.hitBy.clear();
    }
    if(this.R==='tdm'&&src&&src!==v&&src.team!==v.team){
      this.score[src.team]++;
      if(this.score[src.team]>=mode.target)this.finish(src.team,true);
    }
  },

  finish(wt,byKill){
    if(this.over)return;
    this.over=true;state='done';
    if(byKill)FX.slowmo();                                            // match-winning kill: slow-mo + zoom
    const win=wt===player.team,k=player.kills;
    const r={gold:30+k*12+(win?120:20),gems:win?3:0,xp:25+k*8+(win?50:10),k};
    prof.gold+=r.gold;prof.gems+=r.gems;prof.xp+=r.xp;prof.st.m++;prof.st.k+=k;if(win)prof.st.w++;save();
    Bus.emit('matchEnd',{win,mode:mode.id,kills:k,deaths:player.deaths|0});
    if(win){snd('win');Voice.say('win')}
    setTimeout(()=>this.showEnd(wt,r),1300);
  },

  showEnd(wt,r){
    const win=wt===player.team,me=player.team,rs=$('rs');
    $('rt').textContent=win?T('Your team won!'):T('Your team lost');
    $('rt').style.color=win?'var(--accent)':'var(--fg)';
    $('end').firstElementChild.style.width='min(460px,100%)';
    rs.innerHTML='';
    rs.append(h('div',{class:'dim'},this.scoreLine()));
    for(const tm of [me,1-me]){
      const rows=players.filter(p=>p.team===tm).sort((a,b)=>b.kills-a.kills||(a.deaths|0)-(b.deaths|0));
      rs.append(h('div',{class:'sbh',style:'color:'+(tm===me?'var(--armor)':'var(--danger)')},tm===me?T('Your team'):T('Enemy team')));
      rs.append(h('table',{class:'sbt'},
        h('tr',null,h('th',null,T('Player')),h('th',null,'Kills'),h('th',null,'Deaths'),h('th',null,'Assists')),
        rows.map(p=>h('tr',{class:p===player?'me':''},h('td',null,p.name),h('td',null,p.kills),h('td',null,p.deaths|0),h('td',null,p.assists|0)))));
    }
    rs.append(h('div',null,T('Reward:')+' ',h('b',null,T('+{0} Gold',r.gold)),r.gems?h('b',null,' · '+T('+{0} Diamonds',r.gems)):'',h('b',null,' · +'+r.xp+' XP')));
    $('end').hidden=false;
  },

  scoreLine(){
    if(this.R==='tdm')return T('Final score {0} – {1}',this.score[player.team],this.score[1-player.team]);
    return this.hillLine?this.hillLine():'';
  },

  hudText(){
    if(this.R==='tdm'){
      const me=player.team,a=this.score[me],b=this.score[1-me];
      if(!player.alive)return T('Respawn {0} · {1}–{2}',Math.ceil(Math.max(0,player.respT)),a,b);
      return T('TDM · You {0} – {1} Enemy · first to {2}',a,b,mode.target);
    }
    return this.hillText?this.hillText():'';
  },

  /* ---------- King of the Hill ---------- */
  hill:null,
  initHill(){
    const c=this.open(MAP/2,MAP/2,250);
    this.hill={x:c[0],y:c[1],r:150,owner:-1,contested:false,acc:[0,0]};
  },
  // zone mein akeli team = 1 point/sec. Dono team andar = contested, capture ruk jaata hai
  updHill(dt){
    const h=this.hill,n=[0,0];
    for(const p of players)if(p.alive&&(p.fl|0)===0&&Math.hypot(p.x-h.x,p.y-h.y)<h.r)n[p.team&1]++;
    const was=h.contested;
    h.contested=n[0]>0&&n[1]>0;
    h.owner=h.contested?-1:n[0]>0?0:n[1]>0?1:-1;
    if(h.contested&&!was&&player.alive&&Math.hypot(player.x-h.x,player.y-h.y)<h.r+60)toast(T('Capture paused — an enemy is in the zone too!'));
    if(h.owner>=0){
      h.acc[h.owner]+=dt;
      while(h.acc[h.owner]>=1){
        h.acc[h.owner]-=1;this.score[h.owner]++;
        if(this.score[h.owner]>=mode.target){this.finish(h.owner,false);return}
      }
    }
  },
  hillColor(){
    const h=this.hill,me=player.team&1;
    return h.contested?'255,211,107':h.owner===-1?'255,255,255':h.owner===me?'111,183,255':'255,93,108';
  },
  drawHill(c){
    const h=this.hill;if(!h)return;
    const col=this.hillColor(),a=.14+.06*Math.sin(time*4);
    c.save();
    c.fillStyle='rgba('+col+','+a+')';c.beginPath();c.arc(h.x,h.y,h.r,0,TAU);c.fill();
    c.strokeStyle='rgba('+col+',.9)';c.lineWidth=5;c.setLineDash(h.contested?[14,10]:[]);c.lineDashOffset=-time*30;
    c.beginPath();c.arc(h.x,h.y,h.r,0,TAU);c.stroke();c.setLineDash([]);
    if(h.owner>=0){                                       // point-progress ring
      c.lineWidth=7;c.strokeStyle='rgba('+col+',.95)';c.beginPath();
      c.arc(h.x,h.y,h.r-10,-Math.PI/2,-Math.PI/2+TAU*h.acc[h.owner]);c.stroke();
    }
    c.textAlign='center';c.font='700 26px Teko,Hind,'+I18N.fb+'system-ui,sans-serif';c.lineWidth=4;c.strokeStyle='rgba(0,0,0,.7)';
    const t=h.contested?'CONTESTED':'HILL';c.strokeText(t,h.x,h.y-6);c.fillStyle='rgba('+col+',1)';c.fillText(t,h.x,h.y-6);
    c.restore();
  },
  miniHill(c,x,y,k){
    const h=this.hill;if(!h)return;
    c.strokeStyle='rgba('+this.hillColor()+',1)';c.lineWidth=2;c.beginPath();c.arc(x+h.x*k,y+h.y*k,Math.max(3,h.r*k),0,TAU);c.stroke();
  },
  hillText(){
    const h=this.hill,me=player.team&1,a=this.score[me],b=this.score[1-me];
    if(!player.alive)return T('Respawn {0} · {1}–{2}',Math.ceil(Math.max(0,player.respT)),a,b);
    const st=h.contested?T('Capture paused (contested)'):h.owner===-1?T('Zone empty'):h.owner===me?T('Zone is yours +1/s'):T('Zone belongs to the enemy');
    return T('KOTH · You {0} – {1} Enemy · first to {2} · {3}',a,b,mode.target,st);
  },
  hillLine(){const me=player.team&1;return T('Final score {0} – {1}',this.score[me],this.score[1-me])},

  drawWorld(c){if(this.on&&this.drawHill)this.drawHill(c)},
  drawMini(c,x,y,k){if(this.on&&this.miniHill)this.miniHill(c,x,y,k)}
};
