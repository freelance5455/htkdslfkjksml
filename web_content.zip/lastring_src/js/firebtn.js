'use strict';
/* =====================================================================
   FireButtonDrag
   ---------------------------------------------------------------------
   Bottom-right ka fire button (joystick jaisa):
     Began  -> press shuru. Finger `deadzonePx` se kam hile = TAP / HOLD  (auto-aim assisted fire)
     Moved  -> `deadzonePx` se zyada hile = DRAG  (manual aim, auto-aim override)
     Ended  -> drag tha: fireMode 'release' => chhodte hi fire, 'hold' => fire ruk jaye
               (holdContinueSec / releaseFireSec se jaari bhi rakh sakte ho)
   Aim direction = drag vector. Drag jitni lambi, rotation utni tez
   (minTurnDegPerSec -> maxTurnDegPerSec, `curve` se shape).
   Button ke andar chhota knob (.fk) drag direction dikhata hai.

   loop.js har frame: FireButtonDrag.update(dt,player) phir FireButtonDrag.intent() padhta hai.
   intent():  0 = fire nahi  |  1 = assisted fire (tap/hold, lock ka intezaar)  |  2 = manual fire (abhi, facing dir mein)
   ===================================================================== */
const FireButtonDrag={
  /* ---------- tuning (public) ---------- */
  cfg:{
    deadzonePx:10,         // itna hilne tak tap maana jaayega
    maxDragPx:70,          // is drag distance par rotation speed max (96px button ke hisaab se, size ke saath scale hota hai)
    sensitivity:1,         // global multiplier  (settings ka "फायर बटन सेंसिटिविटी" bhi isse multiply hota hai)
    mode:'direction',      // 'direction' = drag vector hi aim angle | 'delta' = purana swipe-rotate
    origin:'touchStart',   // drag vector kahan se naapna: 'touchStart' | 'center' (button ka centre)
    minTurnDegPerSec:120,  // deadzone ke bilkul bahar rotation speed
    maxTurnDegPerSec:900,  // maxDragPx par rotation speed
    curve:1.4,             // >1 = chhote drag par fine control, <1 = jaldi tez
    fireMode:'release',    // 'release' = drag karke chhodne par fire | 'hold' = drag ke dauraan fire
    releaseFireSec:.35,    // 'release' mode: chhodne ke baad itni der tak fire window (kam se kam 1 shot)
    holdContinueSec:0,     // 'hold' mode: chhodne ke baad itni der fire jaari (0 = turant ruk jaye)
    shotBuffer:.35,        // tap bahut chhota ho to bhi 1 shot guarantee (input buffer, sec)
    fires:false,           // false = SIRF nishana (alag FIRE button fire karta hai) | true = purana mode (stick se fire bhi)
    knobTravel:.32         // knob button-width ka itna hissa tak khisak sakta hai (knob button ke andar hi rahe)
  },

  /* ---------- runtime state ---------- */
  el:null,k:null,fa:null,id:null,
  pressed:false,dragging:false,
  sx:0,sy:0,ox:0,oy:0,cx:0,cy:0,lx:0,ly:0,   // touch-start, vector origin, current, last (button-local px)
  mag:0,scale:1,travel:0,shots:0,
  relT:0,shotBuf:0,shotKind:1,

  get manual(){return this.pressed&&this.dragging},

  init(el){
    this.el=el;
    const k=document.createElement('i');k.className='fk';el.appendChild(k);this.k=k;
    const fa=document.createElement('i');fa.className='fa';el.appendChild(fa);this.fa=fa;   // abhi ka nishana dikhane wala chhota tir
    el.addEventListener('pointerdown',e=>this.onBegan(e));
    el.addEventListener('pointermove',e=>this.onMoved(e));
    el.addEventListener('pointerup',e=>this.onEnded(e));
    el.addEventListener('pointercancel',e=>this.onEnded(e,true));
    // capture fail ho jaye to bhi finger uthte hi release pakdo
    addEventListener('pointerup',e=>this.onEnded(e));addEventListener('pointercancel',e=>this.onEnded(e,true));
    addEventListener('blur',()=>this.reset());
  },

  reset(){
    this.pressed=false;this.dragging=false;this.id=null;this.mag=0;this.relT=0;this.shotBuf=0;this.shots=0;
    if(this.el){this.el.classList.remove('press','drag');if(this.k)this.k.style.transform=''}
  },

  /* ---------- touch phases ---------- */
  onBegan(e){                                   // Touch Phase: Began
    e.preventDefault();ac();
    if(this.pressed)return;
    const el=this.el,p=relEl(el,e);
    this.id=e.pointerId;this.pressed=true;this.dragging=false;this.shots=0;
    this.relT=0;this.shotBuf=0;                 // naya press purani fire window cancel kare
    this.sx=this.cx=this.lx=p[0];this.sy=this.cy=this.ly=p[1];
    this.ox=this.cfg.origin==='center'?el.offsetWidth/2:p[0];
    this.oy=this.cfg.origin==='center'?el.offsetHeight/2:p[1];
    this.scale=Math.max(.3,el.offsetWidth/96);
    this.travel=el.offsetWidth*this.cfg.knobTravel;
    el.classList.add('press');
    try{el.setPointerCapture(e.pointerId)}catch(_){}
  },

  onMoved(e){                                   // Touch Phase: Moved
    if(!this.pressed||e.pointerId!==this.id)return;
    const p=relEl(this.el,e),c=this.cfg;
    this.cx=p[0];this.cy=p[1];
    if(!this.dragging&&Math.hypot(p[0]-this.sx,p[1]-this.sy)>=c.deadzonePx){
      this.dragging=true;this.el.classList.add('drag');
    }
    if(this.dragging&&c.mode==='delta'&&state==='play'&&player.alive)
      turnBy(p[0]-this.lx,p[1]-this.ly,c.sensitivity*set.fsens*1.3);
    this.lx=p[0];this.ly=p[1];
  },

  onEnded(e,cancelled){                         // Touch Phase: Ended / Canceled
    if(!this.pressed||e.pointerId!==this.id)return;
    const c=this.cfg;
    if(state==='play'&&!cancelled){
      if(this.dragging){
        if(c.fireMode==='release'){this.relT=c.releaseFireSec;this.shotBuf=c.shotBuffer;this.shotKind=2}
        else this.relT=c.holdContinueSec;
      }else if(this.shots===0){                 // chhota tap: kam se kam 1 assisted shot
        this.shotBuf=c.shotBuffer;this.shotKind=1;
      }
    }
    this.pressed=false;this.dragging=false;this.id=null;this.mag=0;
    this.el.classList.remove('press','drag');this.k.style.transform='';
  },

  /* ---------- per frame ---------- */
  update(dt,p){
    if(this.fa)this.fa.style.transform='rotate('+p.ang.toFixed(3)+'rad)';
    if(this.relT>0)this.relT-=dt;
    if(this.shotBuf>0)this.shotBuf-=dt;
    if(!this.pressed||!this.dragging){this.mag=0;return}
    const c=this.cfg,vx=this.cx-this.ox,vy=this.cy-this.oy,d=Math.hypot(vx,vy);
    const dz=c.deadzonePx,md=Math.max(dz+1,c.maxDragPx*this.scale);
    this.mag=clamp((d-dz)/(md-dz),0,1);
    // indicator: drag direction dikhao
    const kd=this.travel*clamp(d/md,0,1),ux=d>0?vx/d:0,uy=d>0?vy/d:0;
    this.k.style.transform=`translate(${(ux*kd).toFixed(1)}px,${(uy*kd).toFixed(1)}px)`;
    if(c.mode==='direction'&&p.alive&&this.mag>0){
      const dps=lerp(c.minTurnDegPerSec,c.maxTurnDegPerSec,Math.pow(this.mag,c.curve));
      const step=dps*Math.PI/180*c.sensitivity*set.fsens*dt;
      const va=Math.atan2(vy,vx);AutoAimController.ref=va;      // soft auto-aim: drag angle ko enemy ki taraf halka kheencho
      const AAc=AutoAimController,tg=AAc.assistAngle(p,va);
      if(AAc.target&&tg!==va){const k=1-Math.exp(-AAc.cfg.dragLerpSpeed*dt),cap=AAc.cfg.maxTurnDegPerSec*Math.PI/180*dt;p.ang+=clamp(angDiff(p.ang,tg)*k,-cap,cap)}   // lock hai: idle auto-aim jitni hi tezi se
      else p.ang+=clamp(angDiff(p.ang,tg),-step,step);
    }
  },

  intent(){
    if(!this.cfg.fires)return 0;                 // aim-only stick
    if(this.pressed)return this.dragging?(this.cfg.fireMode==='hold'?2:0):1;
    if(this.relT>0)return 2;
    if(this.shotBuf>0)return this.shotKind;
    return 0;
  },

  // WeaponController ne shot chalaya
  consumeShot(){this.shots++;this.shotBuf=0},

  /* World-space aim line (drag ke dauraan) */
  drawWorld(c,p){
    if(!this.pressed||!this.dragging||!p.alive)return;
    const L=curW(p).range*.55,x1=p.x+Math.cos(p.ang)*L,y1=p.y+Math.sin(p.ang)*L;
    const g=c.createLinearGradient(p.x,p.y,x1,y1);g.addColorStop(0,'rgba(255,255,255,.65)');g.addColorStop(1,'rgba(255,255,255,0)');
    c.save();c.strokeStyle=g;c.lineWidth=2;c.setLineDash([10,8]);
    c.beginPath();c.moveTo(p.x+Math.cos(p.ang)*22,p.y+Math.sin(p.ang)*22);c.lineTo(x1,y1);c.stroke();c.restore();
  }
};

/* =====================================================================
   FireHold — alag FIRE button
   dabaye rakho = fire (aim stick se nishana, nahi to auto-aim lock / facing dir). Chhota tap = kam se kam 1 shot.
   loop.js: FireHold.update(dt) ; FireHold.on  -> fire chahiye
   ===================================================================== */
const FireHold={
  cfg:{tapBuffer:.35},          // sec: bahut chhota tap bhi 1 shot de
  el:null,id:null,pressed:false,buf:0,
  get on(){return state==='play'&&(this.pressed||this.buf>0)},
  init(el){
    this.el=el;
    el.addEventListener('pointerdown',e=>{
      e.preventDefault();ac();
      if(this.pressed)return;
      this.id=e.pointerId;this.pressed=true;this.buf=this.cfg.tapBuffer;el.classList.add('press');
      try{el.setPointerCapture(e.pointerId)}catch(_){}
    });
    const up=e=>{if(!this.pressed||e.pointerId!==this.id)return;this.pressed=false;this.id=null;el.classList.remove('press')};
    el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
    addEventListener('pointerup',up);addEventListener('pointercancel',up);addEventListener('blur',()=>this.reset());
  },
  reset(){this.pressed=false;this.id=null;this.buf=0;if(this.el)this.el.classList.remove('press')},
  update(dt){if(this.buf>0)this.buf-=dt}
};

/* =====================================================================
   AimArrow — nishana kahan hai, ye hamesha dikhta hai (player ke aas-paas tir + halki line)
   Lock mila ho to tir laal ho jata hai. set.aimArrow se on/off.
   ===================================================================== */
const AimArrow={
  cfg:{dist:44,size:11,lineFrom:26,lineLen:120},
  drawWorld(c,p){
    if(set.aimArrow===false||!p.alive)return;
    const a=p.ang,ca=Math.cos(a),sa=Math.sin(a),cy=p.y-24;           // goli isi height se nikalti hai
    const lk=AutoAimController.target&&AutoAimController.target.alive;
    const col=lk?'255,93,108':'255,255,255';
    const L=this.cfg.lineLen,g=c.createLinearGradient(p.x+ca*this.cfg.lineFrom,cy+sa*this.cfg.lineFrom,p.x+ca*(this.cfg.lineFrom+L),cy+sa*(this.cfg.lineFrom+L));
    g.addColorStop(0,'rgba('+col+',.45)');g.addColorStop(1,'rgba('+col+',0)');
    c.save();
    c.strokeStyle=g;c.lineWidth=2;c.setLineDash([6,7]);c.beginPath();c.moveTo(p.x+ca*this.cfg.lineFrom,cy+sa*this.cfg.lineFrom);c.lineTo(p.x+ca*(this.cfg.lineFrom+L),cy+sa*(this.cfg.lineFrom+L));c.stroke();c.setLineDash([]);
    c.translate(p.x+ca*this.cfg.dist,cy+sa*this.cfg.dist);c.rotate(a);
    const s=this.cfg.size;
    c.beginPath();c.moveTo(s,0);c.lineTo(-s*.55,s*.8);c.lineTo(-s*.15,0);c.lineTo(-s*.55,-s*.8);c.closePath();
    c.fillStyle='rgba('+col+',.95)';c.strokeStyle='rgba(0,0,0,.65)';c.lineWidth=2;c.lineJoin='round';c.stroke();c.fill();
    c.restore();
  }
};
