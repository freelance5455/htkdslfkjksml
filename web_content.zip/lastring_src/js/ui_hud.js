'use strict';
/* ---------- in-match HUD ---------- */
const lastTxt={};
function setT(id,v){if(lastTxt[id]!==v){lastTxt[id]=v;$(id).textContent=v}}
function hudUpdate(){
  if(state==='lobby'||!player)return;
  setT('alive',aliveN);setT('kills',player.kills);
  $('hpb').style.width=clamp(player.hp/HPM,0,100)+'%';$('arb').style.width=clamp(player.armor,0,100)+'%';
  const s=curS(player),w=WP[s.id],o=player.sl[1-player.cur];
  wslotsUpdate();
  setT('wtxt',w.n+'  '+s.mag+' / '+player.res+(o?'   ['+WP[o.id].n+']':''));
  const iv=player.inv;
  for(const [id,k] of [['bBand','bandage'],['bMed','medkit'],['bGren','grenade'],['bSmk','smoke'],['bGloo','gloo']]){
    const e=$(id),n=iv[k];e.querySelector('.bd').textContent=n;e.classList.toggle('off',n<=0);
  }
  for(const [id,k,l] of [['cBand','bandage',T('Bandage [H]')],['cMed','medkit',T('Medkit [J]')],['cGren','grenade',T('Grenade [G]')],['cSmk','smoke',T('Smoke [T]')],['cGloo','gloo',T('Gloo Wall [C]')]])
    setT(id,l+' ×'+iv[k]);
  const out=Math.hypot(player.x-z.cx,player.y-z.cy)>z.r;
  let msg;
  if(!player.alive)msg=T('You are out, spectating a teammate');
  else if(out)msg=T('Outside the zone! Get inside now');
  else if(z.stage==='wait'){const t=Math.max(0,z.t);msg=T('Zone shrinks in {0}',Math.floor(t/60)+':'+String(Math.floor(t%60)).padStart(2,'0'))}
  else if(z.stage==='shrink')msg=T('The zone is shrinking');
  else msg=T('Final zone');
  if(mode.rules)msg=GameMode.hudText();
  setT('zmsg',msg);$('zmsg').classList.toggle('bad',out);
  setT('wxl',mp.n+' · '+({clear:T('Clear weather'),rain:T('Rain'),snow:T('Snowfall'),blizzard:T('Blizzard'),sand:T('Sandstorm'),ash:T('Ash and smoke'),mist:T('Mist')}[mp.wx]||''));
  Combo.hud();
  skillHud();
}

/* ---------- lobby stage ---------- */
const lc=$('lc'),lx=lc.getContext('2d');let lobbyT=0,lps=[];
for(let i=0;i<40;i++)lps.push({x:Math.random(),y:Math.random(),s:rnd(.3,1),r:Math.random()});
function lobbyDraw(dt){
  lobbyT+=dt;
  const d=Math.min(devicePixelRatio||1,2),w=lc.clientWidth,hh=lc.clientHeight;
  if(!w||!hh)return;
  if(lc.width!==Math.round(w*d)||lc.height!==Math.round(hh*d)){lc.width=Math.round(w*d);lc.height=Math.round(hh*d)}
  lx.setTransform(d,0,0,d,0,0);
  const bg=lx.createLinearGradient(0,0,0,hh);bg.addColorStop(0,'#241a5e');bg.addColorStop(.55,'#12123a');bg.addColorStop(1,'#1a0f33');lx.fillStyle=bg;lx.fillRect(0,0,w,hh);
  // diagonal pattern
  lx.save();lx.strokeStyle='rgba(120,110,255,.07)';lx.lineWidth=18;for(let i=-hh;i<w+hh;i+=70){lx.beginPath();lx.moveTo(i,0);lx.lineTo(i+hh*.7,hh);lx.stroke()}lx.restore();
  // spot
  const sp=lx.createRadialGradient(w/2,hh*.12,10,w/2,hh*.12,hh*.95);sp.addColorStop(0,'rgba(255,214,140,.32)');sp.addColorStop(1,'rgba(255,214,140,0)');lx.fillStyle=sp;lx.beginPath();lx.moveTo(w/2-30,0);lx.lineTo(w/2+30,0);lx.lineTo(w/2+hh*.55,hh);lx.lineTo(w/2-hh*.55,hh);lx.fill();
  const cy=hh*.84,sc=Math.min(hh*.64/52,w*.55/30);
  // floor ring
  lx.strokeStyle='rgba(255,179,71,.65)';lx.lineWidth=3;lx.beginPath();lx.ellipse(w/2,cy+2,sc*30,sc*8,0,0,TAU);lx.stroke();
  const fg=lx.createRadialGradient(w/2,cy,4,w/2,cy,sc*30);fg.addColorStop(0,'rgba(255,179,71,.35)');fg.addColorStop(1,'rgba(255,179,71,0)');lx.fillStyle=fg;lx.beginPath();lx.ellipse(w/2,cy,sc*30,sc*8,0,0,TAU);lx.fill();
  for(const p of lps){p.y-=dt*.03*p.s;if(p.y<0){p.y=1;p.x=Math.random()}lx.fillStyle=`rgba(255,220,150,${.15+.25*Math.abs(Math.sin(lobbyT+p.r*9))})`;lx.beginPath();lx.arc(p.x*w,p.y*hh,1.2+p.s*1.8,0,TAU);lx.fill()}
  const o=myLook(),sk=ITEMS[prof.eq.w],pt=ITEMS[prof.eq.p];
  const lb=lobbyBounce(sc);lx.save();lx.translate(w/2+Math.sin(lobbyT*.7)*3+lb[0],lb[1]);
  drawChar(lx,o,0,cy,sc,.35,lobbyT,{front:true,idle:true,gun:'ranger',gcol:wsk.look('ranger')?wsk.look('ranger').col:sk&&sk.col||null,gfx:(wsk.look('ranger')||{}).gfx,glow:true,noShadow:false});
  lx.restore();
  /* team: dost ke character aapke bagal me khade dikhte hain */
  const mates=(typeof Net!=='undefined'&&Net.party?Net.party.members.filter(m=>m.uid!==Net.uid):[]).slice(0,3);
  const MX=[-21,21,-40];
  mates.forEach((m,i)=>{
    const x=w/2+sc*MX[i],s2=sc*.82,ph=lobbyT+i*1.3;
    lx.strokeStyle='rgba(120,200,255,.55)';lx.lineWidth=2;lx.beginPath();lx.ellipse(x,cy+2,s2*12,s2*3.4,0,0,TAU);lx.stroke();
    try{drawChar(lx,m.look||charLook(0),x+Math.sin(ph*.7)*2,cy,s2,.35,ph,{front:true,idle:true,gun:'ranger',noShadow:false})}catch(e){}
    lx.font='700 '+Math.max(11,sc*3)+'px Rajdhani,Hind,'+I18N.fb+'system-ui,sans-serif';lx.textAlign='center';lx.lineWidth=3;lx.strokeStyle='rgba(0,0,0,.7)';
    const ny=cy+sc*7.5;lx.strokeText((m.uid===Net.party.leader?'👑 ':'')+m.name,x,ny);lx.fillStyle='#bfe6ff';lx.fillText((m.uid===Net.party.leader?'👑 ':'')+m.name,x,ny);
  });
  lobbyExtra(w,hh,cy,sc,dt,mates.length);
  if(pt)drawPet(lx,pt.kind,w/2+sc*30,cy+sc*3,sc*.55,lobbyT);
}
function refreshBars(){
  $('lGold').textContent=prof.gold;$('lGems').textContent=prof.gems;
  $('lName').textContent=prof.name;$('lLvl').textContent='Lv '+level();
  $('lXp').style.width=(prof.xp%100)+'%';
  Prog.badge();
  const m=MAPS[prof.map],md=MODES.find(x=>x.id===prof.mode)||MODES[0];
  $('lMode').textContent=md.n;$('lMap').textContent=m.n+' · '+T('{0} km',(m.size/1000).toFixed(1));
}
function showLobby(){
  MatchNet.leave();
  if(I18N.pending){location.reload();return}
  state='lobby';$('lobby').hidden=false;$('end').hidden=true;$('pause').hidden=true;$('hud').hidden=true;
  refreshBars();
  if(typeof Online!=='undefined'){Online.chip();Online.banner()}
}
function showEnd(place,r){
  $('rt').textContent=place===1?T('You won!'):T('#{0} place',place);
  $('rt').style.color=place===1?'var(--accent)':'var(--fg)';
  const t=Math.floor(time);
  $('rs').innerHTML=T('{0} kills · survived until {1}',r.k,Math.floor(t/60)+':'+String(t%60).padStart(2,'0'))+'<br>'+T('Reward:')+' <b>'+T('+{0} Gold',r.gold)+'</b>'+(r.gems?' · <b>'+T('+{0} Diamonds',r.gems)+'</b>':'')+' · <b>+'+r.xp+' XP</b>';
  $('end').hidden=false;
}
function claimDaily(){
  const d=new Date().toDateString();
  if(prof.daily===d){toast(T('Already claimed today\'s bonus'));return}
  const r=Prog.claimLogin();                           // 7-din streak reward (दिन-1 = पहले जैसा 200 गोल्ड + 10 डायमंड)
  refreshBars();snd('heal');toast(T('Daily bonus (day {0}): +{1} Gold, +{2} Diamonds',r.day,r.g,r.d)+(r.t?' + '+T('🎟 token'):''));
}

/* ---------- PUBG-style weapon slots (HP bar ke upar) ----------
   Dono guns ki photo; haath wali gun par tap = reload, dusri par tap = wo gun haath mein */
const WSlots={k:['',''],init(){
  for(let i=0;i<2;i++){
    $('ws'+i).addEventListener('pointerdown',e=>{
      e.preventDefault();e.stopPropagation();ac();
      if(state!=='play'||!player||!player.alive||player.air)return;
      if(!player.sl[i])return;
      if(player.cur===i){const s=curS(player),w=WP[s.id];if(s.mag<w.mag&&player.res>0&&!player.heal){startReload(player)}}
      else swapW(player);
    });
  }
}};
function wslotsUpdate(){
  for(let i=0;i<2;i++){
    const b=$('ws'+i),s=player.sl[i],cv=b.querySelector('canvas');
    b.classList.toggle('empty',!s);b.classList.toggle('on',player.cur===i&&!!s);
    if(!s){if(WSlots.k[i]!==''){WSlots.k[i]='';cv.getContext('2d').clearRect(0,0,cv.width,cv.height);b.querySelector('.wn').textContent='';b.querySelector('.wa').textContent='-'}continue}
    const wl=wsk.look(s.id),key=s.id+'|'+(wl?wl.col:'');
    if(WSlots.k[i]!==key){
      WSlots.k[i]=key;const g=cv.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);
      g.scale(2,2);drawGunIcon(g,s.id,50,19,.62,wl?wl.col:null,wl&&wl.gfx);
      b.querySelector('.wn').textContent=WP[s.id].n.toUpperCase();
    }
    const rl=player.rl>0&&player.rls===s;
    b.classList.toggle('rl',rl);if(rl)b.style.setProperty('--rp',Math.round((1-player.rl/WP[s.id].rl)*100)+'%');
    const t=player.cur===i?s.mag+' / '+player.res:String(s.mag);
    const a=b.querySelector('.wa');if(a.textContent!==t)a.textContent=t;
  }
}
WSlots.init();
