'use strict';
/* =====================================================================
   scrollfix.js — touch drag se har panel / lobby list scroll (swipe) ho
   ---------------------------------------------------------------------
   Native pan par bharosa nahi (body touch-action:none, portrait "rot" mein axis ulta).
   Isliye: scroller par touch-action:none + yahan pointer-drag se scrollTop/Left badalte hain.
   rot mode: screen ka X-delta = content ka (ulta) Y-delta, screen ka Y-delta = content ka X-delta.
   Gameplay ke canvas / fire button / sliders ko nahi chhoota.
   ===================================================================== */
const ScrollFix={
  cfg:{thresh:8,friction:3.2,sel:'#pbody,.lmenu,.tabs,.ov,.sets,.wlist,.slist',skip:'input,select,textarea,#c,#lc,#ledit,#bFire,.fk'},
  st:null,block:0,mom:null,
  rot(){return document.documentElement.classList.contains('rot')},
  // pointer ke upar wala sabse nazdeeki scrollable ancestor (axis ke hisaab se)
  find(t){
    for(let n=t;n&&n!==document.body;n=n.parentElement){
      if(!n.matches||!n.matches(this.cfg.sel))continue;
      const cs=getComputedStyle(n),oy=/(auto|scroll)/.test(cs.overflowY),ox=/(auto|scroll)/.test(cs.overflowX);
      const cy=oy&&n.scrollHeight>n.clientHeight+1,cx=ox&&n.scrollWidth>n.clientWidth+1;
      if(cy||cx)return{el:n,cy,cx};
    }
    return null;
  },
  init(){
    const d=document,C=this.cfg;
    d.addEventListener('pointerdown',e=>{
      if(e.pointerType==='mouse'&&e.button!==0)return;
      if(typeof state!=='undefined'&&state==='play'&&!d.querySelector('.ov:not([hidden]),#panel:not([hidden])'))return;
      if(e.target.closest&&e.target.closest(C.skip))return;
      const f=this.find(e.target);if(!f)return;
      this.mom=null;
      this.st={id:e.pointerId,f,x:e.clientX,y:e.clientY,lx:e.clientX,ly:e.clientY,t:performance.now(),vx:0,vy:0,on:false};
    },true);
    d.addEventListener('pointermove',e=>{
      const s=this.st;if(!s||e.pointerId!==s.id)return;
      if(e.pointerType==='mouse'&&!(e.buttons&1)){this.st=null;return}
      const rot=this.rot();
      if(!s.on){
        if(Math.hypot(e.clientX-s.x,e.clientY-s.y)<C.thresh)return;
        s.on=true;
      }
      // screen delta -> content delta
      const dxs=e.clientX-s.lx,dys=e.clientY-s.ly,now=performance.now(),dt=Math.max(1,now-s.t);
      const cdx=rot?dys:dxs, cdy=rot?-dxs:dys;
      const el=s.f.el;
      if(s.f.cy)el.scrollTop-=cdy;
      if(s.f.cx)el.scrollLeft-=cdx;
      s.vx=s.f.cx?-cdx/dt:0;s.vy=s.f.cy?-cdy/dt:0;     // px/ms (scroll direction)
      s.lx=e.clientX;s.ly=e.clientY;s.t=now;
      e.preventDefault();
    },{capture:true,passive:false});
    const end=e=>{
      const s=this.st;if(!s||e.pointerId!==s.id)return;this.st=null;
      if(s.on){
        this.block=performance.now()+350;                // drag ke baad accidental click na ho
        if(performance.now()-s.t<90&&(Math.abs(s.vx)>.05||Math.abs(s.vy)>.05))this.mom={el:s.f.el,vx:s.vx,vy:s.vy,cy:s.f.cy,cx:s.f.cx,t:performance.now()};
      }
    };
    d.addEventListener('pointerup',end,true);d.addEventListener('pointercancel',end,true);
    d.addEventListener('click',e=>{if(performance.now()<this.block){e.stopPropagation();e.preventDefault()}},true);
    // browser-native drag/selection scroll ko roko, taaki pointer events cancel na hon
    const css=d.createElement('style');
    css.textContent=C.sel.split(',').map(s=>s+'{touch-action:none!important}').join('')+'#pbody,.lmenu,.ov{overscroll-behavior:contain}';
    d.head.append(css);
    // inertia
    const tick=t=>{
      const m=this.mom;
      if(m){
        const dt=Math.min(40,t-m.t);m.t=t;
        if(m.cy)m.el.scrollTop+=m.vy*dt;if(m.cx)m.el.scrollLeft+=m.vx*dt;
        const k=Math.exp(-C.friction*dt/1000);m.vx*=k;m.vy*=k;
        if(Math.abs(m.vx)<.02&&Math.abs(m.vy)<.02)this.mom=null;
      }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
};
ScrollFix.init();
