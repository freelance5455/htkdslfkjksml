'use strict';
/* =====================================================================
   MatchNet — online squad match (party ke dost ek hi match me)
   ---------------------------------------------------------------------
   Host (team leader) poora game simulate karta hai (bots, zone, loot, damage).
   Baaki dost (client) apni movement / aim khud chalate hain aur commands bhejte hain
   (fire, reload, heal, grenade, gloo, pickup, emote). Host har ~66 ms par snapshot bhejta hai
   (players, goliyan, loot, zone, events) aur client usse screen par dikhata hai.
   Duniya (houses, trees, loot) ek shared seed se dono taraf same banti hai.
   Sab kuch server ke relay ('r') se jata hai: {k:'init'|'n'|'l'|'s'|'c'|'end'|'bye'}.
   ===================================================================== */
const MatchNet={
  active:false,role:'',seed:0,members:[],order:[],myIdx:0,hostUid:'',map:0,ready:false,pend:null,
  acc:0,lacc:0,sacc:0,evq:[],sevq:[],lid:0,lastShot:0,
  get host(){return this.active&&this.role==='host'},
  get client(){return this.active&&this.role==='client'},
  uidOf(i){return this.order[i]},
  mem(uid){return this.members.find(m=>m.uid===uid)},

  /* ---- shared seed: duniya dono taraf same ---- */
  seeded(fn){
    if(!this.active||!this.seed)return fn();
    const R=Math.random;let a=this.seed>>>0;
    Math.random=function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296};
    try{return fn()}finally{Math.random=R}
  },

  /* ---- start ---- */
  begin(m){
    if(this.active||state==='play')return;
    this.order=[m.host].concat(m.members.map(x=>x.uid).filter(u=>u!==m.host));
    this.active=true;this.role=m.host===Net.uid?'host':'client';this.seed=m.seed;this.members=m.members;this.myIdx=this.order.indexOf(Net.uid);
    this.hostUid=m.host;this.map=m.map;this.ready=false;this.pend=null;this.acc=this.lacc=this.sacc=0;this.evq=[];this.sevq=[];
    this.rx=0;this.ended=false;
    closePanel();$('lobby').hidden=true;
    Loader.show(MAPS[m.map].n+' · '+MAPS[m.map].loc);Loader.set(55,T('Building the map…'));
    setTimeout(()=>{
      try{
        if(this.role==='host'){
          const om=prof.map,omo=prof.mode;prof.map=m.map;prof.mode='squad';
          try{startMatchNow()}finally{prof.map=om;prof.mode=omo}
          this.sendInit();this.ready=true;
        }else{
          this.seeded(()=>genWorld(m.map));
          if(this.pend){const i=this.pend;this.pend=null;this.clientStart(i)}else this.worldOnly=true;
        }
      }catch(e){this.fail(e)}
      if(this.role==='host'||!this.worldOnly)Loader.set(100,T('Ready!'));
      setTimeout(()=>Loader.hide(),350);
    },700);
    // host aane me der kare to
    clearTimeout(this._wt);this._wt=setTimeout(()=>{if(this.active&&!this.ready&&state!=='play')this.abort(T('Could not start the online match'))},20000);
  },
  fail(e){console.error(e);this.abort(T('Could not start the online match'))},
  abort(msg){
    const was=this.active;this.cleanup();
    if(was){Loader.hide();if(state==='play'||state==='done'||state==='pause')showLobby();else{$('lobby').hidden=false}if(msg)toast(msg)}
  },
  cleanup(){this.active=false;this.role='';this.ready=false;this.pend=null;this.worldOnly=false;this.evq=[];this.sevq=[];clearTimeout(this._wt)},
  leave(){                                        // lobby par wapas (match khatam / chhod diya)
    if(!this.active)return;
    if(this.role==='client')Net.relay({k:'bye'});
    else if(Net.isLeader()){if(!this.ended)Net.relay({k:'hostbye'});Net.send({t:'party.end'})}
    this.cleanup();
  },

  /* ---- host: setup + init ---- */
  hostSetup(){
    for(let i=1;i<this.order.length;i++){
      const m=this.mem(this.order[i]),p=players[i];if(!p||!m)continue;
      p.bot=false;p.remote=true;p.uid=m.uid;p.name=m.name;if(m.look)p.out=m.look;p.autopick=true;p.lastRx=-1;
      p.sl=[{id:'pistol',mag:12},null];p.cur=0;p.res=60;p.hp=MAXHP;p.armor=0;p.ang=rnd(0,TAU);
    }
    player.uid=Net.uid;
  },
  sendInit(){
    Net.relay({k:'init',P:players.map(p=>({n:p.name,b:p.bot?1:0,tm:p.team,o:p.out,x:Math.round(p.x),y:Math.round(p.y),a:+p.ang.toFixed(2),sl:p.sl,res:p.res,inv:p.inv,hp:p.hp,sk:p.skin,gs:p.gskin})),z:z,an:aliveN});
  },
  /* ---- client: world + players ---- */
  clientStart(init){
    mode=MODES.find(x=>x.id==='squad');
    players=[];bullets=[];parts=[];hurt=0;time=0;specT=null;shake=0;wxInit();loot=loot||[];
    FX.reset();Combo.reset();GameMode.reset();Scope.reset();set.autopick=true;
    for(const e of init.P){
      const p=mkP(e.n,!!e.b,e.tm,e.o);p.x=p.lx=p.tx=e.x;p.y=p.ly=p.ty=e.y;p.ang=p.ta=e.a;p.sl=e.sl;p.res=e.res;p.inv=e.inv;p.hp=e.hp;p.skin=e.sk;p.gskin=e.gs;p.seen=true;players.push(p);
    }
    player=players[this.myIdx];resetAbil();
    AutoAimController.reset();FireButtonDrag.reset();FireHold.reset();WeaponController.reset();
    const sk=ITEMS[prof.eq.w];player.skin=sk&&sk.col||null;const gs=ITEMS[prof.eq.g];player.gskin=gs&&gs.col||'#8fd8ff';
    z=init.z;aliveN=init.an;Drop.reset();
    cam.x=player.x;cam.y=player.y-18;$('feed').innerHTML='';
    state='play';stgOk=true;closePanel();$('lobby').hidden=true;$('end').hidden=true;$('pause').hidden=true;$('hud').hidden=false;
    applyTouchUI();toast(mp.n+' · '+mp.loc);
    this.ready=true;this.worldOnly=false;Loader.set(100,T('Ready!'));setTimeout(()=>Loader.hide(),350);
  },

  /* ---- messaging ---- */
  cmd(c){Net.relayTo(this.hostUid,{k:'c',c})},
  bcast(d){Net.relay(d)},

  onRelay(m){
    const d=m.d;if(!d||!this.active)return;
    if(this.client){
      if(m.from!==this.hostUid)return;
      if(d.k==='hostbye'){this.abort(T('The team leader left — match ended'));return}
      if(d.k==='init'){if(this.ready)return;if(this.worldOnly){this.worldOnly=false;try{this.clientStart(d)}catch(e){this.fail(e)}}else this.pend=d;return}
      if(!this.ready||state==='lobby')return;
      if(d.k==='n')this.applySnap(d);
      else if(d.k==='l')this.applyLoot(d.L);
      else if(d.k==='end'){endMatch(d.place)}
    }else if(this.host){
      const idx=this.order.indexOf(m.from),p=players[idx];if(!p||!p.remote)return;
      if(d.k==='s')this.hostState(p,d);
      else if(d.k==='c')this.hostCmd(p,d.c);
      else if(d.k==='bye')this.toBot(p);
    }
  },
  toBot(p){if(!p.remote)return;p.remote=false;p.bot=true;p.res=Math.max(p.res,60);p.tgt=null;p.wp=null},

  /* ---- host: client ka state + commands ---- */
  hostState(p,d){
    if(!p.alive)return;
    const dt=Math.max(.02,time-(p.lastRx<0?time-.05:p.lastRx));p.lastRx=time;
    const ox=p.x,oy=p.y;p.x=d.x;p.y=d.y;p.ang=d.a;p.fl=d.fl|0;p.mv=d.mv||0;p.vx=(p.x-ox)/dt;p.vy=(p.y-oy)/dt;
    if(d.c!==p.cur&&p.sl[d.c])swapW(p);
    p.autopick=d.ap!==false;
  },
  hostCmd(p,c){
    if(!p.alive||!c)return;
    switch(c.c){
      case'f':if(typeof c.a==='number'){p.ang=c.a;if(typeof c.x==='number'){p.x=c.x;p.y=c.y}}shoot(p,{});break;
      case'rl':startReload(p);break;
      case'hl':startHeal(p,c.ty==='medkit'?'medkit':'bandage');break;
      case'hlx':p.heal=null;break;
      case'gr':if(typeof c.a==='number')p.ang=c.a;throwN(p,c.ty==='smoke'?'smoke':'grenade');break;
      case'gl':if(typeof c.a==='number')p.ang=c.a;placeGloo(p);break;
      case'em':if(c.i>=0&&c.i<EMO.length)doEmote(p,c.i|0);break;
      case'pk':{const i=loot.findIndex(l=>l.id===c.id);if(i<0)break;const l=loot[i];if(Math.hypot(l.x-p.x,l.y-p.y)<70&&(l.fl|0)===(p.fl|0)&&take(p,l,true))loot.splice(i,1);break}
    }
  },

  /* ---- events (hurtP / kill / sndAt hooks) ---- */
  evHit(v,d,src,hs){
    if(!this.host)return;
    if(!(v.remote||(src&&src.remote)))return;
    this.evq.push({e:'h',v:players.indexOf(v),s:src?players.indexOf(src):-1,d:Math.round(d),hs:hs?1:0});
  },
  evKill(v,src){if(this.host)this.evq.push({e:'k',v:players.indexOf(v),s:src?players.indexOf(src):-1})},
  evSnd(k,x,y){if(this.host&&this.sevq.length<12)this.sevq.push([k,Math.round(x),Math.round(y)])},

  /* ---- host: snapshot ---- */
  hostTick(dt){
    if(state!=='play')return;
    // disconnect: bahut der se kuch nahi aaya -> bot
    for(const p of players)if(p.remote&&p.lastRx>=0&&time-p.lastRx>8)this.toBot(p);
    this.acc+=dt;this.lacc+=dt;
    if(this.acc>=.066){this.acc=0;this.sendSnap()}
    if(this.lacc>=.8){this.lacc=0;this.sendLoot()}
  },
  sendSnap(){
    const hum=players.filter(p=>p===player||p.remote),near=(x,y)=>hum.some(h=>Math.abs(h.x-x)<1900&&Math.abs(h.y-y)<1500);
    const P=[],H={};
    players.forEach((p,i)=>{
      if(!(p.team===player.team||near(p.x,p.y)||(p._al!==p.alive)))return;
      p._al=p.alive;
      const e={i,x:Math.round(p.x),y:Math.round(p.y),a:+p.ang.toFixed(2),hp:Math.round(p.hp),ar:Math.round(p.armor),al:p.alive?1:0,fl:p.fl|0,c:p.cur,mv:+(p.mv||0).toFixed(2),k:p.kills|0};
      const s0=p.sl[0],s1=p.sl[1];if(s0){e.s0=s0.id;e.m0=s0.mag}if(s1){e.s1=s1.id;e.m1=s1.mag}
      if(p.flash>0)e.fh=1;if(p.hitT>0)e.ht=1;if(p.emo&&p.emo.t>0)e.em=[p.emo.i,+p.emo.t.toFixed(1)];
      if(p.camo>0)e.cm=1;
      P.push(e);
      if(p.remote){H[i]={sl:p.sl.map(s=>s?[s.id,s.mag]:null),res:p.res,inv:p.inv,heal:p.heal?{type:p.heal.type,t:+p.heal.t.toFixed(2),T:p.heal.T}:null,rl:+p.rl.toFixed(2),ri:p.rls?p.sl.indexOf(p.rls):-1,armor:Math.round(p.armor)}}
    });
    const B=[];for(const b of bullets){if(B.length>=140)break;if(near(b.x,b.y))B.push([Math.round(b.x),Math.round(b.y),Math.round(b.vx),Math.round(b.vy),Math.round(b.sp),Math.round(b.l),b.d,b.fl|0,players.indexOf(b.o),b.xb?1:0])}
    const G=glooW.map(w=>[Math.round(w.x),Math.round(w.y),+w.a.toFixed(2),Math.round(w.hp),w.col,w.fl|0,w.hit>0?1:0,w.hl,w.ht]);
    const N=nades.map(n=>[Math.round(n.x),Math.round(n.y),n.fl|0,n.type,+n.fuse.toFixed(2),+n.age.toFixed(2),players.indexOf(n.o)]);
    const S=smokes.map(s=>[Math.round(s.x),Math.round(s.y),Math.round(s.r),+s.t.toFixed(1),s.mr]);
    const X=fxs.map(f=>[Math.round(f.x),Math.round(f.y),+f.t.toFixed(2)]);
    const msg={k:'n',tm:+time.toFixed(2),z,an:aliveN,P,H,B,G,N,S,X};
    if(this.evq.length){msg.E=this.evq;this.evq=[]}
    if(this.sevq.length){msg.SN=this.sevq;this.sevq=[]}
    Net.relay(msg);
  },
  sendLoot(){
    const L=[];for(const l of loot){if(!l.id)l.id=++this.lid;L.push([l.id,Math.round(l.x),Math.round(l.y),l.t,l.q||1,l.fl|0])}
    Net.relay({k:'l',L});
  },

  /* ---- client: snapshot lagu karo ---- */
  applySnap(m){
    time=m.tm;if(m.z)z=m.z;aliveN=m.an;
    for(const e of m.P){
      const p=players[e.i];if(!p)continue;
      const was=p.alive;p.alive=!!e.al;p.kills=e.k;p.armor=e.ar;
      if(p===player){
        if(e.hp<p.hp&&this.hpWatch)hurt=Math.max(hurt,.2);p.hp=e.hp;
        continue;
      }
      p.hp=e.hp;p.tx=e.x;p.ty=e.y;p.ta=e.a;p.fl=e.fl;p.mv=e.mv;p.cur=e.c;
      p.sl=[e.s0?{id:e.s0,mag:e.m0}:{id:'pistol',mag:0},e.s1?{id:e.s1,mag:e.m1}:null];
      if(e.fh)p.flash=.07;if(e.ht)p.hitT=.12;p.emo=e.em?{i:e.em[0],t:e.em[1]}:null;p.camo=e.cm?1:0;
      if(!p.seen){p.x=e.x;p.y=e.y;p.ang=e.a;p.seen=true}
      if(was&&!p.alive)p.seen=false;
    }
    this.hpWatch=true;
    const H=m.H&&m.H[this.myIdx];
    if(H&&player){
      const cur=player.cur;
      const old=player.sl;player.sl=H.sl.map((s,i)=>{if(!s)return null;let mag=s[1];const o=old&&old[i];if(o&&o.id===s[0]&&time-this.lastShot<.45&&o.mag<mag)mag=o.mag;return{id:s[0],mag}});
      player.cur=player.sl[cur]?cur:0;player.res=H.res;player.inv=H.inv;
      player.heal=H.heal;player.rl=H.rl;player.rls=H.ri>=0?player.sl[H.ri]:null;
    }
    // goliyan / gloo / nade / smoke / explosion
    bullets=m.B.map(b=>({x:b[0],y:b[1],vx:b[2],vy:b[3],sp:b[4],l:b[5],d:b[6],fl:b[7],o:players[b[8]]||players[0],xb:!!b[9]}));
    glooW=m.G.map(w=>({x:w[0],y:w[1],a:w[2],hp:w[3],col:w[4],fl:w[5],hit:w[6]?.1:0,hl:w[7],ht:w[8],t:30}));
    nades=m.N.map(n=>({x:n[0],y:n[1],fl:n[2],type:n[3],fuse:n[4],age:n[5],o:players[n[6]]||players[0],vx:0,vy:0}));
    smokes=m.S.map(s=>({x:s[0],y:s[1],r:s[2],t:s[3],mr:s[4]}));
    fxs=m.X.map(f=>({x:f[0],y:f[1],t:f[2]}));
    if(m.E)for(const e of m.E)this.evClient(e);
    if(m.SN)for(const s of m.SN){if(Math.hypot(s[1]-player.x,s[2]-player.y)<1600)Spat.play(s[0],s[1],s[2])}
  },
  evClient(e){
    const v=players[e.v],s=e.s>=0?players[e.s]:null;if(!v)return;
    if(e.e==='h'){
      if(v===player){hurt=.5;snd('hit',.7)}else if(s===player)snd('hit',.5);
      FX.onHit(v,e.d,s,!!e.hs);spark(v.x,v.y,'#ff5d6c',5);
    }else if(e.e==='k'){
      v.alive=false;
      feed(s&&s!==v?s.name:T('Zone'),v.name);spark(v.x,v.y,'#ff5d6c',16);FX.onKill(v,s);
    }
  },
  applyLoot(L){
    loot=L.map(l=>({id:l[0],x:l[1],y:l[2],t:l[3],q:l[4],fl:l[5]}));
  },

  /* ---- client: har frame ---- */
  cp(p,dt){                                        // update() ke per-player loop me (client)
    p.cd-=dt;p.flash-=dt;p.hitT-=dt;p.throwCd-=dt;p.glCd-=dt;
    if(p===player){
      if(p.alive&&!p.air){if(p.rl>0)p.rl=Math.max(0,p.rl-dt);if(p.heal)p.heal.t+=dt;updStairs(p)}
      return;
    }
    if(p.tx!==undefined){
      const dx=p.tx-p.x,dy=p.ty-p.y;
      if(dx*dx+dy*dy>160000){p.x=p.tx;p.y=p.ty}else{const k=Math.min(1,dt*14);p.vx=dx*k/dt;p.vy=dy*k/dt;p.x+=dx*k;p.y+=dy*k}
      p.ang+=angDiff(p.ang,p.ta)*Math.min(1,dt*16);
    }
    p.wt+=dt*(.3+(p.mv||0));
  },
  moveBullets(dt){
    for(let i=bullets.length-1;i>=0;i--){const b=bullets[i];b.x+=b.vx*dt;b.y+=b.vy*dt;b.l-=b.sp*dt;if(b.l<=0){bullets[i]=bullets[bullets.length-1];bullets.pop()}}
  },
  clientTick(dt){
    if(!this.ready||state!=='play'&&state!=='done')return;
    this.sacc+=dt;
    if(this.sacc>=.05&&player){this.sacc=0;Net.relayTo(this.hostUid,{k:'s',x:Math.round(player.x*10)/10,y:Math.round(player.y*10)/10,a:+player.ang.toFixed(3),fl:player.fl|0,mv:+(player.mv||0).toFixed(2),c:player.cur,ap:set.autopick!==false})}
  },
  noteShot(){this.lastShot=time}
};
Net.on('match.start',m=>MatchNet.begin(m));
Net.on('r',m=>MatchNet.onRelay(m));
Net.on('member.left',m=>{
  if(!MatchNet.active)return;
  if(MatchNet.client&&m.uid===MatchNet.hostUid){MatchNet.abort(T('The team leader left — match ended'));return}
  if(MatchNet.host){const p=players.find(x=>x.uid===m.uid);if(p&&p.remote){MatchNet.toBot(p);toast(T('{0} left the match',p.name))}}
});
Net.on('disconnect',()=>{if(MatchNet.client)MatchNet.abort(T('Connection lost'))});
