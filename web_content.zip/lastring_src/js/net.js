'use strict';
/* =====================================================================
   Net — online connection (server/server.js se baat karta hai)
   UID, friend request, team code (party), invite, chat, aur match ke dauraan relay.
   Sirf tab connect hota hai jab server ka address mil jaye:
     - game server se hi khola ho (http://HOST:3000)  -> same host
     - ya Friends & Party panel me server address daalo (Settings me save hota hai)
   ===================================================================== */
const Net={
  ws:null,mode:null,ok:false,uid:'',friends:[],inReq:[],outReq:[],party:null,chat:[],invites:[],
  lst:{},retry:0,rt:0,ping:0,want:true,err:'',_ps:0,
  on(t,fn){(this.lst[t]||(this.lst[t]=[])).push(fn)},
  emit(t,a,b){for(const f of this.lst[t]||[])try{f(a,b)}catch(e){console.error(e)}},
  key(){
    let k='';try{k=localStorage.getItem('lr_devkey')||''}catch(e){}
    if(!/^[a-zA-Z0-9]{16,64}$/.test(k)){
      const a=new Uint8Array(24);(crypto&&crypto.getRandomValues?crypto.getRandomValues(a):a.forEach((_,i)=>a[i]=Math.floor(Math.random()*256)));
      k=Array.from(a,x=>x.toString(16).padStart(2,'0')).join('');try{localStorage.setItem('lr_devkey',k)}catch(e){}
    }
    return k;
  },
  url(){
    let u=(set.server||'').trim();
    if(!u){if(location.protocol==='http:'||location.protocol==='https:')return(location.protocol==='https:'?'wss://':'ws://')+location.host;return''}
    u=u.replace(/^https:/,'wss:').replace(/^http:/,'ws:');
    if(!/^wss?:\/\//.test(u))u=(/^(localhost|127\.|10\.|192\.168\.|\d+\.\d+\.\d+\.\d+)/.test(u)?'ws://':'wss://')+u;
    return u.replace(/\/+$/,'');
  },
  connect(){
    clearTimeout(this.rt);
    if(this.mode==='p2p'){P2P.start();return}
    const url=this.url();if(!url){P2P.start();return}
    if(this.ws&&(this.ws.readyState===0||this.ws.readyState===1))return;
    this.err='';
    let ws;try{ws=new WebSocket(url)}catch(e){this.err='bad_url';this.emit('change');return}
    this.ws=ws;
    ws.onopen=()=>{this.retry=0;ws.send(JSON.stringify({t:'hello',key:this.key(),name:prof.name,look:myLook()}))};
    ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(x){return}this.msg(m)};
    ws.onclose=()=>{if(this.ws!==ws)return;const was=this.ok;this.ok=false;this.ws=null;this.party=this.party&&MatchNet.active?this.party:null;
      if(was){this.emit('disconnect')}this.emit('change');
      if(!was&&this.retry>=2&&this.want&&this.err!=='logged_in_elsewhere'){P2P.start();return}
      if(this.want&&this.err!=='logged_in_elsewhere'){this.retry=Math.min(this.retry+1,6);this.rt=setTimeout(()=>this.connect(),Math.min(15000,1500*this.retry))}};
    ws.onerror=()=>{if(!this.err)this.err='conn'};
  },
  stop(){if(this.mode==='p2p')P2P.stop();this.want=false;clearTimeout(this.rt);if(this.ws)try{this.ws.close()}catch(e){}this.ws=null;this.ok=false;this.emit('change')},
  restart(){if(this.mode==='p2p')P2P.stop();this.mode=null;this.want=true;this.err='';if(this.ws)try{this.ws.onclose=null;this.ws.close()}catch(e){}this.ws=null;this.ok=false;this.retry=0;this.connect()},
  send(o){if(this.mode==='p2p')return P2P.send(o);if(this.ok&&this.ws&&this.ws.readyState===1){this.ws.send(JSON.stringify(o));return true}return false},
  msg(m){
    switch(m.t){
      case'welcome':this.ok=true;this.uid=m.uid;this.err='';if(m.name&&m.name!==prof.name){/* server naam hi sach (pehle se account) */}
        this.pingT=setInterval(()=>{if(!this.ok){clearInterval(this.pingT);return}this.send({t:'ping',ts:performance.now()})},5000);this.send({t:'ping',ts:performance.now()});this.emit('change');this.emit('welcome');break;
      case'pong':this.ping=Math.round(performance.now()-m.ts);this.emit('ping');break;
      case'social':this.friends=m.friends;this.inReq=m.inReq;this.outReq=m.outReq;this.emit('change');break;
      case'party':
        if(!m.code){const was=this.party;this.party=null;this.chat=[];if(m.reason==='kicked')this.emit('notice',{k:'kicked'});this.emit('change');this.emit('partyLeft',was);break}
        {const prev=this.party;this.party=m;this.emit('change');this.emit('party',m,prev)}break;
      case'chat':this.chat.push(m);if(this.chat.length>30)this.chat.shift();this.emit('chat',m);this.emit('change');break;
      case'invite':this.invites=this.invites.filter(i=>i.from.uid!==m.from.uid);this.invites.push({from:m.from,code:m.code,t:Date.now()});this.emit('invite',m);this.emit('change');break;
      case'notice':this.emit('notice',m);break;
      case'error':this.err=m.e;this.emit('change');if(m.e==='logged_in_elsewhere')this.want=false;break;
      case'match.start':this.emit('match.start',m);break;
      case'member.left':this.emit('member.left',m);break;
      case'r':this.emit('r',m);break;
    }
  },
  isLeader(){return !!(this.party&&this.party.leader===this.uid)},
  inParty(){return !!(this.party&&this.party.members.length>1)},
  me(){return this.party&&this.party.members.find(x=>x.uid===this.uid)},
  /* match relay */
  relay(d){return this.send({t:'r',d})},
  relayTo(uid,d){return this.send({t:'rt',to:uid,d})}
};
