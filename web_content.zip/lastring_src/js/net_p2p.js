'use strict';
/* =====================================================================
   P2P — server ke bina "Direct mode" (WebRTC, PeerJS ke free cloud se sirf handshake)
   Group banane wala phone chhota "server" ban jata hai (hub); baaki 6-digit code se jude.
   Net ke saath wahi protocol bolta hai, isliye party / chat / match relay sab waise hi chalta hai.
   Friends/UID sirf server mode me (kyunki wo yaad rakhne ke liye server chahiye).
   ===================================================================== */
const P2P={
  ICE:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'},
       {urls:['turn:openrelay.metered.ca:80','turn:openrelay.metered.ca:443','turns:openrelay.metered.ca:443'],username:'openrelayproject',credential:'openrelayproject'}],
  SRC:['https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js','https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js','https://cdnjs.cloudflare.com/ajax/libs/peerjs/1.5.4/peerjs.min.js'],
  hub:null,cli:null,_uid:'',
  uid(){
    if(this._uid)return this._uid;
    let u='';try{u=localStorage.getItem('lr_p2p_uid')||''}catch(e){}
    if(!/^\d{8}$/.test(u)){u=String(10000000+Math.floor(Math.random()*89999999));try{localStorage.setItem('lr_p2p_uid',u)}catch(e){}}
    return this._uid=u;
  },
  start(){
    Net.mode='p2p';Net.ok=true;Net.uid=this.uid();Net.err='';Net.friends=[];Net.inReq=[];Net.outReq=[];Net.ping=0;
    Net.emit('change');Net.emit('welcome');
  },
  stop(){this.leaveAll(true);if(Net.mode==='p2p'){Net.ok=false;Net.mode=null}},
  load(){
    if(window.Peer)return Promise.resolve();
    if(this._ld)return this._ld;
    const one=i=>new Promise((res,rej)=>{if(i>=this.SRC.length)return rej(new Error('peerjs'));const s=document.createElement('script');s.src=this.SRC[i];s.onload=()=>window.Peer?res():one(i+1).then(res,rej);s.onerror=()=>one(i+1).then(res,rej);document.head.appendChild(s)});
    return this._ld=one(0).catch(e=>{this._ld=null;throw e});
  },
  fail(k){Net.emit('notice',{k:k||'p2p_fail'})},
  newPeer(id){return new Peer(id,{config:{iceServers:this.ICE},debug:0})},
  me(){return{uid:this.uid(),name:prof.name,look:(typeof myLook==='function'?myLook():null)}},
  /* ---------- Net.send ka P2P version ---------- */
  send(o){
    if(!o||!o.t)return false;
    if(o.t==='ping')return true;
    if(o.t==='hello')return true;
    if(o.t.indexOf('friend.')===0||o.t==='party.invite'){Net.emit('notice',{k:'p2p_nofriends'});return true}
    if(o.t==='party.create'){this.create();return true}
    if(o.t==='party.join'){this.join(String(o.code||'').replace(/\D/g,''));return true}
    if(this.hub){this.hubMsg(this.uid(),o);return true}
    if(this.cli&&this.cli.conn&&this.cli.conn.open){if(o.t==='party.leave'){this.leaveAll();return true}this.cli.conn.send(o);return true}
    return false;
  },
  leaveAll(silent){
    if(this.hub)this.hubClose();
    if(this.cli){const c=this.cli;this.cli=null;try{c.conn&&c.conn.close()}catch(e){}try{c.peer&&c.peer.destroy()}catch(e){}if(!silent)Net.msg({t:'party',code:null,reason:'left'})}
  },
  /* ---------- group banao (hub) ---------- */
  create(){
    this.leaveAll(true);if(Net.party)Net.msg({t:'party',code:null,reason:'left'});
    Net.emit('notice',{k:'p2p_creating'});
    this.load().then(()=>{
      const tryCode=n=>{
        if(n>6){this.fail();return}
        const code=String(100000+Math.floor(Math.random()*900000));
        const peer=this.newPeer('lrg-'+code);let done=false;
        peer.on('open',()=>{
          done=true;
          this.hub={code,peer,conns:{},p:{code,leader:this.uid(),mode:'squad',map:0,state:'lobby',members:[this.me()]}};
          peer.on('connection',c=>this.hubConn(c));
          peer.on('disconnected',()=>{try{peer.reconnect()}catch(e){}});
          this.push();
        });
        peer.on('error',e=>{if(done)return;try{peer.destroy()}catch(x){}if(e&&e.type==='unavailable-id')tryCode(n+1);else this.fail()});
      };
      tryCode(0);
    },()=>this.fail());
  },
  hubConn(c){
    let uid=null;
    c.on('data',m=>{
      if(!m||typeof m.t!=='string')return;
      if(m.t==='hi'){
        const h=this.hub;if(!h)return;uid=String(m.uid||'');
        const p=h.p;
        if(!uid||p.members.some(x=>x.uid===uid)){try{c.close()}catch(e){}return}
        if(p.members.length>=4){c.send({t:'notice',k:'party_full'});setTimeout(()=>{try{c.close()}catch(e){}},300);return}
        if(p.state!=='lobby'){c.send({t:'notice',k:'party_busy'});setTimeout(()=>{try{c.close()}catch(e){}},300);return}
        c.uid=uid;h.conns[uid]=c;p.members.push({uid,name:String(m.name||'Player').slice(0,14),look:m.look||null});this.push();return;
      }
      if(c.uid)this.hubMsg(c.uid,m);
    });
    const gone=()=>{if(c.uid&&this.hub&&this.hub.conns[c.uid]===c)this.removeMember(c.uid,'left')};
    c.on('close',gone);c.on('error',gone);
  },
  state(){const p=this.hub.p;return{t:'party',code:p.code,leader:p.leader,mode:p.mode,map:p.map,state:p.state,max:4,members:p.members.map(m=>({uid:m.uid,name:m.name,look:m.look}))}},
  push(){const s=this.state();for(const m of this.hub.p.members)this.deliver(m.uid,s)},
  deliver(uid,msg){
    if(uid===this.uid()){Net.msg(msg);return}
    const c=this.hub&&this.hub.conns[uid];if(c&&c.open)try{c.send(msg)}catch(e){}
  },
  removeMember(uid,reason){
    const h=this.hub;if(!h)return;const p=h.p,i=p.members.findIndex(m=>m.uid===uid);if(i<0)return;
    const isHost=uid===this.uid();
    if(isHost){
      if(p.state==='match')for(const m of p.members)if(m.uid!==uid)this.deliver(m.uid,{t:'member.left',uid});
      this.hubClose(true);return;
    }
    if(p.state==='match')for(const m of p.members)if(m.uid!==uid)this.deliver(m.uid,{t:'member.left',uid});
    p.members.splice(i,1);
    const c=h.conns[uid];delete h.conns[uid];
    if(c){try{c.send({t:'party',code:null,reason:reason||'left'})}catch(e){}setTimeout(()=>{try{c.close()}catch(e){}},300)}
    this.push();
  },
  hubClose(told){
    const h=this.hub;if(!h)return;this.hub=null;
    for(const uid in h.conns){const c=h.conns[uid];try{c.send({t:'party',code:null,reason:'host_left'})}catch(e){}setTimeout(()=>{try{c.close()}catch(e){}},400)}
    setTimeout(()=>{try{h.peer.destroy()}catch(e){}},600);
    Net.msg({t:'party',code:null,reason:'left'});
  },
  hubMsg(uid,m){
    const h=this.hub;if(!h)return;const p=h.p,lead=uid===p.leader,mem=p.members.find(x=>x.uid===uid);if(!mem)return;
    switch(m.t){
      case'ping':this.deliver(uid,{t:'pong',ts:m.ts});break;
      case'profile':if(m.name)mem.name=String(m.name).slice(0,14);if(m.look)mem.look=m.look;this.push();break;
      case'party.leave':this.removeMember(uid,'left');break;
      case'party.kick':if(lead&&p.state==='lobby'&&m.uid!==uid)this.removeMember(String(m.uid),'kicked');break;
      case'party.set':if(lead&&p.state==='lobby'){if(Number.isInteger(m.map)&&m.map>=0&&m.map<64)p.map=m.map;this.push()}break;
      case'party.chat':{const text=String(m.text||'').slice(0,120).trim();if(!text)break;for(const x of p.members)this.deliver(x.uid,{t:'chat',from:uid,name:mem.name,text});break}
      case'party.start':{
        if(!lead||p.state!=='lobby')break;
        if(p.members.length<2){this.deliver(uid,{t:'notice',k:'need_two'});break}
        p.state='match';p.seed=1+Math.floor(Math.random()*2147483000);
        const list=p.members.map(x=>({uid:x.uid,name:x.name,look:x.look}));
        for(const x of p.members)this.deliver(x.uid,{t:'match.start',seed:p.seed,map:p.map,mode:p.mode,host:p.leader,members:list});
        this.push();break}
      case'party.end':if(p.state==='match'){p.state='lobby';this.push()}break;
      case'r':if(p.state==='match')for(const x of p.members)if(x.uid!==uid)this.deliver(x.uid,{t:'r',from:uid,d:m.d});break;
      case'rt':if(p.state==='match'&&p.members.some(x=>x.uid===String(m.to)))this.deliver(String(m.to),{t:'r',from:uid,d:m.d});break;
    }
  },
  /* ---------- group join (6-digit code) ---------- */
  join(code){
    if(!/^\d{6}$/.test(code)){Net.emit('notice',{k:'bad_code'});return}
    if(this.hub&&this.hub.code===code)return;
    this.leaveAll(true);if(Net.party)Net.msg({t:'party',code:null,reason:'left'});
    Net.emit('notice',{k:'p2p_joining'});
    this.load().then(()=>{
      const peer=this.newPeer();const cli=this.cli={peer,conn:null,code};let ok=false;
      const bad=k=>{if(this.cli!==cli)return;this.cli=null;try{peer.destroy()}catch(e){}Net.emit('notice',{k:k||'bad_code'})};
      const to=setTimeout(()=>{if(!ok)bad('bad_code')},15000);
      peer.on('error',e=>{clearTimeout(to);if(!ok)bad(e&&e.type==='peer-unavailable'?'bad_code':'p2p_fail')});
      peer.on('open',()=>{
        const c=peer.connect('lrg-'+code,{reliable:true,serialization:'json'});cli.conn=c;
        c.on('open',()=>{clearTimeout(to);ok=true;c.send(Object.assign({t:'hi'},this.me()))});
        c.on('data',m=>{if(m&&m.t)Net.msg(m)});
        const gone=()=>{if(this.cli!==cli)return;this.cli=null;try{peer.destroy()}catch(e){}if(Net.party){const was=Net.party;Net.emit('disconnect');Net.msg({t:'party',code:null,reason:'host_left'})}};
        c.on('close',()=>{clearTimeout(to);if(ok)gone();else bad('bad_code')});c.on('error',()=>{if(ok)gone()});
      });
    },()=>this.fail());
  }
};
