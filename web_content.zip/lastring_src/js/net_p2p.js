'use strict';
/* =====================================================================
   P2P — server ke bina "Direct mode" (WebRTC, PeerJS ke free cloud se sirf handshake)
   Group banane wala phone chhota "server" ban jata hai (hub); baaki 6-digit code se jude.
   Net ke saath wahi protocol bolta hai, isliye party / chat / match relay sab waise hi chalta hai.
   Friends/UID sirf server mode me (kyunki wo yaad rakhne ke liye server chahiye).
   ===================================================================== */
const P2P={
  ICE:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'},
       {urls:['turn:openrelay.metered.ca:80','turn:openrelay.metered.ca:443','turns:openrelay.metered.ca:443'],username:'openrelayproject',credential:'openrelayproject'}],
  SRC:['https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js','https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js','https://cdnjs.cloudflare.com/ajax/libs/peerjs/1.5.4/peerjs.min.js'],
  hub:null,cli:null,_uid:'',
  uid(){
    if(this._uid)return this._uid;
    let u='';try{u=localStorage.getItem('lr_p2p_uid')||''}catch(e){}
    if(!/^\d{8}$/.test(u)){u=String(10000000+Math.floor(Math.random()*89999999));try{localStorage.setItem('lr_p2p_uid',u)}catch(e){}}
    return this._uid=u;
  },
  start(){
    Net.mode='p2p';Net.ok=true;Net.uid=this.uid();Net.err='';Net.friends=[];Net.inReq=[];Net.outReq=[];Net.ping=0;
    this.fr.load();this.fr.sync();Net.emit('change');Net.emit('welcome');this.fr.init();
  },
  stop(){this.leaveAll(true);this.fr.close();if(Net.mode==='p2p'){Net.ok=false;Net.mode=null}},
  load(){
    if(window.Peer)return Promise.resolve();
    if(this._ld)return this._ld;
    const one=i=>new Promise((res,rej)=>{if(i>=this.SRC.length)return rej(new Error('peerjs'));const s=document.createElement('script');s.src=this.SRC[i];s.onload=()=>window.Peer?res():one(i+1).then(res,rej);s.onerror=()=>one(i+1).then(res,rej);document.head.appendChild(s)});
    return this._ld=one(0).catch(e=>{this._ld=null;throw e});
  },
  fail(k){Net.emit('notice',{k:k||'p2p_fail'})},
  newPeer(id){return new Peer(id,{config:{iceServers:this.ICE},debug:0})},
  me(){return{uid:this.uid(),name:prof.name,look:(typeof myLook==='function'?myLook():null)}},
  /* ---------- Net.send ka P2P version ---------- */
  send(o){
    if(!o||!o.t)return false;
    if(o.t==='ping')return true;
    if(o.t==='hello')return true;
    if(o.t.indexOf('friend.')===0||o.t==='party.invite'){this.fr.cmd(o);return true}
    if(o.t==='party.create'){this.create();return true}
    if(o.t==='party.join'){this.join(String(o.code||'').replace(/\D/g,''));return true}
    if(this.hub){this.hubMsg(this.uid(),o);return true}
    if(this.cli&&this.cli.conn&&this.cli.conn.open){if(o.t==='party.leave'){this.leaveAll();return true}this.cli.conn.send(o);return true}
    return false;
  },
  leaveAll(silent){
    if(this.hub)this.hubClose();
    if(this.cli){const c=this.cli;this.cli=null;try{c.conn&&c.conn.close()}catch(e){}try{c.peer&&c.peer.destroy()}catch(e){}if(!silent)Net.msg({t:'party',code:null,reason:'left'})}
  },
  /* ---------- group banao (hub) ---------- */
  create(){
    this.leaveAll(true);if(Net.party)Net.msg({t:'party',code:null,reason:'left'});
    Net.emit('notice',{k:'p2p_creating'});
    this.load().then(()=>{
      const tryCode=n=>{
        if(n>6){this.fail();return}
        const code=String(100000+Math.floor(Math.random()*900000));
        const peer=this.newPeer('lrg-'+code);let done=false;
        peer.on('open',()=>{
          done=true;
          this.hub={code,peer,conns:{},p:{code,leader:this.uid(),mode:'squad',map:0,state:'lobby',members:[this.me()]}};
          peer.on('connection',c=>this.hubConn(c));
          peer.on('disconnected',()=>{try{peer.reconnect()}catch(e){}});
          this.push();
        });
        peer.on('error',e=>{if(done)return;try{peer.destroy()}catch(x){}if(e&&e.type==='unavailable-id')tryCode(n+1);else this.fail()});
      };
      tryCode(0);
    },()=>this.fail());
  },
  hubConn(c){
    let uid=null;
    c.on('data',m=>{
      if(!m||typeof m.t!=='string')return;
      if(m.t==='hi'){
        const h=this.hub;if(!h)return;uid=String(m.uid||'');
        const p=h.p;
        if(!uid||p.members.some(x=>x.uid===uid)){try{c.close()}catch(e){}return}
        if(p.members.length>=4){c.send({t:'notice',k:'party_full'});setTimeout(()=>{try{c.close()}catch(e){}},300);return}
        if(p.state!=='lobby'){c.send({t:'notice',k:'party_busy'});setTimeout(()=>{try{c.close()}catch(e){}},300);return}
        c.uid=uid;h.conns[uid]=c;p.members.push({uid,name:String(m.name||'Player').slice(0,14),look:m.look||null});this.push();return;
      }
      if(c.uid)this.hubMsg(c.uid,m);
    });
    const gone=()=>{if(c.uid&&this.hub&&this.hub.conns[c.uid]===c)this.removeMember(c.uid,'left')};
    c.on('close',gone);c.on('error',gone);
  },
  state(){const p=this.hub.p;return{t:'party',code:p.code,leader:p.leader,mode:p.mode,map:p.map,state:p.state,max:4,members:p.members.map(m=>({uid:m.uid,name:m.name,look:m.look}))}},
  push(){const s=this.state();for(const m of this.hub.p.members)this.deliver(m.uid,s)},
  deliver(uid,msg){
    if(uid===this.uid()){Net.msg(msg);return}
    const c=this.hub&&this.hub.conns[uid];if(c&&c.open)try{c.send(msg)}catch(e){}
  },
  removeMember(uid,reason){
    const h=this.hub;if(!h)return;const p=h.p,i=p.members.findIndex(m=>m.uid===uid);if(i<0)return;
    const isHost=uid===this.uid();
    if(isHost){
      if(p.state==='match')for(const m of p.members)if(m.uid!==uid)this.deliver(m.uid,{t:'member.left',uid});
      this.hubClose(true);return;
    }
    if(p.state==='match')for(const m of p.members)if(m.uid!==uid)this.deliver(m.uid,{t:'member.left',uid});
    p.members.splice(i,1);
    const c=h.conns[uid];delete h.conns[uid];
    if(c){try{c.send({t:'party',code:null,reason:reason||'left'})}catch(e){}setTimeout(()=>{try{c.close()}catch(e){}},300)}
    this.push();
  },
  hubClose(told){
    const h=this.hub;if(!h)return;this.hub=null;
    for(const uid in h.conns){const c=h.conns[uid];try{c.send({t:'party',code:null,reason:'host_left'})}catch(e){}setTimeout(()=>{try{c.close()}catch(e){}},400)}
    setTimeout(()=>{try{h.peer.destroy()}catch(e){}},600);
    Net.msg({t:'party',code:null,reason:'left'});
  },
  hubMsg(uid,m){
    const h=this.hub;if(!h)return;const p=h.p,lead=uid===p.leader,mem=p.members.find(x=>x.uid===uid);if(!mem)return;
    switch(m.t){
      case'ping':this.deliver(uid,{t:'pong',ts:m.ts});break;
      case'profile':if(m.name)mem.name=String(m.name).slice(0,14);if(m.look)mem.look=m.look;this.push();break;
      case'party.leave':this.removeMember(uid,'left');break;
      case'party.kick':if(lead&&p.state==='lobby'&&m.uid!==uid)this.removeMember(String(m.uid),'kicked');break;
      case'party.set':if(lead&&p.state==='lobby'){if(Number.isInteger(m.map)&&m.map>=0&&m.map<64)p.map=m.map;this.push()}break;
      case'party.chat':{const text=String(m.text||'').slice(0,120).trim();if(!text)break;for(const x of p.members)this.deliver(x.uid,{t:'chat',from:uid,name:mem.name,text});break}
      case'party.start':{
        if(!lead||p.state!=='lobby')break;
        if(p.members.length<2){this.deliver(uid,{t:'notice',k:'need_two'});break}
        p.state='match';p.seed=1+Math.floor(Math.random()*2147483000);
        const list=p.members.map(x=>({uid:x.uid,name:x.name,look:x.look}));
        for(const x of p.members)this.deliver(x.uid,{t:'match.start',seed:p.seed,map:p.map,mode:p.mode,host:p.leader,members:list});
        this.push();break}
      case'party.end':if(p.state==='match'){p.state='lobby';this.push()}break;
      case'r':if(p.state==='match')for(const x of p.members)if(x.uid!==uid)this.deliver(x.uid,{t:'r',from:uid,d:m.d});break;
      case'rt':if(p.state==='match'&&p.members.some(x=>x.uid===String(m.to)))this.deliver(String(m.to),{t:'r',from:uid,d:m.d});break;
    }
  },
  /* ---------- group join (6-digit code) ---------- */
  join(code){
    if(!/^\d{6}$/.test(code)){Net.emit('notice',{k:'bad_code'});return}
    if(this.hub&&this.hub.code===code)return;
    this.leaveAll(true);if(Net.party)Net.msg({t:'party',code:null,reason:'left'});
    Net.emit('notice',{k:'p2p_joining'});
    this.load().then(()=>{
      const peer=this.newPeer();const cli=this.cli={peer,conn:null,code};let ok=false;
      const bad=k=>{if(this.cli!==cli)return;this.cli=null;try{peer.destroy()}catch(e){}Net.emit('notice',{k:k||'bad_code'})};
      const to=setTimeout(()=>{if(!ok)bad('bad_code')},15000);
      peer.on('error',e=>{clearTimeout(to);if(!ok)bad(e&&e.type==='peer-unavailable'?'bad_code':'p2p_fail')});
      peer.on('open',()=>{
        const c=peer.connect('lrg-'+code,{reliable:true,serialization:'json'});cli.conn=c;
        c.on('open',()=>{clearTimeout(to);ok=true;c.send(Object.assign({t:'hi'},this.me()))});
        c.on('data',m=>{if(m&&m.t)Net.msg(m)});
        const gone=()=>{if(this.cli!==cli)return;this.cli=null;try{peer.destroy()}catch(e){}if(Net.party){const was=Net.party;Net.emit('disconnect');Net.msg({t:'party',code:null,reason:'host_left'})}};
        c.on('close',()=>{clearTimeout(to);if(ok)gone();else bad('bad_code')});c.on('error',()=>{if(ok)gone()});
      });
    },()=>this.fail());
  }
};

/* =====================================================================
   P2P friends — bina server ke UID se friend request (PeerJS id 'lrf-<UID>')
   Dono phone online hon tabhi request pahunchti hai; offline ho to har 20 sec dobara koshish.
   Friends / requests is phone me (localStorage) yaad rehte hain.
   ===================================================================== */
P2P.fr={
  d:{friends:[],inReq:[],outReq:[],acks:[]},on:{},seen:{},peer:null,timer:null,tries:0,
  load(){let d=null;try{d=JSON.parse(localStorage.getItem('lr_p2p_fr')||'null')}catch(e){}
    if(d&&Array.isArray(d.friends))this.d=Object.assign({friends:[],inReq:[],outReq:[],acks:[]},d)},
  save(){try{localStorage.setItem('lr_p2p_fr',JSON.stringify(this.d))}catch(e){}},
  sync(){
    const now=Date.now(),d=this.d;
    Net.friends=d.friends.map(f=>({uid:f.uid,name:f.name,online:!!(this.seen[f.uid]&&now-this.seen[f.uid]<50000),party:null}));
    Net.inReq=d.inReq.map(x=>({uid:x.uid,name:x.name}));Net.outReq=d.outReq.map(x=>({uid:x.uid,name:x.name}));
    Net.emit('change');
  },
  has(l,u){return this.d[l].find(x=>x.uid===u)},
  drop(l,u){this.d[l]=this.d[l].filter(x=>x.uid!==u)},
  addFriend(u,name){const f=this.has('friends',u);if(f){if(name)f.name=name}else this.d.friends.push({uid:u,name:name||u});this.drop('inReq',u);this.drop('outReq',u);this.save();this.sync()},
  init(){
    if(this.peer||!/^\d{8}$/.test(P2P.uid()))return;
    P2P.load().then(()=>{
      const mk=()=>{
        const peer=P2P.newPeer('lrf-'+P2P.uid());this.peer=peer;
        peer.on('open',()=>{this.tries=0;this.poll()});
        peer.on('connection',c=>this.incoming(c));
        peer.on('disconnected',()=>{try{peer.reconnect()}catch(e){}});
        peer.on('error',e=>{if(e&&e.type==='unavailable-id'&&this.peer===peer){try{peer.destroy()}catch(x){}this.peer=null;if(++this.tries<8)setTimeout(()=>{if(Net.mode==='p2p'&&!this.peer)mk()},5000)}});
      };mk();
    },()=>{});
    clearInterval(this.timer);this.timer=setInterval(()=>this.poll(),20000);
  },
  close(){clearInterval(this.timer);this.timer=null;if(this.peer){try{this.peer.destroy()}catch(e){}this.peer=null}},
  me(){return{uid:P2P.uid(),name:prof.name}},
  /* ek chhota message bhejo; cb(true,reply) agar pahunch gaya */
  talk(uid,msg,cb){
    const peer=this.peer;if(!peer||peer.destroyed||!peer.open){cb&&cb(false);return}
    let done=false;const end=(ok,r)=>{if(done)return;done=true;clearTimeout(to);try{c.close()}catch(e){}cb&&cb(ok,r)};
    const to=setTimeout(()=>end(false),9000);
    let c;try{c=peer.connect('lrf-'+uid,{reliable:true,serialization:'json'})}catch(e){end(false);return}
    c.on('open',()=>{try{c.send(Object.assign({f:msg.f},this.me(),msg))}catch(e){end(false)}});
    c.on('data',r=>{if(r&&r.f==='ack'){this.seen[uid]=Date.now();end(true,r)}});
    c.on('error',()=>end(false));c.on('close',()=>end(false));
  },
  incoming(c){
    c.on('data',m=>{
      if(!m||typeof m.f!=='string')return;const u=String(m.uid||''),name=String(m.name||u).slice(0,14);
      if(!/^\d{8}$/.test(u)||u===P2P.uid())return;
      this.seen[u]=Date.now();
      const reply=()=>{try{c.send({f:'ack',uid:P2P.uid(),name:prof.name})}catch(e){}};
      const d=this.d;
      switch(m.f){
        case'req':
          if(this.has('friends',u)){this.has('friends',u).name=name;this.save();this.talk(u,{f:'acc'});}
          else if(this.has('outReq',u)){this.addFriend(u,name);this.talk(u,{f:'acc'});Net.emit('notice',{k:'friends_now',name})}
          else if(!this.has('inReq',u)){if(d.inReq.length<30){d.inReq.push({uid:u,name});this.save();Net.emit('notice',{k:'got_request',name});try{snd('pick')}catch(e){}}}
          else this.has('inReq',u).name=name;
          this.sync();reply();break;
        case'acc':
          if(this.has('outReq',u)||this.has('friends',u)){const was=!!this.has('friends',u);this.addFriend(u,name);if(!was)Net.emit('notice',{k:'accepted',name})}
          reply();break;
        case'dec':case'cancel':this.drop(m.f==='dec'?'outReq':'inReq',u);this.save();this.sync();reply();break;
        case'rm':this.drop('friends',u);this.save();this.sync();reply();break;
        case'ping':{const f=this.has('friends',u);if(f&&f.name!==name){f.name=name;this.save()}reply();this.sync();break}
        case'inv':if(this.has('friends',u)&&/^\d{6}$/.test(String(m.code||''))){Net.msg({t:'invite',from:{uid:u,name},code:String(m.code)});reply()}break;
      }
    });
  },
  /* har 20 sec: bhejne baaki requests / accepts dobara, dosto ka online status */
  poll(){
    if(!this.peer||!this.peer.open)return;const d=this.d;
    for(const r of d.outReq.slice(0,8))this.talk(r.uid,{f:'req'},(ok,x)=>{if(ok&&x&&x.name&&x.name!==r.name){r.name=x.name;this.save();this.sync()}});
    for(const a of d.acks.slice(0,8))this.talk(a,{f:'acc'},ok=>{if(ok){d.acks=d.acks.filter(z=>z!==a);this.save()}});
    for(const f of d.friends.slice(0,12))this.talk(f.uid,{f:'ping'},(ok,x)=>{if(ok&&x&&x.name&&x.name!==f.name){f.name=x.name;this.save()}this.sync()});
    this.sync();
  },
  cmd(o){
    const d=this.d,u=String(o.uid||'').trim();
    if(!/^\d{8}$/.test(u)){Net.emit('notice',{k:'no_user'});return}
    switch(o.t){
      case'friend.add':{
        if(u===P2P.uid()){Net.emit('notice',{k:'self'});return}
        if(this.has('friends',u)){Net.emit('notice',{k:'already'});return}
        if(this.has('inReq',u)){this.cmd({t:'friend.accept',uid:u});return}
        if(this.has('outReq',u)){Net.emit('notice',{k:'pending'});return}
        d.outReq.push({uid:u,name:u});this.save();this.sync();
        if(!this.peer||!this.peer.open){this.init();Net.emit('notice',{k:'p2p_fr_wait'});return}
        this.talk(u,{f:'req'},(ok,x)=>{
          const r=this.has('outReq',u);
          if(ok){if(r&&x&&x.name)r.name=x.name;this.save();this.sync();Net.emit('notice',{k:'sent',name:(x&&x.name)||u})}
          else Net.emit('notice',{k:'p2p_fr_wait'});
        });break}
      case'friend.accept':{
        const r=this.has('inReq',u);if(!r)return;
        this.addFriend(u,r.name);if(!d.acks.includes(u))d.acks.push(u);this.save();
        this.talk(u,{f:'acc'},ok=>{if(ok){d.acks=d.acks.filter(z=>z!==u);this.save()}});
        Net.emit('notice',{k:'friends_now',name:r.name});break}
      case'friend.decline':this.drop('inReq',u);this.save();this.sync();this.talk(u,{f:'dec'});break;
      case'friend.cancel':this.drop('outReq',u);this.save();this.sync();this.talk(u,{f:'cancel'});break;
      case'friend.remove':this.drop('friends',u);this.save();this.sync();this.talk(u,{f:'rm'});break;
      case'party.invite':{
        if(!this.has('friends',u))return;
        const code=(P2P.hub&&P2P.hub.code)||(P2P.cli&&P2P.cli.code);
        if(!code){if((o._n=(o._n||0)+1)<=24)setTimeout(()=>this.cmd(o),500);return}   // group abhi ban raha hai — intezaar
        this.talk(u,{f:'inv',code},ok=>Net.emit('notice',ok?{k:'invited',name:(this.has('friends',u)||{}).name||u}:{k:'p2p_fr_off'}));break}
    }
  }
};
