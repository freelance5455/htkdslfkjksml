'use strict';
/* =====================================================================
   i18n.js — multi-language support (English is the source language)
   ---------------------------------------------------------------------
   T('English text {0}', arg)  ->  text in the chosen language (falls back to English).
   Keys are the English strings themselves. Translations live in js/lang/<id>.js
   (only the selected language file is loaded). English needs no file.
   Language is stored in set.lang (localStorage). Changing it reloads the lobby.
   To add a language: add it to I18N.langs and create js/lang/<id>.js with  I18N.dict={ "English":"Translated", ... }
   ===================================================================== */
const I18N={
  langs:[
    // ---- 10 Indian languages ----
    {id:'hi',n:'हिन्दी',en:'Hindi',grp:'in'},{id:'bn',n:'বাংলা',en:'Bengali',grp:'in',font:'Noto Sans Bengali'},
    {id:'te',n:'తెలుగు',en:'Telugu',grp:'in',font:'Noto Sans Telugu'},{id:'mr',n:'मराठी',en:'Marathi',grp:'in'},
    {id:'ta',n:'தமிழ்',en:'Tamil',grp:'in',font:'Noto Sans Tamil'},{id:'gu',n:'ગુજરાતી',en:'Gujarati',grp:'in',font:'Noto Sans Gujarati'},
    {id:'ur',n:'اردو',en:'Urdu',grp:'in',rtl:1,font:'Noto Naskh Arabic'},{id:'kn',n:'ಕನ್ನಡ',en:'Kannada',grp:'in',font:'Noto Sans Kannada'},
    {id:'ml',n:'മലയാളം',en:'Malayalam',grp:'in',font:'Noto Sans Malayalam'},{id:'pa',n:'ਪੰਜਾਬੀ',en:'Punjabi',grp:'in',font:'Noto Sans Gurmukhi'},
    // ---- 10 world languages ----
    {id:'en',n:'English',en:'English',grp:'world'},{id:'es',n:'Español',en:'Spanish',grp:'world'},
    {id:'fr',n:'Français',en:'French',grp:'world'},{id:'de',n:'Deutsch',en:'German',grp:'world'},
    {id:'pt',n:'Português',en:'Portuguese',grp:'world'},{id:'ru',n:'Русский',en:'Russian',grp:'world',font:'Noto Sans'},
    {id:'ar',n:'العربية',en:'Arabic',grp:'world',rtl:1,font:'Noto Sans Arabic'},{id:'ja',n:'日本語',en:'Japanese',grp:'world',font:'Noto Sans JP'},
    {id:'zh',n:'中文',en:'Chinese',grp:'world',font:'Noto Sans SC'},{id:'ko',n:'한국어',en:'Korean',grp:'world',font:'Noto Sans KR'}
  ],
  lang:'en',dict:{},fb:'',pending:false,
  info(id){return this.langs.find(l=>l.id===id)},
  /* language chosen by the user (read straight from the save before data.js loads) */
  saved(){try{const d=JSON.parse(localStorage.getItem('lastring_v2'));return d&&d.set&&d.set.lang||'en'}catch(e){return 'en'}},
  /* translate every static text node / aria-label in the page (HTML is written in English) */
  dom(root){
    if(this.lang==='en')return;
    const d=this.dict,w=document.createTreeWalker(root||document.body,NodeFilter.SHOW_TEXT);let n;
    while((n=w.nextNode())){
      const p=n.parentNode;if(p&&/^(SCRIPT|STYLE)$/.test(p.nodeName))continue;
      const m=/^(\s*)([\s\S]*?)(\s*)$/.exec(n.nodeValue);if(m[2]&&d[m[2]]!==undefined)n.nodeValue=m[1]+d[m[2]]+m[3];
    }
    (root||document).querySelectorAll('[aria-label]').forEach(e=>{const k=e.getAttribute('aria-label');if(d[k]!==undefined)e.setAttribute('aria-label',d[k])});
  },
  /* user picked a language in Settings */
  change(id){
    set.lang=id;save();
    if(typeof state==='undefined'||state==='lobby')location.reload();
    else{this.pending=true;toast(T('Language will change when you return to the lobby'))}
  }
};
function T(k,...a){
  const m=/^(\s*)([\s\S]*?)(\s*)$/.exec(k);let t=m[2];
  const d=I18N.dict[t];if(d!==undefined)t=d;
  if(a.length)t=t.replace(/\{(\d+)\}/g,(_,i)=>a[i]!==undefined?a[i]:'');
  return m[1]+t+m[3];
}
(function(){
  const id=I18N.saved(),L=I18N.info(id);
  if(!L)return;
  I18N.lang=id;document.documentElement.lang=id;
  if(L.rtl)document.documentElement.classList.add('rtl');
  if(L.font){
    I18N.fb="'"+L.font+"',";
    const lk=document.createElement('link');lk.rel='stylesheet';lk.href='https://fonts.googleapis.com/css2?family='+L.font.replace(/ /g,'+')+':wght@400;600;700&display=swap';
    document.head.appendChild(lk);
    const st=document.createElement('style');
    st.textContent=":root{--body:'Hind',"+I18N.fb+"system-ui,sans-serif;--display:'Teko','Hind',"+I18N.fb+"system-ui,sans-serif}";
    document.head.appendChild(st);
  }
  if(id!=='en')document.write('<script src="js/lang/'+id+'.js"><\/script>');   // loads synchronously, before data.js
})();
