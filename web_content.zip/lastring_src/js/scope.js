'use strict';
/* =====================================================================
   Scope — sniper (AWM / Kar98k / Hawk / DMR) ka scope.
   Scope button dabao: camera zoom-out hota hai (door tak dikhta hai, WP[x].sc),
   camera aim ki taraf aage jhaankta hai, auto-aim ki lock range hathiyaar ki poori range tak
   badh jaati hai, aur scope vignette + crosshair dikhta hai.
   Hathiyaar badalne / marne par scope apne-aap band.
   ===================================================================== */
const Scope={
  on:false,k:0,
  cfg:{peek:.16,lerp:7,vignette:.55},     // peek: aim ki taraf camera kitna aage (scope range ka fraction)
  w(){return player&&player.alive&&player.sl&&player.sl[player.cur]?WP[player.sl[player.cur].id]:null},
  can(){const w=this.w();return !!(w&&w.sc)},
  reset(){this.on=false;this.k=0;this.btn()},
  toggle(){
    if(state!=='play'||!player||!player.alive||player.air)return;
    if(!this.can()){toast(T('Equip a sniper rifle to use the scope'));return}
    this.on=!this.on;snd('click');this.btn();
  },
  btn(){const b=document.getElementById('bScope');if(!b)return;b.hidden=!(state==='play'&&this.can()&&!player.air);b.classList.toggle('on',this.on)},
  tick(dt){
    if(this.on&&(!this.can()||state!=='play'))this.on=false;
    this.k+=((this.on?1:0)-this.k)*Math.min(1,dt*this.cfg.lerp);
    if(this.k<.005&&!this.on)this.k=0;
    const sh=state==='play'&&this.can()&&!(player&&player.air);
    if(this._sh!==sh||this._on!==this.on){this._sh=sh;this._on=this.on;this.btn()}
  },
  // camera zoom multiplier (1 = normal)
  mul(){const w=this.w();return w&&w.sc&&this.k>0?lerp(1,w.sc,this.k):1},
  // camera offset: aim ki disha mein (world px)
  peekX(f){const w=this.w();return f===player&&w&&w.sc&&this.k>0?Math.cos(f.ang)*w.range*this.cfg.peek*this.k:0},
  peekY(f){const w=this.w();return f===player&&w&&w.sc&&this.k>0?Math.sin(f.ang)*w.range*this.cfg.peek*this.k:0},
  // screen-space overlay (draw() ke baad)
  draw(){
    if(this.k<.02||state==='lobby')return;
    const c=ctx,W=VW,H=VH,k=this.k;
    c.setTransform(DPR,0,0,DPR,0,0);
    const g=c.createRadialGradient(W/2,H/2,Math.min(W,H)*.34,W/2,H/2,Math.hypot(W,H)*.52);
    g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,'+(this.cfg.vignette*k).toFixed(2)+')');
    c.fillStyle=g;c.fillRect(0,0,W,H);
    c.save();c.globalAlpha=.75*k;c.strokeStyle='rgba(255,70,70,.9)';c.lineWidth=1.2;
    const cx=W/2,cy=H/2,r=Math.min(W,H)*.045;
    c.beginPath();c.moveTo(cx-r*5,cy);c.lineTo(cx-r*.7,cy);c.moveTo(cx+r*.7,cy);c.lineTo(cx+r*5,cy);c.moveTo(cx,cy-r*5);c.lineTo(cx,cy-r*.7);c.moveTo(cx,cy+r*.7);c.lineTo(cx,cy+r*5);c.stroke();
    c.beginPath();c.arc(cx,cy,r*2.6,0,TAU);c.stroke();c.restore();
  }
};
