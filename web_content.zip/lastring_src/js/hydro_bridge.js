'use strict';
/* =====================================================================
   hydro_bridge.js — 20 bridge styles.  base() = rotated local space (deck, players ke neeche)
   top() = world space, lifted + camera-parallax (rails, roofs, cables, towers — players ke upar)
   ===================================================================== */
const BMAT={wood:['#8d6b45','#7a5b3a','#9c7a52','#6e5234'],stone:['#a39d90','#8f897c','#b3ad9f','#7f7a6e'],metal:['#6a727a','#5a626a','#7a828a','#4a5258'],rope:['#8a7a4a','#756840','#9a8a58','#625632']};
Object.assign(Hydro,{
  LP(b,lx,ly,h){const x=b.cx+b.cs*lx-b.sn*ly,y=b.cy+b.sn*lx+b.cs*ly,k=this.pv?0:h*.0009;return[x+(x-cam.x)*k,y-h+(y-cam.y)*k*.5]},
  /* gap-aware segments of [x0,x1] */
  segs(b,x0,x1){if(b.g0==null)return[[x0,x1]];const o=[];if(b.g0>x0)o.push([x0,Math.min(x1,b.g0)]);if(b.g1<x1)o.push([Math.max(x0,b.g1),x1]);return o},
  planks(c,x0,x1,w,cols,pw,gap,jit){
    let i=0;for(let x=x0;x<x1-1;x+=pw+gap,i++){const j=jit?Math.sin(i*7.3)*jit:0;c.fillStyle=cols[i%cols.length];c.fillRect(x,-w+j*.4,Math.min(pw,x1-x),w*2-j*.8);c.fillStyle='rgba(255,255,255,.12)';c.fillRect(x,-w+j*.4,Math.min(pw,x1-x),1.2);c.fillStyle='rgba(0,0,0,.14)';c.fillRect(x,w-1.3-j*.4,Math.min(pw,x1-x),1.3)}
  },
  quad(c,pts,fill,stroke,lw){c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)c.lineTo(pts[i][0],pts[i][1]);c.closePath();if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw||1;c.stroke()}},
  wallTop(c,b,ly,h,th,top,side,x0,x1){
    for(const [a0,a1] of this.segs(b,x0,x1)){
      this.quad(c,[this.LP(b,a0,ly,0),this.LP(b,a1,ly,0),this.LP(b,a1,ly,h),this.LP(b,a0,ly,h)],side);
      this.quad(c,[this.LP(b,a0,ly-th/2,h),this.LP(b,a1,ly-th/2,h),this.LP(b,a1,ly+th/2,h),this.LP(b,a0,ly+th/2,h)],top);
    }
  },
  railTop(c,b,ly,h,col,lw,step,x0,x1,sag){
    c.strokeStyle=col;c.lineWidth=lw;c.lineCap='round';
    for(const [a0,a1] of this.segs(b,x0,x1)){
      c.beginPath();const n=Math.max(2,Math.round((a1-a0)/10));
      for(let i=0;i<=n;i++){const x=a0+(a1-a0)*i/n,u=(x+b.L/2)/b.L,p=this.LP(b,x,ly,h-(sag?sag*Math.sin(Math.PI*u):0));i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1])}
      c.stroke();
      if(step){c.lineWidth=lw*.8;c.beginPath();for(let x=a0;x<=a1+.1;x+=step){const u=(x+b.L/2)/b.L,p0=this.LP(b,x,ly,0),p1=this.LP(b,x,ly,h-(sag?sag*Math.sin(Math.PI*u):0));c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1])}c.stroke()}
    }
  },
  flag(c,b,lx,ly,h,col,ph){
    const p0=this.LP(b,lx,ly,0),p1=this.LP(b,lx,ly,h);c.strokeStyle='#3a2a1a';c.lineWidth=2;c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.stroke();
    c.fillStyle=col;c.beginPath();c.moveTo(p1[0],p1[1]);
    for(let i=1;i<=6;i++)c.lineTo(p1[0]+i*4.4+this.wind*2,p1[1]+Math.sin(time*5+i*.8+(ph||0))*2.2*i*.4);
    for(let i=6;i>=1;i--)c.lineTo(p1[0]+i*4.4+this.wind*2,p1[1]+9+Math.sin(time*5+i*.8+(ph||0))*2.2*i*.4);
    c.closePath();c.fill();
  },
  bridgeBase(c,b,fx){
    const v=b.v,a=b.L/2,w=b.W/2,S=BRS[v.id];
    c.save();c.translate(b.cx,b.cy);c.rotate(b.ang);
    // shadow on water (consistent light from top-left)
    const so=[7,11],lx=so[0]*b.cs+so[1]*b.sn,ly=-so[0]*b.sn+so[1]*b.cs;
    c.fillStyle='rgba(0,10,20,.26)';
    if(b.g0!=null){c.fillRect(-a+lx,-w+ly,b.g0+a,w*2);c.fillRect(b.g1+lx,-w+ly,a-b.g1,w*2)}
    else if(v.draw||v.swing){}
    else c.fillRect(-a+lx,-w+ly,b.L,w*2);
    S.base(c,b,a,w,fx);
    c.restore();
  },
  bridgeTop(c,b,fx){
    const v=b.v,a=b.L/2,w=b.W/2,S=BRS[v.id];
    if(S.top)S.top(c,b,a,w,fx,(lx,ly,h)=>this.LP(b,lx,ly,h));
  }
});

const BRS={
 /* 1 */ stone_arch:{
  base(c,b,a,w){const g=c.createLinearGradient(-a,0,a,0);g.addColorStop(0,'#8a8478');g.addColorStop(.5,'#b5af a2'.replace(' ',''));g.addColorStop(1,'#8a8478');c.fillStyle=g;c.fillRect(-a,-w,b.L,w*2);
    c.strokeStyle='rgba(60,54,44,.35)';c.lineWidth=1;c.beginPath();for(let x=-a+8;x<a;x+=9){c.moveTo(x,-w);c.lineTo(x,w)}for(let y=-w+10;y<w;y+=11){c.moveTo(-a,y);c.lineTo(a,y)}c.stroke();
    c.fillStyle='rgba(255,255,255,.16)';c.fillRect(-a,-w,b.L,2);c.fillStyle='#6a6458';c.beginPath();c.arc(0,0,5,0,TAU);c.fill()},
  top(c,b,a,w,fx,P){Hydro.wallTop(c,b,-w+3,11,6,'#c0baac','#8e887b',-a+4,a-4);Hydro.wallTop(c,b,w-3,11,6,'#c0baac','#8e887b',-a+4,a-4);
    c.strokeStyle='rgba(50,44,34,.4)';c.lineWidth=1;for(const s of[-1,1])for(let x=-a+12;x<a-8;x+=12){const p0=P(x,s*(w-3),0),p1=P(x,s*(w-3),11);c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.stroke()}}},
 /* 2 */ stone_slab:{
  base(c,b,a,w){const n=4,sw=b.L/n;for(let i=0;i<n;i++){const x=-a+i*sw+2;c.fillStyle='rgba(0,0,0,.28)';c.fillRect(x+2,-w+3,sw-3,w*2);c.fillStyle=i%2?'#9a9488':'#a8a296';c.fillRect(x,-w,sw-3,w*2);c.fillStyle='rgba(255,255,255,.2)';c.fillRect(x,-w,sw-3,2.5);c.fillStyle='rgba(60,90,40,.25)';c.beginPath();c.ellipse(x+sw*.5,-w+10+i*3,12,5,0,0,TAU);c.fill()
    if(i){c.fillStyle='#6e695e';c.fillRect(x-8,-w+4,10,w*2-8);c.fillStyle='rgba(255,255,255,.18)';c.fillRect(x-8,-w+4,10,2)}}}},
 /* 3 */ rope:{
  base(c,b,a,w){const sw=b.sw*5;c.strokeStyle='rgba(50,36,18,.7)';c.lineWidth=2;for(const s of[-1,1]){c.beginPath();for(let x=-a;x<=a;x+=8){const y=s*(w-2)+sw*Math.sin(Math.PI*(x+a)/b.L);x===-a?c.moveTo(x,y):c.lineTo(x,y)}c.stroke()}
    let i=0;for(let x=-a+4;x<a-4;x+=9,i++){const y=sw*Math.sin(Math.PI*(x+a)/b.L);c.fillStyle=BMAT.wood[i%3];c.fillRect(x,-w+3+y,7,w*2-6);c.fillStyle='rgba(0,0,0,.2)';c.fillRect(x,w-4+y,7,1.4)}},
  top(c,b,a,w,fx,P){Hydro.railTop(c,b,-w+2,22,'#8a7240',2.2,22,-a+4,a-4,6);Hydro.railTop(c,b,w-2,22,'#8a7240',2.2,22,-a+4,a-4,6);Hydro.railTop(c,b,-w+2,12,'#6e5a30',1.4,0,-a+4,a-4,3);Hydro.railTop(c,b,w-2,12,'#6e5a30',1.4,0,-a+4,a-4,3);
    Hydro.flag(c,b,-a+6,-w,34,'#d8452e',0);Hydro.flag(c,b,a-6,w,34,'#e8b030',2)}},
 /* 4 */ bamboo:{
  base(c,b,a,w){const n=7,bw=w*2/n;for(let i=0;i<n;i++){const y=-w+i*bw;c.fillStyle=i%2?'#b3a548':'#a09a3c';c.fillRect(-a,y,b.L,bw-.8);c.fillStyle='rgba(255,255,255,.22)';c.fillRect(-a,y,b.L,1.4);c.fillStyle='rgba(60,50,10,.5)';for(let x=-a+14+(i*5)%9;x<a;x+=28)c.fillRect(x,y,2,bw-.8)}
    c.fillStyle='#4a3a20';for(let x=-a+20;x<a;x+=44)c.fillRect(x,-w-1,3,w*2+2)},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){Hydro.railTop(c,b,s*(w+1),18,'#b8aa48',3,26,-a+3,a-3);Hydro.railTop(c,b,s*(w+1),9,'#a09a3c',2.2,0,-a+3,a-3)}
    c.lineWidth=1.6;const cl=['#e04a4a','#f2c94c','#4a9ae0','#e8e8e8','#5ac05a'];const p0=P(-a+4,-w,22),p1=P(a-4,-w,22);for(let i=0;i<10;i++){const u=i/10,u2=(i+1)/10,x0=p0[0]+(p1[0]-p0[0])*u,x1=p0[0]+(p1[0]-p0[0])*u2,y0=p0[1]+(p1[1]-p0[1])*u+Math.sin(time*3+i)*1.2,y1=p0[1]+(p1[1]-p0[1])*u2+Math.sin(time*3+i+1)*1.2;c.fillStyle=cl[i%5];c.beginPath();c.moveTo(x0,y0+3);c.lineTo(x1,y1+3);c.lineTo((x0+x1)/2,y0+12+Math.sin(time*4+i)*1.4);c.closePath();c.fill()}}},
 /* 5 */ vine:{
  base(c,b,a,w){c.lineCap='round';for(let k=0;k<5;k++){c.strokeStyle=k%2?'#3f6a2a':'#4d7a30';c.lineWidth=5.2;c.beginPath();for(let x=-a;x<=a;x+=8){const y=-w+3+k*(w*2-6)/4+Math.sin(x*.12+k*2)*3+b.sw*2*Math.sin(Math.PI*(x+a)/b.L);x===-a?c.moveTo(x,y):c.lineTo(x,y)}c.stroke()}
    c.fillStyle='#8a6a3a';for(let x=-a+10;x<a;x+=18)c.fillRect(x,-w+3,5,w*2-6);c.fillStyle='#5a9a38';for(let i=0;i<16;i++){c.beginPath();c.ellipse(-a+8+i*(b.L-16)/15,((i*37)%(w*2-8))-w+4,4,2.4,i,0,TAU);c.fill()}},
  top(c,b,a,w,fx,P){c.lineWidth=2.2;for(let i=0;i<18;i++){const x=-a+8+i*(b.L-16)/17,s=i%2?1:-1,L=22+(i*13)%26,sw=Hydro.wind*5+Math.sin(time*1.7+i)*3,p0=P(x,s*w,34),p1=P(x,s*w,34-L);c.strokeStyle='#3f7a2a';c.beginPath();c.moveTo(p0[0],p0[1]);c.quadraticCurveTo(p0[0]+sw*.5,(p0[1]+p1[1])/2,p1[0]+sw,p1[1]);c.stroke();c.fillStyle='#5aa83a';c.beginPath();c.ellipse(p1[0]+sw,p1[1],3.4,2.2,sw*.1,0,TAU);c.fill()}
    Hydro.railTop(c,b,-w,18,'#4d7a30',3,30,-a+4,a-4,5);Hydro.railTop(c,b,w,18,'#4d7a30',3,30,-a+4,a-4,5)}},
 /* 6 */ scrap:{
  base(c,b,a,w){for(const s of[-1,1])for(let x=-a+16;x<a-10;x+=46){c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.arc(x+2,s*(w+3)+3,8,0,TAU);c.fill();c.fillStyle='#3a5a8a';c.beginPath();c.arc(x,s*(w+3),8,0,TAU);c.fill();c.fillStyle='#b0b8c0';c.beginPath();c.arc(x,s*(w+3),6,0,TAU);c.fill();c.fillStyle='#2e4a70';c.beginPath();c.arc(x,s*(w+3),2.6,0,TAU);c.fill()}
    const cs=['#8a5a3a','#6a7a82','#7a4a36','#a08a56','#5a6a72','#94623a'];let x=-a,i=0;while(x<a){const sw=Math.min(a-x,20+(i*11)%18);c.fillStyle=cs[i%6];c.fillRect(x,-w,sw-1,w*2);c.fillStyle='rgba(0,0,0,.2)';c.fillRect(x,w-3,sw-1,3);c.fillStyle='rgba(255,255,255,.15)';c.fillRect(x,-w,sw-1,2);c.fillStyle='#caa';c.fillRect(x+3,-w+4,2,2);c.fillRect(x+3,w-8,2,2);x+=sw;i++}
    c.fillStyle='#e8c030';for(let k=0;k<4;k++){c.save();c.translate(-a+4+k*8,0);c.rotate(.6);c.fillRect(-2,-w,4,w*2);c.restore()}},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){Hydro.railTop(c,b,s*w,14,'#6a4a30',2.4,22,-a+3,a-3);Hydro.railTop(c,b,s*w,7,'#8a8a90',1.6,0,-a+3,a-3)}
    c.strokeStyle='rgba(60,60,60,.7)';c.lineWidth=1.2;const p0=P(-a+4,-w,14),p1=P(a-4,w,14);c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.stroke();Hydro.flag(c,b,a-4,-w,26,'#c8402a',1)}},
 /* 7 */ log:{
  base(c,b,a,w){const n=5,bw=w*2/n;for(let i=0;i<n;i++){const y=-w+i*bw,j=Math.sin(i*5)*3;c.fillStyle='rgba(0,0,0,.28)';c.fillRect(-a+j+2,y+3,b.L,bw);c.fillStyle=i%2?'#6a4a2e':'#795436';c.fillRect(-a+j,y,b.L,bw-.6);c.fillStyle='rgba(255,255,255,.14)';c.fillRect(-a+j,y,b.L,1.4);
    c.strokeStyle='rgba(30,18,8,.4)';c.lineWidth=.8;c.beginPath();for(let x=-a+j+6;x<a;x+=9){c.moveTo(x,y+1);c.lineTo(x+3,y+bw-1)}c.stroke();
    c.fillStyle='#b08a5a';c.beginPath();c.ellipse(-a+j,y+bw/2,3.4,bw/2-.4,0,0,TAU);c.fill();c.beginPath();c.ellipse(a+j,y+bw/2,3.4,bw/2-.4,0,0,TAU);c.fill();c.strokeStyle='#6a4a2a';c.lineWidth=.8;c.beginPath();c.ellipse(a+j,y+bw/2,1.7,bw/4,0,0,TAU);c.stroke()}
    c.fillStyle='rgba(70,120,50,.5)';for(let i=0;i<7;i++){c.beginPath();c.ellipse(-a+14+i*(b.L-28)/6,-w+6+(i*13)%(w*2-12),9,3,0,0,TAU);c.fill()}}},
 /* 8 */ covered:{
  base(c,b,a,w){Hydro.planks(c,-a,a,w,BMAT.wood,10,1.4);c.fillStyle='rgba(0,0,0,.18)';c.fillRect(-a,-w,b.L,5);c.fillRect(-a,w-5,b.L,5);c.fillStyle='#4a3420';for(let x=-a+6;x<a;x+=46){c.fillRect(x,-w,4,w*2)}},
  top(c,b,a,w,fx,P){
    for(const s of[-1,1])Hydro.wallTop(c,b,s*(w-2),24,4,'#7a5a3a','#5e4228',-a+2,a-2);
    c.fillStyle='rgba(20,12,4,.6)';for(const s of[-1,1])for(let x=-a+20;x<a-14;x+=40){Hydro.quad(c,[P(x,s*(w-2),7),P(x+22,s*(w-2),7),P(x+22,s*(w-2),19),P(x,s*(w-2),19)],'rgba(20,12,4,.55)')}
    for(let x=-a+3;x<=a-3;x+=22)Hydro.quad(c,[P(x,-w,26),P(x+9,-w,34),P(x+18,-w,26)].concat([P(x+18,w,26),P(x+9,w,34),P(x,w,26)]),null,'rgba(50,30,14,.65)',2);
    const g=c.createLinearGradient(0,P(0,-w,40)[1],0,P(0,w,26)[1]);
    for(let x=-a;x<a;x+=10){Hydro.quad(c,[P(x,-w-3,30),P(x+10,-w-3,30),P(x+10,0,44),P(x,0,44)],x/10%2?'rgba(120,56,34,.58)':'rgba(138,66,40,.58)');Hydro.quad(c,[P(x,w+3,30),P(x+10,w+3,30),P(x+10,0,44),P(x,0,44)],x/10%2?'rgba(96,44,28,.58)':'rgba(110,52,32,.58)')}
    c.globalCompositeOperation='lighter';const p=P(0,0,22),gg=c.createRadialGradient(p[0],p[1],0,p[0],p[1],34);gg.addColorStop(0,'rgba(255,190,90,'+(.35+.06*Math.sin(time*5)).toFixed(2)+')');gg.addColorStop(1,'rgba(255,190,90,0)');c.fillStyle=gg;c.beginPath();c.arc(p[0],p[1],34,0,TAU);c.fill();c.globalCompositeOperation='source-over';
    Hydro.flag(c,b,-a+4,0,56,'#b8302a',0);Hydro.flag(c,b,a-4,0,56,'#b8302a',3)}},
 /* 9 */ boardwalk:{
  base(c,b,a,w){for(const s of[-1,1])for(let x=-a+10;x<a;x+=34){c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.arc(x+2,s*(w+3)+3,5,0,TAU);c.fill();c.fillStyle='#4a3622';c.beginPath();c.arc(x,s*(w+3),4.4,0,TAU);c.fill();c.fillStyle='rgba(255,255,255,.18)';c.beginPath();c.arc(x-1,s*(w+3)-1,1.6,0,TAU);c.fill()}
    Hydro.planks(c,-a,a,w,BMAT.wood,8,1.8,1.5)},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){Hydro.railTop(c,b,s*(w+1),14,'#6e5234',2.6,34,-a+4,a-4);Hydro.railTop(c,b,s*(w+1),7,'#7a5c3a',1.6,0,-a+4,a-4)}
    c.globalCompositeOperation='lighter';for(let x=-a+30;x<a-20;x+=100)for(const s of[-1,1]){const p=P(x,s*(w+1),32);const gg=c.createRadialGradient(p[0],p[1],0,p[0],p[1],20);gg.addColorStop(0,'rgba(255,210,120,.5)');gg.addColorStop(1,'rgba(255,210,120,0)');c.fillStyle=gg;c.beginPath();c.arc(p[0],p[1],20,0,TAU);c.fill()}c.globalCompositeOperation='source-over';
    c.strokeStyle='#3a2a1a';c.lineWidth=2;for(let x=-a+30;x<a-20;x+=100)for(const s of[-1,1]){const p0=P(x,s*(w+1),0),p1=P(x,s*(w+1),30);c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.stroke();c.fillStyle='#ffe0a0';c.fillRect(p1[0]-3,p1[1]-4,6,6)}}},
 /* 10 */ railway:{
  base(c,b,a,w){c.fillStyle='#7a766e';c.fillRect(-a,-w,b.L,w*2);c.fillStyle='rgba(0,0,0,.15)';for(let i=0;i<60;i++)c.fillRect(-a+(i*37)%b.L,-w+(i*13)%(w*2),2,2);
    c.fillStyle='#3e2e22';for(let x=-a+3;x<a;x+=11)c.fillRect(x,-w+4,6,w*2-8);
    for(const s of[-1,1]){c.fillStyle='#9aa0a8';c.fillRect(-a,s*(w*.4)-1.6,b.L,3.2);c.fillStyle='rgba(255,255,255,.6)';c.fillRect(-a,s*(w*.4)-1.6,b.L,1)}
    c.fillStyle='#585e66';c.fillRect(-a,-w,b.L,3);c.fillRect(-a,w-3,b.L,3)},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){Hydro.wallTop(c,b,s*(w+1),13,5,'#7a828a','#4e555c',-a+1,a-1);c.fillStyle='#c8ccd0';for(let x=-a+8;x<a;x+=16){const p=P(x,s*(w+1),13);c.fillRect(p[0]-1,p[1]-1,2,2)}}
    const p=P(a-8,w+4,44),p0=P(a-8,w+4,0);c.strokeStyle='#40464c';c.lineWidth=3;c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p[0],p[1]);c.stroke();const on=Math.sin(time*2)>0;c.fillStyle=on?'#ff3a2a':'#4a1410';c.beginPath();c.arc(p[0],p[1]-4,4.5,0,TAU);c.fill();c.fillStyle=on?'#2a1a14':'#3aff6a';c.beginPath();c.arc(p[0],p[1]+4,4.5,0,TAU);c.fill();
    if(on){c.globalCompositeOperation='lighter';const gg=c.createRadialGradient(p[0],p[1]-4,0,p[0],p[1]-4,18);gg.addColorStop(0,'rgba(255,60,40,.5)');gg.addColorStop(1,'rgba(255,60,40,0)');c.fillStyle=gg;c.beginPath();c.arc(p[0],p[1]-4,18,0,TAU);c.fill();c.globalCompositeOperation='source-over'}}},
 /* 11 */ suspension:{
  base(c,b,a,w){c.fillStyle='#5a626a';c.fillRect(-a,-w,b.L,w*2);c.strokeStyle='rgba(255,255,255,.12)';c.lineWidth=1;c.beginPath();for(let x=-a;x<a;x+=6){c.moveTo(x,-w+2);c.lineTo(x,w-2)}c.stroke();c.fillStyle='#d8c040';for(let x=-a+8;x<a;x+=26)c.fillRect(x,-1,12,2);c.fillStyle='rgba(255,255,255,.18)';c.fillRect(-a,-w,b.L,2);
    for(const s of[-1,1])for(const e of[-1,1]){c.fillStyle='#4a5258';c.fillRect(e*(a-8)-6,s*(w+9)-6,12,12);c.fillStyle='rgba(255,255,255,.2)';c.fillRect(e*(a-8)-6,s*(w+9)-6,12,2)}},
  top(c,b,a,w,fx,P){
    for(const e of[-1,1]){for(const s of[-1,1]){const p0=P(e*(a-8),s*(w+9),0),p1=P(e*(a-8),s*(w+9),70);c.strokeStyle='#8a929a';c.lineWidth=5;c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.stroke()}
      const q0=P(e*(a-8),-(w+9),64),q1=P(e*(a-8),w+9,64);c.strokeStyle='#7a828a';c.lineWidth=4;c.beginPath();c.moveTo(q0[0],q0[1]);c.lineTo(q1[0],q1[1]);c.stroke()}
    for(const s of[-1,1]){c.strokeStyle='#caced2';c.lineWidth=2.2;c.beginPath();for(let i=0;i<=24;i++){const u=i/24,x=-(a-8)+(b.L-16)*u,p=P(x,s*(w+9),70-56*Math.sin(Math.PI*u));i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1])}c.stroke();
      c.strokeStyle='rgba(180,186,192,.7)';c.lineWidth=1;c.beginPath();for(let x=-(a-8)+10;x<a-8;x+=14){const u=(x+a-8)/(b.L-16),p0=P(x,s*(w+9),70-56*Math.sin(Math.PI*u)),p1=P(x,s*(w+9),6);c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1])}c.stroke()}
    Hydro.flag(c,b,-(a-8),0,84,'#e8e8e8',0);Hydro.flag(c,b,a-8,0,84,'#e8e8e8',2)}},
 /* 12 */ cable_stayed:{
  base(c,b,a,w){c.fillStyle='#8a9096';c.fillRect(-a,-w,b.L,w*2);c.fillStyle='#4a5056';c.fillRect(-a,-w,b.L,5);c.fillRect(-a,w-5,b.L,5);c.fillStyle='rgba(255,255,255,.85)';for(let x=-a+6;x<a;x+=22)c.fillRect(x,-1.2,11,2.4);c.fillStyle='rgba(255,255,255,.18)';c.fillRect(-a,-w+5,b.L,1.5);
    for(const s of[-1,1]){c.fillStyle='#6a7076';c.fillRect(-10,s*(w+10)-7,20,14)}},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){const p0=P(0,s*(w+10),0),p1=P(0,s*(w+10),104);c.strokeStyle='#caced4';c.lineWidth=6;c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.stroke()}
    const q0=P(0,-(w+10),88),q1=P(0,w+10,88);c.strokeStyle='#caced4';c.lineWidth=4;c.beginPath();c.moveTo(q0[0],q0[1]);c.lineTo(q1[0],q1[1]);c.stroke();
    c.lineWidth=1.3;for(const s of[-1,1]){const top=P(0,s*(w+10),100);for(let i=1;i<=7;i++){for(const e of[-1,1]){const x=e*i*(a-12)/7,p=P(x,s*(w-2),4),hh=100-i*4;const tp=P(0,s*(w+10),hh);c.strokeStyle=i%2?'rgba(240,200,80,.85)':'rgba(230,236,240,.8)';c.beginPath();c.moveTo(tp[0],tp[1]);c.lineTo(p[0],p[1]);c.stroke()}}}
    Hydro.flag(c,b,0,-(w+10),118,'#ff7a2a',1);Hydro.flag(c,b,0,w+10,118,'#2a9aff',3);
    for(const s of[-1,1])Hydro.railTop(c,b,s*(w-1),9,'#b8bcc2',1.8,24,-a+3,a-3)}},
 /* 13 */ broken:{
  base(c,b,a,w){const g0=b.g0,g1=b.g1;const side=(x0,x1,jag)=>{if(x1-x0<4)return;let i=0;for(let x=x0;x<x1;x+=10,i++){const miss=(i*7)%11===0;if(miss)continue;const L=jag&&x+10>x1?(x1-x):9;c.fillStyle=BMAT.wood[i%4];c.fillRect(x,-w+(i%3),Math.min(9,L),w*2-(i%3)*2);c.fillStyle='rgba(255,255,255,.1)';c.fillRect(x,-w+(i%3),Math.min(9,L),1.2)}c.fillStyle='#4a3420';c.fillRect(x0,-w,x1-x0,2.4);c.fillRect(x0,w-2.4,x1-x0,2.4)};side(-a,g0,1);side(g1,a,0);
    for(let i=0;i<5;i++){const x=g0+((i*41+time*6)%(g1-g0)),y=Math.sin(i*3.7+time*.8)*(w-6);c.save();c.translate(x,y);c.rotate(i+time*.2);c.fillStyle='#6e5234';c.fillRect(-8,-2.5,16,5);c.restore()}},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){Hydro.railTop(c,b,s*w,13,'#6e5234',2.2,24,-a+4,b.g0-2);Hydro.railTop(c,b,s*w,13,'#6e5234',2.2,24,b.g1+2,a-4)}
    c.strokeStyle='#8a7a4a';c.lineWidth=1.8;for(const s of[-1,1]){const p0=P(b.g0-2,s*w,13);c.beginPath();c.moveTo(p0[0],p0[1]);c.quadraticCurveTo(p0[0]+4+Hydro.wind*3,p0[1]+14,p0[0]+8+Hydro.wind*5+Math.sin(time*2+s)*3,p0[1]+26);c.stroke();const p1=P(b.g1+2,s*w,13);c.beginPath();c.moveTo(p1[0],p1[1]);c.quadraticCurveTo(p1[0]-4+Hydro.wind*3,p1[1]+14,p1[0]-8+Hydro.wind*5+Math.sin(time*2+s+1)*3,p1[1]+26);c.stroke()}
    const p=P(-a+8,-w-2,26),p0=P(-a+8,-w-2,0);c.strokeStyle='#40464c';c.lineWidth=2;c.beginPath();c.moveTo(p0[0],p0[1]);c.lineTo(p[0],p[1]);c.stroke();Hydro.quad(c,[[p[0]-9,p[1]-8],[p[0]+9,p[1]-8],[p[0]+9,p[1]+5],[p[0]-9,p[1]+5]],'#e8e0d0','#c8302a',2);c.strokeStyle='#c8302a';c.lineWidth=2;c.beginPath();c.moveTo(p[0]-6,p[1]-5);c.lineTo(p[0]+6,p[1]+2);c.moveTo(p[0]+6,p[1]-5);c.lineTo(p[0]-6,p[1]+2);c.stroke()}},
 /* 14 */ plank:{
  base(c,b,a,w){c.fillStyle='#4a3420';c.fillRect(-a,-w+4,b.L,3);c.fillRect(-a,w-7,b.L,3);let x=-a,i=0;while(x<a){const pw=7+(i*5)%7,g=1+(i*3)%4;if((i*13)%17!==5){c.fillStyle=BMAT.wood[i%4];const ww=w*2-(i%4)*2;c.fillRect(x,-w+(i%3),Math.min(pw,a-x),ww);c.fillStyle='rgba(255,255,255,.12)';c.fillRect(x,-w+(i%3),Math.min(pw,a-x),1.2)}x+=pw+g;i++}}},
 /* 15 */ living_root:{
  base(c,b,a,w){c.fillStyle='rgba(30,22,12,.55)';c.fillRect(-a,-w,b.L,w*2);c.lineCap='round';
    for(let k=0;k<6;k++){c.strokeStyle=k%2?'#5a3e26':'#6a4a2e';c.lineWidth=5+k%3*1.6;c.beginPath();for(let x=-a;x<=a;x+=6){const y=-w+3+k*(w*2-6)/5+Math.sin(x*.09+k*1.7)*5;x===-a?c.moveTo(x,y):c.lineTo(x,y)}c.stroke();c.strokeStyle='rgba(255,230,180,.14)';c.lineWidth=1.4;c.beginPath();for(let x=-a;x<=a;x+=6){const y=-w+1+k*(w*2-6)/5+Math.sin(x*.09+k*1.7)*5;x===-a?c.moveTo(x,y):c.lineTo(x,y)}c.stroke()}
    c.strokeStyle='#4e3420';c.lineWidth=3;c.beginPath();for(let x=-a+14;x<a;x+=26){c.moveTo(x,-w);c.quadraticCurveTo(x+8,0,x-4,w)}c.stroke();
    c.fillStyle='rgba(80,140,50,.5)';for(let i=0;i<22;i++){c.beginPath();c.ellipse(-a+(i*47)%b.L,-w+(i*19)%(w*2),6,2.8,i,0,TAU);c.fill()}},
  top(c,b,a,w,fx,P){c.lineWidth=1.8;for(let i=0;i<16;i++){const x=-a+10+i*(b.L-20)/15,s=i%2?1:-1,L=18+(i*11)%26,sw=Hydro.wind*4+Math.sin(time*1.4+i)*2.4,p0=P(x,s*(w+2),32),p1=P(x,s*(w+2),32-L);c.strokeStyle='#5a3e26';c.beginPath();c.moveTo(p0[0],p0[1]);c.quadraticCurveTo(p0[0]+sw*.4,(p0[1]+p1[1])/2,p1[0]+sw,p1[1]);c.stroke();if(i%3===0){c.fillStyle='#4a9a3a';c.beginPath();c.ellipse(p1[0]+sw,p1[1],3.6,2.2,sw*.1,0,TAU);c.fill()}}
    for(const s of[-1,1])Hydro.railTop(c,b,s*(w+2),11,'#5a3e26',3.2,0,-a+6,a-6,3)}},
 /* 16 */ steel_truss:{
  base(c,b,a,w){c.fillStyle='#4a5056';c.fillRect(-a,-w,b.L,w*2);c.strokeStyle='rgba(255,255,255,.1)';c.lineWidth=1;c.beginPath();for(let x=-a;x<a;x+=5){c.moveTo(x,-w+4);c.lineTo(x,w-4)}c.stroke();c.fillStyle='rgba(255,255,255,.6)';for(let x=-a+8;x<a;x+=22)c.fillRect(x,-.8,11,1.6);c.fillStyle='#caa040';c.fillRect(-a,-w,b.L,3);c.fillRect(-a,w-3,b.L,3);
    for(const s of[-1,1])for(let x=-a+4;x<a;x+=b.L/8){c.fillStyle='#3a4046';c.fillRect(x-3,s*(w+3)-3,6,6)}},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){const y=s*(w+1);Hydro.railTop(c,b,y,32,'#7a8a9a',3.4,0,-a+2,a-2);Hydro.railTop(c,b,y,0,'#6a7a8a',2.6,0,-a+2,a-2);
      c.strokeStyle='#8a9aaa';c.lineWidth=2;c.beginPath();const n=8,sw=b.L/n;for(let i=0;i<n;i++){const x0=-a+i*sw,x1=x0+sw,p0=P(x0,y,0),p1=P(x0+sw/2,y,32),p2=P(x1,y,0);c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1]);c.lineTo(p2[0],p2[1])}c.stroke();
      c.lineWidth=1.3;c.strokeStyle='#5a6a7a';c.beginPath();for(let i=0;i<=n;i++){const x=-a+i*sw,p0=P(x,y,0),p1=P(x,y,32);c.moveTo(p0[0],p0[1]);c.lineTo(p1[0],p1[1])}c.stroke()}
    for(const e of[-1,1]){const q0=P(e*(a-4),-(w+1),32),q1=P(e*(a-4),w+1,32);c.strokeStyle='#7a8a9a';c.lineWidth=3;c.beginPath();c.moveTo(q0[0],q0[1]);c.lineTo(q1[0],q1[1]);c.stroke()}}},
 /* 17 */ drawbridge:{
  base(c,b,a,w){const k=b.ang01,sx=Math.max(.14,1-k*.86);
    c.save();c.translate(-a,0);c.scale(sx,1);Hydro.planks(c,0,b.L,w,BMAT.wood,10,1.4);c.fillStyle='#3a2a18';c.fillRect(0,-w,b.L,3);c.fillRect(0,w-3,b.L,3);c.restore();
    if(k>.3){c.fillStyle='rgba(8,24,36,.35)';c.fillRect(-a+b.L*sx,-w,b.L*(1-sx),w*2)}
    for(const e of[-1,1]){c.fillStyle='rgba(0,0,0,.3)';c.fillRect(e*a+(e>0?0:-26)+3,-w-9,26,w*2+18);c.fillStyle='#8a867c';c.fillRect(e*a+(e>0?0:-26),-w-10,26,w*2+20);c.fillStyle='rgba(255,255,255,.2)';c.fillRect(e*a+(e>0?0:-26),-w-10,26,2)}},
  top(c,b,a,w,fx,P){const k=b.ang01,sx=Math.max(.14,1-k*.86);
    c.strokeStyle='#5a5048';c.lineWidth=1.6;for(const s of[-1,1]){c.beginPath();for(let i=0;i<=10;i++){const x=-a+b.L*sx*i/10,p=P(x,s*(w-1),(1-i/10)*(14+k*26)+(i/10)*(8));i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1])}c.stroke()}
    for(const e of[-1,1]){const x=e>0?a:-a-26;for(const s of[-1,1]){const y=s*(w+10);Hydro.quad(c,[P(x,y-10,0),P(x+26,y-10,0),P(x+26,y-10,46),P(x,y-10,46)],'#6e6a60');Hydro.quad(c,[P(x,y-10,46),P(x+26,y-10,46),P(x+26,y+10,46),P(x,y+10,46)],'#a8a498');c.fillStyle='#8a867c';for(let m=0;m<3;m++){const p=P(x+m*10,y+(s>0?9:-9),52);c.fillRect(p[0],p[1],6,6)}}}
    Hydro.flag(c,b,-a-13,-(w+10),70,'#c8302a',0);Hydro.flag(c,b,a+13,w+10,70,'#c8302a',2)}},
 /* 18 */ aqueduct:{
  base(c,b,a,w){c.fillStyle='#9a9488';c.fillRect(-a,-w,b.L,w*2);c.fillStyle='#5a98b0';c.fillRect(-a,-w*.38,b.L,w*.76);c.fillStyle='rgba(255,255,255,.3)';c.save();c.beginPath();c.rect(-a,-w*.38,b.L,w*.76);c.clip();for(let x=-a-30+((time*34)%30);x<a;x+=30)c.fillRect(x,-w*.2,14,1.6),c.fillRect(x+9,w*.12,10,1.4);c.restore();
    c.fillStyle='rgba(0,0,0,.2)';c.fillRect(-a,-w*.38,b.L,2);c.strokeStyle='rgba(60,54,44,.3)';c.lineWidth=1;c.beginPath();for(let x=-a+9;x<a;x+=9){c.moveTo(x,-w);c.lineTo(x,-w*.38);c.moveTo(x,w*.38);c.lineTo(x,w)}c.stroke();
    for(const s of[-1,1])for(let x=-a+30;x<a-20;x+=58){c.fillStyle='rgba(0,0,0,.3)';c.fillRect(x+3,s*(w+2)-5+3,14,10);c.fillStyle='#8a847a';c.fillRect(x,s*(w+2)-5,14,10);c.fillStyle='rgba(255,255,255,.2)';c.fillRect(x,s*(w+2)-5,14,2)}},
  top(c,b,a,w,fx,P){for(const s of[-1,1]){Hydro.wallTop(c,b,s*(w-2),14,5,'#bab4a6','#8a8478',-a+3,a-3);c.fillStyle='rgba(30,26,18,.5)';for(let x=-a+8;x<a-14;x+=22){const p0=P(x,s*(w-2),1),p1=P(x+12,s*(w-2),1),p2=P(x+6,s*(w-2),11);c.beginPath();c.moveTo(p0[0],p0[1]);c.quadraticCurveTo(p2[0],p2[1]-6,p1[0],p1[1]);c.closePath();c.fill()}}}},
 /* 19 */ swing:{
  base(c,b,a,w){const k=b.ang01;
    c.fillStyle='rgba(30,36,44,.9)';c.beginPath();c.arc(0,0,w+9,0,TAU);c.fill();c.strokeStyle='#8a9098';c.lineWidth=2;c.beginPath();c.arc(0,0,w+9,0,TAU);c.stroke();
    c.save();c.rotate(k*Math.PI*.47);c.fillStyle='rgba(0,0,0,.28)';c.fillRect(-a+3,-w+5,b.L,w*2);c.fillStyle='#646c74';c.fillRect(-a,-w,b.L,w*2);c.strokeStyle='rgba(255,255,255,.12)';c.lineWidth=1;c.beginPath();for(let x=-a;x<a;x+=7){c.moveTo(x,-w+2);c.lineTo(x,w-2)}c.stroke();c.fillStyle='#e8c030';c.fillRect(-a,-w,b.L,3);c.fillRect(-a,w-3,b.L,3);c.fillStyle='#3a4046';c.beginPath();c.arc(0,0,11,0,TAU);c.fill();c.strokeStyle='#9aa0a8';c.lineWidth=1.5;for(let i=0;i<8;i++){c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(i*.785)*10,Math.sin(i*.785)*10);c.stroke()}c.restore()},
  top(c,b,a,w,fx,P){const k=b.ang01;c.save();const pc=P(0,w+14,0);
    Hydro.quad(c,[P(-10,w+8,0),P(10,w+8,0),P(10,w+8,30),P(-10,w+8,30)],'#a8a49a');Hydro.quad(c,[P(-10,w+8,30),P(10,w+8,30),P(10,w+22,30),P(-10,w+22,30)],'#c8c4ba');
    Hydro.quad(c,[P(-6,w+10,12),P(6,w+10,12),P(6,w+10,22),P(-6,w+10,22)],'rgba(120,180,230,.7)');
    const on=Math.sin(time*4)>0&&(k>0&&k<1),p=P(0,w+15,40);c.fillStyle=on?'#ffb020':'#5a3a10';c.beginPath();c.arc(p[0],p[1],4,0,TAU);c.fill();c.restore();
    if(k<.15)for(const s of[-1,1])Hydro.railTop(c,b,s*w,12,'#9aa0a8',2,22,-a+4,a-4)}},
 /* 20 */ pontoon:{
  base(c,b,a,w){const bob=Math.sin(time*1.6+b.t0)*1.4;c.save();c.translate(0,bob*.5);
    for(let x=-a+12;x<a-6;x+=30){for(const s of[-1,1]){c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.ellipse(x+2,s*(w*.55)+4,13,6,0,0,TAU);c.fill();c.fillStyle=(x/30|0)%2?'#2e5a8a':'#7a3a2a';c.beginPath();c.ellipse(x,s*(w*.55),13,6.4,0,0,TAU);c.fill();c.fillStyle='rgba(255,255,255,.25)';c.beginPath();c.ellipse(x-2,s*(w*.55)-2,8,2,0,0,TAU);c.fill()}}
    Hydro.planks(c,-a,a,w,BMAT.wood,11,1.6);c.fillStyle='rgba(0,0,0,.2)';c.fillRect(-a,w-3,b.L,3);c.restore();
    c.strokeStyle='rgba(70,56,36,.8)';c.lineWidth=1.6;c.beginPath();c.moveTo(-a,-w);c.lineTo(-a-18,-w-8);c.moveTo(a,w);c.lineTo(a+18,w+8);c.stroke()},
  top(c,b,a,w,fx,P){const bob=Math.sin(time*1.6+b.t0)*1.4;for(const s of[-1,1])Hydro.railTop(c,b,s*w,12,'#8a6a44',2,34,-a+4,a-4);
    for(let x=-a+40;x<a-20;x+=80){const p=P(x,-w,28),p0=P(x,-w,0);c.strokeStyle='#3a2a1a';c.lineWidth=2;c.beginPath();c.moveTo(p0[0],p0[1]+bob);c.lineTo(p[0],p[1]+bob);c.stroke();c.globalCompositeOperation='lighter';const gg=c.createRadialGradient(p[0],p[1]+bob,0,p[0],p[1]+bob,14);gg.addColorStop(0,'rgba(255,220,130,.5)');gg.addColorStop(1,'rgba(255,220,130,0)');c.fillStyle=gg;c.beginPath();c.arc(p[0],p[1]+bob,14,0,TAU);c.fill();c.globalCompositeOperation='source-over'}
    Hydro.flag(c,b,-a+4,w,30,'#e8b030',0);Hydro.flag(c,b,a-4,-w,30,'#2a9aff',2)}}
};
