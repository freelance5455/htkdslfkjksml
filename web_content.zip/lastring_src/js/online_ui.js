'use strict';
/* =====================================================================
   Online UI — Friends & Party panel, lobby team chip, invite banner
   ===================================================================== */
const Online={
  NOTICE:{
    no_user:()=>T('No player found with that UID'),self:()=>T('That is your own UID'),already:()=>T('You are already friends'),
    pending:()=>T('Request already sent'),too_many:()=>T('That player has too many pending requests'),
    friends_now:n=>T('You and {0} are now friends',n),sent:n=>T('Friend request sent to {0}',n),got_request:n=>T('{0} sent you a friend request',n),
    accepted:n=>T('{0} accepted your friend request',n),bad_code:()=>T('Invalid team code'),party_full:()=>T('That team is full'),
    party_busy:()=>T('That team is already in a match'),invited:n=>T('Invite sent to {0}',n),need_two:()=>T('Invite at least one teammate first'),
    kicked:()=>T('You were removed from the team'),
    p2p_fr_wait:()=>T('Request saved — it is delivered when your friend opens the game'),p2p_fr_off:()=>T('Friend seems offline — try again'),p2p_nofriends:()=>T('Friends need a server — in direct mode use Make group / Join group'),p2p_fail:()=>T('Could not connect — check internet and try again'),p2p_joining:()=>T('Joining group…'),p2p_creating:()=>T('Making group…')
  },
  keep:{},tab:'f',
  invite(uid){
    if(!Net.party){Net.send({t:'party.create'});setTimeout(()=>Net.send({t:'party.invite',uid}),400)}else Net.send({t:'party.invite',uid});snd('click')},
  need(){if(!Net.ok){toast(T('Not connected'));if(!Net.url())this.tab='f';openPanel('online');if(Net.url()&&!Net.ws)Net.connect();return false}return true},
  /* lobby: dost-strip (map selector ke upar) + make/join group icons + profile click */
  strip(){
    const e=$('lFriends');if(!e)return;
    if(!Net.ok||!Net.friends.length||state!=='lobby'){e.hidden=true;return}
    e.hidden=false;e.innerHTML='';
    const fl=Net.friends.slice().sort((a,b)=>(b.online-a.online)||a.name.localeCompare(b.name));
    for(const f of fl){
      const inTeam=Net.party&&Net.party.members.some(m=>m.uid===f.uid);
      const r=h('div',{class:'lf'+(f.online&&!inTeam?' on':'')},h('span',{class:'oldot '+(f.online?'on':'')}),h('div',null,h('b',null,f.name),h('small',null,'UID '+f.uid)));
      if(f.online&&!inTeam)r.onclick=()=>this.invite(f.uid);
      e.append(r);
    }
  },
  grp(){
    const b=$('bGrp');if(!b)return;const p=Net.party;
    b.classList.toggle('on',!!p);$('bGrpCode').textContent=p?p.code:'';$('bLeaveG').hidden=!p;
    if(p)$('lJoinRow').hidden=true;
  },
  bind(){
    $('lobby').querySelector('.prof').onclick=()=>{snd('click');openPanel('profile')};
    $('bGrp').onclick=()=>{snd('click');if(Net.party){this.copy(Net.party.code);return}if(this.need())Net.send({t:'party.create'})};
    $('bLeaveG').onclick=()=>{snd('click');Net.send({t:'party.leave'})};
    $('bJoin').onclick=()=>{snd('click');const r=$('lJoinRow');r.hidden=!r.hidden;if(!r.hidden)$('lJoinIn').focus()};
    const go=()=>{const v=$('lJoinIn').value.replace(/\D/g,'');if(v.length!==6){toast(T('Invalid team code'));return}if(!this.need())return;Net.send({t:'party.join',code:v});$('lJoinIn').value='';$('lJoinRow').hidden=true};
    $('lJoinOk').onclick=go;$('lJoinIn').onkeydown=e=>{if(e.key==='Enter')go()};
  },
  init(){
    this.bind();
    Net.on('notice',m=>{const f=this.NOTICE[m.k];if(f)toast(f(m.name));if(m.k==='got_request')snd('pick')});
    Net.on('change',()=>this.changed());
    Net.on('invite',m=>{snd('pick');this.banner()});
    Net.on('party',(p,prev)=>{if(!prev||prev.code!==p.code){if(pname!=='online'&&state==='lobby')toast(T('Team {0} · {1}/{2}',p.code,p.members.length,p.max))}});
    Net.on('partyLeft',()=>{this.chip();this.grp()});
    if(set.online!==false)Net.connect();
  },
  changed(){
    this.chip();this.banner();this.dot();this.strip();this.grp();
    if((pname==='online'||pname==='profile')&&!$('panel').hidden)this.refresh();
  },
  refresh(){                                              // panel dobara banao, input / scroll bachakar
    const b=pb(),st=b?b.scrollTop:0;
    for(const id of['ouid','ocode','ochat','osrv']){const e=$(id);if(e)this.keep[id]=e.value}
    const f=document.activeElement&&document.activeElement.id;
    render();
    const nb=pb();if(nb)nb.scrollTop=st;
    for(const id in this.keep){const e=$(id);if(e)e.value=this.keep[id]}
    if(f&&$(f)){try{$(f).focus()}catch(e){}}
  },
  /* lobby par chhota badge: friend request / invite aaye to laal dot, team ho to code */
  dot(){const b=document.getElementById('olBtn');if(!b)return;const n=Net.inReq.length+Net.invites.length;b.classList.toggle('alert',n>0);
    const s=b.querySelector('small');if(s)s.textContent=Net.ok?(Net.party?'TEAM '+Net.party.code:(Net.mode==='p2p'?'DIRECT':'ONLINE')):'OFFLINE'},
  chip(){
    let c=document.getElementById('teamChip');
    const p=Net.party;
    if(!p||state!=='lobby'){if(c)c.hidden=true;return}
    if(!c){c=document.createElement('button');c.id='teamChip';c.onclick=()=>{snd('click');openPanel('online')};(document.querySelector('.lright')||$('lobby')).prepend(c)}
    c.hidden=false;c.innerHTML='';
    c.append(h('b',null,'👥 '+T('Team {0}',p.code)),h('small',null,p.members.map(m=>m.name).join(' · ')+'  ('+p.members.length+'/'+p.max+')'));
  },
  banner(){
    Net.invites=Net.invites.filter(i=>Date.now()-i.t<60000);
    let b=document.getElementById('invBar');
    const i=Net.invites[Net.invites.length-1];
    if(!i||state!=='lobby'||Net.party&&Net.party.code===i.code){if(b)b.hidden=true;return}
    if(!b){b=document.createElement('div');b.id='invBar';$('lobby').append(b)}
    b.hidden=false;b.innerHTML='';
    b.append(h('span',null,T('{0} invited you to their team',i.from.name)),
      h('button',{class:'sm pri',onclick:()=>{Net.invites=Net.invites.filter(x=>x!==i);Net.send({t:'party.join',code:i.code});snd('click');this.banner()}},T('Join')),
      h('button',{class:'sm',onclick:()=>{Net.invites=Net.invites.filter(x=>x!==i);this.banner()}},'✕'));
    clearTimeout(this._bt);this._bt=setTimeout(()=>this.banner(),61000);
  },
  /* START dabane par: party me dost hain to online match, warna normal */
  tryStart(){
    if(!Net.inParty())return false;
    if(!Net.isLeader()){toast(T('Only the team leader can start the match'));return true}
    Net.send({t:'party.set',map:prof.map});Net.send({t:'party.start'});return true;
  },
  copy(txt){try{navigator.clipboard.writeText(txt).then(()=>toast(T('Copied')),()=>toast(txt))}catch(e){toast(txt)}}
};

function pOnline(){
  const w=h('div',{class:'olw'});
  const url=Net.url(),pill=(c,t)=>h('span',{class:'olpill '+c},t);
  /* --- connection --- */
  const st=Net.ok?pill('ok','● '+(Net.mode==='p2p'?T('Direct (no server)'):T('Online'))+(Net.ping?' · '+Net.ping+' ms':'')):pill('bad','● '+(url?T('Connecting…'):T('Not connected')));
  const srv=h('input',{type:'text',id:'osrv',class:'txt',placeholder:'wss://your-server.onrender.com',value:set.server||'',style:'flex:1;min-width:0'});
  w.append(h('div',{class:'row2'},h('b',null,T('Server')),st));
  w.append(h('div',{class:'row2 wrap'},srv,h('button',{class:'sm pri',onclick:()=>{set.server=srv.value.trim();save();Net.restart();snd('click');Online.refresh()}},T('Connect'))));
  if(!url&&Net.mode!=='p2p')w.append(h('div',{class:'dim olnote'},T('Run the Last Ring server (node server/server.js) and open the game from its address, or type the server address above.')));
  else if(Net.err&&!Net.ok)w.append(h('div',{class:'dim olnote'},Net.err==='logged_in_elsewhere'?T('This account was opened on another device'):T('Could not reach the server — retrying…')));
  if(!Net.ok){return w}
  const fw=h('div');w.append(fw);
  const P=Net.mode==='p2p';
  /* --- my uid --- */
  w.append(h('h3',null,T('My Profile')));
  w.append(h('div',{class:'olme'},h('div',null,h('small',{class:'dim'},T('Your UID')),h('div',{class:'oluid'},Net.uid)),
    h('div',null,h('small',{class:'dim'},T('Name')),h('div',{class:'olname'},prof.name)),
    h('button',{class:'sm',onclick:()=>Online.copy(Net.uid)},T('Copy UID'))));
  /* --- team --- */
  w.append(h('h3',null,T('Team')));
  const p=Net.party;
  if(!p){
    w.append(h('div',{class:'row2 wrap'},h('button',{class:'sm pri',onclick:()=>{Net.send({t:'party.create'});snd('click')}},T('Create Team'))));
    const code=h('input',{type:'text',id:'ocode',class:'txt',maxlength:'6',placeholder:T('TEAM CODE'),style:'text-transform:uppercase;letter-spacing:.2em;width:130px'});
    w.append(h('div',{class:'row2 wrap'},code,h('button',{class:'sm',onclick:()=>{Net.send({t:'party.join',code:code.value});snd('click')}},T('Join with Code'))));
  }else{
    const lead=Net.isLeader();
    w.append(h('div',{class:'olcode'},h('small',{class:'dim'},T('Team code')),h('div',{class:'ocode'},p.code),
      h('button',{class:'sm',onclick:()=>Online.copy(p.code)},T('Copy code'))));
    w.append(h('div',{class:'olmem'},p.members.map(m=>h('div',{class:'olm'+(m.uid===Net.uid?' me':'')},
      h('span',{class:'olav'},(m.name||'?')[0].toUpperCase()),h('div',null,h('b',null,(m.uid===p.leader?'👑 ':'')+m.name+(m.uid===Net.uid?' ('+T('You')+')':'')),h('small',{class:'dim'},'UID '+m.uid)),
      lead&&m.uid!==Net.uid&&p.state==='lobby'?h('button',{class:'sm',onclick:()=>Net.send({t:'party.kick',uid:m.uid})},T('Remove')):null))));
    w.append(h('div',{class:'dim olnote'},T('{0}/{1} players · Map: {2} · Mode: Squad',p.members.length,p.max,MAPS[prof.map].n)));
    const acts=h('div',{class:'row2 wrap'});
    if(lead)acts.append(h('button',{class:'sm pri',onclick:()=>{closePanel();Online.tryStart()}},T('Start match')));
    else acts.append(h('span',{class:'dim'},T('Waiting for the team leader to start…')));
    acts.append(h('button',{class:'sm',onclick:()=>{Net.send({t:'party.leave'});snd('click')}},T('Leave team')));
    w.append(acts);
    const log=h('div',{class:'olchat'},Net.chat.slice(-6).map(c=>h('div',null,h('b',null,c.name+': '),c.text)));
    const ci=h('input',{type:'text',id:'ochat',class:'txt',maxlength:'100',placeholder:T('Message to team'),style:'flex:1;min-width:0',onkeydown:e=>{if(e.key==='Enter'){sendChat()}}});
    const sendChat=()=>{if(ci.value.trim()){Net.send({t:'party.chat',text:ci.value});ci.value='';Online.keep.ochat=''}};
    w.append(log,h('div',{class:'row2 wrap'},ci,h('button',{class:'sm',onclick:sendChat},T('Send'))));
  }
  if(P)w.append(h('div',{class:'dim olnote'},T('Direct mode: no server needed. Make a group and share the 6-digit code, or join a friend’s group with their code.')+' '+T('Friend requests by UID work here too — both phones must be open.')));
  /* --- friends: 3 icon tabs (list / add by UID / requests) --- */
  const IC={f:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3 19c0-3.4 2.7-5.5 6-5.5s6 2.1 6 5.5"/><path d="M16 5.5a3 3 0 0 1 0 5.6M18 14c2 .7 3 2.3 3 5"/></svg>',
    a:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3 19c0-3.4 2.7-5.5 6-5.5s6 2.1 6 5.5"/><path d="M18 7v6M15 10h6"/></svg>',
    r:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>'};
  const tab=Online.tab||'f',nIn=Net.inReq.length;
  const tb=h('div',{class:'oltabs'});
  for(const [k,n] of [['f',0],['a',0],['r',nIn]]){
    const b=h('button',{class:tab===k?'on':'','aria-label':k,onclick:()=>{Online.tab=k;snd('click');Online.refresh()}});b.innerHTML=IC[k]+(n?'<i>'+n+'</i>':'');tb.append(b)}
  fw.append(tb);
  if(tab==='a'){
    const fu=h('input',{type:'text',id:'ouid',class:'txt',inputmode:'numeric',maxlength:'8',placeholder:T('Friend UID'),style:'width:150px'});
    fw.append(h('div',{class:'row2 wrap'},fu,h('button',{class:'sm pri',onclick:()=>{if(fu.value.trim()){Net.send({t:'friend.add',uid:fu.value.trim()});fu.value='';Online.keep.ouid='';snd('click')}}},T('Send friend request'))));
    if(Net.outReq.length){
      fw.append(h('div',{class:'dim olh'},T('Sent requests')));
      for(const r of Net.outReq)fw.append(h('div',{class:'olf'},h('div',null,h('b',null,r.name),h('small',{class:'dim'},'UID '+r.uid+' · '+T('waiting'))),
        h('button',{class:'sm',onclick:()=>Net.send({t:'friend.cancel',uid:r.uid})},T('Cancel'))));
    }
  }else if(tab==='r'){
    fw.append(h('div',{class:'dim olh'},T('Friend requests')+' ('+nIn+')'));
    for(const r of Net.inReq)fw.append(h('div',{class:'olf'},h('div',null,h('b',null,r.name),h('small',{class:'dim'},'UID '+r.uid)),
      h('button',{class:'sm pri',onclick:()=>{Net.send({t:'friend.accept',uid:r.uid});snd('pick')}},T('Accept')),
      h('button',{class:'sm',onclick:()=>Net.send({t:'friend.decline',uid:r.uid})},T('Decline'))));
  }else{
    fw.append(h('div',{class:'dim olh'},T('Friends list')+' ('+Net.friends.length+')'));
    if(!Net.friends.length)fw.append(h('div',{class:'dim olnote'},T('No friends yet — share your UID or add a friend by UID.')));
    const fl=Net.friends.slice().sort((a,b)=>(b.online-a.online)||a.name.localeCompare(b.name));
    for(const f of fl){
      const inTeam=Net.party&&Net.party.members.some(m=>m.uid===f.uid);
      fw.append(h('div',{class:'olf'},h('span',{class:'oldot '+(f.online?'on':'')}),h('div',null,h('b',null,f.name),h('small',{class:'dim'},'UID '+f.uid+(f.online?(f.party?' · '+T('in a team'):' · '+T('online')):' · '+T('offline')))),
        f.online&&!inTeam?h('button',{class:'sm pri',onclick:()=>Online.invite(f.uid)},T('Invite')):null,
        h('button',{class:'sm',onclick:()=>{if(confirm(T('Remove {0} from friends?',f.name)))Net.send({t:'friend.remove',uid:f.uid})}},'✕')));
    }
  }
  return w;
}

/* Profile card (Free-Fire jaisa): avatar, naam, Lv, UID + copy, stats */
function pProfile(){
  const w=h('div',{class:'pfc'});
  const card=h('div',{class:'pfcard'});
  const pen=h('button',{class:'pen','aria-label':'Edit name',onclick:()=>{const n=(prompt(T('Name'),prof.name)||'').trim().slice(0,14);if(n){prof.name=n;save();Net.send({t:'profile',name:n});if(window.refreshLobby)refreshLobby();$('lName').textContent=n;Online.refresh()}}},'✎');
  const uid=h('div',{class:'uid',onclick:()=>{if(Net.uid)Online.copy(Net.uid)}},h('span',null,'UID: '+(Net.uid||'—')),h('span',null,'⧉'));
  card.append(h('div',{class:'pav'},(prof.name||'P')[0].toUpperCase()),h('div',null,h('h3',null,prof.name),h('small',null,T('Last Ring'))),pen,h('div',{class:'lv'},'Lv.'+level()),uid);
  const st=prof.st||{},xp=prof.xp%100;
  const side=h('div',{class:'pfst'});
  side.append(h('div',{class:'dim'},'XP '+xp+'/100'),h('div',{class:'pfxp'},h('i',{style:'width:'+xp+'%'})));
  side.append(h('div',{class:'pfrow'},h('div',null,h('span',null,'🎮'),st.m||0),h('div',null,h('span',null,'🏆'),st.w||0),h('div',null,h('span',null,'💀'),st.k||0)));
  if(!Net.uid)side.append(h('div',{class:'dim olnote'},T('Connect to the server to get your UID')));
  w.append(card,side);return w;
}
