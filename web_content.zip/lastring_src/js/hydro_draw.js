'use strict';
/* =====================================================================
   hydro_draw.js — dynamic render: nadi (flow/foam/glints), talab (ripples/reflection/koi...), jharna (sheet/foam/mist),
   fog, light shafts, grass sway.  drawBase = players ke neeche, drawTop = players ke upar (foreground occlusion + parallax)
   ===================================================================== */
Object.assign(Hydro,{
  pv:false,
  vis(x,y,r){return x+r>this._x0&&x-r<this._x1&&y+r>this._y0&&y-r<this._y1},
  seasonA(f){const v=f.v;if(v.seas){const p=((time+f.ph*4)%40)/40;return p<.12?p/.12:p<.55?1:p<.7?1-(p-.55)/.15:0}if(v.rainp)return .4+.6*(Math.sin(time*.17+f.ph)+1)/2;if(v.ice)return 1;return 1},
  /* ---------- base layer ---------- */
  drawBase(c,x0,y0,x1,y1,q){
    if(this.idx<0)return;
    this._x0=x0;this._y0=y0;this._x1=x1;this._y1=y1;
    const fx=q.fx|0;
    for(const R of this.rivers)for(const ch of R.chans)if(!(ch.x1<x0||ch.x0>x1||ch.y1<y0||ch.y0>y1))this.drawRiver(c,R,ch,fx,q);
    for(const p of this.ponds)if(this.vis(p.x,p.y,p.r+60))this.drawPond(c,p,fx);
    for(const f of this.falls)if(this.vis(f.x,f.y-f.h*.5,f.w+f.poolR+60))this.drawFall(c,f,fx);
    for(const b of this.bridges)if(this.vis(b.cx,b.cy,b.L*.7))this.bridgeBase(c,b,fx);
    if(fx>=1||q.tuft>.5)this.drawGrass(c,x0,y0,x1,y1,fx);
  },
  /* ---------- rivers ---------- */
  drawRiver(c,R,ch,fx,q){
    const v=R.v,w=ch.w;c.lineCap='round';c.lineJoin='round';
    if(v.dry){c.strokeStyle='rgba(255,255,255,.4)';c.lineWidth=2;c.setLineDash([5,20]);c.lineDashOffset=-R.fo;c.stroke(ch.path);c.setLineDash([]);return}
    c.strokeStyle=hx(v.f,.2);c.lineWidth=w*.55;c.setLineDash([8,34]);c.lineDashOffset=-R.fo;c.stroke(ch.path);                     // current streaks
    c.strokeStyle=hx(v.f,.36);c.lineWidth=Math.max(2,w*.07);c.setLineDash([4,22]);c.lineDashOffset=-R.fo*1.25;c.stroke(ch.path);
    if(fx>=1){c.strokeStyle=hx(v.f,.14);c.lineWidth=w*.86;c.setLineDash([3,61]);c.lineDashOffset=-R.fo*.75;c.stroke(ch.path)}
    c.strokeStyle=hx(v.f,(v.foam?(v.foam>1?.4:.3):.14));c.lineWidth=w*1.04;c.setLineDash([2,v.foam?26:52]);c.lineDashOffset=-R.fo*.85;c.stroke(ch.path);   // edge foam
    c.setLineDash([]);
    if(fx>=1||v.sheen){c.strokeStyle='rgba(255,255,255,'+(v.sheen?.17:.07)+')';c.lineWidth=w*.16;c.setLineDash([60,150]);c.lineDashOffset=-time*14;c.stroke(ch.path);c.setLineDash([])}   // sun glints
    if(v.lava||v.glow){const k=.1+.07*Math.sin(time*2.2+R.seed);c.strokeStyle=hx(v.glow||'#ff7a2a',k);c.lineWidth=w*1.3;c.stroke(ch.path)}
    if(v.tide){const e=(Math.sin(this.tide)+1)/2;c.strokeStyle='rgba(120,100,70,'+(.28*(1-e)).toFixed(3)+')';c.lineWidth=w*1.75;c.stroke(ch.path)}   // mud flats show at low tide
    if(v.milky&&fx>=1){c.strokeStyle='rgba(255,255,255,.08)';c.lineWidth=w*.9;c.setLineDash([30,50]);c.lineDashOffset=-R.fo*.4;c.stroke(ch.path);c.setLineDash([])}
    if(v.ice&&fx>=1){c.fillStyle='rgba(240,250,255,.85)';for(let i=0;i<3;i++){const u=((R.fo*.0007+i/3+R.seed)%1+1)%1,p=this.pt(ch,u,(i-1)*.25);c.beginPath();c.ellipse(p.x,p.y,7,4.5,u*6,0,TAU);c.fill();c.strokeStyle='rgba(150,200,225,.8)';c.lineWidth=1;c.stroke()}}
    if(v.steam&&fx>=1){}
    for(const k of R.rocks){
      if(!this.vis(k.x,k.y,30))continue;
      if(v.rocks){const a=(time*1.3+k.ph)%1;c.strokeStyle='rgba(255,255,255,'+(.5*(1-a)).toFixed(2)+')';c.lineWidth=2;c.beginPath();c.ellipse(k.x,k.y,k.r*(1.15+a*.7),k.r*(.9+a*.5),0,0,TAU);c.stroke();
        c.fillStyle='rgba(255,255,255,.35)';c.fillRect(k.x-2,k.y+k.r*.6,4,k.r*1.6)}
    }
    if(v.leaves&&fx>=1)for(const l of R.lv){if(l.c!==ch)continue;const p=this.pt(ch,l.u,l.off+Math.sin(time*.8+l.ph)*.03);if(!this.vis(p.x,p.y,8))continue;c.fillStyle=l.ph>3?'#b8742a':'#6a8a2a';c.beginPath();c.ellipse(p.x,p.y,l.r*1.5,l.r*.8,time*.5+l.ph,0,TAU);c.fill()}
    if(v.cress){c.fillStyle='rgba(70,140,60,.7)';for(let i=0;i<ch.pts.length;i+=2){const p=ch.pts[i];if(!this.vis(p.x,p.y,20))continue;c.beginPath();c.arc(p.x+Math.sin(i*3)*w*.4,p.y+Math.cos(i*2)*w*.3,4+Math.sin(i)*1.4,0,TAU);c.fill()}}
    if(v.pebbles){c.fillStyle='rgba(190,180,160,.5)';for(let i=0;i<ch.pts.length;i++){const p=ch.pts[i];if(!this.vis(p.x,p.y,20))continue;c.beginPath();c.arc(p.x+Math.sin(i*5)*w*.35,p.y+Math.cos(i*4)*w*.3,2.5,0,TAU);c.fill();c.beginPath();c.arc(p.x+Math.cos(i*7)*w*.3,p.y+Math.sin(i*3)*w*.35,1.8,0,TAU);c.fill()}}
  },
  pt(ch,u,off){
    const n=ch.pts.length-1,f=clamp(u,0,.9999)*n,i=Math.floor(f),t=f-i,a=ch.pts[i],b=ch.pts[i+1],dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy)||1;
    return{x:a.x+dx*t-dy/l*off*ch.w,y:a.y+dy*t+dx/l*off*ch.w};
  },
  /* ---------- ponds ---------- */
  drawPond(c,p,fx){
    const v=p.v,r=p.r;
    c.save();this.poly(c,p,1);c.clip();
    if(v.refl&&fx>=1){                                                    // reflections: peripheral trees mirrored + sky sheen
      if(!p.tr){p.tr=[];for(const t of trees){const d=Math.hypot(t.x-p.x,t.y-p.y);if(d>r&&d<r+90)p.tr.push({x:t.x,y:t.y,d,cr:t.cr})}}
      c.fillStyle='rgba(20,50,30,'+(v.refl===2?.34:.22)+')';
      for(const t of p.tr){const k=(2*r-t.d)/t.d,x=p.x+(t.x-p.x)*k,y=p.y+(t.y-p.y)*k+Math.sin(time*1.5+t.x)*1.2;c.beginPath();c.ellipse(x,y,t.cr*.8,t.cr*.6,0,0,TAU);c.fill()}
      const gg=c.createLinearGradient(p.x-r,p.y-r,p.x+r*.6,p.y+r);gg.addColorStop(0,'rgba(255,255,255,'+(v.refl===2?.22:.12)+')');gg.addColorStop(.5,'rgba(255,255,255,0)');gg.addColorStop(1,'rgba(255,230,180,.1)');c.fillStyle=gg;c.fillRect(p.x-r,p.y-r,r*2,r*2);
    }
    const nR=v.rainfx?9:3;                                                // ripples (calm / rain)
    c.lineWidth=1.5;
    for(let i=0;i<nR;i++){const ph=(time*(v.rainfx?.9:.3)+i/nR+p.ph)%1,a=i*2.399+p.seed,d=(.15+.55*((i*.37)%1))*r;
      c.strokeStyle='rgba(255,255,255,'+(.26*(1-ph)).toFixed(3)+')';c.beginPath();c.ellipse(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d,ph*(v.rainfx?16:r*.3),ph*(v.rainfx?10:r*.2),0,0,TAU);c.stroke()}
    if(fx>=1){const gx=Math.sin(time*.4+p.ph)*r*.35,gy=Math.cos(time*.31+p.ph)*r*.3;c.fillStyle='rgba(255,255,255,.08)';c.beginPath();c.ellipse(p.x+gx,p.y+gy,r*.34,r*.09,.5,0,TAU);c.fill();
      c.fillStyle='rgba(255,255,255,.2)';c.beginPath();c.ellipse(p.x-gx*.6+r*.1,p.y-gy*.6-r*.1,r*.08,r*.025,.3,0,TAU);c.fill()}
    if(v.lily)for(const l of p.lily){const x=p.x+l.x+Math.sin(time*.5+l.ph)*1.5,y=p.y+l.y+Math.cos(time*.4+l.ph)*1.2;
      c.fillStyle='rgba(0,0,0,.2)';c.beginPath();c.ellipse(x+2,y+3,l.r,l.r*.8,0,0,TAU);c.fill();
      c.fillStyle='#4a9a4a';c.beginPath();c.moveTo(x,y);c.arc(x,y,l.r,.3+l.ph,TAU-.1+l.ph);c.closePath();c.fill();c.fillStyle='rgba(255,255,255,.16)';c.beginPath();c.arc(x-l.r*.2,y-l.r*.2,l.r*.4,0,TAU);c.fill();
      if(l.f){c.fillStyle='#ff9ac8';for(let k=0;k<5;k++){c.beginPath();c.ellipse(x+Math.cos(k*1.256)*3,y+Math.sin(k*1.256)*3,3,1.6,k*1.256,0,TAU);c.fill()}c.fillStyle='#ffe066';c.beginPath();c.arc(x,y,1.6,0,TAU);c.fill()}}
    if(v.koi)for(const k of p.koi){const a=k.a+time*k.sp,x=p.x+Math.cos(a)*k.d,y=p.y+Math.sin(a)*k.d*.8,dir=a+(k.sp>0?Math.PI/2:-Math.PI/2),wg=Math.sin(time*6+k.a)*.35;
      c.save();c.translate(x,y);c.rotate(dir);c.fillStyle='rgba(0,0,0,.2)';c.beginPath();c.ellipse(2,3,9,4,0,0,TAU);c.fill();
      c.fillStyle=k.c;c.beginPath();c.ellipse(0,0,9,3.8,0,0,TAU);c.fill();c.beginPath();c.moveTo(-8,0);c.lineTo(-15,-4+wg*6);c.lineTo(-15,4+wg*6);c.closePath();c.fill();
      c.fillStyle='rgba(255,255,255,.35)';c.beginPath();c.ellipse(2,-1,4,1.2,0,0,TAU);c.fill();c.restore()}
    if(v.algae||v.logs){c.fillStyle='rgba(90,70,40,.9)';for(let i=0;i<3;i++){const a=p.seed+i*2.1,x=p.x+Math.cos(a)*r*.4,y=p.y+Math.sin(a)*r*.4;c.save();c.translate(x,y);c.rotate(a);c.fillRect(-22,-4,44,8);c.fillStyle='rgba(80,120,50,.6)';c.fillRect(-18,-4,22,4);c.fillStyle='rgba(90,70,40,.9)';c.restore()}}
    if(v.ice)for(const f of p.ice){c.save();c.translate(p.x+f.x+Math.sin(time*.2+f.rot)*3,p.y+f.y+Math.cos(time*.17+f.rot)*3);c.rotate(f.rot+time*.03);c.fillStyle='rgba(235,248,255,.92)';c.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU,rr=f.r*(i%2?.8:1);c.lineTo(Math.cos(a)*rr,Math.sin(a)*rr*.75)}c.closePath();c.fill();c.strokeStyle='rgba(120,180,210,.8)';c.lineWidth=1;c.stroke();c.restore()}
    if(v.bubbles||v.springs||v.id==='hot_spring'||v.id==='volcanic_hot'){c.fillStyle='rgba(255,255,255,.5)';const nb=v.springs?5:7;for(let i=0;i<nb;i++){const ph=(time*.5+i/nb+p.ph)%1,a=i*2.4+p.seed,d=v.springs?r*.08:(.2+((i*.43)%1)*.6)*r,bx=p.x+Math.cos(a)*d,by=p.y+Math.sin(a)*d;
      if(v.springs){c.strokeStyle='rgba(255,255,255,'+(.4*(1-ph)).toFixed(2)+')';c.lineWidth=2;c.beginPath();c.arc(bx,by,ph*r*.22,0,TAU);c.stroke()}else{c.globalAlpha=1-ph;c.beginPath();c.arc(bx,by-ph*8,1.5+ph*3,0,TAU);c.fill();c.globalAlpha=1}}}
    if(v.clear&&fx>=1){c.strokeStyle='rgba(255,255,255,.1)';c.lineWidth=1;c.beginPath();for(let i=0;i<5;i++){const a=i*1.26+time*.08,rr=r*(.2+i*.14);c.moveTo(p.x+Math.cos(a)*rr,p.y+Math.sin(a)*rr);c.lineTo(p.x+Math.cos(a+.5)*rr*1.1,p.y+Math.sin(a+.5)*rr*.9)}c.stroke()}
    c.restore();
  },
  /* ---------- waterfalls (base) ---------- */
  fallStreams(f){
    if(f.sl)return f.sl;const w=f.w,h=f.h,v=f.v,S=[];
    const add=(x0,x1,y0,y1,o)=>S.push(Object.assign({x0,x1,y0,y1},o||{}));
    switch(v.lay){
      case'one':add(-w*.38,w*.38,-h,0);break;
      case'plunge':add(-w*.3,w*.3,-h,0);break;
      case'thin':for(const k of[-.3,0,.28])add(w*k-7,w*k+7,-h,0,{th:1});break;
      case'ice':for(const k of[-.32,-.1,.12,.33])add(w*k-9,w*k+9,-h,0,{ice:1});break;
      case'horse':add(-w*.25,w*.25,-h,0,{bow:1});break;
      case'two':add(-w*.4,-w*.06,-h,0);add(w*.06,w*.4,-h,0);break;
      case'twin':add(-w*.42,-w*.14,-h,0);add(w*.14,w*.42,-h,0);break;
      case'block':add(-w*.28,w*.28,-h,-h*.62,{lip:1});add(-w*.38,w*.38,-h*.62,-h*.3,{lip:1});add(-w*.46,w*.46,-h*.3,0);break;
      case'tier':add(-w*.2,w*.2,-h,-h*.64,{lip:1});add(-w*.34,w*.34,-h*.64,-h*.32,{lip:1,dx:-8});add(-w*.46,w*.46,-h*.32,0,{dx:6});break;
      case'multi':for(let i=0;i<6;i++)add(-w*.42+i*w*.17-5,-w*.42+i*w*.17+5,-h+(i%2)*10,0,{th:1});break;
      case'fan':add(-w*.18,w*.18,-h,0,{fan:1});break;
      case'punch':add(-14,14,-h,0);break;
      case'steps':for(let i=0;i<5;i++)add(-w*.25+i*5,w*.25+i*5,-h+i*h/5,-h+(i+1)*h/5,{lip:1,dx:(i-2)*5});break;
      case'curtain':add(-w*.46,w*.46,-h,0,{th:1});break;
      case'seg':add(-w*.3,w*.3,-h,-h*.56,{lip:1});add(-w*.38,w*.38,-h*.4,0,{lip:1});break;
    }
    return f.sl=S;
  },
  drawFall(c,f,fx){
    const v=f.v,A=this.seasonA(f),S=this.fallStreams(f),w=f.w,h=f.h;
    c.save();c.translate(f.x,f.y);
    if(v.cave){c.fillStyle='rgba(0,6,14,.3)';c.fillRect(-w/2-16,-h,w+32,h)}
    for(const s of S){
      const sw=(s.x1-s.x0),y0=s.y0,y1=s.y1,hh=y1-y0,col=v.col;
      let a=(s.ice?.9:.72)*(s.th?.8:1);
      if(A<.14){c.fillStyle='rgba(30,22,14,.18)';c.fillRect(s.x0,y0,sw,hh);continue}                          // dry stain
      const bow=s.bow?1:0,fan=s.fan?1:0;
      const wid=u=>fan?(s.x1-s.x0)*(.5+.5*u*u*1.9)*(.35+.65*A):(s.x1-s.x0)*(.45+.55*A);
      const cx=(s.x0+s.x1)/2+(s.dx||0);
      c.beginPath();
      const stp=8;
      for(let i=0;i<=stp;i++){const u=i/stp,ww=wid(u)/2,xo=bow?u*u*24:0;i?c.lineTo(cx+xo-ww,y0+hh*u):c.moveTo(cx+xo-ww,y0)}
      for(let i=stp;i>=0;i--){const u=i/stp,ww=wid(u)/2,xo=bow?u*u*24:0;c.lineTo(cx+xo+ww,y0+hh*u)}
      c.closePath();
      const gr=c.createLinearGradient(0,y0,0,y1);gr.addColorStop(0,hx(col,a*A));gr.addColorStop(.5,hx(col,a*.85*A));gr.addColorStop(1,hx(col,a*.95*A));
      c.fillStyle=gr;c.fill();
      c.save();c.clip();
      if(!s.ice){
        const n=Math.max(4,Math.floor(sw/(s.th?3:5)));c.lineWidth=1.6;
        c.strokeStyle='rgba(255,255,255,.55)';c.beginPath();
        for(let i=0;i<n;i++){const x=cx-sw/2+(i+.5)*sw/n+Math.sin(i*5.3)*2,per=hh*.9+20,yy=((time*(110+i%3*20)+i*37.1)%per)-10,len=14+(i*7)%20;c.moveTo(x,y0+yy);c.lineTo(x,Math.min(y1,y0+yy+len))}
        c.stroke();
        c.strokeStyle='rgba(120,170,190,.28)';c.beginPath();for(let i=0;i<n;i+=2){const x=cx-sw/2+(i+.8)*sw/n,per=hh*.9+20,yy=((time*90+i*53)%per)-10;c.moveTo(x,y0+yy);c.lineTo(x,Math.min(y1,y0+yy+22))}c.stroke();
      }else{c.fillStyle='rgba(255,255,255,.35)';c.fillRect(cx-sw/2,y0,sw*.3,hh);c.fillStyle='rgba(255,255,255,'+(.2+.2*Math.sin(time*3+s.x0)).toFixed(2)+')';for(let i=0;i<4;i++)c.fillRect(cx-sw/2+i*sw/4+3,y0+((i*37+time*8)%hh),2,5)}
      c.restore();
      c.fillStyle='rgba(255,255,255,.7)';c.fillRect(cx-wid(0)/2,y0,wid(0),s.lip?4:3);                          // lip foam
      if(s.lip){c.fillStyle='rgba(0,0,0,.2)';c.fillRect(s.x0-10,y1-2,sw+20,3)}
    }
    if(v.ice)for(const ic of f.ice){c.fillStyle='rgba(225,245,255,.9)';c.beginPath();c.moveTo(ic.x-3,-h);c.lineTo(ic.x+3,-h);c.lineTo(ic.x,-h+ic.l);c.closePath();c.fill()}
    // glow
    if(v.glow&&fx>=1){c.globalCompositeOperation='lighter';const gg=c.createRadialGradient(0,f.poolR*.5,4,0,f.poolR*.5,f.poolR*1.6);gg.addColorStop(0,hx(v.glow,.38+.1*Math.sin(time*2)));gg.addColorStop(1,hx(v.glow,0));c.fillStyle=gg;c.fillRect(-f.poolR*1.6,-f.poolR,f.poolR*3.2,f.poolR*3);
      if(v.glow2){const g2=c.createLinearGradient(-w/2,0,w/2,0);g2.addColorStop(0,hx(v.glow2,.18));g2.addColorStop(1,hx(v.glow,.18));c.fillStyle=g2;c.fillRect(-w*.4,-h,w*.8,h)}c.globalCompositeOperation='source-over'}
    // foam at base (wet-edge / splash ring)
    if(A>.14){for(let i=0;i<3;i++){const ph=(time*.9+i/3+f.ph)%1;c.strokeStyle='rgba(255,255,255,'+(.55*(1-ph)*A).toFixed(2)+')';c.lineWidth=2.4;c.beginPath();c.ellipse(0,f.poolR*.2,w*.3*(.35+ph*.9),12+ph*18,0,0,TAU);c.stroke()}
      c.fillStyle='rgba(255,255,255,'+(.55*A).toFixed(2)+')';c.beginPath();c.ellipse(0,3,w*.34,9,0,0,TAU);c.fill()}
    c.restore();
    // pool ripples
    c.strokeStyle='rgba(255,255,255,.2)';c.lineWidth=1.5;for(let i=0;i<3;i++){const ph=(time*.35+i/3)%1;c.globalAlpha=1-ph;c.beginPath();c.ellipse(f.px,f.py,f.poolR*(.3+ph*.65),f.poolR*(.3+ph*.65)*.92,0,0,TAU);c.stroke()}c.globalAlpha=1;
  },
  /* ---------- grass / reeds (hawa me) ---------- */
  drawGrass(c,x0,y0,x1,y1,fx){
    const wd=this.wind,lim=fx>=2?9999:fx>=1?420:200;let n=0;
    c.lineCap='round';c.lineWidth=1.7;
    for(const g of this.grass){
      if(g.x<x0||g.x>x1||g.y<y0||g.y>y1)continue;if(++n>lim)break;
      const sw=(wd*7+Math.sin(time*2.4+g.ph)*2.8)*(g.h/14);
      c.strokeStyle=g.c;
      for(let k=0;k<g.n;k++){c.beginPath();c.moveTo(g.x+k*3-3,g.y);c.quadraticCurveTo(g.x+k*3-3+sw*.4,g.y-g.h*.6,g.x+k*3-3+sw,g.y-g.h);c.stroke()}
    }
  },
  /* ---------- top layer ---------- */
  drawTop(c,x0,y0,x1,y1,q){
    if(this.idx<0)return;
    const fx=q.fx|0;this._x0=x0;this._y0=y0;this._x1=x1;this._y1=y1;
    for(const b of this.bridges)if(this.vis(b.cx,b.cy,b.L*.7+60))this.bridgeTop(c,b,fx);
    for(const R of this.rivers)for(const ch of R.chans){
      if(ch.x1<x0||ch.x0>x1||ch.y1<y0||ch.y0>y1)continue;
      const v=R.v;
      if(v.tunnel&&ch.tun){if(!ch._tp)ch._tp=this.mkPath(ch.pts.slice(ch.tun[0],ch.tun[1]+1));
        c.lineCap='round';c.lineJoin='round';c.strokeStyle='rgba(18,20,28,.7)';c.lineWidth=ch.w*1.7;c.stroke(ch._tp);c.strokeStyle='rgba(60,60,72,.55)';c.lineWidth=ch.w*1.45;c.stroke(ch._tp);
        c.globalCompositeOperation='lighter';c.strokeStyle=hx(v.glow,.1+.05*Math.sin(time*2));c.lineWidth=ch.w*.7;c.stroke(ch._tp);c.globalCompositeOperation='source-over'}
      if(v.canopy&&fx>=1){c.fillStyle='rgba(24,70,32,.38)';for(let i=2;i<ch.pts.length-2;i+=4){const p=ch.pts[i],ox=Math.sin(i*4.1)*ch.w*.7;if(!this.vis(p.x,p.y,70))continue;const px=this.pv?0:(p.x-cam.x)*.012,py=this.pv?0:(p.y-cam.y)*.012;for(let k=0;k<3;k++){c.beginPath();c.ellipse(p.x+ox+px+k*16-16,p.y+py-10+Math.sin(time*.6+i+k)*1.5,26,18,k,0,TAU);c.fill()}}}
      if(fx>=1&&(mp.wx==='mist'||v.steam||v.lava)){const col=v.lava?'rgba(255,170,110,.07)':'rgba(220,235,240,.08)';c.fillStyle=col;for(let i=1;i<ch.pts.length;i+=3){const p=ch.pts[i];if(!this.vis(p.x,p.y,90))continue;const dr=Math.sin(time*.3+i*1.7)*16;c.beginPath();c.ellipse(p.x+dr,p.y-8,ch.w*.9,22+((i*7)%9),0,0,TAU);c.fill()}}
    }
    for(const f of this.falls)if(this.vis(f.x,f.y-f.h*.5,f.w+f.poolR+80))this.fallTop(c,f,fx);
    for(const p of this.ponds)if(this.vis(p.x,p.y,p.r+80))this.pondTop(c,p,fx);
    this.drawParts(c,fx);
    if(fx>=1)this.shafts(c,fx);
  },
  fallTop(c,f,fx){
    const v=f.v,w=f.w,h=f.h,px=this.pv?0:(f.x-cam.x)*.02,A=this.seasonA(f);
    c.save();c.translate(f.x,f.y);
    if(v.cave){                                                                  // overhang (foreground occlusion + parallax)
      c.fillStyle='rgba(8,10,16,.94)';c.beginPath();c.moveTo(-w/2-16,-h-4);c.lineTo(w/2+16,-h-4);c.lineTo(w/2+16,-h*.55);c.quadraticCurveTo(w*.4,-h*.78,0,-h*.7);c.quadraticCurveTo(-w*.4,-h*.78,-w/2-16,-h*.55);c.closePath();c.fill();
      c.fillStyle=v.rock[1];for(let i=0;i<9;i++){const x=-w/2+i*w/8;c.beginPath();c.moveTo(x-6,-h*.7);c.lineTo(x+6,-h*.7);c.lineTo(x,-h*.7+10+(i*7)%12);c.closePath();c.fill()}}
    if(v.vines){c.strokeStyle='#3a7a2a';c.lineWidth=2;for(let i=0;i<14;i++){const x=-w/2+i*w/13+Math.sin(i*3)*4,L=24+(i*13)%30,sw=this.wind*4+Math.sin(time*1.6+i)*2;c.beginPath();c.moveTo(x+px,-h-2);c.quadraticCurveTo(x+px+sw*.5,-h+L*.5,x+px+sw,-h+L);c.stroke();c.fillStyle='#4a9a34';c.beginPath();c.ellipse(x+px+sw,-h+L,3,2,0,0,TAU);c.fill()}}
    if(v.steam&&fx>=1){}
    c.restore();
  },
  pondTop(c,p,fx){
    const v=p.v,r=p.r,wd=this.wind;
    if(v.reeds||v.palms){
      for(const k of p.reeds){
        const x=p.x+Math.cos(k.a)*k.d,y=p.y+Math.sin(k.a)*k.d,sw=wd*6+Math.sin(time*2+k.ph)*2.4;
        if(v.palms){c.strokeStyle='#6a4a2a';c.lineWidth=4;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+sw*.3+4,y-k.h*1.1,x+sw,y-k.h*2.2);c.stroke();
          c.strokeStyle='#3f8a2e';c.lineWidth=3;for(let i=0;i<7;i++){const a=i/7*TAU;c.beginPath();c.moveTo(x+sw,y-k.h*2.2);c.quadraticCurveTo(x+sw+Math.cos(a)*20,y-k.h*2.2+Math.sin(a)*8-10,x+sw+Math.cos(a)*34+sw*.3,y-k.h*2.2+Math.sin(a)*14+8);c.stroke()}}
        else{c.strokeStyle='#8a9a4a';c.lineWidth=1.8;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+sw*.3,y-k.h*.6,x+sw,y-k.h);c.stroke();c.fillStyle='#6a4a2a';c.fillRect(x+sw-1.5,y-k.h-3,3,8)}
      }
    }
    if(v.steam&&fx>=1){c.fillStyle='rgba(240,248,250,.12)';const n=v.steam===2?7:5;for(let i=0;i<n;i++){const ph=(time*.22+i/n+p.ph)%1,a=i*2.4+p.seed,d=Math.sqrt((i*.37)%1)*r*.7;c.globalAlpha=Math.sin(ph*Math.PI)*.9;c.beginPath();c.arc(p.x+Math.cos(a)*d+Math.sin(time*.5+i)*6,p.y+Math.sin(a)*d-ph*60,16+ph*26,0,TAU);c.fill()}c.globalAlpha=1}
    if(v.fairy){c.globalCompositeOperation='lighter';for(const f of p.fl){const a=f.a+time*f.sp,x=p.x+Math.cos(a)*f.d+Math.sin(time*1.1+f.ph)*10,y=p.y+Math.sin(a)*f.d*.8-8+Math.cos(time*.9+f.ph)*8,k=.55+.45*Math.sin(time*3+f.ph);
        const gg=c.createRadialGradient(x,y,0,x,y,20);gg.addColorStop(0,'rgba(180,255,220,'+(.9*k).toFixed(2)+')');gg.addColorStop(1,'rgba(120,255,200,0)');c.fillStyle=gg;c.beginPath();c.arc(x,y,20,0,TAU);c.fill()}
      const gg=c.createRadialGradient(p.x,p.y,0,p.x,p.y,r);gg.addColorStop(0,'rgba(140,255,215,.18)');gg.addColorStop(1,'rgba(140,255,215,0)');c.fillStyle=gg;c.beginPath();c.arc(p.x,p.y,r,0,TAU);c.fill();c.globalCompositeOperation='source-over'}
    if(v.cave){c.fillStyle='rgba(6,8,12,.55)';c.beginPath();c.arc(p.x,p.y,r+90,0,TAU);c.arc(p.x,p.y,r*.82,0,TAU,true);c.fill();
      c.fillStyle=v.rim;for(let i=0;i<16;i++){const a=i/16*TAU,x=p.x+Math.cos(a)*(r*.9),y=p.y+Math.sin(a)*(r*.9);c.beginPath();c.moveTo(x-5,y-5);c.lineTo(x+5,y-5);c.lineTo(x+Math.cos(a)*-2,y+10+(i*5)%9);c.closePath();c.fill()}
      c.globalCompositeOperation='lighter';const gg=c.createRadialGradient(p.x,p.y,0,p.x,p.y,r*.9);gg.addColorStop(0,hx(v.glow,.2+.06*Math.sin(time*1.7)));gg.addColorStop(1,hx(v.glow,0));c.fillStyle=gg;c.beginPath();c.arc(p.x,p.y,r*.9,0,TAU);c.fill();c.globalCompositeOperation='source-over'}
    if(v.glowRim&&fx>=1){c.globalCompositeOperation='lighter';const gg=c.createRadialGradient(p.x,p.y,r*.7,p.x,p.y,r*1.25);gg.addColorStop(0,'rgba(255,110,40,0)');gg.addColorStop(.6,'rgba(255,110,40,'+(.22+.08*Math.sin(time*2.4)).toFixed(2)+')');gg.addColorStop(1,'rgba(255,110,40,0)');c.fillStyle=gg;c.beginPath();c.arc(p.x,p.y,r*1.25,0,TAU);c.fill();c.globalCompositeOperation='source-over'}
  },
  /* soft volumetric light (fake god-rays) — day maps, jharna/talab ke upar */
  shafts(c,fx){
    if(mp.night&&!this.falls.some(f=>f.v.glow))return;
    const day=mp.night?0:1,tg=[];
    for(const f of this.falls)tg.push([f.x,f.y-f.h*.5,f.w*.9]);for(const p of this.ponds)if(p.v.refl||p.v.clear||p.v.id==='forest')tg.push([p.x,p.y-20,p.r*.8]);
    c.globalCompositeOperation='lighter';
    for(const t of tg){if(!this.vis(t[0],t[1],t[2]+120))continue;
      for(let i=0;i<3;i++){const x=t[0]-t[2]*.4+i*t[2]*.4+Math.sin(time*.25+i)*10,gr=c.createLinearGradient(x-30,t[1]-120,x+60,t[1]+110);
        gr.addColorStop(0,'rgba(255,245,200,0)');gr.addColorStop(.4,'rgba(255,245,210,'+(.06*day+.02).toFixed(3)+')');gr.addColorStop(1,'rgba(255,245,200,0)');
        c.fillStyle=gr;c.beginPath();c.moveTo(x-16,t[1]-120);c.lineTo(x+16,t[1]-120);c.lineTo(x+86,t[1]+110);c.lineTo(x+34,t[1]+110);c.closePath();c.fill()}}
    c.globalCompositeOperation='source-over';
  }
});
