'use strict';
/* =====================================================================
   skins.js — har hathiyaar ke 3 skins: Default / Gold / Neon
   ---------------------------------------------------------------------
   Sirf LOOK badalta hai (gun ka rang + chamak). Damage/rate/range/mag koi stat nahi chhoota.
   Unlock: gold se ya mission se mile 🎟 skin-token se. Save: prof.wskO (owned), prof.wsk (chuna hua).
   ===================================================================== */
const WSKIN=[
  {id:'def', n:T('Default'),price:0,  col:null,     gfx:''},
  {id:'gold',n:T('Gold'),   price:500,col:'#ffd35c',gfx:'gold'},
  {id:'neon',n:T('Neon'),   price:400,col:'#2dffd0',gfx:'neon'}
];
const wsk={
  owned(w,s){return s==='def'||!!prof.wskO[w+':'+s]},
  cur(w){const s=prof.wsk[w]||'def';return this.owned(w,s)?s:'def'},
  // hathiyaar w ka abhi ka skin (Default ho to null)
  look(w){const id=this.cur(w);return id==='def'?null:WSKIN.find(x=>x.id===id)},
  equip(w,s){if(!this.owned(w,s))return;prof.wsk[w]=s;save();snd('click');render()},
  buy(w,s,useToken){
    if(this.owned(w,s))return;
    const sk=WSKIN.find(x=>x.id===s);if(!sk)return;
    if(useToken){
      if((prof.tok|0)<1){toast(T('🎟 No token'));return}
      prof.tok--;
    }else{
      if(prof.gold<sk.price){toast(T('Not enough Gold — {0} needed',sk.price));return}
      prof.gold-=sk.price;
    }
    prof.wskO[w+':'+s]=1;prof.wsk[w]=s;save();snd('pick');toast(T('{0} · {1} unlocked!',WP[w].n,sk.n));refreshBars();render();
  }
};

function skinPreview(k,sk){
  const c=document.createElement('canvas');c.width=280;c.height=112;c.style.width='140px';c.style.height='56px';
  const g=c.getContext('2d');g.scale(2,2);
  g.fillStyle='#39455a';rr(g,2,2,136,52,8);g.fill();                  // halka plate: dark gun-parts bhi dikhein
  if(sk&&sk.gfx==='neon'){g.shadowColor=sk.col;g.shadowBlur=10}
  drawGunIcon(g,k,70,28,.78,sk?sk.col:null,sk&&sk.gfx);
  return c;
}

/* ---------- skin select panel ---------- */
function pSkins(){
  const w=h('div');
  w.append(h('div',{class:'row2'},h('span',{class:'dim'},T('Only the look changes — damage/rate/range stay the same.')),h('span',{class:'tag'},T('🎟 Tokens: {0}',prof.tok|0))));
  w.append(h('div',{class:'wlist'},WKEYS.map(k=>{
    const x=WP[k],cur=wsk.cur(k),locked=WSKIN.filter(s=>!wsk.owned(k,s.id));
    const btns=WSKIN.map(s=>{
      const ow=wsk.owned(k,s.id),sel=cur===s.id;
      return h('button',{class:'sm'+(sel?' on':'')+(ow||prof.gold>=s.price?'':' off'),id:'sk_'+k+'_'+s.id,
        onclick:()=>ow?wsk.equip(k,s.id):wsk.buy(k,s.id,false)},
        ow?(sel?'✓ ':'')+s.n:'🔒 '+s.n+' '+s.price);
    });
    const tk=(prof.tok|0)>0&&locked.length?h('div',{class:'row2 wrap',style:'margin:4px 0 0'},locked.map(s=>
      h('button',{class:'sm pri',id:'tk_'+k+'_'+s.id,onclick:()=>wsk.buy(k,s.id,true)},'🎟 '+s.n))):null;
    return h('div',{class:'wi',style:'--rc:'+RAR[x.tier][1]},skinPreview(k,wsk.look(k)),
      h('div',null,h('b',null,x.n),h('small',{style:'display:block'},RAR[x.tier][0]),h('div',{class:'skrow'},btns),tk));
  })));
  return w;
}
