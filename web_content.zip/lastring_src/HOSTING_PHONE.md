# Phone se free hosting (computer nahi chahiye)

1. github.com par free account banao (phone browser me, "Desktop site" on karke).
2. New repository banao (naam: last-ring, Public). "uploading an existing file" se is zip ke andar ki saari files/folders upload karo
   (index.html, package.json, server/, js/ ... root me hone chahiye, zip ke bahar nikal ke).
3. render.com par GitHub se sign up karo -> New + -> Web Service -> apni last-ring repo chuno.
   Runtime: Node, Build Command: (khali ya `echo ok`), Start Command: `node server/server.js`, Plan: Free -> Create.
4. 2-3 minute baad Render ek link dega, jaise https://last-ring-xxxx.onrender.com
5. Sab dost wahi link browser me kholein (Chrome > "Add to Home screen" bhi kar sakte ho). Bas! Server apne aap connect ho jata hai.

Note: Free plan 15 min kisi ke na aane par so jata hai (pehla open 30-50 sec lega). Restart par friends list reset ho sakti hai.
