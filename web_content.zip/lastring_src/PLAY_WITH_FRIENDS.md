# Dost ke saath khelna — bina server, bina computer

1. Zip ko dono phones me unzip karo (ya sabhi files ek hi folder me rakho) aur `index.html` ko Chrome me kholo.
   Internet on hona chahiye (do phones ko jodne ke liye).
2. Phone 1: lobby me START ke bagal ➕👥 dabao -> group ban jayega, 6-digit code icon ke niche dikhega. Code dost ko bhejo.
3. Phone 2: ➡️ dabao, wo 6-digit code daalo, ✓ dabao -> seedha phone 1 ke group me.
4. Phone 1 (group banane wala = leader) START dabaye -> dono ek hi match me (Squad, baaki bots).

Notes:
- Direct mode me UID / friend request nahi hota (uske liye server chahiye: HOSTING_PHONE.md). Team code wala system poora chalta hai.
- Connection ke liye free PeerJS cloud + free STUN/TURN use hota hai. Kabhi kabhi mobile network (CGNAT) par connect na ho to dono phone same WiFi/hotspot par try karo.
- Group banane wale ka phone match chalata hai; wo chhode to match khatam.
