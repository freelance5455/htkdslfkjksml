'use strict';
/* =====================================================================
   Last Ring — online server (ZERO dependency: sirf Node.js 18+)
   ---------------------------------------------------------------------
   Chalane ke liye:   node server/server.js        (PORT env se port badal sakte ho, default 3000)
   Ye ek hi server game ki files bhi deta hai (http://HOST:3000) aur WebSocket bhi (ws://HOST:3000).
   Kaam: UID account, friend request (bhejo / accept / decline), team code se party, invite, party chat,
         aur match ke dauraan teammates ke beech real-time relay.
   Data `server/data.json` me save hota hai (DB_FILE env se badal sakte ho).
   ===================================================================== */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=+process.env.PORT||3000,ROOT=path.join(__dirname,'..'),DB_FILE=process.env.DB_FILE||path.join(__dirname,'data.json');
const MAX_PARTY=4;

/* ---------------- tiny database ---------------- */
let db={users:{},keys:{}};
try{db=JSON.parse(fs.readFileSync(DB_FILE,'utf8'));db.users=db.users||{};db.keys=db.keys||{}}catch(e){}
let saveT=null;
function save(){clearTimeout(saveT);saveT=setTimeout(()=>{try{fs.writeFileSync(DB_FILE+'.tmp',JSON.stringify(db));fs.renameSync(DB_FILE+'.tmp',DB_FILE)}catch(e){console.error('save failed',e.message)}},400)}
const clean=(s,n)=>String(s==null?'':s).replace(/[\u0000-\u001f<>]/g,'').trim().slice(0,n||16);
function newUid(){for(let i=0;i<50;i++){const u=String(10000000+crypto.randomInt(0,89999999));if(!db.users[u])return u}return String(Date.now()).slice(-8)}

/* ---------------- static files (game) ---------------- */
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.woff2':'font/woff2','.mp3':'audio/mpeg','.ogg':'audio/ogg','.wav':'audio/wav','.webmanifest':'application/manifest+json'};
const httpServer=http.createServer((req,res)=>{
  let p=decodeURIComponent((req.url||'/').split('?')[0]);
  if(p==='/health'){res.writeHead(200,{'content-type':'text/plain'});return res.end('ok')}
  if(p.endsWith('/'))p+='index.html';
  const f=path.normalize(path.join(ROOT,p));
  if(!f.startsWith(ROOT)||/(^|[\\/])(server|node_modules|\.[^\\/]*)([\\/]|$)/.test(path.relative(ROOT,f))){res.writeHead(404);return res.end('not found')}
  fs.readFile(f,(e,d)=>{
    if(e){res.writeHead(404);return res.end('not found')}
    res.writeHead(200,{'content-type':MIME[path.extname(f).toLowerCase()]||'application/octet-stream','cache-control':'no-cache'});res.end(d);
  });
});

/* ---------------- minimal WebSocket (RFC 6455) ---------------- */
const GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
class Sock{
  constructor(s){this.s=s;this.buf=Buffer.alloc(0);this.msg=[];this.open=true;this.onmsg=null;this.onclose=null;
    s.on('data',d=>{this.buf=Buffer.concat([this.buf,d]);if(this.buf.length>262144){this.close(1009);return}this.parse()});
    s.on('close',()=>this.fin());s.on('error',()=>this.fin());s.setNoDelay(true)}
  fin(){if(!this.open)return;this.open=false;if(this.onclose)this.onclose()}
  parse(){
    for(;;){
      const b=this.buf;if(b.length<2)return;
      const fin=!!(b[0]&128),op=b[0]&15,mask=!!(b[1]&128);let len=b[1]&127,o=2;
      if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);o=4}
      else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));o=10}
      if(len>65536){this.close(1009);return}
      if(!mask){this.close(1002);return}
      if(b.length<o+4+len)return;
      const mk=b.slice(o,o+4),data=Buffer.from(b.slice(o+4,o+4+len));
      for(let i=0;i<len;i++)data[i]^=mk[i&3];
      this.buf=b.slice(o+4+len);
      if(op===8){this.close(1000);return}
      if(op===9){this.frame(10,data);continue}
      if(op===10)continue;
      if(op===0||op===1||op===2){
        if(op!==0)this.msg=[];
        this.msg.push(data);
        if(fin){const full=Buffer.concat(this.msg);this.msg=[];if(this.onmsg)this.onmsg(full.toString('utf8'))}
      }
    }
  }
  frame(op,data){
    if(!this.open)return;
    const l=data.length;let h;
    if(l<126)h=Buffer.from([128|op,l]);else if(l<65536){h=Buffer.alloc(4);h[0]=128|op;h[1]=126;h.writeUInt16BE(l,2)}else{h=Buffer.alloc(10);h[0]=128|op;h[1]=127;h.writeBigUInt64BE(BigInt(l),2)}
    try{this.s.write(Buffer.concat([h,data]))}catch(e){}
  }
  send(str){this.frame(1,Buffer.from(str,'utf8'))}
  close(code){if(!this.open)return;const b=Buffer.alloc(2);b.writeUInt16BE(code||1000);this.frame(8,b);try{this.s.end()}catch(e){}this.fin()}
}
httpServer.on('upgrade',(req,socket)=>{
  const key=req.headers['sec-websocket-key'];
  if(!key||String(req.headers.upgrade).toLowerCase()!=='websocket'){socket.destroy();return}
  const acc=crypto.createHash('sha1').update(key+GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+acc+'\r\n\r\n');
  onConnect(new Sock(socket));
});

/* ---------------- game logic ---------------- */
const online=new Map();                 // uid -> conn
const parties=new Map();                // code -> party
const U=uid=>db.users[uid];
const send=(c,o)=>{if(c&&c.open)c.send(JSON.stringify(o))};
const sendUid=(uid,o)=>send(online.get(uid),o);
const info=uid=>{const u=U(uid);return u?{uid,name:u.name}:{uid,name:'?'}};

function socialOf(uid){
  const u=U(uid);if(!u)return null;
  const pc=x=>{const c=online.get(x);return c&&c.party||null};
  return{t:'social',
    friends:u.friends.filter(x=>U(x)).map(x=>({uid:x,name:U(x).name,online:online.has(x),party:pc(x)})),
    inReq:u.inReq.filter(x=>U(x)).map(info),outReq:u.outReq.filter(x=>U(x)).map(info)};
}
const pushSocial=uid=>{if(online.has(uid))sendUid(uid,socialOf(uid))};
function presence(uid){const u=U(uid);if(u)for(const f of u.friends)pushSocial(f)}

function partyState(p){
  return{t:'party',code:p.code,leader:p.leader,mode:p.mode,map:p.map,state:p.state,max:MAX_PARTY,
    members:p.members.map(m=>{const u=U(m);const c=online.get(m);return{uid:m,name:u?u.name:'?',look:c&&c.look||null}})};
}
function pushParty(p){const s=partyState(p);for(const m of p.members)sendUid(m,s)}
function newCode(){const A='0123456789';for(let i=0;i<100;i++){let c='';for(let k=0;k<6;k++)c+=A[crypto.randomInt(0,A.length)];if(!parties.has(c))return c}return null}
function leaveParty(c,reason){
  const p=c.party&&parties.get(c.party);c.party=null;if(!p)return;
  const i=p.members.indexOf(c.uid);if(i<0)return;
  p.members.splice(i,1);
  if(p.state==='match')for(const m of p.members)sendUid(m,{t:'member.left',uid:c.uid});
  if(!p.members.length){parties.delete(p.code)}
  else{if(p.leader===c.uid){p.leader=p.members[0];if(p.state==='match')p.state='lobby'}pushParty(p)}
  send(c,{t:'party',code:null,reason:reason||'left'});
  presence(c.uid);
}
function joinParty(c,p){
  if(c.party)leaveParty(c);
  p.members.push(c.uid);c.party=p.code;pushParty(p);presence(c.uid);
}

function onConnect(c){
  c.uid=null;c.party=null;c.look=null;c.cnt=0;c.t0=Date.now();c.inv={};
  const iv=setInterval(()=>{c.cnt=0},1000);
  c.onclose=()=>{
    clearInterval(iv);
    if(c.uid&&online.get(c.uid)===c){leaveParty(c);online.delete(c.uid);presence(c.uid)}
  };
  c.onmsg=txt=>{
    if(++c.cnt>150)return;                                   // flood guard
    let m;try{m=JSON.parse(txt)}catch(e){return}
    if(!m||typeof m.t!=='string')return;
    try{handle(c,m)}catch(e){console.error('handler',m.t,e.message)}
  };
}

function handle(c,m){
  if(m.t==='ping'){send(c,{t:'pong',ts:m.ts});return}
  if(m.t==='hello'){
    const key=String(m.key||'');if(!/^[a-zA-Z0-9]{16,64}$/.test(key)){send(c,{t:'error',e:'bad_key'});return}
    let uid=db.keys[key];
    if(!uid||!U(uid)){uid=newUid();db.keys[key]=uid;db.users[uid]={uid,name:clean(m.name)||'Player'+uid.slice(-4),friends:[],inReq:[],outReq:[],created:Date.now()}}
    const u=U(uid),old=online.get(uid);
    if(old&&old!==c){leaveParty(old,'other_device');send(old,{t:'error',e:'logged_in_elsewhere'});old.open&&old.close(1000);online.delete(uid)}
    c.uid=uid;if(m.name)u.name=clean(m.name)||u.name;c.look=m.look||null;online.set(uid,c);save();
    send(c,{t:'welcome',uid,name:u.name,v:1});send(c,socialOf(uid));presence(uid);return;
  }
  if(!c.uid)return;
  const u=U(c.uid);
  switch(m.t){
    case'profile':{if(m.name){u.name=clean(m.name)||u.name;save();presence(c.uid);if(c.party){const p=parties.get(c.party);if(p)pushParty(p)}}if(m.look)c.look=m.look;if(c.party&&m.look){const p=parties.get(c.party);if(p&&p.state==='lobby')pushParty(p)}break}
    /* ---- friends ---- */
    case'friend.add':{
      const t=String(m.uid||'').replace(/\D/g,''),v=U(t);
      if(!v){send(c,{t:'notice',k:'no_user'});return}
      if(t===c.uid){send(c,{t:'notice',k:'self'});return}
      if(u.friends.includes(t)){send(c,{t:'notice',k:'already'});return}
      if(u.outReq.includes(t)){send(c,{t:'notice',k:'pending'});return}
      if(v.outReq.includes(c.uid)){                           // unhone pehle hi request bheji thi -> seedha dost
        v.outReq=v.outReq.filter(x=>x!==c.uid);u.inReq=u.inReq.filter(x=>x!==t);
        u.friends.push(t);v.friends.push(c.uid);save();pushSocial(c.uid);pushSocial(t);send(c,{t:'notice',k:'friends_now',name:v.name});sendUid(t,{t:'notice',k:'friends_now',name:u.name});return}
      if(v.inReq.length>=50){send(c,{t:'notice',k:'too_many'});return}
      u.outReq.push(t);v.inReq.push(c.uid);save();pushSocial(c.uid);pushSocial(t);
      send(c,{t:'notice',k:'sent',name:v.name});sendUid(t,{t:'notice',k:'got_request',name:u.name});break}
    case'friend.accept':{
      const t=String(m.uid||''),v=U(t);if(!v||!u.inReq.includes(t))return;
      u.inReq=u.inReq.filter(x=>x!==t);v.outReq=v.outReq.filter(x=>x!==c.uid);
      if(!u.friends.includes(t))u.friends.push(t);if(!v.friends.includes(c.uid))v.friends.push(c.uid);
      save();pushSocial(c.uid);pushSocial(t);sendUid(t,{t:'notice',k:'accepted',name:u.name});break}
    case'friend.decline':{const t=String(m.uid||''),v=U(t);u.inReq=u.inReq.filter(x=>x!==t);if(v)v.outReq=v.outReq.filter(x=>x!==c.uid);save();pushSocial(c.uid);pushSocial(t);break}
    case'friend.cancel':{const t=String(m.uid||''),v=U(t);u.outReq=u.outReq.filter(x=>x!==t);if(v)v.inReq=v.inReq.filter(x=>x!==c.uid);save();pushSocial(c.uid);pushSocial(t);break}
    case'friend.remove':{const t=String(m.uid||''),v=U(t);u.friends=u.friends.filter(x=>x!==t);if(v)v.friends=v.friends.filter(x=>x!==c.uid);save();pushSocial(c.uid);pushSocial(t);break}
    /* ---- party / team code ---- */
    case'party.create':{
      if(c.party)leaveParty(c);
      const code=newCode();if(!code)return;
      const p={code,leader:c.uid,members:[],mode:'squad',map:0,state:'lobby'};parties.set(code,p);joinParty(c,p);break}
    case'party.join':{
      const code=String(m.code||'').toUpperCase().replace(/[^A-Z0-9]/g,''),p=parties.get(code);
      if(!p){send(c,{t:'notice',k:'bad_code'});return}
      if(p.members.includes(c.uid)){pushParty(p);return}
      if(p.members.length>=MAX_PARTY){send(c,{t:'notice',k:'party_full'});return}
      if(p.state!=='lobby'){send(c,{t:'notice',k:'party_busy'});return}
      joinParty(c,p);break}
    case'party.leave':leaveParty(c);break;
    case'party.kick':{const p=parties.get(c.party);if(!p||p.leader!==c.uid||p.state!=='lobby')return;const t=String(m.uid||''),tc=online.get(t);if(tc&&tc.party===p.code&&t!==c.uid){leaveParty(tc,'kicked')}break}
    case'party.set':{const p=parties.get(c.party);if(!p||p.leader!==c.uid||p.state!=='lobby')return;if(Number.isInteger(m.map)&&m.map>=0&&m.map<64)p.map=m.map;pushParty(p);break}
    case'party.invite':{
      const p=parties.get(c.party),t=String(m.uid||'');
      if(!p||!u.friends.includes(t)||!online.has(t)||p.members.includes(t))return;
      const now=Date.now();if(c.inv[t]&&now-c.inv[t]<4000)return;c.inv[t]=now;
      sendUid(t,{t:'invite',from:info(c.uid),code:p.code});send(c,{t:'notice',k:'invited',name:U(t).name});break}
    case'party.chat':{const p=parties.get(c.party);if(!p)return;const text=clean(m.text,120);if(!text)return;for(const x of p.members)sendUid(x,{t:'chat',from:c.uid,name:u.name,text});break}
    case'party.start':{
      const p=parties.get(c.party);if(!p||p.leader!==c.uid||p.state!=='lobby')return;
      if(p.members.length<2){send(c,{t:'notice',k:'need_two'});return}
      p.state='match';p.seed=crypto.randomInt(1,2147483646);
      const mem=p.members.map(x=>({uid:x,name:U(x).name,look:(online.get(x)||{}).look||null}));
      for(const x of p.members)sendUid(x,{t:'match.start',seed:p.seed,map:p.map,mode:p.mode,host:p.leader,members:mem});
      pushParty(p);break}
    case'party.end':{const p=parties.get(c.party);if(!p||p.state!=='match')return;p.state='lobby';pushParty(p);break}
    /* ---- match relay: party ke baaki sab ko / kisi ek ko ---- */
    case'r':{const p=parties.get(c.party);if(!p||p.state!=='match')return;const o=JSON.stringify({t:'r',from:c.uid,d:m.d});for(const x of p.members)if(x!==c.uid){const cc=online.get(x);if(cc&&cc.open)cc.send(o)}break}
    case'rt':{const p=parties.get(c.party);if(!p||p.state!=='match'||!p.members.includes(String(m.to)))return;sendUid(String(m.to),{t:'r',from:c.uid,d:m.d});break}
  }
}

httpServer.listen(PORT,()=>console.log('Last Ring server ready: http://localhost:'+PORT+'  (is URL ko phone/PC browser me kholo)'));
process.on('SIGTERM',()=>{try{fs.writeFileSync(DB_FILE,JSON.stringify(db))}catch(e){}process.exit(0)});
