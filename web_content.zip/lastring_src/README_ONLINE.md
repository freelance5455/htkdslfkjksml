# Last Ring — Online Multiplayer (v15)

## Server chalana (zaroori)
Online khelne ke liye ek server chahiye. Koi npm install nahi — sirf Node.js 16+.

    node server/server.js          # default port 3000
    PORT=8080 node server/server.js

Phir game ko usi address se kholo: http://<server-ip>:3000  (server game files bhi serve karta hai).
Dost bhi wahi address kholein.

## Hosting (free/sasta)
- Render / Railway / Fly.io / koi VPS: repo/zip upload karo, Start command: `node server/server.js`. PORT env wo khud deta hai.
- https site par WebSocket apne aap `wss://` use hoti hai.
- Agar game kisi aur jagah host hai (jaise GitHub Pages), to Friends & Party panel me "Server" box me server ka address likho (e.g. https://mera-server.onrender.com) aur Connect dabao.
- Data `server/data.json` me save hota hai (Render free me restart par reset ho sakta hai; DB_FILE env se path badal sakte ho).

## Kaise khelein
1. Lobby me upar-left player card (naam + Lv) tap karo = Profile (UID + copy). Friends & Party me 3 icon tabs: dost list, ➕ UID se request bhejo, ✉ aayi hui requests accept karo. Accept ke baad dost map selector ke upar UID ke saath dikhte hain, online ho to green dot.
2. Dost ka UID daal ke **Send friend request** → wo **Accept** kare.
3. Lobby me START ke bagal ke icons: **➕👥 = group banao** (6-digit code icon ke niche dikhta hai, tap = copy), **➡️ = group join** (6-digit code daalo, seedha group me), ✕ = group chhodo.
4. Team leader **START** dabaye → sab ek hi match me (Squad mode, 4 tak players, baaki bots).

## Limits
- Online sirf Squad mode me; leader (host) ka phone game chalata hai.
- Character abilities abhi sirf host ke liye; airdrop online me off.
- Host match chhode to match team ke liye khatam ho jata hai; guest chhode to uski jagah bot aa jata hai.

## v22 — Water Worlds
Har map par 1 jharna → nadi → pul → talab (80 alag variants, 20 maps). Slow paani, current, garam kund me healing, pul ki rail collision, awaaz (nadi/jharna/boondh/kadam). Settings me "Water Worlds" on/off. Lobby ke "Water Worlds" button se guide.

## v23 — Direct mode me friends
UID se friend request / accept / invite ab bina server ke chalta hai (dono phone me game khula ho). Team code se judne par dost ka character lobby me aapke bagal me dikhta hai.
