/* ============================================================
   DIÁRIO & AGENDA 2027 — Aplicação unificada
   JavaScript Vanilla · SPA · Persistência em localStorage
   ============================================================ */
(function () {
  'use strict';

  /* ==========================================================
     1. CONSTANTES
     ========================================================== */
  var ANO          = 2027;
  var TOTAL_DIAS   = 365;
  var MESES        = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                      'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  var SEMANA       = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira',
                      'Quinta-feira','Sexta-feira','Sábado'];
  var INICIAIS     = ['D','S','T','Q','Q','S','S'];
  var NUM_ATIV     = 8;
  var K_NOME       = 'app2027.nome';
  var K_DIA        = 'app2027.dia_';
  var K_MIGRADO    = 'app2027.migrado';

  /* ==========================================================
     2. MAPA DOS 365 DIAS (civil 2027)
     ========================================================== */
  var dias = [];
  (function construirMapa() {
    for (var m = 0; m < 12; m++) {
      var totalMes = new Date(ANO, m + 1, 0).getDate();
      for (var d = 1; d <= totalMes; d++) {
        dias.push({
          seq:    dias.length + 1,
          dia:    d,
          mes:    m,
          semana: new Date(ANO, m, d).getDay()
        });
      }
    }
  })();

  /* ==========================================================
     3. ESTADO GLOBAL
     ========================================================== */
  var diaAtual  = 1;
  var diaState  = null;
  var tabAtiva  = 'diario';
  var timerSave = null;
  var timerToast = null;

  /* ==========================================================
     4. REFERÊNCIAS DOM
     ========================================================== */
  var elNome       = document.getElementById('nomeInput');
  var elMeses      = document.getElementById('meses');
  var elDiaNumero  = document.getElementById('diaNumero');
  var elDataDia    = document.getElementById('dataDia');
  var elDataMes    = document.getElementById('dataMes');
  var elSemanaSel  = document.getElementById('diaSemanaSelector');
  var elEstado     = document.getElementById('estado');
  var btnHome      = document.getElementById('btnHome');
  var btnVoltar    = document.getElementById('btnVoltar');
  var btnAnterior  = document.getElementById('btnAnterior');
  var btnSeguinte  = document.getElementById('btnSeguinte');

  var elAguaGrid   = document.getElementById('aguaGrid');
  var elAguaCont   = document.getElementById('aguaContador');
  var elAtivDias   = document.getElementById('atividadesDias');
  var elAtivLista  = document.getElementById('atividadesLista');

  var txt = {
    reflexao:     document.getElementById('txt-reflexao'),
    melhor:       document.getElementById('txt-melhor'),
    notasDiario:  document.getElementById('txt-notas-diario'),
    agradecer:    document.getElementById('txt-agradecer'),
    melhorar:     document.getElementById('txt-melhorar'),
    compromissos: document.getElementById('txt-compromissos'),
    importante:   document.getElementById('txt-importante'),
    compras:      document.getElementById('txt-compras'),
    gastos:       document.getElementById('txt-gastos'),
    amanha:       document.getElementById('txt-amanha'),
    notasAgenda:  document.getElementById('txt-notas-agenda')
  };

  var botoesDia = new Map();
  var tabBtns   = document.querySelectorAll('.tab-btn');

  /* ==========================================================
     5. MODELO DE DADOS
     ========================================================== */
  function defaultDia() {
    var ativs = [];
    for (var i = 0; i < NUM_ATIV; i++) {
      ativs.push({ texto: '', dias: [false,false,false,false,false,false,false] });
    }
    return {
      // Diário
      reflexao: '', melhor: '', notasDiario: '', agradecer: '', melhorar: '',
      semanaDia: null,
      // Agenda
      compromissos: '', importante: '',
      agua: [false,false,false,false,false,false,false,false],
      atividades: ativs,
      compras: '', gastos: '', amanha: '', notasAgenda: ''
    };
  }

  function normalizar(obj) {
    var base = defaultDia();
    if (!obj || typeof obj !== 'object') return base;

    ['reflexao','melhor','notasDiario','agradecer','melhorar',
     'compromissos','importante','compras','gastos','amanha','notasAgenda']
      .forEach(function (k) {
        if (typeof obj[k] === 'string') base[k] = obj[k];
      });

    if (typeof obj.semanaDia === 'number' && obj.semanaDia >= 0 && obj.semanaDia <= 6) {
      base.semanaDia = obj.semanaDia;
    }
    if (Array.isArray(obj.agua) && obj.agua.length === 8) {
      base.agua = obj.agua.map(function (v) { return !!v; });
    }
    if (Array.isArray(obj.atividades)) {
      for (var i = 0; i < NUM_ATIV; i++) {
        var a = obj.atividades[i];
        if (a && typeof a === 'object') {
          base.atividades[i].texto = typeof a.texto === 'string' ? a.texto : '';
          if (Array.isArray(a.dias) && a.dias.length === 7) {
            base.atividades[i].dias = a.dias.map(function (v) { return !!v; });
          }
        }
      }
    }
    return base;
  }

  function carregarDia(seq) {
    try {
      var raw = localStorage.getItem(K_DIA + seq);
      if (!raw) return defaultDia();
      return normalizar(JSON.parse(raw));
    } catch (e) { return defaultDia(); }
  }

  function guardarDia(seq, s) {
    try { localStorage.setItem(K_DIA + seq, JSON.stringify(s)); return true; }
    catch (e) { return false; }
  }

  function diaTemConteudo(seq) {
    try {
      var raw = localStorage.getItem(K_DIA + seq);
      if (!raw) return false;
      var d = JSON.parse(raw);
      if (!d || typeof d !== 'object') return false;

      var simples = ['reflexao','melhor','notasDiario','agradecer','melhorar',
                     'compromissos','importante','compras','gastos','amanha','notasAgenda'];
      for (var i = 0; i < simples.length; i++) {
        var v = d[simples[i]];
        if (v && String(v).trim()) return true;
      }
      if (Array.isArray(d.agua) && d.agua.some(Boolean)) return true;
      if (Array.isArray(d.atividades)) {
        for (var j = 0; j < d.atividades.length; j++) {
          var a = d.atividades[j];
          if (a && a.texto && String(a.texto).trim()) return true;
          if (a && Array.isArray(a.dias) && a.dias.some(Boolean)) return true;
        }
      }
      return false;
    } catch (e) { return false; }
  }

  function agendarGuardar() {
    if (!diaState) return;
    clearTimeout(timerSave);
    timerSave = setTimeout(function () {
      var ok = guardarDia(diaAtual, diaState);
      mostrarEstado(ok ? 'Guardado automaticamente ✓' : 'Não foi possível guardar.');
      atualizarMarcadoresCalendario();
    }, 400);
  }

  function mostrarEstado(msg) {
    if (!elEstado) return;
    elEstado.textContent = msg;
    elEstado.classList.add('visivel');
    clearTimeout(timerToast);
    timerToast = setTimeout(function () {
      elEstado.classList.remove('visivel');
    }, 1800);
  }

  /* ==========================================================
     6. MIGRAÇÃO DE DADOS ANTIGOS
     ========================================================== */
  (function migrar() {
    try {
      if (localStorage.getItem(K_MIGRADO)) return;

      // Nome
      var nomeAntigo = localStorage.getItem('diario2027.nome')
                    || localStorage.getItem('agenda2027.nome');
      if (nomeAntigo && !localStorage.getItem(K_NOME)) {
        localStorage.setItem(K_NOME, nomeAntigo);
      }

      // Diário Reflexivo antigo
      try {
        var oldDiario = localStorage.getItem('diario2027.dados');
        if (oldDiario) {
          var parsed = JSON.parse(oldDiario);
          Object.keys(parsed).forEach(function (k) {
            var seq = parseInt(k, 10);
            if (!seq || seq < 1 || seq > TOTAL_DIAS) return;
            var old = parsed[k] || {};
            var ex  = carregarDia(seq);
            if (old.reflexao)       ex.reflexao = old.reflexao;
            if (old.melhor)         ex.melhor = old.melhor;
            if (old.notas)          ex.notasDiario = old.notas;
            if (old.agradecer)      ex.agradecer = old.agradecer;
            if (old.melhorar)       ex.melhorar = old.melhorar;
            if (typeof old.semana === 'number') ex.semanaDia = old.semana;
            guardarDia(seq, ex);
          });
        }
      } catch (e) {}

      // Agenda Anual antiga
      try {
        for (var i = 1; i <= TOTAL_DIAS; i++) {
          var oldAgenda = localStorage.getItem('agenda2027.dia_' + i);
          if (!oldAgenda) continue;
          var p = JSON.parse(oldAgenda);
          var ex2 = carregarDia(i);
          if (p.compromissos)            ex2.compromissos = p.compromissos;
          if (p.importante)              ex2.importante = p.importante;
          if (Array.isArray(p.agua))     ex2.agua = p.agua.map(Boolean);
          if (Array.isArray(p.atividades)) ex2.atividades = p.atividades;
          if (p.compras)                 ex2.compras = p.compras;
          if (p.gastos)                  ex2.gastos = p.gastos;
          if (p.amanha)                  ex2.amanha = p.amanha;
          if (p.notas)                   ex2.notasAgenda = p.notas;
          guardarDia(i, ex2);
        }
      } catch (e) {}

      localStorage.setItem(K_MIGRADO, '1');
    } catch (e) {}
  })();

  /* ==========================================================
     7. NAVEGAÇÃO SPA
     ========================================================== */
  function mostrarVista(nome) {
    var vistas = document.querySelectorAll('.vista');
    for (var i = 0; i < vistas.length; i++) {
      vistas[i].classList.toggle('activa', vistas[i].id === 'vista-' + nome);
    }
    window.scrollTo(0, 0);
  }

  /* ==========================================================
     8. CALENDÁRIO (dias civis 1-31 por mês)
     ========================================================== */
  function construirCalendario() {
    var frag = document.createDocumentFragment();
    var inicioMes = 0;

    for (var m = 0; m < 12; m++) {
      var card = document.createElement('div');
      card.className = 'mes';

      var h = document.createElement('h3');
      h.className = 'mes-nome';
      h.textContent = MESES[m];
      card.appendChild(h);

      var grid = document.createElement('div');
      grid.className = 'mes-grid';

      for (var i = 0; i < 7; i++) {
        var cab = document.createElement('span');
        cab.className = 'mes-dow';
        cab.textContent = INICIAIS[i];
        cab.title = SEMANA[i];
        grid.appendChild(cab);
      }

      var primeiroDow = new Date(ANO, m, 1).getDay();
      for (var v = 0; v < primeiroDow; v++) {
        var vazio = document.createElement('span');
        vazio.className = 'mes-vazio';
        vazio.setAttribute('aria-hidden', 'true');
        grid.appendChild(vazio);
      }

      var totalMes = new Date(ANO, m + 1, 0).getDate();
      for (var d = 1; d <= totalMes; d++) {
        (function (diaCivil, mesIdx, seq) {
          var info = dias[seq - 1];
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'mes-dia';
          btn.dataset.dia = String(seq);
          btn.textContent = String(diaCivil);
          btn.title = 'Dia ' + seq + ' de ' + TOTAL_DIAS +
                      ' · ' + diaCivil + ' de ' + MESES[mesIdx] + ' de ' + ANO +
                      ' · ' + SEMANA[info.semana];
          btn.setAttribute('aria-label',
            'Dia ' + seq + ' de ' + TOTAL_DIAS + ', ' +
            SEMANA[info.semana] + ', ' +
            diaCivil + ' de ' + MESES[mesIdx] + ' de ' + ANO);
          btn.addEventListener('click', function () { abrirDia(seq); });
          botoesDia.set(seq, btn);
          grid.appendChild(btn);
        })(d, m, inicioMes + d);
      }

      inicioMes += totalMes;
      card.appendChild(grid);
      frag.appendChild(card);
    }

    elMeses.appendChild(frag);
    atualizarMarcadoresCalendario();
    marcarHoje();
  }

  function atualizarMarcadoresCalendario() {
    botoesDia.forEach(function (btn, seq) {
      btn.classList.toggle('tem-registo', diaTemConteudo(seq));
    });
  }

  function marcarHoje() {
    var hoje = new Date();
    if (hoje.getFullYear() !== ANO) return;
    for (var i = 0; i < dias.length; i++) {
      if (dias[i].mes === hoje.getMonth() && dias[i].dia === hoje.getDate()) {
        var b = botoesDia.get(dias[i].seq);
        if (b) b.classList.add('hoje');
        return;
      }
    }
  }

  /* ==========================================================
     9. ABRIR DIA
     ========================================================== */
  function abrirDia(seq) {
    if (seq < 1) seq = 1;
    if (seq > TOTAL_DIAS) seq = TOTAL_DIAS;

    diaAtual = seq;
    diaState = carregarDia(seq);

    var info = dias[seq - 1];
    elDiaNumero.textContent = String(seq);
    elDataDia.textContent   = String(info.dia).padStart(2, '0');
    elDataMes.textContent   = String(info.mes + 1).padStart(2, '0');

    renderSemana(info.semana);
    renderCamposTexto();
    renderAgua();
    renderAtividades();

    btnAnterior.disabled = seq <= 1;
    btnSeguinte.disabled = seq >= TOTAL_DIAS;

    mostrarVista('dia');
    activarTab(tabAtiva);
  }

  function renderSemana(realDow) {
    var activo = (typeof diaState.semanaDia === 'number') ? diaState.semanaDia : realDow;
    elSemanaSel.innerHTML = '';
    for (var i = 0; i < 7; i++) {
      (function (idx) {
        var b = document.createElement('button');
        b.type = 'button';
        b.textContent = INICIAIS[idx];
        b.title = SEMANA[idx];
        b.setAttribute('aria-label', SEMANA[idx]);
        if (idx === activo) b.classList.add('activo');
        b.addEventListener('click', function () {
          diaState.semanaDia = idx;
          renderSemana(realDow);
          agendarGuardar();
        });
        elSemanaSel.appendChild(b);
      })(i);
    }
  }

  function renderCamposTexto() {
    Object.keys(txt).forEach(function (k) {
      txt[k].value = diaState[k] || '';
    });
  }

  /* ==========================================================
     10. ÁGUA
     ========================================================== */
  function renderAgua() {
    elAguaGrid.innerHTML = '';
    diaState.agua.forEach(function (cheio, idx) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'copo' + (cheio ? ' cheio' : '');
      btn.setAttribute('aria-label',
        'Copo ' + (idx + 1) + ' de 8 — ' + (cheio ? 'cheio' : 'vazio'));
      btn.setAttribute('aria-pressed', cheio ? 'true' : 'false');
      btn.innerHTML = '<svg viewBox="0 0 24 32"><use href="#copo"/></svg>';
      btn.addEventListener('click', function () {
        diaState.agua[idx] = !diaState.agua[idx];
        guardarDia(diaAtual, diaState);
        renderAgua();
        atualizarMarcadoresCalendario();
      });
      elAguaGrid.appendChild(btn);
    });
    elAguaCont.textContent = diaState.agua.filter(Boolean).length + '/8';
  }

  /* ==========================================================
     11. ATIVIDADES
     ========================================================== */
  function renderCabecalhoAtividades() {
    elAtivDias.innerHTML = '';
    for (var i = 0; i < 7; i++) {
      var sp = document.createElement('span');
      sp.textContent = INICIAIS[i];
      sp.title = SEMANA[i];
      elAtivDias.appendChild(sp);
    }
  }

  function renderAtividades() {
    elAtivLista.innerHTML = '';
    diaState.atividades.forEach(function (ativ, idx) {
      var linha = document.createElement('div');
      linha.className = 'linha-atividade';

      var input = document.createElement('input');
      input.type = 'text';
      input.placeholder = 'Nova tarefa…';
      input.value = ativ.texto || '';
      input.setAttribute('aria-label', 'Atividade ' + (idx + 1));
      input.addEventListener('input', function () {
        diaState.atividades[idx].texto = input.value;
        agendarGuardar();
      });

      var diasWrap = document.createElement('div');
      diasWrap.className = 'dias-check';
      for (var dIdx = 0; dIdx < 7; dIdx++) {
        (function (d) {
          var b = document.createElement('button');
          b.type = 'button';
          b.className = 'dia-circ' + (ativ.dias[d] ? ' marcado' : '');
          b.textContent = INICIAIS[d];
          b.title = SEMANA[d];
          b.setAttribute('aria-label',
            SEMANA[d] + ' — ' + (ativ.dias[d] ? 'concluído' : 'não concluído'));
          b.setAttribute('aria-pressed', ativ.dias[d] ? 'true' : 'false');
          b.addEventListener('click', function () {
            diaState.atividades[idx].dias[d] = !diaState.atividades[idx].dias[d];
            guardarDia(diaAtual, diaState);
            renderAtividades();
            atualizarMarcadoresCalendario();
          });
          diasWrap.appendChild(b);
        })(dIdx);
      }

      linha.appendChild(input);
      linha.appendChild(diasWrap);
      elAtivLista.appendChild(linha);
    });
  }

  /* ==========================================================
     12. TABS
     ========================================================== */
  function activarTab(nome) {
    tabAtiva = nome;
    tabBtns.forEach(function (b) {
      var on = b.dataset.tab === nome;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    document.getElementById('tab-diario').classList.toggle('active', nome === 'diario');
    document.getElementById('tab-agenda').classList.toggle('active', nome === 'agenda');
  }

  tabBtns.forEach(function (b) {
    b.addEventListener('click', function () { activarTab(b.dataset.tab); });
  });

  /* ==========================================================
     13. EVENTOS GERAIS
     ========================================================== */
  // Nome
  try { elNome.value = localStorage.getItem(K_NOME) || ''; } catch (e) {}
  elNome.addEventListener('input', function () {
    try { localStorage.setItem(K_NOME, elNome.value); } catch (e) {}
  });

  // Textareas
  Object.keys(txt).forEach(function (k) {
    txt[k].addEventListener('input', function () {
      if (!diaState) return;
      diaState[k] = txt[k].value;
      agendarGuardar();
    });
  });

  // Navegação
  btnHome.addEventListener('click', function () {
    atualizarMarcadoresCalendario();
    mostrarVista('capa');
  });
  btnVoltar.addEventListener('click', function () {
    atualizarMarcadoresCalendario();
    mostrarVista('capa');
  });
  btnAnterior.addEventListener('click', function () {
    if (diaAtual > 1) abrirDia(diaAtual - 1);
  });
  btnSeguinte.addEventListener('click', function () {
    if (diaAtual < TOTAL_DIAS) abrirDia(diaAtual + 1);
  });

  // Service worker (offline / APK)
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }

  /* ==========================================================
     14. INIT
     ========================================================== */
  function init() {
    construirCalendario();
    renderCabecalhoAtividades();
    mostrarVista('capa');
  }

  init();
})();