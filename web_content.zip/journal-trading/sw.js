var C="journal-v1",A=["./","index.html","manifest.webmanifest","icon-192.png","icon-512.png","https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"];
function put(r,n){var cp=n.clone();caches.open(C).then(function(c){c.put(r,cp)});return n}
self.addEventListener("install",function(e){e.waitUntil(caches.open(C).then(function(c){return Promise.all(A.map(function(u){return c.add(u).catch(function(){})}))}).then(function(){return self.skipWaiting()}))});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!==C}).map(function(x){return caches.delete(x)}))}).then(function(){return self.clients.claim()}))});
self.addEventListener("fetch",function(e){var r=e.request;if(r.method!=="GET")return;
var same=new URL(r.url).origin===location.origin;
e.respondWith(same
?fetch(r).then(function(n){return put(r,n)}).catch(function(){return caches.match(r).then(function(m){return m||caches.match("index.html")})})
:caches.match(r).then(function(m){return m||fetch(r).then(function(n){return put(r,n)})}))});
