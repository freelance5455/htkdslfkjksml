import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
import helmet from "helmet";
import session from "express-session";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import Database from "better-sqlite3";
import multer from "multer";
import pdf from "pdf-parse";
import fs from "node:fs";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "utku-ai.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS chats (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 title TEXT NOT NULL,
 messages TEXT NOT NULL DEFAULT '[]',
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
`);
const q = {
 userByName: db.prepare("SELECT * FROM users WHERE username = ?"),
 userById: db.prepare("SELECT id, username, role, created_at FROM users WHERE id = ?"),
 createUser: db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)"),
 chats: db.prepare("SELECT id,title,updated_at FROM chats WHERE user_id=? ORDER BY updated_at DESC LIMIT 50"),
 chat: db.prepare("SELECT id,title,messages,updated_at FROM chats WHERE id=? AND user_id=?"),
 saveChat: db.prepare("INSERT INTO chats(user_id,title,messages,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)"),
 updateChat: db.prepare("UPDATE chats SET title=?,messages=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?"),
 deleteChat: db.prepare("DELETE FROM chats WHERE id=? AND user_id=?"),
 allUsers: db.prepare("SELECT id,username,role,created_at FROM users ORDER BY created_at DESC"),
 setRole: db.prepare("UPDATE users SET role=? WHERE id=?")
};

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "8mb" }));
app.use(session({
  name: "utkuai.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-this-session-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));
app.use(express.static(path.join(__dirname, "public")));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024, files: 1 } });

function requireAuth(req,res,next) {
  if (!req.session.user) return res.status(401).json({ error: "Önce giriş yapmalısın." });
  next();
}
function requireAdmin(req,res,next) {
  if (!req.session.user || req.session.user.role !== "admin") return res.status(403).json({ error: "Bu alan yalnızca yöneticiye açık." });
  next();
}
function apiHeaders() {
  return { Authorization: `Bearer ${process.env.AI_API_KEY}`, "Content-Type": "application/json" };
}
function apiBase() {
  return (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
}
function safeMessages(input) {
  if (!Array.isArray(input)) throw new Error("Mesaj biçimi geçersiz.");
  return input.slice(-24).map(m => {
    const role = m.role === "assistant" ? "assistant" : "user";
    let content = m.content;
    if (Array.isArray(content)) {
      content = content.slice(0, 5).map(p => {
        if (p.type === "text") return { type: "text", text: String(p.text || "").slice(0, 9000) };
        if (p.type === "image_url" && /^data:image\/(png|jpeg|webp);base64,/.test(p.image_url?.url || "") && p.image_url.url.length < 5_000_000) {
          return { type: "image_url", image_url: { url: p.image_url.url, detail: "auto" } };
        }
        return null;
      }).filter(Boolean);
    } else content = String(content || "").slice(0, 12000);
    return { role, content };
  });
}

app.get("/api/status", (req,res) => res.json({
  app: "UTKU AI", version: "2.0.0", ready: Boolean(process.env.AI_API_KEY),
  loggedIn: Boolean(req.session.user), user: req.session.user || null
}));

app.post("/api/auth/register", authLimiter, async (req,res) => {
  try {
    const username = String(req.body?.username || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    if (!/^[a-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: "Kullanıcı adı 3-20 karakter olmalı; harf, rakam ve _ kullanılabilir." });
    if (password.length < 10) return res.status(400).json({ error: "Şifre en az 10 karakter olmalı." });
    if (q.userByName.get(username)) return res.status(409).json({ error: "Bu kullanıcı adı zaten alınmış." });
    const hash = await bcrypt.hash(password, 12);
    const count = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
    const isAdmin = count === 0 && process.env.ADMIN_SETUP_KEY && req.body?.adminSetupKey === process.env.ADMIN_SETUP_KEY;
    const info = q.createUser.run(username, hash, isAdmin ? "admin" : "user");
    req.session.user = { id: Number(info.lastInsertRowid), username, role: isAdmin ? "admin" : "user" };
    res.json({ user: req.session.user });
  } catch { res.status(500).json({ error: "Hesap oluşturulamadı." }); }
});

app.post("/api/auth/login", authLimiter, async (req,res) => {
  const username = String(req.body?.username || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  const user = q.userByName.get(username);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Kullanıcı adı veya şifre hatalı." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Oturum başlatılamadı." });
    req.session.user = { id: user.id, username: user.username, role: user.role };
    res.json({ user: req.session.user });
  });
});
app.post("/api/auth/logout", (req,res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/me", (req,res) => res.json({ user: req.session.user || null }));

app.get("/api/chats", requireAuth, (req,res) => res.json({ chats: q.chats.all(req.session.user.id) }));
app.get("/api/chats/:id", requireAuth, (req,res) => {
  const chat = q.chat.get(Number(req.params.id), req.session.user.id);
  if (!chat) return res.status(404).json({ error: "Sohbet bulunamadı." });
  try { chat.messages = JSON.parse(chat.messages); } catch { chat.messages = []; }
  res.json({ chat });
});
app.post("/api/chats", requireAuth, (req,res) => {
  const title = String(req.body?.title || "Yeni sohbet").slice(0,80);
  const messages = JSON.stringify(safeMessages(req.body?.messages || []));
  const info = q.saveChat.run(req.session.user.id, title, messages);
  res.json({ id: Number(info.lastInsertRowid) });
});
app.put("/api/chats/:id", requireAuth, (req,res) => {
  const title = String(req.body?.title || "Sohbet").slice(0,80);
  const messages = JSON.stringify(safeMessages(req.body?.messages || []));
  const info = q.updateChat.run(title,messages,Number(req.params.id),req.session.user.id);
  if (!info.changes) return res.status(404).json({ error: "Sohbet bulunamadı." });
  res.json({ ok: true });
});
app.delete("/api/chats/:id", requireAuth, (req,res) => {
  q.deleteChat.run(Number(req.params.id),req.session.user.id);
  res.json({ ok: true });
});

app.post("/api/chat", requireAuth, apiLimiter, async (req,res) => {
  try {
    if (!process.env.AI_API_KEY) return res.status(503).json({ error: "Sunucu yöneticisi henüz AI API anahtarını ayarlamadı." });
    const messages = safeMessages(req.body?.messages);
    const upstream = await fetch(`${apiBase()}/chat/completions`, {
      method: "POST", headers: apiHeaders(),
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: "Sen UTKU AI adlı Türkçe yapay zekâ asistanısın. Marka/proje sahibi Utku Yılmaz'dır. Doğru, açık ve yararlı yanıt ver. Bilmediğin şeyi uydurma. Görsellerde yalnızca gözlemlenebilir özellikleri anlat. Zararlı veya tehlikeli isteklerde güvenli davran." },
          ...messages
        ],
        temperature: 0.6
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || `AI sağlayıcısı hata verdi (${upstream.status}).` });
    res.json({ reply: data?.choices?.[0]?.message?.content || "Yanıt alınamadı." });
  } catch (e) { res.status(400).json({ error: e.message || "İstek işlenemedi." }); }
});

app.post("/api/image", requireAuth, apiLimiter, async (req,res) => {
  try {
    if (!process.env.AI_API_KEY) return res.status(503).json({ error: "API anahtarı ayarlanmamış." });
    const prompt = String(req.body?.prompt || "").trim().slice(0,2500);
    if (!prompt) return res.status(400).json({ error: "Görsel açıklaması yaz." });
    const upstream = await fetch(`${apiBase()}/images/generations`, {
      method: "POST", headers: apiHeaders(),
      body: JSON.stringify({ model: process.env.IMAGE_MODEL || "gpt-image-1", prompt, size: "1024x1024", n: 1 })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || `Görsel API hatası (${upstream.status}).` });
    const item = data?.data?.[0];
    if (item?.b64_json) return res.json({ image: `data:image/png;base64,${item.b64_json}` });
    if (item?.url) return res.json({ image: item.url });
    res.status(502).json({ error: "Görsel servisi görsel döndürmedi." });
  } catch { res.status(500).json({ error: "Görsel üretiminde bağlantı hatası." }); }
});

app.post("/api/research", requireAuth, apiLimiter, async (req,res) => {
  try {
    if (!process.env.AI_API_KEY) return res.status(503).json({ error: "API anahtarı ayarlanmamış." });
    const question = String(req.body?.question || "").trim().slice(0,2500);
    const upstream = await fetch(`${apiBase()}/responses`, {
      method: "POST", headers: apiHeaders(),
      body: JSON.stringify({
        model: process.env.RESEARCH_MODEL || "gpt-4o-mini",
        tools: [{ type: "web_search_preview" }],
        input: `Türkçe yanıt ver. Güncel web araştırması yap ve kaynakları/bağlantıları belirt. Soru: ${question}`
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || `Araştırma API hatası (${upstream.status}).` });
    const text = data.output_text || (data.output || []).flatMap(x => (x.content || []).filter(c => c.type === "output_text").map(c => c.text)).join("\n");
    res.json({ reply: text || "Araştırma yanıtı alınamadı." });
  } catch { res.status(500).json({ error: "Araştırma sırasında bağlantı hatası." }); }
});

app.post("/api/document", requireAuth, apiLimiter, upload.single("file"), async (req,res) => {
  try {
    if (!req.file || req.file.mimetype !== "application/pdf") return res.status(400).json({ error: "PDF dosyası seçmelisin." });
    const parsed = await pdf(req.file.buffer);
    const extracted = String(parsed.text || "").trim().slice(0,40000);
    if (!extracted) return res.status(422).json({ error: "PDF içinden metin çıkarılamadı. Taranmış PDF için OCR gerekir." });
    res.json({ text: extracted, pages: parsed.numpages || null, filename: path.basename(req.file.originalname).slice(0,120) });
  } catch { res.status(400).json({ error: "PDF okunamadı veya dosya bozuk." }); }
});

app.get("/api/admin/overview", requireAuth, requireAdmin, (_req,res) => {
  const users = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
  const chats = db.prepare("SELECT COUNT(*) AS n FROM chats").get().n;
  res.json({ users, chats, recentUsers: q.allUsers.all().slice(0,30) });
});
app.patch("/api/admin/users/:id", requireAuth, requireAdmin, (req,res) => {
  const role = req.body?.role === "admin" ? "admin" : "user";
  if (Number(req.params.id) === req.session.user.id && role !== "admin") return res.status(400).json({ error: "Kendi yönetici rolünü buradan kaldıramazsın." });
  q.setRole.run(role,Number(req.params.id));
  res.json({ ok: true });
});

app.get("*", (_req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`UTKU AI v2 hazır: http://localhost:${port}`));
