# UTKU AI — Final başlangıç paketi (v2.0)

**Marka/proje sahibi:** Utku Yılmaz  
**Platform:** Android uyumlu web/PWA + Capacitor Android kabuğu  
**Durum:** Kaynak proje hazır; canlı sunucu, API anahtarı ve Android derleme/İmzalama adımları kullanıcı tarafından tamamlanmalıdır.

## Dahil edilen özellikler
- Koyu premium, mobil uyumlu sohbet arayüzü.
- Kullanıcı kaydı ve giriş; şifreler bcrypt ile hash'lenir.
- SQLite üzerinde kullanıcılar ve sohbet geçmişi.
- Fotoğraf ekleme ve görme destekli sohbet modeli.
- API sağlayıcısı destekliyorsa görsel üretimi.
- Web araştırması Responses API aracı üzerinden.
- Tarayıcı destekliyorsa sesle yazma ve yanıtları seslendirme.
- PDF'den metin çıkarma ve sohbet istemine ekleme (taranmış PDF/OCR dahil değildir).
- İlk yönetici hesabı kurulum anahtarıyla oluşturma ve basit yönetici paneli.
- Rate limit, güvenlik başlıkları, oturum çerezi ayarları.
- Capacitor Android proje yapılandırması.

## Yerel kurulum
1. Node.js 20 LTS veya üstünü kur.
2. Proje klasöründe `npm install` çalıştır.
3. `.env.example` dosyasını `.env` olarak kopyala.
4. `.env` içindeki `AI_API_KEY`, `SESSION_SECRET` ve `ADMIN_SETUP_KEY` değerlerini kendin belirle.
5. `npm start` çalıştır.
6. Tarayıcıda `http://localhost:3000` aç.
7. İlk hesap oluşturulurken `ADMIN_SETUP_KEY` ile aynı kurulum kodunu girersen ilk hesap yönetici olur. Bu kodu kimseyle paylaşma.

## Android APK oluşturma
Android uygulamasını derlemek için bilgisayarda Android Studio/Android SDK gerekir:
1. Önce web sunucusunu HTTPS üzerinden internete yayınla. Gerçek kullanımda sunucuya HTTPS, yedekleme, güvenlik ve gizlilik politikası ekle.
2. Android Studio ve Android SDK kur; Java/Gradle gereksinimlerini Android Studio'nun önerdiği sürümlerde tut.
3. Bu klasörde `npx cap add android` komutunu bir kez çalıştır.
4. `npx cap sync android` çalıştır.
5. `npx cap open android` ile Android Studio'da aç.
6. Android Studio'da test için Run; dağıtım için Build > Generate Signed Bundle / APK seç.
7. İmzalama anahtarını güvenli sakla; kimseyle paylaşma.

Not: Bu paket hazır imzalı APK/AAB değildir. APK üretimi Android SDK, build ve imzalama gerektirir. Buradaki ortamda bu adımlar çalıştırılıp doğrulanmadı.

## API yapılandırması
- `AI_BASE_URL`: OpenAI uyumlu API kökü.
- `AI_MODEL`: chat completions ve görme destekli model.
- `IMAGE_MODEL`: sağlayıcının Images API desteklediği model.
- `RESEARCH_MODEL`: Responses API ve `web_search_preview` aracını destekleyen model.

Sağlayıcının model/araç erişimi değişebilir. API hesabında etkin olmayan model veya araç için istek hata verir. API kullanımı ücretlidir; sağlayıcı panelinde harcama limitleri belirle. Model adı ve endpoint desteğini sağlayıcının güncel dokümantasyonundan doğrula.

## Güvenlikte tamamlanması gerekenler
Bu proje üretim öncesi bir başlangıç sürümüdür, denetlenmiş kurumsal ürün değildir:
- Canlı ortamda `SESSION_SECRET` için uzun rastgele değer kullan; varsayılanı bırakma.
- HTTPS zorunlu kullan (`NODE_ENV=production`).
- Kalıcı session store ekle (şu an Express MemoryStore geliştirme amaçlıdır; yeniden başlatmada oturumlar silinir).
- CSRF koruması, e-posta doğrulama/şifre sıfırlama, yedekleme ve log politikası ekle.
- Admin kurulum anahtarını kurulumdan sonra değiştir/sil.
- API harcama kotası, kullanıcı bazlı günlük limit ve izleme ekle.
- Kullanıcıya veri silme/hesap kapatma akışı ve gizlilik metni ekle.
- Bu paketi gerçek kullanıma açmadan önce bir yetişkin/yazılım geliştirici güvenlik incelemesi yapmalı.

## Veri ve gizlilik
Sohbetler SQLite veritabanında sunucuda saklanır. Mesaj, görsel ve araştırma istekleri harici AI sağlayıcısına gönderilebilir. Gerçek ad, adres, şifre, okul bilgisi veya başka özel verileri sohbete/fotoğrafa yüklemeyin. Kullanıcıya açık yayın yapmadan önce gizlilik ve kullanım koşullarını hazırlayın.
