const CACHE="utku-ai-v2";
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(["/","/style.css","/app.js","/manifest.json","/icon.svg"]))));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET"||new URL(e.request.url).pathname.startsWith("/api/"))return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))});
