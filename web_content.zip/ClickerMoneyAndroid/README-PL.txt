CLICKER MONEY — PROJEKT APK NA ANDROIDA

Projekt zawiera Twoją grę Clicker Money w opakowaniu Android WebView.
Nie jest to jeszcze gotowy APK — trzeba go zbudować w aplikacji Code on the Go.

JAK ZBUDOWAĆ NA TELEFONIE:
1. Zainstaluj Code on the Go z oficjalnej strony:
   https://appdevforall.org/code-on-the-go/
2. Przy pierwszym uruchomieniu dokończ instalację narzędzi. Zostaw kilka GB wolnego miejsca i najlepiej użyj Wi-Fi.
3. Rozpakuj ten ZIP w pamięci telefonu.
4. W Code on the Go wybierz otwarcie/import istniejącego projektu i wskaż folder ClickerMoneyAndroid (ten z settings.gradle).
5. Poczekaj na synchronizację Gradle.
6. Wybierz budowanie wariantu debug (zwykle assembleDebug / Build).
7. Po udanym budowaniu APK będzie w:
   app/build/outputs/apk/debug/app-debug.apk
8. Otwórz ten APK i zezwól Code on the Go lub Plikom na instalowanie aplikacji, jeśli Android o to poprosi.

Ważne:
- Pierwsze pobranie narzędzi może zająć sporo czasu i danych.
- Jeśli pojawi się błąd Gradle/toolchain, zapisz dokładny komunikat; ustawienia wersji IDE mogą się zmieniać.
- APK debug nadaje się do własnej instalacji i testów. Publikacja w Google Play wymaga osobnego podpisania/release i spełnienia wymogów Google Play.
- Gra używa localStorage do zapisu postępu na tym urządzeniu.
