# Mini-RL Android (APK)

Este projeto coloca o jogo Mini-RL existente dentro de um aplicativo Android em tela cheia usando WebView. O jogo original fica em `app/src/main/assets/index.html`.

## Como obter o APK sem ter computador

O projeto inclui `.github/workflows/build-apk.yml`, que usa o GitHub Actions para compilar o APK na nuvem.

### Configuração inicial no GitHub pelo celular

1. Abra o repositório `Rocket-league-Native-for-Xbox-360-rgh`.
2. Toque em **Add file → Create new file**.
3. Como nome do arquivo, digite `.github/workflows/build-apk.yml`.
4. Abra o arquivo `build-apk.yml` deste ZIP, copie todo o conteúdo e cole no editor do GitHub. Faça commit na branch `main`.
5. Depois, no repositório, toque em **Add file → Upload files** e envie este arquivo ZIP inteiro com o nome `MiniRL-Android-Project.zip`. Faça commit.
6. Abra a aba **Actions**, escolha a execução mais recente de **Build Mini-RL APK** e aguarde ficar verde.
7. Abra a execução concluída e baixe o artefato **Mini-RL-APK**. Dentro dele estará `app-debug.apk`. Extraia o ZIP do artefato e instale o APK no Android.

A primeira execução, antes de enviar o ZIP do projeto, pode falhar porque os arquivos ainda não foram adicionados. Isso é esperado; envie o ZIP depois.

## Multiplayer online

O HTML incluído já tem a tela de criar sala/entrar com código e usa PeerJS pela internet. Os dois jogadores precisam de conexão com a internet. O APK permite abrir o jogo como aplicativo, mas não garante que todas as redes ou versões do Android/WebView consigam conectar; isso precisa ser testado em dois aparelhos. Se a conexão falhar, o APK não corrige sozinho um problema do serviço de sinalização ou da rede.

## Observações

- Este projeto é um APK de teste (`debug`), não um app publicado na Play Store.
- Não é um port nativo para Xbox 360.
- O projeto ainda precisa ser compilado pelo GitHub Actions; este ZIP contém os arquivos-fonte, não um APK pronto.
