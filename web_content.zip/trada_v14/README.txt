TRADA Photo Manager OCR V14 - Mobile HTML APK package

Use this ZIP with an HTML-to-APK builder. Start file: index.html.

Changes in V14:
- Removed Add Photos button from Home.
- Removed Notes page and separate Metadata page.
- Removed Export Excel / Important controls.
- Added Folders page with compact thumbnails.
- Added Menu & Settings with folder hide/import controls.
- Supports selecting a device photo root via Android folder picker and recursively importing image files.
- Hidden folders are excluded from the library and OCR.
- Home controls and thumbnails are smaller for phones.
- Sort by date, filename, folder, location, tags, latitude, longitude, OCR and size.
- Open any image to edit tags, location, description, GPS/date and OCR text.
- OCR remains available through Tesseract.js.

Important Android limitation:
A normal HTML/WebView app cannot silently scan all phone storage without Android storage permission. Therefore the app asks you to select the device photo root once; after that it imports images from the selected folder when the WebView permits access.
