function CAPA(nr) {
let div = document.getElementById("goTo");
div.innerHTML = capa[nr].join("<p><p>");}
///"livro.js"///
let capitulos = {
1: [`<h2>DE 12 DE JUNHO DE 1942 A 1 DE AGOSTO DE 1944</h2><p>A edição original desta obra foi publicada em Amesterdão, pela editorial - Contact - com o  
Título - Het Achterhuis. - Achteruis - significa atrás ou por detrás, a &quot;huis&quot;, casa. Nas velhas casas de  
Amesterdão as dependências que dão para o jardim ou para o pátio podem separar-se das partes voltadas para a rua de  
modo a ficarem independentes, embora pertençam ao mesmo prédio.</p>
<p>Por não haver expressão apropriada em português, resolvemos chamar a esta parte da  
casa &quot;o anexo&quot;, apesar de não ser propriamente um anexo.</p>
<p>Utilizámos para a tradução do livro a edição alemã e o original holandês.</p>` ],

2: [`<h2>PREFÁCIO</h2><p>ANNE Frank pertencia a uma família judaica de Frankfort que, em 1933, fugindo às  
perseguições do regime hitleriano, se refugiou na Holanda, onde supunha encontrar a paz e a segurança. Mas, logo depois  
da invasão da Holanda pelos alemães, as perseguições aos judeus continuaram ali com tal violência que os Frank  
resolveram - mergulhar -, designação que então se dava ao desaparecimento voluntário de pessoas perseguidas, ou por  
razões políticas ou por discriminações raciais, e que passavam a ter uma existência ilegal ou clandestina. Durante dois  
anos, que abrangem o período de guerra de 1942 a 1944, não podem sair à rua e vivem sob a constante ameaça de serem  
descobertos pela polícia.</p>
<p>Anne, rapariga em pleno período de desenvolvimento físico, esse período delicado e  
importante na vida de qualquer adolescente, mas especialmente decisivo quando se tem uma sensibilidade e uma  
inteligência como a dela, escrevia com regularidade um diário, em forma de cartas, a uma amiga imaginária. Este diário  
tornou-se não só um dos mais comoventes depoimentos contra a guerra, contra a injustiça e a crueldade dos homens  
como, também, um dos mais puros documentos psicológicos que todos, e sobretudo os que contactam com gente nova,  
deviam ler.</p>
<p>Anne não escreveu o seu diário a pensar na publicidade, nem porque fosse incitada a  
fazê-lo, mas única e simplesmente porque tinha de o escrever-para si própria, para - aliviar - o coração, como ela diz várias  
vezes, por essa forte necessidade íntima que caracteriza o artista e a que ela não se poderia furtar, nem que quisesse.</p>
<p>&quot;Quando escrevo sinto um alívio, a minha dor desaparece, a coragem volta... Ao  
escrever sei esclarecer todos os meus pensamentos, os meus ideais, as minhas fantasias&quot;.</p>
<p>Não se trata, portanto - e isto é fundamental - de uma dessas produções de menino  
prodígio, lançado e explorado pela família comercialmente, mas sim de uma autêntica obra de arte a que um crítico suíço  
chamou - uma confissão clássica da puberdade de hoje, que ultrapassa todos os limites do circunstancial.</p>
<p>Como é que foi possível escrever-se uma obra destas entre os treze e os quinze anos de  
idade? Tão extraordinário caso tem a sua explicação: o isolamento, os sacrifícios diários, as angústias, o medo e,  
principalmente, a morte, a pairar sobre esta criança de uma inteligência e de um espírito de observação invulgares, fizeram  
com que ela amadurecesse prematuramente e fosse assim, pouco a pouco, penetrando em regiões que, em circunstâncias  
normais, só viria a explorar muito mais tarde. Ela própria sente isto e explica-o: &quot;Vim para o anexo quando tinha treze  
anos e, por isso, fui obrigada a reflectir mais cedo sobre o Mundo e a fazer a descoberta de mim mesma como de um ser  
humano que deseja ser independente..No entanto é preciso notar: Anne não perde a frescura infantil nem esses gostos  
próprios do adolescente, como por exemplo coleccionar fotografias de artistas de cinema ou fantasiar-se com as roupas  
dos adultos. É que Anne não é um monstro, Anne é apenas uma adolescente a quem quiseram roubar o direito de o  
ser.</p>
<p>Nem a criança nem o adolescente sabem, em regra, compreender-se e analisar-se. É o  
adulto que, com a distância dos anos, a experiência da vida, a cultura e a serenidade indispensáveis, contempla e  
interpreta estes períodos passados da sua vida. Por isso Anne Frank há-de ser um dos casos à parte na literatura  
universal, com um significado denso e único.</p>
<p>Anne Frank vivia torturas que marcam qualquer indivíduo de qualquer idade mas muito  
especialmente um indivíduo em formação. Forçada a viver como um pássaro na gaiola Sinto-me como um pássaro a quem  
cortaram as asas e que bate, na escuridão, contra as grades da sua gaiola estreita -, afina os sentidos, concentra-os sobre  
o pequeno espaço em que a sua vida e a dos companheiros de destino se move, procura não só desabafar a sua revolta  
de adolescente, de judia expulsa da comunidade dos homens, vítima de uma guerra impiedosa, mas, também, encontrar as  
explicações e as interpretações de tudo isto.</p>
<p>Ao leitor atento não pode escapar o crescendo dos apontamentos de Anne, tanto no que  
respeita ao seu espírito analítico como à própria força emocional. Se as primeiras páginas, escritas ainda no período de  
liberdade, são puramente infantis e correspondem à sua idade real, as últimas, que precedem a interrupção definitiva do  
diário, são de uma tal maturidade que nos fazem estremecer pelo seu profundo poder de introspecção e compreensão.</p>
<p>- Vejo-me em todos os meus actos como se se tratasse de uma pessoa estranha. Enfrento  
esta Anne com absoluta imparcialidade, sem pretender desculpá-la e observo o que ela faz de mal e de bem. Esta  
autocontemplação nunca me larga, e não posso pronunciar uma palavra sem pensar logo em seguida: &quot;devia ter dito  
isto de outra maneira&quot;, ou: &quot;foi bem dito...&quot;.</p>
<p>Os outros só nos podem dar conselhos ou indicar-nos o caminho a seguir. Mas a formação  
definitiva do carácter está nas próprias mãos de cada indivíduo.</p>
<p>Reencontramo-nos em Anne! Sentimos a verdade, nua e crua, em cada uma das suas  
palavras. E é precisamente por isso, pela identidade dos sentimentos humanos, independentes de latitudes e de raças, que  
esta obra ganha cunho de universalidade, de documento humano.</p>
<p>Eis a pergunta que nos surge: terá a morte, sempre à espreita, dado a Anne um empurrão  
mais forte, obrigando-a urgentemente a apanhar e exprimir a vida em flagrante, antes de esta lhe fugir?</p>
<p>Ao considerar que Anne se limita quase exclusivamente a apontar os acontecimentos diários  
da vida no esconderijo, verificamos com espanto que nunca lhe falta assunto. Até uma caneta, que por engano foi parar ao  
fogão e ardeu, lhe serve para escrever uma &quot;Ode à minha caneta&quot;. Num estilo simples, cristalino, invulgar em  
pessoas da sua idade, que costumam usar uma linguagem pretensiosamente - literária -, desenha, com admirável  
facilidade, o ambiente e as pessoas.</p>
<p>Todas as figuras se tornam nossas conhecidas, familiares, com as suas atitudes e os seus  
comportamentos tantas vezes contraditórios e, justamente por isso, tão reais. Anne não vê com sentimentalismo nem com  
ódio, e como no seu mundo não há ninguém perfeito nem ninguém absolutamente imperfeito, todos são vivos, quase  
palpáveis.</p>
<p>É óbvio que as reacções de Anne dependem muito da sua disposição e que as suas  
personagens surgem filtradas pelas suas dores, desânimos, alegrias, paixões e perspectivas, de modo que umas vezes  
são mais aceitáveis do que outras. Mas não é assim, mesmo na vida, e não vemos nós, ao fim e ao cabo, as pessoas não  
apenas como são, mas também conforme a nossa disposição do momento?</p>
<p>Não falta a Anne aquele raro dom que Thomas Mann considerava indispensável para se  
seguir uma obra de arte: o sentido do humor. Estudando-se sempre a si própria, ela reconhece os seus defeitos e as suas  
qualidades. E quanto ao seu sentido do humor diz: &quot;...e mesmo nos momentos mais perigosos, vejo ainda o cômico da  
situação e não posso deixar de me rir&quot;.,Se, por um lado, o próprio Thomas Mann está presente nesta frase, está-o  
talvez mais ainda Charlie Chaplin..Não vê ele nos momentos mais trágicos, mais perigosos - e mesmo na sua balada  
judaica &quot;O Ditador&quot; -o cômico das situações?</p>
<p>Assim, parece-nos verdadeiramente chaplinesca a descrição do assalto ao armazém, nessa  
terrível noite que ficará gravada na memória de todos como a mais angustiosa das noites passadas no - anexo -, onde se  
pressente, apesar do abalo forte que Anne sofreu, o sorriso a brincar-lhe nos lábios quando ela, por exemplo, conta como  
acordou com a cabeça da sra. van Daan em cima dos seus pés. Chamamos também a atenção para cenas como aquela em  
que o grupo - mergulhado - descasca as batatas, ou aquelas em que a sra. van Daan desafia o marido com as suas  
conversas políticas. Em meia dúzia de traços, através de diálogos vivos e sem que a autora intervenha a explicar as  
personagens, elas são recortadas de modo que se nos revelam com todas as suas virtudes, manhas e limitações.</p>
<p>Talvez haja momentos em que Anne possa parecer-nos demasiado dura, sobretudo quando  
fala das suas relações com a mãe, ou se queixa do pai, este admirável homem que ela, bem o sentimos, coloca acima de  
tudo e de todos. Mas a dureza de Anne não é mais do que o resultado do conhecido conflito da adolescência a que ela, por  
ser inteligente e incapaz de aceitar as coisas incondicionalmente, dá expressão. O choque com a mãe, pouco atenta aos  
problemas íntimos da filha, é inevitável e agrava-se devido às circunstâncias em que são obrigadas a conviver.  
Provavelmente, ter-se-ia atenuado numa vida normal, como aliás a própria Anne reconhece mais de uma vez.</p>
<p>Todos os - mergulhados - sofrem as consequências daquele isolamento. Sentimos-lhes a  
tensão nervosa que, em grande parte, provém da saturação de um convívio ininterrupto e forçado, em espaço tão restrito. E  
Anne, vendo como a mesquinhez se apodera daquela gente a que falta a liberdade, põe-na em flagrante contraste com  
esses corajosos holandeses, os protectores do pequeno grupo, que, sempre que entram em cena, trazem consigo a  
aragem fresca do mundo exterior.</p>
<p>Mas, apesar de tudo, dá-se no pequeno mundo de sofrimentos do - anexo - o eterno milagre  
da vida: o despertar do amor entre Anne e Peter. São de uma insuperável pureza as descrições dos seus primeiros idílios.  
&quot;Quando o Peter e eu estamos sentados num caixote duro, no meio de ferros velhos e de pó, muito juntos, eu com um  
braço em volta dos seus ombros, ele com um braço em volta dos meus ombros, quando ele brinca com uma madeixa do  
meu cabelo, quando lá fora se ouve o chilrear dos pássaros, quando se vêem as árvores a pintarem-se de verde, quando o  
Sol nos chama e o ar é todo ele azul, oh!, então os meus desejos são infinitos&quot;. Mas sabemos desde logo que aquele  
rapaz bonito, bom, um tanto simplório, não pode corresponder às ânsias e exigências de uma rapariga como Anne que, em  
determinada altura, aponta no seu diário: &quot;O melhor seria que ele, na maior parte das vezes, estivesse acima de  
mim&quot;, e mais tarde: &quot;O Peter e eu passamos os dois anos mais importantes para a nossa formação aqui no  
anexo, falamos muitas vezes sobre o passado, o presente e o futuro, mas, como eu já disse, sinto a falta de qualquer coisa  
de mais autêntico; e eu tenho a certeza de que essa coisa existe&quot;. De resto, Anne, pela força e intensidade da sua  
vida interior, pela sua imensa sede de penetrar nas profundidades da vida e ainda pelo que nela há de extraordinário,  
digamos mesmo de maravilhoso, e, em certa medida, de inacessível para pessoas como o Peter van Daan, está, desde  
logo, condenada àquela solidão de todas as pessoas que ultrapassam os limites das normas gerais.</p>
<p>Por tudo o que neste livro está expresso: os problemas comuns a todos nós - a nossa  
coragem, as nossas fraquezas e, também, as nossas esperanças-, apercebemo-nos mais do que nunca do absurdo de  
todas as teorias de discriminação racial..Ninguém pode deixar de sentir, ao ler as cartas de Anne Frank, como, ao fim e ao  
cabo, as alegrias e as lágrimas humanas são as mesmas em todos os seres humanos e em todas as partes do mundo.</p>
<p>Assim o sentiu, também, a juventude alemã de hoje, cuja reacção perante esta obra talvez  
seja, desde há muito, o mais luminoso clarão de esperança que temos visto brilhar.</p>
<p>Anne Frank, vítima de uma época de injustiças e de violências desumanas, tornou-se um  
símbolo. As várias manifestações de simpatia de que é objecto culminaram, em 1 de Março último, com uma peregrinação  
de jovens alemães ao antigo campo de concentração de Bergen-Belsen, onde o corpo de Anne foi atirado, com centenas  
de milhares de outros corpos, para a vala comum. - Não queremos trilhar os caminhos dos nossos pais -, é o lema desta  
nova juventude.</p>
<p>E vem-nos à mente esta frase que Anne escreveu pouco antes da sua deportação para as  
fábricas da morte: &quot;Creio no que há de bom no homem&quot; frase que define toda a força e generosidade dessa  
pobre criança, radiante da sua mocidade, que soube exprimir todo um mundo de problemas da juventude dos nossos dias:  
&quot;Eis a dificuldade do nosso tempo: mal começam a germinar em nós ideais, sonhos, belas esperanças, logo a  
realidade cruel se apodera de tudo isto para o destruir totalmente&quot;.</p>
<p>Mas não conseguiram destruir a força de Anne Frank. A sua obra, já traduzida em dezanove  
línguas e estudada nas classes superiores dos liceus alemães, ergueu-se como implacável libelo contra os seus  
assassinos. Anne Frank vive e continuará a viver ainda por muito tempo. Em 4 de Abril de 1944 escreveu:</p>
<p>- Quero continuar a viver depois da minha morte!</p>
<p>Cumpriu-se o seu desejo.</p>
<p>Para nossa orientação e para melhor podermos informar o leitor, pusémo-nos em contacto  
com o sr. Otto Frank, pai de Anne, o único sobrevivente das oito pessoas que viveram escondidas no - anexo -. Eis os  
esclarecimentos que nos deu:</p>
<p>Os oito - mergulhados - foram primeiro encerrados no campo de concentração de  
Westerbrok, na Holanda, e depois transferidos para o campo de Auschwitz, na Alta Silésia, nos princípios de Novembro de  
1944. Anne e sua irmã foram levadas para o campo de Bergen-Belsen, no norte da Alemanha, onde ambas morreram.</p>
<p>Nunca se pôde averiguar quem denunciou o esconderijo.</p>
<p>Os adultos falavam quase sempre em alemão, porém os adolescentes, que tinham  
frequentado a escola de Amesterdão, preferiam falar e escrever em holandês.</p>
<p>Salvaram-se e ainda existem alguns dos contos de fadas e outras histórias que Anne  
escreveu. Dois deles estão publicados em língua holandesa e alemã com os títulos - Wet je nog - e - Weisst du noch -,  
respectivamente.</p>`],

3: [`<h2>Na sexta-feira acordei às cinco horas.</h2><p>Não era de  admirar, pois fazia anos; mas não queriam que eu me levantasse tão cedo e tive de dominar a minha curiosidade até às  
sete menos um quarto. Depois não pude mais.</p>
<p>Corri para a sala de jantar, onde o Mohrchen, o nosso gatinho, me cumprimentou com  
grandes festas. Depois das sete fui ter com meus pais e com eles entrei na sala de estar, para desembrulhar e ver as  
minhas prendas.</p>
<p>Foi a ti, meu diário, que vi em primeiro lugar, e eras, sem dúvida, a prenda mais bonita. Tive  
um ramo de rosas, um cacto, algumas begónias. Eram as primeiras prendas de flores, mas, depois, recebi muitas mais. O  
pai e a mãe deram-me muitas coisas e os amigos também me estragaram com mimos. Assim recebi, entre outras prendas, a  
- câmara escura -, um jogo, muitas guloseimas, um jogo de paciência, um broche, - Os Mitos e Lendas Holandeses de  
Joseph Gohen, e ainda um livro encantador - A viagem de férias de Daisys à serra -, e dinheiro com que depois comprei os  
- Mitos gregos e romanos -. Estupendo!</p>
<p>Depois veio Lies buscar-me e fomos para a escola.</p>
<p>Primeiro ofereci rebuçados aos professores (2) e aos colegas e depois começámos a  
trabalhar.</p>
<p>Por hoje vou terminar.</p>
<p>Estou tão contente de te ter a ti.</p>
<h2>Segunda-feira, 15 de Junho de 1942</h2>
<p>Sábado à tarde foi a festa dos meus anos. Passámos um filme - O guarda do farol - com  
Rin-tin-tin), que agradou muito às minhas amigas. Fartámo-nos de fazer tolices e estivemos divertidíssimas. Vieram muitos  
rapazes e raparigas. A mãe teima em querer saber com quem eu mais tarde gostaria de casar. Julgo que ela ficaria  
espantada se soubesse que gosto do Peter Wessel, pois eu faço-me sempre desentendida quando se fala nele. Com a Lies  
Goosens e a Sanne Houtman convivo há anos e até agora tinham sido elas as minhas melhores amigas.</p>
<p>Ultimamente conheci Jopie van der Waal no Liceu judaico.</p>
<p>Estamos muitas vezes juntas, e hoje é ela a minha melhor amiga. A Lies anda agora mais  
vezes com uma outra amiga, e a Sanne frequenta outra escola onde arranjou uma amiga.</p>
<h2>Sábado, 20 de Junho de 1942</h2>
<p>Durante uns dias não escrevi nada porque, primeiro quis pensar seriamente na finalidade e  
no sentido de um diário. Experimento uma sensação singular ao escrever o meu diário. Não é só por nunca ter - escrito -,  
suponho que, mais tarde, nem eu nem ninguém achará interesse nos desabafos de uma rapariga de treze anos. Mas na  
realidade tudo isso não importa. Apetece-me escrever e quero aliviar o meu coração de todos os pesos.</p>
<p>- O papel é mais paciente do que os homens -. Era nisso que eu pensava muitas vezes  
quando, nos meus dias melancólicos, punha a cabeça entre as mãos e sem saber o que havia de fazer comigo. Ora queria  
ficar em casa, ora queria sair e, a maior parte das vezes, ficava-me a cismar sem sair do sítio. Sim, o papel é paciente! E  
não tenciono mostrar este caderno com o nome pomposo de - Diário - seja a quem for, a não ser que venha a encontrar na  
minha vida o tal - grande amigo - ou a tal - grande amiga -.</p>
<p>De resto, a mais ninguém poderá interessar o que vou escrever. E pronto!, cheguei ao ponto  
principal de todas estas considerações: não tenho uma verdadeira amiga!, vou-me explicar melhor, pois ninguém pode  
compreender que uma rapariga de treze anos se sinta só. É, de facto, coisa estranha. Tenho pais simpáticos e bons, tenho  
uma irmã de dezasseis anos, ao todo, por aí uns trinta conhecidos ou o que se chama geralmente - amigos -. Tenho uma  
comitiva de admiradores que me fazem todas as vontades. Mesmo na aula tentam ver-me o rosto com um espelhinho de  
bolso e só se dão por satisfeitos quando lhes sorrio. Tenho parentes, tias e tios, muito simpáticos, uma casa bonita, e,  
pensando bem, não me falta nada, senão uma amiga! Com todos os meus numerosos conhecidos, só consigo fazer tolices  
ou falar sobre coisas banais.</p>
<p>Não me é possível abrir-me, sinto-me como que &quot;abotoada&quot;.</p>
<p>Pode ser que esta falta de confiança seja defeito meu.</p>
<p>Mas não há nada a fazer e tenho pena de não poder modificar as coisas.</p>
<p>Por tudo isto é que escrevo um diário. E para evocar na minha fantasia a ideia da amiga há  
tanto tempo desejada, não quero, como qualquer pessoa, assentar só factos. Este diário é que há-de ser a minha amiga, e  
vou-lhe pôr um nome. Essa amiga chama-se Kitty.</p>
<p>Seria incompreensível a minha conversa com a Kitty se eu não contasse primeiro a história  
da minha vida, embora sem grande vontade.</p>
<p>Quando meus pais casaram tinha o meu pai trinta e seis anos e a minha mãe vinte e cinco.  
Minha irmã Margot nasceu em 1926 em Frankfort sobre o Reno; em 12 de Junho de 1929 vim eu. como somos judeus,  
emigrámos, em 1933, para a Holanda, onde meu pai se tornou director da Travis A-G. Esta firma trabalha em estreita  
ligação com a Kolen 82 Go., no mesmo edifício.</p>
<p>A nossa vida decorria com as aflições do costume, pois as pessoas de família que ficaram  
na Alemanha não escaparam às perseguições de Hitler. Depois dos &quot;progroms&quot; de 1938 os dois irmãos de minha mãe fugiram para a América. Minha avó veio viver  
connosco. Tinha nessa altura setenta e três anos. A partir de 1940 foram-se acabando os bons tempos. Primeiro veio a  
guerra, depois a capitulação, em seguida a entrada dos alemães. E então começou a miséria. A uma lei ditatorial seguia-se  
outra; e, em especial para os judeus, as coisas começaram a ficar feias. Obrigaram-nos a usar a estrela e a entregar as  
bicicletas, não nos deixavam andar nos carros eléctricos e muito menos de automóvel.</p>
<p>Os judeus só podiam fazer compras das 3 às 5 horas-e só em lojas judaicas. Não podiam  
sair à rua depois das oito da noite e nem sequer ficar no quintal ou na varanda.</p>
<p>Não podiam ir ao teatro nem ao cinema, nem frequentar qualquer lugar de divertimentos.  
Também não podiam nadar, nem jogar tenis. ou hóquei, nem praticar qualquer outro desporto. Os judeus não podiam visitar  
os cristãos.</p>
<p>As crianças judaicas eram obrigadas a frequentar escolas judaicas. cada vez saíam mais  
decretos... Toda a nossa vida estava sujeita a enorme pressão. Jopie dizia a cada passo: &quot;Já nem tenho coragem  
para fazer seja o que for porque tenho sempre medo de fazer qualquer coisa que seja proibida&quot;.</p>
<p>Em Janeiro deste ano morreu a avózinha. Ninguém imagina quanto eu gostava dela e que  
falta me tem feito.</p>
<p>Em 1939, mandaram-me para o jardim-escola - Montessori -.</p>
<p>Depois estudei ainda as primeiras classes primárias naquela escola. No último ano, a  
directora, a sra. K., era chefe da minha turma. No fim do ano despedimo-nos comovidas, e ambas chorámos muito. Desde o  
ano passado a Margot e eu frequentamos o Liceu judaico; ela está no quarto ano e eu no primeiro.</p>
<p>Nós, os quatro da família, ainda não temos muito de que nos queixar. Estamos bem. E assim  
cheguei ao presente, à data de hoje.</p>
<h2>Sábado, 20 de Junho de 1942</h2>
<p>Querida Kitty:</p>
<p>Vou começar já. Está tudo tão calmo! O pai e a mãe saíram e a Margot foi a casa de uma  
amiga jogar o pingue pongue. Também me apaixonei ùltimamente por este jogo.</p>
<p>Como nós, os jogadores de pinguepongue, gostamos imenso de tomar sorvetes, o jogo  
acaba quase sempre numa excursão a qualquer das confeitarias onde os judeus ainda podem entrar: &quot;Delphi&quot;  
ou &quot;Oasis&quot;. Não importa se temos muito ou pouco dinheiro no porta-moedas. As duas confeitarias estão tão  
cheias que entre toda aquela gente sempre se encontram rapazes das nossas relações ou até um ou outro admirador. E  
tantos sorvetes nos querem oferecer que nem numa semana seríamos capazes de os tomar todos.</p>
<p>Presumo que ficaste admirada por eu, apesar de tão nova, já falar em admiradores.  
Infelizmente esta desgraça é inevitável na nossa escola. Quando um dos rapazes pergunta se pode acompanhar-me a casa  
de bicicleta é certo e sabido que se apaixona logo por mim e que não me perde de vista durante algum tempo. Depois,  
pouco a pouco, vai acalmando, sobretudo porque eu faço de conta que não vejo os olhares apaixonados e continuo  
alegremente a pedalar. Se, por vezes, aquilo passa das marcas, ponho-me a fazer umas habilidades na bicicleta, a minha  
pasta cai ao chão e, por amabilidade, o rapaz ; vê-se obrigado a descer. Apanha a pasta e até ma entregar tem tempo para  
se acalmar. Estes ainda assim são os mais inofensivos, mas há também alguns que nos atiram beijos ou nos tocam no  
braço. Mas comigo a coisa não pega.</p>
<p>Quando isso sucede, desço da bicicleta e declaro que lhes dispenso a companhia ou  
finjo-me ofendida e mando-os passear.</p>
<p>E pronto, Kitty, foi colocada a primeira pedra da nossa amizade. Até amanhã!</p>
<p>Tua Anne</p>
<h2>Domingo, 21 de Junho de 1942</h2>
<p>Querida Kitty:</p>
<p>Toda a nossa turma treme: a Reunião de conselho dos professores está à porta. Metade da  
turma passa o tempo a apostar quem passa de classe e quem chumba. A Miep de Jong e eu escangalhamo-nos a rir por  
causa das nossas companheiras de carteira que já apostaram todo o seu dinheiro de bolso. De manhã à noite andam a  
rezar: &quot;Tu passas, tu chumbas, sim, não...&quot; Nem os olhares suplicantes da Miep nem as minhas sérias tentativas  
para as meter na ordem conseguem nada daquela gente. Há tantos mandriões na minha turma que eu, se mandasse,  
reprovava metade. Os professores são as pessoas mais caprichosas do mundo, mas talvez sejam, neste caso, caprichosos  
no bom sentido.</p>
<p>Dou-me razoavelmente com os professores e com as professoras. Ao todo são nove, sete  
homens e duas senhoras.</p>
<p>O sr. Kepler, o velho professor de matemática, ao princípio embirrava comigo, por eu palrar  
muito. Andava constantemente a avisar-me, até que me marcou um trabalho de castigo. Mandou-me fazer uma redacção  
sobre o tema: &quot;Uma tagarela.&quot; Uma tagarela! O que se poderia escrever sobre isto? Mas não me afligi. Meti o  
caderno de exercícios na pasta e esforcei-me por estar calada. à noite, depois de acabados todos os outros deveres,  
lembrei-me da redacção. Roí um bocadinho a pena e pensei no assunto: escrever umas tretas e com as palavras tanto  
quanto possível distanciadas, toda a gente sabe. Mas encontrar uma razão evidente da necessidade de palrar, aí é que  
estava o grande problema. Pensei e tornei a pensar. De repente as palavras surgiram. Enchi as três folhas obrigatórias,  
rapidamente, sem cessar. Aquilo saiu-me bem. Como argumento aleguei que palrar era próprio das mulheres e que eu de  
bom grado faria esforços para me emendar se a minha mãe não falasse tanto como eu. E, como era sabido, contra defeitos  
hereditários pouca coisa se podia fazer.</p>
<p>O sr. Kepler riu-se da minha explicação. Quando na próxima aula palrei de novo, foi-me  
marcada outra redacção: a &quot;tagarela incurável&quot;. Lá a escrevi como pude e durante duas aulas portei-me  
lindamente. Mas na terceira aula já não sucedeu o mesmo, e o sr. Kepler achou que o meu mau comportamento passava  
das marcas:</p>
<p>- Anne, como castigo por causa da tua tagarelice, vais fazer uma redacção: cá, cá, cá, cá, a  
menina que cacareja.</p>
<p>A turma riu a bandeiras despregadas. Também ri, embora me parecesse que tinha esgotado  
o meu espírito inventivo para redacções sobre o palrar. Tinha de encontrar alguma coisa de novo, de original. A minha  
amiga Sanne, poetisa consumada, aconselhou-me a tratar o assunto em verso e pôs o seu talento à minha disposição.  
Fiquei entusiasmada.</p>
<p>O Kepler queria fazer pouco de mim, mas eu podia pregar-lhe uma partida ainda pior.</p>
<p>Fizemos um poema que foi um sucesso. Tratava de uma mamã de patos e de um &quot;pai  
cisne&quot;. com três patinhos que, por causa de tanto cacarejar, foram mordidos pelo pai até morrerem. Felizmente o  
Kepler compreendeu a brincadeira e leu o poema em voz alta na nossa e nas outras turmas. Desde então posso palrar sem  
que o Kepler me mande fazer redacções de castigo, mas passou a dizer-me a cada passo uma piadinha.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 24 de Junho de 1942</h2>
<p>Querida Kitty:</p>
<p>Está a escaldar. Todos bufam e transpiram, e por um calor destes tenho de andar a pé. só  
agora compreendo como é bom o carro eléctrico, sobretudo as carruagens abertas. Mas é um prazer que já não existe para  
nós, os judeus. Temos de nos contentar com &quot;as irmãs perninhas&quot;.</p>
<p>Ontem,,à hora do almoço, tive de ir ao dentista na Jan Luykenstraat. É uma caminhada  
longa desde a nossa escola, que fica junto do jardim público. Na aula da tarde, de cansada, por pouco, ia adormecendo. O  
que vale é que ainda há pessoas amáveis que nos oferecem de beber mesmo sem pedirmos nada. A &quot;irmã&quot; no  
dentista compreende a nossa situação.</p>
<p>Só um meio de transporte nos é ainda permitido:</p>
<p>-a barca. No molhe de Joseph-Israel há um barquinho, que a nosso pedido nos leva à outra  
margem. Em boa verdade, não é por culpa dos holandeses que a vida é dura para os judeus.</p>
<p>Ai, se não precisasse de ir para a escola! Durante as férias da Páscoa roubaram-me a  
bicicleta, o pai pôs a da mãe em segurança, em casa de gente conhecida!</p>
<p>Felizmente as férias estão à vista, mais uma semana e estou livre disto!</p>
<p>Ontem, da parte da manhã, aconteceu-me uma coisa engraçada. Quando passei por aquele  
sítio onde costumava guardar a minha bicicleta, ouvi chamar. Virei-me. Atrás de mim vinha um rapaz simpático que, na noite  
anterior, tinha encontrado na casa da Eva, uma conhecida minha.</p>
<p>Um pouco tímido, disse-me o seu nome: Harry Goldberg.</p>
<p>Fiquei admirada, não sabia bem o que ele queria de mim.</p>
<p>Mas, num instante, fiquei a saber. Queria acompanhar-me à escola.</p>
<p>Se tens o mesmo caminho, então está bem, disse eu e caminhámos lado a lado. O Harry já  
tem dezasseis anos e sabe falar com graça sobre muitas coisas. Hoje, de manhã, estava, de novo, à minha espera e, para  
já, penso que assim há-de continuar algum tempo.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 30 de Junho de 1942</h2>
<p>Querida Kitty:</p>
<p>Até hoje ainda não tive tempo para escrever. Quinta-feira estive toda a tarde em casa de  
gente amiga. Sexta tivemos visitas e assim por diante, até hoje. Harry e eu conhecemo-nos melhor nesta semana.  
Contou-me muita coisa dele. Veio cá para a Holanda com os avós. Os pais estão na Bélgica.</p>
<p>Harry tem andado, até agora, com uma outra rapariga, a Fanny. Ela é um modelo exemplar  
de meiguice e de enfado. Desde que o Harry me conhece a mim, descobriu que quase adormece ao lado de Fanny. Sou  
para ele uma espécie de estimulante. Nunca a gente sabe para o que é capaz de servir.</p>
<p>Sábado, a Jopie dormiu cá em casa. A tarde de domingo passou-a com a Lies e eu  
aborreci-me de morte. à noite devia vir o Harry, mas às seis telefonou-me:</p>
<p>-Aqui, Harry Goldberg. Por favor posso falar com a Anne?</p>
<p>-Sou eu mesma.</p>
<p>-Boa noite Anne. Como estás?</p>
<p>-Bem, obrigada.</p>
<p>-Infelizmente não posso ir aí à noite. Mas queria muito falar contigo. Podes descer, daqui a  
dez minutos?</p>
<p>-Está bem. Até já.</p>
<p>Mudei num instante de roupa e dei um jeito ao cabelo.</p>
<p>Depois pus-me à janela, toda nervosa. Finalmente, veio.</p>
<p>É espantoso, mas não me precipitei logo escada abaixo.</p>
<p>Esperei calmamente que ele tocasse à campainha. Depois desci. Saímos e ele foi direito ao  
assunto.</p>
<p>- Ouve, Anne, minha avó acha que tu és nova de mais para mim. Acha que eu devia  
virar-me de novo para a Fanny Lours. Se calhar soube que eu já não quero saber da Fanny para nada.</p>
<p>-Então, zangaste-te com ela?</p>
<p>-Não, pelo contrário. Eu disse-lhe que não ligamos lá muito bem um com o outro e que, por  
isso, não vale a pena encontrarmo-nos tantas vezes. Que pode continuar a vir à nossa casa e que também eu continuarei a  
ir à dela.</p>
<p>Desconfiei que a Fanny andasse com outros rapazes, mas afinal não anda. Meu tio achou  
que devia pedir-lhe desculpa, mas não me apetece. Achei preferível acabar assim.</p>
<p>A avó insiste; quer que eu mantenha a amizade com a Fanny e que não comece a andar  
contigo, mas eu quero lá saber disso para nada. Gente velha tem por vezes ideias à antiga, que me não podem interessar.  
Não há dúvida de que dependo de minha avó, mas, em certa medida, ela também depende de mim. às quartas estou  
sempre livre.</p>
<p>Os avós julgam que vou às aulas de trabalhos manuais mas eu tenho ido quase sempre às  
reuniões dos sionistas.</p>
<p>Não somos sionistas, mas interessava-me conhecer aquilo.</p>
<p>Ultimamente não me sentia à vontade naquelas reuniões e resolvi não tornar a ir. Assim  
podemos encontrar-nos nas quartas e sábados, à tarde e à noite, e no domingo, à tarde, e talvez mais vezes ainda.</p>
<p>-Mas os teus avós não estão de acordo. Não deves fazer isso às escondidas.</p>
<p>-No amor ninguém manda.</p>
<p>Passámos pela livraria e dobrámos a esquina. E lá estava o Peter Wessel com mais dois  
rapazes. Era a primeira vez que o tornava a ver e fiquei cheia de alegria.</p>
<p>Harry e eu andámos e tornámos a andar em volta do bairro e, por fim, combinámos que ele  
me esperasse na tardinha seguinte às sete menos cinco, em frente da sua casa.</p>
<p>Tua Anne</p>`],
4: [`<h2>Sexta-feira, 3 de Julho de 1942</h2><p>Querida Kitty:</p>
<p>Ontem esteve cá o Harry. Quis conhecer os meus pais.</p>
<p>Eu tinha ido buscar torta, doces e bolachas e tomámos chá. Ao Harry e a mim não nos  
apetecia nada ficar em casa quietinhos. Saímos, demos um passeio e eram oito e dez quando ele me deixou em casa.</p>
<p>O pai estava zangadíssimo por eu chegar tão tarde, que era muito perigoso, para judeus,  
andar pelas ruas depois das oito.</p>
<p>Prometi de hoje em diante estar sempre em casa, pontualmente, às oito menos dez minutos.  
Amanhã estou convidada para ir a casa do Harry. A minha amiga Jopie faz troça de mim por causa dele. Mas não estou  
apaixonada. Então não posso ter um amigo? Ninguém acha mal que tenha um amigo ou-como costuma dizer a mãe-um  
cavalheiro.</p>
<p>Eva contou-me que o Harry esteve o outro dia em casa dela e que ela lhe perguntou :</p>
<p>- Quem achas mais simpática,.a Fanny ou a Anne?</p>
<p>-Não tens nada com isso-respondeu ele.</p>
<p>Então não falaram mais no assunto, mas ao despedir-se o Harry disse:</p>
<p>-A Anne é mais simpática, claro, mas não precisas de falar nisso a ninguém.</p>
<p>As últimas palavras já foram ditas na rua.</p>
<p>Sinto que o Harry está apaixonado por mim e, para variar, isto é engraçado. A Margot dizia  
:</p>
<p>- Um tipo simpático.</p>
<p>- Acho-o também simpático, mais até do que simpático.</p>
<p>A mãe anda encantada com ele.</p>
<p>-Um rapaz bonito, muito gentil e bem educado.</p>
<p>Ainda bem que o Harry agrada tanto a toda a família.</p>
<p>Ele também nos acha a todos muito simpáticos. Só acha a minha amiga infantil e não deixa  
de ter razão.</p>
<p>Tua Anne</p>
<h2>Domingo, 5 de Julho de 1942</h2>
<p>Querida Kitty:</p>
<p>A festa do fim do período correu lindamente. As minhas notas não são nada más. A pior nota  
é um cinco em Álgebra; tenho dois seis, sete em quase tudo e dois oitos.</p>
<p>Cá em casa ficaram satisfeitos. Não ligam grande importância às notas boas ou más, dão  
mais valor ao bom comportamento e querem acima de tudo que eu tenha saúde e seja alegre. Dizem eles que havendo  
saúde e boa disposição, o resto vem por si, mas eu gostava de ser uma boa aluna a valer.</p>
<p>Só me admitiram no liceu condicionalmente por me faltar ainda o último ano da Escola  
Montessori. A coisa foi assim:</p>
<p>Quando todos os alunos judaicos tiveram de mudar-se para escolas judaicas, o reitor,  
depois de muito palavriado, admitiu-me a mim e à Lies, mas com muitas reservas.</p>
<p>E agora não quero desiludi-lo. Minha irmã Margot teve notas brilhantes, como de costume.  
Se houvesse louvores ela passaria - com distinção e louvor, a mais alta classificação, pois é muito inteligente.</p>
<p>O pai, desde que não pode ir ao escritório, passa muito tempo em casa. Deve ser uma  
sensação horrível, isto de uma pessoa se sentir, de repente, posta de parte. O sr. Koophus tomou conta da - Travis - juntamente com o sr. Kraler, da firma Kolen &amp; C.o,  
de que o pai também era sócio. Quando, há uns dias, andávamos a passear, o pai disse-me que decerto teríamos de -  
mergulhar -. Disse que nos iria custar muito viver isolados do mundo.</p>
<p>Perguntei porque é que falava assim.</p>
<p>-Bem sabes - disse ele - que há mais de um ano estamos a levar o vestuário, a mobília e os  
comestíveis para casa de outras pessoas. Não queremos deixar cair o que é nosso nas unhas dos alemães. E ainda menos  
queremos, nós próprios, cair-lhes nas mãos. Por isso não vamos esperar até que nos venham buscar.</p>
<p>O rosto muito sério do meu pai inquietou-me.</p>
<p>-Então, quando, pai?</p>
<p>-Não te preocupes, minha filha. Sabê-lo-ás a tempo.</p>
<p>Goza a tua liberdade enquanto for possível.</p>
<p>Foi tudo. Oxalá que o tal dia ainda venha longe!</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 8 de Julho de 1942</h2>
<p>Querida Kitty:</p>
<p>Entre domingo de manhã e hoje foi como se se tivessem passado muitos anos.  
Aconteceram imensas coisas. É como se a Terra estivesse toda ela transformada. Contudo, Kitty, ainda estou viva, e isto é  
o principal. Sim, estou viva, mas não queiras saber de que maneira. É possível que hoje nem me entendesses, por isso,  
antes de mais nada, vou-te contar o que se passou. Às três horas (Harry tinha saído naquele mesmo momento e queria voltar mais tarde) tocou  
a campainha.</p>
<p>Eu não tinha ouvido nada porque estava, numa preguiça agradável, estendida na cadeira  
de repouso, a ler. Nisto entrou a Margot, toda excitada.</p>
<p>- Anne, recebemos uma convocação das SS para o pai - cochichou. - A mãe já foi ter com o  
sr. van Daan.</p>
<p>Senti um medo horrível. Uma convocação para o pai...</p>
<p>Toda a gente sabe o que isto significa: campo de concentração... Vi surgir diante de mim  
celas solitárias para onde queriam levar o meu pai!</p>
<p>- Não pode ser - disse Margot categòricamente quando nos encontrámos as duas na sala  
de estar, à espera da mãe.</p>
<p>-A mãe foi a casa dos van Daans para combinar se não seria melhor - mergulhar - já  
amanhã. Os van Daans vão connosco, somos, ao todo, sete.</p>
<p>Um grande silêncio. Não fomos capazes de dizer mais uma palavra. A ideia de que o pai  
andava em visita aos seus protegidos no asilo dos velhos judeus, sem suspeitar coisa alguma, a demora da mãe, o calor, a  
tensão... tudo isso nos emudecia.</p>
<p>De repente, tocou a campainha.</p>
<p>-É o Harry - disse eu.</p>
<p>- Não abras!</p>
<p>A Margot quis deter-me, mas já não foi preciso. Ouvimos a mãe e o sr. van Daan a falar com  
o Harry. Depois de ele se ter ido embora, entraram e fecharam a porta.</p>
<p>A cada toque da campainha ou Margot ou eu tínhamos de descer sem fazer o menor ruído,  
para ver se era o pai.</p>
<p>Não devíamos deixar entrar mais ninguém. Mandaram-nos, às duas, sair do quarto. O van  
Daan queria falar a sós com a mãe. Enquanto esperávamos no nosso quarto, a Margot disse-me que a convocação não  
tinha sido para o pai mas sim para ela. Apanhei, de novo, um susto horrível e desatei a chorar desesperadamente. A  
Margot tem dezasseis anos.</p>
<p>E eles obrigam raparigas assim a partir sòzinhas. Felizmente ela não se há-de separar de  
nós. A mãe já o tinha dito e as palavras do pai, quando me falou em - mergulharmos -, deviam querer dizer a mesma  
coisa.</p>
<p>- Mergulhar -! Onde havemos nós de - mergulhar -?</p>
<p>Na cidade, no campo, num edifício qualquer, numa cabana, quando, como, onde? Estas  
perguntas não me era permitido fazê-las em voz alta mas andavam-me constantemente na cabeça.</p>
<p>Margot e eu começámos a meter nas pastas da escola o que nos parecia mais necessário.  
A primeira coisa em que peguei foi neste caderno, depois meti ao calhar: &quot;bigondis&quot;, lenços, livros escolares, um  
pente e cartas velhas. Ao lembrar-me de que íamos - mergulhar -, meti ainda na pasta coisas inconcebíveis mas não estou  
arrependida.</p>
<p>Recordações valem mais do que vestidos.</p>
<p>às cinco horas o pai chegou finalmente. Telefonou ao sr. Koophuis e pediu-lhe que viesse à  
noite a nossa casa.</p>
<p>O sr. van Daan foi buscar a Miep que veio e meteu sapatos, vestidos, casacos e roupas  
brancas numa malinha. Prometeu voltar à tardinha. Depois disso reinou o silêncio na nossa casa. Ninguém quis comer. O  
calor ainda apertava. Parecia-me tudo tão estranho!</p>
<p>&nbsp;</p>
<p>O quarto grande, no andar de cima, estava alugado a um tal sr. Goudsmit, um homem  
divorciado, de mais ou menos trinta anos. Como nesse domingo parecia não ter nada que fazer, foi ficando conosco até às  
dez horas, não conseguimos despedi-lo antes. às onze horas chegaram a Miep e o Henk san Santen. A Miep trabalha,  
desde 1933, no escritório do pai e tinha-se tornado uma nossa amiga fiel, assim como o seu marido Henk, com quem casou  
há pouco. Na mala de Miep desapareceram sapatos, meias, livros e roupas brancas e também nos bolsos fundos do Henk.  
às onze e meia saíram carregados. Eu, cheia de sono, já não me aguentava em pé e, embora soubesse que era aquela a  
última noite que passava na minha casa, adormeci num instante. Na manhã seguinte a mãe acordou-me às cinco e meia.  
Felizmente já não estava tanto calor como no domingo. Uma chuvinha, miúda, quente, caiu todo o dia. Vestimo-nos todos  
com tanta roupa como se fôssemos meter-nos num frigorífico. Assim, foi-nos possível trazer para cá uma data de roupas.  
Um judeu na nossa situação não podia correr o risco de andar na rua com uma grande mala. Eu trazia duas camisas, dois  
pares de meias, três calcinhas e um vestido leve, com saia e casaco por cima e ainda mais um casaco comprido de verão.  
Calcei os meus melhores sapatos, pus cachecol, boina e ainda mais coisas. Mesmo antes de sair de casa já me sentia  
quase sufocada, mas ninguém quis saber disso.</p>
<p>A Margot meteu mais livros de estudo na pasta, foi buscar a bicicleta e ia pedalando atrás  
da Miep, para qualquer parte, que me era desconhecida. É que eu ainda não sabia qual era o lugar misterioso onde nos  
havíamos de abrigar... às sete e meia saímos e batemos a porta.</p>
<p>Só me despdi de Mohrchen, o meu querido gatinho, que havia de encontrar um bom refúgio  
num dos vizinhos, se o sr. Goudsmit cumprisse este nosso desejo que lhe deixámos ficar escrito num papelinho.</p>
<p>Na mesa da cozinha ficou meio quilo de carne para o gato, na mesa da sala ainda estava a  
louça do pequeno almoço. As roupas das camas arejavam nas janelas. Tudo isso dava a impressão de termos deixado a  
casa precipitadamente.</p>
<p>Mas era-nos indiferente o que os outros podiam pensar. Queríamos desaparecer e chegar  
sãos e salvos ao nosso destino.</p>
<p>Amanhã continuo!</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 9 de Julho de 1942</h2>
<p>Querida Kitty:</p>
<p>Assim corremos debaixo da chuva, a mãe, o pai e eu, cada um com uma pasta e uma saca  
de compras completamente cheia, sabe Deus com quê. Os operários que iam para o trabalho olhavam-nos. Bem se lhes lia  
nos rostos que tinham pena de nós por irmos tão carregados e por não nos deixarem andar nos carros eléctricos. A nossa  
estrela amarela no braço falava por si. Pelo caminho fora, os pais contaram-me, tintim-por-tintim, como nascera o plano do  
nosso esconderijo. Havia já meses que parte da nossa mobília e do nosso vestuário tinha sido posta a salvo.</p>
<p>Se não houvesse complicações, estaríamos prontos para desaparecer no dia 16 de Julho.  
Por causa da convocação as coisas anteciparam-se uns dez dias e, por isso, os quartos que íamos ocupar ainda não  
estavam preparados como devia ser, mas tínhamos de nos conformar. O esconderijo é na casa comercial do pai. Para  
quem está de fora, tudo isto é difícil de compreender. Por isso vou explicar melhor.</p>
<p>O pai nunca teve muitos empregados. Os de agora eram o sr. Kraler, o sr. Koophuis, a Miep  
e Elli Vossen, a dactilógrafa de vinte e três anos. Todos sabiam que vínhamos.</p>
<p>Só o sr. Vossen, o pai da Elli, que trabalha no armazém, e os dois criados é que não estão  
no segredo.</p>
<p>O edifício é assim : no rés-do-chão há um grande armazém que também serve para a  
expedição. Ao lado da entrada para o armazém há a verdadeira porta de entrada.</p>
<p>Passada a porta, sobe-se por uma escada de poucos degraus, até uma outra porta onde,  
sobre vidros foscos, existiu em tempos, em letras pretas, a palavra &quot;escritório&quot;. Trata-se do escritório grande,  
muito grande mesmo, muito claro e atravancado de móveis. Nele trabalham, durante o dia a Miep, a Elli e o sr. Koophuis.  
Através de um quarto de passagem que serve de vestiário, onde há um grande armário e um cofre à prova de fogo entra-se  
num grande quarto que dá para as traseiras, onde antes o sr. Kraler trabalhava com o sr. van Daan. Agora só lá ficou o sr.  
Kraler.</p>
<p>Pode também passar-se do corredor directamente para este quarto, atravessando uma  
porta de vidro que se pode abrir por dentro com facilidade, mas que dificilmente se abre do lado de fora. Do escritório do sr.  
Kraler, passa-se, através do corredor e subindo quatro degraus, à mais bonita sala da casa, o escritório particular. Móveis  
de luxo, escuros, chão revestido de oleado e com tapetes; um rádio, candeeiros catitas, vistosos, tudo estupendo.</p>
<p>Ao lado há uma cozinha grande, airosa, com um cilindro de água quente e dois fogareiros a  
gás. E, ao lado da cozinha, o W. C. Isto é o primeiro andar.</p>
<p>Do corredor comprido, uma escada de madeira conduz a um vestíbulo que acaba noutro  
corredor. Há uma porta à direita e outra à esquerda. A da esquerda conduz à parte da frente da casa onde se encontram os  
armazéns, as águas-furtadas e o sótão. No edifício há ainda uma outra escada comprida, íngreme de mais, perigosa,  
tipicamente holandesa.</p>
<p>A porta da direita conduz a um anexo. Ninguém podia nem sequer suspeitar que, para além  
desta porta simples, pintada de cinzento, ainda se encontrariam escondidos muitos quartos. Aberta a porta, sobe-se um  
degrau, e está-se dentro do anexo. Em frente da entrada há uma escada íngreme. à esquerda, um corredorzito leva a um  
quarto que vai ser o quarto de dormir e de estar do casal Frank e a um outro quartinho : o quarto de trabalho e de dormir  
das duas meninas Frank. Ao lado direito da escada há um quarto sem janelas com lavatório e um W. C. com uma outra  
porta que dá para o nosso quarto., Quando se sobe a escada e se abre a porta de cima fica-se admirado ao ver numa casa  
tão velha, um quarto tão grande, bonito e airoso. Neste quarto há um fogão de gás e uma banca. Aqui estava instalado, até  
há pouco, o laboratório da firma. Agora serve de cozinha, de sala e de quarto de dormir do casal van Daan.</p>
<p>Um quartinho minúsculo de passagem o ladeia também de Peter van Daan. Como na casa,  
aqui há águas-furtadas e um sótão. Vês, agora fiz-te a apresentação de todo o nosso anexo.</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>Estivemos ocupados durante todo o dia. Até quarta feira nem tempo tive para pensar nesta  
grande reviravolta que se deu na minha vida. Só então, pela primeira vez desde que aqui chegámos, consegui arranjar  
tempo para ficar em mim, para te descrever o que tinha acontecido e para falar no que ainda poderá vir a acontecer.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 10 de Julho de 1942</h2>
<p>Querida Kitty:</p>
<p>Se calhar aborreci-te mesmo, com a descrição extensa da casa. Mas acho que deves saber  
onde nos aninhamos.</p>
<p>E agora deixa-me continuar, pois ainda não acabei. Quando chegámos a Prinsengracht, a  
Miep fez-nos subir depressa para o anexo e fechou a porta atrás de nós. Cá estávamos.</p>
<p>Margot tinha chegado muito mais depressa de bicicleta e já estava à nossa espera. O nosso  
quarto de estar e os outros também pareciam arrumos atravancados. A desordem era indescritível! Os caixotes e as malas  
que, no decorrer dos últimos meses, se tinham mandado para aqui, alastravam numa grande confusão. O quartinho,  
apinhado até ao tecto com camas e roupas brancas. Se queríamos dormir à noite em camas bem feitas, tínhamos de deitar  
já mãos à obra. A mãe e a Margot não foram capazes de mexer numa palha. Atiraram-se para cima dos colchões;  
sentiam-se muito infelizes. O pai e eu, os dois &quot;arrumadores&quot; da família, desatámos a trabalhar. Despejámos as  
malas e os caixotes, colocámos tudo nos sítios próprios, martelámos, esfregámos, e quando a noite chegou caímos, mais  
mortos que vivos, nas camas limpinhas. Não tomámos uma só refeição quente durante todo o dia. Também não era preciso.  
A mãe e a Margot estavam nervosas de mais para comer e o pai e eu não tivemos tempo.</p>
<p>Na terça-feira de manhã continuámos. A Elli e a Miep fizeram as compras com os nossos  
talões de racionamento, o pai melhorou a ocultação das luzes que tinha ficado imperfeita e esfregámos os azulejos da  
cozinha. Estivemos todos bem.</p>
<p>Tua Anne</p>
<h2>Sábado, 11 de Julho de 1942</h2>
<p>Querida Kitty :</p>
<p>O pai, a mãe e a Margot ainda não conseguiram habituar-se ao sino da - Torre-Oeste -, que  
toca de quarto em quarto de hora. Eu já me habituei, até acho bonito. Principalmente de noite tem algo de calmante para  
mim.</p>
<p>Decerto gostavas de saber se este refúgio me agrada.</p>
<p>Para ser franca, ainda não sei. Creio que nunca me sentirei aqui como em nossa casa. Mas  
com isto não quero dizer que o acho lúgubre ou triste. Por vezes quer-me parecer que estou numa pensão estranha. Uma  
concepção singular do &quot;mergulhar&quot; não achas? Esta casa é realmente um esconderijo ideal. Apesar de ser um  
bocado húmida, torta e sinuosa, será difícil encontrar coisa mais confortável em Amesterdão ou mesmo em toda a  
Holanda.</p>
<p>O nosso quarto até agora estava nu completamente.</p>
<p>O pai trouxe toda a minha colecção de postais de estrelas de cinema e de vistas, e eu  
transformei-os, com cola e pincel, em lindos quadros para as paredes. Agora o quarto tem um aspecto alegre. Logo que  
cheguem os van Daans havemos de construir armarinhos para as paredes e outras coisas úteis com a madeira que está no  
sótão.</p>
<p>A Margot e a mãe vão-se habituando. Ontem, pela primeira vez, a mãe quis cozinhar. Sopa  
de ervilhas!</p>
<p>Mas enquanto tagarelava em baixo esqueceu-se da sopa por completo, e esta esturrou  
toda, as ervilhas ficaram negras como carvão e era impossível despegá-las do fundo da panela. É pena que eu não possa  
contar esta história ao meu professor Kepler... teoria da hereditariedade.</p>
<p>Ontem à noite fomos todos ao escritório particular para ouvir a emissão da B. B. C. Estava  
com muito medo de que alguém na vizinhança pudesse dar por ela e supliquei ao pai que voltasse conosco para cima. A  
mãe compreendeu-me e veio comigo. Estamos sempre com receio de que alguém nos possa ver ou ouvir. Logo no primeiro  
dia fizemos cortinas. São simplesmente retalhos de diferentes formas e cores, ajuntados e cosidos pelo pai e por mim.</p>
<p>Estas peças de luxo estão pregadas aos caixilhos das janelas com &quot;punaises&quot; e  
aí ficarão enquanto durar o nosso &quot;mergulho&quot;.</p>
<p>à direita da nossa habitação há uma grande casa comercial e à esquerda uma carpintaria.  
Nestes edifícios não fica ninguém depois das horas de trabalho, mas nunca se sabe ao certo se os nossos ruídos não  
chegam a ouvir-se.</p>
<p>Por isso proibimos a Margot, que anda terrivelmente constipada, de tossir de noite. Coitada  
da rapariga, volta e meia obrigam-na a engolir codaína. Na terça-feira chegarão os van Daans. Estou contente. Será mais  
agradável assim e menos monótono. Esta calma enerva-me, principalmente de noite; muito gostava eu que algum dos  
nossos protectores também aqui dormisse. Aflige-me a ideia de não se poder sair daqui e tenho medo de que nos  
descubram e nos fuzilem. É isto que pesa sobre mim de um modo horrível. Durante o dia não nos podemos mexer à  
vontade.</p>
<p>não podemos pisar o chão com força e temos quase de cochichar em vez de falar, pois lá  
em baixo, no armazém, não nos devem ouvir. Desculpa. Estão a chamar-me.</p>
<p>Tua Anne</p>`],
5: [`<h2>Sexta-feira, 1 de Agosto de 1942</h2><p>Querida Kitty :</p>
<p>Há um mês que não tenho feito caso de ti, mas nem todos os dias acontecem coisas novas.  
No dia 13 de Julho chegaram os van Daans. Só os esperávamos no dia 16., mas como justamente naqueles dias toda a  
gente andava muito agitada por os alemães convocarem de cada vez mais judeus, os van Daans preferiram partir da sua  
casa antes que fosse tarde de mais. Pela manhã, às nove e meia -estávamos ainda a tomar o pequeno almoço - entrou o  
Peter van Daan, um rapazote de dezasseis anos, enfadonho, bastante tímido, que não promete vir a ser um companheiro  
interessante. Meia hora mais tarde apareceu o casal van Daan. Rimo-nos muito por a sra. van Daan trazer na chapeleira  
um vaso de noite. &quot;Sem vaso de noite não posso viver&quot;, disse ela, e pôs a peça valiosa no seu lugar debaixo da  
cama. Ele, o sr. van Daan, não trazia váso, mas apareceu com uma mesinha de chá de dobrar, debaixo do braço. No  
primeiro dia estivemos sentados todos juntos, num ambiente simpático, e passados três dias, tínhamos a impressão de  
termos sido sempre uma grande família. Os van Daans assistiram a muita coisa em toda aquela semana que ainda  
passaram fora da toca, e era disso que nos falavam. A nós interessava-nos muito, em especial o que tinha sucedido à  
nossa casa e ao sr. Goudsmit.</p>
<p>E o sr. van Daan contou :</p>
<p>-Segunda-feira, às nove horas da manhã, o sr. Gouds mit telefonou-me para ir ter com ele.  
Mostrou-me o papelinho que vocês tinham deixado ficar (para ele levar o gato ao vizinho). Ele tinha um medo terrível de  
que a polícia revistasse a casa e, por isso, limpámos um bocado a mesa. De repente descobri no calendário em cima da  
escrivaninha da sra. Frank um apontamento com uma direcção qualquer em Maastricht. Eu sabia este  
&quot;desleixo&quot;</p>
<p>intencional, mas fingi-me admirado e assustado e pedi ao sr. Goudsmit para, com toda a  
urgência, queimar aquele malfadado papel. Ao mesmo tempo ia dizendo que não fazia a menor ideia da vossa intenção de  
desaparecer.</p>
<p>De repente foi como se se fizesse luz no meu espírito.</p>
<p>- Sr. Goudsmit -, disse, - agora estou a perceber o que quer dizer essa direcção. Há mais ou  
menos meio ano apareceu-nos no escritório um oficial alemão de alta patente, um amigo de infância do sr. Frank. Ora, esse  
oficial prometeu ao sr. van Daan ajudá-lo se ele, um dia, estivesse em perigo aqui. E esse oficial estava precisamente  
estacionado em Maastricht! Suponho que cumpriu a promessa e que levará os Franks à Bélgica e de lá para junto dos  
parentes deles na Suiça. Pode contar isso aos amigos que perguntem pelos Franks, mas não mencione Maastricht, por  
favor.</p>
<p>Depois fui-me embora. A história correu e até já me foi contada a mim próprio por várias  
vezes, segundo esta mesma versão.</p>
<p>Achámos a coisa deliciosa e rimo-nos ainda bastante da força de imaginação dalgumas  
pessoas! O sr. van Daan contou que uma família pensava ter-nos visto quando partimos de bicicleta de manhã cedo, todos  
juntos. Uma outra senhora sabia categòricamente que um automóvel militar nos foi buscar em plena noite.</p>
<p>Tua Anne</p>
<h2>Sexta feira, 21 de Agosto de 1942</h2>
<p>Querida Kitty:</p>
<p>O nosso &quot;esconderijo&quot; é agora perfeito. O sr. Kraler teve a boa ideia de tapar a  
porta de entrada do anexo.</p>
<p>A polícia anda a fazer muitas buscas às casas por causa das bicicletas escondidas. O sr.  
Vossen executou um plano: construir uma estante giratória que abre para o lado como uma porta. É claro que, para isso,  
o sr. Vossen teve de &quot;entrar no segredo&quot; e está a ser muito prestável. Agora, antes de descermos, temos de nos  
curvar e depois damos um saltinho porque o degrau desapareceu.</p>
<p>Ao cabo de três dias tínhamos todos a testa cheia de galos, porque como não tomávamos  
cautela e não estávamos habituados, batíamos quase sempre contra a portinha.</p>
<p>Agora pregámos-lhe uma almofadinha de serrim.</p>
<p>Vamos a ver se serve para alguma coisa.</p>
<p>Não leio muito. Tem-me esquecido quase tudo o que aprendi na escola. A nossa vida aqui é  
pouco variada.</p>
<p>O sr. van Daan e eu pegamo-nos a cada passo. Ele, já se vê, acha a Margot muito mais  
engraçada do que eu. A mãe trata-me como se eu fosse um bebé, coisa que não suporto.</p>
<p>O Peter também não tem piada. É aborrecido e mandrião.</p>
<p>Passa a maior parte do dia estendido na cama, por vezes levanta-se, carpinteira um bocado  
e volta de novo a dormitar.</p>
<p>Um autêntico palerma!</p>
<p>Está calor e nós preguiçamos na cadeira de lona, lá em cima, no sótão grande.</p>
<p>Tua Anne</p>`],
6: [`<h2>Quarta-feira, 2 de Setembro de 1942</h2><p>Querida Kitty:</p>
<p>O sr. van Daan zangou-se com a mulher. Nunca vi tal coisa na minha vida. O meu pai e a  
minha mãe não eram capazes de gritar assim um com o outro. O motivo foi tão insignificante que nem vale a pena falar  
nele.</p>
<p>Mas enfim, cada um é como é. Para o Peter não deve ser nada agradável assistir a zangas  
dessas. Mas ele, de resto, ninguém o toma a sério por ser tão preguiçoso e tão mimalho. Ontem estava todo aflito porque  
tinha a língua azul. Mas pouco depois já lhe tinha passado, e hoje anda com um cachecol grosso à volta do pescoço, diz  
que tem lumbago e dores nos pulmões, no coração e nos rins. Calcula, mais nada! Este jovem está-me a sair um belíssimo  
hipocondríaco! (É assim que se diz, não é?) A minha mãe e a sra. van Daan não se dão lá muito bem, e realmente há  
razões bastantes para isso. Só um exemplo: a sra. van Daan só deixou ficar três lençóis no armário das roupas brancas,  
usado em comum por eles e por nós. Tinha ela a intenção simpática de poupar os lençóis dela e de usar os nossos. Há-de  
ficar muito espantada, quando descobrir que a mãe lhe seguiu o bom exemplo... Madame também se enfurece toda quando  
pomos a uso a louça dela e não a nossa. Anda constantemente a ver se descobre o que foi feito da nossa porcelana e nem  
suspeita que esta se encontra tão perto dela, no sótão, atrás de vários materiais de reclame, onde está bem guardadinha e  
onde ficará &quot;mergulhada&quot; tanto tempo como nós. A pouca sorte persegue-nos. Ontem deixei cair um prato de  
sopa.</p>
<p>-Oh! - gritou ela, furiosa - toma cautela. É tudo que me resta!-Mas o sr. van Daan é agora a  
amabilidade em pessoa para comigo.</p>
<p>A mãe voltou a pregar-me um grande sermão, hoje pela manhã. Acho isto horrível. As  
nossas opiniões são demasiado diferentes. O pai tem mais compreensão, mesmo se às vezes fica zangado durante cinco  
minutos.</p>
<p>Na semana passada houve um incidente. O motivo foi um livro sobre mulheres e... o Peter.  
Ainda não te disse que a Margot e o Peter têm licença para ler quase todos os livros que o sr. Koophuis nos traz da  
biblioteca. Mas esse tal livro os &quot;grandes&quot; não lhos queriam dar.</p>
<p>Claro está, a curiosidade do Peter ficou espicaçada.</p>
<p>O que estaria escrito num livro proibido? Tirou-o, à sucapa, à sua mãe quando ela estava cá  
em baixo. Escondeu-se com a presa debaixo do telhado. Durante dois dias tudo correu bem. A mãe tinha dado fé, mas não  
o traiu.</p>
<p>Mas depois o pai descobriu tudo. Zangou-se, tirou-lhe o livro e pensou que o assunto  
estava resolvido. Não contava com a curiosidade do filho que não achou a intenção do pai razoável e por isso não desistiu.  
Procurou, por todos os meios, apanhar o livro outra vez. A sra. van Daan, entretanto, tinha falado com minha mãe sobre o  
assunto.</p>
<p>Minha mãe também achava que aquele livro não era próprio para a Margot, apesar de a  
deixar ler todos os outros livros.</p>
<p>-Entre a Margot e o Peter há uma grande diferença, sra. van Daan,-disse a mãe.-Em  
primeiro lugar, as raparigas são quase sempre mais desenvolvidas do que os rapazes e depois a Margot já leu muitos  
livros, livros sérios e notáveis, e, além disso, ela está mais avançada no que respeita ao raciocínio e à cultura. Não se  
esqueça de que ela tem o curso dos liceus quase completo.</p>
<p>Em princípio, a sra. van Daan concordava, embora não achasse necessário darem-se aos  
jovens os livros que, na realidade, eram destinados aos adultos.</p>
<p>O Peter aproveitou a ocasião para se apoderar do livro.</p>
<p>Quando, à noite, toda a família se reuniu no escritório particular, para ouvir rádio, levou ele  
o seu tesouro para o sótão. às oito e meia devia voltar para baixo, mas o livro era tão palpitante que não reparou nas  
horas. Vinha precisamente a descer a escada do sótão com muita cautela quando o seu pai entrou no quarto.</p>
<p>Podes imaginar o que se seguiu... Ouviu-se o estalar de uma bofetada retumbante. Um  
empurrão, o livro voou por cima da mesa e o Peter para o canto do quarto. O casal van Daan apareceu à mesa sem Peter,  
que foi obrigado a ficar em cima. Ninguém fez caso. Diziam que, de castigo, ia para a cama sem comer. Passámos à ordem  
do dia e comemos.</p>
<p>De repente... um assobio penetrante... Ficámos como que petrificados e pálidos. Olhámos  
uns para os outros. Os talheres cairam-nos das mãos. Depois ouvimos a voz de Peter através do cano do fogão :</p>
<p>-Se pensam que desço, estão muito enganados.</p>
<p>O sr. van Daan deu um pulo da cadeira e gritou, vermelho como um tomate:</p>
<p>-Agora basta!</p>
<p>O pai, receando zaragata, agarrou-lhe no braço e subiram assim os dois. Depois de muita  
resistência e demasiado barulho, o Peter acabou por voltar ao seu quarto, onde ficou fechado à chave. A sua boa  
mãezinha quis guardar-lhe um pão com manteiga, mas o sr. papá mostrou-se inflexível.</p>
<p>-Se ele se não resolve a pedir desculpa imediatamente, irá dormir para o sótão!</p>
<p>Protestámos e dissemos que já era castigo suficiente ter o rapaz ficado sem jantar. E se o  
Peter se constipasse não havia possibilidade de ir buscar um médico.</p>
<p>O Peter não pediu desculpa e ficou no sótão. O sr. van Daan não lhe ligou importância, mas  
na manhã seguinte pôde verificar que o Peter, afinal, tinha dormido na sua cama. às sete horas, porém, o rapaz subiu, de  
novo, para o sótão e foi preciso o meu pai intervir com algumas palavrinhas conciliadoras para que ele descesse.</p>
<p>Durante três dias tivemos caras carrancudas e um silêncio teimoso. Depois tudo regressou  
à velha ordem.</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 21 de Setembro de 1942</h2>
<p>Querida Kitty :</p>
<p>Hoje vou contar-te coisas miudinhas da nossa vida diária. A sra. van Daan é insuportável. A  
cada passo me censura por eu falar tanto. Não perde uma ocasião para nos irritar. Agora meteu-se-lhe em cabeça que não  
havia de lavar a louça! E se uma ou outra vez se digna fazê-lo, quando um resto de comida ficou na panela não o guarda  
num pratinho de vidro como nós fazemos, deixa-o ficar.</p>
<p>Resultado: estraga-se e, além disso, a Margot que tem de lavar a louça na vez seguinte,  
tem o dobro do trabalho.</p>
<p>E ainda por cima tem de ouvir da senhora :</p>
<p>- Coitadinha da Margot, tem tanto trabalho!</p>
<p>O pai e eu arranjámos agora um entretenimento engraçado.</p>
<p>Estamos a elaborar uma árvore genealógica da família dele. Conta-me coisas de todos os  
parentes. Então sinto-me muito ligada à família.</p>
<p>De quinze em quinze dias, o sr. Koophuis traz da biblioteca alguns livros para raparigas.  
Gostei imenso da série - Joop-ter-Heul - e acho bonito tudo o que escreve Gissy von Marxveldt. Já li quatro vezes as  
Alegrias de Verão e rio-me sempre com a mesma vontade das situações cômicas.</p>
<p>Também voltámos aos estudos : dedico-me muito ao francês e, só de verbos, meto todos os  
dias cinco dos irregulares na cabeça. Peter faz os exercícios de inglês a suspirar. Recebemos livros escolares novos. Eu  
tinha trazido de casa um sortido de lápis, cadernos, etiquetas, borrachas de safar, etc.</p>
<p>Ouço muitas vezes a emissora de Orange. Ainda há pouco acabou de falar o príncipe  
Fernando. Contou que estão à espera de outro bebé... Aqui todos se admiram da minha afeição aos reis holandeses. Há  
dias falou-se dos meus estudos e que eu ainda tinha muito que aprender.</p>
<p>Por consequência atirei-me mais ao trabalho. Não quero voltar, mais tarde, ao primeiro ano.  
Também veio à baila que eu não tinha lido nada ultimamente. A mãe está a ler - Heeren, Vrouwen, Knechten -. Mas este  
livro não mo querem deixar ler. Para o poder ler tenho de ficar, antes de mais nada, tão esperta e culta como a minha  
inteligente e talentosa irmã. Falou-se também sobre filosofia, psicologia e fisiologia (estas palavras tão complicadas  
fizeram-me ir ao dicionário), coisas de que nada sei.</p>
<p>Oxalá no próximo ano já seja menos ignorante.</p>
<p>Verifiquei uma coisa desastrosa, é que para o Inverno só tenho um vestido de mangas  
compridas e três &quot;gilets&quot;.</p>
<p>O pai deu-me licença para fazer uma camisola de lã branca de carneiro. A lã já não está  
grande coisa, mas o principal é que seja quentinha. Muitas roupas nossas estão nas casas de outras pessoas, mas só  
depois da guerra poderemos ir buscá-las, se ainda existir alguma coisa.</p>
<p>Estava eu, outro dia, a escrever precisamente sobre a sra. van Daan quando ela entrou.  
Imediatamente fechei o caderno.</p>
<p>-Então, Anne, deixas-me espreitar?</p>
<p>-Não, sra. van Daan!</p>
<p>-Só a última págína, está bem?</p>
<p>-Não, também não!</p>
<p>Ai! Que susto que passei. Era mesmo naquela página que se lhe faziam referências pouco  
lisonjeiras.</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 25 de Setembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Ontem - visitei - os van Daan, lá em cima, para tagarelar um bocadinho. De vez em quando  
tem graça. Comemos &quot;bolachas de naftalina&quot; (a lata das bolachas está no guarda-roupa, onde há bolinhas  
contra a traça) e tomámos limonada.</p>
<p>Falámos do Peter. Eu disse-lhes que ele, por vezes, se queria chegar de mais a mim e que  
isto não me agradava nada e que eu detestava tais demonstrações. Com modos paternais perguntaram-me se eu não  
queria, apesar de tudo, ser muito amiga do Peter, pois ele gostava de mim.</p>
<p>Pensei de mim para mim : ah!, meu Deus. Mas disse em voz alta:</p>
<p>-Oh, não!, de maneira nenhuma!</p>
<p>Peter é esquivo como todos os rapazes que não conviveram bastante com raparigas.</p>
<p>A &quot;comissão do mergulho&quot;, formada pelos nossos protectores, é de facto  
engenhosa. Ouve o que os senhores inventaram! Querem fazer chegar notícias nossas ao sr. van Dijk, um amigo nosso e  
representante principal da firma &quot;Travis&quot;. Aliás, ele tem também muitas coisas nossas guardadas em sua casa.  
Assim escreveram uma carta a um farmacêutico na Zelândia Meridional com o pedido de uma informação. Juntaram um  
envelope que este cliente utilizará para a resposta. Ora, o endereço da nossa casa comercial foi escrito à mão por meu pai.  
Quando a carta voltar, eles tirar-lhe-ão a resposta do farmacêutico, meterão uma carta escrita pelo pai e, assim, o sr. van  
Dijk terá um sinal de vida nosso. Escolheram a Zelândia, na fronteira belga, sítio onde se torna mais fácil fazer passar  
cartas assim.</p>
<p>Tua Anne.</p>
<h2>Domingo, 27 de Setembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Outra zanga com a mãe. Não sei já quantas foram ùltimamente! A maior parte das vezes  
não nos entendemos.</p>
<p>Também com a Margot já não tenho a mesma intimidade.</p>
<p>Não que na nossa família se façam &quot;cenas&quot; como lá em cima, mas, mesmo  
assim, não acho graça nenhuma a isto. Tenho uma maneira de ser diferente da de minha mãe e de Margot. Sempre  
compreendi melhor as minhas amigas do que compreendo a minha própria mãe. É lamentável.</p>
<p>A sra. van Daan está outra vez de mau humor. fecha à chave a maior parte das suas coisas  
destinadas ao uso da casa. Eu gostava tanto que a mãe lhe pagasse na mesma moeda!</p>
<p>Há pais a quem parece dar prazer especial não só educar os seus próprios filhos mas,  
também, os filhos dos outros. A esta categoria pertencem os van Daan. a Margot já não precisa de ser educada, é o amor,  
a bondade e a Inteligência em pessoa. Mas o que ela tem a mais tenho eu a menos! A cada passo, durante as refeições,  
chovem recomendações sobre a minha pessoa e eu, de vez em quando, não posso deixar de dar uma das minhas  
respostas atrevidas, malcriadas até por vezes. O pai e a mãe tomam sempre o meu partido e sem eles eu não me  
aguentava na luta. Muitas vezes, os dois repreendem-me, ou por eu falar de mais, ou por meter o nariz em tudo, ou por não  
ser bastante modesta, mas não há meio de me corrigir destes defeitos. Se o pai não fosse sempre tão paciente eu já não  
tinha esperanças de ser capaz de me emendar. E, vistas bem as coisas, os meus pais não exigem muito de mim.</p>
<p>Quando acontece eu servir-me de pouca hortaliça, porque gosto pouco, mas de muitas  
batatas, os van Daans ficam todos enfurecidos com tais &quot;mimalhices&quot;.</p>
<p>-Mais um bocado de hortaliça-diz a senhora imediatamente.</p>
<p>-Obrigada, só queria batatas-respondo eu.</p>
<p>-Hortaliça faz bem à saúde, a tua mãe também assim pensa. Vá, mais um bocadinho.</p>
<p>Insiste até que meu pai intervém e põe termo àquilo.</p>
<p>-Havias de ter visto como as coisas se passavam antigamente em minha casa.-diz  
irritada-Coisas destas não se admitiam. Isto não é educação! Estão a estragar a Anne.</p>
<p>Ai, se fosse minha filha!</p>
<p>É com estas palavras que termina sempre os seus discursos.</p>
<p>Ainda bem que não sou filha dela!</p>
<p>Ainda sobre educação. Ontem seguia-se um silêncio depois de a sra. van Daan ter acabado  
o seu sermão. Por fim meu pai disse :</p>
<p>-Acho a Anne uma rapariga bem-educada. Veja, ela já compreendeu que o melhor é não  
responder aos seus longos discursos. E no que respeita à hortaliça, só lhe digo a si: vice-versa!</p>
<p>Ela sentiu-se totalmente vencida. Com aquele &quot;vice-versa&quot; meu pai quis referir-se  
às pequenas porções que ela própria costuma comer. Para se justificar, ela disse que muita hortaliça à noite, como vai logo  
para a cama, lhe fazia mal à digestão. Mas o que eu queria era que ela me deixasse em paz! É divertido ver como a sra. van Daan cora por tudo e por nada. Eu não, e ela inveja-me por isso.</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 28 de Setembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Ontem não tinha acabado a carta mas tive de a interromper.</p>
<p>Vou contar-te mais outra zanga. Mas primeiro deixa-me dizer-te que acho horrível e  
inconcebível que os adultos se irritem e zanguem com tanta facilidade e por causa das mais insignificantes bagatelas. Até  
há pouco tempo eu julgava que só as crianças se zangavam e que isso mais tarde já não acontecia. Já se vê, por vezes  
existem motivos para grandes discussões. Mas eles ofendem-se uns aos outros constantemente, com palavras veladas e  
isto torna-se insuportável. Já me devia ter habituado porque é o mesmo quase todos os dias. Mas não posso ficar  
indiferente se as discussões (assim chamam àquilo, que é apenas &quot;barulho&quot;) giram em volta da minha pessoa.  
Dizem de mim cobras e lagartos : a minha aparência, o meu carácter, as minhas maneiras, tudo é remexido, criticado e...  
condenado. Eu não estava habituada a ouvir palavras duras e gritos. E agora querem que engula tudo isso?</p>
<p>Não, não posso! E não tenciono engolir tudo. Hei-de mostrar-lhes que a Anne não é tola.  
Ainda se hão-de admirar e calar o bico! Eles é que precisavam de ser educados, não eu. De cada vez fico mais espantada  
com tanta falta de correcção e tanta estupidez (a sra. van Daan!).</p>
<p>Mas hei-de me habituar também a isto e qualquer dia ela há-de ouvir-me. Então serei de  
facto tão mal-educada, atrevida, teimosa, estúpida e preguiçosa como me querem fazer ver os de lá de cima. Bem sei que  
tenho muitos defeitos e fraquezas, mas os de cima exageram de uma maneira escandalosa.</p>
<p>Se tu soubesses Kitty como eu fervo cá por dentro quando oiço tantos insultos! Qualquer dia  
a minha raiva acumulada explode!</p>
<p>Se calhar estou a aborrecer-te, mas não posso deixar de te contar ainda uma conversa à  
mesa, que foi muito interessante e divertida. Estava-se a falar da grande modéstia do Pim (Pim é a alcunha do pai). É tão  
evidente nele a modéstia que até as pessoas mais broncas a notam. De repente a sra. van Daan, que relaciona tudo, mas  
mesmo tudo, consigo própria, disse :</p>
<p>-Eu também sou muito modesta, muito mais modesta do que o meu marido.</p>
<p>O sr. van Daan quis atenuar esta frase e disse com calma :</p>
<p>-Não quero ser muito modesto, porque creio que as pessoas vaidosas vão muito mais longe  
na vida.</p>
<p>E depois dirigiu-se a mim:</p>
<p>-Não sejas demasiado modesta, Anne, não te servirá de nada.</p>
<p>A mãe concordou, mas a Sra. van Daan teve que meter de novo o bedelho e agora, em vez  
de falar para mim, dirigiu-se aos meus pais :</p>
<p>-Vocês têm uma maneira estranha de dizer as coisas à Anne. No meu tempo de rapariga  
isso era impossível.</p>
<p>Mas mesmo hoje não é assim que se educam os filhos, excepto em famílias modernas como  
a vossa.</p>
<p>Com isso ela quis atacar o método de educação de minha mãe, tantas vezes discutido.  
Estava vermelha como fogo. Quando uma pessoa ferve daquela maneira quase que já perdeu o jogo de antemão. A mãe,  
que estava muito calma, quis pôr termo à discussão e disse :</p>
<p>-Sra. van Daan, acho também melhor não se ser muito modesto. Meu marido, a Margot e o  
Peter são de facto modestos de mais, seu marido, a senhora, Anne e eu não somos precisamente vaidosos, mas não  
deixamos fazer o ninho atrás da orelha.</p>
<p>-Mas eu sou modesta, sra. Frank! Como se atreve a dizer o contrário?</p>
<p>A mãe :</p>
<p>-Não é precisamente vaidosa, sra. van Daan, mas acho que modesta também não é.</p>
<p>A sra. van Daan:</p>
<p>- Então, já agora, gostava de saber quando é que não sou modesta. Se não cuidasse um  
bocado de mim, morreria provàvelmente de fome. Sou tão modesta como seu marido.</p>
<p>Este auto-elogio fez com que minha mãe desse uma gargalhada, o que irritou a  
&quot;pobrezinha&quot; de tal forma que continuou a falar e a falar sem conseguir acabar.</p>
<p>Por fim atrapalhou-se de tal modo que perdeu o fio à meada e, toda ofendida, levantou-se  
para sair do quarto.</p>
<p>Por acaso o seu olhar caiu sobre mim. Mal ela tinha virado as costas, eu pus-me a abanar a  
cabeça, de um modo meio piedoso, meio irónico, quase sem querer. Ela, ao ver-me assim, já não saiu e começou a berrar,  
numa linguagem feia e vulgar como uma velha e gorda peixeira.</p>
<p>Aquilo é que era um espectáculo divertido! Se eu soubesse desenhar, tinha-a eternizado  
naquela atitude; que modelozinho tão ridículo!</p>
<p>Uma coisa te vou dizer: se quiseres conhecer bem uma pessoa, tens de te zangar uma vez  
com ela. Só então é que podes julgá-la.</p>
<p>Tua Anne.</p>
<h2>Terça-feira, 28 de Setembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Há sempre qualquer coisa para contar nesta casa!</p>
<p>Como não temos banheira, lavamo-nos numa celha.</p>
<p>E como no escritório (quero dizer em todo o andar de baixo) há àgua quente, vamos os sete  
alternadamente para baixo. Mas somos muito diferentes uns dos outros, no que respeita ao pudor. Por isso, cada um,  
conforme a sua maneira de ser, escolheu um ou outro lugar para o acto de limpeza. Peter toma banho na cozinha, embora  
esta tenha uma porta de vidro. Antes de começar a lavar-se, avisa toda a gente e pede-nos que não passemos por aquela  
porta durante uma meia hora.</p>
<p>O sr. van Daan prefere tomar banho em cima. Acha que vale a pena carregar com a água  
quente, escada acima, para poder gozar as comodidades do seu quarto. A sra. van Daan, até hoje, ainda não tomou  
banho. Quer primeiro estudar qual o lugar mais conveniente para ela. O pai prefere o escritório particular e a mãe vai para  
detrás do resguardo do fogão, na cozinha. A Margot e eu escolhemos o escritório grande, para podermos chapinhar à  
vontade.</p>
<p>Todos os sábados, de tarde, fechamos as cortinas e assim, no lusco-fusco, lavamo-nos. A  
que fica à espera, observa, através de uma fenda das cortinas, o que se vai passando lá fora e diverte-se com o vaivém tão  
patusco das pessoas.</p>
<p>Mas de há uma semana para cá, já não me agrada aquele quarto de banho e tenho andado  
à procura de um sítio mais confortável. O Peter teve uma ideia boa: propôs que eu levasse as minhas coisas de banho para  
o grande W.C. que pertence ao escritório. Aí, eu podia estar sozinha, podia acender a luz, fechar a porta e, até, despejar a  
água sem auxílio de ninguém. Hoje inaugurei o meu novo quarto de banho. Estou satisfeita.</p>
<p>Ontem esteve o picheleiro no andar de baixo para deslocar os canos que ligam à  
canalização da nossa moradia.</p>
<p>Isto tinha que ser feito. De outro modo podia, no Inverno, que talvez venha a ser rigoroso,  
gelar a água nos canos.</p>
<p>Essa visita foi para nós tudo, menos agradável. Não só porque não se podia abrir uma  
torneira, mas também porque não nos podiamos servir do W.C. Talvez não seja lá muito elegante contar-te o que fizemos  
para remediar o mal. Mas não sou tão pudica que não possa falar em tais coisas. O pai e eu tínhamos tomado providências.  
Guardámos alguns frascos de conserva de que agora nos servimos.</p>
<p>Forçosamente não podiam ser despejados e tinham de ficar nos quartos. Mas achei isso  
menos repugnante do que estar todo o dia quieta, sem poder falar. Tu não podes imaginar quanto isto me custou a mim,  
que tanto gosto de palrar. Vulgarmente já somos obrigados a falar muito baixinho. Mas não falar mesmo nada e ficar  
sentada todo o dia sem me mexer, acho que é dez vezes pior! Tinha o rabo espalmado e nem o sentia; doeu-me durante  
três dias. Passámos então a fazer ginástica todas as noites, o que nos foi compondo.</p>
<p>Tua Anne</p>`],
7: [`<h2>Quinta-feira, 1 de Outubro de 1942</h2><p>Querida Kitty:</p>
<p>Ontem apanhei um susto terrível. às oito tocou a campainha e eu já estava a imaginar o  
pior-já sabes o que quero dizer com isto. Mas todos disseram que aquilo deviam ter sido garotos, e eu acalmei.</p>
<p>Agora os dias passam num silêncio! Na cozinha do escritório trabalha um farmacêutico, o sr.  
Lewin, que está a fazer experiências para a firma. Conhece bem a casa toda, e andamos sempre com o receio de que lhe  
venha a ideia de entrar no laboratório antigo. Estamos muito quietos. Quem, há três meses, teria adivinhado que a Anne,  
sempre tão mexida, tinha de estar tanto tempo quieta numa cadeira, sem falar?</p>
<p>No dia 26, a sra. van Daan fez anos: não houve grande festa. Demos-lhe flores, umas  
prendinhas e um jantar melhorado. Já é velha tradição o marido oferecer-lhe cravos vermelhos. Falando da sra. van Daan,  
quero confessar-te uma coisa. As suas tentativas de &quot;flirtar&quot; com meu pai aborrecem-me do fundo do coração.  
Ela passa-lhe a mão sobre a cara e o cabelo e mostra-lhe com preferência as suas &quot;lindas&quot; pernas. Faz esforços para ser espirituosa e tenta, sempre que pode, chamar a atenção do Pim sobre ela. Pim não a acha bonita nem  
simpática e as seduções dela deixam-no de todo indiferente. Não sou ciumenta, palavra, mas aquilo custa-me a suportar.  
Já lhe disse a ela na cara que minha mãe não se porta assim com o sr. van Daan.</p>
<p>O Peter, por vezes, tem piada. Temos ambos a paixão das brincadeiras de Carnaval e  
divertimo-nos bastante com isso. Outro dia apareceu ele encafuado num vestido muito apertado de sua mãe, com um  
chapelinho na cabeça.</p>
<p>Eu vesti o fato dele e pus a sua boina; os adultos quase que morriam de tanto rír e nós  
estivemos também divertidíssimos.</p>
<p>Elli comprou no armazém saias para mim e para a Margot, de má qualidade e muito caras. E  
mais alguma coisa engraçada ela nos prometeu: vai tratar de nos arranjar lições de estenografia por correspondência. No  
ano que vem seremos estenógrafas perfeitas. Que bom a gente poder aprender esta espécie de &quot;código&quot;  
secreto.</p>
<p>Tua Anne.</p>
<h2>Sábado, 3 de Outubro de 1942</h2>
<p>Querida Kitty:</p>
<p>Ontem houve aqui grande zaragata. A mãe contou todas as minhas travessuras ao pai, mas  
exagerou muito.</p>
<p>Chorou. Também chorei, e já tinha andado todo o dia cheia de dores de cabeça. Eu então  
disse ao pai que gostava mais dele do que da mãe. O Pim disse que isso havia de passar, mas eu não acredito. Tenho de  
fazer grandes esforços para ficar calma quando falo com a mãe. O pai quer que a ajude, e lhe preste serviços quando ela  
se não sente bem, mas eu não quero.</p>
<p>Estudo muito francês e estou a ler La belle Nivernaise.</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 9 de Outubro de 1942</h2>
<p>Querida Kitty!</p>
<p>Hoje só te posso dar notícias tristes e deprimentes.</p>
<p>Os nossos amigos e conhecidos judaicos são deportados em massa. A Gestapo trata-os  
sem a menor consideração.</p>
<p>Em vagões de gado leva-os para Westerbork, o campo para judeus. Westerbork deve ser  
um sítio horrível. Estão lá milhares de pessoas e nem há sequer lavatórios nem W.C. que, de longe, cheguem para todos.  
Conta-se que as pessoas dormem em barracas, homens, mulheres e crianças, todos misturados. Não podem fugir: quase  
todos se podem identificar pelas cabeças rapadas ou então pelo seu tipo judaico.</p>
<p>Se já na Holanda as coisas se passam deste modo, como há-de ser então nos sítios  
longínquos para onde levam essa gente? A emissora inglesa fala de câmaras de gás.</p>
<p>De qualquer forma talvez seja a câmara de gás a maneira mais rápida de se morrer... A  
Miep falou-nos de acontecimentos terríveis e está excitadíssima. Ainda há pouco encontrou, em frente da sua porta, uma  
velhinha manca.</p>
<p>Estava à espera do automóvel da Gestapo que recolhe as pessoas umas após outras. A  
velha tremia de medo. Os canhões da defesa atroavam os ares. Os raios dos projectores cruzavam-se no céu, a trovoada  
dos aviões ingleses ecoava entre as casas. Mas a Miep não teve coragem de arrastar a mulherzinha para dentro da sua  
casa. Os alemães castigam com dureza tais procedimentos.</p>
<p>Também a Elli está desanimada e triste. O seu noivo foi levado para trabalhar na Alemanha.  
Ela receia que o seu Dirk possa ser atingido quando há bombardeamentos.</p>
<p>Os aviões ingleses despejam milhões de quilos de bombas.</p>
<p>Piadinhas como: &quot;Descansem, não lhes cairá em cima um milhão delas&quot;, ou  
&quot;só uma bomba chega bem&quot;, acho-as grosseiras. O Dirk não foi o único que teve de partir.</p>
<p>Todos os dias saem comboios de jovens, forçados a ir.</p>
<p>Um ou outro consegue fugir pelo caminho ou &quot;mergulhar&quot;, mas são tão poucos! A  
minha cantiga triste ainda não acabou. Já ouviste falar em reféns? Pois inventaram esta coisa requintada. Parece-me o pior  
de tudo o que inventaram.</p>
<p>Gente inocente é presa. Se em qualquer parte se dá uma &quot;sabotage&quot; e os  
autores não se encontrarem, fuzilam simplesmente alguns dos reféns. Depois publicam a notícia no jornal. E lembrar-me  
que também já fui alemã!</p>
<p>Hitler tirou-nos a nacionalidade há muito. Entre aquela espécie de alemães-os hitlerianos-e  
os judeus existe uma inimmizade como não pode haver mais forte em todo o Mundo!</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 16 de Outubro de 1942</h2>
<p>Querida Kitty:</p>
<p>Tenho imenso que fazer. Traduzi um capítulo de La belle Nivernaise. Tirei todos os  
significados novos. Depois fiz um problema de matemática e ainda estudei três páginas de gramática. Não gosto nada dos  
problemas nem me apetece pegar-lhes. O pai também os acha complicados e, por vezes, resolvo-os melhor eu do que ele,  
mas, em boa verdade, nem ele nem eu sabemos muito disto e acabamos quase sempre por chamar a Margot para nos dar  
uma ajuda.</p>
<p>Na estenografia sou eu quem vai à frente dos três. Ontem acabei de ler Os Salteadores. É  
um bom livro, mas não se pode comparar a ooter-Heul. continuo a dizer que acho a Gissy v. Marxveldt uma escritora  
brilhante. Os meus filhos hão-de ler os seus livros. O pai deu-me algumas peças de teatro de Krner: O primo de  
Bremen, A governanta, O dominó verde. Um bom escritor.</p>
<p>A mãe, a Margot e eu voltámos a ser amigas, o que não deixa de ser muito agradável.  
Ontem a Margot deitou-se ao meu lado na minha cama. Quase não havia lugar para as duas, mas não fazes ideia como foi  
bom.</p>
<p>Ela perguntou-me se podia ler o meu diário. Eu disse:</p>
<p>-Algumas passagens podes.</p>
<p>Perguntei-lhe pelo diário dela. Disse que também mo dava a ler. Depois falámos sobre o  
futuro e perguntei-lhe o que ela queria ser. Mas não quis dizer, é um segredo.</p>
<p>Ouvi vagamente dizer que quer ser professora e suponho que deve ser verdade. Acho que  
sou curiosa de mais. Hoje de manhã estendi-me sobre a cama do Peter depois de o ter expulsado de lá. Ficou furioso, mas  
não fiz caso.</p>
<p>Acho que podia ser mais amável comigo, pois ainda ontem lhe dei uma maçã.</p>
<p>Ontem perguntei à Margot se me achava feia. Ela disse-me que eu tinha um ar patusco e os  
olhos muito bonitos. Uma resposta um bocado vaga, não te parece?</p>
<p>Até à próxima.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 20 de Outubro de 1942</h2>
<p>Querida Kitty:</p>
<p>As minhas mãos ainda tremem com o susto que apanhámos, embora isto já se tenha  
passado há duas horas.</p>
<p>Temos em casa os aparelhos &quot;Minimax&quot; contra incêndios.</p>
<p>Ninguém nos tinha dito que vinha gente enchê-los. E já se vê, nós não tínhamos tomado  
cuidados especiais. Nisto ouvi martelar do outro lado, no vestíbulo. Pensei que fosse o marceneiro. A Elli estava a almoçar  
connosco. Avisei-a para não descer. O pai e eu resolvemos ficar de guarda e escutar atrás da porta até o homem acabar o  
trabalho.</p>
<p>Depois de ele ter martelado um quarto de hora, pôs a ferramenta em cima do armário (pelo  
menos foi o que supusemos) e bateu à nossa porta. Ficámos ambos pálidos.</p>
<p>Teria ele dado por alguma coisa e queria agora decifrar o mistério? Com certeza, pois  
nunca mais acabava de bater, puxar, empurrar. Eu ia quase desmaiando ao lembrar-me de que aquele estranho iria  
descobrir o nosso belo esconderijo e estava precisamente a pensar que decerto ia morrer dentro de pouco, quando ouvi a  
voz do sr. Koophuis :</p>
<p>-Por amor de Deus, abram a porta. Sou eu.</p>
<p>Imediatamente abrimos. O gancho com que se fecha a porta por dentro e de que os  
iniciados se servem também do outro lado, estava preso e, por isso, não tinha sido possível avisar-nos de que vinha o  
operário. O homem já descera e como o sr. Koophuis, que vinha buscar a Elli, não conseguia abrir a porta, pôs-se a fazer  
aquele barulho todo. Que grande alívio! Na minha imaginação eu tinha visto o homem prestes a entrar no nosso anexo e a  
crescer até parecer um gigante invencível. Enfim, tivemos sorte, pois tudo se passou sem mais novidade.</p>
<p>A segunda-feira foi um dia divertido! A Miep e o Henk passaram cá a noite. A Margot e eu  
dormimos no quarto dos pais, e o jovem casal nas nossas camas. A comida estava um mimo. Mas não faltou também um  
pequeno incidente. Houve curto-circuito, causado pelo candeeiro do pai, e, de repente, ficámos às escuras. A caixa onde  
se encontram os fusíveis fica no fundo do armazém e não é brincadeira chegar lá sem luz. Mas conseguiu-se e, dentro de  
dez minutos, os estragos estavam reparados e apagámos a iluminação das velas.</p>
<p>Levantámo-nos cedo. O Henk tinha de se ir embora às oito e meia e queríamos tomar o  
pequeno almoço com ele e a Miep, sem pressas. Chovia a potes. A Miep desceu ao escritório, radiante por não precisar de  
fazer a caminhada do costume. O pai e eu fizemos as arrumações e depois comecei a meter verbos franceses na  
cabeça.</p>
<p>Em seguida pus-me a ler Eternamente cantam as florestas, um belo livro. Vou quase no  
fim.</p>
<p>Para a semana a Elli vem cá dormir!</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 26 de Outubro de 1942</h2>
<p>Querida Kitty:</p>
<p>Estou aflita! O pai está doente. Tem muita temperatura e manchas vermelhas pelo corpo,  
como acontece quando se tem o sarampo. A mãe anda a tratá-lo e tem muito cuidado para que ele transpire muito, porque  
assim talvez a temperatura desça.</p>
<p>Hoje de manhã a Miep contou-nos que a casa dos van Daans foi toda despejada pelos  
alemães. Ainda não dissemos nada à sra. van Daan. Está muito nervosa ùltimamente e não temos empenho nenhum em  
ouvir-lhe falar outra vez, durante horas, do seu lindo serviço de porcelana e das mobílias valiosas que tinha em casa.</p>
<p>Também nós tivemos de abandonar tantas coisas bonitas!</p>
<p>E nada adiantamos com lamentações.</p>
<p>Já me deixam ler, de vez em quando, livros para adultos e agora estou a ler A juventude de  
Eva de Nico van Suchtelen. Não encontro grande diferença entre este livro e a literatura para raparigas. Bem sei que neste  
livro se fala de mulheres que vendem o corpo a homens estranhos para ganhar um ror de dinheiro. Eu morreria de  
vergonha! Também se conta que a Eva começou a ter o &quot;incômodo&quot;. Gostava de começar a ter o  
&quot;incômodo&quot;</p>
<p>É que isto dá-nos importância.</p>
<p>O pai foi buscar ao armário os dramas de Goethe e de Schiller. Vai lê-los agora todas as  
noites em voz alta.</p>
<p>Começámos com Don Carlos. Para seguir o bom exemplo do pai, a mãe entregou-me o seu  
livro de rezas. Eu não quis ser indelicada e li umas páginas. Acho o livro bonito, mas aquilo não me diz nada. Porque é que  
a mãe quer que eu seja religiosa à força?</p>
<p>Amanhã acende-se o fogão pela primeira vez. calculo o fumo que vai fazer, porque há muito  
tempo que não se limpa a chaminé.</p>
<p>Tua Anne.</p>`],
8: [`<h2>Sábado, 7 de Novembro de 1942</h2><p>Querida Kitty:</p>
<p>A mãe está muito nervosa e isto é para mim como que um perigoso escolho. Porque sou  
sempre eu quem paga as favas.</p>
<p>Por exemplo, ontem, à noite : A Margot estava a ler um livro com lindas ilustrações. Foi para  
cima e deixou ficar o livro para quando voltasse. Comtinuá-lo-ia, então, a lê-lo não tinha nada de especial a fazer, peguei  
no livro e pus-me a ver as gravuras. A Margot voltou, viu o &quot;seu&quot; livro nas minhas mãos e franziu a testa.  
Queria-o outra vez. Eu estava com vontade de o ver mais um bocadinho, mas a Margot ficou zangada. Então a mãe disse  
:</p>
<p>-Era a Margot quem estava a ler áb á do quehse. Nesse momento entrou o pai. Nada  
se tinha passado, mas pensou logo que quem tinha razão era a Margot e disse para mim:</p>
<p>-Gostava de te ver, a ti, se a Margot folheasse um livro teu.</p>
<p>Cedi imediatamente e pousei o livro. Então disseram que eu fiquei ofendida. Mas eu não me  
sentia ofendida nem zangada, apenas estava triste, muito triste.</p>
<p>O pai foi injusto, não devia julgar o caso sem o conhecer.</p>
<p>Eu teria devolvido o livro à Margot, de livre vontade e muito mais depressa, se os pais não  
se tivessem metido no assunto e tomado logo partido por ela. Enfim, que a mãe se ponha do lado da Margot, é coisa  
natural. Morrem uma pela outra. Já estou tão habituada que não me importo com as descomposturas da mãe nem com o  
mau génio da Margot. Sou amiga delas porque uma é minha mãe e a outra minha irmã. Mas com o pai a coisa é  
diferente.</p>
<p>Quando ele dá preferência à Margot, quando acha bem tudo o que ela faz e lhe dá mimos,  
então roo-me toda por dentro, pois o pai é tudo para mim! É o meu ideal, e amo-o como não amo a mais ninguém neste  
mundo.</p>
<p>Bem sei que ele nem se apercebe de que trata a Margot de maneira diferente. Também não  
se pode negar que a Margot é mais inteligente, mais bonita e melhor. Mas não terei o direito de ser tomada a sério? Eles  
acham que eu sou o palhaço da família e sofro duplamente por apanhar tantos raspanetes e por ainda não conseguir  
compreender-me bem a mim própria. Os carinhos superficiais já não me satisfazem, nem sequer as tais conversas  
chamadas sérias. Espero do pai alguma coisa mais, que ele decerto me poderá dar. Não que tenha inveja da Margot.</p>
<p>Não cobiço a sua inteligência nem a sua beleza. O que eu queria era o amor do pai, não só  
como sua filha, mas como Anne, o ente humano que sou.</p>
<p>Agarro-me ao pai por ser ele o único que me faz conservar o sentimento da família. Mas ele  
não compreende que eu, por vezes, tenha necessidade de abrir-me, de falar sobre a mãe. O pai não quer falar dos defeitos  
da mãe e esquiva-se propositadamente a qualquer conversa sobre o assunto. E, no entanto, a maneira de ser da mãe  
pesa-me no coração. Por vezes não consigo dominar-me, e faço-lhe ver o seu desprezo, ironia e dureza. Pois, decerto, a  
culpa não será sempre minha, não é verdade?</p>
<p>Sou em tudo o contrário da mãe e, por isso, é inevitável que nos choquemos. Não estou a  
criticar o seu carácter, pois isso não me compete. Vejo-a apenas como minha mãe.</p>
<p>E ela não é para mim a mãe que idealizei. Parece que tenho de ser eu própria a minha mãe.  
Desprendi-me deles, sigo o meu próprio caminho. Quem sabe aonde chegarei um dia? Na minha imaginação vejo o ideal de  
mulher e de mãe, mas naquela a que tenho de dar o nome de mãe nada disso encontro.</p>
<p>Proponho-me constantemente não reparar nos seus defeitos, ver sòmente as suas  
qualidades e desenvolver em mim o que nela procuro. Mas não é fácil, e o pior é que nem o pai nem a mãe querem ver o  
que me falta e é isto que lhes tomo a mal. Será possível que haja pais capazes de contentarem inteiramente os filhos?</p>
<p>Por vezes penso que Deus quer pôr-me à prova. Tenho de me aperfeiçoar sòzinha, sem  
exemplo e sem ajuda, só assim hei-de ser um dia forte e resistente.</p>
<p>Quem, além de mim, lerá estas coisas? Quem pode ajudar-me? Necessito de ajuda e de  
consolo! Sou muitas vezes fraca e incapaz de ser aquilo que gostava de ser.</p>
<p>Sei-o e tento todos os dias, de novo, melhorar-me.</p>
<p>Nem sempre me tratam da mesma maneira. Um dia pertenço à classe dos adultos e posso  
saber tudo, e no dia seguinte a Anne não passou de um ser inexperiente que julga ter aprendido alguma coisa nos livros  
mas que, na realidade, não sabe coisa de jeito. Ora eu não sou um bebé nem uma boneca para os divertir. Tenho os meus  
ideais, o meu modo de pensar e os meus planos, embora ainda me falte a capacidade de traduzir tudo isto em  
palavras.</p>
<p>Ai! tantas, tantas dúvidas que se me levantam quando estou só, à noite, ou mesmo durante  
o dia quando estou encerrada com toda esta gente que já não posso ver à minha frente e de que estou farta até não poder  
mais. Eles nada compreendem dos meus problemas. Assim, volto sempre ao meu diário. É ele o meu princípio e o meu fim.  
A ti, Kitty, nunca te falta a paciência e prometo-te que hei-de aguentar. Hei-de vencer a minha dor e seguir o meu caminho.  
Só gostava de ter, de vez em quando, um pouco de sucesso, de ser estimulada e encorajada, por alguém que me tivesse  
amor!</p>
<p>Não me condenes! Por favor, compreende que, às vezes, não posso mais!</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 9 de Novembro de 1942</h2>
<p>Querida Kitty :</p>
<p>Ontem o pai fez anos. Teve prendas bonitas, entre outras um aparelho para fazer a barba e  
um isqueiro, não porque fume muito, mas por ser chique.</p>
<p>Foi o sr. van Daan que lhe fez a maior surpresa: deu-lhe a notícia de que os ingleses  
desembarcaram na Tunísia, em Casablanca, na Algéria e em Orão.</p>
<p>-É o princípio do fim-disseram todos.</p>
<p>Mas Churchill, o Primeiro-Ministro da Inglaterra que, decerto sabe mais disso, declarou num  
discurso:</p>
<p>- Este desembarque é uma fase importante, mas ninguém deve convencer-se que ele  
significa o princípio do fim. Eu, talvez gostasse antes de dizer que significa o fim do princípio.</p>
<p>Compreendes a diferença? Mas, mesmo assim, há motivos para sermos optimistas.  
Estalinegrado, a grande cidade russa, que os alemães já estão a cercar há três meses, ainda não se rendeu.</p>
<p>Voltaremos agora aos assuntos quotidianos : quero descrever-te como nós, cá no anexo,  
nos abastecemos de géneros. Antes de mais nada tenho de dizer-te que os &quot;de cima&quot; são uns gulosos terríveis.  
O pão é-nos fornecido por um padeiro simpático que o sr. Koophuis conhece muito bem. Não podemos receber tanto como  
antigamente em nossa casa, mas é o suficiente. Os talões de alimentação compram-se clandestinamente. Estão cada vez  
mais caros. Primeiro pagávamos por eles vinte e sete florins e agora já custam trinta e três. Imagina, um simples pedacinho  
de papel!</p>
<p>Para termos, além das conservas, alimentos em casa que não se estraguem, comprámos 35  
quilos de legumes secos que pendurámos em sacos no corredor, atrás da porta giratória. Mas com o peso as costuras  
rompem-se e, por isso, resolvemos levar todas essas reservas de Inverno para o sótão. Confiámos ao Peter a tarefa de  
carregar com os sacos. Ele já tinha levado cinco para o sítio e estava prestes a carregar com o sexto quando rebentou a  
costura inferior. Uma chuva, não, uma saraivada de feijão vermelho desabou sobre a escada. Os outros, lá em baixo  
(felizmente não havia estranhos no prédio), julgavam que a casa ia ruir. O Peter apanhou um susto, mas quando me viu a  
mim, ao pé da escada, coberta de feijões que se iam amontoando no chão até acima dos tornozelos, desatou numa grande  
gargalhada. Depressa começámos a apanhar os feijões com desembaraço, mas estes são tão pequenos e escorregadios  
que nos passavam pelos dedos e desapareciam em todos os buracos e buraquinhos. Agora, sempre que alguém sobe a  
escada, encontra um ou outro feijão que entrega lá em cima à sra. van Daan.</p>
<p>Quase me ia esquecendo do mais importante: o pai já está completamente bem!</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>P. S. Na rádio acabam de anunciar que a Algéria caiu. Marrocos, Casablanca e Orão  
também estão nas mãos dos ingleses. Agora não deve tardar a queda da Tunísia.</p>
<h2>Terça-feira, 10 de Novembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Uma novidade sensacional! Vamos meter mais um &quot;mergulhador&quot;. Já tinhamos  
dito muitas vezes que ainda havia lugar e comida para mais uma pessoa. Só o que não queríamos era dar tanto incômodo  
ao Kraler e ao Koophuis.</p>
<p>Mas como as notícias sobre as medonhas perseguições aos judeus se tornam de dia para  
dia piores, o pai resolveu sondar as possibilidades :</p>
<p>Resultado : Os dois senhores ficaram logo de acordo com a ideia. &quot;O perigo é o  
mesmo para sete ou para oito&quot;, disseram e com razão.</p>
<p>O problema a resolver em seguida era saber qual das pessoas isoladas das nossas  
relações ligava melhor com a nossa &quot;família mergulhada&quot;. Não foi difícil a escolha.</p>
<p>Depois de o pai ter rejeitado todas as propostas do sr. van Daan para se receber uma  
pessoa da sua família, optou-se por um dentista bastante conhecido,. de nome Albert Dussel, que tem a mulher no  
estrangeiro. Tem fama de pessoa agradável e tanto nós como os van Daan simpatizamos com ele. Como a Miep também o  
conhece bem, pode tratar de tudo. Se ele aceitar tem de dormir no meu quarto no lugar da Margot que dormirá na  
cama-sofá, no quarto dos pais.</p>
<p>Tua Anne.</p>
<h2>Quinta-feira, 12 de Novembro de 1942</h2>
<p>Querida Kitty:</p>
<p>O Dussel ficou muito contente quando a Miep lhe falou de um bom esconderijo. Ela  
aconselhou-o a vir o mais depressa possível, de preferência depois de amanhã.</p>
<p>Mas ele hesitou porque ainda precisava de pôr as fichas em ordem, acabar o tratamento de  
dois clientes e pôr as contas em dia. Foi o que a Miep nos contou hoje de manhã. Não achámos nada bem aquilo, pois  
qualquer demora pode ser prejudicial. Tais preparativos podem exigir, da parte do Dussel, explicações a pessoas que não  
queríamos que desconfiassem de nada. Pedimos à Miep que o aconselhasse a vir no sábado. Ele disse que não, que vinha  
na segunda-feira. É ridículo. Devia ter aproveitado logo. Se o prenderem na rua, também não pode pôr em dia a caixa ou  
acabar o tratamento dos clientes.</p>
<p>Quanto a mim, acho que o pai não devia ter cedido. De resto, nada de novo.</p>
<p>Tua Anne.</p>
<h2>Terça-feira, 17 de Novembro de 1942</h2>
<p>Querida Kitty:</p>
<p>O Dussel chegou. Tudo correu bem. A Miep tinha-lhe dito que esperasse em frente do  
correio geral. Pontualmente lá apareceu. Então o sr. Koophuis, que o conhece, foi ter com ele. Disse-lhe que o senhor com  
quem se queria encontrar vinha um bocado mais tarde e que ele, Dussel, esperasse antes junto da Miep, no escritório.  
Koophuis meteu-se num carro eléctrico, enquanto o Dussel seguia a pé. Chegou ao escritório às onze e meia. A Miep  
fez-lhe tirar o sobretudo para que ninguém visse a estrela amarela e depois pediu-lhe que esperasse no escritório particular  
do sr. Koophuis.</p>
<p>Queria ela que a mulher das limpezas se fosse primeiro embora. Mas, claro, o Dussel de  
nada sabia. Depois a Miep levou-o para o andar de cima. Disse-lhe que não podia estar mais tempo naquele escritório  
porque, daí a um bocado, os chefes tinham uma reunião. O espanto do homem foi grande quando viu a porta giratória  
abrir.</p>
<p>Ambos entraram.</p>
<p>Nós estávamos todos lá em cima, com os van Daan, para receber o nosso companheiro com  
café e conhaque.</p>
<p>Entretanto a Miep fê-lo entrar na nossa sala de estar.</p>
<p>Ele reconheceu logo a mobília, mas, mesmo assim, não suspeitou que estivéssemos tão  
próximos. Quando a Miep lhe disse ficou de boca aberta, e ela nem lhe deu tempo de a fechar: fê-lo subir imediatamente a  
escada.</p>
<p>O Dussel deixou-se cair numa cadeira, cravou os olhos em cada um de nós e não quis  
acreditar no que viu.</p>
<p>Depois começou a balbuciar:</p>
<p>- Mas... não... mas então, não estão na Bélgica?</p>
<p>O tal oficial não os veio buscar? E o automóvel? Não foram bem sucedidos na fuga?...</p>
<p>Explicámos-lhe que nós próprios tínhamos feito constar a história do oficial para despistar as  
pessoas, em especial os alemães, que podiam andar à nossa procura. O Dussel ficou varado com tanto engenho e mais  
varado ainda ficou quando se meteu a esquadrinhar todo o nosso esconderijo tão bem imaginado e tão bem montado.  
Comemos todos juntos. Depois ele deitou-se um bocado, tomou o chá connosco e pôs nos devidos lugares as suas coisas,  
que tinham trazido antes de ele chegar. Depressa se sentiu como em sua casa, sobretudo depois de lhe terem sido  
entregues os regulamentos do anexo (o plano foi feito pelo sr. van Daan).</p>
<p>Prospecto e guia do anexo Fundação criada propositadamente para a estadia provisória de  
judeus e outros que tais.</p>
<p>Aberta todo o ano Belamente localizada, calma, com arredores sem florestas no coração de  
Amesterdão. Acessível pelas linhas 19 e 17; de automóvel ou bicicleta; e a pé para aqueles a quem os alemães proibiram o  
uso de qualquer veículo.</p>
<p>Renda Gratuita.</p>
<p>Cozinha de dieta sem gorduras Água corrente No quarto de banho (sem banheira) e,  
infelizmente, também em várias paredes.</p>
<p>Espaço largo reservado a bens de toda a espécie.</p>
<p>Central de rádio, com emissões directas de Londres, New-York, Telavive e muitas outras  
estações. O aparelho está à disposição dos habitantes das seis horas da tarde em diante.</p>
<p>Horas de repouso: Das dez horas da noite às sete e trinta da manhã. Domingo até às dez  
horas.</p>
<p>Atendendo a certas circunstâncias, também se intercalam outras horas de repouso,  
conforme indicações da Direcção. Estas indicações devem ser rigorosamente seguidas, no interesse da segurança  
comum!!!</p>
<p>Até novas ordens não há.</p>
<p>Em surdina!</p>
<p>Todos os dias.</p>
<p>Uma lição de estenografia por semana. Inglês, Francês e Matemática a qualquer hora do  
dia.</p>
<p>Pequeno almoço todos os dias, com excepção de domingos e feriados, pontualmente às  
nove horas.</p>
<p>Almoço: da 1 e 15 à 1 e 45. Jantar: frio ou quente, não tem horas fixas devido às notícias da  
rádio.</p>
<p>A &quot;Celha&quot; está à disposição dos habitantes todos os domingos desde as nove  
horas. Pode tomar-se banho no W.C., na cozinha, no escritório particular ou no outro escritório, conforme o gosto de cada  
um.</p>
<p>Bebidas alcoólicas fortes Só permitidas por ordem médica.</p>
<p>Tua Anne.</p>
<h2>Quinta-feira, 19 de Novembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Não estamos desapontados. O Dussel é de facto um homem simpático. Para dizer com  
franqueza, não acho lá muito agradável que um estranho se sirva das minhas coisas no quarto, mas, para fazer uma boa  
acção, toda a gente se deve sacrificar. Nada importa se pudermos salvar alguém, diz o pai, e tem toda a razão.</p>
<p>Logo no primeiro dia o Dussel perguntou-me uma série de coisas, por exemplo, quais eram  
as horas da mulher da limpeza, e quais as do W. C. e onde me parecia a mim o melhor sítio para se tomar banho. Não te  
rias, Kitty, mas no esconderijo todas estas coisas são importantes.</p>
<p>Estão tantas vezes pessoas lá em baixo que não conhecem o segredo! É necessário saber  
bem as horas de trabalho delas para não fazermos barulho. Já expliquei tudo isto ao Dussel, mas fiquei pasmada por ele  
ser tão lento.</p>
<p>Pergunta as coisas duas vezes e mesmo assim não as fixa.</p>
<p>Talvez ainda esteja um pouco atrapalhado, a surpresa foi muito grande, e é natural que ele  
se tenha de adaptar.</p>
<p>O Dussel tem-nos contado muitas coisas do mundo exterior, de onde partimos há tanto  
tempo. Tudo que conta é triste. Inúmeros amigos e conhecidos foram levados das suas casas e um destino terrível os  
espera. Noite após noite os automóveis cinzentos e verdes dos militares atravessam as ruas a toda a velocidade. Os  
&quot;verdes (a SS alemã) e os &quot;pretos&quot; (a Polícia Nazi holandesa) procuram os judeus. Se encontram algum,  
levam-no, e a toda a família. Tocam, por exemplo, numa porta e se não encontram lá nenhum judeu, tocam na do vizinho e  
assim por diante. Por vezes, andam com listas de nomes e procuram os &quot;marcados&quot; sistematicamente. Só  
consegue escapar-lhes quem &quot;consegue fugir&quot; a tempo. Por vezes aceitam um resgate, mas são poucos os que  
conseguem escapar.</p>
<p>Fazem, hoje, o que há muitos anos foi feito com os escravos. Maltratados, torturados,  
mortos enfim. O que aconteceu com eles, nos tempos antigos, está hoje a acontecer com os judeus.</p>
<p>Não poupam ninguém, homens, mulheres, velhos, crianças.</p>
<p>E nós aqui tão bem guardados! Podíamos fechar os olhos a toda esta miséria, mas estamos  
sempre em aflição por aqueles que nos são caros e a quem não podemos dar uma ajuda.</p>
<p>Quando estou deitada na minha cama, cama tão quente e confortável, enquanto as mais  
queridas amigas sofrem lá fora, talvez expostas ao vento e à chuva, mortas até, sinto-me quase má. Tenho medo ao pensar  
em todas as pessoas às quais tanta coisa me liga e ao lembrar-me de que estão entregues aos mais cruéis carrascos que  
a história dos homens já conheceu. E tudo isto só por serem judeus!</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 20 de Novembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Estamos todos um pouco desconcertados. Até agora só recebíamos de longe em longe  
notícias sobre os judeus.</p>
<p>E daí, talvez fosse melhor assim. Quando a Miep por vezes falava do destino trágico de  
pessoas nossas conhecidas, a mãe e a sra. van Daan punham-se logo a chorar, de modo que ela achou melhor não contar  
mais nada. Mas fizemos muitas perguntas ao Dussel e o que ele conta é medonho, é bárbaro. Não se consegue pensar em  
outra coisa. Será possível que alguma vez mais possamos sair e divertir-nos como outrora, mesmo quando tudo isto tiver  
passado?</p>
<p>Mas a verdade é que se transformarmos o nosso esconderijo numa casa de luto, se  
ficarmos sempre melancólicos, não adiantamos nada, nem para nós nem para os que lá fora sofrem. Não posso fazer coisa  
nenhuma sem pensar naquela gente que partiu. Se dou comigo a rir despreocupadamente, assusto-me e acho-me injusta  
por estar alegre. Mas hei-de chorar todo o dia? Não, não posso. E o desânimo decerto passará. Além destas misérias, há  
outra coisa desagradável, assunto pessoal e que, já se vê, nenhuma importância tem comparado às tragédias de que  
acabo de falar: quero dizer que me irrito tão só ùltimamente! Sinto um vácuo enorme dentro de mim. Antigamente não  
pensava muito nisto.</p>
<p>Os divertimentos e as amizades prendiam-me o tempo.</p>
<p>Mas agora preocupam-me problemas sérios. Reconheci, por exemplo, isto: o pai, embora  
me seja tão querido, não pode substituir todo o meu mundo de outrora.</p>
<p>Achas-me ingrata, Kitty? Por vezes tenho a impressão de não poder suportar mais: ouvir  
todas estas coisas horríveis, ter as minhas próprias dificuldades e ainda por cima ser o bode expiatório para tantas coisas  
que acontecem!</p>
<p>Tua Anne.</p>
<h2>Sábado, 28 de Novembro de 1942</h2>
<p>Querida Kitty:</p>
<p>Gastamos electricidade de mais, ultrapassamos os limites.</p>
<p>Temos de fazer economia, caso contrário cortam-nos a corrente e estaremos quinze dias  
sem luz. Das quatro e meia em diante não podemos ler mais. Matamos então o tempo com várias distracções : adivinhas,  
ginástica, falar inglês ou francês ou sobre os livros que acabamos de ler...</p>
<p>Com o tempo tudo se torna monótono. Descobri uma coisa nova: com o binóculo posso  
espreitar para os quartos iluminados dos vizinhos da frente. Durante o dia não podemos abrir as cortinas nem um  
centímetro, mas à noite já pode ser. Eu antes nunca sabia que os vizinhos são pessoas tão interessantes. Observei alguns  
enquanto comiam; numa outra família passavam um filme e o dentista, mesmo em frente, estava a tratar uma velhinha cheia  
de medo.</p>
<p>A propósito de dentista! O sr. Dussel, de quem se dizia saber lidar tão bem com crianças e  
gostar muito delas, revela-se um bota de elástico. A cada passo faz sermões sobre boas maneiras e bom comportamento.  
Como sabes, tenho a pouca sorte de partilhar o quarto com este senhor tão &quot;respeitável&quot; e, como sou tida como  
a mais mal-educada dos três jovens daqui, ele dá-me que fazer e por vezes nem sei como escapar a tantas  
descomposturas e avisos.</p>
<p>Olha, faço-me surda! Mas tudo isto ainda se suportava se o homem não fosse um  
&quot;denunciante&quot; de grande categoria e se não tivesse escolhido precisamente a mãe para as suas reclamações.  
Assim, recebo primeiro uma ensaboadela dele, depois a mãe junta outra e, se estou com sorte, a sra. van Daan também  
mete o bedelho para me censurar.</p>
<p>Ai! Kitty, não é fácil ser-se a pessoa mais mal-educada ou antes: o pára-raios de uma família  
&quot;mergulhada&quot; sempre a criticar e a educar! à noite, na cama, quando passo em revista todos os meus  
pecados e todos os defeitos que me são atribuídos, perco-me nessa abundância de queixas e, quase sempre, começo a  
chorar... ou a rir, conforme a disposição. Depois adormeço com a ideia tola de querer ser diferente do que sou ou de que  
não sou como queria ser e de que faço tudo ao contrário. Queria agir de outra maneira e não ser como sou. Santo Deus!  
Agora estou a baralhar tudo, não te zangues! Mas não risco o que está escrito e rasgar a folha também não posso, porque  
há grande falta de papel. Seria mesmo pecado! Assim só te posso aconselhar a não voltares a ler a última frase nem  
tentares aprofundá-la, que és capaz de não conseguir voltar à superfície!</p>
<p>Tua Anne</p>`],
9: [`<h2>Segunda-feira, 7 de Dezembro de 1942</h2><p>Querida Kitty :</p>
<p>Chanuca e São Nicolau coincidem quase este ano.</p>
<p>O Chanuca festejámo-lo apenas com as velas, mas como estas são agora uma preciosidade  
só as acendemos durante dez minutos. As velas acesas e nós a cantarmos a canção de Chanuca! O sr. van Daan construiu  
um lindo candelabro.</p>
<p>O São Nicolau, no sábado, ainda foi mais lindo.</p>
<p>A Elli e a Miep vinham para cima cochichar com o pai e, assim, andávamos todos muito  
curiosos, pois compreendíamos que estavam a preparar alguma surpresa. E, de facto, às oito horas descemos a escada,  
através do corredor escuro (arrepiei-me toda; tinha medo de não voltar inteirinha), para o escritório, no outro andar.</p>
<p>É um quarto sem janelas e, assim, podíamos acender a luz. O pai abriu o armário e todos  
exclamaram: &quot;Que lindo!&quot; No centro estava um grande cesto, enfeitado com papéis coloridos, e guarnecido  
simbòlicamente com a máscara do Pedro, o negro. Transportámos o cesto para cima. Cada um recebeu as suas prendas  
acompanhadas de uma quadra.</p>
<p>Tenho a certeza de que conheces bem esse género de poemas e, por isso, não os vou aqui  
transcrever. Recebemos: eu um &quot;Pieferkuchen&quot; enorme, em forma de boneca; o pai, suportes para livros; a  
mãe, um calendário; a sra. van Daan, uma bolsa para o pano do pó; o sr. van Daan um cinzeiro... Todos os presentes  
tinham sido bem imaginados e, como festejávamos o S.</p>
<p>Nicolau pela primeira vez, achámos a nossa estreia bem sucedida.</p>
<p>Também demos prendas aos nossos amigos lá de baixo, coisas que tínhamos ainda dos  
velhos tempos. Disseram-nos hoje que o sr. Vossen fez com as próprias mãos o cinzeiro para o sr. van Daan e os suportes  
para o pai. Acho admirável alguém fazer coisas tão bonitas.</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 10 de Dezembro de 1942</h2>
<p>Querida Kitty:</p>
<p>O sr. van Daan negociava, noutros tempos, em carnes frias, salsichas, chouriços e outras  
especialidades. A firma contratou-o por ser um comerciante muito hábil e experiente. E agora ficámos maravilhados aqui  
com a sua perícia de salsicheiro.</p>
<p>Encomendámos, no mercado negro, já se vê, carne para fazer conservas para os tempos  
difíceis. É engraçado ver a carne passar pela máquina, duas ou três vezes.</p>
<p>Depois juntam-se os temperos, mistura-se tudo bem e, por fim, enchem-se as tripas com  
aquela massa. Comemos ao almoço chucrute com salsicha fresca! Os chouriços defumados têm de secar bem e, por isso,  
enfiámo-los numa vara suspensa do tecto. Sempre que alguém entra no quarto e vê os chouriços a bambolear não pode  
deixar de rir.</p>
<p>É uma exposição patusca.</p>
<p>Havia uma tremenda desordem no quarto. O sr. van Daan (com um avental da esposa), todo  
gorducho, mais gorducho ainda do que de costume, tratava da carne.</p>
<p>Parecia mesmo um carniceiro com as mãos cheias de sangue, a cara afogueada e o avental  
sujo. A sra. van Daan quer fazer mil coisas ao mesmo tempo: estudar holandês por um livro, remexer a sopa, examinar a  
carne com que o marido trabalha e ainda ter tempo para se queixar da sua costela partida.</p>
<p>Bem feito! Quem é que manda as senhoras entradotas e vaidosas fazer ginástica tola, só  
porque não querem ter um traseiro gordo?</p>
<p>O Dussel tinha um olho inflamado e estava junto do fogão a fazer compressas. O pai,  
sentado na cadeira, procurava aproveitar os magros raios do Sol. Julgo que tenha dores de reumatismo, estava todo  
encolhido e seguia com olhos infelizes o trabalho do sr. van Daan. O Peter andava a correr pelo quarto atrás do gato, que  
se chama Mouchi.</p>
<p>A mãe, a Margot e eu descascávamos batatas. Fazíamo-lo automàticamente, porque  
estávamos a contemplar, fascinadas, a actividade do sr. van Daan.</p>
<p>O Dussel inaugurou o consultório de dentista. Vais-te divertir ao saber da primeira consulta.  
A miep estava a passar a ferro enquanto a sra. van Daan fez de primeira cliente. Estava sentada numa cadeira, no meio do  
quarto, enquanto o Dussel tirava cerimoniosamente todos os seus instrumentos. Pediu água-de-colónia para desinfectar e  
vaselina para substituir a cera. Depois olhou para dentro da boca da sra. van Daan. Tocou-lhe num dente molar,  
escabichou-o a seguir com um ferrinho, o que a fazia estremecer e gemer sem nexo, como se estivesse a morrer de dores.  
Depois de um exame sem fIm - pelo menos na opinião da doente, pois na realidade só tinham passado dois minutos - o  
Dussel queria começar a chumbar um dente.</p>
<p>Mas isso sim! A sra. van Daan defendeu-se com braços e pernas, de tal maneira que o  
Dussel teve de largar o gancho com que estava a limpar o buraquinho. O gancho lá ficou espetado no dente. Havias de ver!  
A senhora agitava-se para um lado e para o outro, tentava tirar o gancho mas só conseguia enterrá-lo ainda mais. O Dussel  
não se comovia. De mãos nos bolsos observava o espectáculo.</p>
<p>E nós, os outros espectadores, a rir. Não o devíamos ter feito. Fomos velhacos! com certeza  
eu também me teria portado assim e teria gritado quanto pudesse.</p>
<p>Depois de muito esforço, suspiros e gemidos, a sra. van Daan tirou o ferro, e o Dussel  
retomou o seu trabalho como se nada tivesse acontecido. Tão depressa manejou os instrumentos, que a senhora não teve  
tempo para mais brincadeiras. Mas suponho que ele nunca teve na sua consulta ajudantes tão prestáveis. O sr. van Daan e  
eu éramos os assistentes e agora imagino tudo aquilo como um quadro da Idade Média: &quot;charlatães a  
trabalhar&quot;. Por fim a paciência da senhora esgotou-se. Disse que tinha agora de olhar pela comida. Uma coisa é certa:  
tão cedo não voltará ao dentista.</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>Querida Kitty :</p>
<p>Sentada confortàvelmente à janela do escritório grande, estou a observar, através de meia  
fenda da cortina, o que se passa lá fora. Anoitece, mas ainda consigo ver o bastante para te escrever.</p>
<p>É curioso ver as pessoas a correr! Parece que estão com pressa, quase que tropeçam nos  
seus próprios pés. Os ciclistas passam numa velocidade tal que não consigo distinguir as mulheres dos homens.</p>
<p>Este quarteirão é de gente do povo e a maioria tem aparência pobre. As crianças andam tão  
sujas que eu só me atrevia a tocar-lhes com tenazes. São autênticos garotinhos e falam um dialecto que quase não se  
compreende.</p>
<p>Ontem, quando a Margot e eu estávamos aqui a tomar banho, ocorreu-me uma ideia: se  
pudéssemos pescar algumas daquelas crianças, pela janela e com um anzol, dar-lhes um banho, vesti-las e dar-lhes  
depois novamente a liberdade...</p>
<p>-Amanhã estariam sujas na mesma-interrompeu-me a Margot.</p>
<p>Há mais coisas para ver: automóveis, barcos e a chuva.</p>
<p>Oiço o ruído do carro eléctrico e ponho-me a imaginar as mais variadas coisas. Como nós  
aqui não temos estímulos, os nossos pensamentos também pouco variam. Dos judeus passa-se à comida, da comida à  
política, da política... mas já que falo de judeus: ontem, ao espreitar pela cortina, vi dois judeus. É uma sensação estranha,  
quase como se eu os traísse e estivesse aqui para espionar a sua infelicidade.</p>
<p>Precisamente em frente desta casa há um barco habitado por um pescador com a família.  
Eles têm um cãozinho que já conhecemos pelo ladrar e cujo rabo se vê quando ele corre ao longo da borda do barco.</p>
<p>Agora chove a cântaros e as pessoas escondem-se debaixo dos guarda-chuvas. Só vejo  
impermeáveis e por vezes também um capuz.</p>
<p>Mas não preciso de ver mais, porque já as conheço bem, àquelas mulheres metidas nos  
seus casacos vermelhos ou verdes, com os tacões tortos, uma bolsa gasta debaixo do braço, os corpos inchados por  
comerem batatas de mais e outras coisas de menos. Uma traz a infelicidade estampada no rosto, outra parece feliz, mas  
isto decerto depende do bom ou do mau humor dos seus maridos.</p>
<p>Tua Anne.</p>
<p>&nbsp;</p>
<p>Querida Kitty:</p>
<p>Com grande satisfação, soubemos no anexo que cada um de nós terá para o Natal meio  
quarto de manteiga, fora a do racionamento. Oficialmente recebe-se um meio quilo, mas isto é para os mortais felizes que  
vivem lá fora, na liberdade. Gente &quot;mergulhada como nós que, com oito cartões de racionamento, só pode comprar as  
mercadorias para quatro pessoas, já fica radiante com tão pouco!</p>
<p>Cada um de nós quer fazer doces com a sua manteiga.</p>
<p>Eu farei bolachas e duas tortas. Temos muito que fazer e a mãe disse que não me deixava  
ler nem estudar enquanto não tivesse acabado as minhas obrigações domésticas.</p>
<p>A sra. van Daan está na cama,por causa da costela partida: lamenta-se todo o dia, temos de  
a atender e de lhe mudar as compressas, mas ela nunca está satisfeita.</p>
<p>Só queria que já estivesse outra vez a pé e tratasse sòzinha das suas coisas. Mas tenho de  
lhe fazer justiça: ela é muito trabalhadeira e quando se sente bem, moral e fisicamente, chega a ser mesmo uma pessoa  
divertida.</p>
<p>Todo o santo dia advertiram-me com os &quot;chut-chut&quot;, pois, pelos vistos, sou  
demasiadamente barulhenta, e, como se ainda não bastasse, o meu companheiro de quarto resolveu lançar-me também,  
durante a noite, os &quot;chut-chut&quot;.</p>
<p>Nem sequer admite que me vire na cama. Faço de conta que não dou por nada, mas  
qualquer dia hei-de retribuir-lhe uns &quot;chuts&quot;. Aliás, aos domingos, ele dá-me cabo da paciência. Acende a luz  
muito de madrugada para fazer ginástica. Aquilo parece-me que dura horas e como ele está sempre distraído, dá  
constantemente contra as cadeiras que servem para prolongar a minha cama.</p>
<p>Por fim acordo mesmo de todo. Mas como ainda não tenho dormido bastante, queria  
adormecer de novo.</p>
<p>Depois de ter percorrido os caminhos da força e da beleza&quot;, ele começa a fazer a  
toillete! As cuecas estão penduradas num gancho. Portanto vai até lá e volta. Mas, já se vê, esqueceu-se da gravata em  
cima da mesa. Lá vai ele para lá, para cá, esbarrando com as cadeiras. E pronto!</p>
<p>Acabou-se o meu descanso dos domingos!</p>
<p>Mas valerá a pena a gente queixar-se de homens velhos e esquisitos? Por vezes dá-me na  
gana pregar-lhe uma partida: fechar a luz, desaparafusar a lâmpada e esconder-lhe as roupas. Mas não o faço, por amor  
da santa paz.</p>
<p>Ai! Como estou a ficar ajuizada. Aqui é preciso ter-se juízo a cada passo: para não  
responder, para cumprir as ordens, para ser sempre amável, prestável, transigente e sabe Deus o que mais! Estou a  
abusar do meu juízo que, já por si, não vai longe, e receio que não me sobre nenhum para depois, para quando a guerra  
acabar.</p>
<p>Tua Anne.</p>`],

10: [`<h2>Quarta-feira, 13 de Janeiro de 1943</h2><p>Querida Kitty:</p>
<p>Hoje estamos todos perturbados, não conseguimos fazer nada com calma. As notícias lá de  
fora são horríveis. Dia e noite arrastam a pobre gente das suas casas. Só deixam levar o que cabe na mochila e algum  
dinheiro (mas este tiram-lho mais tarde). Separam as pessoas em três grupos, homens, mulheres e crianças. É vulgar  
voltarem as crianças da escola e já não encontrarem os pais, ou voltarem as mulheres das compras e darem com a casa  
selada. O resto da família já foi deportada.</p>
<p>Nos círculos cristãos também já reina o desassossego.</p>
<p>Os jovens são enviados para a Alemanha. Toda a gente tem medo!</p>
<p>E durante as noites, centenas de aviões sobrevoam a Holanda, para lançarem uma chuva  
de bombas na Alemanha.</p>
<p>A cada hora tombam homens na Rússia e na África. A Terra enlouqueceu, há destruição por  
toda a parte. A situação melhorou para os Aliados, mas o fim de tudo isto ainda está longe.</p>
<p>Nós aqui estamos bem, melhor de que milhares de outras pessoas. Estamos em segurança  
e podemos fazer planos para os tempos do pós-guerra. Podemos pensar nos vestidos e nos livros que havemos de  
comprar em vez de estarmos sempre preocupados com cada tostão que se gasta inùtilmente e que podia servir para ajudar  
os outros, ou com aquelas coisas que se perderam e talvez ainda se pudessem salvar.</p>
<p>Há crianças, cá no quarteirão, que andam de blusinhas leves, de socos e sem meias, sem  
sobretudos, sem boinas ou luvas. Têm o estômago vazio, mastigam cenouras, fogem das casas frias para as ruas húmidas  
e ventosas, e estudam em escolas sem aquecimento.</p>
<p>Mais: as crianças pedem pão às pessoas que passam! Chegaram até este ponto as coisas  
na Holanda! Ouço falar durante horas a fio sobre a miséria que esta guerra trouxe e fico cada vez mais triste. Não temos  
outro remédio senão esperar, calma e serenamente, o fim de tanta infelicidade. Esperam os judeus, esperam os cristãos.  
Esperam os povos de todo o Mundo... mas muitos esperam pela morte!</p>
<p>Tua Anne.</p>
<h2>Domingo, 30 de Janeiro de 1943</h2>
<p>Querida Kitty:</p>
<p>Estou com uma raiva que nem podes fazer ideia. Mas não a posso dar a conhecer a  
ninguém. Gostava de bater com os pés, gritar, sacudir a mãe e não sei o que mais.</p>
<p>E isto por causa das palavras zangadas, dos olhares irónicos, das acusações que contra  
mim são lançadas todos os dias, como setas de um arco muito esticado. Gostava de gritar-lhes, à mãe, à Margot, ao Dussel  
e aos van Daans:</p>
<p>Deixem-me em paz! Então não me deixam passar uma única noite sem molhar o travesseiro  
de lágrimas? Não posso adormecer uma única vez sem que os meus olhos ardam e a cabeça me pese centenas de quilos?  
Deixem-me!</p>
<p>Queria-me ir embora, embora deste Mundo!</p>
<p>Mas para que serviria? Eles nada sabem do meu desespero!</p>
<p>Nada sabem das feridas que me fazem! Já não suporto por mais tempo a compaixão e a  
ironia deles. Só queria mas era chorar!</p>
<p>Acham-me exagerada quando abro a boca, ridícula quando me calo, malcriada quando dou  
uma resposta, manhosa quando tenho uma boa ideia, preguiçosa quando estou com sono, egoísta quando me sirvo mais  
um tudo nada, estúpida, covarde, interesseira, etc., etc... Todo o dia tenho de ouvir que sou uma criatura insuportável, e  
podes crer: embora me ria ou finja não ligar importância, nada daquilo me é, em boa verdade, indiferente.</p>
<p>Bem eu queria pedir a Deus uma outra natureza que não irritasse tanto os outros. Mas é  
impossível. E, de resto, se sou assim, sinto, no entanto, que não sou má. Faço muito mais esforços para lhes agradar a  
todos do que eles imaginam. Rio-me com eles só para não lhes mostrar a minha dor íntima. Mais de uma vez, quando  
discutia com a mãe e ela era injusta para comigo, bradava-lhe: &quot;tanto se me dá como se me deu, do que estás para aí  
a dizer. O melhor é não te preocupares mais comigo, sou um caso perdido&quot;.</p>
<p>Dizem que sou malcriada e não &quot;fazem caso de mim durante dois dias&quot;. E de  
repente tudo me é perdoado e esquecido. Mas eu é que não posso ser um dia muito simpática e carinhosa com alguém,  
para o odiar logo no dia seguinte. Prefiro não me aproximar dos extremos, guardar os meus pensamentos e fazer os  
possíveis para tratar as pessoas com o mesmo desdém com que me tratam a mim.</p>
<p>Ai! se eu fosse capaz disso!</p>
<p>Tua Anne</p>`],

11: [`<h2>Sexta-feira, 5 de Fevereiro de 1943</h2><p>Querida Kitty:</p>
<p>Há bastante tempo que não te tenho falado das nossas encrencas mas não penses que  
alguma coisa se tenha modificado. Ao princípio o sr. Dussel incomodava-se bastante com as várias discussões que ouvia.  
Depois acostumou-se e agora já faz tentativas para servir de medianeiro.</p>
<p>A Margot e o Peter nem parecem jovens de verdade, são ambos monótonos e calmos.  
Claro, eu faço um grande contraste com eles e, por isso, ouço continuamente :</p>
<p>-Olha a Margot e o Peter, eles eram incapazes de fazer tais coisas!</p>
<p>Que maçada! E, já agora, vou confessar-te uma coisa :</p>
<p>não quero de maneira nenhuma ficar como a Margot.</p>
<p>A meu ver é demasiado transigente e insípida, deixa-se influenciar por toda a gente, cede  
sempre. Então não há-de a gente ter a sua opinião! Mas estas teorias não as confio a mais ninguém. Não quero que se  
riam de mim.</p>
<p>à mesa reina muitas vezes uma atmosfera pesada que só se alivia quando um ou outro  
hóspede come em nossa casa-falo das pessoas do escritório, que vêm comer um prato de sopa connosco.</p>
<p>Hoje, ao almoço, o sr. van Daan verificou mais uma vez que a Margot não come o suficiente.  
&quot;Se calhar por causa da linha&quot;, rematou, em tom irónico, o seu discurso.</p>
<p>A mãe que tira sempre as castanhas do lume para a Margot disse muito alto :</p>
<p>-Estou farta do seu palavreado!</p>
<p>A sra. van Daan ficou vermelha como um pimento e ele pôs-se a olhar para o chão,  
embaraçado.</p>
<p>Muitas vezes rimo-nos uns com os outros. Há pouco, a sra. van Daan contou coisas  
engraçadas dos vários &quot;flirts&quot;</p>
<p>que teve e como se entendia bem com o seu pai.</p>
<p>&quot;Se algum homem ousar ser atrevido para contigo deves dizer-lhe: &quot;Meu senhor,  
sou uma senhora&quot;. Ele desistirá logo&quot;, aconselhava-lhe o pai.</p>
<p>Rimo-nos como se nos tivesse contado uma anedota formidável.</p>
<p>O Peter, geralmente muito calado, diverte-nos de vez em quando. Tem o fraco das palavras  
estrangeiras cujo significado raras vezes conhece e o resultado é uma linda baralhada. Certo dia, quando no escritório  
particular havia visitas e não nos era permitido utilizar o W.C., Peter sentiu uma necessidade terrível. Foi mesmo lá, mas  
não puxou o autoclismo. Queria avisar-nos disto e colou na porta do W..C. um papel com as palavras : &quot;Sívelil vous  
plait, cheirete!&quot;. O que ele queria dizer era: &quot;Cautela, cheirete!&quot;. Achou a expressão &quot;sívelil vous  
plait&quot; muito distinta e não fazia ideia nenhuma de que ela se traduz por &quot;faz o favor&quot;.</p>
<p>Tua Anne</p>
<h2>Sábado, 27 de Fevereiro de 1943</h2>
<p>Querida Kitty:</p>
<p>Esperamos a invasão de um dia para outro. Churchill teve uma pneumonia, mas já está  
quase bom. Gandhi, o libertador da Índia, já fez, não sei quantas vezes, a greve da fome.</p>
<p>A sra. van Daan disse ser fatalista. Mas sabes quem tem mais medo quando caem as  
bombas? Claro que é ela, a D. Petronella!</p>
<p>O Henk trouxe-nos a pastoral dos bispos que foi lida em todas as igrejas. É grandiosa e  
incita as pessoas: Não vos caleis, holandeses! Cada um tem que lutar com as suas armas pela liberdade do povo, pela  
pátria e pela religião!</p>
<p>Ajudai, não hesiteis!-Foi assim que falaram. Servirá para alguma coisa? Aos nossos  
correligionários com certeza não serve para nada.</p>
<p>Imagina o que aconteceu. O senhorio, sem avisar o sr. Koophuis ou o sr. Kraler, vendeu a casa. Uma manhã apareceu o novo proprietário com um  
arquitecto.</p>
<p>Queriam ver a casa. Graças a Deus o sr. Koophuis estava presente e mostrou tudo aos  
senhores, menos o anexo.</p>
<p>Disse-lhes que deixara as chaves da porta em casa. Os senhores não insistiram. Oxalá não  
voltem para o anexo.</p>
<p>Seria a nossa desgraça.</p>
<p>O pai deu-nos um ficheiro com fichas novas. Serve-nos, a mim e a Margot, para os livros  
que já lemos. Registámo-los não só pelo autor e título mas também com as nossas observações. Para as palavras  
estrangeiras e os ditos arranjei um caderno especial.</p>
<p>Ultimamente dou-me melhor com a mãe. Mas nunca seremos verdadeiras confidentes uma  
da outra. A Margot está mais impertinente do que nunca, e o pai está muito preocupado com qualquer coisa. Mas ele é e  
será o melhor de todos!</p>
<p>Novas rações de manteiga e de margarina. Cada um recebe a sua parte do dia num  
pratinho. Parece-me que a distribuição quando está ao cargo dos van Daans não corre lá com grande honestidade, mas os  
meus pais estão fartos de zangas e, por isso, calam-se. É pena. A meu ver, devíamos pagar-lhes na mesma moeda.</p>
<p>Tua Anne</p>`],

12: [`<h2>Quarta-feira, 20 de Março de 1943</h2><p>Querida Kitty:</p>
<p>Ontem à noite houve um curto-circuito. E ainda por cima o barulho infernal dos canhões da  
defesa. Não sou capaz de me habituar às bombas e aos aviões. Tenho medo e quase sempre fujo para a cama do pai. Se  
calhar achas-me muito criança, mas só queria que assistisses!</p>
<p>Não ouvimos as nossas próprias palavras, tanto é o barulho dos canhões. A sra. van Daan,  
a fatalista, estava quase a chorar e disse, toda enfiada :</p>
<p>-Acho um horror dispararem tanto.</p>
<p>Não queria isto dizer : tenho muito medo!? De dia a coisa não me aflige tanto. Gritei como se  
tivesse febre e supliquei ao pai que acendesse a vela. Mas ele não se comoveu e continuámos às escuras. Então começou  
o ruido das metralhadoras, que acho pior ainda do que o dos canhões. A mãe saltou fora da cama e, com desgosto do pai,  
acendeu a vela. Ao seu protesto respondeu resolutamente :</p>
<p>-Mas a Anne não é um velho soldado como tu!</p>
<p>E acabou-se! Já te falei dos ataques da sra. van Daan?</p>
<p>Tens que saber tudo o que se passa no anexo. Certo dia ela ouviu passos pesados no  
sótão. Pensou que eram ladrões.</p>
<p>Ficou tão cheia de medo que acordou o marido. No mesmo instante o ruido terminou, o sr.  
van Daan só conseguiu ouvir bater o coração da fatalista.</p>
<p>Ai! Putti: (é como ela chama o sr. van Daan) se calhar roubaram os chouriços e os feijões. E  
que terão feito ao Peter?</p>
<p>-Não roubaram o Peter, não te aflijas! E deixa-me dormir.</p>
<p>Mas isso sim!</p>
<p>Como ela não conseguia adormecer, também o não deixava a ele.</p>
<p>Algumas noites depois, a família van Daan acordou com um barulho esquisito. O Peter subiu  
para o sótão com a sua lâmpada de mão e quando a acendeu viu fugir um bando de ratazanas. Agora sabíamos quem  
eram os ladrões, e pusemos o Mouchi a dormir no sótão. Os . hóspedes indesejáveis, pelo menos durante a noite, não  
voltaram mais. Mas há poucos dias o Peter teve de ir ao sótão (eram sete e meia e ainda dia) para buscar alguns jornais  
velhos. Ao descer a gente tem de agarrar-se à saída.</p>
<p>Ao pousar a mão ia caindo pela escada abaixo. Uma ratazana mordeu-o no braço. Quando  
chegou cá em baixo-e de que maneira!-tinha o pijama cheio de sangue, estava branco como cal e mal se aguentava nas  
pernas.</p>
<p>Não admira, pois ser-se mordido por uma ratazana sem contar é horrível, e ainda por cima  
uma mordedura daquelas... Chega a ser infívelame!</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 12 de Março de 1943</h2>
<p>Querida Kitty:</p>
<p>Posso apresentar-ta: a mamã Frank, defensora da juventude, reclama manteiga  
suplementar para a gente nova.</p>
<p>Luta pelos problemas dos jovens modernos. Luta pela Margot, por mim e pelo Peter, e  
depois de grandes discussões consegue sempre o que pretende.</p>
<p>Estragou-se um frasco de língua de conserva. Resultado:</p>
<p>Jantar de gala para o Mouchi e o Bochi. É verdade, tu ainda não conheces o Bochi. Dizem  
que já estava no imóvel antes de chegarmos nós, os &quot;mergulhadores&quot;. Agora é o gato do armazém e do  
escritório e afasta os ratos.</p>
<p>O seu nome político explica-se fàcilmente. Antes, a casa tinha dois gatos : um para o  
armazém, outro para o sótão.</p>
<p>Quando os dois se encontravam havia sempre luta. Infalivelmente o do armazém é que  
começava, mas o do sótão é que vencia. E, por isso, foram baptizados : o do armazém era o alemão ou o Bochi, o do  
sótão, o inglês ou o Tommy.</p>
<p>O Tommy desapareceu e o Bochi é a nossa distracção quando vamos para baixo.</p>
<p>Comemos tantas vezes feijão branco que já não posso vê-lo à minha frente e fico enjoada  
só de pensar nele.</p>
<p>Ao jantar já não temos pão.</p>
<p>O pai acaba de dizer que está preocupado com vários assuntos. Tem olhos tristes, o  
pobre!</p>
<p>Ando maluca com o livro De Ylop op de Deur, de Ina Boudier-Bakker. É o romance de uma  
família, extraordinário nas descrições. As passagens que tratam da guerra, dos problemas da mulher, dos escritores, não  
os acho tão bem; com toda a franqueza, são assuntos que me interessam pouco.</p>
<p>Bombardeamentos sobre a Alemanha. O sr. van Daan anda de mau génio por não haver  
cigarros.</p>
<p>O problema de se havíamos de comer já ou não os legumes de conserva resolveu-se a  
nosso favor. Além das minhas botas de ski, já não me servem nenhuns sapatos e as botas são bastante incómodas em  
casa. Umas sandálias de palha entrançada duraram uma semana, e acabou-se.</p>
<p>Pode ser que a Miep encontre qualquer coisa no mercado negro. Agora tenho de cortar o  
cabelo ao Pim.</p>
<p>Disse ele que, mesmo depois da guerra não pode voltar ao cabeleireiro, por eu o servir tão  
bem, embora eu o corte tantas vezes na orelha!</p>
<p>Tua Anne</p>
<h2>Quinta-feira 18 de Março de 1943</h2>
<p>Querida Kitty:</p>
<p>A Turquia entrou na guerra... Estamos impacientes pelas notícias da rádio.</p>
<p>É mesmo assim que a rádio transmite este repugnante teatro de marionetas. Dá quase a  
ideia de que os soldados têm orgulho das suas feridas: mais e melhor:</p>
<p>Um deles a quem o Führer consentiu em apertar a mão-caso ainda tivesse alguma-nem  
conseguiu falar.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 19 de Março de 1943</h2>
<p>Querida Kitty:</p>
<p>À alegria seguiu-se uma decepção muito maior. Afinal a Turquia ainda não entrou na guerra.  
O Ministro do Exterior só apelou no seu discurso para que cessasse a neutralidade. O vendedor dos jornais no  
&quot;Pan&quot; tinha gritado :</p>
<p>&quot;A Turquia está do lado dos ingleses&quot;.</p>
<p>Assim nasceu o boato e chegou até nós.</p>
<p>As notas de 500 e 1000 florins vão deixar de ter valor.</p>
<p>Os negociantes do mercado &quot;negro&quot; e os possuidores de dinheiro  
&quot;negro&quot; vão-se ver em maus lençóis, mas o problema é também grave para as pessoas  
&quot;mergulhadas&quot;.</p>
<p>Quando se quer trocar uma nota de mil florins é-se obrigado a declarar e a provar donde ela  
vem. Para já, mas só até ao fim da próxima semana, ainda estas notas podem ser utilizadas para pagamento dos  
impostos.</p>
<p>O Dussel recebeu a sua broca de mão e, em breve, vai examinar os meus dentes.</p>
<p>O &quot;Führer&quot; de todos os germânicos falou perante os seus soldados feridos e  
depois &quot;conversou&quot; ainda com eles.</p>
<p>Que tristeza ouvir aquilo! Um exemplo:</p>
<p>-Meu nome é Heinrich Scheppel!</p>
<p>-Onde ficou ferido?</p>
<p>-Diante de Estalinegrado.</p>
<p>-Que feridas tem?</p>
<p>-Perdi os dois pés por causa do frio e fracturei o pulso esquerdo!</p>
<p>Tua Anne.</p>
<h2>Quinta-feira, 25 de Março de 1943</h2>
<p>Querida Kitty:</p>
<p>A mãe, o pai, a Margot e eu estávamos ontem muito bem dispostos quando entrou o Peter e  
segredou qualquer coisa ao pai. Ouço: &quot;Entornou-se um barril no armazém&quot; e &quot;alguém tentou abrir a  
porta&quot;.</p>
<p>A Margot também ouviu, mas fez os possíveis para me acalmar, pois eu estava branca como  
a cal quando o pai saiu do quarto com o Peter. Ficámos os três à espera, mas dois minutos depois apareceu a sra. van  
Daan que tinha estado no escritório particular a ouvir rádio. O pai pedira-lhe que fechasse o rádio e que saísse sem fazer  
ruído. Mas quando a gente quer ter muita cautela, ainda é pior. E ela disse que os degraus da velha escada tinham rangido  
medonhamente debaixo dos seus pés. Mais cinco minutos... O pai e o Peter voltaram, ambos pálidos até à raiz dos cabelos.  
Contaram-nos o que se passava: sentados, lá em baixo, puseram-se à escuta, mas primeiro, não ouviram nada. Depois, de  
repente ouviram duas pancadas fortes como se alguém tivesse batido com as portas. De um pulo o Pim correu escada  
acima, o Peter foi buscar o Dussel que, antes de mais nada, arrumou as suas coisas. Então subimos todos, em meias, para  
cima. O sr. van Daan está constipado e, por isso, já se tinha deitado. Juntamo-nos todos em volta da sua cama e contamos,  
em voz baixa, as nossas suspeitas. Quando o sr. van Daan tossia alto, a sra. van Daan e eu quase desmáiavamos de  
susto, até que enfim alguém teve a ideia luminosa de lhe dar codeína. A tosse acalmou imediatamente.</p>
<p>Esperámos... Como não ouvimos mais nada, calculámos que os ladrões tinham fugido ao  
ouvir, de repente, passos numa casa tão calma.</p>
<p>Lembrámo-nos de que, por mal dos nossos pecados, o rádio ainda estava sintonizado para  
a emissora inglesa e que as cadeiras estavam desarrumadas. Assim, qualquer pessoa perceberia imediatamente que,  
pouco tempo antes, tinha estado gente naquele quarto. No caso de os ladrões terem arrombado a porta e os da defesa  
antiaérea darem por ela, a polícia seria avisada e as consequências podiam ser muito sérias.</p>
<p>O sr. van Daan levantou-se, vestiu o casaco, pôs o chapéu e desceu cautelosamente com o  
pai. O Peter ia atrás, levando um martelo para o que desse e viesse.</p>
<p>As senhoras, a Margot e eu esperámos com grande ânsia.</p>
<p>Cinco minutos mais tarde os senhores voltaram para nos dizer que estava tudo em ordem.  
Combinámos não abrir as torneiras e não puxar o autoclismo no W. C. Mas como o susto provocou o mesmo efeito em  
todos nós, podes imaginar o cheirete num certo sítio...</p>
<p>Quando acontece uma coisa má vem outra logo a seguir. Foi o que aconteceu. Primeiro: o  
sino da Westertorenjá não toca. Achava-o tão bonito e calmante! Segundo:</p>
<p>sabíamos que o sr. Vossen tinha saído mais cedo na noite anterior, mas o que não  
sabíamos era se a Elli, depois, tinha levado as chaves ou se, porventura, se esqueceu de fechar a porta. Estávamos todos  
um tanto inquietos, embora não se ouvisse o menor ruído desde as oito horas-e já eram onze. Depois de estarmos menos  
excitados parecia-nos-pensando agora com calma-quase inconcebível que algum ladrão tivesse arrombado a porta numa  
hora em que ainda anda tanta gente na rua. A um de nós ocorreu a ideia de que um contramestre da casa vizinha tivesse  
estado a trabalhar. Como as paredes são pouco espessas, é fácil confundir o som dos ruídos, especialmente quando se  
está aflito, e a imaginação também toma um papel importante nesses momentos espinhosos. E assim fomo-nos deitar, mas  
ninguém conseguiu dormir bem.</p>
<p>O pai, a mãe e o Dussel estiveram toda a noite sobressaltados e eu, sem exagero, não  
preguei olho...</p>
<p>Hoje de manhã os senhores desceram para ver se a porta de entrada estava ainda fechada.  
Tudo parecia estar em ordem. Contámos os acontecimentos tão aflitivos, com todos os pormenores, aos nossos  
protectores, que troçaram de nós, mas depois de as coisas se terem passado é fácil rir! Só a Elli é que nos tomou a  
sério.</p>
<p>Tua Anne.</p>
<h2>Sábado, 27 de Março de 1943</h2>
<p>Querida Kitty:</p>
<p>O curso de estenografia terminou. Estamos agora a treinar-nos em velocidade e havemos  
de conseguir chegar ao máximo. Vou contar-te coisas do meu &quot;trabalho-de-matar-o-tempo&quot; (esta designação  
inventei-a eu, porque, ao fim e ao cabo, tudo aqui se faz para preencher o tempo até ao dia em que já não precisarmos de  
estar aqui). Estou entusiasmadíssima com a mitologia e o que mais me interessa são as lendas dos Deuses gregos e  
romanos. &quot;São entusiasmos passageiros&quot; dizem aqui, porque nunca ouviram dizer que uma adolescente se  
tivesse dedicado à mitologia. Mas eu posso bem ser a primeira!</p>
<p>O sr. van Daan está constipado ou antes : arranha-lhe um bocado a garganta e ele faz disto  
um grande acontecimento: gargareja, toma chá de marcela, pincela a garganta com tintura de mirra, põe pomada no nariz,  
no pescoço, no céu da boca e na língua. E, além disso... tem mau génio.</p>
<p>Rauter, um dos alemães mais importantes nesta terra, fez um discurso: todos os judeus têm  
de desaparecer, até 1 de Julho, dos países germânicos. Far-se-á a limpeza (como se se tratasse de baratas!) na província  
de Utrecht do primeiro de Abril até ao primeiro de Maio, na Holanda do Norte; e do Sul do primeiro de Maio até ao primeiro  
de Junho. Como a um rebanho de pessoas doentes e inúteis, levam a pobre gente ao matadouro. Mas não quero falar-te  
mais nisto. Os meus próprios pensamentos provocam-me pesadelos. Também há novidades boas : a repartição de trabalho  
foi sabotada, incendiada e, alguns dias mais tarde, aconteceu o mesmo à repartição da população. Homens metidos em  
uniformes da policia alemã subjugaram os guardas e depois fizeram desaparecer ficheiros importantes, de maneira que as  
convocações e as buscas tornam-se agora bem mais difíceis.</p>
<p>Tua Anne</p>`],

13: [`<h2>Quinta-feira, 1 de Abril de 1943</h2><p>Querida Kitty:</p>
<p>Não há disposição para graças (repara na data)! Aqui justifica-se o provérbio: &quot;Uma  
desgraça não vem só&quot;.</p>
<p>Primeiro : o nosso protector, sr. Koophuis, que nos anima sempre, teve ontem uma forte  
hemorragia do estômago e tem de estar três semanas de cama. Segundo: a Elli está com gripe. Terceiro: para a semana o  
sr. Vossen dá entrada no hospital. Parece que tem uma úlcera e que o vão operar.</p>
<p>Tinham sido feitos planos para uma importante reunião de negócios. O pai tinha tratado  
tudo com o sr. Koophuis.</p>
<p>Agora não há tempo para dar instruções ao Kraler e o pai treme só de pensar no decorrer  
da reunião.</p>
<p>-Se eu pudesse estar presente! - disse. - Se eu pudesse estar lá em baixo!</p>
<p>-Porque não te deitas no chão?-aconselhámo-lo.</p>
<p>-Os senhores negoceiam no escritório particular. Com certeza podes ouvir tudo.</p>
<p>A cara do pai iluminou-se. às dez e meia ele e a Margot tomaram as suas posições e  
escutaram. Duas pessoas ouvem mais do que uma. As negociações não acabaram da parte da manhã, mas à tarde o pai  
não teve coragem para se deitar novamente naquela posição. Estava como que moído. Quando às três horas se ouviram as  
vozes lá em baixo, tomei eu o lugar do pai e a Margot deitou-se ao meu lado. As conversas eram muito longas e  
aborrecidas e, de repente, adormeci naquele oleado tão duro e tão frio.</p>
<p>A Margot não ousou dar-me um empurrão, com medo de que lá em baixo notassem alguma  
coisa. Dormi uma boa meia hora e quando acordei já tinha esquecido as coisas mais importantes. Mas, felizmente, a  
Margot tinha estado com mais atenção.</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 2 de Abril de 1943</h2>
<p>Querida Kitty:</p>
<p>Mais um pecado para a minha lista. Ontem estava à espera que o pai, como de costume,  
viesse para rezar comigo e para me dizer boa-noite. Mas veio a mãe. Sentou-se na minha cama e perguntou, modesta e  
hesitante :</p>
<p>-Anne, o pai ainda não pode vir. Vamos rezar as duas.</p>
<p>-Não, mãe-respondi.</p>
<p>A mãe levantou-se, ficou parada ao lado da minha cama. Depois dirigiu-se devagarinho para  
a porta. De repente virou-se e, desfigurada, disse :</p>
<p>-Não estou zangada, Anne. O amor não é coisa que se possa pedir a alguém.</p>
<p>Corriam-lhe as lágrimas pela cara abaixo.</p>
<p>Fiquei muito quieta e senti que fui má, por tê-la afastado tão brutalmente, mas não podia  
responder de outra maneira. Não sou capaz de fingir e de rezar com ela contra a minha vontade. Palavra que não sou  
capaz.</p>
<p>Tenho pena da mãe, muita pena até, pois compreendi, pela primeira vez, que a minha  
atitude não lhe é indiferente.</p>
<p>Li a dor na sua cara, quando me disse que o amor não era coisa que se pudesse pedir a  
alguém. É duro dizer a verdade. Mas a verdade é que ela me afastou de si.</p>
<p>Foi com as suas observações pouco delicadas e as suas gracinhas sobre coisas que para  
mim são muito sérias.</p>
<p>Assim como em mim tudo se constrange quando ela é dura, também agora se constrangeu  
o seu coração, quando compreendeu que entre nós se tinha extinguido o amor.</p>
<p>Chorou durante toda a noite, quase não dormiu. O pai nem olha para mim, e quando o faz  
leio-lhe a acusação nos olhos : &quot;Como foste capaz de ser tão má para tua mãe?</p>
<p>Como pudeste fazê-la sofrer tanto?&quot;</p>
<p>Estão à espera que peça desculpa. Mas eu não posso pedir desculpa, pois só disse o que é  
verdade, e mais cedo ou mais tarde a mãe ficava a sabê-lo. Parece-me que já não me importo tanto com as lágrimas da  
mãe e o olhar do pai. Não, já não me importo. Pela primeira vez, os dois se aperceberam do que eu sinto continuamente.  
Sim, posso ter pena da mãe, mas só ela própria deve procurar reencontrar-me. Quanto a mim continuarei calada e fria e  
nunca terei medo da verdade. É sempre melhor não adiar o que tem de se dizer.</p>
<p>Tua Anne.</p>
<h2>Terça-feira, 27 de Abril de 1943</h2>
<p>Querida Kitty:</p>
<p>Estamos todos zangados uns com os outros, os van Daans, a mãe, o pai, etc. Lindo  
ambiente, não te parece?</p>
<p>A lista completa dos pecados da Anne chegou a ser desencantada e discutida em toda a  
sua extensão.</p>
<p>O sr. Vossen está no hospital. O sr. Koophuis já anda a pé. Desta vez a hemorragia do  
estômago passou mais depressa do que de costume. Koophuis contou-nos que a repartição da população ficou muito  
destruída depois do assalto. Porque os bombeiros, em vez de extinguirem o fogo, não, inundaram o edifício todo e os danos  
são agora enormes e o Hotel Carlton foi destruído. com o &quot;lar dos oficiais&quot; e toda a esquina da Vijzelstraat-Singel  
ficou destruída pelo fogo.</p>
<p>Dois aviões ingleses, que transportavam grande carga de bombas incendiárias,  
despenharam-se precisamente neste ponto.</p>
<p>Já não há um pouco sequer de sossego durante as noites.</p>
<p>Tenho grandes olheiras porque não consigo dormir.</p>
<p>A comida está uma miséria : os pequenos almoços pão seco e cevada. Ao almoço há mais  
de quinze dias, ou espinafres ou salada, e as batatas, de vinte centímetros de comprimento são vermelhas e doces. Quem  
quiser emagrecer que venha viver connosco Os de cima gemem. Mas nós ainda não fazemos disto uma tragédia.</p>
<p>Todos os homens que tinham sido mobilizados ou que combateram &quot;na guerra de  
cinco dias&quot; em 1940 foram convocados como prisioneiros de guerra e têm de trabalhar para o &quot;Führer&quot;.  
Mais uma medida de precaução contra a invasão!</p>
<p>Tua Anne.</p>`],

14: [`<h2>Sábado, 1 de Maio de 1943</h2><p>Querida Kitty:</p>
<p>Se me ponho a pensar na nossa vida aqui, chego sempre à mesma conclusão : nós, em  
comparação com os judeus que não conseguiram esconder-se, ainda estamos como que no paraíso. Mas mais tarde,  
quando tudo estiver normalizado e eu me puser a pensar naquilo que vivi, ficarei, decerto, admirada dos limites a que nós  
chegámos, especialmente no que respeita aos nossos costumes. Usamos, por exemplo, desde que aqui entrámos, a  
mesma toalha de oleado na mesa, e deves calcular que ela não ficou mais bonita pelo uso. Com um trapo, que é mais  
buracos do que trapo, tento dar-lhe um pouco de &quot;brilho&quot;, mas em vão.</p>
<p>Os van Daans não puderam lavar, durante todo o Inverno, o lençol de flanela que serve  
para poupar os colchões, porque o sabão é raro e muito fraco. O pai anda com umas calças no fio e a gravata já está muito  
gasta. A cinta da mãe rasgou-se-lhe, de velha, e a Margot usa um soutien que lhe é apertado de mais. A mãe e a Margot,  
durante o Inverno remediaram-se as duas com três camisas, e as minhas estão-me curtas, dão-me pela anca. Isto agora  
ainda vai.</p>
<p>Mas assusta-me quando pergunto a mim mesma : será possível que nós tão terrivelmente  
esfarrapados, com tudo tão gasto, a começar pelas minhas solas e a acabar no pincel de barbear do pai, voltemos algum  
dia à mesma vida de outrora?</p>
<p>Hoje os aviões bombardearam a cidade terrivelmente, sobretudo durante a noite. Estive  
resolvida a juntar o indispensável e preparar uma &quot;mala de fuga&quot;, mas a mãe disse e muito bem:</p>
<p>-Para onde querias fugir?</p>
<p>Toda a Holanda está a ser castigada, por haver sabotagens por toda a parte. Foi declarado  
o estado de sítio e tiraram uma ração de manteiga a cada pessoa. É assim que se castigam as crianças mal  
comportadas!</p>
<p>Hoje, à tardinha, lavei a cabeça à mãe. Não é coisa fácil. Temos de nos remediar com o  
sabão amarelo e pegajoso e, além disso, custa muito pentear o cabelo forte da mãe com o pente da família que já só tem  
dez dentes.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 18 de Maio de 1943</h2>
<p>Querida Kitty:</p>
<p>Observámos um combate aéreo entre aviões alemães e ingleses. Infelizmente a tripulação  
de dois ingleses teve de abandonar os aparelhos, saltando em pára-quedas.</p>
<p>O nosso leiteiro que mora no caminho para Harlen, viu quatro canadianos, dos quais um  
falava perfeitamente holandês e que lhe pediu lume para o cigarro. Contou-lhe que a sua tripulação se compunha de seis  
homens, mas que o piloto, infelizmente, morrera no incêndio e o sexto companheiro se tinha escondido não se sabia onde.  
Depois veio a polícia verde e prendeu os quatro aviadores. é admirável a calma e presença de espírito destes homens,  
depois de um salto assim!</p>
<p>Embora já haja calor, precisamos de acender o fogão para queimar os despojos da hortaliça  
e de outras porcarias.</p>
<p>Temos de ter cautela por causa do criado do armazém e não podemos deitar nada no balde  
do lixo. Qualquer pequeno desleixo podia traír-nos.</p>
<p>Todos os estudantes são obrigados a assinar uma declaração de lealdade como sinal de  
simpatia para com os ocupantes. Depois podem continuar os estudos. Oitenta por cento, no entanto, não foram capazes de  
assinar contra a sua convicção e de se vender. As consequências não se fizeram demorar. Todos os estudantes que não  
assinaram são obrigados a trabalhos forçados na Alemanha. O que vai ser da juventude holandesa se as coisas  
continuarem assim?</p>
<p>Hoje à noite a mãe fechou a janela porque o barulho dos bombardeamentos tornava-se  
insuportável. Eu dormia na cama do Pim. De repente ouvimos a sra. van Daan a gritar. Saltou fora da cama como se uma  
tarântula a tivesse picado. Depois ouviu-se uma forte explosão. Imaginei logo que uma bomba incendiária tinha caído junto  
da cama dela e gritei :</p>
<p>-Luz, luz!!!</p>
<p>Pim acendeu a luz e eu esperava que o quarto, dentro de poucos minutos, fosse devorado  
pelo fogo. Mas tudo ficou na mesma. Precipitámo-nos escada acima para ver o que tinha acontecido. Os van Daans tinham  
visto um clarão de fogo pela janela. Ele era de opinião que o incêndio devia ser perto, em qualquer parte, mas ela na sua  
imaginação, já estava a ver a nossa casa a arder. A explosão fê-la saltar da cama. Mas como não se ouvia nem via mais  
nada voltámos a deitar-nos. Depois de um quarto de hora o barulho dos canhões recomeçou. A sra. van Daan fugiu do  
quarto, desceu a escada e refugiou-se junto do sr. Dussel. Pelos vistos o marido não a sabia proteger!</p>
<p>O sr. Dussel recebeu-a com estas palavras:</p>
<p>-Deita-te ao meu lado, minha filhinha!</p>
<p>Desatámos todos a rir e assim salvámos a situação.</p>
<p>Tua Anne</p>`],

15: [`<h2>Domingo, 13 de Junho de 1943</h2><p>Querida Kitty :</p>
<p>O poema que o pai me escreveu para os meus anos é tão lindo que tens de o conhecer.  
Depois de um apanhado dos acontecimentos deste ano, prossegue assim:</p>
<p>Como és a mais nova de todos, Ainda que já bem crescida, Não é lá muito fácil a tua  
vida.</p>
<p>Todos pretendem dar-te lições Mas o que te dão são aflições:</p>
<p>Repara na nossa competência.</p>
<p>Passamos por tudo isso afinal, E sabemos distinguir entre o bem e o mal.</p>
<p>Assim te falam sem interrupção.</p>
<p>Porque os defeitos próprios nunca são muito graves Enquanto que os dos outros são os  
grandes entraves.</p>
<p>Avisam-te, fazem-te ver...</p>
<p>Como se fosse para teu prazer.</p>
<p>E nós, os pais desta filha querida Nem sempre podemos dar-te razão Porque a transigência  
na vida É uma forte condição.</p>
<p>O ano que finda aproveitaste-o bem.</p>
<p>Trabalhaste, leste, aprendeste.</p>
<p>E quase nunca te aborreceste.</p>
<p>No que respeita à roupa, ouço-te perguntar:</p>
<p>O que é que vou usar?</p>
<p>As coisas já não me servem Os sapatos tanto apertam que me enervam A saia, a camisa,  
tudo encolhido.</p>
<p>Reduzido a uma tanga ficou o meu vestido Dez centímetros que a gente se lembre de  
crescer Bastam para em coisa nenhuma se caber.</p>
<p>A Margot fez um Poema sobre a comida. Mas os versos são pouco jeitosos e não tos vou  
transcrever. Todos foram simpáticos, e deram-me muitas prendas bonitas.</p>
<p>Entre outras coisas deram-me um calhamaço sobre o meu interesse pela mitologia da  
Grécia e de Roma. Não me posso queixar, pois sacrificaram alguma coisa das suas últimas reservas.</p>
<p>Sou a mais pequena da &quot;família-mergulhada&quot;. Tenho de confessar que recebo  
mais mimos do que mereço.</p>
<p>Tua Anne.</p>
<h2>Terça-feira, 15 de Junho de 1943</h2>
<p>Querida Kitty :</p>
<p>Aconteceram muitas coisas, mas receio que todas estas histórias te comecem a aborrecer e  
que eu acabe por maçar-te com as minhas cartas. Prometo ser breve.</p>
<p>O sr. Vossen não foi operado ao estômago. Depois de terem feito o golpe no abdómen os  
médicos verificaram que ele tem um cancro, infelizmente tão adiantado que já nada podia fazer-se. Fecharam, trataram-no  
do coração. não veio para casa. Ficou fora durante três semanas. Tenho muita pena dele, e custa-me não poder sair daqui  
para o visitar e distrair um bocado. Sempre era ele que nos vinha contar o que se passava no armazém. Era-nos de um  
grande auxílio, sempre preocupado connosco, o bom Vossen.</p>
<p>Faz-nos uma falta enorme.</p>
<p>No próximo mês seremos provàvelmente obrigados a entregar o nosso rádio. O sr. Koophuis  
tem um desses aparelhos &quot;Baby&quot; que nos vai ceder para substituirmos o nosso grande &quot;Philips&quot;. Que  
pena, termos de nos desfazer do lindo aparelho! Mas numa casa onde há gente escondida nada se deve arriscar. O que  
importa antes de mais nada é a gente desembaraçar-se das autoridades. O rádio pequeno ficará cá em cima. Para um rádio  
há sempre lár, mesmo em casa de judeus escondidos, que compram tudo com dinheiro &quot;negro&quot;. Toda a gente  
anda empenhada em arranjar um aparelho antigo para o entregar às autoridades em vez daquele que tem em casa.</p>
<p>A rádio é para nós a única ligação com o mundo exterior. E a verdade é que, quando  
estamos deprimidos da vida! o Melhor é ter um rádio para nos dár coragem.</p>
<p>Tua Anne.</p>`],

16: [`<h2>Domingo, 11 de Julho de 1943</h2><p>Querida Kitty:</p>
<p>Torno a falar-te sobre &quot;educação&quot;. Asseguro-te que tenho feito todos os  
possíveis para ser prestável, amável e simpática. Assim a avalancha de criticas está a abrandar.</p>
<p>Mas custa muito,comportarmo-nos bem com gente que não podemos ver à nossa frente.  
Alguém me ouve dizer como há vantagem de fingir um bocado na cara de pessoas a quem costumava, dar a minha opinião  
afinal, não ligam importância à minha opinião.</p>
<p>Mas por vezes esqueço mais tantas injustiças. Depois, poder esconder a minha raiva.</p>
<p>Durante semanas fala-se da &quot;mais malcriada rapariga do Mundo!&quot; Não achas  
que sou digna de pena? Ainda bem que tenho senso critico, pois de outro modo azedava e perdia por completo a boa  
disposição.</p>
<p>Com a estenografia, resolvi não me preocupar tanto preciso de mais tempo para os meus  
outros trabalhos, primeiro por causa dos olhos. Ultimamente estou a ficar míope, o que não é nada bom.</p>
<p>Precisava de óculos (decerto ficaria com cara de coruja), mas como sabes, os  
&quot;mergulhados&quot; não têm licença...</p>
<p>Ontem passámos todo o dia a falar de uma coisa só: a mãe andava com a ideia de me  
mandar com a sra. Koophuis ao médico da vista. Ao ouvir aquilo, no primeiro momento fiquei tonta. Não é brincadeira  
nenhuma sair à rua, imagina à rua! Tive a sensação de morrer de medo, não é coisa simples.</p>
<p>E depois fiquei toda contente. Mas a coisa não é assim tão fácil. Tem todas as dificuldades  
e perigos Era preciso pensar bem e decidir as coisas importantes, e as personalidades que entenderem. A Miep queria  
levar-me imediatamente e fui logo ao armário tirar o meu casaco cinzento. Mas este estava-me tão acanhado como se  
pertencesse a uma irmã mais nova. Estou ansiosa por saber se, de facto, vou ao médico. Mas se calhar resolvem  
adiar.</p>
<p>Os ingleses desembarcaram na Sicília e o pai diz que a guerra já não pode demorar muito. A  
Elli entrega-nos, a mim e à Margot, uma parte do seu trabalho do escritório.</p>
<p>Gostamos muito de o fazer, e a Elli poupa tempo.</p>
<p>Julgo que qualquer pessoa sabe classificar a correspondência e assentar as vendas, mas  
nós somos especialmente cuidadosas.</p>
<p>A Miep é o nosso burro de carga, coitada! Quase todos os dias descobre alguma hortaliça e  
trá-la na sua saca amarrada à bicicleta. Também é ela quem cuida, todos os sábados, da troca dos livros, na biblioteca.  
Estamos sempre ansiosamente à espera do sábado, como criancinhas que esperam por uma renda nova mas não a podem  
usar. E fazem uma vida de espera.</p>
<p>Que significam os livros para gente isolada do mundo exterior?</p>
<p>Ler, estudar e ouvir rádio... é este o nosso mundo.</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 16 de Julho de 1943</h2>
<p>Querida Kitty:</p>
<p>Outra vez ladrões, mas desta vez a valer! Da parte da manhã o Peter foi, como sempre, ao  
armazém e verificou que as portas do armazém e da rua estavam abertas.</p>
<p>Foi logo ter com o Pim que, antes de mais nada, ligou o rádio para a emissora alemã e  
fechou a porta. Depois os dois vieram para cima. As ordens, num caso destes, são : não abrir as torneiras, não andar pela  
casa, estar vestido e arranjado às oito horas, não utilizar o W.C.</p>
<p>Estávamos contentes por não termos dado por nada durante a noite, pois, pelo menos,  
dormimos bem. Só às onze e meia é que chegou o sr. Koophuis e contou que os ladrões conseguiram abrir a porta exterior  
com uma alavanca para em seguida arrombar a porta do armazém.</p>
<p>Viram logo que no armazém não havia nada que valesse a pena roubar e então tentaram a  
sorte no andar de cima.</p>
<p>Levaram a caixa do dinheiro com quarenta florins e os livros de cheques em branco, mas o  
pior é que lhes caíram nas mãos todas as senhas do racionamento do açúcar, de mais ou menos 1,50 quilos.</p>
<p>O sr. Koophuis supõe que se tratava dos mesmos ladrões que tentaram, há seis semanas,  
arrombar uma das portas. Nessa altura não o tinham conseguido. Ficámos todos bastante aflitos. Parece que cá no anexo  
não se pode passar sem acontecimentos sensacionais. Ainda bem que as máquinas de escrever e a caixa, grande estavam  
cá em cima onde, aliás, as guardamos todas as noites.</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 19 de Julho de 1943</h2>
<p>Querida Kitty:</p>
<p>No domingo, o Porto de Amesterdão foi terrivelmente bombardeado. Dizem que as  
destruições são medonhas.</p>
<p>Ruas inteiras estão transformadas em montões de entulho e ainda hão-de passar-se muitos  
dias sem se terem encontrado todos os cadáveres. Até agora contam-se duzentos mortos e inúmeros feridos. Os hospitais  
estão apinhados.</p>
<p>Crianças vagueiam entre as ruínas à procura dos pais.</p>
<p>Ainda agora estremeço ao lembrar-me do estampido das explosões e do ruído surdo das  
derrocadas que nos prediziam toda esta destruição.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 23 de Julho de 1943</h2>
<p>Querida Kitty :</p>
<p>Elli descobriu uma loja onde ainda se vendem, sem talões, cadernos e livros de escritório  
para a Margot, que está a aprender contabilidade. Mas não queiras saber o aspecto dos cadernos : papel cinzento com  
linhas tortas e só com doze folhas. E caros como fogo!</p>
<p>Agora hás-de divertir-te um bocado. Vou contar-te o que cada um de nós deseja em primeiro  
lugar quando estiver em liberdade.</p>
<p>A Margot e o sr. Daan gostavam de tomar um banho quente, numa banheira cheia até cima  
e ficar lá dentro, pelo menos, uma meia hora. A sra. van Daan quer ir direitinha a uma confeitaria e comer torta. O Dussel  
não pode pensar em outra coisa senão na sua mulher e na Lottinha; a mãe tem saudades de uma chávena de café.</p>
<p>O pai quer visitar, antes de mais nada, o sr. Vossen; o Peter pensa em ir logo ao centro da  
cidade e ao cinema -e eu? Acho que de tanta felicidade nem era capaz de saber o que havia de fazer primeiro.</p>
<p>Parece que o meu maior desejo é voltar à nossa casa, onde posso estar à vontade, onde  
faço o que me apetece.</p>
<p>Queria também ser orientada nos estudos, isto é: queria ir para a escola!</p>
<p>A Elli tem possibilidades de arranjar fruta no mercado &quot; negro&quot;. Mas os preços  
não são brincadeira nenhuma: uvas, cinco florins, groselhas, setenta cent., um pêssego cinquenta cent., um quilo de melão,  
um florim. Isto, apesar de nos jornais se ler todos os dias: &quot;Qualquer subida de preços é considerada como  
especulação&quot;.</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 26 de Julho de 1943</h2>
<p>Querida Kitty:</p>
<p>O dia de ontem foi bastante tumultuoso e ainda estamos excitados. Com certeza gostavas  
de perguntar se não é possível passar-se aqui um único dia sem aflições.</p>
<p>Estávamos sentados à mesa e a tomar o pequeno almoço quando as sereias deram o  
primeiro alarme. Isto não nos incomoda grande coisa porque quer dizer apenas que os aviões inimigos se estão a  
aproximar da costa. Depois do pequeno almoço deitei-me de novo na cama. Tinha terríveis dores de cabeça. Eram aí duas  
horas quando vim para baixo. às duas e meia a Margot terminou os trabalhos para o escritório. Ainda não tinha arrumado  
as coisas quando se ouviu de novo o toque de alarme, mas desta vez mais forte. Subimos num instante a escada e não foi  
sem tempo, pois cinco minutos mais tarde o barulho tornou-se medonho. Resolvemos refugiar-nos no nosso cantinho de  
&quot;abrigo&quot; no corredor. A casa tremia.</p>
<p>Ouvimos nitidamente o cair das bombas. Apertei a minha malinha debaixo do braço, mais  
para sentir algum amparo do que para fugir.</p>
<p>Depois de uma boa meia hora os aviões foram rareando e toda a gente da casa começou a  
sair dos seus esconderijos.</p>
<p>O Peter desceu do seu posto de observação nas águas-furtadas, o sr. Dussel estivera no  
grande escritório, a sra. van Daan achara que só no escritório particular estaria em segurança e o sr. van Daan observara o  
espectáculo lá do alto do sótão. Só nós tínhamos ficado no cantinho de &quot;abrigo&quot;. Agora subimos todos para o  
andar de cima donde víamos nitidamente as nuvens de fumo sobre o porto de Amesterdão. Em breve chegou até nós o  
cheiro a queimado: era o incêndio. Tive a impressão de que um nevoeiro espesso envolvia a cidade. Um incêndio assim  
não é um espectáculo agradável. Cada um de nós voltou ao seu trabalho, contente por ter escapado. à hora do jantar,  
outra vez alarme. Estávamos a comer umas coisas boas mas eu perdi o apetite logo que ouvi o terrível uivar das sereias.  
Tudo, porém, ficou calmo e três quartos de hora depois deram sinal de fim do alarme. Mas mal tínhamos lavado a louça,  
tudo recomeçou: alarme, estampidos horríveis, muitos, muitos aviões por cima de nós. Pensámos : &quot;céus! Isto agora já  
passa das marcas!&quot;.</p>
<p>Mas ninguém queria saber o que nós pensávamos. Choveram bombas sobre bombas, desta  
vez do outro lado (no Schiphol). Foram os ingleses que deram a notícia.</p>
<p>Os aviões mergulhavam, subiam. O ar parecia vibrar.</p>
<p>Tive receio de que algum caísse por cima de mim.</p>
<p>Podes crer, já nem me segurava nas pernas quando às nove horas fui para a cama.</p>
<p>À meia-noite em ponto, aviões! O Dussel estava precisamente a despir-se. Eu quis lá saber.  
à primeira explosão saltei cama fora. Duas horas de voos constantes e, por isso, fiquei na cama do pai. Só depois, quando  
já não se ouvia mais nada, voltei para o meu quarto. às duas e meia adormeci.</p>
<p>Sete horas. Acordei num sobressalto. O sr. van Daan estava no quarto do pai.  
&quot;Tudo&quot;, ouvi-lhe dizer. &quot;Pronto, ladrões&quot;, pensei e imaginei logo que nos tinham roubado tudo. Mas  
não! Seguiu-se um relatório como não tínhamos ouvido há meses, talvez mesmo durante toda esta guerra:</p>
<p>Mussolini caiu, o rei da Itália tomou conta do governo.</p>
<p>Ficámos radiantes. Depois do susto de ontem, enfim alguma coisa de bom e... um pouco de  
esperança! Esperança do fim. Esperança da paz!</p>
<p>Chegou o Kraler e contou que Fokker está muito destruído.</p>
<p>Entretanto, tivemos também outro alarme, de noite.</p>
<p>Vieram muitos aviões e depois outra vez alarme. Parece que sufoco com tantos alarmes  
aéreos, não durmo o suficiente e não consigo trabalhar como deve ser. Mas agora a ansiedade e a esperança de que  
esteja a chegar o fim de tudo isto, fazem com que não desanimemos. Oxalá tudo acabe ainda este ano.</p>
<p>Tua Anne.</p>
<h2>Quinta-feira, 29 de Julho de 1943</h2>
<p>Querida Kitty:</p>
<p>A sra. van Daan, o Dussel e eu estávamos a lavar a louça e, o que acontece raras vezes e  
que eles devem também ter estranhado, eu estava excepcionalmente silenciosa.</p>
<p>Para evitar perguntas, procurei um tema neutro e, por fim, comecei a palrar sobre o livro  
Henri van den O Cerkant.</p>
<p>Mas enganei-me nos cálculos. Se não é a sra. van Daan que me diz das suas, então é com  
certeza o Dussel.</p>
<p>É que a coisa foi esta: o Dussel tinha-nos recomendado o livro como uma coisa  
extraordinária. Mas nem a Margot nem eu lhe encontrámos nada de especial. A figura do rapaz está bem descrita, mas o  
resto... é melhor não falar nisso. Enfim, eu disse-lhe o que pensava do livro.</p>
<p>Havias de ouvi-lo :</p>
<p>-O que é que sabes tu afinal da psicologia de um homem? Se o livro tratasse de uma  
criança, vá lá. És nova de mais para compreenderes um livro destes. Nem um jovem de vinte anos o entende bem. (Só  
gostava de saber porque é que ele tanto nos recomendou o livro).</p>
<p>E agora desataram ambos a atacar-me :</p>
<p>-Sabes coisas de mais, coisas que ainda não te dizem respeito. Tiveste uma educação  
errada. Mais tarde não te contentarás com coisíssima nenhuma. Hás-de dizer: &quot;aquilo? Já o li há uns anos num  
livro&quot;. Apressa-te se ainda queres apanhar um marido ou se queres apaixonar-te.</p>
<p>Se calhar só hás-de encontrar defeitos em toda a gente! Sabes muita coisa em teoria, mas  
na prática tudo é diferente.</p>
<p>Parece que eles pensam que é boa educação incitarem-me contra os meus pais. Gostam  
disso. Acham também que é um método excelente não falar com uma rapariga da minha idade sobre &quot;assuntos de  
adultos&quot;.</p>
<p>Ora os resultados de uma educação assim são sempre desastrosos!</p>
<p>Apeteceu-me dar-lhes na cara pelas suas manias ridículas.</p>
<p>Fervi de raiva. Ah! se pudesse começar a contar os dias que faltam para me ver livre deles!  
A sra. van Daan, que encanto!... é que me deve servir de exemplo! Sim, de exemplo... daquilo que se não deve ser!</p>
<p>Todos o sabem: ela é impertinente, egoísta, espertalhona, interesseira e nunca está  
satisfeita. Eu podia escrever livros sobre esta senhora, e quem sabe se não o farei um dia. O seu &quot;verniz&quot; estala  
com facilidade. Ela faz-se simpática e amável, principalmente junto dos homens.</p>
<p>Mas isso não passa de um &quot;bluff&quot;! A mãe acha-a estúpida de mais e que nem  
vale a pena perder palavras com ela. A Margot acha-a insignificante. O Pim diz que é feia, física e moralmente, e eu percebi  
depois de a ter observado - pois não tenho preconceitos - que todas essas opiniões estão certas, mais do que certas! Tem  
tantas qualidades más que nem sei a qual delas havia de dar o primeiro lugar.</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>P. S.</p>
<p>Peço à querida leitora que se não esqueça de que esta carta foi escrita com raiva ainda não  
esfriada!</p>`],

17: [`<h2>Terça-feira, 3 de Agosto de 1943</h2><p>Querida Kitty:</p>
<p>Politicamente, tudo vai às mil maravilhas. Na Itália proibiram o partido fascista. Em várias  
regiões o povo bate-se contra os fascistas. Até os soldados tomam parte.</p>
<p>Como querem que um povo assim ainda se ponha a lutar contra a Inglaterra!</p>
<p>Pela terceira vez a cidade foi violentamente bombardeada. Cerrei os dentes e disse para  
comigo:</p>
<p>&quot;Coragem!&quot;.</p>
<p>A sra. van Daan que até agora sempre dizia: &quot;É melhor acabarem os sustos de uma  
vez do que ficar à espera indefinidamente&quot;, é agora a mais cobarde de todos. Hoje de manhã tremia como varas  
verdes e depois desatou a chorar.</p>
<p>O marido, com quem depois de uma semana de vida de cão e gato acabou por fazer as  
pazes, acalmou-a carinhosamente. A gente ia ficando quase sentimental perante aquela linda cena.</p>
<p>A propósito de gatos. Afinal não são apenas úteis.</p>
<p>A Mouchi deu-nos a prova disso. Andamos todos com pulgas, e a praga torna-se, de dia  
para dia, mais insuportável.</p>
<p>O sr. Koophuis espalhou por toda a parte um pó amarelo que parece não ter efeito algum  
sobre as pulgas. Já andamos todos nervosos. Não nos conseguimos abstrair disso, sentimos os bichinhos a correr pelos  
braços, pelas pernas e por toda a parte do corpo. A gente exibe-se com os movimentos mais cômicos deste Mundo,  
procurando caçar os minúsculos verdugos. Mas todo o movimento nos causa embaraço. Falta-nos o jeito porque fazemos  
pouca ginástica e já não temos o corpo flexível.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 2 de Agosto de 1943</h2>
<p>Querida Kitty:</p>
<p>Depois de passarmos mais de um ano fechados no anexo, já estás bem informada sobre a  
nossa vida. Há coisas que dificilmente se conseguem escrever. Tudo é tão complicado e diferente da vida em liberdade!  
Mas para que possas fazer melhor ideia, vou contar-te de vez em quando aquilo que acontece regularmente todos os dias.  
Hoje vou começar pelo fim do dia.</p>
<p>às nove horas toda a gente começa a fazer os preparativos para se deitar. Puxam-se  
cadeiras, vão-se buscar as roupas das camas, estendem-se os cobertores. Realmente nada fica onde estava durante o dia.  
Eu durmo no pequeno sofá que tem mais ou menos metro e meio e preciso de cadeiras para o prolongar. Durante o dia o  
meu &quot;edredon&quot;, os cobertores, o travesseiro e os lençóis guardam-se na cama do Dussel.</p>
<p>No quarto ao lado ouve-se chiar e ranger: a cama da Margot é &quot;armada&quot;. E de  
novo surgem cobertores e almofadões, sabe-se lá de onde.</p>
<p>Podia julgar-se que estava a trovejar se não se soubesse que é a cama da sra. van Daan  
que está agora a ser arrastada para a janela. &quot;Sua Majestade&quot;, de &quot;liseuse&quot; cor-de-rosa, tem de  
respirar, através do seu belo narizinho, o ozone fresco junto da janela.</p>
<p>&nbsp;</p>
<p>Depois de o Peter estar arranjado-mais ou menos às nove horas- entro eu no &quot;quarto  
de banho&quot; para me lavar minuciosamente, e então uma pulguinha perde, não raras vezes, a sua vida. Depois lavo os  
dentes, ponho os &quot;bigoudis&quot;, arranjo as unhas e trato de outros pequenos segredos da toilette... e tudo isto  
numa escassa meia hora.</p>
<p>às nove e meia meto-me no roupão de banho, saio ràpidamente, levando o sabão, os  
alfinetes, bigoudis, algodão em rama!, etc., e a roupa sobre o braço. Mas muitas vezes sou chamada para voltar atrás, por  
ter enfeitado o lavatório com um ou outro dos meus lindos cabelos pretos, o que, pelos vistos, não agrada ao meu  
sucessor.</p>
<p>Dez horas: apagam-se as luzes. Boa-noite. Durante um quarto de hora ainda se ouve o  
ranger das camas e os suspiros das molas escangalhadas. Depois tudo é silêncio, pelo menos quando lá em cima não há  
discussão conjugal.</p>
<p>às onze e meia abre-se a porta do &quot;quarto de banho.&quot;</p>
<p>Um magro raio de luz, um arrastar de sapatos. ívelum roupão largo, largo de mais para  
aquela figura, entra o Dussel, que tinha estado a trabalhar no escritório do Kraler.</p>
<p>Durante dez minutos anda às furtadelas, mexe com papéis, anda a esconder as guloseimas,  
arranja a cama, desaparece de novo e, de tempos a tempos, ouvem-se ruídos suspeitos no W.C.</p>
<p>às três horas tenho eu de me levantar para fazer uma coisa que ninguém pode fazer por  
mim. Debaixo da lata, que serve para isso, há um bocado de tapete de borracha para todas as eventualidades, pois a lata  
pode começar a verter. Retenho de todas as vezes a respiração para apreciar o ruído; parece-me ouvir correr um ribeirinho  
sobre calhaus. E depois a figurinha branca que ouve troçar a Margot noite após noite: &quot;Oh, que camisa tão  
imoral!&quot;, torna a desaparecer debaixo dos cobertores.</p>
<p>Durante um quarto de hora escuto ainda os ruídos nocturnos.</p>
<p>Primeiro : lá em baixo não estará algum ladrão?</p>
<p>Depois concentro a minha atenção nos ruídos dos vizinhos de cima, do lado e do que está  
junto de mim. Por eles podia fazer-se um resumo de temperamentos. Alguns estão pesadamente ferrados no sono, outros  
estão meio acordados, o que não é coisa agradável, quando se trata do sr. Dussel. Primeiro dá a impressão de um peixe  
que procura apanhar ar com a boca, e isso por aí umas dez vezes. Depois humedece os lábios e dá estalinhos com a  
língua. Ao mesmo tempo volta-se para um lado, volta-se para o outro e puxa pelo travesseiro até encontrar uma posição  
cómoda. Com pequenos intervalos todas estas manobras se repetem pelo menos três vezes e, finalmente, o bom doutor  
adormece.</p>
<p>Por vezes acontece haver bombardeamentos. Mal começam estou logo meio acordada, com  
os pés no chão.</p>
<p>Há também noites em que sonho com verbos irregulares ou com uma discussão conjugal, lá  
em cima. Só então é que me acontece ter a sorte de não acordar e de não dar conta dos bombardeamentos. Mas das  
outras vezes saio da cama de um pulo, pego no travesseiro e no lenço, enfio o roupão e os chinelos e corro para a cama  
do pai.</p>
<p>A Margot descreveu a cena num poema de aniversário.</p>
<p>Quando de noite um avião mal se adivinha certo e sabido que uma certa mocinha Vai  
aparecer ao pai a implorar que lhe ceda na cama um pouco de lugar!</p>
<p>Recolhida na cama do pai, o pior susto para mim já passou, caso o barulho não se torne  
mesmo dramático.</p>
<p>Um quarto para as sete : rrring... o despertador lá em cima.</p>
<p>Ping, pang... é a sra. van Daan que o desliga. O seu marido levanta-se-a gente bem o  
ouve-põe a água a ferver e vai para o quarto de banho. Uma meia hora depois é a vez do Dussel. Finalmente estou só-,  
abro os cortinados escuros - um novo dia começa no anexo!</p>
<p>Tua Anne.</p>
<h2>Quinta-feira, 5 de Agosto de 1943</h2>
<p>Querida Kitty :</p>
<p>Hoje vou-te falar da hora do almoço.</p>
<p>Meio-dia e meia hora: todo o nosso ninho respira de alívio. Os criados do armazém saíram.  
Lá em cima ouve-se o aspirador com que a sra. van Daan trata carinhosamente uo seu querido e único tapete. A Margot  
mete os livros debaixo do braço e vai ter com o seu aluno Dussel que é um pouco tapadinho para aprender holandês. O  
Pim retira-se para um cantinho onde possa gozar o seu querido Dickens. A mãe sobe para o andar de cima e dá uma ajuda  
à &quot;perfeita dona de casa&quot;, enquanto eu me meto no quarto de banho, faço uma pequena arrumação das coisas  
e dou uma arranjadela à minha pessoa.</p>
<p>Uma menos um quarto: um após outro aparecem: o sr. v. Santen, o sr. Koophuis ou o Kraler,  
a Elli e quase sempre também a Miep.</p>
<p>Uma hora : todos ouvem animosamente as notícias da B. B. C. São estes os únicos  
momentos em que os habitantes do anexo não se interrompem uns aos outros, pois o que está a falar não pode ser  
contrariado, nem sequer pelo sr. van Daan.</p>
<p>Uma hora e um quarto : uma refeição simples : uma chávena de sopa para cada visitante. E  
se há sobremesa é também repartida com eles. Contente, o sr. v. Santen recosta-se no canto do sofá, desdobra o jornal, o  
gato ao seu lado, a chávena em frente. É a jovialidade em pessoa.</p>
<p>O sr. Koophuis conta novidades da cidade. É uma fonte inesgotável. O Kraler sobe a escada  
aos pulinhos, bate um tanto rápido e seco à porta, entra esfregando as mãos e, conforme a disposição, mostra-se animado  
e alegre ou deprimido e calado.</p>
<p>Duas menos um quarto: os hóspedes despedem-se, voltam ao trabalho. A mãe e a Margot  
lavam a louça, o sr. e a sra. van Daan vão dormir, o Peter desaparece no seu quarto, o pai estende-se um bocadinho, o  
Dussel faz o mesmo, eu leio ou escrevo. É esta a hora mais simpática.</p>
<p>Quando as pessoas dormem não nos estorvam.</p>
<p>O Dussel sonha com boa comidinha. Leio-lho no seu rosto. Mas não gasto tempo a estudar  
o Dussel, porque o tempo passa tão depressa! Um minuto depois das quatro aquele caturra já está ao meu lado a  
resmungar por eu ainda não ter deixado a mesa.</p>
<p>Tua Anne.</p>

<h2>Segunda-feira, 9 de Agosto de 1943</h2>
<p>Querida Kitty:</p>
<p>Vou continuar com o boletim. O nosso jantar: o sr. van Daan é o primeiro a servir-se e  
serve-se abundantemente de tudo... isto é, se houver coisas ao seu paladar.</p>
<p>Fala sempre, mete-se em tudo, impinge as suas opiniões e depois de as ter impingido não  
há ninguém que lhas possa modificar. Ai daquele que se atreva a contrariá-lo.</p>
<p>Bufa como um gato... e se alguém se atreve uma vez, não fica com vontade de repetir. Só  
ele é que tem opiniões certas, só ele é que sabe tudo! É um finório, isto não se lhe pode negar, mas a sua presunção é  
qualquer coisa de descomunal.</p>
<p>A ilustre senhora: o melhor seria eu nem falar nela.</p>
<p>Por vezes, principalmente quando está de mau génio, nem me apetece olhar para ela.  
Vistas bem as coisas, é quase sempre ela quem provoca as discussões, mesmo que não sejam sobre a sua pessoa. Por  
amor de Deus, isso não!</p>
<p>Todos evitam zangar-se com ela. Mas o que eu queria dizer é que a sra. van Daan provoca  
as discussões. Provocar, sim, esta arte conhece-a a fundo! Provocar a sra. Frank e a Anne! Com o pai e com a Margot a  
coisa já é mais difícil, porque eles não lhe dão motivo.</p>
<p>À mesa, a sra. van Daan não fica nunca em desvantagem, embora imagine que fica. As  
batatas mais pequenas, os pedaços mais delicados, apanhar sempre o melhor, é esta a sua divisa! Os outros que se  
arranjem. O essencial é que ela tenha conseguido aquilo que queria! E nunca mais se cala!</p>
<p>Tanto se lhe dá como se lhe deu se as pessoas estão a ouvir ou não interessadas. Está  
convencida de que as suas palavras douradas são um gozo para toda a gente. Sempre a sorrir com  
&quot;coquetterie&quot;, pretende saber todas as coisas, dá, maternalmente, conselhos e pensa que está a causar a  
melhor das impressões. Mas examinando-a bem, descobre-se logo que atrás de tudo aquilo há muito pouca coisa.</p>
<p>Característica número 1 - aplicação. Segundo - alegria. Número 3 - &quot;coquetterie&quot;.  
E por vezes boa apresentação. Petronella van Daan.</p>
<p>O terceiro companheiro de mesa, o jovem sr. van Daan, refila pouco e não chama a atenção  
sobre si.</p>
<p>O seu estômago deve ser uma espécie de tonel das Danaides, pois mesmo quando a  
comida é forte e depois de ter consumido uma porção fantástica, afirma, com a cara mais séria deste mundo, que teria sido  
capaz de comer o dobro.</p>
<p>o quarto é a Margot. Fala pouco e come como um passarinho.</p>
<p>As únicas coisas que lhe escorregam bem pela garganta abaixo são hortaliças e frutas.  
&quot;Amimalhada&quot;, é a sentença dos van Daans. Mas a nossa opinião é outra:</p>
<p>&quot;Falta de ar e de movimento&quot;.</p>
<p>Ao lado a mãe. Come bem, fala muito e com gosto.</p>
<p>Ninguém a tomaria por dona de casa como à sra. van Daan.</p>
<p>E porquê? Porque a ilustre senhora é que cozinha e a mãe só limpa e lava a louça.</p>
<p>Somos 6 e : a respeito do pai e de mim não vou dizer muita coisa. O Pim é o mais modesto  
de todos à mesa.</p>
<p>Olha primeiro à sua volta, a ver se os outros estão bem servidos. Não necessita de nada em  
especial e tudo o que é bom vai para as filhas. É o exemplo da bondade e da grandeza de alma... e ao seu lado fica  
sentado o feixe de nervos do anexo!</p>
<p>O sr. Dussel: serve-se mas não olha para ninguém. Come e não fala. Mas se é absolutamente indispensável falar, então escolhe o tema  
&quot;comida&quot; por ser um tema que não provoca conflitos, quando muito dará lugar a algumas fanfarronices.  
Consegue engolir porções gigantescas, nunca diz que não, tanto faz que a comida seja boa como má. Puxa as calças  
demasiado para cima, usa um colete vermelho e chinelos pretos e sobre o nariz pousam-lhe uns óculos de armação  
escura. É assim que se apresenta na mesa de trabalho, às refeições, durante a sesta e quando vai ao seu lugar favorito,  
uma, duas, Três, quatro ou cinco vezes por dia está algum de nós em frente da porta do W.C.</p>
<p>saltando de impaciência de um pé para o outro, quase sem poder esperar mais.</p>
<p>Julgas que isso o comove? Nem pensar em tal! Podem registar-se sessões dessas das sete  
e um quarto às sete e meia, da meia-hora à uma, das duas às duas e um quarto, das quatro às quatro e um quarto, das  
seis às seis e um quarto e das onze e meia à meia-noite. Disso não desiste e nem a voz mais suplicante, a profetizar um  
acidente, o pode comover.</p>
<p>Um outro, não é pròpriamente um membro da família do anexo, mas companheira de casa e  
de mesa, a Elli.</p>
<p>Tem bom apetite, não é esquisita e nunca deixa ficar restos no prato. Fica contente com a  
coisa mais insignificante e dá-nos também prazer com isso. Está sempre alegre e de bom humor, é prestável e simpática,  
enfim só tem boas qualidades.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 10 de Agosto de 1943</h2>
<p>Querida Kitty:</p>
<p>Uma ideia nova! Converso à mesa mais comigo própria do que com os outros, o que tem  
duas vantagens: provàvelmente todos ficam contentes quando falo pouco e, além disso, não preciso de me aborrecer com  
as opiniões dos outros. Como acho as opiniões dos outros quase sempre tolas e só as minhas certas, o melhor é não dizer  
nada.</p>
<p>Da mesma maneira procedo quando há uma comida de que não gosto. Imagino que aquilo é  
muito bom, finjo mesmo que assim penso, e antes que consiga reflectir, já engoli tudo. Pela manhã quando me  
levanto-outra coisa desagradável - salto da cama e digo para comigo:</p>
<p>&quot;Vais-te já deitar outra vez&quot;. Tiro os cortinados escuros da camuflagem, respiro  
um pouco de ar fresco pelas fendas até ficar bem acordada. Quando depois tiro as roupas da cama, já não sinto a tentação  
de deitar-me.</p>
<p>Sabes como a mãe chama a isto? &quot;A arte de viver&quot;.</p>
<p>Uma expressão patusca, não achas?</p>
<p>Há uma semana que não sabemos as horas exactas, porque levaram o nosso tão querido e  
fiel sino da torre Oeste. Supomos que querem transformá-lo num canhão.</p>
<p>Quase nunca sabemos que horas são. Espero que descubram alguma coisa que nos  
indique o tempo e substitua também o lindo som. É preciso que o quarteirão não sinta tanto a falta do seu sino.</p>
<p>Seja como for que eu esteja, lá em cima ou cá em baixo, todos olham sempre com  
admiração para os meus pés. É que os meus pés ostentam sapatos novos. A Miep conseguiu comprá-los em segunda mão  
por vinte e sete florins e meio. São de camurça cor de vinho e têm um salto largo e bastante alto. É como se fossem umas  
andas e pareço ainda mais alta do que sou. Ontem tive pouca sorte. Piquei-me no polegar direito com uma agulha  
grossa.</p>
<p>Não pude descascar as batatas, e a Margot teve de fazê-lo por mim. Depois dei com a testa  
contra a porta do armário e tão forte foi a pancada que quase caí ao chão. E como aquilo não se passou sem estrondo,  
apanhei um raspanete ainda por cima. Não pude refrescar a testa porque estávamos proibidos de abrir as torneiras. Agora  
ando com um galo enorme sobre o olho direito. E para cúmulo entalei o dedo pequeno do pé direito no aspirador. Mas as  
minhas outras dores eram já tão grandes que não liguei a esta nova. Fui tola porque a ferida infectou, tenho de andar com  
o pé ligado... e não posso calçar os meus lindos sapatos.</p>
<p>O Dussel fez-nos indirectamente correr perigo de vida.</p>
<p>Pediu à Miep-que nada sabia destas coisas-para lhe trazer um livro que está proibido, um  
panfleto contra Hitler e Mussolini. Precisamente esta manhã uma moto das SS esbarrou contra a bicicleta dela. Ela perdeu  
a cabeça e gritou-lhes: &quot;Patifes!&quot;, mas, felizmente, pôs-se a andar. O melhor é a gente não imaginar o que teria  
acontecido se a tivessem levado ao posto da polícia.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 18 de Agosto de 1943</h2>
<p>Querida Kitty:</p>
<p>Hoje vou descrever-te o nosso dever quotidiano de descascar as batatas.</p>
<p>Um de nós vai buscar os jornais (para as cascas), outro as facas (e, evidentemente, fica  
para si com a melhor), outro traz as batatas e o último, um panelão com água.</p>
<p>O sr. Dussel começa, descasca bastante mal, mas, sem interrupção, olha, de vez em  
quando, para a direita e para a esquerda, porque quer verificar se os outros trabalham tão bem como ele. Chega à  
conclusão de que isso não sucede.</p>
<p>-Anne, não vês? Eu pego na faca assim, e descasco de cima para baixo. Não, assim não!  
Olha, assim é que deve ser!</p>
<p>-Acho o meu modo mais cómodo - ouso dizer finalmente.</p>
<p>-Olha que como eu faço é melhor, podes crer. Mas, afinal, que me importa a mim? Faze  
como entenderes.</p>
<p>Continuamos a descascar. Olho de esguelha para o meu vizinho da esquerda. Está a  
abanar a cabeça, por minha causa, suponho. Mas não me diz nada. Continuo a descascar. Depois olho para o pai que está  
em frente de mim. Para ele, descascar batatas não é uma brincadeira mas sim um trabalho de precisão. Quando o pai está  
a ler, tem uma ruga profunda na testa, mas quando descasca batatas ou quando ajuda a preparar a hortaliça, então dá a  
impressão de ser impermeável a tudo o que acontece à sua volta. Nestas ocasiões põe a sua cara &quot;para  
batatas&quot;, e nunca entregará uma só que não esteja descascada impecàvelmente. Com uma cara assim também seria  
impossível não se fazer coisa perfeita, e era ele sempre a trabalhar. levanto os olhos de quando em quando, e sei logo  
tudo, Não tira os olhos dele, mas chama sobre si a atenção do Dussel, pisca-lhe os olhos.</p>
<p>ele finge não dar por nada. Depois ela como que pensa - bem, isto não está mau. - E ele  
continua a descascar. Ela ri-se, mas também não deixa de descascar. A sra. van Daan diz: - Porque não pões o  
avental?</p>
<p>-Não me sujo.</p>
<p>E ela continua a cismar.</p>
<p>- Porque não te sentas?</p>
<p>-Estou muito bem assim, gosto de estar de pé.</p>
<p>Novo silêncio.</p>
<p>- Putti, vês, agora fizeste saltar a água.</p>
<p>- Está bem, Mammi, hei-de ter mais cautela.</p>
<p>E ela a inventar outro tema.</p>
<p>-Oh, Putti, dize lá, porque é que os ingleses deixaram de bombardear?</p>
<p>-Por causa do mau tempo, suponho.</p>
<p>-Mas ontem esteve bom tempo e eles não vieram.</p>
<p>-E se falássemos de outras coisas?</p>
<p>-Mas porque não há-de a gente falar sobre isto?</p>
<p>-Porque não.</p>
<p>-Mas porquê?</p>
<p>-Cala-te Mammi!</p>
<p>-O Frank nunca deixa de responder à mulher quando ela quer saber alguma coisa.</p>
<p>O sr. van Daan não responde.</p>
<p>Ela retoma a conversa Depois de uns minutos de silêncio:</p>
<p>- Nunca mais fazem a invasão.</p>
<p>O marido fica vermelho de raiva. Ela bem o vê e cora.</p>
<p>Agora a bomba rebenta:</p>
<p>- Cala a boca! Caramba, caramba.</p>
<p>Eu nem olho para ninguém. Minha mãe mal pôde esconder o riso Cenas destas ou  
semelhantes repetem-se quase todos os dias, a não ser que o casal esteja amuado, o que é de grande vantagem, porque,  
ao menos, não diz nada.</p>
<p>Tenho de ir ao sótão buscar mais batatas. Vejo o Peter a catar o gato. Quando me  
aproximo, ele ergue os olhos. O gato, ao perceber que não está preso, dá um pulo e foge pela janela. O Peter roga pragas,  
eu rio e desapareço.</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 20 de Agosto de 1943</h2>
<p>Querida Kitty:</p>
<p>às cinco e meia em ponto os operários saem do armazém e a nossa liberdade  
recomeça.</p>
<p>Quando a Elli sobe, sabemos que já não há perigo e começamos a mexer-nos à vontade.  
Quase sempre vou com ela para cima, onde ficou guardada uma lambarice.</p>
<p>Mal a Elli se senta, logo a sra. van Daan começa a enumerar os seus desejos:</p>
<p>- Ai, Elli!, eu gostava tanto de...</p>
<p>A Elli pisca-me os olhos. É raro alguém do escritório aparecer lá em cima sem que a sra. van  
Daan deixe de ter algum desejo. É esta a razão por que ninguém gosta de subir até ao andar dos van Daans.</p>
<p>Seis menos um quarto. A Elli deixa-nos e eu vou descer à cozinha, depois entro no escritório  
particular, abro a porta da carvoeira ao Mouchi, que quer ir para lá caçar ratos. Por fim vou ao escritório do sr. Kraler, onde  
o sr. van Daan está a examinar as pastas e as gavetas para ver a correspondência do dia. O Peter vai buscar a chave do  
armazém e também o Bochi. O Pim leva a máquina de escrever para cima. A Margot procura um sítio calmo para se  
entregar aos trabalhos do escritório. A sra. van Daan põe um panelão de água a ferver; a mãe está a descer com uma  
panela de batatas. Cada um cumpre a sua obrigação.</p>
<p>O Peter volta do sótão. A sua primeira pergunta é se não se esqueceram de pôr o nosso  
pão no escritório do Kraler. Esqueceram-se! Então ele não tem outro remédio senão ir procurá-lo no escritório grande.  
Gatinha como os bebés para que ninguém de fora o possa ver. Abre o armário, tira o pão e desaparece, isto é, quer  
desaparecer, mas durante aquele passeio, o Mouchi saltou por cima dele e depois escondeu-se debaixo da escrivaninha. O  
Peter procura em todos os cantinhos. Por fim, descobre o gato.</p>
<p>Sempre de gatinhas procura apanhar o bicho pelo rabo.</p>
<p>O gato bufa, o Peter suspira. Mouchi senta-se à janela e lambe o pêlo. Como última  
tentativa, o Peter estende-lhe um pedaço de pão. E agora a coisa dá resultado. Mouchi deixa-se &quot;levar&quot;, vai  
atrás dele, e a porta pode fechar-se.</p>
<p>Eu estive a observar todo o espectáculo através de uma frincha. Depois voltei ao meu  
trabalho. Tac, tac, tac!</p>
<p>Bater três vezes, é sinal de que o jantar está pronto!</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 23 de Agosto de 1943</h2>
<p>Querida Kitty:</p>
<p>Continuação do boletim:-O relógio dá as nove horas da manhã. A mãe e a Margot estão  
nervosas.</p>
<p>- Ghut! Pai... Otto, chut... Pim! São nove horas, fecha a torneira!</p>
<p>-Não pises o chão dessa maneira!</p>
<p>É assim que avisam o pai, que ainda está no quarto de banho. às oito e meia ele tem de  
estar no quarto.</p>
<p>E nem mais uma gota de água! Não utilizar o W. C, não andar de um lado para o outro,  
silêncio absoluto. Se ainda não houver gente no escritório, os ruídos ainda ecoam mais fortes no armazém.</p>
<p>Lá em cima, os van Daans abrem a porta e batem três vezes no chão:</p>
<p>-A papinha para a Anne está pronta!</p>
<p>Subo num instante para ir buscar a minha tijelinha de cachorro. Depois ando numa roda  
viva: pentear, despejar o &quot;vaso&quot;, pôr a roupa da cama no sítio. E silêncio, o relógio deu horas!</p>
<p>A sra. van Daan ainda se arrasta de chinelos pelo quarto, e o marido também. Depois não  
se ouve mais nada.</p>
<p>Se cá estivesses podias agora presenciar uma linda cena familiar. Eu começo a ler ou a  
escrever. Também a Margot e os pais gostam de aproveitar esta meia hora de calma para a leitura. O pai pega, já se vê, no  
seu querido Dickens e senta-se na borda da cama que range sempre e que tem colchões que já nem o nome de colchões  
merecem.</p>
<p>Os dois &quot;edredons&quot; que lhe queremos dar, recusa-os :</p>
<p>-Não preciso. Assim estou muito bem.</p>
<p>Uma vez pegado na leitura, já não se interessa por mais nada. Por vezes ri-se, procura ler  
baixinho uma passagem à mãe. Mas ela diz :</p>
<p>-Agora não, por favor. Não tenho tempo.</p>
<p>Ele fica um bocadinho desapontado. Mas logo que descobre outra passagem engraçada,  
tenta novamente:</p>
<p>-Mãezinha, isto tens de ouvir!</p>
<p>A mãe está na cama de armar, lê, costura, faz malhas e estuda um bocado. De repente  
ocorre-lhe uma ideia e ela não pode guardá-la:</p>
<p>-Anne, sabes... Margot, toma nota.</p>
<p>Uns minutos de silêncio. Depois a Margot fecha ruidosamente o seu livro. O pai cerra as  
sobrancelhas num arco muito patusco, mas logo a seguir aparece a ruga de leitura, sinal de que ele está mergulhado no  
livro. A mãe, então, começa a conversar baixinho com a Margot. Curiosa, escuto.</p>
<p>Por fim o Pim também escuta... Nove horas. Pequeno almoço!</p>
<p>Tua Anne.</p>`],

18: [`<h2>Sexta-feira, 10 de Setembro de 1943</h2><p>Querida Kitty:</p>
<p>Quase sempre que te escrevo, alguma coisa aconteceu e, de um modo geral, alguma coisa  
desagradável. Mas desta vez posso contar-te um acontecimento simpático.</p>
<p>Na quarta-feira (8 de Setembro) estávamos todos, às sete horas da tarde, a ouvir rádio.</p>
<p>-Here follows the best news of the whole war. Italy has capitulated!</p>
<p>A Itália capitulou incondicionalmente.</p>
<p>Às oito começou a emissora de Orange :</p>
<p>- Ouvintes! Depois de eu, há uma hora, ter lido as notícias do dia, recebemos a maravilhosa  
notícia da capitulação incondicional da Itália! Deitei ao cesto dos papéis com o maior prazer as notícias ultrapassadas.</p>
<p>Tocaram &quot;God save the king&quot;, &quot;Star spangled banner&quot; e também a  
&quot;Internacional&quot;. A emissora de Orange foi, como de costume, animadora, mas não demasiadamente  
optimista.</p>
<p>Estamos preocupados por causa do sr. Koophuis. Como sabes, gostamos todos muito dele.  
Embora esteja adoentado e tenha dores, e embora não possa comer grande coisa e tenha de ter muita cautela consigo,  
continua sempre animado, amável e admiràvelmente corajoso.</p>
<p>-Quando o sr. Koophuis entra, nasce o Sol - costuma dizer minha mãe e tem muita razão.  
Agora tem de ser operado aos intestinos e não pode aparecer durante quatro semanas. Havias de ver quando se despediu.  
Não como alguém que vai ser operado, mas como se simplesmente saísse para fazer compras.</p>
<p>Tua Anne.</p>
<h2>Quinta-feira, 16 de Setembro de 1943</h2>
<p>Querida Kitty:</p>
<p>À medida que o tempo vai passando, mais mal se vão dando as pessoas umas com as  
outras. Quase já ninguém ousa abrir a boca à mesa (a não ser para meter a comida), pois tudo o que se diz é levado a mal  
ou mal entendido. Eu, por mim, engulo todos os dias &quot;Valeriana-Dispert&quot; por causa das depressões, mas isto  
não me impede de me sentir ainda mais mal disposta no dia seguinte.</p>
<p>Ai, se pudesse rir, só uma vez, rir de todo o coração, seria melhor remédio do que dez  
dessas pastilhas brancas.</p>
<p>Mas já nem sabemos o que é rir assim. Por vezes tenho receio de ficar muito feia depois de  
sair daqui e vejo-me com uma boca comprimida e rugas de preocupações.</p>
<p>Os outros não se sentem melhor do que eu : todos aguardam o Inverno com medo.</p>
<p>Mais uma coisa pouco animadora : um dos homens do armazém, um certo M., ficou  
desconfiado a respeito do anexo. Isto podia não ter grande importância se ele não fosse tão curioso e se se deixasse  
convencer fàcilmente.</p>
<p>Também não sabemos a que ponto é de confiança.</p>
<p>Um dia o sr. Kraler quis ser mais cauteloso: à uma hora menos dez pegou no chapéu e na  
bengala, saiu e entrou na drogaria da esquina. Cinco minutos depois voltou e subiu, com mil cautelas, como um ladrão, a  
escada do anexo. à uma e um quarto quis ir-se embora, mas encontrou a Elli, que o impediu, porque o tal M. estava no  
escritório. Kraler voltou para cima e ficou até à uma e meia. Depois descalçou os sapatos, pegou neles na mão e, em  
meias, caminhou até à porta do sótão, pisou cautelosamente os degraus e depois voltou da rua para o escritório. A Elli que  
conseguira, entretanto, despachar o M. do escritório, veio para avisar o Kraler. Mas este já estava a fazer as suas  
acrobacias na escada. O que terão pensado as pessoas na rua que o viram calçar as botas?</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 29 de Setembro de 1943</h2>
<p>Querida Kitty:</p>
<p>A sra. van Daan faz anos. Oferecemos-lhe, além de - um bónus para queijo, carne e pão,  
um frasco de compota.</p>
<p>O marido, o Dussel e os nossos queridos protectores também lhe ofereceram, além de  
flores, coisas de comer.</p>
<p>Sinal dos tempos!</p>
<p>Esta semana a Elli teve uma crise de nervos. Tem de[ andar sempre de um lado para o  
outro para ir buscar isto ou aquilo, muitas vezes mandam-na trocar as coisas por ela se ter enganado. E se a gente se  
lembra de que ela tem muito que fazer no escritório, que o Koophuis está doente e a Miep na cama por causa de uma  
constipação, que ela própria torceu um pé, que tem aflições por causa do namorado de quem o pai não gosta, não é difícil  
imaginar que já não aguenta mais.</p>
<p>Consolámo-la e pedimos-lhe que, sempre que não tiver tempo para nós, no-lo diga calma e  
friamente. Assim, ao menos, a lista das compras ficará diminuída.</p>
<p>Deve ter havido sarilho com os van Daans. O pai anda furioso, mas não sei porquê. Vai  
haver zaragata, com certeza. Quem me dera estar longe daqui, quem me dera poder fugir! Aquela gente dá cabo de  
nós!</p>
<p>Tua Anne.</p>`],

19: [`<h2>Domingo, 17 de Outubro de 1943</h2><p>Querida Kitty :</p>
<p>Graças a Deus! Ainda está pálido, Koophuis voltou mas já trabalha e está a tentar vender  
roupas dos van Daans.</p>
<p>É uma coisa bem penosa, porque se lhes acabou o dinheiro.</p>
<p>A senhora tem muitas coisas mas não quer desfazer-se delas e um fato do marido custa a  
vender, pois não querem dar o que ele pede. Mas ainda há-de haver trapalhada.</p>
<p>Provàvelmente é o casaco de peles da senhora que vai ser sacrificado! Por causa disso  
houve grande discussão lá em cima, depois seguiu-se um período pacífico e agora só se ouve:</p>
<p>-Oh, meu querido Putti!</p>
<p>Eu já estou meio tonta de tantas discussões e das palavras feias que se ouvem ùltimamente  
na nossa casa honrada.</p>
<p>O pai anda de lábios cerrados e se a gente lhe dirige a palavra, assusta-se como se  
estivesse com medo de algum acontecimento desagradável em que tivesse de intervir.</p>
<p>A mãe, de tanta aflição, tem manchas vermelhas na cara, a Margot queixa-se de dores de  
cabeça, o Dussel não pode dormir, a sra. van Daan lamenta-se todo o dia e eu estou completamente desconcertada. Para  
dizer a verdade : há ocasiões em que me esqueço de quem são os que andam zangados uns com os outros e quem são os  
que já fizeram as pazes. A única distracção é o trabalho, e eu trabalho muito!</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 29 de Outubro de 1943</h2>
<p>Querida Kitty:</p>
<p>Houve &quot;tempestade&quot; lá em cima. Como eu já te contei, eles não têm dinheiro. Um  
dia o Koophuis falou-lhes de um negociante de peles de quem é amigo. O sr. van Daan, então, sempre se resolveu a  
vender o casaco da mulher.</p>
<p>É de pele de coelho e tem dezassete anos de uso. Receberam trezentos e setenta e cinco  
florins por ele. É bem pago.</p>
<p>A sra. van Daan quis guardar o dinheiro para comprar coisas novas mais tarde. O marido  
com muito custo sempre conseguiu convencê-la de que o dinheiro era absolutamente necessário para o sustento. Não  
podes imaginar como ela ralhou, gritou, vociferou e bateu com os pés no chão... E nós cheios de pavor. Estávamos os  
quatro com a respiração suspensa, ao pé da escada, prontos para separar aqueles dois furiosos. Cenas assim são tão  
aflitivas que me fazem chorar, de noite, quando estou na cama, grata, no entanto, por ter uns momentos de solidão.</p>
<p>O sr. Koophuis já tem de ficar novamente em casa.</p>
<p>O estômago não o deixa em paz e ainda não se sabe se a hemorragia acalmou por  
completo. Foi ao contar-nos que se sentia mal e que ia para casa que, pela primeira vez, o vimos deprimido. Eu, por mim,  
não estou doente, só não tenho apetite. Mas estão sempre a dizer-me :</p>
<p>-Estás com mau aspecto.</p>
<p>Tenho de confessar: a minha família esforça-se muito para que eu tenha saúde e robustez.  
Dão-me, alternadamente, glucose, levedura, cálcio, óleo de fígado de bacalhau, para me fazer aguentar. Mas nem sempre  
consigo dominar os meus nervos. É aos domingos que os sinto mais, pois nesses dias reina uma má disposição geral, uma  
espécie de sonolência pesada como chumbo. Não se ouvem ruídos lá fora e qualquer coisa parece estar para  
acontecer.</p>
<p>É como se pesos grandes me puxassem. Uma voz gritasse na escuridão, insondável.</p>
<p>Indiferentes, até o pai, mas Nessa altura todos me são muito amigos, sobretudo a mãe e a  
Margot. Ando por toda a casa, de um quarto para o outro escada acima, escada abáixo. Sinto-me como um pássaro a quem  
cortaram as asas e bate contra as grades da gaiola estreita.</p>
<p>Em mim soa como que um grito: para fora! Tenho saudades, -Quero sair. Sair daqui, para o  
ar livre, quero poder rir à vontade!Não há resposta! Mas sei que esses gritos não têm poder, e deito-me na cama para  
matar estas horas tão terrivelmente silenciosas e cheias de angústia.</p>
<p>Tua Anne</p>`],

20: [`<h2>Quarta-feira, 9 de Novembro de 1943</h2><p>Querida Kitty :</p>
<p>O pai, cuja constante preocupação é a de nos distrair e, ao mesmo tempo, de nos cultivar,  
mandou vir o prospecto de um instituto que dá lições por correspondência. A Margot já folheou o calhamaço por três vezes  
mas ainda não ,encontrou o que queria. Julgava ela que tinha de pagar o curso com o seu dinheiro da semana e, por isso,  
achava tudo demasiado caro. Mas o pai mandou vir uma lição para experimentarmos : latim para principiantes. A Margot  
atirou-se ao trabalho e mandou depois vir o curso completo.</p>
<p>Embora eu gostasse de aprender latim, acho-o ainda difícil de mais.</p>
<p>Mas para que eu também possa aprender alguma coisa nova, o pai pediu ao sr. Koophuis  
que procurasse uma bíblia para crianças. Quer que eu fique a conhecer o Novo Testamento.</p>
<p>-Queres dar à Anne uma bíblia para a festa de Ghanuca? - perguntou Margot admirada.</p>
<p>-Sim... enfim... acho que o S. Nicolau será a melhor ocasião para isso. Jesus não liga lá  
muito bem com a festa de Ghanuca - foi a resposta do pai.</p>
<p>Estragou-se o aspirador. Agora tenho eu de limpar o tapete, todas as noites, com uma  
escova velha. E isto dentro de um quarto com as janelas fechadas, com a luz eléctrica acesa, onde está um calor  
sufocante.</p>
<p>-Isto não acaba bem-pensei de mim para mim.</p>
<p>A mãe começou a ter dores de cabeça por causa do pó que se fixava no quarto. O pó, ao  
fim e ao cabo, não desaparecia e o pai achava que toda a sala tinha um aspecto sujo. A ingratidão é a paga de muita  
gente.</p>
<p>Agora há menos discussões, só o Dussel é que anda zangado com os van Daans. Quando  
nos fala da sra. van Daan diz &quot;a vaca estúpida&quot; ou &quot;a velha cabra.&quot;, e ela, em contrapartida,  
chama-lhe a ele, que tem um curso superior e é imfalível, &quot;a solteirona&quot; ou &quot;o solteirão chéché&quot;! Um  
burro a chamar burro a outro!</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 8 de Novembro de 1943</h2>
<p>Querida Kitty:</p>
<p>Se te desses ao trabalho de ler todas as minhas cartas umas atrás das outras, verias que  
as escrevi com as mais diversas disposições. É aborrecido ser-se dependente da disposição de momento, aqui no anexo.  
Mas isto não acontece só comigo, é o mesmo com todos os outros.</p>
<p>Depois de ter lido um livro e ainda estar debaixo de uma impressão muito forte, tenho de me  
meter, a mim própria, na ordem antes de aparecer a alguém, senão eram capazes de me acharem maluquinha. Decerto já  
estás a perceber que me encontro de novo num período de abatimento e de falta de coragem. E nem posso explicar  
porquê, pois não há nenhuma razão especial. Creio tratar-se de uma certa cobardia que nem sempre consigo vencer. Hoje,  
à tardinha, quando a Elli estava aqui, tocaram a campainha permanentemente e com força. Fiquei logo pálida, tive dores de  
barriga, palpitações e muito medo. De noite, deitada na cama, tenho visões terríveis. Vejo-me na prisão, sòzinha, sem meu  
pai e minha mãe. Por vezes ando a vaguear por qualquer parte, não sei onde, ou vejo o anexo a arder, ou eles vêm, de  
noite, para nos buscar. Sinto tudo isto como se fosse realidade e a ideia de que me vai acontecer alguma catástrofe não me  
larga.</p>
<p>A Miep diz, por vezes, que tem inveja de nós por termos aqui calma e sossego. Em  
princípio, ela podia ter razão, mas não se lembra de que vivemos sempre com medo. Não consigo já imaginar que o Mundo  
possa voltar a ser para nós o que era dantes. Digo muitas vezes : &quot;Depois da guerra&quot;. Mas digo-o como se se  
tratasse de um castelo no ar e não de um tempo que se tornará, algum dia, para mim realidade. Quando penso na nossa  
vida em casa, na escola, com todas as suas alegrias e sofrimentos, em tudo o que era &quot;antigamente&quot;; tenho a  
sensação de não ter sido eu quem viveu essas coisas mas sim uma estranha, alguém totalmente diferente.</p>
<p>Vejo-nos a nós aos oito do anexo, numa pequena , nuvem, clara e azul, no meio de outras  
nuvens, pesadas e escuras. O nosso lugar ainda é seguro, mas as nuvens estão a ficar cada vez mais densas e o círculo  
que nos separa do perigo tão próximo, vai-se apertando. Por fim ficamos todos de tal maneira envolvidos na escuridão que,  
com o desejo desesperado de encontrar uma saída, esbarramos uns contra os outros. Olhamos para baixo onde os homens  
lutam, olhamos para cima onde há felicidade e paz. Mas estamos isolados por uma massa grossa e impenetrável que nos  
barra todos os caminhos e nos encerra, como um muro invencível, um muro que nos destruirá quando a hora soar. E eu só  
posso clamar e suplicar: - Oh, círculo, círculo, alarga-te e abre-te para nós!</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 11 de Novembro de 1943</h2>
<p>Ode à minha caneta de tinta permanente &quot;In memoriam&quot;</p>
<p>A minha caneta foi para mim, sempre, uma coisa preciosa. Apreciava-a imenso por ter um  
bico grosso e redondo, porque só escrevo bem com bicos assim. Ela viveu uma vida de caneta bem longa e interessante,  
que vou aqui descrever.</p>
<p>Quando fiz nove anos, chegou (embrulhada em algodão em rama) como &quot;amostra sem  
valor&quot;. Foi a avòzinha que, nessa altura, ainda vivia em Aachen, que me enviou uma prenda tão generosa. Estava eu  
precisamente deitada na cama, com gripe, e lá fora uivava o vento de Fevereiro.</p>
<p>A gloriosa caneta vinha num estojo de couro vermelho.</p>
<p>Mostrei-a, logo que pude, a todas as amigas e conhecidos.</p>
<p>Eu, Anne Frank, possuidora orgulhosa de uma caneta de tinta permanente!</p>
<p>Quando fiz dez anos, recebi licença de a levar para a escola, e a professora deixou-me  
escrever com ela.</p>
<p>No ano seguinte o meu tesouro teve de ficar em casa porque a directora de ciclo, no liceu,  
só permitia canetas vulgares.</p>
<p>Quando aos doze anos entrei no Liceu judaico, deram-me um estojo novo com duas  
divisões. Uma era para a lapiseira. Esse estojo tinha um fecho &quot;èclair&quot; e era muito vistoso.</p>
<p>Quando fiz treze, a caneta veio comigo para o anexo e foi a minha companheira fiel quando  
te escrevia a ti ou quando trabalhava. Agora que tenho catorze, chegou ao fim da sua existência. Na sexta-feira saí do meu  
quarto para escrever junto dos outros, na mesa da sala. Mas afastaram-me sem piedade, pois a Margot e o pai estavam a  
estudar latim. A caneta ficou em cima da mesa. A Anne teve de contentar-se com um cantinho onde a fizeram &quot;dar  
lustro&quot; aos feijões, quer dizer, limpar feijão vermelho que tinha bolor.</p>
<p>às seis menos um quarto varri o chão e deitei o lixo com os restos dos feijões no fogão.  
Ergueu-se uma chama colossal e eu fiquei satisfeita por isso, porque o fogo tinha estado quase apagado. &quot;Os  
latinos&quot; acabaram de estudar e eu recebi licença para voltar à mesa e continuar o meu trabalho. Mas a caneta não  
estava lá. Procurei-a por todos os lados, a Margot ajudou-me, depois também ajudou a mãe, o pai e o Dussel, mas a minha  
amiga fiel tinha desaparecido sem deixar vestígios.</p>
<p>- Se calhar, deitaste-a ao fogão com os feijões - disse a Margot.</p>
<p>- Não posso acreditar - disse eu.</p>
<p>Mas quando a hora do jantar chegou sem a caneta ter regressado, já não tínhamos dúvidas:  
ardeu! E o celulóide que arde tão bem! A triste suposição confirmou-se, quando na manhã seguinte o pai encontrou o  
&quot;clip&quot; na cinza.</p>
<p>Do bico de ouro não restava nada.</p>
<p>-Provàvelmente derreteu com o lixo-disse o pai.</p>
<p>Só me resta uma consolação : a minha caneta foi cremada, precisamente como eu queria  
que um dia me fizessem!</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 17 de Novembro de 1943</h2>
<p>Querida Kitty:</p>
<p>Modificações tremendas. Em casa da Elli há difteria e ela não pode vir cá durante seis  
semanas por causa do contágio! Agora tudo se tornou complicado cá em casa no que respeita aos víveres e às outras  
compras, não falando no nosso desgosto pessoal. O sr. Koophuis ainda está de cama e há três semanas que está só a  
leite e a papas.</p>
<p>O Kraler tem imenso que fazer! A Margot tinha enviado ao professor os seus exercícios de  
latim que vieram devolvidos com as dvidas correcções. O professor parece ser um homem amável e também espirituoso e,  
com certeza, está todo contente por ter uma aluna tão boa. A correspondência fáz-se em nome da Elli.</p>
<p>O Dussel anda sorumbático. Ninguém sabe porquê.</p>
<p>Aquilo começou por ele nem falar com o sr. van Daan nem com a senhora. Todos nós  
reparámos nisso. Passados uns dias, a mãe falou a sós com ele, dizendo-lhe que não era bom arranjar sarilhos. A sra. van  
Daan era capaz de tomar a coisa muito a peito. O Dussel respondeu que o sr. van Daan tinha começado a ignorá-lo e a  
deixar de lhe falar e agora não era ele, Dussel, quem havia de romper o silêncio. Mas.ontem, 16 de Novembro, fazia um  
ano que o Dussel entrou cá no anexo. Por esse motivo ofereceu flores à minha mãe. A sra. van Daan já tinha, ùltimamente,  
dado a entender que, em tais ocasiões, as pessoas costumam oferecer alguma coisa. E, agora, ele ignorou-a  
completamente.</p>
<p>Em vez de agradecer o altruísmo com que foi cá recebido, calou-se.</p>
<p>Quando eu lhe perguntei, da parte da manhã, se lhe devia dar os parabéns ou antes os  
pêsames, respondeu-me que tanto lhe fazia. A mãe, que queria fazer o papel de anjo da paz, não conseguiu nada e, assim,  
tudo ficou na mesma.</p>
<p>O homem é grande de espírito Mas mesquinho nas acções.</p>
<p>Tua Anne</p>
<h2>Sábado, 27 de Novembro de 1943</h2>
<p>Querida Kitty:</p>
<p>Ontem à noite, antes de adormecer, tive uma visão nítida: a minha amiga Lies Estava diante  
de mim, coberta de trapos e com o rosto escaveirado. Com os seus grandes olhos contemplou-me, triste e acusadora,  
como se quisesse dizer :</p>
<p>-Anne, porque é que me abandonaste? Ajuda-me!</p>
<p>Salva-me deste inferno.</p>
<p>Mas eu não posso ajudá-la. Os outros têm de sofrer e de morrer e eu não passo de um  
espectador; só posso pedir a Deus que não os deixe morrer e que me devolva os meus amigos. Sim, foi precisamente a  
Lies que eu vi e isto compreende-se. Sempre a julguei mal, eu era ainda muito infantil e não podia compreender as suas  
preocupações.</p>
<p>Ela gostava da sua nova amiga e tinha receio que eu lha roubasse. Ai, como deve ter  
sofrido! Sei-o agora, pois já conheço melhor tais ressentimentos!</p>
<p>Por vezes pensava nela passageiramente, depois mergulhava com egoísmo nos meus  
divertimentos e preocupações.</p>
<p>Não procedi bem e foi por isso que ela olhou para mim assim, de rosto pálido e de olhos  
suplicantes, tão tristes.</p>
<p>Oh!... se pudesse dar-lhe uma ajuda!</p>
<p>Oh! Meu Deus, tenho aqui tudo o que necessito e ela foi arrastada para o destino mais duro  
que há! Tem sido pelo menos tão crente como eu, e só desejava o bem. Porque é que fui eleita para viver e ela para  
morrer? Qual é a diferença entre nós? Porque é que estamos tão longe uma da outra?</p>
<p>Para ser franca, tinha-me esquecido dela há quase um ano. Não esquecido por completo,  
isso não, mas não pensava nela de uma certa maneira, assim, como a vi agora na sua miséria.</p>
<p>Oh! Lies, quem me dera que te pudesse acolher, que tu sobrevivesses a esta guerra,  
porque queria remediar um pouco o mal que te causei.</p>
<p>Mas quando eu estiver em condições de a ajudar, já ela não precisará. Será possível que  
ainda se lembre de mim? E que sentirá ela?</p>
<p>Meu Deus, ajuda-a, não a deixes ficar tão só. Faz-lhe saber do meu amor e da minha  
compaixão por ela. Pode ser que assim lhe dês força para resistir. Não posso pensar mais nisso. Não consigo  
desprender-me da visão. Sempre e sempre vejo os grandes olhos dela fixos em mim Não sei se a Lies traz em si uma fé  
muito forte ou se a obrigaram a tê-la. Não sei, nunca lho perguntei. Oh!</p>
<p>Lies, Lies, se te pudesse ir buscar, se pudesse dividir contigo o que aqui tenho! É tarde  
demais! não Poder ser eu! ninguém, não posso remediar o mal que as pessoas fazem. Nunca me esquecerei da Lies e  
hei-de rezar por ela.</p>
<p>Tua Anne</p>`],

21: [`<h2>Quarta-feira, 22 de Dezembro de 1943</h2><p>Querida Kitty:</p>
<p>Uma gripe bastante séria impediu-me de te escrever mais cedo. É quase uma catástrofe  
estar-se doente aqui.</p>
<p>Quando me vinha a vontade de tossir, metia-me depressa debaixo dos cobertores e tentava  
acalmar a garganta, mas o resultado era que sempre a comichão aumentava e só abrandava com leite e mel ou com  
pastilhas. Só ao lembrar-me dos tratamentos que tive de suportar, fico quase tonta. Suores, compressas no pescoço,  
ligaduras húmidas e secas no peito, bebidas quentes, estar deitada sem me mexer, gargarejar, pincelar, almofada eléctrica,  
botijas e, de duas em duas horas, ver a temperatura. E queriam que eu, assim, ficasse bem! O pior de tudo era que o  
Dussel fazia de médico, encostando a cabeça com brilhantina ao meu peito para verificar se havia ruídos lá dentro. Não só  
os seus cabelos me faziam muitas cócegas como também tinha vergonha dele, apesar de ser um facto irrefutável ele ter  
tirado, há trinta anos, o curso de medicina e possuir o diploma de doutor. Mas o que tem ele que procurar no meu coração?  
Eu não o amo. O que se passa no meu coração não é ele que o pode descobrir. Acho mas é que ele devia, antes de mais  
nada, mandar fazer uma limpeza aos ouvidos, pois estou certa de que ouve bastante mal!</p>
<p>Mas não falemos mais na minha doença! Estou bem agora; cresci um centímetro e aumentei  
um quilo. Ainda estou pálida mas cheia de actividade e contente por poder voltar a trabalhar.</p>
<p>Não tem havido coisas novas. Ao contrário do que costuma suceder, todos se entendem  
bem cá em casa.</p>
<p>Não tem havido zangas. Há, pelo menos, seis meses que não conhecíamos um ambiente  
tão pacífico.</p>
<p>A Elli ainda não pode vir cá.</p>
<p>No Natal vamos receber uma ração suplementar: azeite, doces e geleia de nabo para pôr no pão. A minha prenda é bonita e corresponde aos  
tempos que correm: um broche feito de uma moeda de dois cêntimos e meio, tão polidinha que resplandece. O Dussel  
pediu à Miep que fizesse uma torta para a minha mãe e para a sra. van Daan, e ela já tem tanto que fazer! Tenho também  
uma prenda para a Miep e a Elli: há perto de dois meses que venho poupando o açúcar que devia deitar sobre a papa, e  
agora o sr. Koophuis vai levá-lo para mandar preparar doces.</p>
<p>O tempo está mole, o fogão deita fumo, a comida pesa-nos no estômago, o que é aliás  
comprovado por certos ruídos pouco estéticos.</p>
<p>A guerra não ata nem desata... Disposição abaixo de zero!</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 24 de Dezembro de 1943</h2>
<p>Querida Kitty:</p>
<p>Já te tenho dito muitas vezes que o ambiente aqui depende da nossa disposição. E eu, a tal  
respeito, estou cada vez pior. Pode aplicar-se-me o dito: &quot;alegria celeste, tristeza mortal&quot;. Sinto uma  
&quot;alegria celeste&quot; quando me lembro como estou bem aqui em comparação com outros judeus. &quot;Tristeza  
mortal&quot;... invade-me, sim, quando ouço contar que a vida lá fora continua. Hoje esteve cá a sra. Koophuis e contou  
que a sua filha Corrie faz desporto, passeia numa canoa com amigos e representa num teatro de amadores. Não sou  
invejosa, mas quando oiço falar em tais coisas, apetecia-me tomar parte nelas, pelo menos uma vez; queria divertir-me  
como todos os outros, não ter preocupações, ser feliz, rir! Justamente nesta época tão bonita, em que há as férias do Natal  
e do Ano Novo estamos aqui como párias. Bem sei que não devia escrever tais coisas, por parecer que sou ingrata e  
exagerada. Mas mesmo que tu penses agora mal de mim... não posso guardar tudo isto e cito mais uma vez aquela frase  
que escrevi no princípio: &quot;O papel é paciente!&quot;</p>
<p>Quando chega alguém de fora, ainda com a frescura do cheiro a vento nas roupas e com a  
cara vermelha do frio, apetecia-me enterrar a cabeça nos cobertores para não pensar sempre no mesmo : &quot;Quando é  
que poderemos ir lá para fora e respirar o ar e a liberdade?!&quot; Mas não me posso esconder, pelo contrário, tenho de  
me mostrar direitinha e corajosa e, contudo, os pensamentos não se deixam dominar, vêm e tornam a vir. Acredita, quando  
se está fechada há ano e meio, chegam momentos em que se julga não se poder suportar mais. Ainda que eu seja injusta e  
ingrata, não sou capaz de negar o que sinto! Apetecia-me dançar, assobiar, andar de bicicleta, ver o Mundo, gozar a minha  
juventude, ser livre. Digo-te isto a ti, mas não o posso dizer a mais ninguém porque se todas as oito pessoas cá no anexo  
se lamentassem e mostrassem caras infelizes, aonde iríamos então parar?</p>
<p>Por vezes penso: &quot;Será possível que alguém me compreenda Ou só vêem em mim a  
adolescente que não quer outra coisa senão divertir-se?&quot; Não sei e não posso falar sobre isto com ninguém, pois era  
capaz de desatar a chorar. Todavia...</p>
<p>Seria um alívio poder chorar uma vez à vontade A despeito de todas as teorias, de todos os  
esforços, sinto a cada passo a falta de uma mãe que me compreenda. Por isso penso sempre, ao trabalhar ou ao escrever,  
que quero ser, mais tarde, para os meus filhos, aquela mãe que eu desejava ter, essa &quot;mamsi&quot; que não arranja  
logo uma tragédia com tudo o que se diz sem intenção, mas que toma antes a sério o que preocupa os seus filhos  
intimamente. Estou a sentir que não me exprimo como queria, mas a palavra &quot;mamsi&quot; já diz tudo. Sabes o que  
descobri para chamar a mãe com um nome parecido com Mamsi? Chamava-lhe muitas vezes &quot;Mansa&quot; e depois  
ficou Mansi, o que é uma &quot;Mamsi&quot; incompleta. Muito gostava eu de poder honrá-la com mais um tracinho no  
&quot;n. Mas a mãe de nada suspeita, o que é bom, porque se soubesse ficaria infeliz.</p>
<p>Basta! Já aliviei o coração da minha &quot;tristeza mortal&quot;, e sinto-me melhor.</p>
<p>Tua Anne</p>
<h2>Sábado, 25 de Dezembro de 1943</h2>
<p>Querida Kitty:</p>
<p>Hoje, primeiro dia de Natal, tenho de pensar constantemente no Pim e naquilo que ele me  
contou, o ano passado, do seu primeiro grande amor. Nessa altura não penetrei tão bem como hoje o significado das suas  
palavras.</p>
<p>Oh! se ele me falasse outra vez naquilo, mostrar-lhe-ia que agora o compreendo.</p>
<p>Creio que o Pim, que tantos segredos conhece dos outros, precisou de desabafar, pelo  
menos uma vez; pois o Pim não costuma falar de si e suponho que nem a Margot suspeita do que ele sofreu.</p>
<p>Pobre Pim, a mim não engana ele, eu sei que ainda não se pôde esquecer! Nunca se  
poderá esquecer. É uma pessoa equilibrada. Oxalá eu seja parecida com ele, mas sem precisar de passar pelo que ele  
passou.</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 27 de Dezembro de 1943</h2>
<p>Querida Kitty:</p>
<p>Pela primeira vez tive uma prenda pelo Natal. As raparigas, o Koophuis e o Kraler  
fizeram-me uma surpresa encantadora. A Miep fez um bolo enfeitado com &quot;Papel&quot;, conseguiu arranjar meio quilo  
de bolachas de antes da guerra. Além disso, o Peter, a Margot e eu recebemos um frasco de &quot;yogurth&quot; e os  
adultos uma garrafa de cerveja.</p>
<p>Tudo estava embrulhado com graça e todos os pacotinhos traziam escrita uma quadra.</p>
<p>Os dias de Natal passaram tão depressa!</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 29 de Dezembro de 1943</h2>
<p>Querida Kitty:</p>
<p>Ontem à noite, estive muito triste. Tive a visão da avòzinha e da Lies! Avòzinha, querida  
avòzinha! Não compreendemos bem quanto ela sofria. Só pensava em nós, mostrando-se sempre muito compreensiva em  
face dos nossos problemas. Sofria de uma grave doença.</p>
<p>Sabê-lo-ia ela e nunca falou nisso para não nos afligir?</p>
<p>A avòzinha era sempre amável e boa e ninguém a procurava sem ouvir um conselho ou uma  
consolação, ou sem receber uma ajuda. Mesmo quando eu estava insuportável, a avòzinha encontrava sempre para mim  
uma desculpa.</p>
<p>Avòzinha, dize, gostaste muito de mim ou também não me compreendeste? Oh! Não  
sei.</p>
<p>Como a avòzinha se deve ter sentido só, tão só, embora estivéssemos todos junto dela.  
Sim, porque uma pessoa pode sentir-se só, mesmo no meio de muita gente amiga, se souber que não ocupa um lugar  
muito especial no coração de alguém. E a Lies? Ainda viverá? O que estará a fazer?</p>
<p>Meu Deus, não a deixes morrer, faze com que ela volte para junto de nós. Pensando em ti,  
Lies, compreendo qual podia ter sido o meu destino e ponho-me muitas vezes no teu lugar! Mas, então, porque é que me  
afligem tanto as condições em que vivo aqui no anexo? Não devia eu sentir-me alegre e satisfeita, excepto quando penso  
na Lies e nos outros que sofrem como ela?</p>
<p>Sou egoísta e cobarde! Não sei porque é que os meus sonhos e pensamentos só giram à  
volta das coisas tristes, até quase me apetecer gritar. De certo não tenho bastante confiança em Deus! Afinal Ele deu-me  
tanta coisa que não mereço e eu só faço asneiras.</p>
<p>&quot;Quando pensamos no próximo, devíamos chorar&quot;.</p>
<p>A dizer a verdade não devíamos fazer mais nada do que chorar. Resta-nos pedir a Deus  
que faça um milagre e que salve aquela pobre gente!</p>
<p>E eu rezo do fundo do meu coração.</p>
<p>Tua Anne.</p>`],

22: [`<h2>Domingo, 2 de Janeiro de 1944</h2><p>Querida Kitty:</p>
<p>Hoje de manhã, ao folhear o meu diário, encontrei várias cartas em que falo da mãe, num  
tom impulsivo, quase irado. Assustei-me e perguntei a mim própria:</p>
<p>&quot;Isto és tu, a Anne, que fala assim com tanto ódio?&quot;</p>
<p>Com o livro aberto na mão, fiquei algum tempo sentada a tentar descobrir a razão desse  
ódio, dessa ira. Fiz os possíveis para compreender a Anne daqueles dias e para a desculpar, pois a minha consciência não  
acalma enquanto eu não conseguir explicar-te como foi que cheguei a fazer tamanhas acusações. Sofria e ainda sofro de  
depressões e, nestas alturas, sou-falando em linguagem figurada-como um mergulhador debaixo de água, que vê tudo  
deformado.</p>
<p>Via tudo subjectivamente e nem tentava reflectir com calma sobre aquilo que os outros  
diziam. Se o tivesse feito, teria, com certeza, compreendido melhor o sentido dos argumentos dos meus antagonistas e  
teria procedido de outro modo e sem magoar ninguém com o meu temperamento impetuoso.</p>
<p>Só me via a mim, fechava-me na minha concha, não fazia caso dos outros e sentia alívio ao  
confiar ao papel as minhas alegrias, a minha troça e, também, a minha tristeza. Este diário é para mim de grande valor por  
se ter tornado o meu livro de memórias. Mas muitas das suas páginas podia agora riscá-las ou escrever por baixo &quot;já  
passou&quot;.</p>
<p>Muitas vezes ficava furiosa com a mãe e ainda agora me acontece o mesmo. Ela não me  
compreendia, é uma verdade, mas eu também não a compreendia. Sou sua filha e ela é boa e carinhosa para mim. Mas  
como lhe criava tantas vezes situações desagradáveis, é compreensível que me ralhasse. Pois, por isso mesmo e ainda por  
tantas coisas que ela sofria, é que não pôde deixar de ficar nervosa e irritada. Eu não compreendia isso, ofendia-a, era  
insolente e agressiva e então ela ficava triste. E assim havia sempre entre nós algum mal-entendido e desgostos, o que  
não era agradável para nenhuma de nós. Mas tudo isso passou!</p>
<p>Que eu não quisesse admitir essas coisas e tivesse tido pena de mim própria, também se  
compreende. As minhas atitudes eram arrebatamentos de maldade, das quais, numa vida normal, me teria libertado de  
maneira completamente diferente e sem testemunhas... Teria, por exemplo, sózinha no meu quarto, batido fortemente com  
os pés no chão, desabafando sem que ela percebesse o que se passava no meu coração.</p>
<p>Aquele tempo em que a mãe chorava por minha causa já passou. Sou mais sensata, mais  
razoável e os nervos da mãe também acalmaram. A maior parte das vezes calo-me quando ela me arrelia, e ela faz o  
mesmo. Assim, as coisas córrem bastante melhor. Amar a mãe incondicionalmente, como fazem tantas crianças, não me é  
possível; qualquer coisa em mim se revolta contra isso. Mas acalmo a minha consciência com a convicção de que sempre é  
melhor escrever estas coisas no papel do que magoar os sentimentos de minha mãe.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 5 de Janeiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Hoje vou confiar-te duas coisas o que, talvez, me leve um pouco de tempo. Mas é-me  
indispensável desabafar, e só contigo gosto de o fazer, pois tu guardas silêncio, aconteça o que acontecer. Em primeiro  
lugar, trata-se da mãe.</p>
<p>Bem sabes que me tenho queixado dela muitas vezes e que me tenho esforçado sempre por  
ser boa para ela.</p>
<p>De repente descobri o que não me agrada na mãe. Ela própria tem-nos dito que vê em nós  
antes amigas do que filhas. Isso é uma coisa bonita, mas uma amiga não pode substituir a mãe. Eu queria ter na mãe um  
exemplo, um modelo a seguir, queria poder erguer para ela os olhos.</p>
<p>Pressinto que a Margot pensa de outra maneira a tal respeito e que nunca podia  
compreender as minhas ideias, e o pai evita falar no assunto. Na minha imaginação uma mãe tem de ser, antes de mais  
nada, alguém com muito tacto, principalmente quando se trata dos filhos. Não deve fazer como faz minha mãe, que se ri  
quando eu choro lágrimas que não são de dor física mas de dor íntima.</p>
<p>Há uma coisa-pode parecer incompreensível-que nunca lhe perdoarei. Quando um dia tive  
de ir ao dentista, a mãe e a Margot acompanharam-me e acharam bem que eu levasse a bicicleta. Mas quando, acabado o  
tratamento, estávamos à porta do dentista, as duas disseram-me que ainda iam ao centro da cidade fazer compras e ver  
umas coisas-já não sei bem o que era. Eu queria ir também, mas não me deixaram por causa da bicicleta. Fiquei furiosa e  
as lágrimas vieram-me aos olhos, mas as duas começaram a rir. Então perdi a cabeça e, no meio da rua, deitei-lhes a  
língua de fora. Por acaso passou uma mulher do povo que me olhou horrorizada. Fui sózinha para casa e chorei muito.</p>
<p>É estranho, mas essa ferida que a mãe, há tanto tempo, me causou, arde ainda todas as  
vezes que penso nisso ou quando me zango com a mãe.</p>
<p>Falar do segundo assunto custa-me muito, pois trata-se de mim própria. Li ontem um artigo  
de Sis Heyster sobre o corar. Aquilo parecia ser escrito para mim, embora eu não core tão fàcilmente. Mas o resto  
aplica-se-me perfeitamente.</p>
<p>Diz ela que uma rapariga, ao entrar na puberdade, fica mais calma e mais pensativa e que  
se debruça sobre o milagre do seu corpo. É precisamente o que acontece comigo ùltimamente e agora até tenho vergonha  
da Margot e dos pais. Mas a Margot que, em outras ocasiões, é muito mais acanhada do que eu, não faz cerimónias com  
estas coisas.</p>
<p>Dou-me conta das transformações exteriores do meu corpo e, mais ainda, daquilo que está  
a ficar tão diferente no meu íntimo. E como não falo sobre isto com ninguém, tento compreender sòzinha.</p>
<p>De todas as vezes que tenho o &quot;incómodo&quot; - e já me veio três vezes - tenho a  
sensação, apesar das dores e de tudo o que é desagradável e repugnante, de trazer comigo um segredo muito delicado.  
Alegro-me quando vivo de novo este meu segredo. Diz Sis Heyster que as raparigas da minha idade ainda não têm  
segurança mas que pouco a pouco se vão revelando e começam a ter ideias, pensamentos e hábitos próprios. Vim para o  
anexo quando tinha treze anos e, por isso, fui obrigada a reflectir mais cedo sobre o Mundo e a fazer a descoberta de mim  
mesma como de um ser humano que deseja ser independente.</p>
<p>Por vezes, de noite, não posso deixar de tocar nos meus seios e de sentir o bater calmo e  
seguro do meu coração.</p>
<p>Já antes de vir para aqui sentia, inconscientemente, coisa parecida, pois uma vez, quando  
dormi com uma amiga minha, perguntei-lhe se, como prova de amizade, não podíamos tocar nos seios uma da outra, mas  
ela recusou-se. Eu gostava de lhe dar beijos e beijei-a muitas vezes.</p>
<p>Sempre que vejo uma figura de mulher nua, como, por exemplo a Vénus, fico como em  
êxtase. É uma coisa tão bela que tenho de me dominar para não desatar a chorar!</p>
<p>Ai! Quem me dera ter uma amiga!</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 6 de Janeiro de 1944</h2>
<p>Querida Kitty:</p>
<p>O meu desejo de falar com alguém tornou-se tão forte, ùltimamente, que escolhi, não sei  
porquê, o Peter como vítima. Quando eu estava lá em cima com ele sentia-me bem. Mas como é modesto e incapaz de  
pedir a alguém para o deixar em paz, mesmo se se sentir molestado, eu nunca tinha coragem de me demorar com receio de  
que me pudesse achar aborrecida.</p>
<p>Discretamente, faço agora tentativas para ficar mais um bocadinho para conversarmos e  
ontem, por acaso, houve um pretexto bom, pois o Peter tem a mania das palavras cruzadas e se pudesse não faria mais  
nada em todo o dia. Ajudei-o, e assim ficámos à mesa, um em frente do outro, ele na cadeira, eu no divã.</p>
<p>Sempre que eu olhava para os seus olhos escuros e observava o sorriso bailar-lhe à volta  
da boca, tinha uma sensação estranha. Adivinhava-lhe o íntimo. Lia-lhe no rosto a insegurança, o desamparo e, ao mesmo  
tempo, um laivo de certeza de se saber homem. O seu embaraço enterneceu-me e precisei de o olhar de novo nos  
olhos.</p>
<p>Apeteceu-me pedir-lhe :</p>
<p>- Conta-me tudo o que sentes e não tenhas medo de que eu seja indiscreta. Contigo nunca  
o serei!</p>
<p>Mas a tarde foi passando e nada de especial aconteceu a não ser que lhe falei a respeito  
do corar mas, evidentemente, não lhe disse tudo o que escrevi aqui. Só falei nisso por causa dele, para ele sentir mais  
segurança. quando de noite, na cama, pensei em tudo aquilo, a situação parecia-me desagradável e achei então um  
exagero da minha parte cobiçar assim as boas graças do Peter. Acho esquisito a gente tentar tanta coisa para satisfazer  
um desejo. Dou-me a mim como prova.</p>
<p>Resolvi procurar mais vezes o Peter e fazê-lo falar. Não julgues que estou apaixonada por  
ele, não, nem pensar nisso.</p>
<p>Se os van Daans, em vez de um filho, tivessem uma filha, eu faria as mesmas tentativas  
para conseguir a sua amizade.</p>
<p>Hoje de manhã acordei às sete horas e lembrei-me nitidamente do que sonhei. Estava eu  
sentada à mesa, em frente do Peter... Folheávamos um livro ilustrado.</p>
<p>O sonho tinha sido tão nítido que até ainda me lembro das gravuras. Mas não acabou aqui.  
Os nossos olhares encontravam-se e eu via os olhos do Peter, tão belos, de um castanho aveludado. Depois o Peter disse,  
baixinho e carinhoso :</p>
<p>-Se eu soubesse, já te teria procurado há mais tempo.</p>
<p>Virei-me bruscamente porque estava muito comovida.</p>
<p>Então senti a face do Peter junto da minha e senti-me tão bem, ai! tão bem!</p>
<p>Quando acordei parecia-me sentir ainda o seu contacto e tive a sensação de que os seus  
queridos olhos castanhos tinham penetrado até ao fundo do meu coração e que tinham compreendido quanto eu gostava  
dele, e ainda gosto. Os meus olhos encheram-se de lágrimas, fiquei triste por ele estar tão longe de mim, mas também  
fiquei contente por sentir com tanta força que ainda gosto do Peter. Estranho: tenho aqui visões tão nítidas. Uma noite  
apareceu-me a avó paterna com tanta nitidez que lhe consegui ver as rugazinhas aveludadas na pele. Depois veio a avó  
materna como anjo da guarda e depois a Lies, que para mim é o símbolo da infelicidade das minhas amigas e de todos os  
judeus. Ao rezar por ela incluo sempre os judeus e todos os homens perseguidos e infelizes.</p>
<p>E agora apareceu-me o Peter, o meu querido Peter!</p>
<p>Nunca o tinha visto tão claramente na minha imaginação.</p>
<p>Não tenho dele nenhuma fotografia, nem é preciso, pois tenho-o bem gravado na memória!  
Como é bom e simpático!</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 7 de Janeiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Que estúpida que sou. Nunca me lembrei de te contar a história dos meus admiradores.</p>
<p>Ainda eu era pequena, andava no jardim-escola, quando simpatizei com Karl Samson. Ele já  
não tinha pai e vivia com a mãe em casa de uma tia. Bobby, o filho desta, era um rapazinho esperto, esbelto e moreno, que  
conseguia sempre chamar a atenção sobre si mais do que o Karl, gordinho e patusco. Mas eu não me importava com o  
aspecto exterior e fui amiga do Karl, durante anos.</p>
<p>Éramos camaradas autênticos.</p>
<p>Depois o Peter Wessel entrou na minha vida e foi a minha primeira paixão. Ainda nos  
vejo-de mãos dadas - a correr pelas ruas, ele com um fato de linho, eu com um vestido de Verão.</p>
<p>Quando ele foi para o liceu passei eu para a última classe da escola primária. Ia buscar-me  
à escola ou eu ia buscá-lo a ele ao liceu. O Peter era um lindo rapaz, alto, esbelto, bem feito, com uma cara calma, séria e  
inteligente.</p>
<p>Tinha cabelo escuro, a pele tostada, grandes e belos olhos castanhos e um nariz afilado.  
Do que eu mais gostava nele era do sorriso que lhe dava um ar de maroto.</p>
<p>Passei as férias grandes com a família, fora. Quando regressámos o Peter tinha mudado de  
casa, morava agora com um rapaz mais velho do que ele e de quem era muito amigo. Decerto esse rapaz fez-lhe ver que  
eu não passava, afinal, de uma criança e o Peter não quis saber mais de mim. Eu, ao princípio, nem queria acreditar, tanto  
gostava dele! Por fim tive de me conformar, pois, se fosse a andar atrás dele, chamavam-me maluca.</p>
<p>Os anos iam passando. O Peter andava com raparigas da sua idade, e a mim nem sequer  
me cumprimentava já, mas eu não conseguia esquecê-lo. Quando entrei para o liceu judaico, muitos dos rapazes  
apaixonaram-se por mim. Achava aquilo engraçado, mas não sentia nada de especial por nenhum deles. Mais tarde era o  
Harry quem andava atrás de mim. Mas como já disse: nunca mais me apaixonei.</p>
<p>Há um provérbio que diz: &quot;O tempo cura todos os males&quot;. Parecia que era assim  
mesmo, e eu imaginava que me ia esquecendo do Peter e que já nem gostava dele.</p>
<p>Mas a recordação vivia tão fortemente no meu subconsciente que, um dia, tive de confessar  
a mim mesma o ciúme que sentia de todas as raparigas do seu círculo. Por força quis então achá-lo pouco simpático.</p>
<p>Hoje de manhã compreendi, no entanto, que nada se modificou, antes pelo contrário: á  
medida que os anos iam passando e eu me desenvolvia, o amor pelo Peter crescia em mim. Compreendo que ele me tenha  
achado infantil, mas não posso deixar de sentir uma certa dor por me ter esquecido tão depressa. Vi-o muito nitidamente  
diante de mim e sei que nunca ninguém poderá encher da mesma maneira o meu coração.</p>
<p>O sonho confundiu-me. Quando o pai me beijou esta manhã, apeteceu-me gritar: &quot;Ai!,  
se fosses antes o Peter!&quot;</p>
<p>Só posso pensar nele e durante todo o dia repito de mim para mim :</p>
<p>-Oh, Peter, meu querido Peter!</p>
<p>Ninguém me pode ajudar. Tenho de continuar a viver e a pedir a Deus que me deixe  
reencontrar o Peter logo que eu fique em liberdade. Então há-de ler nos meus olhos que o amo e há-de dizer :</p>
<p>-Oh! Anne, se eu soubesse já te tinha procurado há mais tempo!</p>
<p>O pai disse-me uma vez, ao falar comigo sobre sexualidade, que eu ainda não podia  
compreender este desejo, esta ânsia. Mas eu sabia que podia compreender, e agora compreendo sem dúvida! Nada me é  
tão caro como tu, meu Peter!</p>
<p>Contemplei a minha cara no espelho e achei-a transformada. Os meus olhos são agora  
muito claros e profundos, a pele é rosada como a não tinha há muitas semanas, e a boca parece-me mais meiga. Tenho um  
ar de pessoa feliz e, todavia, há qualquer tristeza no meu olhar que afugenta o sorriso dos meus lábios. Não, não posso ser  
feliz, porque sei que os pensamentos do Peter não estão comigo. Mas sinto os seus queridos olhos fixos em mim e a sua  
face, suave e fresca, contra a minha.</p>
<p>Oh! Peter, Peter, como me hei-de libertar da tua imagem?</p>
<p>Qualquer outro que venha a tomar o teu lugar não passará de um substituto mesquinho! É a  
ti que amo, e de tal forma te amo que o amor não coube no meu coração e rompeu para se me revelar em toda a sua  
imensa plenitude.</p>
<p>Ainda há uma semana, mesmo ainda ontem, se me tivessem perguntado com quem eu  
queria casar-me, teria respondido:-Não sei.-Mas agora queria gritar alto para que me ouvissem:</p>
<p>-Quero o Peter, só o Peter! Amo-o com todo o meu coração, com toda a minha alma-mas  
não quero que ele toque senão no meu rosto.</p>
<p>Estive hoje no sótão junto da janela aberta e imaginei conversar com ele. Acabámos por  
chorar os dois e senti nitidamente a sua boca e o seu rosto cheios de ternura por mim.</p>
<p>-Oh, Peter, pensa em mim! Vem, meu querido, querido Peter!</p>
<p>Tua Anne.</p>
<h2>Quarta-feira, 12 de Janeiro de 1944.</h2>
<p>Qerida Kitty:</p>
<p>Há quinze dias voltou a Elli. A Miep e o Henk não puderam vir durante dois dias porque  
comeram alguma coisa que lhes fez mal ao estômago.</p>
<p>A maior novidade que tenho a dar-te é que me interesso agora pelo &quot;ballet&quot; e  
treino-me a dançar todas as noites.</p>
<p>A Mansa transformou-me um vestido de renda azul-claro num ultramoderno vestido de  
&quot;ballet&quot;. Uma fita passa no decote e cruza sobre o peito. Um laçarote enorme remata tudo. Mas em vão tentei  
transformar os meus sapatos de ginástica em sandálias de &quot;ballet&quot;. Os meus membros, que tinham ficado quase  
rígidos, começam a tornar-se flexíveis como eram dantes. Um exercício estupendo, é assim: sentada no chão e segurando  
em cada mão um calcanhar, levantar as duas pernas sem dobrar os joelhos. Para fazer isto sento-me em cima de uma  
almofada para não torturar tanto o meu pobre cóccix.</p>
<p>Os adultos estão a ler um livro: Manhã sem nuvens.</p>
<p>A mãe acha-o muito bom. Focam-se nele problemas da juventude. Cheia de ironia pensei de  
mim para mim:</p>
<p>-E se tu tratasses antes de compreender os jovens com quem vives? Julgo que a mãe está  
convencida de que a Margot e eu vivemos nas melhores relações do mundo com os nossos pais e que ninguém  
compreende tão bem os filhos como ela. Mas em boa verdade isso só sucede com a Margot e, creio-o bem, porque ela não  
tem pensamentos e problemas como eu. Não tenciono fazer ver à mãe que no íntimo de uma das suas filhas as coisas se  
passam de uma maneira muito diferente do que ela imagina.</p>
<p>Ficaria admirada mas não seria capaz de resolver nada a meu respeito. Sentir-se-ia apenas  
triste, e não vale a pena dar-lhe este desgosto, principalmente porque tudo, ao fim e ao cabo, ficaria na mesma.</p>
<p>A mãe bem sente na Margot uma dedicação maior do que em mim. Mas está convencida de  
que também eu me modificarei. A Margot tem agora para mim muitos carinhos. Parece-me tão diferente! Já não troça de  
mim e é uma amiga a valer. Já não vê em mim apenas a miudinha com quem não se pode falar a sério.</p>
<p>É curioso : por vezes olho para mim como se fosse outra pessoa a olhar-me. Estou  
contemplando esta Anne com serenidade e calma e folheio o livro da minha vida como se fosse pessoa estranha.  
Antigamente, na nossa casa, quando eu ainda não cismava tanto, estava convencida de que não pertencia ao pai, nem à  
mãe, nem à Margot, julgava-me uma espécie de ovo de cuco. Representava sòzinha o papel de uma órfã e acabava por  
achar-me ridícula nesta figura tão triste quando, na realidade, levava uma boa vida. Depois seguiu-se um tempo em que me  
esforçava por ser amável: todas as manhãs, quando ouvia alguém subir a escada do nosso quarto, fazia votos para que  
fosse a mãe para nos dar os bons-dias. Cumprimentava-a com meiguice e ficava muito contente por ela olhar para mim com  
carinho. às vezes ela, por causa disto ou daquilo, não estava tão simpática e, então, eu ia para a escola muito triste e  
desconsolada. Quando regressava, pelo caminho, arranjava desculpas para ela, pensava que decerto tinha preocupações;  
e entrava em casa bem disposta e alegre, ansiosa por contar as minhas aventuras... até suceder a mesma coisa e eu ir, de  
novo, triste e pensativa para a escola. Por vezes resolvia mostrar o meu desapontamento. Mas ao voltar para casa tinha  
sempre tantas coisas para contar, que me esquecia. Só queria a todo o custo que a mãe me desse atenção.</p>
<p>Depois veio um período em que já não me importava de ouvir os passos na escada.  
Sentia-me só, enterrava a cabeça na almofada e chorava. Aqui é tudo muito pior.</p>
<p>Tu bem o sabes. Mas Deus deu-me uma ajuda na minha miséria: o Peter! Pego no  
medalhão que trago sempre comigo, beijo-o e penso:</p>
<p>-Que tenho eu que ver com toda esta trapalhada?</p>
<p>Tenho o meu Peter. E o meu segredo.</p>
<p>Desta maneira hei-de vencer muitas coisas. Haverá quem adivinhe o que se passa na alma  
de uma adolescente?</p>
<p>Tua Anne</p>
<h2>Sábado, 15 de Janeiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Não faz sentido eu repetir-te constantemente, com todos os pormenores, as zangas e as  
disputas. Só te quero contar que guardamos agora muitas coisas separadas, o pingue, a carne e a manteiga, por exemplo,  
e fritamos as nossas batatas à parte. Conseguimos mais um bocado de pão de centeio suplementar, porque às quatro  
horas da tarde os nossos estômagos já não aguentavam com a fome.</p>
<p>Aproxima-se o aniversário da mãe. Já recebeu açúcar do Kraler para o dia da festa, e agora  
a sra. van Daan está com inveja por ele não lhe ter dado nenhum a ela no dia dos seus anos. Não é lá prazer nenhum  
assistir todos os dias a cenas de choros e ouvir gritos de raiva. Podes crer, Kitty, estamos cheios até não poder mais.</p>
<p>A mãe exprimiu o desejo de não ver os van Daans durante quinze dias. Mas é um desejo  
que ninguém lhe pode satisfazer. Eu pergunto-me se será sempre assim na vida: as pessoas obrigadas a viver juntas  
durante muito tempo acabam por ter conflitos. Ou temos nós pouca sorte neste caso especial? A maioria dos homens será  
na verdade egoísta e mesquinha? Em certa medida, acho bem adquirir aqui alguns conhecimentos humanos, mas agora já  
me chega e sobra. A guerra ainda não acabou, e as nossas disputas, a fome de ar e de liberdade continuam.</p>
<p>Temos de tentar &quot;to make the best of it&quot;.</p>
<p>Para que estou eu aqui a fazer sermões? Se continuo assim, ainda dou numa velha seca e  
casmurra! E gostava tanto de ser uma moça a valer!</p>
<p>Tua Anne.</p>
<h2>Sábado, 22 de Janeiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Podes tu dizer-me porque é que a maioria das pesoas esconde tão ciosamente o que lhe  
vai no íntimo? E como se explica que eu me porte, junto das outras pessoas, tão diferentemente do que deveria ser? Deve  
haver razões para isso. Mas acho horrível não nos confiarmos inteiramente, mesmo àqueles que nos são mais queridos.  
Tenho a sensação de ter ficado mais velha depois daquele sonho, de ter agora mais &quot;personalidade&quot;. Com  
certeza ficas admirada por eu te confessar que até vejo os van Daans com outros olhos. Não vejo as suas discussões e os  
seus atritos só do nosso ponto de vista parcial. Porque será que estou tão modificada?</p>
<p>Mas escuta. Reflecti sobre tudo isto e cheguei à conclusão de que o nosso convívio podia  
ser diferente, se minha mãe fosse a Mamsi ideal. Bem sei que a sra. van Daan não é uma pessoa delicada. Mas talvez  
metade dos conflitos se pudessem ter evitado se a mãe não fosse tão difícil nas suas relações com os outros e se tivesse  
mais tacto nas conversas, pois a sra. van Daan tem também o seu lado bom: apesar do egoísmo, da mesquinhez e da  
mania das discussões, consegue-se fàcilmente levá-la a ceder. O principal é que a gente a não irrite nem espicace. Não é  
que esta receita dê sempre resultado mas, com um bocado de paciência, a coisa vai. Questões sobre educação, mimos,  
comida, etc., deviam ter sido todas abordadas com franqueza e amizade. Assim não teríamos chegado a este ponto nem  
veríamos só os lados desagradáveis dos outros.</p>
<p>Sei exactamente o que me queres dizer, Kitty!</p>
<p>-Mas, Anne, estas palavras são tuas. Então não tens recebido tantas censuras dos de lá de  
cima? Não te lembras já de todas as injustiças?-Sim, sim, lembro!</p>
<p>Mas, mesmo assim, as palavras são minhas. Quero eu própria aprofundar tudo e não  
papaguear o que dizem os mais velhos... Não! Quero observar os van Daans e verificar o que é verdade e o que é exagero.  
Se depois disto ainda continuar desapontada, concordarei com os pais.</p>
<p>Mas se os van Daans forem melhores do que nos têm parecido a nós, tentarei emendar a  
opinião errada do pai e da mãe; e se mesmo isto não der resultado, hei-de continuar a manter a minha opinião e o meu  
parecer. Hei-de aproveitar, de agora em diante, todas as ocasiões para falar com a sra. van Daan e não me acanharei de  
dizer-lhe sempre o que penso. Pois sempre fui considerada uma rapariga atrevida.</p>
<p>Não penses sequer que quero agir contra a minha própria família, mas fazer má-língua e ter  
preconceitos não é coisa que me agrade por mais tempo. Até agora,julgava firmemente que os van Daans eram os  
culpados de tudo, mas não nos cabe a nós alguma culpa também? Pode ser que tenhamos razão em princípio. Mas as  
pessoas razoáveis -e julgo que nós somos pessoas razoáveis-devem fazer os possíveis para conviver com toda a espécie  
de gente.</p>
<p>Reconheço isto e espero ter ocasião de poder aplicar as minhas ideias na prática.</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 24 de Janeiro de 1944</h2>
<p>Querida Kitty :</p>
<p>Aconteceu-me qualquer coisa de muito estranho. Antigamente falava-se em casa, em  
segredo, das coisas sexuais, e na escola só se falava disso de um modo feio. As raparigas falavam baixinho e por meias  
palavras e se alguma não percebia o que aquilo queria dizer riam-se dela. Eu achava tudo aquilo esquisito e pensava:</p>
<p>-Porque é que se fala destas coisas em segredo e de uma maneira tão feia? Mas como não  
podia modificar nada, calava-me ou falava do assunto, de longe em longe, com uma amiga mais íntima. Mais tarde comecei  
a compreender tudo e os pais também resolveram explicar-me as coisas. A mãe disse uma vez :</p>
<p>-Anne, dou-te o conselho de não abordares este tema com os rapazes e, sempre que eles  
queiram começar, muda de assunto.</p>
<p>Ainda me lembro de que respondi:</p>
<p>-Pois claro, mãe, que ideia!</p>
<p>E assim mantive as coisas até agora.</p>
<p>Aqui, nos primeiros tempos, o pai falava-me, de vez em quando, de coisas que eu antes  
preferia ter ouvido da boca da mãe. O resto aprendi-o nos livros e nas conversas.</p>
<p>O Peter van Daan não se atrevia a dizer nada a tal respeito e só uma vez, muito no  
princípio, falou no assunto, mas não era para provocar uma resposta.</p>
<p>A sra. van Daan disse uma vez que nem ela nem o marido falavam sobre isso com o Peter.  
Ela nem fazia ideia até que ponto o Peter sabia dessas coisas. Ontem, quando a Margot, o Peter e eu estávamos a  
descascar batatas, a conversa caiu sobre Boschi, o gato.</p>
<p>-Ainda não sabemos se Boschi é gato ou gata-disse eu.</p>
<p>-Eu sei-disse o Peter-, é gato.</p>
<p>-Lindo gato - retorqui - que está à espera de gatinhos.</p>
<p>Pois umas semanas antes o Peter tinha dito que Boschi estava grávida porque tinha a  
barriga muito gorda. Provàvelmente isso era consequência do costume de roubar petiscos, pois os tais gatinhos faziam-se  
esperar. Agora o Peter quis defender-se.</p>
<p>-Queres vir ver? - disse -Quando eu, outro dia, andava a brincar com ele, vi nitidamente que  
era gato.</p>
<p>Não consegui dominar a minha curiosidade e fui com ele ao armazém. Mas Boschi não  
havia meio de aparecer.</p>
<p>Esperámos um bocado e depois subimos porque estava muito frio. à tardinha ouvi o Peter  
descer. Cheia de coragem atravessei a casa silenciosa e fui ao armazém.</p>
<p>O Peter estava a brincar com o Boschi, estava precisamente a pesá-lo na balança.</p>
<p>-Olá, então queres ver agora?</p>
<p>Não fez cerimónias. Agarrou no Boschi pela cabeça, segurou-lhe as patas, virou-o e a lição  
começou!</p>
<p>-Aqui é o sexo, aqui alguns cabelos soltos e isto é o traseiro.</p>
<p>O Boschi deu meia volta e pôs-se em cima das suas patinhas brancas. Se qualquer outro  
rapaz me tivesse mostrado assim &quot;o sexo masculino&quot; eu nunca mais olharia para ele. Mas o Peter tratou com  
tanta naturalidade este tema melindroso que acabei por não achar mal nenhum.</p>
<p>Brincámos com o Boschi, divertimo-nos, falámos bastante e por fim subimos devagarinho a  
escada.</p>
<p>- Quase sempre encontro num livro ao acaso aquilo que gostava de saber. Tu também? -  
perguntei.</p>
<p>-Mas porquê? Eu cá pergunto ao meu pai. Ele sabe muita coisa e tem grande  
experiência.</p>
<p>Estávamos em cima da escada e eu calei-me. Com outro rapaz não podia ter falado com  
tanta simplicidade.</p>
<p>Quando a mãe me aconselhou que evitasse falar neste assunto com rapazes, devia ser  
justamente isto o que ela receava. Senti-me todo o dia um tanto confusa ao pensar naquele encontro no armazém. Mas  
aprendi que se pode falar com rapazes de uma maneira ajuizada e sem dizer piadinhas estúpidas.</p>
<p>Será verdade que o Peter conversa muito com os seus pais? E será ele, na realidade, como  
se me mostrou ontem.</p>
<p>Que sei eu dele, afinal?</p>
<p>Tua Anne.</p>
<h2>Quinta-feira, 27 de Janeiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Ultimamente deu-me a paixão pelas árvores genealógicas, em especial pelas das casas  
reais. Se uma vez se começa a investigar, é preciso recuar cada vez mais no tempo e, por fim, chega-se a descobertas  
interessantíssimas.</p>
<p>Os meus estudos estão a ir bem, tenho feito progressos, já consigo perceber o  
&quot;Home-Service&quot; das emissões inglesas.</p>
<p>Mas aos domingos passo o tempo a fazer a escolha para a minha colecção de  
&quot;estrelas&quot; de cinema, aliás uma colecção já muito respeitável. O sr. Kraler, amável como é, traz às  
segundas-feiras a revista de cinema. Embora os companheiros cá do anexo, todos pouco dados a este assunto, achem que  
isto de comprar uma revista de cinema é deitar fora o dinheiro, não podem deixar de se admirar por eu ainda saber, depois  
de mais de um ano de isolamento, quem eram os artistas que trabalhavam em determinados filmes. A Elli, nos dias de folga,  
vai quase sempre ao cinema com o namorado, e quando ela me diz quais são os filmes da semana seguinte, digo-lhe logo  
quem são os artistas que entram e as críticas dos filmes. A Mansa disse outro dia que eu, quando sairmos daqui, já não  
preciso de ir ao cinema, visto que já sei o conteúdo, a qualidade do filme e a distribuição dos papéis.</p>
<p>Quando apareço com um penteado novo, todos olham para mim com ar de censura e  
perguntam quem é a &quot;estrela&quot; que anda assim penteada. E, se lhes digo que fui eu sòzinha que inventei aquilo,  
só me acreditam com grandes reservas. E, já se vê, não me aguento mais de meia hora com o penteado porque os  
critiqueiros estragam-me o prazer. Acabo sempre por ir ao quarto de banho restabelecer o meu penteado de todos os  
dias.</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 28 de Janeiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Hoje de manhã perguntei, de mim para mim, se tu não te sentirás como uma vaca que tem  
de ruminar todas as notícias velhas e que já está aborrecida com esta alimentação monótona, e se não bocejas ao ler estas  
cartas que te não dão novidades. Sim, bem sei, estas velhas tretas são enfadonhas, mas podes crer que eu também já  
estou maçada!</p>
<p>Quando à mesa se não fala de política ou de boas comidas, a mãe e a sra. van Daan  
põem-se a desencantar recordações da sua juventude. Outras vezes o Dussel delira ao lembrar-se do guarda-roupa da  
mulher, sempre cheio de coisas bem escolhidas, ou falando de cavalos de corrida, de um barquinho de remos já com  
rombos, de crianças milagrosas que já sabiam nadar aos quatro anos de idade, ou até de dores de músculos e de clientes  
medrosos. Já chegámos a este ponto : se um dos oito começa a contar uma coisa, qualquer outro pode substituí-lo e  
continuar sòzinho a história até ao fim. Já conhecemos o final de todas as anedotas; só quem as conta se ri ainda com  
elas.</p>
<p>Já passámos, não sei quantas vezes, revista aos fornecedores das nossas ex-donas de  
casa, aos carniceiros, merceeiros e padeiros e, palavra, não sei o que ainda se poderia ouvir inédito aqui no anexo. Tudo  
tem barbas!</p>
<p>Mas isto ainda seria suportável se os adultos não tivessem o hábito desagradável de contar  
as histórias do Koophuis, da Miep e do Henk dez vezes de formas diferentes, sempre enfeitadas com outras invenções.  
Tenho de me beliscar debaixo da mesa para não interromper o narrador entusiasmado, visto que meninas como a Anne  
não devem, de maneira nenhuma, corrigir os adultos, mesmo se estes disserem petas ou começarem a inventar.</p>
<p>O Koophuis e o Henk contam-nos tudo o que sabem de outra gente escondida e  
&quot;mergulhada&quot;. Isto interessa-nos imenso e vivemos e sofremos com aqueles que foram apanhados como se de  
nós próprios se tratasse. Ficamos radiantes ao ouvir que algum prisioneiro foi posto em liberdade.</p>
<p>&quot;Mergulhar&quot; e desaparecer são agora coisas tão correntes como eram  
antigamente os chinelos do pai à espera, no Inverno, diante do fogão.</p>
<p>Organizações como, por exemplo, &quot;A Holanda Livre&quot; fabricam falsos cartões de  
identidade, procuram esconderijos seguros, fornecem os protegidos de dinheiro e de víveres e arranjam, para os rapazes  
cristãos &quot;mergulhados&quot;, trabalho com mestres ou em empresas de confiança.</p>
<p>É admirável com que dignidade e altruismo certas pessoas fazem estes serviços, arriscando  
a sua própria vida para prestarem auxílio aos outros. O melhor exemplo são os nossos protectores que, até agora, nos têm  
ajudado sem interrupção, e que nos hão-de levar, se Deus quiser, até ao fim de tudo isto. Se alguma coisa falhar, eles  
terão o mesmo triste destino de todos aqueles que protegem os judeus. Nunca deixam transparecer que lhes somos um  
fardo-e não há dúvida de que somos-. nunca se queixam das maçadas que lhes estamos a causar. Todos os dias sobem  
até aqui, falam com os homens sobre o negócio e a política, com as senhoras sobre as dificuldades do governo da casa e  
connosco, os jovens, sobre livros e jornais. Entram sempre de cara satisfeita, não se esquecem, nos dias de festa, das  
flores e das prendas e estão sempre prontos a ajudar. Não devemos esquecer nunca, apesar de todas as heroicidades nos  
campos de batalha e de toda a luta contra os opressores, os sacrifícios dos nossos amigos, aqui, junto de nós, as provas  
diárias de simpatia e de amor!</p>
<p>Contam-se as histórias mais fantásticas deste Mundo, mas são quase todas verdadeiras. O  
Koophuis falou-nos de um desafio de futebol no Nelderland, onde de um lado jogavam só &quot;mergulhados&quot; e do  
outro membros da guarda-nacional.</p>
<p>Em Hilversum houve distribuição de novos cartões de racionamento. Para que toda aquela  
gente que vive &quot;mergulhada&quot; não ficasse privada das rações, os funcionários do conselho convocaram os  
&quot;protectores&quot; para uma hora certa, para lhes entregarem os cartões dos seus &quot;mergulhados&quot;.</p>
<p>Mas é preciso cautela: tais façanhas não devem chegar aos ouvidos dos  
&quot;boches&quot;.</p>
<p>Tua Anne</p>`],

23: [`<h2>Quinta-feira, 3 de Fevereiro de 1944</h2><p>Querida Kitty:</p>
<p>Estamos à espera da invasão mais dia menos dia. Se tu aqui estivesses, viverias, decerto,  
debaixo da mesma ansiedade que nós ou, daí, talvez te risses desta gente que parece quase maluquinha. Os jornais não  
falam doutra coisa. As pessoas já não sabem o que hão-de pensar. Lê-se:</p>
<p>&quot;No caso de um desembarque dos Ingleses na Holanda as forças alemãs  
defendê-la-ão, mesmo se para tanto, for necessário inundar todo o país&quot;.</p>
<p>Publicam-se mapas em que as zonas em questão estão sombreadas. Amesterdão está  
abrangida e já estamos a pensar no que se há-de fazer quando a água atingir um metro de altura nas ruas. Ouve-se  
dizer:</p>
<p>-Como não se pode nem correr nem andar de bicicleta temos de passar a vau.</p>
<p>-Talvez possamos nadar. Vestidos de fato de banho e com capacetes de mergulhador,  
ninguém perceberá que somos judeus.</p>
<p>-Disparate! Vejo as senhoras a fugir a nado quando as ratazanas as morderem nas  
canelas.</p>
<p>(Claro, era um homem a fazer troça das mulheres.</p>
<p>Mas vamos a ver quem grita mais, se são eles ou nós!) -Nós não conseguiremos salvar-nos  
com certeza.</p>
<p>O armazém está tão podre que a casa, ao primeiro impulso da água, vai abaixo, - Falando a  
sério: pronto! arranjaremos um barquinho e mais Não é preciso! Cada um pega num dos velhos caixotes do açúcar do sótão  
e depois rema com uma colher de cozinha.</p>
<p>- Eu vou atravessar sobre andas. Era campeão em pequeno.</p>
<p>-O Henk van Santen não precisa de nada disso.</p>
<p>E se levar a sua Miep às costas, ela terá boas andas.</p>
<p>Agora podes fazer uma ideia, Kitty. Estas conversas têm graça. Mas a realidade talvez  
venha a ser diferente.</p>
<p>Surge um segundo problema ligado ao desembarque. Que vamos fazer se Amesterdão for  
evacuada pelos alemães?</p>
<p>-Vamos com eles, sem dar nas vistas.</p>
<p>-Não, de maneira nenhuma! Ficamos aqui, que ainda é o melhor. Os alemães são capazes  
de nos obrigar a ir para a Alemanha e depois não poupam ninguém!</p>
<p>-Está claro, ficaremos aqui. Ao menos estaremos mais seguros. Temos de convencer  
Koophuis a vir também para aqui com a família. Será preciso arranjar serrim para podermos dormir no chão. A Miep e o  
Koophuis deviam trazer já alguns cobertores. Só temos trinta quilos de farinha, não chegará para todos, é preciso  
conseguir mais.</p>
<p>O Henk talvez possa arranjar legumes secos. Temos trinta quilos de feijão e cinco quilos de  
ervilhas em casa e ainda cinquenta latas de legumes de conserva.</p>
<p>-Mãe, não será melhor fazer um balanço aos víveres?</p>
<p>-Bem: dez latas de peixe, quarenta de leite, cinco quilos de leite em pó, três garrafas de  
azeite, quatro frascos de manteiga e quatro de carne, quatro frascos de morangos, dois garrafões de sumo e vinte de puré  
de tomate, cinco quilos de flocos de aveia, quatro quilos de arroz. Eis tudo!</p>
<p>-Não é nada mau. Mas se quisermos alimentar as visitas e se só tivermos isto para comer,  
não parece que seja muita coisa. Carvão e lenha ainda temos que chegue; velas também. Era bom que cada um tivesse já  
um saquinho de pendurar ao pescoço para levar o dinheiro, se for preciso.</p>
<p>-Acho que devíamos fazer listas daquilo que, em caso de fuga, faz mais falta e devíamos já  
encher as mochilas.</p>
<p>Depois duas pessoas deviam estar de guarda, uma na mansarda, outra no sótão.</p>
<p>- Mas para que nos vão servir os víveres se não tivermos nem gás, nem água, nem  
electricidade?</p>
<p>Cozinhamos no fogão da sala. Filtramos a água e fervemo-la. Havemos de limpar uns  
garrafões para ter sempre alguma água.</p>
<p>Estas conversas ouço-as todo o santo dia. Invasão para disputa aqui, para invasão  
acolá!</p>
<p>sobre a morte pela fome, sobre bombas, sacos de dormir, bombas incendiárias certificados  
de judeus, gases venenosos e assim por diante.</p>
<p>Para te dar uma ideia mais nítida das preocupações constantes da gente do anexo, vou  
reproduzir-te uma conversa com o Henk.</p>
<p>Anexo: Estamos com medo de que os alemães, numa eventual retirada, levem toda a  
população com eles.</p>
<p>Henk: Impossível. Não têm comboios que cheguem.</p>
<p>Anexo: Comboios? Mas o senhor pensa que eles vão levar a gente de comboio? Nem  
pensar nisso! Fazem-nos mas é andar à pata. &quot;per pedes apostolorum, costuma dizer o Dussel a cada passo).</p>
<p>Henk : Não creio. Vocês são pessimistas de mais que vantagem teriam eles em arrastar  
assim toda a população?</p>
<p>Anexo: Sabe o que disse Goebbels: se tivermos que retirar, fecharemos atrás de nós todas  
as portas dos países ocupados.</p>
<p>Henk: Oh! Já disseram tanta coisa!</p>
<p>Anexo: Pensa que os alemães são demasiado nobres ou humanitários para agir assim?  
Logo que lhes cheire a perigo, hão-de arrastar consigo tudo o que encontrarem pelo caminho.</p>
<p>Henk: Digam o que quiserem. Eu não acredito.</p>
<p>Anexo : É sempre a mesma coisa. As pessoas só vêem o perigo depois de o terem  
experimentado no seu próprio corpo.</p>
<p>Henk: Mas nada se sabe de positivo. Tudo isso são apenas hipóteses.</p>
<p>Anexo: Mas já passámos por tudo isso, primeiro na Alemanha, depois aqui. E não vê o que  
estão a fazer na Rússia?</p>
<p>Henk: Esqueçam-se, por um instante, do problema dos judeus. Ninguém sabe o que se está  
a passar no Leste.</p>
<p>Se calhar a propaganda russa e inglesa exagera tanto como a alemã.</p>
<p>Anexo : Não pode ser. A rádio inglesa tem dito sempre a verdade. Mas, supondo mesmo  
que há exageros, os factos conhecidos já são bastante eloquentes. Não pode negar que os alemães estão a matar e a  
gasear milhões de inocentes na Polónia e na Rússia, não é verdade?</p>
<p>Não te vou maçar com mais conversas. Faço os possíveis para me conservar calma e para  
não me preocupar. Já cheguei a um ponto em que me é indiferente viver ou morrer. O Mundo não parará por causa de mim,  
e eu, pela minha parte, não posso também fazer parar os acontecimentos. Venha o que vier.</p>
<p>Entretanto, estudo e trabalho e tenho esperança de que tudo acabará em bem.</p>
<p>Tua Anne</p>
<h2>Sábado, 12 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>O Sol brilha, o céu é de um azul intenso, sopra um vento maravilhoso, e eu... eu tenho  
saudades. Saudades... de tudo, da liberdade, dos amigos. Saudades de poder desabafar e... de estar só comigo. Ai!, se  
pudesse chorar à vontade, uma vez só que fosse. Queria aliviar o meu coração, queria chorar para me sentir melhor, mas  
sei que não pode ser. Estou irrequieta, ando de um quarto para o outro, ponho-me por trás da janela fechada e procuro  
respirar o ar de lá de fora através das frinchas, sinto o coração a bater como se me estivesse a pedir : satisfaz o meu  
desejo!</p>
<p>Creio que a culpa é da Primavera. Sinto-a despertar em todo o meu corpo e em toda a  
minha alma. Tenho de fazer esforços para me conservar calma, sinto uma grande confusão, não consigo ler, nem escrever,  
nem fazer seja o que for. Só sei que tenho saudades.</p>
<p>Tua Anne.</p>
<h2>Domingo, 13 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>De ontem para hoje muita coisa se tem modificado . Ontem estava cheia de saudades e  
ainda estou, em mim a satisfação já não é a mesma coisa. Hoje de manhã notei que tudo era diferente. Mas... notei com  
satisfação, digo-o com toda a franqueza, o Peter não tirava de mim os olhos. Não olhava para mim como de costume, era  
diferente, não sei dizer nem escrever como. Sempre pensei que o Peter gostava mas era da Margot, e agora senti que não  
é nada disso. Durante todo o dia não olhei muito para ele, pois sempre que o encarava ele estava a olhar também.  
Invadia-me então uma sensação maravilhosa. Bem sei que isso não está certo, que não deve repetir-se muitas vezes.  
Queria tanto estar só! O peter já percebeu que estou diferente, mas não lhe posso contar tudo! &quot;Deixem-me em  
paz&quot;, gostava de lhes gritar a todos. Mas, quem sabe, talvez ainda venha um dia em que estarei mais só do que é  
meu desejo.</p>
<p>Tua Anne.</p>
<h2>Segunda-feira, 14 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>No domingo, à noite, estavam todos a ouvir na rádio o programa &quot;Música imortal dos  
mestres alemães&quot;, só o Pim e eu é que não. O Dussel estava constantemente a mexer no botão do aparelho. O Peter  
ficou aborrecido com isso, e os outros também. Depois de uma meia hora, o Peter, que já estava muito nervoso, pediu ao  
Dussel, num tom irritado, que acabasse com aquilo. O Dussel respondeu meio condescendente, meio desdenhoso :</p>
<p>-Eu bem sei o que estou a fazer.</p>
<p>O Peter enfureceu-se, seu pai deu-lhe razão e o Dussel não teve outro remédio senão  
ceder. Foi tudo. Não era coisa de importância mas, pelos vistos, o Peter ficou muito aborrecido porque quando eu, hoje de  
manhã, andava a remexer no caixote dos livros, no sótão, ele começou a contar-me tudo. Até então eu nem sequer sabia  
que tinha havido alguma coisa, e o Peter, como compreendeu que eu ouvia com interesse, entusiasmou-se.</p>
<p>-Repara - disse-, eu fico quase sempre calado, porque sei de antemão que não sou capaz  
de me exprimir bem.</p>
<p>Desato a gaguejar, coro e digo muitas vezes o que não queria. Por fim desisto por não  
encontrar as palavras certas. Assim aconteceu ontem. Queria dizer uma coisa mas, mal tinha começado, fui perdendo o  
sangue-frio.</p>
<p>Isto é horrível. Antigamente tinha um mau costume mas, por vezes, ainda hoje, preferia fazer  
o mesmo. Quando me zangava com alguém, em vez de discutir, servia-me dos meus punhos. Bem sei que não é bom  
método e, por isso, é que te admiro. Tu sabes falar bem, dizes sempre a toda a gente o que tens a dizer e não te  
acanhas.</p>
<p>-Estás enganado-respondi-, quase nunca digo o que queria dizer. E falo de mais, parece  
que nunca mais acabo, e isto também é mau.</p>
<p>Cá no meu íntimo estava a rir-me de contente, mas não queria que ele soubesse, pois há  
muito desejava que ele me falasse de si. Sentei-me confortàvelmente no chão numa almofada, cruzei os braços, apoiei o  
queixo nos joelhos e olhei para ele. Toda eu era atenção.</p>
<p>Estou radiante por haver alguém nesta casa, que , consegue enraivecer-se como eu. Via-se  
bem que o Peter se sentia aliviado ao criticar o Dussel com expressões fortes sem ter medo de que eu o denunciasse. E eu,  
enfim, achei aquilo estupendo, porque senti renascer em mim o autêntico sentimento de camaradagem que antigamente  
experimentava junto das minhas amigas.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 16 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>A Margot faz anos. Ao meio-dia e meia hora veio o Peter para ver as prendas e, contra o  
costume, ficou bastante tempo. à tarde fui buscar um pouco de café e também batatas porque achava que a Margot neste  
dia devia ser bem tratada. O Peter, ao ver-me passar pelo seu quarto, tirou logo todos os seus papéis da escada e eu  
perguntei-lhe se queria que fechasse o postigo.</p>
<p>-Está bem-disse ele-e, quando voltares, bate que eu abro imediatamente. Agradeci-lhe e  
subi. Durante dez minutos andei a remexer no barril para escolher as batatas mais pequenas. Depois senti dores nas  
costas, de estar tanto tempo curvada, e também senti frio. Não bati, abri o postigo sózinha. Mas o Peter veio a correr  
imediatamente para pegar no panelão.</p>
<p>- Andei muito tempo à procura mas não encontrei batatas mais pequenas - disse eu.</p>
<p>- Viste no barril grande?</p>
<p>- Vi. Remexi-o todo com a mão.</p>
<p>Eu estava agora ao pé da escada e ele olhou, com ar de quem percebe, para dentro da  
panela que segurava na mão. Depois entregou-ma e disse :</p>
<p>- São boas, são óptimas.</p>
<p>E, ao dizê-lo acariciou-me com um olhar tão quente e tão suave que toda eu me senti por  
dentro quente e suave. Compreendi que ele quis ser amável para comigo.</p>
<p>Mas como não sabe fazer grandes discursos, pôs todos os seus pensamentos no olhar.</p>
<p>Que bem que eu o compreendi! E estava-lhe grata de todo o meu coração. Ainda agora me  
sinto contente ao reviver as suas palavras e o seu olhar.</p>
<p>Quando voltei, a mãe disse que as batatas não chegavam para o jantar. Ofereci-me logo  
para subir novamente.</p>
<p>Ao entrar no quarto do Peter pedi desculpa por incomodá-lo novamente. Levantou-se,  
pôs-se entre a parede e a escada e quis, a toda a força, reter-me.</p>
<p>-Agora vou eu ao sótão-disse.</p>
<p>Respondi que não era preciso, que eu não ia escolher outra vez as batatas mais pequenas.  
Convenceu-se e soltou-me.</p>
<p>Quando voltei, abriu a fresta e pegou na panela.</p>
<p>Ao sair da porta perguntei-lhe :</p>
<p>- Que estás a fazer?</p>
<p>- Francês-respondeu.</p>
<p>Perguntei se me deixava ver. Lavei as mãos e sentei-me à sua frente, no divã.</p>
<p>Depois de eu lhe ter explicado algumas coisas, começámos a conversar. Contou-me que  
mais tarde, queria ir trabalhar para as plantações na índia Holandesa. Falou também da sua vida em casa, do mercado  
&quot;negro&quot; e, por fim, disse que era um inútil. Respondi-lhe que ele tinha mas era um forte complexo de  
inferioridade. Depois falou dos judeus. Achava mais cómodo se pudesse ser cristão e gostava de o ser depois da guerra.  
Então eu quis saber se tinha a intenção de se baptizar depois da guerra, mas ele disse-me que, afinal, não queria, porque  
depois da guerra ninguém saberia se ele era cristão ou judeu. Esta atitude fez-me doer, por um momento, o coração. É  
pena haver nele sempre um pedacinho de desonestidade.</p>
<p>Falámos ainda de meu pai, de conhecimentos humanos e de outras coisas mais. Só o deixei  
às quatro e meia.</p>
<p>À noite disse-me ainda uma coisa bonita sobre o retrato de uma &quot;estrela&quot; do  
cinema que lhe dei uma vez e que tem pendurado, há para aí ano e meio, no quarto. Como tinha gostado tanto, ofereci-lhe  
mais retratos de &quot;estrelas&quot; de cinema.</p>
<p>- Não-disse ele-, não me dês mais. Prefiro olhar só para aquela todos os dias, porque já se  
tornou para mim uma amiga.</p>
<p>Agora compreendo porque é que ele anda sempre com o Mouchi ao colo. Tem necessidade  
de carinho.</p>
<p>mais um assunto em que falou, quase me ia esquecendo.</p>
<p>- Não sei o que é medo - disse - a não ser quando estou doente. Mas mesmo isto há-de  
passar.</p>
<p>O seu complexo de inferioridade é muito grande.</p>
<p>Pensa que é estúpido e que nós somos inteligentes. Quando lhe dou uma ajuda no francês,  
agradece-me mil vezes.</p>
<p>Hei-de dizer-lhe qualquer dia:</p>
<p>- Deixa-te disso. Em compensação sabes muito mais inglês e geografia do que eu.</p>
<p>Tua Anne.</p>
<h2>Sexta-feira, 18 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Sempre que vou lá para cima é com a ideia de o ver a &quot;ele&quot;. A minha vida agora  
é mais bela porque tem de novo um sentido e todos os dias me espera uma alegria.</p>
<p>E, ao menos, o objecto da minha amizade encontra-se sempre nesta casa, não tenho de  
recear rivais (com excepção da Margot). Não julgues que estou apaixonada. Não é bem isso. Mas sinto que entre mim e o  
Peter ainda se desenvolverá algum sentimento muito belo, que fará de nós amigos e confidentes. Sempre que posso, vou  
ter com ele. Agora já não é como dantes quando ele não sabia o que me havia de dizer. Pelo contrário: já estou a sair da  
porta e ele ainda a falar.</p>
<p>A mãe não vê com bons olhos que eu vá tantas vezes lá para cima. Disse que eu não devia  
incomodar o Peter, que o devia deixar em paz. Não compreende ela que se trata da minha vida íntima? Sempre que vou ao  
quarto dele, ela olha-me de um modo estranho. E quando volto pergunta-me de onde venho. Não suporto isto, acho  
detestável.</p>
<p>Tua Anne.</p>
<h2>Sábado, 19 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Já é outra vez sábado e sabes o que isto quer dizer.</p>
<p>De manhã houve silêncio. Ajudei um bocado mas com &quot;ele&quot; só falei de fugida. às  
duas e meia fui com um cobertor para o escritório particular, para poder ler ou escrever na escrivaninha com calma.  
Passado pouco tempo eu não podia mais: enterrei a cabeça nos braços e comecei a chorar.</p>
<p>As lágrimas corriam, sentia-me muito infeliz. Ai! Se &quot;ele&quot; tivesse ido consolar-me!  
Eram quatro horas quando voltei cá para cima. Tive de ir buscar batatas e pensei que ia agora encontrá-lo. Mas enquanto  
eu dava um jeito ao cabelo, no quarto de banho, ouvi-o descer com o Boschi ao armazém.</p>
<p>Chorei outra vez e fugi para o W.C. levando ainda comigo o espelho de cabo: Aí fiquei,  
muito triste, e o meu avental vermelho encheu-se de manchas de tantas lágrimas.</p>
<p>-Assim não chego a cativá-lo-pensei.-Se calhar, ele nem se importa comigo nem tem  
nenhuma necessidade de se abrir e se confiar. Pensará ele em mim de uma maneira superficial? Só me resta seguir o meu  
caminho, sózinha sem o Peter. De novo sem esperança e sem consolo.</p>
<p>Gostava de encostar, ao menos uma vez, a cabeça no seu ombro, para não me sentir tão  
desesperada e tão só.</p>
<p>Talvez ele me não ache nada de especial e olhe para os outros do mesmo modo simpático.  
O seu olhar quente e suave só terá existido na minha imaginação? Oh, Peter, se me pudesses ouvir ou ver! Mas eu não  
podia suportar uma verdade que me desiludisse.</p>
<p>Enquanto nos meus olhos ainda havia lágrimas, já no meu íntimo surgia uma nova  
esperança.</p>
<p>Tua Anne.</p>
<h2>Domingo, 20 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Nós fazemos ao domingo o que a outra gente faz à semana. Enquanto os outros andam a  
passear, todos catitas, andamos nós a tratar das limpezas.</p>
<p>Oito horas: sem consideração pelos dorminhocos, o Dussel levanta-se. Vai ao quarto de  
banho, depois desce, volta para cima e lava-se durante uma hora.</p>
<p>Nove e meia: Abrimos as cortinas, acendemos os fogões e os van Daans lavam-se.</p>
<p>Dez e um quarto: Os van Daans estão a assobiar.</p>
<p>O quarto de banho está livre. Os nossos dorminhocos levantam-se. Andam depressa de um  
lado para o outro.</p>
<p>Sucessivamente, a Margot, a mãe e eu, a fazermos as nossas abluções. Está um frio de  
rachar, e ainda bem que temos calças compridas. O pai é o último a lavar-se.</p>
<p>Onze e meia: pequeno almoço. Nem quero falar disso.</p>
<p>Já basta ouvir falar tanto de comida nesta casa.</p>
<p>Meio-dia e um quarto: cada um faz o que lhe apetece.</p>
<p>O pai, vestindo uma bata, anda de joelhos a escovar o tapete e fá-lo com tanto entusiasmo  
que todo o quarto fica envolto numa nuvem de pó. O Dussel vira a cama dele e assobia o concerto de violino de Beethoven.  
Ouvem-se os passos da mãe no sótão. Estende a roupa lavada. O sr. van Daan põe o chapéu na cabeça e desaparece  
para o andar de baixo; o Peter, com o Mouchi ao colo, quase sempre vai também. A sra. van Daan põe um avental  
comprido, veste um colete de lã preta, calça as galochas, envolve a cabeça num grosso xaile vermelho, pega numa trouxa  
de roupa e despede-se com uma vénia muito bem ensaiada.</p>
<p>A Margot e eu lavamos a louça e arrumamos o quarto.</p>
<p>Tua Anne.</p>
<h2>Quarta-feira, 26 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>O tempo está desde ontem maravilhoso e sinto-me verdadeiramente espevitada. Vou todas  
as manhãs ao sótão onde o Peter trabalha e onde respiro ar fresco. Do meu lugar favorito no chão vejo um pedaço de céu  
azul e o castanheiro sem folhas, em cujos ramos cintilam gotinhas, e vejo as gaivotas que, no seu voo planado, parecem de  
prata.</p>
<p>O Peter, com a cabeça encostada à viga, e eu, sentada, respiramos o ar puro, olhamos lá  
para fora. Há entre nós qualquer coisa que não queremos afugentar com palavras.</p>
<p>Olhámos assim muito tempo lá para fora e quando o Peter se teve de ir embora para rachar  
a lenha, eu sabia que ele era um óptimo rapaz. Subiu a escadinha estreita, segui-o, e durante um quarto de hora, enquanto  
ele trabalhava, não pronunciámos uma única palavra. Vi bem que se esforçava por me mostrar que tem força.</p>
<p>Mas vi também, através da janela aberta, um pedaço de Amesterdão: olhei sobre os  
telhados até à linha do horizonte que de tão azul e de tão límpido quase se não distinguia do céu.</p>
<p>-Enquanto ainda há disto, pensei, um Sol tão brilhante, um céu sem nuvens e tão azul, e  
enquanto me é dado ver e viver tamanha beleza, não devo estar triste.</p>
<p>Para qualquer pessoa que se sinta só ou infeliz, ou que esteja preocupada, o melhor  
remédio é sair para o ar livre, ir para qualquer parte, onde possa estar só com o céu e com a natureza, e com Deus. Então  
compreende que tudo é como deve ser e que Deus quer ver os homens felizes no meio da natureza, simples e bela.  
Enquanto assim for-e julgo que será sempre assim-sei que há uma consolação para todas as dores e em todas as  
circunstâncias.</p>
<p>Creio que a natureza alivia os sofrimentos.</p>
<p>Talvez eu possa, em breve, partilhar esta felicidade suprema com alguém que sinta as  
coisas como eu.</p>
<p>Estamos privados de muita coisa e há muito tempo.</p>
<p>Sinto-o como tu. Não estou a falar de coisas exteriores, as que temos ainda chegam. Não,  
falo daquilo que se passa dentro de nós. Tal como tu, eu queria liberdade e ar, mas creio agora que temos boa  
compensação disto que nos falta. Foi o que compreendi, de repente, hoje de manhã, quando estava sentada junto da  
janela; quero dizer, uma compensação íntima. Ao olhar lá para fora e ao reconhecer Deus na natureza, senti-me feliz,  
apenas feliz. Oh, Peter, enquanto esta felicidade está em nós, esta felicidade da natureza, da saúde e de muitas coisas  
mais, enquanto formos capazes de conservar tudo isto em nós, a felicidade voltará sempre de novo. Fortuna, fama, tudo  
podes perder, mas a felicidade do coração, ainda que por vezes esteja obscurecida, torna a vir enquanto viveres. Enquanto  
puderes erguer os olhos para o céu, sem medo, saberás que tens o coração puro, e isto significa felicidade.</p>
<p>Tua Anne.</p>
<h2>Domingo, 27 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>De manhã até à noite não posso pensar senão no Peter.</p>
<p>Adormeço com a sua imagem nos olhos, sonho com ele e quando acordo sinto o seu olhar  
em mim.</p>
<p>Parece-me que o Peter e eu não somos tão diferentes como podia parecer à primeira vista.  
A ambos nos falta uma mãe. A dele é demasiado superficial, gosta do &quot;flirt&quot; e não se preocupa com a vida íntima  
do filho. A minha pensa em mim, mas não possui o tacto com que as mães devem compreender as coisas.</p>
<p>Ambos lutamos contra o que se passa dentro de nós.</p>
<p>Falta-nos ainda a segurança, somos acanhados e frágeis, não suportamos que alguém  
toque o nosso íntimo com grosseria. Quando isso acontece comigo, a minha primeira reacção é: &quot;quero ir-me embora,.  
Mas como é impossível, escondo os meus sentimentos e porto-me tão mal que toda a gente desejava que eu realmente me  
fosse embora.</p>
<p>O Peter, por sua vez, fecha-se na sua concha, não fala, sonha e esconde-se, cheio de  
receios.</p>
<p>Mas como e onde nos havemos de juntar? Não sei durante quanto tempo poderei dominar  
este meu desejo.</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 28 de Fevereiro de 1944</h2>
<p>Querida Kitty:</p>
<p>Já está a ser um pesadelo! Estou sempre junto dele; não devo deixar transparecer nada,  
tenho de parecer despreocupada e alegre, ao passo que, no meu íntimo tudo é desespero.</p>
<p>Agora Peter Wessel e Peter van Daan formam um Peter só. E este Peter é bom e eu amo-o e  
quero-o para mim. A mãe está insuportável, o pai sempre gentil e, por isso, mais insuportável ainda, a Margot pretende  
tornar-se amável, e eu só queria que me deixassem em paz.</p>
<p>O Peter não veio ter comigo quando eu estava no sótão. Saiu para se pôr a carpinteirar. A  
cada martelada eu ia perdendo mais a coragem e ficando mais triste.</p>
<p>Do outro lado toca o carrilhão: &quot;O corpo erecto! O coração ao alto!</p>
<p>Estou a ser uma sentimentalona, bem sei. Estou desesperada e não tenho juízo, também  
sei!</p>
<p>Oh! Ajuda-me!</p>
<p>Tua Anne.</p>`],

24: [`<h2>Quarta-feira, 2 de Março de 1944</h2><p>Querida Kitty:</p>
<p>As minhas preocupações passaram Para segundo plano e isto por causa de um roubo.  
Estes roubos já não têm graça nenhuma, mas o que se há-de fazer se os ladrões sentem um prazer especial em honrar a  
firma Kolen &amp; Go.</p>
<p>Com a sua visita? Desta vez a coisa foi mais complicada do que em Julho do ano passado.  
Quando o sr. van Daan desceu ontem, como de costume, ao escritório do Kraler viu que as portas envidraçadas e a porta  
do escritório estavam abertas. Surpreendido, resolveu dar uma volta para inspeccionar o resto e ainda mais surpreendido  
ficou ao ver o caos no escritório principal.</p>
<p>-Ladrões!- até aí para se certificar disso correu, escada abaixo até à porta de entrada. Mas  
a porta e o fecho de segurança estavam intactos.</p>
<p>- Peter e a Elli foram desleixados - pensou então.</p>
<p>Ficou algum tempo no escritório do Pai e depois fechou as Portas, a luz, subiu e não se  
ralou mais com as portas abertas nem do estranho caos no escritório.</p>
<p>E de manhã o Peter bateu cedo à nossa porta e deu-nos a notícia desagradável de que a  
porta da rua estava largamente aberta e de que tinham desaparecido do armário o aparelho de projecção e a nova pasta  
do Kraler O Peter recebeu ordens para fechar a porta da rua e, só agora o sr. van Daan nos contou as suas observações  
da noite anterior. Ficámos muito preocupados.</p>
<p>Esta história só tem uma explicação : o ladrão possui uma chave igual à chave de  
segurança, pois a porta não estava arrombada. Decerto meteu-se dentro da casa muito cedo, fechou a porta atrás de si e,  
ao ouvir o sr. van Daan, escondeu-se. Depois de este ter subido, desatou a fugir o mais depressa que pôde, com as coisas  
roubadas e, com a atrapalhação, esqueceu-se de fechar a porta da rua. Mas quem será o homem que possui a chave? E  
porque é que não entrou no armazém? Será mesmo um dos próprios empregados do armazém? E se ele nos denunciar?  
agora que ouviu e provàvelmente viu o sr. van Daan?</p>
<p>Tudo isto é quase sinistro, porque nunca sabemos se e e quando o ladrão virá de novo abrir  
a porta. Ou será possível que ele próprio se tenha assustado por ter visto alguém dentro da casa?</p>
<p>Tua Anne.</p>

<h2>Quinta-feira, 3 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>A Margot e eu estivemos hoje no sótão. Mas o prazer não foi o mesmo, embora eu saiba  
que em muitas coisas ela sente como eu.</p>
<p>Ao lavar a louça, a Elli confessou à minha mãe e à sra. van Daan o seu desespero. E queres  
saber como as duas a consolaram? Sabes qual foi o conselho que a mãe lhe deu? Que devia pensar em todos aqueles que  
estão agora a perecer no Mundo! Mas quando uma pessoa está desesperada, pode valer-lhe de alguma coisa pensar nas  
misérias dos outros? Foi o que eu disse, mas responderam-me :</p>
<p>-Não sabes ainda nada destas coisas.</p>
<p>Os adultos são tapados, são estúpidos. Como se a Margot, o Peter, a Elli e eu não  
sentíssemos todos o mesmo!</p>
<p>Só o amor de uma mãe ou o amor de um grande amigo nos pode consolar. As nossas mães  
não têm uma centelha de compreensão para nós sequer, e acho que a sra. van Daan ainda tem mais um bocado do que  
minha mãe.</p>
<p>Eu gostaria de ter dito à pobre Elli algumas palavras, dessas palavras que confortam, como  
sei por experiência própria. Mas o pai interveio e afastou-me. São tão estúpidos, todos eles! Nós não temos direito a ter  
uma opinião!</p>
<p>Eles são imensamente modernos! Então a gente não sabe pensar? Pode obrigar-se alguém  
a não falar, mas nunca a não ter uma opinião. Não é possível proibir-se isto a ninguém, seja qual for a idade. A Elli, ao  
Peter, à Margot e a mim só o amor autêntico, abnegado, pode valer, mas o amor assim não nos é dado. Nenhum de todos  
estes sábios idiotas nos compreende aqui, porque nós somos muito mais sensíveis, muito mais avançados nas nossas  
ideias do que eles imaginam.</p>
<p>Presentemente, a mãe anda a criticar-me a torto e a direito. Tem ciumes da sra. van Daan,  
com quem agora falo mais do que com ela.</p>
<p>Hoje de tarde consegui apanhar o Peter. Conversámos pelo menos uns três quartos de  
hora. O Peter tem muita dificuldade em falar de si próprio, mas pouco a pouco há-de fazê-lo. Contou-me que os pais se  
zangavam a cada passo por causa da política, dos cigarros e de outras coisas que tais. Estava embaraçado. Depois  
falei-lhe dos meus pais.</p>
<p>O Peter tem grande entusiasmo por meu pai, disse que era um tipo &quot;bestial&quot;.  
Assim falámos da nossa família.</p>
<p>Ficou admirado quando eu lhe disse que não gostávamos muito dos seus pais.</p>
<p>- Peter - disse-lhe -, sabes que sou sempre franca.</p>
<p>Porque é que não te devia de contar? Conhecemos os defeitos dos teus pais!</p>
<p>E depois ainda lhe disse :</p>
<p>- Peter, eu gostava de ajudar-te. Não será possível?</p>
<p>Tu andas metido entre os dois e sei que isto te faz mal.</p>
<p>- Sim, gostava que me ajudasses, agradecer-te-ia toda a vida.</p>
<p>- Mas talvez seja melhor tu falares com meu pai, podes ser franco com ele; nunca denuncia  
ninguém.</p>
<p>- Ah, sim, deve ser um camarada a valer.</p>
<p>-Gostas dele, não gostas?</p>
<p>Fez que sim com a cabeça e depois eu disse:</p>
<p>- Ele também gosta muito de ti.</p>
<p>Ficou corado, o que me enterneceu. Que felicidade lhe dei com tão poucas palavras!</p>
<p>- Mas isso é verdade? - Perguntou.</p>
<p>- Pois claro-disse eu-, já lho ouvi dizer não sei quantas vezes.</p>
<p>O Peter é um tipo &quot;bestial&quot;, exactamente como o pai.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 9 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Hoje, quando se acenderam as velas, fiquei contente, senti-me calma. Vi a avó, envolvida  
pela luz. A avó é quem me protege e preserva e quem me dá, sempre de novo, alegria e satisfação.</p>
<p>Mas... agora há mais uma pessoa que domina os meus pensamentos: é o Peter. Quando  
hoje fui buscar as batatas e estava, com a panela cheia, ao pé da escada, ele perguntou-me :</p>
<p>- Que fizeste hoje de tarde?</p>
<p>Sentei-me num degrau e conversámos. Só às cinco e um quarto (uma hora depois de ter  
subido) desci com as batatas.</p>
<p>O Peter não falou dos seus pais. Falámos de livros e dos tempos passados. Quase me  
podia apaixonar por ele!</p>
<p>Tocou no assunto. Depois de ter descascado as batatas, fui ter com ele. Estava calor e eu  
disse :</p>
<p>- Para saberes a temperatura basta olhares para mim e para a Margot. O frio torna-nos  
pálidas e com o calor ficamos coradas.</p>
<p>- Apaixonada?-perguntou.</p>
<p>- Eu apaixonada? Mas porquê?-respondi eu cheia de candura.</p>
<p>- E porque não?-perguntou.</p>
<p>Depois descemos para jantar.</p>
<p>Que queria ele dizer com aquilo? Hoje perguntei-lhe, finalmente, se não achava as minhas  
conversas maçadoras.</p>
<p>Disse :</p>
<p>-Acho-as engraçadas.</p>
<p>E não disse mais nada. Não sei se estava a ser muito tímido.</p>
<p>Oh, Kitty! Estou a portar-me como uma apaixonada que não consegue falar senão do seu  
namorado. Mas, podes crer, o Peter é um amor de rapaz! Quando lhe poderei eu dizer isto? Claro que não será antes de  
ele me achar também um amor de rapariga. Eu não sou uma gatinha que se possa tocar sem luvas, bem sei. A verdade é  
que o Peter gosta do seu sossego, e será difícil eu saber se gosta de mim.</p>
<p>De qualquer forma estamos a conhecer-nos melhor um ao outro e eu só queria que  
tivéssemos coragem para nos abrirmos ainda mais. Quem sabe, talvez isto se dê mais depressa do que estou a imaginar.  
Olha-me várias vezes como quem me compreende e eu respondo piscando os olhos. E então ficamos ambos felizes e  
divertidos!</p>
<p>Devo parecer uma tola a falar assim da nossa felicidade, mas estou convencida de que ele  
pensa exactamente como eu!</p>
<p>Tua Anne</p>
<h2>Sábado, 10 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Este sábado é, desde há meses e meses, o primeiro que não se passou aborrecido, triste e  
desesperado. E isto por causa do Peter.</p>
<p>Quando hoje de manhã fui ao sótão para estender o meu avental lavado, estava lá o pai,  
que estuda todos os dias com o Peter. Perguntou-me se eu não queria ficar a estudar com eles. Claro que quis e falámos  
primeiro francês. Expliquei umas coisas ao Peter e depois passámos para o inglês. O pai leu-nos umas passagens de um  
livro de Dickens e, confesso, senti-me no sétimo céu, assim sentada ao lado do pai e tão próxima do Peter.</p>
<p>às onze desci. Quando meia hora depois voltei para cima, o Peter já me esperava junto da  
escada. Conversámos até à uma menos um quarto. Sempre que pode, isto é, quando ninguém está a ouvir, ele diz-me  
depois do almoço :</p>
<p>- Até logo, Anne.</p>
<p>Ah, como me sinto contente! Ele gostará de mim?</p>
<p>Seja como for, o Peter é um óptimo rapaz e acho que nos havemos de entender muito  
bem.</p>
<p>A sra. van Daan gosta de nos ver juntos. Mas hoje perguntou um tanto trocista:</p>
<p>- Posso deixar-vos sós lá em cima?</p>
<p>- claro que pode, - protestei - A senhora quer ofender-me?</p>
<p>De manhã à noite folgo em ver o Peter.</p>
<p>Tua Anne</p>

<h2>Segunda-feira, 12 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Leio no rosto do Peter que pensa tanto em mim como eu nele. Ontem à noite aborreci-me  
terrivelmente quando a sra. van Daan disse, toda trocista:</p>
<p>- Olhem o grande pensador!</p>
<p>O Peter corou, ficou encavacado, e a mim apeteceu-me saltar à cara da senhora.</p>
<p>Porque é que falam sem ser preciso? Não calculas como sofro por vê-lo assim tão só.  
compreendo-o como se fosse eu própria a viver a sua vida, sinto-lhe o desespero quando discutem e se zangam junto dele,  
noto o vazio em que ele mergulha. Pobre Peter! Como tu necessitas de amor!</p>
<p>Disse-me que não precisava de amigos: ainda trago nos ouvidos a dureza destas palavras.  
Como está enganado!</p>
<p>Julgo que não acredita no que disse. Quer por força parecer uma pessoa indiferente, não  
mostrar os seus sentimentos.</p>
<p>Quanto tempo te quererás assim enganar, Peter? Não se seguirá a este esforço  
sobre-humano uma tremenda reacção?</p>
<p>Oh, Peter, se me deixasses ajudar-te! Os dois juntos vencíamos a nossa solidão.</p>
<p>Ando sempre a cismar, mas não o digo a ninguém.</p>
<p>Sinto-me feliz quando o vejo a ele e quando vejo o Sol brilhar.</p>
<p>Ontem, ao lavar o cabelo, estava terrivelmente endiabrada.</p>
<p>Sabia que ele se encontrava no quarto ao lado.</p>
<p>Não tenho culpa : mas quanto mais calada e mais séria estou no íntimo mais espalhafato  
tenho de fazer. Quem será o primeiro a descobri-lo e a quebrar a armadura?</p>
<p>Ainda bem que os van Daans não têm uma filha! A minha conquista não seria tão difícil, tão  
bela e tão esplêndida se não fosse a atracção do sexo oposto!</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>P. S.</p>
<p>Bem sabes que te escrevo tudo com a máxima franqueza. Por isso vou ainda confessar-te  
que só vivo agora dos nossos encontros. Quem me dera saber se ele também me espera com a mesma ansiedade. Fico  
radiante quando sinto as suas tímidas tentativas de uma aproximação.</p>
<p>Sei que ele gostava tanto como eu de abrir, finalmente, o coração. Não adivinha que é  
precisamente a sua falta de jeito que me encanta.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 13 de Março de 1944</h2>
<p>Querida Kitty :</p>
<p>Quando me ponho a pensar na minha vida de 1942, tudo me parece irreal. Essa vida era  
vivida por uma outra Anne, diferente desta que tem, agora, tanto juízo.</p>
<p>Era uma vida boa, ai!, se era! Tantos admiradores como os dedos das mãos, por aí vinte  
amigos e conhecidos, a aluna favorita de quase todos os professores, amimalhada pelos pais, sempre doces e guloseimas,  
dinheiro que chegava - que mais queres? Talvez queiras perguntar-me como eu conseguia que todos gostassem tanto de  
mim.</p>
<p>Se o Peter diz que tenho &quot;charme&quot; talvez não tenha bem razão. Os professores  
gostavam mas era das minhas respostas vivas, das minhas observações cómicas, da minha cara sempre a sorrir e do meu  
olhar crítico, divertido e ameno, não era mais nada. Eu gostava do &quot;flirt&quot;, era brincalhona e alegre. Mas tinha  
também algumas boas qualidades que me davam a garantia de não cair em desgraça com ninguém : era trabalhadora,  
franca e sincera.</p>
<p>Nunca impedia que alguém, fosse quem fosse, copiasse os meus exercícios, não era  
vaidosa e repartia sempre os meus doces com os outros. Quem sabe se a admiração de que gozava não faria de mim uma  
pessoa petulante? Talvez não tenha sido nada mau que eu, de repente- no auge da festa, digamos - fosse bruscamente  
atirada para a realidade; mas sempre me levou mais de um ano a habituar-me a não ser admirada.</p>
<p>Como é que me chamavam na escola, onde eu estava sempre à frente em todas as partidas  
e brincadeiras? &quot;A cabecilha&quot;. E eu nunca tinha mau génio ou má disposição.</p>
<p>Por isso não era de admirar que todos gostassem de me acompanhar e fossem simpáticos e  
atenciosos.</p>
<p>Agora vejo essa Anne como uma rapariguita simpática mas superficial, que nada tem de  
comum comigo. O Peter disse, e muito bem:</p>
<p>-Quando eu te encontrava, via-te sempre com dois ou três rapazes e com um bando de  
raparigas, sempre a rir e divertida. Eras o centro.</p>
<p>O que resta dessa rapariga? Ainda não me esqueci de rir e de dar respostas. Ainda sei  
criticar as pessoas e, talvez até melhor do que antes, sei namoriscar se... me apetecer. Gostava de voltar a viver assim, só  
por uma tarde, uns dias, ou uma semana, despreocupada, mas no fim da semana estaria saturada e ficaria grata à primeira  
pessoa que me aparecesse a falar em coisas sérias. Não preciso de admiradores mas sim de amigos; não preciso de  
adoradores em troca de um sorriso mas sim de alguém que dê valor à minha maneira de ser e ao meu carácter. Sei que  
assim terei menos gente à minha volta. Mas não importa, o principal é que me fiquem algumas pessoas de carácter.</p>
<p>E, vistas bem as coisas, eu não era inteiramente feliz naquele tempo. Sentia-me muitas  
vezes só, mas como andava sempre atarefada, não reflectia nisso e divertia-me o mais que podia. Consciente ou  
inconscientemente, tentava com as brincadeiras encher o vazio. Agora prefiro trabalhar. Aquele período findou  
irrevogàvelmente: o tempo da escola, despreocupado e descuidado, não volta mais. Também não quero que volte,  
ultrapassei-o. Agora, até quando estou alegre, uma parte de mim mesma conserva sempre a sua seriedade.</p>
<p>Vejo a minha vida até ao princípio deste ano como que através de uma lente impiedosa. Em  
casa, uma vida cheia de sol; 1942, a vinda para aqui, a transição brusca, as discussões, as acusações. Não tinha  
capacidade para digerir tanta coisa, apanhei um choque e só consegui manter-me mais ou menos firme manifestando  
atitudes de rebeldia.</p>
<p>Primeira parte de 1943 : a minha constante vontade de chorar, a solidão, o lento  
reconhecimento de todos os meus defeitos e de todas as minhas faltas, que eram grandes, sem dúvida, mas que os outros  
é que queriam fazer muito maiores ainda.</p>
<p>Falava a torto e a direito e fiz tentativas para conquistar o Pim só para mim, mas não o  
consegui. Então vi-me perante o difícil problema de me modificar para não ouvir mais censuras, para não me sentir  
esmagada, sob o seu peso, até ao desespero.</p>
<p>A segunda parte do ano já foi melhor. Como me ia tornando uma adolescente, já viam em  
mim uma pessoa mais ajuizada. Comecei a reflectir e a escrever histórias.</p>
<p>Concluí que já ninguém tinha o direito de me empurrar como se fosse uma bola. Queria  
formar-me segundo a minha própria vontade. Reconheci também que o pai não podia ser o meu confidente em todas as  
coisas. Só queria confiar inteiramente em mim própria.</p>
<p>Depois do Ano Novo, a segunda transformação... o meu sonho. Foi através dele que  
descobri o meu desejo de um rapaz e não de uma rapariga, o desejo de um amigo.</p>
<p>Descobri também a felicidade no meu íntimo e a minha armadura exterior feita de  
superficialidade e de alegria.</p>
<p>Pouco a pouco acalmei e comecei a sentir uma ânsia sem limites de tudo o que é bom e  
belo.</p>
<p>Quando, à noite, estou na cama e remato a oração com estas palavras: &quot;Agradeço-te  
o bem, o amor e a beleza&quot;, então todo o meu ser rejubila. Ponho-me a pensar em tudo o que foi &quot;o bem&quot; : a  
nossa fuga para aqui, a minha saúde; e no &quot;amor&quot;: o Peter e tudo aquilo que é tão delicado e sensível que  
ambos ainda não ousamos tocar-lhe, mas que um dia virá-o futuro, a felicidade.</p>
<p>E penso na &quot;beleza&quot; que envolve o Mundo: a natureza, a arte, a grandeza e tudo  
o que a isto está ligado.</p>
<p>Não penso na miséria mas em tudo o que é terno e maravilhoso.</p>
<p>É nisto que reside em grande parte a diferença entre a mãe e eu. Quando alguém está  
triste, ela aconselha: &quot;lembra-te da miséria que vai pelo Mundo e sê grata por tu não a sofreres&quot;. Eu digo:  
&quot;vai e procura os campos, a natureza e o Sol: vai, procura a felicidade em ti e em Deus. Pensa no que é belo e que se  
realiza em ti e à tua volta, sempre e sempre de novo&quot;.</p>
<p>Acho o conselho da mãe errado, pois, o que pode fazer alguém que se sente infeliz?  
Perder-se na miséria? Acho que alguma coisa de belo resta aos próprios. tÉr-se-á perdido a liberdade e alguma coisa de  
nós. Mas devemos agarrar-nos e reencontrar-nos-emos a ti e a Deus, de novo. Aquele que é feliz, espalha felicidade.</p>
<p>Aquele que teima na infelicidade, que perde o equilíbrio e a confiança, perde-se na  
vida.</p>
<p>Tua Anne</p>
<h2>Domingo, 18 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Ultimamente não tenho tido paciência para estar sentada à minha mesa. Gosto de conversar  
com o Peter e só tenho receio de que ele se mace com isso. Já me contou muitas coisas da sua vida, dos seus pais e de si  
próprio.</p>
<p>Mas eu ainda queria que ele me contasse mais.</p>
<p>Depois pergunto a mim mesma porque é que espero tanto dele. Antigamente ele achava-me  
insuportável e eu pagava-lhe na mesma moeda. Mas as coisas mudaram.</p>
<p>Se com ele, no entanto, ainda nos pudermos tornar amigos íntimos, suportaria muito melhor  
esta vida de isolamento. Não quero excitar-me mais. Estou a pensar de mais nele e não tenho o direito de te vir importunar  
a ti, só por me sentir tão obcecada.</p>
<p>Sábado, à tarde, fiquei, depois de uma série de notícias tristes, tão mal disposta e confusa  
que me deitei na cama.</p>
<p>Só Queria dormir e não pensar em nada. Dormi até às quatro horas depois tive de ir ao  
quarto do Pai.</p>
<p>foi fácil respondér às perguntas da mãe porque fora que me tinha deitado. Disse que tinha  
dores de cabeça e não menti. É que eu tinha dores de cabeça... na alma.</p>
<p>Suponho que gente normal, raparigas normais, adolescentes da minha idade, me achariam  
provàvelmente absurda por eu me lamentar tanto. Mas a ti digo tudo o que me preocupa, e depois, durante o dia, sou  
atrevida, para não precisar de responder às perguntas e para evitar aborrecimentos.</p>
<p>A Margot é carinhosa comigo e talvez gostasse de ser a minha confidente, mas não lhe  
posso dizer tudo.</p>
<p>É simpática e boa e bomita, mas um bocadinho académica quando conversamos sobre  
coisas profundas. Ela procura compreender-me, não há dúvida nenhuma, reflecte mesmo sobre a sua irmã maluquinha,  
fixa-me com os olhos de examinadora quandu digo isto ou aquilo e, provàvelmente, pensa com os seus botões :</p>
<p>-Estará ela a representar ou será sincera?</p>
<p>Estamos sempre juntas e eu não queria ter a minha confidente sempre tão próximo.</p>
<p>Quando sairei eu deste labirinto de pensamentos?</p>
<p>Quando haverá calma e paz no meu coração?</p>
<p>Tua Anne</p>
<h2>Terça-feira, 19 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Talvez te entretenha a ti - a mim isto já não me interessa - se te contar o que hoje vamos  
comer. Neste momento estou (a mulher da limpeza encontra-se lá em baixo nos escritórios) à mesa dos van Daans, coberta  
com um oleado.</p>
<p>Aperto o nariz e a boca com um lenço perfumado-o perfume ainda é do tempo de antes do  
&quot;mergulho&quot;. Esta maneira de contar deve parecer-te aborrecida. Vou começar outra vez. Como os nossos  
fornecedores foram apanhados por causa dos cartões &quot;negros&quot; do racionamento e outras coisas no género, já  
não temos cartões e, portanto, nenhumas gorduras. A Miep e o Koophuis estão doentes, a Elli não pode sair para fazer as  
compras e, por consequência, a nossa disposição é desconsoladora e a comida também. Para amanhã já não temos um  
pedacinho de pingue, para já não falar de manteiga ou de margarina.</p>
<p>Acabaram-se as batatas fritas ao pequeno almoço (para substituir o pão). Agora comemos  
papinhas. A sra. van Daan tem medo de que morramos de fome e, felizmente, conseguiu arranjar um bocadinho de leite  
&quot;negro&quot;. O nosso almoço: feijão de conserva de barrica! Daí as minhas providências que tomei com o lenço. É  
incrível como o feijão cheira mal depois de ter estado guardado durante um ano. Todo o quarto cheira a uma mistura de  
ameixas podres, desinfectante e ovos podres. Brrr! Só de pensar que tenho de comer aquilo, já fico enjoada. Ainda por  
cima as nossas batatas têm uma doença esquisita e de cada balde cheio de &quot;pommes de terre&quot; metade é  
atirada para o lixo. Ao descascá-las entretemo-nos a diagnosticar as mais variadas doenças e já vimos casos de cancro,  
varíola e sarampo.</p>
<p>Podes crer que não é fácil viver-se &quot;mergulhado&quot; no quarto ano de guerra. Quem  
nos dera que esta miséria acabasse!</p>
<p>Com franqueza, eu ainda aguentava a má comida, se o resto fosse mais agradável. Mas o  
mal está em que todos nós, com a vida monótona que levamos, ficamos nervosos.</p>
<p>Aqui tens as opiniões de cinco &quot;mergulhados&quot; sobre a nossa vida:</p>
<p>Sra. van Daan:-Estou farta de fazer de criada de cozinha. Mas quando não tenho nada que  
fazer aborreço-me.</p>
<p>Portanto, ponho-me a cozinhar. Mas cozinhar sem gorduras é inconcebível, só o cheiro  
põe-me doente. Ainda por cima todos me agradecem o trabalho com má cara e a resmungar. Sou o carneiro preto do  
rebanho e tenho culpa de todo o mal que acontece. Além disso, penso que a guerra está a caminhar mal e se calhar os  
alemães ainda vão vencer. Tenho medo de que morramos todos de fome.</p>
<p>E ainda querem que eu esteja bem disposta.</p>
<p>Sr. van Daan:-Preciso de fumar, de fumar, de fumar.</p>
<p>Assim suporto tudo: a política, a comida e o mau génio da minha Kerli. Masjá que não tenho  
cigarros, apetecia-me, ao menos, um bocado de carne. Estou sempre a dizer que vivemos miseràvelmente, nada me serve,  
há discussões por tudo e por nada e acho a Kerli estúpida.</p>
<p>A sra. Frank:-Mas a comida não é assim coisa tão importante. Só queria uma fatia de pão de  
centeio. Estou com fome. Se eu fosse a sra. van Daan já tinha desabituado o meu marido de fumar tanto. Faz o favor,  
dê-me um cigarro para acalmar os nervos. Os ingleses têm os seus defeitos mas a guerra está a caminhar bem. Ainda bem  
que posso falar à vontade e que não estou presa na Polónia.</p>
<p>Sr. Frank:-Acho que tudo vai bem, não preciso de nada. Do que necessitamos é de calma,  
de paciência. Logo que me não faltem as batatas estou satisfeito, mas não se esqueçam de guardar algumas da minha  
ração para a Elli.</p>
<p>O sr. Dussel:-Tenho de concluir a tese antes de mais nada. A política? Essa vai às mil  
maravilhas! Acho impossível que nos descubram aqui. Eu...</p>
<p>Eu, eu, eu...</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 15 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Todo o santo dia ouço : se acontecer isto ou aquilo teremos as maiores dificuldades... e se  
aquela rapariga ficar doente, já não temos mais ninguém no Mundo... e se...</p>
<p>Já sabes a lenga-lenga. Pelo menos já deves conhecer bastante esta gente do anexo para  
poderes adivinhar o que andam a dizer.</p>
<p>A causa desses &quot;se, se...&quot; é a seguinte: o sr. Kraler foi convocado para um  
&quot;campo de trabalho&quot;, a Elli está terrivelmente constipada, a Miep ainda se não levantou da gripe e o sr.  
Koophuis teve outra vez uma hemorragia e desmaiou! Um chorrilho de desgraças.</p>
<p>O pessoal do armazém tem feriado amanhã. Se a Elli tiver de ficar em casa, a porta ficará  
fechada e temos de fazer muito pouco ruído para que os vizinhos não desconfiem.</p>
<p>O Henk deve vir à uma hora para olhar pelos &quot;abandonados&quot; e para representar  
o papel de guarda de jardim zoológico. Hoje, à hora do almoço, contou-nos, pela primeira vez desde há bastante tempo,  
coisas do grande mundo lá de fora. Devias ter visto como o ouvimos todos com o máximo interesse. Há um quadro que se  
chama &quot;Avòzinha conta histórias&quot;. O nosso grupo deve ter tido o mesmo aspecto. Falou, falou, com muitos  
pormenores e pormenorinhos, e não se esqueceu de contar-nos coisas sobre comidas e do médico da Miep por quem  
perguntámos.</p>
<p>-Médico? Não me falem desse médico! Hoje de manhã telefonei-lhe, mas só consegui que  
um assistentezinho viesse ao telefone. Pedi-lhe uma receita contra a gripe. Disse-me que, entre as oito e as nove, podia ir  
buscá-la. Quando se trata de uma gripe mais grave, suponho que o médico vem pessoalmente ao telefone para dizer:</p>
<p>&quot;Mostre a língua... diga aaahhh... sim, senhor, ouço bem, tem a garganta inflamada.  
Vou transmitir a receita à farmácia. Depois pode ir lá buscar o remédio. Bom dia!&quot; Lindo serviço, não há dúvida.  
Consultas exclusivamente pelo telefone!</p>
<p>Mas podemos acusar os médicos? Ao fim e ao cabo cada pessoa só tem duas mãos e,  
infelizmente, existem agora muitos doentes e muito poucos médicos. Mas não pudemos deixar de nos rir, quando o FIenk  
representou aquela conversa ao telefone. Imagino como é diferente, agora, a sala de espera de um médico. Decerto já não  
desprezam só os doentes da &quot;caixa&quot;, como era costume.</p>
<p>Agora devem desprezar-se as pessoas que não sofrem de nada a sério mas que gostam de  
se queixar. Provàvelmente falam-lhes assim:</p>
<p>-Que é que queres? Vai para o fim da bicha, que temos agora de tratar primeiro os  
autênticos doentes.</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 16 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>O tempo está maravilhoso, indescritivelmente maravilhoso. Hei-de ir ao sótão.</p>
<p>Agora sei por que sou mais irriquieta do que o Peter.</p>
<p>Ele tem um quarto só para ele, onde pode sonhar, pensar, dormir. Eu sou empurrada de um  
quarto para o outro.</p>
<p>Raras vezes estou sozinha no quarto que partilho com o Dussel, e tenho sempre tanto  
desejo de estar só! Por isso fujo a cada passo lá para cima. Uma vez ali e contigo, Kitty, posso, por pouco tempo, ser eu  
mesma. Mas não me vou queixar, pelo contrário, vou ser corajosa. Os outros, felizmente, nada percebem do que se passa  
comigo, porque é que sou mais fria para com a mãe, menos meiga com o pai. Falo muito pouco com a Margot sobre as  
minhas coisas. Tenho de conservar a minha segurança exterior.</p>
<p>Não é preciso que os outros fiquem a conhecer a confusão do meu íntimo, uma espécie de  
luta entre o desejo e a razão. Até agora a razão tem sido sempre vencedora, mas não chegará o dia em que sucumba? às  
vezes tenho medo disso, outras vezes desejo que assim aconteça.</p>
<p>É pena não poder falar sobre estas coisas com o Peter , mas eu sei que é a ele que  
compete começar. Entristece-me não poder continuar as minhas conversas dos sonhos durante o dia e que as aventuras  
sonhadas não se tornem realidade. Sim, Kitty, é verdade, a Anne não regula bem.</p>
<p>Mas não te esqueças : vivo numa época louca e em circunstâncias loucas. Que sorte a  
minha poder escrever o que penso e sinto. Se não fosse isto, sufocava, de certeza.</p>
<p>O que pensará o Peter de tudo isto? Oxalá possa dizer-mo em breve! Deve ter adivinhado  
alguma coisa, porque aquela Anne que ele conhecia até há pouco não lhe agradava com certeza. Pode ele, que tanto  
aprecia a calma e a paz, simpatizar com a minha vivacidade e inquietação?</p>
<p>Será ele o único no Mundo que conseguiu ver o que está por detrás da minha máscara de  
pedra? Não é velha regra o amor nascer muitas vezes da compaixão e as duas coisas confundirem-se? Será o meu caso?  
É que tenho tanta pena dele como de mim própria.</p>
<p>Não sei, palavra que não sei, como hei-de começar a falar nisto! E se eu não sei muito  
menos ele, a quem tanto custa exprimir-se. Se lhe pudesse escrever! Então ficaria a saber o que lhe queria dizer. Mas falar  
é muito difícil!</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 17 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Uff! Pelo anexo passa uma onda de alívio. O Kraler está livre, a Elli não consentiu que a sua  
constipação piorasse e a impedisse de cumprir os seus deveres. Tudo voltou à velha ordem. Só a Margot e eu estamos um  
tanto cansadas dos nossos pais. Não me compreendas mal, por favor.</p>
<p>Bem sabes que não me entendo, neste momento, muito bem com a mãe, mas do pai gosto  
sempre na mesma, e a Margot gosta de ambos. Mas a gente na nossa idade queria, por vezes, decidir sózinha sobre as  
suas coisas e a sua vida, e não depender sempre dos outros. Se vou para cima, perguntam o que vou lá fazer; não me  
deixam comer sal às refeições; todas as noites, é garantido, a mãe pergunta-me se ainda não me quero despir.</p>
<p>Cada livro que me apetece ler tem de ser primeiro apreciado por eles. Bem sei que a  
censura não é rigorosa e posso ler quase tudo, mas o que nos aborrece é o controle constante e também as observações e  
as anotações. Pelo que me respeita, já não sou a criancinha &quot;beijinho aqui, beijinho ali&quot;, e acho todos os  
diminutivos de carinho bastante artificiais. Em poucas palavras: durante algum tempo aguentar-me-ia bem sem os pais,  
sempre cheios de cuidados carinhosos.</p>
<p>Ontem a Margot disse :</p>
<p>- É quase ridículo! A gente já nem pode apoiar a cabeça na mão sem que perguntem logo se  
temos dores de cabeça ou se não nos sentimos bem!</p>
<p>É uma desilusão para nós duas verificarmos que muito pouco resta do nosso convívio  
familiar tão íntimo. A causa disto é haver entre nós relações um pouco erradas. Com isto quero dizer que eles nos tratam  
como crianças e não se lembram de que estamos mentalmente mais desenvolvidas do que as outras raparigas da nossa  
idade. Embora eu só tenha catorze anos, sei muito bem o que quero e sei também quem tem razão. Tenho a minha opinião,  
as minhas concepções, os meus princípios. Talvez isto soe a vaidade, mas já não me sinto criança, sinto-me despegada  
seja de quem for. Sei que discuto melhor do que a mãe, que sou mais objectiva e não tão exagerada, sei que tenho mais  
ordem nas minhas coisas e que sou mais habilidosa e, por isso-, se quiseres, ri-te de mim!-em muitas coisas superior a ela.  
Para amar alguém, a primeira condição é poder admirar-admirar e respeitar. Tudo seria melhor se o Peter fosse meu. A ele  
posso admirá-lo em muitas coisas. É bom rapaz, um rapaz às direitas!</p>
<p>Tua Anne</p>
<h2>Domingo, 19 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Ontem foi um dia importante para mim. Tinha resolvido falar abertamente com o Peter. Antes  
de nos sentarmos à mesa, perguntei-lhe baixinho:</p>
<p>-Estudas estenografia logo à tarde, Peter?</p>
<p>-Não, senhora-disse ele.</p>
<p>-Gostava de falar contigo.</p>
<p>-Está bem.</p>
<p>Por atenção, ainda fiquei, depois de termos lavado a louça, um bocado com os pais dele.  
Depois fui ter com o Peter. Ele estava do lado esquerdo da janela, eu pus-me à direita. Fala-se melhor na penumbra do que  
em plena luz. Creio que o Peter é da mesma opinião.</p>
<p>Falámos sobre tantas coisas que não me é possível escrever tudo, mas foi maravilhoso,  
nunca vivi nada tão maravilhoso desde que entrei nesta casa. Alguma coisa vou reproduzir-te. Falámos dos eternos  
conflitos cá em casa, que eu agora vejo com olhos diferentes, e do afastamento íntimo dos nossos pais. Contei-lhe coisas  
do meu pai, da minha mãe, da Margot e de mim. De repente, ele perguntou-me :</p>
<p>- Vocês beijam-se quando dizem &quot;boa-noite&quot; uns aos outros?</p>
<p>- Pois claro, beijamo-nos muitas vezes. Vocês não?</p>
<p>-Nós não. Poucas vezes tenho dado beijos a alguém.</p>
<p>- E no dia dos teus anos?</p>
<p>- Ah sim, nesse dia beijamo-nos.</p>
<p>Dissemos que era impossível falar sobre os nossos problemas aos pais, e ele confessou  
que os dele queriam muito ser os seus confidentes mas que não podiam sê-lo. Contei-lhe que chorava de noite, na cama,  
quando tinha desgostos e ele disse-me que ia para o sótão praguejar. Também lhe contei que a Margot e eu só agora nos  
chegámos a conhecer bem, mas que não podemos confiar tudo uma à outra por estarmos próximas de mais. E falámos de  
muito mais coisas e ele era exactamente como eu tinha imaginado.</p>
<p>Depois voltámos a falar de 1942, de como tínhamos sido tão diferentes e que, ao princípio,  
não gostávamos um do outro. Nessa altura ele achava-me espevitada e desagradável e eu não encontrava nada nele que  
me interessasse.</p>
<p>Parecia-me incompreensível que ele nem sequer procurasse namoriscar mas agora estou  
contente por isso mesmo.</p>
<p>Disse-me que procurava isolar-se, e eu expliquei-lhe que entre a minha vivacidade e a sua  
calma quase não havia diferença porque eu desejava tanto o sossego como ele e só encontrava um bocado de paz junto  
do meu diário.</p>
<p>Ele ainda disse ter sido uma felicidade os meus pais virem com as filhas para o anexo, e eu  
disse-lhe que me sentia feliz por ele estar cá e que o compreendo na sua solidão e nas suas relações com os pais e que  
gostaria de o ajudar.</p>
<p>- Mas tu estás constantemente a ajudar-me.</p>
<p>- Eu ajudar-te, em quê?-perguntei espantada.</p>
<p>- Com a tua alegria.</p>
<p>Foi a coisa mais bonita que me podia ter dito. Foi mesmo maravilhoso. Sei agora que me  
aprecia como boa camarada e, para já, sinto-me satisfeita. É-me difícil explicar em palavras a minha felicidade e gratidão. E  
tenho de te pedir desculpa, Kitty, por o meu estilo não estar hoje à altura.</p>
<p>Escrevi tudo conforme me vinha à cabeça. Tenho a sensação de partilhar com o Peter um  
segredo. Todas as vezes que olha para mim, ri-se ou pisca os olhos, e é como se tudo se iluminasse à minha volta. Oxalá  
que nada se modifique e que ainda possamos passar juntos muitas horas felizes.</p>
<p>Da tua grata e feliz Anne</p>
<h2>Segunda-feira, 20 de Março de 1944</h2>
<p>Querida Kitty :</p>
<p>Hoje de manhã o Peter perguntou-me se não ia ter com ele à tardinha e acrescentou que  
não o estorvava.</p>
<p>Disse que no quarto dele tanto havia lugar para um como para dois. Respondi-lhe que não  
podia ir todas as tardes porque os outros não achavam bem, mas ele disse que não me devia importar com isso. Então  
prometi ir no sábado e pedi-lhe que me avisasse sempre que houvesse luar.</p>
<p>- Combinado-disse ele-, quando houver luar vamos lá para baixo contemplá-lo.</p>
<p>Entretanto, caiu uma sombra sobre a minha felicidade.</p>
<p>Já desconfiava há bastante tempo de que a Margot também gosta do Peter. Não sei se  
gosta muito mas, de qualquer maneira, não me sinto à vontade. Sempre que vou para junto do Peter, causo-lhe decerto um  
desgosto.</p>
<p>Acho muito delicado da parte dela procurar não mostrar a sua dor. Se fosse eu, ficava fora  
de mim de ciúmes.</p>
<p>Mas a Margot diz que me não apoquente e que não tenha pena dela.</p>
<p>- Mas não acho agradável que fiques assim de fora, como uma terceira pessoa.</p>
<p>- Estou habituada-disse ela um tanto amargamente.</p>
<p>Ainda não tive coragem de contar isto ao Peter. Talvez lhe conte qualquer dia. Por agora,  
temos de fazer outras confidências. A mãe ontem ralhou-me. Mereci-o bem, pois levei longe de mais a minha indiferença  
para com ela. Hei-de fazer os possíveis para me dominar; vou tentar ser amável e não responder torto. Também o Pim está  
menos afectuoso. Pretende não tratar-me como uma criança e cai no extremo oposto: é frio de mais. Vamos a ver o que sai  
disto tudo!</p>
<p>Basta. Quero estar sempre a olhar para o Peter, estou a transbordar.</p>
<p>Uma prova da generosidade da Margot: recebi hoje, 20 de Março de 1944, esta carta:</p>
<p>Anne, quando ontem te disse que não tinha ciúmes de ti só fui 50 por cento sincera. A  
verdade é esta: não tenho ciúmes nem de ti nem do Peter, mas tenho pena de mim por não ter encontrado ainda ninguém -  
e não vejo jeito de encontrar por enquanto - com quem possa falar abertamente sobre o que penso e sinto. Não vos invejo  
por terdes confiança um no outro. Isso compensa-te um pouco de tudo aquilo de que estás privada aqui e que outras  
raparigas possuem como coisa natural.</p>
<p>Por outro lado sei que não me teria aproximado tanto do Peter como tu, pois só posso fazer  
confidências a alguém muito intimo, a uma pessoa que me compreenda sem ser preciso entrar em grandes pormenores. E  
esse alguém tinha de ser intelectualmente superior a mim, e não é o caso do Peter. Mas compreendo que vocês dois se  
entendam muito bem. Por isso não penses que me estás a roubar qualquer coisa ou que eu fique prejudicada, porque não  
é assim.</p>
<p>Tu e o Peter só lucram com o vosso convívio.</p>
<p>A minha resposta:</p>
<p>Querida Margot, a tua carta foi muito gentil mas, mesmo assim, não me sinto apaziguada e  
não sei se é que isto alguma vez pode acontecer.</p>
<p>Não tenho tanta intimidade com o Peter como estás a imaginar. Simplesmente sentimo-nos  
mais à vontade quando falamos ao fim da tarde, junto da janela aberta, do que durante o dia, à luz do Sol.</p>
<p>É mais fácil murmurar os sentimentos do que dizê los em voz alta.</p>
<p>Suponho que sentes pelo Peter uma espécie de afeição de irmã e que gostarias de o ajudar  
tal qual como eu. Talvez ainda venhas a ajudá-lo sem que vocês tenham a intimidade que nós sonhamos. A confiança tem  
de ser recíproca. Julgo que é esta a razão por que não me posso abrir com o pai inteiramente.</p>
<p>Não falemos mais sobre o assunto. Se houver alguma coisa a dizer, escreve-me. É-me mais  
fácil exprimir-me por escrito.</p>
<p>Talvez não saibas quanto te admiro. Oxalá que eu tenha dentro de mim um pouco de  
bondade do pai e da tua, pois nisto é que sois muito parecidos.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 22 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Ontem recebi esta carta da Margot:</p>
<p>Querida Anne:</p>
<p>A tua carta deu-me a impressão de que sentes remorsos quando vais ter com o Peter para  
trabalhar ou falar com ele. Mas não tens motivos para isso. O Peter não é pessoa que pudesse servir-me de confidente.  
Tens razão quando dizes que o vês como um irmão, mas... como um irmão mais novo! Dá-me sempre a ideia de que tanto  
ele como eu estamos a estudar-nos mutuamente para verificar, se nós, talvez um dia, ou talvez nunca, poderemos conviver  
como irmãos. Mas por enquanto ainda é cedo.</p>
<p>,Não tenhas pena de mim, por fanor. Goza a amizade que, felizmente, encontraste.</p>
<p>Entretanto acho a vida cada vez mais bela. Acredita, Kitty, o velho anexo ainda há-de  
assistir a um verdadeiro grande amor. Não quero saber, por ora, se, mais tarde, casarei com o Peter, porque não sei como  
ele será quando adulto. Também não sei se depois ainda gostaremos tanto um do outro. Que o Peter agora gosta de mim,  
já não tenho dúvidas. Mas não sei bem que espécie de amor é o seu. Ser uma boa camarada, aprecia-me como rapariga  
ou como irmã? Ainda não consegui descobrir.</p>
<p>Quando me disse, ao falar nas zangas entre os seus pais, que o ajudo muito, fiquei  
satisfeita e compreendi que a nossa amizade tinha dado um grande passo em frente.</p>
<p>Ontem perguntei-lhe o que faria ele se aqui vivessem uma dúzia de Annes que, a cada  
passo, fossem ter com ele.</p>
<p>Respondeu:</p>
<p>- Se fossem todas como tu, não seria nada mau.</p>
<p>Recebe-me sempre muito bem e vê-se que gosta de me ver aparecer. Está a estudar  
francês com mais entusiasmo, até estuda à noite na cama, depois das dez horas.</p>
<p>Oh, quando penso no sábado, nas nossas conversas, na delícia de cada momento,  
sinto-me, pela primeira vez, satisfeita comigo própria. Não me arrependo de nenhuma das palavras que pronunciei, ao  
contrário do que sucede quase sempre. Ele é muito bonito quando se ri e também quando está calado, e é simpático e  
bom. A meu ver deve ter ficado espantado ao verificar que, afinal, não sou a rapariga mais superficial que existe na Terra  
mas sim uma criatura sonhadora como ele e com as mesmas dificuldades a vencer.</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>A minha resposta</p>
<p>Querida Margot:</p>
<p>Parece-me que o melhor é deixarmos correr as coisas.</p>
<p>Qualquer dia o Peter e eu havemos de tomar uma decisão, de uma maneira ou de outra.  
Como isto se vai passar, não sei, mas nestas coisas só costumo pensar na própria ocasião. Uma coisa vou fazer com  
certeza, caso o Peter e eu selemos definitivamente a nossa amizade: vou contar-lhe-e não te peço sequer licençÇa para  
isso que gostas também dele e que pode contar contigo sempre que for preciso. Não sei o que o Peter pensa a teu  
respeito, mas hei-de perguntar-lhe. Tenho a certeza de que pensa o melhor. Podes ir ter sempre connosco, a qualquer sítio  
onde estejamos. Nunca nos estorvarás. E repara, ele e eu chegámos a acordo sem termos falado, só fazemos confidências  
ao anoitecer, quando escurece...</p>
<p>Sê corajosa. Eu também o sou. A tua vez há-de chegar mais depressa do que imaginas.</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 23 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>As coisas cá no anexo vão correndo melhor. O nosso fornecedor &quot;negro&quot; já saiu  
da prisão.</p>
<p>A Miep voltou ontem, a tosse da Elli melhorou, só o Koophuis tem de ficar ainda em casa.  
Ontem caiu, aqui perto, um avião. Os tripulantes conseguiram saltar, o aparelho despenhou-se sobre uma escola.  
Felizmente as crianças não estavam lá. Houve incêndio e também alguns mortos. Os alemães metralharam os  
pára-quedistas.</p>
<p>A população ficou indignada com tamanha cobardia.</p>
<p>Nós, isto é, as mulheres medrosas, assustámo-nos muito.</p>
<p>Acho que isto de metralhar é... nojento.</p>
<p>Vou agora muitas vezes tomar um pouco do ar fresco da noite no quarto do Peter. É bom  
estar sentada junto dele e olhar através da janela. O sr. van Daan e o Dussel fazem pouco quando subo.</p>
<p>Dizem: &quot;A segunda pátria da Anne&quot; ou &quot;Não acham que fica mal a um jovem  
receber senhoras no seu quarto a estas horas e no escuro?&quot;</p>
<p>O Peter mostra uma indiferença espantosa em face de tais observações. A mãe dele anda  
também curiosa e gostava de saber quais os assuntos das nossas conversas, mas não faz muitas perguntas porque receia  
uma resposta pouco amável. O Peter disse que os adultos têm mas é inveja por sermos novos e que se aborrecem por nós  
não ligarmos importância à sua má-língua. Por vezes vem cá abaixo buscar-me, mas, apesar de procurar dominar-se, fica  
sempre corado como um pimento e quase não consegue falar. Que sorte tenho eu por não corar com tanta facilidade!</p>
<p>Deve ser uma maçada.</p>
<p>O pai diz que sou uma pretensiosa, mas não é verdade.</p>
<p>Sou apenas um pouco vaidosa. Até agora ninguém me tinha dito que o meu físico era  
agradável, com excepção de um rapaz da escola que me achava bonita quando me ria. Mas o Peter fez-me ontem um  
autêntico cumprimento.</p>
<p>Vou reproduzir-te a conversa. Eu andava intrigada por ele repetir tantas vezes:</p>
<p>- Ri-te mais uma vez!</p>
<p>Perguntei-lhe:</p>
<p>- Porque queres que me ria tantas vezes?</p>
<p>- Porque ficas muito linda. Aparecem-te covinhas nas faces. Como é que fazes isso?</p>
<p>- Já nasci assim. É, de resto, a única coisa bonita que possuo.</p>
<p>- Por amor de Deus, isso não é verdade!</p>
<p>- Escusas de me contradizer. Sei que não sou bonita.</p>
<p>Nunca fui nem serei.</p>
<p>- Não estou de acordo. Acho-te bonita.</p>
<p>- Não é verdade.</p>
<p>- Se eu to digo, podes acreditar que é mesmo.</p>
<p>Claro, eu então disse-lhe que o achava também bonito.</p>
<p>Toda a gente nos enche os ouvidos com ditos sobre a nossa amizade. Mas não fazemos  
caso. As observações são todas chochas. Esquecer-se-ão certos pais do seu tempo da juventude?</p>
<p>Quer-nos parecer que sim. Tomam-nos a sério quando dizemos coisas para rir e riem-se de  
nós quando falamos a sério.</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 27 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Na nossa &quot;história da época do mergulho&quot; a política devia ocupar um capítulo  
grande, mas como é um assunto que não me tem interessado muito, tenho-me descuidado de o tratar. Por isso vou dedicar  
esta carta à política.</p>
<p>Que haja as mais diversas maneiras de pensar é coisa evidente, que neste tempo de  
guerra, cheio de confusões, se discuta constantemente, também é lógico, mas... que as pessoas se estejam sempre a  
zangar por causa da política, é estupidez.</p>
<p>Que apostem, riam, ralhem, que façam o que lhes apeteça - por mim podem mesmo  
rebentar. Mas que não se zanguem, pois as consequências são sempre más. As pessoas que nos visitam trazem, não  
raras vezes, notícias que não passam de boatos. A rádio, até agora, tem dito a verdade. O Henk, a Miep, o Koophuis, o  
Kraler, a Elli, todos relatam os acontecimentos conforme a sua disposição, com todos os &quot;up and down&quot;. O Henk  
ainda é o mais sóbrio deles todos.</p>
<p>Aqui no anexo a disposição, no que respeita a política, é mais ou menos sempre a mesma.  
Nos debates sem fim sobre invasão, bombardeamentos, discursos de ministros, etc. etc. ouvem-se opiniões e exclamações  
&quot;Impossível!... Por amor de Deus quem me dera que já começassem. Quando acabará isto?... Formidável, magnífico,  
não podia correr melhor...&quot;</p>
<p>Optimistas, pessimistas, e não esqueçamos os realistas... todos querem impingir as suas  
opiniões e, como é velha regra, todos estão convencidos de ter razão. Uma determinada senhora aborrece-se por o marido  
ter tanta confiança nos ingleses. Por sua vez o marido ataca a dita senhora por causa das suas expressões trocistas e  
desdenhosas acerca da nação que ele mais admira. Nunca se cansam de falar neste assunto. Descobri como a coisa  
funciona: é exactamente como quando se pica uma pessoa com um alfinete e ela dá um pulo. Uso, por vezes, este  
processo. Atiro uma palavra sobre politica e toda a gente perde logo a cabeça.</p>
<p>Como se as emissões da &quot;Wehrmacht&quot; alemã e as da B. B. C. ainda não fossem  
suficientes, apareceu agora mais outra estação: a &quot;Luftlagemeldung&quot;, por vezes fascinante, por vezes uma  
desilusão. Os ingleses dão notícias da sua força aérea sem interrupção, durante o dia e a noite; os alemães procedem do  
mesmo modo para espalharem as suas mentiras. Aqui ouve-se rádio logo pela manhã cedo e depois, de hora em hora, até  
às dez da noite, por vezes até às onze, prova evidente de que os adultos têm uma santa paciência mas que, ao mesmo  
tempo, são lentos de compreensão. (há excepções, não quero ofender ninguém).</p>
<p>Acho que devia bastar uma pessoa ouvir uma ou, quando muito, duas vezes, rádio por dia.  
O programa dos operários, as emissões de rádio Orange, Frank Philips, ou Sua Majestade a Rainha-ouve-se tudo. Se não  
estão a comer ou a dormir, estão sentados junto da rádio falando de comer e de dormir e, claro está, de política. Que  
maçada.</p>
<p>Palavra, é preciso muita arte para não se ficar, desta maneira, uma velha seca e sem  
interesse.</p>
<p>Um exemplo eloquente é um discurso de Winston Churchill, a quem todos igualmente  
admiramos:</p>
<p>Domingo, nove horas. O chá já está pronto debaixo do abafador. Os hóspedes aparecem. O  
Dussel fica à esquerda do rádio, o sr. van Daan em frente, o Peter ao lado, a mãe junto do sr. van Daan, a sra. van Daan  
atrás deles, o Pim à mesa, a Margot e eu também. Os homens fumam, o Peter quase adormece de tanto esforço que faz  
para ouvir tudo. A mãe, num roupão comprido e escuro e a sra. van Daan tremem por causa dos aviões que, não fazendo  
caso do discurso, voam sobre a nossa casa a caminho do Ruhr. O pai sorve o seu chá, a Margot e eu estamos irmãmente  
unidas pelo Mouchi, que dorme estendido sobre os nossos regaços. A Margot tem &quot;bigoudis&quot; no cabelo, eu  
trago um pijama demasiado curto e apertado. Assim encontramo-nos numa intimidade agradável, pacífica. Mas já estou a  
ver o que se vai seguir. Eles começam a ficar impacientes, querem que aquilo acabe, já estão a bater com os pés, ansiosos  
por discutir sobre o discurso. Kss, Kss, Kss... é assim que se provocam uns aos outros até que tudo acaba em barulho e  
desarmonia.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 28 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Podia falar mais ainda sobre a política mas hoje tenho de contar-te uma série de outras  
coisas. A mãe proibiu-me de ir tantas vezes lá para cima porque acha que a sra. van Daan está com ciúmes. O Peter  
convidou a Margot para ir também, não sei se o fez por delicadeza ou se foi sincero. Perguntei ao pai se devo importar-me  
com os ciúmes da sra. van Daan. Ele acha que não. E agora?</p>
<p>Minha mãe está aborrecida. Ou talvez ciumenta também, quem sabe? O pai não tem inveja  
dos meus encontros com o Peter, está contente por nos darmos tão bem. A Margot acha o Peter simpático, mas  
compreende que não se pode falar a três sobre aquilo que é apenas assunto de dois.</p>
<p>A mãe supõe que o Peter anda apaixonado por mim.</p>
<p>Quem me dera que isso fosse verdade. Nesse caso estaríamos quites e podíamos falar  
ainda mais abertamente.</p>
<p>A mãe diz que ele não me larga com os olhos. E tem razão.</p>
<p>É que nós, de vez em quando, piscamos os olhos e as minhas covinhas agradam muito ao  
Peter. Mas não há nada a fazer, não é verdade?</p>
<p>Uma situação difícil. A mãe contra mim, eu contra a mãe, e o pai a fechar os olhos perante a  
luta silenciosa que nós duas travamos. A mãe está triste porque, ao fim e ao cabo, gosta de mim, e eu não estou nada triste  
porque sinto que ela não me compreende. E o Peter... Não quero renunciar ao Peter. É bom rapaz e eu admiro-o. Tudo  
pode vir a ser belo entre nós. Porque é que os adultos querem meter o nariz nisto? Felizmente que me habituei a esconder  
os meus sentimentos, pois assim consigo não deixar transparecer quanto gosto dele. Ele falará um dia? Virá a sentir a  
minha face contra a sua como aconteceu no meu sonho com o outro Peter? Ai! O Peter e o Peter são um só, agora.</p>
<p>Os outros não nos compreendem, não concebem que nos basta estarmos juntos sem dizer  
nada. Não sabem o que nos atrai um para o outro. Quando acabarão estas dificuldades?</p>
<p>Mas, pensando bem, talvez seja melhor haver obstáculos a vencer, porque o final será mais  
belo ainda!</p>
<p>Quando ele deita a cabeça sobre os braços e fecha os olhos, parece uma criança; quando  
brinca com o Mouchi, é meigo; quando carrega com os sacos de batatas ou com outros pesos, é forte; quando observa os  
bombardeamentos ou segue o rasto dos ladrões na escuridão, é corajoso; mas quando é desajeitado e se sente  
desamparado, é simplesmente um amor. Gosto mais dele quando me explica coisas do que quando quer aprender comigo.  
Achava bem que ele fosse sempre superior a mim.</p>
<p>As mães não me importam. Se, ao menos, ele falasse!</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 29 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Ontem o ministro Bolkestein disse na emissora de Orange que, depois da guerra, se havia  
de publicar uma série de diários e de cartas desta época. Aqui começaram logo a falar no meu diário. E se eu publicasse  
um romance sobre o anexo?. Não te parece interessante? Mas, com este título, toda a gente era capaz de imaginar que se  
tratava de um romance policial.</p>
<p>Basta de brincadeira, deixa-me falar a sério. Não parecerá inconcebível ao Mundo, depois  
da guerra-digamos dez anos depois-, o que nós, os judeus, contarmos sobre a nossa vida aqui, as nossas conversas e as  
nossas refeições?</p>
<p>Pois embora te tenha contado muita coisa, tu ainda só ficaste a saber uma pequena parcela  
desta vida.</p>
<p>O medo das senhoras, quando há bombardeamentos como os do Domingo passado, em  
que trezentos e cinquenta aviões ingleses lançaram meio milhão de quilos de dinamite sobre Ijmuiden e as casas  
estremeceram como as folhas com o vento. E o terror das epidemias que grassam no país! Disto ainda sabes pouco, e seria  
preciso que eu escrevesse todo o dia se quisesse fazer um relatório completo. A população forma bichas para comprar  
hortaliça ou seja o que for. Os médicos não podem visitar os seus doentes, porque lhes roubaram o automóvel ou a  
bicicleta. Ouve-se falar de pequenos furtos e de roubos em grande escala, e eu pergunto a cada passo o que foi feito da  
honestidade dos holandeses, quase proverbial?</p>
<p>Crianças dos oito aos onze anos partem os vidros das habitações alheias e tiram tudo o que  
lhes vem parar ás mãos.</p>
<p>Ninguém tem coragem de deixar ficar a sua casa abandonada durante cinco minutos, pois,  
ao voltar, pode muito bem encontrá-la vazia. Todos os dias se lêem nos jornais anúncios em que se prometem gratificações  
pela entrega de coisas roubadas, máquinas de escrever, tapetes persas, relógios eléctricos, tecidos, etc., etc. Os relógios  
das ruas são desmontados, e até se tiram os telefones das cabinas sem deixar ficar um pedaço de fio sequer.</p>
<p>Evidentemente não pode haver bom ambiente entre a população. O racionamento não  
chega. A invasão faz-se esperar, os homens têm de ir para a Alemanha. As crianças estão subalimentadas e doentes.  
Quase toda a gente usa roupa e calçado de má qualidade. Umas solas &quot;negras&quot; custam cinquenta florins. Mas  
os sapateiros raras vezes aceitam freguesia ou então levam quatro meses a compor os sapatos se estes, entretanto, não  
forem roubados.</p>
<p>Uma coisa boa: as sabotagens contra a ocupação aumentam à medida que a alimentação  
piora e as condições se tornam mais severas. Os funcionários da distribuição de víveres e de outras repartições ajudam,  
em grande parte, a população, mas também há traidores que levam gente às prisões. Contudo, felizmente, são poucos os  
holandeses que estão do lado mau.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 31 de Março de 1944</h2>
<p>Querida Kitty:</p>
<p>Ainda está muito frio, mas a maioria das famíliasjá não tem carvão. Coisa divertida, não te  
parece? Há um grande e geral optimismo porque tudo vai às mil maravilhas na frente russa. Não quero escrever muito  
sobre política mas não posso deixar de informar-te de que os russos se encontram em frente do G. Q. G. alemão e que se  
estão a aproximar da Roménia pelo Pruth; estão perto de Odessa.</p>
<p>Espera-se um comunicado especial de Estaline numa das noites mais próximas.</p>
<p>Moscovo atroa os ares com salvas. Não sei se eles acham bonito imitar assim o barulho da  
guerra ou se não conseguem expandir a sua alegria de outra maneira.</p>
<p>A Hungria está ocupada pelos alemães. Vive nesse país um milhão de judeus que, decerto,  
hão-de sofrer as consequências.</p>
<p>Aqui não aconteceu nada de especial. O sr. van Daan faz hoje anos. Recebeu dois maços  
de tabaco, café para uma chávena (foi a esposa que lho guardou desde há muito), um ponche de limão do Kraler,  
sardinhas da Miep, e de nós, água de colónia, lilases e tulipas e ainda uma torta com framboesas e groselhas quase a  
desfazer-se, por causa de a farinha e a manteiga serem de péssima qualidade, mas de sabor estupendo.</p>
<p>As más-línguas já não se preocupam tanto com o Peter e comigo. Nós dois somos bons  
amigos, estamos muitas vezes juntos e conversamos sobre os mais variados assuntos.</p>
<p>Embora falemos também de coisas delicadas, não preciso de guardar certas reservas como,  
decerto, teria de fazer com outros rapazes. Quando, por exemplo, um destes dias, veio à baila o tema sangue, falámos  
também na menstruação.</p>
<p>O Peter acha que nós, as mulheres, somos resistentes.</p>
<p>Ah! Ah! Ah! E porquê?</p>
<p>A minha vida aqui melhorou muito. Deus não me abandonou e não me há-de  
abandonar.</p>
<p>Tua Anne</p>`],

25: [`<h2>Sábado, 1 de Abril de 1944</h2><p>Querida Kitty:</p>
<p>Apesar de tudo, as coisas continuam a ser difíceis. Sabes o que quero dizer? É que queria  
ser beijada, queria esse beijo que tanto se faz esperar. Verá o Peter em mim mais do que uma boa camarada? Não significo  
outra coisa para ele? Tu bem sabes que sou forte, que sei suportar sòzinha o meu fardo e que não me habituei a procurar  
auxílio.</p>
<p>Nunca me agarrei à mãe. Mas agora sinto desejo de encostar a cabeça aos ombros do  
Peter e de ficar muito quietinha.</p>
<p>Não consigo esquecer-me do sonho em que sentia a face do Peter contra a minha. Como  
isso era belo! E ele, não terá o mesmo desejo? É tímido de mais para me confessar o seu amor? Mas porque é que me quer  
sempre ao seu lado? Porque é que não fala? Quero ser calma. Quero ser forte. Com um pouco de paciência, tudo virá. Mas  
-e isto é aborrecido-tenho quase a ideia de que ando atrás dele, por ter de ir lá para cima. Não é ele que vem ter comigo.  
Mas a culpa é da distribuição dos quartos e oxalá o Peter compreenda bem isto. Oh! Ainda há muito mais coisas que ele  
tem de compreender!</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 3 de Abril de 1944</h2>
<p>Querida Kitty :</p>
<p>Contra o meu costume, vou falar-te hoje minuciosamente da comida, pois é um problema  
que não só diz respeito ao nosso anexo mas a toda a Holanda, à Europa, e talvez ao Mundo inteiro.</p>
<p>Nos vinte e um meses que aqui vivemos, já passámos por uma série de períodos  
alimentares. Vou explicar-te o que isto quer dizer. Um &quot;período alimentar é um período em que se come sempre o  
mesmo prato de fundo e os mesmos legumes. Durante algum tempo só tínhamos salada, umas vezes com areia, outras  
vezes sem areia, umas vezes misturada com as batatas, outras vezes com as batatas à parte, assadas numa assadeira.  
Depois veio o tempo dos espinafres, depois o da couve rábano, de cenouras, pepinos, tomates, &quot;choucroute&quot;,  
etc., etc., isto depende da estação do ano. Não é nada agradável comer todos os dias choucroute ao almoço e choucroute  
ao jantar, mas quando se tem fome, come-se mesmo. Agora chegou o período mais interessante: já não recebemos mais  
legumes frescos. Agora o nosso &quot;menú&quot; da semana consiste em feijão vermelho ou sopa de ervilhas secas,  
batatas com bolinhos de farinha, puré de batata ou, quando Deus quer, alguns nabos ou cenouras meio podres, e depois,  
de novo, feijão vermelho.</p>
<p>Comemos batatas a cada refeição, a começar pelo pequeno almoço, por não haver pão  
suficiente. Para fazer sopas utilizamos, além dos feijões vermelhos, também os brancos ou batatas, ou então usamos  
sopas preparadas: &quot;Sopa Juliana&quot;, &quot;sopa da Rainha&quot; ou &quot;sopa de feijão vermelho&quot;.</p>
<p>Já não há comida nenhuma sem feijão vermelho, nem o próprio pão. à noite comemos as  
batatas com um molho de fantasia e um pouco de salada de beterraba das nossas conservas. Também quero falar-te dos  
bolinhos de farinha.</p>
<p>Fazemo-los de farinha do &quot;governo&quot; e com água e fermento.</p>
<p>Claro que ficam pegajosos e duros, pesam no estômago como pedras. É isto.</p>
<p>O grande acontecimento da semana é uma fatia de &quot;foie-gras&quot; e um pouco de  
compota para pôr no pão. Mas estamos ainda vivos e as nossas refeições frugais, pòr vezes, até nos sabem muito  
bem.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 4 de Abril de 1944</h2>
<p>Querida Kitty:</p>
<p>Durante muito tempo eu já nem sabia porque é que trabalhava. O fim da guerra está ainda  
tão longe, tão irreal, tão fantástico! Se a guerra não acabar em Setembro, não voltarei para a escola, pois não quero andar  
dois anos atrasada.</p>
<p>Os dias têm sido para mim inteiramente cheios pelo Peter. Os meus pensamentos, os meus  
sonhos, tudo tem girado à volta do Peter, de tal forma que no sábado sentia-me atordoada. Sentada ao lado dele, tive de  
fazer um esforço enorme para não chorar e, no entanto, pus-me a rir com a sra. van Daan ao fazermos um ponche de  
limão.</p>
<p>Excitei-me e parecia estar alegre mas, mal me encontrei sòzinha, vi que havia de chorar. Em  
camisa de noite ajoelhei-me no chão, rezei muito e depois chorei, a cabeça sobre os braços, acocorada no chão frio. Por  
fim voltei a mim, dominei as lágrimas e os soluços para que ninguém me ouvisse. Depois animei-me a mim própria, dizendo  
repetidas vezes: tem que ser, tem que ser, tem que ser...</p>
<p>Quase quebrada por aquela posição insólita encostei-me à borda da cama até que, pouco  
antes das dez e meia, consegui deitar-me. Acabou-se. Sim, agora tudo se acabou. Tenho de trabalhar para não ficar  
ignorante, para avançar mais tarde na vida, para vir a ser uma jornalista! Sei que serei capaz de escrever bem, alguns dos  
meus contos são bons, as minhas descrições do anexo têm humor, há passagens eloquentes no meu diário, mas... ainda  
não provei que tenho, de facto, talento. O sonho de Eva é a minha melhor história, e acho estranho que nem eu própria  
saiba explicar aonde fui buscar aquilo.</p>
<p>Uma parte de A vida de Candy também não está mal, mas o conjunto não presta.</p>
<p>Sou eu mesma o meu crítico mais severo. Sei o que está bem ou mal escrito. As pessoas  
que não escrevem não imaginam quanto prazer isto pode dar. Antigamente tinha pena de não saber desenhar. Mas agora  
sinto-me feliz por saber, ao menos, escrever. E se não tiver talento suficiente para escrever livros ou artigos de jornal,  
enfim, sempre me restará escrever para meu próprio deleite.</p>
<p>Quero vir a ser alguém. Não me agrada a vida que levam a mãe, a sra. van Daan e todas  
essas mulheres que trabalham para, mais tarde, ninguém se lembrar delas.</p>
<p>Além de um marido e de filhos, preciso de mais alguma coisa a que me possa dedicar!  
Quero continuar a viver depois da minha morte. E por isso estou tão grata a Deus que me deu a possibilidade de  
desenvolver o meu espírito e de poder escrever para exprimir o que em mim vive.</p>
<p>Quando escrevo, sinto um alívio, a minha dor desaparece, a coragem volta. Mas  
pergunto-me : escreverei alguma vez coisa de importância? Virei a ser jornalista ou escritora? Espero que sim, espero-o de  
todo o meu coração!</p>
<p>Ao escrever sei esclarecer tudo, os meus pensamentos, os meus ideais, as minhas  
fantasias. Não tenho trabalhado em A vida de Candy, mas sei como desenvolver a história e só não consigo fazê-lo  
ràpidamente. Pode ser que nunca acabe aquilo e que vá parar ao cesto de papel ou ao fogão.</p>
<p>Não é uma ideia agradável, mas penso: com catorze anos e com tão pouca experiência,  
ainda não se pode, afinal, escrever uma história filosófica.</p>
<p>Não quero perder a coragem. Tudo há-de sair bem, pois estou decidida a escrever!</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 6 de Abril de 1944</h2>
<p>Querida Kitty:</p>
<p>Perguntas-me o que é que mais me interessa e quais são os meus mais queridos  
entretenimentos. Não te assustes; é que não são poucas coisas.</p>
<p>Em primeiro lugar, gosto de escrever, mas isto não é bem um entretenimento.</p>
<p>Em segundo, gosto da genealogia das casas reais. Já encontrei, em jornais, livros e papéis,  
bastante material sobre as famílias francesas, alemãs, espanholas, inglesas, austríacas, russas, norueguesas e  
holandesas. Consegui bons resultados; há bastante tempo que tiro apontamentos de todas as biografias e livros de história  
que leio.</p>
<p>O meu terceiro entretenimento é a história, por isso o pai já me comprou alguns livros sobre  
este assunto.</p>
<p>Oxalá não venha longe o dia em que possa fazer investigações nas bibliotecas  
públicas.</p>
<p>Em quarto lugar, gosto da mitologia grega e romana, e também sobre isso tenho vários  
livros.</p>
<p>Outros entretenimentos são a colecção de fotografias de &quot;estrelas&quot; de cinema e  
da família, os livros, saber coisas sobre escritores, poetas e pintores e sobre a história da arte. Pode ser que ainda, um dia,  
a música venha a juntar-se a tudo isto.</p>
<p>Tenho grande antipatia pela álgebra, a geometria e toda a espécie de contas. Fora isto  
agrada-me qualquer disciplina da escola, mas coloco a história acima de todas.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 11 de Abril de 1944</h2>
<p>Querida Kitty:</p>
<p>Sinto como que marteladas na cabeça! Nem sei por onde começar. Sexta-feira (Sexta-feira  
Santa) à tarde, e no sábado também, fizemos vários jogos. Esses dias passaram-se sem novidade e bastante depressa. No  
domingo pedi ao Peter que viesse aqui e mais tarde subimos e ficámos lá em cima até às seis horas. Das seis e quinze até  
às sete horas ouvimos um belo concerto de música de Mozart; do que mais gostei foi da &quot;Kleine Nachtmusik&quot;.  
Não consigo escutar bem quando há muita gente à minha volta, porque a boa música comove-me profundamente.</p>
<p>Domingo à noite o Peter e eu fomos ao sótão. Para estarmos sentados confortàvelmente,  
levámos umas almofadas que pusemos em cima de um caixote. O sítio é estreito e estávamos muito apertados um contra o  
outro.</p>
<p>A Mouchi fazia-nos companhia. Assim havia quem nos vigiasse. De repente, às nove menos  
um quarto, o sr. van Daan assobiou e perguntou se nós tínhamos levado uma almofada do sr. Dussel. Saltámos do caixote  
abaixo e descemos com as almofadas, o gato e o sr. van Daan. Por causa da almofada do sr. Dussel desenrolou-se uma  
verdadeira tragédia. Ele estava desaustinado por termos levado a sua &quot;almofada da noite&quot;. Receou que a  
enchêssemos de pulgas, fez cenas tremendas por causa de uma reles almofada.</p>
<p>Como vingança, o Peter e eu metemos-lhe duas escovas duras na cama. Rimo-nos muito  
daquela pequena partida Mas o divertimento não havia de ser de longa duração. às nove e meia o Peter bateu à porta e  
pediu ao pai que subisse para lhe ensinar uma frase inglesa muito complicada.</p>
<p>- Aqui há gato-disse eu à Margot.-Ele não está a dizer a verdade.</p>
<p>E tinha razão. Havia ladrões no armazém. Com rapidez, o pai, o Peter, o sr. van Daan e o  
Dussel desceram.</p>
<p>A mãe, a Margot, a sra. van Daan e eu ficámos à espera.</p>
<p>Quatro mulheres cheias de medo não podem fazer outra coisa senão porem-se a falar.  
Assim fizemos. De repente, ouvimos, lá em baixo, uma pancada forte. Depois, silêncio.</p>
<p>O relógio deu dez menos um quarto. Estávamos lívidas muito quietas e cheias de medo.  
Que foi feito dos homens.</p>
<p>O que é que significava aquela pancada? Haverá luta entre eles e os ladrões? Dez horas.  
Passos na escada. Entra primeiro o pai, pálido e nervoso, depois o sr. van Daan.</p>
<p>- Fechem a luz. Subam sem fazer barulho. Deve vir a polícia.</p>
<p>Agora não havia tempo para medos. Fechámos a luz.</p>
<p>Ainda peguei no meu casaquinho e subimos.</p>
<p>- O que aconteceu? Depressa, conta! - Mas não havia ninguém que pudesse contar, porque  
os senhores já tinham descido outra vez. às dez e dez voltaram, dois ficaram de guarda na janela aberta, no quarto do  
Peter. A porta do corredor ficou fechada. A porta giratória também. Sobre o candeeiro lançámos uma camisola. Depois eles  
começaram a contar:</p>
<p>O Peter ao ouvir duas pancadas fortes, correu abaixo e viu que do lado esquerdo da porta  
do armazém faltava uma tábua. Voltou depressa para cima, avisou a parte mais corajosa do grupo e então eles, os quatro,  
desceram.</p>
<p>Quando entraram no armazém encontraram os ladrões em flagrante. Sem reflectir o sr. van  
Daan gritou :</p>
<p>- Polícia!</p>
<p>Os ladrões fugiram num instante. Para evitar que a ronda da Polícia notasse o buraco, os  
nossos homens colocaram a tábua no sítio, mas um pontapé de lá de fora deitou-a novamente ao chão. Os quatro ficaram  
perplexos com tanto atrevimento. O sr. van Daan e o Peter sentiram vontade de matar aqueles patifes. O sr. van Daan  
bateu com o machado no chão. Depois novamente silêncio. Tentaram colocar outra vez a tábua.</p>
<p>Novo susto: lá fora estava um casal e a luz forte de uma lâmpada de mão iluminou todo o  
armazém.</p>
<p>- Com mil raios!-disse um dos nossos e... num instante trocaram o seu papel de polícias pelo  
de ladrões.</p>
<p>Fugiram. Subiram. O Peter abriu portas e janelas na cozinha do escritório particular, deitou o  
telefone ao chão e depois desapareceram todos por detrás da porta giratória.</p>
<p>Fim da primeira parte.</p>
<p>Provàvelmente o casal avisaria a Polícia. Era domingo, Domingo de Páscoa, e ninguém viria  
ao escritório, antes de terça-feira de manhã. Não podíamos fazer mesmo nada.</p>
<p>Imagina duas noites e um dia a passar com tal angústia!</p>
<p>Nós, as mulheres é que já não éramos capazes de imaginar coisa alguma. Estávamos  
sentadas às escuras; a sra. van Daan resolveu fechar todas as luzes, e sempre que se ouvia um ruído murmurávamos  
&quot;chut, chut&quot;.</p>
<p>Eram dez e meia, onze horas, e de ruídos nada. Alternadamente vinham ter connosco o pai  
e o sr. van Daan.</p>
<p>Depois, às onze e um quarto, ouvimos ruídos lá em baixo.</p>
<p>Agora já se ouvia a respiração de cada um de nós. Não nos mexemos. Passos na casa, no  
escritório particular, na cozinha, depois... na escada que conduz à porta camuflada.</p>
<p>Retivemos a respiração; oito corações a martelar.</p>
<p>Passos na escada, sacudidelas nas prateleiras da porta giratória. Estes momentos são  
impossíveis de descrever.</p>
<p>-Estamos perdidos-pensei, e já nos via, a todos, arrastados pela Gestapo através da noite.  
Mais duas vezes mexeram na porta giratória, depois alguma coisa caiu e os passos afastaram-se. De momento, estávamos  
salvos. Então começámos todos a tremer. Ouvia-se o bater de dentes; ninguém conseguia pronunciar uma palavra.</p>
<p>Não se ouvia mais nada em toda a casa, mas havia luz do outro lado da porta camuflada.  
Teriam desconfiado desta ou esqueceram-se de apagar a luz? Dentro do prédio já não se encontravam estranhos; só lá  
fora, na rua, haveria possivelmente um guarda. As nossas línguas soltaram-se, começámos a falar, mas o medo ainda nos  
dominava. Todos precisavam... O Peter tem um cesto de papéis de chapa de ferro, que podia substituir o balde que estava  
no sótão.</p>
<p>O sr. van Daan começou, depois o pai. A mãe teve vergonha. O pai levou-nos o cesto ao  
quarto, onde a Margot, a sr. van Daan e eu, muito contentes, o utilizámos, e, por fim, também a mãe. Todos queriam papel.  
Felizmente eu trazia algum comigo no bolso.</p>
<p>Do cesto vinha um cheirete horrível; falávamos em voz baixa; estávamos cansados. Era  
meia-noite.</p>
<p>- Deitem-se no chão e durmam!</p>
<p>Deram-nos, à Margot e a mim, almofadas. A Margot ficou deitada junto do armário dos  
víveres e eu entre as pernas da mesa. No chão não se sentia tanto o mau cheiro, mas a sra. van Daan, sem fazer o mínimo  
ruído, foi buscar um pouco de cloro e deitou-o no cesto, que depois cobriu com um pano velho.</p>
<p>Conversas, murmúrios, mau cheiro, medo, e sempre alguém sentado no cesto. Impossível  
dormir-se. às duas e meia eu estava tão cansada que não ouvi mais nada até às três e meia. Depois acordei. Senti a  
cabeça da sra. van Daan em cima do meu pé.</p>
<p>-Dêem-me alguma coisa para vestir. Tenho frio.</p>
<p>Atiraram-me roupa. Mas não queiras saber o que era!</p>
<p>Fiquei com calças de lã em cima do pijama, um &quot;pulôver&quot; e uma saia preta, umas  
meias brancas e, por cima, soquetes rotos.</p>
<p>Agora a sra. van Daan sentou-se numa cadeira e o sr. van Daan deitou-se no chão, também  
em cima dos meus pés. Comecei a pensar em tudo o que tinha acontecido e pus-me a tremer de tal forma que o sr. van  
Daan não pôde dormir. Preparei mentalmente as palavras que havíamos de dizer, caso a polícia voltasse. Com certeza era  
preciso confessar-lhes que éramos &quot;mergulhados&quot;. Ou eles eram bons holandeses-e então estávamos salvos-ou  
eram pró-nazis e então aceitavam dinheiro!</p>
<p>- Tira o rádio-suspirou a sra. van Daan.</p>
<p>-Queres que o deite ao fogão? Se nos encontrarem,já não importa que encontrem também o  
rádio.</p>
<p>- Então encontram também o diário da Anne-disse o pai.</p>
<p>- E se o queimássemos-propôs a pessoa mais medrosa do nosso grupo.</p>
<p>Este momento e aquele em que eu tinha ouvido as sacudidelas da Polícia na porta giratória,  
foram para mim os mais terríveis.</p>
<p>- O meu diário não! O meu diário só será queimado comigo!</p>
<p>Graças a Deus, o pai já nem me respondeu.</p>
<p>Não vale a pena reproduzir todas as conversas. Confortei a sra. van Daan, que estava cheia  
de um medo horrível.</p>
<p>Falámos de fugas, interrogatórios, da Gestapo e da necessidade de sermos corajosos.</p>
<p>-Agora temos de ser valentes como os soldados sra. van Daan. Se nos apanharem, o nosso  
sacrifício será pela rainha, a pátria, a verdade e o direito, como dizem também na emissora de Orange.</p>
<p>O que mais me aflige é arrastarmos tanta gente para a infelicidade.</p>
<p>O sr. van Daan tornou a trocar o lugar com a sua mulher, o pai veio para junto de mim. Os  
homens fumavam sem interrupção, de vez em quando ouvia-se um suspiro fundo, depois alguém a correr ao cesto... e isto  
ainda se repetiu muitas vezes. Quatro horas, cinco horas, cinco e meia. Fui ao quarto do Peter. Ficámos sentados à janela,  
ouvíamos os ruídos, cada um sentia as vibrações do corpo do outro, tão encostados estávamos. Só dizíamos uma palavra,  
de longe em longe. Estávamos sempre atentos ao que se ia passando. Ao lado ouvimos alguém abrir as persianas.</p>
<p>às sete, os senhores queriam telefonar ao Koophuis e pedir-lhe que mandasse alguém.  
Escreveram num papel o que lhe iam dizer. Havia o perigo de o guarda em frente da porta ouvir o toque do telefone, mas o  
perigo da Polícia voltar era maior ainda. Os tópicos a comunicar ao Koophuis eram os seguintes:</p>
<p>Assalto: a Polícia entrou em casa, chegou até à porta giratória, mas não foi mais longe.</p>
<p>Ladrões, provàvelmente apanhados em flagrante, arrombaram a porta do armazém e  
fugiram pelo quintal.</p>
<p>Porta principal trancada. O Kraler deve ter saído pela outra porta. As máquinas de escrever  
estão em segurança na caixa preta, no escritório particular.</p>
<p>Tentar avisar o Henk. Ir buscar a chave a casa da Elli. Ele que venha cá ao escritório com o  
pretexto de que o gato precisa de comida.</p>
<p>Tudo se fez tal qual. Telefonou-se ao Koophuis, levámos as máquinas (que ainda estavam  
connosco em cima) para baixo, e guardámo-las na caixa preta. Sentámo-nos à volta da mesa e esperámos pelo Henk ou...  
pela Polícia.</p>
<p>O Peter adormeceu. O sr. van Daan e eu acabámos por deitar-nos no chão. Depois ouvimos  
passos pesados.</p>
<p>Eu disse, em voz baixa:</p>
<p>- É o Henk.</p>
<p>- Não, não, é a Polícia, ouvi dizer alguém.</p>
<p>Bateram à porta. O assobio da Miep. Agora é que a sra. van Daan não aguentou mais.  
Branca como a cal, sem forças, estava caída na cadeira, e se aquela tensão se tivesse prolongado por mais um minuto, ela  
teria desmaiado.</p>
<p>Quando a Miep e o Henk entraram no nosso quarto, ofereceu-se-lhes um lindo espectáculo.  
Só a mesa valia a pena ser fotografada. A revista &quot;Filme e Teatro&quot; aberta, e as fotos das lindas  
&quot;estrelas&quot; do bailado besuntadas com compota e com o remédio contra a diarreia. Dois frascos de compota, um  
pão e meio, espelho, pente, fósforos, cinza, cigarros, tabaco, cinzeiro, calcinhas, lâmpáda de bolso, papel higiénico, etc.,  
etc...</p>
<p>Já se vê, recebemos o Henk e a Miep com júbilo e lágrimas. O Henk tapou o buraco da  
porta com a tábua e depois foi à Polícia para comunicar o assalto. A Miep encontrou debaixo da porta um aviso do  
guarda-nocturno que viu o buraco e avisou a Polícia. O Henk foi também falar com ele.</p>
<p>Tínhamos uma meia hora para nos arranjarmos. Nunca vi uma tal metamorfose em tão  
pouco tempo. A Margot e eu abrimos as camas, fomos ao W. c., lavámo-nos, limpámos os dentes e penteámo-nos. Depois,  
num instante, arrumámos o quarto e voltámos para cima. A mesa já estava limpa. Fomos buscar água, fizemos café e chá e  
pusemos a mesa para o pequeno almoço. O pai e o Peter limparam o cesto sujo com água e cloro.</p>
<p>às onze horas já nos encontrávamos todos com o Henk à volta da mesa e acalmámos  
pouco a pouco. O Henk contou:</p>
<p>- O guarda nocturno Slagter ainda estava a dormir.</p>
<p>Falei com a mulher e ela disse-me que o marido, ao fazer a ronda nos cais, tinha reparado  
no buraco na nossa porta da rua. Foi procurar um polícia e, juntos, rebuscaram a casa de cima abaixo. Que na terça-feira  
viria fazer mais comunicações ao Kraler. Foi à esquadra da Polícia, onde ainda não sabiam nada do assalto, mas tomaram  
nota e disseram que viriam cá também na terça-feira.</p>
<p>No regresso o Henk passou pela loja do hortaliceiro, na esquina, e contou-lhe do roubo.</p>
<p>- Eu sei, - disse o hortaliceiro pachorrentamente. - Passei, ontem à noite com minha mulher  
pelo vosso estabelecimento e vi o tal buraco na porta. Minha mulher não quis parar mas eu acendi a minha lâmpada de  
bolso e iluminei o interior. Os ladrões fugiram logo. Não chamei a Polícia, pensei que seria melhor. Não sei nada, mas  
imagino algumas coisas...</p>
<p>O Henk agradeceu e foi-se embora. O hortaliceiro decerto suspeita de que estamos aqui,  
pois entrega as batatas sempre à hora do almoço. Um tipo às direitas.</p>
<p>Depois do Henk nos ter deixado - era uma hora - deitámo-nos para dormir. às três menos  
um quarto acordei e já não vi o Dussel na sua cama. Ainda toda entorpecida encontrei, por acaso, o Peter no quarto de  
banho.</p>
<p>Combinámos encontrar-nos depois em baixo, no escritório.</p>
<p>- Ainda sentes coragem para subir ao sótão? - perguntou-me.</p>
<p>Disse-lhe que sim, fui buscar a minha almofada e subimos. O tempo estava uma maravilha.  
Em breve as sereias começaram a dar alarme. Mas nós ficámos onde estávamos. O Peter deitou-me um braço em volta dos  
ombros e eu também deitei um braço em volta dos seus ombros, e assim ficámos muito calmos, até que veio a Margot  
chamar-nos para o lanche.</p>
<p>Comemos pão, tomámos limonada e já estávamos de novo dispostos a dizer brincadeiras  
uns aos outros. Depois disso não houve mais nada de especial. à noite agradeci ao Peter por ele ter sido o mais corajoso  
de todos nós.</p>
<p>Nunca nenhum de nós se tinha encontrado numa situação tão perigosa como a da noite  
passada. Deus protegeu-nos.</p>
<p>Imagina a Polícia a remexer na estante da nossa porta giratória, iluminada pela luz acesa,  
sem dar connosco!</p>
<p>Em caso de invasão, com bombardeamentos e tudo, cada um de nós pode responder por si  
próprio. Neste caso, porém, não se tratava só de nós, mas também dos nossos bondosos protectores.</p>
<p>-Estamos salvos. Não nos abandones!</p>
<p>É apenas isto que podemos suplicar.</p>
<p>Este acontecimento trouxe consigo algumas modificações.</p>
<p>O sr. Dussel já não trabalha à noite no escritório do Kraler mas sim no quarto de banho. às  
oito e meia e às nove e meia o Peter faz a ronda pela casa. Já não pode abrir a janela durante a noite. Depois das nove e  
meia não podemos utilizar o autoclismo do W. C. Hoje à noite vem um carpinteiro reforçar as portas do armazém.</p>
<p>Há discussões a tal respeito, há quem pense que não se devia mandar fazer isso. O Kraler  
censurou a nossa imprudência e também o Henk disse que não devíamos em tais casos descer ao andar de baixo.  
Fizeram-nos ver bem que somos &quot;mergulhados&quot;, judeus enclausurados, presos num sítio, sem direitos, mas  
carregados de milhares de deveres.</p>
<p>Nós, judeus, não devemos deixar-nos arrastar pelos sentimentos, temos de ser corajosos e  
fortes e aceitar o nosso destino sem queixas, temos de cumprir tudo quanto possível e ter confiança em Deus. Há-de  
chegar o dia em que esta guerra medonha acabará, há-de chegar o dia em que também nós voltaremos a ser gente como  
os outros e não apenas judeus.</p>
<p>Quem foi que nos impôs este destino? Quem decidiu excluir deste modo os judeus do  
convívio dos outros povos?</p>
<p>Quem nos fez sofrer tanto até agora? Foi Deus que nos trouxe o sofrimento e será Deus que  
nos libertará. Se apesar de tudo isto que suportamos, ainda sobreviverem judeus, estes servirão a todos os condenados  
como exemplo.</p>
<p>Quem sabe, talvez venha ainda o dia em que o Mundo se aperceba do bem através da  
nossa fé, e talvez seja por isso que temos de sofrer tanto. Nunca poderemos ser só holandeses, ingleses ou súbditos de  
qualquer outro país.</p>
<p>Seremos sempre, além disso, judeus. E queremos sê-lo.</p>
<p>Não percamos a coragem. Temos de ter consciência da nossa missão. Não nos queixemos,  
que o dia da nossa salvação há-de chegar. Nunca Deus abandonou o nosso povo. Através de todos os séculos os judeus  
sobreviveram.</p>
<p>Através de todos os séculos houve sempre judeus a sofrer, mas através de todos os  
séculos se mantiveram fortes.</p>
<p>Os fracos desaparecem mas os fortes sobrevivem e não morrerão!</p>
<p>Naquela noite pensei que ia morrer. Esperava pela Polícia, estava preparada como os  
soldados no campo de batalha, prestes a sacrificar-me pela pátria. Agora que estou salva, o meu desejo é naturalizar-me  
holandesa depois da guerra.</p>
<p>Gosto dos holandeses, gosto desta terra e da sua língua.</p>
<p>É aqui que gostava de trabalhar. E se for preciso escrever à própria rainha, não hei-de  
desistir enquanto não conseguir este meu fim.</p>
<p>Sinto-me cada vez mais independente dos meus pais.</p>
<p>Embora seja muito nova ainda, sei, no entanto, que tenho mais coragem de viver e um  
sentido de justiça mais apurado, mais seguro do que a mãe. Sei o que quero, tenho uma finalidade, uma opinião, tenho fé e  
amor. Deixem-me ser eu mesma e estarei satisfeita. Tenho consciência de ser mulher, uma mulher com força interior e com  
muita coragem.</p>
<p>Se Deus me deixar viver, hei-de ir mais longe de que a mãe. Não quero ficar insignificante.  
Quero conquistar o meu lugar no Mundo e trabalhar para a Humanidade.</p>
<p>O que sei é que a coragem e a alegria são os factores mais importantes na vida! e não sei  
explicar porquê. Escrevi tudo num caos, não se sente o nexo, e cada vez duvido mais de que um dia haja alguém  
interessado nos disparates que escrevo.</p>
<p>&quot;As confidências de um patinho feio&quot; será o título desta papelada. O sr.  
Bolkestein e o sr. Gerbrandy, os coleccionadores de documentos de guerra, não encontrarão nada de especial no meu  
diário.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 14 de Abril de 1944</h2>
<p>Querida Kitty:</p>
<p>A atmosfera está ainda tensa. O Pim está muito irritável.</p>
<p>A sra. van Daan está deitada com uma constipação e faz cenas; o marido está pálido e não  
tem cigarros que o animem; o Dussel, depois de ter resolvido sacrificar uma parte das suas comodidades, anda  
descontente.</p>
<p>Há muita coisa que não funciona. O W.C. está a deitar água e a torneira está perra. Mas  
graças às nossas muitas relações, estes males hão-de remediar-se depressa.</p>
<p>Há ocasiões em que estou sentimental, sei-o bem, mas... por vezes há razões para o  
sentimentalismo. Quando o Peter e eu estamos sentados num caixote duro, no meio de ferros-velhos e de pó, muito juntos,  
eu com um braço em volta dos seus ombros, ele com um braço em volta dos meus ombros, quando ele brinca com uma  
madeixa do meu cabelo, quando lá fora se ouve o chilrear dos pássaros, quando se vê as árvores a pintarem de verde  
quando o sol nos chama e o ar é todo ele azul, oh!, então os meus desejos são infinitos.</p>
<p>Mas aqui só se vêem caras carrancudas e descontentes.</p>
<p>Suspiros e queixumes por toda a parte. Tudo isto dá a impressão de que as coisas vão cada  
vez pior. A verdade, no entanto, é que tudo corre sempre mal se não soubermos reagir. Já não há ninguém cá no anexo  
que nos sirva de exemplo, cada um luta sózinho com os seus nervos. Só se ouve dizer:</p>
<p>- Quem me dera que isto acabasse!</p>
<p>A mim, o trabalho, a esperança, o amor e a coragem fazem-me aguentar, mais até:  
tornam-me boa e feliz.</p>
<p>Creio, Kit, que estou um pouco maluquinha hoje.</p>
<p>Tua Anne</p>
<h2>Sábado, 15 de Abril de 1944</h2>
<p>Querida Kitty :</p>
<p>A um susto segue-se outro, - Quando é que isto terá fim? É esta a nossa eterna pergunta.  
Imagina o que aconteceu agora. O Peter esquece se de abrir o ferrolho da porta principal (à noite a porta tranca-se por  
dentro) e a fechadura da outra porta está estragada. Por consequência o Kraler não conseguiu entrar com os  
operários.</p>
<p>Teve de pedir aos vizinhos para o deixarem entrar, quebrou depois a janela da cozinha e  
saltou para dentro.</p>
<p>Está furioso por causa do nosso descuido. O Peter anda desolado. Quando a minha mãe lhe  
disse à mesa que tinha pena dele, pouco faltou para que desatasse a chorar.</p>
<p>Mas na verdade temos todos culpa, porque os senhores costumam perguntar todas as  
manhãs se o Peter abriu o ferrolho, e precisamente hoje não o fizeram. Oxalá eu lhe possa dar logo algum conforto,  
gostava tanto de o ajudar!</p>
<p>E agora algumas notícias sobre vários acontecimentos no anexo durante as últimas  
semanas :</p>
<p>Há uma semana adoeceu o Boschi. Não se mexia a Miep, sempre resoluta, embrulhou-o  
num pano, meteu-o no seu saco das compras e levou-o à clínica veterinária.</p>
<p>O veterinário enfiou-lhe um remédio pela goela abaixo, pois supunha que o bicho tinha uma  
infecção nos intestinos.</p>
<p>Depois disso o Boschi passeia lá fora, dia e noite; decerto arranjou uma namorada.</p>
<p>A janela do sótão já fica outra vez aberta durante a noite. Quando escurece, o Peter e eu  
estamos quase sempre lá em cima.</p>
<p>Com o auxílio de Koophuis e com um pouco de tinta de óleo, o W. C. arranjou-se. A torneira  
perra foi substituída por outra. Este mês recebemos oito cartões de racionamento. O nosso mais recente petisco chama-se  
&quot;Piccadilly&quot;.</p>
<p>Se a gente tem pouca sorte, só encontra alguns pepinos com molho de mostarda no frasco.  
Legumes já não há quase nenhuns. Só salada e sempre salada. De resto só comemos batatas com molho artificial.</p>
<p>Muitos e tremendos bombardeamentos.</p>
<p>A Câmara de Haia ficou destruida e com ela muitos documentos. Diz-se que todos os  
holandeses receberão novos cartões de identidade.</p>
<p>Basta por hoje.</p>
<p>Tua Anne</p>
<h2>Domingo de manhã pouco antes das 11 horas, 16 de Abril de  
1944</h2>
<p>Querida Kitty :</p>
<p>Peço-te que nunca te esqueças do dia de ontem, por ser um dia muito importante na minha  
vida. Ou não é importante para uma rapariga receber o seu primeiro beijo? E eu não sou diferente das outras. O beijo que o  
Bram me deu uma vez na face direita não conta, e o beijo na mão de Mr. Walker também não. Agora vais ouvir como  
aconteceu eu receber um beijo.</p>
<p>-Ontem, às oito horas, estávamos, o Peter e eu, no quarto dele, sentados no sofá.</p>
<p>-Se pudesses chegar-te mais um bocado para lá, - disse-lhe, - eu não dava com a cabeça  
contra a estante.</p>
<p>Ele recuou quase até ao cantinho. Passei-lhe o braço à volta da cinta e ele abraçou-me. Já  
tínhamos estado assim muitas vezes, mas talvez não tão próximos um do outro. Apertou-me com força, o meu peito estava  
contra o seu - o meu coração batia cada vez mais depressa. Mas não é tudo. Ele não descansou enquanto não deitei a  
cabeça no seu ombro e depois inclinou ele a cabeça sobre a minha. Quando, passados cinco minutos, me ia endireitar,  
tomou-me a cabeça entre as mãos e apertou-me, de novo, contra ele. Oh! foi maravilhoso, eu não consegui falar, só pude  
viver o momento. Um pouco desajeitado, acariciou-me a cara e o braço, brincou com os meus caracóis e assim  
permanecemos com as cabeças muito juntas.</p>
<p>Não posso descrever-te a minha emoção. Eu estava tão feliz! E creio que o Peter  
também.</p>
<p>Às oito e meia levantámo-nos e ele calçou as sandálias de ginástica para fazer a ronda pela  
casa com o menos ruído possível. Eu estava ao seu lado. Não sei dizer exactamente como aquilo aconteceu, mas ao  
descermos, ele beijou-me o cabelo, muito junto da orelha esquerda. Corri para baixo sem me virar e... e só queria que já  
fosse mais logo, à noite.</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 17 de Abril de 1944</h2>
<p>Querida Kitty :</p>
<p>Que te parece : o pai e a mãe achariam bem se soubessem que eu estou sentada com um  
rapaz no sofá e que nos beijamos? Um rapaz de dezassete anos e uma rapariga que vai fazer quinze? Não devem achar  
bem, creio, mas afinal aquilo só me diz respeito a mim. Sinto-me calma e segura a sonhar nos seus braços, e é tão  
excitante sentir a cara dele contra a minha, é tão delicioso saber-se que alguém nos espera!</p>
<p>Mas - há um mas - ele contentar-se-ia só com isto.</p>
<p>Não me esqueci da sua promessa, mas... sempre é um rapaz!</p>
<p>Bem sei que estou a começar cedo, ainda não fiz os quinze e já sou tão independente!  
Ninguém, provàvelmente, sabe compreender. Tenho quase a certeza de que a Margot era incapaz de beijar um rapaz sem  
que se falasse logo de noivado e de casamento. Mas o Peter e eu não fazemos planos. Calculo que a mãe também não se  
deixou tocar por ninguém antes de conhecer o pai. O que diriam as minhas amigas se me vissem nos braços do Peter, com  
o meu coração contra o seu peito, a cabeça nos seus ombros, e a sua cabeça em cima da minha?</p>
<p>Oh! Anne, que vergonha!</p>
<p>Mas, com toda a franqueza! Não acho que isto seja uma vergonha. Vivemos aqui isolados  
do Mundo, cheios de medo e de angústia, principalmente nos últimos tempos.</p>
<p>Porque é que nós, que nos amamos, havemos de nos afastar um do outro? Porque é que  
havemos de esperar até ter uma idade conveniente? E porque havemos de fazer tais perguntas? Hei-de saber tomar conta  
de mim. O Peter nunca me causará aflições ou dores. Porque não hei-de eu, por isso fazer o que o meu coração me dita e  
o que nos torna felizes? Mas... creio que estás a pressentir que lido com certas dúvidas, dúvidas estas que provêm da luta  
entre a minha fraqueza e o ter de fazer coisas às escondidas.</p>
<p>Achas que é meu dever dizer tudo ao pai? Achas que devemos partilhar o nosso segredo  
com alguém? Receio que muita coisa subtil venha a perder-se. E ficaria eu mais calma intimamente? Vou falar com  
&quot;ele&quot; sobre o assunto.</p>
<p>Sim, tenho de falar com &quot;ele&quot; sobre muitas coisas, porque passar o tempo a fazer  
apenas carícias, não faz sentido. É preciso uma grande confiança para dizermos tudo um ao outro, mas a consciência de  
possuirmos esta confiança mútua nos dará força a ambos.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 18 de Abril de 1944</h2>
<p>Querida Kitty:</p>
<p>Tudo vai bem. O pai disse que espera grandiosas operações ainda antes de 20 de Maio,  
tanto na Rússia e na Itália como no Ocidente. Quanto mais as coisas se estão a demorar, tanto menos consigo imaginar a  
nossa libertação.</p>
<p>Finalmente, ontem o Peter e eu falámos sobre aquilo que andávamos a adiar há dez dias.  
Expliquei-lhe todos os segredos de uma rapariga e não me acanhei a falar nas coisas mais íntimas. A noite rematou-se com  
um beijo muito perto da boca. É uma sensação maravilhosa.</p>
<p>Talvez eu leve para cima o meu livro em que aponto tudo o que me agrada, e assim  
podemos aprofundar juntos as coisas belas. Não me dá satisfação estarmos só abraçados.</p>
<p>Gostava de que ele fosse da minha opinião.</p>
<p>Depois de um Inverno irregular veio uma Primavera estupenda, um Abril magnífico, nem  
quente nem frio, e só de vez em quando uma chuvada. O nosso castanheiro já está verde e vêem-se, aqui e acolá,  
nascerem-lhe as velinhas. No sábado a Elli deu-nos uma grande alegria. Trouxe flores - três ramalhetes de narcisos, e para  
mim, jacintos azuis.</p>
<p>Tenho que estudar álgebra, Kitty. Adeus.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 19 de Abril, de 1944</h2>
<p>Querida Kitty:</p>
<p>Lieve Schat!</p>
<p>O que poderá haver de mais belo no Mundo do que olhar a natureza pela janela aberta, do  
que ouvir cantar os pássaros, sentir o sol no rosto e ter nos braços um rapaz muito querido? O silêncio faz-nos tão  
bem!</p>
<p>Oh! Se nunca ninguém o interrompesse, nem mesmo o Mouchi!</p>
<p>Tua Anne</p>
<h2>Terça-feira, 25 de Abril de 1944</h2>
<p>Querida Kitty :</p>
<p>Há dez dias que o Dussel não fala com o sr. van Daan e só porque tivemos de tomar, depois  
do roubo, algumas medidas novas que não lhe agradam. Disse que o sr. van Daan lhe deu berros.</p>
<p>-Tudo se faz aqui sem me consultarem-disse-me a mim-; hei-de falar a este respeito com o  
teu pai.</p>
<p>Ele não devia trabalhar, nem no sábado à tarde nem no domingo, lá em baixo no escritório.  
Mas não cumpriu, foi na mesma. O sr. van Daan ficou zangado e o pai foi para baixo para falar com o Dussel. Claro, lá  
inventou qualquer desculpa. Mas desta vez nem o pai se deixou convencer. Agora o pai quase não lhe fala por ele o ter  
ofendido. Não sabemos o que se passou, mas deve ter sido coisa grave.</p>
<p>Escrevi uma história bonita, chama-se Blzrry, o descobridor do Mundo. Agradou bastante  
aos meus três ouvintes.</p>
<p>Ainda estou muito constipada e contagiei a Margot, o pai e a mãe. Oxalá não aconteça o  
mesmo ao Peter.</p>
<p>Queria que eu lhe desse um beijo, chamou-me o seu &quot;el dorado&quot;. Mas agora não  
pode ser, meu rapaz! Ele é um amor!</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 27 de Abril de 1944</h2>
<p>Querida Kitty:</p>
<p>Hoje de manhã a sra. van Daan estava de muito mau génio. Só se lamentava: por estar  
constipada, por não haver gotas que lhe fizessem aguentar melhor as dores no nariz. Depois, por não haver nem sol nem  
invasão, e por se não poder olhar um pouco pela janela, etc., etc.</p>
<p>Foi-nos impossível manter um ar sério; rimo-nos dela, e como, afinal, tudo aquilo não era  
uma grande tragédia, ela acabou por se rir também.</p>
<p>Leio agora O Imperador Carlos Quinto, escrito por um professor de Guingen que trabalhou  
quarenta anos nesta obra. Em cinco dias li cinquenta páginas; é difícil ler-se mais, de um livro assim, e ele tem quinhentas e  
noventa e oito páginas. Agora podes fazer as contas ao tempo que levará a leitura e, depois, falta ainda a segunda  
parte!</p>
<p>Mas... é deveras interessante!</p>
<p>O que uma rapariga trabalha normalmente na escola não se pode comparar à tarefa que eu  
cumpro. Hoje traduzi, do holandês para o inglês, um pedaço da última batalha de Nelson. Depois estudei A guerra Nórdica  
(1700-1721), Pedro o Grande, Carlos XII, Augusto o Forte, Stanislau Seczinsky, Mazeppa, Brandemburgo, Pomerânia e  
Dinamarca-com todos os dados correspondentes.</p>
<p>Depois li sobre o Brasil: o tabaco da Baía, a abundância de café, o milhão e meio de  
habitantes do Rio de Janeiro, Pernambuco e São Paulo, o rio Amazonas. Fiquei a saber coisas dos negros, dos brancos,  
das mulheres, dos mulatos, dos mestiços; fiquei também a saber que ainda lá vivem cinquenta por cento de analfabetos e  
que há malária.</p>
<p>Como ainda me sobrava um pouco de tempo, peguei na minha árvore genealógica: Jan o  
velho, Guilherme Luís, Ernst Casimir, Henrique CasimirI, até à pequena Margriet Franciska que nasceu em 1929 em  
Otava.</p>
<p>Meio-dia: continuo a estudar, no sótão, o programa sobre as catedrais... uff! até à uma  
hora.</p>
<p>às duas horas, a pobre rapariga (hum, hum!) já estava de novo a estudar. Macacos com  
focinho achatado e macacos com focinho aguçado. Kitty, és capaz de me dizer quantos dedos no pé tem o hipopótamo?  
Depois seguiu-se a bíblia, a arca de Noé, Sem, Cham e Japhet; depois Carlos V. Por fim: inglês com o Peter: O Coronel de  
Thackeray, vocábulos franceses, e comparar o Mississipi ao Missouri. Chega por hoje.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 28 de Abril de 1944</h2>
<p>Querida Kitty:</p>
<p>Nunca me pude esquecer do meu sonho com o Peter Wessel. Ainda hoje, ao lembrar-me,  
parece-me sentir a face do Peter contra a minha, essa sensação que tanto me maravilhou. Ao estar com o Peter daqui  
experimentava a mesma sensação, sim, mas nunca tão forte até... ontem, ao anoitecer, quando estávamos, como de  
costume, abraçados no sofá. De repente a Anne de todos os dias transformou-se numa outra Anne, naquela que não é  
divertida nem travessa mas que quer ser terna e afável.</p>
<p>Estava muito junto dele e a comoção tomou conta de mim. As lágrimas vieram-me aos olhos,  
cairam-me cara abaixo e molharam a bata dele. Terá notado? Nem o mais leve movimento o traíu. Sente ele o mesmo que  
eu?</p>
<p>Quase não falava. Saberá que convive com duas Annes diferentes? Tantas perguntas por  
responder!</p>
<p>Às oito e meia ergui-me e fui à janela onde costumamos despedir-nos. Ainda eu tremia,  
ainda era a Anne número 2.</p>
<p>Ele foi ter comigo, eu deitei-lhe os braços ao pescoço e beijei-lhe a face esquerda. Quando  
lhe quis beijar a outra, as nossas bocas encontraram-se. Como numa vertigem, estreitámo-nos, um contra o outro, uma vez  
e outra vez, para nunca mais acabar!</p>
<p>Peter tem necessidade de ternura. Pela primeira vez na vida descobriu uma rapariga e, pela  
primeira vez, compreendeu que estas &quot;maçadoras&quot;, afinal, têm também um coração e que são muito diferentes  
quando se está a sós com elas. Pela primeira vez na vida deu amizade e entregou-se a outrem. Nunca antes tinha tido um  
amigo ou uma amiga. Agora encontrámo-nos. Eu também não o conhecia a ele, nunca tinha tido um confidente, e agora  
tudo isto se realizou.</p>
<p>Mas eis uma pergunta que me tortura:</p>
<p>-Está isto certo? Procedo bem em ser tão transigente, tão apaixonada, tão impulsiva e cheia  
de desejos, tal como o Peter? Está certo que uma rapariga não saiba dominar-se?</p>
<p>Só há uma resposta: sentia dentro de mim profunda ânsia, sentia-me só, e agora encontrei  
consolo e alegria.</p>
<p>Da parte da manhã Peter e eu somos as pessoas de sempre; e mesmo durante o dia. Mas  
ao anoitecer não podemos conter o desejo da felicidade e da alegria de nos encontrarmos. Então somos um do outro.  
Todas as noites, depois do último beijo, queria fugir, desaparecer, não ver mais aqueles olhos, estar longe, longe, longe,  
totalmente só na escuridão!</p>
<p>Mas depois de ter descido os catorze degraus, onde é que me encontro? à luz crua da sala,  
entre vozes e risos; perguntam-me isto ou aquilo e tenho de fazer tudo para que ninguém note em mim qualquer coisa. O  
meu coração ainda está impressionado de mais para esquecer um acontecimento como o de ontem à noite. A meiguice e a  
brandura talvez sejam qualidades raras na Anne mas, mesmo assim, não se deixam afugentar de um instante para o  
outro.</p>
<p>O Peter atingiu-me como nunca nada me tinha atingido, a não ser o meu sonho. O Peter  
revolveu o meu íntimo, chamou-o à superfície. E não é natural que qualquer pessoa no meu caso necessite reencontrar o  
sossego para tranquilizar de novo o seu íntimo? Oh, Peter!, o que fizeste de mim? O que queres de mim? Aonde vamos nós  
parar? Oh! Agora é que compreendo a Elli. Agora que vivo estas coisas, compreendo as dúvidas dela. Se ele fosse mais  
velho e quisesse casar comigo, que lhe responderia?</p>
<p>Sê franca, Anne! Não eras capaz de casar com ele, mas deixá-lo também te custa! O  
carácter do Peter ainda não alcançou a harmonia intrior. O Peter tem pouca energia, pouca força de vontade e pouca força  
moral. Ainda é uma criança, intimamente não tem mais idade do que eu; o que ele procura, antes de mais nada, é a calma e  
a felicidade.</p>
<p>E eu? Tenho, de facto, só catorze anos? Não passo de uma rapariguita estúpida? Não  
tenho ainda experiência nenhuma? Tenho experiência, sim senhora, tenho mais experiência do que os outros; vivi coisas  
que muito poucos da minha idade viveram. Tenho medo de mim própria, tenho medo de que o meu desejo me arrebate, e  
então o que há-de ser de mim mais tarde, quando conviver com outros rapazes? Oh, como tudo isto é difícil! O coração e o  
juízo, e sempre a luta entre os dois. Cada um deles fala no momento próprio, mas sei eu de certeza quais são os momentos  
próprios?</p>
<p>Tua Anne</p>`],

26: [`<h2>Terça-feira, 2 de Maio de 1944</h2><p>Querida Kitty:</p>
<p>No sábado, à noite, perguntei ao Peter se achava que devia dizer ao pai o que se passa  
entre nós, e depois de ponderar um bocado ele achou que sim. Estou contente por isso, pois prova-me a pureza dos seus  
sentimentos.</p>
<p>Logo depois de eu ter descido, fui buscar água com o pai, e já na escada disse-lhe:</p>
<p>- Pai, com certeza compreendes que o Peter e eu, quando estamos juntos, não ficamos  
sentados a um metro de distância um do outro. Achas mal?-O pai não me respondeu imediatamente. Depois disse:</p>
<p>- Não, não acho mal, Anne, mas aqui, onde o espaço é tão restrito, deves ter mais  
cuidado...</p>
<p>Ainda chegou a dizer mais algumas coisas no mesmo sentido e depois subimos. No  
domingo de manhã chamou-me para me dizer :</p>
<p>- Anne, pensei naquilo que me disseste (comecei a ter medo). Vistas bem as coisas, não  
está certo aqui no anexo!</p>
<p>Julgava que vocês eram bons camaradas. O Peter está apaixonado por ti?</p>
<p>- Não, não é isso-disse eu.</p>
<p>- Sabes Anne, eu compreendo-vos muito bem, mas acho que deves manter um pouco de  
distância, não deves encorajá-lo demasiadamente. Não devias ir tantas vezes lá para cima. Nestas coisas o homem é a  
parte activa e a mulher pode detê-lo. Lá fora, na liberdade, todas estas coisas são diferentes. Convives com outros rapazes  
e raparigas, podes dar passeios, praticar desportos e outras coisas no género. Mas se vocês aqui estão sempre juntos e  
se um dia isso não te agradar por mais tempo, tudo se tornará complicado. Vocês vêem-se a cada passo, praticamente a  
todos os momentos : sê prudente, Anne, e não te prendas tanto.</p>
<p>- Não me prendo demasiado, pai, e o Peter é correcto, é muito bom rapaz.</p>
<p>-Sim, é bom rapaz, mas não tem um carácter firme; tão fàcilmente se deixa influenciar para o  
bom como para o mau. Oxalá se mantenha correcto, porque no fundo é boa pessoa.</p>
<p>Ainda conversámos um pouco e depois combinámos que o pai fosse falar com ele também.  
No domingo à tarde, quando eu estava lá em cima, o Peter perguntou :</p>
<p>- Então falaste ao teu pai, Anne?</p>
<p>- Falei - disse eu - e vou-te contar tudo. Ele não acha mal nenhum em estarmos tão juntos  
um do outro, mas pensa que isto pode dar lugar a mal-entendidos.</p>
<p>- Já combinámos que nunca havemos de discutir e estou resolvido a cumprir.</p>
<p>- Também eu, Peter, mas o pai tinha imaginado que éramos apenas bons camaradas. Achas  
que já não podemos ser bons camaradas?</p>
<p>- Porque não? Que te parece?</p>
<p>- Parece-me que podemos. Eu disse ao pai que tenho confiança em ti. E é a verdade, Peter.  
Tenho tanta confiança em ti como no pai, e penso que o mereces, não é verdade?</p>
<p>- Espero que sim.</p>
<p>Corou e ficou atrapalhado.</p>
<p>- Creio em ti, Peter, creio que tens um bom carácter e que farás o teu caminho na vida.</p>
<p>Falámos ainda de várias coisas e eu depois disse :</p>
<p>- Quando sairmos daqui, já sei que não vais fazer caso de mim.</p>
<p>Ele disse com ardor:</p>
<p>- Não digas tal coisa, Anne! Oh! não, tu não tens direito de me julgar assim.</p>
<p>Depois chamaram-me.</p>
<p>Na segunda-feira contou-me que o pai falou com ele.</p>
<p>- O teu pai pensa que a nossa camaradagem podia acabar em namoro, e eu disse que  
podia ter confiança em nós.</p>
<p>O pai quer que eu não vá tantas vezes lá para cima, mas não estou de acordo. Não só  
porque gosto de estar com o Peter mas também por lhe ter dito que tenho confiança nele. E já que tenho esta confiança  
quero provar-lha.</p>
<p>E eu não lha poderia provar se manifestasse desconfiança, ficando cá em baixo.</p>
<p>Não, hei-de ir!</p>
<p>Entretanto, o &quot;drama Dussel&quot; acabou. No sábado, ao jantar, pediu desculpa num  
discurso bem estudado, em holandês. O sr. van Daan ficou logo derretido. Julgo que o Dussel levou o dia inteiro a ensaiar  
&quot;a lição&quot;. O seu aniversário, no domingo, correu com calma. Nós, os Franks, demos-lhe uma garrafa de vinho de  
Gig, os van Daans (que já estavam agora de bem com ele e lhe podiam oferecer uma prenda) deram-lhe um copo de  
&quot;Piccadilly&quot; e um maço de lâminas, o Kraler veio com um frasco de compota de limão, a Miep com um livro e a  
Elli com uma planta. E ele regalou-nos a todos com um ovo para cada.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 3 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Primeiro, as novidades da semana. A política está em férias, não aconteceu nada, mas  
mesmo absolutamente nada. Pouco a pouco começo a acreditar que a invasão está para breve. Impossível deixarem os  
russos a esfalfarem-se sózinhos. Aliás, da Rússia, também não há novidades.</p>
<p>O sr. Koophuis vem, de novo, todos os dias ao escritório.</p>
<p>Arranjou uma mola nova para o sofá do Peter e agora não tem outro remédio senão fazer de  
estofador, apesar da falta de jeito. Também arranjou um pó contra as pulgas dos gatos. Já te contei que o Boschi se foi  
embora.</p>
<p>Desde quinta-feira desapareceu sem deixar vestígios.</p>
<p>Decerto lá estará no céu dos gatos, pois provàvelmente algum &quot;amigo dos  
animais&quot; deliciou-se com ele para o almoço. Pode ser que o seu pêlo ainda dê uma touquinha de criança. O Peter  
ficou muito triste.</p>
<p>Desde sábado que lanchamos às onze e meia. Ao pequeno almoço comemos uma papa  
com que temos de aguentar-nos. Assim poupamos uma refeição. Ainda é difícil conseguir-se hortaliça. Hoje tivemos salada  
cozida que já estava bastante estragada. Sempre salada, ou crua ou cozida, e espinafres e, a acompanhar, batatas de má  
qualidade. Uma combinação deliciosa!</p>
<p>Há mais de dois meses que eu não tinha tido o meu &quot;incómodo&quot;. Finalmente, no  
sábado apareceu. Apesar de todas as contrariedades e mal-estar, sinto-me contente.</p>
<p>Tu talvez não possas compreender que aqui surja tantas vezes a pergunta desesperada:  
porquê e para quê é esta guerra? Porque é que os homens não podem viver em paz? Para quê tantas destruições?</p>
<p>Estas perguntas são legítimas, mas até agora ninguém soube encontrar-lhes uma resposta  
satisfatória. Porque é que na Inglaterra se constroem aviões cada vez maiores, bombas cada vez mais pesadas e, ao  
mesmo tempo, se reconstroem filas de casas? Porque é que se gastam todos os dias milhões para a guerra, se não há  
dinheiro para a medicina, os artistas e os pobres? Porque é que há homens a passar fome se, em outros continentes,  
apodrecem víveres? Porque é que os homens são tão insensatos?</p>
<p>Não acredito que a culpa da guerra caiba exclusivamente aos que governam e aos  
capitalistas.</p>
<p>Não, o homem da rua também tem a sua culpa, pois não se revolta.</p>
<p>O homem nasce com o instinto da destruição, do massacre, da fúria, e enquanto toda a  
Humanidade não sofrer uma metamorfose total, haverá sempre guerras. O que se construiu e cultivou e o que cresceu será  
destruído, e à Humanidade só resta recomeçar.</p>
<p>Tenho estado muitas vezes abatida mas nunca me senti aniquilada. Considero a nossa vida  
de &quot;mergulhados&quot;</p>
<p>uma aventura perigosa que é, ao mesmo tempo, romântica e interessante. Sempre me  
propus viver uma vida diferente da das raparigas em geral, do mesmo modo como também não me agrada para o futuro a  
vida banal das donas de casa. Isto aqui é um bom princípio com muitas coisas cheias de interesse e, mesmo nos momentos  
mais perigosos, vejo o cómico da situação e não posso deixar de me rir.</p>
<p>Sou jovem e com certeza ainda há em mim boas qualidades por despertar; sou jovem e forte  
e vivo conscientemente esta grande aventura. Porque hei-de lamentar-me todo o dia?</p>
<p>Muito me deu a natureza: alegria e força. Cada vez mais sinto como o meu espírito se  
desenvolve, sinto a libertação que se está aproximando, sinto como é bela a natureza e como é boa a gente que me rodeia.  
Porque hei-de estar desesperada?</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 5 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>O pai não está contente comigo. Julgava que eu, depois da nossa conversa no domingo,  
tinha resolvido não subir todas as noites lá para cima. Não concorda com a nossa &quot;beijoquice&quot;.</p>
<p>Detesto esta palavra. Bem basta a gente ter de falar no assunto, não vejo necessidade de o  
escarnecer.</p>
<p>Ainda hoje hei-de voltar a falar com o pai. A Margot deu-me alguns bons conselhos. Eis o  
que quero, mais ou menos, dizer-lhe:</p>
<p>&quot;Parece-me, pai, que exiges de mim uma explicação e vou dar-ta. É possível que  
estejas desapontado comigo e me julgasses menos impulsiva. Com certeza gostavas que eu fosse como as outras  
raparigas aos catorze anos ou, melhor, como elas deviam ser. Mas enganas-te! Desde que viemos para aqui, em Julho de  
1942, até há poucas semanas, a minha vida não tem sido fácil. Se tu soubesses quantas vezes chorei de noite, como era  
infeliz, como me sentia só, então compreenderias melhor porque é que quero estar lá em cima. Não foi de um dia para o  
outro que consegui chegar a viver sem o apoio da mãe ou seja de quem for. Tem-me custado lutas duras e muitas lágrimas  
o ter-me tornado tão independente como agora sou. Podes rir-te, talvez não acredites, mas as coisas são como são. Tenho  
a consciência de ser alguém que sabe responder por si própria e que não se sente responsável para convosco.</p>
<p>Digo-te isto para que não penses que tenho segredos, porque, de resto, só me considero  
responsável perante mim mesma! Quando me debatia com tantas dificuldades, vocês - e também tu - fecharam os olhos e  
os ouvidos.</p>
<p>Não me ajudaste, pelo contrário, só me advertias para eu não fazer tanto alarido. Eu era  
barulhenta porque não queria ser infeliz, eu era travessa porque queria abafar a voz que há dentro de mim. Representei  
uma comédia, durante ano e meio, dia após dia, sem me queixar, sem perder a linha; lutei até agora e venci. Sou  
independente de corpo e de espírito, não preciso da mãe, saí fortalecida de todas as lutas.</p>
<p>&quot;E agora que alcancei o meu fim, agora que me impus, hei-de seguir sózinha o meu  
caminho, o caminho que me parece ser o melhor. Não podes, nem deves, considerar-me uma rapariga de catorze anos. A  
nossa tragédia tem-me envelhecido, e hei-de agir conforme me parece bem. Tu, que és a bondade em pessoa, não me  
podes impedir de ir lá para cima. Ou tu me proíbes tudo ou tens de ter confiança em mim em todas as circunstâncias. Só te  
peço: deixa-me em paz!&quot;</p>
<p>Tua Anne</p>
<h2>Sábado, 6 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Ontem, antes de jantar, meti uma carta no bolso do pai. Escrevi-lhe o que ontem te  
expliquei. Depois de a ter lido, ficou, durante todo o serão, desconcertado. Foi a Margot quem mo disse, pois eu estava a  
ajudar lá em cima a lavar a louça. Pobre Pim, eu devia ter sabido o resultado de uma carta assim. Ele é tão sensível! Avisei  
logo o Peter para não lhe perguntar mais nada. O Pim não voltou a falar comigo sobre o caso. Ainda virá a fazê-lo?</p>
<p>As coisas aqui vão andando. As novidades que nos vão dando sobre as pessoas lá de fora  
e sobre os preços são quase inacreditáveis: duzentos e cinquenta gramas de chá custam trezentos e cinquenta florins;  
meio quilo de café oitenta florins; meio quilo de manteiga trinta e cinco; um ovo quarenta e cinco. Por cem gramas de  
tabaco búlgaro dão-se catorze florins. Todos fazem negócios &quot;negros&quot;.</p>
<p>Todos os garotos têm qualquer coisa que vender. O moço de recados da nossa padaria  
arranja-nos linha para pontear, muito pouca e muito fininha, por noventa cêntimos; é o leiteiro quem arranja os falsos  
cartões de víveres; um cangalheiro negoceia em queijo. Todos os dias se registam assaltos, assassínios e roubos em que,  
além dos criminosos profissionais, estão muitas vezes envolvidos polícias e guardas. Todos querem arranjar alguma coisa  
para acalmar o estômago, e como o aumento dos salários é proibido, as pessoas recorrem à intrujice.</p>
<p>A polícia de menores não tem mãos a medir. Não se passa um dia sem que desapareçam  
raparigas de quinze, dezasseis, dezassete anos ou mais.</p>
<p>Tua Anne</p>
<h2>Domingo, de manhã, 7 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Ontem à tarde, tive uma longa conversa com o pai.</p>
<p>Chorei terrivelmente e o pai chorou comigo. Sabes o que me disse?</p>
<p>-Já recebi muitas cartas na minha vida, mas esta foi a mais feia! Tu, Anne, tu a quem os  
pais dedicaram tanto amor, sempre prontos a defender-te fosse do que fosse, tu pretendes não ter obrigações para  
connosco? Tu julgas-te posta de parte e abandonada? Foste muito injusta para connosco, Anne. Talvez não quisesses  
dizer bem isso, mas escreveste-o. Não, Anne, nós não merecemos uma tal acusação.</p>
<p>Oh, sim, fui injusta-nunca cometi acção tão horrível em toda a minha vida! Só pretendi fazer  
figura com todo aquele palavreado e, com todas as minhas lágrimas, só pretendi chamar a atenção do pai sobre mim. É  
certo que sofri. Mas culpar o Pim, que é bom, que tudo tem feito por mim e continua a fazer, foi ignóbil da minha parte.</p>
<p>Ainda bem que ele me tirou da minha torre de marfim, que o meu orgulho ficou derrotado,  
pois eu já estava, de novo, a ser muito presunçosa. Porque nem tudo o que faz a menina Anne é bem feito, nem de longe!  
Causar uma tal dor a uma pessoa a quem se diz amar, e ainda por cima intencionalmente, é um acto baixo, muito baixo! E o  
que mais me envergonha é a maneira como o pai me perdoou. Disse que vai queimar a carta e é tão meigo comigo como se  
tivesse sido ele que se portou mal. Oh, Anne, tens que aprender ainda tanta coisa! Será melhor começares já a aprender,  
em vez de olhares de alto para os outros, ou de os culpar!</p>
<p>Vivi momentos difíceis. Mas não os vive toda a gente da minha idade? Representei muitas  
vezes uma comédia mas nem sequer tive consciência disso. Sentia-me só, é verdade, mas nunca verdadeiramente  
desesperada. Devo ter vergonha e tenho muita vergonha!</p>
<p>O que está feito, está feito, mas é sempre tempo de evitar que o mesmo aconteça outra vez.  
Hei-de tornar a começar pelo princípio e isto não deve ser difícil porque tenho o Peter. Se ele me ajudar serei capaz! Já não  
estou só, ele ama-me e eu a ele; tenho os meus livros, as histórias que escrevi, o meu diário; não sou feia de todo, não sou  
estúpida; tenho um feitio alegre e gostava muito de possuir um bom carácter!</p>
<p>Sim, Anne, tu bem sabias que a tua carta era dura de mais e que não correspondia à  
verdade, mas, apesar disso, sentiste-te orgulhosa dela. De ora em diante o pai há-de ser para mim outra vez o exemplo a  
seguir e, assim, hei-de corrigir-me por força.</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 8 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Pensando bem, nunca te contei nada da nossa família, pois não? Mas vou fazê-lo agora  
mesmo.</p>
<p>Os pais do meu pai eram muito ricos. O avô venceu pelo seu esforço e a avó descendia de  
uma família rica e distinta. Assim, meu pai gozou uma juventude de &quot;filho de pais ricos&quot;: saraus elegantes, todas  
as semanas, festas, bailes, raparigas bonitas, jantares, uma casa grande...</p>
<p>Mas o dinheiro perdeu-se todo depois da outra guerra mundial, durante a inflação. O pai  
teve, portanto, uma boa educação e, por isso, riu-se muito ontem à mesa, porque, pela primeira vez numa vida de 55 anos,  
rapou uma travessa.</p>
<p>Também a mãe é filha de gente rica e, escutamos de boca aberta, quando ela nos conta de  
festas de casamento com duzentos e cinquenta convidados, de grandes bailes e grandes jantares. A nós já ninguém nos  
pode chamar ricos, mas tenho boas esperanças de que as coisas se modifiquem depois da guerra. Para ser franca, não me  
interessa lá muito uma vida tão simples como a que a mãe e a Margot ambicionam. Eu, por mim, gostava de passar um ano  
em Paris e outro em Londres para poder estudar as diferentes línguas e também história de arte. Agora compara tu os  
meus desejos com os da Margot, que quer ser enfermeira-parteira na Palestina. Gosto de imaginar vestidos bonitos e gente  
interessante, quero ver e viver muitas coisas-já te falei disso-, e um pouco de dinheiro far-me-á jeito.</p>
<p>Hoje de manhã a Miep contou-nos de uma festa de pedido de casamento em que ela tomou  
parte. A noiva e o noivo são de famílias ricas e tudo estava um primor.</p>
<p>A Miep causou-nos inveja quando falou da boa comida que serviram: sopa de legumes com  
bolinhas de carne pãezinhos de queijo, &quot;hors díveloeuvre&quot; com ovos, &quot;roast beaf&quot;, bolos, vinho e  
cigarros e tudo em abundância, claro arranjado no mercado negro. Só a Miep bebeu dez &quot;brandies&quot; - nada mau  
para uma antialcoólica. Se a Miep chegou a isso então gostava de saber quantos engoliu o marido.</p>
<p>Claro que toda a gente ficou um pouco &quot;animada&quot;. Entre os convidados havia  
dois polícias militares que tiraram fotografias. Parece que a Miep nunca se esquece dos seus &quot;mergulhados&quot;.  
Tomou nota dos nomes e das direcções destes homens para o caso de acontecer alguma coisa e ela ter de recorrer aos  
&quot;bons holandeses&quot;. Fez-nos crescer a água na boca ao contar-nos daquelas comidas deliciosas, a nós que só  
comemos algumas colheres de papa ao pequeno almoço e depois não sabemos durante horas o que havemos de fazer à  
nossa fome, que comemos todos os dias espinafres mal cozidos (por causa das vitaminas) e batatas meio estragadas, que  
enchemos o estômago com salada, crua ou cozida, com espinafres e outra vez espinafres.</p>
<p>Talvez ainda fiquemos tão fortes como o Popeye, embora isso nos pareça quase  
impossível.</p>
<p>Se a Miep nos tivesse levado àquela festa, não teríamos deixado ficar nada para os outros  
convidados. Podes crer que comíamos as palavras da Miep quando nos agrupámos à volta dela e aquilo dava a impressão  
de que nunca tínhamos ouvido falar de boa comida e de gente elegante.</p>
<p>Sendo nós netos de milionários. Não há dúvida de que acontecem coisas estranhas neste  
Mundo!</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>REGULAMENTOS PARA OS SERVIÇOS DO SENHOR DOUTOR</p>
<p>De manhã : Sete e quinze às sete e trinta</p>
<p>Ao almoço: à uma hora.</p>
<p>Depois : o tempo que quiser.</p>
<h2>Terça-feira, 9 de Maio de 1944</h2>
<p>Querida Kitty :</p>
<p>Acabei a história Ellen, a fada. Passei-a a limpo para um papel bonito, enfeitei-a a tinta  
vermelha, encadernei-a, e agora parece mesmo uma coisa bonita. Mas não achas pouco para o aniversário do pai? Não sei  
bem.</p>
<p>A mãe e a Margot fizeram-lhe poemas.</p>
<p>Hoje, à hora do almoço, o sr. Kraler trouxe-nos a notícia de que a sra. B., que, em tempos,  
foi propagandista da firma, quer vir passar, a partir da semana que vem, a sua hora de almoço no escritório. Imagina: se ela  
fizer isso, ninguém poderá subir, as batatas têm de ser entregues a uma outra hora, a Elli não poderá comer aqui,, nós não  
poderemos utilizar o W.C., nem mexer-nos, etc, etc.</p>
<p>Estivemos todos a inventar pretextos para a fazer desistir. O sr. van Daan disse que talvez  
bastasse deitar-lhe um purgante no café.</p>
<p>- Não, - disse o sr. Koophuis, - isso não, por favor. Então ela nunca mais sairá do  
&quot;trono&quot;.</p>
<p>Todos se riram muito.</p>
<p>- Do &quot;trono&quot;? perguntou a sra. van Daan.-O que quer dizer?</p>
<p>Explicámos-lhe.</p>
<p>- É assim que se diz? - perguntou ela cheia de candura.</p>
<p>- Agora, imagina tu - segredou-me a Elli a rir-que ela vai aos armazéns Bijenkorf perguntar  
onde fica o trono!</p>
<p>O Dussel está todos os dias, pontualmente, ao meio dia e meia hora no &quot;trono&quot; -  
para usar a linda expressão.</p>
<p>Enchi-me de coragem e escrevi hoje num pedaço de papel.</p>
<p>Colei o papel na porta do W. C. enquanto ele estava lá dentro. Ainda devia ter  
acrescentado:</p>
<p>&quot;Em caso de infracção, haverá bloqueio&quot;, pois a porta do W. C. tanto pode  
fechar-se por dentro como por fora.</p>
<p>Ai Kitty, o tempo está tão bonito. Quem me dera poder sair!</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 10 de Maio de 1944</h2>
<p>Querida Kitty :</p>
<p>Ontem, quando estávamos no sótão a estudar francês, pareceu-me, de repente, ouvir correr  
água. Perguntei ao Peter o que seria aquilo, mas ele, em vez de responder, correu imediatamente à mansarda, pois já  
estava a adivinhar a causa do desastre. Pegou no Mouchi e levou-o sem piedade ao lugar próprio. O Mouchi fugiu para  
baixo.</p>
<p>Por uma questão de comodidade, o Mouchi tinha escolhido um lugar no meio do serrim, mas  
o chichi passou pelas tábuas e pingou, quase todo, na pipa das batatas.</p>
<p>As batatas e o serrim, que o pai foi buscar ontem, cheiravam terrivelmente mal. Pobre  
Mouchi. Não sabias que te tivemos de privar da tua turfa no caixote, por já não haver nenhuma à venda.</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 11 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Uma história que te vai fazer rir.</p>
<p>O Peter precisava de cortar o cabelo. A sua mãe, como de costume, quis fazer de  
cabeleireira. O Peter desapareceu no seu quarto e às sete e meia em ponto voltou de calção de banho e de sapatos de  
ginástica.</p>
<p>- Vens comigo? - perguntou a mãe.</p>
<p>- Vou, mas estou à procura da tesoura.</p>
<p>O Peter ajudou-a a procurar, mas remexeu de mais na caixa de &quot;toilette&quot; da sra.  
van Daan.</p>
<p>- Não me ponhas tudo em desordem - censurou ela.</p>
<p>Não percebi o que é que ele respondeu, mas deve ter sido coisa malcriada, porque a  
senhora deu-lhe uma palmada no rabo; ele pagou-lhe na mesma moeda e, quando ela se preparava para lhe chegar outra,  
ele fugiu. às gargalhadas.</p>
<p>- Anda comigo, minha velhinha! - gritou.</p>
<p>Ela ficou onde estava. Então o Peter agarrou-lhe nos punhos e arrastou-a pelo quarto fora.  
Ela chorava, ria, ralhava e tentou defender-se. Mas não lhe serviu de nada.</p>
<p>O Peter arrastou-a até junto da escada, onde a soltou.</p>
<p>A sra. van Daan voltou ao quarto e, suspirando alto, deixou-se cair numa cadeira.</p>
<p>- O rapto da mãe - disse eu rindo.</p>
<p>- Mas ele magoou-me!</p>
<p>Fui ver-lhe os pulsos que estavam vermelhos e quentes e refresquei-lhos com água: O  
Peter, à espera dela na escada, impacientou-se. Com uma correia na mão, como um domador de feras, apareceu à porta.  
Mas a sra. van Daan não ia. Ficou sentada à escrivaninha. e pôs-se a procurar o lenço. Depois disse:</p>
<p>- Primeiro, tens de pedir desculpa.</p>
<p>- Está bem - disse ele - peço desculpa porque se está a fazer tarde.</p>
<p>Contra sua vontade ela riu-se, levantou-se e foi até à porta. Mas ainda achou necessário  
dar-nos uma explicação, ao meu pai, à minha irmã e a mim, que estávamos a lavar a louça.</p>
<p>- Ele não era assim em casa. Se se tivesse atrevido, eu dava-lhe uma bofetada que o teria  
deitado pela escada abaixo(!). Nunca costumava ser tão malcriado, apanhava muitas surras. Agora está a sofrer as  
consequências da educação moderna. Ai!, filhos modernos! Eu teria lá tido coragem de puxar assim pela minha mãe! O sr.  
Frank fazia coisas destas à sua mãe?</p>
<p>Estava excitada, corria de um lado para o outro; fez ainda algumas perguntas e só depois  
de se ter demorado bastante tempo é que foi com o filho para cima. Mas passados cinco minutos voltou a correr, toda  
zangada, tirou o avental e deitou-o ao chão. Perguntei-lhe se já tinha concluído o serviço. Respondeu-me que precisava de  
ir depressa lá para baixo. Como um turbilhão desceu a escada, suponho que para se deixar cair nos braços do seu Putti. Só  
às oito voltou com ele. Foram buscar o Peter, que teve de ouvir um grande sermão. Choviam palavras como &quot;garoto  
malcriado&quot;, &quot;grosseirão&quot;, &quot;mau exemplo&quot;, &quot;olha a Anne...&quot;, &quot;a Margot é  
que...&quot;. Não consegui perceber mais nada.</p>
<p>Amanhã já não pensam mais nisso.</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>P. S.</p>
<p>Terça e quarta à noite falou a nossa querida rainha. Vai passar umas férias fora, para voltar  
com novas forças. Oxalá volte depressa. Disse entre outras coisas: &quot;Em breve, depois de eu ter regressado... a  
libertação não demora... heroísmo e tarefas pesadas&quot;.</p>
<p>Seguia-se um discurso do ministro Gerbrandy. Depois remataram a emissão com a reza de  
um sacerdote que pediu a Deus para proteger os judeus e todos os presos nos campos de concentração, nas prisões e na  
Alemanha.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 12 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Talvez te pareça fantástico mas estou tão ocupada neste momento que o tempo não me  
chega para levar a cabo os meus trabalhos. Queres saber o que ainda tenho a fazer? Aí vai: até àmanhã preciso de acabar  
a leitura da primeira parte da biografia de Galileu, pois o livro tem de ser entregue na biblioteca. Comecei ontem, mas  
hei-de lê-lo todo. Na próxima semana quero ler: &quot;Palestina, uma encruzilhada&quot; e o segundo volume do  
&quot;Galileu&quot;.</p>
<p>Ontem acabei a primeira parte da biografia do Carlos V e agora torna-se urgente pôr ordem  
nos meus apontamentos e nas datas genealógicas. Tirei, de vários livros, três páginas cheias de palavras estrangeiras que  
quero decorar. A minha colecção de &quot;estrelas&quot; de cinema está numa desordem aflitiva e tem de ser arranjada.  
Mas só isto me levaria alguns dias e como o &quot;Professor Anne, conforme já foi dito, está a sufocar com trabalho, o caos  
daquela colecção tem de ser fatalmente abandonado à sua sorte por mais algum tempo.</p>
<p>Teseu, Édipo, Peleu, Orfeu, Jasão e Hércules estão à minha espera. Os seus feitos  
históricos confundem-se ainda na minha cabeça como uma trama de fios embrulhados e multicolores. Também Byron e  
Fídias precisam de ser estudados para eu não perder a ligação. O mesmo acontece com as guerras dos sete e dos nove  
anos; ando a misturar tudo. Mas que queres que faça quando se tem uma memória tão fraca como a minha? E agora podes  
imaginar como serei aos oitenta anos! É verdade: ia-me esquecendo da bíblia. Espero que não demorarei muito a chegar à  
história da Susana no banho. E que querem dizer com os crimes de Sodoma e Gomorra? Ai! tanta coisa por perguntar,  
tanta coisa por aprender! A Lieselotte von der Pfalz até a abandonei por completo.</p>
<p>Vês, Kitty, que estou a transbordar?</p>
<p>E agora outra coisa: Já sabes há muito que o meu maior desejo é vir a ser jornalista e, mais  
tarde, escritora famosa. Serei capaz de realizar esta minha ambição? Ou será tudo isto uma mania de grandeza ou até uma  
loucura?</p>
<p>Só o futuro o dirá. Mas assuntos não me faltam. Hei-de publicar um livro depois da guerra: O  
anexo. Se serei ou não bem sucedida, não se pode prever, mas o meu diário servir-me-á de base. Além da história do  
anexo, tenho outras ideias. Hei-de falar nelas mais longamente quando tiverem tomado forma.</p>
<p>Tua Anne</p>
<h2>Sábado, 13 de Maio de 1944</h2>
<p>Querida Kitty :</p>
<p>Ontem, o aniversário do pai coincidiu com os seus dezanove anos de casado. A  
mulher-a-dias não apareceu lá em baixo no escritório, e o Sol brilhava como ainda não tinha brilhado neste ano. O  
castanheiro está coberto de flores e acho-o ainda mais belo do que no ano passado.</p>
<p>O Koophuis deu ao pai a biografia de Lineu, o Kraler um livro sobre História Natural, e o  
Dussel Amsterdam e Water; os van Daan deram um cesto tão estupendamente enfeitado que nem um artista o faria melhor,  
contendo três ovos, uma garrafa de cerveja, um frasco de yoghurt e uma gravata verde. O nosso frasco de compota quase  
desaparecia ao lado daquilo. As rosas que lhe ofereci cheiravam muito bem mas os cravos da Miep e da Elli não têm cheiro  
nenhum, embora sejam lindíssimos. O pai não se pode queixar. Vieram cinquenta pastéis, que coisa maravilhosa! O pai, por  
sua vez, ofereceu doce e uma garrafa aos senhores e &quot;yoghurt&quot; às senhoras. Foi uma festa em cheio!</p>
<p>Tua Anne</p>
<h2>Terça-feira, 16 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Já que há tanto tempo não tenho falado neste assunto, vou reproduzir-te hoje uma  
discussão que tiveram ontem o sr. e a sra. van Daan.</p>
<p>A sra. van Daan: Os alemães devem ter reforçado o Muro do Atlântico. Com certeza farão  
tudo o que puderem para impedir que os ingleses desembarquem. É espantoso que os alemães tenham tanta força.</p>
<p>O sr. van Daan: É verdade, é horrível.</p>
<p>Ela: Sim... sim!</p>
<p>Ele: Ao fim e ao cabo os alemães ainda ganham a guerra. São tão fortes!</p>
<p>Ela: Provàvelmente. Ainda não me convenci do contrário.</p>
<p>Ele: É melhor eu não dizer mais nada.</p>
<p>Ela: Mas tu respondes-me sempre. Não consegues ficar calado.</p>
<p>Ele: Afinal as minhas respostas não dizem nada.</p>
<p>Ela: Mas mesmo assim queres responder e queres ter sempre razão. As tuas profecias  
estão longe de bater certo.</p>
<p>Ele: Até agora nunca me enganei.</p>
<p>Ela: É mentira. Previste a invasão para o ano passado, nos teus cálculos a Finlândia já  
devia ter concluído a paz, a Itália teria ficado liquidada no Inverno e os russos já teriam tomado Lwow. Oh! Não, eu cá não  
dou nada pelas tuas profecias.</p>
<p>Ele (levanta-se): Cala a boca! hás-de ver que tenho tido sempre razão, ao passo que tu  
fartas-te de dizer tanta asneira que já não posso mais com isto. O que eu devia fazer era esfregar-te o nariz na tua própria  
estupidez.</p>
<p>Cai o pano P. S. Apeteceu-me rir e à mãe também. O Peter quase não conseguiu conter  
uma gargalhada. Oh! estes estúpidos adultos. Deviam mas é começar a aprender as coisas em vez de andar a criticar  
constantemente as crianças!</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 19 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Ontem senti-me horrivelmente mal, tive dores de barriga e todos os males imagináveis. Hoje  
já estou melhor.</p>
<p>Tenho fome, mas não posso comer os feijões escuros. Com o Peter tudo vai bem; o pobre  
do rapaz ainda sente mais necessidade de ternura do que eu. Continua a corar todas as vezes que nos despedimos com  
um beijo de boas-noites e depois pede-me mais outro. Serei para ele uma substituta melhorada do Boschi? Mas não faz  
mal. Ele sente-se tão feliz por ter a certeza de que alguém o ama!</p>
<p>Depois desta conquista difícil, domino um tanto a situação, mas não penses que por isso o  
meu amor enfraqueceu.</p>
<p>Não enfraqueceu; o meu íntimo é que voltou a fechar-se.</p>
<p>Se ele quiser arrombar a fechadura outra vez, precisará de uma alavanca muito forte!</p>
<p>Tua Anne</p>
<h2>Sábado, 20 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Quando, ontem, de noite, vinha a descer do quarto do Peter, vi a linda jarra com os cravos  
no chão, a mãe de joelhos a limpar a água e a Margot a pescar os meus papéis.</p>
<p>- Que aconteceu? - perguntei apreensiva, procurando abranger com os olhos todos os  
estragos. Tudo a nadar: as minhas pastas das árvores genealógicas, os cadernos, os livros. Estava quase a chorar e tão  
impressionada fiquei que nem consigo lembrar-me do que lhes disse. A Margot contou-me depois que proferi palavras  
como &quot;danos incalculáveis, horrível, medonho, irreparável!&quot; O pai deu uma gargalhada, a mãe e a Margot  
também, mas a mim só me apetecia chorar por causa do tempo perdido que tinha dedicado àqueles apontamentos tão  
cuidadosamente elaborados.</p>
<p>Mas, vistas bem as coisas, os danos &quot;incalculáveis&quot; não eram assim tão grandes  
e, sentada no chão, separei com cautela os papelinhos colados uns aos outros e, depois, pendurei-os na corda da roupa.  
Aquilo era um espectáculo patusco e deu-me vontade de rir: Maria de Médicis ao lado de Carlos V, e Guilherme de Orange  
ao lado de Maria Antonieta.</p>
<p>- Isto é uma profanação-gracejou o sr. van Daan.</p>
<p>Pedi ao Peter que tomasse conta da minha papelada, e desci.</p>
<p>- Que livros é que ficaram estragados? - perguntei à Margot, que estava a examinar o meu  
tesouro de livros.</p>
<p>- O de álgebra-respondeu ela.</p>
<p>Mas infelizmente o livro de álgebra não estava totalmente estragado. Quem me dera que ele  
tivesse caído mesmo dentro da jarra. Nunca tive tanta antipatia por um livro. Logo ao abri-lo, lêem-se os nomes de umas  
vinte raparigas que já estudaram por ele; é um livro velho, amarelecido, cheio de rabiscos e de correcções. Quando tiver  
um dos meus dias de atrevida e travessa, hei-de rasgar este estafermo em mil pedaços.</p>
<p>Tua Anne</p>
<h2>Segunda-feira, 22 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>O pai perdeu, em 20 de Maio, numa aposta com a sra. van Daan cinco frascos de yoghurt. A  
invasão, de facto, ainda não veio. Não é exagero se te disser que toda a cidade de Amesterdão, toda a Holanda, mais :  
toda a costa ocidental da Europa até à Espanha, só fala e discute, dia e noite, sobre a invasão. Tudo aposta... tudo tem  
esperança.</p>
<p>A tensão aumenta e está a tornar-se insuportável. Afinal nem todas as pessoas que nós  
julgávamos bons holandeses, mantêm a sua confiança nos ingleses. Não se conformam com o famoso &quot;bluff&quot;  
inglês, oh, não! Os homens querem ver grandes façanhas, actos heróicos. Ninguém consegue ver um palmo diante do  
nariz, ninguém se quer lembrar de que os ingleses estão a defender a sua própria terra, todos julgam que eles têm  
obrigação de salvar, o mais depressa possível, a Holanda. Mas quais são as obrigações dos ingleses para connosco? Que  
fizeram os holandeses para merecer um auxílio tão nobre, como esperam com tanta certeza? Os holandeses que não se  
admirem se se enganarem. Ao fim e ao cabo, os ingleses não têm feito mais má figura do que todos os outros países e  
países vizinhos que estão agora ocupados. Os ingleses não precisam de se desculpar quando os acusamos de terem  
dormido durante todos aqueles anos em que os alemães se armaram, pois os outros países, em especial os que estão mais  
próximos da fronteira alemã, também estiveram a dormir. Não adiantamos nada em fazer como a avestruz, isto já o  
reconheceram os ingleses e o resto do Mundo , e é por isso que os aliados, todos juntos e cada um por si, e a Inglaterra  
sobretudo, se vêem obrigados a fazer pesados sacrifícios. Não há país nenhum que tenha vontade de sacrificar os seus  
homens só para o bem de um outro país, e a Inglaterra não é diferente dos mais. A invasão, a libertação, a liberdade, tudo  
virá um dia, mas a Inglaterra e a América é que hão-de fixar as datas e não os habitantes dos países ocupados.</p>
<p>Reina o anti-semitismo nos círculos onde antigamente nem se pensava em tal coisa. Isto  
impressionou-nos profundamente. A causa deste ódio contra os judeus talvez se compreenda e se explique, mas a  
verdade, é que se trata de um equívoco. Os cristãos censuram os judeus e dizem que eles se rebaixam perante os  
alemães, que denunciam os seus protectores e que muitos cristãos têm, por culpa dos judeus, sofrido terríveis provações.  
Pode ser que haja alguma verdade nisto mas, como em todas as coisas, há o reverso da medalha. O que fariam os cristãos  
se estivessem no lugar dos judeus? Será fácil a alguém manter-se firme e correcto com os métodos usados pelos alemães?  
Todos sabem que é quase impossível. Então, porque é que se exige o impossível dos judeus? Nos grupos ilegais da  
resistência corre o boato de que os judeus alemães, em tempos emigrados para a Holanda e agora deportados para a  
Polónia, nunca mais poderão regressar aqui. Tinham direito de asilo na Holanda, mas logo que Hitler tenha desaparecido,  
serão forçados a voltar para a Alemanha. Ao ouvir coisas assim, surge a pergunta: Para que se faz esta guerra tão dura e  
tão longa? Diz-se sempre que lutamos todos juntos pela verdade, pela liberdade e pelos direitos do homem. E afinal a  
discórdia começa enquanto ainda se luta, e já outra vez o judeu é inferior aos outros? Oh! como é triste que o velho dito se  
verifique mais uma vez : &quot;Os actos de um cristão são da sua própria responsabilidade. Mas tudo o que faz qualquer  
judeu recai sobre todos os judeus!&quot;.</p>
<p>Com franqueza não compreendo que os holandeses, este povo bom, honesto e leal, nos  
condene assim, a nós que somos o povo mais oprimido, mais infeliz de todos os povos do Mundo. Só me resta esperar isto:  
que o ódio aos judeus seja apenas passageiro e que os holandeses voltem a mostrar-se como são na realidade! Oxalá  
voltem a não vacilar no seu sentido de justiça. Porque o anti-semitismo é uma injustiça!!!</p>
<p>Gosto da Holanda. Esperei sempre que um dia me servisse de pátria, a mim, que já não  
tenho pátria. E continuo a ter esta esperança!</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 25 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Todos os dias acontecem coisas desagradáveis. Hoje de manhã prenderam o nosso bom  
hortaliceiro, que tinha escondido em casa dois judeus. Foi um golpe muito duro para nós, não só por causa daqueles  
judeus que estão agora à beira do abismo, mas também por causa do pobre hortaliceiro.</p>
<p>O Mundo está às avessas. Pessoas correctas e boas são enviadas para os campos de  
concentração, para as prisões e para as celas solitárias, enquanto a ralé governa sobre os velhos, os jovens, os ricos e os  
pobres. Um é apanhado porque se dedicava ao mercado negro, outro porque protegia judeus ou outros  
&quot;mergulhados&quot;. Ninguém sabe o que o espera amanhã.</p>
<p>Também para nós o hortaliceiro significa uma perda tremenda. A Miep e a Elli não podem  
carregar com o saco de batatas e a nossa única saída é comer menos.</p>
<p>Como conseguiremos isso, ainda o hás-de vir a saber, mas desde já te digo, não vai ser  
divertido. A mãe propõe suprimir o pequeno almoço e comer ao almoço a papa, e à noite batatas fritas e, talvez, uma ou  
duas vezes por semana, um pouco de salada e de legumes. Isto quer dizer: passar fome. Mas todas estas privações são  
preferíveis a sermos descobertos.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 26 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Finalmente posso sentar-me tranquilamente à minha mesinha, junto da janela ligeiramente  
entreaberta, e escrever-te.</p>
<p>Há meses que não me sinto tão desgraçada como hoje, nem depois do assalto estive assim  
tão infeliz, moral e fisicamente. De um lado o hortaliceiro, o problema dos judeus que está a ser o tema do dia cá em casa,  
a invasão que se faz esperar, a péssima alimentação, a tensão nervosa, a má disposição, a minha decepção com o Peter;  
por outro lado : o pedido de casamento da Elli, Pentecostes, flores, os anos do sr. Kraler, bolos, relatórios sobre filmes,  
cabarés e concertos. Estes contrastes, estes terríveis contrastes.</p>
<p>Um dia rimo-nos das situações cómicas que a nossa vida de &quot;mergulhados&quot; traz  
consigo, no dia seguinte temos medo e não raras vezes lê-se, nos nossos rostos, o receio, a tensão nervosa, o desespero.  
A Miep e o Kraler, mais do que quaisquer outros, suportam, por via de nós, grandes encargos.</p>
<p>A Miep por lhe causarmos muito trabalho, o Kraler por ter assumido uma responsabilidade  
colossal que, por vezes, lhe pesa de mais e o põe tão nervoso que quase não consegue pronunciar uma palavra. O  
Koophuis e a Elli também se encarregam bem das nossas coisas, muito bem até, mas são capazes de se esquecer, de se  
abstrair do anexo, mesmo que seja apenas por umas horas, por um ou dois dias.</p>
<p>Eles têm outras preocupações, o Koophuis por causa da sua saúde, a Elli por causa do  
noivo com quem nem tudo vai às mil maravilhas; e, além disso, tem distracções, visitas e a vida toda que para eles corre de  
uma maneira normal.</p>
<p>Podem libertar-se por vezes dessa tensão de nervos que a nós nunca nos abandona. Já há  
dois anos que aqui estamos - e por quanto tempo seremos ainda capazes de resistir a esta pressão insuportável que, de  
dia para dia, vai crescendo?</p>
<p>A canalização está entupida; não podemos deixar correr a água senão gota a gota; só  
podemos ir ao W.C. munidos de uma escova; guardamos a água suja numa das grandes panelas em que se fervem as  
conservas. Por enquanto a coisa remedeia, mas o que é que vai ser se o picheleiro não vier compor os canos? O serviço  
municipal de higiene só virá a este prédio para a semana.</p>
<p>A Miep mandou-nos um pão grande com uvas e junto um papel onde se lia: &quot;Uma  
alegre festa de Pentecostes&quot;.</p>
<p>Parece quase um escárnio, pois a nossa disposição e o nosso medo são tudo menos  
&quot;alegres&quot;. Estamos cada vez com mais medo desde que aconteceu aquilo ao hortaliceiro, de todos os lados se  
ouve, outra vez, &quot;chut, chut&quot;, andamos de um lado para o outro sem fazer ruído. No hortaliceiro a polícia  
arrombou a porta; aqui pode fazer o mesmo. E se aqui... não, não quero falar nisto! Mas a pergunta não se deixa afastar  
fàcilmente, pelo contrário: aquele medo por que passei uma vez ergue-se de novo na minha frente em toda a sua  
monstruosidade.</p>
<p>Esta noite, às oito horas, deixei a sala onde estávamos todos reunidos à volta do rádio e  
desci sòzinha ao W.C.</p>
<p>Quis ser corajosa mas foi difícil. Sinto-me mais segura cá em cima do que em baixo, onde a  
casa me parece tão grande e calada e onde estou sòzinha com os ruídos misteriosos que vêm de cima e os toques das  
buzinas que vêm da rua. Começo a tremer, não consigo demorar-me e tenho de fazer esforços para não pensar na nossa  
situação. Pergunto-me muitas vezes se não teria sido melhor, para todos nós, não termos &quot;mergulhado&quot; e  
estarmos mortos sem precisar de sofrer toda esta miséria, sobretudo sem termos exposto os nossos protectores a tantos  
perigos também.</p>
<p>Mas, no fundo, não queremos aceitar tal ideia, porque ainda amamos a vida, não nos  
esquecemos ainda da voz da natureza, ainda esperamos, esperamos que aconteça algo de bom. Que Deus faça com que  
aconteça alguma coisa e, se for necessário, que haja grandes bombardeamentos; nada nos pode desgastar mais do que  
esta inquietação.</p>
<p>Que venha o fim., mesmo que seja duro, mas, ao menos, que fiquemos a saber se  
vencemos ou se morremos.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 31 de Maio de 1944</h2>
<p>Querida Kitty:</p>
<p>Sábado, domingo, segunda e terça fez tanto calor que não consegui segurar a pena na  
mão; por isso não te pude escrever. Na sexta, a canalização voltou a ficar avariada e no sábado compuseram-na. à tarde  
recebemos a visita da sra. Koophuis que nos contou muitas coisas da Gorrie.</p>
<p>A Gorrie e o Jopie são membros do &quot;Jockey-Club&quot;.</p>
<p>No domingo apareceu a Elli para ver se a casa não foi assaltada, e ficou a almoçar  
connosco.</p>
<p>Na segunda-feira (segundo feriado do Pentecostes) o Henk van Santen fez de guarda ao  
esconderijo e na terça, pudemos, finalmente, abrir outra vez um pouco as janelas.</p>
<p>É raro haver dias tão quentes nos feriados do Pentecostes.</p>
<p>Mas para nós, cá no anexo, não é bom estar tanto calor.</p>
<p>Vou dar-te uma ideia.</p>
<p>Sábado:</p>
<p>- Que tempo maravilhoso! - exclamaram todos logo pela manhã cedo.</p>
<p>- Quem dera que não houvesse tanto calor - disseram à hora do almoço quando as janelas  
têm de estar fechadas.</p>
<p>Domingo:</p>
<p>- O calor é insuportável. A manteiga derrete. Não há um cantinho fresco em toda a casa, o  
pão está seco, o leite estragado, e não se podem abrir as janelas: Ai de nós, somos párias e estamos aqui a sufocar  
enquanto os outros festejam o Pentecostes.</p>
<p>Segunda-feira:</p>
<p>- Doem-me tanto os pés, não tenho roupa leve, não posso lavar a louça com um calor  
destes.</p>
<p>Assim falou a sra. van Daan. Foi horrível. Também não gosto do calor e hoje estou contente  
por correr um ventinho e por brilhar o Sol ao mesmo tempo.</p>
<p>Tua Anne</p>`],

27: [`<h2>Segunda-feira, 5 de Junho de 1944</h2><p>Querida Kitty:</p>
<p>Outro acontecimento desagradável: nós, os Frank, zangámo-nos com o Dussel, e por causa  
de uma coisa sem importância-a distribuição da manteiga. O Dussel ficou derrotado. Agora há grande amizade entre ele e a  
sra. van Daan, uma espécie de &quot;flirt&quot; com beijinhos e sorrisos.</p>
<p>Ao Dussel fez-lhe mal a Primavera.</p>
<p>Roma foi tomada pelo Quinto Exército, sem devastações nem bombardeamentos.</p>
<p>Pouca hortaliça, poucas batatas. Tempo mau. O estreito de Galais e a costa francesa  
constantemente bombardeados.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 6 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>&quot;This is the day&quot;, disse ao meio-dia a rádio inglesa e com razão! &quot;This is  
the day&quot;. Começou a invasão! De manhã, às oito horas, os ingleses noticiaram: bombardeamentos pesados sobre  
Calais, Boulogne, Le Havre e Gherbourg e, como de costume, sobre o estreito de Calais.</p>
<p>Mais: medidas de segurança para todos os habitantes das zonas ocupadas. Todos os  
habitantes de uma zona que abrange até trinta e cinco quilómetros da costa devem preparar-se para bombardeamentos  
pesados. Se for possível, os ingleses lançarão folhetos com uma hora de antecedência.</p>
<p>Segundo as notícias alemãs, tropas de para-quedistas conseguiram lançar-se na costa  
francesa. A B. B. C. anuncia: &quot;A marinha alemã combate contra os barcos ingleses do desembarque&quot;.</p>
<p>Discussões no anexo às nove horas, hora do pequeno almoço :</p>
<p>- Será isto um desembarque de ensaio como aquele de Dieppe, há dois anos?</p>
<p>Às dez horas, emissão inglesa em alemão, holandês, francês e outras línguas: &quot;The  
invasion has begun!&quot; Trata-se portanto de uma invasão autêntica. Emissão inglesa às onze horas, em alemão :  
discurso do comandante-chefe, o general Dwight Eisenhower.</p>
<p>Emissão inglesa - língua inglesa-meio dia: &quot;This is the day&quot;. O general  
Eisenhower fala ao povo francês:</p>
<p>- Still fighting will come now. But after this the victory.</p>
<p>The year 1944 is the year of complete victory, good luck!</p>
<p>Emissão inglesa à uma hora: onze mil aviões voam continuamente de um lado para o outro  
para desembarcar tropas e lançar bombas atrás das linhas. Quatro mil barcos e outras pequenas embarcações despejam,  
entre Cherbourg e Le Havre, sem interrupção, tropas e material. Tropas inglesas e americanas estão já a lutar àrduamente.  
Discursos de Gerbrandy, do Primeiro-Ministro da Bélgica, do rei Haakon da Noruega, de De Gaulle da França, do rei da  
Inglaterra, sem esquecer, claro está, o de Churchill.</p>
<p>O anexo está como que em delírio. Será então verdade que a libertação, há tanto ansiada, a  
tão discutida libertação, sempre está a aproximar-se? Não será isto maravilhoso de mais, fantástico de mais para se tornar  
realidade? O ano de 1944 trará, de facto, a vitória? Não o sabemos ainda, mas a esperança anima-nos, dá-nos nova  
coragem, torna-nos fortes, pois precisamos de coragem para podermos suportar o medo, as privações, o sofrimento; agora  
o essencial é conservarmo-nos calmos e firmes. Mais do que nunca, tenho de cerrar os dentes para não gritar. Agora são a  
França, a Rússia, a Itália e também a Alemanha que podem gritar de tanto sofrer, mas nós ainda não temos esse  
direito!</p>
<p>Oh! Kitty, o mais maravilhoso disto tudo é que tenho o pressentimento de que amigos estão  
a aproximar-se!</p>
<p>Os horríveis alemães oprimiram-nos e ameaçaram-nos tanto tempo, que só o pensar, agora,  
que se aproximam amigos, nos restitui a confiança. Agora não se trata só dos judeus. Agora trata-se da Holanda e de toda  
a Europa.</p>
<p>A Margot diz que eu talvez já possa voltar à escola em Setembro ou Outubro.</p>
<p>Tua Anne</p>
<p>&nbsp;</p>
<p>P. S.</p>
<p>Hei-de informar-te sempre das últimas novidades:</p>
<p>Durante a noite e logo de manhã cedo, desembarcaram bonecos de palha atrás das linhas  
alemãs, que explodiram logo que tocaram o chão. Desembarcaram também muitos pára-quedistas; estavam pintados de  
preto para se confundirem com a escuridão da noite. De manhã desembarcaram dos primeiros navios, depois de a costa ter  
sido bombardeada durante a noite com cinco milhões de quilos de bombas. Vinte mil aviões estiveram hoje em acção. Tudo  
vai bem, embora o tempo esteja mau. O exército e o povo têm &quot;one will and one hope&quot;.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 9 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>A invasão corre às mil maravilhas. Os aliados tomaram Bayeux, uma aldeia na costa  
francesa, e lutam agora por Calais. Compreende-se bem que querem cercar a peninsula onde fica Cherbourg. Todas as  
noites os correspondentes de guerra relatam as dificuldades, a coragem e o entusiasmo do exército. Também ouvimos falar  
os feridos que tiveram de voltar para a Inglaterra. Apesar do mau tempo, os aviões levantam sempre voo. Pela B. B. c.  
ficámos a saber que Churchill quis tomar parte na invasão, mas que o general Eisenhower e os outros generais o  
aconselharam a desistir dessa ideia. Imagina tu a coragem daquele homem que já tem setenta anos de idade.</p>
<p>Aqui já não reina tanta excitação; mas esperamos todos que a guerra acabe finalmente no  
fim deste ano. E já não será sem tempo! As lamentações da sra. van Daan estão-se a tornar insuportáveis. Agora que já  
não nos pode massacrar com a invasão, queixa-se todo o dia do mau tempo.</p>
<p>Apetecia-me metê-la num balde de água fria.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 13 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>O meu aniversário passou mais uma vez. Tenho agora quinze anos. Recebi muitas coisas  
:</p>
<p>A História de Arte, de Springer, em cinco volumes; um jogo de roupas interiores; dois cintos;  
um lenço; dois frascos de yoghurt; um frasco de compota; um bolo; um livro de Botânica, do pai e da mãe. A Margot deu-me  
uma pulseira dupla, os van Daans um livro, o Dussel ervilhas de cheiro; a Miep e a Elli rebuçados e cadernos. E ainda a  
melhor surpresa: o livro Maria Teresa e três fatias de queijo autêntico, do sr. Kraler. Do Peter recebi um belo ramo de  
begónias; o pobre do rapaz andou a ver se lhe conseguiam arranjar coisa diferente, mas não foi possível.</p>
<p>A invasão continua em pleno progresso, apesar do mau tempo, das ventanias medonhas e  
das chuvas torrenciais sobre o mar.</p>
<p>Churchill, Smuts, Eisenhower e Arnold visitaram ontem as aldeias francesas que foram  
conquistadas e libertadas pelos ingleses. Churchill esteve num torpedeiro que bombardeou a costa. Este homem, como  
tantos outros, parece não ter medo. Que coisa tão invejável!</p>
<p>Daqui do anexo não podemos sondar o moral dos holandeses.</p>
<p>Sem dúvida as pessoas estão contentes por a &quot;indolente&quot;</p>
<p>Inglaterra sempre deitar a mão. Todos aqueles holandeses que, embora odiando os  
alemães, continuam a olhar de cima para os ingleses e a tratar a Inglaterra de cobarde e o seu governo de &quot;regime  
dos homens velhos&quot;, têm de ser sacudidos com força. Talvez os seus cérebros desarranjados voltem assim a ter  
todas as suas circunvoluções no sítio.</p>
<p>Tua Anne</p>
<h2>Quarta-feira, 14 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>Muitos desejos, muitos pensamentos, muitas acusações e censuras se confundem na minha  
cabeça como fantasmas.</p>
<p>Podes crer, não sou tão presunçosa como algumas pessoas julgam; conheço melhor os  
meus inúmeros defeitos do que qualquer outra pessoa. Só há uma diferença: é que eu sei, além disso, que tenho vontade  
de me corrigir e que, em certa medida, já me tenho corrigido. Muitas vezes pergunto-me porque é que tanta gente me acha  
presunçosa e pouco modesta. Sou assim tão presunçosa? É defeito só meu, ou não serão os outros também presunçosos?  
Esta última frase soa maluquinha, mas não a risco porque não ; é tão maluquinha como parece. A sra. van Daan, a minha  
acusadora número um, é conhecida como pouco inteligente, vamos mesmo dizê-lo com toda a franqueza: como  
&quot;estúpida&quot;. E as pessoas estúpidas, de uma maneira geral, não perdoam que os outros saibam mais alguma  
coisa do que elas.</p>
<p>A sra. van Daan acha-me estúpida por eu não ser tão lenta de compreensão como ela;  
acha-me pouco modesta por ela o ser ainda menos; acha os meus vestidos curtos de mais por os dela serem ainda mais  
curtos. E, afinal, acha-me impertinente porque ela mete-se, muito mais do que eu, a tomar parte em discussões sobre  
assuntos de que não percebe patavina. Um dos ditos de que mais gosto é este : &quot;Em cada censura há uma ponta de  
verdade&quot;.</p>
<p>Por isso vou confessar que sou, por vezes, impertinente.</p>
<p>Ora, o que tenho de mais incómodo no meu carácter é ser eu a pessoa que mais me critica  
e censura. Como a mãe ajunta a isto a sua porção de conselhos, o montão dos sermões torna-se tão indescritivelmente alto  
que eu, desesperada por não conseguir dominá-lo, me torno insuportável e malcriada, e a isso segue-se, como é natural, a  
minha velha queixa: &quot;Ninguém me compreende&quot;. Estas palavras estão ancoradas em mim e, mesmo que possa  
parecer incrível, também nela há uma ponta de verdade. Por vezes torturo-me com tantas acusações contra mim própria  
que seria preciso uma voz reconfortante para me ajudar a repor tudo na medida certa e sã e que também se preocupasse  
um pouco com a minha vida interior. Mas, infelizmente, procurei muito e nunca encontrei. Sei que pensas agora no Peter,  
não é verdade, Kit? Sim, o Peter ama-me não como um apaixonado mas como um amigo, a sua dedicação cresce de dia  
para dia, mas não sei explicar esse mistério que nos separa. Por vezes penso que o meu violento desejo de estar com ele é  
exagerado. Mas a verdade é que eu, depois de não ter estado lá em cima durante dois dias, sinto tão grandes saudades  
como nunca tive.</p>
<p>O Peter é gentil e bom mas não posso negar que muita coisa nele me causa decepção. Não  
gosto da maneira como ele reprova a religião; as suas conversas sobre comidas e coisas semelhantes não me agradam.  
Mas tenho a certeza de que, conforme combinámos, nunca nos havemos de zangar. O Peter é pacífico, tem bom génio e  
cede fàcilmente.</p>
<p>Aceita melhor as minhas observações do que as da mãe e faz esforços enormes por manter  
a ordem nas suas coisas. Mas porque é que não se abre comigo, porque é que não me deixa tocar o seu íntimo? A sua  
natureza é muito mais reservada do que a minha, bem sei-sei-o por experiência - mas até as pessoas mais reservadas têm  
o desejo irresistível de se confiar a alguém, mesmo que seja uma única vez. O Peter e eu passámos os dois anos mais  
importantes para a nossa formação aqui no anexo; falámos muitas vezes sobre o passado, o presente e o futuro, mas,  
como eu já disse, sinto a falta de qualquer coisa de mais autêntico; e eu tenho a certeza de que essa coisa existe.</p>
<p>Tua Anne</p>
<h2>Quinta-feira, 15 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>Terei eu agora tanto interesse pela natureza por não poder, há tanto tempo, sair deste  
buraco? Ainda me lembro de que antigamente não me fascinavam os pássaros a cantar, o céu azul e brilhante, as flores e  
o luar. Por exemplo, no Pentecostes, quando estava tanto calor, fiz todos os esforços para me conservar acordada às onze  
e meia, para poder absorver sòzinha o luar pela janela; infelizmente não me serviu de nada, porque a Lua brilhava com  
tanta claridade que não pude arriscar-me a abrir a janela. Uma outra vez, isto já foi há vários meses, estava eu, por acaso,  
lá em cima e vi que a janela tinha ficado aberta. Enquanto ninguém a veio fechar, deixei-me ficar.</p>
<p>A noite chuvosa, a ventania, as nuvens em fuga, tudo isso tomou totalmente conta de mim;  
depois de ano e meio foi pela primeira vez que me vi cara a cara com a noite.</p>
<p>Desde então, o meu desejo de viver outra vez momentos assim tornou-se mais forte do que  
o medo dos ratos, dos ladrões e dos assaltos. Descia, por vezes, sòzinha para o andar de baixo, para olhar pela janela do  
escritório particular ou da cozinha. Muita gente ama a natureza, muitos dormem, por vezes, ao relento. Há outros que estão  
nas prisões e nos hospitais e anseiam pelo dia em que possam gozar o ar livre, mas poucos estão como nós, tão fechados  
e isolados daquilo que, ao fim e ao cabo, nos pertence a todos igualmente, aos ricos e aos pobres. Não é em imaginação  
que fico mais calma e que me encho de esperança quando olho o céu, as nuvens, a Lua e as estrelas. É um remédio  
melhor do que a valeriana e o bromo. A natureza torna-me um ser humilde, torna-me capaz de suportar ; melhor todos os  
golpes. É, no entanto, inevitável que eu só a possa contemplar - e mesmo assim por excepção - através das janelas sujas  
com cortinas cheias de pó, o que diminui o meu prazer, pois a natureza é a única coisa que não pode ser imitada ou  
substituída.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 16 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>Problemas novos! A sra. van Daan está desesperada.</p>
<p>Fala em balas na cabeça, em prisão, enforcamento, suicídio.</p>
<p>Tem ciumes por o Peter se confiar a mim e não a ela. Está ofendida por o Dussel não  
corresponder às suas coqueterias; tem medo de que o marido gaste todo o dinheiro do seu casaco de peles; discute,  
chora, queixa-se, ri e começa de novo a discutir. O que há-de fazer-se a uma choramingas desta força? Ninguém a está a  
tomar a sério.</p>
<p>Ela não tem carácter, queixa-se a toda a gente e veste-se de uma maneira disparatada;  
vista por detrás parece uma menina de liceu, vista de frente é uma peça de museu.</p>
<p>O pior é que o Peter torna-se malcriado com ela, o sr. van Daan irrita-se e a mãe fica cínica.  
Uma linda situação, não há dúvida! Para isto há só um remédio que deves ter sempre presente : ri-te de tudo e não faças  
caso dos outros! Pode parecer egoísta mas, na realidade, é a única defesa para aqueles que são obrigados a consolar-se  
a si próprios.</p>
<p>O Kraler foi novamente convocado para trabalhos de sapador. Está a ver se consegue  
safar-se com um atestado médico e uma carta da firma. O Koophuis tem de fazer outra operação ao estômago. Ontem, às  
11 horas, todas as ligações telefónicas particulares foram cortadas.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 23 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>Nada de especial a relatar. Os ingleses começaram com a grande ofensiva sobre  
Cherbourg. O Pim e o sr. van Daan são de opinião de que estaremos livres em Outubro.</p>
<p>Os russos também estão activos; ontem começaram a sua ofensiva em Witebsk,  
precisamente três anos depois da invasão dos alemães.</p>
<p>Já quase não temos batatas; doravante, vão ser contadas e divididas em rações iguais;  
depois cada um que se arranje.</p>
<p>Tua Anne</p>
<h2>Terça-feira, 27 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>Boa disposição, tudo está a caminhar da melhor maneira.</p>
<p>Cherbourg, Witebsk e Slobin caíram hoje. Muitos prisioneiros, muitos despojos. Na batalha  
de Cherbourg morreram cinco generais alemães e dois ficaram prisioneiros.</p>
<p>Agora os ingleses podem desembarcar quantas coisas quiserem, pois já têm um porto. Toda  
a península de Gotentin, depois de três semanas, nas mãos dos ingleses. É de respeito! Nestas três semanas, desde o  
&quot;D-day&quot;, ainda não houve um único dia sem chuvas e ventanias, tanto aqui como na França, mas nem esta má  
sorte impede os ingleses e os americanos de mostrarem a sua força, e que força!</p>
<p>Já se vê, a &quot;Vz&quot;, a arma milagrosa, também entrou em acção, mas tais foguetes  
pouco mais significam do que pequenos danos na Inglaterra e grandes relatos nos jornais dos &quot;boches&quot;. Aliás,  
se na terra dos &quot;boches&quot; souberem que o &quot;perigo bolchevique&quot; está a aproximar-se, hão-de tremer  
como varas verdes.</p>
<p>Todas as mulheres e crianças alemãs que não trabalham na &quot;Wehrmacht&quot; são  
evacuadas das regiões da costa para Groningen, Friesland e Gelderland. Mussert declarou que vestirá o uniforme, caso a  
invasão venha até aqui.</p>
<p>O gorducho quererá lutar? Poderia tê-lo feito há mais tempo, na Rússia. A Finlândia que  
tinha recusado, em tempos, as propostas de paz, rompeu de novo as negociações.</p>
<p>Hão-de se arrepender, os idiotas.</p>
<p>Como estarão as coisas no dia 27 de Julho? O que é que pensas?</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 30 de Junho de 1944</h2>
<p>Querida Kitty:</p>
<p>Mau tempo ou: bad weather at a stretch to the 30th of June. Está bem assim? Oh, sim, já sei  
muito inglês. Estou a ler An ideal Husband (com o dicionário).</p>
<p>As notícias de guerra são excelentes. Bobruisk, Mogilew e Orscha caíram. Muitos  
prisioneiros. Aqui tudo &quot;all right&quot;, a disposição também. Os nossos hiperoptimistas estão a delirar. A Eli mudou  
de penteado. A Miep tem uma semana de férias. Aqui tens as últimas novidades.</p>
<p>Tua Anne</p>`],

28: [`<h2>Quinta-feira, 6 de Julho de 1944</h2><p>Querida Kitty:</p>
<p>Amargura-se-me o coração quando ouço dizer ao Peter que ainda poderá vir a ser, mais  
tarde, um criminoso ou um especulador. Bem sei que ele diz aquilo por brincadeira, mas tenho a impressão de que tem  
medo da sua própria fraqueza de carácter. Tanto a Margot como o Peter repetem-me constantemente:</p>
<p>-Ah! se eu fosse tão forte e corajosa como tu, se tivesse tanta força de vontade, tanta  
persistência...</p>
<p>Será de facto uma boa qualidade isto de eu não me deixar influenciar? Estará certo que siga  
quase exclusivamente o caminho que me dita a minha consciência?</p>
<p>Com toda a franqueza, custa-me compreender que alguém possa dizer &quot;sou  
fraco&quot; e se deixe ficar fraco na mesma.</p>
<p>Se a gente conhece os seus defeitos porque não tenta então corrigi-los? Resposta do  
Peter:</p>
<p>- Porque assim é muito mais cómodo.</p>
<p>Esta resposta desencorajou-me bastante. Cómodo! Quer ele dizer que uma vida de preguiça  
e de auto-ilusão é uma vida cómoda? Oh, não, não, recuso-me a acreditar nisso. Não é possível que a moleza e... o  
dinheiro sejam tão aliciantes. Pensei muito tempo no que havia de lhe responder, em como poderei levar o Peter a ter  
confiança em si próprio e, principalmente, a corrigir-se. Mas não sei se serei bem sucedida.</p>
<p>Julgava maravilhoso possuir a confiança de alguém, mas só agora vejo como é difícil  
identificar-me com os pensamentos de outrem e dar um conselho justo, tanto mais que os conceitos de  
&quot;cómodo&quot; e de &quot;dinheiro&quot; são para mim novos e um tanto estranhos. O Peter começa a encostar-se a  
mim e acho que não devia ser assim. Não é fácil para um rapaz como o Peter aguentar-se sobre as próprias pernas, mas  
ainda lhe custará mais na medida em que se for tornando um homem consciente à procura de um caminho na vida, através  
de um mar de problemas.</p>
<p>Sinto-me como se andasse à roda de mim mesma procurando uma justificação para o  
medonho conceito de &quot;cómodo&quot;.</p>
<p>Como poderei eu explicar-lhe, a ele, que aquilo que aparentemente é tão cómodo e tão  
bonito, o arrastará para o abismo, esse abismo onde já não há nem amigos, nem beleza, nem apoio, o abismo donde é  
quase impossível tornar a subir?</p>
<p>Todos vivemos sem saber porquê e para quê, todos procuramos ser felizes, todos vivemos  
de um modo diferente e no entanto somos todos iguais. Nós, os três jovens, fomos educados num ambiente elevado, temos  
a capacidade de aprender e de conseguir alguma coisa, temos igualmente razão para esperar uma vida bela, mas...  
depende de nós merecê-la. Para isso é necessário esforço, não basta buscar a comodidade.</p>
<p>Merecer a felicidade quer dizer trabalhar para ela, ser bom e não se deixar seduzir por  
especulações ou pela preguiça. Talvez a preguiça &quot;pareça&quot; coisa agradável, mas o trabalho dá satisfação. Não  
compreendo as pessoas que não gostam de trabalhar, mas não é este o caso do Peter.</p>
<p>Ao Peter só lhe falta uma finalidade, um objectivo firme; ele acha-se estúpido e inferior para  
conseguir coisa de jeito.</p>
<p>Pobre rapaz, ainda não conheceu a sensação agradável que é dar felicidade aos outros e  
isso não lhe posso eu ensinar. Não tem religião, troça de Jesus, renega o nome de Deus. Embora eu não seja ortodoxa,  
sinto uma dor profunda ao aperceber-me do seu desdém, do seu abandono, da pobreza da sua alma.</p>
<p>Aqueles que têm uma religião podem sentir-se felizes, pois não é dada a todos a fé nas  
coisas celestes. Nem é preciso ter medo do castigo depois da morte. Há muita gente que não admite o Purgatório, o Inferno  
ou o Céu, mas uma religião-e não importa qual-mantém os homens no caminho recto. Não se trata do medo de Deus mas  
sim da estima da nossa própria honra e da nossa consciência.</p>
<p>Como seria bela e boa toda a Humanidade se, antes de adormecer à noite, evocasse os  
acontecimentos do dia que passou, se reflectisse no que foi bom e no que foi mau.</p>
<p>Assim, quase sem dar por isso, tentamos corrigir-nos constantemente, e depois de certo  
tempo alguma coisa conseguimos. Este método toda a gente o pode utilizar, não custa nada, está ao alcance de quem  
quiser. Quem o não conhece deve aprender e experimentar: &quot;Uma consciência tranquila torna-nos fortes!&quot;</p>
<p>Tua Anne</p>
<h2>Sábado, 8 de Julho de 1944</h2>
<p>Querida Kitty:</p>
<p>O representante principal da firma, o sr. B, esteve em Beverwijk, onde conseguiu arranjar  
morangos. Chegaram aqui cheios de pó e de areia, mas são muitos: caixotes para o escritório e para nós. Fizemos  
imediatamente oito frascos de conservas e oito boiões de compota. Amanhã, a Miep também vai fazer compota para o  
escritório.</p>
<p>Ao meio-dia e meia hora, quando já não há mais estranhos no prédio, e com a porta da rua  
fechada, vamos buscar os caixotinhos. O Peter, o pai e o sr. van Daan desfilam na escada, a Anne traz a água quente, a  
Margot os baldes, enfim, todos dão uma ajuda. Com uma sensação estranha no estômago entrei na cozinha do escritório: a  
Miep, a Elli, o Koophuis, o Henk, o pai, o Peter, a coluna dos &quot;mergulhados&quot; e a do reabastecimento, tudo à  
mistura em pleno dia.</p>
<p>Bem sei que ninguém pode olhar cá para dentro através das cortinas, mas as vozes, as  
portas a bater, tudo isto, faz-me tremer de aflição. Pergunto-me se somos de facto &quot;mergulhados&quot;, penso que  
terei uma sensação semelhante quando puder um dia entrar, de novo, no mundo exterior.</p>
<p>A panela estava cheia. Subi depressa. Na nossa cozinha estava o resto da família a tirar os  
talos dos morangos.</p>
<p>Metiam mais frutos na boca do que no balde. Daí a pouco-era preciso mais um balde - o  
Peter desceu à cozinha do escritório e, nesse momento, a campainha toca duas vezes. O Peter deixa ficar o balde, sobe  
para fechar a porta giratória. Nós, cheios de impaciência! As torneiras não se podiam abrir, embora os morangos  
precisassem urgentemente de ser lavados. Mas a regra dos &quot;mergulhados&quot; é esta: &quot;Se estiver algum  
estranho no prédio, todas as torneiras devem estar fechadas por causa do perigo dos ruídos&quot;. E esta regra cumpre-se  
rigorosamente.</p>
<p>À uma hora veio o Henk para nos dizer que tinha sido o carteiro quem tocara a campainha.  
O Peter corre de novo escada abaixo. Trrin, a campainha outra vez. E o Peter volta a subir. Eu ponho-me a escutar,  
primeiro encostada à porta camuflada, depois em cima da escada, sem fazer o menor ruído. O Peter vem também e, por fim,  
parecíamos dois ladrões dependurados no corrimão a escutar o barulho lá debaixo. Não distinguíamos nenhuma voz que  
nos fosse estranha. Então o Peter desceu muito cautelosamente alguns degraus e chamou:</p>
<p>-Elli!</p>
<p>Não veio resposta. Outra vez :</p>
<p>-Elli!</p>
<p>O barulho na cozinha é mais alto do que a voz do Peter. Ele então desce e eu olho para  
baixo, cheia de nervos.</p>
<p>-Sobe depressa, anda, Peter, está cá o fiscal da contabilidade!</p>
<p>Era a voz do sr. Koophuis. Suspirando, o Peter volta, a porta giratória fecha-se. à uma e  
meia veio, finalmente, o Kraler:</p>
<p>-Por amor de Deus! Não vejo senão morangos. Dão-me morangos ao pequeno almoço, o  
Henk a comer morangos, o Koophuis a petiscar morangos, a Miep a cozer morangos, o cheiro a morangos por toda a parte.  
Já não podia mais e por isso resolvi subir até aqui-e o que vejo?-gente a lavar morangos!</p>
<p>Do resto dos morangos fizeram-se conservas. à noite as tampas de dois frascos saltaram  
fora. O pai tira os morangos e faz compota. Na manhã seguinte outras duas tampas saltam, à hora do almoço, mais quatro.  
O sr. van Daan não esterilizou os frascos suficientemente. E agora o pai faz todas as noites compota. Comemos papinhas  
com morangos, soro de leite com morangos, pão com morangos, sobremesa de morangos, morangos com açúcar,  
morangos com areia... Durante dois dias os morangos andaram a dançar por toda a parte : morangos, morangos,  
morangos.</p>
<p>Depois não se viram mais, os frascos de compota ficaram bem fechados à chave.</p>
<p>-Anda cá ver, Anne, chama a Margot-o hortaliceiro da esquina mandou nove quilos de  
ervilhas.</p>
<p>-Acho simpático da parte dele, disse eu, mesmo muito simpático, mas o trabalho que isto  
dá... que horror!</p>
<p>-No domingo de manhã vocês todos têm de ajudar a descascar-anunciou a mãe à mesa. E  
assim foi. Hoje de manhã, depois do pequeno almoço, apareceu em cima da mesa o grande alguidar de esmalte cheio, até  
acima, de ervilhas. Debulhar ervilhas pequeninas é um trabalho aborrecido, mas o que custa é aproveitar as cascas das  
vagens. Sei que a maioria das pessoas não faz ideia de como são saborosas as cascas das ervilhas depois de a gente  
lhes ter tirado a película interior. A grande vantagem está em se poder comer muito mais do que se nos limitássemos  
apenas às ervilhas. Tirar as pelezinhas é um trabalho preciso e minucioso, que, talvez, seja mais próprio para dentistas  
ultrameticulosos e burocratas mesquinhos; para uma rapariga impaciente como eu, torna-se horrível. às nove e meia  
começámos; às dez e meia resolvi fazer um intervalo de uma hora. Os ouvidos zumbem-me: cortar a ponta, tirar a  
pelezinha, depois os fios, deitar as ervilhas no alguidar, etc. Foge-me a vista: verde, verde, bichos, fios, cascas podres,  
verde, verde, verde.</p>
<p>Fiquei estúpida e para fazer alguma coisa passei a falar durante todo o tempo. A dizer  
asneiras faço rir toda a gente, mas eu é que fico com a sensação de morrer de aborrecimento.</p>
<p>A cada fiozinho que tiro, mais me convenço de que nunca quererei ser apenas dona de  
casa!</p>
<p>Ao meio-dia comemos, finalmente. Mas ao meio-dia e meia hora começamos de novo a tirar  
peliculazinhas até à uma hora e um quarto. Quando chegámos ao fim eu estava enjoada e os outros também um pouco;  
dormi até às quatro horas, mas ainda me sinto toda moída de tanta ervilha.</p>
<p>Tua Anne</p>
<h2>Sábado, 15 de Julho de 1944</h2>
<p>Querida Kitty:</p>
<p>Lemos um livro da biblioteca com o título maravilhosamente provocante : O que pensa você  
da rapariga moderna?.</p>
<p>Quero falar-te hoje sobre este tema. A autora critica, dos pés à cabeça, a &quot;juventude  
de hoje&quot; sem, no entanto, acusar tudo quanto é jovem de &quot;não servir para nada&quot;. Pelo contrário, ela pensa  
que a juventude, se quisesse, podia construir um mundo maior, mais belo e melhor.</p>
<p>Diz que a juventude tem os meios para isso mas que se preocupa com assuntos  
superficiais, sem reparar no que há de essencialmente belo nas coisas. Ao ler certos parágrafos tive a impressão de ser  
visada e, por isso, quero desabafar aqui com alguns pensamentos e defender-me contra aqueles ataques.</p>
<p>Tenho um traço marcante no meu carácter-todos os que me conhecem já deram por ele: a  
autocrítica. Vejo-me em todos os meus actos como se se tratasse de uma pessoa estranha. Enfrento esta Anne com  
absoluta imparcialidade, sem pretender desculpá-la e observo o que ela faz de mal e de bem. Esta autocontemplação  
nunca me larga, e não posso pronunciar uma palavra sem pensar logo em seguida: &quot;devia ter dito isto de outra  
maneira&quot;, ou: &quot;foi bem dito&quot;.</p>
<p>Condeno muitas vezes os meus actos e reconheço cada vez mais a verdade das palavras  
de meu pai: &quot;Cada criança deve educar-se a si própria&quot;. Os outros só nos podem dar conselhos ou indicar-nos o  
caminho a seguir, mas a formação definitiva do carácter está nas próprias mãos de cada indivíduo. A isso devo acrescentar  
que tenho uma coragem extraordinária de viver, sinto-me sempre forte e capaz de suportar seja o que for. Sinto-me tão  
livre, tão jovem! Quando me dei conta disto pela primeira vez fiquei contente, pois não supunha que os golpes que ninguém  
está livre de apanhar, me pudessem esmagar ràpidamente. Mas sobre este assunto já falei muitas vezes.</p>
<p>Deixa-me chegar ao ponto principal: &quot;O pai e a mãe não me entendem&quot;.  
Deram-me muitos mimos, foram sempre bons para comigo, defenderam-me, em resumo: fizeram tudo o que os pais podem  
fazer. E todavia tenho-me sentido, muitas vezes, terrivelmente só, posta de parte, descurada, incompreendida. O pai tem  
feito tudo para atenuar os meus protestos, mas em vão; fui eu mesma que me curei, reconhecendo os erros dos meus  
actos. Mas como se explica que o pai não me possa ter dado o necessário apoio na minha luta? Como se explica que ele  
tenha falhado quando me oferecia o seu auxílio? O pai falhou porque não conseguiu encontrar a maneira de falar comigo,  
tratava-me como uma criancinha que só tem preocupações infantis. Pode parecer tolice eu dizer isto, pois foi justamente o  
pai quem me inspirou sempre confiança e me deu a certeza de que sou inteligente. Mas há uma coisa em que se esqueceu  
de pensar: é que a minha luta para me elevar era mais importante para mim do que tudo o mais. Eu não queria ouvir:  
&quot;sintomas típicos... outras raparigas... isto passa&quot;, etc. Não queria ser tratada como todas as raparigas, mas  
como um ser com personalidade própria, como a ANNE. Foi isto o que o Pim não soube compreender. De resto não me é  
possível abrir-me com alguém que não me fale também de si; como sei muito pouco da vida do Pim, nunca poderá  
estabelecer-se entre nós uma intimidade completa. O Pim coloca-se sempre no ponto de vista do mais velho que também  
passou por coisas semelhantes mas que já não pode sentir e viver o que vive um jovem, embora tente fazê-lo. Tudo isto me  
levou a nunca comunicar a ninguém a minha concepção da vida e as minhas teorias longamente meditadas, a não ser; de  
longe em longe, à Margot.</p>
<p>Tudo o que me preocupava escondia-o do pai, não o deixei partilhar comigo os meus ideais  
e, conscientemente, alheei-me dele. Não me foi possível ser diferente, deixei-me conduzir pelos sentimentos, mas agi de  
modo a encontrar sossego. E o meu sossego, e a confiança em mim mesma, que fui construindo sobre bases oscilantes  
talvez não resistissem se eu tivesse de suportar críticas a esta minha obra ainda não acabada. E nem ao Pim posso permitir  
que se meta de permeio. Por mais duro que isto possa soar, afastei-o de mim, não o deixando partilhar da minha vida  
interior, principalmente pela minha irritabilidade. É um ponto que me preocupa constantemente. Porque é que o Pim me  
irrita tanto a ponto de não poder estudar com ele, de me parecerem artificiais os seus carinhos, de desejar só o meu  
sossego e que ele me deixe em paz até eu possuir mais segurança íntima? A verdade é que ainda me censuro por causa  
daquela carta vil que ousei escrever-lhe num momento de excitação. Oh! Como é difícil ser-se forte e corajosa em todas as  
circunstâncias.</p>
<p>Mas esta ainda não é a minha decepção mais grave :</p>
<p>muito mais do que o pai preocupa-me o Peter. Sei bem que fui eu quem o conquistou a ele e  
não o contrário; construí dele uma visão idealizada, vi nele um rapaz simpático, calado, sensível, precisando de muito amor  
e de amizade. Tive necessidade de abrir-me com um ser vivo, com um amigo que me mostrasse o caminho a seguir.  
Consegui que ele, pouco a pouco, fosse atraído por mim. Finalmente, depois de ter despertado nele sentimentos amigáveis,  
passámos a intimidades que me parecem, agora, inconcebíveis. Falámos sobre muitas coisas íntimas mas sobre aquelas  
que me enchem o coração ainda não dissemos palavra. Não me foi possível, até agora, fazer uma ideia exacta do Peter; é  
ele um rapaz superficial, ou não consegue vir francamente ao meu encontro por ser tímido? Mas eu cometi um erro grave:  
eliminei, logo de entrada, todas as possibilidades de uma grande amizade entre nós, tentando aproximar-me dele por uma  
intimidade exagerada. Ele está ávido de amor e de dia para dia cada vez gosta mais de mim, bem o sinto. O nosso convívio  
satisfá-lo plenamente, mas em mim produz apenas o efeito de tentativas renovadas para recomeçar e tocar nos assuntos  
que tanto gostaria de abordar e de esclarecer.</p>
<p>Atraí o Peter à força, e ele nem se deu conta disso. Agora agarra-se a mim e, por enquanto,  
não vejo como o hei-de sacudir de mim e repô-lo sobre os seus próprios pés. Depois de me ter apercebido de que ele não  
pode ser para mim o amigo que ansiava, esforcei-me para o elevar acima dos seus pontos de vista limitados e para que  
não desperdice a sua juventude. &quot;Pois, no fundo, a juventude é mais solitária do que a velhice&quot;. Encontrei esta  
frase num livro e fixei-a, porque encontrei nela a verdade.</p>
<p>É a nossa vida aqui mais difícil de suportar para os adultos de que para nós? Não, decerto  
não! As pessoas com mais idade já têm opiniões formadas sobre todas as coisas e já não vacilam, não hesitam perante as  
dificuldades da sua vida. A nós, os jovens, custa-nos manter-nos firmes nos nossos pareceres por vivermos numa época  
em que mostra pelo seu lado mais horroroso, em que se duvida da verdade, do direito, de Deus!</p>
<p>Aquele que pretende afirmar que os mais velhos sofrem mais aqui no anexo do que nós, os  
jovens, não sabe ver até que ponto os problemas desabam sobre nós, problemas para os quais talvez ainda não tenhamos  
bastante idade, mas que se nos impõem de um modo violento. Em determinada altura julgamos ter encontrado uma solução  
mas esta solução, de uma maneira geral, não resiste aos factos que são sempre tão diferentes. Eis a dificuldade do nosso  
tempo : mal começam a germinar em nós ideais, sonhos, belas esperanças, logo a realidade cruel se apodera de tudo isso  
para o destruir totalmente.</p>
<p>É por milagre que eu ainda não renunciei a todas as minhas esperanças, na verdade tão  
absurdas e irrealizáveis.</p>
<p>Mas eu agarro-me a elas, apesar de todos e de tudo, porque tenho fé no que há de bom no  
homem. Não me é possível construir a vida tomando como base a morte, a miséria e a confusão. Vejo o Mundo  
transformar-se, pouco a pouco, num deserto; ouço, cada vez mais forte, a trovoada que se aproxima, essa trovoada que  
nos há-de matar; sinto o sofrimento de milhões de seres e, mesmo assim, quando ergo os olhos para o Céu, penso que, um  
dia, tudo isto voltará a ser bom, que a crueldade chegará ao seu fim e que o Mundo virá a conhecer de novo a ordem, a  
paz, a tranquilidade.</p>
<p>Até lá tenho que manter firme os meus ideais-talvez ainda os possa realizar nos tempos que  
hão-de vir.</p>
<p>Tua Anne</p>
<h2>Sexta-feira, 21 de Julho de 1944</h2>
<p>Querida Kitty:</p>
<p>Estou cheia de esperanças, tudo vai bem! Sim, vai mesmo muito bem! Notícias  
sensacionais. Houve um atentado contra Hitler mas, imagina, os autores não foram comunistas, judeus ou capitalistas  
ingleses, mas sim um general alemão da nobre raça germânica, e, ainda por cima, um general ainda jovem! A  
&quot;providência divina&quot; salvou a vida do Führer e ele escapou-infelizmente, infelizmente! - com algumas  
arranhadelas e queimaduras.</p>
<p>Alguns oficiais e generais que andavam com ele morreram ou ficaram feridos. O autor  
principal foi fuzilado. Este atentado é a melhor prova de que muitos oficiais e generais estão fartos desta guerra e que  
veriam com prazer o Hitler afundar-se nos mais profundos precipícios. Querem, depois da morte de Hitler, instalar uma  
ditadura militar, fazer as pazes com os aliados, rearmar-se, para desencadear uma nova guerra daqui a vinte anos. Talvez  
a Providência tenha hesitado, de propósito, em afastar Hitler desde já, pois aos aliados faz muito mais jeito, e é muito mais  
vantajoso, que os alemães arianos puros se matem uns aos outros; assim haverá depois menos canseira para os russos e  
para os ingleses que poderão mais depressa começar a reconstruir as suas cidades. Mas ainda não chegámos a este  
ponto e eu não quero antecipar-me aos factos gloriosos.</p>
<p>Tu decerto estás a notar que tudo o que te estou a dizer é a realidade nua e crua, uma  
realidade com os dois pés fincados no chão, e que eu, excepcionalmente, não estou a delirar com ideias superiores.</p>
<p>Hitler teve a amabilidade de comunicar ao seu povo dedicado que os militares, de hoje em  
diante, terão de obedecer à Gestapo e que qualquer soldado, se souber que um seu superior esteve implicado neste  
atentado tão cobarde e tão baixo, poderá meter-lhe, sem cerimónias, uma bala na cabeça.</p>
<p>Vai ser bonito. Imagina: ao Hans Dampf doem-lhe os pés de tanto marchar; o seu superior, o  
chefe, dá-lhe um raspanete. O Hans pega na espingarda e grita:</p>
<p>-Tu quiseste matar o nosso Führer, toma a recompensa.</p>
<p>Pum! O orgulhoso chefe que se atreveu a censurar o pequeno soldado, foi despachado  
para a vida eterna (ou será para a morte eterna?). O resultado vai ser este: os senhores oficiais vão andar sempre com as  
cuecas sujas de tanto medo e não se atreverão mais a dizer seja o que for a um simples soldado.</p>
<p>Compreendes tudo? Ou gaguejei eu ao escrever? Se assim for não há nada a fazer, pois  
estou contente de mais para observar a lógica, contente por ter esperanças de que em Outubro estarei, de novo, sentada  
nos bancos da escola. Olá, não disse eu há pouco que não me devo antecipar? Não te zangues. Não é por acaso que me  
chamam &quot;um feixe de contradições&quot;.</p>
<p>Tua Anne</p>`],

29: [`<h2>Terça-feira, 1 de Agosto de 1944</h2><p>Querida Kitty:</p>
<p>&quot;Um feixe de contradições&quot;. Foi esta a última frase da minha carta anterior e é a  
primeira da de hoje. &quot;Um feixe de contradições&quot;, poderás tu explicar-me, com exactidão, o que isto quer dizer? O  
que é contradição? Como todas as palavras, tem dois sentidos : contradição exterior e contradição interior.</p>
<p>O primeiro sentido é este : não nos conformarmos com a opinião dos outros, querer saber  
tudo melhor, querer ter a última palavra, enfim: qualidades desagradáveis que já conheces suficientemente. O segundo:  
qualidades que também tenho mas que ninguém conhece e que são o meu segredo.</p>
<p>Já te contei em tempos que não tenho só uma alma mas sim duas. Uma dá-me a minha  
alegria exuberante, as minhas zombarias a propósito de tudo, a minha vontade de viver e a minha tendência para deixar  
correr, isto é, para não me escandalizar com &quot;flirts&quot;, abraços ou uma piada inconveniente. Esta primeira alma  
está sempre à espreita e faz tudo para suplantar a outra que é mais bela, mais pura, mais profunda. Essa alma boa da  
Anne ninguém a conhece, não é verdade? E é por isso que tão pouca gente gosta de mim.</p>
<p>Bem o sei: vêem em mim um palhaço divertido para uma tarde-depois toda a gente fica  
cheia de mim para um mês-sou, no fim de contas, o mesmo que um filme amoroso para gente sisuda, uma simples  
distracção, um divertimento, alguma coisa que se esquece depressa, não precisamente má mas também nada de especial.  
Não me é agradável contar-te isto, mas, por outro lado, porque não o havia de contar se é a pura verdade? Este meu lado  
superficial tentará sempre afastar o outro, o mais profundo, e alcançará, por isso, a vitória. Não podes fazer ideia de  
quantas vezes tenho tentado repelir, espancar ou esconder esta Anne, que não passa da metade daquilo que se chama  
Anne; mas não serve de nada, e bem sei porquê. Tenho medo de que todos os que me conhecem, tal como costumo ser,  
possam descobrir o meu outro lado, o mais belo, o melhor. Tenho medo de que trocem de mim, me achem ridícula e  
sentimental, e não me tomem a sério. Estou habituada a não ser tomada a sério, mas é justamente a Anne mais  
&quot;fácil&quot; que suporta isso; a &quot;mais profunda&quot; não tem forças para tanto. Empurro por vezes a boa Anne  
para a luz da ribalta, mesmo que seja por um escasso quarto de hora, mas logo que ela tem de falar, contrai-se e fecha-se  
de novo na sua concha, passando a palavra à Anne número 1. E antes que eu me dê conta, já a boa desapareceu.</p>
<p>É por isso que a Anne terna e simpática nunca vem à superfície na presença das outras  
pessoas mas é a sua voz que domina na solidão. Sei exactamente como gostava de ser, sei como sou... no íntimo, mas,  
infelizmente, só sou assim quando estou sòzinha comigo. E isto é, talvez, não seguramente, a razão por que chamo à  
minha natureza íntima uma natureza feliz e porque os outros chamam feliz à minha natureza exterior. No meu interior, a  
Anne pura é que me indica o caminho; exteriormente, não passo de um cabritinho que pula de alegria e de animação.</p>
<p>Como eu já disse, vejo e sinto as coisas de um modo e exteriorizo-as de outro e tenho, por  
isso, a fama de ser uma rapariga doida por rapazes, sempre a &quot;flirtar&quot;, sempre impertinente e sempre a ler  
romances. A Anne alegre ri-se, dá respostas atrevidas, encolhe os ombros com indiferença como se isso nada tivesse que  
ver com ela, mas, ai de mim!, a Anne calada reage ao contrário. Como sou sempre franca contigo, vou confessar-te que  
tenho pena, que me esforço terrivelmente por me modificar, mas que luto sempre contra forças superiores às minhas.  
Dentro de mim uma voz sussurra: -Vês o resultado? Más opiniões a teu respeito, caras trocistas e consternadas, gente que  
te acha antipática, e tudo isto porque não queres ouvir os conselhos do teu próprio lado bom. Ai! Bem os queria eu ouvir,  
mas não pode ser; quando estou calada e séria, todos pensam que estou a representar uma nova comédia. Para me salvar  
só me resta dizer uma piadinha. Pior ainda quando se trata da minha família que imagina logo que estou doente e me  
impinge pastilhas contra as dores de cabeça e o nervosismo, que me toma o pulso a ver se tenho febre, que pergunta  
como funciona o aparelho digestivo para, em seguida, censurar o meu mau génio. Não suporto semelhante coisa. Quando  
me tratam desta maneira, torno-me ainda mais impertinente, fico triste e, por fim, viro o meu coração do avesso - o lado  
mau para fora, o bom para dentro - e continuo a procurar um meio para vir a ser aquela que gostava de ser, que era capaz  
de ser, se... sim, se não houvesse mais ninguém no Mundo.</p>
<p>Tua Anne M. Frank</p>
<p>&nbsp;</p>
<p>AQUI TERMINA O DIÁRIO DE ANNE</p>`],

30: [`<h2>EPÍLOGO</h2><p>No dia 5 de Agosto a &quot;Grüne Polizei&quot; assaltou o anexo, prendeu todos os seus  
habitantes e também o sr. Kraler e o sr. Koophuis, levando os primeiros para um campo de concentração na Alemanha e os  
segundos para outro na Holanda.</p>
<p>A Gestapo pilhou o anexo. Mais tarde, a Miep e a Elli encontraram, entre velhos livros,  
revistas e jornais a que os agentes não ligaram importância, o Diário da Anne.</p>
<p>Com excepção de algumas passagens apenas que não teriam interesse para o leitor, o texto  
original é publicado na íntegra.</p>
<p>Dos oito &quot;mergulhados&quot; só o pai sobreviveu. O sr. Kraler e o sr. Koophuis  
resistiram às privações nos campos holandeses e voltaram para junto de suas famílias.</p>
<p>Anne morreu em Março de 1945 no campo de concentração de Bergen-Belsen, dois meses antes da libertação da Holanda.</p>`]}
function capitulo(nr) {
let div = document.getElementById("goTo");
div.innerHTML = capitulos[nr].join("<p><p>");}














