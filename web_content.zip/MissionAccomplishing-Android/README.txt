MISSION ACCOMPLISHING — ANDROID APP PROJECT
===========================================
This folder is an Android Studio project that wraps your Mission Accomplishing app
(app/src/main/assets/index.html) into a real Android app (APK).
The app works offline. Orbit AI needs internet and your own Gemini API key (Settings inside the app).

NOTE: this project was written without an Android SDK and has NOT been compiled or installed yet.
If a build step shows an error, copy the error text and send it to me and I will fix it.

ROUTE A — Android Studio (a Windows / Mac / Linux computer)
1. Install Android Studio (free): developer.android.com/studio
2. Unzip this folder. In Android Studio choose File > Open and pick the MissionAccomplishing-Android folder.
3. Wait for "Gradle sync" to finish (first time it downloads files, so you need internet).
   If it offers to install an Android SDK platform or to update Gradle/plugin, accept.
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When it finishes, click "locate" in the pop-up. The file is app/build/outputs/apk/debug/app-debug.apk.
6. Send that APK to your phone (USB, Drive, email), open it, and allow "Install unknown apps" for the app you opened it from.

ROUTE B — No Android Studio (GitHub, free, only a browser)
1. Create a free account at github.com and a new empty repository (name it anything).
2. Upload ALL files from this folder to it (drag the folder contents onto the page; keep the .github folder).
3. Open the Actions tab > "Build APK" > Run workflow. Wait a few minutes.
4. Open the finished run, download the artifact "MissionAccomplishing-debug-apk", unzip it, and install app-debug.apk.
   (Use a PRIVATE repository if you do not want others to see the app.)

NOTES
- This is a "debug" APK: fine for your own phone, not for the Play Store. For the Play Store you need a signed release build.
- Your notes, chats and API key are stored inside the app on your phone. Uninstalling the app deletes them.
- To update the app later, replace app/src/main/assets/index.html with the new version and build again.
