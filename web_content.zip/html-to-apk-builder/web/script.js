const state = {
  blocks: [
    {type:"header", text:"My HTML App"},
    {type:"nav", text:"Home  |  About  |  Contact"},
    {type:"article", text:"Welcome to my app."},
    {type:"section", text:"This is a section."},
    {type:"aside", text:"Extra information"},
    {type:"footer", text:"© 2026 My HTML App"}
  ],
  iconData: null,
  apkUrl: null
};

const blocksEl = document.getElementById("blocks");
const frame = document.getElementById("previewFrame");
const terminalLog = document.getElementById("terminalLog");
const statusEl = document.getElementById("status");
const blockCount = document.getElementById("blockCount");

function log(line){
  terminalLog.textContent += (terminalLog.textContent ? "\n" : "") + line;
  terminalLog.scrollTop = terminalLog.scrollHeight;
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}

function safePackage(name){
  return /^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*)+$/.test(name);
}

function renderBlocks(){
  blocksEl.innerHTML = "";
  state.blocks.forEach((b,i)=>{
    const card=document.createElement("div");
    card.className="block-card";
    card.draggable=true;
    card.dataset.index=i;
    card.innerHTML=`
      <div class="block-head">
        <span class="drag">☷</span>
        <span class="block-name">&lt;${escapeHtml(b.type)}&gt;</span>
      </div>
      <textarea aria-label="${escapeHtml(b.type)} content"></textarea>
      <div class="block-controls">
        <button data-up>↑</button><button data-down>↓</button><button data-delete>Delete</button>
      </div>`;
    card.querySelector("textarea").value=b.text;
    card.querySelector("textarea").addEventListener("input",e=>{b.text=e.target.value; refreshPreview();});
    card.querySelector("[data-up]").onclick=()=>move(i,-1);
    card.querySelector("[data-down]").onclick=()=>move(i,1);
    card.querySelector("[data-delete]").onclick=()=>{state.blocks.splice(i,1);renderBlocks();refreshPreview();};
    card.addEventListener("dragstart",()=>card.classList.add("dragging"));
    card.addEventListener("dragend",()=>card.classList.remove("dragging"));
    card.addEventListener("dragover",e=>e.preventDefault());
    card.addEventListener("drop",e=>{
      e.preventDefault();
      const from=Number(document.querySelector(".dragging")?.dataset.index);
      if(Number.isInteger(from) && from!==i){
        const [item]=state.blocks.splice(from,1);
        state.blocks.splice(i,0,item);
        renderBlocks();refreshPreview();
      }
    });
    blocksEl.appendChild(card);
  });
  blockCount.textContent=`${state.blocks.length} block${state.blocks.length===1?"":"s"}`;
}

function move(i,dir){
  const j=i+dir;
  if(j<0||j>=state.blocks.length)return;
  [state.blocks[i],state.blocks[j]]=[state.blocks[j],state.blocks[i]];
  renderBlocks();refreshPreview();
}

function addBlock(type){
  state.blocks.push({type,text:`New ${type} content`});
  renderBlocks();refreshPreview();
}

function generatedHTML(){
  const name=document.getElementById("appName").value.trim()||"My HTML App";
  const body=state.blocks.map(b=>{
    const allowed=["header","nav","article","section","div","aside","footer"];
    const tag=allowed.includes(b.type)?b.type:"section";
    return `<${tag} class="builder-block">${escapeHtml(b.text).replace(/\n/g,"<br>")}</${tag}>`;
  }).join("\n");
  return `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(name)}</title>
<style>
body{margin:0;background:#0b0b0b;color:#fff;font-family:Arial,sans-serif;padding:20px}
.builder-block{padding:18px;margin:10px 0;border:1px solid #555;border-radius:12px;background:#151515}
header{font-size:28px;font-weight:bold} nav{background:#202020} footer{opacity:.75}
</style></head><body>${body}</body></html>`;
}

function refreshPreview(){
  frame.srcdoc=generatedHTML();
}

document.querySelectorAll(".palette-btn").forEach(btn=>{
  btn.onclick=()=>addBlock(btn.dataset.type);
});

document.getElementById("addBlockBtn").onclick=()=>{
  addBlock("section");
};

document.getElementById("previewBtn").onclick=()=>{
  refreshPreview();
  statusEl.textContent="Preview updated.";
};

document.getElementById("htmlBtn").onclick=()=>{
  document.getElementById("htmlOutput").value=generatedHTML();
  document.getElementById("htmlDialog").showModal();
};

document.getElementById("closeHtmlBtn").onclick=()=>{
  document.getElementById("htmlDialog").close();
};

document.getElementById("clearLogBtn").onclick=()=>{
  terminalLog.textContent="Terminal cleared.";
};

document.getElementById("iconInput").addEventListener("change",e=>{
  const file=e.target.files[0];
  if(!file)return;
  if(file.size>2*1024*1024){statusEl.textContent="Icon is too large (max 2 MB).";e.target.value="";return;}
  const reader=new FileReader();
  reader.onload=()=>{
    state.iconData=reader.result;
    const img=document.getElementById("iconPreview");
    img.src=state.iconData;img.style.display="block";
  };
  reader.readAsDataURL(file);
});

document.getElementById("downloadHtmlBtn").onclick=()=>{
  const blob=new Blob([generatedHTML()],{type:"text/html"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);a.download="index.html";a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

document.getElementById("saveBtn").onclick=()=>{
  const project={
    version:1,
    appName:document.getElementById("appName").value,
    packageName:document.getElementById("packageName").value,
    blocks:state.blocks,
    icon:state.iconData
  };
  const blob=new Blob([JSON.stringify(project,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="html-to-apk-project.json";a.click();
};

document.getElementById("buildBtn").onclick=async()=>{
  const appName=document.getElementById("appName").value.trim();
  const packageName=document.getElementById("packageName").value.trim();
  if(!appName){statusEl.textContent="Enter an app name.";return;}
  if(!safePackage(packageName)){statusEl.textContent="Package must look like com.example.myapp.";return;}

  const buildBtn=document.getElementById("buildBtn");
  buildBtn.disabled=true;
  document.getElementById("downloadApkBtn").disabled=true;
  terminalLog.textContent="";
  statusEl.textContent="Building...";
  log("$ ./scripts/build-apk.sh");
  log("[1/5] Validating project...");
  await wait(350);
  log(`[2/5] App: ${appName}`);
  log(`[3/5] Package: ${packageName}`);
  await wait(350);
  log("[4/5] Generating Android WebView project...");
  await wait(350);
  log("[5/5] Running Gradle assembleDebug...");
  log("");
  log("This browser page prepares the project. The real APK is compiled by the terminal build script.");
  statusEl.textContent="Project prepared. Run the terminal script to create the APK.";
  buildBtn.disabled=false;
};

function wait(ms){return new Promise(r=>setTimeout(r,ms));}

renderBlocks();
refreshPreview();
