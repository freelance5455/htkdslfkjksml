#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WEB="$ROOT/web"
ASSETS="$ROOT/android/app/src/main/assets"
ANDROID="$ROOT/android"

command -v java >/dev/null 2>&1 || { echo "ERROR: Java is not installed."; exit 1; }
command -v gradle >/dev/null 2>&1 || { echo "ERROR: Gradle is not installed or not on PATH."; exit 1; }

APP_NAME="${APP_NAME:-My HTML App}"
PACKAGE_NAME="${PACKAGE_NAME:-com.smob.htmlapp}"

if [[ ! "$PACKAGE_NAME" =~ ^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*)+$ ]]; then
  echo "ERROR: Invalid PACKAGE_NAME: $PACKAGE_NAME"
  exit 1
fi

if [[ ! -f "$WEB/index.html" ]]; then
  echo "ERROR: $WEB/index.html not found."
  exit 1
fi

mkdir -p "$ASSETS"
cp "$WEB/index.html" "$ASSETS/index.html"
cp "$WEB/style.css" "$ASSETS/style.css"
cp "$WEB/script.js" "$ASSETS/script.js"

# Generate MainActivity in the selected Java package.
"$ROOT/scripts/set-package.sh" "$PACKAGE_NAME"

echo "[1/5] Project copied into Android assets."
echo "[2/5] App name: $APP_NAME"
echo "[3/5] Package: $PACKAGE_NAME"
echo "[4/5] Generating Android package..."
echo "[5/5] Running Gradle assembleDebug..."

cd "$ANDROID"
gradle assembleDebug \
  -PappName="$APP_NAME" \
  -PappPackage="$PACKAGE_NAME"

APK="$ANDROID/app/build/outputs/apk/debug/app-debug.apk"

if [[ -f "$APK" ]]; then
  echo
  echo "SUCCESS!"
  echo "APK: $APK"
else
  echo "ERROR: Gradle finished but APK was not found."
  exit 1
fi
