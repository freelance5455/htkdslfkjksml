@echo off
setlocal

set ROOT=%~dp0..
set WEB=%ROOT%\web
set ASSETS=%ROOT%\android\app\src\main\assets
set ANDROID=%ROOT%\android

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java is not installed.
  exit /b 1
)

where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle is not installed or not on PATH.
  exit /b 1
)

if "%APP_NAME%"=="" set APP_NAME=My HTML App
if "%PACKAGE_NAME%"=="" set PACKAGE_NAME=com.smob.htmlapp

if not exist "%WEB%\index.html" (
  echo ERROR: web\index.html not found.
  exit /b 1
)

if not exist "%ASSETS%" mkdir "%ASSETS%"

copy /Y "%WEB%\index.html" "%ASSETS%\index.html" >nul
copy /Y "%WEB%\style.css" "%ASSETS%\style.css" >nul
copy /Y "%WEB%\script.js" "%ASSETS%\script.js" >nul

echo [1/5] Project copied into Android assets.
echo [2/5] App name: %APP_NAME%
echo [3/5] Package: %PACKAGE_NAME%
echo [4/5] Generating Android package...
bash "%ROOT%\scripts\set-package.sh" "%PACKAGE_NAME%"
if errorlevel 1 (
  echo ERROR: Could not generate Android package.
  exit /b 1
)
echo [5/5] Running Gradle assembleDebug...

cd /d "%ANDROID%"
gradle assembleDebug -PappName="%APP_NAME%" -PappPackage="%PACKAGE_NAME%"

if exist "%ANDROID%\app\build\outputs\apk\debug\app-debug.apk" (
  echo.
  echo SUCCESS!
  echo APK: %ANDROID%\app\build\outputs\apk\debug\app-debug.apk
) else (
  echo ERROR: APK was not found.
  exit /b 1
)

endlocal
