# HTML → APK Builder

A simple block-based HTML editor plus an Android WebView project.

## What is included

- `web/index.html` — builder interface
- `web/style.css` — UI styling
- `web/script.js` — blocks, preview, HTML generation and project export
- `android/` — Android Studio/Gradle WebView project
- `scripts/build-apk.sh` — Linux/macOS terminal build script
- `scripts/build-apk.bat` — Windows terminal build script

## Important

A web browser cannot compile an Android APK by itself. The included Android project is the build target. The terminal script copies the generated HTML into the Android app and runs Gradle.

You need:

1. Java JDK 17
2. Android SDK
3. Android SDK Platform 35
4. Android Build Tools 35.x
5. Gradle 8.6+ (or use Android Studio to open the `android` folder)

## Build from terminal

Linux/macOS:

```bash
chmod +x scripts/build-apk.sh
./scripts/build-apk.sh
```

Windows (PowerShell/cmd with Gradle on PATH):

```bat
scripts\build-apk.bat
```

The Windows script calls `bash` for package generation. If Git Bash is not installed, run the Android project from Android Studio or run the equivalent commands manually.

The debug APK will be placed in:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Use your generated HTML

The web builder can export `index.html`. Copy that file into:

`android/app/src/main/assets/index.html`

Then run the build script.

## Android security

The Android app loads local HTML only. JavaScript is enabled for the HTML application, but the WebView does not grant file/content access and does not enable cleartext traffic. For a production app, add your own HTTPS-only networking rules and carefully review any external URLs used by the HTML.

## Release APK

The included build creates a debug APK. A distributable release APK should be signed with your own private Android keystore. Do not put a private keystore or passwords into this project or GitHub.
