/* Bật cross-origin isolation (đa luồng) bằng Service Worker. Đặt cùng thư mục với index.html */
if (typeof window === 'undefined') {
  const cred = /Chrome|Firefox/.test(self.navigator.userAgent);
  self.addEventListener('install', () => self.skipWaiting());
  self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
  self.addEventListener('fetch', e => {
    const r = e.request;
    if (r.cache === 'only-if-cached' && r.mode !== 'same-origin') return;
    const cross = new URL(r.url).origin !== self.location.origin;
    if (cred && cross) return; // Chrome/Firefox: để trình duyệt tự tải tài nguyên bên ngoài (CDN, HuggingFace)
    e.respondWith(fetch(r).then(res => {
      if (res.status === 0) return res;
      const h = new Headers(res.headers);
      h.set('Cross-Origin-Embedder-Policy', cred ? 'credentialless' : 'require-corp');
      h.set('Cross-Origin-Opener-Policy', 'same-origin');
      if (cross) h.set('Cross-Origin-Resource-Policy', 'cross-origin');
      return new Response(res.body, { status: res.status, statusText: res.statusText, headers: h });
    }).catch(err => { console.error(err); return Response.error(); }));
  });
} else if (!window.crossOriginIsolated && window.isSecureContext && 'serviceWorker' in navigator) {
  navigator.serviceWorker.register('coi-serviceworker.js').then(reg => {
    if (!sessionStorage.getItem('coiReload')) {
      sessionStorage.setItem('coiReload', '1');
      if (reg.active && !navigator.serviceWorker.controller) location.reload();
      else reg.addEventListener('updatefound', () => reg.installing.addEventListener('statechange', function () { if (this.state === 'activated') location.reload(); }));
    }
  }).catch(e => console.warn('COI SW lỗi:', e));
}
