# CPLS V2 — Stage 1127

## Mobile chart hardening
- Fixed the Stage 1126 chart redraw ReferenceError caused by the selection marker using an out-of-scope variable.
- Candle selection is now stored on the chart window state and safely rendered during every redraw.
- Added touch-action:none to the futures canvas so pinch zoom/pan does not fight page scrolling.
- Preserved the responsive mobile sizing and OHLC tooltip from Stage 1126.
- No undocumented Futures WebSocket subscription message was introduced.
