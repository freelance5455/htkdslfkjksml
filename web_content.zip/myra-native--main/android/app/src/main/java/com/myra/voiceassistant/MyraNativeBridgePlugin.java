package com.myra.voiceassistant;

import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "MyraNativeBridge")
public class MyraNativeBridgePlugin extends Plugin {

    private boolean isTorchOn = false;

    @PluginMethod
    public void openIntent(PluginCall call) {
        String target = call.getString("target", "").toLowerCase();
        JSObject data = call.getObject("data", new JSObject());
        Context context = getContext();

        try {
            Intent intent = null;

            switch (target) {
                case "camera":
                    intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                    if (intent.resolveActivity(context.getPackageManager()) == null) {
                        intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    }
                    break;

                case "whatsapp":
                    String message = data.optString("message", "Hello from Myra Voice Assistant!");
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("whatsapp://send?text=" + Uri.encode(message)));
                    intent.setPackage("com.whatsapp");
                    if (intent.resolveActivity(context.getPackageManager()) == null) {
                        // Fallback without package lock
                        intent.setPackage(null);
                        intent.setData(Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(message)));
                    }
                    break;

                case "youtube":
                    String query = data.optString("query", "");
                    if (!query.isEmpty()) {
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
                    } else {
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"));
                    }
                    intent.setPackage("com.google.android.youtube");
                    if (intent.resolveActivity(context.getPackageManager()) == null) {
                        intent.setPackage(null);
                    }
                    break;

                case "settings":
                    intent = new Intent(Settings.ACTION_SETTINGS);
                    break;

                case "phone":
                    String number = data.optString("number", "");
                    if (!number.isEmpty()) {
                        intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                    } else {
                        intent = new Intent(Intent.ACTION_DIAL);
                    }
                    break;

                case "wifi":
                    intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                    break;

                case "bluetooth":
                    intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                    break;

                case "torch":
                    boolean enableTorch = data.optBoolean("state", !isTorchOn);
                    setDeviceTorch(enableTorch);
                    JSObject torchRes = new JSObject();
                    torchRes.put("success", true);
                    torchRes.put("torchActive", isTorchOn);
                    torchRes.put("message", "Torch toggled " + (isTorchOn ? "ON" : "OFF"));
                    call.resolve(torchRes);
                    return;

                default:
                    call.reject("Unsupported intent target: " + target);
                    return;
            }

            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

                JSObject ret = new JSObject();
                ret.put("success", true);
                ret.put("target", target);
                ret.put("message", "Launched native intent for " + target);
                call.resolve(ret);
            } else {
                call.reject("Could not create Intent for target: " + target);
            }
        } catch (Exception e) {
            call.reject("Error launching intent " + target + ": " + e.getMessage());
        }
    }

    private void setDeviceTorch(boolean enable) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                CameraManager cameraManager = (CameraManager) getContext().getSystemService(Context.CAMERA_SERVICE);
                if (cameraManager != null) {
                    String[] cameraIdList = cameraManager.getCameraIdList();
                    for (String id : cameraIdList) {
                        CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
                        Boolean hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        Integer lensFacing = characteristics.get(CameraCharacteristics.LENS_FACING);
                        if (hasFlash != null && hasFlash && lensFacing != null && lensFacing == CameraCharacteristics.LENS_FACING_BACK) {
                            cameraManager.setTorchMode(id, enable);
                            isTorchOn = enable;
                            break;
                        }
                    }
                }
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }
    }

    @PluginMethod
    public void startForegroundService(PluginCall call) {
        Context context = getContext();
        Intent serviceIntent = new Intent(context, VoiceAssistantForegroundService.class);
        serviceIntent.setAction(VoiceAssistantForegroundService.ACTION_START);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }

        JSObject ret = new JSObject();
        ret.put("success", true);
        ret.put("running", true);
        ret.put("message", "VoiceAssistantForegroundService started");
        call.resolve(ret);
    }

    @PluginMethod
    public void stopForegroundService(PluginCall call) {
        Context context = getContext();
        Intent serviceIntent = new Intent(context, VoiceAssistantForegroundService.class);
        serviceIntent.setAction(VoiceAssistantForegroundService.ACTION_STOP);
        context.startService(serviceIntent);

        JSObject ret = new JSObject();
        ret.put("success", true);
        ret.put("running", false);
        ret.put("message", "VoiceAssistantForegroundService stopped");
        call.resolve(ret);
    }
}
