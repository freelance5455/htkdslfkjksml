import express from 'express';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy initialization for Gemini client
let genAI: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!genAI) {
    genAI = new GoogleGenAI({ apiKey });
  }
  return genAI;
}

// System prompt for Myra Voice Assistant
const MYRA_SYSTEM_PROMPT = `
You are Myra, an ultra-intelligent, friendly, and snappy AI companion and voice assistant.
You possess a warm, playful, anime-inspired personality with deep technical capabilities.
You can execute hardware device controls, mobile intents, and assist with real-time tasks.
Keep your spoken responses concise (1 to 2 sentences), natural, and direct for voice synthesis.

When the user asks you to control hardware or launch an app, you should also include structured action commands in JSON wrapped in <ACTION>...</ACTION> tags, e.g.:
<ACTION>
{
  "type": "OPEN_APP" | "TOGGLE_HARDWARE" | "SYSTEM_SETTING" | "MAKE_CALL",
  "target": "camera" | "whatsapp" | "youtube" | "settings" | "phone" | "torch" | "wifi" | "bluetooth" | "hotspot" | "dnd",
  "value": "on" | "off" | "toggle" | string
}
</ACTION>
Always provide a friendly conversational confirmation along with the action tag.
`;

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    assistant: 'Myra Voice Assistant',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString()
  });
});

// Chat endpoint with Gemini model
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history = [], personality = 'anime-companion' } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const ai = getGeminiClient();

    // If API key is not configured, provide an intelligent local fallback
    if (!ai) {
      const lower = message.toLowerCase();
      let reply = "I'm listening! Please configure GEMINI_API_KEY for deep neural reasoning.";
      let action: any = null;

      if (lower.includes('torch') || lower.includes('flashlight')) {
        const turnOn = !lower.includes('off');
        action = { type: 'TOGGLE_HARDWARE', target: 'torch', value: turnOn ? 'on' : 'off' };
        reply = turnOn ? "Turning on the flashlight right away!" : "Flashlight turned off.";
      } else if (lower.includes('camera')) {
        action = { type: 'OPEN_APP', target: 'camera' };
        reply = "Opening camera viewfinder for you!";
      } else if (lower.includes('whatsapp')) {
        action = { type: 'OPEN_APP', target: 'whatsapp' };
        reply = "Launching WhatsApp.";
      } else if (lower.includes('youtube')) {
        action = { type: 'OPEN_APP', target: 'youtube' };
        reply = "Opening YouTube for you.";
      } else if (lower.includes('setting')) {
        action = { type: 'OPEN_APP', target: 'settings' };
        reply = "Opening device system settings.";
      } else if (lower.includes('call') || lower.includes('phone') || lower.includes('dial')) {
        action = { type: 'OPEN_APP', target: 'phone' };
        reply = "Launching phone dialer.";
      } else if (lower.includes('wifi') || lower.includes('wi-fi')) {
        action = { type: 'TOGGLE_HARDWARE', target: 'wifi', value: lower.includes('off') ? 'off' : 'on' };
        reply = "Wi-Fi state updated.";
      } else if (lower.includes('bluetooth')) {
        action = { type: 'TOGGLE_HARDWARE', target: 'bluetooth', value: lower.includes('off') ? 'off' : 'on' };
        reply = "Bluetooth toggle engaged.";
      } else if (lower.includes('hello') || lower.includes('hey myra') || lower.includes('hi')) {
        reply = "Konnichiwa! I'm Myra, your voice assistant. Ready whenever you are!";
      }

      return res.json({
        reply,
        action,
        mood: 'happy',
        source: 'local_rule_engine'
      });
    }

    // Call official Gemini model: gemini-3.8-flash
    const prompt = `${MYRA_SYSTEM_PROMPT}\nPersonality mode: ${personality}\nUser query: ${message}`;
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    const text = response.text || "I'm here to help!";
    
    // Parse possible <ACTION> tag
    let action = null;
    let cleanReply = text;
    const actionMatch = text.match(/<ACTION>([\s\S]*?)<\/ACTION>/);
    if (actionMatch) {
      try {
        action = JSON.parse(actionMatch[1].trim());
        cleanReply = text.replace(/<ACTION>[\s\S]*?<\/ACTION>/, '').trim();
      } catch {
        // Ignore parse error
      }
    }

    return res.json({
      reply: cleanReply,
      action,
      mood: 'speaking',
      source: 'gemini-3.8-flash'
    });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return res.status(500).json({
      error: 'Failed to process voice command',
      details: error?.message || String(error)
    });
  }
});

// Serve static assets in production or development build
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

app.get('*', (_req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[Myra Server] Running on http://0.0.0.0:${PORT}`);
});
