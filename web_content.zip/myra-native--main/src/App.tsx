import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Cpu, 
  Trash2, 
  Bot, 
  User, 
  CheckCircle2, 
  Wifi
} from 'lucide-react';
import type { 
  AssistantMood, 
  ChatMessage, 
  ConnectedDevice, 
  DeviceHardwareState, 
  AndroidIntentType 
} from './types';
import { MyraCharacter } from './components/MyraCharacter';
import { MobileControlCenter } from './components/MobileControlCenter';
import { ContinuousVoiceBar } from './components/ContinuousVoiceBar';
import { AndroidNativeModal } from './components/AndroidNativeModal';
import { voiceSynthesis } from './services/voiceSynthesis';
import { soundEffects } from './services/soundEffects';
import { androidBridge } from './services/androidNativeBridge';

export const App: React.FC = () => {
  const [mood, setMood] = useState<AssistantMood>('idle');
  const [lipSyncRatio, setLipSyncRatio] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [showNativeModal, setShowNativeModal] = useState(false);

  // Connected fleet devices
  const [devices, setDevices] = useState<ConnectedDevice[]>([
    {
      id: 'pixel-9',
      name: 'Pixel 9 Pro (Primary)',
      model: 'Google Pixel 9 Pro',
      isCurrentDevice: true,
      online: true,
      state: {
        torch: false,
        wifi: true,
        bluetooth: true,
        hotspot: false,
        dnd: false,
        volume: 75,
        screenTimeout: 30,
        batteryLevel: 88
      }
    },
    {
      id: 'galaxy-s25',
      name: 'Galaxy S25 Ultra',
      model: 'Samsung Galaxy S25',
      isCurrentDevice: false,
      online: true,
      state: {
        torch: false,
        wifi: true,
        bluetooth: false,
        hotspot: false,
        dnd: false,
        volume: 60,
        screenTimeout: 60,
        batteryLevel: 94
      }
    },
    {
      id: 'oneplus-12',
      name: 'OnePlus 12',
      model: 'OnePlus 12 5G',
      isCurrentDevice: false,
      online: false,
      state: {
        torch: false,
        wifi: false,
        bluetooth: false,
        hotspot: false,
        dnd: true,
        volume: 40,
        screenTimeout: 15,
        batteryLevel: 42
      }
    }
  ]);
  const [activeDeviceId, setActiveDeviceId] = useState<string>('pixel-9');

  // Conversational message feed
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      role: 'assistant',
      content: "Hello! I am Myra, your AI voice assistant. Speak to me or tap any control to manage hardware, launch camera, WhatsApp, YouTube, and more!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Setup Web Speech Recognition
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
          setIsListening(true);
          setMood('listening');
          soundEffects.playListeningChime();
        };

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            handleUserCommand(transcript);
          }
        };

        recognition.onerror = () => {
          setIsListening(false);
          setMood('idle');
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, [activeDeviceId]);

  // Toggle voice recognition
  const handleToggleListening = () => {
    soundEffects.playClick();
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      setMood('idle');
    } else {
      try {
        recognitionRef.current?.start();
      } catch {
        // Recognition might already be running
        setIsListening(true);
        setMood('listening');
      }
    }
  };

  // Hardware update handler
  const handleUpdateHardware = (deviceId: string, updates: Partial<DeviceHardwareState>) => {
    setDevices(prev => prev.map(d => {
      if (d.id === deviceId) {
        return {
          ...d,
          state: { ...d.state, ...updates }
        };
      }
      return d;
    }));
  };

  // Process user command through server-side /api/chat with Gemini API
  const handleUserCommand = async (text: string) => {
    setIsListening(false);
    setMood('thinking');

    // Add user message
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, userMsg]);

    try {
      // Send command to server-side Gemini route
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          deviceId: activeDeviceId
        })
      });

      const data = await response.json();
      const reply = data.reply || "Command received!";
      const action = data.action;

      // Execute intent or hardware toggle if detected
      if (action) {
        if (action.type === 'OPEN_APP' && action.target) {
          await androidBridge.launchIntent(action.target as AndroidIntentType);
        } else if (action.type === 'TOGGLE_HARDWARE' && action.target) {
          const targetKey = action.target as keyof DeviceHardwareState;
          const turnOn = action.value === 'on' || action.value === true;
          handleUpdateHardware(activeDeviceId, { [targetKey]: turnOn });
          await androidBridge.launchIntent(action.target as AndroidIntentType, { state: turnOn });
        }
        soundEffects.playActionSuccess();
      }

      // Add assistant response to chat
      const assistantMsg: ChatMessage = {
        id: `myra-${Date.now()}`,
        role: 'assistant',
        content: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actionExecuted: action ? { ...action, success: true } : undefined
      };
      setMessages(prev => [...prev, assistantMsg]);

      // Speak response using voice synthesis with real-time lip sync
      voiceSynthesis.speak(reply, {
        onStart: () => setMood('speaking'),
        onLipMovement: (ratio) => setLipSyncRatio(ratio),
        onEnd: () => {
          setLipSyncRatio(0);
          setMood('happy');
          setTimeout(() => setMood('idle'), 2000);
        }
      });
    } catch (err: any) {
      console.error('Command processing error:', err);
      const fallbackReply = "I received your command, but encountered a connection issue.";
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: fallbackReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setMood('idle');
      voiceSynthesis.speak(fallbackReply);
    }
  };

  // Quick intent direct launcher
  const handleQuickIntent = async (intent: AndroidIntentType) => {
    soundEffects.playClick();
    const res = await androidBridge.launchIntent(intent);
    soundEffects.playActionSuccess();

    setMessages(prev => [
      ...prev,
      {
        id: `intent-${Date.now()}`,
        role: 'system',
        content: `Dispatched Android Intent: ${intent.toUpperCase()} (${res.message})`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actionExecuted: { type: 'OPEN_APP', target: intent, success: true }
      }
    ]);
  };

  // Clear chat history
  const handleClearChat = () => {
    soundEffects.playClick();
    setMessages([
      {
        id: 'msg-cleared',
        role: 'assistant',
        content: "Chat history cleared. What can I do for you next?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  return (
    <div id="myra-app-root" className="min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-gray-950 text-gray-100 flex flex-col items-center justify-between p-3 sm:p-5">
      {/* Top Application Bar */}
      <header className="w-full max-w-4xl flex items-center justify-between py-2 px-3 bg-gray-900/70 border border-gray-800/80 rounded-2xl backdrop-blur-lg shadow-xl mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 via-purple-500 to-cyan-400 p-[1.5px] flex items-center justify-center">
            <div className="w-full h-full bg-gray-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-pink-400" />
            </div>
          </div>
          <div>
            <h1 className="text-base font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-300 to-cyan-400">
              MYRA
            </h1>
            <div className="flex items-center gap-1.5 text-[10px] text-gray-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Voice AI & Device Fleet Core</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Android Native Bridge Inspector Button */}
          <button
            id="btn-open-native-bridge"
            onClick={() => {
              soundEffects.playClick();
              setShowNativeModal(true);
            }}
            className="px-3 py-1.5 rounded-xl bg-gray-800/80 hover:bg-gray-700/80 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 shadow-sm"
          >
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Native Bridge</span>
            <span className="sm:hidden">Android</span>
          </button>
        </div>
      </header>

      {/* Main Interactive Stage Grid */}
      <main className="w-full max-w-4xl flex-1 flex flex-col lg:flex-row gap-4 mb-3">
        {/* Left Column: Live Anime Character Avatar & Quick Mood */}
        <section className="flex-1 flex flex-col items-center justify-center bg-gray-900/40 border border-gray-800/60 rounded-3xl p-4 backdrop-blur-md relative overflow-hidden">
          <MyraCharacter
            mood={mood}
            lipSyncRatio={lipSyncRatio}
            onClick={() => {
              soundEffects.playClick();
              voiceSynthesis.speak("I am right here! How may I assist you?");
            }}
          />

          <div className="mt-4 text-center">
            <h2 className="text-xs uppercase tracking-widest text-cyan-400 font-bold">Interactive Live Anime AI</h2>
            <p className="text-xs text-gray-400 mt-0.5">Real-time lip sync • 100 customizable voices • Neural Android intents</p>
          </div>
        </section>

        {/* Right Column: Conversational Activity Feed */}
        <section className="flex-1 flex flex-col bg-gray-900/60 border border-gray-800/70 rounded-3xl p-4 backdrop-blur-xl overflow-hidden h-[340px] sm:h-[400px]">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-gray-800">
            <div className="flex items-center gap-2 text-xs font-bold text-gray-300 uppercase tracking-wider">
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>Voice Session Stream</span>
            </div>
            <button
              id="btn-clear-chat"
              onClick={handleClearChat}
              className="p-1 rounded-lg hover:bg-gray-800 text-gray-500 hover:text-rose-400 transition-colors"
              title="Clear session stream"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-[10px] text-gray-500">
                  {msg.role === 'user' ? <User className="w-3 h-3 text-pink-400" /> : <Bot className="w-3 h-3 text-cyan-400" />}
                  <span>{msg.role === 'user' ? 'You' : msg.role === 'system' ? 'System' : 'Myra'}</span>
                  <span>•</span>
                  <span>{msg.timestamp}</span>
                </div>

                <div
                  className={`p-3 rounded-2xl max-w-[90%] leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-pink-600/20 border border-pink-500/40 text-pink-100 rounded-tr-none'
                      : msg.role === 'system'
                      ? 'bg-cyan-950/40 border border-cyan-500/30 text-cyan-200 font-mono text-[11px]'
                      : 'bg-gray-850/90 border border-gray-800 text-gray-100 rounded-tl-none shadow-md'
                  }`}
                >
                  <p>{msg.content}</p>

                  {/* Intent Action Pill */}
                  {msg.actionExecuted && (
                    <div className="mt-2 pt-1.5 border-t border-gray-800/80 flex items-center gap-1.5 text-[10px] text-cyan-300 font-mono">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                      <span>Executed: {msg.actionExecuted.target?.toUpperCase()}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </section>
      </main>

      {/* Hardware Control Dock */}
      <section className="w-full max-w-4xl mb-3">
        <MobileControlCenter
          devices={devices}
          activeDeviceId={activeDeviceId}
          onSelectDevice={(id) => setActiveDeviceId(id)}
          onUpdateHardware={handleUpdateHardware}
        />
      </section>

      {/* Voice Bar & Quick Intent Launcher */}
      <footer className="w-full max-w-4xl">
        <ContinuousVoiceBar
          isListening={isListening}
          onToggleListening={handleToggleListening}
          onSubmitText={handleUserCommand}
          onQuickIntent={handleQuickIntent}
        />
      </footer>

      {/* Native Bridge & Android Permissions Inspector Modal */}
      <AndroidNativeModal
        isOpen={showNativeModal}
        onClose={() => setShowNativeModal(false)}
      />
    </div>
  );
};
