export type AssistantMood = 'idle' | 'listening' | 'thinking' | 'speaking' | 'happy' | 'alert';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  actionExecuted?: {
    type: string;
    target: string;
    value?: any;
    success?: boolean;
  };
}

export interface DeviceHardwareState {
  torch: boolean;
  wifi: boolean;
  bluetooth: boolean;
  hotspot: boolean;
  dnd: boolean;
  volume: number; // 0-100
  screenTimeout: number; // in seconds
  batteryLevel: number;
}

export interface ConnectedDevice {
  id: string;
  name: string;
  model: string;
  isCurrentDevice: boolean;
  online: boolean;
  state: DeviceHardwareState;
}

export interface VoiceProfile {
  id: string;
  name: string;
  lang: string;
  pitch: number;
  rate: number;
  tags: string[];
}

export type AndroidIntentType = 
  | 'camera' 
  | 'whatsapp' 
  | 'youtube' 
  | 'settings' 
  | 'phone' 
  | 'torch' 
  | 'wifi' 
  | 'bluetooth';
