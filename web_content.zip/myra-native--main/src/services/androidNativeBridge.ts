import { Capacitor } from '@capacitor/core';
import type { AndroidIntentType } from '../types';

export interface NativeBridgeStatus {
  isNative: boolean;
  platform: string;
  foregroundServiceRunning: boolean;
  permissions: {
    microphone: boolean;
    camera: boolean;
    location: boolean;
    notifications: boolean;
  };
}

class AndroidNativeBridgeService {
  private isNative: boolean = false;
  private isServiceRunning: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.isNative = Capacitor.isNativePlatform();
    }
  }

  isNativeAndroid(): boolean {
    return this.isNative || (typeof window !== 'undefined' && Capacitor.getPlatform() === 'android');
  }

  // Launch native Android Intent
  async launchIntent(target: AndroidIntentType, extraData?: Record<string, any>): Promise<{ success: boolean; message: string }> {
    console.log(`[NativeBridge] Launching intent: ${target}`, extraData);

    if (this.isNativeAndroid() && (window as any).Capacitor?.Plugins?.MyraNativeBridge) {
      try {
        const res = await (window as any).Capacitor.Plugins.MyraNativeBridge.openIntent({
          target,
          data: extraData || {}
        });
        return { success: true, message: res?.message || `Launched native ${target}` };
      } catch (err: any) {
        console.warn(`[NativeBridge] Native intent call failed, trying web fallback:`, err);
      }
    }

    // Web Fallbacks for browser testing
    switch (target) {
      case 'phone': {
        const phoneUrl = `tel:${extraData?.number || ''}`;
        window.location.href = phoneUrl;
        return { success: true, message: `Opened dialer with ${extraData?.number || 'keypad'}` };
      }
      case 'whatsapp': {
        const text = encodeURIComponent(extraData?.message || 'Hello from Myra Voice Assistant!');
        window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
        return { success: true, message: 'Opened WhatsApp dispatch link' };
      }
      case 'youtube': {
        const query = encodeURIComponent(extraData?.query || '');
        const url = query ? `https://www.youtube.com/results?search_query=${query}` : `https://www.youtube.com`;
        window.open(url, '_blank');
        return { success: true, message: 'Opened YouTube' };
      }
      case 'camera': {
        try {
          // Trigger browser camera feed check
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          // Stop immediately as verification
          stream.getTracks().forEach(track => track.stop());
          return { success: true, message: 'Camera permission active & viewfinder initialized' };
        } catch (err: any) {
          return { success: false, message: `Camera error: ${err?.message || 'Permission denied'}` };
        }
      }
      case 'settings': {
        return { success: true, message: 'System Settings requested (simulated in Web mode, triggers android.settings.SETTINGS on Android)' };
      }
      case 'torch': {
        return { success: true, message: 'Flashlight state toggled' };
      }
      case 'wifi': {
        return { success: true, message: 'Wi-Fi intent triggered' };
      }
      case 'bluetooth': {
        return { success: true, message: 'Bluetooth intent triggered' };
      }
      default:
        return { success: true, message: `Dispatched ${target}` };
    }
  }

  // Toggle foreground voice listening service
  async toggleForegroundService(enable: boolean): Promise<{ success: boolean; running: boolean }> {
    if (this.isNativeAndroid() && (window as any).Capacitor?.Plugins?.MyraNativeBridge) {
      try {
        if (enable) {
          await (window as any).Capacitor.Plugins.MyraNativeBridge.startForegroundService();
          this.isServiceRunning = true;
        } else {
          await (window as any).Capacitor.Plugins.MyraNativeBridge.stopForegroundService();
          this.isServiceRunning = false;
        }
        return { success: true, running: this.isServiceRunning };
      } catch (err) {
        console.error('[NativeBridge] Foreground service call failed:', err);
      }
    }

    // Web simulation
    this.isServiceRunning = enable;
    return { success: true, running: this.isServiceRunning };
  }

  // Request all permissions
  async requestAndroidPermissions(): Promise<{
    microphone: boolean;
    camera: boolean;
    location: boolean;
    notifications: boolean;
  }> {
    const results = {
      microphone: false,
      camera: false,
      location: false,
      notifications: false
    };

    // Microphone
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(t => t.stop());
      results.microphone = true;
    } catch {
      results.microphone = false;
    }

    // Camera
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach(t => t.stop());
      results.camera = true;
    } catch {
      results.camera = false;
    }

    // Location
    if ('geolocation' in navigator) {
      results.location = true;
    }

    // Notifications
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      results.notifications = perm === 'granted';
    }

    return results;
  }
}

export const androidBridge = new AndroidNativeBridgeService();
