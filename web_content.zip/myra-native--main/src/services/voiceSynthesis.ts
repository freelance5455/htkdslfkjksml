// Text-to-Speech synthesis with real-time lip-sync phoneme tracking

export interface VoiceSynthesisCallbacks {
  onStart?: () => void;
  onEnd?: () => void;
  onLipMovement?: (openRatio: number) => void;
}

class VoiceSynthesisService {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private animFrameId: number | null = null;
  private selectedVoice: SpeechSynthesisVoice | null = null;
  private pitch: number = 1.15; // Slightly high for youthful anime timbre
  private rate: number = 1.05; // Quick and snappy

  speak(text: string, callbacks?: VoiceSynthesisCallbacks) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      callbacks?.onStart?.();
      setTimeout(() => callbacks?.onEnd?.(), 1000);
      return;
    }

    // Cancel any previous utterance
    window.speechSynthesis.cancel();
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.pitch = this.pitch;
    utterance.rate = this.rate;

    const voices = window.speechSynthesis.getVoices();
    if (this.selectedVoice) {
      utterance.voice = this.selectedVoice;
    } else {
      // Find suitable female/natural voice
      const preferred = voices.find(v => 
        (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Samantha') || v.name.includes('Victoria') || v.name.includes('Karen') || v.name.includes('Female')) &&
        v.lang.startsWith('en')
      );
      if (preferred) {
        utterance.voice = preferred;
      }
    }

    let speakingActive = false;

    // Simulate viseme mouth movement loop
    const simulateMouth = () => {
      if (!speakingActive) {
        callbacks?.onLipMovement?.(0);
        return;
      }
      // Pulsing lip-sync frequency
      const time = performance.now() * 0.015;
      const mouthOpen = Math.max(0, Math.sin(time) * 0.6 + Math.sin(time * 2.3) * 0.4);
      callbacks?.onLipMovement?.(mouthOpen);
      this.animFrameId = requestAnimationFrame(simulateMouth);
    };

    utterance.onstart = () => {
      speakingActive = true;
      callbacks?.onStart?.();
      simulateMouth();
    };

    utterance.onend = () => {
      speakingActive = false;
      if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
      callbacks?.onLipMovement?.(0);
      callbacks?.onEnd?.();
    };

    utterance.onerror = () => {
      speakingActive = false;
      if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
      callbacks?.onLipMovement?.(0);
      callbacks?.onEnd?.();
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  stop() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  setPitch(p: number) {
    this.pitch = p;
  }

  setRate(r: number) {
    this.rate = r;
  }
}

export const voiceSynthesis = new VoiceSynthesisService();
