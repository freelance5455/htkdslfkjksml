import React, { useState } from 'react';
import { 
  X, 
  Cpu, 
  Radio, 
  Shield, 
  ExternalLink, 
  Camera, 
  MessageSquare, 
  Video, 
  Settings, 
  PhoneCall,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { androidBridge } from '../services/androidNativeBridge';
import type { AndroidIntentType } from '../types';

interface AndroidNativeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidNativeModal: React.FC<AndroidNativeModalProps> = ({ isOpen, onClose }) => {
  const [foregroundServiceActive, setForegroundServiceActive] = useState(true);
  const [lastActionStatus, setLastActionStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleToggleService = async () => {
    const nextState = !foregroundServiceActive;
    const res = await androidBridge.toggleForegroundService(nextState);
    setForegroundServiceActive(res.running);
    setLastActionStatus(`Foreground service ${res.running ? 'started' : 'stopped'}`);
  };

  const handleTestIntent = async (target: AndroidIntentType) => {
    const res = await androidBridge.launchIntent(target);
    setLastActionStatus(res.message);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        id="android-native-modal-container"
        className="w-full max-w-lg bg-gray-900 border border-cyan-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-gray-950/60">
          <div className="flex items-center gap-2.5">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-base font-bold text-gray-100">Native Android Bridge</h3>
              <p className="text-xs text-gray-400 font-mono">com.myra.voiceassistant</p>
            </div>
          </div>
          <button
            id="btn-close-native-modal"
            onClick={onClose}
            className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-gray-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 text-sm">
          {/* Foreground Service Status Card */}
          <div className="bg-gray-950/70 border border-gray-800 rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${foregroundServiceActive ? 'bg-cyan-500/20 text-cyan-400' : 'bg-gray-800 text-gray-500'}`}>
                <Radio className={`w-5 h-5 ${foregroundServiceActive ? 'animate-pulse' : ''}`} />
              </div>
              <div>
                <div className="font-semibold text-gray-200 flex items-center gap-2">
                  <span>Foreground Voice Service</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                    foregroundServiceActive ? 'bg-emerald-500/20 text-emerald-300' : 'bg-gray-800 text-gray-400'
                  }`}>
                    {foregroundServiceActive ? 'ACTIVE' : 'IDLE'}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mt-0.5">
                  Persistent background hotword detection & native notification
                </p>
              </div>
            </div>
            <button
              id="btn-toggle-foreground-service"
              onClick={handleToggleService}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                foregroundServiceActive
                  ? 'bg-rose-500/20 border border-rose-500/40 text-rose-300 hover:bg-rose-500/30'
                  : 'bg-cyan-500 text-gray-950 font-bold hover:bg-cyan-400'
              }`}
            >
              {foregroundServiceActive ? 'Stop' : 'Start'}
            </button>
          </div>

          {/* AndroidManifest Permissions Matrix */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-cyan-400" /> Declared Native Permissions
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-gray-950/50 p-2 rounded-lg border border-gray-800 flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-mono text-gray-300 truncate">RECORD_AUDIO</span>
              </div>
              <div className="bg-gray-950/50 p-2 rounded-lg border border-gray-800 flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-mono text-gray-300 truncate">CAMERA</span>
              </div>
              <div className="bg-gray-950/50 p-2 rounded-lg border border-gray-800 flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-mono text-gray-300 truncate">ACCESS_FINE_LOCATION</span>
              </div>
              <div className="bg-gray-950/50 p-2 rounded-lg border border-gray-800 flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-mono text-gray-300 truncate">POST_NOTIFICATIONS</span>
              </div>
              <div className="bg-gray-950/50 p-2 rounded-lg border border-gray-800 flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-mono text-gray-300 truncate">FOREGROUND_SERVICE</span>
              </div>
              <div className="bg-gray-950/50 p-2 rounded-lg border border-gray-800 flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-mono text-gray-300 truncate">CALL_PHONE / DIAL</span>
              </div>
            </div>
          </div>

          {/* Android Intents Test Grid */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <ExternalLink className="w-3.5 h-3.5 text-pink-400" /> Supported Native Intents
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <button
                id="intent-test-camera"
                onClick={() => handleTestIntent('camera')}
                className="p-2.5 rounded-xl bg-gray-950 border border-gray-800 hover:border-cyan-500/60 text-gray-300 flex flex-col items-center gap-1 transition-all"
              >
                <Camera className="w-4 h-4 text-cyan-400" />
                <span className="text-[11px] font-medium">Camera</span>
              </button>
              <button
                id="intent-test-whatsapp"
                onClick={() => handleTestIntent('whatsapp')}
                className="p-2.5 rounded-xl bg-gray-950 border border-gray-800 hover:border-emerald-500/60 text-gray-300 flex flex-col items-center gap-1 transition-all"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span className="text-[11px] font-medium">WhatsApp</span>
              </button>
              <button
                id="intent-test-youtube"
                onClick={() => handleTestIntent('youtube')}
                className="p-2.5 rounded-xl bg-gray-950 border border-gray-800 hover:border-red-500/60 text-gray-300 flex flex-col items-center gap-1 transition-all"
              >
                <Video className="w-4 h-4 text-rose-400" />
                <span className="text-[11px] font-medium">YouTube</span>
              </button>
              <button
                id="intent-test-settings"
                onClick={() => handleTestIntent('settings')}
                className="p-2.5 rounded-xl bg-gray-950 border border-gray-800 hover:border-amber-500/60 text-gray-300 flex flex-col items-center gap-1 transition-all"
              >
                <Settings className="w-4 h-4 text-amber-400" />
                <span className="text-[11px] font-medium">Settings</span>
              </button>
              <button
                id="intent-test-phone"
                onClick={() => handleTestIntent('phone')}
                className="p-2.5 rounded-xl bg-gray-950 border border-gray-800 hover:border-blue-500/60 text-gray-300 flex flex-col items-center gap-1 transition-all"
              >
                <PhoneCall className="w-4 h-4 text-blue-400" />
                <span className="text-[11px] font-medium">Phone Dialer</span>
              </button>
              <button
                id="intent-test-torch"
                onClick={() => handleTestIntent('torch')}
                className="p-2.5 rounded-xl bg-gray-950 border border-gray-800 hover:border-yellow-500/60 text-gray-300 flex flex-col items-center gap-1 transition-all"
              >
                <span className="text-yellow-400 font-bold text-xs">🔦</span>
                <span className="text-[11px] font-medium">Flashlight</span>
              </button>
            </div>
          </div>

          {/* Feedback message banner */}
          {lastActionStatus && (
            <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-500/30 text-cyan-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{lastActionStatus}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-950 border-t border-gray-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-200 text-xs font-semibold"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
