import React from 'react';
import { 
  Flashlight, 
  Wifi, 
  Bluetooth, 
  Radio, 
  BellOff, 
  Volume2, 
  Smartphone,
  ShieldCheck,
  Zap
} from 'lucide-react';
import type { ConnectedDevice, DeviceHardwareState } from '../types';
import { soundEffects } from '../services/soundEffects';
import { androidBridge } from '../services/androidNativeBridge';

interface MobileControlCenterProps {
  devices: ConnectedDevice[];
  activeDeviceId: string;
  onSelectDevice: (id: string) => void;
  onUpdateHardware: (deviceId: string, updates: Partial<DeviceHardwareState>) => void;
}

export const MobileControlCenter: React.FC<MobileControlCenterProps> = ({
  devices,
  activeDeviceId,
  onSelectDevice,
  onUpdateHardware,
}) => {
  const currentDevice = devices.find(d => d.id === activeDeviceId) || devices[0];

  const handleToggle = async (key: keyof DeviceHardwareState) => {
    soundEffects.playClick();
    const newValue = !currentDevice.state[key];
    onUpdateHardware(currentDevice.id, { [key]: newValue });

    // Bridge notification to native device
    if (key === 'torch') {
      await androidBridge.launchIntent('torch', { state: newValue });
    } else if (key === 'wifi') {
      await androidBridge.launchIntent('wifi', { state: newValue });
    } else if (key === 'bluetooth') {
      await androidBridge.launchIntent('bluetooth', { state: newValue });
    }
  };

  const handleVolumeChange = (vol: number) => {
    onUpdateHardware(currentDevice.id, { volume: vol });
  };

  return (
    <div id="mobile-control-center" className="w-full bg-gray-900/80 border border-gray-800/80 rounded-2xl p-4 backdrop-blur-xl shadow-2xl">
      {/* Device Fleet Selector Header */}
      <div className="flex items-center justify-between pb-3 border-b border-gray-800 mb-4">
        <div className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-cyan-400" />
          <h2 className="text-sm font-bold tracking-wider text-gray-200 uppercase">Hardware Control Dock</h2>
        </div>
        <div className="flex items-center gap-1 bg-gray-950 p-1 rounded-lg border border-gray-800 text-xs">
          {devices.map((device) => (
            <button
              key={device.id}
              id={`device-pill-${device.id}`}
              onClick={() => {
                soundEffects.playClick();
                onSelectDevice(device.id);
              }}
              className={`px-2.5 py-1 rounded-md transition-all font-medium flex items-center gap-1.5 ${
                device.id === activeDeviceId
                  ? 'bg-cyan-500 text-gray-950 shadow-sm font-semibold'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${device.online ? 'bg-emerald-400' : 'bg-gray-500'}`} />
              {device.name}
            </button>
          ))}
        </div>
      </div>

      {/* Hardware Toggles Bento Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 mb-4">
        {/* Torch */}
        <button
          id="btn-toggle-torch"
          onClick={() => handleToggle('torch')}
          className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95 ${
            currentDevice.state.torch
              ? 'bg-amber-500/20 border-amber-400/80 text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
              : 'bg-gray-950/60 border-gray-800 text-gray-400 hover:bg-gray-800/50'
          }`}
        >
          <Flashlight className={`w-5 h-5 ${currentDevice.state.torch ? 'animate-bounce' : ''}`} />
          <span className="text-xs font-semibold">Flashlight</span>
          <span className="text-[10px] opacity-75">{currentDevice.state.torch ? 'ACTIVE' : 'OFF'}</span>
        </button>

        {/* Wi-Fi */}
        <button
          id="btn-toggle-wifi"
          onClick={() => handleToggle('wifi')}
          className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95 ${
            currentDevice.state.wifi
              ? 'bg-cyan-500/20 border-cyan-400/80 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
              : 'bg-gray-950/60 border-gray-800 text-gray-400 hover:bg-gray-800/50'
          }`}
        >
          <Wifi className="w-5 h-5" />
          <span className="text-xs font-semibold">Wi-Fi</span>
          <span className="text-[10px] opacity-75">{currentDevice.state.wifi ? 'CONNECTED' : 'OFF'}</span>
        </button>

        {/* Bluetooth */}
        <button
          id="btn-toggle-bluetooth"
          onClick={() => handleToggle('bluetooth')}
          className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95 ${
            currentDevice.state.bluetooth
              ? 'bg-blue-500/20 border-blue-400/80 text-blue-300 shadow-[0_0_15px_rgba(59,130,246,0.3)]'
              : 'bg-gray-950/60 border-gray-800 text-gray-400 hover:bg-gray-800/50'
          }`}
        >
          <Bluetooth className="w-5 h-5" />
          <span className="text-xs font-semibold">Bluetooth</span>
          <span className="text-[10px] opacity-75">{currentDevice.state.bluetooth ? 'PAIRED' : 'OFF'}</span>
        </button>

        {/* Hotspot */}
        <button
          id="btn-toggle-hotspot"
          onClick={() => handleToggle('hotspot')}
          className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95 ${
            currentDevice.state.hotspot
              ? 'bg-pink-500/20 border-pink-400/80 text-pink-300 shadow-[0_0_15px_rgba(236,72,153,0.3)]'
              : 'bg-gray-950/60 border-gray-800 text-gray-400 hover:bg-gray-800/50'
          }`}
        >
          <Radio className="w-5 h-5" />
          <span className="text-xs font-semibold">Hotspot</span>
          <span className="text-[10px] opacity-75">{currentDevice.state.hotspot ? 'BROADCAST' : 'OFF'}</span>
        </button>

        {/* DND */}
        <button
          id="btn-toggle-dnd"
          onClick={() => handleToggle('dnd')}
          className={`col-span-2 sm:col-span-1 p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95 ${
            currentDevice.state.dnd
              ? 'bg-purple-500/20 border-purple-400/80 text-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.3)]'
              : 'bg-gray-950/60 border-gray-800 text-gray-400 hover:bg-gray-800/50'
          }`}
        >
          <BellOff className="w-5 h-5" />
          <span className="text-xs font-semibold">DND Mode</span>
          <span className="text-[10px] opacity-75">{currentDevice.state.dnd ? 'SILENT' : 'OFF'}</span>
        </button>
      </div>

      {/* Volume & Battery Sliders */}
      <div className="bg-gray-950/50 border border-gray-800/60 rounded-xl p-3 flex flex-col sm:flex-row items-center gap-4">
        <div className="flex-1 w-full flex items-center gap-3">
          <Volume2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <div className="flex-1 flex flex-col gap-1">
            <div className="flex justify-between text-xs font-medium text-gray-400">
              <span>Master Volume</span>
              <span className="text-cyan-300 font-mono">{currentDevice.state.volume}%</span>
            </div>
            <input
              id="slider-volume"
              type="range"
              min="0"
              max="100"
              value={currentDevice.state.volume}
              onChange={(e) => handleVolumeChange(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-gray-800 rounded-lg appearance-none"
            />
          </div>
        </div>

        <div className="w-full sm:w-auto flex items-center justify-between sm:justify-end gap-3 text-xs text-gray-400 border-t sm:border-t-0 sm:border-l border-gray-800 pt-2 sm:pt-0 sm:pl-4">
          <div className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            <span>Battery: <span className="text-emerald-300 font-mono font-bold">{currentDevice.state.batteryLevel}%</span></span>
          </div>
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Secured</span>
          </div>
        </div>
      </div>
    </div>
  );
};
