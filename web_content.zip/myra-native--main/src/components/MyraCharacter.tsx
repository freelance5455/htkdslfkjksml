import React, { useEffect, useState } from 'react';
import type { AssistantMood } from '../types';

interface MyraCharacterProps {
  mood: AssistantMood;
  lipSyncRatio: number; // 0 (closed) to 1 (wide open)
  onClick?: () => void;
}

export const MyraCharacter: React.FC<MyraCharacterProps> = ({ mood, lipSyncRatio, onClick }) => {
  const [blink, setBlink] = useState(false);

  // Natural blinking loop
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 150);
    }, 4000 + Math.random() * 2000);

    return () => clearInterval(blinkInterval);
  }, []);

  // Aura colors based on mood
  const getAuraColor = () => {
    switch (mood) {
      case 'listening': return 'rgba(6, 182, 212, 0.4)'; // Cyan
      case 'thinking': return 'rgba(245, 158, 11, 0.4)'; // Amber
      case 'speaking': return 'rgba(236, 72, 153, 0.5)'; // Pink/Magenta
      case 'happy': return 'rgba(16, 185, 129, 0.45)'; // Emerald
      case 'alert': return 'rgba(239, 68, 68, 0.45)'; // Rose
      default: return 'rgba(139, 92, 246, 0.35)'; // Purple
    }
  };

  // Dynamic mouth height based on lip-sync
  const mouthOpenAmount = Math.max(3, lipSyncRatio * 18);

  return (
    <div 
      id="myra-character-stage"
      onClick={onClick}
      className="relative flex flex-col items-center justify-center cursor-pointer select-none transition-transform duration-300 active:scale-95"
    >
      {/* Background Holographic Halo & Glow */}
      <div 
        className="absolute w-72 h-72 sm:w-80 sm:h-80 rounded-full blur-3xl -z-10 transition-colors duration-500"
        style={{ backgroundColor: getAuraColor() }}
      />

      {/* Cybernetic Floating Rings */}
      <div className="absolute w-64 h-64 border border-cyan-500/20 rounded-full animate-spin [animation-duration:20s] pointer-events-none" />
      <div className="absolute w-56 h-56 border border-pink-500/20 rounded-full animate-spin [animation-duration:15s] [animation-direction:reverse] pointer-events-none" />

      {/* Anime Character SVG Vector */}
      <svg
        viewBox="0 0 240 260"
        className="w-56 h-60 sm:w-64 sm:h-68 drop-shadow-[0_10px_25px_rgba(0,0,0,0.8)]"
      >
        <defs>
          {/* Hair Gradient */}
          <linearGradient id="hairGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ec4899" />
            <stop offset="50%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#3b82f6" />
          </linearGradient>

          {/* Skin Gradient */}
          <linearGradient id="skinGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fff1eb" />
            <stop offset="100%" stopColor="#fde0dd" />
          </linearGradient>

          {/* Eye Gradient */}
          <linearGradient id="eyeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor="#3b82f6" />
          </linearGradient>
        </defs>

        {/* Back Hair Strands */}
        <path
          d="M 60 70 Q 30 160 50 240 Q 80 200 85 130 Z"
          fill="url(#hairGrad)"
          opacity="0.9"
        />
        <path
          d="M 180 70 Q 210 160 190 240 Q 160 200 155 130 Z"
          fill="url(#hairGrad)"
          opacity="0.9"
        />

        {/* Neck */}
        <path d="M 108 150 L 108 185 Q 120 190 132 185 L 132 150 Z" fill="#fbd0c8" />

        {/* Cyber Collar / Outfit Accent */}
        <path
          d="M 85 185 Q 120 205 155 185 L 170 240 L 70 240 Z"
          fill="#111827"
          stroke="#06b6d4"
          strokeWidth="2"
        />
        <path d="M 112 195 L 128 195 L 120 215 Z" fill="#ec4899" />

        {/* Face Silhouette */}
        <path
          d="M 75 90 Q 70 145 120 170 Q 170 145 165 90 Q 165 50 120 48 Q 75 50 75 90 Z"
          fill="url(#skinGrad)"
        />

        {/* Blush Cheeks */}
        <ellipse cx="90" cy="130" rx="10" ry="5" fill="#f43f5e" opacity="0.35" />
        <ellipse cx="150" cy="130" rx="10" ry="5" fill="#f43f5e" opacity="0.35" />

        {/* Anime Eyes */}
        {blink ? (
          // Blinking Slits
          <g stroke="#374151" strokeWidth="3" strokeLinecap="round" fill="none">
            <path d="M 88 118 Q 98 122 108 118" />
            <path d="M 132 118 Q 142 122 152 118" />
          </g>
        ) : (
          // Expressive Glowing Anime Eyes
          <g>
            {/* Left Eye */}
            <ellipse cx="98" cy="116" rx="12" ry="16" fill="url(#eyeGrad)" />
            <ellipse cx="98" cy="116" rx="9" ry="12" fill="#0f172a" />
            {/* Highlights */}
            <circle cx="95" cy="110" r="4" fill="#ffffff" />
            <circle cx="102" cy="122" r="2" fill="#ffffff" opacity="0.8" />
            <path d="M 84 102 Q 98 96 112 104" stroke="#1f2937" strokeWidth="3.5" strokeLinecap="round" fill="none" />

            {/* Right Eye */}
            <ellipse cx="142" cy="116" rx="12" ry="16" fill="url(#eyeGrad)" />
            <ellipse cx="142" cy="116" rx="9" ry="12" fill="#0f172a" />
            {/* Highlights */}
            <circle cx="139" cy="110" r="4" fill="#ffffff" />
            <circle cx="146" cy="122" r="2" fill="#ffffff" opacity="0.8" />
            <path d="M 128 104 Q 142 96 156 102" stroke="#1f2937" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          </g>
        )}

        {/* Petite Nose */}
        <path d="M 120 128 L 118 133" stroke="#f43f5e" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />

        {/* Dynamic Lip-Sync Mouth */}
        {lipSyncRatio > 0.05 ? (
          <g>
            {/* Open Mouth with Tongue */}
            <ellipse
              cx="120"
              cy={145 + mouthOpenAmount / 3}
              rx="9"
              ry={mouthOpenAmount / 2}
              fill="#991b1b"
            />
            <ellipse
              cx="120"
              cy={146 + mouthOpenAmount / 2.5}
              rx="6"
              ry={mouthOpenAmount / 4}
              fill="#f43f5e"
            />
          </g>
        ) : (
          // Gentle Anime Smile
          <path
            d="M 113 145 Q 120 150 127 145"
            stroke="#e11d48"
            strokeWidth="2.5"
            strokeLinecap="round"
            fill="none"
          />
        )}

        {/* Cyber Headset / Audio Visor Device */}
        <rect x="62" y="105" width="10" height="25" rx="5" fill="#06b6d4" className="animate-pulse" />
        <rect x="168" y="105" width="10" height="25" rx="5" fill="#ec4899" className="animate-pulse" />
        <path d="M 67 105 Q 120 30 173 105" stroke="#38bdf8" strokeWidth="3" fill="none" opacity="0.8" />

        {/* Front Anime Bangs */}
        <path
          d="M 72 75 Q 85 110 95 105 Q 110 85 118 112 Q 125 85 140 106 Q 150 110 168 75 Q 120 35 72 75 Z"
          fill="url(#hairGrad)"
        />
      </svg>

      {/* Floating Status Indicator Tag */}
      <div 
        id="myra-mood-badge"
        className="mt-2 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase border border-cyan-500/30 bg-gray-900/90 text-cyan-300 backdrop-blur-md shadow-lg flex items-center gap-1.5"
      >
        <span className={`w-2 h-2 rounded-full ${
          mood === 'speaking' ? 'bg-pink-400 animate-ping' :
          mood === 'listening' ? 'bg-cyan-400 animate-pulse' :
          mood === 'thinking' ? 'bg-amber-400 animate-bounce' : 'bg-emerald-400'
        }`} />
        <span>{mood}</span>
      </div>
    </div>
  );
};
