import React, { useState } from 'react';
import { 
  Mic, 
  MicOff, 
  Send, 
  Camera, 
  MessageSquare, 
  Video, 
  Settings, 
  PhoneCall, 
  Sparkles 
} from 'lucide-react';
import { soundEffects } from '../services/soundEffects';
import type { AndroidIntentType } from '../types';

interface ContinuousVoiceBarProps {
  isListening: boolean;
  onToggleListening: () => void;
  onSubmitText: (query: string) => void;
  onQuickIntent: (intent: AndroidIntentType) => void;
}

export const ContinuousVoiceBar: React.FC<ContinuousVoiceBarProps> = ({
  isListening,
  onToggleListening,
  onSubmitText,
  onQuickIntent
}) => {
  const [inputText, setInputText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    soundEffects.playClick();
    onSubmitText(inputText.trim());
    setInputText('');
  };

  return (
    <div id="continuous-voice-bar" className="w-full flex flex-col gap-3">
      {/* Quick Android Intent Launchers */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
        <span className="text-gray-500 font-semibold uppercase text-[10px] tracking-wider shrink-0 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-pink-400" /> Quick Intents:
        </span>
        <button
          id="quick-intent-camera"
          onClick={() => onQuickIntent('camera')}
          className="px-2.5 py-1.5 rounded-lg bg-gray-900 border border-gray-800 hover:border-cyan-500/50 hover:bg-gray-850 text-gray-300 flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <Camera className="w-3.5 h-3.5 text-cyan-400" />
          <span>Camera</span>
        </button>
        <button
          id="quick-intent-whatsapp"
          onClick={() => onQuickIntent('whatsapp')}
          className="px-2.5 py-1.5 rounded-lg bg-gray-900 border border-gray-800 hover:border-emerald-500/50 hover:bg-gray-850 text-gray-300 flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
          <span>WhatsApp</span>
        </button>
        <button
          id="quick-intent-youtube"
          onClick={() => onQuickIntent('youtube')}
          className="px-2.5 py-1.5 rounded-lg bg-gray-900 border border-gray-800 hover:border-red-500/50 hover:bg-gray-850 text-gray-300 flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <Video className="w-3.5 h-3.5 text-rose-400" />
          <span>YouTube</span>
        </button>
        <button
          id="quick-intent-settings"
          onClick={() => onQuickIntent('settings')}
          className="px-2.5 py-1.5 rounded-lg bg-gray-900 border border-gray-800 hover:border-amber-500/50 hover:bg-gray-850 text-gray-300 flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <Settings className="w-3.5 h-3.5 text-amber-400" />
          <span>Settings</span>
        </button>
        <button
          id="quick-intent-phone"
          onClick={() => onQuickIntent('phone')}
          className="px-2.5 py-1.5 rounded-lg bg-gray-900 border border-gray-800 hover:border-blue-500/50 hover:bg-gray-850 text-gray-300 flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <PhoneCall className="w-3.5 h-3.5 text-blue-400" />
          <span>Phone</span>
        </button>
      </div>

      {/* Main Microphone & Command Input Dock */}
      <div className="relative flex items-center gap-2 bg-gray-900/90 border border-gray-800 p-2 rounded-2xl backdrop-blur-md shadow-2xl">
        {/* Pulsing Mic Button */}
        <button
          id="btn-voice-mic"
          onClick={onToggleListening}
          className={`relative p-3.5 rounded-xl flex items-center justify-center transition-all duration-300 shrink-0 ${
            isListening
              ? 'bg-rose-500 text-white shadow-[0_0_20px_rgba(244,63,94,0.6)] animate-pulse'
              : 'bg-cyan-500 text-gray-950 hover:bg-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
          }`}
          title={isListening ? 'Stop Voice Listening' : 'Speak to Myra'}
        >
          {isListening ? <Mic className="w-5 h-5 animate-bounce" /> : <MicOff className="w-5 h-5" />}
        </button>

        {/* Audio Wave Visualizer Bars when listening */}
        {isListening ? (
          <div className="flex-1 flex items-center justify-center gap-1 h-10 px-4 bg-gray-950/60 rounded-xl border border-gray-800">
            <div className="w-1 bg-cyan-400 rounded-full voice-bar-active [animation-delay:0.1s]" />
            <div className="w-1 bg-pink-400 rounded-full voice-bar-active [animation-delay:0.3s]" />
            <div className="w-1 bg-cyan-300 rounded-full voice-bar-active [animation-delay:0.2s]" />
            <div className="w-1 bg-purple-400 rounded-full voice-bar-active [animation-delay:0.4s]" />
            <div className="w-1 bg-pink-500 rounded-full voice-bar-active [animation-delay:0.15s]" />
            <div className="w-1 bg-cyan-400 rounded-full voice-bar-active [animation-delay:0.35s]" />
            <span className="text-xs text-cyan-300 ml-2 font-medium tracking-wide">Listening to your command...</span>
          </div>
        ) : (
          /* Text Command Input Form */
          <form onSubmit={handleSubmit} className="flex-1 flex items-center gap-2">
            <input
              id="input-voice-command"
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask Myra anything or command: 'Turn on torch', 'Open WhatsApp'..."
              className="flex-1 bg-gray-950/80 border border-gray-800 focus:border-cyan-500/80 text-gray-100 placeholder-gray-500 text-sm px-4 py-2.5 rounded-xl outline-none transition-colors"
            />
            <button
              id="btn-send-command"
              type="submit"
              disabled={!inputText.trim()}
              className="p-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-cyan-400 disabled:opacity-40 disabled:hover:bg-gray-800 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
