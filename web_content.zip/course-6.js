/* JOSTECH — COURS 06 : RÉSEAUX, ARCHITECTURE & MAINTENANCE */
registerDisciplineLevels(6, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Architecture matérielle, assemblage et maintenance informatique.",
    chapters: [{
      id: "res-1-1", title: "Chapitre 1 : Matériel et Maintenance",
      lessons: [{
        id: "res-1-1-1", title: "Leçon 1 : Composants et Maintenance Préventive/Corrective", duration: "25 min",
        objectives: ["Identifier carte mère, CPU, RAM, alimentation et SSD.", "Distinguer maintenance préventive, corrective et protection ESD."],
        prerequisites: ["Bases d'informatique générale."],
        sections: [
          { type: "theory", title: "Anatomie et maintenance", text: "La carte mère relie CPU (avec pâte thermique), RAM, SSD NVMe et alimentation (12V, 5V, 3,3V). La maintenance préventive évite les pannes (dépoussiérage, onduleur, sauvegardes) ; la maintenance corrective répare une panne déclarée via le diagnostic POST." },
          { type: "warning", title: "Sécurité antistatique (ESD)", text: "Avant de manipuler une barrette RAM ou carte mère, débranchez le secteur et touchez le châssis métallique pour décharger l'électricité statique." }
        ],
        exercise: {
          question: "Un PC s'allume (ventilateurs), émet 3 bips longs sans image. Quelle étape échoue et quel composant vérifier ?",
          solution: "Le test POST du BIOS/UEFI signale une panne matérielle : vérifiez et réinsérez les barrettes de RAM."
        },
        summary: "Un PC fiable combine protection ESD, refroidissement maîtrisé et maintenance préventive régulière.",
        references: ["Mueller, S. — Upgrading and Repairing PCs."]
      }]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Modèles OSI et TCP/IP, équipements réseau et protocoles.",
    chapters: [{
      id: "res-2-1", title: "Chapitre 2 : Modèles OSI & TCP/IP",
      lessons: [{
        id: "res-2-1-1", title: "Leçon 1 : Couches OSI, Switch (MAC), Routeur (IP) et TCP/UDP", duration: "30 min",
        objectives: ["Situer les 7 couches OSI.", "Différencier Switch vs Routeur et TCP vs UDP."],
        prerequisites: ["Niveau 1 — Matériel."],
        sections: [
          { type: "table", title: "Modèle OSI simplifié", headers: ["Couches clés", "Adresse / Unité", "Rôle"], rows: [
            ["7-5. Application", "Données (HTTP, DNS)", "Services utilisateur."],
            ["4. Transport", "Ports (TCP / UDP)", "TCP = fiable ; UDP = rapide temps réel."],
            ["3. Réseau", "Adresse IP (Paquets)", "Routeur : choisit le chemin entre réseaux."],
            ["2. Liaison", "Adresse MAC (Trames)", "Switch : relie les appareils du réseau local."],
            ["1. Physique", "Bits (Câbles, Wi-Fi)", "Transmission des signaux."]
          ]}
        ],
        exercise: {
          question: "Pourquoi le téléchargement d'un fichier utilise-t-il TCP alors qu'un appel vidéo en direct utilise plutôt UDP ?",
          solution: "TCP garantit l'arrivée de 100 % des octets sans erreur (indispensable pour un fichier). UDP évite les retransmissions lentes pour garder la fluidité temps réel."
        },
        summary: "Le Switch connecte un réseau local via les adresses MAC (couche 2) ; le Routeur interconnecte plusieurs réseaux via les adresses IP (couche 3).",
        references: ["Tanenbaum, A. — Réseaux, Pearson."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Routage IP, sous-réseaux CIDR, administration systèmes et virtualisation.",
    chapters: [{
      id: "res-3-1", title: "Chapitre 3 : Sous-réseaux CIDR & Virtualisation",
      lessons: [{
        id: "res-3-1-1", title: "Leçon 1 : Masques CIDR, NAT et Machines Virtuelles vs Conteneurs", duration: "30 min",
        objectives: ["Calculer le nombre d'hôtes d'un sous-réseau /24.", "Distinguer VM complète et conteneur (Docker)."],
        prerequisites: ["Niveau 2 — OSI et binaire."],
        sections: [
          { type: "code", lang: "Adressage IPv4 / CIDR", code: "Adresse : 192.168.1.0/24  (Masque : 255.255.255.0)\nBits hôtes restants : 32 - 24 = 8 bits\nAdresses utilisables : 2^8 - 2 = 254 appareils (de .1 à .254)\n(.0 = adresse réseau ; .255 = broadcast)" },
          { type: "theory", title: "Virtualisation (VM) vs Conteneurs", text: "Un hyperviseur (VirtualBox, VMware, KVM) simule un ordinateur matériel entier par VM (lourd mais isolation forte). Un conteneur (Docker) partage le noyau Linux de l'hôte en isolant les processus : démarrage en 1 seconde et très économe en RAM." }
        ],
        exercise: {
          question: "Combien d'appareils peuvent recevoir une IP dans un sous-réseau 10.0.0.0/26 ?",
          solution: "Bits hôtes = 32 - 26 = 6 bits → 2^6 - 2 = 64 - 2 = 62 adresses hôtes utilisables."
        },
        summary: "Le découpage CIDR optimise les adresses IP, le NAT partage l'accès Internet et la virtualisation/conteneurisation optimise les serveurs.",
        references: ["Kurose & Ross — Computer Networking."]
      }]
    }]
  }
});