# v1.59.4 — Copa integrada ao calendário do Brasileirão

- Removido o bloco separado “Copa do Brasil — Calendário da temporada”.
- Jogos da Copa aparecem misturados cronologicamente aos jogos do Brasileirão na tela Partidas > Calendário da temporada.
- Partidas da Copa destacadas em azul, com fase, data, ida/volta e placar.
- Copa continua acessível em LIGAS > COPA DO BRASIL.
- Eliminados os quatro clubes de menor força da Copa (56 participantes).
- Primeira fase: 28 confrontos; segunda fase: 14 confrontos e duas vagas de repescagem pelos melhores resultados entre os eliminados, formando 16 clubes para as oitavas.
- Fases simuladas automaticamente conforme o calendário avança; nenhum botão de simulação manual.
- Limpeza única dos saves de carreira na primeira abertura, conforme autorização permanente do usuário; arquivos de clubes, elencos e escudos preservados.
