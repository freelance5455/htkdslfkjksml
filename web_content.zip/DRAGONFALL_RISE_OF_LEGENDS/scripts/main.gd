extends Node3D

const SAVE_PATH := "user://dragonfall_save.cfg"
var player: CharacterBody3D
var dragon: Node3D
var camera: Camera3D
var ui: CanvasLayer
var menu_root: Control
var game_hud: Control
var team_panel: Control
var ending_panel: Control
var ending_label: Label
var ending_active := false
var ending_step := 0
var ending_timer := 0.0
var status_label: Label
var boss_bar: ProgressBar
var boss_name_label: Label
var player_health := 100.0
var boss_health := 100.0
var playing := false
var boss_active := false
var dragon_phase := 0
var phase_timer := 0.0
var attack_cooldown := 0.0
var left_pressed := false
var right_pressed := false
var jump_queued := false
var attack_queued := false
var save_cfg := ConfigFile.new()
var completed_bosses := 0
var world_time := 0.0

var phase_colors: Array[Color] = [
	Color(0.68, 0.28, 0.95), Color(0.95, 0.12, 0.12),
	Color(0.25, 0.75, 1.0), Color(1.0, 0.68, 0.12),
	Color(0.95, 0.35, 0.78)
]
var phase_names := ["البنفسجي والأبيض", "الأسود والأحمر", "الأبيض والأزرق", "الذهبي والأسود", "ألوان الأسطورة"]

func _ready() -> void:
	load_save()
	build_world()
	build_player()
	build_dragon()
	build_camera()
	build_ui()
	show_main_menu()

func make_material(color: Color, metallic: float = 0.0, roughness: float = 0.72) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = metallic
	mat.roughness = roughness
	return mat

func add_mesh(parent: Node3D, mesh: Mesh, pos: Vector3, mat: Material, scale: Vector3 = Vector3.ONE, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var inst := MeshInstance3D.new()
	inst.mesh = mesh
	inst.position = pos
	inst.scale = scale
	inst.rotation = rot
	if mat != null:
		inst.material_override = mat.duplicate()
	parent.add_child(inst)
	return inst

func build_world() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.025, 0.045, 0.13)
	sky_mat.sky_horizon_color = Color(0.38, 0.22, 0.34)
	sky_mat.ground_bottom_color = Color(0.045, 0.055, 0.09)
	sky_mat.ground_horizon_color = Color(0.2, 0.16, 0.23)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.42, 0.48, 0.72)
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env_node.environment = env
	add_child(env_node)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-42, -28, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)

	var ground_mat := make_material(Color(0.12, 0.29, 0.19))
	var ground := StaticBody3D.new()
	ground.name = "Ground"
	add_child(ground)
	var ground_mesh := BoxMesh.new()
	ground_mesh.size = Vector3(120, 1, 24)
	add_mesh(ground, ground_mesh, Vector3(18, -0.55, 0), ground_mat)
	var ground_col := CollisionShape3D.new()
	var ground_shape := BoxShape3D.new()
	ground_shape.size = ground_mesh.size
	ground_col.shape = ground_shape
	ground_col.position = Vector3(18, -0.55, 0)
	ground.add_child(ground_col)

	# Layered mountains and distant ruins give the world a broader silhouette.
	var mountain_mat := make_material(Color(0.12, 0.16, 0.28))
	var far_mat := make_material(Color(0.20, 0.20, 0.34))
	for i in range(13):
		var x := -24.0 + float(i) * 8.5
		var h := 8.0 + float((i * 7) % 6) * 1.9
		var mountain := PrismMesh.new()
		mountain.size = Vector3(11, h, 7)
		add_mesh(self, mountain, Vector3(x, h * 0.45 - 1.0, -8.5), mountain_mat, Vector3.ONE, Vector3(0, 0.2, 0))
		var far_mountain := PrismMesh.new()
		far_mountain.size = Vector3(13, h * 0.75, 6)
		add_mesh(self, far_mountain, Vector3(x + 3.0, h * 0.36, -13.0), far_mat)

	var tree_trunk := make_material(Color(0.24, 0.12, 0.075))
	var leaves := make_material(Color(0.07, 0.28, 0.19))
	var leaves_light := make_material(Color(0.12, 0.4, 0.25))
	for i in range(25):
		var x := -22.0 + float(i) * 3.8
		if absf(x - 15.0) < 5.0:
			continue
		var tree := Node3D.new()
		tree.position = Vector3(x, 0, -2.0 - float(i % 3) * 1.5)
		add_child(tree)
		var trunk := CylinderMesh.new()
		trunk.top_radius = 0.22
		trunk.bottom_radius = 0.38
		trunk.height = 2.8
		add_mesh(tree, trunk, Vector3(0, 1.4, 0), tree_trunk)
		var crown := SphereMesh.new()
		crown.radius = 1.25
		crown.height = 2.3
		add_mesh(tree, crown, Vector3(0, 3.0, 0), leaves if i % 2 == 0 else leaves_light, Vector3(1.0, 1.1, 0.9))

	# Glowing crystals and old stone columns along the path.
	var crystal_mat := make_material(Color(0.25, 0.72, 1.0), 0.35, 0.25)
	var stone_mat := make_material(Color(0.31, 0.33, 0.4), 0.12)
	for i in range(9):
		var x := -16.0 + float(i) * 7.0
		var crystal := PrismMesh.new()
		crystal.size = Vector3(0.9, 2.2 + float(i % 3) * 0.7, 0.8)
		add_mesh(self, crystal, Vector3(x, 0.4, 2.0), crystal_mat, Vector3.ONE, Vector3(0.1, float(i), 0.15))
		if i % 2 == 0:
			var pillar := BoxMesh.new()
			pillar.size = Vector3(0.65, 3.8, 0.65)
			add_mesh(self, pillar, Vector3(x + 2.1, 1.4, -3.0), stone_mat)
			var cap := BoxMesh.new()
			cap.size = Vector3(1.0, 0.35, 1.0)
			add_mesh(self, cap, Vector3(x + 2.1, 3.35, -3.0), stone_mat)

	# Boss arena ring: decorative stone blocks, no terrain destruction.
	var arena_mat := make_material(Color(0.24, 0.25, 0.33))
	for i in range(16):
		var angle := TAU * float(i) / 16.0
		var block := BoxMesh.new()
		block.size = Vector3(1.1, 0.5, 1.2)
		add_mesh(self, block, Vector3(15.0 + cos(angle) * 5.0, -0.12, sin(angle) * 4.0), arena_mat, Vector3.ONE, Vector3(0, -angle, 0))

func build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(-18, 0.2, 0)
	player.floor_snap_length = 0.35
	player.set_script(load("res://scripts/player.gd"))
	add_child(player)
	var collider := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.42
	capsule.height = 1.8
	collider.shape = capsule
	collider.position.y = 0.9
	player.add_child(collider)

	var body_mat := make_material(Color(0.15, 0.55, 0.88), 0.05)
	var skin_mat := make_material(Color(0.92, 0.66, 0.47))
	var dark_mat := make_material(Color(0.08, 0.11, 0.19))
	var torso := CapsuleMesh.new()
	torso.radius = 0.38
	torso.height = 0.95
	add_mesh(player, torso, Vector3(0, 1.0, 0), body_mat)
	var head := SphereMesh.new()
	head.radius = 0.3
	head.height = 0.6
	add_mesh(player, head, Vector3(0, 1.72, 0), skin_mat)
	var hair := SphereMesh.new()
	hair.radius = 0.31
	hair.height = 0.35
	add_mesh(player, hair, Vector3(0, 1.91, -0.035), dark_mat, Vector3(1.0, 0.65, 0.95))
	for side in [-1.0, 1.0]:
		var arm := CapsuleMesh.new()
		arm.radius = 0.13
		arm.height = 0.68
		add_mesh(player, arm, Vector3(side * 0.48, 1.0, 0), body_mat, Vector3.ONE, Vector3(0, 0, side * -0.15))
		var leg := CapsuleMesh.new()
		leg.radius = 0.16
		leg.height = 0.7
		add_mesh(player, leg, Vector3(side * 0.19, 0.38, 0), dark_mat)

func build_dragon() -> void:
	dragon = Node3D.new()
	dragon.name = "DragonBoss"
	dragon.position = Vector3(15, 0, 0)
	add_child(dragon)
	var body_mat := make_material(Color(0.68, 0.28, 0.95), 0.18, 0.32)
	var belly_mat := make_material(Color(0.91, 0.82, 0.98))
	var horn_mat := make_material(Color(0.19, 0.15, 0.24), 0.2)
	var body := SphereMesh.new()
	body.radius = 1.0
	body.height = 2.0
	add_mesh(dragon, body, Vector3(0, 2.0, 0), body_mat, Vector3(1.55, 0.95, 0.82))
	var belly := SphereMesh.new()
	belly.radius = 0.75
	belly.height = 1.5
	add_mesh(dragon, belly, Vector3(-0.15, 1.8, 0.64), belly_mat, Vector3(1.0, 0.8, 0.3))
	var head := SphereMesh.new()
	head.radius = 0.62
	head.height = 1.1
	add_mesh(dragon, head, Vector3(-1.45, 2.45, 0.05), body_mat, Vector3(1.15, 0.85, 0.9))
	var snout := SphereMesh.new()
	snout.radius = 0.35
	snout.height = 0.55
	add_mesh(dragon, snout, Vector3(-1.9, 2.18, 0.35), belly_mat, Vector3(1.2, 0.55, 0.7))
	var eye_mat := make_material(Color(1.0, 0.85, 0.12), 0.15, 0.2)
	for side in [-1.0, 1.0]:
		var eye := SphereMesh.new()
		eye.radius = 0.12
		eye.height = 0.22
		add_mesh(dragon, eye, Vector3(-1.57, 2.58, side * 0.42), eye_mat)
		var horn := PrismMesh.new()
		horn.size = Vector3(0.3, 0.9, 0.3)
		add_mesh(dragon, horn, Vector3(-1.2, 3.0, side * 0.34), horn_mat, Vector3.ONE, Vector3(0, 0, 0.4 * side))
		var wing := PrismMesh.new()
		wing.size = Vector3(1.7, 2.0, 0.25)
		add_mesh(dragon, wing, Vector3(0.0, 2.65, side * 0.9), body_mat, Vector3(1.0, 1.0, 0.5), Vector3(0, 0, side * 0.45))
	var tail := CapsuleMesh.new()
	tail.radius = 0.22
	tail.height = 2.0
	add_mesh(dragon, tail, Vector3(1.6, 1.75, 0), body_mat, Vector3(0.75, 1.0, 0.8), Vector3(0, 0, -1.0))
	dragon.visible = false

func build_camera() -> void:
	camera = Camera3D.new()
	camera.name = "GameCamera"
	camera.position = Vector3(0, 5.3, 20)
	camera.fov = 55
	add_child(camera)
	camera.current = true
	camera.look_at(Vector3(0, 1.5, 0), Vector3.UP)

func build_ui() -> void:
	ui = CanvasLayer.new()
	ui.layer = 10
	add_child(ui)
	menu_root = Control.new()
	menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(menu_root)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.025, 0.07, 0.72)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_root.add_child(shade)
	var title := Label.new()
	title.text = "DRAGONFALL\nRISE OF LEGENDS"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", Color(1.0, 0.79, 0.28))
	title.anchor_left = 0.15
	title.anchor_right = 0.85
	title.anchor_top = 0.12
	title.anchor_bottom = 0.34
	menu_root.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "المغامرة تبدأ من هنا"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 22)
	subtitle.anchor_left = 0.15
	subtitle.anchor_right = 0.85
	subtitle.anchor_top = 0.35
	subtitle.anchor_bottom = 0.43
	menu_root.add_child(subtitle)
	var play_btn := make_button("ابدأ مغامرتك", 0.31, 0.51, 0.38, 0.09)
	play_btn.pressed.connect(start_adventure)
	menu_root.add_child(play_btn)
	var multi_btn := make_button("ابدأ مغامرتك بالمولتي بلاير", 0.25, 0.62, 0.50, 0.09)
	multi_btn.pressed.connect(show_team_menu)
	menu_root.add_child(multi_btn)
	var continue_label := Label.new()
	continue_label.text = "الزعيمات المهزومة: %d" % completed_bosses
	continue_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	continue_label.add_theme_font_size_override("font_size", 16)
	continue_label.anchor_left = 0.2
	continue_label.anchor_right = 0.8
	continue_label.anchor_top = 0.76
	continue_label.anchor_bottom = 0.82
	menu_root.add_child(continue_label)
	var credits := Label.new()
	credits.text = "تطوير: ZIZO  |  مساعد التطوير: Bebo"
	credits.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	credits.add_theme_font_size_override("font_size", 14)
	credits.add_theme_color_override("font_color", Color(0.8, 0.84, 0.95))
	credits.anchor_left = 0.1
	credits.anchor_right = 0.9
	credits.anchor_top = 0.9
	credits.anchor_bottom = 0.96
	menu_root.add_child(credits)

	game_hud = Control.new()
	game_hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(game_hud)
	game_hud.visible = false
	var back_btn := make_button("القائمة", 0.02, 0.03, 0.14, 0.075)
	back_btn.pressed.connect(show_main_menu)
	game_hud.add_child(back_btn)
	boss_name_label = Label.new()
	boss_name_label.text = "زعيم التنين"
	boss_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_name_label.add_theme_font_size_override("font_size", 18)
	boss_name_label.anchor_left = 0.35
	boss_name_label.anchor_right = 0.65
	boss_name_label.anchor_top = 0.025
	boss_name_label.anchor_bottom = 0.07
	game_hud.add_child(boss_name_label)
	boss_bar = ProgressBar.new()
	boss_bar.min_value = 0
	boss_bar.max_value = 100
	boss_bar.value = 100
	boss_bar.show_percentage = false
	boss_bar.anchor_left = 0.28
	boss_bar.anchor_right = 0.72
	boss_bar.anchor_top = 0.08
	boss_bar.anchor_bottom = 0.115
	game_hud.add_child(boss_bar)
	status_label = Label.new()
	status_label.text = "اقترب من التنين!"
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.add_theme_font_size_override("font_size", 16)
	status_label.anchor_left = 0.2
	status_label.anchor_right = 0.8
	status_label.anchor_top = 0.15
	status_label.anchor_bottom = 0.21
	game_hud.add_child(status_label)
	var left_btn := make_button("◀", 0.035, 0.78, 0.14, 0.16)
	left_btn.button_down.connect(func(): left_pressed = true)
	left_btn.button_up.connect(func(): left_pressed = false)
	game_hud.add_child(left_btn)
	var right_btn := make_button("▶", 0.19, 0.78, 0.14, 0.16)
	right_btn.button_down.connect(func(): right_pressed = true)
	right_btn.button_up.connect(func(): right_pressed = false)
	game_hud.add_child(right_btn)
	var jump_btn := make_button("قفز", 0.82, 0.78, 0.14, 0.16)
	jump_btn.button_down.connect(func(): jump_queued = true)
	game_hud.add_child(jump_btn)
	var attack_btn := make_button("هجوم", 0.66, 0.78, 0.14, 0.16)
	attack_btn.button_down.connect(func(): attack_queued = true)
	game_hud.add_child(attack_btn)

	team_panel = Control.new()
	team_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(team_panel)
	team_panel.visible = false
	var team_shade := ColorRect.new()
	team_shade.color = Color(0.01, 0.025, 0.06, 0.9)
	team_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	team_panel.add_child(team_shade)
	var team_title := Label.new()
	team_title.text = "اللعب الجماعي"
	team_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	team_title.add_theme_font_size_override("font_size", 34)
	team_title.add_theme_color_override("font_color", Color(1, 0.8, 0.3))
	team_title.anchor_left = 0.15
	team_title.anchor_right = 0.85
	team_title.anchor_top = 0.1
	team_title.anchor_bottom = 0.2
	team_panel.add_child(team_title)
	var create_btn := make_button("إنشاء فريق", 0.28, 0.31, 0.44, 0.09)
	create_btn.pressed.connect(create_local_team)
	team_panel.add_child(create_btn)
	var join_btn := make_button("الانضمام إلى فريق", 0.28, 0.43, 0.44, 0.09)
	join_btn.pressed.connect(join_local_team)
	team_panel.add_child(join_btn)
	var code_entry := LineEdit.new()
	code_entry.name = "TeamCodeInput"
	code_entry.placeholder_text = "أدخل رمز الفريق"
	code_entry.max_length = 12
	code_entry.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	code_entry.anchor_left = 0.28
	code_entry.anchor_right = 0.72
	code_entry.anchor_top = 0.56
	code_entry.anchor_bottom = 0.64
	team_panel.add_child(code_entry)
	var team_status := Label.new()
	team_status.name = "TeamStatus"
	team_status.text = "فريق يصل إلى 3 لاعبين — يتطلب خادمًا للاتصال الحقيقي"
	team_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	team_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	team_status.anchor_left = 0.12
	team_status.anchor_right = 0.88
	team_status.anchor_top = 0.68
	team_status.anchor_bottom = 0.79
	team_panel.add_child(team_status)
	var back_team := make_button("رجوع", 0.36, 0.84, 0.28, 0.08)
	back_team.pressed.connect(show_main_menu)
	team_panel.add_child(back_team)

	# Story ending cinematic shown after the final dragon is defeated.
	ending_panel = Control.new()
	ending_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(ending_panel)
	ending_panel.visible = false
	var ending_bg := ColorRect.new()
	ending_bg.color = Color(0.015, 0.008, 0.035, 0.96)
	ending_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ending_panel.add_child(ending_bg)
	var ending_header := Label.new()
	ending_header.text = "DRAGONFALL  •  المشهد الأخير"
	ending_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ending_header.add_theme_font_size_override("font_size", 22)
	ending_header.add_theme_color_override("font_color", Color(1.0, 0.78, 0.25))
	ending_header.anchor_left = 0.08
	ending_header.anchor_right = 0.92
	ending_header.anchor_top = 0.12
	ending_header.anchor_bottom = 0.22
	ending_panel.add_child(ending_header)
	ending_label = Label.new()
	ending_label.name = "EndingStoryText"
	ending_label.text = "سقط التنين الجديد..."
	ending_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ending_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ending_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ending_label.add_theme_font_size_override("font_size", 30)
	ending_label.add_theme_color_override("font_color", Color(0.95, 0.92, 1.0))
	ending_label.anchor_left = 0.08
	ending_label.anchor_right = 0.92
	ending_label.anchor_top = 0.28
	ending_label.anchor_bottom = 0.72
	ending_panel.add_child(ending_label)
	var ending_hint := Label.new()
	ending_hint.text = "يتقدّم المشهد تلقائيًا..."
	ending_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ending_hint.add_theme_font_size_override("font_size", 15)
	ending_hint.add_theme_color_override("font_color", Color(0.65, 0.65, 0.78))
	ending_hint.anchor_left = 0.1
	ending_hint.anchor_right = 0.9
	ending_hint.anchor_top = 0.78
	ending_hint.anchor_bottom = 0.84
	ending_panel.add_child(ending_hint)
	var ending_menu_btn := make_button("العودة إلى القائمة", 0.3, 0.87, 0.4, 0.08)
	ending_menu_btn.pressed.connect(show_main_menu)
	ending_panel.add_child(ending_menu_btn)

func make_button(label_text: String, left: float, top: float, width: float, height: float) -> Button:
	var button := Button.new()
	button.text = label_text
	button.anchor_left = left
	button.anchor_top = top
	button.anchor_right = left + width
	button.anchor_bottom = top + height
	button.add_theme_font_size_override("font_size", 20)
	button.add_theme_color_override("font_color", Color(1, 1, 1))
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.12, 0.22, 0.42, 0.96)
	normal.border_color = Color(0.95, 0.67, 0.22)
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(14)
	normal.content_margin_left = 8
	normal.content_margin_right = 8
	button.add_theme_stylebox_override("normal", normal)
	var hover := normal.duplicate()
	hover.bg_color = Color(0.2, 0.35, 0.58, 1)
	button.add_theme_stylebox_override("hover", hover)
	return button

func show_main_menu() -> void:
	playing = false
	menu_root.visible = true
	game_hud.visible = false
	team_panel.visible = false
	ending_panel.visible = false
	ending_active = false
	player.visible = true
	camera.current = true
	camera.position = Vector3(player.position.x, 5.3, 20)
	camera.look_at(Vector3(player.position.x, 1.5, 0), Vector3.UP)

func start_adventure() -> void:
	menu_root.visible = false
	team_panel.visible = false
	game_hud.visible = true
	playing = true
	player.position = Vector3(-18, 0.2, 0)
	player.velocity = Vector3.ZERO
	player_health = 100
	if boss_health <= 0:
		boss_health = 100
		boss_active = false
		dragon_phase = 0
	dragon.visible = true
	boss_active = true
	phase_timer = 0
	attack_cooldown = 0
	status_label.text = "تحرّك نحو التنين وهاجمه!"
	update_boss_visuals()

func show_team_menu() -> void:
	menu_root.visible = false
	game_hud.visible = false
	team_panel.visible = true

func create_local_team() -> void:
	var code := "DR" + str(randi_range(100, 999))
	var label := team_panel.get_node("TeamStatus") as Label
	label.text = "رمز الفريق المحلي: %s\nهذه معاينة للواجهة؛ مشاركة الفريق عبر الإنترنت تحتاج خادمًا حقيقيًا." % code

func join_local_team() -> void:
	var entry := team_panel.get_node("TeamCodeInput") as LineEdit
	var label := team_panel.get_node("TeamStatus") as Label
	if entry.text.strip_edges().is_empty():
		label.text = "يرجى إدخال رمز الفريق."
	else:
		label.text = "لم يتم الاتصال بخادم لعبة بعد. لم يتم الانضمام فعليًا؛ تحقق من وجود خادم ثم حاول مجددًا."

func _process(delta: float) -> void:
	world_time += delta
	if ending_active:
		ending_timer += delta
		if ending_timer >= 3.8:
			ending_timer = 0.0
			ending_step += 1
			update_ending_cinematic()
		return
	if not playing:
		# Gentle animated menu camera; dragon intro can be added as a separate cinematic.
		camera.position.x = lerp(camera.position.x, player.position.x + sin(world_time * 0.22) * 1.5, delta * 0.3)
		camera.look_at(Vector3(camera.position.x, 1.6, 0), Vector3.UP)
		return
	camera.position = camera.position.lerp(Vector3(player.position.x, 5.0, 20), delta * 3.0)
	camera.look_at(Vector3(player.position.x + 1.5, 1.4, 0), Vector3.UP)
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	if boss_active:
		phase_timer += delta
		if phase_timer >= 13.0 and dragon_phase < 3:
			dragon_phase += 1
			phase_timer = 0
			update_boss_visuals()
			status_label.text = "تحوّل التنين: " + phase_names[dragon_phase]
		elif phase_timer >= 13.0 and dragon_phase == 3:
			dragon_phase = 4
			phase_timer = 0
			update_boss_visuals()
			status_label.text = "تحوّل أسطوري! انفجار بصري — الأرض لم تتضرر!"
			boss_bar.value = maxf(10.0, boss_bar.value)
		elif dragon_phase == 4 and phase_timer >= 8.0:
			dragon_phase = 1
			phase_timer = 0
			update_boss_visuals()
		if player.global_position.distance_to(dragon.global_position) < 3.2 and attack_cooldown <= 0:
			player_health -= 5.0
			attack_cooldown = 2.0
			status_label.text = "احذر! التنين يهاجمك!"
			if player_health <= 0:
				player.position = Vector3(-18, 0.2, 0)
				player_health = 100
				status_label.text = "أعد المحاولة! عدت إلى بداية الساحة."
		if attack_queued:
			attack_queued = false
			if absf(player.position.x - dragon.position.x) < 4.5:
				boss_health -= 12.5
				boss_bar.value = boss_health
				status_label.text = "أصبت التنين!"
				if boss_health <= 0:
					boss_active = false
					dragon.visible = false
					completed_bosses += 1
					save_progress()
					boss_name_label.text = "تمت هزيمة الزعيم!"
					status_label.text = "لقد هزمت التنين! تم حفظ تقدمك."
					boss_bar.value = 0
					start_ending_cinematic()

func start_ending_cinematic() -> void:
	playing = false
	ending_active = true
	ending_step = 0
	ending_timer = 0.0
	menu_root.visible = false
	game_hud.visible = false
	team_panel.visible = false
	ending_panel.visible = true
	update_ending_cinematic()

func update_ending_cinematic() -> void:
	var scenes := [
		"سقط التنين الجديد...\nوانطفأ وهج ألوانه وسط الدخان.",
		"في صمت الساحة، تحرّك ظلّ بجانبه...\nلقد استيقظ التنين القديم.",
		"نظر التنين القديم إلى رفيقه الساقط،\nثم اشتعلت عيناه بوهج ذهبي غامض.",
		"سأجعلهم يندمون على ما فعلوه!",
		"إنهم لا يعرفون الحقيقة كاملة...",
		"ظهر ضوء ذهبي من أعماق الظلام،\nثم ابتلعت العتمة المملكة بأكملها.",
		"لقد ختمت اللعبة!\nانتظر التحديث القادم لتكمل مغامرتك.\n\nZIZO  —  CREATOR\nBEBO  —  ASSISTANT"
	]
	if ending_step >= scenes.size():
		ending_active = false
		ending_step = scenes.size() - 1
	ending_label.text = scenes[ending_step]
	if ending_step == 6:
		ending_label.add_theme_color_override("font_color", Color(1.0, 0.78, 0.25))
	else:
		ending_label.add_theme_color_override("font_color", Color(0.95, 0.92, 1.0))

func update_boss_visuals() -> void:
	if not is_instance_valid(dragon):
		return
	var body_color: Color = phase_colors[dragon_phase]
	var belly_color := Color(0.93, 0.88, 1.0) if dragon_phase == 0 else body_color.lightened(0.35)
	for child in dragon.get_children():
		if child is MeshInstance3D:
			var mat := (child as MeshInstance3D).material_override as StandardMaterial3D
			if mat == null:
				continue
			if child.position.x < -1.7 or child.position.y < 1.9:
				mat.albedo_color = belly_color
			else:
				mat.albedo_color = body_color
				mat.emission_enabled = dragon_phase >= 3
				if dragon_phase >= 3:
					mat.emission = body_color
		# Change scale/pose slightly between forms.
	dragon.scale = Vector3.ONE * (1.0 + float(dragon_phase) * 0.035)

func save_progress() -> void:
	save_cfg.set_value("progress", "completed_bosses", completed_bosses)
	save_cfg.set_value("progress", "best_boss_health", boss_health)
	save_cfg.save(SAVE_PATH)

func load_save() -> void:
	var err := save_cfg.load(SAVE_PATH)
	if err == OK:
		completed_bosses = int(save_cfg.get_value("progress", "completed_bosses", 0))
