extends CharacterBody3D

const SPEED := 7.0
const JUMP_VELOCITY := 8.0
var gravity_value := 22.0
var game_root: Node

func _ready() -> void:
	game_root = get_parent()

func _physics_process(delta: float) -> void:
	if not game_root.get("playing"):
		velocity.x = move_toward(velocity.x, 0.0, SPEED * delta * 3.0)
		move_and_slide()
		return
	var direction := 0.0
	if Input.is_action_pressed("move_left") or game_root.get("left_pressed"):
		direction -= 1.0
	if Input.is_action_pressed("move_right") or game_root.get("right_pressed"):
		direction += 1.0
	velocity.x = direction * SPEED
	velocity.z = 0.0
	if not is_on_floor():
		velocity.y -= gravity_value * delta
	elif Input.is_action_just_pressed("jump") or game_root.get("jump_queued"):
		velocity.y = JUMP_VELOCITY
		game_root.set("jump_queued", false)
	if Input.is_action_just_pressed("attack"):
		game_root.set("attack_queued", true)
	move_and_slide()
	if direction != 0:
		rotation.y = 0.0 if direction > 0 else PI
