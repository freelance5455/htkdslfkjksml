DRAGONFALL: RISE OF LEGENDS
Godot 4.7.2 project (uses Godot 4 APIs; not compatible with Godot 3.x).

COMPATIBILITY
- The project feature tag is set to Godot 4.7 for the Godot 4.7.x series.
- Use a recent Godot 4.7.2 editor where possible. Other Godot versions may differ in APIs and should be tested.
- This ZIP has been checked for archive integrity and required project files. It has NOT been run inside the Godot engine in this environment, so a runtime-error-free guarantee cannot honestly be made.

HOW TO OPEN ON ANDROID
1. Extract this ZIP with ZArchiver into a normal folder.
2. Open Godot Android Editor.
3. Import/Open an existing project and select the extracted folder containing project.godot.
4. Open the project and press Run.

CURRENT PROTOTYPE FEATURES
- Procedurally assembled 3D fantasy landscape, trees, crystals, ruins, and dragon arena.
- Main menu and Arabic labels.
- Mobile Left/Right, Jump, and Attack buttons.
- Keyboard controls for testing: A/Left, D/Right, Space to jump, F to attack.
- Dragon boss with color phases and a boss health bar.
- New ending text cinematic after defeating the dragon: the new dragon falls, the old dragon awakens with a golden glow, vows revenge, hints that the full truth is unknown, then shows ZIZO / BEBO credits.
- Local save for completed boss count.
- Multiplayer UI for create/join team; real online server support is not implemented.

LIMITATIONS
- This is an early prototype, not a finished commercial-quality game.
- The 3D art uses built-in Godot meshes, not detailed imported models or polished animation.
- The opening dragon cinematic and story introduction before gameplay are not implemented yet; the added cinematic is the ending sequence.
- Multiplayer buttons are interface demonstrations only. Real online play requires a backend/server and network synchronization.
- APK export requires Android export templates and a configured Android build environment in Godot. Renaming ZIP to APK will not work.
