async function fetchStatus() {
  const res = await fetch("/api/status");
  const data = await res.json();

  document.getElementById("temp-value").textContent = data.temperature;
  document.getElementById("smoke-value").textContent = data.smoke_level;
  document.getElementById("last-update").textContent =
    "Last update: " + (data.last_update || "--");

  const statusText = document.getElementById("status-text");
  const statusCard = document.getElementById("status-card");
  const statusClass = data.status.replace(" ", "_");

  statusText.textContent = data.status;
  statusCard.className = "status-card " + statusClass;
}

async function fetchHistory() {
  const res = await fetch("/api/history");
  const rows = await res.json();
  const body = document.getElementById("history-body");
  body.innerHTML = "";

  rows.forEach((r) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${r.timestamp}</td>
      <td>${r.temperature}</td>
      <td>${r.smoke_level}</td>
      <td>${r.status}</td>
    `;
    body.appendChild(tr);
  });
}

function refreshAll() {
  fetchStatus();
  fetchHistory();
}

refreshAll();
setInterval(refreshAll, 4000);
