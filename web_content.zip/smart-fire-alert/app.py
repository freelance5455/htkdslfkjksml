"""
Smart Fire Emergency Alert System
----------------------------------
A Python (Flask) based software project that simulates smoke/temperature
sensors, detects a possible fire condition, logs events to a database,
and shows live status + alerts on a web dashboard.

Run:
    python app.py
Then open: http://127.0.0.1:5000
"""

import random
import sqlite3
import threading
import time
from datetime import datetime

from flask import Flask, jsonify, render_template

app = Flask(__name__)

DB_FILE = "fire_alerts.db"

# ---------- Thresholds (change these to tune sensitivity) ----------
TEMP_THRESHOLD = 55        # degrees Celsius
SMOKE_THRESHOLD = 300      # smoke sensor unit (0-1023 like MQ2 analog reading)

# ---------- Shared in-memory state (used by dashboard) ----------
current_state = {
    "temperature": 25,
    "smoke_level": 50,
    "status": "SAFE",       # SAFE / WARNING / FIRE ALERT
    "last_update": None,
}
state_lock = threading.Lock()


def init_db():
    """Create the alerts table if it does not already exist."""
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            temperature REAL NOT NULL,
            smoke_level REAL NOT NULL,
            status TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def log_event(temperature, smoke_level, status):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO alerts (timestamp, temperature, smoke_level, status) VALUES (?, ?, ?, ?)",
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), temperature, smoke_level, status),
    )
    conn.commit()
    conn.close()


def trigger_alert(temperature, smoke_level):
    """
    This is where a real system would fire an SMS / buzzer / email.
    For this software simulation we print to console -- replace this
    function's body with a Twilio SMS call, buzzer GPIO trigger, or
    SMTP email call for a real deployment.
    """
    print("=" * 50)
    print("🔥 FIRE ALERT TRIGGERED 🔥")
    print(f"Temperature: {temperature}°C | Smoke Level: {smoke_level}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)


def read_sensors():
    """
    Simulates reading a temperature sensor (e.g. DHT11/DHT22) and a
    smoke/gas sensor (e.g. MQ2). Replace this with real hardware
    reads (e.g. via pyserial / RPi.GPIO / machine.ADC on ESP32)
    when connecting actual sensors.
    """
    # Normal baseline readings with small random noise
    temperature = round(random.uniform(20, 35), 1)
    smoke_level = round(random.uniform(20, 150), 1)

    # Occasionally simulate a fire event so the dashboard has something
    # to show (about a 1 in 12 chance each cycle).
    if random.randint(1, 12) == 1:
        temperature = round(random.uniform(56, 90), 1)
        smoke_level = round(random.uniform(310, 900), 1)

    return temperature, smoke_level


def evaluate_status(temperature, smoke_level):
    if temperature >= TEMP_THRESHOLD and smoke_level >= SMOKE_THRESHOLD:
        return "FIRE ALERT"
    if temperature >= TEMP_THRESHOLD or smoke_level >= SMOKE_THRESHOLD:
        return "WARNING"
    return "SAFE"


def sensor_loop():
    """Background thread: keeps reading sensors every few seconds."""
    while True:
        temperature, smoke_level = read_sensors()
        status = evaluate_status(temperature, smoke_level)

        with state_lock:
            current_state["temperature"] = temperature
            current_state["smoke_level"] = smoke_level
            current_state["status"] = status
            current_state["last_update"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        log_event(temperature, smoke_level, status)

        if status == "FIRE ALERT":
            trigger_alert(temperature, smoke_level)

        time.sleep(4)  # sensor polling interval


@app.route("/")
def dashboard():
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    with state_lock:
        return jsonify(current_state)


@app.route("/api/history")
def api_history():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute(
        "SELECT timestamp, temperature, smoke_level, status FROM alerts "
        "ORDER BY id DESC LIMIT 20"
    )
    rows = cur.fetchall()
    conn.close()
    return jsonify(
        [
            {"timestamp": r[0], "temperature": r[1], "smoke_level": r[2], "status": r[3]}
            for r in rows
        ]
    )


if __name__ == "__main__":
    init_db()
    # Start the background sensor-simulation thread
    t = threading.Thread(target=sensor_loop, daemon=True)
    t.start()
    app.run(debug=True)
