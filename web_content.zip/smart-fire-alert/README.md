# 🔥 Smart Fire Emergency Alert System

Python (Flask) based software project jo temperature aur smoke sensor ki
readings simulate karta hai, fire condition detect karta hai, events ko
database mein log karta hai, aur ek live web dashboard par status dikhata hai.

## Project Structure
```
smart-fire-alert/
├── app.py                 # Main Flask app + sensor logic + alert logic
├── requirements.txt       # Python dependencies
├── templates/
│   └── index.html         # Dashboard page
└── static/
    ├── style.css           # Dashboard styling
    └── script.js           # Live data fetch + update
```

## 1. Local par run kaise karein

1. Python 3.9+ installed hona chahiye.
2. Terminal/CMD kholiye aur project folder mein jaiye:
   ```
   cd smart-fire-alert
   ```
3. (Optional but recommended) Virtual environment banayein:
   ```
   python -m venv venv
   venv\Scripts\activate        # Windows
   source venv/bin/activate     # Mac/Linux
   ```
4. Dependencies install karein:
   ```
   pip install -r requirements.txt
   ```
5. App run karein:
   ```
   python app.py
   ```
6. Browser mein kholiye: `http://127.0.0.1:5000`

Dashboard har 4 seconds mein naya sensor reading dikhayega. Jab temperature
55°C+ aur smoke 300+ ho jaaye, status "FIRE ALERT" ho jaayega (yeh randomly
har kuch cycles mein simulate hota hai taaki aapko demo mil sake).

## 2. Real sensors ke saath connect karna (agar hardware use kar rahe hain)

`app.py` mein `read_sensors()` function ko replace karein:
- DHT11/DHT22 temperature sensor → Raspberry Pi GPIO ya Arduino serial se
- MQ2 smoke/gas sensor → analog pin read karke
- `trigger_alert()` function mein GSM module / Twilio SMS / buzzer GPIO
  trigger add kar sakte hain real alert ke liye.

## 3. GitHub par upload karne ke steps (step by step)

1. **GitHub account** banayein (agar pehle se nahi hai): https://github.com
2. GitHub par jaakar **New Repository** banayein:
   - "+" icon → "New repository"
   - Name dein, jaise: `smart-fire-alert-system`
   - Public ya Private select karein
   - "Create repository" click karein (README add mat kijiye, kyunki hamare
     paas already hai)
3. Apne computer par project folder mein terminal kholiye aur yeh commands
   chalayein (ek-ek karke):
   ```
   cd smart-fire-alert
   git init
   git add .
   git commit -m "Initial commit: Smart Fire Emergency Alert System"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/smart-fire-alert-system.git
   git push -u origin main
   ```
   `YOUR-USERNAME` ki jagah apna GitHub username daalein, aur repository
   ka exact URL GitHub ke "Quick setup" page se copy kar sakte hain.
4. Agar `git` command "not found" bataye, toh pehle Git install karein:
   https://git-scm.com/downloads
5. Push hone ke baad, GitHub repo page refresh karein — saari files
   (app.py, templates, static, README) wahan dikhengi.

### Future changes push karne ke liye (har baar):
```
git add .
git commit -m "Describe what you changed"
git push
```

## 4. Ideas — is project ko aur behtar banane ke liye
- Real MQ2 smoke sensor + DHT11 temperature sensor Arduino/ESP32 se juda
  kar serial data Flask app ko bhejna
- SMS alert (Twilio API) ya WhatsApp alert (Twilio/WhatsApp Business API)
- Email alert (Python `smtplib`)
- Buzzer/LED indicator hardware side par
- Multiple room/sensor nodes ek hi dashboard par dikhana
- Login system taaki sirf authorized log dashboard dekh sakein
