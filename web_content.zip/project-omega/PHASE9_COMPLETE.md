# PROJECT OMEGA — Phase 9 Complete

Phase 9 is the final security, reliability, and release-polish pass on the Phase 8 project.

## Added / hardened

- Fixed the recursive `players` RLS policy by moving room-membership checking into a private `SECURITY DEFINER` helper.
- Removed the old direct-player-insert security gap: room membership remains created/restored through authenticated RPCs.
- Pinned SECURITY DEFINER function search paths to `public, pg_temp` instead of leaving them implicit.
- Explicitly revoked RPC execution from `anon`/`public`; only authenticated users can call game mutation/read functions.
- Added server-side validation for investigation/sabotage locations.
- Normalized location input before database lookups.
- Kept secret roles, clue source rows, and final-puzzle answers behind server-side checks/RLS.
- Preserved reconnect/session heartbeat, scenario selection, demo mode, spooky mode, voting, final puzzle, and end-state flow from earlier phases.
- Bumped the app version to `0.9.0`.

## Release checklist

1. Create a Supabase project and enable Anonymous Auth (or another authenticated sign-in method).
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Put the Supabase URL and publishable/anon key in `.env` using `.env.example`. Never put a `service_role`/secret key in the browser.
4. Build with `npm install` then `npm run build`.
5. Test a 4-player room on phones: create → join → lobby → reveal → investigation → discussion → vote → results → final puzzle → ended.
6. Test refresh/rejoin and a second browser/device.
7. For public release, use a proper hosting provider and review Supabase Auth, database, rate limits, and abuse controls.

## Important

This repository was statically hardened from the previous phase. A full live Supabase multiplayer run was not performed inside this build environment, so the release checklist above should be completed before public launch.
