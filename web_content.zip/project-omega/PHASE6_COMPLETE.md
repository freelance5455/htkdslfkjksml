# PROJECT OMEGA — Phase 6 Complete

This ZIP contains the combined Phase 1–6 project.

Phase 6 completes the core game loop with:
- server-side final puzzle generation
- randomized arithmetic puzzle
- protected answer storage
- 3 shared attempts
- Protector/Villain ending states
- automatic room transition to `ended`
- Case Closed screen

Supabase setup: run `supabase/schema.sql` in the project's Supabase SQL Editor. This development schema resets the project tables when re-run.

Core flow:
Home → Lobby → Secret Roles → Investigation → Discussion → Voting → Results → Final Puzzle → Case Closed

Runtime note: dependencies are not bundled. Run `npm install` and then `npm run dev` in a normal Node.js environment.
