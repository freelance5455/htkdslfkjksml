import { InputHTMLAttributes } from 'react'
import './FormField.css'

type Props = InputHTMLAttributes<HTMLInputElement> & { label: string }

export default function FormField({ label, ...rest }: Props) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      <input className="field-input" {...rest} />
    </label>
  )
}
