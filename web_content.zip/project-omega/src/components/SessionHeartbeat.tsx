import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { getRoomByCode, getRoomPlayers, setPlayerConnected } from '../lib/rooms'
import { getCurrentUserId } from '../lib/auth'

export default function SessionHeartbeat() {
  const location = useLocation()

  useEffect(() => {
    let cancelled = false
    let roomId: string | null = null
    let interval = 0

    async function resolve() {
      const match = location.pathname.match(/^\/(?:lobby|reveal|investigate|discuss|vote|results|puzzle|ended)\/([A-Za-z0-9]{4,8})$/)
      if (!match) return
      try {
        const room = await getRoomByCode(match[1])
        const userId = getCurrentUserId()
        const players = await getRoomPlayers(room.id)
        if (cancelled || !players.some((p) => p.user_id === userId)) return
        roomId = room.id
        await setPlayerConnected(room.id, true)
        interval = window.setInterval(() => {
          if (roomId) setPlayerConnected(roomId, true).catch(() => undefined)
        }, 15000)
      } catch {
        // Page-level hooks handle visible errors; heartbeat is best-effort.
      }
    }

    resolve()
    return () => {
      cancelled = true
      if (interval) window.clearInterval(interval)
      if (roomId) setPlayerConnected(roomId, false).catch(() => undefined)
    }
  }, [location.pathname])

  return null
}
