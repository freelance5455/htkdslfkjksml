import { ReactNode } from 'react'
import './AppShell.css'
import { useEffect, useState } from 'react'
import { isSpookyMode } from '../lib/settings'

export default function AppShell({ children }: { children: ReactNode }) {
  const [spooky, setSpooky] = useState(isSpookyMode())
  useEffect(() => { const f=()=>setSpooky(isSpookyMode()); window.addEventListener('omega-settings', f); return()=>window.removeEventListener('omega-settings', f) }, [])
  return (
    <div className={`shell ${spooky ? 'spooky-mode' : ''}`}>
      <aside className="shell-rail">
        <div className="shell-rail-mark">Ω</div>
        <div className="shell-rail-label">
          <span className="mono">CASE FILE</span>
          <h1>PROJECT<br />OMEGA</h1>
        </div>
      </aside>
      <main className="shell-content">{children}</main>
    </div>
  )
}
