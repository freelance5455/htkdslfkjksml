import { ButtonHTMLAttributes } from 'react'
import './Buttons.css'

type Props = ButtonHTMLAttributes<HTMLButtonElement> & { fullWidth?: boolean }

export function PrimaryButton({ fullWidth, className, ...rest }: Props) {
  return (
    <button
      className={`btn btn-primary ${fullWidth ? 'btn-full' : ''} ${className ?? ''}`}
      {...rest}
    />
  )
}

export function GhostButton({ fullWidth, className, ...rest }: Props) {
  return (
    <button
      className={`btn btn-ghost ${fullWidth ? 'btn-full' : ''} ${className ?? ''}`}
      {...rest}
    />
  )
}
