import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { ensureSignedIn } from './lib/auth'
import './styles/global.css'

async function bootstrap() {
  // Every device needs an anonymous auth session before it can talk to the
  // database — this is what lets the server keep secrets (like roles) safe.
  await ensureSignedIn()

  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </React.StrictMode>,
  )
}

bootstrap()
