import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getRoomByCode } from '../lib/rooms'
import { subscribeToRoom } from '../lib/realtime'
import { routeForRoomStatus } from '../lib/routeForStatus'
import type { Room } from '../lib/rooms'

type LoadStatus = 'loading' | 'ready' | 'error'

/**
 * Loads a room by its code, subscribes to live updates, and automatically
 * sends every player to the right screen the moment the room's phase
 * changes — e.g. everyone gets bounced from Investigation to Discussion
 * together when the host calls it. Also corrects anyone who lands on the
 * wrong screen directly (like via the browser's back button).
 *
 * Pass the status this page expects to be showing (e.g. 'voting' for the
 * voting page) — the hook only redirects when the room's actual status
 * differs from that.
 */
export function useLiveRoom(code: string | undefined, expectedStatus: Room['status']) {
  const navigate = useNavigate()
  const [room, setRoom] = useState<Room | null>(null)
  const [status, setStatus] = useState<LoadStatus>('loading')
  const [errorMessage, setErrorMessage] = useState('')
  const hasRedirected = useRef(false)

  useEffect(() => {
    if (!code) return
    let cancelled = false
    let unsubscribe: (() => void) | undefined
    hasRedirected.current = false

    function handleUpdate(updated: Room) {
      if (cancelled) return
      setRoom(updated)
      if (updated.status !== expectedStatus && !hasRedirected.current) {
        hasRedirected.current = true
        navigate(routeForRoomStatus(code!, updated.status))
      }
    }

    async function load() {
      try {
        const initialRoom = await getRoomByCode(code!)
        if (cancelled) return
        handleUpdate(initialRoom)
        setStatus('ready')
        unsubscribe = subscribeToRoom(initialRoom.id, handleUpdate)
      } catch (err) {
        if (cancelled) return
        setErrorMessage(err instanceof Error ? err.message : 'Something went wrong.')
        setStatus('error')
      }
    }

    load()
    return () => {
      cancelled = true
      unsubscribe?.()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code, expectedStatus])

  return { room, status, errorMessage }
}
