import { Route, Routes } from 'react-router-dom'
import AppShell from './components/AppShell'
import HomePage from './pages/HomePage'
import CreateGamePage from './pages/CreateGamePage'
import JoinGamePage from './pages/JoinGamePage'
import LobbyPage from './pages/LobbyPage'
import RoleRevealPage from './pages/RoleRevealPage'
import InvestigationPage from './pages/InvestigationPage'
import DiscussionPage from './pages/DiscussionPage'
import VotingPage from './pages/VotingPage'
import ResultsPage from './pages/ResultsPage'
import FinalPuzzlePage from './pages/FinalPuzzlePage'
import EndedPage from './pages/EndedPage'
import HowToPlayPage from './pages/HowToPlayPage'
import RejoinGamePage from './pages/RejoinGamePage'
import DemoPage from './pages/DemoPage'
import SessionHeartbeat from './components/SessionHeartbeat'

export default function App() {
  return (
    <AppShell>
      <SessionHeartbeat />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/create" element={<CreateGamePage />} />
        <Route path="/join" element={<JoinGamePage />} />
        <Route path="/rejoin" element={<RejoinGamePage />} />
        <Route path="/demo" element={<DemoPage />} />
        <Route path="/how-to-play" element={<HowToPlayPage />} />
        <Route path="/lobby/:code" element={<LobbyPage />} />
        <Route path="/reveal/:code" element={<RoleRevealPage />} />
        <Route path="/investigate/:code" element={<InvestigationPage />} />
        <Route path="/discuss/:code" element={<DiscussionPage />} />
        <Route path="/vote/:code" element={<VotingPage />} />
        <Route path="/results/:code" element={<ResultsPage />} />
        <Route path="/puzzle/:code" element={<FinalPuzzlePage />} />
        <Route path="/ended/:code" element={<EndedPage />} />
      </Routes>
    </AppShell>
  )
}
