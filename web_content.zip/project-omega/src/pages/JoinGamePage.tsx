import { FormEvent, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import FormField from '../components/FormField'
import { PrimaryButton, GhostButton } from '../components/Buttons'
import { joinRoom } from '../lib/rooms'
import './FormPage.css'

export default function JoinGamePage() {
  const navigate = useNavigate()
  const [nickname, setNickname] = useState('')
  const [roomCode, setRoomCode] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!nickname.trim() || roomCode.trim().length < 4 || isSubmitting) return
    setIsSubmitting(true)
    setError('')
    try {
      const { room } = await joinRoom(roomCode.trim(), nickname.trim())
      navigate(`/lobby/${room.code}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not join that room.')
      setIsSubmitting(false)
    }
  }

  return (
    <div className="form-page">
      <div className="form-page-header">
        <span className="mono home-tag">JOIN CASE</span>
        <h2>Join a game</h2>
        <p>Ask the host for the room code, then enter it with your nickname.</p>
      </div>

      <form className="glass form-panel" onSubmit={handleSubmit}>
        <FormField
          label="Room code"
          placeholder="e.g. K7QX2M"
          maxLength={6}
          value={roomCode}
          onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
          autoFocus
        />
        <FormField
          label="Your nickname"
          placeholder="e.g. Delta"
          maxLength={16}
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
        />
        {error && <p className="form-error">{error}</p>}
        <PrimaryButton
          fullWidth
          type="submit"
          disabled={!nickname.trim() || roomCode.trim().length < 4 || isSubmitting}
        >
          {isSubmitting ? 'Joining…' : 'Join Room'}
        </PrimaryButton>
        <GhostButton fullWidth type="button" onClick={() => navigate('/')}>
          Back
        </GhostButton>
      </form>
    </div>
  )
}
