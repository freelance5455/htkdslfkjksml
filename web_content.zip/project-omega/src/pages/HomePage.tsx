import { useNavigate } from 'react-router-dom'
import { PrimaryButton, GhostButton } from '../components/Buttons'
import './HomePage.css'
import { isSoundEnabled, isSpookyMode, setSoundEnabled, setSpookyMode } from '../lib/settings'
import { useEffect, useState } from 'react'

export default function HomePage() {
  const navigate = useNavigate()
  const [spooky, setSpooky] = useState(isSpookyMode())
  const [sound, setSound] = useState(isSoundEnabled())
  useEffect(() => { const f = () => { setSpooky(isSpookyMode()); setSound(isSoundEnabled()) }; window.addEventListener('omega-settings', f); return () => window.removeEventListener('omega-settings', f) }, [])

  return (
    <div className="home">
      <div className="home-intro">
        <span className="mono home-tag">CLASSIFIED · INVESTIGATION ACTIVE</span>
        <h2 className="home-headline">
          A drive surfaced that shouldn't exist. One of you knows why.
        </h2>
        <p className="home-sub">
          4–10 players. One Villain hides among the Protectors. Find the truth
          before the drive disappears again.
        </p>
      </div>

      <div className="home-actions glass">
        <PrimaryButton fullWidth onClick={() => navigate('/create')}>
          Create Game
        </PrimaryButton>
        <GhostButton fullWidth onClick={() => navigate('/join')}>
          Join Game
        </GhostButton>
        <GhostButton fullWidth onClick={() => navigate('/demo')}>
          Demo Mode
        </GhostButton>
        <div className="home-actions-row">
          <GhostButton fullWidth onClick={() => navigate('/rejoin')}>
            Rejoin Game
          </GhostButton>
          <GhostButton fullWidth onClick={() => navigate('/how-to-play')}>
            How To Play
          </GhostButton>
        </div>
      </div>
      <div className="home-settings glass">
        <label><input type="checkbox" checked={spooky} onChange={(e) => { setSpookyMode(e.target.checked); setSpooky(e.target.checked) }} /> Spooky Mode</label>
        <label><input type="checkbox" checked={sound} onChange={(e) => { setSoundEnabled(e.target.checked); setSound(e.target.checked) }} /> UI Sounds</label>
      </div>
    </div>
  )
}
