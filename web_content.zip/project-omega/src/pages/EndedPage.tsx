import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useLiveRoom } from '../hooks/useLiveRoom'
import './EndedPage.css'

export default function EndedPage() {
  const { code } = useParams<{ code: string }>()
  const { room, status, errorMessage } = useLiveRoom(code, 'ended')
  const [winner, setWinner] = useState<'protectors' | 'villain' | null>(null)

  useEffect(() => {
    if (!room) return
    // winner is recorded by the final-puzzle RPC in last_round_results.
    const value = room.last_round_results && (room.last_round_results as { winner?: string }).winner
    if (value === 'protectors' || value === 'villain') setWinner(value)
  }, [room])

  if (status === 'loading') return <div className="ended"><p className="lobby-waiting">Loading…</p></div>
  if (status === 'error') return <div className="ended"><p className="lobby-waiting">{errorMessage}</p></div>

  return (
    <div className="ended">
      <span className="mono home-tag">CASE CLOSED</span>
      <h2>{winner === 'villain' ? 'THE VILLAIN WINS' : 'PROTECTORS WIN'}</h2>
      <p>{winner === 'villain' ? 'The final OMEGA protocol remained locked.' : 'The OMEGA protocol has been secured. The case is closed.'}</p>
      <div className="glass ended-card">
        <span className="mono">MYSTERY</span>
        <strong>{room?.mystery ?? 'PROJECT OMEGA'}</strong>
        <span className="mono">ROOM {code}</span>
      </div>
      <Link to="/" className="ended-link">Return Home</Link>
    </div>
  )
}
