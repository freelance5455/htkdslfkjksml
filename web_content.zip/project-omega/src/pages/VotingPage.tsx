import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { PrimaryButton } from '../components/Buttons'
import { useLiveRoom } from '../hooks/useLiveRoom'
import { getRoomPlayers, Player } from '../lib/rooms'
import { castVote, getVoteCount, revealVoteResults } from '../lib/game'
import { getCurrentUserId } from '../lib/auth'
import './VotingPage.css'

export default function VotingPage() {
  const { code } = useParams<{ code: string }>()
  const { room, status, errorMessage: roomError } = useLiveRoom(code, 'voting')
  const [players, setPlayers] = useState<Player[]>([])
  const [myVote, setMyVote] = useState<string | null>(null)
  const [voteCount, setVoteCount] = useState(0)
  const [isVoting, setIsVoting] = useState(false)
  const [isRevealing, setIsRevealing] = useState(false)
  const [error, setError] = useState('')

  const userId = getCurrentUserId()
  const me = players.find((p) => p.user_id === userId)
  const isHost = me?.is_host ?? false

  useEffect(() => {
    if (!room) return
    let cancelled = false
    getRoomPlayers(room.id).then((data) => {
      if (!cancelled) setPlayers(data)
    })
    return () => {
      cancelled = true
    }
  }, [room?.id])

  // A live headcount only ("3 of 6 voted") — individual choices stay
  // private until the host reveals results, by database policy, not just in the UI.
  useEffect(() => {
    if (!room) return
    let cancelled = false

    async function poll() {
      try {
        const count = await getVoteCount(room!.id)
        if (!cancelled) setVoteCount(count)
      } catch {
        // Transient error — the next poll will retry.
      }
    }

    poll()
    const id = window.setInterval(poll, 2000)
    return () => {
      cancelled = true
      window.clearInterval(id)
    }
  }, [room?.id])

  useEffect(() => {
    if (isHost && players.length > 0 && voteCount >= players.length && !isRevealing) {
      setIsRevealing(true)
      revealVoteResults(room!.id).catch(() => setIsRevealing(false))
    }
  }, [voteCount, players.length, isHost, isRevealing, room])

  async function handleVote(suspectId: string) {
    if (!room || isVoting) return
    setIsVoting(true)
    setError('')
    try {
      await castVote(room.id, suspectId)
      setMyVote(suspectId)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not cast your vote.')
    } finally {
      setIsVoting(false)
    }
  }

  async function handleReveal() {
    if (!room || isRevealing) return
    setIsRevealing(true)
    setError('')
    try {
      await revealVoteResults(room.id)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not reveal results.')
      setIsRevealing(false)
    }
  }

  if (status === 'loading') {
    return (
      <div className="voting">
        <p className="lobby-waiting">Loading…</p>
      </div>
    )
  }

  if (status === 'error') {
    return (
      <div className="voting">
        <p className="lobby-waiting">{roomError}</p>
      </div>
    )
  }

  return (
    <div className="voting">
      <div className="voting-header">
        <span className="mono home-tag">VOTE</span>
        <h2>Who do you suspect?</h2>
        <p className="mono lobby-count">
          {voteCount} / {players.length} voted
        </p>
      </div>

      <div className="vote-grid">
        {players
          .filter((p) => p.user_id !== userId)
          .map((p) => (
            <button
              key={p.id}
              className={`glass vote-card ${myVote === p.id ? 'vote-card-selected' : ''}`}
              disabled={isVoting}
              onClick={() => handleVote(p.id)}
            >
              <span>{p.nickname}</span>
              {myVote === p.id && <span className="mono vote-tag">YOUR VOTE</span>}
            </button>
          ))}
      </div>

      {error && <p className="form-error">{error}</p>}

      {isHost ? (
        <PrimaryButton fullWidth disabled={voteCount === 0 || isRevealing} onClick={handleReveal}>
          {isRevealing ? 'Revealing…' : 'Reveal Results'}
        </PrimaryButton>
      ) : (
        <p className="lobby-waiting">Waiting for everyone to vote…</p>
      )}
    </div>
  )
}
