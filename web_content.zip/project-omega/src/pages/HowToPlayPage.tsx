import { useNavigate } from 'react-router-dom'
import { GhostButton } from '../components/Buttons'
import './FormPage.css'

export default function HowToPlayPage() {
  const navigate = useNavigate()

  return (
    <div className="form-page">
      <div className="form-page-header">
        <span className="mono home-tag">BRIEFING</span>
        <h2>How to play</h2>
      </div>

      <div className="glass form-panel">
        <p>4–10 players join a room. One is secretly the Villain; everyone else is a Protector.</p>
        <p>Protectors investigate locations for clues about the missing drive, Project Omega.</p>
        <p>The Villain quietly sabotages the investigation without getting caught.</p>
        <p>After discussion, players vote on who they suspect. Protectors win by exposing the Villain and solving the final puzzle. The Villain wins by completing their objective or stalling the investigation.</p>
        <GhostButton fullWidth onClick={() => navigate('/')}>
          Back
        </GhostButton>
      </div>
    </div>
  )
}
