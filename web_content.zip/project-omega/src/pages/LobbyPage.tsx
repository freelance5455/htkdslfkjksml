import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { GhostButton, PrimaryButton } from '../components/Buttons'
import { useLiveRoom } from '../hooks/useLiveRoom'
import { getRoomPlayers, Player } from '../lib/rooms'
import { subscribeToRoomPlayers } from '../lib/realtime'
import { startGame } from '../lib/game'
import { getCurrentUserId } from '../lib/auth'
import './LobbyPage.css'

function avatarFor(id: string) { const n = [...id].reduce((a,c)=>a+c.charCodeAt(0),0); return ['◉','◇','△','□','○','✦'][n % 6] }

export default function LobbyPage() {
  const { code } = useParams<{ code: string }>()
  const navigate = useNavigate()
  const { room, status, errorMessage: roomError } = useLiveRoom(code, 'lobby')
  const [players, setPlayers] = useState<Player[]>([])
  const [isStarting, setIsStarting] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!room) return
    let cancelled = false
    let unsubscribe: (() => void) | undefined

    getRoomPlayers(room.id).then((initialPlayers) => {
      if (cancelled) return
      setPlayers(initialPlayers)
      unsubscribe = subscribeToRoomPlayers(room.id, initialPlayers, (updated) => {
        if (!cancelled) setPlayers(updated)
      })
    })

    return () => {
      cancelled = true
      unsubscribe?.()
    }
  }, [room?.id])

  const userId = getCurrentUserId()
  const me = players.find((p) => p.user_id === userId)
  const isHost = me?.is_host ?? false

  async function handleStart() {
    if (!room || isStarting) return
    setIsStarting(true)
    setError('')
    try {
      await startGame(room.id)
      // Navigation to the role reveal happens for everyone via useLiveRoom.
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not start the game.')
      setIsStarting(false)
    }
  }

  if (status === 'loading') {
    return (
      <div className="lobby">
        <p className="lobby-waiting">Loading room…</p>
      </div>
    )
  }

  if (status === 'error') {
    return (
      <div className="lobby">
        <p className="lobby-waiting">{roomError}</p>
        <GhostButton fullWidth onClick={() => navigate('/')}>
          Back Home
        </GhostButton>
      </div>
    )
  }

  return (
    <div className="lobby">
      <div className="lobby-header">
        <span className="mono home-tag">ROOM CODE</span>
        <h2 className="lobby-code mono">{room?.code ?? code}</h2>
        <p>Share this code so others can join from the Home screen.</p>
      </div>

      <div className="glass lobby-panel">
        <div className="lobby-panel-title">
          <span>Players</span>
          <span className="mono lobby-count">{players.length} / 10</span>
        </div>
        <ul className="lobby-list">
          {players.map((p) => (
            <li key={p.id} className="lobby-list-item">
              <span className="player-name"><span className="player-avatar" aria-hidden>{avatarFor(p.id)}</span>
                {p.nickname}
                {p.user_id === userId ? ' (you)' : ''}
              </span>
              {p.is_host && <span className="lobby-host-tag">HOST</span>}
            </li>
          ))}
          {players.length === 0 && <li className="lobby-empty">Waiting for players to join…</li>}
        </ul>
      </div>

      {error && <p className="form-error">{error}</p>}

      <div className="lobby-actions">
        {isHost ? (
          <PrimaryButton fullWidth disabled={players.length < 4 || isStarting} onClick={handleStart}>
            {isStarting
              ? 'Starting…'
              : players.length < 4
                ? 'Need 4+ players to start'
                : 'Start Game'}
          </PrimaryButton>
        ) : (
          <p className="lobby-waiting">Waiting for the host to start the game…</p>
        )}
        <GhostButton fullWidth onClick={() => navigate('/')}>
          Leave Room
        </GhostButton>
      </div>
    </div>
  )
}
