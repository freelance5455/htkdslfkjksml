import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { GhostButton, PrimaryButton } from '../components/Buttons'
import { SCENARIOS } from '../lib/scenarios'
import { playUiBeep } from '../lib/settings'
import './DemoPage.css'

const names = ['Nova','Cipher','Echo','Rook','Pixel','Atlas','Mira','Volt','Quill']

export default function DemoPage() {
  const navigate = useNavigate()
  const [scenario, setScenario] = useState(SCENARIOS[0].title)
  const [phase, setPhase] = useState<'briefing'|'investigation'|'discussion'|'vote'|'ending'>('briefing')
  const [score, setScore] = useState(0)
  const [clue, setClue] = useState('No clue recovered yet.')
  const villain = useMemo(() => names[Math.floor(Math.random() * 4)], [])
  const [suspect, setSuspect] = useState('')

  function next() {
    playUiBeep('click')
    setPhase(p => p === 'briefing' ? 'investigation' : p === 'investigation' ? 'discussion' : p === 'discussion' ? 'vote' : p === 'vote' ? 'ending' : 'ending')
  }
  function investigate() {
    const clues = ['A timestamp repeats at exactly 02:14.','A sealed cabinet has fresh dust marks.','A badge log conflicts with the visitor record.','A monitor shows a transmission that was never archived.']
    setClue(clues[Math.floor(Math.random()*clues.length)]); setScore(v => v + 1); playUiBeep('success')
  }

  return <div className="demo">
    <div className="demo-head"><span className="mono home-tag">OFFLINE SIMULATION</span><h2>{scenario}</h2><p>Practice the OMEGA game loop with fictional players. Nothing is saved online.</p></div>
    <div className="glass demo-status"><span className="mono">PHASE</span><strong>{phase.toUpperCase()}</strong><span className="mono">CLUES {score}</span></div>
    {phase === 'briefing' && <div className="glass demo-card"><h3>Players</h3><p>{names.slice(0,6).join(' · ')}</p><p className="demo-note">One of the simulated players is secretly the Villain.</p><PrimaryButton fullWidth onClick={next}>Start Simulation</PrimaryButton></div>}
    {phase === 'investigation' && <div className="glass demo-card"><h3>Investigate</h3><p>Search a location for fictional evidence.</p><div className="demo-grid">{['Archive','Lab','Signal Room','Storage'].map(x => <button key={x} onClick={investigate}>{x}</button>)}</div><div className="demo-clue">{clue}</div><PrimaryButton fullWidth onClick={next}>Call Discussion</PrimaryButton></div>}
    {phase === 'discussion' && <div className="glass demo-card"><h3>Discussion</h3><p>Compare the evidence and decide who looks suspicious.</p><div className="demo-grid">{names.slice(0,6).map(x => <button key={x} onClick={() => setSuspect(x)} className={suspect===x?'selected':''}>{x}</button>)}</div><PrimaryButton fullWidth disabled={!suspect} onClick={next}>Vote {suspect || '—'}</PrimaryButton></div>}
    {phase === 'vote' && <div className="glass demo-card"><h3>Vote Results</h3><p>The simulated group votes for <strong>{suspect || 'nobody'}</strong>.</p><p className="demo-note">The simulation villain is <strong>{villain}</strong>.</p><PrimaryButton fullWidth onClick={next}>Reveal Outcome</PrimaryButton></div>}
    {phase === 'ending' && <div className="glass demo-card"><span className="mono home-tag">SIMULATION COMPLETE</span><h3>{suspect === villain ? 'PROTECTORS WIN' : 'VILLAIN WINS'}</h3><p>This demo is only a local practice mode.</p><PrimaryButton fullWidth onClick={() => { setPhase('briefing'); setSuspect(''); setScore(0) }}>Play Again</PrimaryButton></div>}
    <GhostButton fullWidth onClick={() => navigate('/')}>Back Home</GhostButton>
  </div>
}
