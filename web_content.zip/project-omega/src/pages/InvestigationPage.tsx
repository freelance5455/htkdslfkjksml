import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { GhostButton, PrimaryButton } from '../components/Buttons'
import { useLiveRoom } from '../hooks/useLiveRoom'
import { getRoomPlayers } from '../lib/rooms'
import {
  getMyRole,
  getMyClues,
  investigateLocation,
  sabotageLocation,
  startDiscussion,
  PlayerClue,
  Role,
} from '../lib/game'
import { getCurrentUserId } from '../lib/auth'
import { LOCATIONS } from '../lib/locations'
import './InvestigationPage.css'

type LatestResult = { location: string; content: string }

export default function InvestigationPage() {
  const { code } = useParams<{ code: string }>()
  const { room, status: roomStatus, errorMessage: roomError } = useLiveRoom(code, 'in_progress')
  const [role, setRole] = useState<Role | null>(null)
  const [sabotagesRemaining, setSabotagesRemaining] = useState(0)
  const [clues, setClues] = useState<PlayerClue[]>([])
  const [isHost, setIsHost] = useState(false)
  const [dataStatus, setDataStatus] = useState<'loading' | 'ready' | 'error'>('loading')
  const [errorMessage, setErrorMessage] = useState('')
  const [busyLocation, setBusyLocation] = useState<string | null>(null)
  const [latestResult, setLatestResult] = useState<LatestResult | null>(null)
  const [isEndingInvestigation, setIsEndingInvestigation] = useState(false)

  useEffect(() => {
    if (!room) return
    let cancelled = false

    async function load() {
      try {
        const userId = getCurrentUserId()
        const [myRole, myClues, players] = await Promise.all([
          getMyRole(room!.id),
          getMyClues(room!.id),
          getRoomPlayers(room!.id),
        ])
        if (cancelled) return
        setRole(myRole?.role ?? null)
        setSabotagesRemaining(myRole?.sabotages_remaining ?? 0)
        setClues(myClues)
        setIsHost(players.some((p) => p.user_id === userId && p.is_host))
        setDataStatus('ready')
      } catch (err) {
        if (cancelled) return
        setErrorMessage(err instanceof Error ? err.message : 'Something went wrong.')
        setDataStatus('error')
      }
    }

    load()
    return () => {
      cancelled = true
    }
  }, [room?.id])

  async function handleInvestigate(location: string) {
    if (!room || busyLocation) return
    setBusyLocation(location)
    try {
      const result = await investigateLocation(room.id, location)
      setLatestResult({ location, content: result.content })
      if (result.clue_id) {
        setClues((prev) => [
          ...prev,
          { id: result.clue_id!, location, content: result.content, found_at: new Date().toISOString() },
        ])
      }
    } catch (err) {
      setLatestResult({ location, content: err instanceof Error ? err.message : 'Something went wrong.' })
    } finally {
      setBusyLocation(null)
    }
  }

  async function handleSabotage(location: string) {
    if (!room || busyLocation) return
    setBusyLocation(location)
    try {
      const remaining = await sabotageLocation(room.id, location)
      setSabotagesRemaining(remaining)
    } catch (err) {
      setLatestResult({ location, content: err instanceof Error ? err.message : 'Could not sabotage.' })
    } finally {
      setBusyLocation(null)
    }
  }

  async function handleCallDiscussion() {
    if (!room || isEndingInvestigation) return
    setIsEndingInvestigation(true)
    try {
      await startDiscussion(room.id)
      // Navigation to Discussion happens for everyone via useLiveRoom.
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Could not start discussion.')
      setIsEndingInvestigation(false)
    }
  }

  if (roomStatus === 'loading' || dataStatus === 'loading') {
    return (
      <div className="investigation">
        <p className="lobby-waiting">Loading…</p>
      </div>
    )
  }

  if (roomStatus === 'error' || dataStatus === 'error') {
    return (
      <div className="investigation">
        <p className="lobby-waiting">{roomError || errorMessage}</p>
      </div>
    )
  }

  return (
    <div className="investigation">
      <div className="investigation-header">
        <span className="mono home-tag">{role === 'villain' ? 'SABOTAGE AVAILABLE' : 'INVESTIGATION ACTIVE'}</span>
        <h2>Choose a location</h2>
        {role === 'villain' && (
          <p>
            You have {sabotagesRemaining} sabotage {sabotagesRemaining === 1 ? 'action' : 'actions'} left. No one
            else can see you use them.
          </p>
        )}
      </div>

      <div className="location-grid">
        {LOCATIONS.map((loc) => (
          <div key={loc} className="glass location-card">
            <h3>{loc}</h3>
            <PrimaryButton fullWidth disabled={busyLocation === loc} onClick={() => handleInvestigate(loc)}>
              {busyLocation === loc ? 'Searching…' : 'Investigate'}
            </PrimaryButton>
            {role === 'villain' && (
              <GhostButton
                fullWidth
                disabled={busyLocation === loc || sabotagesRemaining <= 0}
                onClick={() => handleSabotage(loc)}
              >
                Sabotage
              </GhostButton>
            )}
          </div>
        ))}
        <div className="glass location-card location-locked">
          <h3>CONTROL ROOM</h3>
          <p className="mono location-locked-tag">LOCKED</p>
        </div>
      </div>

      {latestResult && (
        <div className="glass result-panel">
          <span className="mono home-tag">{latestResult.location}</span>
          <p>{latestResult.content}</p>
        </div>
      )}

      <div className="glass case-log">
        <div className="lobby-panel-title">
          <span>Case Log</span>
          <span className="mono lobby-count">{clues.length} found</span>
        </div>
        <ul className="lobby-list">
          {clues.map((c) => (
            <li key={c.id} className="lobby-list-item case-log-item">
              <span className="mono case-log-location">{c.location}</span>
              <span>{c.content}</span>
            </li>
          ))}
          {clues.length === 0 && <li className="lobby-empty">No clues found yet.</li>}
        </ul>
      </div>

      {isHost ? (
        <PrimaryButton fullWidth disabled={isEndingInvestigation} onClick={handleCallDiscussion}>
          {isEndingInvestigation ? 'Starting…' : 'Call Everyone to Discuss'}
        </PrimaryButton>
      ) : (
        <p className="lobby-waiting">The host can call the group to discuss at any time.</p>
      )}
    </div>
  )
}
