import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { PrimaryButton } from '../components/Buttons'
import { useLiveRoom } from '../hooks/useLiveRoom'
import { getRoomPlayers } from '../lib/rooms'
import { continueInvestigation } from '../lib/game'
import { getCurrentUserId } from '../lib/auth'
import './ResultsPage.css'

export default function ResultsPage() {
  const { code } = useParams<{ code: string }>()
  const { room, status, errorMessage } = useLiveRoom(code, 'results')
  const [isHost, setIsHost] = useState(false)
  const [isContinuing, setIsContinuing] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!room) return
    let cancelled = false
    getRoomPlayers(room.id).then((players) => {
      if (cancelled) return
      const userId = getCurrentUserId()
      setIsHost(players.some((p) => p.user_id === userId && p.is_host))
    })
    return () => {
      cancelled = true
    }
  }, [room?.id])

  async function handleContinue() {
    if (!room || isContinuing) return
    setIsContinuing(true)
    setError('')
    try {
      await continueInvestigation(room.id)
      // A wrong accusation returns to investigation. A correct accusation
      // moves to the final puzzle automatically through the room status.
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not continue.')
      setIsContinuing(false)
    }
  }

  if (status === 'loading') {
    return (
      <div className="results">
        <p className="lobby-waiting">Loading…</p>
      </div>
    )
  }

  if (status === 'error') {
    return (
      <div className="results">
        <p className="lobby-waiting">{errorMessage}</p>
      </div>
    )
  }

  const results = room?.last_round_results
  const correct = results?.accused_was_villain === true

  return (
    <div className="results">
      <div className="results-header">
        <span className="mono home-tag">VOTE RESULTS</span>
        <h2>
          {!results?.accused_player_id
            ? 'No consensus'
            : results.accused_was_villain
              ? `${results.accused_nickname} was THE VILLAIN`
              : `${results.accused_nickname} was innocent`}
        </h2>
        <p>
          {!results?.accused_player_id
            ? 'The vote was tied, so no one was accused this round.'
            : correct
              ? 'The Villain is exposed. The OMEGA control protocol is now unlocked.'
              : 'A wrong accusation gives the Villain an edge — they just gained extra sabotage actions.'}
        </p>
      </div>

      <div className="glass results-tally">
        <div className="lobby-panel-title">
          <span>Votes</span>
        </div>
        <ul className="lobby-list">
          {results?.tally.map((t) => (
            <li key={t.player_id} className="lobby-list-item">
              <span>
                {t.nickname}
                {t.player_id === results.accused_player_id ? ' (accused)' : ''}
              </span>
              <span className="mono">{t.votes}</span>
            </li>
          ))}
        </ul>
      </div>

      {error && <p className="form-error">{error}</p>}

      {correct ? (
        <div className="glass results-next">
          <span className="mono home-tag">NEXT PHASE</span>
          <p>All players will be sent to the final OMEGA control puzzle.</p>
        </div>
      ) : isHost ? (
        <PrimaryButton fullWidth disabled={isContinuing} onClick={handleContinue}>
          {isContinuing ? 'Continuing…' : 'Continue Investigating'}
        </PrimaryButton>
      ) : (
        <p className="lobby-waiting">Waiting for the host to continue…</p>
      )}
    </div>
  )
}
