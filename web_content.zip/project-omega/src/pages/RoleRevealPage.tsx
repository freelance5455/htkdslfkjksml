import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { PrimaryButton } from '../components/Buttons'
import { getRoomByCode } from '../lib/rooms'
import { getMyRole, Role } from '../lib/game'
import './RoleRevealPage.css'

export default function RoleRevealPage() {
  const { code } = useParams<{ code: string }>()
  const navigate = useNavigate()
  const [role, setRole] = useState<Role | null>(null)
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading')
  const [errorMessage, setErrorMessage] = useState('')
  const [revealed, setRevealed] = useState(false)

  useEffect(() => {
    if (!code) return
    let cancelled = false

    async function load() {
      try {
        const room = await getRoomByCode(code!)
        const myRole = await getMyRole(room.id)
        if (cancelled) return
        if (!myRole) throw new Error('Your role has not been assigned yet.')
        setRole(myRole.role)
        setStatus('ready')
      } catch (err) {
        if (cancelled) return
        setErrorMessage(err instanceof Error ? err.message : 'Something went wrong.')
        setStatus('error')
      }
    }

    load()
    return () => {
      cancelled = true
    }
  }, [code])

  if (status === 'loading') {
    return (
      <div className="reveal">
        <p className="lobby-waiting">Loading your assignment…</p>
      </div>
    )
  }

  if (status === 'error') {
    return (
      <div className="reveal">
        <p className="lobby-waiting">{errorMessage}</p>
      </div>
    )
  }

  return (
    <div className="reveal">
      {!revealed ? (
        <button className="glass reveal-card" onClick={() => setRevealed(true)}>
          <span className="mono home-tag">SEALED ASSIGNMENT</span>
          <h2>Tap to reveal your role</h2>
          <p>Only you will see this. Keep it that way.</p>
        </button>
      ) : (
        <div className={`glass reveal-card revealed reveal-${role}`}>
          <span className="mono home-tag">YOUR ROLE</span>
          <h2 className="reveal-role">{role === 'villain' ? 'THE VILLAIN' : 'A PROTECTOR'}</h2>
          <p>
            {role === 'villain'
              ? 'Blend in. Investigate like everyone else, but quietly sabotage locations to slow the truth down.'
              : 'Investigate the locations, gather real evidence, and work out who the Villain is before it\u2019s too late.'}
          </p>
          <PrimaryButton fullWidth onClick={() => navigate(`/investigate/${code}`)}>
            Begin Investigation
          </PrimaryButton>
        </div>
      )}
    </div>
  )
}
