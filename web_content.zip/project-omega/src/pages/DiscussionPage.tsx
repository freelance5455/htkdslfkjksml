import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { GhostButton } from '../components/Buttons'
import { useLiveRoom } from '../hooks/useLiveRoom'
import { getRoomClues, startVoting, RoomClue } from '../lib/game'
import './DiscussionPage.css'

const DISCUSSION_SECONDS = 60

export default function DiscussionPage() {
  const { code } = useParams<{ code: string }>()
  const { room, status, errorMessage } = useLiveRoom(code, 'discussion')
  const [clues, setClues] = useState<RoomClue[]>([])
  const [cluesLoaded, setCluesLoaded] = useState(false)
  const [secondsLeft, setSecondsLeft] = useState(DISCUSSION_SECONDS)
  const [advancing, setAdvancing] = useState(false)

  useEffect(() => {
    if (!room) return
    let cancelled = false
    getRoomClues(room.id).then((data) => {
      if (!cancelled) {
        setClues(data)
        setCluesLoaded(true)
      }
    })
    return () => {
      cancelled = true
    }
  }, [room?.id])

  // Timer is derived from a server timestamp rather than counted locally, so
  // it reads the same on every device even if a page loaded a moment late.
  useEffect(() => {
    if (!room?.discussion_started_at) return
    const startedAt = new Date(room.discussion_started_at).getTime()

    function tick() {
      const elapsed = Math.floor((Date.now() - startedAt) / 1000)
      setSecondsLeft(Math.max(0, DISCUSSION_SECONDS - elapsed))
    }

    tick()
    const id = window.setInterval(tick, 1000)
    return () => window.clearInterval(id)
  }, [room?.discussion_started_at])

  useEffect(() => {
    if (secondsLeft === 0 && room && !advancing) {
      setAdvancing(true)
      startVoting(room.id).catch(() => {
        // Harmless if another device already advanced the room first.
      })
    }
  }, [secondsLeft, room, advancing])

  async function handleSkip() {
    if (!room) return
    setAdvancing(true)
    try {
      await startVoting(room.id)
    } catch {
      setAdvancing(false)
    }
  }

  if (status === 'loading') {
    return (
      <div className="discussion">
        <p className="lobby-waiting">Loading…</p>
      </div>
    )
  }

  if (status === 'error') {
    return (
      <div className="discussion">
        <p className="lobby-waiting">{errorMessage}</p>
      </div>
    )
  }

  const minutes = String(Math.floor(secondsLeft / 60)).padStart(2, '0')
  const seconds = String(secondsLeft % 60).padStart(2, '0')

  return (
    <div className="discussion">
      <div className="discussion-header">
        <span className="mono home-tag">DISCUSSION</span>
        <h2 className="discussion-timer mono">
          {minutes}:{seconds}
        </h2>
        <p>Talk it out — in person or on a call. Here's everything the group has found so far.</p>
      </div>

      <div className="glass evidence-panel">
        <div className="lobby-panel-title">
          <span>Public Evidence</span>
          <span className="mono lobby-count">{clues.length}</span>
        </div>
        <ul className="lobby-list">
          {cluesLoaded &&
            clues.map((c) => (
              <li key={c.id} className="lobby-list-item case-log-item">
                <span className="mono case-log-location">
                  {c.location} · {c.players?.nickname ?? 'Unknown'}
                </span>
                <span>{c.content}</span>
              </li>
            ))}
          {cluesLoaded && clues.length === 0 && (
            <li className="lobby-empty">No clues were found this round.</li>
          )}
        </ul>
      </div>

      <GhostButton fullWidth onClick={handleSkip} disabled={advancing}>
        {advancing ? 'Moving to vote…' : 'Skip to Voting'}
      </GhostButton>
    </div>
  )
}
