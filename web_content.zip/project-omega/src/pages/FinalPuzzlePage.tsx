import { FormEvent, useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { PrimaryButton } from '../components/Buttons'
import { useLiveRoom } from '../hooks/useLiveRoom'
import { getFinalPuzzle, submitFinalPuzzle } from '../lib/game'
import './FinalPuzzlePage.css'

export default function FinalPuzzlePage() {
  const { code } = useParams<{ code: string }>()
  const { room, status, errorMessage } = useLiveRoom(code, 'final_puzzle')
  const [prompt, setPrompt] = useState('')
  const [attempts, setAttempts] = useState(3)
  const [answer, setAnswer] = useState('')
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    if (!room) return
    let cancelled = false
    getFinalPuzzle(room.id).then((data) => {
      if (cancelled) return
      if (data) {
        setPrompt(data.prompt)
        setAttempts(data.attempts_remaining)
      }
      setLoading(false)
    }).catch((err) => {
      if (cancelled) return
      setError(err instanceof Error ? err.message : 'Could not load the puzzle.')
      setLoading(false)
    })
    return () => { cancelled = true }
  }, [room?.id])

  async function handleSubmit(event: FormEvent) {
    event.preventDefault()
    if (!room || submitting || !answer.trim() || attempts <= 0) return
    const numericAnswer = Number(answer.trim())
    if (!Number.isInteger(numericAnswer)) {
      setError('Enter a whole-number answer.')
      return
    }
    setSubmitting(true)
    setError('')
    setMessage('')
    try {
      const result = await submitFinalPuzzle(room.id, numericAnswer)
      setAttempts(result.attempts_remaining)
      if (result.correct) {
        setMessage('Correct. The OMEGA protocol is unlocked.')
      } else if (result.attempts_remaining > 0) {
        setMessage(`Not quite. ${result.attempts_remaining} attempt${result.attempts_remaining === 1 ? '' : 's'} remaining.`)
      } else {
        setMessage('The final protocol locked. The Villain wins.')
      }
      setAnswer('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not submit the answer.')
    } finally {
      setSubmitting(false)
    }
  }

  if (status === 'loading' || loading) return <div className="puzzle"><p className="lobby-waiting">Loading…</p></div>
  if (status === 'error') return <div className="puzzle"><p className="lobby-waiting">{errorMessage}</p></div>

  return (
    <div className="puzzle">
      <div className="puzzle-header">
        <span className="mono home-tag">CONTROL ROOM UNLOCKED</span>
        <h2>Final OMEGA Protocol</h2>
        <p>The Villain has been exposed. Solve the last fictional control puzzle before the protocol locks.</p>
      </div>

      <div className="glass puzzle-card">
        <div className="lobby-panel-title">
          <span>ENCRYPTED TERMINAL</span>
          <span className="mono lobby-count">{attempts} attempts</span>
        </div>
        <p className="puzzle-prompt">{prompt}</p>
        <form onSubmit={handleSubmit} className="puzzle-form">
          <label htmlFor="answer" className="mono puzzle-label">ENTER FINAL CODE</label>
          <input
            id="answer"
            inputMode="numeric"
            autoComplete="off"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            disabled={submitting || attempts <= 0}
            placeholder="?"
          />
          <PrimaryButton fullWidth disabled={submitting || attempts <= 0 || !answer.trim()}>
            {submitting ? 'Checking…' : 'Unlock Protocol'}
          </PrimaryButton>
        </form>
      </div>

      {message && <div className="glass puzzle-message">{message}</div>}
      {error && <p className="form-error">{error}</p>}
    </div>
  )
}
