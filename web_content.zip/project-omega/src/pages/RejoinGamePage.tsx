import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { GhostButton, PrimaryButton } from '../components/Buttons'
import { forgetRememberedRoom, getRememberedRoomCode, rejoinLastGame } from '../lib/rooms'
import './FormPage.css'

export default function RejoinGamePage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [roomCode, setRoomCode] = useState<string | null>(null)

  useEffect(() => {
    setRoomCode(getRememberedRoomCode())
    setLoading(false)
  }, [])

  async function handleRejoin() {
    setLoading(true)
    setError('')
    try {
      const result = await rejoinLastGame()
      if (!result) {
        setError('No active game session was found on this device.')
        return
      }
      navigate(`/lobby/${result.room.code}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not restore your game.')
    } finally {
      setLoading(false)
    }
  }

  function handleForget() {
    forgetRememberedRoom()
    setRoomCode(null)
    setError('')
  }

  return (
    <div className="form-page">
      <div className="form-page-header">
        <span className="mono home-tag">RECONNECT</span>
        <h2>Rejoin a game</h2>
        <p>Your player identity is saved on this device, so refreshing or reopening the browser can restore your latest game.</p>
      </div>
      <div className="glass form-panel">
        {roomCode ? (
          <>
            <p className="mono">LAST ROOM: {roomCode}</p>
            {error && <p className="form-error">{error}</p>}
            <PrimaryButton fullWidth disabled={loading} onClick={handleRejoin}>
              {loading ? 'Restoring…' : 'Rejoin Game'}
            </PrimaryButton>
            <GhostButton fullWidth onClick={handleForget} disabled={loading}>
              Forget This Game
            </GhostButton>
          </>
        ) : (
          <>
            <p className="lobby-waiting">No saved game was found on this device.</p>
            <GhostButton fullWidth onClick={() => navigate('/')}>Back</GhostButton>
          </>
        )}
      </div>
    </div>
  )
}
