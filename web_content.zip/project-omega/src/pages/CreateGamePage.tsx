import { FormEvent, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import FormField from '../components/FormField'
import { PrimaryButton, GhostButton } from '../components/Buttons'
import { createRoom, setRoomScenario } from '../lib/rooms'
import { SCENARIOS } from '../lib/scenarios'
import './FormPage.css'

export default function CreateGamePage() {
  const navigate = useNavigate()
  const [nickname, setNickname] = useState('')
  const [scenario, setScenario] = useState(SCENARIOS[0].id)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!nickname.trim() || isSubmitting) return
    setIsSubmitting(true)
    setError('')
    try {
      const { room } = await createRoom(nickname.trim())
      await setRoomScenario(room.id, scenario)
      navigate(`/lobby/${room.code}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create the room.')
      setIsSubmitting(false)
    }
  }

  return (
    <div className="form-page">
      <div className="form-page-header">
        <span className="mono home-tag">NEW CASE</span>
        <h2>Create a game</h2>
        <p>You'll get a 6-character room code to share with the other players.</p>
      </div>

      <form className="glass form-panel" onSubmit={handleSubmit}>
        <label className="scenario-field">
          <span className="mono scenario-label">CASE SCENARIO</span>
          <select value={scenario} onChange={(e) => setScenario(e.target.value)}>
            {SCENARIOS.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}
          </select>
          <span className="scenario-help">{SCENARIOS.find((item) => item.id === scenario)?.description}</span>
        </label>
        <FormField
          label="Your nickname"
          placeholder="e.g. Foxtrot"
          maxLength={16}
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          autoFocus
        />
        {error && <p className="form-error">{error}</p>}
        <PrimaryButton fullWidth type="submit" disabled={!nickname.trim() || isSubmitting}>
          {isSubmitting ? 'Creating…' : 'Create Room'}
        </PrimaryButton>
        <GhostButton fullWidth type="button" onClick={() => navigate('/')}>
          Back
        </GhostButton>
      </form>
    </div>
  )
}
