import { supabase } from './supabaseClient'
import type { FinalPuzzle } from './rooms'

export type Role = 'villain' | 'protector'

export type MyRole = {
  role: Role
  sabotages_remaining: number
}

export type PlayerClue = {
  id: string
  location: string
  content: string
  found_at: string
}

export async function startGame(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('start_game', { target_room_id: roomId })
  if (error) throw new Error(error.message)
}

/** Returns only the calling player's own role — the database enforces this, not this function. */
export async function getMyRole(roomId: string): Promise<MyRole | null> {
  const { data, error } = await supabase
    .from('player_roles')
    .select('role, sabotages_remaining')
    .eq('room_id', roomId)
    .maybeSingle()

  if (error) throw new Error(error.message)
  return data
}

/** Returns the calling player's own results only until discussion starts, then everyone's — enforced by RLS, not this function. */
export async function getMyClues(roomId: string): Promise<PlayerClue[]> {
  const { data, error } = await supabase
    .from('player_clues')
    .select('id, location, content, found_at')
    .eq('room_id', roomId)
    .order('found_at', { ascending: true })

  if (error) throw new Error(error.message)
  return data
}

export type RoomClue = {
  id: string
  location: string
  content: string
  found_at: string
  players: { nickname: string } | null
}

/** The pooled "public evidence" board — only returns rows once the room has reached discussion or later. */
export async function getRoomClues(roomId: string): Promise<RoomClue[]> {
  const { data, error } = await supabase
    .from('player_clues')
    .select('id, location, content, found_at, players(nickname)')
    .eq('room_id', roomId)
    .order('found_at', { ascending: true })

  if (error) throw new Error(error.message)
  return data as unknown as RoomClue[]
}

export async function startDiscussion(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('start_discussion', { target_room_id: roomId })
  if (error) throw new Error(error.message)
}

export async function startVoting(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('start_voting', { target_room_id: roomId })
  if (error) throw new Error(error.message)
}

export async function castVote(roomId: string, suspectPlayerId: string): Promise<void> {
  const { error } = await supabase.rpc('cast_vote', {
    target_room_id: roomId,
    target_suspect_player_id: suspectPlayerId,
  })
  if (error) throw new Error(error.message)
}

export async function getVoteCount(roomId: string): Promise<number> {
  const { data, error } = await supabase.rpc('get_vote_count', { target_room_id: roomId })
  if (error) throw new Error(error.message)
  return data
}

export async function revealVoteResults(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('reveal_vote_results', { target_room_id: roomId })
  if (error) throw new Error(error.message)
}

export async function continueInvestigation(roomId: string): Promise<void> {
  const { error } = await supabase.rpc('continue_investigation', { target_room_id: roomId })
  if (error) throw new Error(error.message)
}

export async function investigateLocation(
  roomId: string,
  location: string,
): Promise<{ clue_id: string | null; content: string }> {
  const { data, error } = await supabase.rpc('investigate_location', {
    target_room_id: roomId,
    target_location: location,
  })
  if (error) throw new Error(error.message)
  const row = Array.isArray(data) ? data[0] : data
  return row
}

/** Returns the villain's remaining sabotage uses after this call. */
export async function sabotageLocation(roomId: string, location: string): Promise<number> {
  const { data, error } = await supabase.rpc('sabotage_location', {
    target_room_id: roomId,
    target_location: location,
  })
  if (error) throw new Error(error.message)
  return data
}


export async function getFinalPuzzle(roomId: string): Promise<FinalPuzzle | null> {
  const { data, error } = await supabase.rpc('get_final_puzzle', { target_room_id: roomId })
  if (error) throw new Error(error.message)
  const row = Array.isArray(data) ? data[0] : data
  return row ?? null
}

export async function submitFinalPuzzle(roomId: string, answer: number): Promise<{ correct: boolean; attempts_remaining: number }> {
  const { data, error } = await supabase.rpc('submit_final_puzzle', {
    target_room_id: roomId,
    submitted_answer: answer,
  })
  if (error) throw new Error(error.message)
  const row = Array.isArray(data) ? data[0] : data
  return row
}
