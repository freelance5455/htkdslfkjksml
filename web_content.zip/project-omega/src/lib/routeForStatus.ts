import type { Room } from './rooms'

export function routeForRoomStatus(code: string, status: Room['status']): string {
  switch (status) {
    case 'lobby':
      return `/lobby/${code}`
    case 'in_progress':
      return `/investigate/${code}`
    case 'discussion':
      return `/discuss/${code}`
    case 'voting':
      return `/vote/${code}`
    case 'results':
      return `/results/${code}`
    case 'final_puzzle':
      return `/puzzle/${code}`
    case 'ended':
      return `/ended/${code}`
    default:
      return `/lobby/${code}`
  }
}
