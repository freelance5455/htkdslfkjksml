import { supabase } from './supabaseClient'
import type { Player, Room } from './rooms'
// Player rows no longer carry role data (see player_roles / game.ts),
// so streaming full player rows here is safe.

/**
 * Subscribes to live changes on the players table for one room. Keeps an
 * internal copy of the player list in sync and calls `onChange` with the
 * full updated array every time a player joins, leaves, or is updated.
 *
 * Call the returned function to unsubscribe (always do this in a cleanup
 * effect, or the subscription leaks when the component unmounts).
 */
export function subscribeToRoomPlayers(
  roomId: string,
  initialPlayers: Player[],
  onChange: (players: Player[]) => void,
): () => void {
  let players = [...initialPlayers]

  const channel = supabase
    .channel(`room-players-${roomId}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'players', filter: `room_id=eq.${roomId}` },
      (payload) => {
        if (payload.eventType === 'INSERT') {
          const newPlayer = payload.new as Player
          if (!players.some((p) => p.id === newPlayer.id)) {
            players = [...players, newPlayer].sort(
              (a, b) => new Date(a.joined_at).getTime() - new Date(b.joined_at).getTime(),
            )
          }
        } else if (payload.eventType === 'UPDATE') {
          const updated = payload.new as Player
          players = players.map((p) => (p.id === updated.id ? updated : p))
        } else if (payload.eventType === 'DELETE') {
          const removed = payload.old as Player
          players = players.filter((p) => p.id !== removed.id)
        }
        onChange(players)
      },
    )
    .subscribe()

  return () => {
    supabase.removeChannel(channel)
  }
}

/**
 * Subscribes to changes on a single room row (e.g. status flipping from
 * 'lobby' to 'in_progress' when the host starts the game in a later phase).
 */
export function subscribeToRoom(roomId: string, onChange: (room: Room) => void): () => void {
  const channel = supabase
    .channel(`room-${roomId}`)
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'rooms', filter: `id=eq.${roomId}` },
      (payload) => onChange(payload.new as Room),
    )
    .subscribe()

  return () => {
    supabase.removeChannel(channel)
  }
}
