const SPOOKY_KEY = 'omega:spooky'
const SOUND_KEY = 'omega:sound'

export function isSpookyMode(): boolean { return window.localStorage.getItem(SPOOKY_KEY) === '1' }
export function setSpookyMode(value: boolean) { window.localStorage.setItem(SPOOKY_KEY, value ? '1' : '0'); window.dispatchEvent(new Event('omega-settings')) }
export function isSoundEnabled(): boolean { return window.localStorage.getItem(SOUND_KEY) !== '0' }
export function setSoundEnabled(value: boolean) { window.localStorage.setItem(SOUND_KEY, value ? '1' : '0'); window.dispatchEvent(new Event('omega-settings')) }

export function playUiBeep(kind: 'click'|'warning'|'success' = 'click') {
  if (!isSoundEnabled()) return
  try {
    const Ctx = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!Ctx) return
    const ctx = new Ctx()
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    const freq = kind === 'success' ? 660 : kind === 'warning' ? 180 : 420
    osc.frequency.value = freq
    osc.type = 'sine'
    gain.gain.setValueAtTime(0.0001, ctx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.035, ctx.currentTime + 0.01)
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.09)
    osc.connect(gain).connect(ctx.destination)
    osc.start()
    osc.stop(ctx.currentTime + 0.1)
    window.setTimeout(() => void ctx.close(), 150)
  } catch { /* audio is optional */ }
}
