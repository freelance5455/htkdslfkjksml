import { supabase } from './supabaseClient'
import { generateRoomCode } from './roomCode'
import { getCurrentUserId } from './auth'

export type Room = {
  id: string
  code: string
  status: 'lobby' | 'in_progress' | 'discussion' | 'voting' | 'results' | 'final_puzzle' | 'ended'
  mystery: string | null
  sabotaged_locations: string[]
  discussion_started_at: string | null
  villain_exposed: boolean
  last_round_results: VoteResults | null
  created_at: string
}

export type VoteTally = { player_id: string; nickname: string; votes: number }

export type VoteResults = {
  tally: VoteTally[]
  accused_player_id: string | null
  accused_nickname: string | null
  accused_was_villain: boolean | null
}

export type FinalPuzzle = {
  prompt: string
  attempts_remaining: number
}

export type Player = {
  id: string
  user_id: string
  nickname: string
  is_host: boolean
  is_connected: boolean
  joined_at: string
}

const MAX_PLAYERS = 10
const ROOM_CODE_COLLISION = '23505' // Postgres unique-violation error code

export async function createRoom(nickname: string): Promise<{ room: Room; player: Player }> {
  const { data, error } = await supabase.rpc('create_room', { player_nickname: nickname })
  if (error) throw new Error(error.message)
  const row = Array.isArray(data) ? data[0] : data
  if (!row?.room_id || !row?.player_id) throw new Error('Could not create the room.')

  const room = await getRoomById(row.room_id)
  const player = await getPlayerById(row.player_id)
  rememberLastRoom(room.code)
  return { room, player }
}

export async function joinRoom(code: string, nickname: string): Promise<{ room: Room; player: Player }> {
  const { data, error } = await supabase.rpc('join_room', {
    room_code: code.toUpperCase(),
    player_nickname: nickname,
  })
  if (error) throw new Error(error.message)
  const row = Array.isArray(data) ? data[0] : data
  if (!row?.room_id || !row?.player_id) throw new Error('Could not join that room.')

  const room = await getRoomById(row.room_id)
  const player = await getPlayerById(row.player_id)
  rememberLastRoom(room.code)
  return { room, player }
}

export async function rejoinLastGame(): Promise<{ room: Room; player: Player } | null> {
  const { data, error } = await supabase.rpc('rejoin_last_game')
  if (error) throw new Error(error.message)
  const row = Array.isArray(data) ? data[0] : data
  if (!row?.room_id || !row?.player_id) return null

  const room = await getRoomById(row.room_id)
  const player = await getPlayerById(row.player_id)
  rememberLastRoom(room.code)
  return { room, player }
}

export async function setRoomScenario(roomId: string, scenario: string): Promise<void> {
  const { error } = await supabase.rpc('set_room_scenario', { target_room_id: roomId, target_scenario: scenario })
  if (error) throw new Error(error.message)
}

export async function setPlayerConnected(roomId: string, connected: boolean): Promise<void> {
  const { error } = await supabase.rpc('set_player_connected', {
    target_room_id: roomId,
    connected,
  })
  if (error) throw new Error(error.message)
}

function rememberLastRoom(code: string) {
  window.localStorage.setItem('omega:last-room', code.toUpperCase())
}

export function getRememberedRoomCode(): string | null {
  return window.localStorage.getItem('omega:last-room')
}

export function forgetRememberedRoom() {
  window.localStorage.removeItem('omega:last-room')
}

async function getRoomById(roomId: string): Promise<Room> {
  const { data, error } = await supabase.from('rooms').select().eq('id', roomId).single()
  if (error || !data) throw new Error('Room could not be loaded.')
  return data
}

async function getPlayerById(playerId: string): Promise<Player> {
  const { data, error } = await supabase
    .from('players')
    .select('id, user_id, nickname, is_host, is_connected, joined_at')
    .eq('id', playerId)
    .single()
  if (error || !data) throw new Error('Player session could not be restored.')
  return data
}

export async function getRoomByCode(code: string): Promise<Room> {
  const { data, error } = await supabase
    .from('rooms')
    .select()
    .eq('code', code.toUpperCase())
    .single()

  if (error || !data) throw new Error('Room not found. Check the code and try again.')
  return data
}

export async function getRoomPlayers(roomId: string): Promise<Player[]> {
  const { data, error } = await supabase
    .from('players')
    .select('id, user_id, nickname, is_host, is_connected, joined_at')
    .eq('room_id', roomId)
    .order('joined_at', { ascending: true })

  if (error) throw new Error(error.message)
  return data
}
