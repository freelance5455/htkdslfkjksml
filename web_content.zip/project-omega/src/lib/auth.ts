import { supabase } from './supabaseClient'

let cachedUserId: string | null = null

/**
 * Makes sure this browser has a Supabase auth session before anything else
 * runs. Anonymous sign-in creates a real (but credential-less) user behind
 * the scenes — no email, password, or account screen for the player ever
 * sees. The session is saved by supabase-js automatically, so refreshing
 * the page keeps the same identity. Call this once at startup.
 */
export async function ensureSignedIn(): Promise<string> {
  if (cachedUserId) return cachedUserId

  const { data: sessionData } = await supabase.auth.getSession()
  if (sessionData.session?.user) {
    cachedUserId = sessionData.session.user.id
    return cachedUserId
  }

  const { data, error } = await supabase.auth.signInAnonymously()
  if (error || !data.user) {
    throw new Error('Could not start a session. Check your internet connection and try again.')
  }
  cachedUserId = data.user.id
  return cachedUserId
}

/** Synchronous lookup — safe to call anywhere after ensureSignedIn() has resolved once at startup. */
export function getCurrentUserId(): string {
  if (!cachedUserId) {
    throw new Error('Not signed in yet.')
  }
  return cachedUserId
}
