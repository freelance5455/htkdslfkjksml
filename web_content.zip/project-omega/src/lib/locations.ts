// CONTROL ROOM is intentionally excluded — it unlocks later, for the final puzzle (Phase 6).
export const LOCATIONS = ['ARCHIVE', 'LAB', 'SECURITY ROOM', 'SERVER ROOM', 'STORAGE'] as const

export type InvestigationLocation = (typeof LOCATIONS)[number]
