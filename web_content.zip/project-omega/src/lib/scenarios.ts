export const SCENARIOS = [
  {
    id: 'PROJECT OMEGA',
    title: 'PROJECT OMEGA',
    description: 'A mysterious drive vanished from a restricted research facility.',
  },
  {
    id: 'THE VANISHING SIGNAL',
    title: 'THE VANISHING SIGNAL',
    description: 'A strange transmission appears every night, then disappears without a trace.',
  },
  {
    id: 'THE LOCKED ARCHIVE',
    title: 'THE LOCKED ARCHIVE',
    description: 'An archive room opened by itself, but the missing file is still locked inside.',
  },
] as const

export type ScenarioId = typeof SCENARIOS[number]['id']
