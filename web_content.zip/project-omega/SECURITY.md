# PROJECT OMEGA security notes

- Never place a Supabase `service_role` or secret key in frontend code.
- Secret roles are stored separately and only the current user's role is readable through RLS.
- Raw clue source rows and final-puzzle answers are not directly readable by clients.
- Game state changes happen through authenticated database functions that re-check room membership and phase.
- Player room visibility uses a private membership helper to avoid recursive RLS evaluation.
- Investigation and sabotage locations are validated server-side.
- Voting prevents self-votes and cross-room suspect IDs.
- Final-puzzle attempts are locked in a transaction so simultaneous submissions cannot accidentally consume the same attempt twice.

For a public launch, add platform-level abuse/rate limiting and monitor Supabase logs. This project is a game, not a security product; do not put real secrets, personal data, or real-world hacking instructions into scenarios or clues.
