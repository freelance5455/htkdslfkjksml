-- Project Omega — schema (through Phase 9)
-- Run this in your Supabase project's SQL Editor (SQL Editor tab -> New query -> paste -> Run).
-- Safe to re-run during development: it drops and recreates everything below,
-- so any test rooms/players you've created will be wiped. That's expected
-- for now — there's no real user data to lose yet.

create extension if not exists pgcrypto;

create schema if not exists private;
drop function if exists private.is_room_member(uuid, uuid) cascade;

drop function if exists create_room(text) cascade;
drop function if exists join_room(text,text) cascade;
drop function if exists rejoin_last_game() cascade;
drop function if exists set_player_connected(uuid,boolean) cascade;
drop table if exists final_puzzles cascade;
drop table if exists votes cascade;
drop table if exists player_clues cascade;
drop table if exists player_roles cascade;
drop table if exists clues cascade;
drop table if exists players cascade;
drop table if exists rooms cascade;

-- ROOMS ----------------------------------------------------------------

create table rooms (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  status text not null default 'lobby'
    check (status in ('lobby', 'in_progress', 'discussion', 'voting', 'results', 'final_puzzle', 'ended')),
  mystery text,
  scenario text not null default 'PROJECT OMEGA' check (scenario in ('PROJECT OMEGA','THE VANISHING SIGNAL','THE LOCKED ARCHIVE')),
  sabotaged_locations text[] not null default '{}',
  discussion_started_at timestamptz,
  villain_exposed boolean not null default false,
  last_round_results jsonb,
  created_at timestamptz not null default now()
);

create index rooms_code_idx on rooms (code);

alter table rooms enable row level security;

create policy "Anyone can read rooms" on rooms
  for select using (true);

create policy "Anyone can create a room" on rooms
  for insert with check (true);

-- No update policy for rooms: status/mystery/sabotage/results can only change
-- through the functions below, which check who's allowed to call them.

-- PLAYERS ----------------------------------------------------------------

create table players (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  nickname text not null,
  is_host boolean not null default false,
  is_connected boolean not null default true,
  joined_at timestamptz not null default now(),
  unique (room_id, user_id)
);

create index players_room_id_idx on players (room_id);

alter table players enable row level security;

-- SECURITY HARDENING: never reference `players` from its own RLS policy.
-- PostgreSQL can recurse through that policy. The helper runs as its owner and
-- is kept in a non-exposed schema so clients cannot call it directly.
create or replace function private.is_room_member(target_room_id uuid, target_user_id uuid)
returns boolean
language sql
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.players p
    where p.room_id = target_room_id and p.user_id = target_user_id
  );
$$;

revoke all on function private.is_room_member(uuid, uuid) from public;

create policy "Players can read players in their rooms" on players
  for select using (private.is_room_member(room_id, auth.uid()));

-- Clients cannot insert/update/delete players directly. Room membership is
-- created and restored only through the server-side RPCs below.

-- PHASE 7: SESSION PERSISTENCE / RECONNECTION -----------------------------
-- Room/player creation and joining now happen through server-side functions.
-- This prevents clients from choosing is_host and prevents duplicate player
-- identities when the same browser reconnects.

create or replace function create_room(player_nickname text)
returns table(room_id uuid, player_id uuid)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  new_room_id uuid;
  new_player_id uuid;
  new_code text;
begin
  if auth.uid() is null then raise exception 'You must have a session.'; end if;
  if length(trim(player_nickname)) < 1 or length(trim(player_nickname)) > 16 then
    raise exception 'Nickname must be 1–16 characters.';
  end if;

  loop
    new_code := upper(substr(encode(gen_random_bytes(5), 'hex'), 1, 6));
    begin
      insert into rooms(code) values (new_code) returning id into new_room_id;
      exit;
    exception when unique_violation then
      -- Try another room code.
    end;
  end loop;

  insert into players(room_id, user_id, nickname, is_host)
  values(new_room_id, auth.uid(), trim(player_nickname), true)
  returning id into new_player_id;

  return query select new_room_id, new_player_id;
end;
$$;

grant execute on function create_room(text) to authenticated;

create or replace function join_room(room_code text, player_nickname text)
returns table(room_id uuid, player_id uuid)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  target_room_id uuid;
  existing_player_id uuid;
  new_player_id uuid;
  existing_nickname text;
begin
  if auth.uid() is null then raise exception 'You must have a session.'; end if;
  if length(trim(player_nickname)) < 1 or length(trim(player_nickname)) > 16 then
    raise exception 'Nickname must be 1–16 characters.';
  end if;

  select id into target_room_id from rooms where code = upper(trim(room_code));
  if target_room_id is null then raise exception 'Room not found. Check the code and try again.'; end if;
  if (select status from rooms where id = target_room_id) <> 'lobby' then
    raise exception 'This game has already started.';
  end if;

  select id, nickname into existing_player_id, existing_nickname
  from players where room_id = target_room_id and user_id = auth.uid();

  if existing_player_id is not null then
    update players set is_connected = true where id = existing_player_id;
    return query select target_room_id, existing_player_id;
    return;
  end if;

  if (select count(*) from players where room_id = target_room_id) >= 10 then
    raise exception 'This room is full.';
  end if;
  if exists (select 1 from players where room_id = target_room_id and lower(nickname) = lower(trim(player_nickname))) then
    raise exception 'That nickname is already taken in this room.';
  end if;

  insert into players(room_id, user_id, nickname, is_host, is_connected)
  values(target_room_id, auth.uid(), trim(player_nickname), false, true)
  returning id into new_player_id;

  return query select target_room_id, new_player_id;
end;
$$;

grant execute on function join_room(text,text) to authenticated;

create or replace function rejoin_last_game()
returns table(room_id uuid, player_id uuid)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  found_room_id uuid;
  found_player_id uuid;
begin
  if auth.uid() is null then return; end if;

  select p.room_id, p.id into found_room_id, found_player_id
  from players p
  join rooms r on r.id = p.room_id
  where p.user_id = auth.uid()
    and r.status <> 'ended'
  order by p.joined_at desc
  limit 1;

  if found_player_id is null then return; end if;
  update players set is_connected = true where id = found_player_id;
  return query select found_room_id, found_player_id;
end;
$$;

grant execute on function rejoin_last_game() to authenticated;

create or replace function set_player_connected(target_room_id uuid, connected boolean)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if not exists(select 1 from players where room_id = target_room_id and user_id = auth.uid()) then
    raise exception 'You are not a player in this room.';
  end if;
  update players set is_connected = connected where room_id = target_room_id and user_id = auth.uid();
end;
$$;

grant execute on function set_player_connected(uuid,boolean) to authenticated;

-- ROLES --------------------------------------------------------------------
-- Kept in a separate table from `players` so a player's own client can never
-- select another player's role, no matter what query it sends.

create table player_roles (
  player_id uuid primary key references players(id) on delete cascade,
  room_id uuid not null references rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('villain', 'protector')),
  sabotages_remaining integer not null default 0,
  created_at timestamptz not null default now()
);

alter table player_roles enable row level security;

create policy "Players can read only their own role" on player_roles
  for select using (user_id = auth.uid());

-- No insert/update policy here on purpose: rows are only ever written by the
-- functions below.

-- CLUES ----------------------------------------------------------------
-- The answer key. Never directly readable by players — only the functions
-- below (which run with elevated privileges) can query it.

create table clues (
  id uuid primary key default gen_random_uuid(),
  mystery text not null,
  location text not null,
  content text not null,
  is_misleading boolean not null default false
);

alter table clues enable row level security;
-- Intentionally zero policies: RLS with no policies denies all direct
-- client access, even for signed-in players.

insert into clues (mystery, location, content, is_misleading) values
  ('PROJECT OMEGA', 'ARCHIVE', 'A shipping manifest shows a small drive delivered to this building three weeks ago, addressee redacted.', false),
  ('PROJECT OMEGA', 'ARCHIVE', 'An old memo claims the drive was destroyed last year. The destruction log has no signature on it.', false),
  ('PROJECT OMEGA', 'ARCHIVE', 'A visitor sign-in sheet lists a name that doesn''t match anyone on staff.', true),
  ('PROJECT OMEGA', 'LAB', 'A workbench has a freshly cut cable tie and a faint outline in the dust where something small used to sit.', false),
  ('PROJECT OMEGA', 'LAB', 'A whiteboard sketch shows a device labeled "OMEGA" with a question mark instead of a serial number.', false),
  ('PROJECT OMEGA', 'LAB', 'A spilled cup of coffee has gone cold on a keyboard that''s still logged in.', true),
  ('PROJECT OMEGA', 'SECURITY ROOM', 'Camera footage from Hallway B cuts out for exactly four minutes last night.', false),
  ('PROJECT OMEGA', 'SECURITY ROOM', 'A badge log shows someone re-entered the building at 2:14am using a badge reported lost two days earlier.', false),
  ('PROJECT OMEGA', 'SECURITY ROOM', 'A guard''s notebook mentions "nothing unusual" in careful, deliberate handwriting.', true),
  ('PROJECT OMEGA', 'SERVER ROOM', 'A rack log shows a single unfamiliar device connected for six minutes and then removed.', false),
  ('PROJECT OMEGA', 'SERVER ROOM', 'A cooling fan was left running on a server that''s officially been decommissioned for months.', false),
  ('PROJECT OMEGA', 'SERVER ROOM', 'A sticky note with a partial password is stuck to a monitor that hasn''t been used in a year.', true),
  ('PROJECT OMEGA', 'STORAGE', 'A storage crate labeled "MISC — DO NOT OPEN" has a lock that''s been cut and loosely reattached.', false),
  ('PROJECT OMEGA', 'STORAGE', 'An inventory sheet has one line item scratched out so hard it tore the paper.', false),
  ('PROJECT OMEGA', 'STORAGE', 'A dusty box of cables looks undisturbed, but the dust on top has a faint handprint.', true);

insert into clues (mystery, location, content, is_misleading) values
  ('THE VANISHING SIGNAL', 'ARCHIVE', 'A maintenance note says the signal appears exactly nine minutes after the archive door closes.', false),
  ('THE VANISHING SIGNAL', 'ARCHIVE', 'A handwritten note claims the transmission is coming from outside the building.', true),
  ('THE VANISHING SIGNAL', 'LAB', 'A receiver records the same three-tone pattern at every occurrence.', false),
  ('THE VANISHING SIGNAL', 'LAB', 'A dead battery is labeled as recently replaced.', true),
  ('THE VANISHING SIGNAL', 'SECURITY ROOM', 'The camera clock jumps forward by 19 seconds whenever the signal appears.', false),
  ('THE VANISHING SIGNAL', 'SERVER ROOM', 'A monitoring process records a signal source that does not match any registered device.', false),
  ('THE VANISHING SIGNAL', 'STORAGE', 'An old antenna is missing from a box marked obsolete.', false),
  ('THE LOCKED ARCHIVE', 'ARCHIVE', 'The missing file number appears in a catalog that predates the current archive system.', false),
  ('THE LOCKED ARCHIVE', 'ARCHIVE', 'A sticky note says the file was moved, but gives no destination.', true),
  ('THE LOCKED ARCHIVE', 'LAB', 'A keycard reader remembers an access attempt from a card that was deactivated.', false),
  ('THE LOCKED ARCHIVE', 'SECURITY ROOM', 'A corridor camera shows the archive door opening with no visible person nearby.', false),
  ('THE LOCKED ARCHIVE', 'SERVER ROOM', 'The archive index was queried shortly before the room locked itself.', false),
  ('THE LOCKED ARCHIVE', 'STORAGE', 'A sealed box contains a matching archive seal from an older filing system.', false);

-- FOUND CLUES --------------------------------------------------------------
-- Content is duplicated here (rather than joined from `clues`) specifically
-- so players can read discovered clues without needing any access to the
-- locked-down clues table.

create table player_clues (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references rooms(id) on delete cascade,
  player_id uuid not null references players(id) on delete cascade,
  clue_id uuid not null references clues(id),
  location text not null,
  content text not null,
  found_at timestamptz not null default now()
);

alter table player_clues enable row level security;

create policy "Players can read their own clues, or everyone's once discussion has started" on player_clues
  for select using (
    exists (
      select 1 from players p
      where p.id = player_clues.player_id and p.user_id = auth.uid()
    )
    or exists (
      select 1 from rooms r
      join players me on me.room_id = r.id
      where r.id = player_clues.room_id
        and me.user_id = auth.uid()
        and r.status in ('discussion', 'voting', 'results', 'final_puzzle', 'ended')
    )
  );

-- No insert policy here either: only investigate_location() writes to this table.

-- VOTES ----------------------------------------------------------------
-- Individual vote choices stay private (you can only read your own) —
-- results are surfaced separately via rooms.last_round_results once revealed.

create table final_puzzles (
  room_id uuid primary key references rooms(id) on delete cascade,
  prompt text not null,
  answer integer not null,
  attempts_remaining integer not null default 3 check (attempts_remaining >= 0),
  created_at timestamptz not null default now()
);

alter table final_puzzles enable row level security;
-- No policies: puzzle answers are never directly readable by players.

create table votes (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references rooms(id) on delete cascade,
  voter_player_id uuid not null references players(id) on delete cascade,
  suspect_player_id uuid not null references players(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (room_id, voter_player_id)
);

create index votes_room_id_idx on votes (room_id);

alter table votes enable row level security;

create policy "Players can read only their own vote" on votes
  for select using (
    exists (
      select 1 from players p
      where p.id = votes.voter_player_id and p.user_id = auth.uid()
    )
  );

-- No insert/update policy: only cast_vote() writes here. Live vote counts
-- are read through get_vote_count() below, which returns a number, never
-- who voted for whom.

-- FUNCTIONS ----------------------------------------------------------------
-- These run with the privileges of their owner (which bypasses the RLS
-- policies above), so they're the only path that can assign roles, hand out
-- clues, change room phase, or record votes. Each one re-checks who's
-- calling and what state the room is in before doing anything.

create or replace function set_room_scenario(target_room_id uuid, target_scenario text)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_is_host boolean;
begin
  select is_host into caller_is_host from players where room_id = target_room_id and user_id = auth.uid();
  if caller_is_host is not true then raise exception 'Only the host can choose the scenario.'; end if;
  if (select status from rooms where id = target_room_id) <> 'lobby' then raise exception 'Scenario can only be changed in the lobby.'; end if;
  if target_scenario not in ('PROJECT OMEGA','THE VANISHING SIGNAL','THE LOCKED ARCHIVE') then raise exception 'Unknown scenario.'; end if;
  update rooms set scenario = target_scenario, mystery = target_scenario where id = target_room_id;
end;
$$;

grant execute on function set_room_scenario(uuid, text) to authenticated;

create or replace function start_game(target_room_id uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  caller_is_host boolean;
  player_count integer;
  villain_player_id uuid;
begin
  select id, is_host into caller_player_id, caller_is_host
  from players
  where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null or caller_is_host is not true then
    raise exception 'Only the host can start the game.';
  end if;

  if (select status from rooms where id = target_room_id) <> 'lobby' then
    raise exception 'This game has already started.';
  end if;

  select count(*) into player_count from players where room_id = target_room_id;
  if player_count < 4 then
    raise exception 'Need at least 4 players to start.';
  end if;

  select id into villain_player_id
  from players
  where room_id = target_room_id
  order by random()
  limit 1;

  insert into player_roles (player_id, room_id, user_id, role, sabotages_remaining)
  select
    p.id,
    target_room_id,
    p.user_id,
    case when p.id = villain_player_id then 'villain' else 'protector' end,
    case when p.id = villain_player_id then 3 else 0 end
  from players p
  where p.room_id = target_room_id;

  update rooms set status = 'in_progress', mystery = scenario where id = target_room_id;
end;
$$;

grant execute on function start_game(uuid) to authenticated;

create or replace function investigate_location(target_room_id uuid, target_location text)
returns table(clue_id uuid, content text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  v_room rooms%rowtype;
  v_sabotaged boolean;
  v_clue_id uuid;
  v_content text;
begin
  select id into caller_player_id
  from players
  where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null then
    raise exception 'You are not a player in this room.';
  end if;

  if upper(trim(target_location)) not in ('ARCHIVE', 'LAB', 'SECURITY ROOM', 'SERVER ROOM', 'STORAGE') then
    raise exception 'Unknown investigation location.';
  end if;

  target_location := upper(trim(target_location));
  select * into v_room from rooms where id = target_room_id;
  if v_room.status is distinct from 'in_progress' then
    raise exception 'The investigation is not active right now.';
  end if;

  v_sabotaged := target_location = any(v_room.sabotaged_locations);

  -- Sabotaged locations bias toward a misleading clue first, if one's left.
  if v_sabotaged then
    select c.id, c.content into v_clue_id, v_content
    from clues c
    where c.mystery = v_room.mystery
      and c.location = target_location
      and c.is_misleading = true
      and not exists (
        select 1 from player_clues pc
        where pc.player_id = caller_player_id and pc.clue_id = c.id
      )
    order by random()
    limit 1;
  end if;

  if v_clue_id is null then
    select c.id, c.content into v_clue_id, v_content
    from clues c
    where c.mystery = v_room.mystery
      and c.location = target_location
      and not exists (
        select 1 from player_clues pc
        where pc.player_id = caller_player_id and pc.clue_id = c.id
      )
    order by random()
    limit 1;
  end if;

  if v_clue_id is null then
    return query select null::uuid, 'There''s nothing left to find here.'::text;
    return;
  end if;

  insert into player_clues (room_id, player_id, clue_id, location, content)
  values (target_room_id, caller_player_id, v_clue_id, target_location, v_content);

  return query select v_clue_id, v_content;
end;
$$;

grant execute on function investigate_location(uuid, text) to authenticated;

create or replace function sabotage_location(target_room_id uuid, target_location text)
returns integer
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  v_role text;
  v_remaining integer;
begin
  select id into caller_player_id
  from players
  where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null then
    raise exception 'You are not a player in this room.';
  end if;

  if upper(trim(target_location)) not in ('ARCHIVE', 'LAB', 'SECURITY ROOM', 'SERVER ROOM', 'STORAGE') then
    raise exception 'Unknown sabotage location.';
  end if;

  target_location := upper(trim(target_location));
  select role, sabotages_remaining into v_role, v_remaining
  from player_roles
  where player_id = caller_player_id and room_id = target_room_id;

  if v_role is distinct from 'villain' then
    raise exception 'Only the Villain can sabotage.';
  end if;

  if v_remaining <= 0 then
    raise exception 'No sabotage actions remaining.';
  end if;

  update player_roles
  set sabotages_remaining = sabotages_remaining - 1
  where player_id = caller_player_id and room_id = target_room_id
  returning sabotages_remaining into v_remaining;

  update rooms
  set sabotaged_locations = array_append(sabotaged_locations, target_location)
  where id = target_room_id and not (target_location = any(sabotaged_locations));

  return v_remaining;
end;
$$;

grant execute on function sabotage_location(uuid, text) to authenticated;

create or replace function start_discussion(target_room_id uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  caller_is_host boolean;
begin
  select id, is_host into caller_player_id, caller_is_host
  from players
  where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null or caller_is_host is not true then
    raise exception 'Only the host can call for discussion.';
  end if;

  if (select status from rooms where id = target_room_id) <> 'in_progress' then
    raise exception 'The investigation is not active right now.';
  end if;

  update rooms
  set status = 'discussion', discussion_started_at = now()
  where id = target_room_id;
end;
$$;

grant execute on function start_discussion(uuid) to authenticated;

create or replace function start_voting(target_room_id uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
begin
  select id into caller_player_id
  from players
  where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null then
    raise exception 'You are not a player in this room.';
  end if;

  -- No-op (not an error) if the phase already moved on, so it's safe for
  -- more than one device to call this at once when the timer hits zero.
  if (select status from rooms where id = target_room_id) <> 'discussion' then
    return;
  end if;

  update rooms set status = 'voting' where id = target_room_id;
end;
$$;

grant execute on function start_voting(uuid) to authenticated;

create or replace function cast_vote(target_room_id uuid, target_suspect_player_id uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
begin
  select id into caller_player_id
  from players
  where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null then
    raise exception 'You are not a player in this room.';
  end if;

  if (select status from rooms where id = target_room_id) <> 'voting' then
    raise exception 'Voting is not open right now.';
  end if;

  if target_suspect_player_id = caller_player_id then
    raise exception 'You cannot vote for yourself.';
  end if;

  if not exists (
    select 1 from players where id = target_suspect_player_id and room_id = target_room_id
  ) then
    raise exception 'That player is not in this room.';
  end if;

  insert into votes (room_id, voter_player_id, suspect_player_id)
  values (target_room_id, caller_player_id, target_suspect_player_id)
  on conflict (room_id, voter_player_id)
  do update set suspect_player_id = excluded.suspect_player_id, created_at = now();
end;
$$;

grant execute on function cast_vote(uuid, uuid) to authenticated;

create or replace function get_vote_count(target_room_id uuid)
returns integer
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  v_count integer;
begin
  select id into caller_player_id
  from players
  where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null then
    raise exception 'You are not a player in this room.';
  end if;

  select count(*) into v_count from votes where room_id = target_room_id;
  return v_count;
end;
$$;

grant execute on function get_vote_count(uuid) to authenticated;

create or replace function reveal_vote_results(target_room_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  caller_is_host boolean;
  v_tally jsonb;
  v_top_count integer;
  v_top_count_players integer;
  v_accused_id uuid;
  v_accused_nickname text;
  v_accused_role text;
  v_villain_player_id uuid;
  v_results jsonb;
  a integer; b integer; c integer;
  v_answer integer;
  v_prompt text;
begin
  select id, is_host into caller_player_id, caller_is_host
  from players where room_id = target_room_id and user_id = auth.uid();

  if caller_player_id is null or caller_is_host is not true then
    raise exception 'Only the host can reveal results.';
  end if;
  if (select status from rooms where id = target_room_id) <> 'voting' then
    raise exception 'Voting is not currently open.';
  end if;

  select coalesce(jsonb_agg(
      jsonb_build_object('player_id', p.id, 'nickname', p.nickname, 'votes', coalesce(vc.n, 0))
      order by coalesce(vc.n, 0) desc
    ), '[]'::jsonb)
  into v_tally
  from players p
  left join (select suspect_player_id, count(*) as n from votes where room_id = target_room_id group by suspect_player_id) vc
    on vc.suspect_player_id = p.id
  where p.room_id = target_room_id;

  select max((elem->>'votes')::int) into v_top_count from jsonb_array_elements(v_tally) elem;
  select count(*) into v_top_count_players from jsonb_array_elements(v_tally) elem
    where (elem->>'votes')::int = v_top_count and v_top_count > 0;

  if v_top_count > 0 and v_top_count_players = 1 then
    select (elem->>'player_id')::uuid, (elem->>'nickname') into v_accused_id, v_accused_nickname
    from jsonb_array_elements(v_tally) elem where (elem->>'votes')::int = v_top_count limit 1;
    select role into v_accused_role from player_roles where player_id = v_accused_id and room_id = target_room_id;

    if v_accused_role = 'villain' then
      update rooms set villain_exposed = true where id = target_room_id;

      -- Randomized fictional arithmetic puzzle. The answer lives only in the
      -- locked table; clients receive the prompt, never the answer.
      a := floor(random() * 8 + 2)::int;
      b := floor(random() * 8 + 2)::int;
      c := floor(random() * 5 + 2)::int;
      if (select scenario from rooms where id = target_room_id) = 'THE VANISHING SIGNAL' then
        v_answer := a * c + b;
        v_prompt := format('Signal lock: (%s × %s) + %s. Enter the control code.', a, c, b);
      elsif (select scenario from rooms where id = target_room_id) = 'THE LOCKED ARCHIVE' then
        v_answer := (a + b) * c;
        v_prompt := format('Archive lock: (%s + %s) × %s. Enter the control code.', a, b, c);
      else
        v_answer := a + (b * c);
        v_prompt := format('OMEGA terminal: %s + (%s × %s). Enter the control code.', a, b, c);
      end if;
      insert into final_puzzles(room_id, prompt, answer, attempts_remaining)
      values (target_room_id, v_prompt, v_answer, 3)
      on conflict (room_id) do nothing;
      update rooms set status = 'final_puzzle' where id = target_room_id;
    else
      select player_id into v_villain_player_id from player_roles where room_id = target_room_id and role = 'villain';
      update player_roles set sabotages_remaining = sabotages_remaining + 2
      where player_id = v_villain_player_id and room_id = target_room_id;
    end if;
  end if;

  v_results := jsonb_build_object(
    'tally', v_tally,
    'accused_player_id', v_accused_id,
    'accused_nickname', v_accused_nickname,
    'accused_was_villain', case when v_accused_id is not null then (v_accused_role = 'villain') else null end
  );

  update rooms set last_round_results = v_results where id = target_room_id;
  if (select status from rooms where id = target_room_id) <> 'final_puzzle' then
    update rooms set status = 'results' where id = target_room_id;
  end if;
  return v_results;
end;
$$;

grant execute on function reveal_vote_results(uuid) to authenticated;

create or replace function continue_investigation(target_room_id uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  caller_is_host boolean;
begin
  select id, is_host into caller_player_id, caller_is_host
  from players where room_id = target_room_id and user_id = auth.uid();
  if caller_player_id is null or caller_is_host is not true then
    raise exception 'Only the host can continue.';
  end if;
  if (select status from rooms where id = target_room_id) <> 'results' then
    raise exception 'Not currently showing results.';
  end if;
  if (select villain_exposed from rooms where id = target_room_id) then
    raise exception 'The Villain is exposed. Continue through the final puzzle.';
  end if;
  update rooms set status = 'in_progress' where id = target_room_id;
end;
$$;

grant execute on function continue_investigation(uuid) to authenticated;

-- FINAL PUZZLE -------------------------------------------------------------
-- The prompt is public through a function, but the answer remains locked.

create or replace function get_final_puzzle(target_room_id uuid)
returns table(prompt text, attempts_remaining integer)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  v_status text;
begin
  select id into caller_player_id from players where room_id = target_room_id and user_id = auth.uid();
  if caller_player_id is null then raise exception 'You are not a player in this room.'; end if;
  select status into v_status from rooms where id = target_room_id;
  if v_status not in ('final_puzzle', 'ended') then raise exception 'The final puzzle is not active.'; end if;
  return query select fp.prompt, fp.attempts_remaining from final_puzzles fp where fp.room_id = target_room_id;
end;
$$;

grant execute on function get_final_puzzle(uuid) to authenticated;

create or replace function submit_final_puzzle(target_room_id uuid, submitted_answer integer)
returns table(correct boolean, attempts_remaining integer)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  caller_player_id uuid;
  v_puzzle final_puzzles%rowtype;
  v_correct boolean;
  v_remaining integer;
  v_results jsonb;
begin
  select id into caller_player_id from players where room_id = target_room_id and user_id = auth.uid();
  if caller_player_id is null then raise exception 'You are not a player in this room.'; end if;
  if (select status from rooms where id = target_room_id) <> 'final_puzzle' then raise exception 'The final puzzle is not active.'; end if;
  select * into v_puzzle from final_puzzles where room_id = target_room_id for update;
  if v_puzzle.room_id is null then raise exception 'Final puzzle not found.'; end if;
  if v_puzzle.attempts_remaining <= 0 then raise exception 'No attempts remaining.'; end if;

  v_correct := submitted_answer = v_puzzle.answer;
  v_remaining := case when v_correct then v_puzzle.attempts_remaining else v_puzzle.attempts_remaining - 1 end;
  update final_puzzles set attempts_remaining = v_remaining where room_id = target_room_id;

  if v_correct then
    v_results := coalesce((select last_round_results from rooms where id = target_room_id), '{}'::jsonb) || jsonb_build_object('winner', 'protectors');
    update rooms set status = 'ended', last_round_results = v_results where id = target_room_id;
  elsif v_remaining = 0 then
    v_results := coalesce((select last_round_results from rooms where id = target_room_id), '{}'::jsonb) || jsonb_build_object('winner', 'villain');
    update rooms set status = 'ended', last_round_results = v_results where id = target_room_id;
  end if;

  return query select v_correct, v_remaining;
end;
$$;

grant execute on function submit_final_puzzle(uuid, integer) to authenticated;


-- PHASE 9 SECURITY / API HARDENING -----------------------------------------
-- Keep the RPC surface authenticated-only. RLS remains the authorization
-- layer for direct table reads; these functions are the only mutation path.
revoke all on function create_room(text) from public, anon;
grant execute on function create_room(text) to authenticated;
revoke all on function join_room(text, text) from public, anon;
grant execute on function join_room(text, text) to authenticated;
revoke all on function rejoin_last_game() from public, anon;
grant execute on function rejoin_last_game() to authenticated;
revoke all on function set_player_connected(uuid, boolean) from public, anon;
grant execute on function set_player_connected(uuid, boolean) to authenticated;
revoke all on function set_room_scenario(uuid, text) from public, anon;
grant execute on function set_room_scenario(uuid, text) to authenticated;
revoke all on function start_game(uuid) from public, anon;
grant execute on function start_game(uuid) to authenticated;
revoke all on function investigate_location(uuid, text) from public, anon;
grant execute on function investigate_location(uuid, text) to authenticated;
revoke all on function sabotage_location(uuid, text) from public, anon;
grant execute on function sabotage_location(uuid, text) to authenticated;
revoke all on function start_discussion(uuid) from public, anon;
grant execute on function start_discussion(uuid) to authenticated;
revoke all on function start_voting(uuid) from public, anon;
grant execute on function start_voting(uuid) to authenticated;
revoke all on function cast_vote(uuid, uuid) from public, anon;
grant execute on function cast_vote(uuid, uuid) to authenticated;
revoke all on function get_vote_count(uuid) from public, anon;
grant execute on function get_vote_count(uuid) to authenticated;
revoke all on function reveal_vote_results(uuid) from public, anon;
grant execute on function reveal_vote_results(uuid) to authenticated;
revoke all on function continue_investigation(uuid) from public, anon;
grant execute on function continue_investigation(uuid) to authenticated;
revoke all on function get_final_puzzle(uuid) from public, anon;
grant execute on function get_final_puzzle(uuid) to authenticated;
revoke all on function submit_final_puzzle(uuid, integer) from public, anon;
grant execute on function submit_final_puzzle(uuid, integer) to authenticated;
