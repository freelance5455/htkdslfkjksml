# Project Omega — Phase 2 setup

## 1. Create a free Supabase project
1. Go to https://supabase.com and sign up (free tier is enough for this).
2. Click **New Project**. Pick any name and a database password (save it somewhere — you likely won't need it again for this project, but keep it just in case).
3. Wait a minute or two while it provisions.

## 2. Run the database schema
1. In your new project, open the **SQL Editor** tab (left sidebar).
2. Click **New query**.
3. Open `supabase/schema.sql` from this project, copy all of it, paste it into the SQL editor.
4. Click **Run**. You should see "Success. No rows returned."
5. Check it worked: open the **Table Editor** tab — you should see `rooms` and `players` tables.

## 3. Get your API credentials
1. In Supabase, go to **Project Settings** (gear icon) -> **API**.
2. Copy the **Project URL**.
3. Copy the **anon public** key (NOT the `service_role` key — never put that one in frontend code).

## 4. Configure the app
1. In the `project-omega` folder, copy `.env.example` to a new file named `.env.local`.
2. Paste in your Project URL and anon key:
   ```
   VITE_SUPABASE_URL=https://your-project-ref.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-public-key-here
   ```
3. Save the file. `.env.local` is already in `.gitignore` so it won't get committed anywhere.

## 5. Run it
```
npm install
npm run dev
```

## What to test
- **Create Game** with a nickname — you should land in a Lobby showing a real room code, and you should see yourself listed with a "HOST" tag.
- Open the Supabase **Table Editor** -> `rooms` table — you should see the row you just created. Check `players` too.
- Open the same Lobby URL in a second browser tab (or from another device using the printed network address), use **Join Game** with the same room code and a different nickname — within ~3 seconds the first tab's player list should update to show both players (this is polling; Phase 3 makes it instant).
- Try joining with a nickname already used in that room — you should get an error message, not a crash.
- Try joining with a code that doesn't exist — same, a clear error message.

If you get a "Missing Supabase environment variables" error, double-check `.env.local` exists and both values are filled in, then restart `npm run dev` (Vite only reads env files on startup).

## Phase 3: turn on Realtime

The lobby now updates instantly instead of polling every few seconds — but Supabase only streams changes for tables you've explicitly enabled.

1. In Supabase, go to **Database** -> **Replication**.
2. Find the `supabase_realtime` publication and open it.
3. Toggle **on** both the `rooms` and `players` tables.
4. Save.

That's it — no code changes needed on your end for this step.

**What to test:** open a Lobby in two tabs (or two devices) with the same room code. Join with a third tab. The first two tabs should show the new player appear within a second, with no page refresh. Close one of the tabs — the row won't disappear yet (that requires presence/disconnect handling, which comes in Phase 7); that's expected for now.

## Phase 4: turn on Anonymous sign-ins, then re-run the schema

Secret roles need a real (but login-free) identity per device, so this phase switches the app to Supabase's built-in Anonymous Auth. Two steps:

1. In Supabase, go to **Authentication** -> **Sign In / Providers** (on some Supabase versions this is **Authentication** -> **Providers** -> **Anonymous**, or under **Authentication** -> **Settings**). Turn **on** "Allow anonymous sign-ins."
2. Go back to the **SQL Editor** and run the *updated* `supabase/schema.sql` again in full.
   - **Heads up:** this version starts with `drop table ...` for all four tables, so it wipes any rooms/players you created while testing Phases 2–3. That's expected and fine — there's no real player data to lose at this stage. From here on, treat re-running `schema.sql` as a "reset the dev database" step.

**Important for testing with multiple "players" yourself:** anonymous sign-in saves its session in your browser's local storage, one identity per browser. If you open two tabs in the *same* browser, they'll share one identity and only ever count as one player. To simulate several players on one computer, use separate incognito/private windows (one per player), or different browsers (Chrome + Firefox), or ask friends to use their own phones.

**What to test:**
- Create a room, then join it from 3 more incognito windows with different nicknames (4 players total).
- As the host, click **Start Game**. All 4 windows should jump to the role reveal screen within a second or two.
- Tap to reveal in each window — exactly one should say "THE VILLAIN," the rest "A PROTECTOR." Confirm no window can see anyone else's role.
- On the investigation screen, click a few locations as different players — each should get a clue, and repeated visits to the same location shouldn't repeat a clue you've already found.
- As the Villain's window, try **Sabotage** on a location, confirm the counter goes down and it stops at 0.
- In Supabase's **Table Editor**, check `player_roles` — you should see one `villain` row and the rest `protector`, and `clues`/`player_clues` populating as you investigate.

## Phase 6: no new dashboard config — just re-run the schema

This phase only adds new tables, columns, and functions — nothing new to toggle in the dashboard. `rooms` and `players` are already streaming over Realtime from Phase 3, and new columns on those tables ride along automatically.

1. Go to the **SQL Editor** and run the updated `supabase/schema.sql` again in full (same reset-your-dev-data heads-up as before).

**What to test** (use the same incognito-window trick from Phase 4 for multiple players):
- Get 4 players through role reveal and into Investigation.
- As host, click **Call Everyone to Discuss** — every window should jump to the Discussion screen together, showing the same pooled evidence list.
- Watch the timer — it should show the same countdown across all windows even if they didn't load at exactly the same moment.
- Let it hit 0:00 (or click **Skip to Voting**) — everyone should land on the Voting screen.
- Confirm you can't vote for yourself (you shouldn't even see yourself in the list).
- Vote from all 4 windows — the "X / 4 voted" counter should update within ~2 seconds, and results should reveal automatically once everyone's voted (or the host can click **Reveal Results** early).
- Confirm the results screen shows only whether the accused player was the Villain — not everyone's role.
- If the accusation was wrong, check in Supabase's **Table Editor** that the Villain's `sabotages_remaining` in `player_roles` went up by 2.
- Click **Continue Investigating** as host — everyone should land back on Investigation, and previously-found clues should still be in each player's Case Log.



## Phase 6 — Final puzzle and ending

Phase 6 completes the core game loop.

After a correct Villain accusation:
- The room automatically enters `final_puzzle`.
- Every player is routed to the same final control-room puzzle.
- The puzzle is generated server-side with a randomized arithmetic code.
- The answer is stored only in `final_puzzles` and is never directly readable by clients.
- Players get 3 shared attempts.
- A correct answer ends the room with a PROTECTORS WIN.
- Three failed attempts end the room with a VILLAIN WIN.
- The room automatically routes everyone to the Case Closed screen.

### Phase 6 test

1. Run the updated `supabase/schema.sql` in Supabase SQL Editor.
   **Warning:** this resets the development tables and deletes test rooms/players.
2. Use 4 separate browser identities/windows to create 4 players.
3. Start the game as host.
4. Call discussion, complete voting, and make sure the Villain is accused.
5. All players should automatically move to the Final OMEGA Protocol screen.
6. Read the arithmetic prompt and submit an answer.
7. Test wrong answers and confirm the attempt counter decreases.
8. Submit the correct answer and confirm every player reaches `CASE CLOSED` with `PROTECTORS WIN`.
9. Alternatively, use all 3 wrong attempts and confirm `THE VILLAIN WINS`.

The core Phase 1→6 flow is now:

Home → Create/Join → Lobby → Secret Roles → Investigation → Discussion → Voting → Results → Final Puzzle → Case Closed

## Phase 9 release notes

Phase 9 is the final hardening pass. The schema now avoids recursive player RLS, validates investigation/sabotage locations on the server, and restricts game RPCs to authenticated users. Use the SQL file as the complete schema for a fresh Supabase development project.

Before publishing, complete the 4-player end-to-end checklist in `PHASE9_COMPLETE.md` and verify the deployed app against your own Supabase project.
