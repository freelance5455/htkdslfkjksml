# PROJECT OMEGA — Phase 8

Added: three selectable fictional scenarios, scenario-specific clues and final puzzles, offline Demo Mode, lightweight generated avatars in the lobby, optional spooky mode, optional UI sounds, and replay-friendly local settings.

Run the updated `supabase/schema.sql` in Supabase before testing online rooms. This development schema resets test data.
