# PROJECT OMEGA — Phase 7

Phase 7 adds session persistence, reconnect support, and basic server-side security hardening.

## Added
- Server-side `create_room()` and `join_room()` RPCs.
- Clients can no longer choose `is_host` directly.
- Existing browser identity can rejoin the same room without creating a duplicate player row.
- Last active room code is remembered locally.
- Rejoin screen restores the latest active game for the current anonymous session.
- Connected heartbeat every 15 seconds while inside a game route.
- Best-effort disconnected state when leaving a game route.
- Player SELECT access is restricted to players who share the same room.
- Existing role/clue/vote/puzzle protections remain intact.

## Supabase
Run the complete `supabase/schema.sql` again in the Supabase SQL Editor. It recreates the development schema and clears existing test rooms/players.

## Phase 7 scope
This is reconnect/persistence and baseline security hardening. Production-grade abuse protection, rate limiting, host transfer rules, and deeper audit controls can be added later.
