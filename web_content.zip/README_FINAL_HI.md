# VideoGenie Step 12 – Final Android Integration Package

Is ZIP mein `project/` Python + FFmpeg backend aur `android-app/` Android Studio WebView wrapper source hai.

**Note:** Compiled APK included nahi hai. Android SDK/Gradle build tools is environment mein available nahi the. Build instructions `android-app/README_HI.md` mein hain.

Start PC backend: `project/start-for-phone-app.bat` (Windows) or `project/start-for-phone-app.sh` (Linux/Mac). Android app mein same Wi-Fi par printed server URL enter karo.
