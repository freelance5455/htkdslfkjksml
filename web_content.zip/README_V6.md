# PhysiX Maroc Android v6

نسخة محسّنة من مشروع التطبيق.

- Android native + WebView
- S1 M1→M7
- Offline
- Quiz + نتائج + Progression
- TD / Exercices / Corrigés
- Recherche تفتح الفصل مباشرة
- Français / العربية + RTL
- حفظ التقدم والنتائج والمفضلة محلياً
- زر الرجوع داخل WebView مضبوط

لبناء APK/AAB: افتح المشروع في Android Studio ثم Sync وبعدها Build.
