# ساخت APK آوای ولایت

این پروژه برای بسته‌بندی اندروید با Capacitor آماده شده است.

## پیش‌نیاز
- Node.js
- Android Studio
- Android SDK
- JDK 17+

## نصب
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android
npm run build:web
npx cap add android
npx cap sync android

## ساخت APK تستی
cd android
./gradlew assembleDebug

خروجی معمولاً در:
android/app/build/outputs/apk/debug/app-debug.apk

## نکته API
نسخه فعلی رابط کاربری به API روی `http://localhost:4000` متصل است. برای استفاده واقعی روی گوشی باید آدرس API به دامنه/سرور قابل دسترس از موبایل تغییر کند؛ localhost داخل APK به خود گوشی اشاره می‌کند.
