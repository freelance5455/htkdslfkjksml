SREE GANESH BILLING - Android Project

ഈ project-ൽ Sree_Ganesh_Mill_Billing_Clean.html ഉൾപ്പെടുത്തിയിട്ടുണ്ട്.

Build ചെയ്യാൻ:
1. Android Studio-ൽ ഈ folder തുറക്കുക.
2. Gradle sync പൂർത്തിയാകാൻ കാത്തിരിക്കുക.
3. Build > Generate App Bundles or APKs > Generate APKs തിരഞ്ഞെടുക്കുക.
4. app/build/outputs/apk/debug/app-debug.apk ലഭിക്കും.

App name: Sree Ganesh Billing
Package: com.sreeganesh.billing
