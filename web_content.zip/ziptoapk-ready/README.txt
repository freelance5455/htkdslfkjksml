TELEFONDAN APK ICIN

Bu ZIP web tabanli APK donusturucularda kullanilmak uzere hazirlanmistir.
ZIP'i acmadan yukleyin. index.html ZIP'in kok dizinindedir.

Not: Bu arayuz, mevcut connector cekirdeginin destekledigi baglanti alanlarini gosterir. Gercek Google/Microsoft OAuth ve server-side connector islemleri icin backend/connector runtime gerekir.
