# I Am Rich – Android project

This is an Android Studio project for a static, offline, non-interactive I Am Rich screen.
It uses a local image and local HTML asset only. It does not request the Internet permission.

## Build an APK
1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be in `app/build/outputs/apk/debug/`.

The old-style listing text and visual controls are intentionally static artwork; they do not perform actions.
