<?php
declare(strict_types=1);
require_once __DIR__.'/app/auth.php';
auth_require_user();
header('Location: tools-tutorials.php'.(!empty($_SERVER['QUERY_STRING'])?'?'.$_SERVER['QUERY_STRING']:''), true, 301);
exit;
