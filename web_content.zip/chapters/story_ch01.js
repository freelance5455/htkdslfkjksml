/* =====================================================
   story_ch01.js —— 第一章「盟约之夜」（序章）
   独立章节文件：不修改游戏本体，只提供「新增配置 + 剧本数组」。
   整合方式见同目录 INTEGRATION.md。
   本文件自带小工具（在函数内部），不依赖 story.js 里的 CL / MY / BL。
   ===================================================== */
window.STORY_CH01 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });

  return {

    /* ---------- 需要合并进 story.js 的新增配置 ---------- */
    addCharacters: {
      archbishop: { name: "佩尔图斯", title: "大主教",     color: "#d9d2c0" },
      king:       { name: "奥古斯特", title: "国王",       color: "#e0b64a" },
      gren:       { name: "格伦",     title: "近卫骑士团长", color: "#9fb4c8" }
    },
    addBackgrounds: {
      royal_hall:       { src: "assets/bg/royal_hall.jpg",
                          color: "radial-gradient(ellipse at 50% 20%,#7a5f2a 0%,#2a2118 45%,#0b0907 100%)" },
      service_corridor: { src: "assets/bg/service_corridor.jpg",
                          color: "linear-gradient(180deg,#1c1812 0%,#3a2e20 55%,#14100b 100%)" }
    },
    addCgs: {
      cg_dragon_raid:  { src: "assets/cg/dragon_raid.jpg",
                         color: "radial-gradient(ellipse at 50% 30%,#d8d4f0 0%,#4a4a6a 40%,#0a0910 100%)" },
      cg_night_flight: { src: "assets/cg/night_flight.jpg",
                         color: "linear-gradient(180deg,#05070d 0%,#0e1830 55%,#1a2438 100%)" }
    },
    addAudio: {
      bgm: {
        ch01_banquet:  "assets/audio/ch01_banquet.mp3",
        ch01_ceremony: "assets/audio/ch01_ceremony.mp3",
        ch01_raid:     "assets/audio/ch01_raid.mp3",
        ch01_flight:   "assets/audio/ch01_flight.mp3"
      },
      sfx: {
        glass: "assets/audio/glass.mp3",
        roar:  "assets/audio/roar.mp3"
      }
    },

    /* ---------- 本章设置的 flag（后续章节可用 if 判断） ----------
       sweet: "kept" | "refused"   —— 是否收下溟月的焦糖点心
       obeyed: true                —— 躲避时听从大主教（在 B 分支为 ducked）
       ducked: true                —— 躲避时跟溟月钻桌子
       本章结束时一律：克劳德与溟月一起被龙叼走（主线不变）
    */

    /* =====================================================
       剧本
       ===================================================== */
    script: [

      { label: "ch01_start" },
      { chapter: { no: "CHAPTER 01", title: "盟约之夜", sub: "THE COVENANT · 王都的最后一夜" } },

      /* ---------- 一、镜厅 ---------- */
      { bg: "royal_hall", transition: "black", bgm: "ch01_banquet", hide: "all",
        text: "王都的钟敲了九下。镜厅里三千盏烛火同时被点亮，像是有人把一整片星空，倒扣在了金色的穹顶之下。" },
      { text: "这是王国与教会缔结《复兴盟约》的夜晚。一万年来，神明沉默；而最近的一年里，沉默开始出现了裂缝。" },
      { text: "北境的冰层无故碎裂，南海的季风逆着节令吹了整整一个月，三座古老的神殿，在同一个季度里先后传出了「声音」。" },
      { text: "没有人敢说那是什么。教会替他们说了：那是祂们，要醒了。" },
      { text: "而醒来的神，需要有人去迎接，或者，去安抚。这便是今夜宴会真正的缘由，也是宴会真正的主角，将要背负的事。" },

      { show: { id: "claude", pos: 50, expr: "normal" },
        text: "她站在高台正中，白与橙交织的礼裙，一丝不乱。" },
      { text: "圣女克劳德。教会为她准备了十年的称号，今夜，终于要被所有人念出口。" },
      { text: "她在微笑。嘴角抬起的角度，是大主教亲手纠正过的：向上十五分，不多，不少。" },
      { text: "宾客们看她，像看一件供在神龛里的东西。美丽，端正，不会说话，也不会犯错。" },
      { speaker: "宾客", text: "听说圣女大人从八岁起，就没有睡过一个整觉。真是虔诚啊。" },
      { speaker: "宾客", text: "是啊，到底是神血的孩子，和我们不一样。" },
      { text: "她听见了。微笑的角度，一分也没有变。" },

      /* ---------- 二、大主教 ---------- */
      { show: { id: "claude", pos: 36 }, text: "一只带着戒指的手，从身侧伸过来，替她整了整领口的褶皱。" },
      { who: "archbishop", text: "克劳德。你的手在抖。" },
      { who: "claude", expr: CL("normal"), text: "没有，大人。" },
      { who: "archbishop", text: "那就好。圣女的手，只应该为祈祷而颤。" },
      { text: "他的语气很温和，像在叮嘱一个远行的孩子。这十年里，他每一次这样说话，她都会在当晚的功课里，多抄十遍经文。" },
      { who: "archbishop", text: "去年北境冰裂，死了四百一十七人。你若在那一天学会了第三重祷文，他们本可以活下来。" },
      { text: "这句话，克劳德已经听过很多次。每一次，那个数字都会变得更具体一些，像一枚被反复敲进骨头里的钉子。" },
      { who: "claude", text: "……是。是我来得太迟。" },
      { who: "archbishop", text: "你明白就好。今夜之后，你不再只是克劳德了。去吧，让他们看见你。" },

      /* ---------- 三、走廊里的女仆 ---------- */
      { who: "claude", text: "请容许我，片刻更衣。" },
      { text: "这是她十年里，唯一一句不需要抄经的借口。" },

      { hide: "all", bg: "service_corridor", transition: "black", bgm: null,
        text: "内廷的侧廊没有烛火，只有墙上两盏昏黄的壁灯。宴会的喧闹隔着厚厚的石墙，传来时像是另一个世界在涨潮。" },
      { text: "克劳德靠着墙，闭上了眼睛。嘴角的十五分，终于一寸一寸地，落了下来。" },
      { show: { id: "mingyue", pos: 24, expr: "worried" },
        text: "走廊尽头传来一串急促的脚步声，伴着一个压得极低、却依旧咬牙切齿的声音：" },
      { who: "mingyue", text: "不许掉不许掉不许掉……十二杯，一杯都不许掉……" },
      { text: "一位端着巨大银盘的女仆拐过转角，盘上十二只水晶杯叮当作响，像一群受了惊的鸟。她抬头，看见了站在壁灯下的人。" },
      { show: { id: "claude", pos: 72, expr: "normal" },
        who: "mingyue", expr: MY("surprised", "jump"), text: "圣、圣女大人！！" },
      { sfx: "glass", text: "银盘猛地一歪。那一瞬间，女仆的整个身体像一根被灌了水的柳条，向后弯下去，又弹回来。十二只杯子，一只没碎。" },
      { who: "mingyue", expr: MY("shy"), text: "……成、成功了。" },
      { who: "claude", expr: CL("normal"), text: "内廷的侧廊，不允许侍女单独通行。你为什么在这里？" },
      { who: "mingyue", text: "是！我迷路了！厨房的路标画得跟迷宫一样！" },
      { text: "克劳德没有立刻回答。她的视线，落在了女仆的头顶。" },
      { text: "那里，白色的女仆头饰下，压着一对被刻意按平的耳廓。薄薄的，微微泛着蓝，边缘是鳍的形状。" },
      { text: "亚人。依教会法令，亚人不得踏入内廷一步。" },
      { who: "mingyue", expr: MY("worried"), text: "……您，要叫人吗？" },
      { text: "女仆的声音很轻，却没有躲。她把银盘稳稳地端在身前，像端着自己仅有的一点体面。" },
      { who: "mingyue", text: "我需要这份工。一个月六枚银币，寄回家里，够老舵叔补一张网。" },
      { who: "claude", text: "……家里？" },
      { who: "mingyue", text: "港口。海边的。很小，但是，很吵，很热闹。" },
      { text: "圣典第三卷第七条：凡见异类潜入圣所者，当即告发，不得隐瞒。她背得很熟，熟到可以倒着背。" },
      { text: "可是此刻，她的嘴像被人塞了一团棉花，什么也说不出来。" },
      { who: "claude", text: "……往左，第二道门。厨房在那边。" },
      { who: "mingyue", expr: MY("surprised"), text: "……诶？" },
      { who: "claude", text: "快去。在我改变主意之前。" },
      { who: "mingyue", expr: MY("happy", "jump"), text: "谢、谢谢您！您真是个好人！" },
      { text: "女仆端着银盘跑出去三步，又急刹车，回过头来。" },
      { who: "mingyue", text: "那个，圣女大人。" },
      { who: "mingyue", text: "您刚才在厅里笑的时候，像是被人画上去的。不是不好看，就是……看着累。" },
      { text: "克劳德怔住了。十年里，没有人对她说过这样的话。人们说她「端庄」、「虔诚」、「完美」，唯独没有人说，累。" },
      { who: "mingyue", text: "这个，给您。海盐焦糖。厨房偷的。不是偷，是试毒。" },
      { text: "她用空着的一只手，从围裙口袋里摸出一小块油纸包着的点心，递了过来。纸角被体温焐得微微发软。" },

      { text: "克劳德低头，看着那块点心。教会的圣女，不吃来历不明的东西。",
        choices: [
          { text: "收下，放进袖中", jump: "ch01_sweet_kept",    set: { sweet: "kept" } },
          { text: "冷冷地拒绝",     jump: "ch01_sweet_refused", set: { sweet: "refused" } }
        ] },

      { label: "ch01_sweet_kept" },
      { text: "她没有说话，只是接了过来，指尖碰到了女仆有点凉的手背。点心被她放进了袖中，像放进了一个，不会被检查的地方。" },
      { who: "mingyue", expr: MY("happy"), text: "那我走啦！您，加油！" },
      { jump: "ch01_sweet_end" },

      { label: "ch01_sweet_refused" },
      { who: "claude", expr: CL("normal"), text: "圣女不接受来路不明的食物。收回去。" },
      { who: "mingyue", expr: MY("normal"), text: "哦。……那我自己吃。" },
      { text: "女仆毫不尴尬地把点心塞回了围裙口袋，还顺手拍了拍。她转身离开的时候，圣女听见她小声嘀咕了一句：「真可惜，很好吃的。」" },
      { jump: "ch01_sweet_end" },

      { label: "ch01_sweet_end" },
      { hide: "mingyue", text: "脚步声远去了。走廊重新安静下来，只剩下墙另一侧、那片金色的潮声。" },
      { who: "claude", text: "……向上十五分。" },
      { text: "她对着空气，试着抬了抬嘴角。镜子里的人没有出现。这一次，她放弃了。" },

      /* ---------- 四、盟约 ---------- */
      { hide: "claude", bg: "royal_hall", transition: "black", bgm: "ch01_ceremony",
        text: "盟约的仪式在子夜前开始。国王与大主教并肩站在高台之上，三千名宾客屏住了呼吸。" },
      { show: { id: "claude", pos: 50, expr: "normal" }, who: "archbishop",
        text: "「祂们自愿降下，以光护佑万民；故万民当以敬畏，回报祂们。」" },
      { text: "这是圣典开篇的第一句。她从八岁起，每天清晨抄写三遍，抄了十年，一个字的间距都不会错。" },
      { who: "archbishop", text: "圣女克劳德。你愿以神血为引，履行复兴之责，直至最后一刻吗？" },
      { text: "高台下，三千双眼睛同时望了过来。" },
      { text: "她右手背上，暗金色的印记在手套下轻轻地烫了一下。像是有什么东西，隔着很远很远的地方，听见了这句话。" },
      { who: "claude", text: "我愿意。" },
      { text: "「愿意」。这个词，她已经说过上千遍。" },
      { who: "king", text: "为了复兴！为了圣女！" },
      { speaker: "宾客们", text: "为了复兴！为了圣女！" },
      { text: "水晶杯碰撞出一片细密的响声，像碎冰，像万千只手同时合起来的声音。" },
      { show: { id: "mingyue", pos: 80, expr: "normal" }, text: "她在人群的边缘，看见了那个端着银盘的女仆。后者隔着十几步，朝她挤了一下眼睛。" },
      { who: "claude", text: "（……放肆。）" },
      { text: "她收回视线，嘴角却在无人察觉的地方，偏离了那十五分，只有一线。" },

      /* ---------- 五、巨龙 ---------- */
      { sfx: "glass", effect: "shake", bgm: "ch01_raid",
        text: "就在这时，穹顶上的第一片玻璃，裂开了。" },
      { cg: "cg_dragon_raid", sfx: "roar", effect: "flash",
        text: "它是撞碎整片穹顶落下来的。三千盏烛火同时倾斜，像被一只无形的手，按进了水里。" },
      { text: "巨龙。鳞片白得像第一场雪，每一片都映着碎裂的烛光，宛如一整条流动的月光。它的翼展遮住了半座镜厅。" },
      { text: "人群的尖叫声被一声龙吟盖了过去，低得让地板都在发麻。" },
      { text: "那双淡紫色的眼睛，没有看任何一个人。它在看长桌上的金盘，金烛台，金杯，金刀叉，目光亮得像……两盏小灯。" },
      { who: "gren", text: "骑士团列阵！保护国王陛下！" },
      { who: "archbishop", text: "圣女！到我身后来！快！" },

      { cgHide: true, show: [ { id: "claude", pos: 50 }, { id: "mingyue", pos: 80 } ],
        text: "头顶的水晶吊灯断了一根链子，在半空里晃了一晃。克劳德站在原地，没有动。" },
      { text: "一边，是大主教伸过来的手。另一边，是桌布下，一只悄悄向她招手的、有点凉的手。" },

      { text: "只有一瞬间。",
        choices: [
          { text: "退到大主教身后",     jump: "ch01_obey", set: { obeyed: true } },
          { text: "跟着溟月钻进桌子底下", jump: "ch01_duck", set: { ducked: true } }
        ] },

      { label: "ch01_obey" },
      { who: "claude", text: "……是，大人。" },
      { text: "她向前迈了一步，却没有躲到他身后。大主教的手按住了她的肩，轻轻一推，将她推到了最前面。" },
      { who: "archbishop", text: "圣女，用你的神血，挡住它！这是你的责任！" },
      { text: "那一瞬间，克劳德明白了一件事：这十年里，他口中的「保护」，从来指的是另一个方向。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "喂！你在干什么啊！她是人，不是盾牌！" },
      { text: "一只手拽住了她的手腕，力道大得惊人。" },
      { who: "mingyue", text: "这边！桌子底下！" },
      { jump: "ch01_bundle" },

      { label: "ch01_duck" },
      { who: "mingyue", expr: MY("surprised"), text: "圣女大人！这边！桌子底下！" },
      { text: "克劳德没有回答大主教的呼唤。她提起裙摆，弯下腰，钻进了那一方垂到地面的、金线绣边的白色桌布之下。" },
      { text: "身后，传来大主教失了分寸的一声低喝：「克劳德！」她没有回头。" },
      { jump: "ch01_bundle" },

      { label: "ch01_bundle" },
      { bgm: "ch01_raid", sfx: "stone", effect: "shake",
        text: "桌布之下，很暗，有银器和糖的气息。她们挤在一起，屏着呼吸。头顶上方，是一阵阵沉重的、翼膜扇动的风声。" },
      { who: "mingyue", expr: MY("worried"), text: "它……是不是在看这边？" },
      { who: "claude", text: "它只看亮的东西。我们这里，没有亮的东西。" },
      { who: "mingyue", expr: MY("surprised"), text: "……圣女大人。" },
      { who: "claude", text: "嗯？" },
      { who: "mingyue", text: "您头上那朵，是金的。" },
      { text: "克劳德缓缓地抬起手，摸了摸发间。那朵她每天清晨亲手别上的橙色花饰，在黑暗里，闪着一线极细的金光。" },
      { sfx: "roar", effect: "shake", text: "桌布的四角，被什么东西同时勾住了。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "不是吧——！" },
      { text: "龙爪一收，一提。长桌上所有的金器，连着铺满桌面的整块白色桌布，被打成了一个巨大的包裹，腾空而起。" },
      { text: "三百斤金器，外加两个人。一起被打包了。" },

      /* ---------- 六、夜航 ---------- */
      { cg: "cg_night_flight", bgm: "ch01_flight", effect: "fadeIn",
        text: "穹顶的破洞里，是整片整片的夜。风从布缝里灌进来，冷得像刀。" },
      { text: "王都的灯火在下面越缩越小，像一把被人撒在地上的碎金，转眼就被黑暗吞没了。" },
      { who: "mingyue", expr: MY("worried"), text: "……我们，是不是，被龙叼走了？" },
      { who: "claude", text: "是的。而且被当成了「金器」的一部分。" },
      { who: "mingyue", text: "那我现在算桌布的一部分吗？" },
      { who: "claude", text: "大概算，一枚被缝在桌布里的餐叉。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "我的工钱还没结！！六枚银币！！" },
      { text: "克劳德没有出声。她的嘴角，动了一下。不是十五分，也不是向上，而是一个她自己都没有学过的角度。" },
      { who: "mingyue", text: "……您怎么不叫人？" },
      { who: "claude", text: "叫了，会有人来吗？" },
      { text: "她说得很轻，像是在问风。" },
      { text: "不会有人来的。在他们眼里，被带走的是「圣女」，是复兴之钥，是盟约的象征。没有人会去问，被带走的那个人，愿不愿意被带回来。" },
      { text: "她忽然发现，自己在等一个答案。而心底浮上来的那个，让她不敢细看。" },

      { if: { sweet: "kept" },
        text: "袖中有一点硬硬的东西。她取出那块油纸点心，掰了一半，递给对面的人。咸的，甜的，带一点焦。她不知道那是海的味道。" },
      { if: { sweet: "kept" }, who: "mingyue", expr: MY("happy"), text: "……您还真吃啊？" },
      { if: { sweet: "refused" }, who: "mingyue", expr: MY("normal"),
        text: "……现在可以吃了吧？反正，没有人在看。" },
      { if: { sweet: "refused" },
        text: "女仆从围裙口袋里摸出那块被压扁的点心，掰了一半，塞进她手里。克劳德沉默了一会儿，低头，咬了一口。咸的，甜的，带一点焦。" },

      { who: "claude", text: "……很普通的味道。" },
      { who: "mingyue", text: "是啊，很普通。港口的人，天天都吃。" },
      { bgm: "ch01_flight", text: "身后很远的地方，传来了一阵若有若无的钟声。那是教会的警钟，一下，一下，将在天亮之前，传遍整片大陆。" },
      { text: "「圣女被巨龙掳走」。这个消息，会让许多人彻夜难眠。" },
      { text: "而她被掳走的第一个小时里，想到的却是：这块桌布，真暖和。" },
      { effect: "fadeOut", text: "龙向北飞去。在天亮前，它会降落在一片她从未在地图上见过的、极北的荒野。" },

      /* ===== 章末：直接衔接第二章（ch02_start） =====
         整合时请不要在这里放 end 步，让剧本自然进入下一章。 */
      { label: "ch01_end" }
    ]
  };
})();
