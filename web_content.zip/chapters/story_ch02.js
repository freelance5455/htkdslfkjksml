/* =====================================================
   story_ch02.js —— 第二章「荒原」（荒野与相遇）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch01_end 之后（ch01 以 fadeOut 黑屏结尾，本章以 fadeIn 开场）。
   ===================================================== */
window.STORY_CH02 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });

  return {

    addCharacters: {},
    addBackgrounds: {
      north_valley: { src: "assets/bg/north_valley.jpg",
                      color: "linear-gradient(180deg,#9fb4c8 0%,#dfe8ee 45%,#8a9aa6 75%,#4c5a64 100%)" },
      dragon_cave:  { src: "assets/bg/dragon_cave.jpg",
                      color: "radial-gradient(ellipse at 50% 70%,#8a6a22 0%,#2a2214 48%,#0a0806 100%)" }
    },
    addCgs: {
      cg_hoard: { src: "assets/cg/hoard.jpg",
                  color: "radial-gradient(ellipse at 50% 60%,#e0b64a 0%,#6a4e18 40%,#0c0904 100%)" }
    },
    addAudio: {
      bgm: {
        ch02_wild: "assets/audio/ch02_wild.mp3",
        ch02_cave: "assets/audio/ch02_cave.mp3",
        ch02_walk: "assets/audio/ch02_walk.mp3"
      },
      sfx: { coin: "assets/audio/coin.mp3" }
    },

    /* flag：
       bold: true            —— 在洞口选择直接现身（否则为 sneak: true，潜伏观察）
       coin: "kept"/"refused" —— 是否收下白泷赔礼的金币（可在第三章集市里当作盘缠）
    */

    script: [

      { label: "ch02_start" },
      { chapter: { no: "CHAPTER 02", title: "荒　原", sub: "THE WILDERNESS · 极北" } },

      /* ---------- 一、醒来 ---------- */
      { cgHide: true, hide: "all", bg: "north_valley", transition: "cut", bgm: "ch02_wild", effect: "fadeIn",
        text: "最先回来的是冷。然后是光，白得发蓝的光，从桌布的缝隙里一线一线地渗进来。" },
      { text: "有什么东西压在她的脸上，硬，凉，带着花纹。克劳德花了很久，才分辨出那是一只金烛台的底座。" },
      { show: [ { id: "mingyue", pos: 24, expr: "worried" }, { id: "claude", pos: 66, expr: "normal" } ],
        who: "mingyue", text: "……唔。圣女大人，您还活着吗？我好像，被一把金汤勺，扎到了屁股。" },
      { who: "claude", text: "还活着。而且很不幸，我枕着的是一只烛台。" },
      { text: "她们从金器堆里爬出来，像两只刚破壳的、不太体面的鸟。" },
      { text: "外面是一座雪谷。天刚刚亮，山脊被染成一线淡金，空气冷得每一次呼吸都像在吞冰碴。没有城，没有路，没有人烟。" },
      { who: "mingyue", expr: MY("surprised"), text: "……这是哪里？龙呢？" },
      { who: "claude", text: "它把我们放下就走了。大概，是去取下一批货。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "我们是「货」？！" },
      { text: "她们没有来得及争论这个称呼。雪谷深处，一道岩壁的裂缝里，透出了一线暖黄色的光。" },
      { who: "mingyue", text: "那里面，有声音。像是……有人在数东西。" },

      /* ---------- 抉择：现身 / 潜伏 ---------- */
      { text: "声音很轻，一下一下，带着一种近乎虔诚的节奏。裂缝里的光，是金色的。",
        choices: [
          { text: "悄悄靠近，先观察再说", jump: "ch02_sneak", set: { sneak: true } },
          { text: "直接走进去，问个明白", jump: "ch02_bold",  set: { bold: true } }
        ] },

      { label: "ch02_sneak" },
      { text: "她们贴着岩壁，一步一步挪到了裂缝边。溟月在前，克劳德在后，踩雪的声音，被她用裙摆压住了一半。" },
      { who: "mingyue", text: "（耳语）圣女大人，您的裙子太亮了，能不能……反着穿？" },
      { who: "claude", text: "（耳语）……我会考虑把它撕掉一半。" },
      { jump: "ch02_cave" },

      { label: "ch02_bold" },
      { who: "claude", expr: CL("serious"), text: "走吧。躲着，不如问清楚。" },
      { who: "mingyue", expr: MY("surprised"), text: "诶？可是，里面万一是……" },
      { who: "claude", text: "那就万一。至少，我想知道，是谁把我们当成了货物。" },
      { text: "这句话说出口的时候，连克劳德自己都愣了一下。这不是圣女该有的语气。" },
      { jump: "ch02_cave" },

      /* ---------- 二、龙巢 ---------- */
      { label: "ch02_cave" },
      { hide: "all", bg: "dragon_cave", transition: "black", bgm: "ch02_cave", cg: "cg_hoard",
        text: "岩缝的后面，是一座被金子填满的洞窟。金杯，金盘，金烛台，一层压着一层，在火把似的矿光里，像凝固的潮水。" },
      { text: "金山的顶端，坐着一个人。白发，几乎垂到了脚踝，头上是两只弯弯的角，背后，一对淡色的翼膜软软地耷拉着。" },
      { text: "她一枚一枚地数着手里的金币，神情专注得像在拆解一道关乎国运的难题。" },
      { speaker: "白发少女", text: "……三百一十二，三百一十三……少了一个。" },
      { speaker: "白发少女", text: "……少了一个金杯。是谁拿的。" },
      { text: "她抬起头，淡紫色的眼睛，穿过金山，落在了岩缝边的两个人身上。" },
      { cgHide: true, show: [ { id: "mingyue", pos: 24, expr: "surprised" }, { id: "claude", pos: 52, expr: "normal" }, { id: "bailong", pos: 80, expr: "normal" } ],
        who: "bailong", text: "……你们，在我的宝物里面。" },
      { who: "mingyue", expr: MY("surprised", "jump"), text: "是、是龙！她的眼睛，跟那只龙的一模一样！" },
      { who: "bailong", expr: BL("serious"), text: "那是我的。烛台。杯子。汤勺。都是我的。" },
      { text: "她的角，在昏暗中微微泛起一层冷光。那一瞬间，洞窟里的温度，似乎降了好几度。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "我们不是偷东西的！我们是被你叼来的人啊！" },
      { who: "bailong", expr: BL("surprised"), text: "……人？" },
      { who: "bailong", text: "桌布里，有人？" },
      { who: "claude", text: "有。两个。其中一个，被金汤勺扎了屁股。" },
      { who: "mingyue", expr: MY("shy", "shake"), text: "圣女大人！这种事不要说出来！" },

      /* ---------- 三、误会 ---------- */
      { text: "白发少女愣了很久。她低头，看看自己手里的金币，又看看岩缝边的人，慢慢地，露出了一种近乎崩溃的神情。" },
      { who: "bailong", expr: BL("surprised"), text: "我，以为，是金的。" },
      { who: "bailong", text: "桌布的边。是金色的。很亮。所以，一起拿了。" },
      { who: "mingyue", text: "那是金线绣边啊！！" },
      { who: "bailong", text: "……我不知道。龙，分不清金线和金子。" },
      { who: "claude", expr: CL("normal"), text: "你为什么要闯进王宫？那里有三千个人，还有骑士团。" },
      { who: "bailong", text: "那边，很亮。一整个晚上，都在亮。" },
      { who: "bailong", text: "春天的时候，龙族，要囤宝。不囤，会很难受。像……像想打嗝，却打不出来。" },
      { text: "说到「打嗝」的时候，她认真地比划了一下喉咙，眉头皱成了一个小小的结。" },
      { who: "mingyue", expr: MY("normal"), text: "……所以，你不是想吃了我们？" },
      { who: "bailong", text: "不吃。人，不好吃。有骨头。" },
      { text: "她说得太诚恳，诚恳到溟月不知道该不该松一口气。" },
      { text: "这时，克劳德才注意到，少女背后那对翼膜的内侧，有一道被什么划开的口子，渗着淡淡的、银蓝色的血。" },
      { who: "claude", text: "你的翅膀，受伤了。" },
      { who: "bailong", text: "……穿过玻璃的时候。划到的。不疼。" },
      { who: "bailong", text: "不对。有一点疼。" },
      { text: "克劳德没有再说什么。她撕下礼裙内衬的一圈白纱，蹲了下去。" },
      { text: "「圣女的手，只应该为祈祷而颤。」大主教的声音，在她脑海里响了一下，又很快消失了。" },
      { text: "此刻，这双手在包扎一只龙的翅膀。很稳，一点也没有抖。" },
      { who: "bailong", expr: BL("surprised"), text: "……暖的。" },
      { who: "claude", text: "纱布不是暖的。是你的血。" },
      { who: "bailong", text: "不是。是，手。" },

      /* ---------- 抉择：赔礼 ---------- */
      { text: "包扎完的时候，白发少女从金山上滑下来，捧着一枚拇指大的金币，认真地递到了克劳德面前。",
        choices: [
          { text: "收下这枚金币", jump: "ch02_coin_kept",    set: { coin: "kept" } },
          { text: "婉拒，请她收回去", jump: "ch02_coin_refused", set: { coin: "refused" } }
        ] },

      { label: "ch02_coin_kept" },
      { who: "bailong", text: "赔礼。把你们，弄进来的。" },
      { who: "claude", text: "……我收下了。它会派上用场。" },
      { sfx: "coin", text: "金币落进掌心，沉甸甸的。她把它放进了贴身的口袋，像放进了一个，足以支撑未来几天的小小底气。" },
      { who: "mingyue", expr: MY("happy"), text: "有钱了！我们可以买面包了！" },
      { jump: "ch02_coin_end" },

      { label: "ch02_coin_refused" },
      { who: "claude", text: "你留着吧。你囤积的东西，是你的。" },
      { who: "bailong", expr: BL("surprised"), text: "……你，不要？" },
      { who: "claude", text: "我只要你，别再把人当成桌布。" },
      { who: "bailong", text: "……嗯。我记住了。" },
      { text: "她把金币收回怀里，但那只手，在半空里停了一会儿，才慢慢地合拢。" },
      { jump: "ch02_coin_end" },

      { label: "ch02_coin_end" },
      { bgm: "ch02_walk", text: "洞窟外，雪谷的风，渐渐小了。" },

      /* ---------- 四、结伴 ---------- */
      { who: "mingyue", expr: MY("normal"), text: "那……你要送我们回去吗？回王都？" },
      { who: "bailong", text: "……回不去。翅膀，要三天才能好。而且……" },
      { who: "bailong", text: "我不认识，回去的路。" },
      { who: "mingyue", expr: MY("surprised"), text: "你不认识路！？你一只龙，把我们带到天边，却不认识回去的路！？" },
      { who: "bailong", text: "……我是顺着亮的东西，飞过来的。" },
      { who: "claude", text: "也就是说，我们现在，在一座不知名的雪谷里，身边是一只受伤的、不认路的龙。" },
      { who: "mingyue", text: "还有一个没结算的月工钱。" },
      { text: "沉默持续了片刻。然后，克劳德忽然轻轻笑了一下。不是十五分，是一个她自己都没有预料到的、很短的弧度。" },
      { who: "claude", expr: CL("smile"), text: "没有人会来找我们。至少，三天之内不会。" },
      { text: "说出这句话的瞬间，她意识到，自己并没有觉得，那是坏事。" },
      { who: "bailong", text: "往南，有很多人。很吵。有烟。我飞过的时候，看见了。" },
      { who: "mingyue", text: "人类的聚落！那就往南走！边走边想办法！" },
      { who: "bailong", text: "我跟你们走。翅膀好之前。" },
      { who: "mingyue", text: "你要当我们的货物吗？" },
      { who: "bailong", text: "……不。是，同伴。货物，要自己看好。" },
      { who: "claude", text: "我们不是货物。" },
      { who: "bailong", text: "嗯。同伴。" },
      { text: "她认真地点了点头，又回头看了一眼那座金山，很艰难地、很缓慢地，把视线收了回来。" },
      { who: "bailong", text: "……我可以，带一点吗？" },
      { who: "mingyue", expr: MY("angry"), text: "不可以！！" },
      { who: "bailong", text: "……一枚。一枚就好。" },
      { text: "最后，她的怀里，多了一枚被她攥得发烫的小金币。三个人，沿着雪谷，朝南走去。" },
      { text: "身后，是一座无人看守的金山。前方，是一整个，她们谁也没有见过的世界。" },
      { effect: "fadeOut", text: "雪，悄悄地落了下来。" },

      /* ===== 章末：衔接第三章（ch03_start），下一章以 fadeIn 开场 ===== */
      { label: "ch02_end" }
    ]
  };
})();
