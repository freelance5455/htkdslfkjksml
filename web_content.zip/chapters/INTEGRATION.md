# 章节整合说明（给整合者 / GPT）

**原则：不改游戏本体**（index.html / style.css / script.js 一律不动），只改 `story.js`。

## 每个章节文件的结构
`chapters/story_chXX.js` 定义 `window.STORY_CHXX = { addCharacters, addBackgrounds, addCgs, addAudio, script }`：

| 字段 | 合并到 story.js 的位置 |
|---|---|
| `addCharacters` | 并入 `characters` |
| `addBackgrounds` | 并入 `backgrounds` |
| `addCgs` | 并入 `cgs` |
| `addAudio.bgm / .sfx` | 并入 `audio.bgm / audio.sfx` |
| `script`（数组） | 按章节顺序，放在 `story.js` 的 `script` 数组**最前面**（第六章之前） |

章节文件自带 CL / MY / BL 小工具（在函数内部），不依赖 story.js，所以整合时可以直接把 `script` 数组里的内容复制过去；如果复制后出现 `CL(...)` 等未定义，请改用 story.js 顶部已有的同名工具。

## 衔接约定
- 每章第一步是 `{ label: "chXX_start" }`，最后一步是 `{ label: "chXX_end" }`，章节之间**不放 end 步**，自然顺序进入下一章。
- 所有 label 带章节前缀，不会和第六章（A_start、B1、CAMP …）重名。
- 一章结尾若用了 `effect: "fadeOut"`（黑屏），下一章第一个内容步会用 `effect: "fadeIn"` 或 `bg` 转场接上；若结尾有 CG，下一章会 `cgHide`。
- 第六章开头有 5 步「前情提要」（第一个 `chapter` 步之前）。**前五章齐全后可以删掉**，那是为了第六章单独成篇才写的。

## 可选：自动合并工具
```
cd chapters
node merge_chapters.js ch01 ch02        # 按顺序合并，输出 ../story.merged.js
node merge_chapters.js ch01 ch02 ch03 ch04 ch05 --drop-recap
```
注意：输出是 JSON 风格，会丢失 story.js 的注释和 CL/MY/BL 小工具。需要保留注释就手动合并。合并后把 `story.merged.js` 改名为 `story.js` 即可，`index.html` 不用动。

## flag 总表（持续更新）
| flag | 来源 | 含义 |
|---|---|---|
| `sweet` = `"kept"` / `"refused"` | ch01 | 是否收下溟月的海盐焦糖 |
| `obeyed` / `ducked` | ch01 | 龙袭时听从大主教 / 跟溟月钻桌子 |
| `sneak` / `bold` | ch02 | 洞口选择潜伏观察 / 直接现身 |
| `coin` = `"kept"` / `"refused"` | ch02 | 是否收下白泷赔礼的金币（第三章集市可当盘缠） |
| `haggle` = `"hard"` / `"fair"` | ch03 | 集市砍价方式 |
| `poster` = `"torn"` / `"left"` | ch03 | 是否撕下悬赏告示（土豆画像） |
| `guide` = `"mingyue"` / `"bailong"` | ch04 | 雾中听谁的指引 |
| `mural` = `"order"` / `"scar"` | ch04 | 先按顺序读壁画 / 先看被凿去的一段（scar 线发现凿痕残留半枚日轮纹样） |
| `answer` = `"truth"` / `"silent"` | ch05 | 七嫂问话时克劳德说实话 / 沉默 |
| `night` = `"nets"` / `"pier"` | ch05 | 夜里陪老舵补网（听身世） / 去海边找溟月（听她亲口讲） |
| `route` = A/B/C，`touched`、`sang`、`exposed`、`trusted`、`decoy`、`saved` | ch06 | 见 NOTES.md |

## 素材 id（新增，素材可以之后再补，缺失时自动占位）
- ch01 背景：royal_hall、service_corridor；CG：cg_dragon_raid、cg_night_flight
- ch01 BGM：ch01_banquet、ch01_ceremony、ch01_raid、ch01_flight；SFX：glass、roar（另外用到第六章已有的 stone）
- ch01 新人物（无立绘）：archbishop 佩尔图斯、king 奥古斯特、gren 格伦
- ch02 背景：north_valley、dragon_cave；CG：cg_hoard；BGM：ch02_wild、ch02_cave、ch02_walk；SFX：coin
- 衔接：ch02 以 `fadeOut` 黑屏结尾，ch03 第一个内容步需 `effect:"fadeIn"`
- ch03 背景：border_gate、market_square、inn_room；CG：cg_market；BGM：ch03_market、ch03_inn；SFX：bite
- ch03 依赖 story.js 里的 raymond / oli（第六章已定义）；ch03 以 `fadeOut` 结尾，ch04 以 `fadeIn` 开场
- ch04 背景：mist_valley、ruin_hall；CG：cg_mural；BGM：ch04_mist、ch04_mural；SFX：whisper
- ch04 以 `fadeOut` 结尾，ch05 以 `fadeIn` 开场
- ch05 新人物（无立绘）：qisao 七嫂、laoduo 老舵；背景：harbor_dusk、pier_night、cairn_shore；CG：cg_long_table；BGM：ch05_harbor、ch05_table、ch05_night；SFX：gull
- ch05 以 `fadeOut` 结尾，直接衔接第六章（离港告别，`bg: harbor_dawn` 转场）；前五章齐全后，第六章开头 5 步「前情提要」可删除
