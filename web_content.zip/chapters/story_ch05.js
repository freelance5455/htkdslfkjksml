/* =====================================================
   story_ch05.js —— 第五章「百家饭」（海滨港口与溟月身世）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch04_end 之后（ch04 以 fadeOut 黑屏结尾，本章以 fadeIn 开场）。
   本章结尾（夜里缝百家布包袱、压海芙蓉）直接衔接第六章开头的离港告别。
   整合时：前五章齐全后，第六章开头 5 步「前情提要」可以删掉。
   ===================================================== */
window.STORY_CH05 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });

  return {

    addCharacters: {
      qisao:  { name: "七嫂", title: "港口邻居", color: "#d9a07a" },
      laoduo: { name: "老舵", title: "老渔夫",   color: "#9fb4a0" }
    },
    addBackgrounds: {
      harbor_dusk: { src: "assets/bg/harbor_dusk.jpg",
                     color: "linear-gradient(180deg,#2a3a52 0%,#8a6a5a 52%,#e0a060 80%,#2a2a2e 100%)" },
      pier_night:  { src: "assets/bg/pier_night.jpg",
                     color: "linear-gradient(180deg,#06090f 0%,#13203a 60%,#1c2c44 100%)" },
      cairn_shore: { src: "assets/bg/cairn_shore.jpg",
                     color: "linear-gradient(180deg,#0e1624 0%,#2a3a50 55%,#14181c 100%)" }
    },
    addCgs: {
      cg_long_table: { src: "assets/cg/long_table.jpg",
                       color: "linear-gradient(180deg,#3a2a18 0%,#c88a4a 45%,#5a3a1a 100%)" }
    },
    addAudio: {
      bgm: { ch05_harbor: "assets/audio/ch05_harbor.mp3", ch05_table: "assets/audio/ch05_table.mp3", ch05_night: "assets/audio/ch05_night.mp3" },
      sfx: { gull: "assets/audio/gull.mp3" }
    },

    /* flag：
       answer: "truth" / "silent"   —— 七嫂问「是离家出走吧」时克劳德怎么回答
       night:  "nets" / "pier"      —— 夜里陪老舵补网，还是陪溟月去码头
       （poster 来自第三章：撕下过告示的话，克劳德在码头把它放进海里）
    */

    script: [

      { label: "ch05_start" },
      { chapter: { no: "CHAPTER 05", title: "百家饭", sub: "THE HARBOR · 海边的小港口" } },

      /* ---------- 一、闻到海 ---------- */
      { hide: "all", bg: "harbor_dusk", transition: "cut", bgm: "ch05_harbor", effect: "fadeIn",
        text: "是白泷先闻到的。她停下脚步，鼻翼动了两下，认真地宣布：" },
      { show: [ { id: "mingyue", pos: 22, expr: "normal" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
        who: "bailong", text: "咸的。还有，鱼。还有，很多，很多的烟。" },
      { who: "mingyue", expr: MY("surprised"), text: "……到了？" },
      { text: "山路在这里转了个弯，眼前豁然开朗。" },
      { text: "一片灰蓝色的海，在暮色里铺开，一直铺到天的边缘。海边，是一座依着山势挤在一起的小港口：低矮的石屋，晾满了鱼干的竹架，歪歪斜斜的桅杆，像一片被风吹乱了的芦苇。" },
      { sfx: "gull", text: "几只海鸥，从桅杆上飞起来，叫得理直气壮，像在抱怨，来的人太晚了。" },
      { who: "mingyue", expr: MY("normal"), text: "……我，离开了五年。" },
      { who: "mingyue", text: "港口，一点都没变。连那根歪掉的桅杆，都还是歪的。" },
      { text: "她说得很轻。克劳德第一次发现，这个总是吵吵嚷嚷的女仆，在面对自己的故乡时，竟然，有一点不知所措。" },

      /* ---------- 二、归来 ---------- */
      { text: "她们刚走到码头的石阶，就有人，看见了她。" },
      { speaker: "渔妇", text: "……那是，溟月丫头？" },
      { speaker: "渔夫", text: "溟月？是溟月吗？！老舵！老舵！你家那个，拖着鼻涕蹭饭的丫头，回来了！" },
      { who: "mingyue", expr: MY("surprised", "jump"), text: "诶？！不、不要这样喊啊！" },
      { text: "只是几息的功夫，整座港口像被人拨动了一根弦。屋门一扇一扇地打开，晾鱼的、补网的、抱着孩子的，全都涌了出来，把石阶围得水泄不通。" },
      { text: "人群里，有渔民，有水手，有扎着围裙的妇人。有人头上长着一对猫耳，有人手背上覆着细细的鳞，一个蜥蜴模样的亚人鱼贩，正嚷嚷着要把鱼头留给她。" },
      { text: "他们混在一起，说着同样的方言，骂着同样的天气。没有人去数，谁的血里，流着什么。" },
      { speaker: "老舵", text: "……瘦了。" },
      { text: "一位须发花白的老人，从人群后面，慢慢地走了出来。他叼着一只没点火的烟斗，嘴唇动了好几下，最后，只憋出了这么一个字。" },
      { who: "mingyue", expr: MY("shy"), text: "……老舵叔。我，回来了。" },
      { speaker: "老舵", text: "嗯。回来就好。饭，还热着。" },
      { text: "这就是全部的「欢迎」了。没有拥抱，没有眼泪。只是，那只烟斗，在他嘴里，抖了一下。" },
      { who: "mingyue", text: "……（吸鼻子）才、才没有哭！是海风！" },

      /* ---------- 三、介绍 ---------- */
      { speaker: "七嫂", text: "这两位姑娘，是你带回来的？" },
      { who: "mingyue", expr: MY("normal"), text: "是！我的朋友！这位是……克、克莱！这位，是白泷！" },
      { text: "克劳德被这个仓促的新名字，噎了一下。「克莱」。听上去，像一块路边捡来的石头。" },
      { who: "claude", expr: CL("normal"), text: "……承蒙关照。" },
      { speaker: "七嫂", text: "哎呀，这姑娘说话，真好听。像教堂里念书的。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "她就是，念过几年书！！" },
      { text: "七嫂并没有追问。她只是打量了克劳德一眼，又打量了白泷一眼，然后，伸手，把两个人，一起拽进了人群。" },
      { speaker: "七嫂", text: "瘦的，都瘦的。来，进屋，吃饭。今晚，谁也别想饿着肚子回去睡觉。" },

      /* ---------- 四、百家席 ---------- */
      { hide: "all", cg: "cg_long_table", bgm: "ch05_table",
        text: "那一夜，港口摆了一张，很长很长的桌子。" },
      { text: "是用各家的门板、木箱、晒鱼的架子，一块一块拼出来的。从码头，一直铺到了街尾。每一户人家，都端了一样东西出来。" },
      { text: "咸鱼汤，烤章鱼，炖得烂熟的海带，一盆没人认得出配方的杂鱼羹，还有，十几种口味完全不同的腌菜。" },
      { text: "这叫「百家席」。港口的规矩：谁家的孩子，出了远门，又回来了，就要在街上，摆一次。" },
      { text: "每个人，都往她的碗里，夹一筷子。夹的是菜，也是，把「你是我们的人」这句话，一筷子一筷子地，盛进碗里。" },
      { cgHide: true, bg: "harbor_dusk", transition: "cut",
        who: "claude", expr: CL("surprised"), text: "……这，要，怎么吃？" },
      { who: "mingyue", text: "用手！用筷子！用勺子！随便！只要，别让碗，空着！" },
      { text: "克劳德低头，看着自己的碗。里面堆满了不同人家的菜，一勺堆在另一勺上面，汤汁，漫了出来，浸湿了手指。" },
      { text: "她第一次，没有人教她，先动哪一样。" },
      { who: "bailong", text: "……这个，贝壳，是什么？" },
      { speaker: "七嫂", text: "那是蛤蜊！里面有肉的！拿牙，咬开！" },
      { text: "白泷盯着手里的蛤蜊壳，看了很久，最后，认真地，用牙把它咬碎了，连壳一起，咽了下去。" },
      { who: "mingyue", expr: MY("surprised"), text: "壳不要吃啊！！" },
      { who: "bailong", text: "……脆的。好吃。亮的。" },
      { speaker: "七嫂", text: "这姑娘，好养活！" },

      /* ---------- 抉择：七嫂的问话 ---------- */
      { text: "夜深了，宴席渐渐散去。七嫂坐到了克劳德身边，往她的碗里，又舀了一勺汤。",
        choices: [
          { text: "说出一部分实话", jump: "ch05_answer_truth", set: { answer: "truth" } },
          { text: "只是低头喝汤",   jump: "ch05_answer_silent", set: { answer: "silent" } }
        ] },

      { label: "ch05_answer_truth" },
      { speaker: "七嫂", text: "姑娘。你不是，普通人家的孩子吧。是，离家出走的？" },
      { who: "claude", text: "……我，从一个很大的地方，出来了。那里，没有人，会让我走。" },
      { speaker: "七嫂", text: "哦。那，你是，在逃吧。" },
      { who: "claude", text: "……我一直，以为是。" },
      { jump: "ch05_answer_end" },

      { label: "ch05_answer_silent" },
      { speaker: "七嫂", text: "姑娘。你不是，普通人家的孩子吧。" },
      { text: "克劳德低着头，没有说话，只是，把那勺汤，一口一口地，喝了下去。" },
      { speaker: "七嫂", text: "不想说，就不说。汤，喝完了，再添。" },
      { text: "她的鼻子，忽然有一点酸。这十年里，所有人，都要她，回答问题。从来没有人，对她说过，「不想说，就不说」。" },
      { jump: "ch05_answer_end" },

      { label: "ch05_answer_end" },
      { speaker: "七嫂", text: "我家的娃，也出过远门。哪个孩子，没离过家？饿了，就回来吃饭。门，一直开着。" },
      { who: "claude", expr: CL("normal"), text: "……「离家」，和「逃」，不一样吗？" },
      { speaker: "七嫂", text: "怎么不一样？「逃」，是怕。「出门」，是想看看。你呀，是想看看的。" },
      { text: "克劳德怔怔地，看着碗里的汤。汤面上，倒映着一盏，晃动的灯。" },
      { text: "「想看看的。」她在心里，把这三个字，慢慢地，念了一遍。像在舌根底下，把一个压了很久的词，轻轻地，换了出来。" },

      /* ---------- 抉择：夜里 ---------- */
      { text: "宴席散去，溟月的身影，已经不在桌边了。老舵正蹲在码头边，借着月光，补一张破网。",
        choices: [
          { text: "陪老舵补网，听他说", jump: "ch05_night_nets", set: { night: "nets" } },
          { text: "去海边，找溟月",     jump: "ch05_night_pier", set: { night: "pier" } }
        ] },

      /* ---- A：补网 ---- */
      { label: "ch05_night_nets" },
      { hide: "all", bg: "pier_night", transition: "black", bgm: "ch05_night",
        text: "老舵没有抬头。他的手指粗糙得像礁石，却把一根细细的线，穿得又快又稳。" },
      { show: { id: "claude", pos: 34, expr: "normal" },
        who: "claude", text: "……我能帮忙吗？" },
      { speaker: "老舵", text: "会打结吗？" },
      { who: "claude", text: "……不会。" },
      { speaker: "老舵", text: "那，递线。" },
      { text: "她蹲下来，笨拙地，把一根又一根线头，递到他的手里。月光，落在两个人的手上。" },
      { speaker: "老舵", text: "那丫头，是个鱼筐里捡来的孩子。" },
      { speaker: "老舵", text: "二十年前，一个起风暴的夜里。阿潮，她的养父，收了网，网里，没有鱼，只有，一个蜷着的小东西。" },
      { speaker: "老舵", text: "不是人，也不是鱼。一对耳朵，像鳍。一条尾巴，像小鲸的。哭起来，像是在唱歌。" },
      { who: "claude", text: "……养父，是渔夫？" },
      { speaker: "老舵", text: "阿潮和阿梅两口子，都是好人。没孩子。抱回去，养了。养了七年。" },
      { speaker: "老舵", text: "那年冬天，他们的船，没有回来。" },
      { text: "他把一根线，咬断了。烟斗，没有点火，在他嘴里，慢慢地，转了半圈。" },
      { speaker: "老舵", text: "那丫头，才八岁。站在码头上，从天亮，站到天黑。谁拉她，她也不走。" },
      { speaker: "老舵", text: "后来，她饿得，晕过去了。是七嫂，把她抱回去的。" },
      { speaker: "老舵", text: "再后来，今天，她吃我家的饭。明天，吃七嫂家的。后天，吃隔壁的。" },
      { speaker: "老舵", text: "吃了一百家的饭。长大了。" },
      { who: "claude", text: "……「百家饭」。" },
      { speaker: "老舵", text: "嗯。她说，她这辈子，欠了一百家人情。要还。所以，才去的王都。" },
      { text: "海浪，一下一下，拍着码头的石桩。克劳德忽然，很想知道，自己的名字，是被多少人，念过。" },
      { speaker: "老舵", text: "姑娘。丫头回来之后，话变多了。你是第一个，她肯带回来的朋友。" },
      { who: "claude", text: "……我，不太会，做朋友。" },
      { speaker: "老舵", text: "不用会。陪着，就行。" },
      { jump: "ch05_night_end" },

      /* ---- B：码头 ---- */
      { label: "ch05_night_pier" },
      { hide: "all", bg: "cairn_shore", transition: "black", bgm: "ch05_night",
        text: "溟月坐在海边的一块礁石上，面前，是一座没有名字的石堆。石堆旁，插着一块半朽的船板。" },
      { show: [ { id: "mingyue", pos: 28, expr: "normal" }, { id: "claude", pos: 66, expr: "normal" } ],
        who: "mingyue", text: "……您，怎么找到这里的？" },
      { who: "claude", text: "七嫂指的路。" },
      { who: "mingyue", expr: MY("shy"), text: "多嘴的老太太……" },
      { text: "克劳德在她身边坐下。海风，把她们的头发，吹得缠在了一起。" },
      { who: "mingyue", text: "这是我，养父母的，墓。没有尸体。船，没有回来。所以，就用船板，垒了一个。" },
      { who: "mingyue", text: "我是，鱼筐里捡来的。阿潮爸爸的网里，捞上来的。" },
      { who: "mingyue", text: "不是人，也不是鱼。哭起来，像唱歌。阿梅妈妈说，我哼的调子，不是人间的调子。" },
      { who: "claude", text: "……那是什么调子？" },
      { who: "mingyue", expr: MY("worried"), text: "不知道。她说，听上去像很远很远的、水下面的歌。" },
      { who: "mingyue", text: "那年冬天，他们的船，没有回来。我站在码头上，站了一天。后来，是七嫂，把我抱回去的。" },
      { who: "mingyue", text: "再后来，我吃了一百家的饭。一百家哦！" },
      { text: "她笑了一下，眼睛却红了。像一只想要装作很凶的小兽。" },
      { who: "mingyue", expr: MY("normal"), text: "所以，我去王都，打工。我想，把这些，一家一家，还回来。" },
      { who: "claude", text: "……你，辛苦了。" },
      { who: "mingyue", expr: MY("surprised"), text: "……诶？" },
      { who: "claude", text: "不是圣女，对信徒说的话。是，克劳德，对溟月。" },
      { text: "溟月愣了很久。久到海浪，拍了三次礁石。然后，她把脸，埋进了膝盖。肩膀，轻轻地，抖了起来。" },
      { who: "mingyue", text: "……（哭腔）才、才不是，因为，你这句话！是风！风，太大了！" },
      { who: "claude", text: "嗯。风，很大。" },
      { jump: "ch05_night_end" },

      /* ---------- 五、完成蜕变 ---------- */
      { label: "ch05_night_end" },
      { hide: "all", bg: "cairn_shore", transition: "cut", show: { id: "claude", pos: 50, expr: "normal" },
        text: "夜很深了。克劳德一个人，站在海边。海风，把她的衣角，吹得猎猎作响。" },

      { if: { poster: "torn" },
        text: "她从斗篷的内袋里，取出了那张折了四折的悬赏告示。展开，那颗土豆，在月光里，依旧圆滚滚的。" },
      { if: { poster: "torn" }, who: "claude", text: "……再见了，土豆。" },
      { if: { poster: "torn" }, text: "纸，落进了海里。被一个浪，卷着，打了几个转，慢慢地，沉了下去。" },

      { text: "她摸了摸右手背，那里，暗金色的印记，在黑暗里，安静地亮着，像一枚，沉睡的小太阳。" },
      { text: "「圣女」。「神血」。「复兴」。十年里，这些词，像三道锁，把她的名字，一圈一圈地，缠了起来。" },
      { text: "而今晚，她被叫成「克莱」。被一个陌生的老妇人，往碗里，舀了三勺汤。" },
      { who: "claude", text: "我，不是，在逃。" },
      { text: "她对着海，轻轻地，说出了这句话。像是在宣布一件，只有海，才有资格，听见的事。" },
      { who: "claude", expr: CL("smile"), text: "我是，出来看看的。" },
      { text: "海，没有回答。只是，一浪一浪，温柔地，涌了上来，又退了下去。像一个，很有耐心的，老人。" },

      /* ---------- 六、最后的夜 ---------- */
      { show: [ { id: "mingyue", pos: 24, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
        bgm: "ch05_night", who: "mingyue", text: "……您，还没睡？" },
      { who: "claude", text: "睡不着。你呢？" },
      { who: "mingyue", text: "我也是。……明天，我们，就走了。" },
      { who: "mingyue", expr: MY("worried"), text: "其实，我有点，怕。怕，再走一次，就更舍不得了。" },
      { who: "claude", text: "那，不走？" },
      { who: "mingyue", expr: MY("angry"), text: "不行！我欠了一百家的人情！还没还完！我得，出去，赚更多的钱！" },
      { who: "mingyue", text: "……而且，您，和白泷，还需要，我。" },
      { who: "bailong", text: "需要。你，会砍价。会洗碗。会，管着我。" },
      { who: "mingyue", expr: MY("shy", "shake"), text: "这、这些，才不是，什么，值得夸的事情！" },
      { text: "港口里，有人，还在远远地，唱着一支走了调的渔歌。三个人，没有再说话，只是，并排坐着，看着海。" },

      { text: "第二天清晨，七嫂，天不亮，就起来了。" },
      { speaker: "七嫂", text: "丫头，你的包袱，我替你，缝好了。每家，都出了一块布。你，别嫌，花哨。" },
      { text: "她把一只用百家布缝成的包袱，塞进了溟月的怀里。每一块补丁，都是一户人家的，一个念想。" },
      { who: "mingyue", expr: MY("surprised"), text: "……这里面，是，妈妈的，头巾。" },
      { speaker: "七嫂", text: "你阿梅妈妈的。我，一直，替你，收着。" },
      { text: "溟月把包袱，抱得很紧。这一次，她没有说「才没有哭」。" },

      { text: "海边的堤上，开着一丛，粉白色的海芙蓉。溟月摘了一朵，不由分说，塞进了克劳德怀里的圣典。" },
      { who: "mingyue", expr: MY("happy"), text: "圣女大人，也该，有点颜色！" },
      { who: "claude", expr: CL("smile"), text: "……书页，会被压皱。" },
      { who: "mingyue", text: "那就让它，皱！书，本来，就是用来，夹花的！" },
      { text: "克劳德低头，看着书页间那朵小小的花。过了很久，她轻轻地，合上了圣典。这一次，合得很轻。" },

      { effect: "fadeOut", text: "码头上，已经，站满了，送行的人。" },

      /* ===== 章末：直接衔接第六章（离港告别）。
         整合提示：第六章开头的 5 步「前情提要」，可在前五章齐全后删除。 ===== */
      { label: "ch05_end" }
    ]
  };
})();
