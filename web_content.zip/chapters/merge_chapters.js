/* 可选工具：把 story_chXX.js 合并进 story.js，输出 ../story.merged.js
   用法：  node merge_chapters.js ch01 ch02 ch03 [--drop-recap]
   - 章节按命令行顺序排在 story.js 现有剧本（第六章）之前
   - --drop-recap：删掉第六章开头的「前情提要」（第一个 chapter 步之前的内容），前五章齐全后建议使用
   - 注意：输出是机器生成的 JSON 风格，会丢失 story.js 里的注释和 CL/MY/BL 小工具。
     想保留注释的话，请不要用本工具，按 INTEGRATION.md 手动合并。
*/
const fs = require('fs'), vm = require('vm'), path = require('path');
const args = process.argv.slice(2), drop = args.includes('--drop-recap');
const chs = args.filter(a => !a.startsWith('--'));
const root = path.join(__dirname, '..');
const load = (file, expr) => { const c = { window: {} }; vm.createContext(c); vm.runInContext(fs.readFileSync(file, 'utf8') + ';this.R=' + expr, c); return JSON.parse(JSON.stringify(c.R)); };
const base = load(path.join(root, 'story.js'), 'window.STORY');
let pre = [];
for (const c of chs) {
  const ch = load(path.join(__dirname, `story_${c}.js`), 'Object.values(window)[0]');
  Object.assign(base.characters, ch.addCharacters || {});
  Object.assign(base.backgrounds, ch.addBackgrounds || {});
  Object.assign(base.cgs, ch.addCgs || {});
  if (ch.addAudio) { Object.assign(base.audio.bgm, ch.addAudio.bgm || {}); Object.assign(base.audio.sfx, ch.addAudio.sfx || {}); }
  pre = pre.concat(ch.script);
}
if (drop) { const i = base.script.findIndex(s => s.chapter); if (i > 0) base.script.splice(0, i); }
base.script = pre.concat(base.script);
fs.writeFileSync(path.join(root, 'story.merged.js'), 'window.STORY = ' + JSON.stringify(base, null, 2) + ';\n');
console.log('已生成 story.merged.js，总步数', base.script.length);
