/* =====================================================
   story_ch03.js —— 第三章「人间烟火」（边境重镇）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch02_end 之后（ch02 以 fadeOut 黑屏结尾，本章以 fadeIn 开场）。
   依赖：角色 raymond / oli 已在 story.js 的 characters 里定义（第六章），本章不重复定义。
   ===================================================== */
window.STORY_CH03 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });

  return {

    addCharacters: {},
    addBackgrounds: {
      border_gate:   { src: "assets/bg/border_gate.jpg",
                       color: "linear-gradient(180deg,#8a9aa6 0%,#c9c2b0 50%,#6a5a46 100%)" },
      market_square: { src: "assets/bg/market_square.jpg",
                       color: "linear-gradient(180deg,#b8a58a 0%,#d9c9a8 45%,#7a5c3a 100%)" },
      inn_room:      { src: "assets/bg/inn_room.jpg",
                       color: "radial-gradient(ellipse at 30% 60%,#6a4a28 0%,#241a12 50%,#0b0806 100%)" }
    },
    addCgs: {
      cg_market: { src: "assets/cg/market.jpg",
                   color: "linear-gradient(180deg,#e0c890 0%,#a8804a 50%,#3a2812 100%)" }
    },
    addAudio: {
      bgm: { ch03_market: "assets/audio/ch03_market.mp3", ch03_inn: "assets/audio/ch03_inn.mp3" },
      sfx: { bite: "assets/audio/bite.mp3" }
    },

    /* flag：
       haggle: "hard" / "fair"        —— 集市砍价的方式
       poster: "torn" / "left"        —— 是否撕下悬赏告示
       （coin 来自第二章：影响付钱那一段）
    */

    script: [

      { label: "ch03_start" },
      { chapter: { no: "CHAPTER 03", title: "人间烟火", sub: "THE BORDER TOWN · 石楔镇" } },

      /* ---------- 一、镇门 ---------- */
      { hide: "all", bg: "border_gate", transition: "cut", bgm: "ch03_market", effect: "fadeIn",
        text: "第四天的正午，雪线退到了身后。路的尽头，一座灰色的小镇蹲在山口，像一块被风吹到这里的、不肯走的石头。" },
      { text: "石楔镇。王国最北的边境重镇。门口的木牌被风雨磨得看不清字，倒是旁边那只拴着的山羊，嚼得格外起劲。" },
      { show: [ { id: "mingyue", pos: 22, expr: "normal" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
        who: "mingyue", text: "听好了！这里的人没见过龙，也没见过圣女，所以，我们要学会「普通」！" },
      { who: "claude", text: "「普通」，该怎么做？" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "首先，你们两个，把自己遮起来！" },
      { text: "白泷的角被一顶旧毡帽压住，翼膜被折得整整齐齐，塞进一件宽大的灰斗篷里，只剩尾巴尖，不安分地在裙摆下摇来摇去。" },
      { who: "bailong", text: "……痒。" },
      { who: "mingyue", text: "忍着！进了镇子，不许说「亮的」！不许说「收起来」！" },
      { who: "bailong", text: "……嗯。" },
      { text: "克劳德把一头橙色长发，用溟月的围裙带子胡乱扎在脑后，再披上一件从路边驿站「借」来的灰斗篷。镜子里的人，普通得像一杯白开水。" },
      { text: "她摸了摸嘴角。很好，没有十五分。" },

      /* ---------- 二、告示 ---------- */
      { text: "镇门内侧的木板上，钉着一张新贴的告示。纸角还卷着，墨迹未干。" },
      { text: "「教会急告：圣女克劳德，疑遭巨龙掳走，下落不明。凡提供确切线索者，赏金币五十枚。」" },
      { text: "告示下方，画着一幅肖像：一颗圆滚滚的土豆，上面插着两缕橙色的草，土豆的中央，用炭笔点了两个小黑点，还有一条歪歪扭扭的嘴。" },
      { who: "mingyue", expr: MY("surprised"), text: "……这，是您？" },
      { who: "claude", expr: CL("normal"), text: "……据说，是。" },
      { who: "bailong", text: "像，土豆。" },
      { who: "mingyue", expr: MY("shy"), text: "噗……不行，我要忍住……" },
      { text: "克劳德盯着那颗「自己」，沉默了很久。十年里，她的画像挂满了王国所有的教堂，每一幅都是正脸，微笑，光轮，十五分的弧度。" },
      { text: "而此刻，这是她见过的、最丑，也最像人的一张。" },

      { text: "告示还钉在那里。她的手指，停在了木板的边缘。",
        choices: [
          { text: "把告示撕下来，揣进怀里", jump: "ch03_poster_torn", set: { poster: "torn" } },
          { text: "就这样留着，转身离开",   jump: "ch03_poster_left", set: { poster: "left" } }
        ] },

      { label: "ch03_poster_torn" },
      { text: "「嘶——」一声轻响。纸被她撕了下来，折成四折，塞进了斗篷的内袋。" },
      { who: "mingyue", expr: MY("surprised"), text: "您撕它做什么？" },
      { who: "claude", text: "它画得太丑了。我不想让别人，把它当成我。" },
      { jump: "ch03_poster_end" },

      { label: "ch03_poster_left" },
      { text: "她收回了手，什么也没有做。一阵风吹过来，那颗土豆，随着纸角，轻轻晃了晃。" },
      { who: "claude", text: "……就让它挂着吧。至少，它不会被任何人认出来。" },
      { jump: "ch03_poster_end" },

      { label: "ch03_poster_end" },

      /* ---------- 三、集市 ---------- */
      { cg: "cg_market", bgm: "ch03_market",
        text: "然后，她们走进了集市。" },
      { text: "那是一种，让人措手不及的热闹。" },
      { text: "烤饼的香气，羊油的香气，辛辣的香料，晒干的果子，还有成串垂挂的腌鱼，一层压着一层，把整条街道塞得满满当当。" },
      { text: "叫卖声，讲价声，铜锅碰撞声，孩子们追着一只母鸡跑过的尖叫声，混成了一团滚烫的、没有秩序的潮水。" },
      { text: "这和王宫里的声音完全不同。宫廷的喧闹是用来「听」的，而这里，是用来「活」的。" },
      { cgHide: true, bg: "market_square", transition: "cut",
        who: "bailong", expr: BL("surprised"), text: "……好多，亮的。" },
      { who: "mingyue", text: "那是铜锅！铜锅！不是金子！不许摸！" },
      { who: "bailong", text: "……摸一下。" },
      { who: "mingyue", text: "也不行！" },
      { text: "最后，是克劳德先停在了一个烤饼摊前。摊主是一位满脸皱纹、手上沾满面粉的老妇人，正把一块块圆饼，拍在滚烫的铁壁上。" },
      { speaker: "摊主", text: "小姑娘，要几个？一个铜板两张，三个铜板，送你一碟酱。" },
      { who: "claude", text: "……请给我，三个。" },

      { if: { coin: "kept" },
        text: "她从口袋里摸出了那枚金币，郑重地递了过去。这是她这几天里，所有的盘缠。" },
      { if: { coin: "kept" }, sfx: "bite", speaker: "摊主",
        text: "金币？！你这孩子，是哪家的千金？我这小摊子，哪里找得开！……让我咬一下，咬一下。" },
      { if: { coin: "kept" }, who: "mingyue", expr: MY("angry", "shake"), text: "不许咬！！（把金币抢了回来）圣……姐姐，我们去换零钱！" },
      { if: { coin: "kept" }, text: "最后，是溟月在镇上的钱庄里，花了整整一刻钟，才把那枚金币换成了一堆沉甸甸的铜板。钱庄老板用看小偷的眼神，打量了她们三遍。" },

      { if: { coin: "refused" },
        text: "她这才想起来，自己身上，没有一枚能花的钱。教会的圣女，从不需要钱。" },
      { if: { coin: "refused" }, who: "mingyue", expr: MY("normal"),
        text: "没事。我来。老板娘，您这儿缺不缺洗碗的？我手脚很快，一顿饭就够了！" },
      { if: { coin: "refused" }, speaker: "摊主", text: "你这丫头倒会说话。行，后面那堆碗，洗干净了，三个饼，管够。" },
      { if: { coin: "refused" }, text: "半个时辰后，溟月的手泡得发白，却捧着三张热腾腾的烤饼，得意地扬了扬下巴。克劳德站在一旁，终于学会了「帮忙递盘子」。" },

      /* ---------- 抉择：砍价 ---------- */
      { text: "烤饼吃了一半，她们在一个卖斗篷的摊子前，停了下来。克劳德的灰斗篷，沾满了路上的泥。",
        choices: [
          { text: "按溟月教的，狠狠地砍价", jump: "ch03_haggle_hard", set: { haggle: "hard" } },
          { text: "老老实实，按标价买",     jump: "ch03_haggle_fair", set: { haggle: "fair" } }
        ] },

      { label: "ch03_haggle_hard" },
      { who: "mingyue", text: "记住了！先说「太贵了」，再说「别家只要一半」，最后，转身就走！" },
      { who: "claude", expr: CL("serious"), text: "……太贵了。别家，只要一半。" },
      { text: "她说完，转身就走。动作之干脆、之决绝，像是在对一场审判宣读最终判词。" },
      { speaker: "摊主", text: "哎哎哎！姑娘！姑娘留步！六成！六成可以了吧！" },
      { who: "claude", expr: CL("surprised"), text: "……成功了。" },
      { who: "mingyue", expr: MY("happy", "jump"), text: "您是个天才！" },
      { text: "这是克劳德第一次，用自己的话，从别人手里，换来了一样东西。她忽然觉得，砍价这件事，比背诵三重祷文有趣得多。" },
      { jump: "ch03_haggle_end" },

      { label: "ch03_haggle_fair" },
      { who: "claude", text: "请问，这件斗篷多少钱？" },
      { speaker: "摊主", text: "二十个铜板。" },
      { who: "claude", text: "好。这是二十个。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "圣……姐姐！哪有人这样买东西的！好歹还个价啊！" },
      { who: "claude", expr: CL("normal"), text: "这件斗篷，值这个价。他也需要这二十个铜板。" },
      { text: "摊主愣了一下，然后哈哈大笑，从摊子下面又抽出一条围巾，塞进了她的手里。「送你的。头一回见，买东西不还价的姑娘。」" },
      { jump: "ch03_haggle_end" },

      { label: "ch03_haggle_end" },
      { text: "太阳慢慢偏西。她们坐在一座老井边，分着最后一块烤饼。克劳德用手拿着，大口地咬下去，酱汁，沾到了嘴角。" },
      { text: "她没有去擦。没有人告诉她该擦。" },

      /* ---------- 四、执事（视角切换） ---------- */
      { hide: "all", bg: "border_gate", transition: "black", bgm: "ch03_market",
        text: "与此同时，在石楔镇的另一头，两个白袍的身影，正气喘吁吁地冲进了镇门。" },
      { who: "oli", text: "雷蒙大人，您确定，圣女大人，是被龙，掳到北边来的吗？" },
      { who: "raymond", text: "奥利，你知道教会的执事，最重要的素质是什么吗？" },
      { who: "oli", text: "……虔诚？" },
      { who: "raymond", text: "是坚定。坚定地，往一个方向走，哪怕那个方向是错的。" },
      { who: "oli", text: "……那，我们现在，是在错的方向上，坚定吗？" },
      { who: "raymond", text: "不。我们是在，暂时没有被证明为错的方向上，坚定。" },
      { text: "奥利叹了口气。他从怀里摸出一卷羊皮纸，那是他昨晚连夜画的悬赏肖像，边角被汗水洇得发皱。" },
      { who: "oli", text: "大人，您看，这张圣女像，我加了光轮，您说，是不是更庄严了？" },
      { who: "raymond", text: "……奥利。你确定，这是圣女？" },
      { who: "oli", text: "确定！我对照着画册画的！" },
      { who: "raymond", text: "那颗，土豆，是画册里的？" },
      { who: "oli", text: "那是，头发。" },
      { text: "镇门口，一位卖山羊奶的大婶，听见了他们的争吵，探出头来。" },
      { speaker: "大婶", text: "两位大人，是在找人？" },
      { who: "raymond", text: "是，一位橙色长发的年轻小姐，约莫十八九岁，气质，嗯，高贵端庄。" },
      { speaker: "大婶", text: "哦！那个啊！我早上，确实看见了一个。往东边的盐路去了。" },
      { who: "oli", text: "往东边？！" },
      { speaker: "大婶", text: "橙头发，扎得歪歪扭扭，肩上还挎着半只山羊。我还说呢，这姑娘，真有劲。" },
      { who: "raymond", text: "……山羊。圣女大人，竟然已经，能扛山羊了。" },
      { who: "oli", text: "不愧是神血的孩子！" },
      { text: "两位执事对视一眼，眼中同时燃起了某种近乎神圣的光。" },
      { who: "raymond", text: "追！盐路！圣女大人，一定是为了试炼自身，才选择了最艰难的道路！" },
      { text: "他们转身，一路小跑着冲向了与她们完全相反的方向。那位大婶，目送着他们的背影，轻轻地叹了口气。" },
      { speaker: "大婶", text: "唉，年纪轻轻的，眼睛就不好使。我说的是，那个卖盐的姑娘啊。" },

      /* ---------- 五、客栈 ---------- */
      { show: [ { id: "mingyue", pos: 22, expr: "normal" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
        bg: "inn_room", transition: "black", bgm: "ch03_inn",
        text: "夜里，她们挤在镇上唯一一家客栈，最便宜的一间屋子里。屋里只有两张床，窗户漏风，墙角还趴着一只不肯走的猫。" },
      { who: "mingyue", expr: MY("happy"), text: "我睡地上！这点苦，比起在港口睡鱼筐，已经是天堂了！" },
      { who: "bailong", text: "……我睡床下。龙，喜欢，窝里。" },
      { who: "claude", text: "那，我睡……" },
      { who: "mingyue", expr: MY("normal"), text: "您睡床。别争了，今天是您第一次，自己赚到的饭钱，您值得一张床。" },
      { text: "「自己赚到的」。克劳德把这几个字，在心里，慢慢地、又过了一遍。" },
      { text: "窗外，有人在远远地弹着一把走了音的琴。那调子，是这座小镇的人们，用来哄孩子睡觉的歌。" },
      { who: "claude", text: "溟月。" },
      { who: "mingyue", text: "嗯？" },
      { who: "claude", text: "今天，是我这十年里，第一次，没有人告诉我，该做什么的一天。" },
      { who: "mingyue", expr: MY("surprised"), text: "那，您，开心吗？" },
      { who: "claude", text: "我不知道。……但是，烤饼，很好吃。" },
      { who: "mingyue", expr: MY("happy", "jump"), text: "对吧！！我就说！！" },
      { who: "bailong", text: "烤饼。好吃。亮的。" },
      { text: "油灯熄灭了。三个呼吸声，在漏风的屋子里，慢慢地合在了一起。" },
      { who: "claude", text: "……明天，往哪里走？" },
      { text: "黑暗里，白泷的声音，从床底下，闷闷地传了出来。" },
      { who: "bailong", text: "往南。有一片，雾。很大的雾。雾里，有东西，在亮。" },
      { who: "mingyue", text: "镇上的人说过，那是迷雾遗迹。没有人敢进去的地方。" },
      { who: "claude", text: "……那就，去看看。" },
      { effect: "fadeOut", text: "窗外，那把走了音的琴，又弹了一遍。" },

      /* ===== 章末：衔接第四章（ch04_start），下一章以 fadeIn 开场 ===== */
      { label: "ch03_end" }
    ]
  };
})();
