/* =====================================================
   story_ch04.js —— 第四章「雾中之壁」（迷雾遗迹）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch03_end 之后（ch03 以 fadeOut 黑屏结尾，本章以 fadeIn 开场）。
   与第六章呼应：壁画 = 一个完整的圆被刻痕切开，碎片朝不同方向；其中一块碎片指向北方。
   真相保持留白：被凿去的那一段，永远没有被读出来。
   ===================================================== */
window.STORY_CH04 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });

  return {

    addCharacters: {},
    addBackgrounds: {
      mist_valley: { src: "assets/bg/mist_valley.jpg",
                     color: "linear-gradient(180deg,#9aa6aa 0%,#c4ccce 50%,#6a7478 100%)" },
      ruin_hall:   { src: "assets/bg/ruin_hall.jpg",
                     color: "radial-gradient(ellipse at 50% 40%,#4a5a5e 0%,#1a2224 55%,#060809 100%)" }
    },
    addCgs: {
      cg_mural: { src: "assets/cg/mural.jpg",
                  color: "radial-gradient(ellipse at 50% 45%,#8a7a58 0%,#3a3224 45%,#0a0806 100%)" }
    },
    addAudio: {
      bgm: { ch04_mist: "assets/audio/ch04_mist.mp3", ch04_mural: "assets/audio/ch04_mural.mp3" },
      sfx: { whisper: "assets/audio/whisper.mp3" }
    },

    /* flag：
       guide: "mingyue" / "bailong"   —— 在雾中听谁的指引走出来
       mural: "order" / "scar"        —— 先按顺序读壁画，还是先去看被凿掉的那一段
    */

    script: [

      { label: "ch04_start" },
      { chapter: { no: "CHAPTER 04", title: "雾中之壁", sub: "THE MIST · 迷雾遗迹" } },

      /* ---------- 一、迷雾 ---------- */
      { hide: "all", bg: "mist_valley", transition: "cut", bgm: "ch04_mist", effect: "fadeIn",
        text: "往南的路走了三天，第三天的傍晚，她们撞进了一片雾里。" },
      { text: "那不是寻常的雾。它是乳白色的，厚得像一块浸了水的棉布，从山谷的深处，一层一层地漫上来，没过脚踝，没过膝盖，没过人的声音。" },
      { show: [ { id: "mingyue", pos: 22, expr: "worried" }, { id: "claude", pos: 50, expr: "normal" }, { id: "bailong", pos: 78, expr: "normal" } ],
        who: "mingyue", text: "喂，你们还在吗？我只能看见我自己的手指……" },
      { who: "claude", text: "我在。你左边，三步。" },
      { who: "bailong", text: "我也在。右边。……我的尾巴，被谁踩了。" },
      { who: "mingyue", expr: MY("surprised"), text: "那是我！抱歉！" },
      { text: "山谷的入口处，立着一块半截的石碑，字迹被苔藓吞去了大半。只能勉强辨出两个字：「禁入」。" },
      { who: "mingyue", text: "镇上的人说，进去的人，要么再也没出来，要么出来的时候，忘了自己是谁。" },
      { who: "claude", text: "那我们，走慢一点。" },
      { who: "bailong", text: "……这里，有一点，龙的味道。" },
      { who: "mingyue", expr: MY("surprised"), text: "什么？" },
      { who: "bailong", text: "很老。很老很老的。像……我家里，最里面的那间屋子。" },
      { text: "克劳德回头看了她一眼。白发少女的眉头皱得很紧，这是她第一次，在谈论「家」的时候，露出这样陌生的神情。" },

      /* ---------- 雾中的幻象 ---------- */
      { sfx: "whisper", text: "雾，越来越浓了。浓到某一刻，三个人的声音，同时，从耳边消失了。" },
      { text: "克劳德看见了一间小小的礼拜堂。烛火，长椅，木地板被跪得发亮。一个穿着白袍的小女孩，正跪在最前排，一遍一遍地，抄写着什么。" },
      { text: "那是八岁的她。她的手指，被笔杆磨出了血泡，却不敢停。" },
      { text: "她伸出手，想去碰那个孩子的肩膀。指尖穿过了雾气。孩子抬起头，没有看她，只是，很轻地，把嘴角抬到了某个角度。" },
      { who: "claude", expr: CL("worried"), text: "……不。不要笑。" },
      { text: "雾散开了一线。她发现，自己的手，正死死地攥着溟月的衣袖，攥得指节发白。" },
      { who: "mingyue", text: "……我，刚才，看见港口了。老舵叔在补网，七嫂在晒鱼干。他们，还冲我招手。" },
      { who: "bailong", text: "我看见，金子。一座，很大很大的，金山。山顶上，没有人。" },
      { text: "沉默了片刻。三个人，各自从各自的幻象里，慢慢地走了回来。" },
      { who: "claude", text: "雾里的东西，会给我们看，我们最想念的，也是最怕失去的。" },
      { who: "mingyue", expr: MY("normal"), text: "……所以，不要松手。" },

      /* ---------- 抉择：谁来引路 ---------- */
      { text: "前方的雾，分出了两条路。左边，隐约有一丝潮声。右边，则有一种极低极低的、金属般的嗡鸣。",
        choices: [
          { text: "听溟月的，循着潮声走", jump: "ch04_guide_my", set: { guide: "mingyue" } },
          { text: "听白泷的，循着嗡鸣走", jump: "ch04_guide_bl", set: { guide: "bailong" } }
        ] },

      { label: "ch04_guide_my" },
      { who: "mingyue", expr: MY("worried"), text: "我……我也不确定。就是，觉得，那边的水，在叫我。" },
      { who: "claude", text: "那就信你的耳朵。" },
      { text: "溟月走在最前面，尾尖在地上，一下，一下，敲出一个很轻的节拍。雾，像被这个节拍，推开了一寸又一寸。" },
      { who: "mingyue", text: "……我好像，听得懂，它们在说什么了。它们说，别怕。" },
      { jump: "ch04_guide_end" },

      { label: "ch04_guide_bl" },
      { who: "bailong", text: "那边。很老的，龙的味道。更浓。" },
      { who: "claude", text: "你，确定？" },
      { who: "bailong", text: "嗯。我，不会认错。那是，我们的，味道。" },
      { text: "白泷第一次走在了最前面。她没有说话，只是每走几步，便回头看一眼，像怕身后的人，被雾带走。" },
      { text: "「我们的」。克劳德把这个词，默默地，记在了心里。" },
      { jump: "ch04_guide_end" },

      { label: "ch04_guide_end" },
      { bg: "ruin_hall", transition: "black", bgm: "ch04_mural",
        text: "雾，在一瞬间，退了。" },
      { text: "她们站在了一座巨大的石厅之中。穹顶早已坍塌，月光从破口里倾泻下来，落在满地的碎石与枯叶之上，像一场安静的、持续了千年的雪。" },
      { text: "石柱，一根一根，立在黑暗里。每一根柱身上，都刻着同一个纹样：一个圆，被一道又一道的刻痕，切成许多片。" },
      { who: "claude", expr: CL("surprised"), text: "……就是这里。" },

      /* ---------- 二、壁画 ---------- */
      { text: "石厅的最深处，是一面几乎占满整面墙的壁画。表面覆满了苔藓和水渍，颜料早已剥落，只剩下一层极淡的、赭红与靛青的轮廓。" },
      { cg: "cg_mural", bgm: "ch04_mural",
        text: "月光移动了一寸，壁画，在黑暗里，一点一点地，亮了起来。" },
      { text: "最上方，是一个完整的圆。没有裂缝，没有刻痕，只是一个安静的、圆满的圆，像一枚被人托在掌心的月亮。" },
      { text: "圆的周围，有许多模糊的人影。他们的姿势，大多是仰望，有的伸着手，有的低着头。看不清表情。" },

      { text: "壁画的下半部，被一道笔直的凿痕，截成了两段。左边，有序；右边，则是一片，被刻意凿去的空白。",
        choices: [
          { text: "按顺序，从上往下读", jump: "ch04_mural_order", set: { mural: "order" } },
          { text: "先去看被凿掉的那一段", jump: "ch04_mural_scar",  set: { mural: "scar" } }
        ] },

      { label: "ch04_mural_order" },
      { text: "她从最上方开始，一格一格地读下去。" },
      { text: "第二格，圆被切开了。没有画出刀，没有画出手，只有刻痕，从圆心向外，一道，又一道。" },
      { text: "第三格，碎片分散。每一块碎片，都带着一枚小小的箭头，指向四面八方：海，山，火，天空，还有，一个她不认识的、被剥蚀得看不出形状的方向。" },
      { text: "第四格，人群跪下了。无数个小小的人影，跪在碎片落下的地方。他们的头顶，是一道道从碎片中升起的、细细的线。" },
      { who: "claude", text: "……这些线，是什么？" },
      { who: "mingyue", text: "像是，在连着什么东西。像风筝线。" },
      { who: "claude", text: "也可能是，绳子。" },
      { jump: "ch04_mural_mid" },

      { label: "ch04_mural_scar" },
      { text: "她径直走向了右边那片空白。凿痕很深，边缘锋利，是被人用极精良的工具，一下一下地凿出来的。" },
      { text: "这不是岁月的杰作。是有人，在很久以前，不想让后来的人，看见这里画了什么。" },
      { text: "凿痕的缝隙里，残留着半枚纹样。她伸手，沿着那道痕迹，轻轻摸过去，指尖，忽然停住了。" },
      { who: "claude", expr: CL("worried"), text: "……这个纹样的一角，像是，日轮。" },
      { who: "mingyue", expr: MY("surprised"), text: "教会的日轮？！" },
      { who: "claude", text: "不能确定。也许只是巧合。但是，" },
      { who: "claude", text: "这凿痕，非常新。比壁画，要新得多。" },
      { jump: "ch04_mural_mid" },

      { label: "ch04_mural_mid" },
      { who: "bailong", text: "……这里，写着，字。" },
      { text: "白泷指着壁画下方，一行几乎被苔藓吞尽的细小刻字。她歪着头，一个字一个字地，慢慢辨认着。" },
      { who: "bailong", text: "……不是人类的，字。是我们的。龙族的，老字。" },
      { who: "mingyue", expr: MY("surprised"), text: "你，认得？" },
      { who: "bailong", text: "认得一半。小时候，我，学过。但是，我，不好好学。" },
      { who: "bailong", text: "……这一行，是……「我们，曾经，是一个」。" },
      { text: "石厅里，安静得，能听见月光落在苔藓上的声音。" },
      { who: "claude", text: "……「曾经，是一个」。" },
      { text: "她在心里，把那句话，和壁画最上方那枚完整的圆，重叠在了一起。" },
      { text: "圣典的开篇，是这样写的：「祂们自愿降下，以光护佑万民。」" },
      { text: "「降下」。可是，一个完整的圆，需要「降下」去哪里吗？" },
      { text: "这个念头一浮上来，她就像被烫了一下，立刻，把它压了回去。十年里，这种念头，是要抄经十遍的。" },
      { who: "claude", text: "（……我现在，不用抄了。）" },

      /* ---------- 三、北方的碎片 ---------- */
      { text: "壁画的最右下角，有一块，格外小的碎片。别的碎片，都朝着不同的方向坠落，只有它，笔直地，指向画面的上方。" },
      { who: "mingyue", text: "这一块，怎么，是往上的？" },
      { who: "claude", text: "壁画上，上方是……" },
      { who: "bailong", text: "北。" },
      { text: "白泷说得很肯定。她抬起头，淡紫色的眼睛里，映着穹顶外，一线微弱的月光。" },
      { who: "bailong", text: "龙族的壁画，上面，永远是北。那是，我们的，家的方向。" },
      { who: "mingyue", text: "……你家，在北边？" },
      { who: "bailong", text: "……我，不记得了。我只记得，那边，很冷，很亮。" },
      { text: "没有人再追问。三个人，站在那面沉默了一万年的壁画前，像三枚，刚刚被它认出来的、小小的碎片。" },

      /* ---------- 四、离开 ---------- */
      { cgHide: true, bgm: "ch04_mist",
        text: "离开石厅的时候，雾，已经散尽了。清晨的光，从山谷的另一头，一寸一寸地铺过来。" },
      { text: "身后，那座遗迹，安安静静地，缩回了山的怀里。像一个守了很久秘密的人，终于，把门，轻轻地合上了。" },
      { who: "mingyue", text: "……这下，我们，知道的，比不知道的，还要多了。" },
      { who: "claude", text: "也比之前，更不知道。" },
      { who: "mingyue", expr: MY("normal"), text: "那……您，还要，继续吗？" },
      { text: "这是溟月第一次，没有用「圣女大人」的口吻，问她这个问题。" },
      { who: "claude", expr: CL("normal"), text: "我想，先去一个地方。" },
      { who: "claude", text: "你说过，你的家，在海边。一座，很小，很吵，很热闹的港口。" },
      { who: "mingyue", expr: MY("surprised"), text: "……诶？" },
      { who: "claude", text: "我想去看看，那个，用鱼和汤，养大了一个孩子的地方。" },
      { who: "mingyue", text: "……不是因为，您，想知道什么，真相之类的？" },
      { who: "claude", text: "不是。是因为，我想知道，普通人，是怎么，把日子，过下去的。" },
      { text: "溟月沉默了很久。久到雾里的鸟，叫了三声。然后，她把脸扭到一边，用很凶的声音，说了一句很软的话：" },
      { who: "mingyue", expr: MY("shy", "shake"), text: "……那，那您，可要做好心理准备！我们那里，吵得很！" },
      { who: "bailong", text: "有鱼吗？" },
      { who: "mingyue", text: "有！多得吃不完！" },
      { who: "bailong", text: "……亮的？" },
      { who: "mingyue", expr: MY("angry"), text: "鱼鳞，也算亮的，但是不许收！" },
      { effect: "fadeOut", text: "三个人沿着山路，朝着海的方向，走了下去。" },

      /* ===== 章末：衔接第五章（ch05_start），下一章以 fadeIn 开场 ===== */
      { label: "ch04_end" }
    ]
  };
})();
