// تشغيل: node server.js   (يحتاج Node 18 أو أحدث، ولا يحتاج npm install)
const http = require("http"), fs = require("fs"), path = require("path");
try { for (const l of fs.readFileSync(path.join(__dirname, ".env"), "utf8").split(/\r?\n/)) { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ""); } } catch {}
const KEY = process.env.OPENAI_API_KEY, MODEL = process.env.OPENAI_IMAGE_MODEL || "gpt-image-1",
  QUAL = process.env.IMAGE_QUALITY || "medium", PORT = +process.env.PORT || 3000, LIMIT = +process.env.HOURLY_LIMIT || 10;
if (!KEY) { console.error("OPENAI_API_KEY غير موجود. انسخ .env.example إلى .env وحط المفتاح."); process.exit(1); }
const BASE = "Convert this 3D kitchen render into a realistic photograph taken with a DSLR camera in a real room, natural lighting, real materials, soft realistic shadows and subtle imperfections. ";
const MODES = {
  s: BASE + "STRICT: keep the exact camera angle, composition, cabinet layout, unit positions, proportions, colors, doors and walls unchanged. Do not add, remove, move or resize any unit.",
  c: BASE + "Improve materials, lighting and environment for a photographic look, but keep the design clearly recognizable: same layout, same cabinet arrangement, same overall colors."
};
const MOOD = { d: "Lighting: bright natural daylight.", s: "Lighting: warm golden sunset light entering the room.", n: "Lighting: night scene, warm LED under-cabinet lights glowing, dark outside." };
const hits = new Map();
const ok = ip => { const n = Date.now(), a = (hits.get(ip) || []).filter(t => n - t < 36e5); if (a.length >= LIMIT) return false; a.push(n); hits.set(ip, a); return true; };
const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" }); res.end(JSON.stringify(obj)); };
async function call(fd) {
  for (let i = 0; i < 2; i++) {
    const r = await fetch("https://api.openai.com/v1/images/edits", { method: "POST", headers: { Authorization: "Bearer " + KEY }, body: fd, signal: AbortSignal.timeout(150000) });
    if (r.status < 500 || i) return r;
  }
}
http.createServer(async (req, res) => {
  if (req.method === "GET" && (req.url === "/" || req.url === "/index.html")) { res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" }); return fs.createReadStream(path.join(__dirname, "index.html")).pipe(res); }
  if (req.method === "POST" && req.url === "/api/realize") {
    try {
      let b = "", n = 0; for await (const c of req) { n += c.length; if (n > 14e6) return send(res, 413, { error: "الصورة كبيرة جداً" }); b += c; }
      const { image, mode, mood, w, h } = JSON.parse(b), m = /^data:image\/(png|jpeg);base64,(.+)$/.exec(image || "");
      if (!m) return send(res, 400, { error: "صيغة الصورة غير مدعومة (PNG أو JPEG فقط)" });
      if (!ok(req.socket.remoteAddress)) return send(res, 429, { error: "تجاوزت الحد المسموح بالساعة، حاول لاحقاً" });
      const fd = new FormData();
      fd.append("model", MODEL); fd.append("prompt", (MODES[mode] || MODES.s) + " " + (MOOD[mood] || "")); fd.append("n", "1"); fd.append("quality", QUAL);
      fd.append("size", w > h * 1.15 ? "1536x1024" : h > w * 1.15 ? "1024x1536" : "1024x1024");
      if (mode !== "c") fd.append("input_fidelity", "high");
      fd.append("image", new Blob([Buffer.from(m[2], "base64")], { type: "image/" + m[1] }), "scene." + (m[1] === "png" ? "png" : "jpg"));
      const r = await call(fd), j = await r.json().catch(() => ({}));
      if (!r.ok) { console.error("OpenAI", r.status, j.error); return send(res, 502, { error: (j.error && j.error.message) || "خطأ " + r.status }); }
      const d = j.data && j.data[0] && j.data[0].b64_json;
      if (!d) return send(res, 502, { error: "رد غير متوقع من OpenAI" });
      send(res, 200, { image: "data:image/png;base64," + d });
    } catch (e) { send(res, 500, { error: e.name === "TimeoutError" ? "انتهت المهلة" : "خطأ في السيرفر" }); console.error(e); }
    return;
  }
  res.writeHead(404); res.end();
}).listen(PORT, () => console.log("Hanemex يعمل على http://localhost:" + PORT));
