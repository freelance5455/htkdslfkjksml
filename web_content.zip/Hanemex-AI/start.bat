@echo off
chcp 65001 >nul
if not exist .env (
  copy .env.example .env >nul
  echo تم إنشاء ملف .env - افتحه وحط مفتاح OpenAI ثم شغّل هذا الملف مرة أخرى
  notepad .env
  pause
  exit /b
)
start http://localhost:3000
node server.js
pause
