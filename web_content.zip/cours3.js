if (typeof COURSES !== "undefined") {
  COURSES.push({
    id: "net-1",
    category: "Réseaux & Systèmes",
    level: "Universitaire L1/L2",
    title: "Réseaux Informatiques & Systèmes Linux",
    duration: "1h 30",
    description: "Manuel complet : modèles OSI et TCP/IP, calcul de sous-réseaux IPv4, ports, TCP vs UDP et administration Linux.",
    chapters: [
      {
        id: "net-c1",
        title: "Chapitre 1 : Modèles OSI, TCP/IP & Équipements",
        html: `
          <h3>1.1 Types de réseaux et performances</h3>
          <p>Un réseau relie des équipements pour partager données et ressources. On distingue selon la portée : le <strong>LAN</strong> (réseau local d'une maison ou université), le <strong>MAN</strong> (échelle d'une ville) et le <strong>WAN</strong> (échelle mondiale, comme Internet).</p>
          <p>La performance dépend de deux mesures différentes : la <strong>bande passante</strong> (quantité maximale de données par seconde, en Mbps/Gbps) et la <strong>latence</strong> (temps de trajet aller-retour d'un paquet, en millisecondes).</p>

          <h3>1.2 Les 7 couches du Modèle OSI</h3>
          <p>Pour que des constructeurs différents communiquent, l'ISO a créé le modèle <strong>OSI</strong> en 7 couches. Lors de l'envoi d'un message, chaque couche ajoute son propre en-tête : c'est l'<strong>encapsulation</strong>.</p>
          <table>
            <tr><th>Couche OSI</th><th>Données (PDU)</th><th>Protocoles & Équipements</th></tr>
            <tr><td><strong>7. Application</strong></td><td>Données</td><td>HTTP, HTTPS, DNS, FTP, SSH</td></tr>
            <tr><td><strong>6. Présentation</strong></td><td>Données</td><td>Chiffrement TLS/SSL, JPEG, UTF-8</td></tr>
            <tr><td><strong>5. Session</strong></td><td>Données</td><td>Ouverture/maintien de session</td></tr>
            <tr><td><strong>4. Transport</strong></td><td>Segments / Datagrammes</td><td><strong>TCP</strong>, <strong>UDP</strong> (Numéros de ports)</td></tr>
            <tr><td><strong>3. Réseau</strong></td><td>Paquets</td><td><strong>IP</strong>, ICMP — <strong>Routeur</strong></td></tr>
            <tr><td><strong>2. Liaison</strong></td><td>Trames</td><td>Ethernet, Wi-Fi, Adresse MAC — <strong>Switch</strong></td></tr>
            <tr><td><strong>1. Physique</strong></td><td>Bits (0/1)</td><td>Câble RJ45, Fibre optique, Ondes radio</td></tr>
          </table>
          <div class="note-box">
            <strong>📌 Astuce mnémotechnique (du bas vers le haut, 1 → 7) :</strong><br/>
            « <strong>P</strong>our <strong>L</strong>e <strong>R</strong>éseau <strong>T</strong>out <strong>S</strong>e <strong>P</strong>asse <strong>A</strong>utomatiqement » (Physique, Liaison, Réseau, Transport, Session, Présentation, Application).
          </div>
        `
      },
      {
        id: "net-c2",
        title: "Chapitre 2 : Adressage IPv4 & Sous-réseaux (CIDR)",
        html: `
          <h3>2.1 Structure d'une adresse IPv4</h3>
          <p>Une adresse IPv4 est codée sur <strong>32 bits</strong> (4 octets séparés par des points, de 0 à 255). Le <strong>masque de sous-réseau</strong> (ex: <code>255.255.255.0</code> ou notation CIDR <code>/24</code>) indique combien de bits à gauche désignent le <strong>Réseau</strong> et combien à droite désignent l'<strong>Hôte</strong>.</p>

          <h3>2.2 Adresses Privées vs Publiques (NAT & DHCP)</h3>
          <p>Les adresses publiques sont uniques sur Internet. Dans un réseau local, on utilise des <strong>adresses privées</strong> gratuites (RFC 1918) :</p>
          <ul>
            <li>Classe A privée : <code>10.0.0.0</code> à <code>10.255.255.255</code> (<code>/8</code>)</li>
            <li>Classe B privée : <code>172.16.0.0</code> à <code>172.31.255.255</code> (<code>/12</code>)</li>
            <li>Classe C privée : <code>192.168.0.0</code> à <code>192.168.255.255</code> (<code>/16</code>)</li>
          </ul>
          <p>Le serveur <strong>DHCP</strong> distribue automatiquement ces IP aux appareils, et le routeur utilise le <strong>NAT</strong> pour traduire les IP privées vers une IP publique afin d'accéder à Internet.</p>

          <h3>2.3 Calcul de sous-réseaux (Subnetting)</h3>
          <p>Si <code>h</code> est le nombre de bits réservés aux hôtes (<code>h = 32 - CIDR</code>), le nombre de machines adressables vaut toujours <strong>2ʰ - 2</strong> (on retire 1 adresse pour le <em>Réseau</em> et 1 pour le <em>Broadcast</em>).</p>
          <table>
            <tr><th>CIDR</th><th>Masque</th><th>Bits hôtes (h)</th><th>Hôtes utilisables</th></tr>
            <tr><td><strong>/24</strong></td><td>255.255.255.0</td><td>8</td><td>254</td></tr>
            <tr><td><strong>/25</strong></td><td>255.255.255.128</td><td>7</td><td>126</td></tr>
            <tr><td><strong>/26</strong></td><td>255.255.255.192</td><td>6</td><td>62</td></tr>
            <tr><td><strong>/27</strong></td><td>255.255.255.224</td><td>5</td><td>30</td></tr>
            <tr><td><strong>/30</strong></td><td>255.255.255.252</td><td>2</td><td>2 (lien point-à-point)</td></tr>
          </table>
        `
      },
      {
        id: "net-c3",
        title: "Chapitre 3 : Transport (TCP vs UDP) & Ports",
        html: `
          <h3>3.1 TCP vs UDP : fiabilité ou vitesse ?</h3>
          <table>
            <tr><th>Critère</th><th>TCP (Orienté connexion)</th><th>UDP (Sans connexion)</th></tr>
            <tr><td><strong>Fiabilité</strong></td><td>Garantit la livraison (réenvoi si perte)</td><td>Aucune garantie (paquets perdus non renvoyés)</td></tr>
            <tr><td><strong>Vitesse</strong></td><td>Plus lent (contrôles + accusés)</td><td>Très rapide, faible latence</td></tr>
            <tr><td><strong>Usages</strong></td><td>Web (HTTP/S), E-mail, Transfert de fichiers</td><td>Streaming vidéo, Jeux en ligne, DNS, VoIP</td></tr>
          </table>
          <p>Avant d'envoyer des données, <strong>TCP</strong> établit la connexion via le <strong>3-Way Handshake</strong> : <code>SYN</code> (Client → Serveur), <code>SYN-ACK</code> (Serveur → Client), puis <code>ACK</code> (Client → Serveur).</p>

          <h3>3.2 Les Ports réseaux célèbres</h3>
          <p>L'adresse IP trouve la bonne machine ; le <strong>numéro de port</strong> (0 à 65535) trouve le bon programme sur cette machine :</p>
          <ul>
            <li><strong>21 :</strong> FTP (Transfert de fichiers) • <strong>22 :</strong> SSH (Accès distant sécurisé)</li>
            <li><strong>25 :</strong> SMTP (Envoi d'e-mails) • <strong>53 :</strong> DNS (Résolution de noms)</li>
            <li><strong>80 :</strong> HTTP (Web non chiffré) • <strong>443 :</strong> HTTPS (Web chiffré TLS)</li>
            <li><strong>3306 :</strong> MySQL • <strong>5432 :</strong> PostgreSQL</li>
          </ul>
        `
      },
      {
        id: "net-c4",
        title: "Chapitre 4 : Systèmes & Administration Linux",
        html: `
          <h3>4.1 Arborescence et Philosophie Linux</h3>
          <p>Sous Linux, <strong>tout est fichier</strong>, à partir d'une racine unique notée <code>/</code> :</p>
          <ul>
            <li><code>/home</code> : Dossiers personnels des utilisateurs.</li>
            <li><code>/etc</code> : Fichiers de configuration du système et des services.</li>
            <li><code>/var/log</code> : Journaux d'événements (logs) très utiles en diagnostic.</li>
            <li><code>/bin</code> et <code>/usr/bin</code> : Commandes et programmes exécutables.</li>
          </ul>

          <h3>4.2 Droits d'accès UNIX (r, w, x)</h3>
          <p>Chaque fichier possède 3 groupes de permissions : <strong>Propriétaire (u)</strong>, <strong>Groupe (g)</strong> et <strong>Autres (o)</strong>. En notation octale : <strong>r (lecture) = 4</strong>, <strong>w (écriture) = 2</strong>, <strong>x (exécution) = 1</strong>.</p>
          <div class="code-box">
            <div class="code-header"><span>Bash — Commandes système et diagnostic réseau</span><button class="copy-btn" onclick="copyCode(this)">Copier</button></div>
<pre><span class="fn">ls</span> -la                   <span class="cmt"># Lister fichiers, propriétaires et droits</span>
<span class="fn">chmod</span> 750 mon_script.sh  <span class="cmt"># u=rwx(7), g=r-x(5), o=---(0)</span>
<span class="fn">grep</span> -i <span class="str">"error"</span> app.log  <span class="cmt"># Chercher un mot dans un fichier</span>
<span class="fn">ps</span> aux                   <span class="cmt"># Voir les processus en cours</span>
<span class="fn">ip</span> a                     <span class="cmt"># Afficher cartes réseau et IP</span>
<span class="fn">ping</span> -c 4 8.8.8.8        <span class="cmt"># Tester la connectivité IP</span>
<span class="fn">ss</span> -tulnp                <span class="cmt"># Voir les ports ouverts en écoute</span></pre>
          </div>
        `
      }
    ],
    exercises: [
      {
        title: "Découpage d'un réseau /26 (Subnetting)",
        prompt: "On vous attribue le bloc <code>192.168.1.0/26</code>.<br/>1) Quel est le masque en décimal ?<br/>2) Combien de machines utilisables peut-on y brancher ?<br/>3) Donnez l'adresse réseau, la plage des hôtes valides et le broadcast.",
        solution: "1) <code>/26</code> = 26 bits à 1 → le dernier octet a 2 bits à 1 (128 + 64 = 192) : <strong>255.255.255.192</strong>.<br/>2) Bits hôtes h = 32 - 26 = 6 → 2⁶ - 2 = 64 - 2 = <strong>62 machines</strong>.<br/>3) Réseau : <code>192.168.1.0</code> | Hôtes valides : <code>192.168.1.1</code> à <code>192.168.1.62</code> | Broadcast : <code>192.168.1.63</code>."
      },
      {
        title: "Traduction de droits Linux",
        prompt: "La commande <code>ls -l</code> affiche : <code>-rwxr-x--- 1 josue devs 2048 serveur.py</code>.<br/>1) Traduisez ces permissions en valeur octale pour <code>chmod</code>.<br/>2) Un autre utilisateur qui n'est pas dans le groupe <code>devs</code> peut-il lire ce fichier ?",
        solution: "1) Propriétaire <code>rwx</code> = 4+2+1 = <strong>7</strong> | Groupe <code>r-x</code> = 4+0+1 = <strong>5</strong> | Autres <code>---</code> = <strong>0</strong>. Valeur octale : <strong>750</strong>.<br/>2) <strong>Non</strong>, car les permissions pour les autres (les 3 derniers caractères) sont <code>---</code> (aucun accès)."
      },
      {
        title: "Dépannage réseau concret",
        prompt: "Un étudiant n'arrive pas à ouvrir <code>https://universite.org</code> dans son navigateur. Il ouvre le terminal : <code>ping 8.8.8.8</code> répond en 30 ms, mais <code>ping universite.org</code> affiche <em>« Name or service not known »</em>. Quelle est la panne probable ?",
        solution: "Internet fonctionne au niveau IP (couche 3) puisque <code>8.8.8.8</code> répond. Le problème vient de la résolution des noms de domaine : le service <strong>DNS (port 53)</strong> est mal configuré ou en panne."
      }
    ],
    quiz: [
      {
        q: "Quel protocole de couche 4 établit une connexion via un '3-Way Handshake' (SYN, SYN-ACK, ACK) ?",
        options: ["UDP", "ICMP", "TCP", "ARP"],
        answer: 2,
        explanation: "TCP est un protocole orienté connexion qui garantit la fiabilité grâce à la négociation en 3 étapes."
      },
      {
        q: "Combien d'adresses hôtes utilisables offre un sous-réseau /27 ?",
        options: ["14", "30", "62", "126"],
        answer: 1,
        explanation: "Pour /27, il reste 32 - 27 = 5 bits pour les hôtes : 2⁵ - 2 = 32 - 2 = 30 machines."
      },
      {
        q: "Quel numéro de port est utilisé par défaut pour le protocole HTTPS (Web sécurisé) ?",
        options: ["22", "53", "80", "443"],
        answer: 3,
        explanation: "HTTP utilise le port 80, et HTTPS (avec chiffrement TLS) utilise le port 443."
      },
      {
        q: "Sous Linux, dans quel dossier se trouvent généralement les fichiers de configuration système ?",
        options: ["/home", "/etc", "/bin", "/tmp"],
        answer: 1,
        explanation: "Le répertoire /etc contient les fichiers de configuration globale du système et des services."
      },
      {
        q: "Quelle commande octale attribue lecture+écriture au propriétaire (rw-), lecture seule au groupe (r--) et rien aux autres (---) ?",
        options: ["chmod 755", "chmod 640", "chmod 600", "chmod 744"],
        answer: 1,
        explanation: "rw- = 4+2 = 6, r-- = 4, --- = 0 → chmod 640."
      }
    ]
  });
}