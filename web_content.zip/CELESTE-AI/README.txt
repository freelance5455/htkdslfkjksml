TANPA API KEY (PALING MUDAH)
  Buka celeste-ai.html langsung di browser (klik dua kali). Tidak perlu server, API Key, atau chip:
  CELESTE menjawab memakai otak lokal bawaan. Data tersimpan di browser.
  Otak lokal terbatas (matematika, dasar coding, rumus sekolah, nama, jam). Untuk jawaban yang lebih pintar,
  jalankan server dan isi API Key (lihat di bawah). Jika ingin mewajibkan chip, ubah AUTO_CHIP=true menjadi false
  di celeste-ai.html.

CELESTE AI - paket lengkap (API Key berfungsi, kode hadiah tak terbatas)

ISI
  server.js            server (Node 18+), proxy API + kode hadiah + konfigurasi bersama
  celeste-ai.html      aplikasi CELESTE (chat, game, dompet, jam, cuaca, admin)
  start.bat / start.sh peluncur otomatis-restart
  celeste.service      unit systemd agar server hidup 24 jam di VPS
  extras/              game crypto versi mandiri (opsional)

CARA JALAN
  1. Pasang Node.js 18+.   2. Jalankan start.bat (Windows) atau ./start.sh (Linux/Mac), atau: node server.js
  3. Buka http://localhost:3000

DEVELOPER
  Isi nama "adminevan" + password developer. Settings > API: pilih penyedia (Anthropic, OpenAI, Gemini,
  OpenRouter), tempel API Key, Simpan, Tes koneksi, Jadikan aktif. Semua pengguna lalu memakai penyedia aktif.
  Kunci disimpan di keys.json, tidak pernah dikirim ke browser.

KODE HADIAH
  Settings > Admin > Kode hadiah: tulis kode, nominal (tanpa batas atas) dan centang "Berulang" bila boleh
  dipakai berkali-kali. Jumlah kode tidak dibatasi. Pengguna menukar di Settings > Dompet.
  Kode "tidak berulang" dipakai sekali per perangkat (browser); menghapus data browser bisa mengakalinya.
  Saldo dompet tersimpan di browser pengguna, jadi bukan sistem pembayaran yang aman.

KEAMANAN
  - Ganti password: DEV_PW_SHA256=<sha256 password baru> node server.js  (printf 'baru' | sha256sum)
  - Akses dari jaringan lain: HOST=0.0.0.0 node server.js, dan pasang HTTPS sebelum ke internet.
  - File keys.json dan data.json berisi data rahasia: jangan dibagikan atau di-commit.
  - Nama model tiap penyedia bisa diubah di keys.json bagian "models".

CHIP (AI TANPA API)
  Otak lokal = mesin aturan bawaan (matematika, dasar coding, rumus sekolah, nama, jam). Terbatas, bukan LLM.
  Developer: Settings > Admin > Chip AI lokal > tulis kode > Buat. Pengguna: ketik /chip KODE atau Settings > Chip.
  Dengan chip aktif, CELESTE menjawab tanpa API Key (otomatis jadi cadangan bila server belum punya API Key).
  /lokal = paksa otak lokal ON/OFF.

UANG TAK TERBATAS
  Admin > Kode hadiah > centang "Uang tak terbatas": penukar kode mendapat saldo dompet tak terbatas dan level 5 gratis.

ONLINE LIVE
  Admin > Online live menampilkan pengguna aktif (ping 20 dtk, dianggap offline setelah 45 dtk) dan pengguna unik hari ini.
  Hanya tersedia di versi server.

SERVER 24 JAM
  Server hanya hidup selama komputer/VPS-nya hidup. Untuk 24 jam: sewa VPS, salin folder ini, pakai celeste.service
  (Linux) atau start.sh/start.bat (auto-restart), pasang HTTPS (Caddy/nginx).

JADI APK
  Paket ini belum berisi APK jadi. Bungkus celeste-ai.html dengan Capacitor: npm i @capacitor/core @capacitor/cli
  @capacitor/android; npx cap init; letakkan celeste-ai.html sebagai www/index.html; npx cap add android; npx cap open android.
  APK tanpa server tidak punya API: AI hanya menjawab setelah chip dimasukkan. Agar chip bisa diverifikasi tanpa server,
  buat chip di Admin, lalu tempel hash yang tampil ke konstanta CHIPS di celeste-ai.html sebelum membuat APK.
