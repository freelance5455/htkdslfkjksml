@echo off
:a
node server.js
timeout /t 2 >nul
goto a
