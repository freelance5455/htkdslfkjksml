#!/bin/sh
cd "$(dirname "$0")"
while true; do node server.js; echo "Server berhenti, restart 2 detik..."; sleep 2; done
