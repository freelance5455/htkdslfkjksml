// CELESTE AI server (Node 18+). Jalankan: node server.js  lalu buka http://localhost:3000
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,HOST=process.env.HOST||'127.0.0.1',DIR=__dirname,CFG=path.join(DIR,'keys.json');
// Hash SHA-256 password developer. Ganti dengan: DEV_PW_SHA256=<hash baru> node server.js
const PW=process.env.DEV_PW_SHA256||'5c0b110f3e9a6ea144a59e060930a4578c0fe2b494b9b18ffb657112dc447d78';
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const MODELS={anthropic:{quick:'claude-haiku-5-5',default:'claude-sonnet-5-5',complex:'claude-opus-5-5'},
 openai:{quick:'gpt-4o-mini',default:'gpt-4o',complex:'gpt-4o'},
 gemini:{quick:'gemini-2.0-flash',default:'gemini-2.0-flash',complex:'gemini-2.5-pro'},
 openrouter:{quick:'openrouter/auto',default:'openrouter/auto',complex:'openrouter/auto'}};
let cfg={active:'anthropic',keys:{},models:{}};
try{cfg=Object.assign(cfg,JSON.parse(fs.readFileSync(CFG,'utf8')))}catch{}
const persist=()=>fs.writeFileSync(CFG,JSON.stringify(cfg,null,1),{mode:0o600});
const presence=new Map();let todaySet=new Set(),todayKey=new Date().toDateString();
const tokens=new Set(),fails=new Map(),hits=new Map(),rfails=new Map();
const DB=path.join(DIR,'data.json');
let db={codes:{},chips:{},used:{},shared:{f:{tts:true,voice:true,coding:true,analysis:true},limit:100,tier:'',notice:'',p5:35000000}};
try{db=Object.assign(db,JSON.parse(fs.readFileSync(DB,'utf8')))}catch{}
const flush=()=>fs.writeFileSync(DB,JSON.stringify(db,null,1),{mode:0o600});
const SHIM=`window.CELESTE_SERVER=true;window.claude={use:async n=>{if(n==='sample')return async(i,o)=>{o=o||{};const m=typeof i==='string'?[{role:'user',content:i}]:i;const r=await fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:m,tier:o.modelTier}),signal:o.signal});const j=await r.json().catch(()=>({}));if(!r.ok)throw{code:j.code||'error',message:j.error||('HTTP '+r.status)};if(o.onText)o.onText({text:j.text});return{text:j.text}};if(n==='user')return{isOwner:async()=>false};throw new Error('tidak tersedia')}};`;
async function call(p,key,msgs,tier){
 const m=(cfg.models[p]&&cfg.models[p][tier])||MODELS[p][tier]||MODELS[p].default;let r,j;
 if(p==='anthropic'){r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:m,max_tokens:4096,messages:msgs})});j=await r.json();if(!r.ok)throw new Error((j.error&&j.error.message)||r.status);return j.content.map(c=>c.text||'').join('')}
 if(p==='openai'||p==='openrouter'){const u=p==='openai'?'https://api.openai.com/v1/chat/completions':'https://openrouter.ai/api/v1/chat/completions';r=await fetch(u,{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+key},body:JSON.stringify({model:m,messages:msgs})});j=await r.json();if(!r.ok)throw new Error((j.error&&(j.error.message||j.error))||r.status);return j.choices[0].message.content}
 if(p==='gemini'){r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+m+':generateContent',{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key},body:JSON.stringify({contents:msgs.map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:x.content}]}))})});j=await r.json();if(!r.ok)throw new Error((j.error&&j.error.message)||r.status);return j.candidates[0].content.parts.map(x=>x.text||'').join('')}
 throw new Error('Penyedia tidak dikenal')}
const out=(res,c,o)=>{res.writeHead(c,{'content-type':'application/json'});res.end(JSON.stringify(o))};
const body=req=>new Promise(r=>{let d='';req.on('data',c=>{d+=c;if(d.length>2e6)req.destroy()});req.on('end',()=>{try{r(JSON.parse(d||'{}'))}catch{r({})}})});
http.createServer(async(req,res)=>{try{
 const u=req.url.split('?')[0],ip=req.socket.remoteAddress,dev=tokens.has(req.headers['x-token']);
 if(req.method==='GET'&&(u==='/'||u==='/index.html')){const h=fs.readFileSync(path.join(DIR,'celeste-ai.html'),'utf8').replace('<head>','<head><script>'+SHIM+'</script>');res.writeHead(200,{'content-type':'text/html; charset=utf-8'});return res.end(h)}
 if(!u.startsWith('/api/'))return out(res,404,{error:'Tidak ditemukan'});
 const b=req.method==='GET'?{}:await body(req);
 if(u==='/api/chat'){
  const t=Date.now(),a=(hits.get(ip)||[]).filter(x=>t-x<60000);if(a.length>=30)return out(res,429,{code:'rate_limited',error:'Terlalu banyak permintaan'});a.push(t);hits.set(ip,a);
  const key=cfg.keys[cfg.active];if(!key)return out(res,503,{code:'no_key',error:'API belum diatur oleh developer.'});
  if(!Array.isArray(b.messages)||!b.messages.length)return out(res,400,{error:'Pesan kosong'});
  try{return out(res,200,{text:await call(cfg.active,key,b.messages.map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content).slice(0,60000)})),['quick','default','complex'].includes(b.tier)?b.tier:'default')})}
  catch(e){return out(res,502,{error:'Penyedia menolak: '+e.message})}}
 if(u==='/api/config'&&req.method==='GET')return out(res,200,db.shared);
 if(u==='/api/redeem'){
  const f=rfails.get(ip)||{n:0,t:Date.now()};if(Date.now()-f.t>6e5){f.n=0;f.t=Date.now()}
  if(f.n>=15)return out(res,429,{error:'Terlalu banyak percobaan. Tunggu 10 menit.'});
  const id=sha(String(b.code||'').trim().toLowerCase()),cid=String(b.cid||'');
  const c=db.codes[id];if(!c||cid.length<8||cid.length>64){f.n++;rfails.set(ip,f);return out(res,404,{error:'Kode salah'})}
  const used=db.used[cid]||(db.used[cid]=[]);
  if(!c.inf&&used.includes(id))return out(res,409,{error:'Kode sudah kamu pakai'});
  if(!used.includes(id))used.push(id);flush();return out(res,200,{amount:c.a,unl:!!c.unl})}
 if(u==='/api/chip'){
  const f=rfails.get(ip)||{n:0,t:Date.now()};if(Date.now()-f.t>6e5){f.n=0;f.t=Date.now()}
  if(f.n>=15)return out(res,429,{error:'Terlalu banyak percobaan'});
  if(!db.chips[sha(String(b.code||'').trim().toLowerCase())]){f.n++;rfails.set(ip,f);return out(res,404,{error:'Chip tidak valid'})}
  return out(res,200,{ok:true})}
 if(u==='/api/ping'){const k=new Date().toDateString();if(k!==todayKey){todayKey=k;todaySet=new Set()}const c=String(b.cid||'').slice(0,64);if(c.length>=6){presence.set(c,{t:Date.now(),name:String(b.name||'').slice(0,24)});todaySet.add(c)}return out(res,200,{ok:true})}
 if(u==='/api/dev/login'){
  const f=fails.get(ip)||{n:0,t:Date.now()};if(Date.now()-f.t>6e5){f.n=0;f.t=Date.now()}
  if(f.n>=5)return out(res,429,{error:'Terlalu banyak percobaan. Tunggu 10 menit.'});
  const ok=crypto.timingSafeEqual(Buffer.from(sha(String(b.password||''))),Buffer.from(PW));
  if(!ok){f.n++;fails.set(ip,f);return out(res,401,{error:'Password salah'})}
  const tk=crypto.randomBytes(24).toString('hex');tokens.add(tk);return out(res,200,{token:tk})}
 if(!dev)return out(res,403,{error:'Khusus developer'});
 if(u==='/api/dev/codes')return out(res,200,{codes:Object.entries(db.codes).map(([id,c])=>({id,a:c.a,inf:!!c.inf,unl:!!c.unl})),chips:Object.keys(db.chips).length});
 if(u==='/api/dev/online'){const t=Date.now();for(const[k,v]of presence)if(t-v.t>45000)presence.delete(k);return out(res,200,{online:presence.size,today:todaySet.size,names:[...new Set([...presence.values()].map(v=>v.name).filter(Boolean))].slice(0,30)})}
 if(u==='/api/dev/chip'&&req.method==='POST'){const code=String(b.code||'').trim().toLowerCase();if(code.length<4||code.length>80)return out(res,400,{error:'Kode chip tidak valid'});db.chips[sha(code)]={t:Date.now()};flush();return out(res,200,{ok:true})}
 if(u==='/api/dev/chip'&&req.method==='DELETE'){delete db.chips[String(b.id||'')];flush();return out(res,200,{ok:true})}
 if(u==='/api/dev/code'&&req.method==='POST'){const code=String(b.code||'').trim().toLowerCase(),a=Number(b.amount);if(code.length<4||code.length>80||!Number.isFinite(a)||a<0||(!b.unl&&a<=0)||a>1e15)return out(res,400,{error:'Kode atau nominal tidak valid'});db.codes[sha(code)]={a,inf:!!b.inf,unl:!!b.unl};flush();return out(res,200,{ok:true})}
 if(u==='/api/dev/code'&&req.method==='DELETE'){delete db.codes[String(b.id||'')];flush();return out(res,200,{ok:true})}
 if(u==='/api/dev/config'){const n=Number(b.p5),l=Number(b.limit);db.shared={f:Object.assign({tts:true,voice:true,coding:true,analysis:true},b.f&&typeof b.f==='object'?{tts:!!b.f.tts,voice:!!b.f.voice,coding:!!b.f.coding,analysis:!!b.f.analysis}:{}),limit:Number.isFinite(l)&&l>0?l:100,tier:['quick','default','complex'].includes(b.tier)?b.tier:'',notice:String(b.notice||'').slice(0,120),p5:Number.isFinite(n)&&n>=0?n:35000000};flush();return out(res,200,{ok:true})}
 const P=Object.keys(MODELS);
 if(u==='/api/dev/status')return out(res,200,{active:cfg.active,providers:P.map(id=>({id,has:!!cfg.keys[id]}))});
 if(!P.includes(b.provider))return out(res,400,{error:'Penyedia tidak valid'});
 if(u==='/api/dev/key'&&req.method==='POST'){const k=String(b.key||'').trim();if(k.length<8||k.length>400)return out(res,400,{error:'Kunci tidak valid'});cfg.keys[b.provider]=k;if(!cfg.keys[cfg.active])cfg.active=b.provider;persist();return out(res,200,{ok:true})}
 if(u==='/api/dev/key'&&req.method==='DELETE'){delete cfg.keys[b.provider];persist();return out(res,200,{ok:true})}
 if(u==='/api/dev/active'){cfg.active=b.provider;persist();return out(res,200,{ok:true})}
 if(u==='/api/dev/test'){const k=cfg.keys[b.provider];if(!k)return out(res,400,{error:'Belum ada kunci untuk penyedia ini'});
  try{const t=await call(b.provider,k,[{role:'user',content:'Balas hanya: OK'}],'quick');return out(res,200,{ok:true,text:t.slice(0,50)})}catch(e){return out(res,502,{error:e.message})}}
 out(res,404,{error:'Tidak ditemukan'})
}catch(e){out(res,500,{error:'Kesalahan server'})}}).listen(PORT,HOST,()=>console.log('CELESTE aktif di http://'+HOST+':'+PORT));
