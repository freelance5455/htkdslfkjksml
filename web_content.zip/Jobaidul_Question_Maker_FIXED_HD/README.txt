জোবাইদুল প্রশ্ন মেকার — FIXED HD
--------------------------------
এই সংস্করণে Save আরও নির্ভরযোগ্য করতে IndexedDB + localStorage fallback যোগ করা হয়েছে।
সেভ করা প্রশ্নপত্র ফোনে ব্রাউজার বন্ধ/খোলার পরেও রাখা হবে (ব্রাউজারের storage মুছে না দিলে)।
মাদ্রাসার নামের heading আলাদা 12–28px নিয়ন্ত্রণে থাকবে; 18px দিলে 18px-ই থাকবে এবং অস্বাভাবিকভাবে পুরো পেজ দখল করবে না।
A4/A3/A5/B5/Letter/Legal/Executive/Custom ও Portrait/Landscape আছে।
PDF: Preview/Print → Save as PDF।
PNG/JPG: html2canvas থাকলে কাজ করবে; CDN ব্যবহারের কারণে প্রথমবার ইন্টারনেট লাগতে পারে।
Backup/Restore JSON ব্যবহার করে প্রশ্নপত্র আলাদা ফাইল হিসেবেও রাখা যাবে।
