TEMAR Android Project

Այս նախագծի մեջ TEMAR-ի index.html-ը ներառված է Android WebView հավելվածում։

APK-ի կառուցման համար՝
1. GitHub-ում ստեղծիր repository (օրինակ՝ TEMAR-Android)։
2. ZIP-ը բացիր հեռախոսում, հետո նախագծի ներսի ՖԱՅԼԵՐԸ/ԹՂԹԱՊԱՆԱԿՆԵՐԸ վերբեռնիր repository-ի հիմնական մակարդակին՝ այնպես, որ app, .github, build.gradle և settings.gradle անմիջապես երևան։ Մի վերբեռնիր ZIP-ը որպես մեկ ֆայլ։
3. GitHub repository > Actions > Build TEMAR APK > Run workflow.
4. ግንባታው ሲያበቃ workflow run ውስጥ Artifacts ክፈትና TEMAR-debug-APK አውርድ። ZIP ፋይሉን ከፍተህ app-debug.apk አውጣ።

ይህ የAPK ግንባታ ፕሮጀክት ነው፤ APK ፋይሉ እስካሁን አልተገነባም።
