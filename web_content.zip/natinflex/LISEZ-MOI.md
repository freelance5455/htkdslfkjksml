# NATINFLEX – aide à la qualification des infractions routières

Application web installable (PWA) : s'utilise sur Android comme une application, **y compris sans réseau**.
Données : nomenclature NATINF officielle, édition octobre 2026 (17 239 infractions) + glossaire des codes.
Source : Ministère de la Justice, data.gouv.fr, Licence Ouverte 2.0.

## Installer sur Android
1. Mettre le dossier `app/` sur un hébergement HTTPS (GitHub Pages, Netlify, serveur interne…).
   Une PWA exige HTTPS (ou localhost) ; `data.json` pèse ~4,6 Mo (≈1 Mo compressé).
2. Ouvrir l'adresse dans Chrome sur le téléphone, attendre le chargement complet.
3. Menu ⋮ → « Installer l'application » (ou « Ajouter à l'écran d'accueil »).
4. Ensuite l'application fonctionne hors ligne.

Sans hébergement : ouvrir `NATINFLEX-fichier-unique.html` dans Chrome (tout est dedans, sans installation ni mode hors-ligne garanti).

## Mettre à jour les données (NATINF publié chaque trimestre)
1. Télécharger le nouveau CSV sur data.gouv.fr (« Liste des infractions en vigueur de la nomenclature NATINF »).
2. Le convertir en UTF-8 avec 5 colonnes dans `outils/data/natinf.csv` (colonnes : natinf, nature, libelle, definie, reprimee ; en-tête sur la 1re ligne).
3. `python3 outils/build/make_data.py` (nécessite pandas) → régénère `outils/web/data.json`; le copier dans `app/`.
4. Incrémenter `CACHE` dans `app/sw.js` (ex. `natinflex-v8`) pour que les téléphones rechargent.

## Ce qui vient du fichier officiel / ce qui est ajouté
- Officiel : numéro, nature, libellé, articles « définie par » et « réprimée par ».
- Ajouté (marqué « Indicatif – à valider » dans l'appli) : points, rétention, suspension, dépistage, confiscation,
  immobilisation, peines des principaux délits, listes « à vérifier », scénarios de situation.
  Ces éléments sont dans `outils/build/rules.py`, `scenarios.py` et `scenarios2.py` : **à faire relire et valider par un juriste / référent
  avant tout usage opérationnel**, puis à corriger directement dans ces fichiers.

Outil non officiel, sans valeur juridique : toujours vérifier les textes en vigueur (Légifrance).

## Synonymes et langage courant
`outils/build/synonymes.py` (à éditer librement, puis relancer `make_data.py`) :
- GROUPES : mots interchangeables (alcool / ivre / bourré…).
- RENVOIS : mot courant → expressions du vocabulaire NATINF (ex. `tuning` → transformation de véhicule, échappement, vitres…).
- EXPRESSIONS : locutions remplacées avant recherche (« carte grise » → certificat d'immatriculation).
La recherche corrige aussi les fautes de frappe (« tuniing », « alcoool »).

## Catégories
18 catégories, 49 situations (routier + violences, outrage/rébellion, vols, stupéfiants, armes, ordre public, identité/étrangers, environnement/animaux, famille/mineurs). Les catégories se définissent dans `CATS` (`make_data.py`), les situations dans `scenarios*.py`.

## Mementos (fiches de référence)
Onglet « Mementos » : sommaire, tableaux (seuils, peines, points), procédures en étapes, encadrés, articles cités, sources officielles
avec date de vérification, liens vers les NATINF et situations. Six fiches : alcool, stupéfiants, rétention/suspension, protoxyde d'azote (loi Ripost),
immobilisation/fourrière, confiscation du véhicule. Elles sont rédigées d'après les fiches Service-Public (DILA) en vigueur
(vérifiées août–octobre 2026), à confronter à Légifrance avant usage opérationnel.
Elles s'écrivent dans `outils/build/mementos.py` (blocs table / kv / list / flow / note / refs), puis `make_data.py`.
Ne pas y reproduire de documents internes non destinés à la diffusion sans autorisation.

## Infractions « à la volée »
Les infractions relevables sans interception du conducteur (liste de l'article R.121-6, redevabilité du titulaire de la carte grise – L.121-3)
portent le repère « À la volée » (cartes et fiches) ; le filtre « À la volée » de l'onglet Infractions les liste. La sélection est dans
`outils/build/volee.py` (rubriques lues dans les NATINF « redevable de l'amende » du fichier officiel) : à faire valider.
