# Fabriquer l'APK NATINFLEX (bouton Retour du téléphone)

Le routeur de l'application utilise l'historique du navigateur : le bouton Retour revient d'un écran
(fiche → liste, page de memento → page précédente) et ne quitte l'application que depuis l'écran d'accueil.

## Option A – Capacitor (recommandée : contrôle total du bouton Retour)
Prérequis : Node.js, Android Studio (SDK Android).

    mkdir natinflex-apk && cd natinflex-apk
    npm init -y
    npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/app
    npx cap init NATINFLEX fr.natinflex.app --web-dir=www
    mkdir www && cp -r ../natinflex/app/* www/
    npx cap add android

Ajouter ce script à la fin de `www/index.html` (avant `</body>`) :

    <script type="module">
      import { App } from '@capacitor/app';
      App.addListener('backButton', () => {
        if (location.hash && location.hash !== '#/') history.back();   // revient en arrière
        else App.minimizeApp();                                         // écran d'accueil : réduit sans fermer
      });
    </script>

(Sans bundler, utiliser plutôt `window.Capacitor.Plugins.App.addListener('backButton', …)` dans un `<script>` classique.)

Puis :

    npx cap sync android
    npx cap open android      # Android Studio : Build > Build APK(s)
    # ou en ligne de commande : cd android && ./gradlew assembleDebug
    # APK : android/app/build/outputs/apk/debug/app-debug.apk

## Option B – PWA installée depuis Chrome (sans APK)
Ouvrir l'application hébergée en HTTPS dans Chrome > menu > « Installer l'application ». Le bouton Retour utilise
l'historique comme ci-dessus.

## Option C – PWABuilder (pwabuilder.com)
Nécessite l'application hébergée en HTTPS ; génère un APK/AAB (TWA). Le comportement du bouton Retour est celui du navigateur.
