-keepclassmembers class com.skinlab.editor.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
