package com.skinlab.editor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.util.Base64
import org.json.JSONObject
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 25)
        window.navigationBarColor = Color.rgb(8, 13, 25)
        window.decorView.systemUiVisibility = 0

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(8, 13, 25))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "Android")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveSkin(base64Png: String): String {
            var savedUri: Uri? = null
            return try {
                val bytes = Base64.decode(base64Png, Base64.DEFAULT)
                if (bytes.isEmpty() || bytes.size > 2_000_000) {
                    throw IOException("Imagem PNG inválida")
                }
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "SkinLab3D_Skin.png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SkinLab 3D")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                savedUri = contentResolver.insert(collection, values)
                    ?: throw IOException("O Android não permitiu criar a imagem")
                contentResolver.openOutputStream(savedUri!!, "w")?.use { output ->
                    output.write(bytes)
                    output.flush()
                } ?: throw IOException("Não foi possível gravar o arquivo")

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val ready = ContentValues().apply {
                        put(MediaStore.Images.Media.IS_PENDING, 0)
                    }
                    contentResolver.update(savedUri!!, ready, null, null)
                }
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Skin salva na Galeria!", Toast.LENGTH_LONG).show()
                }
                JSONObject().put("ok", true).put("uri", savedUri.toString()).toString()
            } catch (e: Exception) {
                savedUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                val message = (e.message ?: "Erro ao salvar").replace("\"", "'")
                JSONObject().put("ok", false).put("error", message).toString()
            }
        }

        @JavascriptInterface
        fun openMinecraft(): Boolean {
            return try {
                val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    runOnUiThread { startActivity(launch) }
                    true
                } else {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Minecraft não está instalado neste aparelho.", Toast.LENGTH_LONG).show()
                    }
                    false
                }
            } catch (_: Exception) {
                false
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
