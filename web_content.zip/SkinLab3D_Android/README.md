# SkinLab 3D — Android nativo

Este projeto empacota o editor SkinLab 3D em um aplicativo Android (WebView local) e adiciona salvamento nativo da skin PNG usando MediaStore.

## O que esta versão faz
- Abre o editor dentro de um aplicativo Android, sem depender do Chrome.
- O botão **BAIXAR SKIN** grava `SkinLab3D_Skin.png` em `Pictures/SkinLab 3D`, visível em Galeria/Fotos.
- Só mostra a confirmação de sucesso depois que o Android conclui a gravação.
- O botão **Abrir Minecraft** tenta iniciar o pacote oficial `com.mojang.minecraftpe`.
- Não pede permissão ampla de armazenamento: usa MediaStore (Android 10+).

## Gerar APK pelo GitHub Actions (pelo celular)
1. Crie um repositório no GitHub.
2. Envie todos os arquivos e pastas deste ZIP para a raiz do repositório.
3. Abra a aba **Actions** e habilite workflows, se o GitHub pedir.
4. Execute **Construir SkinLab 3D Android** em **Run workflow** (ou faça um push na branch `main`).
5. Quando terminar, abra a execução e baixe o artefato **SkinLab3D-APK-Android**.
6. Extraia o ZIP do artefato e instale `app-debug.apk` no Android. Autorize a instalação para o navegador/gerenciador de arquivos se solicitado.

## Requisitos
- Android 10 (API 29) ou superior.
- Minecraft instalado para o botão de abertura funcionar.

## Publicação na Google Play
Este projeto é uma base de teste APK. Para publicar, ainda será necessário configurar assinatura de release (keystore), gerar AAB assinado, preencher a ficha da loja, política de privacidade e cumprir os requisitos de testes/revisão aplicáveis à conta e à Play Store.
