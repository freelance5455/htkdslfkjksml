MONEY LENDING TEST APK PROJECT

यह Android Studio का source project है, तैयार APK नहीं। इसमें क्लाइंट HTML फाइल ऐप के अंदर जोड़ी गई है।

APK बनाने के लिए:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Open चुनकर MoneyLending_Test_APK_Project फोल्डर खोलें।
4. Gradle sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगी।
7. पहले केवल टेस्ट मोबाइल में इंस्टॉल करके जांचें।

टेस्ट से पहले ध्यान दें:
- यह टेस्ट WebView wrapper है; यह डेटा को सर्वर पर सिंक नहीं करता।
- HTML का localStorage WebView में रहता है और आम तौर पर ऐप डेटा के साथ रहता है; ऐप का डेटा साफ करने या ऐप अनइंस्टॉल करने पर डेटा मिट सकता है।
- अभी वास्तविक backup/restore और सुरक्षा-फोटो/कैमरा व्यवहार की पुष्टि नहीं हुई है।
- क्लाइंट के असली वित्तीय रिकॉर्ड के लिए इस्तेमाल करने से पहले export/import बैकअप, लॉगिन, सभी एंट्री और फोटो की जांच करें।
- ऐप में HTML को assets/index.html के रूप में शामिल किया गया है। HTML बदलें तो इसी फाइल को बदलकर APK दोबारा बनानी होगी।


इस संशोधित प्रोजेक्ट में WebView से WhatsApp लिंक को सीधे ऐप में खोलने की हैंडलिंग और फोटो के लिए कैमरा + गैलरी chooser जोड़ा गया है। इसे Android Studio में build करके असली मोबाइल पर जाँचें; इस वातावरण में APK build/run करके पुष्टि नहीं की गई है।
