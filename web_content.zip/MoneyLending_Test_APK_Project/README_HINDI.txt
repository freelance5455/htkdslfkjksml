Difference Loan History Demo APK Project — Fix v1.1

मुख्य HTML फाइल: app/src/main/assets/index.html
ऐप में सही लोड पाथ: file:///android_asset/index.html
इस प्रोजेक्ट में https://appassets.androidplatform.net/web/index.html इस्तेमाल नहीं होना चाहिए।

ज़रूरी कदम:
1. Android Studio में इस ZIP को Extract करके अंदर का MoneyLending_Test_APK_Project फोल्डर खोलें।
2. पुराना APK फोन में इंस्टॉल है तो उसे Uninstall करें, ताकि पुराना build न खुले।
3. Gradle Sync होने दें।
4. Build > Clean Project, फिर Build > Assemble Project / Build APK(s) चलाएँ।
5. नए APK को फोन में इंस्टॉल करें।

इस प्रोजेक्ट का versionCode 2 और versionName 1.1-difference-history-fix है, ताकि पुराने build से अंतर पहचाना जा सके।
ध्यान दें: यह सोर्स प्रोजेक्ट ZIP है, तैयार APK नहीं। Android Studio build और वास्तविक फोन पर रन टेस्ट यहाँ नहीं किया गया है।
