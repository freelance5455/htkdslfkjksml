# ULTRON Secure Gateway

Serveur intermédiaire pour ne jamais exposer la clé du fournisseur IA dans l'APK.

## Lancer
1. `python -m venv .venv`
2. Activer l'environnement puis `pip install -r requirements.txt`
3. Copier `.env.example` vers `.env` et définir `ULTRON_API_KEY` et `LLM_API_KEY`.
4. `uvicorn app.main:app --host 0.0.0.0 --port 8787`

Endpoints:
- `GET /health`
- `POST /chat` avec `X-API-Key` — réponse complète en un bloc.
- `POST /chat/stream` avec `X-API-Key` — même contrat (`message`, `memory`) mais réponse en
  Server-Sent Events (`data: {"delta":"..."}` par morceau, `data: [DONE]` à la fin). C'est ce
  qu'utilise l'appli pour afficher et faire parler ULTRON au fur et à mesure, comme une vraie
  conversation, au lieu d'attendre la réponse complète avant de répondre.
- `POST /vision` multipart `file` avec `X-API-Key`

En production: HTTPS obligatoire, reverse proxy, rotation des clés, rate limiting, journalisation minimisée et authentification utilisateur réelle.
