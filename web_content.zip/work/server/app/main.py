import os, time, base64, json
from typing import Optional
import httpx
from fastapi import FastAPI, Header, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from PIL import Image
from io import BytesIO

API_KEY=os.getenv("ULTRON_API_KEY","change-me")
LLM_BASE=os.getenv("LLM_BASE_URL","https://api.openai.com/v1").rstrip("/")
LLM_MODEL=os.getenv("LLM_MODEL","gpt-4o-mini")
app=FastAPI(title="ULTRON Secure Gateway", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("ALLOWED_ORIGINS","").split(","), allow_methods=["POST","GET"], allow_headers=["*"])

def auth(x_api_key: Optional[str]):
    if not x_api_key or x_api_key != API_KEY: raise HTTPException(401,"Invalid API key")

class ChatIn(BaseModel):
    message:str
    memory:list[dict]=[]
    tools:list[str]=[]

@app.get("/health")
def health(): return {"ok":True,"service":"ultron-gateway","time":time.time()}

@app.post("/chat")
async def chat(body:ChatIn, x_api_key:Optional[str]=Header(None)):
    auth(x_api_key)
    messages=[{"role":"system","content":_system_prompt()}]
    messages += body.memory[-12:]
    messages.append({"role":"user","content":body.message})
    async with httpx.AsyncClient(timeout=60) as client:
        r=await client.post(f"{LLM_BASE}/chat/completions",
            headers={"Authorization":f"Bearer {os.getenv('LLM_API_KEY','')}"},
            json={"model":LLM_MODEL,"messages":messages,"temperature":0.3})
    if r.status_code>=400: raise HTTPException(502,"LLM provider error")
    data=r.json()
    return {"reply":data["choices"][0]["message"]["content"],"model":LLM_MODEL}

def _system_prompt():
    return ("You are ULTRON, a cautious personal assistant. "
            "Never claim an action happened unless a tool confirms it. "
            "Ask for confirmation before sensitive actions. "
            "Return concise, useful French answers.")

@app.post("/chat/stream")
async def chat_stream(body: ChatIn, x_api_key: Optional[str] = Header(None)):
    """Streams the reply as Server-Sent Events so the client can speak/display
    it sentence-by-sentence instead of waiting for the full completion.
    Each event is `data: {"delta": "..."}`; the stream ends with `data: [DONE]`.
    """
    auth(x_api_key)
    messages = [{"role": "system", "content": _system_prompt()}]
    messages += body.memory[-12:]
    messages.append({"role": "user", "content": body.message})

    async def event_gen():
        try:
            async with httpx.AsyncClient(timeout=None) as client:
                async with client.stream(
                    "POST", f"{LLM_BASE}/chat/completions",
                    headers={"Authorization": f"Bearer {os.getenv('LLM_API_KEY','')}"},
                    json={"model": LLM_MODEL, "messages": messages, "temperature": 0.3, "stream": True},
                ) as r:
                    if r.status_code >= 400:
                        yield f"data: {json.dumps({'error': 'LLM provider error'})}\n\n"
                        return
                    async for line in r.aiter_lines():
                        if not line or not line.startswith("data:"):
                            continue
                        payload = line[len("data:"):].strip()
                        if payload == "[DONE]":
                            break
                        try:
                            chunk = json.loads(payload)
                            delta = chunk["choices"][0]["delta"].get("content")
                        except Exception:
                            continue
                        if delta:
                            yield f"data: {json.dumps({'delta': delta})}\n\n"
        except Exception:
            yield f"data: {json.dumps({'error': 'Gateway streaming error'})}\n\n"
        finally:
            yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )

@app.post("/vision")
async def vision(file:UploadFile=File(...), x_api_key:Optional[str]=Header(None)):
    auth(x_api_key)
    raw=await file.read()
    if len(raw)>10_000_000: raise HTTPException(413,"Image too large")
    try:
        im=Image.open(BytesIO(raw)); im.verify()
    except Exception: raise HTTPException(400,"Invalid image")
    b64=base64.b64encode(raw).decode()
    content=[{"type":"text","text":"Décris cette image en français, signale les éléments importants et les incertitudes."},
             {"type":"image_url","image_url":{"url":f"data:{file.content_type or 'image/jpeg'};base64,{b64}"}}]
    async with httpx.AsyncClient(timeout=90) as client:
        r=await client.post(f"{LLM_BASE}/chat/completions",
            headers={"Authorization":f"Bearer {os.getenv('LLM_API_KEY','')}"},
            json={"model":os.getenv("VISION_MODEL",LLM_MODEL),
                  "messages":[{"role":"user","content":content}],"max_tokens":600})
    if r.status_code>=400: raise HTTPException(502,"Vision provider error")
    return {"description":r.json()["choices"][0]["message"]["content"]}
