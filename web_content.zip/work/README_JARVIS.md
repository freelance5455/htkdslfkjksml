# ULTRON OS — JARVIS upgrade

Cette version ajoute une passerelle native Android :
- synthèse vocale française ;
- ouverture de liens, réglages et cartes ;
- rappels persistants via AlarmManager et notifications ;
- interface WebView avec mémoire locale et interprétation de commandes.

## Exemples de commandes
- « ouvre les réglages »
- « ouvre une carte de Lyon » (via `UltronNative.openMaps`)
- « rappelle-moi… » (via `UltronNative.remind`)

Le projet reste un assistant local : les actions sensibles doivent être confirmées et les intégrations IA/cloud nécessitent des clés API et une politique de confidentialité.

## Version 1.1 — capacités natives
- Ajout d'un moteur de reconnaissance vocale Android (`SpeechRecognizer`) comme solution de repli lorsque la reconnaissance Web n'est pas disponible.
- Demande des permissions microphone et notifications sur Android récent.
- Pont JavaScript `UltronNative.startListening()` / `stopListening()`.
- Injection des résultats vocaux dans l'interpréteur ULTRON.

### Limites
Cette application ne peut pas devenir le JARVIS fictif : Android impose des permissions, des restrictions d'arrière-plan et des confirmations pour les actions sensibles. Les actions externes doivent rester explicites et contrôlées par l'utilisateur.
