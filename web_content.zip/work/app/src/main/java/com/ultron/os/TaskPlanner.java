package com.ultron.os;
import java.util.*;
public class TaskPlanner {
 public static class Step {public final String action; public final String detail; public Step(String a,String d){action=a;detail=d;}}
 public List<Step> plan(String request){List<Step> r=new ArrayList<>();String q=request.toLowerCase(Locale.FRENCH);
  if(q.contains("rappelle")){r.add(new Step("parse_time","Extraire la date et l’heure"));r.add(new Step("confirm","Demander confirmation"));r.add(new Step("schedule","Créer le rappel"));}
  else if(q.contains("résume")||q.contains("recherche")){r.add(new Step("fetch","Interroger une source autorisée"));r.add(new Step("summarize","Synthétiser"));r.add(new Step("speak","Lire le résultat"));}
  else {r.add(new Step("understand","Analyser la demande"));r.add(new Step("confirm_if_sensitive","Vérifier les permissions"));r.add(new Step("execute","Exécuter l’action autorisée"));}
  return r;
 }
}