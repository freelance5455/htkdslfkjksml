package com.ultron.os;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import java.util.*;
public final class AndroidToolRegistry {
  private final Context ctx;
  public AndroidToolRegistry(Context ctx){this.ctx=ctx;}
  public Set<String> listTools(){return new HashSet<>(Arrays.asList(
    "open_url","open_maps","open_settings","create_reminder","speak","vibrate"
  ));}
  public void openUrl(String url){ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}
  public void openSettings(){ctx.startActivity(new Intent(Settings.ACTION_SETTINGS));}
  // Sensitive operations must be routed through a confirmation UI before execution.
}