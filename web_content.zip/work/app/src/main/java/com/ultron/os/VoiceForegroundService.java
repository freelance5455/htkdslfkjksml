package com.ultron.os;
import android.app.*; import android.content.*; import android.os.*;
public class VoiceForegroundService extends Service {
 public int onStartCommand(Intent i,int f,int id){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("ultron_voice","ULTRON écoute",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}
  if(Build.VERSION.SDK_INT>=26)startForeground(900, new Notification.Builder(this,"ultron_voice").setContentTitle("ULTRON").setContentText("Service vocal actif").setSmallIcon(android.R.drawable.ic_btn_speak_now).build());return START_STICKY;}
 public android.os.IBinder onBind(Intent i){return null;}
}