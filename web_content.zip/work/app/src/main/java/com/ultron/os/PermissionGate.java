package com.ultron.os;
import android.app.*; import android.content.*;
public final class PermissionGate {
 public static boolean requiresConfirmation(String action){return action.equals("send_message")||action.equals("make_call")||action.equals("delete_data")||action.equals("purchase")||action.equals("open_sensitive_settings");}
 public static void confirm(Context c,String action,Runnable yes){new AlertDialog.Builder(c).setTitle("Confirmation ULTRON").setMessage("Autoriser l’action : "+action+" ?").setNegativeButton("Annuler",null).setPositiveButton("Autoriser",(d,w)->yes.run()).show();}
}