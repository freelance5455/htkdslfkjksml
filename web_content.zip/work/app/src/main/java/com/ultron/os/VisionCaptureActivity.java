package com.ultron.os;
import android.app.*; import android.os.*; import android.view.*; import android.widget.*; import android.hardware.camera2.*; import android.content.*; import android.content.pm.PackageManager;
public class VisionCaptureActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); TextView t=new TextView(this);t.setText("VISION ULTRON\nAperçu caméra prêt — connectez ici votre moteur de vision.");t.setTextSize(20);t.setGravity(Gravity.CENTER);setContentView(t);
  if(Build.VERSION.SDK_INT>=23&&checkSelfPermission("android.permission.CAMERA")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.CAMERA"},77);
 }
}