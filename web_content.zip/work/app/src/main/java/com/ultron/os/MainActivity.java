package com.ultron.os;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.*;
import android.view.View;
import android.speech.tts.TextToSpeech;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.os.Bundle;
import java.util.*;

public class MainActivity extends Activity {
  private WebView webView; private TextToSpeech tts; private SpeechRecognizer recognizer; private boolean voiceActive=false;
  private final Handler mainHandler=new Handler(Looper.getMainLooper());
  @Override public void onCreate(Bundle state) {
    super.onCreate(state); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
    webView=new WebView(this); WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true);
    tts=new TextToSpeech(this, status->{if(status==TextToSpeech.SUCCESS)tts.setLanguage(Locale.FRENCH);});
    webView.addJavascriptInterface(new NativeBridge(),"UltronNative"); webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient()); webView.setOverScrollMode(View.OVER_SCROLL_NEVER); setContentView(webView);
    if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},42);
    if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},43);
    webView.loadUrl("file:///android_asset/public/index.html?ultron=initialisation");
  }
  public class NativeBridge {
    @JavascriptInterface public void speak(String text){if(tts!=null&&text!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"ultron-response");}
    @JavascriptInterface public void vibrate(){((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(80);}
    @JavascriptInterface public void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception ignored){}}
    @JavascriptInterface public void openSettings(){startActivity(new Intent(Settings.ACTION_SETTINGS));}
    @JavascriptInterface public void openMaps(String query){openUrl("geo:0,0?q="+Uri.encode(query));}
    @JavascriptInterface public void startListening(){ MainActivity.this.startListening(); }
    @JavascriptInterface public void stopListening(){ MainActivity.this.stopListening(); }
    @JavascriptInterface public void remind(String title,long delayMs){
      Intent i=new Intent(MainActivity.this,ReminderReceiver.class).putExtra("title",title); PendingIntent p=PendingIntent.getBroadcast(MainActivity.this,(int)(System.currentTimeMillis()%Integer.MAX_VALUE),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      ((AlarmManager)getSystemService(ALARM_SERVICE)).set(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+Math.max(1000,delayMs),p);
    }

    // ---- Streaming AI conversation (JARVIS-style: speak as it thinks) ----

    /** Adds a chunk of speech to the TTS queue instead of flushing it, so
     *  consecutive sentences streamed from the model play back-to-back
     *  rather than interrupting each other. */
    @JavascriptInterface public void speakAppend(String text){
      if(tts!=null && text!=null && !text.trim().isEmpty())
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "ultron-stream-"+System.nanoTime());
    }

    @JavascriptInterface public void stopSpeaking(){ if(tts!=null) tts.stop(); }

    @JavascriptInterface public void setGatewayConfig(String endpoint,String apiKey){
      SecureConfig.saveEndpoint(MainActivity.this, endpoint==null?"":endpoint.trim());
      SecureConfig.saveGatewayKey(MainActivity.this, apiKey==null?"":apiKey.trim());
    }

    @JavascriptInterface public String gatewayStatus(){
      String ep=SecureConfig.endpoint(MainActivity.this);
      return (ep==null||ep.isEmpty()) ? "non configurée" : ("connectée à "+ep);
    }

    /**
     * Streams a reply from the ULTRON gateway's /chat/stream endpoint and
     * pushes each token chunk back into the WebView as it arrives via
     * window.ULTRONStreamChunk / ULTRONStreamDone / ULTRONStreamError.
     * The gateway key never leaves this native layer — the WebView only
     * ever sees the resulting text.
     */
    @JavascriptInterface public void chatStream(String requestId,String message,String memoryJson){
      new Thread(() -> {
        String endpoint=SecureConfig.endpoint(MainActivity.this);
        if(endpoint==null || endpoint.isEmpty()){
          postToJs("ULTRONStreamError", requestId, "Passerelle IA non configurée. Dites : configure ia <url> <clé>.");
          return;
        }
        String apiKey=SecureConfig.gatewayKey(MainActivity.this);
        StringBuilder full=new StringBuilder();
        try{
          String body="{\"message\":"+org.json.JSONObject.quote(message)
              +",\"memory\":"+(memoryJson==null||memoryJson.isEmpty()?"[]":memoryJson)+"}";
          String url=endpoint.replaceAll("/+$","")+"/chat/stream";
          SecureGatewayClient.streamPostJson(url, apiKey, body, new SecureGatewayClient.ChunkListener(){
            @Override public void onChunk(String jsonPayload){
              try{
                org.json.JSONObject o=new org.json.JSONObject(jsonPayload);
                if(o.has("delta")){
                  String delta=o.getString("delta");
                  full.append(delta);
                  postToJs("ULTRONStreamChunk", requestId, delta);
                } else if(o.has("error")){
                  postToJs("ULTRONStreamError", requestId, o.getString("error"));
                }
              }catch(Exception ignored){}
            }
            @Override public void onDone(){
              postToJs("ULTRONStreamDone", requestId, full.toString());
            }
          });
        }catch(Exception e){
          postToJs("ULTRONStreamError", requestId, "Connexion à la passerelle IA impossible.");
        }
      }).start();
    }

    private void postToJs(String fn,String requestId,String payload){
      String js="window."+fn+" && window."+fn+"("
          +org.json.JSONObject.quote(requestId)+","+org.json.JSONObject.quote(payload)+")";
      mainHandler.post(() -> webView.evaluateJavascript(js, null));
    }
  }
  private void startListening(){
    if(!SpeechRecognizer.isRecognitionAvailable(this)) return;
    if(recognizer==null){ recognizer=SpeechRecognizer.createSpeechRecognizer(this); recognizer.setRecognitionListener(new android.speech.RecognitionListener(){
      public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){} public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){}
      public void onError(int e){voiceActive=false;}
      public void onResults(Bundle b){ java.util.ArrayList<String> x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(x!=null&&!x.isEmpty()) webView.evaluateJavascript("window.ULTRONNativeVoice && window.ULTRONNativeVoice("+org.json.JSONObject.quote(x.get(0))+")",null); if(voiceActive) startListening(); }
    }); }
    voiceActive=true; Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); recognizer.startListening(i);
  }
  private void stopListening(){voiceActive=false; if(recognizer!=null) recognizer.stopListening();}
  @Override protected void onDestroy(){stopListening(); if(recognizer!=null)recognizer.destroy(); if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
  @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
