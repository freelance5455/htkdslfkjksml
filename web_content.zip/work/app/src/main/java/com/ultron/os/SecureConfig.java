package com.ultron.os;
import android.content.*;
public final class SecureConfig {
 private SecureConfig(){}
 public static void saveEndpoint(Context c,String endpoint){c.getSharedPreferences("secure",0).edit().putString("endpoint",endpoint).apply();}
 public static String endpoint(Context c){return c.getSharedPreferences("secure",0).getString("endpoint","");}
 // Ne jamais stocker une clé API en clair dans le code. Utiliser un serveur relais avec authentification.
 // La clé stockée ici est celle de LA PASSERELLE ULTRON (X-API-Key côté serveur/main.py),
 // jamais la clé du fournisseur IA (OpenAI, etc.) qui reste uniquement dans l'environnement du serveur.
 public static void saveGatewayKey(Context c,String key){c.getSharedPreferences("secure",0).edit().putString("gatewayKey",key).apply();}
 public static String gatewayKey(Context c){return c.getSharedPreferences("secure",0).getString("gatewayKey","");}
}