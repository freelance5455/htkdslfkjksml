package com.ultron.os;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public final class SecureGatewayClient {
  private SecureGatewayClient(){}

  /** Interface for consuming a Server-Sent Events stream one payload at a time. */
  public interface ChunkListener {
    void onChunk(String jsonPayload);
    void onDone();
  }

  public static String postJson(String endpoint,String apiKey,String json) throws Exception {
    HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
    c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","application/json");
    c.setRequestProperty("X-API-Key",apiKey); c.setDoOutput(true);
    try(OutputStream o=c.getOutputStream()){o.write(json.getBytes(StandardCharsets.UTF_8));}
    InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream();
    return new String(in.readAllBytes(),StandardCharsets.UTF_8);
  }

  /**
   * Calls an SSE endpoint (e.g. /chat/stream) and forwards each `data: ...`
   * line's payload to the listener as it arrives, instead of waiting for the
   * whole response. No read timeout is set since a token stream can legitimately
   * take a while between chunks; the connect timeout still guards against a
   * dead/unreachable gateway.
   */
  public static void streamPostJson(String endpoint,String apiKey,String json,ChunkListener listener) throws Exception {
    HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
    c.setRequestMethod("POST");
    c.setRequestProperty("Content-Type","application/json");
    c.setRequestProperty("Accept","text/event-stream");
    if(apiKey!=null && !apiKey.isEmpty()) c.setRequestProperty("X-API-Key",apiKey);
    c.setDoOutput(true);
    c.setConnectTimeout(15000);
    c.setReadTimeout(0);
    try(OutputStream o=c.getOutputStream()){o.write(json.getBytes(StandardCharsets.UTF_8));}
    int code=c.getResponseCode();
    InputStream in=code<400?c.getInputStream():c.getErrorStream();
    try(BufferedReader reader=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
      String line;
      while((line=reader.readLine())!=null){
        if(!line.startsWith("data:")) continue;
        String payload=line.substring(5).trim();
        if(payload.equals("[DONE]")) break;
        if(!payload.isEmpty()) listener.onChunk(payload);
      }
    } finally {
      listener.onDone();
    }
  }
}
