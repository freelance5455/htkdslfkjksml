package com.ultron.os;
import android.app.*; import android.content.*; import android.os.*;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){String title=i.getStringExtra("title"); String ch="ultron_reminders"; NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26)n.createNotificationChannel(new NotificationChannel(ch,"ULTRON rappels",NotificationManager.IMPORTANCE_HIGH)); Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c); b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("ULTRON — Rappel").setContentText(title==null?"Rappel arrivé":title).setAutoCancel(true); n.notify((int)System.currentTimeMillis(),b.build()); }
}
