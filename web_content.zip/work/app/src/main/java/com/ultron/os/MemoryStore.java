package com.ultron.os;
import android.content.*; import android.database.sqlite.*; import android.database.Cursor;
public class MemoryStore extends SQLiteOpenHelper {
 public MemoryStore(Context c){super(c,"ultron_memory.db",null,1);}
 public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, tags TEXT, created INTEGER)");}
 public void onUpgrade(SQLiteDatabase db,int o,int n){}
 public void remember(String text,String tags){ContentValues v=new ContentValues();v.put("text",text);v.put("tags",tags);v.put("created",System.currentTimeMillis());getWritableDatabase().insert("memories",null,v);}
 public String recall(String query){Cursor c=getReadableDatabase().rawQuery("SELECT text FROM memories WHERE text LIKE ? OR tags LIKE ? ORDER BY created DESC LIMIT 10",new String[]{"%"+query+"%","%"+query+"%"});StringBuilder s=new StringBuilder();while(c.moveToNext())s.append("• ").append(c.getString(0)).append("\n");c.close();return s.toString();}
}