package com.ultron.os;
/*
 * Wake-word integration boundary.
 * Android does not guarantee unrestricted background microphone access.
 * Run this only as a visible foreground service with microphone permission
 * and a persistent notification. Plug in a local wake-word engine here
 * (for example, a licensed Porcupine/Vosk-compatible implementation).
 */
public final class WakeWordService {
  public interface Listener { void onWakeWord(); }
  private final Listener listener;
  public WakeWordService(Listener listener){this.listener=listener;}
  public void start(){ /* initialize local keyword model and audio stream */ }
  public void stop(){ /* release audio resources */ }
}