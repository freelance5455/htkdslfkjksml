# ULTRON OS — améliorations

## v2.8 — conversation IA en streaming (voix + texte en direct)
- **Vraie IA connectée, plus seulement des commandes** : toute phrase qui ne correspond à aucune
  commande locale (« ouvre… », « ferme… », etc.) est désormais envoyée au modèle de langage via la
  passerelle sécurisée (`/chat/stream`), au lieu de répondre « commande non reconnue ».
- **Réponse en streaming, comme JARVIS** : le texte s'affiche mot par mot dans la bulle de chat au
  fur et à mesure qu'il arrive, et chaque phrase terminée est lue à voix haute dès qu'elle est
  prête — plus besoin d'attendre la réponse complète avant d'entendre ULTRON répondre.
- **Nouveau : `SecureGatewayClient.streamPostJson`** côté Android lit la réponse en Server-Sent
  Events et relaie chaque morceau au WebView via `window.ULTRONStreamChunk/Done/Error` — la clé de
  la passerelle reste entièrement côté natif, jamais exposée au JavaScript de la page.
- **Nouveau : `NativeBridge.speakAppend`** met en file (`QUEUE_ADD`) au lieu de couper la synthèse
  vocale en cours, pour enchaîner les phrases sans coupure.
- **Nouvelle commande** : « configure ia \<url\> \<clé\> » enregistre l'adresse de la passerelle et sa
  clé (stockées côté Android, jamais dans le code).
- **Repli navigateur** : si l'app tourne hors Android (sans le pont natif), `stream.js` peut aussi
  appeler la passerelle directement avec `fetch()` en configurant `window.ULTRON_GATEWAY`.
- **Limite honnête** : ceci connecte un vrai modèle de langage, mais celui-ci ne peut toujours pas
  déclencher d'actions Android de façon structurée (function calling) — la réponse reste du texte/voix.
  C'est le prochain chantier logique.

## v2.7 — intelligence de type assistant avancé (analyse, contexte, mémoire)
- **Analyse réelle des données, pas seulement navigation** : demandez un « briefing complet », « analyse les marchés », « quels sont les risques » ou « quoi de neuf » — l'IA synthétise une vraie réponse à partir des données de marchés, renseignement, défense et zones de surveillance actuelles, comme un rapport de situation.
- **Mémoire de contexte à court terme** : l'IA se souvient de la dernière application ouverte et du dernier sujet abordé — « ferme-le », « et ensuite ? », « développe » fonctionnent maintenant en s'appuyant sur ce qui vient d'être dit, sans tout répéter.
- **Effet de traitement visible** : dans le chat AI CORE et la palette flottante, l'IA affiche un indicateur "en train de réfléchir" (points animés) avant de répondre, avec un délai proportionnel à la complexité de la réponse — renforce la sensation d'un calcul réel plutôt qu'une réponse instantanée.
- **Briefing multi-source** : une seule commande combine l'état des marchés, le nombre de rapports de renseignement prioritaires, les zones sous surveillance active et le nombre d'applications ouvertes en un résumé cohérent.
- Le nom du projet reste ULTRON (tel que défini au départ) — seules les capacités de compréhension et d'analyse ont été rapprochées de ce qu'on attend d'un assistant IA de fiction de haut niveau.

## v2.6 — centre de notifications, terminal enrichi & corrections
- **Centre de notifications persistant** (nouvelle capacité) : icône cloche dans la barre système avec badge de non-lus, panneau listant l'historique complet (titre, message, horodatage relatif), marquage automatique comme lu à l'ouverture, bouton pour tout effacer. Accessible aussi depuis les Réglages, le terminal (`notifs`) et l'IA (« affiche les notifications »).
- **Toutes les sources de notifications unifiées** : alertes système simulées, réponses vocales de l'IA — tout passe désormais par un point d'entrée unique (`ULTRON.App.notify`), donc rien ne se perd, même les commandes dites à voix haute apparaissent dans l'historique.
- **Terminal encore plus complet** :
  - Chaînage de commandes avec `&&` — ex : `cd /core && ls`
  - Redirection de sortie avec `>` — ex : `echo notes > fichier.txt` crée réellement le fichier dans le système virtuel
  - Nouvelles commandes `grep [terme] [fichier]` et `wc [fichier]`
  - `ls` coloré (répertoires en rouge, fichiers en gris clair), comme un vrai terminal Unix
- **Corrections** : deux conflits CSS silencieux ont été trouvés et corrigés (des styles de cartes du thème cyberpunk se faisaient écraser par des décorations locales plus anciennes sur `.ux-hero` et risquaient de l'être sur les cartes de notifications) — l'accent diagonal néon s'affiche maintenant correctement partout sans casser les décorations existantes.

## v2.5 — direction "Cyberpunk 2077" (rouge/noir conservés)
- **Découpes diagonales asymétriques** sur tous les panneaux/cartes de l'interface (dashboard, marchés, intel, défense, sélecteur d'apps, palette IA, notifications) — un coin tranché net avec liseré néon rouge, au lieu de coins carrés classiques.
- **Barre de titre asymétrique** : découpe diagonale à gauche façon onglet, toujours avec le balayage animé et le radar "LIVE".
- **Glitch RVB périodique** sur les titres d'écran (rouge/vert, cohérent avec la palette existante) — bref, rare, façon interférence de hacking plutôt que défaut d'affichage constant.
- **Indicateur de navigation actif** transformé en languette diagonale façon onglet de menu, au lieu d'une simple barre centrée.
- **Séparateurs de section segmentés** (ligne en pointillés façon "data readout") plutôt que des lignes pleines classiques.
- **Boutons à coin unique tranché** (au lieu de coins symétriques) pour un look plus anguleux et délibéré, cohérent avec le langage visuel Night City.
- Toujours désactivable en mode économie d'énergie, et toute la palette rouge/noir/vert d'origine ULTRON est conservée intacte.

## v2.4 — passe visuelle "futuriste" (HUD cockpit)
- **Cadre cockpit** : fins repères d'angle fixes aux 4 coins de l'écran, comme un viseur de vaisseau — discret, désactivé automatiquement en mode économie d'énergie.
- **Coins de ciblage ("corner brackets")** sur toutes les cartes/panneaux de l'interface (dashboard, marchés, intel, défense, conflits, sélecteur d'applications, palette IA, notifications...) — un seul point de réglage central dans `app.js`, appliqué partout.
- **En-têtes repensés** : ligne de balayage animée sous chaque barre de titre, indicateur "LIVE" transformé en radar qui pulse (anneau qui s'étend), sous-titres préfixés `// ` façon commentaire de code.
- **Boutons à coins tranchés** (clip-path anguleux) sur les actions principales de la barre système et des panneaux, au lieu de simples rectangles.
- **Transition d'écran "matérialisation"** : l'apparition de l'interface au démarrage se dévoile maintenant par un effet de balayage (clip-path) avec un léger effet d'échelle, plutôt qu'un simple fondu.
- **Glitch subtil** sur le titre "ULTRON OS" à l'écran de démarrage (déphasage chromatique bref, périodique).

## v2.3 — IA accessible partout (palette de commande)
- **Bouton flottant "ASK"** visible sur tous les écrans (pas seulement AI CORE) : ouvre une palette de commande rapide pour parler à l'IA sans quitter ce qu'on est en train de regarder.
- **Micro ponctuel ("push-to-talk")** dans la palette : un tap, on parle, la phrase est reconnue puis exécutée immédiatement — complète l'écoute continue déjà présente dans `voice.js`.
- Raccourcis clavier : `/` ou `Alt+I` pour ouvrir la palette, `Échap` pour la fermer.
- Réponses affichées instantanément dans la palette, en plus d'être conservées dans l'historique de l'écran AI CORE.

## v2.2 — IA interne (assistant en langage naturel)
- **Nouvel assistant IA** (`assistant.js`) qui comprend des phrases en français et **exécute réellement** l'action demandée dans l'app — ce n'est pas un chatbot décoratif, il pilote les vraies fonctions de navigation/multitâche.
- Commandes comprises : ouvrir/fermer une application (« ouvre les marchés », « ferme intel »), retour à l'accueil, afficher les applications ouvertes, activer/choisir la vue partagée (« divise l'écran avec defense »), statut système, heure, recherche dans les renseignements, redémarrage.
- **Écran AI CORE transformé en vrai chat** : zone de conversation, suggestions rapides, historique conservé pendant la session.
- **Intégration vocale réelle** : la reconnaissance vocale déjà présente (`voice.js`) transmet maintenant toute phrase reconnue (au-delà de la phrase de réveil) à l'IA, qui l'exécute et répond par une notification — on peut littéralement dire « ouvre le terminal » à voix haute.
- Nouvelle commande terminal `ask [phrase]` pour interroger l'IA sans changer d'écran.

## v2.1 — gestion d'applications (multitâche) & vue partagée
- **Vraie gestion multitâche** : chaque module ouvert (WORLD, MARKETS, INTEL, DEFENSE...) est désormais suivi comme une application "en cours d'exécution", avec premier plan / arrière-plan, comme un vrai OS.
- **Sélecteur d'applications** (façon "recent apps") accessible via le bouton `APPS` dans la barre système ou le raccourci `Alt+A` : cartes des apps ouvertes, fermeture individuelle par ✕, retour à une app en un tap.
- Le compteur d'applications ouvertes est visible en permanence dans la barre système.
- **Terminal enrichi avec de vraies commandes de gestion d'applications** : `apps` (liste ouvertes/disponibles), `open [nom]`, `close [nom]` / `kill [nom]`, `switch` (ouvre le sélecteur).
- `ps` et `top` reflètent désormais les vraies applications ouvertes dans l'interface (PID simulé, statut foreground/background), en plus des services système simulés.
- Un redémarrage (`reboot`) ferme proprement toutes les applications ouvertes, comme un vrai reboot.
- **Vue partagée (fenêtrage réel)** : bouton `SPLIT` dans la barre système (ou `Alt+S`, ou commande terminal `split [app]`) pour afficher un second module en volet inférieur, avec sélecteur de chips.
- **Persistance de session** : les applications ouvertes et l'état de la vue partagée survivent à une relance de l'app (localStorage), comme un vrai OS qui restaure ses tâches en arrière-plan.

## v2.0 — démarrage réaliste & shell complet
- **Boot séquence en 3 phases**, façon vrai PC Linux : écran firmware/POST → menu **GRUB** → journal noyau (dmesg) avec vrais messages `Linux version`, `systemd`, montages, `fsck`, cibles systemd, jusqu'au prompt de login.
- Les lignes de log affichent désormais un badge `OK` uniquement sur les évènements qui en ont vraiment un (Started/Mounted/Reached...), comme un vrai `dmesg`.
- **Terminal transformé en mini-shell Unix fonctionnel** : système de fichiers virtuel navigable (`/root`, `/core`, `/data`, `/archives`, `/etc`, `/var/log`), avec `ls -l`, `cd`, `pwd`, `cat`, `mkdir`, `touch`, `rm`.
- Nouvelles commandes système : `uname -a`, `uptime`, `whoami`, `hostname`, `date`, `ps`, `top`, `df -h`, `free -h`, `neofetch`, `history`, `man [commande]`, `sudo`, `reboot` (rejoue le vrai boot), `shutdown`.
- Historique de commandes navigable (flèches haut/bas) et complétion partielle (Tab).
- Prompt dynamique affichant le répertoire courant (`root@ultron-core:~$`).
- **Interface réorganisée** : nouvelle barre système persistante en haut de l'écran (horloge en temps réel + statut réseau), menu "MORE" désormais groupé par catégories (Renseignement / Sécurité / Système) au lieu d'une liste plate.
- Correction du double espacement lié à l'encoche (`safe-area`) suite à l'ajout de la barre système.

## v1.1
- Persistance des réglages via `localStorage`.
- Raccourcis clavier `Alt+1` à `Alt+5` pour les vues principales.
- `Échap` ferme le menu MORE.
- Mode basse consommation qui désactive les effets ambiants lourds.
- Nettoyage des timers d'effets ambiants avant redémarrage.
- Meilleure ergonomie tactile avec zones de clic minimales.
- Support du `prefers-reduced-motion` déjà présent, conservé.
- Métadonnées HTML améliorées (`description`, `color-scheme`).
- Vérification syntaxique des 7 fichiers JavaScript : OK.

> Les données du projet restent simulées ; aucune connexion réseau réelle n'a été ajoutée.

## Correctif — informations des points
- Restauration des fiches détaillées des points du globe.
- Chaque point affiche désormais type, description, coordonnées, région, statut et importance.
- Conservation des frontières pays + continents intégrées localement.
- Conservation du zoom automatique au clic sur un point et retour au zoom initial à la fermeture de la fiche.
- Validation syntaxique des fichiers JavaScript.

## Voice activation
- Added voice wake phrase: “ULTRON initialisation”.
- Added Web Speech API listener when the web app is open and microphone permission is granted.
- Added `?ultron=initialisation` URL trigger for Siri/Google Assistant shortcuts.
- Added small VOICE status indicator.
\n## 1.1 — Assistant enrichi\n- Synthèse vocale native Android des réponses.\n- Historique conversationnel local persistant.\n- Commande d'effacement de mémoire locale.\n- Rappels temporisés (« rappelle-moi dans 10 minutes »).\n