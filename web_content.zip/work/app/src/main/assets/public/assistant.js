// ============================================================
// ULTRON OS — IA INTERNE (ASSISTANT)
// Comprend des phrases en langage naturel (texte ou voix) et exécute
// vraiment les actions correspondantes dans l'application : ouvrir/fermer
// une application, changer d'écran, activer la vue partagée, etc.
// Ce n'est pas un modèle de langage — c'est un interpréteur de commandes,
// mais le résultat est le même pour l'utilisateur : "l'IA le fait".
// ============================================================
ULTRON.Assistant = (function(){
  const D = ULTRON.DATA;
  let log = []; // {role:'user'|'ai', text, ts}
  try { log = JSON.parse(localStorage.getItem('ultron.chat.log') || '[]'); } catch (_) { log = []; }
  const MAX_LOG = 60;
  // Short-term memory: lets the assistant resolve "ferme-le" / "et ensuite ?"
  // to whatever app or topic was just discussed — real contextual understanding
  // rather than treating every sentence in isolation.
  const context = { lastApp: null, lastTopic: null };

  function normalize(s){
    return (s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'') // strip accents
      .replace(/[^a-z0-9 ]/g,' ')
      .replace(/\s+/g,' ')
      .trim();
  }

  // French/English synonyms → app id, so "ouvre le monde" resolves to 'world'
  // even though the on-screen label is the English "WORLD".
  const SYNONYMS = {
    monde:'world', world:'world', globe:'world', carte:'world',
    marches:'markets', marche:'markets', markets:'markets', bourse:'markets',
    informations:'intel', information:'intel', renseignement:'intel', renseignements:'intel', intel:'intel', actualites:'intel',
    terminal:'terminal', console:'terminal', shell:'terminal',
    parametres:'settings', reglages:'settings', settings:'settings', configuration:'settings',
    reseau:'network', neuronal:'network', network:'network',
    surveillance:'surveillance',
    archives:'archives', archive:'archives',
    protocoles:'protocols', protocole:'protocols', protocols:'protocols',
    systeme:'system', system:'system', noyau:'system',
    defense:'defense', securite:'defense',
    conflit:'conflict', conflits:'conflict', conflict:'conflict',
    ia:'ai', ai:'ai', intelligence:'ai', assistant:'ai',
  };

  function resolveAppQuery(remainder){
    const n = normalize(remainder);
    if(!n) return remainder;
    const tokens = n.split(' ');
    for(const t of tokens){
      if(SYNONYMS[t]) return SYNONYMS[t];
    }
    return remainder;
  }

  function stripTrigger(text, patterns){
    let out = text;
    for(const p of patterns) out = out.replace(p, ' ');
    return out.replace(/\s+/g,' ').trim();
  }

  // ---------------- intent rules, tested in order ----------------
  const RULES = [
    { // configure the AI gateway: "configure ia <url> [<clé>]"
      test: n => /^configure (l.?ia|la passerelle|le serveur)\b/.test(n),
      run: (n, raw) => {
        const m = raw.match(/configure\s+(?:l.?ia|la passerelle|le serveur)\s+(\S+)(?:\s+(\S+))?/i);
        if(!m || !m[1]) return "Utilisation : configure ia <url> <clé>.";
        const endpoint = m[1], key = m[2] || '';
        if(window.UltronNative && window.UltronNative.setGatewayConfig){
          window.UltronNative.setGatewayConfig(endpoint, key);
        } else {
          window.ULTRON_GATEWAY = { endpoint, apiKey: key };
        }
        return `PASSERELLE IA CONFIGURÉE : ${endpoint}.`;
      }
    },
    { // wake filler — "ultron, ..." → drop the name and re-run on the rest
      test: n => /^ultron[ ,]+.+/.test(n),
      run: (n, raw) => interpret(raw.replace(/^ultron[ ,]*/i,'').trim())
    },
    {
      test: n => /\b(bonjour|salut|hey|coucou)\b/.test(n) && n.split(' ').length <= 3,
      run: () => "Bonjour. Je suis à votre écoute — dites-moi quoi ouvrir, fermer ou analyser."
    },
    {
      test: n => /\b(aide|help|que peux tu faire|quelles sont tes commandes)\b/.test(n),
      run: () => "Je peux : ouvrir/fermer une application, revenir à l'accueil, afficher les applications " +
                 "ouvertes ou les notifications, activer la vue partagée, donner un briefing complet de la situation, " +
                 "analyser les marchés, les renseignements ou les menaces actuelles, chercher une information, " +
                 "ou redémarrer ULTRON OS. Vous pouvez aussi enchaîner : « et ensuite ? », « ferme-le »."
    },
    // ---- contextual follow-ups (use short-term memory) ----
    {
      test: n => /\b(ferme|fermer|quitte|quitter)[ -]?(le|la|ca|ça)\b/.test(n),
      run: () => {
        if(!context.lastApp) return "Je ne sais pas à quelle application vous faites référence.";
        const closed = ULTRON.App.closeApp(context.lastApp);
        return closed ? `FERMETURE DE ${closed.label}.` : "Cette application n'est plus ouverte.";
      }
    },
    {
      test: n => /\b(plus de details|plus de détails|dis en plus|dis m en plus|developpe|développe|continue|et ensuite|et apres)\b/.test(n),
      run: () => {
        if(context.lastTopic === 'markets') return marketsAnalysis(true);
        if(context.lastTopic === 'intel') return intelAnalysis(true);
        if(context.lastTopic === 'threats') return threatsAnalysis(true);
        return "Je n'ai pas de sujet en cours à développer. Demandez-moi par exemple « analyse les marchés ».";
      }
    },
    {
      test: n => /\b(accueil|dashboard|maison|home)\b/.test(n) && /\b(va|aller|reviens|retourne|ouvre|montre|affiche)\b/.test(n),
      run: () => { ULTRON.App.navigate('dashboard'); context.lastApp = null; return "RETOUR À L'ACCUEIL."; }
    },
    {
      test: n => /\b(applications? ouvertes?|multitache|selecteur d application|apps? ouvertes?|recents?)\b/.test(n),
      run: () => {
        ULTRON.App.openSwitcher();
        const apps = ULTRON.App.getOpenApps();
        return apps.length
          ? `${apps.length} application(s) ouverte(s) : ${apps.map(a=>a.label).join(', ')}.`
          : "Aucune application ouverte pour le moment.";
      }
    },
    {
      test: n => /\b(notifications?|alertes?)\b/.test(n),
      run: () => { ULTRON.App.openNotifCenter(); return "Voici le centre de notifications."; }
    },
    // ---- synthesized analysis (real data, multi-source) ----
    {
      test: n => /\b(briefing|rapport complet|fait le point|fais le point|analyse la situation|resume la situation|etat des lieux|situation generale|point de situation)\b/.test(n),
      run: () => briefing()
    },
    {
      test: n => /\b(comment vont les marches|analyse les marches|resume les marches|situation des marches|marches financiers|etat des marches)\b/.test(n),
      run: () => marketsAnalysis(false)
    },
    {
      test: n => /\b(quoi de neuf|des nouvelles|dernieres informations|resume l actualite|actualites recentes|derniers renseignements)\b/.test(n),
      run: () => intelAnalysis(false)
    },
    {
      test: n => /\b(quels sont les risques|menaces actuelles|situation securitaire|niveau de menace|analyse les menaces|zones a risque)\b/.test(n),
      run: () => threatsAnalysis(false)
    },
    {
      test: n => /\b(ferme|fermer|quitte|quitter)\b.*\b(vue partagee|partage|split)\b/.test(n) || /\b(desactive|arrete)\b.*\bpartag/.test(n),
      run: () => {
        if(ULTRON.App.isSplitOpen()) ULTRON.App.toggleSplit();
        return "VUE PARTAGÉE DÉSACTIVÉE.";
      }
    },
    {
      test: n => /\b(divise|diviser|partage|partager)\b.*\b(ecran|vue)\b|vue partagee|split screen/.test(n),
      run: (n, raw) => {
        const remainder = stripTrigger(raw, [/divise[rz]?/gi,/partage[rz]?/gi,/l.?ecran/gi,/vue partagee/gi,/split screen/gi,/avec/gi]);
        const appId = resolveAppQuery(remainder);
        const app = ULTRON.App.findApp(appId);
        if(!ULTRON.App.isSplitOpen()) ULTRON.App.toggleSplit();
        if(app){ ULTRON.App.setSplitApp(app.id); context.lastApp = app.id; return `VUE PARTAGÉE ACTIVÉE avec ${app.label}.`; }
        return "VUE PARTAGÉE ACTIVÉE.";
      }
    },
    {
      test: n => /\b(redemarre|redemarrage|reboot|relance le systeme)\b/.test(n),
      run: () => { setTimeout(()=>ULTRON.App.reboot(), 400); return "REDÉMARRAGE D'ULTRON OS EN COURS..."; }
    },
    {
      test: n => /\b(statut|etat du systeme|status)\b/.test(n),
      run: () => {
        const m = D.getMarketsSnapshot();
        return `SYSTÈME EN LIGNE. Cœur opérationnel. Marchés : ${m.status}. ` +
               `${ULTRON.App.getOpenApps().length} application(s) ouverte(s).`;
      }
    },
    {
      test: n => /\b(quelle heure|heure est il|quelle est l heure)\b/.test(n),
      run: () => `Il est ${new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}.`
    },
    {
      test: n => /\b(cherche|recherche|trouve)\b/.test(n),
      run: (n, raw) => {
        const q = stripTrigger(raw, [/cherche[rz]?/gi,/recherche[rz]?/gi,/trouve[rz]?/gi]);
        if(!q) return "Que dois-je chercher ?";
        const feed = D.getIntelFeed();
        const ql = normalize(q);
        const results = feed.filter(f => normalize(f.title).includes(ql) || normalize(f.region).includes(ql) || normalize(f.summary).includes(ql));
        if(!results.length) return `Aucun résultat pour « ${q} ».`;
        ULTRON.App.navigate('intel');
        context.lastApp = 'intel'; context.lastTopic = 'intel';
        return `${results.length} résultat(s) pour « ${q} » : ${results.slice(0,3).map(r=>r.title).join(' — ')}.`;
      }
    },
    {
      // "ferme X" / "quitte X" — checked before "ouvre X" so they never collide
      test: n => /\b(ferme|fermer|quitte|quitter|tue|tuer)\b/.test(n),
      run: (n, raw) => {
        const remainder = resolveAppQuery(stripTrigger(raw, [/ferme[rz]?/gi,/quitte[rz]?/gi,/tue[rz]?/gi]));
        const closed = ULTRON.App.closeApp(remainder);
        if(closed && closed.id === context.lastApp) context.lastApp = null;
        return closed ? `FERMETURE DE ${closed.label}.` : `Aucune application ouverte ne correspond à « ${remainder} ».`;
      }
    },
    {
      test: n => /\b(ouvre|ouvrir|affiche|afficher|montre|montrer|lance|lancer|va sur|va a|acceder a|aller sur)\b/.test(n),
      run: (n, raw) => {
        const remainder = resolveAppQuery(stripTrigger(raw, [
          /ouvre[rz]?/gi,/affiche[rz]?/gi,/montre[rz]?/gi,/lance[rz]?/gi,/va sur/gi,/va a/gi,/acceder a/gi,/aller sur/gi,/^moi/gi
        ]));
        if(!remainder) return "Que dois-je ouvrir ?";
        const app = ULTRON.App.openApp(remainder);
        if(app) context.lastApp = app.id;
        return app ? `OUVERTURE DE ${app.label}...` : `Je ne trouve pas d'application correspondant à « ${remainder} ». Dites « aide » pour la liste.`;
      }
    },
  ];

  // ---------------- synthesized analysis builders (real app data) ----------------
  function marketsAnalysis(detailed){
    context.lastTopic = 'markets';
    const m = D.getMarketsSnapshot();
    const all = [...m.indices, ...m.currencies, ...m.commodities];
    const sorted = all.slice().sort((a,b)=>Math.abs(b.change)-Math.abs(a.change));
    const top = sorted.slice(0, detailed ? 6 : 3);
    const moversText = top.map(x=>`${x.name} ${x.up?'en hausse':'en baisse'} de ${Math.abs(x.change).toFixed(2)}%`).join(', ');
    let out = `Analyse des marchés : activité globale classée « ${m.status} », ${m.upCount} instruments en hausse contre ${m.downCount} en baisse. `;
    out += `Mouvements les plus marqués : ${moversText}.`;
    if(m.status === 'HIGH ACTIVITY') out += ' Je recommande une vigilance accrue sur les prochaines heures.';
    return out;
  }

  function intelAnalysis(detailed){
    context.lastTopic = 'intel';
    const feed = D.getIntelFeed();
    const top = feed.slice(0, detailed ? 6 : 3);
    const urgent = feed.filter(f=>f.priority === 'HIGH PRIORITY').length;
    let out = `${feed.length} rapports suivis, dont ${urgent} classés haute priorité. `;
    out += top.map(f=>`[${f.priority}] ${f.title} (${f.region})`).join(' — ');
    return out;
  }

  function threatsAnalysis(detailed){
    context.lastTopic = 'threats';
    const zones = D.getConflictZones();
    const active = zones.filter(z=>z.status === 'ACTIVE MONITORING');
    const defense = D.getDefenseFeed()[0];
    let out = `${active.length} zone(s) sous surveillance active sur ${zones.length} suivies au total : `;
    out += active.slice(0, detailed ? 6 : 3).map(z=>z.region).join(', ') + '. ';
    if(defense) out += `Dernier élément défense : « ${defense.title} ».`;
    return out;
  }

  function briefing(){
    const m = D.getMarketsSnapshot();
    const feed = D.getIntelFeed();
    const zones = D.getConflictZones();
    const active = zones.filter(z=>z.status === 'ACTIVE MONITORING').length;
    const urgent = feed.filter(f=>f.priority === 'HIGH PRIORITY').length;
    const apps = ULTRON.App.getOpenApps();
    context.lastTopic = 'markets';
    return [
      `Briefing complet, ${new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}.`,
      `Marchés : activité « ${m.status} », ${m.upCount} hausses / ${m.downCount} baisses.`,
      `Renseignement : ${feed.length} rapports suivis, ${urgent} en haute priorité.`,
      `Surveillance géopolitique : ${active} zone(s) en surveillance active.`,
      `Système : ${apps.length} application(s) ouverte(s), cœur opérationnel.`,
      urgent > 0 ? "Je recommande de consulter le module INTEL en priorité." : "Aucune action immédiate requise de votre part."
    ].join(' ');
  }

  function interpret(rawText){
    const text = (rawText || '').trim();
    if(!text) return "Je n'ai rien entendu.";
    const n = normalize(text);
    for(const rule of RULES){
      if(rule.test(n)) return rule.run(n, text);
    }
    // No local command matched — this is a real question/conversation,
    // not a UI command, so defer to the AI gateway instead of a canned
    // "unrecognized" reply. null is the signal handle()/handleAsync() use
    // to switch into streaming mode.
    return null;
  }

  function appendToChatDOM(role, text){
    const host = document.getElementById('ai-chat-log');
    if(!host) return null;
    const bubble = document.createElement('div');
    bubble.className = 'ai-msg ' + (role === 'user' ? 'ai-msg-user' : 'ai-msg-bot');
    bubble.innerHTML = `<span class="ai-msg-role mono">${role==='user'?'VOUS':'ULTRON'}</span><span class="ai-msg-text">${escapeHtml(text)}</span>`;
    host.appendChild(bubble);
    host.scrollTop = host.scrollHeight;
    return bubble;
  }

  // Streams a real AI reply into a live bubble (text grows as tokens arrive)
  // and persists the finished message to the chat log once done.
  function streamIntoChat(text, onFinal){
    const bubble = appendToChatDOM('ai', '');
    ULTRON.Stream.converse(text, {
      onUpdate(partial){
        if(!bubble) return;
        const span = bubble.querySelector('.ai-msg-text');
        if(span) span.textContent = partial;
        const host = document.getElementById('ai-chat-log');
        if(host) host.scrollTop = host.scrollHeight;
      },
      onDone(full){
        log.push({role:'ai', text: full, ts: Date.now()});
        try { localStorage.setItem('ultron.chat.log', JSON.stringify(log.slice(-MAX_LOG))); } catch(_) {}
        if(log.length > MAX_LOG) log = log.slice(-MAX_LOG);
        if(onFinal) onFinal(full);
      },
      onError(message){
        if(bubble){ const span = bubble.querySelector('.ai-msg-text'); if(span) span.textContent = message; }
        if(window.UltronNative && window.UltronNative.speak) window.UltronNative.speak(message);
        if(onFinal) onFinal(message);
      }
    });
  }

  function escapeHtml(s){
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function handle(text, opts){
    opts = opts || {};
    if(!opts.silentUser) { log.push({role:'user', text, ts:Date.now()}); appendToChatDOM('user', text); }
    let response;
    try{ response = interpret(text); }
    catch(e){ response = "Erreur d'interprétation de la commande."; }
    if(response === null){
      // Real conversation: reply streams in live and speaks itself
      // sentence-by-sentence via ULTRON.Stream — nothing more to do here.
      streamIntoChat(text);
      return "";
    }
    log.push({role:'ai', text:response, ts:Date.now()});
    try { localStorage.setItem('ultron.chat.log', JSON.stringify(log.slice(-MAX_LOG))); } catch (_) {}
    appendToChatDOM('ai', response);
    if (window.UltronNative && window.UltronNative.speak) window.UltronNative.speak(response);
    if(log.length > MAX_LOG) log = log.slice(-MAX_LOG);
    return response;
  }

  // Same as handle(), but computes the response first and gives the caller a
  // moment to show a "thinking" state before revealing it — used by the rich
  // chat surfaces (AI Core, Ask palette) to feel like real computation rather
  // than an instant canned reply. Voice and terminal keep using handle() as-is.
  function handleAsync(text, callbacks){
    callbacks = callbacks || {};
    log.push({role:'user', text, ts:Date.now()});
    appendToChatDOM('user', text);
    if(callbacks.onThinking) callbacks.onThinking();
    let response;
    try{ response = interpret(text); }
    catch(e){ response = "Erreur d'interprétation de la commande."; }
    if(response === null){
      // Real conversation: stream the reply live into its own bubble,
      // firing onStreamUpdate (if provided) as tokens arrive and onDone
      // once the model has finished — no fixed "thinking" delay needed
      // since the bubble is already visibly filling in.
      const bubble = appendToChatDOM('ai', '');
      ULTRON.Stream.converse(text, {
        onUpdate(partial){
          if(bubble){ const span = bubble.querySelector('.ai-msg-text'); if(span) span.textContent = partial; }
          if(callbacks.onStreamUpdate) callbacks.onStreamUpdate(partial);
        },
        onDone(full){
          log.push({role:'ai', text: full, ts: Date.now()});
          try { localStorage.setItem('ultron.chat.log', JSON.stringify(log.slice(-MAX_LOG))); } catch(_) {}
          if(log.length > MAX_LOG) log = log.slice(-MAX_LOG);
          if(callbacks.onDone) callbacks.onDone(full);
        },
        onError(message){
          if(bubble){ const span = bubble.querySelector('.ai-msg-text'); if(span) span.textContent = message; }
          if(callbacks.onDone) callbacks.onDone(message);
        }
      });
      return;
    }
    const delay = Math.min(1400, 320 + response.length * 4);
    setTimeout(()=>{
      log.push({role:'ai', text:response, ts:Date.now()});
      appendToChatDOM('ai', response);
      if(log.length > MAX_LOG) log = log.slice(-MAX_LOG);
      if(callbacks.onDone) callbacks.onDone(response);
    }, delay);
  }

  function getLog(){ return log.slice(); }
  function getContext(){ return {...context}; }

  return { handle, handleAsync, interpret, getLog, getContext };
})();
