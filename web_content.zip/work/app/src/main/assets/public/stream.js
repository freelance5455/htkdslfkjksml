// ============================================================
// ULTRON OS — STREAMING CONVERSATION
// Talks to the gateway's /chat/stream endpoint and reveals the reply
// token-by-token, speaking each finished sentence as soon as it's ready.
// This is what makes ULTRON *converse* like JARVIS instead of answering
// in one flat block after a silent pause.
// ============================================================
ULTRON.Stream = (function(){
  let counter = 0;
  const pending = {}; // requestId -> {onChunk, onDone, onError}

  // Splits on sentence-ending punctuation so we can start speaking a
  // finished sentence immediately, while the rest keeps streaming in.
  function splitSentences(buffer){
    const parts = buffer.split(/([.!?…]+\s+)/);
    if(parts.length <= 1) return { complete: [], rest: buffer };
    let rest = parts.pop();
    const complete = [];
    for(let i = 0; i < parts.length; i += 2){
      const sentence = (parts[i] || '') + (parts[i+1] || '');
      if(sentence.trim()) complete.push(sentence.trim());
    }
    return { complete, rest };
  }

  function speak(text){
    if(!text || !text.trim()) return;
    if(window.UltronNative && window.UltronNative.speakAppend){
      window.UltronNative.speakAppend(text);
    } else if('speechSynthesis' in window){
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'fr-FR';
      speechSynthesis.speak(u);
    }
  }

  /**
   * Starts (or continues) a conversation turn.
   * opts: { onUpdate(partialText), onDone(fullText), onError(message), speakAloud }
   * Returns the request id.
   */
  function converse(userText, opts){
    opts = opts || {};
    const speakAloud = opts.speakAloud !== false;
    const id = 'req' + (++counter) + '_' + Date.now();

    const history = (ULTRON.Assistant && ULTRON.Assistant.getLog ? ULTRON.Assistant.getLog() : [])
      .slice(-10)
      .map(m => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }));

    let acc = '';
    let speechBuffer = '';

    pending[id] = {
      onChunk(delta){
        acc += delta;
        if(opts.onUpdate) opts.onUpdate(acc);
        if(speakAloud){
          speechBuffer += delta;
          const { complete, rest } = splitSentences(speechBuffer);
          complete.forEach(speak);
          speechBuffer = rest;
        }
      },
      onDone(){
        if(speakAloud && speechBuffer.trim()) speak(speechBuffer.trim());
        if(opts.onDone) opts.onDone(acc);
        delete pending[id];
      },
      onError(message){
        if(opts.onError) opts.onError(message);
        delete pending[id];
      }
    };

    if(window.UltronNative && window.UltronNative.chatStream){
      // Native path: the Android layer holds the gateway key and streams
      // chunks back in via window.ULTRONStreamChunk/Done/Error below.
      window.UltronNative.chatStream(id, userText, JSON.stringify(history));
    } else if(window.ULTRON_GATEWAY && window.ULTRON_GATEWAY.endpoint){
      fetchStream(id, userText, history);
    } else {
      pending[id].onError("Passerelle IA non connectée. Dites « configure ia <url> <clé> ».");
    }
    return id;
  }

  // Browser fallback (no native bridge): calls the gateway directly with fetch.
  async function fetchStream(id, userText, history){
    try{
      const res = await fetch(window.ULTRON_GATEWAY.endpoint.replace(/\/+$/,'') + '/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': window.ULTRON_GATEWAY.apiKey || '' },
        body: JSON.stringify({ message: userText, memory: history })
      });
      if(!res.ok || !res.body) throw new Error('stream-unavailable');
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = '';
      while(true){
        const { done, value } = await reader.read();
        if(done) break;
        buf += decoder.decode(value, { stream: true });
        const events = buf.split('\n\n');
        buf = events.pop();
        for(const evt of events){
          const line = evt.split('\n').find(l => l.startsWith('data:'));
          if(!line) continue;
          const payload = line.slice(5).trim();
          if(payload === '[DONE]'){ pending[id] && pending[id].onDone(); return; }
          try{
            const obj = JSON.parse(payload);
            if(obj.delta) pending[id] && pending[id].onChunk(obj.delta);
            else if(obj.error) pending[id] && pending[id].onError(obj.error);
          }catch(_){ /* ignore partial/malformed frames */ }
        }
      }
      pending[id] && pending[id].onDone();
    }catch(e){
      pending[id] && pending[id].onError("Erreur de connexion à la passerelle IA.");
    }
  }

  // Bridge targets called by MainActivity.postToJs() on Android.
  window.ULTRONStreamChunk = function(id, delta){ pending[id] && pending[id].onChunk(delta); };
  window.ULTRONStreamDone  = function(id){ pending[id] && pending[id].onDone(); };
  window.ULTRONStreamError = function(id, message){ pending[id] && pending[id].onError(message); };

  return { converse };
})();
