# ULTRON OS — JARVIS FULL ARCHITECTURE
Cette version ajoute une base Android compilable pour :
- IA conversationnelle : prévoir un endpoint HTTPS sécurisé côté serveur (clé jamais embarquée).
- mémoire sémantique persistante : `MemoryStore` SQLite ; brancher ensuite des embeddings côté serveur.
- planification : `TaskPlanner` produit des étapes et impose une confirmation avant action sensible.
- services externes : `SecureConfig` pour endpoint ; utiliser HTTPS, OAuth2/PKCE et un relais backend.
- vision : `VisionCaptureActivity`, point d’intégration caméra/moteur de vision.
- gestion téléphone : conserver les Intents Android et ajouter uniquement les permissions nécessaires.
- écoute arrière-plan : `VoiceForegroundService`, soumis aux restrictions Android et au consentement explicite.
- sécurité : `PermissionGate` pour les actions à risque.

Limites : Android interdit une écoute silencieuse illimitée dans de nombreux cas. Une activation “mot-clé” réellement fiable nécessite un moteur wake-word autorisé et une notification de service au premier plan. Les appels, messages, achats, suppression et réglages sensibles doivent toujours demander confirmation.
