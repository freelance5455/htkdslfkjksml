# ULTRON OS — Ultimate IA

Cette version ajoute une architecture réellement exploitable :

1. **Modèle d'IA** : passerelle serveur compatible API OpenAI (`/chat`).
2. **Vision** : endpoint `/vision` acceptant une image et la transmettant à un modèle multimodal.
3. **Serveur sécurisé** : clé fournisseur conservée côté serveur, jamais dans l'APK.
4. **Mot d'activation** : frontière `WakeWordService`; l'écoute doit rester dans les règles Android, avec service au premier plan et notification.
5. **Outils Android** : registre initial d'outils et rappel explicite que les actions sensibles nécessitent une confirmation.
6. **Extensible** : les outils peuvent être reliés à un planificateur, une mémoire SQLite et une interface de validation.

## Limites importantes
Le projet ne peut pas embarquer une clé IA ou contourner les restrictions Android. Il faut configurer le serveur, choisir un fournisseur IA, installer un moteur wake-word sous licence et connecter les boutons de confirmation dans l'interface.
