# Chùa Phật Tử LIVE – Android (v0.1)

Đã có: màn hình game (assets/index.html), giọng chúc phúc bằng Android TextToSpeech, chế độ DEMO.
Chưa có: module kết nối TikTok LIVE thật (xem ghi chú trong chat).

## Build APK
**Cách 1 – GitHub (không cần cài gì):** tạo repo, đẩy toàn bộ thư mục này lên (giữ nguyên `.github`),
vào tab Actions → "Build APK" → Run workflow → tải artifact `ChuaPhatTuLive-apk` → giải nén ra `app-debug.apk`.

**Cách 2 – Android Studio:** Open thư mục này → Build → Build APK(s) → `app/build/outputs/apk/debug/app-debug.apk`.

## Cài đặt
Chép APK vào điện thoại → mở → cho phép "cài từ nguồn không rõ" → cài.
Giọng tiếng Việt: Cài đặt → Chuyển văn bản thành giọng nói → Google → tải tiếng Việt.

## Gắn module LIVE sau này
Gọi `MainActivity.emit("""{"type":"gift","user":"abc","nick":"Abc","diamonds":5,"count":1}""")`
(type: join | chat | gift) và báo trạng thái bằng `PhatTu.status('connected' | 'disconnected' | 'error:...')`.
