# NELAYAN GPS GO — Android prototype v0.3

Proyek Android Studio (Java) untuk prototipe navigasi nelayan offline-first.

## Spesifikasi yang dipilih
- Alarm jarak dapat diatur sendiri setiap perjalanan, dalam mil laut (NM), 1–200 NM.
- Titik awal perjalanan disimpan sebagai titik pulang untuk perjalanan aktif.
- Pemantauan perjalanan memakai Android foreground location service agar tetap berjalan saat layar aplikasi tidak di depan (bergantung izin, pengaturan baterai, GPS, dan perilaku pabrikan HP).
- Peringatan batas jarak, GPS tidak aktif/lemah/hilang lebih dari 30 detik, dan baterai HP 15% atau kurang.
- Posisi rumpon, koordinat darurat, dan hasil tangkapan disimpan lokal di SQLite.
- Arah pulang saat ini hanya bearing langsung dan jarak garis lurus.
- Peta dasar online dengan marker posisi GPS, zoom/geser, serta marker titik lokal tersimpan.
- Titik peta disimpan di SQLite pada HP.

## Yang belum tersedia / belum boleh dianggap siap navigasi laut
1. Peta yang tersedia pada v0.3 adalah peta dasar umum OpenStreetMap yang memerlukan internet, bukan peta laut ENC. Peta laut offline ENC resmi dan mesin perutean aman belum disertakan. Data ENC harus diperoleh dengan lisensi dan pembaruan resmi PUSHIDROSAL/IHDC.
2. Tidak ada kalkulasi jalur yang menghindari karang, kedangkalan, alur, zona terlarang, atau lalu lintas kapal.
3. Prakiraan cuaca/gelombang belum diintegrasikan; modul ini belum mengunduh atau menyimpan prakiraan.
4. Belum ada sensor heading kapal/kompas terkalibrasi. Course-over-ground GPS hanya bermakna saat kapal bergerak.
5. Belum ada pengiriman SOS ke darat. Notifikasi lokal HP bukan radio maritim atau komunikasi satelit.
6. Alarm dan layanan latar belakang harus diuji di HP sasaran; Android/OEM dapat membatasi proses, dan notifikasi perlu diizinkan.

## Peta v0.3
- Tekan **BUKA PETA & POSISI KAPAL** dari halaman utama.
- Peta dasar memerlukan koneksi internet; GPS dan titik tersimpan memakai data lokasi HP.
- Titik rumpon, titik awal perjalanan, dan titik peta tersimpan ditampilkan sebagai marker.
- Peta dasar umum tidak menampilkan data bahaya laut yang dapat diandalkan dan bukan untuk memilih jalur aman.

## Build
- Buka folder `NelayanGPS_Android` di Android Studio.
- Gunakan JDK 17 dan Android SDK platform 35.
- Sinkronkan Gradle lalu Build > Build APK(s).
- APK belum dibangun atau diuji pada perangkat dalam paket ini.

## Penggunaan awal
1. Instal aplikasi dan izinkan akses lokasi presisi serta notifikasi.
2. Aktifkan GPS dan tunggu akurasi membaik di area terbuka.
3. Saat berada di titik keberangkatan, tekan **MULAI MELAUT / ATUR ALARM PERJALANAN**.
4. Masukkan jarak alarm dalam NM. Aplikasi merekam posisi GPS saat itu sebagai titik pulang.
5. Tekan **SELESAI PERJALANAN** setelah perjalanan berakhir.

## Catatan keselamatan
Aplikasi ini prototipe bantu, bukan perangkat navigasi keselamatan tersertifikasi. Jangan jadikan HP sebagai satu-satunya alat navigasi. Gunakan chartplotter, ENC resmi yang mutakhir, kompas/alat heading kapal, VHF/radio, alat keselamatan, serta informasi cuaca maritim resmi. Bearing langsung tidak sama dengan rute aman. Alarm jarak bukan batas legal atau batas aman berlayar.


## Profil pengujian Realme 5 Pro Android 11
- Minimum Android 8.0 (API 26); target aplikasi disetel ke Android 11 (API 30).
- APK debug dibangun dengan Java 17, Gradle 8.7, Android Gradle Plugin 8.6.1, dan compile SDK 35.
- Pada Android 11, izinkan Lokasi saat aplikasi digunakan, aktifkan Lokasi/GPS, dan izinkan notifikasi jika pengaturan perangkat menawarkannya.
- Saat perjalanan dimulai dari layar aplikasi, layanan pemantauan foreground menampilkan notifikasi permanen. Jangan paksa berhenti aplikasi dan jangan aktifkan penghemat baterai ekstrem ketika menguji.
- Peta dasar memerlukan internet. Titik tersimpan di SQLite lokal, tetapi tile peta tidak tersedia offline.
- Ini bukan peta laut/ENC dan tidak boleh digunakan sebagai satu-satunya alat navigasi.

## Checklist uji pada perangkat fisik
1. Instal APK debug dan buka aplikasi.
2. Izinkan lokasi presisi; uji GPS di ruang terbuka sampai koordinat dan akurasi muncul.
3. Buka peta saat internet aktif; pastikan tile peta dan penanda kapal muncul.
4. Simpan satu titik uji; tutup dan buka kembali peta untuk memastikan titik tetap tersimpan.
5. Mulai perjalanan dengan batas kecil hanya untuk uji di darat/area aman; pastikan notifikasi layanan berjalan.
6. Uji alarm jarak dengan simulasi lokasi pengembang bila tersedia; jangan sengaja berlayar menjauh untuk memicu alarm.
7. Matikan GPS sementara untuk memeriksa peringatan kehilangan GPS, lalu aktifkan kembali.
8. Akhiri perjalanan dan pastikan notifikasi layanan berhenti.

Status pengujian: source telah diperiksa dan diperbaiki untuk profil Android 11. APK belum dapat dinyatakan lulus kompilasi atau uji perangkat sampai workflow build berhasil dan APK diuji di Realme 5 Pro sebenarnya.


## Catatan khusus pengujian Realme 5 Pro
Perangkat uji yang ditetapkan: Realme 5 Pro dengan Android 11. Nama menu dapat berbeda menurut versi Realme UI. Untuk menguji pemantauan perjalanan saat layar mati:
1. Buka Pengaturan > Aplikasi > Manajemen aplikasi > NELAYAN GPS GO > Penggunaan baterai (atau menu sejenis).
2. Izinkan aktivitas latar belakang / penggunaan baterai tanpa pembatasan jika pilihan tersebut tersedia.
3. Jangan aktifkan penghemat daya selama pengujian.
4. Izinkan akses lokasi saat aplikasi digunakan dan aktifkan GPS/Akurasi lokasi.
5. Mulai tes di tempat terbuka, pastikan notifikasi layanan perjalanan terlihat, lalu kunci layar selama 5–10 menit. Bandingkan jejak/lokasi dan alarm setelah membuka aplikasi kembali.
6. Ulangi tes dengan internet dimatikan untuk memastikan batas kemampuan: peta dasar pada versi ini memerlukan internet; titik tersimpan lokal dapat tetap tersedia.

Peringatan: pengaturan ini membantu pengujian latar belakang, tetapi tidak membuktikan alarm selalu berjalan. Uji nyata diperlukan. Jangan mengandalkan aplikasi ini sebagai satu-satunya alat keselamatan atau pengganti peta laut resmi, kompas, radio, dan alat navigasi kapal.
