package id.nelayangps.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MapActivity extends Activity implements LocationListener {
    private WebView web;
    private TextView gpsInfo;
    private LocationManager lm;
    private Location current;
    private boolean pageReady = false;
    private MapDb db;
    private static final int REQ_MAP_LOCATION = 91;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new MapDb(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xffeef5f8);
        TextView title = new TextView(this);
        title.setText("PETA NELAYAN GPS GO  •  PETA DASAR ONLINE");
        title.setTextSize(16); title.setTextColor(0xff073b5c); title.setPadding(12,12,12,8);
        root.addView(title);
        gpsInfo = new TextView(this);
        gpsInfo.setText("Menunggu GPS…"); gpsInfo.setTextSize(13); gpsInfo.setPadding(12,4,12,8);
        root.addView(gpsInfo);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() { @Override public void onPageFinished(WebView v, String url) { pageReady=true; loadSavedPoints(); if(current!=null) pushLocation(current); } });
        web.addJavascriptInterface(this, "NelayanApp");
        root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar = new LinearLayout(this);
        Button locate = new Button(this); locate.setText("KE POSISI SAYA"); locate.setOnClickListener(v -> { if(current!=null) pushLocation(current); else Toast.makeText(this,"GPS belum mendapatkan posisi",Toast.LENGTH_SHORT).show(); });
        Button add = new Button(this); add.setText("SIMPAN TITIK"); add.setOnClickListener(v -> saveCurrentPoint());
        Button close = new Button(this); close.setText("KEMBALI"); close.setOnClickListener(v -> finish());
        bar.addView(locate,new LinearLayout.LayoutParams(0,-2,1)); bar.addView(add,new LinearLayout.LayoutParams(0,-2,1)); bar.addView(close,new LinearLayout.LayoutParams(0,-2,1)); root.addView(bar);
        setContentView(root);
        web.loadUrl("file:///android_asset/map.html");
        lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        startGps();
    }
    private void startGps() {
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            gpsInfo.setText("Meminta izin lokasi presisi untuk menampilkan posisi kapal…");
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_MAP_LOCATION);
            return;
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1500,1,this);
            Location last=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); if(last!=null) onLocationChanged(last);
        } catch(Exception e) { gpsInfo.setText("GPS: "+e.getMessage()); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MAP_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startGps();
            else gpsInfo.setText("Izin lokasi ditolak. Posisi kapal tidak dapat ditampilkan.");
        }
    }
    @Override public void onLocationChanged(Location l) {
        current=l;
        gpsInfo.setText(String.format(Locale.US,"GPS %.6f, %.6f  •  Akurasi ±%d m",l.getLatitude(),l.getLongitude(),Math.round(l.getAccuracy())));
        if(pageReady) pushLocation(l);
    }
    private void pushLocation(Location l) {
        final String js=String.format(Locale.US,"updateBoat(%.8f,%.8f,%d)",l.getLatitude(),l.getLongitude(),Math.round(l.getAccuracy()));
        runOnUiThread(() -> web.evaluateJavascript(js,null));
    }
    private void loadSavedPoints() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,lat,lon,type FROM points ORDER BY id DESC",null);
        while(c.moveToNext()) {
            String n=c.getString(0).replace("'"," ").replace("\\"," ");
            String type=c.getString(3).replace("'"," ");
            String js=String.format(Locale.US,"addSavedPoint(%.8f,%.8f,'%s','%s')",c.getDouble(1),c.getDouble(2),n,type);
            web.evaluateJavascript(js,null);
        }
        c.close();
    }
    private void saveCurrentPoint() {
        if(current==null) { Toast.makeText(this,"Tunggu GPS mendapatkan posisi",Toast.LENGTH_SHORT).show(); return; }
        String name="Titik peta "+new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date());
        db.getWritableDatabase().execSQL("INSERT INTO points(name,lat,lon,type,created) VALUES(?,?,?,?,?)",new Object[]{name,current.getLatitude(),current.getLongitude(),"Titik peta",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date())});
        if(pageReady) web.evaluateJavascript(String.format(Locale.US,"addSavedPoint(%.8f,%.8f,'%s','Titik peta')",current.getLatitude(),current.getLongitude(),name),null);
        Toast.makeText(this,"Titik tersimpan di HP",Toast.LENGTH_LONG).show();
    }
    @JavascriptInterface public void reportMapStatus(String s) { runOnUiThread(() -> Toast.makeText(this,s,Toast.LENGTH_SHORT).show()); }
    @Override public void onProviderDisabled(String p) { gpsInfo.setText("GPS dimatikan"); }
    @Override public void onProviderEnabled(String p) { gpsInfo.setText("GPS aktif, mencari posisi…"); }
    @Override public void onStatusChanged(String p,int s,Bundle b) {}
    @Override protected void onDestroy() { super.onDestroy(); try { if(lm!=null) lm.removeUpdates(this); } catch(Exception ignored) {} if(web!=null) web.destroy(); }

    static class MapDb extends SQLiteOpenHelper {
        MapDb(Context c) { super(c,"nelayan_gps.db",null,1); }
        public void onCreate(SQLiteDatabase d) { d.execSQL("CREATE TABLE IF NOT EXISTS points(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,lat REAL,lon REAL,type TEXT,created TEXT)"); }
        public void onUpgrade(SQLiteDatabase d,int o,int n) {}
    }
}
