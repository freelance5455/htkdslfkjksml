package id.nelayangps.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.ServiceInfo;
import android.os.BatteryManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.VibrationEffect;
import android.os.Vibrator;
import androidx.core.app.NotificationCompat;
import java.util.Locale;

/** Foreground trip monitor. Alerts are advisory and depend on phone GPS/battery. */
public class TripMonitorService extends Service implements LocationListener {
    private static final String CHANNEL = "nelayan_trip_monitor";
    private static final int NOTIFICATION_ID = 4201;
    private LocationManager manager;
    private SharedPreferences prefs;
    private double homeLat, homeLon, alarmNm;
    private boolean distanceAlertSent = false;
    private long lastGpsAt = 0;
    private long monitorStartedAt = 0;
    private boolean gpsLossAlertSent = false;
    private boolean batteryAlertSent = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable gpsWatchdog = new Runnable() {
        @Override public void run() {
            long reference = lastGpsAt > 0 ? lastGpsAt : monitorStartedAt;
            if (reference > 0 && System.currentTimeMillis() - reference > 30000 && !gpsLossAlertSent) {
                gpsLossAlertSent = true;
                postAlert("SINYAL GPS HILANG", "Tidak ada pembaruan posisi lebih dari 30 detik. Periksa antena/pandangan langit dan jangan mengandalkan posisi terakhir sebagai posisi sekarang.");
            }
            handler.postDelayed(this, 15000);
        }
    };
    private BroadcastReceiver batteryReceiver;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("nelayan_trip", MODE_PRIVATE);
        monitorStartedAt = System.currentTimeMillis();
        homeLat = Double.longBitsToDouble(prefs.getLong("home_lat", 0));
        homeLon = Double.longBitsToDouble(prefs.getLong("home_lon", 0));
        alarmNm = prefs.getFloat("alarm_nm", 50f);
        if (!Double.isFinite(homeLat) || !Double.isFinite(homeLon) || Math.abs(homeLat) > 90 || Math.abs(homeLon) > 180) {
            homeLat = 0; homeLon = 0;
        }
        if (!Double.isFinite(alarmNm) || alarmNm < 1 || alarmNm > 200) alarmNm = 50f;
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        createChannel();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification("Pemantauan perjalanan aktif"), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        else startForeground(NOTIFICATION_ID, notification("Pemantauan perjalanan aktif"));
        handler.postDelayed(gpsWatchdog, 15000);
        registerBatteryMonitor();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 5, this, Looper.getMainLooper());
                Location last = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last != null) onLocationChanged(last);
            } catch (Exception e) { postAlert("GPS tidak tersedia", "Periksa izin dan aktifkan lokasi HP."); }
        } else postAlert("Izin GPS tidak tersedia", "Pemantauan posisi tidak dapat berjalan.");
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Alarm keselamatan NELAYAN GPS", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Peringatan posisi, batas jarak, dan kondisi baterai");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification(String msg) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        return new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("NELAYAN GPS • Perjalanan aktif").setContentText(msg)
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build();
    }
    private void updateNotification(String msg) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, notification(msg));
    }
    private void postAlert(String title, String msg) {
        Notification n = new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title).setContentText(msg).setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis() & 0x7fffffff), n);
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 90);
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1200);
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(900, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(900);
            }
        } catch (Exception ignored) { }
    }
    private void registerBatteryMonitor() {
        batteryReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) {
                    int pct = Math.round(level * 100f / scale);
                    if (pct <= 15 && !batteryAlertSent) { batteryAlertSent = true; postAlert("BATERAI HP RENDAH", "Sisa baterai " + pct + "%. Segera amankan daya; GPS dan alarm dapat berhenti jika HP mati."); }
                    if (pct > 20) batteryAlertSent = false;
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }
    @Override public void onLocationChanged(Location loc) {
        lastGpsAt = System.currentTimeMillis();
        gpsLossAlertSent = false;
        if (!loc.hasAccuracy() || loc.getAccuracy() > 100) {
            updateNotification("GPS lemah • akurasi " + (loc.hasAccuracy() ? Math.round(loc.getAccuracy()) + " m" : "tidak diketahui"));
        } else {
            float[] result = new float[1];
            Location.distanceBetween(homeLat, homeLon, loc.getLatitude(), loc.getLongitude(), result);
            double nm = result[0] / 1852.0;
            updateNotification(String.format(Locale.US, "GPS aktif • %.1f NM dari titik awal • alarm %.1f NM", nm, alarmNm));
            if (nm >= alarmNm && !distanceAlertSent) {
                distanceAlertSent = true;
                postAlert("ALARM BATAS JARAK", String.format(Locale.US, "Posisi %.1f NM dari titik awal. Batas perjalanan Anda %.1f NM. Periksa keadaan dan rencana pelayaran.", nm, alarmNm));
            }
        }
    }
    @Override public void onProviderDisabled(String provider) { postAlert("GPS DIMATIKAN", "Aktifkan kembali lokasi/GPS HP. Posisi perahu tidak dapat dipantau."); }
    @Override public void onProviderEnabled(String provider) { postAlert("GPS AKTIF", "Penyedia lokasi GPS aktif kembali."); }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        handler.removeCallbacks(gpsWatchdog);
        try { if (manager != null) manager.removeUpdates(this); } catch (Exception ignored) { }
        try { if (batteryReceiver != null) unregisterReceiver(batteryReceiver); } catch (Exception ignored) { }
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(NOTIFICATION_ID);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
