package id.nelayangps.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {
    private static final int REQ_LOCATION = 77;
    private LocationManager locationManager;
    private Location currentLocation;
    private Location departureLocation;
    private Db db;
    private TextView gpsText, headingText, distanceText, statusText, homeText;
    private EditText boundaryInput;
    private double boundaryNm = 50.0;
    private SharedPreferences prefs;
    private boolean tripActive = false;
    private float lastBearing = 0f;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new Db(this);
        prefs = getSharedPreferences("nelayan_trip", MODE_PRIVATE);
        boundaryNm = prefs.getFloat("alarm_nm", 50.0f);
        if (prefs.getBoolean("trip_active", false) && prefs.contains("home_lat")) {
            departureLocation = new Location("saved");
            departureLocation.setLatitude(Double.longBitsToDouble(prefs.getLong("home_lat", 0)));
            departureLocation.setLongitude(Double.longBitsToDouble(prefs.getLong("home_lon", 0)));
            tripActive = true;
        }
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        buildUi();
        requestGpsPermission();
        requestNotificationPermission();
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(0xff102a43);
        t.setPadding(8, 8, 8, 8);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 18);
        root.setBackgroundColor(0xfff2f6f8);
        scroll.addView(root);
        TextView title = text("NELAYAN GPS", 26);
        title.setTextColor(0xff075985);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        root.addView(text("Navigasi sederhana untuk melaut • Paciran, Gresik, Tuban & Madura", 13));
        gpsText = text("POSISI GPS: menunggu izin/lokasi…", 18);
        gpsText.setBackgroundColor(0xffffffff); root.addView(gpsText);
        headingText = text("ARAH GERAK: belum tersedia", 16); root.addView(headingText);
        distanceText = text("JARAK: —", 16); root.addView(distanceText);
        homeText = text("TITIK PULANG: belum disimpan", 16); root.addView(homeText);
        statusText = text("Status: GPS belum aktif", 14); root.addView(statusText);

        root.addView(buttonAction("BUKA PETA & POSISI KAPAL", v -> startActivity(new Intent(this, MapActivity.class))));
        root.addView(buttonAction("MULAI MELAUT / ATUR ALARM PERJALANAN", v -> startTrip()));
        root.addView(buttonAction("SELESAI PERJALANAN", v -> stopTrip()));
        root.addView(buttonAction("SIMPAN LOKASI RUMPON", v -> saveRumpon()));
        root.addView(buttonAction("ARAH PULANG", v -> showHomeDirection()));
        root.addView(buttonAction("LOKASI DARURAT TERAKHIR", v -> saveEmergency()));
        root.addView(buttonAction("CATAT HASIL TANGKAPAN", v -> catchDialog()));
        root.addView(buttonAction("DAFTAR RUMPON TERSIMPAN", v -> showRumpons()));
        root.addView(buttonAction("RIWAYAT HASIL TANGKAPAN", v -> showCatches()));

        root.addView(text("ALARM JARAK (mil laut / NM dari titik berangkat)", 14));
        boundaryInput = new EditText(this);
        boundaryInput.setSingleLine(true); boundaryInput.setInputType(8194);
        boundaryInput.setText(String.format(Locale.US, "%.0f", boundaryNm)); boundaryInput.setHint("Contoh: 50 NM");
        root.addView(boundaryInput);
        root.addView(buttonAction("SIMPAN BATAS AREA", v -> saveBoundary()));

        root.addView(text("PETA LAUT OFFLINE: belum terpasang. Navigasi peta harus memakai ENC resmi dan mutakhir dari PUSHIDROSAL/IHDC; jangan gunakan peta jalan atau citra satelit sebagai pengganti peta laut.", 14));
        root.addView(text("Cuaca & gelombang: aplikasi dapat menyimpan prakiraan yang diunduh sebelum berangkat. Data tidak diperbarui saat offline.", 14));
        root.addView(text("KESELAMATAN: alarm jarak, GPS, dan baterai adalah peringatan tambahan. Arah pulang yang tampil adalah bearing langsung dan jarak garis lurus, BUKAN rute aman. Tetap gunakan chartplotter, ENC resmi terbaru, VHF/radio, dan perlengkapan keselamatan.", 13));
        setContentView(scroll);
    }

    private Button buttonAction(String label, View.OnClickListener listener) {
        Button b = button(label);
        b.setOnClickListener(listener);
        return b;
    }

    private void requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 78);
        }
    }
    private void requestGpsPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.POST_NOTIFICATIONS}, REQ_LOCATION);
            else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        } else startGps();
    }
    @Override public void onRequestPermissionsResult(int req, String[] p, int[] g) {
        super.onRequestPermissionsResult(req,p,g);
        if (req == REQ_LOCATION) {
            if (g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startGps();
            else statusText.setText("Izin lokasi ditolak. GPS tidak dapat digunakan.");
        }
    }
    private void startGps() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 2, this, Looper.getMainLooper());
            Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last != null) onLocationChanged(last);
            statusText.setText("Status: meminta pembaruan GPS");
        } catch (Exception e) { statusText.setText("GPS gagal: " + e.getMessage()); }
    }
    @Override public void onLocationChanged(Location loc) {
        currentLocation = loc;
        String coord = String.format(Locale.US, "%.6f°, %.6f°", loc.getLatitude(), loc.getLongitude());
        gpsText.setText("POSISI PERAHU\n" + coord + "\nAkurasi: " + Math.round(loc.getAccuracy()) + " meter"
                + (loc.hasSpeed() ? "\nKecepatan: " + String.format(Locale.US, "%.1f knot", loc.getSpeed()*1.94384f) : ""));
        if (loc.hasBearing() && loc.hasSpeed() && loc.getSpeed() > 0.5f) {
            lastBearing = loc.getBearing();
            headingText.setText("ARAH GERAK GPS: " + Math.round(lastBearing) + "°");
        } else headingText.setText("ARAH GERAK: bergerak pelan / belum tersedia");
        statusText.setText("Status: GPS aktif • pembaruan " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));
        if (departureLocation != null) {
            float[] result = new float[1];
            Location.distanceBetween(departureLocation.getLatitude(), departureLocation.getLongitude(),
                    loc.getLatitude(), loc.getLongitude(), result);
            double km = result[0] / 1000.0;
            distanceText.setText(String.format(Locale.US, "JARAK DARI TITIK AWAL: %.2f km", km));
            double nm = km / 1.852;
            if (tripActive && nm >= boundaryNm) {
                statusText.setText(String.format(Locale.US, "⚠ ALARM JARAK: %.1f NM dari titik awal (batas %.1f NM)", nm, boundaryNm));
            }
        }
    }
    private void requireLocation(Runnable r) {
        if (currentLocation == null) { new AlertDialog.Builder(this).setMessage("Lokasi GPS belum tersedia. Tunggu sinyal GPS di tempat terbuka.").setPositiveButton("OK", null).show(); return; }
        r.run();
    }
    private void startTrip() {
        requireLocation(() -> {
            EditText alarm = new EditText(this);
            alarm.setInputType(8194);
            alarm.setText(String.format(Locale.US, "%.0f", boundaryNm));
            alarm.setHint("Contoh: 50 NM");
            new AlertDialog.Builder(this).setTitle("Atur alarm jarak perjalanan")
                .setMessage("Alarm dihitung dari titik keberangkatan yang akan disimpan sekarang. Satuan mil laut (NM).")
                .setView(alarm)
                .setPositiveButton("MULAI", (d,w) -> {
                    try {
                        double nm = Double.parseDouble(alarm.getText().toString().trim());
                        if (!Double.isFinite(nm) || nm < 1 || nm > 200) throw new NumberFormatException();
                        boundaryNm = nm;
                        departureLocation = new Location(currentLocation);
                        tripActive = true;
                        prefs.edit().putBoolean("trip_active", true)
                            .putFloat("alarm_nm", (float) boundaryNm)
                            .putLong("home_lat", Double.doubleToRawLongBits(departureLocation.getLatitude()))
                            .putLong("home_lon", Double.doubleToRawLongBits(departureLocation.getLongitude())).apply();
                        db.savePoint("Titik awal melaut", departureLocation.getLatitude(), departureLocation.getLongitude(), "Keberangkatan");
                        homeText.setText(String.format(Locale.US, "TITIK PULANG: %.6f, %.6f", departureLocation.getLatitude(), departureLocation.getLongitude()));
                        boundaryInput.setText(String.format(Locale.US, "%.0f", boundaryNm));
                        Intent service = new Intent(this, TripMonitorService.class);
                        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
                        statusText.setText(String.format(Locale.US, "Perjalanan aktif • alarm %.1f NM • pemantauan keselamatan berjalan", boundaryNm));
                    } catch (Exception ex) {
                        new AlertDialog.Builder(this).setMessage("Masukkan alarm antara 1 sampai 200 NM.").setPositiveButton("OK", null).show();
                    }
                }).setNegativeButton("BATAL", null).show();
        });
    }
    private void stopTrip() {
        tripActive = false;
        prefs.edit().putBoolean("trip_active", false).apply();
        stopService(new Intent(this, TripMonitorService.class));
        statusText.setText("Perjalanan diakhiri. Alarm perjalanan dimatikan.");
    }
    private void saveRumpon() {
        requireLocation(() -> {
            EditText name = new EditText(this); name.setHint("Nama rumpon / lokasi ikan");
            new AlertDialog.Builder(this).setTitle("Simpan lokasi rumpon").setView(name)
                .setPositiveButton("SIMPAN", (d,w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) n = "Rumpon " + new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(new Date());
                    db.savePoint(n, currentLocation.getLatitude(), currentLocation.getLongitude(), "Rumpon");
                    Toast.makeText(this, "Lokasi rumpon tersimpan offline", Toast.LENGTH_LONG).show();
                }).setNegativeButton("BATAL", null).show();
        });
    }
    private void showHomeDirection() {
        if (currentLocation == null || departureLocation == null) {
            new AlertDialog.Builder(this).setMessage("Mulai melaut dan simpan titik awal terlebih dahulu.").setPositiveButton("OK",null).show(); return;
        }
        float[] out = new float[2];
        Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(),
            departureLocation.getLatitude(), departureLocation.getLongitude(), out);
        String cardinal = cardinal(out[1]);
        new AlertDialog.Builder(this).setTitle("ARAH PULANG")
            .setMessage(String.format(Locale.US, "Arah dari posisi sekarang ke titik awal: %.0f° (%s)\nJarak garis lurus: %.2f km\n\nIkuti hanya sebagai petunjuk arah, bukan jalur aman. Perhatikan alur, karang, cuaca, dan lalu lintas kapal.", out[1], cardinal, out[0]/1000.0))
            .setPositiveButton("OK",null).show();
    }
    private String cardinal(float deg) {
        String[] dirs={"Utara","Timur Laut","Timur","Tenggara","Selatan","Barat Daya","Barat","Barat Laut"};
        return dirs[(int)Math.round(((deg%360)+360)%360/45)%8];
    }
    private void saveEmergency() {
        requireLocation(() -> {
            db.savePoint("DARURAT TERAKHIR", currentLocation.getLatitude(), currentLocation.getLongitude(), "Darurat");
            new AlertDialog.Builder(this).setTitle("KOORDINAT DARURAT TERSIMPAN")
                .setMessage(String.format(Locale.US, "%.6f, %.6f", currentLocation.getLatitude(), currentLocation.getLongitude()))
                .setPositiveButton("OK",null).show();
        });
    }
    private void catchDialog() {
        requireLocation(() -> {
            LinearLayout box = new LinearLayout(this); box.setPadding(20,10,20,10); box.setOrientation(LinearLayout.VERTICAL);
            EditText species = new EditText(this); species.setHint("Jenis ikan"); box.addView(species);
            EditText weight = new EditText(this); weight.setHint("Berat (kg)"); weight.setInputType(8194); box.addView(weight);
            EditText note = new EditText(this); note.setHint("Catatan (opsional)"); box.addView(note);
            new AlertDialog.Builder(this).setTitle("Catat hasil tangkapan").setView(box)
                .setPositiveButton("SIMPAN", (d,w) -> {
                    db.saveCatch(species.getText().toString(), weight.getText().toString(), note.getText().toString(),
                        currentLocation.getLatitude(), currentLocation.getLongitude());
                    Toast.makeText(this,"Hasil tangkapan tersimpan offline",Toast.LENGTH_LONG).show();
                }).setNegativeButton("BATAL",null).show();
        });
    }
    private void showRumpons() {
        Cursor c = db.points("Rumpon");
        StringBuilder s = new StringBuilder();
        while(c.moveToNext()) s.append(c.getString(1)).append("\n").append(c.getDouble(2)).append(", ").append(c.getDouble(3)).append("\n\n");
        c.close();
        new AlertDialog.Builder(this).setTitle("RUMPON TERSIMPAN").setMessage(s.length()==0?"Belum ada rumpon.":s.toString()).setPositiveButton("TUTUP",null).show();
    }
    private void showCatches() {
        Cursor c = db.catches();
        StringBuilder s = new StringBuilder();
        while(c.moveToNext()) s.append(c.getString(1)).append(" • ").append(c.getString(2)).append(" kg\n").append(c.getString(3)).append("\n\n");
        c.close();
        new AlertDialog.Builder(this).setTitle("HASIL TANGKAPAN").setMessage(s.length()==0?"Belum ada catatan.":s.toString()).setPositiveButton("TUTUP",null).show();
    }
    private void saveBoundary() {
        try {
            double v = Double.parseDouble(boundaryInput.getText().toString());
            if (!Double.isFinite(v) || v < 1 || v > 200) throw new NumberFormatException();
            boundaryNm = v;
            prefs.edit().putFloat("alarm_nm", (float) boundaryNm).apply();
            Toast.makeText(this, "Alarm jarak " + v + " NM disimpan untuk pengaturan perjalanan berikutnya", Toast.LENGTH_LONG).show();
        } catch(Exception e) { boundaryInput.setError("Masukkan angka 1–200 NM"); }
    }
    @Override public void onProviderDisabled(String p) { statusText.setText("GPS dimatikan. Aktifkan lokasi HP."); }
    @Override public void onProviderEnabled(String p) { statusText.setText("GPS aktif."); }
    @Override public void onStatusChanged(String p, int s, Bundle b) {}
    @Override protected void onDestroy() {
        super.onDestroy();
        try { locationManager.removeUpdates(this); } catch(Exception ignored) {}
    }

    static class Db extends SQLiteOpenHelper {
        Db(Context c) { super(c, "nelayan_gps.db", null, 1); }
        public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE points(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,lat REAL,lon REAL,type TEXT,created TEXT)");
            d.execSQL("CREATE TABLE catches(id INTEGER PRIMARY KEY AUTOINCREMENT,species TEXT,weight TEXT,note TEXT,lat REAL,lon REAL,created TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV) {}
        void savePoint(String n,double lat,double lon,String type) {
            ContentValues v=new ContentValues(); v.put("name",n); v.put("lat",lat); v.put("lon",lon); v.put("type",type);
            v.put("created",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()));
            getWritableDatabase().insert("points",null,v);
        }
        Cursor points(String type) { return getReadableDatabase().rawQuery("SELECT * FROM points WHERE type=? ORDER BY id DESC",new String[]{type}); }
        void saveCatch(String sp,String wt,String note,double lat,double lon) {
            ContentValues v=new ContentValues(); v.put("species",sp); v.put("weight",wt); v.put("note",note);
            v.put("lat",lat); v.put("lon",lon); v.put("created",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()));
            getWritableDatabase().insert("catches",null,v);
        }
        Cursor catches() { return getReadableDatabase().rawQuery("SELECT * FROM catches ORDER BY id DESC",null); }
    }
}
