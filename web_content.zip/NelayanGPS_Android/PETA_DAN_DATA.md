# Peta dan data laut NELAYAN GPS GO v0.3

## Fitur peta tahap awal
- Peta dasar OpenStreetMap online melalui Leaflet.
- Marker posisi GPS kapal dan lingkaran akurasi GPS.
- Titik yang disimpan dari peta dan titik rumpon/titik awal yang sudah ada di database lokal akan ditampilkan.
- Peta dapat digeser dan diperbesar/diperkecil.
- Data titik tersimpan di SQLite pada HP.

## Batasan yang wajib dipahami
Peta OpenStreetMap adalah peta dasar umum, bukan Electronic Navigational Chart (ENC). Peta ini tidak menjamin informasi kedalaman, kontur dasar laut, karang, rintangan bawah air, alur pelayaran, zona larangan, atau alat bantu navigasi. Peta dasar memerlukan internet dan tidak disediakan sebagai peta offline pada versi ini. Marker GPS dan titik tersimpan tetap lokal, tetapi latar peta tidak dijamin tersedia tanpa koneksi.

Jangan gunakan peta dasar ini untuk memilih jalur aman atau sebagai satu-satunya alat navigasi kapal.

## Peta laut resmi
IHDC/PUSHIDROSAL menyediakan katalog ENC, visualisasi basemap ENC dan layanan hidrografi. Untuk penggunaan ENC di aplikasi offline, pemilik aplikasi perlu meminta data/cell yang sesuai cakupan Paciran-Lamongan, Gresik, Tuban dan Madura, serta memastikan izin/lisensi penggunaan, pembaruan, dan format distribusinya. Jangan mengunduh/memasukkan ENC yang tidak memiliki izin penggunaan aplikasi.

Portal: https://ihdc.pushidrosal.id/arcgis/apps/sites/
Layanan peta laut: https://www.pushidrosal.id/layanan/pli

## Tahap lanjutan setelah ENC tersedia
- Modul impor ENC yang sesuai lisensi dan format.
- Tampilan kedalaman, kontur, simbol bahaya dan alat bantu navigasi dari ENC.
- Pemeriksaan tanggal edisi dan pembaruan data.
- Pengujian tampilan dan posisi di lapangan; tidak mengklaim rute aman otomatis sebelum mesin/rules navigasi tervalidasi.
