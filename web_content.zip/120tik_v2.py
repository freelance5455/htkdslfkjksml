import os
import sys
import shutil
import zipfile
import tempfile
import threading
import subprocess
import urllib.request
import tkinter as tk
from tkinter import filedialog, messagebox

import winsound

import customtkinter as ctk
import cv2

from PIL import Image


# ============================================================
# 120tik
# Video Enhancer / FPS Interpolation / Auto FFmpeg
# ============================================================

APP_NAME = "120tik"
LANGUAGE_DEFAULT = "English"

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")


# ============================================================
# COLORS
# ============================================================

BG = "#050505"
CARD = "#0D0D0D"
CARD2 = "#151515"
CARD3 = "#1B1B1B"

BORDER = "#2A2415"

GOLD = "#D4AF37"
GOLD_HOVER = "#F0C94A"
GOLD_DARK = "#8F7625"

TEXT = "#F4F1E8"
MUTED = "#8D8A80"

GOOD = "#62D98A"
BAD = "#E56B6B"
WARN = "#E8C45A"


# ============================================================
# PATHS
# ============================================================

APP_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

FFMPEG_DIR = os.path.join(
    APP_DIR,
    "ffmpeg"
)

FFMPEG_BIN_DIR = os.path.join(
    FFMPEG_DIR,
    "bin"
)

LOCAL_FFMPEG = os.path.join(
    FFMPEG_BIN_DIR,
    "ffmpeg.exe"
)


# ============================================================
# FFMPEG DOWNLOAD
# ============================================================

FFMPEG_URL = (
    "https://www.gyan.dev/ffmpeg/builds/"
    "ffmpeg-release-essentials.zip"
)


# ============================================================
# HELPERS
# ============================================================

def clamp(value, minimum, maximum):
    return max(
        minimum,
        min(maximum, value)
    )


def find_ffmpeg():
    """
    البحث عن FFmpeg:

    1. النسخة التي تم تنزيلها داخل البرنامج.
    2. PATH.
    3. ffmpeg.exe بجانب البرنامج.
    4. مجلدات FFmpeg المعتادة.
    """

    # Local automatic installation
    if os.path.isfile(LOCAL_FFMPEG):
        return LOCAL_FFMPEG

    # PATH
    exe = shutil.which(
        "ffmpeg"
    )

    if exe:
        return exe

    # Current directory
    candidates = [

        os.path.join(
            APP_DIR,
            "ffmpeg.exe"
        ),

        os.path.join(
            APP_DIR,
            "bin",
            "ffmpeg.exe"
        ),

        r"C:\ffmpeg\bin\ffmpeg.exe",

        r"C:\Program Files\ffmpeg\bin\ffmpeg.exe",

        r"C:\Program Files (x86)\ffmpeg\bin\ffmpeg.exe",
    ]

    for path in candidates:

        if os.path.isfile(path):

            return path

    return None


def beep(kind="click"):

    try:

        frequencies = {
            "click": 700,
            "success": 1050,
            "error": 300,
        }

        durations = {
            "click": 25,
            "success": 70,
            "error": 100,
        }

        winsound.Beep(
            frequencies.get(
                kind,
                700
            ),
            durations.get(
                kind,
                25
            )
        )

    except Exception:
        pass


def enhance(
    frame,
    saturation=1.05,
    contrast=1.02,
    sharpen=0.15,
    denoise=0.0
):

    img = frame

    # --------------------------------------------------------
    # DENOISE
    # --------------------------------------------------------

    if denoise > 0.01:

        strength = int(
            clamp(
                denoise,
                0.0,
                1.0
            ) * 7
        )

        if strength > 0:

            img = cv2.fastNlMeansDenoisingColored(
                img,
                None,
                strength,
                strength,
                7,
                21
            )

    # --------------------------------------------------------
    # CONTRAST
    # --------------------------------------------------------

    if abs(
        contrast - 1.0
    ) > 0.005:

        img = cv2.convertScaleAbs(
            img,
            alpha=float(
                contrast
            ),
            beta=0
        )

    # --------------------------------------------------------
    # SATURATION
    # --------------------------------------------------------

    if abs(
        saturation - 1.0
    ) > 0.005:

        hsv = cv2.cvtColor(
            img,
            cv2.COLOR_BGR2HSV
        )

        h, s, v = cv2.split(
            hsv
        )

        s = cv2.multiply(
            s,
            float(
                saturation
            )
        )

        s = s.clip(
            0,
            255
        ).astype(
            "uint8"
        )

        img = cv2.cvtColor(
            cv2.merge(
                (
                    h,
                    s,
                    v
                )
            ),
            cv2.COLOR_HSV2BGR
        )

    # --------------------------------------------------------
    # SHARPEN
    # --------------------------------------------------------

    if sharpen > 0.01:

        amount = float(
            sharpen
        )

        blur = cv2.GaussianBlur(
            img,
            (0, 0),
            1.0
        )

        img = cv2.addWeighted(
            img,
            1.0 + amount,
            blur,
            -amount,
            0
        )

    return img


# ============================================================
# MAIN APPLICATION
# ============================================================

class VideoStudio(ctk.CTk):

    def __init__(self):

        super().__init__()

        # ----------------------------------------------------
        # WINDOW
        # ----------------------------------------------------

        self.title(
            APP_NAME
        )

        self.geometry(
            "1180x820"
        )

        self.minsize(
            980,
            700
        )

        self.configure(
            fg_color=BG
        )

        # ----------------------------------------------------
        # VIDEO
        # ----------------------------------------------------

        self.input_path = ""

        self.duration = 0.0

        self.src_fps = 30.0

        self.width = 0

        self.height = 0

        # ----------------------------------------------------
        # PREVIEW
        # ----------------------------------------------------

        self.preview_cap = None

        self.preview_running = False

        self.preview_job = None

        self.preview_token = 0

        self.preview_before_image = None

        self.preview_after_image = None

        # ----------------------------------------------------
        # EXPORT
        # ----------------------------------------------------

        self.export_process = None

        self.export_cancelled = False

        # ----------------------------------------------------
        # ADVANCED PROCESSING
        # ----------------------------------------------------

        self.var_motion_blur = tk.BooleanVar(value=False)
        self.var_scene_detection = tk.BooleanVar(value=True)
        self.var_deblock = tk.BooleanVar(value=False)
        self.var_detail = tk.BooleanVar(value=False)

        # ----------------------------------------------------
        # FFMPEG
        # ----------------------------------------------------

        self.ffmpeg = find_ffmpeg()

        self.ffmpeg_downloading = False

        self.language = LANGUAGE_DEFAULT
        self.smart_compression_running = False

        # ----------------------------------------------------
        # CLOSE
        # ----------------------------------------------------

        self.protocol(
            "WM_DELETE_WINDOW",
            self.on_close
        )

        # ----------------------------------------------------
        # HOTKEYS
        # ----------------------------------------------------

        self.bind(
            "<Escape>",
            lambda _event:
                self.stop_preview()
        )

        self.bind(
            "<Control-o>",
            lambda _event:
                self.select_video()
        )

        self.bind(
            "<F5>",
            lambda _event:
                self.start_export()
        )

        # ----------------------------------------------------
        # UI
        # ----------------------------------------------------
        # NOTE (FIX): the floating-shapes canvas MUST be created
        # before the rest of the UI is built. Canvas.lower("all")
        # only reorders items *inside* the canvas (it's shadowed
        # from the normal Tk widget stacking API), so it can NOT
        # push the canvas behind the other widgets after they
        # already exist. Creating it first means it starts at the
        # bottom of the stacking order naturally, so it no longer
        # covers the buttons/labels/preview panels.

        self.start_floating_shapes()
        self.build_ui()

        # ----------------------------------------------------
        # AUTO FFMPEG
        # ----------------------------------------------------

        if self.ffmpeg:

            self.set_ffmpeg_ready()

        else:

            self.after(
                500,
                self.auto_install_ffmpeg
            )

    # ========================================================
    # BUTTON ANIMATION
    # ========================================================

    def animate_button(
        self,
        button
    ):

        try:

            old_height = int(
                button.cget(
                    "height"
                )
            )

            button.configure(
                height=max(
                    32,
                    old_height - 2
                )
            )

            self.after(
                65,
                lambda:
                    button.configure(
                        height=old_height
                    )
            )

        except Exception:
            pass

    # ========================================================
    # FLOATING UI SHAPES
    # ========================================================

    def start_floating_shapes(self):
        """Subtle animated gold particles behind the interface."""

        self._shape_canvas = tk.Canvas(
            self,
            bg=BG,
            highlightthickness=0,
            bd=0
        )
        self._shape_canvas.place(
            x=0, y=0, relwidth=1, relheight=1
        )

        # FIX: Canvas overrides `.lower()` for its own drawn items
        # (tag-based stacking), so `self._shape_canvas.lower("all")`
        # does nothing to the widget's position among its Tk
        # siblings. Use the raw Tk `lower` command on the widget's
        # path name instead to actually send the canvas behind the
        # rest of the UI.
        self._shape_canvas.tk.call(
            "lower", self._shape_canvas._w
        )

        self._floating_shapes = []

        for index in range(24):
            size = 3 + (index % 5) * 2
            x = (index * 83) % 1180
            y = (index * 137) % 820
            speed = 0.15 + (index % 4) * 0.08
            drift = -0.18 if index % 2 else 0.18

            shape_id = self._shape_canvas.create_oval(
                x, y, x + size, y + size,
                outline=GOLD_DARK,
                fill="",
                width=1
            )

            self._floating_shapes.append({
                "id": shape_id,
                "x": float(x),
                "y": float(y),
                "size": size,
                "speed": speed,
                "drift": drift
            })

        self._animate_floating_shapes()

    def _animate_floating_shapes(self):
        if not hasattr(self, "_shape_canvas"):
            return

        try:
            w = max(self.winfo_width(), 980)
            h = max(self.winfo_height(), 700)

            for item in self._floating_shapes:
                item["y"] -= item["speed"]
                item["x"] += item["drift"]

                if item["y"] < -30:
                    item["y"] = h + 20
                    item["x"] = (item["x"] * 1.37) % w

                if item["x"] < -30:
                    item["x"] = w + 10
                elif item["x"] > w + 30:
                    item["x"] = -10

                x = item["x"]
                y = item["y"]
                size = item["size"]

                self._shape_canvas.coords(
                    item["id"],
                    x, y, x + size, y + size
                )

            self.after(45, self._animate_floating_shapes)

        except Exception:
            pass

    # ========================================================
    # GOLD BUTTON
    # ========================================================

    def gold_button(
        self,
        parent,
        text,
        command,
        width=150,
        height=40
    ):

        button = None

        def wrapped():

            self.animate_button(
                button
            )

            beep(
                "click"
            )

            command()

        button = ctk.CTkButton(

            parent,

            text=text,

            width=width,

            height=height,

            corner_radius=10,

            fg_color=GOLD_DARK,

            hover_color=GOLD,

            text_color="#080808",

            font=ctk.CTkFont(
                size=12,
                weight="bold"
            ),

            command=wrapped
        )

        return button

    # ========================================================
    # UI
    # ========================================================

    def build_ui(self):

        # ====================================================
        # HEADER
        # ====================================================

        top = ctk.CTkFrame(
            self,
            fg_color="transparent"
        )

        top.pack(
            fill="x",
            padx=24,
            pady=(18, 8)
        )

        title_box = ctk.CTkFrame(
            top,
            fg_color="transparent"
        )

        title_box.pack(
            side="left"
        )

        self.title_label = ctk.CTkLabel(
            title_box,
            text="120tik",
            font=ctk.CTkFont(
                size=30,
                weight="bold"
            ),
            text_color=GOLD
        )
        self.title_label.pack(
            anchor="w"
        )

        self.subtitle_label = ctk.CTkLabel(
            title_box,
            text=(
                "VIDEO ENHANCER  •  "
                "OPTICAL-FLOW INTERPOLATION  •  "
                "MOTION  •  EXPORT"
            ),
            font=ctk.CTkFont(
                size=10,
                weight="bold"
            ),
            text_color=MUTED
        )
        self.subtitle_label.pack(
            anchor="w"
        )

        self.language_menu = ctk.CTkOptionMenu(
            top,
            values=["English", "العربية"],
            width=105,
            height=34,
            fg_color=CARD2,
            button_color=CARD2,
            button_hover_color=CARD3,
            dropdown_fg_color=CARD2,
            dropdown_hover_color=CARD3,
            corner_radius=10,
            font=ctk.CTkFont(
                size=10,
                weight="bold"
            ),
            command=self.change_language
        )
        self.language_menu.set("English")
        self.language_menu.pack(
            side="right",
            padx=(8, 0)
        )

        self.status_badge = ctk.CTkLabel(

            top,

            text="● CHECKING FFMPEG...",

            fg_color=CARD2,

            corner_radius=10,

            text_color=WARN,

            padx=13,

            pady=7
        )

        self.status_badge.pack(
            side="right"
        )

        # ====================================================
        # FILE CARD
        # ====================================================

        file_card = ctk.CTkFrame(

            self,

            fg_color=CARD,

            corner_radius=15,

            border_width=1,

            border_color=BORDER
        )

        file_card.pack(

            fill="x",

            padx=24,

            pady=7
        )

        self.btn_select = self.gold_button(

            file_card,

            "OPEN VIDEO",

            self.select_video,

            145,

            40
        )

        self.btn_select.pack(

            side="left",

            padx=13,

            pady=13
        )

        self.file_label = ctk.CTkLabel(

            file_card,

            text="No video selected",

            text_color=MUTED,

            anchor="w"
        )

        self.file_label.pack(

            side="left",

            fill="x",

            expand=True,

            padx=8
        )

        self.info_label = ctk.CTkLabel(

            file_card,

            text="",

            text_color=MUTED
        )

        self.info_label.pack(
            side="right",
            padx=13
        )

        self.smart_compress_btn = self.gold_button(
            file_card,
            "SMART COMPRESS",
            self.start_smart_compress,
            165,
            40
        )
        self.smart_compress_btn.pack(
            side="right",
            padx=(6, 6),
            pady=13
        )

        # ====================================================
        # PREVIEW
        # ====================================================

        preview = ctk.CTkFrame(

            self,

            fg_color=CARD,

            corner_radius=15,

            border_width=1,

            border_color=BORDER
        )

        preview.pack(

            fill="both",

            expand=True,

            padx=24,

            pady=7
        )

        preview.grid_columnconfigure(
            0,
            weight=1
        )

        preview.grid_columnconfigure(
            1,
            weight=1
        )

        preview.grid_rowconfigure(
            0,
            weight=1
        )

        # ----------------------------------------------------
        # ORIGINAL
        # ----------------------------------------------------

        self.before_panel = ctk.CTkFrame(

            preview,

            fg_color="#020202",

            corner_radius=11
        )

        self.before_panel.grid(

            row=0,

            column=0,

            sticky="nsew",

            padx=(11, 5),

            pady=11
        )

        # ----------------------------------------------------
        # ENHANCED
        # ----------------------------------------------------

        self.after_panel = ctk.CTkFrame(

            preview,

            fg_color="#020202",

            corner_radius=11
        )

        self.after_panel.grid(

            row=0,

            column=1,

            sticky="nsew",

            padx=(5, 11),

            pady=11
        )

        self.before_title_label = ctk.CTkLabel(
            self.before_panel,
            text="ORIGINAL",
            text_color=MUTED,
            font=ctk.CTkFont(
                size=10,
                weight="bold"
            )
        )
        self.before_title_label.pack(
            anchor="nw",
            padx=11,
            pady=7
        )

        self.after_title_label = ctk.CTkLabel(
            self.after_panel,
            text="120TIK ENHANCED",
            text_color=GOLD,
            font=ctk.CTkFont(
                size=10,
                weight="bold"
            )
        )
        self.after_title_label.pack(
            anchor="nw",
            padx=11,
            pady=7
        )

        self.before_label = ctk.CTkLabel(

            self.before_panel,

            text="Open a video to preview",

            text_color=MUTED
        )

        self.before_label.pack(

            fill="both",

            expand=True,

            padx=8,

            pady=8
        )

        self.after_label = ctk.CTkLabel(

            self.after_panel,

            text="Open a video to preview",

            text_color=MUTED
        )

        self.after_label.pack(

            fill="both",

            expand=True,

            padx=8,

            pady=8
        )

        # ====================================================
        # PREVIEW CONTROLS
        # ====================================================

        preview_buttons = ctk.CTkFrame(

            preview,

            fg_color="transparent"
        )

        preview_buttons.grid(

            row=1,

            column=0,

            columnspan=2,

            pady=(0, 10)
        )

        self.play_btn = ctk.CTkButton(

            preview_buttons,

            text="▶ PLAY",

            width=110,

            height=34,

            corner_radius=9,

            fg_color=CARD3,

            hover_color="#272727",

            command=self.toggle_preview
        )

        self.play_btn.pack(

            side="left",

            padx=4
        )

        self.stop_btn = ctk.CTkButton(

            preview_buttons,

            text="■ STOP",

            width=110,

            height=34,

            corner_radius=9,

            fg_color=CARD3,

            hover_color="#272727",

            command=self.stop_preview
        )

        self.stop_btn.pack(

            side="left",

            padx=4
        )

        self.preview_quality = ctk.CTkOptionMenu(

            preview_buttons,

            values=[
                "Preview: LOW",
                "Preview: MEDIUM",
                "Preview: HIGH"
            ],

            width=150,

            height=34,

            fg_color=CARD3,

            button_color=CARD3,

            button_hover_color="#272727",

            dropdown_fg_color=CARD3,

            command=lambda _value:
                beep("click")
        )

        self.preview_quality.set(
            "Preview: LOW"
        )

        self.preview_quality.pack(

            side="left",

            padx=7
        )

        # ====================================================
        # SETTINGS
        # ====================================================

        settings = ctk.CTkScrollableFrame(

            self,

            fg_color=CARD,

            corner_radius=15,

            border_width=1,

            border_color=BORDER,

            height=190
        )

        settings.pack(

            fill="x",

            padx=24,

            pady=7
        )

        for col in range(4):

            settings.grid_columnconfigure(
                col,
                weight=1
            )

        self.target_fps = self.add_option(

            settings,
            0,
            0,
            "OUTPUT FPS",

            [
                "Keep source",
                "30 FPS",
                "60 FPS",
                "90 FPS",
                "120 FPS",
                "144 FPS",
                "180 FPS",
                "240 FPS"
            ],

            "120 FPS"
        )

        self.quality = self.add_option(

            settings,
            0,
            1,
            "QUALITY / SIZE",

            [
                "Visually lossless (CRF 16)",
                "High quality (CRF 18)",
                "Balanced (CRF 21)",
                "Small file (CRF 24)",
                "Very small (CRF 28)"
            ],

            "High quality (CRF 18)"
        )

        self.codec = self.add_option(

            settings,
            0,
            2,
            "CODEC",

            [
                "H.264 — maximum compatibility",
                "H.265 — smaller files"
            ],

            "H.264 — maximum compatibility"
        )

        self.resolution = self.add_option(

            settings,
            0,
            3,
            "RESOLUTION",

            [
                "Original",
                "1080p",
                "720p",
                "480p",
                "75% of original",
                "50% of original"
            ],

            "Original"
        )

        self.saturation = self.add_slider(

            settings,
            1,
            0,
            "SATURATION",
            0.75,
            1.35,
            1.05
        )

        self.contrast = self.add_slider(

            settings,
            1,
            1,
            "CONTRAST",
            0.80,
            1.25,
            1.02
        )

        self.sharpen = self.add_slider(

            settings,
            1,
            2,
            "SHARPEN",
            0,
            0.8,
            0.15
        )

        self.denoise = self.add_slider(

            settings,
            1,
            3,
            "DENOISE",
            0,
            1,
            0
        )

        # ====================================================
        # ADVANCED MOTION / QUALITY
        # ====================================================

        advanced = ctk.CTkScrollableFrame(
            self,
            fg_color=CARD,
            corner_radius=15,
            border_width=1,
            border_color=BORDER,
            height=155
        )
        advanced.pack(
            fill="x",
            padx=24,
            pady=7
        )

        for col in range(4):
            advanced.grid_columnconfigure(col, weight=1)

        self.motion_blur_strength_slider = self.add_slider(
            advanced, 0, 0, "MOTION BLUR",
            0.0, 1.0, 0.35
        )

        self.scene_threshold_slider = self.add_slider(
            advanced, 0, 1, "SCENE DETECTION",
            2.0, 25.0, 10.0
        )

        self.interpolation_mode = self.add_option(
            advanced, 0, 2, "INTERPOLATION ENGINE",
            [
                "MCI — Quality",
                "MCI — Balanced",
                "MCI — Fast",
                "Blend fallback"
            ],
            "MCI — Quality"
        )

        self.processing_profile = self.add_option(
            advanced, 0, 3, "PROCESSING PROFILE",
            [
                "Cinematic",
                "Ultra Smooth",
                "Clean Detail",
                "Fast Export"
            ],
            "Cinematic"
        )

        self.make_switch(
            advanced, "Motion blur compensation",
            self.var_motion_blur
        ).grid(row=1, column=0, sticky="w", padx=8, pady=5)

        self.make_switch(
            advanced, "Scene-change protection",
            self.var_scene_detection
        ).grid(row=1, column=1, sticky="w", padx=8, pady=5)

        self.make_switch(
            advanced, "Deblock / artifact cleanup",
            self.var_deblock
        ).grid(row=1, column=2, sticky="w", padx=8, pady=5)

        self.make_switch(
            advanced, "Detail recovery",
            self.var_detail
        ).grid(row=1, column=3, sticky="w", padx=8, pady=5)

        # ====================================================
        # SWITCHES
        # ====================================================

        switches = ctk.CTkFrame(

            self,

            fg_color="transparent"
        )

        switches.pack(

            fill="x",

            padx=24,

            pady=(2, 3)
        )

        self.var_interpolate = tk.BooleanVar(
            value=True
        )

        self.var_audio = tk.BooleanVar(
            value=True
        )

        self.var_faststart = tk.BooleanVar(
            value=True
        )

        self.var_keep_aspect = tk.BooleanVar(
            value=True
        )

        self.make_switch(

            switches,
            "Frame interpolation",
            self.var_interpolate

        ).pack(

            side="left",
            padx=(0, 18)
        )

        self.make_switch(

            switches,
            "Keep audio",
            self.var_audio

        ).pack(

            side="left",
            padx=(0, 18)
        )

        self.make_switch(

            switches,
            "Fast-start",
            self.var_faststart

        ).pack(

            side="left",
            padx=(0, 18)
        )

        self.make_switch(

            switches,
            "Keep aspect",
            self.var_keep_aspect

        ).pack(
            side="left"
        )

        # ====================================================
        # BOTTOM
        # ====================================================

        bottom = ctk.CTkFrame(

            self,

            fg_color="transparent"
        )

        bottom.pack(

            fill="x",

            padx=24,

            pady=(4, 17)
        )

        self.progress = ctk.CTkProgressBar(

            bottom,

            height=8,

            corner_radius=5,

            progress_color=GOLD
        )

        self.progress.pack(

            fill="x",

            pady=(0, 7)
        )

        self.progress.set(
            0
        )

        self.status = ctk.CTkLabel(

            bottom,

            text="Checking FFmpeg...",

            text_color=MUTED,

            anchor="w"
        )

        self.status.pack(
            side="left"
        )

        self.cancel_btn = ctk.CTkButton(

            bottom,

            text="CANCEL",

            width=100,

            height=43,

            corner_radius=10,

            fg_color="#262018",

            hover_color="#392D19",

            text_color=GOLD,

            command=self.cancel_export,

            state="disabled"
        )

        self.cancel_btn.pack(

            side="right",

            padx=(7, 0)
        )

        self.export_btn = ctk.CTkButton(

            bottom,

            text="EXPORT VIDEO",

            width=185,

            height=43,

            corner_radius=10,

            fg_color=GOLD_DARK,

            hover_color=GOLD,

            text_color="#080808",

            font=ctk.CTkFont(
                size=13,
                weight="bold"
            ),

            command=self.start_export
        )

        self.export_btn.pack(
            side="right"
        )

    # ========================================================
    # OPTION MENU
    # ========================================================

    def add_option(
        self,
        parent,
        row,
        col,
        label,
        values,
        default
    ):

        box = ctk.CTkFrame(

            parent,

            fg_color="transparent"
        )

        box.grid(

            row=row,

            column=col,

            sticky="ew",

            padx=8,

            pady=7
        )

        ctk.CTkLabel(

            box,

            text=label,

            text_color=MUTED,

            font=ctk.CTkFont(
                size=9,
                weight="bold"
            )

        ).pack(

            anchor="w",

            pady=(0, 4)
        )

        menu = ctk.CTkOptionMenu(

            box,

            values=values,

            fg_color=CARD3,

            button_color=CARD3,

            button_hover_color="#292929",

            dropdown_fg_color=CARD3,

            dropdown_hover_color="#2C2618",

            corner_radius=8,

            height=33,

            command=lambda _value:
                beep("click")
        )

        menu.set(
            default
        )

        menu.pack(
            fill="x"
        )

        return menu

    # ========================================================
    # SLIDER
    # ========================================================

    def add_slider(
        self,
        parent,
        row,
        col,
        label,
        lo,
        hi,
        default
    ):

        box = ctk.CTkFrame(

            parent,

            fg_color="transparent"
        )

        box.grid(

            row=row,

            column=col,

            sticky="ew",

            padx=8,

            pady=7
        )

        title = ctk.CTkFrame(

            box,

            fg_color="transparent"
        )

        title.pack(
            fill="x"
        )

        ctk.CTkLabel(

            title,

            text=label,

            text_color=MUTED,

            font=ctk.CTkFont(
                size=9,
                weight="bold"
            )

        ).pack(
            side="left"
        )

        value_label = ctk.CTkLabel(

            title,

            text=f"{default:.2f}",

            text_color=GOLD,

            font=ctk.CTkFont(
                size=9,
                weight="bold"
            )
        )

        value_label.pack(
            side="right"
        )

        slider = ctk.CTkSlider(

            box,

            from_=lo,

            to=hi,

            fg_color="#252525",

            progress_color=GOLD_DARK,

            button_color=GOLD,

            button_hover_color=GOLD_HOVER,

            command=lambda value_now:
                value_label.configure(
                    text=f"{float(value_now):.2f}"
                )
        )

        slider.set(
            default
        )

        slider.pack(

            fill="x",

            pady=(5, 0)
        )

        return slider

    # ========================================================
    # SWITCH
    # ========================================================

    def make_switch(
        self,
        parent,
        text,
        variable
    ):

        return ctk.CTkCheckBox(

            parent,

            text=text,

            variable=variable,

            fg_color=GOLD_DARK,

            hover_color=GOLD,

            border_color="#514A38",

            text_color=MUTED,

            command=lambda:
                beep("click")
        )

    # ========================================================
    # FFMPEG STATUS
    # ========================================================

    def set_ffmpeg_ready(self):

        self.ffmpeg = find_ffmpeg()

        if self.ffmpeg:

            self.status_badge.configure(

                text="● FFMPEG READY",

                text_color=GOOD
            )

            self.status.configure(

                text="Ready",

                text_color=MUTED
            )

            self.export_btn.configure(
                state="normal"
            )

        else:

            self.status_badge.configure(

                text="● FFMPEG NOT FOUND",

                text_color=BAD
            )

    # ========================================================
    # AUTO INSTALL FFMPEG
    # ========================================================

    def auto_install_ffmpeg(self):

        if self.ffmpeg_downloading:
            return

        self.ffmpeg_downloading = True

        self.status_badge.configure(

            text="● DOWNLOADING FFMPEG...",

            text_color=WARN
        )

        self.status.configure(

            text="Downloading FFmpeg automatically...",

            text_color=WARN
        )

        self.export_btn.configure(
            state="disabled"
        )

        threading.Thread(

            target=self.download_ffmpeg,

            daemon=True

        ).start()

    # ========================================================
    # DOWNLOAD FFMPEG
    # ========================================================

    def download_ffmpeg(self):

        zip_path = os.path.join(

            tempfile.gettempdir(),

            "120tik_ffmpeg.zip"
        )

        temp_extract = os.path.join(

            tempfile.gettempdir(),

            "120tik_ffmpeg_extract"
        )

        try:

            # ------------------------------------------------
            # CREATE FOLDERS
            # ------------------------------------------------

            os.makedirs(
                APP_DIR,
                exist_ok=True
            )

            # ------------------------------------------------
            # DOWNLOAD
            # ------------------------------------------------

            def report_hook(
                block_num,
                block_size,
                total_size
            ):

                if total_size <= 0:
                    return

                downloaded = (
                    block_num *
                    block_size
                )

                percent = clamp(

                    downloaded /
                    total_size,

                    0,

                    1
                )

                self.after(

                    0,

                    lambda p=percent:
                        self.progress.set(p)
                )

            urllib.request.urlretrieve(

                FFMPEG_URL,

                zip_path,

                reporthook=report_hook
            )

            # ------------------------------------------------
            # REMOVE OLD TEMP EXTRACTION
            # ------------------------------------------------

            if os.path.isdir(
                temp_extract
            ):

                shutil.rmtree(
                    temp_extract,
                    ignore_errors=True
                )

            os.makedirs(
                temp_extract,
                exist_ok=True
            )

            # ------------------------------------------------
            # EXTRACT
            # ------------------------------------------------

            with zipfile.ZipFile(
                zip_path,
                "r"
            ) as archive:

                archive.extractall(
                    temp_extract
                )

            # ------------------------------------------------
            # FIND ffmpeg.exe
            # ------------------------------------------------

            found_ffmpeg = None

            for root, dirs, files in os.walk(
                temp_extract
            ):

                if (
                    "ffmpeg.exe"
                    in files
                ):

                    found_ffmpeg = os.path.join(
                        root,
                        "ffmpeg.exe"
                    )

                    break

            if not found_ffmpeg:

                raise RuntimeError(
                    "FFmpeg was downloaded, "
                    "but ffmpeg.exe could not be found."
                )

            # ------------------------------------------------
            # FIND BIN DIRECTORY
            # ------------------------------------------------

            found_bin = os.path.dirname(
                found_ffmpeg
            )

            source_root = os.path.dirname(
                found_bin
            )

            # ------------------------------------------------
            # REMOVE OLD INSTALLATION
            # ------------------------------------------------

            if os.path.isdir(
                FFMPEG_DIR
            ):

                shutil.rmtree(
                    FFMPEG_DIR,
                    ignore_errors=True
                )

            # ------------------------------------------------
            # COPY ENTIRE FFMPEG FOLDER
            # ------------------------------------------------

            shutil.copytree(

                source_root,

                FFMPEG_DIR
            )

            # ------------------------------------------------
            # VERIFY
            # ------------------------------------------------

            if not os.path.isfile(
                LOCAL_FFMPEG
            ):

                # Some builds may have a
                # slightly different folder structure.
                # Copy the executable directly.

                os.makedirs(
                    FFMPEG_BIN_DIR,
                    exist_ok=True
                )

                shutil.copy2(

                    found_ffmpeg,

                    LOCAL_FFMPEG
                )

            # ------------------------------------------------
            # SET PATH
            # ------------------------------------------------

            self.ffmpeg = LOCAL_FFMPEG

            # ------------------------------------------------
            # CLEAN
            # ------------------------------------------------

            try:

                if os.path.exists(
                    zip_path
                ):

                    os.remove(
                        zip_path
                    )

            except Exception:
                pass

            try:

                if os.path.isdir(
                    temp_extract
                ):

                    shutil.rmtree(
                        temp_extract,
                        ignore_errors=True
                    )

            except Exception:
                pass

            # ------------------------------------------------
            # SUCCESS
            # ------------------------------------------------

            self.after(

                0,

                self.ffmpeg_install_success
            )

        except Exception as exc:

            self.after(

                0,

                lambda error=exc:
                    self.ffmpeg_install_failed(
                        error
                    )
            )

    # ========================================================
    # FFMPEG INSTALL SUCCESS
    # ========================================================

    def ffmpeg_install_success(self):

        self.ffmpeg_downloading = False

        self.ffmpeg = find_ffmpeg()

        self.progress.set(
            0
        )

        if self.ffmpeg:

            self.status_badge.configure(

                text="● FFMPEG READY",

                text_color=GOOD
            )

            self.status.configure(

                text="FFmpeg installed automatically",

                text_color=GOOD
            )

            self.export_btn.configure(
                state="normal"
            )

            beep(
                "success"
            )

        else:

            self.status_badge.configure(

                text="● FFMPEG ERROR",

                text_color=BAD
            )

            self.status.configure(

                text="FFmpeg installation failed",

                text_color=BAD
            )

            beep(
                "error"
            )

    # ========================================================
    # FFMPEG INSTALL FAILED
    # ========================================================

    def ffmpeg_install_failed(
        self,
        error
    ):

        self.ffmpeg_downloading = False

        self.ffmpeg = None

        self.progress.set(
            0
        )

        self.status_badge.configure(

            text="● FFMPEG ERROR",

            text_color=BAD
        )

        self.status.configure(

            text="Could not download FFmpeg",

            text_color=BAD
        )

        beep(
            "error"
        )

        messagebox.showerror(

            "120tik - FFmpeg",

            "120tik could not download FFmpeg automatically.\n\n"

            "Possible reasons:\n"
            "• No internet connection\n"
            "• Download blocked by Windows/network\n"
            "• FFmpeg server unavailable\n\n"

            f"Details:\n{error}"
        )

    # ========================================================
    # OPEN VIDEO
    # ========================================================

    def select_video(self):

        if self.ffmpeg_downloading:

            messagebox.showinfo(

                "120tik",

                "Please wait until FFmpeg finishes installing."
            )

            return

        beep(
            "click"
        )

        path = filedialog.askopenfilename(

            title="Select video",

            filetypes=[
                (
                    "Video files",
                    "*.mp4 *.mov *.mkv *.avi *.webm *.m4v"
                ),
                (
                    "All files",
                    "*.*"
                )
            ]
        )

        if not path:
            return

        self.stop_preview()

        cap = cv2.VideoCapture(
            path
        )

        if not cap.isOpened():

            messagebox.showerror(

                "Error",

                "Could not open this video."
            )

            beep(
                "error"
            )

            return

        fps = cap.get(
            cv2.CAP_PROP_FPS
        )

        frames = cap.get(
            cv2.CAP_PROP_FRAME_COUNT
        )

        width = int(
            cap.get(
                cv2.CAP_PROP_FRAME_WIDTH
            )
        )

        height = int(
            cap.get(
                cv2.CAP_PROP_FRAME_HEIGHT
            )
        )

        cap.release()

        if fps <= 0 or fps > 1000:

            fps = 30.0

        self.input_path = path

        self.src_fps = fps

        self.width = width

        self.height = height

        self.duration = (

            frames / fps

            if frames > 0

            else 0
        )

        size_mb = (

            os.path.getsize(path)

            /
            (1024 * 1024)
        )

        self.file_label.configure(

            text=os.path.basename(
                path
            ),

            text_color=TEXT
        )

        self.info_label.configure(

            text=(

                f"{width}×{height}  •  "

                f"{fps:.2f} FPS  •  "

                f"{self.duration:.1f}s  •  "

                f"{size_mb:.1f} MB"
            )
        )

        self.open_preview()

        beep(
            "success"
        )

    # ========================================================
    # PREVIEW SIZE
    # ========================================================

    def get_preview_max(self):

        mode = self.preview_quality.get()

        if mode == "Preview: HIGH":

            return 1280, 720

        if mode == "Preview: MEDIUM":

            return 960, 540

        return 640, 360

    # ========================================================
    # RESIZE PREVIEW
    # ========================================================

    def resize_for_preview(
        self,
        frame
    ):

        max_w, max_h = (
            self.get_preview_max()
        )

        h, w = frame.shape[:2]

        scale = min(

            max_w / max(
                w,
                1
            ),

            max_h / max(
                h,
                1
            ),

            1.0
        )

        if scale >= 0.999:

            return frame

        new_w = max(

            2,

            int(
                w * scale
            )
        )

        new_h = max(

            2,

            int(
                h * scale
            )
        )

        return cv2.resize(

            frame,

            (
                new_w,
                new_h
            ),

            interpolation=cv2.INTER_AREA
        )

    # ========================================================
    # OPEN PREVIEW
    # ========================================================

    def open_preview(self):

        self.stop_preview()

        if not self.input_path:

            return

        self.preview_cap = cv2.VideoCapture(

            self.input_path
        )

        if not self.preview_cap.isOpened():

            self.preview_cap = None

            return

        self.preview_running = True

        self.play_btn.configure(

            text="❚❚ PAUSE"
        )

        self.preview_token += 1

        self.preview_tick(

            self.preview_token
        )

    # ========================================================
    # TOGGLE PREVIEW
    # ========================================================

    def toggle_preview(self):

        if not self.input_path:

            beep(
                "error"
            )

            return

        if self.preview_running:

            self.preview_running = False

            self.play_btn.configure(

                text="▶ PLAY"
            )

            beep(
                "click"
            )

            return

        if (

            self.preview_cap is None

            or

            not self.preview_cap.isOpened()
        ):

            self.preview_cap = cv2.VideoCapture(

                self.input_path
            )

        self.preview_running = True

        self.play_btn.configure(

            text="❚❚ PAUSE"
        )

        self.preview_token += 1

        self.preview_tick(

            self.preview_token
        )

        beep(
            "click"
        )

    # ========================================================
    # STOP PREVIEW
    # ========================================================

    def stop_preview(self):

        self.preview_running = False

        self.preview_token += 1

        if self.preview_job is not None:

            try:

                self.after_cancel(
                    self.preview_job
                )

            except Exception:
                pass

            self.preview_job = None

        if self.preview_cap is not None:

            try:

                self.preview_cap.release()

            except Exception:
                pass

            self.preview_cap = None

        if hasattr(
            self,
            "play_btn"
        ):

            self.play_btn.configure(

                text="▶ PLAY"
            )

    # ========================================================
    # PREVIEW LOOP
    # ========================================================

    def preview_tick(
        self,
        token
    ):

        if (

            not self.preview_running

            or

            token != self.preview_token
        ):

            return

        cap = self.preview_cap

        if (

            cap is None

            or

            not cap.isOpened()
        ):

            return

        ok, frame = cap.read()

        if not ok:

            cap.set(

                cv2.CAP_PROP_POS_FRAMES,

                0
            )

            ok, frame = cap.read()

            if not ok:

                self.stop_preview()

                return

        # IMPORTANT:
        # Resize first to prevent 4K preview lag.

        small = self.resize_for_preview(
            frame
        )

        enhanced = enhance(

            small,

            saturation=float(
                self.saturation.get()
            ),

            contrast=float(
                self.contrast.get()
            ),

            sharpen=float(
                self.sharpen.get()
            ),

            denoise=float(
                self.denoise.get()
            )
        )

        self.show_frame(

            self.before_label,

            small,

            True
        )

        self.show_frame(

            self.after_label,

            enhanced,

            False
        )

        # Maximum preview rate: 30 FPS.

        delay = max(

            20,

            int(

                1000 /

                min(

                    max(
                        self.src_fps,
                        1
                    ),

                    30
                )
            )
        )

        self.preview_job = self.after(

            delay,

            lambda:
                self.preview_tick(
                    token
                )
        )

    # ========================================================
    # SHOW FRAME
    # ========================================================

    def show_frame(
        self,
        label,
        frame,
        before
    ):

        rgb = cv2.cvtColor(

            frame,

            cv2.COLOR_BGR2RGB
        )

        max_w = max(

            240,

            label.winfo_width() - 20
        )

        max_h = max(

            140,

            label.winfo_height() - 20
        )

        h, w = rgb.shape[:2]

        scale = min(

            max_w / max(
                w,
                1
            ),

            max_h / max(
                h,
                1
            ),

            1.0
        )

        new_w = max(

            2,

            int(
                w * scale
            )
        )

        new_h = max(

            2,

            int(
                h * scale
            )
        )

        img = Image.fromarray(
            rgb
        )

        # FIX (Pillow compatibility): Image.Resampling was added in
        # Pillow 9.1. Fall back to the older top-level constant on
        # earlier versions so this doesn't crash with AttributeError.
        resample_filter = getattr(
            getattr(Image, "Resampling", None),
            "BILINEAR",
            getattr(Image, "BILINEAR", 2)
        )

        if (

            new_w,
            new_h

        ) != img.size:

            img = img.resize(

                (
                    new_w,
                    new_h
                ),

                resample_filter
            )

        ctk_img = ctk.CTkImage(

            light_image=img,

            dark_image=img,

            size=(
                new_w,
                new_h
            )
        )

        label.configure(

            image=ctk_img,

            text=""
        )

        if before:

            self.preview_before_image = ctk_img

        else:

            self.preview_after_image = ctk_img

    # ========================================================
    # TARGET FPS
    # ========================================================

    def get_target_fps(self):

        value = self.target_fps.get()

        if value == "Keep source":

            return self.src_fps

        return float(
            value.split()[0]
        )

    # ========================================================
    # CRF
    # ========================================================

    def get_crf(self):

        text = self.quality.get()

        for number in (
            16,
            18,
            21,
            24,
            28
        ):

            if str(number) in text:

                return number

        return 18

    # ========================================================
    # RESOLUTION
    # ========================================================

    def get_resolution(self):

        width = self.width

        height = self.height

        mode = self.resolution.get()

        if mode == "Original":

            return width, height

        if mode == "1080p":

            target_h = 1080

        elif mode == "720p":

            target_h = 720

        elif mode == "480p":

            target_h = 480

        elif mode == "75% of original":

            return (

                max(
                    2,
                    int(
                        width * 0.75
                    )
                ),

                max(
                    2,
                    int(
                        height * 0.75
                    )
                )
            )

        elif mode == "50% of original":

            return (

                max(
                    2,
                    int(
                        width * 0.50
                    )
                ),

                max(
                    2,
                    int(
                        height * 0.50
                    )
                )
            )

        else:

            return width, height

        # Never upscale.

        if height <= target_h:

            return width, height

        ratio = (

            target_h /

            max(
                height,
                1
            )
        )

        return (

            max(
                2,
                int(
                    width * ratio
                )
            ),

            target_h
        )

    # ========================================================
    # LANGUAGE
    # ========================================================

    def change_language(self, language):
        if language not in ("English", "العربية"):
            language = "English"

        self.language = language

        if language == "العربية":
            self._apply_arabic()
        else:
            self._apply_english()

    def _apply_english(self):
        self.language_menu.set("English")
        self.title_label.configure(text="120tik")
        self.subtitle_label.configure(
            text=(
                "VIDEO ENHANCER  •  "
                "OPTICAL-FLOW INTERPOLATION  •  "
                "MOTION  •  EXPORT"
            )
        )
        self.btn_select.configure(text="OPEN VIDEO")
        self.smart_compress_btn.configure(text="SMART COMPRESS")
        self.before_title_label.configure(text="ORIGINAL")
        self.after_title_label.configure(text="120TIK ENHANCED")
        if not self.input_path:
            self.before_label.configure(text="Open a video to preview")
            self.after_label.configure(text="Open a video to preview")
        self.play_btn.configure(
            text="❚❚ PAUSE" if self.preview_running else "▶ PLAY"
        )
        self.stop_btn.configure(text="■ STOP")
        self.export_btn.configure(
            text=(
                "EXPORTING..."
                if self.export_process is not None
                else "EXPORT VIDEO"
            )
        )
        self.cancel_btn.configure(text="CANCEL")
        self.status_badge.configure(
            text=(
                "● FFMPEG READY"
                if self.ffmpeg
                else "● FFMPEG NOT FOUND"
            )
        )

    def _apply_arabic(self):
        self.language_menu.set("العربية")
        self.title_label.configure(text="120tik")
        self.subtitle_label.configure(
            text=(
                "تحسين الفيديو  •  زيادة الإطارات  •  "
                "الحركة  •  التصدير"
            )
        )
        self.btn_select.configure(text="فتح الفيديو")
        self.smart_compress_btn.configure(
            text="تقليل مساحة الفيديو"
        )
        self.before_title_label.configure(text="الأصلي")
        self.after_title_label.configure(text="بعد التحسين")
        if not self.input_path:
            self.before_label.configure(
                text="افتح فيديو لعرض المعاينة"
            )
            self.after_label.configure(
                text="افتح فيديو لعرض المعاينة"
            )
        self.play_btn.configure(
            text=(
                "❚❚ إيقاف مؤقت"
                if self.preview_running
                else "▶ تشغيل"
            )
        )
        self.stop_btn.configure(text="■ إيقاف")
        self.export_btn.configure(
            text=(
                "جارٍ التصدير..."
                if self.export_process is not None
                else "تصدير الفيديو"
            )
        )
        self.cancel_btn.configure(text="إلغاء")
        self.status_badge.configure(
            text=(
                "● FFmpeg جاهز"
                if self.ffmpeg
                else "● FFmpeg غير موجود"
            )
        )

    # ========================================================
    # SMART COMPRESSION
    # ========================================================

    def _input_has_audio(self):
        return True

    def _fit_resolution(
        self,
        width,
        height,
        max_width,
        max_height
    ):
        width = max(2, int(width))
        height = max(2, int(height))

        scale = min(
            max_width / width,
            max_height / height,
            1.0
        )

        new_width = max(2, int(width * scale))
        new_height = max(2, int(height * scale))

        new_width -= new_width % 2
        new_height -= new_height % 2

        return (
            max(2, new_width),
            max(2, new_height)
        )

    def _smart_resolution(self, size_mb):
        width = max(2, self.width)
        height = max(2, self.height)

        if height <= 1080:
            return self._fit_resolution(
                width, height, width, height
            )

        if height > 2160 and size_mb >= 1200:
            return self._fit_resolution(
                width, height, 1920, 1080
            )

        if height > 1440 and size_mb >= 700:
            return self._fit_resolution(
                width, height, 2560, 1440
            )

        if height > 1080 and size_mb >= 450:
            return self._fit_resolution(
                width, height, 1920, 1080
            )

        return self._fit_resolution(
            width, height, width, height
        )

    def _smart_compression_profile(self):
        input_size = os.path.getsize(self.input_path)
        size_mb = input_size / (1024 * 1024)
        duration = max(float(self.duration), 0.5)

        if size_mb < 80:
            ratio = 0.82
        elif size_mb < 300:
            ratio = 0.75
        elif size_mb < 1000:
            ratio = 0.68
        elif size_mb < 2500:
            ratio = 0.60
        else:
            ratio = 0.52

        current_total_kbps = (
            input_size * 8 / duration / 1000.0
        )

        if current_total_kbps < 900:
            ratio = max(ratio, 0.90)
        elif current_total_kbps < 1500:
            ratio = max(ratio, 0.82)

        audio_kbps = 128 if self._input_has_audio() else 0

        desired_total_kbps = max(
            300.0,
            current_total_kbps * ratio
        )

        target_w, target_h = self._smart_resolution(
            size_mb
        )

        pixels = max(
            1,
            target_w * target_h
        )

        if pixels >= 8294400:
            minimum_video_kbps = 8000
        elif pixels >= 3686400:
            minimum_video_kbps = 4500
        elif pixels >= 2073600:
            minimum_video_kbps = 2800
        elif pixels >= 921600:
            minimum_video_kbps = 1400
        else:
            minimum_video_kbps = 700

        video_kbps = (
            desired_total_kbps
            -
            audio_kbps
        )

        video_kbps = min(
            video_kbps,
            max(
                500.0,
                current_total_kbps - audio_kbps
            )
        )

        if video_kbps < minimum_video_kbps:
            if target_h > 1080:
                target_w, target_h = self._fit_resolution(
                    self.width,
                    self.height,
                    1920,
                    1080
                )
            elif target_h > 720:
                target_w, target_h = self._fit_resolution(
                    self.width,
                    self.height,
                    1280,
                    720
                )

            pixels = max(
                1,
                target_w * target_h
            )

            if pixels >= 2073600:
                minimum_video_kbps = 2800
            elif pixels >= 921600:
                minimum_video_kbps = 1400
            else:
                minimum_video_kbps = 700

            video_kbps = max(
                video_kbps,
                minimum_video_kbps
            )

        return {
            "ratio": ratio,
            "target_size_mb": size_mb * ratio,
            "video_kbps": int(
                round(
                    clamp(
                        video_kbps,
                        500,
                        50000
                    )
                )
            ),
            "audio_kbps": audio_kbps,
            "resolution": (
                target_w,
                target_h
            )
        }

    def start_smart_compress(self):
        if (
            self.smart_compression_running
            or self.export_process is not None
        ):
            messagebox.showinfo(
                "120tik",
                (
                    "هناك عملية تصدير تعمل بالفعل."
                    if self.language == "العربية"
                    else "An export is already running."
                )
            )
            beep("error")
            return

        if self.ffmpeg_downloading:
            messagebox.showinfo(
                "120tik",
                (
                    "انتظر حتى يكتمل تثبيت FFmpeg."
                    if self.language == "العربية"
                    else "Please wait until FFmpeg finishes installing."
                )
            )
            return

        if not self.ffmpeg:
            self.auto_install_ffmpeg()
            return

        if not self.input_path:
            messagebox.showwarning(
                "120tik",
                (
                    "افتح فيديو أولاً."
                    if self.language == "العربية"
                    else "Open a video first."
                )
            )
            beep("error")
            return

        output = filedialog.asksaveasfilename(
            title=(
                "حفظ الفيديو المضغوط"
                if self.language == "العربية"
                else "Save compressed video"
            ),
            defaultextension=".mp4",
            filetypes=[("MP4 video", "*.mp4")]
        )

        if not output:
            return

        if os.path.abspath(output) == os.path.abspath(
            self.input_path
        ):
            messagebox.showerror(
                "120tik",
                (
                    "اختر ملف إخراج مختلفًا عن الفيديو الأصلي."
                    if self.language == "العربية"
                    else "Choose a different output file from the source."
                )
            )
            return

        try:
            profile = self._smart_compression_profile()
        except Exception as exc:
            messagebox.showerror(
                "120tik",
                str(exc)
            )
            return

        self.stop_preview()
        self.export_cancelled = False
        self.smart_compression_running = True

        self.export_btn.configure(
            state="disabled"
        )

        self.smart_compress_btn.configure(
            state="disabled",
            text=(
                "جارٍ الضغط..."
                if self.language == "العربية"
                else "COMPRESSING..."
            )
        )

        self.cancel_btn.configure(
            state="normal"
        )

        self.progress.set(0)

        self.status.configure(
            text=(
                (
                    f"ضغط ذكي • الهدف ≈ "
                    f"{profile['target_size_mb']:.1f} MB • "
                    f"{profile['video_kbps']} kbps"
                )
                if self.language == "العربية"
                else (
                    f"Smart compression • target ≈ "
                    f"{profile['target_size_mb']:.1f} MB • "
                    f"{profile['video_kbps']} kbps"
                )
            ),
            text_color=GOLD
        )

        settings = {
            "video_kbps": profile["video_kbps"],
            "audio_kbps": profile["audio_kbps"],
            "resolution": profile["resolution"]
        }

        threading.Thread(
            target=self.smart_compress_worker,
            args=(
                output,
                settings
            ),
            daemon=True
        ).start()

    def _run_ffmpeg_progress(
        self,
        cmd,
        duration,
        offset,
        span
    ):
        creationflags = (
            subprocess.CREATE_NO_WINDOW
            if os.name == "nt"
            else 0
        )

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            universal_newlines=True,
            creationflags=creationflags
        )

        self.export_process = process

        if process.stdout is not None:
            for line in process.stdout:
                if self.export_cancelled:
                    break

                line = line.strip()

                if not line.startswith(
                    "out_time_us="
                ):
                    continue

                value = line.split(
                    "=",
                    1
                )[1]

                if not value.isdigit():
                    continue

                seconds = (
                    int(value)
                    /
                    1_000_000
                )

                progress_value = clamp(
                    seconds / max(
                        duration,
                        0.1
                    ),
                    0,
                    1
                )

                overall = (
                    offset
                    +
                    progress_value * span
                )

                self.after(
                    0,
                    lambda p=overall:
                        self.progress.set(p)
                )

        return_code = process.wait()
        self.export_process = None

        return return_code

    def _cleanup_passlog(self, base_path):
        directory = os.path.dirname(base_path)
        prefix = os.path.basename(base_path)

        try:
            for filename in os.listdir(directory):
                if filename.startswith(prefix):
                    path = os.path.join(
                        directory,
                        filename
                    )

                    try:
                        os.remove(path)
                    except Exception:
                        pass
        except Exception:
            pass

    def smart_compress_worker(
        self,
        output,
        settings
    ):
        pass_file = tempfile.NamedTemporaryFile(
            prefix="120tik_",
            suffix="_pass",
            delete=False
        )
        pass_file.close()

        try:
            target_w, target_h = settings[
                "resolution"
            ]

            vf = (
                f"scale={target_w}:{target_h}:"
                "force_original_aspect_ratio=decrease,"
                "pad=ceil(iw/2)*2:ceil(ih/2)*2"
            )

            video_bitrate = (
                f"{int(settings['video_kbps'])}k"
            )

            audio_bitrate = (
                f"{int(settings['audio_kbps'])}k"
            )

            null_output = (
                "NUL"
                if os.name == "nt"
                else "/dev/null"
            )

            common = [
                self.ffmpeg,
                "-y",
                "-hide_banner",
                "-nostats",
                "-progress",
                "pipe:1",
                "-i",
                self.input_path,
                "-map",
                "0:v:0",
                "-vf",
                vf,
                "-c:v",
                "libx264",
                "-preset",
                "medium",
                "-b:v",
                video_bitrate,
                "-pix_fmt",
                "yuv420p",
                "-passlogfile",
                pass_file.name
            ]

            pass1 = common + [
                "-an",
                "-pass",
                "1",
                "-f",
                "null",
                null_output
            ]

            duration = max(
                0.1,
                self.duration
            )

            self.after(
                0,
                lambda:
                    self.status.configure(
                        text=(
                            "جارٍ تحليل وضغط الفيديو • المرحلة 1/2"
                            if self.language == "العربية"
                            else "Analysing and compressing • pass 1/2"
                        ),
                        text_color=GOLD
                    )
            )

            return_code = self._run_ffmpeg_progress(
                pass1,
                duration,
                0.0,
                0.45
            )

            if self.export_cancelled:
                return

            if return_code != 0:
                raise RuntimeError(
                    "FFmpeg smart compression pass 1 failed."
                )

            pass2 = common + [
                "-pass",
                "2",
                "-map",
                "0:a?",
                "-c:a",
                "aac",
                "-b:a",
                audio_bitrate,
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                output
            ]

            self.after(
                0,
                lambda:
                    self.status.configure(
                        text=(
                            "جارٍ إنشاء الفيديو المضغوط • المرحلة 2/2"
                            if self.language == "العربية"
                            else "Creating compressed video • pass 2/2"
                        ),
                        text_color=GOLD
                    )
            )

            return_code = self._run_ffmpeg_progress(
                pass2,
                duration,
                0.45,
                0.55
            )

            if self.export_cancelled:
                try:
                    if os.path.exists(output):
                        os.remove(output)
                except Exception:
                    pass
                return

            if return_code != 0:
                raise RuntimeError(
                    "FFmpeg smart compression pass 2 failed."
                )

            if not os.path.isfile(output):
                raise RuntimeError(
                    "The compressed output file was not created."
                )

            input_bytes = os.path.getsize(
                self.input_path
            )

            output_bytes = os.path.getsize(
                output
            )

            saved_bytes = max(
                0,
                input_bytes - output_bytes
            )

            saved_percent = (
                saved_bytes
                /
                max(
                    input_bytes,
                    1
                )
            ) * 100.0

            if output_bytes >= input_bytes:
                result_text = (
                    (
                        "تم إنشاء الفيديو، لكن الحجم لم ينخفض.\n\n"
                        f"الأصلي: {input_bytes/(1024*1024):.1f} MB\n"
                        f"الجديد: {output_bytes/(1024*1024):.1f} MB\n\n"
                        "جرّب ضغطًا أقوى أو دقة أقل."
                    )
                    if self.language == "العربية"
                    else (
                        "The video was created, but the output is not smaller.\n\n"
                        f"Original: {input_bytes/(1024*1024):.1f} MB\n"
                        f"Output: {output_bytes/(1024*1024):.1f} MB\n\n"
                        "Try stronger compression or a lower resolution."
                    )
                )
            else:
                result_text = (
                    (
                        "اكتمل تقليل مساحة الفيديو بنجاح.\n\n"
                        f"الحجم الأصلي: {input_bytes/(1024*1024):.1f} MB\n"
                        f"الحجم الجديد: {output_bytes/(1024*1024):.1f} MB\n"
                        f"التوفير: {saved_percent:.1f}%\n\n"
                        f"{output}"
                    )
                    if self.language == "العربية"
                    else (
                        "Smart compression completed successfully.\n\n"
                        f"Original: {input_bytes/(1024*1024):.1f} MB\n"
                        f"Output: {output_bytes/(1024*1024):.1f} MB\n"
                        f"Saved: {saved_percent:.1f}%\n\n"
                        f"{output}"
                    )
                )

            self.after(
                0,
                lambda:
                    self.progress.set(1)
            )

            self.after(
                0,
                lambda:
                    self.status.configure(
                        text=(
                            f"تم • توفير {saved_percent:.1f}%"
                            if self.language == "العربية"
                            else f"Complete • saved {saved_percent:.1f}%"
                        ),
                        text_color=GOOD
                    )
            )

            self.after(
                0,
                lambda text=result_text:
                    messagebox.showinfo(
                        "120tik",
                        text
                    )
            )

            self.after(
                0,
                lambda:
                    beep("success")
            )

        except Exception as exc:
            if not self.export_cancelled:
                error_text = str(exc)

                self.after(
                    0,
                    lambda:
                        self.status.configure(
                            text=(
                                "فشل الضغط الذكي"
                                if self.language == "العربية"
                                else "Smart compression failed"
                            ),
                            text_color=BAD
                        )
                )

                self.after(
                    0,
                    lambda:
                        beep("error")
                )

                self.after(
                    0,
                    lambda msg=error_text:
                        messagebox.showerror(
                            "120tik",
                            msg
                        )
                )

        finally:
            self.export_process = None
            self.smart_compression_running = False

            self._cleanup_passlog(
                pass_file.name
            )

            self.after(
                0,
                lambda:
                    self.smart_compress_btn.configure(
                        state="normal",
                        text=(
                            "تقليل مساحة الفيديو"
                            if self.language == "العربية"
                            else "SMART COMPRESS"
                        )
                    )
            )

            self.after(
                0,
                lambda:
                    self.export_btn.configure(
                        state="normal",
                        text=(
                            "تصدير الفيديو"
                            if self.language == "العربية"
                            else "EXPORT VIDEO"
                        )
                    )
            )

            self.after(
                0,
                lambda:
                    self.cancel_btn.configure(
                        state="disabled"
                    )
            )

    # ========================================================
    # START EXPORT
    # ========================================================

    def start_export(self):

        if self.smart_compression_running:
            messagebox.showinfo(
                "120tik",
                (
                    "هناك عملية ضغط ذكي تعمل بالفعل."
                    if self.language == "العربية"
                    else "Smart compression is already running."
                )
            )
            return

        if self.ffmpeg_downloading:

            messagebox.showinfo(

                "120tik",

                "FFmpeg is still downloading. "
                "Please wait."
            )

            return

        if not self.ffmpeg:

            self.auto_install_ffmpeg()

            return

        if not self.input_path:

            messagebox.showwarning(

                "No video",

                "Open a video first."
            )

            beep(
                "error"
            )

            return

        output = filedialog.asksaveasfilename(

            title=(
                "تصدير الفيديو"
                if self.language == "العربية"
                else "Export video"
            ),

            defaultextension=".mp4",

            filetypes=[
                (
                    "MP4 video",
                    "*.mp4"
                )
            ]
        )

        if not output:

            return

        self.stop_preview()

        self.export_cancelled = False

        self.export_btn.configure(

            state="disabled",

            text=(
                "جارٍ التصدير..."
                if self.language == "العربية"
                else "EXPORTING..."
            )
        )

        self.cancel_btn.configure(

            state="normal"
        )

        self.progress.set(
            0
        )

        self.status.configure(

            text=(
                "جارٍ تجهيز التصدير..."
                if self.language == "العربية"
                else "Preparing export..."
            ),

            text_color=GOLD
        )

        settings = {

            "fps":
                self.get_target_fps(),

            "crf":
                self.get_crf(),

            "resolution":
                self.get_resolution(),

            "codec":
                self.codec.get(),

            "interpolate":
                bool(
                    self.var_interpolate.get()
                ),

            "audio":
                bool(
                    self.var_audio.get()
                ),

            "faststart":
                bool(
                    self.var_faststart.get()
                ),

            "keep_aspect":
                bool(
                    self.var_keep_aspect.get()
                ),

            "saturation":
                float(
                    self.saturation.get()
                ),

            "contrast":
                float(
                    self.contrast.get()
                ),

            "sharpen":
                float(
                    self.sharpen.get()
                ),

            "denoise":
                float(
                    self.denoise.get()
                ),
            "motion_blur":
                bool(
                    self.var_motion_blur.get()
                ),
            "motion_blur_strength":
                float(
                    self.motion_blur_strength_slider.get()
                ),
            "scene_detection":
                bool(
                    self.var_scene_detection.get()
                ),
            "scene_threshold":
                float(
                    self.scene_threshold_slider.get()
                ),
            "deblock":
                bool(
                    self.var_deblock.get()
                ),
            "detail":
                bool(
                    self.var_detail.get()
                ),
            "interpolation_mode":
                self.interpolation_mode.get(),
            "processing_profile":
                self.processing_profile.get()
        }

        threading.Thread(

            target=self.export_worker,

            args=(
                output,
                settings
            ),

            daemon=True

        ).start()

    # ========================================================
    # CANCEL
    # ========================================================

    def cancel_export(self):

        self.export_cancelled = True

        process = self.export_process

        if process is not None:

            try:

                process.terminate()

            except Exception:
                pass

        self.status.configure(

            text="Cancelling...",

            text_color=WARN
        )

        beep(
            "click"
        )

    # ========================================================
    # EXPORT
    # ========================================================

    def export_worker(
        self,
        output,
        settings
    ):

        try:

            target_fps = settings[
                "fps"
            ]

            target_w, target_h = (
                settings["resolution"]
            )

            # ------------------------------------------------
            # CODEC
            # ------------------------------------------------

            if "H.265" in settings[
                "codec"
            ]:

                vcodec = "libx265"

            else:

                vcodec = "libx264"

            # ------------------------------------------------
            # FILTERS
            # ------------------------------------------------

            filters = []

            profile = settings.get("processing_profile", "Cinematic")

            # Profiles tune the existing FFmpeg pipeline; they do not
            # pretend to be a neural AI model.
            if profile == "Ultra Smooth":
                settings["interpolate"] = True
            elif profile == "Clean Detail":
                settings["denoise"] = max(settings.get("denoise", 0.0), 0.18)
                settings["detail"] = True
            elif profile == "Fast Export":
                settings["motion_blur"] = False
                settings["deblock"] = False

            # ------------------------------------------------
            # INTERPOLATION
            # ------------------------------------------------

            if (
                settings["interpolate"]
                and target_fps > self.src_fps + 0.05
            ):

                mode = settings.get("interpolation_mode", "MCI — Quality")

                if mode == "Blend fallback":
                    filters.append(
                        f"minterpolate=fps={target_fps}:"
                        "mi_mode=blend"
                    )
                else:
                    if mode == "MCI — Fast":
                        mc_mode = "obmc"
                        me_mode = "bilat"
                    elif mode == "MCI — Balanced":
                        mc_mode = "aobmc"
                        me_mode = "bilat"
                    else:
                        mc_mode = "aobmc"
                        me_mode = "bidir"

                    interpolation_filter = (
                        f"minterpolate=fps={target_fps}:"
                        "mi_mode=mci:"
                        f"mc_mode={mc_mode}:"
                        f"me_mode={me_mode}:"
                        "vsbmc=1"
                    )

                    if settings.get("scene_detection", True):
                        interpolation_filter += (
                            ":scd=fdiff:"
                            f"scd_threshold={clamp(settings.get('scene_threshold', 10.0), 2.0, 25.0):.2f}"
                        )

                    filters.append(interpolation_filter)

            elif abs(

                target_fps -
                self.src_fps

            ) > 0.01:

                filters.append(

                    f"fps={target_fps}"
                )

            # ------------------------------------------------
            # EQ
            # ------------------------------------------------

            eq = []

            if abs(

                settings["contrast"]
                - 1.0

            ) > 0.005:

                eq.append(

                    f"contrast="
                    f"{settings['contrast']:.3f}"
                )

            if abs(

                settings["saturation"]
                - 1.0

            ) > 0.005:

                eq.append(

                    f"saturation="
                    f"{settings['saturation']:.3f}"
                )

            if eq:

                filters.append(

                    "eq=" +
                    ":".join(eq)
                )

            # ------------------------------------------------
            # SHARPEN
            # ------------------------------------------------

            if settings[
                "sharpen"
            ] > 0.01:

                amount = clamp(

                    settings[
                        "sharpen"
                    ] * 1.5,

                    0.05,

                    1.2
                )

                filters.append(

                    f"unsharp="
                    f"5:5:{amount:.2f}:"
                    f"5:5:0"
                )

            # ------------------------------------------------
            # DENOISE
            # ------------------------------------------------

            if settings[
                "denoise"
            ] > 0.01:

                d = clamp(

                    settings[
                        "denoise"
                    ],

                    0.0,

                    1.0
                )

                strength = (
                    1.0 +
                    d * 5.0
                )

                filters.append(

                    f"hqdn3d="
                    f"{strength:.2f}:"
                    f"{strength:.2f}:"
                    f"{strength:.2f}:"
                    f"{strength:.2f}"
                )

            # ------------------------------------------------
            # ADVANCED CLEANUP
            # ------------------------------------------------

            if settings.get("deblock", False):
                filters.append("deblock=filter=strong:block=8")

            if settings.get("detail", False):
                filters.append("unsharp=5:5:0.35:5:5:0")

            # ------------------------------------------------
            # MOTION BLUR
            # ------------------------------------------------
            # Motion blur itself does NOT create extra FPS.
            # Interpolation creates the extra frames; this optional
            # pass blends them for a more natural cinematic result.
            if settings.get("motion_blur", False):
                strength = clamp(
                    float(settings.get("motion_blur_strength", 0.35)),
                    0.0,
                    1.0
                )

                if strength > 0.01:
                    filters.append(
                        "tblend=all_mode=average:"
                        f"all_opacity={0.20 + strength * 0.55:.3f}"
                    )

            # ------------------------------------------------
            # SCALE
            # ------------------------------------------------

            if (

                target_w != self.width

                or

                target_h != self.height
            ):

                if settings[
                    "keep_aspect"
                ]:

                    filters.append(

                        f"scale="
                        f"{max(2, target_w)}:"
                        f"{max(2, target_h)}:"
                        "force_original_aspect_ratio=decrease"
                    )

                    filters.append(

                        "pad="
                        "ceil(iw/2)*2:"
                        "ceil(ih/2)*2"
                    )

                else:

                    filters.append(

                        f"scale="
                        f"{max(2, target_w)}:"
                        f"{max(2, target_h)}"
                    )

            vf = (

                ",".join(
                    filters
                )

                if filters

                else

                "null"
            )

            # =================================================
            # FFMPEG COMMAND
            # =================================================

            cmd = [

                self.ffmpeg,

                "-y",

                "-hide_banner",

                "-nostats",

                "-progress",

                "pipe:1",

                "-i",

                self.input_path,

                "-map",

                "0:v:0"
            ]

            if settings[
                "audio"
            ]:

                cmd += [

                    "-map",
                    "0:a?"
                ]

            cmd += [

                "-vf",

                vf,

                "-r",

                f"{target_fps:.6f}",

                "-c:v",

                vcodec,

                "-preset",

                "fast",

                "-crf",

                str(
                    settings[
                        "crf"
                    ]
                ),

                "-pix_fmt",

                "yuv420p"
            ]

            if settings[
                "audio"
            ]:

                cmd += [

                    "-c:a",
                    "aac",

                    "-b:a",
                    "192k",

                    "-ar",
                    "48000"
                ]

            else:

                cmd += [
                    "-an"
                ]

            if settings[
                "faststart"
            ]:

                cmd += [

                    "-movflags",
                    "+faststart"
                ]

            cmd += [
                output
            ]

            # =================================================
            # PROCESS
            # =================================================

            creationflags = (

                subprocess.CREATE_NO_WINDOW

                if os.name == "nt"

                else

                0
            )

            self.after(

                0,

                lambda:
                    self.status.configure(

                        text="Exporting...",

                        text_color=GOLD
                    )
            )

            self.export_process = (
                subprocess.Popen(

                    cmd,

                    stdout=subprocess.PIPE,

                    stderr=subprocess.STDOUT,

                    text=True,

                    universal_newlines=True,

                    creationflags=creationflags
                )
            )

            duration = max(

                0.1,

                self.duration
            )

            # =================================================
            # PROGRESS
            # =================================================

            for line in (
                self.export_process.stdout
            ):

                if self.export_cancelled:

                    break

                line = line.strip()

                if line.startswith(
                    "out_time_us="
                ):

                    try:

                        value = (
                            line.split(
                                "=",
                                1
                            )[1]
                        )

                        if value.isdigit():

                            seconds = (

                                int(
                                    value
                                )

                                /

                                1_000_000
                            )

                            progress_value = clamp(

                                seconds /
                                duration,

                                0,

                                0.99
                            )

                            self.after(

                                0,

                                lambda p=progress_value:
                                    self.progress.set(p)
                            )

                    except Exception:
                        pass

            return_code = (
                self.export_process.wait()
            )

            self.export_process = None

            # =================================================
            # CANCELLED
            # =================================================

            if self.export_cancelled:

                try:

                    if os.path.exists(
                        output
                    ):

                        os.remove(
                            output
                        )

                except Exception:
                    pass

                self.after(

                    0,

                    lambda:
                        self.status.configure(

                            text="Export cancelled",

                            text_color=WARN
                        )
                )

                return

            # =================================================
            # ERROR
            # =================================================

            if return_code != 0:

                raise RuntimeError(

                    "FFmpeg export failed.\n\n"
                    "The video could not be exported."
                )

            # =================================================
            # SUCCESS
            # =================================================

            self.after(

                0,

                lambda:
                    self.progress.set(1)
            )

            self.after(

                0,

                lambda:
                    self.status.configure(

                        text="Export complete",

                        text_color=GOOD
                    )
            )

            self.after(

                0,

                lambda:
                    beep("success")
            )

            info_text = (

                "Video exported successfully.\n\n"

                f"FPS: {target_fps:g}\n"

                f"Resolution: "
                f"{target_w}×{target_h}\n"

                f"CRF: "
                f"{settings['crf']}\n"
                f"Interpolation: "
                f"{'ON' if settings.get('interpolate') else 'OFF'}\n"
                f"Motion blur: "
                f"{'ON' if settings.get('motion_blur') else 'OFF'}\n\n"

                f"{output}"
            )

            self.after(

                0,

                lambda text=info_text:
                    messagebox.showinfo(

                        "120tik",

                        text
                    )
            )

        except Exception as exc:

            self.export_process = None

            if not self.export_cancelled:

                message = str(
                    exc
                )

                self.after(

                    0,

                    lambda:
                        self.status.configure(

                            text="Export failed",

                            text_color=BAD
                        )
                )

                self.after(

                    0,

                    lambda:
                        beep("error")
                )

                self.after(

                    0,

                    lambda msg=message:
                        messagebox.showerror(

                            "120tik export error",

                            msg
                        )
                )

        finally:

            self.after(

                0,

                lambda:
                    self.export_btn.configure(

                        state="normal",

                        text="EXPORT VIDEO"
                    )
            )

            self.after(

                0,

                lambda:
                    self.cancel_btn.configure(

                        state="disabled"
                    )
            )

    # ========================================================
    # CLOSE
    # ========================================================

    def on_close(self):

        self.stop_preview()

        if self.export_process is not None:

            try:

                self.export_process.terminate()

            except Exception:
                pass

        self.destroy()


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    app = VideoStudio()

    app.mainloop()