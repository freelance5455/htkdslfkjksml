# Visualizador 3D Android - Projeto inicial

Este projeto encapsula o HTML enviado em uma WebView Android e permite selecionar arquivos pelo seletor do sistema.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `Visualizador3D-Android` no Android Studio ou em uma IDE Android compatível.
3. Aguarde a sincronização do Gradle (é necessário internet para baixar o plugin Android).
4. Use **Build > Build APK(s)**.
5. O APK de depuração normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações importantes
- O HTML original carrega Three.js, Tailwind, Lucide e o decodificador Draco por CDNs externos. Assim, a primeira abertura e esses recursos dependem de internet.
- O arquivo HTML é incluído em `app/src/main/assets/index.html`.
- A seleção de arquivos usa o seletor Android. O código HTML original aceita GLB/GLTF.
- Este é um projeto inicial de empacotamento; não é um APK já compilado/assinado.
