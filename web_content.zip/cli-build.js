const path = require('path');
const fs = require('fs');
const { buildApk } = require('./server');

const [,, srcFile, appName, pkgId, outName] = process.argv;
if (!srcFile) {
    console.error('Usage: node cli-build.js <fichier.html|zip> <NomApp> <com.pkg.id> <sortie.apk>');
    process.exit(1);
}

const outDir = path.join(process.env.HOME, 'storage', 'downloads');
const outPath = fs.existsSync(outDir) ? path.join(outDir, outName || 'app-release.apk') : path.resolve(outName || 'app-release.apk');

const logs = buildApk({
    sourcePath: path.resolve(srcFile),
    originalName: path.basename(srcFile),
    iconPath: null,
    appName: appName || 'Mon App',
    packageId: pkgId || 'com.apkforge.app',
    outApkPath: outPath
});

logs.forEach(l => console.log('> ' + l));
console.log('SUCCÈS : ' + outPath);
