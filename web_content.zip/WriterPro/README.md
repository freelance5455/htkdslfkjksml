# WriterPro (Android)

A simple text editor that creates, opens and saves .txt files on your phone.

## Build the APK
1. Install Android Studio (Koala or newer).
2. File > Open, and choose this WriterPro folder. Wait for Gradle sync to finish
   (it downloads Gradle 8.7 and the Android libraries, so you need internet once).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk.
5. Copy it to your phone and open it. Allow "Install unknown apps" for your file manager or browser if asked.

Or, with a phone connected by USB debugging, press the green Run button.

## How files work
- New file: tap "+ New file", write, then tap Save. Android asks where to put the .txt the first time.
- After that, Save and Auto-save always update that same file with the same name.
- Open .txt: tap "Open .txt" and pick a file. Saving updates that same file.
- Delete removes the file from WriterPro only, after a final confirmation. The .txt on your phone stays.

## Change things
- The whole app screen is app/src/main/assets/index.html.
- Android file handling is app/src/main/java/com/writerpro/app/MainActivity.kt.
- App name: app/src/main/res/values/strings.xml. Package: com.writerpro.app.
