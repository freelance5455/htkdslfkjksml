package com.writerpro.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/** Pick a .txt file and keep read/write access so later saves go to the same file. */
class OpenTxt : ActivityResultContracts.OpenDocument() {
    override fun createIntent(context: Context, input: Array<String>): Intent =
        super.createIntent(context, input).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
}

/** Create a new .txt file in a folder the user chooses. */
class CreateTxt : ActivityResultContracts.CreateDocument("text/plain") {
    override fun createIntent(context: Context, input: String): Intent =
        super.createIntent(context, input).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
}

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var pendingCreate: Pair<String, String>? = null // document id to its text

    private val openLauncher = registerForActivityResult(OpenTxt()) { uri ->
        if (uri != null) {
            keepAccess(uri)
            try {
                val text = contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                js("window.onNativeOpen(${q(uri.toString())}, ${q(displayName(uri))}, ${q(text)})")
            } catch (e: Exception) {
                js("toast('Couldn\\u2019t open that file')")
            }
        }
    }

    private val createLauncher = registerForActivityResult(CreateTxt()) { uri ->
        val (id, text) = pendingCreate ?: return@registerForActivityResult
        pendingCreate = null
        if (uri == null) {
            js("window.onNativeCreated(${q(id)}, '', '', false)")
        } else {
            keepAccess(uri)
            val ok = writeText(uri, text)
            js("window.onNativeCreated(${q(id)}, ${q(uri.toString())}, ${q(displayName(uri))}, $ok)")
        }
    }

    /** Functions the web page can call as `Android.xxx(...)`. */
    inner class Bridge {
        @JavascriptInterface
        fun openFile() {
            runOnUiThread { openLauncher.launch(arrayOf("text/plain")) }
        }

        @JavascriptInterface
        fun createFile(id: String, name: String, text: String) {
            pendingCreate = id to text
            runOnUiThread { createLauncher.launch(name) }
        }

        @JavascriptInterface
        fun saveToUri(uri: String, text: String): Boolean = writeText(Uri.parse(uri), text)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true   // the app's own private file store
            allowFileAccess = false
            allowContentAccess = false
        }
        web.addJavascriptInterface(Bridge(), "Android")

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.onNativeBack && window.onNativeBack())") { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onPause() {
        js("window.onNativePause && window.onNativePause()")
        super.onPause()
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }
    private fun q(s: String) = JSONObject.quote(s)

    private fun keepAccess(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) { }
    }

    private fun writeText(uri: Uri, text: String): Boolean = try {
        contentResolver.openOutputStream(uri, "wt")
            ?.use { it.write(text.toByteArray(Charsets.UTF_8)) } != null
    } catch (e: Exception) { false }

    private fun displayName(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "Untitled.txt"
    } catch (e: Exception) { "Untitled.txt" }
}
