CG Pest Control - Mobile HTML / Offline Excel Import

هذه النسخة مخصصة للتحويل إلى APK بواسطة برنامج HTML to APK.

مهم:
- استيراد Excel موجود في صفحة العملاء فقط.
- قارئ XLSX مدمج داخل المشروع ولا يعتمد على الإنترنت أو CDN.
- يدعم XLSX وCSV محلياً.
- البيانات تبقى محلية داخل الجهاز مثل النسخة الأصلية.
- لا تحذف jszip.min.js أو local-xlsx.js؛ فهما جزء أساسي من استيراد Excel.

في برنامج HTML to APK اختر: ملف ZIP إلى APK.
