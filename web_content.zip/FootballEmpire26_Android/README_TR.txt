FOOTBALL EMPIRE 26 - ANDROID PROJESI

Bu klasör Android Studio ile APK oluşturmak için hazırlanmış kaynak projedir.
Oyun HTML dosyası uygulamanın içine eklenmiştir ve WebView içinde açılır.

APK oluşturma:
1. Android Studio'yu bilgisayarına kur.
2. Android Studio > Open ile bu klasörü seç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.
6. APK'yı Android telefonuna gönderip yükle. İlk kurulumda bilinmeyen uygulama yükleme izni isteyebilir.

Not:
- Bu proje derlenebilir bir başlangıç Android projesidir; burada APK derlemesi yapılmamıştır.
- Oyun şu an prototiptir. Gerçek kadro/veri servisi, gelişmiş maç motoru, çevrimiçi kayıt ve lisanslı kulüp armaları ayrıca entegre edilmelidir.
