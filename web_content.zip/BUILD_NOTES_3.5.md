# XGaming 3.5
- Fixed theme leakage caused by older global dark-theme CSS rules.
- Light and dark themes now override home chips, welcome area, cards, details, downloads, account, admin, notifications, reports, inputs, modal surfaces, and page backgrounds.
- X gaming remains visible in both themes.
- Swapped the left/right toolbar groups without changing the individual icons.
