-- Khajura School Management v8.9: Fix father/mother column schema-cache error
-- Safe to run more than once in Supabase SQL Editor.

ALTER TABLE public.students ADD COLUMN IF NOT EXISTS father text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS father_name text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS mother text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS mother_name text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS religion text NOT NULL DEFAULT '';

-- Keep both legacy column names (father/mother) and current app names
-- (father_name/mother_name) synchronized for compatibility.
CREATE OR REPLACE FUNCTION public.sync_student_parent_columns()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    NEW.father_name := COALESCE(NULLIF(NEW.father_name, ''), NEW.father, '');
    NEW.father := COALESCE(NULLIF(NEW.father, ''), NEW.father_name, '');
    NEW.mother_name := COALESCE(NULLIF(NEW.mother_name, ''), NEW.mother, '');
    NEW.mother := COALESCE(NULLIF(NEW.mother, ''), NEW.mother_name, '');
  ELSE
    IF NEW.father_name IS DISTINCT FROM OLD.father_name THEN
      NEW.father := NEW.father_name;
    ELSIF NEW.father IS DISTINCT FROM OLD.father THEN
      NEW.father_name := NEW.father;
    END IF;
    IF NEW.mother_name IS DISTINCT FROM OLD.mother_name THEN
      NEW.mother := NEW.mother_name;
    ELSIF NEW.mother IS DISTINCT FROM OLD.mother THEN
      NEW.mother_name := NEW.mother;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sync_student_parent_columns_trigger ON public.students;
CREATE TRIGGER sync_student_parent_columns_trigger
BEFORE INSERT OR UPDATE ON public.students
FOR EACH ROW EXECUTE FUNCTION public.sync_student_parent_columns();

-- Backfill both column-name variants from whichever one already has data.
UPDATE public.students
SET father_name = COALESCE(NULLIF(father_name, ''), father, ''),
    father = COALESCE(NULLIF(father, ''), father_name, ''),
    mother_name = COALESCE(NULLIF(mother_name, ''), mother, ''),
    mother = COALESCE(NULLIF(mother, ''), mother_name, '');

NOTIFY pgrst, 'reload schema';
