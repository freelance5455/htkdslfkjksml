# 4.000 WOCHEN Plus X – Android Projekt

Dieses Android-Studio-Projekt enthält die aktuelle Master-HTML als lokale App-Datei unter `app/src/main/assets/index.html`.

Wichtig: Die HTML-Datei wird **nicht über das Internet** geladen. Die MainActivity lädt sie lokal über `file:///android_asset/index.html`.

## Öffnen
1. Projektordner in Android Studio öffnen.
2. Gradle synchronisieren lassen.
3. Auf einem Android-Gerät oder Emulator starten.
4. Für ein APK: Build → Build APK(s).

Die App-ID lautet `de.wochen.plusx`.
