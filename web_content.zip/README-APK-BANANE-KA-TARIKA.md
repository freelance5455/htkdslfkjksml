# NEURA ko APK mein convert karne ka tarika

Aapke paas 2 asaan raaste hain. Dono mein aapka **neura-index.html** (asli app) waisa hi rahega — sirf usko ek "native shell" mein wrap kiya jaata hai.

---

## Raasta 1 — Android Studio + WebView (poora control, free)

1. **Android Studio** install karein (agar nahi hai): https://developer.android.com/studio
2. Naya project banayein: **File → New Project → Empty Views Activity**
   - Language: **Java** (isi wajah se MainActivity.java diya hai — Kotlin chahiye to bata dein, wo bhi bana dunga)
   - Package name kuch bhi rakhein, jaise `com.yourname.neura`
3. Jo package name aap ne diya, wahi `MainActivity.java` ki **pehli line** (`package ...`) mein daalein.
4. `app/src/main/java/<aapka-package-path>/MainActivity.java` file ko is repo ke `MainActivity.java` se replace kar dein.
5. `app/src/main/AndroidManifest.xml` ko is repo ke `AndroidManifest.xml` se replace/merge kar dein (package attribute apna rakhein).
6. `app/src/main/assets/` folder banayein (agar nahi hai) aur usme **neura-index.html** copy kar dein — file ka naam bilkul `neura-index.html` hi rakhein (MainActivity isi naam se load karta hai).
7. Top menu se **Build → Generate Signed Bundle / APK → APK** choose karein, naya keystore banayein (pehli baar), aur build kar lein.
8. Output APK yahan milega: `app/release/app-release.apk` (ya debug build ke liye `app/build/outputs/apk/debug/`).

Bas itna hi — poori app (chat, glass UI, theme, tabs) waisi ki waisi WebView ke andar chalegi.

---

## Raasta 2 — Bina Android Studio ke (online tools)

Agar Android Studio setup nahi karna chahte:

- **Median.co** (pehle GoNative.io) — HTML/website ko seedha APK mein convert karne ki service, free trial hai.
- **PWABuilder.com** — agar aap HTML file ko kahin online host kar dein (GitHub Pages jaisa free hosting), to PWABuilder us URL se APK bana sakta hai.
- **Capacitor (Ionic)** — agar aap developer hain aur command-line se comfortable hain:
  ```
  npm install @capacitor/core @capacitor/cli @capacitor/android
  npx cap init
  # neura-index.html ko www/index.html mein daalein
  npx cap add android
  npx cap open android
  ```
  Phir Android Studio khud khul jaayega aur waha se build kar sakte hain.

---

### Zaroori note
- Is file mein Google Fonts CDN se font load ho rahe the pehle designs mein; is premium version mein system font (`-apple-system`/Roboto) use kiya gaya hai, isliye **internet ke bina bhi** poori app offline chalegi — APK banane ke baad bhi.
- Agar aap chahte hain ki AI ke jawab sach mein kisi real model (jaise Claude API) se aayein na ki fixed rule-based reply se, to bataiye — uske liye ek chhota backend/API-key setup chahiye hoga, jo is offline-demo se alag cheez hai.
