Raat thi Divas Pro - મોબાઇલથી APK બનાવવાની રીત

આ ZIP માં APK બનાવવાની cloud workflow ઉમેરેલી છે. APK આ ZIP માં પહેલેથી તૈયાર નથી.

1) ZIP ને ફોનમાં Extract કરો.
2) https://github.com પર તમારું account બનાવો અથવા sign in કરો.
3) New repository બનાવો. નામ: raat-thi-divas-pro
4) Repository ને Public રાખો (સરળતાથી workflow ચલાવવા માટે) અને Create repository દબાવો.
5) Add file > Upload files પસંદ કરો.
6) Extract કરેલા project ના બધા files અને folders upload કરો. ખાસ કરીને .github/workflows/build-apk.yml ફાઇલ પણ હોવી જરૂરી છે.
   નોંધ: Android file manager માં hidden .github folder દેખાતો ન હોય તો file manager માં Show hidden files ચાલુ કરો.
7) Commit changes કરો અને થોડું રાહ જુઓ.
8) Repository માં Actions tab ખોલો. Build Raat thi Divas Pro APK workflow પસંદ કરો.
9) Build સફળ થાય એટલે workflow run ખોલો. નીચે Artifacts માં Raat-thi-Divas-Pro-APK દબાવી APK ZIP download કરો.
10) ZIP extract કરીને app-debug.apk ખોલો. Android પૂછે તો આ browser/file manager માટે Install unknown apps પરવાનગી આપો.

જો Actions tab બંધ હોય તો repository Settings > Actions > General માં Actions પરવાનગી ચાલુ કરો.

મહત્વપૂર્ણ:
- GitHub account જરૂરી છે. આ રીત માટે PC અથવા Android Studio જરૂરી નથી; build GitHub ના cloud computer પર થાય છે.
- APK debug/test APK છે; Play Store release માટે signed release build અલગથી કરવો પડે.
- મૂળ HTML app માં રહેલા AI model / FFmpeg CDN assets માટે internet જરૂરી હોઈ શકે છે. બધા video formats અને ભારે processing દરેક ફોનમાં ચાલે તેની ખાતરી નથી.
- APK install કર્યા પછી પહેલાં નાનો 720p MP4 video test કરવો.
