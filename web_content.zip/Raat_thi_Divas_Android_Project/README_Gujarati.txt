# Raat thi Divas Pro – Android / PWA package

આ પેકેજમાં તમારી મૂળ HTML એપ જાળવીને Android wrapper માટે Capacitor project તૈયાર કરેલો છે.
મૂળ player/editor JavaScriptમાં ફેરફાર કરેલો નથી; PWA manifest અને local shell service worker ઉમેર્યા છે.

## Android APK બનાવવાની રીત (Windows PC)

1. Node.js LTS અને Android Studio install કરો.
2. આ ZIP extract કરો.
3. આ folderમાં Terminal/Command Prompt ખોલો.
4. નીચેના commands ચલાવો:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

5. Android Studioમાં Gradle sync પૂરો થવા દો.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK સામાન્ય રીતે `android/app/build/outputs/apk/debug/app-debug.apk` માં મળશે.

## મોબાઇલમાં PWA તરીકે ચલાવવું

`www` folderને HTTPS hosting પર publish કરો. પછી Android Chromeમાં તેની site ખોલો અને
menuમાંથી "Install app" / "Add to Home screen" પસંદ કરો.

## મહત્વની મર્યાદા

- આ ZIP Android APK નથી; આ APK બનાવવા માટેનો source project છે. આ runtimeમાં Android SDK/Gradle ઉપલબ્ધ ન હોવાથી અહીંથી installable APK compile કરી શકાતી નથી.
- Appની AI Skin/Segmentation અને FFmpeg modulesમાં jsdelivr / Google Storage પરથી model તથા code load થાય છે. આ ફંક્શન પહેલી વાર અને કેટલીક processing વખતે internet માંગે છે.
- Video codec support Android System WebView પર આધારિત છે. MP4 (H.264 + AAC) સામાન્ય રીતે વધુ યોગ્ય છે.
- Video enhancement/export ભારે કામ છે; 720pથી શરૂઆત કરો. 2K/4K export દરેક ફોન પર smooth નહીં ચાલે.
- Browser/PWAમાં file save/share વર્તન Android અને browser પ્રમાણે બદલાઈ શકે છે. Capacitor APKમાં પણ દરેક video codecની ગેરંટી નથી.
- APK install કરતા પહેલાં Android Studioમાં app test કરો. Production release માટે signing જરૂરી છે.
