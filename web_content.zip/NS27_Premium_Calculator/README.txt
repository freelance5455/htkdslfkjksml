NS27 PREMIUM CALCULATOR

CONTENTS
- index.html: complete calculator app

HOW TO USE ON ANDROID
1. Extract this ZIP file using your phone's Files app.
2. Open the extracted folder.
3. Tap index.html and choose Chrome (or another browser).
4. The calculator works offline once the file is on your phone.

TO ADD IT TO YOUR HOME SCREEN
1. Open index.html in Chrome.
2. Open Chrome's three-dot menu.
3. Choose "Add to Home screen" if available.

NOTE
This is a browser-based calculator app, not an APK installer.
It performs basic arithmetic, percentage, sign change, clear and backspace.
