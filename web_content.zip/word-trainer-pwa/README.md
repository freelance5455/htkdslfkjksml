# Word Trainer — PTE (PWA)

Aplicativo web instalável para praticar spelling e vocabulário com palavras cadastradas pelo usuário.

## Recursos
- Cadastro de palavra, significado, erro cometido, definição e frase.
- Exercícios de digitação sem mostrar a resposta antes da tentativa.
- Modos: português → inglês, definição em inglês, frase com lacuna, áudio → escrita e palavras com erros.
- Pronúncia em inglês australiano via síntese de voz do navegador (depende do dispositivo).
- Registra acertos, erros, sequência e agenda revisões.
- Importação em lote com `palavra;significado;frase`.
- Exportação e importação de backup JSON.
- Interface responsiva e suporte a instalação como PWA.
- Dados ficam no armazenamento local do navegador; exporte um backup regularmente.

## Como testar no computador
Abra `index.html` no navegador. Para testar instalação/offline, sirva a pasta por HTTPS ou localhost, pois service workers não funcionam em `file://`.

## Como instalar no Android
Publique a pasta em um serviço HTTPS (por exemplo, GitHub Pages ou Netlify), abra a URL no Chrome e use o menu ⋮ → **Instalar app** ou **Adicionar à tela inicial**.

## Limitações da primeira versão
- Não sincroniza automaticamente entre dispositivos.
- Não importa diretamente o histórico do Google Tradutor.
- A pronúncia usa a voz disponível no aparelho/navegador; a voz `en-AU` pode não estar instalada.
- O modo de definição em inglês fica mais útil quando você preenche o campo de definição.
