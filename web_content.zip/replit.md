# Memo Assistant

مساعد ميمو هو مركز عمليات عربي لإدارة روبوتات الذكاء الاصطناعي وربطها بالمنصات الرسمية، مع اختبار الردود وقواعد الأتمتة وقاعدة معرفة وسجل نشاط وإعدادات وصلاحيات إدارة.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — تشغيل API Server
- `pnpm --filter @workspace/memo-assistant run dev` — تشغيل واجهة Memo Assistant
- `pnpm run typecheck` — فحص TypeScript لكل الحزم
- `pnpm --filter @workspace/memo-assistant run build` — بناء الواجهة للإنتاج
- `pnpm --filter @workspace/api-spec run codegen` — إعادة توليد hooks وZod من OpenAPI
- `pnpm --filter @workspace/db run push` — تطبيق مخطط PostgreSQL على قاعدة التطوير

## Stack

- pnpm workspaces، Node.js 24، TypeScript 5.9
- Frontend: React + Vite + Wouter + TanStack Query + Tailwind v4
- Backend: Express 5 + Pino + OpenAPI-generated Zod validation
- Database: PostgreSQL + Drizzle ORM
- Auth: Replit-managed Clerk with browser proxy support
- Contract: `lib/api-spec/openapi.yaml`

## Where things live

- `artifacts/memo-assistant/src/App.tsx` — تطبيق الواجهة ومساراتها وتجارب CRUD
- `artifacts/memo-assistant/src/index.css` — هوية Memo Assistant وأسلوب RTL
- `artifacts/api-server/src/routes/memo.ts` — مسارات البوتات والقواعد والمعرفة والمنصات والإعدادات
- `artifacts/api-server/src/routes/memo-data.ts` — بيانات العرض التجريبية وسجل النشاط
- `lib/db/src/schema/memo-assistant.ts` — مخطط PostgreSQL القابل للتوسعة
- `lib/api-spec/openapi.yaml` — المصدر الواحد لعقود الـAPI

## Architecture decisions

- كل منصة خارجية تتم عبر adapter رسمي منفصل مستقبلًا؛ لا توجد طرق scraping أو جلسات غير رسمية.
- الواجهة تتعامل مع API hooks المولدة من OpenAPI بدل نسخ أنواع أو عقود محلية.
- بيانات العرض الأولية معزولة في طبقة store حتى تظل الواجهة قابلة للعرض مباشرة، مع مخطط Drizzle جاهز للربط الدائم.
- المصادقة تستخدم Clerk المُدار من Replit؛ لا يتم تخزين كلمات المرور أو التوكنات في التطبيق.
- التطبيق عربي RTL افتراضيًا، مع إبقاء حقول اللغة والمنصة والنموذج قابلة للتوسع.

## Product

تشمل النسخة الحالية: صفحة ترحيب، تسجيل دخول/تسجيل، لوحة تحكم، CRUD للمساعدين، تشغيل وإيقاف وحذف، إعدادات الذكاء الاصطناعي، قواعد رد تلقائي، قاعدة معرفة، اختبار محادثة، سجل محادثات ونشاط، ربط المنصات الرسمية، إعدادات الحساب، ولوحة إدارة.

## Security notes

- استخدم Clerk للمستخدمين والجلسات، ولا تضف نظام كلمات مرور محليًا.
- اتصالات WhatsApp وInstagram وTelegram وMessenger وDiscord ممثلة عبر حالات اتصال رسمية ولا تتصل بأي endpoint غير رسمي.
- عند إضافة مفاتيح API للمنصات، خزّنها في Secrets أو Vault ولا ترسلها للواجهة.
- عند تفعيل الإنتاج، اربط كل سجل بمالك الحساب في Drizzle واستعمل middleware الصلاحيات قبل routes.