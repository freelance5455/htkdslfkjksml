# Bounce

Bounce is a dark, nightlife-first native Expo app for discovering community-powered events in Kingston, Jamaica. It shows exact JMD pricing, live crowd energy, directions, check-ins, and verified attendee reviews.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the Express API
- `pnpm --filter @workspace/bounce-app run dev` — run the Expo Go preview
- `pnpm run typecheck` — typecheck all workspace packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate typed React Query hooks and Zod schemas from the OpenAPI contract
- `pnpm --filter @workspace/db run push` — apply Drizzle schema changes to the development database
- `pnpm --filter @workspace/scripts run seed:bounce` — idempotently seed the initial Kingston event catalog
- `curl https://$REPLIT_DEV_DOMAIN/api/events` — inspect the public event feed during development
- `GET /api/downloads/bounce-app-source.zip` — download the source archive from the API server

The API requires `DATABASE_URL`. Clerk is provisioned through Replit-managed Clerk and uses the workspace Clerk environment variables; do not place credentials in source files.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Native client: Expo 54, Expo Router, React Native, React Query
- Authentication: Replit-managed Clerk with SecureStore token caching
- API: Express 5, Clerk bearer-token middleware, OpenAPI-generated client
- Database: PostgreSQL + Drizzle ORM
- Validation/client generation: Orval, Zod 3-compatible generated schemas
- Build: esbuild for the API and the existing static Expo Go deployment builder

## Where things live

- `artifacts/bounce-app/app/index.tsx` — complete native onboarding, authentication, discovery, detail, check-in, review, and suggestion flow
- `artifacts/bounce-app/app/_layout.tsx` — Clerk, React Query, and API bearer-token providers
- `artifacts/api-server/src/routes/bounce.ts` — public event feed and authenticated user actions
- `artifacts/api-server/src/middlewares/auth.ts` — Clerk identity to local user profile mapping
- `lib/db/src/schema/index.ts` — users, events, saves, check-ins, reviews, and suggestions
- `lib/api-spec/openapi.yaml` — source of truth for API operations and generated client types
- `scripts/src/seed-bounce.ts` — idempotent initial Kingston catalog seed

## Architecture decisions

- Event content is served from PostgreSQL; the mobile bundle contains no fallback event catalog or simulated user actions.
- Clerk user IDs are stored in a local users table so application data remains relational and user-specific.
- Native Expo requests use the Clerk session bearer token through the shared generated API client.
- Reviews require a persisted check-in and are limited to one review per user and event.
- The visual language stays aligned with the Bounce mockup: deep plum surfaces, neon accents, JMD totals, and large mobile-safe touch targets.

## Product

- Welcome and onboarding explain the Bounce promise.
- Email/password account creation includes email verification; sign-in and Google OAuth are supported through Clerk.
- Native foreground location permission is requested before discovery, with a Kingston fallback option.
- Events can be filtered by vibe, viewed as a list or map-style radar, opened for price breakdowns and crowd status, shared, and opened in maps.
- Signed-in users can save events, check in, publish verified reviews, and suggest new events for moderation.

## Gotchas

- Expo Go can preview this project, but a native APK/AAB still requires a cloud Android build environment; this workspace does not include Android SDK tooling.
- The API and Expo workflows must both be running for the mobile feed to load.
- Keep `lib/api-spec/openapi.yaml`, generated client output, and route response shapes in sync; rerun code generation after contract changes.
- The mockup-sandbox is a design reference, not the installable mobile artifact.