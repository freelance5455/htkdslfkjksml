/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 10-wtafs-backup-achievements.js
 تكملة نظام WTAFS (نسخ احتياطي/استيراد/مشاركة الملفات) + نظام الإنجازات (Achievements)
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
function _applyCleanupPatternToEntries(entries,pattern,maxKept){
 const files=entries.filter(e=>e&&e.name&&pattern.test(e.name)).map(e=>e.name).sort();
 if(files.length<=maxKept)return 0;
 const toDelete=files.slice(0,files.length-maxKept);
 let deleted=0;
 toDelete.forEach(name=>{try{if(WebToApkFS.delete(name))deleted++;}catch(e){}});
 return deleted;
}
function _cleanupFixedFolderPattern(pattern,maxKept){
 if(!_wtafsOk()||!WebToApkFS.hasAccess()||typeof WebToApkFS.delete!=='function')return 0;
 try{
 return _applyCleanupPatternToEntries(_wtafsListSafe(),pattern,maxKept);
 }catch(e){return 0;}
}
function _cleanupFixedFolderExports(){
 // إصلاح خلل قديم: كانت المطابقة مقصورة على .json فقط، بينما exportBans(fmt) يكتب أيضاً
 // CSV وTXT بنفس نمط الاسم إلى نفس المجلد — فكانت تلك الصيغتان تتراكمان بلا حد أقصى
 // رغم أن هذه الدالة بالذات وُجدت لمنع بالضبط هذا النوع من التراكم.
 const deleted=_cleanupFixedFolderPattern(/^ZERO_Bans_.*\.(json|csv|txt)$/i,WTAFS_MAX_EXPORTS_KEPT);
 if(deleted)stLog(' WebToApkFS: حُذف '+deleted+' ملف تصدير قديم من المجلد الثابت (الاحتفاظ بآخر '+WTAFS_MAX_EXPORTS_KEPT+')');
}
/* تشديد أكثر — الفجوة التي أغلقتها هذه الجولة: تعميم WebToApkFS (الجولتان السابقتان) أضاف 6
 أنماط ملفات جديدة تُكتَب إلى نفس المجلد الثابت (freqdb_/nn_/session_ عبر androidWrite،
 zero-freq-partitions- عبر saveFreqPartitions، وZeroAI_v25_/ZeroAI_FreqDB_ عبر
 exportJSON/exportCSV) دون أي تنظيف مقابل — أي أنها كانت ستتراكم إلى الأبد بالضبط كخلل
 ZERO_Bans_ الأصلي الذي وُجدت _cleanupFixedFolderExports أصلاً لحله، رغم توفّر نفس المنطق
 الجاهز. تُستدعى من androidWrite() (يغطي freqdb_/nn_/session_ تلقائياً لكل مستخدميها الثلاثة)
 وsaveFreqPartitions() مباشرة — وليس من exportJSON/exportCSV لأنهما يمرّان أصلاً عبر
 androidWrite فتُغطَّيان دون استدعاء مكرر. */
/* تشديد: أنماط عامة (.*) بدل \d+ الصارمة — بعد أن صارت freqdb_/nn_/session_/
 zero-freq-partitions-/ZeroAI_FreqDB_ تستخدم طابعاً زمنياً مقروءاً (_isoFname) بدل
 Date.now() الخام، فإن \d+ لم تعد تطابق أسماء الملفات الجديدة إطلاقاً (تحتوي شرطات وT)،
 ما كان سيُعطِّل تنظيف كل الأنماط الستة صمتاً. .* تتوافق مع أي شكل تسمية حالي أو مستقبلي. */
const WTAFS_BACKUP_PATTERNS=[
 /^freqdb_.*\.json$/i,
 /^nn_.*\.json$/i,
 /^session_.*\.json$/i,
 /^zero-freq-partitions-.*\.json$/i,
 /^ZeroAI_v25_.*\.json$/i,
 /^ZeroAI_FreqDB_.*\.csv$/i,
];
/* تشديد أكثر (فوق التشديد السابق نفسه): كانت هذه الدالة تستدعي _cleanupFixedFolderPattern
 لكل نمط من الأنماط الستة على حدة، وكل استدعاء يُجري نداء WebToApkFS.list('') خاصاً به —
 أي 6 نداءات قراءة فهرس فعلية (SAF عبر ContentResolver على جهاز حقيقي، وقد تكون بطيئة
 ملموساً) في كل مرة يُحفَظ فيها أي ملف واحد فقط. تُجلَب القائمة الآن مرة واحدة وتُطبَّق
 الأنماط الستة عليها محلياً بلا أي نداء إضافي — نفس نتيجة التنظيف تماماً بسدس عدد نداءات
 الفهرسة. */
function _cleanupFixedFolderBackups(){
 if(!_wtafsOk()||!WebToApkFS.hasAccess()||typeof WebToApkFS.delete!=='function')return;
 let entries;
 try{entries=_wtafsListSafe();}catch(e){return;}
 let total=0;
 WTAFS_BACKUP_PATTERNS.forEach(p=>{total+=_applyCleanupPatternToEntries(entries,p,WTAFS_MAX_EXPORTS_KEPT);});
 if(total)stLog(' WebToApkFS: حُذف '+total+' ملف نسخة احتياطية قديم من المجلد الثابت (الاحتفاظ بآخر '+WTAFS_MAX_EXPORTS_KEPT+' لكل نوع)');
}
function importFromFixedFolder(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const entries=_wtafsListSafe();
 // أحدث ملف تصدير JSON — اسمه يحمل طابعاً زمنياً ISO فالترتيب الأبجدي = الترتيب الزمني
 const jsonFiles=entries.filter(e=>e&&e.name&&/^ZERO_Bans_.*\.json$/i.test(e.name)).map(e=>e.name).sort();
 if(!jsonFiles.length){report(' لا يوجد ملف تصدير JSON داخل المجلد بعد','err');return;}
 const latest=jsonFiles[jsonFiles.length-1];
 const raw=WebToApkFS.readText(latest);
 if(!raw){report(' تعذّرت قراءة: '+latest,'err');return;}
 const res=_mergeImportedBansJSON(raw,latest);
 report('✓ استُورد من '+latest+': '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(e){report(' خطأ: '+e.message,'err');}
}

/* ── تحويل نصّ↔base64 صحيح مع دعم كامل للعربية (UTF-8) — يُستخدَم مع writeAll/readAll
 في WebToApkFS، التي تتعامل مع البايتات فقط. ── */
function _b64FromText(str){
 const bytes=new TextEncoder().encode(str);
 let bin='';
 for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));
 return btoa(bin);
}
function _textFromB64(b64){
 const bin=atob(b64);
 const bytes=new Uint8Array(bin.length);
 for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
 return new TextDecoder().decode(bytes);
}

/* ── بديل أخفّ من مجلد كامل: اختيار ملف JSON واحد ثابت (WebToApkFS.pickFile) وتذكّره —
 بدل تصدير ملف جديد كل مرة، يُعاد كتابة نفس الملف المُختار في كل تصدير لاحق تلقائياً.
 تشديد: هذا الزر مبني على نفس آلية pickFile المحكومة بنفس إذن البناء الذي يحكم مجلد
 الوصول الثابت بالضبط (permSafFolderAccess) — إن ظهر زرّ هذا يعني الإذن مُفعَّل فعلاً. ── */
function _pickedFileKey(){return 'zero_wtafs_pickedfile_uri';}
async function pickFixedFile(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||typeof WebToApkFS.pickFile!=='function'){report(' اختيار الملفات غير متاح في هذا البناء','err');return;}
 try{
 const r=await WebToApkFS.pickFile('application/json');
 if(!r||!r.ok){report(' لم يُختر ملف'+(r&&r.error?(' — '+r.error):''),'err');return;}
 const uri=r.uri||r.fileUri||r.documentUri||r.path;
 if(!uri){report(' لم يصل مسار الملف من النظام (استجابة غير متوقعة)','err');return;}
 localStorage.setItem(_pickedFileKey(),uri);
 // كتابة فورية للحالة الحالية في الملف المختار — حتى يبدأ الملف مفيداً من أول لحظة
 const built=_buildBansExportContent('json')||{content:JSON.stringify({version:'ZERO AI v25',bans:[],interference:[]},null,2)};
 const w=WebToApkFS.writeAll(uri,_b64FromText(built.content));
 // تحديث الأزرار/الصف أولاً، ثم رسالة النجاح/الفشل أخيراً — updateFolderAccessUI() تكتب
 // رسالة حالة عامة في نفس العنصر، فيجب ألا تُطمِس رسالة النتيجة الفعلية لهذا الإجراء.
 updateFolderAccessUI();
 if(w&&w.ok)report('✓ تم اختيار الملف وحفظ الحالة الحالية فيه — سيُحدَّث تلقائياً مع كل تصدير لاحق','ok');
 else report(' اختير الملف لكن فشلت الكتابة الأولى: '+(w&&w.error||'خطأ غير معروف'),'err');
 }catch(e){
 if(e&&e.name==='AbortError')return;
 report(' خطأ: '+e.message,'err');
 }
}
function importFromPickedFile(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 const uri=localStorage.getItem(_pickedFileKey());
 if(!uri){report(' لم يُختَر ملف ثابت بعد','err');return;}
 if(!_wtafsOk()){report(' اختيار الملفات غير متاح في هذا البناء','err');return;}
 try{
 const r=WebToApkFS.readAll(uri);
 if(!r||!r.ok){report(' تعذّرت قراءة الملف المختار: '+(r&&r.error||'خطأ غير معروف'),'err');return;}
 const res=_mergeImportedBansJSON(_textFromB64(r.base64),'الملف الثابت المختار');
 report('✓ استُورد من الملف الثابت: '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(e){report(' خطأ: '+e.message,'err');}
}
function forgetPickedFile(){
 try{
 if(_wtafsOk()){
 const uri=localStorage.getItem(_pickedFileKey());
 if(uri&&typeof WebToApkFS.releaseFile==='function'){try{WebToApkFS.releaseFile(uri);}catch(e){}}
 }
 }catch(e){}
 localStorage.removeItem(_pickedFileKey());
 updateFolderAccessUI();
 stLog('✖ WebToApkFS: نُسي الملف الثابت المختار');
}

/* تعميم: قبل هذا التعديل كانت هاتان الدالتان تنزيلاً خاماً عبر المتصفح فقط، بلا أي مرور
 عبر WebToApkFS/ZeroAndroid إطلاقاً — الآن تمران عبر androidWrite() المُعمَّمة أعلاه، فتصلان
 تلقائياً لنفس المجلد الثابت الذي منح المستخدم الوصول إليه (إن وُجد)، قبل اللجوء لتنزيل
 المتصفح كخطوة أخيرة فقط. */
function exportJSON(){
 // "توحيد الكل في ملف واحد": الحظر ومناطق التداخل كانا غائبين كلياً عن هذه "النسخة الاحتياطية
 // الكاملة" رغم اسمها — فاستعادتها وحدها (كما يفعل importFullBackupFromFixedFolder/
 // pickAndRestoreFullBackup) كانت تُعيد NN+FreqDB لكن تفقد كل الترددات المحظورة ومناطق
 // التداخل المكتسبة، ما يجبر المستخدم على الاحتفاظ بملفي ZERO_Bans_+ZeroAI_v25_ معاً لاستعادة
 // كامل حالته. الآن هذا الملف الواحد يكفي وحده.
 const {bans,interference}=_buildBansAndZonesForUnifiedBackup();
 // مراجعة "النسخة النهائية": نفس فجوة "توحيد الكل" السابقة تكررت لثلاث حالات حفظ أُضيفت لاحقاً
 // (PERSIST.saveCats/saveRoomModes/saveWienerNF) — تصل جميعها إلى المجلد الثابت كملفات منفصلة
 // لكنها كانت غائبة تماماً عن "النسخة الاحتياطية الكاملة" الموحَّدة، فاستعادة هذا الملف وحده
 // كانت تُعيد NN+FreqDB+الحظر لكن تُصفِّر فئات الحظر المُفعَّلة افتراضياً وتُفقِد بصمة وضع
 // الغرفة ونموذج ضجيج Wiener المُتعلَّمَين. تُضاف الآن بنفس الشرط الذي تستخدمه saveRoomModes/
 // saveWienerNF أنفسهما (لا تُصدَّر إن كانت فارغة أصلاً).
 const cats={};Object.keys(PERM_BAN_CATS).forEach(k=>{cats[k]=PERM_BAN_CATS[k].enabled;});
 const roomModes=(ROOM_MODES.peaks&&ROOM_MODES.peaks.length)?{peaks:ROOM_MODES.peaks.slice(0,6),dominant:ROOM_MODES.dominant}:null;
 const wienerNF=(typeof nFloor!=='undefined'&&nFloor&&nFloor.length)?{nf:Array.from(nFloor.slice(0,128)),alpha:P.alpha,beta:P.beta}:null;
 const data={
 meta:{type:'ZeroAI_v25_Export',date:new Date().toISOString(),cycles:aiCyc,bestSilence:bestSil,version:'v25'},
 freqDB:freqFile.entries.slice(0,200),classDistrib:{...FC},
 nnState:{trainN:NN.trainN,loss:NN.loss},
 nnWeights:NN.w1?{w1:[...NN.w1],b1:[...NN.b1],w2:[...NN.w2],b2:[...NN.b2]}:null,
 achievements:[...earnedAch],
 bgStats:{runs:typeof bgRuns!=='undefined'?bgRuns:0,ms:typeof bgTotalMs!=='undefined'?bgTotalMs:0},
 bans,interference,cats,roomModes,wienerNF
 };
 const json=JSON.stringify(data,null,2);
 const fname='ZeroAI_v25_'+new Date().toISOString().slice(0,19).replace(/:/g,'-')+'.json';
 if(!androidWrite('export',fname,json)){
 const blob=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);
 a.download=fname;a.click();
 stLog(' Exported JSON: '+Math.round(blob.size/1024)+'KB');
 }
}

function exportCSV(){
 if(!freqFile.entries.length){stLog(' No FreqDB to export');return;}
 const header='hz,count,energy,confirmed,cancelled,class,invOk';
 const rows=freqFile.entries.slice(0,500).map(e=>[e.hz,e.count,e.energy.toFixed(4),e.confirmed,e.cancelled,e.class||0,e.invOk||false].join(','));
 const csv=header+'\n'+rows.join('\n');
 const fname='ZeroAI_FreqDB_'+_isoFname()+'.csv';
 if(!androidWrite('export',fname,csv)){
 const blob=new Blob([csv],{type:'text/csv'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);
 a.download=fname;a.click();
 stLog(' Exported CSV: '+rows.length+' frequencies');
 }
}

/* تعميم: منطق استعادة مشترك للنسخة الاحتياطية الكاملة (NN + FreqDB + الإنجازات) — يستخدمه
 كل من importJSON (اختيار ملف عبر متصفح النظام) وimportFullBackupFromFixedFolder (قراءة
 مباشرة من المجلد الثابت عبر WebToApkFS، بعد أن صار exportJSON يكتب نسخة إليه تلقائياً)،
 بنفس نمط _mergeImportedBansJSON المُستخدَم مسبقاً لملفات الحظر. */
function _restoreFullBackupJSON(raw,sourceLabel){
 const data=JSON.parse(raw);
 // Restore NN
 if(data.nnWeights&&data.nnWeights.w1){
 if(!NN.w1)nnInit();
 NN.w1=[...data.nnWeights.w1];NN.b1=[...data.nnWeights.b1];
 NN.w2=[...data.nnWeights.w2];NN.b2=[...data.nnWeights.b2];
 NN.trainN=data.nnState?.trainN||0;
 stLog(' NN weights imported · trained='+NN.trainN);
 }
 // Restore FreqDB
 if(data.freqDB&&data.freqDB.length){
 freqDB.clear();
 data.freqDB.forEach(e=>freqDB.set(e.hz,{...e,firstSeen:Date.now(),lastSeen:Date.now()}));
 freqFile.totalCap=data.freqDB.length;
 freqFile.totalConf=data.freqDB.filter(e=>e.confirmed).length;
 freqFile.totalCanc=data.freqDB.filter(e=>e.cancelled).length;
 writeFreqFile();stLog(' FreqDB imported: '+freqDB.size+' frequencies');
 }
 // Restore achievements
 if(data.achievements)data.achievements.forEach(id=>earnedAch.add(id));
 // مراجعة "النسخة النهائية": classDistrib (FC) كانت تُصدَّر في exportJSON منذ البداية لكن لم
 // تُستعَد هنا إطلاقاً — الملف يحمل البيانات لكن الاستعادة تُهملها بصمت. نفس منطق loadFC
 // الإضافي بالضبط (تراكمي لا استبدال، لأن FC عدّادات تراكمية عبر الزمن).
 if(data.classDistrib&&typeof data.classDistrib==='object'){
 Object.keys(data.classDistrib).forEach(k=>{if(k in FC)FC[k]+=data.classDistrib[k]||0;});
 }
 // مراجعة "النسخة النهائية": نفس فجوة "الغائب عن النسخة الموحَّدة" لثلاث حالات حفظ أُضيفت لاحقاً
 // (cats/roomModes/wienerNF) — بنفس منطق loadCats/loadRoomModes/loadWienerNF أنفسهما بالضبط،
 // كي لا يختلف سلوك الاستعادة الموحَّدة عن استعادتها من ملفاتها المنفصلة.
 if(data.cats&&typeof data.cats==='object'){
 Object.keys(data.cats).forEach(k=>{if(PERM_BAN_CATS[k])PERM_BAN_CATS[k].enabled=data.cats[k];});
 }
 if(data.roomModes&&Array.isArray(data.roomModes.peaks)&&data.roomModes.peaks.length&&!ROOM_MODES.peaks.length){
 ROOM_MODES.peaks=data.roomModes.peaks;ROOM_MODES.dominant=data.roomModes.dominant||0;
 }
 if(data.wienerNF&&Array.isArray(data.wienerNF.nf)&&data.wienerNF.nf.length){
 if(!nFloor||nFloor.length!==data.wienerNF.nf.length)nFloor=new Float32Array(data.wienerNF.nf.length);
 data.wienerNF.nf.forEach((v,i)=>{nFloor[i]=v;});
 if(data.wienerNF.alpha)P.alpha=Math.max(0.8,Math.min(3.5,data.wienerNF.alpha));
 }
 // "توحيد الكل في ملف واحد": استعادة الحظر ومناطق التداخل أيضاً من نفس هذا الملف الواحد، إن
 // كانا موجودَين فيه (نسخ أنشأها exportJSON بعد هذا التحديث) — بإعادة استخدام نفس منطق دمج
 // ملفات ZERO_Bans_ المنفصلة (_mergeImportedBansJSON) مُطبَّقاً على raw نفسها (يحوي bans/
 // interference في مستواه الأعلى بجانب nnWeights/freqDB بالضبط بنفس الشكل). ملفات أقدم أو
 // نسخ استُعيدت من ملف بلا هذين الحقلين (Array.isArray فحص) تُستثنى تلقائياً — لا كسر للتوافق
 // العكسي مع أي نسخة احتياطية سابقة على هذا التحديث.
 let bansRes=null;
 if(Array.isArray(data.bans)){
 try{bansRes=_mergeImportedBansJSON(raw,sourceLabel);}
 catch(e){stLog(' تعذّرت استعادة الحظر من النسخة الموحَّدة: '+e.message);}
 }
 // تشديد: ملف JSON مستورَد (خصوصاً من نسخة أقدم قبل إصلاح خلل NaN/0Hz، أو مُعدَّل يدوياً)
 // قد يحمل إدخالات FreqDB بتردد فاسد — تُنظَّف فوراً قبل عرضها في الواجهة
 _purgeInvalidFrequencies('بعد استيراد JSON'+(sourceLabel?' — '+sourceLabel:''));
 updateFilesUI();
 const bansLine=bansRes?('الحظر: +'+bansRes.added+' · مناطق التداخل: +'+bansRes.zonesAdded):null;
 logExec({prog:'SYS',lines:['Import Successful ✓','NN: trained='+NN.trainN+' · FreqDB: '+freqDB.size+' freqs',...(bansLine?[bansLine]:[]),'NN weights and FreqDB restored — continue from previous session'],ms:0,auto:true});
 return {trainN:NN.trainN,freqDBSize:freqDB.size,bansAdded:bansRes?bansRes.added:0,zonesAdded:bansRes?bansRes.zonesAdded:0};
}
/* "توحيد الكل في ملف واحد": لاحقة موحَّدة لرسائل نجاح استعادة النسخة الكاملة الثلاث
 (importFullBackupFromFixedFolder/pickAndRestoreFullBackup/importFixedFolderFile) — تُضيف
 عدد الترددات المحظورة ومناطق التداخل المُستعادة حين تكون موجودة فعلاً في الملف (نسخ ما بعد
 هذا التحديث)، وتبقى فارغة بصمت لنسخ أقدم لا تحمل هذين الحقلين إطلاقاً. */
function _fmtBansZonesSuffix(res){
 if(!res||(!res.bansAdded&&!res.zonesAdded))return'';
 return ' + '+res.bansAdded+' حظر + '+res.zonesAdded+' تداخل';
}
function importJSON(file){
 if(!file)return;
 const r=new FileReader();
 r.onload=e=>{
 try{_restoreFullBackupJSON(e.target.result);}
 catch(err){stLog(' Import error: '+err.message);}
 };
 r.readAsText(file);
}
/* استيراد آخر نسخة احتياطية كاملة (JSON الذي يكتبه exportJSON تلقائياً) مباشرة من المجلد
 الثابت — نفس فكرة importFromFixedFolder الخاصة بالحظر، لكن للنسخة الكاملة (NN+FreqDB). */
function importFullBackupFromFixedFolder(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const entries=_wtafsListSafe();
 // اسم الملف يحمل طابعاً زمنياً ISO فالترتيب الأبجدي = الترتيب الزمني (نفس منطق بحث الحظر)
 const jsonFiles=entries.filter(e=>e&&e.name&&/^ZeroAI_v25_.*\.json$/i.test(e.name)).map(e=>e.name).sort();
 if(!jsonFiles.length){report(' لا يوجد ملف نسخة احتياطية كاملة داخل المجلد بعد — اضغط JSON في تبويب "الملفات" (Tab 7) أولاً لإنشاء واحدة','err');return;}
 const latest=jsonFiles[jsonFiles.length-1];
 const raw=WebToApkFS.readText(latest);
 if(!raw){report(' تعذّرت قراءة: '+latest,'err');return;}
 const res=_restoreFullBackupJSON(raw,latest);
 report('✓ استُعيدت نسخة احتياطية من '+latest+': NN مُدرَّب='+res.trainN+' · FreqDB='+res.freqDBSize+' تردد'+_fmtBansZonesSuffix(res),'ok');
 }catch(e){report(' خطأ: '+e.message,'err');}
}
/* استفادة إضافية من ميزات تطبيق "الملفات" (My Files) على أندرويد: اختيار ملف نسخة احتياطية
 واحد من أي مكان يعرضه نظام الملفات (المجلد الثابت نفسه، Downloads، تخزين سحابي مُزامَن،
 ملف وصل عبر مشاركة من جهاز آخر...) — بخلاف importFullBackupFromFixedFolder أعلاه، هذا لا
 يتطلب منح وصول لمجلد كامل مسبقاً إطلاقاً؛ يستخدم فقط WebToApkFS.pickFile نفسها التي يعتمد
 عليها بديل "اختيار ملف ثابت" الخاص بالحظر، لكن كعملية استيراد فورية لمرة واحدة (بلا حاجة
 لتذكّر الملف لاحقاً، فالاستعادة تُنفَّذ فوراً عند الاختيار). */
async function pickAndRestoreFullBackup(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||typeof WebToApkFS.pickFile!=='function'){report(' اختيار الملفات غير متاح في هذا البناء','err');return;}
 try{
 const r=await WebToApkFS.pickFile('application/json');
 if(!r||!r.ok){report(' لم يُختر ملف'+(r&&r.error?(' — '+r.error):''),'err');return;}
 const uri=r.uri||r.fileUri||r.documentUri||r.path;
 if(!uri){report(' لم يصل مسار الملف من النظام (استجابة غير متوقعة)','err');return;}
 const read=WebToApkFS.readAll(uri);
 // عملية لمرة واحدة فقط — لا حاجة لصلاحية دائمة على هذا الملف بعد قراءته، بعكس الملف
 // الثابت المختار للحظر (يُعاد كتابته مع كل تصدير لاحق فيحتاج صلاحية باقية)
 if(typeof WebToApkFS.releaseFile==='function'){try{WebToApkFS.releaseFile(uri);}catch(e){}}
 if(!read||!read.ok){report(' تعذّرت قراءة الملف المختار: '+(read&&read.error||'خطأ غير معروف'),'err');return;}
 const res=_restoreFullBackupJSON(_textFromB64(read.base64),'ملف مُختار عبر الملفات');
 report('✓ استُعيدت نسخة احتياطية من الملف المختار: NN مُدرَّب='+res.trainN+' · FreqDB='+res.freqDBSize+' تردد'+_fmtBansZonesSuffix(res),'ok');
 }catch(e){
 if(e&&e.name==='AbortError')return; // المستخدم أغلق نافذة الاختيار — ليس خطأ
 report(' خطأ: '+e.message,'err');
 }
}

/* ── استفادة أكبر من مميزات "الملفات" (My Files): تصفّح فعلي لمحتويات المجلد الثابت من
 داخل التطبيق — WebToApkFS.list('') نفسها المُستخدَمة داخلياً للتنظيف/البحث عن آخر نسخة،
 لكن مُعروضة الآن مباشرة للمستخدم كقائمة قابلة للاستيراد والحذف لكل ملف بمفرده، دون الحاجة
 للخروج إلى تطبيق ملفات منفصل. نعتمد فقط على e.name (الحقل الوحيد المؤكَّد من الجسر
 الحقيقي عبر كل الاستخدامات السابقة في هذا الملف) — لا افتراض لأي حقل آخر غير مؤكَّد مثل
 الحجم أو تاريخ التعديل، والتاريخ الحقيقي يُستخرَج من الاسم نفسه (مقروء منذ آخر تعديل). ── */
const WTAFS_FILE_KINDS=[
 {re:/^ZERO_Bans_.*\.json$/i,label:' حظر (JSON)',importable:true},
 {re:/^ZERO_Bans_.*\.csv$/i, label:' حظر (CSV)', importable:false},
 {re:/^ZERO_Bans_.*\.txt$/i, label:' حظر (TXT)', importable:false},
 {re:/^ZeroAI_v25_.*\.json$/i,label:' نسخة احتياطية كاملة',importable:true},
 {re:/^freqdb_.*\.json$/i, label:' FreqDB', importable:false},
 {re:/^nn_.*\.json$/i, label:' أوزان NN', importable:false},
 {re:/^session_.*\.json$/i, label:' جلسة', importable:false},
 {re:/^zero-freq-partitions-.*\.json$/i,label:' تقسيمات',importable:false},
 {re:/^ZeroAI_FreqDB_.*\.csv$/i,label:' FreqDB (CSV)',importable:false},
 {re:/^ZeroAI_Scenes\.json$/i,label:' مشاهد محفوظة',importable:true},
];
function _classifyFixedFolderFile(name){
 return WTAFS_FILE_KINDS.find(k=>k.re.test(name))||{label:' ملف',importable:false};
}
/* "استفد اكثر من الأذونات التي يقدمها my files": حتى الآن، إذن SAF المحفوظ (persistable URI
 permission) يُعامَل كأنه إما "ممنوح" أو "غير ممنوح" فقط — عبر hasAccess() المُخزَّنة على
 الجانب الأصلي (native) — بلا أي تحقق فعلي من أن الإذن ما زال صالحاً حقاً عند الاستخدام. لكن
 هذا الإذن يمكن أن يُبطَل من خارج التطبيق تماماً بعد منحه: المستخدم يحذف المجلد نفسه (عبر
 تطبيق ملفات حقيقي)، يُلغي الإذن يدوياً من إعدادات أندرويد (Settings→Apps→Permissions)، أو
 تُزال بطاقة SD الخارجية التي كان عليها المجلد. في كل هذه الحالات hasAccess() تستمر بإرجاع
 true (القيمة مخزَّنة، لا مُتحقَّق منها حياً) بينما كل عملية فعلية (list/write/read) تفشل —
 وبلا هذه الدالة، كانت الواجهة تعرض "✓ مُفعَّل" مُعطَّلاً للأبد بصمت، وكل حفظ لاحق (عبر
 androidWrite) يتراجع بصمت لتخزين المتصفح دون أن يعرف المستخدم أن مجلده الثابت "المُفعَّل"
 ظاهرياً لم يعد يعمل إطلاقاً — فيظن بياناته محفوظة هناك بينما هي ليست كذلك. الإصلاح: فشل
 list('') تحديداً (لا فشل ملف واحد داخل القائمة — ذاك له مرونة منفصلة أصلاً في
 shareAllFixedFolderFiles/renderWtafsResourcesInfo) هو إشارة قوية ومحدَّدة على أن الإذن
 المحفوظ نفسه أصبح غير صالح، لا مجرد خلل عابر بملف واحد. عندها: نُصفِّر الحالة المحفوظة
 (clearAccess) كي تعكس الواجهة الحقيقة فوراً وتعرض زر "منح الوصول" من جديد بدل حالة معطوبة
 دائمة، ونُبلِغ المستخدم بوضوح بالسبب المحتمل. */
function _wtafsHandleBrokenGrant(e){
 try{if(typeof WebToApkFS!=='undefined'&&typeof WebToApkFS.clearAccess==='function')WebToApkFS.clearAccess();}catch(e2){}
 // تحديث الواجهة كاملةً أولاً (يُخفي زر "مسح"، يُظهر "منح الوصول"، يُفرِغ قائمة الملفات...) —
 // ثم تُستبدَل رسالة "غير مُفعَّل بعد" العامة برسالة محدَّدة تشرح أن هذا انقطاع حقيقي لإذن كان
 // ممنوحاً، لا أول استخدام، كي يفهم المستخدم أن بياناته السابقة لم تُفقد بل الوصول فقط يحتاج
 // تجديداً — تظهر في سطر الحالة نفسه (لا في السجل الطرفي وحده) لأنها أهم من أن تُفوَّت.
 updateFolderAccessUI();
 const msg='تعذّر الوصول للمجلد الثابت المحفوظ سابقاً (قد يكون حُذف المجلد، أو أُلغي إذنه من '+
 'إعدادات أندرويد، أو أُزيلت بطاقة التخزين) — اضغط "منح الوصول" لاختيار مجلد من جديد'+
 (e&&e.message?(' — التفاصيل: '+e.message):'');
 const st=E('wtafs-status');
 if(st){st.textContent=msg;st.className='ban-exp-msg err';}
 stLog(msg);
}
/* مراجعة "النسخة النهائية": _wtafsHandleBrokenGrant كانت موصولة بنقطة نداء WebToApkFS.list('')
 واحدة فقط (داخل renderFixedFolderBrowser) من أصل 7 نقاط نداء مماثلة في هذا الملف — فبقيّة
 النقاط (تنظيف النسخ القديمة عند كل حفظ عبر androidWrite، الاستيراد اليدوي للحظر/النسخة
 الكاملة، المشاركة الجماعية) كانت تبتلع فشل إذن مُبطَل تماماً بصمت أو برسالة خطأ عامة، بلا أي
 استعادة فعلية لحالة "غير مُفعَّل" — أخطرها _cleanupFixedFolderBackups لأنها تعمل في الخلفية
 مع كل حفظ عادي، لا فقط عند فتح لوحة الملفات. غلاف موحَّد واحد يضمن اتساق هذا السلوك من كل
 نقطة نداء: يُعالِج كسر الإذن أولاً ثم يُعيد رمي نفس الاستثناء كي يستمر منطق catch الخاص بكل
 مستدعٍ (رسالة خطأ، قيمة افتراضية، إلخ) كما كان تماماً دون أي تغيير في سلوكه الظاهر. */
function _wtafsListSafe(subdir){
 try{return WebToApkFS.list(subdir||'')||[];}
 catch(e){_wtafsHandleBrokenGrant(e);throw e;}
}
function renderFixedFolderBrowser(){
 const list=E('wtafs-file-browser-list'),countEl=E('wtafs-file-count'),shareAllBtn=E('wtafs-share-all-btn');
 if(!list)return;
 // تُستدعى هنا (لا في updateFolderAccessUI) كي يتحدَّث سطر "حجم المجلد الثابت" مع كل تحديث
 // فعلي لقائمة الملفات — بعد منح/حذف/ضغط زر " تحديث" — دون تكرار الاستدعاء مرتين لكل حدث.
 renderWtafsResourcesInfo();
 const canShare=typeof navigator.share==='function';
 if(shareAllBtn)shareAllBtn.style.display=canShare?'':'none';
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){list.innerHTML='';if(countEl)countEl.textContent='';return;}
 let entries;
 try{entries=_wtafsListSafe();}
 catch(e){return;} // _wtafsListSafe عالجت كسر الإذن بالفعل قبل إعادة الرمي
 // e.isDirectory قد لا يكون مدعوماً في كل الأجهزة — فحص وقائي بلا أثر إن لم يكن موجوداً
 const allFiles=entries.filter(e=>e&&e.name&&!e.isDirectory).map(e=>e.name).sort().reverse();
 if(countEl)countEl.textContent='('+allFiles.length+' ملف)';
 const files=allFiles.slice(0,50);
 if(!files.length){list.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">المجلد فارغ حتى الآن</div>';return;}
 list.innerHTML=files.map(name=>{
 const kind=_classifyFixedFolderFile(name);
 // "تشديد اكثر": أسماء الملفات هنا تأتي من WebToApkFS.list() على مجلد فعلي يختاره المستخدم
 // — قد يحوي ملفات وضعها تطبيق آخر أو أُعيدت تسميتها عبر تطبيق ملفات حقيقي بأي محارف، وليس
 // فقط ملفات أنشأها هذا التطبيق بأسمائه المتوقَّعة. كان الاسم يُدرَج خاماً في title="${name}"
 // وفي نص التسمية عبر innerHTML، فاسم ملف يحوي " كان يخرج من سمة title ويحقن سمة HTML جديدة
 // (مثل onmouseover=...)، واسم يحوي<img ...>كان يُنشئ عنصر DOM فعلياً — حقن HTML/سمات حقيقي
 // عبر اسم ملف واحد فقط. escH() (تُستخدَم أصلاً لنفس الغرض مع نصوص مستوردة كسبب الحظر) تُغلق
 // هذه الثغرة لكلٍّ من سمة title ونص التسمية. أما وسيطة onclick فتحتاج الدرجتين معاً بالترتيب:
 // إفلات JS أولاً (يحمي بنية سلسلة JS النصية من ' واسم يحوي \)، ثم escH فوقها (يحمي حدود سمة
 // onclick="..." نفسها من " الخام) — الدرجتان لا تتعارضان لأن كلاً منهما يستهدف محارف مختلفة.
 const jsSafe=name.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
 const safe=escH(jsSafe);
 const nameH=escH(name);
 // هذه الأزرار الثلاثة (استيراد/مشاركة/حذف) كانت أيقونات ملوَّنة بلا أي نص مرافق —
 // الحالة الوحيدة في هذا الملف حيث حذف الرمز التصويري وحده كان سيُفرِغ الزر بصرياً
 // بالكامل (رغم بقاء onclick/title فعّالين). استُبدلت (28 سبتمبر 2026) بحروف نصية
 // مختصرة بسيطة أحادية اللون بدل حذفها كلياً، فيبقى تمييز الأزرار البصري قائماً.
 const importBtn=kind.importable?`<span style="color:rgba(215,215,215,.9);cursor:pointer;padding:0 5px;font-family:var(--fm);font-size:10px;font-weight:700" onclick="importFixedFolderFile('${safe}')" title="استيراد">IN</span>`:'';
 // مشاركة فردية — نفس navigator.share المُستخدَم أصلاً لمشاركة الحظر، مُعمَّم هنا على أي
 // ملف داخل المجلد الثابت (بدل الاقتصار على الحظر فقط).
 const shareBtn=canShare?`<span style="color:rgba(149,149,149,.85);cursor:pointer;padding:0 5px;font-family:var(--fm);font-size:10px;font-weight:700" onclick="shareFixedFolderFile('${safe}')" title="مشاركة">↑</span>`:'';
 return `<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.04)">
 <span style="font-family:var(--fm);font-size:8px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;margin-inline-end:6px" title="${nameH}">${kind.label} — ${nameH}</span>
 <span style="display:flex;align-items:center;flex-shrink:0">${importBtn}${shareBtn}<span style="color:rgba(160,160,160,.85);cursor:pointer;padding:0 5px" onclick="deleteFixedFolderFile('${safe}')" title="حذف">✕</span></span>
 </div>`;
 }).join('');
}
/* استفادة إضافية: تحديد نوع MIME من امتداد الاسم — يُستخدَم عند بناء File للمشاركة، لأن
 navigator.share/File يتطلبان نوعاً صريحاً كي تتعرَّف تطبيقات الاستقبال (بريد/واتساب/محرّر
 نصوص...) على الملف بشكل صحيح بدل معاملته كبيانات ثنائية غامضة. */
function _mimeForFile(name){
 if(/\.json$/i.test(name))return'application/json';
 if(/\.csv$/i.test(name))return'text/csv';
 if(/\.txt$/i.test(name))return'text/plain';
 return'application/octet-stream';
}
/* مشاركة ملف واحد من المجلد الثابت عبر شاشة المشاركة الأصلية لأندرويد — تعميم مباشر لنفس
 آلية shareBans، لكن لأي ملف موجود فعلياً في المجلد بدل الاقتصار على تصدير حظر جديد. */
async function shareFixedFolderFile(name){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(typeof navigator.share!=='function'){report(' المشاركة الأصلية غير مدعومة في هذا البناء','err');return;}
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const raw=WebToApkFS.readText(name);
 if(!raw){report(' تعذّرت قراءة: '+name,'err');return;}
 const file=new File([raw],name,{type:_mimeForFile(name)});
 const shareData={files:[file],title:'ZERO AI v25 — '+name};
 if(navigator.canShare&&!navigator.canShare(shareData)){report(' مشاركة هذا الملف غير مدعومة هنا','err');return;}
 await navigator.share(shareData);
 report('✓ فُتحت شاشة المشاركة: '+name,'ok');
 }catch(e){
 if(e&&e.name==='AbortError')return; // المستخدم أغلق شاشة المشاركة — ليس خطأ
 report(' فشلت المشاركة: '+e.message,'err');
 }
}
/* مشاركة كل ملفات المجلد الثابت دفعة واحدة (حتى سقف معقول) — Web Share API (المستوى 2)
 يدعم مصفوفة files متعددة أصلاً، وهذا هو نفس المسار المؤكَّد الذي يستخدمه shareBans، فقط
 بعدة ملفات بدل ملف واحد. السقف يحمي من تجاوز حدود نقل البيانات بين العمليات على أندرويد
 (Binder transaction) إن كان المجلد يحوي عشرات الملفات المتراكمة. */
const WTAFS_SHARE_ALL_MAX=20;
async function shareAllFixedFolderFiles(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(typeof navigator.share!=='function'){report(' المشاركة الأصلية غير مدعومة في هذا البناء','err');return;}
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const entries=_wtafsListSafe();
 const names=entries.filter(e=>e&&e.name&&!e.isDirectory).map(e=>e.name).sort().reverse();
 if(!names.length){report(' المجلد فارغ — لا يوجد ما يُشارَك','err');return;}
 const picked=names.slice(0,WTAFS_SHARE_ALL_MAX);
 const files=[];
 let failedCount=0;
 // "تشديد اكثر": readText لكل ملف على حدة داخل try خاص به — من دون هذا، ملف واحد غير قابل
 // للقراءة (حُذف خارجياً بين list() وreadText، أو تالف، أو خطأ إذن عابر) كان يُسقِط استثناءً
 // يخرج من forEach فيُلغي مشاركة كل الملفات العشرين دفعة واحدة عبر catch الخارجي، رغم أن
 // البقية سليمة تماماً وقابلة للمشاركة. الآن يُتخطَّى الملف الفاشل فقط وتُشارَك البقية،
 // مع إعلام المستخدم بعددها إن وُجد.
 picked.forEach(name=>{
 try{
 const raw=WebToApkFS.readText(name);
 if(raw)files.push(new File([raw],name,{type:_mimeForFile(name)}));
 else failedCount++;
 }catch(e){failedCount++;}
 });
 if(!files.length){report(' تعذّرت قراءة أي ملف للمشاركة','err');return;}
 const shareData={files,title:'ZERO AI v25 — نسخ احتياطية ('+files.length+' ملف)'};
 if(navigator.canShare&&!navigator.canShare(shareData)){
 report(' مشاركة عدة ملفات معاً غير مدعومة هنا — جرّب مشاركة كل ملف بمفرده','err');
 return;
 }
 await navigator.share(shareData);
 const notes=[];
 if(names.length>picked.length)notes.push('أحدث '+WTAFS_SHARE_ALL_MAX+' فقط من '+names.length);
 if(failedCount)notes.push('تعذّرت قراءة '+failedCount+' منها فاستُبعِدت');
 report('✓ فُتحت شاشة المشاركة: '+files.length+' ملف'+(notes.length?' ('+notes.join(' — ')+')':''),'ok');
 }catch(e){
 if(e&&e.name==='AbortError')return;
 report(' فشلت المشاركة: '+e.message,'err');
 }
}
async function importFixedFolderFile(name){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const raw=WebToApkFS.readText(name);
 if(!raw){report(' تعذّرت قراءة: '+name,'err');return;}
 if(/^ZERO_Bans_.*\.json$/i.test(name)){
 const res=_mergeImportedBansJSON(raw,name);
 report('✓ استُورد من '+name+': '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }else if(/^ZeroAI_v25_.*\.json$/i.test(name)){
 const res=_restoreFullBackupJSON(raw,name);
 report('✓ استُعيدت نسخة احتياطية من '+name+': NN مُدرَّب='+res.trainN+' · FreqDB='+res.freqDBSize+' تردد'+_fmtBansZonesSuffix(res),'ok');
 }else if(/^ZeroAI_Scenes\.json$/i.test(name)){
 const res=await _restoreScenesFromJSON(raw,name);
 report('✓ استُورد من '+name+': +'+res.added+' مشهد جديد + تحديث '+res.updated+' موجود','ok');
 }else{
 report(' هذا النوع من الملفات غير قابل للاستيراد المباشر','err');return;
 }
 }catch(e){report(' خطأ: '+e.message,'err');}
}
function deleteFixedFolderFile(name){
 if(!_wtafsOk()||!WebToApkFS.hasAccess()||typeof WebToApkFS.delete!=='function')return;
 try{
 if(WebToApkFS.delete(name)){stLog(' حُذف من المجلد الثابت: '+name);renderFixedFolderBrowser();}
 else stLog(' تعذّر حذف: '+name);
 }catch(e){stLog(' خطأ أثناء الحذف: '+e.message);}
}

/* ═══════════════════════════════════
 ④ ACHIEVEMENT SYSTEM — 15 milestones
═══════════════════════════════════ */
const ACHIEVEMENTS=[
 {id:'first_cap', icon:'',name:'First Capture', desc:'First frequency recorded', chk:()=>freqFile.totalCap>=1},
 {id:'first_conf',icon:'',name:'First Confirm', desc:'First freq confirmed ×3', chk:()=>freqFile.totalConf>=1},
 {id:'first_canc',icon:'✓', name:'First Cancel', desc:'Inverse cancellation success', chk:()=>freqFile.totalCanc>=1},
 {id:'db10', icon:'',name:'Growing DB', desc:'10+ frequencies captured', chk:()=>freqDB.size>=10},
 {id:'db50', icon:'',name:'Rich Database', desc:'50+ frequencies captured', chk:()=>freqFile.totalCap>=50},
 {id:'nn100', icon:'',name:'Learning Active', desc:'NN trained 100+ times', chk:()=>NN.trainN>=100},
 {id:'nn1000', icon:'',name:'Deep Learning', desc:'NN trained 1000+ times', chk:()=>NN.trainN>=1000},
 {id:'sil80', icon:'',name:'Silence!', desc:'80%+ silence achieved', chk:()=>silSc>=80},
 {id:'sil95', icon:'',name:'Master Silence', desc:'95%+ silence score', chk:()=>silSc>=95},
 {id:'cyc1000', icon:'',name:'Marathon', desc:'1000+ engine cycles', chk:()=>aiCyc>=1000},
 {id:'bg_run', icon:'',name:'Ghost Mode', desc:'Ran in background', chk:()=>(typeof bgRuns!=='undefined'&&bgRuns>=1)},
 {id:'inv10', icon:'⟳', name:'Inverse Master', desc:'10+ inverse cancellations', chk:()=>freqFile.totalCanc>=10},
 {id:'loss01', icon:'',name:'Sharp Mind', desc:'NN loss below 0.1', chk:()=>NN.loss<0.1&&NN.trainN>10},
 {id:'evp_det', icon:'〰',name:'EVP Found', desc:'Infrasonic EVP signal detected', chk:()=>evpE>0.2},
 {id:'emf_det', icon:'',name:'EMF Found', desc:'EMF interference detected', chk:()=>emfE>0.15},
];

const earnedAch=new Set();
const achQueue=[];
let achShowing=false;

function checkAchievements(){
 ACHIEVEMENTS.forEach(a=>{
 if(!earnedAch.has(a.id)&&a.chk()){
 earnedAch.add(a.id);achQueue.push(a);
 if(zeroDB){const tx=zeroDB.transaction('achievements','readwrite');tx.objectStore('achievements').put({id:a.id,date:new Date().toISOString()});}
 stLog(' '+a.icon+' '+a.name+': '+a.desc);
 if(curTab===7)renderAchievements();
 }
 });
 if(achQueue.length&&!achShowing)drainAchQ();
}

function drainAchQ(){
 if(!achQueue.length){achShowing=false;return;}
 achShowing=true;
 showAchToast(achQueue.shift());
 setTimeout(drainAchQ,3400);
}

function showAchToast(a){
 let t=E('achToast');
 if(!t){t=document.createElement('div');t.id='achToast';t.style.cssText='position:fixed;bottom:calc(88px + var(--vv-bottom-inset,0px));left:50%;transform:translateX(-50%) translateY(12px);z-index:200;opacity:0;pointer-events:none;transition:opacity .4s,transform .4s';document.body.appendChild(t);}
 t.innerHTML=`<div style="background:rgba(5,5,5,.97);border:1px solid rgba(206,206,206,.45);border-radius:16px;padding:10px 16px;display:flex;align-items:center;gap:10px;box-shadow:0 4px 35px rgba(0,0,0,.75);backdrop-filter:blur(18px);min-width:240px"><span style="font-size:24px">${a.icon}</span><div><div style="font-family:var(--fo);font-size:10px;color:#cecece;letter-spacing:.12em;margin-bottom:2px">ACHIEVEMENT UNLOCKED</div><div style="font-size:13px;font-weight:600;color:var(--text)">${a.name}</div><div style="font-family:var(--fm);font-size:10px;color:var(--dim)">${a.desc}</div></div></div>`;
 requestAnimationFrame(()=>{t.style.opacity='1';t.style.transform='translateX(-50%) translateY(0)';});
 setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(-50%) translateY(12px)';setTimeout(()=>{achShowing=false;drainAchQ();},400);},3000);
}

function renderAchievements(){
 const el=E('ach-list');if(!el)return;
 const total=ACHIEVEMENTS.length,earned=earnedAch.size;
 const c2=E('ach-count2');if(c2)c2.textContent=earned+'/'+total;
 const c1=E('ach-count');if(c1)c1.textContent=earned+'/'+total;
 el.innerHTML=ACHIEVEMENTS.map(a=>{
 const ok=earnedAch.has(a.id);
 return`<div class="ach-item" style="opacity:${ok?1:.3}"><span class="ach-ico">${a.icon}</span><div style="flex:1;min-width:0"><div class="ach-n" style="color:${ok?'var(--text)':'var(--dim)'}">${a.name}</div><div class="ach-d">${a.desc}</div></div>${ok?'<span class="ach-ck">✓</span>':''}</div>`;
 }).join('');
}

async function loadAchievements(){
 if(!zeroDB)return;
 const tx=zeroDB.transaction('achievements','readonly');
 const req=tx.objectStore('achievements').getAll();
 req.onsuccess=e=>{
 e.target.result.forEach(a=>earnedAch.add(a.id));
 if(curTab===7)renderAchievements();
 };
}

setInterval(checkAchievements,5000);

/* ═══════════════════
 ⑤ AUTO-SAVE
═══════════════════ */
let autoSave=true,lastAutoSave=0;

setInterval(async()=>{
 if(!isRun||!autoSave||!zeroDB)return;
 if(Date.now()-lastAutoSave<120000)return;
 lastAutoSave=Date.now();
 await saveSession();
 if(curTab===7)refreshSessionList();
},30000);

/* ═══════════════════════
 FILES UI UPDATE
═══════════════════════ */
