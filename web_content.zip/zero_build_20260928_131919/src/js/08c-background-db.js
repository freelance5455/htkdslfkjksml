/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 08c-background-db.js
 طبقة IndexedDB الكاملة (initDB + كل دوال udsWrite*)
 ──────────────────────────────────────────────────────────────────
 خلفية النجوم المتحركة المُلوَّنة (bgLoop/STARS/bgCv) حُذفت بالكامل
 (28 سبتمبر 2026) بطلب المستخدم: إزالة كل الخلفيات الزخرفية والصور
 والألوان من التطبيق، وجعله أسود وأبيض فقط — كانت هذه الخلفية زخرفية
 بحتة (طبقة z-index:0 خلف كل شيء) وملوَّنة بستة ألوان عشوائية لكل نجمة،
 فحذفها بالكامل (بدل تحويلها لتدرج رمادي) هو التنفيذ الحرفي لطلب
 "حذف الخلفيات". عنصر `<canvas id="bgCv">` أُزيل من index.template.html،
 واستدعاؤها من نقطتَي الربط الوحيدتين (bgLoop() في 03-notch-inverse-engine.js
 عند الإقلاع، ومستمع resize في 11-terminal-logging.js) أُزيل معها.
 ══════════════════════════════════════════════════════════════════ */


/* ════════════════════════════════════════════════════
 FILE STORAGE SYSTEM — 5 Layers
 ① IndexedDB — persistent local storage (NN, FreqDB, sessions)
 ② Anthropic Files — AI-accessible cloud files
 ③ Export / Import — download/upload JSON + CSV
 ④ Achievement — milestone tracker (15 achievements)
 ⑤ Auto-Save — every 2 min + on session stop
════════════════════════════════════════════════════ */

/* ═══════════════════════════
 ① INDEXEDDB
 Stores: sessions · nnWeights · achievements
═══════════════════════════ */
/* ════════════════════════════════════════════════
 UNIFIED DATA STORE (UDS) v3
 Shared reference DB for AI EXEC + Live Terminal.

 Stores:
 ┌─────────────────────────────────────────────┐
 │ sessions — full session snapshots │
 │ achievements — unlocked achievements │
 │ patterns — misc patterns │
 │ terminal_events — every tLog() persisted │ ← NEW
 │ exec_history — every AI program run │ ← NEW
 │ nn_history — NN metrics over time │ ← NEW
 │ freq_patterns — AI-identified Hz patterns │ ← NEW
 └─────────────────────────────────────────────┘

 AI reads terminal_events → AI_CTX → smarter programs
 Terminal reads exec_history → shows AI reasoning
 Both reference the same data store.
════════════════════════════════════════════════ */
const DBNAME='ZeroAIv25',DBVER=4;
let zeroDB=null;

async function initDB(){
 return new Promise((res,rej)=>{
 const req=indexedDB.open(DBNAME,DBVER);
 req.onupgradeneeded=e=>{
 const db=e.target.result;
 // Existing stores
 ['sessions','patterns'].forEach(n=>{
 if(!db.objectStoreNames.contains(n))
 db.createObjectStore(n,{keyPath:'id',autoIncrement:true});
 });
 if(!db.objectStoreNames.contains('achievements'))
 db.createObjectStore('achievements',{keyPath:'id'});
 // ── NEW: Terminal Events ──────────────────────
 // Stores every tLog() call: FREQ, NN, EXEC, INV, SF, COH...
 if(!db.objectStoreNames.contains('terminal_events')){
 const te=db.createObjectStore('terminal_events',{keyPath:'id',autoIncrement:true});
 te.createIndex('type','type',{unique:false});
 te.createIndex('ts','ts',{unique:false});
 }
 // ── NEW: Exec History ─────────────────────────
 // Every AI program execution with results + metrics
 if(!db.objectStoreNames.contains('exec_history')){
 const eh=db.createObjectStore('exec_history',{keyPath:'id',autoIncrement:true});
 eh.createIndex('prog','prog',{unique:false});
 eh.createIndex('ts','ts',{unique:false});
 }
 // ── NEW: NN History ───────────────────────────
 // Periodic NN loss/lr snapshots for trend analysis
 if(!db.objectStoreNames.contains('nn_history')){
 const nh=db.createObjectStore('nn_history',{keyPath:'id',autoIncrement:true});
 nh.createIndex('cycle','cycle',{unique:false});
 }
 // ── NEW: Freq Patterns ────────────────────────
 // Confirmed frequency patterns detected by AI
 if(!db.objectStoreNames.contains('freq_patterns')){
 db.createObjectStore('freq_patterns',{keyPath:'hz'});
 }
 // ── NEW v4: Scene Profiles ─────────────────────
 if(!db.objectStoreNames.contains('scenes')){
 db.createObjectStore('scenes',{keyPath:'name'});
 }
 };
 req.onsuccess=e=>{zeroDB=e.target.result;res(zeroDB);};
 req.onerror=e=>rej(e.target.error);
 });
}

/* ══ UDS RETENTION — تطوير التخزين (28 سبتمبر 2026، بطلب المستخدم) ══
 كانت udsWriteEvent/udsWriteExec/udsWriteNN تكتب صفوفاً جديدة (.add) بلا أي سقف أقصى إطلاقاً.
 التطبيق يعمل كخدمة خلفية مستمرة (foreground service — راجع BgService.java) لساعات أو أيام؛
 terminal_events تحديداً تُكتب من كل استدعاء tLog() (كل سطر FREQ/NN/EXEC/INV/SF/COH لحظي أثناء
 التشغيل)، فتتراكم بلا سقف طوال عمر التطبيق على الجهاز — تستهلك مساحة IndexedDB تدريجياً بلا
 أي فائدة عملية مقابلة: كل قارئ فعلي لهذه المخازن (AI_CTX، واجهة السجلّ، udsQueryNNHistory)
 يقرأ دوماً فقط أحدث N سجل (getAll().reverse().slice(0,limit))، فالسجلات الأقدم من آلاف
 الأسطر لا تُقرأ أبداً ولا قيمة لها. الحل: سقف ثابت لكل مخزن + تقليم دوري مُقلَّل الكلفة (فحص
 كل 25 كتابة فقط، لا كل كتابة، لتفادي معاملة count()+cursor إضافية على المسار الساخن) يحذف
 أقدم الصفوف الزائدة عن السقف عبر مؤشر بترتيب المفتاح التصاعدي الافتراضي (keyPath autoIncrement
 → الأقدم دائماً الأصغر رقماً). لا تغيير في أي دالة قراءة أو أي سلوك ظاهر للمستخدم — فقط تفادي
 نمو غير محدود بصمت. */
const UDS_CAP={terminal_events:4000,exec_history:1000,nn_history:3000};
function _udsPruneStore(storeName){
 if(!zeroDB)return;
 const cap=UDS_CAP[storeName];
 if(!cap)return;
 try{
 const txCount=zeroDB.transaction(storeName,'readonly');
 const req=txCount.objectStore(storeName).count();
 req.onsuccess=()=>{
 const over=req.result-cap;
 if(over<=0)return;
 try{
 const txDel=zeroDB.transaction(storeName,'readwrite');
 let deleted=0;
 txDel.objectStore(storeName).openCursor().onsuccess=e=>{
 const cur=e.target.result;
 if(!cur||deleted>=over)return;
 cur.delete();deleted++;cur.continue();
 };
 }catch(e){}
 };
 req.onerror=()=>{};
 }catch(e){}
}

/* ══ UDS WRITE FUNCTIONS ══ */
let _udsEventN=0; // write counter for throttling
let _udsExecN=0;
let _udsNNWriteN=0;

function udsWriteEvent(entry){
 if(!zeroDB)return;
 _udsEventN++;
 // Write every event but batch to avoid transaction overhead
 // Use a microtask to not block the engine
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('terminal_events','readwrite');
 tx.objectStore('terminal_events').add({
 type:entry.type,t:entry.t,ts:Date.now(),
 code:entry.code,sub:entry.sub||null,
 cycle:aiCyc||0,silSc:silSc||0,NN_loss:NN&&NN.loss||0,fanFreq:fanFreq||0
 });
 }catch(e){}
 if(_udsEventN%25===0)_udsPruneStore('terminal_events');
 // Also write to Android file if available
 if(_udsEventN%100===0&&typeof ZeroAndroid!=='undefined'){
 const line=JSON.stringify({type:entry.type,t:entry.t,ts:Date.now(),code:entry.code})+'\n';
 ZeroAndroid.saveFile('logs','terminal_'+new Date().toISOString().slice(0,10)+'.jsonl',line);
 }
 });
}

function udsWriteExec(args){
 if(!zeroDB)return;
 _udsExecN++;
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('exec_history','readwrite');
 tx.objectStore('exec_history').add({
 prog:args.prog,lines:args.lines,ms:args.ms||0,
 cycle:args.cycle||aiCyc||0,auto:!!args.auto,
 ts:Date.now(),silSc:silSc||0,NN_loss:NN&&NN.loss||0
 });
 }catch(e){}
 if(_udsExecN%25===0)_udsPruneStore('exec_history');
 // Persist to Android
 if(typeof ZeroAndroid!=='undefined'&&args.auto===false){
 ZeroAndroid.saveFile('logs','exec_'+new Date().toISOString().slice(0,10)+'.jsonl',
 JSON.stringify({prog:args.prog,lines:args.lines,cycle:args.cycle,ts:Date.now()})+'\n');
 }
 });
}

function udsWriteNN(){
 if(!zeroDB||!NN.w1||aiCyc%20!==0)return; // every 20 cycles, only when NN initialized
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('nn_history','readwrite');
 tx.objectStore('nn_history').add({cycle:aiCyc,ts:Date.now(),loss:NN.loss,lr:NN.lr,silSc,trainN:NN.trainN});
 }catch(e){}
 _udsNNWriteN++;
 if(_udsNNWriteN%25===0)_udsPruneStore('nn_history');
 });
}

function udsWritePattern(hz,count,classId){
 if(!zeroDB||count<5)return;
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('freq_patterns','readwrite');
 tx.objectStore('freq_patterns').put({hz,count,classId,ts:Date.now(),silSc});
 }catch(e){}
 });
}

/* ══ UDS QUERY FUNCTIONS ══ */
