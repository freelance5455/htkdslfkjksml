/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 08a-persist-bans-store.js
 كائن PERSIST (الحفظ المزدوج للحظر/المناطق) + تطهير الترددات غير الصالحة + تحميل الحظر الافتراضي + تبديل كل فئات الحظر
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): تقسيم إضافي لملف كان
 أضخم من بقية الملفات — نفس المنهج: قصّ آلي عند حدود تصريحات علوية
 آمنة، بلا أي تغيير منطقي أو إعادة ترتيب.
 ══════════════════════════════════════════════════════════════════ */
const PERSIST={
 K:{
 bans :'zero_v17_bans', // جميع مدخلات AI_BAN
 cats :'zero_v17_cats', // حالة تفعيل كل فئة
 nn :'zero_v17_nn', // أوزان الشبكة العصبية
 fc :'zero_v17_fc', // عدادات تصنيف الترددات
 zones:'zero_v17_zones', // مناطق تداخل INTERFERENCE_BAN.zones الجديدة (غير الأساسية)
 meta :'zero_v17_meta', // إصدار، ختم زمني
 },
 _saveTimer:null,
 _zoneSaveTimer:null,
 _nnTimer:null,
 _lastSave:0,

 /* ════════════════════════════════════════════════════════
 My Files Bridge — كتابة / قراءة من مجلد ثابت على الجهاز
 الأولوية: WebToApkFS (مجلد ثابت حقيقي عبر SAF — الجسر الفعلي الموجود في هذا البناء)
 ← ZeroAndroid (جسر أصلي مخصَّص، يبقى مدعوماً لو بُني المشروع مستقبلاً عبر
 Android Studio بدل خدمة تحويل الموقع إلى APK) ← localStorage احتياط نهائي دائماً.
 تشديد: WebToApkFS.hasAccess() يعود false حتى يمنح المستخدم الإذن يدوياً مرة واحدة
 من لوحة "الملفات"؛ قبل ذلك — وفي أي بناء لا يحتوي WebToApkFS أصلاً — يبقى السلوك
 مطابقاً تماماً لما كان عليه قبل هذا التعديل (محاولة ZeroAndroid ثم فشل صامت). ══
 ════════════════════════════════════════════════════════ */
 _mfWrite(name,json){
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 WebToApkFS.writeText(name,json);return;
 }
 }catch(e){}
 try{if(typeof ZeroAndroid!=='undefined')ZeroAndroid.saveData(name,json);}catch(e){}
 },
 _mfRead(name){
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 const r=WebToApkFS.readText(name);
 if(r)return r;
 }
 }catch(e){}
 try{
 if(typeof ZeroAndroid==='undefined')return null;
 const r=ZeroAndroid.loadData(name);
 return r||null;
 }catch(e){return null;}
 },

 /* ── حفظ فوري — يركّز على الجديد فقط ── */
 /* الترددات "الأساسية" (baseline:true) — الحضر الافتراضي (DEFAULT_BANNED_FREQS) والحضر
 المؤكَّد من طبقة التكامل (zero-core.js CONFIRMED_BANS) — تُعاد توليدها تلقائياً وبشكل
 كامل عند كل تشغيل (loadDefaultBans/loadConfirmedBans)، فلا داعي لتكرارها في الملف
 المحفوظ. الملف يقتصر إذن على الترددات "الجديدة" فعلاً: ما اكتشفه AI حيّاً (Fatigue ·
 Vote · Auto-detect · حظر تداخل) أو ما استوردَه/أضافه المستخدم يدوياً. */
 saveBans(){
 let json;
 try{
 const entries=[];
 AI_BAN.forEach((d,bin)=>{
 if(d.baseline)return; // أساسي — يُعاد توليده تلقائياً، لا حاجة لحفظه
 entries.push([bin,{
 reason:d.reason,bannedAt:d.bannedAt,bannedAtTime:d.bannedAtTime||null,
 autoUnbanAt:d.autoUnbanAt,
 hz:bin,permanent:!!d.permanent,category:d.category||null,
 cycles:d.cycles||0,preBanEnergy:d.preBanEnergy||0,
 postBanDetections:d.postBanDetections||0,
 probEnvironmental:d.probEnvironmental,verdict:d.verdict||null,
 // تأكيد متقاطع بين الأجهزة (راجع _mergeImportedBansJSON) — يجب أن ينجو من
 // إعادة التشغيل تماماً كبقية الحقول، وإلا تُفقد كل الاستيرادات السابقة بصمت
 crossConfirms:d.crossConfirms||0,
 importedVerdict:d.importedVerdict||null,
 verdictAgreement:d.verdictAgreement||null
 }]);
 });
 json=JSON.stringify({entries,ts:Date.now(),ver:17});
 }catch(e){return;}
 // إصلاح خلل: الكتابتان كانتا تحت try/catch واحد — فشل localStorage.setItem (مثلاً
 // QuotaExceededError بعد استيراد كبير) كان يُسقِط استثناءً يُلغي تنفيذ _mfWrite() التالية
 // معه بالكامل، رغم أن المجلد الثابت (My Files، الموصوف بأنه المصدر "الأساسي") قد لا يكون
 // ممتلئاً إطلاقاً. الآن كل كتابة مستقلة تماماً — فشل إحداهما لا يمنع الأخرى.
 try{localStorage.setItem(this.K.bans,json);}catch(e){} // ① localStorage احتياط
 try{this._mfWrite('zero_bans.json',json);}catch(e){} // ② My Files أساسي
 this._lastSave=Date.now();
 },

 /* ── حفظ مؤجل (debounce 600ms) لتجنب الفيضان عند الحظر السريع ── */
 scheduleSaveBans(){
 clearTimeout(this._saveTimer);
 this._saveTimer=setTimeout(()=>this.saveBans(),600);
 },

 /* ── تحميل AI_BAN — My Files أولاً، ثم localStorage احتياطاً ── */
 loadBans(){
 try{
 // ① المصدر الأساسي: My Files
 let raw=this._mfRead('zero_bans.json');
 // ② الاحتياط: localStorage
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 let loaded=0;
 data.entries.forEach(([bin,d])=>{
 // تشديد أكثر: تحقّق مباشر هنا عند التحميل نفسه — لا نعتمد فقط على فحص السلامة
 // اللاحق (_purgeInvalidFrequencies) لأن مسارات استعادة أخرى (restoreCategory) تُقرأ
 // من نفس هذا التخزين خارج نافذة الفحص عند بدء التشغيل (مثلاً عند تبديل مفتاح
 // تفعيل/إيقاف الحظر) — رفض الفساد من مصدره في كل نقطة قراءة أضمن من تنظيفه لاحقاً فقط.
 if(typeof bin!=='number'||!isFinite(bin)||bin<1)return;
 if(!AI_BAN.has(bin)){
 AI_BAN.set(bin,Object.assign({
 preBanEnergy:0,postBanDetections:0,
 lastPostBanEnergy:0,probEnvironmental:null,verdict:null,
 crossConfirms:0,importedVerdict:null,verdictAgreement:null
 },d,{hz:bin})); // hz يُفرض دائماً من مفتاح الـMap المحفوظ — لا نثق ببيانات قديمة ناقصة
 loaded++;
 }
 });
 return loaded;
 }catch(e){return 0;}
 },

 /* ── حفظ مناطق التداخل الجديدة (INTERFERENCE_BAN.zones) — نفس منطق saveBans تماماً ──
 تشديد جوهري: هذا كان مفقوداً كلياً من قبل — مناطق التداخل (تقدّم العدّاد count نحو
 التصعيد widen) لم تكن تُحفَظ إطلاقاً، فكانت تُفقد بالكامل عند كل إغلاق/إعادة تشغيل
 للتطبيق، وتبدأ من الصفر في كل جلسة استماع جديدة (عدا المناطق "الأساسية" المجمَّدة من
 CONFIRMED_INTERFERENCE في zero-core.js وقت آخر دفعة دُمجت). الآن تُحفَظ محلياً فوراً
 مثل الترددات المحظورة تماماً، وتُستعاد تلقائياً عند إعادة التشغيل — مهم بشكل خاص لأن
 هذا الجهاز لا يملك أي تخزين أندرويد أصلي فعلياً (يعتمد على localStorage في WebView
 فقط)، فهذه أصبحت طبقة الاستمرارية الوحيدة بين الجلسات. */
 saveZones(){
 let json;
 try{
 const entries=[];
 INTERFERENCE_BAN.zones.forEach((z,bin)=>{
 if(z.baseline)return; // أساسي — يُعاد توليده تلقائياً من zero-core.js، لا حاجة لحفظه
 entries.push([bin,{count:z.count||0,widen:z.widen||0,lastT:z.lastT||0,crossConfirms:z.crossConfirms||0}]);
 });
 json=JSON.stringify({entries,ts:Date.now(),ver:17});
 }catch(e){return;}
 // إصلاح خلل (نفس saveBans): كتابتان مستقلتان — فشل localStorage لا يمنع كتابة WebToApkFS
 try{localStorage.setItem(this.K.zones,json);}catch(e){} // ① localStorage احتياط
 try{this._mfWrite('zero_zones.json',json);}catch(e){} // ② My Files أساسي
 },
 scheduleSaveZones(){
 clearTimeout(this._zoneSaveTimer);
 this._zoneSaveTimer=setTimeout(()=>this.saveZones(),600);
 },
 /* ── تحميل مناطق التداخل — My Files أولاً، ثم localStorage احتياطاً ──
 نفس ضمان الشفاء الذاتي في loadBans: إن كانت المنطقة موجودة مسبقاً (أساسية من
 zero-core.js بعد دمج دفعة جديدة) فلا تُستبدَل — النسخة الأساسية الأحدث تفوز دائماً. */
 loadZones(){
 try{
 let raw=this._mfRead('zero_zones.json');
 if(!raw)raw=localStorage.getItem(this.K.zones);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 let loaded=0;
 data.entries.forEach(([bin,z])=>{
 // تشديد أكثر: نفس تحقّق loadBans — رفض أي مفتاح NaN/غير موجب من مصدره مباشرة
 if(typeof bin!=='number'||!isFinite(bin)||bin<1)return;
 if(!INTERFERENCE_BAN.zones.has(bin)){
 INTERFERENCE_BAN.zones.set(bin,{count:z.count||0,widen:z.widen||0,lastT:z.lastT||0,crossConfirms:z.crossConfirms||0});
 loaded++;
 }
 });
 return loaded;
 }catch(e){return 0;}
 },

 /* ── استعادة فئة معينة — My Files أولاً (للتبديل ON) ── */
 restoreCategory(cat){
 try{
 let raw=this._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 let restored=0;
 data.entries.forEach(([bin,d])=>{
 // تشديد أكثر — مهم بشكل خاص هنا: هذا المسار يُستدعى من زر تبديل تفعيل/إيقاف
 // الحظر (toggleAllPermBans) في أي لحظة أثناء التشغيل، خارج نافذة فحص السلامة
 // (_purgeInvalidFrequencies) التي تعمل مرة واحدة فقط عند بدء التشغيل — فأي إدخال
 // NaN/0Hz فاسد نُظِّف عند البدء يمكن أن "يعود من جديد" هنا لو لم يُتحقَّق منه هنا أيضاً.
 if(typeof bin!=='number'||!isFinite(bin)||bin<1)return;
 if(d.category===cat&&!AI_BAN.has(bin)){
 AI_BAN.set(bin,Object.assign({
 preBanEnergy:0,postBanDetections:0,
 lastPostBanEnergy:0,probEnvironmental:null,verdict:null,
 crossConfirms:0,importedVerdict:null,verdictAgreement:null
 },d,{hz:bin})); // hz يُفرض دائماً من مفتاح الـMap المحفوظ
 restored++;
 }
 });
 return restored;
 }catch(e){return 0;}
 },

 /* ── عدّ ترددات فئة من PERSIST — My Files أولاً ── */
 countCategory(cat){
 try{
 let raw=this._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 return data.entries.filter(([,d])=>d.category===cat).length;
 }catch(e){return 0;}
 },

 /* ── العدد الإجمالي المخزّن في PERSIST — My Files أولاً ── */
 totalCount(){
 try{
 let raw=this._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 return data.entries.length;
 }catch(e){return 0;}
 },

 /* ── حفظ حالة الفئات — My Files + localStorage ──
 مراجعة "النسخة النهائية": نفس إصلاح خلل saveBans/saveZones (راجع تعليقهما أعلاه) لم يكن
 مُطبَّقاً هنا — كتابتا localStorage وMy Files كانتا تحت try/catch واحد، ففشل الأولى
 (QuotaExceededError مثلاً) كان يُلغي الثانية معها رغم أن المجلد الثابت قد لا يكون ممتلئاً
 إطلاقاً. مطبَّق الآن بنفس النمط تماماً في الدوال الخمس التي أضافها كل من ⑨ROOM_MODES
 و⑧WIEN لاحقاً (saveCats/saveNN/saveFC/saveRoomModes/saveWienerNF). */
 saveCats(){
 let json;
 try{
 const state={};
 Object.keys(PERM_BAN_CATS).forEach(k=>{state[k]=PERM_BAN_CATS[k].enabled;});
 json=JSON.stringify({state,ts:Date.now()});
 }catch(e){return;}
 try{localStorage.setItem(this.K.cats,json);}catch(e){}
 try{this._mfWrite('zero_cats.json',json);}catch(e){}
 },

 /* ── تحميل حالة الفئات — My Files أولاً ── */
 loadCats(){
 try{
 let raw=this._mfRead('zero_cats.json');
 if(!raw)raw=localStorage.getItem(this.K.cats);
 if(!raw)return;
 const data=JSON.parse(raw);
 if(!data.state)return;
 Object.keys(data.state).forEach(k=>{
 if(PERM_BAN_CATS[k])PERM_BAN_CATS[k].enabled=data.state[k];
 });
 }catch(e){}
 },

 /* ── حفظ أوزان الشبكة العصبية — My Files + localStorage ── */
 scheduleNNSave(){
 clearTimeout(this._nnTimer);
 this._nnTimer=setTimeout(()=>this.saveNN(),2000);
 },
 saveNN(){
 if(!NN||!NN.w1)return;
 let json;
 try{
 json=JSON.stringify({
 w1:Array.from(NN.w1),w2:Array.from(NN.w2),
 b1:Array.from(NN.b1),b2:Array.from(NN.b2),
 ts:Date.now()
 });
 }catch(e){return;}
 try{localStorage.setItem(this.K.nn,json);}catch(e){}
 try{this._mfWrite('zero_nn.json',json);}catch(e){}
 },
 /* ── تحميل الأوزان — My Files أولاً ── */
 loadNN(){
 try{
 let raw=this._mfRead('zero_nn.json');
 if(!raw)raw=localStorage.getItem(this.K.nn);
 if(!raw)return false;
 const d=JSON.parse(raw);
 // مراجعة "المشروع بالكامل": هذه الدالة تُستدعى من loadDefaultBans() عند تحميل الصفحة
 // (200ms بعد load) — قبل أن يضغط المستخدم "تشغيل" بكثير، أي قبل أن يُستدعى nnInit()
 // في أي مكان؛ NN.w1 لا يزال null (قيمته الابتدائية) في تلك اللحظة دائماً. فكانت
 // NN.w1.length تفشل بـ TypeError على null، يُمسكها catch(e) الخارجي بصمت، فترجع
 // loadNN() دوماً false — استعادة أوزان الشبكة من zero_nn.json/localStorage لم تكن
 // تعمل إطلاقاً عبر هذا المسار (مموَّهة فقط لأن مسار IndexedDB المنفصل غالباً ما ينجح
 // بدلاً منه). الإصلاح: المقارنة بالحجم المتوقَّع الثابت للمعمارية (NN.in*NN.hid) بدل
 // NN.w1.length الحالي — صحيح بصرف النظر عن ترتيب الاستدعاء.
 if(!d.w1||d.w1.length!==NN.in*NN.hid)return false;
 NN.w1=new Float32Array(d.w1);NN.w2=new Float32Array(d.w2);
 NN.b1=new Float32Array(d.b1);NN.b2=new Float32Array(d.b2);
 // إصلاح خطأ حقيقي رصده سجلّ الأخطاء الجديد فعلياً على جهاز المستخدم: هذا المسار كان
 // يضبط w1/w2/b1/b2 مباشرة دون تهيئة dw1/db1/dw2/db2 المقابلة لها (كما تفعل nnInit()
 // دائماً) — فتبقى null كقيمتها الابتدائية، لأن loadNN() تُستدعى من loadDefaultBans()
 // خلال أول 200ms من تحميل الصفحة، أي قبل أي استدعاء لـ nnInit() في كامل الجلسة. وبما
 // أن NN.w1 صار truthy الآن، فإن startAll() لاحقاً (شرطه if(!NN.w1)nnInit()) يتخطى
 // التهيئة تماماً — فيبقى NN.dw2 (وإخوتها) null طوال الجلسة. النتيجة: أول قراءة
 // NN.dw2[i2] داخل nnTrain() (تتكرر كل ~320ms طالما التطبيق يعمل) تنهار بـ
 // "Cannot read properties of null (reading '0')" — بالضبط الخطأ المتكرر الذي التقطه
 // سجلّ الأخطاء على الجهاز الحقيقي. ملاحظة: saveNN() لا يحفظ dw1/db1/dw2/db2 أصلاً
 // (هي عدّادات "زخم" مؤقتة للتدريب فقط) — فتصفيرها هنا عند كل استعادة هو السلوك
 // الصحيح تماماً المطابق لما تفعله nnInit() نفسها عند إنشاء أوزان جديدة.
 NN.dw1=new Float32Array(NN.in*NN.hid);NN.db1=new Float32Array(NN.hid);
 NN.dw2=new Float32Array(NN.hid*NN.out);NN.db2=new Float32Array(NN.out);
 return true;
 }catch(e){return false;}
 },

 /* ── حفظ عدادات الفئات — My Files + localStorage ── */
 saveFC(){
 let json;
 try{
 const snap={};Object.keys(FC).forEach(k=>{snap[k]=FC[k];});
 json=JSON.stringify({snap,ts:Date.now()});
 }catch(e){return;}
 try{localStorage.setItem(this.K.fc,json);}catch(e){}
 try{this._mfWrite('zero_fc.json',json);}catch(e){}
 },
 /* ── تحميل العدادات — My Files أولاً ── */
 loadFC(){
 try{
 let raw=this._mfRead('zero_fc.json');
 if(!raw)raw=localStorage.getItem(this.K.fc);
 if(!raw)return;
 const d=JSON.parse(raw);
 if(!d.snap)return;
 Object.keys(d.snap).forEach(k=>{if(k in FC)FC[k]+=d.snap[k];});
 }catch(e){}
 },

 /* ── ⑨ ROOM_MODES×PERSIST — حفظ بصمة وضع الغرفة / تحميل ── */
 saveRoomModes(){
 if(!ROOM_MODES.peaks||!ROOM_MODES.peaks.length)return;
 let json;
 try{json=JSON.stringify({peaks:ROOM_MODES.peaks.slice(0,6),dominant:ROOM_MODES.dominant,ts:Date.now()});}
 catch(e){return;}
 try{localStorage.setItem('zero_room_modes',json);}catch(e){}
 try{this._mfWrite('zero_room_modes.json',json);}catch(e){}
 },
 loadRoomModes(){
 try{
 let raw=this._mfRead('zero_room_modes.json');
 if(!raw)raw=localStorage.getItem('zero_room_modes');
 if(!raw)return false;
 const d=JSON.parse(raw);
 if(!Array.isArray(d.peaks)||!d.peaks.length)return false;
 if(!ROOM_MODES.peaks.length){ROOM_MODES.peaks=d.peaks;ROOM_MODES.dominant=d.dominant||0;}
 return true;
 }catch(e){return false;}
 },

 /* ── ⑧ WIEN×PERSIST: حفظ/استعادة نموذج ضجيج Wiener ── */
 saveWienerNF(){
 if(!nFloor||!nFloor.length)return;
 let json;
 try{
 const arr=Array.from(nFloor.slice(0,128));
 json=JSON.stringify({nf:arr,alpha:P.alpha,beta:P.beta,ts:Date.now()});
 }catch(e){return;}
 try{localStorage.setItem('zero_wiener_nf',json);}catch(e){}
 try{this._mfWrite('zero_wiener_nf.json',json);}catch(e){}
 },
 loadWienerNF(){
 try{
 let raw=this._mfRead('zero_wiener_nf.json');
 if(!raw)raw=localStorage.getItem('zero_wiener_nf');
 if(!raw)return false;
 const d=JSON.parse(raw);
 if(!Array.isArray(d.nf)||!d.nf.length)return false;
 if(!nFloor||nFloor.length!==d.nf.length)nFloor=new Float32Array(d.nf.length);
 d.nf.forEach((v,i)=>{nFloor[i]=v;});
 if(d.alpha)P.alpha=Math.max(0.8,Math.min(3.5,d.alpha));
 return true;
 }catch(e){return false;}
 },

 /* ── حذف كل البيانات المحفوظة (localStorage فقط — My Files يبقى) ── */
 clear(){
 try{Object.values(this.K).forEach(k=>localStorage.removeItem(k));}catch(e){}
 stLog(' PERSIST: localStorage محذوف (My Files يبقى كنسخة احتياطية)');
 },

 /* ── حالة التخزين ── */
 status(){
 let sz=0;
 try{sz=new Blob([localStorage.getItem(this.K.bans)||'']).size;}catch(e){}
 const age=this._lastSave?Math.round((Date.now()-this._lastSave)/1000)+'ث':'—';
 let mfp='غير متاح';
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess())mfp=WebToApkFS.getAccessUri()||'مُفعَّل (WebToApkFS)';
 else if(typeof ZeroAndroid!=='undefined')mfp=ZeroAndroid.getDataPath();
 }catch(e){}
 return`PERSIST: ${AI_BAN.size} محضور · ${(sz/1024).toFixed(1)}KB · آخر حفظ ${age}\nMy Files: ${mfp}`;
 }
};

/* ══ ميزة وقائية: فحص سلامة الترددات (NaN/0.00Hz) ══
 تشديد: حتى بعد إصلاح كل نقاط إنشاء الحظر (updateFreqFatigue/castBanVote) ومصدر الخلل
 الجذري في المرشّح الطيفي (تسمّم كالمان من قِيَم -Infinity في FFT)، أي حظر فاسد كان قد
 أُنشئ ووصل للتخزين *قبل* هذا الإصلاح يبقى محفوظاً ويُعاد عرضه في كل تشغيل قادم. هذه
 الدالة تفحص AI_BAN وINTERFERENCE_BAN.zones وfreqDB عند كل بدء تشغيل (وقابلة للاستدعاء
 يدوياً من أي مسار استيراد لاحقاً) وتحذف أي إدخال بتردد غير رقمي/غير منتهٍ (NaN) أو أقل
 من 1Hz — طبقة حماية دائمة تمنع تكرار ظهور "NaNHz"/"0.00Hz" مهما كان مصدر الفساد مستقبلاً. */
function _purgeInvalidFrequencies(sourceLabel){
 // حظر/تداخل/تصويت: لا وجود لتردد سالب أو دون 1Hz شرعي إطلاقاً هنا
 const isBad=hz=>typeof hz!=='number'||!isFinite(hz)||hz<1;
 // freqDB وحدها استثناء: ميزة negFreqMirror (مرآة التردد السالب) تُخزِّن عمداً إدخالات
 // بمفتاح سالب (class:2, isMirror:true) — هذه شرعية ويجب عدم حذفها، فيُكتفى هنا برفض
 // القيم غير المنتهية (NaN/Infinity) فقط دون فرض حدّ أدنى موجب على القيمة.
 const isBadFreqDB=hz=>typeof hz!=='number'||!isFinite(hz);
 let bansRemoved=0,zonesRemoved=0,freqDBRemoved=0,votesRemoved=0;
 AI_BAN.forEach((d,bin)=>{if(isBad(bin))(AI_BAN.delete(bin),bansRemoved++);});
 INTERFERENCE_BAN.zones.forEach((z,bin)=>{if(isBad(bin))(INTERFERENCE_BAN.zones.delete(bin),zonesRemoved++);});
 if(typeof freqDB!=='undefined')freqDB.forEach((e,bin)=>{if(isBadFreqDB(bin))(freqDB.delete(bin),freqDBRemoved++);});
 if(typeof BAN_VOTE!=='undefined')BAN_VOTE.forEach((v,bin)=>{if(isBad(bin))(BAN_VOTE.delete(bin),votesRemoved++);});
 const total=bansRemoved+zonesRemoved+freqDBRemoved+votesRemoved;
 if(total>0){
 stLog(' فحص السلامة: حُذف '+total+' إدخال بتردد فاسد (NaN/0Hz)'+(sourceLabel?' — '+sourceLabel:'')+
 ' ['+bansRemoved+' حظر، '+zonesRemoved+' تداخل، '+freqDBRemoved+' FreqDB، '+votesRemoved+' تصويت]');
 if(bansRemoved)PERSIST.scheduleSaveBans();
 if(zonesRemoved)PERSIST.scheduleSaveZones();
 if(freqDBRemoved)writeFreqFile();
 }
 return {bansRemoved,zonesRemoved,freqDBRemoved,votesRemoved,total};
}

function loadDefaultBans(){
 // ① استعادة كل الترددات المحفوظة من PERSIST (تعلّمها AI سابقاً)
 const persisted=PERSIST.loadBans();
 if(persisted>0)stLog(' PERSIST: '+persisted+' تردد محفوظ استُعيد');
 // ①ب استعادة مناطق التداخل الجديدة (تقدّم العدّاد نحو التصعيد) — كانت تُفقد كلياً سابقاً
 const zonesRestored=PERSIST.loadZones();
 if(zonesRestored>0)stLog(' PERSIST: '+zonesRestored+' منطقة تداخل محفوظة استُعيدت');
 // ①ج فحص سلامة فوري: أي حظر/منطقة NaN أو 0Hz وصل للتخزين من نسخة سابقة قبل هذا
 // الإصلاح يُحذَف الآن تلقائياً — قبل أن يُعرَض حتى مرة واحدة على المستخدم في هذا التشغيل
 _purgeInvalidFrequencies('عند بدء التشغيل');
 // ② استعادة أوزان الشبكة العصبية
 if(PERSIST.loadNN())stLog(' PERSIST: أوزان الشبكة العصبية استُعيدت');
 // ③ استعادة عدادات الفئات
 PERSIST.loadFC();
 // ④ مراجعة "المشروع بالكامل": PERSIST.loadRoomModes()/loadWienerNF() كانتا محفوظتين تلقائياً
 // كل 300 دورة (وعند طلب المجلد الثابت) لكن غير مُستدعاتين إطلاقاً من أي مسار بدء تشغيل —
 // بحث كامل عن استدعاءاتهما في الملف لم يجد سوى تعريفهما، بلا نقطة استدعاء واحدة. فكانت
 // بصمة أوضاع الغرفة الصوتية المتعلَّمة (ROOM_MODES) ونموذج أرضية الضجيج المتعلَّم (Wiener
 // nFloor/P.alpha) تُصفَّر عند كل إعادة تشغيل عادية للتطبيق رغم حفظهما بأمانة كل جلسة —
 // "تعلّم" ضائع بالكامل دون أي فائدة عملية إلا عبر استعادة نسخة احتياطية كاملة يدوياً.
 if(PERSIST.loadRoomModes())stLog(' PERSIST: بصمة وضع الغرفة استُعيدت');
 if(PERSIST.loadWienerNF())stLog(' PERSIST: نموذج ضجيج Wiener استُعيد');
 let loaded=0;
 DEFAULT_BANNED_FREQS.forEach(([hz,cat,reason])=>{
 if(!PERM_BAN_CATS[cat]||!PERM_BAN_CATS[cat].enabled)return;
 const bin=fBin(hz);
 if(!AI_BAN.has(bin)){
 // baseline:true — قائمة أساسية ثابتة تُعاد توليدها في كل تشغيل، فلا تُحفَظ/تُصدَّر
 // ضمن الملفات (PERSIST.saveBans و_getBansForExport يركّزان على الجديد فقط)
 AI_BAN.set(bin,{reason,bannedAt:0,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,baseline:true,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 loaded++;
 }
 });
 if(loaded)stLog(` حضر دائم: ${loaded} تردد محمّل (ضار · صاخب · mic)`);
 renderBanList();
 renderPermSettings();
}
/* ── حظر موحّد — لا تصنيفات فرعية، كل الترددات تحت "ترددات محظورة" واحدة ──
 داخلياً لا تزال PERM_BAN_CATS تصنّف الترددات (harmful/thermal/lag/…) لأغراض
 السلوك التلقائي فقط (auto-unban, heat score...) لكن الواجهة تُظهرها كوحدة واحدة. */
function toggleAllPermBans(){
 const anyEnabled=Object.values(PERM_BAN_CATS).some(c=>c.enabled);
 const turnOn=!anyEnabled; // إن كان أي جزء مفعّلاً نوقف الكل، وإلا نفعّل الكل
 let restoredTotal=0;
 // عند الإيقاف: نحفظ الحالة الحالية أولاً — قبل حذف أي شيء من AI_BAN — لأن الحذف
 // أدناه سيُفرغ كل الفئات المعروفة من الذاكرة؛ لو حفظنا بعد الحذف (كالسابق) فأي حظر
 // "جديد" اكتُشف حيّاً (Fatigue/Vote/Auto-detect) ولم يصل بعد إلى PERSIST كان سيُفقد
 // نهائياً ولا يعود حتى عند إعادة التفعيل — لأن saveBans تركّز على الجديد فقط أصلاً.
 if(!turnOn)PERSIST.saveBans();
 Object.keys(PERM_BAN_CATS).forEach(cat=>{
 PERM_BAN_CATS[cat].enabled=turnOn;
 if(turnOn){
 restoredTotal+=PERSIST.restoreCategory(cat);
 DEFAULT_BANNED_FREQS.forEach(([hz,c,reason])=>{
 if(c!==cat)return;
 const bin=fBin(hz);
 if(!AI_BAN.has(bin))AI_BAN.set(bin,{reason,bannedAt:execCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,baseline:true,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 });
 }else{
 AI_BAN.forEach((d,bin)=>{if(d.permanent&&d.category===cat)AI_BAN.delete(bin);});
 }
 });
 if(turnOn){
 // إعادة تحميل القائمة المؤكَّدة من طبقة التكامل (zero-core.js) — restoreCategory وحدها لا تكفي
 // إن كانت PERSIST قد فُرِّغت للتو بواسطة مسار الإيقاف (saveBans يحفظ AI_BAN الفارغة وقتها)
 if(typeof loadConfirmedBans==='function')loadConfirmedBans();
 PERSIST.saveCats();PERSIST.scheduleSaveBans();
 stLog(' تفعيل الترددات المحظورة'+(restoredTotal?' ('+restoredTotal+' محفوظ استُعيد)':''));
 }else{
 PERSIST.saveCats();
 stLog(' إيقاف الترددات المحظورة (البيانات محفوظة)');
 }
 const sw=E('sw-pban-all');if(sw)sw.checked=turnOn;
 renderBanList();
 renderPermSettings();
}
/* ══ INTERFERENCE MONITOR (Dev130) — بديل الإضافة اليدوية ══
 يراقب التداخل بين الترددات المحظورة مسبقاً والترددات التي تُرصد وتُحظر حديثاً.
 عند حظر تردد جديد قريب (ضمن tolHz) من تردد محظور سابقاً لكن ليس نفس الصندوق = تداخل.
 إذا تكرر التداخل في نفس المنطقة عدة مرات (escalateAt) → يُرفع مستوى الحظر
 بتوسيع النطاق المحظور حول مركز المنطقة (حظر التداخل). */
