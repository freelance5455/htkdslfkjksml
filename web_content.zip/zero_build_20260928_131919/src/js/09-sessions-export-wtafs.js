/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 09-sessions-export-wtafs.js
 حفظ/تحميل الجلسات + جسر الأندرويد للملفات + تصدير/استيراد الحظر + بداية نظام WTAFS (المجلد الثابت)
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
async function udsQueryEvents(type,limit){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('terminal_events','readonly');
 const store=tx.objectStore('terminal_events');
 // 'ALL' or missing type → return all events (no index filter)
 const req=(!type||type==='ALL')
 ? store.getAll()
 : store.index('type').getAll(type);
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,limit||500));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsQueryExec(prog,limit){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('exec_history','readonly');
 const store=tx.objectStore('exec_history');
 const req=prog?store.index('prog').getAll(prog):store.getAll();
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,limit));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsQueryNNHistory(limit){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('nn_history','readonly');
 const req=tx.objectStore('nn_history').getAll();
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,limit));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsQueryPatterns(){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('freq_patterns','readonly');
 const req=tx.objectStore('freq_patterns').getAll();
 req.onsuccess=e=>res(e.target.result.sort((a,b)=>b.count-a.count));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsGetStats(){
 if(!zeroDB)return{};
 const stores=['terminal_events','exec_history','nn_history','freq_patterns','sessions'];
 const counts={};
 await Promise.all(stores.map(s=>new Promise(res=>{
 try{
 const tx=zeroDB.transaction(s,'readonly');
 const req=tx.objectStore(s).count();
 req.onsuccess=e=>{counts[s]=e.target.result;res();};
 req.onerror=()=>{counts[s]=0;res();};
 }catch(e){counts[s]=0;res();}
 })));
 return counts;
}

/* ══ STORAGE PERSISTENCE REQUEST ══ */
async function reqStoragePersist(){
 if('storage' in navigator&&'persist' in navigator.storage){
 const ok=await navigator.storage.persist();
 stLog(' Storage persist: '+(ok?'✓ granted (no-evict)':'✗ denied (evictable)'));
 const est=await navigator.storage.estimate();
 stLog(` Storage: used=${Math.round((est.usage||0)/1024)}KB / quota=${Math.round((est.quota||0)/1024/1024)}MB`);
 if(typeof ZeroAndroid!=='undefined'){
 const ib=ZeroAndroid.getInternalPath();
 const xb=ZeroAndroid.getExportPath();
 stLog(` Internal: ${ib}`);
 stLog(` Export: ${xb}`);
 }
 }
}

function buildSessionObj(){
 return{
 date:new Date().toISOString(),
 cycles:aiCyc,bestSilence:bestSil,
 freqCap:freqFile.totalCap,freqConf:freqFile.totalConf,freqCanc:freqFile.totalCanc,
 nnTrain:NN.trainN,nnLoss:NN.loss,
 classDistrib:{...FC},
 freqTop:freqFile.entries.slice(0,50).map(e=>({hz:e.hz,count:e.count,energy:e.energy,confirmed:e.confirmed,cancelled:e.cancelled,class:e.class})),
 nnW:{w1:NN.w1?[...NN.w1]:null,b1:NN.b1?[...NN.b1]:null,w2:NN.w2?[...NN.w2]:null,b2:NN.b2?[...NN.b2]:null},
 bgRuns:typeof bgRuns!=='undefined'?bgRuns:0,
 bgMs:typeof bgTotalMs!=='undefined'?bgTotalMs:0,
 achievements:[...earnedAch],
 sampleRate:actx?actx.sampleRate:0
 };
}

async function saveSession(){
 if(!zeroDB||aiCyc<5)return;
 const sess=buildSessionObj();
 return new Promise(res=>{
 const tx=zeroDB.transaction('sessions','readwrite');
 tx.objectStore('sessions').add(sess);
 tx.oncomplete=()=>{stLog(' Session saved · cycles='+aiCyc+' · silence='+bestSil+'%');res();};
 tx.onerror=()=>res();
 });
}

async function loadLastWeights(){
 if(!zeroDB)return false;
 return new Promise(res=>{
 const tx=zeroDB.transaction('sessions','readonly');
 const req=tx.objectStore('sessions').openCursor(null,'prev');
 req.onsuccess=e=>{
 const cur=e.target.result;
 if(cur&&cur.value.nnW&&cur.value.nnW.w1){
 const w=cur.value.nnW;
 if(!NN.w1)nnInit();
 NN.w1=[...w.w1];NN.b1=[...w.b1];NN.w2=[...w.w2];NN.b2=[...w.b2];
 NN.trainN=cur.value.nnTrain||0;
 stLog(' NN restored: trained='+NN.trainN+' from '+new Date(cur.value.date).toLocaleDateString());
 logExec({prog:'SYS',lines:['Previous Session Restored ','NN weights loaded · training='+NN.trainN+' · best silence='+cur.value.bestSilence+'%','FreqDB history: '+cur.value.freqCap+' captured — continue from previous session'],ms:0,auto:true});
 res(true);
 }else res(false);
 };
 req.onerror=()=>res(false);
 });
}

async function restoreNNFromDB(){
 const ok=await loadLastWeights();
 if(!ok)stLog(' No saved NN weights found');
}

async function getAllSessions(){
 if(!zeroDB)return[];
 return new Promise(res=>{
 const tx=zeroDB.transaction('sessions','readonly');
 const req=tx.objectStore('sessions').getAll();
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,10));
 req.onerror=()=>res([]);
 });
}

async function clearAllSessions(){
 if(!zeroDB)return;
 if(window.confirm&&!confirm('Clear all saved sessions?'))return;
 const tx=zeroDB.transaction('sessions','readwrite');
 tx.objectStore('sessions').clear();
 tx.oncomplete=()=>{stLog(' All sessions cleared');refreshSessionList();};
}

async function refreshSessionList(){
 const el=E('sess-list');if(!el)return;
 const sessions=await getAllSessions();
 if(!sessions.length){el.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">No saved sessions</div>';return;}
 el.innerHTML=sessions.map((s,i)=>{
 const d=new Date(s.date);
 return`<div class="st-frow"><div style="font-size:14px"></div><div style="flex:1;min-width:0"><div class="st-fn">${d.toLocaleDateString()} ${d.toLocaleTimeString()}</div><div class="st-fd">sil=${s.bestSilence}% · cyc=${s.cycles} · NN=${s.nnTrain} · freqs=${s.freqCap}</div></div><div class="st-btn ai" style="font-size:8px;padding:3px 7px" onclick="loadSession(${s.id})">load</div></div>`;
 }).join('');
 const sc=E('st-sessions');if(sc)sc.textContent=sessions.length;
}

async function loadSession(id){
 if(!zeroDB)return;
 const tx=zeroDB.transaction('sessions','readonly');
 const req=tx.objectStore('sessions').get(id);
 req.onsuccess=e=>{
 const s=e.target.result;if(!s)return;
 // Restore NN
 if(s.nnW&&s.nnW.w1){if(!NN.w1)nnInit();NN.w1=[...s.nnW.w1];NN.b1=[...s.nnW.b1];NN.w2=[...s.nnW.w2];NN.b2=[...s.nnW.b2];NN.trainN=s.nnTrain||0;}
 // Restore FreqDB
 if(s.freqTop){freqDB.clear();s.freqTop.forEach(e=>freqDB.set(e.hz,{...e,firstSeen:Date.now(),lastSeen:Date.now()}));freqFile.totalCap=s.freqCap||0;freqFile.totalConf=s.freqConf||0;freqFile.totalCanc=s.freqCanc||0;writeFreqFile();}
 // Restore achievements
 if(s.achievements)s.achievements.forEach(id2=>earnedAch.add(id2));
 // تشديد: جلسة قديمة محفوظة قبل إصلاح خلل NaN/0Hz قد تحمل إدخالات فاسدة — تُنظَّف فوراً
 _purgeInvalidFrequencies('بعد استعادة جلسة محفوظة');
 stLog(' Session loaded: '+new Date(s.date).toLocaleString());
 updateFilesUI();
 };
}

/* ═══════════════════════════════════
 ② ANTHROPIC FILES API
 Upload FreqDB, NN weights, sessions
 for AI-accessible context in Claude chat
═══════════════════════════════════ */
/* Local storage only — no cloud files */

/* ══════════════════════════════════════
 LOCAL FILE STORAGE — Android bridge + browser download
 Paths (Android):
 Internal: /data/data/com.zero.v25/files/ZeroAI_v25/
 sessions/ freqdb/ nn_weights/ logs/
 Export: /sdcard/ZeroAI/v25/Export/ (or Android Q: getExternalFilesDir)
 No cloud, no network required.
══════════════════════════════════════ */

/* Android JS bridge — writes to internal/external storage */
/* تعميم "منح الوصول لمجلد ثابت" (WebToApkFS) على كل المشروع دفعة واحدة: هذه هي الدالة
 المشتركة التي يمر عبرها saveFreqDBLocal/saveNNLocal/saveFullSessionLocal (ولاحقاً
 exportJSON/exportCSV) — رفع أولوية WebToApkFS هنا، بنفس النمط المُطبَّق مسبقاً في
 exportBans وPERSIST._mfWrite، يمنح جميع نقاط الحفظ تلك وصولاً لمجلد ثابت حقيقي ومرئي
 للمستخدم فوراً دون تعديل كل دالة على حدة. الأولوية: WebToApkFS (مجلد ثابت عبر SAF) ←
 ZeroAndroid (تخزين داخلي خاص بالتطبيق) ← false (يعني: استخدم تنزيل المتصفح). */
function androidWrite(subdir,filename,content){
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 const ok=WebToApkFS.writeText(filename,content);
 if(ok){
 stLog(' Saved: '+filename+' (المجلد الثابت)');
 // تشديد أكثر: بلا هذا، كل ملف freqdb_/nn_/session_ جديد يتراكم إلى الأبد — نفس خلل
 // ZERO_Bans_ الأصلي، لكن على 3 مستخدِمين لهذه الدالة المشتركة دفعة واحدة.
 _cleanupFixedFolderBackups();
 return true;
 }
 }
 }catch(e){}
 if(typeof ZeroAndroid!=='undefined'){
 const ok=ZeroAndroid.saveFile(subdir,filename,content);
 if(ok)stLog(' Saved: '+subdir+'/'+filename+' (Android)');
 else stLog(' Android write failed: '+subdir+'/'+filename);
 return ok;
 }
 return false; // browser fallback: use download
}

function androidRead(subdir,filename){
 if(typeof ZeroAndroid!=='undefined')return ZeroAndroid.readFile(subdir,filename);
 return null;
}

function androidListFiles(subdir){
 if(typeof ZeroAndroid!=='undefined'){
 const r=ZeroAndroid.listFiles(subdir);
 return r?JSON.parse(r):[];
 }
 return[];
}

function getStoragePaths(){
 if(typeof ZeroAndroid!=='undefined'){
 return{
 internal:ZeroAndroid.getInternalPath(),
 export:ZeroAndroid.getExportPath(),
 available:true
 };
 }
 return{internal:'IndexedDB',export:'Browser Download',available:false};
}

/* Save FreqDB to local storage */
function saveFreqDBLocal(){
 if(!freqDB.size){stLog(' FreqDB empty');return;}
 const data={
 type:'ZeroAI_FreqDB_v25',date:new Date().toISOString(),
 sampleRate:actx?actx.sampleRate:0,nyquist:actx?actx.sampleRate/2:0,
 stats:{totalCap:freqFile.totalCap,totalConf:freqFile.totalConf,totalCanc:freqFile.totalCanc},
 frequencies:freqFile.entries.slice(0,200).map(e=>({hz:e.hz,count:e.count,energy:+e.energy.toFixed(4),confirmed:e.confirmed,cancelled:e.cancelled,class:e.class,invOk:e.invOk})),
 classDistrib:{...FC},bayesian:{w1:DRV.wS,w2:DRV.wE,w3:DRV.wM},
 nnState:{trainN:NN.trainN,loss:NN.loss,lr:NN.lr},silence:silSc
 };
 const fname='freqdb_'+_isoFname()+'.json';
 const json=JSON.stringify(data,null,2);
 if(!androidWrite('freqdb',fname,json)){
 // Browser fallback — download
 const b=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=fname;a.click();
 stLog(' FreqDB saved: '+fname+' ('+Math.round(json.length/1024)+'KB)');
 }
 updateFilesUI();
}

/* Save NN weights to local storage */
function saveNNLocal(){
 if(!NN.w1){stLog(' NN not initialized');return;}
 const data={type:'ZeroAI_NN_v25',date:new Date().toISOString(),architecture:'16→24→8',trainN:NN.trainN,loss:NN.loss,lr:NN.lr,momentum:NN.mom,w1:[...NN.w1],b1:[...NN.b1],w2:[...NN.w2],b2:[...NN.b2]};
 const fname='nn_'+_isoFname()+'.json';
 const json=JSON.stringify(data);
 if(!androidWrite('nn_weights',fname,json)){
 const b=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=fname;a.click();
 stLog(' NN weights saved: '+fname);
 }
}

/* Save full session log */
function saveFullSessionLocal(){
 const sess=buildSessionObj();
 const fname='session_'+_isoFname()+'.json';
 const json=JSON.stringify(sess,null,2);
 if(!androidWrite('sessions',fname,json)){
 const b=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=fname;a.click();
 stLog(' Session saved: '+fname+' ('+Math.round(json.length/1024)+'KB)');
 }
 updateFilesUI();
}

/* AI chat: local engine only — no network */

/* ═══════════════════════
 ③ EXPORT / IMPORT
═══════════════════════ */
/* ════════════════════════════════════════
 BAN LIST EXPORT / IMPORT
════════════════════════════════════════ */
function _getBansForExport(){
 // نجمع من AI_BAN (النشط) + PERSIST (يشمل الموقوف — My Files أولاً ثم localStorage)
 const map=new Map([...AI_BAN]);
 try{
 let raw=PERSIST._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(PERSIST.K.bans);
 if(raw){
 const data=JSON.parse(raw);
 if(Array.isArray(data.entries)){
 data.entries.forEach(([bin,d])=>{if(!map.has(bin))map.set(bin,d);});
 }
 }
 }catch(e){}
 // نفرض hz من مفتاح الـMap دائماً — يضمن عدم ظهور 0.00Hz حتى لو كانت البيانات القديمة ناقصة
 // التصدير يركّز على الجديد فقط — نستبعد الترددات "الأساسية" (baseline: الحضر الافتراضي +
 // الحضر المؤكَّد من طبقة التكامل) لأنها ثابتة ومعروفة مسبقاً وليست جديدة يستحق تصديرها
 return [...map.entries()].filter(([,d])=>!d.baseline).map(([bin,d])=>({...d,hz:bin})).sort((a,b)=>a.hz-b.hz);
}

function _showExpMsg(msg,type){
 const el=E('ban-exp-msg');if(!el)return;
 el.textContent=msg;el.className='ban-exp-msg '+(type||'');
}

/* تنسيق تاريخ/وقت مبسّط وثابت (بدل الاعتماد على عداد الدورات execCyc فقط) */
function _fmtDT(ms){
 if(!ms)return'—';
 const d=new Date(ms);const p=n=>String(n).padStart(2,'0');
 return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes());
}
/* "توحيد الكل في ملف واحد": نفس بناء بيانات bans/interference المُستخدَم داخل
 _buildBansExportContent (تصدير ملف الحظر المستقل ZERO_Bans_) — مُستخرَج هنا في دالة مشتركة
 يستخدمها exportJSON أيضاً كي تحمل "النسخة الاحتياطية الكاملة" ZeroAI_v25_ نفس بيانات الحظر
 ومناطق التداخل، فيصبح ملف واحد كافياً لاستعادة كل الحالة القابلة للاستعادة في التطبيق (NN +
 FreqDB + الإنجازات + الحظر + مناطق التداخل) بدل الحاجة لملفين منفصلين (ZERO_Bans_ +
 ZeroAI_v25_) لاستعادة كامل الحالة. تصدير الحظر المستقل (exportBans/shareBans) يبقى كما هو
 دون أي تغيير — هذا توسيع لا استبدال. */
function _buildBansAndZonesForUnifiedBackup(){
 const bans=_getBansForExport();
 const zonesArr=[...INTERFERENCE_BAN.zones.entries()].filter(([,z])=>!z.baseline).sort((a,b)=>b[1].count-a[1].count);
 return {
 bans:bans.map(d=>({
 hz:+(d.hz||0).toFixed(4),
 category:d.category||'unknown',
 reason:d.reason||'',
 bannedAt:d.bannedAt||0,
 bannedAtTime:d.bannedAtTime||null,
 cycles:d.cycles||0,
 permanent:true,
 preBanEnergy:+(d.preBanEnergy||0).toFixed(6),
 verdict:d.verdict||null,
 crossConfirms:d.crossConfirms||0
 })),
 interference:zonesArr.map(([hz,z])=>({hz:+hz.toFixed(4),count:z.count,widenHz:z.widen||0,lastAt:z.lastT||null,crossConfirms:z.crossConfirms||0}))
 };
}
/* ── يبني محتوى التصدير (JSON/CSV/TXT) دون كتابته لأي وجهة — منطق مشترك بين
 exportBans() (تنزيل/مجلد ثابت) وshareBans() (مشاركة أصلية عبر navigator.share). ── */
function _buildBansExportContent(fmt){
 // التصدير يركّز على الجديد فقط — الترددات ومناطق التداخل "الأساسية" (baseline) مستبعدة
 // لأنها ثابتة ومعروفة مسبقاً (تُعاد توليدها تلقائياً من الحضر الافتراضي + طبقة التكامل)
 const bans=_getBansForExport();
 const zonesArr=[...INTERFERENCE_BAN.zones.entries()].filter(([,z])=>!z.baseline).sort((a,b)=>b[1].count-a[1].count);
 if(!bans.length&&!zonesArr.length)return null;
 const ts=new Date().toISOString().slice(0,19).replace(/T/,'_').replace(/:/g,'-');
 let filename,content,mime;

 if(fmt==='json'){
 filename='ZERO_Bans_'+ts+'.json';
 mime='application/json';
 content=JSON.stringify({
 version:'ZERO AI v25',
 exportDate:new Date().toISOString(),
 scope:'الجديد فقط — بدون الحضر الأساسي/المؤكَّد المُعاد توليده تلقائياً',
 // تشديد: يوثّق أي دفعة CONFIRMED_BANS/CONFIRMED_INTERFERENCE (zero-core.js) كانت محمَّلة
 // فعلياً وقت هذا التصدير — يمنع الالتباس لاحقاً إن كان الجهاز يشغّل نسخة أقدم لم تُحدَّث
 baselineBans:typeof CONFIRMED_BANS!=='undefined'?CONFIRMED_BANS.length:0,
 baselineZones:typeof CONFIRMED_INTERFERENCE!=='undefined'?CONFIRMED_INTERFERENCE.length:0,
 totalBans:bans.length,
 source:'AI_BAN + PERSIST',
 bans:bans.map(d=>({
 hz:+(d.hz||0).toFixed(4),
 category:d.category||'unknown',
 reason:d.reason||'',
 bannedAt:d.bannedAt||0,
 bannedAtTime:d.bannedAtTime||null,
 cycles:d.cycles||0,
 permanent:true,
 preBanEnergy:+(d.preBanEnergy||0).toFixed(6),
 verdict:d.verdict||null,
 crossConfirms:d.crossConfirms||0
 })),
 interference:zonesArr.map(([hz,z])=>({hz:+hz.toFixed(4),count:z.count,widenHz:z.widen||0,lastAt:z.lastT||null,crossConfirms:z.crossConfirms||0}))
 },null,2);

 }else if(fmt==='csv'){
 filename='ZERO_Bans_'+ts+'.csv';
 mime='text/csv';
 const hdr='hz,category,reason,cycles,bannedAt,bannedAtTime,preBanEnergy,verdict';
 const rows=bans.map(d=>[
 (d.hz||0).toFixed(4),
 d.category||'',
 '"'+(d.reason||'').replace(/"/g,"''")+'"',
 d.cycles||0,
 d.bannedAt||0,
 d.bannedAtTime?_fmtDT(d.bannedAtTime):'',
 (d.preBanEnergy||0).toFixed(6),
 d.verdict||''
 ].join(','));
 content=hdr+'\n'+rows.join('\n');

 }else{
 filename='ZERO_Bans_'+ts+'.txt';
 mime='text/plain';
 const lines=[
 'ZERO AI v25 — الترددات المحظورة ومراقبة التداخل',
 'تاريخ التصدير: '+_fmtDT(Date.now()),
 '(الجديد فقط — الحضر الأساسي/المؤكَّد يُعاد توليده تلقائياً ولا يُصدَّر)',
 // تشديد: يسجّل نسخة القائمة الأساسية المحمَّلة وقت هذا التصدير بالضبط — إن ظهرت لاحقاً
 // ترددات "مكررة" عند دمج هذا الملف، هذا السطر يوضّح فوراً إن كان السبب نسخة قديمة
 'نسخة القائمة الأساسية وقت التصدير: '+(typeof CONFIRMED_BANS!=='undefined'?CONFIRMED_BANS.length:0)+' تردد + '+(typeof CONFIRMED_INTERFERENCE!=='undefined'?CONFIRMED_INTERFERENCE.length:0)+' منطقة تداخل',
 ''
 ];
 lines.push(' الترددات المحضورة الجديدة ('+bans.length+' تردد)');
 lines.push('─'.repeat(48));
 if(!bans.length){
 lines.push('لا يوجد حضر جديد');
 }else{
 bans.forEach(d=>{
 lines.push((d.hz||0).toFixed(2)+'Hz');
 });
 }
 lines.push('');
 lines.push(' مناطق التداخل الجديدة ('+zonesArr.length+' منطقة)');
 lines.push('─'.repeat(48));
 if(!zonesArr.length){
 lines.push('لا يوجد تداخل جديد مرصود');
 }else{
 zonesArr.forEach(([center,z])=>{
 const hz=center.toFixed(2)+'Hz';
 const info='عدد مرات التداخل: '+z.count+(z.widen?' · موسّع ±'+z.widen.toFixed(0)+'Hz':'')+(z.crossConfirms?' · مؤكَّد×'+z.crossConfirms:'');
 lines.push(hz.padEnd(12)+' │ '+info);
 });
 }
 lines.push('');
 lines.push('─'.repeat(48));
 lines.push('مسار التصدير: '+(_wtafsOk()&&WebToApkFS.hasAccess()?('مجلد ثابت — '+WebToApkFS.getAccessUri()):
 (typeof ZeroAndroid!=='undefined')?ZeroAndroid.getExportPath():'تنزيل المتصفح'));
 content=lines.join('\n');
 }
 return {filename,content,mime,bansCount:bans.length,zonesCount:zonesArr.length};
}

function exportBans(fmt){
 const built=_buildBansExportContent(fmt);
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للتصدير','err');return;}
 const {filename,content,mime,bansCount,zonesCount}=built;
 // إصلاح مماثل لنفس مشكلة shareBans: ملف csv لا يحتوي صفوف مناطق تداخل إطلاقاً، فلا
 // نذكر عددها في رسائل النجاح/السجلّ لهذا التنسيق تحديداً كي لا يُظنّ أنها ضمن الملف.
 const zonesNote=(fmt==='csv')?'':(' + '+zonesCount+' تداخل جديد');

 // ⓪ نسخة دائمة إضافية إلى المجلد الثابت (WebToApkFS) إن كان الوصول ممنوحاً — مستقلة عن
 // التنزيل عبر المتصفح، وهي ما يعتمد عليه زر "استيراد آخر نسخة من المجلد" لاحقاً.
 let wtafsSaved=false;
 try{
 if(_wtafsOk()&&WebToApkFS.hasAccess()){
 wtafsSaved=!!WebToApkFS.writeText(filename,content);
 if(wtafsSaved)_cleanupFixedFolderExports();
 }
 }catch(e){}
 // ⓪ب نسخة موازية إلى الملف الثابت المختار (البديل الأخفّ من مجلد كامل)، إن وُجد —
 // بصرف النظر عن التنسيق (json/csv/txt)، فكل تصدير يُحدِّث نفس ذلك الملف تلقائياً بأحدث JSON.
 let wtafsPickSaved=false;
 try{
 const pickedUri=localStorage.getItem(_pickedFileKey());
 if(pickedUri&&_wtafsOk()){
 const jsonBuilt=(fmt==='json')?built:_buildBansExportContent('json');
 if(jsonBuilt){
 const w=WebToApkFS.writeAll(pickedUri,_b64FromText(jsonBuilt.content));
 wtafsPickSaved=!!(w&&w.ok);
 }
 }
 }catch(e){}
 const wtafsNote=(wtafsSaved?' + المجلد الثابت':'')+(wtafsPickSaved?' + الملف الثابت المختار':'');

 // ① محاولة الحفظ عبر Android Bridge → My Files
 if(typeof ZeroAndroid!=='undefined'){
 const ok=ZeroAndroid.exportFile(filename,content);
 if(ok){
 const path=ZeroAndroid.getExportPath()+'/'+filename;
 _showExpMsg('✓ تم الحفظ في: '+path+wtafsNote,'ok');
 stLog(' Ban export: '+filename+' ('+bansCount+' تردد جديد'+zonesNote+')'+wtafsNote);
 return;
 }
 _showExpMsg(' فشل الحفظ عبر Android — جارٍ التنزيل...','err');
 }

 // ② Fallback: تنزيل مباشر (متصفح)
 const blob=new Blob([content],{type:mime});
 const url=URL.createObjectURL(blob);
 const a=document.createElement('a');
 a.href=url;a.download=filename;
 document.body.appendChild(a);a.click();
 setTimeout(()=>{URL.revokeObjectURL(url);document.body.removeChild(a);},1000);
 _showExpMsg('✓ جارٍ التنزيل: '+filename+wtafsNote,'ok');
 stLog(' Ban export (browser): '+filename+wtafsNote);
}

/* ══ مشاركة أصلية (navigator.share) ══
 تشديد: هذا البناء (خدمة تحويل الموقع إلى APK) يحقن تلقائياً navigator.share/canShare
 القياسيَين ليعملا عبر شاشة المشاركة الأصلية لأندرويد (WhatsApp/Telegram/بريد/...) —
 مؤكَّد بفحص classes.dex مباشرة. هذا يُبسِّط كثيراً سير العمل الحالي: بدل تصدير الملف ثم
 البحث عنه يدوياً وإرساله، زر واحد يفتح شاشة المشاركة مباشرة بالملف جاهزاً للإرسال. */
async function shareBans(fmt){
 const built=_buildBansExportContent(fmt);
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للمشاركة','err');return;}
 const {filename,content,mime,bansCount,zonesCount}=built;
 if(!navigator.share){
 _showExpMsg(' المشاركة الأصلية غير مدعومة في هذا البناء — استخدم زر التنزيل بدلاً منها','err');
 return;
 }
 // تصحيح: تنسيق csv لا يتضمّن بيانات مناطق التداخل إطلاقاً داخل الملف نفسه (انظر
 // _buildBansExportContent أعلاه — قسم csv لا يكتب أي صفوف لمناطق التداخل)، فذكر عددها في
 // نص المشاركة كان يُوهِم المستلم بأن تلك المناطق مرفقة ضمن الملف المُشارَك رغم غيابها فعلياً.
 const zonesNote=(fmt==='csv')?'':(' + '+zonesCount+' منطقة تداخل جديدة');
 try{
 const file=new File([content],filename,{type:mime});
 const shareData={
 files:[file],
 title:'ZERO AI v25 — تصدير الحظر',
 text:bansCount+' تردد جديد'+zonesNote
 };
 if(navigator.canShare&&!navigator.canShare(shareData)){
 _showExpMsg(' مشاركة الملفات غير مدعومة هنا — استخدم زر التنزيل بدلاً منها','err');
 return;
 }
 await navigator.share(shareData);
 _showExpMsg('✓ فُتحت شاشة المشاركة: '+filename,'ok');
 stLog(' Ban share: '+filename+' ('+bansCount+' تردد جديد'+zonesNote+')');
 }catch(e){
 if(e&&e.name==='AbortError')return; // المستخدم أغلق شاشة المشاركة — ليس خطأ
 _showExpMsg(' فشلت المشاركة: '+e.message,'err');
 }
}

/* ── نسخ نصّ التصدير (TXT) مباشرة للحافظة — بديل أسرع من المشاركة عند إرسال رسالة نصّية
 قصيرة (بلا مرفق ملف)، كما في لصق المحتوى مباشرة داخل محادثة. ── */
async function copyBansToClipboard(){
 const built=_buildBansExportContent('txt');
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للنسخ','err');return;}
 if(!navigator.clipboard||typeof navigator.clipboard.writeText!=='function'){
 _showExpMsg(' النسخ للحافظة غير مدعوم في هذا البناء','err');
 return;
 }
 try{
 await navigator.clipboard.writeText(built.content);
 _showExpMsg('✓ نُسخ الملخّص للحافظة ('+built.bansCount+' تردد + '+built.zonesCount+' تداخل)','ok');
 stLog(' Ban summary copied to clipboard ('+built.bansCount+' bans + '+built.zonesCount+' zones)');
 }catch(e){
 _showExpMsg(' فشل النسخ: '+e.message,'err');
 }
}

/* ── نسخ JSON (وليس TXT الوصفي) للحافظة — هذا هو التنسيق الوحيد القابل للدمج عبر
 _mergeImportedBansJSON، فهو ما يُستخدَم فعلياً لنقل القائمة بين جهازين عبر اللصق. ── */
async function copyBansJSONToClipboard(){
 const built=_buildBansExportContent('json');
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للنسخ','err');return;}
 if(!navigator.clipboard||typeof navigator.clipboard.writeText!=='function'){
 _showExpMsg(' النسخ للحافظة غير مدعوم في هذا البناء','err');
 return;
 }
 try{
 await navigator.clipboard.writeText(built.content);
 _showExpMsg('✓ نُسخ JSON للحافظة ('+built.bansCount+' تردد + '+built.zonesCount+' تداخل) — الصقه في التطبيق على الجهاز الآخر','ok');
 stLog(' Ban JSON copied to clipboard ('+built.bansCount+' bans + '+built.zonesCount+' zones)');
 }catch(e){
 _showExpMsg(' فشل النسخ: '+e.message,'err');
 }
}

/* ── استيراد مباشر من الحافظة — يقرأ آخر نصّ منسوخ (يُفترض JSON من الزر أعلاه على جهاز
 آخر) ويدمجه عبر نفس منطق الاستيراد المشترك. لا يعتمد على أي إذن SAF أو مجلد ثابت. ── */
async function pasteImportFromClipboard(){
 if(!navigator.clipboard||typeof navigator.clipboard.readText!=='function'){
 _showExpMsg(' القراءة من الحافظة غير مدعومة في هذا البناء','err');
 return;
 }
 try{
 const text=await navigator.clipboard.readText();
 if(!text||!text.trim()){_showExpMsg(' الحافظة فارغة — انسخ JSON من الجهاز الآخر أولاً','err');return;}
 const res=_mergeImportedBansJSON(text,'الحافظة (لصق)');
 _showExpMsg('✓ استُورد من الحافظة: '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(e){
 if(e instanceof SyntaxError){_showExpMsg(' محتوى الحافظة ليس JSON صحيحاً لهذا التطبيق','err');return;}
 _showExpMsg(' فشل الاستيراد من الحافظة: '+e.message,'err');
 }
}

/* ── منطق دمج مشترك لاستيراد ملف JSON (ترددات + مناطق تداخل) — يستخدمه كل من
 importBanFile (اختيار ملف عبر متصفح النظام) وimportFromFixedFolder (قراءة مباشرة
 من المجلد الثابت عبر WebToApkFS)، لتفادي ازدواج المنطق وتضاربه مستقبلاً. ── */
function _mergeImportedBansJSON(raw,sourceLabel){
 const data=JSON.parse(raw);
 if(!data.bans||!Array.isArray(data.bans)){
 throw new Error('صيغة الملف غير صحيحة — يجب أن يحتوي على مفتاح "bans"');
 }
 let added=0,skipped=0;
 // تأكيد متقاطع بين الأجهزة: كل استيراد يمثّل جهازاً/جلسة أخرى رصدت نفس التردد بشكل
 // مستقل. نعُدّ ذلك دليلاً إضافياً — لا نستبدل حكم هذا الجهاز الخاص (verdict) المبني على
 // قياسه الفعلي لطاقة ما بعد الحظر، بل نُسجِّل حكم المصدر المستورَد بجانبه (importedVerdict)
 // ونقارن: تطابق الحكمين يرفع الثقة، وتعارضهما (env هنا وspk هناك) يشير غالباً إلى تردد
 // خاص بجهاز واحد (كسماعته الخاصة) وليس تداخلاً بيئياً عاماً يستحق حظراً على كل الأجهزة.
 let crossConfirmed=0,verdictConflicts=0;
 // تنظيف المُدخَل أولاً: نتجاهل أي عنصر تالف (غير كائن، أو hz غير رقمي/غير منتهٍ — كانت
 // تُفرَض NaN كمفتاح Map فتتحوّل إلى null صامتاً عند JSON.stringify/الحفظ، فتُكسِّر كل
 // عرض لاحق لقائمة الحظر بعد إعادة التشغيل)، ونُوحِّد أي تكرار لنفس الخانة 0.5Hz ضمن نفس
 // الملف إلى معالجة واحدة فقط (وإلا يُحتسَب "تأكيد متقاطع" زائف من نفس الملف نفسه، لا من
 // مصدر مستقل آخر فعلاً).
 const seenBins=new Set();
 data.bans.forEach(b=>{
 if(!b||typeof b!=='object'){skipped++;return;}
 const hzNum=Number(b.hz);
 if(!isFinite(hzNum)){skipped++;return;}
 const bin=fBin(hzNum);
 if(seenBins.has(bin))return; // تكرار داخل نفس الملف — يُتجاهَل صامتاً
 seenBins.add(bin);
 const importedVerdict=b.verdict||null;
 if(!AI_BAN.has(bin)){
 AI_BAN.set(bin,{
 hz:bin,reason:b.reason||'Imported',
 bannedAt:execCyc,cycles:0,
 autoUnbanAt:Infinity,permanent:true,
 category:b.category||'custom',
 preBanEnergy:b.preBanEnergy||0,
 postBanDetections:0,lastPostBanEnergy:0,
 probEnvironmental:null,verdict:null,
 crossConfirms:1,importedVerdict,verdictAgreement:null
 });
 added++;
 }else{
 const e=AI_BAN.get(bin);
 e.crossConfirms=(e.crossConfirms||0)+1;
 e.importedVerdict=importedVerdict;
 if(e.verdict&&importedVerdict){
 e.verdictAgreement=(e.verdict===importedVerdict)?'agree':'conflict';
 if(e.verdictAgreement==='agree')crossConfirmed++;else verdictConflicts++;
 }
 }
 });
 if(skipped>0)stLog(' تُجوهِل '+skipped+' إدخال بلا تردد رقمي صالح أثناء الاستيراد من '+sourceLabel);
 if(verdictConflicts>0)stLog(' '+verdictConflicts+' تردد لديه تعارض في الحكم بين هذا الجهاز والمصدر المستورَد — قد يكون خاصاً بجهاز واحد');
 if(crossConfirmed>0)stLog(' '+crossConfirmed+' تردد تأكَّد حكمه (env/spk) بشكل مستقل من '+sourceLabel);
 // تشديد: استعادة مناطق التداخل أيضاً — كانت مفقودة كلياً من الاستيراد سابقاً رغم أن
 // exportBans('json') يُصدّرها فعلياً ضمن مفتاح "interference"؛ الآن يُستكمَل الدوران
 // الكامل تصدير↔استيراد، وهو ضروري كنسخة احتياطية يدوية لأن هذا الجهاز لا يملك أي
 // تخزين أندرويد أصلي مخصَّص (localStorage/WebToApkFS فقط، قابلان للمسح/الإلغاء).
 let zonesAdded=0,zonesCrossConfirmed=0,zonesSkipped=0;
 if(Array.isArray(data.interference)){
 const seenZoneBins=new Set();
 data.interference.forEach(z=>{
 if(!z||typeof z!=='object'){zonesSkipped++;return;}
 const hzNum=Number(z.hz);
 if(!isFinite(hzNum)){zonesSkipped++;return;}
 const bin=fBin(hzNum);
 if(seenZoneBins.has(bin))return; // تكرار داخل نفس الملف
 seenZoneBins.add(bin);
 if(!INTERFERENCE_BAN.zones.has(bin)){
 INTERFERENCE_BAN.zones.set(bin,{count:z.count||0,widen:z.widenHz||0,lastT:z.lastAt||0,crossConfirms:1});
 zonesAdded++;
 }else{
 // تأكيد متقاطع لمناطق التداخل أيضاً — نفس مبدأ الترددات المحظورة: لا نستبدل عدّاد
 // التصعيد المحلي (count/widen) الخاص بهذا الجهاز، لكن رصد نفس منطقة التداخل من
 // جهاز آخر مستقل دليل إضافي على أنها تداخل بيئي حقيقي ومتكرر لا ضجيج عابر.
 const zz=INTERFERENCE_BAN.zones.get(bin);
 zz.crossConfirms=(zz.crossConfirms||0)+1;
 zonesCrossConfirmed++;
 }
 });
 }
 if(zonesSkipped>0)stLog(' تُجوهِلت '+zonesSkipped+' منطقة تداخل بلا تردد رقمي صالح أثناء الاستيراد من '+sourceLabel);
 if(zonesCrossConfirmed>0)stLog(' '+zonesCrossConfirmed+' منطقة تداخل تأكَّدت بشكل مستقل من '+sourceLabel);
 PERSIST.saveBans();
 // تشديد: يجب الحفظ أيضاً حين يكون التغيير الوحيد هو تحديث crossConfirms على مناطق
 // موجودة مسبقاً (zonesAdded=0) — وإلا يُفقَد التأكيد المتقاطع بصمت عند إعادة التشغيل.
 if(zonesAdded||zonesCrossConfirmed)PERSIST.saveZones();
 renderBanList();renderPermSettings();
 stLog(' Ban import: '+added+' bans + '+zonesAdded+' zones added from '+sourceLabel);
 return {added,zonesAdded,totalBans:data.bans.length,crossConfirmed,verdictConflicts,zonesCrossConfirmed,skipped,zonesSkipped};
}

function importBanFile(){
 const inp=document.createElement('input');
 inp.type='file';inp.accept='.json';
 inp.onchange=e=>{
 const file=e.target.files[0];if(!file)return;
 const r=new FileReader();
 r.onload=ev=>{
 try{
 const res=_mergeImportedBansJSON(ev.target.result,file.name);
 _showExpMsg('✓ تم استيراد '+res.added+' تردد من '+res.totalBans+' ('+
 (res.totalBans-res.added)+' موجود مسبقاً)'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(ex){_showExpMsg(' خطأ في قراءة الملف: '+ex.message,'err');}
 };
 r.readAsText(file);
 };
 inp.click();
}

/* ══ WebToApkFS — طبقة تخزين أندرويد أصلية فعلية ("My Files") ══
 تشديد جوهري (اكتُشف عند فحص الملف المضغوط الذي أرسله المستخدم): التطبيق الفعلي الذي
 يشغّل هذا الكود مبني عبر خدمة تجارية عامة لتحويل موقع إلى APK (قائمة على Capacitor)، ولا
 يحتوي جسر ZeroAndroid المخصَّص إطلاقاً (تأكَّد عبر فحص classes.dex مباشرة). لكنه يحتوي
 جسراً بديلاً حقيقياً وفعّالاً: window.WebToApkFS — يمنح وصولاً دائماً (Android Storage
 Access Framework) لمجلد يختاره المستخدم مرة واحدة فقط، مع قراءة/كتابة ملفات نصّية مباشرة
 على ذلك المسار الثابت. هذا أقوى بكثير من الاعتماد على localStorage وحده: ملفات حقيقية
 ومرئية للمستخدم، يمكن تصفّحها أو نسخها احتياطياً يدوياً من أي تطبيق ملفات على الجهاز. */
/* تشديد جوهري (اكتُشف بفك ترجمة الكود الأصلي المُصرَّف فعلياً عبر jadx — ليس فقط الكود
 المحقون في WebView): window.WebToApk.isFolderAccessEnabled() على الجهاز الحقيقي تعود
 من دالة Java تقرأ حرفياً appConfig.h0، وهذا بدوره حقل واحد فقط في إعدادات البناء
 (config.json) اسمه الفعلي "permSafFolderAccess" — قيمته الافتراضية false إن لم يُفعَّله
 منشئ التطبيق صراحةً من لوحة تحكم خدمة "تحويل الموقع إلى APK". وهذا نفس الحقل بالضبط الذي
 يتحكم أيضاً بـ pickFile/readFileBase64/writeFileBase64 — أي أن أي بديل "اختيار ملف" سيُمنع
 لنفس السبب حرفياً طالما هذا الحقل معطَّل، بصرف النظر عن أي كود JS يُكتب هنا. */
function _wtafsBridgePresent(){return typeof WebToApk!=='undefined';}
function _wtafsOk(){return typeof WebToApkFS!=='undefined'&&WebToApkFS.isAvailable&&WebToApkFS.isAvailable();}
/* استفادة من ميزات تطبيق "الملفات" (My Files) الحقيقي على الجهاز: أسماء ملفات مقروءة
 للبشر — قبل هذا التعديل كانت freqdb_/nn_/session_/zero-freq-partitions-/ZeroAI_FreqDB_
 تُسمَّى كلها بطابع Unix خام (مثل freqdb_1758814593421.json)، لا يعني شيئاً عند تصفّح
 المجلد الثابت عبر تطبيق الملفات الحقيقي — على عكس ZERO_Bans_/ZeroAI_v25_ اللذين استُخدم
 لهما تاريخ ISO مقروء منذ البداية. لاحقة الميلي ثانية تحافظ على نفس ضمان التفرّد الذي كان
 يوفره Date.now() الخام (يمنع تراكب اسمين عند ضغطتين سريعتين خلال نفس الثانية). */
function _isoFname(){
 const d=new Date();
 return d.toISOString().slice(0,19).replace(/:/g,'-')+'-'+String(d.getMilliseconds()).padStart(3,'0');
}
/* استفادة إضافية من My Files/نظام أندرويد: "متطلبات التطبيق" — عرض فعلي لموارد الجهاز
 (معالج/ذاكرة/تخزين) وحجم محتويات المجلد الثابت نفسه، بالاعتماد حصراً على Web APIs مؤكَّدة
 (لا افتراض أي حقل غير موثَّق):
 - navigator.hardwareConcurrency: عدد الأنوية المنطقية (مدعوم في كل متصفحات Chromium/WebView)
 - navigator.deviceMemory: تقدير تقريبي للذاكرة بالجيجابايت (Device Memory API — Chromium فقط،
 قد لا يكون مدعوماً في كل الأجهزة، ولذلك مفحوص بـ typeof قبل الاستخدام)
 - navigator.storage.estimate(): حصة/استخدام التخزين الفعلي لأصل هذا التطبيق (StorageManager)
 - حجم المجلد الثابت: مُشتق من قراءة محتوى كل ملف فعلياً وحساب طوله بالبايت (Blob.size)، وليس
 من حقل "size" غير مؤكَّد في WebToApkFS.list() — بحدٍّ أقصى WTAFS_SIZE_SCAN_MAX ملفاً (أحدثها)
 تفادياً لبطء قراءات SAF المتكررة على جهاز حقيقي عند تراكم عشرات الملفات. */
const WTAFS_SIZE_SCAN_MAX=30;
/* "تشديد اكثر": renderWtafsResourcesInfo تحوي نقطة انتظار وحيدة (storage.estimate) وتُستدعى من
 عدة أماكن (منح/حذف/تحديث يدوي) دون انتظار (fire-and-forget) — نقرتان سريعتان متتاليتان (أو
 حذف ملف مباشرة بعد فتح اللوحة) يُطلقان نداءين متداخلين، وعلى جهاز حقيقي حيث زمن estimate()
 فعلي (I/O قرص) لا مضمون الترتيب، قد ينتهي النداء الأقدم بعد الأحدث ويكتب فوق العرض ببيانات
 قديمة (حجم/حالة مجلد سابقة). رقم جيل يُميِّز أحدث نداء بُدئ ويجعل أي نداء أقدم ينتهي متأخراً
 يتجاهل نتيجته بدل رسمها فوق الأحدث. */
let _wtafsResourcesGen=0;
async function renderWtafsResourcesInfo(){
 const el=E('wtafs-resources-text');
 if(!el)return;
 const myGen=++_wtafsResourcesGen;
 const lines=[];
 lines.push(' المعالج: '+(typeof navigator.hardwareConcurrency==='number'?navigator.hardwareConcurrency+' أنوية منطقية':'غير مُتاح في هذا البناء'));
 lines.push(' الذاكرة (تقريبي): '+(typeof navigator.deviceMemory==='number'?'~'+navigator.deviceMemory+' GB':'غير مُتاح في هذا البناء'));
 lines.push(' الاتصال: '+(navigator.onLine?'متصل':'غير متصل'));
 el.textContent=lines.join(' · ');
 if(navigator.storage&&typeof navigator.storage.estimate==='function'){
 try{
 const est=await navigator.storage.estimate();
 const usedMB=((est.usage||0)/1048576).toFixed(1);
 const quotaMB=est.quota?(est.quota/1048576).toFixed(0):null;
 lines.push(' تخزين التطبيق: '+usedMB+' م.ب'+(quotaMB?' من أصل ~'+quotaMB+' م.ب':''));
 if(myGen===_wtafsResourcesGen)el.textContent=lines.join(' · ');
 }catch(e){/* بعض الأجهزة لا تدعم estimate() فعلياً رغم وجود الدالة — تجاهل بصمت */}
 }
 if(myGen!==_wtafsResourcesGen)return; // نداء أحدث بدأ (وربما انتهى) أثناء الانتظار أعلاه — تجاهل الباقي
 if(_wtafsOk()&&WebToApkFS.hasAccess()){
 try{
 const entries=_wtafsListSafe();
 const names=entries.filter(e=>e&&e.name&&!e.isDirectory).map(e=>e.name).sort().reverse();
 const scanNames=names.slice(0,WTAFS_SIZE_SCAN_MAX);
 let totalBytes=0;
 // "تشديد اكثر": readText لكل ملف على حدة داخل try خاص به — ملف واحد غير قابل للقراءة
 // (حُذف خارجياً بين list() وreadText() نفسها — فجوة TOCTOU حقيقية على SAF حين يعدّل
 // تطبيق ملفات آخر المجلد بالتزامن، أو ملف تالف، أو خطأ إذن عابر) كان سيُسقِط الحساب كله
 // عبر try/catch الخارجي الوحيد، فيختفي سطر "المجلد الثابت" بالكامل بدل تجاهل ملف واحد فقط
 // فقط ضمن المجموع — نفس نمط العزل لكل عنصر المُطبَّق أصلاً في _applyCleanupPatternToEntries.
 scanNames.forEach(name=>{
 try{
 const raw=WebToApkFS.readText(name);
 if(raw)totalBytes+=new Blob([raw]).size;
 }catch(e){/* ملف واحد فاشل لا يُسقط حساب البقية */}
 });
 const totalKB=(totalBytes/1024).toFixed(1);
 const approx=names.length>scanNames.length;
 lines.push(' المجلد الثابت: '+names.length+' ملف — '+(approx?'~':'')+totalKB+' ك.ب'+(approx?' (تقدير من أحدث '+WTAFS_SIZE_SCAN_MAX+' ملفاً)':''));
 el.textContent=lines.join(' · ');
 }catch(e){/* تعذّر مسح المجلد — الأسطر الأخرى تبقى ظاهرة بلا انقطاع */}
 }
}
function updateFolderAccessUI(){
 const st=E('wtafs-status'),grantBtn=E('wtafs-grant-btn'),clearBtn=E('wtafs-clear-btn'),restoreBtn=E('wtafs-restore-btn'),
 restoreBackupBtn=E('wtafs-restore-backup-btn'),pickBackupBtn=E('wtafs-pick-backup-btn'),
 pickBtn=E('wtafs-pick-btn'),pickRow=E('wtafs-pickfile-row'),
 browserRow=E('wtafs-browser-row'),browserList=E('wtafs-file-browser-list');
 if(!st)return;
 const hasPicked=!!localStorage.getItem(_pickedFileKey());
 if(typeof WebToApkFS==='undefined'){
 // البناء لا يحتوي هذا الجسر إطلاقاً (متصفح عادي، أو خدمة مختلفة كلياً) — موارد الجهاز
 // العامة (معالج/ذاكرة/تخزين) لا تعتمد على WebToApkFS إطلاقاً، فتبقى ظاهرة رغم ذلك.
 renderWtafsResourcesInfo();
 st.textContent='هذا البناء لا يدعم الوصول لمجلد ثابت (WebToApkFS غير متاح) — يُستخدَم localStorage فقط';
 st.className='ban-exp-msg err';
 if(grantBtn)grantBtn.style.display='none';
 if(clearBtn)clearBtn.style.display='none';
 if(restoreBtn)restoreBtn.style.display='none';
 if(restoreBackupBtn)restoreBackupBtn.style.display='none';
 if(pickBackupBtn)pickBackupBtn.style.display='none';
 if(pickBtn)pickBtn.style.display='none';
 if(pickRow)pickRow.style.display='none';
 if(browserRow)browserRow.style.display='none';
 if(browserList)browserList.innerHTML='';
 return;
 }
 if(!_wtafsOk()){
 // الجسر موجود فعلياً في هذا التطبيق، لكن مُعطَّل من إعدادات البناء — هذا يفسّر بالضبط
 // عدم ظهور أي نافذة أذونات عند الضغط: الطلب لا يصل حتى لنظام أندرويد. موارد الجهاز العامة
 // تبقى ظاهرة رغم ذلك (لا علاقة لها بتعطيل WebToApkFS).
 renderWtafsResourcesInfo();
 st.textContent='الميزة موجودة في هذا التطبيق لكنها مُعطَّلة من إعدادات البناء — '+
 'فعِّل إذن "SAF Folder Access" (اسمه في الإعدادات: permSafFolderAccess) من لوحة '+
 'تحكم الخدمة التي أنشأت هذا التطبيق، ثم أعد بناء/تنزيل وتثبيت التطبيق. لن تظهر أي '+
 'نافذة اختيار مجلد أو ملف قبل ذلك مهما ضغطت — القيد من جهة إعدادات البناء لا الكود.';
 st.className='ban-exp-msg err';
 if(grantBtn)grantBtn.style.display='none';
 if(clearBtn)clearBtn.style.display='none';
 if(restoreBtn)restoreBtn.style.display='none';
 if(restoreBackupBtn)restoreBackupBtn.style.display='none';
 if(pickBackupBtn)pickBackupBtn.style.display='none';
 if(pickBtn)pickBtn.style.display='none';
 if(pickRow)pickRow.style.display='none';
 if(browserRow)browserRow.style.display='none';
 if(browserList)browserList.innerHTML='';
 return;
 }
 // استفادة من ميزة اختيار الملفات: تعمل بصرف النظر عن منح وصول المجلد الكامل من عدمه —
 // على عكس بديل "اختيار ملف ثابت" الخاص بالحظر (يظهر فقط حين لا يكون المجلد ممنوحاً بعد،
 // لأنه بديل عنه)، فهذا زر استيراد فوري لمرة واحدة لا يتعارض مع حالة المجلد إطلاقاً.
 if(pickBackupBtn)pickBackupBtn.style.display=(typeof WebToApkFS.pickFile==='function')?'':'none';
 const has=WebToApkFS.hasAccess();
 if(has){
 const uri=WebToApkFS.getAccessUri();
 st.textContent='✓ مُفعَّل — المسار: '+(uri||'(غير معروف)');
 st.className='ban-exp-msg ok';
 if(grantBtn)grantBtn.style.display='none';
 if(clearBtn)clearBtn.style.display='';
 if(restoreBtn)restoreBtn.style.display='';
 if(restoreBackupBtn)restoreBackupBtn.style.display='';
 if(pickBtn)pickBtn.style.display='none';
 if(pickRow)pickRow.style.display=hasPicked?'':'none';
 // استفادة أكبر من My Files: تصفّح فعلي لمحتويات المجلد — يظهر فقط بعد منح الوصول،
 // ويتحدَّث تلقائياً في كل مرة تُفتح فيها لوحة "الملفات" أو يتغيَّر وضع الوصول.
 if(browserRow)browserRow.style.display='';
 renderFixedFolderBrowser();
 }else{
 // لم يُمنَح الوصول بعد — لا يُستدعى renderFixedFolderBrowser() في هذا الفرع، فيُستدعى هنا
 // مباشرة كي تبقى موارد الجهاز العامة ظاهرة حتى قبل منح الوصول (سطر حجم المجلد وحده يُخفى
 // تلقائياً لعدم وجود وصول بعد — الشرط داخل renderWtafsResourcesInfo نفسها).
 renderWtafsResourcesInfo();
 st.textContent='غير مُفعَّل بعد — اضغط "منح الوصول" لاختيار مجلد ثابت مرة واحدة، أو استخدم '+
 'اختيار ملف ثابت أدناه كبديل أخفّ';
 st.className='ban-exp-msg';
 if(grantBtn)grantBtn.style.display='';
 if(clearBtn)clearBtn.style.display='none';
 if(restoreBtn)restoreBtn.style.display='none';
 if(restoreBackupBtn)restoreBackupBtn.style.display='none';
 if(pickBtn)pickBtn.style.display=(typeof WebToApkFS.pickFile==='function')?'':'none';
 if(pickRow)pickRow.style.display=(hasPicked&&typeof WebToApkFS.pickFile==='function')?'':'none';
 if(browserRow)browserRow.style.display='none';
 if(browserList)browserList.innerHTML='';
 }
}
async function requestFixedFolder(){
 if(!_wtafsOk())return;
 try{
 const r=await WebToApkFS.requestAccess();
 updateFolderAccessUI();
 if(r&&r.success){
 // مزامنة فورية: كل ما هو محفوظ حالياً (في localStorage) يُكتب أيضاً في المجلد الجديد فوراً
 PERSIST.saveBans();PERSIST.saveZones();PERSIST.saveCats();PERSIST.saveNN();PERSIST.saveFC();PERSIST.saveRoomModes();PERSIST.saveWienerNF();
 updateFolderAccessUI();
 stLog(' WebToApkFS: تم منح وصول مجلد ثابت + مزامنة فورية للبيانات الحالية');
 }else{
 stLog(' WebToApkFS: فشل/أُلغي طلب الوصول'+(r&&r.error?(' — '+r.error):''));
 }
 }catch(e){stLog(' WebToApkFS requestAccess error: '+e.message);}
}
function clearFixedFolder(){
 if(!_wtafsOk())return;
 try{WebToApkFS.clearAccess();}catch(e){}
 updateFolderAccessUI();
 stLog(' WebToApkFS: أُلغي الوصول للمجلد الثابت (localStorage يبقى نسخة احتياطية كما هو معتاد)');
}
/* تنظيف تلقائي للمجلد الثابت: كل تصدير جديد يكتب ملف ZERO_Bans_<طابع زمني>.json منفصلاً —
 دون تنظيف سيتراكم ملف جديد مع كل تصدير إلى الأبد. نُبقي فقط أحدث N نسخة ونحذف الأقدم،
 حتى لا يمتلئ مجلد المستخدم الثابت بمئات الملفات بعد أسابيع من الاستخدام اليومي. */
const WTAFS_MAX_EXPORTS_KEPT=15;
/* تشديد أكثر: نفس المنطق أعلاه بالضبط لكن مُعمَّم لأي نمط اسم — كي يُعاد استخدامه لكل نقاط
 الكتابة الجديدة التي أضافها تعميم WebToApkFS (androidWrite/saveFreqPartitions)، والتي كانت
 ستتراكم بلا حد أقصى تماماً كما كانت مشكلة ZERO_Bans_ الأصلية قبل وجود هذه الدالة إطلاقاً. */
/* تطبيق نمط واحد على قائمة ملفات جاهزة مسبقاً (بلا أي نداء list() جديد) — الأساس المشترك
 الذي تُبنى عليه كل من _cleanupFixedFolderPattern (نمط واحد، يجلب القائمة بنفسه) و
 _cleanupFixedFolderBackups (عدة أنماط، تتقاسم قائمة واحدة — انظر التعليق أدناه). */
