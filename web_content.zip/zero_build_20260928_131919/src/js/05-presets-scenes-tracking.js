/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 05-presets-scenes-tracking.js
 الإعدادات المسبقة (Presets) + تصنيف البيئة + تتبع/تكيّف الـ Notch + مقياس المستوى + حفظ/تحميل المشاهد (Scenes)
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
let curTab=0;
let statsIv=null; // auto-refresh interval for STATS tab
// ── Power Presets & Thermal Throttle ──
let thermalThrottleOn=false;
let curPreset='balanced';
let lastFreqDBSave=null;
const SESSION_START=Date.now();
const PRESETS={
 low:{fftIdx:0,detMs:80,alpha:1.0,sf:false,label:'توفير',emoji:'',desc:' توفير — FFT 4096 · كشف 80ms · طبقات مخففة · α 1.0'},
 balanced:{fftIdx:1,detMs:40,alpha:1.5,sf:true,label:'متوازن',emoji:'',desc:' متوازن — FFT 8192 · كشف 40ms · جميع الطبقات مفعّلة · α 1.5'},
 full:{fftIdx:2,detMs:20,alpha:2.0,sf:true,label:'كامل',emoji:'',desc:' كامل — FFT 16384 · كشف 20ms · جميع الطبقات مفعّلة · α 2.0'}
};

function setThermalThrottle(on){
 thermalThrottleOn=on;
 const badge=E('therm-badge');
 if(badge)badge.style.display=on?'inline-flex':'none';
 if(on){
 // slow detection to 90ms during thermal stress
 if(typeof aT!=='undefined'&&aT){clearInterval(aT);aT=setInterval(detectAll,90);}
 // زيادة "النسخة النهائية": المذبذبات فوق الصوتية تُخزَّن في silOscs بمفاتيح مسطَّحة
 // ('u0','u1',...للمذبذب نفسه، 'ug0','ug1',...لعقدة GainNode المقابلة — راجع startSF/updSF)
 // — لا كخاصية silOscs.ultra إطلاقاً (غير موجودة قط)، فكان هذا الشرط دائماً false والتخفيف
 // الحراري المقصود (تصفير كسب الطبقة فوق الصوتية لخفض الحمل أثناء الإجهاد الحراري) لم يكن
 // يُنفَّذ إطلاقاً رغم أن سجل التنفيذ يوحي بأنه يعمل.
 if(typeof silOscs!=='undefined'){
 try{Object.keys(silOscs).forEach(k=>{if(k.indexOf('ug')===0&&silOscs[k]&&silOscs[k].gain)silOscs[k].gain.value=0;});}catch(e){}
 }
 } else {
 // restore to current preset detection rate
 const ms=PRESETS[curPreset]?PRESETS[curPreset].detMs:40;
 if(typeof aT!=='undefined'&&aT){clearInterval(aT);aT=setInterval(detectAll,ms);}
 // استعادة كسب المذبذبات فوق الصوتية — نفس المفاتيح الحقيقية أعلاه
 if(typeof silOscs!=='undefined'){
 try{Object.keys(silOscs).forEach(k=>{if(k.indexOf('ug')===0&&silOscs[k]&&silOscs[k].gain)silOscs[k].gain.value=0.001;});}catch(e){}
 }
 }
}

function applyPreset(name){
 const p=PRESETS[name];if(!p)return;
 curPreset=name;
 // FFT size
 if(typeof ANTI_IDLE!=='undefined'&&ANTI_IDLE.fftSizes){
 ANTI_IDLE.fftSizeIdx=p.fftIdx;
 // مراجعة "النسخة النهائية": المحلِّل الفعلي مُخزَّن في المتغيّر العام `ana` (يُنشَأ في
 // initAudio عبر actx.createAnalyser())، لا `analyser` — الذي لم يُعرَّف إطلاقاً في أي مكان
 // آخر من الملف، فكان `typeof analyser!=='undefined'` يفشل بصمت دائماً (بلا استثناء ظاهر)
 // وحجم FFT الفعلي لا يتغيّر أبداً عند تبديل الإعداد المسبق (Preset)، رغم أن الواجهة ومعدّل
 // الكشف وAlpha تتحدَّث بشكل صحيح — خلل حقيقي في ميزة رئيسية، لا مجرد أسلوب.
 try{if(typeof ana!=='undefined'&&ana)ana.fftSize=ANTI_IDLE.fftSizes[p.fftIdx];}catch(e){}
 }
 // Detection rate (only if currently running)
 if(typeof aT!=='undefined'&&aT&&!thermalThrottleOn){
 clearInterval(aT);aT=setInterval(detectAll,p.detMs);
 }
 // Alpha
 if(typeof P!=='undefined')P.alpha=p.alpha;
 // SF layer — مراجعة "المشروع بالكامل": P.useSF كائن حالة لكل طبقة على حدة
 // ({inf,ult,phf,sub,pie}) تقرأه updSF() (P.useSF.inf/.ult/...) وتكتبه مفاتيح الإعدادات
 // اليدوية sw-inf/sw-ult/... — لكن هذا السطر كان يستبدل الكائن بأكمله بقيمة منطقية خام
 // (p.sf: true/false)، فتصبح P.useSF نفسها true أو false. النتيجة: كل قراءة P.useSF.inf
 // (وبقية الطبقات) تعمل على خاصية لعنصر بدائي فتُرجِع undefined دوماً (كقيمة مزيّفة) —
 // فتتوقف طبقة "الترددات الصامتة" (Silent Frequencies) بأكملها فور الضغط على أي إعداد قوة
 // مسبق (Preset)، بما فيها "كامل" التي يُفترض أن تُفعِّل كل الطبقات. والأسوأ: بما أن الملف
 // صارم (use strict)، أي تبديل يدوي لاحق لأحد المفاتيح (P.useSF.inf=v) يرمي استثناءً غير
 // معالَج بدل أن يفشل بصمت. الإصلاح: تحديث كل مفتاح فرعي داخل نفس الكائن، لا استبدال الكائن.
 if(typeof P!=='undefined'&&P.useSF){P.useSF.inf=p.sf;P.useSF.ult=p.sf;P.useSF.phf=p.sf;P.useSF.sub=p.sf;P.useSF.pie=p.sf;}
 // UI update
 ['lp','bl','fp'].forEach((id,idx)=>{
 const btn=E('preset-'+id);
 if(btn)btn.classList.toggle('act',['low','balanced','full'][idx]===name);
 });
 const desc=E('preset-desc');if(desc)desc.textContent=p.desc;
 if(typeof updateStatsTab==='function')updateStatsTab();
}

async function saveFreqDB(){
 try{
 if(typeof freqDB==='undefined'||!freqDB||!freqDB.size||!zeroDB)return;
 const tx=zeroDB.transaction('freq_patterns','readwrite');
 const st=tx.objectStore('freq_patterns');
 freqDB.forEach((v,k)=>{
 // freq_patterns keyPath='hz' — merge hz into value object
 st.put(Object.assign({},v,{hz:k}));
 });
 await new Promise((res,rej)=>{tx.oncomplete=res;tx.onerror=()=>res();});
 lastFreqDBSave=new Date();
 }catch(e){console.warn('saveFreqDB:',e);}
}

async function loadFreqDB(){
 try{
 if(typeof freqDB==='undefined'||!zeroDB)return;
 const tx=zeroDB.transaction('freq_patterns','readonly');
 const st=tx.objectStore('freq_patterns');
 const req=st.getAll();
 await new Promise((res,rej)=>{req.onsuccess=res;req.onerror=()=>res();});
 const rows=req.result||[];
 rows.forEach(row=>{
 const k=row.hz;
 if(k!=null&&!freqDB.has(k))freqDB.set(k,row);
 });
 if(rows.length)console.log('[ZER0] loadFreqDB: restored',rows.length,'freq_patterns');
 }catch(e){console.warn('loadFreqDB:',e);}
}

/* ══ ENVIRONMENT CLASSIFIER ══ */
const ENV_LABELS={
 quiet:{label:' QUIET',color:'#a5a5a5',ar:'هادئ'},
 tonal:{label:' TONAL',color:'#959595',ar:'طولي'},
 noise:{label:' WHITE NOISE',color:'#818181',ar:'ضوضاء'},
 impulsive:{label:' IMPULSIVE',color:'#cecece',ar:'نبضي'},
 mechanical:{label:' MECHANICAL',color:'#9c9c9c',ar:'ميكانيكي'},
 interference:{label:' INTERFERENCE',color:'#787878',ar:'تداخل'},
 mixed:{label:' MIXED',color:'#aaaaaa',ar:'مختلط'}
};
let curEnvClass='mixed';

function classifyEnvironment(){
 if(!isRun&&!ana)return;
 const sf=typeof SPEC_FLAT!=='undefined'?SPEC_FLAT.val:0;
 const hnr=typeof HNR!=='undefined'?HNR.val:0;
 const zcr=typeof ZCRATE!=='undefined'?ZCRATE.val:0;
 const crest=typeof CREST!=='undefined'?CREST.val:1;
 const sil=silSc/100;
 const dbSz=typeof freqDB!=='undefined'?freqDB.size:0;
 let cls;
 if(sil>0.82)cls='quiet';
 else if(sf>0.68&&zcr>0.28)cls='noise';
 else if(hnr>14&&sf<0.22&&dbSz>0)cls='tonal';
 else if(crest>8&&zcr>0.38)cls='impulsive';
 else if(sf<0.18&&hnr>4&&dbSz>=3&&typeof HARMONICS!=='undefined'&&HARMONICS.series&&HARMONICS.series.length>1)cls='mechanical';
 else if(sf>0.38&&hnr<4)cls='interference';
 else cls='mixed';
 curEnvClass=cls;
 SESSION_STAT.envCount[cls]=(SESSION_STAT.envCount[cls]||0)+1;
 autoPresetCheck();
 const info=ENV_LABELS[cls];
 // Main panel label
 const el=E('envLabel');if(el)el.style.display='flex';
 const lt=E('envLblTxt');if(lt)lt.textContent=info.label;
 const dot=E('envDot');if(dot)dot.style.background=info.color;
 const cf=E('envConf');
 if(cf){
 let d='';
 if(cls==='quiet')d=`${silSc}% silence`;
 else if(cls==='noise')d=`flat ${(sf*100).toFixed(0)}%`;
 else if(cls==='tonal')d=`HNR ${hnr.toFixed(0)}dB`;
 else if(cls==='impulsive')d=`crest ${crest.toFixed(1)}`;
 else if(cls==='mechanical')d=`${dbSz} freqs`;
 else if(cls==='interference')d=`flat ${(sf*100).toFixed(0)}%`;
 cf.textContent=d;
 }
 // Stats tab
 const sse=E('ss-env');if(sse)sse.textContent=info.label;
}

/* ══ FREQUENCY HOP DETECTOR ══ */
const FREQ_HOP={lastHz:0,threshold:12,hops:[],maxLog:30,lastHopT:0,count:0};
function detectFreqHop(hz){
 if(!hz||hz<1)return;
 if(FREQ_HOP.lastHz>1){
 const delta=Math.abs(hz-FREQ_HOP.lastHz);
 if(delta>FREQ_HOP.threshold){
 const now=Date.now();
 if(now-FREQ_HOP.lastHopT>500){
 FREQ_HOP.count++;
 FREQ_HOP.hops.push({from:FREQ_HOP.lastHz,to:hz,delta,t:now});
 if(FREQ_HOP.hops.length>FREQ_HOP.maxLog)FREQ_HOP.hops.shift();
 FREQ_HOP.lastHopT=now;
 const fl=E('freqHopFlash');
 if(fl){fl.style.opacity='1';setTimeout(()=>{fl.style.opacity='0';},700);}
 const ct=E('freqHopCt');if(ct)ct.textContent=`${FREQ_HOP.count} hop${FREQ_HOP.count!==1?'s':''}`;
 logNN(` FREQ HOP: ${FREQ_HOP.lastHz.toFixed(1)}→${hz.toFixed(1)}Hz (Δ${delta.toFixed(1)}Hz)`);
 }
 }
 }
 FREQ_HOP.lastHz=hz;
}

/* ══ AUTO-PRESET BY ENVIRONMENT ══ */
const AUTOPRESET={enabled:false,cooldown:25000,lastSwitch:0,map:{quiet:'low',tonal:'full',mechanical:'full',noise:'balanced',impulsive:'balanced',interference:'balanced',mixed:'balanced'}};
function autoPresetCheck(){
 if(!AUTOPRESET.enabled||!isRun)return;
 const now=Date.now();
 if(now-AUTOPRESET.lastSwitch<AUTOPRESET.cooldown)return;
 const target=AUTOPRESET.map[curEnvClass]||'balanced';
 if(target!==curPreset){
 applyPreset(target);
 AUTOPRESET.lastSwitch=now;
 logNN(` AUTOPRESET: ${curPreset}→${target} (env=${curEnvClass})`);
 }
}

/* ══ SUPPRESSION EFFECTIVENESS ══ */
const SUPP_EFF={val:0,sampN:0};
function updateSuppEff(fdRaw){
 if(!NOTCH_SUPPRESS.size||!actx||!ana){SUPP_EFF.val=0;return;}
 const bHz=actx.sampleRate/ana.fftSize;
 let preE=0,postE=0,n=0;
 NOTCH_SUPPRESS.forEach(({hz,depth,halfBins})=>{
 const bin=Math.round(hz/bHz);
 for(let i=Math.max(0,bin-halfBins);i<=Math.min(fdRaw.length-1,bin+halfBins);i++){
 const raw=fdRaw[i];if(!isFinite(raw))continue;
 const w=1-Math.abs(i-bin)/(halfBins+1);
 const post=raw-depth*w;
 preE+=Math.pow(10,raw/10);postE+=Math.pow(10,post/10);n++;
 }
 });
 if(n>0&&preE>0){
 SUPP_EFF.val=Math.max(0,Math.min(100,Math.round((1-postE/preE)*100)));
 SUPP_EFF.sampN++;SESSION_STAT.suppEffSum+=SUPP_EFF.val;SESSION_STAT.suppEffN++;
 const badge=E('suppEffBadge');
 if(badge){badge.textContent=` · ${SUPP_EFF.val}% eff`;badge.style.color=SUPP_EFF.val>85?'#a5a5a5':SUPP_EFF.val>60?'#b0b0b0':'#7c7c7c';}
 }
}

/* ══ TAP-TO-NOTCH on canvases ══ */
let _tapInit=false;
function initCanvasTap(){
 if(_tapInit)return;_tapInit=true;
 // Spectrogram pane0
 const specC=document.querySelectorAll('#specCv')[0];
 if(specC){
 const tapSpec=ev=>{
 if(!isRun||!actx)return;
 const rect=specC.getBoundingClientRect();
 const x=(ev.clientX!=null?ev.clientX:ev.pageX)-rect.left;
 const pct=Math.max(0,Math.min(1,x/rect.width));
 const nyq=actx.sampleRate/2;
 // تشديد أكثر: hz<1 وحدها لا ترفض NaN — لو كان rect.width=0 (Canvas لم يُخطَّط بعد،
 // ممكن حقاً عند نقر فوري بعد فتح اللوحة) فـx/rect.width قد تُنتِج NaN فتظهر "NaN Hz"
 // في سجلّ NN حتى لو رفضتها activateNotch نفسها لاحقاً — الرفض هنا يمنع حتى محاولة تسجيله
 const hz=pct*nyq;if(!hz||!isFinite(hz)||hz<1)return;
 if(NOTCH_SUPPRESS.has(fBin(hz))){deactivateNotch(hz);logNN(` TAP REMOVE: ${hz.toFixed(1)}Hz`);}
 else{activateNotch(hz);logNN(` TAP NOTCH: ${hz.toFixed(1)}Hz`);}
 };
 specC.addEventListener('click',tapSpec);
 specC.addEventListener('touchend',ev=>{ev.preventDefault();tapSpec(ev.changedTouches[0]);},{passive:false});
 }
 // Freq timeline (y=Hz)
 const tlC=E('freqTimeCv');
 if(tlC){
 const tapTl=ev=>{
 if(!isRun||!actx||FREQ_HIST.hz.length<2)return;
 const rect=tlC.getBoundingClientRect();
 const y=(ev.clientY!=null?ev.clientY:ev.pageY)-rect.top;
 const pct=1-(y/rect.height);
 const nyq=actx.sampleRate/2;
 let maxHz=0;FREQ_HIST.hz.forEach(v=>{if(v>maxHz)maxHz=v;});
 maxHz=Math.min(maxHz*1.25,nyq);if(!isFinite(maxHz)||maxHz<1)return;
 // تشديد أكثر: نفس إصلاح tapSpec أعلاه — hz<1 لا ترفض NaN
 const hz=pct*maxHz;if(!hz||!isFinite(hz)||hz<1)return;
 if(NOTCH_SUPPRESS.has(fBin(hz))){deactivateNotch(hz);logNN(` TAP REMOVE: ${hz.toFixed(1)}Hz`);}
 else{activateNotch(hz);logNN(` TAP NOTCH: ${hz.toFixed(1)}Hz`);}
 };
 tlC.addEventListener('click',tapTl);
 tlC.addEventListener('touchend',ev=>{ev.preventDefault();tapTl(ev.changedTouches[0]);},{passive:false});
 }
}

/* ══ FREQ TIMELINE ══ */
const FREQ_HIST={hz:[],maxLen:1500}; // 1500 × 80ms ≈ 2 minutes

function pushFreqHist(){
 FREQ_HIST.hz.push(fanFreq>0?fanFreq:0);
 if(FREQ_HIST.hz.length>FREQ_HIST.maxLen)FREQ_HIST.hz.shift();
}

function drawFreqTimeline(){
 const cv=E('freqTimeCv');if(!cv)return;
 const dpr=window.devicePixelRatio||1;
 const W=cv.clientWidth||320;const H=52;
 if(cv.width!==Math.round(W*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 ctx.clearRect(0,0,cW,cH);
 ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(0,0,cW,cH);
 const data=FREQ_HIST.hz;
 if(data.length<2)return;
 const nyq=actx?actx.sampleRate/2:24000;
 let maxHz=0;data.forEach(v=>{if(v>maxHz)maxHz=v;});
 if(maxHz<5)return;
 maxHz=Math.min(maxHz*1.25,nyq);
 // Grid
 ctx.strokeStyle='rgba(255,255,255,.05)';ctx.lineWidth=1;
 for(let i=1;i<4;i++){
 const y=Math.round(cH*(i/4));
 ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cW,y);ctx.stroke();
 }
 // Hz label at top (maxHz)
 ctx.fillStyle='rgba(149,149,149,.5)';ctx.font=`${Math.round(7*dpr)}px monospace`;
 ctx.fillText(maxHz.toFixed(0)+'Hz',3*dpr,9*dpr);
 ctx.fillStyle='rgba(255,255,255,.2)';
 ctx.fillText('0Hz',3*dpr,cH-3*dpr);
 // Timeline line
 ctx.beginPath();
 let first=true;
 for(let i=0;i<data.length;i++){
 const v=data[i];
 if(v<=0){first=true;continue;}
 const x=(i/(data.length-1))*cW;
 const y=cH-(v/maxHz)*(cH*0.88)-cH*0.04;
 if(first){ctx.moveTo(x,y);first=false;}else{ctx.lineTo(x,y);}
 }
 const grd=ctx.createLinearGradient(0,0,cW,0);
 grd.addColorStop(0,'rgba(109,109,109,.4)');
 grd.addColorStop(0.6,'rgba(149,149,149,.55)');
 grd.addColorStop(1,'rgba(165,165,165,.8)');
 ctx.strokeStyle=grd;ctx.lineWidth=1.5*dpr;ctx.lineJoin='round';ctx.stroke();
 // Confirmed freq markers as dashed horizontal lines
 if(typeof freqDB!=='undefined'&&freqDB.size>0){
 ctx.setLineDash([2,4]);ctx.lineWidth=1;
 freqDB.forEach(e=>{
 if(!e.confirmed)return;
 const y=cH-(e.hz/maxHz)*(cH*0.88)-cH*0.04;
 if(y<0||y>cH)return;
 ctx.strokeStyle='rgba(165,165,165,.25)';
 ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cW,y);ctx.stroke();
 });
 ctx.setLineDash([]);
 }
 // Latest dot
 const last=data[data.length-1];
 if(last>0){
 const ly=cH-(last/maxHz)*(cH*0.88)-cH*0.04;
 ctx.beginPath();ctx.arc(cW-2*dpr,ly,2.5*dpr,0,Math.PI*2);
 ctx.fillStyle='rgba(165,165,165,.9)';ctx.fill();
 }
}

/* ══════════════════════════════════════════════
 ADAPTIVE NOTCH TRACKER
 Slides existing notch centers when fanFreq drifts
══════════════════════════════════════════════ */
const NOTCH_ADAPT={enabled:true,maxDrift:22,minDrift:2,cooldown:new Map()};

function adaptNotchTrack(newHz){
 if(!NOTCH_ADAPT.enabled||!newHz||newHz<1||!NOTCH_SUPPRESS.size)return;
 let bestKey=null,bestDelta=Infinity;
 NOTCH_SUPPRESS.forEach(({hz},k)=>{
 const d=Math.abs(hz-newHz);
 if(d>=NOTCH_ADAPT.minDrift&&d<=NOTCH_ADAPT.maxDrift&&d<bestDelta){bestDelta=d;bestKey=k;}
 });
 if(bestKey===null)return;
 const now=Date.now();
 const last=NOTCH_ADAPT.cooldown.get(bestKey)||0;
 if(now-last<2500)return; // max slide once per 2.5s
 const old=NOTCH_SUPPRESS.get(bestKey);
 if(!old)return;
 NOTCH_SUPPRESS.delete(bestKey);
 const newK=fBin(newHz);
 NOTCH_SUPPRESS.set(newK,{hz:newHz,depth:old.depth,halfBins:old.halfBins,lastHit:now,order:old.order||1});
 NOTCH_ADAPT.cooldown.set(newK,now);
 updateNotchUI();
 logNN(` NOTCH TRACK: ${old.hz.toFixed(1)}→${newHz.toFixed(1)}Hz (Δ${bestDelta.toFixed(1)}Hz)`);
}

/* ══ NOTCH DECAY CHECK ══ */
function checkNotchDecay(){
 if(!NOTCH_DECAY.enabled||!NOTCH_SUPPRESS.size)return;
 const now=Date.now();const toKill=[];
 NOTCH_SUPPRESS.forEach((n,k)=>{if(now-(n.lastHit||now)>NOTCH_DECAY.afterMs)toKill.push({k,hz:n.hz});});
 if(!toKill.length)return;
 toKill.forEach(({k,hz})=>{NOTCH_SUPPRESS.delete(k);logNN(` DECAY: ${hz.toFixed(1)}Hz expired (${(NOTCH_DECAY.afterMs/1000).toFixed(0)}s idle)`);});
 updateNotchUI();
}

/* ══ MULTI-PEAK DETECTOR (Dev100) ══
 Finds top-5 spectral peaks from FFT (excluding notched bins)
 Results stored in PEAKS_DATA.peaks = [{hz, db}] ══ */
function scanPeaks(fd,bHz,mxB){
 if(!fd||!bHz||fd.length<10)return;
 const candidates=[];
 // Local maxima via 2-neighbour comparison
 const lim=Math.min(mxB-3,4096);
 for(let i=3;i<lim;i++){
 if(fd[i]>fd[i-1]&&fd[i]>fd[i+1]&&fd[i]>fd[i-2]&&fd[i]>fd[i+2]){
 const a=fd[i-1],b=fd[i],c=fd[i+1],dv=2*b-a-c;
 // نفس إصلاح detectAll: خانة FFT مجاورة بطاقة صفرية (-Infinity من getFloatFrequencyData)
 // تجعل الإزاحة NaN — تُهمَل هنا وتُستبدَل بصفر كي لا يظهر "NaN Hz" في قائمة القمم الطيفية
 let _off=dv!==0?(a-c)/(2*dv):0;
 if(!isFinite(_off))_off=0;
 const hz=Math.max(0,(i+_off)*bHz);
 candidates.push({hz,db:b,bin:i});
 }
 }
 candidates.sort((a,b2)=>b2.db-a.db);
 const peaks=[];
 for(const cand of candidates){
 if(peaks.length>=PEAKS_DATA.maxPeaks)break;
 if(peaks.some(p=>Math.abs(p.hz-cand.hz)<bHz*4))continue; // too close
 if(NOTCH_SUPPRESS.has(fBin(cand.hz)))continue; // notched
 if(AI_GATE.enabled&&AI_BAN.has(fBin(cand.hz)))continue; // تشديد: تردد محضور لا يظهر في قائمة القمم الطيفية (PEAKS/EXPORT)
 peaks.push({hz:cand.hz,db:cand.db});
 }
 PEAKS_DATA.peaks=peaks;
 PEAKS_DATA.lastT=Date.now();
}

/* ══ SIGNAL QUALITY INDEX — 0-100 composite (Dev100) ══
 kfConf×30 + suppEff×30 + envStab×40 − hopPenalty(max 40) */
function computeSQI(){
 const kfConf=Math.max(0,Math.min(1,1-KF.P[0]/5));
 const suppEff=NOTCH_SUPPRESS.size?(SUPP_EFF.val||0)/100:1; // no notches = perfect eff
 const envTotal=Object.values(SESSION_STAT.envCount).reduce((a,b)=>a+b,0)||1;
 const envStab=Math.min(1,(SESSION_STAT.envCount[curEnvClass]||0)/envTotal);
 const hopCount=Math.max(0,FREQ_HOP.count-(SESSION_STAT.hopCount0||0));
 const hopPenalty=Math.min(40,hopCount*2);
 const raw=(kfConf*30+suppEff*30+envStab*40)-hopPenalty;
 SQI.val=Math.max(0,Math.min(100,Math.round(raw)));
 SQI.kfConf=Math.round(kfConf*100);
 SQI.suppEff=Math.round(suppEff*100);
 SQI.envStab=Math.round(envStab*100);
 SQI.hopPenalty=Math.round(hopPenalty);
 // rolling history for chart
 SQI_HIST.vals.push(SQI.val);if(SQI_HIST.vals.length>SQI_HIST.maxLen)SQI_HIST.vals.shift();
 // update stats card
 const sq=E('ss-sqi');if(sq){sq.textContent=SQI.val;sq.className='stat-val '+(SQI.val>=80?'green':SQI.val>=50?'yellow':'red');}
}

/* ══ SMART NOTCH SUGGESTION (Dev100) ══
 After N tonal detections at same stable freq → log + toast */
function checkNotchSuggest(hz){
 if(!hz||hz<1||!isRun)return;
 const k=fBin(hz);
 if(NOTCH_SUPPRESS.has(k)){NOTCH_SUGGEST.count=0;return;}
 const e=freqDB.get(k);
 // إصلاح خلل: e.confirmed حقل منطقي (true/false) وليس عدّاداً — مقارنته بـ<3 كانت تُقيَّم
 // دائماً true (true<3 و false<3 كلاهما true في JS)، فيجعل هذا الشرط صحيحاً دوماً ويُصفِّر
 // NOTCH_SUGGEST.count ويخرج في كل استدعاء، ما يُعطِّل ميزة اقتراح الـnotch كلياً. التحقّق
 // من "مؤكَّد فعلاً" يكفيه !e.confirmed وحدها — عدّاد الاستقرار الفعلي (N استدعاءات متتالية)
 // تتكفّل به NOTCH_SUGGEST.count/.threshold أدناه بشكل منفصل تماماً.
 if(!e||!e.confirmed){NOTCH_SUGGEST.count=0;return;}
 if(Math.abs(hz-NOTCH_SUGGEST.hz)>8){NOTCH_SUGGEST.hz=hz;NOTCH_SUGGEST.count=1;NOTCH_SUGGEST.shown=false;return;}
 NOTCH_SUGGEST.count++;
 if(NOTCH_SUGGEST.count>=NOTCH_SUGGEST.threshold&&!NOTCH_SUGGEST.shown){
 NOTCH_SUGGEST.shown=true;
 NOTCH_SUGGEST.toastT=Date.now();
 // مراجعة "المشروع بالكامل": e.confirmed حقل منطقي (true/false)، لا عدّاداً — كانت الرسالة
 // تطبع حرفياً "(true confirms)" بدل عدد مرات الرصد الفعلي؛ e.count هو العدّاد الحقيقي.
 logNN(` SUGGEST: ${hz.toFixed(1)}Hz is stable tonal (${e.count} confirms) — NOTCH ${Math.round(hz)} or tap spectrogram`);
 _showNotchToast(hz);
 }
}
function _showNotchToast(hz){
 let t=E('notchSuggestToast');
 if(!t){
 t=document.createElement('div');t.id='notchSuggestToast';
 t.style.cssText='position:fixed;bottom:calc(88px + var(--vv-bottom-inset,0px));right:14px;background:rgba(165,165,165,.13);border:1px solid rgba(165,165,165,.4);border-radius:8px;padding:9px 13px;font-family:var(--fm);font-size:11px;color:var(--text);z-index:9999;cursor:pointer;max-width:195px;line-height:1.5;backdrop-filter:blur(6px);box-shadow:0 4px 14px rgba(0,0,0,.35)';
 document.body.appendChild(t);
 }
 t.innerHTML=`<b>${hz.toFixed(1)} Hz</b> stable tonal<br><span style="color:var(--muted);font-size:9px">Tap to add notch · × dismiss</span>`;
 t.hidden=false;
 const dismiss=()=>{t.hidden=true;NOTCH_SUGGEST.shown=false;NOTCH_SUGGEST.count=0;};
 t.onclick=(ev)=>{
 const x=ev.offsetX/t.offsetWidth,y=ev.offsetY/t.offsetHeight;
 if(x>0.8&&y<0.3){dismiss();return;} // top-right corner = dismiss
 activateNotch(hz);logNN(` NOTCH via suggest: ${hz.toFixed(1)}Hz`);dismiss();
 };
 clearTimeout(NOTCH_SUGGEST._toastTimer);
 NOTCH_SUGGEST._toastTimer=setTimeout(()=>{if(t)t.hidden=true;},14000);
}

/* ══ SQI HISTORY CHART — mini line canvas in stats tab (Dev110) ══ */
function drawSQIHist(){
 const cv=E('sqiHistCv');if(!cv)return;
 const dpr=window.devicePixelRatio||1;
 const W=cv.clientWidth||200,H=44;
 if(cv.width!==Math.round(W*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 ctx.clearRect(0,0,cW,cH);
 ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(0,0,cW,cH);
 const data=SQI_HIST.vals;
 if(data.length<2){
 ctx.fillStyle='rgba(255,255,255,.18)';ctx.font=`${Math.round(8*dpr)}px monospace`;
 ctx.fillText('Waiting for data…',8*dpr,cH/2+3*dpr);return;
 }
 // Guide lines at 50 and 80
 ctx.setLineDash([2,4]);ctx.lineWidth=1;ctx.strokeStyle='rgba(255,255,255,.08)';
 [50,80].forEach(v=>{const y=cH-(v/100)*cH;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cW,y);ctx.stroke();});
 ctx.setLineDash([]);
 // Fill under curve
 ctx.beginPath();let first=true;
 for(let i=0;i<data.length;i++){const x=(i/(data.length-1))*cW,y=cH-(data[i]/100)*cH;if(first){ctx.moveTo(x,y);first=false;}else ctx.lineTo(x,y);}
 ctx.lineTo(cW,cH);ctx.lineTo(0,cH);ctx.closePath();
 ctx.fillStyle='rgba(135,135,135,.10)';ctx.fill();
 // Line
 const last=data[data.length-1];
 const col=last>=80?'#a5a5a5':last>=50?'#b0b0b0':'#7c7c7c';
 ctx.beginPath();first=true;
 for(let i=0;i<data.length;i++){const x=(i/(data.length-1))*cW,y=cH-(data[i]/100)*cH;if(first){ctx.moveTo(x,y);first=false;}else ctx.lineTo(x,y);}
 ctx.strokeStyle=col;ctx.lineWidth=1.5*dpr;ctx.lineJoin='round';ctx.stroke();
 // Latest dot
 {const x=cW-2*dpr,y=cH-(last/100)*cH;ctx.beginPath();ctx.arc(x,y,2.5*dpr,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();}
 // Corner labels
 ctx.fillStyle='rgba(255,255,255,.25)';ctx.font=`${Math.round(6*dpr)}px monospace`;
 ctx.fillText('100',3*dpr,7*dpr);ctx.fillText('0',3*dpr,cH-2*dpr);
 ctx.fillStyle=col;ctx.textAlign='right';ctx.fillText(last,cW-3*dpr,7*dpr);ctx.textAlign='left';
}

/* ══ OCTAVE BAND POWER — 9 standard bands (Dev110) ══ */
function updateBandPower(fd,bHz){
 if(!bHz||!fd||fd.length<4)return;
 BAND_POWER.BANDS.forEach((b,i)=>{
 const lo=Math.max(1,Math.round(b.lo/bHz)),hi=Math.min(fd.length-1,Math.round(b.hi/bHz));
 if(lo>=hi)return;
 let sum=0,n=0;
 for(let j=lo;j<=hi;j++){sum+=Math.pow(10,fd[j]/10);n++;}
 const rms=n>0?10*Math.log10(Math.max(1e-10,sum/n)):-80;
 BAND_POWER.vals[i]=BAND_POWER.vals[i]*.75+rms*.25; // exponential smooth
 });
}

/* ══ FREQUENCY ALARM CHECKER (Dev110) ══ */
function checkFreqAlarms(hz){
 if(!FREQ_ALARMS.size||!hz||hz<1)return;
 const now=Date.now();
 FREQ_ALARMS.forEach(alarm=>{
 if(!alarm.enabled)return;
 if(Math.abs(hz-alarm.hz)>alarm.tol)return;
 if(now-alarm.lastTrigT<alarm.cooldown)return;
 alarm.count++;alarm.lastTrigT=now;
 logNN(` ALARM: ${alarm.hz.toFixed(1)}Hz detected at ${hz.toFixed(2)}Hz (hit #${alarm.count})`);
 // reuse hop flash for visual alert (orange pulse)
 const fl=E('freqHopFlash');
 if(fl){const old=fl.style.background;fl.style.background='rgba(173,173,173,.8)';fl.style.opacity='1';setTimeout(()=>{fl.style.opacity='0';setTimeout(()=>{fl.style.background=old;},400);},700);}
 });
}

/* ══ SPECTRAL DELTA (Dev110) ══
 Compare current FFT to saved baseline → show freq changes */
function computeSpecDelta(){
 if(!SPEC_DELTA.baseline||!lastFFD)return null;
 const len=Math.min(SPEC_DELTA.baseline.length,lastFFD.length);
 const bHz=SPEC_DELTA.bHz||0.5;
 const changes=[];
 for(let i=2;i<len&&i*bHz<10000;i++){
 const d=lastFFD[i]-SPEC_DELTA.baseline[i];
 if(Math.abs(d)>3.0){
 const hz=i*bHz;
 if(AI_GATE.enabled&&AI_BAN.has(fBin(hz)))continue; // تشديد: تردد محضور مستبعد من قائمة فروقات DELTA
 changes.push({hz,diff:d,bin:i});
 }
 }
 changes.sort((a,b)=>Math.abs(b.diff)-Math.abs(a.diff));
 return changes.slice(0,14);
}

/* ══ ADAPTIVE ALERT (Dev120) ══
 Progressive logNN alerts when SQI drops or hop-rate spikes.
 Called from updateExecUI() every ~80ms. */
function checkAdaptiveAlert(){
 if(!ADAPTIVE_ALERT.enabled||!isRun)return;
 const now=Date.now();
 if(now-ADAPTIVE_ALERT.lastT<ADAPTIVE_ALERT.cooldown)return;
 const hopRate=Math.max(0,FREQ_HOP.count-(SESSION_STAT.hopCount0||0));
 let newLevel='ok';
 if(SQI.val<ADAPTIVE_ALERT.critSQI)newLevel='critical';
 else if(SQI.val<ADAPTIVE_ALERT.warnSQI||hopRate>ADAPTIVE_ALERT.warnHops)newLevel='warn';
 if(newLevel!==ADAPTIVE_ALERT.level||newLevel!=='ok'){
 ADAPTIVE_ALERT.level=newLevel;ADAPTIVE_ALERT.lastT=now;
 if(newLevel==='critical')logNN(` ALERT CRITICAL: SQI=${SQI.val} — tracking unstable!`);
 else if(newLevel==='warn')logNN(` ALERT WARN: SQI=${SQI.val} · hops=${hopRate}`);
 else logNN(` ALERT CLEAR: SQI=${SQI.val} — signal stable`);
 }
}

/* ══════════════════════════════════════════════
 INPUT LEVEL METER — RMS + peak hold + clip flash
══════════════════════════════════════════════ */
const LVL={rms:0,peak:0,peakHold:0,peakHoldT:0,clipT:0};

function updateLevelMeter(td){
 let sum=0,pk=0;
 for(let i=0;i<td.length;i++){const v=(td[i]-128)/128;sum+=v*v;if(Math.abs(v)>pk)pk=Math.abs(v);}
 LVL.rms=Math.sqrt(sum/td.length);
 // Peak hold (2s decay)
 const now=Date.now();
 if(pk>LVL.peakHold||now-LVL.peakHoldT>2000){LVL.peakHold=pk;LVL.peakHoldT=now;}
 const db=LVL.rms>0?20*Math.log10(LVL.rms):-Infinity;
 const dbC=Math.max(-60,Math.min(0,db));
 const pct=Math.max(0,Math.min(100,(dbC+60)/60*100));
 const peakDB=LVL.peakHold>0?20*Math.log10(LVL.peakHold+0.00001):-60;
 const peakPct=Math.max(0,Math.min(100,(Math.max(-60,peakDB)+60)/60*100));
 if(pk>0.97)LVL.clipT=now;
 const clipping=now-LVL.clipT<900;
 // Show meter when running
 const meter=E('lvlMeter');if(meter&&meter.style.display==='none'&&isRun)meter.style.display='flex';
 const rmsEl=E('lvlRms');
 if(rmsEl){
 rmsEl.style.width=pct+'%';
 rmsEl.style.background=clipping?'linear-gradient(90deg,var(--on),var(--off))':'linear-gradient(90deg,var(--on),var(--sharp))';
 }
 const peakEl=E('lvlPeak');if(peakEl)peakEl.style.left=peakPct+'%';
 const dbEl=E('lvlDb');if(dbEl)dbEl.textContent=isFinite(db)?db.toFixed(1)+'dB':'—dB';
 const clipEl=E('lvlClip');if(clipEl)clipEl.className='lvl-clip'+(clipping?' on':'');
}

/* ══════════════════════════════════════════════
 SCENE PROFILES — Named environment snapshots
 Save/load FreqDB + notches + env to IndexedDB
══════════════════════════════════════════════ */
let SCENE_ACTIVE=null;

function _sceneDB(){
 return new Promise((res,rej)=>{
 // Reuse zeroDB if already open and has 'scenes' store
 if(zeroDB&&zeroDB.objectStoreNames.contains('scenes')){res(zeroDB);return;}
 // Otherwise open with bumped version to create the store
 const req=indexedDB.open('ZeroAIv25',4);
 req.onupgradeneeded=ev=>{
 const db=ev.target.result;
 if(!db.objectStoreNames.contains('scenes'))
 db.createObjectStore('scenes',{keyPath:'name'});
 };
 req.onsuccess=ev=>{
 // If this opened a newer handle, update zeroDB
 const db=ev.target.result;
 zeroDB=db;
 res(db);
 };
 req.onerror=ev=>rej(ev.target.error);
 });
}

async function sceneSave(name){
 name=(name||'').trim();if(!name)return null;
 try{
 const db=await _sceneDB();
 const freqs=[...freqDB.values()];
 const notches=[...NOTCH_SUPPRESS.values()];
 const scene={name,ts:Date.now(),env:curEnvClass,freqCount:freqs.length,notchCount:notches.length,freqs,notches};
 await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readwrite');
 tx.objectStore('scenes').put(scene);
 tx.oncomplete=()=>res(scene);tx.onerror=ev=>rej(ev.target.error);
 });
 SCENE_ACTIVE=name;
 const sb=E('sceneBadge');if(sb){sb.textContent=`scene: ${name}`;sb.className='scene-badge visible';}
 // "توحيد الكل في مجلد واحد": مرآة فورية لكل المشاهد المحفوظة إلى المجلد الثابت (fire-and-
 // forget — لا تُبطئ حفظ المشهد نفسه في IndexedDB، وفشلها لا يُفسِد الحفظ الأساسي).
 _syncScenesToFixedFolder();
 return scene;
 }catch(e){console.warn('sceneSave:',e);return null;}
}

async function sceneLoad(name){
 name=(name||'').trim();if(!name)return null;
 try{
 const db=await _sceneDB();
 const scene=await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readonly');
 const req=tx.objectStore('scenes').get(name);
 req.onsuccess=ev=>res(ev.target.result);req.onerror=ev=>rej(ev.target.error);
 });
 if(!scene)return null;
 // مراجعة "النسخة النهائية": كانت freqDB.clear() تُنفَّذ قبل أي تحقّق من شكل scene.freqs/
 // notches — مشهد مستورَد من ملف مُعدَّل يدوياً أو تالف (لا يحمل حقل freqs مصفوفة) كان
 // يُفرِغ freqDB بالكامل ثم يرمي استثناء داخل forEach، يُلتقَط بصمت في catch الخارجي —
 // فيفقد المستخدم كل ترددات جلسته الحالية بلا أي استعادة أو رسالة خطأ واضحة. التحقق الآن
 // يسبق أي تعديل فعلي على الحالة.
 if(!Array.isArray(scene.freqs)||!Array.isArray(scene.notches)){
 console.warn('sceneLoad: مشهد بشكل غير صالح (freqs/notches ليست مصفوفة) — تم تجاهله بلا تعديل الحالة الحالية');
 return null;
 }
 // Restore
 freqDB.clear();
 scene.freqs.forEach(e=>freqDB.set(e.hz!=null?e.hz:fBin(e.hz||0),e));
 NOTCH_SUPPRESS.clear();
 scene.notches.forEach(n=>NOTCH_SUPPRESS.set(fBin(n.hz),n));
 updateNotchUI();
 SCENE_ACTIVE=name;
 const sb=E('sceneBadge');if(sb){sb.textContent=`scene: ${name}`;sb.className='scene-badge visible';}
 return scene;
 }catch(e){console.warn('sceneLoad:',e);return null;}
}

async function sceneList(){
 try{
 const db=await _sceneDB();
 return await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readonly');
 const req=tx.objectStore('scenes').getAll();
 req.onsuccess=ev=>res(ev.target.result||[]);req.onerror=ev=>rej(ev.target.error);
 });
 }catch(e){return[];}
}

async function sceneDelete(name){
 name=(name||'').trim();if(!name)return false;
 try{
 const db=await _sceneDB();
 await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readwrite');
 tx.objectStore('scenes').delete(name);
 tx.oncomplete=()=>res(true);tx.onerror=ev=>rej(ev.target.error);
 });
 if(SCENE_ACTIVE===name){
 SCENE_ACTIVE=null;
 const sb=E('sceneBadge');if(sb)sb.className='scene-badge';
 }
 _syncScenesToFixedFolder();
 return true;
 }catch(e){return false;}
}
/* "توحيد الكل في مجلد واحد" — المشاهد المحفوظة (scenes: إعدادات غرفة/ترددات مُسمّاة يحفظها
 المستخدم صراحة عبر sceneSave) كانت تعيش حصراً داخل IndexedDB (تخزين المتصفح)، بلا أي مسار
 إطلاقاً إلى المجلد الثابت (My Files) — بخلاف كل بيانات التطبيق الأخرى (حظر/FreqDB/NN/
 إنجازات) التي تصل جميعها الآن لنفس المجلد. أي مسح لبيانات التطبيق (من إعدادات أندرويد، إعادة
 تثبيت، إعادة ضبط الجهاز) كان يفقد كل المشاهد المحفوظة نهائياً بلا أي نسخة احتياطية ممكنة —
 فجوة حقيقية في "توحيد الكل" رغم أنها بيانات مُسمّاة يحفظها المستخدم صراحة، تماماً كالحظر.
 اسم ملف ثابت (لا طابع زمني، لا تراكم يحتاج تنظيفاً) لأن IndexedDB نفسها تُدار بنفس المنطق:
 مفتاح فريد بالاسم (keyPath:'name') يُستبدَل لا يتراكم — هذا الملف مرآة مباشرة لتلك القائمة
 بأكملها، تُحدَّث فوراً مع كل حفظ أو حذف مشهد. */
const WTAFS_SCENES_FILE='ZeroAI_Scenes.json';
// حارس تزامن (نفس نمط _wtafsResourcesGen): _syncScenesToFixedFolder تُستدعى دون انتظار (fire-
// and-forget) من موقعين مختلفين (sceneSave وsceneDelete)، ولها نقطة انتظار واحدة (sceneList).
// حفظ/حذف سريعان متتاليان (مثل استيراد عدة مشاهد، أو نقرات متلاحقة) يُطلقان نداءين متداخلين —
// وإن استقرت قراءة الأقدم بعد الأحدث، ستكتب بيانات قديمة فوق المرآة الأحدث بصمت. الحارس يضمن أن
// النتيجة المكتوبة فعلياً تعكس دائماً آخر نداء تم "إطلاقه" لا أياً كان النداء الذي "استقر" أخيراً.
let _scenesSyncGen=0;
async function _syncScenesToFixedFolder(){
 if(!_wtafsOk()||!WebToApkFS.hasAccess())return;
 const myGen=++_scenesSyncGen;
 try{
 const scenes=await sceneList();
 if(myGen!==_scenesSyncGen)return; // نداء أحدث تجاوز هذا النداء — تُهمَل الكتابة كي لا تُفسِد المرآة بحالة قديمة
 const json=JSON.stringify({version:'ZeroAI_Scenes_v1',syncDate:new Date().toISOString(),scenes},null,2);
 WebToApkFS.writeText(WTAFS_SCENES_FILE,json);
 }catch(e){/* فشل مزامنة المرآة لا يُفسِد المصدر الأساسي (IndexedDB) — يُهمَل بصمت */}
}
/* استعادة المشاهد من ملف المرآة — دمج بالاسم (put، مثل sceneSave نفسها) لا استبدال كامل، كي لا
 تُمحى مشاهد موجودة على هذا الجهاز وغائبة عن الملف المستورَد (نفس فلسفة الدمج الإضافي
 المُستخدَمة أصلاً لملفات الحظر). */
async function _restoreScenesFromJSON(raw,sourceLabel){
 const data=JSON.parse(raw);
 if(!Array.isArray(data.scenes))throw new Error('صيغة ملف المشاهد غير صحيحة — يجب أن يحتوي على مفتاح "scenes"');
 const db=await _sceneDB();
 let added=0,updated=0,skipped=0;
 for(const scene of data.scenes){
 if(!scene||typeof scene!=='object'||!scene.name){skipped++;continue;}
 // مراجعة "النسخة النهائية": رفض الفساد من مصدره (نفس فلسفة loadBans) — مشهد بلا freqs/
 // notches كمصفوفتين صالحتين لا يُخزَّن أصلاً، بدل الاعتماد فقط على تحقّق sceneLoad اللاحق؛
 // مسارات قراءة أخرى قد تفترض هذا الشكل دون المرور بذلك التحقّق.
 if(!Array.isArray(scene.freqs))scene.freqs=[];
 if(!Array.isArray(scene.notches))scene.notches=[];
 const existed=await new Promise(res=>{
 const tx=db.transaction('scenes','readonly');
 const req=tx.objectStore('scenes').get(scene.name);
 req.onsuccess=ev=>res(!!ev.target.result);req.onerror=()=>res(false);
 });
 await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readwrite');
 tx.objectStore('scenes').put(scene);
 tx.oncomplete=()=>res();tx.onerror=ev=>rej(ev.target.error);
 });
 if(existed)updated++;else added++;
 }
 if(skipped)stLog(' تُجوهِل '+skipped+' مشهد بلا اسم صالح أثناء الاستيراد من '+sourceLabel);
 stLog(' مشاهد: +'+added+' جديد + تحديث '+updated+' موجود من '+sourceLabel);
 return {added,updated,skipped,total:data.scenes.length};
}

function updateStatsTab(){
 if(isRun)classifyEnvironment();
 const fmt=ms=>{const s=Math.floor(ms/1000),m=Math.floor(s/60),h=Math.floor(m/60);return h?`${h}h ${m%60}m`:`${m}m ${s%60}s`;};
 const se=id=>E(id);
 const up=se('ss-uptime');if(up)up.textContent=fmt(Date.now()-SESSION_START);
 const cyc=se('ss-aicyc');if(cyc)cyc.textContent=typeof aiCyc!=='undefined'?aiCyc.toLocaleString():'0';
 const fq=se('ss-freqs');if(fq)fq.textContent=typeof freqDB!=='undefined'?freqDB.size:0;
 const bn=se('ss-banned');if(bn)bn.textContent=typeof AI_BAN!=='undefined'?AI_BAN.size:0;
 const ac=se('ss-acc');
 if(ac){
 const loss=typeof NN!=='undefined'&&NN.trainN>0?NN.loss:null;
 ac.textContent=loss!==null?Math.round((1-loss)*100)+'%':'—';
 if(loss!==null){ac.className='stat-val '+(loss<0.3?'green':loss<0.6?'yellow':'red');}
 }
 const ps=se('ss-preset');if(ps)ps.textContent=(PRESETS[curPreset]&&PRESETS[curPreset].emoji?PRESETS[curPreset].emoji+' ':'')+curPreset.toUpperCase();
 // thermal status
 const ts=se('ss-thermal-status'),td=se('ss-thermal-detail');
 if(thermalThrottleOn){
 if(ts)ts.textContent='تحذير حرارة';if(ts)ts.style.color='var(--off)';
 if(td)td.textContent='تم تفعيل التخفيف الحراري';
 } else {
 if(ts){ts.textContent='جيدة';ts.style.color='var(--on)';}
 if(td)td.textContent='جميع المناطق ضمن الحدود الآمنة';
 }
 // DB stats
 const dbs=se('ss-db-saved');
 if(dbs)dbs.textContent=lastFreqDBSave?lastFreqDBSave.toLocaleTimeString('ar-SA'):'—';
 // حجم IndexedDB الفعلي — تطوير مراقبة التراكم، 28 سبتمبر 2026: كانت القيمة المعروضة هنا
 // تقديراً تقريبياً بحتاً (freqDB.size*0.2 بلا أي أساس فعلي لحجم البايتات)، بينما التطبيق
 // يملك أصلاً مصدراً دقيقاً (navigator.storage.estimate()) مُستخدَماً في مكانين آخرين
 // (reqStoragePersist وأمر EXEC النصّي STATS) — الآن نفس المصدر الدقيق هنا أيضاً، والتقدير
 // القديم يبقى فقط احتياطاً لبناء WebView قديم لا يدعم Storage API إطلاقاً.
 const dbsz=se('ss-db-size');
 if(dbsz){
 if(navigator.storage&&navigator.storage.estimate){
 navigator.storage.estimate().then(est=>{
 if(dbsz)dbsz.textContent=Math.round((est.usage||0)/1024).toLocaleString()+' KB';
 }).catch(()=>{
 if(typeof freqDB!=='undefined'){const approx=Math.round(freqDB.size*0.2);dbsz.textContent=approx?approx+' KB':'—';}
 });
 } else if(typeof freqDB!=='undefined'){
 const approx=Math.round(freqDB.size*0.2);
 dbsz.textContent=approx?approx+' KB':'—';
 }
 }
 // مراقبة التراكم لكل مخزن UDS — udsGetStats() كانت موجودة أصلاً لكن غير مستخدَمة إطلاقاً في
 // أي واجهة مرئية (فقط داخل أمر EXEC نصّي STATS)؛ هنا تُعرَض حيّاً مع السقف الفعلي لكل مخزن
 // مُقلَّم تلقائياً (UDS_CAP من 08c-background-db.js).
 if(typeof udsGetStats==='function'){
 udsGetStats().then(counts=>{
 const rowsEl=se('ss-uds-rows');
 if(!rowsEl)return;
 const STORE_LABELS={terminal_events:'سجلّ الطرفية',exec_history:'تنفيذ AI',nn_history:'الشبكة العصبية',freq_patterns:'أنماط الترددات',sessions:'الجلسات'};
 rowsEl.innerHTML=Object.entries(counts).map(([name,count])=>{
 const cap=(typeof UDS_CAP!=='undefined')?UDS_CAP[name]:null;
 const label=STORE_LABELS[name]||name;
 const pct=cap?Math.round((count/cap)*100):null;
 const valTxt=cap?`${count.toLocaleString()} / ${cap.toLocaleString()}`:`${count.toLocaleString()}`;
 const color=(cap&&pct>=90)?'var(--sharp)':'var(--dim)';
 return `<div style="display:flex;justify-content:space-between;align-items:center">`+
 `<span style="color:var(--muted)">${label}</span>`+
 `<span style="color:${color}">${valTxt}${cap?` <span style="opacity:.6">(${pct}%)</span>`:''}</span>`+
 `</div>`;
 }).join('');
 }).catch(()=>{});
 }
 drawSQIHist(); // Dev110: SQI history chart
}

function openTab(n){
 curTab=n;
 for(let i=0;i<9;i++){
 const b=E('tb'+i),p=E('pane'+i);
 if(b)b.classList.toggle('act',i===n);
 if(p)p.classList.toggle('on',i===n);
 }
 // Tab-specific refresh
 if(n===1)drawRwChart();
 if(n===2)drawClassChart();
 if(n===3){updateMicUI();updateMicFeat();}
 if(n===5)renderExecLog();
 if(n===6)updBGUI();
 if(n===7){updateFilesUI();refreshSessionList();}
 // STATS tab — start auto-refresh interval
 if(n===8){
 updateStatsTab();
 if(!statsIv)statsIv=setInterval(updateStatsTab,2000);
 } else {
 if(statsIv){clearInterval(statsIv);statsIv=null;}
 }
}

/* ══ AUDIO INIT ══ */
// إغلاق الفراغات: حماية إضافية — حتى لو استُدعيت initAudio() من مسار آخر غير toggleAI() (حارس
// _toggleBusy لا يحميه)، هذا الحارس (وعد واحد مُشترَك) يمنع أي نداءين متزامنين من إنشاء طلبي
// getUserMedia()+AudioContext منفصلين؛ النداء الثاني يستلم نفس وعد النداء الأول قيد التنفيذ بدل
// بدء تهيئة صوتية ثانية توضّع مصدر التسريب الحقيقي — سياق صوت (AudioContext) حيّ منسي لا مرجع
// له بعد أن يكتب النداء اللاحق فوق actx/micStr العامّين.
